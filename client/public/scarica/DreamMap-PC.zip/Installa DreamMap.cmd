@echo off
rem DreamMap per PC: doppio clic qui e fa tutto da solo. Se manca .NET 8, Windows chiede il
rem permesso per installarlo; per il resto non servono permessi da amministratore.
rem
rem Se lo apri DENTRO lo zip (WinRAR, 7-Zip, Esplora file), il programma estrae solo questo
rem file in una cartella temporanea e il resto del pacchetto non c'e': in quel caso cerca lo
rem zip in Download (o sul Desktop), lo estrae da solo e riparte da li'.
cd /d "%~dp0"
if exist "%~dp0installa.ps1" if exist "%~dp0app\FocusLock.exe" goto installa

echo Sto estraendo il pacchetto completo...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dove = @(); try { $dove += (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch {}; $dove += (Join-Path $env:USERPROFILE 'Downloads'); $dove += [Environment]::GetFolderPath('Desktop'); $z = $dove | Where-Object { $_ -and (Test-Path $_) } | ForEach-Object { Get-ChildItem -Path $_ -Filter 'DreamMap-PC*.zip' -ErrorAction SilentlyContinue } | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if (-not $z) { exit 2 }; $d = Join-Path $env:LOCALAPPDATA 'DreamMap-installa'; if (Test-Path $d) { Remove-Item $d -Recurse -Force }; Expand-Archive -LiteralPath $z.FullName -DestinationPath $d -Force; exit 0"
if errorlevel 1 goto nonTrovato
call "%LOCALAPPDATA%\DreamMap-installa\DreamMap-PC\Installa DreamMap.cmd"
exit /b

:nonTrovato
echo.
echo Non trovo DreamMap-PC.zip in Download o sul Desktop.
echo Fai clic destro sullo zip, scegli "Estrai tutto", apri la cartella estratta
echo e fai doppio clic su "Installa DreamMap" da li'.
echo.
pause
exit /b

:installa
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installa.ps1"
if errorlevel 1 (
  echo.
  echo Qualcosa non e' andato: leggi il messaggio sopra.
)
echo.
pause
