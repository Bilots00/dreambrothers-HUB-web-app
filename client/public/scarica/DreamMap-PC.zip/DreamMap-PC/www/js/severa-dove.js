/* ===========================================================================================
   DOVE VALE LA MODALITA' SEVERA: SOLO SUL TELEFONO O ANCHE SUL COMPUTER

   0.9.395, Andrea: "voglio rendere i toggle della versione desktop non disattivabili durante la
   modalità severa [...] adesso si può spuntare via anche se la modalità severa è attiva dal
   telefono. [...] se l'utente ha la versione desktop scaricata e il profilo collegato, deve poter
   scegliere se attivarla solo dal telefono o anche sul computer."

   CHI FA COSA:
   - il TELEFONO pubblica il suo stato della Modalita' severa nella riga dell'account fl:sev-stato
     (sdvPubblicaStato, dopo ogni lettura del motore e almeno una volta al giorno);
   - la scelta "solo sul telefono / anche sul computer" viaggia in fl:sev-dove, che scrivono tutti
     e due (vince la piu' recente). Il telefono la segna da solo, col valore di serie "anche sul
     computer", quando si accende una sessione con un computer collegato (sdvSegnaAllAvvio);
   - il PROGRAMMA DEL COMPUTER (focuslock-desktop: RulesSync + PhoneStrictSync) legge le due righe
     e rifiuta lui toggle, cestino e allentamenti, anche dal pannello, senza dipendere da questa
     pagina. Nella Vista telefono del computer getRulesFull.strict dice gia' se le regole di li'
     sono chiuse (anche dalla Modalita' severa del telefono), e getRulesFull.sevDove la scelta.

   E UNA FUNZIONE SOLA decide se una modifica si puo' fare: sevRifiuta(azione, cosa). La usano
   le schermate di questa pagina sul telefono, nella Vista telefono e nell'app Android.
   =========================================================================================== */

const SDV_KEY = 'fl_sev_dove';            // 'telefono' | 'computer'
const SDV_T = 'fl_sev_dove_t';            // quando e' stata fatta la scelta (vince la piu' recente)
const SDV_SLOT_DOVE = 'fl:sev-dove';
const SDV_SLOT_STATO = 'fl:sev-stato';
let SDV_PC_LIVELLO = 0;                   // sul computer: getRulesFull.strict (programma del computer o telefono)
let SDV_PC_DOVE = '';                     // sul computer: getRulesFull.sevDove
let SDV_PUB_FIRMA = '';

function sdvLs(k){ try{ return localStorage.getItem(k); }catch(_){ return null; } }
function sdvLsSet(k, v){ try{ if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); }catch(_){ } }

/** Questa pagina gira sul computer (Vista telefono di DreamMap per il computer)? */
function sdvSuPc(){
  try{
    if (typeof pcQui === 'function') return pcQui() === 'desktop';
    return !!(window.Capacitor && Capacitor.getPlatform && Capacitor.getPlatform() === 'desktop');
  }catch(_){ return false; }
}

/** C'e' un computer con la versione per il computer collegato a questo profilo?
 *  Il segnale e' la riga che il computer scrive ogni dieci minuti nell'account (pcdati.js,
 *  fl:pc-usage -> cache fl_pc_usage / fl_altro_usage). Sul computer la risposta e' si'. */
function sdvPcCollegato(){
  if (sdvSuPc()) return true;
  try{ if (typeof mwDueDispositivi === 'function' && mwDueDispositivi()) return true; }catch(_){ }
  for (const k of ['fl_pc_usage', 'fl_altro_usage']){
    try{
      const c = JSON.parse(sdvLs(k) || 'null');
      if (c && c.doc && c.doc.giorni && Object.keys(c.doc.giorni).length) return true;
    }catch(_){ }
  }
  return false;
}

/** 'computer' o 'telefono'. Di serie "anche sul computer": la protezione e' la cosa che conta. */
function sdvDove(){
  if (sdvSuPc() && (SDV_PC_DOVE === 'telefono' || SDV_PC_DOVE === 'computer')) return SDV_PC_DOVE;
  const v = sdvLs(SDV_KEY);
  return v === 'telefono' ? 'telefono' : 'computer';
}
function sdvValePerPc(){ return sdvDove() === 'computer'; }
/** La scelta e' stata fatta davvero (a mano, o segnata all'avvio di una sessione)? */
function sdvScelta(){ return !!(+sdvLs(SDV_T) || 0); }

function sdvSetDove(v, daAltro){
  if (v !== 'telefono' && v !== 'computer') return;
  /* togliere il computer mentre la Modalita' severa e' accesa e vale anche li' e' allentare:
     no (lo rifiuta anche il programma del computer, PhoneStrict.RefuseChoice) */
  if (!daAltro && v === 'telefono' && sdvDove() === 'computer' && sdvScelta() && sevBloccaQui()){
    try{ toast(sevFrase()); }catch(_){ }
    return;
  }
  sdvLsSet(SDV_KEY, v);
  if (sdvSuPc()) SDV_PC_DOVE = v;
  if (!daAltro){ sdvLsSet(SDV_T, String(Date.now())); sdvPubblicaDove(); }
  try{ document.querySelectorAll('[data-sdv]').forEach(function(b){ b.classList.toggle('on', b.dataset.sdv === v); b.setAttribute('aria-pressed', b.dataset.sdv === v ? 'true' : 'false'); }); }catch(_){ }
}

/** La Modalita' severa blocca le modifiche QUI, adesso? Una risposta sola per tutte le schermate. */
function sevBloccaQui(){
  /* il motore del telefono (getStrictState -> inAppEditLocked) */
  try{ if (typeof BLK_STRICT !== 'undefined' && BLK_STRICT && BLK_STRICT.inAppEditLocked) return true; }catch(_){ }
  /* sul computer: la risposta del programma (getRulesFull.strict), che conta anche la Modalita'
     severa del telefono quando vale per il computer */
  return sdvSuPc() && SDV_PC_LIVELLO > 0;
}

function sdvFineTesto(){
  let until = 0;
  try{ if (typeof BLK_STRICT !== 'undefined' && BLK_STRICT && +BLK_STRICT.strictUntil > 0) until = +BLK_STRICT.strictUntil; }catch(_){ }
  if (until > Date.now()){
    const d = new Date(until);
    const g = d.toLocaleDateString('it-IT', { day: 'numeric', month: 'long' });
    const h = d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
    return 'Finisce il ' + g + ' alle ' + h + '.';
  }
  return 'Quando finisce lo vedi nella pagina Modalità severa.';
}
/** La riga che spiega il rifiuto (la stessa del programma del computer, PhoneStrict.Refusal). */
function sevFrase(){ return 'La Modalità severa è accesa: le regole non si spengono finché non finisce. ' + sdvFineTesto(); }

/**
 * LA funzione che decide. null = si puo' fare; altrimenti la frase da mostrare.
 * azione: 'spegni' | 'elimina' | 'allenta' (rifiutate con la Modalita' severa accesa)
 *         'aggiungi' | 'stringi' (sempre permesse: aggiungere regole o renderle piu' severe si puo' sempre)
 * cosa:   la regola / il programma / il limite toccato (facoltativo)
 */
function sevRifiuta(azione, cosa){
  if (azione === 'aggiungi' || azione === 'stringi') return null;
  if (!sevBloccaQui()) return null;
  /* i due minuti di grazia di un programma appena creato o duplicato (0.9.290) */
  try{ if (cosa && typeof blkInGrazia === 'function' && blkInGrazia(cosa)) return null; }catch(_){ }
  /* PUNTO UNICO per le eccezioni di una singola regola. Qui va (e solo qui) l'eccezione dei
     programmi creati dal Genio e non ancora confermati (cosa.confermato === false): la aggiunge
     chi lavora su quel ramo, con la sua regola. (Sul computer l'eccezione c'e' gia', nel
     programma: StrictMode.RefuseRuleChange salta le regole con Confermato == false.) */
  /* 0.9.395, Andrea: "e' un errore del genio oggettivo": il programma creato dal Genio e non ancora confermato
     si cambia e si toglie anche con la Modalita' severa accesa, senza punti al vecchio te (blkDaConfermare, blocco.js) */
  try{ if (cosa && typeof blkDaConfermare === 'function' && blkDaConfermare(cosa)) return null; }catch(_){ }
  return sevFrase();
}

/**
 * Il controllo sulle SCRITTURE al motore (blocco.js -> blkNative). Sul telefono lo fa gia' il
 * motore Android (refuseIfWeakening). Nella Vista telefono del computer il ponte (setRulesFull ->
 * MobileBridge.ApplyRules) non passa dal controllo del pannello, quindi si controlla qui. Togliere
 * un sito, una parola o un'app dal blocco, aggiungere un'eccezione, spegnere: e' allentare.
 */
let SDV_ULTIME = null;   // le ultime regole lette dal motore (getRulesFull)
const SDV_BLOCCO = ['sites', 'keywords', 'apps'];
const SDV_ECCEZIONI = ['allow', 'allowApps', 'allowWords'];
function sdvRicordaRegole(r){
  if (!r || typeof r !== 'object') return;
  SDV_ULTIME = r;
  if (typeof r.strict === 'number' && sdvSuPc()) SDV_PC_LIVELLO = r.strict;
  if (r.sevDove === 'telefono' || r.sevDove === 'computer') SDV_PC_DOVE = r.sevDove;
}
function sdvAllenta(method, args, prima){
  args = args || {};
  if (method === 'setEnabled' && args.enabled === false) return true;
  if (method === 'unblockApp') return true;
  if (method === 'setQuickBlock' && args.enabled === false) return true;
  if (method !== 'setRulesFull') return false;
  if (args.enabled === false) return true;
  prima = prima || {};
  const lista = function(x){ return Array.isArray(x) ? x.map(String) : null; };
  for (const k of SDV_BLOCCO){
    const n = lista(args[k]), p = lista(prima[k]);
    if (n && p && p.some(function(v){ return n.indexOf(v) < 0; })) return true;   // ne manca una
  }
  for (const k of SDV_ECCEZIONI){
    const n = lista(args[k]), p = lista(prima[k]) || [];
    if (n && n.some(function(v){ return p.indexOf(v) < 0; })) return true;         // un'eccezione in piu'
  }
  return false;
}
/** null = la scrittura passa; altrimenti la frase del rifiuto. */
function sevRifiutaScrittura(method, args){
  if (!sdvSuPc()) return null;              // sul telefono decide il motore
  if (!sdvAllenta(method, args, SDV_ULTIME)) return null;
  return sevRifiuta('allenta', null);
}

/* ---------- le due righe dell'account (le legge il programma del computer) ---------- */
function sdvApi(){ try{ return (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi) ? NATIVE : null; }catch(_){ return null; } }
async function sdvScriviRiga(slot, nome, dati){
  const n = sdvApi(); if (!n) return false;
  try{
    await n.accountApi({ method: 'PUT', path: '/api/focuslock/backups', body: JSON.stringify({
      deviceId: slot, deviceName: nome, appVersion: slot,
      summary: { programs: 0, apps: 0, sites: 0, keywords: 0 },
      backup: { web: { sevdove: dati } } }) });
    return true;
  }catch(_){ return false; }
}
function sdvPubblicaDove(){
  const t = +sdvLs(SDV_T) || 0; if (!t) return;
  sdvScriviRiga(SDV_SLOT_DOVE, 'Dove vale la Modalità severa', { dove: sdvDove(), t: t });
}
/** Il telefono pubblica il suo stato (chiamata da severe.js e blocco.js dopo ogni lettura del motore). */
function sdvPubblicaStato(st){
  if (sdvSuPc() || !st) return;
  const s = { level: +st.level || 0, until: +st.strictUntil || 0, edit: !!st.inAppEditLocked };
  /* il giorno nella firma: almeno una volta al giorno si riscrive, cosi' il computer sa che il
     telefono c'e' ancora (una sessione senza scadenza non chiude il computer per sempre) */
  const firma = JSON.stringify(s) + new Date().toISOString().slice(0, 10);
  if (firma === SDV_PUB_FIRMA) return;
  SDV_PUB_FIRMA = firma;
  s.at = Date.now();
  sdvScriviRiga(SDV_SLOT_STATO, 'Modalità severa del telefono', s);
}

/** All'avvio di una sessione con un computer collegato, il valore di serie diventa una scelta. */
function sdvSegnaAllAvvio(){
  if (sdvSuPc() || !sdvPcCollegato() || sdvScelta()) return;
  sdvLsSet(SDV_KEY, sdvDove());
  sdvLsSet(SDV_T, String(Date.now()));
  sdvPubblicaDove();
}

/* ---------- la scelta, nella pagina Modalita' severa ---------- */
function sdvSceltaHtml(){
  if (!sdvPcCollegato()) return '';
  /* una sessione gia' accesa prima che la scelta esistesse resta del telefono finche' non si sceglie */
  const inSospeso = !sdvScelta() && !sdvSuPc() && sevBloccaQui();
  const d = inSospeso ? '' : sdvDove();
  const b = function(v, t){ return '<button type="button" class="sdv-b' + (d === v ? ' on' : '') + '" data-sdv="' + v + '" aria-pressed="' + (d === v) + '" onclick="sdvSetDove(\'' + v + '\')">' + t + '</button>'; };
  return '<div class="sdv">'
    + '<p class="sdv-t">La Modalità severa vale:</p>'
    + '<div class="sdv-r">' + b('telefono', 'Solo sul telefono') + b('computer', 'Anche sul computer') + '</div>'
    + (inSospeso ? '<p class="sdv-n">Non hai ancora scelto: per questa sessione la Modalità severa vale solo sul telefono.</p>' : '')
    + '</div>';
}
(function sdvStile(){
  try{
    if (typeof document === 'undefined' || !document.head) return;
    const st = document.createElement('style');
    st.textContent = '.sdv{margin:14px 0 4px;width:100%}'
      + '.sdv-t{margin:0 0 8px;font:700 13px var(--font-body);color:var(--navy)}'
      + '.sdv-r{display:flex;gap:8px}'
      + '.sdv-b{flex:1;min-height:42px;border:1.5px solid var(--line);border-radius:12px;background:#fff;color:var(--navy);font:700 13px var(--font-body);cursor:pointer;padding:8px}'
      + '.sdv-b.on{border-color:#0075E3;background:var(--blue-soft);color:#0075E3}'
      + '.sdv-n{margin:8px 0 0;font:500 12px/1.5 var(--font-body);color:var(--muted)}'
      + 'body.dark .sdv-t{color:#fff}body.dark .sdv-b{background:#1C2E5A;color:#BCE0FF;border-color:rgba(188,224,255,.24)}body.dark .sdv-b.on{border-color:#8CC6FF;color:#fff}';
    document.head.appendChild(st);
  }catch(_){ }
})();
