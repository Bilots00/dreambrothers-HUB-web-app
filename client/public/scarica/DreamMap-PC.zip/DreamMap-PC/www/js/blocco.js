/* blocco.js - corsia U-A · BLOCCO E PROGRAMMI.
 *
 * Everything that decides what gets blocked and when: the engine status banner, the Quick
 * Block (its own screen, its own lists, its own on/off), the programs with real schedules
 * (hours, weekdays, "all day", usage quotas), the nine ready-made templates, the
 * blocklist/allowlist selector and the four "Opzioni extra" flags.
 *
 * WHY THIS FILE OWNS SO MUCH STATE
 * The old version kept programs in localStorage and sent the engine the flat UNION of every
 * program's apps and keywords. That made an 08:00-16:00 program and a permanent one produce
 * exactly the same rules: the schedule existed only on screen. The engine now has Schedule,
 * so a program is sent whole - hours, days, quotas - and the union is gone. localStorage is
 * still written, but only as a mirror for the browser preview: the engine is the truth.
 *
 * SCREENS ARE REGISTERED HERE, NOT IN index.html: six lanes edit that file at once, so each
 * area adds its own markup at load time through registry.js.
 *
 * LOAD ORDER: this file runs before nav.js, so nothing here may call toast()/goId()/esc() at
 * load time - only inside handlers, which run later. That is why blkEsc() exists.
 */

/* ================= 0 · HELPERS THAT MUST WORK AT LOAD TIME ================= */

/* nav.js (which owns esc) is loaded last on purpose. The markup below is built while this
   file loads, so it needs an escaper of its own. */
/* ---------------------------------------------------------------------------------------
   La favicon di un sito, chiesta AL SITO STESSO.

   Nessun servizio di terze parti (Google, DuckDuckGo): quelli vedrebbero l'elenco dei siti
   che una persona sta bloccando, che è esattamente la cosa che questa app non fa uscire dal
   telefono. Si chiede https://dominio/favicon.ico e basta; se non c'è, resta l'iniziale.
   --------------------------------------------------------------------------------------- */
function flFavHost(v){
  const h = String(v == null ? '' : v).trim().toLowerCase()
    .replace(/^https?:\/\//, '').split(/[\/?#]/)[0];
  return (h && h.indexOf('.') > 0 && !/\s/.test(h)) ? h : '';
}
/* 0.9.403 BUG-304, Andrea: "nel tempo di navigazione molti siti (dreambrothers.it) non hanno la favicon, che c'e' in Chrome e in Stay
   Focused. Piu' fonti, in ordine: la cache, l'icona dichiarata dal sito, /favicon.ico, un servizio di favicon, con cache. Vale per il
   pannello di panoramica, per le revisioni e per ogni posto dove compare". Chiesto da Andrea: da qui, se il sito non risponde, l'ultima
   fonte e' il servizio di Google (solo il dominio). La fonte che funziona si ricorda (fl_fav_cache); un sito senza nessuna icona si
   riprova dopo tre giorni. L'icona dichiarata (<link rel="icon"> o apple-touch-icon) si legge dalla pagina del sito con la richiesta
   nativa (CapacitorHttp, che non ha il limite CORS della WebView); nel browser di prova quel passo si salta */
const FL_FAV = { cache: null, dich: {} };
const FL_FAV_K = 'fl_fav_cache';
function flFavCache(){
  if (!FL_FAV.cache){ try{ const c = JSON.parse(localStorage.getItem(FL_FAV_K) || '{}'); FL_FAV.cache = (c && typeof c === 'object') ? c : {}; }catch(_){ FL_FAV.cache = {}; } }
  return FL_FAV.cache;
}
function flFavSalva(host, u){
  const c = flFavCache(); c[host] = { u: u || '', t: Date.now() };
  const k = Object.keys(c); if (k.length > 500) k.sort(function(a, b){ return (c[a].t || 0) - (c[b].t || 0); }).slice(0, k.length - 500).forEach(function(x){ delete c[x]; });
  try{ localStorage.setItem(FL_FAV_K, JSON.stringify(c)); }catch(_){ }
}
/** L'icona ricordata di un sito: un indirizzo, 'none' (nessuna icona, riprova fra tre giorni) o '' (da cercare) */
function flFavRicordata(host){
  const x = flFavCache()[host]; if (!x) return '';
  if (!x.u) return (Date.now() - (x.t || 0) < 3 * 864e5) ? 'none' : '';
  return x.u;
}
function flFavBase(h){ const p = h.replace(/^www\./, '').split('.'); if (p.length <= 2) return p.join('.'); const due = p.slice(-2).join('.'); return /^(co|com|org|net|gov|ac)\.[a-z]{2}$/.test(due) ? p.slice(-3).join('.') : due; }
function flFavFonti(host){
  const base = flFavBase(host), l = ['https://' + host + '/favicon.ico'];
  if (host.indexOf('www.') !== 0) l.push('https://www.' + host + '/favicon.ico');
  if (base !== host && base !== host.replace(/^www\./, '')) l.push('https://' + base + '/favicon.ico');
  l.push('https://www.google.com/s2/favicons?domain=' + encodeURIComponent(base) + '&sz=64');
  return l.filter(function(u, i){ return l.indexOf(u) === i; });
}
/** L'icona dichiarata dalla pagina del sito (la piu' grande fra icon e apple-touch-icon), o '' */
function flFavDichiarata(host){
  if (FL_FAV.dich[host]) return FL_FAV.dich[host];
  const H = (typeof window !== 'undefined' && window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp) || null;
  if (!H || !H.get || typeof NATIVE === 'undefined' || !NATIVE) return (FL_FAV.dich[host] = Promise.resolve(''));
  return (FL_FAV.dich[host] = H.get({ url: 'https://' + host + '/', connectTimeout: 6000, readTimeout: 6000, responseType: 'text' }).then(function(r){
    const html = String((r && r.data) || '').slice(0, 200000), da = (r && r.url) || ('https://' + host + '/');
    let best = '', bestN = -1;
    (html.match(/<link\b[^>]*>/gi) || []).forEach(function(t){
      const rel = (/\brel\s*=\s*["']?([^"'>]+)/i.exec(t) || [])[1] || '';
      if (!/(^|\s)(icon|apple-touch-icon(-precomposed)?)(\s|$)/i.test(rel)) return;
      const href = (/\bhref\s*=\s*["']?([^"'\s>]+)/i.exec(t) || [])[1]; if (!href || /^data:/i.test(href)) return;
      const sz = +(((/\bsizes\s*=\s*["']?(\d+)/i.exec(t) || [])[1]) || (/apple-touch/i.test(rel) ? 180 : 32));
      if (sz > bestN){ bestN = sz; try{ best = new URL(href, da).href; }catch(_){ } }
    });
    return best;
  }).catch(function(){ return ''; }));
}
function flFavOk(img){
  /* il globo che Google manda per un sito che non conosce e' di 16px: meglio l'iniziale */
  if (/google\.com\/s2\/favicons/.test(img.src) && img.naturalWidth && img.naturalWidth < 32){ flFavErr(img); return; }
  img.classList.add('on');
  const h = img.dataset.host; if (h && flFavRicordata(h) !== img.src) flFavSalva(h, img.src);
}
function flFavErr(img){
  const h = img.dataset.host; if (!h){ img.remove(); return; }
  const prova = function(){
    const tent = (img.dataset.tent || '').split('|');
    const l = [img.dataset.dich || ''].concat(flFavFonti(h)).filter(function(u){ return u && tent.indexOf(u) < 0; });
    if (!l.length){ flFavSalva(h, ''); img.remove(); return; }
    img.dataset.tent = tent.concat([l[0]]).join('|');
    img.src = l[0];
  };
  if (img.dataset.chiesta){ prova(); return; }
  img.dataset.chiesta = '1';
  flFavDichiarata(h).then(function(u){ if (u) img.dataset.dich = u; prova(); });
}
function flFavHtml(v, cls){
  const host = flFavHost(v);
  const letter = (String(v == null ? '?' : v).replace(/^www\./, '').charAt(0) || '?').toUpperCase();
  const base = '<span class="fav' + (cls ? ' ' + cls : '') + '">' + blkEsc(letter);
  if (!host) return base + '</span>';
  const ric = flFavRicordata(host);
  if (ric === 'none') return base + '</span>';
  const primo = ric || ('https://' + host + '/favicon.ico');
  return base + '<img alt="" loading="lazy" src="' + blkEsc(primo) + '" data-host="' + blkEsc(host) + '" data-tent="' + blkEsc(primo) + '"'
    + (ric ? ' data-ric="1"' : '') + ' onload="flFavOk(this)" onerror="if(this.dataset.ric){delete this.dataset.ric;this.dataset.tent=\'\'}flFavErr(this)"></span>';
}
(function favStyle(){
  const st = document.createElement('style');
  st.textContent = '.fav{position:relative;display:inline-flex;align-items:center;justify-content:center;'
    + 'width:22px;height:22px;flex:none;border-radius:6px;background:var(--blue-soft);color:var(--blue);'
    + 'font:800 11px var(--font-body);overflow:hidden}'
    + '.fav img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:contain;background:#fff;opacity:0;transition:opacity .2s}'
    + '.fav img.on{opacity:1}'
    + '.fav.big{width:34px;height:34px;border-radius:9px;font-size:15px}'
    + '.blk-chip .fav{width:15px;height:15px;border-radius:4px;font-size:8px;margin-right:5px}'
    + 'body.dark .fav{background:#12203A;color:#9EC1FF}';
  document.head.appendChild(st);
})();

function blkEsc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}

/* Every call to the plugin goes through here. Two failure modes have to stay distinct:
   NATIVE missing (browser preview - the feature degrades, no error is shown) and a method
   that rejects (Modalita severa refusing a change, bad arguments - the user must read the
   engine's own message, which is already in Italian, not a generic "non riuscito"). */
async function blkNative(method, args, silent){
  if(!NATIVE || typeof NATIVE[method] !== 'function') return null;
  /* 0.9.395, Andrea: "va bene che ci sia, purché non sia disattivabile". Sul computer il ponte verso il programma non
     controlla niente: con la Modalita' severa accesa la scrittura che allenta si rifiuta qui (severa-dove.js) */
  if(typeof sevRifiutaScrittura === 'function'){
    const no = sevRifiutaScrittura(method, args || {});
    if(no){ if(!silent && typeof toast === 'function') toast(no); return null; }
  }
  try{
    const r = await NATIVE[method](args || {});
    if(method === 'getRulesFull' && typeof sdvRicordaRegole === 'function') sdvRicordaRegole(r);
    return r;
  }catch(e){
    const msg = (e && (e.message || e.errorMessage)) || 'Operazione non riuscita';
    /* 0.9.302: il contratto di abitudine protegge la regola: si offre l'attesa invece di un messaggio e basta */
    if(e && e.code === 'contract-wait' && !silent && typeof ctrRifiuto === 'function'){ ctrRifiuto(e); return null; }
    if(!silent && typeof toast === 'function') toast(msg);
    console.warn('[blocco] ' + method + ' rifiutato', e && e.code, msg);
    return null;
  }
}
function blkHasNative(method){ return !!(NATIVE && typeof NATIVE[method] === 'function'); }

/* ================= 1 · STILE (prefisso blk-, niente collisioni) ================= */
(function blkStyle(){
  const css = `
  .blk-title{font:800 17px var(--font-display);font-style:italic;color:var(--navy)}
  #s-newtype .topbar{position:relative}#s-newtype .nt-snd-tit{position:absolute;left:52px;right:52px;margin:0 !important;text-align:center}#s-newtype.snd-mode > h2{display:none}body.dark .nt-snd-tit{color:#fff}
  .blk-right{margin-left:auto}
  .blk-gear{margin-left:10px;border:0;background:none;font-size:17px;cursor:pointer;color:var(--muted);line-height:1}
  .blk-quicklink{width:100%;margin:0 0 10px;border:1px dashed var(--line);background:#fff;border-radius:12px;
    padding:11px;font:700 12px var(--font-body);color:var(--blue);cursor:pointer;text-align:left}
  .blk-quicklink .chev{float:right;color:var(--faint)}

  .blk-moderow{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:14px;margin-bottom:10px;cursor:pointer}
  .blk-modetxt b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}
  .blk-modetxt small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:2px}
  .blk-chevbtn{margin-left:auto;flex:none;width:30px;height:30px;border-radius:50%;background:var(--blue-soft);
    color:var(--blue);display:grid;place-items:center;font:800 13px var(--font-body)}
  .blk-chevbtn svg{display:block;color:#0075E3}
  body.dark .blk-chevbtn svg{color:#8CC6FF}
  .emo-grid.emo-6{grid-template-columns:repeat(6,1fr);gap:8px}
  .emo-grid .emo-dopo{display:none}.emo-grid.tutte .emo-dopo{display:block}
  .emo-grid button.scelta{box-shadow:0 0 0 2.5px #0075E3;background:var(--blue-soft)}
  .emo-altro{display:block;margin:0 auto 14px;border:0;background:none;color:var(--blue);font:700 14px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}
  .emo-altro[hidden]{display:none}
  .blk-trow-tap{cursor:pointer}.blk-trow-tap .chev{margin-left:auto}
  .blk-sheet{position:relative}
  .blk-x{position:absolute;top:14px;right:14px;width:36px;height:36px;border:0;border-radius:50%;background:var(--bg);color:var(--navy);display:grid;place-items:center;cursor:pointer;z-index:2}
  body.dark .blk-x{background:rgba(255,255,255,.1);color:#fff}

  .blk-chips{display:flex;flex-wrap:wrap;gap:6px;margin:-4px 0 10px;padding:0 2px}
  /* IL COLORE DEL TEMA, QUI, non in un correttivo a parte: #fff fisso con il testo in
     --navy era bianco su bianco di notte, e lo e' rimasto cinque volte perche' il rimedio
     stava in un altro foglio. La carta e' --card, il bordo --line: seguono il tema da soli. */
  .blk-chip{display:inline-flex;align-items:center;gap:5px;font:600 10.5px var(--font-body);color:var(--navy);
    background:var(--card,#fff);border:1px solid var(--line);border-radius:99px;padding:4px 10px;max-width:100%}
  body.dark .blk-chip{background:#141C2C;color:#E8F1FF;border-color:#25314A}
  .blk-chip i{font-style:normal;color:var(--blue)}
  .blk-chip.more{color:var(--muted);background:var(--line)}
  body.dark .blk-chip.more{background:#1B2540;color:#9FB6CF}

  .blk-opt{display:flex;align-items:flex-start;gap:11px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:13px;margin-bottom:8px}
  .blk-opt .oi{width:30px;height:30px;flex:none;border-radius:9px;background:var(--blue-soft);color:var(--blue);
    display:grid;place-items:center;font:800 11px var(--font-body)}
  .blk-opt .ot{flex:1}
  .blk-opt b{display:block;font:700 13px var(--font-body);color:var(--navy)}
  .blk-opt small{display:block;font:500 11px/1.5 var(--font-body);color:var(--muted);margin-top:3px}
  .blk-opt .switch{margin-top:3px}

  .blk-daysbox{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px;margin-top:10px}
  .blk-days{display:flex;gap:6px;justify-content:space-between}
  .blk-day{flex:1;height:36px;border-radius:10px;border:1.5px solid var(--line);background:#fff;
    font:700 12px var(--font-body);color:var(--muted);cursor:pointer;transition:all .15s}
  .blk-day.on{background:var(--blue);border-color:var(--blue);color:#fff}
  .blk-presets{display:flex;gap:6px;margin-top:10px}
  .blk-preset{flex:1;border:1px solid var(--line);background:var(--bg);border-radius:99px;padding:6px 4px;
    font:700 10.5px var(--font-body);color:var(--navy);cursor:pointer}
  .blk-swrow{display:flex;align-items:center;gap:10px;margin-top:12px;font:700 13px var(--font-body);color:var(--navy)}
  .blk-swrow small{display:block;font:500 11px var(--font-body);color:var(--muted);margin-top:2px}
  .blk-swrow .switch{margin-left:auto}

  /* One long line, ellipsised: a schedule plus two counters wraps and pushes the pill out of
     the row on a 360px screen. */
  .blk-prog small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .blk-prog>div{min-width:0}
  .blk-soon > span,.blk-soon > b,.blk-soon > small{opacity:.55}
  .blk-soon small{color:var(--faint);font:800 9.5px var(--font-body);letter-spacing:.5px}
  .blk-soon .fl-tip-i{margin-left:0;opacity:.8}
  .blk-opensbox{margin-top:18px}

  .blk-tplhead{display:flex;align-items:center;gap:10px;margin:30px 0 8px;cursor:pointer}
  .blk-tplhead b{font:800 20px var(--font-display);color:var(--navy)}
  .blk-tplhead small{display:block;font:500 11px/1.5 var(--font-body);color:var(--muted);margin-top:2px}
  .blk-tplchev{margin-left:auto;color:var(--muted);transition:transform .2s}
  .blk-tplchev.closed{transform:rotate(180deg)}
  .blk-quote{}
  .blk-tplwrap{margin-bottom:6px}
  .blk-tplwrap[hidden]{display:none}
  .blk-inhead{cursor:default;margin-top:34px}
  /* Tutto al centro, come l'intestazione che ha sopra: un pannello in cui il badge sta a
     sinistra e il titolo pure e' una colonna di roba allineata a caso. */
  .blk-doom{background:linear-gradient(160deg,#12203A,#1E3A6B);border-radius:20px;padding:22px 18px;margin:0 0 4px;color:#fff;cursor:pointer;text-align:center}
  .blk-doom-badge{display:inline-block;background:rgba(255,255,255,.16);color:#fff;font:800 9.5px var(--font-body);letter-spacing:.8px;padding:6px 11px;border-radius:8px}
  .blk-doom b{display:block;font:800 18px/1.2 var(--font-display);margin:16px 0 8px;color:#fff}
  .blk-doom p{font:500 12.5px/1.55 var(--font-body);color:#C8DAF2;margin:0 auto 20px;max-width:24em}
  .blk-doom .cta{width:100%;background:#0075E3;display:inline-flex;align-items:center;justify-content:center;gap:9px}
  .blk-inintro{padding:44px 0 14px}
  .blk-inintro h2{text-transform:none}
  /* Same stack as a program card: icon on top, everything centred. A template is a
     program the user has not made yet, and it should look like one. */
  .blk-tpl{position:relative;background:#fff;border:1px solid var(--line);border-radius:18px;
    padding:22px 18px 18px;margin-top:10px;text-align:center;box-shadow:0 2px 10px rgba(0,30,68,.05)}
  .blk-trend{position:relative;background:linear-gradient(160deg,#001E44,#0E2350 60%,#005BB0);border-radius:22px;padding:16px 16px 14px;margin-bottom:8px;color:#fff}
  .blk-trend-badge{display:inline-block;background:#E63946;color:#fff;font:800 10px var(--font-body);letter-spacing:.6px;padding:5px 10px;border-radius:8px}
  .blk-trend > b{display:block;font:800 19px/1.2 var(--font-display);margin:10px 0 4px;color:#fff}
  .blk-trend > p{font:500 12.5px/1.5 var(--font-body);color:#BCE0FF;margin:0 0 12px}
  .blk-trend-x{position:absolute;top:12px;right:12px;background:none;border:0;color:#fff;font-size:18px;cursor:pointer;padding:4px 8px}
  .blk-trend .blk-tpl{margin-bottom:0;background:#0F2041;border-color:#14234A;color:#fff}
  .blk-trend .blk-tpl b{color:#fff}
  .blk-trend .blk-tpl small{color:#BCE0FF}
  .blk-tpl .tem{display:block;font-size:34px;line-height:1;margin-bottom:10px}
  .blk-tpl b{display:block;font:800 16px var(--font-display);color:var(--navy)}
  .blk-tpl small{display:block;font:500 12px/1.6 var(--font-body);color:var(--muted);margin-top:4px}
  .blk-trg{display:inline-flex;align-items:center;gap:4px;font:700 9px var(--font-body);letter-spacing:.4px;
    text-transform:uppercase;border-radius:99px;padding:3px 8px;margin-bottom:14px}
  .blk-trg.clock{background:var(--blue-soft);color:var(--blue)}
  .blk-trg.hour{background:#FFF3E0;color:#B26A00}
  .blk-trg.geo{background:#EDF1F6;color:var(--faint)}
  .blk-add{position:absolute;top:12px;right:12px;width:28px;height:28px;border-radius:50%;border:0;
    background:var(--blue);color:#fff;font:800 17px var(--font-body);line-height:1;cursor:pointer}
  .blk-add.off{background:var(--bg);color:var(--faint);border:1px solid var(--line);font-size:10px;width:auto;
    padding:0 9px;border-radius:99px;font-weight:800;height:22px}
  .blk-quote{font:italic 500 11.5px/1.55 var(--font-body);color:var(--muted);margin:6px 4px 0;text-align:center}

  .blk-sw{position:absolute;inset:0;z-index:95;pointer-events:none}
  .blk-base{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px;margin:12px 0}
  .blk-base-h{display:flex;align-items:baseline;gap:8px}
  .blk-base-h b{font:700 14px var(--font-display);color:var(--navy)}
  .blk-base-h span{margin-left:auto;font:600 11.5px var(--font-body);color:var(--blue)}
  .blk-base p{font:500 11.5px/1.6 var(--font-body);color:var(--muted);margin:6px 0 10px}
  .blk-sw .blk-scrim{position:absolute;inset:0;background:rgba(0,19,43,.5);opacity:0;transition:opacity .3s}
  .blk-sw .blk-sheet{position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:24px 24px 0 0;
    padding:16px 18px calc(20px + env(safe-area-inset-bottom));transform:translateY(102%);transition:transform .32s;
    max-height:82%;overflow-y:auto}
  .blk-sw.open{pointer-events:auto}
  .blk-sw.open .blk-scrim{opacity:1}
  .blk-sw.open .blk-sheet{transform:none}
  .blk-sw .grab{width:44px;height:5px;border-radius:99px;background:#DCE8F5;margin:0 auto 14px}
  .blk-sw h3{font:800 17px var(--font-display);font-style:italic;color:var(--navy);text-align:center}
  .blk-ssub{font:500 12px/1.6 var(--font-body);color:var(--muted);text-align:center;margin:6px 10px 16px}
  .blk-trow{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:13px;margin-bottom:9px}
  .blk-trow .blk-tico{font-size:18px;width:26px;text-align:center;flex:none}
  .blk-trow b{font:700 13.5px var(--font-body);color:var(--navy)}
  .blk-trow small{display:block;font:500 11px var(--font-body);color:var(--muted)}
  .blk-trow .switch{margin-left:auto}

  .blk-modecard{display:flex;gap:12px;align-items:flex-start;background:#fff;border:2px solid var(--line);
    border-radius:16px;padding:14px;margin-bottom:10px;cursor:pointer}
  .blk-modecard.sel{border-color:var(--blue);background:var(--blue-soft)}
  .blk-modecard .mi{font-size:22px;flex:none}
  .blk-modecard b{display:block;font:800 14px var(--font-display);color:var(--navy)}
  .blk-modecard small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:3px}

  .blk-qlmode{display:flex;align-items:center;gap:8px;width:100%;margin:8px 0 0;padding:12px;background:#fff;
    border:1px solid var(--line);border-radius:12px;font:600 12px var(--font-body);color:var(--muted);cursor:pointer}
  .blk-qlmode b{margin-left:auto;font:700 12px var(--font-body);color:var(--blue)}
  .blk-modepick{display:flex;gap:14px;margin:8px 2px 0;font:600 12px var(--font-body);color:var(--navy)}
  .blk-modepick label{display:flex;align-items:center;gap:6px}
  .blk-modepick input{accent-color:var(--blue)}
  `;
  const tag = document.createElement('style');
  tag.id = 'blk-style';
  tag.textContent = css;
  document.head.appendChild(tag);
})();

/* ================= 2 · STATO ================= */

/* Programs are still mirrored in localStorage so the browser preview has something to draw,
   but the engine's schedules are the authority: loadFromEngine() overwrites this list on a
   real device. */
let PROGRAMS = JSON.parse(localStorage.getItem('fl_programs') || '[]');
let DRAFT = null;                                   // program being created/edited
let QUICK = { enabled:false, apps:[], sites:[], keywords:[] };

/* The flags that live in Rules and apply to the whole engine, not to one program:
   list mode, the four "Opzioni extra" and the Lancia/Notifiche pair. */
let EXTRA = {
  enabled:true, listMode:'blocklist', allowApps:[],
  blockNewlyInstalled:false, blockUnsupportedBrowsers:false, blockAdult:false, blockReinstalled:false,
  blockPurchases:false, searchTyping:false,
  blockLaunch:true, blockNotifications:true
};

let QL_TAB = 'app';            // which tab of the quick-block list screen is open
let QL_APPS = [];              // installed apps, read once per visit
let SET_TARGET = 'quick';      // whose Lancia/Notifiche the bottom sheet is editing
let MODE_TARGET = 'quick';
let TPL_OPEN = localStorage.getItem('fl_tpl_open') !== '0';

const DAY_SHORT = ['L','M','M','G','V','S','D'];
const DAY_LONG  = ['lunedì','martedì','mercoledì','giovedì','venerdì','sabato','domenica'];

/* 0.9.390, Andrea (BUG-123): "il blocco non ha funzionato perche' ha modificato le regole di un programma". Prima di scrivere si annota
   cosa si e' allentato (un'app tolta, un programma spento o cancellato, orari o limiti piu' larghi): lo legge il caso "ci e' ricascato"
   della revisione della sera (ricRegistraAllentati, ricascato.js) */
function saveProgramsLocal(){
  try{ if(typeof ricRegistraAllentati === 'function') ricRegistraAllentati(localStorage.getItem('fl_programs'), PROGRAMS); }catch(_){ }
  localStorage.setItem('fl_programs', JSON.stringify(PROGRAMS));
}

/* The engine is the source of truth for programmes; localStorage is only its cache.

   Until now they were two independent copies. Anything that changed the engine without
   going through this screen - a restore from Drive, a restore from a file, Android putting
   the app back on a new phone - left the engine full and the dashboard empty, and the user
   staring at "no programmes" while the blocks fired. Reading the engine on every start and
   every return to the foreground is what makes a backup restore actually appear. The only
   thing the cache still owns is the icon, which the engine has no field for. */
function scheduleToProgram(sc, iconOf){
  return {
    id: sc.id, name: sc.name || 'Programma', type: sc.type || 'sempre',
    icon: iconOf[sc.id] || (BLK_TYPE_ICON[sc.type] || '🚫'),
    from: sc.from || '00:00', to: sc.to || '00:00',
    days: (Array.isArray(sc.days) && sc.days.length === 7) ? sc.days : [true,true,true,true,true,true,true],
    allDay: !!sc.allDay,
    qh: sc.quotaHourMin || null, qd: sc.quotaDayMin || null,
    /* 0.9.291, Andrea: "il programma duplicato si cambia nei due minuti ma non si elimina". Rileggendo i programmi dal
       motore la tolleranza si perdeva, e la copia risultava gia' chiusa a chiave: ora torna indietro con lui. */
    grazia: +sc.grazia || 0,
    /* 0.9.395: il programma del tuo agente personale e il suo "da confermare" tornano indietro dal motore (come la grazia) */
    daAgente: !!sc.daAgente, daConfermare: !!sc.daConfermare,
    /* 0.9.400 BUG-169: le due scelte del bivio (si cambiano solo con la Modalità severa spenta) */
    bivio: !!sc.bivio, rettifica: !!sc.rettifica,
    rimastoMs: typeof sc.rimastoMs === 'number' ? sc.rimastoMs : null, rimastoAl: +sc.rimastoAl || 0,
    apps: sc.apps || [], sites: sc.sites || [], keywords: sc.keywords || [], allow: sc.allow || [],
    redirectUrl: sc.redirectUrl || '',
    wifi: Array.isArray(sc.wifi) ? sc.wifi : [],
    places: Array.isArray(sc.places) ? sc.places : [],
    useTime: sc.useTime !== false, useWifi: !!sc.useWifi, usePlace: !!sc.usePlace, useLimit: !!sc.useLimit,
    activeNow: !!sc.activeNow,
    blockLaunch: sc.blockLaunch !== false, blockNotifications: sc.blockNotifications !== false,
    on: sc.enabled !== false
  };
}
const BLK_TYPES = [
  { k:'ora',       ico:'🕑', name:'Ora',                        desc:'Attivo solo nei giorni e nella fascia oraria che scegli qui sotto.' },
  { k:'limite',    ico:'⏳', name:'Limite di utilizzo',          desc:'Concede un tot di minuti, poi blocca.' },
  { k:'sempre',    ico:'🚫', name:'Permanente',                  desc:'Sempre attivo, senza orari.' },
  { k:'wifi',      ico:'📶', name:'Wi-Fi',                       desc:'Attivo quando il telefono è connesso a una delle reti Wi-Fi scelte.' },
  { k:'posizione', ico:'📍', name:'Posizione',                   desc:'Attivo quando il telefono si trova in uno dei luoghi scelti.' },
  { k:'combo',     ico:'🧩', name:'Combinazione personalizzata', desc:'Attivo solo quando tutte le condizioni accese qui sotto sono vere insieme.' }
];
const BLK_TYPE_ICON = {}, BLK_TYPE_NAME = {}, BLK_TYPE_DESC = {};
BLK_TYPES.forEach(function(t){ BLK_TYPE_ICON[t.k] = t.ico; BLK_TYPE_NAME[t.k] = t.name; BLK_TYPE_DESC[t.k] = t.desc; });
/* SOLO PER I PROGRAMMI DEI SUONI (0.9.181): il suono parte mentre usi un'app o un sito. Il
   «permanente» e il «limite di utilizzo» li' non hanno senso, e nel foglio non compaiono. */
const BLK_TYPE_APP = { k:'app', ico:'📲', name:'Mentre usi un\u2019app o un sito', desc:'Il suono parte quando apri una delle app o dei siti scelti, e si ferma quando li lasci.' };
BLK_TYPE_ICON.app = BLK_TYPE_APP.ico; BLK_TYPE_NAME.app = BLK_TYPE_APP.name; BLK_TYPE_DESC.app = BLK_TYPE_APP.desc;
/* 0.9.402 BUG-236, Andrea: "condizione nuova Quando fai un'abitudine: le abitudini della scheda Azione; quando succede, parte il suono" */
const BLK_TYPE_HAB = { k:'abitudine', ico:'🔁', name:'Quando fai un\u2019abitudine', desc:'Il suono parte quando DreamMap vede l\u2019abitudine che scegli qui sotto.' };
BLK_TYPE_ICON.abitudine = BLK_TYPE_HAB.ico; BLK_TYPE_NAME.abitudine = BLK_TYPE_HAB.name; BLK_TYPE_DESC.abitudine = BLK_TYPE_HAB.desc;
function blkTipiDisponibili(){
  if (DRAFT && DRAFT.sound) return BLK_TYPES.filter(function(t){ return t.k !== 'sempre' && t.k !== 'limite'; }).concat([BLK_TYPE_APP, BLK_TYPE_HAB]);
  return BLK_TYPES;
}

async function hydrateProgramsFromEngine(){
  if(!blkHasNative('getSchedules')) return false;
  const r = await blkNative('getSchedules', {}, true);
  if(!r || !Array.isArray(r.schedules)) return false;
  const iconOf = {};
  PROGRAMS.forEach(function(p){ if(p && p.id && p.icon) iconOf[p.id] = p.icon; });
  const fresh = r.schedules.map(function(sc){ return scheduleToProgram(sc, iconOf); });
  PROGRAMS.length = 0;
  fresh.forEach(function(p){ PROGRAMS.push(p); });
  saveProgramsLocal();
  return true;
}

// On start and on every return from the background: a restore may have happened meanwhile.
(async function blkHydrateBoot(){
  try{ if(await hydrateProgramsFromEngine() && typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  try{ await blkLoadInstalled(); }catch(_){ }
})();
// The blue ring means "blocking right now", and "now" moves: re-read once a minute while the
// home is on screen, so a programme that started at 20:00 lights up at 20:00.
setInterval(async function(){
  const home = document.getElementById('s-home');
  const tab = document.getElementById('tab-blocco');
  if(!home || !home.classList.contains('active') || !tab || !tab.classList.contains('on')) return;
  try{ if(await hydrateProgramsFromEngine()) renderPrograms(); }catch(_){ }
}, 60000);
document.addEventListener('visibilitychange', async function(){
  if(document.hidden) return;
  try{ if(await hydrateProgramsFromEngine()) renderPrograms(); }catch(_){ }
});

/* A program without an id cannot be matched to the engine's schedule on the next save: the
   engine would grow a duplicate on every push. Old programs get one here, once. */
function blkEnsureIds(){
  let dirty = false;
  PROGRAMS.forEach(function(p){
    if(!p.id){ p.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); dirty = true; }
    if(!Array.isArray(p.days) || p.days.length !== 7){ p.days = [true,true,true,true,true,true,true]; dirty = true; }
  });
  if(dirty) saveProgramsLocal();
}
blkEnsureIds();

/* ================= 3 · SCHERMATE E OVERLAY ================= */

registerScreen('s-quick', `
  <div class="topbar">
    <button class="iconbtn" onclick="closeQuick()">✕</button>
    <b class="blk-title">Blocco rapido</b>
    <button class="iconbtn blk-right" onclick="openBlockSettings('quick')" aria-label="Impostazioni del blocco rapido">${flIngranaggio(22)}</button>
  </div>

  <div class="blk-moderow" onclick="openModeSheet('quick')">
    <div class="blk-modetxt">
      <b id="qkModeName">Lista di blocco</b>
      <small id="qkModeDesc">Seleziona app, siti web e parole chiave che desideri bloccare.</small>
    </div>
    <span class="blk-chevbtn"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></span>
  </div>

  <!-- 0.9.367, Andrea: "siti web senza titolo, parole chiave attaccate a siti web, titoli di dimensioni diverse". Ogni lista ha il suo
       titolo, grande come Opzioni extra, e spazio vero sopra; la riga sotto dice cosa fa -->
  <div class="sect blk-sez"><b>Applicazioni</b></div>
  <div class="setrow" onclick="openQuickList('app')"><span>📱</span><b>Scegli le app</b><small id="qkNApps">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipApps"></div>
  <div class="sect blk-sez"><b>Siti web</b></div>
  <div class="setrow" onclick="openQuickList('web')"><span>🌐</span><b>Scegli i siti</b><small id="qkNSites">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipSites"></div>
  <div class="sect blk-sez"><b>Parole chiave</b></div>
  <div class="setrow" onclick="openQuickList('kw')"><span>🔤</span><b>Scegli le parole</b><small id="qkNKw">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipKw"></div>

  <div class="sect"><b>Opzioni extra</b></div>
  <div class="hintline">Valgono per tutti i tuoi blocchi, non solo per questo.</div>
  <div id="qkExtra"></div>

  <div class="spacer"></div>
  <button class="cta fl-salva" onclick="saveQuick()">Salva</button>
`, { back:'s-home' });

registerScreen('s-qlist', `
  <div class="topbar"><button class="iconbtn" onclick="goId('s-quick')">‹</button><b class="blk-title" id="qlTitle">Lista di blocco</b></div>
  <div class="bltabs">
    <button class="bltab on" data-ql="app" onclick="qlTab('app')">App</button>
    <button class="bltab" data-ql="web" onclick="qlTab('web')">Web</button>
    <button class="bltab" data-ql="kw" onclick="qlTab('kw')">Parole chiave</button>
  </div>

  <div id="ql-app">
    <input class="fin" id="qlSearch" placeholder="Cerca un'app…" oninput="renderQlApps()" autocomplete="off">
    <div id="qlAppList" class="picklist"></div>
  </div>
  <div id="ql-web" hidden>
    <div class="addrow ql-addrow"><input class="fin" id="qlWebIn" placeholder="Aggiungi un sito, es. instagram.com" autocomplete="off" enterkeyhint="done" oninput="qlCtaPaint()" onkeydown="if(event.key==='Enter'){event.preventDefault();qlAdd('web')}"></div>
    <div id="qlWebList" class="picklist"></div>
  </div>
  <div id="ql-kw" hidden>
    <!-- 0.9.366, Andrea: "come su AppBlock: niente +, niente muro di testo, niente riga Tipo di corrispondenza. Mentre scrivi, dentro la
         casella compare Nel dominio con la freccia, che apre il foglio delle scelte; in fondo il pulsante Inserisci" -->
    <div class="addrow ql-addrow"><input class="fin" id="qlKwIn" placeholder="Aggiungi una parola chiave" autocomplete="off" enterkeyhint="done" oninput="qlCtaPaint()" onkeydown="if(event.key==='Enter'){event.preventDefault();qlAdd('kw')}">
      <button type="button" class="ql-kwmode" id="qlKwModeChip" hidden onclick="qlOpenMode(null)"><span id="qlKwModeChipT">Nel dominio</span><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button></div>
    <div class="blk-opt" style="margin-top:10px" hidden><span class="oi">🔎</span>
      <div class="ot"><b>Blocca ricerche e contenuti in tutte le app</b><small>Se scrivi una di queste parole nella barra di ricerca di qualsiasi app, o se compare in un risultato, in un profilo o in un titolo, l'app viene chiusa. Vale per tutti i programmi e per il Blocco rapido.</small></div>
      <button class="switch" id="qlSearchSw" onclick="toggleExtra('searchTyping')"></button></div>
    <!-- Same control as the program editor: three match types, and every row can change its
         own afterwards. Two radio buttons here meant the Quick Block could not reach "nel
         contenuto della pagina" and could never correct a word once added. -->
    <span id="qlKwModeLbl" hidden></span><span id="qlKwModeHint" hidden></span>
    <div id="qlKwList" class="picklist"></div>
  </div>

  <div class="spacer"></div>
  <button class="cta fl-salva" id="qlCta" onclick="goId('s-quick')">Salva</button>
`, { back:'s-quick' });
/* 0.9.366: in fondo "Inserisci" mentre si scrive (come AppBlock), "Salva" quando la casella e' vuota; nella casella delle parole
   compare il tipo di corrispondenza */
function qlCtaPaint(){
  const kwV = ((document.getElementById('qlKwIn') || {}).value || '').trim();
  const webV = ((document.getElementById('qlWebIn') || {}).value || '').trim();
  const kwOn = !(document.getElementById('ql-kw') || {}).hidden, webOn = !(document.getElementById('ql-web') || {}).hidden;
  /* una parola senza punto non e' un dominio: finche' non si sceglie a mano, il tipo si indovina (come nella Lista di blocco dei programmi) */
  try{ if (kwV && typeof UB_MODE_TOUCHED !== 'undefined' && !UB_MODE_TOUCHED && typeof ubLooksLikeDomain === 'function') UB_NEW_MODE = ubLooksLikeDomain(kwV) ? 'domain' : 'url'; }catch(_){ }
  const chip = document.getElementById('qlKwModeChip');
  if (chip){ chip.hidden = !kwV; const t = document.getElementById('qlKwModeChipT'); if (t) t.textContent = qlModeLabel((typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain'); }
  const cta = document.getElementById('qlCta'); if (!cta) return;
  const which = kwOn && kwV ? 'kw' : (webOn && webV ? 'web' : '');
  if (which){ cta.textContent = 'Inserisci'; cta.onclick = function(){ qlAdd(which); }; }
  else { cta.textContent = 'Salva'; cta.onclick = function(){ goId('s-quick'); }; }
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.ql-addrow{position:relative}.ql-addrow .fin{padding-right:128px}.ql-kwmode{position:absolute;right:52px;top:50%;transform:translateY(-50%);display:inline-flex;align-items:center;gap:4px;border:0;background:none;color:var(--muted);font:600 13.5px var(--font-body);cursor:pointer;padding:6px 4px}'
    + '.ql-kwmode[hidden]{display:none}'
    /* 0.9.367, Andrea: "scrivendo una parola chiave, Inserisci compare in fondo alla pagina invece che sopra alla tastiera, come su
       AppBlock: l'utente non lo vede e deve scorrere". Con la tastiera aperta (body.kbd, nav.js) il pulsante in fondo alla lista di
       blocco e al blocco rapido sta appoggiato sopra alla tastiera; la lista sotto si allunga per non finirci dietro */
    + 'body.kbd #qlCta,body.kbd #s-blocklist > .cta{position:fixed;left:18px;right:18px;bottom:calc(var(--kbdfix, 0px) + 12px);z-index:80;width:auto;margin:0;box-shadow:0 6px 18px rgba(0,30,68,.25)}'
    + 'body.kbd #qlKwList,body.kbd #qlWebList,body.kbd #kwList,body.kbd #webList{padding-bottom:90px}';
  document.head.appendChild(st);
})();

/* Bottom sheet "Impostazioni" (G03) - what is blocked for the selected apps. */
(function(){
  const el = registerOverlay('blkSetSheet', `
    <div class="blk-scrim" onclick="closeBlockSettings()"></div>
    <div class="blk-sheet">
      <div class="grab"></div>
      <h3>Impostazioni</h3>
      <p class="blk-ssub">Scegli cosa è bloccato per le tue app selezionate. Devi selezionare almeno un'opzione.</p>
      <div class="blk-trow"><span class="blk-tico">🚷</span><div><b>Blocca l'apertura</b><small>L'app non si apre.</small></div>
        <button class="switch on" id="swLaunch" onclick="toggleBlockSetting('launch')"></button></div>
      <div class="blk-trow"><span class="blk-tico">🔕</span><div><b>Blocca le notifiche</b><small>Le sue notifiche non arrivano.</small></div>
        <button class="switch on" id="swNotif" onclick="toggleBlockSetting('notif')"></button></div>
      <!-- 0.9.366, Andrea: "Mostra il motivo di ogni blocco va nell'ingranaggio del Blocco rapido, non nelle Opzioni extra" -->
      <div class="blk-trow blk-trow-motivo" id="swMotivoRow"><span class="blk-tico">🔍</span><div><b>Mostra il motivo di ogni blocco</b><small>Sulla schermata di blocco una (i) dice quale regola l'ha fatto scattare.</small></div>
        <button class="switch" id="swMotivo" onclick="blkMotivoCambia(this)"></button></div>
      <div class="blk-trow blk-trow-tap" id="swLockRow" hidden onclick="closeBlockSettings();plkApri()"><span class="blk-tico">🛡️</span><div><b>Schermata di blocco</b><small id="edLockTxt">Predefinita</small></div><span class="chev"></span></div>
      <!-- 0.9.400 BUG-169, Andrea: due scelte che si fanno PRIMA della Modalità severa; con la Modalità severa accesa si vedono, ferme, con la (i) che dice perché -->
      <div class="blk-trow blk-trow-scelta" id="swBivioRow"><span class="blk-tico">🔀</span><div><b>Mostra il Bivio su tutte le schermate di blocco</b><small>Ogni schermata di blocco ti lascia scegliere se entrare comunque o restare in rotta, e il punto va alla partita fra vecchio te e nuovo te.</small><small class="blk-scelta-perche" id="swBivioPerche" hidden></small></div>
        <button type="button" class="blk-scelta-i" id="swBivioI" hidden onclick="blkScelteInfo('bivio')" aria-label="Perché non si può cambiare">i</button>
        <button class="switch" id="swBivio" onclick="blkSceltaCambia('bivio')" aria-label="Mostra il Bivio su tutte le schermate di blocco"></button></div>
      <div class="blk-trow blk-trow-scelta" id="swRettRow"><span class="blk-tico">✏️</span><div><b>Permetti la rettifica anche in Modalità severa</b><small id="swRettTxt">Dal bivio puoi cambiare i minuti del limite, al giorno o all’ora, anche con la Modalità severa accesa.</small><small class="blk-scelta-perche" id="swRettPerche" hidden></small></div>
        <button type="button" class="blk-scelta-i" id="swRettI" hidden onclick="blkScelteInfo('rettifica')" aria-label="Perché non si può cambiare">i</button>
        <button class="switch" id="swRett" onclick="blkSceltaCambia('rettifica')" aria-label="Permetti la rettifica anche in Modalità severa"></button></div>
      <button class="cta" style="margin-top:12px" onclick="closeBlockSettings()">Fatto</button>
    </div>
  `);
  if(el) el.className = 'blk-sw';
})();

/* Bottom sheet "Modalità Blocco" (G21/G01) - blocklist vs allowlist, AppBlock's own wording. */
(function(){
  const el = registerOverlay('blkModeSheet', `
    <div class="blk-scrim" onclick="closeModeSheet()"></div>
    <div class="blk-sheet">
      <div class="grab"></div>
      <h3>Modalità Blocco</h3>
      <p class="blk-ssub">Scegli la variante che meglio si adatta alle tue preferenze.</p>
      <div class="blk-modecard" id="mcBlock" onclick="pickListMode('blocklist')">
        <span class="mi">🚫</span>
        <div><b>Lista di blocco</b><small>Seleziona app, siti web e parole chiave che desideri bloccare.</small></div>
      </div>
      <div class="blk-modecard" id="mcAllow" onclick="pickListMode('allowlist')">
        <span class="mi">⭐</span>
        <div><b>Elenco consentiti <span class="tag prem">PRO</span></b><small>Seleziona app che desideri autorizzare. Tutte le altre saranno bloccate.</small></div>
      </div>
      <div class="hintline" style="text-align:center">La modalità vale per tutto il motore, non per un singolo blocco.</div>
      <button class="cta" onclick="closeModeSheet()">Continua</button>
    </div>
  `);
  if(el) el.className = 'blk-sw';
})();

/* ================= 4 · INNESTI NEL MARKUP CONGELATO =================
 * index.html belongs to no lane any more, so the pieces that must live inside screens
 * already written there (the Blocco tab, the program editor) are grafted in from here at
 * load time. Every insertion is guarded: if the host markup ever changes, the graft is
 * skipped instead of throwing and taking the whole module down with it. */
/* 0.9.397: la (i) di "Numero aperture", una frase sola nel fumetto (flTip, dream-storia.js). Il riquadro si disegna all'avvio, prima che
   dream-storia.js sia caricato: il pulsante chiama flTip solo quando lo tocchi */
var BLK_APERTURE_TIP = 'Usa “Minuti al giorno” finché il conteggio delle aperture non è pronto, perché per ora il limite conta i minuti e non quante volte apri l’app.';
function BLK_APERTURE_I(){ return '<button type="button" class="fl-tip-i" aria-label="Spiegazione" onclick="event.stopPropagation();event.preventDefault();if(window.flTip)flTip(this,BLK_APERTURE_TIP)">i</button>'; }
(function blkGraft(){

  /* ---- 4.1 Blocco tab: gear + "scegli cosa bloccare" on the Quick Block card ---- */
  const qb = document.querySelector('#tab-blocco .qb');
  if(qb){
    const head = qb.querySelector('.qbhead');
    if(head) head.insertAdjacentHTML('beforeend',
      '<button class="blk-gear" title="Impostazioni" aria-label="Impostazioni del blocco rapido" onclick="event.stopPropagation();openBlockSettings(\'quick\')">' + flIngranaggio(20) + '</button>');
    const btn = qb.querySelector('.startbtn');
    if(btn) btn.insertAdjacentHTML('beforebegin',
      '<button class="blk-quicklink" onclick="openQuick()">Scegli cosa bloccare<span class="chev"></span></button>');
  }

  /* La freccia del pulsante rosso "vesti la tua visione" nello slideshow del sito
   (snippets/icon.liquid, arrow-right-short). Un pulsante che porta da qualche parte lo dice
   con una freccia; scriverlo e basta lo fa sembrare un interruttore. */
const BLK_ARROW = '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" aria-hidden="true">'
  + '<path d="M4 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
  + '<path d="M12 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

/* ---- 4.2 Blocco tab: the nine templates replace the three hardcoded cards ---- */
  const tab = document.getElementById('tab-blocco');
  if(tab){
    let sect = null;
    tab.querySelectorAll('.sect').forEach(function(s){
      if(s.textContent.indexOf('Modelli') >= 0) sect = s;
    });
    const olds = tab.querySelectorAll('.prog[onclick^="useTemplate"]');
    const anchor = sect || (olds.length ? olds[0] : null);
    if(anchor){
      anchor.insertAdjacentHTML('beforebegin', `
        <div class="blk-tplhead" onclick="toggleTemplates()">
          <div><b>Modelli</b><small>Hai bisogno di idee? Dai un'occhiata a cosa piace agli utenti.</small></div>
          <span class="blk-tplchev" id="tplChev"></span>
        </div>
        <div class="blk-tplwrap" id="tplWrap"></div>
        <div class="sev-intro blk-inintro">
          <div class="sev-intro-ic">💀</div>
          <h2>Doom-scrolling apps</h2>
          <p>L'ora che perdi sta tutta nei Reels e negli Shorts. Il resto dell'app puoi tenerlo.</p>
        </div>
        <div class="blk-doom" onclick="inappOpen()">
          <span class="blk-doom-badge">🛡️ BLOCCO IN-APP</span>
          <b>Spegni la parte, non l'app</b>
          <p>Chiudi Reels, Shorts e le storie. Il resto dell'app resta com'era.</p>
          <button class="cta" type="button" onclick="event.stopPropagation();inappOpen()">Configura${BLK_ARROW}</button>
        </div>`);
      if(sect) sect.remove();
      olds.forEach(function(n){ n.remove(); });
    }
  }

  /* ---- 4.3 Program editor: days, "Tutto il giorno", openings, mode, extra options ---- */
  /* 0.9.397, Andrea: "Numero aperture e' attaccato al riquadro dei giorni, e sotto ci sono quattro righe di spiegazione". Il riquadro
     ha il suo spazio sopra (.blk-opensbox) e la spiegazione sta nella (i) accanto al titolo, come le altre (i) dell'app (flTip) */
  const quota = document.getElementById('edQuotaBox');
  if(quota) quota.insertAdjacentHTML('afterend', `
    <div class="blk-daysbox" id="edDaysBox">
      <div class="blk-days" id="edDays"></div>
      <div class="blk-presets">
        <button class="blk-preset" onclick="edDaysPreset('ogni')">Ogni giorno</button>
        <button class="blk-preset" onclick="edDaysPreset('feriali')">Giorni feriali</button>
        <button class="blk-preset" onclick="edDaysPreset('weekend')">Fine settimana</button>
      </div>
      <div class="blk-swrow" id="edAllDayRow">
        <div><b>Attiva tutto il giorno</b><small>Attivo per l'intera giornata, senza fascia oraria.</small></div>
        <button class="switch" id="edAllDay" onclick="edToggleAllDay()"></button>
      </div>
    </div>
    <div id="edOpensBox" class="blk-opensbox" hidden>
      <div class="setrow blk-soon"><span>🔢</span><b>Numero aperture</b>${BLK_APERTURE_I()}<small>PROSSIMAMENTE</small></div>
    </div>`);

  const ed = document.getElementById('s-editor');
  const spacer = ed ? ed.querySelector('.spacer') : null;
  const titBlocco = document.getElementById('edBloccoSect');
  try{ const g = document.getElementById('edIngr'); if (g) g.innerHTML = flIngranaggio(22); }catch(_){ }
  if(titBlocco) titBlocco.insertAdjacentHTML('afterend', `
    <div class="blk-moderow" onclick="openModeSheet('draft')">
      <div class="blk-modetxt"><b id="edModeName">Lista di blocco</b><small id="edModeDesc">Seleziona app, siti web e parole chiave che desideri bloccare.</small></div>
      <span class="blk-chevbtn"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></span>
    </div>`);
  /* 0.9.402 BUG-236: le Opzioni extra stanno in un riquadro loro (edExtraBox), cosi' un programma di suoni le nasconde per nome */
  if(spacer) spacer.insertAdjacentHTML('beforebegin', `
    <div id="edExtraBox">
    <small id="edWhatLbl" hidden>Avvio · Notifiche</small>
    <div class="sect"><b>Opzioni extra</b></div>
    <div class="hintline">Valgono per tutti i tuoi blocchi, non solo per questo.</div>
    <div id="edExtra"></div>
    </div>`);

  /* The chips under the editor's three list rows (G04) are grafted by blocklist.js, which owns
     that screen's lists: adding a second strip here would draw every item twice. Chips in the
     Quick Block screen below are ours because that screen is ours. */
})();

/* ================= 5 · I NOVE MODELLI (G09) =================
 * Names, schedules and quoted lines come from AppBlock's own screens (gap analysis §1.1.5).
 * "Ritorno a scuola" is the one card whose line was never captured, so its line is ours and
 * is marked as such in the handover rather than passed off as AppBlock's.
 * "A casa" is a location trigger: geofencing is deferred to 1.1, so the card says so instead
 * of creating a program that would never fire. */
const DISTRACTIONS = ['instagram.com','tiktok.com','facebook.com','x.com','youtube.com','reddit.com','snapchat.com'];

const TEMPLATES = {
  scuola:   {name:'Ritorno a scuola', em:'🎒', trig:'clock', when:'Giorni feriali, 08:00 – 16:00',
             quote:'Torna in classe con la testa sgombra.', mine:true,
             type:'ora', from:'08:00', to:'16:00', days:'feriali', feat:true},
  focus:    {name:'Focus', em:'🎯', trig:'clock', when:'Giorni feriali, 08:00 – 17:00',
             quote:'Rendi più efficaci le tue sessioni di studio o lavoro.',
             type:'ora', from:'08:00', to:'17:00', days:'feriali'},
  limite:   {name:'Limite app', em:'⏳', trig:'hour', when:'Ogni giorno, 30m',
             quote:'Liberati dallo scrolling infinito.',
             type:'limite', qd:30, days:'ogni'},
  tempo:    {name:'Tempo per me', em:'🫖', trig:'clock', when:'Giorni feriali, 17:00 – 18:00',
             quote:'Trai il massimo dai tuoi momenti preziosi.',
             type:'ora', from:'17:00', to:'18:00', days:'feriali'},
  casa:     {name:'A casa', em:'🏠', trig:'geo', when:'Ogni giorno, Posizione',
             quote:'Blocca le distrazioni in luoghi specifici.', soon:true},
  studio:   {name:'Ora dello studio', em:'📖', trig:'clock', when:'Giorni feriali, 16:00 – 21:00',
             quote:'Studia in tutta tranquillità.',
             type:'ora', from:'16:00', to:'21:00', days:'feriali'},
  detox:    {name:'Detox digitale', em:'🌿', trig:'clock', when:'Domenica, Tutto il giorno',
             quote:'Regalati un giorno senza telefono.',
             type:'ora', allDay:true, days:'domenica'},
  serata:   {name:'Serata', em:'🌙', trig:'clock', when:'Ogni giorno, 20:00 – 23:59',
             quote:'Per avere più facilmente dei sogni d\'oro.',
             type:'ora', from:'20:00', to:'23:59', days:'ogni'},
  mattinata:{name:'Mattinata mindful', em:'🌅', trig:'clock', when:'Giorni feriali, 06:00 – 09:00',
             quote:'Goditi la tua routine mattutina senza interruzioni.',
             type:'ora', from:'06:00', to:'09:00', days:'feriali'}
};
const TPL_ORDER = ['scuola','focus','limite','tempo','casa','studio','detox','serata','mattinata'];
const TRIG_LABEL = { clock:'🕐 Orario', hour:'⏳ Limite di utilizzo', geo:'📍 Posizione' };

function renderTemplates(){
  const wrap = document.getElementById('tplWrap');
  const chev = document.getElementById('tplChev');
  if(!wrap) return;
  wrap.hidden = !TPL_OPEN;
  if(chev) chev.className = 'blk-tplchev' + (TPL_OPEN ? ' closed' : '');
  let trendClosed = false; try{ trendClosed = localStorage.getItem('fl_trend_closed') === '1'; }catch(_){ }
  wrap.innerHTML = TPL_ORDER.map(function(k){
    const t = TEMPLATES[k];
    const btn = t.soon
      ? '<button class="blk-add off" onclick="templateSoon()">PRESTO</button>'
      : '<button class="blk-add" onclick="useTemplate(\'' + k + '\')">+</button>';
    const card = '<div class="blk-tpl">' + btn +
             '<span class="blk-trg ' + t.trig + '">' + TRIG_LABEL[t.trig] + '</span>' +
             '<span class="tem">' + t.em + '</span>' +
             '<b>' + blkEsc(t.name) + '</b><small>' + blkEsc(t.when) + '</small>' +
           '</div>';
    // AppBlock's "TENDENZA" panel around the template of the moment: a navy card with its
    // own headline, dismissable. A blue ring here meant "active", which a template never is.
    if(t.feat && !trendClosed){
      return '<div class="blk-trend">' +
        '<button class="blk-trend-x" onclick="blkTrendClose()" aria-label="Chiudi">✕</button>' +
        '<span class="blk-trend-badge">📈 TENDENZA</span>' +
        '<b>' + blkEsc(t.trendTitle || 'Modalità Studio. Attivata') + '</b>' +
        '<p>' + blkEsc(t.trendSub || 'Inizia l\'anno scolastico senza distrazioni. Blocca tutte le app che ti distraggono.') + '</p>' +
        card + '</div>' +
        '<div class="blk-quote">"' + blkEsc(t.quote) + '"</div>';
    }
    return card + '<div class="blk-quote">"' + blkEsc(t.quote) + '"</div>';
  }).join('');
}
function blkTrendClose(){
  try{ localStorage.setItem('fl_trend_closed', '1'); }catch(_){ }
  renderTemplates();
}
function toggleTemplates(){
  TPL_OPEN = !TPL_OPEN;
  localStorage.setItem('fl_tpl_open', TPL_OPEN ? '1' : '0');
  renderTemplates();
}
function templateSoon(){
  toast('Trigger Posizione: arriva nella 1.1');
}

/* A template opens the editor already filled in - it is a starting point, not a program
   created behind the user's back. */
function useTemplate(kind){
  const t = TEMPLATES[kind];
  if(!t || t.soon){ templateSoon(); return; }
  DRAFT = {
    id:null, name:t.name, type:t.type, icon:t.em,
    from:t.from || '22:00', to:t.to || '08:00',
    qh:null, qd:t.qd || null,
    days:daysFromPreset(t.days), allDay:!!t.allDay,
    apps:[], sites:DISTRACTIONS.slice(), keywords:[], allow:[],
    blockLaunch:true, blockNotifications:true, on:true, idx:-1,
    bivio:true, rettifica:false
  };
  openEditor();
}

/* ================= 6 · GIORNI, ORARI, DESCRIZIONI ================= */

function daysFromPreset(p){
  if(p === 'feriali')  return [true,true,true,true,true,false,false];
  if(p === 'weekend')  return [false,false,false,false,false,true,true];
  if(p === 'domenica') return [false,false,false,false,false,false,true];
  return [true,true,true,true,true,true,true];
}
function daysLabel(days){
  if(!Array.isArray(days) || days.length !== 7) return 'Ogni giorno';
  const on = days.filter(Boolean).length;
  if(on === 0) return 'Nessun giorno';
  if(on === 7) return 'Ogni giorno';
  const week = days[0] && days[1] && days[2] && days[3] && days[4] && !days[5] && !days[6];
  if(week) return 'Giorni feriali';
  if(!days[0] && !days[1] && !days[2] && !days[3] && !days[4] && days[5] && days[6]) return 'Fine settimana';
  if(on === 1) return DAY_LONG[days.indexOf(true)].charAt(0).toUpperCase() + DAY_LONG[days.indexOf(true)].slice(1);
  return days.map(function(d,i){ return d ? DAY_SHORT[i] : null; }).filter(Boolean).join(' ');
}
function renderEdDays(){
  const box = document.getElementById('edDays');
  if(!box || !DRAFT) return;
  box.innerHTML = DAY_SHORT.map(function(l,i){
    return '<button class="blk-day' + (DRAFT.days[i] ? ' on' : '') + '" onclick="edDay(' + i + ')">' + l + '</button>';
  }).join('');
}
/* This used to be a bare classList.toggle: the button lit up and nothing was ever stored
   (G13). It now writes into the DRAFT, which is what reaches the engine. */
function edDay(i){
  if(!DRAFT) return;
  DRAFT.days[i] = !DRAFT.days[i];
  if(!DRAFT.days.some(Boolean)){
    // Zero days would mean "never blocks" while looking armed - the worst possible failure.
    DRAFT.days[i] = true;
    toast('Serve almeno un giorno');
  }
  renderEdDays();
}
function edDaysPreset(p){
  if(!DRAFT) return;
  DRAFT.days = daysFromPreset(p);
  renderEdDays();
}
function edToggleAllDay(){
  if(!DRAFT) return;
  DRAFT.allDay = !DRAFT.allDay;
  paintEditorSchedule();
}
function paintEditorSchedule(){
  if(!DRAFT) return;
  const t = DRAFT.type, combo = t === 'combo';
  const timeOn = t === 'ora' || (combo && DRAFT.useTime);
  const wifiOn = t === 'wifi' || (combo && DRAFT.useWifi);
  const placeOn = t === 'posizione' || (combo && DRAFT.usePlace);
  const limitOn = t === 'limite' || (combo && DRAFT.useLimit);
  const sw = document.getElementById('edAllDay');
  if(sw) sw.className = 'switch' + (DRAFT.allDay ? ' on' : '');
  const time = document.getElementById('edTimeBox');
  if(time) time.hidden = !timeOn || DRAFT.allDay;
  const daysBox = document.getElementById('edDaysBox');
  if(daysBox) daysBox.hidden = (t === 'sempre' || t === 'app' || t === 'abitudine');
  const allRow = document.getElementById('edAllDayRow');
  if(allRow) allRow.hidden = !timeOn;
  const opens = document.getElementById('edOpensBox');
  if(opens) opens.hidden = !limitOn;
  const quota = document.getElementById('edQuotaBox');
  if(quota) quota.hidden = !limitOn;
  const cb = document.getElementById('edComboBox');
  if(cb){
    cb.hidden = !combo;
    [['edUseTime','useTime'],['edUseLimit','useLimit'],['edUsePlace','usePlace'],['edUseWifi','useWifi']].forEach(function(pair){
      const el = document.getElementById(pair[0]); if(el) el.className = 'switch' + (DRAFT[pair[1]] ? ' on' : '');
    });
    const warn = document.getElementById('edComboWarn');
    if(warn) warn.hidden = edComboCount() >= 2;
  }
  const wb = document.getElementById('edWifiBox'); if(wb) wb.hidden = !wifiOn;
  const pb = document.getElementById('edPlaceBox'); if(pb) pb.hidden = !placeOn;
  if(wifiOn) edPaintWifi();
  if(placeOn) edPaintPlaces();
  renderEdDays();
}

/* ---- Wi-Fi / posizione / combinazione: the conditions AppBlock offers beyond the clock ---- */
/* AppBlock asks for at least two: a "combination" of one condition is just that condition,
   and the four types above already cover each on its own. */
function edComboCount(){
  if(!DRAFT) return 0;
  return ['useTime','useLimit','useWifi','usePlace'].filter(function(k){ return !!DRAFT[k]; }).length;
}
function edComboToggle(key){
  if(!DRAFT || DRAFT.type !== 'combo') return;
  DRAFT[key] = !DRAFT[key];
  paintEditorSchedule();
  if(DRAFT[key] && (key === 'useWifi' || key === 'usePlace')) edEnsureLocation(key === 'usePlace');
}

/* The SSID is location data on Android: without the permission the phone reports
   "<unknown ssid>" and a Wi-Fi program would never fire. Asked here, once, when it matters. */
const ED_LOC_DISCLOSED = 'fl_loc_disclosed';
async function edEnsureLocation(wantBackground){
  if(!NATIVE || !NATIVE.requestLocationPermission) return { granted:true, background:true, preview:true };
  let p = null;
  try{ p = await NATIVE.getLocationPermission(); }catch(e){ p = null; }
  if(!(p && p.granted)){
    // Google Play's "prominent disclosure": said in our own words, before the system dialog,
    // and only once. The dialog itself never explains why an app wants the location.
    if(localStorage.getItem(ED_LOC_DISCLOSED) !== '1'){
      /* 0.9.402 BUG-248, Andrea: "sette righe sono troppe: va scritto corto (2 righe)". Restano le tre cose che Google chiede di dire
         prima del permesso: a cosa serve (il blocco quando arrivi), che si legge anche ad app chiusa, che resta sul telefono */
      const ok = await blkConfirm('DreamMap usa la posizione',
        'Il blocco scatta quando arrivi, anche ad app chiusa. Resta sul tuo telefono.', 'Continua');
      if(!ok) return { granted:false, declined:true };
      localStorage.setItem(ED_LOC_DISCLOSED, '1');
    }
    try{ p = await NATIVE.requestLocationPermission(); }catch(e){ p = null; }
  }
  edPaintLocationHint(p, wantBackground);
  return p || { granted:false };
}
function edPaintLocationHint(p, wantBackground){
  const ids = ['edWifiPerm','edPlacePerm'];
  ids.forEach(function(id){
    const el = document.getElementById(id); if(!el) return;
    if(!p){ el.hidden = true; return; }
    if(!p.granted){
      el.hidden = false;
      el.innerHTML = '⚠️ Senza il permesso di posizione Android non rivela né la rete né il luogo. Il programma non potrebbe mai scattare. '
        + '<a href="#" onclick="event.preventDefault();edEnsureLocation(true)">Concedi il permesso</a>';
    }else if(wantBackground && !p.background){
      el.hidden = false;
      el.innerHTML = 'ℹ️ Per funzionare anche a schermo spento imposta la posizione su <b>Consenti sempre</b>. '
        + '<a href="#" onclick="event.preventDefault();NATIVE&&NATIVE.openLocationSettings&&NATIVE.openLocationSettings()">Apri le impostazioni</a>';
    }else if(p.locationOn === false){
      el.hidden = false;
      el.textContent = '⚠️ La posizione del telefono è spenta. Accendila dalle impostazioni rapide.';
    }else{
      el.hidden = true;
    }
  });
}

function edPaintWifi(){
  const box = document.getElementById('edWifiList'); if(!box || !DRAFT) return;
  const list = DRAFT.wifi || [];
  box.innerHTML = list.length
    ? list.map(function(ssid, i){ return '<span class="blk-chip"><i>📶</i>' + blkEsc(ssid) + ' <b style="cursor:pointer;padding-left:4px" onclick="edWifiRemove(' + i + ')">✕</b></span>'; }).join('')
    : '<span class="hintline" style="padding:0">Nessuna rete ancora. Aggiungi quella attuale o scrivi il nome.</span>';
}
function edWifiAddName(name){
  if(!DRAFT) return;
  const v = String(name || '').trim();
  if(!v){ toast('Scrivi il nome della rete'); return; }
  DRAFT.wifi = DRAFT.wifi || [];
  if(DRAFT.wifi.indexOf(v) < 0) DRAFT.wifi.push(v);
  edPaintWifi();
}
function edWifiAdd(){
  const el = document.getElementById('edWifiIn');
  edWifiAddName(el ? el.value : '');
  if(el) el.value = '';
}
function edWifiRemove(i){ if(!DRAFT || !DRAFT.wifi) return; DRAFT.wifi.splice(i, 1); edPaintWifi(); }
async function edWifiCurrent(){
  if(!NATIVE || !NATIVE.getWifiInfo){ toast('Anteprima nel browser:\nsul telefono qui compare la rete a cui sei connesso'); return; }
  const p = await edEnsureLocation(false);
  if(p && p.granted === false) return;
  let info = null;
  try{ info = await NATIVE.getWifiInfo(); }catch(e){ info = null; }
  if(!info || !info.current){
    toast(info && info.wifiEnabled === false ? 'Il Wi-Fi è spento' : 'Non sei connesso a nessuna rete Wi-Fi');
    return;
  }
  edWifiAddName(info.current);
  toast('Aggiunta: ' + info.current);
}
async function edWifiScan(){
  const near = document.getElementById('edWifiNear');
  if(!NATIVE || !NATIVE.getWifiInfo){ toast('Anteprima nel browser:\nsul telefono qui compaiono le reti vicine'); return; }
  const p = await edEnsureLocation(false);
  if(p && p.granted === false) return;
  let info = null;
  try{ info = await NATIVE.getWifiInfo(); }catch(e){ info = null; }
  const nets = (info && Array.isArray(info.networks)) ? info.networks : [];
  if(!near) return;
  if(!nets.length){ near.innerHTML = '<span class="hintline" style="padding:0">Nessuna rete visibile adesso' + (info && info.wifiEnabled === false ? ': il Wi-Fi è spento' : '') + '.</span>'; return; }
  near.innerHTML = nets.map(function(n){
    return '<button type="button" class="blk-chip" style="cursor:pointer;border:1px solid var(--line);background:#fff" onclick="edWifiAddName(' + JSON.stringify(n).replace(/"/g,'&quot;') + ')">＋ ' + blkEsc(n) + '</button>';
  }).join('');
}

const ED_RADII = [{m:100,l:'100 m'},{m:250,l:'250 m'},{m:500,l:'500 m'},{m:1000,l:'1 km'}];
let edRadiusM = 150;
function edPaintPlaces(){
  const box = document.getElementById('edPlaceList'); if(!box || !DRAFT) return;
  const list = DRAFT.places || [];
  box.innerHTML = list.length
    ? list.map(function(p, i){
        return '<div class="setrow" style="cursor:default"><span>📍</span><b>' + blkEsc(p.name || 'Luogo') + '</b>'
          + '<small>raggio ' + (p.radius >= 1000 ? (p.radius/1000) + ' km' : p.radius + ' m') + '</small>'
          + '<button type="button" class="ghostmini" style="margin-left:auto" onclick="edPlaceRemove(' + i + ')">✕</button></div>';
      }).join('')
    : '<div class="hintline" style="padding:0 0 8px">Nessun luogo ancora. Vai sul posto e tocca "Aggiungi la posizione attuale".</div>';
  const r = document.getElementById('edRadius');
  if(r) r.innerHTML = '<span class="hintline" style="padding:0;width:100%">Raggio intorno al punto</span>' + ED_RADII.map(function(o){
    return '<button type="button" class="sev-chip' + (edRadiusM === o.m ? ' on' : '') + '" onclick="edRadiusPick(' + o.m + ')">' + o.l + '</button>';
  }).join('');
}
function edRadiusPick(m){ edRadiusM = m; edPaintPlaces(); }
function edPlaceRemove(i){ if(!DRAFT || !DRAFT.places) return; DRAFT.places.splice(i, 1); edPaintPlaces(); }
async function edPlaceAddCurrent(){
  if(!DRAFT) return;
  const nameEl = document.getElementById('edPlaceName');
  const name = (nameEl ? nameEl.value : '').trim() || ('Luogo ' + ((DRAFT.places || []).length + 1));
  if(!NATIVE || !NATIVE.getCurrentLocation){
    DRAFT.places = DRAFT.places || [];
    DRAFT.places.push({ name: name, lat: 45.4642, lng: 9.19, radius: edRadiusM });
    if(nameEl) nameEl.value = '';
    edPaintPlaces(); toast('Anteprima:\nsul telefono qui viene letta la posizione reale');
    return;
  }
  const p = await edEnsureLocation(true);
  if(p && p.granted === false) return;
  toast('Leggo la posizione…');
  let loc = null;
  try{ loc = await NATIVE.getCurrentLocation(); }
  catch(e){ toast((e && e.message) || 'Posizione non disponibile'); return; }
  if(!loc || typeof loc.lat !== 'number'){ toast('Posizione non disponibile'); return; }
  DRAFT.places = DRAFT.places || [];
  DRAFT.places.push({ name: name, lat: loc.lat, lng: loc.lng, radius: edRadiusM });
  if(nameEl) nameEl.value = '';
  edPaintPlaces();
  toast('Aggiunto: ' + name + (loc.accuracy > 0 ? ' (±' + Math.round(loc.accuracy) + ' m)' : ''));
}

function describeProgram(p){
  const bits = [];
  if(p.type === 'ora' || (p.type === 'combo' && p.useTime !== false)){
    bits.push(daysLabel(p.days));
    bits.push(p.allDay ? 'Tutto il giorno' : ((p.from || '') + ' – ' + (p.to || '')));
  }
  if(p.type === 'wifi' || (p.type === 'combo' && p.useWifi)){
    const w = p.wifi || []; bits.push(w.length === 1 ? 'Wi-Fi ' + w[0] : w.length + ' reti Wi-Fi');
  }
  if(p.type === 'posizione' || (p.type === 'combo' && p.usePlace)){
    const pl = p.places || []; bits.push(pl.length === 1 ? '📍 ' + (pl[0].name || 'luogo') : pl.length + ' luoghi');
  }
  if(p.type === 'limite' || (p.type === 'combo' && p.useLimit)){
    if(p.qh) bits.push(p.qh + 'm/ora');
    if(p.qd) bits.push(p.qd + 'm/giorno');
    if(!p.qh && !p.qd) bits.push('nessun limite impostato');
  }
  if(p.type === 'sempre') bits.push('Sempre attivo');
  if(p.type === 'limite') bits.push(daysLabel(p.days));
  const n = (p.apps || []).length, s = (p.sites || []).length + (p.keywords || []).length;
  bits.push(n + ' app · ' + s + ' siti/parole');
  return bits.join(' · ');
}

/* ================= 7 · PUSH VERSO IL MOTORE =================
 * One program = one Schedule. No more flattened union: that is what made an hourly program
 * and a permanent one indistinguishable to the engine (G12). */
function programToSchedule(p){
  return {
    id: p.id,
    name: p.name || 'Programma',
    type: p.type || 'sempre',
    from: p.from || '00:00',
    to: p.to || '00:00',
    days: (Array.isArray(p.days) && p.days.length === 7) ? p.days : [true,true,true,true,true,true,true],
    allDay: !!p.allDay,
    quotaHourMin: p.qh || 0,
    quotaDayMin: p.qd || 0,
    apps: p.apps || [],
    sites: p.sites || [],
    keywords: p.keywords || [],
    redirectUrl: p.redirectUrl || '',
    wifi: p.wifi || [],
    places: p.places || [],
    useTime: p.useTime !== false, useWifi: !!p.useWifi, usePlace: !!p.usePlace, useLimit: !!p.useLimit,
    allow: p.allow || [],
    blockLaunch: p.blockLaunch !== false,
    blockNotifications: p.blockNotifications !== false,
    enabled: p.on !== false,
    grazia: blkInGrazia(p) ? p.grazia : 0,
    daAgente: !!p.daAgente,
    daConfermare: !!p.daConfermare,
    /* 0.9.400 BUG-169: "Bivio su tutte le schermate di blocco" e "Rettificabile anche in Modalità severa" */
    bivio: !!p.bivio,
    rettifica: !!p.rettifica
  };
}

async function pushRules(){
  saveProgramsLocal();
  if(!NATIVE) return;
  blkEnsureIds();

  if(blkHasNative('saveSchedules')){
    const res = await blkNative('saveSchedules', { schedules: PROGRAMS.map(programToSchedule) });
    if(res === null){
      /* 0.9.287: rifiutato dal motore (Modalita' severa): la pagina torna a quello che il motore applica davvero,
         invece di mostrare un programma modificato che non vale */
      try{ if(await hydrateProgramsFromEngine()){ saveProgramsLocal(); if(typeof renderPrograms === 'function') renderPrograms(); } }catch(_){ }
      return;
    }
    await blkClearLegacyUnion();
    /* Whether a programme is blocking RIGHT NOW is the engine's answer, not ours: resuming a
       paused one left `activeNow` at what it was while paused (false), so the card said
       PROGRAMMATO with no ring until the once-a-minute refresh came round. Re-reading here
       costs one call and makes every save tell the truth immediately. */
    try{ if(await hydrateProgramsFromEngine() && typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
    return;
  }

  /* Older engine build without Schedule: the union is all it understands. Degrading to it is
     better than saving nothing, but the user is told the schedule is not being honoured. */
  const apps = new Set(), kws = new Set(), allow = new Set();
  PROGRAMS.filter(function(p){ return p.on !== false; }).forEach(function(p){
    (p.apps || []).forEach(function(a){ apps.add(a); });
    // Keywords are {t, m} objects since the match-type work; the legacy setRules only
    // understands flat strings, so the term is what goes across on this path.
    (p.keywords || []).forEach(function(k){ kws.add((k && k.t) ? k.t : k); });
    (p.sites || []).forEach(function(s){ kws.add(s); });
    (p.allow || []).forEach(function(a){ allow.add(a); });
  });
  const cur = await blkNative('getRules', {}, true);
  await blkNative('setRules', {
    apps:[...apps], keywords:[...kws], allow:[...allow],
    strict: cur ? cur.strict : 0, enabled: cur ? cur.enabled : true
  });
  if(typeof toast === 'function') toast('Motore datato:\ngli orari non vengono applicati');
}

/* Versions before schedules wrote the union into the GLOBAL apps/keywords, which block
   around the clock. Leaving them there would keep every program permanent forever, so they
   are cleared once - and only once the schedules have actually been accepted. A refusal from
   Modalita severa is not an error here: it is retried on the next save. */
async function blkClearLegacyUnion(){
  if(localStorage.getItem('fl_union_cleared') === '1') return;
  const cur = await blkNative('getRulesFull', {}, true);
  if(!cur) return;
  const dirty = (cur.apps && cur.apps.length) || (cur.keywords && cur.keywords.length) || (cur.sites && cur.sites.length);
  if(!dirty){ localStorage.setItem('fl_union_cleared','1'); return; }
  const ok = await blkNative('setRulesFull', { apps:[], keywords:[], sites:[] }, true);
  if(ok) localStorage.setItem('fl_union_cleared','1');
}

/* ================= 8 · LISTA DEI PROGRAMMI ================= */

let BLK_STRICT = null;   // last known severe-mode state; null until the engine has answered

/* Whether the engine will refuse any change to the programs right now.
   "Blocca i blocchi nelle app" is the one guard that is always on in severe mode, so this is
   also the answer to "may the user delete a program". */
function blkEditLocked(){
  /* 0.9.395, Andrea: "adesso si può spuntare via anche se la modalità severa è attiva dal telefono": la risposta e' una sola
     per telefono, Vista telefono del computer e app Android (severa-dove.js, sevBloccaQui) */
  if (typeof sevBloccaQui === 'function') return sevBloccaQui();
  return !!(BLK_STRICT && BLK_STRICT.inAppEditLocked);
}
/* 0.9.290, Andrea (come AppBlock): "duplicandolo uno deve poterlo modificare: se si blocca subito per la modalita' severa
   non si possono cambiare le regole. Diamo due minuti, poi diventa attivo da solo". Un programma creato o duplicato con
   la Modalita' severa accesa ha `grazia` (l'ora in cui finiscono i due minuti): fino ad allora si cambia, si mette in
   pausa e si elimina come se la modalita' fosse spenta; il motore (FocusLockPlugin.refuseIfWeakening) fa lo stesso. */
const BLK_GRAZIA_MS = 2 * 60 * 1000;
function blkInGrazia(p){ return !!(p && p.grazia && p.grazia > Date.now()); }
/* 0.9.395, Andrea: "il genio ha creato un programma che blocca Telegram senza chiedere niente; l'errore e' dell'agente, non voglio
   perdere punti". Il programma creato dal tuo agente personale aspetta la conferma dell'utente: fino ad allora la Modalita' severa
   non lo chiude a chiave (il motore fa lo stesso, Schedule.liberoDalLucchetto). Confermato, vale la Modalita' severa come per tutti. */
function blkDaConfermare(p){ return !!(p && p.daConfermare); }
function blkBloccato(p){ return blkEditLocked() && !blkInGrazia(p) && !blkDaConfermare(p); }

async function blkRefreshStrict(){
  if(!blkHasNative('getStrictState')) return;
  const st = await blkNative('getStrictState', {}, true);
  if(st) BLK_STRICT = st;
  /* 0.9.395: il telefono pubblica il suo stato, cosi' il computer sa se la Modalita' severa e' accesa */
  if(st && typeof sdvPubblicaStato === 'function') sdvPubblicaStato(st);
}

/* Which packages are on the phone right now. A programme whose every app has been
   uninstalled is not blocking anything, and the card has to say so instead of "ATTIVO". */
let BLK_INSTALLED = null;
async function blkLoadInstalled(){
  if(!blkHasNative('getInstalledApps')) return;
  const r = await flApps().catch(function(){ return null; });
  if(r && Array.isArray(r.apps)){
    BLK_INSTALLED = new Set(r.apps.map(function(a){ return a.packageName; }));
    renderPrograms();
  }
}
/* "Sta bloccando qualcosa?" — false when the programme has nothing left to act on. */
function blkHasTargets(p){
  if((p.sites || []).length || (p.keywords || []).length) return true;
  const apps = p.apps || [];
  if(!apps.length) return false;
  if(!BLK_INSTALLED) return true;              // not known yet: do not accuse
  return apps.some(function(a){ return BLK_INSTALLED.has(a); });
}
/* The four states a card can be in, and what they look like. */
/* "9m 53s rimasti", come AppBlock; a zero l'app e' chiusa fino alla prossima ora (o a domani) */
function blkRimasto(ms){
  if (!(ms > 0)) return 'Tempo finito';
  const t = Math.ceil(ms / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
  return (h ? h + 'h ' + m + 'm' : m + 'm ' + sec + 's') + ' rimasti';
}
/* fermo mentre guardi DreamMap: il tempo scende solo quando usi quell'app, e si rilegge dal motore */
function blkCardState(p, locked){
  if(p.on === false) return { cls:'off', pill:'IN PAUSA', pillCls:'paused' };
  /* 0.9.395: il programma del tuo agente che aspetta la conferma lo dice, e non ha il lucchetto */
  if(blkDaConfermare(p)) return { cls: p.activeNow ? 'on' : '', pill:'DA CONFERMARE', pillCls:'conf' };
  if(!blkHasTargets(p)) return { cls:'off', pill:'NON BLOCCA NIENTE', pillCls:'paused' };
  /* 0.9.292, Andrea: "PROTETTO non dice che sta bloccando adesso: la parola giusta e' ATTIVO" */
  if(locked) return { cls: p.activeNow ? 'on' : '', pill: p.activeNow ? '🔒 ATTIVO' : '🔒 PROGRAMMATO', pillCls: p.activeNow ? '' : 'idle' };
  if(p.activeNow) return { cls:'on', pill:'ATTIVO', pillCls:'' };
  return { cls:'', pill:'PROGRAMMATO', pillCls:'idle' };
}

/* IL PROGRAMMA NUOVO IN EVIDENZA (0.9.282, Andrea): dal "Mostra il programma" del Genio si arriva qui, la pagina scorre
   fino al programma creato, tutto il resto si scurisce e il suo bordo lampeggia. Toccandolo (o toccando fuori) si torna normali. */
function blkEvidenzia(pid){
  let n = 0;
  const giro = function(){
    const c = document.querySelector('.blk-card[data-pid="' + (window.CSS && CSS.escape ? CSS.escape(pid) : pid) + '"]');
    if (!c){ if (++n < 20) setTimeout(giro, 200); return; }
    /* 0.9.402 BUG-238: qui la pagina deve andare sul programma, non tornare dove eri: si ferma il ripristino della posizione */
    try{ BLK_SCROLL.mano = Date.now() + 1; }catch(_){ }
    c.scrollIntoView({ block: 'center', behavior: 'smooth' });
    let v = document.getElementById('blkEvVelo');
    if (!v){ v = document.createElement('div'); v.id = 'blkEvVelo'; v.className = 'blk-ev-velo'; v.onclick = blkEvidenzaVia; (c.closest('.screen') || document.getElementById('phone') || document.body).appendChild(v); }
    c.classList.add('blk-ev');
  };
  setTimeout(giro, 350);
}
function blkEvidenzaVia(){
  const v = document.getElementById('blkEvVelo'); if (v) v.remove();
  document.querySelectorAll('.blk-card.blk-ev').forEach(function(c){ c.classList.remove('blk-ev'); });
}
function renderPrograms(){
  const box = document.getElementById('progList');
  if(!box) return;
  if(!PROGRAMS.length){
    box.innerHTML = '<div class="hintline" style="text-align:center;padding:18px 0">Nessun programma. Tocca “+ Inserisci” per crearne uno.</div>';
    setTimeout(blkPaintStreak, 0);
    return;
  }
  const locked = blkEditLocked();
  setTimeout(blkPaintStreak, 0);
  box.innerHTML = PROGRAMS.map(function(p,i){
    const paused = p.on === false;
    const st = blkCardState(p, locked);
    const dead = st.pill === 'NON BLOCCA NIENTE';
    const conf = blkDaConfermare(p);
    return '<div class="blk-card' + (locked && !conf ? ' blk-card-locked' : '') + (conf ? ' blk-card-conf' : '') + (st.cls ? ' ' + st.cls : '') + '" data-pid="' + blkEsc(p.id || '') + '" onclick="blkEvidenzaVia();editProgram(' + i + ')" role="button">' +
      '<button class="blk-card-more" onclick="event.stopPropagation(); blkProgMenu(' + i + ')" aria-label="Opzioni">⋯</button>' +
      '<div class="blk-card-ico">' + (p.icon || '🕑') + '</div>' +
      '<b class="blk-card-name">' + blkEsc(p.name) + '</b>' +
      '<small class="blk-card-desc">' + blkEsc(describeProgram(p)) + '</small>' +
      (typeof p.rimastoMs === 'number' && p.on !== false ? '<small class="blk-card-rim" data-ms="' + p.rimastoMs + '" data-al="' + (p.rimastoAl || Date.now()) + '">' + blkRimasto(p.rimastoMs) + '</small>' : '') +
      '<span class="blk-card-pill' + (st.pillCls ? ' ' + st.pillCls : '') + '">' + st.pill + '</span>' +
      /* 0.9.395, Andrea: "mostragli il link al programma, cosi' puo' controllare le condizioni" */
      (conf ? '<small class="blk-card-confnota">L’ha creato il tuo agente personale e aspetta la tua conferma. Controlla le condizioni:<br>finché non lo confermi puoi cambiarlo o toglierlo senza penalità, anche con la Modalità severa accesa.</small>'
            + '<span class="blk-card-confaz"><button type="button" class="blk-card-resume" onclick="event.stopPropagation();blkConferma(' + i + ')">Va bene così</button>'
            + '<button type="button" class="blk-card-resume blk-card-cambia" onclick="event.stopPropagation();editProgram(' + i + ')">Cambialo</button></span>' : '') +
      (dead ? '<small class="blk-card-dead">Le app di questo programma non sono più sul telefono. Quando le reinstalli tornano bloccate da sole; intanto tocca la card per aggiungerne altre.</small>' : '') +
      // A paused programme is one tap from being on again, right where it is: the ⋯ menu
      // hid the only action anybody wants on it.
      (paused && (!locked || conf) ? '<button class="blk-card-resume" onclick="event.stopPropagation();toggleProgram(' + i + ')">▶ Riprendi</button>' : '') +
    '</div>';
  }).join('');
}

/* The three-dot menu, in place of a bare ✕.

   A program is work: naming it, choosing its hours, picking its apps. Putting a delete cross
   as the only affordance on the card made destruction the easiest thing to reach, and it went
   through the browser's own confirm() — a dialog that does not belong to this app and cannot
   be styled, which is why it looked like a web page error. */
function blkProgMenu(i){
  const p = PROGRAMS[i];
  if(!p) return;
  const locked = blkBloccato(p);
  const paused = p.on === false;

  const sheet = document.getElementById('blkProgSheet');
  const body = document.getElementById('blkProgSheetBody');
  if(!sheet || !body) return;

  const row = function(icon, label, handler, danger, disabled){
    const b = document.createElement('button');
    b.className = 'blk-sheet-row' + (danger ? ' danger' : '') + (disabled ? ' disabled' : '');
    b.innerHTML = '<span class="ic">' + icon + '</span><span>' + blkEsc(label) + '</span>';
    if(disabled) b.disabled = true;
    else b.addEventListener('click', function(){ blkCloseProgMenu(); handler(); });
    return b;
  };

  body.innerHTML = '';
  const title = document.createElement('div');
  title.className = 'blk-sheet-title';
  title.textContent = p.name;
  body.appendChild(title);

  /* 0.9.395: il programma del tuo agente che aspetta la conferma: Va bene cosi', Cambialo, Toglilo (senza penalita') */
  if(blkDaConfermare(p)){
    const nota = document.createElement('p');
    nota.className = 'blk-sheet-note';
    nota.textContent = 'L’ha creato il tuo agente personale e aspetta la tua conferma. Finché non lo confermi puoi cambiarlo, '
                     + 'metterlo in pausa o toglierlo senza penalità, anche con la Modalità severa accesa.';
    body.appendChild(nota);
    body.appendChild(row('✅', 'Va bene così', function(){ blkConferma(i); }, false, false));
    body.appendChild(row('✏️', 'Cambialo', function(){ editProgram(i); }, false, false));
    body.appendChild(row(paused ? '▶️' : '⏸', paused ? 'Riprendi' : 'Metti in pausa', function(){ toggleProgram(i); }, false, false));
    body.appendChild(row('🗑', 'Toglilo', function(){ deleteProgram(i); }, true, false));
    sheet.classList.add('open');
    return;
  }

  if(locked){
    const note = document.createElement('p');
    note.className = 'blk-sheet-note';
    note.textContent = "Modalità severa attiva. Puoi ancora AGGIUNGERE app, siti e parole "
                     + "a questo blocco, ma non toglierne, né metterlo in pausa o eliminarlo. "
                     + "Stringere sì, allentare no.";
    body.appendChild(note);
  }

  // Editing stays open while the strict mode runs, and this is not an oversight.
  //
  // The lock exists to stop the block being loosened, and adding a keyword to a programme is
  // the opposite of loosening. Greying this row out took a tightening away from the user for
  // no gain: it was the one thing they were allowed to do and the app said no. Removals are
  // still refused, by the engine, on save - which is where a guard belongs, because that is
  // the only place it cannot be walked around.
  body.appendChild(row('✏️', locked ? 'Aggiungi altri blocchi' : 'Modifica',
                       function(){ editProgram(i); }, false, false));
  /* "Metti in pausa" e' un eufemismo: descrive il gesto, non quello che succede. Interrompere
     un blocco e' interromperlo, e la parola giusta e' gia' meta' dell'attrito. */
  body.appendChild(row(paused ? '▶️' : '⏸', paused ? 'Riprendi' : 'Interrompi',
                       function(){ blkCloseProgMenu();
                                   if (paused || typeof itProgramAsk !== 'function') toggleProgram(i);
                                   else setTimeout(function(){ itProgramAsk(i); }, 220); },
                       false, locked));
  /* 0.9.287, Andrea: un programma come modello per un altro. Si apre l'editor con una copia nuova:
     creare un blocco in piu' stringe, quindi si puo' anche con la Modalita' severa accesa. */
  body.appendChild(row('📄', 'Duplica', function(){ blkDuplicaProgramma(i); }, false, false));
  body.appendChild(row('🗑', 'Elimina', function(){ deleteProgram(i); }, true, locked));

  sheet.classList.add('open');
}
async function blkDuplicaProgramma(i){
  const p = PROGRAMS[i];
  if(!p) return;
  window.BLK_GREY = false;
  /* 0.9.290: la copia nasce subito (come "Duplica" in AppBlock). Con la Modalita' severa accesa ha due minuti per
     essere cambiata; il foglio lo dice, e l'editor della copia si apre da solo. */
  const copia = JSON.parse(JSON.stringify(p));
  copia.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
  delete copia.idx;
  copia.on = true;
  copia.name = (p.name || 'Programma') + ' (copia)';
  if(!Array.isArray(copia.days) || copia.days.length !== 7) copia.days = [true,true,true,true,true,true,true];
  const severa = blkEditLocked();
  if (severa) copia.grazia = Date.now() + BLK_GRAZIA_MS;
  PROGRAMS.push(copia);
  saveProgramsLocal();
  await pushRules();
  try{ if (typeof lcProgDi === 'function' && typeof lcSalvaProgramma === 'function'){ const sc = lcProgDi(p.id); if (sc) lcSalvaProgramma(copia.id, JSON.parse(JSON.stringify(sc))); } }catch(_){ }
  renderPrograms();
  const idx = PROGRAMS.findIndex(function(x){ return x.id === copia.id; });
  const apri = function(){ if (idx >= 0) editProgram(idx); };
  if (severa && !blkGraziaNonMostrare()) blkGraziaFoglio(apri); else { apri(); toast('Copia di “' + (p.name || 'Programma') + '”: cambia quello che vuoi'); }
}
function blkGraziaNonMostrare(){ try{ return localStorage.getItem('fl_sev_grazia_no') === '1'; }catch(_){ return false; } }
/* Il foglio come quello di AppBlock, nel modo dei fogli dell'app: la X, il velo scuro, un tocco fuori lo chiude. */
function blkGraziaFoglio(poi){
  let w = document.getElementById('blkGrazia'); if (w) w.remove();
  w = document.createElement('div'); w.id = 'blkGrazia'; w.className = 'blk-grazia';
  w.innerHTML = '<div class="blk-grazia-f" role="dialog" aria-modal="true">'
    + '<button type="button" class="blk-grazia-x" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="blk-grazia-ico"><svg viewBox="0 0 24 24" width="30" height="30" fill="#fff" aria-hidden="true"><path d="M13.5 2 4.8 13.4h6.1L9.9 22l8.9-12h-6.2z"/></svg></div>'
    + '<b>Modalità severa attiva</b>'
    + '<p>Il programma duplicato si blocca da solo fra due minuti. Fino ad allora puoi cambiarne le regole.</p>'
    + '<label class="blk-grazia-cb"><input type="checkbox" id="blkGraziaNo"><span>Non mostrare di nuovo</span></label>'
    + '<button type="button" class="cta blk-grazia-ok">Cambio le regole</button></div>';
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  const chiudi = function(){
    try{ if (document.getElementById('blkGraziaNo').checked) localStorage.setItem('fl_sev_grazia_no', '1'); }catch(_){ }
    w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 220);
    if (typeof poi === 'function') poi();
  };
  w.addEventListener('click', function(e){ if (e.target === w) chiudi(); });
  w.querySelector('.blk-grazia-x').onclick = chiudi;
  w.querySelector('.blk-grazia-ok').onclick = chiudi;
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.blk-grazia{position:fixed;inset:0;z-index:99970;background:rgba(0,8,20,.62);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .2s}.blk-grazia.in{opacity:1}',
    '.blk-grazia-f{position:relative;width:100%;max-width:520px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:32px 22px calc(24px + env(safe-area-inset-bottom));text-align:center;transform:translateY(24px);transition:transform .25s cubic-bezier(.2,.9,.3,1)}.blk-grazia.in .blk-grazia-f{transform:none}body.dark .blk-grazia-f{background:#12203A}',
    '.blk-grazia-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .blk-grazia-x{background:rgba(255,255,255,.1);color:#fff}',
    '.blk-grazia-ico{width:64px;height:64px;margin:0 auto 18px;border-radius:20px;background:linear-gradient(160deg,#E63946,#B3202C);display:flex;align-items:center;justify-content:center;font-size:32px}',
    '.blk-grazia-f > b{display:block;font:800 21px/1.3 var(--font-display,var(--font-body));color:var(--navy)}body.dark .blk-grazia-f > b{color:#fff}',
    '.blk-grazia-f p{margin:12px auto 24px;max-width:30ch;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.blk-grazia-cb{display:inline-flex;align-items:center;gap:10px;margin:0 0 28px;font:600 14.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .blk-grazia-cb{color:#fff}.blk-grazia-cb input{width:20px;height:20px;accent-color:#0075E3}',
    '.blk-grazia-f .cta{width:100%}'
  ].join('');
  document.head.appendChild(st);
})();
/** 0.9.395: "Va bene cosi'": il programma del tuo agente diventa come gli altri, e con la Modalita' severa accesa si chiude a chiave. */
async function blkConferma(i){
  const p = PROGRAMS[i]; if (!p) return;
  p.daConfermare = false;
  saveProgramsLocal(); renderPrograms();
  try{ flVibra(14); }catch(_){ }
  await pushRules();
  try{ if (typeof syncNative === 'function') syncNative(); }catch(_){ }
  toast('“' + (p.name || 'Programma') + '” confermato');
}
function blkCloseProgMenu(){
  const sheet = document.getElementById('blkProgSheet');
  if(sheet) sheet.classList.remove('open');
}

/* An in-app confirmation. window.confirm() shows the WebView's own dialog, which carries the
   page origin and none of the app's design: to the user it reads as a browser error, not as a
   decision the app is asking for. Returns a promise so callers stay linear. */
function blkConfirm(title, text, okLabel, danger){
  return new Promise(function(resolve){
    const box = document.getElementById('blkConfirm');
    if(!box) return resolve(window.confirm(title));
    document.getElementById('blkConfirmTitle').textContent = title;
    document.getElementById('blkConfirmText').textContent = text || '';
    const ok = document.getElementById('blkConfirmOk');
    const no = document.getElementById('blkConfirmNo');
    ok.textContent = okLabel || 'Conferma';
    ok.className = 'cta' + (danger ? ' danger' : '');
    const done = function(v){
      box.classList.remove('open');
      ok.onclick = null; no.onclick = null;
      resolve(v);
    };
    ok.onclick = function(){ done(true); };
    no.onclick = function(){ done(false); };
    box.classList.add('open');
  });
}

/* 0.9.311, ELIMINA PROGRAMMA. Un popup al centro, uno solo per tutti i programmi dell'app (blocchi, bianco e nero,
   suoni, cicli del Full Focus, quelli creati dall'agente personale): prima alcuni cancellavano al primo tocco.
   MANTIENI e' la scelta che non fa danni: ci finiscono anche il tocco fuori e il tasto indietro di Android
   (navChiudiVelo tocca il velo: per questo lo z-index sta sopra a 100 e il velo copre tutta la cornice).
   Le card dei modelli usano lo stesso popup con le loro parole (o.titolo, o.testo, o.si). */
function blkEliminaChiedi(o){
  o = o || {};
  return new Promise(function(resolve){
    const vecchio = document.getElementById('blkElimina'); if (vecchio) vecchio.remove();
    const w = document.createElement('div');
    w.id = 'blkElimina'; w.className = 'blk-el';
    w.innerHTML = '<div class="blk-el-f" role="alertdialog" aria-modal="true" aria-labelledby="blkElT" aria-describedby="blkElP">'
      + '<b id="blkElT"></b><p id="blkElP"></p>'
      + '<div class="blk-el-az"><button type="button" class="blk-el-no"></button><button type="button" class="blk-el-si"></button></div></div>';
    w.querySelector('#blkElT').textContent = o.titolo || 'Elimina programma';
    w.querySelector('#blkElP').textContent = o.testo || 'Vuoi davvero eliminare il programma? L\u2019operazione non può essere annullata.';
    w.querySelector('.blk-el-no').textContent = o.no || 'MANTIENI';
    w.querySelector('.blk-el-si').textContent = o.si || 'ELIMINA';
    document.body.appendChild(w);
    requestAnimationFrame(function(){ w.classList.add('in'); });
    let finito = false;
    const fine = function(v){
      if (finito) return; finito = true;
      w.remove();
      resolve(v);
    };
    w.addEventListener('click', function(e){ if (e.target === w) fine(false); });
    w.querySelector('.blk-el-no').onclick = function(){ fine(false); };
    w.querySelector('.blk-el-si').onclick = function(){ fine(true); };
  });
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.blk-el{position:fixed;inset:0;z-index:99975;background:rgba(0,8,20,.62);display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;transition:opacity .16s}.blk-el.in{opacity:1}',
    '.blk-el-f{width:100%;max-width:372px;background:var(--card,#fff);border-radius:28px;padding:30px 26px 18px;text-align:center;box-shadow:0 18px 50px rgba(0,19,43,.32)}',
    '.blk-el-f b{display:block;font:800 20px/1.3 var(--font-display,var(--font-body));color:var(--navy)}',
    '.blk-el-f p{margin:14px 0 22px;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.blk-el-az{display:flex;justify-content:center;gap:14px}',
    '.blk-el-az button{min-height:46px;padding:0 16px;border:0;background:none;border-radius:50px;font:800 15px var(--font-body);letter-spacing:.3px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.blk-el-az button:active{background:rgba(0,117,227,.1)}',
    '.blk-el-no{color:#0075E3}',
    '.blk-el-si{color:#E63946}',
    /* di notte il foglio stacca dal velo, e il rosso pieno su blu notte non si leggerebbe: si schiarisce */
    'body.dark .blk-el{background:rgba(0,6,16,.74)}',
    'body.dark .blk-el-f{background:#1C2E5A;border:1px solid rgba(188,224,255,.24)}',
    'body.dark .blk-el-f b{color:#fff}',
    'body.dark .blk-el-f p{color:#BCE0FF}',
    'body.dark .blk-el-no{color:#8CC6FF}',
    'body.dark .blk-el-si{color:#FF8791}'
  ].join('');
  document.head.appendChild(st);
})();

async function toggleProgram(i){
  /* 0.9.395: una funzione sola decide (severa-dove.js, sevRifiuta), anche nella Vista telefono del computer */
  const noPausa = typeof sevRifiuta === 'function' ? sevRifiuta('spegni', PROGRAMS[i]) : (blkBloccato(PROGRAMS[i]) ? 'La Modalità severa è accesa. I blocchi non si possono mettere in pausa' : null);
  if(noPausa){ toast(noPausa); return; }
  PROGRAMS[i].on = PROGRAMS[i].on === false;
  if (PROGRAMS[i].on !== false && typeof itRipresa === 'function') itRipresa('p' + (PROGRAMS[i].id || i));
  saveProgramsLocal(); renderPrograms();
  // A programme switched off is the plan interrupted: the streak starts over.
  if(PROGRAMS[i].on === false && typeof sevStreakBreak === 'function') sevStreakBreak('program');
  await pushRules();                      // re-reads the engine and repaints with the truth
  syncNative();
}

async function deleteProgram(i){
  const p = PROGRAMS[i];
  if(!p) return;
  const noElimina = typeof sevRifiuta === 'function' ? sevRifiuta('elimina', p) : (blkBloccato(p) ? 'La Modalità severa è accesa. I blocchi non si possono eliminare' : null);
  if(noElimina){ toast(noElimina); return; }
  const ok = await blkEliminaChiedi();
  if(!ok) return;
  /* mentre il popup era aperto il motore puo' aver riscritto l'elenco: si cerca lo stesso programma */
  const at = PROGRAMS.indexOf(p) >= 0 ? PROGRAMS.indexOf(p) : PROGRAMS.findIndex(function(x){ return x.id === p.id; });
  if(at < 0) return;
  PROGRAMS.splice(at,1); saveProgramsLocal(); renderPrograms(); await pushRules(); syncNative();
}

/* ================= 9 · CREAZIONE E MODIFICA ================= */

/* UN EDITOR SOLO, DUE ELENCHI.
   Un programma in bianco e nero ha le stesse condizioni di un blocco — ora, giorni, Wi-Fi,
   posizione, combinazione — quindi usa questo stesso editor. Cambia solo dove finisce: fra i
   blocchi, o nell'elenco della pagina Bianco e nero, dove il motore di blocco non lo vede
   mai. `grey` viaggia nella bozza; il limite di utilizzo non ha senso per il grigio e la
   card sparisce. */
/* TERZO ELENCO (1/10): i programmi dei SUONI (sounds.js). Stesse condizioni, stesso editor;
   al posto della lista di blocco c'e' il suono da far partire. newBlock('sound'). */
function newBlock(grey){
  window.BLK_SOUND = grey === 'sound';
  if (window.BLK_SOUND) grey = false;
  window.BLK_GREY = !!grey;
  DRAFT = null;
  const h = document.querySelector('#s-newtype h2');
  if (h) h.textContent = window.BLK_SOUND ? 'Programma di suoni' : (grey ? 'Programma in bianco e nero' : 'Crea nuovo blocco');
  if (window.BLK_SOUND) grey = true;   /* come per il grigio, il limite di utilizzo qui non ha senso */
  const cards = document.querySelectorAll('#s-newtype .typecard');
  if (cards[1]) cards[1].hidden = !!grey;
  blkTipiSuoni(!!window.BLK_SOUND);
  goId('s-newtype');
  if(typeof adsMaybeInterstitial === 'function') adsMaybeInterstitial('new-program');
}

/* La pagina dei tipi, in versione suoni: il titolo sta sulla riga della freccia, al centro; il
   permanente sparisce; compare «mentre usi un'app o un sito»; le descrizioni parlano di suoni. */
/* 0.9.402: dopo i due punti si va a capo; nelle descrizioni corte niente due punti */
const BLK_DESC_SUONI = { ora: 'Il suono parte nei giorni e nelle ore che scegli. Per esempio, la pioggia dalle 9 alle 12 nei giorni feriali.', wifi: 'Il suono parte quando sei connesso a una rete, per esempio quella dell\u2019ufficio.', posizione: 'Il suono parte quando sei in un luogo, per esempio in biblioteca.', combo: 'Orario, Wi-Fi e posizione insieme. Il suono parte solo quando valgono tutte.' };
function blkTipiSuoni(on){
  const sec = document.getElementById('s-newtype'); if (!sec) return;
  sec.classList.toggle('snd-mode', on);
  const bar = sec.querySelector('.topbar');
  let tit = document.getElementById('ntSndTit');
  if (!tit && bar){ tit = document.createElement('b'); tit.id = 'ntSndTit'; tit.className = 'blk-title nt-snd-tit'; tit.textContent = 'Programma di suoni'; bar.appendChild(tit); }
  if (tit) tit.hidden = !on;
  sec.querySelectorAll('.typecard').forEach(function(c){
    const m = String(c.getAttribute('onclick') || '').match(/pickType\('(\w+)'\)/); const k = m ? m[1] : '';
    const p = c.querySelector('p'); if (!p) return;
    if (!c.dataset.desc) c.dataset.desc = p.textContent;
    p.textContent = (on && BLK_DESC_SUONI[k]) ? BLK_DESC_SUONI[k] : c.dataset.desc;
    c.querySelectorAll('.ttag').forEach(function(tg){ tg.hidden = on; });
    if (k === 'sempre') c.hidden = on;
  });
  let app = document.getElementById('ntSndApp');
  if (!app){
    app = document.createElement('div'); app.id = 'ntSndApp'; app.className = 'typecard';
    app.setAttribute('onclick', "pickType('app')");
    app.innerHTML = '<div><b>Mentre usi un\u2019app o un sito</b><p>Il suono parte quando apri le app o i siti che scegli, e si ferma quando li lasci. Per esempio, l’app dove scrivi o studi.</p></div><span class="tico">📲</span>';
    const prima = sec.querySelectorAll('.typecard')[1]; if (prima) sec.insertBefore(app, prima); else sec.appendChild(app);
  }
  app.hidden = !on;
  let den = document.getElementById('ntSndDentro');
  if (!den){
    den = document.createElement('div'); den.id = 'ntSndDentro'; den.className = 'typecard';
    den.setAttribute('onclick', "if(typeof sndDentroApri==='function')sndDentroApri()");
    den.innerHTML = '<div><b>Dentro DreamMap</b><p>Il suono parte quando avvii una sessione di Full Focus o apri una sezione di DreamMap, per esempio il diario di viaggio.</p></div><span class="tico">🚀</span>';
    app.parentNode.insertBefore(den, app.nextSibling);
  }
  den.hidden = !on;
  let hab = document.getElementById('ntSndHab');
  if (!hab){
    hab = document.createElement('div'); hab.id = 'ntSndHab'; hab.className = 'typecard';
    hab.setAttribute('onclick', "pickType('abitudine')");
    hab.innerHTML = '<div><b>Quando fai un\u2019abitudine</b><p>Il suono parte quando DreamMap vede una delle tue abitudini. Per esempio, un audio che ti ricorda di posare il telefono quando apri i social.</p></div><span class="tico">🔁</span>';
    den.parentNode.insertBefore(hab, den.nextSibling);
  }
  hab.hidden = !on;
}
function pickType(type){
  DRAFT = {
    id:null, name:'', type:type, icon:BLK_TYPE_ICON[type] || '🚫',
    from:'22:00', to:'08:00', qh:null, qd:null,
    days:[true,true,true,true,true,true,true], allDay:false,
    apps:[], sites:[], keywords:[], allow:[],
    wifi:[], places:[], useTime: type === 'combo', useWifi:false, usePlace:false, useLimit:false,
    blockLaunch:true, blockNotifications:true, on:true, idx:-1,
    /* 0.9.400 BUG-169: un programma nuovo nasce con il bivio (mai un muro senza scelta) e senza rettifica (resta una protezione) */
    bivio:true, rettifica:false
  };
  if (window.BLK_GREY){ DRAFT.grey = true; DRAFT.icon = '🌑'; }
  if (window.BLK_SOUND){ DRAFT.sound = true; DRAFT.suono = 'rain'; DRAFT.volume = 0.5; DRAFT.icon = type === 'app' ? '📲' : (type === 'abitudine' ? '🔁' : '🎵'); DRAFT.from = '09:00'; DRAFT.to = '12:00'; DRAFT.shuffle = false; if (type === 'app' || type === 'abitudine'){ DRAFT.useTime = false; DRAFT.allDay = true; } if (type === 'abitudine') DRAFT.hab = ''; }
  try{ if (DRAFT.sound && typeof sndSceltaTabDi === 'function') sndSceltaTabDi(DRAFT.suono); }catch(_){ }
  openEditor();
  if(type === 'wifi' || type === 'posizione') edEnsureLocation(type === 'posizione');
}
/* Indietro dall'editor: alla scheda Blocco, o alla pagina Bianco e nero se la bozza e' grigia. */
function edBack(){
  const grey = !!(window.BLK_GREY || (DRAFT && DRAFT.grey));
  const suono = !!(window.BLK_SOUND || (DRAFT && DRAFT.sound));
  window.BLK_GREY = false; window.BLK_SOUND = false;
  if (suono && typeof suoProgApri === 'function'){ suoProgApri(); return; }
  /* 0.9.291, Andrea: "dopo Cambio le regole, tornando indietro finisco in Dream invece che in Proteggi i tuoi sogni".
     Indietro torna dove eri (nav.js), non alla casa. */
  if (grey && typeof grOpen === 'function') grOpen(); else if (typeof flIndietro === 'function') flIndietro(); else goId('s-home');
}
function editProgram(i){
  window.BLK_GREY = false;
  DRAFT = JSON.parse(JSON.stringify(PROGRAMS[i]));
  DRAFT.idx = i;
  if(!Array.isArray(DRAFT.days) || DRAFT.days.length !== 7) DRAFT.days = [true,true,true,true,true,true,true];
  openEditor();
}
function openEditor(){
  document.getElementById('edIcon').textContent = DRAFT.icon || '🕑';
  document.getElementById('edName').value = DRAFT.name || '';
  const edR = document.getElementById('edRedirect'); if (edR) edR.value = DRAFT.redirectUrl || '';
  const edS = document.getElementById('edStopNote'); if (edS) edS.value = DRAFT.stopNote || '';
  /* 0.9.283: la schermata di blocco del programma si carica quando si apre la sua pagina (lockcustom.js) */
  DRAFT.schermata = null;
  try{ if (typeof settingsLoad === 'function') settingsLoad().then(function(){ if (typeof plkRigaPaint === 'function' && DRAFT && !DRAFT.schermata){ DRAFT.schermata = (typeof lcProgDi === 'function') ? lcProgDi(DRAFT.id) : null; plkRigaPaint(); } }); }catch(_){ }
  edPaintCondition();
  document.getElementById('edFrom').value = DRAFT.from || '22:00';
  document.getElementById('edTo').value = DRAFT.to || '08:00';
  blkPaintTimeLabels();
  document.getElementById('edQh').value = DRAFT.qh || '';
  document.getElementById('edQd').value = DRAFT.qd || '';

  paintModeRow('draft');
  paintWhatLabel();
  renderExtraOptions('edExtra');
  refreshEditorCounts();
  try{ if (typeof sndEditorMode === 'function') sndEditorMode(!!DRAFT.sound); }catch(e){ try{ console.warn('sndEditorMode', e); }catch(_){ } }
  /* 0.9.313, Andrea: "Crea" su un programma che esiste gia' non ha senso */
  const nuovo = !(DRAFT.idx >= 0);
  const edSalva = document.getElementById('edSalva');
  if (edSalva) edSalva.textContent = nuovo ? 'Crea' : 'Salva';
  goId('s-editor');
  /* 0.9.402 BUG-233, Andrea: "nel Nuovo programma non compare nessun pulsante per salvare: il programma non si puo' creare". Due cause:
     nei suoni sndEditorMode nascondeva tutto fino al primo button.cta, ma dal 0.9.382 il pulsante sta dentro alla fascia .ed-piede (un div),
     e la fascia spariva con il resto; e il Salva comune (registry.js) resta nascosto finche' non cambi qualcosa. Una pagina che crea
     qualcosa ha SEMPRE il suo Crea (regola 333): il programma nuovo conta come gia' modificato */
  if (nuovo) blkCreaVisibile();
}
function blkCreaVisibile(){
  try{
    if (typeof FL_SALVA === 'undefined' || typeof flSalvaApplica !== 'function') return;
    FL_SALVA.sporca['s-editor'] = true; flSalvaApplica('s-editor');
    setTimeout(function(){ if (DRAFT && !(DRAFT.idx >= 0)){ FL_SALVA.sporca['s-editor'] = true; flSalvaApplica('s-editor'); } }, 160);
  }catch(_){ }
}
/* tornando dalla lista delle app (o da un'altra sottopagina) a un programma nuovo, il Crea resta */
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-editor' && typeof DRAFT !== 'undefined' && DRAFT && !(DRAFT.idx >= 0)) blkCreaVisibile(); });

/* Everything the chosen condition decides on this screen, in one place, so changing the
   condition later repaints exactly what creating it painted. */
function edPaintCondition(){
  if(!DRAFT) return;
  if(!Array.isArray(DRAFT.wifi)) DRAFT.wifi = [];
  if(!Array.isArray(DRAFT.places)) DRAFT.places = [];
  const t = DRAFT.type;
  const ico = document.getElementById('edIcon'); if(ico) ico.textContent = DRAFT.icon || BLK_TYPE_ICON[t] || '🕑';
  const ci = document.getElementById('edCondIco'); if(ci) ci.textContent = BLK_TYPE_ICON[t] || '🕑';
  const nm = document.getElementById('edName');
  /* 0.9.402 BUG-236: un programma di suoni non e' una "notte pulita" */
  if(nm) nm.placeholder = DRAFT.sound
    ? ({app:'Es. Scrivere con la pioggia', abitudine:'Es. Posa il telefono', wifi:'Es. In ufficio', posizione:'Es. In biblioteca', combo:'Es. Studio in biblioteca'}[t] || 'Es. Pioggia per studiare')
    : ({limite:'Es. Social a piccole dosi', sempre:'Es. Mai più', wifi:'Es. In ufficio',
     posizione:'Es. In palestra', combo:'Es. Studio in biblioteca'}[t] || 'Es. Notte pulita');
  const lbl = document.getElementById('edCondLbl'); if(lbl) lbl.textContent = BLK_TYPE_NAME[t] || 'Ora';
  const body = document.getElementById('edCondBody'); if(body) body.textContent = BLK_TYPE_DESC[t] || '';
  paintEditorSchedule();
}

/* The condition picker, reachable from the editor at any time. Nothing else in the draft is
   touched: the name, the lists and the schedule survive the change, which is the whole point
   of being able to change it at all. */
function edOpenTypeSheet(){
  if(!DRAFT) return;
  const body = document.getElementById('blkTypeSheetBody');
  const sheet = document.getElementById('blkTypeSheet');
  if(!body || !sheet) return;
  body.innerHTML = '<div class="blk-sheet-title">Condizione del programma</div>'
    + blkTipiDisponibili().map(function(t){
        return '<button type="button" class="blk-typerow' + (t.k === DRAFT.type ? ' sel' : '') + '"'
          + ' onclick="edPickType(\'' + t.k + '\')"><span class="ti">' + t.ico + '</span>'
          + '<span class="tt"><b>' + blkEsc(t.name) + '</b><small>' + blkEsc(t.desc) + '</small></span>'
          + '<span class="tk">' + (t.k === DRAFT.type ? '✓' : '') + '</span></button>';
      }).join('');
  sheet.classList.add('open');
}
function edCloseTypeSheet(){
  const sheet = document.getElementById('blkTypeSheet');
  if(sheet) sheet.classList.remove('open');
}
async function edPickType(k){
  edCloseTypeSheet();
  if(!DRAFT || !BLK_TYPE_NAME[k] || k === DRAFT.type) return;
  const old = DRAFT.type;
  // A hand-picked emoji is the user's; the default one belongs to the condition and follows it.
  if(!DRAFT.icon || DRAFT.icon === BLK_TYPE_ICON[old]) DRAFT.icon = BLK_TYPE_ICON[k];
  DRAFT.type = k;
  if(k === 'combo' && !DRAFT.useTime && !DRAFT.useWifi && !DRAFT.usePlace) DRAFT.useTime = true;
  /* 0.9.402: nei suoni "Vale tutto il giorno" non c'e' (l'Ora chiede solo da che ora a che ora): passando all'Ora la fascia oraria si vede */
  if(DRAFT.sound && (k === 'ora' || k === 'combo')) DRAFT.allDay = false;
  edPaintCondition();
  try{ if (DRAFT.sound && typeof sndEditorMode === 'function') sndEditorMode(true); }catch(_){ }
  toast('Condizione: ' + BLK_TYPE_NAME[k]);
  if(k === 'wifi' || k === 'posizione') edEnsureLocation(k === 'posizione');
}

/* =========================== IL PANNELLO DELLA COSTANZA ===========================
 * Il "First step taken" di Opal, con la striscia di giorni.
 *
 * Compare solo quando qualcosa sta davvero bloccando: almeno un programma acceso con delle
 * regole vive, oppure il Blocco rapido avviato con almeno una voce in elenco. Se l'utente
 * cancella o mette in pausa tutto — cioè se smonta la protezione per aggirarla — il pannello
 * sparisce e la striscia riparte da zero. È l'unica cosa che gli dà valore: non è una
 * decorazione, è la prova che oggi le regole hanno tenuto.
 */
let BLK_QUICK_KNOWN = false;   // il Blocco rapido è stato letto dal motore almeno una volta
function blkProtectionUp(){
  const anyProgram = (PROGRAMS || []).some(function(p){ return p.on !== false && blkHasTargets(p); });
  return anyProgram || (!!EXTRA.enabled && quickHasTargets());
}
function blkToday(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}
function blkDaysBetween(a, b){
  const pa = a.split('-').map(Number), pb = b.split('-').map(Number);
  const da = Date.UTC(pa[0], pa[1]-1, pa[2]), db = Date.UTC(pb[0], pb[1]-1, pb[2]);
  return Math.round((db - da) / 86400000);
}
/* Legge, aggiorna e riscrive la striscia. Un giorno saltato la spezza: non si può sommare
   ieri con la settimana scorsa e chiamarla costanza. */
function blkStreak(up){
  let st = { days:0, last:'' };
  try{ st = JSON.parse(localStorage.getItem('fl_streak') || 'null') || st; }catch(_){ }
  const today = blkToday();
  if(!up){
    if(st.days !== 0){ st = { days:0, last:'' }; try{ localStorage.setItem('fl_streak', JSON.stringify(st)); }catch(_){ } }
    return 0;
  }
  if(st.last === today) return st.days || 1;
  const gap = st.last ? blkDaysBetween(st.last, today) : 999;
  st.days = (gap === 1 ? (st.days || 0) + 1 : 1);
  st.last = today;
  try{ localStorage.setItem('fl_streak', JSON.stringify(st)); }catch(_){ }
  return st.days;
}
/* LE FRASI DELLA SERIE. Corte come quelle dell'app di riferimento: un titolo di due o tre
   parole, poi una o due frasi brevi che si leggono in tre secondi. Si dice sempre «Modalità
   severa» per esteso: «la severa» da sola non vuol dire niente per chi legge. Un complimento
   chiaro, mai una frase che si puo' scambiare per una critica. La chiusa in grassetto (f) c'e'
   solo in pochi giorni, dove una riga deve restare addosso. L'elevazione («stai diventando
   un'altra persona») compare una volta ogni tanto e sempre DOPO un fatto, mai nella forma
   «non è X, è Y» (Brain, regole anti-AI). */
const BLK_PIETRE = {
  1:   { t: 'Primo passo fatto',    p: 'Hai acceso la Modalità severa. La parte difficile era questa.', f: 'Il tuo io futuro ti sta già ringraziando.' },
  2:   { t: 'Secondo giorno',       p: 'Ieri poteva essere un caso. Oggi no.' },
  3:   { t: 'Sta prendendo ritmo',  p: 'Tre giorni di Modalità severa. Da qui comincia il cambiamento.' },
  5:   { t: 'Cinque giorni',        p: 'Una settimana di lavoro intera con le regole accese. Tienile così.' },
  7:   { t: 'Una settimana intera', p: 'Sette giorni di Modalità severa. Un’abitudine sta nascendo.' },
  10:  { t: 'Doppia cifra',         p: 'Dieci giorni. Non stai più provando. Stai diventando un’altra persona.' },
  14:  { t: 'In pieno ritmo',       p: 'Due settimane piene di costanza. La disciplina comincia a venirti naturale.' },
  21:  { t: 'Tre settimane',        p: 'Ventun giorni. Il tempo che serve a un’abitudine per non chiedere più permesso.' },
  /* 0.9.292, Andrea: "dopo un mese, come Opal: A new normal. One month of focus. The dedication you show is amazing." */
  30:  { t: 'Un nuovo normale',     p: 'Un mese di concentrazione. La dedizione che dimostri è straordinaria.' },
  50:  { t: 'Cinquanta giorni',     p: 'Sette settimane di fila. Chi ti sta vicino se n’è accorto.' },
  60:  { t: 'Due mesi',             p: 'Sessanta giorni. Le cose che rimandavi hanno una data.' },
  90:  { t: 'Tre mesi',             p: 'Un trimestre intero di Modalità severa. Questa è disciplina vera.' },
  100: { t: 'Cento giorni',         p: 'Tre cifre. Pochissimi arrivano fin qui.', f: 'Tu sì.' },
  180: { t: 'Sei mesi',             p: 'Mezzo anno con le regole accese. Rileggi cosa scrivevi il primo giorno.' },
  200: { t: 'Duecento giorni',      p: 'Duecento. La mattina il telefono non decide più niente per te.' },
  270: { t: 'Nove mesi',            p: 'Nove mesi. Il tempo che serve per far nascere qualcosa.' },
  365: { t: 'Un anno intero',       p: 'Trecentosessantacinque giorni di Modalità severa.', f: 'Sei un’altra persona.' }
};

/* Le altre giornate: [frase, chiusa in grassetto o '']. Una frase sola, breve. La sceglie il
   numero del giorno, quindi due giorni vicini non leggono mai la stessa cosa, e riaprendo
   l'app oggi si ritrova quella di stamattina. 0.9.263, Andrea: piu' spinta, mai il numero. */
const BLK_FRASI = {
  corta: [
    ['Le regole hanno tenuto anche oggi. Tu pure.', ''],
    ['Oggi il telefono ha chiesto. Hai detto di no.', ''],
    ['Un altro giorno vinto contro il vecchio te.', ''],
    ['Il primo impulso è arrivato e l’hai lasciato passare.', ''],
    ['Ancora qui. È esattamente quello che conta.', ''],
    ['Ogni giorno così rende il prossimo un po’ più facile.', '']
  ],
  media: [
    ['Stai costruendo un ritmo. Non regalarlo a una sera storta.', ''],
    ['Quello che all’inizio costava fatica adesso ti viene da solo.', ''],
    ['Le giornate così non fanno rumore. Si sommano, e un giorno si vedono.', ''],
    ['La serie ha un peso, adesso.', 'Proteggila.'],
    ['Il tuo io futuro sta prendendo forma, un giorno alla volta.', ''],
    ['Le scuse ci sono ancora. Tu non le ascolti più.', '']
  ],
  lunga: [
    ['La persona che eri avrebbe già mollato.', 'Tu sei ancora qui.'],
    ['Decidi tu le tue giornate, non la prossima notifica.', ''],
    ['Nessuna scorciatoia ti avrebbe portato fin qui. Solo i giorni.', ''],
    ['Ogni sera con le regole accese è un voto per chi stai diventando.', ''],
    ['Quello che per gli altri è forza di volontà, per te ormai è un’abitudine.', ''],
    ['Hai smesso di trattare con te stesso. Si vede.', '']
  ]
};

/* I TITOLI DELLA SERIE (0.9.265, Andrea). Call of Duty era solo lo spunto: ogni 5 giorni un TITOLO di una parola
   sola che dice il traguardo raggiunto (niente "Nucleare" o "Spietato": parole che parlano di costanza e di
   concentrazione). Negli altri giorni il titolo cambia ogni giorno: un incoraggiamento o un complimento sul
   percorso ("Primo passo fatto"), e alle tappe settimanali e mensili una frase come quelle di Opal ("Due settimane
   piene di costanza: la disciplina comincia a venirti naturale"). Sotto, una riga breve che spinge. */
const BLK_RANGHI = {
  5:   ['Costante',      'Cinque giorni senza cedere. La costanza è cominciata qui.'],
  10:  ['Determinato',   'Dieci giorni e le regole non si sono piegate una volta. Neanche tu.'],
  15:  ['Concentrato',   'Sei pericoloso quando sei concentrato. E da quindici giorni lo sei.'],
  20:  ['Disciplinato',  'Venti giorni. Quello che prima ti costava fatica adesso lo fai e basta.'],
  25:  ['Tenace',        'Le tentazioni bussano ancora. Tu non apri più.'],
  30:  ['Inarrestabile', 'Un mese intero. A questo punto fermarti costerebbe più fatica che continuare.'],
  35:  ['Lucido',        'Le tue giornate le decide la tua testa, non la prossima notifica.'],
  40:  ['Instancabile',  'Quaranta giorni. Chi ti sta vicino se n’è accorto, anche se non te l’ha detto.'],
  45:  ['Saldo',         'Le giornate storte arrivano anche a te. Non ti spostano più.'],
  50:  ['Incrollabile',  'Cinquanta giorni di fila. Pochissimi arrivano fin qui.'],
  60:  ['Padrone',       'Due mesi. Il tuo tempo adesso lo comandi tu.'],
  75:  ['Esemplare',     'La versione di te che mollava non abita più qui.'],
  90:  ['Inscalfibile',  'Tre mesi. Questa ormai non è forza di volontà. È chi sei.'],
  100: ['Leggendario',   'Cento giorni. Tre cifre di costanza.'],
  150: ['Fuoriclasse',   'La concentrazione per te è diventata normale. Per gli altri è un superpotere.'],
  200: ['Visionario',    'Duecento giorni dietro al tuo sogno. Il futuro che vedevi adesso si vede.'],
  365: ['Leggenda',      'Un anno intero con le regole accese. Rileggi chi eri il primo giorno.']
};
/* il titolo di ogni giorno che non e' un traguardo: un incoraggiamento, un complimento */
const BLK_TITOLI_GIORNO = ['Giorno vinto', 'Ancora in piedi', 'Ritmo tenuto', 'Un altro sì a te', 'Nessuna scusa',
  'Testa sul sogno', 'Passo dopo passo', 'Mente lucida', 'Più forte di ieri', 'Sulla tua rotta'];
function blkRango(n){
  let r = null;
  Object.keys(BLK_RANGHI).forEach(function(k){ if (n >= +k) r = { da: +k, t: BLK_RANGHI[k][0], p: BLK_RANGHI[k][1] }; });
  return r;
}
/* compatibilita': chi chiedeva la medaglia trova il rango */
function blkMedaglia(n){ const r = blkRango(n); return r ? { da: r.da, nome: r.t, p: r.p, f: '' } : { da: 1, nome: 'Primo passo fatto', p: '', f: '' }; }

/** La chiusa in grassetto, gia' pronta per finire in un <p>. */
function blkForte(c){
  return (c && c.f) ? ' <strong>' + blkEsc(c.f) + '</strong>' : '';
}

function blkStreakCopy(n){
  n = Math.max(1, n || 0);
  /* ogni 5 giorni: il titolo di una parola, il giorno in cui si sblocca scoppia */
  if (n % 5 === 0){
    const r = BLK_RANGHI[n] ? { t: BLK_RANGHI[n][0], p: BLK_RANGHI[n][1], nuovo: true } : null;
    if (r) return { t: r.t, p: r.p, f: '', nuova: true };
    const g0 = n < 30 ? BLK_FRASI.media : BLK_FRASI.lunga;
    const v0 = g0[(n / 5) % g0.length];
    const rr = blkRango(n);
    return { t: rr ? rr.t : 'Costante', p: v0[0], f: v0[1] };
  }
  /* le tappe (primo giorno, una settimana, due settimane...): la loro frase */
  if (BLK_PIETRE[n]) return { t: BLK_PIETRE[n].t, p: BLK_PIETRE[n].p, f: BLK_PIETRE[n].f || '' };
  /* gli altri giorni: un titolo nuovo ogni giorno e una riga che spinge */
  const gruppo = n < 7 ? BLK_FRASI.corta : (n < 30 ? BLK_FRASI.media : BLK_FRASI.lunga);
  const v = gruppo[n % gruppo.length];
  return { t: BLK_TITOLI_GIORNO[n % BLK_TITOLI_GIORNO.length], p: v[0], f: v[1] };
}
/** Il giorno della medaglia nuova il titolo scoppia una volta sola (poi resta fermo). */
function blkMedagliaClasse(n, c){
  if (!c || !c.nuova) return '';
  let vista = 0; try{ vista = +localStorage.getItem('fl_sev_medaglia_vista') || 0; }catch(_){ }
  if (vista >= n) return '';
  try{ localStorage.setItem('fl_sev_medaglia_vista', String(n)); }catch(_){ }
  return ' medaglia-nuova';
}
function blkStreakHtml(n){
  const c = blkStreakCopy(n);
  return '<div class="blk-streak' + blkMedagliaClasse(n, c) + '" id="blkStreak">'
    + '<div class="txt"><b>' + blkEsc(c.t) + '</b><p>' + blkEsc(c.p) + blkForte(c) + '</p></div>'
    + '<div class="flame">🔥<span>' + n + '</span></div>'
    + '</div>';
}
/* Va sotto la prima card dei programmi; se programmi non ce ne sono, sotto il Blocco rapido. */
function blkPaintStreak(){
  const tab = document.getElementById('tab-blocco');
  if(!tab) return;
  const old = document.getElementById('blkStreak');
  if(old) old.remove();
  const up = blkProtectionUp();
  // Finché non sappiamo che cosa contiene il Blocco rapido, "niente sta bloccando" è solo
  // ignoranza, non un fatto: azzerare la striscia qui la cancellerebbe a ogni avvio a chi usa
  // soltanto il Blocco rapido.
  if(!up && !BLK_QUICK_KNOWN) return;
  // The streak is still kept up to date from here; the panel itself now lives in the
  // Profile (with the phrase of the day) and in Modalità severa (with the fire).
  blkStreak(up);
}

/* Counters and chips: a number alone never told the user WHAT was in the list (G04). */
function refreshEditorCounts(){
  if(!DRAFT) return;
  const a = document.getElementById('edAppCount'), w = document.getElementById('edWebCount'), k = document.getElementById('edKwCount');
  if(a) a.textContent = (DRAFT.apps || []).length;
  if(w) w.textContent = (DRAFT.sites || []).length;
  if(k) k.textContent = (DRAFT.keywords || []).length;
}
function paintChips(id, arr){
  const box = document.getElementById(id);
  if(!box) return;
  const max = 6;
  box.innerHTML = arr.slice(0,max).map(function(v){
    const label = (v && v.t) ? v.t : v;
    // a domain gets its own favicon; an app or a keyword keeps the dot
    const lead = flFavHost(label) ? flFavHtml(label) : '<i>•</i>';
    return '<span class="blk-chip">' + lead + blkEsc(shortLabel(label)) + '</span>';
  }).join('') + (arr.length > max ? '<span class="blk-chip more">+' + (arr.length - max) + '</span>' : '');
}
/* A package name is unreadable at chip size — but its LAST segment names the wrong thing:
   com.instagram.android is not "android". The app's real label wins whenever the installed
   list has been read; otherwise the most telling segment does, skipping the generic tails
   every vendor appends. Domains and keywords fall through untouched. */
const SHORT_GENERIC = { android:1, app:1, apps:1, mobile:1, client:1, main:1, ui:1,
                        free:1, lite:1, pro:1, beta:1, plus:1 };
function shortLabel(v){
  const s = String(v == null ? '' : v);
  if(!s || s.indexOf(' ') >= 0) return s;
  // ubAppLabel only answers for a string that IS an installed package, so a domain is safe here.
  if(typeof ubAppLabel === 'function'){
    const l = ubAppLabel(s);
    if(l && l !== s) return l;
  }
  if(s.indexOf('com.') === 0 && s.split('.').length > 2){
    const parts = s.split('.').slice(1).filter(Boolean);
    for(let i = parts.length - 1; i >= 0; i--){
      if(!SHORT_GENERIC[parts[i].toLowerCase()]) return parts[i];
    }
  }
  return s;
}

async function saveBlock(){
  if(!DRAFT) return;
  DRAFT.name = document.getElementById('edName').value.trim() || 'Programma senza nome';
  const edR2 = document.getElementById('edRedirect'); DRAFT.redirectUrl = edR2 ? edR2.value.trim() : '';
  const edS2 = document.getElementById('edStopNote'); DRAFT.stopNote = edS2 ? edS2.value.trim() : '';
  DRAFT.from = document.getElementById('edFrom').value;
  DRAFT.to   = document.getElementById('edTo').value;
  DRAFT.qh   = parseInt(document.getElementById('edQh').value,10) || null;
  DRAFT.qd   = parseInt(document.getElementById('edQd').value,10) || null;

  if(DRAFT.sound && DRAFT.type === 'app' && !DRAFT.apps.length && !DRAFT.sites.length && !(DRAFT.keywords || []).length){
    toast('Scegli almeno un\'app, un sito o una parola');
    return;
  }
  /* 0.9.402 BUG-236: un programma di suoni finisce sempre con la scelta del suono; quello dell'abitudine anche con l'abitudine */
  if(DRAFT.sound && DRAFT.type === 'abitudine' && !DRAFT.hab){ toast('Scegli quale abitudine fa partire il suono'); return; }
  if(DRAFT.sound && !DRAFT.shuffle && !DRAFT.suono){ toast('Scegli quale suono deve partire'); return; }
  if(!DRAFT.sound && !DRAFT.apps.length && !DRAFT.sites.length && !DRAFT.keywords.length){
    const funz = (!DRAFT.grey && typeof ubFunzScelte === 'function') ? ubFunzScelte() : [];
    toast(funz.length ? 'Le funzioni che hai spuntato sono già bloccate. Per salvare il programma aggiungi un\'app, un sito o una parola'
                      : 'Aggiungi almeno un\'app, un sito o una parola');
    return;
  }
  const needLimit = DRAFT.type === 'limite' || (DRAFT.type === 'combo' && DRAFT.useLimit);
  if(needLimit && !DRAFT.qh && !DRAFT.qd){
    toast('Imposta un limite in minuti');
    return;
  }
  const needWifi = DRAFT.type === 'wifi' || (DRAFT.type === 'combo' && DRAFT.useWifi);
  const needPlace = DRAFT.type === 'posizione' || (DRAFT.type === 'combo' && DRAFT.usePlace);
  if(needWifi && !(DRAFT.wifi || []).length){ toast('Aggiungi almeno una rete Wi-Fi'); return; }
  if(needPlace && !(DRAFT.places || []).length){ toast('Aggiungi almeno un luogo'); return; }
  if(DRAFT.type === 'combo' && edComboCount() < 2){
    toast('Imposta almeno due condizioni'); return;
  }
  if(!DRAFT.id) DRAFT.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);

  const idx = DRAFT.idx;
  const clean = Object.assign({}, DRAFT);
  delete clean.idx;
  if (clean.sound && typeof sndSaveProgram === 'function'){
    sndSaveProgram(clean, idx);
    window.BLK_SOUND = false;
    toast(idx >= 0 ? 'Programma aggiornato' : 'Programma di suoni creato');
    if (typeof suoProgApri === 'function') suoProgApri(); else sndPaginaApri();
    return;
  }
  if (clean.grey && typeof grSaveProgram === 'function'){
    grSaveProgram(clean, idx);
    window.BLK_GREY = false;
    toast(idx >= 0 ? 'Programma aggiornato' : 'Programma in bianco e nero creato');
    grAfterProgramSave();
    return;
  }
  if (idx < 0 && blkEditLocked()) clean.grazia = Date.now() + BLK_GRAZIA_MS;
  /* 0.9.395: "Cambialo" apre il programma del tuo agente qui; salvandolo, le condizioni le hai decise tu: e' confermato */
  if (clean.daConfermare) clean.daConfermare = false;
  if(idx >= 0) PROGRAMS[idx] = clean; else PROGRAMS.push(clean);
  saveProgramsLocal();
  await pushRules();
  try{ if (clean.schermata && typeof lcSalvaProgramma === 'function') lcSalvaProgramma(clean.id, clean.schermata); }catch(_){ }
  renderPrograms();
  toast(idx >= 0 ? 'Programma aggiornato' : 'Programma creato');
  goId('s-home'); switchTab('blocco');
  // The natural transition the owner chose for advertising: work is done, nothing is
  // interrupted. The ads module decides on its own whether this one earns an ad.
  if(typeof adsMaybeInterstitial === 'function') adsMaybeInterstitial('program-saved');
}

/* ================= 10 · BLOCCO RAPIDO (G02) =================
 * "Inizia" with no list blocked nothing at all while the counter cheerfully read
 * "0 app · 0 siti": the most visible button in the app did nothing. The Quick Block now owns
 * its own lists in the engine (Rules.QuickBlock) and refuses to start empty. */

async function loadQuick(){
  if(!blkHasNative('getQuickBlock')) return;
  const q = await blkNative('getQuickBlock', {}, true);
  if(!q) return;
  QUICK = {
    enabled: !!q.enabled,
    apps: q.apps || [],
    sites: q.sites || [],
    keywords: q.keywords || [],
    bivio: !!q.bivio,
    rettifica: !!q.rettifica
  };
}
async function loadExtra(){
  if(!blkHasNative('getRulesFull')) return;
  const r = await blkNative('getRulesFull', {}, true);
  if(!r) return;
  EXTRA = {
    enabled: r.enabled !== false,
    listMode: r.listMode || 'blocklist',
    allowApps: r.allowApps || [],
    blockNewlyInstalled: !!r.blockNewlyInstalled,
    blockUnsupportedBrowsers: !!r.blockUnsupportedBrowsers,
    blockAdult: !!r.blockAdult,
    blockReinstalled: !!r.blockReinstalled,
    blockPurchases: !!r.blockPurchases,
    searchTyping: !!r.searchTyping,
    blockLaunch: r.blockLaunch !== false,
    blockNotifications: !!r.blockNotifications,
    // The engine-wide lists. They are what the first-install seed lands in, and until now no
    // screen read them: the base protection was real and had no window.
    sites: r.sites || [],
    keywords: r.keywords || []
  };
}

async function openQuick(){
  await loadQuick();
  await loadExtra();
  paintQuick();
  goId('s-quick');
}
function closeQuick(){ goId('s-home'); switchTab('blocco'); }

function paintQuick(){
  const allow = EXTRA.listMode === 'allowlist';
  const apps = allow ? EXTRA.allowApps : QUICK.apps;
  const set = function(id, v){ const e = document.getElementById(id); if(e) e.textContent = v; };
  set('qkNApps', apps.length);
  set('qkNSites', QUICK.sites.length);
  set('qkNKw', QUICK.keywords.length);
  paintChips('qkChipApps', (!allow && typeof ubFunzScelte === 'function') ? apps.concat(ubFunzScelte()) : apps);
  paintChips('qkChipSites', QUICK.sites);
  paintChips('qkChipKw', QUICK.keywords);
  paintModeRow('quick');
  renderExtraOptions('qkExtra');
}

async function saveQuick(){
  if(!NATIVE){ toast('Anteprima nel browser:\nnulla viene salvato nel motore'); goId('s-home'); return; }
  const apps = EXTRA.listMode === 'allowlist' ? EXTRA.allowApps : QUICK.apps;
  if(!apps.length && !QUICK.sites.length && !QUICK.keywords.length){
    toast('Scegli almeno un\'app, un sito o una parola');
    return;
  }
  /* The saved list has to inherit the master switch. Saving it as inert while the banner says
     "Protezione attiva" is exactly the lie this screen exists to remove: the engine only reads
     the quick lists when QuickBlock.enabled is true. */
  /* Only the master switch is re-read here. Calling loadExtra() would overwrite EXTRA with
     the engine's copy and throw away the very edits (allowApps, the extra flags) this save
     is about. */
  const cur = await blkNative('getRules', {}, true);
  QUICK.enabled = cur ? cur.enabled !== false : EXTRA.enabled;
  EXTRA.enabled = QUICK.enabled;

  const res = await blkNative('setQuickBlock', {
    enabled: QUICK.enabled, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords,
    bivio: !!QUICK.bivio, rettifica: !!QUICK.rettifica
  });
  if(res === null) return;

  /* In allowlist mode the app list is not the quick block's: the engine reads Rules.allowApps
     for it. Saving only the quick block here would let the screen show a list of authorised
     apps that the engine has never heard of. */
  if(EXTRA.listMode === 'allowlist'){
    const ok = await blkNative('setRulesFull', { allowApps: EXTRA.allowApps });
    if(ok === null) return;
  }
  toast('Blocco rapido salvato');
  closeQuick();
  syncNative();
}

/* Start / pause. The engine flag `enabled` is the master switch; the quick block has its own
   `enabled` inside QuickBlock, and both have to move together or the button lies. */
async function quickBlockToggle(force){
  if(!NATIVE){ toast('Disponibile solo nell\'app installata'); return; }

  /* Fermare il blocco rapido passa dal pannello della decisione. Accenderlo no: mettersi una
     regola addosso non ha bisogno di attrito, toglierla si'. */
  /* 0.9.287: con la Modalita' severa accesa il Blocco rapido non si ferma (prima il pannello faceva fermare lo stesso) */
  if(QUICK.enabled && blkEditLocked()){ toast('Modalità severa attiva:\nil Blocco rapido resta acceso finché non la spegni'); try{ flVibra(30); }catch(_){ } return; }
  if(QUICK.enabled && force !== true && typeof itQuickAsk === 'function'){ itQuickAsk(); return; }

  const svc = await blkNative('isServiceEnabled', {}, true);
  if(svc && !svc.enabled){
    toast('Prima attiva il servizio di blocco');
    if(typeof openPerm === 'function') openPerm('accessibility'); else goEngine();
    return;
  }

  await loadQuick();
  await loadExtra();
  const hasQuick = QUICK.apps.length || QUICK.sites.length || QUICK.keywords.length;
  const hasPrograms = PROGRAMS.some(function(p){ return p.on !== false; });
  const allowMode = EXTRA.listMode === 'allowlist';
  // An extra option IS something to block. With the adult classifier on, "choose what to
  // block first" was refusing to start a blocker that had plenty to do - the very toggle the
  // user had just switched on was being ignored by the button below it.
  const hasExtras = EXTRA.blockAdult || EXTRA.blockUnsupportedBrowsers
                 || EXTRA.blockNewlyInstalled || EXTRA.blockReinstalled || EXTRA.blockPurchases
                 || (EXTRA.sites || []).length || (EXTRA.keywords || []).length;

  if(!hasQuick && !hasPrograms && !allowMode && !hasExtras){
    // Starting here would switch on a blocker with nothing to block. Send them to the list.
    toast('Scegli prima cosa bloccare');
    await openQuick();
    return;
  }

  /* This button is the QUICK BLOCK's, and only its. It used to flip the engine's master
     switch as well, so pausing the quick block silently paused every programme: "blocco
     rapido in pausa" read, in the engine, as "nothing blocks anything". Now the quick block
     has its own on/off, and the master switch is only ever put back ON here. */
  const next = !QUICK.enabled;
  if(next && EXTRA.enabled === false){
    const okRules = await blkNative('setEnabled', { enabled: true });
    if(okRules === null) return;
    EXTRA.enabled = true;
  }
  if(blkHasNative('setQuickBlock')){
    const ok = await blkNative('setQuickBlock', {
      enabled: next, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords,
      bivio: !!QUICK.bivio, rettifica: !!QUICK.rettifica
    }, true);
    if(ok === null){ if(!next) toast('Modalità severa attiva:\nil Blocco rapido resta acceso'); return; }
    QUICK.enabled = next;
  }
  if(!next && typeof sevStreakBreak === 'function') sevStreakBreak('quick');
  if(next && typeof itRipresa === 'function') itRipresa('quick');
  paintQuickBlock(next);
  toast(next ? 'Blocco rapido attivo' : 'Blocco rapido in pausa:\ni programmi restano attivi');
  syncNative();
}
/* Quante regole ha il Blocco rapido: senza nessuna, avviato o no, non sta bloccando niente. */
function quickHasTargets(){
  if(EXTRA.listMode === 'allowlist') return (EXTRA.allowApps || []).length > 0;
  return (QUICK.apps || []).length > 0 || (QUICK.sites || []).length > 0 || (QUICK.keywords || []).length > 0;
}
function paintQuickBlock(on){
  BLK_QUICK_KNOWN = true;
  const card = document.querySelector('#tab-blocco .qb');
  const has = quickHasTargets();
  if(card){
    // Stesso codice colore delle card dei programmi: anello blu mentre blocca, rosso quando
    // ha delle regole ma è in pausa, niente anello quando non c'è ancora nulla da bloccare.
    card.classList.toggle('on', !!on && has);
    card.classList.toggle('off', !on && has);
  }
  const btn = document.getElementById('qbBtn');
  if(!btn) return;
  /* L'icona di stop e' un SVG, come nell'app di riferimento: un quadrato dentro un cerchio.
     Le emoji cambiano faccia da un telefono all'altro; un tracciato no. */
  btn.innerHTML = on
    ? '<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true"><circle cx="10" cy="10" r="8.6" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="6.6" y="6.6" width="6.8" height="6.8" rx="1.2" fill="currentColor"/></svg>STOP'
    : '▶ Inizia';
  btn.style.background = '';
  // AppBlock: "Inizia" is the blue call to action, "Stop" is grey and faded once the block
  // is running. The rings on the card keep saying whether anything is blocked.
  btn.classList.remove('paused');
  btn.classList.toggle('stop', !!on);
  blkPaintStreak();
}

/* ---- the quick block's own list screen ---- */
function openQuickList(which){
  QL_TAB = which;
  goId('s-qlist');
  qlTab(which);
}
function qlTab(which){
  QL_TAB = which;
  setTimeout(function(){ try{ qlCtaPaint(); }catch(_){ } }, 0);
  document.querySelectorAll('#s-qlist .bltab').forEach(function(b){ b.classList.toggle('on', b.dataset.ql === which); });
  ['app','web','kw'].forEach(function(k){
    const e = document.getElementById('ql-' + k);
    if(e) e.hidden = (k !== which);
  });
  const title = document.getElementById('qlTitle');
  if(title) title.textContent = EXTRA.listMode === 'allowlist' ? 'Elenco consentiti' : 'Lista di blocco';
  if(which === 'app') loadQlApps(); else renderQlSimple(which);
}
async function loadQlApps(){
  const box = document.getElementById('qlAppList');
  if(!box) return;
  if(!NATIVE){ box.innerHTML = '<div class="hintline" style="padding:14px">Elenco disponibile solo nell\'app installata.</div>'; return; }
  if(!QL_APPS.length){
    if(!(typeof FLA !== 'undefined' && FLA.list && FLA.list.length)) box.innerHTML = '<div class="hintline" style="padding:14px">Leggo le app installate…</div>';
    const r = await flApps().catch(function(){ return null; });
    QL_APPS = (r && r.apps) || [];
  }
  renderQlApps();
  if(typeof ubFunzRileggi === 'function') ubFunzRileggi(renderQlApps);
}
function qlAppTarget(){ return EXTRA.listMode === 'allowlist' ? EXTRA.allowApps : QUICK.apps; }
function renderQlApps(){
  const box = document.getElementById('qlAppList');
  if(!box) return;
  const q = ((document.getElementById('qlSearch') || {}).value || '').toLowerCase();
  /* Nell'elenco dei consentiti non si blocca niente: le funzioni non c'entrano */
  const conFunz = EXTRA.listMode !== 'allowlist';
  const list = QL_APPS.filter(function(a){ return ubAppCercata(a, q, conFunz); });
  const target = qlAppTarget();
  if(!list.length){ box.innerHTML = '<div class="hintline" style="padding:14px">Nessuna app trovata.</div>'; return; }
  box.innerHTML = ubPrimaLeScelte(list, target).map(function(a){ return ubRigaAppHtml(a, target.indexOf(a.packageName) >= 0, conFunz); }).join('');
  if (typeof ubLoadIcons === 'function') ubLoadIcons(box);
  box.querySelectorAll('input:not([data-funz])').forEach(function(i){
    i.addEventListener('change', function(){
      const arr = qlAppTarget();
      const at = arr.indexOf(i.value);
      if(i.checked){ if(at < 0) arr.push(i.value); }
      else if(at >= 0) arr.splice(at,1);
      ubFunzSegui(box, i.value, i.checked);
      paintQuick();
    });
  });
  ubFunzCollega(box, paintQuick);
}
function qlList(which){ return which === 'web' ? QUICK.sites : QUICK.keywords; }
/* The Quick Block's keyword list borrows the program editor's picker (blocklist.js) instead of
   owning a second, poorer copy of it: same three match types, same sheet, same wording. */
function qlModeSrc(){
  return {
    list: function(){ return QUICK.keywords; },
    normalize: function(){
      if(typeof ubNormalizeKeywordList === 'function') QUICK.keywords = ubNormalizeKeywordList(QUICK.keywords);
    },
    after: function(){ renderQlSimple('kw'); paintQuick(); try{ qlCtaPaint(); }catch(_){ } }
  };
}
function qlOpenMode(i){
  if(typeof ubOpenModeForList !== 'function'){ toast('Non disponibile in questa versione'); return; }
  ubOpenModeForList(i, qlModeSrc());
}
function qlModeLabel(m){
  if(typeof UB_MODES !== 'undefined' && UB_MODES[m]) return UB_MODES[m].label;
  return m === 'domain' ? 'Nel dominio' : m === 'content' ? 'Nel contenuto della pagina' : 'Ovunque nell\'URL';
}
function qlPaintKwMode(){
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const lbl = document.getElementById('qlKwModeLbl');
  if(lbl) lbl.textContent = qlModeLabel(m);
  const hint = document.getElementById('qlKwModeHint');
  if(hint && typeof UB_MODES !== 'undefined' && UB_MODES[m]) hint.textContent = UB_MODES[m].hint;
}
function renderQlSimple(which){
  const box = document.getElementById(which === 'web' ? 'qlWebList' : 'qlKwList');
  if(!box) return;
  if(which === 'kw') qlPaintKwMode();
  const arr = qlList(which);
  if(!arr.length){ box.innerHTML = '<div class="hintline" style="padding:14px">Ancora niente in elenco.</div>'; return; }
  box.innerHTML = arr.map(function(v,i){
    const term = (v && v.t) ? v.t : v;
    if(which === 'web'){
      return '<div class="pickrow">' + flFavHtml(term, 'big') + '<span class="pl">' + blkEsc(term) + '</span>' +
        '<button class="del" onclick="qlRemove(\'web\',' + i + ')">✕</button></div>';
    }
    const m = (v && v.m) ? v.m : 'url';
    return '<div class="pickrow ub-kwrow"><span class="pl">' + blkEsc(term) + '</span>' +
      '<button class="ub-modetag ub-m-' + m + '" onclick="qlOpenMode(' + i + ')">' + blkEsc(qlModeLabel(m)) + '<i class="ub-caret"></i></button>' +
      '<button class="del" onclick="qlRemove(\'kw\',' + i + ')">✕</button></div>';
  }).join('');
}
function qlAdd(which){
  const input = document.getElementById(which === 'web' ? 'qlWebIn' : 'qlKwIn');
  if(!input) return;
  const v = input.value.trim().toLowerCase();
  if(!v) return;
  const arr = qlList(which);
  if(which === 'web'){
    if(arr.indexOf(v) < 0) arr.push(v);
  }else{
    const mode = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
    if(arr.some(function(k){ return (k.t || k) === v && (k.m || 'url') === mode; })){
      toast('“' + v + '” è già in elenco come “' + qlModeLabel(mode) + '”');
    }else{
      const app = (typeof ubNewApp === 'function') ? ubNewApp() : mode === 'content';
      if (typeof UB_NEW_APP !== 'undefined') UB_NEW_APP = null;
      arr.push({ t:v, m:mode, a:app });
    }
  }
  input.value = '';
  renderQlSimple(which);
  paintQuick();
  try{ qlCtaPaint(); }catch(_){ }
}
function qlRemove(which, i){
  qlList(which).splice(i,1);
  renderQlSimple(which);
  paintQuick();
}

/* ================= 11 · BOTTOM SHEET "IMPOSTAZIONI" (G03) ================= */

function openBlockSettings(target){
  SET_TARGET = target || 'quick';
  const from = SET_TARGET === 'draft' && DRAFT
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications };
  if(SET_TARGET !== 'draft' && NATIVE) loadExtra().then(paintBlockSettings);
  paintSwitches(from);
  /* 0.9.373, Andrea: il motivo del blocco anche nelle impostazioni del programma (l'ingranaggio), non nelle Preferenze della schermata */
  const mr = document.getElementById('swMotivoRow'); if (mr) mr.hidden = false;
  const lr = document.getElementById('swLockRow'); if (lr){ lr.hidden = SET_TARGET !== 'draft'; try{ if (typeof plkRigaPaint === 'function') plkRigaPaint(); }catch(_){ } }
  const ms = document.getElementById('swMotivo'); if (ms) ms.className = 'switch' + (blkMotivoQui() ? ' on' : '');
  /* 0.9.400 BUG-169: le due scelte del bivio; quelle del Blocco rapido si rileggono dal motore (senza toccare le liste in modifica) */
  try{ blkScelteDipingi(); }catch(_){ }
  if (SET_TARGET !== 'draft' && blkHasNative('getQuickBlock')) blkNative('getQuickBlock', {}, true).then(function(q){ if (q){ QUICK.bivio = !!q.bivio; QUICK.rettifica = !!q.rettifica; } try{ blkScelteDipingi(); }catch(_){ } });
  const el = document.getElementById('blkSetSheet');
  if(el) el.classList.add('open');
}
function paintSwitches(v){
  const l = document.getElementById('swLaunch'), n = document.getElementById('swNotif');
  if(l) l.className = 'switch' + (v.launch ? ' on' : '');
  if(n) n.className = 'switch' + (v.notif ? ' on' : '');
}
function paintBlockSettings(){
  paintSwitches(SET_TARGET === 'draft' && DRAFT
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications });
}
async function toggleBlockSetting(which){
  const draft = SET_TARGET === 'draft' && DRAFT;
  const cur = draft
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications };
  const next = Object.assign({}, cur);
  next[which] = !cur[which];

  // AppBlock's own rule, and the engine's: with both off a program is armed and inert.
  if(!next.launch && !next.notif){ toast('Devi selezionare almeno un\'opzione.'); return; }

  if(draft){
    DRAFT.blockLaunch = next.launch;
    DRAFT.blockNotifications = next.notif;
    paintSwitches(next);
    paintWhatLabel();
    return;
  }
  EXTRA.blockLaunch = next.launch;
  EXTRA.blockNotifications = next.notif;
  paintSwitches(next);
  if(!NATIVE){ toast('Anteprima nel browser:\nl\'impostazione non viene salvata'); return; }
  const ok = await blkNative('setRulesFull', { blockLaunch: next.launch, blockNotifications: next.notif });
  if(ok === null){ await loadExtra(); paintBlockSettings(); }
}
function closeBlockSettings(){
  const el = document.getElementById('blkSetSheet');
  if(el) el.classList.remove('open');
}
function paintWhatLabel(){
  const e = document.getElementById('edWhatLbl');
  if(!e || !DRAFT) return;
  const bits = [];
  if(DRAFT.blockLaunch !== false) bits.push('Avvio');
  if(DRAFT.blockNotifications !== false) bits.push('Notifiche');
  e.textContent = bits.join(' · ') || '—';
}

/* ================= 12 · LISTA DI BLOCCO / ELENCO CONSENTITI (G01/G21) ================= */

function openModeSheet(target){
  MODE_TARGET = target || 'quick';
  paintModeSheet();
  const el = document.getElementById('blkModeSheet');
  if(el) el.classList.add('open');
}
function closeModeSheet(){
  const el = document.getElementById('blkModeSheet');
  if(el) el.classList.remove('open');
}
function paintModeSheet(){
  const b = document.getElementById('mcBlock'), a = document.getElementById('mcAllow');
  if(b) b.className = 'blk-modecard' + (EXTRA.listMode === 'blocklist' ? ' sel' : '');
  if(a) a.className = 'blk-modecard' + (EXTRA.listMode === 'allowlist' ? ' sel' : '');
}
async function pickListMode(mode){
  const prev = EXTRA.listMode;
  EXTRA.listMode = mode;
  paintModeSheet(); paintModeRow('quick'); paintModeRow('draft');
  if(NATIVE){
    const ok = await blkNative('setRulesFull', { listMode: mode });
    if(ok === null){ EXTRA.listMode = prev; paintModeSheet(); paintModeRow('quick'); paintModeRow('draft'); return; }
  }
  if(mode === 'allowlist' && !EXTRA.allowApps.length){
    toast('Scegli le app da autorizzare:\ntutte le altre saranno bloccate');
  }
  paintQuick();
}
function paintModeRow(where){
  const n = document.getElementById(where === 'draft' ? 'edModeName' : 'qkModeName');
  const d = document.getElementById(where === 'draft' ? 'edModeDesc' : 'qkModeDesc');
  const allow = EXTRA.listMode === 'allowlist';
  if(n) n.textContent = allow ? 'Elenco consentiti' : 'Lista di blocco';
  if(d) d.textContent = allow
    ? 'Seleziona app che desideri autorizzare. Tutte le altre saranno bloccate.'
    : 'Seleziona app, siti web e parole chiave che desideri bloccare.';
}

/* ================= 13 · OPZIONI EXTRA (G05-G08) =================
 * All four are already implemented in the engine (Rules.blockNewlyInstalled,
 * blockUnsupportedBrowsers, blockAdult, blockReinstalled). They were simply never exposed.
 * Each toggle saves immediately through setRulesFull: a screen that stores a promise until
 * some later "Salva" is a screen where a crash silently loses protection. */
const EXTRA_OPTS = [
  { k:'blockNewlyInstalled', i:'✨', t:'Aggiungi app appena installate',
    d:'Se attivato, le app installate da poco verranno automaticamente bloccate.' },
  { k:'blockUnsupportedBrowsers', i:'🧭', t:'Blocca browser non supportati',
    d:'Se i siti web non possono essere bloccati in un browser, viene invece bloccato il browser.' },
  { k:'blockAdult', i:'18+', t:'Blocco dei siti porno',
    d:'I siti porno vengono rilevati e bloccati automaticamente in tutti i tuoi browser.' },
  { k:'blockReinstalled', i:'♻️', t:'Blocca applicazioni reinstallate',
    d:'Conserveremo le applicazioni non installate tra i tuoi blocchi. Non potrai evitare il blocco durante la reinstallazione.' },
  { k:'blockPurchases', i:'💳', t:'Blocca acquisti in-app',
    d:'La finestra di pagamento di Google Play viene chiusa appena si apre, in qualsiasi app. Gli acquisti dentro DreamMap restano possibili.' }
];

/* 0.9.364, Andrea: "voglio un'impostazione nell'ingranaggio del Blocco rapido: mostra il motivo di ogni blocco, con una (i) accanto al
   titolo della schermata". Il nativo la legge da Rules.lockMotivo */
/* con la sua schermata personalizzata il programma ha il suo motivo (DRAFT.schermata.motivo), altrimenti vale quello di tutti */
function blkMotivoPropria(){ try{ return SET_TARGET === 'draft' && typeof DRAFT === 'object' && DRAFT && DRAFT.schermata && DRAFT.schermata.modo === 'propria'; }catch(_){ return false; } }
function blkMotivoQui(){ return blkMotivoPropria() ? DRAFT.schermata.motivo !== false : blkMotivoOn(); }
function blkMotivoCambia(b){
  const on = !b.classList.contains('on');
  if (blkMotivoPropria()){ DRAFT.schermata.motivo = on; try{ if (DRAFT.id && DRAFT.idx >= 0 && typeof lcSalvaProgramma === 'function') lcSalvaProgramma(DRAFT.id, DRAFT.schermata); }catch(_){ } }
  else blkMotivoSet(on);
  b.classList.toggle('on', on);
}
function blkMotivoOn(){ try{ return localStorage.getItem('fl_lock_motivo') === '1'; }catch(_){ return false; } }
function blkMotivoRigaHtml(){
  return '<div class="blk-opt"><span class="oi">🔍</span><div class="ot"><b>Mostra il motivo di ogni blocco</b><small>Sulla schermata di blocco compare una (i):<br>la tocchi e leggi la regola e la parola che l’hanno fatto scattare.</small></div>'
    + '<button class="switch' + (blkMotivoOn() ? ' on' : '') + '" onclick="blkMotivoSet(!this.classList.contains(\'on\'));this.classList.toggle(\'on\')"></button></div>';
}
async function blkMotivoSet(on){
  try{ localStorage.setItem('fl_lock_motivo', on ? '1' : '0'); }catch(_){ }
  try{ if (NATIVE && NATIVE.setSettings) await NATIVE.setSettings({ lockMotivo: !!on }); }catch(_){ }
}
function renderExtraOptions(containerId){
  // the search switch lives in the keyword tabs, not in the extra list
  document.querySelectorAll('#qlSearchSw,#kwSearchSw').forEach(function(sw){ sw.className = 'switch' + (EXTRA.searchTyping ? ' on' : ''); });
  const box = document.getElementById(containerId);
  if(!box) return;
  box.innerHTML = EXTRA_OPTS.map(function(o){
    return '<div class="blk-opt"><span class="oi">' + o.i + '</span>' +
      '<div class="ot"><b>' + blkEsc(o.t) + '</b><small>' + blkEsc(o.d) + '</small></div>' +
      '<button class="switch' + (EXTRA[o.k] ? ' on' : '') + '" onclick="toggleExtra(\'' + o.k + '\')"></button></div>';
  }).join('') + dnsRigaHtml();
  dnsAggiorna();
}

/* 0.9.275, Andrea: "il blocco dei siti porno dovrebbe essere piu' rigoroso, non solo i siti piu'
   noti, anche tramite impostazioni per bloccare a livello di DNS, e forzare la safe search su
   Google come fa Family Link". Il DNS privato di Android vale per tutto il telefono: ogni
   browser, ogni app, anche i siti che nessuna lista conosce. Due filtri gratuiti di CleanBrowsing:
   - porno + SafeSearch forzata su Google e Bing;
   - lo stesso, piu' YouTube in modalita' protetta e niente proxy o VPN per aggirarlo.
   Se il telefono ha il permesso di sistema (lo stesso del bianco e nero) DreamMap lo scrive da
   sola e lo rimette se qualcuno lo toglie dalle Impostazioni; se no apre la schermata con
   l'indirizzo gia' copiato. */
const DNS_SCELTE = [
  { h:'', t:'Spenta' },
  { h:'adult-filter-dns.cleanbrowsing.org', t:'Attiva' },
  { h:'family-filter-dns.cleanbrowsing.org', t:'Attiva, anche su YouTube' }
];
let DNS_STATO = null;
function dnsRigaHtml(){
  const v = DNS_STATO ? (DNS_STATO.voluto || '') : '';
  const att = DNS_STATO ? (DNS_STATO.attuale || '') : '';
  let nota = 'Forza la Ricerca sicura di Google e filtra i siti per adulti in ogni app.';
  if (DNS_STATO && v && att.toLowerCase() !== v.toLowerCase()) {
    nota = DNS_STATO.puoScrivere ? 'Lo sto rimettendo. Era stato cambiato nelle Impostazioni.'
      : 'Non ancora attivo. In "DNS privato" scegli "Nome host" e incolla l\'indirizzo. \u00e8 gi\u00e0 copiato.';
  } else if (DNS_STATO && v) {
    nota = 'Attivo su tutto il telefono. Si spegne solo da qui.';
  }
  return '<div class="blk-opt blk-dns"><span class="oi">\uD83D\uDEE1\uFE0F</span>' +
    '<div class="ot"><b>Ricerca sicura di Google</b><small class="dns-nota">' + blkEsc(nota) + '</small>' +
    '<div class="dns-scelte">' + DNS_SCELTE.map(function(o){
      return '<button class="dns-sc' + (o.h === v ? ' on' : '') + '" onclick="dnsScegli(\'' + o.h + '\')">' + blkEsc(o.t) + '</button>';
    }).join('') + '</div></div></div>';
}
async function dnsAggiorna(){
  if(!NATIVE || !NATIVE.dnsStato) return;
  try {
    const st = await NATIVE.dnsStato();
    const cambiato = JSON.stringify(st) !== JSON.stringify(DNS_STATO);
    DNS_STATO = st;
    if (cambiato) document.querySelectorAll('.blk-dns').forEach(function(el){ el.outerHTML = dnsRigaHtml(); });
  } catch(e){}
}
async function dnsScegli(h){
  if(!NATIVE || !NATIVE.dnsImposta){ toast('Disponibile sul telefono'); return; }
  /* spegnerlo con la modalita' severa accesa non si puo': e' proprio il momento in cui serve */
  if(!h && DNS_STATO && DNS_STATO.voluto){
    try { const st = await NATIVE.getStrictState(); if (st && st.level >= 1){ toast('Con la modalit\u00e0 severa accesa la protezione resta attiva'); return; } } catch(e){}
  }
  try {
    const r = await NATIVE.dnsImposta({ host: h });
    if (h && !r.scritto) toast('Indirizzo copiato:\nincollalo in "DNS privato", "Nome host"');
    else toast(h ? 'Protezione attiva in tutto il telefono' : 'Protezione spenta');
  } catch(e){ toast('Non sono riuscito a cambiarlo'); }
  DNS_STATO = null;
  dnsAggiorna();
}
document.addEventListener('visibilitychange', function(){ if(!document.hidden && document.querySelector('.blk-dns')) dnsAggiorna(); });
async function toggleExtra(key){
  const prev = !!EXTRA[key];
  EXTRA[key] = !prev;
  renderExtraOptions('qkExtra'); renderExtraOptions('edExtra'); renderExtraOptions('bpExtra');
  if(!NATIVE){
    toast('Anteprima nel browser:\nl\'opzione non viene salvata');
    return;
  }
  const payload = {}; payload[key] = EXTRA[key];
  const ok = await blkNative('setRulesFull', payload);
  if(ok === null){
    EXTRA[key] = prev;                       // the engine refused: the switch must go back
    renderExtraOptions('qkExtra'); renderExtraOptions('edExtra'); renderExtraOptions('bpExtra');
  }
}

/* ================= 14 · BANNER DI STATO =================
 * The single place that answers "is anything actually being blocked". isServiceRunning()
 * now separates "granted" from "alive": on MIUI and One UI the system kills accessibility
 * services, and until this banner said so the user believed they were protected.
 *
 * heartbeatAge === -1 means the service has never written a heartbeat at all. On a build
 * where FocusLockService does not write one yet that is every device, so it is reported as
 * "unverified" rather than "dead": crying wolf on every launch would teach the user to
 * ignore the banner on the one day it is right. */
/* How many rules the engine actually has to work with, across the quick block and every
   enabled program. The banner used to report "Protezione attiva" while this was zero: the
   service was granted, the master switch was on, and there was nothing whatsoever to match.
   Saying "protected" over an empty rule set is the worst lie this app can tell, because the
   user stops checking. */
/* The banner was always sending the user to the accessibility settings, whatever it said.
   When the problem is an empty rule set, that is the wrong room entirely. */
function svcBannerTap(){
  const b = document.getElementById('svcbanner');
  const state = b ? (b.dataset.state || 'perm') : 'perm';
  if(state === 'norules'){ openQuick(); return; }
  openPerm('accessibility');
}

function blkRuleCount(engine){
  let n = 0;
  try{
    if(engine){
      /* The engine's own snapshot. The local mirror lied here once already - the banner said
         "no rules" over a program the engine was happily enforcing in Chrome - so when a
         snapshot is available it is the only voice that counts. */
      n += (engine.apps||[]).length + (engine.sites||[]).length + (engine.keywords||[]).length;
      const q = engine.quick || {};
      n += (q.apps||[]).length + (q.sites||[]).length + (q.keywords||[]).length;
      (engine.schedules||[]).forEach(function(sc){
        if(sc && sc.enabled !== false){
          n += (sc.apps||[]).length + (sc.sites||[]).length + (sc.keywords||[]).length;
        }
      });
      if(engine.listMode === 'allowlist') n += 1;   // "block everything except" IS a rule
      if(engine.blockAdult) n += 1;                 // so is the adult classifier
      return n;
    }
    n += (QUICK.apps||[]).length + (QUICK.sites||[]).length + (QUICK.keywords||[]).length;
    (PROGRAMS||[]).forEach(function(p){
      if(p && p.on !== false){
        n += (p.apps||[]).length + (p.sites||[]).length + (p.keywords||[]).length;
      }
    });
  }catch(_){ }
  return n;
}

/* The protection nobody asked for, made visible.

   On a first install the engine seeds itself: ten adult domains into the GLOBAL site list and
   the adult classifier switched on. Both are real and both block - but the dashboard renders
   the quick block and the programmes, which are different containers, so it truthfully showed
   "0 app · 0 siti/parole" while sites were being blocked. From the outside that reads as an
   app possessed by rules the user never wrote, and the obvious wrong conclusion is the one
   that got reported: "it restored them from my Google account". There is no account and no
   backup; there was only a container with no window onto it. This is the window. */
/* The sheet behind "Vedi e modifica": the engine-wide sites, one by one, with the adult
   classifier toggle. Built with DOM calls so no handler string has to survive quoting.
   Removing a site goes through setRulesFull, where the strict-mode guard already refuses it
   while a session runs - the sheet does not need a lock of its own. */
function openBaseProtection(){
  let sw = document.getElementById('blkBaseSheet');
  if(!sw){
    sw = registerOverlay('blkBaseSheet', '<div class="blk-scrim"></div><div class="blk-sheet"><div class="grab"></div><h3>Protezione di base</h3><p class="blk-ssub">Siti bloccati per tutti, da subito. Puoi toglierne, aggiungerne, o spegnere il rilevamento.</p><div id="blkBaseAdult"></div><div class="addrow"><input class="fin" id="blkBaseIn" placeholder="aggiungi un dominio, es. sito.com" autocomplete="off" enterkeyhint="done"></div><div id="blkBaseList" class="picklist"></div><button class="cta" style="margin-top:12px" id="blkBaseClose">Fatto</button></div>');
    sw.className = 'blk-sw';
    sw.querySelector('.blk-scrim').addEventListener('click', closeBaseProtection);
    sw.querySelector('#blkBaseClose').addEventListener('click', closeBaseProtection);
    const input = sw.querySelector('#blkBaseIn');
    input.addEventListener('keydown', function(ev){
      if(ev.key !== 'Enter') return;
      ev.preventDefault();
      addBaseSite(input.value);
      input.value = '';
    });
  }
  paintBaseProtection();
  sw.classList.add('open');
}
function closeBaseProtection(){
  const sw = document.getElementById('blkBaseSheet');
  if(sw) sw.classList.remove('open');
}

function paintBaseProtection(){
  const adult = document.getElementById('blkBaseAdult');
  if(adult){
    adult.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'blk-opt';
    const ico = document.createElement('span'); ico.className = 'oi'; ico.textContent = '18+';
    const txt = document.createElement('div'); txt.className = 'ot';
    const b = document.createElement('b'); b.textContent = 'Rilevamento automatico dei siti porno';
    const sm = document.createElement('small'); sm.textContent = 'Riconosce i siti per adulti anche se non sono in questa lista.';
    txt.appendChild(b); txt.appendChild(sm);
    const sw = document.createElement('button');
    sw.className = 'switch' + (EXTRA.blockAdult ? ' on' : '');
    sw.addEventListener('click', async function(){
      await toggleExtra('blockAdult');
      await loadExtra();
      paintBaseProtection();
      renderBaseProtection();
    });
    row.appendChild(ico); row.appendChild(txt); row.appendChild(sw);
    adult.appendChild(row);
  }

  const list = document.getElementById('blkBaseList');
  if(!list) return;
  list.innerHTML = '';
  const sites = EXTRA.sites || [];
  if(!sites.length){
    const e = document.createElement('div');
    e.className = 'hintline';
    e.style.padding = '14px';
    e.textContent = 'Nessun sito nella protezione di base.';
    list.appendChild(e);
    return;
  }
  sites.forEach(function(site){
    const r = document.createElement('div');
    r.className = 'pickrow ub-kwrow';
    const name = document.createElement('span');
    name.className = 'pl';
    name.textContent = site;
    const del = document.createElement('button');
    del.className = 'del';
    del.setAttribute('aria-label', 'Togli ' + site);
    del.textContent = '\u2715';
    del.addEventListener('click', function(){ removeBaseSite(site); });
    r.appendChild(name); r.appendChild(del);
    list.appendChild(r);
  });
}

async function addBaseSite(raw){
  const site = String(raw || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if(!site || site.indexOf('.') < 0){ toast('Scrivi un dominio, es. sito.com'); return; }
  const next = (EXTRA.sites || []).slice();
  if(next.indexOf(site) >= 0){ toast('Gia\u0300 presente'); return; }
  next.push(site);
  const ok = await blkNative('setRulesFull', { sites: next });
  if(ok === null) return;                      // the engine already said why
  await loadExtra();
  paintBaseProtection();
  renderBaseProtection();
  refreshServiceBanner();
}

async function removeBaseSite(site){
  const next = (EXTRA.sites || []).filter(function(x){ return x !== site; });
  const ok = await blkNative('setRulesFull', { sites: next });
  if(ok === null) return;                      // strict mode refuses removals; message shown
  await loadExtra();
  paintBaseProtection();
  renderBaseProtection();
  refreshServiceBanner();
}

/* Retired. The card explained a seed the engine no longer plants, and it was being appended
   once per call - the home tab showed it twice. Any copy still in the DOM is removed here so
   an upgraded install does not keep a ghost of it. */
async function renderBaseProtection(){
  document.querySelectorAll('#blkBaseProt, .blk-base').forEach(function(el){ el.remove(); });
  return;
  const host = document.getElementById('tab-blocco');
  if(!host) return;

  let row = document.getElementById('blkBaseProt');
  const engine = NATIVE ? await blkNative('getRulesFull', {}, true) : null;
  const sites = engine && engine.sites ? engine.sites.length : 0;
  const kws = engine && engine.keywords ? engine.keywords.length : 0;
  const adult = !!(engine && engine.blockAdult);

  if(!sites && !kws && !adult){
    if(row) row.hidden = true;
    return;
  }

  if(!row){
    row = document.createElement('div');
    row.id = 'blkBaseProt';
    row.className = 'blk-base';
    // The quick-block card carries no id in the frozen markup, so it is found by class.
    const anchorEl = host.querySelector('.qb') || host.firstElementChild;
    if(anchorEl && anchorEl.parentNode) anchorEl.parentNode.insertBefore(row, anchorEl.nextSibling);
    else host.appendChild(row);
  }

  const bits = [];
  if(sites) bits.push(sites + (sites === 1 ? ' sito' : ' siti'));
  if(kws) bits.push(kws + (kws === 1 ? ' parola' : ' parole'));
  if(adult) bits.push('rilevamento automatico');

  row.hidden = false;
  row.innerHTML =
    '<div class="blk-base-h"><b>Protezione di base</b><span>' + blkEsc(bits.join(' · ')) + '</span></div>'
    + '<p>Attiva dalla prima installazione, indipendente dai programmi e dal Blocco rapido. '
    + 'È il motivo per cui alcuni siti risultano bloccati anche senza un programma tuo.</p>'
    + '<button class="blk-quicklink" id="blkBaseOpen">Vedi e modifica<span class="chev"></span></button>';

  const btn = document.getElementById('blkBaseOpen');
  if(btn) btn.addEventListener('click', openBaseProtection);
}

async function refreshServiceBanner(){
  const b = document.getElementById('svcbanner');
  if(!b) return;
  const ic = document.getElementById('svcbanner-ic');
  const tx = document.getElementById('svcbanner-txt');
  const bt = document.getElementById('svcbanner-btn');
  const qc = document.getElementById('qbCount');
  const say = function(cls, icon, text, btn, state){
    b.hidden = false;
    b.dataset.state = state || 'perm';
    b.className = 'svcbar' + (cls ? ' ' + cls : '');
    if(ic) ic.textContent = icon;
    if(tx) tx.textContent = text;
    if(bt){ bt.textContent = btn || 'Abilita'; bt.hidden = !btn; }
  };

  if(!NATIVE){
    b.hidden = true;        // the preview strip was one more banner above the quick block
    if(qc) qc.textContent = '0 app · 0 siti/parole';
    return;
  }

  await loadQuick();
  await loadExtra();

  const allow = EXTRA.listMode === 'allowlist';
  const nApps = allow ? EXTRA.allowApps.length : QUICK.apps.length;
  const nWeb  = QUICK.sites.length + QUICK.keywords.length;
  if(qc) qc.textContent = nApps + (allow ? ' app permesse' : ' app') + ' · ' + nWeb + ' siti/parole';

  let svc = await blkNative('isServiceRunning', {}, true);
  if(!svc) svc = await blkNative('isServiceEnabled', {}, true);
  const enabled = !!(svc && svc.enabled);
  const known = svc && typeof svc.heartbeatAge === 'number' && svc.heartbeatAge >= 0;
  const dead = enabled && known && svc.stale;
  // The card is about the quick block: its own switch, under the engine's master switch.
  // A master switch left OFF by an older build (which paused everything from this button)
  // is put back on now, so the programmes it silenced come back to life.
  if(EXTRA.enabled === false && blkHasNative('setEnabled')){
    const okRules = await blkNative('setEnabled', { enabled: true }, true);
    if(okRules !== null) EXTRA.enabled = true;
  }
  const on = QUICK.enabled;

  paintQuickBlock(on);

  await blkRefreshStrict();   // the cards need to know whether they are locked
  const engineRules = await blkNative('getRulesFull', {}, true);
  const nRules = blkRuleCount(engineRules);
  renderBaseProtection();

  if(!enabled){
    say('', '!', 'Il blocco non può funzionare — servizio non attivo', 'Abilita');
  }else if(dead){
    say('', '!', 'Il sistema ha fermato il servizio. Non stai bloccando nulla', 'Riattiva');
  }else{
    // Working, or paused by the user's own switch: nothing to shout about. The quick-block
    // card already shows the switch state; a green "verified" strip on top of it was noise.
    b.hidden = true;
  }
}

/* ================= 15 · AVVIO ================= */
renderTemplates();
renderPrograms();

/* Sheet and dialog, registered by this module so index.html stays untouched. */
(function blkRegisterChrome(){
  if(typeof registerOverlay !== 'function') return;
  registerOverlay('blkProgSheet',
    '<div class="blk-sheet-scrim" onclick="blkCloseProgMenu()"></div>' +
    '<div class="blk-sheet"><div class="blk-grab"></div><div id="blkProgSheetBody"></div>' +
    '<button class="ghost blk-sheet-cancel" onclick="blkCloseProgMenu()">Annulla</button></div>');
  /* The thin Premium band AppBlock keeps above the tab bar ("7 giorni di Premium gratuiti").
     Sticky at the bottom of the Blocco tab, gone the moment the user is Premium. While no
     trial has ever been taken it offers the week; afterwards it simply sells. */
  /* Appesa a #phone, non alla pagina che scorre: dentro .tabpage un position:sticky non può
     superare il fondo del suo contenuto, e infatti la banda restava a mezz'aria sopra il menu
     invece di appoggiarcisi. Qui è ancorata all'altezza reale della barra, misurata. */
  const phone = document.getElementById('phone');
  if(phone && !document.getElementById('blkPremBand')){
    const band = document.createElement('div');
    band.className = 'blk-premband';
    band.id = 'blkPremBand';
    band.hidden = true;           // 0.9.359: nasce nascosta; la mostra solo blkPaintPremBand, quando sa chi sei
    band.setAttribute('onclick', 'go(11)');
    phone.appendChild(band);
  }
  registerOverlay('blkTypeSheet',
    '<div class="blk-sheet-scrim" onclick="edCloseTypeSheet()"></div>' +
    '<div class="blk-sheet"><div class="blk-grab"></div><div id="blkTypeSheetBody"></div>' +
    '<button class="ghost blk-sheet-cancel" onclick="edCloseTypeSheet()">Annulla</button></div>');
  registerOverlay('blkConfirm',
    '<div class="blk-sheet-scrim"></div>' +
    '<div class="blk-dialog"><b id="blkConfirmTitle"></b><p id="blkConfirmText"></p>' +
    '<button class="cta" id="blkConfirmOk"></button>' +
    '<button class="ghost" id="blkConfirmNo">Annulla</button></div>');

  const css = [
    /* Card: generous padding and everything centred, the way AppBlock stacks a program. */
    '.blk-card{position:relative;background:#fff;border:1px solid var(--line);border-radius:18px;cursor:pointer;-webkit-tap-highlight-color:transparent;',
    /* 0.9.358, Andrea: "i programmi sono ravvicinatissimi: un leggero margine in piu', 4-5 px" */
    '  padding:22px 18px 18px;margin-bottom:17px;text-align:center;box-shadow:0 2px 10px rgba(0,30,68,.05)}',
    '.blk-card-locked{border-color:#F5C2C7;background:#FFFBFB}',
    /* The active ring is the selected-swatch of dream-brothers.com: blue border, a 1.5px halo,
       two layers of blue glow, and a thin white inner frame. */
    '.blk-card.on{border-color:#0B84FF;background:#F7FBFF;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.28),0 22px 44px rgba(11,132,255,.16)}',
    /* Solo una cornice: niente sfondo, niente z-index, cosi' non copre nulla e soprattutto
       non costringe i figli a position:relative — che e' quello che aveva spostato i tre
       puntini dall'angolo al centro della card. */
    '.blk-card.on::before{content:"";position:absolute;inset:3px;border:3px solid #fff;border-radius:15px;pointer-events:none}',
    '.blk-card.off{border-color:#E63946;box-shadow:0 0 0 1.5px #F08A92,0 8px 18px rgba(230,57,70,.18)}',
    '.blk-card-pill.idle{background:#DCE8F5;color:#4A5A72}',
    /* Il Dream gradient del brand (brand-kit): rosa tenue -> lavanda -> blu -> ciano. */
    '.blk-streak{display:flex;align-items:center;gap:14px;border-radius:22px;padding:18px;margin:0 0 12px;',
    '  background:linear-gradient(135deg,rgba(246,204,204,1),rgba(246,204,228,1) 23%,rgba(236,207,239,1) 31%,rgba(223,210,248,1) 41%,rgba(208,215,253,1) 50%,rgba(193,219,255,1) 57%,rgba(188,224,255,1) 67%,rgba(184,229,255,1) 80%,rgba(182,233,254,1) 88%,rgba(190,239,253,1) 94%,rgba(199,244,252,1) 97%,rgba(210,249,251,1) 99%,rgba(221,254,252,1) 100%)}',
    /* IL BORDO CHE SI ACCENDE quando la Modalita' severa e' avviata. Fermo finche' e'
       accesa; pulsa una volta sola, la prima volta che il pannello si fa vedere dopo
       l'attivazione — un'animazione che riparte a ogni visita e' un tic, non una festa. */
    /* L'ALONE E' QUELLO DEL LUCCHETTO, non l'azzurro dei blocchi.
       L'azzurro circonda gia' il Blocco rapido e i programmi: usarlo anche qui voleva dire
       dire «qualcosa e' acceso» invece di «Modalita' severa avviata». Questo e' lo stesso
       gradiente conico che gira intorno alla bolla del lucchetto (app.css) — ed e' anche
       quello della frase del giorno sul sito. Un segno, un significato.
       Il doppio strato serve: un figlio con z-index negativo si disegna SOPRA allo sfondo del
       genitore, quindi il gradiente del pannello va ridipinto sopra all'alone. */
    '.blk-streak.accesa{position:relative;isolation:isolate}',
    /* NON SI RUOTA LA SCATOLA, si ruota la luce.
       `transform:rotate()` su un rettangolo largo fa spazzare agli angoli un'area molto piu'
       grande della card, e il bagliore esce a macchie da tutte le parti. Su un cerchio quel
       trucco funziona — un disco ruotato e' identico a se stesso — e infatti l'avevo copiato
       dalla bolla del lucchetto senza accorgermi che qui la forma e' un'altra.
       `--flang` e' registrata come angolo in app.css: e' l'unico modo perche' il browser sappia
       interpolare l'inclinazione di un conic-gradient. */
    '.blk-streak.accesa::before{content:"";position:absolute;inset:-7px;border-radius:29px;',
      'z-index:-2;pointer-events:none;filter:blur(12px);',
      'background:conic-gradient(from var(--flang),#3F9FF4,#0075E3,#E63946,#3F9FF4);',
      'animation:flGlowAng 3s linear infinite}',
    '.blk-streak.accesa::after{content:"";position:absolute;inset:0;border-radius:inherit;',
      'background:inherit;z-index:-1;pointer-events:none}',
    /* Appena avviata l'alone respira una volta, poi si posa. */
    '@keyframes blkNato{0%{transform:scale(.88);opacity:.2}60%{transform:scale(1.06);opacity:1}100%{transform:scale(1);opacity:1}}',
    '.blk-streak.accesa.nuova::before{animation:flGlowAng 3s linear infinite,blkNato 1.2s ease-out}',
    '.blk-streak .txt{flex:1;min-width:0}',
    /* la medaglia nuova: il titolo scoppia e una luce lo attraversa, una volta */
    '.blk-streak.medaglia-nuova b{display:inline-block;transform-origin:left center;animation:blkMedaglia 1.1s cubic-bezier(.2,1.6,.4,1) both,blkLuce 1.8s ease-out .6s both}',
    '@keyframes blkMedaglia{0%{transform:scale(.6);opacity:0}60%{transform:scale(1.14);opacity:1}100%{transform:scale(1)}}',
    '@keyframes blkLuce{0%{text-shadow:0 0 0 rgba(255,255,255,0)}35%{text-shadow:0 0 16px rgba(255,255,255,.95),0 0 4px rgba(255,255,255,.9)}100%{text-shadow:0 0 0 rgba(255,255,255,0)}}',
    '.blk-streak b{display:block;font:800 17px var(--font-display);color:#001E44;margin-bottom:5px}',
    '.blk-streak p{font:500 12.5px/1.55 var(--font-body);color:#31456B;margin:0}',
    '.blk-streak strong{font-weight:800;color:#001E44}',
    '.blk-streak .flame{position:relative;font-size:54px;line-height:1;flex:none;filter:drop-shadow(0 6px 10px rgba(230,120,0,.35))}',
    /* IL NUMERO DENTRO AL FUOCO. Era a 17px in Montserrat sopra a un'emoji arancione: troppo
       piccolo e troppo sottile per un fondo che gli cambia colore sotto. Piu' grande, in
       Poppins nero (che ha le aste molto piu' spesse del display), e con un contorno chiaro
       sotto — senza, un numero scuro su arancione resta un'ombra. */
    '.blk-streak .flame span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;',
    '  padding-top:13px;font:900 24px var(--font-body);color:#5A2A00;',
    '  text-shadow:0 1px 0 rgba(255,225,170,.85),0 -1px 0 rgba(255,225,170,.6),',
    '  1px 0 0 rgba(255,225,170,.6),-1px 0 0 rgba(255,225,170,.6)}',
    '.blk-card-dead{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--red-deep);margin-top:10px}',
    'body.dark .blk-card.on{background:#0E1E3A}',
    'body.dark .blk-card.on::before{border-color:#1B2E52}',
    '.blk-card-ico{font-size:34px;line-height:1;margin-bottom:10px}',
    '.blk-card-name{display:block;font:800 16px var(--font-display);color:var(--navy)}',
    '.blk-card-desc{display:block;font:500 12px/1.6 var(--font-body);color:var(--muted);margin:5px 12px 14px}',
    '.blk-card-rim{display:block;margin:-8px 12px 14px;font:700 13px/1.4 var(--font-body);color:#0075E3}body.dark .blk-card-rim{color:#4FB8FF}',
    '.blk-card-pill{display:inline-block;font:800 10px var(--font-body);letter-spacing:.4px;',
    '  color:#fff;background:var(--blue);border-radius:99px;padding:6px 14px}',
    '.blk-card-pill.paused{background:#8FA6C2}',
    /* 0.9.395: il programma del tuo agente che aspetta la conferma */
    '.blk-card-pill.conf{background:#E08A00}',
    '.blk-card-confnota{display:block;margin:12px 12px 0;font:600 12.5px/1.5 var(--font-body);color:var(--navy)}body.dark .blk-card-confnota{color:#DCEBFF}',
    '.blk-card-confaz{display:flex;justify-content:center;flex-wrap:wrap;gap:8px}.blk-card-confaz .blk-card-resume{margin:12px 0 0}',
    '.blk-card-resume.blk-card-cambia{background:transparent;color:var(--blue);box-shadow:inset 0 0 0 2px var(--blue)}body.dark .blk-card-resume.blk-card-cambia{color:#8CC6FF;box-shadow:inset 0 0 0 2px #8CC6FF}',
    '.blk-card-resume{display:block;margin:12px auto 0;border:0;border-radius:99px;background:var(--blue);color:#fff;',
    '  font:800 13px var(--font-body);padding:11px 26px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.blk-card-more{position:absolute;top:10px;right:8px;background:none;border:0;font-size:22px;',
    '  line-height:1;color:var(--faint);padding:6px 10px;cursor:pointer}',
    /* Sheet */
    /* con la tastiera aperta sparisce come la barra delle schede: era l'altra meta' del
       menu che saliva sopra ai tasti */
    'body.kbd .blk-premband{display:none !important}',
    '.blk-premband{position:absolute;left:14px;right:14px;z-index:39;display:flex;align-items:center;gap:9px;padding:12px 16px;',
    '  background:linear-gradient(90deg,#0B2A55,#0075E3);color:#fff;font:700 13px var(--font-body);border-radius:16px;cursor:pointer;',
    '  box-shadow:0 10px 24px rgba(0,30,68,.28)}',
    '.blk-premband .arr{margin-left:auto;color:#fff}',
    '.blk-premband[hidden]{display:none}',
    '#blkProgSheet,#blkConfirm,#blkTypeSheet{position:fixed;inset:0;z-index:70;display:none}',
    '#blkProgSheet.open,#blkConfirm.open,#blkTypeSheet.open{display:block}',
    '#blkTypeSheet .blk-sheet{max-height:82%;overflow:auto}',
    '.blk-typerow{display:flex;align-items:flex-start;gap:12px;width:100%;text-align:left;background:#fff;',
    '  border:1px solid var(--line);border-radius:14px;padding:12px;margin-bottom:8px;cursor:pointer}',
    '.blk-typerow.sel{border-color:var(--blue);background:var(--blue-soft)}',
    '.blk-typerow .ti{font-size:22px;flex:none;line-height:1.2}',
    '.blk-typerow .tt{flex:1;min-width:0}',
    '.blk-typerow .tt b{display:block;font:800 14px var(--font-display);color:var(--navy)}',
    '.blk-typerow .tt small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:2px}',
    '.blk-typerow .tk{color:var(--blue);font-weight:800;flex:none}',
    '.blk-sheet-scrim{position:absolute;inset:0;background:rgba(0,19,43,.45)}',
    '.blk-sheet{position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:22px 22px 0 0;',
    '  padding:10px 16px calc(18px + env(safe-area-inset-bottom))}',
    '.blk-grab{width:38px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 12px}',
    '.blk-sheet-title{font:800 16px var(--font-display);color:var(--navy);text-align:center;margin-bottom:6px}',
    '.blk-sheet-note{font:500 11.5px/1.6 var(--font-body);color:var(--red-deep);background:var(--red-soft);',
    '  border-radius:12px;padding:11px 12px;margin:8px 0 12px}',
    '.blk-sheet-row{display:flex;align-items:center;gap:13px;width:100%;background:none;border:0;',
    '  padding:15px 6px;font:600 14.5px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    '.blk-sheet-row .ic{width:24px;text-align:center}',
    '.blk-sheet-row.danger{color:var(--red)}',
    '.blk-sheet-row.disabled{opacity:.38;cursor:not-allowed}',
    '.blk-sheet-cancel{width:100%;margin-top:6px}',
    /* Dialog */
    '.blk-dialog{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(320px,88%);',
    '  background:#fff;border-radius:20px;padding:24px 20px 18px;text-align:center}',
    '.blk-dialog b{display:block;font:800 17px var(--font-display);color:var(--navy)}',
    '.blk-dialog p{font:500 12.5px/1.65 var(--font-body);color:var(--muted);margin:10px 0 18px}',
    '.blk-dialog .cta{width:100%}',
    '.blk-dialog .cta.danger{background:var(--red)}',
    '.blk-dialog .ghost{width:100%;margin-top:4px}'
  ].join(' ');
  const st = document.createElement('style');
  st.id = 'blk-card-style';
  st.textContent = css;
  document.head.appendChild(st);
})();

/* ================= SELETTORE ORARIO A DUE COLONNE =================
 * The native <input type="time"> hands over to the system clock, and on One UI that is an
 * analog dial: to set 22:00 you drag a hand twice and switch AM/PM. Two vertical wheels -
 * hours, minutes - are one flick each, and they are what AppBlock shows. */

let BLK_TIME_TARGET = null;

function blkTimeParts(v){
  const m = /^(\d{1,2}):(\d{2})/.exec(v || '');
  return m ? { h: Math.min(23, +m[1]), mi: Math.min(59, +m[2]) } : { h: 22, mi: 0 };
}
function blkPad(n){ return (n < 10 ? '0' : '') + n; }

/* 0.9.402 BUG-234, Andrea: "Dalle che ora non e' italiano; il 21, lo 00 e i due punti sono tre altezze diverse; le colonne devono girare in
   tondo come su iPhone: dopo 23 viene 00, dopo 55 viene 00". LA CAUSA dell'altezza: il valore scelto si centrava con scrollTop, ma il primo
   elemento della colonna (00) non si poteva portare al centro, perche' sopra non c'era niente da scorrere: restava in alto. Adesso ogni
   colonna e' la lista ripetuta nove volte, si parte dalla copia di mezzo, e quando ci si avvicina ai bordi lo scroll si sposta di qualche
   copia (stesso numero, nessuno se ne accorge): un bordo non c'e' mai, e il valore scelto sta SEMPRE nella riga di mezzo. La fascia azzurra
   e' una sola, dietro alle due colonne, alla stessa altezza dei due punti. Vale per ogni selettore di ora: anche i campi <input type="time">
   sparsi nell'app (blkTimeAggancia, qui sotto) e le sveglie (alarms.js, con flRuotaGiro). */
const BLK_TIME_H = 44, BLK_TIME_COPIE = 9;
/** Una colonna che gira in tondo: n voci alte h, ripetute `copie` volte, con la riga scelta a `righeSopra` righe dal bordo alto.
    Restituisce l'indice della voce al centro, gia' riportata nella copia di mezzo quando si avvicinava ai bordi. */
function flRuotaGiro(col, n, h, copie, righeSopra){
  if (!col || n < 2) return 0;
  copie = copie || BLK_TIME_COPIE;
  let i = Math.round(col.scrollTop / h) + (righeSopra || 0);
  i = Math.max(0, Math.min(n * copie - 1, i));
  const copia = Math.floor(i / n), mezzo = Math.floor(copie / 2);
  if (copia < 2 || copia > copie - 3){
    const salto = (mezzo - copia) * n;
    const b = col.style.scrollBehavior; col.style.scrollBehavior = 'auto';
    col.scrollTop += salto * h; i += salto;
    col.style.scrollBehavior = b;
  }
  return i;
}
function blkTimeMinStep(input, mi){
  const st = parseInt(input && input.getAttribute && input.getAttribute('step'), 10);
  if (st >= 60 && 60 % Math.round(st / 60) === 0) return Math.max(1, Math.round(st / 60));
  if (input && (input.id === 'edFrom' || input.id === 'edTo' || input.type === 'hidden')) return 5;
  return (mi % 5 === 0) ? 5 : 1;
}
/* il titolo del selettore aperto da un campo qualunque: "Da che ora?" accanto a "Dalle", altrimenti "A che ora?" */
function blkTimeTitolo(input){
  let t = '';
  try{
    t = input.getAttribute('aria-label') || '';
    if (!t && input.id){ const l = document.querySelector('label[for="' + input.id + '"]'); if (l) t = l.textContent; }
    if (!t){ const l = input.closest('label'); if (l) t = l.textContent; }
    if (!t && input.previousElementSibling) t = input.previousElementSibling.textContent;
  }catch(_){ }
  return /^\s*(dalle|dal|da)\b/i.test(t || '') ? 'Da che ora?' : 'A che ora?';
}

/* Opens the wheel for any hidden time input, not just the editor's two: the onboarding has
   its own pair, and two implementations of the same control is how they drift apart.
   0.9.402: accetta anche l'elemento stesso (i campi <input type="time"> senza id). */
function blkOpenTime(target, opts){
  opts = opts || {};
  const input = (target && target.nodeType === 1) ? target : document.getElementById(target === 'from' ? 'edFrom' : (target === 'to' ? 'edTo' : target));
  if(!input) return;
  const inputId = input.id || '';
  BLK_TIME_TARGET = {
    input: input,
    inputId: inputId,
    labelId: opts.labelId || (inputId ? inputId + 'Lbl' : ''),
    onDone: opts.onDone || null
  };
  const cur = blkTimeParts(input.value);
  const wrap = document.getElementById('blkTime');
  if(!wrap) return;
  document.getElementById('blkTimeTitle').textContent =
    opts.title || (target === 'to' ? 'A che ora?' : (target === 'from' ? 'Da che ora?' : blkTimeTitolo(input)));
  const passo = blkTimeMinStep(input, cur.mi);
  /* un campo dentro a un foglio (il Full Focus programmato, un inSheet) apre la ruota SOPRA a quel foglio, non dietro */
  let zMax = 0;
  for (let e = input.parentElement; e && e !== document.body; e = e.parentElement){ const z = parseInt(getComputedStyle(e).zIndex, 10); if (z > zMax) zMax = z; }
  wrap.style.zIndex = zMax >= 70 ? String(zMax + 1) : '';
  wrap.classList.add('open');

  const fill = function(id, count, step, sel){
    const col = document.getElementById(id);
    col.innerHTML = '';
    const n = Math.ceil(count / step);
    col.dataset.n = n;
    const frag = document.createDocumentFragment();
    for(let c = 0; c < BLK_TIME_COPIE; c++){
      for(let v = 0; v < count; v += step){
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'blk-time-item';
        b.textContent = blkPad(v);
        b.dataset.v = v;
        b.tabIndex = -1;
        frag.appendChild(b);
      }
    }
    col.appendChild(frag);
    const items = col.children;
    let acceso = -1;
    const segna = function(i){ if (i === acceso) return; if (items[acceso]) items[acceso].classList.remove('on'); if (items[i]) items[i].classList.add('on'); acceso = i; };
    // the chosen value sits in the middle copy, on the middle row
    const i0 = Math.floor(BLK_TIME_COPIE / 2) * n + Math.max(0, Math.min(n - 1, Math.round(sel / step) % n));
    col.style.scrollBehavior = 'auto';
    col.scrollTop = (i0 - 2) * BLK_TIME_H;
    col.style.scrollBehavior = '';
    segna(i0);
    col.onscroll = function(){
      // while the finger moves the bright number follows the middle row; when it stops, the column goes back to the middle copy
      segna(Math.max(0, Math.min(items.length - 1, Math.round(col.scrollTop / BLK_TIME_H) + 2)));
      clearTimeout(col._t);
      col._t = setTimeout(function(){ segna(flRuotaGiro(col, n, BLK_TIME_H, BLK_TIME_COPIE, 2)); }, 140);
    };
    col.onclick = function(e){
      const b = e.target && e.target.closest && e.target.closest('.blk-time-item'); if (!b) return;
      const k = Array.prototype.indexOf.call(items, b);
      col.scrollTo({ top: (k - 2) * BLK_TIME_H, behavior: 'smooth' });
    };
  };
  fill('blkTimeH', 24, 1, cur.h);
  fill('blkTimeM', 60, passo, cur.mi);
}

function blkCloseTime(){
  const w = document.getElementById('blkTime');
  if(w) w.classList.remove('open');
}

/** Il valore nella riga di mezzo di una colonna (anche se la colonna sta ancora frenando). */
function blkTimeCentro(id){
  const col = document.getElementById(id); if (!col) return null;
  const items = col.children; if (!items.length) return null;
  const i = Math.max(0, Math.min(items.length - 1, Math.round(col.scrollTop / BLK_TIME_H) + 2));
  return +items[i].dataset.v;
}
function blkConfirmTime(){
  const h = blkTimeCentro('blkTimeH');
  const m = blkTimeCentro('blkTimeM');
  if(h == null || m == null || !BLK_TIME_TARGET){ blkCloseTime(); return; }
  const value = blkPad(h) + ':' + blkPad(m);
  const input = BLK_TIME_TARGET.input || document.getElementById(BLK_TIME_TARGET.inputId);
  if(input){
    input.value = value;
    // Fired so whoever owns the field reacts exactly as it did with the native picker.
    try{ input.dispatchEvent(new Event('input', { bubbles: true })); }catch(_){ }
    try{ input.dispatchEvent(new Event('change', { bubbles: true })); }catch(_){ }
  }
  const lbl = BLK_TIME_TARGET.labelId ? document.getElementById(BLK_TIME_TARGET.labelId) : null;
  if(lbl) lbl.textContent = value;
  if(BLK_TIME_TARGET.onDone) BLK_TIME_TARGET.onDone(value);
  blkCloseTime();
}

/* 0.9.402 BUG-234: "vale per ogni selettore di ora dell'app". I campi <input type="time"> sparsi nell'app (calendario, piano, silenzio,
   resoconto della sera, Full Focus programmato...) aprivano l'orologio del telefono, che su One UI e' un quadrante analogico. Un tocco su
   uno qualunque di loro apre la stessa ruota; il valore torna nel campo con gli eventi input e change, quindi chi lo ascolta non cambia. */
(function blkTimeAggancia(){
  const campo = function(e){
    const t = e.target;
    if (!t || t.tagName !== 'INPUT' || String(t.type).toLowerCase() !== 'time' || t.disabled || t.readOnly) return null;
    return document.getElementById('blkTime') ? t : null;
  };
  document.addEventListener('pointerdown', function(e){ if (campo(e)) e.preventDefault(); }, true);
  document.addEventListener('mousedown', function(e){ if (campo(e)) e.preventDefault(); }, true);
  document.addEventListener('click', function(e){
    const t = campo(e); if (!t) return;
    e.preventDefault(); e.stopImmediatePropagation();
    try{ t.blur(); }catch(_){ }
    blkOpenTime(t);
  }, true);
  document.addEventListener('keydown', function(e){
    const t = campo(e); if (!t || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault(); blkOpenTime(t);
  }, true);
})();

/* Keeps the visible labels in step with the hidden inputs whenever the editor is filled in. */
function blkPaintTimeLabels(){
  ['edFrom','edTo'].forEach(function(id){
    const el = document.getElementById(id), lbl = document.getElementById(id + 'Lbl');
    if(el && lbl) lbl.textContent = el.value || '--:--';
  });
}

(function blkRegisterTimePicker(){
  if(typeof registerOverlay !== 'function') return;
  registerOverlay('blkTime',
    '<div class="blk-sheet-scrim" onclick="blkCloseTime()"></div>' +
    '<div class="blk-sheet" role="dialog" aria-modal="true" aria-labelledby="blkTimeTitle">' +
      '<div class="blk-grab"></div>' +
      '<div class="blk-sheet-title" id="blkTimeTitle"></div>' +
      '<div class="blk-time-cols">' +
        '<div class="blk-time-col" id="blkTimeH" aria-label="Ore"></div>' +
        '<div class="blk-time-sep" aria-hidden="true">:</div>' +
        '<div class="blk-time-col" id="blkTimeM" aria-label="Minuti"></div>' +
      '</div>' +
      '<button class="cta" onclick="blkConfirmTime()">Conferma</button>' +
      '<button class="ghost blk-sheet-cancel" data-chiudi onclick="blkCloseTime()">Annulla</button>' +
    '</div>');

  const css = [
    /* Without this the sheet has no display rule at all: it sat visible and empty over the
       home screen from the moment the app opened, and blkCloseTime() - which only removes
       .open - could not put away something that was never hidden to begin with. */
    '#blkTime{position:fixed;inset:0;z-index:70;display:none}',
    '#blkTime.open{display:block}',
    '.blk-timerow{gap:10px}',
    '.blk-timefield{width:100%;background:#fff;border:1px solid var(--line);border-radius:14px;',
    '  padding:12px 14px;text-align:left;cursor:pointer}',
    '.blk-timefield .flbl{display:block;margin-bottom:2px}',
    '.blk-timefield b{font:800 20px var(--font-display);color:var(--navy)}',
    /* 0.9.402 BUG-234: cinque righe da 44px. La riga di mezzo e' la fascia azzurra, una sola dietro alle due colonne; i due punti stanno
       sulla stessa riga, con la stessa altezza di riga dei numeri */
    '.blk-time-cols{position:relative;display:flex;align-items:center;justify-content:center;gap:4px;margin:10px 0 16px;height:220px}',
    '.blk-time-cols::before{content:"";position:absolute;left:50%;top:50%;width:236px;max-width:92%;height:44px;transform:translate(-50%,-50%);background:var(--blue-soft);border-radius:12px;pointer-events:none}',
    'body.dark .blk-time-cols::before{background:rgba(0,117,227,.24)}',
    '.blk-time-col{position:relative;z-index:1;height:220px;overflow-y:auto;scroll-snap-type:y mandatory;width:96px;overscroll-behavior:none;',
    '  -webkit-overflow-scrolling:touch;scrollbar-width:none;-webkit-mask-image:linear-gradient(transparent,#000 22%,#000 78%,transparent);mask-image:linear-gradient(transparent,#000 22%,#000 78%,transparent)}',
    '.blk-time-col::-webkit-scrollbar{display:none}',
    '.blk-time-item{display:block;width:100%;height:44px;background:none;border:0;padding:0;margin:0;',
    '  font:600 21px/44px var(--font-display);color:var(--faint);cursor:pointer;scroll-snap-align:center;font-variant-numeric:tabular-nums}',
    '.blk-time-item.on{color:var(--navy);font-weight:800}',
    'body.dark .blk-time-item.on{color:#fff}',
    '.blk-time-sep{position:relative;z-index:1;height:44px;font:800 21px/44px var(--font-display);color:var(--navy)}',
    'body.dark .blk-time-sep{color:#fff}'
  ].join(' ');
  const st = document.createElement('style');
  st.id = 'blk-time-style';
  st.textContent = css;
  document.head.appendChild(st);
})();

/* ---- Emoji picker for the editor: the big icon, or an emoji dropped into the name ---- */
const BLK_EMOJI = ['🕑','⏳','🚫','🎯','📚','💼','🧠','🌙','☀️','🏃','🧘','💤','📵','🔕','🔒','🛡️','🎓','✍️','🧪','💻',
  '🍎','🏋️','🚴','🎨','🎸','📖','🧹','🍽️','👨‍👩‍👧','❤️','🔥','⚡','🌱','🌊','🏔️','🚀','🎧','📝','⏰','🛏️',
  '📵','🙈','🐢','🦁','🐝','🍀','🌸','🎁','🏆','💎','🗝️','🧭','📌','✅','🧩','🎲','🕹️','📺','🎬','☕'];
function blkEmojiPicker(target){
  let sh = document.getElementById('blkEmoji');
  if(!sh){
    sh = document.createElement('div');
    sh.id = 'blkEmoji';
    sh.className = 'blk-sw';
    sh.innerHTML = '<div class="blk-scrim"></div>' +
      '<div class="blk-sheet"><div class="grab"></div><h3 id="blkEmojiTitle" style="margin:0 0 4px">Scegli un\'emoji</h3>' +
      '<div class="emo-grid emo-6" id="blkEmojiGrid"></div><button type="button" class="emo-altro" id="blkEmojiAltro">Mostra altre</button>' +
      '<div class="emo-own"><input id="blkEmojiOwn" placeholder="…o scrivine una dalla tastiera" maxlength="4" data-no-mic data-no-dettatura><button class="cta" style="padding:10px 14px;width:auto" id="blkEmojiUse">Usa</button></div>' +
      '<button class="ghost cancel" id="blkEmojiClose" style="margin-top:8px">Annulla</button></div>';
    const phone = document.getElementById('phone'); (phone || document.body).appendChild(sh);
    sh.querySelector('.blk-scrim').addEventListener('click', function(){ sh.classList.remove('open'); });
    sh.querySelector('#blkEmojiClose').addEventListener('click', function(){ sh.classList.remove('open'); });
    const grid = sh.querySelector('#blkEmojiGrid');
    /* 0.9.371, Andrea: "troppe icone su una riga, e nessun anello su quella scelta; ne voglio 6 per riga, le altre nascoste dietro a
       Mostra altro; il microfono per scrivere un'icona non ha senso" */
    BLK_EMOJI.filter(function(e,i,a){ return a.indexOf(e) === i; }).forEach(function(e, i){
      const b = document.createElement('button'); b.type = 'button'; b.textContent = e; b.setAttribute('data-e', e);
      if (i >= 18) b.className = 'emo-dopo';
      b.addEventListener('click', function(){ blkEmojiApply(e); });
      grid.appendChild(b);
    });
    sh.querySelector('#blkEmojiAltro').addEventListener('click', function(){ grid.classList.add('tutte'); this.hidden = true; });
    sh.querySelector('#blkEmojiUse').addEventListener('click', function(){
      const v = (sh.querySelector('#blkEmojiOwn').value || '').trim();
      if(v) blkEmojiApply(v);
    });
  }
  sh._target = target;
  sh.querySelector('#blkEmojiTitle').textContent = 'Icona del programma';
  try{
    const scelta = (target !== 'name' && typeof DRAFT === 'object' && DRAFT && DRAFT.icon) || ((document.getElementById('edIcon') || {}).textContent || '');
    const grid = sh.querySelector('#blkEmojiGrid'); let dopo = false;
    grid.querySelectorAll('button').forEach(function(b){ const on = target !== 'name' && b.getAttribute('data-e') === scelta; b.classList.toggle('scelta', on); if (on && b.classList.contains('emo-dopo')) dopo = true; });
    grid.classList.toggle('tutte', dopo); sh.querySelector('#blkEmojiAltro').hidden = dopo;
  }catch(_){ }
  sh.querySelector('#blkEmojiOwn').value = '';
  sh.classList.add('open');
}
function blkEmojiApply(e){
  const sh = document.getElementById('blkEmoji');
  if(!sh) return;
  if(sh._target === 'name'){
    const inp = document.getElementById('edName');
    const start = inp.selectionStart != null ? inp.selectionStart : inp.value.length;
    const end = inp.selectionEnd != null ? inp.selectionEnd : start;
    inp.value = inp.value.slice(0, start) + e + ' ' + inp.value.slice(end);
    try{ inp.focus(); inp.setSelectionRange(start + e.length + 1, start + e.length + 1); }catch(_){ }
  } else {
    if(typeof DRAFT === 'object' && DRAFT) DRAFT.icon = e;
    const ico = document.getElementById('edIcon'); if(ico) ico.textContent = e;
  }
  sh.classList.remove('open');
}

/* ---- the Premium band: text and visibility follow the entitlement ---- */
/* BUG-049 (Da Andrea n. 230, 22/11): la spinta a pagare sta solo dove l'utente pensa al suo
   sogno (Sogno) e al suo account (Profilo), mai in START, Mappa, Modalita' severa o Report. */
function blkPremBandPagina(scheda){
  return scheda === 'rotta' || scheda === 'profilo';
}
function blkPaintPremBand(){
  const band = document.getElementById('blkPremBand');
  if(!band) return;
  /* 0.9.359, Andrea: "quando scarico una nuova versione dell'APK compare il banner Passa a Premium anche se sono gia' Premium:
     l'ho detto prima e non hai risolto". CAUSA VERA: questo file si carica PRIMA di profile.js. All'avvio, con la scheda
     Blocco accesa per un attimo, Premium non esisteva ancora: la risposta era "non Premium" e la fascia compariva; e
     Premium.onChange piu' sotto non si agganciava mai (Premium non c'era), quindi nessuno la toglieva fino al primo cambio di
     scheda. Dopo un aggiornamento la pagina si carica molto piu' lenta (il telefono ricompila tutti gli script), per questo
     succedeva proprio li'. Finche' Premium non esiste la risposta e' "Premium": un invito a pagare mostrato a chi paga e'
     peggio di un invito che arriva un secondo dopo. */
  const premium = (typeof Premium === 'undefined') ? true : Premium.isPremium();
  const home = document.getElementById('s-home');
  /* CAUSA VERA (BUG-049): qui si guardava se "tab-blocco" avesse la classe "on" — ma "blocco"
     non e' piu' una scheda dentro TABS (nav.js) da quando e' diventata una pagina a parte;
     switchTab() non la tocca piu', la classe scritta nell'HTML all'avvio resta per sempre, e la
     fascia compariva su qualunque scheda della casa. Ora si guarda la scheda vera. */
  const scheda = (typeof navTabCorrente === 'function') ? navTabCorrente() : '';
  const paginaGiusta = blkPremBandPagina(scheda);
  const tab = paginaGiusta ? document.getElementById('tab-' + scheda) : null;
  const onBlocco = !!(paginaGiusta && home && home.classList.contains('active'));
  band.hidden = premium || !onBlocco;
  if(band.hidden){
    ['rotta', 'profilo'].forEach(function(t){ const e = document.getElementById('tab-' + t); if(e) e.style.paddingBottom = ''; });
    return;
  }
  // Sopra la barra di navigazione, alla sua altezza vera (cambia con la safe area).
  const nav = document.querySelector('.bottomnav');
  const navH = nav ? nav.offsetHeight : 64;
  band.style.bottom = (navH + 10) + 'px';
  if(tab) tab.style.paddingBottom = (96 + band.offsetHeight) + 'px';
  if(premium) return;
  let trialUsed = false; try{ trialUsed = localStorage.getItem('fl_trial_used') === '1'; }catch(_){ }
  band.innerHTML = trialUsed
    ? '💎 <span>Passa a Premium — blocco illimitato, zero pubblicità</span><span class="arr">›</span>'
    : '🎁 <span>7 giorni di Premium gratuiti</span><span class="arr">›</span>';
}
blkPaintPremBand();
/* Premium arriva con profile.js, dopo questo file: ci si aggancia quando tutti gli script sono caricati */
(function blkPremAggancia(){
  const aggancia = function(){ try{ if (typeof Premium !== 'undefined' && Premium.onChange && !blkPaintPremBand.__agganciata){ blkPaintPremBand.__agganciata = true; Premium.onChange(blkPaintPremBand); } blkPaintPremBand(); }catch(_){ } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', aggancia); else setTimeout(aggancia, 0);
})();
document.addEventListener('fl:screen', function(){ setTimeout(blkPaintPremBand, 0); });
document.addEventListener('fl:tab', function(){ setTimeout(blkPaintPremBand, 0); });
window.addEventListener('resize', blkPaintPremBand);

(function blkEvStile(){
  const st = document.createElement('style');
  st.textContent = '.blk-ev-velo{position:fixed;inset:0;z-index:60;background:rgba(0,10,26,.62)}'
    + '.blk-card.blk-ev{position:relative;z-index:61;animation:blkEvLampo 1s ease-in-out infinite}'
    + '@keyframes blkEvLampo{0%,100%{box-shadow:0 0 0 3px #4FB8FF,0 0 24px 6px rgba(79,184,255,.75)}50%{box-shadow:0 0 0 3px rgba(79,184,255,.15),0 0 0 0 rgba(79,184,255,0)}}';
  document.head.appendChild(st);
})();

/* 0.9.371, Andrea: "toccata l'icona del programma e premuto indietro, il popover resta aperto e si torna alla scheda Sogno; e lo stesso
   con l'ingranaggio del blocco rapido. Prima di tornare indietro si chiude il popover". I fogli blk-sw stanno a z-index 95, sotto al
   livello che il tasto indietro cercava (nav.js navVeloAperto): ora il tasto li vede. E ogni foglio ha la sua X, come tutti i popover. */
function blkXTutte(){
  try{
    document.querySelectorAll('.blk-sw > .blk-sheet').forEach(function(f){
      if (f.querySelector(':scope > .blk-x')) return;
      const x = document.createElement('button'); x.type = 'button'; x.className = 'blk-x'; x.setAttribute('aria-label', 'Chiudi');
      x.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
      x.addEventListener('click', function(e){ e.stopPropagation(); const w = f.parentElement; const sc = w && w.querySelector('.blk-scrim'); if (sc) sc.click(); else if (w) w.classList.remove('open'); });
      f.insertBefore(x, f.firstChild);
    });
  }catch(_){ }
}
(function(){
  const via = function(){ blkXTutte(); try{ const ph = document.getElementById('phone'); if (ph && !ph.__blkX){ ph.__blkX = 1; new MutationObserver(function(){ blkXTutte(); }).observe(ph, { childList: true }); } }catch(_){ } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', via); else via();
})();
/* 0.9.379, Andrea: "nel blocco rapido il pulsante Salva non e' sticky come nei programmi". Lo stesso piede dei programmi (#s-editor .ed-piede):
   attaccato al bordo in basso, con lo sfondo della pagina dietro */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#s-qlist > .spacer{display:none}'; document.head.appendChild(st); })();
/* 0.9.381, Andrea: "il pannello Lista di blocco e' troppo attaccato al titolo Blocco rapido" */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#s-quick > .blk-moderow{margin-top:22px!important}'; document.head.appendChild(st); })();

/* ================= 0.9.400 BUG-169 · LE DUE SCELTE DEL BIVIO =================
 * Andrea: "Bivio su tutte le schermate di blocco" (entrare comunque o restare, con il punto alla partita) e "Rettificabile anche in
 * Modalità severa" (dal bivio si rivedono i minuti del limite; dal Blocco rapido si toglie l'app). Si scelgono SOLO con la Modalità
 * severa spenta: con lei accesa si vedono ferme, con la (i) che dice perché (il motore rifiuta comunque di accenderle,
 * FocusLockPlugin.weakensAnySchedule). Di base un programma nuovo nasce con il bivio acceso (mai un muro senza scelta) e la rettifica
 * spenta (resta una protezione); i programmi di prima e il Blocco rapido restano spenti: niente si allenta di nascosto.
 * Il programma le salva con sé (fl_programs e il motore, Schedule.bivio/rettifica, quindi anche nei backup); il Blocco rapido nel
 * motore (QuickBlock.bivio/rettifica), subito. */
function blkScelteDi(){ return (SET_TARGET === 'draft' && DRAFT) ? DRAFT : QUICK; }
function blkScelteBloccate(){
  if (!blkEditLocked()) return false;
  /* un programma appena creato con la Modalità severa accesa (i due minuti) o quello del tuo agente da confermare si cambiano ancora */
  if (SET_TARGET === 'draft' && DRAFT && DRAFT.idx >= 0 && (blkInGrazia(DRAFT) || blkDaConfermare(DRAFT))) return false;
  return true;
}
function blkScelteDipingi(){
  const o = blkScelteDi() || {};
  const chiuso = blkScelteBloccate();
  const rapido = SET_TARGET !== 'draft';
  /* i programmi del bianco e nero e dei suoni non bloccano niente: niente bivio */
  const niente = !rapido && !!(o.grey || o.sound);
  ['swBivioRow', 'swRettRow'].forEach(function(id){ const r = document.getElementById(id); if (r) r.hidden = niente; });
  [['bivio', 'swBivio', 'swBivioI', 'swBivioPerche'], ['rettifica', 'swRett', 'swRettI', 'swRettPerche']].forEach(function(r){
    const sw = document.getElementById(r[1]), i = document.getElementById(r[2]), pe = document.getElementById(r[3]);
    if (sw){ sw.className = 'switch' + (o[r[0]] ? ' on' : '') + (chiuso ? ' blk-sw-chiuso' : ''); sw.setAttribute('aria-disabled', chiuso ? 'true' : 'false'); }
    if (i) i.hidden = !chiuso;
    if (pe && !chiuso) pe.hidden = true;
  });
  const t = document.getElementById('swRettTxt');
  if (t) t.textContent = rapido ? 'Dal bivio puoi togliere un’app dal Blocco rapido anche con la Modalità severa accesa.'
                                : 'Dal bivio puoi cambiare i minuti del limite, al giorno o all’ora, anche con la Modalità severa accesa.';
}
function blkScelteInfo(k){
  const pe = document.getElementById(k === 'bivio' ? 'swBivioPerche' : 'swRettPerche');
  if (!pe) return;
  pe.textContent = 'Con la Modalità severa accesa questa scelta resta com’è. Si cambia solo con la Modalità severa spenta, prima di accenderla.';
  pe.hidden = !pe.hidden;
}
async function blkSceltaCambia(k){
  if (k !== 'bivio' && k !== 'rettifica') return;
  if (blkScelteBloccate()){ blkScelteInfo(k); try{ flVibra(30); }catch(_){ } return; }
  if (SET_TARGET === 'draft' && DRAFT){
    /* il programma la salva con sé, quando tocchi Salva (saveBlock, programToSchedule) */
    DRAFT[k] = !DRAFT[k];
    blkScelteDipingi();
    return;
  }
  const prima = !!QUICK[k], dopo = !prima;
  QUICK[k] = dopo; blkScelteDipingi();
  if (!NATIVE){ toast('Anteprima nel browser:\nl\'impostazione non viene salvata'); return; }
  /* le liste si prendono dal motore: quelle che stai modificando nella pagina del Blocco rapido si salvano con il loro Salva */
  const cur = await blkNative('getQuickBlock', {}, true);
  const r = cur ? await blkNative('setQuickBlock', {
    enabled: !!cur.enabled, apps: cur.apps || [], sites: cur.sites || [], keywords: cur.keywords || [],
    bivio: k === 'bivio' ? dopo : !!cur.bivio, rettifica: k === 'rettifica' ? dopo : !!cur.rettifica
  }) : null;
  if (r === null){ QUICK[k] = prima; blkScelteDipingi(); return; }
  QUICK.bivio = !!r.bivio; QUICK.rettifica = !!r.rettifica; blkScelteDipingi();
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.blk-trow-scelta > div{flex:1;min-width:0}'
  + '.blk-scelta-i{flex:none;width:24px;height:24px;border-radius:50%;border:1.6px solid var(--muted);background:transparent;color:var(--muted);font:700 italic 13px Georgia,serif;line-height:1;cursor:pointer;padding:0}'
  + '.blk-scelta-perche{margin-top:6px;color:#0075E3!important;font-weight:700!important}'
  + '.switch.blk-sw-chiuso{opacity:.45;cursor:not-allowed}'
  + 'body.dark .blk-scelta-i{border-color:#C8EFFD;color:#C8EFFD}body.dark .blk-scelta-perche{color:#7CC4FF!important}';
  document.head.appendChild(st); })();

/* 0.9.401 BUG-201, Andrea: "Proteggi i tuoi sogni: uscendo da un programma si perde il punto in cui si era. Tornando indietro da un
   programma, la pagina deve tornare alla posizione di scorrimento di prima".
   CAUSA: go() (nav.js) rimette in cima ogni schermata in cui si arriva (to.scrollTop = 0), anche quando ci si torna con Indietro.
   0.9.402 BUG-238, Andrea: "sul telefono non funziona. La posizione viene salvata e ripristinata sempre, tranne quando e' passato molto
   tempo (piu' di 10 minuti)". Perche' la 0.9.401 non bastava, provando i percorsi veri:
   - passando dalla casa la posizione si buttava via (verso la casa, o arrivando dalla casa dopo piu' di un secondo e mezzo): ma molti
     percorsi ci passano (il Full Focus finito, la casa e poi di nuovo Proteggi, un Indietro che fa il giro e porta a casa);
   - la posizione si rimetteva per un secondo e mezzo soltanto, contando lo scorrimento in pixel. Sul telefono la pagina si ridisegna
     DOPO: la panoramica del tempo di schermo aspetta il motore (scBlockScores, con un nuovo tentativo dopo 1,5 s), le slide e il
     cielo in cima rifanno la loro animazione, le porte del contratto arrivano dalla rete. Un pezzo che cambia altezza SOPRA al punto
     in cui eri sposta tutto quello che c'e' sotto: lo scrollTop resta uguale, ma tu non vedi piu' la stessa cosa;
   - se il WebView viene ricaricato (Android lo chiude mentre sei nelle impostazioni di sistema per un permesso) la posizione era solo
     in memoria.
   ADESSO: uscendo si segna l'elemento che stava in cima alla vista (con un id, o figlio di un elemento con un id) e a quanti pixel
   dal bordo stava, oltre allo scrollTop; si salva anche in localStorage. Tornando, da qualunque percorso, entro 10 minuti, la pagina
   rimette QUELL'elemento allo stesso punto, e lo rifa' a ogni cambio di altezza (ResizeObserver, MutationObserver e un controllo ogni
   120 ms) per 6 secondi, finche' non tocchi tu lo schermo. */
const BLK_SCROLL = { y: 0, at: 0, chiave: '', delta: 0, prima: '', mano: 0, maxMs: 10 * 60000, durataMs: 6000, k: 'fl_blk_scroll' };
/**
 * Puro, per le prove: la posizione da rimettere arrivando su #s-blocco, o 0 (si riparte dall'alto).
 * {@code y}, {@code at}: dove eri e quando hai lasciato la pagina. Da qualunque schermata si arrivi (anche dalla casa), entro
 * {@code BLK_SCROLL.maxMs} (10 minuti).
 */
function blkScrollDaRimettere(y, at, ora){
  if (!(y > 0) || !(at > 0) || ora < at) return 0;
  if (ora - at > BLK_SCROLL.maxMs) return 0;
  return y;
}
/** Puro: lo scrollTop che rimette l'elemento di riferimento a {@code delta} pixel dal bordo alto della pagina. */
function blkScrollPerAncora(scrollTop, topElemento, topPagina, delta){ return Math.max(0, Math.round(scrollTop + (topElemento - topPagina) - delta)); }
/** L'elemento in cima alla vista: il piu' piccolo (almeno 24 px) che attraversa il bordo alto, con un id o figlio di uno con un id. */
function blkScrollAncora(pag){
  try{
    const top = pag.getBoundingClientRect().top, riga = top + 2;
    let meglio = null, hMeglio = 1e9;
    pag.querySelectorAll('[id],[data-pid],[id] > *').forEach(function(el){
      const r = el.getBoundingClientRect();
      if (r.height < 24 || r.top > riga || r.bottom <= riga) return;
      if (r.height < hMeglio){ meglio = el; hMeglio = r.height; }
    });
    if (!meglio) return null;
    let chiave = '';
    const esc = (window.CSS && CSS.escape) ? CSS.escape : function(s){ return String(s).replace(/[^\w-]/g, '\\$&'); };
    if (meglio.id) chiave = '#' + esc(meglio.id);
    else if (meglio.getAttribute('data-pid')) chiave = '[data-pid="' + String(meglio.getAttribute('data-pid')).replace(/["\\]/g, '\\$&') + '"]';
    else {
      const pa = meglio.parentElement; if (!pa || !pa.id) return null;
      chiave = '#' + esc(pa.id) + ' > :nth-child(' + (Array.prototype.indexOf.call(pa.children, meglio) + 1) + ')';
    }
    return { chiave: chiave, delta: Math.round(meglio.getBoundingClientRect().top - top) };
  }catch(_){ return null; }
}
function blkScrollSegna(pag){
  const a = blkScrollAncora(pag);
  BLK_SCROLL.y = pag.scrollTop; BLK_SCROLL.at = Date.now();
  BLK_SCROLL.chiave = a ? a.chiave : ''; BLK_SCROLL.delta = a ? a.delta : 0;
  try{ localStorage.setItem(BLK_SCROLL.k, JSON.stringify({ y: BLK_SCROLL.y, at: BLK_SCROLL.at, chiave: BLK_SCROLL.chiave, delta: BLK_SCROLL.delta })); }catch(_){ }
}
function blkScrollLeggi(){
  if (BLK_SCROLL.at) return BLK_SCROLL;
  try{ const s = JSON.parse(localStorage.getItem(BLK_SCROLL.k) || 'null'); if (s && s.at) Object.assign(BLK_SCROLL, { y: +s.y || 0, at: +s.at || 0, chiave: s.chiave || '', delta: +s.delta || 0 }); }catch(_){ }
  return BLK_SCROLL;
}
/** Dove deve stare la pagina adesso: l'elemento di riferimento al suo posto, o (se non c'e' piu') lo scrollTop di prima. */
function blkScrollVoluto(pag, s){
  if (s.chiave){
    try{
      const el = pag.querySelector(s.chiave);
      if (el && el.getClientRects().length) return blkScrollPerAncora(pag.scrollTop, el.getBoundingClientRect().top, pag.getBoundingClientRect().top, s.delta);
    }catch(_){ }
  }
  return s.y;
}
function blkScrollRimetti(pag){
  const s = blkScrollLeggi();
  if (!blkScrollDaRimettere(s.y, s.at, Date.now())) return false;
  const t0 = Date.now();
  let fine = false, ro = null, mo = null, giro = 0;
  const metti = function(){
    if (fine) return;
    if (BLK_SCROLL.mano > t0 || !pag.classList.contains('active') || Date.now() - t0 > BLK_SCROLL.durataMs){ basta(); return; }
    const v = blkScrollVoluto(pag, s);
    if (Math.abs(pag.scrollTop - v) > 2) pag.scrollTop = v;
  };
  const basta = function(){
    fine = true; clearInterval(giro);
    try{ if (ro) ro.disconnect(); }catch(_){ } try{ if (mo) mo.disconnect(); }catch(_){ }
  };
  metti();
  try{ if (typeof ResizeObserver === 'function'){ ro = new ResizeObserver(metti); Array.prototype.forEach.call(pag.children, function(c){ ro.observe(c); }); const h = document.getElementById('blHost'); if (h) Array.prototype.forEach.call(h.children, function(c){ ro.observe(c); }); } }catch(_){ }
  try{ if (typeof MutationObserver === 'function'){ mo = new MutationObserver(metti); mo.observe(pag, { childList: true, subtree: true }); } }catch(_){ }
  giro = setInterval(metti, 120);
  return true;
}
(function(){
  if (typeof document === 'undefined') return;
  ['touchstart', 'wheel', 'pointerdown'].forEach(function(ev){ document.addEventListener(ev, function(){ BLK_SCROLL.mano = Date.now(); }, { passive: true, capture: true }); });
  document.addEventListener('fl:screen', function(e){
    const ora = e && e.detail, prima = BLK_SCROLL.prima;
    BLK_SCROLL.prima = ora;
    const pag = document.getElementById('s-blocco'); if (!pag || ora === prima) return;
    /* si esce dalla pagina: go() non tocca la schermata che lascia, il suo scrollTop e i suoi elementi sono ancora quelli di un attimo fa */
    if (prima === 's-blocco') blkScrollSegna(pag);
    if (ora === 's-blocco') blkScrollRimetti(pag);
  });
  /* l'app va in secondo piano mentre sei sulla pagina (un permesso nelle impostazioni di Android): la posizione resta anche se il
     WebView viene ricaricato */
  document.addEventListener('visibilitychange', function(){
    try{ const pag = document.getElementById('s-blocco'); if (document.hidden && pag && pag.classList.contains('active')) blkScrollSegna(pag); }catch(_){ }
  });
})();

/* 0.9.402 BUG-230, Andrea: "se la Modalita' severa e' in serie, il primo ingresso del giorno in DreamMap mostra un pannello di festa
   come quello del livello, senza coriandoli, con lo stesso testo del pannello sfumato della pagina della Modalita' severa (Giorno 2:
   ieri poteva essere un caso, oggi no). Serve a far sentire il progresso e a non voler rompere la serie". Una volta al giorno, dal
   secondo giorno della serie (il primo e' quello in cui la si accende, con l'app gia' aperta). Il testo e' blkStreakCopy, lo stesso
   di sevStreakFoot; il pannello e' lvFestaSemplice (levels.js). Mai durante intro e tour: flMomentoProtetto, poi flDopoProtetto.
   La serie dei giorni nell'app (le tappe) qui non c'entra: quella ha gia' il suo popover nell'intestazione. */
const BLK_SEV_FESTA_K = 'fl_sev_festa_giorno';
/** I giorni della serie della Modalita' severa, solo in lettura (sevStreakDays scrive e cancella: qui non si tocca niente). */
async function blkSevFestaGiorni(){
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.getStrictState !== 'function') return 0;
  let s = null;
  try{ s = await NATIVE.getStrictState(); }catch(_){ return 0; }
  if (!s || !(s.level >= 1)) return 0;
  let st = null; try{ st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null'); }catch(_){ st = null; }
  let start = st && st.start;
  if (!start){ try{ const a = localStorage.getItem('fl_sev_armed'); if (a && /^\d{4}-\d{2}-\d{2}$/.test(a)) start = a; }catch(_){ } }
  if (!start) return 0;
  return Math.max(0, blkDaysBetween(start, blkToday()) + 1);
}
let BLK_SEV_FESTA_GIRO = false;
async function blkSevFesta(){
  if (BLK_SEV_FESTA_GIRO || document.hidden) return;
  const oggi = blkToday();
  let vista = ''; try{ vista = localStorage.getItem(BLK_SEV_FESTA_K) || ''; }catch(_){ }
  if (vista === oggi) return;
  BLK_SEV_FESTA_GIRO = true;
  let n = 0;
  try{ n = await blkSevFestaGiorni(); }catch(_){ n = 0; }
  BLK_SEV_FESTA_GIRO = false;
  if (n < 2) return;
  const apri = function(){
    let v = ''; try{ v = localStorage.getItem(BLK_SEV_FESTA_K) || ''; }catch(_){ }
    if (v === blkToday() || typeof lvFestaSemplice !== 'function') return;
    /* un'altra festa gia' aperta (il livello): si riprova fra poco */
    if (document.getElementById('lvFesta')){ setTimeout(blkSevFesta, 10000); return; }
    const c = blkStreakCopy(n);
    if (!lvFestaSemplice({ badge: '🔥', numero: n, sopra: 'Modalità severa · giorno ' + n, titolo: c.t, testo: c.p, forte: c.f, cta: 'Continua così' })) return;
    try{ localStorage.setItem(BLK_SEV_FESTA_K, blkToday()); }catch(_){ }
  };
  if (typeof flMomentoProtetto === 'function' && flMomentoProtetto() && typeof flDopoProtetto === 'function') flDopoProtetto(apri, 'sev-festa');
  else apri();
}
setTimeout(blkSevFesta, 5000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(blkSevFesta, 2500); });
document.addEventListener('fl:giorno', function(){ setTimeout(blkSevFesta, 2500); });
