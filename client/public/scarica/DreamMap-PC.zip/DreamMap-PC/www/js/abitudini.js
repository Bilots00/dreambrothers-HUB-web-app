/* ===========================================================================================
   LE ABITUDINI MISURATE (0.9.397, prefisso abt)

   Andrea: "nella scheda Azione aggiungi come abitudini il sonno, il focus, il riposo, i respiri, il task switching, l'uso del PC
   e le ore di lavoro, misurate con i dati che l'app ha gia'. Il binge watching e' sbagliato: un podcast mentre guidi non e'
   binge watching. Il Genio non ripete il tempo di schermo: dice cosa ha gia' letto e guarda come ti svegli. E chiede come ti
   senti di energia, per confrontarlo con quello che misura".

   NIENTE CONTI NUOVI. I numeri vengono dalle funzioni che li fanno gia':
     · sonno, focus e riposo: scCompute(scReportPunteggi(giorno)) (scores.js), gli stessi della scheda Profilo;
     · la notte e la sveglia: la notte del motore unico (sonno-motore.js: sveglia, allarme, rimandi, svegliaDa);
     · la dopamina e i cambi d'app: il motore della dopamina (dopamina-motore.js: contatori.cambi e contatori.attivoMin),
       per oggi in DP.dett e per i giorni chiusi nella storia (fl_dopa_giorni_v2, dpStoria);
     · i video di ogni giorno: i granelli del telefono che legge gia' la dopamina (dpGraniTelefono), riassunti qui
       (abtGiornoVideo) e salvati nel giorno chiuso della storia;
     · il Full Focus (ffHist), i respiri (rsStorico), il computer (pcMedia, la cache fl_pc_usage).
   Un'abitudine senza dati dice cosa serve per misurarla: mai un numero inventato.

   La parte pura (niente DOM, niente localStorage) si prova con node tools/test-lettura-397.js.
   =========================================================================================== */

/* LE SOGLIE, raccolte da Andrea il 27/11/2026. Accanto a ognuna, quale capo della forchetta si prende e perche'. */
const ABT_SOGLIE = {
  /* BINGE WATCHING: sessioni lunghe e continue di video, almeno 2-3 ore di fila (o 3-4 episodi); diventa un'abitudine quando
     si ripete piu' sere a settimana (3-4 su 7) per almeno 3-4 settimane. */
  bingeBucoMin: 10,      // due pezzi di video a meno di 10 minuti sono la stessa sessione "di fila" (la pausa fra due episodi)
  bingePassaggioMs: 60000, // un pezzo sotto il minuto non allunga niente: e' un'occhiata, non un episodio
  bingeSerieMin: 120,    // serie e film (Netflix, Prime Video, Disney+, RaiPlay...): 2 ore di fila, il capo basso (3 episodi da 40')
  bingeYtMin: 180,       // YouTube e i video lunghi: 3 ore di fila, il capo alto, perche' spesso e' sottofondo. Le serie pesano di piu'
  bingeYtPezzoMin: 30,   // una sessione di YouTube fatta di pezzi lunghi, senza toccare niente, puo' essere un podcast...
  bingeYtPezzoQuota: 0.6, // ...se piu' del 60% del tempo sta in pezzi cosi': si dice in modo neutro, non si accusa
  bingeSereSett: 3,      // 3 sere su 7 (il capo basso di 3-4)
  bingeSettimane: 3,     // per 3 settimane delle ultime 4 (il capo basso di 3-4)
  bingeGiorniDati: 21,   // sotto le 3 settimane di dati non si puo' dire che e' un'abitudine
  /* TASK SWITCHING: attenzione frammentata quando si cambia app o compito ogni 1-5 minuti; task switching sporadico con
     un'interruzione ogni 15-20 minuti. (Le stesse soglie della dispersione in dopamina-config.js.) */
  switchMoltoMin: 1,     // un cambio al minuto o piu': frammentata del tutto
  switchFrammMin: 5,     // un cambio ogni 5 minuti o meno: frammentata
  switchSporadMin: 15,   // un cambio ogni 15 minuti o piu': sporadico (il capo basso di 15-20)
  switchAttivoMin: 30,   // sotto la mezz'ora di schermo non si dice niente
  /* FOCUS: focus vero dopo 15-20 minuti senza interruzioni, flusso dopo 20-30. Una sessione di Full Focus e' una scelta
     dichiarata: qui si conta il focus vero da 20 minuti e il flusso da 30, i capi alti, per non dire "flusso" troppo presto.
     Dopo un'interruzione servono circa 23 minuti per tornare alla stessa profondita' (Gloria Mark, University of California,
     Irvine, "The Cost of Interrupted Work: More Speed and Stress", 2008). */
  focusVeroMin: 20,
  flussoMin: 30,
  rientroMin: 23,
  /* LA SVEGLIA: servono almeno 3 notti misurate; un orario e' "regolare" se in media si sposta meno di 45 minuti */
  svegliaNottiMin: 3,
  svegliaRegolareMin: 45,
  lavoroMaxMs: 8 * 3600000  // l'inizio del lavoro si cerca nelle 8 ore dopo la sveglia
};

/* ---------- i giorni ---------- */
function abtChiave(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function abtMezzanotte(t){ const d = new Date(t == null ? Date.now() : t); d.setHours(0, 0, 0, 0); return d.getTime(); }
/** La mezzanotte di `n` giorni prima (rispetta l'ora legale: si torna indietro di calendario, non di 24 ore). */
function abtGiornoPrima(oggi, n){ const d = new Date(abtMezzanotte(oggi)); d.setDate(d.getDate() - n); return d.getTime(); }
function abtMinuti(ms){ return Math.round((ms || 0) / 60000); }
function abtOre(min){
  min = Math.max(0, Math.round(min || 0));
  if (min < 60) return min + (min === 1 ? ' minuto' : ' minuti');
  const h = Math.floor(min / 60), r = min % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '');
}
function abtOreCorte(min){ min = Math.max(0, Math.round(min || 0)); if (min < 60) return min + ' min'; const h = Math.floor(min / 60), r = min % 60; return h + ' h' + (r ? ' ' + r + ' min' : ''); }
function abtOra(t){ const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function abtOraDaMin(m){ m = Math.round(m); return Math.floor(m / 60) % 24 + ':' + String(m % 60).padStart(2, '0'); }
function abtVirgola(v, dec){ return Number(v).toFixed(dec == null ? 1 : dec).replace('.', ','); }
/** Un numero detto come lo dice una persona: 4, 3,5 (mai 4,0). */
function abtNum(v){ v = Math.round((+v || 0) * 10) / 10; return Number.isInteger(v) ? String(v) : abtVirgola(v, 1); }

/* ---------- il binge watching ---------- */
/* YouTube Music e le app che si ascoltano e basta non sono video: non entrano mai. */
const ABT_NON_VIDEO = /youtube\.music|apps\.youtube\.music|youtubemusic|spotify|soundcloud|podcast|audible|deezer|tidal|castbox|radio/;
const ABT_SERIE = /netflix|primevideo|amazon\.avod|amazon\.video|disney|hbo|\.max\b|wbd\.|raiplay|mediaset|infinity|crunchyroll|paramount|skygo|sky\.go|nowtv|now\.tv|appletv|tv\.apple|timvision|discovery|pluto|rakuten|mubi|chili/;
const ABT_VIDEO = /youtube|twitch|vimeo|dailymotion|dazn|kick\.com/;
/** 'serie' (serie e film), 'yt' (YouTube e i video che possono essere sottofondo) o '' (non e' un video). */
function abtVideoTipo(p, l){
  const x = (String(p || '') + ' ' + String(l || '')).toLowerCase();
  if (!x.trim() || ABT_NON_VIDEO.test(x)) return '';
  if (ABT_SERIE.test(x)) return 'serie';
  if (ABT_VIDEO.test(x)) return 'yt';
  return '';
}
/**
 * Le sessioni continue di video di una giornata, dai granelli del telefono ({ p, l, s, ms } o { s, e }).
 * Pezzi della stessa sessione a meno di bingeBucoMin minuti; un pezzo sotto il minuto non allunga niente.
 * Ogni sessione: { s, e, min, serieMin, ytMin, equivMin, lunga, dubbio }.
 *   · equivMin: i minuti "pesati": quelli delle serie valgono interi, quelli di YouTube due terzi (2 ore su 3);
 *   · lunga: equivMin >= bingeSerieMin (2 ore di serie, o 3 di YouTube);
 *   · dubbio: soprattutto YouTube, almeno 2 ore, e fatta di pezzi lunghi senza toccare niente: puo' essere un podcast.
 *     Una sessione dubbia non e' mai lunga: non si conta come binge watching, se ne parla in modo neutro.
 */
function abtSessioniVideo(grani, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  const pezzi = (grani || []).map(function(g){
    const s = +g.s, ms = g.ms != null ? +g.ms : (+g.e - +g.s);
    return { s: s, e: s + ms, ms: ms, tipo: abtVideoTipo(g.p, g.l) };
  }).filter(function(g){ return g.tipo && isFinite(g.s) && g.ms >= C.bingePassaggioMs; })
    .sort(function(a, b){ return a.s - b.s; });
  const out = [];
  let cur = null;
  pezzi.forEach(function(g){
    if (cur && g.s - cur.e <= C.bingeBucoMin * 60000){ cur.e = Math.max(cur.e, g.e); cur.pezzi.push(g); }
    else { if (cur) out.push(cur); cur = { s: g.s, e: g.e, pezzi: [g] }; }
  });
  if (cur) out.push(cur);
  const peso = C.bingeSerieMin / C.bingeYtMin;
  return out.map(function(x){
    let serie = 0, yt = 0, lunghi = 0;
    x.pezzi.forEach(function(g){ if (g.tipo === 'serie') serie += g.ms; else yt += g.ms; if (g.tipo === 'yt' && g.ms >= C.bingeYtPezzoMin * 60000) lunghi += g.ms; });
    const serieMin = serie / 60000, ytMin = yt / 60000, equiv = serieMin + ytMin * peso;
    const soloYt = ytMin > serieMin;
    const dubbio = soloYt && ytMin >= C.bingeSerieMin && yt > 0 && lunghi / yt >= C.bingeYtPezzoQuota;
    return { s: x.s, e: x.e, min: Math.round((serie + yt) / 60000), serieMin: Math.round(serieMin), ytMin: Math.round(ytMin),
             equivMin: Math.round(equiv), lunga: !dubbio && equiv >= C.bingeSerieMin, dubbio: dubbio };
  });
}
/**
 * Il riassunto di una giornata, quello che resta salvato nel giorno chiuso della dopamina:
 * { lunghe, dubbie, maxMin, serie, primoProd }. primoProd = l'ora del primo uso produttivo del telefono
 * (un'app segnata come produttiva, almeno 3 minuti, dalle 4 del mattino): serve a dire quando comincia il lavoro.
 */
function abtGiornoVideo(grani, cfgIn){
  const ss = abtSessioniVideo(grani, cfgIn);
  const lunghe = ss.filter(function(x){ return x.lunga; });
  let primoProd = 0;
  (grani || []).forEach(function(g){
    const ms = g.ms != null ? +g.ms : (+g.e - +g.s);
    if (!(g.di != null && +g.di <= 0.1) || ms < 3 * 60000 || (g.dev && g.dev !== 'telefono')) return;
    if (new Date(+g.s).getHours() < 4) return;
    if (!primoProd || +g.s < primoProd) primoProd = +g.s;
  });
  return { lunghe: lunghe.length, dubbie: ss.filter(function(x){ return x.dubbio; }).length,
           maxMin: ss.reduce(function(m, x){ return Math.max(m, x.lunga ? x.min : 0); }, 0),
           serie: lunghe.some(function(x){ return x.serieMin >= x.ytMin; }), primoProd: primoProd };
}
/**
 * IL VERDETTO, sulle ultime 4 settimane. `giorni` = { 'YYYY-MM-DD': riassunto di abtGiornoVideo } solo per i giorni di cui
 * ci sono i dati (un giorno che manca non e' un giorno senza video: e' un giorno che non conosciamo).
 * livello: 'abitudine' | 'episodi' | 'dubbio' | 'no' | 'senza'.
 */
function abtBinge(giorni, oggi, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  giorni = giorni || {};
  const sere = [0, 0, 0, 0], datiSett = [0, 0, 0, 0];
  let dati = 0, lunghi = 0, dubbi = 0, serie = 0, maxMin = 0;
  for (let i = 0; i < 28; i++){
    const g = giorni[abtChiave(abtGiornoPrima(oggi || Date.now(), i))];
    if (!g) continue;
    const w = Math.floor(i / 7);
    dati++; datiSett[w]++;
    if (g.lunghe > 0){ sere[w]++; lunghi++; if (g.serie) serie++; maxMin = Math.max(maxMin, g.maxMin || 0); }
    else if (g.dubbie > 0) dubbi++;
  }
  const settimane = sere.filter(function(n){ return n >= C.bingeSereSett; }).length;
  const conDati = datiSett.filter(function(n){ return n > 0; }).length;
  const media = conDati ? sere.reduce(function(a, n){ return a + n; }, 0) / conDati : 0;
  let livello = 'senza';
  if (settimane >= C.bingeSettimane) livello = 'abitudine';
  else if (lunghi > 0) livello = 'episodi';
  else if (dubbi > 0) livello = 'dubbio';
  else if (dati > 0) livello = 'no';
  const v = { livello: livello, giorniDati: dati, giorniLunghi: lunghi, giorniDubbi: dubbi, giorniSerie: serie,
              settimane: settimane, sereSettimana: Math.round(media * 10) / 10, maxMin: maxMin,
              pochiDati: dati < C.bingeGiorniDati && livello !== 'abitudine' };
  v.testo = abtBingeTesto(v, C);
  return v;
}
/** Le parole del verdetto: neutre, mai un'accusa. Un giorno solo non e' un'abitudine, e un video lungo puo' essere un podcast. */
function abtBingeTesto(v, C){
  C = C || ABT_SOGLIE;
  let t;
  if (v.livello === 'abitudine') t = 'Sessioni di video di ' + (C.bingeSerieMin / 60) + ' ore o più di fila, ' + abtNum(v.sereSettimana) + ' sere a settimana da ' + v.settimane + ' settimane: è diventata un’abitudine.';
  else if (v.livello === 'episodi') t = v.giorniLunghi === 1 ? 'Una sessione lunga di video in un giorno solo: un giorno solo non è un’abitudine.'
    : 'Sessioni lunghe di video in ' + v.giorniLunghi + ' giorni su ' + v.giorniDati + ': non è ancora un’abitudine.';
  else if (v.livello === 'dubbio') t = 'Ci sono sessioni lunghe su YouTube: possono essere video o un podcast in sottofondo, dai dati non si capisce.';
  else if (v.livello === 'no') t = 'Nessuna sessione di video di ' + (C.bingeSerieMin / 60) + ' ore di fila.';
  else t = 'Per riconoscere il binge watching servono i dati di utilizzo di qualche settimana.';
  if (v.pochiDati && v.livello !== 'senza') t += ' Per dire se è un’abitudine servono ' + (C.bingeGiorniDati / 7) + ' settimane di dati: per ora ne ho ' + v.giorniDati + (v.giorniDati === 1 ? ' giorno.' : ' giorni.');
  return t;
}

/* ---------- il task switching ---------- */
/** Ogni quanti minuti si cambia app, dai contatori del motore della dopamina. null = troppo poco schermo per dirlo. */
function abtSwitch(attivoMin, cambi, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  attivoMin = +attivoMin || 0; cambi = +cambi || 0;
  if (attivoMin < C.switchAttivoMin) return null;
  const ogni = cambi > 0 ? attivoMin / cambi : attivoMin;
  let k, t, stato;
  if (ogni <= C.switchMoltoMin){ k = 'molto'; t = 'Attenzione molto frammentata'; stato = 'cambia'; }
  else if (ogni <= C.switchFrammMin){ k = 'frammentata'; t = 'Attenzione frammentata'; stato = 'cambia'; }
  else if (ogni < C.switchSporadMin){ k = 'spesso'; t = 'Interruzioni frequenti'; stato = 'neutro'; }
  else { k = 'sporadico'; t = 'Task switching sporadico'; stato = 'tieni'; }
  return { ogniMin: Math.round(ogni * 10) / 10, k: k, t: t, stato: stato, cambi: cambi, attivoMin: attivoMin };
}
/** Il focus di una sessione di Full Focus, in minuti: 'breve', 'vero' o 'flusso'. */
function abtFocusLivello(min, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  return min >= C.flussoMin ? 'flusso' : (min >= C.focusVeroMin ? 'vero' : 'breve');
}
/** Le sessioni di Full Focus di una finestra (le righe di fl_ff_hist): quante, di focus vero, di flusso, i minuti. */
function abtFocusSessioni(hist, da, a, cfgIn){
  const l = (hist || []).filter(function(x){ return x && !x.meditazione && x.tag !== 'meditazione' && +x.at >= da && +x.at <= (a || Infinity); });
  let vero = 0, flusso = 0, min = 0;
  l.forEach(function(x){
    const m = x.spentMs ? x.spentMs / 60000 : (x.ok ? (x.min || 25) : 0);
    min += m;
    const lv = abtFocusLivello(m, cfgIn);
    if (lv !== 'breve') vero++;
    if (lv === 'flusso') flusso++;
  });
  return { n: l.length, vero: vero, flusso: flusso, min: Math.round(min) };
}

/* ---------- la sveglia ---------- */
/**
 * Come ti svegli, dalle notti del motore del sonno. `notti` = [{ k, n: { ok, sveglia, allarme, rimandi, svegliaDa } }];
 * `lavoro` = { k: l'ora in cui e' cominciato il lavoro quel giorno } (la prima sessione di Full Focus o il primo uso produttivo).
 * pronto = almeno svegliaNottiMin notti misurate: sotto, il Genio fa le domande.
 */
function abtSveglia(notti, lavoro, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  const ok = (notti || []).filter(function(x){ return x && x.n && x.n.ok && x.n.sveglia > 0; });
  const conSv = ok.filter(function(x){ return x.n.svegliaDa === 'sveglia' || x.n.allarme > 0 || x.n.rimandi > 0; });
  const rimandi = conSv.reduce(function(a, x){ return a + (+x.n.rimandi || 0); }, 0);
  const orari = ok.map(function(x){ const d = new Date(x.n.sveglia); return d.getHours() * 60 + d.getMinutes(); });
  const media = orari.length ? orari.reduce(function(a, m){ return a + m; }, 0) / orari.length : 0;
  const scarto = orari.length ? orari.reduce(function(a, m){ return a + Math.abs(m - media); }, 0) / orari.length : 0;
  const attese = [];
  ok.forEach(function(x){
    const t = lavoro && lavoro[x.k];
    if (t && t > x.n.sveglia && t - x.n.sveglia <= C.lavoroMaxMs) attese.push((t - x.n.sveglia) / 60000);
  });
  return {
    pronto: ok.length >= C.svegliaNottiMin, notti: ok.length,
    conSveglia: conSv.length, daSolo: ok.length - conSv.length,
    rimandiMedia: conSv.length ? Math.round(rimandi / conSv.length * 10) / 10 : 0,
    giorniRimandi: conSv.filter(function(x){ return x.n.rimandi > 0; }).length,
    oraMin: Math.round(media), scartoMin: Math.round(scarto), regolare: orari.length >= 2 && scarto <= C.svegliaRegolareMin,
    lavoroMin: attese.length ? Math.round(attese.reduce(function(a, m){ return a + m; }, 0) / attese.length) : null,
    lavoroGiorni: attese.length
  };
}
/** Le righe che il Genio mostra quando i dati della sveglia ci sono: [emoji, titolo, riga]. */
function abtSvegliaRighe(sv){
  if (!sv || !sv.pronto) return [];
  const r = [];
  r.push(['⏰', sv.conSveglia + (sv.conSveglia === 1 ? ' giorno' : ' giorni') + ' con la sveglia', sv.daSolo ? sv.daSolo + (sv.daSolo === 1 ? ' giorno ti sei svegliato da solo.' : ' giorni ti sei svegliato da solo.') : 'Non ti sei mai svegliato da solo.']);
  if (sv.conSveglia) r.push(['🔁', sv.giorniRimandi ? 'La rimandi ' + abtNum(sv.rimandiMedia) + (sv.rimandiMedia === 1 ? ' volta' : ' volte') + ' in media' : 'Non la rimandi mai',
    sv.giorniRimandi ? 'Succede in ' + sv.giorniRimandi + ' mattine su ' + sv.conSveglia + '.' : 'Quando suona, ti alzi.']);
  r.push(['🌅', 'Ti svegli verso le ' + abtOraDaMin(sv.oraMin), sv.regolare ? 'Quasi sempre alla stessa ora.' : 'L’ora cambia di circa ' + abtOre(sv.scartoMin) + ' da un giorno all’altro.']);
  r.push(['💼', sv.lavoroMin != null ? 'Dalla sveglia al lavoro: ' + abtOre(sv.lavoroMin) : 'L’inizio del lavoro non l’ho ancora visto',
    sv.lavoroMin != null ? 'In media, su ' + sv.lavoroGiorni + (sv.lavoroGiorni === 1 ? ' giorno.' : ' giorni.') : 'Lo misuro dalla prima sessione di Full Focus della mattina.']);
  return r;
}
/* LE DOMANDE AL POSTO DEI DATI: compaiono solo quando i dati non ci sono. Quattro o sei risposte, mai cinque. */
const ABT_DOMANDE_SV = [
  { k: 'ora', t: 'A che ora ti svegli di solito?', o: [['🌌', 'Prima delle 6'], ['🌅', 'Fra le 6 e le 7'], ['☀️', 'Fra le 7 e le 8'], ['🕗', 'Fra le 8 e le 9'], ['🕘', 'Fra le 9 e le 10'], ['🛌', 'Dopo le 10']] },
  { k: 'stessa', t: 'Ti svegli sempre alla stessa ora?', o: [['⏱️', 'Sempre alla stessa ora'], ['🙂', 'Quasi sempre'], ['🔀', 'Cambia spesso'], ['🎲', 'Ogni giorno è diversa']] },
  { k: 'usa', t: 'Usi la sveglia?', o: [['⏰', 'Sì, sempre'], ['💼', 'Solo nei giorni di lavoro'], ['🤷', 'A volte'], ['🌞', 'No, mi sveglio da solo']] },
  { k: 'rimanda', t: 'Quando suona, la rimandi?', o: [['🚀', 'Mai, mi alzo subito'], ['1️⃣', 'Una volta'], ['🔁', 'Due o tre volte'], ['😴', 'Più di tre volte']] },
  { k: 'lavoro', t: 'Quanto tempo passa dalla sveglia a quando ti metti al lavoro?', o: [['⚡', 'Meno di mezz’ora'], ['🚶', 'Fra mezz’ora e un’ora'], ['🐢', 'Fra una e due ore'], ['🛋️', 'Più di due ore']] }
];
/** Quali domande fare: tutte senza le notti; solo quella sul lavoro se le notti ci sono ma l'inizio del lavoro no; nessuna se c'e' tutto.
    `risposte` = quelle date finora: chi non usa la sveglia non si sente chiedere se la rimanda. */
function abtDomandeSveglia(sv, risposte){
  risposte = risposte || {};
  let l;
  if (!sv || !sv.pronto) l = ABT_DOMANDE_SV.slice();
  else if (sv.lavoroMin == null) l = ABT_DOMANDE_SV.filter(function(d){ return d.k === 'lavoro'; });
  else l = [];
  return l.filter(function(d){ return !(d.k === 'rimanda' && risposte.usa === 3); });
}
/** I minuti fra sveglia e lavoro detti dalla risposta (il centro della fascia), per il confronto con l'energia. */
const ABT_LAVORO_RISPOSTA = [20, 45, 90, 150];

/* ---------- quello che il Genio ha gia' letto ---------- */
const ABT_NUMERI = ['Nessuna', 'Una', 'Due', 'Tre', 'Quattro'];
/**
 * "Quattro cose le ho gia' lette: ...": i tre punteggi della scheda Profilo e la dopamina, se c'e'.
 * p = { sleep, focus, rest } (scCompute), dopa = DP.L o null. Torna { frase, voci: [[emoji, nome, valore]] }.
 */
function abtLetti(p, dopa){
  const voci = [];
  const num = function(v){ return v != null && isFinite(+v); };
  if (p && num(p.sleep)) voci.push(['🌙', 'il sonno', 'Sonno', String(Math.round(p.sleep)), 'sleep']);
  if (p && num(p.focus)) voci.push(['⏳', 'il focus', 'Focus', String(Math.round(p.focus)), 'focus']);
  if (p && num(p.rest)) voci.push(['🌲', 'il riposo', 'Riposo', String(Math.round(p.rest)), 'rest']);
  if (num(dopa)) voci.push(['⛽', 'la dopamina', 'Dopamina', abtNum(dopa), 'dopa']);
  if (!voci.length) return { frase: '', voci: [] };
  /* 0.9.400 BUG-173, Andrea: "dopo i due punti si va a capo, e l'elenco ripete le card che sono subito sotto". La frase dice quante sono,
     le carte dicono quali. Ogni voce porta la sua chiave (sleep, focus, rest, dopa) per il perche' e il dettaglio */
  const frase = voci.length === 1 ? 'Una cosa l’ho già letta.' : ABT_NUMERI[voci.length] + ' cose le ho già lette.';
  return { frase: frase, voci: voci.map(function(v){ return [v[0], v[2], v[3], v[4]]; }) };
}

/* ---------- la domanda di controllo sull'energia ---------- */
/* La scala, dal basso: le parole dei criteri di Andrea. Energia alta: poco attrito a iniziare, resilienza agli intoppi,
   obiettivi chiari, ritmo costante. Energia bassa: procrastinazione, fatica prima di cominciare, pilota automatico
   (scrolling, binge watching), bassa tolleranza alla frustrazione. */
/* 0.9.400 BUG-172: ogni gradino ha la sua emoji, come le facce del controllo dell'umore */
const ABT_ENERGIA = [[1, 'A terra', '🪫'], [2, 'Scarico', '😮‍💨'], [3, 'Così così', '😐'], [4, 'Carico', '🙂'], [5, 'Pieno di energia', '⚡']];
const ABT_ENERGIA_RIGHE = [
  ['⚡', 'Energia alta', 'Cominci senza fatica, reggi gli intoppi, sai cosa fare e tieni il ritmo.'],
  ['🪫', 'Energia bassa', 'Rimandi, fai fatica a cominciare, vai avanti col pilota automatico e ti arrabbi presto.'],
  ['📅', 'Un giorno no è normale', 'Un calo di uno o due giorni capita a tutti. Settimane senza miglioramento sono un’altra cosa.']
];
/**
 * Quanta energia dicono i numeri, sulla stessa scala da 1 a 5. m = { sonno, riposo, dopamina, lavoroMin }.
 * Ogni misura diventa un numero da 0 a 1 (sonno e riposo /100, la dopamina /100 con la base a 50, dalla sveglia al lavoro
 * mezz'ora o meno = 1 e tre ore o piu' = 0); servono almeno due misure, altrimenti null.
 */
function abtEnergiaStima(m){
  m = m || {};
  const v = [];
  const n = function(x){ return x != null && isFinite(+x); };
  if (n(m.sonno)) v.push(Math.max(0, Math.min(1, +m.sonno / 100)));
  if (n(m.riposo)) v.push(Math.max(0, Math.min(1, +m.riposo / 100)));
  if (n(m.dopamina)) v.push(Math.max(0, Math.min(1, +m.dopamina / 100)));
  if (n(m.lavoroMin)) v.push(Math.max(0, Math.min(1, 1 - (+m.lavoroMin - 30) / 150)));
  if (v.length < 2) return null;
  return Math.round((1 + 4 * v.reduce(function(a, x){ return a + x; }, 0) / v.length) * 10) / 10;
}
/**
 * Il confronto fra la risposta (1-5) e la stima. distante = due punti o piu' di differenza.
 * storico = le righe di taratura salvate (abtRigaTaratura): se la risposta e' bassa da settimane, il Genio suggerisce con
 * delicatezza di parlarne con un medico o uno psicologo. Mai una diagnosi.
 */
function abtEnergiaConfronto(risposta, m, storico, adesso){
  const r = Math.max(1, Math.min(5, Math.round(+risposta || 0)));
  const stima = abtEnergiaStima(m);
  const out = { risposta: r, stima: stima, distante: false, verso: '', testo: '', nota: 'La dopamina è una stima che viene dal telefono, non una misura medica.', settimane: false, calo: '' };
  const cosa = [];
  if (m && m.sonno != null) cosa.push('sonno ' + Math.round(m.sonno));
  if (m && m.riposo != null) cosa.push('riposo ' + Math.round(m.riposo));
  if (m && m.dopamina != null) cosa.push('dopamina ' + abtNum(m.dopamina));
  const numeri = cosa.length ? ' (' + cosa.join(', ') + ')' : '';
  if (stima == null) out.testo = 'Me lo segno. Fra qualche giorno di dati potrò confrontarlo con quello che misuro.';
  else if (r - stima >= 2){ out.distante = true; out.verso = 'sopra';
    out.testo = 'Ti senti più carico di quello che dicono i miei numeri' + numeri + '. Può darsi che tu stia andando avanti con le riserve: il conto, di solito, arriva dopo.'; }
  else if (stima - r >= 2){ out.distante = true; out.verso = 'sotto';
    out.testo = 'I miei numeri di questi giorni sono buoni' + numeri + ', ma tu ti senti scarico. Conta di più come ti senti tu: il telefono vede solo una parte della giornata.'; }
  else out.testo = 'Quello che senti e quello che misuro vanno d’accordo' + numeri + '.';
  /* il calo: un giorno o due e' normale; settimane senza miglioramento sono un'altra cosa */
  const t = adesso || Date.now();
  const recenti = (storico || []).filter(function(x){ return x && +x.at > t - 28 * 86400000 && +x.at <= t; }).sort(function(a, b){ return a.at - b.at; });
  const bassi = recenti.filter(function(x){ return +x.risposta <= 2; });
  if (r <= 2){
    const alti = recenti.filter(function(x){ return +x.risposta >= 4; });
    const primoBasso = bassi.length ? bassi[0].at : t;
    const dopoAlti = alti.filter(function(x){ return x.at > primoBasso; }).length;
    if (bassi.length >= 3 && t - primoBasso >= 14 * 86400000 && !dopoAlti){
      out.settimane = true;
      out.calo = 'Mi dici di sentirti così da qualche settimana. Se non migliora, può aiutare parlarne con un medico o con uno psicologo: non è una diagnosi, è un modo di prenderti cura di te.';
    } else out.calo = 'Un giorno o due giù di energia capitano a tutti.';
  }
  return out;
}
/** La riga di taratura: la risposta accanto ai valori misurati quel giorno. Servira' a tarare la stima della dopamina. */
function abtRigaTaratura(risposta, m, adesso){
  m = m || {};
  const t = adesso || Date.now();
  const n = function(x){ return x != null && isFinite(+x) ? Math.round(+x * 10) / 10 : null; };
  return { giorno: abtChiave(t), at: t, risposta: Math.round(+risposta || 0), stima: abtEnergiaStima(m),
           sonno: n(m.sonno), focus: n(m.focus), riposo: n(m.riposo), dopamina: n(m.dopamina),
           lavoroMin: n(m.lavoroMin), lavoroDetto: n(m.lavoroDetto), conSveglia: m.conSveglia == null ? null : !!m.conSveglia,
           rimandi: n(m.rimandi) };
}
/** Una riga per giorno: la risposta di oggi prende il posto di quella di stamattina. Se ne tengono 180. */
function abtTaraturaAggiungi(lista, riga){
  const l = (Array.isArray(lista) ? lista : []).filter(function(x){ return x && x.giorno !== riga.giorno; });
  l.push(riga);
  return l.slice(-180);
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { ABT_SOGLIE, ABT_DOMANDE_SV, ABT_ENERGIA, ABT_ENERGIA_RIGHE, ABT_LAVORO_RISPOSTA, abtChiave, abtGiornoPrima,
    abtVideoTipo, abtSessioniVideo, abtGiornoVideo, abtBinge, abtBingeTesto, abtSwitch, abtFocusLivello, abtFocusSessioni,
    abtSveglia, abtSvegliaRighe, abtDomandeSveglia, abtLetti, abtEnergiaStima, abtEnergiaConfronto, abtRigaTaratura, abtTaraturaAggiungi };
}

/* ===========================================================================================
   LA PARTE CHE LEGGE (nel telefono): le stesse funzioni dell'app, nessun conto nuovo
   =========================================================================================== */
const ABT_TARATURA_KEY = 'fl_energia_taratura';   // [riga di abtRigaTaratura], una per giorno
const ABT_SV_RISPOSTE_KEY = 'fl_sveglia_risposte'; // { at, ora, stessa, usa, rimanda, lavoro } le risposte alle domande della sveglia
const ABT = { notti: {}, cache: {} };
function abtJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function abtTaratura(){ const l = abtJ(ABT_TARATURA_KEY, []); return Array.isArray(l) ? l : []; }
function abtTaraturaSalva(riga){ try{ localStorage.setItem(ABT_TARATURA_KEY, JSON.stringify(abtTaraturaAggiungi(abtTaratura(), riga))); return true; }catch(_){ return false; } }
function abtSvRisposte(){ const r = abtJ(ABT_SV_RISPOSTE_KEY, null); return (r && typeof r === 'object') ? r : null; }
function abtSvRisposteSalva(r){ try{ localStorage.setItem(ABT_SV_RISPOSTE_KEY, JSON.stringify(Object.assign({}, r, { at: Date.now() }))); }catch(_){ } }

/** I punteggi di un giorno (0 = oggi), gli stessi della scheda Profilo. null se il telefono non li ha. */
async function abtPunteggi(off){
  try{
    if (typeof scReportPunteggi !== 'function' || typeof scCompute !== 'function') return null;
    const r = await scReportPunteggi(off || 0);
    return r && r.granted ? scCompute(r) : null;
  }catch(_){ return null; }
}
/** Le notti degli ultimi n giorni, dal motore del sonno (le notti passate restano in memoria: non cambiano piu'). */
async function abtNotti(n){
  const out = [];
  for (let i = 0; i < (n || 14); i++){
    const k = abtChiave(abtGiornoPrima(Date.now(), i));
    let c = i > 0 ? ABT.notti[k] : null;
    if (!c){
      const p = await abtPunteggi(i);
      if (!p && i === 0) continue;
      if (!p) break;                                   // senza permesso, o oltre la storia del telefono
      c = { k: k, n: p.notte || null, sleep: p.sleep, rest: p.rest, focus: p.focus };
      if (i > 0) ABT.notti[k] = c;
    }
    out.push(c);
  }
  return out;
}
/** I giorni chiusi della dopamina, con oggi in cima (DP.dett): i cambi d'app, i minuti di schermo, i video. */
function abtGiorniDopa(){
  const g = Object.assign({}, (typeof dpGiorni === 'function') ? dpGiorni() : {});
  try{
    if (typeof DP !== 'undefined' && DP && DP.dett && DP.dett.ris && DP.dett.giorno){
      const c = DP.dett.ris.contatori || {};
      const tel = (DP.dett.grani || []).filter(function(x){ return !x.dev || x.dev === 'telefono'; });
      g[DP.dett.giorno] = Object.assign({}, g[DP.dett.giorno] || {}, { cambi: c.cambi, attivoMin: c.attivoMin, video: abtGiornoVideo(tel), oggi: true });
    }
  }catch(_){ }
  return g;
}
/** I giorni chiusi salvati prima della 0.9.397 non hanno il riassunto dei video: si rileggono, quattro per volta, con la stessa
    lettura della dopamina (dpGraniTelefono). Non si crea mai un giorno nuovo: quello lo fa dpStoria. */
async function abtVideoRiempi(){
  if (typeof dpGiorni !== 'function' || typeof dpGraniTelefono !== 'function' || typeof DP_GIORNI_KEY === 'undefined') return;
  if (ABT.riempi) return ABT.riempi;
  ABT.riempi = (async function(){
    const g = dpGiorni();
    let fatti = 0;
    for (let i = 1; i <= 28 && fatti < 4; i++){
      const from = abtGiornoPrima(Date.now(), i), k = abtChiave(from);
      if (!g[k] || g[k].video) continue;
      const gr = await dpGraniTelefono(from, abtGiornoPrima(Date.now(), i - 1));
      if (!gr) break;
      g[k].video = abtGiornoVideo(gr); fatti++;
    }
    if (fatti){ try{ localStorage.setItem(DP_GIORNI_KEY, JSON.stringify(g)); }catch(_){ } }
  })().catch(function(){ }).then(function(){ ABT.riempi = null; });
  return ABT.riempi;
}
/** Il verdetto sul binge watching, sui giorni che hanno il riassunto dei video. */
function abtBingeOra(){
  const g = abtGiorniDopa(), v = {};
  Object.keys(g).forEach(function(k){ if (g[k] && g[k].video) v[k] = g[k].video; });
  return abtBinge(v, Date.now());
}
/** L'ora in cui e' cominciato il lavoro, per giorno: la prima sessione di Full Focus o il primo uso produttivo del telefono. */
function abtLavoroPerGiorno(){
  const out = {};
  try{
    const hist = (typeof ffHist === 'function') ? ffHist() : abtJ('fl_ff_hist', []);
    (hist || []).forEach(function(x){
      if (!x || x.meditazione || x.tag === 'meditazione') return;
      const s = +x.start || (+x.at - (x.spentMs || (x.min || 25) * 60000));
      if (!s) return;
      const k = abtChiave(s);
      if (!out[k] || s < out[k]) out[k] = s;
    });
  }catch(_){ }
  const g = abtGiorniDopa();
  Object.keys(g).forEach(function(k){ const p = g[k] && g[k].video && g[k].video.primoProd; if (p && (!out[k] || p < out[k])) out[k] = p; });
  return out;
}
/** Come ti svegli negli ultimi 14 giorni. */
async function abtSvegliaLeggi(){
  const notti = await abtNotti(14);
  return abtSveglia(notti, abtLavoroPerGiorno());
}

/* ---------- le abitudini della scheda Azione ---------- */
/**
 * Le righe delle abitudini misurate, nel periodo della scheda (1, 7 o 30 giorni).
 * Ogni riga: { k, em, t, val, sub, stato: 'tieni' | 'cambia' | 'neutro' | 'manca' }. 'manca' = senza dati: sub dice cosa serve.
 */
async function abtAbitudini(per){
  per = per || 7;
  const giorni = Math.max(1, per), da = abtGiornoPrima(Date.now(), giorni - 1);
  const righe = [];
  /* sonno e riposo: la media dei punteggi dei giorni del periodo (al massimo sette letture) */
  const notti = await abtNotti(Math.min(giorni, 7));
  const media = function(k){ const l = notti.map(function(x){ return x[k]; }).filter(function(v){ return v != null && isFinite(v); }); return l.length ? { v: Math.round(l.reduce(function(a, x){ return a + x; }, 0) / l.length), n: l.length } : null; };
  const stato = function(v){ return v >= 70 ? 'tieni' : (v < 50 ? 'cambia' : 'neutro'); };
  const sn = media('sleep'), rp = media('rest');
  righe.push(sn ? { k: 'sonno', em: '🌙', t: 'Sonno', val: String(sn.v), sub: sn.n === 1 ? 'Il punteggio di stanotte.' : 'La media di ' + sn.n + ' notti.', stato: stato(sn.v) }
    : { k: 'sonno', em: '🌙', t: 'Sonno', val: '', sub: 'Per misurarlo serve l’accesso ai dati di utilizzo, e una notte col telefono fermo.', stato: 'manca' });
  /* il focus: le sessioni di Full Focus, con le soglie del focus vero e del flusso */
  const ff = abtFocusSessioni((typeof ffHist === 'function') ? ffHist() : abtJ('fl_ff_hist', []), da);
  /* 0.9.401 BUG-192, Andrea: "l'abitudine di focus e riposo della scheda Profilo". Il focus e' il punteggio Focus del Profilo (scCompute,
     la stessa lettura del sonno e del riposo); le sessioni di Full Focus restano nella riga sotto. Senza punteggio, le sessioni come prima */
  const fc = media('focus');
  if (fc) righe.push({ k: 'focus', em: '⏳', t: 'Focus', val: String(fc.v), sub: (fc.n === 1 ? 'Il punteggio di oggi.' : 'La media di ' + fc.n + ' giorni.') + (ff.n ? ' ' + (ff.n === 1 ? 'Una sessione di Full Focus.' : ff.n + ' sessioni di Full Focus.') : ''), stato: stato(fc.v) });
  else righe.push(ff.n ? { k: 'focus', em: '⏳', t: 'Focus', val: ff.n === 1 ? '1 sessione' : ff.n + ' sessioni', sub: (ff.n === 1 ? 'Una sessione di Full Focus' : ff.n + ' sessioni di Full Focus') + ', ' + (ff.vero === 1 ? 'una' : ff.vero) + ' di almeno ' + ABT_SOGLIE.focusVeroMin + ' minuti.', stato: ff.vero ? 'tieni' : 'neutro' }
    : { k: 'focus', em: '⏳', t: 'Focus', val: '', sub: 'Per misurarlo fai una sessione di Full Focus: il focus vero comincia dopo ' + ABT_SOGLIE.focusVeroMin + ' minuti.', stato: 'manca' });
  righe.push(rp ? { k: 'riposo', em: '🌲', t: 'Riposo', val: String(rp.v), sub: rp.n === 1 ? 'Il punteggio di oggi.' : 'La media di ' + rp.n + ' giorni.', stato: stato(rp.v) }
    : { k: 'riposo', em: '🌲', t: 'Riposo', val: '', sub: 'Per misurarlo serve l’accesso ai dati di utilizzo.', stato: 'manca' });
  /* i respiri */
  try{
    const rs = ((typeof rsStorico === 'function') ? rsStorico() : abtJ('fl_respiro', [])).filter(function(x){ return x && +x.at >= da; });
    const sec = rs.reduce(function(a, x){ return a + (x.sec || 0); }, 0);
    righe.push(rs.length ? { k: 'respiro', em: '🫁', t: 'Respirazione', val: String(rs.length), sub: (rs.length === 1 ? 'Un esercizio' : rs.length + ' esercizi') + ', ' + abtOre(sec / 60) + ' in tutto.', stato: 'tieni' }
      : { k: 'respiro', em: '🫁', t: 'Respirazione', val: '', sub: 'Per misurarla fai un esercizio di respirazione.', stato: 'manca' });
  }catch(_){ }
  /* il task switching: i cambi d'app del motore della dopamina, sui giorni che li hanno */
  const gd = abtGiorniDopa();
  let att = 0, cambi = 0;
  Object.keys(gd).forEach(function(k){ const x = gd[k]; if (k >= abtChiave(da) && x && x.attivoMin != null){ att += +x.attivoMin || 0; cambi += +x.cambi || 0; } });
  const sw = abtSwitch(att, cambi);
  righe.push(sw ? { k: 'switch', em: '🔀', t: 'Task switching', val: 'ogni ' + abtNum(sw.ogniMin < 10 ? sw.ogniMin : Math.round(sw.ogniMin)) + ' min', sub: sw.t + ({ molto: ': meno di un minuto fra un’app e l’altra.', frammentata: ': ' + ABT_SOGLIE.switchFrammMin + ' minuti o meno fra un’app e l’altra.', spesso: ': fra ' + ABT_SOGLIE.switchFrammMin + ' e ' + ABT_SOGLIE.switchSporadMin + ' minuti fra un’app e l’altra.', sporadico: ': ' + ABT_SOGLIE.switchSporadMin + ' minuti o più fra un’app e l’altra.' }[sw.k] || '.'), stato: sw.stato }
    : { k: 'switch', em: '🔀', t: 'Task switching', val: '', sub: 'Per misurarlo serve almeno mezz’ora di schermo letta dalla dopamina.', stato: 'manca' });
  /* il computer: l'uso e le ore di lavoro (le cose segnate come lavoro), dalla cache fl_pc_usage */
  let pc = null;
  try{ if (typeof pcMedia === 'function') pc = pcMedia(giorni); }catch(_){ pc = null; }
  if (!pc){ try{ const c = abtJ('fl_pc_usage', null); if (c && c.doc && typeof PC !== 'undefined'){ PC.doc = c.doc; pc = pcMedia(giorni); } }catch(_){ } }
  righe.push(pc ? { k: 'pc', em: '💻', t: 'Uso del PC', val: abtOreCorte(pc.min), sub: 'Al giorno, nei ' + pc.giorni + (pc.giorni === 1 ? ' giorno' : ' giorni') + ' in cui il computer era acceso.', stato: pc.min && pc.distr / pc.min >= 0.35 ? 'cambia' : 'neutro' }
    : { k: 'pc', em: '💻', t: 'Uso del PC', val: '', sub: 'Per misurarlo collega il computer a DreamMap.', stato: 'manca' });
  righe.push(pc && pc.prod > 0 ? { k: 'lavoro', em: '🛠️', t: 'Ore di lavoro', val: abtOreCorte(pc.prod), sub: 'Al giorno, sui programmi che hai segnato come lavoro.', stato: 'tieni' }
    : { k: 'lavoro', em: '🛠️', t: 'Ore di lavoro', val: '', sub: pc ? 'Per misurarle segna sul computer i programmi di lavoro.' : 'Per misurarle collega il computer e segna i programmi di lavoro.', stato: 'manca' });
  /* i video lunghi: solo quando c'e' qualcosa da dire, in modo neutro */
  const bg = abtBingeOra();
  if (bg.livello === 'episodi' || bg.livello === 'dubbio') righe.push({ k: 'video', em: '🍿', t: 'Video lunghi', val: '', sub: bg.testo, stato: 'neutro' });
  try{ abtVideoRiempi(); }catch(_){ }
  return { at: Date.now(), righe: righe, binge: bg };
}
