/* ===========================================================================================
   LE ABITUDINI MISURATE (0.9.397, prefisso abt)

   Andrea: "nella scheda Azione aggiungi come abitudini il sonno, il focus, il riposo, i respiri, il task switching, l'uso del PC
   e le ore di lavoro, misurate con i dati che l'app ha gia'. Il binge watching e' sbagliato: un podcast mentre guidi non e'
   binge watching. Il Genio non ripete il tempo di schermo: dice cosa ha gia' letto e guarda come ti svegli. E chiede come ti
   senti di energia, per confrontarlo con quello che misura".

   NIENTE CONTI NUOVI. I numeri vengono dalle funzioni che li fanno gia':
     · sonno, focus e riposo: scCompute(scReportPunteggi(giorno)) (scores.js), gli stessi della scheda Profilo;
     · la notte e la sveglia: la notte del motore unico (sonno-motore.js: sveglia, allarme, rimandi, svegliaDa);
     · la dopamina e i cambi d'app: il motore della dopamina (dopamina-motore.js: contatori.cambi e contatori.attivoMin),
       per oggi in DP.dett e per i giorni chiusi nella storia (fl_dopa_giorni_v2, dpStoria);
     · i video di ogni giorno: i granelli del telefono che legge gia' la dopamina (dpGraniTelefono), riassunti qui
       (abtGiornoVideo) e salvati nel giorno chiuso della storia;
     · il Full Focus (ffHist), i respiri (rsStorico), il computer (pcMedia, la cache fl_pc_usage).
   Un'abitudine senza dati dice cosa serve per misurarla: mai un numero inventato.

   La parte pura (niente DOM, niente localStorage) si prova con node tools/test-lettura-397.js.
   =========================================================================================== */

/* LE SOGLIE, raccolte da Andrea il 27/11/2026. Accanto a ognuna, quale capo della forchetta si prende e perche'. */
const ABT_SOGLIE = {
  /* BINGE WATCHING: sessioni lunghe e continue di video, almeno 2-3 ore di fila (o 3-4 episodi); diventa un'abitudine quando
     si ripete piu' sere a settimana (3-4 su 7) per almeno 3-4 settimane. */
  bingeBucoMin: 10,      // due pezzi di video a meno di 10 minuti sono la stessa sessione "di fila" (la pausa fra due episodi)
  bingePassaggioMs: 60000, // un pezzo sotto il minuto non allunga niente: e' un'occhiata, non un episodio
  bingeSerieMin: 120,    // serie e film (Netflix, Prime Video, Disney+, RaiPlay...): 2 ore di fila, il capo basso (3 episodi da 40')
  bingeYtMin: 180,       // YouTube e i video lunghi: 3 ore di fila, il capo alto, perche' spesso e' sottofondo. Le serie pesano di piu'
  bingeYtPezzoMin: 30,   // una sessione di YouTube fatta di pezzi lunghi, senza toccare niente, puo' essere un podcast...
  bingeYtPezzoQuota: 0.6, // ...se piu' del 60% del tempo sta in pezzi cosi': si dice in modo neutro, non si accusa
  bingeSereSett: 3,      // 3 sere su 7 (il capo basso di 3-4)
  bingeSettimane: 3,     // per 3 settimane delle ultime 4 (il capo basso di 3-4)
  bingeGiorniDati: 21,   // sotto le 3 settimane di dati non si puo' dire che e' un'abitudine
  /* TASK SWITCHING: attenzione frammentata quando si cambia app o compito ogni 1-5 minuti; task switching sporadico con
     un'interruzione ogni 15-20 minuti. (Le stesse soglie della dispersione in dopamina-config.js.) */
  switchMoltoMin: 1,     // un cambio al minuto o piu': frammentata del tutto
  switchFrammMin: 5,     // un cambio ogni 5 minuti o meno: frammentata
  switchSporadMin: 15,   // un cambio ogni 15 minuti o piu': sporadico (il capo basso di 15-20)
  switchAttivoMin: 30,   // sotto la mezz'ora di schermo non si dice niente
  /* FOCUS: focus vero dopo 15-20 minuti senza interruzioni, flusso dopo 20-30. Una sessione di Full Focus e' una scelta
     dichiarata: qui si conta il focus vero da 20 minuti e il flusso da 30, i capi alti, per non dire "flusso" troppo presto.
     Dopo un'interruzione servono circa 23 minuti per tornare alla stessa profondita' (Gloria Mark, University of California,
     Irvine, "The Cost of Interrupted Work: More Speed and Stress", 2008). */
  focusVeroMin: 20,
  flussoMin: 30,
  rientroMin: 23,
  /* LA SVEGLIA: servono almeno 3 notti misurate; un orario e' "regolare" se in media si sposta meno di 45 minuti */
  svegliaNottiMin: 3,
  svegliaRegolareMin: 45,
  lavoroMaxMs: 8 * 3600000  // l'inizio del lavoro si cerca nelle 8 ore dopo la sveglia
};

/* ---------- i giorni ---------- */
function abtChiave(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function abtMezzanotte(t){ const d = new Date(t == null ? Date.now() : t); d.setHours(0, 0, 0, 0); return d.getTime(); }
/** La mezzanotte di `n` giorni prima (rispetta l'ora legale: si torna indietro di calendario, non di 24 ore). */
function abtGiornoPrima(oggi, n){ const d = new Date(abtMezzanotte(oggi)); d.setDate(d.getDate() - n); return d.getTime(); }
function abtMinuti(ms){ return Math.round((ms || 0) / 60000); }
function abtOre(min){
  min = Math.max(0, Math.round(min || 0));
  if (min < 60) return min + (min === 1 ? ' minuto' : ' minuti');
  const h = Math.floor(min / 60), r = min % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '');
}
function abtOreCorte(min){ min = Math.max(0, Math.round(min || 0)); if (min < 60) return min + ' min'; const h = Math.floor(min / 60), r = min % 60; return h + ' h' + (r ? ' ' + r + ' min' : ''); }
function abtOra(t){ const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function abtOraDaMin(m){ m = Math.round(m); return Math.floor(m / 60) % 24 + ':' + String(m % 60).padStart(2, '0'); }
function abtVirgola(v, dec){ return Number(v).toFixed(dec == null ? 1 : dec).replace('.', ','); }
/** Un numero detto come lo dice una persona: 4, 3,5 (mai 4,0). */
function abtNum(v){ v = Math.round((+v || 0) * 10) / 10; return Number.isInteger(v) ? String(v) : abtVirgola(v, 1); }

/* ---------- il binge watching ---------- */
/* YouTube Music e le app che si ascoltano e basta non sono video: non entrano mai. */
const ABT_NON_VIDEO = /youtube\.music|apps\.youtube\.music|youtubemusic|spotify|soundcloud|podcast|audible|deezer|tidal|castbox|radio/;
const ABT_SERIE = /netflix|primevideo|amazon\.avod|amazon\.video|disney|hbo|\.max\b|wbd\.|raiplay|mediaset|infinity|crunchyroll|paramount|skygo|sky\.go|nowtv|now\.tv|appletv|tv\.apple|timvision|discovery|pluto|rakuten|mubi|chili/;
const ABT_VIDEO = /youtube|twitch|vimeo|dailymotion|dazn|kick\.com/;
/** 'serie' (serie e film), 'yt' (YouTube e i video che possono essere sottofondo) o '' (non e' un video). */
function abtVideoTipo(p, l){
  const x = (String(p || '') + ' ' + String(l || '')).toLowerCase();
  if (!x.trim() || ABT_NON_VIDEO.test(x)) return '';
  if (ABT_SERIE.test(x)) return 'serie';
  if (ABT_VIDEO.test(x)) return 'yt';
  return '';
}
/**
 * Le sessioni continue di video di una giornata, dai granelli del telefono ({ p, l, s, ms } o { s, e }).
 * Pezzi della stessa sessione a meno di bingeBucoMin minuti; un pezzo sotto il minuto non allunga niente.
 * Ogni sessione: { s, e, min, serieMin, ytMin, equivMin, lunga, dubbio }.
 *   · equivMin: i minuti "pesati": quelli delle serie valgono interi, quelli di YouTube due terzi (2 ore su 3);
 *   · lunga: equivMin >= bingeSerieMin (2 ore di serie, o 3 di YouTube);
 *   · dubbio: soprattutto YouTube, almeno 2 ore, e fatta di pezzi lunghi senza toccare niente: puo' essere un podcast.
 *     Una sessione dubbia non e' mai lunga: non si conta come binge watching, se ne parla in modo neutro.
 */
function abtSessioniVideo(grani, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  const pezzi = (grani || []).map(function(g){
    const s = +g.s, ms = g.ms != null ? +g.ms : (+g.e - +g.s);
    return { s: s, e: s + ms, ms: ms, tipo: abtVideoTipo(g.p, g.l) };
  }).filter(function(g){ return g.tipo && isFinite(g.s) && g.ms >= C.bingePassaggioMs; })
    .sort(function(a, b){ return a.s - b.s; });
  const out = [];
  let cur = null;
  pezzi.forEach(function(g){
    if (cur && g.s - cur.e <= C.bingeBucoMin * 60000){ cur.e = Math.max(cur.e, g.e); cur.pezzi.push(g); }
    else { if (cur) out.push(cur); cur = { s: g.s, e: g.e, pezzi: [g] }; }
  });
  if (cur) out.push(cur);
  const peso = C.bingeSerieMin / C.bingeYtMin;
  return out.map(function(x){
    let serie = 0, yt = 0, lunghi = 0;
    x.pezzi.forEach(function(g){ if (g.tipo === 'serie') serie += g.ms; else yt += g.ms; if (g.tipo === 'yt' && g.ms >= C.bingeYtPezzoMin * 60000) lunghi += g.ms; });
    const serieMin = serie / 60000, ytMin = yt / 60000, equiv = serieMin + ytMin * peso;
    const soloYt = ytMin > serieMin;
    const dubbio = soloYt && ytMin >= C.bingeSerieMin && yt > 0 && lunghi / yt >= C.bingeYtPezzoQuota;
    return { s: x.s, e: x.e, min: Math.round((serie + yt) / 60000), serieMin: Math.round(serieMin), ytMin: Math.round(ytMin),
             equivMin: Math.round(equiv), lunga: !dubbio && equiv >= C.bingeSerieMin, dubbio: dubbio };
  });
}
/**
 * Il riassunto di una giornata, quello che resta salvato nel giorno chiuso della dopamina:
 * { lunghe, dubbie, maxMin, serie, primoProd }. primoProd = l'ora del primo uso produttivo del telefono
 * (un'app segnata come produttiva, almeno 3 minuti, dalle 4 del mattino): serve a dire quando comincia il lavoro.
 */
function abtGiornoVideo(grani, cfgIn){
  const ss = abtSessioniVideo(grani, cfgIn);
  const lunghe = ss.filter(function(x){ return x.lunga; });
  let primoProd = 0;
  (grani || []).forEach(function(g){
    const ms = g.ms != null ? +g.ms : (+g.e - +g.s);
    if (!(g.di != null && +g.di <= 0.1) || ms < 3 * 60000 || (g.dev && g.dev !== 'telefono')) return;
    if (new Date(+g.s).getHours() < 4) return;
    if (!primoProd || +g.s < primoProd) primoProd = +g.s;
  });
  return { lunghe: lunghe.length, dubbie: ss.filter(function(x){ return x.dubbio; }).length,
           maxMin: ss.reduce(function(m, x){ return Math.max(m, x.lunga ? x.min : 0); }, 0),
           serie: lunghe.some(function(x){ return x.serieMin >= x.ytMin; }), primoProd: primoProd };
}
/**
 * IL VERDETTO, sulle ultime 4 settimane. `giorni` = { 'YYYY-MM-DD': riassunto di abtGiornoVideo } solo per i giorni di cui
 * ci sono i dati (un giorno che manca non e' un giorno senza video: e' un giorno che non conosciamo).
 * livello: 'abitudine' | 'episodi' | 'dubbio' | 'no' | 'senza'.
 */
function abtBinge(giorni, oggi, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  giorni = giorni || {};
  const sere = [0, 0, 0, 0], datiSett = [0, 0, 0, 0];
  let dati = 0, lunghi = 0, dubbi = 0, serie = 0, maxMin = 0;
  for (let i = 0; i < 28; i++){
    const g = giorni[abtChiave(abtGiornoPrima(oggi || Date.now(), i))];
    if (!g) continue;
    const w = Math.floor(i / 7);
    dati++; datiSett[w]++;
    if (g.lunghe > 0){ sere[w]++; lunghi++; if (g.serie) serie++; maxMin = Math.max(maxMin, g.maxMin || 0); }
    else if (g.dubbie > 0) dubbi++;
  }
  const settimane = sere.filter(function(n){ return n >= C.bingeSereSett; }).length;
  const conDati = datiSett.filter(function(n){ return n > 0; }).length;
  const media = conDati ? sere.reduce(function(a, n){ return a + n; }, 0) / conDati : 0;
  let livello = 'senza';
  if (settimane >= C.bingeSettimane) livello = 'abitudine';
  else if (lunghi > 0) livello = 'episodi';
  else if (dubbi > 0) livello = 'dubbio';
  else if (dati > 0) livello = 'no';
  const v = { livello: livello, giorniDati: dati, giorniLunghi: lunghi, giorniDubbi: dubbi, giorniSerie: serie,
              settimane: settimane, sereSettimana: Math.round(media * 10) / 10, maxMin: maxMin,
              pochiDati: dati < C.bingeGiorniDati && livello !== 'abitudine' };
  v.testo = abtBingeTesto(v, C);
  return v;
}
/** Le parole del verdetto: neutre, mai un'accusa. Un giorno solo non e' un'abitudine, e un video lungo puo' essere un podcast. */
function abtBingeTesto(v, C){
  C = C || ABT_SOGLIE;
  let t;
  if (v.livello === 'abitudine') t = 'Sessioni di video di ' + (C.bingeSerieMin / 60) + ' ore o più di fila, ' + abtNum(v.sereSettimana) + ' sere a settimana da ' + v.settimane + ' settimane. È diventata un’abitudine.';
  else if (v.livello === 'episodi') t = v.giorniLunghi === 1 ? 'Una sessione lunga di video in un giorno solo. Un giorno solo non è un’abitudine.'
    : 'Sessioni lunghe di video in ' + v.giorniLunghi + ' giorni su ' + v.giorniDati + ': non è ancora un’abitudine.';
  else if (v.livello === 'dubbio') t = 'Ci sono sessioni lunghe su YouTube. Possono essere video o un podcast in sottofondo, dai dati non si capisce.';
  else if (v.livello === 'no') t = 'Nessuna sessione di video di ' + (C.bingeSerieMin / 60) + ' ore di fila.';
  else t = 'Per riconoscere il binge watching servono i dati di utilizzo di qualche settimana.';
  if (v.pochiDati && v.livello !== 'senza') t += ' Per dire se è un’abitudine servono ' + (C.bingeGiorniDati / 7) + ' settimane di dati. Per ora ne ho ' + v.giorniDati + (v.giorniDati === 1 ? ' giorno.' : ' giorni.');
  return t;
}

/* ---------- il task switching ---------- */
/** Ogni quanti minuti si cambia app, dai contatori del motore della dopamina. null = troppo poco schermo per dirlo. */
function abtSwitch(attivoMin, cambi, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  attivoMin = +attivoMin || 0; cambi = +cambi || 0;
  if (attivoMin < C.switchAttivoMin) return null;
  const ogni = cambi > 0 ? attivoMin / cambi : attivoMin;
  let k, t, stato;
  if (ogni <= C.switchMoltoMin){ k = 'molto'; t = 'Attenzione molto frammentata'; stato = 'cambia'; }
  else if (ogni <= C.switchFrammMin){ k = 'frammentata'; t = 'Attenzione frammentata'; stato = 'cambia'; }
  else if (ogni < C.switchSporadMin){ k = 'spesso'; t = 'Interruzioni frequenti'; stato = 'neutro'; }
  else { k = 'sporadico'; t = 'Task switching sporadico'; stato = 'tieni'; }
  return { ogniMin: Math.round(ogni * 10) / 10, k: k, t: t, stato: stato, cambi: cambi, attivoMin: attivoMin };
}
/** Il focus di una sessione di Full Focus, in minuti: 'breve', 'vero' o 'flusso'. */
function abtFocusLivello(min, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  return min >= C.flussoMin ? 'flusso' : (min >= C.focusVeroMin ? 'vero' : 'breve');
}
/** Le sessioni di Full Focus di una finestra (le righe di fl_ff_hist): quante, di focus vero, di flusso, i minuti. */
function abtFocusSessioni(hist, da, a, cfgIn){
  const l = (hist || []).filter(function(x){ return x && !x.meditazione && x.tag !== 'meditazione' && +x.at >= da && +x.at <= (a || Infinity); });
  let vero = 0, flusso = 0, min = 0;
  l.forEach(function(x){
    const m = x.spentMs ? x.spentMs / 60000 : (x.ok ? (x.min || 25) : 0);
    min += m;
    const lv = abtFocusLivello(m, cfgIn);
    if (lv !== 'breve') vero++;
    if (lv === 'flusso') flusso++;
  });
  return { n: l.length, vero: vero, flusso: flusso, min: Math.round(min) };
}

/* ---------- la sveglia ---------- */
/**
 * Come ti svegli, dalle notti del motore del sonno. `notti` = [{ k, n: { ok, sveglia, allarme, rimandi, svegliaDa } }];
 * `lavoro` = { k: l'ora in cui e' cominciato il lavoro quel giorno } (la prima sessione di Full Focus o il primo uso produttivo).
 * pronto = almeno svegliaNottiMin notti misurate: sotto, il Genio fa le domande.
 */
function abtSveglia(notti, lavoro, cfgIn){
  const C = Object.assign({}, ABT_SOGLIE, cfgIn || {});
  const ok = (notti || []).filter(function(x){ return x && x.n && x.n.ok && x.n.sveglia > 0; });
  const conSv = ok.filter(function(x){ return x.n.svegliaDa === 'sveglia' || x.n.allarme > 0 || x.n.rimandi > 0; });
  const rimandi = conSv.reduce(function(a, x){ return a + (+x.n.rimandi || 0); }, 0);
  const orari = ok.map(function(x){ const d = new Date(x.n.sveglia); return d.getHours() * 60 + d.getMinutes(); });
  const media = orari.length ? orari.reduce(function(a, m){ return a + m; }, 0) / orari.length : 0;
  const scarto = orari.length ? orari.reduce(function(a, m){ return a + Math.abs(m - media); }, 0) / orari.length : 0;
  const attese = [];
  ok.forEach(function(x){
    const t = lavoro && lavoro[x.k];
    if (t && t > x.n.sveglia && t - x.n.sveglia <= C.lavoroMaxMs) attese.push((t - x.n.sveglia) / 60000);
  });
  return {
    pronto: ok.length >= C.svegliaNottiMin, notti: ok.length,
    conSveglia: conSv.length, daSolo: ok.length - conSv.length,
    rimandiMedia: conSv.length ? Math.round(rimandi / conSv.length * 10) / 10 : 0,
    giorniRimandi: conSv.filter(function(x){ return x.n.rimandi > 0; }).length,
    oraMin: Math.round(media), scartoMin: Math.round(scarto), regolare: orari.length >= 2 && scarto <= C.svegliaRegolareMin,
    lavoroMin: attese.length ? Math.round(attese.reduce(function(a, m){ return a + m; }, 0) / attese.length) : null,
    lavoroGiorni: attese.length
  };
}
/** Le righe che il Genio mostra quando i dati della sveglia ci sono: [emoji, titolo, riga]. */
function abtSvegliaRighe(sv){
  if (!sv || !sv.pronto) return [];
  const r = [];
  r.push(['⏰', sv.conSveglia + (sv.conSveglia === 1 ? ' giorno' : ' giorni') + ' con la sveglia', sv.daSolo ? sv.daSolo + (sv.daSolo === 1 ? ' giorno ti sei svegliato da solo.' : ' giorni ti sei svegliato da solo.') : 'Non ti sei mai svegliato da solo.']);
  if (sv.conSveglia) r.push(['🔁', sv.giorniRimandi ? 'La rimandi ' + abtNum(sv.rimandiMedia) + (sv.rimandiMedia === 1 ? ' volta' : ' volte') + ' in media' : 'Non la rimandi mai',
    sv.giorniRimandi ? 'Succede in ' + sv.giorniRimandi + ' mattine su ' + sv.conSveglia + '.' : 'Quando suona, ti alzi.']);
  r.push(['🌅', 'Ti svegli verso le ' + abtOraDaMin(sv.oraMin), sv.regolare ? 'Quasi sempre alla stessa ora.' : 'L’ora cambia di circa ' + abtOre(sv.scartoMin) + ' da un giorno all’altro.']);
  r.push(['💼', sv.lavoroMin != null ? 'Dalla sveglia al lavoro: ' + abtOre(sv.lavoroMin) : 'L’inizio del lavoro non l’ho ancora visto',
    sv.lavoroMin != null ? 'In media, su ' + sv.lavoroGiorni + (sv.lavoroGiorni === 1 ? ' giorno.' : ' giorni.') : 'Lo misuro dalla prima sessione di Full Focus della mattina.']);
  return r;
}
/* LE DOMANDE AL POSTO DEI DATI: compaiono solo quando i dati non ci sono. Quattro o sei risposte, mai cinque. */
const ABT_DOMANDE_SV = [
  { k: 'ora', t: 'A che ora ti svegli di solito?', o: [['🌌', 'Prima delle 6'], ['🌅', 'Fra le 6 e le 7'], ['☀️', 'Fra le 7 e le 8'], ['🕗', 'Fra le 8 e le 9'], ['🕘', 'Fra le 9 e le 10'], ['🛌', 'Dopo le 10']] },
  { k: 'stessa', t: 'Ti svegli sempre alla stessa ora?', o: [['⏱️', 'Sempre alla stessa ora'], ['🙂', 'Quasi sempre'], ['🔀', 'Cambia spesso'], ['🎲', 'Ogni giorno è diversa']] },
  { k: 'usa', t: 'Usi la sveglia?', o: [['⏰', 'Sì, sempre'], ['💼', 'Solo nei giorni di lavoro'], ['🤷', 'A volte'], ['🌞', 'No, mi sveglio da solo']] },
  { k: 'rimanda', t: 'Quando suona, la rimandi?', o: [['🚀', 'Mai, mi alzo subito'], ['1️⃣', 'Una volta'], ['🔁', 'Due o tre volte'], ['😴', 'Più di tre volte']] },
  { k: 'lavoro', t: 'Quanto tempo passa dalla sveglia a quando ti metti al lavoro?', o: [['⚡', 'Meno di mezz’ora'], ['🚶', 'Fra mezz’ora e un’ora'], ['🐢', 'Fra una e due ore'], ['🛋️', 'Più di due ore']] }
];
/** Quali domande fare: tutte senza le notti; solo quella sul lavoro se le notti ci sono ma l'inizio del lavoro no; nessuna se c'e' tutto.
    `risposte` = quelle date finora: chi non usa la sveglia non si sente chiedere se la rimanda. */
function abtDomandeSveglia(sv, risposte){
  risposte = risposte || {};
  let l;
  if (!sv || !sv.pronto) l = ABT_DOMANDE_SV.slice();
  else if (sv.lavoroMin == null) l = ABT_DOMANDE_SV.filter(function(d){ return d.k === 'lavoro'; });
  else l = [];
  return l.filter(function(d){ return !(d.k === 'rimanda' && risposte.usa === 3); });
}
/** I minuti fra sveglia e lavoro detti dalla risposta (il centro della fascia), per il confronto con l'energia. */
const ABT_LAVORO_RISPOSTA = [20, 45, 90, 150];

/* ---------- quello che il Genio ha gia' letto ---------- */
const ABT_NUMERI = ['Nessuna', 'Una', 'Due', 'Tre', 'Quattro'];
/**
 * "Quattro cose le ho gia' lette: ...": i tre punteggi della scheda Profilo e la dopamina, se c'e'.
 * p = { sleep, focus, rest } (scCompute), dopa = DP.L o null. Torna { frase, voci: [[emoji, nome, valore]] }.
 */
function abtLetti(p, dopa){
  const voci = [];
  const num = function(v){ return v != null && isFinite(+v); };
  if (p && num(p.sleep)) voci.push(['🌙', 'il sonno', 'Sonno', String(Math.round(p.sleep)), 'sleep']);
  if (p && num(p.focus)) voci.push(['⏳', 'il focus', 'Focus', String(Math.round(p.focus)), 'focus']);
  if (p && num(p.rest)) voci.push(['🌲', 'il riposo', 'Riposo', String(Math.round(p.rest)), 'rest']);
  if (num(dopa)) voci.push(['⛽', 'la dopamina', 'Dopamina', abtNum(dopa), 'dopa']);
  if (!voci.length) return { frase: '', voci: [] };
  /* 0.9.400 BUG-173, Andrea: "dopo i due punti si va a capo, e l'elenco ripete le card che sono subito sotto". La frase dice quante sono,
     le carte dicono quali. Ogni voce porta la sua chiave (sleep, focus, rest, dopa) per il perche' e il dettaglio */
  const frase = voci.length === 1 ? 'Una cosa l’ho già letta.' : ABT_NUMERI[voci.length] + ' cose le ho già lette.';
  return { frase: frase, voci: voci.map(function(v){ return [v[0], v[2], v[3], v[4]]; }) };
}

/* ---------- la domanda di controllo sull'energia ---------- */
/* La scala, dal basso: le parole dei criteri di Andrea. Energia alta: poco attrito a iniziare, resilienza agli intoppi,
   obiettivi chiari, ritmo costante. Energia bassa: procrastinazione, fatica prima di cominciare, pilota automatico
   (scrolling, binge watching), bassa tolleranza alla frustrazione. */
/* 0.9.400 BUG-172: ogni gradino ha la sua emoji, come le facce del controllo dell'umore */
const ABT_ENERGIA = [[1, 'A terra', '🪫'], [2, 'Scarico', '😮‍💨'], [3, 'Così così', '😐'], [4, 'Carico', '🙂'], [5, 'Pieno di energia', '⚡']];
const ABT_ENERGIA_RIGHE = [
  ['⚡', 'Energia alta', 'Cominci senza fatica, reggi gli intoppi, sai cosa fare e tieni il ritmo.'],
  ['🪫', 'Energia bassa', 'Rimandi, fai fatica a cominciare, vai avanti col pilota automatico e ti arrabbi presto.'],
  ['📅', 'Un giorno no è normale', 'Un calo di uno o due giorni capita a tutti. Settimane senza miglioramento sono un’altra cosa.']
];
/**
 * Quanta energia dicono i numeri, sulla stessa scala da 1 a 5. m = { sonno, riposo, dopamina, lavoroMin }.
 * Ogni misura diventa un numero da 0 a 1 (sonno e riposo /100, la dopamina /100 con la base a 50, dalla sveglia al lavoro
 * mezz'ora o meno = 1 e tre ore o piu' = 0); servono almeno due misure, altrimenti null.
 */
function abtEnergiaStima(m){
  m = m || {};
  const v = [];
  const n = function(x){ return x != null && isFinite(+x); };
  if (n(m.sonno)) v.push(Math.max(0, Math.min(1, +m.sonno / 100)));
  if (n(m.riposo)) v.push(Math.max(0, Math.min(1, +m.riposo / 100)));
  if (n(m.dopamina)) v.push(Math.max(0, Math.min(1, +m.dopamina / 100)));
  if (n(m.lavoroMin)) v.push(Math.max(0, Math.min(1, 1 - (+m.lavoroMin - 30) / 150)));
  if (v.length < 2) return null;
  return Math.round((1 + 4 * v.reduce(function(a, x){ return a + x; }, 0) / v.length) * 10) / 10;
}
/**
 * Il confronto fra la risposta (1-5) e la stima. distante = due punti o piu' di differenza.
 * storico = le righe di taratura salvate (abtRigaTaratura): se la risposta e' bassa da settimane, il Genio suggerisce con
 * delicatezza di parlarne con un medico o uno psicologo. Mai una diagnosi.
 */
function abtEnergiaConfronto(risposta, m, storico, adesso){
  const r = Math.max(1, Math.min(5, Math.round(+risposta || 0)));
  const stima = abtEnergiaStima(m);
  const out = { risposta: r, stima: stima, distante: false, verso: '', testo: '', nota: 'La dopamina è una stima che viene dal telefono, non una misura medica.', settimane: false, calo: '' };
  const cosa = [];
  if (m && m.sonno != null) cosa.push('sonno ' + Math.round(m.sonno));
  if (m && m.riposo != null) cosa.push('riposo ' + Math.round(m.riposo));
  if (m && m.dopamina != null) cosa.push('dopamina ' + abtNum(m.dopamina));
  const numeri = cosa.length ? ' (' + cosa.join(', ') + ')' : '';
  if (stima == null) out.testo = 'Me lo segno. Fra qualche giorno di dati potrò confrontarlo con quello che misuro.';
  else if (r - stima >= 2){ out.distante = true; out.verso = 'sopra';
    out.testo = 'Ti senti più carico di quello che dicono i miei numeri' + numeri + '. Può darsi che tu stia andando avanti con le riserve. Il conto, di solito, arriva dopo.'; }
  else if (stima - r >= 2){ out.distante = true; out.verso = 'sotto';
    out.testo = 'I miei numeri di questi giorni sono buoni' + numeri + ', ma tu ti senti scarico. Conta di più come ti senti tu. Il telefono vede solo una parte della giornata.'; }
  else out.testo = 'Quello che senti e quello che misuro vanno d’accordo' + numeri + '.';
  /* il calo: un giorno o due e' normale; settimane senza miglioramento sono un'altra cosa */
  const t = adesso || Date.now();
  const recenti = (storico || []).filter(function(x){ return x && +x.at > t - 28 * 86400000 && +x.at <= t; }).sort(function(a, b){ return a.at - b.at; });
  const bassi = recenti.filter(function(x){ return +x.risposta <= 2; });
  if (r <= 2){
    const alti = recenti.filter(function(x){ return +x.risposta >= 4; });
    const primoBasso = bassi.length ? bassi[0].at : t;
    const dopoAlti = alti.filter(function(x){ return x.at > primoBasso; }).length;
    if (bassi.length >= 3 && t - primoBasso >= 14 * 86400000 && !dopoAlti){
      out.settimane = true;
      out.calo = 'Mi dici di sentirti così da qualche settimana. Se non migliora, può aiutare parlarne con un medico o con uno psicologo. Non è una diagnosi, è un modo di prenderti cura di te.';
    } else out.calo = 'Un giorno o due giù di energia capitano a tutti.';
  }
  return out;
}
/** La riga di taratura: la risposta accanto ai valori misurati quel giorno. Servira' a tarare la stima della dopamina. */
function abtRigaTaratura(risposta, m, adesso){
  m = m || {};
  const t = adesso || Date.now();
  const n = function(x){ return x != null && isFinite(+x) ? Math.round(+x * 10) / 10 : null; };
  return { giorno: abtChiave(t), at: t, risposta: Math.round(+risposta || 0), stima: abtEnergiaStima(m),
           sonno: n(m.sonno), focus: n(m.focus), riposo: n(m.riposo), dopamina: n(m.dopamina),
           lavoroMin: n(m.lavoroMin), lavoroDetto: n(m.lavoroDetto), conSveglia: m.conSveglia == null ? null : !!m.conSveglia,
           rimandi: n(m.rimandi) };
}
/** Una riga per giorno: la risposta di oggi prende il posto di quella di stamattina. Se ne tengono 180. */
function abtTaraturaAggiungi(lista, riga){
  const l = (Array.isArray(lista) ? lista : []).filter(function(x){ return x && x.giorno !== riga.giorno; });
  l.push(riga);
  return l.slice(-180);
}

/* ---------- l'habit tracker (0.9.402 BUG-228) ----------
   Andrea: "Sonno 55/100 e 17 esercizi non sono abitudini. Il popover di ogni card mostra una griglia di 30-31 giorni calcolata da sola:
   quante volte l'ha fatta e di fila, per vedere quanto e' costante". Un'abitudine e' una cosa che fai o non fai in un giorno: qui ogni
   abitudine misurata diventa una mappa { 'YYYY-MM-DD': true | false } (un giorno che manca = l'app non ha i dati, non "non fatta"). */
const ABT_TRACKER_GIORNI = 30;
const ABT_ABIT = {
  lettoEntroMin: 60,        // a letto prima dell'una: dopo l'una il punteggio del sonno toglie 8 punti (snPunteggio)
  oreMin: 7,                // dormire almeno 7 ore: sotto le 7 la collina del sonno scende sotto 90 (SN_CURVA)
  svegliaScartoMin: 45,     // svegliarsi alla stessa ora: entro 45 minuti dalla tua ora solita (la stessa soglia di "regolare")
  focusPunti: 70,           // una giornata di focus: il punteggio Focus del Profilo da 70, o una sessione di focus vero
  riposoPunti: 70,          // una giornata di riposo: il punteggio Riposo da 70 (circa due terzi della giornata lontano dallo schermo)
  switchOgniMin: 5,         // task switching sotto controllo: piu' di 5 minuti fra un'app e l'altra, con almeno mezz'ora di schermo
  pcDistrQuota: 0.35,       // il computer usato bene: meno di un terzo del tempo su cose che distraggono
  pcMinMin: 30,             // sotto la mezz'ora di computer il giorno non conta
  lavoroMin: 60             // un giorno di lavoro: almeno un'ora sui programmi segnati come lavoro
};
/**
 * La griglia degli ultimi n giorni (di serie 30), dal piu' vecchio a oggi.
 * fatti = { 'YYYY-MM-DD': true | false }. Ogni cella: { k, g (giorno del mese), dow (0 = domenica), stato: 'si' | 'no' | 'vuoto', oggi }.
 * fila = i giorni di fila fino a oggi (oggi conta solo se e' gia' fatta: la giornata non e' finita), filaMax = il record nella griglia.
 */
function abtTracker(fatti, oggi, n){
  fatti = fatti || {}; n = n || ABT_TRACKER_GIORNI;
  const celle = [];
  for (let i = n - 1; i >= 0; i--){
    const t = abtGiornoPrima(oggi || Date.now(), i), k = abtChiave(t), v = fatti[k], d = new Date(t);
    celle.push({ k: k, g: d.getDate(), dow: d.getDay(), stato: v === true ? 'si' : (v === false ? 'no' : 'vuoto'), oggi: i === 0 });
  }
  let fila = 0;
  for (let i = celle.length - 1; i >= 0; i--){
    if (celle[i].stato === 'si') fila++;
    else if (i === celle.length - 1) continue;      // oggi non ancora: si conta da ieri
    else break;
  }
  let filaMax = 0, cur = 0;
  celle.forEach(function(c){ if (c.stato === 'si'){ cur++; if (cur > filaMax) filaMax = cur; } else cur = 0; });
  const fatte = celle.filter(function(c){ return c.stato === 'si'; }).length;
  const conDati = celle.filter(function(c){ return c.stato !== 'vuoto'; }).length;
  return { celle: celle, fatte: fatte, conDati: conDati, su: n, fila: fila, filaMax: filaMax };
}
/** Le ultime `per` celle di una griglia: quante fatte su quante con i dati (la card mostra "5 su 7 giorni"). */
function abtTrackerPeriodo(tr, per){
  const l = (tr && tr.celle || []).slice(-Math.max(1, per || 7));
  return { fatte: l.filter(function(c){ return c.stato === 'si'; }).length, conDati: l.filter(function(c){ return c.stato !== 'vuoto'; }).length, giorni: l.length,
           oggi: l.length ? l[l.length - 1].stato : 'vuoto' };
}
/** Il colore della card da quanto e' costante: da 70% tieni, sotto il 40% da cambiare, in mezzo neutro; senza dati 'manca'. */
function abtTrackerStato(p){
  if (!p || !p.conDati) return 'manca';
  const q = p.fatte / p.conDati;
  return q >= 0.7 ? 'tieni' : (q < 0.4 ? 'cambia' : 'neutro');
}
function abtMinDelGiorno(t){ const d = new Date(t); return d.getHours() * 60 + d.getMinutes(); }
/**
 * Le tre abitudini del sonno dalle notti del motore (sonno-motore.js): [{ k: 'YYYY-MM-DD' del risveglio, n: { ok, inizio, sveglia, sonnoMs } }].
 * letto: a letto prima dell'una (la sera dalle 18 conta come "prima"); ore: almeno oreMin ore di sonno; sveglia: entro svegliaScartoMin
 * minuti dalla tua ora solita (la mediana delle sveglie). Torna { letto, ore, sveglia, oraSveglia (minuti), notti }.
 */
function abtSonnoAbitudini(notti, cfgIn){
  const C = Object.assign({}, ABT_ABIT, cfgIn || {});
  const ok = (notti || []).filter(function(x){ return x && x.k && x.n && x.n.ok && x.n.sveglia > 0; });
  const letto = {}, ore = {}, sveglia = {};
  const sv = ok.map(function(x){ return abtMinDelGiorno(x.n.sveglia); }).sort(function(a, b){ return a - b; });
  const med = sv.length ? (sv.length % 2 ? sv[(sv.length - 1) / 2] : Math.round((sv[sv.length / 2 - 1] + sv[sv.length / 2]) / 2)) : null;
  ok.forEach(function(x){
    if (x.n.inizio > 0){ const m = abtMinDelGiorno(x.n.inizio); letto[x.k] = m >= 18 * 60 || m < C.lettoEntroMin; }
    if (x.n.sonnoMs > 0) ore[x.k] = x.n.sonnoMs >= C.oreMin * 3600000;
    if (med != null && sv.length >= 3) sveglia[x.k] = Math.abs(abtMinDelGiorno(x.n.sveglia) - med) <= C.svegliaScartoMin;
  });
  return { letto: letto, ore: ore, sveglia: sveglia, oraSveglia: med, notti: ok.length };
}
/**
 * Il punteggio del sonno di una notte, pezzo per pezzo (la (i) delle abitudini del sonno): le stesse regole di snPunteggio.
 * curva = snCurva (la collina sulle ore); n = la notte. Torna { righe: [{ t, v, segno }], totale } o null.
 */
function abtSonnoParti(n, curva, cfgIn){
  if (!n || !n.ok || !(n.sonnoMs > 0) || typeof curva !== 'function') return null;
  const pena = Object.assign({ penaInterruzione: 2, penaMax: 6 }, cfgIn || {});
  const eff = (n.effettivoMs || n.sonnoMs) / 3600000;
  const base = Math.round(curva(eff));
  const righe = [{ t: 'Ore di sonno: ' + abtOre(eff * 60), v: base, segno: '' }];
  let s = curva(eff);
  const bed = n.inizio ? abtMinDelGiorno(n.inizio) : -1;
  if (bed >= 0 && bed < 12 * 60){
    if (bed >= 3 * 60){ s -= 12; righe.push({ t: 'A letto alle ' + abtOraDaMin(bed) + ', dopo le 3', v: -12, segno: '-' }); }
    else if (bed >= 60){ s -= 8; righe.push({ t: 'A letto alle ' + abtOraDaMin(bed) + ', dopo l’una', v: -8, segno: '-' }); }
  }
  const ni = (n.interruzioni || []).length || (+n.nInt || 0);
  if (ni){ const p = Math.min(pena.penaMax, ni * pena.penaInterruzione); s -= p; righe.push({ t: ni === 1 ? 'Un risveglio nella notte' : ni + ' risvegli nella notte', v: -p, segno: '-' }); }
  return { righe: righe, totale: Math.round(Math.max(0, Math.min(100, s))) };
}
/** I giorni fatti delle altre abitudini misurate, dai dati che l'app ha gia'. Ogni funzione torna { 'YYYY-MM-DD': true | false }. */
function abtFattiRespiro(storico){ const o = {}; (storico || []).forEach(function(x){ if (x && +x.at) o[abtChiave(+x.at)] = true; }); return o; }
function abtFattiPunti(giorni, campo, soglia){
  const o = {};
  (giorni || []).forEach(function(x){ if (x && x.k && x[campo] != null && isFinite(+x[campo])) o[x.k] = +x[campo] >= soglia; });
  return o;
}
function abtFattiFocus(giorni, hist, cfgIn){
  const C = Object.assign({}, ABT_ABIT, cfgIn || {});
  const o = abtFattiPunti(giorni, 'focus', C.focusPunti);
  (hist || []).forEach(function(x){
    if (!x || x.meditazione || x.tag === 'meditazione' || !+x.at) return;
    const m = x.spentMs ? x.spentMs / 60000 : (x.ok ? (x.min || 25) : 0);
    if (m >= ABT_SOGLIE.focusVeroMin) o[abtChiave(+x.at)] = true;
  });
  return o;
}
function abtFattiSwitch(gd, cfgIn){
  const C = Object.assign({}, ABT_ABIT, cfgIn || {}), o = {};
  Object.keys(gd || {}).forEach(function(k){ const x = gd[k]; if (!x || x.attivoMin == null || +x.attivoMin < ABT_SOGLIE.switchAttivoMin) return; const ogni = (+x.cambi || 0) > 0 ? +x.attivoMin / +x.cambi : +x.attivoMin; o[k] = ogni > C.switchOgniMin; });
  return o;
}
function abtFattiVideo(gd){ const o = {}; Object.keys(gd || {}).forEach(function(k){ const v = gd[k] && gd[k].video; if (v) o[k] = !(v.lunghe > 0); }); return o; }
function abtFattiPc(giorniPc, cfgIn){
  const C = Object.assign({}, ABT_ABIT, cfgIn || {}), pc = {}, lav = {};
  Object.keys(giorniPc || {}).forEach(function(k){
    const d = giorniPc[k]; if (!d) return;
    if ((d.m || 0) >= C.pcMinMin) pc[k] = (d.distr || 0) / d.m < C.pcDistrQuota;
    if ((d.m || 0) > 0) lav[k] = (d.prod || 0) >= C.lavoroMin;
  });
  return { pc: pc, lavoro: lav };
}
/** I giorni di un'abitudine scritta da te: quelli che hai segnato (fl_azioni_fatti); dal giorno in cui l'hai creata a ieri, un giorno non
    segnato e' un giorno non fatta. Oggi resta aperto finche' non lo segni. */
function abtFattiSegnatiDa(l, creata, oggi){
  const o = {}, t0 = abtMezzanotte(oggi || Date.now());
  if (creata){ for (let i = 1; i <= ABT_TRACKER_GIORNI; i++){ const t = abtGiornoPrima(t0, i); if (t < abtMezzanotte(creata)) break; o[abtChiave(t)] = false; } }
  (l || []).forEach(function(k){ if (typeof k === 'string') o[k] = true; });
  return o;
}
/* 0.9.402 BUG-226, Andrea: "anche la lettura del Genio chiede se si viene interrotti spesso da persone o animali". La domanda si aggiunge a
   quelle della sveglia (oracle.js, orSvDomande); la risposta resta in fl_sveglia_risposte (interr: 0-3) e pesa un minimo sull'arrivo
   previsto (eta-motore.js, etaAaiDelta). nota: '' = sotto la domanda nessuna riga sulle mattine */
const ABT_DOMANDA_INTERR = { k: 'interr', t: 'Mentre lavori o studi, ti *interrompono* spesso persone o animali?', nota: '',
  o: [['🧘', 'Quasi mai'], ['🙂', 'Qualche volta al giorno'], ['🔔', 'Più volte al giorno'], ['🌀', 'Più volte all’ora']] };
function abtDomandaInterruzioni(){ return [ABT_DOMANDA_INTERR]; }

if (typeof module !== 'undefined' && module.exports){
  module.exports = { ABT_SOGLIE, ABT_DOMANDE_SV, ABT_ENERGIA, ABT_ENERGIA_RIGHE, ABT_LAVORO_RISPOSTA, abtChiave, abtGiornoPrima,
    abtVideoTipo, abtSessioniVideo, abtGiornoVideo, abtBinge, abtBingeTesto, abtSwitch, abtFocusLivello, abtFocusSessioni,
    abtSveglia, abtSvegliaRighe, abtDomandeSveglia, abtLetti, abtEnergiaStima, abtEnergiaConfronto, abtRigaTaratura, abtTaraturaAggiungi,
    ABT_ABIT, ABT_DOMANDA_INTERR, abtTracker, abtTrackerPeriodo, abtTrackerStato, abtSonnoAbitudini, abtSonnoParti, abtFattiRespiro, abtFattiPunti, abtFattiFocus,
    abtFattiSwitch, abtFattiVideo, abtFattiPc, abtFattiSegnatiDa, abtDomandaInterruzioni };
}

/* ===========================================================================================
   LA PARTE CHE LEGGE (nel telefono): le stesse funzioni dell'app, nessun conto nuovo
   =========================================================================================== */
const ABT_TARATURA_KEY = 'fl_energia_taratura';   // [riga di abtRigaTaratura], una per giorno
const ABT_SV_RISPOSTE_KEY = 'fl_sveglia_risposte'; // { at, ora, stessa, usa, rimanda, lavoro } le risposte alle domande della sveglia
const ABT = { notti: {}, cache: {} };
function abtJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function abtTaratura(){ const l = abtJ(ABT_TARATURA_KEY, []); return Array.isArray(l) ? l : []; }
function abtTaraturaSalva(riga){ try{ localStorage.setItem(ABT_TARATURA_KEY, JSON.stringify(abtTaraturaAggiungi(abtTaratura(), riga))); return true; }catch(_){ return false; } }
function abtSvRisposte(){ const r = abtJ(ABT_SV_RISPOSTE_KEY, null); return (r && typeof r === 'object') ? r : null; }
function abtSvRisposteSalva(r){ try{ localStorage.setItem(ABT_SV_RISPOSTE_KEY, JSON.stringify(Object.assign({}, r, { at: Date.now() }))); }catch(_){ } }

/** I punteggi di un giorno (0 = oggi), gli stessi della scheda Profilo. null se il telefono non li ha. */
async function abtPunteggi(off){
  try{
    if (typeof scReportPunteggi !== 'function' || typeof scCompute !== 'function') return null;
    const r = await scReportPunteggi(off || 0);
    return r && r.granted ? scCompute(r) : null;
  }catch(_){ return null; }
}
/** Le notti degli ultimi n giorni, dal motore del sonno. Le notti passate non cambiano piu': restano in memoria e, dalla 0.9.402, anche nel
    telefono (fl_abt_notti), cosi' l'habit tracker dei 30 giorni non rilegge ogni volta trenta giornate. opz.max = quante notti nuove leggere
    al massimo in questo giro (le altre arrivano al prossimo). */
const ABT_NOTTI_KEY = 'fl_abt_notti';
function abtNottiCache(){ const c = abtJ(ABT_NOTTI_KEY, {}); return (c && typeof c === 'object' && !Array.isArray(c)) ? c : {}; }
function abtNotteDaCache(k, x){
  return { k: k, sleep: x.sl, rest: x.re, focus: x.fo,
    n: x.ok ? { ok: true, inizio: x.i || 0, sveglia: x.s || 0, sonnoMs: x.m || 0, effettivoMs: x.e || 0, nInt: x.ni || 0, interruzioni: [], svegliaDa: x.sd || '', allarme: x.al || 0, rimandi: x.ri || 0 } : null };
}
function abtNotteInCache(c){
  const n = c.n || {};
  return { ok: n.ok ? 1 : 0, i: n.inizio || 0, s: n.sveglia || 0, m: n.sonnoMs || 0, e: n.effettivoMs || 0, ni: (n.interruzioni || []).length, sd: n.svegliaDa || '', al: n.allarme || 0, ri: n.rimandi || 0,
    sl: c.sleep == null ? null : c.sleep, re: c.rest == null ? null : c.rest, fo: c.focus == null ? null : c.focus };
}
async function abtNotti(n, opz){
  opz = opz || {};
  const out = [], cache = abtNottiCache();
  let nuove = 0, scritto = false;
  for (let i = 0; i < (n || 14); i++){
    const k = abtChiave(abtGiornoPrima(Date.now(), i));
    let c = i > 0 ? (ABT.notti[k] || (cache[k] ? abtNotteDaCache(k, cache[k]) : null)) : null;
    if (!c){
      if (i > 0 && opz.max != null && nuove >= opz.max) break;
      const p = await abtPunteggi(i);
      nuove++;
      if (!p && i === 0) continue;
      if (!p) break;                                   // senza permesso, o oltre la storia del telefono
      c = { k: k, n: p.notte || null, sleep: p.sleep, rest: p.rest, focus: p.focus };
      if (i > 0){ ABT.notti[k] = c; cache[k] = abtNotteInCache(c); scritto = true; }
    }
    out.push(c);
  }
  if (scritto){
    try{
      const ks = Object.keys(cache).sort();
      if (ks.length > 45) ks.slice(0, ks.length - 45).forEach(function(k){ delete cache[k]; });
      localStorage.setItem(ABT_NOTTI_KEY, JSON.stringify(cache));
    }catch(_){ }
  }
  return out;
}
/** I giorni chiusi della dopamina, con oggi in cima (DP.dett): i cambi d'app, i minuti di schermo, i video. */
function abtGiorniDopa(){
  const g = Object.assign({}, (typeof dpGiorni === 'function') ? dpGiorni() : {});
  try{
    if (typeof DP !== 'undefined' && DP && DP.dett && DP.dett.ris && DP.dett.giorno){
      const c = DP.dett.ris.contatori || {};
      const tel = (DP.dett.grani || []).filter(function(x){ return !x.dev || x.dev === 'telefono'; });
      g[DP.dett.giorno] = Object.assign({}, g[DP.dett.giorno] || {}, { cambi: c.cambi, attivoMin: c.attivoMin, video: abtGiornoVideo(tel), oggi: true });
    }
  }catch(_){ }
  return g;
}
/** I giorni chiusi salvati prima della 0.9.397 non hanno il riassunto dei video: si rileggono, quattro per volta, con la stessa
    lettura della dopamina (dpGraniTelefono). Non si crea mai un giorno nuovo: quello lo fa dpStoria. */
async function abtVideoRiempi(){
  if (typeof dpGiorni !== 'function' || typeof dpGraniTelefono !== 'function' || typeof DP_GIORNI_KEY === 'undefined') return;
  if (ABT.riempi) return ABT.riempi;
  ABT.riempi = (async function(){
    const g = dpGiorni();
    let fatti = 0;
    for (let i = 1; i <= 28 && fatti < 4; i++){
      const from = abtGiornoPrima(Date.now(), i), k = abtChiave(from);
      if (!g[k] || g[k].video) continue;
      const gr = await dpGraniTelefono(from, abtGiornoPrima(Date.now(), i - 1));
      if (!gr) break;
      g[k].video = abtGiornoVideo(gr); fatti++;
    }
    if (fatti){ try{ localStorage.setItem(DP_GIORNI_KEY, JSON.stringify(g)); }catch(_){ } }
  })().catch(function(){ }).then(function(){ ABT.riempi = null; });
  return ABT.riempi;
}
/** Il verdetto sul binge watching, sui giorni che hanno il riassunto dei video. */
function abtBingeOra(){
  const g = abtGiorniDopa(), v = {};
  Object.keys(g).forEach(function(k){ if (g[k] && g[k].video) v[k] = g[k].video; });
  return abtBinge(v, Date.now());
}
/** L'ora in cui e' cominciato il lavoro, per giorno: la prima sessione di Full Focus o il primo uso produttivo del telefono. */
function abtLavoroPerGiorno(){
  const out = {};
  try{
    const hist = (typeof ffHist === 'function') ? ffHist() : abtJ('fl_ff_hist', []);
    (hist || []).forEach(function(x){
      if (!x || x.meditazione || x.tag === 'meditazione') return;
      const s = +x.start || (+x.at - (x.spentMs || (x.min || 25) * 60000));
      if (!s) return;
      const k = abtChiave(s);
      if (!out[k] || s < out[k]) out[k] = s;
    });
  }catch(_){ }
  const g = abtGiorniDopa();
  Object.keys(g).forEach(function(k){ const p = g[k] && g[k].video && g[k].video.primoProd; if (p && (!out[k] || p < out[k])) out[k] = p; });
  return out;
}
/** Come ti svegli negli ultimi 14 giorni. */
async function abtSvegliaLeggi(){
  const notti = await abtNotti(14);
  return abtSveglia(notti, abtLavoroPerGiorno());
}

/* ---------- le abitudini della scheda Azione ---------- */
/* 0.9.402 BUG-228, Andrea: "Sonno 55/100 e 17 esercizi, 1 ora e 4 minuti non sono abitudini. Le abitudini sono andare a dormire a una
   certa ora, dormire X ore, svegliarsi a una certa ora, con una (i) che scompone il punteggio; e ogni card ha un habit tracker di 30
   giorni calcolato da solo". Ogni riga ha i suoi giorni fatti (fatti) e la sua griglia (tr, abtTracker); la card dice quanti giorni su
   quanti nel periodo scelto. La riga 'sonno' (il punteggio) resta per chi la legge (la lettura, il triangolo) ma non e' piu' una card. */
const ABT_RIGHE_DEF = {
  letto: ['🛏️', 'A letto prima dell’una', 'Conta le sere in cui vai a letto prima dell’una.', 'Per misurarlo serve l’accesso ai dati di utilizzo, e una notte col telefono fermo.'],
  ore: ['😴', 'Dormire 7 ore', 'Conta le notti con almeno 7 ore di sonno.', 'Per misurarlo serve l’accesso ai dati di utilizzo, e una notte col telefono fermo.'],
  sveglia: ['⏰', 'Sveglia alla stessa ora', 'Conta le mattine in cui ti svegli entro tre quarti d’ora dalla tua ora solita.', 'Per misurarla servono almeno tre notti misurate.'],
  focus: ['⏳', 'Focus', 'Conta i giorni con il Focus del Profilo da 70 in su, o con una sessione di Full Focus di almeno 20 minuti.', 'Per misurarlo fai una sessione di Full Focus. Il focus vero comincia dopo 20 minuti.'],
  riposo: ['🌲', 'Riposo', 'Conta i giorni con il Riposo del Profilo da 70 in su. Circa due terzi della giornata lontano dallo schermo.', 'Per misurarlo serve l’accesso ai dati di utilizzo.'],
  respiro: ['🫁', 'Respirazione', 'Conta i giorni in cui fai almeno un esercizio di respirazione.', 'Per misurarla fai un esercizio di respirazione.'],
  switch: ['🔀', 'Task switching', 'Conta i giorni in cui passano più di 5 minuti fra un’app e l’altra.', 'Per misurarlo serve almeno mezz’ora di schermo letta dalla dopamina.'],
  pc: ['💻', 'Uso del PC', 'Conta i giorni in cui al computer meno di un terzo del tempo va sulle distrazioni.', 'Per misurarlo collega il computer a DreamMap.'],
  lavoro: ['🛠️', 'Ore di lavoro', 'Conta i giorni con almeno un’ora sui programmi che hai segnato come lavoro.', 'Per misurarle collega il computer e segna i programmi di lavoro.'],
  video: ['🍿', 'Video lunghi', 'Conta i giorni senza sessioni di video di due ore o più di fila.', '']
};
/** Una riga misurata dai suoi giorni fatti: la griglia, il periodo, il valore della card e il colore. */
function abtRigaTracker(k, fatti, per, extra){
  const d = ABT_RIGHE_DEF[k], tr = abtTracker(fatti, Date.now(), ABT_TRACKER_GIORNI), p = abtTrackerPeriodo(tr, per);
  const r = Object.assign({ k: k, em: d[0], t: d[1], def: d[2], fatti: fatti, tr: tr, per: per }, extra || {});
  if (!p.conDati){ r.val = ''; r.sub = d[3] || d[2]; r.stato = 'manca'; return r; }
  r.stato = abtTrackerStato(p);
  r.val = per === 1 ? (p.oggi === 'si' ? 'Fatta oggi' : (p.oggi === 'no' ? 'Non oggi' : 'Oggi ancora no')) : p.fatte + ' su ' + p.conDati;
  r.unita = per === 1 ? '' : (p.conDati === 1 ? ' giorno' : ' giorni');
  r.sub = tr.fila >= 2 ? tr.fila + ' giorni di fila' : (tr.filaMax >= 2 ? 'Record: ' + tr.filaMax + ' giorni di fila' : d[2]);
  return r;
}
/**
 * Le righe delle abitudini misurate, nel periodo della scheda (1, 7 o 30 giorni).
 * Ogni riga: { k, em, t, val, unita, sub, def, fatti, tr, stato: 'tieni' | 'cambia' | 'neutro' | 'manca' }. 'manca' = senza dati: sub dice
 * cosa serve. opz.tutte = leggi tutte le 30 notti (il foglio della card); di serie al massimo 14 notti nuove per giro.
 */
async function abtAbitudini(per, opz){
  per = per || 7; opz = opz || {};
  const giorni = Math.max(1, per), da = abtGiornoPrima(Date.now(), giorni - 1);
  const righe = [];
  const notti = await abtNotti(ABT_TRACKER_GIORNI, { max: opz.tutte ? null : 14 });
  /* il punteggio del sonno (la media dei giorni del periodo, al massimo sette): non e' una card, lo leggono la lettura e il triangolo */
  const nPer = notti.slice(0, Math.min(giorni, 7));
  const media = function(k){ const l = nPer.map(function(x){ return x[k]; }).filter(function(v){ return v != null && isFinite(v); }); return l.length ? { v: Math.round(l.reduce(function(a, x){ return a + x; }, 0) / l.length), n: l.length } : null; };
  const stato = function(v){ return v >= 70 ? 'tieni' : (v < 50 ? 'cambia' : 'neutro'); };
  const sn = media('sleep');
  righe.push(sn ? { k: 'sonno', em: '🌙', t: 'Sonno', val: String(sn.v), sub: sn.n === 1 ? 'Il punteggio di stanotte.' : 'La media di ' + sn.n + ' notti.', stato: stato(sn.v), punteggio: true }
    : { k: 'sonno', em: '🌙', t: 'Sonno', val: '', sub: 'Per misurarlo serve l’accesso ai dati di utilizzo, e una notte col telefono fermo.', stato: 'manca', punteggio: true });
  /* le tre abitudini del sonno */
  const sa = abtSonnoAbitudini(notti.map(function(x){ return { k: x.k, n: x.n }; }));
  const ultima = notti.filter(function(x){ return x.n && x.n.ok; })[0] || null;
  righe.push(abtRigaTracker('letto', sa.letto, per, { notte: ultima }));
  righe.push(abtRigaTracker('ore', sa.ore, per, { notte: ultima }));
  righe.push(abtRigaTracker('sveglia', sa.sveglia, per, { notte: ultima, oraSveglia: sa.oraSveglia }));
  /* focus e riposo: il punteggio del Profilo di ogni giorno diventa "fatto" o "non fatto" */
  const hist = (typeof ffHist === 'function') ? ffHist() : abtJ('fl_ff_hist', []);
  righe.push(abtRigaTracker('focus', abtFattiFocus(notti, hist), per));
  righe.push(abtRigaTracker('riposo', abtFattiPunti(notti, 'rest', ABT_ABIT.riposoPunti), per));
  /* i respiri: un giorno con almeno un esercizio, mai un totale */
  try{ righe.push(abtRigaTracker('respiro', abtFattiRespiro((typeof rsStorico === 'function') ? rsStorico() : abtJ('fl_respiro', [])), per)); }catch(_){ }
  /* il task switching: i cambi d'app del motore della dopamina, giorno per giorno */
  const gd = abtGiorniDopa();
  righe.push(abtRigaTracker('switch', abtFattiSwitch(gd), per));
  /* il computer: i giorni della cache fl_pc_usage (PC.doc.giorni) */
  let gpc = null;
  try{ gpc = (typeof PC !== 'undefined' && PC.doc && PC.doc.giorni) || null; if (!gpc){ const c = abtJ('fl_pc_usage', null); gpc = c && c.doc && c.doc.giorni || null; } }catch(_){ gpc = null; }
  const fpc = abtFattiPc(gpc || {});
  righe.push(abtRigaTracker('pc', fpc.pc, per));
  const lav = abtRigaTracker('lavoro', fpc.lavoro, per);
  if (lav.stato === 'manca' && gpc) lav.sub = 'Per misurarle segna sul computer i programmi di lavoro.';
  righe.push(lav);
  /* i video lunghi: solo quando c'e' qualcosa da dire, in modo neutro */
  const bg = abtBingeOra();
  if (bg.livello === 'episodi' || bg.livello === 'dubbio'){ const v = abtRigaTracker('video', abtFattiVideo(gd), per); v.sub = bg.testo; if (v.stato === 'manca') v.stato = 'neutro'; righe.push(v); }
  try{ abtVideoRiempi(); }catch(_){ }
  return { at: Date.now(), righe: righe, binge: bg, completa: !!opz.tutte || notti.length >= ABT_TRACKER_GIORNI };
}
