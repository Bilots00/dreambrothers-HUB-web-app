/* =========================================================================================
   FULL FOCUS A CICLI, E IL FULL FOCUS CHE PARTE DA SOLO.

   Due richieste, una sola idea: togliere la decisione. Alle 9 non si sceglie se cominciare,
   si e' gia' cominciato; finita una sessione non si sceglie se farne un'altra, parte da sola
   dopo la pausa. E' il Pomodoro di AppBlock (durata, pausa, numero di sessioni, ripetizione
   automatica) piu' i programmi a orario, che armano il Full Focus anche ad app chiusa.

   Chi fa cosa:
   · questa pagina scrive due impostazioni del motore — ffAuto (i programmi, le app consentite,
     la priorita' di oggi) e ffCiclo (la catena in corso) — e disegna la pausa;
   · il telefono (FocusAuto.java) ha la sveglia: avvia i programmi, fa partire la pausa quando
     una sessione del ciclo finisce e la sessione dopo quando la pausa finisce;
   · una sessione partita da sola, quando l'app si apre, viene ADOTTATA: diventa FF.run come
     se l'avessi fatta partire tu, con la sua pianta e il suo verdetto.
   ========================================================================================= */
const FFC = { prossimo: null, tick: 0 };
const FFC_KEY = 'fl_ff_auto';
const FFC_GIORNI = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];

function ffcCicli(){
  const p = ffPref();
  p.cicli = Object.assign({ on: false, pausa: 5, sessioni: 4, auto: true }, p.cicli || {});
  return p.cicli;
}
function ffcStato(){
  try{
    const raw = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS.ffCiclo : '';
    const s = raw ? JSON.parse(raw) : null;
    return (s && s.tot) ? s : null;
  }catch(_){ return null; }
}
function ffcNative(patch){
  try{ if (typeof SETTINGS !== 'undefined') Object.assign(SETTINGS, patch); }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) return NATIVE.setSettings(patch); }catch(_){ }
  return Promise.resolve();
}
/* 0.9.387: la frase dell'anteprima e' quella della bolla vera (ffBollaFrase in assenze.js) */
function ffcBollaFrase(modo){ return (typeof ffBollaFrase === 'function') ? ffBollaFrase(modo) : (modo === 'giu' ? 'alla fine della sessione' : 'di concentrazione'); }
function ffcMin(m){ return m >= 60 && m % 60 === 0 ? (m / 60) + 'h' : m + ' min'; }
function ffcOra(min){ return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }

/* ---------------------------------------------------------------- la pagina delle impostazioni
   Rifatta nella 0.9.201 dopo la bocciatura di Andrea («spazio inesistente, ordine, poca
   chiarezza»). Si apre dall'ingranaggio del foglio del Timer. Regole: UNA cosa in evidenza (i
   cicli, l'unica con l'emoji), sotto ogni voce una riga che dice cosa cambia per te, le scelte
   dei cicli raggruppate in una card sola, le altre due voci sono righe con la freccia. */
const FFC_SVG_BACK = '<svg viewBox="0 0 8 12" width="9" height="13" aria-hidden="true"><path fill="none" d="M7 1L2 6L7 11" stroke="currentColor" stroke-width="1.6"/></svg>';
function ffcTesta(titolo, indietro){
  return '<div class="ff-sh-head"><button type="button" class="ff-back" onclick="' + indietro + '" aria-label="Indietro">' + FFC_SVG_BACK + '</button><div class="ff-sh-title">' + titolo + '</div><span></span></div>';
}
function ffcRigaSw(tit, sub, on, fn){
  return '<div class="ffi-r"><div><b>' + tit + '</b><small>' + sub + '</small></div><button type="button" class="switch' + (on ? ' on' : '') + '" onclick="' + fn + '"></button></div>';
}
/* 0.9.335, Andrea: "non voglio le pill, i minuti escono dal bordo: metti un menu a tendina". Le pillole restano
   solo dove le scelte sono parole in colonna (la bolla); i numeri si scelgono da una tendina. */
function ffcRigaChips(tit, sub, vals, cur, fn, fmt, cls){
  if (cls !== 'col') return '<div class="ffi-r col"><div><b>' + tit + '</b><small>' + sub + '</small></div><label class="ffi-sel"><select onchange="' + fn + '(+this.value)">'
    + vals.map(function(v){ return '<option value="' + v + '"' + (v === cur ? ' selected' : '') + '>' + (fmt ? fmt(v) : v) + '</option>'; }).join('')
    + '</select><svg viewBox="0 0 12 8" width="12" height="8" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></label></div>';
  return '<div class="ffi-r col"><div><b>' + tit + '</b><small>' + sub + '</small></div><div class="ffi-chips' + (cls ? ' ' + cls : '') + '">'
    + vals.map(function(v){ return '<button type="button" class="' + (v === cur ? 'on' : '') + '" onclick="' + fn + '(' + v + ')">' + (fmt ? fmt(v) : v) + '</button>'; }).join('') + '</div></div>';
}
function ffcRigaVai(tit, sub, val, fn){
  return '<button type="button" class="ffi-r vai" onclick="' + fn + '"><div><b>' + tit + '</b><small>' + sub + '</small></div><span>' + val + '</span><svg class="chev" viewBox="0 0 8 12" width="8" height="12" aria-hidden="true"><path fill="none" d="M1 1l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>';
}
/* 0.9.326, Andrea: "troppe sezioni in un popover, e' confusionario: dividile in sottopagine come le impostazioni del Report, che ha quattro voci e tutto il resto vuoto" */
const FF_IMP = { k: '' };
const FFI_BOLLA_FMT = function(v){ return v.indexOf('su') >= 0 ? 'Il tempo passato' : (v.indexOf('giu') >= 0 ? 'Il tempo che manca' : 'Nessuna bolla'); };
/* 0.9.375, Andrea: "otto pannelli in una pagina sono troppi: raggruppali come nelle impostazioni del Report". Tre cartelle */
/* 0.9.381, Andrea: "suono e bolla del tempo non nella stessa pagina: la bolla va nelle impostazioni della sessione, il suono da solo" */
const FF_IMP_T = { sessione: 'La sessione', suono: 'Il suono', schermo: 'Telefono e schermo' };
function ffImpostazioniApri(){
  /* 0.9.331, Andrea: "tornando indietro il popover e' chiuso invece di restare aperto": si ricorda da dove si e' venuti */
  const sh = document.getElementById('ffSheetWrap'), sub0 = document.getElementById('s-ff-imp'), sub1 = document.getElementById('s-ff-imp2');
  if (!(sub0 && sub0.classList.contains('active')) && !(sub1 && sub1.classList.contains('active'))) FF_IMP.daFoglio = !!(sh && sh.classList.contains('open'));
  try{ ffSheetClose(); }catch(_){ }
  const sub = document.getElementById('s-ff-imp2');
  if (sub && sub.classList.contains('active') && FF_IMP.k){ ffImpSezPaint(); return; }
  goId('s-ff-imp'); ffImpPaint();
}
function ffImpEsci(){
  goId('s-fullfocus'); try{ ffPaint(); }catch(_){ }
  if (FF_IMP.daFoglio){ FF_IMP.daFoglio = false; setTimeout(function(){ try{ ffTimerOpen(); }catch(_){ } }, 60); }
}
function ffSchermoToggle(){ const p = ffPref(); p.schermoNo = !p.schermoNo; ffSavePref(); try{ ffSchermoApplica(); }catch(_){ } ffImpostazioniApri(); }
function ffImpPaint(){
  const box = document.getElementById('ffImpBody'); if (!box) return;
  const p = ffPref(), c = ffcCicli(), n = ffcProgrammi().filter(function(x){ return x.on; }).length;
  const riga = function(ico, t, val, fn){ return '<div class="setrow" onclick="' + fn + '"><span>' + ico + '</span><b>' + t + '</b><small>' + esc(val || '') + '</small><span class="chev"></span></div>'; };
  const riga2 = function(ico, t, sub, fn){ return '<div class="setrow ffi-grp" onclick="' + fn + '"><span>' + ico + '</span><div class="ffi-grp-t"><b>' + t + '</b><small>' + esc(sub) + '</small></div><span class="chev"></span></div>'; };
  box.innerHTML = riga2('⏱️', 'La sessione', 'Pausa, bolla del tempo, cicli e quando parte da sola', "ffImpSez('sessione')")
    + riga2('🔊', 'Il suono', 'Cosa senti mentre ti concentri', "ffImpSez('suono')")
    + riga2('📱', 'Telefono e schermo', 'Schede aperte, schermo acceso, foglio delle distrazioni', "ffImpSez('schermo')")
    + '<div class="spacer"></div>';
}
function ffImpSez(k){ FF_IMP.k = k; goId('s-ff-imp2'); ffImpSezPaint(); }
function ffImpSezPaint(){
  const box = document.getElementById('ffImp2Body'), t = document.getElementById('ffImp2T'); if (!box) return;
  if (t) t.textContent = FF_IMP_T[FF_IMP.k] || '';
  const p = ffPref(), c = ffcCicli();
  let h = '';
  if (FF_IMP.k === 'sessione'){
    const fuori = p.fuori !== 'continua', n = ffcProgrammi().filter(function(x){ return x.on; }).length;
    h = '<div class="ffi-sez">⏸️ La pausa</div><div class="ffi-card">' + ffcRigaSw('Puoi mettere in pausa', ffPausaPermessa() ? 'Durante la sessione vedi il pulsante della pausa.' : 'Durante la sessione il pulsante della pausa non c’è.', ffPausaPermessa(), 'ffPausaPrefToggle()')
      + (ffPausaPermessa() ? ffcLega(ffcRigaChips('Quanto dura', 'Alla fine la sessione riparte da sola.', [3, 5, 10], ffPausaMin(), 'ffPausaMinSet', function(v){ return v + ' min'; })) : '') + '</div>'
      + '<div class="ffi-sez">🚪 Quando esci dall’app</div><div class="ffi-card">'
      + ffcRigaSw('Il tempo si ferma quando esci dall’app', fuori ? 'Il conto si ferma su un’altra app, e riprende quando torni.' : 'Il conto continua anche mentre sei su un’altra app.', fuori, 'ffFuoriToggle()')
      + (fuori ? ffcLega(ffcRigaChips('Si ferma al massimo per', 'Le app consentite per la sessione non fermano il tempo.', [3, 5, 10, 15], ffFuoriMin(), 'ffFuoriMinSet', function(v){ return v + ' min'; })) : '') + '</div>'
      + ffcBollaHtml()
      + '<div class="ffi-sez">🍅 I cicli</div><div class="ffi-card">' + ffcRigaSw('Cicli con pausa', c.on ? c.sessioni + ' sessioni da ' + p.minutes + ' min, con ' + c.pausa + ' min di pausa.' : 'Più sessioni di fila, con una pausa in mezzo.', c.on, 'ffcToggle()')
      + (c.on ? ffcRigaChips('Quante sessioni', 'Finite tutte, il ciclo è chiuso.', [2, 3, 4, 5, 6], c.sessioni, 'ffcSessioni', function(v){ return v + ' sessioni'; })
          + ffcRigaChips('Pausa fra una sessione e l’altra', 'Il telefono è libero per questi minuti.', [5, 10, 15, 20], c.pausa, 'ffcPausa', function(v){ return v + ' min'; })
          + ffcRigaSw('Riparte da sola', 'Finita la pausa, la sessione dopo parte senza toccare niente.', c.auto, 'ffcAuto()') : '') + '</div>'
      + '<div class="ffi-sez">⏰ Programmi</div><div class="ffi-card">' + ffcRigaVai('Pianifica la sessione', 'Parte da sola a un’ora o quando apri un’app che scegli tu.', n ? n + ' attiv' + (n === 1 ? 'o' : 'i') : 'Spento', 'ffcProgrammiApri()') + '</div>';
  } else if (FF_IMP.k === 'schermo'){
    const sc = (typeof ffdScelta === 'function') ? ffdScelta() : '';
    h = ((typeof ffsImpostazioniHtml === 'function') ? ffsImpostazioniHtml() : '')
      + '<div class="ffi-sez">☀️ Lo schermo</div><div class="ffi-card">' + ffcRigaSw('Mantieni lo schermo acceso', 'Durante la sessione lo schermo non si spegne da solo.', !p.schermoNo, 'ffSchermoToggle()') + '</div>'
      + '<div class="ffi-sez">📝 Il foglio delle distrazioni</div><div class="ffi-card">' + ffcRigaVai('Dove scrivi le distrazioni', 'Un pensiero che arriva lo scrivi e lo lasci lì.', sc === 'carta' ? 'Su carta' : sc === 'telefono' ? 'Nel telefono' : 'Da scegliere', "ffdFoglioApri('impostazioni')") + '</div>';
  } else if (FF_IMP.k === 'suono'){
    /* 0.9.381, Andrea: "metti Il suono parte da solo, e poi quale suono far partire; e collegalo ai programmi della pagina dei suoni con
       lo stesso pannello Crea un programma, che apre i programmi dei suoni" */
    const sc = FF_SOUNDS.filter(function(x){ return x.id !== 'none'; });
    h = '<div class="ffi-sez">🔊 Il suono</div><div class="ffi-card">' + ffcRigaSw('Il suono parte da solo', p.suonoAuto ? 'Appena inizia la sessione parte il suono che scegli qui sotto.' : 'La sessione parte in silenzio: il suono lo accendi tu, toccando l’icona in alto.', !!p.suonoAuto, 'ffSuonoAutoToggle()')
      + (p.suonoAuto ? ffcLega('<div class="ffi-r col"><div><b>Quale suono</b><small>Parte appena finiscono i dieci secondi per ripensarci.</small></div><label class="ffi-sel"><select onchange="ffSuonoAutoScegli(this.value)">'
          + sc.map(function(x){ return '<option value="' + x.id + '"' + ((p.sound && p.sound !== 'none' ? p.sound : 'rain') === x.id ? ' selected' : '') + '>' + x.name + '</option>'; }).join('')
          + '</select><svg viewBox="0 0 12 8" width="12" height="8" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></label></div>') : '') + '</div>'
      + '<div class="ffi-sez">🎵 Un suono per ogni momento</div>'
      + '<button type="button" class="ffi-prog" onclick="ffSuonoProgrammi()"><span aria-hidden="true">🎧</span><div><b>Crea un programma</b><small>Il suono parte da solo quando ti serve: a un’ora, in un posto o mentre usi un’app.</small></div><svg class="chev" viewBox="0 0 8 12" width="8" height="12" aria-hidden="true"><path fill="none" d="M1 1l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>';
  } else if (FF_IMP.k === 'pausa'){
    const fuori = p.fuori !== 'continua';
    h = '<div class="ffi-card">' + ffcRigaSw('Puoi mettere in pausa', ffPausaPermessa() ? 'Durante la sessione vedi il pulsante della pausa.' : 'Durante la sessione il pulsante della pausa non c’è.', ffPausaPermessa(), 'ffPausaPrefToggle()')
      + (ffPausaPermessa() ? ffcRigaChips('Quanto dura', 'Alla fine la sessione riparte da sola.', [3, 5, 10], ffPausaMin(), 'ffPausaMinSet', function(v){ return v + ' min'; }) : '') + '</div>'
      + '<div class="ffi-sez">🚪 Quando esci dall’app</div>'
      + '<div class="ffi-card">' + ffcRigaSw('Il tempo si ferma', fuori ? 'Se vai su un’altra app il conto si ferma, e riprende quando torni.' : 'Il conto continua a scendere anche mentre sei su un’altra app.', fuori, 'ffFuoriToggle()')
      + (fuori ? ffcRigaChips('Si ferma al massimo per', 'Le app che hai consentito per la sessione non fermano il tempo.', [3, 5, 10, 15], ffFuoriMin(), 'ffFuoriMinSet', function(v){ return v + ' min'; }) : '') + '</div>';
  } else if (FF_IMP.k === 'cicli'){
    h = '<div class="ffi-card">' + ffcRigaSw('🍅 Cicli con pausa', c.on ? c.sessioni + ' sessioni da ' + p.minutes + ' min, con ' + c.pausa + ' min di pausa.' : 'Più sessioni di fila, con una pausa in mezzo.', c.on, 'ffcToggle()')
      + (c.on ? ffcRigaChips('Quante sessioni', 'Finite tutte, il ciclo è chiuso.', [2, 3, 4, 5, 6], c.sessioni, 'ffcSessioni', function(v){ return v + ' sessioni'; })
          + ffcRigaChips('Pausa fra una sessione e l’altra', 'Il telefono è libero per questi minuti.', [5, 10, 15, 20], c.pausa, 'ffcPausa', function(v){ return v + ' min'; })
          + ffcRigaSw('Riparte da sola', 'Finita la pausa, la sessione dopo parte senza toccare niente.', c.auto, 'ffcAuto()') : '') + '</div>';
  } else if (FF_IMP.k === 'bolla'){
    /* 0.9.335, Andrea: "ogni 5 minuti per qualche secondo... COSA succede? Manca il verbo, e l'utente deve vederla" */
    const mb = (typeof ffBollaModo === 'function') ? ffBollaModo() : 'su';
    h = '<div class="ffi-bolla-prev"><div class="ffi-bp-schermo"><i></i><i></i><i></i>'
      + (mb === 'off' ? '<span class="ffi-bp-off">Nessuna bolla</span>' : '<span class="ffi-bp-pill"><i class="ffi-bp-anello"></i><b>' + (mb === 'giu' ? '18:24' : '6:36') + '</b> ' + ffcBollaFrase(mb) + '</span>')
      + '</div></div>'
      + '<p class="ffi-bolla-t">Durante una sessione, ogni 5 minuti compare per qualche secondo questa bolla con il tempo.</p>'
      + '<p class="ffi-bolla-s">La vedi sul telefono e sul computer, anche quando sei dentro a un’altra app.</p>'
      + '<div class="ffi-card">' + ffcRigaChips('Cosa mostra la bolla', 'Tocca una scelta per vederla qui sopra.', ["'su'", "'giu'", "'off'"], "'" + mb + "'", 'ffBollaModoSet', FFI_BOLLA_FMT, 'col') + '</div>';
  } else if (FF_IMP.k === 'schede'){
    h = (typeof ffsImpostazioniHtml === 'function') ? ffsImpostazioniHtml().replace(/<div class="ffi-sez">[\s\S]*?<\/div>/, '') : '';
  }
  box.innerHTML = h;
}
registerScreen('s-ff-imp', '<div class="topbar"><button class="iconbtn" onclick="ffImpEsci()" aria-label="Indietro">' + FFC_SVG_BACK + '</button><b class="blk-title">Impostazioni del Full Focus</b></div><div id="ffImpBody"></div>', { back: function(){ setTimeout(function(){ if (FF_IMP.daFoglio){ FF_IMP.daFoglio = false; try{ ffTimerOpen(); }catch(_){ } } }, 60); return 's-fullfocus'; } });
registerScreen('s-ff-imp2', '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-ff-imp\');ffImpPaint()" aria-label="Indietro">' + FFC_SVG_BACK + '</button><b class="blk-title" id="ffImp2T"></b></div><div id="ffImp2Body"></div>', { back: function(){ try{ ffImpPaint(); }catch(_){ } return 's-ff-imp'; } });
function ffcToggle(){ const c = ffcCicli(); c.on = !c.on; ffSavePref(); ffImpostazioniApri(); }
function ffcPausa(v){ ffcCicli().pausa = v; ffSavePref(); ffImpostazioniApri(); }
function ffcSessioni(v){ ffcCicli().sessioni = v; ffSavePref(); ffImpostazioniApri(); }
function ffcAuto(){ const c = ffcCicli(); c.auto = !c.auto; ffSavePref(); ffImpostazioniApri(); }

/* ---------------------------------------------------------------- la sessione che parte */
/** Il pezzo di catena della sessione che sta per partire, o null se e' una sessione sola. */
function ffcRunCiclo(p){
  if (FFC.prossimo){ const x = FFC.prossimo; FFC.prossimo = null; return x; }
  const c = ffcCicli();
  return c.on ? { n: 1, tot: c.sessioni, pausa: c.pausa, auto: c.auto } : null;
}
function ffcCompito(){
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    if (one && one.task) return String(one.task.text || one.task.t || one.task || '').slice(0, 120);
  }catch(_){ }
  return '';
}
function ffcListe(){
  const p = ffPref();
  const apps = (p.allow || []).slice(); if (apps.indexOf('com.dreambrothers.dreammap') < 0) apps.push('com.dreambrothers.dreammap');
  return { allowApps: apps, allow: (p.allowSites || []).slice(), allowWords: (p.allowWords || []).slice() };
}
/** Quello che il motore deve sapere della catena, scritto insieme all'orario di fine. */
function ffcEngineCiclo(run){
  if (!run || !run.ciclo) return '';
  return JSON.stringify(Object.assign({ n: run.ciclo.n, tot: run.ciclo.tot, pausa: run.ciclo.pausa, auto: run.ciclo.auto,
    minuti: run.minutes, task: ffcCompito(), inizio: run.startAt, pausaFino: 0 }, ffcListe()));
}
/** Rinuncia o «basta cosi'»: la catena si ferma, nessuna sessione dopo. */
async function ffcStop(){
  FFC.prossimo = null;
  try{ await ffcNative({ ffCiclo: '' }); }catch(_){ }
  try{ ffPaint(); }catch(_){ }
}
/** Dopo il verdetto di una sessione del ciclo: il motore ha gia' fatto partire la pausa. */
function ffcDopo(){
  setTimeout(async function(){
    try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
    /* se il telefono ha gia' aperto la sessione dopo (app chiusa durante la pausa), la si prende */
    if (!FF.run && typeof SETTINGS !== 'undefined' && +(SETTINGS && SETTINGS.ffUntil) > Date.now()){ ffcAdottaDaMotore(); return; }
    ffcTickAvvia();
    try{ ffPaint(); }catch(_){ }
  }, 1500);
}

/* ---------------------------------------------------------------- la pausa */
function ffcTickAvvia(){
  clearInterval(FFC.tick);
  FFC.tick = setInterval(function(){
    const s = ffcStato();
    if (!s || !s.pausaFino || FF.run){ clearInterval(FFC.tick); FFC.tick = 0; return; }
    /* la pausa e' finita e la sessione dopo parte da sola: la fa partire il telefono, qui la si adotta */
    if (s.auto && Date.now() > s.pausaFino + 2500){
      clearInterval(FFC.tick); FFC.tick = 0;
      ffcAdottaDaMotore();
      return;
    }
    const scr = document.getElementById('s-fullfocus');
    if (scr && scr.classList.contains('active')) ffPaint();
  }, 1000);
}
/** Disegno della pausa sulla schermata del timer. La chiama ffPaint quando non c'e' sessione.
    0.9.394, Andrea: "'Basta cosi'' finisce sovrapposto al 40:00. Non voglio piu' vedere mai cose sovrapposte: durante la pausa il tempo
    dei 40 minuti lo sostituisce il countdown della pausa". In pausa il numero grande E' la pausa (e non si tocca per cambiarlo), sopra
    la parola Pausa, sotto la frase della sessione dopo con la sua durata, poi il pulsante e in fondo "Basta cosi'": tutto in fila
    (fullfocus.js, ffStatus/ffTime/ffPoi/ffCta/ffBasta), niente scritto dentro a un altro. */
function ffcPausaTesti(s, left){
  const dopo = (s.n + 1) + ' di ' + s.tot;
  const dura = s.minuti ? ' (' + ffcMin(s.minuti) + ')' : '';
  if (left > 0) return { etichetta: 'Pausa', tempo: ffFmt(left),
    poi: s.auto ? 'Poi la sessione ' + dopo + dura + ' parte da sola' : 'Poi tocca a te: sessione ' + dopo + dura,
    cta: 'Inizia subito la sessione ' + dopo };
  /* la pausa e' finita: il numero grande e' la sessione che viene adesso (la sua durata), non un 00:00 fermo */
  return { etichetta: s.auto ? 'Sta ripartendo' : 'Pausa finita', tempo: ffFmt((s.minuti || 0) * 60000),
    poi: s.auto ? 'La sessione ' + dopo + ' sta partendo' : 'Adesso tocca a te: sessione ' + dopo,
    cta: 'Inizia la sessione ' + dopo };
}
function ffcPaint(){
  const s = ffcStato();
  if (!s || !s.pausaFino || FF.run) return;
  const left = s.pausaFino - Date.now();
  const t = ffcPausaTesti(s, left);
  const scr = document.getElementById('s-fullfocus');
  const st = document.getElementById('ffStatus'), tm = document.getElementById('ffTime'), poi = document.getElementById('ffPoi');
  const cta = document.getElementById('ffCta'), basta = document.getElementById('ffBasta');
  if (scr) scr.classList.add('ff-in-pausa');
  if (st){ st.hidden = false; st.textContent = t.etichetta; }
  if (tm) tm.textContent = t.tempo;
  if (poi){ poi.hidden = false; poi.textContent = t.poi; }
  if (cta){ cta.hidden = false; cta.textContent = t.cta; }
  if (basta) basta.hidden = false;
  if (!FFC.tick && left > 0) ffcTickAvvia();
}
/** Il pulsante durante la pausa: la sessione dopo, adesso. */
function ffcProssimaOra(){
  const s = ffcStato();
  if (!s) return false;
  FFC.prossimo = { n: s.n + 1, tot: s.tot, pausa: s.pausa, auto: s.auto };
  const p = ffPref(); if (s.minuti) p.minutes = s.minuti;
  ffStart();
  return true;
}
function ffcInPausa(){ const s = ffcStato(); return !!(s && s.pausaFino && !FF.run); }

/* ---------------------------------------------------------------- le sessioni partite da sole */
/** Una sessione armata dal telefono senza che questa pagina la vedesse partire: diventa FF.run. */
async function ffcAdottaDaMotore(){
  try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
  ffcImporta();
  /* 0.9.309: ff-cicli.js si carica prima di settings.js; chiamata troppo presto, SETTINGS non esiste ancora */
  if (FF.run || typeof SETTINGS === 'undefined') return;
  const until = +(SETTINGS && SETTINGS.ffUntil) || 0;
  if (until <= Date.now()) { try{ ffPaint(); }catch(_){ } return; }
  const s = ffcStato() || {};
  const p = ffPref();
  let prev = null; try{ prev = SETTINGS.ffPrev ? JSON.parse(SETTINGS.ffPrev) : null; }catch(_){ }
  const from = +(SETTINGS.ffFrom) || s.inizio || Date.now();
  /* 0.9.387 (BUG-098): una sessione partita da un programma ha i suoi dieci secondi per ripensarci nella bolla del telefono
     (RipensaciBolla.java). Dentro quei secondi non si adotta: se l'utente salta o rimanda, qui non deve restare una sessione
     fantasma. Si riguarda appena sono passati. */
  /* 0.9.394: si aspetta la fine dei dieci secondi scritta dal telefono (ffGrazia), non dodici secondi dall'inizio: una sessione
     recuperata in ritardo (FocusAuto.recupera) conta dal suo orario vero, che e' prima dei suoi dieci secondi */
  const grazia = Math.max(+(SETTINGS.ffGrazia) || 0, +FFC.grazia || 0);
  if (grazia && grazia <= until && Date.now() < grazia + 2000){ clearTimeout(FFC.adotta); FFC.adotta = setTimeout(ffcAdottaDaMotore, Math.max(500, grazia + 2500 - Date.now())); return; }
  ffcBollaVia();
  const run = { startAt: from, endAt: until, graceUntil: 0, minutes: s.minuti || Math.round((until - from) / 60000),
    tag: p.tag, intent: s.task || p.intent || '', intensive: true, meditazione: false, mode: 'allow', sound: p.sound, prev: prev,
    ciclo: s.tot ? { n: s.n, tot: s.tot, pausa: s.pausa, auto: s.auto } : null, daMotore: true };
  /* 0.9.389 (BUG-115), Andrea: "quando ho acceso il telefono il punto mi era gia' stato assegnato senza che io avessi partecipato".
     La presenza nella pagina del Full Focus comincia ADESSO, non all'ora in cui il telefono l'ha fatta partire (ff-presenza.js) */
  try{ if (typeof ffpAdotta === 'function') ffpAdotta(run, Date.now()); }catch(_){ }
  FF.run = run;
  ffWrite('fl_ff_session', run);
  clearInterval(FF.tick); FF.tick = setInterval(ffTickFn, 1000);
  if (ffPref().suonoAuto && run.sound && run.sound !== 'none'){ run.suonoOn = true; ffSoundStart(run.sound); }
  ffPaint();
}
/** Le sessioni finite ad app chiusa entrano nella storia (e nelle monete) una volta sola. */
function ffcImporta(){
  let log = [];
  try{ log = JSON.parse((SETTINGS && SETTINGS.ffAutoLog) || '[]') || []; }catch(_){ log = []; }
  if (!log.length) return;
  const hist = ffHist();
  let nuove = 0, monete = 0, sole = 0, primaSola = 0;
  log.forEach(function(r){
    if (!r || !r.s || !r.e) return;
    if (hist.some(function(h){ return h && Math.abs((h.start || 0) - r.s) < 60000; })) return;
    const min = +r.m || Math.round((r.e - r.s) / 60000);
    /* 0.9.389 (BUG-115), Andrea: "il punto per essere assegnato deve essere dentro la pagina di Full Focus". Questa sessione la
       pagina non l'ha mai vista: presenza zero, la decide la stessa funzione delle altre (ffpEsito). Resta nella storia, finita,
       ma andata avanti da sola: niente monete e niente punto */
    const spent = Math.max(0, r.e - r.s);
    const daSola = (typeof ffpEsito === 'function') ? !ffpEsito({ startAt: r.s, pres: { ms: 0, attesa: [] } }, r.e, spent).valida : false;
    const coins = daSola ? 0 : Math.round(min * 1.25);
    const voce = { at: r.e, start: r.s, spentMs: spent, stage: 4, min: min, tag: ffPref().tag, ok: true, coins: coins,
      intent: r.t || '', intensive: true, meditazione: false, auto: true };
    if (daSola){ voce.daSola = true; voce.presenzaMs = 0; sole++; if (!primaSola || r.s < primaSola) primaSola = r.s; }
    hist.push(voce);
    nuove++; monete += coins;
  });
  if (!nuove) return;
  /* la riga al ritorno: una sola, anche se le sessioni andate avanti da sole sono piu' d'una */
  if (sole && typeof toast === 'function'){
    const d = new Date(primaSola), ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    try{ toast((sole === 1 ? 'La sessione delle ' + ora + ' è andata avanti senza di te.' : sole + ' sessioni sono andate avanti senza di te.') + ' ' + (typeof FFP_FRASE2 !== 'undefined' ? FFP_FRASE2 : '')); }catch(_){ }
  }
  hist.sort(function(a, b){ return (a.at || 0) - (b.at || 0); });
  ffWrite('fl_ff_hist', hist.slice(-500));
  if (monete) ffAddCoins(monete);
  try{ if (typeof dpCalcola === 'function') dpCalcola(true); }catch(_){ }
}

/* ---------------------------------------------------------------- i programmi */
function ffcProgrammi(){ try{ return JSON.parse(localStorage.getItem(FFC_KEY) || '[]') || []; }catch(_){ return []; } }
function ffcSalvaProgrammi(l){ try{ localStorage.setItem(FFC_KEY, JSON.stringify(l)); }catch(_){ } ffcPush(); }
/** Il motore riceve i programmi, le app consentite e la priorita' di oggi (per la notifica). */
function ffcPush(){
  const l = ffcProgrammi();
  /* 0.9.387 (BUG-098): anche la categoria ("Lavoro"): il promemoria cinque minuti prima e la bolla dei dieci secondi la dicono */
  let cat = ''; try{ const t = (typeof ffTag === 'function') ? ffTag() : null; cat = (t && t.name) || ''; }catch(_){ }
  const payload = Object.assign({ programmi: l, task: ffcCompito(), cat: cat }, ffcListe());
  ffcNative({ ffAuto: l.length ? JSON.stringify(payload) : '' });
}
function ffcGiorniTxt(g){
  const on = (g || []).map(function(x, i){ return x ? i : -1; }).filter(function(i){ return i >= 0; });
  if (on.length === 7) return 'Ogni giorno';
  if (on.length === 5 && on.join() === '0,1,2,3,4') return 'Lun–Ven';
  if (on.length === 2 && on.join() === '5,6') return 'Weekend';
  return on.map(function(i){ return ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'][i]; }).join(' ') || 'Nessun giorno';
}
function ffcProgrammiApri(){
  const l = ffcProgrammi();
  FFC.vista = l.length ? 'lista' : 'vuota';
  /* 0.9.394: si ricontrolla ogni volta che si apre l'elenco (un permesso tolto nel frattempo); si ridisegna solo se cambia */
  if (l.length) setTimeout(ffcPermessiControlla, 0);
  /* 0.9.335, Andrea: "quel popover fa cagare". Una cosa per volta: senza programmi un invito con il disegno,
     con i programmi l'ora grande e i giorni sotto, come una sveglia. */
  if (!l.length){
    ffSheetOpen(ffcTesta('Programmi', 'ffImpostazioniApri()')
      + '<div class="ffc-v2"><span class="ffc-v2-ico">⏰</span><b>Fai partire il Full Focus da solo</b>'
      + '<p>Scegli un’ora e i giorni. A quell’ora la sessione inizia anche se l’app è chiusa.</p></div>'
      + '<button type="button" class="cta ff-go" onclick="ffcProgEdit(\'\')">Scegli l’ora</button>');
    return;
  }
  ffSheetOpen(ffcTesta('Programmi', 'ffImpostazioniApri()')
    + ffcPermessoHtml()
    + l.map(function(x){
        return '<div class="ffc-prog ffc-prog2' + (x.on ? '' : ' spento') + '"><button type="button" class="ffc-prog-t" onclick="ffcProgEdit(\'' + x.id + '\')"><b>' + ffcOra(x.ora) + '</b>'
          + '<small>' + esc(ffcGiorniTxt(x.giorni)) + ' · ' + (x.sessioni > 1 ? x.sessioni + ' sessioni da ' : '') + ffcMin(x.minuti) + '</small></button>'
          + '<button type="button" class="switch' + (x.on ? ' on' : '') + '" onclick="ffcProgOn(\'' + x.id + '\')" aria-label="Acceso"></button></div>';
      }).join('')
    + '<p class="ffc-sotto">Lavora sulla priorità di oggi.</p>'
    /* 0.9.393: il + e' un'icona SVG (mai un carattere), la sottolineatura resta solo sotto alle parole */
    + '<div class="ffc-add-w"><button type="button" class="ff-link ffc-add" onclick="ffcProgEdit(\'\')"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span>Aggiungi un altro orario</span></button></div>');
}
function ffcProgOn(id){
  const l = ffcProgrammi();
  const x = l.filter(function(y){ return y.id === id; })[0]; if (!x) return;
  x.on = !x.on; ffcSalvaProgrammi(l); ffcProgrammiApri();
  if (x.on && typeof toast === 'function') toast('⏰ Alle ' + ffcOra(x.ora) + ' parte da solo');
  if (x.on) ffcPermessiControlla();
}
let FFC_ED = null;
function ffcProgEdit(id){
  const c = ffcCicli();
  const x = ffcProgrammi().filter(function(y){ return y.id === id; })[0];
  FFC_ED = x ? JSON.parse(JSON.stringify(x))
    : { id: 'p' + Date.now().toString(36), on: true, ora: 9 * 60, giorni: [true, true, true, true, true, false, false], minuti: ffPref().minutes || 50, sessioni: c.sessioni || 2, pausa: c.pausa || 10, auto: true };
  /* 0.9.394: l'avviso scelto per questo programma (di serie la notifica 5 minuti prima e la bolla alla partenza) */
  FFC_ED.avviso = ffcAvviso(FFC_ED);
  /* 0.9.393, Andrea: "il pulsante Salva nel popover del nuovo programma non e' sticky e deve comparire solo se l'utente modifica qualcosa".
     La fascia comune del Salva (registry.js, flPiede): compare quando il programma e' diverso da com'era all'apertura */
  try{ if (typeof flPiedeApri === 'function') flPiedeApri('ffc-prog', ffcEdFirma); }catch(_){ }
  ffcEdPaint(!!x);
}
function ffcEdFirma(){ const e = FFC_ED; return e ? JSON.stringify([e.ora, e.giorni, e.minuti, e.sessioni, e.pausa, e.auto, ffcAvviso(e)]) : ''; }

/* L'AVVISO DI OGNI PROGRAMMA (0.9.394). Andrea: "voglio che quando l'utente programma una sessione possa pianificare se ricevere un
   promemoria/notifica X minuti prima, o una chiamata dei sogni che gli ricorda che ha una sessione da fare". Si sceglie nella scheda
   del programma: niente, una notifica o la chiamata dei sogni 5, 10, 15 o 30 minuti prima, e la bolla dei 10 secondi alla partenza.
   Di serie la notifica 5 minuti prima e la bolla, cioe' quello che facevano i programmi della 0.9.387. Lo legge il telefono
   (FocusAuto.java, campo "avviso" di ogni programma in ffAuto). */
const FFC_AVVISO_MIN = [5, 10, 15, 30];
function ffcAvviso(x){
  const a = (x && x.avviso) || {};
  return { tipo: (a.tipo === 'niente' || a.tipo === 'chiamata') ? a.tipo : 'notifica', min: FFC_AVVISO_MIN.indexOf(+a.min) >= 0 ? +a.min : 5, bolla: a.bolla !== false };
}
const FFC_AVV_FMT = function(v){ return v.indexOf('chiamata') >= 0 ? 'La chiamata dei sogni' : (v.indexOf('niente') >= 0 ? 'Niente' : 'Una notifica'); };
function ffcAvvisoHtml(e){
  const av = ffcAvviso(e);
  return '<div class="ffi-sez">Avvisami</div>'
    + '<div class="ffi-card">'
    +   ffcRigaChips('Prima della sessione', av.tipo === 'chiamata' ? 'Il telefono squilla come la chiamata dei sogni e ti ricorda la sessione.' : av.tipo === 'notifica' ? 'Una notifica ti ricorda che la sessione sta per partire.' : 'Nessun avviso prima: la sessione parte e basta.', ["'notifica'", "'chiamata'", "'niente'"], "'" + av.tipo + "'", 'ffcEdAvvTipo', FFC_AVV_FMT, 'col')
    +   (av.tipo !== 'niente' ? ffcLega(ffcRigaChips('Quanto prima', 'I minuti prima dell’inizio della sessione.', FFC_AVVISO_MIN, av.min, 'ffcEdAvvMin', function(v){ return v + ' minuti prima'; })) : '')
    +   ffcRigaSw('La bolla dei 10 secondi', av.bolla ? 'All’ora giusta compare sopra le app: puoi rimandare o saltare.' : 'All’ora giusta la sessione parte subito, senza bolla.', av.bolla, 'ffcEdAvvBolla()')
    + '</div>';
}
function ffcEdAvvTipo(t){ const e = FFC_ED; if (!e) return; e.avviso = Object.assign(ffcAvviso(e), { tipo: t }); ffcEdPaint(ffcEsiste()); }
function ffcEdAvvMin(m){ const e = FFC_ED; if (!e) return; e.avviso = Object.assign(ffcAvviso(e), { min: +m }); ffcEdPaint(ffcEsiste()); }
function ffcEdAvvBolla(){ const e = FFC_ED; if (!e) return; const a = ffcAvviso(e); a.bolla = !a.bolla; e.avviso = a; ffcEdPaint(ffcEsiste()); }
function ffcEdPaint(esiste){
  const e = FFC_ED; if (!e) return;
  FFC.vista = 'scheda';
  ffSheetOpen(ffcTesta(esiste ? 'Modifica il programma' : 'Nuovo programma', 'ffcProgrammiApri()')
    + '<div class="ffi-sez">Quando</div>'
    + '<div class="ffi-card">'
    +   '<div class="ffi-r"><div><b>Ora</b><small>A quest’ora il Full Focus parte da solo.</small></div><input type="time" class="fin ffc-ora" value="' + ffcOra(e.ora) + '" onchange="ffcEdOra(this.value)"></div>'
    +   '<div class="ffi-r col"><div><b>Giorni</b><small>Solo nei giorni accesi.</small></div><div class="ffi-chips giorni">' + FFC_GIORNI.map(function(g, i){ return '<button type="button" class="' + (e.giorni[i] ? 'on' : '') + '" onclick="ffcEdGiorno(' + i + ')">' + g + '</button>'; }).join('') + '</div></div>'
    + '</div>'
    + '<div class="ffi-sez">Quanto</div>'
    + '<div class="ffi-card">'
    +   ffcRigaChips('Durata di una sessione', 'Minuti di concentrazione, senza interruzioni.', [15, 20, 25, 30, 45, 50, 60, 75, 90, 120].concat([15, 20, 25, 30, 45, 50, 60, 75, 90, 120].indexOf(e.minuti) < 0 ? [e.minuti] : []).sort(function(a, b){ return a - b; }), e.minuti, 'ffcEdMin', ffcMin)
    +   ffcRigaChips('Quante sessioni', 'Una sola, o un ciclo con le pause.', [1, 2, 3, 4, 5, 6], e.sessioni, 'ffcEdSes', function(v){ return v === 1 ? '1 sessione' : v + ' sessioni'; })
    +   (e.sessioni > 1
          ? ffcRigaChips('Pausa fra una sessione e l’altra', 'Il telefono è libero per questi minuti.', [5, 10, 15, 20], e.pausa, 'ffcEdPausa', function(v){ return v + ' min'; })
          + ffcRigaSw('Riparte da sola', 'Finita la pausa, la sessione dopo parte senza toccare niente.', e.auto, 'ffcEdAuto()')
          : '')
    + '</div>'
    + ffcAvvisoHtml(e)
    + '<button type="button" class="cta ff-go fl-salva" data-fl="ffc-prog" onclick="ffcEdSalva()">Salva</button>'
    + (esiste ? '<button type="button" class="ff-link ffc-del" onclick="ffcEdElimina()">Elimina il programma</button>' : ''));
}
function ffcEsiste(){ return FFC_ED && ffcProgrammi().some(function(y){ return y.id === FFC_ED.id; }); }
function ffcEdOra(v){ const m = /^(\d{1,2}):(\d{2})/.exec(v || ''); if (m && FFC_ED) FFC_ED.ora = Math.min(1439, (+m[1]) * 60 + (+m[2])); }
function ffcEdGiorno(i){ FFC_ED.giorni[i] = !FFC_ED.giorni[i]; ffcEdPaint(ffcEsiste()); }
function ffcEdMin(v){ FFC_ED.minuti = v; ffcEdPaint(ffcEsiste()); }
function ffcEdSes(v){ FFC_ED.sessioni = v; ffcEdPaint(ffcEsiste()); }
function ffcEdPausa(v){ FFC_ED.pausa = v; ffcEdPaint(ffcEsiste()); }
function ffcEdAuto(){ FFC_ED.auto = !FFC_ED.auto; ffcEdPaint(ffcEsiste()); }
function ffcEdSalva(){
  const e = FFC_ED; if (!e) return;
  if (!e.giorni.some(Boolean)){ toast('Scegli almeno un giorno'); return; }
  const max = typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 90;
  if (e.minuti > max){ toast('Al tuo livello arrivi a ' + max + ' minuti'); return; }
  const l = ffcProgrammi().filter(function(y){ return y.id !== e.id; });
  e.avviso = ffcAvviso(e);
  l.push(e); l.sort(function(a, b){ return a.ora - b.ora; });
  ffcSalvaProgrammi(l);
  FFC_ED = null;
  toast('⏰ Alle ' + ffcOra(e.ora) + ' parte da solo');
  ffcProgrammiApri();
  /* 0.9.394: se al telefono manca qualcosa per farla partire all'ora giusta, lo si dice adesso, con il pulsante che porta li' */
  ffcPermessiControlla();
}

/* I PERMESSI (0.9.394). Andrea: "non viene ricevuta nessuna notifica, e la sessione a volte non parte neanche". Sul telefono vero
   mancava quello che serve, e l'app non lo diceva: senza "Sveglie e promemoria" (su Android 14 un'app appena installata non ce l'ha)
   la sveglia arriva anche dieci minuti dopo; senza le notifiche il promemoria non si vede; senza il servizio di blocco la sessione non
   blocca niente e la bolla non compare. Quando si salva un programma la scheda lo dice, una cosa per volta, con il pulsante che apre
   l'impostazione giusta del telefono. Le impostazioni le cambia l'utente: l'app apre solo la pagina. */
const FFC_PERMESSI = {
  servizio: { t: 'Il blocco di DreamMap è spento', f: 'Senza, all’ora giusta la sessione non blocca le app e la bolla non compare. Accendi DreamMap nelle impostazioni di accessibilità del telefono.', b: 'Apri le impostazioni' },
  esatte: { t: 'Manca il permesso per l’orario preciso', f: 'Senza, il telefono può far partire la sessione con qualche minuto di ritardo. Accendi «Sveglie e promemoria» per DreamMap.', b: 'Apri l’impostazione' },
  notifiche: { t: 'Le notifiche di DreamMap sono spente', f: 'Senza, l’avviso prima della sessione non arriva.', b: 'Accendi le notifiche' }
};
/** Cosa manca, in ordine di importanza. `stato` e' la risposta di ffProgrammiStato; conta solo se c'e' un programma acceso. */
function ffcPermessiMancanti(stato, progs){
  if (!stato) return [];
  const on = (progs || []).filter(function(x){ return x && x.on; });
  if (!on.length) return [];
  const l = [];
  if (stato.servizio === false || stato.servizioVivo === false) l.push('servizio');
  if (stato.esatte === false) l.push('esatte');
  if (stato.notifiche === false && on.some(function(x){ return ffcAvviso(x).tipo !== 'niente'; })) l.push('notifiche');
  return l;
}
async function ffcStatoLeggi(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.ffProgrammiStato) return null;
  try{
    const r = await NATIVE.ffProgrammiStato();
    if (r && Array.isArray(r.registro)) ffcRegistroScrivi(r.registro);
    FFC.stato = r || null;
    return FFC.stato;
  }catch(_){ return null; }
}
async function ffcPermessiControlla(){
  const st = await ffcStatoLeggi();
  const prima = (FFC.mancanti || []).join();
  FFC.mancanti = ffcPermessiMancanti(st, ffcProgrammi());
  /* si ridisegna solo l'elenco dei programmi, se e' ancora quello aperto */
  const sh = (typeof document !== 'undefined') ? document.getElementById('ffSheetWrap') : null;
  if (FFC.mancanti.join() !== prima && FFC.vista === 'lista' && sh && sh.classList.contains('open')) ffcProgrammiApri();
}
function ffcPermessoHtml(){
  const k = (FFC.mancanti || [])[0], x = k && FFC_PERMESSI[k];
  if (!x) return '';
  const f = (k === 'servizio' && FFC.stato && FFC.stato.servizio && FFC.stato.servizioVivo === false)
    ? 'Il telefono l’ha fermato. Spegni e riaccendi DreamMap nelle impostazioni di accessibilità, se no all’ora giusta la sessione non blocca le app.' : x.f;
  return '<div class="ffc-perm"><b>' + x.t + '</b><p>' + f + '</p><button type="button" class="cta ff-go ffc-perm-b" onclick="ffcPermessoApri(\'' + k + '\')">' + x.b + '</button></div>';
}
async function ffcPermessoApri(k){
  try{
    if (k === 'servizio' && NATIVE.openAccessibilitySettings) await NATIVE.openAccessibilitySettings();
    else if (k === 'esatte' && NATIVE.requestAlarmAccess) await NATIVE.requestAlarmAccess({ what: 'exact' });
    else if (k === 'notifiche' && NATIVE.requestAlarmAccess) await NATIVE.requestAlarmAccess({ what: 'notifications' });
  }catch(_){ }
  /* al ritorno dalle impostazioni si ricontrolla: l'avviso sparisce appena il permesso c'e' (come in alarms.js) */
  const giro = function(){ ffcPermessiControlla(); };
  const torna = function(){ if (!document.hidden){ giro(); setTimeout(giro, 900); setTimeout(giro, 2500); document.removeEventListener('visibilitychange', torna); } };
  document.addEventListener('visibilitychange', torna);
  setTimeout(giro, 1500);
}

/* IL REGISTRO (0.9.394): le ultime 50 cose successe alle sessioni programmate sul telefono (FocusAuto.registra: "sveglia di avvio
   messa per le 21:05", "sveglia di avvio scattata", "permesso mancante", "notifica mostrata", "sessione avviata"). Non si mostra
   all'utente: parte con i messaggi all'assistenza (settings.js) e si legge da qui. La chiave non comincia con fl_ apposta: il
   backup porta le chiavi fl_, e il registro di un telefono non deve finire su un altro. */
const FFC_REG_KEY = 'dm_ff_prog_registro';
function ffcRegistroScrivi(l){ try{ localStorage.setItem(FFC_REG_KEY, JSON.stringify((l || []).slice(-50))); }catch(_){ } }
function ffcRegistro(){ try{ return JSON.parse(localStorage.getItem(FFC_REG_KEY) || '[]') || []; }catch(_){ return []; } }
function ffcRegistroAllegato(){
  const l = ffcRegistro();
  return l.length ? '\n\n--- Sessioni programmate del Full Focus (' + (typeof APP_VERSION !== 'undefined' ? APP_VERSION : '') + ')\n' + l.join('\n') : '';
}
async function ffcEdElimina(){
  const e = FFC_ED; if (!e) return;
  if (!(await blkEliminaChiedi())) return;
  ffcSalvaProgrammi(ffcProgrammi().filter(function(y){ return y.id !== e.id; }));
  FFC_ED = null;
  ffcProgrammiApri();
}

/* ---------------------------------------------------------------- l'avvio dell'app */
setTimeout(function(){
  (async function(){
    try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
    ffcImporta();
    /* la priorita' di oggi cambia: la notifica del programma deve dire quella giusta */
    if (ffcProgrammi().length) ffcPush();
    /* 0.9.394: una sessione programmata che doveva gia' essere partita parte adesso (la sveglia puo' essere arrivata tardi) */
    await ffcControlla();
    if (!FF.run && !(ffRead('fl_ff_session', null))) ffcAdottaDaMotore();
    if (ffcInPausa()) ffcTickAvvia();
    ffcStatoLeggi();
  })();
}, 2500);
document.addEventListener('visibilitychange', function(){
  if (document.hidden) return;
  setTimeout(async function(){ if (!FF.run){ await ffcControlla(); ffcAdottaDaMotore(); } ffcStatoLeggi(); }, 600);
});

/* LA SESSIONE PROGRAMMATA CON LA PAGINA APERTA (0.9.394). Andrea: "quando sono entrato nella pagina Full Focus non era ancora
   partita". Una sessione fatta partire dal telefono veniva adottata solo quando l'app tornava visibile: con DreamMap gia' aperta non
   succedeva niente, e la pagina del Full Focus restava ferma sul pulsante di partenza mentre il telefono bloccava. Adesso:
   - il telefono lo dice alla pagina (FocusLockPlugin.notifyFfProgrammato, "ffProgrammato"): la pagina si porta sul Full Focus e,
     finiti i dieci secondi per ripensarci, la sessione e' quella in corso;
   - se la bolla sopra le app non e' potuta comparire (servizio di blocco fermo), la stessa bolla compare dentro la pagina;
   - aprendo la pagina del Full Focus si chiede al telefono se c'e' una sessione programmata da recuperare (ffcControlla). */
async function ffcControlla(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.ffProgrammaControlla) return false;
  if (typeof FF !== 'undefined' && FF.run) return false;
  try{
    const r = await NATIVE.ffProgrammaControlla();
    if (r && r.avviata){ FFC.grazia = +r.grazia || 0; try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ } return true; }
  }catch(_){ }
  return false;
}
/** La notifica, la bolla o la chiamata dei sogni toccate: la pagina del Full Focus, con la sessione in corso se c'e' (assenze.js, "apri"). */
async function ffcDaNotifica(avviso){
  ffcApriPagina();
  if (!(typeof FF !== 'undefined' && FF.run)){
    try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
    await ffcControlla();
    ffcAdottaDaMotore();
  }
  /* la chiamata dei sogni non dice niente prima della risposta: dopo, la pagina dice quando parte */
  if (avviso){ const p = ffcProssimoOggi(); if (p && typeof toast === 'function') toast('Alle ' + ffcOra(p.ora) + ' parte la tua sessione di Full Focus'); }
}
/** Il prossimo programma acceso di oggi, da adesso in poi. */
function ffcProssimoOggi(adesso){
  const d = adesso ? new Date(adesso) : new Date(), m = d.getHours() * 60 + d.getMinutes(), g = (d.getDay() + 6) % 7;
  return ffcProgrammi().filter(function(x){ return x && x.on && x.giorni && x.giorni[g] && x.ora >= m; }).sort(function(a, b){ return a.ora - b.ora; })[0] || null;
}
function ffcApriPagina(){
  const scr = document.getElementById('s-fullfocus');
  if (scr && scr.classList.contains('active')){ try{ ffPaint(); }catch(_){ } return; }
  try{ if (typeof ffOpen === 'function') ffOpen(); else goId('s-fullfocus'); }catch(_){ }
}
/** L'avviso del telefono: una sessione programmata e' partita, saltata o rimandata. Con l'app nascosta non si fa niente: al ritorno ci pensa visibilitychange. */
function ffcEventoProgrammato(ev){
  const fase = ev && ev.fase;
  if (fase === 'avviata'){
    FFC.grazia = +ev.grazia || 0;
    if (typeof document !== 'undefined' && document.hidden) return 'nascosta';
    ffcApriPagina();
    if (FFC.grazia > Date.now() && !ev.bolla) ffcBollaMostra(ev.desc || '', FFC.grazia);
    ffcAdottaDaMotore();
    return 'aperta';
  }
  if (fase === 'saltata' || fase === 'rimandata'){
    clearTimeout(FFC.adotta); ffcBollaVia(); FFC.grazia = 0;
    (async function(){ try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ } try{ ffPaint(); }catch(_){ } })();
    return fase;
  }
  return '';
}
try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.addListener) NATIVE.addListener('ffProgrammato', function(ev){ try{ ffcEventoProgrammato(ev); }catch(_){ } }); }catch(_){ }
/* entrando nella pagina del Full Focus (dopo l'animazione d'ingresso): se c'e' una sessione programmata da recuperare, parte e si vede */
if (typeof document !== 'undefined' && document.addEventListener){
  document.addEventListener('fl:screen', function(e){
    if (!e || e.detail !== 's-fullfocus' || (typeof FF !== 'undefined' && FF.run)) return;
    /* sempre anche l'adozione: una sessione gia' armata dal telefono, di cui la pagina non ha saputo niente, si vede subito */
    setTimeout(async function(){ await ffcControlla(); ffcAdottaDaMotore(); }, 520);
  });
}

/* LA BOLLA DEI DIECI SECONDI DENTRO LA PAGINA (0.9.394): la stessa di RipensaciBolla.java (angolo in alto a sinistra, gradiente del
   brand, anello blu con i secondi, "Rimanda 10 min" e "Salta questa volta"), solo quando quella sopra le app non e' comparsa. */
function ffcBollaMostra(desc, fine){
  if (typeof document === 'undefined') return;
  ffcBollaVia();
  const b = document.createElement('div');
  b.id = 'ffcBolla'; b.className = 'ffc-bolla';
  b.innerHTML = '<div class="ffc-bolla-r"><i class="ffc-bolla-n" id="ffcBollaN">' + ffcSecondi(fine) + '</i><div><b id="ffcBollaT">Parte il tuo Full Focus</b>'
    + (desc ? '<small>' + (typeof esc === 'function' ? esc(desc) : String(desc)) + '</small>' : '') + '</div></div>'
    + '<div class="ffc-bolla-b" id="ffcBollaB"><button type="button" onclick="ffcBollaScelta(\'rimanda\')">Rimanda 10 min</button><button type="button" onclick="ffcBollaScelta(\'salta\')">Salta questa volta</button></div>';
  (document.getElementById('phone') || document.body).appendChild(b);
  requestAnimationFrame(function(){ b.classList.add('in'); });
  clearInterval(FFC.bollaT);
  FFC.bollaT = setInterval(function(){
    const n = ffcSecondi(fine), e = document.getElementById('ffcBollaN');
    if (e) e.textContent = String(n);
    if (n > 0) return;
    clearInterval(FFC.bollaT); FFC.bollaT = 0;
    const t = document.getElementById('ffcBollaT'), bb = document.getElementById('ffcBollaB');
    if (t) t.textContent = 'Si parte. Buon lavoro!';
    if (bb) bb.hidden = true;
    setTimeout(ffcBollaVia, 1400);
  }, 250);
}
/** I secondi che restano: come AvvioProgrammato.secondiRimasti (10, 9, ... 1, poi 0). */
function ffcSecondi(fine){ const r = fine - Date.now(); return r <= 0 ? 0 : Math.min(99, Math.ceil(r / 1000)); }
function ffcBollaVia(){
  clearInterval(FFC.bollaT); FFC.bollaT = 0;
  try{ const b = document.getElementById('ffcBolla'); if (b) b.remove(); }catch(_){ }
}
async function ffcBollaScelta(s){
  let ok = false;
  try{ const r = await NATIVE.ffProgrammaScelta({ scelta: s }); ok = !!(r && r.ok); }catch(_){ }
  ffcBollaVia();
  if (!ok){ try{ toast('I dieci secondi sono finiti, la sessione è partita'); }catch(_){ } return; }
  try{ toast(s === 'rimanda' ? 'Rimandata di 10 minuti' : 'Saltata. Il programma resta acceso per la prossima volta'); }catch(_){ }
}
(function(){
  if (typeof document === 'undefined' || !document.head) return;
  const st = document.createElement('style');
  st.textContent = '.ffc-bolla{position:absolute;left:10px;top:calc(env(safe-area-inset-top,0px) + 8px);z-index:9998;max-width:calc(100% - 20px);box-sizing:border-box;padding:12px 14px;border-radius:24px;background:linear-gradient(90deg,#F6CCCC,#F0CFEF,#DFD2F8,#C7DDFF,#B8E5FF,#D2F9FB);color:#001E44;box-shadow:0 6px 18px rgba(0,30,68,.22);transform:translateX(-40px);opacity:0;transition:transform .3s,opacity .25s}'
    + '.ffc-bolla.in{transform:none;opacity:1}.ffc-bolla-r{display:flex;align-items:center;gap:11px}'
    + '.ffc-bolla-n{flex:none;display:flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:50%;border:3px solid #0075E3;box-sizing:border-box;font:800 15px var(--font-body);font-style:normal;color:#001E44}'
    + '.ffc-bolla b{display:block;font:800 16.5px var(--font-body);color:#001E44}.ffc-bolla small{display:block;margin-top:2px;font:700 13.5px/1.35 var(--font-body);color:rgba(0,30,68,.8)}'
    + '.ffc-bolla-b{display:flex;gap:8px;margin-top:12px}.ffc-bolla-b button{min-height:44px;padding:9px 14px;border-radius:99px;border:1px solid rgba(0,30,68,.2);background:rgba(255,255,255,.8);font:800 13.5px var(--font-body);color:#001E44;cursor:pointer}'
    /* l'avviso di un permesso che manca, in cima all'elenco dei programmi */
    + '.ffc-perm{margin:4px 0 22px;padding:18px 18px 16px;border-radius:20px;background:#FFF4E5;border:1.5px solid #FFC879;text-align:left}.ffc-perm b{display:block;font:800 16px/1.3 var(--font-display);color:#001E44}'
    + '.ffc-perm p{margin:8px 0 14px;font:500 14px/1.5 var(--font-body);color:#3A4A63}.ffc-perm-b{width:100%}'
    + 'body.dark .ffc-perm{background:#2A2210;border-color:#7A5A1E}body.dark .ffc-perm b{color:#fff}body.dark .ffc-perm p{color:rgba(255,255,255,.8)}';
  document.head.appendChild(st);
})();

(function(){
  const css = [
    /* la pagina delle impostazioni (0.9.201): tre livelli di contrasto, una riga per voce, una card per gruppo */
    '.ffi-sez{margin:30px 2px 12px;font:800 19px var(--font-display);color:var(--navy)}',
    'body.dark .ffi-sez{color:#fff}',
    '#ffImp2Body > .ffi-sez:first-child{margin-top:8px}',
    '.ffi-grp{gap:14px;padding:18px 16px}.ffi-grp > span:first-child{font-size:24px}.ffi-grp-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}.ffi-grp-t b{font:800 16.5px var(--font-display);color:var(--navy)}.ffi-grp-t small{font:500 13px/1.35 var(--font-body);color:var(--muted)}body.dark .ffi-grp-t b{color:#fff}',
    '.ffi-card{border:1px solid var(--line);border-radius:18px;padding:0 16px;background:var(--card,#fff)}',
    '.ffi-card.primo{margin-top:4px;background:#F3F5F8;border:0;padding:4px 18px}',
    '.ffi-r{display:flex;align-items:center;gap:14px;width:100%;padding:16px 0;border-top:1px solid var(--line);text-align:left}',
    '.ffi-r:first-child{border-top:0}.ffi-r > div:first-child{flex:1;min-width:0}',
    '.ffi-r b{display:block;font:800 15.5px/1.25 var(--font-body);color:var(--navy)}',
    '.ffi-r small{display:block;margin-top:4px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.ffi-r.col{flex-direction:column;align-items:stretch;gap:0}',
    '.ffi-r.vai{background:transparent;border-left:0;border-right:0;border-bottom:0;cursor:pointer;font:inherit;color:inherit}',
    '.ffi-r.vai > span{font:700 13.5px var(--font-body);color:var(--muted);white-space:nowrap}',
    '.ffi-r.vai .chev{flex:none;color:var(--muted)}',
    '.ffi-chips{display:flex;gap:8px;margin-top:12px}',
    /* 0.9.315: pillole con un margine vero intorno al testo; quelle con le parole lunghe vanno una per riga */
    '.ffi-chips button{flex:1;min-width:0;min-height:48px;border-radius:99px;border:1.5px solid var(--line);background:var(--card,#fff);font:800 14.5px/1.2 var(--font-body);color:var(--navy);cursor:pointer;padding:10px 8px}',
    '.ffi-chips.col{flex-direction:column}.ffi-chips.col button{flex:none;width:100%;padding:13px 20px}',
    '.ffi-chips button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.ffi-chips.giorni{gap:6px}.ffi-chips.giorni button{font-size:13px;padding:10px 0}',
    'body.dark .ffi-card{background:#12203A;border-color:#22345A}body.dark .ffi-card.primo{background:#0E1B33}',
    'body.dark .ffi-r{border-top-color:#22345A}body.dark .ffi-r b{color:#fff}',
    'body.dark .ffi-chips button{background:#16233A;border-color:#22345A;color:#fff}body.dark .ffi-chips button.on{background:#0075E3;border-color:#0075E3}',
    '#ffSheet .ffi-sez{text-align:center;margin:30px 0 12px}',
    '#ffSheet .ffi-card{margin-bottom:6px}',
    '#ffSheet .ffc-r.ffc-col > b,#ffSheet .ffc-r.ffc-col > small{text-align:center}',
    /* OEOF e colore selettivo: acceso solo quello scelto, il resto spento */
    '#ffSheet .ff-pre:not(.on){filter:grayscale(1);opacity:.62}',
    '.ffc-box{display:flex;flex-direction:column;gap:12px;margin:4px 0 12px;padding:12px 16px;border:1px solid var(--line);border-radius:16px}',
    '.ffc-r{display:flex;align-items:center;justify-content:space-between;gap:12px}',
    '.ffc-r.ffc-col{flex-direction:column;align-items:stretch;gap:8px}',
    '.ffc-r > b{font:800 14px var(--font-body);color:var(--navy);white-space:nowrap}',
    '.ffc-chips{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}',
    '.ffc-chips .ff-pre{padding:8px 14px}',
    '.ffc-giorni{flex-wrap:nowrap;gap:6px}',
    '.ffc-g{flex:1 1 0;min-width:0;max-width:40px;padding:8px 0 !important;text-align:center}',
    '.ffc-ora{max-width:120px;text-align:center}',
    '.ffc-prog-link{display:block;width:100%;margin:4px 0 16px;text-align:center}',
    '.ffc-sotto{margin:0 0 16px;font:500 13.5px/1.45 var(--font-body);color:var(--muted);text-align:center}',
    '.ffc-vuoto{margin:16px 0 24px;text-align:center;color:var(--muted)}',
    '.ffc-prog{display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;border:1px solid var(--line);border-radius:16px}',
    '.ffc-prog-t{flex:1;display:flex;flex-direction:column;align-items:flex-start;gap:4px;background:none;border:0;padding:0;text-align:left;cursor:pointer}',
    '.ffc-prog-t b{font:800 15px var(--font-body);color:var(--navy)}',
    '.ffc-prog-t small{font:500 12.5px var(--font-body);color:var(--muted)}',
    '.ffc-del{display:block;margin:12px auto 0;color:#E63946}',
    'body.dark .ffc-r > b, body.dark .ffc-prog-t b{color:#fff}',
    'body.dark .ffc-box, body.dark .ffc-prog{border-color:#22345A}'
  ].join('\n');
  const st = document.createElement('style'); st.id = 'ffc-css'; st.textContent = css;
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = ''
    + '.ffi-sel{position:relative;display:block;margin-top:10px}.ffi-sel select{width:100%;box-sizing:border-box;-webkit-appearance:none;appearance:none;border:1.5px solid #BCE0FF;border-radius:14px;padding:13px 40px 13px 14px;background:var(--card,#fff);color:var(--navy);font:700 15px var(--font-body);cursor:pointer}'
    + '.ffi-sel svg{position:absolute;right:15px;top:50%;margin-top:-4px;color:#0075E3;pointer-events:none}body.dark .ffi-sel select{background:#0B2550;border-color:#2C4A80;color:#fff}body.dark .ffi-sel svg{color:#8CC6FF}'
    + '.ffi-bolla-prev{display:flex;justify-content:center;margin:6px 0 18px}.ffi-bp-schermo{position:relative;width:230px;height:150px;border-radius:22px;background:linear-gradient(180deg,#DCEBFF,#F0FBFF);border:1.5px solid #BCE0FF;overflow:hidden;display:flex;flex-direction:column;gap:9px;padding:52px 18px 0;box-sizing:border-box}'
    + '.ffi-bp-schermo > i{display:block;height:9px;border-radius:5px;background:rgba(0,30,68,.1)}.ffi-bp-schermo > i:nth-child(2){width:78%}.ffi-bp-schermo > i:nth-child(3){width:58%}'
    + '.ffi-bp-pill{position:absolute;left:10px;top:12px;display:flex;align-items:center;gap:6px;padding:7px 12px 7px 9px;border-radius:99px;background:linear-gradient(90deg,#F6CCCC,#DFD2F8,#B8E5FF);color:#001E44;font:700 11.5px var(--font-body);white-space:nowrap;box-shadow:0 4px 12px rgba(0,30,68,.18);animation:ffiBp 2.4s ease-in-out infinite}'
    + '.ffi-bp-pill b{font:800 13px var(--font-body)}.ffi-bp-anello{width:11px;height:11px;border-radius:50%;border:2.5px solid #0075E3;box-sizing:border-box}'
    + '.ffi-bp-off{position:absolute;left:0;right:0;top:16px;text-align:center;font:700 12px var(--font-body);color:var(--muted)}'
    + '@keyframes ffiBp{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}'
    + '.ffi-bolla-t{margin:0 8px 6px;text-align:center;font:800 17px/1.35 var(--font-display);color:var(--navy)}.ffi-bolla-s{margin:0 8px 18px;text-align:center;font:500 14px/1.45 var(--font-body);color:var(--muted)}'
    + 'body.dark .ffi-bp-schermo{background:linear-gradient(180deg,#14305E,#0B2550);border-color:#2C4A80}body.dark .ffi-bp-schermo > i{background:rgba(255,255,255,.12)}'
    + '.ffc-v2{text-align:center;padding:10px 6px 22px}.ffc-v2-ico{display:inline-flex;align-items:center;justify-content:center;width:76px;height:76px;border-radius:50%;background:#F0FBFF;font-size:38px;line-height:1}'
    + '.ffc-v2 b{display:block;margin:16px 0 8px;font:800 19px var(--font-display);color:var(--navy)}.ffc-v2 p{margin:0 auto;max-width:290px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}body.dark .ffc-v2-ico{background:#14305E}'
    + '.ffc-prog2 .ffc-prog-t b{font:800 30px/1 var(--font-display);letter-spacing:-.01em}.ffc-prog2 .ffc-prog-t small{margin-top:6px}.ffc-prog2.spento .ffc-prog-t{opacity:.5}'
    + '.ffc-add{display:block;margin:6px auto 4px}'
    /* 0.9.393, Andrea: "Lavora sulla priorita' di oggi e' troppo attaccato al pannello" e "Aggiungi un altro orario e' troppo piccolo e
       la sottolineatura troppo vicina al testo: va bene che sia testo sottolineato e non un pulsante, ma il testo deve essere piu' grande e
       la sottolineatura piu' distanziata, per far capire che e' cliccabile". Lo stile del link sottolineato e' uno per tutta l'app
       (registry.js, FL_LINK_SEL): qui solo lo spazio sopra e sotto */
    + '.ffc-sotto{margin:22px 0 18px!important}'
    + '.ffc-add{display:inline-flex;align-items:center;gap:6px;margin:4px auto 6px}.ffc-add svg{flex:none}'
    + '.ffc-add-w{text-align:center}';
  document.head.appendChild(st);
})();
/* 0.9.380, Andrea: "nelle impostazioni del Full Focus (la sessione, suono e bolla, telefono e schermo) i pannelli sono attaccati ai bordi e
   non c'e' contrasto: il pannello che raccoglie tante impostazioni va scuro, con spazio vuoto intorno". Horror vacui da evitare: ogni pannello
   di un sottomenu e' scuro, con margine dai bordi e respiro fra un gruppo e l'altro */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '#ffImp2Body{padding:0 6px 24px}#ffImp2Body .ffi-sez{margin:34px 4px 14px}'
  + '#ffImp2Body .ffi-card{background:linear-gradient(170deg,#0B2E5E,#001E44)!important;border:0!important;padding:4px 18px!important;border-radius:22px!important;box-shadow:0 10px 24px rgba(0,30,68,.14)}'
  + '#ffImp2Body .ffi-card .ffi-r{border-top-color:rgba(140,198,255,.18)!important;padding:18px 0}#ffImp2Body .ffi-card .ffi-r b{color:#fff!important}#ffImp2Body .ffi-card .ffi-r small{color:rgba(200,225,255,.78)!important}'
  + '#ffImp2Body .ffi-card .ffi-r.vai > span,#ffImp2Body .ffi-card .chev{color:#8CC6FF!important}'
  + '#ffImp2Body .ffi-card .ffi-chips button:not(.on){background:rgba(255,255,255,.08)!important;border-color:rgba(140,198,255,.3)!important;color:#fff!important}'; document.head.appendChild(st); })();

/* 0.9.381: una scelta che dipende dalla levetta sopra sta attaccata a lei, senza riga divisoria in mezzo */
function ffcLega(html){ return String(html).replace('<div class="ffi-r', '<div class="ffi-lega ffi-r'); }
/* LA BOLLA DEL TEMPO, nella pagina della sessione: una levetta; solo se e' accesa, cosa mostra e l'anteprima */
function ffcBollaHtml(){
  const mb = (typeof ffBollaModo === 'function') ? ffBollaModo() : 'off', on = mb !== 'off';
  /* 0.9.382, Andrea: "l'immagine della bolla che fluttua va PRIMA della levetta: quando parli della bolla del tempo l'utente deve capire di
     cosa parli. Le immagini vanno sempre per prime". L'anteprima apre il pannello, accesa o spenta; sotto la levetta e, se accesa, cosa mostra */
  const giu = mb === 'giu';
  return '<div class="ffi-sez">🫧 La bolla del tempo</div><div class="ffi-card">'
    + '<div class="ffi-bolla-prev ffi-bolla-in ffi-bolla-top' + (on ? '' : ' spenta') + '"><div class="ffi-bp-schermo"><i></i><i></i><i></i><span class="ffi-bp-pill"><i class="ffi-bp-anello"></i><b>' + (giu ? '18:24' : '6:36') + '</b> ' + ffcBollaFrase(giu ? 'giu' : 'su') + '</span></div></div>'
    + ffcRigaSw('Mostra la bolla del tempo', on ? 'Ogni 5 minuti compare per qualche secondo, anche dentro a un’altra app.' : 'Spenta: durante la sessione non compare niente sulle altre app.', on, 'ffBollaToggle()')
    + (on ? ffcLega(ffcRigaChips('Cosa mostra', 'Tocca una scelta per vederla nell’immagine qui sopra.', ["'su'", "'giu'"], "'" + mb + "'", 'ffBollaModoSet', FFI_BOLLA_FMT, 'col')) : '')
    + '</div>';
}
function ffSuonoAutoScegli(id){ const p = ffPref(); p.sound = id; ffSavePref(); try{ flVibra(6); }catch(_){ } }
function ffSuonoProgrammi(){
  try{ if (typeof suoProgApri === 'function'){ suoProgApri(); return; } }catch(_){ }
  try{ if (typeof newBlock === 'function') newBlock('sound'); }catch(_){ }
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '#ffImp2Body .ffi-card .ffi-r.ffi-lega{border-top:0!important;padding-top:4px!important}'
  /* Andrea: "nelle schede aperte il testo appare scuro su scuro e diventa bianco in ritardo": il colore giusto subito, non dal guardiano */
  + '#ffImp2Body .ffi-card .ffs-nota{color:rgba(200,225,255,.82)!important}'
  + '#ffImp2Body .ffi-bolla-in{margin:6px 0 14px}#ffImp2Body .ffi-bolla-top{margin:16px 0 4px}#ffImp2Body .ffi-bolla-top + .ffi-r{border-top:0!important}#ffImp2Body .ffi-bolla-top.spenta .ffi-bp-pill{opacity:.55}'
  + '#ffImp2Body .ffi-sez{margin-top:30px!important}'
  + '.ffi-prog{display:flex;align-items:center;gap:14px;width:100%;padding:18px 16px;border-radius:18px;border:1px solid rgba(140,198,255,.25);background:linear-gradient(170deg,#0B2E5E,#001E44);color:#fff;text-align:left;font:inherit;cursor:pointer}'
  + '.ffi-prog > span{font-size:26px}.ffi-prog div{flex:1}.ffi-prog b{display:block;font:800 15.5px var(--font-display);color:#fff}.ffi-prog small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:rgba(200,225,255,.8)}.ffi-prog .chev{color:#8CC6FF}';
  document.head.appendChild(st); })();
