/* ===========================================================================================
   LA PRESENZA NEL FULL FOCUS (0.9.389, BUG-115)

   Andrea (25/11): "Stamattina avevo programmato il Full Focus. Quando ho acceso il telefono il punto
   mi era gia' stato assegnato senza che io avessi partecipato [...]. Il punto per essere assegnato
   deve essere dentro l'app di DreamMap, dentro la pagina di Full Focus, non fuori dall'app o quando
   l'utente sblocca il telefono e la sessione intanto continua ad andare in background."

   LA CAUSA. Il punto (mgFocusPoint in ffFinish, il punto prenotato di prenota.js, la prova
   dell'arbitro mgProofToday, le sessioni "portate a termine" della partita) guardava una cosa sola:
   il tempo era finito (ok). Una sessione programmata la fa partire il telefono all'orario
   (FocusAuto.java) e la chiude da solo: alla riapertura la pagina la adottava (ffcAdottaDaMotore) e
   la chiudeva come riuscita, o la importava gia' finita (ffcImporta) con ok: true. Nessuno guardava
   se l'utente c'era.

   LA REGOLA, una sola per le sessioni avviate a mano e per quelle programmate (ffpEsito):
   il punto si prende se si e' stati nella pagina del Full Focus per almeno l'80% del tempo di
   lavoro (le uscite fino a due minuti si perdonano sempre). Conta come "nella pagina":
   - la pagina del Full Focus (s-fullfocus e le sue pagine s-ff-*) davanti, con l'app aperta;
   - lo schermo spento PARTENDO dalla pagina del Full Focus, con la sessione accesa (o nella pausa
     di un ciclo): e' il telefono messo giu' a faccia in giu', la cosa per cui il Full Focus esiste.
     La pagina tiene lo schermo acceso da sola (flSchermoAcceso -> FLAG_KEEP_SCREEN_ON), quindi lo
     schermo si spegne solo se lo spegne l'utente col tasto o se ha scelto lui di lasciarlo spegnere.
     Togliere il punto a chi lavora col telefono spento sarebbe punire proprio chi fa la cosa giusta.
     Per sapere che era spento e non su un'altra app si chiede al telefono (getTopApps) quanto tempo
     e' passato sulle altre app in quel tratto: solo quello va fuori.
   Non conta: l'app chiusa o su un'altra app, le altre pagine di DreamMap, e il tempo prima che
   l'utente apra la pagina in una sessione partita da sola. Una sessione mai vista dalla pagina
   (finita ad app chiusa) ha presenza zero.
   0.9.394, l'eccezione dell'arrivo: in una sessione partita da sola, i primi minuti (fino a
   FFP_ARRIVO_MS) prima di arrivare nella pagina contano, tolto il tempo sulle altre app. Chi tocca
   la notifica e arriva ha usato il telefono solo per entrare (ffpAdotta).
   Senza la presenza la sessione resta nella storia, finita (ok), con daSola: true: "andata
   avanti senza di te". Niente punto, niente monete, niente scrigno, niente "Hai completato la
   task?" (che confermerebbe il punto prenotato). Al ritorno lo dice una riga sola.
   =========================================================================================== */
const FFP_QUOTA = 0.8;                 // la parte del tempo di lavoro da passare nella pagina
const FFP_TOLLERANZA_MS = 2 * 60000;   // uscite brevi: fino a due minuti fuori va sempre bene
const FFP_VIA_KEY = 'fl_ff_pres_via';  // lo schermo spento dalla pagina durante la pausa di un ciclo
const FFP_ARRIVO_MS = 10 * 60000;      // 0.9.394: il tempo per arrivare nella pagina in una sessione partita da sola (ffpAdotta)
const FFP_FRASE = 'La sessione è andata avanti senza di te.';
const FFP_FRASE2 = 'Il punto si prende facendola qui, con la pagina del Full Focus aperta.';

/** La pagina che si vede adesso (nav.js: order[cur]). */
function ffpSchermata(){ try{ return (typeof order !== 'undefined' && typeof cur !== 'undefined') ? String(order[cur] || '') : ''; }catch(_){ return ''; } }
function ffpPaginaFF(id){ return /^s-(fullfocus|ff-)/.test(id == null ? ffpSchermata() : String(id)); }
function ffpNascosta(){ try{ return !!(typeof document !== 'undefined' && document.hidden); }catch(_){ return false; } }
/** 'qui' (pagina del Full Focus davanti), 'via' (app nascosta: schermo spento o un'altra app), 'altrove' (un'altra pagina di DreamMap). */
function ffpStato(){ return ffpNascosta() ? 'via' : (ffpPaginaFF() ? 'qui' : 'altrove'); }

/** Il registro della presenza, nuovo per ogni sessione. */
function ffpNuova(run, stato, ora){
  if (!run) return null;
  run.pres = { ms: 0, da: stato === 'qui' ? ora : 0, via: 0, attesa: [] };
  return run.pres;
}

/**
 * Il conto, a ogni cambio. `ms` sono i tratti chiusi nella pagina; `da` il tratto in corso; `via` l'inizio dello schermo
 * spento (o di un'altra app) PARTENDO dalla pagina: quel tratto si decide dopo, chiedendo al telefono (attesa).
 * Nascondersi partendo da un'altra pagina non apre nessun tratto: quel tempo e' fuori.
 */
function ffpSegna(run, stato, ora){
  const p = run && run.pres; if (!p) return;
  const eraQui = !!p.da;
  if (p.da && stato !== 'qui'){ p.ms += Math.max(0, ora - p.da); p.da = 0; }
  if (p.via && stato !== 'via'){ p.attesa.push({ da: p.via, a: ora }); p.via = 0; }
  if (stato === 'qui' && !p.da) p.da = ora;
  if (stato === 'via' && eraQui && !p.via) p.via = ora;
}

/** Quanto, nei tratti con l'app nascosta, e' passato sulle ALTRE app. Senza il telefono (o senza il permesso) non si sa: zero. */
async function ffpFuoriMs(da, a){
  if (!(a > da) || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return 0;
  try{
    const r = await Promise.race([
      /* qualche secondo prima: l'altra app si apre un attimo prima che la pagina se ne accorga (come in ffFuoriRientro) */
      NATIVE.getTopApps({ from: da - 5000, to: a, limit: 80, by: 'ms', icons: 0, minMs: 1000 }),
      new Promise(function(ok){ setTimeout(function(){ ok(null); }, 2500); })
    ]);
    let fuori = 0;
    ((r && r.apps) || []).forEach(function(x){ if (x && !x.self) fuori += +x.ms || 0; });
    return Math.min(fuori, a - da);
  }catch(_){ return 0; }
}

/** Prima del verdetto: si chiude il tratto aperto e si chiede al telefono cosa e' successo nei tratti con l'app nascosta. */
async function ffpRisolvi(run, fine){
  const p = run && run.pres; if (!p) return;
  if (p.via){ p.attesa.push({ da: p.via, a: Math.max(p.via, fine) }); p.via = 0; }
  for (let i = 0; i < p.attesa.length; i++){
    const t = p.attesa[i];
    if (t.fuori == null) t.fuori = await ffpFuoriMs(t.da, t.a);
  }
}

/**
 * LA FUNZIONE CHE DECIDE. `fine`: dove finisce la sessione (i tratti oltre non contano); `lavoratoMs`: il tempo di lavoro
 * (ffSpeso, senza le pause). Una sessione senza registro (`pres`) e' una sessione partita con la versione di prima: vale
 * come prima. Una sessione che la pagina non ha mai visto si passa con `pres: { ms: 0 }`.
 */
function ffpEsito(run, fine, lavoratoMs){
  const dur = Math.max(0, +lavoratoMs || 0);
  const p = run && run.pres;
  if (!p) return { conosciuta: false, presenteMs: dur, lavoratoMs: dur, quota: 1, valida: true };
  const inizio = +(run.startAt) || 0;
  const taglia = function(da, a){ return Math.max(0, Math.min(a, fine) - Math.max(da, inizio)); };
  let pres = +p.ms || 0;
  if (p.da) pres += taglia(p.da, fine);
  (p.attesa || []).forEach(function(t){ pres += Math.max(0, taglia(t.da, t.a) - (+t.fuori || 0)); });
  if (p.via) pres += taglia(p.via, fine);   // non ancora chiesto al telefono: si fida
  pres = Math.min(pres, dur);
  const assente = dur - pres;
  return { conosciuta: true, presenteMs: pres, lavoratoMs: dur, quota: dur ? pres / dur : 1,
    valida: assente <= Math.max(FFP_TOLLERANZA_MS, (1 - FFP_QUOTA) * dur) };
}

/** Una sessione della storia vale il punto (e la prova dell'arbitro)? Finita, e fatta davvero. */
/* 0.9.404 BUG-314: e nemmeno una sessione sotto la soglia della tabella unica (ffSessioneCorta, fullfocus.js: meno di 10 minuti veri) */
function ffPuntoValido(x){ return !!(x && x.ok && !x.daSola && !(typeof ffSessioneCorta === 'function' ? ffSessioneCorta(x) : x.corta)); }

/* ---------------------------------------------------------------- gli ascoltatori */
/** Il conto della sessione in corso, a ogni cambio di pagina, di schermo o di app. */
function ffpOra(){
  try{
    const ora = Date.now();
    const run = (typeof FF !== 'undefined') ? FF.run : null;
    if (run && run.pres){
      ffpSegna(run, ffpStato(), ora);
      if (typeof ffWrite === 'function') ffWrite('fl_ff_session', run);
      return;
    }
    /* la pausa di un ciclo: lo schermo spento dalla pagina continua nella sessione dopo, se parte da sola */
    if (!run && typeof ffcInPausa === 'function' && ffcInPausa()){
      if (ffpNascosta() && ffpPaginaFF()) ffpViaScrivi({ da: ora, a: 0 });
      else if (!ffpNascosta()){ const v = ffpViaLeggi(); if (v && !v.a){ v.a = ora; ffpViaScrivi(v); } }
    }
  }catch(_){ }
}
function ffpViaLeggi(){ try{ return JSON.parse(localStorage.getItem(FFP_VIA_KEY) || 'null'); }catch(_){ return null; } }
function ffpViaScrivi(v){ try{ if (v) localStorage.setItem(FFP_VIA_KEY, JSON.stringify(v)); else localStorage.removeItem(FFP_VIA_KEY); }catch(_){ } }

/**
 * Una sessione partita dal telefono diventa FF.run (ffcAdottaDaMotore). La presenza comincia adesso, se la pagina e'
 * davanti. Solo la sessione DOPO LA PAUSA di un ciclo si porta dietro lo schermo spento lasciato nella pagina durante
 * la pausa: chi ha messo giu' il telefono nel mezzo del ciclo e' ancora li'. Un programma che parte la mattina no:
 * la pagina lasciata aperta la sera prima non e' una presenza.
 */
function ffpAdotta(run, ora){
  ffpNuova(run, ffpStato(), ora);
  const v = ffpViaLeggi(); ffpViaScrivi(null);
  if (v && run.ciclo && run.ciclo.n > 1){
    const da = Math.max(+v.da || 0, +run.startAt || 0), a = +v.a || (ffpNascosta() ? 0 : ora);
    if (a && a > da) run.pres.attesa.push({ da: da, a: a });
    else if (!a && ffpNascosta()) run.pres.via = da;
    return run.pres;
  }
  /* L'ARRIVO (0.9.394). Andrea ha visto "La sessione e' andata avanti senza di te" su una sessione programmata: era partita da sola,
     lui e' entrato nella pagina qualche minuto dopo, e quei minuti contavano come assenza. Ma chi tocca la notifica o la bolla e
     arriva nella pagina ha usato il telefono solo per entrare: non e' stato via. Il tempo fra l'inizio della sessione partita da
     sola e l'arrivo nella pagina conta come presenza, se e' entro FFP_ARRIVO_MS, TOLTO il tempo passato sulle altre app (si chiede
     al telefono come per lo schermo spento: ffpRisolvi). Chi in quei minuti era su un'altra app quel tempo lo perde; chi arriva
     mezz'ora dopo no: quella sessione e' andata avanti senza di lui (BUG-115 resta: il punto si prende stando nella pagina). */
  const inizio = +run.startAt || 0, ritardo = ora - inizio;
  if (run.daMotore && inizio > 0 && ritardo > 0 && ritardo <= FFP_ARRIVO_MS) run.pres.attesa.push({ da: inizio, a: ora, arrivo: true });
  return run.pres;
}

if (typeof document !== 'undefined' && document.addEventListener){
  document.addEventListener('visibilitychange', ffpOra);
  document.addEventListener('fl:screen', function(){ setTimeout(ffpOra, 0); });
}
