/* ===========================================================================================
   LA LETTURA DEL GENIO: I NUMERI E LE FRASI, IN UN POSTO SOLO (22/11/2026, Andrea)

   Prima ogni schermata faceva i conti per conto suo: l'intro dava il 45% a un Sognatore, la
   lettura il 37% a un Disciplinato che aveva risposto in modo impeccabile, la scheda Identita'
   scriveva "Stai diventando" anche all'Inconcludente, il triangolo dava "Identita' 30%" a chi
   aveva appena fatto la lettura e "Azione 0%" a chi l'app l'aveva aperta da un giorno.

   Qui ci sono le regole, una volta sola, e tutte le schermate le chiamano:
   · fraseProfilo: "Stai diventando ..." per i profili che portano avanti (Disciplinato,
     Realizzatore), "Se continui così, rischi di diventare ..." per tutti gli altri. Mai
     "Se continui così, diventi".
   · glProbabilita: la probabilita' di realizzare il sogno. Ogni profilo ha la sua fascia,
     ordinata (un Disciplinato sta sopra a un Sognatore, che sta sopra a un Inconcludente), e
     dentro la fascia conta quanto le risposte somigliano a quelle di chi ce la fa: risposte
     migliori, numero piu' alto. Sempre.
   · glIdentita, glAzione, glTreScegli: i tre lati della combinazione segreta. L'identita'
     viene dal profilo e dalle risposte; l'azione si misura solo quando ci sono abbastanza
     giorni (prima e' "la misuro nei prossimi giorni", non 0%, con le abitudini gia' viste: glAbitudiniViste); il numero sbagliato si sceglie
     solo fra i lati misurati davvero, e se non si puo' dire non si dice.
   · glLeva, glEmojiSogno: chi devi diventare. La frase e' LA leva di quel sogno, la cosa che
     da sola fa quasi tutto il risultato (il 20% che da' l'80%); l'emoji viene dal sogno, mai
     un astronauta messo li' per caso.

   Funzioni pure: niente DOM, niente localStorage. Si provano con node tools/test-lettura.js.
   =========================================================================================== */

/* ---------- C · la frase del profilo ---------- */
const GL_POSITIVI = { disc: 1, real: 1 };
function glProfiloId(p){ return typeof p === 'string' ? p : String((p && p.id) || ''); }
/** Vero se il profilo porta avanti: e' l'unico caso in cui si dice "stai diventando". */
function glProfiloPositivo(p){ return !!GL_POSITIVI[glProfiloId(p)]; }
/** L'inizio della frase, senza il nome: per l'etichetta sopra al profilo. `io` = in prima persona (il messaggio all'agente). */
function fraseProfiloKick(profilo, io){
  if (glProfiloPositivo(profilo)) return io ? 'Sto diventando' : 'Stai diventando';
  return io ? 'Se continuo così, rischio di diventare' : 'Se continui così, rischi di diventare';
}
/** Il nome del profilo dentro una frase: "il Sognatore", "l'Inconcludente". */
function glNomeInFrase(nome){
  return String(nome || '').replace(/^Il /, 'il ').replace(/^L['’]/, 'l\'').replace(/^La /, 'la ').replace(/^Lo /, 'lo ');
}
/** LA frase del profilo, ovunque compaia: fraseProfilo({ id: 'disc', name: 'Il Disciplinato in costruzione' }). */
function fraseProfilo(profilo, opz){
  opz = opz || {};
  const nome = (profilo && typeof profilo === 'object') ? profilo.name : (opz.nome || '');
  const k = fraseProfiloKick(profilo, !!opz.io);
  return nome ? k + ' ' + (opz.asterischi ? '*' + glNomeInFrase(nome) + '*' : glNomeInFrase(nome)) : k;
}

/* ---------- D · la probabilita' di realizzare il sogno ---------- */
/* Le fasce, dal profilo che arriva piu' spesso al traguardo a quello che ci arriva meno. Non si sovrappongono: un Disciplinato che
   risponde male resta sopra a un Sognatore che risponde benissimo, perche' il profilo e' gia' il riassunto di tutte le risposte. */
const GL_FASCE = {
  real: [80, 92], disc: [64, 80], equi: [50, 64], sogn: [40, 50],
  nott: [34, 40], inc: [28, 34], reat: [22, 28], proc: [15, 22]
};
const GL_ORDINE = ['real', 'disc', 'equi', 'sogn', 'nott', 'inc', 'reat', 'proc'];
function glCl(x, a, b){ return Math.max(a, Math.min(b, x)); }
/**
 * Quanto le risposte somigliano a quelle di chi realizza il sogno, da 0 a 1.
 * `risposte` = { q1: 0..1 }; `attese` = { q1: probabilita' che il Realizzatore dica si' } (o la lista OR_Q, con e.real).
 * La risposta da persona di successo e' il si' pieno se il Realizzatore tende al si', il no pieno se tende al no:
 * piu' la risposta si avvicina, piu' vale. "Non lo so" vale a meta'. Nessuna risposta: 0,5.
 */
function glQualita(risposte, attese){
  const A = {};
  if (Array.isArray(attese)) attese.forEach(function(q){ if (q && q.id && q.e && typeof q.e.real === 'number') A[q.id] = q.e.real; });
  else Object.keys(attese || {}).forEach(function(k){ if (typeof attese[k] === 'number') A[k] = attese[k]; });
  let s = 0, n = 0;
  Object.keys(risposte || {}).forEach(function(k){
    const a = +risposte[k];
    if (!(k in A) || !isFinite(a)) return;
    const meta = A[k] >= 0.5 ? 1 : 0;
    s += 1 - Math.abs(glCl(a, 0, 1) - meta); n++;
  });
  return n ? s / n : 0.5;
}
/**
 * LA probabilita', in un numero intero. `qualita` da 0 a 1 (glQualita); `comportamento` facoltativo, da 0 a 1 (i voti della partita, le
 * promesse tenute): quando c'e' pesa un quarto, e sposta il numero dentro alla fascia, mai fuori.
 */
function glProbabilita(profilo, qualita, comportamento){
  const f = GL_FASCE[glProfiloId(profilo)] || GL_FASCE.equi;
  let q = glCl(isFinite(+qualita) ? +qualita : 0.5, 0, 1);
  if (comportamento != null && isFinite(+comportamento)) q = 0.75 * q + 0.25 * glCl(+comportamento, 0, 1);
  return Math.round(f[0] + (f[1] - f[0]) * q);
}
/** Le righe della (i): da dove viene il numero, dette come le direbbe una persona. */
function glProbabilitaRighe(profilo, qualita, comportamento){
  const f = GL_FASCE[glProfiloId(profilo)] || GL_FASCE.equi;
  const nome = (profilo && profilo.name) ? glNomeInFrase(profilo.name) : 'il tuo profilo';
  /* 0.9.391, BUG-124: il profilo e' la traiettoria (chi stai diventando), non chi sei: come ti vedi e' l'immagine di se' (immagine-di-se.js) */
  const r = [['🧭', 'Chi stai diventando', 'Per ' + nome + ' la probabilità sta fra il ' + f[0] + '% e il ' + f[1] + '%.']];
  const q = Math.round(glCl(isFinite(+qualita) ? +qualita : 0.5, 0, 1) * 100);
  r.push(['💬', 'Le tue risposte', q >= 70 ? 'Assomigliano a quelle di chi ce la fa. Il numero sale verso l’alto della fascia.' : (q >= 40 ? 'Metà ti spingono avanti e metà ti frenano. Il numero sta a metà della fascia.' : 'Descrivono abitudini che ti frenano. Il numero resta in basso nella fascia.')]);
  if (comportamento != null && isFinite(+comportamento)) r.push(['⚽', 'Quello che fai', 'I voti della tua partita e le promesse tenute spostano il numero, sempre dentro alla fascia.']);
  r.push(['📈', 'Il numero si muove', 'Sale ogni giorno in cui fai le tappe e voti per il nuovo te.']);
  return r;
}

/* ---------- F · i tre lati della combinazione segreta ---------- */
/* L'identita': chi sei oggi rispetto a chi devi diventare. La fascia del profilo, e dentro la fascia le risposte; i voti della partita,
   quando ci sono, pesano un quinto. Un Disciplinato sta in alto: dargli il 30% era come dare 3 su 10 a chi ha studiato. */
const GL_FASCE_IO = {
  real: [84, 96], disc: [70, 86], equi: [54, 70], sogn: [42, 56],
  nott: [36, 50], inc: [32, 46], reat: [28, 42], proc: [20, 34]
};
function glIdentita(profilo, qualita, voti){
  const f = GL_FASCE_IO[glProfiloId(profilo)] || GL_FASCE_IO.equi;
  let v = f[0] + (f[1] - f[0]) * glCl(isFinite(+qualita) ? +qualita : 0.5, 0, 1);
  if (voti && (+voti.neo || 0) + (+voti.old || 0) > 0) v = 0.8 * v + 0.2 * (100 * (+voti.neo || 0) / ((+voti.neo || 0) + (+voti.old || 0)));
  return Math.round(glCl(v, 0, 100));
}
/* L'azione si misura con i giorni: prima dei primi tre non c'e' niente da misurare, e uno 0% detto il primo giorno e' falso. */
const GL_GIORNI_AZIONE = 3;
/** null = "la misuro nei prossimi giorni". giorni = da quanti giorni c'e' l'app; fatti = i giorni con una tappa negli ultimi 7. */
function glAzione(giorni, fatti, azioni){
  giorni = Math.max(0, Math.floor(+giorni || 0));
  if (giorni < GL_GIORNI_AZIONE) return null;
  const finestra = Math.min(7, giorni);
  return Math.round(glCl(Math.min(1, (+fatti || 0) / finestra) * 70 + Math.min(30, (+azioni || 0) * 10), 0, 100));
}
/** Il numero sbagliato della combinazione: il lato piu' basso fra quelli MISURATI (un numero, non null). Servono almeno due lati misurati,
    e il piu' basso deve essere davvero basso (sotto il 70%): altrimenti '' e non si dice niente. */
function glTreScegli(v){
  const k = ['io', 'azione', 'ambiente'].filter(function(x){ return v && typeof v[x] === 'number' && isFinite(v[x]); });
  if (k.length < 2) return '';
  k.sort(function(a, b){ return v[a] - v[b]; });
  return v[k[0]] < 70 ? k[0] : '';
}
/* 0.9.402 BUG-227, Andrea: "l'Azione mostra subito una panoramica delle abitudini che l'app gia' rileva, con un asterisco: la misura vera
   dipendera' dalle tappe dei prossimi giorni". Finche' glAzione e' null il triangolo (pscTreHtml) mostra le abitudini della scheda Azione
   (pscAbVoci). Qui la scelta: solo quelle con un dato, al massimo `max`, ognuna con la parola del suo stato (mai il punteggio). */
const GL_AB_STATO = { tieni: 'Va bene', cambia: 'Da cambiare', neutro: 'Così così' };
function glAbitudiniViste(voci, max){
  return (voci || []).filter(function(r){ return r && r.t && r.stato && r.stato !== 'manca' && r.stato !== 'attesa' && (r.val || r.sub); })
    .slice(0, max || 4)
    .map(function(r){ return { k: r.k, em: r.em || '📏', t: r.t, stato: GL_AB_STATO[r.stato] ? r.stato : 'neutro', parola: GL_AB_STATO[r.stato] || GL_AB_STATO.neutro }; });
}

/* ---------- H · chi devi diventare: la leva del sogno ---------- */
/* LA LEVA. Per ogni tipo di sogno, l'abitudine che da sola muove l'ago: quella che rende quasi tutto il resto meno necessario.
   "Lavora un'ora al progetto prima dei messaggi" va bene per qualunque cosa, e quindi per nessuna. Si legge dalle parole del sogno;
   l'ordine conta (prima i sogni piu' precisi). `ico` e' l'emoji del sogno, quando il sogno non ne ha una sua. */
const GL_LEVE = [
  { k: 'ecommerce', re: /negozio online|e-?commerce|shop online|dropshipping|shopify|amazon|etsy|vendere (prodotti )?(on ?line|su internet)/, ico: '🛒',
    t: 'una persona che ogni giorno trova e prova un prodotto o un’offerta nuova, e guarda i numeri delle vendite' },
  { k: 'vendite', re: /vendite del mio prodotto|lanciare il mio prodotto|prodotto nuovo|invenzione/, ico: '🧪',
    t: 'una persona che ogni settimana fa provare il prodotto a persone vere e lo cambia con quello che dicono' },
  { k: 'associazione', re: /associazione|beneficenza|volontariato|una causa|onlus/, ico: '🤝',
    t: 'una persona che ogni settimana porta una persona nuova dentro alla sua causa' },
  { k: 'contenuti', re: /contenuti|creator|influencer|youtube|youtuber|tiktok|instagram|podcast|canale|social|brand personale|far sentire la mia voce/, ico: '🎙️',
    t: 'una persona che pubblica un contenuto ogni giorno e guarda quale funziona, per rifarlo meglio' },
  { k: 'libro', re: /libro|romanzo|scrivere|scrittor|racconti/, ico: '📖',
    t: 'una persona che scrive una pagina ogni giorno, anche brutta, senza tornare indietro a correggerla' },
  { k: 'spettacolo', re: /spettacolo|attore|attrice|cantante|musicista|album|canzon|musica|band|recitare/, ico: '🎭',
    t: 'una persona che ogni giorno prova il pezzo più difficile e ogni settimana si fa sentire da qualcuno' },
  { k: 'arte', re: /capolavoro|arte|disegn|dipin|illustra|fotograf|film/, ico: '🎨',
    t: 'una persona che ogni giorno finisce un pezzo, anche piccolo, e ogni settimana lo fa vedere a qualcuno' },
  { k: 'insegnare', re: /insegnare|insegnante|lezioni|corso|formazione/, ico: '📚',
    t: 'una persona che ogni settimana spiega qualcosa a persone vere e chiede cosa non hanno capito' },
  { k: 'studio', re: /esam|laure|concors|universit|scuola|certificaz|maturit|professionista|medico|avvocato|architetto|ingegner/, ico: '🎓',
    t: 'una persona che ogni giorno si mette alla prova con esercizi ed esami veri, invece di rileggere' },
  { k: 'sport', re: /il mio sport|atleta|allenatore|istruttore|gare|campionat|agonist/, ico: '🏅',
    t: 'una persona che ogni giorno allena il suo punto debole, con qualcuno che la corregge' },
  { k: 'corpo', re: /corpo|forma|fisic|palestr|peso|dimagr|chil|muscol|maratona|correre|salute|vitalit/, ico: '👟',
    t: 'una persona che non salta mai due allenamenti di fila e si prepara da sola quello che mangia' },
  { k: 'attivita', re: /attivit|business|aziend|impres|startup|studio mio|locale|clienti|servizio/, ico: '🏪',
    t: 'una persona che ogni giorno parla con un cliente nuovo e gli propone quello che vende' },
  { k: 'liberta', re: /viaggiar|libert|lavorare da dove|nomade|il mondo/, ico: '🌍',
    t: 'una persona che ogni giorno lavora prima di tutto alla fonte di guadagno che si può portare ovunque' },
  { k: 'carriera', re: /carriera|promozion|lavoro dei sogni|manager|stipendio|colloquio|assunt/, ico: '💼',
    t: 'una persona che ogni settimana porta un risultato che si può misurare e lo fa sapere a chi decide' },
  { k: 'soldi', re: /soldi|guadagn|indipendenza economica|entrate|reddito/, ico: '💰',
    t: 'una persona che ogni giorno lavora per prima cosa a quello che le porta soldi' },
  { k: 'fede', re: /fede|preg|parola|dio|anima|chiesa/, ico: '🙏',
    t: 'una persona che ogni mattina prega prima di prendere in mano il telefono' },
  { k: 'coscienza', re: /coscienza|medita|universo|spiritual|consapevol/, ico: '✨',
    t: 'una persona che medita ogni mattina, prima di tutto il resto' },
  { k: 'famiglia', re: /famiglia|figli|persona giusta|relazion|amici|partner|amore|coppia/, ico: '❤️',
    t: 'una persona che ogni giorno dà un’ora piena, senza telefono, alle persone che ama' }
];
/* Quando le parole del sogno non bastano: la leva del campo (le sei carte "chi vuoi diventare" del Genio) */
const GL_LEVE_CAMPO = {
  studio:   { ico: '🎓', t: 'una persona che ogni giorno si mette alla prova con esercizi ed esami veri, invece di rileggere' },
  corpo:    { ico: '👟', t: 'una persona che non salta mai due allenamenti di fila e si prepara da sola quello che mangia' },
  lavoro:   { ico: '🏪', t: 'una persona che ogni giorno lavora per prima cosa a quello che porta clienti e soldi' },
  arte:     { ico: '🎨', t: 'una persona che ogni giorno finisce un pezzo, anche piccolo, e ogni settimana lo fa vedere a qualcuno' },
  carriera: { ico: '💼', t: 'una persona che ogni settimana porta un risultato che si può misurare e lo fa sapere a chi decide' },
  presenza: { ico: '❤️', t: 'una persona che ogni giorno dà un’ora piena, senza telefono, alle persone che ama' },
  altro:    { ico: '🎯', t: 'una persona che ogni giorno fa per prima la cosa che avvicina di più il sogno' }
};
function glNorm(s){ return String(s || '').toLowerCase().replace(/[’']/g, ' ').replace(/\s+/g, ' '); }
/** La leva del sogno: { t, ico, k, specifica }. specifica = trovata dalle parole del sogno (non solo dal campo). */
function glLeva(sogno, campo){
  const s = glNorm(sogno);
  if (s){ for (let i = 0; i < GL_LEVE.length; i++){ if (GL_LEVE[i].re.test(s)) return { t: GL_LEVE[i].t, ico: GL_LEVE[i].ico, k: GL_LEVE[i].k, specifica: true }; } }
  const c = GL_LEVE_CAMPO[campo] || GL_LEVE_CAMPO.altro;
  return { t: c.t, ico: c.ico, k: campo && GL_LEVE_CAMPO[campo] ? campo : 'altro', specifica: false };
}
/** L'emoji del sogno: quella che il sogno ha gia' davanti, altrimenti quella della sua leva. Mai l'astronauta. */
function glEmojiSogno(sogno, campo){
  try{ const m = String(sogno || '').trim().match(/^(\p{Extended_Pictographic}️?(?:‍\p{Extended_Pictographic}️?)*)/u); if (m && m[1] !== '🧑‍🚀') return m[1]; }catch(_){ }
  return glLeva(sogno, campo).ico;
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { GL_FASCE, GL_FASCE_IO, GL_ORDINE, GL_GIORNI_AZIONE, GL_LEVE, GL_LEVE_CAMPO,
    glProfiloPositivo, fraseProfiloKick, fraseProfilo, glNomeInFrase, glQualita, glProbabilita, glProbabilitaRighe,
    glIdentita, glAzione, glTreScegli, glAbitudiniViste, glLeva, glEmojiSogno };
}
