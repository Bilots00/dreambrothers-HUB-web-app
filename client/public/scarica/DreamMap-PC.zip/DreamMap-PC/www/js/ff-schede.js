/* LE SCHEDE APERTE DURANTE IL FULL FOCUS (0.9.298).
   Andrea: "nelle impostazioni del Full Focus voglio dare accesso solo a certe parti dell'app: poter tornare
   indietro dalla pagina del Full Focus alla scheda START e alla Mappa, per proseguire la roadmap, e bloccare
   schede come Dream e Profilo una volta avviata la sessione".
   Ogni scheda della barra in basso ha il suo interruttore (ffPref().schede). Mentre la sessione corre
   (FF.run), una scheda chiusa non si apre: la barra la mostra con il lucchetto e un tocco dice quando si
   riapre. Sopra le schede aperte c'e' una pillola con il tempo che resta, per tornare al timer. */
const FFS_SCHEDE = [
  { k: 'rotta', n: 'Sogno', ico: '🧭', sub: 'Il sogno, l’arrivo e le sfide.' },
  { k: 'mappa', n: 'Mappa', ico: '🗺️', sub: 'Il percorso, per fare la prossima tappa.' },
  { k: 'sveglia', n: 'START', ico: '🚀', sub: 'Il foglio di oggi e la partita.' },
  { k: 'profilo', n: 'Profilo', ico: '👤', sub: 'Account, impostazioni e report.' }
];
const FFS_DEF = { rotta: false, mappa: true, sveglia: true, profilo: false };

function ffsSchede(){
  const p = ffPref();
  if (!p.schede || typeof p.schede !== 'object') p.schede = Object.assign({}, FFS_DEF);
  return p.schede;
}
function ffsInCorso(){ return !!(typeof FF !== 'undefined' && FF.run && FF.run.endAt > Date.now()); }
function ffsAperta(k){ const s = ffsSchede(); return s[k] == null ? !!FFS_DEF[k] : !!s[k]; }
function ffsNome(k){ const x = FFS_SCHEDE.filter(function(s){ return s.k === k; })[0]; return x ? x.n : k; }
/** La prima scheda aperta: e' dove si atterra uscendo dal timer. null se sono tutte chiuse. */
function ffsPrimaAperta(){ const x = ['sveglia', 'mappa', 'rotta', 'profilo'].filter(ffsAperta)[0]; return x || null; }

function ffsToggle(k){
  const s = ffsSchede(); s[k] = !ffsAperta(k);
  ffSavePref(); ffsBarra();
  if (typeof ffImpostazioniApri === 'function') ffImpostazioniApri();
}
/** La sezione delle impostazioni del Full Focus (ff-cicli.js la mette in fondo). */
function ffsImpostazioniHtml(){
  return '<div class="ffi-sez">🔓 Le schede aperte</div>'
    + '<div class="ffi-card">'
    + '<p class="ffs-nota">Le schede accese restano aperte mentre il timer corre. Quelle spente si riaprono a fine sessione.</p>'
    + FFS_SCHEDE.map(function(x){ return ffcRigaSw(x.ico + ' ' + x.n, x.sub, ffsAperta(x.k), 'ffsToggle(\'' + x.k + '\')'); }).join('')
    + '</div>';
}

/* La barra in basso: le schede chiuse con il lucchetto, mentre la sessione corre */
function ffsBarra(){
  const on = ffsInCorso();
  FFS_SCHEDE.forEach(function(x){
    const b = document.getElementById('nav-' + x.k); if (!b) return;
    b.classList.toggle('ffs-chiusa', on && !ffsAperta(x.k));
  });
  ffsPillola();
}
/* La pillola per tornare al timer, sopra le schede aperte.
   0.9.394, Andrea: "il testo va a capo su due righe e Full Focus non e' allineato a Torna; il blu scuro su sfondo scuro non si
   legge, si mimetizza. Metti tutto su una riga, mettila in alto e rendila piu' visibile, con un altro colore, con abbastanza
   contrasto". Adesso sta in alto, nell'intestazione, come seconda riga sotto ai suoi pulsanti (non li copre, e l'intestazione
   cresce: le schede scendono, niente le passa sopra). E' oro, il colore delle stelle del Full Focus, col testo blu notte (contrasto
   oltre 9:1, si vede sul cielo scuro come sulle pagine chiare). Una riga sola: niente a capo, e sui telefoni stretti la frase
   corta "Torna al focus". L'icona e' disegnata (una stella), non un'emoji. */
const FFS_STELLA = '<svg class="ffs-ico" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M12 2.5c.6 4.900 2.600 6.900 7.500 7.500-4.900.6-6.900 2.600-7.500 7.500-.6-4.900-2.600-6.900-7.500-7.500 4.900-.6 6.900-2.600 7.500-7.500z" fill="currentColor"/></svg>';
function ffsPillola(){
  let p = document.getElementById('ffsPill');
  const home = typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] === 's-home';
  const head = document.querySelector('#s-home .home-head');
  const mostra = ffsInCorso() && home && !!head;
  if (!mostra){
    if (p && !p.hidden){ p.hidden = true; ffsTestaAggiorna(head, false); }
    return;
  }
  if (!p){
    /* la riga (ffsPill) occupa tutta la larghezza e va a capo sotto ai pulsanti; dentro, centrata, la pillola che si tocca */
    p = document.createElement('div'); p.id = 'ffsPill'; p.className = 'ffs-riga';
    p.innerHTML = '<button type="button" class="ffs-pill" aria-label="Torna al Full Focus"></button>';
    p.firstChild.onclick = function(){ if (typeof ffOpen === 'function') ffOpen(); };
  }
  if (p.parentNode !== head) head.appendChild(p);
  const resto = Math.max(0, FF.run.endAt - Date.now());
  const tempo = typeof ffFmt === 'function' ? ffFmt(resto) : '';
  if (!p.querySelector('.ffs-tempo')){
    p.firstChild.innerHTML = FFS_STELLA + '<span class="ffs-tempo"></span><span class="ffs-frase"><span class="ffs-lunga">Torna al Full Focus</span><span class="ffs-corta">Torna al focus</span></span>';
  }
  const t = p.querySelector('.ffs-tempo'); if (t.textContent !== tempo) t.textContent = tempo;
  if (p.hidden){ p.hidden = false; ffsTestaAggiorna(head, true); }
  else if (!head.classList.contains('ffs-con-pill')) ffsTestaAggiorna(head, true);
}
/* l'intestazione con la pillola e' piu' alta: le schede col cielo sotto all'intestazione (blkhero.js, --hdr-h) devono saperlo */
function ffsTestaAggiorna(head, on){
  if (head) head.classList.toggle('ffs-con-pill', !!on);
  try{ if (typeof flHeaderSync === 'function') requestAnimationFrame(flHeaderSync); }catch(_){ }
}

/* switchTab passa di qui: una scheda chiusa durante la sessione non si apre. Si aggancia quando tutti gli script sono
   caricati: nav.js (dove nasce switchTab) arriva dopo questo file. */
function ffsAggancia(){
  if (window.__ffsAgganciato) return; window.__ffsAgganciato = true;
(function(){
  const orig = window.switchTab;
  if (typeof orig !== 'function') return;
  window.switchTab = switchTab = function(name){
    if (ffsInCorso() && FFS_DEF.hasOwnProperty(name) && !ffsAperta(name)){
      const resto = Math.max(1, Math.ceil((FF.run.endAt - Date.now()) / 60000));
      if (typeof toast === 'function') toast(ffsNome(name) + ' si riapre a fine sessione, fra ' + resto + ' min');
      try{ if (typeof flVibra === 'function') flVibra([20]); }catch(_){ }
      return;
    }
    return orig.apply(this, arguments);
  };
})();

/* Uscendo dal timer mentre corre si atterra su una scheda aperta, non su quella di prima */
(function(){
  const orig = window.ffClose;
  if (typeof orig !== 'function') return;
  window.ffClose = ffClose = function(){
    if (ffsInCorso()){
      const k = ffsPrimaAperta();
      if (!k){ if (typeof toast === 'function') toast('Durante la sessione le schede sono chiuse: si riaprono alla fine'); return; }
      orig.apply(this, arguments);
      try{ window.switchTab(k); }catch(_){ }
      ffsBarra();
      return;
    }
    return orig.apply(this, arguments);
  };
})();

}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ffsAggancia); else ffsAggancia();

document.addEventListener('fl:screen', ffsBarra);
setInterval(function(){ if (ffsInCorso() || document.querySelector('.ffs-chiusa') || (document.getElementById('ffsPill') && !document.getElementById('ffsPill').hidden)) ffsBarra(); }, 1000);

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.ffs-nota{margin:12px 0 6px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.ffs-chiusa{opacity:.38;position:relative}',
    '.ffs-chiusa::after{content:"🔒";position:absolute;top:2px;right:calc(50% - 22px);font-size:11px}',
    /* 0.9.394: la pillola e' la seconda riga dell'intestazione: l'intestazione va a capo solo quando c'e' la pillola, e il titolo al
       centro resta centrato sulla prima riga (i pulsanti) */
    '#s-home .home-head.ffs-con-pill{flex-wrap:wrap;row-gap:8px;padding-bottom:12px}',
    '#s-home .home-head.ffs-con-pill .hdr-center{bottom:auto;height:64px}',
    /* la prima riga resta alta 44 come quando l'intestazione e' da sola: pulsanti e titolo non si spostano di un pixel */
    '#s-home .home-head.ffs-con-pill::before{content:"";order:-1;flex:none;width:0;height:44px;margin-right:-10px}',
    '.ffs-riga{order:9;flex:0 0 100%;display:flex;justify-content:center;min-width:0;pointer-events:none;position:relative;z-index:1}',
    '.ffs-riga[hidden]{display:none}',
    '.ffs-pill{flex:0 1 auto;display:inline-flex;align-items:center;justify-content:center;gap:8px;max-width:100%;box-sizing:border-box;padding:9px 18px 9px 14px;border:0;border-radius:99px;background:linear-gradient(135deg,#FFD978,#FFC94D 55%,#FFB82E);color:#001E44;white-space:nowrap;line-height:1;box-shadow:0 6px 18px rgba(0,30,68,.28),inset 0 0 0 1px rgba(255,255,255,.55);cursor:pointer;pointer-events:auto}',
    '.ffs-pill:active{transform:scale(.97)}',
    '.ffs-pill .ffs-ico{flex:none;display:block;color:#001E44}',
    '.ffs-pill .ffs-tempo{font:900 15px/1 var(--font-body);font-variant-numeric:tabular-nums;color:#001E44}',
    '.ffs-pill .ffs-frase{font:700 14px/1 var(--font-body);color:#001E44;white-space:nowrap}',
    '.ffs-pill .ffs-corta{display:none}',
    '@media (max-width:340px){.ffs-pill .ffs-lunga{display:none}.ffs-pill .ffs-corta{display:inline}}',
    /* nell'intestazione di vetro i figli prendono i tocchi: la riga no (sotto c'e' il cielo della scheda), solo la pillola */
    '#s-home .home-head .ffs-riga{pointer-events:none}'
  ].join('');
  document.head.appendChild(st);
})();
