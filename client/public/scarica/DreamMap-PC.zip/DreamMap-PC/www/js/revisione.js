/* ===========================================================================================
   LA REVISIONE DELLA SERA (0.9.225)

   Dal sistema di Davy Fogarty (fondatore di The Oodie, video «The Last 10% Is Why You're Still
   Average»): il segreto non e' la pianificazione, e' la revisione. Ogni sera tre domande sul
   giorno appena finito, e per quello che ti ha interrotto non «domani mi impegno di piu'»: si
   cambia il sistema (si blocca, si spegne, si delega, si elimina).

   Sulla scena del Genio, una domanda alla volta, con i dati veri di oggi accanto alla domanda:
     1. Durante i blocchi di lavoro profondo eri davvero concentrato? (le sessioni di Full Focus
        di oggi, quante finite e quante interrotte, e il tempo sulle app che distraggono)
     2. Hai lavorato su cose ad alta leva o solo su quelle facili? (la priorita' di oggi: fatta
        o no, e le cose chiuse)
     3. Cosa, di preciso, ti ha interrotto?
     4. Cosa cambi nel sistema, da domani? (dipende dalla risposta 3)
   Si salva in fl_revisioni ([{ giorno, focus, leva, interruzione, contromisura, testo }]) e la
   legge anche il tuo agente personale. Si apre dalla vista Roadmap della Mappa (la card della sera).
   =========================================================================================== */
const RV_KEY = 'fl_revisioni';
const RV = { passo: '', storia: [], r: {}, dati: null, opz: [] };
/* 0.9.363 (lavoro 18): la revisione segue la giornata della persona (flGiornoKey, start.js), non il calendario */
function rvOggi(){ try{ return (typeof flGiornoKey === 'function') ? flGiornoKey() : ((typeof mtKey === 'function') ? mtKey(Date.now()) : new Date().toISOString().slice(0, 10)); }catch(_){ return new Date().toISOString().slice(0, 10); } }
/* 0.9.372, Andrea: "se faccio la revisione della sera a mezzanotte e 52, prima di dormire, l'app conta il telefono da mezzanotte a
   mezzanotte e 52: la revisione della sera e' della giornata appena passata". Dopo mezzanotte e prima di dormire (flDopoMezzanotte, start.js)
   la giornata della revisione e' ieri: i dati, il punteggio e l'umore partono da ieri a mezzanotte */
function rvUmOff(){ try{ return (typeof flDopoMezzanotte === 'function' && flDopoMezzanotte()) ? 1 : 0; }catch(_){ return 0; } }
function rvInizio(){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - rvUmOff()); return d; }
function rvSera(){ try{ return new Date().getHours() >= 17 || (typeof flDopoMezzanotte === 'function' && flDopoMezzanotte()); }catch(_){ return new Date().getHours() >= 17; } }
function rvLista(){ try{ return JSON.parse(localStorage.getItem(RV_KEY) || '[]') || []; }catch(_){ return []; } }
/* 0.9.381: con il permesso di rifarla (fl_rv_rifai, solo per oggi) la revisione di oggi conta come da fare, senza cancellare quella gia'
   fatta: rifacendola, quella nuova prende il suo posto (rvSalvaEsito) */
function rvFattaOggi(){ if (rvRifai()) return false; const g = rvOggi(); return rvLista().some(function(x){ return x.giorno === g; }); }
/** I giorni di fila con la revisione fatta, fino a oggi o a ieri. */
function rvSerie(){
  const l = rvLista(); const fatti = {}; l.forEach(function(x){ fatti[x.giorno] = 1; });
  let n = 0, d = new Date(); if (!fatti[rvOggi()]) d.setDate(d.getDate() - 1);
  while (true){ const k = (typeof mtKey === 'function') ? mtKey(d.getTime()) : d.toISOString().slice(0, 10); if (!fatti[k]) break; n++; d.setDate(d.getDate() - 1); }
  return n;
}
function rvOre(min){ min = Math.round(min || 0); if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti'; const h = Math.floor(min / 60), m = min % 60; return (h === 1 ? '1 ora' : h + ' ore') + (m ? ' e ' + m + (m === 1 ? ' minuto' : ' minuti') : ''); }

/* ---------- i dati veri di oggi ---------- */
async function rvRaccogli(){
  const d0 = rvInizio();
  const out = { ff: { n: 0, finite: 0, mollate: 0, min: 0 }, prio: '', prioFatta: false, chiuse: [], app: [] };
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (!x || x.meditazione || x.at < d0.getTime()) return;
      out.ff.n++; if (x.ok) out.ff.finite++; else out.ff.mollate++;
      out.ff.min += (x.spentMs || 0) / 60000;
    });
  }catch(_){ }
  try{
    const g = rvOggi();
    const righe = (typeof stRigheDi === 'function') ? stRigheDi(g) : [];
    out.prio = (typeof stPriorita === 'function') ? String(stPriorita(g, righe) || '').replace(/^[☐☑•\-]\s*/, '') : '';
    const fatte = (typeof stDone === 'function') ? stDone().filter(function(x){ return x.day === g; }) : [];
    out.chiuse = fatte.map(function(x){ return x.text; });
    const n = function(t){ return String(t || '').trim().toLowerCase(); };
    out.prioFatta = !!out.prio && out.chiuse.some(function(t){ return n(t) === n(out.prio); });
  }catch(_){ }
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps){
      const r = await NATIVE.getTopApps({ from: d0.getTime(), to: Date.now(), limit: 40, icons: 0 });
      out.app = rvSoloDistr((r && r.apps) || []).filter(function(x){ return x.min >= 5; }).slice(0, 2);
    }
  }catch(_){ }
  return out;
}

/** Le app che distraggono di una lista di getTopApps, come { pkg, nome, min }, dalla piu' usata. Una funzione sola: la usano i dati di
    oggi (rvRaccogli) e i sette giorni del caso "ci e' ricascato" (ricCerca, ricascato.js, 0.9.390). */
function rvSoloDistr(apps){
  let cats = {}; try{ cats = (typeof insCats === 'function') ? insCats(null) : {}; }catch(_){ }
  const noti = (typeof PRC_DISTR !== 'undefined') ? PRC_DISTR : [];
  return (apps || []).filter(function(x){ return x && (cats[x.packageName] === 'distr' || (!cats[x.packageName] && noti.indexOf(x.packageName) >= 0)); })
    .map(function(x){ return { pkg: x.packageName, nome: x.label || x.appName || x.packageName, min: Math.round((x.ms || 0) / 60000) }; })
    .sort(function(a, b){ return b.min - a.min; });
}

/* ---------- la scena ---------- */
async function rvApri(){
  try{ RV_DA.tab = localStorage.getItem('fl_tab') === 'insights' ? 'insights' : ''; }catch(_){ RV_DA.tab = ''; }
  if (typeof GN === 'undefined' || typeof gnVai !== 'function'){ toast('Il Genio non è pronto, riprova'); return; }
  RV.pMax = 0; RV.r = {}; RV.storia = []; RV.visti = {}; RV.bozze = {}; RV.cvRegistrata = false; RV.partitaVista = false; RV.colloVisto = false; RV.tagliaVisto = false; RV.imprRisp = null; RV.imprGiro = 0;
  RV.dati = await rvRaccogli();
  /* 0.9.390, Andrea (BUG-123): "se un'app ha preso tante ore per 2 giorni di fila, o piu' volte nella stessa settimana, e aveva gia' provato a
     bloccarla, il Genio non deve riproporre la stessa risposta scriptata". Il caso si cerca adesso (ricascato.js), mentre si risponde alle
     prime domande; quando si arriva alla domanda su cosa cambiare, al suo posto compare il cartellone (rvVai, passo 'ricascato') */
  RV.ric = null; RV.ricVisto = false;
  try{ if (typeof ricCerca === 'function') ricCerca(rvInizio(), rvOggi()).then(function(c){ RV.ric = c || null; }, function(){ }); }catch(_){ }
  RV.corta = false;
  RV.passo = rvPrimoPasso();
  /* 0.9.322: "Riprendi da dove avevi lasciato" (dream-storia.js): le risposte tornano al loro posto */
  const rip = RV_RIPRESA; RV_RIPRESA = null;
  if (rip){
    RV.r = rip.r || {}; RV.storia = rip.storia || []; RV.visti = rip.visti || {}; RV.bozze = rip.bozze || {}; RV.scrivoPer = rip.scrivoPer || '';
    RV.passo = /^cv(Cosa|Scrivo|Scopri)$/.test(rip.passo) ? 'cvRivela' : rip.passo;
  }
  RV.colloVisto = !!(RV.r && RV.r.colloVisto);
  /* 0.9.393: anche la revisione corta (gia' fatto il punto oggi) comincia dall'imprevisto: il collo viene prima */
  if (!rip && RV.passo === 'imprevisto' && rvColloPrima('imprevisto')) RV.passo = 'collo';
  GN.on = true; GN.modo = 'rv'; GN.audio = true; GN.storia = [];
  RV.giorno = rvOggi(); RV.apertaAt = Date.now();
  goId('s-genio');
  rvBarra();
  GN.step = ''; gnVai('rv');
}
/* 0.9.322, Andrea: "se esco a meta' non deve ricominciare da capo: puo' scegliere se riprendere, come su Netflix". Ogni passo
   della sera si segna qui, per quel giorno. La revisione finita cancella il segno. */
const RV_RIP_K = 'fl_rv_ripresa';
let RV_RIPRESA = null;
function rvRipSalva(){
  try{
    if (!RV.passo || RV.passo === 'fine' || !RV.storia.length) return;
    localStorage.setItem(RV_RIP_K, JSON.stringify({ g: rvOggi(), at: Date.now(), passo: RV.passo, storia: RV.storia, r: RV.r, visti: RV.visti, bozze: RV.bozze, scrivoPer: RV.scrivoPer || '' }));
  }catch(_){ }
}
function rvRipLeggi(){
  try{
    const o = JSON.parse(localStorage.getItem(RV_RIP_K) || 'null'); if (!o) return null;
    if (o.g !== rvOggi() || rvFattaOggi()){ localStorage.removeItem(RV_RIP_K); return null; }
    return o;
  }catch(_){ return null; }
}
function rvRipVia(){ try{ localStorage.removeItem(RV_RIP_K); }catch(_){ } }
/* 0.9.280, Andrea: "la revisione comincia sempre dal controllo dell'umore, con le stesse faccine della
   scorciatoia; poi, se vuole, un pensiero sulla giornata. Se le ha gia' fatte tutte e due, si saltano. E
   l'ultima domanda e' sugli imprevisti, da mandare al Genio perche' ricalcoli la roadmap". */
function rvUmoreOggi(){ try{ return (typeof umLeggi === 'function' && typeof umGiorno === 'function') ? (umLeggi(umGiorno(rvUmOff())) || {}) : {}; }catch(_){ return {}; } }
/* 0.9.335, Andrea: "la revisione della sera piu' breve se ho appena fatto il Rientra in rotta o ho gia' chiesto il controllo
   della rotta": le domande sulla giornata le ho gia' fatte li'. Restano l'umore, l'imprevisto e la prima cosa di domani. */
function rvGiaFattoOggi(){
  const d0 = rvInizio();
  try{ if (typeof rnLista === 'function' && rnLista().some(function(x){ return x && x.at >= d0.getTime(); })) return true; }catch(_){ }
  try{ if (localStorage.getItem('fl_ctl_giorno') === new Date().toDateString()) return true; }catch(_){ }
  return false;
}
function rvPartitaDopo(da){
  if (da === 'partita'){ const sv = (typeof vtSerie === 'function') ? vtSerie() : {}; if (sv.tipo && sv.n >= 2) return 'partitaSerie'; }
  const d0 = rvInizio();
  if (typeof vtPuntiHtml === 'function' && vtPuntiHtml(d0.getTime(), Date.now(), true)) return 'partitaPunti';
  return rvPartitaFine();
}
function rvPartitaFine(){ RV.partitaVista = true; return rvPrimoPasso(); }
/* 0.9.402 BUG-259, Andrea: "La partita di oggi 2-2, Pareggio non torna con il campionato. Prima il punteggio di oggi, con Pareggio di
   oggi, poi il campionato, cioe' il totale che si vede nella scheda START, con chi e' avanti" (lezione 359: un numero parziale sta accanto
   al totale, mai un pareggio che sembra contraddire il punteggio vero). Oggi: i punti segnati da mezzanotte (vtSomma, vittorie.js).
   Il campionato: lo stesso numero del tabellone di START, letto con la stessa funzione (mtState, start.js). */
function rvCampionato(){
  let stag = 'campionato'; try{ stag = (typeof mgCfg === 'function' && mgCfg().season) || 'campionato'; }catch(_){ }
  /* chi gioca "ogni giorno" ha un totale che riparte a mezzanotte: e' gia' la partita di oggi, non c'e' un secondo numero */
  if (stag === 'giorno') return null;
  let s = null; try{ s = (typeof mtState === 'function') ? mtState() : null; }catch(_){ }
  if (!s) return null;
  const neo = +s.neo || 0, old = +s.old || 0, d = Math.abs(neo - old);
  const dove = stag === 'tempo' ? 'Nella partita a tempo' : 'Nel campionato', pt = d === 1 ? '1 punto' : d + ' punti';   /* il numero e l'unita' mai separati a capo */
  return { nome: stag === 'tempo' ? 'La partita a tempo' : 'Il campionato', neo: neo, old: old,
    linea: neo > old ? dove + ' sei avanti tu, di ' + pt + '.' : (old > neo ? dove + ' è avanti il vecchio te, di ' + pt + '.' : dove + ' siete pari.') };
}
function rvPartitaHtml(da, a){
  let p = { old: 0, neo: 0 }; try{ if (typeof vtSomma === 'function') p = vtSomma(da, a); }catch(_){ }
  const esito = p.neo > p.old ? 'Oggi stai vincendo tu' : (p.old > p.neo ? 'Oggi è avanti il vecchio te' : (p.neo ? 'Pareggio di oggi' : 'La partita di oggi non è ancora cominciata'));
  const sq = function(k, nome, n, su){ return '<div class="vt-sq ' + k + (su ? ' su' : '') + '"><small>' + nome + '</small><b>' + n + '</b></div>'; };
  let h = '<div class="vt scuro rv-par"><p class="vt-kick">La partita di oggi</p>'
    + '<div class="vt-tab">' + sq('old', 'Vecchio te', p.old, p.old > p.neo) + '<span class="vt-vs">:</span>' + sq('neo', 'Nuovo te', p.neo, p.neo > p.old) + '</div>'
    + '<p class="vt-esito">' + esito + '</p>';
  const c = rvCampionato();
  if (c){
    h += '<div class="rv-camp"><p class="rv-camp-k">' + c.nome + '</p>'
      + '<div class="rv-camp-tab"><span class="old"><small>Vecchio te</small><b>' + c.old + '</b></span><i aria-hidden="true">:</i>'
      + '<span class="neo"><small>Nuovo te</small><b>' + c.neo + '</b></span></div>'
      + '<p class="rv-camp-l">' + c.linea + '</p></div>';
  }
  return h + '</div>';
}
function rvPrimoPasso(){
  /* 0.9.369, Andrea: "prima chiedigli come sta; poi il punteggio. Se ha avuto una giornata di merda, non infierire: chiedigli se vuole
     saperlo". L'umore viene prima di tutto; il punteggio subito dopo, a passi (rvPartitaPasso) */
  const u = rvUmoreOggi();
  if (typeof umScrivi === 'function' && !u.sodd) return 'umore';
  const pp = rvPartitaPasso(u.sodd); if (pp) return pp;
  if (rvGiaFattoOggi()){ RV.corta = true; return 'imprevisto'; }
  /* 0.9.301: dopo l'umore la rivelazione di dove e' andato il tempo (conversa.js), con Premium prima una domanda di
     consapevolezza e dopo la chat con il tuo agente personale; senza, il Genio a opzioni riparte dal pensiero o dal focus */
  if (typeof cvInizio === 'function') return cvInizio('rv');
  if (typeof umScrivi === 'function' && !String(u.nota || '').trim()) return 'pensiero';
  return 'focus';
}
function rvPartitaC(){ try{ const d0 = rvInizio(); return typeof vtC === 'function' && vtC(d0.getTime(), Date.now()); }catch(_){ return false; } }
function rvMorbido(){ try{ return localStorage.getItem('fl_tono') === 'morbido'; }catch(_){ return false; } }
/** il primo passo della partita: con una giornata storta (o il tono morbido) prima si chiede se vuole saperlo */
function rvPartitaPasso(sodd){
  if (RV.partitaVista || !rvPartitaC()) return '';
  return ((+sodd || 3) <= 2 || rvMorbido()) ? 'partitaChiedi' : 'partita';
}
function rvUmore(n){
  try{ umScrivi(umGiorno(rvUmOff()), { sodd: n }); gnAu.scelta(n - 1); flVibra(14); }catch(_){ }
  /* 0.9.400 (BUG-181), Andrea: "quando l'utente dice di non stare bene, l'agente chiede perche' (cosa e' successo), come il controllo
     dell'umore, e se c'e' ansia propone il respiro". Con una giornata storta, prima del resto: cosa e' successo, e la risposta del Genio */
  if (n <= 2 && !RV.r.umoreCosa){ RV.r.umVoto = n; rvVai('umoreCosa'); return; }
  rvDopoUmore(n);
}
function rvDopoUmore(n){
  { const pp = rvPartitaPasso(n); if (pp){ rvVai(pp); return; } }
  if (rvGiaFattoOggi()){ RV.corta = true; rvVai('imprevisto'); return; }
  if (typeof cvInizio === 'function'){ rvVai(cvInizio('rv')); return; }
  rvVai(String(rvUmoreOggi().nota || '').trim() ? 'focus' : 'pensiero');
}
/* 0.9.400 (BUG-181): le risposte di "cosa e' successo" sono quelle del controllo dell'umore (Cosa ti ha pesato di piu' oggi?, umore.js),
   piu' l'ansia, che porta al respiro. [chiave, emoji, testo, indice nell'umore, risposta del Genio] */
const RV_RESPIRO_PERCHE = 'Espirare più a lungo di quanto inspiri rallenta il battito e calma il sistema nervoso, così l’ansia scende.';
const RV_ANSIA = /\bansi[ae]\b|ansios|agitat|panico|nervos|angosci|stressat|\bstress\b|preoccupat|cuore a mille/i;
function rvUmoreMotivi(){
  let l = [];
  try{ l = (typeof UM_DOMANDE !== 'undefined' && UM_DOMANDE.pesato) ? UM_DOMANDE.pesato.opz.map(function(o, i){ return ['m' + i, o.ico, o.t, i, o.r]; }) : []; }catch(_){ l = []; }
  if (!l.length) l = [['lavoro', '💼', 'Il lavoro o lo studio', -1, ''], ['sonno', '😴', 'Ho dormito poco', -1, ''], ['persone', '🗯️', 'Una discussione con qualcuno', -1, ''], ['niente', '➖', 'Nulla in particolare', -1, '']];
  /* l'ansia prima di "Nulla in particolare", che resta l'ultima */
  const ultima = l.length && /nulla/i.test(l[l.length - 1][2]) ? l.pop() : null;
  l.push(['ansia', '😰', 'Mi sento in ansia', -1, 'Grazie per avermelo detto. L’ansia stringe il respiro e fa sembrare tutto più grande di com’è.']);
  if (ultima) l.push(ultima);
  return l;
}
function rvUmoreCosaOk(x){
  RV.r.umoreCosa = x.t;
  RV.r.umoreAnsia = x.k === 'ansia' || RV_ANSIA.test(String(x.t || ''));
  RV.r.umoreRisp = x.r || (RV.r.umoreAnsia ? 'Grazie per avermelo detto. L’ansia stringe il respiro e fa sembrare tutto più grande di com’è.' : 'Grazie per avermelo detto. Una giornata così pesa, e stasera la chiudiamo con calma.');
  /* la risposta va anche nell'umore di oggi, come nel controllo dell'umore */
  try{
    const day = umGiorno(rvUmOff()), u = umLeggi(day) || {};
    const patch = { risposte: (u.risposte || []).filter(function(r){ return r.q !== 'pesato'; }).concat([{ q: 'pesato', i: x.i, t: x.i >= 0 ? '' : x.t }]) };
    if (x.i >= 0 || x.k === 'ansia') patch.motivi = (u.motivi || []).concat([x.t]).filter(function(m, i, a){ return a.indexOf(m) === i; });
    umScrivi(day, patch);
  }catch(_){ }
  rvVai('umoreRisp');
}
/** Il respiro di 3 minuti (lo stesso "Respira con me" del controllo dell'umore); finito, si torna alla revisione da dove si era. */
function rvRespiro(){
  if (typeof rsApri !== 'function'){ rvDopoUmore(RV.r.umVoto || 2); return; }
  try{ flVibra(10); }catch(_){ }
  rsApri({ tecnica: 'rilassamento', durata: 180, libera: 'rilassamento', da: 'revisione', dopo: function(){
    try{ goId('s-genio'); }catch(_){ }
    if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rv') rvDopoUmore(RV.r.umVoto || 2);
  } });
}
function rvPensieroOk(salta){
  const a = document.getElementById('rvPensiero'); const t = a ? a.value.trim() : '';
  if (!salta && t){ try{ umScrivi(umGiorno(rvUmOff()), { nota: t.slice(0, 400) }); }catch(_){ } }
  rvVai('focus');
}
function rvImprevisto(si){
  if (!si){ RV.r.imprevisto = ''; rvVai(rvDomaniTask() ? 'domani' : 'fine'); return; }
  rvVai('imprevistoScrivo');
}
function rvImprevistoOk(){
  const a = document.getElementById('rvImpr'); const t = a ? a.value.trim() : '';
  /* 0.9.310: mai obbligatorio. A campo vuoto si va avanti senza imprevisto */
  RV.r.imprevisto = t;
  if (!t){ rvVai(rvDomaniTask() ? 'domani' : 'fine'); return; }
  /* 0.9.388, Andrea (BUG-111): "racconto l'imprevisto e dopo nessun riscontro". Prima di andare avanti risponde il tuo agente: l'ha
     segnato, e cosa cambia (il passo che si sposta, il piano che si adatta). Se l'agente non c'e' o non risponde, il ripiego locale */
  RV.imprRisp = null; RV.r.imprevistoRisposta = '';
  rvVai('imprevistoRisp');
  rvImprevistoRisposta(t);
}
function rvImprevistoDomanda(t){
  const passo = rvDomaniTask();
  return 'Nella revisione della sera ti racconto un imprevisto: "' + t + '".' + (passo ? ' Domani il mio primo passo è: "' + passo + '".' : '')
    + ' Rispondimi in due o tre frasi brevi, senza domande: dimmi che l’hai segnato e cosa cambia per il mio piano (se il passo di domani si sposta, se il piano si adatta, se mi lascia più tempo o me ne toglie). Niente elenchi.';
}
/** La risposta del ripiego: neutra, perche' un imprevisto puo' togliere tempo o lasciarne di piu' (Andrea: "fino a dicembre ho piu' tempo per il mio progetto"). */
function rvImprevistoLocale(){
  return 'L’ho segnato, e ne tengo conto per il tuo piano.\n\nCosa cambia:\nil passo di domani lo metti all’ora che l’imprevisto lascia libera. Se ti lascia più tempo, gli dai un blocco più lungo. Se cambia più di un giorno, alla fine chiedi al Genio di *ricalcolare la rotta*.';
}
/** Il testo dell'agente nel fumetto del Genio: niente elenchi ne' titoli, il grassetto diventa l'evidenziato del Genio, al massimo 480 lettere. */
function rvTestoGenio(s){
  let t = String(s || '').replace(/\r/g, '').replace(/^\s*#+\s*/gm, '').replace(/^\s*[-•*]\s+/gm, '').replace(/\*\*(.+?)\*\*/g, '*$1*').replace(/\n{3,}/g, '\n\n').trim();
  if (t.length > 480){ const c = t.slice(0, 480), i = Math.max(c.lastIndexOf('. '), c.lastIndexOf('.\n')); t = i > 120 ? c.slice(0, i + 1) : c.replace(/\s+\S*$/, '') + '.'; }
  return typeof flACapo === 'function' ? flACapo(t) : t;
}
function rvImprevistoRisposta(t){
  const giro = RV.imprGiro = (RV.imprGiro || 0) + 1;
  const fatto = function(x){
    if (RV.imprGiro !== giro) return;
    RV.imprRisp = x; RV.r.imprevistoRisposta = x.agente ? x.testo : '';
    if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rv' && RV.passo === 'imprevistoRisp'){ GN.step = ''; gnVai('rv'); }
  };
  const ripiego = function(tipo){ fatto({ testo: rvImprevistoLocale(), agente: false, errore: tipo || '' }); };
  if (typeof cvAgenteBreve !== 'function'){ ripiego(''); return; }
  Promise.resolve(cvAgenteBreve(rvImprevistoDomanda(t), 'imprevisto', 30000)).then(function(testo){
    const s = rvTestoGenio(testo);
    if (!s){ ripiego('altro'); return; }
    fatto({ testo: s, agente: true });
  }, function(e){ ripiego(e && e.code === 'senza-agente' ? '' : (typeof cvErroreTipo === 'function' ? cvErroreTipo(e) : 'altro')); });
}
/* l'imprevisto va al Genio come bozza: il messaggio parte solo quando lo mandi tu */
function rvImprevistoAlGenio(){
  const t = RV.r.imprevisto || '';
  rvChiudi();
  const testo = 'Oggi c\'è stato un imprevisto: ' + t + '\nRicalcola il mio percorso tenendone conto: sposta o cambia le tappe che non reggono più.';
  if (typeof agApri === 'function'){ Promise.resolve(agApri()).then(function(){ try{ AG.vista = 'chat'; agPaint(); }catch(_){ } }); setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900); }
}
function rvBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const p0 = { umore: 0.04, umoreCosa: 0.05, umoreRisp: 0.055, partitaChiedi: 0.06, partita: 0.07, partitaSerie: 0.075, partitaPunti: 0.08, cvDomanda: 0.09, cvCosa: 0.085, cvScrivo: 0.09, cvScopri: 0.1, cvRivela: 0.12, cvFuturo: 0.14, cvChat: 0.3, pensiero: 0.14, focus: 0.24, leva: 0.42, inter: 0.58, sistema: 0.72, ricascato: 0.72, scrivo: 0.6, imprevisto: 0.86, imprevistoScrivo: 0.9, imprevistoRisp: 0.94, fine: 1 }[RV.passo]; const p1 = p0 == null ? (RV.pMax || 0.2) : p0;
  /* 0.9.373, Andrea: "la barra avanza e poi torna indietro di colpo". Le schermate della partita non avevano un posto (valevano 0.2) e
     le domande dopo valevano meno: ora hanno il loro posto e la barra non scende mai */
  const p = Math.max(RV.pMax || 0, p1); RV.pMax = p;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(p * 100) + '%';
  if (txt) txt.textContent = 'La revisione della sera';
}
/* 0.9.371, Andrea: "il collo di bottiglia vorrei vederlo anche nella revisione, se hai il Premium (senza un agente personale l'app non lo
   trova davvero); e il Taglia solo se l'utente si e' scritto delle cose, quando la sua AI e' collegata: a fine giornata gli propone di
   tagliare quello che non e' la priorita'". Due passi in piu', solo quando servono: il collo prima dell'imprevisto, il Taglia prima
   della fine */
/* 0.9.374, Andrea: "nelle revisioni, non solo in quella della sera, voglio la panoramica: il triangolo che mostra l'allineamento fra
   identita', azione e ambiente, cosi' l'utente capisce dove lavorare e dov'e' la sua lacuna". Lo stesso triangolo della scheda
   Panoramica (partita-schede.js, pscTreHtml), senza il pulsante che porterebbe fuori dalla revisione. */
function flPanoRevHtml(){
  let h = ''; try{ h = (typeof pscTreHtml === 'function') ? pscTreHtml() : ''; }catch(_){ h = ''; }
  return h ? '<div class="rv-pano" onclick="event.stopPropagation()">' + h.replace(/<button type="button" class="pst-cta"[^>]*>[^<]*<\/button>/, '') + '</div>' : '';
}
function rvVai(p){
  try{ if (typeof ricPosterChiudi === 'function') ricPosterChiudi(); }catch(_){ }
  /* 0.9.390 (BUG-123): ci e' ricascato. Il cartellone prende il posto della domanda su cosa cambiare; con la chat del tuo agente (che salta
     quella domanda) compare prima dell'imprevisto. Una volta per sera */
  if ((p === 'sistema' || p === 'imprevisto') && RV.ric && !RV.ricVisto){ RV.ricVisto = true; p = 'ricascato'; }
  const pc = rvColloPrima(p);
  if (pc) p = pc;
  else if (p === 'domani' && !RV.panoVisto && flPanoRevHtml()){ RV.panoVisto = true; p = 'pano'; }
  /* 0.9.380, Andrea: "il Taglia doveva venire prima di prenotare il punto, facoltativo: invece toccando Prenota parte il Taglia con il timer".
     Si propone prima della domanda su domani, e chi dice di si' torna qui dopo averlo fatto */
  else if (p === 'domani' && !RV.tagliaVisto && rvTagliaN() >= 3){ RV.tagliaVisto = true; RV.dopoTaglia = 'domani'; p = 'taglia'; }
  RV.storia.push(RV.passo); RV.passo = p; rvRipSalva(); rvBarra(); GN.step = ''; gnVai('rv');
}
function rvPrem(){ try{ return typeof pscPremium === 'function' ? pscPremium() : (typeof Premium !== 'undefined' && !!Premium.isPremium()); }catch(_){ return false; } }
/** il collo di bottiglia degli ultimi 7 giorni, trovato dal tuo agente personale (collo.js); solo con Premium */
/* 0.9.387 (BUG-101): con il periodo ('settimana', 'mese') il collo di quel periodo, se c'e'; la revisione della settimana usa questa stessa funzione */
function rvCollo(per){
  if (!rvPrem()) return null;
  try{ if (per && typeof cloLeggi === 'function'){ const p = cloLeggi(per); if (p && p.t) return p; } }catch(_){ }
  try{ const c = (typeof cloUltimo === 'function') ? cloUltimo() : null; if (c && c.t && (!c.at || Date.now() - c.at < 7 * 86400000)) return c; }catch(_){ }
  return null;
}
/* 0.9.393, Andrea: "in ogni revisione deve essere mostrato, oltre al grafico di panoramica ambiente/azione/identita', l'immagine/slide del
   collo di bottiglia, cioe' proporre all'utente di individuare il collo di bottiglia con il proprio agente e mostrargli cosa sta bloccando
   il progresso verso il sogno (solo per gli utenti Premium che hanno un agente personale). Ma se l'utente ha gia' chiesto quel giorno al
   proprio agente di scovare il collo di bottiglia e l'ha gia' visto nella scheda Sogno, non ha senso mostrarglielo anche nella revisione".
   Prima il passo c'era solo se il collo era gia' stato trovato, e solo prima dell'imprevisto: con la chat del tuo agente (Premium) la sera
   non passa mai dall'imprevisto, quindi proprio chi ha l'agente non lo vedeva. Adesso, per i Premium, in ogni revisione: trovato, la
   bottiglia; non ancora trovato, la bottiglia e "Trovalo con il tuo agente personale" (cloChiedi, lo stesso della scheda Sogno). Si salta
   solo se oggi l'ha gia' visto (o chiesto) nella scheda Sogno (cloVistoOggiNelSogno, collo.js). Free: niente passo. */
/* 0.9.403, Andrea (BUG-279): "di base mostra il sabotatore invisibile nella bottiglia, come nella scheda Sogno. Se non ha fatto il quiz, il
   pulsante porta al quiz. Solo dopo il quiz compare Trovalo con il tuo agente, per un collo piu' preciso, e solo per chi ha l'agente. Mai
   una bottiglia vuota con Il collo e' libero a chi non ha mai trovato niente. Nella revisione il Genio puo' proporre il quiz". Il passo
   del collo c'e' per tutti: il collo trovato dal tuo agente (Premium), se no il sabotatore, se no il quiz. */
function rvColloMostra(per){
  const c = rvCollo(per);
  try{ if (typeof cloVistoOggiNelSogno === 'function' && cloVistoOggiNelSogno(c)) return false; }catch(_){ }
  return !!c || typeof cloBottigliaRevisione === 'function';
}
/** La sera: il collo prende il posto di `p` (l'imprevisto, o la chat con il tuo agente), una volta sola. Ritorna 'collo' o ''. */
function rvColloPrima(p){
  if (RV.colloVisto || (p !== 'imprevisto' && p !== 'cvChat') || !rvColloMostra('')) return '';
  RV.colloVisto = true; RV.r.colloVisto = 1; RV.r.dopoCollo = p;
  return 'collo';
}
/** "Trovalo con il tuo agente personale" nella sera: la revisione si ferma al passo dopo (si riprende da li') e si apre il tuo agente. */
function rvColloTrova(){
  const dopo = (RV.r && RV.r.dopoCollo) || 'imprevisto';
  RV.storia.push(RV.passo); RV.passo = dopo; rvRipSalva();
  rvChiudi();
  setTimeout(function(){ try{ if (typeof cloChiedi === 'function') cloChiedi(false, 'oggi'); }catch(_){ } }, 350);
}
const RV_COLLO_PER = { settimana: 'questa settimana', mese: 'questo mese' };
/** 0.9.403 BUG-279: "Scopri cosa ti blocca" nella revisione: la revisione si ferma al passo dopo il collo (si riprende da li') e si apre il
    quiz del sabotatore invisibile (blocchi.js). modo: 'rv' (la sera) o 'rvp' (la settimana, il mese). */
function rvColloQuiz(modo){
  try{
    if (modo === 'rvp' && typeof RVP !== 'undefined' && typeof rvpChiudi === 'function'){
      RVP.storia.push(RVP.passo); RVP.passo = (typeof rvpExtraDopo === 'function') ? rvpExtraDopo('collo') : 'fine'; if (typeof rvpRipSalva === 'function') rvpRipSalva(); rvpChiudi();
    } else {
      const dopo = (RV.r && RV.r.dopoCollo) || 'imprevisto';
      RV.storia.push(RV.passo); RV.passo = dopo; rvRipSalva(); rvChiudi();
    }
  }catch(_){ }
  setTimeout(function(){ try{ if (typeof blocchiApri === 'function') blocchiApri(); }catch(_){ } }, 350);
}
/** Il passo del collo di bottiglia, per la sera e per le revisioni di periodo: { titolo, html } con il pulsante che fa `continua` (codice JS).
    Senza un collo trovato e con `trova` (codice JS): la bottiglia e la proposta di trovarlo con il tuo agente personale (solo Premium). */
function rvColloPasso(per, continua, trova){
  const c = rvCollo(per);
  const agente = !!(trova && rvPrem() && typeof cloChiedi === 'function');
  if (!c && typeof cloBottigliaRevisione !== 'function' && !agente) return null;
  /* le schede Oggi, Settimana, Mese della bottiglia: la revisione della settimana apre la scheda Settimana */
  try{ if (typeof cloPeriodoSalva === 'function') cloPeriodoSalva(per || 'oggi'); }catch(_){ }
  let bott = ''; try{ bott = (typeof cloSlideHtml === 'function') ? cloSlideHtml(true, false) : ''; }catch(_){ bott = ''; }
  /* 0.9.403 BUG-279: senza un collo trovato, il sabotatore invisibile del quiz; senza quiz, il quiz. Mai la bottiglia vuota */
  if (!c && typeof cloBottigliaRevisione === 'function'){
    const modo = /rvp/.test(String(trova || continua || '')) ? 'rvp' : 'rv';
    const b = cloBottigliaRevisione(modo);
    if (b.s){
      const t = String(b.s.titolo || '').replace(/[*<>]/g, '');
      return { titolo: (per && per !== 'oggi' ? 'Ecco cosa ti ha frenato ' + (RV_COLLO_PER[per] || 'in questo periodo') : 'Prima di chiudere, ecco cosa ti sta frenando') + ':\n*' + t + '*',
        html: '<div class="rv-collo rv-collo-sab" onclick="event.stopPropagation()">' + b.html + '</div>'
          + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();' + continua + '">Continua</button>'
          + (agente ? '<button type="button" class="gn-link" onclick="event.stopPropagation();' + trova + '">Trovalo con il tuo agente, per un collo più preciso</button>' : '') + '</div>' };
    }
    return { titolo: 'Cosa ti blocca davvero?\nTe lo dice *il quiz del sabotatore invisibile*, in pochi minuti.',
      html: '<div class="rv-collo rv-collo-sab" onclick="event.stopPropagation()">' + b.html + '</div>'
        + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvColloQuiz(\'' + modo + '\')">🕵️ Scopri cosa ti blocca</button>'
        + '<button type="button" class="gn-link" onclick="event.stopPropagation();' + continua + '">Più tardi</button></div>' };
  }
  if (!c){
    /* i pulsanti della slide restano nascosti (rv-collo-trova): la scelta e' una sola, e la dice il Genio */
    return { titolo: 'Cosa ti sta frenando di più ' + (RV_COLLO_PER[per] || 'oggi') + '?\n*Il tuo agente personale* lo trova con te.',
      html: (bott ? '<div class="rv-collo rv-collo-trova" onclick="event.stopPropagation()">' + bott + '</div>' : '')
        + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();' + trova + '">Trovalo con il tuo agente personale</button>'
        + '<button type="button" class="gn-link" onclick="event.stopPropagation();' + continua + '">Più tardi</button></div>' };
  }
  const t = String(c.t || '').replace(/[*<>]/g, '');
  return { titolo: (per && per !== 'oggi' ? 'Ecco cosa ti ha frenato di più ' + (RV_COLLO_PER[per] || 'in questo periodo') : 'Prima di chiudere, ti ricordo cosa ti sta frenando di più') + ':\n*' + t + '*',
    html: (bott ? '<div class="rv-collo" onclick="event.stopPropagation()">' + bott + '</div>' : '')
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();' + continua + '">Continua</button></div>' };
}
/** quante cose hai scritto nella nota di oggi: il Taglia si propone solo con la tua AI collegata (o con Premium) e almeno tre cose */
function rvTagliaN(){
  let ai = false; try{ ai = (typeof pntUsato === 'function' && pntUsato()) || rvPrem(); }catch(_){ ai = false; }
  if (!ai) return 0;
  try{ return (typeof mnIdeePerTaglia === 'function') ? mnIdeePerTaglia(8).length : 0; }catch(_){ return 0; }
}
function rvTagliaVia(){
  /* senza timer, e finito il Taglia si torna alla revisione, alla domanda su domani */
  const torna = RV.dopoTaglia || 'fine';
  const ripresa = { r: RV.r, storia: RV.storia.concat([RV.passo]), visti: RV.visti, bozze: RV.bozze, scrivoPer: RV.scrivoPer, passo: torna };
  try{ if (typeof ES !== 'undefined') ES.dopo = function(){ try{ RV_RIPRESA = ripresa; rvApri().then(function(){ RV.tagliaVisto = true; }); }catch(_){ } }; }catch(_){ }
  rvSalvaEsito(); rvChiudi();
  setTimeout(function(){ try{ if (typeof esApri === 'function'){ const d = new Date(); esApri({ id: 'sera-taglia-' + d.getFullYear() + (d.getMonth() + 1) + d.getDate(), es: 'taglia', arco: 'oggi', calmo: true }); } }catch(_){ } }, 450);
}
/* 0.9.340, Andrea: "ho toccato indietro alla fine e la revisione e' sparita": indietro torna sempre alla domanda di prima */
function rvIndietro(){ try{ if (typeof ricPosterChiudi === 'function') ricPosterChiudi(); }catch(_){ } if (!RV.storia.length){ rvChiudi(); return true; } RV.passo = RV.storia.pop(); rvBarra(); GN.step = ''; gnVai('rv'); return true; }
/* 0.9.373, Andrea: "toccando la X durante la revisione, prima di uscire chiedi: sei sicuro di voler uscire?" */
function rvEsciChiedi(){
  /* 0.9.374: come in un livello di Duolingo, la barra in alto cade e si raddrizza se resti */
  if (typeof flEsciConferma === 'function'){
    if (typeof flEsciAperta === 'function' && flEsciAperta()){ flEsciResta(); return; }
    flEsciConferma('#gnTop .gn-prog', rvChiudi, { titolo: 'Sei sicuro di voler uscire?', sotto: 'Quello che hai scritto resta. La riprendi da qui.', resta: 'CONTINUO LA REVISIONE', via: 'ESCI' });
    return;
  }
  let v = document.getElementById('rvEsci'); if (v) v.remove();
  v = document.createElement('div'); v.id = 'rvEsci'; v.className = 'rv-esci';
  v.innerHTML = '<div class="rv-esci-in"><button type="button" class="rv-esci-x" aria-label="Chiudi" onclick="document.getElementById(\'rvEsci\').remove()">✕</button><h3>Sei sicuro di voler uscire?</h3><p>Quello che hai scritto resta:<br>la riprendi da qui.</p>'
    + '<button type="button" class="cta" onclick="document.getElementById(\'rvEsci\').remove()">Continuo la revisione</button><button type="button" class="rv-esci-l" onclick="document.getElementById(\'rvEsci\').remove();rvChiudi()">Esci</button></div>';
  v.addEventListener('click', function(e){ if (e.target === v) v.remove(); });
  (document.getElementById('phone') || document.body).appendChild(v);
}
function rvChiudi(){
  /* la scelta fatta sulla prima cosa di domani (tutorial, domanda, tre passi, punto) parte solo adesso, a giornata chiusa */
  const azione = RV.passo === 'fine' ? RV.dopoAzione : '';
  RV.dopoAzione = '';
  try{ if (typeof ricPosterChiudi === 'function') ricPosterChiudi(); }catch(_){ }
  if (azione) setTimeout(function(){ rvDomaniAzione(azione); }, 250);
  rvRipSalva();
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab(RV_DA.tab || 'mappa'); }catch(_){ } RV_DA.tab = '';
  try{ if (typeof rvCardPaint === 'function') rvCardPaint(); }catch(_){ }
  try{ rvOvunquePaint(); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}
const RV_DA = { tab: '' };
function rvCarte(voci, scrivo){
  RV.opz = voci;
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();rvScegli(' + i + ')"><span>' + o[1] + '</span><b>' + gnEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>'
    + (scrivo ? '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rvScrivo()">✍️ Lo scrivo io</button>' : '');
}
/* 0.9.387, Andrea (BUG-102): "dopo i due punti si va SEMPRE a capo, regola generale da ora in poi". Ogni card dei fatti della sera e delle
   revisioni di periodo passa di qui: dopo i due punti la frase continua sulla riga sua (flACapo), e l'a capo si vede davvero */
function flACapo(t){ return String(t == null ? '' : t).replace(/:[ \t]+(?=\S)/g, ':\n'); }
function rvVisto(righe){ return righe.length ? '<div class="rng-visto">' + righe.map(function(r){ return '<div class="rng-v"><span>' + r[0] + '</span><p>' + gnEsc(flACapo(r[1])).replace(/\n/g, '<br>') + '</p></div>'; }).join('') + '</div>' : ''; }
/* 0.9.276, Andrea: "gli hai mostrato due dati e poi la domanda, tutto insieme: zero one element one focus".
   Prima una schermata con i dati della giornata, poi la domanda da sola. */
function rvDati(p, titolo, v){
  if (!v.length || RV.visti[p]) return false;
  gnDomanda('pensa', titolo, rvVisto(v) + '<div class="or-grid one"><button type="button" class="or-a main" data-p="' + p + '" onclick="event.stopPropagation();rvDatiOk(this)">Avanti</button></div>');
  return true;
}
function rvDatiOk(b){ RV.visti[b.getAttribute('data-p')] = 1; GN.step = ''; gnVai('rv'); }
/* 0.9.282, Andrea: "scrivo un pensiero, vado avanti, torno indietro e il campo e' vuoto". Il testo resta: la bozza di
   ogni campo (o, per il pensiero, quello gia' salvato oggi) torna dentro quando la domanda si ridisegna. */
function rvBozza(k, v){ RV.bozze = RV.bozze || {}; RV.bozze[k] = v; rvRipSalva(); }
function rvRiempi(giri){
  const b = RV.bozze || {};
  const campi = [['rvPensiero', b.pensiero || (rvUmoreOggi().nota || '')], ['rvImpr', b.impr || RV.r.imprevisto || ''], ['rvTesto', b.scrivo || '']];
  let trovato = false;
  campi.forEach(function(c){ const t = document.getElementById(c[0]); if (t){ trovato = true; if (!t.value && c[1]) t.value = c[1]; } });
  if (!trovato && (giri || 0) < 20) setTimeout(function(){ rvRiempi((giri || 0) + 1); }, 250);
}
function rvEntra(){
  setTimeout(rvRiempi, 300);
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo'); }
  if (typeof cvEntra === 'function' && cvEntra('rv')) return;
  const d = RV.dati || { ff: { n: 0 }, app: [], chiuse: [] }, p = RV.passo;
  const d0 = rvInizio();
  if (p === 'collo'){
    /* 0.9.374, Andrea: "ti ricorda cosa ti sta frenando ma non fa vedere il pannello del collo di bottiglia della scheda Sogno: la stessa
       immagine, la pallina che non riesce a uscire per colpa di quello che la blocca". Nella revisione le schede Oggi, Settimana, Mese */
    const dopo = (RV.r && RV.r.dopoCollo) || 'imprevisto';
    const cp = rvColloPasso('', 'rvVai(\'' + dopo + '\')', 'rvColloTrova()');
    if (!cp){ rvVai(dopo); return; }
    gnDomanda('pensa', cp.titolo, cp.html);
    return;
  }
  if (p === 'pano'){
    gnDomanda('rivela', 'Ecco la tua combinazione segreta. *Il numero più basso* è quello su cui lavorare domani.',
      flPanoRevHtml() + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(\'domani\')">Continua</button></div>');
    return;
  }
  if (p === 'taglia'){
    const n = rvTagliaN();
    gnDomanda('pensa', 'Oggi nella nota hai scritto ' + n + ' cose. *Tagliamo quelle che non sono la priorità?* Quelle tagliate restano nel cestino delle note.',
      '<div class="or-grid"><button type="button" class="or-a main" onclick="event.stopPropagation();rvTagliaVia()">Sì, tagliamo</button><button type="button" class="or-a" onclick="event.stopPropagation();rvVai(RV.dopoTaglia || \'fine\')">Non stasera</button></div>');
    return;
  }
  if (p === 'partitaChiedi'){
    gnDomanda('pensa', 'Una giornata dura capita. Ho visto com’è andata la partita contro il vecchio te:\n*vuoi saperlo adesso*?',
      '<div class="or-grid"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(\'partita\')">Sì, dimmelo</button><button type="button" class="or-a" onclick="event.stopPropagation();rvVai(rvPartitaFine())">Oggi no</button></div>');
    return;
  }
  if (p === 'partita'){
    /* 0.9.402 BUG-259: prima la partita di oggi, poi il campionato (il totale di START) con chi e' avanti (rvPartitaHtml) */
    gnDomanda('rivela', 'Ecco la partita di oggi e, sotto, il campionato.', rvPartitaHtml(d0.getTime(), Date.now())
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(rvPartitaDopo(\'partita\'))">Continua</button></div>');
    return;
  }
  if (p === 'partitaSerie'){
    const sv = vtSerie();
    gnDomanda(sv.tipo === 'vinte' ? 'rivela' : 'pensa', vtSerieFrase(sv, (typeof vtNome === 'function') ? vtNome() : ''),
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(rvPartitaDopo(\'partitaSerie\'))">Continua</button></div>');
    return;
  }
  if (p === 'partitaPunti'){
    gnDomanda('pensa', 'Ecco gli ultimi punti, e chi li ha segnati.', vtPuntiHtml(d0.getTime(), Date.now(), true)
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(rvPartitaFine())">Continua</button></div>');
    return;
  }
  if (p === 'umore'){
    const V = (typeof UM_VOCI !== 'undefined') ? UM_VOCI : ['Malissimo', 'Storta', 'Così così', 'Bene', 'Benissimo'];
    const E = (typeof UM_EMOJI !== 'undefined') ? UM_EMOJI : ['😫', '😕', '😐', '🙂', '🤩'];
    gnDomanda('pensa', 'Prima di tutto:\n*come ti senti oggi*?',
      '<div class="gn-carta"><div class="rv-facce">' + V.map(function(v, i){ return '<button type="button" onclick="event.stopPropagation();rvUmore(' + (i + 1) + ')"><span>' + E[i] + '</span><small>' + gnEsc(v) + '</small></button>'; }).join('') + '</div></div>');
    return;
  }
  if (p === 'umoreCosa'){
    gnDomanda('pensa', 'Mi dispiace che oggi sia andata così.\n*Cosa è successo*, o cosa non è andato come speravi?', rvCarte(rvUmoreMotivi(), true));
    return;
  }
  if (p === 'umoreRisp'){
    const ansia = !!RV.r.umoreAnsia;
    gnDomanda('pensa', (RV.r.umoreRisp || 'Grazie per avermelo detto.') + (ansia ? '\n\nPrima di andare avanti, *tre minuti di respiro*?' : ''),
      ansia ? '<p class="rv-resp-perche">' + gnEsc(RV_RESPIRO_PERCHE) + '</p><div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvRespiro()">🌬️ Respira con me, 3 minuti</button>'
        + '<button type="button" class="gn-link" onclick="event.stopPropagation();rvDopoUmore(RV.r.umVoto || 2)">Continuo la revisione</button></div>'
        : '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvDopoUmore(RV.r.umVoto || 2)">Continua</button></div>');
    return;
  }
  if (p === 'pensiero'){
    gnDomanda('pensa', 'Vuoi lasciare *un pensiero* sulla tua giornata?',
      '<textarea class="gn-area" id="rvPensiero" rows="4" oninput="rvBozza(\'pensiero\',this.value)" placeholder="Com\u2019è andata, cosa ti porti a casa…" onclick="event.stopPropagation()"></textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvPensieroOk(false)">Salva</button>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();rvPensieroOk(true)">Salta</button></div>');
    return;
  }
  if (p === 'imprevisto'){
    gnDomanda('pensa', (RV.corta ? 'Oggi hai già fatto il punto con me, quindi ti chiedo solo due cose.\n\n' : '') + 'Oggi c\u2019è stato *un imprevisto*, o sta arrivando qualcosa che cambia i tuoi piani?',
      rvCarte([['no', '🛡️', 'No, tutto come previsto'], ['si', '⚠️', 'Sì, lo dico al Genio']], false));
    return;
  }
  /* 0.9.329, Andrea: "prima di chiudere, la prima cosa da fare domani: la vede, si prepara, fa domande, la scompone o guarda il tutorial. Domattina e' gia' pronto" */
  /* 0.9.388, Andrea (BUG-112): al posto dei cinque pulsanti, il popover del passo di domani (prenota.js), lo stesso che si apre dopo:
     il perche', il calendario di domani per scegliere l'ora, Scomponilo, Tutorial e Blinda. Chiuso, si va alla pagina del diario */
  if (p === 'domani'){
    const t = rvDomaniTask();
    if (!t){ rvVai('fine'); return; }
    gnDomanda('rivela', 'Prima di chiudere, guarda *la prima cosa di domani*.',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvDomaniApri()">Il passo di domani</button></div>', rvDomaniApri);
    return;
  }
  if (p === 'imprevistoRisp'){
    const x = RV.imprRisp;
    if (!x){
      if (!RV.imprGiro && RV.r.imprevisto) rvImprevistoRisposta(RV.r.imprevisto);   // ripresa della revisione: si richiede
      gnDomanda('pensa', 'Ci penso un attimo…', '<div class="rv-pensa" aria-label="Sta pensando"><i></i><i></i><i></i></div>');
      return;
    }
    let nota = '';
    if (!x.agente && x.errore){ const nome = (typeof cvNomeAgente === 'function') ? cvNomeAgente() : 'Il tuo agente'; nota = x.errore === 'accesso' ? ((typeof agAccessoTesti === 'function') ? agAccessoTesti('nota').testo : 'Il tuo agente personale risponde dal server di DreamMap, che ti riconosce dal tuo account Google.') : nome + ' adesso non risponde. Intanto ti rispondo io.'; }
    /* 0.9.389 (BUG-118): senza accesso le parole vengono da un posto solo (agAccessoTesti, agente.js) */
    gnDomanda('rivela', x.testo, (nota ? '<p class="rv-impr-nota">' + gnEsc(nota) + '</p>' : '')
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(rvDomaniTask() ? \'domani\' : \'fine\')">Continua</button></div>');
    return;
  }
  if (p === 'imprevistoScrivo'){
    gnDomanda('pensa', 'Raccontamelo:\n*cosa è successo*, o cosa arriva?',
      '<textarea class="gn-area" id="rvImpr" rows="4" oninput="rvBozza(\'impr\',this.value);rvCampoBtn(this,\'rvImprOk\',\'Confermo\')" placeholder="Per esempio: questa settimana lavoro di sera, ho due giorni in meno…" onclick="event.stopPropagation()"></textarea><div class="or-grid one"><button type="button" class="or-a" id="rvImprOk" onclick="event.stopPropagation();rvImprevistoOk()">Salta</button></div>',
      function(){ const a = document.getElementById('rvImpr'); if (a) a.focus(); });
    return;
  }
  if (p === 'focus'){
    const v = [];
    if (d.ff.n) v.push(['⏱️', 'Oggi hai fatto ' + (d.ff.n === 1 ? 'una sessione' : d.ff.n + ' sessioni') + ' di Full Focus, per ' + rvOre(d.ff.min) + (d.ff.mollate ? ': ' + (d.ff.mollate === 1 ? 'una interrotta' : d.ff.mollate + ' interrotte') + '.' : ', tutte finite.')]);
    else v.push(['⏱️', 'Oggi non hai fatto sessioni di Full Focus.']);
    if (d.app[0]) v.push(['📱', 'Sul telefono: ' + rvOre(d.app[0].min) + ' su ' + d.app[0].nome + (d.app[1] ? ' e ' + rvOre(d.app[1].min) + ' su ' + d.app[1].nome : '') + '.']);
    if (rvDati('focus', 'Ecco *la tua giornata*.', v)) return;
    gnDomanda('pensa', 'Durante i blocchi di lavoro profondo di oggi, *eri davvero concentrato*?',
      rvCarte([['si', '🎯', 'Sì, quasi sempre'], ['meta', '🌗', 'A metà'], ['poco', '🌫️', 'Poco'], ['nessuno', '🚫', 'Oggi niente lavoro profondo']], false));
    return;
  }
  if (p === 'leva'){
    const v = [];
    if (d.prio) v.push([d.prioFatta ? '✅' : '⭕', 'La priorità di oggi era "' + d.prio + '": ' + (d.prioFatta ? 'l’hai chiusa.' : 'non è ancora chiusa.')]);
    try{ if (typeof pntRigheSera === 'function') pntRigheSera().forEach(function(x){ v.push(x); }); }catch(_){ }
    if (d.chiuse.length) v.push(['📋', 'Cose chiuse oggi: ' + d.chiuse.length + (d.chiuse.length === 1 ? ' (' + d.chiuse[0] + ').' : ', fra cui "' + d.chiuse[0] + '".')]);
    if (rvDati('leva', 'Ecco *cosa hai chiuso* oggi.', v)) return;
    gnDomanda('pensa', 'Oggi hai lavorato sulle cose *ad alta leva*, quelle che avvicinano davvero il sogno, o solo su quelle facili?',
      rvCarte([['alta', '🚀', 'Sulla cosa più importante'], ['media', '🧩', 'Su cose utili, non le più importanti'], ['facili', '🪶', 'Sulle cose facili'], ['nessuna', '⏸️', 'Su niente del piano']], true));
    return;
  }
  if (p === 'inter'){
    const a = d.app[0];
    gnDomanda('pensa', 'Cosa, *di preciso*, ti ha interrotto oggi?',
      rvCarte([['app', '📱', a ? a.nome : 'Un’app'], ['notifiche', '🔔', 'Le notifiche'], ['persone', '🗣️', 'Persone o telefonate'], ['testa', '💭', 'I miei pensieri, le idee nuove'], ['energia', '🪫', 'Mi mancava l’energia'], ['niente', '🛡️', 'Niente, è filato liscio']], true));
    return;
  }
  if (p === 'ricascato'){
    /* 0.9.390 (BUG-123): il cartellone a tutto schermo (ricascato.js). Dietro, il Genio aspetta: se il cartellone si chiude con indietro, lo si riapre */
    if (!RV.ric){ rvVai('sistema'); return; }
    gnDomanda('pensa', 'Prima di scegliere, guarda bene questi numeri.',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();ricPosterApri(RV.ric)">Rivedi</button></div>');
    if (typeof ricPosterApri === 'function') ricPosterApri(RV.ric);
    return;
  }
  if (p === 'sistema'){
    const k = RV.r.inter, app = (d.app[0] && d.app[0].nome) || 'quell’app';
    RV.sistemaPkg = (d.app[0] && d.app[0].pkg) || '';
    /* 0.9.390 (BUG-123): dopo il cartellone ("Scelgo un altro cambiamento") la risposta che ha gia' fallito non si ripropone */
    if (RV.ric && RV.ricVisto){
      const ric = RV.ric, via = ['blocca'].concat(ric.tentativo && ric.tentativo.cosa === 'elimina' ? ['elimina'] : []);
      RV.sistemaPkg = ric.pkg;
      const alt = [['blocca', '🛡️', 'Blocco ' + ric.nome + ' nelle ore di lavoro'], ['stanza', '📵', 'Telefono in un’altra stanza durante i blocchi'], ['elimina', '🗑️', 'Tolgo ' + ric.nome + ' dal telefono']]
        .filter(function(o){ return via.indexOf(o[0]) < 0; });
      gnDomanda('pensa', 'Allora un altro cambiamento.\n*Cosa cambi* da domani?', rvCarte(alt, true));
      return;
    }
    const l = {
      app: [['blocca', '🛡️', 'Blocco ' + app + ' nelle ore di lavoro'], ['stanza', '📵', 'Telefono in un’altra stanza durante i blocchi'], ['elimina', '🗑️', 'Tolgo ' + app + ' dal telefono']],
      notifiche: [['silenzio', '🔕', 'Lavoro solo in Full Focus, notifiche chiuse'], ['automatizza', '⚙️', 'Spengo le notifiche che non servono'], ['finestre', '🪟', 'Rispondo ai messaggi in due finestre fisse']],
      persone: [['avviso', '🚪', 'Avviso prima con un "adesso non ci sono"'], ['delega', '🤝', 'Delego quello che può fare qualcun altro'], ['finestre', '🪟', 'Telefonate e messaggi in due finestre fisse']],
      testa: [['caveau', '🔒', 'Le idee nuove nel caveau, subito'], ['scrivo', '✍️', 'Scrivo i pensieri che girano, e torno'], ['respiro', '🌬️', 'Dieci minuti di respiro prima del blocco']],
      energia: [['mattina', '🌅', 'Il blocco difficile quando ho più energia'], ['sonno', '🌙', 'Stasera a letto prima'], ['corto', '✂️', 'Blocchi più corti, con le pause']]
    }[k] || [['uguale', '🛡️', 'Tengo il sistema com’è, perché funziona'], ['alza', '📈', 'Domani alzo l’asticella di un blocco']];
    gnDomanda('pensa', 'Non serve più forza di volontà:\nserve un sistema migliore. *Cosa cambi* da domani?', rvCarte(l, true));
    return;
  }
  if (p === 'scrivo'){
    gnDomanda('pensa', 'Scrivilo *con parole tue*.', '<textarea class="gn-area" id="rvTesto" rows="4" oninput="rvBozza(\'scrivo\',this.value);rvCampoBtn(this,\'rvTestoOk\',\'Confermo\')" placeholder="Scrivi qui…" onclick="event.stopPropagation()"></textarea><div class="or-grid one"><button type="button" class="or-a" id="rvTestoOk" onclick="event.stopPropagation();rvScrivoOk()">Salta</button></div>',
      function(){ const a = document.getElementById('rvTesto'); if (a) a.focus(); });
    return;
  }
  if (p === 'fine'){ rvFine(); return; }
}
function rvScegli(i){
  const o = RV.opz[i]; if (!o) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  const p = RV.passo;
  if (p === 'focus'){ RV.r.focus = o[0]; RV.r.focusTesto = o[2]; rvVai('leva'); return; }
  if (p === 'leva'){ RV.r.leva = o[0]; RV.r.levaTesto = o[2]; rvVai('inter'); return; }
  if (p === 'inter'){ RV.r.inter = o[0]; RV.r.interTesto = o[2]; rvVai(o[0] === 'niente' ? 'sistema' : 'sistema'); return; }
  if (p === 'sistema'){ RV.r.sistema = o[0]; RV.r.sistemaTesto = o[2]; RV.r.sistemaPkg = (o[0] === 'blocca' || o[0] === 'elimina') ? (RV.sistemaPkg || '') : ''; rvVai('imprevisto'); return; }
  if (p === 'imprevisto'){ rvImprevisto(o[0] === 'si'); return; }
  if (p === 'umoreCosa'){ rvUmoreCosaOk({ k: o[0], t: o[2], i: o[3] == null ? -1 : o[3], r: o[4] || '' }); return; }
}
function rvScrivo(){ RV.scrivoPer = RV.passo; rvVai('scrivo'); }
function rvScrivoOk(){
  const a = document.getElementById('rvTesto'); const t = a ? a.value.trim() : '';
  /* 0.9.310: lo scritto e' facoltativo. A campo vuoto la domanda si salta e si va alla prossima */
  const per = RV.scrivoPer;
  RV.passo = RV.storia.pop() || RV.passo;
  if (per === 'umoreCosa'){ if (t) rvUmoreCosaOk({ k: 'scritto', t: t, i: -1, r: '' }); else rvDopoUmore(RV.r.umVoto || 2); return; }
  if (per === 'leva'){ if (t){ RV.r.leva = 'scritto'; RV.r.levaTesto = t; } rvVai('inter'); return; }
  if (per === 'inter'){ if (t){ RV.r.inter = 'scritto'; RV.r.interTesto = t; } rvVai('sistema'); return; }
  if (t){ RV.r.sistema = 'scritto'; RV.r.sistemaTesto = t; } rvVai('imprevisto');
}
/* il pulsante sotto a un campo facoltativo: "Salta" a campo vuoto, la sua parola quando c'e' del testo */
function rvCampoBtn(a, id, pieno){ const b = document.getElementById(id); if (b) b.textContent = a.value.trim() ? pieno : 'Salta'; }
/* la prima cosa di domani */
/* 0.9.388, Andrea (BUG-112): "nella revisione il passo di domani era Il tuo piano su misura, dopo la chiusura un altro". Qui c'era una
   seconda funzione, che leggeva anche il nome della tappa in corso della mappa (la tappa del piano su misura non e' una cosa da
   fare). Adesso il passo di domani viene da UNA funzione sola, pkPassoDomani (prenota.js): la stessa del popover e della prenotazione.
   Dentro c'e' anche la regola della 0.9.374 (una sessione di Full Focus dice su cosa). */
function rvDomaniTask(){
  try{ const x = (typeof pkPassoDomani === 'function') ? pkPassoDomani() : null; return x && x.t ? (typeof pkTitolo === 'function' ? pkTitolo(x.t) : x.t) : ''; }catch(_){ return ''; }
}
function rvSalvaEsito(){
  rvRipVia();
  try{ localStorage.removeItem('fl_rv_rifai'); }catch(_){ }
  const r = RV.r, g = rvOggi();
  const l = rvLista().filter(function(x){ return x.giorno !== g; });
  let decN = null; try{ decN = (typeof cloDecisioniOggi === 'function') ? cloDecisioniOggi() : null; }catch(_){ }
  l.push({ giorno: g, at: Date.now(), decisioni: decN, focus: r.focusTesto || '', leva: r.levaTesto || '', interruzione: r.interTesto || '', contromisura: r.sistemaTesto || '', contromisuraK: r.sistema || '', contromisuraPkg: r.sistemaPkg || '', imprevisto: r.imprevisto || '', imprevistoRisposta: r.imprevistoRisposta || '', dati: RV.dati });
  try{ localStorage.setItem(RV_KEY, JSON.stringify(l.slice(-120))); }catch(_){ }
}
/* 0.9.340, Andrea: "ero alla parte finale, mi ha portato a una pagina (il tutorial) e la revisione era finita": scegliere cosa
   fare con la prima cosa di domani non chiude piu' la revisione. Si arriva alla pagina finale del diario, e la scelta parte
   quando chiudi la giornata. La richiesta all'agente resta nel campo: parte solo con invio */
/* 0.9.388 (BUG-112): la scelta si fa nel popover del passo di domani (prenota.js, pkPuntoApri). Scomponilo e Tutorial toccati li'
   durante la revisione restano in coda (PK_PUNTO.coda) e partono qui, a giornata chiusa, con lo stesso messaggio del popover */
const RV_DOPO = { scomponi: 'Chiudi e scomponi il passo', tutorial: 'Chiudi e guarda il tutorial', domanda: 'Chiudi e fai la tua domanda', prenota: 'Chiudi e prenota il punto' };
function rvDomaniAzione(k){
  const t = rvDomaniTask();
  if ((k === 'scomponi' || k === 'tutorial') && typeof pkAiutoVia === 'function'){ pkAiutoVia(k === 'tutorial' ? 'video' : 'passi', t, (typeof pkPuntiDomani === 'function' ? pkPuntiDomani()[0] : null)); return; }
  if (k === 'prenota'){ if (typeof pkPuntoApri === 'function') pkPuntoApri(); return; }
  if (typeof agApri !== 'function') return;
  agApri();
  setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza('Domani la prima cosa è "' + t + '". Ho una domanda: '); }catch(_){ } }, 300);
}
/* Il popover del passo di domani dentro la revisione: chiuso (prenotato o no), si va alla pagina del diario. rev: 'rv' o 'rvp'. */
function rvDomaniPopover(rev, quando, poi){
  if (typeof pkPuntoApri !== 'function'){ poi(''); return; }
  pkPuntoApri({ rev: rev, poi: function(){
    if (!quando()) return;
    const c = (typeof PK_PUNTO !== 'undefined') ? PK_PUNTO.coda : '';
    poi(c === 'video' ? 'tutorial' : (c === 'passi' ? 'scomponi' : ''));
  } });
}
function rvDomaniApri(){
  if (!GN.on || GN.modo !== 'rv' || RV.passo !== 'domani' || document.getElementById('stgVelo')) return;
  rvDomaniPopover('rv', function(){ return GN.on && GN.modo === 'rv' && RV.passo === 'domani'; }, function(az){ RV.dopoAzione = az; rvVai('fine'); });
}
/* ---------------------------------------------------------------------------------------
   0.9.388, Andrea (BUG-113): "sotto il diario tre pulsanti: Fai ricalcolare la rotta al Genio, Prenota il punto di domani, Chiudi e
   prenota il punto. Ne bastano due, e il testo dipende dallo stato: se il punto di domani e' gia' prenotato niente pulsante che porta
   a prenotare (tocchi e ti dice che e' gia' prenotato); altrimenti Prenota il punto e chiudi. Una funzione sola che decide".
   La usano la sera (rvFine), la sera fatta in chat (cvFineHtml) e le revisioni di periodo (rvpFine).
   o: { extra: [html dei pulsanti in piu', come Fai ricalcolare la rotta], max: quanti pulsanti al massimo (2),
        chiudi: il codice che chiude, prenota: il codice che apre il popover e poi chiude, chiudiT: la parola di Chiudi, coda: l'azione in coda }
   --------------------------------------------------------------------------------------- */
function flFineBottoni(o){
  o = o || {};
  const r = (typeof pkPuntiDomani === 'function') ? pkPuntiDomani()[0] : null;
  const puoi = typeof pkPuntoApri === 'function' && !!o.prenota;
  const extra = (o.extra || []).filter(Boolean).slice(0, Math.max(0, (o.max || 2) - 1));
  let ultimo;
  if (r || !puoi) ultimo = '<button type="button" class="or-a main" onclick="event.stopPropagation();' + o.chiudi + '">' + gnEsc((o.coda && o.coda !== 'prenota' && RV_DOPO[o.coda]) || o.chiudiT || 'Chiudi la giornata') + '</button>';
  else ultimo = '<button type="button" class="or-a main" onclick="event.stopPropagation();' + o.prenota + '">Prenota il punto e chiudi</button>';
  /* gia' prenotato: si vede cosa e per che ora (lo stesso riquadro del popover, testo scuro sul gradiente: BUG-114) */
  const pren = r ? '<div class="pkp-gia rv-pren"><small>Prenotato per domani' + (typeof pkOra === 'function' ? ' alle ' + pkOra(r.inizio) : '') + '</small><p>' + gnEsc(typeof pkTitoloVis === 'function' ? pkTitoloVis(r.testo).intero : (typeof pkTitolo === 'function' ? pkTitolo(r.testo) : r.testo)) + '</p></div>' : '';
  return pren + '<div class="or-grid one">' + extra.join('') + ultimo + '</div>';
}
function rvPrenotaChiudi(){
  rvDomaniPopover('rv', function(){ return GN.on && GN.modo === 'rv' && RV.passo === 'fine'; }, function(az){ if (az) RV.dopoAzione = az; rvChiudi(); });
}
function rvFine(){
  rvSalvaEsito();
  const r = RV.r;
  const serie = rvSerie();
  gnDomanda('rivela', 'Revisione fatta. Domani il sistema *lavora per te*.',
    /* 0.9.310: una pagina del diario di viaggio (revisioni-periodo.js, rvdPaginaHtml), non un elenco di domande e risposte */
    (typeof rvdPaginaHtml === 'function'
      ? rvdPaginaHtml({ tipo: 'sera', at: Date.now(), decisioni: (typeof cloDecisioniOggi === 'function' ? cloDecisioniOggi() : null), focus: r.focusTesto || '', leva: r.levaTesto || '', interruzione: r.interTesto || '', contromisura: r.sistemaTesto || '' }, serie > 1 ? serie + ' sere di fila con la revisione' : '')
      : '')
    /* 0.9.301: il consenso ai dati anonimi che insegnano al Genio (conversa.js), spento finche' non lo accendi */
    + (typeof cvConsensoHtml === 'function' ? cvConsensoHtml() : '')
    /* 0.9.242: la sera si prenota domani (prenota.js). 0.9.388 (BUG-113): due pulsanti al massimo, decisi da flFineBottoni */
    + flFineBottoni({ extra: [r.imprevisto ? '<button type="button" class="or-a" onclick="event.stopPropagation();rvImprevistoAlGenio()">Fai ricalcolare la rotta al Genio</button>' : ''],
        chiudi: 'rvChiudi()', prenota: 'rvPrenotaChiudi()', coda: RV.dopoAzione }));
  try{ flVibra([20, 40, 30]); }catch(_){ }
}
/** Per il tuo agente personale: le ultime revisioni della sera. */
function rvPerAgente(){
  const l = rvLista().slice(-5); if (!l.length) return '';
  /* 0.9.310: i campi vuoti (domande saltate, o la sera fatta dentro una revisione di periodo) non si scrivono */
  return 'Revisioni della sera (Fogarty): ' + l.map(function(x){
    return x.giorno + (x.inclusaIn ? ' (dentro la revisione di periodo)' : '') + ' ' + [['concentrazione', x.focus], [x.inclusaIn ? 'ha funzionato' : 'lavoro', x.leva], [x.inclusaIn ? 'gli ha fatto perdere tempo' : 'interruzione', x.interruzione], ['da domani', x.contromisura], ['imprevisto', x.imprevisto]]
      .filter(function(c){ return c[1]; }).map(function(c){ return c[0] + ' "' + c[1] + '"'; }).join(', ');
  }).join('; ') + '.';
}

/* ---------- la card nella Mappa (vista Roadmap): dalle 17 in poi, finche' non e' fatta ----------
   0.9.235, Andrea: finche' la revisione e' da fare, la card compare nella Roadmap, nella Mappa (sopra al
   pannello di pianificazione), in START (sotto alle nuvole) e in Dream; fatta, sparisce ovunque e resta
   solo quella verde in Dream. */
/** 0.9.310: la sera di oggi fatta dentro una revisione di periodo: il nome di quella revisione, o ''. */
function rvInclusaOggi(){ const g = rvOggi(); const x = rvLista().filter(function(v){ return v.giorno === g; }).pop(); return x && x.inclusaIn ? ({ settimana: 'revisione della settimana', mese: 'revisione del mese', trimestre: 'revisione del trimestre', anno: 'revisione dell’anno' }[x.inclusaIn] || '') : ''; }
/* 0.9.340, Andrea: "rimettimi la revisione della sera una tantum adesso, cosi' la rifaccio": una volta sola, per l'amministratore,
   la revisione di oggi si riapre anche prima delle 17. Fatta, il permesso sparisce. */
/* 0.9.347, Andrea: "la revisione della sera di ieri, alle 14 di oggi, e' ancora li'. Quando ti risvegli la mattina non deve piu' esserci,
   altrimenti il Genio fa la revisione del giorno sbagliato. Lo stesso per la settimana: un giorno di ritardo al massimo, poi sparisce".
   Restava aperta la schermata: l'app era in sottofondo dalla sera prima e al ritorno riprendeva da li'. Adesso, quando l'app torna davanti
   (e ogni minuto), una revisione della sera aperta in un giorno passato si chiude dalle 5 del mattino in poi; una revisione di periodo
   si chiude appena il suo periodo non e' piu' quello da rivedere (la settimana: fino a lunedi' compreso). Le risposte date restano. */
function rvScadutaControlla(){
  try{
    if (typeof GN === 'undefined' || !GN.on) return;
    const ora = new Date().getHours();
    if (GN.modo === 'rv' && RV.giorno && RV.giorno !== rvOggi() && ora >= 5){
      rvRipVia(); rvChiudi();
      try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
      if (typeof toast === 'function') toast('La revisione di ieri si è chiusa. Stasera trovi quella di oggi.');
      return;
    }
    if (GN.modo === 'rvp' && typeof RVP !== 'undefined' && RVP.tipo && RVP.periodo && typeof rvpPeriodoDovuto === 'function' && rvpPeriodoDovuto(RVP.tipo) !== RVP.periodo){
      if (typeof rvpChiudi === 'function') rvpChiudi();
      try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
      if (typeof toast === 'function') toast('Il tempo per questa revisione è finito. La prossima arriva da sola.');
    }
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(rvScadutaControlla, 300); });
setInterval(rvScadutaControlla, 60000);
/* 0.9.348, Andrea: "alle 11 di mattina c'e' ancora la revisione della sera". La causa: il permesso "rifalla una volta" del 0.9.340 restava
   acceso per sempre se la revisione si chiudeva dalla chat (che non passa da rvSalvaEsito), e teneva la card a schermo a ogni ora.
   Adesso il permesso vale solo per il giorno in cui e' stato dato */
function rvRifai(){ try{ const v = localStorage.getItem('fl_rv_rifai'); if (!v) return false; if (v !== rvOggi()){ localStorage.removeItem('fl_rv_rifai'); return false; } return true; }catch(_){ return false; } }
setTimeout(function(){
  try{
    if (localStorage.getItem('fl_rv_rifai_340') || !(typeof flAdmin === 'function' && flAdmin())) return;
    localStorage.setItem('fl_rv_rifai_340', '1'); localStorage.setItem('fl_rv_rifai', rvOggi());
    try{ if (typeof nvsPaint === 'function') nvsPaint(); }catch(_){ }
  }catch(_){ }
}, 2500);
function rvStato(){
  if (rvFattaOggi()) return 'fatta';
  if (rvRifai()) return 'da-fare';
  /* 0.9.310, UNA REVISIONE SOLA: con una revisione di periodo da fare (revisioni-periodo.js) la card della sera non
     compare: quella del periodo la contiene, e fatta lei e' fatta anche la sera */
  try{ if (typeof rvpDovuta === 'function' && rvpDovuta()) return ''; }catch(_){ }
  return rvSera() ? 'da-fare' : '';
}
function rvCardHtml(){
  const fatta = rvFattaOggi(), h = new Date().getHours(), serie = rvSerie();
  if (!fatta && !rvSera()) return '';
  return '<div class="rv-card' + (fatta ? ' fatta' : '') + '" onclick="' + (fatta ? '' : 'rvApri()') + '" role="button"><span class="rv-ico">' + (fatta ? '✅' : '🌙') + '</span><div><small>La revisione della sera</small><b>'
    + (fatta ? 'Fatta. Domani il sistema lavora per te.' : 'Tre domande sulla giornata, e una cosa da cambiare nel sistema.') + '</b>'
    + (serie > 1 ? '<i>' + serie + ' sere di fila</i>' : '') + '</div>' + (fatta ? '' : '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>') + '</div>';
}
function rvCardPaint(){
  /* 0.9.337, Andrea: "le revisioni solo nella scheda Sogno, come prima slide del carosello" */
  ['mppRevisione'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
  try{ rvOvunquePaint(); }catch(_){ }
  return;
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  let h = document.getElementById('mppRevisione');
  const rm = document.getElementById('mppSentiero');
  if (!h){ h = document.createElement('div'); h.id = 'mppRevisione'; h.className = 'mpp-slot'; }
  if (rm && h.nextElementSibling !== rm) rm.parentNode.insertBefore(h, rm);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  h.classList.toggle('mpp-via', v !== 'rotta');
  h.innerHTML = rvStato() === 'da-fare' ? rvCardHtml() : ''; h.hidden = !h.innerHTML;
  try{ rvOvunquePaint(); }catch(_){ }
}
/** Mette uno spazio con id `id` subito prima (o subito dopo) di un elemento. */
function rvSlot(id, rif, dopo){
  if (!rif || !rif.parentNode) return null;
  let h = document.getElementById(id);
  if (!h){ h = document.createElement('div'); h.id = id; h.className = 'rv-slot'; }
  if (dopo){ if (rif.nextElementSibling !== h) rif.parentNode.insertBefore(h, rif.nextSibling); }
  else if (h.nextElementSibling !== rif) rif.parentNode.insertBefore(h, rif);
  return h;
}
function rvOvunquePaint(){
  /* 0.9.337, Andrea: "le revisioni (sera, settimana, mese, trimestre, anno) solo in Sogno, come prima slide grande del carosello
     dove c'e' la tua storia". Le card piccole nelle altre schede si tolgono; la slide la disegna nvsPaint (dream-storia.js). */
  ['mppRevMia', 'stRevisione', 'nvRevisione', 'insRevisione'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
  try{ if (typeof nvsPaint === 'function' && document.getElementById('nvsCar')) nvsPaint(NVS.rientro); }catch(_){ }
  return;
  const st = rvStato(); const card = st ? rvCardHtml() : '';
  /* la Mappa, vista "pianifica tu": sopra al pannello di pianificazione */
  const mia = rvSlot('mppRevMia', document.getElementById('mppFoglio'), false);
  if (mia){ let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ } mia.classList.toggle('mpp-via', v !== 'mia'); mia.innerHTML = st === 'da-fare' ? card : ''; mia.hidden = !mia.innerHTML; }
  /* START: sotto alle nuvole */
  const sta = rvSlot('stRevisione', document.getElementById('stHero'), true);
  if (sta){ const hs = st === 'da-fare' ? card : ''; if (sta._html !== hs){ sta._html = hs; sta.innerHTML = hs; } sta.hidden = !hs; }
  /* Dream: sopra alla lettura del Genio. Se l'episodio di oggi e' fatto e non c'e' da rientrare in
     rotta, la card da fare prende il posto della lettura (lo fa nvPaint in rotta-tab.js) */
  const top = document.getElementById('nvTop');
  const dr = rvSlot('nvRevisione', top, false);
  if (dr){ const gia = top && top.querySelector('.rv-card'); const hd = (st === 'fatta' || (st === 'da-fare' && !gia)) ? card : ''; if (dr._html !== hd){ dr._html = hd; dr.innerHTML = hd; } dr.hidden = !hd; }
  /* la prossima mossa (0.9.237) sta subito sotto alla lettura del Genio */
  try{ const mo = document.getElementById('nvMossa'); if (mo && top && top.nextElementSibling !== mo) top.parentNode.insertBefore(mo, top.nextSibling); }catch(_){ }
  /* il Report: niente (0.9.235, Andrea aveva scritto Report al posto di Roadmap) */
  const rep = document.getElementById('insRevisione'); if (rep) rep.remove();
}

/* 0.9.234, Andrea: la stessa card anche in cima al Report. Compare dalle 17 finche' la revisione non
   e' fatta; poi resta solo quella verde "Fatta. Domani il sistema lavora per te." (fino a mezzanotte). */
function rvReportPaint(){ try{ rvOvunquePaint(); }catch(_){ } }
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.rv = { entra: rvEntra };
  if (typeof insRender === 'function'){ const v6 = insRender; window.insRender = insRender = function(){ const r = v6.apply(this, arguments); try{ rvReportPaint(); }catch(_){ } return r; }; }
  if (typeof switchTab === 'function'){ const v7 = switchTab; window.switchTab = switchTab = function(t){ const r = v7.apply(this, arguments); setTimeout(function(){ try{ rvOvunquePaint(); }catch(_){ } }, 80); return r; }; }
  /* i blocchi di START, Mappa e Dream si riordinano da soli: dopo, gli spazi tornano al loro posto */
  if (typeof scsOrdinaBlocchi === 'function'){ const v8 = scsOrdinaBlocchi; window.scsOrdinaBlocchi = scsOrdinaBlocchi = function(){ const r = v8.apply(this, arguments); try{ rvOvunquePaint(); }catch(_){ } return r; }; }
  if (typeof cstOrdinaBlocchi === 'function'){ const v9 = cstOrdinaBlocchi; window.cstOrdinaBlocchi = cstOrdinaBlocchi = function(){ const r = v9.apply(this, arguments); try{ rvOvunquePaint(); }catch(_){ } return r; }; }
  setInterval(function(){ try{ rvReportPaint(); rvCardPaint(); }catch(_){ } }, 60000);
  if (typeof gnChiudiTop === 'function'){ const v = gnChiudiTop; gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'rv'){ if (RV.passo === 'fine') rvChiudi(); else rvEsciChiedi(); return; } return v.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v2 = gnIndietro; gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rv') return rvIndietro(); return v2.apply(this, arguments); }; }
  if (typeof mppPaint === 'function'){ const v3 = mppPaint; window.mppPaint = mppPaint = function(){ const r = v3.apply(this, arguments); try{ rvCardPaint(); }catch(_){ } return r; }; }
  if (typeof mppApplicaVista === 'function'){ const v4 = mppApplicaVista; window.mppApplicaVista = mppApplicaVista = function(){ const r = v4.apply(this, arguments); try{ rvCardPaint(); }catch(_){ } return r; }; }
  if (typeof rnPerAgente === 'function'){ const v5 = rnPerAgente; window.rnPerAgente = rnPerAgente = function(){ return [v5.apply(this, arguments), rvPerAgente()].filter(Boolean).join(' '); }; }
  const st = document.createElement('style');
  st.textContent = [
    '#mppRevisione{padding:0 16px;margin:8px 0 10px}#mppRevisione[hidden]{display:none}',
    '.rv-slot[hidden]{display:none}#mppRevMia{padding:0 16px;margin:8px 0 10px}#stRevisione{padding:0 16px;margin:10px 0 12px}#nvRevisione{margin:0 0 14px}',
    '.rv-card{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:20px;background:linear-gradient(135deg,#1E2A5A,#0F2041);color:#fff;cursor:pointer;box-shadow:0 10px 24px rgba(0,20,60,.18)}.rv-card.fatta{cursor:default;background:#EAF6EF;color:#14234A;box-shadow:none}',
    '.rv-card > div{flex:1;min-width:0}.rv-ico{font-size:28px;flex:none}.rv-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.rv-card.fatta small{color:#1B9E6A}',
    '.rv-card b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}.rv-card i{display:block;margin-top:3px;font:600 12px var(--font-body);font-style:normal;color:#8CC6FF}.rv-card.fatta i{color:#1B9E6A}'
  ].join('');
  document.head.appendChild(st);
})();

(function rvStile(){
  const st = document.createElement('style');
  st.textContent = '.rv-facce{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.rv-facce button{display:flex;flex-direction:column;align-items:center;gap:8px;border:0;border-radius:16px;background:rgba(0,117,227,.08);padding:14px 2px;cursor:pointer}.rv-facce span{font-size:34px;line-height:1}.rv-facce small{font:700 11.5px var(--font-body);color:#0E2350;text-align:center}body.dark .rv-facce small{color:#EEF4FF}body.dark .rv-facce button{background:rgba(255,255,255,.08)}.rv-facce button:active{transform:scale(.94)}';
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  /* 0.9.388: i cinque pulsanti della prima cosa di domani (.rv-dom) non ci sono piu' (BUG-112). Qui l'attesa della risposta
     all'imprevisto (BUG-111) e il riquadro del punto gia' prenotato sopra ai pulsanti finali (BUG-113): testo scuro sul gradiente */
  st.textContent = '.rv-pensa{display:flex;justify-content:center;gap:8px;padding:18px 0}.rv-pensa i{width:10px;height:10px;border-radius:50%;background:#BCE0FF;animation:rvPensa 1s infinite ease-in-out}.rv-pensa i:nth-child(2){animation-delay:.15s}.rv-pensa i:nth-child(3){animation-delay:.3s}'
    + '@keyframes rvPensa{0%,80%,100%{opacity:.3;transform:translateY(0)}40%{opacity:1;transform:translateY(-4px)}}'
    + '.rv-impr-nota{margin:0 0 14px;text-align:center;font:600 13px/1.45 var(--font-body);color:#DCEBFF}'
    + '.rv-pren{margin:6px 0 14px}'
    /* 0.9.400 (BUG-181): il perche' del respiro, una riga su fondo scuro con il testo bianco */
    + '.rv-resp-perche{margin:0 0 14px;padding:12px 14px;border-radius:16px;background:rgba(9,20,44,.78);border:1px solid rgba(140,198,255,.32);color:#fff;text-align:center;font:600 14px/1.45 var(--font-body)}';
  document.head.appendChild(st);
})();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style');
  st.textContent = '.rv-esci{position:absolute;inset:0;z-index:99990;background:rgba(0,14,34,.6);display:flex;align-items:flex-end}.rv-esci-in{position:relative;width:100%;box-sizing:border-box;padding:28px 22px calc(22px + env(safe-area-inset-bottom));border-radius:26px 26px 0 0;background:var(--card,#fff);text-align:center}.rv-esci-in h3{margin:4px 40px 12px;font:800 21px var(--font-display);color:var(--navy)}.rv-esci-in p{margin:0 0 30px;font:500 15px/1.5 var(--font-body);color:var(--muted)}.rv-esci-in .cta{width:100%}.rv-esci-l{display:block;margin:10px auto 0;padding:10px;border:0;background:none;color:var(--muted);font:700 15px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}.rv-esci-x{position:absolute;top:14px;right:14px;width:36px;height:36px;border:0;border-radius:50%;background:var(--bg);color:var(--navy);cursor:pointer}body.dark .rv-esci-in{background:#12203A}body.dark .rv-esci-in h3,body.dark .rv-esci-x{color:#fff}';
  document.head.appendChild(st); })();

/* 0.9.374: il collo di bottiglia e la panoramica dentro la revisione, sul pannello scuro come nella scheda Sogno */
(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = '.rv-collo,.rv-pano{align-self:stretch;margin:18px 0 6px;padding:18px 16px 16px;border-radius:24px;background:linear-gradient(170deg,#0B2E5E,#001E44);box-shadow:inset 0 0 0 1px rgba(140,198,255,.18)}'
    + '.rv-collo.rv-collo-sab{padding:0;background:none;box-shadow:none}.rv-collo-sab .clo-bott-pan{margin:0}'   /* 0.9.403 BUG-279: la bottiglia del quiz ha gia' il suo pannello */
    + '.rv-collo .nvp-rs{width:auto!important;flex:none!important}.rv-collo-trova .clo-cta,.rv-collo-trova .clo-link{display:none!important}.rv-pano .psc-pano-h{display:block;font:800 22px var(--font-display);color:#fff;margin-top:6px}.rv-pano .psc-pano-p{margin:8px 0 0;font:500 14.5px/1.5 var(--font-body);color:#C8EFFD}';
  document.head.appendChild(st);
})();

/* 0.9.381, Andrea: "rimettimi la revisione serale per rifarla, solo per me che sono l'admin, e che scompaia dopo averla fatta. Dammi la
   possibilita' di rifarla quante volte voglio". Una volta adesso (fl_rv_rifai_381), e poi dal menu ☰ la voce "Rifai la revisione della
   sera", che vede solo l'admin: il permesso vale per oggi e si spegne appena la revisione e' fatta */
function rvRifaiAdmin(){
  if (!(typeof flAdmin === 'function' && flAdmin())) return;
  try{ localStorage.setItem('fl_rv_rifai', rvOggi()); }catch(_){ }
  try{ if (typeof drawerClose === 'function') drawerClose(); }catch(_){ }
  try{ rvOvunquePaint(); }catch(_){ }
  try{ if (typeof nvsPaint === 'function') nvsPaint(); }catch(_){ }
  setTimeout(function(){ try{ rvApri(); }catch(_){ } }, 250);
}
setTimeout(function(){
  try{
    if (!(typeof flAdmin === 'function' && flAdmin())) return;
    if (!localStorage.getItem('fl_rv_rifai_381')){ localStorage.setItem('fl_rv_rifai_381', '1'); localStorage.setItem('fl_rv_rifai', rvOggi()); try{ rvOvunquePaint(); }catch(_){ } try{ if (typeof nvsPaint === 'function') nvsPaint(); }catch(_){ } }
    const nav = document.querySelector('#drawerWrap .drawer'), sep = nav && nav.querySelector('.dsep');
    if (nav && sep && !document.getElementById('drwRvAdmin')){
      const b = document.createElement('button'); b.className = 'drow'; b.id = 'drwRvAdmin'; b.setAttribute('onclick', 'rvRifaiAdmin()');
      b.innerHTML = '<span class="ic">🌙</span>Rifai la revisione della sera<span class="arr">→</span>';
      nav.insertBefore(b, sep);
    }
  }catch(_){ }
}, 3000);

/* 0.9.402 BUG-259: il campionato sotto la partita di oggi, in un riquadro che stacca dal fondo scuro della scena (testo chiaro fisso) */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style');
  st.textContent = '.rv-par .vt-esito{margin-bottom:0}'
    + '.rv-camp{width:100%;box-sizing:border-box;margin:28px 0 32px;padding:16px 16px 18px;border-radius:20px;background:rgba(9,20,44,.62);border:1px solid rgba(140,198,255,.3);text-align:center;color:#fff}'
    + '.rv-camp-k{margin:0 0 12px;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}'
    + '.rv-camp-tab{display:flex;align-items:center;justify-content:center;gap:22px}'
    + '.rv-camp-tab span{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:84px}'
    + '.rv-camp-tab small{font:700 12.5px var(--font-body);color:#C8EFFD}'
    + '.rv-camp-tab b{font:900 30px/1 var(--font-display)}.rv-camp-tab .old b{color:#FF8A92}.rv-camp-tab .neo b{color:#8CC6FF}'
    + '.rv-camp-tab i{font:800 20px var(--font-display);font-style:normal;opacity:.5}'
    + '.rv-camp-l{margin:14px 0 0;font:700 15px/1.4 var(--font-body);color:#fff}';
  document.head.appendChild(st); })();
