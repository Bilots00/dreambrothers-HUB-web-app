/* ===========================================================================================
   IL PONTE CON LE ALTRE AI (0.9.333)

   Andrea: "se usa un'AI agentica che puo' comunicare con DreamMap, quello su cui lavora deve arrivare al Genio: se l'utente ha
   lavorato e il Genio non lo sa, e' un problema". Si accende solo dal pulsante nel foglio dell'albero maestro, e da li' c'e' una
   chiave sua. La sua AI scrive un riassunto (mai la conversazione intera) con il server MCP o con una chiamata HTTP (dal 0.9.353
   la Timeline non ha piu' il riquadro per incollarlo a mano). Il Genio lo legge nel brief e nella revisione della sera.
   Spegnendolo, la chiave e tutto quello che era stato scritto spariscono dal server e dal telefono. Prefisso pnt-.
   =========================================================================================== */
const PNT_K = 'fl_ponte_chiave', PNT_LOG = 'fl_ponte_log';
const PNT = { at: 0 };
function pntBase(){ return (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app'; }
function pntChiave(){ try{ return localStorage.getItem(PNT_K) || ''; }catch(_){ return ''; } }
function pntOn(){ return !!pntChiave(); }
/* 0.9.371, Andrea: "dice Collegata, ma Le tue AI dice che non hanno ancora scritto niente". Acceso non vuol dire collegato: collegata e'
   quando la sua AI ha usato il collegamento almeno una volta (il server lo segna, usatoAt) */
function pntUsato(){ try{ return +(localStorage.getItem('fl_ponte_usato') || 0) > 0 || pntVoci().length > 0; }catch(_){ return false; } }
/* l'ora del resoconto della sera, scelta dall'utente: entra nel messaggio da dare alla sua AI */
function pntOraSera(){ try{ return localStorage.getItem('fl_ponte_ora') || '21:00'; }catch(_){ return '21:00'; } }
function pntOraSeraMetti(v){ if (!/^\d{2}:\d{2}$/.test(v || '')) return; try{ localStorage.setItem('fl_ponte_ora', v); }catch(_){ } try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ } }
function pntMcpUrl(){ return pntBase() + '/api/dreammap/ponte/mcp/' + pntChiave(); }
function pntHttpUrl(){ return pntBase() + '/api/dreammap/ponte/registra'; }
function pntVoci(){ try{ return JSON.parse(localStorage.getItem(PNT_LOG) || '[]') || []; }catch(_){ return []; } }
async function pntCollega(){
  const r = await frApi('POST', '/api/focuslock/ponte/collega', { device: frDevice() });
  if (!r || !r.chiave) throw new Error('nessuna chiave');
  try{ localStorage.setItem(PNT_K, r.chiave); }catch(_){ }
  /* una chiave nuova: il server non ha ancora risposto per lei */
  PNT.risposto = 0; PNT.rispChiave = ''; PNT.errore = false;
  pntPianoManda();
  return r.chiave;
}
async function pntScollega(){
  const c = pntChiave();
  try{ localStorage.removeItem(PNT_K); localStorage.removeItem(PNT_LOG); }catch(_){ }
  if (c){ try{ await frApi('POST', '/api/focuslock/ponte/scollega', { chiave: c }); }catch(_){ } }
}
/* il piano di oggi, per lo strumento leggi_piano */
function pntPianoManda(){
  if (!pntOn() || typeof amAlbero !== 'function') return;
  try{
    const a = amAlbero();
    const testo = 'Il sogno: ' + (a.SOGNO || 'da scrivere') + '\nQuest\'anno: ' + (a.ANNO || 'da scrivere') + '\nQuesto mese: ' + (a.MESE || 'da scrivere') + '\nQuesta settimana: ' + (a.SETTIMANA || 'da scrivere') + '\nOggi, una cosa sola: ' + (a.OGGI || 'da scrivere');
    /* 0.9.397: con la roadmap che si vede (i passi, o la proposta del Genio) e fin dove ha mostrato quelle della sua AI */
    frApi('POST', '/api/focuslock/ponte/piano', { chiave: pntChiave(), piano: testo, roadmap: pntRoadmapVista(), rmVista: +pntRmStato().vista || 0 }).catch(function(){ });
  }catch(_){ }
}
/* 0.9.397, sull'account vero: leggi_piano diceva "Quest'anno: da scrivere, Questo mese: da scrivere..." e il Genio la roadmap gliel'aveva
   fatta il giorno prima. Le cinque righe qui sopra hanno solo gli anelli GIA' APPLICATI (fl_orizzonti) e niente passi; la roadmap su
   misura del Genio resta nella sua chat, nella carta con "Applica la roadmap" (agPianoHtml, agente.js), finche' non la tocca. La roadmap
   che l'utente vede: gli anelli applicati con i passi ancora da fare; se non ce n'e' nessuno, l'ultima proposta del Genio. */
const PNT_ANELLI = ['cinque', 'anno', 'mese', 'settimana', 'oggi'];
function pntRoadmapVista(){
  const v = { fonte: 'app' };
  try{ v.sogno = (typeof nvSogno === 'function') ? String(nvSogno() || '').trim() : ''; }catch(_){ v.sogno = ''; }
  try{ v.adesso = (typeof stTask === 'function') ? String(stTask() || '').replace(/^[☐☑•]\s*/, '').trim() : ''; }catch(_){ v.adesso = ''; }
  let n = 0;
  if (typeof ozAnello === 'function') PNT_ANELLI.forEach(function(k){
    try{
      const a = ozAnello(k) || {};
      const testo = String(a.testo || '').trim();
      const passi = (Array.isArray(a.passi) ? a.passi : []).filter(function(p){ return p && p.t && !p.fatto; }).map(function(p){ return String(p.t); }).slice(0, 6);
      if (testo || passi.length){ v[k] = { testo: testo, passi: passi }; n++; }
    }catch(_){ }
  });
  if (n) return v;
  try{
    const ms = (typeof agStato === 'function') ? (agStato().msgs || []) : [];
    for (let i = ms.length - 1; i >= 0; i--){
      const m = ms[i], p = m && m.direzione === 'out' && m.azioni && m.azioni.piano;
      if (!p || typeof p !== 'object') continue;
      const g = { fonte: 'genio', at: +m.at || 0, sogno: String(p.sogno || '').trim() || v.sogno, adesso: v.adesso };
      PNT_ANELLI.forEach(function(k){
        const x = p[k]; if (!x || typeof x !== 'object') return;
        const passi = (Array.isArray(x.passi) ? x.passi : []).map(function(t){ return String(t || ''); }).filter(Boolean).slice(0, 6);
        if (x.testo || passi.length) g[k] = { testo: String(x.testo || ''), passi: passi };
      });
      return g;
    }
  }catch(_){ }
  return v;
}
/* ---------- 0.9.347: LA ROADMAP FATTA DALLA TUA AI (gratis) ----------
   Si accende il ponte, si copia l'indirizzo del server MCP e un messaggio da incollare nella propria AI. L'AI fa le domande e scrive la
   roadmap con lo strumento scrivi_roadmap; l'app la trova da sola e la applica solo con il si' dell'utente (agApplicaPiano). */
const PNT_RM_K = 'fl_pnt_rm';
function pntRmStato(){ try{ return JSON.parse(localStorage.getItem(PNT_RM_K) || '{}') || {}; }catch(_){ return {}; } }
function pntRmSalva(o){ try{ localStorage.setItem(PNT_RM_K, JSON.stringify(o)); }catch(_){ } }
function pntRmMessaggio(){ return 'Collegati a DreamMap (il server MCP che ti ho aggiunto, con gli strumenti leggi_piano e scrivi_roadmap). Leggi il mio piano, fammi le domande che ti servono una alla volta, poi scrivi il mio percorso verso il sogno con scrivi_roadmap.'; }
async function pntCopia(t, ok){ try{ await navigator.clipboard.writeText(t); }catch(_){ try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.copyText) await NATIVE.copyText({ text: t }); }catch(__){ } } if (typeof toast === 'function') toast(ok || 'Copiato'); }
async function pntRoadmapApri(){
  try{ if (!pntOn()) await pntCollega(); }catch(_){ if (typeof toast === 'function') toast('Il collegamento non si è acceso: riprova fra un attimo.'); return; }
  const o = pntRmStato(); o.attesa = Date.now(); pntRmSalva(o);
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio pnt-rm"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="pnt-rm-ico" aria-hidden="true">🔌</div><h3>La tua AI fa il tuo percorso</h3>'
    + '<div class="pnt-rm-p"><b>1</b><div><p>Aggiungi DreamMap alla tua AI come connettore (server MCP).</p><button type="button" class="pnt-rm-b" onclick="pntCopia(pntMcpUrl(),\'Indirizzo copiato\')">Copia l’indirizzo</button></div></div>'
    + '<div class="pnt-rm-p"><b>2</b><div><p>Incolla questo messaggio nella tua AI.</p><button type="button" class="pnt-rm-b" onclick="pntCopia(pntRmMessaggio(),\'Messaggio copiato\')">Copia il messaggio</button></div></div>'
    + '<div class="pnt-rm-p"><b>3</b><div><p>Rispondi alle sue domande. Quando ha finito, il percorso compare qui da solo.</p></div></div>'
    /* 0.9.348, Andrea: "con Claude si puo' creare un workflow che ogni giorno fa da reporter di cosa ho fatto e aggiorna la roadmap da solo,
       senza che io debba chiedere il ricalcolo". Il messaggio da mettere come attivita' di ogni sera nella sua AI, e l'interruttore che
       fa applicare la roadmap senza chiedere (acceso da lui: e' il suo si') */
    + '<div class="pnt-rm-p"><b>4</b><div><p>Ogni sera, il resoconto: nella tua AI crea un’attività che parte da sola con questo messaggio.</p><button type="button" class="pnt-rm-b" onclick="pntCopia(pntRmSera(),\'Messaggio della sera copiato\')">Copia il messaggio della sera</button></div></div>'
    + '<button type="button" class="pnt-rm-auto' + (pntRmStato().auto ? ' on' : '') + '" onclick="pntRmAuto(this)"><div><b>Aggiorna il percorso da solo</b><small>Quando la tua AI lo riscrive, si applica senza chiedertelo.</small></div><i aria-hidden="true"></i></button>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
  pntRoadmapGuarda();
}
function pntRmSera(){ return 'Ogni giorno alle ' + pntOraSera() + ', resoconto della sera per DreamMap: leggi il mio piano con leggi_piano. '
  + 'Poi scrivi con registra_lavoro tutto quello su cui abbiamo lavorato oggi (le task, quanto tempo, e se erano la priorità del piano). '
  + 'Se quello che sto facendo non torna più con il percorso, aggiornalo con scrivi_roadmap.'; }
function pntRmAuto(b){ const o = pntRmStato(); o.auto = !o.auto; if (o.auto) o.attesa = Date.now(); pntRmSalva(o); if (b) b.classList.toggle('on', !!o.auto); try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ } if (o.auto) pntRoadmapGuarda(); }
async function pntRoadmapControlla(){
  if (!pntOn()) return;
  const o = pntRmStato();
  try{
    const r = await frApi('GET', '/api/focuslock/ponte/roadmap?chiave=' + encodeURIComponent(pntChiave()));
    if (!r || !r.piano || !(r.at > (o.vista || 0))) return;
    o.vista = r.at; pntRmSalva(o);
    /* 0.9.397: leggi_piano dice alla sua AI che l'app la roadmap l'ha mostrata (o applicata) */
    if (o.auto && typeof agApplicaPiano === 'function'){ agApplicaPiano(r.piano); pntPianoManda(); if (typeof toast === 'function') setTimeout(function(){ toast('La tua AI ha aggiornato il percorso'); }, 1400); return; }
    pntRoadmapProponi(r.piano);
    pntPianoManda();
  }catch(_){ }
}
function pntRoadmapProponi(p){
  if (typeof inSheet !== 'function') return;
  PNT_RM_P = p;
  const nomi = { cinque: 'Fra cinque anni', anno: 'Quest’anno', mese: 'Questo mese', settimana: 'Questa settimana', oggi: 'Oggi' };
  /* 0.9.400 BUG-180, Andrea: "le card azzurrine Quest'anno, Questo mese, Questa settimana, Oggi devono essere identiche ai toggle degli
     orizzonti" (lezione 270). Sono lo STESSO componente della pagina degli orizzonti (orizzonti.js, ozToggleHtml), con dentro i passi */
  const ks = ['anno', 'mese', 'settimana', 'oggi'].filter(function(k){ return p[k] && p[k].testo; });
  const righe = typeof ozToggleHtml === 'function'
    ? '<div class="pst pnt-rm-oz"><div class="oz-corpo"><div class="oz-its">' + ks.map(function(k){
        const passi = (Array.isArray(p[k].passi) ? p[k].passi : []).filter(Boolean);
        return ozToggleHtml({ k: k, nome: nomi[k], sotto: passi.length ? (passi.length === 1 ? '1 passo' : passi.length + ' passi') : '', obiettivo: String(p[k].testo), aperto: k === 'oggi',
          corpo: passi.length ? '<div class="oz-cap">' + passi.map(function(t){ return ozTappaRigaHtml(typeof flAccenti === 'function' ? flAccenti(String(t)) : String(t), false); }).join('') + '</div>' : '' });
      }).join('') + '</div></div></div>'
    : ks.map(function(k){ return '<div class="pnt-rm-a"><small>' + nomi[k] + '</small><b>' + String(p[k].testo).replace(/</g, '&lt;') + '</b></div>'; }).join('');
  inSheet('<div class="en-foglio pnt-rm"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="pnt-rm-ico" aria-hidden="true">🗺️</div><h3>La tua AI ha scritto il percorso</h3>' + righe
    + '<button type="button" class="en-cta" onclick="inSheetChiudi();if(typeof agApplicaPiano===\'function\')agApplicaPiano(PNT_RM_P)">Applica il percorso</button>'
    + '<button type="button" class="pnt-rm-no" onclick="inSheetChiudi()">Non adesso</button></div>');
}
let PNT_RM_P = null, PNT_RM_T = 0;
/* 0.9.397: la roadmap della sua AI si cercava SOLO nei tre giorni dopo aver aperto il foglio del resoconto della sera (o con "Aggiorna il
   percorso da solo"). Chi collega la sua AI da "Collega la tua AI" e le chiede la roadmap non la vedeva mai, e scrivi_roadmap gli diceva
   "l'utente la vede nell'app". Adesso, con il ponte acceso, si cerca sempre all'avvio e a ogni rientro nell'app; il giro ogni 20 secondi
   resta solo mentre si aspetta (il foglio aperto da poco, o l'interruttore acceso). */
function pntRoadmapGuarda(){
  if (!pntOn()) return;
  const o = pntRmStato();
  clearInterval(PNT_RM_T); PNT_RM_T = 0;
  if (o.auto || (o.attesa && Date.now() - o.attesa < 3 * 86400000)) PNT_RM_T = setInterval(function(){ if (document.visibilityState === 'visible') pntRoadmapControlla(); }, 20000);
  pntRoadmapControlla();
}
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible' && pntOn()) pntRoadmapControlla(); });
/* 0.9.397: applicata una roadmap (quella del Genio o quella della sua AI), leggi_piano la legge subito, senza aspettare il rientro */
(function(){ if (typeof agApplicaPiano !== 'function') return; const v = agApplicaPiano; window.agApplicaPiano = agApplicaPiano = function(){ const r = v.apply(this, arguments); setTimeout(function(){ try{ pntPianoManda(); }catch(_){ } }, 600); return r; }; })();
setTimeout(pntRoadmapGuarda, 6000);
(function(){ const st = document.createElement('style'); st.textContent = '.pnt-rm{text-align:center}.pnt-rm-ico{font-size:46px;line-height:1;margin:6px 0 10px}.pnt-rm h3{margin:0 0 18px}'
  + '.pnt-rm-p{display:flex;gap:12px;align-items:flex-start;text-align:left;margin:0 0 16px}.pnt-rm-p > b{flex:none;width:28px;height:28px;border-radius:50%;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;font:800 14px var(--font-body)}.pnt-rm-p p{margin:3px 0 8px;font:600 14.5px/1.45 var(--font-body);color:var(--navy)}body.dark .pnt-rm-p p{color:#fff}'
  + '.pnt-rm-b{padding:9px 14px;border-radius:99px;border:1.5px solid #3F9FF4;background:#F0FBFF;color:#0075E3;font:800 13.5px var(--font-body);cursor:pointer}body.dark .pnt-rm-b{background:#12203A}'
  + '.pnt-rm-a{text-align:left;padding:12px 14px;border-radius:16px;background:var(--bg,#F0FBFF);border:1px solid var(--line);margin:0 0 8px}.pnt-rm-a small{display:block;font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}.pnt-rm-a b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body);color:var(--navy)}body.dark .pnt-rm-a{background:#12203A;border-color:#22345A}body.dark .pnt-rm-a b{color:#fff}'
  + '.pnt-rm-auto{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin:4px 0 6px;padding:14px;border-radius:16px;border:1.5px solid #C8EFFD;background:#F0FBFF;text-align:left;cursor:pointer}.pnt-rm-auto div{flex:1}.pnt-rm-auto b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}.pnt-rm-auto small{display:block;margin-top:2px;font:500 12.5px/1.35 var(--font-body);color:var(--muted)}.pnt-rm-auto i{flex:none;width:44px;height:26px;border-radius:99px;background:#C8D6E8;position:relative;transition:background .2s}.pnt-rm-auto i::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:transform .2s}.pnt-rm-auto.on i{background:#0075E3}.pnt-rm-auto.on i::after{transform:translateX(18px)}body.dark .pnt-rm-auto{background:#12203A;border-color:#22345A}body.dark .pnt-rm-auto b{color:#fff}'
  + '.pnt-rm .pnt-rm-oz{text-align:left;padding:14px 0 12px;margin:0 0 6px;border-radius:24px}.pnt-rm-oz .oz-corpo{padding:0 12px}'
  + '.pnt-rm .en-cta{margin-top:14px}.pnt-rm-no{display:block;margin:10px auto 0;border:0;background:none;color:var(--muted);font:700 14px var(--font-body);cursor:pointer}'; document.head.appendChild(st); })();
/* 0.9.397, Andrea: "ho collegato Claude, e la scheda Le tue AI diceva ancora non collegate: il lavoro della mia AI e' comparso solo
   qualche secondo dopo". LA CAUSA: la scheda si disegnava con quello che il telefono sapeva in quel momento e si ridisegnava solo DOPO la
   risposta del server (e al rientro nell'app solo se la risposta diceva "usata"): nel frattempo restava il disegno di prima, quello di
   quando il collegamento non c'era. Adesso il controllo ha uno stato (PNT.inCorso, PNT.risposto): finche' il server non ha risposto per
   questa chiave la scheda mostra il lavoro gia' salvato sul telefono, se c'e', oppure "Controllo il collegamento..."; si ridisegna subito
   quando torni dal collegamento (pntRidisegna) e di nuovo appena arriva la risposta. "Non ancora usato" compare solo dopo la risposta. */
PNT.inCorso = null; PNT.risposto = 0; PNT.rispChiave = ''; PNT.errore = false;
function pntRisposto(){ return PNT.risposto > 0 && PNT.rispChiave === pntChiave(); }
function pntInControllo(){ return pntOn() && !pntRisposto() && !PNT.errore; }
async function pntSync(forza){
  if (!pntOn()) return pntVoci();
  if (PNT.inCorso) return PNT.inCorso;
  if (!forza && Date.now() - PNT.at < 120000 && pntRisposto()) return pntVoci();
  PNT.at = Date.now();
  const chiave = pntChiave();
  PNT.inCorso = (async function(){
    try{
      const r = await frApi('GET', '/api/focuslock/ponte/log?chiave=' + encodeURIComponent(chiave) + '&giorni=30');
      if (pntChiave() === chiave){
        if (r && Array.isArray(r.voci)) localStorage.setItem(PNT_LOG, JSON.stringify(r.voci));
        if (r && +r.usatoAt) localStorage.setItem('fl_ponte_usato', String(+r.usatoAt));
        PNT.risposto = Date.now(); PNT.rispChiave = chiave; PNT.errore = false;
      }
    }catch(_){ if (pntChiave() === chiave) PNT.errore = true; }
    finally{ PNT.inCorso = null; }
    return pntVoci();
  })();
  return PNT.inCorso;
}
/** Ridisegna quello che mostra lo stato del collegamento: la scheda della Timeline, le schede della partita e, se serve, il foglio
    dell'albero maestro (che dice Collegata o Da aggiungere). */
function pntRidisegna(foglio){
  try{ if (typeof TL !== 'undefined' && TL.tab === 'ai' && typeof tlPaint === 'function') tlPaint(); }catch(_){ }
  try{ if (typeof pscRidisegna === 'function') pscRidisegna(); }catch(_){ }
  try{ const w = document.getElementById('amSheet'); if (foglio && w && !w.hidden && typeof amApri === 'function') amApri(true); }catch(_){ }
}
/** Controlla adesso e ridisegna due volte: subito (con "Controllo il collegamento..." se non c'e' niente di salvato) e alla risposta. */
function pntControllaOra(){
  if (!pntOn()) return Promise.resolve(pntVoci());
  const prima = pntUsato();
  PNT.risposto = 0; PNT.errore = false;
  const p = pntSync(true);
  pntRidisegna(false);
  return Promise.resolve(p).then(function(v){ pntRidisegna(pntUsato() !== prima); return v; });
}
function pntDelGiorno(off){
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const da = d0.getTime() - (off || 0) * 86400000, a = da + 86400000;
  return pntVoci().filter(function(v){ return v && v.at >= da && v.at < a; });
}
function pntMinTxt(m){ m = Math.round(m || 0); if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti'; const h = Math.floor(m / 60), r = m % 60; return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + ' minuti' : ''); }
/* per il tuo agente personale: quello che le altre AI hanno scritto, oggi e ieri */
function pntBriefTesto(){
  if (!pntOn()) return '';
  const riga = function(v){ return '- [' + v.fonte + (v.minuti ? ', ' + v.minuti + ' min' : '') + (v.inRotta === false ? ', fuori rotta' : (v.inRotta === true ? ', in rotta' : '')) + '] ' + v.testo; };
  const oggi = pntDelGiorno(0), ieri = pntDelGiorno(1);
  if (!oggi.length && !ieri.length) return '';
  let t = 'SU COSA HA LAVORATO CON LE ALTRE AI (lo scrivono loro con il ponte, e conta come lavoro vero: usalo per capire quante ore ha dato al sogno e se erano in rotta):';
  if (oggi.length) t += '\nOggi:\n' + oggi.slice(0, 20).map(riga).join('\n');
  if (ieri.length) t += '\nIeri:\n' + ieri.slice(0, 10).map(riga).join('\n');
  return t;
}
/* le righe della revisione della sera: [emoji, frase] */
function pntRigheSera(){
  const l = pntDelGiorno(0); if (!l.length) return [];
  const min = l.reduce(function(a, v){ return a + (v.minuti || 0); }, 0), fuori = l.filter(function(v){ return v.inRotta === false; }).length;
  const f = (l.length === 1 ? 'Con le tue AI oggi hai fatto 1 lavoro' : 'Con le tue AI oggi hai fatto ' + l.length + ' lavori') + (min ? ', per ' + pntMinTxt(min) : '') + (fuori ? ': ' + (fuori === 1 ? '1 era fuori rotta' : fuori + ' erano fuori rotta') : '') + '.';
  return [['💬', f]];
}
/* LA SCHEDA NELLA TIMELINE
   0.9.353, Andrea: "via il riquadro del copia-incolla: nessuno sta li' a copiare". Non collegate: una riga, il pulsante che apre il
   foglio del collegamento (amApri, albero-maestro.js) e i passi dietro la (i). Collegate: il resoconto del giorno. Sotto, in tutti e
   due i casi, quanto ci metti a decidere: il tempo per scrivere alla tua AI (cloAiMedia, collo.js) e quello fra un messaggio e
   l'altro (dcsTraDecisioni e dcsDurata, decisioni.js), come nella scheda Decisioni. */
function pntSchedaHtml(off){
  const e = (typeof esc === 'function') ? esc : function(s){ return String(s == null ? '' : s); };
  const info = function(on){ return '<button type="button" class="pnt-i" onclick="pntPassiApri(' + (on ? 'true' : 'false') + ')" aria-label="' + (on ? 'Così la tua AI scrive qui' : 'Come colleghi le tue AI') + '">i</button>'; };
  let testa;
  if (!pntOn()){
    testa = '<div class="pnt-vuoto"><span aria-hidden="true">💬</span><b>Le tue AI non sono ancora collegate</b>'
      + '<p>Collegale e qui vedi su cosa hai lavorato con loro.' + info(false) + '</p>'
      + '<button type="button" class="cta" onclick="pntCollegaApri()">Collega le tue AI</button></div>';
  } else {
    const l = pntDelGiorno(off);
    const min = l.reduce(function(a, v){ return a + (v.minuti || 0); }, 0);
    /* 0.9.397: niente di salvato per questo giorno e il server non ha ancora risposto: si controlla, e la scheda lo dice */
    const controllo = !l.length && pntInControllo();
    if (controllo && !PNT.inCorso) Promise.resolve(pntSync(true)).then(function(){ pntRidisegna(true); });
    testa = (min ? '<p class="tlr-arr"><small>Lavoro segnato dalle tue AI</small><b>' + e(pntMinTxt(min)) + '</b></p>' : '')
      + (controllo ? '<p class="pnt-nulla pnt-controllo" role="status"><i class="pnt-rot" aria-hidden="true"></i>Controllo il collegamento…</p>'
      : (!l.length && PNT.errore && !pntRisposto()) ? '<p class="pnt-nulla">Non riesco a controllare il collegamento: serve la rete.</p><button type="button" class="pnt-come" onclick="pntControllaOra()">Riprova</button>'
      : l.length ? '<div class="prc-lista">' + l.map(function(v){
          return '<div class="prc-r"><span>💬</span><p>' + e(v.testo) + '<small>' + e(v.fonte) + ' · ' + new Date(v.at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) + (v.minuti ? ' · ' + pntMinTxt(v.minuti) : '') + '</small></p>'
            /* in rotta e' blu: il verde resta per un miglioramento */
            + (v.inRotta === false ? '<i class="su">Fuori rotta</i>' : (v.inRotta === true ? '<i class="pnt-ok">In rotta</i>' : '')) + '</div>';
        }).join('') + '</div>'
        /* 0.9.367, Andrea: "non ci deve essere quel pannello: piuttosto un testo che apre il popover del collegamento"
           0.9.371: se l'AI non ha mai usato il collegamento lo dice, e porta a come aggiungerlo; se l'ha usato, si sceglie a che ora la
           tua AI scrive il resoconto della sera e si copia il messaggio con quell'ora dentro */
        : (pntUsato()
          ? '<p class="pnt-nulla">La tua AI è collegata. Per questo giorno non ha ancora scritto.</p>'
            /* 0.9.382, Andrea: "non voglio il pulsante Copia il messaggio della sera se l'utente ha il Premium e ha collegato la sua AI:
               quello serve a chi non ha il Premium e vuole farlo a mano" */
            + (pntPremium() ? '' : '<div class="pnt-ora"><span>Il resoconto della sera alle</span><input type="time" value="' + pntOraSera() + '" onchange="pntOraSeraMetti(this.value)" aria-label="Ora del resoconto della sera"></div>'
            + '<button type="button" class="pnt-come" onclick="pntCopia(pntRmSera(),\'Messaggio della sera copiato: incollalo in un’attività della tua AI\')">Copia il messaggio della sera</button>')
          : '<p class="pnt-nulla">Il collegamento è pronto, ma la tua AI non l’ha ancora usato.</p><button type="button" class="pnt-come" onclick="if(typeof amPonteInfo===\'function\')amPonteInfo()">Aggiungilo alla tua AI<svg viewBox="0 0 8 12" width="8" height="12" aria-hidden="true" style="margin-left:6px;vertical-align:0"><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" d="M1.5 1 6.5 6 1.5 11"/></svg></button>'));
  }
  return testa + pntDecidereHtml(off);
}
/** Quanto ci metti a decidere: le due misure della scheda Decisioni della Timeline. */
function pntDecidereHtml(off){
  const dur = (typeof dcsDurata === 'function') ? dcsDurata : function(s){ s = Math.round(s); return s < 60 ? s + ' secondi' : Math.round(s / 60) + ' minuti'; };
  const ai = (typeof cloAiMedia === 'function') ? cloAiMedia() : null;
  /* gli orari dei messaggi restano due giorni (collo.js): piu' indietro non si misura */
  const misura = (off || 0) <= 1;
  let tra = null;
  if (misura){
    try{
      const d0 = new Date(); d0.setHours(0, 0, 0, 0);
      const da = d0.getTime() - (off || 0) * 86400000, a = da + 86400000;
      const l = (typeof cloMessaggi === 'function' ? cloMessaggi() : []).filter(function(t){ return t >= da && t < a; }).map(function(t){ return { at: t }; });
      tra = (typeof dcsTraDecisioni === 'function') ? dcsTraDecisioni(l) : null;
    }catch(_){ tra = null; }
  }
  return '<div class="pnt-dec"><p class="pnt-dec-t">Quanto ci metti a decidere</p><div class="tld-ins">'
    + '<div><span aria-hidden="true">💬</span><b>' + (ai ? dur(ai) : 'Non ancora misurato') + '</b><small>per scrivere un messaggio alla tua AI</small></div>'
    + '<div><span aria-hidden="true">⏱️</span><b>' + (tra !== null ? dur(tra) : (misura ? 'Servono due messaggi' : 'Non misurato')) + '</b><small>fra un messaggio e l’altro alla tua AI</small></div>'
    + '</div></div>';
}
/** Il pulsante "Collega le tue AI": il foglio del collegamento; quando si chiude, la scheda si ridisegna con quello che e' cambiato. */
async function pntCollegaApri(){
  if (typeof amApri !== 'function') return;
  await amApri();
  const w = document.getElementById('amSheet');
  if (!w || w.__pntGuarda || typeof MutationObserver === 'undefined') return;
  w.__pntGuarda = true;
  /* 0.9.397: chiuso il foglio, la scheda si ridisegna SUBITO (con il collegamento nuovo: "Controllo il collegamento...") e di nuovo alla
     risposta del server. Prima restava il disegno di prima, "non sono ancora collegate", finche' il server non rispondeva */
  new MutationObserver(function(){
    if (!w.hidden) return;
    pntControllaOra();
  }).observe(w, { attributes: true, attributeFilter: ['hidden'] });
}
/** I passi dietro la (i): come si collegano le AI, oppure, gia' collegate, come scrivono qui. */
function pntPassiApri(on){
  if (typeof inSheet !== 'function') return;
  const r = on ? [
      ['🔌', 'Il collegamento è acceso', 'Le tue AI possono scrivere qui quando finite un lavoro.'],
      ['💬', 'Chiedi il resoconto', 'Alla fine scrivi alla tua AI "Registra su DreamMap quello che abbiamo fatto".'],
      ['🌙', 'Fai partire il resoconto ogni sera', 'Nel foglio del collegamento tocca "Imposta il resoconto della sera".']
    ] : [
      ['🔌', 'Accendi il collegamento', 'Tocca "Collega le tue AI" e accendi "Fai sapere al Genio cosa fai".'],
      ['📋', 'Dai il collegamento alla tua AI', 'Copialo e aggiungilo alla tua AI come connettore.'],
      ['✍️', 'Lavora come sempre', 'Quando finite, la tua AI scrive qui su cosa avete lavorato.']
    ];
  inSheet('<div class="en-foglio pnt-passi"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<h3>' + (on ? 'Così la tua AI scrive qui' : 'Come colleghi le tue AI') + '</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe(r) : '')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()' + (on ? '' : ';pntCollegaApri()') + '">' + (on ? 'Ho capito' : 'Collega le tue AI') + '</button></div>');
}
/* 0.9.382, Andrea: "ho collegato DreamMap a Claude, eppure la scheda Le tue AI diceva da aggiungere: solo dopo si e' aggiornata". Il
   controllo col server era al massimo uno ogni due minuti: finche' la tua AI non risulta usata, al rientro nell'app si controlla subito
   e la scheda si ridisegna appena arriva la risposta */
function pntPremium(){ try{ return (typeof cvPremium === 'function' && cvPremium()) || (typeof orPremium === 'function' && orPremium()); }catch(_){ return false; } }
/* 0.9.397: al rientro (di solito dalla tua AI, dopo averla collegata) la scheda dice subito che sta controllando e si ridisegna alla
   risposta, qualunque cosa dica: prima si ridisegnava solo se la risposta era "usata" */
function pntControllaSubito(){
  if (!pntOn() || pntUsato()) return Promise.resolve(pntVoci());
  return pntControllaOra();
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden){ try{ if (!pntUsato()) pntControllaSubito(); else Promise.resolve(pntSync(false)).then(function(){ pntRidisegna(false); }); pntPianoManda(); }catch(_){ } } });
setTimeout(function(){ try{ pntSync(false); pntPianoManda(); }catch(_){ } }, 6000);
(function(){
  const st = document.createElement('style');
  /* 0.9.353: la scheda della Timeline sta nel pannello scuro (.pst.tlr): testo chiaro fisso nei due temi. Riga -> pulsante 32px,
     blocco -> blocco 30px. La (i) e' quella delle altre schede scure (.am-lg-i, friends.js) */
  st.textContent = '.pnt-vuoto{text-align:center;padding:14px 6px 0}.pnt-vuoto span{display:block;font-size:44px;line-height:1}.pnt-vuoto b{display:block;margin:14px 0 8px;font:800 18px var(--font-display);color:#fff}.pnt-vuoto p{margin:0 0 32px;font:500 14.5px/1.45 var(--font-body);color:#C8EFFD}'
    + '.pnt-i{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:8px;padding:0;vertical-align:-1px;border:1.5px solid rgba(200,239,253,.7);border-radius:50%;background:none;color:#C8EFFD;font:800 12.5px/1 var(--font-body);cursor:pointer}'
    + '.pnt-nulla{margin:0;text-align:center;font:500 14px/1.5 var(--font-body);color:#C8EFFD}'
    + '.pnt-controllo{display:flex;align-items:center;justify-content:center;gap:10px}.pnt-rot{flex:none;width:16px;height:16px;border-radius:50%;border:2px solid rgba(200,239,253,.35);border-top-color:#C8EFFD;animation:pntRot .9s linear infinite}@keyframes pntRot{to{transform:rotate(360deg)}}'
    + '.pnt-come{display:block;margin:14px auto 0;padding:8px 14px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);cursor:pointer;text-decoration:underline;text-underline-offset:3px}'
    + '.pnt-ora{display:flex;align-items:center;justify-content:center;gap:10px;margin:22px 0 0;font:600 14px var(--font-body);color:#C8EFFD}.pnt-ora input{height:40px;padding:0 12px;border:1.5px solid rgba(140,198,255,.45);border-radius:12px;background:rgba(255,255,255,.06);color:#fff;font:800 15px var(--font-body);color-scheme:dark}'
    + '.prc-r i.pnt-ok{background:#C8EFFD;color:#001E44}'
    + '.pnt-dec{margin-top:12px}.pnt-dec-t{margin:0 0 26px;text-align:center;font:800 15px var(--font-display);color:#fff}'
    + '.pnt-passi-e{display:block;margin-top:8px;font-size:40px;line-height:1}.pnt-passi h3{margin-top:12px!important}';
  document.head.appendChild(st);
})();
