/* ===========================================================================================
   SCEGLI L'ICONA (0.9.393): UN componente solo per scegliere un'icona, o una propria immagine.
   0.9.393, Andrea: "voglio la stessa liberta' della pagina Il tuo sogno: le icone, Mostra altre con tante emoji e la casella
   ...o scrivine una dalla tastiera con Usa. Deve essere sempre libero l'utente di poter scegliere se usare un'icona oppure
   un'immagine". Era il selettore dell'icona del sogno (costruisci.js); adesso lo stesso pezzo serve:
     - la pagina "Il tuo sogno" (costruisci.js), che resta identica: niente pulsante dell'immagine, come aveva chiesto Andrea;
     - "Modifica la card" delle sessioni (preset.js, scheda Aspetto), con "Usa una tua immagine";
     - le card dei luoghi della scheda Ambiente (partita-schede.js): emoji OPPURE la foto del luogo.

   Uso:
     sciHtml('chi', { ora: '🎯', img: '' | url, base: [...], altre: [...], scegli: function(e){}, foto: function(){} | null,
                      ridisegna: function(){}, bordo: true|false, riga: false })
   riga: false toglie il pulsante "Usa una tua immagine" sotto alle icone, dove la pagina ha gia' il suo (il luogo: la foto in alto).
   Il foglio che lo usa ridisegna se stesso (ridisegna) quando si tocca "Mostra altre"; scegli() riceve l'emoji toccata o scritta.
   Prefisso sci- (le classi cst-icone, cst-ico, cst-altre, emo-own sono quelle del sogno: lo stesso aspetto ovunque).
   =========================================================================================== */
const SCI_BASE = ['🎯', '🚀', '✈️', '🎓', '🏋️', '🎵', '💎', '⛵', '💰', '🏠', '📚', '🧘', '🎬', '🌍', '💻', '❤️', '🛒', '🌟'];
const SCI_ALTRE = ['🏆', '🎨', '📷', '🎤', '🎸', '🎹', '⚽', '🏀', '🥇', '🏃', '🚴', '🏊', '🧗', '🏔️', '🏝️', '🗺️', '🚗', '🏍️', '🛥️', '🏡', '🏢', '🏪', '🛍️', '📈', '💼', '🤝', '🧠', '📖', '✍️', '🎙️', '📱', '🧪', '🩺', '⚖️', '🍳', '🌱', '🐶', '👶', '💍', '👨‍👩‍👧', '🙏', '☀️', '🌙', '🔥', '⭐', '🦁', '🕊️', '🎁',
  '🛋️', '🛏️', '🪴', '🏫', '🏥', '☕', '🍽️', '🌳', '🏖️', '⛪', '🎮', '🎧', '📝', '⏰', '🧩', '🍎', '💪', '🚶'];
const SCI = {};
const SCI_FOTO_SVG = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="12" cy="12.5" r="3.5"/><path d="M8.5 5l1.5-2h4l1.5 2"/></svg>';

function sciEsc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
/** La prima emoji di quello che si scrive, o '' se non e' un'emoji (una lettera non e' un'icona). */
function sciPrimaEmoji(v){
  v = String(v || '').trim(); if (!v) return '';
  const seg = (typeof Intl !== 'undefined' && Intl.Segmenter) ? Array.from(new Intl.Segmenter('it', { granularity: 'grapheme' }).segment(v)).map(function(s){ return s.segment; }) : Array.from(v);
  const e = seg[0] || '';
  return /\p{Extended_Pictographic}|\p{Emoji_Presentation}/u.test(e) ? e : '';
}
/** "Mostra altre" chiuso: lo si chiama quando si apre di nuovo la pagina. */
function sciChiudi(chi){ if (SCI[chi]) SCI[chi].tutte = false; }
function sciTutte(chi){ return !!(SCI[chi] && SCI[chi].tutte); }

function sciHtml(chi, o){
  o = o || {};
  const s = SCI[chi] = Object.assign(SCI[chi] || { tutte: false }, { scegli: o.scegli, foto: o.foto || null, ridisegna: o.ridisegna });
  const ora = o.ora || '', img = o.img || '';
  const base = (o.base || SCI_BASE).slice();
  let l = base.filter(function(e, i){ return base.indexOf(e) === i; });
  if (ora && l.indexOf(ora) < 0) l = [ora].concat(l);
  if (s.tutte) l = l.concat((o.altre || SCI_ALTRE).filter(function(e){ return l.indexOf(e) < 0; }));
  const a = sciEsc(chi);
  return '<div class="cst-icone sci-griglia' + (o.bordo ? ' sci-bordo' : '') + '" data-sci="' + a + '">'
    + (img ? '<button type="button" class="cst-ico on" aria-label="La tua immagine"' + (s.foto ? ' onclick="sciFoto(\'' + a + '\')"' : '') + '><img class="cst-ico-img" src="' + sciEsc(img) + '" alt=""></button>' : '')
    + l.map(function(e){ return '<button type="button" class="cst-ico' + (ora === e && !img ? ' on' : '') + '" data-e="' + sciEsc(e) + '" onclick="sciScegli(\'' + a + '\',this.getAttribute(\'data-e\'))">' + e + '</button>'; }).join('') + '</div>'
    /* 0.9.380, Andrea: "la stessa casella dei programmi, con il pulsante Usa: abitua l'utente a uno schema solo" */
    + (s.tutte ? '<div class="emo-own cst-emo-own"><input placeholder="…o scrivine una dalla tastiera" maxlength="4" data-no-mic data-no-dettatura enterkeyhint="done" onkeydown="if(event.key===\'Enter\'){event.preventDefault();sciScritta(\'' + a + '\',this);}"><button type="button" class="cta" style="padding:10px 14px;width:auto" onclick="sciScritta(\'' + a + '\',this.previousElementSibling)">Usa</button></div>' : '')
    + '<button type="button" class="cst-altre" onclick="sciAltre(\'' + a + '\')">' + (s.tutte ? 'Mostra meno' : 'Mostra altre') + '</button>'
    /* l'icona OPPURE un'immagine: dove la pagina lo permette, la scelta dell'immagine sta qui, accanto alle icone */
    + (s.foto && o.riga !== false ? '<button type="button" class="sci-foto" onclick="sciFoto(\'' + a + '\')">' + SCI_FOTO_SVG + '<span>' + (img ? 'Cambia la tua immagine' : 'Usa una tua immagine') + '</span></button>' : '');
}
function sciScegli(chi, e){ const s = SCI[chi]; if (!s || !e || typeof s.scegli !== 'function') return; try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ } s.scegli(e); }
function sciScritta(chi, inp){
  const e = sciPrimaEmoji(inp && inp.value);
  if (!e){ try{ if (inp && inp.value) toast('Scrivi un’emoji, per esempio 🏝️'); }catch(_){ } if (inp) try{ inp.focus(); }catch(_){ } return; }
  sciScegli(chi, e);
}
function sciAltre(chi){ const s = SCI[chi]; if (!s) return; s.tutte = !s.tutte; if (typeof s.ridisegna === 'function') s.ridisegna(); }
function sciFoto(chi){ const s = SCI[chi]; if (s && typeof s.foto === 'function') s.foto(); }

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* sui fogli bianchi (Modifica la card, il luogo) il tondo bianco non si vedrebbe: bordo sottile e l'anello blu su quella scelta */
  '.sci-bordo .cst-ico{border:1.5px solid var(--line,#DCE6F2);background:var(--card,#fff)}'
  + '.sci-bordo .cst-ico.on{border-color:#0075E3;box-shadow:0 0 0 2px rgba(0,117,227,.25)}'
  + 'body.dark .sci-bordo .cst-ico{border-color:#22345A;background:#12203A}'
  + '.sci-foto{display:flex;align-items:center;justify-content:center;gap:8px;margin:12px auto 0;border:1.5px solid var(--line,#DCE6F2);border-radius:99px;background:transparent;padding:10px 18px;font:700 13px var(--font-body);color:var(--navy,#001E44);cursor:pointer}'
  + 'body.dark .sci-foto{color:#fff;border-color:#22345A}';
  document.head.appendChild(st); })();
