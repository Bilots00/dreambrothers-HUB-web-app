/* ===========================================================================================
   L'IMMAGINE DI SE': IL QUIZ "COME TI VEDI" (0.9.391, BUG-124, Andrea)

   Andrea: "nella slide Come ti vedi oggi compare il risultato della lettura, chi sto diventando: ma chi sto diventando e' diverso
   da come mi vedo. Dillo con parole tue non sembra un pulsante, e Dimmi la verita': come ti vedi oggi? non e' un quiz e non e'
   nemmeno la domanda giusta. Voglio un quiz vero, le domande migliori per misurare l'immagine di se', come farebbe Maxwell
   Maltz. Il Genio fa da specchio: non puo' essere in disaccordo con me. Prima capisce come mi vedo, poi le abitudini, poi
   trova chi sto diventando."

   Due cose distinte, da non confondere mai piu':
   · L'IMMAGINE DI SE' (qui): come l'utente si vede. Un archetipo, scelto dalle sue risposte. Il Genio lo mostra e basta:
     e' uno specchio, non un giudizio, e non lo contraddice.
   · LA TRAIETTORIA (oracle.js, il profilo della lettura): chi sta diventando se non cambia niente. Sta nella slide
     "Stai diventando" e nel risultato della lettura, mai nella slide "Come ti vedi oggi".

   Il quiz. Dodici domande (nove fino alla 0.9.401), una per schermata. Le domande sono nostre, per uomini e donne (nessun aggettivo che cambia col sesso), e
   toccano i punti in cui l'immagine di se' si vede davvero: come reagisci a un errore, cosa fai quando una cosa va bene, cosa pensi
   di meritare, come ti racconti, chi decide la tua giornata, come ti immagini fra un anno, cosa ti frena, come prendi una critica,
   cosa fai con una promessa fatta a te stesso. Se il sogno e' un'impresa (si vende qualcosa), tre domande cambiano e parlano di
   prezzo, rischio e clienti.

   0.9.393, Andrea: "le domande hanno sei opzioni in colonna come una lista della spesa, con la nuvoletta a testo piccolo: e'
   overwhelming. Deve essere come le domande della Stagione 1, Episodio 6 (In quale momento della giornata hai la testa piu' lucida?):
   nuvoletta con il testo GRANDE e una parte in blu, sotto il pannello bianco con le carte a due colonne, emoji grande e testo breve in
   grassetto. Al massimo 4 opzioni visibili. Lo sfondo sfocato dietro, come nelle altre domande. Il Genio si rimpicciolisce solo se sotto
   c'e' tanto contenuto". Adesso:
   · le risposte sono le carte delle domande della Stagione 1, la STESSA funzione (flCarteHtml, domande.js, usata anche da episodi.js):
     testo breve, e dove c'e' altro da dire la (i) sulla carta (o il tenere premuto) apre la descrizione;
   · QUATTRO risposte per domanda, non sei. I sei archetipi restano tutti: ognuno ha la sua risposta in sei domande su nove (la tabella
     e' bilanciata, controllata da tools/test-quiz-come-ti-vedi-393.js), e le tre domande per l'impresa toccano gli stessi archetipi di
     quelle che sostituiscono. Se una domanda avesse piu' di quattro carte, il pannello scorre e sfuma dove si taglia;
   · la scena e' quella delle domande degli episodi: testo grande, Genio come nella S1E6, sfondo sfocato;
   · la nuvoletta iniziale (cinque righe) e' spezzata in quattro nuvolette brevi, tocca per continuare, ognuna con la sua parola in blu.

   Ogni risposta ha un archetipo principale (2 punti) e a volte uno vicino (1 punto). Vince chi ha piu' punti; a parita',
   chi ha piu' risposte principali; poi l'ordine della lista.

   UNA funzione sola per l'archetipo, letta ovunque: idsArchetipo(). La scheda Identita', la lettura del Genio e il corpo che
   va al server la chiamano, e nessuno ricalcola per conto suo.
   =========================================================================================== */

const IDS_KEY = 'fl_immagine_di_se';

/* GLI ARCHETIPI. m/f: il nome per un uomo e per una donna (gnSesso); frase: come si descriverebbe lui stesso, in prima persona
   (lo specchio: la frase che l'utente potrebbe dire di se'); forza: la cosa buona che il Genio vede e da cui parte.
   0.9.402 BUG-213, Andrea: "Il Costruttore con una frase sola non rappresenta l'utente: il quiz va fatto molto meglio e piu' dettagliato".
   Ogni archetipo ha anche tre tratti (due forze e il suo punto debole, detti senza aggettivi che cambiano col sesso) e un ritratto: due
   frasi vere, alla seconda persona, su come lavori e su dove ti incagli. Nella frase in prima persona niente due punti a meta' riga. */
const IDS_ARCHETIPI = [
  { id: 'cos', ico: '🔨', m: 'Il Costruttore', f: 'La Costruttrice', forza: 'la costanza',
    /* 0.9.403 BUG-299: "Accontentarsi di quello che funziona" suonava come un giudizio e cozzava con il lato da Esigente: e' il rischio del
       ritratto (restare nel lavoro di tutti i giorni), detto in tre parole */
    tratti: ['La costanza', 'Il senso pratico', 'Evitare i rischi'],
    frase: 'Costruisco un pezzo alla volta. Quando sbaglio, sistemo e vado avanti. Un errore è una cosa che è successa, non quello che sono.',
    ritratto: 'Vai avanti un passo alla volta e un errore non ti ferma. Il rischio è restare nel lavoro di tutti i giorni senza alzare mai l\'asticella.' },
  { id: 'sog', ico: '🌄', m: 'Il Sognatore prudente', f: 'La Sognatrice prudente', forza: 'la visione',
    tratti: ['La visione', 'La pazienza', 'La paura di sbagliare'],
    frase: 'Vedo chiaro dove voglio arrivare. Aspetto il momento giusto per partire, perché sbagliare mi pesa più che aspettare.',
    ritratto: 'Sai dove vuoi arrivare e lo vedi meglio di tanti altri. Ma aspetti un momento perfetto che non arriva, e intanto il sogno resta fermo.' },
  { id: 'esi', ico: '🎯', m: 'L\'Esigente', f: 'L\'Esigente', forza: 'la cura nei dettagli',
    tratti: ['La cura nei dettagli', 'L\'impegno', 'La fatica a perdonarsi'],
    frase: 'Pretendo tanto da me e do sempre il massimo. Quando una cosa non viene perfetta, faccio fatica a perdonarmela.',
    ritratto: 'Dai il massimo in quello che fai, e si vede. Ma per te niente è mai abbastanza, e un piccolo errore pesa più di dieci cose fatte bene.' },
  { id: 'cus', ico: '🤝', m: 'Il Custode', f: 'La Custode', forza: 'la generosità',
    tratti: ['La generosità', 'L\'affidabilità', 'Mettere il sogno in fondo alla fila'],
    frase: 'Ci sono sempre per gli altri. Per i miei sogni resta il tempo che avanza, e spesso non ne avanza.',
    ritratto: 'Le persone sanno di poter contare su di te, sempre. Il tuo sogno però arriva per ultimo, e il suo tempo finisce prima di cominciare.' },
  { id: 'esp', ico: '🧭', m: 'L\'Esploratore', f: 'L\'Esploratrice', forza: 'la curiosità',
    tratti: ['La curiosità', 'L\'entusiasmo', 'Cambiare strada a metà'],
    frase: 'Ho mille idee e la voglia di provarle tutte. Parto con un entusiasmo enorme, poi arriva sempre qualcosa di nuovo.',
    ritratto: 'Ti accendi davanti a ogni idea nuova e impari in fretta. Ma passi alla prossima prima di finire quella di adesso, e i risultati non arrivano.' },
  { id: 'tal', ico: '💎', m: 'Il Talento nascosto', f: 'Il Talento nascosto', forza: 'quello che hai dentro e non hai ancora mostrato',
    tratti: ['Le capacità che non mostri', 'La sensibilità', 'Il dubbio su quanto vali'],
    frase: 'Sento di valere più di quello che si vede. Non l\'ho ancora dimostrato, prima di tutto a me.',
    ritratto: 'Dentro di te c\'è più di quello che fai vedere, e lo senti. Ma aspetti di sentirti all\'altezza prima di provarci, e così nessuno lo scopre.' }
];

/* LE DOMANDE. t: la domanda nella nuvoletta, breve (due righe a testo grande) e con la parte chiave fra *asterischi* (in blu).
   r: le quattro risposte, nell'ordine in cui si vedono (mescolato a mano: una risposta giusta non c'e'). Di ogni risposta: e l'emoji,
   t il testo breve della carta, s (se serve) la frase intera, che si legge nella (i) e va al Genio; a l'archetipo principale,
   p quelli vicini (un punto).
   Chi c'e' in ogni domanda (sei archetipi, ognuno in otto domande su dodici):
     d1 esi cos tal esp · d2 tal esp esi sog · d3 cus cos tal esi · d4 sog cus tal esi · d5 cus cos esp sog
     d6 sog cos esp tal · d7 esi cos cus esp · d8 tal cos cus sog · d9 esp esi cus sog
     d10 esi cus esp tal · d11 cos sog esp tal · d12 cos sog esi cus
   0.9.402 BUG-213: tre domande in piu' (d10-d12: il complimento, l'ora libera, l'aiuto). Le prime nove restano com'erano, risposta per
   risposta nello stesso ordine: chi ha fatto il quiz prima ha lo stesso archetipo di allora (idsArchetipo, v < 3: bastano le nove). */
const IDS_DOMANDE = [
  { id: 'd1', t: 'Sbagli una cosa importante. *Cosa ti dici*?', r: [
    { e: '🔁', t: 'Ci rimugino per giorni', s: 'Me lo ripeto per giorni e non lo mando giù.', a: 'esi' },
    { e: '🔧', t: 'Vediamo cosa sistemare', s: 'Ho sbagliato, va bene. Guardo cosa sistemare e vado avanti.', a: 'cos' },
    { e: '🙈', t: 'Non era cosa per me', s: 'Lo sapevo che non era una cosa per me.', a: 'tal', p: { sog: 1 } },
    { e: '🎲', t: 'Passo a un\'altra cosa', s: 'Passo ad altro, c\'è sempre qualcosa di nuovo da provare.', a: 'esp' } ] },
  { id: 'd2', t: 'Una cosa ti va *meglio del previsto*. E dopo?', r: [
    { e: '🤔', t: 'Penso che sia fortuna', a: 'tal' },
    { e: '🎉', t: 'Comincio un progetto nuovo', s: 'Mi entusiasmo e comincio subito un progetto nuovo.', a: 'esp' },
    { e: '🔍', t: 'Cerco cosa migliorare', a: 'esi' },
    { e: '😬', t: 'Ho paura che non duri', a: 'sog' } ] },
  { id: 'd3', t: 'Quanto pensi di *meritare* la vita del tuo sogno?', r: [
    { e: '⚖️', t: 'Prima gli altri, poi io', a: 'cus' },
    { e: '✅', t: 'La merito, se la costruisco', a: 'cos' },
    { e: '🌥️', t: 'Forse un giorno', s: 'Forse un giorno, quando sarò all\'altezza.', a: 'tal', p: { sog: 1 } },
    { e: '🏆', t: 'Solo se è tutto perfetto', s: 'La merito solo se faccio tutto alla perfezione.', a: 'esi' } ] },
  { id: 'd4', t: 'Se dovessi *raccontarti in una frase*, cosa diresti?', r: [
    { e: '💭', t: 'Aspetto il momento giusto', s: 'Ho grandi idee e aspetto il momento giusto.', a: 'sog' },
    { e: '🤝', t: 'Ci sono per chi ha bisogno', a: 'cus' },
    { e: '💎', t: 'Valgo più di quel che mostro', s: 'Valgo più di quello che faccio vedere.', a: 'tal' },
    { e: '🎯', t: 'Pretendo molto da me', s: 'Pretendo molto da me, forse troppo.', a: 'esi' } ] },
  { id: 'd5', t: 'Chi decide *come va la tua giornata*, di solito?', r: [
    { e: '📲', t: 'Gli altri', s: 'Gli altri, con richieste, messaggi e imprevisti.', a: 'cus' },
    { e: '🗓️', t: 'Io, con un piano', s: 'Io. So cosa fare prima di cominciare.', a: 'cos' },
    { e: '🎢', t: 'Mi lascio portare', s: 'Ogni giorno è diverso e mi lascio portare.', a: 'esp' },
    { e: '⏳', t: 'Aspetto di sentirmi in forma', s: 'Aspetto di sentirmi in forma per fare le cose importanti.', a: 'sog' } ] },
  { id: 'd6', t: 'Pensa a *te fra un anno*. Cosa vedi?', r: [
    { e: '🌅', t: 'Il traguardo, non la strada', s: 'Vedo chiarissimo il traguardo, ma non la strada per arrivarci.', a: 'sog' },
    { e: '🏗️', t: 'I passi fatti, uno a uno', a: 'cos' },
    { e: '🔀', t: 'Tre o quattro vite diverse', s: 'Tre o quattro vite diverse, e mi piacciono tutte.', a: 'esp' },
    { e: '🌫️', t: 'Più o meno come oggi', s: 'Faccio fatica a vedere qualcosa di diverso da oggi.', a: 'tal' } ] },
  { id: 'd7', t: 'Vuoi cominciare una cosa nuova. *Cosa ti frena*?', r: [
    { e: '🎓', t: 'Non saperla fare bene subito', a: 'esi' },
    { e: '🚀', t: 'Niente, se ha senso comincio', a: 'cos' },
    { e: '🧺', t: 'Il tempo tolto agli altri', s: 'Il tempo che toglierei alle persone che contano su di me.', a: 'cus' },
    { e: '🧩', t: 'Le cose già cominciate', s: 'Le altre cose che ho già cominciato e non ho ancora finito.', a: 'esp' } ] },
  { id: 'd8', t: 'Qualcuno *critica* quello che fai. Come reagisci?', r: [
    { e: '💔', t: 'Ci resto male a lungo', a: 'tal', p: { esi: 1 } },
    { e: '🛠️', t: 'Prendo quello che serve', a: 'cos' },
    { e: '🙂', t: 'Dico che ha ragione', s: 'Dico che ha ragione, anche quando non lo penso.', a: 'cus' },
    { e: '🛑', t: 'Forse non era il momento', s: 'Mi convinco che forse non era il momento giusto.', a: 'sog' } ] },
  { id: 'd9', t: 'Ti prometti una cosa *solo per te*. Come va a finire?', r: [
    { e: '✨', t: 'Arriva un\'idea nuova', s: 'Parto fortissimo, poi arriva un\'idea nuova e cambio strada.', a: 'esp' },
    { e: '🧷', t: 'Se salto un giorno, crollo', s: 'La mantengo, ma se salto un giorno mi sento un disastro.', a: 'esi' },
    { e: '🫶', t: 'Salta se qualcuno ha bisogno', s: 'Salta appena qualcuno ha bisogno di me.', a: 'cus' },
    { e: '📅', t: 'La rimando a lunedì', s: 'La rimando a lunedì, poi al mese prossimo.', a: 'sog', p: { tal: 1 } } ] },
  { id: 'd10', t: 'Qualcuno ti fa *un complimento*. Cosa pensi?', r: [
    { e: '🔎', t: 'Vedo solo cosa non va', s: 'Penso subito a cosa poteva venire meglio.', a: 'esi' },
    { e: '🎁', t: 'Il merito è anche degli altri', s: 'Dico che il merito è anche di chi mi ha aiutato.', a: 'cus' },
    { e: '⚡', t: 'Mi carica per la prossima idea', s: 'Mi dà la carica e penso già alla prossima idea.', a: 'esp' },
    { e: '🙊', t: 'Ringrazio, ma non ci credo', s: 'Ringrazio, ma dentro non ci credo davvero.', a: 'tal', p: { esi: 1 } } ] },
  { id: 'd11', t: 'Hai *un\'ora libera* tutta per te. Come la usi?', r: [
    { e: '🧱', t: 'Porto avanti il mio progetto', s: 'La uso per fare un passo sul mio progetto.', a: 'cos' },
    { e: '☁️', t: 'Immagino come sarà', s: 'Immagino come sarà la mia vita quando ce l\'avrò fatta.', a: 'sog' },
    { e: '🧪', t: 'Provo una cosa nuova', s: 'Provo una cosa nuova che ho scoperto da poco.', a: 'esp' },
    { e: '📲', t: 'Finisco sui social', s: 'Finisco sui social o sui video con il telefono in mano, e l\'ora passa.', a: 'tal', p: { sog: 1 } } ] },
  { id: 'd12', t: 'Ti serve *un aiuto* per andare avanti. Cosa fai?', r: [
    { e: '🙋', t: 'Lo chiedo a chi ne sa di più', s: 'Lo chiedo a chi ne sa più di me, senza problemi.', a: 'cos' },
    { e: '🕰️', t: 'Aspetto che si sblocchi', s: 'Aspetto che la situazione si sblocchi da sé.', a: 'sog' },
    { e: '🧗', t: 'Ce la faccio senza nessuno', s: 'Preferisco farcela senza nessuno, così il merito è tutto mio.', a: 'esi' },
    { e: '🤐', t: 'Non voglio disturbare', s: 'Non lo chiedo, non voglio essere un peso per nessuno.', a: 'cus' } ] }
];
/* le domande che c'erano fino alla 0.9.401: chi ha risposto allora (v < 3) ha risposto a queste nove */
const IDS_N_PRIMA = 9;
/* PER I SOGNI DI IMPRESA: tre domande prendono il posto di quelle sul merito, su cosa ti frena e sulla critica, e parlano di soldi,
   rischio e clienti. Gli stessi archetipi della domanda che sostituiscono, un'altra porta per guardarli. */
const IDS_DOMANDE_IMPRESA = {
  d3: { id: 'b3', t: 'Devi dire *il prezzo* di quello che offri. Cosa fai?', r: [
    { e: '📉', t: 'Lo abbasso subito', s: 'Lo abbasso prima ancora che me lo chiedano.', a: 'tal', p: { cus: 1 } },
    { e: '💶', t: 'Lo dico chiaro', s: 'Lo dico chiaro, vale quello che costa.', a: 'cos' },
    { e: '🧮', t: 'Lo ricalcolo dieci volte', s: 'Lo ricalcolo dieci volte e non mi sembra mai giusto.', a: 'esi' },
    { e: '🎁', t: 'Faccio uno sconto', s: 'Faccio uno sconto, così nessuno resta scontento.', a: 'cus' } ] },
  d7: { id: 'b7', t: 'Devi *investire soldi tuoi*. Cosa fai?', r: [
    { e: '📊', t: 'Investo, con un limite', s: 'Investo, con un limite che decido prima.', a: 'cos' },
    { e: '💸', t: 'Investo d\'impulso', s: 'Investo d\'impulso su ogni idea che mi piace.', a: 'esp' },
    { e: '🧾', t: 'Prima studio tutto', a: 'esi' },
    { e: '🏠', t: 'Prima la famiglia', s: 'Quei soldi servono prima alla mia famiglia.', a: 'cus' } ] },
  d8: { id: 'b8', t: 'Chiami *un possibile cliente*. Cosa pensi?', r: [
    { e: '😳', t: 'Ho paura di disturbare', a: 'cus', p: { tal: 1 } },
    { e: '🤝', t: 'Gli spiego come lo aiuto', s: 'Bene, gli spiego come posso aiutarlo.', a: 'cos' },
    { e: '⏳', t: 'Aspetto che si faccia vivo', s: 'Aspetto che sia il cliente a farsi vivo.', a: 'sog' },
    { e: '🪞', t: 'Non sceglierà proprio me', a: 'tal' } ] }
};
/* LE RISPOSTE DATE CON LA 0.9.391-392 (sei per domanda): per chi ha gia' fatto il quiz allora, l'archetipo esce come allora. Per ogni
   domanda l'archetipo di ogni risposta, nell'ordine di allora ('tal+sog': tal principale, sog vicino). */
const IDS_V1 = {
  d1: 'esi cos tal+sog cus sog esp', d2: 'tal esp cos esi sog cus+tal', d3: 'cus cos tal+sog esi sog esp', d4: 'sog cus cos tal esp esi',
  d5: 'cus esi cos esp sog tal+esp', d6: 'sog cos esp tal cus esi', d7: 'esi tal+sog cos cus esp sog', d8: 'tal+esi cos esi cus esp sog',
  d9: 'esp esi cus cos sog+tal tal', b3: 'tal+cus cos esi cus sog esp', b7: 'sog cos tal esp esi cus', b8: 'esi cus+tal cos esp sog tal'
};
function idsV1Risposta(id, i){
  const l = (IDS_V1[id] || '').split(' '), x = l[+i]; if (!x) return null;
  const k = x.split('+'), p = {}; if (k[1]) p[k[1]] = 1;
  return { a: k[0], p: p };
}

/* ---------- le regole (funzioni pure: niente DOM, niente localStorage) ---------- */
/** Il sogno e' un'impresa (un business, un negozio, dei clienti, delle vendite)? Allora tre domande parlano di prezzo, rischio e vendita,
    e il foglio "Perche' parto da qui" ha la pagina sul prezzo.
    0.9.393, Andrea: "la slide sugli affari compare a TUTTI: non ha senso per chi non fa business". Il campo 'lavoro' da solo non basta:
    lo prendono anche "Viaggiare ed essere libero", "Fondare la mia associazione" e ogni sogno scritto a mano ("Ho un sogno unico").
    Decide il sogno detto a parole; un campo scelto che non e' il lavoro (corpo, studio, arte, carriera, presenza) dice di no.
    E "attivita' fisica" o "guadagnare massa" non sono un'impresa. */
function idsImpresa(sogno, campo){
  if (campo && campo !== 'lavoro' && campo !== 'altro') return false;
  const s = String(sogno || '').toLowerCase()
    .replace(/attivit[aà] (fisica|sportiv\w*|all'aperto)/g, '')
    .replace(/guadagn\w* (peso|massa|muscol\w*|chili|forza|fiducia|tempo)/g, '');
  if (/associazion|volontariat|beneficenz|no.?profit/.test(s)) return false;
  return /business|impres|aziend|attivit[aà]|negozio|e-?commerce|\bshop|startup|clienti|vender|vendit|\bbrand\b|agenzia|freelance|partita iva|fattur|guadagn|dropshipping|amazon|etsy|ristorante|locale mio|studio mio|impero|il mio prodotto|prodotto nuovo/.test(s);
}
/** Le dodici domande del quiz, con le tre per l'impresa al loro posto quando serve. */
function idsDomande(impresa){
  return IDS_DOMANDE.map(function(d){ return (impresa && IDS_DOMANDE_IMPRESA[d.id]) ? IDS_DOMANDE_IMPRESA[d.id] : d; });
}
function idsArchetipoDi(id){ return IDS_ARCHETIPI.filter(function(a){ return a.id === id; })[0] || null; }
/** Il nome dell'archetipo per quella persona: "La Costruttrice" per una donna, "Il Costruttore" altrimenti. */
function idsNome(a, sesso){ a = typeof a === 'string' ? idsArchetipoDi(a) : a; if (!a) return ''; return sesso === 'f' ? a.f : a.m; }
/** Il nome dentro una frase: "la Costruttrice", "l'Esploratore". */
function idsNomeInFrase(n){ return String(n || '').replace(/^Il /, 'il ').replace(/^La /, 'la ').replace(/^L['’]/, 'l\''); }
/** La risposta i della domanda d0 (d1..d12), con le domande per l'impresa al loro posto; v = 1 per le risposte date con la 0.9.391-392. */
function idsRisposta(d0, i, impresa, v){
  const d = (impresa && IDS_DOMANDE_IMPRESA[d0.id]) ? IDS_DOMANDE_IMPRESA[d0.id] : d0;
  if (i == null || !isFinite(+i)) return null;
  if (v === 1) return idsV1Risposta(d.id, i);
  return d.r[+i] || null;
}
/**
 * L'ARCHETIPO dalle risposte. risposte = { d1: indice, ... } (le chiavi sono quelle della domanda di sinistra, d1..d12, anche quando
 * al suo posto c'e' la domanda per l'impresa). Torna { id, punti, principali, fatte } o null se non c'e' nessuna risposta valida.
 * v: la versione del quiz con cui si e' risposto (1 = le sei risposte della 0.9.391-392; altrimenti le quattro di adesso).
 */
function idsCalcola(risposte, impresa, v){
  const punti = {}, prin = {};
  IDS_ARCHETIPI.forEach(function(a){ punti[a.id] = 0; prin[a.id] = 0; });
  let fatte = 0;
  IDS_DOMANDE.forEach(function(d0){
    const r = idsRisposta(d0, risposte ? risposte[d0.id] : null, impresa, v); if (!r || !(r.a in punti)) return;
    fatte++;
    punti[r.a] += 2; prin[r.a]++;
    Object.keys(r.p || {}).forEach(function(k){ if (k in punti) punti[k] += r.p[k]; });
  });
  if (!fatte) return null;
  const ordine = IDS_ARCHETIPI.map(function(a){ return a.id; });
  const fila = ordine.slice().sort(function(x, y){ return (punti[y] - punti[x]) || (prin[y] - prin[x]) || (ordine.indexOf(x) - ordine.indexOf(y)); });
  const vince = fila[0];
  /* 0.9.402 BUG-213: il secondo lato, quando pesa davvero (almeno 4 punti e due terzi di quelli di chi vince) */
  const lato = (punti[fila[1]] >= 4 && punti[fila[1]] * 3 >= punti[vince] * 2) ? fila[1] : '';
  return { id: vince, lato: lato, punti: punti, principali: prin, fatte: fatte };
}
/** Il testo senza gli asterischi del blu, per il Genio e per il server. */
function idsPulito(t){ return String(t || '').replace(/\*/g, ''); }
/** Le risposte dette a parole, per il Genio e per il server: [{ domanda, risposta, archetipo }]. La risposta e' la frase intera (s),
    non il testo breve della carta. Per le risposte della 0.9.391-392 si dice la risposta di adesso dello stesso archetipo, se c'e'. */
function idsRisposteTesto(risposte, impresa, v){
  return idsDomande(impresa).map(function(d, k){
    const r0 = idsRisposta(IDS_DOMANDE[k], risposte ? risposte[IDS_DOMANDE[k].id] : null, impresa, v); if (!r0) return null;
    const r = (v === 1) ? d.r.filter(function(x){ return x.a === r0.a; })[0] : r0;
    return r ? { domanda: idsPulito(d.t), risposta: r.s || r.t, archetipo: r0.a } : null;
  }).filter(Boolean);
}

/* ---------- dove si salva, e LA funzione che tutti leggono ---------- */
function idsLeggi(){
  try{ const v = JSON.parse(localStorage.getItem(IDS_KEY) || 'null'); return (v && typeof v === 'object' && v.risposte) ? v : null; }catch(_){ return null; }
}
function idsSalva(risposte, impresa){
  const c = idsCalcola(risposte, impresa); if (!c) return null;
  /* v: 2 dalla 0.9.393 (quattro risposte per domanda); i record senza v o con v: 1 sono quelli della 0.9.391-392.
     v: 3 dalla 0.9.402 (dodici domande); un v: 2 resta valido con le sue nove */
  const rec = { v: 3, risposte: Object.assign({}, risposte), impresa: !!impresa, id: c.id, at: Date.now() };
  try{ localStorage.setItem(IDS_KEY, JSON.stringify(rec)); }catch(_){ return null; }
  return rec;
}
function idsVersione(rec){ return (rec && +rec.v >= 3) ? 3 : ((rec && +rec.v >= 2) ? 2 : 1); }
/** Quante domande deve avere un quiz di quella versione per valere: le dodici di adesso, o le nove di prima. */
function idsNecessarie(v){ return v >= 3 ? IDS_DOMANDE.length : IDS_N_PRIMA; }
/* 0.9.403 BUG-299, Andrea: "i tratti non si contraddicono con il secondo lato. Un lato da Esigente non puo' avere tra i tratti accontentarsi
   di quello che funziona. Vanno rivisti i tratti degli archetipi e delle combinazioni". I tre tratti adesso sono: la prima forza
   dell'archetipo, la prima forza del secondo lato (cosi' il lato si vede), e il punto debole. Il punto debole cambia quando quello
   dell'archetipo andrebbe contro la natura del lato (archetipo>lato). */
const IDS_DEBOLE_COMBO = {
  'cos>esi': 'Pretendere tanto da te',
  'cos>esp': 'Tenere le idee nuove nel cassetto',
  'sog>cos': 'Aspettare il momento giusto',
  'sog>esp': 'Sognare tante strade senza sceglierne una',
  'esi>cos': 'Volere tutto sotto controllo',
  'esp>cos': 'Aprire più cantieri insieme',
  'esp>esi': 'Lasciare a metà quello che non viene perfetto'
};
function idsTratti(a, l){
  const t = (a && a.tratti) || [];
  if (!l || !l.tratti || l.id === a.id) return t.slice(0, 3);
  return [t[0], l.tratti[0], IDS_DEBOLE_COMBO[a.id + '>' + l.id] || t[2]].filter(Boolean);
}
/** Il nome senza l'articolo, per "con un lato da Esploratrice". */
function idsNomeNudo(n){ return String(n || '').replace(/^(Il|La) /, '').replace(/^L['’]/, ''); }
function idsSesso(){ try{ return (typeof gnSesso === 'function') ? gnSesso() : ''; }catch(_){ return ''; } }
/**
 * COME TI VEDI: l'archetipo dell'utente, o null se il quiz non l'ha ancora fatto. La funzione unica: la scheda Identita', la lettura
 * del Genio e il server leggono da qui. { id, ico, nome, nomeInFrase, frase, forza, tratti, ritratto, lato: { id, nome } | null,
 * impresa, risposte: [{ domanda, risposta }], at }
 */
function idsArchetipo(rec){
  rec = rec || idsLeggi(); if (!rec) return null;
  const v = idsVersione(rec);
  const c = idsCalcola(rec.risposte, rec.impresa, v); if (!c || c.fatte < idsNecessarie(v)) return null;
  const a = idsArchetipoDi(c.id); if (!a) return null;
  const sesso = idsSesso(), nome = idsNome(a, sesso);
  const l = c.lato ? idsArchetipoDi(c.lato) : null;
  return { id: a.id, ico: a.ico, nome: nome, nomeInFrase: idsNomeInFrase(nome), frase: a.frase, forza: a.forza,
    tratti: idsTratti(a, l), ritratto: a.ritratto || '', lato: l ? { id: l.id, ico: l.ico, nome: idsNome(l, sesso) } : null,
    impresa: !!rec.impresa, risposte: idsRisposteTesto(rec.risposte, rec.impresa, v), at: rec.at || 0 };
}
/** Il sogno e il campo di adesso, per sapere se le domande sono quelle dell'impresa. */
function idsImpresaOra(sogno, campo){
  try{ if (sogno == null) sogno = (typeof orSognoScelto === 'function') ? orSognoScelto() : ((typeof nvSogno === 'function') ? nvSogno() : ''); }catch(_){ sogno = ''; }
  try{ if (campo == null) campo = (typeof gnDati === 'function' && gnDati().target) || ((typeof orTargetDaSogno === 'function') ? orTargetDaSogno(sogno) : ''); }catch(_){ campo = ''; }
  return idsImpresa(sogno, campo);
}
function idsEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
/** La domanda in html: la parte fra asterischi in blu (cls: la classe del blu, sulla lettura 'or-blu'). */
function idsDomandaHtml(t, cls){ return idsEsc(t).replace(/\*([^*]+)\*/g, '<b' + (cls ? ' class="' + cls + '"' : '') + '>$1</b>'); }
/** Le risposte di una domanda: le carte delle domande della Stagione 1 (flCarteHtml, domande.js), testo breve e la (i) con la frase intera.
    fn = la funzione da chiamare con l'indice. */
function idsScelteHtml(d, fn, scelta){
  const voci = d.r.map(function(r, i){ return { e: r.e, t: r.t, s: r.s || '', js: fn + '(' + i + ')', on: scelta === i }; });
  if (typeof flCarteHtml === 'function') return flCarteHtml(voci);
  return '<div class="gn-carta"><div class="gn-cards">' + voci.map(function(v){ return '<button type="button" class="gn-card" onclick="event.stopPropagation();' + v.js + '"><span>' + v.e + '</span><b>' + idsEsc(v.t) + '</b></button>'; }).join('') + '</div></div>';
}
/** La carta dell'archetipo (lo specchio): l'emoji, il nome, il secondo lato, i tre tratti, la frase in prima persona e il ritratto.
    Per la lettura e per la fine del quiz. 0.9.402 BUG-213: "una frase sola non rappresenta l'utente" */
function idsCartaHtml(a){
  if (!a) return '';
  const tr = (a.tratti || []).filter(Boolean);
  return '<div class="ids-carta"><span class="ids-carta-e" aria-hidden="true">' + a.ico + '</span><b class="ids-carta-n">' + idsEsc(a.nome) + '</b>'
    + (a.lato && a.lato.nome ? '<small class="ids-carta-lato">con un lato da ' + idsEsc(idsNomeNudo(a.lato.nome)) + '</small>' : '')
    + (tr.length ? '<span class="ids-carta-tr">' + tr.map(function(t){ return '<em>' + idsEsc(t) + '</em>'; }).join('') + '</span>' : '')
    + '<p class="ids-carta-f">"' + idsEsc(a.frase) + '"</p>'
    + (a.ritratto ? '<p class="ids-carta-r">' + idsEsc(a.ritratto) + '</p>' : '') + '</div>';
}
/** Perche' il Genio parte da qui, detto a chi non sa niente della materia.
    0.9.393, Andrea: "la slide E negli affari, con Dan Kennedy e il prezzo che chiedi, compare a TUTTI: non ha senso per chi non fa
    business. Non devi riportare nell'interfaccia cose che io dico a te: deve essere tutto contestualizzato, gli utenti non sanno cosa ci
    siamo detti, presentalo come se fossero ignoranti in materia". Niente nomi che un utente qualsiasi non conosce (Kennedy tolto; Maltz
    detto per quello che era), e la pagina sul prezzo solo per chi sogna di vendere qualcosa. */
function idsPercheRighe(impresa){
  const r = [['🪞', 'Prima come ti vedi', 'Un chirurgo americano, Maxwell Maltz, lo notò nei suoi pazienti. Anche dopo un\'operazione riuscita, molti continuavano a sentirsi come prima. Nessuno riesce a comportarsi a lungo in modo diverso dall\'idea che ha di sé.'],
    ['🧭', 'Poi la rotta', 'Come un pilota automatico, la mente corregge la rotta verso l\'obiettivo che le dai, un errore alla volta. Un errore dice cosa correggere, non chi sei.']];
  if (impresa) r.push(['💶', 'Anche quando vendi', 'L\'idea che hai di te si vede anche nel lavoro. Il prezzo che chiedi e il modo in cui parli a un cliente dicono quanto pensi di valere.']);
  r.push(['🙂', 'Nessuna risposta giusta', 'Rispondi d\'istinto, con la prima che senti tua. Il Genio non ti giudica, ti fa da specchio.']);
  return r;
}
/** Il foglio "Perche' parto da come ti vedi". impresa: se il sogno e' un'impresa; senza, si guarda il sogno di adesso. */
function idsPerche(impresa){
  if (typeof inSheet !== 'function') return;
  if (impresa !== true && impresa !== false) impresa = idsImpresaOra();
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Perché parto da come ti vedi</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe(idsPercheRighe(impresa)) : '')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}

/* ---------------------------------------------------------------------------------------
   IL QUIZ SULLA SCENA DEL GENIO (dalla scheda Identita'): il Genio parla, una domanda alla volta, come negli episodi.
   1. quattro nuvolette brevi, tocca per continuare (IDS_INTRO); l'ultima ha "Comincio" e "Perche' parti da qui?";
   2. le dodici domande, con le carte;
   3. lo specchio: "Ti vedi come la Costruttrice", la carta, e si torna alla scheda Identita' sulla slide Come ti vedi oggi.
   --------------------------------------------------------------------------------------- */
/* 0.9.393, Andrea: "la nuvoletta iniziale (Prima di dirti chi stai diventando, voglio sapere come ti vedi tu. Nove domande: rispondi
   d'istinto, non c'e' una risposta giusta) e' troppo lunga, cinque righe, senza emoji ne' parola colorata. Va spezzata in piu' nuvolette
   successive, tocca per continuare come nelle storie, ognuna di una o due righe, con una parola chiave in blu". */
const IDS_INTRO = [
  'Prima voglio sapere *come ti vedi tu*. 🪞',
  'Poi ti dirò *chi stai diventando*. 🔮',
  'Ti faccio *dodici domande*, una alla volta. 📝',
  'Rispondi *d\'istinto*.\nNessuna è sbagliata. 🙂'
];
const IDS = { passo: 'via', i: 0, risposte: {}, impresa: false, storia: [], da: '' };
function idsApri(da){
  if (typeof GN === 'undefined' || typeof gnVai !== 'function' || typeof GN_PASSI === 'undefined'){ try{ if (typeof pscToast === 'function') pscToast('Il Genio non è pronto, riprova'); }catch(_){ } return; }
  idsAggancia();
  IDS.passo = 'via'; IDS.i = 0; IDS.risposte = {}; IDS.storia = []; IDS.da = da || 'identita';
  IDS.impresa = idsImpresaOra();
  GN.on = true; GN.modo = 'ids'; GN.audio = true; GN.storia = [];
  goId('s-genio');
  const t = document.getElementById('gnTop'); if (t) t.hidden = false;
  idsBarra();
  GN.step = ''; gnVai('ids');
}
function idsBarra(){
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  const n = IDS_DOMANDE.length;
  if (bar) bar.style.width = (IDS.passo === 'via' ? 4 : (IDS.passo === 'fine' ? 100 : Math.round((IDS.i + 1) / (n + 1) * 100))) + '%';
  if (txt) txt.textContent = IDS.passo === 'q' ? 'Come ti vedi · ' + (IDS.i + 1) + ' di ' + n : 'Come ti vedi';
}
function idsVai(p, i){ IDS.storia.push([IDS.passo, IDS.i]); IDS.passo = p; if (i != null) IDS.i = i; idsBarra(); GN.step = ''; gnVai('ids'); }
function idsIndietro(){
  if (!IDS.storia.length){ idsChiudi(); return true; }
  const s = IDS.storia.pop(); IDS.passo = s[0]; IDS.i = s[1]; idsBarra(); GN.step = ''; gnVai('ids'); return true;
}
/** La scena, come quella degli episodi (epiClassi, episodi.js). Il testo della nuvoletta e' sempre grande (domanda); il Genio si fa piu'
    piccolo (molte) solo con le carte o lo specchio sotto, come nella domanda della S1E6; lo sfondo si sfoca solo sotto alle domande. */
function idsScena(cosa){
  const sc = document.getElementById('gnScena'), sg = document.getElementById('s-genio');
  const q = cosa === 'q', sotto = q || cosa === 'fine';
  if (sc){ sc.classList.add('con-top', 'domanda'); sc.classList.toggle('molte', sotto); sc.classList.toggle('carte', q); sc.classList.remove('apertura', 'volo', 'ids-q', 'epi-cine', 'epi-frase'); }
  if (sg){ sg.classList.toggle('domanda', q); sg.classList.remove('apertura', 'volo'); }
}
function idsChiudi(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  try{ const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('ids-q', 'domanda', 'molte', 'carte'); const sg = document.getElementById('s-genio'); if (sg) sg.classList.remove('domanda'); }catch(_){ }
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
  /* si torna alla scheda Identita', sulla slide Come ti vedi oggi (la seconda) */
  try{ if (typeof PST !== 'undefined') PST.aaiTab = 'io'; if (typeof PSC_SUB !== 'undefined') localStorage.setItem(PSC_SUB, 'oggi'); }catch(_){ }
  setTimeout(function(){ try{ if (typeof PSC !== 'undefined') PSC.ioSl = 1; if (typeof pstPaint === 'function') pstPaint(); if (typeof pscIoVaiSl === 'function') pscIoVaiSl(1, true); }catch(_){ } }, 120);
}
function idsEntra(){
  idsScena(IDS.passo);
  const D = idsDomande(IDS.impresa);
  if (IDS.passo === 'via'){
    const k = Math.max(0, Math.min(IDS_INTRO.length - 1, IDS.i || 0));
    if (k < IDS_INTRO.length - 1){
      /* le nuvolette prima dell'ultima: si legge e si tocca per continuare */
      try{ gnPosa(k ? 'pensa' : 'saluta'); }catch(_){ }
      gnScrivi(IDS_INTRO[k], function(){ const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false; });
      return;
    }
    gnDomanda('rivela', IDS_INTRO[k],
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();idsVai(\'q\',0)">Comincio</button></div>'
      + '<button type="button" class="gn-link ids-perche" onclick="event.stopPropagation();idsPerche(' + (IDS.impresa ? 'true' : 'false') + ')">Perché parti da qui?</button>');
    return;
  }
  if (IDS.passo === 'q'){
    const d = D[IDS.i]; if (!d){ idsFine(); return; }
    const k = IDS_DOMANDE[IDS.i].id;
    gnDomanda('pensa', d.t, idsScelteHtml(d, 'idsScegli', IDS.risposte[k] != null ? +IDS.risposte[k] : null));
    return;
  }
  if (IDS.passo === 'fine'){
    const a = idsArchetipo();
    if (!a){ IDS.passo = 'q'; IDS.i = 0; GN.step = ''; gnVai('ids'); return; }
    gnDomanda('rivela', idsFineTesto(a),
      idsCartaHtml(a) + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();idsChiudi()">Torna alla tua identità</button></div>');
  }
}
/** La nuvoletta dello specchio, breve: il nome in blu, e da qui si parte. */
function idsFineTesto(a){ return 'Ti vedi come *' + idsNomeInFrase(a.nome) + '*. 🪞'; }
/** Il tocco sulla scena: nelle nuvolette dell'inizio, la prossima. */
function idsTocco(){
  if (IDS.passo === 'via' && (IDS.i || 0) < IDS_INTRO.length - 1) idsVai('via', (IDS.i || 0) + 1);
}
function idsScegli(i){
  const k = IDS_DOMANDE[IDS.i].id;
  IDS.risposte[k] = i;
  try{ gnAu.scelta(i % 4); if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  if (IDS.i < IDS_DOMANDE.length - 1){ idsVai('q', IDS.i + 1); return; }
  idsFine();
}
function idsFine(){
  if (!idsSalva(IDS.risposte, IDS.impresa)){ try{ if (typeof pscToast === 'function') pscToast('La memoria del telefono è piena, non si salva'); }catch(_){ } return; }
  try{ gnAu.punto(); if (typeof flVibra === 'function') flVibra([10, 30, 10]); }catch(_){ }
  idsVai('fine');
}
/* la scena del Genio e' in genio-intro.js, caricato dopo: gli agganci si mettono la prima volta che serve */
let idsAgganciato = false;
function idsAggancia(){
  if (idsAgganciato || typeof GN_PASSI === 'undefined') return;
  idsAgganciato = true;
  GN_PASSI.ids = { entra: idsEntra, tocco: idsTocco };
  if (typeof gnChiudiTop === 'function'){ const v = gnChiudiTop; window.gnChiudiTop = gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'ids'){ idsChiudi(); return; } return v.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v2 = gnIndietro; window.gnIndietro = gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'ids') return idsIndietro(); return v2.apply(this, arguments); }; }
}
(function(){
  if (typeof document === 'undefined' || !document.head) return;
  const st = document.createElement('style');
  st.textContent = [
    /* la carta dello specchio: sulla scena del Genio e nella lettura, sempre su fondo scuro */
    '.ids-carta{display:flex;flex-direction:column;align-items:center;text-align:center;margin:0 0 18px;padding:22px 18px 20px;border-radius:22px;background:rgba(255,255,255,.1);box-shadow:inset 0 0 0 1.5px rgba(140,198,255,.28)}',
    '.ids-carta-e{width:64px;height:64px;border-radius:32px;background:#fff;display:flex;align-items:center;justify-content:center;font-size:34px;line-height:1;box-shadow:0 8px 22px rgba(0,0,0,.25)}',
    '.ids-carta-n{display:block;margin-top:14px;font:800 20px/1.25 var(--font-display);color:#fff}',
    '.ids-perche{display:block;margin:16px auto 0}',
    /* 0.9.393: tolta la regola che rimpiccioliva il Genio sotto a tutte le domande del quiz (.gn.ids-q .gn-sopra 14vh): con quattro carte
       la scena e' quella della domanda della S1E6 (idsScena) */
    '.ids-carta-f{margin:10px 0 0;font:italic 600 15px/1.5 var(--font-body);color:rgba(232,241,255,.9)}',
    /* 0.9.402 BUG-213: il secondo lato, i tre tratti e il ritratto (il fondo della carta e' sempre scuro: testo chiaro fisso) */
    '.ids-carta-lato{display:block;margin-top:4px;font:600 13.5px var(--font-body);color:#BCE0FF}',
    '.ids-carta-tr{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;margin-top:14px}.ids-carta-tr em{font:700 12.5px/1.3 var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:6px 10px;border-radius:99px}',
    '.ids-carta-r{margin:12px 0 0;padding-top:12px;border-top:1px dashed rgba(140,198,255,.35);font:500 14px/1.5 var(--font-body);color:rgba(232,241,255,.82)}'
  ].join('\n');
  document.head.appendChild(st);
})();

if (typeof module !== 'undefined' && module.exports){
  module.exports = { IDS_KEY, IDS_ARCHETIPI, IDS_DEBOLE_COMBO, idsTratti, IDS_DOMANDE, IDS_DOMANDE_IMPRESA, IDS_INTRO, IDS_V1, IDS_N_PRIMA, idsNecessarie, idsNomeNudo, idsCartaHtml, idsImpresa, idsDomande, idsArchetipoDi, idsNome, idsNomeInFrase,
    idsCalcola, idsRisposteTesto, idsArchetipo, idsPercheRighe, idsScelteHtml, idsDomandaHtml, idsFineTesto, idsPulito };
}
