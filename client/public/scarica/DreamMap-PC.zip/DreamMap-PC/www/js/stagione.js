/* ===========================================================================================
   LA STAGIONE DI SPINTA (0.9.242): il Monk mode di Davie Fogarty

   Novanta giorni come se la tua vita dipendesse dall'obiettivo, poi due settimane di riposo e
   il bilancio. Si sceglie (opt-in), da una porta chiara: la vista Roadmap della Mappa e la prima
   card delle Sfide di Dream. Mentre dura la spinta le sezioni che distraggono restano spente
   (blocchi-sezioni.js: giochi del Genio, Academy, respiro, Consigliato per te, sfide, Lega);
   il respiro e i consigli si riaprono solo nei giorni con l'umore basso.

   I DATI: fl_stagione = { inizio (mezzanotte del primo giorno), obiettivo, blocchi { k: true },
   bilancio, interrotta } e fl_stagione_storia = [stagioni finite]. Entrano nel backup da soli
   (profile.js prende tutte le chiavi fl_).

   PER DREAM: flStagioneAttiva() restituisce { fase: 'spinta'|'reset', giorno, di, obiettivo,
   inizio, fineSpinta, fineReset, blocchi, bilancio } oppure null. Ci si puo' appoggiare una card.
   (Il "Monk Mode" degli scrigni, trenta giorni e quindici ore a settimana, e' un'altra cosa e
   resta com'e'.)
   =========================================================================================== */
const STG_KEY = 'fl_stagione';
const STG_STORIA_KEY = 'fl_stagione_storia';
const STG_SPINTA = 90;
const STG_RESET = 14;
const STG = { passo: 'intro', bozza: null, bil: null };

function stgLeggiJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function stgScriviJ(k, v){ try{ if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function stgEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function stgMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function stgGiorniDa(inizio, adesso){ return Math.round((stgMezzanotte(adesso) - stgMezzanotte(inizio)) / 86400000) + 1; }
function stgData(ms){ const d = new Date(ms); const m = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']; return d.getDate() + ' ' + m[d.getMonth()]; }

/* 0.9.363, Andrea: "i 90 giorni non devono essere per forza 90: sono il default, ma se l'utente vuole un mese puo' farlo. E una
   modalita' ADHD per chi soffre di cecita' temporale, con scadenze vicine come entro domani" (il reel del dott. Valerio Rosso:
   una scadenza lontana resta astratta finche' non diventa urgente; esistono solo "adesso" e "non adesso"). Quindi in modalita'
   ADHD: scadenze vicine, il conto alla rovescia in ore, una cosa sola da fare adesso. s.di = giorni di spinta, s.adhd. */
const STG_DURATE = [[90, '90 giorni'], [60, '60 giorni'], [30, '30 giorni']];
const STG_DURATE_ADHD = [[2, 'Entro domani'], [3, '3 giorni'], [7, '1 settimana'], [14, '2 settimane']];
function stgDi(s){ const n = s && +s.di; return n > 0 ? Math.min(365, Math.round(n)) : STG_SPINTA; }
function stgRiposo(di){ return di >= 30 ? STG_RESET : Math.max(1, Math.round(di / 4)); }
function stgGiorniTxt(n){ return n === 1 ? '1 giorno' : n + ' giorni'; }
function stgOreTxt(ms){ const h = Math.max(0, Math.floor(ms / 3600000)), m = Math.max(0, Math.floor(ms / 60000) % 60); return h >= 1 ? (h === 1 ? '1 ora' : h + ' ore') + (h < 10 && m ? ' e ' + m + ' min' : '') : m + ' minuti'; }
function stgCorrente(){ const s = stgLeggiJ(STG_KEY, null); return s && s.inizio ? s : null; }

/** Lo stato della stagione adesso, o null se non c'e' (o e' finita: allora passa nella storia). */
function flStagioneAttiva(adesso){
  const s = stgCorrente(); if (!s) return null;
  const g = stgGiorniDa(s.inizio, adesso), DI = stgDi(s), RI = stgRiposo(DI);
  const fineSpinta = stgMezzanotte(s.inizio) + DI * 86400000;
  const fineReset = fineSpinta + RI * 86400000;
  if (g < 1) return null;
  if (g > DI + RI){ stgArchivia(s, false); return null; }
  const spinta = g <= DI;
  return { fase: spinta ? 'spinta' : 'reset', giorno: spinta ? g : g - DI, di: spinta ? DI : RI, adhd: !!s.adhd, spintaDi: DI,
           giornoTot: g, obiettivo: s.obiettivo || '', inizio: s.inizio, fineSpinta: fineSpinta, fineReset: fineReset,
           blocchi: s.blocchi || {}, bilancio: s.bilancio || null };
}
/* 0.9.372: il programma di blocco della spinta (modo "tutto"): le app segnate come distrazioni e i social sul web, tutto il giorno, ogni
   giorno. Porta stagione:true e si toglie da solo quando la stagione si chiude o si interrompe */
async function stgProgrammaCrea(DI, muto){
  try{
    if (typeof PROGRAMS === 'undefined') return;
    const L = stgLista();
    const apps = L.apps.slice(), siti = L.sites.slice();
    for (let i = PROGRAMS.length - 1; i >= 0; i--) if (PROGRAMS[i] && PROGRAMS[i].stagione) PROGRAMS.splice(i, 1);
    PROGRAMS.push({ id: 'p' + Date.now().toString(36), name: 'Stagione di spinta', type: 'ora', icon: '🛡️', from: '00:00', to: '23:59',
      days: [true, true, true, true, true, true, true], allDay: true, apps: apps, sites: siti, keywords: L.words.slice(), allow: [],
      blockLaunch: true, blockNotifications: true, on: true, stagione: true, fino: stgMezzanotte() + DI * 86400000 });
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    if (typeof pushRules === 'function') await pushRules();
    if (!apps.length && !muto) try{ toast('Bloccati i social sul web. Per bloccare anche le app, segna quelle che ti distraggono nel Report.'); }catch(_){ }
  }catch(_){ }
}
/* "Tutto, tranne i sempre consentiti": l'elenco consentito del motore per tutta la spinta, con le app e i siti del Full Focus; le regole di
   prima si mettono da parte e tornano alla fine.
   0.9.402 BUG-211, Andrea: "Il blocco non si e' acceso: uso una lista di blocco" dopo aver avviato la stagione. La causa: l'elenco consentito
   si armava con setRulesFull, che con la Modalita' severa (o il contratto di abitudine) rifiuta ogni cambio di listMode come
   "indebolimento"; e anche quando passava, il telefono lo smontava al primo avvio (FocusSession.repairIfStuck: un elenco consentito
   senza una sessione del Full Focus era considerato un guasto). Adesso lo arma il telefono con la sua scadenza (beginSeasonAllowlist,
   StagioneConsentiti.java), come fa il Full Focus. Il ripiego sulla lista di blocco resta solo per un motore vecchio, ed e' silenzioso. */
function stgLog(msg, e){ try{ console.warn('[stagione] ' + msg, (e && (e.code || e.message)) || ''); }catch(_){ } try{ const l = stgLeggiJ('fl_stg_log', []) || []; l.push({ at: Date.now(), msg: String(msg).slice(0, 200) }); stgScriviJ('fl_stg_log', l.slice(-20)); }catch(_){ } }
async function stgConsentitiArma(DI, finoDato){
  const fino = finoDato || (stgMezzanotte() + DI * 86400000);
  try{
    const p = (typeof ffPref === 'function') ? ffPref() : {};
    const apps = (p.allow || []).slice(); if (apps.indexOf('com.dreambrothers.dreammap') < 0) apps.push('com.dreambrothers.dreammap');
    const siti = (p.allowSites || []).slice();
    if (typeof blkHasNative === 'function' && blkHasNative('beginSeasonAllowlist')){
      const r = await blkNative('beginSeasonAllowlist', { allowApps: apps, allow: siti, fino: fino }, true);
      if (r && r.ok){ localStorage.setItem('fl_stg_prima', JSON.stringify({ nativo: true, fino: fino })); return; }
      stgLog('beginSeasonAllowlist. Elenco consentito non armato');
    } else if (typeof blkNative === 'function' && typeof NATIVE !== 'undefined' && NATIVE){
      /* motore di prima della 0.9.402: la strada vecchia, senza messaggi */
      const cur = await blkNative('getRulesFull', {}, true);
      if (!localStorage.getItem('fl_stg_prima')) localStorage.setItem('fl_stg_prima', JSON.stringify({ listMode: (cur && cur.listMode) || 'blocklist', allowApps: (cur && cur.allowApps) || [], allow: (cur && cur.allow) || [], fino: fino }));
      const ok = await blkNative('setRulesFull', { listMode: 'allowlist', allowApps: apps, allow: siti }, true);
      if (ok !== null) return;
      localStorage.removeItem('fl_stg_prima');
      stgLog('setRulesFull: elenco consentito rifiutato (motore vecchio)');
    } else return;
  }catch(e){ stgLog('elenco consentito non armato', e); }
  /* ripiego silenzioso: il programma della stagione con le distrazioni segnate (non due volte) */
  if (!finoDato) stgProgrammaCrea(DI, true);
}
/* una stagione "tutto" gia' in corso (partita col ripiego, o con l'elenco smontato dal telefono): con il motore nuovo si riarma da sola */
function stgConsentitiRiarma(){
  try{
    const s = stgCorrente(), st = flStagioneAttiva();
    if (!s || !st || st.fase !== 'spinta' || s.modo !== 'consentiti') return;
    if (typeof blkHasNative !== 'function' || !blkHasNative('beginSeasonAllowlist')) return;
    const pr = stgLeggiJ('fl_stg_prima', null);
    if (pr && pr.nativo && pr.fino === st.fineSpinta) return;
    stgConsentitiArma(st.spintaDi, st.fineSpinta);
  }catch(e){ stgLog('riarmo non riuscito', e); }
}
async function stgConsentitiTogli(){
  try{
    const pr = JSON.parse(localStorage.getItem('fl_stg_prima') || 'null'); if (!pr) return;
    if (pr.nativo){
      if (typeof blkHasNative === 'function' && blkHasNative('endSeasonAllowlist')){ const ok = await blkNative('endSeasonAllowlist', {}, true); if (ok === null){ stgLog('endSeasonAllowlist rifiutato'); return; } }
      localStorage.removeItem('fl_stg_prima');
      return;
    }
    if (typeof blkNative === 'function'){ const ok = await blkNative('setRulesFull', { listMode: pr.listMode, allowApps: pr.allowApps || [], allow: pr.allow || [] }, true); if (ok === null) return; }
    localStorage.removeItem('fl_stg_prima');
  }catch(_){ }
}
async function stgProgrammaTogli(){
  stgConsentitiTogli();
  try{
    if (typeof PROGRAMS === 'undefined') return;
    let tolti = 0;
    for (let i = PROGRAMS.length - 1; i >= 0; i--) if (PROGRAMS[i] && PROGRAMS[i].stagione){ PROGRAMS.splice(i, 1); tolti++; }
    if (!tolti) return;
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    if (typeof pushRules === 'function') await pushRules();
  }catch(_){ }
}
/* a ogni avvio: finita la spinta, il programma si toglie anche se la stagione non e' stata chiusa a mano */
setTimeout(function(){ try{ const pr = JSON.parse(localStorage.getItem('fl_stg_prima') || 'null'); if ((pr && pr.fino && Date.now() > pr.fino) || (typeof PROGRAMS !== 'undefined' && PROGRAMS.some(function(p){ return p && p.stagione && p.fino && Date.now() > p.fino; }))) stgProgrammaTogli(); else stgConsentitiRiarma(); }catch(_){ } }, 6000);
function stgArchivia(s, interrotta){
  stgProgrammaTogli();
  const l = stgLeggiJ(STG_STORIA_KEY, []) || [];
  l.push(Object.assign({}, s, { chiusa: Date.now(), interrotta: !!interrotta }));
  stgScriviJ(STG_STORIA_KEY, l.slice(-20));
  stgScriviJ(STG_KEY, null);
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO (usato anche da prenota.js e piano-settimana.js): un velo con una card blu notte
   --------------------------------------------------------------------------------------- */
function stgFoglio(html, id, intera){
  { const v0 = document.getElementById('stgVelo'); if (v0) v0.remove(); }
  STG.dopoChiudi = null;
  const v = document.createElement('div');
  v.id = 'stgVelo'; v.className = 'stg-velo' + (intera ? ' stg-pagina' : '');
  v.innerHTML = '<div class="stg-scrim" onclick="stgFoglioChiudi()"></div><div class="stg-f" role="dialog" aria-modal="true"' + (id ? ' id="' + id + '"' : '') + '>'
    + '<button type="button" class="stg-x" onclick="stgFoglioChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="stg-fin">' + html + '</div></div>';
  (document.getElementById('phone') || document.body).appendChild(v);
  return v;
}
function stgFoglioCorpo(html){ const c = document.querySelector('#stgVelo .stg-fin'); if (c){ c.innerHTML = html; c.scrollTop = 0; } }
function stgFoglioChiudi(){
  const v = document.getElementById('stgVelo'); if (v) v.remove();
  /* aperto dalla tappa della mappa: chiuso il foglio, la tappa si chiude (accettata o rimandata) */
  if (STG.daMappa){ STG.daMappa = false; setTimeout(function(){ try{ sdAggiorna(true); sdPaint(); }catch(_){ } }, 200); }
  /* 0.9.388 (BUG-112): chi apre un foglio puo' sapere quando si chiude, dalla X, dal velo o da un pulsante. Il popover del passo di
     domani (prenota.js) lo usa per far andare avanti la revisione della sera quando lo chiudi */
  const dopo = STG.dopoChiudi; STG.dopoChiudi = null;
  if (typeof dopo === 'function') setTimeout(function(){ try{ dopo(); }catch(_){ } }, 0);
}
function stgBack(){ if (document.getElementById('stgVelo')){ if (STG.bozza && STG_PASSI.indexOf(STG.passo) > 0 && document.querySelector('#stgVelo .stg-testa')) stgIndietro(); else stgFoglioChiudi(); return true; } return false; }

const STG_I = {
  monte: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20l6.5-11 4 6.5 2.5-4L21 20z"/><path d="M14.5 6.5l1.5-2.5 1.5 2.5"/></svg>',
  luna: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>',
  spento: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>'
};

/* ---------------------------------------------------------------------------------------
   COMINCIARE: tre schermate (come funziona, l'obiettivo, cosa si spegne)
   --------------------------------------------------------------------------------------- */
function stgObiettivoProposto(){
  /* 0.9.290, Andrea: "viene precompilato con 'L'app e' pubblica e viaggia insieme a ogni quadro venduto': quello non e'
     l'obiettivo che mi sono scritto, viene dalla roadmap". Il trimestre del piano e gli orizzonti li scrive l'agente;
     qui va solo quello che la persona ha scritto con le sue parole: l'obiettivo della stagione di prima, se c'e',
     altrimenti il sogno che ha scelto lui. */
  try{
    const st = JSON.parse(localStorage.getItem('fl_stagione_storia') || '[]') || [];
    const ult = st.length ? st[st.length - 1] : null;
    if (ult && ult.obiettivo && String(ult.obiettivo).trim()) return stgPulito(ult.obiettivo);
  }catch(_){ }
  try{ if (typeof nvSogno === 'function'){ const sg = String(nvSogno() || '').trim(); if (sg) return stgPulito(sg); } }catch(_){ }
  return '';
}
function stgPulito(t){ t = String(t || '').trim(); return typeof flAccenti === 'function' ? flAccenti(t) : t; }
function stgApri(){
  const st = flStagioneAttiva();
  if (st && st.fase === 'reset'){ stgBilancioApri(); return; }
  if (st){ stgStatoApri(); return; }
  STG.passo = 'intro';
  STG.bozza = { obiettivo: stgObiettivoProposto(), blocchi: {}, di: STG_SPINTA, adhd: false };
  (typeof BS_STAGIONE_DEF !== 'undefined' ? BS_STAGIONE_DEF : []).forEach(function(k){ STG.bozza.blocchi[k] = true; });
  /* 0.9.368, Andrea: "si apre a schermo intero invece di un popover, con un'immagine che non c'entra": popover, e la stessa foto della card */
  stgFoglio(stgPassoHtml(), null, false);
}
/* 0.9.373, Andrea: "tutto al centro, mai un po' a sinistra e un po' al centro; la barra 90/14 anche al passo 1, sopra alle durate;
   Accetto la sfida rosso; Cosa blocchi: i sempre consentiti (come il Full Focus) o una lista di blocco (come i programmi); poi la
   modalita' severa, e le distrazioni di DreamMap in un pannello che si apre; e indietro torna al passo prima, mai chiude il foglio".
   I passi: la sfida, 1 quanto dura, 2 cosa blocchi, 3 modalita' severa, 4 l'obiettivo */
const STG_PASSI = ['intro', 'durata', 'blocco', 'severa', 'obiettivo'];
/* 0.9.374, Andrea: "nella barra i giorni di spinta e di riposo centrati fanno schifo: 2 giorni tocca il bordo e spinta va a capo. Era
   meglio prima, uno a sinistra e l'altro a destra: e' una barra, va contestualizzata". La barra resta solo colore; sotto, la spinta a
   sinistra e il riposo a destra, su una riga */
/* 0.9.375, Andrea: "con la modalita' ADHD 2 giorni di spinta sembrano meno di 1 di riposo; e le scritte le voglio dentro la barra, bianche,
   come prima". Si torna alla barra con le scritte dentro (spinta bianca sul blu, riposo sul gradiente) e le parti sono in proporzione ai
   giorni veri: prima il riposo valeva almeno 14, e contro 2 giorni di spinta vinceva lui. Ogni parte ha la larghezza minima della sua
   scritta, cosi' non va mai a capo piu' di una volta */
function stgLineaHtml(b){ const DI = stgDi(b), RI = stgRiposo(DI); return '<div class="stg-linea stg-linea2"><div class="stg-l-spinta" style="flex:' + Math.max(DI, RI + 0.5) + ' 1 0"><b>' + stgGiorniTxt(DI) + '</b><small>spinta</small></div><div class="stg-l-riposo" style="flex:' + RI + ' 1 0"><b>' + RI + '</b><small>riposo</small></div></div>'; }
function stgTesta(n){ return '<div class="stg-testa"><button type="button" class="stg-back" onclick="stgIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><small class="stg-eti">Passo ' + n + ' di 4</small></div>'; }
function stgPassoHtml(){
  const b = STG.bozza;
  if (STG.passo === 'intro'){
    const DI = stgDi(b), RI = stgRiposo(DI);
    return '<div class="stg-hero"><img src="img/sfide/spinta.jpg" alt=""><div class="stg-hero-t"><small>Una sfida del Genio</small><h2>La stagione di spinta</h2></div></div>'
      /* 0.9.374, Andrea: "il titolo sulla foto e' a sinistra e il testo sotto e' al centro: si rompe la formattazione". Tutto a sinistra
         come il titolo; il testo dei pulsanti resta al centro (sempre) */
      + '<div class="stg-centro stg-sx"><p class="stg-lead">' + stgGiorniTxt(DI) + ' come se la tua vita dipendesse dal tuo obiettivo. Poi ' + RI + ' di riposo.</p>'
      + stgLineaHtml(b)
      + '<button type="button" class="stg-cta rossa" onclick="stgVai(\'durata\')">Accetto la sfida</button>'
      + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button></div>';
  }
  if (STG.passo === 'durata'){
    return '<div class="stg-centro stg-sx">' + stgTesta(1) + '<h2 class="stg-h">Quanto dura la spinta?</h2>'
      + stgLineaHtml(b)
      + stgDurataHtml(b)
      + '<p class="stg-nota">Finisce il ' + stgData(stgMezzanotte() + (stgDi(b) - 1) * 86400000) + ', poi ' + stgRiposo(stgDi(b)) + ' di riposo.</p>'
      + '<button type="button" class="stg-cta" onclick="stgVai(\'blocco\')">Avanti</button></div>';
  }
  if (STG.passo === 'blocco'){
    const m = b.modo || 'lista';
    const opz = function(k, ico, t, sub, dentro){ return '<button type="button" class="stg-modo' + (m === k ? ' on' : '') + '" onclick="STG.bozza.modo=\'' + k + '\';stgVai(\'blocco\')"><i>' + ico + '</i><span><b>' + t + '</b><small>' + sub + '</small>' + (dentro || '') + '</span></button>'; };
    let nAllow = 0; try{ nAllow = (ffPref().allow || []).length; }catch(_){ }
    return '<div class="stg-centro stg-sx">' + stgTesta(2) + '<h2 class="stg-h">Cosa blocchi?</h2>'
      /* 0.9.379, Andrea: "prima Una lista di blocco, poi Tutto tranne i sempre consentiti; e Scegli i sempre consentiti dentro al suo
         pannello, non fuori. Con la lista di blocco fammi scegliere cosa bloccare: il blocco rapido e i programmi che ho gia', o nuovi" */
      /* 0.9.380, Andrea: "non si blocca un blocco rapido: una lista apposta per la stagione, con le app, i siti e le parole, come il foglio
         dei sempre consentiti. E Scegli i sempre consentiti torna un link sottolineato, mai uguale al pulsante principale" */
      + opz('lista', '🛡️', 'Una lista di blocco', 'Le app, i siti e le parole che blocchi solo durante la stagione.', m === 'lista' ? '<span class="stg-modo-l" role="button" tabindex="0" onclick="event.stopPropagation();stgListaApri()">' + stgListaTxt() + '</span>' : '')
      + opz('consentiti', '⭐', 'Tutto, tranne i sempre consentiti', 'Come nel Full Focus. Si aprono solo le app che consenti tu' + (nAllow ? ' (' + nAllow + ')' : '') + '.', m === 'consentiti' ? '<span class="stg-modo-l" role="button" tabindex="0" onclick="event.stopPropagation();stgConsentiti()">Scegli i sempre consentiti</span>' : '')
      + '<button type="button" class="stg-cta" onclick="stgVai(\'severa\')">Avanti</button></div>';
  }
  if (STG.passo === 'severa'){
    const righe = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).map(function(d){
      const spenta = !!b.blocchi[d.k];
      return '<div class="stg-riga' + (spenta ? ' spenta' : '') + '"><div><b>' + stgEsc(d.n) + '</b><small>' + (spenta ? 'Spenta per ' + stgGiorniTxt(stgDi(b)) : 'Resta accesa') + '</small></div><button type="button" class="switch' + (spenta ? '' : ' on') + '" onclick="stgBloccoCambia(\'' + d.k + '\')" aria-label="' + stgEsc(d.n) + (spenta ? ': spenta' : ': accesa') + '"></button></div>';
    }).join('');
    const sev = !!b.severa;
    /* 0.9.401 BUG-196, Andrea: il pannello delle distrazioni dentro DreamMap ripeteva la scheda DreamMap del passo 2. Compare solo se al
       passo 2 la scheda DreamMap non e' stata aperta (STG.bozza.dmVisto, scritto da stgDmTraccia) */
    const dm = b.dmVisto ? '' : '<details class="stg-dm"' + (STG.dmAperto ? ' open' : '') + ' ontoggle="STG.dmAperto=this.open"><summary>Le distrazioni dentro DreamMap<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></summary><div class="stg-righe">' + righe + '</div></details>';
    /* 0.9.401 BUG-195, Andrea: "chiede di accendere la modalita' severa gia' accesa". Se e' gia' accesa il passo e' fatto e lo dice */
    if (stgSeveraAccesa()){
      b.severa = false;
      return '<div class="stg-centro stg-sx">' + stgTesta(3) + '<h2 class="stg-h">La modalità severa è già accesa</h2>'
        + '<div class="stg-fatto"><i aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></i><span><b>Passo fatto</b><small>Finché resta accesa, i blocchi della stagione non si possono togliere.</small></span></div>'
        + dm
        + '<button type="button" class="stg-cta" onclick="stgVai(\'obiettivo\')">Avanti</button></div>';
    }
    return '<div class="stg-centro stg-sx">' + stgTesta(3) + '<h2 class="stg-h">Accendi la modalità severa?</h2>'
      + '<p class="stg-p">Con la modalità severa i blocchi non si possono togliere. Dopo il via scegli per quanto tempo resta accesa, come si spegne e cosa blocca.</p>'
      + '<div class="stg-sn"><button type="button" class="' + (sev ? 'on' : '') + '" onclick="STG.bozza.severa=true;stgVai(\'severa\')">Sì, la accendo</button><button type="button" class="' + (sev ? '' : 'on') + '" onclick="STG.bozza.severa=false;stgVai(\'severa\')">No</button></div>'
      + dm
      + '<button type="button" class="stg-cta" onclick="stgVai(\'obiettivo\')">Avanti</button></div>';
  }
  /* l'obiettivo */
  return '<div class="stg-centro stg-sx">' + stgTesta(4) + '<h2 class="stg-h">Per cosa spingi ' + (b.adhd ? 'fino alla scadenza' : 'questi ' + stgGiorniTxt(stgDi(b))) + '?</h2>'
    + '<p class="stg-p">Una cosa sola, quella per cui vale la pena dire di no a tutto il resto.</p>'
    + '<textarea class="stg-area" id="stgObiettivo" rows="3" placeholder="Per esempio: lanciare il negozio online e fare le prime 100 vendite">' + stgEsc(b.obiettivo) + '</textarea>'
    + '<button type="button" class="stg-cta" onclick="stgObiettivoOk()">Comincio oggi la stagione</button></div>';
}
/** Il passo prima (la freccia in alto e il tasto indietro del telefono): dalla sfida si chiude */
function stgIndietro(){
  stgObiettivoTieni();
  const i = STG_PASSI.indexOf(STG.passo);
  if (i <= 0){ stgFoglioChiudi(); return; }
  stgVai(STG_PASSI[i - 1]);
}
/* 0.9.375, Andrea: "dalla Stagione apro i sempre consentiti, torno indietro e resta aperto il timer del Full Focus: bug gravissimo".
   Il foglio dei consentiti si apre sopra alla Stagione come da una card dei programmi: la freccia e il tasto indietro lo chiudono
   e basta, e sotto c'e' di nuovo la Stagione con il numero aggiornato */
function stgConsentiti(){ try{ if (typeof FF !== 'undefined'){ FF.allowDaPreset = true; FF.allowDaStg = true; } if (typeof ffAllowOpen === 'function') ffAllowOpen('apps'); }catch(_){ } }
/* la durata: tre durate pronte (90 di partenza) o un numero tuo; la modalita' ADHD mostra scadenze vicine */
function stgDurataHtml(b){
  const lista = b.adhd ? STG_DURATE_ADHD : STG_DURATE, di = stgDi(b);
  const libero = !lista.some(function(x){ return x[0] === di; });
  return '<div class="stg-dur"><p class="stg-dur-k">Quanto dura la spinta</p><div class="stg-dur-l">'
    + lista.map(function(x){ return '<button type="button" class="' + (x[0] === di ? 'on' : '') + '" onclick="stgDurata(' + x[0] + ')">' + x[1] + '</button>'; }).join('')
    + (b.adhd ? '' : '<button type="button" class="' + (libero ? 'on' : '') + '" onclick="stgDurataTua()">' + (libero ? stgGiorniTxt(di) : 'Scegli tu') + '</button>')
    + '</div><button type="button" class="stg-adhd' + (b.adhd ? ' on' : '') + '" onclick="stgAdhd()" aria-pressed="' + !!b.adhd + '"><span><b>Modalità ADHD</b><small>Scadenze vicine e conto alla rovescia in ore, per chi fa fatica a sentire il tempo che passa.</small></span><i class="switch' + (b.adhd ? ' on' : '') + '"></i></button></div>';
}
function stgDurata(n){ if (!STG.bozza) return; STG.bozza.di = n; try{ flVibra(6); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgDurataTua(){
  const v = prompt('Quanti giorni dura la tua spinta? (da 7 a 365)', String(stgDi(STG.bozza)));
  const n = Math.round(+String(v || '').replace(/[^0-9]/g, ''));
  if (n >= 7 && n <= 365) stgDurata(n); else if (v != null) try{ toast('Scegli un numero di giorni fra 7 e 365.'); }catch(_){ }
}
function stgAdhd(){ const b = STG.bozza; if (!b) return; b.adhd = !b.adhd; b.di = b.adhd ? 2 : STG_SPINTA; try{ flVibra(8); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgVai(p){ STG.passo = p; try{ flVibra(6); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgObiettivoTieni(){ const a = document.getElementById('stgObiettivo'); if (a && STG.bozza) STG.bozza.obiettivo = a.value; }
function stgObiettivoOk(){
  const a = document.getElementById('stgObiettivo');
  const t = String(a ? a.value : '').replace(/\s+/g, ' ').trim();
  if (t.length < 4){ try{ toast('Scrivi il tuo obiettivo, anche in poche parole.'); }catch(_){ } return; }
  STG.bozza.obiettivo = t; stgComincia();
}
function stgBloccoCambia(k){
  STG.bozza.blocchi[k] = !STG.bozza.blocchi[k];
  const c = document.querySelector('#stgVelo .stg-fin'), y = c ? c.scrollTop : 0;
  stgFoglioCorpo(stgPassoHtml());
  if (c) c.scrollTop = y;
}
function stgComincia(){
  const b = STG.bozza; if (!b || !b.obiettivo) return;
  const DI = stgDi(b);
  /* 0.9.401 BUG-197: la pagina della stagione mostra cosa resta spento davvero, quindi la lista (o i consentiti) entra nella stagione */
  const salva = { inizio: stgMezzanotte(), at: Date.now(), obiettivo: b.obiettivo, blocchi: b.blocchi, bilancio: null, di: DI, adhd: !!b.adhd, modo: b.modo || 'dreammap', usa: b.usa || null };
  try{
    if (b.modo === 'consentiti'){ const p = (typeof ffPref === 'function') ? ffPref() : {}; salva.consentiti = { apps: (p.allow || []).slice(), sites: (p.allowSites || []).slice() }; }
    else { const L = stgLista(); salva.lista = { apps: L.apps.slice(), sites: L.sites.slice(), words: L.words.slice() }; }
    const nomi = {}; (STG_LISTA.apps || []).concat(typeof FF_APPS !== 'undefined' && FF_APPS ? FF_APPS : []).forEach(function(a){ if (a && a.packageName && a.label) nomi[a.packageName] = a.label; });
    const usate = (salva.lista ? salva.lista.apps : salva.consentiti.apps); salva.nomi = {}; usate.forEach(function(k){ if (nomi[k]) salva.nomi[k] = nomi[k]; });
  }catch(_){ }
  stgScriviJ(STG_KEY, salva);
  if (b.modo === 'consentiti') stgConsentitiArma(DI); else stgProgrammaCrea(DI);
  /* la modalita' severa si accende dalla sua pagina (il motore chiede la conferma) */
  /* 0.9.382, Andrea: "non gli stai facendo scegliere per quanto tempo tenerla, con quale condizione si spegne e cosa viene bloccato: o lo
     porti nella pagina della modalita' severa o lo fai in un popover". Si apre la pagina della modalita' severa, dove si sceglie tutto */
  if (b.severa && !stgSeveraAccesa()) setTimeout(function(){ try{ stgFoglioChiudi(); if (typeof sevVaiPagina === 'function') sevVaiPagina(); else if (typeof sevOpenStatus === 'function') sevOpenStatus(); }catch(_){ } }, 1600);
  /* la stagione e' la prima slide della scheda Sogno: lo slideshow si rifa' */
  try{ const h = document.getElementById('nvHero'); if (h) h.remove(); if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
  try{ flVibra([20, 40, 30]); }catch(_){ }
  stgFoglioCorpo('<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small><h2 class="stg-h">' + (b.adhd ? 'Il tempo parte adesso' : 'Giorno 1 di ' + DI) + '</h2>'
    + (b.adhd ? flContoHtml(stgMezzanotte() + DI * 86400000, null, 'fl-conto-pag') : '')
    + '<p class="stg-p">Da adesso conta una cosa sola, "' + stgEsc(b.obiettivo) + '". Le sezioni che distraggono sono spente fino al ' + stgData(stgMezzanotte() + (DI - 1) * 86400000) + '.</p>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Andiamo</button>');
  stgAggiorna();
}
function stgAggiorna(){
  try{ if (typeof bsControlla === 'function') bsControlla(true); }catch(_){ }
  stgPaint();
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   DURANTE: lo stato, e l'uscita (che costa una conferma scritta)
   --------------------------------------------------------------------------------------- */
function stgSpenteTxt(st){
  const l = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).filter(function(d){ return st.blocchi[d.k]; }).map(function(d){ return d.n; });
  return l.length ? l.join(', ') : 'Nessuna sezione';
}
/* 0.9.401 BUG-197, Andrea: "testo a sinistra e pulsante al centro, Mancano 145 ore, Restano spenti: nessuna sezione". Tutto al centro;
   l'obiettivo e il conto alla rovescia che scorre (BUG-193); sotto, cosa resta spento davvero: con i Sempre consentiti "tutto tranne"
   le app che consenti, con la lista di blocco le app, i siti e le parole bloccati. Le sezioni di DreamMap in un pannello che si apre.
   La frase della modalita' severa sta dietro alla (i) */
function stgStatoApri(){
  const st = flStagioneAttiva(); if (!st) return;
  const pct = Math.round(st.giorno / st.di * 100);
  const sev = stgSeveraAccesa();
  stgFoglio('<div class="stg-centro stg-stato">'
    + '<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small>'
    + '<h2 class="stg-h">' + stgEsc(st.obiettivo) + '</h2>'
    + flContoHtml(st.fineSpinta, null, 'fl-conto-pag')
    + '<div class="stg-barra"><i style="width:' + pct + '%"></i></div>'
    + '<p class="stg-nota stg-st-n">Giorno ' + st.giorno + ' di ' + st.di + '. Il riposo comincia il ' + stgData(st.fineSpinta) + '.</p>'
    + '<div class="stg-spento" id="stgSpento">' + stgSpentoHtml(st) + '</div>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Torno a spingere</button>'
    + (sev ? '<div class="stg-sev-n"><span>🔒 Modalità severa accesa</span><button type="button" class="stg-i" onclick="stgSeveraInfo()" aria-label="Perché non si può interrompere">i</button></div>'
           : '<button type="button" class="stg-link" onclick="stgInterrompiChiedi()">Interrompi la stagione</button>')
    + '</div>', null, true);
  try{ const box = document.getElementById('stgSpento'); if (box && typeof ubFillIcons === 'function') ubFillIcons(box); }catch(_){ }
  stgSpentoNomi(st);
}
function stgSeveraInfo(){
  const righe = [['🔒', 'La stagione va fino in fondo', 'Finché la modalità severa è accesa, non puoi interromperla.'], ['🔓', 'Quando la severa si spegne', 'In questa pagina torna il pulsante per interrompere la stagione.']];
  const corpo = (typeof flInfoRighe0 === 'function') ? flInfoRighe0(righe) : righe.map(function(r){ return '<p class="stg-p"><b>' + r[1] + '</b><br>' + r[2] + '</p>'; }).join('');
  if (typeof inSheet === 'function') inSheet('<div class="en-foglio stg-sev-f"><h3>Modalità severa accesa</h3>' + corpo + '<button type="button" class="stg-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
  else try{ toast('Finché la modalità severa è accesa, la stagione non si interrompe.'); }catch(_){ }
}
/* cosa resta spento: dalla stagione salvata (0.9.401); per le stagioni cominciate prima, dal programma della stagione o dai consentiti */
function stgSpentoDati(st){
  const s = stgCorrente() || {};
  if (s.modo === 'consentiti'){
    let c = s.consentiti;
    if (!c){ let p = {}; try{ p = (typeof ffPref === 'function') ? ffPref() : {}; }catch(_){ } c = { apps: (p.allow || []).slice(), sites: (p.allowSites || []).slice() }; }
    const apps = (c.apps || []).slice(); if (apps.indexOf('com.dreambrothers.dreammap') < 0) apps.push('com.dreambrothers.dreammap');
    return { modo: 'consentiti', apps: apps, sites: c.sites || [], words: [], nomi: s.nomi || {} };
  }
  let L = s.lista;
  if (!L){ try{ const pr = (typeof PROGRAMS !== 'undefined' ? PROGRAMS : []).filter(function(p){ return p && p.stagione; })[0]; if (pr) L = { apps: pr.apps || [], sites: pr.sites || [], words: pr.keywords || [] }; }catch(_){ } }
  L = L || { apps: [], sites: [], words: [] };
  return { modo: 'lista', apps: L.apps || [], sites: L.sites || [], words: L.words || [], nomi: s.nomi || {} };
}
function stgAppNome(pkg, nomi){
  if (nomi && nomi[pkg]) return nomi[pkg];
  if (pkg === 'com.dreambrothers.dreammap') return 'DreamMap';
  try{ const a = (FLA.list || []).filter(function(x){ return x.packageName === pkg; })[0]; if (a && a.label) return a.label; }catch(_){ }
  try{ if (typeof ubAppLabel === 'function'){ const l = ubAppLabel(pkg); if (l && l !== pkg) return l; } }catch(_){ }
  return '';
}
function stgSpentoHtml(st){
  const d = stgSpentoDati(st);
  const MAX = 8;
  const pill = function(ico, nome){ return '<span class="stg-ch">' + ico + '<span>' + stgEsc(nome) + '</span></span>'; };
  const appPill = function(pkg){ const pz = String(pkg).split('.'), x = pz[1] || pz[0] || String(pkg), n = stgAppNome(pkg, d.nomi) || (x.charAt(0).toUpperCase() + x.slice(1)); return pill('<span class="ub-appico ub-appico-fb stg-ch-i">' + stgEsc(n.charAt(0).toUpperCase()) + '<img class="ub-appico ub-appico-img" data-pkg="' + stgEsc(pkg) + '" alt=""></span>', n).replace('class="stg-ch"', 'class="stg-ch" data-pkg="' + stgEsc(pkg) + '"'); };
  const tutte = d.apps.map(appPill).concat(d.sites.map(function(x){ return pill('<span class="stg-ch-i stg-ch-e" aria-hidden="true">🌐</span>', x); }), d.words.map(function(x){ return pill('<span class="stg-ch-i stg-ch-e" aria-hidden="true">🔤</span>', x); }));
  const chips = tutte.length ? '<div class="stg-chs">' + tutte.slice(0, MAX).join('') + (tutte.length > MAX ? '<span class="stg-ch stg-ch-piu">e altre ' + (tutte.length - MAX) + '</span>' : '') + '</div>' : '';
  /* 0.9.403 BUG-302, Andrea: "Cosa resta spento si leggeva come l'elenco di cio' che e' spento: titolo e sottotitolo diventano una frase
     sola, Resta spento tutto, tranne:, seguita dalle app. Prima di un elenco c'e' sempre il due punti, e dopo si va a capo" (lezione 380) */
  let h = '';
  if (d.modo === 'consentiti') h += '<p class="stg-sp-t stg-sp-uno">Resta spento tutto, tranne:</p>' + chips;
  else if (tutte.length) h += '<p class="stg-sp-t stg-sp-uno">Bloccati fino al ' + stgData(st.fineSpinta - 86400000) + ':</p>' + chips;
  else h += '<p class="stg-sp-t stg-sp-uno">Nessuna app e nessun sito nella lista della stagione.</p>';
  const sez = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).filter(function(x){ return st.blocchi[x.k]; });
  if (sez.length) h += '<details class="stg-dm stg-sp-dm"><summary>' + (sez.length === 1 ? '1 sezione di DreamMap spenta' : sez.length + ' sezioni di DreamMap spente') + '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></summary><ul class="stg-sp-l">' + sez.map(function(x){ return '<li>' + stgEsc(x.n) + '</li>'; }).join('') + '</ul></details>';
  return h;
}
/* i nomi delle app che non conosciamo ancora arrivano dalla lettura delle app installate: la pagina si aggiorna da sola */
function stgSpentoNomi(st){
  const d = stgSpentoDati(st);
  if (!d.apps.some(function(p){ return !stgAppNome(p, d.nomi); }) || typeof flApps !== 'function') return;
  flApps().then(function(){ const box = document.getElementById('stgSpento'); if (!box) return; box.innerHTML = stgSpentoHtml(st); try{ if (typeof ubFillIcons === 'function') ubFillIcons(box); }catch(_){ } }).catch(function(){ });
}
function stgInterrompiChiedi(){
  stgFoglioCorpo('<small class="stg-eti">Interrompere la stagione</small><h2 class="stg-h">Sei sicuro di fermarti?</h2>'
    + '<p class="stg-p">La stagione finisce adesso, le sezioni si riaprono e i giorni fatti restano nella tua storia. Per confermare scrivi la parola MI FERMO.</p>'
    + '<input class="stg-in" id="stgFermo" autocomplete="off" placeholder="MI FERMO">'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Continuo la stagione</button>'
    + '<button type="button" class="stg-link" onclick="stgInterrompi()">Interrompi adesso</button>');
}
function stgInterrompi(){
  const i = document.getElementById('stgFermo');
  if (!i || String(i.value || '').trim().toUpperCase() !== 'MI FERMO'){ try{ toast('Per interrompere scrivi MI FERMO.'); }catch(_){ } return; }
  const s = stgCorrente(); if (s) stgArchivia(s, true);
  stgFoglioChiudi(); stgAggiorna();
  try{ toast('Stagione interrotta. Le sezioni sono di nuovo aperte.'); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   IL RIPOSO E IL BILANCIO (i 14 giorni dopo la spinta)
   --------------------------------------------------------------------------------------- */
function stgNumeri(st){
  const out = { sessioni: 0, minuti: 0, revisioni: 0 };
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (x && x.ok && !x.meditazione && x.at >= st.inizio && x.at < st.fineSpinta){ out.sessioni++; out.minuti += Math.round((x.spentMs || 0) / 60000); }
    });
  }catch(_){ }
  try{ (JSON.parse(localStorage.getItem('fl_revisioni') || '[]') || []).forEach(function(x){ const t = new Date(x.giorno + 'T12:00:00').getTime(); if (t >= st.inizio && t < st.fineSpinta) out.revisioni++; }); }catch(_){ }
  return out;
}
const STG_VICINO = ['Per niente', 'Poco', 'Abbastanza', 'Molto', 'Ce l’ho fatta'];
function stgBilancioApri(){
  const st = flStagioneAttiva(); if (!st || st.fase !== 'reset') return;
  STG.bil = Object.assign({ ottenuto: '', vicino: 0, tengo: '', cambio: '' }, st.bilancio || {});
  stgFoglio(stgBilancioHtml(st), null, true);
}
function stgBilancioHtml(st){
  const b = STG.bil, n = stgNumeri(st);
  const ore = Math.floor(n.minuti / 60);
  return '<div class="stg-ico">' + STG_I.luna + '</div><small class="stg-eti">Il riposo:<br>giorno ' + st.giorno + ' di ' + st.di + '</small>'
    + '<h2 class="stg-h">Il bilancio della stagione</h2>'
    + '<div class="stg-ob"><small>L’obiettivo dei 90 giorni</small><b>' + stgEsc(st.obiettivo) + '</b></div>'
    + '<div class="stg-num"><div><b>' + n.sessioni + '</b><small>sessioni di Full Focus finite</small></div><div><b>' + ore + '</b><small>' + (ore === 1 ? 'ora di lavoro profondo' : 'ore di lavoro profondo') + '</small></div><div><b>' + n.revisioni + '</b><small>sere con la revisione</small></div></div>'
    + '<label class="stg-q">Cosa hai ottenuto in questi 90 giorni?</label><textarea class="stg-area" id="stgB1" rows="3">' + stgEsc(b.ottenuto) + '</textarea>'
    + '<label class="stg-q">Quanto ti sei avvicinato al tuo obiettivo?</label><div class="stg-chips">' + STG_VICINO.map(function(t, i){ return '<button type="button" class="stg-chip' + (b.vicino === i + 1 ? ' on' : '') + '" onclick="stgVicino(' + (i + 1) + ')">' + t + '</button>'; }).join('') + '</div>'
    + '<label class="stg-q">Cosa tieni per la prossima stagione?</label><textarea class="stg-area" id="stgB2" rows="2">' + stgEsc(b.tengo) + '</textarea>'
    + '<label class="stg-q">Cosa cambi?</label><textarea class="stg-area" id="stgB3" rows="2">' + stgEsc(b.cambio) + '</textarea>'
    + '<button type="button" class="stg-cta" onclick="stgBilancioSalva()">Salvo il bilancio</button>'
    + '<p class="stg-nota">Il riposo finisce il ' + stgData(st.fineReset - 86400000) + '. Poi puoi cominciare una stagione nuova.</p>';
}
function stgBilancioLeggiCampi(){
  const v = function(id){ const e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; };
  STG.bil.ottenuto = v('stgB1'); STG.bil.tengo = v('stgB2'); STG.bil.cambio = v('stgB3');
}
function stgVicino(i){ stgBilancioLeggiCampi(); STG.bil.vicino = i; const st = flStagioneAttiva(); if (st) stgFoglioCorpo(stgBilancioHtml(st)); }
function stgBilancioSalva(){
  stgBilancioLeggiCampi();
  if (!STG.bil.ottenuto){ try{ toast('Scrivi almeno cosa hai ottenuto.'); }catch(_){ } return; }
  const s = stgCorrente(); if (!s) return;
  s.bilancio = Object.assign({}, STG.bil, { at: Date.now() });
  stgScriviJ(STG_KEY, s);
  stgFoglioChiudi(); stgPaint();
  try{ toast('Bilancio salvato. Adesso riposa davvero.'); }catch(_){ }
}
/** Per il tuo agente personale: a che punto e' la stagione. */
function stgPerAgente(){
  const st = flStagioneAttiva(); if (!st) return '';
  return st.fase === 'spinta'
    ? 'Stagione di spinta (Monk mode, 90 giorni): giorno ' + st.giorno + ' di 90, obiettivo "' + st.obiettivo + '". Niente distrazioni.'
    : 'Riposo dopo la stagione di spinta: giorno ' + st.giorno + ' di 14. ' + (st.bilancio ? 'Bilancio: ottenuto "' + st.bilancio.ottenuto + '", cambia "' + (st.bilancio.cambio || '') + '".' : 'Bilancio ancora da fare.');
}

/* ---------------------------------------------------------------------------------------
   LE PORTE: la card nella Mappa (vista Roadmap) e la prima card delle Sfide di Dream
   --------------------------------------------------------------------------------------- */
function stgCardHtml(){
  const st = flStagioneAttiva();
  /* 0.9.275, Andrea: non una sezione della Roadmap ma una sfida, una proposta del gioco. Finche' non e'
     cominciata vive come tappa della mappa (sentiero-mappa.js, nodo "stg") e come card delle Sfide di
     Dream; qui compare solo il contatore, mentre la stagione e' in corso. */
  if (!st) return '';
  if (st.fase === 'spinta'){
    const pct = Math.round(st.giorno / st.di * 100);
    return '<div class="stg-card on" onclick="stgStatoApri()" role="button"><span class="stg-c-ico">' + STG_I.monte + '</span><div><small>La stagione di spinta</small>'
      + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><div class="stg-barra"><i style="width:' + pct + '%"></i></div><i>' + stgEsc(st.obiettivo) + '</i></div>' + STG_I.avanti + '</div>';
  }
  return '<div class="stg-card riposo" onclick="stgBilancioApri()" role="button"><span class="stg-c-ico">' + STG_I.luna + '</span><div><small>Il riposo dopo la stagione</small>'
    + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><i>' + (st.bilancio ? 'Bilancio fatto. Rileggilo quando vuoi.' : 'Fai il bilancio dei 90 giorni.') + '</i></div>' + STG_I.avanti + '</div>';
}
function stgPaint(){
  if (typeof document === 'undefined') return;
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  const rif = document.getElementById('mppPianoRm') || document.getElementById('mppSentiero');
  if (!rif || !rif.parentNode) return;
  let h = document.getElementById('mppStagione');
  if (!h){ h = document.createElement('div'); h.id = 'mppStagione'; h.className = 'mpp-slot'; }
  if (rif.nextElementSibling !== h) rif.parentNode.insertBefore(h, rif.nextSibling);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  /* 0.9.288, Andrea: "dopo averla accettata il pannello della stagione non compare piu' nella Mappa": si nascondeva
     nella vista "Pianifica tu". La stagione vale per tutte e due le strade. */
  h.classList.remove('mpp-via');
  const html = stgCardHtml();
  if (h.dataset.html !== html){ h.dataset.html = html; h.innerHTML = html; }
}
/** La card per il carosello delle Sfide (sfide-dream.js), finche' la stagione non e' cominciata. */
function stgSfidaCard(){
  if (flStagioneAttiva()) return null;
  return { k: 'stagione', ico: '🏔️', img: 'img/sfide/spinta.jpg', t: 'La stagione di spinta',
    s: '90 giorni come se la tua vita dipendesse dal tuo obiettivo. Niente distrazioni dentro DreamMap. Poi 14 giorni di riposo e il bilancio.',
    meta: '90 giorni', fatta: false, via: 'stgApri()' };
}

if (typeof document !== 'undefined'){
  (function(){
    if (typeof rmpPaint === 'function' && !rmpPaint.__stg){ const v = rmpPaint; const w = function(){ const r = v.apply(this, arguments); try{ stgPaint(); }catch(_){ } return r; }; w.__stg = true; window.rmpPaint = w; }
    if (typeof rnPerAgente === 'function' && !rnPerAgente.__stg){ const v2 = rnPerAgente; const w2 = function(){ return [v2.apply(this, arguments), stgPerAgente()].filter(Boolean).join(' '); }; w2.__stg = true; window.rnPerAgente = w2; }
  })();
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(stgPaint, 120); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(stgPaint, 600); });
  setTimeout(stgPaint, 1500);
  setInterval(stgPaint, 60000);
  (function(){
    const st = document.createElement('style');
    st.textContent = [
      '#mppStagione{padding:0 16px;margin:10px 0 12px}#mppStagione:empty{display:none}',
      '.stg-card{display:flex;align-items:center;gap:12px;padding:15px 16px;border-radius:20px;background:linear-gradient(135deg,#0075E3,#005BB0);color:#FFFFFF;cursor:pointer;box-shadow:0 10px 24px rgba(0,91,176,.22)}',
      '.stg-card > div{flex:1;min-width:0}.stg-card > svg{flex:none;opacity:.85}.stg-c-ico{flex:none;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:rgba(255,255,255,.16);color:#FFFFFF}',
      '.stg-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#BCE0FF}',
      '.stg-card b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}',
      '.stg-card i{display:block;margin-top:4px;font:600 12.5px/1.4 var(--font-body);font-style:normal;color:#D2ECFF;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.stg-card.riposo{background:linear-gradient(135deg,#3F9FF4,#0075E3)}',
      '.stg-barra{height:8px;border-radius:8px;background:var(--blue-soft,#E3F1FF);overflow:hidden;margin:8px 0 12px}.stg-card .stg-barra{background:rgba(255,255,255,.22);margin:8px 0 0}.stg-barra i{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,#0075E3,#3F9FF4);margin:0}.stg-card .stg-barra i{background:#FFFFFF}',
      '.stg-velo{position:fixed;inset:0;z-index:10040;display:flex;align-items:flex-end;justify-content:center}',
      '.stg-scrim{position:absolute;inset:0;background:rgba(0,30,68,.55)}',
      '.stg-f{position:relative;width:100%;max-width:520px;max-height:92vh;border-radius:26px 26px 0 0;background:var(--card,#FFFFFF);color:var(--ink,#0A1A2F);box-shadow:0 -10px 40px rgba(0,30,68,.28);display:flex;flex-direction:column;overflow:hidden}',
      '.stg-fin{overflow:auto;padding:24px 20px calc(24px + env(safe-area-inset-bottom))}',
      '.stg-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.35);color:#FFFFFF;display:grid;place-items:center;z-index:3;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}',
      '.stg-hero{position:relative;margin:-24px -20px 16px;height:178px;overflow:hidden}.stg-hero img{width:100%;height:100%;object-fit:cover;display:block}',
      '.stg-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 30%,rgba(0,30,68,.78))}',
      '.stg-hero-t{position:absolute;left:20px;right:20px;bottom:14px;z-index:1;color:#FFFFFF}.stg-hero-t small{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#BCE0FF}.stg-hero-t h2{margin:2px 0 0;font:900 26px/1.15 var(--font-display,var(--font-body))}',
      '.stg-lead{margin:0 0 14px;font:700 17px/1.45 var(--font-body);color:var(--navy,#001E44)}',
      '.stg-linea{display:flex;gap:4px;height:46px;border-radius:14px;overflow:hidden;margin:0 0 6px}.stg-linea > div{display:flex;flex-direction:column;justify-content:center;padding:0 12px;color:#FFFFFF}.stg-linea b{font:800 15px/1.1 var(--font-body)}.stg-linea small{font:600 11.5px var(--font-body);opacity:.9}',
      '.stg-l-spinta{flex:90;background:linear-gradient(90deg,#0075E3,#3F9FF4)}.stg-l-riposo{flex:24;background:var(--dream);color:#0E2350!important}.stg-l-riposo b,.stg-l-riposo small{color:#0E2350}',
      '.stg-date{display:flex;justify-content:space-between;margin:0 0 14px;font:600 12px var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-punti{list-style:none;margin:0 0 6px;padding:0;display:grid;gap:10px}.stg-punti li{display:flex;align-items:center;gap:12px;font:500 15px/1.45 var(--font-body);color:var(--ink,#0A1A2F)}.stg-punti b{color:#0075E3}',
      '.stg-punti i{flex:none;width:36px;height:36px;border-radius:12px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;font-style:normal;font-size:17px}',
      '.stg-ico{width:58px;height:58px;border-radius:18px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;margin-bottom:12px}',
      '.stg-eti{display:block;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}',
      '.stg-h{margin:6px 40px 10px 0;font:800 24px/1.25 var(--font-display,var(--font-body));color:var(--navy,#001E44)}',
      '.stg-p{margin:0 0 14px;font:500 16px/1.55 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-nota{margin:12px 0 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-tappe{display:grid;gap:10px;margin:6px 0 14px}.stg-tappe > div{padding:14px;border-radius:16px;background:var(--blue-soft,#E3F1FF)}.stg-tappe b{display:block;font:800 16px var(--font-body);color:#0075E3}.stg-tappe p{margin:4px 0 0;font:500 15px/1.5 var(--font-body);color:var(--ink,#0A1A2F)}',
      '.stg-cta{display:block;width:100%;margin-top:14px;padding:16px;border:0;border-radius:999px;background:#0075E3;color:#FFFFFF;font:800 17px var(--font-body);box-shadow:0 8px 20px rgba(0,117,227,.28)}',
      '.stg-link{display:block;width:100%;margin-top:6px;padding:12px;border:0;background:none;color:var(--muted,#4A5A72);font:700 15px var(--font-body)}',
      '.stg-area,.stg-in{display:block;width:100%;box-sizing:border-box;padding:14px;border-radius:14px;border:1.5px solid var(--line,#DCE8F5);background:var(--bg,#F4F9FF);color:var(--ink,#0A1A2F);font:500 16px/1.5 var(--font-body);resize:vertical}',
      '.stg-area::placeholder,.stg-in::placeholder{color:var(--faint,#8B99AC)}',
      '.stg-righe{display:grid;gap:12px;margin:0 0 28px}.stg-riga{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);border:1.5px solid var(--line,#DCE8F5)}.stg-riga > div{flex:1;min-width:0}',
      '.stg-riga b{display:block;font:700 15px/1.35 var(--font-body);color:var(--ink,#0A1A2F)}.stg-riga small{display:block;margin-top:2px;font:500 13px/1.4 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-ob{padding:16px 18px;border-radius:16px;background:var(--dream);margin:0 0 28px}.stg-ob small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#005BB0}.stg-ob b{display:block;margin-top:4px;font:700 16px/1.4 var(--font-body);color:#0E2350}',
      '.stg-num{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:4px 0 12px}.stg-num > div{padding:12px 8px;border-radius:14px;background:var(--blue-soft,#E3F1FF);text-align:center}.stg-num b{display:block;font:800 24px var(--font-body);color:#0075E3}.stg-num small{display:block;margin-top:2px;font:600 12px/1.3 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-q{display:block;margin:14px 0 6px;font:700 15.5px/1.4 var(--font-body);color:var(--navy,#001E44)}',
      /* 0.9.276, Andrea: "tutto ammassato, nessuna distanza fra un elemento e l'altro: piuttosto una pagina a schermo
         intero". La stagione e' una pagina intera, con lo spazio della skill ui-scansionabile (16/24/32 px). */
      '.stg-pagina{align-items:stretch}.stg-pagina .stg-scrim{display:none}.stg-pagina .stg-f{max-width:none;max-height:none;height:100%;border-radius:0}',
      '.stg-pagina .stg-fin{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:24px 24px calc(28px + env(safe-area-inset-bottom))}',
      /* 0.9.288, Andrea: "la barra 90/14 tagliata, l'intestazione tagliata, Non adesso in bella vista". La colonna era alta
         quanto lo schermo e schiacciava i suoi figli invece di scorrere: adesso nessuno si schiaccia, la foto in cima e'
         grande e i pulsanti si trovano scorrendo. */
      '.stg-pagina .stg-fin > *{flex-shrink:0}',
      '.stg-pagina .stg-hero{height:clamp(300px,50vh,440px)!important}',
      '.stg-pagina .stg-linea{height:auto!important;min-height:58px}.stg-linea > div{padding:8px 12px}',
      '.stg-riga.spenta b{color:var(--muted,#4A5A72)}.stg-riga.spenta small{color:#E5484D;font-weight:700}',
      '.stg-area{min-height:110px}.stg-area:focus{outline:none;border-color:#0075E3}body.dark .stg-area:focus{border-color:#3F9FF4}',
      '.stg-pagina .stg-hero{margin:-24px -24px 28px;height:clamp(200px,32vh,280px)}.stg-pagina .stg-hero-t{left:24px;right:24px;bottom:20px}.stg-pagina .stg-hero-t h2{font-size:30px;margin-top:6px}',
      '.stg-pagina .stg-lead{margin:0 0 28px;font-size:18px;line-height:1.5}',
      '.stg-pagina .stg-linea{height:54px;margin:0 0 10px}.stg-pagina .stg-date{margin:0 0 36px}',
      '.stg-pagina .stg-punti{gap:22px;margin:0 0 40px}.stg-pagina .stg-punti li{gap:16px;font-size:16px}.stg-pagina .stg-punti i{width:44px;height:44px;border-radius:14px}',
      '.stg-pagina .stg-cta{margin-top:auto}.stg-pagina .stg-link{margin-top:12px}',
      '.stg-pagina .stg-h{margin:10px 0 16px;font-size:26px}.stg-pagina .stg-p{margin:0 0 24px}.stg-pagina .stg-eti{margin-top:8px}',
      '.stg-pagina .stg-area,.stg-pagina .stg-righe,.stg-pagina .stg-ob,.stg-pagina .stg-barra{margin-bottom:28px}',
      /* 0.9.277, Andrea: "il margine e' inesistente nel popover". Bordi del foglio 28px, titolo staccato, pulsante con aria. */
      '.stg-fin{padding:32px 28px calc(28px + env(safe-area-inset-bottom))}',
      /* 0.9.372, Andrea: "l'immagine in cima al popover ha un margine ai lati e sopra: deve toccare i bordi" */
      '.stg-velo:not(.stg-pagina) .stg-hero{margin:-32px -28px 24px!important;height:200px}',
      '.stg-dur-k{display:none}.stg-dur{margin-bottom:8px}',
      'body.dark .stg-f .stg-dur-l button.on{background:#E63946!important;border-color:#E63946!important;color:#fff!important}',
      '.stg-modo{display:flex;align-items:center;gap:14px;width:100%;margin:0 0 14px;padding:16px;border-radius:18px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);text-align:left;cursor:pointer}.stg-modo i{flex:none;width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);font-style:normal;font-size:22px}.stg-modo b{display:block;font:800 16px var(--font-body);color:var(--navy,#001E44)}.stg-modo small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#4A5A72)}.stg-modo.on{border-color:#0075E3;box-shadow:inset 0 0 0 1.5px #0075E3}body.dark .stg-modo{background:#12203A;border-color:#22345A}body.dark .stg-modo b{color:#fff}',
      '.stg-h{margin:12px 48px 28px 0}.stg-p{margin:0 0 24px}.stg-cta{margin-top:36px}.stg-q{margin:24px 0 12px}.stg-chips{gap:10px}',
      '.stg-chips{display:flex;flex-wrap:wrap;gap:8px}.stg-chip{padding:10px 14px;border-radius:999px;border:1.5px solid var(--line,#DCE8F5);background:transparent;color:var(--ink,#0A1A2F);font:700 14.5px var(--font-body)}.stg-chip.on{background:#0075E3;border-color:#0075E3;color:#FFFFFF}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { flStagioneAttiva: flStagioneAttiva, stgArchivia: stgArchivia, STG_SPINTA: STG_SPINTA, STG_RESET: STG_RESET };
}

/* 0.9.363, Andrea: "la stagione di spinta, COME SE LA TUA VITA DIPENDESSE DA QUESTO, deve essere la prima slide dello slideshow
   della scheda Sogno: e' un evento importante". Solo durante la spinta. */
/* 0.9.373, Andrea: "con la stagione di spinta la scadenza e' piu' importante di qualunque altra data: e' la prima slide della scheda Sogno" */
function stgHeroSlideHtml(){
  let st = null; try{ st = flStagioneAttiva(); }catch(_){ st = null; }
  if (!st || st.fase !== 'spinta') return '';
  setTimeout(flContoAvvia, 0);
  return '<article class="bh-slide stg-hs" data-i="8" style="--bh-img:url(\'img/sfide/spinta.jpg\');--bh-pos:center 40%"><div class="bh-img"></div><span class="bh-ov"></span>'
    /* 0.9.402 BUG-266, Andrea: "il titolo Come se la tua vita dipendesse da questo va a capo": un titolo breve e forte, su una riga */
    + '<div class="bh-stack stg-hs-in"><small>Niente altro conta</small><b>' + stgEsc(st.obiettivo) + '</b>'
    /* 0.9.401 BUG-193: al posto di "Mancano 146 ore" il conto alla rovescia che scorre, nel formato scelto in Personalizza */
    + flContoHtml(st.fineSpinta, null, 'fl-conto-hero') + '<span>Scadenza: ' + stgData(st.fineSpinta - 86400000) + '</span>'
    + '<button type="button" class="stg-cta rossa" onclick="stgStatoApri()">Vai alla stagione</button></div></article>';
}
function stgSlideHtml(){
  let st = null; try{ st = flStagioneAttiva(); }catch(_){ st = null; }
  if (!st || st.fase !== 'spinta') return '';
  setTimeout(flContoAvvia, 0);
  const conta = st.adhd ? flContoHtml(st.fineSpinta, null, 'fl-conto-hero') : 'Giorno ' + st.giorno + ' di ' + st.di;
  return '<div class="stg-sl"><small class="stg-sl-k">Niente altro conta</small>'
    + '<b class="stg-sl-ob">' + stgEsc(st.obiettivo) + '</b>'
    + '<div class="stg-sl-c">' + (st.adhd ? conta : '<span>' + conta + '</span>') + '<div class="stg-barra"><i style="width:' + Math.round(st.giorno / st.di * 100) + '%"></i></div></div>'
    + '<button type="button" class="stg-cta stg-sl-go" onclick="stgStatoApri()">' + (st.adhd ? 'Fai la cosa di adesso' : 'Vai alla stagione') + '</button></div>';
}
(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    /* 0.9.368, Andrea: "i pulsanti della durata e la riga della modalita' ADHD bianchi su bianco": il foglio e' chiaro, i colori seguono il tema */
    '.stg-f .stg-dur-l button{border-color:#C8EFFD!important;background:#F0FBFF!important;color:#001E44!important}.stg-f .stg-dur-l button.on{background:#E63946!important;border-color:#E63946!important;color:#fff!important}',
    'body.dark .stg-f .stg-dur-l button{background:#0E1D3D!important;border-color:#1F3A66!important;color:#fff!important}',
    '.stg-f .stg-adhd{border-color:#C8EFFD!important;background:#F0FBFF!important;color:#001E44!important}.stg-f .stg-adhd small{color:#3F5A7A!important}.stg-f .stg-dur-k{color:#0075E3!important}',
    'body.dark .stg-f .stg-adhd{background:#0E1D3D!important;border-color:#1F3A66!important;color:#fff!important}body.dark .stg-f .stg-adhd small{color:#BFD3EC!important}body.dark .stg-f .stg-dur-k{color:#8CC6FF!important}',
    '.stg-dur{margin:22px 0 26px;text-align:left}.stg-dur-k{margin:0 0 10px;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF;text-align:center}',
    '.stg-dur-l{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.stg-dur-l button{border:1.5px solid rgba(188,224,255,.35);background:rgba(255,255,255,.06);color:#fff;padding:9px 14px;border-radius:99px;font:700 14px var(--font-body);cursor:pointer}.stg-dur-l button.on{background:#E63946;border-color:#E63946}',
    '.stg-adhd{display:flex;align-items:center;gap:14px;width:100%;margin-top:16px;padding:14px 16px;border-radius:16px;border:1px solid rgba(188,224,255,.25);background:rgba(255,255,255,.05);color:#fff;text-align:left;cursor:pointer}.stg-adhd span{flex:1;min-width:0}.stg-adhd b{display:block;font:800 15px var(--font-body)}.stg-adhd small{display:block;margin-top:4px;font:500 13px/1.4 var(--font-body);color:#BFD3EC}.stg-adhd .switch{flex:none;pointer-events:none}',
    '.stg-centro{display:flex;flex-direction:column;align-items:center;text-align:center}.stg-centro > *{align-self:stretch}.stg-centro .stg-h,.stg-centro .stg-p,.stg-centro .stg-nota,.stg-centro .stg-lead{text-align:center;margin-left:0!important;margin-right:0!important}',
    '.stg-cta.rossa{background:#E63946!important;box-shadow:0 8px 20px rgba(230,57,70,.3)!important}',
    '.stg-testa{position:relative;display:flex;align-items:center;justify-content:center;min-height:40px;margin:0 0 6px}.stg-back{position:absolute;left:0;top:0;width:40px;height:40px;border-radius:50%;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);color:var(--navy,#001E44);display:grid;place-items:center;cursor:pointer}body.dark .stg-back{background:#12203A;border-color:#22345A;color:#fff}',
    '.stg-centro .stg-linea{margin:4px 0 22px}.stg-centro .stg-dur{margin-top:0}',
    '.stg-linea2{height:auto!important;min-height:54px!important;margin:4px 0 24px!important;border-radius:14px!important}.stg-linea2 > div{padding:8px 12px!important;min-width:0}.stg-linea2 .stg-l-spinta{min-width:96px}.stg-linea2 .stg-l-riposo{min-width:72px}.stg-linea2 b,.stg-linea2 small{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stg-linea2 .stg-l-spinta b,.stg-linea2 .stg-l-spinta small{color:#fff!important}',
    '.stg-linea-w{margin:4px 0 24px}.stg-linea-w .stg-linea,.stg-centro .stg-linea-w .stg-linea,.stg-pagina .stg-linea-w .stg-linea{height:16px!important;min-height:0!important;margin:0!important;border-radius:99px}.stg-linea-w .stg-linea > div{padding:0!important}',
    '.stg-linea-l{display:flex;justify-content:space-between;gap:12px;margin-top:10px;font:600 13.5px var(--font-body);color:var(--muted,#4A5A72)}.stg-linea-l span:first-child{text-align:left}.stg-linea-l span:last-child{text-align:right}.stg-linea-l b{font-weight:800;color:var(--navy,#001E44)}body.dark .stg-linea-l b{color:#fff}',
    '.stg-centro.stg-sx,.stg-centro.stg-sx .stg-lead{text-align:left!important}.stg-centro.stg-sx .stg-cta,.stg-centro.stg-sx .stg-link{text-align:center}',
    '.stg-sn{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:4px 0 22px}.stg-sn button{padding:14px;border-radius:16px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);font:800 15px var(--font-body);color:var(--navy,#001E44);cursor:pointer}.stg-sn button.on{border-color:#0075E3;background:#0075E3;color:#fff}body.dark .stg-sn button{background:#12203A;border-color:#22345A;color:#fff}body.dark .stg-sn button.on{background:#0075E3;border-color:#0075E3}',
    '.stg-dm{border:1.5px solid var(--line,#DCE8F5);border-radius:16px;text-align:left}.stg-dm summary{list-style:none;display:flex;align-items:center;justify-content:center;gap:8px;padding:14px;font:800 15px var(--font-body);color:var(--navy,#001E44);cursor:pointer}.stg-dm summary::-webkit-details-marker{display:none}.stg-dm[open] summary svg{transform:rotate(180deg)}.stg-dm .stg-righe{padding:0 12px 12px;margin:0}body.dark .stg-dm{border-color:#22345A}body.dark .stg-dm summary{color:#fff}',
    '.stg-link.sotto{margin-top:-4px;color:#0075E3;text-decoration:underline;text-underline-offset:3px}body.dark .stg-link.sotto{color:#8CC6FF}',
    '.stg-hs-in{display:flex;flex-direction:column;align-items:center;text-align:center;padding:60px 24px 70px;color:#fff}.stg-hs-in small{font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#FF8A9B}.stg-hs-in b{margin:14px 0 18px;font:800 23px/1.3 var(--font-display)}.stg-hs-in em{font:900 34px var(--font-display);font-style:normal}.stg-hs-in span{margin:6px 0 26px;font:700 14px var(--font-body);color:#BCE0FF}.stg-hs-in .stg-cta{width:auto;padding:14px 28px}',
    '.stg-sl{display:flex;flex-direction:column;align-items:center;text-align:center;padding:26px 20px 22px;border-radius:22px;background:linear-gradient(180deg,#001E44 0%,#0B2A5C 100%);color:#fff}',
    '.stg-sl-k{font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#FF8A9B}.stg-sl-ob{display:block;margin:14px 0 22px;font:800 21px/1.3 var(--font-display);color:#fff}',
    '.stg-sl-c{width:100%;margin-bottom:28px}.stg-sl-c span{display:block;margin-bottom:10px;font:800 15px var(--font-body);color:#BCE0FF}.stg-sl-go{margin:0!important;width:100%}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* 0.9.377, Andrea: "nella prima schermata il testo e' a sinistra, nel passo 1 di 4 al centro: o tutto a sinistra o tutto al centro. E la freccia
   indietro deve stare alla stessa altezza e alla stessa distanza dal bordo della X". Tutti i passi a sinistra come l'intro (i pulsanti con il
   testo al centro); in cima una riga sola: freccia a sinistra, Passo 1 di 4 al centro, la X a destra, alla stessa altezza */
(function(){ const st = document.createElement('style'); st.textContent = '.stg-centro.stg-sx .stg-h,.stg-centro.stg-sx .stg-p,.stg-centro.stg-sx .stg-nota,.stg-centro.stg-sx p,.stg-centro.stg-sx .stg-dur-k{text-align:left!important}.stg-centro.stg-sx .stg-dur-l{justify-content:flex-start!important}.stg-linea2 > div{align-items:flex-start!important;text-align:left!important}'
  + '#stgVelo .stg-testa{position:static!important;height:26px;min-height:0!important;margin:0 0 10px!important}#stgVelo .stg-testa .stg-eti{position:absolute;top:12px;left:60px;right:60px;height:38px;display:flex;align-items:center;justify-content:center;z-index:2}#stgVelo .stg-back{position:absolute!important;top:12px!important;left:12px!important;width:38px!important;height:38px!important;z-index:3}'; document.head.appendChild(st); })();

/* LA LISTA DELLA STAGIONE (0.9.380). Una categoria sua, come i sempre consentiti: le app, i siti e le parole bloccati solo per la spinta.
   La prima volta parte dalle app che hai segnato come distrazioni e dai social sul web. STG.bozza.lista = { apps, sites, words } */
const STG_LISTA = { tab: 'apps', apps: null };
function stgLista(){
  const b = STG.bozza || {};
  if (!b.lista){
    let apps = []; try{ const c = (typeof insCats === 'function') ? insCats() : {}; apps = Object.keys(c).filter(function(k){ return c[k] === 'distr'; }); }catch(_){ apps = []; }
    const siti = (typeof DISTRACTIONS !== 'undefined') ? DISTRACTIONS.slice() : ['instagram.com', 'tiktok.com', 'facebook.com', 'youtube.com'];
    b.lista = { apps: apps, sites: siti, words: [] };
  }
  return b.lista;
}
function stgListaTxt(){ const L = stgLista(), n = L.apps.length + L.sites.length + L.words.length; return n ? 'Nella lista: ' + n + '. Cambia la lista' : 'Scegli cosa bloccare'; }
/* 0.9.381, Andrea: "nella lista della stagione le app e i siti non hanno la miniatura e non c'e' la barra per cercare; il pulsante Aggiungi
   e' diverso da quello dei Sempre consentiti (sotto, non accanto alla casella); e quelli scelti non vengono per primi, come nel blocco
   rapido e nei programmi". Lo stesso contenuto delle schede dei Sempre consentiti: icona, ricerca, casella a destra, scelti in cima */
async function stgListaApri(tab){
  if (tab) STG_LISTA.tab = tab;
  if (STG_LISTA.tab === 'apps' && !STG_LISTA.apps){ try{ const r = await flApps(); STG_LISTA.apps = ((r && r.apps) || []).slice().sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); }); }catch(_){ STG_LISTA.apps = []; } }
  const L = stgLista(), t = STG_LISTA.tab;
  const check = '<svg viewBox="0 0 14 14" width="13" height="13" aria-hidden="true"><path d="M2 7.5L5.5 11L12 3.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const tabs = [['apps', 'App'], ['sites', 'Siti'], ['words', 'Parole']].map(function(x){ return '<button type="button" class="' + (t === x[0] ? 'on' : '') + '" onclick="stgListaApri(\'' + x[0] + '\')">' + (t === x[0] ? check : '') + x[1] + '</button>'; }).join('');
  const cerca = (typeof FF_ICO_SEARCH !== 'undefined') ? FF_ICO_SEARCH : '🔎';
  let corpo = '';
  if (t === 'apps'){
    if (STG_LISTA.apps && STG_LISTA.apps.length){
      /* i scelti per primi, poi gli altri in ordine alfabetico */
      const l = STG_LISTA.apps.slice().sort(function(a, b){ const sa = L.apps.indexOf(a.packageName) >= 0 ? 0 : 1, sb = L.apps.indexOf(b.packageName) >= 0 ? 0 : 1; return sa - sb; });
      corpo = '<div class="fl-search">' + cerca + '<input id="stgListaQ" placeholder="Cerca un’app…" oninput="stgListaFiltra()" autocomplete="off"></div>'
        + '<div class="ff-picklist" id="stgListaL">' + l.map(function(a){
            const on = L.apps.indexOf(a.packageName) >= 0, lettera = stgEsc((a.label || '?').charAt(0).toUpperCase());
            return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + lettera + '<img class="ub-appico ub-appico-img" data-pkg="' + stgEsc(a.packageName) + '" alt=""></span>'
              + '<span class="ff-pickname">' + stgEsc(a.label || a.packageName) + '</span>'
              + '<input type="checkbox"' + (on ? ' checked' : '') + ' onchange="stgListaApp(\'' + stgEsc(a.packageName) + '\',this.checked)"></label>';
          }).join('') + '</div>';
    } else corpo = '<p class="ff-empty">Le app installate si leggono nell’app sul telefono.</p>';
  } else {
    const k = t === 'sites' ? 'sites' : 'words';
    corpo = '<div class="fl-search"><span class="fl-plus">＋</span><input id="stgListaIn" placeholder="' + (k === 'sites' ? 'Aggiungi un sito (es. instagram.com)' : 'Aggiungi una parola (es. calcio)') + '" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();stgListaAggiungi(\'' + k + '\')}"></div>'
      + '<button type="button" class="ghostmini ff-addsite" onclick="stgListaAggiungi(\'' + k + '\')">Aggiungi</button>'
      + (L[k].length ? '<div class="ff-picklist">' + L[k].map(function(v, i){ return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + (k === 'sites' ? '🌐' : '🔤') + '</span><span class="ff-pickname">' + stgEsc(v) + '</span><button type="button" class="ff-rm" aria-label="Togli" onclick="stgListaTogli(\'' + k + '\',' + i + ')">✕</button></div>'; }).join('') + '</div>'
        : '<p class="ff-empty">' + (k === 'sites' ? 'Nessun sito ancora. Quelli che aggiungi restano chiusi fino alla fine della spinta.' : 'Nessuna parola ancora. Un indirizzo che la contiene resta chiuso fino alla fine della spinta.') + '</p>');
  }
  const html = '<div class="stg-lista"><h3>La lista della stagione</h3><p class="stg-p stg-lista-p">Quello che scegli qui resta bloccato fino alla fine della spinta.</p><div class="ff-seg stg-seg">' + tabs + '</div>' + corpo
    + '<button type="button" class="stg-cta" onclick="inSheetChiudi();stgVai(\'blocco\')">Fatto</button></div>';
  if (typeof inSheet === 'function') inSheet('<div class="en-foglio">' + html + '</div>');
  try{ const bx = document.getElementById('stgListaL'); if (bx && typeof ubFillIcons === 'function') ubFillIcons(bx); }catch(_){ }
}
function stgListaFiltra(){
  const q = ((document.getElementById('stgListaQ') || {}).value || '').toLowerCase();
  document.querySelectorAll('#stgListaL .ff-pickrow').forEach(function(r){ r.style.display = r.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none'; });
}
function stgListaApp(pkg, on){ const L = stgLista(), i = L.apps.indexOf(pkg); if (on && i < 0) L.apps.push(pkg); if (!on && i >= 0) L.apps.splice(i, 1); try{ flVibra(6); }catch(_){ } }
function stgListaAggiungi(k){
  const inp = document.getElementById('stgListaIn'); let v = String(inp ? inp.value : '').trim().toLowerCase(); if (!v) return;
  if (k === 'sites') v = v.replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
  const L = stgLista(); if (L[k].indexOf(v) < 0) L[k].push(v);
  stgListaApri();
}
function stgListaTogli(k, i){ const L = stgLista(); L[k].splice(i, 1); stgListaApri(); }
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* 0.9.379, Andrea: "le opzioni dei giorni non scelte hanno il bordo azzurrino: le voglio come i block swatch non selezionati del mio
     tema, con gli angoli da 50 pixel. Solo il pannello della modalita' ADHD tiene il bordo azzurro" */
  '.stg-f .stg-dur-l button:not(.on){background:#fff!important;border:1px solid #DEDEDE!important;color:#1C1C1C!important;border-radius:50px!important;font-weight:600!important}'
  + 'body.dark .stg-f .stg-dur-l button:not(.on){background:#0B1220!important;border-color:#2A3346!important;color:#E8F1FF!important}'
  + '.stg-modo-x{display:inline-block;margin-top:10px;padding:8px 14px;border-radius:99px;background:#0075E3;color:#fff!important;font:700 13.5px var(--font-body)}'
  + '.stg-lista h3{text-align:center;margin:4px 0 18px}.stg-lr{display:flex;align-items:center;gap:12px;width:100%;margin:0 0 8px;padding:12px 14px;border-radius:16px;border:1.5px solid #DEDEDE;background:#fff;text-align:left;cursor:pointer;font:inherit}'
  + '.stg-lr.on{border-color:#0075E3;background:#F0FBFF}.stg-lr-i{font-size:22px}.stg-lr-t{flex:1;min-width:0}.stg-lr-t b{display:block;font:800 14.5px var(--font-display);color:#001E44}.stg-lr-t small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:#5B6B85}'
  + '.stg-lr-c{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid #C9D6EA}.stg-lr.on .stg-lr-c{background:#0075E3;border-color:#0075E3;box-shadow:inset 0 0 0 3px #fff}'
  + 'body.dark .stg-lr{background:#0B1220;border-color:#2A3346}body.dark .stg-lr.on{background:#14305E;border-color:#3F9FF4}body.dark .stg-lr-t b{color:#fff}body.dark .stg-lr-t small{color:#BFD3EC}'
  + '.stg-lista .stg-link{display:block;margin:14px auto 6px}.stg-lista .stg-cta{width:100%;margin-top:12px}'; document.head.appendChild(st); })();
/* tornando a casa dopo aver creato i blocchi, la stagione si riapre al passo 2 */
document.addEventListener('fl:tab', function(){
  if (STG.riapri && STG.bozza && !document.getElementById('stgVelo')){ const p = STG.riapri; STG.riapri = ''; setTimeout(function(){ try{ STG.passo = p; stgFoglio(stgPassoHtml(), null, false); }catch(_){ } }, 300); }
});
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.stg-lista h3{padding:0 40px}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.stg-modo-l{display:inline-block;margin-top:10px;color:#0075E3;font:700 14px var(--font-body);text-decoration:underline;text-underline-offset:4px}body.dark .stg-modo-l{color:#8CC6FF}'
  + '.stg-lista-p{text-align:center;margin:-8px 0 16px!important}.stg-ltab{display:flex;gap:6px;background:#EEF2F7;border-radius:99px;padding:5px;margin-bottom:16px}.stg-ltab button{flex:1;border:0;border-radius:99px;background:transparent;padding:10px;font:700 14px var(--font-body);color:var(--muted);cursor:pointer}.stg-ltab button.on{background:#fff;color:#001E44;box-shadow:0 2px 8px rgba(0,30,68,.12)}body.dark .stg-ltab{background:#0E1B33}'
  + '.stg-pl{display:flex;flex-direction:column;max-height:46vh;overflow-y:auto;margin-bottom:8px}.stg-pr{display:flex;align-items:center;gap:12px;padding:10px 4px;border-bottom:1px solid var(--line);font:600 14.5px var(--font-body);color:var(--navy)}.stg-pr span{flex:1;min-width:0}.stg-pr img{width:32px;height:32px;border-radius:8px}.stg-pr input{width:22px;height:22px;accent-color:#0075E3}.stg-pr-x{border:0;background:none;color:var(--muted);font-size:16px;cursor:pointer}body.dark .stg-pr{color:#fff}'
  + '.stg-add{display:flex;gap:8px;margin-bottom:12px}.stg-add input{flex:1}.stg-add button{border:0;border-radius:14px;padding:0 16px;background:#E3F1FF;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}'; document.head.appendChild(st); })();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.stg-lista .stg-pr span{text-align:left}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.stg-lista .stg-seg{margin:0 0 16px}.stg-lista .ff-picklist{max-height:44vh}.stg-lista .ff-addsite{display:block;width:100%;margin-top:12px}'; document.head.appendChild(st); })();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.stg-lista .ff-pickname{flex:1;min-width:0;text-align:left!important}'; document.head.appendChild(st); })();

/* 0.9.382 */
function stgSpenteLista(st){
  const l = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).filter(function(d){ return st.blocchi[d.k]; }).map(function(d){ return d.n; });
  if (!l.length) return '<p class="stg-p">Nessuna sezione.</p>';
  return '<ul class="stg-sp-l">' + l.map(function(n){ return '<li>' + stgEsc(n) + '</li>'; }).join('') + '</ul>';
}
function stgSeveraAccesa(){
  try{ if (typeof sevState !== 'undefined' && sevState && sevState.level > 0) return true; }catch(_){ }
  /* 0.9.401 BUG-195: come il resto dell'app (blocchi-sezioni.js): lo stato del motore, poi il livello salvato (fl_strict) */
  try{ if (typeof bsSeveraAccesa === 'function' && bsSeveraAccesa()) return true; }catch(_){ }
  try{ const b = document.getElementById('strictBubble'); return !!(b && b.classList.contains('on')); }catch(_){ return false; }
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.stg-sp-t{margin-bottom:8px!important}.stg-sp-l{margin:0 0 18px;padding:0 0 0 22px;text-align:left}.stg-sp-l li{margin:0 0 10px;font:600 15px/1.4 var(--font-body);color:inherit}'
  + '.stg-sev-n{margin:14px 0 0;text-align:center}'
  /* Andrea: "Vai alla stagione tocca la barra dei pallini della slideshow: ci vuole la distanza come nella focus box" */
  + '.stg-hs .stg-hs-in{padding-bottom:104px!important}';
  document.head.appendChild(st); })();

/* ===========================================================================================
   0.9.401 BUG-193: IL CONTO ALLA ROVESCIA (stile Mission Impossible)
   Andrea: "al posto di Mancano 146 ore un conto alla rovescia che si vede scorrere: giorni, ore, minuti, secondi. Nelle impostazioni
   scelgo come vederlo; di base completo, con i secondi". Cifre grandi a larghezza fissa, etichette piccole sotto.
   flConto(el, scadenza, formato) lo monta in un elemento; flContoHtml(scadenza, formato, classe) lo scrive dentro a una stringa.
   Un battito solo (FL_CONTO_T) aggiorna ogni secondo tutti i conti presenti nella pagina; quando non ce n'e' piu' nessuno si ferma da solo,
   cosi' un elemento tolto dalla pagina non lascia intervalli orfani. formato: 'g' | 'gh' | 'ghm' | 'tutto' (vuoto = quello scelto
   in Personalizza, fl_conto_formato).
   =========================================================================================== */
const FL_CONTO_KEY = 'fl_conto_formato';
const FL_CONTO_FORMATI = [['g', 'Solo giorni'], ['gh', 'Giorni e ore'], ['ghm', 'Giorni, ore e minuti'], ['tutto', 'Completo']];
const FL_CONTO_U = [['g', 86400000, 'giorni', 'giorno'], ['h', 3600000, 'ore', 'ora'], ['m', 60000, 'min', 'min'], ['s', 1000, 'sec', 'sec']];
const FL_CONTO_T = { t: 0, vuoti: 0 };
/* 0.9.404 BUG-322, Andrea: la scelta del formato in Personalizza si toglie, il conto alla rovescia e' sempre completo (giorni, ore,
   minuti, secondi). Una scelta vecchia salvata in fl_conto_formato non conta piu'. Un formato passato a mano (data-fmt) resta possibile. */
function flContoFormato(){ return 'tutto'; }
function flContoParti(ms, fmt){
  const n = { g: 1, gh: 2, ghm: 3, tutto: 4 }[fmt] || 4;
  const usate = FL_CONTO_U.slice(0, n), ult = usate[n - 1][1];
  /* l'ultima unita' mostrata si arrotonda per eccesso: con "solo giorni" a 3 ore dalla fine resta 1 giorno, non 0 */
  let resto = Math.ceil(Math.max(0, ms) / ult);
  const out = usate.map(function(u){ const f = u[1] / ult, v = Math.floor(resto / f); resto -= v * f; return { k: u[0], v: v, et: v === 1 ? u[3] : u[2] }; });
  /* i giorni a zero non si mostrano (l'ultimo giorno della modalita' ADHD), a meno che non siano l'unica unita' */
  if (out.length > 1 && out[0].k === 'g' && out[0].v === 0) out.shift();
  return out;
}
function flContoCifre(v){ const s = String(v); return (s.length < 2 ? '0' + s : s); }
function flContoDentro(ms, fmt){
  const p = flContoParti(ms, fmt);
  return p.map(function(x, i){
    return (i ? '<span class="fl-conto-s" aria-hidden="true">:</span>' : '')
      + '<span class="fl-conto-u' + (i === p.length - 1 ? ' fl-conto-ult' : '') + '" data-k="' + x.k + '"><b>' + flContoCifre(x.v).split('').map(function(c){ return '<i>' + c + '</i>'; }).join('') + '</b><small>' + x.et + '</small></span>';
  }).join('');
}
function flContoHtml(fine, fmt, cls){
  setTimeout(flContoAvvia, 0);
  return '<div class="fl-conto' + (cls ? ' ' + cls : '') + '" data-fine="' + (+fine || 0) + '"' + (fmt ? ' data-fmt="' + fmt + '"' : '') + ' role="timer">' + flContoDentro((+fine || 0) - Date.now(), fmt || flContoFormato()) + '</div>';
}
/** Monta il conto alla rovescia in el, fino a scadenza (ms). Restituisce el. */
function flConto(el, scadenza, formato){
  if (!el) return el;
  el.classList.add('fl-conto'); el.setAttribute('role', 'timer');
  el.dataset.fine = String(+scadenza || 0);
  if (formato) el.dataset.fmt = formato; else delete el.dataset.fmt;
  el.innerHTML = flContoDentro((+scadenza || 0) - Date.now(), formato || flContoFormato());
  flContoAvvia();
  return el;
}
function flContoAggiorna(el){
  const fmt = el.dataset.fmt || flContoFormato(), p = flContoParti((+el.dataset.fine || 0) - Date.now(), fmt);
  const uu = el.querySelectorAll('.fl-conto-u');
  /* cambia la forma (un'unita' in meno, una cifra in piu', un altro formato): si riscrive tutto */
  if (uu.length !== p.length || p.some(function(x, i){ return uu[i].dataset.k !== x.k || uu[i].querySelectorAll('i').length !== flContoCifre(x.v).length; })){ el.innerHTML = flContoDentro((+el.dataset.fine || 0) - Date.now(), fmt); return; }
  let anima = true; try{ anima = !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); }catch(_){ }
  p.forEach(function(x, i){
    const ii = uu[i].querySelectorAll('i'), c = flContoCifre(x.v);
    for (let j = 0; j < c.length; j++){
      if (ii[j].textContent === c[j]) continue;
      ii[j].textContent = c[j];
      if (anima && ii[j].animate) try{ ii[j].animate([{ transform: 'translateY(-35%)', opacity: 0.25 }, { transform: 'none', opacity: 1 }], { duration: 240, easing: 'cubic-bezier(.2,.8,.2,1)' }); }catch(_){ }
    }
    const sm = uu[i].querySelector('small'); if (sm && sm.textContent !== x.et) sm.textContent = x.et;
  });
}
function flContoTick(){
  const l = document.querySelectorAll('.fl-conto[data-fine]');
  if (!l.length){ if (++FL_CONTO_T.vuoti >= 5){ clearInterval(FL_CONTO_T.t); FL_CONTO_T.t = 0; } return; }
  FL_CONTO_T.vuoti = 0;
  if (document.hidden) return;
  l.forEach(function(el){ try{ flContoAggiorna(el); }catch(_){ } });
}
function flContoAvvia(){ if (typeof document === 'undefined') return; FL_CONTO_T.vuoti = 0; if (!FL_CONTO_T.t) FL_CONTO_T.t = setInterval(flContoTick, 1000); }
if (typeof document !== 'undefined'){
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.querySelector('.fl-conto[data-fine]')){ flContoAvvia(); flContoTick(); } });
  document.addEventListener('fl:tab', function(){ setTimeout(function(){ if (document.querySelector('.fl-conto[data-fine]')) flContoAvvia(); }, 200); });
}

/* LA SCELTA IN PERSONALIZZA: come vedere il conto alla rovescia. Una sezione sua, "La stagione di spinta", sotto all'Intestazione
   (la slide della stagione e' in cima alla scheda Sogno). Con un'anteprima che scorre: si vede subito cosa cambia */
function flContoSet(f){
  try{ localStorage.setItem(FL_CONTO_KEY, f); }catch(_){ }
  try{ flVibra(6); }catch(_){ }
  stgPersonalizzaPaint();
  try{ document.querySelectorAll('.fl-conto[data-fine]:not([data-fmt])').forEach(function(el){ el.innerHTML = flContoDentro((+el.dataset.fine || 0) - Date.now(), f); }); }catch(_){ }
}
function stgPersonalizzaPaint(){
  /* 0.9.404 BUG-322: in Personalizza la sezione "La stagione di spinta" non c'e' piu'; se un giro vecchio l'aveva messa, si toglie */
  const box = typeof document !== 'undefined' && document.getElementById('psStagioneBox');
  if (box) box.remove();
}
if (typeof document !== 'undefined'){
  setTimeout(function(){ try{ stgPersonalizzaPaint(); }catch(_){ } }, 1700);
  document.addEventListener('fl:screen', function(e){ if (e.detail === 's-personalize') setTimeout(function(){ try{ stgPersonalizzaPaint(); }catch(_){ } }, 40); });
}

/* BUG-196: al passo 2 la scheda DreamMap dei Sempre consentiti (fullfocus.js, solo dalla stagione) e' stata aperta o usata: il passo 3
   non ripete il pannello delle distrazioni dentro DreamMap */
function stgDmTraccia(){ try{ if (typeof STG !== 'undefined' && STG.bozza) STG.bozza.dmVisto = true; }catch(_){ } }
(function(){
  if (typeof window === 'undefined') return;
  if (typeof ffAllowOpen === 'function' && !ffAllowOpen.__stg){ const a0 = ffAllowOpen; const a1 = function(tab){ if (tab === 'dm' && typeof FF !== 'undefined' && FF.allowDaStg) stgDmTraccia(); return a0.apply(this, arguments); }; a1.__stg = true; window.ffAllowOpen = a1; }
  if (typeof ffDmCambia === 'function' && !ffDmCambia.__stg){ const d0 = ffDmCambia; const d1 = function(){ stgDmTraccia(); return d0.apply(this, arguments); }; d1.__stg = true; window.ffDmCambia = d1; }
})();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = [
  /* il conto alla rovescia: cifre a larghezza fissa, etichette piccole sotto; il colore segue chi lo contiene */
  '.fl-conto{display:flex;justify-content:center;align-items:flex-start;gap:6px;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;line-height:1}',
  '.fl-conto-u{display:flex;flex-direction:column;align-items:center;flex:none}',
  '.fl-conto-u b{display:flex;font:900 42px/1 var(--font-display,var(--font-body));letter-spacing:0}',
  '.fl-conto-u i{display:inline-block;width:.64em;text-align:center;font-style:normal}',
  '.fl-conto-u small{margin-top:8px;font:800 10.5px/1 var(--font-body);letter-spacing:.14em;text-transform:uppercase;white-space:nowrap}',
  '.fl-conto-s{flex:none;display:flex;align-items:center;height:42px;font:800 30px/1 var(--font-display,var(--font-body));opacity:.45;padding-bottom:4px;box-sizing:border-box}',
  '.fl-conto-hero{margin:2px 0 12px;color:#FFFFFF}.fl-conto-hero .fl-conto-ult{color:#FF8A9B}.fl-conto-hero small{color:#BCE0FF}',
  '.stg-hs-in .fl-conto-hero span.fl-conto-s,.stg-hs-in .fl-conto-hero span.fl-conto-u{margin:0;font-size:inherit;color:inherit}',
  '.stg-hs-in .fl-conto-hero span.fl-conto-s{font:800 30px/1 var(--font-display,var(--font-body));display:flex}',
  '.stg-hs-in .fl-conto-hero span.fl-conto-ult{color:#FF8A9B}',
  '.stg-hs-in .fl-conto + span{margin-top:4px!important}',
  '.fl-conto-pag{margin:4px 0 22px;color:var(--navy,#001E44)}.fl-conto-pag .fl-conto-ult{color:#E63946}.fl-conto-pag small{color:var(--muted,#4A5A72)}',
  'body.dark .fl-conto-pag{color:#FFFFFF}body.dark .fl-conto-pag .fl-conto-ult{color:#FF8A9B}',
  '.fl-conto-mini .fl-conto-u b{font-size:30px}.fl-conto-mini .fl-conto-s{font-size:22px;height:30px}.fl-conto-mini{color:var(--navy,#001E44)}.fl-conto-mini small{color:var(--muted,#4A5A72)}body.dark .fl-conto-mini{color:#FFFFFF}',
  /* 0.9.404 BUG-322: niente piu' .ps-conto qui. Era l'anteprima di Personalizza (tolta) e lo stesso nome lo usa il conto delle ore del
     Piano della settimana (piano-settimana.js): il suo background:rgba(0,117,227,.18) cancellava il pannello scuro e le cifre bianche finivano
     su un azzurro chiarissimo, bianco su bianco; queste regole a loro volta davano bordo e ombra al pannello del Piano. */
  '@media (max-width:360px){.fl-conto-u b{font-size:34px}.fl-conto-s{font-size:24px;height:34px}}',
  /* 0.9.402 BUG-266, Andrea: "i due punti non sono allineati alle cifre, e il conto alla rovescia va in un pannello scuro, quasi nero, nella slide
     e nella pagina della stagione". I due punti non sono piu' il carattere ":" (che ogni carattere disegna a un'altezza sua): sono due pallini
     disegnati, centrati sull'altezza delle cifre (la stessa scatola, alta quanto le cifre). Il pannello quasi nero e' scuro in tutti e due i
     temi, con l'inchiostro fisso: cifre bianche, l'ultima rossa, etichette azzurro smorzato */
  '.fl-conto{--fl-conto-px:42px}.fl-conto-mini{--fl-conto-px:30px}',
  '@media (max-width:360px){.fl-conto{--fl-conto-px:34px}.fl-conto-mini{--fl-conto-px:26px}}',
  '.fl-conto .fl-conto-u b,.stg-hs-in .fl-conto .fl-conto-u b{font-size:var(--fl-conto-px)!important;line-height:1!important;margin:0!important}',
  '.fl-conto .fl-conto-s,.stg-hs-in .fl-conto-hero span.fl-conto-s{position:relative;display:block!important;width:calc(var(--fl-conto-px) * .2);height:var(--fl-conto-px)!important;margin:0!important;padding:0!important;font-size:0!important;line-height:0!important;opacity:1!important;color:inherit}',
  '.fl-conto .fl-conto-s::before,.fl-conto .fl-conto-s::after{content:"";position:absolute;left:50%;top:51%;width:calc(var(--fl-conto-px) * .14);height:calc(var(--fl-conto-px) * .14);border-radius:50%;background:currentColor;opacity:.5;transform:translate(-50%,calc(-50% - var(--fl-conto-px) * .15))}',
  '.fl-conto .fl-conto-s::after{transform:translate(-50%,calc(-50% + var(--fl-conto-px) * .15))}',
  '.fl-conto-hero,.fl-conto-pag{box-sizing:border-box;border-radius:20px;background:linear-gradient(180deg,#0D1220 0%,#05070C 100%);border:1px solid rgba(255,255,255,.08);box-shadow:0 12px 28px rgba(0,0,0,.28)}',
  '.fl-conto-hero,.fl-conto-pag{padding:18px 16px 16px}.fl-conto-hero{margin:2px 0 16px}.fl-conto-pag{margin:4px 0 24px}',
  '.fl-conto-hero,.fl-conto-pag,body.dark .fl-conto-pag{color:#FFFFFF}',
  '.fl-conto-hero .fl-conto-ult,.fl-conto-pag .fl-conto-ult,body.dark .fl-conto-pag .fl-conto-ult,.stg-hs-in .fl-conto-hero span.fl-conto-ult{color:#FF5A6A}',
  '.fl-conto-hero small,.fl-conto-pag small{color:#8FA3BF!important}',
  'body.dark .fl-conto-hero,body.dark .fl-conto-pag{border-color:rgba(140,198,255,.22)}',
  /* BUG-195: il passo gia' fatto */
  '.stg-fatto{display:flex;align-items:center;gap:14px;margin:0 0 24px;padding:16px;border-radius:18px;border:1.5px solid #0075E3;background:var(--blue-soft,#E3F1FF);text-align:left}',
  '.stg-fatto i{flex:none;width:44px;height:44px;border-radius:50%;display:grid;place-items:center;background:#0075E3;color:#FFFFFF;font-style:normal}',
  '.stg-fatto span{flex:1;min-width:0}.stg-fatto b{display:block;font:800 16px var(--font-body);color:var(--navy,#001E44)}.stg-fatto small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#4A5A72)}',
  'body.dark .stg-fatto{background:#12305C;border-color:#3F9FF4}body.dark .stg-fatto b{color:#FFFFFF}body.dark .stg-fatto small{color:#BFD3EC}',
  /* BUG-197: la pagina della stagione, tutta al centro */
  '.stg-stato{flex:1 0 auto}.stg-stato > .stg-ico{align-self:center!important;margin:8px auto 14px}',
  '.stg-stato .stg-eti{text-align:center;margin-top:0!important}',
  '.stg-pagina .stg-stato .stg-h{margin:12px 0 24px!important;font-size:24px}',
  '.stg-stato .stg-barra{margin:0 0 12px!important}',
  '.stg-stato .stg-st-n{margin:0 0 32px!important}',
  '.stg-spento{padding:20px 18px;border-radius:20px;background:var(--bg,#F4F9FF);border:1.5px solid var(--line,#DCE8F5);text-align:center}',
  'body.dark .stg-spento{background:#0E1D3D;border-color:#1F3A66}',
  '.stg-sp-k{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}body.dark .stg-sp-k{color:#8CC6FF}',
  '.stg-spento .stg-sp-t{margin:12px 0 16px!important;font:700 16px/1.45 var(--font-body);color:var(--navy,#001E44);text-align:center}body.dark .stg-spento .stg-sp-t{color:#FFFFFF}',
  '.stg-chs{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}',
  '.stg-ch{display:inline-flex;align-items:center;gap:8px;max-width:100%;box-sizing:border-box;padding:6px 12px 6px 6px;border-radius:99px;background:var(--card,#FFFFFF);border:1px solid var(--line,#DCE8F5);font:700 14px var(--font-body);color:var(--navy,#001E44)}',
  '.stg-ch > span:last-child{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  'body.dark .stg-ch{background:#12203A;border-color:#22345A;color:#FFFFFF}',
  '.stg-ch-i{flex:none;width:26px;height:26px;border-radius:8px;overflow:hidden;font-size:13px}.stg-ch-e{display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);font-size:15px}body.dark .stg-ch-e{background:#1A2E52}',
  '.stg-ch-piu{padding:6px 12px;color:var(--muted,#4A5A72)}',
  '.stg-sp-dm{margin-top:20px}.stg-sp-dm summary{font-size:14.5px;text-align:center}.stg-sp-dm .stg-sp-l{margin:0;padding:0 18px 14px 36px}',
  '.stg-stato .stg-cta{margin-top:auto!important}.stg-stato .stg-spento{margin-bottom:36px}',
  '.stg-sev-n{display:flex;align-items:center;justify-content:center;gap:10px;margin:16px 0 0!important;font:700 14.5px var(--font-body);color:var(--muted,#4A5A72)}',
  '.stg-i{flex:none;width:26px;height:26px;border-radius:50%;border:1.5px solid currentColor;background:none;color:#0075E3;font:800 13px/1 Georgia,serif;font-style:italic;display:grid;place-items:center;cursor:pointer;padding:0}body.dark .stg-i{color:#8CC6FF}',
  '.stg-sev-f .fl-info{margin:0 0 8px}'
].join('\n'); document.head.appendChild(st); })();

/* 0.9.403 BUG-302: la frase prima dell'elenco e' il titolo del pannello (una sola, con il due punti) */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.stg-spento .stg-sp-t.stg-sp-uno{margin:2px 0 16px!important;font:800 18px/1.35 var(--font-display)}';
  document.head.appendChild(st); })();
