/* ===========================================================================================
   IL TOUR SULLA CASA VERA — il Genio ti porta in giro per l'app, come la Valchiria di Clash

   Il tutorial di prima era una scena a parte: un tabellone disegnato dentro al film e un
   pulsante da tenere premuto che «segnava un punto». Due bugie in una: la scheda START non si
   vedeva mai (si parlava di una cosa che l'utente non aveva davanti), e il punto lo regalava
   un gesto che non c'entra niente con la partita — nessuna azione, nessun passo verso il sogno.

   Qui non c'è nessuna scena. Il Genio, piccolo, sta sopra alla CASA VERA con il menu in basso
   visibile; il resto è in ombra, l'elemento che conta è nella luce con la freccia sopra, e
   l'utente tocca la cosa vera. Il Genio aspetta il tocco: non avanza da solo. Le fermate sono
   azioni, non spiegazioni:

     1. tocca Mappa          → la mappa alla Duolingo: una tappa al giorno, la serie, la rotta
     2. tocca START          → il foglio di domani, con la prima riga già scritta (dalla rotta)
     3. premi invio          → IL PUNTO È PRENOTATO (mtPlanMark): è la stessa mossa che farà
                               ogni sera, e vale solo se domani la fa dentro una sessione Focus
     4. il tabellone         → il vecchio te ha già segnato con le ore VERE di ieri
     5. tocca Blocco         → dove chiude le app mentre fa la sua riga
     6. i permessi

   Niente punto regalato: il tabellone lo tocca solo l'arbitro, dopo.
   =========================================================================================== */

const GT = { on: false, i: 0, stop: null, timer: 0, tick: 0, ev: null };

/* I TESTI DEL GIRO: li scrive il Copywriter (ruolo nel company brain). {segnaposto} fra graffe. */
/* Il Copywriter li ha scritti per «domani»; il foglio che il giro apre e' quello di OGGI (la
   scheda Domani si apre a sera): stesse parole, cambiato solo il giorno. */
const GT_TESTI = {
  /* 0.9.264, Andrea: il Genio ripeteva qui il sogno intero scritto a mano. Il foglio si spiega per quello che e'. */
  tour_start: 'Qui c\u2019è *START*. Il foglio di oggi. Ci scrivi ^una riga sola^, la cosa che oggi ti avvicina al sogno. Falla dentro Full Focus, e vale un punto.',
  tour_scrivi: 'La prima riga te la scrivo io:\n*«{riga}»*. Cambiala se vuoi, poi mettila sul foglio.',
  tour_scrivi_btn: 'La metto sul foglio',
  tour_fatto: 'È sul foglio. Il punto arriva solo se la fai dentro *Full Focus*. Lì i minuti li conta il telefono. Te lo mostro.'
};
function gtT(k, v){
  let s = GT_TESTI[k] || '';
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  return s;
}

function gtEl(){
  let el = document.getElementById('gnTour');
  if (el) return el;
  el = document.createElement('div');
  el.id = 'gnTour';
  el.innerHTML =
      '<div class="gt-scrim" id="gtScrim"></div>'
    + '<div class="gt-spot" id="gtSpot" hidden></div>'
    + '<div class="gt-arrow" id="gtArrow" hidden>👇</div>'
    + '<div class="gt-genio" id="gtGenioBox">'
    +   '<img id="gtGenio" src="img/genio/genio-saluta.png" alt="">'
    +   '<div class="gt-bolla"><p id="gtTesto"></p><div class="gt-risp" id="gtRisp"></div></div>'
    + '</div>';
  (document.getElementById('phone') || document.body).appendChild(el);
  document.getElementById('gtScrim').addEventListener('click', gtToccoScrim);
  try{ document.querySelector('#gnTour .gt-bolla').addEventListener('click', function(e){ if (GT.timer && typeof GT.completa === 'function' && !e.target.closest('button')){ GT.completa(); } }); }catch(_){ }
  return el;
}

/* ---------- utilità ---------- */
function gtSogno(){
  try{ return (typeof gnLettura === 'function') ? gnLettura() : null; }catch(_){ return null; }
}
function gtNomi(){
  try{ return (typeof gnNomi === 'function') ? gnNomi() : { vecchio: 'il vecchio te', nuovo: 'il nuovo te' }; }
  catch(_){ return { vecchio: 'il vecchio te', nuovo: 'il nuovo te' }; }
}
function gtPosa(p){
  const img = document.getElementById('gtGenio');
  if (img) img.src = 'img/genio/genio-' + (p || 'saluta') + '.png';
}
/* Il typewriter del Genio, nella bolla del tour: stesse regole del film (26 ms a lettera, la
   parte fra *asterischi* si accende). */
/* 0.9.292, Andrea: "dopo l'onboarding il Genio scrive nettamente piu' lento". Il tempo per lettera era lo stesso (55 ms),
   ma nella bolla le lettere sono da 15 px contro i 19,5 della frase del giorno: la riga cresceva un quarto piu' piano.
   Il passo segue la grandezza del carattere, come nella frase della settimana (settimana.js, wkPassoLettera). */
function gtPasso(el){
  const base = (typeof CIT_MS === 'number') ? CIT_MS : 55;
  let fs = 19.5; try{ fs = parseFloat(getComputedStyle(el).fontSize) || 19.5; }catch(_){ }
  return Math.max(24, Math.round(base * Math.min(1, fs / 19.5)));
}
function gtScrivi(testo, dopo){
  const el = document.getElementById('gtTesto'); if (!el) return;
  clearInterval(GT.timer);
  const parti = (typeof gnParti === 'function') ? gnParti(testo) : { html: testo, n: testo.length };
  let i = 0;
  el.innerHTML = '';
  const gb = document.getElementById('gtGenioBox'); if (gb) gb.classList.remove('gt-attesa');
  const fine = function(){ clearInterval(GT.timer); GT.timer = 0; el.innerHTML = parti.html; if (dopo) dopo(); };
  GT.timer = setInterval(function(){
    i++;
    try{ if (i % 2 === 0 && typeof gnAu !== 'undefined') gnAu.tick(); }catch(_){ }
    el.innerHTML = (typeof gnParti === 'function') ? gnParti(testo, i).html : testo.slice(0, i);
    if (i >= parti.n) fine();
  }, gtPasso(el));
  GT.completa = fine;
}

/* LA PROSSIMA TAPPA DELLA ROTTA. Il primo passo non fatto dell'orizzonte più vicino; se non
   c'è ancora niente scritto, il primo passo lo propone il Genio dal sogno scelto — e lo scrive
   anche nella rotta (orizzonte «oggi»), così la riga del foglio è SULLA rotta per costruzione. */
/* 0.9.390 (BUG-122), Andrea: "guardare i numeri lo fa l'intelligenza artificiale in 2 secondi: servono passi concreti". Niente primi
   passi di sola ricerca (cercare il prezzo, guardare le uscite): un'azione che fa avanzare (tools/test-passi-azione.js) */
const GT_PRIMI_PASSI = {
  viaggiare: 'Fissare la data della partenza e dirla a una persona (10 min)',
  lavoro:    'Scrivere a una persona che fa già il lavoro che voglio (10 min)',
  amore:     'Scrivere a una persona che mi piace (10 min)',
  legami:    'Chiamare una persona a cui tengo, senza motivo (10 min)',
  imparare:  'Dieci minuti di pratica sulla cosa che sto imparando',
  liberta:   'Scrivere le tre cose che mi tengono fermo, e la prima da togliere (10 min)',
  soldi:     'Disdire un abbonamento che non uso più (10 min)',
  meglio:    'Dieci minuti sulla cosa che rimando da più tempo',
  progetto:  'Scrivere a una persona che potrebbe diventare il mio primo cliente (10 min)',
  sessione:  'Dieci minuti sul capitolo che rimando',
  passione:  'Dieci minuti sulla cosa che amo',
  famiglia:  'Scrivere a una persona a cui tengo, senza motivo (10 min)',
  controllo: 'Dieci minuti sulla cosa che rimando da più tempo',
  corpo:     'Dieci minuti di allenamento, adesso',
  capolavoro: 'Dieci minuti sul mio capolavoro',
  voce:      'Registrare un minuto di video, senza rifarlo (10 min)',
  fede:      'Dieci minuti di preghiera, telefono in un\'altra stanza',
  coscienza: 'Dieci minuti di meditazione, telefono in un\'altra stanza',
  scrivo:    'Costruire il mio percorso con il Genio (10 min)'
};
/* 0.9.293: il giro di prima scriveva da solo uno di questi passi nella rotta di oggi ("Scrivere a una persona che potrebbe
   diventare il mio primo cliente"), e ricompariva come Prossima mossa. Lo tolgo, una volta, se non e' stato fatto. */
function gtPuliziaPassi293(){
  try{
    if (localStorage.getItem('fl_gt_pulizia293') === '1' || typeof ozAnello !== 'function' || typeof ozSalvaAnello !== 'function') return;
    const vecchi = Object.keys(GT_PRIMI_PASSI).map(function(k){ return GT_PRIMI_PASSI[k]; });
    const a = ozAnello('oggi');
    const via = (a.passi || []).filter(function(p){ return !(p && !p.fatto && vecchi.indexOf(p.t) >= 0); });
    if (via.length !== (a.passi || []).length){
      a.passi = via;
      if (!via.length && /^Il primo passo/.test(a.testo || '')) a.testo = '';
      ozSalvaAnello('oggi', a);
    }
    localStorage.setItem('fl_gt_pulizia293', '1');
  }catch(_){ }
}
window.addEventListener('load', function(){ setTimeout(gtPuliziaPassi293, 800); });
function gtMissione(){
  try{ if (typeof stMissione === 'function'){ const m = stMissione(); if (m && m.t) return m.t; } }catch(_){ }
  let k = 'meglio';
  try{ k = (typeof gnDati === 'function' && gnDati().sognoK) || 'meglio'; }catch(_){ }
  const t = GT_PRIMI_PASSI[k] || GT_PRIMI_PASSI.meglio;
  /* nella rotta, una volta sola */
  try{
    if (typeof ozAnello === 'function' && typeof ozSalvaAnello === 'function'){
      const a = ozAnello('oggi');
      if (!(a.passi || []).some(function(p){ return p && p.t === t; })){
        a.passi = (a.passi || []).concat([{ t: t, fatto: false, il: '' }]);
        if (!a.testo){ const L = gtSogno(); a.testo = (L && L.sogno && L.sogno !== 'quel sogno') ? 'Il primo passo verso ' + L.sogno : 'Il primo passo'; }
        ozSalvaAnello('oggi', a);
      }
    }
  }catch(_){ }
  return t;
}
function gtModalita(){
  let m = 'normale';
  try{ m = localStorage.getItem('fl_modalita') || 'normale'; }catch(_){ }
  return { k: m, n: { facile: 1, normale: 3, difficile: 5 }[m] || 3 };
}

/* ---------- le fermate ----------
   Ogni fermata è un'azione vera. Il primo punto NON è regalato: è la prima scelta della
   partita (il pannello della decisione, quello vero), e il tabellone si muove in diretta con
   il cartello del gol. Prima, però, l'utente vede tutte e due le regole: come si segna e
   come segna l'altro. */
function gtStops(){
  /* 0.9.293, Andrea: "il tour e' da rifare sulla roadmap nuova: niente riga che scrivo io (non e' network marketing),
     la manina che indica un riquadro bianco, la scelta 'chi vuoi essere' troppo presto, e 'fare la tua riga' non e'
     italiano". Quattro fermate sulle schede vere (Dream, Mappa, START), il primo passo e' la prima tappa del percorso,
     nessun compito inventato e nessuna scelta da firmare: il pannello delle scelte arriva quando c'e' qualcosa da
     scegliere (la Modalita' severa, il rinnovo). */
  const tappa = gtPrimaTappa();
  const casa = function(tab){ return function(){ try{ goId('s-home'); if (tab) switchTab(tab); }catch(_){ } }; };
  /* 0.9.337, Andrea: "il tour parte dalla scheda Sogno, ma deve partire dalla Mappa, dove si svolge tutto; poi START, e Sogno per
     ultima. Spiega una cosa per fermata, senza mischiare la storia con il rientro, e spiega cosa si fa in START". */
  return [
    /* 0.9.366, Andrea: "l'overlay scuro e' applicato a caso". La prima fermata puntava al sentiero intero (alto come dieci schermi):
       ora la luce va sulla tappa di oggi e sulle due vicine */
    { posa: 'saluta', tab: 'mappa', target: '#mppSentiero .sd-cap.on, #mppSentiero .sd-nodo.corrente, #mppSentiero', modo: 'btn', attesa: 900,
      pre: function(){ casa('mappa')(); try{ if (typeof mppVista === 'function' && !(typeof faStrada === 'function' && faStrada())) mppVista('rotta'); const t = document.getElementById('tab-mappa'); if (t) t.scrollTo({ top: 0 }); const n = document.getElementById('mppSentiero'); if (n) n.scrollIntoView({ block: 'start' }); }catch(_){ } },
      testo: 'Questa è la *Mappa*. Qui fai il viaggio verso il tuo sogno, una tappa al giorno, come i livelli di un gioco.',
      btn: 'Ho capito' },
    { posa: 'rivela', tab: 'mappa', target: '#mppSentiero .sd-nodo.corrente, #mppSentiero', modo: 'btn', attesa: 700,
      pre: function(){ try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n) n.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: tappa
        ? 'La prima tappa è *' + tappa + '*. Lì scegli come arrivarci:\nseguire la strada del Genio, o pianificare tu.'
        : 'La prima tappa è il tuo *piano su misura*. Lì scegli come arrivarci:\nseguire la strada del Genio, o pianificare tu.',
      btn: 'Ho capito' },
    { posa: 'pensa', tab: 'mappa', target: '#nav-sveglia', modo: 'tap',
      testo: 'Poi c\u2019è *START*. È da qui che lavori al sogno. Tocca START.' },
    /* 0.9.366: "Da qui parte il Full Focus" illuminava la slide del piano scritto. La luce va sulle sessioni pronte (Per te) */
    { posa: 'rivela', tab: 'sveglia', target: '#prHost .pr-card, #prHost, #stMatchBox', modo: 'btn', attesa: 700,
      pre: function(){ try{ const b = document.querySelector('#prHost .pr-card') || document.getElementById('prHost') || document.getElementById('stMatchBox'); if (b) b.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: 'Da qui parte il *Full Focus*. Il telefono resta bloccato finché la sessione non finisce. Puoi farla da solo, ^in coppia^ con un amico, con i ~suoni~ per concentrarti.',
      btn: 'Ho capito' },
    { posa: 'saluta', tab: 'sveglia', target: '#nav-rotta', modo: 'tap',
      testo: 'Per ultima la scheda *Sogno*. Tocca Sogno.' },
    /* 0.9.366: "la data in cui arrivi" illuminava il pannello Il tuo viaggio. La luce va sulla data */
    /* 0.9.402 BUG-250, Andrea: "il faro sulla data inquadra la slide Liberati dai ladri di sogni". Il bersaglio era il primo .nv-data
       della scheda, cioe' quello della slide dell'arrivo anche quando lo slideshow mostrava un'altra slide (lo sweep tiene accesa la
       vecchia sotto alla nuova, e "la slide nuova a ogni apertura" la cambiava a ogni ridisegno). Ora il tour porta lui lo slideshow
       sulla slide dell'arrivo, lo tiene fermo li' finche' la fermata dura e illumina la data solo sulla slide accesa (lezione 350) */
    { posa: 'rivela', tab: 'rotta', target: '#nvHero .bh-slide.on #nvArrivoSlide .nv-data, #nvArrivo .nv-data, #nvPannello', modo: 'btn', attesa: BH_SWEEP_MS_GT + 300,
      pre: gtArrivoPrepara, ogni: gtArrivoTieni,
      testo: 'Qui vedi *la data in cui arrivi* al tuo sogno. Si sposta ogni giorno, con quello che fai.',
      btn: 'Ho capito' },
    { posa: 'pensa', tab: 'rotta', target: '#nvsPan', modo: 'btn', attesa: 400, pre: function(){ try{ const n = document.getElementById('nvsPan'); if (n) n.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: 'E qui c\u2019è *la tua storia*. Un episodio al giorno, in cui il Genio impara chi sei. La sera trovi qui anche ^la revisione^ della giornata.',
      btn: 'Ho capito' },
    { posa: 'saluta', tab: 'mappa', target: null, modo: 'btn', attesa: 400, pre: casa('mappa'),
      testo: function(){
        return GT.permessiOk
          ? 'Fatto. Adesso la prima tappa. Scegli come arrivare al tuo sogno.'
          : 'Hai visto tutto. Ora l\u2019app ha bisogno di *due permessi* per bloccare le distrazioni.';
      },
      btn: function(){ return GT.permessiOk ? 'Scelgo adesso' : 'Andiamo'; }, btnFn: function(){ const ok = GT.permessiOk; gtFine(); if (ok) gtBivioDopo(); } }
  ];
}
/* 0.9.402 BUG-250: la fermata della data d'arrivo. Lo slideshow di Sogno va sulla slide dell'arrivo e resta fermo (FL_HEROES.rotta.tieni,
   rispettato da flHeroGo in blkhero.js); se l'utente ha tolto quella slide, la luce va sulla data del pannello Il tuo viaggio, scheda
   Sogno. Il blocco si toglie in gtStacca, cioe' alla fermata dopo o alla fine del tour. */
const BH_SWEEP_MS_GT = (typeof BH_SWEEP_MS === 'number') ? BH_SWEEP_MS : 700;
function gtArrivoSlide(){
  const box = document.querySelector('#nvHero #nvArrivoSlide');
  if (!box || !box.querySelector('.nv-data')) return null;
  const slide = box.closest('.bh-slide'), track = slide && slide.parentElement;
  if (!slide || !track) return null;
  return { slide: slide, i: Array.prototype.indexOf.call(track.children, slide) };
}
function gtArrivoPrepara(){
  try{
    const a = gtArrivoSlide(), h = (typeof FL_HEROES !== 'undefined') ? FL_HEROES.rotta : null;
    if (a && h && a.i >= 0){
      h.tieni = a.i; GT.eroe = 'rotta';
      if (h.slide !== a.i && typeof flHeroGo === 'function') flHeroGo('rotta', a.i);
      a.slide.scrollIntoView({ block: 'center' });
      return;
    }
    const d = document.querySelector('#nvArrivo .nv-data');
    if (d){
      if (d.offsetParent === null && typeof nvpVai === 'function') nvpVai('sogno');
      d.scrollIntoView({ block: 'center' });
      return;
    }
    const pn = document.getElementById('nvPannello'); if (pn) pn.scrollIntoView({ block: 'center' });
  }catch(_){ }
}
/* a ogni fotogramma: se lo slideshow e' stato rifatto (flHeroRifai) o spostato, si torna sulla slide dell'arrivo */
function gtArrivoTieni(){
  if (GT.eroe !== 'rotta') return;
  try{
    const h = FL_HEROES.rotta, a = gtArrivoSlide();
    if (!h || !a || a.i < 0) return;
    if (h.tieni !== a.i || h.slide !== a.i){ h.tieni = a.i; flHeroGo('rotta', a.i); GT.fermo = null; }
  }catch(_){ }
}
function gtLasciaEroe(){
  if (!GT.eroe) return;
  try{ const h = FL_HEROES[GT.eroe]; if (h){ h.tieni = null; h.held = Date.now(); } }catch(_){ }
  GT.eroe = null;
}
/* 0.9.337, Andrea: "l'utente non viene mai fatto scegliere se seguire il Genio o pianificare lui": finito il tour si sceglie subito */
function gtBivioDopo(){
  setTimeout(function(){
    try{
      if (typeof faStrada === 'function' && faStrada()) return;
      if (typeof faApriStrada === 'function') faApriStrada(function(k){ if (k === 'rotta' && typeof sdPianoApri === 'function') sdPianoApri(); });
    }catch(_){ }
  }, 600);
}
/* il titolo della tappa di oggi nella roadmap (quella che il sentiero segna come corrente) */
function gtPrimaTappa(){
  try{
    const n = document.querySelector('#mppSentiero .sd-nodo.corrente');
    const t = n && n.getAttribute('aria-label');
    if (t && String(t).trim()) return String(t).trim();
  }catch(_){ }
  return '';
}

/* ---------- il motore ---------- */
function gtStart(){
  /* i permessi si guardano subito, cosi' l'ultima fermata sa gia' se chiederli */
  GT.permessiOk = false;
  try{ if (typeof gnPermessiDati === 'function') gnPermessiDati().then(function(ok){ GT.permessiOk = !!ok; }); }catch(_){ }
  try{ if (typeof GN !== 'undefined' && GN.permessiOk) GT.permessiOk = true; }catch(_){ }
  if (GT.rivedi) GT.permessiOk = true;
  gtEl();
  GT.on = true; GT.i = 0;
  /* 0.9.402 BUG-217: per tutto il tour nessun punto, VAR o popup (socialproof.js, flMomentoProtetto) */
  try{ if (typeof flMomentoSegna === 'function') flMomentoSegna('tour', true); }catch(_){ }
  document.body.classList.add('gt-on');
  gtVai(0);
}
function gtFine(){
  GT.on = false;
  try{ if (typeof flMomentoSegna === 'function') flMomentoSegna('tour', false); }catch(_){ }
  gtStacca();
  clearInterval(GT.timer);
  document.body.classList.remove('gt-on');
  const el = document.getElementById('gnTour'); if (el) el.remove();
  if (GT.rivedi){ GT.rivedi = false; return; }
  try{ const d = gnDati(); d.tourFatto = Date.now(); gnSalva(); }catch(_){ }
  try{ if (typeof gnPermessi === 'function') gnPermessi(); }catch(_){ }
}
function gtStacca(){
  gtLasciaEroe();
  clearInterval(GT.tick); GT.tick = 0;
  cancelAnimationFrame(GT.raf || 0); GT.raf = 0;
  if (GT.ev){ document.removeEventListener(GT.ev.n, GT.ev.f); GT.ev = null; }
}
function gtVai(i){
  const stops = gtStops();
  if (i >= stops.length){ gtFine(); return; }
  gtStacca();
  GT.i = i; GT.stop = stops[i];
  const s = GT.stop;
  const risp = document.getElementById('gtRisp'); if (risp) risp.innerHTML = '';
  /* 0.9.366, Andrea: "la nuvoletta appare vuota per un attimo". La bolla resta nascosta finche' il Genio non comincia a scrivere */
  const tx = document.getElementById('gtTesto'); if (tx) tx.innerHTML = '';
  const gb = document.getElementById('gtGenioBox'); if (gb) gb.classList.add('gt-attesa');
  const sp0 = document.getElementById('gtSpot'); if (sp0) sp0.classList.remove('gt-pronto');
  GT.fermo = null; GT.lato = null; GT.sistemato = false; GT.fuoriDa = 0;
  gtPosa(s.posa);
  try{ if (s.pre) s.pre(); }catch(_){ }
  setTimeout(function(){
    if (!GT.on || GT.stop !== s) return;
    /* il bersaglio deve stare nella luce: se e' sotto la piega, la scheda scorre fin li' */
    try{ const el = gtTarget(); if (el && !el.closest('.bottomnav, nav')) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
    gtBollaAltezza(s);
    gtMira(s.target);
    gtScrivi(typeof s.testo === 'function' ? s.testo() : s.testo, function(){
      if (s.modo === 'btn' || s.btn){
        const r = document.getElementById('gtRisp');
        if (r) r.innerHTML = '<button type="button" class="gt-btn" onclick="gtBtn()">' + ((typeof s.btn === 'function' ? s.btn() : s.btn) || 'Avanti') + '</button>';
      }
    });
    if (s.modo === 'evento' && s.evento){
      const f = function(){ gtDopoAzione(); };
      GT.ev = { n: s.evento, f: f };
      document.addEventListener(s.evento, f);
    }
  }, s.attesa || 120);
}
/* 0.9.402 BUG-217: quanto sara' alta la bolla a testo finito (con il pulsante): la luce e lo scorrimento la evitano da subito, non quando
   la bolla e' cresciuta sopra all'elemento */
function gtBollaAltezza(s){
  GT.bollaH = 0;
  try{
    const box = document.getElementById('gtGenioBox'), tx = document.getElementById('gtTesto'), r = document.getElementById('gtRisp');
    if (!box || !tx || !r) return;
    const testo = typeof s.testo === 'function' ? s.testo() : s.testo;
    const parti = (typeof gnParti === 'function') ? gnParti(testo) : { html: testo };
    const t0 = tx.innerHTML, r0 = r.innerHTML;
    tx.innerHTML = parti.html;
    if (s.modo === 'btn' || s.btn) r.innerHTML = '<button type="button" class="gt-btn">Avanti</button>';
    GT.bollaH = box.getBoundingClientRect().height;
    tx.innerHTML = t0; r.innerHTML = r0;
  }catch(_){ }
}
function gtBtn(){
  const s = GT.stop; if (!s) return;
  if (s.btnFn){
    s.btnFn();
    /* chi aspetta un evento (la decisione, il piano) avanza quando l'evento arriva */
    if (s.modo === 'evento') return;
  }
  gtDopoAzione();
}
function gtDopoAzione(){
  if (!GT.on) return;
  try{ if (typeof gnAu !== 'undefined') gnAu.scelta(1); }catch(_){ }
  gtVai(GT.i + 1);
}

/* IL BERSAGLIO. Il riflettore segue l'elemento vero (che può muoversi: una scheda che scorre,
   una tastiera che sale), quindi si rimisura quattro volte al secondo finché la fermata dura. */
/* 0.9.402 BUG-217, Andrea: "ho toccato il VAR, sono finito nel Full Focus e il tour continuava: 'Da qui parte il Full Focus' e 'Tocca
   START' sulla pagina sbagliata". Le pagine sotto restano nel DOM (nascoste con visibility), quindi offsetParent non basta: il bersaglio
   vale solo se sta nella casa, con la casa davanti e la sua scheda aperta. */
function gtInCasa(){
  const a = document.querySelector('.screen.active');
  return !!(a && a.id === 's-home');
}
function gtTarget(){
  const s = GT.stop; if (!s || !s.target) return null;
  if (!gtInCasa()) return null;
  const sels = s.target.split(',');
  for (let i = 0; i < sels.length; i++){
    const el = document.querySelector(sels[i].trim());
    if (!el || el.offsetParent === null) continue;
    const scr = el.closest('.screen'); if (scr && !scr.classList.contains('active')) continue;
    /* 0.9.402 BUG-250: in uno slideshow vale solo la slide accesa, non quella che sta uscendo sotto allo sweep */
    const sl = el.closest('.bh-slide'); if (sl && (!sl.classList.contains('on') || sl.classList.contains('bh-out'))) continue;
    try{ const cs = getComputedStyle(el); if (cs.visibility === 'hidden') continue; }catch(_){ }
    return el;
  }
  return null;
}
/* Se l'utente e' finito su un'altra pagina (una notifica, il tasto indietro), il tour non indica cose che li' non ci sono: lo schermo
   resta scuro e dopo mezzo secondo si torna nella casa, sulla scheda di questa fermata. Con una sessione del Full Focus in corso si
   aspetta, senza strappare l'utente dalla sessione. */
function gtRiporta(){
  const s = GT.stop; if (!s) return;
  try{ if (typeof FF !== 'undefined' && FF && FF.run) return; }catch(_){ }
  try{
    if (!gtInCasa() && typeof goId === 'function') goId('s-home');
    if (s.tab && typeof switchTab === 'function' && (typeof navTabCorrente !== 'function' || navTabCorrente() !== s.tab)) switchTab(s.tab);
    if (s.pre) setTimeout(function(){ try{ if (GT.on && GT.stop === s) s.pre(); }catch(_){ } }, 420);
  }catch(_){ }
  GT.fermo = null; GT.sistemato = false;
}
/* La forma del bersaglio: gli angoli veri dell'elemento (border-radius da getComputedStyle, anche in percentuale), piu' il margine. */
function gtAngoli(el, w, h, pad){
  let cs = null; try{ cs = getComputedStyle(el); }catch(_){ }
  const uno = function(v){
    v = String(v || '0').split(' ')[0];
    const n = parseFloat(v) || 0;
    const px = /%$/.test(v) ? n / 100 * Math.min(w, h) : n;
    return Math.round(Math.min(Math.max(px, 6) + pad, (Math.min(w, h) + pad * 2) / 2));
  };
  if (!cs) return '14px';
  return uno(cs.borderTopLeftRadius) + 'px ' + uno(cs.borderTopRightRadius) + 'px ' + uno(cs.borderBottomRightRadius) + 'px ' + uno(cs.borderBottomLeftRadius) + 'px';
}
function gtScorritore(el){
  let n = el && el.parentElement;
  while (n && n !== document.body){
    try{ const oy = getComputedStyle(n).overflowY; if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 2) return n; }catch(_){ }
    n = n.parentElement;
  }
  return null;
}
/* 0.9.366, Andrea: "l'overlay scuro e' disallineato, Clash Royale non lo fa cosi'". La luce si misurava quattro volte al secondo mentre
   la scheda scorreva (scrollIntoView smooth): restava indietro. Ora si rimisura a ogni fotogramma, e la luce si accende solo quando
   l'elemento e' fermo da tre fotogrammi; mentre scorre lo schermo e' tutto scuro */
function gtMira(){
  clearInterval(GT.tick); GT.tick = 0;
  cancelAnimationFrame(GT.raf || 0);
  const giro = function(){ if (!GT.on) return; gtMisura(); GT.raf = requestAnimationFrame(giro); };
  GT.raf = requestAnimationFrame(giro);
}
function gtMisura(){
  const spot = document.getElementById('gtSpot'), arrow = document.getElementById('gtArrow'), box = document.getElementById('gtGenioBox');
  const phone = document.getElementById('phone') || document.body;
  const s = GT.stop;
  /* fuori dalla casa: tutto scuro, nessuna luce, e si torna indietro */
  if (s && !gtInCasa()){
    const sc0 = document.querySelector('#gnTour .gt-scrim'); if (sc0) sc0.style.background = 'rgba(4,10,28,.66)';
    if (spot) spot.hidden = true; if (arrow) arrow.hidden = true;
    const ora = Date.now();
    if (!GT.fuoriDa) GT.fuoriDa = ora;
    else if (ora - GT.fuoriDa > 500){ GT.fuoriDa = ora + 1500; gtRiporta(); }
    return;
  }
  GT.fuoriDa = 0;
  if (s && s.ogni){ try{ s.ogni(); }catch(_){ } }
  const el = gtTarget();
  /* 0.9.342: senza bersaglio l'ombra c'e' comunque */
  { const sc = document.querySelector('#gnTour .gt-scrim'); if (sc) sc.style.background = el ? '' : 'rgba(4,10,28,.66)'; }
  if (!spot || !arrow || !box) return;
  const pr = phone.getBoundingClientRect();
  if (!el){ spot.hidden = true; arrow.hidden = true; box.classList.remove('su'); return; }
  const r = el.getBoundingClientRect();
  const pad = 8;
  /* fermo? tre fotogrammi con la stessa posizione e la stessa misura */
  const firma = Math.round(r.left) + ',' + Math.round(r.top) + ',' + Math.round(r.width) + ',' + Math.round(r.height);
  if (!GT.fermo || GT.fermo.f !== firma){ GT.fermo = { f: firma, n: 0 }; }
  else GT.fermo.n++;
  const pronto = GT.fermo.n >= 3;
  const inNav = !!(el.closest && el.closest('.bottomnav, nav, #bottomNav'));
  const alto = 56, basso = inNav ? pr.height : pr.height - 84;
  /* 0.9.402 BUG-217, Andrea: "il riquadro taglia una parte del pannello: il buio copre tutto tranne l'elemento intero, ritagliato sulla
     sua forma, come nei tour di Clash". La luce e' l'elemento intero con i suoi angoli e un margine: niente tetto all'altezza e niente
     taglio sotto la bolla. E' la bolla a mettersi dall'altra parte, e se serve la pagina scorre finche' l'elemento sta tutto nel libero. */
  const t = r.top - pr.top - pad, b = r.bottom - pr.top + pad;
  const visibile = b > alto && t < basso && r.width > 0 && r.right > pr.left && r.left < pr.right;
  spot.hidden = !visibile;
  spot.classList.toggle('gt-pronto', pronto && visibile);
  /* un elemento piu' alto dello spazio fra la testa e la barra delle schede: la luce si ferma al bordo dello spazio (la barra resta al
     buio, non sembra lei il bersaglio), con il lato dritto dove l'elemento continua */
  const tv = inNav ? t : Math.max(t, alto), bv = inNav ? b : Math.min(b, basso);
  spot.style.left = (r.left - pr.left - pad) + 'px';
  spot.style.top = tv + 'px';
  spot.style.width = (r.width + pad * 2) + 'px';
  spot.style.height = Math.max(0, bv - tv) + 'px';
  { const ang = gtAngoli(el, r.width, r.height, pad).split(' ');
    if (ang.length === 4){ if (tv > t){ ang[0] = '0px'; ang[1] = '0px'; } if (bv < b){ ang[2] = '0px'; ang[3] = '0px'; } spot.style.borderRadius = ang.join(' '); }
    else spot.style.borderRadius = ang.join(' '); }
  /* la bolla: dalla parte con piu' spazio, decisa una volta per fermata (niente altalena mentre la pagina scorre) */
  if (GT.lato === null || GT.lato === undefined){
    GT.lato = inNav ? 'su' : ((t - alto) > (basso - b) ? 'su' : 'giu');
  }
  box.classList.toggle('su', GT.lato === 'su');
  let bt = basso, bbot = alto;
  try{
    const bb = box.getBoundingClientRect(), hb = Math.max(bb.height, GT.bollaH || 0);
    if (GT.lato === 'su'){ bbot = bb.top - pr.top + hb; bt = bb.top - pr.top; }
    else { bt = bb.bottom - pr.top - hb; bbot = bb.bottom - pr.top; }
  }catch(_){ }
  /* l'elemento sotto la bolla: una volta, appena fermo, la pagina scorre fino a metterlo tutto nello spazio libero */
  if (pronto && !inNav && !GT.sistemato){
    GT.sistemato = true;
    const liberoSu = GT.lato === 'su' ? bbot + 12 : alto + 12;
    const liberoGiu = GT.lato === 'su' ? basso - 12 : bt - 12;
    const h = b - t;
    if (t < liberoSu || b > liberoGiu){
      const sc = gtScorritore(el);
      if (sc){
        const spazio = liberoGiu - liberoSu;
        const delta = h <= spazio ? (t - liberoSu) - (spazio - h) / 2 : (t - liberoSu);
        try{ sc.scrollBy({ top: delta, behavior: 'smooth' }); }catch(_){ sc.scrollTop += delta; }
      }
    }
  }
  /* la freccia: sopra all'elemento se c'e' posto, altrimenti sotto, rivolta in su; mai sopra alla bolla */
  const sopraOk = t - 44 > alto && !(GT.lato === 'su' && t - 44 < bbot);
  const sottoOk = b + 44 < basso && !(GT.lato === 'giu' && b + 44 > bt);
  arrow.hidden = !(pronto && visibile) || (!sopraOk && !sottoOk);
  arrow.textContent = sopraOk ? '👇' : '👆';
  arrow.style.left = (r.left - pr.left + r.width / 2) + 'px';
  arrow.style.top = (sopraOk ? t - 42 : b + 4) + 'px';
}
/* Un tocco sull'ombra: se cade dentro alla luce, arriva all'elemento vero. Fuori, niente. */
function gtToccoScrim(e){
  /* 0.9.292, Andrea: "toccando lo schermo il Genio continua a scrivere lettera per lettera invece di mostrare tutto" */
  if (GT.timer && typeof GT.completa === 'function'){ GT.completa(); return; }
  const s = GT.stop; if (!s) return;
  const el = gtTarget(); if (!el) return;
  const r = el.getBoundingClientRect();
  const x = e.clientX, y = e.clientY;
  if (x < r.left - 6 || x > r.right + 6 || y < r.top - 6 || y > r.bottom + 6){
    const a = document.getElementById('gtArrow'); if (a){ a.classList.remove('nudge'); void a.offsetWidth; a.classList.add('nudge'); }
    return;
  }
  const tour = document.getElementById('gnTour');
  tour.style.pointerEvents = 'none';
  const sotto = document.elementFromPoint(x, y) || el;
  tour.style.pointerEvents = '';
  try{
    if (sotto.tagName === 'TEXTAREA' || sotto.tagName === 'INPUT'){ sotto.focus(); return; }
    const b = sotto.closest('button, a, label, [onclick]') || el;
    b.click();
  }catch(_){ }
  if (s.modo === 'tap') setTimeout(gtDopoAzione, 80);
}

/* ---------- lo stile ---------- */
(function(){
  const css = [
    '#gnTour{position:absolute;inset:0;z-index:60;pointer-events:none}',
    '#gnTour .gt-scrim{position:absolute;inset:0;pointer-events:auto}',
    '.gt-spot{position:absolute;border-radius:14px;box-shadow:0 0 0 9999px rgba(4,10,28,.66);pointer-events:none;border:2px solid rgba(140,198,255,0);box-sizing:border-box;transition:border-color .25s}',
    '.gt-spot:not(.gt-pronto){background:rgba(4,10,28,.66)}.gt-spot.gt-pronto{border-color:rgba(140,198,255,.85)}',
    '.gt-genio.gt-attesa .gt-bolla{visibility:hidden}',
    '.gt-arrow{position:absolute;transform:translateX(-50%);font-size:34px;line-height:1;animation:gtBounce 1s ease-in-out infinite;pointer-events:none;filter:drop-shadow(0 4px 8px rgba(0,0,0,.4))}',
    '.gt-arrow.nudge{animation:gtNudge .35s ease}',
    '@keyframes gtBounce{0%,100%{transform:translate(-50%,0)}50%{transform:translate(-50%,-8px)}}',
    '@keyframes gtNudge{0%,100%{transform:translate(-50%,0)}25%{transform:translate(-62%,0)}75%{transform:translate(-38%,0)}}',
    '.gt-genio{position:absolute;left:12px;right:12px;bottom:calc(84px + env(safe-area-inset-bottom));display:flex;align-items:flex-end;gap:8px;pointer-events:none}',
    '.gt-genio.su{bottom:auto;top:calc(56px + env(safe-area-inset-top))}',
    '.gt-genio img{width:96px;height:auto;flex:none;filter:drop-shadow(0 8px 16px rgba(0,0,0,.45))}',
    '.gt-bolla{flex:1;min-width:0;background:#fff;color:#0E2350;border:2px solid #0E2350;border-radius:18px 18px 18px 4px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.35);pointer-events:auto}',
    '.gt-bolla p{margin:0;font:600 15px/1.4 var(--font-body);color:#0E2350}',
    '.gt-bolla p b{color:#0075E3;font-weight:800}',
    /* 0.9.402 BUG-249: mai due evidenziazioni dello stesso colore nella nuvoletta (lezione 317). La seconda e' rossa (^), la terza oro (~) */
    '.gt-bolla p b.c-ros{color:#E63946}.gt-bolla p b.c-oro{color:#C77700}',
    '.gt-risp{margin-top:10px}.gt-risp:empty{display:none}',
    /* 0.9.342, Andrea: "il pulsante giallo, ho capito: nel mio brand non c'e' il giallo" */
    '.gt-btn{width:100%;border:0;border-radius:14px;padding:13px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 6px 16px rgba(0,117,227,.35)}',
    'body.gt-on .gn-tap{display:none}',
    'body.dec-on #gnTour{display:none}'
  ].join('');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
