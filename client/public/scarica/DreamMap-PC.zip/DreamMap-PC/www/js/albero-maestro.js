/* ===========================================================================================
   L'ALBERO MAESTRO: IL PROMPT PER LE AI (0.9.253)

   Andrea: un testo da dare alle AI con cui lavora (Claude, ChatGPT, Gemini, Cursor…) che le
   lega al suo albero maestro: le fa rifiutare le aggiunte fuori rotta e le mette dalla parte
   del nuovo te, contro il vecchio te che aggiunge. Il testo vive in content/albero-maestro.md;
   qui si riempie con il SUO albero (sogno, anno, mese, settimana, oggi: orizzonti.js e il
   foglio) e si copia o si condivide. Si apre dalla pagina del caveau.
   =========================================================================================== */
const AM = { md: '' };
function amEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function amAlbero(){
  const a = {};
  try{ a.SOGNO = (typeof nvSogno === 'function') ? String(nvSogno() || '').trim() : ''; }catch(_){ a.SOGNO = ''; }
  ['anno', 'mese', 'settimana'].forEach(function(k){ try{ a[k.toUpperCase()] = (typeof ozAnello === 'function') ? String((ozAnello(k) || {}).testo || '').trim() : ''; }catch(_){ a[k.toUpperCase()] = ''; } });
  try{ a.OGGI = (typeof stTask === 'function') ? String(stTask() || '').replace(/^[☐☑•]\s*/, '').trim() : ''; }catch(_){ a.OGGI = ''; }
  return a;
}
function amTesto(){
  const a = amAlbero();
  let t = AM.md.replace(/\{\{(SOGNO|ANNO|MESE|SETTIMANA|OGGI)\}\}/g, function(_, k){ return a[k] || '(ancora da scrivere)'; });
  /* 0.9.333: con il ponte acceso, il prompt dice all'AI come avvisare il Genio */
  if (typeof pntOn === 'function'){
    t += '\n\n## Il ponte con DreamMap\n\nAlla fine di ogni lavoro fai sapere al mio Genio cosa ho fatto: un riassunto di una o due frasi, mai la conversazione intera, mai dati sensibili.\n\n'
      + (pntOn() ? '- Se hai i connettori MCP, il server è ' + pntMcpUrl() + ' e lo strumento è `registra_lavoro`.\n- Se puoi fare una chiamata HTTP: POST ' + pntHttpUrl() + ' con JSON {"chiave":"' + pntChiave() + '","riassunto":"...","fonte":"il tuo nome","minuti":0,"in_rotta":true}.\n' : '')
      /* 0.9.353: nella Timeline il riquadro per incollare il resoconto non c'e' piu' (Andrea: "nessuno sta li' a copiare e incollare") */
      + '- Se non puoi chiamare niente, chiudi con un resoconto di due righe che comincia con "Resoconto per DreamMap:": lo mando io al mio Genio in chat.';
  }
  return t;
}
async function amCarica(){
  if (AM.md) return AM.md;
  try{ const r = await fetch('content/albero-maestro.md'); AM.md = await r.text(); }catch(_){ AM.md = ''; }
  return AM.md;
}
async function amApri(silenzioso){
  await amCarica();
  if (!AM.md){ toast('Il testo non è disponibile adesso'); return; }
  let w = document.getElementById('amSheet');
  if (!w){ w = document.createElement('div'); w.id = 'amSheet'; w.className = 'alm-sheet'; w.addEventListener('click', function(e){ if (e.target === w) amChiudi(); }); document.body.appendChild(w); }
  /* 0.9.367, Andrea: "il foglio e' illeggibile: fai sapere al Genio, copia il collegamento, come si usa, l'interruttore, copia il
     prompt, condividi, leggi il prompt, manca un livello del tuo piano... troppe cose insieme". Ora tre scelte, una riga ciascuna:
     ogni riga fa UNA cosa e il dettaglio si apre dopo il tocco. Lo scollegamento sta in fondo, piccolo, solo se sei collegato */
  const on = (typeof pntOn === 'function') && pntOn();
  /* 0.9.397: finche' il server non ha risposto per questa chiave, ne' Collegata ne' Da aggiungere: si controlla (ponte.js), e il foglio
     si ridisegna da solo alla risposta (pntRidisegna) */
  const usata = on && typeof pntUsato === 'function' && pntUsato();
  const controllo = on && !usata && typeof pntInControllo === 'function' && pntInControllo();
  if (controllo && typeof pntSync === 'function' && typeof PNT !== 'undefined' && !PNT.inCorso) Promise.resolve(pntSync(true)).then(function(){ try{ if (typeof pntRidisegna === 'function') pntRidisegna(true); }catch(_){ } });
  const riga = function(ico, t, sub, az, stato){
    return '<button type="button" class="alm-op" onclick="' + az + '"><span class="alm-op-e" aria-hidden="true">' + ico + '</span>'
      + '<span class="alm-op-t"><b>' + t + '</b><small>' + sub + '</small></span>'
      + (stato ? '<em class="alm-op-ok">' + stato + '</em>' : '<i class="alm-op-fr" aria-hidden="true"><svg viewBox="0 0 8 12" width="9" height="14"><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" d="M1.5 1 6.5 6 1.5 11"/></svg></i>') + '</button>';
  };
  w.innerHTML = '<div class="am-in"><i class="pr-grab"></i><button type="button" class="am-x" aria-label="Chiudi" onclick="amChiudi()">✕</button>'
    + '<span class="alm-ico" aria-hidden="true">🌳</span>'
    + '<h3>Il tuo piano, dentro le tue AI</h3>'
    + '<p class="am-sotto">Così la tua AI lavora per il nuovo te.</p>'
    + '<div class="alm-ops">'
    /* 0.9.371: Collegata solo quando la tua AI ha usato davvero il collegamento (ponte.js pntUsato); prima dice cosa manca */
    +   riga('🔌', 'Collega la tua AI', on ? (usata ? 'Legge il piano e scrive al Genio da sola' : (controllo ? 'Controllo il collegamento…' : 'Aggiungi il collegamento alla tua AI')) : 'Claude, ChatGPT, Cursor: un collegamento solo', on ? 'amPonteInfo()' : 'amPonteTocca(null,true)', on ? (usata ? 'Collegata' : (controllo ? 'Controllo…' : 'Da aggiungere')) : '')
    +   riga('📋', 'Copia il prompt', 'Per le AI senza collegamento: incollalo all’inizio della chat', 'amCopia()')
    +   riga('🌙', 'Il resoconto della sera', 'Ogni sera la tua AI aggiorna il percorso', 'amChiudi();setTimeout(function(){ if(typeof pntRoadmapApri===\'function\')pntRoadmapApri(); },250)')
    + '</div>'
    + (on ? '<button type="button" class="alm-scollega" onclick="amPonteTocca(this)">Scollega le tue AI</button>' : '')
    + '</div>';
  w.hidden = false;
  if (!silenzioso){ try{ flVibra(8); }catch(_){ } }
}
function amTestoMostra(b){ const x = document.getElementById('amBox'); if (!x) return; x.hidden = !x.hidden; b.textContent = x.hidden ? 'Leggi il prompt' : 'Nascondi il prompt'; }
async function amPonteTocca(b, poiPassi){
  if (b) b.disabled = true;
  let ok = false;
  try{
    if (pntOn()){ await pntScollega(); toast('Scollegato: quello che le tue AI avevano scritto è cancellato'); }
    else { await pntCollega(); ok = true; }
  }catch(_){ toast('Serve la rete per collegare le tue AI'); }
  amApri();
  if (ok && poiPassi) setTimeout(amPonteInfo, 120);
}
async function amPonteCopia(){
  let ok = false;
  try{ await navigator.clipboard.writeText(pntMcpUrl()); ok = true; }catch(_){ }
  if (!ok){ try{ const ta = document.createElement('textarea'); ta.value = pntMcpUrl(); ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); }catch(_){ } }
  toast(ok ? 'Collegamento copiato' : 'Non sono riuscito a copiare');
}
/* 0.9.341, Andrea: "il testo e' tutto attaccato e non ci sono istruzioni pratiche, step 1, step 2, step 3: vai nella tua AI, vai su
   connettori, aggiungi il connettore". Una sezione per AI, con i passi numerati, e i due pulsanti per copiare quello che serve. */
/* 0.9.367, Andrea: "Claude, ChatGPT, tutto in un unico popover e' troppo: o si fa scegliere qual e' la tua AI e poi le istruzioni
   per quella, altrimenti e' overwhelming". Prima la scelta (quattro pulsanti), poi i passi della sola AI scelta. */
const AM_PASSI = [
  { k: 'claude', ico: '🟠', t: 'Claude', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'Apri Claude (app o sito) e vai in Impostazioni, poi in Connettori.',
    'Tocca "Aggiungi un connettore personalizzato", scrivi DreamMap e incolla il collegamento.',
    /* 0.9.374, Andrea: "Claude chiede Accedi ora, Accedi quando necessario o Nessun accesso, e noi non diciamo cosa scegliere". Claude lo
       chiede per ogni connettore nuovo; DreamMap non ha un accesso da fare perche' la chiave e' gia' dentro al collegamento */
    'Alla voce Autenticazione scegli "Nessun accesso" (Claude lo segna come Rilevato) e tocca Aggiungi. Non serve accedere: la tua chiave è già nel collegamento.'], fine: 'In una chat nuova scrivi "Leggi il mio piano DreamMap".', schermo: true },
  { k: 'chatgpt', ico: '💬', t: 'ChatGPT', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'In ChatGPT apri Impostazioni, poi App e connettori, e attiva la modalità sviluppatore.',
    'Crea un connettore e incolla il collegamento.'], fine: 'Da lì in poi ChatGPT legge il tuo piano e scrive al Genio da solo.' },
  /* 0.9.371, Andrea: "nessun utente si mette a scrivere nel terminale; non sono tutti programmatori. Claude ha i connettori personalizzati:
     basta mostrare la schermata di Claude". Claude Code legge gli stessi connettori dell'account Claude: si aggiunge da Claude, una volta */
  { k: 'code', ico: '💻', t: 'Claude Code o Cursor', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'Claude Code: apri Claude (app o sito), Impostazioni, Connettori, "Aggiungi un connettore personalizzato", e incolla il collegamento. Alla voce Autenticazione scegli "Nessun accesso". Se usi Claude Code con lo stesso account, lo trova da solo.',
    'Cursor: Impostazioni, poi MCP, poi "Aggiungi un nuovo server", e incolla il collegamento.'], fine: 'Da lì in poi l’AI legge il tuo piano e scrive al Genio da sola.', schermo: true },
  { k: 'altre', ico: '✨', t: 'Gemini o un’altra AI', prompt: true, p: [
    'Tocca "Copia il prompt" qui sotto.',
    'Incollalo come primo messaggio di una chat nuova.',
    'Alla fine chiedi il resoconto per DreamMap e mandalo al Genio.'], fine: '' }
];
function amPonteInfo(k){
  const on = (typeof pntOn === 'function') && pntOn();
  const x = AM_PASSI.filter(function(v){ return v.k === k; })[0];
  if (!x){
    const html = '<div class="en-foglio am-come"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="rmp-i-ico" aria-hidden="true">🔌</span><h3>Qual è la tua AI?</h3>'
      + '<div class="am-scegli">' + AM_PASSI.map(function(v){ return '<button type="button" onclick="amPonteInfo(\'' + v.k + '\')"><span aria-hidden="true">' + v.ico + '</span><b>' + amEsc(v.t) + '</b></button>'; }).join('') + '</div>'
      + '<p class="am-come-n">🔒 Il collegamento è solo tuo. Non darlo ad altri.</p></div>';
    if (document.querySelector('.am-come')){ const f = document.querySelector('.am-come'); f.outerHTML = html; } else inSheet(html);
    return;
  }
  const html = '<div class="en-foglio am-come"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>' + (x.schermo ? '' : '<span class="rmp-i-ico" aria-hidden="true">' + x.ico + '</span>') + '<h3>' + amEsc(x.t) + '</h3>'
    + (x.schermo ? amSchermoClaude() : '')
    + '<section class="am-come-b"><ol>' + x.p.map(function(r){ return '<li>' + amEsc(r) + '</li>'; }).join('') + '</ol>' + (x.fine ? '<p class="am-come-fine">' + amEsc(x.fine) + '</p>' : '') + '</section>'
    + '<div class="am-come-az">' + (x.prompt ? '<button type="button" class="cta" onclick="amCopia()">Copia il prompt</button>' : '<button type="button" class="cta" onclick="amCollegaECopia()">Copia il collegamento</button>') + '</div>'
    + '<button type="button" class="am-cambia" onclick="amPonteInfo()">Cambia AI</button></div>';
  const f = document.querySelector('.am-come'); if (f) f.outerHTML = html; else inSheet(html);
}
/* 0.9.367: per Claude, ChatGPT e Cursor serve il collegamento: se il ponte e' spento si accende e si copia, un tocco solo */
async function amCollegaECopia(){
  try{ if (typeof pntOn === 'function' && !pntOn()) await pntCollega(); }catch(_){ toast('Serve la rete per collegare le tue AI'); return; }
  amPonteCopia();
}
/* il disegno della finestra di Claude dove si aggiunge il connettore: si riconosce al volo */
function amSchermoClaude(){
  return '<div class="am-scr" aria-label="Claude: Impostazioni, Connettori, Aggiungi un connettore personalizzato">'
    + '<div class="am-scr-top"><i></i><i></i><i></i><b>Impostazioni</b></div>'
    + '<div class="am-scr-c"><div class="am-scr-menu"><span>Generali</span><span>Profilo</span><span class="on">Connettori</span><span>Privacy</span></div>'
    + '<div class="am-scr-main"><b>Connettori</b><small>Collega Claude alle tue app e ai tuoi servizi.</small>'
    + '<div class="am-scr-btn">+ Aggiungi un connettore personalizzato</div>'
    + '<div class="am-scr-form"><label>Nome</label><div class="am-scr-in">DreamMap</div><label>URL del server MCP</label><div class="am-scr-in incolla">Incolla qui il collegamento</div>'
    + '<label>Autenticazione</label><div class="am-scr-auth"><span>○ Accedi ora</span><span>○ Accedi quando necessario</span><span class="on">● Nessun accesso <em>Rilevato</em></span></div></div></div></div></div>';
}
function amChiudi(){ const w = document.getElementById('amSheet'); if (w) w.hidden = true; }
async function amCopia(){
  const t = amTesto();
  let ok = false;
  try{ if (navigator.clipboard && navigator.clipboard.writeText){ await navigator.clipboard.writeText(t); ok = true; } }catch(_){ }
  if (!ok){ try{ const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); }catch(_){ } }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast(ok ? 'Copiato: incollalo nella chat con l’AI' : 'Non sono riuscito a copiare: usa Condividi');
}
function amCondividi(){
  const t = amTesto();
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ NATIVE.shareText({ text: t, title: 'L’albero maestro' }); return; } }catch(_){ }
  try{ if (navigator.share){ navigator.share({ title: 'L’albero maestro', text: t }); return; } }catch(_){ }
  amCopia();
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.am-come{text-align:center}.am-come h3,.am-come .rmp-i-ico{text-align:center}.am-come-s{margin:6px 0 20px!important;text-align:center;font:500 14px var(--font-body);color:var(--muted)}',
    '.am-come-b{margin:0 0 16px;padding:16px;border-radius:18px;background:var(--bg,#F4F9FF);border:1px solid var(--line)}body.dark .am-come-b{background:#12203A;border-color:#22345A}',
    '.am-come-b > b{display:flex;align-items:center;justify-content:center;gap:10px;font:800 16px var(--font-display);color:var(--navy)}.am-come-b > b span{font-size:20px}',
    '.am-come-b ol{margin:14px 0 0;padding:0;list-style:none;counter-reset:pa;text-align:left}.am-come-b li{position:relative;counter-increment:pa;margin:0 0 10px;padding-left:36px;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .am-come-b li{color:#DCEBFF}.am-come-b li:last-child{margin-bottom:0}',
    '.am-come-b li::before{content:counter(pa);position:absolute;left:0;top:0;width:24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:800 12.5px/24px var(--font-body);text-align:center}',
    '.am-come-az .alm-sec{display:block;width:100%;margin:0;padding:15px 18px;border-radius:50px;border:1.5px solid #0075E3;background:transparent;color:#0075E3;font:800 15px var(--font-body);cursor:pointer}body.dark .am-come-az .alm-sec{color:#8CC6FF;border-color:#8CC6FF}',
    '.alm-ops{display:flex;flex-direction:column;gap:12px;margin:26px 0 8px}',
    '.alm-op{display:flex;align-items:center;gap:14px;width:100%;padding:16px;border:1px solid #C8EFFD;border-radius:18px;background:#F0FBFF;text-align:left;cursor:pointer}',
    'body.dark .alm-op{background:#1C2E5A;border-color:#2A4170}',
    '.alm-op-e{flex:none;width:44px;height:44px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:22px}body.dark .alm-op-e{background:#14234A}',
    '.alm-op-t{flex:1;min-width:0}.alm-op-t b{display:block;font:800 15.5px var(--font-display);color:var(--navy,#001E44)}body.dark .alm-op-t b{color:#fff}',
    '.alm-op-t small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}body.dark .alm-op-t small{color:#C9D6EE}',
    '.alm-op-fr{flex:none;font:400 26px/1 var(--font-body);font-style:normal;color:#3F9FF4}',
    '.alm-op-ok{flex:none;padding:5px 10px;border-radius:99px;background:#0075E3;color:#fff;font:800 11.5px var(--font-body);font-style:normal}',
    '.alm-scollega{display:block;margin:18px auto 4px;padding:8px 14px;border:0;background:none;color:var(--muted);font:600 13px var(--font-body);text-decoration:underline;cursor:pointer}',
    '.am-scegli{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:26px 0 22px}',
    '.am-scegli button{display:flex;flex-direction:column;align-items:center;gap:10px;padding:20px 10px;border:1px solid #C8EFFD;border-radius:18px;background:#F0FBFF;cursor:pointer}body.dark .am-scegli button{background:#12203A;border-color:#22345A}',
    '.am-scegli span{font-size:30px;line-height:1}.am-scegli b{font:800 14.5px/1.3 var(--font-body);color:var(--navy)}body.dark .am-scegli b{color:#fff}',
    '.am-come-fine{margin:14px 0 0!important;text-align:left;font:600 13.5px/1.5 var(--font-body);color:#0075E3}body.dark .am-come-fine{color:#8CC6FF}',
    '.am-come .am-come-b{margin-top:22px}',
    '.am-cambia{display:block;margin:0 auto;padding:10px 16px;border:0;background:none;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}body.dark .am-cambia{color:#8CC6FF}',
    '.am-come-az{display:flex;flex-direction:column;gap:10px;margin:22px 0 14px}.am-come-az .cta{width:100%;margin:0}.am-come-n{margin:0!important;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.alm-sheet{position:fixed;inset:0;z-index:9400;background:rgba(5,12,30,.55);display:flex;align-items:flex-end;justify-content:center}.alm-sheet[hidden]{display:none}',
    '.am-in{width:100%;max-width:520px;max-height:88vh;overflow:auto;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:10px 18px calc(18px + env(safe-area-inset-bottom))}',
    'body.dark .am-in{background:#14234A;color:#fff}',
    /* 0.9.397: la X a 14px dal bordo del foglio (friends.js spiega la causa): .am-in e' il foglio stesso, senza un padding che la rientri */
    '.am-in > .am-x{top:14px;right:14px;z-index:5}',
    '.am-in{position:relative}.alm-ico{display:block;margin:12px 0 8px;font-size:40px;line-height:1;text-align:center}.alm-b{margin-top:14px;padding:16px;border-radius:20px;background:#F0FBFF;text-align:center}body.dark .alm-b{background:#1C2E5A}.alm-b b{display:block;font:800 16px var(--font-display);color:var(--navy,#14234A)}body.dark .alm-b b{color:#fff}.alm-b small{display:block;margin-top:4px;font:500 13.5px/1.4 var(--font-body);color:var(--muted,#5B6B86)}body.dark .alm-b small{color:#C9D6EE}',
    '.alm-az{display:flex;gap:8px;margin-top:14px}.alm-az .cta{flex:1;margin:0}.alm-sec{flex:none;padding:0 16px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}body.dark .alm-sec{color:#fff}.alm-link{margin-top:12px;padding:0;border:0;background:none;color:#0075E3;font:700 13.5px var(--font-body);cursor:pointer}body.dark .alm-link{color:#8CC6FF}.alm-b .am-box{margin-top:10px;max-height:220px;overflow:auto;text-align:left}.alm-b .am-box[hidden]{display:none}.alm-manca{margin:12px 0 0;font:600 13px var(--font-body);color:#C62835}.alm-r{display:flex;align-items:center;gap:12px;text-align:left}.alm-r > div{flex:1;min-width:0}.alm-url{margin-top:12px;padding:10px;border-radius:12px;background:var(--card,#fff);overflow:hidden}body.dark .alm-url{background:#14234A}.alm-url code{display:block;font:500 11.5px monospace;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.am-kick{margin:10px 0 4px;text-align:center;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}',
    '.am-in h3{margin:0;text-align:center;font:800 20px var(--font-display,var(--font-body));color:var(--navy,#14234A)}body.dark .am-in h3{color:#fff}',
    '.am-sotto{margin:8px 0 10px;text-align:center;font:500 13.5px/1.5 var(--font-body);color:var(--muted,#5B6B86)}body.dark .am-sotto{color:#C9D6EE}',
    '.am-avviso{margin:0 0 10px;padding:9px 12px;border-radius:12px;background:rgba(255,214,107,.18);border:1px solid rgba(255,214,107,.6);font:600 12.5px/1.45 var(--font-body);color:#C42B38}body.dark .am-avviso{color:#FF8A93}',
    '.am-box{max-height:38vh;overflow:auto;white-space:pre-wrap;padding:12px;border-radius:14px;background:var(--bg,#F3F6FB);font:500 12.5px/1.5 var(--font-body);color:var(--navy,#14234A)}body.dark .am-box{background:rgba(255,255,255,.06);color:#EEF4FF}',
    '.am-btn{display:flex;gap:8px;margin:12px 0 4px}.am-btn .cta{flex:1;margin:0}',
    '.am-share{flex:0 0 auto;padding:0 16px;border:0;border-radius:99px;background:transparent;box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}body.dark .am-share{color:#fff;box-shadow:0 0 0 1.5px rgba(255,255,255,.25)}',
    '.cvp-prompt{display:flex;align-items:center;gap:12px;width:100%;margin:0 0 12px;padding:14px;border:0;border-radius:18px;text-align:left;background:linear-gradient(135deg,#1E2A5A,#0F2041);color:#fff;cursor:pointer}',
    '.cvp-prompt span{font-size:26px;flex:none}.cvp-prompt b{display:block;font:800 14.5px var(--font-body)}.cvp-prompt small{display:block;margin-top:2px;font:500 12.5px/1.4 var(--font-body);color:#C9D6EE}'
  ].join('');
  document.head.appendChild(st);
})();

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = '.am-scr{margin:6px 0 26px;border-radius:16px;overflow:hidden;background:#F5F4EE;box-shadow:0 0 0 1px #E2DED3,0 8px 20px rgba(0,30,68,.12);text-align:left;font-family:var(--font-body)}'
    + '.am-scr-top{display:flex;align-items:center;gap:5px;padding:9px 12px;background:#ECE9DF}.am-scr-top i{width:8px;height:8px;border-radius:50%;background:#D4CFC2}.am-scr-top b{margin-left:8px;font:700 11.5px var(--font-body);color:#3D3929}'
    + '.am-scr-c{display:flex;min-height:150px}.am-scr-menu{flex:none;width:30%;padding:10px 8px;border-right:1px solid #E2DED3;display:flex;flex-direction:column;gap:4px}.am-scr-menu span{padding:5px 7px;border-radius:7px;font:500 10.5px var(--font-body);color:#6B6556}.am-scr-menu span.on{background:#E3DFD3;color:#1F1E1A;font-weight:700}'
    + '.am-scr-main{flex:1;min-width:0;padding:10px 12px}.am-scr-main > b{display:block;font:700 13px var(--font-body);color:#1F1E1A}.am-scr-main > small{display:block;margin:2px 0 10px;font:500 10px/1.35 var(--font-body);color:#6B6556}'
    + '.am-scr-btn{display:inline-block;padding:6px 10px;border-radius:8px;background:#C96442;color:#fff;font:700 10.5px var(--font-body);box-shadow:0 0 0 3px rgba(201,100,66,.25)}'
    + '.am-scr-form{margin-top:10px;padding:8px;border-radius:10px;background:#fff;box-shadow:0 0 0 1px #E2DED3}.am-scr-form label{display:block;margin:4px 0 3px;font:600 9.5px var(--font-body);color:#6B6556}.am-scr-in{padding:5px 7px;border-radius:6px;box-shadow:0 0 0 1px #D9D4C7;font:500 10px var(--font-body);color:#1F1E1A}.am-scr-in.incolla{color:#9A9384;box-shadow:0 0 0 1.5px #0075E3}';
  document.head.appendChild(st);
})();

/* 0.9.374: la voce Autenticazione nel disegno della finestra di Claude */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.am-scr-auth{display:flex;flex-direction:column;gap:4px;margin-top:4px;font:600 10.5px var(--font-body);color:#5B6B85}.am-scr-auth .on{color:#001E44;font-weight:800}.am-scr-auth em{font-style:normal;font-size:9.5px;padding:1px 6px;border-radius:99px;background:#E3F1FF;color:#0075E3;margin-left:4px}'; document.head.appendChild(st); })();
