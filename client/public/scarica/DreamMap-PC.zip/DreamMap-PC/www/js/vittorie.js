/* ===========================================================================================
   IL PUNTEGGIO PRIMA DI TUTTO (0.9.367)

   Andrea: "nella revisione serale, settimanale, in tutte le revisioni e nel report settimanale, per prima cosa lo score della
   partita fra il vecchio se' e il nuovo se': e' quello che dice se ti stai avvicinando al sogno. Mostragli se sta vincendo o
   perdendo, gli ultimi punti segnati e a cosa sono stati attribuiti. E la serie: sei imbattuto da X giorni contro il vecchio
   te, oppure da X giorni il vecchio te ti sta asfaltando e tu non reagisci".

   Fonte dei numeri: la storia della partita (match.js, mgHist: ogni giorno con i suoi eventi, chi ha segnato, quanti punti, il
   motivo). Niente di inventato: un giorno senza eventi non e' ne' vinto ne' perso e interrompe la serie.
   - vtGiorni(): per giorno { old, neo, ev }.
   - vtSerie(): la serie di giorni chiusi vinti (o persi) di fila, da ieri all'indietro; oggi si aggiunge se e' gia' in vantaggio.
   - vtHtml(titolo, da, a): il tabellone del periodo, la serie, gli ultimi punti. Lo usano la revisione della sera
     (revisione.js), il report della settimana (settimana.js) e le revisioni di settimana/mese/trimestre (revisioni-periodo.js).
   =========================================================================================== */
function vtEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function vtK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function vtEventi(){
  const out = [];
  try{
    const h = (typeof mgHist === 'function') ? mgHist() : [];
    /* 0.9.404 BUG-310: una riga "annullo" (il doppione tolto) toglie un punto al vecchio te, una "revoca" lo toglie al nuovo te.
       Prima diventavano un punto in piu' al nuovo te ("Punto fuori rotta contato due volte... +1 Nuovo te"). `src` e' la riga
       intera: la (i) del punto ne legge i dettagli (programma, app, dispositivo) */
    h.forEach(function(g){ (g && g.eventi || []).forEach(function(e){
      if (!e || e.stornato) return;
      const tolto = e.chi === 'annullo' || e.chi === 'revoca';
      out.push({ chi: e.chi === 'old' || e.chi === 'annullo' ? 'old' : 'neo', tolto: tolto, n: Math.max(1, Math.round(+e.punti || 1)), at: +e.at || 0, m: String(e.motivo || ''), src: e });
    }); });
  }catch(_){ }
  return out.sort(function(a, b){ return a.at - b.at; });
}
function vtGiorni(){
  const g = {};
  vtEventi().forEach(function(e){ const k = vtK(e.at); g[k] = g[k] || { old: 0, neo: 0, ev: [] }; g[k][e.chi] = Math.max(0, g[k][e.chi] + (e.tolto ? -e.n : e.n)); g[k].ev.push(e); });
  return g;
}
/** { tipo: 'vinte'|'perse'|'', n, oggi: { old, neo } } */
function vtSerie(){
  const g = vtGiorni(), oggi = vtK(Date.now());
  let tipo = '', n = 0;
  for (let i = 1; i < 400; i++){
    const k = vtK(Date.now() - i * 86400000), x = g[k];
    if (!x || x.old === x.neo) break;
    const t = x.neo > x.old ? 'vinte' : 'perse';
    if (!tipo) tipo = t; else if (t !== tipo) break;
    n++;
  }
  const o = g[oggi] || { old: 0, neo: 0 };
  /* oggi conta solo se allunga la serie gia' in corso nella stessa direzione */
  if (o.neo > o.old && (tipo === 'vinte' || !tipo)){ tipo = 'vinte'; n++; }
  else if (o.old > o.neo && (tipo === 'perse' || !tipo)){ tipo = 'perse'; n++; }
  return { tipo: tipo, n: n, oggi: o };
}
function vtSomma(da, a){
  const o = { old: 0, neo: 0, ev: [] };
  vtEventi().forEach(function(e){ if (e.at >= da && e.at <= a){ o[e.chi] = Math.max(0, o[e.chi] + (e.tolto ? -e.n : e.n)); o.ev.push(e); } });
  return o;
}
function vtSerieFrase(s, nome){
  const n = s.n;
  if (!s.tipo || !n) return '';
  /* 0.9.369, Andrea: "dice sei imbattuto da 8 giorni mentre oggi perdo 2 a 6". Se oggi va nell'altro verso, la frase lo dice */
  const o = s.oggi || { old: 0, neo: 0 };
  if (s.tipo === 'vinte' && o.old > o.neo) return 'Fino a ieri eri imbattuto da ' + n + (n === 1 ? ' giorno' : ' giorni') + '. Oggi il vecchio te è avanti. Puoi ancora rimontare.';
  if (s.tipo === 'perse' && o.neo > o.old) return 'Il vecchio te vinceva da ' + n + (n === 1 ? ' giorno' : ' giorni') + '. Oggi sei avanti tu. Tieni duro fino a stasera.';
  if (s.tipo === 'vinte') return n === 1 ? 'Hai vinto l’ultima giornata contro il vecchio te.' : 'Sei imbattuto da ' + n + ' giorni contro il vecchio te.';
  return n === 1 ? 'L’ultima giornata l’ha vinta il vecchio te. Reagisci adesso.' : 'Da ' + n + ' giorni il vecchio te ti sta battendo' + (nome ? ', ' + nome : '') + '. Oggi reagisci.';
}
function vtNome(){ try{ return String((JSON.parse(localStorage.getItem('fl_user') || 'null') || {}).name || '').split(' ')[0]; }catch(_){ return ''; } }
function vtOra(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
/**
 * Il tabellone del periodo [da, a]. titolo: "oggi", "questa settimana"... scuro: testo chiaro (scene scure).
 */
function vtHtml(titolo, da, a, scuro){
  const p = vtSomma(da, a), s = vtSerie(), nome = vtNome();
  const esito = p.neo > p.old ? 'Stai vincendo tu' : (p.old > p.neo ? 'Sta vincendo il vecchio te' : (p.neo ? 'Pareggio' : 'La partita non è ancora cominciata'));
  const ultimi = p.ev.slice(-3).reverse();
  return '<div class="vt' + (scuro ? ' scuro' : '') + '">'
    + '<p class="vt-kick">La partita di ' + vtEsc(titolo) + '</p>'
    + '<div class="vt-tab"><div class="vt-sq neo' + (p.neo > p.old ? ' su' : '') + '"><small>Nuovo te</small><b>' + p.neo + '</b></div><span class="vt-vs">:</span>'
    + '<div class="vt-sq old' + (p.old > p.neo ? ' su' : '') + '"><small>Vecchio te</small><b>' + p.old + '</b></div></div>'
    + '<p class="vt-esito">' + esito + '</p>'
    + (s.tipo ? '<div class="vt-serie ' + s.tipo + '"><span aria-hidden="true">' + (s.tipo === 'vinte' ? '🏆' : '⚠️') + '</span><p>' + vtEsc(vtSerieFrase(s, nome)) + '</p></div>' : '')
    + (ultimi.length ? '<div class="vt-ult"><p class="vt-ult-t">Gli ultimi punti</p>' + ultimi.map(function(e){
        return '<div class="vt-pt ' + e.chi + '"><i>' + (e.tolto ? '−' : (e.chi === 'neo' ? '+' : '−')) + e.n + '</i><div><b>' + vtEsc(e.m || (e.chi === 'neo' ? 'Punto per il nuovo te' : 'Punto per il vecchio te')) + '</b><small>' + (e.chi === 'neo' ? 'Nuovo te' : 'Vecchio te') + ' · ' + vtOra(e.at) + '</small></div></div>';
      }).join('') + '</div>' : '')
    + '</div>';
}
/* 0.9.369, Andrea: "il punteggio, stai vincendo, la serie e gli ultimi punti tutti nella stessa schermata: troppo". I pezzi separati, una
   schermata ciascuno: il tabellone con l'esito, poi la serie (la dice il Genio), poi gli ultimi punti */
function vtTabHtml(titolo, da, a, scuro){
  const p = vtSomma(da, a);
  const esito = p.neo > p.old ? 'Stai vincendo tu' : (p.old > p.neo ? 'Sta vincendo il vecchio te' : (p.neo ? 'Pareggio' : 'La partita non è ancora cominciata'));
  return '<div class="vt' + (scuro ? ' scuro' : '') + '"><p class="vt-kick">La partita di ' + vtEsc(titolo) + '</p>'
    /* 0.9.372, Andrea: "nel resto dell'app il vecchio te sta a sinistra e il nuovo te a destra: qui era al contrario, confonde". Sempre lo
       stesso ordine: vecchio te, poi nuovo te. E l'esito ha spazio prima del pulsante */
    + '<div class="vt-tab"><div class="vt-sq old' + (p.old > p.neo ? ' su' : '') + '"><small>Vecchio te</small><b>' + p.old + '</b></div><span class="vt-vs">:</span>'
    + '<div class="vt-sq neo' + (p.neo > p.old ? ' su' : '') + '"><small>Nuovo te</small><b>' + p.neo + '</b></div></div>'
    + '<p class="vt-esito" style="margin-bottom:32px">' + esito + '</p></div>';
}
/* 0.9.404 BUG-310, Andrea: "Ecco gli ultimi punti: tutti insieme, senza motivo e senza dettagli". Adesso:
   - tutti i punti del giorno, dal piu' recente, tre per slide: si vedono i primi tre, "Mostra altri" porta alla slide dopo e il
     contatore dice dove sei (2/4). Si scorre anche col dito;
   - ogni punto dice il motivo preciso (quale programma, quale app, da quale dispositivo) e ha una (i) con i dettagli;
   - un punto tolto (il doppione, la revoca) si vede come punto tolto, non come punto in piu' al nuovo te. */
const VT_PER_SLIDE = 3;
function vtPuntiHtml(da, a, scuro){
  const tutti = vtSomma(da, a).ev.slice().reverse();
  if (!tutti.length) return '';
  const pagine = [];
  for (let i = 0; i < tutti.length; i += VT_PER_SLIDE) pagine.push(tutti.slice(i, i + VT_PER_SLIDE));
  const n = pagine.length;
  return '<div class="vt' + (scuro ? ' scuro' : '') + '"><div class="vt-ult vt-car-w" style="margin-top:0">'
    + '<div class="vt-car" onscroll="vtCarScorri(this)">' + pagine.map(function(pg, pi){
        return '<div class="vt-pag">' + pg.map(function(e, j){ return vtPuntoHtml(e, 'vtp' + pi + '_' + j); }).join('') + '</div>';
      }).join('') + '</div>'
    + (n > 1 ? '<div class="vt-car-nav"><span class="vt-car-n" aria-live="polite">1/' + n + '</span>'
      + '<button type="button" class="vt-car-piu" onclick="event.stopPropagation();vtCarAvanti(this)">Mostra altri</button></div>' : '')
    + '</div></div>';
}
function vtPuntoHtml(e, id){
  const segno = e.tolto ? '−' : (e.chi === 'neo' ? '+' : '−');
  const testo = e.tolto
    ? (e.chi === 'old' ? 'Punto tolto al vecchio te' : 'Punto tolto al nuovo te')
    : (vtMotivoPulito(vtMotivoVero(e) || vtMotivoProg(e) || e.m) || (e.chi === 'neo' ? 'Punto per il nuovo te' : 'Punto per il vecchio te'));
  const chi = e.tolto ? 'Punto tolto' : (e.chi === 'neo' ? 'Nuovo te' : 'Vecchio te');
  return '<div class="vt-pt ' + e.chi + (e.tolto ? ' tolto' : '') + '"><i>' + segno + e.n + '</i><div><b>' + vtEsc(testo) + '</b><small>' + chi + ' · ' + vtOra(e.at) + '</small>'
    + '<div class="vt-dett" id="' + id + '" hidden>' + vtDettagliHtml(e) + '</div></div>'
    + '<button type="button" class="vt-info" aria-label="Dettagli del punto" aria-expanded="false" onclick="event.stopPropagation();vtInfo(this,\'' + id + '\')">i</button></div>';
}
/* I dettagli della (i): niente "etichetta: valore" sulla stessa riga (dopo i due punti si va a capo), l'etichetta sopra e il valore sotto */
function vtDettagli(e){
  const r = e.src || {}, out = [];
  const prog = r.prog || vtProgDa(e);
  const pkg = r.rotta || r.ancora || '';
  let app = '';
  if (pkg) app = vtNomeApp(pkg);
  else if (/^fuori rotta:/i.test(e.m)) app = 'La chat con l’AI sul computer';
  if (e.tolto) out.push(['Cosa è successo', vtMotivoPulito(e.m)]);
  if (prog) out.push(['Programma', prog]);
  if (app) out.push(['App', app]);
  out.push(['Ora', vtOra(e.at)]);
  const dev = r.da && r.da !== 'altro' ? String(r.da) : (r.da === 'altro' ? 'Il tuo altro dispositivo' : 'Questo dispositivo');
  out.push(['Dove', dev]);
  out.push(['Punti', (e.tolto ? 'Tolto ' : '') + e.n + (e.n === 1 ? ' punto' : ' punti') + (e.tolto ? '' : (e.chi === 'neo' ? ' al nuovo te' : ' al vecchio te'))]);
  const nota = /\(×\d+,\s*([^)]*)\)/.exec(e.m);
  if (nota) out.push(['Perché vale ' + e.n, 'La regola della tua partita.\n' + nota[1].replace(/^./, function(c){ return c.toUpperCase(); })]);
  return out;
}
function vtNomeApp(pkg){
  try{ if (typeof tlNomeApp === 'function') return tlNomeApp(pkg); }catch(_){ }
  try{ const n = JSON.parse(localStorage.getItem('fl_app_nomi') || '{}') || {}; if (n[pkg]) return String(n[pkg]); }catch(_){ }
  const via = ['com', 'android', 'app', 'apps', 'google', 'org', 'net', 'www', 'mobile'];
  const p = String(pkg || '').split('.').filter(function(x){ return x && via.indexOf(x.toLowerCase()) < 0; });
  const n = p.length ? p[0] : String(pkg || '');
  return n.charAt(0).toUpperCase() + n.slice(1);
}
function vtDettagliHtml(e){
  return vtDettagli(e).map(function(x){ return '<p><small>' + vtEsc(x[0]) + '</small><span>' + vtEsc(x[1]).replace(/\n/g, '<br>') + '</span></p>'; }).join('');
}
/* Il programma di un "blocco interrotto" scritto prima che il motivo lo dicesse: il registro delle interruzioni (interrupt.js,
   fl_interrupts_log) ha l'ora e il codice del programma; si cerca la riga nello stesso istante */
function vtProgDa(e){
  if (!/^blocco (interrotto|rapido)/i.test(e.m)) return '';
  if (/^blocco rapido/i.test(e.m)) return 'Blocco rapido';
  const g = /^blocco interrotto: «([^»]+)»/i.exec(e.m);
  if (g) return g[1];
  try{
    const reg = JSON.parse(localStorage.getItem('fl_interrupts_log') || '[]') || [];
    let best = null, d0 = 15000;
    reg.forEach(function(x){ if (!x || !x.at) return; const d = Math.abs(x.at - e.at); if (d < d0){ d0 = d; best = x; } });
    if (!best || !best.id) return '';
    if (best.id === 'quick') return 'Blocco rapido';
    const pid = String(best.id).replace(/^p/, '');
    const progs = (typeof PROGRAMS !== 'undefined' && PROGRAMS) ? PROGRAMS : (JSON.parse(localStorage.getItem('fl_programs') || '[]') || []);
    const p = progs.filter(function(x){ return x && String(x.id) === pid; })[0];
    return (p && p.name) ? String(p.name) : '';
  }catch(_){ return ''; }
}
function vtMotivoProg(e){
  if (!/^blocco interrotto\s*(\(|$)/i.test(e.m)) return '';
  const p = vtProgDa(e);
  return p ? 'Blocco interrotto: «' + p + '»' : '';
}
function vtInfo(b, id){
  const d = document.getElementById(id); if (!d) return;
  d.hidden = !d.hidden;
  b.setAttribute('aria-expanded', d.hidden ? 'false' : 'true');
  b.classList.toggle('on', !d.hidden);
}
function vtCarPagina(car){ return Math.round(car.scrollLeft / Math.max(1, car.clientWidth)); }
function vtCarScorri(car){
  const w = car.parentNode, n = car.children.length, i = vtCarPagina(car);
  const c = w && w.querySelector('.vt-car-n'); if (c) c.textContent = (i + 1) + '/' + n;
  const b = w && w.querySelector('.vt-car-piu'); if (b) b.textContent = i >= n - 1 ? 'Torna ai primi' : 'Mostra altri';
}
function vtCarAvanti(b){
  const car = b.closest('.vt-car-w').querySelector('.vt-car'); if (!car) return;
  const n = car.children.length, i = vtCarPagina(car), dopo = i >= n - 1 ? 0 : i + 1;
  try{ car.scrollTo({ left: dopo * car.clientWidth, behavior: 'smooth' }); }catch(_){ car.scrollLeft = dopo * car.clientWidth; }
  /* il contatore si aggiorna subito, senza aspettare la fine dello scorrimento */
  const c = car.parentNode.querySelector('.vt-car-n'); if (c) c.textContent = (dopo + 1) + '/' + n;
  b.textContent = dopo >= n - 1 ? 'Torna ai primi' : 'Mostra altri';
}
/* "blocco interrotto (×2, un blocco interrotto, o il blocco rapido fermato)": la nota tecnica del modello resta fuori */
/* 0.9.373, Andrea: "Segnato su un altro dispositivo, senza dire per cosa". Il motivo vero lo porta il registro dell'altro dispositivo
   (LS_DOC.devices[..].log, livescore.js): si cerca il suo punto piu' vicino nel tempo, dello stesso giocatore */
function vtMotivoVero(e){
  try{
    if (!/segnato su un altro dispositivo/i.test(String(e.m || ''))) return '';
    const dev = (typeof LS_DOC !== 'undefined' && LS_DOC && LS_DOC.devices) || {};
    let best = null, d0 = 6 * 3600000;
    Object.keys(dev).forEach(function(k){ const x = dev[k]; ((x && x.log) || []).forEach(function(l){ if (!l || l.chi !== e.chi || !l.at) return; const d = Math.abs(l.at - e.at); if (d < d0){ d0 = d; best = { m: l.motivo, nome: x.name || '' }; } }); });
    if (best && best.m) return String(best.m).replace(/\s*\(dal [^)]*\)\s*$/i, '') + (best.nome ? ' (dal ' + String(best.nome).toLowerCase() + ')' : '');
  }catch(_){ }
  return e.chi === 'neo' ? 'Un punto per il nuovo te, dal tuo altro dispositivo' : 'Un punto per il vecchio te, dal tuo altro dispositivo';
}
function vtMotivoPulito(m){ return String(m || '').replace(/\s*\(×\d+[^)]*\)\s*$/, '').replace(/^./, function(c){ return c.toUpperCase(); }); }
/** C'e' una partita da mostrare nel periodo? (un periodo senza eventi non apre con un tabellone vuoto) */
function vtC(da, a){ const p = vtSomma(da, a); return p.neo + p.old > 0; }

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.vt{width:100%;display:flex;flex-direction:column;align-items:center;text-align:center;color:var(--navy)}.vt.scuro{color:#fff}',
    '.vt-kick{margin:0 0 18px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}.vt.scuro .vt-kick{color:#8CC6FF}',
    '.vt-tab{display:flex;align-items:center;justify-content:center;gap:12px;width:100%}',
    '.vt-sq{flex:1;max-width:140px;padding:16px 8px;border-radius:20px;background:#F0FBFF;border:2px solid #C8EFFD}.vt.scuro .vt-sq{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)}',
    '.vt-sq small{display:block;font:700 12.5px var(--font-body);color:var(--muted)}.vt.scuro .vt-sq small{color:#C8EFFD}',
    '.vt-sq b{display:block;margin-top:6px;font:900 44px/1 var(--font-display)}',
    '.vt-sq.neo b{color:#0075E3}.vt.scuro .vt-sq.neo b{color:#8CC6FF}.vt-sq.old b{color:#E63946}.vt.scuro .vt-sq.old b{color:#FF8A92}',
    '.vt-sq.su.neo{border-color:#0075E3}.vt-sq.su.old{border-color:#E63946}',
    '.vt-vs{font:800 24px var(--font-display);opacity:.5}',
    '.vt-esito{margin:16px 0 0;font:800 18px/1.3 var(--font-display)}',
    '.vt-serie{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin-top:26px;padding:14px 16px;border-radius:16px;text-align:left}',
    '.vt-serie span{font-size:26px;flex:none}.vt-serie p{margin:0;font:700 14.5px/1.4 var(--font-body)}',
    '.vt-serie.vinte{background:rgba(0,117,227,.1);border:1px solid rgba(0,117,227,.3)}.vt-serie.perse{background:rgba(230,57,70,.1);border:1px solid rgba(230,57,70,.35)}',
    '.vt-ult{width:100%;margin-top:30px}.vt-ult-t{margin:0 0 12px;font:800 15px var(--font-display)}',
    '.vt-pt{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:10px;border-radius:14px;background:rgba(0,30,68,.04);text-align:left}.vt.scuro .vt-pt{background:rgba(255,255,255,.06)}',
    '.vt-pt i{flex:none;min-width:38px;font:900 17px var(--font-display);font-style:normal}.vt-pt.neo i{color:#0075E3}.vt.scuro .vt-pt.neo i{color:#8CC6FF}.vt-pt.old i{color:#E63946}.vt.scuro .vt-pt.old i{color:#FF8A92}',
    '.vt-pt div{flex:1;min-width:0}.vt-pt b{display:block;font:700 14px/1.35 var(--font-body)}.vt-pt small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted)}.vt.scuro .vt-pt small{color:#C8EFFD}',
    /* 0.9.404 BUG-310: il carosello dei punti (tre per slide), il contatore, la (i) e i dettagli */
    '.vt-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch}.vt-car::-webkit-scrollbar{display:none}',
    '.vt-pag{flex:0 0 100%;min-width:100%;scroll-snap-align:start;box-sizing:border-box}',
    '.vt-car-nav{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:6px}',
    '.vt-car-n{font:800 13px var(--font-body);color:var(--muted);padding:6px 12px;border-radius:999px;background:rgba(0,30,68,.06)}.vt.scuro .vt-car-n{color:#C8EFFD;background:rgba(255,255,255,.1)}',
    '.vt-car-piu{border:0;background:none;padding:8px 0;font:800 14px var(--font-body);color:#0075E3;text-decoration:underline;text-underline-offset:3px;cursor:pointer}.vt.scuro .vt-car-piu{color:#8CC6FF}',
    '.vt-pt{align-items:flex-start}.vt-pt i{padding-top:1px}',
    '.vt-info{flex:none;width:28px;height:28px;border-radius:50%;border:1.5px solid rgba(0,30,68,.25);background:transparent;color:var(--navy);font:800 italic 14px/1 Georgia,serif;cursor:pointer;padding:0}',
    '.vt.scuro .vt-info{border-color:rgba(255,255,255,.4);color:#fff}.vt-info.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.vt-dett{margin-top:10px;padding-top:10px;border-top:1px solid rgba(0,30,68,.1)}.vt.scuro .vt-dett{border-top-color:rgba(255,255,255,.14)}',
    '.vt-dett p{margin:0 0 8px}.vt-dett p:last-child{margin-bottom:0}.vt-dett small{margin:0;font:700 11.5px var(--font-body);letter-spacing:.04em;text-transform:uppercase}',
    '.vt-dett span{display:block;font:600 13.5px/1.35 var(--font-body)}',
    '.vt-pt.tolto i{opacity:.75}'
  ].join('');
  document.head.appendChild(st);
})();
