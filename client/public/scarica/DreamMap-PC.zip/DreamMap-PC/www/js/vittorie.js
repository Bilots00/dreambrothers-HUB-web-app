/* ===========================================================================================
   IL PUNTEGGIO PRIMA DI TUTTO (0.9.367)

   Andrea: "nella revisione serale, settimanale, in tutte le revisioni e nel report settimanale, per prima cosa lo score della
   partita fra il vecchio se' e il nuovo se': e' quello che dice se ti stai avvicinando al sogno. Mostragli se sta vincendo o
   perdendo, gli ultimi punti segnati e a cosa sono stati attribuiti. E la serie: sei imbattuto da X giorni contro il vecchio
   te, oppure da X giorni il vecchio te ti sta asfaltando e tu non reagisci".

   Fonte dei numeri: la storia della partita (match.js, mgHist: ogni giorno con i suoi eventi, chi ha segnato, quanti punti, il
   motivo). Niente di inventato: un giorno senza eventi non e' ne' vinto ne' perso e interrompe la serie.
   - vtGiorni(): per giorno { old, neo, ev }.
   - vtSerie(): la serie di giorni chiusi vinti (o persi) di fila, da ieri all'indietro; oggi si aggiunge se e' gia' in vantaggio.
   - vtHtml(titolo, da, a): il tabellone del periodo, la serie, gli ultimi punti. Lo usano la revisione della sera
     (revisione.js), il report della settimana (settimana.js) e le revisioni di settimana/mese/trimestre (revisioni-periodo.js).
   =========================================================================================== */
function vtEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function vtK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function vtEventi(){
  const out = [];
  try{
    const h = (typeof mgHist === 'function') ? mgHist() : [];
    h.forEach(function(g){ (g && g.eventi || []).forEach(function(e){ if (!e || e.stornato) return; out.push({ chi: e.chi === 'old' ? 'old' : 'neo', n: Math.max(1, Math.round(+e.punti || 1)), at: +e.at || 0, m: String(e.motivo || '') }); }); });
  }catch(_){ }
  return out.sort(function(a, b){ return a.at - b.at; });
}
function vtGiorni(){
  const g = {};
  vtEventi().forEach(function(e){ const k = vtK(e.at); g[k] = g[k] || { old: 0, neo: 0, ev: [] }; g[k][e.chi] += e.n; g[k].ev.push(e); });
  return g;
}
/** { tipo: 'vinte'|'perse'|'', n, oggi: { old, neo } } */
function vtSerie(){
  const g = vtGiorni(), oggi = vtK(Date.now());
  let tipo = '', n = 0;
  for (let i = 1; i < 400; i++){
    const k = vtK(Date.now() - i * 86400000), x = g[k];
    if (!x || x.old === x.neo) break;
    const t = x.neo > x.old ? 'vinte' : 'perse';
    if (!tipo) tipo = t; else if (t !== tipo) break;
    n++;
  }
  const o = g[oggi] || { old: 0, neo: 0 };
  /* oggi conta solo se allunga la serie gia' in corso nella stessa direzione */
  if (o.neo > o.old && (tipo === 'vinte' || !tipo)){ tipo = 'vinte'; n++; }
  else if (o.old > o.neo && (tipo === 'perse' || !tipo)){ tipo = 'perse'; n++; }
  return { tipo: tipo, n: n, oggi: o };
}
function vtSomma(da, a){
  const o = { old: 0, neo: 0, ev: [] };
  vtEventi().forEach(function(e){ if (e.at >= da && e.at <= a){ o[e.chi] += e.n; o.ev.push(e); } });
  return o;
}
function vtSerieFrase(s, nome){
  const n = s.n;
  if (!s.tipo || !n) return '';
  /* 0.9.369, Andrea: "dice sei imbattuto da 8 giorni mentre oggi perdo 2 a 6". Se oggi va nell'altro verso, la frase lo dice */
  const o = s.oggi || { old: 0, neo: 0 };
  if (s.tipo === 'vinte' && o.old > o.neo) return 'Fino a ieri eri imbattuto da ' + n + (n === 1 ? ' giorno' : ' giorni') + '. Oggi il vecchio te è avanti. Puoi ancora rimontare.';
  if (s.tipo === 'perse' && o.neo > o.old) return 'Il vecchio te vinceva da ' + n + (n === 1 ? ' giorno' : ' giorni') + '. Oggi sei avanti tu. Tieni duro fino a stasera.';
  if (s.tipo === 'vinte') return n === 1 ? 'Hai vinto l’ultima giornata contro il vecchio te.' : 'Sei imbattuto da ' + n + ' giorni contro il vecchio te.';
  return n === 1 ? 'L’ultima giornata l’ha vinta il vecchio te. Reagisci adesso.' : 'Da ' + n + ' giorni il vecchio te ti sta battendo' + (nome ? ', ' + nome : '') + '. Oggi reagisci.';
}
function vtNome(){ try{ return String((JSON.parse(localStorage.getItem('fl_user') || 'null') || {}).name || '').split(' ')[0]; }catch(_){ return ''; } }
function vtOra(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
/**
 * Il tabellone del periodo [da, a]. titolo: "oggi", "questa settimana"... scuro: testo chiaro (scene scure).
 */
function vtHtml(titolo, da, a, scuro){
  const p = vtSomma(da, a), s = vtSerie(), nome = vtNome();
  const esito = p.neo > p.old ? 'Stai vincendo tu' : (p.old > p.neo ? 'Sta vincendo il vecchio te' : (p.neo ? 'Pareggio' : 'La partita non è ancora cominciata'));
  const ultimi = p.ev.slice(-3).reverse();
  return '<div class="vt' + (scuro ? ' scuro' : '') + '">'
    + '<p class="vt-kick">La partita di ' + vtEsc(titolo) + '</p>'
    + '<div class="vt-tab"><div class="vt-sq neo' + (p.neo > p.old ? ' su' : '') + '"><small>Nuovo te</small><b>' + p.neo + '</b></div><span class="vt-vs">:</span>'
    + '<div class="vt-sq old' + (p.old > p.neo ? ' su' : '') + '"><small>Vecchio te</small><b>' + p.old + '</b></div></div>'
    + '<p class="vt-esito">' + esito + '</p>'
    + (s.tipo ? '<div class="vt-serie ' + s.tipo + '"><span aria-hidden="true">' + (s.tipo === 'vinte' ? '🏆' : '⚠️') + '</span><p>' + vtEsc(vtSerieFrase(s, nome)) + '</p></div>' : '')
    + (ultimi.length ? '<div class="vt-ult"><p class="vt-ult-t">Gli ultimi punti</p>' + ultimi.map(function(e){
        return '<div class="vt-pt ' + e.chi + '"><i>' + (e.chi === 'neo' ? '+' : '−') + e.n + '</i><div><b>' + vtEsc(e.m || (e.chi === 'neo' ? 'Punto per il nuovo te' : 'Punto per il vecchio te')) + '</b><small>' + (e.chi === 'neo' ? 'Nuovo te' : 'Vecchio te') + ' · ' + vtOra(e.at) + '</small></div></div>';
      }).join('') + '</div>' : '')
    + '</div>';
}
/* 0.9.369, Andrea: "il punteggio, stai vincendo, la serie e gli ultimi punti tutti nella stessa schermata: troppo". I pezzi separati, una
   schermata ciascuno: il tabellone con l'esito, poi la serie (la dice il Genio), poi gli ultimi punti */
function vtTabHtml(titolo, da, a, scuro){
  const p = vtSomma(da, a);
  const esito = p.neo > p.old ? 'Stai vincendo tu' : (p.old > p.neo ? 'Sta vincendo il vecchio te' : (p.neo ? 'Pareggio' : 'La partita non è ancora cominciata'));
  return '<div class="vt' + (scuro ? ' scuro' : '') + '"><p class="vt-kick">La partita di ' + vtEsc(titolo) + '</p>'
    /* 0.9.372, Andrea: "nel resto dell'app il vecchio te sta a sinistra e il nuovo te a destra: qui era al contrario, confonde". Sempre lo
       stesso ordine: vecchio te, poi nuovo te. E l'esito ha spazio prima del pulsante */
    + '<div class="vt-tab"><div class="vt-sq old' + (p.old > p.neo ? ' su' : '') + '"><small>Vecchio te</small><b>' + p.old + '</b></div><span class="vt-vs">:</span>'
    + '<div class="vt-sq neo' + (p.neo > p.old ? ' su' : '') + '"><small>Nuovo te</small><b>' + p.neo + '</b></div></div>'
    + '<p class="vt-esito" style="margin-bottom:32px">' + esito + '</p></div>';
}
function vtPuntiHtml(da, a, scuro){
  const ultimi = vtSomma(da, a).ev.slice(-3).reverse();
  if (!ultimi.length) return '';
  return '<div class="vt' + (scuro ? ' scuro' : '') + '"><div class="vt-ult" style="margin-top:0">' + ultimi.map(function(e){
    return '<div class="vt-pt ' + e.chi + '"><i>' + (e.chi === 'neo' ? '+' : '−') + e.n + '</i><div><b>' + vtEsc(vtMotivoPulito(vtMotivoVero(e) || e.m) || (e.chi === 'neo' ? 'Punto per il nuovo te' : 'Punto per il vecchio te')) + '</b><small>' + (e.chi === 'neo' ? 'Nuovo te' : 'Vecchio te') + ' · ' + vtOra(e.at) + '</small></div></div>';
  }).join('') + '</div></div>';
}
/* "blocco interrotto (×2, un blocco interrotto, o il blocco rapido fermato)": la nota tecnica del modello resta fuori */
/* 0.9.373, Andrea: "Segnato su un altro dispositivo, senza dire per cosa". Il motivo vero lo porta il registro dell'altro dispositivo
   (LS_DOC.devices[..].log, livescore.js): si cerca il suo punto piu' vicino nel tempo, dello stesso giocatore */
function vtMotivoVero(e){
  try{
    if (!/segnato su un altro dispositivo/i.test(String(e.m || ''))) return '';
    const dev = (typeof LS_DOC !== 'undefined' && LS_DOC && LS_DOC.devices) || {};
    let best = null, d0 = 6 * 3600000;
    Object.keys(dev).forEach(function(k){ const x = dev[k]; ((x && x.log) || []).forEach(function(l){ if (!l || l.chi !== e.chi || !l.at) return; const d = Math.abs(l.at - e.at); if (d < d0){ d0 = d; best = { m: l.motivo, nome: x.name || '' }; } }); });
    if (best && best.m) return String(best.m).replace(/\s*\(dal [^)]*\)\s*$/i, '') + (best.nome ? ' (dal ' + String(best.nome).toLowerCase() + ')' : '');
  }catch(_){ }
  return e.chi === 'neo' ? 'Un punto per il nuovo te, dal tuo altro dispositivo' : 'Un punto per il vecchio te, dal tuo altro dispositivo';
}
function vtMotivoPulito(m){ return String(m || '').replace(/\s*\(×\d+[^)]*\)\s*$/, '').replace(/^./, function(c){ return c.toUpperCase(); }); }
/** C'e' una partita da mostrare nel periodo? (un periodo senza eventi non apre con un tabellone vuoto) */
function vtC(da, a){ const p = vtSomma(da, a); return p.neo + p.old > 0; }

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.vt{width:100%;display:flex;flex-direction:column;align-items:center;text-align:center;color:var(--navy)}.vt.scuro{color:#fff}',
    '.vt-kick{margin:0 0 18px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}.vt.scuro .vt-kick{color:#8CC6FF}',
    '.vt-tab{display:flex;align-items:center;justify-content:center;gap:12px;width:100%}',
    '.vt-sq{flex:1;max-width:140px;padding:16px 8px;border-radius:20px;background:#F0FBFF;border:2px solid #C8EFFD}.vt.scuro .vt-sq{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.12)}',
    '.vt-sq small{display:block;font:700 12.5px var(--font-body);color:var(--muted)}.vt.scuro .vt-sq small{color:#C8EFFD}',
    '.vt-sq b{display:block;margin-top:6px;font:900 44px/1 var(--font-display)}',
    '.vt-sq.neo b{color:#0075E3}.vt.scuro .vt-sq.neo b{color:#8CC6FF}.vt-sq.old b{color:#E63946}.vt.scuro .vt-sq.old b{color:#FF8A92}',
    '.vt-sq.su.neo{border-color:#0075E3}.vt-sq.su.old{border-color:#E63946}',
    '.vt-vs{font:800 24px var(--font-display);opacity:.5}',
    '.vt-esito{margin:16px 0 0;font:800 18px/1.3 var(--font-display)}',
    '.vt-serie{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin-top:26px;padding:14px 16px;border-radius:16px;text-align:left}',
    '.vt-serie span{font-size:26px;flex:none}.vt-serie p{margin:0;font:700 14.5px/1.4 var(--font-body)}',
    '.vt-serie.vinte{background:rgba(0,117,227,.1);border:1px solid rgba(0,117,227,.3)}.vt-serie.perse{background:rgba(230,57,70,.1);border:1px solid rgba(230,57,70,.35)}',
    '.vt-ult{width:100%;margin-top:30px}.vt-ult-t{margin:0 0 12px;font:800 15px var(--font-display)}',
    '.vt-pt{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:10px;border-radius:14px;background:rgba(0,30,68,.04);text-align:left}.vt.scuro .vt-pt{background:rgba(255,255,255,.06)}',
    '.vt-pt i{flex:none;min-width:38px;font:900 17px var(--font-display);font-style:normal}.vt-pt.neo i{color:#0075E3}.vt.scuro .vt-pt.neo i{color:#8CC6FF}.vt-pt.old i{color:#E63946}.vt.scuro .vt-pt.old i{color:#FF8A92}',
    '.vt-pt div{flex:1;min-width:0}.vt-pt b{display:block;font:700 14px/1.35 var(--font-body)}.vt-pt small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted)}.vt.scuro .vt-pt small{color:#C8EFFD}'
  ].join('');
  document.head.appendChild(st);
})();
