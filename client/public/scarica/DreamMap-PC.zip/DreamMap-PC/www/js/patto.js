/* ===========================================================================================
   IL PATTO CON IL TUO DREAMBROTHER (0.9.285, Andrea)

   "Il contratto di abitudine con il proprio Dreambrother, con un deterrente economico: dare soldi a
   una persona firmando un contratto con lei."

   22/11/2026: I SOLDI NON PASSANO DALL'APP. Stripe vieta i trasferimenti tra privati e muovere soldi
   per conto d'altri richiede una licenza (PSD2). L'app fa da arbitro: decide il giorno, scrive il
   debito, lo dice al garante (qui e su Telegram), prepara il pagamento. Chi si impegna paga con la
   sua app (PayPal, Revolut, Satispay, bonifico) entro 48 ore e lo segna; il garante conferma.
   Se non paga: un punto al vecchio te e la penitenza scelta alla firma (patPenitenza).

   - Si scrive il patto una domanda alla volta (Atomic Habits: cosa, quando, dopo cosa, dove, la
     versione da due minuti), scegliendo come la verifica l'app: cose che il telefono vede da solo.
   - Il garante riceve un codice e firma dalla sua app (il server: dreammapPatti.ts).
   - Ogni giorno questo telefono controlla da solo e manda il verdetto. Un giorno mancato e' un
     debito verso il garante. Un giorno senza verdetto lo segna il server, e dopo due giorni vale
     come mancato.
   - Il garante, aprendo l'app, vede cosa e' successo e quanto gli devi.
   =========================================================================================== */
const PAT = { lista: null, w: null, passo: 0, firma: null, pagamenti: false };
const PAT_INVIATI_K = 'fl_patti_inviati';    // { "<id>|<giorno>": esito } i verdetti gia' mandati
const PAT_VISTI_K = 'fl_patti_visti';        // { "<id>|<giorno>": 1 } quello che il garante ha gia' visto
const PAT_PEN_K = 'fl_patti_penitenze';      // { "<id>|<giorno>": ms } le penitenze gia' applicate su questo telefono
/* 22/11/2026: i testi passano da T() (lingua.js) al momento di mostrarli: la traduzione arriva dopo il caricamento */
const PAT_VERIFICHE = [
  { k: 'sessione', ico: '🚀', n: function(){ return T('Una sessione di Full Focus'); }, s: function(m){ return T('Di almeno {m} minuti, entro l’ora del patto', { m: m }); }, par: 'minuti' },
  { k: 'schermo', ico: '📱', n: function(){ return T('Poco telefono'); }, s: function(m, h){ return T('Al massimo {h} ore di schermo in tutta la giornata', { h: h }); }, par: 'ore' },
  { k: 'passo', ico: '🛤️', n: function(){ return T('Un passo del percorso'); }, s: function(){ return T('Almeno un passo chiuso nella giornata'); } },
  { k: 'riga', ico: '✅', n: function(){ return T('Una riga del foglio'); }, s: function(){ return T('Una riga spuntata entro l’ora del patto, che contiene la parola che scegli'); }, par: 'parola' },
  { k: 'coppia', ico: '👥', n: function(){ return T('Una sessione in coppia'); }, s: function(){ return T('Portata a termine, anche solo in parte'); } },
  /* 0.9.302: il patto dei soldi del contratto di abitudine (contratto.js). Non si sceglie qui: lo crea il contratto. */
  { k: 'contratto', ico: '📜', n: function(){ return T('Il contratto di abitudine'); }, s: function(){ return T('Nessuno sgarro nella giornata'); }, nascosta: true }
];
/** I giorni da lunedi' a domenica nella lingua di chi legge: 'narrow' = L M M G V S D, 'long' = lunedì... */
function patGiorni(forma){
  const l = (typeof ltLingua === 'function') ? ltLingua() : 'it-IT';
  const out = [];
  for (let i = 0; i < 7; i++){
    const d = new Date(2024, 0, 1 + i, 12);   // l'1 gennaio 2024 era un lunedi'
    try{ out.push(d.toLocaleDateString(l, { weekday: forma || 'narrow' })); }catch(_){ out.push(['L', 'M', 'M', 'G', 'V', 'S', 'D'][i]); }
  }
  return out;
}
const PAT_I = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
function patEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function patJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function patScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function patPuo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.accountApi === 'function'; }
async function patApi(method, path, body){
  if (!patPuo()) throw new Error(T('Il patto funziona nell’app sul telefono'));
  return NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
}
/** I soldi come li scrive chi legge (ltEuro in lingua.js); senza lingua.js, all'italiana. */
function patEuro(cent){
  if (typeof ltEuro === 'function') return ltEuro(cent);
  const e = (+cent || 0) / 100; return (e % 1 ? e.toFixed(2).replace('.', ',') : String(e)) + ' €';
}
function patGiornoK(ms){ const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function patData(k){
  const d = new Date(k + 'T12:00:00');
  if (typeof ltData === 'function') return ltData(d.getTime(), { weekday: 'short', day: 'numeric', month: 'short' });
  return d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' });
}
/** Un numero come lo scrive chi legge (2,5 / 2.5). */
function patNum(n){ try{ return Number(n).toLocaleString((typeof ltLingua === 'function') ? ltLingua() : 'it-IT'); }catch(_){ return String(n); } }
/** Un elenco come lo scrive chi legge: "a, b e c" / "a, b and c" (Intl.ListFormat). */
function patElenco(l){
  l = (l || []).filter(Boolean);
  try{ return new Intl.ListFormat((typeof ltLingua === 'function') ? ltLingua() : 'it-IT', { style: 'long', type: 'conjunction' }).format(l); }
  catch(_){ return l.length <= 1 ? (l[0] || '') : l.slice(0, -1).join(', ') + ' e ' + l[l.length - 1]; }
}
function patTitolo(id, testo){ const t = document.getElementById(id); if (t) t.textContent = testo; }

registerScreen('s-patto', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="' + patEsc(T('Indietro')) + '">' + PAT_I + '</button><b class="blk-title" id="patTit">' + T('Il tuo patto') + '</b></div><div id="patBody"></div><div class="spacer"></div>');
registerScreen('s-patto-nuovo', '<div class="topbar"><button class="iconbtn" onclick="patIndietroW()" aria-label="' + patEsc(T('Indietro')) + '">' + PAT_I + '</button><b class="blk-title" id="patWTit">' + T('Un patto nuovo') + '</b></div><div class="md-prog" id="patProg"></div><div id="patW"></div><div class="spacer"></div>', { back: function(){ patIndietroW(); return null; } });
registerScreen('s-patto-firma', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="' + patEsc(T('Indietro')) + '">' + PAT_I + '</button><b class="blk-title" id="patFTit">' + T('Firma come garante') + '</b></div><div id="patF"></div><div class="spacer"></div>');

/* ---------------------------------------------------------------------------------------
   LA PAGINA: i tuoi patti e quelli in cui fai da garante
   --------------------------------------------------------------------------------------- */
async function patApri(){ goId('s-patto'); patPaint(); await patCarica(); patPaint(); }
async function patCarica(){
  try{ const r = await patApi('GET', '/api/focuslock/patti'); PAT.lista = (r && r.patti) || []; PAT.pagamenti = !!(r && r.pagamenti); }
  catch(e){ PAT.lista = { errore: String((e && e.message) || e) }; }
}
function patCardHtml(p){
  const ab = p.abitudine || {};
  const ver = PAT_VERIFICHE.filter(function(v){ return v.k === (ab.verifica && ab.verifica.tipo); })[0];
  const io = p.ruolo === 'autore';
  /* 0.9.302: un patto verso un ente (dal contratto di abitudine): niente garante, i soldi sono da donare */
  if (p.destinazione && p.destinazione.tipo === 'beneficenza') return patCardEnteHtml(p, ver, ultimi7(p));
  const stato = p.stato === 'attesa' ? (io ? T('Aspetta la firma di {chi}', { chi: p.garante || T('chi hai scelto') }) : T('Da firmare')) : p.stato === 'attivo' ? T('Attivo fino al {data}', { data: patData(p.aGiorno) }) : p.stato === 'sciolto' ? T('Sciolto dal garante') : T('Finito');
  const ultimi = (p.giorni || []).slice(0, 7).reverse().map(function(g){ return '<i class="pat-pal ' + g.esito + '" title="' + patEsc(patData(g.giorno)) + '"></i>'; }).join('');
  const soldi = patTotaleTxt(p, io);
  let az = '';
  if (io && p.stato === 'attesa') az = '<button type="button" class="am-cta" onclick="patManda(' + p.id + ')">' + T('Manda il patto a {chi}', { chi: patEsc(p.garante || T('il tuo garante')) }) + '</button>';
  if (!io && p.stato === 'attivo' && p.posta > 0 && !p.ricevi) az += '<button type="button" class="am-cta" onclick="patRiceviApri(' + p.id + ')">' + T('Scrivi come vuoi ricevere i soldi') + '</button>';
  if (!io && p.stato === 'attivo' && p.telegram && p.telegram.acceso && !p.telegram.collegato) az += '<button type="button" class="am-link" onclick="patTelegram(' + p.id + ')">' + T('Avvisami su Telegram') + '</button>';
  if (!io && p.ricevi) az += '<button type="button" class="am-link" onclick="patRiceviApri(' + p.id + ')">' + T('Come ricevi i soldi: {modi}', { modi: patEsc(patRiceviTxt(p.ricevi)) }) + '</button>';
  if (!io && p.stato === 'attivo') az += '<button type="button" class="am-link" onclick="patSciogli(' + p.id + ')">' + T('Sciogli il patto') + '</button>';
  /* 0.9.374, Andrea: "annullare il patto prima ancora che sia firmato: l'utente diventa uno che si rimangia la parola. Meglio Modifica il
     patto: modificare e' diverso da annullare". Il patto sul contratto si modifica cambiando il contratto; gli altri, finche' non sono
     firmati, si riscrivono */
  let modifica = '';
  if (io && p.stato === 'attesa') modifica = (ab.verifica && ab.verifica.tipo === 'contratto')
    ? '<button type="button" class="pat-mod" onclick="if(typeof ctrModifica===\'function\')ctrModifica()">' + T('Modifica il patto') + '</button>'
    : '<button type="button" class="pat-mod" onclick="patSciogli(' + p.id + ')">' + T('Riscrivi il patto') + '</button>';
  /* 0.9.372, Andrea: "non e' il contratto che appariva stampato, e non c'e' piu' il pulsante per stamparlo". Il patto sul contratto di
     abitudine mostra il diploma (lo stesso foglio della stampa, contratto.js) con Stampa il contratto; sotto, stato e pulsanti */
  if (io && ab.verifica && ab.verifica.tipo === 'contratto' && typeof ctrDiplomaHtml === 'function'){
    setTimeout(patDiplomaRiempi, 60);
    /* 0.9.374, Andrea: "Stampa, poi Ancora nessun giorno mancato, poi Manda il patto, Annulla, Scrivi un altro patto: che ordine e'?
       Prima tutte le CTA, poi il resto". Prima le azioni (la principale piena, Stampa a contorno), poi com'e' andata, poi Modifica */
    return '<div class="pat-dip"><p class="pat-stato">' + patEsc(stato) + '</p>' + patDebitiHtml(p, io) + '<div class="ctr-diploma pat-diploma"><div class="ctr-diploma-c">' + T('Preparo il contratto…') + '</div></div>'
      + (az ? '<div class="pat-az">' + az + '</div>' : '')
      + '<button type="button" class="ctr-stampa" onclick="patStampa()">' + (typeof CTR_STAMPA_ICO !== 'undefined' ? CTR_STAMPA_ICO : '') + T('Stampa il contratto') + '</button>'
      + '<div class="pat-stat">' + (ultimi ? '<div class="pat-pals">' + ultimi + '</div>' : '') + '<p class="pat-soldi">' + soldi + '</p></div>'
      + modifica + '</div>';
  }
  /* 0.9.317, Andrea: "fa cagare, e' tutto ammassato. Deve essere un contratto vintage sulla pagina del diario di viaggio, tutto al centro" */
  return '<div class="pat-card pat-carta dv-carta' + (io ? '' : ' garante') + '">'
    + '<small class="pat-eti">' + (io ? T('Il tuo patto') : T('Fai da garante a {chi}', { chi: patEsc(p.autore) })) + '</small>'
    + '<p class="pat-stato">' + patEsc(stato) + '</p>'
    + '<h3 class="pat-cosa">' + patEsc(ab.cosa || '') + '</h3>'
    + '<svg class="pat-onda" viewBox="0 0 160 8" preserveAspectRatio="none" fill="none" stroke="#b23a3a" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 5C22 1 42 7 62 4s40-3 58 0 26 2 38 0"/></svg>'
    + (ver ? '<div class="pat-clausola"><small>' + T('Ogni giorno') + '</small><p>' + ver.ico + ' ' + patEsc(patMaiuscola(patVerTxt(ab))) + '</p></div>' : '')
    + '<div class="pat-clausola"><small>' + T('Se manco un giorno') + '</small><p>' + (p.posta > 0 ? T('<b>{euro}</b> per ogni giorno, al massimo {tetto} al mese, da pagare entro 48 ore', { euro: patEuro(p.posta), tetto: patEuro(p.tetto) }) : T('Niente soldi: basta la parola')) + '</p></div>'
    + (p.posta > 0 ? '<div class="pat-clausola"><small>' + T('Se non pago entro 48 ore') + '</small><p>' + patEsc(patMaiuscola(patNonPagaTxt(p.seNonPaga))) + '</p></div>' : '')
    + (ultimi ? '<div class="pat-clausola"><small>' + T('Gli ultimi giorni') + '</small><div class="pat-pals">' + ultimi + '</div></div>' : '')
    + '<p class="pat-soldi">' + soldi + '</p>'
    + patDebitiHtml(p, io)
    /* 0.9.337, Andrea: "nella firma di chi promette c'e' scritto Tu invece del mio nome" */
    + '<div class="pat-firme"><div>' + patFirmaHtml(io ? patMioNome() : (p.autore || ''), io) + '<small>' + T('firma di chi promette') + '</small></div><div><i>' + (p.stato === 'attesa' ? '&nbsp;' : patEsc(io ? (p.garante || '') : patMioNome())) + '</i><small>' + T('firma del garante') + '</small></div></div>'
    + (az ? '<div class="pat-az">' + az + '</div>' : '') + modifica + '</div>';
}
async function patCtrPronto(){ try{ if (typeof CTR !== 'undefined' && !CTR.s && typeof ctrMotore === 'function') CTR.s = await ctrMotore().contrattoStato(); }catch(_){ } }
async function patDiplomaRiempi(){
  const l = document.querySelectorAll('.pat-diploma'); if (!l.length || typeof ctrStampaCanvas !== 'function') return;
  await patCtrPronto();
  try{ const cv = await ctrStampaCanvas(); const u = cv.toDataURL('image/png'); l.forEach(function(h){ h.innerHTML = '<img src="' + u + '" alt="' + patEsc(T('Il tuo contratto')) + '">'; }); }catch(_){ }
}
async function patStampa(){ await patCtrPronto(); if (typeof ctrStampa === 'function') ctrStampa(); }
function patMioNome(){ try{ return ((typeof nvNome === 'function' && nvNome()) || '').trim() || T('Io'); }catch(_){ return T('Io'); } }
function patFirmaHtml(nome, mia){
  let img = ''; try{ img = mia ? (localStorage.getItem('fl_firma_mia') || '') : ''; }catch(_){ }
  return img ? '<img class="pat-firma-img" src="' + img + '" alt="' + patEsc(nome) + '">' : '<i>' + patEsc(nome) + '</i>';
}
function ultimi7(p){ return (p.giorni || []).slice(0, 7).reverse().map(function(g){ return '<i class="pat-pal ' + g.esito + '" title="' + patEsc(patData(g.giorno)) + '"></i>'; }).join(''); }
function patCardEnteHtml(p, ver, ultimi){
  const ente = (p.destinazione && p.destinazione.ente) || T('l’ente che hai scelto');
  const stato = p.stato === 'attivo' ? T('Attivo fino al {data}', { data: patData(p.aGiorno) }) : p.stato === 'sciolto' ? T('Sciolto') : T('Finito');
  return '<div class="pat-card">'
    + '<small class="pat-eti">' + T('Il tuo patto in beneficenza · {stato}', { stato: patEsc(stato) }) + '</small>'
    + '<b class="pat-cosa">' + patEsc((p.abitudine && p.abitudine.cosa) || '') + '</b>'
    + (ver ? '<p class="pat-ver">' + ver.ico + ' ' + patEsc(patMaiuscola(patVerTxt(p.abitudine || {}))) + '</p>' : '')
    + '<p class="pat-posta">' + T('<b>{euro}</b> per ogni giorno mancato, al massimo {tetto} al mese', { euro: patEuro(p.posta), tetto: patEuro(p.tetto) }) + '</p>'
    + (ultimi ? '<div class="pat-pals">' + ultimi + '<small>' + T('gli ultimi giorni') + '</small></div>' : '')
    + '<p class="pat-soldi">' + (p.totali.dovuti ? T('{euro} da donare a {ente}', { euro: patEuro(p.totali.dovuti), ente: patEsc(ente) }) : T('Ancora nessun giorno mancato')) + '</p>'
    + '<p class="pat-nota">' + T('La donazione la fai tu: ogni giorno mancato resta scritto qui con la sua cifra.') + '</p>'
    + '</div>';
}
/** La verifica detta come una frase sola: "una sessione di Full Focus di almeno 25 minuti, entro le 21:00". */
function patVerTxt(ab){
  const v = ab.verifica || {}, entro = ab.entro || '23:59';
  if (v.tipo === 'sessione') return T('una sessione di Full Focus di almeno {minuti} minuti, entro le {ora}', { minuti: v.minuti || 25, ora: entro });
  if (v.tipo === 'schermo') return T('al massimo {ore} ore di schermo in tutta la giornata', { ore: patNum(v.ore || 3) });
  if (v.tipo === 'passo') return T('almeno un passo del percorso chiuso nella giornata');
  if (v.tipo === 'riga') return T('una riga del foglio con "{parola}" spuntata entro le {ora}', { parola: (v.parole || [])[0] || '', ora: entro });
  if (v.tipo === 'coppia') return T('una sessione in coppia portata a termine nella giornata');
  if (v.tipo === 'contratto') return T('nessuno sgarro al contratto di abitudine nella giornata');
  return '';
}
function patMaiuscola(t){ t = String(t || ''); return t.charAt(0).toUpperCase() + t.slice(1); }
function patMinuscola(t){ t = String(t || ''); return t.charAt(0).toLowerCase() + t.slice(1); }
function patPaint(){
  const host = document.getElementById('patBody'); if (!host) return;
  patTitolo('patTit', T('Il tuo patto'));
  if (!patPuo()){ host.innerHTML = '<p class="pat-intro">' + T('Il patto funziona nell’app sul telefono, con il tuo account Google.') + '</p>'; return; }
  const intro = '<p class="pat-intro">' + T('Scegli un’abitudine e un amico che fa da garante. <b>Se manchi un giorno, l’app glielo dice e gli devi i soldi:</b> lui non deve controllare niente.') + '</p>';
  if (!PAT.lista){ host.innerHTML = intro + '<p class="pat-carica">' + T('Carico i tuoi patti…') + '</p>'; return; }
  if (PAT.lista.errore){ host.innerHTML = intro + '<p class="pat-carica">' + T('Non riesco a leggere i patti: {errore}', { errore: patEsc(PAT.lista.errore) }) + '</p><button type="button" class="am-cta" onclick="patApri()">' + T('Riprova') + '</button>'; return; }
  const miei = PAT.lista.filter(function(p){ return p.ruolo === 'autore'; }), suoi = PAT.lista.filter(function(p){ return p.ruolo === 'garante'; });
  host.innerHTML = intro
    + miei.map(patCardHtml).join('')
    + '<button type="button" class="am-cta pat-nuovo' + (miei.length ? ' sec' : '') + '" onclick="patNuovo()">' + (miei.length ? T('Scrivi un altro patto') : T('Scrivi il tuo patto')) + '</button>'
    + (suoi.length ? '<p class="pat-sez">' + T('Fai da garante') + '</p>' + suoi.map(patCardHtml).join('') : '')
    + '<button type="button" class="pat-firma-riga" onclick="patFirmaApri()"><span>✍️</span><span><b>' + T('Un amico ti ha chiesto di fargli da garante?') + '</b><small>' + T('Scrivi il suo codice e firma il patto') + '</small></span><span class="chev"></span></button>';
}
async function patManda(id){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0]; if (!p) return;
  /* 22/11/2026, Andrea: il pitch per i beta tester. "Vuoi guadagnare dei soldi senza dover fare niente? Tu aiuti me, io aiuto te" */
  const t = T('Mi fai da garante su DreamMap? Il mio patto: {cosa}.', { cosa: (p.abitudine && p.abitudine.cosa) || '' }) + ' '
    + (p.posta > 0 ? T('Ogni giorno che manco ti devo {euro} (al massimo {tetto} al mese). Tu non devi controllare niente: l’app fa da arbitro e ti avvisa quando sgarro. Tu mi aiuti, e se sgarro ci guadagni.', { euro: patEuro(p.posta), tetto: patEuro(p.tetto) })
                 : T('Non ci sono soldi in mezzo: basta la parola, data a te. L’app fa da arbitro e ti avvisa quando sgarro.'))
    + '\n' + T('Scarica DreamMap, vai su "Il patto con il tuo Dreambrother" e firma con il codice: {codice}', { codice: p.codice });
  try{ if (NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: t, title: T('Il mio patto') }); return; } }catch(_){ }
  try{ await navigator.clipboard.writeText(t); toast(T('Messaggio copiato: incollalo al tuo garante')); }catch(_){ toast(T('Il codice del patto è {codice}', { codice: p.codice })); }
}
async function patSciogli(id){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0]; if (!p) return;
  let ok = true;
  const mio = p.ruolo === 'autore';
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(mio ? T('Annullare il patto?') : T('Sciogliere il patto?'), mio ? T('Non è ancora firmato: sparisce e basta.') : T('Da domani i giorni mancati non costano più niente.'), mio ? T('Annulla il patto') : T('Sciogli'), true); }catch(_){ }
  if (!ok) return;
  try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: id }); }catch(_){ toast(T('Non sono riuscito a farlo')); return; }
  await patCarica(); patPaint();
}
function patApriFuori(url){
  try{ if (NATIVE && NATIVE.openUrl){ NATIVE.openUrl({ url: url }); } else window.open(url, '_blank'); }catch(_){ window.open(url, '_blank'); }
}

/* ---------------------------------------------------------------------------------------
   IL DEBITO VERSO IL GARANTE (22/11/2026): l'app scrive, avvisa e prepara il pagamento; i soldi li manda chi si impegna
   --------------------------------------------------------------------------------------- */
function patTotaleTxt(p, io){
  const t = p.totali || {}, g = patEsc(p.garante || T('il tuo garante')), a = patEsc(p.autore);
  if (!(p.posta > 0)){
    if (io) return t.mancati ? (t.mancati === 1 ? T('Hai mancato un giorno: {chi} lo sa', { chi: g }) : T('Hai mancato {n} giorni: {chi} lo sa', { n: t.mancati, chi: g })) : T('Ancora nessun giorno mancato');
    return t.mancati ? (t.mancati === 1 ? T('{chi} ha mancato un giorno', { chi: a }) : T('{chi} ha mancato {n} giorni', { chi: a, n: t.mancati })) : T('{chi} non ha ancora mancato un giorno', { chi: a });
  }
  const da = (t.daPagare || 0) + (t.dichiarati || 0);
  if (io) return da ? T('Devi {euro} a {chi}', { euro: patEuro(da), chi: g }) : (t.inviati ? T('Hai pagato {euro} a {chi}', { euro: patEuro(t.inviati), chi: g }) : T('Ancora nessun giorno mancato'));
  return da ? T('{chi} ti deve {euro}', { chi: a, euro: patEuro(da) }) : (t.inviati ? T('Hai ricevuto {euro} da {chi}', { euro: patEuro(t.inviati), chi: a }) : T('{chi} non ha ancora mancato un giorno', { chi: a }));
}
function patNonPagaTxt(n){
  n = n || {}; const l = [T('un punto al vecchio me')];
  const d = function(h){ return typeof ctrDurata === 'function' ? ctrDurata(h * 60) : T('{n} ore', { n: h }); };
  if (+n.grigioOre) l.push(T('il telefono in bianco e nero per {durata}', { durata: d(+n.grigioOre) }));
  if (+n.severaOre) l.push(T('la modalità severa per {durata}', { durata: d(+n.severaOre) }));
  if (n.serie) l.push(T('la serie che riparte da zero'));
  return patElenco(l);
}
function patRiceviTxt(r){ r = r || {}; return [r.paypal && 'PayPal', r.revolut && 'Revolut', r.satispay && 'Satispay', r.iban && T('bonifico')].filter(Boolean).join(', '); }
function patQuandoMs(ms){
  const d = new Date(ms), l = (typeof ltLingua === 'function') ? ltLingua() : 'it-IT';
  let giorno = '', ora = '';
  try{ giorno = d.toLocaleDateString(l, { weekday: 'long', day: 'numeric', month: 'long' }); }catch(_){ giorno = d.toDateString(); }
  try{ ora = d.toLocaleTimeString(l, { hour: '2-digit', minute: '2-digit' }); }catch(_){ ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  return T('{giorno} alle {ora}', { giorno: giorno, ora: ora });
}
/** Le righe dei debiti aperti (e di quelli appena chiusi), per chi si impegna e per il garante. */
function patDebitiHtml(p, io){
  const l = (p.giorni || []).filter(function(g){ return g.debito && (g.debito !== 'ricevuto' || (Date.now() - (+g.ricevutoAt || 0)) < 3 * 86400000); });
  if (!l.length) return '';
  const chi = patEsc(io ? (p.garante || T('il tuo garante')) : p.autore);
  return '<div class="pat-debiti">' + l.map(function(g){
    const arg = p.id + ',\'' + g.giorno + '\'';
    const v = { chi: chi, euro: patEuro(g.importo), giorno: patData(g.giorno) };
    let t = '', sub = '', az = '', cls = g.debito;
    if (io){
      const paga = '<button type="button" class="am-cta" onclick="patPagaApri(' + arg + ')">' + T('Paga {chi}', v) + '</button><button type="button" class="am-link" onclick="patHoPagato(' + arg + ')">' + T('L’ho già pagato') + '</button>';
      if (g.debito === 'da_pagare'){ t = T('Devi {euro} a {chi}', v); sub = T('Per {giorno}. Entro {scadenza}', { giorno: v.giorno, scadenza: patQuandoMs(g.scadeAt) }); az = paga; }
      else if (g.debito === 'scaduto'){ t = T('Non hai pagato {chi} in tempo', v); sub = T('{euro} per {giorno}. È scattata la penitenza: {penitenza}. Il debito resta: pagalo comunque.', { euro: v.euro, giorno: v.giorno, penitenza: patNonPagaTxt(p.seNonPaga) }); az = paga; }
      else if (g.debito === 'pagato'){ t = T('Hai pagato {euro} a {chi}', v); sub = T('Per {giorno}. Aspetta che {chi} confermi di averli ricevuti.', v); }
      else { t = T('{chi} ha ricevuto {euro}', v); sub = T('Per {giorno}. Hai mantenuto la parola.', v); }
    } else {
      if (g.debito === 'da_pagare' || g.debito === 'scaduto'){ t = T('{chi} ti deve {euro}', v); sub = g.debito === 'scaduto' ? T('Per {giorno}. Il tempo per pagarti è finito: per DreamMap ha mancato la parola.', v) : T('Per {giorno}. Ha tempo fino a {scadenza}.', { giorno: v.giorno, scadenza: patQuandoMs(g.scadeAt) }); az = '<button type="button" class="am-cta" onclick="patChiedi(' + arg + ')">' + T('Chiediglieli') + '</button><button type="button" class="am-link" onclick="patRicevuto(' + arg + ',true)">' + T('Li ho già ricevuti') + '</button>'; }
      else if (g.debito === 'pagato'){ t = T('{chi} dice di averti pagato {euro}', v); sub = T('Per {giorno}. Controlla e conferma.', v); az = '<button type="button" class="am-cta" onclick="patRicevuto(' + arg + ',true)">' + T('Ricevuti') + '</button><button type="button" class="am-link" onclick="patRicevuto(' + arg + ',false)">' + T('Non mi sono arrivati') + '</button>'; }
      else { t = T('Hai ricevuto {euro} da {chi}', v); sub = T('Per {giorno}.', v); }
    }
    return '<div class="pat-deb ' + cls + '"><b>' + t + '</b><small>' + sub + '</small>' + (az ? '<div class="pat-deb-az">' + az + '</div>' : '') + '</div>';
  }).join('') + '</div>';
}
function patTrova(id, giorno){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0] || null;
  return { p: p, g: p ? (p.giorni || []).filter(function(x){ return x.giorno === giorno; })[0] || null : null };
}
async function patCopia(t, msg){
  try{ await navigator.clipboard.writeText(t); toast(msg || T('Copiato')); }catch(_){ toast(t); }
}
function patFoglio(html){
  if (typeof ctrFoglio === 'function'){ ctrFoglio(html); return; }
  const host = document.getElementById('patBody'); if (host) host.insertAdjacentHTML('afterbegin', '<div class="pat-paga">' + html + '</div>');
}
function patFoglioChiudi(){ try{ if (typeof ctrFoglioChiudi === 'function') ctrFoglioChiudi(); }catch(_){ } }
/** Il foglio per pagare: i modi che il garante ha scritto, con la cifra e la causale pronte. I messaggi stanno in PAT.paga:
    dentro un onclick una traduzione con un apostrofo romperebbe il codice. */
function patPagaApri(id, giorno){
  const x = patTrova(id, giorno); if (!x.p || !x.g) return;
  const r = x.p.ricevi || {}, chi = patEsc(x.p.garante || T('il tuo garante')), euro = patEuro(x.g.importo);
  const causale = T('Patto DreamMap {giorno}', { giorno: patData(giorno) });
  PAT.paga = { id: id, giorno: giorno, causale: causale, r: r, euro: euro,
    mRevolut: T('Scrivi {euro} su Revolut', { euro: euro }), mSatispay: T('Numero copiato: mandagli {euro} su Satispay', { euro: euro }),
    mIban: T('IBAN copiato'), mCausale: T('Causale copiata') };
  let h = '<h3 class="pat-paga-t">' + T('Paga {euro} a {chi}', { euro: euro, chi: chi }) + '</h3><p class="pat-paga-s">' + T('Con l’app che usi già. DreamMap non tocca i tuoi soldi: prepara solo il pagamento.') + '</p><div class="pat-paga-l">';
  if (x.g.paypal) h += '<button type="button" class="am-cta" onclick="patApriFuori(\'' + x.g.paypal + '\')">' + T('PayPal: {euro} già scritti', { euro: euro }) + '</button>';
  if (r.revolut) h += '<button type="button" class="am-cta sec" onclick="patCopia(PAT.paga.euro,PAT.paga.mRevolut);patApriFuori(\'https://revolut.me/' + encodeURIComponent(r.revolut) + '\')">' + T('Revolut: {nome}', { nome: patEsc(r.revolut) }) + '</button>';
  if (r.satispay) h += '<button type="button" class="am-cta sec" onclick="patCopia(PAT.paga.r.satispay,PAT.paga.mSatispay)">' + T('Satispay: copia il numero {numero}', { numero: patEsc(r.satispay) }) + '</button>';
  if (r.iban) h += '<button type="button" class="am-cta sec" onclick="patCopia(PAT.paga.r.iban,PAT.paga.mIban)">' + T('Bonifico: copia l’IBAN') + '</button><p class="pat-paga-s">' + patEsc(r.intestatario || x.p.garante || '') + ' · ' + patEsc(r.iban) + '<br>' + T('Causale: {causale}', { causale: patEsc(causale) }) + ' <button type="button" class="am-link" onclick="patCopia(PAT.paga.causale,PAT.paga.mCausale)">' + T('Copia') + '</button></p>';
  if (!x.g.paypal && !r.revolut && !r.satispay && !r.iban) h += '<p class="pat-paga-s">' + T('{chi} non ha ancora scritto come vuole ricevere i soldi: chiediglielo, e pagalo come fate di solito.', { chi: chi }) + '</p>';
  h += '</div><button type="button" class="am-cta" onclick="patFoglioChiudi();patHoPagato(' + id + ',\'' + giorno + '\')">' + T('Ho pagato {chi}', { chi: chi }) + '</button>';
  patFoglio(h);
}
async function patHoPagato(id, giorno){
  const x = patTrova(id, giorno); if (!x.p) return;
  const chi = x.p.garante || T('il tuo garante');
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Hai pagato {chi}?', { chi: chi }), T('Glielo diciamo: lui conferma quando gli arrivano. Se non gli arrivano, il debito torna aperto.'), T('Sì, ho pagato')); }catch(_){ }
  if (!ok) return;
  try{ const r = await patApi('POST', '/api/focuslock/patti/pagato', { id: id, giorno: giorno }); patAggiorna(r && r.patto); toast(T('Fatto: {chi} lo sa', { chi: chi })); }
  catch(_){ toast(T('Non sono riuscito a segnarlo: riprova')); }
}
async function patRicevuto(id, giorno, arrivati){
  try{ const r = await patApi('POST', '/api/focuslock/patti/ricevuto', { id: id, giorno: giorno, arrivati: !!arrivati }); patAggiorna(r && r.patto); toast(arrivati ? T('Segnato: li hai ricevuti') : T('Segnato: il debito è di nuovo aperto')); }
  catch(_){ toast(T('Non sono riuscito a segnarlo: riprova')); }
}
/** Il garante chiede i soldi: un messaggio pronto da mandare all'amico, con il link per pagare. È una cosa tra loro. */
async function patChiedi(id, giorno){
  const x = patTrova(id, giorno); if (!x.p || !x.g) return;
  const t = T('Ehi {chi}, hai mancato il patto {giorno}: mi devi {euro}.', { chi: x.p.autore || '', giorno: patData(giorno), euro: patEuro(x.g.importo) })
    + (x.g.paypal ? ' ' + T('Puoi pagarmi qui: {link}', { link: x.g.paypal }) : '') + ' ' + T('Poi segnalo su DreamMap.');
  try{ if (NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: t, title: T('Il patto') }); return; } }catch(_){ }
  patCopia(t, T('Messaggio copiato: mandalo a {chi}', { chi: x.p.autore || T('lui') }));
}
function patAggiorna(patto){
  if (patto && Array.isArray(PAT.lista)) PAT.lista = PAT.lista.map(function(p){ return p.id === patto.id ? patto : p; });
  if (document.getElementById('patBody')) patPaint();
  try{ if (typeof ctrPattoCarica === 'function' && document.getElementById('ctrBody')) ctrPattoCarica(); }catch(_){ }
}

/* COME VUOLE RICEVERE I SOLDI IL GARANTE: almeno un modo, se il patto ha dei soldi */
function patRiceviForm(r){
  r = r || {};
  return '<label class="pat-l" for="patRPaypal">' + T('PayPal (il nome del tuo PayPal.me)') + '</label><input id="patRPaypal" class="fin" maxlength="60" placeholder="' + patEsc(T('Per esempio: {nome}', { nome: 'marcorossi' })) + '" value="' + patEsc(r.paypal || '') + '">'
    + '<label class="pat-l" for="patRRevolut">' + T('Revolut (il tuo @nome)') + '</label><input id="patRRevolut" class="fin" maxlength="60" placeholder="' + patEsc(T('Per esempio: {nome}', { nome: 'marcor' })) + '" value="' + patEsc(r.revolut || '') + '">'
    + '<label class="pat-l" for="patRSatispay">' + T('Satispay (il tuo numero)') + '</label><input id="patRSatispay" class="fin" inputmode="tel" maxlength="20" placeholder="+39 333 123 4567" value="' + patEsc(r.satispay || '') + '">'
    + '<label class="pat-l" for="patRIban">' + T('IBAN per il bonifico') + '</label><input id="patRIban" class="fin" maxlength="42" placeholder="IT60 X054 2811 1010 0000 0123 456" value="' + patEsc(r.iban || '') + '">'
    + '<input id="patRNome" class="fin" maxlength="70" placeholder="' + patEsc(T('Intestato a')) + '" value="' + patEsc(r.intestatario || '') + '">'
    + '<p class="pat-paga-s">' + T('Lo vede solo chi ti deve i soldi. Basta uno.') + '</p>';
}
function patRiceviLeggi(){
  const v = function(i){ const e = document.getElementById(i); return e ? e.value.trim() : ''; };
  return { paypal: v('patRPaypal'), revolut: v('patRRevolut'), satispay: v('patRSatispay'), iban: v('patRIban'), intestatario: v('patRNome') };
}
function patRiceviApri(id){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0]; if (!p) return;
  patFoglio('<h3 class="pat-paga-t">' + T('Come vuoi ricevere i soldi?') + '</h3>' + patRiceviForm(p.ricevi) + '<button type="button" class="am-cta fl-salva" onclick="patRiceviSalva(' + id + ')">' + T('Salva') + '</button>');
}
async function patRiceviSalva(id){
  try{ const r = await patApi('POST', '/api/focuslock/patti/ricevi', { id: id, ricevi: patRiceviLeggi() }); patFoglioChiudi(); patAggiorna(r && r.patto); toast(T('Salvato')); }
  catch(e){ toast(/almeno un modo/.test(String(e && e.message)) ? T('Scrivi almeno un modo valido: PayPal, Revolut, Satispay o IBAN') : T('Non sono riuscito a salvarlo: riprova')); }
}
async function patTelegram(id){
  try{ const r = await patApi('POST', '/api/focuslock/patti/telegram', { id: id }); if (r && r.url) patApriFuori(r.url); }
  catch(_){ toast(T('Gli avvisi su Telegram non sono ancora disponibili')); }
}

/* LA PENITENZA se non si paga il garante entro 48 ore (22/11/2026, Andrea: "se l'utente non mantiene la parola data non sta cambiando:
   un punto al vecchio se', con il motivo, e poi la penitenza che ha scelto lui alla firma"). Il server dice che il debito e' scaduto;
   questo telefono la applica una volta sola (PAT_PEN_K) e lo dice al server. */
async function patPenitenza(p, g){
  const n = p.seNonPaga || {}, chi = p.garante || T('il tuo garante'), fatto = [T('un punto al vecchio te')];
  try{ if (typeof mgOldPoint === 'function') mgOldPoint(T('Non hai pagato {chi} come avevi promesso nel contratto: non hai mantenuto la parola data', { chi: chi })); }catch(_){ }
  if (+n.grigioOre){
    try{ const m = (typeof ctrMotore === 'function') ? ctrMotore() : null; if (m && typeof m.contrattoGrigio === 'function'){ await m.contrattoGrigio({ ore: +n.grigioOre }); fatto.push(T('bianco e nero per {durata}', { durata: patNonPagaOre(+n.grigioOre) })); } }catch(_){ }
  }
  if (+n.severaOre && typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.setStrictConfig === 'function'){
    try{
      const st = typeof NATIVE.getStrictState === 'function' ? await NATIVE.getStrictState() : null;
      if (!(st && (st.level || 0) >= 1)){
        await NATIVE.setStrictConfig({ level: 1, unlockMethod: 'timer', strictUntil: Date.now() + (+n.severaOre) * 3600000, uninstallGuard: false, settingsGuard: false, recentsGuard: false, splitScreenGuard: false });
        fatto.push(T('modalità severa per {durata}', { durata: patNonPagaOre(+n.severaOre) }));
      }
    }catch(_){ }
  }
  if (n.serie && typeof mtRoll === 'function' && typeof mtWrite === 'function' && typeof MT_KEY !== 'undefined'){
    try{ const s = mtRoll(); if (s.streak){ s.streak = 0; mtWrite(MT_KEY, s); if (typeof mtPaint === 'function') mtPaint(); } fatto.push(T('la serie riparte da zero')); }catch(_){ }
  }
  toast(T('Non hai pagato {chi} entro 48 ore: {penitenza}', { chi: chi, penitenza: fatto.join(', ') }));
}
function patNonPagaOre(h){ return typeof ctrDurata === 'function' ? ctrDurata(h * 60) : T('{n} ore', { n: h }); }
async function patPenitenzeControlla(lista){
  const fatte = patJ(PAT_PEN_K, {}) || {};
  for (const p of lista){
    if (p.ruolo !== 'autore') continue;
    for (const g of (p.giorni || [])){
      if (g.debito !== 'scaduto' || g.penitenzaAt) continue;
      const k = p.id + '|' + g.giorno;
      if (!fatte[k]){ fatte[k] = Date.now(); patScrivi(PAT_PEN_K, fatte); await patPenitenza(p, g); }
      try{ await patApi('POST', '/api/focuslock/patti/penitenza', { id: p.id, giorno: g.giorno }); }catch(_){ }
    }
  }
}

/* ---------------------------------------------------------------------------------------
   IL PATTO NUOVO: una domanda per schermata
   --------------------------------------------------------------------------------------- */
const PAT_PASSI = ['cosa', 'verifica', 'quando', 'facile', 'garante', 'posta', 'firma'];
function patNuovo(){
  /* 0.9.337, Andrea: "il contratto di abitudine e il patto con il Dreambrother devono essere la stessa cosa" */
  if (typeof ctrNuovo === 'function'){ ctrNuovo(); return; }
  PAT.w = { cosa: '', verifica: { tipo: 'sessione', minuti: 25, ore: 3, parole: [] }, giorni: [true, true, true, true, true, false, false], entro: '21:00', dopoDi: '', dove: '', dueMinuti: '', garante: '', posta: 5, tetto: 50, durata: 30 };
  PAT.passo = 0;
  goId('s-patto-nuovo'); patWPaint();
}
function patIndietroW(){ if (PAT.passo > 0){ PAT.passo--; patWPaint(); return; } if (typeof navTornaDietro === 'function' && navTornaDietro('s-patto-nuovo')) return; goId('s-patto'); }
function patAvanti(){ patLeggiCampi(); const err = patControlla(); if (err){ toast(err); return; } PAT.passo = Math.min(PAT_PASSI.length - 1, PAT.passo + 1); patWPaint(); }
function patLeggiCampi(){
  const w = PAT.w; const v = function(id){ const e = document.getElementById(id); return e ? e.value.trim() : null; };
  if (v('patCosa') !== null) w.cosa = v('patCosa');
  if (v('patParola') !== null) w.verifica.parole = v('patParola') ? [v('patParola').toLowerCase()] : [];
  if (v('patDopo') !== null) w.dopoDi = v('patDopo');
  if (v('patDove') !== null) w.dove = v('patDove');
  if (v('patDue') !== null) w.dueMinuti = v('patDue');
  if (v('patGarante') !== null) w.garante = v('patGarante');
}
function patControlla(){
  const w = PAT.w, p = PAT_PASSI[PAT.passo];
  if (p === 'cosa' && !w.cosa) return T('Scrivi l’abitudine che vuoi costruire');
  if (p === 'verifica' && w.verifica.tipo === 'riga' && !(w.verifica.parole || []).length) return T('Scrivi la parola che deve avere la riga');
  if (p === 'quando' && !w.giorni.some(Boolean)) return T('Scegli almeno un giorno');
  if (p === 'garante' && !w.garante) return T('Scrivi il nome del tuo garante');
  return '';
}
function patWPaint(){
  const host = document.getElementById('patW'); if (!host || !PAT.w) return;
  const w = PAT.w, p = PAT_PASSI[PAT.passo];
  const prog = document.getElementById('patProg'); if (prog) prog.innerHTML = '<i style="width:' + Math.round((PAT.passo + 1) / PAT_PASSI.length * 100) + '%"></i>';
  const avanti = '<button type="button" class="am-cta" onclick="patAvanti()">' + T('Avanti') + '</button>';
  const meno = patEsc(T('Meno')), piu = patEsc(T('Più'));
  let h = '';
  if (p === 'cosa'){
    const esempi = [T('Lavorare al mio progetto ogni mattina'), T('Stare lontano dal telefono la sera'), T('Chiudere un passo del percorso al giorno'), T('Fare una sessione in coppia al giorno')];
    h = '<h2 class="pat-q">' + T('Quale abitudine vuoi costruire?') + '</h2><p class="pat-qs">' + T('Una cosa sola, detta come la diresti a un amico.') + '</p>'
      + '<input id="patCosa" class="fin" maxlength="160" placeholder="' + patEsc(T('Per esempio: lavorare al negozio online ogni mattina')) + '" value="' + patEsc(w.cosa) + '">'
      + '<div class="pat-esempi">' + esempi.map(function(e){ return '<button type="button" onclick="document.getElementById(\'patCosa\').value=this.textContent">' + patEsc(e) + '</button>'; }).join('') + '</div>' + avanti;
  } else if (p === 'verifica'){
    h = '<h2 class="pat-q">' + T('Come la controlla l’app, ogni giorno?') + '</h2><p class="pat-qs">' + T('Scegli una cosa che il telefono vede da solo: così il tuo garante non deve controllare niente.') + '</p>'
      + '<div class="pat-ver-l">' + PAT_VERIFICHE.filter(function(v){ return !v.nascosta; }).map(function(v){ return '<button type="button" class="' + (v.k === w.verifica.tipo ? 'on' : '') + '" onclick="patLeggiCampi();PAT.w.verifica.tipo=\'' + v.k + '\';patWPaint()"><span>' + v.ico + '</span><span><b>' + patEsc(v.n()) + '</b><small>' + patEsc(v.s(String(w.verifica.minuti), patNum(w.verifica.ore))) + '</small></span></button>'; }).join('') + '</div>';
    if (w.verifica.tipo === 'sessione') h += '<div class="md-row"><span>' + T('Minuti della sessione') + '</span><div class="md-step"><button type="button" onclick="PAT.w.verifica.minuti=Math.max(10,PAT.w.verifica.minuti-5);patWPaint()" aria-label="' + meno + '">−</button><b>' + w.verifica.minuti + '</b><button type="button" onclick="PAT.w.verifica.minuti=Math.min(180,PAT.w.verifica.minuti+5);patWPaint()" aria-label="' + piu + '">+</button></div></div>';
    if (w.verifica.tipo === 'schermo') h += '<div class="md-row"><span>' + T('Ore di schermo al massimo') + '</span><div class="md-step"><button type="button" onclick="PAT.w.verifica.ore=Math.max(0.5,PAT.w.verifica.ore-0.5);patWPaint()" aria-label="' + meno + '">−</button><b>' + patNum(w.verifica.ore) + '</b><button type="button" onclick="PAT.w.verifica.ore=Math.min(12,PAT.w.verifica.ore+0.5);patWPaint()" aria-label="' + piu + '">+</button></div></div>';
    if (w.verifica.tipo === 'riga') h += '<input id="patParola" class="fin" maxlength="40" placeholder="' + patEsc(T('La parola della riga, per esempio: video')) + '" value="' + patEsc((w.verifica.parole || [])[0] || '') + '">';
    h += avanti;
  } else if (p === 'quando'){
    const lettere = patGiorni('narrow');
    h = '<h2 class="pat-q">' + T('In quali giorni, ed entro che ora?') + '</h2><p class="pat-qs">' + (w.verifica.tipo === 'schermo' ? T('Il tempo sul telefono si conta a fine giornata.') : T('Dopo quell’ora, se non l’hai fatto, il giorno è mancato.')) + '</p>'
      + '<div class="pat-gg">' + lettere.map(function(g, i){ return '<button type="button" class="' + (w.giorni[i] ? 'on' : '') + '" onclick="PAT.w.giorni[' + i + ']=!PAT.w.giorni[' + i + '];patWPaint()">' + patEsc(g) + '</button>'; }).join('') + '</div>'
      + (w.verifica.tipo === 'schermo' || w.verifica.tipo === 'passo' || w.verifica.tipo === 'coppia' ? '' : '<div class="md-row"><span>' + T('Entro le') + '</span><div class="md-step"><button type="button" onclick="PAT.w.entro=patOraPiu(PAT.w.entro,-30);patWPaint()" aria-label="' + patEsc(T('Prima')) + '">−</button><b>' + w.entro + '</b><button type="button" onclick="PAT.w.entro=patOraPiu(PAT.w.entro,30);patWPaint()" aria-label="' + patEsc(T('Dopo')) + '">+</button></div></div>')
      + avanti;
  } else if (p === 'facile'){
    h = '<h2 class="pat-q">' + T('Rendila facile da cominciare') + '</h2><p class="pat-qs">' + T('Le abitudini si attaccano a quelle che hai già. Puoi lasciare vuoto.') + '</p>'
      + '<label class="pat-l" for="patDopo">' + T('Dopo cosa la fai?') + '</label><input id="patDopo" class="fin" maxlength="120" placeholder="' + patEsc(T('Per esempio: dopo il caffè del mattino')) + '" value="' + patEsc(w.dopoDi) + '">'
      + '<label class="pat-l" for="patDove">' + T('Dove?') + '</label><input id="patDove" class="fin" maxlength="80" placeholder="' + patEsc(T('Per esempio: alla scrivania in camera')) + '" value="' + patEsc(w.dove) + '">'
      + '<label class="pat-l" for="patDue">' + T('La versione da due minuti') + '</label><input id="patDue" class="fin" maxlength="120" placeholder="' + patEsc(T('Per esempio: aprire il computer e scrivere una riga')) + '" value="' + patEsc(w.dueMinuti) + '">' + avanti;
  } else if (p === 'garante'){
    h = '<h2 class="pat-q">' + T('Chi è il tuo Dreambrother?') + '</h2><p class="pat-qs">' + T('L’amico che fa da garante: firma il patto dalla sua app e gli dai i soldi dei giorni che manchi.') + '</p>'
      + '<input id="patGarante" class="fin" maxlength="60" placeholder="' + patEsc(T('Il suo nome')) + '" value="' + patEsc(w.garante) + '">' + avanti;
  } else if (p === 'posta'){
    h = '<h2 class="pat-q">' + T('Quanto ti costa un giorno mancato?') + '</h2><p class="pat-qs">' + T('Abbastanza da non volerlo perdere, non tanto da metterti in difficoltà.') + '</p>'
      + '<div class="pat-poste">' + [2, 5, 10, 20, 50].map(function(e){ return '<button type="button" class="' + (w.posta === e ? 'on' : '') + '" onclick="PAT.w.posta=' + e + ';PAT.w.tetto=Math.max(PAT.w.tetto,' + e + ');patWPaint()">' + patEuro(e * 100) + '</button>'; }).join('') + '</div>'
      + '<div class="md-row"><span>' + T('Al massimo al mese') + '</span><div class="md-step"><button type="button" onclick="PAT.w.tetto=Math.max(PAT.w.posta,PAT.w.tetto-10);patWPaint()" aria-label="' + meno + '">−</button><b>' + patEuro(w.tetto * 100) + '</b><button type="button" onclick="PAT.w.tetto=Math.min(500,PAT.w.tetto+10);patWPaint()" aria-label="' + piu + '">+</button></div></div>'
      + '<div class="md-row"><span>' + T('Quanto dura il patto') + '</span><div class="md-step"><button type="button" onclick="PAT.w.durata=Math.max(7,PAT.w.durata-7);patWPaint()" aria-label="' + meno + '">−</button><b>' + T('{n} giorni', { n: w.durata }) + '</b><button type="button" onclick="PAT.w.durata=Math.min(180,PAT.w.durata+7);patWPaint()" aria-label="' + piu + '">+</button></div></div>' + avanti;
  } else {
    const ab = { cosa: w.cosa, verifica: w.verifica, entro: w.entro };
    const nomi = patGiorni('long');
    const gg = w.giorni.filter(Boolean).length === 7 ? T('tutti i giorni') : patElenco(nomi.filter(function(_, i){ return w.giorni[i]; }));
    const quando = [gg, w.dopoDi ? patMinuscola(w.dopoDi) : '', w.dove ? patMinuscola(w.dove) : ''].filter(Boolean).join(', ');
    h = '<h2 class="pat-q">' + T('Il tuo patto') + '</h2>'
      + '<div class="pat-contratto"><p>' + T('Io mi impegno a <b>{cosa}</b>, {quando}.', { cosa: patEsc(patMinuscola(w.cosa)), quando: patEsc(quando) }) + '</p>'
      + '<p>' + T('L’app lo controlla da sola: {verifica}.', { verifica: patEsc(patVerTxt(ab)) }) + '</p>'
      + '<p>' + T('Per ogni giorno che manco, <b>do a {chi} {euro}</b> entro 48 ore, al massimo {tetto} al mese, per {giorni} giorni a partire da domani.', { chi: patEsc(w.garante), euro: patEuro(w.posta * 100), tetto: patEuro(w.tetto * 100), giorni: w.durata }) + '</p>'
      + (w.dueMinuti ? '<p>' + T('Quando non ho voglia, comincio così: {come}.', { come: patEsc(w.dueMinuti) }) + '</p>' : '') + '</div>'
      + '<button type="button" class="am-cta" onclick="patFirmaMio()">' + T('Firmo il patto') + '</button>';
  }
  host.innerHTML = '<div class="pat-w">' + h + '</div>';
  patTitolo('patWTit', T('Un patto nuovo · {n} di {tot}', { n: PAT.passo + 1, tot: PAT_PASSI.length }));
}
function patOraPiu(hhmm, min){ const p = String(hhmm).split(':'); let t = (+p[0]) * 60 + (+p[1]) + min; t = Math.max(6 * 60, Math.min(23 * 60 + 30, t)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
async function patFirmaMio(){
  const w = PAT.w; if (!w) return;
  const entro = (w.verifica.tipo === 'schermo' || w.verifica.tipo === 'passo' || w.verifica.tipo === 'coppia') ? '23:59' : w.entro;
  let r;
  try{
    r = await patApi('POST', '/api/focuslock/patti', { abitudine: { cosa: w.cosa, verifica: w.verifica, giorni: w.giorni, entro: entro, dopoDi: w.dopoDi, dove: w.dove, dueMinuti: w.dueMinuti }, posta: w.posta, tetto: w.tetto, durataGiorni: w.durata, garanteNome: w.garante, nome: (typeof nvNome === 'function' && nvNome()) || '' });
  }catch(e){ toast(T('Non sono riuscito a salvare il patto: {errore}', { errore: String((e && e.message) || e) })); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  PAT.w = null; PAT.passo = 0;
  goId('s-patto'); await patCarica(); patPaint();
  if (r && r.patto){ toast(T('Patto firmato da te: adesso mandalo a {chi}', { chi: r.patto.garante || T('il tuo garante') })); setTimeout(function(){ patManda(r.patto.id); }, 600); }
}

/* ---------------------------------------------------------------------------------------
   IL GARANTE FIRMA
   --------------------------------------------------------------------------------------- */
function patFirmaApri(){ PAT.firma = null; goId('s-patto-firma'); patFirmaPaint(); }
function patFirmaPaint(){
  const host = document.getElementById('patF'); if (!host) return;
  patTitolo('patFTit', T('Firma come garante'));
  const f = PAT.firma;
  if (!f){
    host.innerHTML = '<p class="pat-intro">' + T('Scrivi il codice che ti ha mandato il tuo amico: <b>leggi il suo patto prima di firmare.</b>') + '</p>'
      + '<input id="patCod" class="fin pat-cod" maxlength="12" placeholder="' + patEsc(T('Il codice')) + '" autocomplete="off" autocapitalize="characters">'
      + '<button type="button" class="am-cta" onclick="patLeggiCodice()">' + T('Leggi il patto') + '</button>';
    return;
  }
  host.innerHTML = patCardHtml(f) + '<p class="pat-intro">'
    + (f.posta > 0
      ? T('Firmando fai da garante: <b>non devi controllare niente.</b> Se {chi} manca un giorno, l’app te lo dice e ti deve {euro}: te li manda lui, direttamente, entro 48 ore.', { chi: patEsc(f.autore), euro: patEuro(f.posta) }) + '</p><h3 class="pat-sez">' + T('Come vuoi ricevere i soldi?') + '</h3>' + patRiceviForm(null)
      : T('Firmando fai da garante: <b>non devi controllare niente.</b> Se {chi} manca un giorno, l’app te lo dice.', { chi: patEsc(f.autore) }) + '</p>')
    + '<button type="button" class="am-cta" onclick="patFirmaGarante(\'' + patEsc(f.codice) + '\')">' + T('Firmo come garante') + '</button>';
}
async function patLeggiCodice(){
  const c = ((document.getElementById('patCod') || {}).value || '').trim().toUpperCase();
  if (!c){ toast(T('Scrivi il codice del patto')); return; }
  try{ const r = await patApi('GET', '/api/focuslock/patti/codice/' + encodeURIComponent(c)); PAT.firma = r && r.patto; patFirmaPaint(); }
  catch(e){ toast(/tuo patto/.test(String(e && e.message)) ? T('Questo è il tuo patto: il garante deve essere un’altra persona') : T('Non trovo un patto con questo codice')); }
}
async function patFirmaGarante(codice){
  const ricevi = (PAT.firma && PAT.firma.posta > 0) ? patRiceviLeggi() : null;
  try{ await patApi('POST', '/api/focuslock/patti/firma', { codice: codice, nome: (typeof nvNome === 'function' && nvNome()) || '', ricevi: ricevi }); }
  catch(e){ toast(/almeno un modo/.test(String(e && e.message)) ? T('Scrivi almeno un modo per ricevere i soldi: PayPal, Revolut, Satispay o IBAN') : T('Non sono riuscito a firmare: riprova')); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  toast(T('Hai firmato: da domani il patto è attivo'));
  goId('s-patto'); await patCarica(); patPaint();
}

/* ---------------------------------------------------------------------------------------
   IL CONTROLLO DI OGNI GIORNO, da solo: il verdetto parte dal telefono di chi si impegna
   --------------------------------------------------------------------------------------- */
function patScadenzaMs(giorno, entro){ const p = String(entro || '23:59').split(':'); const d = new Date(giorno + 'T00:00:00'); d.setHours(+p[0] || 23, +p[1] || 0, 59, 0); return d.getTime(); }
function patPrevisti(p, fino){
  const ab = p.abitudine || {}; const out = [];
  const d = new Date(p.daGiorno + 'T12:00:00');
  for (let i = 0; i < 200; i++){ const k = patGiornoK(d.getTime()); if (k > fino || k > p.aGiorno) break; if (ab.giorni && ab.giorni[(d.getDay() + 6) % 7]) out.push(k); d.setDate(d.getDate() + 1); }
  return out;
}
/** Il verdetto di un giorno: true fatto, false mancato, null non si sa ancora. */
async function patVerdetto(ab, giorno){
  const v = ab.verifica || {};
  const inizio = new Date(giorno + 'T00:00:00').getTime(), fine = inizio + 86400000;
  const scad = patScadenzaMs(giorno, ab.entro);
  const passata = Date.now() > scad;
  if (v.tipo === 'sessione'){
    const h = patJ('fl_ff_hist', []) || [];
    /* 0.9.389 (BUG-115), Andrea: "il punto per essere assegnato deve essere dentro la pagina di Full Focus": una sessione andata avanti da sola non conta (ffPuntoValido) */
    const ok = h.some(function(x){ const t = +(x.start || x.at || 0); const min = Math.round((x.spentMs || (x.min || 0) * 60000) / 60000); return (typeof ffPuntoValido === 'function' ? ffPuntoValido(x) : (x && x.ok)) && !x.meditazione && t >= inizio && t <= scad && min >= (v.minuti || 25); });
    return ok ? true : (passata ? false : null);
  }
  if (v.tipo === 'passo'){
    const oz = patJ('fl_orizzonti', {}) || {};
    const ok = Object.keys(oz).some(function(k){ return ((oz[k] && oz[k].passi) || []).some(function(x){ return x && x.fatto && x.il === giorno; }); });
    return ok ? true : (Date.now() > fine ? false : null);
  }
  if (v.tipo === 'riga'){
    const l = patJ('fl_notes_done', []) || [];
    const par = (v.parole || [])[0] || '';
    const ok = l.some(function(x){ return x && x.day === giorno && (!par || String(x.text || '').toLowerCase().indexOf(par) >= 0) && (!x.at || +x.at <= scad); });
    return ok ? true : (passata ? false : null);
  }
  if (v.tipo === 'coppia'){
    const l = patJ('fl_coppia_storia', []) || [];
    const ok = l.some(function(x){ return x && x.esito !== 'no' && +x.slotAt >= inizio && +x.slotAt < fine; });
    return ok ? true : (Date.now() > fine ? false : null);
  }
  if (v.tipo === 'contratto') return (typeof ctrVerdetto === 'function') ? ctrVerdetto(giorno) : null;
  if (v.tipo === 'schermo'){
    if (Date.now() < fine) return null;
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return null;
    try{ const r = await NATIVE.getScreenTimeRange({ from: inizio, to: fine, bucket: 'day' }); if (!r || typeof r.ms !== 'number') return null; return r.ms <= (v.ore || 3) * 3600000; }catch(_){ return null; }
  }
  return null;
}
let PAT_CONTROLLO = false;
async function patControllaGiorni(){
  if (!patPuo() || PAT_CONTROLLO) return;
  PAT_CONTROLLO = true;
  try{
    let lista = PAT.lista;
    if (!Array.isArray(lista)){ await patCarica(); lista = PAT.lista; }
    if (!Array.isArray(lista)) return;
    const inviati = patJ(PAT_INVIATI_K, {}) || {};
    const oggi = patGiornoK(Date.now());
    let cambiato = false;
    for (const p of lista){
      if (p.ruolo !== 'autore' || p.stato !== 'attivo') continue;
      const gia = {}; (p.giorni || []).forEach(function(g){ if (g.esito !== 'nessundato') gia[g.giorno] = g.esito; });
      for (const g of patPrevisti(p, oggi)){
        const k = p.id + '|' + g;
        if (gia[g] || inviati[k]) continue;
        const v = await patVerdetto(p.abitudine || {}, g);
        if (v === null) continue;
        const esito = v ? 'rispettato' : 'mancato';
        try{
          const r = await patApi('POST', '/api/focuslock/patti/giorno', { id: p.id, giorno: g, esito: esito, dettaglio: v ? 'Fatto, visto dal telefono' : 'Non fatto entro l’ora del patto' });
          inviati[k] = esito; cambiato = true;
          if (!v){
            const gv = { giorno: patData(g), chi: p.garante || T('il tuo garante'), euro: patEuro((r && r.importo) || 0) };
            toast(!(r && r.importo) ? T('Patto mancato {giorno}: {chi} lo sa', gv)
              : p.destinazione && p.destinazione.tipo === 'beneficenza' ? T('Patto mancato {giorno}: {euro} da donare a {ente}', { giorno: gv.giorno, euro: gv.euro, ente: p.destinazione.ente || T('l’ente che hai scelto') })
              : T('Patto mancato {giorno}: devi {euro} a {chi}, entro 48 ore', gv));
          }
        }catch(_){ }
      }
    }
    if (cambiato){ patScrivi(PAT_INVIATI_K, inviati); await patCarica(); lista = Array.isArray(PAT.lista) ? PAT.lista : lista; if (document.getElementById('patBody')) patPaint(); }
    /* i debiti non pagati in tempo: la penitenza, una volta sola */
    try{ await patPenitenzeControlla(lista); }catch(_){ }
    /* il garante: quello che e' successo dall'ultima volta, senza dover chiedere */
    const visti = patJ(PAT_VISTI_K, {}) || {};
    let nuovi = 0, soldi = 0, chi = ''; const pagati = [];
    lista.forEach(function(p){
      if (p.ruolo !== 'garante') return;
      (p.giorni || []).forEach(function(g){
        const k = p.id + '|' + g.giorno;
        if (g.esito === 'mancato' && !visti[k]){ visti[k] = 1; nuovi++; soldi += g.importo || 0; chi = p.autore; }
        if (g.debito === 'pagato' && !visti[k + '|pagato']){ visti[k + '|pagato'] = 1; pagati.push(T('{chi} dice di averti pagato {euro}: controlla e conferma nel patto', { chi: p.autore, euro: patEuro(g.importo) })); }
      });
    });
    patScrivi(PAT_VISTI_K, visti);
    if (nuovi){
      const nv = { chi: chi, n: nuovi, euro: patEuro(soldi) };
      toast(nuovi === 1 ? (soldi ? T('{chi} ha mancato un giorno del patto: ti deve {euro}', nv) : T('{chi} ha mancato un giorno del patto', nv))
                        : (soldi ? T('{chi} ha mancato {n} giorni del patto: ti deve {euro}', nv) : T('{chi} ha mancato {n} giorni del patto', nv)));
    }
    else if (pagati.length) toast(pagati[0]);
  } finally { PAT_CONTROLLO = false; }
}
(function(){
  setTimeout(patControllaGiorni, 9000);
  document.addEventListener('visibilitychange', function(){
    if (document.hidden) return;
    setTimeout(patControllaGiorni, 2500);
  });
  setInterval(patControllaGiorni, 15 * 60000);
  const css = [
    '.pat-intro{margin:4px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.pat-intro b{color:var(--navy)}body.dark .pat-intro b{color:#fff}',
    '.pat-carica{text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.pat-card{display:flex;flex-direction:column;gap:6px;padding:18px 16px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:14px}body.dark .pat-card{background:#12203A;border-color:#22345A}',
    '.pat-card.garante{border-color:#E63946}',
    '.pat-debiti{display:flex;flex-direction:column;gap:10px;width:100%;margin:12px 0}',
    '.pat-deb{display:flex;flex-direction:column;gap:4px;padding:14px;border-radius:16px;background:#fff;border:1px solid var(--line);text-align:left}body.dark .pat-deb{background:#12203A;border-color:#22345A}',
    '.pat-deb b{font:800 16px/1.3 var(--font-body);color:var(--navy)}body.dark .pat-deb b{color:#fff}.pat-deb small{font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.pat-deb.scaduto{border-color:#E63946;background:#FFF1F2}body.dark .pat-deb.scaduto{background:#3A1620}.pat-deb.ricevuto{opacity:.75}',
    '.pat-deb-az{display:flex;flex-direction:column;gap:6px;margin-top:8px}',
    '.pat-paga-t{margin:0 0 6px;font:800 19px/1.3 var(--font-body);color:var(--navy)}body.dark .pat-paga-t{color:#fff}',
    '.pat-paga-s{margin:6px 0;font:500 13px/1.5 var(--font-body);color:var(--muted)}.pat-paga-l{display:flex;flex-direction:column;gap:8px;margin:12px 0}',
    /* il foglio del diario (la carta .dv-carta di diario.js): sta sempre nei suoi colori, anche al buio */
    '.pat-carta,body.dark .pat-carta{background-color:#efe3c6;background-image:radial-gradient(ellipse at 20% 10%,rgba(255,255,255,.35),transparent 55%),radial-gradient(ellipse at 90% 90%,rgba(120,80,30,.16),transparent 50%)}',
    '.pat-carta{position:relative;align-items:center;text-align:center;gap:0;padding:30px 26px 26px;border:0;border-radius:6px 16px 16px 6px;box-shadow:0 14px 30px rgba(0,30,68,.22),inset 0 0 0 1px rgba(0,0,0,.06);margin-bottom:22px}',
    '.pat-carta::before{left:12px}',
    '.pat-carta > *{position:relative;z-index:1}',
    '.pat-carta .pat-eti,.pat-carta.garante .pat-eti{font:700 12px var(--font-body);letter-spacing:.14em;color:#7a6248}',
    '.pat-stato{margin:6px 0 0;font:500 19px/1.2 "Caveat","Segoe Print","Bradley Hand",cursive;color:#b23a3a}',
    '.pat-carta .pat-cosa,body.dark .pat-carta .pat-cosa{margin:20px 0 6px;font:700 28px/1.15 "Caveat","Segoe Print","Bradley Hand",cursive;color:#2b1f14;overflow-wrap:anywhere}',
    '.pat-onda{display:block;width:150px;height:8px;margin:0 auto 22px}',
    '.pat-clausola{width:100%;margin-bottom:22px}.pat-clausola small{display:block;font:700 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#7a6248}',
    '.pat-clausola p,body.dark .pat-clausola p{margin:6px 0 0;font:500 21px/1.25 "Caveat","Segoe Print","Bradley Hand",cursive;color:#3b2d20}.pat-clausola p b{font-weight:700;color:#b23a3a}',
    '.pat-carta .pat-pals{justify-content:center;margin:10px 0 0}',
    '.pat-carta .pat-soldi,body.dark .pat-carta .pat-soldi{margin:0 0 22px;font:700 21px/1.25 "Caveat","Segoe Print","Bradley Hand",cursive;color:#2b1f14}',
    '.pat-carta .pat-nota,body.dark .pat-carta .pat-nota{margin:0 0 22px;background:rgba(120,80,30,.1);color:#5a4634}',
    /* 0.9.372: le due firme alla stessa altezza (prima "firma del garante" stava piu' in alto) */
    '.pat-firme > div{display:flex;flex-direction:column;justify-content:flex-end}.pat-firme i,.pat-firme .pat-firma-img{height:36px;min-height:36px!important;box-sizing:border-box;border-bottom:1.5px solid #5a4634}.pat-firme .pat-firma-img{object-fit:contain;object-position:left bottom}',
    '.pat-dip{margin:0 0 26px;text-align:center}.pat-dip .pat-stato{margin:0 0 14px}.pat-dip .ctr-stampa{margin:16px auto 0}.pat-dip .pat-soldi{margin:22px 0 0}.pat-dip .pat-az{margin-top:26px}',
    '.pat-firme{display:grid;grid-template-columns:1fr 1fr;gap:18px;width:100%;margin:6px 0 24px}.pat-firme i{display:block;min-height:30px;padding-bottom:2px;border-bottom:1.5px solid #5a4634;font:700 24px/1.2 "Caveat","Segoe Print","Bradley Hand",cursive;font-style:normal;color:#2b1f14;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.pat-firme small{display:block;margin-top:5px;font:500 11.5px var(--font-body);color:#7a6248}',
    '.pat-az{display:flex;flex-direction:column;gap:6px;width:100%}.pat-carta .am-link{color:#5a4634}',
    '.pat-eti{font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}.pat-card.garante .pat-eti{color:#D63384}',
    '.pat-cosa{font:800 19px/1.3 var(--font-display);color:var(--navy)}body.dark .pat-cosa{color:#fff}',
    '.pat-ver,.pat-posta,.pat-soldi{margin:0;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.pat-posta b{color:#E63946;font-weight:800}.pat-soldi{color:var(--navy);font-weight:700}body.dark .pat-soldi{color:#fff}',
    '.pat-nota{margin:2px 0 0;padding:8px 10px;border-radius:12px;background:var(--bg,#F4F9FF);font:500 12px/1.4 var(--font-body);color:var(--muted)}body.dark .pat-nota{background:#0F1B33}',
    '.pat-pals{display:flex;align-items:center;gap:6px;margin:4px 0}.pat-pals small{margin-left:4px;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.pat-pal{width:16px;height:16px;border-radius:50%;background:var(--line)}.pat-pal.rispettato{background:#0075E3}.pat-pal.mancato{background:#E63946}.pat-pal.nessundato{background:#B9C6DD}',
    '.pat-card .am-cta{margin-top:8px}.pat-nuovo{margin:2px 0 20px}',
    '.pat-sez{margin:6px 4px 10px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.pat-firma-riga{display:flex;align-items:center;gap:12px;width:100%;text-align:left;border:0;background:transparent;padding:14px 4px;border-top:1px solid var(--line);cursor:pointer}.pat-firma-riga > span:first-child{font-size:22px}.pat-firma-riga > span:nth-child(2){flex:1}',
    '.pat-firma-riga b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .pat-firma-riga b{color:#fff}.pat-firma-riga small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.pat-w{display:flex;flex-direction:column;gap:12px}',
    '.pat-q{margin:6px 0 0;font:800 24px/1.25 var(--font-display);color:var(--navy);text-align:center;text-wrap:balance}body.dark .pat-q{color:#fff}',
    '.pat-qs{margin:0 0 6px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.pat-esempi{display:flex;flex-wrap:wrap;gap:8px}.pat-esempi button{border:1px dashed var(--line);background:transparent;border-radius:99px;padding:8px 12px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-esempi button{color:#fff}',
    '.pat-ver-l{display:flex;flex-direction:column;gap:8px}.pat-ver-l button{display:flex;align-items:center;gap:12px;text-align:left;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:16px;padding:12px;cursor:pointer}body.dark .pat-ver-l button{background:#12203A;border-color:#22345A}',
    '.pat-ver-l button.on{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4}.pat-ver-l span:first-child{font-size:22px}.pat-ver-l b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .pat-ver-l b{color:#fff}.pat-ver-l small{display:block;font:500 12px/1.35 var(--font-body);color:var(--muted)}',
    '.pat-gg{display:flex;justify-content:space-between;gap:6px}.pat-gg button{flex:1;aspect-ratio:1;border-radius:50%;border:1.5px solid var(--line);background:var(--card,#fff);font:800 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-gg button{background:#12203A;border-color:#22345A;color:#fff}.pat-gg button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.pat-l{font:700 13px var(--font-body);color:var(--navy);margin-top:4px}body.dark .pat-l{color:#fff}',
    '.pat-poste{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.pat-poste button{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;padding:12px 0;font:800 15px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-poste button{background:#12203A;border-color:#22345A;color:#fff}.pat-poste button.on{background:#E63946;border-color:#E63946;color:#fff}',
    '.pat-contratto{padding:18px 16px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .pat-contratto{background:#12203A;border-color:#22345A}.pat-contratto p{margin:0 0 10px;font:500 14.5px/1.55 var(--font-body);color:var(--navy)}body.dark .pat-contratto p{color:#fff}.pat-contratto p:last-child{margin:0}',
    '.pat-cod{text-align:center;font:800 22px var(--font-body);letter-spacing:.2em;text-transform:uppercase}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* 0.9.374: le azioni del patto, una sola piena per volta; lo stato sotto, smorzato; Modifica come link chiaro */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.pat-dip .pat-az{margin-top:24px}.pat-dip .ctr-stampa{margin:12px 0 0!important}.pat-stat{margin:26px 0 0;display:flex;flex-direction:column;align-items:center;gap:8px}.pat-stat .pat-soldi{margin:0;font:600 14px var(--font-body);color:var(--muted)}.pat-mod{display:block;margin:14px auto 0;padding:10px 14px;border:0;background:none;color:#0075E3;font:700 14.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}body.dark .pat-mod{color:#8CC6FF}.am-cta.pat-nuovo.sec{background:#FDECEE!important;color:#E63946!important;border:1.5px solid #E63946!important;box-shadow:none!important;margin-top:34px}body.dark .am-cta.pat-nuovo.sec{background:rgba(230,57,70,.14)!important;color:#FF8A92!important;border-color:#E63946!important}'; document.head.appendChild(st); })();
/* 22/11/2026: quando arriva la traduzione (lingua.js) la pagina aperta si ridisegna nella lingua di chi legge */
if (typeof ltAlCambio === 'function') ltAlCambio(function(){ if (document.getElementById('patBody')) patPaint(); if (document.getElementById('patW') && PAT.w) patWPaint(); if (document.getElementById('patF')) patFirmaPaint(); });
