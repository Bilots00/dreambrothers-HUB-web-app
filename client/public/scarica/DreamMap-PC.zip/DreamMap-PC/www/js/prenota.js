/* ===========================================================================================
   IL PUNTO PRENOTATO — il pre-commitment, e le decisioni a tempo del tuo agente personale

   IL TRUCCO DEL BARATTOLO. Andrea metteva la pallina nel barattolo PRIMA di fare la cosa: la
   micro-decisione di metterla lo obbligava, per coerenza, a fare la cosa subito dopo. Qui il
   barattolo e' il tabellone: il punto va al nuovo te nel momento in cui decidi, ma e' solo
   PRENOTATO. Si conferma chiudendo la task in una sessione FullFocus entro oggi (chiusa entro
   un'ora vale doppio, come un tiro da tre), e a fine giornata, se la task e' ancora aperta,
   torna indietro con il suo motivo scritto nel registro.

   DUE PORTE:
     · dopo la chiamata dei sogni (dreamcall.js): il pannello olografico del primo passo,
       «parti prima di sentirti pronto» — la stessa cornice della proroga della severa;
     · le decisioni del tuo agente personale (Jordan, via jordan.js): una scelta vera fra due strade,
       con un conto alla rovescia che si vede tre secondi e poi sparisce. Risposta in tempo =
       punto prenotato; lo tieni se mantieni la decisione, e l'agente puo' revocarlo con una
       riga di motivo (`revoche` nel verdetto) se torni indietro.

   Le persone che riescono decidono in fretta e cambiano idea lentamente; le altre ci mettono
   settimane a decidere e disfano tutto subito. Questo modulo allena la prima abitudine.
   =========================================================================================== */

const PK_KEY = 'fl_prenotazioni';            // [{ id, tipo, testo, at, giorno, scade, stato, punti, decId, scelta, motivo }]
const PK_RISP_KEY = 'fl_decisioni_risposte'; // [{ id, scelta, testo, domanda, at, inTempo, secondi }]
const PK_DOPPIO_MIN = 60;                    // entro quanti minuti la task chiusa vale doppio
const PK_TIMER_VISTA_MS = 3000;              // il conto alla rovescia si vede cosi', poi sparisce
const PK = { task: '', dec: null, scadeAt: 0, timer: 0, mostrata: {} };

function pkLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function pkScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function pkKey(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function pkNorm(s){ return String(s || '').toLowerCase().replace(/[^a-z0-9àèéìòù]+/g, ' ').trim(); }
function pkEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x); }
function pkLista(){ return pkLeggi(PK_KEY, []) || []; }
function pkSalva(l){ pkScrivi(PK_KEY, l.slice(-200)); }
function pkAperte(tipo){ return pkLista().filter(function(x){ return x && x.stato === 'prenotato' && (!tipo || x.tipo === tipo); }); }

/* ---------------------------------------------------------------------------------------
   IL TABELLONE: il punto si mette subito, e si toglie con il motivo
   --------------------------------------------------------------------------------------- */
function pkSegna(motivo){
  try{ if (typeof mgLog === 'function') mgLog('neo', motivo); }catch(_){ }
  try{ if (typeof mtFocusPoint === 'function') mtFocusPoint(); }catch(_){ }
}
/** −1 al nuovo te. Il registro lo scrive come «revoca», e il tabellone condiviso lo sa. */
function pkTogli(motivo){
  try{
    if (typeof mtRoll !== 'function' || typeof mtWrite !== 'function') return;
    const s = mtRoll();
    s.neo = Math.max(0, (s.neo || 0) - 1);
    mtWrite(MT_KEY, s);
    if (typeof mgLog === 'function') mgLog('revoca', motivo);
    /* il conto di questo dispositivo sul tabellone condiviso scende con lui: altrimenti alla
       prossima sincronizzazione il punto tornerebbe da solo */
    try{
      if (typeof lsMine === 'function' && typeof lsWrite === 'function'){
        const m = lsMine();
        m.neo = Math.max(0, (m.neo || 0) - 1);
        if (m.seen) m.seen.neo = Math.max(0, (m.seen.neo || 0) - 1);
        lsWrite(m);
        if (typeof lsPushSoon === 'function') lsPushSoon();
      }
    }catch(_){ }
    if (typeof mtPaint === 'function') mtPaint();
    pkCartello(motivo);
  }catch(_){ }
}
/** Il cartello della revoca: come quello del gol, ma dice cosa e' stato tolto e perche'. */
function pkCartello(motivo){
  if (typeof document === 'undefined') return;
  /* 0.9.397: lo stesso cartello del gol (start.js, mtCartello) con la riga della revoca appena scritta: cosi' anche qui c'e' "Chiedi il VAR" */
  if (typeof mtCartello !== 'function') return;
  let ev = null;
  try{ ev = ((typeof mgToday === 'function' ? mgToday() : {}).eventi || []).filter(function(e){ return e && e.chi === 'revoca'; }).pop() || null; }catch(_){ }
  mtCartello({ tipo: 'revoca', ev: ev || { chi: 'revoca', motivo: String(motivo || ''), at: Date.now() } });
}

/* ---------------------------------------------------------------------------------------
   PRENOTARE, CONFERMARE, REVOCARE
   --------------------------------------------------------------------------------------- */
function pkPrenota(tipo, testo, extra, adesso){
  const at = adesso || Date.now();
  const r = Object.assign({
    id: 'p' + at.toString(36) + Math.floor(Math.random() * 1000).toString(36),
    tipo: tipo, testo: String(testo || '').trim(), at: at, giorno: pkKey(at),
    scade: tipo === 'passo' ? at + PK_DOPPIO_MIN * 60000 : 0, stato: 'prenotato', punti: 1
  }, extra || {});
  const l = pkLista(); l.push(r); pkSalva(l);
  if (tipo === 'punto'){ pkSegna('Punto prenotato: "' + r.testo + '" alle ' + pkOra(r.inizio) + '. Resta se lo fai entro la fine dell’appuntamento'); return r; }
  pkSegna(tipo === 'passo'
    ? 'Punto prenotato: «' + r.testo + '». Vale se la chiudi in FullFocus entro oggi'
    : 'Decisione presa in tempo. «' + (r.scelta || r.testo) + '». Vale se la mantieni');
  return r;
}
function pkConferma(id, quando){
  const l = pkLista();
  const r = l.filter(function(x){ return x.id === id && x.stato === 'prenotato'; })[0];
  if (!r) return null;
  quando = quando || Date.now();
  r.stato = 'confermato'; r.confermataAt = quando;
  const prima = !!(r.scade && quando <= r.scade);
  if (prima){ r.punti = 2; }
  pkSalva(l);
  if (prima) pkSegna('Chiusa prima della scadenza. Punto doppio («' + r.testo + '»)');
  else if (typeof toast === 'function') toast('Punto confermato: «' + r.testo + '»');
  return r;
}
function pkRevoca(id, motivo){
  const l = pkLista();
  const r = l.filter(function(x){ return x.id === id && x.stato === 'prenotato'; })[0];
  if (!r) return null;
  r.stato = 'revocato'; r.motivo = String(motivo || ''); r.revocataAt = Date.now();
  pkSalva(l);
  pkTogli(r.motivo);
  return r;
}
/** La task chiusa (la risposta «Si', completata», o una riga spuntata con la prova). */
function pkConfermaTask(testo, quando){
  const n = pkNorm(testo);
  const aperte = pkAperte('passo');
  let r = aperte.filter(function(x){ return n && pkNorm(x.testo) === n; })[0];
  /* senza un testo che combacia, vale la prenotazione di oggi: era quella la task */
  if (!r) r = aperte.filter(function(x){ return x.giorno === pkKey(quando || Date.now()); })[0];
  return r ? pkConferma(r.id, quando) : null;
}
/** Dopo una sessione FullFocus chiusa bene con quella intenzione. */
function pkDopoSessione(){
  let ultima = null;
  /* 0.9.389 (BUG-115), Andrea: "il punto per essere assegnato deve essere dentro la pagina di Full Focus": una sessione andata avanti da sola non conta (ffPuntoValido) */
  try{ ultima = (pkLeggi('fl_ff_hist', []) || []).filter(function(x){ return (typeof ffPuntoValido === 'function' ? ffPuntoValido(x) : (x && x.ok)); }).slice(-1)[0]; }catch(_){ }
  if (!ultima || Date.now() - ultima.at > 30 * 60000 || !ultima.intent) return;
  const n = pkNorm(ultima.intent);
  const r = pkAperte('passo').filter(function(x){ return pkNorm(x.testo) === n; })[0];
  if (r) pkConferma(r.id, ultima.at);
}
/** A fine giornata quello che e' rimasto aperto torna indietro. */
function pkControlla(adesso){
  const ora = adesso || Date.now();
  const oggi = pkKey(ora);
  pkAperte('passo').forEach(function(r){
    if (r.giorno < oggi) pkRevoca(r.id, 'Task «' + r.testo + '» non chiusa entro fine giornata. Il punto prenotato torna indietro');
  });
  pkPuntiControlla(ora);
}

/* ---------------------------------------------------------------------------------------
   LA PORTA 3 (0.9.242): "PRENOTA IL PUNTO", i passi di domani messi a un'ora precisa

   Dal sistema di Davie Fogarty: le cose importanti di domani si mettono in calendario a un'ora
   precisa, la sera prima. Prenotarle e' gia' un micro-impegno, e vale subito +1 al nuovo te.
   Se l'ora dell'appuntamento passa e il passo non e' fatto, il punto torna indietro con il suo
   motivo scritto. Si apre dalla scheda Domani del piano del percorso e dalla fine della
   revisione della sera. L'appuntamento va nel calendario di DreamMap (calendario.js) e, se e'
   collegato, in quello del telefono.
   --------------------------------------------------------------------------------------- */
/* 0.9.294, Andrea: "si prenota un punto per una sola task, la prossima, non 200": un punto al giorno, e solo il passo
   che viene adesso nella roadmap */
const PK_PUNTI_MAX = 1;
const PK_PUNTO = { scelto: -1, ora: '09:00', durata: 60, voci: [], giorno: '' };
function pkOra(ms){ const d = new Date(ms || Date.now()); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
/* 0.9.363 (lavoro 18): alle 00:40, ancora svegli, il punto prenotato e' per la mattina che arriva, cioe' per oggi */
function pkDomaniKey(){ return pkKey((typeof flDopoMezzanotte === 'function' && flDopoMezzanotte()) ? Date.now() : Date.now() + 86400000); }
/** Il passo e' fatto? Nella roadmap (fl_orizzonti), fra le righe spuntate di quel giorno, o in una sessione chiusa con quell'intenzione. */
function pkPuntoFatto(r){
  const n = pkNorm(r.testo);
  try{
    if (typeof ozAnello === 'function'){
      const k = ['oggi', 'settimana', 'mese', 'anno', 'cinque'];
      for (let i = 0; i < k.length; i++){
        const p = (ozAnello(k[i]).passi || []).filter(function(x){ return x && pkNorm(x.t) === n; })[0];
        if (p && p.fatto) return true;
      }
    }
  }catch(_){ }
  try{ if ((pkLeggi('fl_notes_done', []) || []).some(function(x){ return x && x.day === r.giorno && pkNorm(x.text) === n; })) return true; }catch(_){ }
  /* 0.9.389 (BUG-115), Andrea: "il punto per essere assegnato deve essere dentro la pagina di Full Focus": una sessione andata avanti da sola non conta (ffPuntoValido) */
  try{ if ((pkLeggi('fl_ff_hist', []) || []).some(function(x){ return (typeof ffPuntoValido === 'function' ? ffPuntoValido(x) : (x && x.ok)) && x.at >= r.at && pkNorm(x.intent) === n; })) return true; }catch(_){ }
  return false;
}
function pkPuntiControlla(ora){
  pkAperte('punto').forEach(function(r){
    if (pkPuntoFatto(r)){
      const l = pkLista(); const x = l.filter(function(y){ return y.id === r.id; })[0];
      if (x){ x.stato = 'confermato'; x.confermataAt = ora; pkSalva(l); }
      if (typeof toast === 'function') toast('Punto confermato: "' + r.testo + '"');
      return;
    }
    if (r.fine && ora > r.fine) pkRevoca(r.id, 'Il passo "' + r.testo + '" era prenotato per le ' + pkOra(r.inizio) + ' e non è stato fatto in tempo. Il punto torna indietro');
  });
}
/* ---------------------------------------------------------------------------------------
   IL PASSO DI DOMANI, DA UNA FUNZIONE SOLA (0.9.388)
   Andrea (BUG-112): "nella revisione la prima cosa di domani era Il tuo piano su misura, e dopo la chiusura il passo di domani era
   Guarda quali prodotti hanno venduto di piu' nell'ultimo mese". LA CAUSA: erano due funzioni. La revisione (rvDomaniTask) leggeva
   anche la tappa in corso della mappa, che puo' non essere una cosa da fare (la tappa del piano su misura si chiama cosi'); Prenota
   il punto (pkPuntoVoci) leggeva i passi di domani della roadmap. Adesso c'e' pkPassiDomani, e la usano la revisione della sera,
   quelle di periodo, il popover del passo di domani e la prenotazione. Dall'alto: il passo gia' prenotato per domani, quello che
   hai scelto tu per domani, i passi di domani della roadmap (prima quelli di lavoro vero), le righe del foglio di domani (prima
   della roadmap per chi pianifica da se'), la missione della mappa. Mai il nome di una tappa che non e' una cosa da fare.
   --------------------------------------------------------------------------------------- */
function pkPassoPulito(s){ return String(s || '').replace(/^[☐☑•\-\s]+/, '').replace(/\s*·\s*(oggi|domani)\s*$/i, '').trim(); }
/* ---------------------------------------------------------------------------------------
   0.9.403, Andrea (BUG-280, BUG-284; lezioni 369 e 372): "nella revisione ho prenotato Togliere dal negozio i capi..., e uscendo la
   roadmap mostrava come prossimo passo Scrivere in una pagina l'offerta completa"; "il badge diceva 1 ora, il Perché 20 minuti, il
   Tempo stimato 15". LE CAUSE: la revisione prendeva i passi "di domani" della roadmap (rmpPassi().domani, che dopo un passo fatto
   oggi scivola di uno), la mappa il primo passo aperto (sdRoadmapPassi); e il tempo aveva tre fonti (60 di serie nel badge, la frase
   dell'agente, il numero dell'agente arrotondato al quarto d'ora). Adesso:
   · IL PROSSIMO PASSO viene da una fonte sola: il punto prenotato (finche' e' aperto) e poi il primo passo aperto della roadmap, nello
     stesso ordine per la revisione, il popover, la mappa, la scheda Oggi e il pannello Prossima tappa (sdRoadmapPassi mette davanti il
     prenotato; pkPassiDomani legge sdRoadmapPassi);
   · I DATI DI UN PASSO (il tempo e la categoria scelti dall'agente) stanno in fl_passo_dati, con la stessa chiave per tutti: il badge,
     il foglio (i), la roadmap, START e la mappa leggono lo stesso numero (pkTempoNoto). Se l'agente cambia la stima, cambia ovunque.
   --------------------------------------------------------------------------------------- */
const PK_DATI_KEY = 'fl_passo_dati';           // { chiave: { min, cat, at } }
function pkChiave(t){ return pkNorm(pkTitolo(pkPassoPulito(t)).replace(/[.…\s]+$/, '')); }
function pkDati(){ const v = pkLeggi(PK_DATI_KEY, {}); return (v && typeof v === 'object') ? v : {}; }
function pkDato(t){ const k = pkChiave(t); return k ? (pkDati()[k] || null) : null; }
function pkDatoSalva(t, patch){
  const k = pkChiave(t); if (!k) return;
  const d = pkDati(); d[k] = Object.assign({}, d[k] || {}, patch || {}, { at: Date.now() });
  Object.keys(d).sort(function(a, b){ return (d[b].at || 0) - (d[a].at || 0); }).slice(200).forEach(function(x){ delete d[x]; });
  pkScrivi(PK_DATI_KEY, d);
}
/** Il tempo di un passo che qualcuno ha gia' stimato (l'agente): 0 se nessuno. */
function pkTempoNoto(t){ const x = pkDato(t); return x && +x.min > 0 ? +x.min : 0; }
/** Un testo di passo con "(60 minuti)" dentro dice il tempo unico, se c'e'. */
function pkTempoNelTesto(t){ const n = pkTempoNoto(t); return n ? String(t || '').replace(/\((\d+)\s*(min[a-z]*)\)/i, '(' + n + ' $2)') : String(t || ''); }
/** I minuti, arrotondati ai 5 (mai al quarto d'ora: 20 minuti restano 20). */
function pkArrotonda(m){ return Math.max(5, Math.min(180, Math.round((+m || 0) / 5) * 5)); }
/** Il punto prenotato che e' ancora da fare (oggi o domani): e' IL prossimo passo. */
function pkPuntoAttivo(){
  const oggi = pkKey(Date.now()), ora = Date.now();
  return pkLista().filter(function(x){ return x && x.tipo === 'punto' && x.stato === 'prenotato' && String(x.giorno || '') >= oggi && !(x.fine && ora > x.fine); })
    .sort(function(a, b){ return (a.inizio || 0) - (b.inizio || 0); })[0] || null;
}
/** Un passo che e' solo una scelta da due secondi viene dopo quelli di lavoro vero (0.9.347): la stessa regola per tutti. */
function pkOrdinaPassi(l){
  l = l || [];
  return l.filter(function(x){ return !pkMicroScelta(x.t); }).concat(l.filter(function(x){ return pkMicroScelta(x.t); }));
}
/** Un testo lungo, accorciato alla fine di una parola con "…" (mai a meta' parola). */
function pkTaglia(t, n){
  t = String(t || '').replace(/\s+/g, ' ').trim(); n = n || 400;
  if (t.length <= n) return t;
  return t.slice(0, n).replace(/\s+\S*$/, '').replace(/[\s,;:.–—-]+$/, '') + '…';
}
/** Il titolo del passo a schermo: { corto, intero, tagliato }. Un passo salvato tagliato a 160 lettere (fino alla 0.9.402) finisce
    con "…" e non a meta' parola. */
function pkTitoloVis(t, n){
  let intero = pkTitolo(t); n = n || 90;
  if (intero.length >= 158 && !/[.!?)…"»]$/.test(intero)) intero = intero.replace(/\s+\S*$/, '').replace(/[\s,;:.–—-]+$/, '') + '…';
  if (intero.length <= n + 12) return { corto: intero, intero: intero, tagliato: false };
  return { corto: pkTaglia(intero, n), intero: intero, tagliato: true };
}
function pkPassiDomani(){
  const out = [], visti = {};
  const metti = function(t, extra){
    const x = pkPassoPulito(t), n = pkChiave(x);
    if (!x || visti[n]) return; visti[n] = 1;
    out.push(Object.assign({ t: x }, extra || {}));
  };
  pkPuntiDomani().forEach(function(r){ metti(r.testo, { prenotato: r, k: r.k || '', j: r.j != null ? r.j : -1, fonte: 'prenotato' }); });
  try{ const o = (typeof stOne === 'function') ? stOne() : null; if (o && !o.done && o.forDay && typeof mtKey === 'function' && o.forDay > mtKey(Date.now())) metti(o.task && (o.task.text || o.task.t || o.task), { fonte: 'scelto' }); }catch(_){ }
  const mio = pkPianificaIo();
  const foglio = function(){ try{ ((typeof stLines === 'function') ? stLines('tomorrow') : []).forEach(function(t){ metti(t, { fonte: 'foglio' }); }); }catch(_){ } };
  if (mio) foglio();
  const rm = [];
  /* 0.9.403 BUG-280: il primo passo aperto della roadmap, lo stesso che la mappa e la scheda Oggi mostrano come prossimo (sdRoadmapPassi,
     sentiero-mappa.js). rmpPassi().domani e' solo il riparto sui giorni: dopo un passo fatto oggi scivolava di uno */
  let daMappa = false;
  try{ if (typeof sdRoadmapPassi === 'function'){ sdRoadmapPassi().forEach(function(x){ if (x && x.t) rm.push({ t: x.t, k: x.k, j: x.j, min: x.min }); }); daMappa = true; } }catch(_){ daMappa = false; }
  if (!daMappa){
    try{ if (typeof rmpPassi === 'function') (rmpPassi().domani || []).forEach(function(x){ if (x && x.t && !x.fatto) rm.push({ t: x.t, k: x.k, j: x.j }); }); }catch(_){ }
    try{ if (typeof ozAnello === 'function') ['settimana', 'mese'].forEach(function(k){ (ozAnello(k).passi || []).forEach(function(p, j){ if (p && p.t && !p.fatto) rm.push({ t: p.t, k: k, j: j }); }); }); }catch(_){ }
  }
  /* 0.9.347: un passo che e' solo una scelta da due secondi viene dopo quelli di lavoro vero */
  pkOrdinaPassi(rm).forEach(function(x){ metti(x.t, { k: x.k, j: x.j, min: x.min, fonte: 'roadmap' }); });
  if (!mio) foglio();
  try{ const s = pkPassoDalSentiero(); if (s) metti(s.t, { min: s.min, fonte: 'mappa' }); }catch(_){ }
  try{ if (typeof gtPrimaTappa === 'function') metti(gtPrimaTappa(), { fonte: 'mappa' }); }catch(_){ }
  return out;
}
/* 0.9.374, Andrea: "dice Domani si comincia da qui: Una sessione di Full Focus. Si', ma su che cosa?". Una sessione senza argomento
   dice su cosa: il passo che viene dopo, la cosa di oggi, altrimenti il sogno */
function pkPassoSuCosa(t, l){
  t = String(t || '');
  if (!/full focus/i.test(t) || / su |:/i.test(t.replace(/full focus/i, ''))) return t;
  let su = '';
  (l || []).some(function(y){ if (y.t !== t && !/full focus/i.test(y.t)){ su = y.t; return true; } return false; });
  try{ if (!su && typeof stTask === 'function'){ const x = pkPassoPulito(stTask()); if (x && !/full focus/i.test(x)) su = x; } }catch(_){ }
  try{ if (!su && typeof nvSogno === 'function'){ const x = String(nvSogno() || '').trim(); if (x) su = x; } }catch(_){ }
  return su ? t.replace(/\.$/, '') + ' su: ' + su.charAt(0).toLowerCase() + su.slice(1) : t;
}
/** IL passo di domani: { t, k, j, min, prenotato, fonte } oppure null. */
function pkPassoDomani(){
  const l = pkPassiDomani(); if (!l.length) return null;
  return Object.assign({}, l[0], { t: pkPassoSuCosa(l[0].t, l) });
}
/** I passi da proporre per la prenotazione: lo stesso passo di domani (uno solo per chi segue il Genio, fino a otto per chi pianifica da se'). */
function pkPuntoVoci(){
  const l = pkPassiDomani();
  return l.filter(function(x){ return !x.prenotato; }).map(function(x){ return Object.assign({}, x, { t: pkPassoSuCosa(x.t, l) }); })
    .slice(0, pkPianificaIo() ? 8 : 1);
}
function pkMicroScelta(t){ return /^\s*(scegliere|decidere|valutare|confrontare|individuare|selezionare)\b[^.]{0,60}\b(strumento|tool|app|applicazione|piattaforma|software|programma|servizio|corso|tema|colore|font|nome|fornitore)\b/i.test(String(t || '')); }
/* 0.9.276, Andrea: "se ho scelto di non pianificare, che cazzo mi viene a chiedere cosa fai domani? Non devo
   scriverlo io il passo: lo pianifica il Genio o l'agente". Chi segue la strada del Genio riceve il passo gia'
   scelto (dalla Roadmap, poi dalla mappa) e decide solo l'ora. Chi pianifica da se' sceglie o scrive. */
function pkPianificaIo(){ try{ const u = (typeof faStrada === 'function') ? faStrada() : null; return !!(u && u.scelta === 'mia'); }catch(_){ return false; } }
function pkPassoDalSentiero(){
  try{
    const p = (typeof sdPrimoLeggi === 'function') ? sdPrimoLeggi() : null;
    /* 0.9.382: un primo passo salvato dalla lista generica (cosa vendi e a chi) non vale per chi ha un sogno preciso con i suoi passi */
    let generico = false;
    try{ const det = gnDati().sognoDettaglio; const g = ((SN.cfg && SN.cfg.missioni && SN.cfg.missioni.progetto) || []).map(function(x){ return String(x.t).replace(/\s*\(\d+ min\)$/, ''); });
      generico = !!(SN_MIS_DETTAGLIO[det] && p && g.indexOf(String(p.t).replace(/\s*\(\d+ min\)$/, '')) >= 0);
      /* 0.9.402 BUG-255: un passo che c'e' anche nella lista del suo sogno (per esempio "Cambia l'offerta con quello che ti hanno detto i clienti") vale */
      if (generico && SN_MIS_DETTAGLIO[det].some(function(x){ return String(x.t).replace(/\s*\(\d+ min\)$/, '') === String(p.t).replace(/\s*\(\d+ min\)$/, ''); })) generico = false; }catch(_){ }
    if (p && p.t && !p.fatto && !p.tutte && !generico) return { t: p.t, min: p.min || 30 };
    if (typeof sdTutti === 'function' && typeof sdMissione === 'function'){
      const s = sdStato();
      const nd = sdTutti().filter(function(x){ return x.tipo === 'mis' && !sdNodoFatto(x, s); })[0];
      const m = nd && sdMissione(nd);
      if (m && m.t) return { t: m.t.replace(/\s*\(\d+ min\)$/, ''), min: m.min || 30 };
    }
  }catch(_){ }
  return null;
}
function pkPuntiDomani(){ return pkLista().filter(function(x){ return x.tipo === 'punto' && x.giorno === pkDomaniKey() && x.stato !== 'revocato'; }); }
/* 0.9.347, Andrea: "il Taglia lo farei fare nella revisione serale prima di prenotare il punto del giorno dopo: se quel giorno ha scritto
   delle idee nelle note, o se ha il blocco del focus del sabotatore invisibile (troppa carne al fuoco, non trova la priorita'). Non solo le
   idee: anche le abitudini che non c'entrano con il sogno". Una volta al giorno al massimo; si puo' saltare. */
function pkGiornoInizio(){ const d = new Date(); if (d.getHours() < 5) d.setDate(d.getDate() - 1); d.setHours(0, 0, 0, 0); return d.getTime(); }
function pkTagliaServe(){
  try{
    const d0 = pkGiornoInizio();
    const st = (typeof esStato === 'function') ? esStato() : null;
    if (st && (st.storia || []).some(function(x){ return x.tipo === 'taglia' && x.at >= d0; })) return '';
    if (PK_PUNTO.tagliaSaltata === d0) return '';
    let focus = false; try{ const b = JSON.parse(localStorage.getItem('fl_bq') || localStorage.getItem('fl_blocchi') || 'null'); focus = !!(b && b.primario === 'dispersione'); }catch(_){ }
    let idee = []; try{ idee = (typeof mnIdeePerTaglia === 'function') ? mnIdeePerTaglia(8) : []; }catch(_){ idee = []; }
    let toccata = false; try{ const n = (typeof mnInbox === 'function') ? mnInbox() : null; const t = n && (n.mod || n.m || n.u || n.updatedAt || n.agg || n.at || 0); toccata = +t >= d0; }catch(_){ }
    if (idee.length >= 3 && (toccata || focus)) return 'oggi';
    if (focus) return 'abitudini';
    return '';
  }catch(_){ return ''; }
}
function pkTagliaHtml(arco){
  const idee = arco === 'oggi';
  return '<div class="pkg pkt"><small class="stg-eti">Prima del passo di domani</small>'
    + '<div class="pkt-ico" aria-hidden="true">✂️</div>'
    + '<h2 class="stg-h">' + (idee ? 'Taglia la carne al fuoco' : 'Taglia quello che non serve') + '</h2>'
    + '<p class="stg-p">' + (idee ? 'Oggi nelle tue note sono arrivate idee nuove.' : 'Oggi il telefono ti ha portato da altre parti.') + '</p>'
    + '<p class="stg-p">' + (idee ? 'In 60 secondi tieni solo quella che ti avvicina di più al sogno.' : 'In 60 secondi tagli le abitudini che non c’entrano con il sogno.') + '</p>'
    + '<button type="button" class="stg-cta" onclick="pkTagliaVia(\'' + arco + '\')">Taglia adesso</button>'
    + '<button type="button" class="stg-link" onclick="PK_PUNTO.tagliaSaltata=pkGiornoInizio();stgFoglioCorpo(pkPuntoHtml())">Salta, scelgo il passo</button></div>';
}
function pkTagliaVia(arco){
  try{ stgFoglioChiudi(); }catch(_){ }
  if (typeof esApri !== 'function'){ pkPuntoApri(); return; }
  ES.dopo = function(){ PK_PUNTO.tagliaSaltata = pkGiornoInizio(); pkPuntoApri(); };
  esApri({ id: 'sera-taglia-' + pkGiornoInizio(), es: 'taglia', arco: arco });
}
/* ---------------------------------------------------------------------------------------
   IL POPOVER DEL PASSO DI DOMANI (0.9.388)
   Andrea (BUG-112): "alla fine della revisione cinque pulsanti (Scomponila in 3 passi, Guarda un tutorial, Ho una domanda, Prenota
   il punto, Ci sono, chiudo la giornata), e dopo la chiusura un altro popover, Il tuo prossimo passo, con Scelgo quando farlo / Non
   adesso. Ci vuole UN popover, uguale a quello della roadmap per una tappa da fare in Full Focus: la (i) nel pannello della task con
   il perche', la priorita' e il tempo (li chiede all'agente), il calendario di domani a blocchi per scegliere l'ora libera fra gli
   altri impegni, e Scomponilo, Tutorial e Blinda subito, non solo dopo aver prenotato". Lo aprono la revisione della sera (al posto
   dei cinque pulsanti), quelle di periodo, il piano della roadmap (Prenota il punto) e la pagina finale del diario. Prenotato, resta
   lo stesso popover: dice a che ora e tiene le tre azioni.
   opz: { rev: 'rv' | 'rvp' (dentro una revisione: Scomponi e Tutorial partono quando la revisione si chiude), poi: funzione chiamata
   quando il popover si chiude (dalla X, dal velo o da un pulsante) }.
   --------------------------------------------------------------------------------------- */
const PK_INFO = { mem: {}, attesa: {} };
function pkSvg(d, n){ return '<svg viewBox="0 0 24 24" width="' + (n || 22) + '" height="' + (n || 22) + '" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>'; }
const PK_ICO = {
  scala: '<path d="M7 3v18M17 3v18M7 7.5h10M7 12h10M7 16.5h10"/>',
  video: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.2v5.6l4.6-2.8z"/>',
  scudo: '<path d="M12 3l7 3v5.5c0 4.6-3 7.9-7 9.5-4-1.6-7-4.9-7-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
  perche: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  pri: '<path d="M13 3L5 13.5h6.2L10 21l8.5-10.5h-6.3z"/>',
  tempo: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4.2l2.8 1.8M10 2.5h4"/>',
  /* 0.9.390, Andrea (BUG-121): "l'icona non e' del calendario": il calendario con i giorni (come CAL_I.calGiorni di calendario.js) */
  cal: '<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/><path d="M7.5 13.5h.01M12 13.5h.01M16.5 13.5h.01M7.5 17.2h.01M12 17.2h.01" stroke-width="2.8"/>',
  giu: '<path d="M6 9l6 6 6-6"/>'
};
function pkTitolo(t){ const s = String(t || '').replace(/\s*\(\d+\s*min[^)]*\)\s*$/i, '').trim(); return (typeof flAccenti === 'function') ? flAccenti(s) : s; }
function pkMinDi(t){ const m = /\((\d+)\s*min/i.exec(String(t || '')); return m ? +m[1] : 0; }
/* 0.9.403 BUG-284: il tempo e' uno solo. Prima quello scelto da te in START, poi quello stimato dall'agente (pkTempoNoto, lo stesso
   della mappa e della roadmap), poi quello scritto nel passo, poi quello che scegli di solito (sdStimaImparata, come la mappa), se no
   25 minuti. Niente piu' "1 ora" di serie, e niente arrotondamento al quarto d'ora */
function pkDurataDi(v){
  if (!v) return 25;
  let m = 0;
  try{ if (typeof stMeta === 'function' && typeof stDayKey === 'function'){ const x = stMeta(v.t, stDayKey('tomorrow')); if (x && x.stima) m = +x.stima; } }catch(_){ }
  if (!m) m = pkTempoNoto(v.t);
  if (!m) m = +v.min || pkMinDi(v.t);
  try{ if (!m && typeof sdStimaImparata === 'function') m = +sdStimaImparata(pkTitolo(v.t)) || 0; }catch(_){ }
  return m ? pkArrotonda(m) : 25;
}
/** La durata che il popover mostra (badge, (i), calendario): quella del punto prenotato, se no quella del passo da prenotare. */
function pkDurCorrente(){
  const r = pkPuntiDomani()[0];
  return r ? Math.max(5, Math.round((r.fine - r.inizio) / 60000)) : PK_PUNTO.durata;
}
function pkDurTxt(m){
  m = Math.round(+m || 0); const h = Math.floor(m / 60), r = m % 60;
  if (!h) return m + ' minuti';
  if (!r) return h === 1 ? '1 ora' : h + ' ore';
  if (r === 30) return (h === 1 ? '1 ora' : h + ' ore') + ' e mezza';
  return (h === 1 ? '1 ora' : h + ' ore') + ' e ' + r + ' minuti';
}
/** La mezzanotte del giorno del punto: domani (dopo mezzanotte, finche' non dormi, la mattina che arriva: 0.9.363). */
function pkDomaniBase(){ const d = new Date(); if (!(typeof flDopoMezzanotte === 'function' && flDopoMezzanotte())) d.setDate(d.getDate() + 1); d.setHours(0, 0, 0, 0); return d.getTime(); }
function pkMinDaOra(hhmm){ const p = String(hhmm || '').split(':'); return (+p[0] || 0) * 60 + (+p[1] || 0); }
function pkHHMMDa(min){ return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }
/** Gli impegni di domani gia' in calendario (DreamMap e, se collegato, il calendario del telefono: calendario.js). */
function pkImpegniDomani(){
  const d0 = pkDomaniBase(), d1 = d0 + 86400000;
  let l = []; try{ if (typeof calEventiTra === 'function') l = calEventiTra(d0, d1) || []; }catch(_){ l = []; }
  return l.filter(function(e){ return e && !e.tuttoIlGiorno && +e.fine > +e.inizio; })
    .map(function(e){ return { t: String(e.titolo || 'Impegno'), inizio: Math.max(+e.inizio, d0), fine: Math.min(+e.fine, d1) }; });
}
function pkSlotOccupato(min, durata, imp){
  const s = pkDomaniBase() + min * 60000, e = s + durata * 60000;
  return (imp || pkImpegniDomani()).filter(function(x){ return x.inizio < e && x.fine > s; })[0] || null;
}
/** La prima ora libera di domani per un passo lungo `durata` minuti: prima le 9, poi dalle 8 in avanti, a mezz'ore. */
function pkPrimaOraLibera(durata){
  const imp = pkImpegniDomani(), prove = [9 * 60];
  for (let m = 8 * 60; m <= 21 * 60; m += 30) if (m !== 9 * 60) prove.push(m);
  for (let i = 0; i < prove.length; i++) if (!pkSlotOccupato(prove[i], durata, imp)) return pkHHMMDa(prove[i]);
  return '09:00';
}
/** Il passo che il popover sta mostrando: quello prenotato, se c'e', altrimenti il passo di domani. */
function pkVoceCorrente(){
  const r = pkPuntiDomani()[0];
  if (r) return { t: r.testo, k: r.k || '', j: r.j, fonte: 'prenotato', min: Math.max(5, Math.round((r.fine - r.inizio) / 60000)) };
  return PK_PUNTO.voci[Math.max(0, PK_PUNTO.scelto)] || null;
}
function pkPuntoApri(opz){
  opz = (opz && typeof opz === 'object' && !opz.target) ? opz : {};
  PK_PUNTO.voci = pkPuntoVoci(); PK_PUNTO.fase = 'passo'; PK_PUNTO.oraLibera = false;
  PK_PUNTO.rev = opz.rev || ''; PK_PUNTO.coda = ''; PK_PUNTO.blinda = false; PK_PUNTO.infoAperta = false; PK_PUNTO.calAperto = false;
  /* 0.9.403 BUG-280/283: il titolo lungo si apre con Mostra tutto; l'ora si sceglie dalle pillole o dal calendario (Lo scelgo io) */
  PK_PUNTO.titoloTutto = false; PK_PUNTO.calIo = false; PK_PUNTO.oraScelta = false; PK_PUNTO.prom = pkPromBase();
  /* 0.9.390 (BUG-121): ogni volta che si apre, il calendario riparte da domani, vista Giorno */
  try{ if (typeof CAL !== 'undefined' && CAL.ist) delete CAL.ist.passo; }catch(_){ }
  PK_PUNTO.scelto = PK_PUNTO.voci.length ? 0 : -1;
  PK_PUNTO.durata = pkDurataDi(PK_PUNTO.voci[0]);
  PK_PUNTO.ora = pkPrimaOraLibera(PK_PUNTO.durata);
  const gia = pkPuntiDomani()[0] || null; PK_PUNTO.ultimo = gia;
  if (typeof stgFoglio !== 'function'){ if (typeof opz.poi === 'function') opz.poi(); return; }
  const h = new Date().getHours();
  const taglia = (!PK_PUNTO.rev && !gia && (h >= 17 || h < 5)) ? pkTagliaServe() : '';
  stgFoglio(taglia ? pkTagliaHtml(taglia) : pkPuntoHtml());
  try{ if (typeof STG !== 'undefined') STG.dopoChiudi = typeof opz.poi === 'function' ? opz.poi : null; }catch(_){ }
}
/** Ridisegna il popover lasciando dov'era lo scorrimento (stgFoglioCorpo torna in cima). */
function pkRidisegna(){
  const c = (typeof document !== 'undefined') ? document.querySelector('#stgVelo .stg-fin') : null; if (!c) return;
  /* la griglia del calendario resta dov'era se mostra gli stessi giorni; se no parte un'ora prima del passo */
  const s = c.scrollTop, sc = c.querySelector('.pkc .cal-scroll'), k0 = sc ? sc.getAttribute('data-k') : '', s2 = sc ? sc.scrollTop : null;
  c.innerHTML = pkPuntoHtml(); c.scrollTop = s;
  const sc2 = c.querySelector('.pkc .cal-scroll');
  const h = (typeof CAL_H === 'number') ? CAL_H : 48;
  if (sc2) sc2.scrollTop = (s2 != null && k0 === sc2.getAttribute('data-k')) ? s2 : Math.max(0, (pkMinDaOra(PK_PUNTO.ora) - 60) / 60 * h);
}
function pkPuntoHtml(){
  const r = pkPuntiDomani()[0];
  if (!r && (PK_PUNTO.fase === 'lista' || !PK_PUNTO.voci.length)) return pkListaHtml();
  return pkDomaniHtml();
}
function pkFineNome(){ return PK_PUNTO.rev === 'rv' ? 'la giornata' : 'la revisione'; }
function pkDomaniHtml(){
  const r = pkPuntiDomani()[0] || null;
  const v = pkVoceCorrente(); if (!v) return pkListaHtml();
  const tit = pkTitolo(v.t), inf = PK_INFO.mem[pkNorm(v.t)] || pkInfoLocale(v);
  /* 0.9.403 BUG-284: la durata e' una sola (pkDurCorrente): la stessa nel badge, nella (i) e nel calendario */
  const dur = pkDurCorrente();
  /* 0.9.403 BUG-280: il testo intero, oppure accorciato con "…" e Mostra tutto (mai tagliato a meta' parola) */
  const tv = pkTitoloVis(v.t);
  let em = { ico: '🎯', bg: '#0075E3,#001E44' }; try{ if (typeof stEmojiDi === 'function') em = stEmojiDi(tit) || em; }catch(_){ }
  const pri = { alta: ['alta', 'Priorità alta'], media: ['media', 'Priorità media'], bassa: ['bassa', 'Priorità bassa'] }[inf.pri] || ['media', 'Priorità media'];
  const d0 = pkDomaniBase(), sel = pkMinDaOra(PK_PUNTO.ora);
  const dalle = r ? pkOra(r.inizio) : pkOra(d0 + sel * 60000), alle = r ? pkOra(r.fine) : pkOra(d0 + (sel + dur) * 60000);
  const aiuto = function(k, ico, t){
    const on = PK_PUNTO.coda === k;
    return '<button type="button" class="pkdm-a' + (on ? ' on' : '') + '" onclick="pkDopo(\'' + k + '\')" aria-pressed="' + on + '"><span>' + (String(ico).charAt(0) === '<' ? pkSvg(ico, 26) : '<i class="pkdm-em" style="font-style:normal;font-size:26px;line-height:1">' + ico + '</i>') + '</span>' + t
      + (on ? '<small>Parte quando chiudi ' + pkFineNome() + '</small>' : '') + '</button>';
  };
  const bl = r ? !!pkBlindati()[r.id] : !!PK_PUNTO.blinda;
  return '<div class="pkdm sd-task">'
    + '<small class="stg-eti">' + (r ? 'Prenotato, +1 al nuovo te' : 'Il passo di domani') + '</small>'
    + '<div class="sd-task-img" style="background:linear-gradient(160deg,' + em.bg + ')">' + em.ico + '</div>'
    /* il pannello col gradiente della task, con la (i) dentro: il perche', la priorita' e il tempo */
    + '<div class="pkdm-passo">' + (r ? '<small>Domani alle ' + dalle + '</small>' : '') + '<b>' + pkEsc(tv.tagliato && !PK_PUNTO.titoloTutto ? tv.corto : tv.intero) + '</b>'
    +   (tv.tagliato ? '<button type="button" class="pkdm-tutto" onclick="PK_PUNTO.titoloTutto=!PK_PUNTO.titoloTutto;pkRidisegna()" aria-expanded="' + !!PK_PUNTO.titoloTutto + '">' + (PK_PUNTO.titoloTutto ? 'Mostra meno' : 'Mostra tutto') + '</button>' : '')
    +   '<button type="button" class="pkdm-i' + (PK_PUNTO.infoAperta ? ' on' : '') + '" onclick="pkInfoTocca()" aria-expanded="' + !!PK_PUNTO.infoAperta + '" aria-label="Perché questo passo, quanto conta e quanto dura">i</button></div>'
    + (PK_PUNTO.infoAperta ? pkInfoHtml(v) : '')
    + '<div class="sd-task-badge"><span class="pri ' + pri[0] + '">' + pri[1] + '</span><span class="pkdm-dur">' + pkSvg(PK_ICO.tempo, 15) + pkDurTxt(dur) + '</span></div>'
    + pkCalHtml()
    + '<div class="sd-task-due pkdm-due">' + aiuto('passi', '🧩', 'Scomponilo in passi') + aiuto('video', '🎥', 'Guarda un tutorial')   /* 0.9.391, Andrea: "per Scomponi e Tutorial le emoji di prima, non le icone: il puzzle rende i tanti pezzettini" */ + '</div>'
    + '<button type="button" class="pkd-v pkd-bl' + (bl ? ' on' : '') + '" onclick="pkBlinda()" aria-pressed="' + bl + '"><span>' + pkSvg(PK_ICO.scudo, 22) + '</span><div><b>' + (bl ? 'Il passo è blindato' : 'Blinda il passo') + '</b>'
    +   '<small>Domani dalle ' + dalle + ' alle ' + alle + ' le app che ti distraggono ' + (bl ? 'restano bloccate.' : 'si bloccano da sole.') + '</small></div><i class="pkd-sw" aria-hidden="true"></i></button>'
    + (r
        ? '<button type="button" class="stg-cta pkdm-fine" onclick="stgFoglioChiudi()">Ho finito</button>'
        : '<button type="button" class="cta sd-task-go pkdm-go" onclick="pkPuntoConferma()">Prenoto il punto alle ' + dalle + '</button>'
          + '<p class="pkdm-nota">Prenotarlo vale subito +1 al nuovo te. Se l’ora passa e il passo non è fatto, il punto torna indietro.</p>'
          + (pkPianificaIo() ? '<button type="button" class="stg-link" onclick="PK_PUNTO.fase=\'lista\';pkRidisegna()">Scelgo un altro passo</button>' : '')
          + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>')
    + '</div>';
}
/* QUANDO LO FAI: l'area pieghevole con il calendario.
   0.9.390, Andrea (BUG-121): "c'e' solo la vista giornaliera: manca la vista dei prossimi 3 giorni, settimanale e mensile, l'overview
   che c'e' nel pannello di pianificazione della roadmap, con l'ingranaggio per mostrare solo gli eventi di DreamMap o anche quelli di
   Google Calendar". Dentro c'e' lo STESSO calendario della Mappa (calendario.js: calCorpo con un'istanza, 'passo'): stesse viste
   (Giorno, 3 giorni, Settimana, Mese), stessa rotella, stessi colori. Si apre su domani; in Giorno e 3 giorni un tocco su un orario
   libero di domani sceglie l'ora del passo (pkCalScegli), Settimana e Mese servono a guardare e a spostarsi su un altro giorno.
   L'icona ora e' un calendario vero, ed e' centrata: la regola del sottotitolo (.pkc-testa span) le toglieva il flex. */
function pkCalIstanza(){
  if (typeof CAL === 'undefined' || !CAL.ist) return false;
  const d0 = pkDomaniBase();
  let ist = CAL.ist.passo;
  if (!ist || ist.base !== d0) ist = CAL.ist.passo = { base: d0, vista: 'giorno', giorno: new Date(d0) };
  ist.tocca = pkCalScegli; ist.ridisegna = pkRidisegna;
  ist.mio = function(){
    const sel = pkMinDaOra(PK_PUNTO.ora), dur = PK_PUNTO.durata;
    return { inizio: d0 + sel * 60000, fine: d0 + (sel + dur) * 60000, sopra: !!pkSlotOccupato(sel, dur) };
  };
  return true;
}
/* 0.9.403, Andrea (BUG-283): "Quando lo fai propone prima alcune fasce orarie a pillole; per chi ha Premium le sceglie il Genio in base al
   calendario. C'e' anche Lo scelgo io, che apre il calendario della giornata. Dopo la scelta si vede la giornata a fasce con il passo
   messo nel suo spazio (Confermato, e' qui). E si puo' aggiungere un promemoria: nel calendario di Google, con una notifica o con la
   chiamata dei sogni". Le pillole: per tutti la prima ora libera della mattina, del pomeriggio e della sera; con Premium tre ore scelte
   dal Genio sul calendario (libere con un quarto d'ora di respiro dagli altri impegni, prima le ore in cui di solito porti a termine
   le sessioni di Full Focus). Lo scelgo io apre il calendario di prima (calCorpo). Scelta l'ora, la giornata a fasce; prenotato,
   "Confermato, e' qui". */
const PK_FASCE = [['mattina', '🌅', 'Mattina', 8 * 60, 12 * 60 + 30], ['pomeriggio', '☀️', 'Pomeriggio', 13 * 60, 17 * 60 + 30], ['sera', '🌙', 'Sera', 17 * 60 + 30, 21 * 60 + 30]];
const PK_AVVISO_ID = 403, PK_AVVISO_PRIMA = 10;
function pkPrem(){ try{ return typeof pscPremium === 'function' ? !!pscPremium() : (typeof Premium !== 'undefined' && !!Premium.isPremium()); }catch(_){ return false; } }
function pkFasciaDi(min){ for (let i = PK_FASCE.length - 1; i >= 0; i--) if (min >= PK_FASCE[i][3] - (i ? 0 : 8 * 60)) return PK_FASCE[i]; return PK_FASCE[0]; }
/** Le pillole per tutti: la prima mezz'ora libera di ogni fascia in cui il passo ci sta tutto. [{ min, ico, t }] */
function pkFascePillole(dur){
  const imp = pkImpegniDomani(), out = [];
  PK_FASCE.forEach(function(f){
    for (let m = f[3]; m + dur <= f[4]; m += 30) if (!pkSlotOccupato(m, dur, imp)){ out.push({ min: m, ico: f[1], t: f[2] }); return; }
  });
  return out;
}
/** Le ore in cui di solito porti a termine una sessione di Full Focus (ultimi 60 giorni): { ora: quante } */
function pkOreBuone(){
  const c = {};
  try{ (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){ if (x && x.ok && x.at > Date.now() - 60 * 86400000){ const h = new Date(x.at - (x.spentMs || 0)).getHours(); c[h] = (c[h] || 0) + 1; } }); }catch(_){ }
  return c;
}
/** Le proposte del Genio (Premium): tre ore libere con un quarto d'ora di respiro, distanti almeno un'ora e mezza, le migliori per te. */
function pkProposteGenio(dur){
  const imp = pkImpegniDomani(), buone = pkOreBuone(), cand = [];
  for (let m = 8 * 60; m + dur <= 21 * 60 + 30; m += 30){
    if (pkSlotOccupato(m, dur, imp)) continue;
    const respiro = !pkSlotOccupato(Math.max(0, m - 15), dur + 30, imp);
    const h = Math.floor(m / 60);
    cand.push({ min: m, p: (buone[h] || 0) * 3 + (respiro ? 2 : 0) + (h >= 9 && h <= 11 ? 1 : 0) - m / 10000 });
  }
  cand.sort(function(a, b){ return b.p - a.p; });
  const out = [];
  cand.forEach(function(x){ if (out.length < 3 && out.every(function(y){ return Math.abs(y.min - x.min) >= 90; })) out.push(x); });
  return out.sort(function(a, b){ return a.min - b.min; }).map(function(x){ const f = pkFasciaDi(x.min); return { min: x.min, ico: f[1], t: 'Alle ' + pkOra(pkDomaniBase() + x.min * 60000), s: f[2] }; });   /* due proposte nella stessa fascia: il titolo e' l'ora */
}
function pkPillole(){ return pkPrem() ? pkProposteGenio(PK_PUNTO.durata) : pkFascePillole(PK_PUNTO.durata); }
/** Una pillola toccata: l'ora del passo, e si vede la giornata */
function pkPillola(min){
  min = +min || 0;
  if (pkSlotOccupato(min, PK_PUNTO.durata)){ try{ flVibra(12); }catch(_){ } return; }
  PK_PUNTO.ora = pkHHMMDa(min); PK_PUNTO.oraScelta = true; PK_PUNTO.calIo = false;
  try{ flVibra(8); }catch(_){ }
  pkRidisegna();
}
function pkCalIo(){ PK_PUNTO.calIo = !PK_PUNTO.calIo; try{ flVibra(8); }catch(_){ } pkRidisegna(); }
/** La giornata di domani a fasce, con il passo nel suo spazio. */
function pkGiornataHtml(inizio, fine, tit, ok){
  const d0 = pkDomaniBase();
  const righe = pkImpegniDomani().map(function(e){ return { inizio: e.inizio, fine: e.fine, t: e.t, mio: false }; })
    .filter(function(e){ return !(Math.abs(e.inizio - inizio) < 60000 && Math.abs(e.fine - fine) < 60000); })
    .concat([{ inizio: inizio, fine: fine, t: tit, mio: true }]).sort(function(a, b){ return a.inizio - b.inizio; });
  return '<div class="pkg-g">' + PK_FASCE.map(function(f, i){
    const da = d0 + (i ? f[3] : 0) * 60000, a = d0 + (i < PK_FASCE.length - 1 ? PK_FASCE[i + 1][3] : 24 * 60) * 60000;
    const qui = righe.filter(function(e){ return e.inizio >= da && e.inizio < a; });
    return '<div class="pkg-f"><small class="pkg-fh"><span aria-hidden="true">' + f[1] + '</span>' + f[2] + '</small>'
      + (qui.length ? qui.map(function(e){
          return '<div class="pkg-r' + (e.mio ? ' mio fl-sel' : '') + '"><span class="pkg-o">' + pkOra(e.inizio) + '</span><div><b>' + pkEsc(e.mio ? pkTaglia(e.t, 70) : e.t) + '</b>'
            + (e.mio ? '<small>' + (ok ? 'Confermato, è qui' : 'Il tuo passo va qui') + '</small>' : '') + '</div></div>';
        }).join('') : '<p class="pkg-vuota">Libera</p>') + '</div>';
  }).join('') + '</div>';
}
/* IL PROMEMORIA: tre interruttori, ognuno con il suo verbo. Il calendario di Google c'e' solo se l'app e' gia' collegata (calCollegato,
   calendario.js); la notifica arriva 10 minuti prima (NATIVE.avviso); la chiamata dei sogni e' quella degli appuntamenti con te stesso
   (il campo chiamata dell'evento, dreamcall.js). */
function pkGcalOk(){ try{ return typeof calCollegato === 'function' && !!calCollegato(); }catch(_){ return false; } }
function pkPromBase(){
  let ch = true; try{ if (typeof calChiamataGlobale === 'function') ch = !!calChiamataGlobale(); }catch(_){ }
  return { gcal: pkGcalOk(), notifica: true, chiamata: ch };
}
function pkPromDi(r){ return (r && r.prom) ? Object.assign(pkPromBase(), r.prom) : (PK_PUNTO.prom || pkPromBase()); }
function pkPromHtml(r){
  const p = pkPromDi(r);
  const sw = function(k, on, t, s){
    return '<div class="blk-swrow pkr-r"><div><b>' + t + '</b><small>' + s + '</small></div>'
      + '<button type="button" class="switch' + (on ? ' on' : '') + '" role="switch" aria-checked="' + on + '" aria-label="' + t + '" onclick="pkPromTocca(\'' + k + '\')"></button></div>';
  };
  return '<div class="pkr"><small class="pkr-h">Il promemoria</small>'
    + (pkGcalOk() ? sw('gcal', p.gcal, 'Scrivilo nel calendario di Google', 'Lo vedi anche nel calendario del telefono.') : '')
    + sw('notifica', p.notifica, 'Mandami una notifica', PK_AVVISO_PRIMA + ' minuti prima dell’inizio.')
    + sw('chiamata', p.chiamata, 'Fammi chiamare dal mio sogno', 'All’ora del passo squilla la chiamata dei sogni.')
    + '</div>';
}
/** L'evento del calendario di un punto, salvato con o senza la copia nel calendario di Google. */
function pkEvSalva(ev, gcal){
  if (typeof calSalvaEvento !== 'function') return null;
  if (gcal || !pkGcalOk() || typeof calNorm !== 'function' || typeof calEventi !== 'function' || typeof calScriviTutti !== 'function') return calSalvaEvento(ev);
  const l = calEventi(), i = ev.id ? l.findIndex(function(x){ return x.id === ev.id; }) : -1;
  const n = calNorm(ev, i >= 0 ? l[i] : null);
  if (i >= 0) l[i] = n; else l.push(n);
  calScriviTutti(l);
  try{ if (typeof calAvvisa === 'function') calAvvisa(n, 'salva'); }catch(_){ }
  return n;
}
function pkAvviso(r, on){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE) return;
    if (!on || !r){ if (NATIVE.avvisoAnnulla) NATIVE.avvisoAnnulla({ id: PK_AVVISO_ID }); return; }
    const at = r.inizio - PK_AVVISO_PRIMA * 60000;
    if (NATIVE.avviso && at > Date.now()) NATIVE.avviso({ id: PK_AVVISO_ID, at: at, titolo: 'Fra ' + PK_AVVISO_PRIMA + ' minuti il tuo passo', testo: pkTaglia(pkTitolo(r.testo), 120), apri: 'mappa' });
  }catch(_){ }
}
/** Mette in pratica il promemoria di un punto gia' prenotato. */
function pkPromApplica(r){
  if (!r) return;
  const p = pkPromDi(r);
  let ev = null; try{ ev = (typeof calEventi === 'function' && r.evId) ? calEventi().filter(function(x){ return x.id === r.evId; })[0] : null; }catch(_){ ev = null; }
  if (ev){
    const era = !!(ev.gcal && ev.gcal.eventId != null);
    const n = pkEvSalva(Object.assign({}, ev, { chiamata: !!p.chiamata }), !!p.gcal);
    try{ if (!p.gcal && era && typeof calTelefonoTogli === 'function') calTelefonoTogli(n || ev); }catch(_){ }
  }
  pkAvviso(r, !!p.notifica);
}
function pkPromTocca(k){
  const r = pkPuntiDomani()[0] || null;
  const p = pkPromDi(r); p[k] = !p[k];
  try{ flVibra(8); }catch(_){ }
  if (r){ const l = pkLista(); const x = l.filter(function(y){ return y.id === r.id; })[0]; if (x){ x.prom = p; pkSalva(l); pkPromApplica(x); } }
  else PK_PUNTO.prom = p;
  pkRidisegna();
}
function pkCalHtml(){
  const r = pkPuntiDomani()[0] || null;
  const imp = pkImpegniDomani(), d0 = pkDomaniBase();
  const sel = pkMinDaOra(PK_PUNTO.ora), dur = PK_PUNTO.durata;
  const occ = pkSlotOccupato(sel, dur, imp);
  const n = imp.length;
  const inizio = r ? r.inizio : d0 + sel * 60000, fine = r ? r.fine : d0 + (sel + dur) * 60000;
  const sotto = r ? 'Confermato. Qui scegli il promemoria.' : (n ? (n === 1 ? 'Un impegno' : n + ' impegni') + ' in calendario. Scegli un’ora libera.' : 'Domani il calendario è libero.');
  let h = '<div class="pkc' + (PK_PUNTO.calAperto ? ' on' : '') + '">'
    + '<button type="button" class="pkc-testa" onclick="pkCalApri()" aria-expanded="' + !!PK_PUNTO.calAperto + '"><span class="pkc-ico">' + pkSvg(PK_ICO.cal, 24) + '</span>'
    + '<div class="pkc-tx"><small>Quando lo fai</small><b>Domani alle ' + pkOra(inizio) + '</b><span>' + sotto + '</span></div>'
    + '<i class="pkc-chev">' + pkSvg(PK_ICO.giu, 20) + '</i></button>';
  if (!PK_PUNTO.calAperto) return h + '</div>';
  h += '<div class="pkc-corpo">';
  if (!r){
    const pil = pkPillole(), prem = pkPrem();
    h += '<p class="pkc-p">' + (prem ? 'Il Genio ha guardato il tuo calendario di domani. Ti propone queste ore.' : 'Scegli quando ti va meglio. Il passo dura ' + pkDurTxt(dur) + '.') + '</p>'
      + '<div class="pkc-pills" role="group" aria-label="Quando lo fai">'
      + pil.map(function(x){ const on = PK_PUNTO.oraScelta && !PK_PUNTO.calIo && x.min === sel;
          return '<button type="button" class="pkc-pill' + (on ? ' on fl-sel' : '') + '" aria-pressed="' + on + '" onclick="pkPillola(' + x.min + ')"><span aria-hidden="true">' + x.ico + '</span><b>' + x.t + '</b><small>' + (x.s || 'alle ' + pkOra(d0 + x.min * 60000)) + '</small></button>'; }).join('')
      + '<button type="button" class="pkc-pill pkc-io' + (PK_PUNTO.calIo ? ' on fl-sel' : '') + '" aria-pressed="' + !!PK_PUNTO.calIo + '" onclick="pkCalIo()"><span aria-hidden="true">📅</span><b>Lo scelgo io</b><small>dal calendario</small></button>'
      + '</div>';
    if (PK_PUNTO.calIo && typeof calCorpo === 'function' && pkCalIstanza()){
      h += '<p class="pkc-p">Tocca un’ora libera di domani. Il passo dura ' + pkDurTxt(dur) + '.</p>' + calCorpo({ ist: 'passo' })
        + (occ ? '<p class="pkc-avv">A quest’ora hai già un impegno:<br>' + pkEsc(occ.t) + '.</p>' : '');
    }
  }
  if (r || PK_PUNTO.oraScelta) h += pkGiornataHtml(inizio, fine, pkTitolo(r ? r.testo : (pkVoceCorrente() || {}).t), !!r);
  h += pkPromHtml(r) + '</div>';
  return h + '</div>';
}
function pkCalApri(){
  PK_PUNTO.calAperto = !PK_PUNTO.calAperto; try{ flVibra(8); }catch(_){ }
  pkRidisegna();
}
/** Un tocco su un orario vuoto del calendario del popover (calToccaVuoto di calendario.js): ms e' l'inizio della mezz'ora toccata. */
function pkCalScegli(ms){
  const d0 = pkDomaniBase();
  if (!(ms >= d0 && ms < d0 + 86400000)){
    try{ flVibra(12); }catch(_){ }
    if (typeof toast === 'function') toast('Il passo è per domani. Scegli un’ora di domani.');
    return;
  }
  let min = Math.round((ms - d0) / 60000);
  min = Math.max(0, Math.min(24 * 60 - PK_PUNTO.durata, min));
  const occ = pkSlotOccupato(min, PK_PUNTO.durata);
  if (occ){ try{ flVibra(12); }catch(_){ } if (typeof toast === 'function') toast('A quell’ora c’è già: ' + occ.t); return; }
  PK_PUNTO.ora = pkHHMMDa(min); PK_PUNTO.oraScelta = true;
  try{ flVibra(8); }catch(_){ }
  pkRidisegna();
}
/* LA (i): IL PERCHE', LA PRIORITA' E IL TEMPO. Li chiede al tuo agente personale (cvAgenteBreve, conversa.js); se l'agente non c'e'
   o non risponde (0.9.387, BUG-097: in ogni caso un ripiego), li scrive DreamMap da quello che sa del passo. */
function pkInfoLocale(v){
  const nomi = { oggi: 'oggi', settimana: 'questa settimana', mese: 'questo mese', anno: 'quest’anno' };
  let perche = '';
  try{ if (v && v.k && typeof ozAnello === 'function'){ const a = ozAnello(v.k); if (a && a.testo) perche = 'Ti porta al traguardo di ' + (nomi[v.k] || 'questo periodo') + ':\n' + pkTitolo(a.testo).replace(/[.\s]+$/, '') + '.'; } }catch(_){ }
  if (!perche){
    let s = ''; try{ s = (typeof nvSogno === 'function') ? String(nvSogno() || '').trim() : ''; }catch(_){ s = ''; }
    perche = s ? 'È il prossimo passo del percorso verso il tuo sogno:\n' + s.replace(/[.\s]+$/, '') + '.' : 'È il prossimo passo del tuo percorso. Farlo domani tiene la strada aperta.';
  }
  const alta = !!(v && (v.k || v.fonte === 'roadmap' || v.fonte === 'prenotato' || v.fonte === 'scelto'));
  const dalPasso = !!(v && (v.min || pkMinDi(v.t)));
  return { perche: perche, pri: alta ? 'alta' : 'media',
    priM: alta ? 'Viene prima delle altre cose. Senza questo passo il percorso si ferma.' : 'È utile, ma senza questo passo il percorso va avanti lo stesso.',
    min: pkDurataDi(v), minM: dalPasso ? 'È il tempo scritto nel passo del percorso.' : 'È il tempo di un blocco di lavoro profondo. Se finisci prima, meglio.', agente: false };
}
/* 0.9.403, Andrea (BUG-284): "il Perche' contiene anche Priorita': alta... e Tempo: 20 minuti..., che poi si ripetono sotto". L'agente a
   volte scrive tutto su una riga: la riga del perche' si portava dietro le altre due. Adesso il testo si divide sulle etichette, dovunque
   stiano (Perché:, Priorità:, Tempo:, Categoria:), e ogni sezione dice una cosa sola. I minuti restano quelli detti (20, non 15). */
const PK_CATS = ['sito', 'scrittura', 'video', 'studio', 'chiamata', 'riunione', 'vendita', 'email', 'design', 'marketing', 'sport', 'casa', 'mente'];
function pkInfoParti(testo){
  const s = String(testo || '').replace(/\*\*/g, '').replace(/\r/g, '');
  const re = /(^|[\s.;,–—-])(perch[eé]|priorit[aà]|tempo(?:\s+stimato)?|categoria)\s*:/gi;
  const pos = []; let m;
  while ((m = re.exec(s))){ const k = m[2].toLowerCase().charAt(0) === 'p' ? (/^perch/i.test(m[2]) ? 'perche' : 'priorita') : (/^tempo/i.test(m[2]) ? 'tempo' : 'categoria'); pos.push({ k: k, i: m.index + m[1].length, j: re.lastIndex }); }
  const out = {};
  pos.forEach(function(p, n){ const fine = n + 1 < pos.length ? pos[n + 1].i : s.length; if (out[p.k] == null) out[p.k] = s.slice(p.j, fine).replace(/^[\s:]+/, '').replace(/[\s,;–—-]+$/, '').trim(); });
  return out;
}
function pkInfoLeggi(testo, loc){
  const x = pkInfoParti(testo);
  if (!x.perche) return Object.assign({}, loc, { errore: 'altro' });
  const su = function(t){ t = String(t || '').trim(); return t ? t.charAt(0).toUpperCase() + t.slice(1) : ''; };
  const q = /^(alta|media|bassa)\b[\s,.;:–—-]*([\s\S]*)$/i.exec(x.priorita || '');
  const t = /^(?:circa\s*|più o meno\s*)?(\d{1,3})\s*(min[a-z]*|or[ae])\b[\s,.;:–—-]*([\s\S]*)$/i.exec(x.tempo || '');
  const min = t ? (/^or/i.test(t[2]) ? +t[1] * 60 : +t[1]) : 0;
  const cat = String(x.categoria || '').toLowerCase().replace(/[^a-zàèéìòù]/g, ' ').trim().split(/\s+/)[0] || '';
  return { perche: su(x.perche), pri: q ? q[1].toLowerCase() : loc.pri, priM: (q && su(q[2])) || loc.priM,
    min: min ? pkArrotonda(min) : loc.min, minM: (t && su(t[3])) || loc.minM, cat: PK_CATS.indexOf(cat) >= 0 ? cat : '', agente: true };
}
function pkInfoChiedi(v){
  const n = pkNorm(v.t); if (PK_INFO.attesa[n]) return;
  const loc = pkInfoLocale(v);
  if (typeof cvAgenteBreve !== 'function'){ PK_INFO.mem[n] = loc; return; }
  PK_INFO.attesa[n] = true;
  /* 0.9.390 (BUG-122), Andrea: "Guarda quali prodotti hanno venduto di più, 45 minuti: non ci vogliono 45 minuti". Il passo di serie
     diceva 15 minuti e l'agente, che non lo sapeva, ne ha detti 45: adesso riceve il tempo scritto nel passo, e la regola sul server
     (evento passo_domani) gli chiede il tempo vero del compito */
  const minPasso = +(v.min || pkMinDi(v.t)) || 0;
  /* 0.9.403 (BUG-284, BUG-282): quattro righe separate, un tempo solo, e la categoria del lavoro (la sceglie l'agente: l'emoji e il colore) */
  const domanda = 'Domani il mio primo passo è: "' + pkTitolo(v.t) + '".' + (minPasso ? ' Il percorso lo stima in ' + minPasso + ' minuti.' : '') + ' Rispondimi con quattro righe, ognuna sulla sua riga, senza altro testo:\n'
    + 'Perché: perché questo passo conta adesso per il mio sogno, in una frase, senza parlare di priorità né di tempo.\n'
    + 'Priorità: alta, media o bassa, e perché, in una frase.\n'
    + 'Tempo: un numero solo di minuti, quelli che il compito richiede davvero, e perché, in una frase senza altri numeri.\n'
    + 'Categoria: una sola parola fra ' + PK_CATS.join(', ') + '.';
  Promise.resolve(cvAgenteBreve(domanda, 'passo_domani', 30000)).then(function(t){ PK_INFO.mem[n] = pkInfoLeggi(t, loc); }, function(e){
    const tipo = (e && e.code === 'senza-agente') ? '' : ((typeof cvErroreTipo === 'function') ? cvErroreTipo(e) : 'altro');
    PK_INFO.mem[n] = Object.assign({}, loc, { errore: tipo });
  }).then(function(){
    delete PK_INFO.attesa[n];
    const x = PK_INFO.mem[n];
    /* il tempo e la categoria dell'agente valgono ovunque: badge, (i), roadmap, START, mappa */
    if (x && x.agente) pkDatoSalva(v.t, Object.assign({ min: x.min }, x.cat ? { cat: x.cat } : {}));
    const cur = pkVoceCorrente();
    if (!cur || pkNorm(cur.t) !== n) return;
    /* il tempo detto dall'agente vale per il passo da prenotare (l'ora resta, se e' ancora libera) e per quello gia' prenotato */
    const r = pkPuntiDomani()[0];
    if (x && x.agente && !r && x.min !== PK_PUNTO.durata){ PK_PUNTO.durata = x.min; if (pkSlotOccupato(pkMinDaOra(PK_PUNTO.ora), x.min)) PK_PUNTO.ora = pkPrimaOraLibera(x.min); }
    if (x && x.agente && r && r.stato === 'prenotato' && r.inizio > Date.now() && Math.round((r.fine - r.inizio) / 60000) !== x.min) pkPuntoDurata(r, x.min);
    pkRidisegna();
  });
}
/** Un punto gia' prenotato prende la durata nuova: la fine, la scadenza e l'evento del calendario. */
function pkPuntoDurata(r, min){
  const l = pkLista(); const x = l.filter(function(y){ return y.id === r.id; })[0]; if (!x) return;
  x.fine = x.inizio + min * 60000; x.scade = x.fine; pkSalva(l);
  try{ if (x.evId && typeof calEventi === 'function'){ const ev = calEventi().filter(function(e){ return e.id === x.evId; })[0]; if (ev) pkEvSalva(Object.assign({}, ev, { fine: x.fine }), pkPromDi(x).gcal); } }catch(_){ }
}
function pkInfoTocca(){
  PK_PUNTO.infoAperta = !PK_PUNTO.infoAperta; try{ flVibra(8); }catch(_){ }
  const v = pkVoceCorrente();
  if (PK_PUNTO.infoAperta && v && !PK_INFO.mem[pkNorm(v.t)]) pkInfoChiedi(v);
  pkRidisegna();
}
function pkInfoHtml(v){
  const x = PK_INFO.mem[pkNorm(v.t)];
  if (!x) return '<div class="pkdm-info att"><span class="pkdm-pensa" aria-hidden="true"><i></i><i></i><i></i></span><p>Chiedo al tuo agente perché questo passo, quanto conta e quanto dura.</p></div>';
  const priT = { alta: 'Alta', media: 'Media', bassa: 'Bassa' }[x.pri] || 'Media';
  const riga = function(ico, t, p){ return '<div class="pkdm-ir"><span>' + pkSvg(ico, 20) + '</span><div><b>' + t + '</b><p>' + pkEsc(p).replace(/\n/g, '<br>') + '</p></div></div>'; };
  let nota = '';
  /* 0.9.389 (BUG-118): senza accesso le parole vengono da un posto solo (agAccessoTesti, agente.js) */
  if (x.errore === 'accesso') nota = 'Queste righe le scrive DreamMap. ' + ((typeof agAccessoTesti === 'function') ? agAccessoTesti('nota').testo : 'Il tuo agente personale risponde dal server di DreamMap, che ti riconosce dal tuo account Google.');
  else if (x.errore) nota = 'Il tuo agente adesso non risponde. Queste righe le scrive DreamMap.';
  /* 0.9.403 BUG-284: il tempo e' quello del badge (pkDurCorrente), non un secondo numero; nella spiegazione nessun altro numero di minuti */
  const dur = pkDurCorrente();
  const minM = String(x.minM || '').replace(/\b(?:circa\s+)?\d{1,3}\s*minut[io]\b/gi, pkDurTxt(dur));
  /* 0.9.403 BUG-280 (lezione 370): ogni proposta dell'agente si puo' contestare. I pollici sono quelli delle risposte dell'agente
     (drsVoto, dream-storia.js, con il foglio del perche' di agente-voti.js); "Parlane con il tuo agente" apre la chat con il passo e
     il perche' gia' scritti, e l'agente puo' cambiare il passo nel percorso */
  const testoVoto = 'Passo di domani: ' + pkTitolo(v.t) + '\nPerché: ' + x.perche;
  const voto = typeof drsVoto === 'function'
    ? '<div class="pkdm-voto"><p>Ti convince questo passo?</p><div class="drs-at lui">'
      + '<button type="button" class="drs-v" aria-label="Mi piace" onclick="event.stopPropagation();drsVoto(1,' + pkEsc(JSON.stringify(testoVoto)) + ',\'passo\',this)">' + (typeof drsSvg === 'function' ? drsSvg('su') : '👍') + '</button>'
      + '<button type="button" class="drs-v" aria-label="Non mi piace" onclick="event.stopPropagation();drsVoto(-1,' + pkEsc(JSON.stringify(testoVoto)) + ',\'passo\',this)">' + (typeof drsSvg === 'function' ? drsSvg('giu') : '👎') + '</button></div></div>'
    : '';
  const parla = typeof agNuovaConversazione === 'function' ? '<button type="button" class="pkdm-parla" onclick="pkParlane()"><span aria-hidden="true">💬</span>Non sono d’accordo, parlane con il tuo agente</button>' : '';
  return '<div class="pkdm-info">' + riga(PK_ICO.perche, 'Perché', x.perche) + riga(PK_ICO.pri, 'Priorità', priT + '. ' + x.priM) + riga(PK_ICO.tempo, 'Tempo stimato', pkDurTxt(dur) + '. ' + minM)
    + (nota ? '<small class="pkdm-inota">' + nota + '</small>' : '') + voto + parla + '</div>';
}
/** "Non sono d'accordo, parlane con il tuo agente": la chat con il passo e il perche' gia' scritti. Dentro una revisione la revisione si
    ferma qui e si riprende dal passo di domani (come "Trovalo con il tuo agente" del collo). */
function pkParlane(){
  const v = pkVoceCorrente(); if (!v || typeof agNuovaConversazione !== 'function') return;
  const x = PK_INFO.mem[pkNorm(v.t)] || pkInfoLocale(v);
  const testo = 'Come passo di domani mi hai proposto:\n"' + pkTitolo(v.t) + '"\n\nIl perché:\n' + String(x.perche || '').trim()
    + '\n\nNon sono d’accordo. Se ho ragione, cambia il passo nel mio percorso.\nIl motivo:\n';
  try{ if (typeof STG !== 'undefined') STG.dopoChiudi = null; }catch(_){ }
  try{ if (typeof stgFoglioChiudi === 'function') stgFoglioChiudi(); }catch(_){ }
  try{
    if (PK_PUNTO.rev === 'rv' && typeof rvChiudi === 'function'){ if (typeof rvRipSalva === 'function') rvRipSalva(); rvChiudi(); }
    else if (PK_PUNTO.rev === 'rvp' && typeof rvpChiudi === 'function'){ if (typeof rvpRipSalva === 'function') rvpRipSalva(); rvpChiudi(); }
  }catch(_){ }
  delete PK_INFO.mem[pkNorm(v.t)];
  setTimeout(function(){ try{ agNuovaConversazione(testo, { titolo: 'Il passo di domani' }); }catch(_){ } }, 350);
}
/* QUANDO NON C'E' UN PASSO PRONTO, O CHI PIANIFICA DA SE' NE VUOLE UN ALTRO: la lista e il passo scritto a mano */
function pkListaHtml(){
  const voci = PK_PUNTO.voci.map(function(x, i){
    return '<button type="button" class="pkp-voce' + (PK_PUNTO.scelto === i ? ' on' : '') + '" onclick="pkPuntoScegli(' + i + ')"><span class="pkp-r"></span><b>' + pkEsc(pkTitolo(x.t)) + '</b></button>';
  }).join('');
  return '<small class="stg-eti">Prenota il punto</small><h2 class="stg-h">Cosa fai domani, e a che ora?</h2>'
    + '<p class="stg-p">Scegli un passo e mettilo in calendario. Prenotarlo vale subito <b>+1 al nuovo te</b>. Se l’ora passa e il passo non è fatto, il punto torna indietro.</p>'
    + (voci ? '<div class="pkp-voci">' + voci + '</div>' : '')
    + '<label class="stg-q">' + (voci ? 'Oppure scrivi tu il passo' : 'Scrivi il passo di domani') + '</label>'
    + '<input class="stg-in" id="pkpTesto" placeholder="Per esempio: chiamo tre clienti" oninput="pkPuntoScritto(this)">'
    + '<div class="pkp-ora"><label class="stg-q">A che ora</label><input type="time" class="stg-in pkp-time" id="pkpOra" value="' + PK_PUNTO.ora + '"></div>'
    + '<label class="stg-q">Quanto dura</label><div class="stg-chips">' + [[30, 'Mezz’ora'], [60, 'Un’ora'], [90, 'Un’ora e mezza'], [120, 'Due ore']].map(function(d){ return '<button type="button" class="stg-chip' + (PK_PUNTO.durata === d[0] ? ' on' : '') + '" onclick="pkPuntoDurata(' + d[0] + ',this)">' + d[1] + '</button>'; }).join('') + '</div>'
    + '<button type="button" class="stg-cta" onclick="pkPuntoConferma()">Prenoto il punto</button>'
    + (PK_PUNTO.voci.length ? '<button type="button" class="stg-link" onclick="PK_PUNTO.fase=\'passo\';pkRidisegna()">Indietro</button>' : '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>');
}
function pkPuntoScegli(i){
  PK_PUNTO.scelto = i;
  const t = document.getElementById('pkpTesto'); if (t) t.value = '';
  document.querySelectorAll('#stgVelo .pkp-voce').forEach(function(b, k){ b.classList.toggle('on', k === i); });
}
function pkPuntoScritto(el){ if (String(el.value || '').trim()){ PK_PUNTO.scelto = -1; document.querySelectorAll('#stgVelo .pkp-voce').forEach(function(b){ b.classList.remove('on'); }); } }
function pkPuntoDurata(m, btn){ PK_PUNTO.durata = m; document.querySelectorAll('#stgVelo .stg-chips .stg-chip').forEach(function(b){ b.classList.toggle('on', b === btn); }); }
function pkPuntoConferma(){
  const scritto = String((document.getElementById('pkpTesto') || {}).value || '').replace(/\s+/g, ' ').trim();
  /* 0.9.294: un punto al giorno. Gia' prenotato, il popover lo mostra */
  if (pkPuntiDomani().length >= PK_PUNTI_MAX){ pkRidisegna(); return; }
  const voce = scritto ? { t: scritto } : PK_PUNTO.voci[PK_PUNTO.scelto];
  if (!voce || !voce.t){ if (typeof toast === 'function') toast('Scegli un passo o scrivilo tu.'); return; }
  const hm = String((document.getElementById('pkpOra') || {}).value || PK_PUNTO.ora).split(':');
  const h = +hm[0], m = +hm[1];
  if (isNaN(h) || isNaN(m)){ if (typeof toast === 'function') toast('Scegli l’ora.'); return; }
  PK_PUNTO.ora = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  /* 0.9.388: il giorno del punto e' lo stesso del calendario del popover (pkDomaniBase: dopo mezzanotte, finche' non dormi, la mattina che arriva) */
  const d = new Date(pkDomaniBase()); d.setHours(h, m, 0, 0);
  const inizio = d.getTime(), fine = inizio + PK_PUNTO.durata * 60000;
  let ev = null;
  /* 0.9.403 BUG-283: il promemoria scelto (la chiamata dei sogni e il calendario di Google sull'evento, la notifica a parte) */
  const prom = PK_PUNTO.prom || pkPromBase();
  try{ ev = pkEvSalva({ titolo: voce.t, inizio: inizio, fine: fine, colore: '#3F9FF4', chiamata: !!prom.chiamata, descr: 'Punto prenotato in DreamMap. Fallo entro la fine dell’appuntamento e il punto resta al nuovo te.' }, !!prom.gcal); }catch(_){ }
  const r = pkPrenota('punto', voce.t, { k: voce.k || '', j: voce.j != null ? voce.j : -1, evId: ev ? ev.id : '', inizio: inizio, fine: fine, scade: fine, giorno: pkKey(inizio), prom: prom });
  pkAvviso(r, !!prom.notifica);
  /* 0.9.403 BUG-280: il passo prenotato e' il prossimo anche sulla mappa */
  pkFissaNellaMappa(r);
  PK_PUNTO.calAperto = true;
  try{ flVibra([20, 40, 30]); }catch(_){ }
  PK_PUNTO.ultimo = r; PK_PUNTO.fase = 'passo';
  /* Blinda il passo acceso prima di prenotare: il blocco si crea adesso, con l'ora vera */
  if (PK_PUNTO.blinda && !pkBlindati()[r.id]) pkBlinda();
  PK_PUNTO.blinda = false;
  pkRidisegna();
  try{ if (typeof rmpPaint === 'function') rmpPaint(); }catch(_){ }
}
/** 0.9.403 BUG-280: la tappa missione in corso sulla mappa prende il passo prenotato (fl_mis_rm di sentiero-mappa.js lega un passo a
    ogni tappa la prima volta che compare: senza questo restava il passo di prima). Un'altra tappa ancora da fare con lo stesso passo
    lo lascia libero. */
function pkFissaNellaMappa(r){
  try{
    if (!r || !r.testo || typeof sdCorrente !== 'function' || typeof sdMisRm !== 'function') return;
    if (typeof sdStradaMia === 'function' && sdStradaMia()) return;
    const nd = (sdCorrente() || {}).nodo; if (!nd || nd.tipo !== 'mis') return;
    const m = sdMisRm(), k = pkChiave(r.testo);
    if (m[nd.id] && pkChiave(m[nd.id].t) === k) return;
    const dalla = (typeof sdRoadmapPassi === 'function' ? sdRoadmapPassi() : []).filter(function(x){ return pkChiave(x.t) === k; })[0];
    const st = (typeof sdStato === 'function') ? sdStato() : null;
    Object.keys(m).forEach(function(id){
      if (id === nd.id || !m[id] || pkChiave(m[id].t) !== k) return;
      let fatta = false; try{ fatta = !!(st && st.fatti && st.fatti[id]); }catch(_){ fatta = false; }
      if (!fatta) delete m[id];
    });
    m[nd.id] = dalla || { t: pkTitolo(r.testo), s: 'Il passo che hai prenotato.', min: Math.max(5, Math.round((r.fine - r.inizio) / 60000)), k: r.k || '', j: r.j != null ? r.j : -1, rm: true };
    localStorage.setItem('fl_mis_rm', JSON.stringify(m));
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LA PORTA 1: dopo la chiamata dei sogni — il primo passo, prima di sentirsi pronti
   --------------------------------------------------------------------------------------- */
function pkTaskDiOggi(){
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    const tx = one && !one.done && one.task && (one.task.text || one.task);
    if (tx) return String(tx).trim();
  }catch(_){ }
  try{ const m = (typeof stMissione === 'function') ? stMissione() : null; if (m && m.t) return String(m.t).trim(); }catch(_){ }
  return '';
}
function pkDopoChiamata(){
  try{
    if (typeof decOpen !== 'function' || (typeof DEC !== 'undefined' && DEC.open)) return;
    const oggi = pkKey(Date.now());
    if (pkLista().some(function(x){ return x.tipo === 'passo' && x.giorno === oggi; })) return;   // una al giorno
    const task = pkTaskDiOggi();
    if (!task) return;
    PK.task = task;
    decOpen('custom', {
      kicker: 'Il primo passo di oggi',
      /* 0.9.381, Andrea: "il testo del pannello olografico e' troppo lungo, sette righe: una (i) accanto al titolo e il resto in un popover" */
      title: 'PARTI PRIMA<br>DI SENTIRTI <span class="fl-inw">PRONTO <button type="button" class="fl-i pk-i" onclick="event.stopPropagation();pkPassoInfo()" aria-label="Come funziona il punto">i</button></span>',
      line: '"' + pkEsc(task) + '"',
      left: 'NON<br>OGGI', right: 'PRENOTO<br>IL PUNTO',
      leftAct: 'pkPassoNo()', rightAct: 'pkPassoSi()',
      foot: 'Rimandare non costa un punto. Costa un giorno.'
    });
  }catch(_){ }
}
/* 0.9.381, Andrea: "dopo la scelta c'e' un'altra scelta, Piu' tardi o Parto adesso: decision fatigue. Portalo direttamente nel Full Focus:
   con la regola dei due minuti, una volta li' e' molto piu' facile che parta; se vuole, parte piu' tardi" */
function pkPassoSi(){
  pkPrenota('passo', PK.task);
  try{ if (typeof decVote === 'function') decVote('passo', true, 0); }catch(_){ }
  pkPartiAdesso();
}
function pkPassoInfo(){
  if (typeof inSheet !== 'function') return;
  const r = [['✋', 'Non serve sapere come', 'Serve cominciare. Il primo passo si fa anche senza sentirsi pronti.'],
    ['🎯', 'Il punto lo prenoti adesso', 'Lo confermi chiudendo la task in una sessione di Full Focus entro oggi.'],
    ['⚡', 'Vale doppio', 'Se la chiudi entro ' + PK_DOPPIO_MIN + ' minuti.']];
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il primo passo di oggi</h3>' + (typeof flInfoRighe === 'function' ? flInfoRighe(r) : '') + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pkPassoSiVecchio(){
  const r = pkPrenota('passo', PK.task);
  if (typeof decResultCon === 'function') decResultCon(
    'Punto prenotato:<br><b>+1 al nuovo te</b>, sul tabellone da adesso.<br>Hai <b>' + PK_DOPPIO_MIN + ' minuti</b> per farlo valere doppio. Se a fine giornata «' + pkEsc(r.testo) + '» e’ ancora aperta, torna indietro.',
    1, true,
    ['<button type="button" class="dec-opt no" onclick="decClose()">PIÙ TARDI</button>',
     '<button type="button" class="dec-opt yes" onclick="pkPartiAdesso()">PARTI<br>ADESSO</button>'],
    'Prenotato');
}
function pkPassoNo(){
  try{ if (typeof decVote === 'function') decVote('passo', false, 0); }catch(_){ }
  if (typeof decClose === 'function') decClose();
}
/** Parte la sessione FullFocus su quella task, intensiva: e' cosi' che il punto si conferma. */
function pkPartiAdesso(){
  if (typeof decClose === 'function') decClose();
  try{
    if (typeof ffPref === 'function'){
      const p = ffPref(); p.intent = PK.task; p.intensive = true;
      if (typeof ffSavePref === 'function') ffSavePref();
    }
    if (typeof stSaltaSync === 'function') stSaltaSync();
    if (typeof ffOpen === 'function') ffOpen();
  }catch(_){ }
}
/* ---------------------------------------------------------------------------------------
   LA PORTA 2: le decisioni del tuo agente personale, con il conto alla rovescia che sparisce
   --------------------------------------------------------------------------------------- */
function pkDecMin(){
  try{ const c = (typeof mgCfg === 'function') ? mgCfg() : {}; const n = parseFloat(c.decMin); return n > 0 ? n : 1; }catch(_){ return 1; }
}
function pkRisposte(){ return pkLeggi(PK_RISP_KEY, []) || []; }
/** Le decisioni che l'agente ha depositato e a cui non ho ancora risposto (tre giorni al massimo). */
function pkDecisioniPendenti(){
  let v = null;
  try{ v = (typeof jdCache === 'function') ? (jdCache() || {}).verdetto : null; }catch(_){ }
  if (!v || !Array.isArray(v.decisioni)) return [];
  /* 0.9.278, Andrea: "Domani apri prima Claude per il tool o la telecamera per l'UGC? Io non devo fare nessun video".
     Le decisioni arrivavano da Jordan, l'agente sul VPS, che vede solo i numeri della giornata e non quello che sa il
     Genio. Nell'app si mostrano solo le decisioni scritte dal tuo agente personale (fonte "agente"), che conosce il tuo percorso. */
  if (!v.decisioni.some(function(d){ return d && d.fonte === 'agente'; })) return [];
  const risposte = {}; pkRisposte().forEach(function(r){ risposte[r.id] = 1; });
  const vecchio = (v.at || 0) < Date.now() - 3 * 86400000;
  return v.decisioni.filter(function(d){
    if (!(d && d.id && d.domanda && d.a && d.b && !risposte[d.id] && !vecchio)) return false;
    /* UNA DECISIONE CHE NOMINA UN'APP PRODUTTIVA NON SI MOSTRA. «Domani blocchi Claude Code»
       e' arrivata davvero: l'agente vedeva l'app in cima al tempo del computer. Il filtro sta
       qui perche' e' l'app a sapere cosa e' produttivo, e a decidere cosa mostrare. */
    /* «SILENZI CLAUDE CODE» (1/10): il filtro guardava solo blocca/limita/rinuncia/chiudi/spegni,
       e «silenzia» passava. Adesso basta che la decisione nomini un'app produttiva o neutra
       insieme a QUALSIASI verbo che la tolga di mezzo. */
    try{ const tx = d.domanda + ' ' + d.a + ' ' + d.b; if (typeof jdNominaProtetta === 'function' && /blocc|limit|rinunc|chiud|spegn|silenz|mut[ao]|ferm|paus|stop|riduc|tagli|rinvi|evit|lasci|senza|niente|proibi|viet/i.test(tx) && jdNominaProtetta(tx)) return false; }catch(_){ }
    return true;
  });
}
function pkDecisioneApri(d){
  if (typeof decOpen !== 'function' || (typeof DEC !== 'undefined' && DEC.open)) return;
  PK.dec = d;
  PK.scadeAt = Date.now() + pkDecMin() * 60000;
  decOpen('custom', {
    kicker: d.kicker || 'Il tuo agente personale ti chiede',
    title: 'DECIDI ADESSO',
    line: pkEsc(d.domanda),
    left: pkEsc(d.a), right: pkEsc(d.b), leftClass: 'yes',
    leftAct: 'pkRisposta(\'a\')', rightAct: 'pkRisposta(\'b\')',
    extra: '<div class="dec-timer" id="pkTimer">' + pkMmSs(PK.scadeAt - Date.now()) + '</div>',
    foot: ''
  });
  pkTimerAvvia();
}
function pkMmSs(ms){ const s = Math.max(0, Math.ceil(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
/* Il conto alla rovescia si vede tre secondi — il tempo di capire che c'e' — poi sparisce:
   sotto pressione non si decide, si scappa. Torna solo quando e' scaduto. */
function pkTimerAvvia(){
  clearInterval(PK.timer);
  const t0 = Date.now();
  PK.timer = setInterval(function(){
    const el = (typeof document !== 'undefined') ? document.getElementById('pkTimer') : null;
    if (!el || (typeof DEC !== 'undefined' && !DEC.open)){ clearInterval(PK.timer); return; }
    const resta = PK.scadeAt - Date.now();
    if (resta <= 0){ el.textContent = 'TEMPO SCADUTO'; el.classList.add('scaduto'); el.classList.remove('via'); clearInterval(PK.timer); return; }
    el.textContent = pkMmSs(resta);
    if (Date.now() - t0 > PK_TIMER_VISTA_MS) el.classList.add('via');
  }, 250);
}
function pkRisposta(k){
  const d = PK.dec; if (!d) return;
  clearInterval(PK.timer);
  const adesso = Date.now();
  const inTempo = adesso <= PK.scadeAt;
  const secondi = Math.max(1, Math.round((adesso - (PK.scadeAt - pkDecMin() * 60000)) / 1000));
  const scelta = k === 'a' ? d.a : d.b;
  const l = pkRisposte();
  l.push({ id: d.id, scelta: k, testo: scelta, domanda: d.domanda, at: adesso, inTempo: inTempo, secondi: secondi });
  pkScrivi(PK_RISP_KEY, l.slice(-100));
  let r = null;
  if (inTempo) r = pkPrenota('decisione', d.domanda, { decId: d.id, scelta: scelta }, adesso);
  if (typeof decResultCon === 'function') decResultCon(
    inTempo
      ? 'Deciso in <b>' + secondi + ' secondi</b>: <b>' + pkEsc(scelta) + '</b>.<br>+1 al nuovo te, prenotato:<br>lo tieni se la decisione la mantieni. Se torni indietro, torna indietro anche lui.'
      : 'Deciso: <b>' + pkEsc(scelta) + '</b>. Fuori tempo, nessun punto. La decisione però e’ presa:<br>adesso tienila.',
    inTempo ? 1 : null, true,
    ['<button type="button" class="dec-opt yes" onclick="decClose()">VADO</button>'],
    inTempo ? 'Prenotato' : 'Registrato');
  PK.dec = null;
  try{ if (typeof jdDeposita === 'function') jdDeposita(true); }catch(_){ }
}
/** Il verdetto dell'agente: le revoche (decisione non mantenuta) e le nuove decisioni. */
function pkDaVerdetto(v){
  if (!v) return;
  try{
    (Array.isArray(v.revoche) ? v.revoche : []).forEach(function(x){
      if (!x || !x.id) return;
      const r = pkLista().filter(function(p){ return p.decId === x.id && p.stato === 'prenotato'; })[0];
      if (r) pkRevoca(r.id, 'Decisione non mantenuta: ' + (x.motivo || 'sei tornato indietro'));
    });
  }catch(_){ }
  const pend = pkDecisioniPendenti();
  if (pend.length && !PK.mostrata[pend[0].id]){ PK.mostrata[pend[0].id] = 1; setTimeout(function(){ pkDecisioneApri(pend[0]); }, 800); }
}
/** Quello che va depositato per l'agente: le prenotazioni recenti e le risposte date. */
function pkPerAgente(){
  const da = Date.now() - 7 * 86400000;
  return {
    prenotazioni: pkLista().filter(function(x){ return x.at >= da; }).map(function(x){
      return { id: x.id, tipo: x.tipo, testo: x.testo, stato: x.stato, at: x.at, punti: x.punti, decId: x.decId || '', scelta: x.scelta || '', motivo: x.motivo || '' };
    }),
    decisioniRisposte: pkRisposte().filter(function(x){ return x.at >= da; })
  };
}

/* ---------------------------------------------------------------------------------------
   I GANCI
   --------------------------------------------------------------------------------------- */
if (typeof document !== 'undefined'){
  /* la riga spuntata con la prova (sessione vista) conferma la prenotazione con quel testo */
  document.addEventListener('fl:spunta', function(){
    try{
      const oggi = pkKey();
      const done = (pkLeggi('fl_notes_done', []) || []).filter(function(x){ return x && x.day === oggi && x.verified; });
      pkAperte('passo').forEach(function(r){
        const d = done.filter(function(x){ return pkNorm(x.text) === pkNorm(r.testo); })[0];
        if (d) pkConferma(r.id, d.at || Date.now());
      });
    }catch(_){ }
  });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) pkControlla(); });
  setTimeout(pkControlla, 2500);
  setInterval(pkControlla, 10 * 60000);
  /* le decisioni in sospeso si presentano quando si apre una scheda, mai da sole */
  document.addEventListener('fl:tab', function(e){
    if (['blocco', 'severa', 'sveglia'].indexOf(e.detail) < 0) return;
    setTimeout(function(){
      const pend = pkDecisioniPendenti();
      if (pend.length && !PK.mostrata[pend[0].id]){ PK.mostrata[pend[0].id] = 1; pkDecisioneApri(pend[0]); }
    }, 2200);
  });
  document.addEventListener('DOMContentLoaded', function(){
    if (typeof jdLeggi === 'function' && !jdLeggi.__pk){
      const orig = jdLeggi;
      const w = async function(f){ const v = await orig(f); try{ pkDaVerdetto(v); }catch(_){ } return v; };
      w.__pk = true; w.__rev = orig.__rev; jdLeggi = w;
    }
  });

  (function pkStile(){
    const st = document.createElement('style');
    st.textContent = [
      '.dec-sub{display:block;margin-top:6px;font:500 12.5px/1.5 var(--font-body);color:rgba(226,243,255,.62)}',
      '.dec-timer{margin-top:16px;font:800 30px/1 var(--font-display);font-style:italic;letter-spacing:.06em;color:#EAF6FF;text-shadow:0 0 18px rgba(90,200,255,.7);transition:opacity .6s ease}',
      '.dec-timer.via{opacity:0}',
      '.dec-timer.scaduto{font-size:16px;letter-spacing:.2em;color:#FF9AA2;text-shadow:0 0 18px rgba(240,80,110,.5)}',
      '.pz-r.revoca i{filter:grayscale(1);opacity:.6}',
      '.pkp-voci{display:grid;gap:8px;margin:4px 0 6px}',
      /* 0.9.388, Andrea (BUG-114): "il riquadro GIA' PRENOTATI PER DOMANI ha il testo bianco su un pannello azzurro chiaro: illeggibile".
         Questi stili erano nati per un foglio scuro; il foglio (stagione.js, .stg-f) e' bianco. Testo scuro su fondo chiaro, e il
         riquadro del gia' prenotato col gradiente del brand come le altre card (stg-ob) */
      '.pkp-voce{display:flex;align-items:center;gap:12px;width:100%;padding:14px;border-radius:14px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#FFFFFF);color:var(--navy,#001E44);text-align:left}',
      '.pkp-voce b{flex:1;font:700 15.5px/1.4 var(--font-body)}',
      '.pkp-r{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid #9DB3CF}',
      '.pkp-voce.on{border-color:#0075E3;background:#EEF6FF}.pkp-voce.on .pkp-r{border-color:#0075E3;box-shadow:inset 0 0 0 4px #FFFFFF;background:#0075E3}',
      'body.dark .pkp-voce{background:#12203A;border-color:#22345A;color:#FFFFFF}body.dark .pkp-voce.on{background:#16305A;border-color:#8CC6FF}body.dark .pkp-voce.on .pkp-r{border-color:#8CC6FF;box-shadow:inset 0 0 0 4px #12203A;background:#8CC6FF}',
      '.pkp-gia{padding:14px 16px;border-radius:16px;background:var(--dream);margin:0 0 14px;text-align:left}.pkp-gia small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#005BB0}.pkp-gia p{margin:4px 0 0;font:700 15.5px/1.4 var(--font-body);color:#0E2350}',
      '.pkp-time{max-width:180px}',
      '.pkg{display:flex;flex-direction:column;padding-top:6px}.pkg .stg-h{margin:10px 0 24px}',
      '.pkg-passo{padding:22px 18px;border-radius:20px;background:var(--dream);color:#0E2350;margin:0 0 32px}.pkg-passo b{display:block;font:800 19px/1.4 var(--font-display,var(--font-body))}',
      '.pkg-sotto{margin:-10px 0 24px;font:600 15px/1.45 var(--font-body);color:var(--muted,#4A5A72)}',
      '.pkg-ore{gap:10px;margin:0 0 32px}.pkg .stg-cta{margin-top:0}.pkg .stg-link{margin-top:10px}',
      '.rmp-prenota{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:4px 8px;width:100%;margin-top:12px;padding:14px;border:0;border-radius:14px;background:#0075E3;color:#FFFFFF;font:800 16px var(--font-body)}',
      '.rmp-prenota small{flex-basis:100%;text-align:center;font:600 13px var(--font-body);opacity:.85}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { pkPrenota: pkPrenota, pkConferma: pkConferma, pkRevoca: pkRevoca, pkConfermaTask: pkConfermaTask,
                     pkControlla: pkControlla, pkLista: pkLista, pkAperte: pkAperte, pkDaVerdetto: pkDaVerdetto,
                     pkDecisioniPendenti: pkDecisioniPendenti, pkRisposta: pkRisposta, PK: PK, PK_DOPPIO_MIN: PK_DOPPIO_MIN,
                     pkPuntiControlla: pkPuntiControlla, pkPuntoFatto: pkPuntoFatto };
}

/* ===========================================================================================
   0.9.344 — DOPO LA PRENOTAZIONE: PREPARARSI E BLINDARE
   Andrea: "prenotando il punto non c'e' modo di vedere il tutorial di quel passo o di farlo scomporre. E mi e' capitato di
   prenotare e perdermi lo stesso: servono le sponde del bowling, che rendono impossibile uscire dalla pista". Dopo "Prenoto il
   punto" il foglio propone quattro cose: i passi, il tutorial, parlarne con l'agente, e blindare il passo (domani, in quell'ora,
   le app che distraggono si bloccano da sole; il blocco sparisce quando l'ora e' passata).
   =========================================================================================== */
function pkBlindati(){ return pkLeggi('fl_blinda', {}) || {}; }
function pkHHMM(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
/* 0.9.388 (BUG-112): dopo la prenotazione resta lo stesso popover del passo di domani (pkDomaniHtml), con l'ora e le tre azioni */
function pkDopoHtml(r){ void r; return pkDomaniHtml(); }
function pkAppDistraggono(){
  const out = {};
  try{ (typeof APPS_CACHE !== 'undefined' ? APPS_CACHE : []).forEach(function(a){ if (a && a.packageName && typeof scIsDistracting === 'function' && scIsDistracting(a.packageName)) out[a.packageName] = 1; }); }catch(_){ }
  try{ if (!Object.keys(out).length && typeof SC_DEFAULT_DISTRACT !== 'undefined') SC_DEFAULT_DISTRACT.forEach(function(p){ out[p] = 1; }); }catch(_){ }
  try{ const c = (typeof insCats === 'function') ? insCats() : {}; Object.keys(c).forEach(function(p){ if (c[p] === 'distr') out[p] = 1; }); }catch(_){ }
  try{ if (typeof QUICK !== 'undefined') (QUICK.apps || []).forEach(function(p){ out[p] = 1; }); }catch(_){ }
  delete out['com.dreambrothers.dreammap'];
  return Object.keys(out);
}
function pkProgrammaTogli(pid){
  try{
    if (typeof PROGRAMS === 'undefined') return;
    const i = PROGRAMS.findIndex(function(x){ return x.id === pid; }); if (i < 0) return;
    PROGRAMS.splice(i, 1); saveProgramsLocal();
    try{ renderPrograms(); }catch(_){ } try{ pushRules(); }catch(_){ } try{ syncNative(); }catch(_){ }
  }catch(_){ }
}
function pkBlinda(){
  const r = PK_PUNTO.ultimo;
  /* 0.9.388 (BUG-112): Blinda si puo' accendere anche prima di prenotare; il blocco si crea quando prenoti (pkPuntoConferma) */
  if (!r){ PK_PUNTO.blinda = !PK_PUNTO.blinda; try{ flVibra(PK_PUNTO.blinda ? [14, 40, 14] : 10); }catch(_){ } pkRidisegna(); return; }
  const m = pkBlindati();
  if (m[r.id]){ pkProgrammaTogli(m[r.id].pid); delete m[r.id]; pkScrivi('fl_blinda', m); try{ flVibra(10); }catch(_){ } }
  else {
    const app = pkAppDistraggono();
    if (!app.length || typeof frProgrammaDaAgente !== 'function'){ if (typeof toast === 'function') toast('Non trovo app da bloccare. Nel Report segna quali app ti distraggono, poi riprova.'); return; }
    const giorni = [false, false, false, false, false, false, false]; giorni[(new Date(r.inizio).getDay() + 6) % 7] = true;
    const pid = frProgrammaDaAgente({ nome: 'Passo blindato', app: app, dalle: pkHHMM(r.inizio), alle: pkHHMM(r.fine), giorni: giorni, zitto: true }, false);
    if (!pid){ if (typeof toast === 'function') toast('Il blocco non si è creato:\nriprova fra un attimo.'); return; }
    try{ const p = PROGRAMS.filter(function(x){ return x.id === pid; })[0]; if (p){ p.icon = '🛡️'; p.blindato = r.id; saveProgramsLocal(); try{ renderPrograms(); }catch(_){ } } }catch(_){ }
    m[r.id] = { pid: pid, fine: r.fine }; pkScrivi('fl_blinda', m);
    try{ flVibra([14, 40, 14]); }catch(_){ }
  }
  pkRidisegna();
}
/* un passo blindato dura solo la sua ora: passata quella, il blocco si toglie da solo */
function pkBlindaPulisci(){
  try{
    const m = pkBlindati(); let cambiato = false;
    Object.keys(m).forEach(function(id){ if (m[id] && m[id].fine && Date.now() > m[id].fine + 60000){ pkProgrammaTogli(m[id].pid); delete m[id]; cambiato = true; } });
    if (cambiato) pkScrivi('fl_blinda', m);
  }catch(_){ }
}
setTimeout(pkBlindaPulisci, 9000); setInterval(pkBlindaPulisci, 5 * 60000);
function pkDopo(tipo){
  const v = pkVoceCorrente(); if (!v) return;
  const r = pkPuntiDomani()[0] || null, t = pkTitolo(v.t);
  /* 0.9.388 (BUG-112): dentro una revisione la richiesta aspetta la fine (0.9.340: "mi ha portato al tutorial e la revisione era
     finita"). Si segna sul pulsante, e parte quando chiudi la revisione */
  if (PK_PUNTO.rev && (tipo === 'passi' || tipo === 'video')){ PK_PUNTO.coda = PK_PUNTO.coda === tipo ? '' : tipo; try{ flVibra(8); }catch(_){ } pkRidisegna(); return; }
  const via = function(){ pkAiutoVia(tipo, t, r); };
  try{ stgFoglioChiudi(); }catch(_){ }
  /* dentro una revisione: prima la revisione si chiude con la sua schermata di fine, poi parte la richiesta */
  if (typeof rvfInRevisione === 'function' && rvfInRevisione()){ RVF.dopo = via; rvfChiudiRevisione(); }
  else setTimeout(via, 280);
}
/** Scomponilo in passi, Guarda un tutorial (il messaggio parte da solo: 0.9.347) e la domanda (resta nel campo). Li usano il popover
    del passo di domani e la fine delle revisioni (rvDomaniAzione). r: la prenotazione, se c'e'. */
function pkAiutoVia(tipo, t, r){
  t = String(t || '');
  if (tipo === 'chat'){
    if (typeof agApri === 'function'){ agApri(); setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza((r ? 'Domani alle ' + pkOra(r.inizio) : 'Domani') + ' faccio questa cosa: "' + t + '". Da dove mi conviene partire?'); }catch(_){ } }, 400); }
    return;
  }
  const testo = tipo === 'video'
    ? 'Trovami un tutorial video che mostri come fare questa cosa, e dimmi quanto tempo darmi per guardarlo: "' + t + '"'
    : 'Scomponi questa cosa da fare in 3 passi al massimo, da pochi minuti ciascuno, così so da dove partire: "' + t + '"';
  if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo, { invia: true, titolo: tipo === 'video' ? 'Il tutorial di domani' : 'Il passo di domani in tre passi' });
}
(function(){
  if (typeof document === 'undefined') return; const st = document.createElement('style');
  st.textContent = [
    '.pkd-t{margin:22px 0 12px;text-align:center;font:800 15px/1.35 var(--font-display);color:var(--navy)}body.dark .pkd-t{color:#fff}',
    '.pkd-l{display:flex;flex-direction:column;gap:10px;margin-bottom:22px}',
    /* 0.9.347: le due scelte affiancate, e l'ora libera */
    '.pkt{text-align:center}.pkt-ico{font-size:54px;line-height:1;margin:10px 0 16px}.pkt .stg-p{margin:0 0 8px}.pkt .stg-p + .stg-cta{margin-top:18px}',
    '.pkd-due{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:0 0 16px}',
    '.pkd-c{display:flex;flex-direction:column;align-items:center;gap:8px;padding:18px 12px;border-radius:20px;border:1.5px solid #C8EFFD;background:#F0FBFF;text-align:center;cursor:pointer;box-shadow:0 6px 16px rgba(0,117,227,.08);font-family:var(--font-body)}',
    '.pkd-c span{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;background:#fff;font-size:26px;box-shadow:0 4px 10px rgba(0,117,227,.12)}',
    '.pkd-c b{font:800 15px/1.25 var(--font-body);color:var(--navy)}.pkd-c small{font:500 12.5px/1.35 var(--font-body);color:var(--muted)}.pkd-c:active{transform:scale(.97)}',
    'body.dark .pkd-c{background:#12203A;border-color:#22345A}body.dark .pkd-c span{background:#0B1830}',
    '.pkg-ore .pkg-altra{padding-left:16px;padding-right:16px}.pkg-ora-libera{display:block;width:100%;box-sizing:border-box;margin:4px 0 18px;font:700 20px var(--font-body);text-align:center}',
    '.pkd-v{display:flex;align-items:center;gap:14px;width:100%;padding:14px 16px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer;font:inherit;color:var(--navy)}.pkd-v > span{flex:none;width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;background:#E3F1FF}',
    '.pkd-v > div{flex:1;min-width:0}.pkd-v b{display:block;font:800 15.5px/1.3 var(--font-body);color:var(--navy)}.pkd-v small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.pkd-sw{flex:none;position:relative;width:46px;height:28px;border-radius:99px;background:#C9D9EE;transition:background .2s}.pkd-sw::after{content:"";position:absolute;left:3px;top:3px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,30,68,.25);transition:transform .2s}',
    '.pkd-bl.on{border-color:#0075E3;background:rgba(0,117,227,.06)}.pkd-bl.on .pkd-sw{background:#0075E3}.pkd-bl.on .pkd-sw::after{transform:translateX(18px)}',
    'body.dark .pkd-v{background:#12203A;border-color:#22345A}body.dark .pkd-v b{color:#fff}body.dark .pkd-v > span{background:#1B2C4F}body.dark .pkd-sw{background:#2C4170}',
    /* 0.9.388 (BUG-112): il popover del passo di domani, con l'aspetto del popover della tappa di Full Focus (sentiero-mappa.js, .sd-task) */
    '.pkdm{padding-top:4px}.pkdm .stg-eti{text-align:center;margin:0 0 4px}.pkdm .sd-task-img{margin:10px auto 18px}',
    '.pkdm-passo{position:relative;margin:0 0 16px;padding:18px 52px 18px 18px;border-radius:20px;background:var(--dream);text-align:left}',
    '.pkdm-passo small{display:block;margin:0 0 4px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#005BB0}',
    '.pkdm-passo b{display:block;font:800 19px/1.35 var(--font-display,var(--font-body));color:#0E2350}',
    '.pkdm-i{position:absolute;right:14px;top:16px;width:28px;height:28px;padding:0 0 0 1px;border-radius:50%;border:1.8px solid #0075E3;background:rgba(255,255,255,.7);color:#0075E3;font:800 14px/1 Georgia,serif;font-style:italic;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.pkdm-i.on{background:#0075E3;color:#FFFFFF}',
    '.pkdm-info{margin:0 0 18px;padding:16px;border-radius:18px;background:#F0F7FF;border:1.5px solid #D6E8FB;text-align:left;display:flex;flex-direction:column;gap:14px}',
    '.pkdm-ir{display:flex;gap:12px;align-items:flex-start}.pkdm-ir > span{flex:none;width:36px;height:36px;border-radius:12px;background:#FFFFFF;color:#0075E3;display:flex;align-items:center;justify-content:center}',
    '.pkdm-ir b{display:block;font:800 14.5px/1.3 var(--font-body);color:#0E2350}.pkdm-ir p{margin:4px 0 0!important;max-width:none!important;font:500 14px/1.5 var(--font-body);color:#33445E}',
    '.pkdm-inota{display:block;font:600 12.5px/1.45 var(--font-body);color:#4A5A72}',
    '.pkdm-info.att{flex-direction:row;align-items:center}.pkdm-info.att p{margin:0!important;font:600 14px/1.45 var(--font-body);color:#33445E}',
    '.pkdm-pensa{flex:none;display:inline-flex;gap:4px}.pkdm-pensa i{width:7px;height:7px;border-radius:50%;background:#0075E3;animation:pkdmPensa 1s infinite ease-in-out}.pkdm-pensa i:nth-child(2){animation-delay:.15s}.pkdm-pensa i:nth-child(3){animation-delay:.3s}',
    '@keyframes pkdmPensa{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-3px)}}',
    'body.dark .pkdm-info{background:#12203A;border-color:#22345A}body.dark .pkdm-ir b{color:#FFFFFF}body.dark .pkdm-ir p,body.dark .pkdm-info.att p,body.dark .pkdm-inota{color:#BFD3EC}body.dark .pkdm-ir > span{background:#1B2C4F;color:#8CC6FF}',
    '.pkdm .sd-task-badge{margin:0 0 20px}.pkdm-dur{display:inline-flex;align-items:center;gap:6px}',
    '.pkc{margin:0 0 20px;border:1.5px solid var(--line,#DCE8F5);border-radius:18px;background:var(--card,#FFFFFF);text-align:left;overflow:hidden}',
    '.pkc-testa{display:flex;align-items:center;gap:12px;width:100%;padding:14px 16px;border:0;background:none;text-align:left;cursor:pointer;font:inherit;color:var(--navy,#001E44)}',
    /* 0.9.390 (BUG-121): l'icona al centro del suo riquadro. Prima ".pkc-testa span" (il sottotitolo) valeva anche per .pkc-ico e la
       faceva display:block: l'icona finiva in alto a sinistra. Adesso il sottotitolo ha il suo selettore (.pkc-tx > span). */
    '.pkc-testa .pkc-ico{flex:none;width:46px;height:46px;margin:0;padding:0;border-radius:14px;background:#E3F1FF;color:#0075E3;display:flex;align-items:center;justify-content:center;line-height:0}.pkc-ico svg{display:block;flex:none}',
    '.pkc-tx{flex:1;min-width:0}.pkc-tx small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}',
    '.pkc-tx b{display:block;margin-top:2px;font:800 16px/1.3 var(--font-body);color:var(--navy,#001E44)}.pkc-tx > span{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted,#4A5A72)}',
    '.pkc-chev{flex:none;color:#0075E3;transition:transform .2s;display:flex}.pkc.on .pkc-chev{transform:rotate(180deg)}',
    '.pkc-corpo{padding:0 12px 14px}.pkc-p{margin:0 4px 10px!important;max-width:none!important;font:600 13.5px/1.4 var(--font-body);color:var(--muted,#4A5A72)}',
    /* il calendario della Mappa dentro il popover (il popover e' .sd-task, centrato: qui tutto torna a sinistra) */
    '.pkc .cal-ist{text-align:left}.pkc .cal-scroll{height:340px}.pkc .cal-ist p{max-width:none}',
    '.pkc-avv{margin:10px 4px 0!important;max-width:none!important;font:700 13.5px/1.4 var(--font-body);color:#C42B38}',
    'body.dark .pkc{background:#12203A;border-color:#22345A}body.dark .pkc-tx b{color:#FFFFFF}body.dark .pkc-tx > span,body.dark .pkc-p{color:#BFD3EC}body.dark .pkc-ico{background:#1B2C4F;color:#8CC6FF}',
    '.pkdm-due{margin:0 0 14px}.pkdm-a span{color:#0075E3;display:flex}.pkdm-a small{display:block;margin-top:2px;font:700 11.5px/1.3 var(--font-body);color:#005BB0}',
    '.pkdm-a.on{border-color:#0075E3!important;background:#EEF6FF!important;box-shadow:0 3px 0 #0075E3!important}body.dark .pkdm-a.on{background:#16305A!important}body.dark .pkdm-a span,body.dark .pkdm-a small{color:#8CC6FF}',
    '.pkdm .pkd-bl{margin:0 0 22px}.pkdm .pkd-bl > span{color:#0075E3}body.dark .pkdm .pkd-bl > span{color:#8CC6FF}',
    '.pkdm .pkdm-go{margin-top:0}.pkdm-nota{margin:12px auto 4px!important;max-width:34ch!important;font:500 13px/1.45 var(--font-body);color:var(--muted,#4A5A72)}',
    '.pkdm .stg-link{display:block;margin:8px auto 0}.pkdm .pkdm-fine{margin-top:0}',
    /* 0.9.403 BUG-280: Mostra tutto, sottolineato (un testo cliccabile senza forma di pulsante) */
    '.pkdm-tutto{display:inline-block;margin:8px 0 0;padding:4px 0;border:0;background:none;font:700 14px/1.3 var(--font-body);color:#005BB0;text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    /* 0.9.403 BUG-280: i pollici e Parlane con il tuo agente, staccati dalle righe della (i) */
    '.pkdm-voto{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:6px;padding-top:16px;border-top:1px solid #D6E8FB}',
    '.pkdm-voto p{margin:0!important;max-width:none!important;font:700 14px/1.35 var(--font-body);color:#0E2350}.pkdm-voto .drs-at{margin:0;opacity:1}',
    '.pkdm-voto .drs-v{color:#33445E}.pkdm-voto .drs-v.on{color:#0075E3}',
    '.pkdm-parla{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:48px;margin-top:4px;padding:12px 14px;border:1.5px solid #0075E3;border-radius:14px;background:#FFFFFF;color:#0075E3;font:800 14.5px/1.3 var(--font-body);cursor:pointer}',
    '.pkdm-parla span{font-size:18px;line-height:1}',
    'body.dark .pkdm-voto{border-top-color:#22345A}body.dark .pkdm-voto p{color:#FFFFFF}body.dark .pkdm-voto .drs-v{color:#BFD3EC}body.dark .pkdm-voto .drs-v.on{color:#8CC6FF}',
    'body.dark .pkdm-parla{background:#16305A;border-color:#8CC6FF;color:#FFFFFF}',
    /* 0.9.403 BUG-283: le pillole delle fasce (staccate, con l'emoji; scelta: il bagliore .fl-sel), la giornata a fasce e il promemoria */
    '.pkc-pills{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 18px}',
    '.pkc-pill{display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-height:64px;padding:12px 14px;border:1.5px solid #CFE2F7;border-radius:16px;background:#F0F7FF;color:#0E2350;text-align:left;cursor:pointer;font:inherit}',
    '.pkc-pill span{font-size:20px;line-height:1;margin-bottom:4px}.pkc-pill b{font:800 14.5px/1.25 var(--font-body);color:#0E2350}.pkc-pill small{font:600 12.5px/1.3 var(--font-body);color:#33445E}',
    '.pkc-pill.on{border-color:#0075E3;background:#FFFFFF}',
    'body.dark .pkc-pill{background:#1B2C4F;border-color:#2C4470;color:#FFFFFF}body.dark .pkc-pill b{color:#FFFFFF}body.dark .pkc-pill small{color:#BFD3EC}body.dark .pkc-pill.on{background:#16305A;border-color:#8CC6FF}',
    '.pkg-g{display:flex;flex-direction:column;gap:14px;margin:4px 0 22px}',
    '.pkg-fh{display:flex;align-items:center;gap:6px;margin:0 0 8px;font:800 11.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#4A5A72}.pkg-fh span{font-size:15px;letter-spacing:0}',
    '.pkg-r{display:flex;align-items:flex-start;gap:12px;margin:0 0 8px;padding:10px 12px;border-radius:12px;background:#F4F7FB}.pkg-r:last-child{margin-bottom:0}',
    '.pkg-o{flex:none;min-width:42px;font:800 13.5px/1.35 var(--font-body);color:#33445E}.pkg-r b{display:block;font:700 14px/1.35 var(--font-body);color:#0E2350}',
    '.pkg-r.mio{background:#E3F1FF;border:1.5px solid #0075E3}.pkg-r.mio .pkg-o{color:#005BB0}.pkg-r.mio small{display:block;margin-top:3px;font:800 12.5px/1.3 var(--font-body);color:#005BB0}',
    '.pkg-vuota{margin:0!important;max-width:none!important;padding:10px 12px;border-radius:12px;border:1.5px dashed #DCE8F5;font:600 13px/1.3 var(--font-body);color:#4A5A72}',
    'body.dark .pkg-fh{color:#BFD3EC}body.dark .pkg-r{background:#1B2C4F}body.dark .pkg-o{color:#BFD3EC}body.dark .pkg-r b{color:#FFFFFF}body.dark .pkg-r.mio{background:#16305A;border-color:#8CC6FF}body.dark .pkg-r.mio .pkg-o,body.dark .pkg-r.mio small{color:#8CC6FF}body.dark .pkg-vuota{border-color:#2C4470;color:#BFD3EC}',
    '.pkr{padding-top:18px;border-top:1px solid var(--line,#DCE8F5)}.pkr-h{display:block;margin:0 4px 10px;font:800 11.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}',
    '.pkr .pkr-r{padding:12px 4px}.pkr .pkr-r b{font:700 14.5px/1.3 var(--font-body)}.pkr .pkr-r small{display:block;margin-top:3px;font:500 12.5px/1.35 var(--font-body);color:var(--muted,#4A5A72)}',
    'body.dark .pkr{border-top-color:#22345A}body.dark .pkr-h{color:#8CC6FF}body.dark .pkr .pkr-r b{color:#FFFFFF}body.dark .pkr .pkr-r small{color:#BFD3EC}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.dec-title .pk-i{color:#8CC6FF;margin-left:8px;vertical-align:middle;font-size:14px!important}'; document.head.appendChild(st); })();
