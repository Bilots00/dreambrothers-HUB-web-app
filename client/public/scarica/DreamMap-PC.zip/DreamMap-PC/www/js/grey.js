/* ===========================================================================================
   IL BIANCO E NERO, MA SOLO DOVE SERVE

   È il bianco e nero DI SISTEMA — quello di «Modalità e routine» di Samsung, quello di
   Impostazioni → Accessibilità: il telefono diventa davvero monocromatico. Non un filtro
   disegnato sopra: quello copre, non scolora.

   LA PAGINA, IN TRE COSE E BASTA.
   Un interruttore. Due cartelle quadrate — «Sempre» e «Programmi» — e niente altro. Prima qui
   dentro c'erano schede, file di pillole, elenchi aperti e campi: sette decisioni in una
   schermata, per una funzione che ne ha due. Le cartelle sono le stesse della pagina Categorie:
   si riconoscono a colpo d'occhio, e quello che contengono si apre quando serve.

     🌑 Sempre      → app, siti, indirizzi con le loro sottocartelle, parole che compaiono
                      sulla pagina: valgono sempre, senza condizioni.
     🗓️ Programmi   → le stesse cose ma solo in certi momenti: orari, giorni, rete Wi-Fi,
                      luogo. Stessa condizione dei programmi della scheda Blocco — ma qui NON
                      bloccano niente: tolgono il colore.
   =========================================================================================== */

let GR = { granted: false, permission: false, why: '', on: false, apps: [], sites: [], programs: [], pkg: 'com.dreambrothers.dreammap', service: true,
  /* LA TERZA CARTELLA, al contrario delle altre due: le UNICHE cose che restano a colori. Con
     `modo` = 'eccezioni' tutto quello che non sta qui dentro e' in bianco e nero. */
  modo: 'lista', colori: { apps: [], sites: [] } };
let GR_APPS = null;
let GR_LOADING = false;
const GR_PROGS_KEY = 'fl_grey_programs';

/* Le tre frasi, scritte per QUESTA pagina: riusare quelle della Lista di blocco voleva dire
   leggere «blocca» dove qui non si blocca niente. */
const GR_HINTS = {
  domain: 'Tutto il sito perde il colore, sottodomini compresi: «instagram.com» prende anche «m.instagram.com», non «notinstagram.com».',
  url: 'Solo gli indirizzi che contengono quello che scrivi: «youtube.com/shorts» spegne gli Shorts e lascia a colori il resto di YouTube, sottocartelle comprese.',
  content: 'Quando quella parola compare sulla pagina. Serve perché Chrome nella barra mostra solo il dominio: è l\'unica che arriva dentro alle pagine.'
};

registerScreen('s-grey', `
  <div class="topbar"><button class="iconbtn" onclick="grBack()">‹</button><b class="blk-title">Bianco e nero</b></div>
  <div id="grBody"></div>
  <div class="spacer"></div>
`, { back: 's-settings' });

registerScreen('s-greyalways', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">Sempre in bianco e nero</b></div>
  <div id="grAlwaysBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greyprogs', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">Programmi</b></div>
  <div id="grProgsBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greycolor', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">A colori</b></div>
  <div id="grColorBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greycolorapps', `
  <div class="topbar"><button class="iconbtn" onclick="grColorOpen()">‹</button><b class="blk-title">App a colori</b></div>
  <div class="fl-search">\ud83d\udd0e<input id="grQc" placeholder="Cerca un'app…" oninput="grColorFilter()" autocomplete="off"></div>
  <div class="gr-list" id="grListColor"></div>
  <div class="spacer"></div>
`, { back: 's-greycolor' });

registerScreen('s-greyapps', `
  <div class="topbar"><button class="iconbtn" onclick="grAlwaysOpen()">‹</button><b class="blk-title">App in bianco e nero</b></div>
  <div class="fl-search">🔎<input id="grQ" placeholder="Cerca un'app…" oninput="grFilter()" autocomplete="off"></div>
  <div class="gr-list" id="grList"></div>
  <div class="spacer"></div>
`, { back: 's-greyalways' });

/* ---------------------------------------------------------------------------------------
   Aprire e chiudere
   --------------------------------------------------------------------------------------- */

function grBack(){
  goId('s-settings');
  /* La riga «Bianco e nero selettivo» della pagina di prima deve dire lo stato NUOVO: senza
     questa chiamata restava ferma a quello che c'era quando la pagina è stata disegnata. */
  try{ if (typeof settingsPaintExits === 'function') settingsPaintExits(); }catch(_){ }
}

function grProgramsLoad(){
  try{ GR.programs = JSON.parse(localStorage.getItem(GR_PROGS_KEY) || '[]') || []; }catch(_){ GR.programs = []; }
}

/* 0.9.264, Andrea: con l'aggiornamento le app e i siti del bianco e nero erano spariti, e la pagina ci metteva
   troppo ad aprirsi (prima "collega il computer", poi gli elenchi). Le cause:
   - la pagina partiva dai valori VUOTI mentre aspettava il telefono: un tocco in quel momento (anche il nuovo
     interruttore della schermata di blocco) salvava gli elenchi vuoti sopra a quelli veri;
   - lo stato si chiedeva DOPO l'elenco delle app installate, e le chiamate al telefono passano in fila: si
     aspettava che arrivassero tutte le app con le icone.
   Adesso: l'ultimo stato letto si tiene sul telefono (fl_grey_cache) e la pagina si apre gia' giusta; lo
   stato vero si chiede per primo; e finche' non e' arrivato non si salva niente. */
const GR_CACHE = 'fl_grey_cache';
function grDaStato(r){
  GR.granted = !!r.granted;
  GR.permission = !!r.permission;
  GR.why = r.why || '';
  GR.on = !!r.on;
  GR.apps = r.apps || [];
  GR.sites = (r.sites || []).map(grKw);
  GR.modo = r.mode === 'eccezioni' ? 'eccezioni' : 'lista';
  GR.colori = { apps: r.colorApps || [], sites: (r.colorSites || []).map(function(v){ return grKw(v).t; }) };
  GR.lockColor = !!r.lockColor;
  if (r.package) GR.pkg = r.package;
  if (typeof r.service === 'boolean') GR.service = r.service;
}
function grInCache(){
  try{ localStorage.setItem(GR_CACHE, JSON.stringify({ granted: GR.granted, permission: GR.permission, on: GR.on, apps: GR.apps, sites: GR.sites, mode: GR.modo, colorApps: GR.colori.apps, colorSites: GR.colori.sites, lockColor: !!GR.lockColor, package: GR.pkg, service: GR.service })); }catch(_){ }
}
async function grOpen(){
  goId('s-grey');
  grProgramsLoad();
  try{ const c = JSON.parse(localStorage.getItem(GR_CACHE) || 'null'); if (c){ grDaStato(c); GR.caricato = true; } }catch(_){ }
  grPaint();
  await grAggiorna();
  /* le app installate DOPO lo stato: servono solo quando si tocca "Scegli le app" */
  grLoadApps();
}

/* Rilegge lo stato vero dal telefono e ridisegna, senza cambiare pagina. La usano l'apertura, il
   «Ricontrolla», il ritorno dalle impostazioni e il controllo a giro durante l'attivazione. */
async function grAggiorna(aMano){
  const prima = GR.granted;
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.greyState){
    try{
      const r = await NATIVE.greyState();
      if (r){
        grDaStato(r);
        GR.caricato = true;
        grInCache();
      }
    }catch(_){ }
  }
  if (!GR.granted){ await grSpStato(); if (GR.caricato) GR.guidaVista = true; } else grPollFerma();
  grPaint();
  if (!GR.granted && grSpInCorso()) grPollAvvia();
  /* IL PERMESSO E' APPENA ARRIVATO: il riquadro sparisce (grPaint qui sopra) e il bianco e nero
     riparte da solo con le impostazioni gia' salvate — le legge il motore, e greyState ha appena
     fatto dimenticare al motore il «no» di prima. Lo si dice solo a chi aveva davanti la guida. */
  if (GR.granted && prima === false && GR.guidaVista){
    GR.guidaVista = false;
    try{ toast(GR.on ? 'Fatto: il bianco e nero è attivo' : 'Fatto: ora accendi il bianco e nero qui sotto'); }catch(_){ }
  } else if (aMano && !GR.granted){
    try{ toast('Non ancora: segui i passi qui sopra'); }catch(_){ }
  }
}

/* ---------------------------------------------------------------------------------------
   L'ATTIVAZIONE SOLO COL TELEFONO (23/11/2026)

   Andrea: "anche per chi non ha un PC, e la guida piu' semplice". Da Android 11 il telefono si
   collega al proprio Debug wireless e si da' il permesso da solo (GrigioSenzaPc.java): l'utente
   accende il Debug wireless, tocca «Accoppia dispositivo con codice» e scrive le sei cifre nella
   notifica di DreamMap, senza lasciare quella schermata. Su Android 10 e prima non c'e': resta il
   computer.
   --------------------------------------------------------------------------------------- */
let GS = null;          // lo stato dell'attivazione: {supported, sdk, devOn, wifiDebug, wifi, notif, permesso, stato, msg}
let GR_POLL = null;
let GR_PC_APERTA = false;

async function grSpStato(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.greySenzaPc){ GS = null; return; }
  try{ GS = await NATIVE.greySenzaPc({ azione: 'stato' }); }catch(_){ GS = null; }
}
function grSpInCorso(){ return !!(GS && (GS.stato === 'aspetto' || GS.stato === 'lavoro' || GS.ascolto)); }
function grSuPagina(){ const s = document.getElementById('s-grey'); return !!(s && s.classList.contains('active')); }

function grPollFerma(){ if (GR_POLL){ clearInterval(GR_POLL); GR_POLL = null; } }
function grPollAvvia(){
  if (GR_POLL) return;
  let firma = '';
  GR_POLL = setInterval(async function(){
    if (!grSuPagina() || GR.granted){ grPollFerma(); return; }
    await grSpStato();
    if (GS && (GS.permesso || GS.stato === 'fatto')){ grPollFerma(); await grAggiorna(); return; }
    /* si ridisegna solo se qualcosa e' cambiato: un tocco a meta' non va perso */
    const f = JSON.stringify(GS || {});
    if (f !== firma){ firma = f; grPaint(); }
    if (!grSpInCorso()) grPollFerma();
  }, 2500);
}

async function grSpApri(dove){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.greySenzaPc) return;
  try{ GS = await NATIVE.greySenzaPc({ azione: 'apri', dove: dove }); }catch(_){ }
}

/* Il via: la notifica con il campo del codice, l'ascolto delle porte, e (se `apri`) il Debug
   wireless. Senza notifiche il codice non ha dove arrivare: si chiedono prima. */
async function grSpAvvia(apri){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.greySenzaPc){ toast('Aggiorna DreamMap per attivarlo dal telefono'); return; }
  if (GS && GS.notif === false && NATIVE.notifChiedi){
    try{
      const r = await NATIVE.notifChiedi();
      if (!r || !r.granted){ toast('Accendi le notifiche di DreamMap: il codice si scrive lì'); return; }
    }catch(_){ }
  }
  try{ GS = await NATIVE.greySenzaPc({ azione: 'avvia', apri: apri !== false }); }
  catch(e){ toast((e && e.message) || 'Non riesco a partire'); return; }
  if (apri === false) toast('Notifica rimandata: la trovi in alto');
  grPaint();
  grPollAvvia();
}

/* Tornando dalle impostazioni la pagina dice subito com'e' andata. */
document.addEventListener('visibilitychange', function(){
  if (!document.hidden && grSuPagina()) setTimeout(function(){ grAggiorna(); }, 300);
});

/* 0.9.286, Andrea: "sul computer cerco Foto o Esplora risorse e non le trovo". Due cause: l'elenco si leggeva una volta
   sola e restava quello per giorni (sul computer la pagina non si chiude mai: Foto, vista dopo, non c'era); ed Esplora
   risorse il computer non lo offre mai, perche' un blocco messo li' lascerebbe il computer senza scrivania. Per il bianco
   e nero non c'e' rischio: qui si aggiunge, insieme a Foto, e l'elenco si rilegge se ha piu' di un minuto. */
let GR_APPS_AT = 0;
/* 0.9.287: il nome di Windows e quello inglese si trovano tutti e due (alias); il computer manda anche l'icona */
const GR_PC_EXTRA = [{ packageName: 'win:explorer', label: 'Esplora file', alias: 'Esplora risorse File Explorer' }, { packageName: 'win:Photos', label: 'Foto', alias: 'Photos Immagini' }];
async function grLoadApps(forza){
  /* 0.9.350, Andrea: "cercando un'app compare Leggo le app del telefono e ci mette ore: deve trovarle subito". L'elenco c'e' gia': quello
     salvato l'ultima volta per questa pagina, o quello letto all'avvio per tutta l'app (app-installate.js). Si mostra quello, e
     intanto si rilegge dal telefono in sottofondo */
  if (!GR_APPS){
    let c = null; try{ const j = JSON.parse(localStorage.getItem('fl_apps_colori') || 'null'); if (j && Array.isArray(j.apps) && j.apps.length) c = j.apps; }catch(_){ }
    if (!c && typeof FLA !== 'undefined' && FLA.list && FLA.list.length) c = FLA.list.slice();
    if (c){ GR_APPS = c.slice().sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); }); GR_APPS_AT = 0; setTimeout(function(){ try{ grPaintApps(); }catch(_){ } try{ grPaint(); }catch(_){ } }, 0); }
  }
  if (GR_LOADING) return GR_APPS;
  if (GR_APPS && GR_APPS_AT && !(forza && Date.now() - GR_APPS_AT > 60000)) return GR_APPS;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalledApps){ GR_APPS = []; return GR_APPS; }
  GR_LOADING = true;
  try{
    const r = await NATIVE.getInstalledApps({ uso: 'colori' });
    GR_APPS = (r && r.apps) || [];
    const pc = typeof pcQui === 'function' && pcQui() === 'desktop';
    if (pc) GR_PC_EXTRA.forEach(function(x){ if (!GR_APPS.some(function(a){ return String(a.packageName || '').toLowerCase() === x.packageName.toLowerCase(); })) GR_APPS.push(Object.assign({ system: false }, x)); });
    GR_APPS.sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); });
    GR_APPS_AT = Date.now();
    try{ localStorage.setItem('fl_apps_colori', JSON.stringify({ at: GR_APPS_AT, apps: GR_APPS.map(function(x){ return { packageName: x.packageName, label: x.label, system: x.system, alias: x.alias }; }) })); }catch(_){ }
  }catch(_){ GR_APPS = GR_APPS || []; }
  GR_LOADING = false;
  try{ grPaintApps(); }catch(_){ }
  try{ grPaint(); }catch(_){ }
  return GR_APPS;
}

/* Ogni voce nella forma {t, m} che il motore capisce — le stesse tre modalità della Lista di
   blocco. Una stringa nuda con una barra dentro è un indirizzo, senza è un dominio. */
function grKw(v){
  if (typeof ubKw === 'function' && v && typeof v === 'object') return ubKw(v);
  const t = String((v && typeof v === 'object') ? (v.t || v.term || '') : (v || '')).trim().toLowerCase();
  const m = (v && typeof v === 'object' && (v.m || v.mode)) ? String(v.m || v.mode) : (t.indexOf('/') >= 0 ? 'url' : 'domain');
  return { t: t, m: m };
}

async function grSave(){
  try{ localStorage.setItem(GR_PROGS_KEY, JSON.stringify(GR.programs)); }catch(_){ }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setGrey) return;
  /* mai scrivere sopra agli elenchi veri prima di averli letti */
  if (!GR.caricato){ try{ toast('Un attimo: sto leggendo le tue impostazioni'); }catch(_){ } return; }
  grInCache();
  const programs = GR.programs.map(function(p){
    return (typeof programToSchedule === 'function') ? programToSchedule(p) : p;
  });
  try{ await NATIVE.setGrey({ on: GR.on, apps: GR.apps, sites: GR.sites, programs: programs,
                              mode: GR.modo, colorApps: GR.colori.apps, colorSites: GR.colori.sites, lockColor: !!GR.lockColor }); }catch(_){ }
  /* la riserva di dopamina legge il bianco e nero: che sappia subito del cambio */
  try{ if (typeof DP !== 'undefined' && DP) DP.grigio = null; }catch(_){ }
}

function grToggleOn(){
  GR.on = !GR.on;
  grSave(); grPaint();
  if (GR.on && !GR.granted) toast('Manca l\'attivazione: i passi sono qui sopra');
  else if (GR.on && !grCount()) toast('Adesso scegli su cosa: le due cartelle qui sotto');
}

function grCount(){ return GR.apps.length + GR.sites.length + GR.programs.length + (GR.modo === 'eccezioni' ? 1 : 0); }

/* ---------------------------------------------------------------------------------------
   LA PAGINA: un interruttore e due cartelle
   --------------------------------------------------------------------------------------- */

function grPaint(){
  const box = document.getElementById('grBody');
  if (!box) return;
  /* la tendina «Hai un computer?» aperta resta aperta quando la pagina si ridisegna da sola */
  try{ GR_PC_APERTA = !!(box.querySelector && box.querySelector('.gr-pc[open]')); }catch(_){ }

  /* DUE CASI DIVERSI, NON UNO SOLO.
     Se il sistema dice che il permesso NON c'è, va concesso, e si spiega come.
     Se dice che c'è ma la scrittura fallisce lo stesso, il problema è un altro: si mostra
     l'errore vero invece di ripetere istruzioni già eseguite. È esattamente la trappola in cui
     è finito Andrea — riquadro rosso acceso dopo un'attivazione riuscita, e nessun modo di
     capire da che parte stesse il guasto. */
  const permesso = GR.granted ? '' : (GR.permission
    ? '<div class="gr-warn">'
      + '<b class="gr-tit">' + GR_ICO.avviso + 'Il permesso c\'è, ma la scrittura non passa</b>'
      + '<p>Android dice che DreamMap ha il permesso, eppure il telefono rifiuta di cambiare il bianco e nero di sistema. Non è un passaggio che hai saltato tu.</p>'
      + (GR.why ? '<div class="gr-why">' + esc(GR.why) + '</div>' : '')
      + '<p style="margin:12px 0 0">Prova a riavviare il telefono: il permesso resta, e quasi sempre è quello a sbloccarlo.</p>'
      + '<button type="button" class="ghostmini" style="width:100%;margin-top:12px" onclick="grAggiorna(true)">Ricontrolla</button>'
      + '</div>'
    : grGuida());
  const testa = '<div class="ps-block">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>🌑 Bianco e nero selettivo</b>'
    + '<small>Il telefono diventa monocromatico solo mentre hai davanti quello che scegli tu. Tutto il resto resta a colori.</small></div>'
    + '<button class="switch' + (GR.on ? ' on' : '') + '" onclick="grToggleOn()"></button></div>'
    + (GR.service === false
        ? '<p class="hintline" style="padding:10px 2px 0;color:#E5515F">Il servizio di blocco è spento: senza di lui nessuno sa cosa hai davanti. Accendilo dal profilo.</p>'
        : '')
    + '</div>';

  box.innerHTML = permesso + testa
    + '<div class="sect" style="margin-top:26px"><b>Cosa diventa bianco e nero</b></div>'
    + '<div class="hintline" style="padding:0 2px 12px">' + (GR.modo === 'eccezioni'
        ? 'Tutto, tranne quello che sta nella cartella <b>A colori</b>. Le altre due cartelle non servono finch\u00e9 questa \u00e8 accesa.'
        : 'Tre cartelle: quello che vale sempre, quello che vale solo in certi momenti, e \u2014 al contrario \u2014 le uniche cose che restano a colori.') + '</div>'
    + '<div class="grp-row">' + grCardSempre() + grCardColori() + grCardProgrammi() + '</div>';

  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}

/* LE ICONE DELLA GUIDA. Disegni, non caratteri: la freccia «→» stava piu' in alto del testo e
   cambiava da un telefono all'altro. Il chevron ha la stessa altezza della riga (1em) e scende
   di quel poco che serve a stare sulla linea delle lettere. */
const GR_ICO = (function(){
  const s = function(cls, d){ return '<svg class="gr-ico' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + d + '</svg>'; };
  return {
    chev: s('gr-chev', '<path d="M9 6l6 6-6 6"/>'),
    chiave: s('', '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>'),
    avviso: s('', '<path d="M12 3.5L2.5 20h19z"/><path d="M12 10v4.5"/><circle cx="12" cy="17.2" r=".6" fill="currentColor"/>'),
    telefono: s('', '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>'),
    wifi: s('', '<path d="M2.5 9a14 14 0 0 1 19 0"/><path d="M5.5 12.5a9.5 9.5 0 0 1 13 0"/><path d="M8.7 15.8a5 5 0 0 1 6.6 0"/><circle cx="12" cy="19" r=".9" fill="currentColor"/>'),
    campana: s('', '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>'),
    spunta: s('', '<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
    computer: s('', '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>'),
    giro: s('', '<path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v4.5h-4.5"/>')
  };
})();

/* Un percorso nelle impostazioni: «Impostazioni › Info sul telefono › ...» con il chevron disegnato. */
function grPercorso(passi){ return passi.map(esc).join(GR_ICO.chev); }

/* Un passo della guida: numero (o spunta se fatto), titolo, una riga, e il pulsante che porta li'. */
function grPasso(n, fatto, titolo, riga, bottone){
  return '<div class="gr-step' + (fatto ? ' fatto' : '') + '">'
    + '<i>' + (fatto ? GR_ICO.spunta : n) + '</i>'
    + '<span><b>' + titolo + '</b>' + (riga ? '<small>' + riga + '</small>' : '') + (bottone || '') + '</span>'
    + '</div>';
}

/* La guida per chi ha un computer (e l'unica, su Android 10 e prima). */
function grGuidaPc(sola){
  const vecchio = GS && GS.sdk && GS.sdk < 30;
  if (vecchio){
    /* Prima di Android 11 il debug senza cavo non c'e': serve il cavo USB e un comando. */
    return '<div class="gr-steps">'
      + grPasso(1, false, 'Accendi il Debug USB', grPercorso(['Impostazioni', 'Opzioni sviluppatore', 'Debug USB']) + '.')
      + grPasso(2, false, 'Collega il telefono al computer', 'Col cavo. Sul telefono conferma «Consenti debug USB».')
      + grPasso(3, false, 'Sul computer scrivi questo comando', '<code class="gr-cmd">adb shell pm grant ' + esc(GR.pkg) + ' android.permission.WRITE_SECURE_SETTINGS</code>')
      + grPasso(4, false, 'Torna qui', 'Tocca «Ricontrolla»: il riquadro sparisce.')
      + '</div>';
  }
  return (sola ? '' : '<p class="gr-pcintro">Telefono e computer sulla stessa rete Wi-Fi.</p>')
    + '<div class="gr-steps">'
    + grPasso(1, false, 'Sul telefono', grPercorso(['Impostazioni', 'Opzioni sviluppatore', 'Debug wireless', '«Accoppia dispositivo con codice di accoppiamento»']) + '.')
    + grPasso(2, false, 'Sul computer', grPercorso(['DreamMap', 'Impostazioni', '«Attiva il bianco e nero sul telefono»']) + ': ci scrivi codice e indirizzo.')
    + grPasso(3, false, 'Torna qui', 'Riapri DreamMap: il riquadro sparisce da solo.')
    + '</div>';
}

function grGuida(){
  const soloTelefono = GS && GS.supported;
  let corpo;
  if (soloTelefono){
    const dev = !!GS.devOn, wd = !!GS.wifiDebug;
    const passo1 = grPasso(1, dev, dev ? 'Opzioni sviluppatore accese' : 'Accendi le Opzioni sviluppatore',
      dev ? '' : grPercorso(['Impostazioni', 'Info sul telefono']) + ': tocca 7 volte «Numero build». Su Samsung è dentro «Informazioni software».',
      dev ? '' : '<button type="button" class="gr-stepbtn" onclick="grSpApri(\'info\')">' + GR_ICO.telefono + 'Apri Info sul telefono</button>');
    const passo2 = grPasso(2, wd, wd ? 'Debug wireless acceso' : 'Accendi il Debug wireless',
      (GS.wifi === false ? '<em class="gr-nota">Adesso non sei su un Wi-Fi: collegati a una rete, anche senza internet.</em>' : 'Serve il Wi-Fi, anche senza internet. Ti porto io alla voce giusta.'),
      '<button type="button" class="gr-stepbtn" onclick="grSpAvvia()">' + GR_ICO.wifi + (wd ? 'Riapri il Debug wireless' : 'Apri Debug wireless') + '</button>');
    const passo3 = grPasso(3, false, 'Tocca «Accoppia dispositivo con codice di accoppiamento»',
      'Arriva una notifica di DreamMap: scrivi lì le 6 cifre, senza uscire da quella schermata.',
      '<button type="button" class="gr-stepbtn gr-stepbtn-lieve" onclick="grSpAvvia(false)">' + GR_ICO.campana + 'Rimandami la notifica</button>');
    const passo4 = grPasso(4, false, 'Fatto', 'DreamMap si dà il permesso da sola e spegne il Debug wireless. Questo riquadro sparisce.');
    let stato = '';
    if (GS.stato === 'lavoro') stato = '<p class="gr-stato">Sto collegando DreamMap al telefono…</p>';
    else if (GS.msg) stato = '<p class="gr-stato gr-stato-no">' + esc(GS.msg) + '</p>';
    corpo = '<p>Android protegge il bianco e nero di sistema. Lo sblocchi una volta, da qui: due minuti, niente cavi.</p>'
      + '<div class="gr-steps">' + passo1 + passo2 + passo3 + passo4 + '</div>'
      + stato
      + '<button type="button" class="ghostmini gr-ricontrolla" onclick="grAggiorna(true)">' + GR_ICO.giro + 'Ricontrolla</button>'
      + '<details class="gr-pc"' + (GR_PC_APERTA ? ' open' : '') + '><summary>' + GR_ICO.computer + 'Hai un computer? Puoi farlo anche da lì</summary>' + grGuidaPc(false) + '</details>';
  } else {
    corpo = '<p>Android protegge il bianco e nero di sistema. ' + (GS && GS.sdk && GS.sdk < 30
        ? 'Su questo telefono si sblocca una volta dal computer, col cavo.'
        : 'Si sblocca una volta dal computer, senza cavo.') + '</p>'
      + grGuidaPc(true)
      + '<button type="button" class="ghostmini gr-ricontrolla" onclick="grAggiorna(true)">' + GR_ICO.giro + 'Ricontrolla</button>';
  }
  return '<div class="gr-warn gr-guida">'
    + '<b class="gr-tit">' + GR_ICO.chiave + 'Un\'attivazione, una volta sola</b>'
    + corpo
    + '</div>';
}

function grMiniChips(voci, extra){
  const q = voci.slice(0, 3);
  while (q.length < 3) q.push('<span class="grp-chip grp-chip-void"></span>');
  q.push('<span class="grp-chip grp-chip-more">' + extra + '</span>');
  return '<span class="grp-grid">' + q.join('') + '</span>';
}

function grCardSempre(){
  const n = GR.apps.length + GR.sites.length;
  const voci = [];
  GR.apps.slice(0, 3).forEach(function(p){
    voci.push('<span class="grp-chip"><span class="ub-appico ub-appico-fb">' + esc(grAppLabel(p).charAt(0).toUpperCase())
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(p) + '" alt=""></span></span>');
  });
  GR.sites.slice(0, Math.max(0, 3 - voci.length)).forEach(function(k){
    const m = grKw(k).m;
    voci.push('<span class="grp-chip">' + (m === 'content' ? '🔤' : (m === 'url' ? '📄' : '🌐')) + '</span>');
  });
  return '<button type="button" class="grp-card" onclick="grAlwaysOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '🌑')
    + '<b class="grp-name">Sempre</b>'
    + '<small class="grp-count">' + (n ? n + (n === 1 ? ' voce' : ' voci') : 'vuoto') + '</small>'
    + '</button>';
}

function grCardProgrammi(){
  const n = GR.programs.length;
  const attivi = GR.programs.filter(function(p){ return p.on !== false; }).length;
  const voci = GR.programs.slice(0, 3).map(function(p){
    return '<span class="grp-chip">' + (p.icon || '🕑') + '</span>';
  });
  return '<button type="button" class="grp-card" onclick="grProgsOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '🗓️')
    + '<b class="grp-name">Programmi</b>'
    + '<small class="grp-count">' + (n ? attivi + ' su ' + n + ' attivi' : 'nessuno') + '</small>'
    + '</button>';
}

function grCardColori(){
  const n = GR.colori.apps.length + GR.colori.sites.length;
  const on = GR.modo === 'eccezioni';
  const voci = [];
  GR.colori.apps.slice(0, 3).forEach(function(p){
    voci.push('<span class="grp-chip"><span class="ub-appico ub-appico-fb">' + esc(grAppLabel(p).charAt(0).toUpperCase())
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(p) + '" alt=""></span></span>');
  });
  GR.colori.sites.slice(0, Math.max(0, 3 - voci.length)).forEach(function(){ voci.push('<span class="grp-chip">\ud83c\udf10</span>'); });
  return '<button type="button" class="grp-card' + (on ? ' grp-on' : '') + '" onclick="grColorOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '\ud83c\udfa8')
    + '<b class="grp-name">A colori</b>'
    + '<small class="grp-count">' + (on ? (n ? n + (n === 1 ? ' voce' : ' voci') + ' \u00b7 il resto grigio' : 'acceso, vuoto') : (n ? n + (n === 1 ? ' voce' : ' voci') + ' \u00b7 spento' : 'spento')) + '</small>'
    + '</button>';
}

/* ---------------------------------------------------------------------------------------
   A COLORI: le uniche eccezioni. Tutto il resto in bianco e nero.
   --------------------------------------------------------------------------------------- */
function grColorOpen(){
  goId('s-greycolor');
  grPaintColor();
  grLoadApps();
}
function grPaintColor(){
  const box = document.getElementById('grColorBody');
  if (!box) return;
  const on = GR.modo === 'eccezioni';
  const testa = '<div class="ps-block">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83c\udfa8 Tutto il resto in bianco e nero</b>'
    + '<small>Solo le app e i siti scelti qui restano a colori. Ogni altra schermata perde il colore, e con lui buona parte dello stimolo: la riserva di dopamina lo sente.</small></div>'
    + '<button class="switch' + (on ? ' on' : '') + '" onclick="grColorToggle()"></button></div>'
    + '</div>';
  const app = '<div class="sect" style="margin-top:26px"><b>\ud83d\udcf1 App a colori</b></div>'
    + '<div class="setrow" onclick="grColorOpenApps()"><span>\ud83d\udcf1</span><b>Scegli le app</b><small>'
    + (GR.colori.apps.length ? GR.colori.apps.length + (GR.colori.apps.length === 1 ? ' scelta' : ' scelte') : (GR_APPS ? 'nessuna' : 'leggo le app\u2026')) + '</small><span class="chev"></span></div>'
    + (GR.colori.apps.length
        ? '<div class="gr-chips">' + GR.colori.apps.map(function(p){
            return '<span class="gr-chip">' + esc(grAppLabel(p)) + '<button type="button" onclick="grColorRemoveApp(\'' + esc(p) + '\')" aria-label="Togli">\u2715</button></span>';
          }).join('') + '</div>'
        : '');
  const siti = '<div class="sect" style="margin-top:26px"><b>\ud83c\udf10 Siti a colori</b></div>'
    + '<div class="gr-addrow">'
    +   '<input id="grColorSiteIn" placeholder="notion.so \u00b7 docs.google.com" autocomplete="off"'
    +   ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();grColorSiteAdd();}">'
    + '</div>'
    + '<button type="button" class="ghostmini ff-addsite" onclick="grColorSiteAdd()">Inserisci</button>'
    + (GR.colori.sites.length
        ? '<div class="gr-list" style="margin-top:12px">' + GR.colori.sites.map(function(t, i){
            return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">\ud83c\udf10</span>'
              + '<span class="ff-pickname">' + esc(t) + '</span>'
              + '<button type="button" class="ff-rm" onclick="grColorSiteDel(' + i + ')" aria-label="Togli">\u2715</button></div>';
          }).join('') + '</div>'
        : '<p class="ff-empty">Il sito su cui lavori mettilo qui: \u00e8 quello che devi vedere a colori.</p>');
  /* 0.9.263, Andrea: la schermata di blocco del telefono (e la frase del giorno sopra) si puo' vedere a colori */
  const blocco = '<div class="ps-block" style="margin-top:26px">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udd12 Schermata di blocco a colori</b>'
    + '<small>Quando il telefono è bloccato, la schermata di blocco e la frase del giorno restano a colori. Appena sblocchi, il bianco e nero torna dove l’avevi scelto.</small></div>'
    + '<button class="switch' + (GR.lockColor ? ' on' : '') + '" onclick="grLockColorToggle()"></button></div>'
    + '</div>';
  box.innerHTML = testa + blocco + app + siti;
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}
function grLockColorToggle(){
  GR.lockColor = !GR.lockColor;
  grSave(); grPaintColor();
  try{ toast(GR.lockColor ? 'La schermata di blocco resta a colori' : 'La schermata di blocco segue il bianco e nero'); }catch(_){ }
}
function grColorToggle(){
  GR.modo = GR.modo === 'eccezioni' ? 'lista' : 'eccezioni';
  if (GR.modo === 'eccezioni') GR.on = true;
  grSave(); grPaintColor();
  if (GR.modo === 'eccezioni' && !GR.granted) toast('Manca l\'attivazione: i passi sono nella pagina Bianco e nero');
  else if (GR.modo === 'eccezioni') toast('Tutto in bianco e nero, tranne quello che scegli qui');
}
async function grColorOpenApps(){
  goId('s-greycolorapps');
  grPaintColorApps();
  await grLoadApps(true);
  grPaintColorApps();
}
function grPaintColorApps(){
  const box = document.getElementById('grListColor');
  if (!box) return;
  if (!GR_APPS){ box.innerHTML = '<p class="ff-empty">Leggo le app del telefono\u2026</p>'; return; }
  if (!GR_APPS.length){ box.innerHTML = '<p class="ff-empty">Nessuna app da elencare.</p>'; return; }
  box.innerHTML = GR_APPS.map(function(a){
    const on = GR.colori.apps.indexOf(a.packageName) >= 0;
    const letter = esc((a.label || '?').charAt(0).toUpperCase());
    return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
      + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>' + (a.alias ? '<span class="ff-alias" hidden>' + esc(a.alias) + '</span>' : '')
      + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '')
      + ' onchange="grColorToggleApp(this)"></label>';
  }).join('');
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
  grColorFilter();
}
function grColorFilter(){
  const q = ((document.getElementById('grQc') || {}).value || '').trim().toLowerCase();
  document.querySelectorAll('#grListColor .ff-pickrow').forEach(function(r){
    r.style.display = (!q || r.textContent.toLowerCase().indexOf(q) >= 0) ? '' : 'none';
  });
}
function grColorToggleApp(cb){
  const i = GR.colori.apps.indexOf(cb.value);
  if (cb.checked && i < 0) GR.colori.apps.push(cb.value);
  if (!cb.checked && i >= 0) GR.colori.apps.splice(i, 1);
  grSave();
}
function grColorRemoveApp(pkg){
  GR.colori.apps = GR.colori.apps.filter(function(x){ return x !== pkg; });
  grSave(); grPaintColor();
}
function grColorSiteAdd(){
  const inp = document.getElementById('grColorSiteIn');
  const t = grKw((inp && inp.value) || '').t;
  if (!t){ toast('Scrivi un sito'); return; }
  if (GR.colori.sites.indexOf(t) < 0) GR.colori.sites.push(t);
  if (inp) inp.value = '';
  grSave(); grPaintColor();
}
function grColorSiteDel(i){
  GR.colori.sites.splice(i, 1);
  grSave(); grPaintColor();
}

/* ---------------------------------------------------------------------------------------
   SEMPRE: app, siti, indirizzi, parole
   --------------------------------------------------------------------------------------- */

function grAlwaysOpen(){
  goId('s-greyalways');
  grPaintAlways();
}

function grPaintAlways(){
  const box = document.getElementById('grAlwaysBody');
  if (!box) return;

  const app = '<div class="sect"><b>📱 App</b></div>'
    + '<div class="setrow" onclick="grOpenApps()"><span>📱</span><b>Scegli le app</b><small>'
    + (GR.apps.length ? GR.apps.length + (GR.apps.length === 1 ? ' scelta' : ' scelte') : (GR_APPS ? 'nessuna' : 'leggo le app…')) + '</small><span class="chev"></span></div>'
    + (GR.apps.length
        ? '<div class="gr-chips">' + GR.apps.map(function(p){
            return '<span class="gr-chip">' + esc(grAppLabel(p)) + '<button type="button" onclick="grRemoveApp(\'' + esc(p) + '\')" aria-label="Togli">✕</button></span>';
          }).join('') + '</div>'
        : '');

  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const siti = '<div class="sect" style="margin-top:26px"><b>🌐 Siti, pagine e parole</b></div>'
    + '<div class="gr-addrow">'
    +   '<input id="grSiteIn" placeholder="instagram.com · youtube.com/shorts · reels" autocomplete="off"'
    +   ' oninput="grOnInput()" onkeydown="if(event.key===\'Enter\'){event.preventDefault();grSiteAdd();}">'
    +   '<button type="button" class="gr-modebtn" onclick="grOpenMode()"><span id="grModeLbl">' + esc(grModeLabel(m)) + '</span><i class="ub-caret"></i></button>'
    + '</div>'
    + '<p class="hintline" id="grModeHint" style="padding:8px 2px 0"></p>'
    + '<button type="button" class="ghostmini ff-addsite" onclick="grSiteAdd()">Inserisci</button>'
    + (GR.sites.length
        ? '<div class="gr-list" style="margin-top:12px">' + GR.sites.map(function(k, i){
            const mm = grKw(k);
            return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">'
              + (mm.m === 'content' ? '🔤' : (mm.m === 'url' ? '📄' : '🌐')) + '</span>'
              + '<span class="ff-pickname">' + esc(mm.t) + '</span>'
              + '<button type="button" class="ub-modetag ub-m-' + mm.m + '" onclick="grOpenMode(' + i + ')">' + esc(grModeLabel(mm.m)) + '<i class="ub-caret"></i></button>'
              + '<button type="button" class="ff-rm" onclick="grSiteDel(' + i + ')" aria-label="Togli">✕</button></div>';
          }).join('') + '</div>'
        : '<p class="ff-empty">Il sito su cui lavori lascialo fuori: è quello che devi vedere a colori.</p>');

  box.innerHTML = app + siti;
  grPaintModeBtn();
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}

/* ---- le app ---- */

async function grOpenApps(){
  goId('s-greyapps');
  grPaintApps();
  await grLoadApps(true);
  grPaintApps();
}

function grPaintApps(){
  const box = document.getElementById('grList');
  if (!box) return;
  if (!GR_APPS){ box.innerHTML = '<p class="ff-empty">Leggo le app del telefono…</p>'; return; }
  if (!GR_APPS.length){ box.innerHTML = '<p class="ff-empty">Nessuna app da elencare.</p>'; return; }
  box.innerHTML = GR_APPS.map(function(a){
    const on = GR.apps.indexOf(a.packageName) >= 0;
    const letter = esc((a.label || '?').charAt(0).toUpperCase());
    return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
      + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>' + (a.alias ? '<span class="ff-alias" hidden>' + esc(a.alias) + '</span>' : '')
      + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '')
      + ' onchange="grToggleApp(this)"></label>';
  }).join('');
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
  grFilter();
}

function grToggleApp(cb){
  const i = GR.apps.indexOf(cb.value);
  if (cb.checked && i < 0) GR.apps.push(cb.value);
  if (!cb.checked && i >= 0) GR.apps.splice(i, 1);
  grSave();
}

function grRemoveApp(pkg){
  GR.apps = GR.apps.filter(function(x){ return x !== pkg; });
  grSave(); grPaintAlways();
}

function grFilter(){
  const inp = document.getElementById('grQ');
  const q = ((inp && inp.value) || '').toLowerCase();
  document.querySelectorAll('#grList .ff-pickrow').forEach(function(r){
    r.style.display = r.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
  });
}

function grAppLabel(pkg){
  const a = (GR_APPS || []).filter(function(x){ return x.packageName === pkg; })[0];
  return a ? (a.label || pkg) : String(pkg || '').split('.').pop();
}

/* ---- siti, indirizzi, parole ---- */

function grModeSrc(){
  return {
    list: function(){ return GR.sites; },
    normalize: function(){ GR.sites = GR.sites.map(grKw); },
    hints: GR_HINTS,
    after: function(){ grSave(); grPaintAlways(); }
  };
}

function grOpenMode(i){
  if (typeof ubOpenModeForList !== 'function'){ toast('Non disponibile in questa versione'); return; }
  ubOpenModeForList(typeof i === 'number' ? i : null, grModeSrc());
}

function grOnInput(){
  const v = ((document.getElementById('grSiteIn') || {}).value || '').trim().toLowerCase();
  if (typeof UB_MODE_TOUCHED !== 'undefined' && !UB_MODE_TOUCHED){
    UB_NEW_MODE = v.indexOf('/') >= 0 ? 'url'
      : ((typeof ubLooksLikeDomain === 'function' && ubLooksLikeDomain(v)) ? 'domain' : (v ? 'content' : 'domain'));
  }
  grPaintModeBtn();
}

function grPaintModeBtn(){
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const b = document.getElementById('grModeLbl');
  if (b) b.textContent = grModeLabel(m);
  const h = document.getElementById('grModeHint');
  if (h) h.textContent = GR_HINTS[m] || '';
}

function grModeLabel(m){
  if (typeof UB_MODES !== 'undefined' && UB_MODES[m]) return UB_MODES[m].label;
  return m === 'content' ? 'Nel contenuto della pagina' : (m === 'url' ? 'Ovunque nell\'URL' : 'Nel dominio');
}

function grSiteAdd(){
  const inp = document.getElementById('grSiteIn');
  let v = String(inp ? inp.value : '').trim().toLowerCase();
  if (!v){ toast('Scrivi un sito, un indirizzo o una parola'); return; }
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : (v.indexOf('/') >= 0 ? 'url' : 'domain');
  if (m === 'domain'){
    v = (typeof ubSiteNorm === 'function') ? ubSiteNorm(v) : v.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').split('/')[0];
    if (!v || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(v)){ toast('Per «nel dominio» serve un indirizzo, per esempio instagram.com'); return; }
  } else {
    v = v.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').replace(/\/+$/, '');
  }
  if (GR.sites.some(function(x){ return x.t === v && x.m === m; })){ toast('«' + v + '» è già in elenco'); return; }
  GR.sites.push({ t: v, m: m });
  if (inp) inp.value = '';
  if (typeof UB_MODE_TOUCHED !== 'undefined') UB_MODE_TOUCHED = false;
  grSave(); grPaintAlways();
}

function grSiteDel(i){
  GR.sites.splice(i, 1);
  grSave(); grPaintAlways();
}

/* ---------------------------------------------------------------------------------------
   PROGRAMMI: gli stessi della scheda Blocco, in un elenco che non blocca niente
   --------------------------------------------------------------------------------------- */

function grProgsOpen(){
  goId('s-greyprogs');
  grProgramsLoad();
  grPaintProgs();
}

function grPaintProgs(){
  const box = document.getElementById('grProgsBody');
  if (!box) return;
  box.innerHTML =
      '<p class="hintline" style="padding:0 2px 14px">Come «Modalità e routine»: a certe ore, in certi giorni, su una rete Wi-Fi o in un luogo, le app e i siti del programma diventano bianco e nero. Non vengono bloccati: perdono solo il colore.</p>'
    + (GR.programs.length
        ? GR.programs.map(function(p, i){
            const paused = p.on === false;
            return '<div class="gr-prog' + (paused ? ' off' : '') + '" onclick="grEditProgram(' + i + ')" role="button">'
              + '<span class="gr-prog-ico">' + (p.icon || '🌑') + '</span>'
              + '<div class="gr-prog-txt"><b>' + esc(p.name || 'Programma') + '</b>'
              + '<small>' + esc(typeof describeProgram === 'function' ? describeProgram(p) : '') + '</small></div>'
              + '<span class="gr-prog-pill">' + (paused ? 'IN PAUSA' : 'ATTIVO') + '</span>'
              + '<div class="gr-prog-btns">'
              +   '<button type="button" onclick="event.stopPropagation();grProgramToggle(' + i + ')">' + (paused ? '▶ Riprendi' : '⏸ Pausa') + '</button>'
              +   '<button type="button" class="del" onclick="event.stopPropagation();grProgramDelete(' + i + ')">Elimina</button>'
              + '</div></div>';
          }).join('')
        : '<p class="ff-empty">Nessun programma. Il primo può essere «dalle 21 alle 7, tutti i giorni»: la sera il telefono si spegne di colore da solo.</p>')
    + '<button type="button" class="cta" style="margin-top:16px" onclick="grNewProgram()">＋ Nuovo programma</button>';
}

function grNewProgram(){
  if (typeof newBlock !== 'function'){ toast('Non disponibile in questa versione'); return; }
  /* IL PARAMETRO NON È UN DETTAGLIO: `newBlock()` senza argomento azzera il contrassegno
     «questo è grigio», e il programma finiva fra i blocchi — bloccando davvero l'app invece di
     scolorirla. È successo, ed è il difetto peggiore che questa pagina potesse avere. */
  newBlock(true);
}

function grEditProgram(i){
  const p = GR.programs[i];
  if (!p || typeof openEditor !== 'function') return;
  window.BLK_GREY = true;
  DRAFT = JSON.parse(JSON.stringify(p));
  DRAFT.grey = true;
  DRAFT.idx = i;
  if (!Array.isArray(DRAFT.days) || DRAFT.days.length !== 7) DRAFT.days = [true, true, true, true, true, true, true];
  openEditor();
}

/* Chiamata da saveBlock() quando la bozza è grigia: il programma finisce qui, non fra i
   blocchi, e il motore di blocco non lo vede mai. */
function grSaveProgram(clean, idx){
  grProgramsLoad();
  if (idx >= 0 && GR.programs[idx]) GR.programs[idx] = clean; else GR.programs.push(clean);
  grSave();
}

function grAfterProgramSave(){
  grProgramsLoad();
  grProgsOpen();
}

async function grProgramToggle(i){
  const p = GR.programs[i]; if (!p) return;
  p.on = p.on === false;
  await grSave(); grPaintProgs();
}

async function grProgramDelete(i){
  const p = GR.programs[i]; if (!p) return;
  if (!(await blkEliminaChiedi())) return;
  const at = GR.programs.indexOf(p); if (at < 0) return;
  GR.programs.splice(at, 1);
  await grSave(); grPaintProgs();
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */

(function grStyle(){
  const css = [
    /* L'elenco riempie lo schermo: il .ff-picklist del timer si ferma a 42vh, e qui tagliava
       le app a quattro righe lasciando mezzo schermo vuoto sotto. */
    '.gr-list{margin-top:10px}',
    '.gr-warn{border:1px solid #E5515F;border-radius:20px;padding:16px;margin-bottom:14px;background:rgba(229,81,95,.05)}',
    '.gr-warn>b{display:block;font:800 15px var(--font-body);color:var(--navy);margin-bottom:6px}',
    'body.dark .gr-warn>b{color:#fff}',
    '.gr-warn>p{margin:0 0 12px;font:500 13px/1.55 var(--font-body);color:var(--muted)}',
    '.gr-steps{display:flex;flex-direction:column;gap:12px}',
    '.gr-steps>div{display:flex;gap:10px;align-items:flex-start;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.gr-steps i{flex:0 0 24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:700 12px/24px var(--font-body);text-align:center;font-style:normal}',
    '.gr-steps b{color:var(--navy)}',
    '.gr-why{font:600 11px/1.5 ui-monospace,Menlo,Consolas,monospace;background:rgba(14,35,80,.06);'
      + 'border-radius:10px;padding:10px 12px;color:#6B7A99;word-break:break-word}',
    'body.dark .gr-steps b{color:#fff}',
    /* la guida nuova: icone disegnate, allineate al testo */
    '.gr-ico{width:1.15em;height:1.15em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;vertical-align:-0.2em;flex:0 0 auto}',
    '.gr-chev{width:.9em;height:.9em;margin:0 3px;vertical-align:-0.1em;stroke-width:2.6;opacity:.55}',
    '.gr-warn>b.gr-tit{display:flex;align-items:center;gap:8px;margin-bottom:8px}',
    '.gr-warn>b.gr-tit .gr-ico{color:#E5515F;width:20px;height:20px}',
    '.gr-guida{border-color:rgba(0,117,227,.35);background:rgba(0,117,227,.04)}',
    '.gr-guida>b.gr-tit .gr-ico{color:#0075E3}',
    '.gr-step>span{flex:1;min-width:0}',
    '.gr-step>span>b{display:block;margin-bottom:3px}',
    '.gr-step small{display:block;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.gr-step i .gr-ico{width:14px;height:14px;vertical-align:-2px;stroke-width:3}',
    '.gr-step.fatto i{background:#1BA672}',
    '.gr-step.fatto b{opacity:.75}',
    '.gr-stepbtn{display:inline-flex;align-items:center;gap:8px;margin-top:10px;border:0;border-radius:12px;padding:10px 14px;background:#0075E3;color:#fff;font:700 13px/1 var(--font-body);cursor:pointer}',
    '.gr-stepbtn-lieve{background:rgba(0,117,227,.10);color:#0075E3}',
    'body.dark .gr-stepbtn-lieve{background:rgba(255,255,255,.10);color:#fff}',
    '.gr-nota{display:block;font-style:normal;color:#E5515F;font-weight:600}',
    '.gr-stato{margin:14px 0 0;padding:10px 12px;border-radius:12px;background:rgba(0,117,227,.08);font:600 13px/1.5 var(--font-body);color:var(--navy)}',
    '.gr-stato-no{background:rgba(229,81,95,.08);color:#C23B4A}',
    'body.dark .gr-stato{color:#fff}',
    '.gr-ricontrolla{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin-top:14px}',
    '.gr-pc{margin-top:16px;border-top:1px solid var(--line);padding-top:12px}',
    '.gr-pc>summary{display:flex;align-items:center;gap:8px;cursor:pointer;list-style:none;font:600 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.gr-pc>summary::-webkit-details-marker{display:none}',
    '.gr-pc[open]>summary{margin-bottom:12px}',
    '.gr-pcintro{margin:0 0 10px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.gr-cmd{display:block;margin-top:6px;padding:8px 10px;border-radius:10px;background:rgba(14,35,80,.06);font:600 11.5px/1.5 ui-monospace,Menlo,Consolas,monospace;color:var(--navy);word-break:break-all;user-select:all}',
    'body.dark .gr-cmd{background:rgba(255,255,255,.08);color:#fff}',
    '.gr-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}',
    '.gr-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 8px 6px 12px;border-radius:99px;background:rgba(0,117,227,.10);color:var(--navy);font:600 12.5px/1 var(--font-body)}',
    'body.dark .gr-chip{background:rgba(255,255,255,.08);color:#fff}',
    '.gr-chip button{border:0;background:transparent;color:var(--muted);font:700 12px/1 var(--font-body);cursor:pointer;padding:2px 4px}',
    '.gr-addrow{display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:6px 6px 6px 14px}',
    'body.dark .gr-addrow{background:#12203A;border-color:#22345A}',
    '.gr-addrow input{flex:1;min-width:0;border:0;outline:0;background:transparent;font:500 14px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .gr-addrow input{color:#fff}',
    '.gr-modebtn{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;border:0;border-radius:10px;padding:9px 11px;background:rgba(14,35,80,.06);color:var(--navy);font:700 12px/1 var(--font-body);cursor:pointer;white-space:nowrap}',
    'body.dark .gr-modebtn{background:rgba(255,255,255,.10);color:#fff}',
    '.gr-prog{display:grid;grid-template-columns:auto 1fr auto;gap:10px 12px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:20px;padding:14px;margin-bottom:10px;cursor:pointer}',
    'body.dark .gr-prog{background:#12203A;border-color:#22345A}',
    '.gr-prog.off{opacity:.62}',
    '.gr-prog-ico{font-size:22px}',
    '.gr-prog-txt b{display:block;font:700 15px var(--font-body);color:var(--navy)}',
    'body.dark .gr-prog-txt b{color:#fff}',
    '.gr-prog-txt small{display:block;margin-top:2px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.gr-prog-pill{font:800 10px/1 var(--font-body);letter-spacing:.06em;color:#0075E3;background:rgba(0,117,227,.12);padding:6px 9px;border-radius:99px}',
    '.gr-prog.off .gr-prog-pill{color:var(--muted);background:rgba(14,35,80,.07)}',
    '.gr-prog-btns{grid-column:1/-1;display:flex;gap:8px}',
    '.gr-prog-btns button{flex:1;border:0;border-radius:12px;padding:9px 0;background:rgba(14,35,80,.06);color:var(--navy);font:700 12px/1 var(--font-body);cursor:pointer}',
    'body.dark .gr-prog-btns button{background:rgba(255,255,255,.08);color:#fff}',
    '.gr-prog-btns button.del{color:#E5515F}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* L'interruttore del mantra a colori: vive nelle impostazioni del motore, perche' e' il
   servizio a doverlo leggere nel momento in cui disegna la card — la pagina web li' non c'e'. */
async function grToggleMantraColori(){
  const ora = (typeof SETTINGS !== 'undefined') && SETTINGS.mantraColori;
  if (typeof settingsSave === 'function') await settingsSave({ mantraColori: !ora });
  grPaint();
  if (typeof toast === 'function'){
    toast(!ora ? 'Il mantra arrivera\' a colori' : 'Il mantra resta in bianco e nero');
  }
}

/* La cartella accesa si vede: bordo blu, come una scelta fatta. Le tre cartelle scorrono in
   orizzontale come nella pagina Categorie, che e' lo stesso disegno. */
(function grStyleColori(){
  const st = document.createElement('style');
  /* LA TERZA CARTELLA SI DEVE INTRAVEDERE. Con tre cartelle da 158px la terza stava tutta
     fuori dallo schermo, e una riga che scorre di lato senza che se ne veda il bordo e' una
     riga che non scorre. Qui le cartelle sono larghe due e mezzo per riga: la terza sbuca. */
  st.textContent = '.grp-card.grp-on{border-color:var(--blue);box-shadow:0 0 0 2px rgba(0,117,227,.18)}\n'
    + '#grBody .grp-card{width:calc((100% - 34px) / 2.4)}';
  document.head.appendChild(st);
})();
