/* ===========================================================================================
   IL VAR DEI PUNTI (0.9.397)

   Andrea: "quando l'app da' o toglie un punto, l'utente lo deve poter contestare, come il capitano
   che va dall'arbitro e il VAR che annulla un gol per fuorigioco".

   DAL PUNTO DI VISTA DELL'UTENTE.
   · Il cartello del punto (start.js, mtCartello) e ogni riga del registro dei punti (insights.js)
     hanno "Chiedi il VAR". Il tocco apre la chat del Genio sopra la pagina con il caso gia' scritto
     nel campo: quale punto, quando, il motivo dell'app, i dati che l'app ha visto, e in fondo
     "Perche' lo contesto:", dove lui scrive le sue ragioni. Parte solo quando tocca invio.
   · Il Genio rivede la decisione con i dati veri: quelli che contano NON sono quelli del messaggio
     (si possono cambiare), sono quelli che l'app mette nel brief (varBrief: il registro dei punti,
     e per il caso aperto le sessioni, gli orari, le regole della partita).
   · Il verdetto arriva come blocco ```json {"var": {"caso", "esito", "motivo"}}``` (dreammapVar.ts sul
     server): l'app lo applica e lo mostra sotto la risposta e in un cartello, in stile VAR:
     "Decisione confermata", "Punto annullato", "Punto spostato al nuovo te".

   LE SERRATURE (qui, non nel prompt: il prompt si puo' sbagliare, l'app no).
   1. Il punto deve esistere davvero nel registro di QUESTO dispositivo (fl_match_hist, la riga
      nata qui e non importata): il codice del caso e' chi-ora-dispositivo. Un codice inventato o
      copiato male non tocca niente.
   2. Un punto si rivede una volta sola: dopo il verdetto (anche "confermata") e' chiuso.
   3. Tre revisioni al giorno (VAR_MAX_GIORNO): la quarta decisione non si applica.
   4. Il VAR non crea punti: annulla o sposta quel punto, con i suoi punti (e.punti), mai uno di piu'.
      Un punto gia' nato da un verdetto del VAR non si rivede (niente ping-pong).
   5. Si rivedono i punti degli ultimi 7 giorni della partita in corso (con "una partita al giorno"
      o "a tempo" solo quelli di oggi: quelli di ieri sono in un risultato gia' chiuso).
   6. Un verdetto si applica una volta per messaggio (fl_var.msgs), anche se la chat si ridisegna,
      e mai da un messaggio di piu' di tre giorni fa.
   =========================================================================================== */

const VAR_KEY = 'fl_var';
const VAR_MAX_GIORNO = 3;
const VAR_GIORNI = 7;
const VAR_ESITI = ['confermato', 'annullato', 'spostato'];
const VAR_IC = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="12.5" rx="2.2"/><path d="M8.5 20.5h7M12 17v3.5"/><path d="M10.2 8.4l4.4 2.4-4.4 2.4z" fill="currentColor" stroke="none"/></svg>';

function varEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function varLeggi(){
  let v = null;
  try{ v = JSON.parse(localStorage.getItem(VAR_KEY) || 'null'); }catch(_){ }
  if (!v || typeof v !== 'object') v = {};
  v.decisi = v.decisi || {}; v.msgs = v.msgs || {}; v.giorni = v.giorni || {}; v.richieste = v.richieste || {};
  return v;
}
function varScrivi(v){
  /* si tengono le ultime: un registro che cresce per sempre non serve a nessuno */
  try{
    const taglia = function(o, n){ const k = Object.keys(o); if (k.length > n) k.sort(function(a, b){ return ((o[a] && o[a].at) || o[a] || 0) - ((o[b] && o[b].at) || o[b] || 0); }).slice(0, k.length - n).forEach(function(x){ delete o[x]; }); };
    taglia(v.decisi, 200); taglia(v.msgs, 200); taglia(v.richieste, 40);
    const g = Object.keys(v.giorni).sort(); g.slice(0, Math.max(0, g.length - 14)).forEach(function(x){ delete v.giorni[x]; });
    localStorage.setItem(VAR_KEY, JSON.stringify(v));
  }catch(_){ }
}
function varOggi(t){ return (typeof mgDayKey === 'function') ? mgDayKey(t) : new Date(t || Date.now()).toISOString().slice(0, 10); }
function varDev(){ try{ return (typeof lsDevId === 'function') ? String(lsDevId()).slice(-6) : 'qui'; }catch(_){ return 'qui'; } }
/** Il codice di un punto: chi (n, o, r) - l'ora in base 36 - il dispositivo dove e' nato. */
function varChiave(e){
  if (!e || !e.at) return '';
  const c = e.chi === 'neo' ? 'n' : e.chi === 'old' ? 'o' : e.chi === 'revoca' ? 'r' : '';
  return c ? c + '-' + Number(e.at).toString(36) + '-' + varDev() : '';
}
function varUsateOggi(){ return +varLeggi().giorni[varOggi()] || 0; }
function varRestanti(){ return Math.max(0, VAR_MAX_GIORNO - varUsateOggi()); }

/** L'evento del registro con quel codice, se e' nato qui: { e, g (il giorno), hist }. */
function varTrova(chiave){
  const k = String(chiave || '').trim();
  if (!/^[nor]-[0-9a-z]{6,12}-[0-9a-z]{1,6}$/.test(k)) return null;
  const hist = (typeof mgHist === 'function') ? mgHist() : [];
  for (let gi = hist.length - 1; gi >= 0; gi--){
    const ev = hist[gi].eventi || [];
    for (let i = 0; i < ev.length; i++){
      const e = ev[i];
      if (e && !e.da && varChiave(e) === k) return { e: e, g: hist[gi], hist: hist };
    }
  }
  return null;
}
/** Si puo' chiedere il VAR su questo punto? '' se si', altrimenti il perche'. */
function varBloccato(e){
  if (!e) return 'assente';
  if (e.da) return 'altrove';
  if (['neo', 'old', 'revoca'].indexOf(e.chi) < 0) return 'tipo';
  if (e.var && e.var.da) return 'davar';
  if (e.var || varLeggi().decisi[varChiave(e)]) return 'gia';
  if (e.stornato) return 'tolto';
  const ora = Date.now();
  let stag = 'campionato'; try{ stag = (typeof mgCfg === 'function' && mgCfg().season) || 'campionato'; }catch(_){ }
  if (stag !== 'campionato' && varOggi(e.at) !== varOggi(ora)) return 'chiuso';
  if (ora - e.at > VAR_GIORNI * 864e5) return 'chiuso';
  try{ if (typeof lsMine === 'function' && typeof lsEpocaT === 'function'){ const t0 = lsEpocaT(lsMine().epoch); if (t0 && e.at < t0) return 'chiuso'; } }catch(_){ }
  return '';
}
const VAR_NO = {
  assente: 'Questo punto non c’è nel registro di questo dispositivo.',
  altrove: 'Questo punto è nato su un altro dispositivo: il VAR si chiede da lì.',
  tipo: 'Questa riga non è un punto: il VAR non la rivede.',
  davar: 'Questo punto l’ha già deciso il VAR.',
  gia: 'Il VAR ha già rivisto questo punto: un punto si rivede una volta sola.',
  tolto: 'Questo punto è già stato tolto.',
  chiuso: 'Questo punto appartiene a una partita già chiusa.',
  limite: 'Hai usato le tre revisioni del VAR di oggi. Domani se ne aprono altre tre.'
};
function varPuoChiedere(e){ return !varBloccato(e) && varRestanti() > 0; }

/* ---------------------------------------------------------------- il caso: i dati che l'app ha visto */
function varOra(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function varQuando(t){
  const oggi = varOggi(), g = varOggi(t), ieri = varOggi(Date.now() - 864e5);
  if (g === oggi) return 'oggi alle ' + varOra(t);
  if (g === ieri) return 'ieri alle ' + varOra(t);
  const d = new Date(t);
  return 'il ' + d.getDate() + ' ' + ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()] + ' alle ' + varOra(t);
}
function varNomi(){
  let v = 'il vecchio te', n = 'il nuovo te';
  try{ if (typeof inVecchio === 'function') v = inVecchio() || v; if (typeof inNuovo === 'function') n = inNuovo() || n; }catch(_){ }
  return { vecchio: v, nuovo: n };
}
function varMotivo(e){ return String((e && e.motivo) || 'senza motivo registrato').replace(/\s*\(×\d+[^)]*\)\s*$/, '').trim(); }
/** "1 punto al vecchio te", "2 punti al nuovo te", "1 punto tolto al nuovo te" */
function varCosa(e){
  const n = Math.max(1, Math.round(+e.punti || 1)), nm = varNomi(), p = n === 1 ? '1 punto' : n + ' punti';
  if (e.chi === 'revoca') return p + (n === 1 ? ' tolto ' : ' tolti ') + (String(nm.nuovo).replace(/^il /, 'al ').replace(/^la /, 'alla '));
  return p + ' ' + String(e.chi === 'old' ? nm.vecchio : nm.nuovo).replace(/^il /, 'al ').replace(/^la /, 'alla ');
}
/** I dati su cui si basava il punto: le sessioni intorno a quell'ora, la deviazione, le regole della partita, il resto del giorno. */
function varDati(e, g){
  const r = [];
  try{
    const c = (typeof mgCfg === 'function') ? mgCfg() : {};
    r.push('Regole della partita: livello ' + (c.severity || 'normale') + '; il vecchio te segna quando molli: ' + (c.oldScores === false ? 'no' : 'sì') + '; la riga spuntata vale solo con una sessione: ' + (c.tickNeedsSession === false ? 'no' : 'sì') + '.');
  }catch(_){ }
  try{
    const ff = (typeof ffHist === 'function') ? ffHist() : JSON.parse(localStorage.getItem('fl_ff_hist') || '[]');
    const vicine = (ff || []).filter(function(x){ return x && x.at && x.at >= e.at - 6 * 36e5 && x.at <= e.at + 3 * 60000; }).slice(-3);
    if (vicine.length) r.push('Sessioni di Full Focus vicine: ' + vicine.map(function(x){
      const fatti = Math.round((+x.spentMs || 0) / 60000);
      return 'finita alle ' + varOra(x.at) + ', ' + fatti + ' minuti fatti su ' + (x.minPrevisti || x.min || 0) + ' scelti, '
        + (x.ok ? 'portata a termine' : 'mollata') + (x.daSola ? ', andata avanti da sola senza la pagina di Full Focus aperta' : '')
        + (x.presenzaMs ? ', presente ' + Math.round(x.presenzaMs / 60000) + ' minuti' : '') + (x.intent ? ', intenzione "' + String(x.intent).slice(0, 60) + '"' : '');
    }).join('; ') + '.');
    else r.push('Sessioni di Full Focus nelle sei ore prima: nessuna.');
  }catch(_){ }
  try{
    if (/^fuori rotta/i.test(String(e.motivo || ''))){
      const dv = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || [];
      const m = String(e.motivo).replace(/^fuori rotta:\s*/i, '');
      const x = dv.filter(function(d){ return d && String(d.motivo || '') === m; }).pop();
      if (x) r.push('La richiesta fuori rotta l’ha vista l’arbitro sul computer alle ' + varOra(x.at) + (x.minuti ? ', ' + x.minuti + ' minuti di lavoro' : '') + '.');
    }
  }catch(_){ }
  try{
    let neo = 0, old = 0;
    ((g && g.eventi) || []).forEach(function(x){ if (!x || x.stornato) return; const n = +x.punti || 1; if (x.chi === 'neo') neo += n; else if (x.chi === 'old') old += n; });
    r.push('Quel giorno: ' + neo + (neo === 1 ? ' punto' : ' punti') + ' al nuovo te e ' + old + (old === 1 ? ' punto' : ' punti') + ' al vecchio te.');
  }catch(_){ }
  return r.join(' ');
}
/** Il messaggio che si scrive nel campo della chat: lui lo legge, ci aggiunge le sue ragioni, lo manda. */
function varCasoTesto(e, g){
  return 'Chiedo il VAR su questo punto.\n'
    + 'Il punto: ' + varCosa(e) + ', ' + varQuando(e.at) + '.\n'
    + 'Il motivo dell’app: "' + varMotivo(e) + '".\n'
    + 'I dati che l’app ha visto: ' + varDati(e, g) + '\n'
    + 'Codice del punto: ' + varChiave(e) + '\n'
    + 'Perché lo contesto: ';
}

/* ---------------------------------------------------------------- il brief: i dati veri, per il Genio */
function varBrief(){
  try{
    const hist = (typeof mgHist === 'function') ? mgHist() : [];
    const v = varLeggi(), l = [];
    hist.slice(-VAR_GIORNI).forEach(function(g){ (g.eventi || []).forEach(function(e){ if (e && !e.da && varChiave(e)) l.push({ e: e, g: g }); }); });
    if (!l.length) return '';
    l.sort(function(a, b){ return b.e.at - a.e.at; });
    const righe = l.slice(0, 12).map(function(x){
      const e = x.e, b = varBloccato(e);
      const stato = e.var ? 'deciso dal VAR: ' + e.var.esito : b === 'tolto' ? 'già tolto' : b === 'chiuso' ? 'partita chiusa, non si rivede' : b === 'davar' ? 'nato da un verdetto del VAR' : 'si può rivedere';
      return '  ' + varChiave(e) + ' | ' + varCosa(e) + ' | ' + varQuando(e.at) + ' | "' + varMotivo(e).slice(0, 90) + '" | ' + stato;
    });
    const out = ['IL VAR DEI PUNTI: revisioni usate oggi ' + varUsateOggi() + ' su ' + VAR_MAX_GIORNO + '. I punti veri del registro (codice | punto | quando | motivo dell’app | stato):'].concat(righe);
    /* i casi chiesti nelle ultime 24 ore e non ancora decisi: con i dati, cosi' il Genio decide su quelli e non sul messaggio */
    Object.keys(v.richieste).filter(function(k){ return Date.now() - (+v.richieste[k] || 0) < 864e5 && !v.decisi[k]; }).slice(-2).forEach(function(k){
      const t = varTrova(k); if (!t) return;
      out.push('IL CASO APERTO ' + k + ': ' + varCosa(t.e) + ', ' + varQuando(t.e.at) + ', motivo "' + varMotivo(t.e).slice(0, 140) + '". ' + varDati(t.e, t.g));
    });
    return out.join('\n').slice(0, 3000);
  }catch(_){ return ''; }
}

/* ---------------------------------------------------------------- chiedere il VAR */
function varChiedi(chiave){
  const t = varTrova(chiave);
  const b = t ? varBloccato(t.e) : 'assente';
  if (b || !varRestanti()){ if (typeof toast === 'function') toast(VAR_NO[b || 'limite']); return false; }
  try{ if (typeof mtGoalClose === 'function') mtGoalClose(); }catch(_){ }
  const v = varLeggi(); v.richieste[chiave] = Date.now(); varScrivi(v);
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  const testo = varCasoTesto(t.e, t.g);
  const titolo = 'Il VAR: ' + varMotivo(t.e).slice(0, 40);
  (async function(){
    let fatto = false;
    try{ if (typeof agPopover === 'function') fatto = await agPopover(testo, { titolo: titolo }); }catch(_){ }
    if (!fatto){ try{ if (typeof agNuovaConversazione === 'function') await agNuovaConversazione(testo, { titolo: titolo }); }catch(_){ } }
  })();
  return true;
}
/** Una riga del registro toccata: il cartello di quel punto, con il VAR se si puo' chiedere. */
function varRiga(chiave){
  const t = varTrova(chiave); if (!t || typeof mtCartello !== 'function') return;
  mtCartello({ tipo: t.e.chi === 'old' ? 'old' : t.e.chi === 'revoca' ? 'revoca' : 'neo', ev: t.e, fermo: true, registro: false });
}

/* ---------------------------------------------------------------- il verdetto */
/** Sposta il tabellone: d = { neo, old } (positivi o negativi). Il conto di questo dispositivo sul tabellone condiviso segue,
    altrimenti alla sincronizzazione successiva il punto tornerebbe da solo (come pkTogli e acAnnulla). */
function varTabellone(d){
  try{
    if (typeof mtRoll !== 'function' || typeof mtWrite !== 'function') return;
    const s = mtRoll();
    s.neo = Math.max(0, (s.neo || 0) + (d.neo || 0)); s.old = Math.max(0, (s.old || 0) + (d.old || 0));
    mtWrite(typeof MT_KEY !== 'undefined' ? MT_KEY : 'fl_match', s);
    if (typeof lsMine === 'function' && typeof lsWrite === 'function'){
      const m = lsMine();
      m.neo = Math.max(0, (m.neo || 0) + (d.neo || 0)); m.old = Math.max(0, (m.old || 0) + (d.old || 0));
      if (m.seen){ m.seen.neo = Math.max(0, (m.seen.neo || 0) + (d.neo || 0)); m.seen.old = Math.max(0, (m.seen.old || 0) + (d.old || 0)); }
      lsWrite(m);
      if (typeof lsPushSoon === 'function') lsPushSoon();
    }
    if (typeof mtPaint === 'function') mtPaint();
  }catch(_){ }
}
/**
 * Applica il blocco {"var": {...}} di una risposta del Genio. Una volta sola per messaggio (msgId) e per punto.
 * Torna { stato: 'ok' | il perche' no, esito, caso, motivo, cosa, nuovo (true solo la prima volta) }.
 */
function varApplica(az, msgId, msgAt){
  const v = varLeggi();
  const idm = String(msgId || '');
  if (idm && v.msgs[idm]) return Object.assign({}, v.msgs[idm], { nuovo: false });
  const fine = function(o){ o.at = Date.now(); if (idm){ v.msgs[idm] = o; varScrivi(v); } return Object.assign({}, o, { nuovo: o.stato === 'ok' }); };
  const a = (az && typeof az === 'object') ? az : {};
  const caso = String(a.caso || a.codice || '').trim();
  const esito = String(a.esito || '').trim().toLowerCase();
  const motivo = String(a.motivo || '').replace(/\s+/g, ' ').trim().slice(0, 240);
  if (VAR_ESITI.indexOf(esito) < 0) return fine({ stato: 'nonvalido', caso: caso, esito: esito, motivo: motivo });
  if (msgAt && Date.now() - msgAt > 3 * 864e5) return fine({ stato: 'scaduto', caso: caso, esito: esito, motivo: motivo });
  const t = varTrova(caso);
  if (!t){
    const dev = caso.split('-')[2];
    return fine({ stato: dev && dev !== varDev() ? 'altrove' : 'assente', caso: caso, esito: esito, motivo: motivo });
  }
  const e = t.e, cosa = varCosa(e), punto = varMotivo(e);
  const b = varBloccato(e);
  if (b) return fine({ stato: b, caso: caso, esito: esito, motivo: motivo, cosa: cosa, punto: punto });
  if (varUsateOggi() >= VAR_MAX_GIORNO) return fine({ stato: 'limite', caso: caso, esito: esito, motivo: motivo, cosa: cosa, punto: punto });
  if (esito === 'spostato' && e.chi === 'revoca') return fine({ stato: 'nonvalido', caso: caso, esito: esito, motivo: motivo, cosa: cosa, punto: punto });

  const n = Math.max(1, Math.round(+e.punti || 1));
  e.var = { esito: esito, at: Date.now(), motivo: motivo.slice(0, 160), msg: idm };
  if (esito !== 'confermato') e.stornato = true;
  try{ localStorage.setItem(typeof MG_HIST !== 'undefined' ? MG_HIST : 'fl_match_hist', JSON.stringify(t.hist)); }catch(_){ }
  let verso = '';
  if (esito === 'annullato'){
    if (e.chi === 'neo') varTabellone({ neo: -n });
    else if (e.chi === 'old') varTabellone({ old: -n });
    else varTabellone({ neo: n });                       // la revoca annullata: il punto torna al nuovo te
  } else if (esito === 'spostato'){
    verso = e.chi === 'old' ? 'neo' : 'old';
    /* il punto dall'altra parte: una riga nuova nel registro, segnata come nata dal VAR (non si rivede) */
    try{ if (typeof mgLog === 'function') mgLog(verso, 'Dal VAR: ' + punto, Object.assign({ var: { da: caso, esito: 'spostato', at: Date.now() } }, n > 1 ? { punti: n } : {})); }catch(_){ }
    varTabellone(verso === 'neo' ? { neo: n, old: -n } : { old: n, neo: -n });
  }
  v.decisi[caso] = { esito: esito, at: Date.now(), msg: idm };
  v.giorni[varOggi()] = (+v.giorni[varOggi()] || 0) + 1;
  delete v.richieste[caso];
  return fine({ stato: 'ok', caso: caso, esito: esito, motivo: motivo, cosa: cosa, punto: punto, verso: verso, chi: e.chi });
}
function varTitolo(r){
  const nm = varNomi();
  if (r.esito === 'confermato') return 'Decisione confermata';
  if (r.esito === 'annullato') return r.chi === 'revoca' ? 'Revoca annullata' : 'Punto annullato';
  if (r.esito === 'spostato') return 'Punto spostato ' + String(r.verso === 'neo' ? nm.nuovo : nm.vecchio).replace(/^il /, 'al ').replace(/^la /, 'alla ');
  return 'Decisione del VAR';
}
const VAR_NON_APPLICATA = {
  nonvalido: 'La decisione non è valida: il punto resta com’era.',
  scaduto: 'La decisione è di più di tre giorni fa: il punto resta com’era.',
  assente: 'Il codice non corrisponde a nessun punto del registro: il punto resta com’era.',
  altrove: 'Il punto è nato su un altro dispositivo: la decisione vale lì.',
  tipo: 'Questa riga non è un punto: il punto resta com’era.',
  davar: 'Questo punto l’ha già deciso il VAR: resta com’è.',
  gia: 'Il VAR aveva già rivisto questo punto: resta la prima decisione.',
  tolto: 'Questo punto era già stato tolto.',
  chiuso: 'Il punto appartiene a una partita già chiusa: resta com’era.',
  limite: 'Le tre revisioni di oggi sono finite: il punto resta com’era.'
};
/** Sotto la risposta del Genio: il verdetto, applicato la prima volta che la risposta si vede (o arriva). */
function varAgenteHtml(az, msgId, msgAt){
  const r = varApplica(az, msgId, msgAt);
  if (r.nuovo) varAnnuncia(r);
  const ok = r.stato === 'ok';
  const cls = ok ? (r.esito === 'confermato' ? 'conf' : 'giu') : 'no';
  return '<div class="var-v ' + cls + '" role="status"><span class="var-v-tag">' + VAR_IC + 'VAR</span>'
    + '<b class="var-v-t">' + varEsc(ok ? varTitolo(r) : 'Decisione non applicata') + '</b>'
    + (r.cosa ? '<p class="var-v-p">' + varEsc(r.cosa.charAt(0).toUpperCase() + r.cosa.slice(1)) + (r.punto ? ': "' + varEsc(r.punto.slice(0, 90)) + '"' : '') + '</p>' : '')
    + (ok ? '' : '<p class="var-v-p">' + varEsc(VAR_NON_APPLICATA[r.stato] || VAR_NON_APPLICATA.nonvalido) + '</p>')
    + '</div>';
}
/** Il cartello della decisione, una volta sola: il momento in cui il VAR si gira verso il campo. */
function varAnnuncia(r){
  try{ if (typeof flVibra === 'function') flVibra(r.esito === 'confermato' ? 8 : 24); }catch(_){ }
  setTimeout(function(){
    try{ if (typeof mtCartello === 'function') mtCartello({ tipo: 'var', titolo: varTitolo(r), perche: r.motivo, punto: r.cosa ? r.cosa + ': "' + r.punto + '"' : '', fermo: true, verso: r.verso || '', esito: r.esito }); }catch(_){ }
  }, 700);
}
/** I verdetti arrivati mentre la chat non si vedeva (da Telegram, o con la pagina chiusa): si applicano alla sincronizzazione. */
function varDaMessaggi(){
  try{
    if (typeof agStato !== 'function') return;
    const v = varLeggi();
    (agStato().msgs || []).forEach(function(m){
      if (!m || m.direzione !== 'out' || !m.id || !m.azioni || !m.azioni.var || v.msgs[String(m.id)]) return;
      const r = varApplica(m.azioni.var, m.id, m.at);
      if (r.nuovo) varAnnuncia(r);
    });
  }catch(_){ }
}
(function(){
  if (typeof window === 'undefined') return;
  const monta = function(){
    const o = window.agSync;
    if (typeof o === 'function' && !o.__var){
      const w = async function(){ const r = await o.apply(this, arguments); varDaMessaggi(); return r; };
      w.__var = true; window.agSync = w;
    }
  };
  if (typeof document !== 'undefined' && document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else setTimeout(monta, 0);
})();

(function(){
  if (typeof document === 'undefined' || !document.head) return;
  const st = document.createElement('style');
  st.textContent = [
    /* il verdetto sotto la risposta: scuro in tutti e due i temi, il testo e' bianco fisso */
    '.var-v{margin:10px 0 4px;padding:16px 18px 16px;border-radius:18px;background:#0B1B3D;color:#fff;max-width:88%;box-sizing:border-box}',
    '.var-v-tag{display:inline-flex;align-items:center;gap:6px;padding:4px 10px 4px 8px;border-radius:999px;background:#FFD24A;color:#1A1300;font:900 11.5px/1 var(--font-body);letter-spacing:.14em}',
    '.var-v-tag svg{width:14px;height:14px}',
    '.var-v-t{display:block;margin-top:12px;font:800 19px/1.25 var(--font-display);color:#fff}',
    '.var-v.giu .var-v-t{color:#FFD24A}',
    '.var-v.no .var-v-t{color:rgba(255,255,255,.72)}',
    '.var-v-p{margin:8px 0 0;font:500 13.5px/1.45 var(--font-body);color:rgba(255,255,255,.74)}'
  ].join('\n');
  document.head.appendChild(st);
})();
