/* boot.js — la schermata di caricamento.

   COSA RISOLVE.
   All'avvio si vedeva una pagina bianca, a volte per parecchi secondi, e spesso spariva solo
   toccando lo schermo: segno che la pagina era già pronta e la WebView non aveva ancora
   disegnato niente. Nel frattempo, anche quando il bianco non c'era, la scheda Blocco compariva
   vuota — nessuna parola chiave, nessuna app, il pulsante "Inizia" al posto di "Stop" su un
   blocco rapido che era invece acceso — e il pannello del tempo di schermo arrivava dopo. Tutto
   questo perché quei dati li chiede il telefono e arrivano quando arrivano.

   LA SOLUZIONE è quella dei videogiochi: invece di nascondere l'attesa, la si occupa. Una
   schermata che c'è dal primo fotogramma (sta nell'HTML, non la crea nessuno script), una
   barra che avanza sui passi VERI del caricamento, e una frase diversa a ogni avvio. Chi
   aspetta tre secondi leggendo qualcosa che gli serve non ha aspettato: ha letto.

   TRE REGOLE, e valgono più della grafica:
   1. la barra dice la verità — avanza quando un pezzo è pronto davvero, non a tempo;
   2. c'è un tetto (5 secondi): una schermata di caricamento che non se ne va è peggio del
      bianco, perché il bianco almeno sembra un problema e non una scelta;
   3. all'uscita si forza il disegno, che è quello che il tocco faceva a mano. */

/* L'INGRANAGGIO DELLE IMPOSTAZIONI, UNO SOLO (0.9.359). Andrea: "a volte usiamo l'emoji dell'ingranaggio, a volte l'icona SVG,
   nel Blocco rapido c'e' un carattere che sembra un timone: ci deve essere sempre la stessa cosa, l'utente si abitua e non si
   confonde. E' una delle regole piu' importanti di UI". Ogni pulsante che apre delle impostazioni usa questo disegno (e i tre
   puntini restano solo per i menu con delle azioni). Prende il colore del testo intorno. */
function flIngranaggio(px){
  const s = px || 20;
  return '<svg class="fl-ingr" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
    + '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>'
    + '<circle cx="12" cy="12" r="3"/></svg>';
}
(function(){ const st = document.createElement('style'); st.textContent = '.fl-ingr{display:inline-block;flex:none;vertical-align:middle}'; document.head.appendChild(st); })();

/* Le frasi. Brevi: chi aspetta non legge un poema, e una frase lunga la si salta.
   0.9.363, la posizione di Andrea: le frasi brevi di persone famose, vive o morte, vanno bene come omaggio, con il nome e la
   frase giusta ("se lo fa Brain.fm, posso farlo anch'io"). Il divieto degli autori viventi scritto qui prima non era suo. */
const BOOT_LINES = [
  ['Ricorda che non ottenere ciò che vuoi a volte è un meraviglioso colpo di fortuna.', 'Dalai Lama'],
  ['Ogni progresso avviene fuori dalla zona di comfort.', 'Michael John Bobak'],
  /* L'unica di un autore vivente, e ci sta per scelta di Andrea: e' un aforisma di due righe
     citato ovunque, e dice in una frase quello che fa tutta questa app — il piano batte il
     talento. Da tenere presente solo prima della pubblicazione sullo store, dove le citazioni
     di autori viventi vanno verificate una per una. */
  ['Un idiota con un piano può battere un genio senza un piano.', 'Warren Buffett'],
  /* 0.9.369, scelte da Andrea (18/11/2026), con l'originale inglese */
  ['Troppi di noi non vivono i propri sogni perché vivono le proprie paure.', 'Les Brown', 'Too many of us are not living our dreams because we are living our fears.'],
  ['La tua mente diventa la tua prigione quando ti concentri sulla tua paura.', 'Tim Fargo', 'Your mind is your prison when you focus on your fear.'],
  ['Cambia la tua vita oggi. Non scommettere sul futuro. Agisci adesso, senza rimandare.', 'Simone de Beauvoir', 'Change your life today. Don’t gamble on the future, act now, without delay.'],
  /* scelte da Andrea (7/10/2026) */
  ['Se domani non dovesse esserci, faresti comunque quello che stai per fare oggi? Se la risposta è no, sei vivo, ma non stai vivendo.', 'Greg Plitt'],
  ['Ogni momento è un nuovo momento. Hai pagato per quello che eri ieri. Quello che sei oggi lo decidi tu.', 'Raymond Douglas Stanford'],
  ['Fai come Napoleone. Vedi solo l’obiettivo. L’ostacolo dovrà spostarsi.', 'Bob Proctor'],
  ['Cosa proveresti a fare, se sapessi di non poter fallire?', 'Robert H. Schuller'],
  ['Cosa sogneresti, se sapessi di non poter fallire? Un sogno piccolo costa la stessa fatica di uno grande.', 'Orrin Woodward'],
  /* scelte da Andrea (19/10/2026): sono anche frasi del giorno (scores.js, SC_SCELTE) */
  ['Il successo è andare da un fallimento all’altro senza perdere l’entusiasmo.', 'Winston Churchill'],
  ['Siamo ciò che facciamo ripetutamente; l’eccellenza, quindi, non è un atto, ma un’abitudine.', 'Will Durant'],
  ['Non abbiamo poco tempo. Ne perdiamo molto.', 'Seneca'],
  ['Mentre si rimanda, la vita passa.', 'Seneca'],
  ['Nessuno ti restituirà gli anni. Nessuno ti renderà a te stesso.', 'Seneca'],
  ['Non è che abbiamo poco tempo. È che ne sprechiamo molto.', 'Seneca'],
  ['Comincia. Il coraggio ha in sé genio e potere.', 'Goethe'],
  ['Le cose che contano di più non devono mai cedere a quelle che contano di meno.', 'Goethe'],
  ['Non rimandare a domani quello che puoi fare oggi.', 'Benjamin Franklin'],
  ['Il tempo perduto non si ritrova mai più.', 'Benjamin Franklin'],
  ['Ama la vita? Allora non sprecare il tempo. È la stoffa di cui è fatta.', 'Benjamin Franklin'],
  ['Chi insegue due conigli non ne prende nessuno.', 'Proverbio'],
  ['Un viaggio di mille miglia comincia con un passo.', 'Lao Tzu'],
  ['La natura non ha fretta, eppure tutto si compie.', 'Lao Tzu'],
  ['Non importa quanto vai piano, purché tu non ti fermi.', 'Confucio'],
  ['Il momento migliore per piantare un albero era vent’anni fa. Il secondo è adesso.', 'Proverbio'],
  ['La conoscenza non basta. Bisogna applicarla. Volere non basta. Bisogna fare.', 'Bruce Lee'],
  ['Chi è dappertutto non è in nessun posto.', 'Seneca'],
  ['Vivi come se dovessi morire domani. Impara come se dovessi vivere per sempre.', 'Gandhi'],
  ['Prima fai il necessario, poi il possibile. E all’improvviso stai facendo l’impossibile.', 'Francesco d’Assisi'],
  ['La disciplina è il ponte fra i sogni e i risultati.', 'Proverbio'],
  ['Se conosci il nemico e conosci te stesso, non temere il risultato di cento battaglie.', 'Sun Tzu'],
  ['Le occasioni si moltiplicano quando vengono colte.', 'Sun Tzu'],
  ['La fortuna è ciò che succede quando la preparazione incontra l’occasione.', 'Seneca'],
  ['Ogni cosa ha due manici. Da uno si può portare, dall’altro no.', 'Epitteto'],
  ['Non sono le cose a turbarci, ma le opinioni che ne abbiamo.', 'Epitteto'],
  ['Conosci te stesso.', 'Socrate'],
  ['La vita non esaminata non è degna di essere vissuta.', 'Socrate'],
  ['Fai ogni cosa come se fosse l’ultima della tua vita.', 'Marco Aurelio'],
  ['Hai potere sulla tua mente, non sugli eventi. Rendendotene conto, troverai la forza.', 'Marco Aurelio'],
  ['Smettila di discutere su cosa sia un uomo buono. Siilo.', 'Marco Aurelio'],
  ['L’ostacolo alla via diventa la via.', 'Marco Aurelio'],
  ['Chi ha un perché abbastanza forte sopporta quasi ogni come.', 'Nietzsche'],
  ['Chi guarda fuori sogna, chi guarda dentro si sveglia.', 'Carl Gustav Jung'],
  ['La perfezione si raggiunge quando non c’è più niente da togliere.', 'Antoine de Saint-Exupéry'],
  ['Un obiettivo senza un piano è solo un desiderio.', 'Antoine de Saint-Exupéry'],
  ['Le persone di successo prendono decisioni prontamente e le cambiano lentamente, se mai le cambiano.', 'Napoleon Hill'],
  /* 0.9.335, Andrea: simmetria, due righe gemelle con la virgola, non "e" in mezzo */
  ['La paura dice "E se...",\nla fede dice "Anche se..."', ''],
  ['Concentrarsi vuol dire saper dire di no.', 'Steve Jobs', 'Focus is about saying no.'],
  ['Il genio è un per cento ispirazione e novantanove per cento sudore.', 'Thomas Edison'],
  ['Non ho fallito. Ho solo trovato diecimila modi che non funzionano.', 'Thomas Edison'],
  ['Se il tuo domani sarà uguale a quello di ieri, avrai vissuto un giorno solo.', 'Gianluca Liguori'],
  ['La felicità è quando ciò che pensi, ciò che dici e ciò che fai sono in armonia.', 'Mahatma Gandhi'],
  ['L’unico modo di fare un gran lavoro è amare quello che fai.', 'Proverbio'],
  ['Fatto è meglio di perfetto.', 'Proverbio'],
  ['Chi vuole fare qualcosa trova un modo. Chi non vuole trova una scusa.', 'Proverbio arabo'],
  ['La goccia scava la pietra non con la forza, ma cadendo spesso.', 'Ovidio'],
  /* scelte da Andrea (22/10/2026): le brevi anche qui, le altre solo come frasi del giorno (scores.js, SC_SCELTE).
     Il terzo elemento e' l'originale inglese, per chi usa il telefono in inglese. */
  ['Tutto quello che non stai cambiando, lo stai scegliendo.', 'Laurie Buchanan', 'Whatever you are not changing, you are choosing.'],
  ['Noi siamo quello che scegliamo di essere. Ora scegli!', 'Green Goblin', 'We are who we choose to be. Now choose!'],
  ['La vita si restringe o si espande in proporzione al proprio coraggio.', 'Anaïs Nin', 'Life shrinks or expands in proportion to one\u2019s courage.'],
  ['Tutto ciò che hai sempre voluto è dall’altra parte della paura.', 'George Addair', 'Everything you\u2019ve ever wanted is on the other side of fear.'],
  ['L’unico limite a ciò che realizzeremo domani saranno i nostri dubbi di oggi.', 'Franklin D. Roosevelt', 'The only limit to our realization of tomorrow will be our doubts of today.'],
  ['Ogni battaglia viene vinta o persa prima ancora di essere combattuta.', 'Sun Tzu', 'Every battle is won or lost before it is ever fought.'],
  ['Non ci sono limiti. Ci sono solo plateau. Non devi restarci, devi andare oltre.', 'Bruce Lee', 'There are no limits. There are only plateaus, and you must not stay there, you must go beyond them.'],
  ['Presto e bene raramente vanno insieme.', 'Proverbio'],
  ['Sono un vecchio e ho avuto molti guai, la maggior parte dei quali non è mai accaduta.', 'Mark Twain'],
  ['Il segreto per andare avanti è cominciare.', 'Mark Twain'],
  ['Fra vent’anni sarai più deluso per le cose che non hai fatto che per quelle che hai fatto.', 'Mark Twain'],
  ['Chi rimanda l’ora di vivere bene è come il contadino che aspetta che il fiume finisca.', 'Orazio'],
  ['Cogli l’attimo, fidandoti il meno possibile del domani.', 'Orazio'],
  ['Il tempo è la moneta della tua vita. Spendila tu, o la spenderanno altri per te.', 'Carl Sandburg'],
  ['Due cose sono infinite, l’universo e la distrazione. E dell’universo non sono sicuro.', 'DreamMap'],
  ['Il telefono non ruba tempo. Lo chiede, e noi diciamo di sì.', 'DreamMap'],
  ['Una cosa alla volta. È tutto qui il segreto.', 'DreamMap'],
  ['Non devi vincere la giornata. Devi vincere la prossima ora.', 'DreamMap'],
  ['Quello che rimandi oggi lo pagherai domani, con gli interessi.', 'DreamMap'],
  ['Il lavoro si allarga fino a riempire il tempo che gli lasci.', 'Cyril N. Parkinson'],
  ['La concentrazione non è un talento. È una cosa che si allena.', 'DreamMap'],
  ['Chi controlla la sua attenzione controlla la sua vita.', 'DreamMap'],
  ['Il momento in cui non hai voglia è il momento che conta.', 'DreamMap'],
  ['Ogni notifica è una domanda. Non sei obbligato a rispondere.', 'DreamMap'],
  /* 0.9.343, Andrea */
  ['Quando cominci a camminare sulla via, la via appare.', 'Rumi'],
  ['Il conflitto esiste solo come opportunità per innalzare la nostra coscienza.', 'Carl Jung'],
  /* 0.9.394, Andrea: la frase di Buddha dello screenshot dei suoni per concentrarsi (anche al caricamento e fra le frasi del giorno) */
  ['Dubita di tutto. Trova la tua luce.', 'Buddha', 'Doubt everything. Find your own light.'],
  /* 0.9.397, Andrea: le frasi su sogni, parole e azioni, in tutte e tre le liste (caricamento, suoni per concentrarsi, frasi del giorno).
     Le inglesi sono tradotte dal 0.9.401 (BUG-204); l'autore e' quello verificato, altrimenti Anonimo */
  ['Vi hanno detto di essere realisti. Ma chi sogna in grande cambia il mondo. Chi è realista, di solito, diventa commercialista.', 'Anonimo', 'They told you to be realistic. But those who dream big change the world. Those who are realistic usually become accountants.'],
  ['Viviamo in un’epoca in cui se dici \'voglio cambiare il mondo\' ti ridono in faccia. E invece dovremmo abituarci a farlo tutti i giorni.', 'Anonimo', 'We live in an age when, if you say \'I want to change the world\', people laugh in your face. And yet we should get used to doing it every day.'],
  ['Il tuo dovere reale è di salvare il tuo sogno.', 'Amedeo Modigliani', 'Your real duty is to save your dream.'],
  ['Il sogno non è fuori, è dentro di noi. Guardando la Luna per sognare, fuori ne vediamo solo il riflesso.', 'Anonimo', 'The dream is not outside, it is within us: when we look at the Moon to dream, outside we only see its reflection.'],
  ['Tu sei ciò che fai, non ciò che dici che farai.', 'Anonimo', 'You are what you do, not what you say you’ll do.'],
  ['Le parole dimostrano chi vuoi essere, le azioni chi sei davvero.', 'Anonimo', 'Words show who you want to be; actions show who you really are.'],
  ['Quello che pensi diventi, quello che dici attrai, quello che fai ritorna. Niente accade per caso.', 'Anonimo', 'What you think, you become; what you say, you attract; what you do comes back to you. Nothing happens by chance.'],
  ['Le persone possono dubitare di ciò che dici, ma crederanno a ciò che fai.', 'Charles H. Spurgeon', 'Men may doubt what you say, but they will believe what you do.'],
  ['Quando non sai più che fare, chiedi aiuto a DreamMap.', 'DreamMap', 'When you don’t know what to do anymore, ask DreamMap for help.'],
  ['Quando non sai più che fare, lascia fare a Dio.', 'Anonimo', 'When you don’t know what to do anymore, let God do it.'],
  ['Le azioni mostrano chi sei davvero più delle parole. Ogni azione è una scelta, e ogni scelta è un voto per l’identità che vuoi.', 'Anonimo', 'Actions show who you really are more than words. Every action is a choice, and every choice is a vote for the identity you want.'],
  ['Quello che fai grida più forte di quello che dici.', 'Anonimo', 'What you do shouts louder than what you say.'],
  ['Il dialogo interiore conta, ma le tue azioni parleranno sempre più forte delle parole che ti ripeti o che racconti agli altri.', 'Anonimo', 'Your inner dialogue matters, but your actions will always speak louder than the words you repeat to yourself or tell others.'],
  ['Stai attento ai tuoi pensieri, perché diventeranno le tue parole. Stai attento alle tue parole, perché diventeranno le tue azioni. Stai attento alle tue azioni, perché diventeranno le tue abitudini. Stai attento alle tue abitudini, perché diventeranno il tuo carattere. Stai attento al tuo carattere, perché diventerà il tuo destino.', 'Anonimo', 'Watch your thoughts, for they become words. Watch your words, for they become actions. Watch your actions, for they become habits. Watch your habits, for they become character. Watch your character, for it becomes your destiny.'],
  ['Dirsi onesti, coraggiosi o affidabili conta poco se i gesti di ogni giorno vanno nella direzione opposta.', 'Anonimo', 'Calling yourself honest, brave or reliable counts for little if your everyday actions go the opposite way.'],
  ['Le persone si fidano di ciò che ti vedono fare, non di ciò che ti sentono dire.', 'Anonimo', 'People trust what they see you do, not what they hear you say.'],
  ['L’identità si costruisce agendo. Sono le abitudini e le scelte concrete a definire il carattere.', 'Anonimo', 'Identity is built by acting: habits and concrete choices are what define character.'],
  ['Allineare parole e comportamenti ti rende credibile, anche quando costa fatica.', 'Anonimo', 'Aligning your words and your behaviour makes you credible, even when it takes effort.'],
  /* 0.9.401 BUG-204, Andrea: "ogni frase in inglese va tradotta bene". Le sei frasi che restavano in inglese hanno l'italiano, e l'originale resta per chi ha il telefono in inglese */
  ['Il tuo peggior nemico non può farti del male quanto i tuoi pensieri, se non li sorvegli.', 'Buddha', 'Your worst enemy cannot harm you as much as your own unguarded thoughts.'],
  ['Scala la montagna per vedere il mondo, non perché il mondo veda te.', 'David McCullough Jr.', 'Climb the mountain so you can see the world, not so the world can see you.'],
  ['Preoccupati di quello che pensano gli altri e sarai sempre loro prigioniero.', 'Anonimo', 'Care about what other people think and you will always be their prisoner.'],
  ['Se vuoi elevare te stesso, eleva qualcun altro.', 'Booker T. Washington', 'If you want to lift yourself up, lift up someone else.'],
  ['Il nostro potenziale è sconfinato quando abbiamo il coraggio di crederci.', 'Anonimo', 'Our potential is boundless when we have the courage to believe in it.'],
  ['Se l’occasione non bussa, costruisci una porta.', 'Anonimo', 'If opportunity doesn’t knock, build a door.'],
  ['La caverna in cui hai paura di entrare custodisce il tesoro che cerchi.', 'Joseph Campbell', 'The cave you fear to enter holds the treasure you seek.'],
  ['Il compito di chi guida è creare altri leader, non altri seguaci.', 'Ralph Nader'],
  ['Raramente le persone hanno successo se non si divertono in quello che fanno.', 'Dale Carnegie'],
  ['Chiedi quello che vuoi, e preparati a ottenerlo.', 'Maya Angelou'],
  ['L’inizio è la parte più importante del lavoro.', 'Platone'],
  ['La calma non è assenza di rumore. È sapere cosa stai facendo.', 'DreamMap'],
  /* scelta da Andrea (14/11/2026) */
  ['Quello che fai fa la differenza, e devi decidere che tipo di differenza vuoi fare.', 'Jane Goodall'],
  /* 0.9.401 BUG-204, Andrea: Van Gogh (lo scrive al fratello Theo nel 1884, riprendendo Zola) e la Bhagavad Gita (17,3: "l'uomo e' fatto di fede"), in tutte e tre le liste */
  ['Preferisco morire di passione che di noia.', 'Vincent van Gogh', 'I would rather die of passion than of boredom.'],
  ['L’uomo è fatto della sua fede. Come crede, così è.', 'Bhagavad Gita', 'Man is made by his belief. As he believes, so he is.'],
  /* 0.9.402 BUG-210, Andrea: le due frasi di Denzel Washington, dal discorso ai laureati della Dillard University (New Orleans, 2015).
     La seconda nella traduzione di Andrea; niente due punti (dopo i due punti si va a capo), in tutte e tre le liste */
  ['Non confondere mai il movimento con il progresso, perché puoi correre sul posto e non arrivare da nessuna parte.', 'Denzel Washington', 'Never confuse movement with progress, because you can run in place and not get anywhere.'],
  ['I sogni senza obiettivi sono solo sogni e, alla fine, alimentano la delusione.', 'Denzel Washington', 'Dreams without goals are just dreams, and they ultimately fuel disappointment.'],
  /* 0.9.402 BUG-257, Andrea: le due frasi sul diavolo e sul passato, in tutte e tre le liste (di autore incerto: Anonimo) */
  ['Quando il diavolo ti ricorda il tuo passato, ricordagli il suo futuro.', 'Anonimo', 'When the devil reminds you of your past, remind him of his future.'],
  ['Se il diavolo ti invita sempre a guardare il tuo passato, ci deve essere qualcosa di meraviglioso nel tuo futuro che non vuole che tu veda.', 'Anonimo', 'If the devil is always inviting you to look at your past, there must be something wonderful in your future that he doesn’t want you to see.'],
  /* 0.9.403 BUG-275, Andrea: due frasi di Alex Hormozi e una di Walt Disney, in tutte e tre le liste. Nella seconda di Hormozi
     i due punti diventano una domanda (dopo i due punti si va a capo). La frase di Buddha c'era gia' in tutte e tre */
  ['Se hai tutte le informazioni per prendere una decisione perfetta, hai perso l’occasione.', 'Alex Hormozi', 'If you have all the information to make a perfect decision, you missed the opportunity.'],
  ['Come si resta poveri? Facendosi distrarre facilmente.', 'Alex Hormozi', 'How to stay poor? Be easily distracted.'],
  ['Il modo per cominciare è smettere di parlare e iniziare a fare.', 'Walt Disney', 'The way to get started is to quit talking and begin doing.']
];

const BOOT = { el: null, bar: null, pct: 0, shown: 0, done: false, timer: 0 };

/* Il passo avanti della barra. Non va mai indietro, non salta: arriva dove deve arrivare
   scorrendo, perché una barra che salta al 90% e resta lì sembra bloccata. */
function bootTo(p){
  BOOT.pct = Math.max(BOOT.pct, Math.min(1, p));
}

function bootPaint(){
  if (!BOOT.bar) return;
  /* si avvicina al valore vero di un quinto per fotogramma: morbido, e mai fermo del tutto */
  BOOT.shown += (BOOT.pct - BOOT.shown) * 0.2;
  if (BOOT.pct - BOOT.shown < 0.004) BOOT.shown = BOOT.pct;
  BOOT.bar.style.width = Math.round(BOOT.shown * 100) + '%';
  if (!BOOT.done) requestAnimationFrame(bootPaint);
}

function flMazzo(k, n){
  let m = []; try{ m = JSON.parse(localStorage.getItem(k) || '[]') || []; }catch(_){ m = []; }
  m = m.filter(function(i){ return i >= 0 && i < n; });
  if (!m.length){ m = []; for (let i = 0; i < n; i++) m.push(i); for (let i = n - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); const t = m[i]; m[i] = m[j]; m[j] = t; } }
  const v = m.shift(); try{ localStorage.setItem(k, JSON.stringify(m)); }catch(_){ }
  return v;
}
/* ===========================================================================================
   IL REGISTRO DELLE FRASI DI OGGI (0.9.401 BUG-204)
   Andrea: "la frase del giorno, quella di caricamento e quella dei suoni non sono mai la stessa nello stesso momento: ruotano e
   non si sovrappongono". Le liste hanno molte frasi in comune, e ognuna sceglieva per conto suo. Adesso ogni canale scrive qui
   cosa ha mostrato oggi, e quando sceglie salta le frasi gia' uscite oggi negli ALTRI canali:
     - giorno: la frase del giorno (scores.js, scQuoteFor). E' l'ancora: e' la stessa del sito e della schermata di blocco e non
       cambia mai; si segna anche quella di domani, cosi' il primo caricamento del giorno la conosce gia';
     - carica: la frase della schermata di caricamento (qui sotto, bootStart);
     - suoni:  la frase dei suoni per concentrarsi (suoni-start.js, suoFrase);
     - start:  le citazioni della scheda START (citazioni.js, citDelGiorno).
   In localStorage `fl_frasi_oggi`: { 'AAAA-MM-GG': { canale: [chiavi] } }, solo oggi e i giorni dopo. La chiave e' la frase
   senza virgolette ne' punteggiatura, in minuscolo: l'italiano e l'originale inglese si segnano tutti e due. Questo file parte
   per primo, quindi il registro sta qui. */
const FL_FRASI_K = 'fl_frasi_oggi';
function flFraseData(off){ const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + (off || 0)); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function flFraseChiave(t){ return String(t == null ? '' : t).toLowerCase().replace(/[^a-z0-9àèéìòóùç]+/g, ' ').trim().slice(0, 80); }
function flFrasiReg(){
  let r = {}; try{ r = JSON.parse(localStorage.getItem(FL_FRASI_K) || '{}') || {}; }catch(_){ r = {}; }
  const oggi = flFraseData(0), o = {};
  Object.keys(r).forEach(function(g){ if (g >= oggi && r[g] && typeof r[g] === 'object') o[g] = r[g]; });
  return o;
}
/** Segna che il canale ha mostrato queste frasi (una stringa o un elenco: italiano e inglese) nel giorno `off` (0 = oggi, 1 = domani). */
function flFraseSegna(canale, testi, off){
  try{
    const r = flFrasiReg(), g = flFraseData(off || 0);
    const d = r[g] || (r[g] = {});
    const l = Array.isArray(d[canale]) ? d[canale] : (d[canale] = []);
    (Array.isArray(testi) ? testi : [testi]).forEach(function(t){ const k = flFraseChiave(t); if (k && l.indexOf(k) < 0) l.push(k); });
    if (l.length > 400) d[canale] = l.slice(-400);
    localStorage.setItem(FL_FRASI_K, JSON.stringify(r));
  }catch(_){ }
}
/** Vero se una di queste frasi e' gia' uscita oggi in un canale DIVERSO da `canale`. */
function flFraseAltrove(canale, testi){
  try{
    const d = flFrasiReg()[flFraseData(0)]; if (!d) return false;
    const ks = (Array.isArray(testi) ? testi : [testi]).map(flFraseChiave).filter(Boolean);
    return Object.keys(d).some(function(c){ return c !== canale && Array.isArray(d[c]) && ks.some(function(k){ return d[c].indexOf(k) >= 0; }); });
  }catch(_){ return false; }
}
/** Le frasi di una voce delle liste [italiano, autore, inglese]: l'italiano e, se c'e', l'originale. */
function flFraseTesti(q){ return q ? [q[0]].concat(q[2] ? [q[2]] : []) : []; }
/** Come flMazzo, ma salta le carte che `libera(i)` rifiuta (restano nel mazzo per la prossima volta). */
function flMazzoLibero(k, n, libera){
  if (typeof libera !== 'function') return flMazzo(k, n);
  let m = []; try{ m = JSON.parse(localStorage.getItem(k) || '[]') || []; }catch(_){ m = []; }
  m = m.filter(function(i){ return i >= 0 && i < n; });
  if (!m.length){ for (let i = 0; i < n; i++) m.push(i); for (let i = n - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); const t = m[i]; m[i] = m[j]; m[j] = t; } }
  const ok = function(i){ try{ return !!libera(i); }catch(_){ return true; } };
  let pos = m.findIndex(ok);
  if (pos < 0){
    /* le carte rimaste nel mazzo sono tutte gia' uscite altrove: una libera fuori dal mazzo, se c'e' */
    for (let i = 0; i < n; i++){ if (ok(i)){ try{ localStorage.setItem(k, JSON.stringify(m)); }catch(_){ } return i; } }
    pos = 0;
  }
  const v = m.splice(pos, 1)[0];
  try{ localStorage.setItem(k, JSON.stringify(m)); }catch(_){ }
  return v;
}
function bootStart(){
  BOOT.el = document.getElementById('boot');
  if (!BOOT.el) return;
  BOOT.bar = document.getElementById('bootBar');
  /* 0.9.369, Andrea: "che non siano sempre le stesse". Un mazzo: ogni frase esce una volta, poi il mazzo si rimescola.
     0.9.401 BUG-204: salta le frasi gia' uscite oggi come frase del giorno, dei suoni o della scheda START */
  const q = BOOT_LINES[flMazzoLibero('fl_mazzo_boot', BOOT_LINES.length, function(i){ return !flFraseAltrove('carica', flFraseTesti(BOOT_LINES[i])); })];
  flFraseSegna('carica', flFraseTesti(q));
  const t = document.getElementById('bootQuote');
  const a = document.getElementById('bootWho');
  /* le virgolette normali (regola di Andrea), e l'originale inglese per chi ha il telefono in inglese */
  const en = q[2] && typeof flLingua === 'function' && flLingua() === 'en';
  /* una frase che ha gia' le sue virgolette dentro non ne prende altre; l'a capo resta a capo */
  if (t){ const f = en ? q[2] : q[0]; t.style.whiteSpace = 'pre-line'; t.textContent = f.indexOf('"') >= 0 ? f : '"' + f + '"'; }
  if (a) a.textContent = q[1];
  bootTo(0.12);
  requestAnimationFrame(bootPaint);
  /* IL PASSAGGIO DI CONSEGNE.

     Sopra a tutto c'e' ancora la schermata di avvio di Android — il lucchetto su fondo blu —
     e finche' c'e' quella, questa non la vede nessuno. La si toglie appena la frase e' stata
     disegnata davvero (due fotogrammi: uno per applicare il testo, uno per comporlo), non
     quando i dati sono pronti: da li' in poi ad aspettare ci pensa questa schermata, che
     almeno ha qualcosa da dire. */
  requestAnimationFrame(function(){ requestAnimationFrame(bootHandoff); });
  /* Il tetto: oltre i cinque secondi si entra comunque. Meglio una scheda che si completa
     sotto gli occhi che una porta chiusa. */
  BOOT.timer = setTimeout(bootDone, 5000);
}

/* Il ponte verso la schermata di avvio di Android.

   NATIVE non esiste ancora quando questo file parte: il ponte con il telefono lo costruisce
   js/native.js, che viene caricato dopo. Quindi si riprova, per qualche secondo: appena c'e',
   si dice al telefono che puo' togliere il lucchetto e lasciare il posto a questa schermata.
   Se non arriva mai (siamo in un browser) non succede niente di male. */
function bootHandoff(){
  let tries = 0;
  const go = function(){
    try{
      if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.appReady){ NATIVE.appReady(); return; }
    }catch(_){ }
    if (++tries < 50) setTimeout(go, 60);
  };
  go();
}

/* Chiamata da nav.js quando i pezzi veri sono pronti. */
function bootDone(){
  if (BOOT.done) return;
  BOOT.done = true;
  clearTimeout(BOOT.timer);
  bootTo(1);
  if (BOOT.bar) BOOT.bar.style.width = '100%';
  const el = BOOT.el || document.getElementById('boot');
  if (!el) return;
  el.classList.add('gone');
  setTimeout(function(){
    try{ el.remove(); }catch(_){ }
    bootRepaint();
  }, 420);
}

/* LA SPINTA AL DISEGNO.

   È la parte che risolve il bianco che spariva al tocco. Su questa WebView capita che il
   primo fotogramma dopo l'avvio non venga composto finché non arriva un evento: la pagina
   c'è, è completa, e non si vede. Toccare lo schermo la faceva comparire — cioè il tocco
   faceva da sveglia. Qui la sveglia la diamo noi: si tocca una proprietà che obbliga a
   ricomporre il livello, e si rilascia al fotogramma dopo. */
function bootRepaint(){
  const ph = document.getElementById('phone');
  if (!ph) return;
  try{
    ph.style.transform = 'translateZ(0)';
    void ph.offsetHeight;
    requestAnimationFrame(function(){
      ph.style.transform = '';
      void ph.offsetHeight;
      try{ window.scrollTo(0, 0); }catch(_){ }
    });
  }catch(_){ }
}

bootStart();

/* Lo stile di questa schermata sta nella TESTA di index.html, non qui: uno script in fondo
   alla pagina puo' arrivare dopo il primo fotogramma, e una schermata di caricamento che per
   un istante appare senza stile e' peggio di non averla. */
