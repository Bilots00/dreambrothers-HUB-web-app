/* ===========================================================================================
   AMBIENTE, AZIONE E IDENTITA' (0.9.354): le prime tre schede del pannello mini "Le statistiche della
   partita", nella scheda Identita' di "Il tuo viaggio" (rotta-tab.js, #pstBoxMini di partita-stats.js).

   Andrea: "Ambiente | Azione | Identita' | Riepilogo | +. Prima l'ambiente, poi le azioni, e l'identita'
   come conseguenza delle due". partita-stats.js disegna le linguette e chiama qui il corpo della scheda.

   AMBIENTE. I luoghi in cui la persona passa il tempo, come le card di "Per te" in START (preset.js): foto
   dalla galleria (lato lungo 720 px, JPEG, come csImmagineDato), nome, tempo indicativo (ore al giorno o al
   mese), persone e inneschi visivi scritti a mano, una nota breve. Si aggiungono e si cambiano in una pagina
   a schermo intero (s-ambiente). Le foto stanno in IndexedDB (fl_ambiente); nei dati resta solo il
   riferimento 'idb:<chiave>' (o 'ls:<chiave>' se IndexedDB non c'e'): localStorage non si riempie.
     fl_ambienti = [{ id, nome, ore, unita: 'giorno'|'mese', persone, inneschi, nota, img, at }]
   La card fissa "Il telefono" non si elimina: apre s-ambiente-tel, dove un'immagine del sogno va sul blocco
   schermo o come sfondo della Home (NATIVE.setWallpaperImage, SfondoFoto.java) e dove sta la stessa levetta
   "Frase del giorno sul blocco schermo" della pagina Ispirazione quotidiana (scores.js, scToggleLockQuote,
   #inspLockSw): qui si legge lo stato e si chiama la stessa funzione, cosi' le due levette dicono la stessa cosa.
     fl_ambiente_tel = { img, fonte: 'galleria'|'sogno', lockAt, homeAt }

   AZIONE. Con Premium: quello che ha notato il tuo agente personale (tlFrasiPremium della Timeline, i
   resoconti del ponte con le altre AI). Con il piano gratis: le app, i siti e le ricerche del periodo
   (getTopApps, getWebTime, la radiografia della Timeline). Ogni voce diventa un'azione scritta chiara, con
   un'emoji o una foto: un'abitudine da cambiare o una nuova azione.
     fl_azioni_id = [{ id, tipo: 'cambia'|'nuova', t, em, img, da: { tipo, nome }, at }]

   IDENTITA'. Tre sotto-schede: "Chi sono oggi" (fl_chi_sono_oggi = { frase, parole: [3], at }, scritta
   dalla persona), "Chi devo diventare" (la card passaporto della pagina "Il mio io futuro", dai dati di
   fl_iofuturo; tocca e si apre la pagina con nfNotion) e "Chi stai diventando": il pannello #scLife di
   scores.js, adottato vivo con data-adotta. Non sta piu' nel carosello della scheda Identita'.
   Prefisso psc-.
   =========================================================================================== */
const PSC_LUOGHI = 'fl_ambienti';
const PSC_TEL = 'fl_ambiente_tel';
const PSC_AZIONI = 'fl_azioni_id';
const PSC_OGGI = 'fl_chi_sono_oggi';
const PSC_SUB = 'fl_partita_io_sub';
const PSC_BOZZA = 'fl_ambiente_bozza';
const PSC = { url: {}, carica: {}, az: {}, azCarica: {}, azAtt: false, azFonti: [], bozza: null, azBozza: null, salva: false };

const PSC_SVG = {
  indietro: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
  info: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v7M12 6.5v.2"/></svg>',
  infoGrande: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.2"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  /* 0.9.395: "Rifai il quiz" nella carta di Come ti vedi oggi (la freccia che torna indietro in cerchio) */
  rifai: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3.5 4v4.5H8"/></svg>',
  foto: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="12" cy="12.5" r="3.5"/><path d="M8.5 5l1.5-2h4l1.5 2"/></svg>'
};

function pscPremium(){
  try{ if (typeof ngPremium === 'function') return !!ngPremium(); }catch(_){ }
  try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; }
}
function pscToast(t){ try{ toast(t); }catch(_){ } }
function pscVibra(n){ try{ if (typeof flVibra === 'function') flVibra(n || 8); }catch(_){ } }
/* 0.9.377, Andrea: "due (i) diverse, una in corsivo e una minuscola, fanno schifo: la (i) del titolo e, dentro alle schede, un punto di
   domanda nello stesso cerchio". Stesso cerchio della (i) del titolo (pst-i), con il punto di domanda, attaccato alla fine della frase */
/* 0.9.379, Andrea: "il (?) va a capo da solo, attaccato al pulsante del periodo: inguardabile". La (i) e' informazione sulla riga (il (?)
   sta sul titolo La combinazione segreta), e resta incollata all'ultima parola con uno spazio vero: mai da sola su una riga */
/* 0.9.381: solo il pulsante; l'aggancio globale (registry.js) lo incolla all'ultima parola, cosi' non va mai a capo da solo */
function pscInfoBtn(azione, nome){ return '<button type="button" class="pst-i psc-i2" onclick="event.stopPropagation();' + azione + '" aria-label="' + pstE(nome) + '">i</button>'; }
/** Il periodo delle schede (oggi, 7 giorni, 30 giorni): un menu a tendina sotto al pulsante, come nel pannello Dove va la tua attenzione. */
function pscPerMenu(ev, b){
  if (ev) ev.stopPropagation();
  pscPerMenuChiudi();
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const v = document.createElement('div'); v.id = 'pscPerVelo'; v.className = 'arb-veil'; v.addEventListener('click', function(e){ e.stopPropagation(); pscPerMenuChiudi(); });
  casa.appendChild(v);
  const m = document.createElement('div'); m.id = 'pscPerMenu'; m.className = 'rep-menu rep-rangemenu';
  m.innerHTML = [[1, 'Oggi'], [7, 'Ultimi 7 giorni'], [30, 'Ultimi 30 giorni']].map(function(x){ return '<button type="button"' + (PST.per === x[0] ? ' class="on"' : '') + ' onclick="event.stopPropagation();pscPerScegli(' + x[0] + ')">' + x[1] + '</button>'; }).join('');
  casa.appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, b);
}
function pscPerMenuChiudi(){ ['pscPerVelo', 'pscPerMenu'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); }); }
function pscPerScegli(per){ pscPerMenuChiudi(); PST.per = per; try{ pstSalvaVista(); }catch(_){ } pscVibra(6); pstPaint(); }
function pscOre(ms){
  const m = Math.round((ms || 0) / 60000);
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '');
}
function pscData(t){ const d = new Date(t); return d.getDate() + ' ' + ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()]; }
function pscNum(v, max, intero){
  let n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  if (!isFinite(n) || n < 0) n = 0;
  n = Math.min(max, n);
  return intero ? Math.round(n) : Math.round(n * 2) / 2;
}
function pscId(p){ return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
/** Ridisegna quello che si vede: il pannello mini e le pagine aperte. */
function pscRidisegna(){
  /* mentre una card si trascina non si riscrive niente: il dito la perderebbe */
  if (PSC.drag){ PSC.dragDopo = true; return; }
  try{ if (typeof pstVisibile === 'function' && pstVisibile()) pstPaint(); }catch(_){ }
  try{ const a = document.getElementById('s-ambiente'); if (a && a.classList.contains('active')) pscLuogoPaint(); }catch(_){ }
  try{ const b = document.getElementById('s-ambiente-tel'); if (b && b.classList.contains('active')) pscTelPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LE IMMAGINI: in IndexedDB, mai in localStorage (le foto lo riempirebbero). In pagina si mostrano con un
   indirizzo blob:, corto, cosi' ridisegnare il pannello non si porta dietro centinaia di KB di testo.
   --------------------------------------------------------------------------------------- */
function pscDb(){
  return new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_ambiente', 1);
      r.onupgradeneeded = function(){ r.result.createObjectStore('img'); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ko(r.error); };
    }catch(e){ ko(e); }
  });
}
async function pscIdbPut(k, v){
  try{
    const db = await pscDb();
    await new Promise(function(ok, ko){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').put(v, k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ko(tx.error); }; tx.onabort = function(){ ko(tx.error); }; });
    return true;
  }catch(_){ return false; }
}
async function pscIdbGet(k){
  try{ const db = await pscDb(); return await new Promise(function(ok){ const tx = db.transaction('img', 'readonly'); const q = tx.objectStore('img').get(k); q.onsuccess = function(){ ok(q.result || null); }; q.onerror = function(){ ok(null); }; }); }catch(_){ return null; }
}
async function pscIdbDel(k){
  try{ const db = await pscDb(); await new Promise(function(ok){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').delete(k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ok(); }; }); }catch(_){ }
}
function pscBlob(dato){
  const m = /^data:([^;,]+)(;base64)?,(.*)$/.exec(String(dato || ''));
  if (!m) return null;
  const bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
  const a = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
  return new Blob([a], { type: m[1] });
}
function pscUrlDa(ref, dato){
  try{ const b = pscBlob(dato); PSC.url[ref] = b ? URL.createObjectURL(b) : dato; }catch(_){ PSC.url[ref] = dato; }
  return PSC.url[ref];
}
/** Salva un'immagine (data URL) e restituisce il riferimento da scrivere nei dati; '' se non c'e' posto. */
async function pscSalvaImg(k, dato, piccolo){
  if (!dato) return '';
  if (await pscIdbPut(k, dato)){ pscUrlDa('idb:' + k, dato); return 'idb:' + k; }
  const ls = 'fl_ambiente_img_' + k;
  try{ localStorage.setItem(ls, piccolo || dato); pscUrlDa('ls:' + ls, piccolo || dato); return 'ls:' + ls; }catch(_){ }
  return '';
}
/** L'indirizzo da mettere in pagina per un riferimento. Se e' in IndexedDB lo legge e poi ridisegna. */
function pscImgUrl(ref){
  if (!ref) return '';
  if (PSC.url[ref]) return PSC.url[ref];
  if (ref.indexOf('ls:') === 0){ let d = ''; try{ d = localStorage.getItem(ref.slice(3)) || ''; }catch(_){ } return d ? pscUrlDa(ref, d) : ''; }
  if (ref.indexOf('idb:') === 0){
    /* 0.9.388 (BUG-109): se la lettura non torna niente si riprova al prossimo disegno (prima restava segnata per sempre) */
    if (!PSC.carica[ref]){ PSC.carica[ref] = true; pscIdbGet(ref.slice(4)).then(function(d){ if (d){ pscUrlDa(ref, d); pscRidisegna(); } else delete PSC.carica[ref]; }); }
    return '';
  }
  return /^(img\/|data:image\/|https?:|blob:)/.test(ref) ? ref : '';
}
/** Il data URL di un riferimento (per il telefono, che vuole i byte). */
async function pscImgDato(ref){
  if (!ref) return '';
  if (ref.indexOf('idb:') === 0) return (await pscIdbGet(ref.slice(4))) || '';
  if (ref.indexOf('ls:') === 0){ try{ return localStorage.getItem(ref.slice(3)) || ''; }catch(_){ return ''; } }
  return '';
}
function pscImgVia(ref){
  if (!ref) return;
  try{ if (PSC.url[ref] && PSC.url[ref].indexOf('blob:') === 0) URL.revokeObjectURL(PSC.url[ref]); }catch(_){ }
  delete PSC.url[ref]; delete PSC.carica[ref];
  if (ref.indexOf('idb:') === 0) pscIdbDel(ref.slice(4));
  else if (ref.indexOf('ls:') === 0){ try{ localStorage.removeItem(ref.slice(3)); }catch(_){ } }
}
/* la galleria: l'input si crea, si tocca e si butta, dentro al tocco vero della persona */
function pscScegliFoto(dopo){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    pscLeggiFile(f).then(dopo).catch(function(){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); });
  });
  document.body.appendChild(inp);
  inp.click();
}
function pscLeggiFile(f){
  return new Promise(function(ok, ko){
    const fr = new FileReader();
    fr.onload = function(){ pscCaricaImg(fr.result).then(ok, ko); };
    fr.onerror = ko;
    fr.readAsDataURL(f);
  });
}
function pscCaricaImg(src){ return new Promise(function(ok, ko){ const img = new Image(); img.onload = function(){ ok(img); }; img.onerror = ko; img.src = src; }); }
function pscRiduci(img, lato, q){
  try{
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height; if (!w0 || !h0) return '';
    const k = Math.min(1, lato / Math.max(w0, h0));
    const c = document.createElement('canvas'); c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', q || .8);
  }catch(_){ return ''; }
}
/** Lato lungo 720 px, JPEG: la misura delle altre immagini dell'app (csImmagineDato, caveau-selezione.js). */
function pscPiccola(img){ return ((typeof csImmagineDato === 'function') ? csImmagineDato(img, 720) : '') || pscRiduci(img, 720, .72); }

/* ---------------------------------------------------------------------------------------
   AMBIENTE
   --------------------------------------------------------------------------------------- */
function pscLuoghi(){ const l = pstJ(PSC_LUOGHI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id; }) : []; }
function pscScriviLuoghi(l){ try{ localStorage.setItem(PSC_LUOGHI, JSON.stringify(l)); return true; }catch(_){ return false; } }
function pscTel(){ const t = pstJ(PSC_TEL, {}); return (t && typeof t === 'object' && !Array.isArray(t)) ? t : {}; }
function pscScriviTel(t){ try{ localStorage.setItem(PSC_TEL, JSON.stringify(t)); return true; }catch(_){ return false; } }
function pscTempoTxt(x){
  const n = +x.ore || 0;
  if (!n) return '';
  return String(n).replace('.', ',') + (n === 1 ? ' ora' : ' ore') + (x.unita === 'mese' ? ' al mese' : ' al giorno');
}
function pscLockAcceso(){ try{ return localStorage.getItem('fl_lockquote_on') === '1'; }catch(_){ return false; } }

/* 0.9.367, Andrea: "come le card della sezione Per te: cambiare l'emoji e lo sfondo della card (di serie la casa), o metterci la
   foto di una stanza". Gli sfondi sono i gradienti del brand */
const PSC_SFONDI = { blu: 'linear-gradient(160deg,#3F9FF4,#0075E3 45%,#001E44)', notte: 'linear-gradient(160deg,#0075E3,#001E44 70%)', rosso: 'linear-gradient(160deg,#E63946,#001E44 75%)', cielo: 'linear-gradient(160deg,#8CC6FF,#3F9FF4 55%,#0075E3)' };
const PSC_CASA_EMOJI = ['🏠', '🏡', '🛋️', '🛏️', '🪴', '🏢', '🧘', '📚'];
function pscCardHtml(o){
  const url = pscImgUrl(o.img);
  /* 0.9.363, Andrea: "con la copertina del sogno l'emoji del telefono sparisce e l'occhio non capisce che e' il telefono".
     Con la foto, l'emoji dell'ambiente resta in un pallino nell'angolo in alto a sinistra */
  const st = url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : (o.sfondo && PSC_SFONDI[o.sfondo] ? ' style="background:' + PSC_SFONDI[o.sfondo] + '"' : '');
  return '<button type="button"' + (o.id ? ' id="' + o.id + '"' : '') + ' class="psc-card' + (url ? ' foto' : '') + '"' + st + ' onclick="' + o.click + '" aria-label="' + pstE(o.nome) + '">'
    + (url ? '<span class="psc-card-ico" aria-hidden="true">' + o.art + '</span>' : '<span class="psc-card-art" aria-hidden="true">' + o.art + '</span>')
    + '<span class="psc-veil" aria-hidden="true"></span>'
    + '<span class="psc-card-txt"><b>' + pstE(o.nome) + '</b>'
    + o.righe.filter(Boolean).map(function(r){ return '<i>' + pstE(r) + '</i>'; }).join('')
    + (o.chips.length ? '<span class="psc-chips">' + o.chips.map(function(c){ return typeof c === 'object' ? '<em class="' + (c.c || '') + '">' + pstE(c.t) + '</em>' : '<em>' + pstE(c) + '</em>'; }).join('') + '</span>' : '')
    + '</span></button>';
}
/* 0.9.378, Andrea: "distingui gli inneschi visivi allineati da quelli disallineati, in rosso: l'ambiente che non gioca a tuo favore,
   il cibo spazzatura, la PlayStation, le cose che ti distraggono" */
function pscInnChips(x, ch){
  if (x.inneschi || x.inneschi === 0) ch.push('✨ ' + x.inneschi + ' a favore');
  if (x.inneschiNo) ch.push({ t: '⛔ ' + x.inneschiNo + ' contro', c: 'no' });
  return ch;
}
function pscInnCampi(b, step){
  return pscCampo('pscInneschi', 'Quanti inneschi ti ricordano il sogno?', step('pscInneschi', 'inneschi', 999), 'Le immagini e gli oggetti che ti fanno pensare al sogno: una foto, un libro, un post-it.')
    + pscCampo('pscInneschiNo', '<span class="psc-rosso">Quanti inneschi ti portano lontano?</span>', step('pscInneschiNo', 'inneschiNo', 999), 'Le cose che ti spingono verso le vecchie abitudini: il cibo spazzatura in vista, la console accesa, il telefono sul comodino.');
}
function pscPcVisibile(){ try{ return (typeof mwQuiComputer === 'function' && mwQuiComputer()) || (typeof mwDueDispositivi === 'function' && mwDueDispositivi()); }catch(_){ return false; } }
function pscAmbienteHtml(){
  const tel = pscTel(), l = pscLuoghi();
  /* 0.9.363, Andrea: "il badge Frase del giorno viene tagliato, e il badge Home sulla card del telefono non c'entra:
     la casa e' un'altra card". Il telefono resta pulito; le sue scelte stanno nella sua pagina */
  const telChips = [];
  /* 0.9.386, Andrea: "niente Riordina con le frecce: i tre puntini in alto a destra aprono la modifica (le X per togliere), e tenendo
     premuto una card la sposti, come le app sulla Home di Android". Tutte le card si spostano, anche telefono, computer e casa; la X
     c'e' solo sui luoghi tuoi (il telefono, il computer e la casa non si tolgono). L'ordine si salva (fl_ambiente_ordine) */
  /* 0.9.401 BUG-192: i tre puntini aprono il foglio (pscMenuApri: layout, Modifica, Rimuovi, Rimetti le predefinite). In "Modifica" le
     card si spostano e il tocco le apre; in "Rimuovi" la X sta solo sui luoghi tuoi e il tocco non apre niente. Niente piu' la scritta
     "tieni premuta una card": Andrea l'ha tolta */
  const modo = pscModo('amb'), togli = modo === 'togli';
  const voce = function(ord, card, via){
    return '<div class="psc-ord' + (modo ? ' modo' : '') + '" data-ord="' + pstE(ord) + '">' + card
      + (togli && via ? '<button type="button" class="psc-ord-x" aria-label="' + pstE(via[0]) + '" onclick="' + via[1] + '">' + PSC_X + '</button>' : '') + '</div>';
  };
  const telImg = tel.img || tel.imgHome;
  const voci = [{ ord: 'tel', html: voce('tel', pscCardHtml({ click: togli ? '' : 'pscTelApri()', img: telImg, art: '📱', nome: 'Il telefono', righe: ['Ti segue ovunque'], chips: pscInnChips(tel, telChips) })) }];
  if (pscPcVisibile()) voci.push({ ord: 'pc', html: voce('pc', pscCardHtml({ click: togli ? '' : 'pscPcApri()', img: pscPc().img, art: '💻', nome: 'Il computer', righe: ['Dove lavori'], chips: pscInnChips(pscPc(), []) })) });
  voci.push({ ord: 'casa', html: voce('casa', pscCasaCardHtml(togli)) });
  l.forEach(function(x){
    const ch = [];
    if (x.persone || x.persone === 0) ch.push('👥 ' + x.persone + (x.persone === 1 ? ' persona' : ' persone'));
    pscInnChips(x, ch);
    const card = pscCardHtml({ click: togli ? '' : 'pscLuogoApri(' + pstA(x.id) + ')', img: x.img, art: x.art || '🏡', nome: x.nome, righe: [pscTempoTxt(x)], chips: ch });
    voci.push({ ord: 'l:' + x.id, html: voce('l:' + x.id, card, ['Togli ' + x.nome, 'pscLuogoTogli(' + pstA(x.id) + ')']) });
  });
  return '<div class="psc-amb">'
    + '<div class="psc-testa psc-testa-k"><p>I posti in cui passi il tempo decidono chi diventi.' + pscInfoBtn('pscAmbInfo()', 'Come funziona l\'ambiente') + '</p>'
    + pscKebabHtml(modo, modo ? 'pscAmbModo(false)' : 'pscMenuApri(\'amb\')', 'I tuoi luoghi: layout e modifica') + '</div>'
    + pscFilaHtml('amb', pscOrdina(voci, pstJ(PSC_AMB_ORD, [])).map(function(v){ return v.html; }),
      modo ? '' : '<button type="button" class="psc-card psc-card-piu" onclick="pscLuogoNuovo()"><span class="psc-piu-ic">' + PST_ICO.piu + '</span><b>Aggiungi un luogo</b></button>', 'psc-griglia')
    + '</div>';
}
/* ---------------------------------------------------------------------------------------
   CASA (0.9.363). Andrea: "una card Casa come preset, oltre al telefono: la camera da letto, la casa, dove segnare gli
   inneschi di quell'ambiente. Il tempo passato in casa si deduce da solo dal tempo connesso al Wi-Fi di casa".
   Il telefono si segna ogni rete a cui si connette (Conditions.setSsid, NATIVE.getWifiLog); qui si sceglie quale e' la
   rete di casa e si sommano le ore. fl_ambiente_casa = { ssid, inneschi, img }.
   --------------------------------------------------------------------------------------- */
const PSC_CASA = 'fl_ambiente_casa';
const PSC_WIFI = { log: null, current: '', permesso: true, at: 0, p: null };
function pscCasa(){ const c = pstJ(PSC_CASA, {}); return (c && typeof c === 'object' && !Array.isArray(c)) ? c : {}; }
function pscScriviCasa(c){ try{ localStorage.setItem(PSC_CASA, JSON.stringify(c)); return true; }catch(_){ return false; } }
function pscWifiCarica(forza){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getWifiLog) return Promise.resolve(null);
  if (PSC_WIFI.p) return PSC_WIFI.p;
  if (!forza && PSC_WIFI.log && Date.now() - PSC_WIFI.at < 60000) return Promise.resolve(PSC_WIFI);
  PSC_WIFI.p = NATIVE.getWifiLog({}).then(function(r){
    PSC_WIFI.log = (r && Array.isArray(r.log)) ? r.log : []; PSC_WIFI.current = (r && r.current) || ''; PSC_WIFI.permesso = !(r && r.permesso === false);
    PSC_WIFI.at = Date.now(); PSC_WIFI.p = null; pscCasaRinfresca(); return PSC_WIFI;
  }).catch(function(){ PSC_WIFI.p = null; return null; });
  return PSC_WIFI.p;
}
/* i millisecondi sulla rete di casa fra da e a */
function pscCasaMs(ssid, da, a){
  let ms = 0;
  (PSC_WIFI.log || []).forEach(function(x){ if (!x || x.s !== ssid) return; const s0 = Math.max(+x.a || 0, da), e0 = Math.min(+x.b || Date.now(), a); if (e0 > s0) ms += e0 - s0; });
  return ms;
}
function pscOreTxt(ms){ const m = Math.round(ms / 60000); if (m < 60) return m + (m === 1 ? ' minuto' : ' minuti'); const h = Math.floor(m / 60), r = m % 60; return h + (h === 1 ? ' ora' : ' ore') + (r ? ' e ' + r + ' min' : ''); }
function pscOreCorte(ms){ const m = Math.round(ms / 60000); if (m < 60) return m + ' min'; return Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm'; }
function pscCasaTempi(c){
  if (!c.ssid || !PSC_WIFI.log) return null;
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const oggi = pscCasaMs(c.ssid, d0.getTime(), Date.now());
  const da7 = d0.getTime() - 6 * 86400000;
  const tot7 = pscCasaMs(c.ssid, da7, Date.now());
  /* la media si fa sui giorni da quando il telefono la registra, non su sette giorni che non ha visto */
  const primo = (PSC_WIFI.log[0] && +PSC_WIFI.log[0].a) || Date.now();
  const giorni = Math.max(1, Math.min(7, Math.ceil((Date.now() - Math.max(da7, primo)) / 86400000)));
  return { oggi: oggi, media: tot7 / giorni };
}
function pscCasaCardHtml(modo){
  const c = pscCasa();
  try{ pscWifiCarica(false); }catch(_){ }
  const t = pscCasaTempi(c);
  /* 0.9.364, Andrea: "la card non deve parlare di Wi-Fi subito: solo una volta aperta". Sulla card il tempo, se c'e', o niente */
  const righe = [t && t.media >= 60000 ? pscOreTxt(t.media) + ' al giorno' : 'Dove passi più tempo'];
  const ch = [];
  if (c.persone || c.persone === 0) ch.push('👥 ' + c.persone + (c.persone === 1 ? ' persona' : ' persone'));
  pscInnChips(c, ch);
  return pscCardHtml({ id: 'pscCasaCard', click: modo ? '' : 'pscCasaApri()', img: c.img, art: c.emoji || '🏠', sfondo: c.sfondo || '', nome: 'Casa', righe: righe, chips: ch });
}
function pscCasaRinfresca(){
  const el = document.getElementById('pscCasaCard'); if (el){ const t = document.createElement('div'); t.innerHTML = pscCasaCardHtml(pscModo('amb') === 'togli'); if (t.firstElementChild) el.parentNode.replaceChild(t.firstElementChild, el); }
  if (PSC.bozza && PSC.bozza.casa && document.getElementById('pscLuogoBody')) pscLuogoPaint();
}
function pscCasaApri(ridisegna){
  /* 0.9.364, Andrea: "Casa deve essere una card come le altre: l'immagine della stanza in cui passo piu' tempo, le persone, gli
     inneschi. E il Wi-Fi si chiede solo dentro, spiegato bene: il tempo che passi li' si puo' contare da solo". La pagina e' quella
     dei luoghi (s-ambiente), con il blocco del tempo al posto di "Quanto tempo ci passi?" */
  if (ridisegna){ if (PSC.bozza && PSC.bozza.casa) pscLuogoPaint(); return; }
  pscVibra(6);
  const c = pscCasa();
  try{ if (typeof sciChiudi === 'function') sciChiudi('pscCasa'); }catch(_){ }
  PSC.bozza = Object.assign({ id: 'casa', casa: true, nome: 'Casa', persone: '', inneschi: '', nota: '', img: '', emoji: '🏠', sfondo: '' }, c, { casa: true, nuova: '' });
  PSC.bozzaFoto = pscLuogoFirma(PSC.bozza);
  /* 0.9.367, Andrea: "la pagina della casa fa schifo: era meglio il popover, come quello dell'agente con le due frecce per allargarlo" */
  PSC.foglio = true;
  const pag = document.getElementById('pscLuogoBody'); if (pag) pag.innerHTML = '';
  /* 0.9.368, Andrea: "il pulsante per allargare e' piu' in basso della X, e a pagina intera tutto tocca il bordo destro: toglilo" */
  inSheet('<div class="en-foglio psc-casa-fg">'
    + '<button type="button" class="am-x" aria-label="Chiudi" onclick="pscCasaChiudi()">✕</button><div id="pscLuogoSheet"></div></div>');
  pscCasaVelo();
  pscLuogoPaint();
  pscWifiCarica(true);
}
const PSC_FRECCE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7"/></svg>';
function pscCasaGrande(){
  PSC.foglio = false;
  try{ inSheetChiudi(); }catch(_){ }
  goId('s-ambiente'); pscLuogoPaint();
  try{ const p = document.getElementById('s-ambiente'); if (p) p.scrollTop = 0; }catch(_){ }
}
function pscCasaEmoji(e){ if (!PSC.bozza) return; PSC.bozza.emoji = e; pscVibra(6); pscLuogoPaint(); }
function pscCasaSfondo(k){ if (!PSC.bozza) return; PSC.bozza.sfondo = k; PSC.bozza.nuova = ''; if (PSC.bozza.img){ PSC.bozza.togliImg = true; } pscVibra(6); pscLuogoPaint(); }
/* il blocco del tempo di Casa: spiegato come un servizio, non come un controllo */
function pscCasaTempoHtml(){
  const c = PSC.bozza || {}, nat = typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getWifiLog;
  const t = pscCasaTempi(c);
  let corpo;
  if (!nat) corpo = '<p class="psc-casa-p">Sul telefono il tempo che passi in casa si conta da solo, senza che tu lo debba segnare.</p>';
  else if (!c.ssid) corpo = '<p class="psc-casa-p">Invece di stimarlo tu, il tempo in casa si può contare da solo: quando il telefono è collegato alla rete di casa, sei a casa. Il conto resta sul telefono.</p>'
    + (!PSC_WIFI.permesso ? '<button type="button" class="en-cta psc-casa-go" onclick="pscCasaPermesso()">Conta il tempo da solo</button><small class="psc-casa-n2">Android chiede il permesso della posizione per dire il nome della rete.</small>'
      : PSC_WIFI.current ? '<button type="button" class="en-cta psc-casa-go" onclick="pscCasaRete()">Sono a casa adesso: conta da qui</button><small class="psc-casa-n2">Rete di adesso: ' + pstE(PSC_WIFI.current) + '</small>'
      : '<small class="psc-casa-n2">Quando sei a casa e il telefono è collegato alla tua rete, torna qui e tocca il pulsante.</small>');
  else {
    const primo = pscCasaInizio(c);
    corpo = '<div class="psc-casa-num"><div><b>' + (t ? pscOreCorte(t.oggi) : '—') + '</b><small>oggi</small></div><i></i><div><b>' + (t ? pscOreCorte(t.media) : '—') + '</b><small>al giorno, in media</small></div></div>'
      + (primo && Date.now() - primo < 86400000 ? '<small class="psc-casa-n2">Il conto è partito ' + pscQuando(primo) + ': domani il numero è quello di una giornata intera.</small>' : '')
      /* 0.9.367, Andrea: "Rete di casa: Vodafone attaccato ai numeri, e non si puo' cambiare". Una riga sua, con Cambia */
      + '<div class="psc-rete"><span aria-hidden="true">📶</span><div><small>Rete di casa</small><b>' + pstE(c.ssid) + '</b></div><button type="button" onclick="pscCasaReteCambia()">' + (PSC.reteApri ? 'Chiudi' : 'Cambia') + '</button></div>'
      + (PSC.reteApri ? '<div class="psc-reti">' + ((PSC.reti || []).length ? PSC.reti.map(function(n, i){ return '<button type="button" class="' + (n === c.ssid ? 'on' : '') + '" onclick="pscCasaReteScegli(' + i + ')"><span>' + pstE(n) + '</span>' + (n === PSC_WIFI.current ? '<small>collegato adesso</small>' : '') + '</button>'; }).join('') : '<p>Nessuna rete visibile adesso. Accendi il Wi-Fi e riprova.</p>') + '</div>' : '');
  }
  return '<div class="psc-campo"><label>Il tempo che passi a casa</label>' + corpo + '</div>';
}
/* da quando il telefono conta: la prima volta che ha visto la rete di casa */
function pscCasaInizio(c){ let p = 0; (PSC_WIFI.log || []).forEach(function(x){ if (x && x.s === c.ssid && (!p || +x.a < p)) p = +x.a; }); return p; }
function pscQuando(t){ const d = new Date(t), o = new Date(); const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); return (d.toDateString() === o.toDateString() ? 'oggi alle ' : 'ieri alle ') + hm; }
async function pscCasaSalva(){
  const b = PSC.bozza; if (!b || PSC.salva) return;
  PSC.salva = true;
  const c = pscCasa();
  let img = c.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('amb_casa_' + Date.now().toString(36), b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; }
    else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const vuoto = function(v){ return v === '' || v == null; };
  if (b.togliImg && !b.nuova){ if (img) pscImgVia(img); img = ''; }
  pscScriviCasa(Object.assign({}, c, { emoji: b.emoji || '🏠', sfondo: b.sfondo || '', img: img, ssid: b.ssid || c.ssid || '', persone: vuoto(b.persone) ? null : pscNum(b.persone, 9999, true), inneschi: vuoto(b.inneschi) ? null : pscNum(b.inneschi, 999, true), inneschiNo: vuoto(b.inneschiNo) ? null : pscNum(b.inneschiNo, 999, true), nota: String(b.nota || '').trim().slice(0, 120), at: Date.now() }));
  PSC.salva = false; PSC.bozza = null; PSC.bozzaFoto = null;
  pscVibra([10, 30, 10]); pscToast('Casa aggiornata');
  if (PSC.foglio){ PSC.foglio = false; try{ inSheetChiudi(); }catch(_){ } } else flIndietro();
  setTimeout(pscRidisegna, 60);
}
/* 0.9.368, Andrea: "Cambia diceva Sei gia' collegato a questa rete senza farmi scegliere fra quelle che l'app rileva". Cambia apre l'elenco
   dentro al foglio: la rete di adesso, quelle vicine e quelle gia' viste dal telefono */
async function pscCasaReteCambia(){
  PSC.reteApri = !PSC.reteApri;
  if (PSC.reteApri){
    let vicine = [];
    try{ if (typeof edEnsureLocation === 'function') await edEnsureLocation(false); const info = NATIVE && NATIVE.getWifiInfo ? await NATIVE.getWifiInfo() : null; vicine = (info && Array.isArray(info.networks)) ? info.networks.map(function(n){ return String((n && (n.ssid || n.name)) || n || '').trim(); }) : []; }catch(_){ vicine = []; }
    const viste = (PSC_WIFI.log || []).map(function(x){ return x && x.s; });
    const tutte = [PSC_WIFI.current].concat(vicine, viste).filter(function(x, i, l){ return x && x !== '<unknown ssid>' && l.indexOf(x) === i; }).slice(0, 12);
    PSC.reti = tutte;
  }
  pscVibra(6); pscLuogoPaint();
}
/* 0.9.388 (BUG-108): con il foglio della Casa aperto la rete scelta va nella bozza e si scrive con Salva */
function pscCasaReteScegli(i){
  const n = (PSC.reti || [])[i]; if (!n) return;
  if (PSC.bozza && PSC.bozza.casa) PSC.bozza.ssid = n;
  else { const c = pscCasa(); c.ssid = n; c.at = Date.now(); pscScriviCasa(c); }
  PSC.reteApri = false; pscVibra(10); pscToast('Rete di casa: ' + n); pscLuogoPaint();
}
function pscCasaRete(){
  if (!PSC_WIFI.current) return;
  if (PSC.bozza && PSC.bozza.casa){ PSC.bozza.ssid = PSC_WIFI.current; pscVibra(10); pscLuogoPaint(); try{ flModificato('s-ambiente'); }catch(_){ } return; }
  const c = pscCasa(); c.ssid = PSC_WIFI.current; c.at = Date.now(); pscScriviCasa(c);
  pscVibra(10); pscCasaRinfresca();
}
function pscCasaInneschi(d){ const c = pscCasa(); c.inneschi = Math.max(0, Math.min(99, (+c.inneschi || 0) + d)); pscScriviCasa(c); pscCasaRinfresca(); }
async function pscCasaPermesso(){
  try{ if (typeof edEnsureLocation === 'function') await edEnsureLocation(false); else if (NATIVE.requestLocationPermission) await NATIVE.requestLocationPermission({ background: false }); }catch(_){ }
  pscWifiCarica(true);
}
function pscAmbInfo(){
  pscVibra(6);
  /* 0.9.368, Andrea: "due emoji (la casa sul titolo e quella della slide) no: uno non vive per forza in una casa. Il titolo senza emoji,
     un'emoji per slide, e il carosello in un pannello scuro". E il link alla lezione sottolineato, che sembri toccabile */
  inSheet('<div class="en-foglio psc-fg psc-fg-amb"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il tuo ambiente</h3>'
    + flInfoRighe([
      ['👥', 'I luoghi ti cambiano', 'Le persone e le cose intorno a te spingono le tue scelte.'],
      ['⏱️', 'Conta il tempo', 'Più ore passi in un luogo, più quel luogo decide per te.'],
      ['✨', 'Gli inneschi visivi', 'Sono le immagini e gli oggetti che ti ricordano il sogno. Più ne vedi, più ci pensi.'],
      ['📱', 'Il telefono ti segue', 'Lo guardi tutto il giorno. Mettici un’immagine del sogno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button>'
    /* 0.9.357: la lezione dell'Academy sul cambiare stanza, il perché scientifico di questa scheda */
    + (typeof acApriLezione === 'function' ? '<button type="button" class="am-link psc-lez" onclick="inSheetChiudi();acApriLezione(\'focus\', \'Cambiare stanza per ricaricare la testa\')">Leggi la lezione sul cambiare stanza</button>' : '')
    + '</div>');
}

/* LA PAGINA DI UN LUOGO: nuovo o da cambiare. La bozza di un luogo nuovo resta salvata (senza la foto) finche' non lo salvi */
registerScreen('s-ambiente',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t" id="pscLuogoT">Il luogo</b><button class="iconbtn" onclick="pscAmbInfo()" aria-label="Come funziona l\'ambiente">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscLuogoBody"></div><div class="spacer"></div>', { back: function(){ return pscLuogoIndietro(); } });

/* 0.9.388, Andrea (BUG-108): "senza Salva, tornando indietro non deve cambiare niente". Il luogo e la Casa avevano gia' la loro bozza
   (PSC.bozza): adesso, se la bozza e' diversa da com'era quando l'hai aperta, indietro (o la X del foglio della Casa) chiede
   "Vuoi salvare le modifiche?". Lascia stare butta la bozza, anche quella di un luogo nuovo rimasta da parte (fl_ambiente_bozza) */
function pscLuogoFirma(b){
  if (!b) return '';
  const v = function(x){ return x == null ? '' : String(x); };
  return JSON.stringify([v(b.nome), v(b.ore), v(b.unita), v(b.persone), v(b.inneschi), v(b.inneschiNo), v(b.nota), v(b.emoji), v(b.sfondo), v(b.ssid), !!b.nuova, !!b.togliImg, v(b.art)]);
}
function pscLuogoSporco(){ return !!PSC.bozza && PSC.bozzaFoto != null && pscLuogoFirma(PSC.bozza) !== PSC.bozzaFoto; }
function pscLuogoLascia(){
  const b = PSC.bozza;
  if (b && !b.id && !b.casa){ try{ localStorage.removeItem(PSC_BOZZA); }catch(_){ } }
  PSC.bozza = null; PSC.bozzaFoto = null;
}
function pscLuogoIndietro(){
  if (pscLuogoSporco()){
    const b = PSC.bozza;
    pscChiediSalva(function(){ if (b.casa) pscCasaSalva(); else pscLuogoSalva(); }, function(){ pscLuogoLascia(); try{ flIndietro(); }catch(_){ goId('s-home'); } });
    return null;
  }
  return 's-home';
}
function pscCasaChiudi(){
  const via = function(){ pscLuogoLascia(); PSC.foglio = false; try{ inSheetChiudi(); }catch(_){ } };
  if (pscLuogoSporco()){ pscChiediSalva(function(){ pscCasaSalva(); }, via); return; }
  via();
}
/* il tocco fuori dal foglio della Casa passa dalla stessa domanda della X */
function pscCasaVelo(){
  const w = document.getElementById('inSheet'); if (!w || w.__pscCasa) return;
  w.__pscCasa = 1;
  w.addEventListener('click', function(e){
    if (e.target === w && PSC.foglio && PSC.bozza && PSC.bozza.casa && document.getElementById('pscLuogoSheet')){ e.stopImmediatePropagation(); pscCasaChiudi(); }
  }, true);
}

function pscLuogoApri(id){
  const x = id ? pscLuoghi().filter(function(l){ return l.id === id; })[0] : null;
  if (id && !x) return;
  pscVibra(6);
  let bz = null; try{ bz = JSON.parse(localStorage.getItem(PSC_BOZZA) || 'null'); }catch(_){ bz = null; }
  PSC.bozza = x ? Object.assign({}, x) : ((bz && typeof bz === 'object') ? bz : { id: '', nome: '', ore: '', unita: 'giorno', persone: '', inneschi: '', nota: '', img: '' });
  PSC.bozza.nuova = ''; PSC.bozza.togliImg = false;
  PSC.bozzaFoto = pscLuogoFirma(PSC.bozza);
  try{ if (typeof sciChiudi === 'function') sciChiudi('psc'); }catch(_){ }
  goId('s-ambiente');
  pscLuogoPaint();
  try{ const p = document.getElementById('s-ambiente'); if (p) p.scrollTop = 0; }catch(_){ }
}
function pscBz(k, v){
  const b = PSC.bozza; if (!b) return;
  b[k] = v;
  if (!b.id){ try{ const c = Object.assign({}, b); delete c.nuova; localStorage.setItem(PSC_BOZZA, JSON.stringify(c)); }catch(_){ } }
}
function pscBzUnita(u){ pscBz('unita', u); pscVibra(6); pscLuogoPaint(); }
/* 0.9.373, Andrea: "nella card dell'ambiente meta' a sinistra e meta' al centro; e Conta le immagini... va dietro a una (i)". Tutto al
   centro; la frase breve sotto al titolo diventa il tooltip della (i) */
/* 0.9.380, Andrea: "la (i) va a capo da sola e non apre niente": resta attaccata all'ultima parola (nowrap) e il fumetto sta sopra al foglio */
function pscLabI(lab, btn){
  if (!btn) return lab;
  if (/<\/span>$/.test(lab)) return lab.replace(/(\S+)<\/span>$/, '<span class="psc-nw">$1 ' + btn + '</span></span>');
  const i = lab.lastIndexOf(' ');
  return i < 0 ? '<span class="psc-nw">' + lab + ' ' + btn + '</span>' : lab.slice(0, i + 1) + '<span class="psc-nw">' + lab.slice(i + 1) + ' ' + btn + '</span>';
}
/* 0.9.395, Andrea: "il fumetto deve sempre comparire sotto o sopra la card". La (i) dell'etichetta apriva il fumetto sopra alla casella
   (e a quello che ci hai scritto): il campo e' l'ancora (data-tip-ancora, flTip), il fumetto va sotto o sopra il campo intero */
function pscCampo(id, lab, input, sotto){
  return '<div class="psc-campo"' + (sotto ? ' data-tip-ancora' : '') + '><label for="' + id + '">' + pscLabI(lab, sotto && typeof flTipBtn === 'function' ? flTipBtn(sotto.replace(/<[^>]+>/g, '')) : '') + '</label>' + (sotto && typeof flTipBtn !== 'function' ? '<small>' + sotto + '</small>' : '') + input + '</div>';
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style');
  st.textContent = '.psc-campo{text-align:center!important;align-items:center!important}.psc-campo > label{display:block;text-align:center!important;width:100%}.psc-campo .psc-step,.psc-campo .md-step{justify-content:center!important;margin-left:auto!important;margin-right:auto!important}.psc-campo .psc-tempo{justify-content:center!important}.psc-campo .psc-nota-in{text-align:left}'
    + '.psc-casa-l{text-align:center!important}.psc-casa-emo,.psc-casa-sf{justify-content:center!important}'
    /* 0.9.393: l'icona del luogo e della Casa con il selettore condiviso (scegli-icona.js) */
    + '.psc-casa-testa .sci-griglia,#pscLuogoBody .sci-griglia,#pscLuogoSheet .sci-griglia{align-self:stretch;width:100%}.psc-foto-art{display:block;font-size:52px;line-height:1}.psc-foto-emo .psc-foto-v b{display:inline-flex;align-items:center;gap:6px;color:#0075E3}.psc-foto-emo .psc-foto-v b svg{width:18px;height:18px}'
    /* 0.9.401 BUG-187, Andrea: "L'icona del luogo e' attaccata alle icone". Il titolo del campo e la griglia stavano a 0 px: 18 px veri */
    + '.psc-campo > .sci-griglia{margin-top:18px!important}';
  document.head.appendChild(st); })();
function pscLuogoPaint(){
  const box = document.getElementById(PSC.foglio && document.getElementById('pscLuogoSheet') ? 'pscLuogoSheet' : 'pscLuogoBody'), b = PSC.bozza; if (!box || !b) return;
  const t = document.getElementById('pscLuogoT'); if (t) t.textContent = b.casa ? 'Casa' : (b.id ? 'Il luogo' : 'Un luogo nuovo');
  /* 0.9.364, Andrea: "al centro fra - e + voglio poter toccare il numero e scriverlo, se non ho voglia di toccare 22 volte il +". E i
     colori di - e + come nelle altre sezioni (md-step: bordo sottile, sfondo trasparente) */
  const step = function(id, k, max){ const v = b[k] === '' || b[k] == null ? '' : String(b[k]);
    return '<div class="md-step psc-step"><button type="button" onclick="pscStep(\'' + id + '\',\'' + k + '\',-1,' + max + ')" aria-label="Meno">−</button>'
      + '<input class="psc-step-n" id="' + id + '" type="number" inputmode="numeric" min="0" max="' + max + '" placeholder="0" value="' + pstE(v) + '" oninput="pscBz(\'' + k + '\',this.value)">'
      + '<button type="button" onclick="pscStep(\'' + id + '\',\'' + k + '\',1,' + max + ')" aria-label="Più">+</button></div>'; };
  const url = b.nuova || pscImgUrl(b.img);
  const num = function(id, k, ph, max, passo){ return '<input class="fin psc-fin psc-n" id="' + id + '" type="number" inputmode="decimal" min="0" max="' + max + '" step="' + passo + '" placeholder="' + ph + '" value="' + pstE(b[k] === '' || b[k] == null ? '' : b[k]) + '" oninput="pscBz(\'' + k + '\',this.value)">'; };
  const urlVero = b.togliImg ? b.nuova : url;
  const testa = b.casa
    ? '<div class="psc-casa-testa"><div class="psc-casa-anteprima' + (urlVero ? ' foto' : '') + '" style="' + (urlVero ? 'background-image:url(\'' + String(urlVero).replace(/['()\\]/g, '') + '\')' : 'background:' + (PSC_SFONDI[b.sfondo] || PSC_SFONDI.blu)) + '"><span>' + (b.emoji || '🏠') + '</span><b>Casa</b></div>'
      /* 0.9.393, Andrea: "la stessa liberta' della pagina Il tuo sogno": lo stesso selettore (scegli-icona.js), con Mostra altre e Usa */
      + '<p class="psc-casa-l">Emoji</p>' + pscIconaHtml('pscCasa', b.emoji || '🏠', '', PSC_CASA_EMOJI, pscCasaEmoji)
      + '<p class="psc-casa-l">Sfondo</p><div class="psc-casa-sf">' + Object.keys(PSC_SFONDI).map(function(k){ return '<button type="button" aria-label="Sfondo ' + k + '" class="' + (!urlVero && (b.sfondo || 'blu') === k ? 'on' : '') + '" style="background:' + PSC_SFONDI[k] + '" onclick="pscCasaSfondo(\'' + k + '\')"></button>'; }).join('')
      + '<button type="button" class="psc-casa-foto' + (urlVero ? ' on' : '') + '" onclick="pscLuogoFoto()" aria-label="Una tua foto">' + PSC_SVG.foto + '</button></div></div>'
    /* 0.9.393, Andrea: "nelle card dei luoghi si sceglie solo l'immagine: deve essere sempre libero l'utente di scegliere se usare
       un'icona oppure un'immagine". Sopra, come apparira' la card: la foto, o l'emoji scelta; sotto, il selettore delle icone.
       Un'emoji toglie la foto (togliImg, come nella Casa), una foto prende il posto dell'emoji */
    : '<button type="button" class="psc-foto' + (urlVero ? ' piena' : ' psc-foto-emo') + '" onclick="pscLuogoFoto()"' + (urlVero ? ' style="background-image:url(\'' + String(urlVero).replace(/['()\\]/g, '') + '\')"' : '') + '>'
      + (urlVero ? '<span class="psc-foto-c">' + PSC_SVG.foto + 'Cambia la foto</span>' : '<span class="psc-foto-v"><span class="psc-foto-art" aria-hidden="true">' + (b.art || '🏡') + '</span><b>' + PSC_SVG.foto + 'Oppure una foto dalla galleria</b></span>')
    + '</button>'
    + pscCampo('pscIco', 'L’icona del luogo', pscIconaHtml('psc', b.art || '🏡', urlVero, null, pscLuogoEmoji));
  box.innerHTML = testa
    + (b.casa ? pscCasaTempoHtml() : pscCampo('pscNome', 'Come si chiama il luogo?', '<input class="fin psc-fin" id="pscNome" maxlength="40" placeholder="Per esempio, la mia camera" value="' + pstE(b.nome || '') + '" oninput="pscBz(\'nome\',this.value)">')
    + pscCampo('pscOre', 'Quanto tempo ci passi?', '<div class="psc-tempo">' + num('pscOre', 'ore', '0', b.unita === 'mese' ? 744 : 24, '0.5') + '<span class="psc-u">ore</span>'
      + '<div class="psc-unita" role="radiogroup" aria-label="Ogni quanto">' + [['giorno', 'al giorno'], ['mese', 'al mese']].map(function(u){ return '<button type="button" role="radio" aria-checked="' + (b.unita === u[0]) + '" class="' + (b.unita === u[0] ? 'on' : '') + '" onclick="pscBzUnita(\'' + u[0] + '\')">' + u[1] + '</button>'; }).join('') + '</div></div>',
      'Scegli "al mese" per un posto in cui vai di rado.'))
    + pscCampo('pscPersone', 'Quante persone ci sono di solito?', step('pscPersone', 'persone', 9999))
    + pscInnCampi(b, step)
    /* 0.9.379, Andrea: "la nota breve e' troppo attaccata e non serve a tutti: nascondila in un collapsible, dicendo che e' facoltativa" */
    + '<details class="psc-nota-d"' + (b.nota ? ' open' : '') + '><summary>✍️ Aggiungi una nota <small>(facoltativa)</small></summary>'
    + '<textarea class="fin psc-fin psc-nota-in" id="pscNota" rows="2" maxlength="120" placeholder="Per esempio, la foto del mare sopra la scrivania" oninput="pscBz(\'nota\',this.value)">' + pstE(b.nota || '') + '</textarea></details>'
    + '<button type="button" class="en-cta psc-salva" onclick="' + (b.casa ? 'pscCasaSalva()' : 'pscLuogoSalva()') + '">' + (b.id ? 'Salva' : 'Salva il luogo') + '</button>'
    + (b.id && !b.casa ? '<button type="button" class="psc-via" onclick="pscLuogoElimina()">Elimina il luogo</button>' : '');
}
function pscStep(id, k, d, max){
  const i = document.getElementById(id); const v = Math.max(0, Math.min(max, (parseInt(i && i.value, 10) || 0) + d));
  if (i) i.value = String(v); pscBz(k, String(v)); pscVibra(6);
}
/* il selettore condiviso dell'icona (scegli-icona.js): nella pagina del luogo e nel foglio della Casa */
const PSC_LUOGO_EMOJI = ['🏡', '🏠', '🛋️', '🛏️', '🪴', '🏢', '💼', '🏫', '📚', '☕', '🍽️', '🏋️', '🌳', '🏖️', '🚗', '🧘', '🎮', '💻'];
function pscIconaHtml(chi, ora, img, base, scegli){
  if (typeof sciHtml !== 'function') return '';
  return sciHtml(chi, { ora: ora, img: img || '', base: base || PSC_LUOGO_EMOJI, bordo: true, scegli: scegli,
    foto: img ? pscLuogoFoto : null, riga: false, ridisegna: pscLuogoPaint });
}
/* l'emoji del luogo: prende il posto della foto, cosi' la card mostra quello che hai scelto */
function pscLuogoEmoji(e){
  const b = PSC.bozza; if (!b || !e) return;
  pscBz('art', e);
  if (b.nuova || b.img){ b.nuova = ''; b.togliImg = !!b.img; }
  pscVibra(6); pscLuogoPaint();
}
function pscLuogoFoto(){
  pscScegliFoto(function(img){
    const d = pscPiccola(img);
    if (!d){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
    if (PSC.bozza){ PSC.bozza.nuova = d; PSC.bozza.togliImg = false; pscLuogoPaint(); }
  });
}
async function pscLuogoSalva(){
  const b = PSC.bozza; if (!b || PSC.salva) return;
  const nome = String(b.nome || '').trim().slice(0, 40);
  if (!nome){ pscToast('Scrivi il nome del luogo'); const n = document.getElementById('pscNome'); if (n) n.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('l');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('amb_' + id + '_' + Date.now().toString(36), b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; }
    else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const unita = b.unita === 'mese' ? 'mese' : 'giorno';
  const vuoto = function(v){ return v === '' || v == null; };
  const o = { id: id, nome: nome, ore: pscNum(b.ore, unita === 'mese' ? 744 : 24), unita: unita,
    persone: vuoto(b.persone) ? null : pscNum(b.persone, 9999, true), inneschi: vuoto(b.inneschi) ? null : pscNum(b.inneschi, 999, true),
    inneschiNo: vuoto(b.inneschiNo) ? null : pscNum(b.inneschiNo, 999, true),
    nota: String(b.nota || '').trim().slice(0, 120), img: img, at: Date.now() };
  if (b.togliImg && !b.nuova){ if (img) pscImgVia(img); img = ''; o.img = ''; }
  if (b.art) o.art = String(b.art).slice(0, 16);
  const l = pscLuoghi(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviLuoghi(l)){ pscToast('La memoria del telefono è piena, il luogo non si salva'); return; }
  try{ localStorage.removeItem(PSC_BOZZA); }catch(_){ }
  PSC.bozza = null; PSC.bozzaFoto = null;
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Luogo aggiornato' : 'Luogo aggiunto al tuo ambiente');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}
async function pscLuogoElimina(){
  const b = PSC.bozza; if (!b || !b.id) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare "' + b.nome + '"?', 'Il luogo sparisce con la sua foto.', 'Elimina', true); }catch(_){ }
  if (!ok) return;
  pscScriviLuoghi(pscLuoghi().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.bozza = null;
  pscToast('Luogo eliminato');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}

/* IL TELEFONO: la card fissa. Un'immagine del sogno sul blocco schermo o sulla Home, e la frase del giorno */
registerScreen('s-ambiente-tel',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t">Il telefono</b><button class="iconbtn" onclick="pscTelInfo()" aria-label="Come funziona il telefono come innesco">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscTelBody"></div><div class="spacer"></div>', { back: function(){ return pscBozzaIndietro('tel'); } });

function pscTelApri(){
  pscVibra(6);
  /* 0.9.388 (BUG-108): ogni volta che si entra si parte dai dati salvati; la bozza nasce prima di goId, cosi' il Salva (registry.js,
     FL_SALVA_STATO) fotografa la bozza intatta e compare appena cambia */
  pscBozzaLascia('tel'); pscBozzaDi('tel');
  goId('s-ambiente-tel');
  pscTelPaint();
  pscLockSync().then(function(){ pscTelPaint(); });
}
/* ---------------------------------------------------------------------------------------
   0.9.388, Andrea (BUG-108): "le modifiche si salvano anche senza toccare Salva: se torno indietro restano". Nelle pagine del
   telefono e del computer ogni scelta (l'immagine della galleria o della copertina, i due contatori) va in una BOZZA in memoria;
   i dati veri (fl_ambiente_tel, fl_ambiente_pc) e le immagini in IndexedDB si scrivono solo con Salva o con "Metti sul...".
   Tornando indietro con una bozza diversa dai dati salvati si chiede "Vuoi salvare le modifiche?" (Salva / Lascia stare).
   La bozza: { img, imgHome, fonte, fonteHome, inneschi, inneschiNo, nuova: { lock|home|pc: dataURL }, nuovaUrl: {...} }.
   La levetta della frase del giorno resta un interruttore del telefono (e' la stessa della pagina Ispirazione quotidiana):
   non passa dalla bozza.
   --------------------------------------------------------------------------------------- */
PSC.bozze = {};
function pscBozzaLeggi(dove){ return dove === 'pc' ? pscPc() : pscTel(); }
function pscBozzaNum(v){ return v === '' || v == null || !isFinite(+v) ? null : +v; }
function pscBozzaNuova(dove){
  const o = pscBozzaLeggi(dove);
  return { img: o.img || '', imgHome: o.imgHome || '', fonte: o.fonte || '', fonteHome: o.fonteHome || '', inneschi: pscBozzaNum(o.inneschi), inneschiNo: pscBozzaNum(o.inneschiNo), nuova: {}, nuovaUrl: {} };
}
function pscBozzaDi(dove){ if (!PSC.bozze[dove]) PSC.bozze[dove] = pscBozzaNuova(dove); return PSC.bozze[dove]; }
function pscBozzaFirma(o){
  const n = o.nuova || {};
  return JSON.stringify([o.img || '', o.imgHome || '', pscBozzaNum(o.inneschi), pscBozzaNum(o.inneschiNo), !!n.lock, !!n.home, !!n.pc]);
}
function pscBozzaSporca(dove){ const b = PSC.bozze[dove]; return !!b && pscBozzaFirma(b) !== pscBozzaFirma(pscBozzaLeggi(dove)); }
/* il campo di ogni schermo: il blocco schermo e il computer usano img, la Home imgHome. Nessun ripiego dall'uno all'altro */
function pscBozzaCampo(k){ return k === 'home' ? 'imgHome' : 'img'; }
/** L'immagine da mostrare per uno schermo: quella appena scelta (in memoria) o quella salvata. */
function pscBozzaUrl(dove, k){ const b = pscBozzaDi(dove); return b.nuovaUrl[k] || b.nuova[k] || pscImgUrl(b[pscBozzaCampo(k)]); }
function pscBozzaHaImg(dove, k){ const b = pscBozzaDi(dove); return !!(b.nuova[k] || b[pscBozzaCampo(k)]); }
async function pscBozzaDato(dove, k){ const b = pscBozzaDi(dove); return b.nuova[k] || await pscImgDato(b[pscBozzaCampo(k)]); }
function pscBozzaUrlVia(b, k){ try{ const u = b.nuovaUrl[k]; if (u && u.indexOf('blob:') === 0) URL.revokeObjectURL(u); }catch(_){ } delete b.nuovaUrl[k]; }
/** Un'immagine scelta: resta nella bozza. L'anteprima la mostra subito, senza aspettare IndexedDB. */
function pscBozzaImmagine(dove, k, dato, fonte){
  const b = pscBozzaDi(dove);
  pscBozzaUrlVia(b, k);
  b.nuova[k] = dato;
  try{ const bl = pscBlob(dato); b.nuovaUrl[k] = bl ? URL.createObjectURL(bl) : dato; }catch(_){ b.nuovaUrl[k] = dato; }
  if (fonte) b[k === 'home' ? 'fonteHome' : 'fonte'] = fonte;
  try{ if (typeof flModificato === 'function') flModificato(dove === 'pc' ? 's-ambiente-pc' : 's-ambiente-tel'); }catch(_){ }
}
function pscBozzaLascia(dove){
  const b = PSC.bozze[dove]; if (!b) return;
  Object.keys(b.nuovaUrl || {}).forEach(function(k){ pscBozzaUrlVia(b, k); });
  delete PSC.bozze[dove];
}
/** Scrive la bozza nei dati veri. soli = ['lock'] scrive solo l'immagine di quello schermo (Metti sul...); senza, tutto (Salva). */
async function pscBozzaScrivi(dove, soli){
  const b = PSC.bozze[dove]; if (!b) return true;
  const o = pscBozzaLeggi(dove), via = [];
  const chiavi = soli || (dove === 'pc' ? ['pc'] : ['lock', 'home']);
  for (let i = 0; i < chiavi.length; i++){
    const k = chiavi[i], campo = pscBozzaCampo(k);
    if (!b.nuova[k]) continue;
    const ref = await pscSalvaImg((dove === 'pc' ? 'amb_pc_' : 'tel_' + k + '_') + Date.now().toString(36), b.nuova[k]);
    if (!ref){ pscToast('La memoria è piena, l’immagine non si salva'); return false; }
    if (o[campo] && o[campo] !== ref) via.push(o[campo]);
    o[campo] = ref;
    if (dove === 'tel'){ o[k === 'home' ? 'fonteHome' : 'fonte'] = b[k === 'home' ? 'fonteHome' : 'fonte'] || ''; o[k === 'home' ? 'homeAt' : 'lockAt'] = 0; o.at = Date.now(); }
    b[campo] = ref; pscBozzaUrlVia(b, k); delete b.nuova[k];
  }
  if (!soli){ o.inneschi = b.inneschi; o.inneschiNo = b.inneschiNo; o.salvatoAt = Date.now(); }
  if (!(dove === 'pc' ? pscScriviPc(o) : pscScriviTel(o))){ pscToast('La memoria è piena, le modifiche non si salvano'); return false; }
  /* la vecchia immagine si butta solo se nessuno schermo la usa piu' */
  via.forEach(function(r){ if (r !== o.img && r !== o.imgHome) pscImgVia(r); });
  return true;
}
async function pscBozzaSalvaTorna(dove){
  if (!(await pscBozzaScrivi(dove))) return;
  pscBozzaLascia(dove);
  pscVibra([10, 30, 10]); try{ pscRidisegna(); }catch(_){ }
  try{ flIndietro(); }catch(_){ goId('s-home'); }
}
/* la domanda prima di perdere delle modifiche: la stessa della schermata di blocco personalizzata (lockcustom.js, lcChiedi) */
function pscChiediSalva(fSalva, fLascia){
  if (typeof lcChiedi === 'function'){
    lcChiedi('Vuoi salvare le modifiche?', 'Salva', fSalva, 'Lascia stare', fLascia);
    /* sopra anche al foglio della Casa (#inSheet sta a 10050) */
    try{ const l = document.querySelectorAll('.lc-chiedi'); if (l.length) l[l.length - 1].style.zIndex = '10100'; }catch(_){ }
    return;
  }
  let si = false; try{ si = window.confirm('Vuoi salvare le modifiche?'); }catch(_){ }
  if (si) fSalva(); else fLascia();
}
/* il tasto indietro (quello in alto e quello di Android) delle pagine del telefono e del computer */
function pscBozzaIndietro(dove){
  if (pscBozzaSporca(dove)){
    pscChiediSalva(function(){ return pscBozzaSalvaTorna(dove); }, function(){ pscBozzaLascia(dove); try{ flIndietro(); }catch(_){ goId('s-home'); } });
    return null;
  }
  pscBozzaLascia(dove);
  return 's-home';
}
(function(){ try{ if (typeof FL_SALVA_STATO === 'object' && FL_SALVA_STATO){
  FL_SALVA_STATO['s-ambiente-tel'] = function(){ const b = PSC.bozze.tel; return b ? pscBozzaFirma(b) : ''; };
  FL_SALVA_STATO['s-ambiente-pc'] = function(){ const b = PSC.bozze.pc; return b ? pscBozzaFirma(b) : ''; };
} }catch(_){ } })();
/** L'immagine del sogno che l'app usa gia': la copertina della pagina del sogno (costruisci.js), foto o immagine scelta. */
function pscImgSogno(){
  try{
    if (typeof cstCfg === 'function'){
      const c = String(cstCfg().cover || '');
      if (c === 'mia'){ const d = localStorage.getItem('fl_mappa_cover_img') || ''; if (d) return d; }
      else if (/^img\//.test(c)) return c;
    }
  }catch(_){ }
  return '';
}
/* 0.9.388, Andrea (BUG-109): "scelgo un'immagine per il blocco schermo e l'anteprima resta blu con Frase del giorno; e la Home mostra
   l'immagine del blocco schermo anche se per la Home non l'ho scelta (infatti la Home non cambia)". CAUSE: l'anteprima leggeva i dati
   salvati con pscImgUrl, che per un riferimento idb: la prima volta restituisce '' e aspetta IndexedDB (se la lettura non torna,
   PSC.carica restava segnato e l'immagine non arrivava piu'); e pscTelRef dava alla Home l'immagine del blocco schermo quando la Home
   non ne aveva una sua. Adesso l'anteprima legge la bozza della scheda aperta (l'immagine appena scelta sta in memoria e si vede
   subito), ogni scheda ha solo la sua immagine, e sul blocco schermo con la frase accesa la frase vera di oggi sta sopra all'immagine */
function pscTelTestaHtml(){
  const tab = pscTelTab(), lock = tab === 'lock', url = pscBozzaUrl('tel', tab);
  const frase = lock && pscLockAcceso();
  return '<div class="psc-tel-prev"><div class="psc-tel-schermo' + (frase ? ' frase' : '') + (url ? ' foto' : '') + '" data-scheda="' + tab + '"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>'
    + (frase ? '<span class="psc-fatto-velo"></span><p>' + pstE(PSC.telCit || 'Frase del giorno') + '</p>' : (url ? '' : '<span aria-hidden="true">📱</span>')) + '</div></div>'
    + '<p class="psc-tel-p">' + (url ? 'Guarda questa immagine ogni volta che prendi il telefono.' : 'Scegli un’immagine che ti ricorda il sogno.') + '</p>';
}
/** La frase del giorno di oggi (scores.js): la stessa per l'anteprima e per il foglio Fatto. */
async function pscFraseOggi(){
  try{ const q = (typeof scQuotes === 'function') ? await scQuotes() : null; const pk = q && typeof scQuoteFor === 'function' ? scQuoteFor(q, 0) : null; return pk && pk.text ? String(pk.text).replace(/[<>&]/g, '').slice(0, 120) : ''; }catch(_){ return ''; }
}
/* 0.9.388, Andrea (BUG-110): "le due pillole in un contenitore tipo interruttore mi fanno cagare: era meglio come tabs". Sono le
   linguette del pannello Il tuo viaggio (rotta-tab.js: .pst-tabs, .nvp-tabs-in, .pst-tab.nvp-tab, .nvp-em, la barretta .nvp-pos che
   scorre, nvpBarra), con i colori della pagina chiara. Si scrivono una volta: al tocco si spostano solo "on" e la barretta */
function pscTelTabsHtml(){
  return '<div class="pst-tabs psc-tel-tabs" role="tablist" aria-label="Su quale schermo" id="pscTelTabs"><div class="nvp-tabs-in">'
    + [['lock', PSC_TEL_ICO.lock, 'Blocco schermo'], ['home', PSC_TEL_ICO.home, 'Schermata home']].map(function(x){
        return '<button type="button" role="tab" data-psc-tab="' + x[0] + '" aria-controls="pscTelResto" aria-selected="false" class="pst-tab nvp-tab" onclick="pscTelVaiTab(\'' + x[0] + '\')"><i class="nvp-em" aria-hidden="true">' + x[1] + '</i><span>' + x[2] + '</span></button>';
      }).join('') + '<span class="nvp-pos" aria-hidden="true"></span></div></div>';
}
function pscTelTabsSegna(anima){
  const row = document.getElementById('pscTelTabs'); if (!row) return;
  const tab = pscTelTab();
  row.querySelectorAll('.nvp-tab').forEach(function(b){ const on = b.getAttribute('data-psc-tab') === tab; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
  if (typeof nvpBarra !== 'function') return;
  nvpBarra(!!anima, row);
  /* la pagina appena aperta non ha ancora le misure: la barretta si rimette a posto quando arrivano */
  if (typeof ResizeObserver === 'function' && !row._ro){ row._ro = new ResizeObserver(function(){ nvpBarra(false, row); }); row._ro.observe(row); if (row.firstElementChild) row._ro.observe(row.firstElementChild); }
}
function pscTelPaint(){
  const box = document.getElementById('pscTelBody'); if (!box) return;
  pscBozzaDi('tel');
  let nuova = false;
  if (!document.getElementById('pscTelTabs') || !document.getElementById('pscTelResto')){
    box.innerHTML = '<div id="pscTelTesta"></div>' + pscTelTabsHtml() + '<div id="pscTelResto" class="psc-tel-resto"></div>';
    nuova = true;
  }
  document.getElementById('pscTelTesta').innerHTML = pscTelTestaHtml();
  document.getElementById('pscTelResto').innerHTML = pscTelRestoHtml();
  if (nuova) pscTelTabsSegna(false);
  if (pscTelTab() === 'lock' && pscLockAcceso() && !PSC.telCit && !PSC.telCitP){
    PSC.telCitP = pscFraseOggi().then(function(c){ PSC.telCitP = null; if (c){ PSC.telCit = c; const tt = document.getElementById('pscTelTesta'); if (tt) tt.innerHTML = pscTelTestaHtml(); } });
  }
}
function pscTelRestoHtml(){
  const b = pscBozzaDi('tel'), t = pscTel(), sogno = pscImgSogno(), prem = pscPremium(), q = pscLockAcceso();
  /* 0.9.386, Andrea: "niente piu' i pulsanti blu e rosso di Dove la metti: subito dopo la frase due schede, Blocco schermo e Schermata
     home. Dentro a ognuna scegli l'immagine, la frase del giorno sopra, e la metti su quello schermo". Ogni schermo ha la sua immagine
     (img per il blocco schermo, imgHome per la Home) */
  const tab = pscTelTab(), url = pscBozzaUrl('tel', tab), lock = tab === 'lock';
  /* "Messa il" solo se la scheda ha un'immagine sua e non ne hai appena scelta un'altra */
  const at = (b.nuova[tab] || !b[pscBozzaCampo(tab)]) ? 0 : (lock ? t.lockAt : t.homeAt);
  return '<div class="psc-tel-pan" role="tabpanel">'
    + '<div class="psc-fonti"><button type="button" onclick="pscTelGalleria()">' + PSC_TEL_ICO.galleria + '<span>Scegli dalla galleria</span></button>'
    + (sogno ? '<button type="button" onclick="pscTelSogno()">' + PSC_TEL_ICO.sogno + '<span>Usa la copertina del sogno</span></button>' : '') + '</div>'
    + (lock
      ? '<div class="psc-riga-sw psc-tel-sw' + (prem ? '' : ' chiusa') + '"' + (prem ? '' : ' role="button" tabindex="0" onclick="pscLockToggle()"') + '>'
        + '<div><b>La frase del giorno sopra</b><small>Ogni giorno una frase nuova sopra alla tua immagine.</small>' + (prem ? '' : '<span class="psc-prem">⭐ Premium</span>') + '</div>'
        + (prem ? '<button type="button" class="switch' + (q ? ' on' : '') + '" id="pscLockSw" role="switch" aria-checked="' + q + '" aria-label="La frase del giorno sul blocco schermo" onclick="pscLockToggle()"></button>'
          : '<span class="switch psc-sw-chiuso" aria-hidden="true"></span>')
        + '</div>'
      : '<p class="psc-tel-n">La frase del giorno si vede solo sul blocco schermo: sulla Home resta la tua immagine.</p>')
    + '<button type="button" class="en-cta psc-tel-ok' + (url ? '' : ' spento') + '" onclick="pscTelMetti(\'' + tab + '\')">' + (lock ? 'Metti sul blocco schermo' : 'Metti sulla schermata home') + '</button>'
    + (at ? '<small class="psc-tel-at">Messa il ' + pscData(at) + '</small>' : '')
    + '</div>'
    + pscInnDigHtml('tel', b)
    /* 0.9.381, Andrea: "il telefono non ha il pulsante Salva: deve comparire solo dopo una modifica" (registry.js, FL_SALVA) */
    + '<button type="button" class="en-cta psc-salva" onclick="pscAmbSalvaTorna()">Salva</button>';
}
function pscAmbSalvaTorna(){
  /* 0.9.386: salvare la card conta come averle risposto (letturaSbloccata, il passaggio Mappa il tuo ambiente: salvatoAt).
     0.9.388 (BUG-108): Salva e' l'unico momento in cui la bozza diventa i dati veri */
  let suPc = false;
  try{ const pc = document.getElementById('s-ambiente-pc'); suPc = !!(pc && pc.classList.contains('active')); }catch(_){ }
  return pscBozzaSalvaTorna(suPc ? 'pc' : 'tel');
}
/* 0.9.378, Andrea: "anche nella card del telefono le opzioni per gli inneschi visivi: c'e' l'ambiente fisico e l'ambiente digitale".
   Due contatori: le app e i widget che ti ricordano il sogno, e le app che ti portano lontano. 0.9.388 (BUG-108): vanno nella bozza
   della pagina (t e' la bozza) e si scrivono con Salva */
function pscInnDigHtml(dove, t){
  const st = function(k, max){ const v = t[k] == null ? '' : String(t[k]);
    return '<div class="md-step psc-step"><button type="button" onclick="pscInnDig(\'' + dove + '\',\'' + k + '\',-1)" aria-label="Meno">−</button>'
      + '<input class="psc-step-n" type="number" inputmode="numeric" min="0" max="' + max + '" placeholder="0" value="' + pstE(v) + '" onchange="pscInnDigSet(\'' + dove + '\',\'' + k + '\',this.value)">'
      + '<button type="button" onclick="pscInnDig(\'' + dove + '\',\'' + k + '\',1)" aria-label="Più">+</button></div>'; };
  return '<section class="psc-blocco"><p class="psc-k">Gli inneschi sul ' + (dove === 'pc' ? 'computer' : 'telefono') + '</p>'
    + pscCampo('pscDig1' + dove, 'Quante app o immagini ti ricordano il sogno?', st('inneschi', 99), 'Uno sfondo con il sogno, un widget con la tua frase, un\'app che ti fa lavorare.')
    + pscCampo('pscDig2' + dove, '<span class="psc-rosso">Quante app ti portano lontano?</span>', st('inneschiNo', 99), (dove === 'pc' ? 'I siti e i programmi aperti che ti distraggono appena li vedi.' : 'Le app che ti distraggono appena le vedi sulla schermata Home.'))
    + '</section>';
}
function pscInnDigSet(dove, k, v){
  const o = pscBozzaDi(dove === 'pc' ? 'pc' : 'tel');
  o[k] = v === '' ? null : Math.max(0, Math.min(99, parseInt(v, 10) || 0));
}
function pscInnDig(dove, k, d){
  const o = pscBozzaDi(dove === 'pc' ? 'pc' : 'tel');
  pscInnDigSet(dove, k, String(Math.max(0, (+o[k] || 0) + d)));
  pscVibra(6);
  if (dove === 'pc') pscPcPaint(); else pscTelPaint();
}
/* IL COMPUTER (0.9.378). Andrea: "se l'utente ha collegato la versione PC, la card di preset del computer come per il telefono: lo
   sfondo del blocco schermo e quello del desktop". L'immagine si sceglie sul computer, perche' e' li' che va messa: dal telefono la
   card tiene gli inneschi e dice dove si cambia lo sfondo. fl_ambiente_pc = { img, inneschi, inneschiNo, deskAt, lockAt } */
const PSC_PC = 'fl_ambiente_pc';
function pscPc(){ const t = pstJ(PSC_PC, {}); return (t && typeof t === 'object' && !Array.isArray(t)) ? t : {}; }
function pscScriviPc(t){ try{ localStorage.setItem(PSC_PC, JSON.stringify(t)); return true; }catch(_){ return false; } }
function pscPcApri(){ pscVibra(6); pscBozzaLascia('pc'); pscBozzaDi('pc'); goId('s-ambiente-pc'); pscPcPaint(); }
function pscPcQui(){ try{ return typeof mwQuiComputer === 'function' && mwQuiComputer(); }catch(_){ return false; } }
const PSC_PC_ICO_DESK = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>';
function pscPcPaint(){
  const box = document.getElementById('pscPcBody'); if (!box) return;
  /* 0.9.388 (BUG-108): l'immagine e i contatori sono quelli della bozza; deskAt e lockAt quelli salvati */
  const t = pscPc(), b = pscBozzaDi('pc'), url = pscBozzaUrl('pc', 'pc'), sogno = pscImgSogno(), qui = pscPcQui();
  const tile = function(k, ico, txt, at){ return '<button type="button" class="psc-tile psc-tile-' + k + (url ? '' : ' spento') + '" onclick="pscPcMetti(\'' + k + '\')"><span aria-hidden="true">' + ico + '</span><b>' + txt + '</b>' + (at ? '<small>Messa il ' + pscData(at) + '</small>' : '') + '</button>'; };
  box.innerHTML = '<div class="psc-pc-prev"><div class="psc-pc-schermo"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : '<span aria-hidden="true">💻</span>') + '</div><i class="psc-pc-base" aria-hidden="true"></i></div>'
    + (qui
      ? '<p class="psc-tel-p">' + (url ? 'La vedi ogni volta che accendi il computer.' : 'Scegli un’immagine che ti ricorda il sogno.') + '</p>'
        + '<div class="psc-fonti"><button type="button" onclick="pscPcGalleria()">' + PSC_TEL_ICO.galleria + '<span>Scegli un’immagine</span></button>' + (sogno ? '<button type="button" onclick="pscPcSogno()">' + PSC_TEL_ICO.sogno + '<span>Usa la copertina del sogno</span></button>' : '') + '</div>'
        + '<section class="psc-blocco"><p class="psc-k">Dove la metti</p><div class="psc-tiles">' + tile('desk', PSC_PC_ICO_DESK, 'Metti come sfondo del desktop', t.deskAt) + tile('lock', PSC_TEL_ICO.lock, 'Metti sul blocco schermo', t.lockAt) + '</div></section>'
      : '<p class="psc-tel-p">Lo sfondo del computer si sceglie dal computer: apri DreamMap lì e tocca questa card.</p>')
    + pscInnDigHtml('pc', b)
    + '<button type="button" class="en-cta psc-salva" onclick="pscAmbSalvaTorna()">Salva</button>';
}
function pscPcGalleria(){ pscScegliFoto(function(img){ pscPcImposta(pscRiduci(img, 2400, .88)); }); }
async function pscPcSogno(){
  const src = pscImgSogno(); if (!src) return;
  try{ const img = await pscCaricaImg(src); await pscPcImposta(pscRiduci(img, 2400, .88)); }catch(_){ pscToast('Non riesco a leggere la copertina del sogno'); }
}
async function pscPcImposta(dato){
  if (!dato){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
  /* 0.9.388 (BUG-108): l'immagine scelta resta nella bozza finche' non tocchi Salva o "Metti come sfondo..." */
  pscBozzaImmagine('pc', 'pc', dato, '');
  pscVibra(8); pscPcPaint();
}
async function pscPcMetti(dove){
  if (!pscBozzaHaImg('pc', 'pc')){ pscToast('Scegli prima un’immagine'); return; }
  const url = pscBozzaUrl('pc', 'pc');
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setDesktopWallpaper){
    try{ await NATIVE.setDesktopWallpaper({ image: url, target: dove }); }
    catch(e){ pscToast(pscErr(e)); return; }
    if (!(await pscBozzaScrivi('pc', ['pc']))) return;
    const t = pscPc(); t[dove === 'lock' ? 'lockAt' : 'deskAt'] = Date.now(); pscScriviPc(t); pscPcPaint(); try{ pscRidisegna(); }catch(_){ }
    pscToast(dove === 'lock' ? 'Messa sul blocco schermo' : 'Messa come sfondo del desktop'); return;
  }
  /* mettere l'immagine e' una scelta: si salva anche quando il computer la fa scaricare */
  if (!(await pscBozzaScrivi('pc', ['pc']))) return;
  pscPcPaint();
  /* l'app del computer che non sa ancora cambiare lo sfondo: l'immagine si scarica e si mette in due tocchi */
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Mettila in due tocchi</h3>'
    + flInfoRighe([
      ['⬇️', 'Scarica l’immagine', 'Il pulsante qui sotto la salva nella cartella Download.'],
      ['🖱️', 'Tasto destro sull’immagine', dove === 'lock' ? 'Scegli Imposta come sfondo, poi in Impostazioni, Personalizzazione, Schermata di blocco, scegli l’immagine.' : 'Scegli Imposta come sfondo del desktop.']
    ])
    + '<a class="en-cta" style="display:block;text-align:center;text-decoration:none" href="' + url + '" download="DreamMap-sfondo.jpg" onclick="setTimeout(inSheetChiudi,300)">Scarica l’immagine</a></div>');
}

/* 0.9.389, Andrea 25/11: "nella card del computer in alto a destra c'e' un pulsante info che non apre niente: e' grigio, senza icona
   SVG e senza la i, che invece c'e' nella card del telefono". Era un segnaposto vuoto: adesso e' lo stesso pulsante, con la sua spiegazione. */
function pscPcInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il computer come innesco</h3>'
    + flInfoRighe([
      ['💻', 'Lo accendi per lavorare', 'Il primo schermo che vedi decide come cominci.'],
      ['🎯', 'Mettici il sogno', 'Sullo sfondo o sul blocco schermo, ti ricorda per cosa stai lavorando.'],
      ['🧲', 'Conta gli inneschi', 'Quante cose sul computer ti portano verso il sogno, e quante lontano.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pscTelInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il telefono come innesco</h3>'
    + flInfoRighe([
      ['👀', 'Lo guardi sempre', 'Prendi il telefono decine di volte al giorno.'],
      ['🎯', 'Mettici il sogno', 'Ogni volta che lo sblocchi, l’immagine ti ricorda dove stai andando.'],
      ['💬', 'Oppure una frase', 'Con Premium il blocco schermo mostra una frase nuova ogni giorno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/** Un'immagine nuova per il telefono: lato lungo 1600 px, per non vederla sgranata sullo schermo intero.
    0.9.388 (BUG-108/109): va nella bozza della SUA scheda (target), non nei dati salvati e non nell'altra scheda. */
function pscTelImposta(dato, fonte, target){
  if (!dato){ pscToast('Non riesco a leggere questa foto, provane un’altra'); return; }
  pscBozzaImmagine('tel', target === 'home' ? 'home' : 'lock', dato, fonte);
  pscVibra(8);
  pscTelPaint();
}
function pscTelGalleria(){ const tab = pscTelTab(); pscScegliFoto(function(img){ pscTelImposta(pscRiduci(img, 1600, .86), 'galleria', tab); }); }
async function pscTelSogno(){
  const src = pscImgSogno(); if (!src) return;
  const tab = pscTelTab();
  try{ const img = await pscCaricaImg(src); await pscTelImposta(pscRiduci(img, 1600, .86), 'sogno', tab); }
  catch(_){ pscToast('Non riesco a leggere la copertina del sogno'); }
}
/* le due schede della pagina del telefono: quale e' aperta, e l'immagine di ciascuna */
function pscTelTab(){ return PSC.telTab === 'home' ? 'home' : 'lock'; }
function pscTelVaiTab(k){ if (pscTelTab() === k) return; PSC.telTab = k === 'home' ? 'home' : 'lock'; pscVibra(6); pscTelTabsSegna(true); pscTelPaint(); }
/* 0.9.388 (BUG-109): ogni schermo solo la sua immagine. Prima la Home senza imgHome prendeva quella del blocco schermo */
function pscTelRef(t, target){ return (target === 'home' ? t.imgHome : t.img) || ''; }
const PSC_TEL_ICO = {
  lock: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  home: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l9-7 9 7"/><path d="M5.5 9.5V20h13V9.5"/></svg>',
  galleria: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="9.5" r="1.8"/><path d="M21 16l-5.5-5.5L5 20"/></svg>',
  sogno: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/></svg>'
};
function pscErr(e){
  const m = String((e && (e.message || e.errorMessage)) || '');
  if (/not implemented|unimplemented/i.test(m) || (e && e.code === 'UNIMPLEMENTED')) return 'Aggiorna l’app per mettere lo sfondo';
  return m || 'Non riuscito, riprova fra poco';
}
async function pscTelMetti(target){
  target = target === 'home' ? 'home' : 'lock';
  if (!pscBozzaHaImg('tel', target)){ pscToast('Scegli prima un’immagine'); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setWallpaperImage){ pscToast('Disponibile nell’app installata'); return; }
  /* 0.9.381, Andrea: "Spegni la frase e metti la foto, Metti la foto e tieni la frase: sembra metti la cera togli la cera. Non e' una
     scelta: la frase ha gia' il suo sfondo". Con la frase accesa l'immagine diventa lo sfondo della frase (LockQuote, lato nativo), e un
     foglio con l'anteprima lo conferma e si chiude da solo */
  const frase = target === 'lock' && await pscLockSync();
  await pscTelApplica(target, frase);
}
/* 0.9.354: la frase del giorno ridisegna il blocco schermo ogni giorno e domani coprirebbe la foto. Si chiede prima */
function pscTelAvviso(){
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">💬</span><h3>La frase del giorno è accesa</h3>'
    + '<p class="psc-fg-p">Domani la frase coprirà la tua foto sul blocco schermo.</p>'
    + '<button type="button" class="en-cta" onclick="pscTelSpegniEMetti()">Spegni la frase e metti la foto</button>'
    + '<button type="button" class="psc-fg-2" onclick="inSheetChiudi();pscTelApplica(\'lock\')">Metti la foto e tieni la frase</button></div>');
}
async function pscTelSpegniEMetti(){
  inSheetChiudi();
  if (await pscLockSync() && typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  await pscTelApplica('lock');
}
async function pscTelApplica(target, frase){
  target = target === 'home' ? 'home' : 'lock';
  /* 0.9.388 (BUG-109): i byte sono quelli della scheda da cui hai toccato Metti (la bozza: l'immagine appena scelta o quella salvata) */
  const dato = await pscBozzaDato('tel', target);
  if (!dato){ pscToast('Non trovo l’immagine, sceglila di nuovo'); return; }
  try{ await NATIVE.setWallpaperImage({ data: dato, target: target }); }
  catch(e){ pscToast(pscErr(e)); return; }
  /* 0.9.388 (BUG-108): mettere l'immagine sullo schermo e' come salvarla, ma solo quella: le altre modifiche restano nella bozza */
  if (!(await pscBozzaScrivi('tel', [target]))) return;
  const n = pscTel(); n[target === 'lock' ? 'lockAt' : 'homeAt'] = Date.now(); pscScriviTel(n);
  pscVibra([10, 30, 10]);
  pscTelPaint();
  pscTelFatto(target, !!frase);
  pscRidisegna();
}
/* LA FRASE DEL GIORNO: lo stato vero lo sa il telefono (getLockQuote). Si copia sulle due levette, poi si usa la stessa funzione */
async function pscLockSync(){
  let on = pscLockAcceso();
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getLockQuote){ const st = await NATIVE.getLockQuote(); on = !!(st && st.on); try{ if (on) localStorage.setItem('fl_lockquote_on', '1'); else localStorage.removeItem('fl_lockquote_on'); }catch(_){ } } }catch(_){ }
  const a = document.getElementById('inspLockSw'); if (a) a.className = 'switch' + (on ? ' on' : '');
  const b = document.getElementById('pscLockSw'); if (b){ b.className = 'switch' + (on ? ' on' : ''); b.setAttribute('aria-checked', String(on)); }
  return on;
}
async function pscLockToggle(){
  if (!pscPremium()){ if (typeof pfApri === 'function') pfApri(); return; }
  await pscLockSync();
  if (typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  pscTelPaint();
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   AZIONE
   --------------------------------------------------------------------------------------- */
function pscAzioni(){ const l = pstJ(PSC_AZIONI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id && x.t; }) : []; }
function pscScriviAzioni(l){ try{ localStorage.setItem(PSC_AZIONI, JSON.stringify(l)); return true; }catch(_){ return false; } }
/* 0.9.381, Andrea: "Sto leggendo le attivita' del telefono non scompare mai, resta li'". CAUSA: una delle letture (la radiografia, il
   riassunto del tuo agente, il ponte con le AI) a volte non risponde: l'attesa non finiva e la scritta restava per sempre. Ogni lettura ha
   ora al massimo 6 secondi; quello che arriva si mostra, il resto si salta */
function pscEntro(p, ms){ return Promise.race([Promise.resolve(p), new Promise(function(r){ setTimeout(function(){ r(null); }, ms || 6000); })]); }
async function pscAzCarica(per){
  if (PSC.azCarica[per]) return;
  PSC.azCarica[per] = true;
  try{ await pscAzCarica0(per); }catch(_){ PSC.az[per] = PSC.az[per] || { at: Date.now(), apps: [], siti: [], ricerche: [], frasi: [], browser: false }; }
  PSC.azCarica[per] = false;
  pscRidisegna();
}
async function pscAzCarica0(per){
  const F = pstFinestra(per), out = { at: Date.now(), apps: [], siti: [], ricerche: [], frasi: [], browser: false };
  if (typeof NATIVE === 'undefined' || !NATIVE) out.browser = true;
  else {
    try{
      if (NATIVE.getTopApps){
        const r = await pscEntro(NATIVE.getTopApps({ from: F.da, to: F.a, limit: 40, icons: 8 }));
        out.tutte = ((r && r.apps) || []).filter(function(a){ const p = String(a && a.packageName || ''); return a && (a.ms || 0) >= 60000 && p.indexOf('com.dreambrothers') !== 0 && !(typeof tlLauncher === 'function' && tlLauncher(p)); });
        out.apps = out.tutte.slice(0, 4);
      }
    }catch(_){ }
    try{
      if (NATIVE.getWebTime){ const w = await pscEntro(NATIVE.getWebTime({ from: F.da, to: F.a, bucket: 'none', limit: 40 })); out.sitiTutti = ((w && w.sites) || []).filter(function(s){ return s && s.host; }); out.siti = out.sitiTutti.slice(0, 3); }
    }catch(_){ }
    try{
      if (typeof tlRadioLeggi === 'function'){
        const r = await pscEntro(tlRadioLeggi(F.da, F.a)), per0 = {};
        ((r && r.eventi) || []).forEach(function(e0){
          const e = (typeof tlRicercaVera === 'function') ? tlRicercaVera(e0) : e0;
          if (!e || e.tipo !== 'ricerca' || !e.cosa) return;
          const testo = String(e.cosa).trim(), k = testo.toLowerCase();
          if (k.length < 2) return;
          if (!per0[k]) per0[k] = { t: testo.slice(0, 60), n: 0, at: 0 };
          per0[k].n++; if (+e.t > per0[k].at) per0[k].at = +e.t;
        });
        out.ricerche = Object.keys(per0).map(function(k){ return per0[k]; }).sort(function(a, b){ return b.n - a.n || b.at - a.at; }).slice(0, 4);
      }
    }catch(_){ }
  }
  /* 0.9.401 BUG-192: le abitudini misurate non si leggono piu' qui. Stavano dentro ai 6 secondi di questa lettura, dopo l'attesa del
     computer: sul telefono di Andrea (30 giorni, sette notti da leggere) arrivavano tardi, la lettura le buttava e la scheda Azione non
     mostrava ne' il sonno ne' il task switching. Ora hanno la loro lettura (pscAbCarica) e le card compaiono appena arrivano */
  if (pscPremium()){
    try{
      const r = (typeof tlRiassuntoDi === 'function') ? await pscEntro(tlRiassuntoDi(0)) : null;
      out.frasi = (typeof tlFrasiPremium === 'function') ? (tlFrasiPremium(r || ((typeof tlRiassunto === 'function') ? tlRiassunto(null) : {}), 0) || []).slice(0, 3) : [];
    }catch(_){ out.frasi = []; }
    try{ if (typeof pntSync === 'function') await pscEntro((typeof pntUsato === 'function' && !pntUsato()) ? pntSync(true) : pntSync(false), 4000); }catch(_){ }
  }
  PSC.az[per] = out;
}
function pscAzioneHtml(){
  const per = PST.per, d = PSC.az[per];
  if (!d || Date.now() - d.at > 60000) pscAzCarica(per);
  const a = PSC.abit[per];
  if (!a || Date.now() - a.at > 300000) pscAbCarica(per);
  return '<div class="psc-az">' + pscAzCardHtml(d, per) + '</div>';
}
/* 0.9.401 BUG-192: le abitudini che l'app misura da sola (abitudini.js, abtAbitudini: sonno, focus e riposo con scCompute e
   scReportPunteggi come la scheda Profilo, il task switching con i contatori della dopamina). Una lettura sua, con 25 secondi di tempo:
   quello che arriva resta per cinque minuti */
PSC.abit = {}; PSC.abCarica = {};
async function pscAbCarica(per){
  if (PSC.abCarica[per] || typeof abtAbitudini !== 'function') return;
  PSC.abCarica[per] = true;
  try{
    try{ if (typeof pcSync === 'function') await pscEntro(pcSync(false), 3000); }catch(_){ }
    const r = await pscEntro(abtAbitudini(per), 25000);
    if (r && r.righe) PSC.abit[per] = r;
    else if (!PSC.abit[per]) PSC.abit[per] = { at: Date.now() - 240000, righe: [], vuota: true };
  }catch(_){ if (!PSC.abit[per]) PSC.abit[per] = { at: Date.now() - 240000, righe: [], vuota: true }; }
  PSC.abCarica[per] = false;
  pscRidisegna();
}
/* ---------------------------------------------------------------------------------------
   AZIONE (0.9.374). Andrea: "in Azione non voglio gli insights del tuo agente (la domenica salti piu' tappe): quelli sono
   pattern e stanno nella Timeline. Come per l'ambiente, servono card di azioni, di abitudini: binge watching, scrolling sui social,
   le telefonate, la navigazione, ma anche quelle sane come il Full Focus. Aggiungibili e rimovibili. Prima le card; poi, se tocchi
   Chiedi al tuo agente personale, parte come nel Rientra in rotta: vedi dove va la tua attenzione, cosi' capisci che le card si
   basano su dati veri. Chi non ha Premium non ha la chat ma un questionario come la lettura del Genio".
   Le card proposte nascono dai dati del telefono (le app per categoria, i siti, le sessioni di Full Focus) e dalla lettura del
   Genio (i momenti in cui prendi il telefono senza pensarci). La X le toglie (fl_azioni_via); toccandole diventano tue
   (fl_azioni_id, con la chiave k della proposta).
   --------------------------------------------------------------------------------------- */
const PSC_AZ_VIA = 'fl_azioni_via';
const PSC_AZ_CAT = [
  { k: 'adulti', em: '🔞', t: 'Siti per adulti', tipo: 'cambia', cat: 1, app: 1, re: /^$/ },
  { k: 'social', em: '📲', t: 'Scrolling sui social', tipo: 'cambia', re: /instagram|tiktok|musically|zhiliaoapp|facebook\.katana|facebook\.lite|twitter|com\.x\.android|reddit|snapchat|threads|pinterest|tumblr|bereal/ },
  /* 0.9.397, Andrea: "chiama binge watching anche le ore di YouTube che sono solo sottofondo, un podcast mentre guidi". Il binge
     watching non e' la somma del giorno: sono sessioni continue di video di 2-3 ore, ripetute piu' sere a settimana per settimane.
     La card nasce solo dal verdetto di abitudini.js (abtBinge); qui la categoria serve a non contare questi minuti altrove. YouTube
     Music non e' video */
  { k: 'video', em: '🍿', t: 'Binge watching', tipo: 'cambia', binge: true, re: /^(?!.*youtube\.music)(?=.*(youtube|netflix|primevideo|amazon\.avod|disney|twitch|hbo|raiplay|mediaset|dazn|crunchyroll|vimeo|paramount|skygo|nowtv))/ },
  { k: 'chat', em: '💬', t: 'Chat e messaggi', tipo: 'cambia', cat: 180, app: 150, re: /whatsapp|telegram|messenger|facebook\.orca|signal|discord|viber|android\.mms|messaging/ },
  { k: 'tel', em: '📞', t: 'Telefonate', tipo: 'cambia', cat: 240, app: 240, re: /dialer|incallui|android\.phone|contacts|telecom/ },
  { k: 'giochi', em: '🎮', t: 'Giochi', tipo: 'cambia', cat: 60, app: 45, re: /\.game|games|supercell|king\.|roblox|mojang|playrix|miniclip|rovio|zynga|chess/ },
  { k: 'shop', em: '🛍️', t: 'Shopping online', tipo: 'cambia', re: /amazon\.mshop|ebay|zalando|shein|temu|aliexpress|vinted|subito|wish/ },
  { k: 'news', em: '📰', t: 'Notizie a raffica', tipo: 'cambia', re: /news|repubblica|corriere|ansa|flipboard|bbc|cnn|ilpost/ },
  { k: 'web', em: '🌐', t: 'Navigazione sul web', tipo: 'cambia', re: /chrome|firefox|browser|opera|brave|microsoft\.emmx|sbrowser|duckduckgo/ },
  { k: 'lavoro', em: '🛠️', t: 'Lavoro sul sogno', tipo: 'nuova', cat: 10, app: 10, re: /anthropic|claude|openai|chatgpt|notion|shopify|gemini|figma|canva|google\.android\.apps\.docs|slack|trello|asana|linkedin/ }
];
/* 0.9.375, Andrea: "18 minuti di navigazione, 15 di telefonate, 9 di YouTube non sono abitudini: se gli dici da cambiare ti manda a fare
   in culo". Una categoria diventa una card solo se pesa davvero: di serie 2 ore al giorno in tutto, oppure 45 minuti al giorno su una
   sola app (i giochi da 1 ora, chat e telefonate solo oltre le 3-4 ore, i siti per adulti sempre). Le soglie sono minuti al giorno. */
const PSC_AZ_SOGLIA = { cat: 120, app: 45 };
const PSC_AZ_ADULTI = /porn|xvideos|xnxx|xhamster|redtube|youporn|onlyfans|chaturbate|brazzers|spankbang|stripchat|livejasmin|cam4|bongacams/;
function pscAzVia(){ const l = pstJ(PSC_AZ_VIA, []); return Array.isArray(l) ? l : []; }
function pscAzNome(a){ return a.label || a.appName || String(a.packageName || '').split('.').pop(); }
function pscAzOreCorte(ms){ const m = Math.round((ms || 0) / 60000); if (m < 60) return m + ' min'; const h = Math.floor(m / 60), r = m % 60; return h + ' h' + (r ? ' ' + r + ' min' : ''); }
function pscAzProposte(d, per){
  const out = [], giorni = Math.max(1, per);
  if (d && !d.browser){
    const presa = {};
    PSC_AZ_CAT.forEach(function(c){
      let app;
      if (c.k === 'adulti') app = (d.sitiTutti || d.siti || []).filter(function(s){ return PSC_AZ_ADULTI.test(String(s && s.host || '').toLowerCase()); }).map(function(s){ return { label: String(s.host).replace(/^www\./, ''), ms: s.ms || 0 }; });
      else {
        app = (d.tutte || d.apps || []).filter(function(a){ const p = String(a && a.packageName || '').toLowerCase(); return p && !presa[p] && c.re.test(p); });
        app.forEach(function(a){ presa[String(a.packageName).toLowerCase()] = 1; });
      }
      if (c.binge) return;
      if (!app.length) return;
      app = app.slice().sort(function(a, b){ return (b.ms || 0) - (a.ms || 0); });
      const ms = app.reduce(function(s, a){ return s + (a.ms || 0); }, 0);
      const minG = ms / giorni / 60000, top = (app[0].ms || 0) / giorni / 60000;
      const sc = c.cat || PSC_AZ_SOGLIA.cat, sa = c.app || PSC_AZ_SOGLIA.app;
      if (!(minG >= sc || top >= sa)) return;
      let lista = app.slice(0, 6).map(function(a){ return { n: pscAzNome(a), media: (a.ms || 0) / giorni }; });
      if (c.k === 'web' && d.siti && d.siti.length) lista = (d.sitiTutti || d.siti).slice().sort(function(a, b){ return (b.ms || 0) - (a.ms || 0); }).slice(0, 6).map(function(s){ return { n: String(s.host).replace(/^www\./, ''), media: (s.ms || 0) / giorni }; });
      lista = lista.filter(function(x){ return x.media >= 60000; });
      out.push({ k: c.k, em: c.em, t: c.t, tipo: c.tipo, ms: ms, media: ms / giorni, det: lista.length ? lista[0].n + ' ' + pscAzOreCorte(lista[0].media) : '', app: lista, fonte: 'telefono' });
    });
  }
  /* il binge watching: solo quando e' un'abitudine (abtBinge: sessioni di 2 ore o piu', 3 sere a settimana, da 3 settimane) */
  try{
    const ab = (d && d.abit) || (PSC.abit && PSC.abit[per]), bg = ab && ab.binge;
    if (bg && bg.livello === 'abitudine') out.push({ k: 'video', em: '🍿', t: 'Binge watching', tipo: 'cambia', ms: 0, media: 0,
      det: (typeof abtNum === 'function' ? abtNum(bg.sereSettimana) : bg.sereSettimana) + ' sere a settimana, da ' + bg.settimane + ' settimane', fonte: 'telefono' });
  }catch(_){ }
  try{
    const F = pstFinestra(per);
    const ff = (typeof ffHist === 'function' ? ffHist() : []).filter(function(v){ return v && +v.at >= F.da; });
    if (ff.length){
      const ms = ff.reduce(function(s, v){ return s + (v.spentMs || (v.min || 0) * 60000); }, 0);
      out.push({ k: 'ff', em: '🎯', t: 'Sessioni di Full Focus', tipo: 'nuova', ms: ms, media: ms / giorni, det: ff.length === 1 ? '1 sessione' : ff.length + ' sessioni', fonte: 'telefono' });
    }
  }catch(_){ }
  try{
    const o = JSON.parse(localStorage.getItem('fl_oracle') || '{}');
    (o.trigger || []).forEach(function(id){
      const t = (typeof OR_TRIGGER !== 'undefined' ? OR_TRIGGER : []).filter(function(x){ return x.id === id; })[0];
      if (t) out.push({ k: 'tr_' + id, em: t.ico, t: 'Il telefono ' + t.t.charAt(0).toLowerCase() + t.t.slice(1), tipo: 'cambia', fonte: 'lettura' });
    });
  }catch(_){ }
  const via = pscAzVia(), mie = pscAzioni().map(function(a){ return a.k; }).filter(Boolean);
  return out.filter(function(x){ return via.indexOf(x.k) < 0 && mie.indexOf(x.k) < 0; })
    .sort(function(a, b){ return (a.tipo === b.tipo ? 0 : (a.tipo === 'cambia' ? -1 : 1)) || (b.ms || 0) - (a.ms || 0); });
}
function pscAzFonteTxt(f){ return f === 'lettura' ? 'Dalla lettura del Genio' : (f === 'mia' ? 'Scritta da te' : 'Dal tuo telefono'); }
/* 0.9.401 BUG-192, Andrea: "nella scheda Azione mancano task switching, sonno e l'abitudine di focus e riposo della scheda Profilo: vanno
   mostrati come abitudini. Il sottotitolo diventa Le tue abitudini (i) negli ultimi 30 giorni, la scheda continua a chiamarsi Azione. Le
   abitudini mappate dall'app non si possono eliminare; quelle create dall'utente si'. I tre puntini aprono un menu: il layout (una colonna a
   carosello, una cosa alla volta, oppure due colonne), modifica e rimuovi, e una voce chiara Rimetti le predefinite".
   Tre tipi di card, nella stessa griglia e nello stesso ordine salvato (fl_azioni_ordine):
     · 'm:<k>' le abitudini MISURATE dall'app (abtAbitudini): il segno "Misurata dall'app", nessuna X, mai;
     · 'p:<k>' le proposte nate dai dati del telefono e dalla lettura del Genio: anche loro le mappa l'app, quindi niente X. Toccandole
       diventano tue;
     · 'a:<id>' le tue: le uniche che "Rimuovi" toglie. */
const PSC_AB_FISSE = ['sonno', 'switch', 'focus', 'riposo'];
const PSC_AB_BASE = { sonno: ['🌙', 'Sonno'], switch: ['🔀', 'Task switching'], focus: ['⏳', 'Focus'], riposo: ['🌲', 'Riposo'] };
const PSC_MISURA = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15a8 8 0 0 1 16 0"/><path d="M12 15l3.5-4.5"/></svg>';
/** Le righe delle abitudini misurate del periodo: quelle della lettura della scheda (d.abit, nei test) o quelle di pscAbCarica. */
function pscAbRighe(d, per){
  const a = (d && d.abit) || (PSC.abit && PSC.abit[per]);
  return a && Array.isArray(a.righe) ? a.righe : null;
}
/** Le card delle abitudini misurate: le quattro fisse sempre (sonno, task switching, focus, riposo), le altre solo quando hanno un dato. */
function pscAbVoci(d, per){
  const righe = pscAbRighe(d, per), per0 = {};
  (righe || []).forEach(function(r){ if (r && r.k) per0[r.k] = r; });
  const l = PSC_AB_FISSE.map(function(k){ return per0[k] || { k: k, em: PSC_AB_BASE[k][0], t: PSC_AB_BASE[k][1], val: '', sub: '', stato: righe ? 'manca' : 'attesa' }; })
    .concat((righe || []).filter(function(r){ return r && PSC_AB_FISSE.indexOf(r.k) < 0 && r.stato !== 'manca'; }));
  PSC.abVoci = l;
  return l;
}
/** I punteggi del Profilo si leggono "su 100"; il task switching ha gia' la sua unita'. */
function pscAbSu100(r){ return (r.k === 'sonno' || r.k === 'riposo' || r.k === 'focus') && /^\d+$/.test(String(r.val)); }
function pscAbValore(r){
  if (r.stato === 'attesa') return '<i class="psc-azc-v attesa">Sto misurando</i>';
  if (r.stato === 'manca' || !r.val) return '<i class="psc-azc-v manca">Da misurare</i>';
  return '<i class="psc-azc-v ' + pstE(r.stato) + '">' + pstE(r.val) + (pscAbSu100(r) ? '<span> su 100</span>' : '') + '</i>';
}
function pscAbCardHtml(r, fermo){
  return '<button type="button" class="psc-azc-b"' + (fermo ? '' : ' onclick="pscAbInfo(' + pstA(r.k) + ')"') + '>'
    + '<span class="psc-azc-e">' + pstE(r.em || '📏') + '</span><b>' + pstE(r.t) + '</b>' + pscAbValore(r)
    + '<em class="psc-azc-mis">' + PSC_MISURA + 'Misurata dall’app</em></button>';
}
/** Il layout delle card di una scheda ('amb' o 'az'): 'due' colonne (di serie) o 'una' alla volta, a carosello. */
const PSC_LAYOUT = 'fl_card_layout';
function pscLayout(k){ const o = pstJ(PSC_LAYOUT, {}); return o && o[k] === 'una' ? 'una' : 'due'; }
function pscLayoutSet(k, v){
  const o = pstJ(PSC_LAYOUT, {}), n = (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
  n[k] = v === 'una' ? 'una' : 'due';
  try{ localStorage.setItem(PSC_LAYOUT, JSON.stringify(n)); }catch(_){ }
  PSC.carPos = PSC.carPos || {}; PSC.carPos[k] = 0;
  pscVibra(6);
}
/** La modifica di una scheda: '' (niente), 'sposta' (le card si spostano, il tocco apre la card) o 'togli' (la X sulle card tue).
    true vale 'togli': e' il valore delle versioni prima della 0.9.401. */
function pscModo(k){ const m = k === 'amb' ? PSC.ambModo : PSC.azModo; return m === true ? 'togli' : (m === 'sposta' || m === 'togli' ? m : ''); }
/** Le card in fila: la griglia a due colonne, o il carosello con i pallini (una alla volta). Durante la modifica sempre la griglia:
    spostare una card si fa vedendole tutte. */
function pscFilaHtml(k, voci, piu, cls){
  if (pscLayout(k) === 'una' && !pscModo(k)){
    const l = voci.concat(piu ? [piu] : []);
    PSC.carPos = PSC.carPos || {};
    const i0 = Math.min(PSC.carPos[k] || 0, Math.max(0, l.length - 1));
    setTimeout(function(){ pscCarRimetti(k); }, 0);
    return '<div class="psc-car-w"><div class="psc-car" data-car="' + k + '" onscroll="pscCarScorri(this)">' + l.map(function(h){ return '<div class="psc-car-s">' + h + '</div>'; }).join('') + '</div>'
      + (l.length > 1 ? '<div class="psc-car-dots" aria-hidden="true">' + l.map(function(_, i){ return '<i' + (i === i0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div>' : '') + '</div>';
  }
  return '<div class="' + cls + '" data-ord-grid="' + k + '">' + voci.join('') + (piu || '') + '</div>';
}
function pscCarScorri(c){
  const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)), k = c.getAttribute('data-car');
  PSC.carPos = PSC.carPos || {}; PSC.carPos[k] = i;
  const w = c.parentNode; Array.prototype.forEach.call(w.querySelectorAll('.psc-car-dots i'), function(x, j){ x.classList.toggle('on', j === i); });
}
/* il pannello si ridisegna spesso (arrivano i dati): il carosello torna sulla card che stavi guardando */
function pscCarRimetti(k){
  try{
    const c = document.querySelector('.psc-car[data-car="' + k + '"]'); if (!c) return;
    const i = (PSC.carPos && PSC.carPos[k]) || 0;
    if (i && Math.abs(c.scrollLeft - i * c.clientWidth) > 4){ const b = c.style.scrollBehavior; c.style.scrollBehavior = 'auto'; c.scrollLeft = i * c.clientWidth; c.style.scrollBehavior = b; }
  }catch(_){ }
}
function pscAzCardHtml(d, per){
  const prem = pscPremium();
  PSC.azProp = pscAzProposte(d, per);
  const mie = pscAzioni();
  const tag = function(tipo){ return '<em class="psc-azc-tag ' + (tipo === 'cambia' ? 'cambia' : 'tieni') + '">' + (tipo === 'cambia' ? 'Da cambiare' : 'Da tenere') + '</em>'; };
  const modo = pscModo('az'), togli = modo === 'togli';
  const cls = 'psc-ord' + (modo ? ' modo' : '');
  const x0 = function(nome, azione){ return togli ? '<button type="button" class="psc-ord-x" aria-label="Togli ' + pstE(nome) + '" onclick="' + azione + '">' + PSC_X + '</button>' : ''; };
  const voci = pscAbVoci(d, per).map(function(r){
    return { ord: 'm:' + r.k, html: '<div class="psc-azc mis ' + cls + '" data-ord="' + pstE('m:' + r.k) + '">' + pscAbCardHtml(r, togli) + '</div>' };
  }).concat(mie.map(function(a){
    const url = pscImgUrl(a.img);
    return { ord: 'a:' + a.id, html: '<div class="psc-azc ' + cls + '" data-ord="' + pstE('a:' + a.id) + '"><button type="button" class="psc-azc-b"' + (togli ? '' : ' onclick="pscAzModifica(' + pstA(a.id) + ')"') + '>'
      + '<span class="psc-azc-e"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : pstE(a.em || '🎯')) + '</span>'
      + '<b>' + pstE(a.t) + '</b>' + (a.da && a.da.val ? '<i>' + pstE(a.da.val) + '</i>' : '') + tag(a.tipo) + '</button>'
      + x0(a.t, 'pscAzEliminaId(' + pstA(a.id) + ')') + '</div>' };
  })).concat(PSC.azProp.map(function(x, i){
    return { ord: 'p:' + x.k, html: '<div class="psc-azc prop ' + cls + '" data-ord="' + pstE('p:' + x.k) + '"><button type="button" class="psc-azc-b"' + (togli ? '' : ' onclick="pscAzDaProposta(' + i + ')"') + '>'
      + '<span class="psc-azc-e">' + x.em + '</span><b>' + pstE(x.t) + '</b>'
      + (x.media ? '<i>' + pstE(pscAzOreCorte(x.media)) + ' al giorno</i>' : '')
      + (x.det ? '<small>' + pstE(x.det) + '</small>' : '') + tag(x.tipo)
      + '<span class="psc-azc-f">' + pscAzFonteTxt(x.fonte) + '</span></button>'
      /* 0.9.401 BUG-192, Andrea: le proposte nate dai dati si tolgono (e tornano con Rimetti le predefinite); solo le misurate restano */
      + x0(x.t, 'pscAzTogliK(' + pstA(x.k) + ')') + '</div>' };
  }));
  const card = pscOrdina(voci, pstJ(PSC_AZ_ORD, [])).map(function(v){ return v.html; });
  const testa = '<div class="psc-testa psc-testa-k"><p>Le tue abitudini' + pscInfoBtn('pscAzInfo()', 'Come funzionano le abitudini') + ' <button type="button" class="psc-per-btn" onclick="pscPerMenu(event,this)">' + pscQuando(per) + ' <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>' + '</p>'
    + pscKebabHtml(modo, modo ? 'pscAzModo(false)' : 'pscMenuApri(\'az\')', 'Le tue abitudini: layout e modifica') + '</div>';
  /* 0.9.386, Andrea: "Sto leggendo le attivita' del telefono e' attaccato alle card, e deve sparire quando la lettura e' finita" */
  const attesa = !d ? '<p class="pst-nota psc-az-attesa">Sto leggendo le attività del telefono.</p>' : '';
  const piu = modo ? '' : '<button type="button" class="psc-azc psc-azc-piu" onclick="pscAzScegli()"><span class="psc-piu-ic">' + PST_ICO.piu + '</span><b>Aggiungi un’abitudine</b></button>';
  return testa + attesa
    + pscFilaHtml('az', card, piu, 'psc-azg')
    + (modo ? '' : pscAbMancaHtml(d, per))
    + '<button type="button" class="psc-az-chiedi" onclick="azlApri()"><i aria-hidden="true">' + (prem ? '💬' : '🔮') + '</i><span>' + (prem ? 'Chiedi al tuo agente personale' : 'Scopri le tue azioni con il Genio') + '</span></button>';
}
/* Le altre abitudini che l'app sa misurare (respiri, computer, ore di lavoro) e che non hanno ancora un dato: chiuse sotto le card, con
   cosa serve per misurarle. Mai un numero inventato */
function pscAbMancaHtml(d, per){
  const manca = (pscAbRighe(d, per) || []).filter(function(r){ return r && r.stato === 'manca' && PSC_AB_FISSE.indexOf(r.k) < 0; });
  if (!manca.length) return '';
  return '<details class="psc-ab-d psc-ab"><summary class="psc-ab-sub">Da misurare · ' + manca.length + '</summary><div class="psc-ab-g manca">'
    + manca.map(function(r){ return '<div class="psc-ab-r manca"><span class="psc-ab-e" aria-hidden="true">' + r.em + '</span><span class="psc-ab-t"><b>' + pstE(r.t) + '</b><small>' + pstE(r.sub) + '</small></span></div>'; }).join('')
    + '</div></details>';
}
/** Il foglio di un'abitudine misurata: il numero, da dove viene e perche' non si toglie. */
function pscAbInfo(k){
  const r = (PSC.abVoci || []).filter(function(x){ return x.k === k; })[0]; if (!r) return;
  pscVibra(6);
  const num = r.stato === 'manca' || r.stato === 'attesa' || !r.val ? '' : '<p class="psc-abf-n ' + pstE(r.stato) + '">' + pstE(r.val) + (pscAbSu100(r) ? '<small> su 100</small>' : '') + '</p>';
  const sub = r.stato === 'attesa' ? 'Sto leggendo i dati del telefono. Torna fra qualche secondo.' : (r.sub || 'Per misurarla servono i dati di utilizzo del telefono.');
  inSheet('<div class="en-foglio psc-fg psc-abf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<span class="psc-fg-e" aria-hidden="true">' + pstE(r.em || '📏') + '</span><h3>' + pstE(r.t) + '</h3>' + num
    + '<p class="psc-abf-p">' + pstE(sub).replace(/: /g, ':<br>') + '</p>'
    + '<p class="psc-abf-m">' + PSC_MISURA + '<span>La misura l’app da sola:<br>cambia con le tue giornate e non si toglie.</span></p>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/* I TRE PUNTINI (0.9.401 BUG-192): un foglio con il layout, Modifica, Rimuovi e Rimetti le predefinite. Prima i tre puntini mettevano
   la scheda in modifica con la scritta "tieni premuta una card per spostarla": Andrea l'ha tolta */
const PSC_LAY_SVG = {
  una: '<svg viewBox="0 0 48 40" width="48" height="40" aria-hidden="true"><rect x="12" y="3" width="24" height="26" rx="5" fill="currentColor" opacity=".9"/><circle cx="18" cy="35" r="2.2" fill="currentColor"/><circle cx="24" cy="35" r="2.2" fill="currentColor" opacity=".4"/><circle cx="30" cy="35" r="2.2" fill="currentColor" opacity=".4"/></svg>',
  due: '<svg viewBox="0 0 48 40" width="48" height="40" aria-hidden="true"><rect x="8" y="3" width="15" height="15" rx="4" fill="currentColor" opacity=".9"/><rect x="25" y="3" width="15" height="15" rx="4" fill="currentColor" opacity=".9"/><rect x="8" y="21" width="15" height="15" rx="4" fill="currentColor" opacity=".9"/><rect x="25" y="21" width="15" height="15" rx="4" fill="currentColor" opacity=".9"/></svg>'
};
function pscMenuApri(k){
  if (typeof inSheet !== 'function') return;
  pscVibra(6);
  const lay = pscLayout(k), az = k === 'az';
  const mie = az ? pscAzioni().length + ((PSC.azProp || []).length) : pscLuoghi().length;
  const riga = function(em, t, s, azione, spenta){ return '<button type="button" class="psc-menu-r' + (spenta ? ' spenta' : '') + '" onclick="' + azione + '"><span aria-hidden="true">' + em + '</span><div><b>' + t + '</b><small>' + s + '</small></div></button>'; };
  const noTogli = az ? 'Le abitudini misurate dall’app non si tolgono' : 'Telefono, computer e casa non si tolgono';
  inSheet('<div class="en-foglio psc-menu"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>' + (az ? 'Le tue abitudini' : 'I tuoi luoghi') + '</h3>'
    + '<p class="psc-menu-k">Come le vedi</p><div class="psc-lay" role="radiogroup" aria-label="Come le vedi">'
    + [['una', 'Una alla volta'], ['due', 'Due colonne']].map(function(x){ return '<button type="button" role="radio" aria-checked="' + (lay === x[0]) + '" class="psc-lay-b' + (lay === x[0] ? ' fl-sel' : '') + '" onclick="pscMenuLayout(\'' + k + '\',\'' + x[0] + '\')">' + PSC_LAY_SVG[x[0]] + '<b>' + x[1] + '</b></button>'; }).join('')
    + '</div>'
    + '<div class="psc-menu-l">'
    + riga('✏️', 'Modifica', az ? 'Cambia un’abitudine o spostala' : 'Cambia un luogo o spostalo', 'inSheetChiudi();pscModoVai(\'' + k + '\',\'sposta\')')
    + riga('🗑️', 'Rimuovi', mie ? (az ? 'Togli le tue e quelle proposte dall’app' : 'Togli i luoghi che hai aggiunto tu') : (az ? 'Non hai ancora abitudini tue da togliere' : 'Non hai ancora luoghi tuoi da togliere'), mie ? 'inSheetChiudi();pscModoVai(\'' + k + '\',\'togli\')' : 'pscToast(\'' + noTogli + '\')', !mie)
    + riga('↩️', 'Rimetti le predefinite', az ? 'Tornano quelle che avevi tolto, nell’ordine di partenza' : 'Le card tornano nell’ordine di partenza', 'pscPredefinite(\'' + k + '\')')
    + '</div></div>');
}
function pscMenuLayout(k, v){ pscLayoutSet(k, v); pscMenuApri(k); pscRidisegna(); }
function pscModoVai(k, m){
  if (k === 'amb') PSC.ambModo = m; else PSC.azModo = m;
  pscVibra(6);
  if (m === 'sposta') pscToast('Tieni premuta una card per spostarla');
  pscRidisegna();
}
async function pscPredefinite(k){
  inSheetChiudi();
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Rimettere le predefinite?', k === 'az' ? 'Tornano le abitudini che avevi tolto, nell’ordine di partenza. Quelle che hai scritto tu restano.' : 'Le card tornano nell’ordine di partenza. I tuoi luoghi restano.', 'Rimetti', false); }catch(_){ }
  if (!ok) return;
  try{
    if (k === 'az'){ localStorage.removeItem(PSC_AZ_VIA); localStorage.removeItem(PSC_AZ_ORD); PSC.azModo = false; }
    else { localStorage.removeItem(PSC_AMB_ORD); PSC.ambModo = false; }
  }catch(_){ }
  PSC.carPos = PSC.carPos || {}; PSC.carPos[k] = 0;
  pscVibra([10, 30, 10]); pscToast('Ecco le predefinite'); pscRidisegna();
}
function pscAzTogli(i){ const x = PSC.azProp && PSC.azProp[i]; if (x) pscAzTogliK(x.k); }
/* 0.9.386, BUG Andrea: "tocco la X, compare Azione tolta ma la card resta". CAUSA: la chiave finiva davvero in fl_azioni_via, ma il
   pannello non si ridisegnava. pscRidisegna chiedeva a pstVisibile() se il pannello si vedeva, e pstVisibile guardava solo #pstBox e
   #pstBoxMini, non #pstBoxAai (il pannello della combinazione segreta, dove stanno le azioni): nella scheda Azione #pstBoxMini e'
   parcheggiato e nascosto, quindi niente ridisegno, e la card restava li' finche' qualcos'altro non ridisegnava. Stessa causa per "Sto
   leggendo le attivita' del telefono" che non spariva. Ora pstVisibile conta anche #pstBoxAai, e la chiave si toglie per nome, non per
   posizione (con le card riordinate la posizione non e' piu' quella della lista) */
function pscAzTogliK(k){
  if (!k) return;
  const l = pscAzVia(); if (l.indexOf(k) < 0) l.push(k);
  try{ localStorage.setItem(PSC_AZ_VIA, JSON.stringify(l.slice(-60))); }catch(_){ }
  pscOrdTogli(PSC_AZ_ORD, 'p:' + k);
  PSC.azProp = (PSC.azProp || []).filter(function(x){ return x.k !== k; });
  pscVibra(6); pscToast('Abitudine tolta'); pscRidisegna();
}
async function pscAzEliminaId(id){
  const a = pscAzioni().filter(function(x){ return x.id === id; })[0]; if (!a) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Togliere questa abitudine?', '"' + a.t + '" sparisce dalle tue abitudini.', 'Togli', true); }catch(_){ }
  if (!ok) return;
  pscScriviAzioni(pscAzioni().filter(function(x){ return x.id !== id; }));
  if (a.img) pscImgVia(a.img);
  /* se nasceva da una proposta, la proposta non torna fuori */
  if (a.k){ const l = pscAzVia(); if (l.indexOf(a.k) < 0){ l.push(a.k); try{ localStorage.setItem(PSC_AZ_VIA, JSON.stringify(l.slice(-60))); }catch(_){ } } }
  pscOrdTogli(PSC_AZ_ORD, 'a:' + id);
  pscVibra(6); pscToast('Abitudine tolta'); pscRidisegna();
}
function pscAzDaProposta(i){
  const x = PSC.azProp && PSC.azProp[i]; if (!x) return;
  PSC.azBozza = { id: '', k: x.k, tipo: x.tipo, t: x.t, em: x.em, img: '', nuova: '', app: x.app || null, da: { tipo: 'proposta', nome: x.det || pscAzFonteTxt(x.fonte), val: x.media ? pscAzOreCorte(x.media) + ' al giorno' : '' } };
  /* 0.9.393: una proposta da fare tua e' gia' qualcosa da salvare: il Salva c'e' da subito (registry.js, flPiede) */
  pscAzPiede(true);
  pscVibra(6);
  pscAzFoglio();
}
function pscPerGiro(){ const l = [1, 7, 30]; PST.per = l[(l.indexOf(PST.per) + 1) % 3]; try{ pstSalvaVista(); }catch(_){ } pscVibra(6); pstPaint(); }
function pscQuando(per){ return per === 1 ? 'oggi' : (per === 7 ? 'negli ultimi 7 giorni' : 'negli ultimi 30 giorni'); }
/* PREMIUM: quello che ha notato il tuo agente personale (gli stessi pattern del Riepilogo della Timeline) */
function pscAgenteHtml(d, per){
  const frasi = (d && d.frasi) || [];
  let ponte = '';
  try{
    if (typeof pntOn === 'function' && pntOn() && typeof pntVoci === 'function'){
      const F = pstFinestra(per), v = pntVoci().filter(function(x){ return x && x.at >= F.da && x.testo; });
      if (v.length) ponte = '<div class="psc-ponte"><span aria-hidden="true">🤝</span><p>Le tue AI hanno scritto ' + v.length + (v.length === 1 ? ' resoconto' : ' resoconti') + ' ' + pscQuando(per) + '.<small>' + pstE(String(v[0].testo).slice(0, 110)) + '</small></p></div>';
    }
  }catch(_){ }
  return '<div class="psc-ag"><div class="tls-genio"><img src="img/genio/genio-pensa.png" alt=""><span>Il tuo agente personale ha notato</span></div>'
    + (!d ? '<p class="pst-nota">Il tuo agente personale sta leggendo la giornata.</p>'
      : (frasi.length ? '<ul class="tls-punti">' + frasi.map(function(f){ return '<li><span class="tls-em">' + f.ico + '</span><span>' + f.html + '</span></li>'; }).join('') + '</ul>'
        : '<p class="pst-nota">Il tuo agente personale ha ancora pochi dati. Torna dopo aver usato il telefono un po’ di più.</p>'))
    + ponte
    /* 0.9.369, Andrea: "un po' a sinistra un po' al centro, e Chiedi al tuo agente non sembra un pulsante". Tutto al centro: il pulsante pieno,
       il secondario sottolineato */
    + '<button type="button" class="pst-cta psc-az-cta" onclick="pscAgChat()">' + PST_ICO.chat + '<span>Chiedi al tuo agente personale</span></button>'
    + '<button type="button" class="psc-az-link" onclick="pscAzAttivita(true)">Trasforma le attività in abitudini</button></div>';
}
function pscAzAttivita(on){ PSC.azAtt = !!on; pscVibra(6); pstPaint(); }
async function pscAgChat(){
  let ok = false;
  try{ if (typeof agPopover === 'function') ok = await agPopover('', { titolo: 'Le mie azioni', pill: ['Quale abitudine mi allontana di più dal sogno?', 'Che azione nuova posso fare domani?'] }); }catch(_){ ok = false; }
  if (!ok && typeof agPopover !== 'function') pscToast('Il tuo agente personale non risponde adesso, riprova fra poco');
}
/* GRATIS (e Premium dal link): le app, i siti e le ricerche del periodo. Il + trasforma la voce in un'azione */
function pscAttivitaHtml(d, per){
  PSC.azFonti = [];
  /* 0.9.367: niente schede Oggi / 7 giorni / 30 giorni sopra: il periodo si cambia toccando la parola */
  const testa = '<div class="psc-testa"><p>Ecco cosa hai fatto' + pscInfoBtn('pscAzInfo()', 'Come funzionano le azioni') + ' <button type="button" class="psc-per-btn" onclick="pscPerMenu(event,this)">' + pscQuando(per) + ' <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>.' + '</p></div>';
  const torna = pscPremium() ? '<button type="button" class="pst-link muto psc-torna" onclick="pscAzAttivita(false)">Torna al tuo agente personale</button>' : '';
  if (!d) return testa + '<p class="pst-nota">Sto leggendo le attività del telefono.</p>' + torna;
  if (d.browser) return testa + '<p class="pst-nota">Le attività del telefono si vedono nell’app installata.</p>' + torna;
  /* 0.9.371, Andrea: "la scheda Azione e' troppo diversa dal pannello Dove va la tua attenzione; l'interfaccia con il + va bene quando
     l'utente tocca il pulsante". Di serie le righe sono come quelle di Dove va la tua attenzione (icona, nome, barra, tempo); il + accanto
     a ogni riga compare solo dopo "Trasforma in un'azione" */
  const piu = !!PSC.azPiu;
  const riga = function(f, ico, nome, val, quota){
    const i = PSC.azFonti.push(f) - 1;
    if (!piu) return '<div class="psc-att psc-att-r"><span class="psc-att-i" aria-hidden="true">' + ico + '</span><span class="psc-att-n"><b>' + pstE(nome) + '</b><i class="psc-att-tr"><em style="width:' + Math.max(4, Math.round((quota || 0) * 100)) + '%"></em></i></span><b class="psc-att-v">' + pstE(val) + '</b></div>';
    return '<div class="psc-att"><span class="psc-att-i" aria-hidden="true">' + ico + '</span><span class="psc-att-n"><b>' + pstE(nome) + '</b><small>' + pstE(val) + '</small></span>'
      + '<button type="button" class="psc-att-piu" aria-label="Trasforma ' + pstE(nome) + ' in un’azione" onclick="pscAzNuova(' + i + ')">' + PST_ICO.piu + '</button></div>';
  };
  const maxA = Math.max(1, (d.apps || []).reduce(function(m, a){ return Math.max(m, a.ms || 0); }, 0));
  const maxS = Math.max(1, (d.siti || []).reduce(function(m, a){ return Math.max(m, a.ms || 0); }, 0));
  const maxR = Math.max(1, (d.ricerche || []).reduce(function(m, a){ return Math.max(m, a.n || 0); }, 0));
  const gruppo = function(tit, righe){ return righe.length ? '<div class="psc-gr"><p class="psc-gr-t">' + tit + '</p>' + righe.join('') + '</div>' : ''; };
  const app = d.apps.map(function(a){
    const nome = a.label || a.appName || String(a.packageName || '').split('.').pop();
    const ico = (a.icon && String(a.icon).indexOf('data:image') === 0) ? '<img src="' + a.icon + '" alt="">' : '📱';
    return riga({ tipo: 'app', nome: nome, val: pscOre(a.ms), em: '📱' }, ico, nome, pscOre(a.ms), (a.ms || 0) / maxA);
  });
  const siti = d.siti.map(function(s){ const h = String(s.host).replace(/^www\./, ''); return riga({ tipo: 'sito', nome: h, val: pscOre(s.ms), em: '🌐' }, '🌐', h, pscOre(s.ms), (s.ms || 0) / maxS); });
  const ric = d.ricerche.map(function(r){ const v = r.n === 1 ? 'Cercata 1 volta' : 'Cercata ' + r.n + ' volte'; return riga({ tipo: 'ricerca', nome: r.t, val: v, em: '🔎' }, '🔎', r.t, v, (r.n || 0) / maxR); });
  const tutto = gruppo('📱 App', app) + gruppo('🌐 Siti', siti) + gruppo('🔎 Ricerche', ric);
  const trasforma = !tutto ? '' : (piu
    ? '<p class="psc-att-hint">Tocca + accanto a quello che vuoi cambiare.</p><button type="button" class="psc-az-link" onclick="PSC.azPiu=false;pscVibra(6);pstPaint()">Fatto</button>'
    : '<button type="button" class="pst-cta psc-az-cta" onclick="PSC.azPiu=true;pscVibra(6);pstPaint()">' + PST_ICO.piu + '<span>Trasforma in un’azione</span></button>');
  return testa + (tutto || '<p class="pst-nota">Le app aperte le conta il telefono. Serve il permesso di utilizzo.</p>') + trasforma + torna;
}
function pscAzInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Le tue abitudini</h3>'
    + flInfoRighe([
      ['📏', 'Le misura l’app', 'Sonno, focus, riposo e task switching vengono dal telefono, come nella scheda Profilo. Non si tolgono.'],
      ['📱', 'Le proposte nascono dai tuoi dati', 'App, siti e sessioni di Full Focus del periodo che scegli. Toccane una per farla tua.'],
      ['✍️', 'Le tue', 'Quelle che scrivi tu le cambi e le togli quando vuoi, dai tre puntini.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pscAzioniListaHtml(){
  const l = pscAzioni();
  return '<section class="psc-blocco psc-azb"><p class="psc-k">Le tue abitudini</p>'
    + (l.length ? '<div class="psc-azl">' + l.map(function(a){
        const url = pscImgUrl(a.img);
        return '<button type="button" class="psc-azr" onclick="pscAzModifica(' + pstA(a.id) + ')"><span class="psc-azr-e"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : pstE(a.em || '🎯')) + '</span>'
          + '<span class="psc-azr-t"><b>' + pstE(a.t) + '</b><small class="' + (a.tipo === 'cambia' ? 'cambia' : 'nuova') + '">' + (a.tipo === 'cambia' ? 'Da cambiare' : 'Da tenere') + '</small></span></button>';
      }).join('') + '</div>'
      : '<p class="pst-nota psc-azv">Qui trovi le abitudini che scrivi.</p>')
    + '<button type="button" class="psc-az-out" onclick="pscAzScegli()">' + PST_ICO.piu + '<span>Aggiungi un’abitudine</span></button></section>';
}
/* 0.9.401 BUG-192, Andrea: "il popover Aggiungi un'azione va rifatto piu' chiaro e pulito: una (i) con i dettagli sulle abitudini,
   modelli da cui partire come per gli ambienti (Il lavoro, La scuola, Parto da zero), molte piu' emoji (un selettore vero, non poche
   icone), una casella di testo ridimensionabile e piu' spazio per scrivere". Le emoji sono il selettore condiviso (scegli-icona.js,
   sciHtml): le stesse del luogo e del sogno, con Mostra altre e la casella per scriverne una */
const PSC_EMOJI = ['📵', '📱', '📚', '🏃', '🚶', '💧', '🧘', '✍️', '🌙', '💤', '🎯', '⏰', '🍎', '💪', '🎧', '🧹', '☕', '🎮'];
const PSC_AZ_MODELLI = [
  { k: 'letto', em: '📵', nome: 'Niente telefono a letto', t: 'Il telefono resta fuori dalla camera', tipo: 'cambia', s: 'Contro lo scrolling prima di dormire' },
  { k: 'social', em: '📲', nome: 'Social solo dopo pranzo', t: 'Apro i social solo dopo pranzo', tipo: 'cambia', s: 'Contro i social appena sveglio' },
  { k: 'leggo', em: '📚', nome: 'Dieci pagine ogni sera', t: 'Leggo 10 pagine prima di dormire', tipo: 'nuova', s: 'Al posto del telefono, la sera' },
  { k: 'cammino', em: '🚶', nome: 'Una camminata al giorno', t: 'Cammino 20 minuti dopo pranzo', tipo: 'nuova', s: 'Anche una passeggiata conta' }
];
/** Il + della scheda Azione: prima i modelli, come per un luogo nuovo (pscLuogoNuovo). */
function pscAzScegli(){
  if (typeof inSheet !== 'function'){ pscAzNuova(-1); return; }
  pscVibra(6);
  inSheet('<div class="en-foglio psc-mod"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Aggiungi un’abitudine</h3><p class="psc-mod-p">Parti da un modello o da zero.</p>'
    + PSC_AZ_MODELLI.map(function(m){ return '<button type="button" class="psc-mod-r" onclick="pscAzNuova(-1,\'' + m.k + '\')"><span aria-hidden="true">' + m.em + '</span><div><b>' + m.nome + '</b><small>' + m.s + '</small></div></button>'; }).join('')
    + '<button type="button" class="psc-mod-r zero" onclick="pscAzNuova(-1)"><span aria-hidden="true">✏️</span><div><b>Parto da zero</b><small>Un’abitudine tutta tua, con le tue parole</small></div></button></div>');
}
function pscAzNuova(i, modello){
  const f = (i >= 0 && PSC.azFonti[i]) ? PSC.azFonti[i] : null;
  const m = modello ? PSC_AZ_MODELLI.filter(function(x){ return x.k === modello; })[0] : null;
  PSC.azBozza = { id: '', tipo: m ? m.tipo : (f && f.tipo !== 'ricerca' ? 'cambia' : 'nuova'), t: m ? m.t : '', em: m ? m.em : (f ? f.em : '🎯'), img: '', nuova: '', da: f ? { tipo: f.tipo, nome: f.nome, val: f.val } : null };
  try{ if (typeof sciChiudi === 'function') sciChiudi('pscAz'); }catch(_){ }
  /* un modello e' gia' un'abitudine pronta da salvare: il Salva c'e' da subito */
  pscAzPiede(!!m);
  pscVibra(6);
  pscAzFoglio();
}
function pscAzModifica(id){
  const a = pscAzioni().filter(function(x){ return x.id === id; })[0]; if (!a) return;
  PSC.azBozza = Object.assign({ nuova: '' }, a);
  try{ if (typeof sciChiudi === 'function') sciChiudi('pscAz'); }catch(_){ }
  pscAzPiede();
  pscVibra(6);
  pscAzFoglio();
}
function pscAzEsempio(b){
  const n = b.da && b.da.nome ? b.da.nome : '';
  if (b.tipo === 'cambia') return b.da && b.da.tipo === 'app' ? 'Per esempio, non apro ' + n + ' a letto' : (b.da && b.da.tipo === 'sito' ? 'Per esempio, non apro ' + n + ' appena mi siedo' : 'Per esempio, il telefono resta fuori dalla camera');
  return 'Per esempio, dopo il caffè leggo 10 pagine';
}
/* 0.9.393, Andrea: "il pulsante Salva l'azione sta finendo sopra la text area quando si digita e si apre la tastiera [...] non e' lo stesso
   pulsante Salva con il footer giusto che compare nei programmi". Il Salva va nella fascia comune (registry.js, flPiede: sticky in fondo al
   foglio, la casella in cui scrivi resta sopra la fascia e sopra la tastiera) e compare solo quando la bozza e' diversa da quella dell'apertura */
function pscAzFirma(){ const b = PSC.azBozza; return b ? JSON.stringify([b.tipo, String(b.t || '').trim(), b.em, b.img || '', b.nuova ? b.nuova.length : 0]) : ''; }
function pscAzPiede(pronto){ try{ if (typeof flPiedeApri === 'function') flPiedeApri('psc-az', pscAzFirma, pronto); }catch(_){ } }
/* la casella cresce con quello che scrivi (e si puo' tirare piu' in alto) */
function pscAzCresci(t){ try{ t.style.height = 'auto'; t.style.height = Math.max(112, t.scrollHeight + 2) + 'px'; }catch(_){ } }
function pscAzFoglio(){
  const b = PSC.azBozza; if (!b) return;
  const url = b.nuova || pscImgUrl(b.img);
  const iBtn = '<button type="button" class="fl-tip-i psc-azf-i" aria-label="Cosa rende buona un’abitudine" onclick="pscAzBuonaInfo()">i</button>';
  const emoji = typeof sciHtml === 'function'
    ? sciHtml('pscAz', { ora: b.em || '🎯', img: url || '', base: PSC_EMOJI, bordo: true, scegli: pscAzEmoji, foto: pscAzFoto, ridisegna: function(){ pscAzLeggi(); pscAzFoglio(); } })
    : '<div class="psc-emoji">' + PSC_EMOJI.map(function(e){ return '<button type="button" class="' + (!url && b.em === e ? 'on' : '') + '" onclick="pscAzEmoji(\'' + e + '\')" aria-label="Emoji ' + e + '">' + e + '</button>'; }).join('') + '</div>';
  inSheet('<div class="en-foglio psc-fg psc-azf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    /* in alto l'emoji (o la foto) che hai scelto: come apparira' la card */
    + '<span class="psc-azf-e" aria-hidden="true"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : pstE(b.em || '🎯')) + '</span>'
    + '<h3>' + (b.id ? 'La tua abitudine' : (b.k ? 'Fanne una tua abitudine' : 'Aggiungi un’abitudine')) + '</h3>'
    /* 0.9.375, Andrea: "se tocco la card voglio vedere su quale app e' andato il tempo": l'elenco delle app, dalla piu' usata */
    + (b.app && b.app.length
      ? '<div class="psc-azf-app"><p>' + pstE(b.em || '') + ' ' + pstE(b.da && b.da.val ? b.da.val : '') + ', così:</p><ul>' + b.app.map(function(a){ return '<li><span>' + pstE(a.n) + '</span><b>' + pstE(pscAzOreCorte(a.media)) + ' al giorno</b></li>'; }).join('') + '</ul></div>'
      : (b.da ? '<p class="psc-fg-da">' + pstE(b.da.nome) + ', ' + pstE(String(b.da.val || '').toLowerCase()) + '</p>' : ''))
    + '<div class="psc-scelta" role="radiogroup" aria-label="Che tipo di abitudine">' + [['cambia', 'Da cambiare'], ['nuova', 'Da tenere o cominciare']].map(function(x){
        return '<button type="button" role="radio" aria-checked="' + (b.tipo === x[0]) + '" class="' + (b.tipo === x[0] ? 'on ' : '') + x[0] + '" onclick="pscAzTipo(\'' + x[0] + '\')">' + x[1] + '</button>';
      }).join('') + '</div>'
    + '<label class="psc-lab" for="pscAzT">Scrivila in modo <span class="psc-nw">chiaro ' + iBtn + '</span></label>'
    + '<textarea class="fin psc-fin psc-azt" id="pscAzT" rows="3" maxlength="120" enterkeyhint="done" placeholder="' + pstE(pscAzEsempio(b)) + '" oninput="PSC.azBozza.t=this.value;pscAzCresci(this)">' + pstE(b.t || '') + '</textarea>'
    + '<label class="psc-lab">Scegli un’emoji o una foto</label>'
    + emoji
    + '<button type="button" class="en-cta psc-salva fl-salva" data-fl="psc-az" onclick="pscAzSalva()">' + (b.id ? 'Salva' : 'Salva l’abitudine') + '</button>'
    + (b.id ? '<button type="button" class="psc-via" onclick="pscAzElimina()">Elimina l’abitudine</button>' : '')
    + '</div>');
  try{ const t = document.getElementById('pscAzT'); if (t && t.value) pscAzCresci(t); }catch(_){ }
}
/* la (i) della casella: cosa rende buona un'abitudine. Si torna al foglio con quello che avevi scritto */
function pscAzBuonaInfo(){
  pscAzLeggi(); pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="pscAzFoglio()">✕</button><h3>Cosa rende buona un’abitudine</h3>'
    + flInfoRighe([
      ['🎯', 'Si vede se l’hai fatta', 'Leggo 10 pagine, non leggo di più. Una cosa che a fine giornata è fatta o non è fatta.'],
      ['🐣', 'È piccola', 'Così piccola che la fai anche nei giorni storti. Crescerà dopo.'],
      ['⏰', 'Ha un momento', 'Attaccala a un gesto che fai già: dopo il caffè apro il libro.']
    ])
    + '<button type="button" class="en-cta" onclick="pscAzFoglio()">Torna all’abitudine</button></div>');
}
function pscAzLeggi(){ const i = document.getElementById('pscAzT'); if (i && PSC.azBozza) PSC.azBozza.t = i.value; }
function pscAzTipo(k){ pscAzLeggi(); PSC.azBozza.tipo = k; pscVibra(6); pscAzFoglio(); }
function pscAzEmoji(e){ pscAzLeggi(); const b = PSC.azBozza; if (!b || !e) return; b.em = e; b.nuova = ''; if (b.img){ b.imgVia = b.img; b.img = ''; } pscVibra(6); pscAzFoglio(); }
function pscAzFoto(){
  pscAzLeggi();
  pscScegliFoto(function(img){ const d = pscRiduci(img, 240, .8); if (!d || !PSC.azBozza) return; PSC.azBozza.nuova = d; pscAzFoglio(); });
}
async function pscAzSalva(){
  pscAzLeggi();
  const b = PSC.azBozza; if (!b || PSC.salva) return;
  const t = String(b.t || '').trim().replace(/\s+/g, ' ').slice(0, 120);
  if (t.length < 3){ pscToast('Scrivi l’abitudine in modo chiaro'); const i = document.getElementById('pscAzT'); if (i) i.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('a');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('az_' + id + '_' + Date.now().toString(36), b.nuova, b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; } else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const o = { id: id, k: b.k || '', tipo: b.tipo === 'cambia' ? 'cambia' : 'nuova', t: t.charAt(0).toUpperCase() + t.slice(1), em: b.em || '🎯', img: img, da: b.da || null, at: Date.now() };
  const l = pscAzioni(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviAzioni(l)){ pscToast('La memoria del telefono è piena, l’abitudine non si salva'); return; }
  if (b.imgVia && b.imgVia !== img) pscImgVia(b.imgVia);
  /* la proposta fatta tua resta al suo posto nell'ordine scelto */
  if (i < 0 && b.k){ try{ const ord = pstJ(PSC_AZ_ORD, []); const j = Array.isArray(ord) ? ord.indexOf('p:' + b.k) : -1; if (j >= 0){ ord[j] = 'a:' + id; localStorage.setItem(PSC_AZ_ORD, JSON.stringify(ord)); } }catch(_){ } }
  PSC.azBozza = null;
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Abitudine aggiornata' : 'Abitudine salvata fra le tue');
  pscRidisegna();
}
async function pscAzElimina(){
  const b = PSC.azBozza; if (!b || !b.id) return;
  inSheetChiudi();
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare questa abitudine?', '"' + b.t + '" sparisce dalle tue abitudini.', 'Elimina', true); }catch(_){ }
  if (!ok){ pscAzFoglio(); return; }
  pscScriviAzioni(pscAzioni().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.azBozza = null;
  pscToast('Abitudine eliminata');
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   IDENTITA': chi sono oggi, chi devo diventare, chi stai diventando
   --------------------------------------------------------------------------------------- */
/* 0.9.367, Andrea: "Chi sei oggi dovrebbe essere come ti vedi, la tua self image. E due schede bastano: come ti vedi e chi devi
   diventare. Il pannello di chi stai diventando va dentro a come ti vedi, ma prima chiedi come si vede, con delle opzioni e la
   possibilita' di scrivere". "Chi stai diventando" non e' piu' una scheda: sta sotto all'immagine di te */
const PSC_IO = [['oggi', 'Chi stai diventando'], ['devo', 'Chi devi diventare']];
function pscIoSub(){ let v = ''; try{ v = localStorage.getItem(PSC_SUB) || ''; }catch(_){ } return PSC_IO.some(function(x){ return x[0] === v; }) ? v : 'oggi'; }
function pscIoVai(k){
  if (k === pscIoSub()) return;
  try{ localStorage.setItem(PSC_SUB, k); }catch(_){ }
  pscVibra(6);
  pstPaint();
  if (k === 'oggi'){ const el = document.getElementById('scLife'); if (el && !el.innerHTML.trim() && typeof scLifePaint === 'function'){ try{ scLifePaint(); }catch(_){ } } }
}
/* ---------------------------------------------------------------------------------------
   LA PANORAMICA: il triangolo dei tre pilastri (0.9.368). Ogni lato da 0 a 100, dai dati veri:
   - Ambiente: i luoghi descritti e gli inneschi visivi che ci hai messo;
   - Azione: i giorni con una tappa negli ultimi 7 e le azioni che hai scritto;
   - Identita': come ti vedi, il tuo Io Futuro, e quanto stai battendo il vecchio te negli ultimi 7 giorni.
   Il piu' basso e' "il numero sbagliato della combinazione": un tocco porta alla sua scheda.
   --------------------------------------------------------------------------------------- */
/* 22/11/2026, Andrea: "Identita' 30% per un Disciplinato e' ridicolo, come dare 3 su 10 a chi ha studiato; Ambiente 0% e Azione 0% solo
   perche' mancano i dati, e poi il numero sbagliato della combinazione: Azione". Le regole stanno in genio-lettura.js:
   - Identita': dalla lettura (il profilo e quanto le risposte somigliano a quelle di chi ce la fa, glIdentita), con i voti della partita;
     senza lettura, come prima (come ti vedi, il tuo Io Futuro, la partita);
   - Ambiente: dalla mappa dei tuoi posti; null finche' non ne hai descritto nessuno (con il lucchetto la mappa e' gia' fatta);
   - Azione: null ("la misuro nei prossimi giorni") finche' non ci sono abbastanza giorni (glAzione), mai 0% il primo giorno.
   null = non misurato: non si disegna come 0 e non puo' essere il numero sbagliato (glTreScegli). */
function pscTreValori(){
  /* 0.9.380, Andrea: "Ambiente 100% solo per aver segnato la casa e' assurdo: al 100% ci arrivi con telefono, computer e tutti i posti
     allineati". Conta quanti dei tuoi posti hai descritto (il telefono, il computer se c'e', la casa, i tuoi luoghi: almeno tre) e quanto
     sono dalla tua parte (gli inneschi a favore contro quelli contro) */
  const amb = (function(){
    const posti = [pscTel()].concat(pscPcVisibile() ? [pscPc()] : []).concat([pscCasa()]).concat(pscLuoghi());
    const fatti = posti.filter(function(x){ return x && ((x.inneschi != null && x.inneschi !== '') || x.inneschiNo || (x.persone != null && x.persone !== '')); });
    if (!fatti.length) return null;
    let fav = 0, con = 0; fatti.forEach(function(x){ fav += +x.inneschi || 0; con += +x.inneschiNo || 0; });
    const copre = fatti.length / Math.max(3, posti.length), bil = fav + con ? fav / (fav + con) : 0.5;
    return Math.max(0, Math.min(100, Math.round(copre * (50 + 50 * bil))));
  })();
  const az = (function(){
    let g = 0;
    try{ const f = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; for (let i = 0; i < 7; i++){ const d = new Date(Date.now() - i * 86400000); const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); if (f[k]) g++; } }catch(_){ }
    let giorni = 7; try{ if (typeof flGiorniDaPrimoAvvio === 'function' && typeof flPrimoAvvio === 'function' && flPrimoAvvio()) giorni = flGiorniDaPrimoAvvio(); }catch(_){ giorni = 7; }
    if (typeof glAzione === 'function') return glAzione(giorni, g, pscAzioni().length);
    return Math.min(100, Math.round(g / 7 * 70) + Math.min(30, pscAzioni().length * 10));
  })();
  /* i voti della partita: gli ultimi 7 giorni, o (se non ce ne sono) tutta la partita */
  const voti = (function(){
    try{ if (typeof vtSomma === 'function'){ const p = vtSomma(Date.now() - 7 * 86400000, Date.now()); if (p.neo + p.old) return { neo: p.neo, old: p.old }; } }catch(_){ }
    try{ const m = (typeof mtState === 'function') ? mtState() : null; const neo = +(m && m.neo) || 0, old = +(m && m.old) || 0; if (neo + old) return { neo: neo, old: old }; }catch(_){ }
    return null;
  })();
  const io = (function(){
    const l = pscLettura();
    if (l && typeof glIdentita === 'function') return glIdentita(l.profile, l.qualita != null ? l.qualita : 0.5, voti);
    /* senza lettura: come ti vedi, il tuo Io Futuro, la partita */
    /* 0.9.391: come ti vedi e' il quiz dell'immagine di se' (idsArchetipo); il vecchio "ti vedi cosi'" scritto a mano vale ancora */
    let v = ((typeof idsArchetipo === 'function' && idsArchetipo()) || pscOggi()) ? 25 : 0;
    let carta = false;
    try{ const n = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : {}; if (n && n.identita && n.identita.identity_statement) carta = true; }catch(_){ }
    if (carta) v += 30;
    if (voti) v += Math.round(45 * voti.neo / (voti.neo + voti.old));
    return Math.min(100, v);
  })();
  return { ambiente: amb, azione: az, io: io };
}
/** La lettura vera del Genio (fl_oracle), o null: quella dell'intro, sui telefoni che l'avevano gia', non conosceva ancora nessuno. */
function pscLettura(){ try{ const l = (typeof orLast === 'function') ? orLast() : null; return (l && !l.intro && l.profile) ? l : null; }catch(_){ return null; } }
/** Il numero sbagliato della combinazione, solo fra i lati misurati; '' se non si puo' dire. */
function pscTreBasso(v){
  v = v || pscTreValori();
  return (typeof glTreScegli === 'function') ? glTreScegli(v) : '';
}
function pscTreHtml(){
  const v = pscTreValori();
  const nomi = { ambiente: 'Ambiente', azione: 'Azione', io: 'Identità' };
  const basso = pscTreBasso(v);
  const mis = function(k){ return typeof v[k] === 'number'; };
  /* il triangolo: tre assi a 90, 210 e 330 gradi dal centro (cx 110, cy 112, raggio 82). Un lato non misurato resta al centro, senza punto */
  const P = function(k, val){ const ang = { io: -90, azione: 150, ambiente: 30 }[k] * Math.PI / 180, r = 82 * Math.max(0.06, (val || 0) / 100); return [110 + r * Math.cos(ang), 112 + r * Math.sin(ang)]; };
  const pt = function(k, val){ const p = P(k, val); return p[0].toFixed(1) + ',' + p[1].toFixed(1); };
  const pieno = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, 100); }).join(' ');
  const meta = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, 50); }).join(' ');
  const tuo = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, mis(k) ? v[k] : 0); }).join(' ');
  const eti = function(k, x, y, anc){ return '<text x="' + x + '" y="' + y + '" text-anchor="' + anc + '" class="psc-tre-l' + (k === basso ? ' basso' : '') + (mis(k) ? '' : ' attesa') + '">' + nomi[k] + (mis(k) ? ' ' + v[k] + '%' : '') + '</text>'; };
  const aria = ['ambiente', 'azione', 'io'].map(function(k){ return nomi[k] + ' ' + (mis(k) ? v[k] + '%' : 'da misurare'); }).join(', ');
  const svg = '<svg class="psc-tre-svg" viewBox="0 0 220 210" role="img" aria-label="' + aria + '">'
    + '<polygon points="' + pieno + '" class="psc-tre-g"/><polygon points="' + meta + '" class="psc-tre-g2"/>'
    + '<polygon points="' + tuo + '" class="psc-tre-tu"/>'
    + ['io', 'azione', 'ambiente'].filter(mis).map(function(k){ const p = P(k, v[k]); return '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="5" class="psc-tre-p' + (k === basso ? ' basso' : '') + '"/>'; }).join('')
    + eti('io', 110, 18, 'middle') + eti('azione', 6, 200, 'start') + eti('ambiente', 214, 200, 'end') + '</svg>';
  /* i lati senza dati si dicono a parole sotto al triangolo: mai uno 0% */
  const attesa = { azione: 'La misuro nei prossimi giorni, con le tappe che fai.', ambiente: 'La misuro quando mappi i posti in cui vivi.', io: 'La misuro con la lettura del Genio.' };
  const righe = ['azione', 'ambiente', 'io'].filter(function(k){ return !mis(k); }).map(function(k){ return '<p class="psc-pano-att"><b>' + nomi[k] + '</b>' + attesa[k] + '</p>'; }).join('');
  if (!basso) return '<div class="psc-pano">' + svg + righe + '</div>';
  const perche = { ambiente: 'I luoghi in cui passi il tempo non ti ricordano il sogno: è lì che il vecchio te ritorna.', azione: 'Sai chi vuoi diventare, ma i giorni passano senza tappe: l’identità si nutre di prove.', io: 'Fai le cose, ma dentro ti vedi ancora come prima: è così che si torna al punto di partenza.' }[basso];
  return '<div class="psc-pano">' + svg + righe
    + '<p class="psc-pano-k">Il numero sbagliato della combinazione</p><b class="psc-pano-h">' + nomi[basso] + '</b>'
    + '<p class="psc-pano-p">' + perche + '</p>'
    + '<button type="button" class="pst-cta" onclick="pstVaiAai(\'' + basso + '\')">Lavora su ' + nomi[basso].toLowerCase() + '</button></div>';
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-tre-l.attesa{opacity:.6}.psc-pano-att{margin:10px 0 0;text-align:center;font:600 13.5px/1.45 var(--font-body);color:rgba(200,239,253,.82)}.psc-pano-att b{display:block;margin:0 0 2px;color:#FFFFFF;font-weight:800}.psc-pano-att + .psc-pano-k{margin-top:16px}'; document.head.appendChild(st); })();
/* 0.9.369, Andrea: "le schede Come ti vedi e Chi devi diventare comparivano anche sopra al campionato; sotto al campionato mancavano le
   statistiche della partita; Come ti vedi e Chi stai diventando sono due cose diverse; il pannello di chi stai diventando era tagliato e
   ballava su e giu'". La scheda Identita' e' un carosello:
   1. il campionato in diretta, e sotto le statistiche della partita;
   2. come ti vedi (la tua carta, o la domanda del Genio);
   3. chi stai diventando adesso e chi devi diventare, con il selettore solo qui.
   Il carosello scorre solo di lato: in altezza segue la slide, niente che balla */
function pscIoHtml(){
  const cur = pscIoSub();
  let par = '';
  try{ if (typeof nvpPartitaSlideHtml === 'function') par = nvpPartitaSlideHtml() + (typeof nvpRiepilogoHtml === 'function' ? nvpRiepilogoHtml() : ''); }catch(_){ par = ''; }
  /* 0.9.371, Andrea: "hai messo la scheda Chi stai diventando quando c'e' gia' il pannello Stai diventando; quel pannello stava in una
     scheda che in realta' era Come ti vedi oggi". Niente piu' selettore dentro al carosello: la seconda slide e' come ti vedi oggi, con
     sotto il pannello Stai diventando; la terza e' chi devi diventare */
  void cur;
  let stai = '', devo = '';
  try{ stai = pscStaiHtml(); }catch(_){ stai = ''; }
  try{ devo = pscDevoHtml(); }catch(_){ devo = ''; }
  /* 0.9.372, Andrea: "il pannello Stai diventando doveva venire prima di Come ti vedi oggi: la seconda cosa dopo il campionato".
     Una slide per cosa: 1. il campionato con le statistiche, 2. stai diventando, 3. come ti vedi oggi, 4. chi devi diventare */
  /* 0.9.376, Andrea: "prima Stai diventando, con la probabilita' di realizzare il sogno; poi Come ti vedi oggi; poi Chi devi diventare;
     per ultimo il campionato in diretta con le statistiche". Come ti vedi mostra i risultati del sabotatore invisibile (lo specchio),
     Chi devi diventare comincia dal capovolgimento del freno */
  const sl = [];
  sl.push('<div class="psc-io-s">' + stai + '</div>');
  sl.push('<div class="psc-io-s"><p class="psc-io-k">🪞 Come ti vedi oggi</p>' + pscOggiHtml() + pscSpecchioHtml() + '</div>');
  /* 0.9.381, Andrea: "le tre mosse mettile sotto al passaporto di chi devi diventare, nella terza slide della scheda Identita'" */
  sl.push('<div class="psc-io-s"><p class="psc-io-k">Chi devi diventare</p>' + pscCapovoltoHtml() + devo + (typeof orMosseHtml === 'function' ? orMosseHtml() : '') + '</div>');
  if (par) sl.push('<div class="psc-io-s psc-io-par">' + par + '</div>');
  const i0 = Math.max(0, Math.min(sl.length - 1, +PSC.ioSl || 0));
  return '<div class="psc-io"><div class="psc-io-car" data-no-swipe data-i="' + i0 + '"><div class="psc-io-tr" style="transform:translateX(-' + (i0 * 100) + '%)">' + sl.join('') + '</div></div>'
    + '<div class="psc-io-dots">' + sl.map(function(_, i){ return '<i' + (i === i0 ? ' class="on"' : '') + ' onclick="pscIoVaiSl(' + i + ')"></i>'; }).join('') + '</div></div>';
}
/* 0.9.372, Andrea: "nella scheda Identita', scorrendo su e giu', a volte si inceppa dentro al pannello". LA CAUSA: il carosello era una
   striscia che scorre di lato (overflow-x): il browser decideva a ogni gesto chi doveva scorrere, e a volte prendeva il carosello invece
   della pagina. Ora non scorre niente di lato: la striscia si sposta con transform, il dito di lato lo leggiamo noi (touch-action:pan-y),
   e il verticale e' SEMPRE della pagina. L'altezza segue la slide che si vede. */
function pscIoVaiSl(i, subito){
  const c = document.querySelector('.psc-io-car'); if (!c) return;
  const tr = c.querySelector('.psc-io-tr'); if (!tr) return;
  const n = tr.children.length; i = Math.max(0, Math.min(n - 1, i | 0));
  PSC.ioSl = i; c.setAttribute('data-i', i);
  if (subito) tr.style.transition = 'none';
  tr.style.transform = 'translateX(-' + (i * 100) + '%)';
  if (subito){ void tr.offsetWidth; tr.style.transition = ''; }
  const d = c.nextElementSibling; if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
  pscIoAltezza(c);
}
function pscIoAltezza(c){
  if (!c) return;
  const tr = c.querySelector('.psc-io-tr'); if (!tr) return;
  const s = tr.children[+c.getAttribute('data-i') || 0]; if (!s) return;
  const h = s.offsetHeight; if (h > 0 && Math.abs((parseFloat(c.style.height) || 0) - h) > 1) c.style.height = h + 'px';
  if (!c.__ro && typeof ResizeObserver !== 'undefined'){ c.__ro = new ResizeObserver(function(){ pscIoAltezza(c); }); Array.prototype.forEach.call(tr.children, function(x){ c.__ro.observe(x); }); }
}
setInterval(function(){ const c = document.querySelector('.psc-io-car'); if (c && c.offsetParent && !c.__ro) pscIoAltezza(c); }, 700);
(function(){
  let x0 = 0, y0 = 0, t0 = 0, car = null, lato = null;
  document.addEventListener('touchstart', function(e){ car = (e.touches.length === 1 && e.target.closest) ? e.target.closest('.psc-io-car') : null; if (!car) return; if (e.target.closest('.pst-anelli.sfoglia,input,textarea,[contenteditable]')){ car = null; return; } x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now(); lato = null; }, { passive: true });
  document.addEventListener('touchmove', function(e){ if (!car || lato) return; const dx = e.touches[0].clientX - x0, dy = e.touches[0].clientY - y0; if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return; lato = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'x' : 'y'; }, { passive: true });
  document.addEventListener('touchend', function(e){
    if (!car || lato !== 'x'){ car = null; return; }
    const p = (e.changedTouches || [])[0]; const c = car; car = null; if (!p) return;
    const dx = p.clientX - x0, v = Math.abs(dx) / Math.max(1, Date.now() - t0);
    if (Math.abs(dx) < 45 && !(Math.abs(dx) > 22 && v > 0.35)) return;
    pscIoVaiSl((+c.getAttribute('data-i') || 0) + (dx < 0 ? 1 : -1));
  }, { passive: true });
})();
/* LO SPECCHIO (0.9.376): i freni del sabotatore invisibile (blocchi.js, fl_blocchi) sono l'immagine che hai di te. Se non l'hai ancora
   fatto, un invito; se c'e', il freno principale e quelli che pesano di piu', con la loro forza */
function pscFreni(){ try{ const b = pstJ('fl_blocchi', null); return b && b.P ? b : null; }catch(_){ return null; } }
const PSC_FRENO_T = { valore: 'Non mi sento all’altezza', passato: 'Il peso di quello che è andato male', dispersione: 'Non riesco a concentrarmi', tempo: 'Il tempo che scappa', paura: 'La paura di non farcela', sguardi: 'Il giudizio degli altri', denaro: 'Il rapporto con i soldi', imparare: 'Il dover imparare ancora' };
function pscSpecchioHtml(){
  const b = pscFreni();
  if (!b) return '<div class="psc-spec"><p class="psc-spec-p">Il sabotatore invisibile ti dice quali convinzioni ti frenano.</p><button type="button" class="pst-link" onclick="if(typeof blocchiApri===\'function\')blocchiApri()">Scopri il tuo sabotatore</button></div>';
  const l = Object.keys(b.P).filter(function(k){ return b.P[k] > 0; }).sort(function(x, y){ return b.P[y] - b.P[x]; }).slice(0, 3);
  return '<div class="psc-spec"><p class="psc-spec-k">Quello che ti frena, dal sabotatore invisibile</p>'
    + l.map(function(k){ return '<div class="psc-spec-r' + (k === b.primario ? ' top' : '') + '"><span>' + pstE(PSC_FRENO_T[k] || k) + '</span><i><b style="width:' + Math.min(100, b.P[k]) + '%"></b></i><em>' + b.P[k] + '%</em></div>'; }).join('')
    + '<button type="button" class="pst-link" onclick="if(typeof blocchiApri===\'function\')blocchiApri()">Rivedi il sabotatore</button></div>';
}
/* 0.9.401 BUG-206, Andrea: "Non riesco a concentrarmi diventa Diventa una persona che sa concentrarsi: e' ovvio e vago. Una persona che si
   concentra non usa la forza di volonta': toglie le distrazioni. Il passo diventa Diventa una persona che toglie le distrazioni; toccandolo
   si apre Proteggi i tuoi sogni, oppure si sceglie di programmare sessioni di Full Focus preventive. Vale lo stesso per gli altri
   sabotatori: un passo concreto e specifico, non un diventa una persona che sa X".
   Per ogni freno del sabotatore invisibile: il passo, il perche' in una riga e le due strade dell'app che lo fanno davvero */
const PSC_PASSI = {
  dispersione: ['Diventa una persona che toglie le distrazioni', 'Chi si concentra non usa la forza di volontà:<br>toglie le distrazioni prima che arrivino.', ['blocca', 'ffprog']],
  tempo: ['Diventa una persona che dà un orario alla cosa che conta', 'Il tempo non si trova:<br>si dà a quello che conta, prima del resto.', ['calendario', 'ffprog']],
  valore: ['Diventa una persona che tiene il conto di quello che fa', 'La fiducia non arriva pensando:<br>arriva vedendo quello che hai già fatto.', ['diario', 'tappa']],
  passato: ['Diventa una persona che riparte da un passo piccolo, oggi', 'Il passato non si cambia:<br>si riparte da una cosa piccola, adesso.', ['tappa', 'diario']],
  paura: ['Diventa una persona che comincia con cinque minuti', 'La paura non passa aspettando:<br>passa dopo i primi cinque minuti.', ['focus', 'tappa']],
  sguardi: ['Diventa una persona che si misura con il suo ieri, non con gli altri', 'Gli altri vedono un momento:<br>tu vedi quanto sei cresciuto.', ['partita', 'blocca']],
  denaro: ['Diventa una persona che investe un’ora al giorno su di sé', 'L’investimento che rende di più:<br>un’ora al giorno sul tuo sogno.', ['ffprog', 'tappa']],
  imparare: ['Diventa una persona che prova oggi e corregge domani', 'Non serve sapere tutto prima:<br>si impara facendo e correggendo.', ['tappa', 'focus']]
};
const PSC_STRADE = {
  blocca: ['🛡️', 'Proteggi i tuoi sogni', 'Blocca le app che ti distraggono, nelle ore che scegli tu.'],
  ffprog: ['🎯', 'Programma sessioni di Full Focus preventive', 'A un’ora fissa partono da sole e bloccano tutto il resto.'],
  focus: ['⏱️', 'Avvia una sessione di Full Focus', 'Bastano cinque minuti: il resto viene dopo.'],
  tappa: ['🗺️', 'Fai la tappa di oggi', 'Un passo piccolo sulla tua mappa, adesso.'],
  calendario: ['📅', 'Mettila nel calendario', 'Dai un giorno e un’ora alla cosa che conta.'],
  diario: ['📓', 'Scrivi nel diario', 'Una riga su quello che hai fatto oggi.'],
  partita: ['⚽', 'Guarda la partita con il vecchio te', 'L’unico confronto che conta è con chi eri ieri.']
};
function pscPasso(){ const b = pscFreni(); return b && b.primario && PSC_PASSI[b.primario] ? { k: b.primario, p: PSC_PASSI[b.primario] } : null; }
function pscCapovoltoHtml(){
  const x = pscPasso(); if (!x) return '';
  return '<button type="button" class="psc-capo psc-capo-b" onclick="pscPassoApri()"><p><span>' + pstE(PSC_FRENO_T[x.k] || '') + '</span></p><b>' + pstE(x.p[0]) + '</b>'
    + '<em class="psc-capo-go">Scegli come<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></em></button>';
}
/** Il foglio del passo: il perche' in una riga e le due strade. */
function pscPassoApri(){
  const x = pscPasso(); if (!x || typeof inSheet !== 'function') return;
  pscVibra(6);
  inSheet('<div class="en-foglio psc-mod psc-passo"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>' + pstE(x.p[0]) + '</h3>'
    + '<p class="psc-passo-p">' + x.p[1] + '</p>'
    + x.p[2].map(function(k){ const s = PSC_STRADE[k]; return '<button type="button" class="psc-mod-r" onclick="inSheetChiudi();pscStradaVai(\'' + k + '\')"><span aria-hidden="true">' + s[0] + '</span><div><b>' + s[1] + '</b><small>' + s[2] + '</small></div></button>'; }).join('')
    + '</div>');
}
function pscStradaVai(k){
  pscVibra(8);
  setTimeout(function(){
    try{
      if (k === 'blocca'){ if (typeof blPaginaApri === 'function') blPaginaApri(); else goId('s-blocco'); }
      else if (k === 'ffprog'){ if (typeof ffcProgrammiApri === 'function') ffcProgrammiApri(); else if (typeof ffOpen === 'function') ffOpen(); }
      else if (k === 'focus'){ if (typeof ffOpen === 'function') ffOpen(); }
      else if (k === 'partita'){ if (typeof paApri === 'function') paApri(); }
      else if (k === 'diario'){ if (typeof dvApri === 'function') dvApri(); }
      else if (k === 'tappa'){
        goId('s-home'); switchTab('mappa');
        setTimeout(function(){ try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n) n.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ } }, 600);
      }
      else if (k === 'calendario'){
        goId('s-home'); switchTab('mappa'); if (typeof mppVista === 'function') mppVista('mia');
        setTimeout(function(){ try{ if (typeof mfTab === 'function') mfTab('cal'); const f = document.getElementById('mppFoglio'); if (f) f.scrollIntoView({ block: 'start', behavior: 'smooth' }); }catch(_){ } }, 600);
      }
    }catch(_){ }
  }, 220);
}
function pscOggi(){ const o = pstJ(PSC_OGGI, null); return (o && typeof o === 'object') ? o : null; }
/* 0.9.391, Andrea (BUG-124): "nella slide Come ti vedi oggi compare il risultato della lettura, chi sto diventando: ma chi sto
   diventando e' diverso da come mi vedo. Dillo con parole tue non sembra un pulsante, e porta a una domanda che non e' un quiz".
   La slide mostra SOLO l'immagine di se': l'archetipo del quiz Come ti vedi (immagine-di-se.js, idsArchetipo, la funzione unica).
   Chi stai diventando (il profilo della lettura) sta nella sua slide, la prima, e qui non compare piu'. Senza quiz: un invito con
   un pulsante vero. Il vecchio "Ti vedi cosi'" scritto a mano (fl_chi_sono_oggi) non si mostra piu': non era la domanda giusta.
   0.9.395, Andrea: "voglio che sia incastonato in un riquadro che abbia lo stesso aspetto del chi devi diventare, perche' cosi' e' messo
   male il come ti vedi l'Esigente: non sembra una carta d'identita'". Come ti vedi oggi e' la carta d'identita' di oggi: LA STESSA carta
   del passaporto di Chi devi diventare (pscPassHtml, una funzione sola), con l'icona dell'archetipo al posto della foto, i campi, la sua
   frase e "Rifai il quiz" come azione della carta (come "Apri la pagina" del passaporto). Senza quiz la stessa carta, vuota, con l'invito
   e il pulsante del quiz dentro */
function pscOggiHtml(){ return pscOggiCartaHtml((typeof idsArchetipo === 'function') ? idsArchetipo() : null, true); }
/* a: l'archetipo (idsArchetipo) o null; conAzione: false nella lettura del Genio, dove la carta si guarda e basta */
function pscOggiCartaHtml(a, conAzione){
  const nome = pscNome();
  if (a){
    return pscPassHtml({ cls: 'psc-pass-oggi', testa: 'Il mio io di oggi', testaIco: '🪞', fotoIco: a.ico,
      campi: [['Nome', nome], ['Ti vedi così', a.nome]], frase: '“' + a.frase + '”',
      js: conAzione ? 'pscOggiApri()' : '', aria: 'Rifai il quiz: come ti vedi', apri: 'Rifai il quiz', apriIco: PSC_SVG.rifai });
  }
  let av = ''; try{ av = localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
  return pscPassHtml({ cls: 'psc-pass-oggi psc-pass-vuota', testa: 'Il mio io di oggi', testaIco: '🪞', foto: av, fotoIco: '🙂',
    campi: [['Nome', nome], ['Ti vedi così', 'Ancora da scoprire']],
    invito: 'Nove domande veloci, a scelta. Il Genio ti mostra l’immagine che hai di te, come uno specchio.',
    cta: conAzione ? '<button type="button" class="pst-cta psc-oggi-quiz" onclick="pscOggiApri()">Fai il quiz: come ti vedi</button>' : '' });
}
/* 0.9.391: "Come ti vedi" non e' piu' una domanda con sei risposte e la casella: e' il quiz dell'immagine di se', sulla scena del
   Genio (immagine-di-se.js, idsApri). pscOggiApri resta il nome che chiamano gli altri pulsanti. */
function pscOggiApri(){ if (typeof idsApri === 'function') idsApri('identita'); else pscToast('Il Genio non è pronto, riprova'); }
/* LA CARTA D'IDENTITA' (0.9.395): il passaporto di Chi devi diventare e la carta di Come ti vedi oggi, nella scheda Identita' e nella
   lettura del Genio (oracle.js, orIdentikitHtml). Una funzione sola, cosi' le carte sono la stessa e non due che si somigliano.
   o: { testa, testaIco, foto (indirizzo dell'immagine), fotoIco (al posto della foto), campi: [[etichetta, valore]] (i vuoti non si
   mostrano), frase (la riga sotto, in corsivo), invito (la riga sotto, dritta), tratti: [], js + aria + apri + apriIco (tutta la carta e'
   il pulsante, l'azione e' la riga in fondo), cta (un pulsante vero dentro la carta: allora la carta non e' un pulsante), cls } */
function pscPassHtml(o){
  o = o || {};
  const campi = (o.campi || []).filter(function(c){ return c && c[1]; }).map(function(c){ return '<small>' + pstE(c[0]) + '</small><b>' + pstE(c[1]) + '</b>'; }).join('');
  const foto = '<span class="psc-pass-foto"' + (o.foto ? ' style="background-image:url(\'' + String(o.foto).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (o.foto ? '' : '<i aria-hidden="true">' + (o.fotoIco || '') + '</i>') + '</span>';
  const tratti = (o.tratti || []).filter(Boolean);
  const pulsante = !!o.js && !o.cta;
  const cls = 'psc-pass' + (o.cls ? ' ' + o.cls : '') + ((pulsante && o.apri) || o.cta ? '' : ' psc-pass-chiusa');
  const dentro = '<span class="psc-pass-top"><b>' + pstE(o.testa || '') + '</b>' + (o.testaIco ? '<i aria-hidden="true">' + o.testaIco + '</i>' : '') + '</span>'
    + '<span class="psc-pass-mid">' + foto + '<span class="psc-pass-dati">' + campi + '</span></span>'
    + (o.frase ? '<span class="psc-pass-id">' + pstE(o.frase) + '</span>' : '')
    + (o.invito ? '<span class="psc-pass-id psc-pass-invito">' + pstE(o.invito) + '</span>' : '')
    + (tratti.length ? '<span class="psc-pass-tr">' + tratti.map(function(t){ return '<em>' + pstE(t) + '</em>'; }).join('') + '</span>' : '')
    + (pulsante && o.apri ? '<span class="psc-pass-apri">' + pstE(o.apri) + (o.apriIco || PSC_SVG.avanti) + '</span>' : '')
    + (o.cta ? '<span class="psc-pass-cta">' + o.cta + '</span>' : '');
  return pulsante
    ? '<button type="button" class="' + cls + '" onclick="' + o.js + '"' + (o.aria ? ' aria-label="' + pstE(o.aria) + '"' : '') + '>' + dentro + '</button>'
    : '<div class="' + cls + '">' + dentro + '</div>';
}
/** Il nome (solo il primo) per le carte d'identita': quello detto al Genio, se no quello dell'account. */
function pscNome(){
  let nome = '';
  try{ const g = (typeof gnDati === 'function') ? gnDati() : null; nome = g && g.nome ? String(g.nome) : ''; }catch(_){ }
  if (!nome){ try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = u && u.name ? String(u.name) : ''; }catch(_){ } }
  return nome.trim().split(' ')[0];
}
(function(){ if (typeof document === 'undefined' || !document.head) return; const st = document.createElement('style');
  st.textContent = '.psc-oggi-quiz{white-space:normal;min-height:52px;line-height:1.25}'
    + 'div.psc-pass{cursor:default}.psc-pass-chiusa{padding-bottom:16px}.psc-pass-invito{font-style:normal!important;font-weight:500!important;color:rgba(255,255,255,.85)!important}'
    + '.psc-pass-cta{display:block;padding:18px 16px 16px}.psc-pass-cta .pst-cta{width:100%}';
  document.head.appendChild(st); })();
function pscOggiSalva(){
  const f = document.getElementById('pscOggiF');
  const frase = String((f && f.value) || '').trim().replace(/\s+/g, ' ').slice(0, 140) || PSC.vedi || '';
  const pin = document.getElementById('pscOggiP');
  const parole = String((pin && pin.value) || '').split(/[,;\n]+/).map(function(x){ return x.trim().slice(0, 20); }).filter(Boolean).slice(0, 3);
  if (!frase && !parole.length){ pscToast('Scegli una risposta o scrivi come ti vedi'); return; }
  try{ localStorage.setItem(PSC_OGGI, JSON.stringify({ frase: frase, parole: parole, at: Date.now() })); }
  catch(_){ pscToast('La memoria del telefono è piena, non si salva'); return; }
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast('Salvato come ti vedi');
  pscRidisegna();
}
/* LA CARD PASSAPORTO: il riassunto della pagina "Il mio io futuro" della replica di Notion (nfNotion), dagli stessi dati */
function pscDevoHtml(){
  let o = {}; try{ o = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : (pstJ('fl_iofuturo', {}) || {}); }catch(_){ o = {}; }
  const id = o && o.identita;
  /* 22/11/2026, Andrea: "Il tuo Io Futuro non c'e' ancora non ha senso: il Genio mi ha appena detto chi devo diventare". Chi devi
     diventare viene dalla lettura (fl_oracle: persona, emoji, sogno), la stessa carta che la lettura ti ha appena mostrato */
  const l = pscLettura();
  if (l && l.persona) return pscDevoLetturaHtml(l, (id && id.identity_statement) ? id : null);
  if (!id || !id.identity_statement){
    return '<div class="psc-oggi"><span class="psc-oggi-v" aria-hidden="true">🧭</span><b class="psc-oggi-h">Il tuo Io Futuro non c’è ancora</b><p class="psc-oggi-p">Scopri chi diventi quando arrivi al sogno.</p>'
      + '<button type="button" class="pst-cta" onclick="if(typeof nfApri===\'function\')nfApri(\'s-home\')">Scopri il tuo Io Futuro</button></div>';
  }
  let im = '', sogno = '', data = '';
  try{ im = (typeof nfImmagine === 'function') ? nfImmagine() : ''; }catch(_){ }
  try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  try{ data = (typeof nfDataArrivo === 'function') ? nfDataArrivo() : ''; }catch(_){ }
  const tratti = (Array.isArray(id.traits) ? id.traits : []).map(function(t){ return String(t || '').trim().replace(/[.;]+$/, ''); }).filter(Boolean).slice(0, 3);
  /* 0.9.395: la stessa carta d'identita' di Come ti vedi oggi (pscPassHtml) */
  return pscPassHtml({ testa: 'Il mio io futuro', testaIco: '✈️', foto: im, fotoIco: pscSognoEmoji(),
    campi: [['Nome', pscNome()], ['Destinazione', sogno], ['Arrivo previsto', data]], frase: String(id.identity_statement).slice(0, 180), tratti: tratti,
    js: 'pscDevoApri()', aria: 'Apri la pagina Il mio io futuro', apri: 'Apri la pagina' });
}
/** L'emoji del sogno (oracle.js, orSognoEmoji: quella scelta, quella del sogno, quella della sua leva). Mai l'astronauta. */
function pscSognoEmoji(){ try{ if (typeof orSognoEmoji === 'function') return orSognoEmoji(); }catch(_){ } return '🎯'; }
/* IL PASSAPORTO DALLA LETTURA: chi devi diventare come te l'ha detto il Genio (la leva del tuo sogno), con il nome, la destinazione e
   l'emoji del sogno. Se c'e' anche il tuo Io Futuro, i suoi tratti e la sua pagina; se no, un invito ad approfondire */
function pscDevoLetturaHtml(l, id){
  let im = '', sogno = '', data = '';
  try{ im = (typeof nfImmagine === 'function') ? nfImmagine() : ''; }catch(_){ }
  sogno = String(l.sogno || '').trim();
  if (!sogno){ try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ } }
  try{ data = (typeof nfDataArrivo === 'function') ? nfDataArrivo() : ''; }catch(_){ }
  const persona = String(l.persona || '').replace(/[.!]+$/, '');
  const tratti = id ? (Array.isArray(id.traits) ? id.traits : []).map(function(t){ return String(t || '').trim().replace(/[.;]+$/, ''); }).filter(Boolean).slice(0, 3) : [];
  /* 0.9.395: la stessa carta d'identita' di Come ti vedi oggi (pscPassHtml) */
  return pscPassHtml({ testa: 'Il mio io futuro', testaIco: '✈️', foto: im, fotoIco: l.emoji || pscSognoEmoji(),
    campi: [['Nome', pscNome()], ['Destinazione', sogno], ['Arrivo previsto', data]], frase: persona.charAt(0).toUpperCase() + persona.slice(1) + '.', tratti: tratti,
    js: id ? 'pscDevoApri()' : 'if(typeof nfApri===\'function\')nfApri(\'s-home\')', aria: id ? 'Apri la pagina Il mio io futuro' : 'Approfondisci con il tuo Io Futuro',
    apri: id ? 'Apri la pagina' : 'Approfondisci con il tuo Io Futuro' });
}
function pscDevoApri(){
  pscVibra(8);
  if (typeof nfNotion === 'function') nfNotion('s-home');
  else if (typeof nfApri === 'function') nfApri('s-home');
}
/* CHI STAI DIVENTANDO: il pannello vivo #scLife (scores.js), adottato qui. Se e' vuoto (nessun giorno misurato) parla la riga sotto */
function pscStaiHtml(){
  return '<div class="psc-life" data-adotta="scLife"></div><p class="psc-life-vuoto">Il Genio ti dice chi stai diventando dopo il primo giorno di misure.</p>';
}

(function(){
  const css = [
    /* --- dentro al pannello scuro (testo bianco fisso, uguale nei due temi) --- */
    '.psc-amb,.psc-az,.psc-io{display:flex;flex-direction:column;padding-top:8px}',
    /* 0.9.374: lo stesso margine di lato della scheda Identita' (la slide sta 6 px piu' dentro del pannello) */
    '.psc-az{padding:8px 6px 0}',
    '.psc-azg{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    /* 0.9.397: le abitudini misurate. Un pannello che stacca dal fondo, righe con 16px sopra e sotto; l'icona spenta, il valore acceso
       solo dove chiede attenzione (rosso da cambiare, azzurro da tenere); "Da misurare" piu' smorzato ancora */
    '.psc-ab{margin-top:34px}.psc-ab-k{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 14px}.psc-ab-k p{margin:0;font:800 17px/1.3 var(--font-display);color:#fff}',
    '.psc-ab-g{display:flex;flex-direction:column;border-radius:20px;background:rgba(255,255,255,.07);padding:4px 18px}',
    '.psc-ab-r{display:flex;align-items:center;gap:14px;padding:16px 0}.psc-ab-r + .psc-ab-r{border-top:1px solid rgba(255,255,255,.09)}',
    '.psc-ab-e{flex:none;width:28px;text-align:center;font-size:21px;line-height:1;filter:grayscale(1);opacity:.7}.psc-ab-r.cambia .psc-ab-e{filter:none;opacity:1}',
    '.psc-ab-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}.psc-ab-t b{font:800 15px/1.3 var(--font-body);color:#fff}.psc-ab-t small{font:500 13px/1.45 var(--font-body);color:rgba(232,241,255,.66)}',
    '.psc-ab-v{flex:none;white-space:nowrap;font:800 17px/1 var(--font-display);color:#fff}.psc-ab-r.cambia .psc-ab-v{color:#FF6B76}.psc-ab-r.tieni .psc-ab-v{color:#8CC6FF}',
    '.psc-ab-sub{margin:26px 0 10px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:rgba(232,241,255,.5)}',
    '.psc-ab-d > summary{list-style:none;cursor:pointer;padding:6px 0}.psc-ab-d > summary::-webkit-details-marker{display:none}.psc-ab-d > summary::after{content:" ▾"}.psc-ab-d[open] > summary::after{content:" ▴"}',
    '.psc-ab-g.manca{background:rgba(255,255,255,.04)}.psc-ab-g.manca .psc-ab-t b{color:rgba(255,255,255,.78)}.psc-ab-g.manca .psc-ab-e{opacity:.45}',
    '.psc-azc{position:relative;min-width:0;display:flex}',
    '.psc-azc-b{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;padding:20px 12px 14px;border:0;border-radius:20px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;font:inherit}',
    '.psc-azc.prop .psc-azc-b{background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1.5px rgba(140,198,255,.22)}',
    '.psc-azc-b:active{transform:scale(.98)}',
    '.psc-azc-e{width:48px;height:48px;border-radius:24px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:24px;line-height:1;margin-bottom:4px}',
    '.psc-azc-b b{font:800 15px/1.25 var(--font-display);color:#fff;overflow-wrap:anywhere}',
    '.psc-azc-b i{font:800 13px var(--font-body);font-style:normal;color:#8CC6FF}',
    '.psc-azc-b small{font:600 12px/1.35 var(--font-body);color:rgba(200,239,253,.72);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '.psc-azc-tag{margin-top:4px;font:800 10.5px var(--font-body);font-style:normal;letter-spacing:.06em;text-transform:uppercase;color:#fff;padding:4px 9px;border-radius:99px;background:#0075E3}.psc-azc-tag.cambia{background:#E63946}',
    '.psc-azc-f{margin-top:2px;font:600 11px var(--font-body);color:rgba(200,239,253,.55)}',
    '.psc-azc-x{position:absolute;top:8px;right:8px;width:28px;height:28px;border:0;border-radius:14px;background:rgba(255,255,255,.12);color:#C8EFFD;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.psc-azc-piu{min-height:150px;flex-direction:column;align-items:center;justify-content:center;gap:12px;border:1.5px dashed rgba(140,198,255,.55);border-radius:20px;background:rgba(255,255,255,.04);cursor:pointer;color:#fff;font:inherit;padding:12px}.psc-azc-piu b{font:800 14px/1.3 var(--font-display);color:#fff}',
    /* il pulsante come quello del report della settimana: pieno, largo, con spazio vero dentro */
    '.psc-az-chiedi{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin-top:26px;min-height:56px;padding:14px 22px;border:0;border-radius:18px;background:#0075E3;color:#fff;font:800 15px/1.35 var(--font-body);text-align:center;cursor:pointer;box-sizing:border-box}.psc-az-chiedi i{flex:none;font-size:20px;font-style:normal;line-height:1}.psc-az-chiedi span{text-wrap:balance}',
    '.psc-per-btn{border:0;background:rgba(140,198,255,.18);color:#C8EFFD;font:700 14px var(--font-body);padding:3px 10px;border-radius:99px;cursor:pointer;display:inline-flex;align-items:center;gap:4px}',
    '.psc-fg-amb h3{margin:6px 0 22px!important;text-align:center}.psc-fg-amb .fl-info-car{border-radius:22px;background:linear-gradient(160deg,#0075E3 0%,#001E44 78%)}',
    '.psc-fg-amb .fl-info-s{padding:30px 22px 26px}.psc-fg-amb .fl-info-s b{color:#fff!important}.psc-fg-amb .fl-info-s p{color:rgba(255,255,255,.86)!important}',
    '.psc-lez{text-decoration:underline;text-underline-offset:3px;color:#0075E3!important}body.dark .psc-lez{color:#8CC6FF!important}',
    '.psc-stai{margin-top:34px}.psc-oggi-k{margin:14px 0 0;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-vedi .psc-vedi-g{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:22px 0 6px}.psc-vedi-o{min-height:58px;padding:10px 12px;border-radius:16px;border:1.5px solid #C8EFFD;background:#F0FBFF;color:#001E44;font:700 14px/1.3 var(--font-body);cursor:pointer}.psc-vedi-o.on{border-color:#0075E3;background:#0075E3;color:#fff}body.dark .psc-vedi-o{background:#0E1D3D;border-color:#1F3A66;color:#fff}body.dark .psc-vedi-o.on{background:#0075E3;border-color:#0075E3}.psc-vedi .psc-lab{display:block;margin:26px 0 10px}.psc-vedi .psc-salva{margin-top:30px}',
    '.psc-testa{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 26px;text-align:center}.psc-testa p{margin:0;font:600 14px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.psc-i{flex:none;width:24px;height:24px;padding:0;border:0;border-radius:12px;background:rgba(140,198,255,.2);color:#C8EFFD;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-griglia{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-card{position:relative;min-width:0;aspect-ratio:3/4;border:0;padding:0;border-radius:20px;overflow:hidden;cursor:pointer;display:flex;align-items:flex-end;text-align:left;background:linear-gradient(160deg,#3F9FF4,#0075E3 45%,#001E44);background-size:cover;background-position:center;-webkit-tap-highlight-color:transparent}',
    '.psc-card:active{transform:scale(.98)}',
    /* l'emoji sta in alto, nel suo spazio: centrata a meta' card finiva sotto al nome quando il nome va su due righe */
    '.psc-card:not(.psc-card-piu){flex-direction:column;justify-content:space-between;align-items:stretch;aspect-ratio:auto;min-height:232px}.psc-card.foto{justify-content:flex-end}.psc-card-piu{aspect-ratio:auto;min-height:232px}.psc-card-art{position:relative;z-index:1;align-self:center;margin-top:20px;font-size:46px;line-height:1}',
    '.psc-veil{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 34%,rgba(0,30,68,.86))}',
    '.psc-card-txt{position:relative;display:flex;flex-direction:column;gap:3px;padding:12px;width:100%;box-sizing:border-box;min-width:0}',
    '.psc-card-txt b{font:800 16px/1.2 var(--font-display);color:#fff;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:break-word}',
    '.psc-card-txt i{font:600 12px/1.3 var(--font-body);font-style:normal;color:#C8EFFD}',
    '.psc-card-ico{position:absolute;top:10px;left:10px;z-index:2;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;background:rgba(255,255,255,.92);box-shadow:0 3px 10px rgba(0,0,0,.25)}',
    '.psc-casa-p{margin:0 0 22px;text-align:center;font:500 15px/1.5 var(--font-body);color:var(--muted)}.psc-casa-p b{color:var(--navy)}body.dark .psc-casa-p b{color:#fff}',
    '.psc-casa-n{display:flex;align-items:center;gap:16px;margin:4px 0 26px}.psc-casa-n > div{flex:1;text-align:center}.psc-casa-n b{display:block;font:900 22px/1.2 var(--font-display);color:#0075E3}.psc-casa-n small{display:block;margin-top:6px;font:600 12.5px var(--font-body);color:var(--muted)}.psc-casa-n i{width:1px;height:40px;background:var(--line)}body.dark .psc-casa-n b{color:#8CC6FF}',
    '.psc-casa-inn{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 18px;padding:14px 16px;border-radius:16px;background:var(--bg,#F0FBFF);border:1px solid var(--line)}.psc-casa-inn span{font:700 14.5px var(--font-body);color:var(--navy)}.psc-casa-inn div{display:flex;align-items:center;gap:12px}.psc-casa-inn button{width:34px;height:34px;border-radius:50%;border:0;background:#0075E3;color:#fff;font:800 18px/1 var(--font-body);cursor:pointer}.psc-casa-inn b{min-width:22px;text-align:center;font:800 17px var(--font-body);color:var(--navy)}body.dark .psc-casa-inn{background:#12203A;border-color:#22345A}body.dark .psc-casa-inn span,body.dark .psc-casa-inn b{color:#fff}',
    '.psc-step{gap:12px}.psc-step-n{width:76px;height:44px;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);color:var(--navy);text-align:center;font:800 18px var(--font-display);-moz-appearance:textfield}.psc-step-n::-webkit-inner-spin-button,.psc-step-n::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.psc-step button{width:40px;height:40px;border-radius:20px}body.dark .psc-step-n{background:#141C2C;color:#fff;border-color:#25314A}',
    '.psc-casa-go{margin-top:4px}.psc-casa-n2{display:block;margin-top:10px;font:500 13px/1.45 var(--font-body);color:var(--muted);text-align:center}.psc-casa-cambia{border:0;background:none;padding:0;color:#0075E3;font:700 13px var(--font-body);text-decoration:underline;cursor:pointer}',
    '.psc-casa-num{display:flex;align-items:center;gap:16px;margin:8px 0 4px}.psc-casa-num > div{flex:1;text-align:center}.psc-casa-num b{display:block;font:900 22px/1.2 var(--font-display);color:#0075E3}.psc-casa-num small{display:block;margin-top:6px;font:600 12.5px var(--font-body);color:var(--muted)}.psc-casa-num i{width:1px;height:40px;background:var(--line)}body.dark .psc-casa-num b{color:#8CC6FF}',
    '.psc-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}.psc-chips em{font:700 10.5px/1 var(--font-body);font-style:normal;color:#fff;background:rgba(255,255,255,.18);padding:5px 7px;border-radius:99px;white-space:nowrap}',
    '.psc-card-piu{background:rgba(255,255,255,.04);border:1.5px dashed rgba(140,198,255,.55);flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:12px}',
    '.psc-piu-ic{width:44px;height:44px;border-radius:22px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center}.psc-piu-ic svg{width:20px;height:20px}',
    '.psc-card-piu b{font:800 14px/1.3 var(--font-display);color:#fff}',
    /* azione */
    '.psc-gr{display:flex;flex-direction:column;gap:8px}.psc-gr + .psc-gr{margin-top:22px}',
    '.psc-gr-t{margin:0 0 4px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-att{display:flex;align-items:center;gap:12px;min-height:52px;padding:8px 8px 8px 12px;border-radius:16px;background:rgba(255,255,255,.07)}',
    '.psc-att-i{flex:none;width:32px;height:32px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;overflow:hidden}.psc-att-i img{width:32px;height:32px;object-fit:contain}',
    '.psc-att-n{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;text-align:left}.psc-att-n b{font:700 14px/1.3 var(--font-body);color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psc-att-n small{font:600 12px var(--font-body);color:#C8EFFD}',
    '.psc-att-r{background:none!important;padding:6px 4px!important;min-height:44px!important}.psc-att-tr{display:block;height:6px;margin-top:6px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}.psc-att-tr em{display:block;height:100%;border-radius:99px;background:#3F9FF4}.psc-att-v{flex:none;font:800 13.5px var(--font-body);color:#fff}',
    '.psc-att-hint{margin:26px 0 0;text-align:center;font:600 14px var(--font-body);color:#C8EFFD}',
    '.psc-att-piu{flex:none;width:40px;height:40px;border:0;border-radius:20px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-blocco-az,.psc-azb{margin-top:30px}.psc-azb .pst-link{margin-top:14px}',
    '.psc-k{margin:0 0 26px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-azl{display:flex;flex-direction:column;gap:8px}',
    '.psc-ag,.psc-azb{display:flex;flex-direction:column;align-items:center;text-align:center}.psc-ag .tls-genio{justify-content:center}.psc-ag .tls-punti{text-align:left;align-self:stretch}.psc-azl{align-self:stretch}',
    '.psc-az-cta{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:24px;width:auto!important;padding:0 24px!important}.psc-az-cta svg{flex:none}',
    '.psc-az-link{margin-top:14px;border:0;background:none;color:#C8EFFD;font:600 14px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    '.psc-az-out{display:inline-flex;align-items:center;gap:8px;margin-top:20px;min-height:46px;padding:0 22px;border:1.5px solid rgba(255,255,255,.5);border-radius:23px;background:none;color:#fff;font:700 14.5px var(--font-body);cursor:pointer}.psc-az-out svg{width:18px;height:18px}',
    '.psc-azb .psc-k{text-align:center}',
    '.psc-azr{display:flex;align-items:center;gap:12px;width:100%;padding:10px 12px;border:0;border-radius:16px;background:rgba(255,255,255,.07);text-align:left;cursor:pointer}',
    '.psc-azr-e{flex:none;width:40px;height:40px;border-radius:20px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:20px;line-height:1}',
    '.psc-azr-t{flex:1;min-width:0;display:flex;flex-direction:column;align-items:flex-start;gap:5px}.psc-azr-t b{font:700 14.5px/1.35 var(--font-body);color:#fff}',
    '.psc-azr-t small{font:800 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#fff;padding:4px 8px;border-radius:99px;background:#0075E3}.psc-azr-t small.cambia{background:#E63946}',
    '.psc-azv{margin-top:-8px}',
    '.psc-ag .tls-punti{margin-top:20px}.psc-ag .pst-link.muto,.psc-torna{margin-top:4px}',
    '.psc-ponte{display:flex;gap:12px;align-items:flex-start;margin-top:18px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.07);text-align:left}.psc-ponte span{font-size:20px}.psc-ponte p{margin:0;font:600 13.5px/1.45 var(--font-body);color:#fff}.psc-ponte small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:#C8EFFD}',
    /* identita */
    /* 0.9.368, Andrea: "due schede e lo spazio per una terza vuoto, e Chi devi diventare va a capo": tante colonne quanti i pulsanti, una riga */
    '.psc-seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:4px;padding:4px;border-radius:18px;background:rgba(255,255,255,.07)}',
    '.psc-seg button{min-height:44px;border:0;border-radius:14px;background:none;color:rgba(255,255,255,.65);font:700 13.5px/1.2 var(--font-body);padding:6px 8px;cursor:pointer;white-space:nowrap}.psc-seg button.on{background:#fff;color:#001E44}',
    /* 0.9.371, Andrea: "nella scheda Identita' se provo a scorrere su e giu' non scorre, si scorre solo di lato". LA CAUSA:
       overscroll-behavior-y:none sul carosello (0.9.370) fermava il passaggio dello scorrimento verticale alla pagina. Ora si ferma solo
       quello di lato (che altrimenti cambierebbe scheda), e l'altezza segue la slide che si vede (pscIoAltezza) */
    '.psc-io-car{overflow:hidden;margin:0 -12px;touch-action:pan-y;transition:height .25s ease}.psc-io-tr{display:flex;align-items:flex-start;transition:transform .32s cubic-bezier(.2,.8,.2,1);will-change:transform}.psc-io-dots i{cursor:pointer}',
    '.psc-io-k{margin:4px 0 22px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    /* lo spazio intorno alla slide lascia respirare l'alone del pannello (prima tagliato), e il pannello non e' mai piu' largo della slide */
    '.psc-io-s .psc-seg{margin-bottom:24px}.psc-io-s #scLife,.psc-io-s .psc-life{overflow:visible!important;max-height:none!important}.psc-io-s{padding:8px 18px 22px!important}',
    '.psc-io-s #scLife{width:auto!important;max-width:100%!important;box-sizing:border-box!important;margin-left:0!important;margin-right:0!important}',
    '.psc-io-s{flex:0 0 100%;min-width:0;box-sizing:border-box;padding:0 4px}',
    '.psc-io-dots{display:flex;justify-content:center;gap:7px;margin:22px 0 4px}.psc-io-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.28)}.psc-io-dots i.on{background:#fff}',
    '.psc-pano{display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:6px;width:100%}.psc-tre-svg{display:block;width:min(280px,86%);height:auto;margin:0 auto}',
    '.psc-tre-g{fill:rgba(255,255,255,.04);stroke:rgba(255,255,255,.25);stroke-width:1.2}.psc-tre-g2{fill:none;stroke:rgba(255,255,255,.14);stroke-width:1;stroke-dasharray:3 4}',
    '.psc-tre-tu{fill:rgba(63,159,244,.35);stroke:#3F9FF4;stroke-width:2.2;stroke-linejoin:round}.psc-tre-p{fill:#3F9FF4;stroke:#fff;stroke-width:1.5}.psc-tre-p.basso{fill:#E63946}',
    '.psc-tre-l{font:700 11.5px var(--font-body);fill:#C8EFFD}.psc-tre-l.basso{fill:#FF8A92}',
    '.psc-pano-k{margin:26px 0 0;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#FF8A92}',
    '.psc-pano-h{display:block;margin-top:8px;font:800 24px var(--font-display);color:#fff}.psc-pano-p{margin:12px 0 0;max-width:30ch;font:500 14.5px/1.5 var(--font-body);color:rgba(255,255,255,.85)}',
    '.psc-pano .pst-cta{margin-top:30px;width:auto;padding:0 28px;white-space:nowrap}',
    '.psc-io-c{margin-top:26px;display:flex;flex-direction:column}',
    '.psc-oggi{display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.psc-oggi-v{width:72px;height:72px;border-radius:36px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:38px;line-height:1;box-shadow:0 8px 22px rgba(0,0,0,.28)}',
    '.psc-oggi-h{margin-top:14px;font:800 18px var(--font-display);color:#fff}.psc-oggi-p{margin:8px 0 32px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.75)}',
    '.psc-oggi-f{margin:16px 0 0;font:italic 600 17px/1.45 var(--font-body);color:#fff}',
    '.psc-parole{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:18px}.psc-parole em{font:800 13px var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:7px 12px;border-radius:99px}',
    '.psc-oggi .pst-link{margin-top:24px}',
    '.psc-pass{display:flex;flex-direction:column;width:100%;padding:0;border:1px solid rgba(140,198,255,.35);border-radius:20px;overflow:hidden;background:linear-gradient(160deg,#0B3F7A,#001E44);text-align:left;cursor:pointer;box-shadow:0 10px 24px rgba(0,0,0,.25)}',
    '.psc-pass-top{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#0075E3}.psc-pass-top b{font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#fff}.psc-pass-top i{font-style:normal;font-size:18px}',
    '.psc-pass-mid{display:flex;gap:14px;padding:16px}',
    '.psc-pass-foto{flex:none;width:86px;height:110px;border-radius:12px;background:#C8EFFD;background-size:cover;background-position:center 30%;display:flex;align-items:center;justify-content:center;border:3px solid #fff}.psc-pass-foto i{font-style:normal;font-size:40px}',
    '.psc-pass-dati{flex:1;min-width:0;display:flex;flex-direction:column}.psc-pass-dati small{font:800 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.psc-pass-dati small:not(:first-child){margin-top:9px}.psc-pass-dati b{margin-top:2px;font:700 14px/1.3 var(--font-body);color:#fff;overflow-wrap:anywhere}',
    '.psc-pass-id{display:block;margin:0 16px;padding-top:14px;border-top:1px dashed rgba(140,198,255,.4);font:italic 600 14.5px/1.5 var(--font-body);color:#fff}',
    '.psc-pass-tr{display:flex;flex-wrap:wrap;gap:6px;padding:12px 16px 0}.psc-pass-tr em{font:700 12px/1.3 var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:6px 10px;border-radius:99px}',
    '.psc-pass-apri{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;padding:14px;border-top:1px solid rgba(255,255,255,.1);font:800 14px var(--font-body);color:#8CC6FF}',
    '.psc-life{padding:16px 6px}.psc-life #scLife{margin:0!important}.psc-life .life-wrap{margin:0}.psc-life .life{padding:26px 16px 22px!important}.psc-life .life-big{font-size:clamp(21px,6.4vw,27px)!important;line-height:1.15;overflow-wrap:break-word}',
    '.psc-life-vuoto{display:none;margin:0;text-align:center;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.7)}.psc-life:empty + .psc-life-vuoto,.psc-life:has(> #scLife:empty) + .psc-life-vuoto{display:block}.psc-life:has(> #scLife:empty){display:none}',
    /* --- le pagine a schermo intero (colori del tema) --- */
    '.psc-bar{display:flex;align-items:center}.psc-bar-t{flex:1;text-align:center;font:800 17px var(--font-display);color:var(--navy)}',
    '.psc-pag{padding:12px 20px 40px;max-width:560px;margin:0 auto;display:flex;flex-direction:column}',
    '.psc-foto{position:relative;width:100%;aspect-ratio:16/10;border-radius:22px;border:1.5px dashed var(--line);background-color:var(--card);background-size:cover;background-position:center;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;color:var(--navy)}',
    '.psc-foto.piena{border:0;align-items:flex-end;justify-content:flex-end}',
    '.psc-foto-v{display:flex;flex-direction:column;align-items:center;gap:10px;color:#0075E3}.psc-foto-v b{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-foto-c{display:inline-flex;align-items:center;gap:6px;margin:12px;padding:8px 12px;border-radius:99px;background:rgba(0,30,68,.72);color:#fff;font:700 12.5px var(--font-body)}.psc-foto-c svg{width:16px;height:16px}',
    '.psc-campo{display:flex;flex-direction:column;margin-top:30px}.psc-campo > label{font:800 15px var(--font-display);color:var(--navy)}.psc-campo > small{margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-campo > input,.psc-campo > .psc-tempo,.psc-campo > textarea{margin-top:10px}',
    /* 0.9.367, Andrea: "il - e + attaccati alla domanda: usa le regole dello spacing". Domanda -> controllo 16 px, gruppo -> gruppo 32 px */
    '.psc-campo{margin-top:32px!important}.psc-campo > .psc-step,.psc-campo > .md-step{margin-top:16px!important}.psc-campo > small + .psc-step,.psc-campo > small + .md-step{margin-top:16px!important}.psc-campo > .psc-nota-in{margin-top:22px!important}',
    '.psc-casa-fg{padding-top:8px}.psc-fg-alza{position:absolute;left:16px;top:16px;width:40px;height:40px;border:0;border-radius:50%;background:#EAF2FB;color:#001E44;display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .psc-fg-alza{background:#1B2B48;color:#fff}',
    '.psc-casa-testa{display:flex;flex-direction:column;align-items:center;margin-top:12px}',
    '.psc-casa-anteprima{position:relative;width:132px;height:170px;border-radius:20px;background-size:cover!important;background-position:center!important;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:22px 10px 14px;box-sizing:border-box;box-shadow:0 10px 24px rgba(0,30,68,.2)}',
    '.psc-casa-anteprima span{font-size:46px;line-height:1}.psc-casa-anteprima.foto span{position:absolute;left:10px;top:10px;font-size:22px;width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.9);display:flex;align-items:center;justify-content:center}.psc-casa-anteprima b{font:800 16px var(--font-display);color:#fff;text-shadow:0 1px 6px rgba(0,0,0,.3)}',
    '.psc-casa-l{align-self:stretch;margin:26px 0 12px;font:800 14px var(--font-display);color:var(--navy);text-align:left}body.dark .psc-casa-l{color:#fff}',
    '.psc-casa-emo{display:grid;grid-template-columns:repeat(8,1fr);gap:6px;align-self:stretch}.psc-casa-emo button{aspect-ratio:1;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);font-size:20px;cursor:pointer;padding:0}.psc-casa-emo button.on{border-color:#0075E3;box-shadow:0 0 0 2px rgba(0,117,227,.25)}',
    '.psc-casa-sf{display:flex;gap:12px;align-self:stretch}.psc-casa-sf button{flex:1;height:48px;border:0;border-radius:14px;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(0,0,0,.05)}.psc-casa-sf button.on{box-shadow:0 0 0 3px var(--bg,#fff),0 0 0 5px #0075E3}',
    '.psc-casa-foto{display:flex;align-items:center;justify-content:center;background:#F0FBFF!important;border:1.5px dashed #8CC6FF!important;color:#0075E3}body.dark .psc-casa-foto{background:#0E1D3D!important;color:#8CC6FF}',
    '.psc-rete{display:flex;align-items:center;gap:12px;margin-top:20px;padding:14px;border-radius:16px;background:#F0FBFF;border:1px solid #C8EFFD}body.dark .psc-rete{background:#0E1D3D;border-color:#1F3A66}',
    '.psc-rete > span{font-size:20px}.psc-rete > div{flex:1;min-width:0}.psc-rete small{display:block;font:600 12px var(--font-body);color:var(--muted)}.psc-rete b{display:block;margin-top:2px;font:700 14.5px var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}body.dark .psc-rete b{color:#fff}',
    '.psc-rete button{flex:none;min-height:36px;padding:0 14px;border:1.5px solid #0075E3;border-radius:18px;background:none;color:#0075E3;font:700 13px var(--font-body);cursor:pointer}body.dark .psc-rete button{color:#8CC6FF;border-color:#8CC6FF}',
    '.psc-casa-num b{white-space:nowrap}',
    '.psc-reti{display:flex;flex-direction:column;gap:8px;margin-top:12px}.psc-reti button{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:48px;padding:0 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);color:var(--navy);font:700 14px var(--font-body);text-align:left;cursor:pointer}',
    '.psc-reti button span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psc-reti button small{flex:none;font:600 12px var(--font-body);color:var(--muted)}.psc-reti button.on{border-color:#0075E3;box-shadow:0 0 0 2px rgba(0,117,227,.2)}body.dark .psc-reti button{color:#fff}',
    '.psc-reti p{margin:0;font:500 13.5px var(--font-body);color:var(--muted);text-align:center}',
    '.psc-casa-fg{padding-top:44px}.psc-casa-testa{margin-top:0}',
    '.psc-fin{box-sizing:border-box;font-size:16px!important}.psc-n{max-width:120px}.psc-tempo .psc-n{width:84px;flex:none}.psc-nota-in{min-height:64px!important;margin-top:12px!important}',
    '.psc-tempo{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.psc-u{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-unita{display:flex;gap:2px;padding:3px;border-radius:99px;background:rgba(0,117,227,.1)}.psc-unita button{border:0;background:none;color:var(--navy);font:700 13px var(--font-body);padding:9px 14px;border-radius:99px;cursor:pointer}.psc-unita button.on{background:#0075E3;color:#fff}',
    'body.dark .psc-unita{background:rgba(140,198,255,.14)}',
    '.psc-salva{margin-top:32px}',
    '.psc-via{display:block;margin:16px auto 0;border:0;background:none;color:#E63946;font:700 14px var(--font-body);padding:8px;cursor:pointer}',
    '.psc-tel-prev{display:flex;justify-content:center;margin-top:6px}',
    '.psc-tel-schermo{width:150px;aspect-ratio:9/19;border-radius:26px;border:5px solid #001E44;background:linear-gradient(160deg,#3F9FF4,#001E44);background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:44px;box-shadow:0 14px 30px rgba(0,30,68,.25)}',
    'body.dark .psc-tel-schermo{border-color:#3F9FF4}',
    '.psc-tel-p{margin:20px 0 0;text-align:center;font:600 14.5px/1.45 var(--font-body);color:var(--navy)}',
    '.psc-fonti{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:16px}.psc-fonti button{border:1.5px solid #3F9FF4;background:var(--card);color:var(--navy);font:700 13.5px var(--font-body);padding:10px 14px;border-radius:99px;cursor:pointer}',
    '.psc-blocco{margin-top:30px}.psc-pag .psc-k{color:#0075E3}body.dark .psc-pag .psc-k{color:#8CC6FF}',
    '.psc-tiles{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-tile{display:flex;flex-direction:column;align-items:center;gap:12px;padding:18px 12px;border-radius:20px;border:0;background:#0075E3;color:#fff;cursor:pointer;text-align:center}.psc-tile span{font-size:28px;line-height:1}.psc-tile b{font:800 14px/1.3 var(--font-body)}.psc-tile small{font:600 11.5px var(--font-body);color:#C8EFFD}',
    '.psc-tile.spento{opacity:.45}.psc-tile span svg{width:28px;height:28px;display:block}',
    /* 0.9.364, Andrea: "quel contenitore grigio non e' un colore del mio brand: azzurrino" (il rosa tenue sul bianco sembrava grigio) */
    '.psc-avviso{margin:16px 0 0;padding:12px 14px;border-radius:16px;background:#F0FBFF;border:1px solid #C8EFFD;color:#001E44;font:600 13.5px/1.45 var(--font-body)}body.dark .psc-avviso{background:#0E1D3D;border-color:#22345A;color:#D6E8FF}',
    '.psc-riga-sw{display:flex;align-items:center;gap:14px;padding:16px;border-radius:20px;background:var(--card);border:1px solid var(--line)}.psc-riga-sw > div{flex:1;min-width:0}.psc-riga-sw b{display:block;font:800 15px/1.3 var(--font-body);color:var(--navy)}.psc-riga-sw small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-riga-sw.chiusa{cursor:pointer}.psc-prem{display:inline-block;margin-top:8px;padding:4px 9px;border-radius:99px;background:#001E44;color:#fff;font:800 11px var(--font-body);letter-spacing:.04em}body.dark .psc-prem{background:#0075E3}',
    '.psc-sw-chiuso{opacity:.6;pointer-events:none}',
    /* --- i fogli --- */
    '.psc-fg{text-align:center}.psc-fg-e{display:block;font-size:40px;line-height:1;margin-top:8px}.psc-fg h3{margin:14px 26px 26px!important}',
    /* 0.9.386, Andrea: "nel foglio Fatto il titolo e il paragrafo sono appiccicati". CAUSA: il margine sopra era negativo (-12px) e
       contava sul margine sotto del titolo; nel foglio Fatto il titolo non ne ha, e il paragrafo gli finiva addosso. Mai negativo */
    '.psc-fg-p{margin:14px 0 32px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.psc-fg-da{margin:12px 0 24px;font:600 13.5px var(--font-body);color:var(--muted)}',
    '.psc-azf-app{margin:-8px 0 24px;padding:14px 16px;border-radius:16px;background:#F0FBFF;text-align:left}.psc-azf-app p{margin:0 0 10px;font:700 14px var(--font-body);color:var(--navy)}.psc-azf-app ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}.psc-azf-app li{display:flex;justify-content:space-between;gap:12px;font:500 14px var(--font-body);color:var(--navy)}.psc-azf-app li b{flex:none;font-weight:800;color:#0075E3}body.dark .psc-azf-app{background:#12203A}body.dark .psc-azf-app li b{color:#8CC6FF}',
    '.psc-fg-2{display:block;width:100%;margin-top:12px;min-height:50px;border:1.5px solid var(--line);border-radius:25px;background:none;color:var(--navy);font:700 15px var(--font-body);cursor:pointer}',
    '.psc-lab{display:block;margin:22px 0 10px;text-align:left;font:800 14px var(--font-display);color:var(--navy)}',
    '.psc-scelta{display:grid;grid-template-columns:1fr 1fr;gap:8px}.psc-scelta button{min-height:52px;border:1.5px solid var(--line);border-radius:16px;background:none;color:var(--navy);font:700 13.5px/1.3 var(--font-body);padding:8px;cursor:pointer}',
    '.psc-scelta button.on.cambia{background:#E63946;border-color:#E63946;color:#fff}.psc-scelta button.on.nuova{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.psc-emoji{display:grid;grid-template-columns:repeat(9,1fr);gap:4px}.psc-emoji button{aspect-ratio:1;border:1.5px solid transparent;border-radius:12px;background:rgba(0,117,227,.08);font-size:18px;line-height:1;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#0075E3;background-size:cover;background-position:center}',
    '.psc-emoji button.on{border-color:#0075E3;background-color:rgba(0,117,227,.18)}.psc-emoji-foto svg{width:18px;height:18px}body.dark .psc-emoji button{background-color:rgba(140,198,255,.12);color:#8CC6FF}',
    '.psc-tre{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.psc-tre input{min-width:0;padding:12px 8px!important;text-align:center}',
    '.psc-oggi-in{min-height:72px!important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function(){ const st = document.createElement('style'); st.textContent = '.psc-spec{margin:18px 0 0;padding:16px;border-radius:18px;background:rgba(255,255,255,.07);text-align:left}.psc-spec-k{margin:0 0 12px;font:800 13px var(--font-body);letter-spacing:.04em;color:#8CC6FF;text-align:center}.psc-spec-p{margin:0 0 6px;font:500 14px/1.45 var(--font-body);color:rgba(232,241,255,.85);text-align:center}.psc-spec-r{display:grid;grid-template-columns:1fr 70px 40px;align-items:center;gap:10px;margin:0 0 10px;font:600 13.5px/1.3 var(--font-body);color:rgba(232,241,255,.85)}.psc-spec-r.top span{color:#fff;font-weight:800}.psc-spec-r i{height:8px;border-radius:8px;background:rgba(255,255,255,.12);overflow:hidden}.psc-spec-r i b{display:block;height:100%;border-radius:8px;background:#E63946}.psc-spec-r em{font:800 13px var(--font-body);font-style:normal;color:#fff;text-align:right}.psc-spec .pst-link{display:block;margin:10px auto 0}.psc-capo{margin:0 0 16px;padding:16px;border-radius:18px;background:rgba(63,159,244,.16);text-align:center}.psc-capo p{margin:0 0 6px;font:600 13.5px var(--font-body);color:rgba(232,241,255,.75)}.psc-capo p span{text-decoration:line-through;color:#FF8A92}.psc-capo b{font:800 17px/1.35 var(--font-display);color:#fff}'; document.head.appendChild(st); })();

(function(){ const st = document.createElement('style'); st.textContent = '.psc-testa p .pst-i{margin-left:2px}'; document.head.appendChild(st); })();

registerScreen('s-ambiente-pc',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t">Il computer</b><button class="iconbtn" onclick="pscPcInfo()" aria-label="Come funziona il computer come innesco">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscPcBody"></div><div class="spacer"></div>', { back: function(){ return pscBozzaIndietro('pc'); } });
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-rosso{color:#E63946!important}.psc-chips em.no{background:rgba(230,57,70,.92)!important;color:#fff!important}'
  + '.psc-pc-prev{display:flex;flex-direction:column;align-items:center;margin:8px 0 18px}.psc-pc-schermo{width:min(300px,82%);aspect-ratio:16/10;border-radius:12px;border:8px solid #001E44;background:#C8EFFD center/cover;display:flex;align-items:center;justify-content:center;font-size:44px;box-shadow:0 10px 24px rgba(0,30,68,.18)}.psc-pc-base{display:block;width:34%;height:10px;margin-top:6px;border-radius:0 0 10px 10px;background:#001E44}'
  + 'body.dark .psc-pc-schermo{border-color:#22345A}body.dark .psc-pc-base{background:#22345A}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-nota-d{margin:26px 0 8px}.psc-nota-d summary{list-style:none;cursor:pointer;text-align:center;font:700 14.5px var(--font-body);color:#0075E3}.psc-nota-d summary::-webkit-details-marker{display:none}.psc-nota-d summary small{color:var(--muted);font-weight:500}.psc-nota-d[open] summary{margin-bottom:12px}body.dark .psc-nota-d summary{color:#8CC6FF}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-testa p .psc-nw{white-space:nowrap}.psc-testa p .psc-i2{margin-left:6px!important}.psc-testa p .psc-per-btn{margin:4px 0}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-nw{white-space:nowrap}'; document.head.appendChild(st); })();

/* 0.9.381: la conferma dopo aver messo l'immagine. Un foglio grande al posto del toast (Andrea: "i pop-up piccolini scompaiono subito e il
   testo e' minuscolo"), con l'anteprima del telefono, che si chiude da solo dopo qualche secondo */
async function pscTelFatto(target, frase){
  const url = pscBozzaUrl('tel', target === 'home' ? 'home' : 'lock');
  const cit = frase ? (await pscFraseOggi()) || 'La frase del giorno' : '';
  if (typeof inSheet !== 'function'){ pscToast('Fatto'); return; }
  const tit = target === 'lock' ? (frase ? 'Fatto: la frase del giorno è sopra alla tua immagine' : 'Fatto: la tua immagine è sul blocco schermo') : 'Fatto: la tua immagine è lo sfondo della Home';
  const sub = frase ? 'Ogni giorno la frase cambia, la tua immagine resta sotto.' : 'Guardala ogni volta che prendi il telefono.';
  inSheet('<div class="en-foglio psc-fatto"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="psc-fatto-tel"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>'
    + (frase ? '<span class="psc-fatto-velo"></span><p>' + String(cit).replace(/[<>&]/g, '').slice(0, 120) + '</p>' : '') + '</div>'
    + '<h3>' + tit + '</h3><p class="psc-fg-p">' + sub + '</p><i class="psc-fatto-barra"></i></div>');
  clearTimeout(window.__pscFattoT);
  window.__pscFattoT = setTimeout(function(){ try{ if (document.querySelector('.psc-fatto')) inSheetChiudi(); }catch(_){ } }, 5500);
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* Andrea: "i due pannelli quadrati non sembrano pulsanti: un bordo piu' scuro, un bagliore, due colori diversi" */
  '.psc-tile{border:2px solid #004C99!important;box-shadow:0 0 0 3px rgba(0,117,227,.18),0 10px 22px rgba(0,117,227,.35);transition:transform .15s}.psc-tile:active{transform:scale(.96)}'
  + '.psc-tile-home,.psc-tile-desk{background:#E63946!important;border-color:#9E1C27!important;box-shadow:0 0 0 3px rgba(230,57,70,.18),0 10px 22px rgba(230,57,70,.35)}.psc-tile-home small,.psc-tile-desk small{color:#FFE1E4!important}'
  + '.psc-fatto{text-align:center}.psc-fatto h3{margin:18px 0 0}.psc-fatto-tel{position:relative;width:140px;aspect-ratio:9/19;margin:6px auto 0;border-radius:24px;border:5px solid #001E44;background:linear-gradient(160deg,#3F9FF4,#001E44);background-size:cover;background-position:center;overflow:hidden;display:flex;align-items:center;justify-content:center}'
  + '.psc-fatto-velo{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,8,20,.4),rgba(0,8,20,.7))}.psc-fatto-tel p{position:relative;margin:0 12px;font:italic 600 12px/1.4 Georgia,serif;color:#fff;text-align:center}'
  + '.psc-fatto-barra{display:block;height:4px;margin:20px auto 0;width:60%;border-radius:4px;background:#0075E3;transform-origin:left;animation:pscFattoB 5.5s linear forwards}@keyframes pscFattoB{from{transform:scaleX(1)}to{transform:scaleX(0)}}'
  + 'body.dark .psc-fatto-tel{border-color:#3F9FF4}';
  document.head.appendChild(st); })();
/* 0.9.381, Andrea: "Emoji e Sfondo troppo attaccati alla card della casa, e Sfondo troppo attaccato al tempo che passi a casa" */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.psc-casa-testa .psc-casa-l{margin-top:34px!important;margin-bottom:14px!important}.psc-casa-testa{margin-bottom:36px!important}'; document.head.appendChild(st); })();

/* ---------------------------------------------------------------------------------------
   0.9.381, Andrea: "quando l'utente aggiunge un luogo, voglio poter partire da un modello (il lavoro, la scuola o l'universita': nel
   90% dei casi uno dei due ce l'hanno tutti) oppure da zero. E come le card di Per te e del Dopamine Detox, i luoghi creati si devono
   poter eliminare (chi non va piu' a scuola) e riordinare". Telefono, computer e casa restano fissi in testa; i luoghi tuoi si spostano
   con le frecce e si tolgono con la ✕, dopo una conferma
   --------------------------------------------------------------------------------------- */
const PSC_MODELLI = [
  { k: 'lavoro', art: '💼', nome: 'Il lavoro', ore: '8', s: 'L’ufficio, il negozio, il cantiere' },
  { k: 'scuola', art: '🎓', nome: 'La scuola', ore: '6', s: 'La scuola o l’università, la biblioteca' }
];
function pscLuogoNuovo(){
  if (typeof inSheet !== 'function'){ pscLuogoApri(''); return; }
  pscVibra(6);
  inSheet('<div class="en-foglio psc-mod"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Un luogo nuovo</h3><p class="psc-mod-p">Parti da un modello o da zero.</p>'
    + PSC_MODELLI.map(function(m){ return '<button type="button" class="psc-mod-r" onclick="inSheetChiudi();pscLuogoDaModello(\'' + m.k + '\')"><span aria-hidden="true">' + m.art + '</span><div><b>' + m.nome + '</b><small>' + m.s + '</small></div></button>'; }).join('')
    + '<button type="button" class="psc-mod-r zero" onclick="inSheetChiudi();pscLuogoApri(\'\')"><span aria-hidden="true">✏️</span><div><b>Parto da zero</b><small>Un posto tutto tuo, con il nome che vuoi</small></div></button></div>');
}
function pscLuogoDaModello(k){
  const m = PSC_MODELLI.filter(function(x){ return x.k === k; })[0]; if (!m) return pscLuogoApri('');
  try{ localStorage.removeItem(PSC_BOZZA); }catch(_){ }
  pscLuogoApri('');
  const b = PSC.bozza; if (!b) return;
  b.nome = m.nome; b.ore = m.ore; b.unita = 'giorno'; b.art = m.art;
  pscLuogoPaint();
  try{ flModificato('s-ambiente'); }catch(_){ }
}
function pscAmbModo(on){ PSC.ambModo = !!on; pscVibra(6); pscRidisegna(); }
function pscLuogoSposta(id, dir){
  const l = pscLuoghi(), i = l.findIndex(function(x){ return x.id === id; }), j = i + dir;
  if (i < 0 || j < 0 || j >= l.length) return;
  const t = l[i]; l[i] = l[j]; l[j] = t;
  pscScriviLuoghi(l); pscVibra(6); pscRidisegna();
}
async function pscLuogoTogli(id){
  const x = pscLuoghi().filter(function(l){ return l.id === id; })[0]; if (!x) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Togliere "' + x.nome + '"?', 'Il luogo sparisce con la sua foto.', 'Togli', true); }catch(_){ }
  if (!ok) return;
  pscScriviLuoghi(pscLuoghi().filter(function(l){ return l.id !== id; }));
  if (x.img) pscImgVia(x.img);
  pscOrdTogli(PSC_AMB_ORD, 'l:' + id);
  pscToast('Luogo tolto');
  pscRidisegna();
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.psc-amb .psc-testa{display:flex;flex-direction:column;align-items:center;gap:10px}.psc-rio{border:0;border-radius:99px;padding:8px 14px;background:#0075E3;color:#fff;font:700 13px var(--font-body);cursor:pointer}'
  + '.psc-rio-p{margin:0 0 12px;text-align:center;font:500 13px var(--font-body);color:var(--muted)}'
  + '.psc-rio-w{position:relative;display:flex;flex-direction:column;gap:8px}.psc-rio-w .psc-card{pointer-events:none}'
  + '.psc-rio-c{display:flex;justify-content:center;gap:8px}.psc-rio-c button{width:38px;height:38px;border-radius:50%;border:1.5px solid var(--line);background:var(--card,#fff);color:var(--navy);font:800 16px var(--font-body);cursor:pointer}.psc-rio-c button.x{color:#E63946;border-color:#F5C2C7}.psc-rio-c button:disabled{opacity:.35}'
  + '.psc-mod{text-align:center}.psc-mod-p{margin:12px 0 18px;color:var(--muted);font:500 14px var(--font-body)}'
  + '.psc-mod-r{display:flex;align-items:center;gap:14px;width:100%;margin-top:10px;padding:14px 16px;border-radius:18px;border:1.5px solid var(--line);background:var(--card,#fff);text-align:left;font:inherit;color:var(--ink,#0E2350);cursor:pointer}'
  + '.psc-mod-r > span{font-size:28px;line-height:1}.psc-mod-r b{display:block;font:800 15.5px var(--font-display)}.psc-mod-r small{display:block;margin-top:3px;font:500 13px var(--font-body);color:var(--muted)}'
  + '.psc-mod-r.zero{border-style:dashed}';
  document.head.appendChild(st); })();
/* 0.9.382, Andrea: "la percentuale nel pannello Stai diventando (oggi e' il 54% di probabilita') e' troppo scura: te l'avevo detto
   azzurro chiaro, ben visibile". Il pannello e' scuro in tutti e due i temi: la percentuale e' sempre azzurro chiaro */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  'body:not(.fl-x) .psc-life .life-p strong.life-pct,body:not(.fl-x) .psc-life .life-pct.life-pct{color:#8CC6FF!important;font-weight:800}';
  document.head.appendChild(st); })();

/** 0.9.382: la lettura del Genio e' stata fatta (c'e' il risultato salvato). */
function pscLetturaFatta(){ return typeof pstLetturaFatta === 'function' ? pstLetturaFatta() : false; }

/* ===========================================================================================
   0.9.386 — L'ORDINE DELLE CARD, I TRE PUNTINI E LA LETTURA DEL GENIO CHE SI APRE DOPO DUE PASSAGGI
   =========================================================================================== */
const PSC_AMB_ORD = 'fl_ambiente_ordine';
const PSC_AZ_ORD = 'fl_azioni_ordine';
const PSC_X = '<svg viewBox="0 0 14 14" width="11" height="11" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" d="M2.5 2.5l9 9M11.5 2.5l-9 9"/></svg>';
const PSC_PUNTINI = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="12" cy="5" r="2" fill="currentColor"/><circle cx="12" cy="12" r="2" fill="currentColor"/><circle cx="12" cy="19" r="2" fill="currentColor"/></svg>';
const PSC_SPUNTA = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
const PSC_LUCCHETTO = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';

/** I tre puntini in alto a destra: aprono la modifica. In modifica diventano la spunta che la chiude. */
function pscKebabHtml(modo, azione, nome){
  return modo ? '<button type="button" class="psc-kebab fatto" aria-label="Fatto" onclick="' + azione + '">' + PSC_SPUNTA + '</button>'
    : '<button type="button" class="psc-kebab" aria-label="' + pstE(nome) + '" onclick="' + azione + '">' + PSC_PUNTINI + '</button>';
}
function pscAzModo(on){ PSC.azModo = !!on; pscVibra(6); pscRidisegna(); }
/** Le voci ({ ord }) nell'ordine salvato: quelle che l'ordine conosce al loro posto, le nuove dopo, nel loro ordine di serie. */
function pscOrdina(voci, ordine){
  const o = Array.isArray(ordine) ? ordine : [];
  return voci.map(function(v, i){ const p = o.indexOf(v.ord); return { v: v, i: i, p: p < 0 ? Infinity : p }; })
    .sort(function(a, b){ return a.p === b.p ? a.i - b.i : (a.p < b.p ? -1 : 1); })
    .map(function(x){ return x.v; });
}
function pscOrdTogli(k, ord){ try{ const o = pstJ(k, []); if (!Array.isArray(o)) return; const n = o.filter(function(x){ return x !== ord; }); if (n.length !== o.length) localStorage.setItem(k, JSON.stringify(n)); }catch(_){ } }
/** Salva l'ordine che si vede nella griglia; le voci che adesso non si vedono (le proposte di un altro periodo) restano in coda. */
function pscOrdSalva(grid){
  if (!grid) return;
  const k = grid.getAttribute('data-ord-grid') === 'amb' ? PSC_AMB_ORD : PSC_AZ_ORD;
  const vis = Array.prototype.map.call(grid.querySelectorAll(':scope > [data-ord]'), function(e){ return e.getAttribute('data-ord'); });
  const prima = pstJ(k, []);
  const n = vis.concat((Array.isArray(prima) ? prima : []).filter(function(x){ return vis.indexOf(x) < 0; })).slice(0, 120);
  try{ localStorage.setItem(k, JSON.stringify(n)); }catch(_){ }
}

/* TIENI PREMUTO E TRASCINA. Lo stesso gesto delle card "Scrivi al tuo Io futuro" e "Videochiama il tuo Io futuro" della scheda Sogno
   (cstTrascinabile, costruisci.js): dopo mezzo secondo la card si alza e vibra, segue il dito, le altre le fanno posto e la pagina
   scorre se la porti in alto o in basso. Qui l'ascolto e' uno solo, sul documento: il pannello si riscrive spesso e le card nuove
   funzionano da sole. Il tocco breve resta un tocco */
const PSC_DRAG = { el: null, grid: null, t: 0, x0: 0, y0: 0, dx: 0, dy: 0, x: 0, y: 0, raf: 0, fine: 0, sc: null };
function pscDragScroller(el){
  let p = el.parentElement;
  while (p && p !== document.body){ const o = getComputedStyle(p).overflowY; if ((o === 'auto' || o === 'scroll') && p.scrollHeight > p.clientHeight + 4) return p; p = p.parentElement; }
  return document.scrollingElement || document.documentElement;
}
function pscDragParti(){
  const el = PSC_DRAG.el; if (!el || !el.isConnected) return;
  PSC.drag = true;
  const r = el.getBoundingClientRect(); PSC_DRAG.dx = PSC_DRAG.x0 - r.left; PSC_DRAG.dy = PSC_DRAG.y0 - r.top;
  PSC_DRAG.x = PSC_DRAG.x0; PSC_DRAG.y = PSC_DRAG.y0;
  el.classList.add('psc-alzata');
  pscVibra(18);
  const sc = PSC_DRAG.sc = pscDragScroller(el);
  const giro = function(){
    if (!PSC.drag || PSC_DRAG.el !== el) return;
    const q = sc.getBoundingClientRect ? sc.getBoundingClientRect() : { top: 0, bottom: innerHeight };
    const alto = Math.max(q.top, 0) + 110, basso = Math.min(q.bottom, innerHeight) - 130;
    let v = 0;
    if (PSC_DRAG.y < alto) v = -Math.min(18, (alto - PSC_DRAG.y) / 5);
    else if (PSC_DRAG.y > basso) v = Math.min(18, (PSC_DRAG.y - basso) / 5);
    if (v){ const p0 = sc.scrollTop; sc.scrollTop += v; if (sc.scrollTop !== p0) pscDragSegui(PSC_DRAG.x, PSC_DRAG.y); }
    PSC_DRAG.raf = requestAnimationFrame(giro);
  };
  PSC_DRAG.raf = requestAnimationFrame(giro);
}
function pscDragSegui(x, y){
  const el = PSC_DRAG.el, grid = PSC_DRAG.grid; if (!el || !grid) return;
  PSC_DRAG.x = x; PSC_DRAG.y = y;
  el.style.transform = ''; el.style.pointerEvents = 'none';
  let b = null;
  (document.elementsFromPoint(x, y) || []).some(function(n){ const c = n.closest ? n.closest('[data-ord]') : null; if (c && c.parentElement === grid){ b = c; return true; } return false; });
  el.style.pointerEvents = '';
  if (b && b !== el){
    /* la card va al posto di quella sotto al dito: dopo, se la porti avanti; prima, se la porti indietro */
    const fr = Array.prototype.slice.call(grid.children), avanti = fr.indexOf(el) < fr.indexOf(b);
    grid.insertBefore(el, avanti ? b.nextSibling : b);
  }
  const r = el.getBoundingClientRect();
  el.style.transform = 'translate(' + (x - PSC_DRAG.dx - r.left) + 'px,' + (y - Math.min(PSC_DRAG.dy, 70) - r.top) + 'px) scale(1.04)';
}
function pscDragMuovi(e){
  const p = e.touches && e.touches[0]; if (!p) return;
  if (!PSC.drag){
    if (Math.abs(p.clientX - PSC_DRAG.x0) > 8 || Math.abs(p.clientY - PSC_DRAG.y0) > 8){ clearTimeout(PSC_DRAG.t); PSC_DRAG.el = null; document.removeEventListener('touchmove', pscDragMuovi); }
    return;
  }
  e.preventDefault();
  pscDragSegui(p.clientX, p.clientY);
}
function pscDragFine(){
  clearTimeout(PSC_DRAG.t);
  document.removeEventListener('touchmove', pscDragMuovi);
  const el = PSC_DRAG.el, grid = PSC_DRAG.grid;
  PSC_DRAG.el = null;
  if (!PSC.drag) return;
  PSC.drag = false; PSC_DRAG.fine = Date.now();
  cancelAnimationFrame(PSC_DRAG.raf);
  if (el){ el.classList.remove('psc-alzata'); el.style.transform = ''; }
  pscOrdSalva(grid);
  pscVibra(8);
  if (PSC.dragDopo){ PSC.dragDopo = false; pscRidisegna(); }
}
function pscDragPresa(t, x, y){
  if (!t || !t.closest || t.closest('.psc-ord-x,input,textarea,select')) return false;
  const el = t.closest('[data-ord]'), grid = el && el.parentElement;
  if (!el || !grid || !grid.hasAttribute('data-ord-grid')) return false;
  PSC_DRAG.el = el; PSC_DRAG.grid = grid; PSC_DRAG.x0 = x; PSC_DRAG.y0 = y;
  clearTimeout(PSC_DRAG.t); PSC_DRAG.t = setTimeout(pscDragParti, 480);
  return true;
}
if (typeof document !== 'undefined' && document.addEventListener){
  document.addEventListener('touchstart', function(e){
    if (!e.touches || e.touches.length !== 1) return;
    if (pscDragPresa(e.target, e.touches[0].clientX, e.touches[0].clientY)) document.addEventListener('touchmove', pscDragMuovi, { passive: false });
  }, { passive: true });
  document.addEventListener('touchend', pscDragFine, { passive: true });
  document.addEventListener('touchcancel', pscDragFine, { passive: true });
  /* col mouse (il gemello sul computer): stesso gesto */
  document.addEventListener('mousedown', function(e){ if (e.button === 0) pscDragPresa(e.target, e.clientX, e.clientY); });
  document.addEventListener('mousemove', function(e){
    if (PSC.drag){ pscDragSegui(e.clientX, e.clientY); return; }
    if (PSC_DRAG.el && (Math.abs(e.clientX - PSC_DRAG.x0) > 8 || Math.abs(e.clientY - PSC_DRAG.y0) > 8)){ clearTimeout(PSC_DRAG.t); PSC_DRAG.el = null; }
  });
  document.addEventListener('mouseup', pscDragFine);
  /* il tocco che chiude un trascinamento non apre la card */
  document.addEventListener('click', function(e){ if (Date.now() - PSC_DRAG.fine < 400 && e.target && e.target.closest && e.target.closest('[data-ord]')){ e.stopPropagation(); e.preventDefault(); } }, true);
  document.addEventListener('contextmenu', function(e){ if (e.target && e.target.closest && e.target.closest('[data-ord-grid] > [data-ord]')) e.preventDefault(); });
  /* tornando sulla casa (dalla pagina del telefono, dal sabotatore...) i passaggi della lettura si rileggono */
  document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-home' && !pscLetturaFatta()) setTimeout(pscRidisegna, 80); });
}

/* ---------------------------------------------------------------------------------------
   LA LETTURA DEL GENIO SI APRE DOPO DUE PASSAGGI (0.9.386). Andrea: "la lettura deve essere bloccata finche' l'utente non ha fatto i
   passaggi che le danno senso: mappare l'ambiente e la sfida del sabotatore invisibile. Sopra al pulsante, con il lucchetto, la lista
   dei passaggi con la grafica del Riscaldamento (riscaldamento.js: gruppi che si aprono, spunte); quando sono fatti tutti e due il
   lucchetto sparisce".
   - Mappa il tuo ambiente: hai risposto alle card della scheda Ambiente. Il telefono, il computer (se c'e'), la casa: i loro inneschi
     o le persone, o li hai salvati. Il lavoro (o la scuola): almeno un luogo tuo, di solito dal modello "Il lavoro".
   - Il sabotatore invisibile: fl_blocchi con il freno principale (blocchi.js). E' la stessa cosa che guarda la tappa della mappa
     (sentiero-mappa.js, nodo boss) e l'episodio (episodi.js): fatto da una parte, vale per tutte.
   letturaSbloccata() e' la funzione unica da usare dappertutto; letturaPassi() dice il dettaglio.
   --------------------------------------------------------------------------------------- */
function pscRisposto(o){
  if (!o || typeof o !== 'object') return false;
  const c = function(v){ return v != null && v !== ''; };
  return c(o.inneschi) || c(o.inneschiNo) || c(o.persone) || !!o.salvatoAt;
}
function pscSabotatoreFatto(){
  try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : pstJ('fl_blocchi', null); return !!(b && b.primario); }catch(_){ return false; }
}
/** I due passaggi prima della lettura del Genio, con le card dell'ambiente una per una. */
function letturaPassi(){
  const casa = pscCasa();
  const carte = [{ k: 'tel', t: 'Il telefono', s: 'Le app che ti ricordano il sogno e quelle che ti portano lontano.', fatto: pscRisposto(pscTel()), vai: 'pscTelApri()' }];
  if (pscPcVisibile()) carte.push({ k: 'pc', t: 'Il computer', s: 'Gli inneschi sul computer.', fatto: pscRisposto(pscPc()), vai: 'pscPcApri()' });
  carte.push({ k: 'casa', t: 'Casa', s: 'Chi c’è e cosa vedi, a casa.', fatto: pscRisposto(casa) || !!casa.at || !!casa.ssid, vai: 'pscCasaApri()' });
  carte.push({ k: 'lavoro', t: 'Il lavoro o la scuola', s: 'Dove passi le ore fuori casa.', fatto: pscLuoghi().length > 0, vai: 'pscLuogoNuovo()' });
  const amb = carte.every(function(x){ return x.fatto; });
  return { ambiente: { fatto: amb, carte: carte }, sabotatore: { fatto: pscSabotatoreFatto() } };
}
/** La lettura del Genio si puo' fare: l'ambiente e' mappato e la sfida del sabotatore invisibile e' fatta. */
function letturaSbloccata(){
  try{ const p = letturaPassi(); return !!(p.ambiente.fatto && p.sabotatore.fatto); }catch(_){ return false; }
}
function pscSblApri(k){
  let cur = PSC.sblAperto;
  if (!cur){ const p = letturaPassi(); cur = !p.ambiente.fatto ? 'amb' : (!p.sabotatore.fatto ? 'sab' : ''); }
  PSC.sblAperto = cur === k ? 'nessuno' : k;
  pscVibra(6); pscRidisegna();
}
function pscSabotatoreApri(){ if (typeof blocchiApri === 'function') blocchiApri(false); }
function pscSblHtml(p){
  let aperto = PSC.sblAperto;
  if (!aperto || (aperto !== 'amb' && aperto !== 'sab' && aperto !== 'nessuno')) aperto = !p.ambiente.fatto ? 'amb' : 'sab';
  const fatti = (p.ambiente.fatto ? 1 : 0) + (p.sabotatore.fatto ? 1 : 0);
  const spunta = function(ok){ return '<span class="rs-ico rs-check' + (ok ? ' on' : '') + '" aria-hidden="true">' + (ok ? PSC_SPUNTA : '') + '</span>'; };
  const gruppo = function(k, n, tit, conto, ok, dentro){
    const on = aperto === k;
    return '<div class="rs-g' + (on ? ' on' : '') + '"><button type="button" class="rs-gh" aria-expanded="' + on + '" onclick="pscSblApri(\'' + k + '\')">'
      + '<span class="rs-gn' + (ok ? ' ok' : '') + '">' + (ok ? PSC_SPUNTA : n) + '</span><b>' + tit + '</b><small>' + conto + '</small><span class="animated-plus"></span></button>'
      + '<div class="rs-gin">' + dentro + '</div></div>';
  };
  const c = p.ambiente.carte, cf = c.filter(function(x){ return x.fatto; }).length;
  const amb = c.map(function(x){
    return '<div class="rs-p' + (x.fatto ? ' ok' : '') + '">' + spunta(x.fatto) + '<div><b>' + pstE(x.t) + '</b>'
      + (x.fatto ? '' : '<small>' + pstE(x.s) + '</small><div class="rs-btns"><button type="button" class="rs-go" onclick="' + x.vai + '">Apri</button></div>') + '</div></div>';
  }).join('');
  const sabOk = p.sabotatore.fatto;
  const sab = '<div class="rs-p' + (sabOk ? ' ok' : '') + '">' + spunta(sabOk) + '<div><b>Il sabotatore invisibile</b>'
    + (sabOk ? '' : '<small>Qualche domanda veloce: scopri cosa ti frena davvero. Vale anche come tappa della mappa.</small><div class="rs-btns"><button type="button" class="rs-go" onclick="pscSabotatoreApri()">Inizia la sfida</button></div>') + '</div></div>';
  return '<div class="rs pst-sbl"><div class="rs-top"><div><small>Prima della lettura</small><b>' + fatti + ' di 2 fatti</b></div><div class="rs-bar"><i style="width:' + (fatti * 50) + '%"></i></div></div>'
    + gruppo('amb', 1, 'Mappa il tuo ambiente', cf + ' di ' + c.length, p.ambiente.fatto, amb)
    + gruppo('sab', 2, 'Fai la sfida del sabotatore invisibile', sabOk ? 'Fatto' : 'Da fare', sabOk, sab)
    + '</div>';
}
/** Il pannello della combinazione segreta prima della lettura (partita-stats.js, pstPaintIn): i passaggi e il pulsante con il lucchetto. */
function pscViaHtml(){
  const p = letturaPassi(), ok = p.ambiente.fatto && p.sabotatore.fatto;
  return '<div class="pst-via"><img src="img/genio/genio-pensa.png" alt=""><b>Trova la tua combinazione</b><p>Il Genio ti fa qualche domanda e ti dice quale dei tre numeri ti sta frenando.</p>'
    + (ok ? '' : pscSblHtml(p))
    + '<button type="button" class="pst-via-cta' + (ok ? '' : ' chiuso') + '"' + (ok ? '' : ' aria-disabled="true"') + ' onclick="pscLetturaVai()">' + (ok ? '' : PSC_LUCCHETTO) + '<span>Fai la lettura del Genio</span></button>'
    + (ok ? '' : '<small class="pst-via-n">Si apre quando hai fatto i due passaggi.</small>')
    + '</div>';
}
/** Il pulsante della lettura: se i passaggi sono fatti parte la lettura, se no apre il passaggio che manca. */
function pscLetturaVai(){
  if (letturaSbloccata()){ if (typeof orOpen === 'function') orOpen(); return; }
  const p = letturaPassi();
  PSC.sblAperto = !p.ambiente.fatto ? 'amb' : 'sab';
  pscVibra(10);
  pscToast('Prima fai i due passaggi qui sopra');
  pscRidisegna();
  try{ const a = document.getElementById('nvAai') || document.getElementById('pstBoxAai'); if (a && a.offsetParent) a.scrollIntoView({ behavior: 'smooth', block: 'start' }); }catch(_){ }
}

(function(){ if (typeof document === 'undefined' || !document.head) return; const st = document.createElement('style'); st.textContent = [
  /* i tre puntini sulla riga del titolo della scheda, tutto a destra */
  '.psc-testa-k{position:relative}.psc-testa-k > p{padding:0 46px}',
  '.psc-kebab{position:absolute;top:-6px;right:0;width:36px;height:36px;border:0;border-radius:18px;background:rgba(255,255,255,.1);color:#C8EFFD;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
  '.psc-kebab.fatto{background:#0075E3;color:#fff}',
  '.psc-modo-p{margin:0 0 18px;text-align:center;font:600 13px/1.45 var(--font-body);color:rgba(200,239,253,.78)}',
  /* le card che si spostano */
  '.psc-ord{position:relative;display:flex;min-width:0;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}.psc-ord > .psc-card{flex:1;min-width:0}',
  '.psc-ord.modo > .psc-card,.psc-ord.modo > .psc-azc-b{outline:1.5px dashed rgba(140,198,255,.6);outline-offset:3px}',
  '.psc-ord-x{position:absolute;top:-8px;right:-8px;z-index:3;width:30px;height:30px;border-radius:15px;border:2px solid #001E44;background:#E63946;color:#fff;display:flex;align-items:center;justify-content:center;padding:0;cursor:pointer}',
  '.psc-alzata{z-index:30;transition:none!important}.psc-alzata > .psc-card,.psc-alzata > .psc-azc-b{box-shadow:0 18px 40px rgba(0,0,0,.45)}',
  /* il testo di attesa non tocca le card */
  '.psc-az-attesa{margin:0 0 22px!important}',
  /* la pagina del telefono: le due schede. 0.9.388 (BUG-110): le linguette di Il tuo viaggio (.pst-tabs/.nvp-tab/.nvp-pos, rotta-tab.js),
     qui solo i colori della pagina chiara: testo blu notte, la scelta in blu con l'icona nel pallino, la barretta blu che scorre */
  /* la pagina larga quanto lo schermo: con margin:auto in una .screen a colonna la pagina prendeva la larghezza della riga piu' lunga
     senza a capo (le schede) e usciva di 20 px a destra (si vede anche nelle foto di Andrea del 22/11) */
  '#pscTelBody{width:100%}',
  /* due schede sole: si dividono la riga a meta' (niente scorrimento, niente parole tagliate), la barretta e' larga quanto la scheda */
  '.psc-tel-tabs{margin:26px -20px 0;padding:0;border-bottom:1px solid var(--line)}body.dark .psc-tel-tabs{border-bottom-color:rgba(255,255,255,.12)}',
  '.psc-tel-tabs .nvp-tabs-in{width:100%;margin:0}',
  '.psc-tel-tabs .nvp-tab{flex:1 1 0;min-width:0;justify-content:center;color:var(--navy);opacity:.62;font-size:12px;letter-spacing:.04em;padding:12px 4px 14px;transition:opacity .25s ease-in-out,color .25s ease-in-out}.psc-tel-tabs .nvp-tab.on{opacity:1;color:#0075E3}.psc-tel-tabs .nvp-tab.on::after{display:none}',
  '.psc-tel-tabs .nvp-em{background:#0075E3;color:#fff}.psc-tel-tabs .nvp-em svg{width:13px;height:13px}',
  'body.dark .psc-tel-tabs .nvp-tab{color:#fff}body.dark .psc-tel-tabs .nvp-tab.on{color:#8CC6FF}body.dark .psc-tel-tabs .nvp-pos{background:#8CC6FF}body.dark .psc-tel-tabs .nvp-em{background:#8CC6FF;color:#001E44}',
  '.psc-tel-pan{display:flex;flex-direction:column;margin-top:22px}.psc-tel-pan .psc-fonti{margin-top:0}',
  '.psc-fonti button{display:inline-flex;align-items:center;gap:7px}',
  '.psc-tel-sw{margin-top:22px}',
  '.psc-tel-n{margin:22px 6px 0;text-align:center;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
  '.psc-tel-ok{margin-top:22px}.psc-tel-ok.spento{opacity:.5}',
  '.psc-tel-at{display:block;margin-top:10px;text-align:center;font:600 12px var(--font-body);color:var(--muted)}',
  '.psc-tel-schermo{position:relative;overflow:hidden}.psc-tel-schermo.frase p{position:relative;margin:0 12px;font:italic 600 12px/1.4 Georgia,serif;color:#fff;text-align:center}',
  /* i passaggi prima della lettura: la grafica del Riscaldamento, nei colori del pannello scuro */
  '.pst-sbl{margin:2px 0 22px;text-align:left;background:rgba(255,255,255,.06)!important;border-color:rgba(140,198,255,.2)!important}',
  '.pst-via .pst-sbl .rs-top b{font:800 18px/1.25 var(--font-display)}.pst-via .pst-sbl .rs-gh b{display:block;font:800 14.5px/1.3 var(--font-body)}.pst-via .pst-sbl .rs-p b{display:block;font:700 14px/1.35 var(--font-body)}',
  '.pst-sbl .rs-top small{color:#8CC6FF}.pst-sbl .rs-top b{color:#fff}.pst-sbl .rs-bar{background:rgba(255,255,255,.1)}',
  '.pst-sbl .rs-g{border-color:rgba(140,198,255,.2)}.pst-sbl .rs-gh{color:#fff}.pst-sbl .rs-gh b{font-weight:800}.pst-sbl .rs-gh small{color:rgba(200,239,253,.72)}.pst-sbl .animated-plus{color:#8CC6FF}',
  '.pst-sbl .rs-gn{background:rgba(140,198,255,.18);color:#C8EFFD}.pst-sbl .rs-gn.ok{background:#1B9E6A;color:#fff}',
  '.pst-sbl .rs-gin{border-top-color:rgba(140,198,255,.2)}.pst-sbl .rs-p{border-bottom-color:rgba(140,198,255,.14)}',
  '.pst-sbl .rs-p b{color:#fff}.pst-sbl .rs-p small{color:rgba(200,239,253,.72)}.pst-sbl .rs-p.ok{opacity:.75}.pst-sbl .rs-p.ok b{color:rgba(200,239,253,.75)}',
  '.pst-sbl .rs-ico.rs-check{width:28px;height:28px;border-radius:9px;margin-top:1px;background:transparent;border:2px solid rgba(140,198,255,.45);cursor:default}.pst-sbl .rs-ico.rs-check.on{background:#1B9E6A;border-color:#1B9E6A;color:#fff}',
  /* il pulsante con il lucchetto */
  '.pst-via-cta{display:flex!important;align-items:center;justify-content:center;gap:10px}',
  '.pst-via-cta.chiuso{background:rgba(255,255,255,.14);color:rgba(255,255,255,.78);box-shadow:inset 0 0 0 1.5px rgba(255,255,255,.22)}',
  '.pst-via-n{display:block;margin-top:12px;font:600 12.5px/1.4 var(--font-body);color:rgba(200,239,253,.72)}'
].join(''); document.head.appendChild(st); })();

/* 0.9.401 BUG-192: le card delle abitudini misurate, il carosello "una alla volta", il foglio dei tre puntini, "Aggiungi un'abitudine" */
(function(){ if (typeof document === 'undefined' || !document.head) return; const st = document.createElement('style'); st.textContent = [
  /* il pannello della combinazione e' scuro nei due temi: colori chiari fissi */
  '.psc-azc-b b{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}',
  '.psc-azc-b i.psc-azc-v{font:800 16px/1.2 var(--font-display);font-style:normal;color:#fff}.psc-azc-b i.psc-azc-v span{font:600 12px var(--font-body);color:rgba(200,239,253,.7)}',
  '.psc-azc-b i.psc-azc-v.cambia{color:#FF8A93}.psc-azc-b i.psc-azc-v.tieni{color:#8CC6FF}',
  '.psc-azc-b i.psc-azc-v.manca,.psc-azc-b i.psc-azc-v.attesa{font:600 12.5px/1.3 var(--font-body);color:rgba(200,239,253,.62)}',
  '.psc-azc-mis{display:inline-flex;align-items:center;gap:5px;margin-top:8px;padding:4px 10px;border-radius:99px;white-space:nowrap;font:700 11px var(--font-body);font-style:normal;color:rgba(200,239,253,.78);box-shadow:inset 0 0 0 1px rgba(140,198,255,.3)}.psc-azc-mis svg{flex:none}',
  /* colore solo dove c'e' un dato: una misurata senza dati e' sbiadita */
  '.psc-azc.mis:has(.psc-azc-v.manca) .psc-azc-e,.psc-azc.mis:has(.psc-azc-v.attesa) .psc-azc-e{filter:grayscale(1);opacity:.6}',
  /* una alla volta: il carosello con i pallini */
  '.psc-car-w{margin:0 -4px}',
  '.psc-car{display:flex;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:4px 0}.psc-car::-webkit-scrollbar{display:none}',
  '.psc-car-s{flex:0 0 100%;min-width:0;box-sizing:border-box;scroll-snap-align:center;scroll-snap-stop:always;padding:0 4px;display:flex}.psc-car-s > *{flex:1;min-width:0}',
  '.psc-car-s .psc-card{min-height:260px}.psc-car-s .psc-azc-b{min-height:230px;justify-content:center;padding:26px 18px 20px}.psc-car-s .psc-azc-piu,.psc-car-s .psc-card-piu{min-height:230px}',
  '.psc-car-s .psc-azc-e{width:64px;height:64px;border-radius:32px;font-size:32px}.psc-car-s .psc-azc-b b{font-size:18px}',
  '.psc-car-dots{display:flex;justify-content:center;flex-wrap:wrap;gap:8px;margin:16px 0 0}.psc-car-dots i{flex:none;width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.25);transition:background .2s,transform .2s}.psc-car-dots i.on{background:#8CC6FF;transform:scale(1.25)}',
  /* il foglio dei tre puntini */
  '.psc-menu{text-align:center}',
  '.psc-menu-k{margin:26px 0 14px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}',
  '.psc-lay{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
  '.psc-lay-b{display:flex;flex-direction:column;align-items:center;gap:10px;padding:18px 10px 16px;border-radius:18px;border:1.5px solid var(--line);background:var(--card);color:var(--navy);font:inherit;cursor:pointer}',
  '.psc-lay-b svg{color:#9DB4D3}.psc-lay-b.fl-sel svg{color:#0075E3}body.dark .psc-lay-b.fl-sel svg{color:#8CC6FF}.psc-lay-b b{font:800 14px var(--font-body)}',
  '.psc-menu-l{display:flex;flex-direction:column;gap:10px;margin:30px 0 8px}',
  '.psc-menu-r{display:flex;align-items:center;gap:14px;width:100%;padding:14px 16px;border-radius:18px;border:1.5px solid var(--line);background:var(--card);text-align:left;font:inherit;color:var(--navy);cursor:pointer}',
  '.psc-menu-r > span{flex:none;font-size:24px;line-height:1}.psc-menu-r b{display:block;font:800 15.5px var(--font-display)}.psc-menu-r small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}.psc-menu-r.spenta{opacity:.55}',
  /* il foglio di un'abitudine misurata */
  '.psc-abf{text-align:center}.psc-abf h3{margin-bottom:0!important}',
  '.psc-abf-n{margin:18px 0 0;font:900 42px/1 var(--font-display);color:var(--navy)}.psc-abf-n small{font:700 15px var(--font-body);color:var(--muted)}.psc-abf-n.cambia{color:#E63946}.psc-abf-n.tieni{color:#0075E3}body.dark .psc-abf-n.tieni{color:#8CC6FF}body.dark .psc-abf-n.cambia{color:#FF8A93}',
  '.psc-abf-p{margin:20px auto 0;max-width:30ch;font:500 15px/1.5 var(--font-body);color:var(--muted)}',
  '.psc-abf-m{display:flex;align-items:flex-start;gap:10px;margin:28px auto 32px;max-width:32ch;padding:14px 16px;border-radius:16px;background:var(--fl-sel-sfondo);font:600 13.5px/1.45 var(--font-body);color:var(--navy);text-align:left}.psc-abf-m svg{flex:none;width:18px;height:18px;margin-top:1px;color:#0075E3}body.dark .psc-abf-m svg{color:#8CC6FF}',
  /* Aggiungi un'abitudine: l'emoji scelta in alto, la casella che cresce, il selettore condiviso delle emoji */
  '.psc-azf-e{display:flex;align-items:center;justify-content:center;width:68px;height:68px;margin:6px auto 0;border-radius:34px;background:var(--fl-sel-sfondo);background-size:cover;background-position:center;font-size:36px;line-height:1}',
  '.psc-azf .psc-lab{margin:28px 0 12px}.psc-lab .psc-nw{white-space:nowrap}.psc-azf-i{margin-left:6px!important;color:#0075E3!important}body.dark .psc-azf-i{color:#8CC6FF!important}',
  '.psc-azt{display:block;width:100%;box-sizing:border-box;min-height:112px;resize:vertical;padding:14px 16px;font:500 16px/1.45 var(--font-body);border-radius:16px}',
  '.psc-azf .sci-griglia{margin-top:2px}'
].join(''); document.head.appendChild(st); })();

/* 0.9.401 BUG-206: il passo di "Chi devi diventare" e' un pulsante (apre le due strade); il foglio con il perche' */
(function(){ if (typeof document === 'undefined' || !document.head) return; const st = document.createElement('style'); st.textContent = [
  '.psc-capo-b{display:flex;flex-direction:column;align-items:center;width:100%;box-sizing:border-box;border:0;font:inherit;cursor:pointer;box-shadow:inset 0 0 0 1.5px rgba(140,198,255,.28)}.psc-capo-b:active{transform:scale(.98)}',
  '.psc-capo-b p{margin:0 0 10px!important}.psc-capo-b b{display:block}',
  '.psc-capo-go{display:inline-flex;align-items:center;gap:4px;margin-top:14px;font:700 13.5px var(--font-body);font-style:normal;color:#8CC6FF}',
  '.psc-passo h3{margin-bottom:0!important}.psc-passo-p{margin:16px auto 26px!important;max-width:32ch;font:500 15px/1.5 var(--font-body)!important;color:var(--muted)!important}',
  '.psc-passo .psc-mod-r + .psc-mod-r{margin-top:12px}'
].join(''); document.head.appendChild(st); })();
