/* ===========================================================================================
   LIVELLI — l'anello intorno al ritratto, come il profilo di Skool.

   I punti vengono da ciò che l'app misura davvero: i blocchi scattati, i giorni di fila della
   Modalità severa, i minuti di FullFocus portati a termine, le sfide completate e gli alberi
   piantati. Ogni livello sblocca qualcosa di concreto (un suono di FullFocus, una durata più
   lunga, un anello diverso, una pianta rara): l'elenco è in LV_LEVELS ed è quello che il
   resto dell'app consulta (lvHas('sound:wind'), lvMaxMinutes()).
   =========================================================================================== */

/* ------------------------------------------------------------------ la scala (0.9.397)

   Andrea: "i livelli 2, 3, 4 e 5 si chiamano tutti Seme; ogni livello deve avere un nome suo, come i gradi di Call of
   Duty, con un emblema al posto delle emoji, e all'inizio si deve salire in fretta e poi sempre piu' piano".

   I PUNTI DI UNA GIORNATA. Chi usa l'app bene, tutti i giorni, fa circa 60 punti: il piano di domani (12), la
   Modalita' severa accesa (8 al giorno di fila), una tappa della mappa (15-25, SD_XP in sentiero-mappa.js) e una
   sessione di Full Focus da 25 minuti un giorno si' e uno no (25 + 20, la meta' al giorno). Chi fa Full Focus ogni
   giorno, ascolta il mantra e fa due tappe arriva verso i 110. Sopra a tutto, una volta sola, le sfide (1.960 punti
   in tutto, i primi 60 il primo giorno).

   LA CURVA. A 60 punti al giorno: livello 2 il primo giorno, livello 5 in sei giorni, livello 10 in un mese, livello
   50 in circa un anno. I primi nove gradini sono scritti a mano (da 30 a 360 punti l'uno); dal decimo il costo cresce
   piano, da 380 a circa 730 punti, cioe' da sei giorni a dodici per gradino.
   La scala di prima (40.000 punti per ciclo, esponente 1,8) chiedeva 1.894 punti per il livello 10 e 16.700 per il
   30: a 60 punti al giorno il livello 30 arrivava dopo nove mesi e il 50 dopo quasi due anni, e il livello 50 non si
   vedeva mai (era lo stesso punto del prestigio).

   NESSUNO SCENDE. Ogni gradino della scala nuova costa meno o uguale a quello di prima, e il ciclo intero (con il
   livello 50 che adesso dura un gradino vero) costa meno di 40.000: con gli stessi punti si e' allo stesso livello o
   piu' su, e non si perde una stella del prestigio. Il controllo e' in tools/test-livelli-397.js.

   Al cinquantesimo si ricomincia da uno con una stella in piu' (il prestigio), e le stelle sono venti. */

const LV_PER_CICLO = 50;
const LV_PRESTIGI = 20;
/* il costo per salire dal livello n al livello n+1: i primi nove a mano, poi la formula */
const LV_COSTI_INIZIO = [30, 70, 120, 180, 200, 220, 260, 320, 360];
function lvCosto(n){
  if (n <= LV_COSTI_INIZIO.length) return LV_COSTI_INIZIO[n - 1];
  const j = n - 10;
  return Math.round((380 + 5 * j + 0.1 * j * j) / 5) * 5;
}

/* Dieci famiglie da cinque gradi: il nome cambia a ogni livello, la famiglia decide la forma dell'emblema e il grado le
   stelle sul nastro. Il viaggio va dal seme al sogno: crescere, mettersi in cammino, leggere la mappa, prendere il
   largo, salire, volare, orientarsi con le stelle, guidare gli altri, diventare una leggenda, costruire il sogno. */
const LV_FAMIGLIE = [
  { nome: 'Il seme',        nomi: ['Seme', 'Radice', 'Germoglio', 'Stelo', 'Bocciolo'] },
  { nome: 'Il sentiero',    nomi: ['Viandante', 'Camminatore', 'Escursionista', 'Battistrada', 'Apripista'] },
  { nome: 'La mappa',       nomi: ['Segnavia', 'Tracciatore', 'Cartografo', 'Esploratore', 'Pioniere'] },
  { nome: 'Il mare aperto', nomi: ['Mozzo', 'Marinaio', 'Timoniere', 'Nostromo', 'Capitano'] },
  { nome: 'La vetta',       nomi: ['Scalatore', 'Rocciatore', 'Alpinista', 'Capocordata', 'Conquistatore'] },
  { nome: 'Il volo',        nomi: ['Pilota', 'Aviatore', 'Asso', 'Caposquadriglia', 'Comandante'] },
  { nome: 'Le stelle',      nomi: ['Osservatore', 'Astronomo', 'Navigatore stellare', 'Astronauta', 'Cosmonauta'] },
  { nome: 'La guida',       nomi: ['Guardiano', 'Custode', 'Mentore', 'Maestro', 'Stratega'] },
  { nome: 'La leggenda',    nomi: ['Eroe', 'Campione', 'Leggenda', 'Mito', 'Titano'] },
  { nome: 'Il sogno',       nomi: ['Visionario', 'Costruttore', 'Architetto', 'Creatore', 'Sognatore'] }
];

/* I premi: solo cose che esistono gia' nell'app (i suoni del Full Focus, le durate, le cornici intorno alla foto, la
   stella rara, le due caselle chiuse del mercato del negozio) piu' l'emblema nuovo di ogni famiglia. Quasi uno a
   gradino fino al 10, poi piu' radi. Ogni premio arriva allo stesso livello di prima o prima: chi l'aveva lo tiene.
   Pioggia, Onde del mare e Temporale sono gia' liberi dal primo livello. */
const LV_PREMI = {
  1:  { perk: 'I suoni Pioggia, Onde del mare e Temporale in Full Focus', grants: ['sound:rain', 'sound:ocean', 'sound:white'] },
  2:  { perk: 'Il suono Vento in Full Focus', grants: ['sound:wind'] },
  3:  { perk: 'La cornice d’argento intorno alla tua foto', grants: ['ring:silver'] },
  4:  { perk: 'Il suono Camino in Full Focus', grants: ['sound:fire'] },
  5:  { perk: 'Sessioni di Full Focus fino a 120 minuti', grants: ['minutes:120'] },
  6:  { perk: 'L’emblema del Sentiero e i suoni Ruscello e Notte d’estate', grants: ['sound:night'] },
  7:  { perk: 'La quinta casella del mercato, nel negozio', grants: ['mercato:5'] },
  8:  { perk: 'La stella rara in Full Focus', grants: ['plant:rare'] },
  9:  { perk: 'La sesta casella del mercato, nel negozio', grants: ['mercato:6'] },
  10: { perk: 'Il suono Bosco in Full Focus', grants: ['sound:cafe'] },
  11: { perk: 'L’emblema della Mappa: lo scudo', grants: [] },
  15: { perk: 'La cornice d’oro intorno alla tua foto', grants: ['ring:gold'] },
  16: { perk: 'L’emblema del Mare aperto, con il bordo d’argento', grants: [] },
  20: { perk: 'Sessioni di Full Focus fino a 180 minuti', grants: ['minutes:180'] },
  21: { perk: 'L’emblema della Vetta', grants: [] },
  26: { perk: 'L’emblema del Volo, con le ali', grants: [] },
  30: { perk: 'La cornice arcobaleno intorno alla tua foto', grants: ['ring:rainbow'] },
  31: { perk: 'L’emblema delle Stelle, con il bordo d’oro', grants: [] },
  36: { perk: 'L’emblema della Guida, con l’alloro', grants: [] },
  40: { perk: 'La cornice animata intorno alla tua foto', grants: ['ring:animated'] },
  41: { perk: 'L’emblema della Leggenda, con l’alloro e le ali', grants: [] },
  /* title:sognatore c'era gia' al 46: nessuno lo legge, ma chi ce l'aveva lo tiene */
  46: { perk: 'L’emblema del Sogno, con i raggi', grants: ['title:sognatore'] },
  50: { perk: 'L’emblema completo del Sognatore', grants: [] }
};

/* Una frase per livello: dice cosa e' cambiato a quel gradino, con il «tu». La prima la vede chi ricomincia dal
   livello 1 con una stella (il livello 1 non si festeggia mai la prima volta). */
const LV_FRASE_PRESTIGIO = 'Ricominci dal livello 1 con una stella in più: il giro che hai chiuso resta tuo.';
const LV_FRASI = [
  'Il tuo sogno è scritto: adesso ha un posto dove crescere.',
  'Le prime radici: hai fatto il passo che quasi tutti rimandano.',
  'La tua rotta adesso ha un primo tratto segnato, non solo una destinazione.',
  'Il tuo telefono comincia a lavorare per il tuo sogno, non contro.',
  'La concentrazione per te non è più un esperimento: sta per aprirsi.',
  'Hai lasciato il punto di partenza: adesso sei per strada, non alla finestra.',
  'Quello che scrivi la sera nel piano di domani, adesso lo fai davvero.',
  'La tua giornata comincia dall’unica cosa, non dalle notifiche.',
  'Tieni il passo anche nei giorni senza voglia: è così che si apre una strada.',
  'La tua costanza adesso pesa più della voglia del giorno.',
  'Domani non riparti da zero: la strada che hai segnato è ancora lì.',
  'Arrivi al Full Focus con una cosa sola in testa, e si vede da quanto dura.',
  'La tua mappa ha più giorni scritti con un piano che giorni lasciati al caso.',
  'Quando la giornata va storta, sai qual è il passo minimo per non perderla.',
  'Sei arrivato dove quasi tutti smettono: da qui la strada la apri tu.',
  'Hai preso il largo: il porto delle scuse resta alle tue spalle.',
  'Il tempo che finiva nello scroll adesso ha un nome nel tuo piano.',
  'Il timone lo tieni tu: la Modalità severa è una scelta tua, non una punizione.',
  'Le tue regole reggono anche nei giorni in cui non hai voglia di rispettarle.',
  'La rotta la decidi tu, e il mare mosso non ti fa tornare indietro.',
  'Comincia la salita: ogni gradino adesso costa di più, e vale di più.',
  'Le tue sessioni portate a termine sono più di quelle interrotte.',
  'Il tuo piano di domani lo scrivi in due minuti, perché sai cosa conta.',
  'La tua settimana ha un ritmo che riconosci anche senza guardare l’app.',
  'Metà del ciclo: venticinque livelli saliti un giorno alla volta.',
  'Scegli cosa non fare con la stessa cura con cui scegli cosa fare.',
  'Le distrazioni ti rubano meno tempo, perché le vedi arrivare prima.',
  'I tuoi giorni migliori non sono più un caso: sai come ripeterli.',
  'Chi ti guarda vede una persona costante, e ha ragione.',
  'Trenta livelli: mesi di lavoro vero dietro a un numero solo.',
  'Alzi lo sguardo e il tuo sogno non è più un puntino lontano: ha una data stimata.',
  'Il tuo Full Focus parte prima che arrivi la voglia di rimandare.',
  'Le tue giornate storte durano un giorno, non una settimana.',
  'Il tuo piano non ha più bisogno di promemoria: ci pensi tu.',
  'Sei uscito dalle buone intenzioni: qui contano solo i giorni fatti.',
  'Quello che sai fare adesso puoi insegnarlo a un amico, dal primo blocco.',
  'Le tue regole non le rinegozi più ogni mattina.',
  'Il tempo che hai protetto in questi mesi vale più di una giornata perfetta.',
  'Chi parte oggi da zero guarda il tuo numero per capire che si può.',
  'Per te la concentrazione è il modo normale di lavorare, non l’eccezione.',
  'Per arrivare qui sono servite centinaia di sere con il piano già scritto.',
  'Vinci anche le partite che una volta davi per perse.',
  'Le scuse che ti fermavano un anno fa oggi non le riconosci più.',
  'Quello che hai costruito non dipende più dalla voglia del giorno.',
  'Cinque gradini alla fine del ciclo, e la stella si vede già.',
  'Il sogno che avevi scritto il primo giorno adesso ha una forma che si può toccare.',
  'La tua rotta è quasi tutta disegnata dai passi che hai già fatto.',
  'Chi guarda il tuo profilo vede mesi di lavoro, non un colpo di fortuna.',
  'Un livello alla fine del ciclo: il prossimo ti porta una stella.',
  'Hai chiuso il ciclo. Ancora un tratto e ricominci con una stella, e il conto resta.'
];

/* La scala intera, quella che il resto dell'app consulta (lvHas('sound:wind'), lvMaxMinutes(), lvLevelFor()). */
const LV_LEVELS = (function(){
  const out = [];
  let xp = 0;
  for (let n = 1; n <= LV_PER_CICLO; n++){
    const f = LV_FAMIGLIE[Math.floor((n - 1) / 5)];
    const pr = LV_PREMI[n] || null;
    out.push({ n: n, xp: xp, name: f.nomi[(n - 1) % 5], perk: pr ? pr.perk : '', grants: pr ? pr.grants.slice() : [] });
    xp += lvCosto(n);
  }
  return out;
})();
/* Il ciclo finisce un gradino DOPO il livello 50: il cinquantesimo si vede, e dura quanto gli altri. */
const LV_XP_CICLO = LV_LEVELS[LV_PER_CICLO - 1].xp + lvCosto(LV_PER_CICLO);

/* ---------------------------------------------------------------------------------------
   L'EMBLEMA: uno per livello, disegnato qui. La famiglia sceglie la forma e il metallo, il grado le stelle sul
   nastro. Salendo si aggiunge sempre qualcosa e non si toglie niente:
     Il seme e Il sentiero: la medaglia tonda (bronzo); La mappa, Il mare aperto e La vetta: lo scudo (argento dal mare);
     Il volo e Le stelle: lo scudo con le ali (oro dalle stelle); La guida, La leggenda e Il sogno: la rosetta d'oro,
     con l'alloro, poi le ali, poi i raggi.
   --------------------------------------------------------------------------------------- */
/* 0.9.400 BUG-179, Andrea: "l'emblema del livello verde con le stelline gialle non c'entra con il brand" (lezione 269). I colori sono
   quelli del brand: i blu, l'azzurro e il bianco; l'oro solo come accento, dalle Stelle in su (era gia' il bordo d'oro dei premi).
   Niente verde e niente giallo: l'alloro e' azzurro, le stelle del grado sono bianche (d'oro dalle Stelle in su). */
const LV_EM_STILE = [
  { a: '#5BB2FF', b: '#0B5FB8', bordo: '#D6E8FF', forma: 'tondo' },
  { a: '#3F9FF4', b: '#004A99', bordo: '#BCE0FF', forma: 'tondo', doppio: true },
  { a: '#2F86E8', b: '#00306B', bordo: '#E4F1FF', forma: 'scudo' },
  { a: '#1F6FD1', b: '#001E44', bordo: '#FFFFFF', forma: 'scudo' },
  { a: '#6FA8E8', b: '#163A6E', bordo: '#F0F6FF', forma: 'scudo', doppio: true },
  { a: '#5EC8F2', b: '#0B4C9C', bordo: '#FFFFFF', forma: 'scudo', ali: true },
  { a: '#22407F', b: '#000F2B', bordo: '#F5B301', forma: 'scudo', ali: true, gemma: true, oro: true },
  { a: '#0B84FF', b: '#003A80', bordo: '#F5B301', forma: 'rosetta', alloro: true, oro: true },
  { a: '#123A70', b: '#000A1F', bordo: '#F5B301', forma: 'rosetta', alloro: true, ali: true, oro: true },
  { a: '#0075E3', b: '#001E44', bordo: '#F5B301', forma: 'rosetta', alloro: true, ali: true, raggi: true, gemma: true, oro: true }
];
/* 0.9.400 BUG-179, Andrea: "emblemi vari, come in Call of Duty: tanti stemmi diversi, mai lo stesso ripetuto" (lezione 251). Il segno
   al centro e' diverso a ogni livello: nei livelli dispari un disegno (gradi, scudi, ali, corone...), nei pari un'emoji nei colori
   del brand. La famiglia sceglie la forma e i colori, il grado le stelle sul nastro. */
const LV_EM_SEGNI = [
  'germoglio', '💧', 'gallone1', '🔹', 'diamante', '🌀', 'sentiero', '🧭', 'gallone2', '🦋',
  'bussola', '🌐', 'gallone3', '💠', 'scudo', '🐬', 'ancora', '🌊', 'onda', '🐳',
  'monte', '🗻', 'bandiera', '🧊', 'fulmine', '❄️', 'volo', '✈️', 'ali', '🕊️',
  'stella', '🛰️', 'luna', '🚀', 'cometa', '🌌', 'faro', '🔮', 'chiave', '🛡️',
  'spade', '⚔️', 'corona', '🔱', 'tridente', '💎', 'gemma', '🧿', 'polare', '🌠'
];
let LV_EM_ID = 0;
function lvEmStella(cx, cy, r, ri, punte){
  const p = []; const k = punte || 5;
  for (let i = 0; i < k * 2; i++){ const a = -Math.PI / 2 + i * Math.PI / k, rr = i % 2 ? (ri || r * 0.45) : r; p.push((cx + Math.cos(a) * rr).toFixed(1) + ' ' + (cy + Math.sin(a) * rr).toFixed(1)); }
  return 'M' + p.join(' L') + 'Z';
}
function lvEmGlifo(g, st){
  const W = 'fill="#FFFFFF"', S = 'fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"';
  const scuro = (st && st.b) || '#001E44';
  const G = function(w){ return 'fill="none" stroke="#FFFFFF" stroke-width="' + w + '" stroke-linecap="round" stroke-linejoin="round"'; };
  const ala = 'M48 45C41 36 31 34 26 37C30 39 32 41 33 44C29 44 27 47 27 50C32 48 36 49 39 51C37 53 37 56 38 59C43 55 46 51 48 45Z';
  switch (g){
    case 'germoglio': return '<path ' + S + ' d="M50 60V42M41 60H59"/><path ' + W + ' d="M50 48C42 48 37 42 37 35C45 35 50 40 50 48Z"/><path ' + W + ' d="M50 43C58 43 63 37 63 30C55 30 50 35 50 43Z"/>';
    case 'sentiero': return '<path ' + S + ' stroke-dasharray="5 4" d="M41 62C41 52 59 51 57 42C56 36 46 37 50 30"/><path ' + W + ' d="M50 30V18L60 21.5L50 25Z"/>';
    case 'bussola': return '<circle cx="50" cy="44" r="15" ' + S + '/><path ' + W + ' d="M50 28L55 44L50 60L45 44Z"/><circle cx="50" cy="44" r="2.4" fill="' + scuro + '"/>';
    case 'ancora': return '<circle cx="50" cy="29" r="4" ' + S + '/><path ' + S + ' d="M50 33V60M42 40H58M36 50C38 59 47 61 50 61C53 61 62 59 64 50"/>';
    case 'monte': return '<path ' + W + ' d="M32 60L46 36L53 47L57 41L68 60Z"/><path fill="' + scuro + '" d="M46 36L50.5 43.5L47 42L43.6 40Z"/>';
    case 'volo': return '<path ' + W + ' d="M33 47L67 31L55 61L49.5 50Z"/><path fill="' + scuro + '" d="M49.5 50L67 31L52 52Z"/>';
    case 'stella': return '<path ' + W + ' d="' + lvEmStella(50, 45, 16, 7) + '"/>';
    case 'faro': return '<path ' + W + ' d="M45 61L47 37H53L55 61Z"/><rect x="45.5" y="30" width="9" height="6" rx="1.5" ' + W + '/><path ' + S + ' stroke-width="2.6" d="M41 31L34 28M41 35L34 38M59 31L66 28M59 35L66 38"/>';
    case 'corona': return '<path ' + W + ' d="M35 57L37 36L45 46L50 31L55 46L63 36L65 57Z"/><path fill="none" stroke="' + scuro + '" stroke-width="2" d="M37 52H63"/>';
    /* i gradi, come le mostrine: uno, due, tre galloni */
    case 'gallone1': return '<path ' + G(5.5) + ' d="M36 50L50 39L64 50"/>';
    case 'gallone2': return '<path ' + G(5) + ' d="M36 44L50 33L64 44M36 56L50 45L64 56"/>';
    case 'gallone3': return '<path ' + G(4.4) + ' d="M37 39L50 30L63 39M37 49L50 40L63 49M37 59L50 50L63 59"/>';
    case 'diamante': return '<path ' + W + ' d="M50 27L63 43L50 61L37 43Z"/><path fill="none" stroke="' + scuro + '" stroke-width="1.6" d="M37 43H63M50 27L45 43L50 61L55 43Z"/>';
    case 'scudo': return '<path ' + W + ' d="M50 28L63 32V43C63 52 57 57 50 61C43 57 37 52 37 43V32Z"/><path fill="none" stroke="' + scuro + '" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" d="M43 42L50 37L57 42M43 49L50 44L57 49"/>';
    case 'onda': return '<path ' + S + ' d="M32 40C37 34 42 34 45 40C48 46 53 46 56 40C59 34 64 34 68 40M32 52C37 46 42 46 45 52C48 58 53 58 56 52C59 46 64 46 68 52"/>';
    case 'bandiera': return '<path ' + W + ' d="M33 61L48 39L63 61Z"/><path ' + G(2.6) + ' d="M48 39V24"/><path ' + W + ' d="M48 24L59 27.5L48 31Z"/>';
    case 'fulmine': return '<path ' + W + ' d="M55 26L38 48H49L45 64L62 40H51Z"/>';
    case 'ali': return '<path ' + W + ' d="' + ala + '"/><path ' + W + ' transform="translate(100 0) scale(-1 1)" d="' + ala + '"/><circle cx="50" cy="44" r="3.4" ' + W + '/>';
    case 'luna': return '<path ' + W + ' d="M55 28A17 17 0 1 0 61 57A13.5 13.5 0 1 1 55 28Z"/>';
    case 'cometa': return '<path ' + W + ' d="' + lvEmStella(58, 37, 10, 4.4) + '"/><path ' + G(3) + ' d="M51 44L34 60M46 39L33 47M56 49L46 62"/>';
    case 'chiave': return '<circle cx="42" cy="37" r="8" ' + S + '/><path ' + S + ' d="M48 43L64 59M56 51L60.5 46.5M60.5 55.5L65 51"/>';
    case 'spade': return '<path ' + G(3.4) + ' d="M35 29L62 58M65 29L38 58M33 51L41 59M67 51L59 59"/>';
    case 'tridente': return '<path ' + S + ' d="M50 29V62M40 31V41C40 47 44 50 50 50C56 50 60 47 60 41V31M45 62H55"/>';
    case 'gemma': return '<path ' + W + ' d="M50 27L64 35V52L50 60L36 52V35Z"/><path fill="' + scuro + '" opacity=".35" d="M50 27L64 35L50 43L36 35Z"/>';
    default:
      /* un'emoji: al centro dello stemma, su un tondo chiaro che la stacca dal fondo */
      if (g && !/^[a-z0-9]+$/.test(g)) return '<circle cx="50" cy="45" r="17" fill="#FFFFFF" fill-opacity=".92"/><text x="50" y="46.5" text-anchor="middle" dominant-baseline="central" font-size="21">' + String(g).replace(/[<>&]/g, '') + '</text>';
      return '<path ' + W + ' d="' + lvEmStella(50, 45, 18, 4.5, 4) + '"/><path ' + W + ' opacity=".75" transform="rotate(45 50 45)" d="' + lvEmStella(50, 45, 11, 3.5, 4) + '"/>';
  }
}
/** L'SVG dell'emblema del livello n. opz: { testo: '12' } mette il numero al posto del disegno (i pallini piccoli). */
function lvEmblema(n, size, opz){
  n = Math.max(1, Math.min(LV_PER_CICLO, Math.round(+n || 1)));
  opz = opz || {};
  const fi = Math.floor((n - 1) / 5), grado = ((n - 1) % 5) + 1, st = LV_EM_STILE[fi];
  const id = 'lvE' + n + '_' + (++LV_EM_ID);
  const nome = LV_LEVELS[n - 1].name;
  let x = '<svg class="lv-em" viewBox="0 0 100 100" width="' + (size || 48) + '" height="' + (size || 48) + '" role="img" aria-label="Emblema del livello ' + n + ', ' + nome + '">'
    + '<defs><linearGradient id="' + id + 'c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + st.a + '"/><stop offset="1" stop-color="' + st.b + '"/></linearGradient>'
    + '<linearGradient id="' + id + 'm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF" stop-opacity=".9"/><stop offset=".45" stop-color="' + st.bordo + '"/><stop offset="1" stop-color="' + st.bordo + '" stop-opacity=".75"/></linearGradient></defs>';
  /* i raggi, dietro a tutto */
  if (st.raggi){
    let r = '';
    for (let i = 0; i < 16; i++){ const a = i * Math.PI / 8, a1 = a - 0.07, a2 = a + 0.07; r += 'M50 46L' + (50 + Math.cos(a1) * 50).toFixed(1) + ' ' + (46 + Math.sin(a1) * 50).toFixed(1) + 'L' + (50 + Math.cos(a2) * 50).toFixed(1) + ' ' + (46 + Math.sin(a2) * 50).toFixed(1) + 'Z'; }
    x += '<path fill="' + st.bordo + '" opacity=".38" d="' + r + '"/>';
  }
  /* le ali, ai lati */
  if (st.ali){
    const ala = 'M27 36C15 30 6 34 2 42C10 41 14 43 17 46C9 46 5 51 4 57C11 54 16 55 19 57C13 59 11 63 11 68C18 64 23 63 28 64Z';
    /* 0.9.400 BUG-179: le ali bianche e azzurre (l'oro resta un accento: il bordo, la gemma, le stelle) */
    x += '<linearGradient id="' + id + 'w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#BCE0FF"/></linearGradient>';
    x += '<path fill="url(#' + id + 'w)" stroke="' + st.b + '" stroke-width="1.2" d="' + ala + '"/><path fill="url(#' + id + 'w)" stroke="' + st.b + '" stroke-width="1.2" transform="translate(100 0) scale(-1 1)" d="' + ala + '"/>';
  }
  /* l'alloro, intorno alla base */
  if (st.alloro){
    let fo = '';
    for (let i = 0; i < 6; i++){
      const a = Math.PI * (0.62 + i * 0.105), cx = 50 + Math.cos(a) * 37, cy = 50 + Math.sin(a) * 37, rot = a * 180 / Math.PI + 90;
      fo += '<ellipse cx="' + cx.toFixed(1) + '" cy="' + cy.toFixed(1) + '" rx="3.4" ry="7" transform="rotate(' + rot.toFixed(0) + ' ' + cx.toFixed(1) + ' ' + cy.toFixed(1) + ')"/>';
    }
    x += '<g fill="#BCE0FF" stroke="' + st.b + '" stroke-width=".8">' + fo + '</g><g fill="#BCE0FF" stroke="' + st.b + '" stroke-width=".8" transform="translate(100 0) scale(-1 1)">' + fo + '</g>';
  }
  /* il corpo */
  let corpo;
  if (st.forma === 'tondo') corpo = 'M50 16A30 30 0 1 1 49.9 16Z';
  else if (st.forma === 'scudo') corpo = 'M50 13L77 21V45C77 63 64 75 50 82C36 75 23 63 23 45V21Z';
  else { const p = []; for (let i = 0; i < 32; i++){ const a = -Math.PI / 2 + i * Math.PI / 16, rr = i % 2 ? 29 : 33; p.push((50 + Math.cos(a) * rr).toFixed(1) + ' ' + (46 + Math.sin(a) * rr).toFixed(1)); } corpo = 'M' + p.join(' L') + 'Z'; }
  x += '<path d="' + corpo + '" fill="url(#' + id + 'c)" stroke="url(#' + id + 'm)" stroke-width="4.5" stroke-linejoin="round"/>';
  if (st.doppio || fi >= 4) x += '<path d="' + corpo + '" fill="none" stroke="#FFFFFF" stroke-opacity=".32" stroke-width="1.4" transform="translate(50 47) scale(.82) translate(-50 -47)"/>';
  /* la gemma in cima */
  if (st.gemma) x += '<path fill="' + st.bordo + '" stroke="#FFFFFF" stroke-width="1.4" d="' + lvEmStella(50, 11, 7, 3, 4) + '"/>';
  /* il disegno della famiglia, o il numero */
  if (opz.testo != null){
    const t = String(opz.testo), fs = t.length <= 2 ? 30 : (t.length === 3 ? 24 : 19);
    x += '<text x="50" y="47" text-anchor="middle" dominant-baseline="central" style="font-family:var(--font-display,Arial),Arial,sans-serif" font-weight="900" font-size="' + fs + '" fill="#FFFFFF" stroke="' + st.b + '" stroke-width="1" paint-order="stroke">' + String(t).replace(/[<>&]/g, '') + '</text>';
  } else x += lvEmGlifo(LV_EM_SEGNI[n - 1], st);
  /* il nastro con le stelle del grado */
  x += '<path fill="' + st.b + '" stroke="url(#' + id + 'm)" stroke-width="1.6" stroke-linejoin="round" d="M24 79H76L71 85.5L76 92H24L29 85.5Z"/>';
  const passo = 9.5, x0 = 50 - (grado - 1) * passo / 2;
  for (let i = 0; i < grado; i++) x += '<path fill="' + (st.oro ? '#F5B301' : '#FFFFFF') + '" d="' + lvEmStella(x0 + i * passo, 85.5, 4.1, 1.8) + '"/>';
  return x + '</svg>';
}

/* ---------------------------------------------------------------------------------------
   UNA FUNZIONE SOLA per tutto quello che si dice di un livello: il nome, la famiglia, il grado, la frase, il premio e
   l'emblema. La chiamano il popup, la pagina dei livelli, il profilo, gli amici e la card da condividere.
   --------------------------------------------------------------------------------------- */
function lvDati(n, prestigio){
  n = Math.max(1, Math.min(LV_PER_CICLO, Math.round(+n || 1)));
  const l = LV_LEVELS[n - 1], fi = Math.floor((n - 1) / 5), pres = +prestigio || 0;
  return {
    n: n, nome: l.name, famiglia: LV_FAMIGLIE[fi].nome, grado: ((n - 1) % 5) + 1, xp: l.xp,
    frase: (n === 1 && pres > 0) ? LV_FRASE_PRESTIGIO : LV_FRASI[n - 1],
    perk: (n === 1 && pres > 0) ? 'Una stella in più accanto al tuo livello' : l.perk,
    grants: l.grants.slice(),
    emblema: function(size, opz){ return lvEmblema(n, size, opz); }
  };
}
/** La riga «emblema · Livello N · Nome» per i profili (il mio pubblico e quello degli amici). coda: testo semplice da aggiungere. */
function lvRigaHtml(n, coda){
  const d = lvDati(n);
  const e = function(t){ return String(t == null ? '' : t).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  return '<span class="lv-riga">' + d.emblema(22) + '<span>Livello ' + d.n + ' · ' + e(d.nome) + e(coda || '') + '</span></span>';
}
const LV_CHALLENGES = [
  { id: 'first_block', name: 'Il primo blocco',      hint: 'Crea un programma o riempi il Blocco rapido', pts: 20 },
  { id: 'why',         name: 'Il tuo perché',        hint: 'Metti l\'immagine del perché in Modalità severa', pts: 10 },
  { id: 'first_ff',    name: 'Prima concentrazione', hint: 'Completa una sessione FullFocus', pts: 30 },
  { id: 'ff_10',       name: 'Dieci sessioni',       hint: 'Completa dieci sessioni FullFocus', pts: 100 },
  { id: 'streak_7',    name: 'Una settimana di fila', hint: 'Sette giorni con la Modalità severa attiva', pts: 50 },
  { id: 'streak_30',   name: 'Un mese di fila',      hint: 'Trenta giorni con la Modalità severa attiva', pts: 150 },
  { id: 'blocks_100',  name: 'Cento tentazioni',     hint: 'Cento blocchi scattati', pts: 50 },
  { id: 'tree',        name: 'Un albero vero',       hint: 'Pianta il primo albero dal tuo cielo', pts: 200 },
  { id: 'mantra_7',    name: 'Sette volte il perché', hint: 'Ascolta il tuo mantra sette giorni di fila', pts: 250 },
  { id: 'renew_1',     name: 'Ci hai rimesso la firma', hint: 'Rinnova la Modalità severa quando scade', pts: 300 },
  { id: 'renew_3',     name: 'Tre volte di fila',     hint: 'Rinnova la Modalità severa tre volte', pts: 800 }
];
const LV = { xp: 0, level: 1, parts: null, at: 0 };

function lvRead(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }

/* The figures, from the data the app already keeps. Async only for the block history. */
async function lvCompute(){
  const parts = { blocks: 0, streak: 0, ffMin: 0, ffSessions: 0, trees: 0, mantraDays: 0, mantraTotal: 0, decisions: 0, votes: 0, done: [] };
  let hist = [];
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInsights){
    try{ const r = await NATIVE.getInsights({ days: 400 }); hist = (r && r.history) || []; }catch(_){ hist = []; }
  }
  parts.blocks = hist.reduce((a, h) => a + (h.blocks || 0), 0);
  const st = lvRead('fl_sev_streak', null);
  if (st && st.start && typeof blkDaysBetween === 'function' && typeof blkToday === 'function') parts.streak = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
  const ff = lvRead('fl_ff_hist', []);
  ff.forEach(s => { if (s && s.ok){ parts.ffSessions++; parts.ffMin += (s.min || 0); } });
  parts.trees = (lvRead('fl_trees', []) || []).length;
  /* LE PROVE IN FOTO: facoltative, e valgono esperienza (non punti della partita). */
  try{
    const meta = lvRead('fl_notes_meta', {}) || {};
    parts.prove = Object.keys(meta).filter(function(k){ return meta[k] && meta[k].foto; }).length;
  }catch(_){ parts.prove = 0; }
  if (typeof decPoints === 'function'){
    /* Ogni voto tagliato a ±60 PRIMA di sommarlo: i voti vecchi sono registrati a 300, e
       lasciarli pesare per intero vorrebbe dire che chi ha gia' votato resta dieci livelli
       sopra a chi vota da domani con la scala nuova. */
    let dec = 0;
    try{ (decLog().votes || []).forEach(function(v){ dec += Math.max(-60, Math.min(60, +v.pts || 0)); }); }
    catch(_){ dec = decPoints(); }
    parts.decisions = dec;
    parts.votes = decCount(true);
    /* i rinnovi: solo le firme della Modalita' severa (prima ogni "si'" contava, anche la riga messa sul foglio) */
    try{ parts.firme = (decLog().votes || []).filter(function(v){ return v && v.yes && (v.kind === 'strict' || v.kind === 'blinda'); }).length; }catch(_){ parts.firme = 0; }
  }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getMantraLog){
    try{ const m = await NATIVE.getMantraLog(); parts.mantraDays = (m && m.days) || 0; parts.mantraTotal = (m && m.total) || 0; }catch(_){ }
  }

  const hasBlock = (typeof PROGRAMS !== 'undefined' && PROGRAMS && PROGRAMS.length > 0)
    || (typeof QUICK !== 'undefined' && QUICK && ((QUICK.apps || []).length + (QUICK.sites || []).length + (QUICK.keywords || []).length) > 0);
  let why = ''; try{ why = localStorage.getItem('fl_why_img') || ''; }catch(_){ }
  const done = {
    first_block: hasBlock, why: !!why, first_ff: parts.ffSessions >= 1, ff_10: parts.ffSessions >= 10,
    streak_7: parts.streak >= 7, streak_30: parts.streak >= 30, blocks_100: parts.blocks >= 100, tree: parts.trees >= 1,
    mantra_7: parts.mantraDays >= 7,
    /* 0.9.264, Andrea: firmare la Modalita' severa nel giro del Genio portava dal livello 1 al 4. La prima
       firma contava gia' come "rinnovo" (300 punti): rinnovare vuol dire firmare DI NUOVO, quindi dalla seconda. */
    renew_1: (parts.firme || 0) >= 2, renew_3: (parts.firme || 0) >= 4
  };
  parts.done = LV_CHALLENGES.filter(c => done[c.id]).map(c => c.id);
  /* Ascoltare il mantra è il gesto che costa meno e vale di più: è l'unico momento in cui si
     sceglie a mente fredda di ricordarsi perché si è cominciato. Quaranta punti al giorno di
     striscia e quindici a ascolto lo mettono sopra a tutto il resto. */
  /* Le decisioni pesano più di tutto il resto messo insieme, ed è giusto così: un giorno di
     blocchi è un'abitudine che gira da sola, mentre firmare di nuovo quando potresti smettere
     è l'unico momento in cui scegli davvero. Il rifiuto toglie punti, perché anche quello è
     una scelta e va contata come tale. */
  /* Le protezioni serie spese si pagano qui. A mano costano poco, in automatico quattro
     volte tanto: la differenza fra "oggi non ce la faccio, lo dico" e un giorno passato senza
     accorgersene. Il conto lo tiene start.js in fl_sp_toll, che sa quale delle due e' stata. */
  const toll = lvRead('fl_sp_toll', 0) || 0;

  /* I GIORNI CON IL PIANO: il gesto piu' piccolo e piu' importante di tutta l'app, e finora
     non valeva un punto. Scrivere stasera l'unica cosa di domani e' l'unica cosa che una
     persona puo' fare adesso, sempre, anche in una giornata storta. */
  let pianiFatti = 0;
  try{
    const m = JSON.parse(localStorage.getItem('fl_plan_days') || '{}') || {};
    pianiFatti = Object.keys(m).length;
  }catch(_){ }

  /* QUELLO CHE NON VALE PIU' NIENTE: `parts.blocks`.
     Un punto per blocco scattato pagava la persona ogni volta che provava ad aprire l'app che
     si era vietata — piu' cedevi, piu' salivi. Il numero resta contato nel tabellone
     dell'arbitro, che e' il posto giusto per una tentazione: li' dice qualcosa, qui diceva
     il contrario di quello che serviva.

     E gli ascolti del mantra sono scesi da quindici punti a due: la costanza vale (i GIORNI
     di fila), la ripetizione nello stesso giorno no — quindici punti a tocco erano una
     macchinetta da premere. */
  let xp = parts.streak * 8
         + parts.ffMin * 1 + parts.ffSessions * 20
         + parts.trees * 150
         + parts.mantraDays * 10 + parts.mantraTotal * 2
         + pianiFatti * 12
         + (parts.prove || 0) * 25
         + parts.decisions - toll;
  /* il sentiero di oggi (sentiero.js): tappe fatte e scrigni aperti, gia' contati li' */
  try{ if (typeof snXp === 'function') xp += snXp(); }catch(_){ }
  try{ if (typeof sdXp === 'function') xp += sdXp(); }catch(_){ }
  LV_CHALLENGES.forEach(c => { if (done[c.id]) xp += c.pts; });
  /* 0.9.262, Andrea: "Ricomincia da capo" deve riportare il livello all'inizio. Il livello e' la somma di tante
     storie dell'app, e il reset ne toglieva solo alcune (da 14 si scendeva a 12). Adesso al reset si segna lo
     ZERO: i punti che c'erano in quel momento diventano la base, e da li' si riparte dal livello 1. */
  try{
    if (localStorage.getItem('fl_lv_azzera')){ localStorage.setItem('fl_lv_base', String(Math.max(0, Math.round(xp)))); localStorage.removeItem('fl_lv_azzera'); }
    xp -= (+localStorage.getItem('fl_lv_base') || 0);
  }catch(_){ }
  LV.parts = parts; LV.xp = Math.max(0, Math.round(xp)); LV.at = Date.now();
  lvTelefono();

  /* Il ciclo: quanti giri interi sono stati fatti (il prestigio) e a che punto e' quello in
     corso. I punti NON si azzerano: azzerarli vorrebbe dire cancellare quello che e' successo,
     e qui l'unica cosa che conta e' proprio che sia successo. */
  const d = lvDaPunti(LV.xp);
  const before = LV.level;
  LV.prestigio = d.prestigio;
  LV.restoXp = d.resto;
  LV.level = d.level;
  lvNotice(before);
  try{ lvFestaControlla(); }catch(_){ }
  return LV;
}
/* ---------------------------------------------------------------------------------------
   UN LIVELLO SOLO FRA TELEFONO E COMPUTER (0.9.306)

   Andrea: "il livello del profilo sul PC e' diverso da quello del telefono, e sono collegati allo stesso account".
   LA CAUSA. Il livello non viaggia: ogni dispositivo lo ricalcola da solo (lvCompute) dai pezzi che ha in mano. Il
   computer riceve dal telefono le chiavi dell'app (lo specchio, specchio-web.js), ma due pezzi degli XP non sono
   chiavi: i giorni e gli ascolti del mantra (getMantraLog) e i blocchi scattati (getInsights, la sfida "Cento
   tentazioni") li sa solo il motore del telefono, e sul computer valevano zero. Il computer contava meno XP e
   mostrava un livello piu' basso.
   LA DECISIONE: la fonte della verita' sono gli XP del telefono. Il telefono, che misura tutto, scrive i suoi XP in
   fl_lv_tel (una chiave del viaggio: lo specchio la porta al computer entro mezzo minuto, regole-sync.js); il
   computer, quando la trova, mostra quelli. Non si sommano: quello che si fa sul computer (le tappe, le sessioni)
   vive in chiavi che lo specchio riporta dal telefono, quindi una somma conterebbe due volte la stessa vita.
   Senza un telefono collegato il computer conta da solo, come prima.
   --------------------------------------------------------------------------------------- */
const LV_TEL_KEY = 'fl_lv_tel';
function lvSuComputer(){
  try{ if (typeof swSpecchio === 'function') return swSpecchio(); }catch(_){ }
  try{ return typeof pcQui === 'function' && pcQui() === 'desktop'; }catch(_){ return false; }
}
function lvTelefono(){
  try{
    if (lvSuComputer()){
      const t = JSON.parse(localStorage.getItem(LV_TEL_KEY) || 'null');
      if (t && typeof t.xp === 'number' && isFinite(t.xp) && t.xp >= 0){
        LV.xpQui = LV.xp; LV.xp = Math.round(t.xp); LV.daTelefono = true;
        /* anche "Da dove vengono i punti" e le sfide sono quelli del telefono: le righe tornano con il totale */
        if (t.parts && typeof t.parts === 'object') LV.parts = Object.assign({}, LV.parts || {}, t.parts);
      }
      return;
    }
    const t = JSON.parse(localStorage.getItem(LV_TEL_KEY) || 'null');
    const parts = JSON.stringify(LV.parts || {});
    if (!t || t.xp !== LV.xp || JSON.stringify(t.parts || {}) !== parts) localStorage.setItem(LV_TEL_KEY, JSON.stringify({ xp: LV.xp, at: Date.now(), parts: LV.parts || {} }));
  }catch(_){ }
}
/** Dai punti al livello: quanti cicli interi (il prestigio), il livello nel ciclo in corso e i punti dentro al ciclo. */
function lvDaPunti(xp){
  xp = Math.max(0, Math.round(+xp || 0));
  const cicli = Math.min(LV_PRESTIGI, Math.floor(xp / LV_XP_CICLO));
  const resto = xp - cicli * LV_XP_CICLO;
  let lvl = 1;
  LV_LEVELS.forEach(function(l){ if (resto >= l.xp) lvl = l.n; });
  return { prestigio: cicli, level: cicli >= LV_PRESTIGI ? LV_PER_CICLO : lvl, resto: resto, assoluto: cicli * LV_PER_CICLO + (cicli >= LV_PRESTIGI ? LV_PER_CICLO : lvl) };
}
function lvInfo(){
  const cur = LV_LEVELS[LV.level - 1], next = LV_LEVELS[LV.level] || null;
  const resto = (typeof LV.restoXp === 'number') ? LV.restoXp : LV.xp;
  const pres = LV.prestigio || 0;
  /* al livello 50 la barra va verso la stella del prestigio (la fine del ciclo), non verso un 51 che non c'e' */
  const fine = next ? next.xp : (pres >= LV_PRESTIGI ? 0 : LV_XP_CICLO);
  const span = fine ? fine - cur.xp : 1;
  const pct = fine ? Math.max(0, Math.min(100, Math.round((resto - cur.xp) / span * 100))) : 100;
  const d = lvDati(LV.level, pres);
  return {
    level: LV.level, name: cur.name, xp: LV.xp, next: next,
    toNext: fine ? Math.max(0, fine - resto) : 0, pct: pct,
    prestigio: pres, dati: d,
    /* Come si dice a voce: «prestigio 3, livello 12». Senza stelle, «livello 12» al terzo giro
       sembrerebbe un passo indietro rispetto al cinquanta di prima. */
    etichetta: (pres ? 'prestigio ' + pres + ' \u00b7 ' : '') + 'livello ' + LV.level
      + (pres >= LV_PRESTIGI ? ' \u00b7 massimo' : '')
  };
}
/* What the levels have unlocked so far: lvHas('sound:wind'), lvMaxMinutes(). */
function lvHas(grant){
  /* dopo il prestigio il livello torna a 1, ma quello che e' stato sbloccato nel giro chiuso resta (prima spariva) */
  const tutti = (LV.prestigio || 0) > 0 ? LV_PER_CICLO : LV.level;
  for (let i = 0; i < tutti; i++) if (LV_LEVELS[i].grants.indexOf(grant) >= 0) return true;
  try{ if ((JSON.parse(localStorage.getItem('fl_grants_extra') || '[]') || []).indexOf(grant) >= 0) return true; }catch(_){ }
  return false;
}
/** Uno sblocco regalato fuori dai livelli (il tassello del giorno, domande.js). */
function lvGrantExtra(grant){
  try{
    const l = JSON.parse(localStorage.getItem('fl_grants_extra') || '[]') || [];
    if (l.indexOf(grant) < 0){ l.push(grant); localStorage.setItem('fl_grants_extra', JSON.stringify(l)); }
  }catch(_){ }
}
function lvMaxMinutes(){ return lvHas('minutes:180') ? 180 : (lvHas('minutes:120') ? 120 : 90); }
function lvRing(){ return lvHas('ring:rainbow') ? 'rainbow' : (lvHas('ring:gold') ? 'gold' : (lvHas('ring:silver') ? 'silver' : 'blue')); }
function lvLevelFor(grant){ const l = LV_LEVELS.filter(x => x.grants.indexOf(grant) >= 0)[0]; return l ? l.n : 1; }

/* A level reached is told once, with what it unlocks. */
function lvNotice(before){
  let seen = 1; try{ seen = +localStorage.getItem('fl_lv_seen') || 1; }catch(_){ }
  if (LV.level > seen){
    try{ localStorage.setItem('fl_lv_seen', String(LV.level)); }catch(_){ }
    /* Il livello nuovo non lo dice piu' un toast: lo festeggia il popup qui sotto
       (lvFestaControlla), che sa anche del prestigio e non scatta al primo avvio. */
  }
}
async function lvBump(){
  const prima = LV.level;
  await lvCompute(); lvPaintProfile();
  /* si sente anche con le mani (0.9.203): un livello in piu' e' un evento, non una riga */
  /* se il popup del livello e' appena partito, vibra lui insieme ai coriandoli */
  try{ if (LV.level > prima && !(LV.festaAt && Date.now() - LV.festaAt < 4000)) flVibra([30, 40, 30, 40, 90]); }catch(_){ }
  if (typeof frSyncMaybe === 'function') frSyncMaybe();
}

/* ---------------------------------------------------------------------------------------
   The ring around the portrait, and the line under the name
   --------------------------------------------------------------------------------------- */
function lvRingSvg(pct, size, stroke){
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const ring = lvRing();
  const col = ring === 'gold' ? '#F5B301' : ring === 'silver' ? '#C9D3E0' : ring === 'rainbow' ? 'url(#lvRainbow)' : '#5B8DEF';
  return '<svg class="lv-ring' + (lvHas('ring:animated') ? ' anim' : '') + '" viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '">'
    + '<defs><linearGradient id="lvRainbow" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3F9FF4"/><stop offset=".5" stop-color="#0075E3"/><stop offset="1" stop-color="#E63946"/></linearGradient></defs>'
    + '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="' + stroke + '"/>'
    + '<circle class="lv-prog" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="' + stroke + '" stroke-linecap="round"'
    + ' stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + (c * (1 - pct / 100)).toFixed(1) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/>'
    + '</svg>';
}
/* The level and the points are not printed under the name: they are behind the badge. One
   tap shows them, another (or the page of the levels) takes them away again. */
function lvToggleLine(){
  const line = document.querySelector('.prof-hero .lv-line');
  if (!line){ lvOpen(); return; }
  line.hidden = !line.hidden;
  if (!line.hidden){
    clearTimeout(lvToggleLine.t);
    lvToggleLine.t = setTimeout(() => { line.hidden = true; }, 9000);
  }
}
async function lvPaintProfile(){
  const av = document.getElementById('profAv');
  if (!av) return;
  if (!LV.parts || Date.now() - LV.at > 30000) await lvCompute();
  const info = lvInfo();
  let wrap = av.parentElement && av.parentElement.classList.contains('lv-wrap') ? av.parentElement : null;
  if (!wrap){
    wrap = document.createElement('div'); wrap.className = 'lv-wrap';
    av.parentNode.insertBefore(wrap, av);
    wrap.appendChild(av);
  }
  let ring = wrap.querySelector('.lv-ring'); if (ring) ring.remove();
  wrap.insertAdjacentHTML('beforeend', lvRingSvg(info.pct, LV_ANELLO.profilo, LV_ANELLO.spessore));
  let badge = wrap.querySelector('.lv-badge');
  /* 0.9.379, Andrea: "toccando il livello si apre una riga attaccata al badge Premium: deve aprire la pagina dei livelli, con quanto manca e
     cosa sblocca ogni livello, come in Call of Duty" */
  if (!badge){ badge = document.createElement('b'); badge.className = 'lv-badge'; wrap.appendChild(badge); }
  /* 0.9.400 BUG-179: il bollino e' lo stesso della pagina Account (lvBollinoMetti); toccandolo si apre l'emblema vero del livello */
  badge.onclick = function(e){ e.stopPropagation(); lvEmblemaApri(); };
  /* Il pallino sull'avatar: il livello, e se ci sono stelle il numero del prestigio davanti.
     «3·12» sta in due caratteri e mezzo e dice piu' di «12». */
  /* 0.9.400 BUG-179, Andrea: "nel Profilo e nell'Account il livello e' un numero semplice nel bollino azzurro, uguale nelle due pagine".
     L'emblema non sta piu' sulla foto: si apre toccando il numero */
  lvBollinoMetti(badge, info);
  const hero = wrap.closest('.prof-hero');
  let line = hero ? hero.querySelector('.lv-line') : null;
  if (!line && hero){
    line = document.createElement('div'); line.className = 'lv-line'; line.hidden = true; line.onclick = lvOpen;
    // above the name: the level is what the ring says, the name is who it belongs to
    const name = hero.querySelector('h2');
    if (name) hero.insertBefore(line, name); else hero.appendChild(line);
  }
  if (line) line.innerHTML = '<b>Livello ' + info.level + ' · ' + esc(info.name) + '</b>'
    + (info.next ? '<small>' + info.toNext + ' punti al prossimo livello</small>' : '<small>Livello massimo raggiunto</small>');
}

/* 0.9.400 BUG-179, Andrea: "nel Profilo l'anello e' attaccato alla foto ed e' diverso da quello dell'Account" (lezione 269: lo stesso
   elemento ha la stessa forma in tutte le pagine). L'anello ha lo stesso spessore e lo stesso spazio dalla foto in tutte e due le
   pagine; cambia solo la grandezza della foto. foto = misura - 2 * (spessore + spazio). */
const LV_ANELLO = { spessore: 5, spazio: 5, profilo: 112, account: 140 };
function lvFotoDentro(misura){ return misura - 2 * (LV_ANELLO.spessore + LV_ANELLO.spazio); }
/** Il bollino del livello sulla foto: il numero, nel tondo azzurro (con il prestigio davanti, se c'e'). Uguale in Profilo e Account. */
function lvBollinoMetti(el, info){
  if (!el || !info) return;
  el.classList.add('lv-bollino');
  el.textContent = info.prestigio ? info.prestigio + '·' + info.level : String(info.level);
  el.setAttribute('aria-label', 'Livello ' + info.level + ', ' + info.name + '. Tocca per vedere il tuo emblema');
  el.setAttribute('role', 'button');
}
/** L'emblema vero del livello, in un foglio: il nome, l'emblema grande e quanto manca al prossimo. Da qui la pagina di tutti i livelli. */
function lvEmblemaApri(){
  let info = null; try{ info = lvInfo(); }catch(_){ info = null; }
  if (!info || typeof inSheet !== 'function'){ lvOpen(); return; }
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  const d = info.dati || lvDati(info.level, info.prestigio);
  const e = function(t){ return String(t == null ? '' : t).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  const dopo = info.next ? (info.toNext === 1 ? 'Manca <b>1 punto</b>' : 'Mancano <b>' + info.toNext + ' punti</b>') + ' al livello ' + info.next.n + ',<br>' + e(info.next.name)
    : (info.toNext ? 'Mancano <b>' + info.toNext + ' punti</b> alla prossima stella del prestigio' : 'Hai raggiunto il livello più alto');
  inSheet('<div class="am-sheet lv-emf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="lv-emf-em">' + d.emblema(136) + '</div>'
    + '<small class="lv-emf-k">Livello ' + d.n + (String(d.famiglia || '').replace(/^(il|lo|la|l'|i|gli|le)\s*/i, '').toLowerCase() === String(d.nome || '').toLowerCase() ? '' : ' · ' + e(d.famiglia)) + '</small>'
    + '<h3 class="lv-emf-n">' + e(d.nome) + '</h3>'
    + '<div class="lv-emf-bar" aria-hidden="true"><i style="width:' + info.pct + '%"></i></div>'
    + '<p class="lv-emf-p">' + dopo + '</p>'
    + '<button type="button" class="cta lv-emf-cta" onclick="inSheetChiudi();lvOpen()">Vedi tutti i livelli</button></div>');
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* il bollino: lo stesso nelle due pagine */
  '.lv-bollino,.lv-wrap .lv-badge.lv-bollino,.acc-av .acc-lv-n2.lv-bollino{position:absolute;right:-6px;top:-4px;left:auto;bottom:auto;min-width:40px;width:auto;height:40px;padding:0 7px;box-sizing:border-box;border-radius:20px;'
  + 'border:3px solid #fff;background:linear-gradient(160deg,#3F9FF4,#0075E3);color:#fff;font:800 17px/1 var(--font-display);display:flex;align-items:center;justify-content:center;cursor:pointer;filter:none;box-shadow:0 6px 16px rgba(0,30,68,.3);z-index:3}'
  /* l'anello del Profilo: 112px, la foto da 92 a 10px dal bordo (5 di anello e 5 di spazio) */
  + '.lv-wrap:not(.big){width:112px;height:112px}.lv-wrap:not(.big) .av{left:10px;top:10px;width:92px!important;height:92px!important}'
  /* l'alone chiaro attaccato alla foto riempiva lo spazio: resta solo l'ombra sotto */
  + '.prof-hero .lv-wrap:not(.big) .av{box-shadow:0 10px 26px rgba(0,0,0,.35)!important}'
  /* il foglio dell'emblema */
  + '.lv-emf{text-align:center!important;padding:6px 4px 4px}.lv-emf-em{display:flex;justify-content:center;margin:10px 0 12px;filter:drop-shadow(0 10px 22px rgba(0,30,68,.28))}'
  + '.lv-emf-k{display:block;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}body.dark .lv-emf-k{color:#8CC6FF}'
  + '.lv-emf-n{margin:6px 0 16px;font:800 24px/1.2 var(--font-display);color:var(--navy)}body.dark .lv-emf-n{color:#fff}'
  + '.lv-emf-bar{height:8px;margin:0 18px;border-radius:99px;background:rgba(0,117,227,.14);overflow:hidden}.lv-emf-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#3F9FF4,#0075E3)}'
  + 'body.dark .lv-emf-bar{background:rgba(255,255,255,.14)}'
  + '.lv-emf-p{margin:14px 0 0;font:500 15px/1.5 var(--font-body);color:var(--muted)}.lv-emf-p b{color:var(--navy)}body.dark .lv-emf-p{color:#BFD3EC}body.dark .lv-emf-p b{color:#fff}'
  + '.lv-emf-cta{width:100%;margin-top:22px}';
  document.head.appendChild(st); })();

/* ---------------------------------------------------------------------------------------
   The Levels page: where the points come from, what each level unlocks, the challenges
   --------------------------------------------------------------------------------------- */
registerScreen('s-levels', `
  <div class="topbar"><button class="iconbtn" onclick="lvClose()">‹</button><b class="blk-title">Il tuo livello</b></div>
  <div id="lvBody"></div>
  <div class="spacer"></div>
`, { back: 's-home' });

async function lvOpen(){ goId('s-levels'); await lvCompute(); lvPaintPage(); }
function lvClose(){ if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); if (typeof switchTab === 'function') switchTab('profilo'); } }
/** Le stelle del prestigio: fino a dieci disegnate, oltre si scrive il numero. */
function lvStelle(n){
  if (n <= 0) return '';
  if (n <= 10) return new Array(n + 1).join('★');
  return '★ × ' + n;
}

function lvPaintPage(){
  const box = document.getElementById('lvBody'); if (!box) return;
  const info = lvInfo(), p = LV.parts || {};
  /* L'elenco dice esattamente cosa paga, e quanto. I blocchi scattati NON ci sono piu': erano
     la riga che premiava il tentativo di aprire l'app vietata. Restano contati nel tabellone
     dell'arbitro, dove un tentativo bloccato vuol dire qualcosa. */
  let piani = 0;
  try{ piani = Object.keys(JSON.parse(localStorage.getItem('fl_plan_days') || '{}') || {}).length; }catch(_){ }
  const rows = [
    ['📝', 'Giorni chiusi con il piano di domani', piani + ' × 12', piani * 12],
    ['🌱', 'Minuti di FullFocus completati', (p.ffMin || 0) + ' × 1', (p.ffMin || 0)],
    ['🎯', 'Sessioni portate a termine', (p.ffSessions || 0) + ' × 20', (p.ffSessions || 0) * 20],
    ['🔒', 'Giorni di fila in Modalità severa', (p.streak || 0) + ' × 8', (p.streak || 0) * 8],
    ['🔥', 'Giorni di fila con il mantra', (p.mantraDays || 0) + ' × 10', (p.mantraDays || 0) * 10],
    ['🌳', 'Alberi veri piantati', (p.trees || 0) + ' × 150', (p.trees || 0) * 150]
  ];
  const chDone = p.done || [];
  const d = info.dati;
  box.innerHTML = '<div class="lv-hero"><div class="lv-wrap big"><div class="lv-big">' + d.emblema(112) + '</div>' + lvRingSvg(info.pct, 132, 8)
    +   '<b class="lv-big-n">' + info.level + '</b></div>'
    + (info.prestigio ? '<div class="lv-pres">' + lvStelle(info.prestigio) + '</div>' : '')
    + '<small class="lv-fam">' + esc(d.famiglia) + ' · grado ' + d.grado + ' di 5</small>'
    + '<h2>Livello ' + info.level + ' · ' + esc(info.name) + '</h2>'
    + '<p class="lv-frase">' + esc(d.frase) + '</p>'
    + '<div class="lv-bar"><i style="width:' + info.pct + '%"></i></div>'
    + '<small>' + info.xp + ' punti' + (info.next ? ' · ' + info.toNext + ' al livello ' + info.next.n
        : (info.prestigio >= LV_PRESTIGI ? ' · hai tutte le stelle' : ' · ' + info.toNext + ' alla prossima stella')) + '</small>'
    /* 0.9.397: il prestigio in due righe, non in un paragrafo */
    + '<p class="lv-pres-txt">Dopo il livello 50 ricominci dal livello 1 con <b>una stella in più</b>: è il prestigio. Le stelle sono venti'
    +   (info.prestigio ? ', e ne hai <b>' + info.prestigio + '</b>.' : '.') + '</p>'
    + '</div>'
    /* 0.9.379: prima cosa si sblocca salendo, come in Call of Duty: il prossimo premio in grande, poi i livelli che vengono */
    + lvProssimiHtml(info)
    + '<div class="sect"><b>Da dove vengono i punti</b></div>'
    + rows.map(r => '<div class="lv-row"><span class="em">' + r[0] + '</span><div><b>' + r[1] + '</b><small>' + r[2] + '</small></div><b class="pt">' + r[3] + '</b></div>').join('')
    + '<div class="sect"><b>Sfide</b></div>'
    + LV_CHALLENGES.map(c => { const ok = chDone.indexOf(c.id) >= 0; return '<div class="lv-row' + (ok ? ' ok' : '') + '"><span class="em">' + (ok ? '✅' : '⬜') + '</span><div><b>' + esc(c.name) + '</b><small>' + esc(c.hint) + '</small></div><b class="pt">' + (ok ? '+' : '') + c.pts + '</b></div>'; }).join('')
    + '<div class="sect"><b>I cinquanta livelli</b></div>'
    + LV_LEVELS.map(function(l){ const x = lvDati(l.n); return '<div class="lv-row' + (l.n <= info.level ? ' ok' : ' locked') + '"><span class="lv-row-em">' + x.emblema(40) + '</span><div><b>Livello ' + l.n + ' · ' + esc(x.nome) + '</b><small>' + esc(x.perk || (x.famiglia + ' · grado ' + x.grado + ' di 5')) + '</small></div><b class="pt">' + l.xp + '</b></div>'; }).join('');
}

(function lvStyle(){
  const css = [
    '.lv-wrap{position:relative;display:inline-block;width:104px;height:104px;vertical-align:top;z-index:2;margin-bottom:14px}',
    '.lv-badge{z-index:3}',
    '.lv-wrap .av{position:absolute;left:6px;top:6px;margin:0}',
    '.prof-sky .prof-hero .lv-wrap .av{width:92px;height:92px;font-size:38px}',
    '.lv-wrap .lv-ring{position:absolute;left:0;top:0;pointer-events:none}',
    '.lv-ring.anim .lv-prog{animation:lvPulse 2.4s ease-in-out infinite}',
    '@keyframes lvPulse{0%,100%{opacity:1}50%{opacity:.55}}',
    /* the badge sits ON the ring, at one o'clock: under the portrait there is the name, and
       at five o'clock it landed on the PREMIUM ribbon */
    '.lv-badge{position:absolute;right:-10px;top:-8px;width:46px;height:46px;display:flex;align-items:center;justify-content:center;cursor:pointer;filter:drop-shadow(0 4px 8px rgba(0,0,0,.4))}',
    '.lv-badge .lv-em{display:block}',
    '.lv-riga{display:inline-flex;align-items:center;gap:6px;vertical-align:middle}.lv-riga .lv-em{flex:none;display:block}',
    '.lv-line{margin:6px 0 10px;cursor:pointer;animation:ufSinceIn .45s ease-out both}',
    '.lv-line[hidden]{display:none}',
    '.lv-line b{display:block;font:800 14px var(--font-display);color:#9EC1FF}',
    '.lv-line small{display:block;font:500 12px var(--font-body);color:rgba(255,255,255,.75);margin-top:2px}',
    '.lv-hero{text-align:center;padding:10px 0 6px}',
    '.lv-wrap.big{width:132px;height:132px}',
    '.lv-big{position:absolute;left:10px;top:10px;width:112px;height:112px;display:flex;align-items:center;justify-content:center;filter:drop-shadow(0 6px 14px rgba(0,30,68,.28))}',
    '.lv-big .lv-em{display:block}',
    '.lv-big-n{position:absolute;right:-6px;bottom:-4px;min-width:38px;height:38px;padding:0 6px;box-sizing:border-box;border-radius:99px;background:#E63946;color:#FFFFFF;border:3px solid #FFFFFF;display:flex;align-items:center;justify-content:center;font:800 17px var(--font-display);z-index:3}',
    'body.dark .lv-big-n{border-color:#0B1628}',
    '.lv-fam{display:block;margin-top:16px!important;font:800 11px var(--font-body)!important;letter-spacing:.12em;text-transform:uppercase;color:#E63946!important}',
    '.lv-frase{margin:0 26px 18px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.lv-row-em{flex:none;width:40px;height:40px;display:block}',
    '.lv-row-em .lv-em{display:block}',
    '.lv-row.locked .lv-row-em{filter:grayscale(1);opacity:.7}',
    '.lv-wrap.big .lv-ring circle:first-of-type{stroke:rgba(0,30,68,.1)}',
    '.lv-hero h2{font:800 22px var(--font-display);font-style:italic;color:var(--navy);margin:6px 0 10px}',
    /* Le stelle sopra al nome del rango: sono la cosa che si guarda per prima quando ci sono,
       e l'unica differenza visibile fra chi ha ricominciato tre volte e chi zero. */
    '.lv-pres{margin-top:12px;font-size:17px;letter-spacing:3px;color:#F5C542}',
    '.lv-pres-txt{margin:20px 26px 0;font:500 12px/1.6 var(--font-body);color:var(--muted)}',
    '.lv-pres-txt b{color:var(--navy);font-weight:800}',
    'body.dark .lv-pres-txt b{color:#fff}',
    '.lv-bar{height:8px;border-radius:99px;background:rgba(0,30,68,.08);overflow:hidden;margin:0 30px}',
    '.lv-bar i{display:block;height:100%;background:var(--blue);border-radius:99px}',
    '.lv-hero small{display:block;margin-top:8px;font:600 12px var(--font-body);color:var(--muted)}',
    '.lv-row{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin-bottom:8px}',
    '.lv-row .em{font-size:20px;line-height:1;flex:none}',
    '.lv-row > div{flex:1;min-width:0}',
    '.lv-row b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}',
    '.lv-row small{display:block;font:500 11.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.lv-row .pt{flex:none;font:800 14px var(--font-display);color:var(--blue)}',
    '.lv-row.locked{opacity:.6}',
    'body.dark .lv-row{background:#12203A;border-color:#22345A}body.dark .lv-row b,body.dark .lv-hero h2{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* ===========================================================================================
   IL LIVELLO NUOVO SI FESTEGGIA (0.9.214), come su Meditopia: popup al centro sopra lo sfondo
   scurito, coriandoli sparati dal basso, il distintivo del rango, «Livello N», una frase scritta
   per QUEL livello e «Condividi».

   UNA VOLTA PER LIVELLO. In fl_lv_festa c'e' l'ultimo livello festeggiato, contato sul ciclo
   intero (prestigio × 50 + livello): al prestigio il livello torna a 1, e senza contare il
   ciclo il livello 1 con una stella sembrerebbe un passo indietro. Se i punti scendono (un
   rifiuto, una protezione spesa) il segno resta dov'era: riprendere un livello gia' festeggiato
   non si festeggia di nuovo.

   MAI AL PRIMO AVVIO. Chiave assente = prima volta che questo codice gira (installazione nuova
   o aggiornamento): si segna il livello di adesso in silenzio. Lo stesso durante l'onboarding.
   =========================================================================================== */
const LV_FESTA_K = 'fl_lv_festa';
/* 0.9.397: le emoji dei ranghi e le frasi stanno nella scala (LV_FRASI, lvEmblema), e si leggono da lvDati */
const LV_SCALA_K = 'fl_lv_scala';
const LV_SCALA_V = '397';
function lvFestaAssoluto(){ return (LV.prestigio || 0) * LV_PER_CICLO + LV.level; }
function lvFestaControlla(){
  const ora = lvFestaAssoluto();
  let ultimo = null;
  try{ const v = localStorage.getItem(LV_FESTA_K); ultimo = (v === null || v === '') ? null : +v; }catch(_){ return; }
  let onb = true; try{ onb = localStorage.getItem('fl_onboarded') === '1'; }catch(_){ }
  /* 0.9.293: durante il giro del Genio e nel giorno dell'installazione i livelli si segnano in silenzio: nessuna festa
     per punti presi mentre si sta ancora imparando dove sono le cose */
  try{
    if (typeof GT !== 'undefined' && GT.on) onb = false;
    const tf = (typeof gnDati === 'function') ? +gnDati().tourFatto || 0 : 0;
    if (!tf || new Date(tf).toDateString() === new Date().toDateString()) onb = false;
  }catch(_){ }
  /* 0.9.397, LA SCALA NUOVA. Con gli stessi punti si sale (mai si scende): chi era al 3 si puo' trovare al 4, chi era al 20
     al 27. Senza questo, al primo avvio partirebbe un popup per ogni gradino guadagnato, uno dopo l'altro. Una volta sola:
     si festeggia soltanto il livello raggiunto, e il popup dice di quanti gradini si e' saliti e cosa si e' sbloccato. */
  let scala = ''; try{ scala = localStorage.getItem(LV_SCALA_K) || ''; }catch(_){ }
  let salto = null;
  if (scala !== LV_SCALA_V){
    try{ localStorage.setItem(LV_SCALA_K, LV_SCALA_V); }catch(_){ }
    if (ultimo !== null && isFinite(ultimo) && ora > ultimo + 1){
      salto = ultimo;
      ultimo = ora - 1;
      try{ localStorage.setItem(LV_FESTA_K, String(ultimo)); }catch(_){ }
    }
  }
  if (ultimo === null || !isFinite(ultimo) || !onb){
    if (ultimo === null || !isFinite(ultimo) || ora > ultimo){ try{ localStorage.setItem(LV_FESTA_K, String(ora)); }catch(_){ } }
    return;
  }
  if (ora <= ultimo) return;
  if (document.getElementById('lvFesta')) return;
  /* 0.9.264, Andrea: UN LIVELLO ALLA VOLTA. Se i punti ne fanno salire piu' d'uno, si festeggia il
     prossimo; quando la festa si chiude arriva quello dopo (lvFestaChiudi richiama questa funzione). */
  const prossimo = ultimo + 1;
  try{ localStorage.setItem(LV_FESTA_K, String(prossimo)); }catch(_){ }
  LV.festaAt = Date.now();
  const dati = { level: ((prossimo - 1) % LV_PER_CICLO) + 1, prestigio: Math.floor((prossimo - 1) / LV_PER_CICLO), salti: salto === null ? 1 : prossimo - salto, da: salto };
  /* a schermo spento si aspetta che torni visibile: un popup che nessuno vede e' un popup perso */
  /* 0.9.401 BUG-191: la festa del livello aspetta la fine di un momento protetto (onboarding, scelte, storie, livelli: socialproof.js) */
  const via = function(){ setTimeout(function(){ if (typeof flDopoProtetto === 'function') flDopoProtetto(function(){ lvFestaApri(dati); }, 'lv-festa-' + prossimo); else lvFestaApri(dati); }, 450); };
  if (document.hidden){
    const f = function(){ if (!document.hidden){ document.removeEventListener('visibilitychange', f); via(); } };
    document.addEventListener('visibilitychange', f);
  } else via();
}
function lvFestaFrase(level, prestigio){ return lvDati(level, prestigio).frase; }
/** I premi sbloccati fra due livelli assoluti (prestigio x 50 + livello), escluso il primo: per il popup della scala nuova. */
function lvPremiFra(da, a){
  const out = [];
  for (let k = da + 1; k <= a; k++){ const n = ((k - 1) % LV_PER_CICLO) + 1, p = Math.floor((k - 1) / LV_PER_CICLO); const x = lvDati(n, p); if (x.perk && out.indexOf(x.perk) < 0) out.push(x.perk); }
  return out;
}
/** Il popup. dati = { level, prestigio, salti }; senza argomenti mostra il livello di adesso. */
function lvFestaApri(dati){
  /* 0.9.290, Andrea: "per il livello sbloccato voglio la vibrazione" */
  try{ flVibra([30, 60, 30, 60, 120]); }catch(_){ }
  dati = dati || { level: LV.level, prestigio: LV.prestigio || 0, salti: 1 };
  const l = LV_LEVELS[dati.level - 1]; if (!l) return;
  const d = lvDati(dati.level, dati.prestigio);
  /* con la scala nuova si puo' salire di piu' gradini in un colpo: il popup e' uno, e dice tutto quello che si e' aperto */
  const premi = (dati.da != null && dati.salti > 1) ? lvPremiFra(dati.da, (dati.prestigio || 0) * LV_PER_CICLO + dati.level) : (d.perk ? [d.perk] : []);
  lvFestaChiudi(true);
  LV.festa = dati;
  const w = document.createElement('div');
  w.id = 'lvFesta'; w.className = 'lvf-w';
  w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true'); w.setAttribute('aria-label', 'Livello ' + dati.level);
  w.innerHTML = '<canvas class="lvf-cv" id="lvfCv"></canvas>'
    + '<div class="lvf-card">'
    +   '<button type="button" class="lvf-x" aria-label="Chiudi" onclick="lvFestaChiudi()">✕</button>'
    +   '<div class="lvf-badge">' + d.emblema(124) + '<b>' + dati.level + '</b></div>'
    +   (dati.prestigio ? '<div class="lvf-stelle">' + lvStelle(dati.prestigio) + '</div>' : '')
    +   '<small class="lvf-liv">' + (dati.prestigio ? 'Prestigio ' + dati.prestigio + ' · ' : '') + 'Livello ' + dati.level + '</small>'
    +   '<h2>' + esc(d.nome) + '</h2>'
    +   (dati.salti > 1 ? '<small class="lvf-salto">Con la scala nuova dei livelli sei salito di ' + dati.salti + ' gradini</small>' : '')
    +   '<p>' + esc(d.frase) + '</p>'
    +   (premi.length ? '<div class="lvf-perk"><small>' + (premi.length > 1 ? 'Sbloccati' : 'Sbloccato') + '</small>'
          + premi.slice(0, 3).map(function(t){ return '<b>' + esc(t) + '</b>'; }).join('')
          + (premi.length > 3 ? '<b class="lvf-altri">' + (premi.length === 4 ? 'e un altro' : 'e altri ' + (premi.length - 3)) + ', nella pagina dei livelli</b>' : '') + '</div>' : '')
    +   '<button type="button" class="lvf-share" onclick="lvFestaCondividi()">Condividi</button>'
    + '</div>';
  w.addEventListener('click', function(e){ if (e.target === w) lvFestaChiudi(); });
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ flVibra([30, 40, 30, 40, 90]); }catch(_){ }
  lvFestaCoriandoli(document.getElementById('lvfCv'));
}
function lvFestaChiudi(subito){
  const w = document.getElementById('lvFesta'); if (!w) return;
  if (w._raf) cancelAnimationFrame(w._raf);
  w._fine = true;
  if (subito === true){ w.remove(); return; }
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 260);
  /* il livello dopo, se i punti ne avevano fatti salire piu' d'uno */
  setTimeout(function(){ try{ lvFestaControlla(); }catch(_){ } }, 700);
}
/* 0.9.299, Andrea: "quando si clicca su Congratulati ci devono essere i coriandoli, gli stessi di quando si sale di
   livello, prima del messaggio". Gli stessi cannoni della festa del livello, su una tela che non si tocca. */
function flCoriandoli(){
  try{
    const vecchia = document.getElementById('flFesta'); if (vecchia){ vecchia._fine = true; vecchia.remove(); }
    const d = document.createElement('div');
    d.id = 'flFesta';
    d.style.cssText = 'position:fixed;inset:0;z-index:9700;pointer-events:none';
    const cv = document.createElement('canvas');
    d.appendChild(cv);
    document.body.appendChild(d);
    lvFestaCoriandoli(cv, d);
    setTimeout(function(){ d._fine = true; d.remove(); }, 2700);
  }catch(_){ }
  return Date.now();
}
/* I coriandoli: sparati dal basso verso l'alto da tre cannoni, poi la gravita' li riporta giu'.
   Colori del brand piu' l'oro; due secondi e mezzo, poi la tela si spegne. */
function lvFestaCoriandoli(cv, casa){
  if (!cv) return;
  const w = casa || document.getElementById('lvFesta');
  let ridotto = false; try{ ridotto = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); }catch(_){ }
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const W = window.innerWidth, H = window.innerHeight;
  cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
  const x = cv.getContext('2d'); if (!x) return;
  x.scale(dpr, dpr);
  const COL = ['#E63946', '#0075E3', '#F5B301', '#FFD166', '#FFFFFF', '#5B8DEF'];
  const N = ridotto ? 40 : 150;
  const P = [];
  for (let i = 0; i < N; i++){
    const lato = i % 3;                       // 0 = centro, 1 = sinistra, 2 = destra
    const sx = lato === 0 ? W / 2 : (lato === 1 ? W * 0.12 : W * 0.88);
    const ang = -Math.PI / 2 + (lato === 1 ? 0.35 : (lato === 2 ? -0.35 : 0)) + (Math.random() - 0.5) * 0.9;
    const v = (H * 0.016) + Math.random() * (H * 0.012);
    P.push({ x: sx + (Math.random() - 0.5) * 30, y: H + 10, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v,
      w: 6 + Math.random() * 6, h: 9 + Math.random() * 8, r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.35,
      c: COL[i % COL.length], tondo: Math.random() < 0.25, ritardo: Math.floor(Math.random() * 14) });
  }
  const DUR = 2500; let t0 = 0;
  const giro = function(t){
    if (!w || w._fine) return;
    if (!t0) t0 = t;
    const dt = t - t0;
    x.clearRect(0, 0, W, H);
    x.globalAlpha = dt > DUR - 500 ? Math.max(0, (DUR - dt) / 500) : 1;
    P.forEach(function(p){
      if (p.ritardo > 0){ p.ritardo--; return; }
      p.vy += H * 0.00045; p.vx *= 0.99; p.vy *= 0.992;
      p.x += p.vx + Math.sin((t + p.r * 100) / 220) * 0.6; p.y += p.vy; p.r += p.vr;
      x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c;
      if (p.tondo){ x.beginPath(); x.arc(0, 0, p.w / 2, 0, 6.283); x.fill(); }
      else x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * Math.abs(Math.cos(p.r * 1.7)) + 2);
      x.restore();
    });
    if (dt < DUR) w._raf = requestAnimationFrame(giro);
    else x.clearRect(0, 0, W, H);
  };
  w._raf = requestAnimationFrame(giro);
}
/** L'emblema come immagine, per il canvas: l'SVG passa da un indirizzo data. */
function lvEmblemaImmagine(n, size){
  return new Promise(function(fine){
    try{
      const svg = lvEmblema(n, size).replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ');
      const img = new Image();
      const t = setTimeout(function(){ fine(null); }, 1500);
      img.onload = function(){ clearTimeout(t); fine(img); };
      img.onerror = function(){ clearTimeout(t); fine(null); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    }catch(_){ fine(null); }
  });
}
/** La card da condividere: bianca, come quella della serie (sdSerieCanvas). */
async function lvFestaCanvas(){
  const d = LV.festa || { level: LV.level, prestigio: LV.prestigio || 0 };
  const l = LV_LEVELS[d.level - 1] || LV_LEVELS[0];
  const W = 900, H = 1300, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  x.fillStyle = '#ffffff'; x.fillRect(0, 0, W, H);
  x.textAlign = 'center'; x.textBaseline = 'alphabetic';
  x.fillStyle = '#0075E3'; x.font = '900 64px sans-serif'; x.fillText('DreamMap', W / 2, 140);
  /* 0.9.397: l'emblema del livello, lo stesso SVG del popup, disegnato sulla card */
  const em = await lvEmblemaImmagine(d.level, 400);
  if (em) x.drawImage(em, W / 2 - 200, 200, 400, 400);
  else { x.beginPath(); x.arc(W / 2, 400, 170, 0, 6.283); x.fillStyle = '#0075E3'; x.fill(); }
  if (d.prestigio){ x.fillStyle = '#F5B301'; x.font = '700 46px sans-serif'; x.fillText(lvStelle(d.prestigio), W / 2, 640); }
  x.fillStyle = '#E63946'; x.font = '900 120px sans-serif'; x.fillText('Livello ' + d.level, W / 2, 790);
  x.fillStyle = '#001E44'; x.font = '800 64px sans-serif'; x.fillText(lvDati(d.level, d.prestigio).nome, W / 2, 880);
  /* la frase, mandata a capo a mano: il canvas non lo fa */
  x.fillStyle = '#4A5A72'; x.font = '600 38px sans-serif';
  const parole = lvFestaFrase(d.level, d.prestigio).split(' '); const righe = []; let r = '';
  parole.forEach(function(p){ const t = r ? r + ' ' + p : p; if (x.measureText(t).width > W - 160 && r){ righe.push(r); r = p; } else r = t; });
  if (r) righe.push(r);
  righe.slice(0, 4).forEach(function(t, i){ x.fillText(t, W / 2, 970 + i * 52); });
  let nome = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = (u && u.name) ? String(u.name) : ''; }catch(_){ }
  const MESI = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic']; const g = new Date();
  x.fillStyle = '#6B7A90'; x.font = '700 42px sans-serif';
  x.textAlign = 'left'; x.fillText(nome ? '@' + nome.split(' ')[0] : 'DreamMap', 70, 1240);
  x.textAlign = 'right'; x.fillText(g.getDate() + ' ' + MESI[g.getMonth()] + ' ' + g.getFullYear(), W - 70, 1240);
  return cv;
}
async function lvFestaCondividi(){
  const d = LV.festa || { level: LV.level, prestigio: LV.prestigio || 0 };
  const l = LV_LEVELS[d.level - 1] || LV_LEVELS[0];
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const url = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/dreammap') + (code ? '?invito=' + encodeURIComponent(code) : '');
  const testo = 'Sono al livello ' + d.level + ' su DreamMap: ' + l.name + '. Tu a che livello sei?\n' + url;
  if (typeof flCondividiApri === 'function'){ flCondividiApri(lvFestaCanvas, testo, 'Condividi il livello'); return; }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'DreamMap' }); } }catch(_){ }
}
(function lvFestaStile(){
  const css = [
    /* sotto al foglio di condivisione (.qrw, 9995): «Condividi» lo apre sopra, e chiuso quello si torna qui */
    '.lvf-w{position:fixed;inset:0;z-index:9994;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,14,34,0);transition:background .25s}',
    '.lvf-w.in{background:rgba(0,14,34,.66)}',
    '.lvf-cv{position:fixed;inset:0;pointer-events:none;z-index:2}',
    '.lvf-card{position:relative;z-index:1;width:100%;max-width:340px;box-sizing:border-box;padding:30px 22px 20px;border-radius:26px;background:#FFFFFF;color:#001E44;text-align:center;',
    '  box-shadow:0 24px 60px rgba(0,0,0,.35);transform:scale(.82);opacity:0;transition:transform .42s cubic-bezier(.2,1.4,.4,1),opacity .25s}',
    '.lvf-w.in .lvf-card{transform:scale(1);opacity:1}',
    '.lvf-x{position:absolute;right:12px;top:12px;width:34px;height:34px;border:0;border-radius:50%;background:rgba(0,30,68,.07);color:#001E44;font-size:15px;cursor:pointer}',
    '.lvf-badge{position:relative;width:124px;height:124px;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;filter:drop-shadow(0 10px 18px rgba(0,30,68,.3));animation:lvfEm .7s cubic-bezier(.2,1.5,.4,1) both .12s}',
    '.lvf-badge .lv-em{display:block}',
    '@keyframes lvfEm{0%{transform:scale(.4) rotate(-14deg);opacity:0}100%{transform:none;opacity:1}}',
    '@media (prefers-reduced-motion: reduce){.lvf-badge{animation:none}}',
    '.lvf-salto{display:block;margin:-2px 0 12px;font:700 12.5px var(--font-body);color:#0075E3}',
    'body.dark .lvf-salto{color:#8CC6FF}',
    '.lvf-perk b + b{margin-top:6px}',
    '.lvf-perk .lvf-altri{font-weight:600;color:#6B7A90}',
    '.lvf-badge b{position:absolute;right:-8px;bottom:-6px;min-width:38px;height:38px;padding:0 6px;box-sizing:border-box;border-radius:99px;background:#E63946;color:#FFFFFF;border:3px solid #FFFFFF;display:flex;align-items:center;justify-content:center;font:800 17px var(--font-display)}',
    '.lvf-stelle{font-size:15px;letter-spacing:3px;color:#F5B301;margin-bottom:4px}',
    '.lvf-liv{display:block;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#E63946}',
    '.lvf-card h2{margin:6px 0 10px;font:800 28px/1.15 var(--font-display);font-style:italic;color:#001E44}',
    '.lvf-card p{margin:0 4px;font:500 14.5px/1.5 var(--font-body);color:#4A5A72}',
    '.lvf-perk{margin:16px 0 0;padding:10px 12px;border-radius:14px;background:rgba(0,117,227,.08)}',
    '.lvf-perk small{display:block;font:700 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#6B7A90}',
    '.lvf-perk b{display:block;margin-top:2px;font:700 13px/1.35 var(--font-body);color:#001E44}',
    '.lvf-share{display:block;width:100%;margin-top:20px;padding:14px;border:0;border-radius:99px;background:#0075E3;color:#FFFFFF;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.3)}',
    'body.dark .lvf-card{background:#12203A;color:#FFFFFF}',
    'body.dark .lvf-card h2,body.dark .lvf-perk b{color:#FFFFFF}',
    'body.dark .lvf-card p{color:rgba(255,255,255,.78)}',
    'body.dark .lvf-x{background:rgba(255,255,255,.1);color:#FFFFFF}',
    'body.dark .lvf-badge b{border-color:#12203A}',
    'body.dark .lvf-perk{background:rgba(255,255,255,.07)}body.dark .lvf-perk small{color:rgba(255,255,255,.6)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
/** Il tasto indietro di Android chiude il popup prima di cambiare pagina (nav.js, handleBack). */
function lvFestaBack(){
  if (!document.getElementById('lvFesta')) return false;
  /* se sopra c'e' il foglio di condivisione, indietro chiude prima quello */
  const sh = document.getElementById('accQrW');
  if (sh && typeof accQrChiudi === 'function'){ accQrChiudi(); return true; }
  lvFestaChiudi(); return true;
}

function lvProssimiHtml(info){
  const avanti = LV_LEVELS.filter(function(l){ return l.n > info.level; });
  const premio = avanti.filter(function(l){ return l.perk; })[0];
  const resto = (typeof LV.restoXp === 'number') ? LV.restoXp : (info.xp || 0);
  const da = premio ? Math.max(0, premio.xp - resto) : 0;
  /* 0.9.397: le righe hanno l'emblema del livello al posto del numero e delle emoji; quelle con un premio stanno accese */
  return (premio ? '<div class="lv-next"><span class="lv-next-em">' + lvEmblema(premio.n, 64) + '</span><div><small>Il prossimo premio</small><b>' + esc(premio.perk) + '</b><span>Al livello ' + premio.n + ' · ' + esc(premio.name) + (da ? ' · mancano ' + da + ' punti' : '') + '</span></div></div>' : '')
    + '<div class="sect"><b>Cosa sblocchi salendo</b></div><div class="lv-cammino">'
    + avanti.slice(0, 12).map(function(l){ const x = lvDati(l.n); return '<div class="lv-step' + (l.perk ? ' premio' : '') + '"><span class="lv-step-em">' + x.emblema(44) + '</span><div><b>' + esc(l.perk ? l.perk : 'Livello ' + l.n + ' · ' + x.nome) + '</b><small>' + (l.perk ? 'Livello ' + l.n + ' · ' + esc(x.nome) : esc(x.famiglia) + ', grado ' + x.grado + ' di 5') + ' · ' + l.xp + ' punti</small></div></div>'; }).join('')
    + '</div>';
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.lv-next{display:flex;align-items:center;gap:16px;margin:26px 0 6px;padding:18px;border-radius:20px;background:linear-gradient(160deg,#0075E3,#001E44 80%);color:#fff;text-align:left}.lv-next-em{flex:none;width:64px;height:64px;display:block;filter:drop-shadow(0 4px 10px rgba(0,0,0,.35))}.lv-next-em .lv-em{display:block}.lv-next > div{flex:1;min-width:0}.lv-next small{display:block;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.lv-next b{display:block;margin:6px 0 6px;font:800 18px/1.3 var(--font-display);color:#fff}.lv-next span{font:600 13.5px var(--font-body);color:rgba(232,241,255,.85)}'
  + '.lv-cammino{display:flex;flex-direction:column;gap:8px}.lv-step{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;border:1px solid var(--line);background:var(--card,#fff)}.lv-step.premio{border-color:#3F9FF4;background:#F0FBFF}.lv-step-em{flex:none;width:44px;height:44px;display:block}.lv-step-em .lv-em{display:block}.lv-step:not(.premio) .lv-step-em{filter:grayscale(1);opacity:.62}.lv-step div{flex:1;min-width:0}.lv-step b{display:block;font:800 14px/1.3 var(--font-display);color:var(--navy)}.lv-step small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}'
  + 'body.dark .lv-step{background:#12203A;border-color:#22345A}body.dark .lv-step.premio{background:#14305E;border-color:#3F9FF4}body.dark .lv-step b{color:#fff}'; document.head.appendChild(st); })();
