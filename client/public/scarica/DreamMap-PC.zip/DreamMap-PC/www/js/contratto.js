/* ===========================================================================================
   IL CONTRATTO DI ABITUDINE (0.9.302, Andrea)

   "Schermata di blocco / contratto di abitudine: regola di tempo di attesa che aumenta in modo
   esponenziale per disincentivare la modifica delle regole; penitenza 2: schermata in bianco e
   nero che si applica su tutto; penitenza 3: soldi persi / donati ad un amico o in beneficenza
   se si sgarra."

   Un contratto con se stessi: cosa ci si impegna a non fare, su quali app, quanto tempo al giorno
   ci si concede, e le penitenze se si sgarra.
   - Penitenza 1, sempre: per allentare una regola di blocco si aspetta 1, 2, 4, 8... minuti (tetto
     24 ore, il conto torna a un minuto dopo 7 giorni senza richieste); finita l'attesa le regole
     restano aperte 15 minuti. Lo fa rispettare il telefono (Contratto.java + il plugin), non questa
     pagina: chiudere l'app non accorcia niente.
   - Penitenza 2: uno sgarro mette in bianco e nero TUTTO il telefono per le ore scelte (Greyscale).
   - Penitenza 3: i soldi passano dal patto (patto.js, dreammapPatti.ts) con la verifica
     "contratto": un giorno con uno sgarro e' un giorno mancato. Il garante lo sa subito, e chi si
     impegna gli paga i soldi con la sua app (PayPal, Revolut, Satispay, bonifico) entro 48 ore:
     DreamMap non tocca i soldi, fa solo da arbitro (22/11/2026).
   - Penitenza 4, se non paga il garante entro 48 ore: sempre un punto al vecchio te ("non hai
     mantenuto la parola data"), piu' quello che ha scelto alla firma: bianco e nero, modalita'
     severa, la serie che riparte da zero (nonPaga nel contratto, patPenitenza in patto.js).
   - Cosa conta come sgarro: il terzo tentativo del giorno di aprire un'app del contratto bloccata,
     il tempo di oggi oltre il limite, una regola spenta nella finestra (o lo sblocco di emergenza
     della modalita' severa). Uno per tipo e per app al giorno.

   Nel browser (e sul computer) il motore e' CTR_LOCALE, con le stesse regole, su localStorage:
   li' non blocca niente, serve all'anteprima e alle prove.
   =========================================================================================== */
const CTR = { s: null, w: null, passo: 0, tick: 0, appTutte: null, cerca: '', patto: null };
const CTR_ICO = '📜';
const CTR_I = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
const CTR_X = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const CTR_CHEV = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
const CTR_REGOLE = { tettoMin: 1440, finestraMin: 15, azzeraGiorni: 7, tentativi: 3 };

function ctrEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function ctrNativo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.contrattoStato === 'function'; }

/* ---------------------------------------------------------------------------------------
   IL MOTORE NEL BROWSER: le stesse regole di Contratto.java
   --------------------------------------------------------------------------------------- */
const CTR_LOCALE = (function(){
  const K = 'fl_contratto_web', MIN = 60000, ORA = 3600000, GIORNO = 86400000;
  const leggi = function(){ try{ return JSON.parse(localStorage.getItem(K) || '{}') || {}; }catch(_){ return {}; } };
  const scrivi = function(d){ try{ localStorage.setItem(K, JSON.stringify(d)); }catch(_){ } };
  const giorno = function(ms){ const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const attesaMinuti = function(n){ n = Math.max(0, n | 0); return n >= 11 ? CTR_REGOLE.tettoMin : Math.min(CTR_REGOLE.tettoMin, Math.pow(2, n)); };
  const nValido = function(d, ora){ return (!d.ultimaRichiesta || ora - d.ultimaRichiesta >= CTR_REGOLE.azzeraGiorni * GIORNO) ? 0 : (d.n || 0); };
  const firmato = function(d){ const k = d.c || {}; return !!k.attivo && Date.now() < (k.fineAt || Infinity); };
  /* 0.9.340: con un amico come garante il contratto vale da quando l'amico firma */
  const vigore = function(d){ const k = d.c || {}, s = k.soldi || {}; return s.tipo !== 'amico' || +k.garanteAt > 0; };
  const attivo = function(d){ return firmato(d) && vigore(d); };
  const finestra = function(d, ora){ return d.attesaFino > 0 && ora >= d.attesaFino && ora < d.attesaFino + CTR_REGOLE.finestraMin * MIN; };
  const apps = function(k){ return ((k && k.apps) || []).map(function(a){ return String(a.p || a).toLowerCase(); }); };
  const euro = function(k){ const s = (k && k.soldi) || {}; return s.tipo && s.tipo !== 'nessuno' ? (+s.euro || 0) : 0; };
  const indebolisce = function(a, b){
    const dopo = apps(b);
    if (apps(a).some(function(p){ return dopo.indexOf(p) < 0; })) return true;
    if ((+b.limiteMin || 0) > (+a.limiteMin || 0)) return true;
    if ((+b.grigioOre || 0) < (+a.grigioOre || 0)) return true;
    if (euro(b) < euro(a)) return true;
    return (b.fineAt || 0) < (a.fineAt || 0);
  };
  const messaggio = function(d){
    const ora = Date.now();
    if (d.attesaFino > ora) return T('Il tuo contratto di abitudine protegge questa regola. Mancano {n} minuti alla fine dell’attesa.', { n: Math.max(1, Math.ceil((d.attesaFino - ora) / MIN)) });
    return T('Il tuo contratto di abitudine protegge questa regola. Per cambiarla chiedi la modifica e aspetta {durata}.', { durata: ctrDurata(attesaMinuti(nValido(d, ora))) });
  };
  const stato = function(){
    const d = leggi(), ora = Date.now(), n = nValido(d, ora);
    return { contratto: d.c || {}, attivo: attivo(d), inAttesaGarante: firmato(d) && !vigore(d), adesso: ora, n: n, prossimaAttesaMin: attesaMinuti(n), attesaFino: d.attesaFino || 0, attesaMin: d.attesaMin || 0,
      finestraFino: d.attesaFino ? d.attesaFino + CTR_REGOLE.finestraMin * MIN : 0, ultimaRichiesta: d.ultimaRichiesta || 0, grigioFino: d.grigioFino || 0,
      sgarri: d.sgarri || [], tentativi: (d.t && d.t.g === giorno(ora)) ? d.t.c : {}, regole: CTR_REGOLE, permessoGrigio: true, locale: true };
  };
  const rifiuta = function(msg){ const e = new Error(msg); e.code = 'contract-wait'; return Promise.reject(e); };
  const api = {
    attesaMinuti: attesaMinuti,
    contrattoStato: function(){ return Promise.resolve(stato()); },
    contrattoFirma: function(o){
      const d = leggi(), ora = Date.now(), nuovo = JSON.parse(JSON.stringify((o && o.contratto) || {}));
      const giorni = Math.max(1, Math.min(365, +nuovo.giorni || 30));
      nuovo.attivo = true;
      if (attivo(d)){
        nuovo.firmatoAt = d.c.firmatoAt; nuovo.fineAt = nuovo.fineAt || d.c.fineAt;
        if (!finestra(d, ora) && indebolisce(d.c, nuovo)) return rifiuta(messaggio(d));
      } else { nuovo.firmatoAt = ora; nuovo.fineAt = ora + giorni * GIORNO; d.attesaFino = 0; }
      d.c = nuovo; scrivi(d); return Promise.resolve(stato());
    },
    contrattoChiedi: function(){
      const d = leggi(), ora = Date.now();
      if (attivo(d) && !(d.attesaFino > ora) && !finestra(d, ora)){
        const n = nValido(d, ora), m = attesaMinuti(n);
        d.n = n + 1; d.ultimaRichiesta = ora; d.attesaFino = ora + m * MIN; d.attesaMin = m; scrivi(d);
      }
      return Promise.resolve(stato());
    },
    contrattoRitira: function(){ const d = leggi(); if (firmato(d) && !vigore(d)){ d.c.attivo = false; d.c.ritiratoAt = Date.now(); d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoAnnulla: function(){ const d = leggi(); if (d.attesaFino > Date.now()){ d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoChiudi: function(){ const d = leggi(); if (finestra(d, Date.now())){ d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoStrappa: function(){
      const d = leggi(); if (!attivo(d)) return Promise.resolve(stato());
      if (!finestra(d, Date.now())) return rifiuta(messaggio(d));
      d.c.attivo = false; d.c.strappatoAt = Date.now(); scrivi(d); return Promise.resolve(stato());
    },
    /* nel browser nessuno vede le app: le prove chiamano queste due al posto del servizio */
    sgarro: function(tipo, pkg, nome, cosa){
      const d = leggi(); if (!attivo(d)) return false;
      const ora = Date.now(), g = giorno(ora), chiave = g + ':' + tipo + ':' + (pkg || '');
      d.fatti = (d.fatti && d.fatti.g === g) ? d.fatti : { g: g, l: [] };
      if (d.fatti.l.indexOf(chiave) >= 0) return false;
      d.fatti.l.push(chiave);
      const k = d.c, ore = +k.grigioOre || 0, s = { t: ora, g: g, k: tipo, n: nome || pkg || '', c: cosa || '', grigioOre: ore };
      if (pkg) s.p = pkg;
      if (k.soldi && k.soldi.tipo && k.soldi.tipo !== 'nessuno'){ s.euro = +k.soldi.euro || 0; s.a = k.soldi.a || ''; s.dest = k.soldi.tipo; }
      d.sgarri = [s].concat(d.sgarri || []).slice(0, 300);
      if (ore > 0) d.grigioFino = Math.max(d.grigioFino || 0, ora + ore * ORA);
      scrivi(d); return true;
    },
    tentativo: function(pkg, nome){
      const d = leggi(); if (!attivo(d) || apps(d.c).indexOf(String(pkg).toLowerCase()) < 0) return;
      const g = giorno(Date.now());
      d.t = (d.t && d.t.g === g) ? d.t : { g: g, c: {} };
      d.t.c[pkg] = (d.t.c[pkg] || 0) + 1; scrivi(d);
      if (d.t.c[pkg] >= CTR_REGOLE.tentativi) api.sgarro('tentativo', pkg, nome, T('{n} tentativi di aprirla oggi', { n: d.t.c[pkg] }));
    },
    /* 22/11/2026: la penitenza di un debito non pagato al garante (come Contratto.penitenzaGrigio) */
    contrattoGrigio: function(o){ const d = leggi(), h = Math.max(0, Math.min(72, +((o || {}).ore) || 0)); if (h){ d.grigioFino = Math.max(d.grigioFino || 0, Date.now() + h * ORA); scrivi(d); } return Promise.resolve(stato()); },
    modificaConcessa: function(){ const d = leggi(); return !attivo(d) || finestra(d, Date.now()); },
    messaggio: function(){ return messaggio(leggi()); }
  };
  return api;
})();
window.CTR_LOCALE = CTR_LOCALE;
function ctrMotore(){ return ctrNativo() ? NATIVE : CTR_LOCALE; }

/* ---------------------------------------------------------------------------------------
   LE PAROLE
   --------------------------------------------------------------------------------------- */
/* 22/11/2026: le parole passano da T() (lingua.js): in italiano restano identiche, nelle altre lingue arrivano tradotte */
function ctrLoc(){ try{ return (typeof ltLingua === 'function') ? ltLingua() : 'it-IT'; }catch(_){ return 'it-IT'; } }
function ctrIt(){ try{ return (typeof ltItaliano === 'function') ? ltItaliano() : true; }catch(_){ return true; } }
/** "a, b e c" nella lingua di chi legge (Intl.ListFormat; in italiano: "a, b e c"). */
function ctrLista(l){
  l = (l || []).filter(function(x){ return x !== '' && x != null; }).map(String);
  if (l.length <= 1) return l[0] || '';
  try{ return new Intl.ListFormat(ctrLoc(), { style: 'long', type: 'conjunction' }).format(l); }
  catch(_){ return T('{lista} e {ultimo}', { lista: l.slice(0, -1).join(', '), ultimo: l[l.length - 1] }); }
}
/** Euro interi (5 -> "5 €", "€5"...). */
function ctrEuro(e){ return (typeof ltEuro === 'function') ? ltEuro((+e || 0) * 100) : (+e || 0) + ' €'; }
function ctrMaiuscola(t){ t = String(t || ''); return t.charAt(0).toUpperCase() + t.slice(1); }
function ctrDurata(min){
  min = Math.round(min);
  if (min < 60) return min === 1 ? T('un minuto') : T('{n} minuti', { n: min });
  const h = Math.floor(min / 60), m = min % 60;
  const s = h === 1 ? T('un’ora') : T('{n} ore', { n: h });
  return m ? T('{ore} e {n} minuti', { ore: s, n: m }) : s;
}
function ctrConto(ms){
  const t = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(s).padStart(2, '0');
}
function ctrData(ms){ try{ return new Date(ms).toLocaleDateString(ctrLoc(), { day: 'numeric', month: 'long' }); }catch(_){ return new Date(ms).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }); } }
function ctrOra(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function ctrQuando(ms){
  const d = new Date(ms), oggi = new Date(); const ieri = new Date(Date.now() - 86400000);
  const st = function(a, b){ return a.toDateString() === b.toDateString(); };
  if (st(d, oggi)) return T('Oggi alle {ora}', { ora: ctrOra(ms) });
  if (st(d, ieri)) return T('Ieri alle {ora}', { ora: ctrOra(ms) });
  let g = ''; try{ g = d.toLocaleDateString(ctrLoc(), { weekday: 'long', day: 'numeric', month: 'long' }); }catch(_){ g = d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' }); }
  return T('{giorno} alle {ora}', { giorno: ctrMaiuscola(g), ora: ctrOra(ms) });
}
function ctrNomiApp(k){ return ctrLista(((k && k.apps) || []).map(function(x){ return x.n || x.p; })); }
function ctrLimiteTxt(k){
  const l = +k.limiteMin || 0;
  return l ? T('Al massimo {durata} al giorno su {app}', { durata: ctrDurata(l), app: ctrNomiApp(k) }) : T('Su {app} neanche un minuto', { app: ctrNomiApp(k) });
}
function ctrSoldiTxt(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return '';
  if (s.tipo === 'beneficenza') return T('{euro} in beneficenza a {chi}', { euro: ctrEuro(s.euro), chi: s.a || T('un ente') });
  return T('{euro} a {chi}', { euro: ctrEuro(s.euro), chi: s.a || T('un amico') });
}
/** 22/11/2026: la penitenza se non si paga il garante entro 48 ore. Il punto al vecchio te c'e' sempre. */
function ctrNonPaga(k){ const n = (k && k.nonPaga) || {}; return { grigioOre: +n.grigioOre || 0, severaOre: +n.severaOre || 0, serie: !!n.serie }; }
function ctrNonPagaTxt(k, io){
  const n = ctrNonPaga(k), l = [io ? T('un punto al vecchio me') : T('un punto al vecchio te')];
  if (n.grigioOre) l.push(io ? T('il mio telefono in bianco e nero per {durata}', { durata: ctrDurata(n.grigioOre * 60) }) : T('il telefono in bianco e nero per {durata}', { durata: ctrDurata(n.grigioOre * 60) }));
  if (n.severaOre) l.push(T('la modalità severa per {durata}', { durata: ctrDurata(n.severaOre * 60) }));
  if (n.serie) l.push(io ? T('la mia serie che riparte da zero') : T('la serie che riparte da zero'));
  return ctrLista(l);
}
function ctrSgarroTit(x){
  if (x.k === 'tentativo') return T('Hai provato ad aprire {app}', { app: x.n || T('un’app del contratto') });
  if (x.k === 'limite') return T('Hai superato il limite su {app}', { app: x.n || T('un’app del contratto') });
  return /emergenza/i.test(x.c || '') ? T('Hai usato lo sblocco di emergenza') : T('Hai spento una regola');
}

/* ---------------------------------------------------------------------------------------
   LO STATO
   --------------------------------------------------------------------------------------- */
async function ctrCarica(){
  try{ CTR.s = await ctrMotore().contrattoStato(); }catch(_){ CTR.s = CTR.s || null; }
  if (CTR.s && CTR.s.regole) Object.assign(CTR_REGOLE, CTR.s.regole);
  ctrGrigioWeb();
  return CTR.s;
}
function ctrAttivo(){ return !!(CTR.s && CTR.s.attivo); }
/* Nel browser e sul computer il bianco e nero di sistema non c'e': la penitenza scolora la pagina. */
function ctrGrigioWeb(){
  try{ const on = !!(CTR.s && CTR.s.locale && CTR.s.grigioFino > Date.now()); document.documentElement.classList.toggle('ctr-grigio', on); }catch(_){ }
}
/** Il verdetto di un giorno per il patto con la verifica "contratto": false con uno sgarro, true a giorno finito, null prima. */
async function ctrVerdetto(giorno){
  const s = await ctrCarica(); if (!s) return null;
  if ((s.sgarri || []).some(function(x){ return x.g === giorno; })) return false;
  const fine = new Date(giorno + 'T00:00:00').getTime() + 86400000;
  /* un giorno finito prima della firma non dice niente */
  const firmato = +((s.contratto || {}).firmatoAt) || 0;
  if (!firmato || firmato >= fine) return null;
  return Date.now() >= fine ? true : null;
}

/* ---------------------------------------------------------------------------------------
   LE SCHERMATE
   --------------------------------------------------------------------------------------- */
registerScreen('s-contratto', '<div class="topbar ctr-top"><button class="iconbtn" onclick="flIndietro()" aria-label="' + T('Indietro') + '">' + CTR_I + '</button><b class="blk-title" id="ctrTit">' + T('Contratto di abitudine') + '</b><button type="button" class="iconbtn ctr-i" onclick="ctrSgarriInfo()" aria-label="' + T('Cosa conta come sgarro') + '"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg></button></div><div id="ctrBody"></div><div class="spacer"></div>');
registerScreen('s-contratto-nuovo', '<div class="topbar ctr-top"><button class="iconbtn" onclick="ctrIndietroW()" aria-label="' + T('Indietro') + '">' + CTR_I + '</button><b class="blk-title" id="ctrWTit">' + T('Il tuo contratto') + '</b><span class="iconbtn ctr-vuota" aria-hidden="true"></span></div><div class="md-prog" id="ctrProg"></div><div id="ctrW"></div><div class="spacer"></div>', { back: function(){ ctrIndietroW(); return null; } });
registerScreen('s-contratto-attesa', '<div id="ctrA"></div>', { back: function(){ ctrAttesaStop(); return 's-contratto'; } });

async function ctrApri(){
  goId('s-contratto');
  if (!CTR.s) ctrPaint();
  await ctrCarica(); ctrPaint();
  ctrPattoCarica();
}

function ctrPaint(){
  const host = document.getElementById('ctrBody'); if (!host) return;
  const s = CTR.s;
  const tt = document.getElementById('ctrTit'); if (tt) tt.textContent = T('Contratto di abitudine');
  if (!s){ host.innerHTML = '<p class="ctr-carica">' + T('Leggo il tuo contratto…') + '</p>'; return; }
  if (!s.attivo && !s.inAttesaGarante){ host.innerHTML = ctrVuotoHtml(s); return; }
  const k = s.contratto || {}, ora = Date.now();
  /* 0.9.340: finche' il garante non firma, il contratto e' una proposta: lo si vede, ma non protegge niente */
  if (s.inAttesaGarante){
    const chi = ((k.soldi || {}).a) || T('il tuo garante');
    host.innerHTML = '<div class="ctr-attesa-g"><span class="ctr-emo">\u270d\ufe0f</span><b>' + T('Il contratto entra in vigore quando {chi} lo firma', { chi: ctrEsc(chi) }) + '</b>'
      + '<p>' + T('Fino a quel momento le tue regole restano libere e gli sgarri non contano.') + '</p>'
      + (CTR.patto && CTR.patto.stato === 'attesa' ? '<button type="button" class="am-cta" onclick="patManda(' + CTR.patto.id + ')">' + T('Manda il contratto a {chi}', { chi: ctrEsc(chi) }) + '</button>' : '') + '</div>'
      + ctrDiplomaHtml()
      + '<button type="button" class="ctr-stampa" onclick="ctrStampa()">' + CTR_STAMPA_ICO + T('Stampa il contratto') + '</button>';
    ctrDiplomaRiempi();
    return;
  }
  const grigio = s.grigioFino > ora;
  const inCorso = s.attesaFino > 0 && s.finestraFino > ora;
  host.innerHTML = (inCorso ? ctrStatoHtml(s) : '')
    + ctrDiplomaHtml()
    + '<h3 class="ctr-sez">' + T('Se sgarri') + '</h3>'
    + '<div class="ctr-pen">'
    +   ctrPenRiga('1', T('Le regole si cambiano dopo un’attesa'), T('La prossima attesa è di {durata}, poi raddoppia', { durata: ctrDurata(s.prossimaAttesaMin) }))
    +   ctrPenRiga('2', (+k.grigioOre ? T('Bianco e nero per {durata}', { durata: ctrDurata(k.grigioOre * 60) }) : T('Niente bianco e nero')), grigio ? (new Date(s.grigioFino).toDateString() !== new Date().toDateString() ? T('In corso fino alle {ora} di {data}', { ora: ctrOra(s.grigioFino), data: ctrData(s.grigioFino) }) : T('In corso fino alle {ora}', { ora: ctrOra(s.grigioFino) })) : (+k.grigioOre ? T('Su tutto il telefono, dopo ogni sgarro') : T('L’hai scelto tu alla firma')), grigio)
    +   ctrPenRiga('3', ctrSoldiTxt(k) ? T('{soldi} per ogni giorno con uno sgarro', { soldi: ctrSoldiTxt(k) }) : T('Niente soldi'), ctrSoldiNota(k))
    +   (+((k.soldi || {}).euro) > 0 && (k.soldi || {}).tipo === 'amico' ? ctrPenRiga('4', T('Se non paghi {chi} entro 48 ore', { chi: (k.soldi || {}).a || T('il tuo garante') }), T('{penitenza}. Non hai mantenuto la parola data', { penitenza: ctrMaiuscola(ctrNonPagaTxt(k)) })) : '')
    + '</div>'
    + ctrPattoHtml(k)
    + ctrStoricoHtml(s.sgarri || [])
    + (inCorso ? '' : ctrStatoHtml(s))
    /* 0.9.340, Andrea: "una volta creato il contratto non si deve poter stracciare: si puo' stampare, che e' diverso" */
    + '<button type="button" class="ctr-stampa" onclick="ctrStampa()">' + CTR_STAMPA_ICO + T('Stampa il contratto') + '</button>';
  ctrDiplomaRiempi();
}
/* 0.9.369, Andrea: "nella pagina il contratto e' un pannello bianco, e solo stampandolo diventa il diploma professionale: deve essere il
   diploma da subito". La pagina mostra lo stesso foglio della stampa (ctrStampaCanvas), come immagine */
function ctrDiplomaHtml(){ return '<div class="ctr-diploma" id="ctrDiploma"><div class="ctr-diploma-c">' + T('Preparo il contratto…') + '</div></div>'; }
async function ctrDiplomaRiempi(){
  const h = document.getElementById('ctrDiploma'); if (!h) return;
  try{ const cv = await ctrStampaCanvas(); const u = cv.toDataURL('image/png'); const b = document.getElementById('ctrDiploma'); if (b) b.innerHTML = '<img src="' + u + '" alt="' + ctrEsc(T('Il tuo contratto di abitudine')) + '">'; }catch(_){ }
}
const CTR_STAMPA_ICO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/></svg>';
/* STAMPA: il contratto su un foglio, come immagine da salvare o mandare (lo stesso foglio di condivisione del profilo) */
function ctrStampa(){
  if (typeof flCondividiApri !== 'function'){ toast(T('La stampa funziona nell’app sul telefono')); return; }
  flCondividiApri(ctrStampaCanvas, '', T('Il tuo contratto'));
}
async function ctrStampaCanvas(){
  const k = (CTR.s && CTR.s.contratto) || {};
  const W = 1000, H = 1400, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const x = cv.getContext('2d');
  x.fillStyle = '#FBF8F1'; x.fillRect(0, 0, W, H);
  x.strokeStyle = '#001E44'; x.lineWidth = 3; x.strokeRect(40, 40, W - 80, H - 80);
  x.lineWidth = 1; x.strokeRect(54, 54, W - 108, H - 108);
  x.textAlign = 'center'; x.fillStyle = '#0075E3'; x.font = '700 30px sans-serif'; x.fillText('DREAMMAP', W / 2, 140);
  x.fillStyle = '#001E44'; x.font = '800 58px serif'; x.fillText(T('Contratto di abitudine'), W / 2, 220);
  const righe = function(t, y, font, max, passo){
    x.font = font; const parole = String(t || '').split(/\s+/); let r = '';
    parole.forEach(function(p){ const prova = r ? r + ' ' + p : p; if (x.measureText(prova).width > max && r){ x.fillText(r, W / 2, y); y += passo; r = p; } else r = prova; });
    if (r){ x.fillText(r, W / 2, y); y += passo; }
    return y;
  };
  let y = 330;
  /* 22/11/2026: la frase si riscrive nella lingua di chi guarda; quella salvata alla firma resta per i contratti senza impegno */
  const fr = k.impegno ? ctrFrase(k.impegno) : (k.frase || ''), lungo = String(fr).length > 140;
  x.fillStyle = '#001E44'; y = righe(fr, y, lungo ? '600 33px serif' : '600 40px serif', W - 220, lungo ? 45 : 54);
  if (k.invece){ const inv = ctrIt() ? ctrMinuscola(k.invece) : k.invece; y += 18; x.fillStyle = '#0075E3'; y = righe(k.dopo ? T('{dopo}, al suo posto. {invece}.', { dopo: k.dopo, invece: inv }) : T('Al suo posto. {invece}.', { invece: inv }), y, 'italic 600 30px serif', W - 240, 42); }
  y += 26; x.fillStyle = '#4A5B74'; y = righe(ctrLimiteTxt(k), y, '500 30px sans-serif', W - 240, 42);
  y += 40;
  const pen = [];
  if (+k.grigioOre) pen.push(T('Se sgarro, il telefono va in bianco e nero per {durata}.', { durata: ctrDurata(k.grigioOre * 60) }));
  if (ctrSoldiTxt(k)) pen.push(T('Se sgarro, {soldi} per ogni giorno con uno sgarro, da pagare entro 48 ore.', { soldi: ctrMinuscola(ctrSoldiTxt(k)) }));
  if (+((k.soldi || {}).euro) > 0 && (k.soldi || {}).tipo === 'amico') pen.push(T('Se non pago {chi} entro 48 ore. {penitenza}.', { chi: (k.soldi || {}).a || T('il mio garante'), penitenza: ctrNonPagaTxt(k, true) }));
  pen.push(T('Le regole si cambiano solo dopo un’attesa che raddoppia ogni volta.'));
  x.fillStyle = '#001E44'; pen.forEach(function(p){ y = righe(p, y, '500 28px sans-serif', W - 260, 40) + 14; });
  /* 0.9.369, Andrea: "Firmato il 14 si sovrappone alle firme". La data sta sotto alle due firme, mai sopra */
  const fy = H - 260;
  if (k.firmatoAt){ x.fillStyle = '#4A5B74'; x.font = '500 24px sans-serif'; x.fillText(k.fineAt ? T('Firmato il {data}, valido fino al {fine}', { data: ctrData(k.firmatoAt), fine: ctrData(k.fineAt) }) : T('Firmato il {data}', { data: ctrData(k.firmatoAt) }), W / 2, fy + 110); }
  /* le due firme */
  x.strokeStyle = '#001E44'; x.lineWidth = 2;
  x.beginPath(); x.moveTo(120, fy); x.lineTo(450, fy); x.moveTo(550, fy); x.lineTo(880, fy); x.stroke();
  x.fillStyle = '#4A5B74'; x.font = '500 22px sans-serif'; x.fillText(T('firma di chi promette'), 285, fy + 36); x.fillText(T('firma del garante'), 715, fy + 36);
  let firma = ''; try{ firma = localStorage.getItem('fl_firma_mia') || ''; }catch(_){ firma = ''; }
  if (firma){ try{ const im = await new Promise(function(ok, ko){ const i = new Image(); i.onload = function(){ ok(i); }; i.onerror = ko; i.src = firma; }); const s = Math.min(320 / im.width, 110 / im.height); x.drawImage(im, 285 - im.width * s / 2, fy - 8 - im.height * s, im.width * s, im.height * s); }catch(_){ } }
  else { x.fillStyle = '#001E44'; x.font = 'italic 44px serif'; x.fillText((typeof patMioNome === 'function') ? patMioNome() : '', 285, fy - 20); }
  const g = (k.soldi || {}).a || '';
  if (g && +k.garanteAt){ x.fillStyle = '#001E44'; x.font = 'italic 44px serif'; x.fillText(g, 715, fy - 20); }
  return cv;
}
/* 0.9.340: il contratto entra in vigore quando il garante firma il patto sul server. Si controlla aprendo la pagina e all'avvio. */
async function ctrVigoreControlla(){
  try{
    const s = CTR.s || await ctrCarica();
    if (!s || !s.inAttesaGarante) return;
    const k = s.contratto || {}, id = (k.soldi || {}).pattoId;
    if (!id || typeof patCarica !== 'function' || typeof PAT === 'undefined') return;
    await patCarica();
    const p = (Array.isArray(PAT.lista) ? PAT.lista : []).filter(function(x){ return x.id === id; })[0];
    CTR.patto = p || CTR.patto || null;
    if (!p || p.stato !== 'attivo') return;
    const nuovo = JSON.parse(JSON.stringify(k)); nuovo.garanteAt = Date.now();
    CTR.s = await ctrMotore().contrattoFirma({ contratto: nuovo });
    try{ toast(T('{chi} ha firmato:\nil contratto è in vigore', { chi: ((k.soldi || {}).a) || T('Il tuo garante') })); }catch(_){ }
    if (document.getElementById('ctrBody')) ctrPaint();
  }catch(_){ }
}
/* 0.9.340, Andrea: "chiudimi il contratto che si e' creato: non l'ha firmato il mio garante e mi blocca il programma di
   WhatsApp". Una volta sola, per l'amministratore: la proposta non firmata si ritira e il patto in attesa si scioglie. */
async function ctrRitiroUnaTantum(){
  try{
    if (localStorage.getItem('fl_ctr_ritiro_340')) return;
    if (!(typeof flAdmin === 'function' && flAdmin())) return;
    const s = await ctrCarica(); if (!s) return;
    if (!s.inAttesaGarante){ localStorage.setItem('fl_ctr_ritiro_340', '1'); return; }
    const id = ((s.contratto || {}).soldi || {}).pattoId;
    const m = ctrMotore();
    if (typeof m.contrattoRitira === 'function') CTR.s = await m.contrattoRitira();
    if (id && typeof patApi === 'function'){ try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: id }); }catch(_){ } }
    localStorage.setItem('fl_ctr_ritiro_340', '1');
  }catch(_){ }
}
setTimeout(function(){ ctrRitiroUnaTantum().then(ctrVigoreControlla); }, 6000);
function ctrPenRiga(n, t, sub, acceso){
  return '<div class="ctr-pr' + (acceso ? ' on' : '') + '"><i>' + n + '</i><div><b>' + ctrEsc(t) + '</b><small>' + ctrEsc(sub || '') + '</small></div></div>';
}
function ctrSoldiNota(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return T('L’hai scelto tu alla firma');
  if (s.tipo === 'beneficenza') return T('Per ora è un impegno scritto. La donazione la fai tu');
  if (!(+s.euro > 0)) return T('{chi} lo sa lo stesso. L’app glielo dice', { chi: s.a || T('Il tuo garante') });
  return T('Glieli paghi tu, con la tua app, entro 48 ore. L’app gli dice che hai sgarrato');
}
function ctrVuotoHtml(s){
  const fatti = (s.sgarri || []).length;
  return '<div class="ctr-vuoto">'
    + '<span class="ctr-emo">' + CTR_ICO + '</span>'
    + '<h2>' + T('Firma un contratto con te stesso') + '</h2>'
    + '<p>' + T('Scrivi cosa non vuoi più fare. Se sgarri, paghi una penitenza che hai scelto tu.') + '</p>'
    + '<div class="ctr-pen">'
    +   ctrPenRiga('1', T('Le regole si cambiano solo dopo un’attesa'), T('Un minuto, poi due, poi quattro. Raddoppia ogni volta'))
    +   ctrPenRiga('2', T('Il telefono va in bianco e nero'), T('Tutto, anche le app a colori, per le ore che scegli'))
    +   ctrPenRiga('3', T('Paghi qualcosa'), T('A un amico che fa da garante, o in beneficenza'))
    + '</div>'
    + '<button type="button" class="am-cta ctr-cta" onclick="ctrNuovo()">' + T('Scrivi il tuo contratto') + '</button>'
    + '</div>'
    + (fatti ? ctrStoricoHtml(s.sgarri) : '');
}
function ctrStatoHtml(s){
  const ora = Date.now();
  if (s.attesaFino > ora){
    return '<button type="button" class="ctr-stato attesa" onclick="ctrAttesaApri()"><small>' + T('Stai aspettando di cambiare le regole') + '</small><b id="ctrStatoConto">' + ctrConto(s.attesaFino - ora) + '</b><span>' + T('Tocca per vedere l’attesa') + '</span></button>';
  }
  if (s.finestraFino > ora && s.attesaFino > 0){
    return '<button type="button" class="ctr-stato aperta" onclick="ctrAttesaApri()"><small>' + T('Le regole sono aperte') + '</small><b id="ctrStatoConto">' + ctrConto(s.finestraFino - ora) + '</b><span>' + T('Poi si richiudono da sole') + '</span></button>';
  }
  return '<div class="ctr-stato ctr-stato-giu"><small>' + T('Vuoi cambiare una regola protetta?') + '</small><button type="button" class="ctr-chiedi" onclick="ctrChiedi()">' + T('Chiedi di cambiare le regole') + '</button><span>' + T('Adesso l’attesa è di {durata}', { durata: ctrDurata(s.prossimaAttesaMin) }) + '</span></div>';
}
function ctrStoricoHtml(l){
  const righe = (l || []).slice(0, 40);
  let h = '<h3 class="ctr-sez">' + T('I tuoi sgarri') + '</h3>';
  if (!righe.length) return h + '<p class="ctr-nessuno">' + T('Nessuno sgarro finora.') + '</p>';
  const giorniPagati = {};
  h += '<div class="ctr-storico">' + righe.slice().reverse().map(function(x){
    const pen = [];
    if (+x.grigioOre) pen.push(T('bianco e nero per {durata}', { durata: ctrDurata(x.grigioOre * 60) }));
    if (+x.euro && !giorniPagati[x.g]){ giorniPagati[x.g] = 1; pen.push(x.dest === 'beneficenza' ? T('{euro} in beneficenza per quel giorno', { euro: ctrEuro(x.euro) }) : T('{euro} a {chi} per quel giorno', { euro: ctrEuro(x.euro), chi: x.a || T('il tuo garante') })); }
    return '<div class="ctr-sg"><b>' + ctrEsc(ctrSgarroTit(x)) + '</b><small>' + ctrEsc(ctrQuando(x.t)) + (x.c && !/emergenza/i.test(x.c) ? ' · ' + ctrEsc(x.c) : '') + '</small>' + (pen.length ? '<small class="ctr-sg-pen">' + ctrEsc(T('Penitenza: {lista}', { lista: ctrLista(pen) })) + '</small>' : '') + '</div>';
  }).reverse().join('') + '</div>';
  return h;
}

/* il foglio della (i): cosa conta come sgarro, detto una volta e bene */
function ctrSgarriInfo(){
  const t = CTR_REGOLE.tentativi;
  ctrFoglio('<span class="ctr-emo">' + CTR_ICO + '</span><h3>' + T('Cosa conta come sgarro') + '</h3>'
    + '<div class="ctr-def"><b>' + T('Insisti su un’app bloccata') + '</b><p>' + T('Dal {n}° tentativo nello stesso giorno di aprire un’app del contratto mentre è bloccata.', { n: t }) + '</p></div>'
    + '<div class="ctr-def"><b>' + T('Superi il tuo limite') + '</b><p>' + T('Il tempo di oggi su un’app del contratto va oltre quello che ti sei concesso. Se il limite è zero, basta un minuto.') + '</p></div>'
    + '<div class="ctr-def"><b>' + T('Spegni una regola') + '</b><p>' + T('Spegni la protezione, un programma o il Blocco rapido, oppure usi lo sblocco di emergenza della modalità severa.') + '</p></div>'
    + '<p class="ctr-foglio-nota">' + T('Conta uno sgarro per tipo e per app al giorno. Lo vede il telefono da solo.') + '</p>');
}
function ctrFoglio(html){
  let f = document.getElementById('ctrFoglio');
  if (!f){
    f = document.createElement('div'); f.id = 'ctrFoglio'; f.className = 'ctr-velo';
    f.addEventListener('click', function(e){ if (e.target === f) ctrFoglioChiudi(); });
    (document.getElementById('phone') || document.body).appendChild(f);
  }
  f.innerHTML = '<div class="ctr-sheet" role="dialog"><button type="button" class="ctr-x" onclick="ctrFoglioChiudi()" aria-label="' + T('Chiudi') + '">' + CTR_X + '</button>' + html + '</div>';
  requestAnimationFrame(function(){ f.classList.add('open'); });
}
function ctrFoglioChiudi(){ const f = document.getElementById('ctrFoglio'); if (f) f.classList.remove('open'); }

/* ---------------------------------------------------------------------------------------
   LA RICHIESTA DI MODIFICA E LA SCHERMATA DI ATTESA
   --------------------------------------------------------------------------------------- */
async function ctrChiedi(){
  await ctrCarica();
  const s = CTR.s; if (!s || !s.attivo) return;
  if (!(s.attesaFino > Date.now()) && !(s.finestraFino > Date.now() && s.attesaFino > 0)){
    const m = s.prossimaAttesaMin, dopo = CTR_LOCALE.attesaMinuti((s.n || 0) + 1);
    let ok = true;
    try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Aspetti {durata}?', { durata: ctrDurata(m) }), T('Dopo hai {n} minuti per cambiare le regole. La prossima volta l’attesa sarà di {durata}.', { n: CTR_REGOLE.finestraMin, durata: ctrDurata(dopo) }), T('Comincia l’attesa')); }catch(_){ }
    if (!ok) return;
    try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(e){ toast(String((e && e.message) || T('Non sono riuscito a farlo'))); return; }
    try{ flVibra(12); }catch(_){ }
  }
  ctrAttesaApri();
}
/** Il plugin ha rifiutato una modifica (codice "contract-wait"): lo si dice e si offre l'attesa. */
async function ctrRifiuto(e){
  await ctrCarica();
  const s = CTR.s;
  if (s && s.attesaFino > Date.now()){ toast(String((e && e.message) || T('Il contratto protegge questa regola'))); ctrAttesaApri(); return; }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Il contratto protegge questa regola'), T('Per cambiarla aspetti {durata}. Poi hai {n} minuti per farlo.', { durata: ctrDurata((s && s.prossimaAttesaMin) || 1), n: CTR_REGOLE.finestraMin }), T('Chiedi di cambiarla')); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(_){ }
  ctrAttesaApri();
}
function ctrAttesaApri(){ goId('s-contratto-attesa'); ctrAttesaPaint(true); ctrAttesaStop(); CTR.tick = setInterval(function(){ ctrAttesaPaint(false); }, 1000); }
function ctrAttesaStop(){ if (CTR.tick){ clearInterval(CTR.tick); CTR.tick = 0; } }
function ctrAttesaPaint(tutto){
  const host = document.getElementById('ctrA'); if (!host) return;
  const scr = document.getElementById('s-contratto-attesa');
  if (!tutto && scr && !scr.classList.contains('active')){ ctrAttesaStop(); return; }
  const s = CTR.s || {}, ora = Date.now();
  const attesa = s.attesaFino > ora, aperta = !attesa && s.attesaFino > 0 && s.finestraFino > ora;
  const fase = attesa ? 'attesa' : aperta ? 'aperta' : 'chiusa';
  const tot = attesa ? (s.attesaMin || 1) * 60000 : CTR_REGOLE.finestraMin * 60000;
  const resta = attesa ? s.attesaFino - ora : aperta ? s.finestraFino - ora : 0;
  const p = Math.max(0, Math.min(1, resta / tot));
  if (!tutto && host.dataset.fase === fase){
    const t = document.getElementById('ctrATempo'); if (t) t.textContent = ctrConto(resta);
    const a = document.getElementById('ctrAArco'); if (a) a.setAttribute('stroke-dashoffset', String(603 * (1 - p)));
    return;
  }
  host.dataset.fase = fase;
  const anello = '<div class="ef-anello"><svg viewBox="0 0 210 210" width="210" height="210" aria-hidden="true"><circle cx="105" cy="105" r="96" fill="none" stroke="rgba(255,255,255,.1)" stroke-width="10"/><circle id="ctrAArco" cx="105" cy="105" r="96" fill="none" stroke="' + (aperta ? '#7CC4FF' : '#2F9BFF') + '" stroke-width="10" stroke-linecap="round" stroke-dasharray="603" stroke-dashoffset="' + (603 * (1 - p)) + '" transform="rotate(-90 105 105)"/></svg><span><span class="ctr-a-dentro"><b id="ctrATempo" class="ef-tempo">' + ctrConto(resta) + '</b><small>' + (attesa ? T('e le regole si aprono') : T('e si richiudono')) + '</small></span></span></div>';
  let h;
  if (attesa){
    const dopo = CTR_LOCALE.attesaMinuti(s.n || 0);
    h = '<div class="ef-centro ef-alto">' + anello
      + '<h1>' + T('Aspetta ancora un po’') + '</h1>'
      + '<p>' + T('Il contratto che hai firmato ti chiede di aspettare {durata} prima di cambiare le regole.', { durata: ctrDurata(s.attesaMin || 1) }) + '</p>'
      + '<p class="ctr-a-pross">' + T('La prossima volta l’attesa sarà di {durata}.', { durata: ctrDurata(dopo) }) + '</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-grigio" onclick="ctrIndietroAttesa()">' + T('Torna al contratto') + '</button><button type="button" class="ef-link" onclick="ctrAnnulla()">' + T('Annulla la richiesta') + '</button></div>';
  } else if (aperta){
    h = '<div class="ef-centro ef-alto">' + anello
      + '<h1>' + T('Le regole sono aperte') + '</h1>'
      + '<p>' + T('Puoi cambiare le regole protette per {n} minuti. Spegnerne una conta come sgarro.', { n: CTR_REGOLE.finestraMin }) + '</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="ctrVaiProtezione()">' + T('Vai alla Protezione') + '</button><button type="button" class="ef-link" onclick="ctrChiudiFinestra()">' + T('Ho cambiato idea, richiudi') + '</button></div>';
  } else {
    h = '<div class="ef-centro ef-alto"><span class="ctr-emo ctr-emo-scuro">' + CTR_ICO + '</span><h1>' + T('Le regole sono di nuovo protette') + '</h1><p>' + T('Per cambiarle serve un’altra attesa.') + '</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-grigio" onclick="ctrIndietroAttesa()">' + T('Torna al contratto') + '</button></div>';
  }
  host.innerHTML = '<div class="ef ctr-a"><button type="button" class="ef-x" onclick="ctrIndietroAttesa()" aria-label="' + T('Chiudi') + '">' + CTR_X + '</button>' + h + '</div>';
}
function ctrIndietroAttesa(){ ctrAttesaStop(); goId('s-contratto'); ctrPaint(); ctrCarica().then(ctrPaint); }
async function ctrAnnulla(){
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Annullare la richiesta?'), T('Le regole restano protette. La richiesta resta contata. La prossima attesa non si accorcia.'), T('Annulla la richiesta')); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoAnnulla(); }catch(_){ }
  ctrIndietroAttesa();
}
async function ctrChiudiFinestra(){ try{ CTR.s = await ctrMotore().contrattoChiudi(); }catch(_){ } ctrIndietroAttesa(); }
function ctrVaiProtezione(){ ctrAttesaStop(); try{ if (typeof blPaginaApri === 'function') blPaginaApri(); else goId('s-home'); }catch(_){ goId('s-home'); } }

async function ctrStrappa(){
  await ctrCarica();
  const s = CTR.s; if (!s || !s.attivo) return;
  const aperta = s.attesaFino > 0 && s.attesaFino <= Date.now() && s.finestraFino > Date.now();
  if (!aperta){
    let ok = true;
    try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Vuoi strappare il contratto?'), T('Anche per questo serve l’attesa. {durata}. Poi hai {n} minuti per farlo.', { durata: ctrDurata(s.attesaFino > Date.now() ? s.attesaMin : s.prossimaAttesaMin), n: CTR_REGOLE.finestraMin }), s.attesaFino > Date.now() ? T('Vedi l’attesa') : T('Comincia l’attesa'), true); }catch(_){ }
    if (!ok) return;
    if (!(s.attesaFino > Date.now())){ try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(_){ } }
    ctrAttesaApri(); return;
  }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(T('Strappare il contratto?'), T('Le regole tornano libere e i prossimi sgarri non costano più niente. Quelli già fatti restano scritti.'), T('Strappa il contratto'), true); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoStrappa(); }catch(e){ toast(String((e && e.message) || T('Non sono riuscito a farlo'))); return; }
  /* il patto verso un ente (o non ancora firmato dall'amico) lo scioglie chi si impegna; quello firmato lo scioglie l'amico */
  let resta = '';
  try{
    const k = (CTR.s && CTR.s.contratto) || {};
    if (k.soldi && k.soldi.pattoId && typeof patApi === 'function'){
      try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: k.soldi.pattoId }); }
      catch(_){ if (k.soldi.tipo === 'amico') resta = k.soldi.a || T('il tuo garante'); }
    }
  }catch(_){ }
  toast(resta ? T('Contratto strappato. Il patto con {chi} resta:\npuò scioglierlo solo lui', { chi: resta }) : T('Contratto strappato'));
  await ctrCarica(); ctrPaint();
}

/* ---------------------------------------------------------------------------------------
   IL PATTO DEI SOLDI (patto.js): verifica "contratto", verso un amico o un ente
   --------------------------------------------------------------------------------------- */
async function ctrPattoCarica(){
  const k = (CTR.s && CTR.s.contratto) || {};
  if (!k.soldi || !k.soldi.pattoId || typeof patCarica !== 'function' || typeof PAT === 'undefined') return;
  try{ await patCarica(); CTR.patto = Array.isArray(PAT.lista) ? PAT.lista.filter(function(p){ return p.id === k.soldi.pattoId; })[0] || null : null; }catch(_){ }
  if (CTR.s && CTR.s.inAttesaGarante){ await ctrVigoreControlla(); }
  if (document.getElementById('ctrBody')) ctrPaint();
}
function ctrPattoHtml(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return '';
  if (!s.pattoId) return '<div class="ctr-patto"><p>' + (s.errore ? T('Il patto con i soldi non è partito. {errore}.', { errore: ctrEsc(s.errore) }) : T('Il patto con i soldi non è partito.')) + '</p><button type="button" class="am-link" onclick="ctrPattoCrea()">' + T('Riprova') + '</button></div>';
  const p = CTR.patto;
  if (s.tipo === 'amico' && p && p.stato === 'attesa') return '<div class="ctr-patto"><p>' + T('{chi} non ha ancora firmato il patto.', { chi: ctrEsc(s.a || T('Il tuo garante')) }) + '</p><button type="button" class="am-cta" onclick="patManda(' + p.id + ')">' + T('Manda il patto a {chi}', { chi: ctrEsc(s.a || T('il tuo garante')) }) + '</button></div>';
  return '';
}
/** Crea il patto sul server. Torna l'id, o scrive l'errore nel contratto (che resta firmato lo stesso). */
async function ctrPattoCrea(k){
  k = k || (CTR.s && CTR.s.contratto) || {};
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return 0;
  let id = 0, errore = '';
  try{
    if (typeof patApi !== 'function') throw new Error(T('Il patto funziona nell’app sul telefono'));
    const giorni = Math.max(7, Math.round(((k.fineAt || Date.now()) - Date.now()) / 86400000) || (k.giorni || 30));
    const ab = { cosa: ctrTitoloPatto(k.impegno), verifica: { tipo: 'contratto' }, giorni: [true, true, true, true, true, true, true], entro: '23:59', seNonPaga: ctrNonPaga(k) };
    /* 0.9.335, Andrea: "hai creato 2 contratti". Un "Riprova" dopo una risposta persa ne creava un secondo sul server: se il patto
       di questo contratto c'e' gia' (stessa frase, non sciolto), si riprende quello */
    try{
      if (typeof patCarica === 'function'){ await patCarica(); }
      const gia = (Array.isArray(PAT.lista) ? PAT.lista : []).filter(function(p){ const a = p && p.abitudine; return a && a.verifica && a.verifica.tipo === 'contratto' && a.cosa === ab.cosa && p.stato !== 'sciolto' && p.stato !== 'finito'; }).sort(function(x, y){ return (y.id || 0) - (x.id || 0); })[0];
      if (gia && gia.id) id = gia.id;
    }catch(_){ }
    if (s.tipo === 'beneficenza') ab.destinazione = { tipo: 'beneficenza', ente: s.a };
    if (!id){
      const r = await patApi('POST', '/api/focuslock/patti', { abitudine: ab, posta: s.euro, tetto: s.tetto || Math.max(s.euro, s.euro * 10), durataGiorni: giorni, garanteNome: s.tipo === 'amico' ? s.a : '', nome: (typeof nvNome === 'function' && nvNome()) || '' });
    id = (r && r.patto && r.patto.id) || 0;
    }
  }catch(e){ errore = String((e && e.message) || e).slice(0, 120); }
  const nuovo = JSON.parse(JSON.stringify(k));
  nuovo.soldi = Object.assign({}, s, { pattoId: id || 0, errore: id ? '' : errore });
  try{ CTR.s = await ctrMotore().contrattoFirma({ contratto: nuovo }); }catch(_){ }
  if (id && s.tipo === 'amico') setTimeout(function(){ try{ patManda(id); }catch(_){ } }, 700);
  if (document.getElementById('ctrBody')){ ctrPaint(); ctrPattoCarica(); }
  return id;
}

/* ---------------------------------------------------------------------------------------
   IL CONTRATTO NUOVO: una domanda per schermata
   --------------------------------------------------------------------------------------- */
/* 0.9.373, Andrea: "l'habit stacking: cosa ti piace fare, da usare anche nel contratto di abitudine". Dopo cosa non vuoi piu' fare, un
   passo: al posto di quella cosa, cosa fai, e dopo cosa (lo stesso momento di sempre). Si legge sul contratto: "Dopo il caffe', invece
   di aprire Instagram, leggo dieci pagine". Le cose che ti piacciono restano (fl_piaceri) per gli altri suggerimenti dell'app */
const CTR_PASSI = ['impegno', 'invece', 'app', 'limite', 'attesa', 'grigio', 'soldi', 'nonpaga', 'firma'];
/* 22/11/2026: "Se non paghi il garante" c'e' solo quando ci sono soldi da pagare */
function ctrPassoSalta(i){ const w = CTR.w; return CTR_PASSI[i] === 'nonpaga' && !(w && w.soldi && +w.soldi.euro > 0); }
/* 22/11/2026: funzioni, non costanti: la traduzione arriva dopo il caricamento */
function ctrAncore(){ return [T('Appena sveglio'), T('Dopo il caffè'), T('Dopo pranzo'), T('Appena torno a casa'), T('Prima di dormire')]; }
function ctrInveceEsempi(){ return [T('Leggo dieci pagine'), T('Una sessione di Full Focus'), T('Esco a camminare'), T('Scrivo la cosa di oggi'), T('Faccio dieci minuti di esercizi'), T('Ascolto un podcast')]; }
function ctrPiaceri(){ try{ return JSON.parse(localStorage.getItem('fl_piaceri') || '[]') || []; }catch(_){ return []; } }
function ctrEsempi(){ return [T('Aprire Instagram appena sveglio'), T('Scorrere TikTok a letto'), T('Guardare YouTube mentre lavoro'), T('Controllare il telefono ogni cinque minuti')]; }
function ctrNuovo(){
  CTR.w = { impegno: '', dopo: '', invece: '', apps: [], limiteMin: 15, limiteMio: false, grigioOre: 6, grigioMio: false, soldi: { tipo: 'amico', a: '', euro: 5, mio: false }, nonPaga: { grigioOre: 24, severaOre: 0, serie: false }, giorni: 30 };
  CTR.passo = 0; CTR.cerca = '';
  goId('s-contratto-nuovo'); ctrWPaint();
  ctrAppCarica();
}
/* 0.9.375, Andrea: "Modifica il patto non fa modificare un cazzo: manda alla pagina del contratto con Manda e Stampa". Si riapre il
   contratto passo per passo, con le risposte di prima gia' dentro; alla firma il contratto (non ancora in vigore) e il patto in attesa
   si sostituiscono con quelli nuovi, e si torna al patto */
function ctrModifica(){
  const via = function(){
    const k = (CTR.s && CTR.s.contratto) || {}, s = k.soldi || {};
    let firma = ''; try{ firma = localStorage.getItem('fl_firma_mia') || ''; }catch(_){ }
    CTR.w = { impegno: k.impegno || '', dopo: '', invece: (k.alPosto && k.alPosto.length) ? '' : (k.invece || ''), alPosto: (k.alPosto || []).slice(), apps: (k.apps || []).slice(), limiteMin: k.limiteMin != null ? k.limiteMin : 15, limiteMio: false,
      grigioOre: k.grigioOre != null ? k.grigioOre : 6, grigioMio: false, soldi: { tipo: s.tipo || 'amico', a: s.a || '', euro: s.euro != null ? s.euro : 5, mio: false }, nonPaga: k.nonPaga ? ctrNonPaga(k) : { grigioOre: 24, severaOre: 0, serie: false }, giorni: k.giorni || 30, firma: firma,
      modifica: { pattoId: s.pattoId || 0 } };
    CTR.passo = 0; CTR.cerca = '';
    goId('s-contratto-nuovo'); ctrWPaint(); ctrAppCarica();
  };
  if (CTR.s) via(); else ctrCarica().then(via, via);
}
/* 0.9.369, Andrea: "dal patto tocco Scrivi un altro patto, poi indietro, e finisco nel Contratto di abitudine invece che nel patto": si torna dove si era */
function ctrIndietroW(){ ctrLeggiCampi(); if (CTR.passo > 0){ CTR.passo--; if (CTR.passo > 0 && ctrPassoSalta(CTR.passo)) CTR.passo--; ctrWPaint(); return; } if (typeof navTornaDietro === 'function' && navTornaDietro('s-contratto-nuovo')) return; goId('s-contratto'); ctrPaint(); }
function ctrAvanti(){ ctrLeggiCampi(); const e = ctrControlla(); if (e){ toast(e); return; } CTR.passo = Math.min(CTR_PASSI.length - 1, CTR.passo + 1); if (ctrPassoSalta(CTR.passo)) CTR.passo++; ctrWPaint(); try{ document.getElementById('s-contratto-nuovo').scrollTop = 0; }catch(_){ } }
function ctrLeggiCampi(){
  const w = CTR.w; if (!w) return;
  const v = function(id){ const e = document.getElementById(id); return e ? e.value.trim() : null; };
  if (v('ctrImpegno') !== null) w.impegno = v('ctrImpegno');
  /* 0.9.382, Andrea: "anche se l'avevo selezionato, Avanti mi mostrava Scegli quando e cosa fai al suo posto": il campo vuoto
     "Oppure scrivila tu" cancellava la scelta fatta con una card. Il campo conta solo se c'e' scritto qualcosa */
  if (v('ctrInvece')) w.invece = v('ctrInvece');
  if (v('ctrLimMio') !== null && w.limiteMio){ const n = parseInt(v('ctrLimMio'), 10); if (!isNaN(n)) w.limiteMin = Math.max(0, Math.min(1440, n)); }
  if (v('ctrGrigioMio') !== null && w.grigioMio){ const n = parseInt(v('ctrGrigioMio'), 10); if (!isNaN(n)) w.grigioOre = Math.max(0, Math.min(72, n)); }
  if (v('ctrSoldiA') !== null) w.soldi.a = v('ctrSoldiA');
  if (v('ctrEuroMio') !== null && w.soldi.mio){ const n = parseInt(v('ctrEuroMio'), 10); if (!isNaN(n)) w.soldi.euro = Math.max(0, Math.min(100, n)); }
}
function ctrControlla(){
  const w = CTR.w, p = CTR_PASSI[CTR.passo];
  if (p === 'impegno' && !w.impegno) return T('Scrivi cosa non vuoi più fare');
  if (p === 'invece' && !(w.alPosto && w.alPosto.length) && !w.invece) return T('Scegli cosa fai al suo posto');
  /* 0.9.401 (BUG-202): con la musica, prima del passo dopo si sceglie quale (un file dal telefono o un link di YouTube) */
  if (p === 'invece' && ctrCanzoneManca(w)){ setTimeout(ctrCanzoneMostra, 0); return T('Prima scegli quale musica vuoi ascoltare'); }
  if (p === 'app' && !w.apps.length) return T('Scegli almeno un’app');
  if (p === 'soldi' && !w.soldi.a) return T('Scrivi il nome del tuo garante');
  if (p === 'firma' && !w.firma) return T('Firma il contratto');
  return '';
}
function ctrOpz(on, js, txt){ return '<button type="button" class="ctr-opz' + (on ? ' on' : '') + '" onclick="ctrLeggiCampi();' + js + ';ctrWPaint()">' + txt + '</button>'; }
function ctrWPaint(){
  const host = document.getElementById('ctrW'); if (!host || !CTR.w) return;
  const w = CTR.w, p = CTR_PASSI[CTR.passo];
  const prog = document.getElementById('ctrProg'); if (prog) prog.innerHTML = '<i style="width:' + Math.round((CTR.passo + 1) / CTR_PASSI.length * 100) + '%"></i>';
  const tit = document.getElementById('ctrWTit'); if (tit) tit.textContent = T('Il tuo contratto · {passo} di {totale}', { passo: CTR.passo + 1, totale: CTR_PASSI.length });
  const avanti = function(t){ return '<button type="button" class="am-cta ctr-avanti" onclick="ctrAvanti()">' + (t || T('Avanti')) + '</button>'; };
  let h = '';
  if (p === 'impegno'){
    h = '<h2 class="ctr-q">' + T('Cosa non vuoi più fare?') + '</h2><p class="ctr-qs">' + T('Una cosa sola, detta come la diresti a un amico.') + '</p>'
      + '<textarea id="ctrImpegno" class="fin ctr-campo" rows="3" placeholder="' + ctrEsc(T('Per esempio, aprire Instagram appena sveglio')) + '">' + ctrEsc(w.impegno) + '</textarea>'
      + '<div class="ctr-esempi">' + ctrEsempi().map(function(e){ return '<button type="button" onclick="ctrEsempioAggiungi(this.textContent)">' + ctrEsc(e) + '</button>'; }).join('') + '</div>' + avanti();
  } else if (p === 'invece'){
    const piace = ctrPiaceri().filter(function(x){ return ctrInveceEsempi().indexOf(x) < 0; }).slice(0, 4);
    /* 0.9.382, Andrea: "le opzioni di cosa fai al suo posto devono essere quelle dell'habit stacking di prima (sciacquarmi la faccia, il
       cruciverba...) su card bianche a due colonne, e se ne scegli piu' d'una c'e' il casuale. Il quando lo togli: nessuno se lo ricorda.
       Quando viene beccato in flagrante, la schermata di blocco gli mostra quello che aveva promesso nel contratto" */
    if (!w.alPosto) w.alPosto = [];
    const tutte = (typeof RNG_PREMI !== 'undefined' ? RNG_PREMI : []);
    const subito = CTR.altre ? tutte : tutte.slice(0, 6);
    const n = w.alPosto.length;
    h = '<h2 class="ctr-q">' + T('Cosa fai al suo posto?') + '</h2><p class="ctr-qs">' + T('Quando apri le app del contratto, la schermata di blocco ti ricorda cosa avevi promesso. Puoi sceglierne più di una.') + '</p>'
      + '<div class="ctr-alp">' + subito.map(function(x){ const on = w.alPosto.indexOf(x[0]) >= 0;
          return '<button type="button" class="ctr-alp-c' + (on ? ' on' : '') + '" aria-pressed="' + on + '" onclick="ctrAlPosto(\'' + x[0] + '\')"><span aria-hidden="true">' + x[1] + '</span><b>' + ctrEsc(T(x[2])) + '</b></button>'; }).join('') + '</div>'
      + (CTR.altre || tutte.length <= 6 ? '' : '<button type="button" class="ctr-alp-altre" onclick="CTR.altre=true;ctrWPaint()">' + T('Altre opzioni') + '</button>')
      + (n >= 2 ? '<div class="ctr-alp-ruota"><span aria-hidden="true">🎡</span><p>' + T('Ne hai scelte {n}. Sulla schermata di blocco una ruota ne sceglie una a caso.', { n: n }) + '</p></div>' : '')
      /* 0.9.391, Andrea (BUG-127): "l'utente deve poterla scegliere prima". Con la card della canzone scelta, qui si sceglie il file:
         sulla schermata di blocco parte da sola quando esce (rientro-genio.js, canzoneSalvaFile) */
      /* 0.9.401 (BUG-202): oltre al file, un link di YouTube; senza una delle due Avanti non va avanti (ctrControlla) */
      + (w.alPosto.indexOf('musica') >= 0 && typeof canzoneBottone === 'function' ? ctrCanzoneHtml() : '')
      + '<input id="ctrInvece" class="fin ctr-alp-mia" placeholder="' + ctrEsc(T('Oppure scrivila tu')) + '" value="' + ctrEsc(n ? '' : (w.invece || '')) + '">'
      + avanti();
  } else if (p === 'app'){
    h = '<h2 class="ctr-q">' + T('Su quali app vale il contratto?') + '</h2><p class="ctr-qs">' + T('Il telefono conta il tempo e i tentativi solo su queste.') + '</p>'
      + (w.apps.length ? '<div class="ctr-scelte">' + w.apps.map(function(a){ return '<button type="button" onclick="ctrAppTogli(\'' + ctrEsc(a.p) + '\')">' + ctrEsc(a.n) + ' <span aria-hidden="true">×</span></button>'; }).join('') + '</div>' : '')
      + '<input id="ctrCerca" class="fin" placeholder="' + ctrEsc(T('Cerca un’app')) + '" value="' + ctrEsc(CTR.cerca) + '" oninput="CTR.cerca=this.value;ctrAppLista()">'
      + '<div id="ctrAppL" class="ctr-appl"></div>' + avanti();
  } else if (p === 'limite'){
    const v = [[0, T('Neanche un minuto')], [15, T('{n} minuti', { n: 15 })], [30, T('{n} minuti', { n: 30 })], [60, T('Un’ora')]];
    h = '<h2 class="ctr-q">' + T('Quanto tempo al giorno ti concedi su {app}?', { app: ctrEsc(ctrNomiApp(w)) }) + '</h2><p class="ctr-qs">' + T('Oltre questo tempo è uno sgarro.') + '</p>'
      + '<div class="ctr-opzl">' + v.map(function(x){ return ctrOpz(!w.limiteMio && w.limiteMin === x[0], 'CTR.w.limiteMio=false;CTR.w.limiteMin=' + x[0], x[1]); }).join('')
      + ctrOpz(w.limiteMio, 'CTR.w.limiteMio=true', T('Lo scrivo io')) + '</div>'
      + (w.limiteMio ? '<label class="ctr-l" for="ctrLimMio">' + T('Minuti al giorno') + '</label><input id="ctrLimMio" class="fin" type="number" inputmode="numeric" min="0" value="' + w.limiteMin + '">' : '')
      + avanti();
  } else if (p === 'attesa'){
    const scala = [1, 2, 4, 8, 16, 32];
    h = '<span class="ctr-emo">⏳</span><h2 class="ctr-q">' + T('Le regole si cambiano solo dopo un’attesa') + '</h2>'
      + '<p class="ctr-qs">' + T('Ogni volta che vorrai allentare un blocco, aspetterai. E ogni volta l’attesa raddoppia.') + '</p>'
      + '<div class="ctr-scala">' + scala.map(function(m, i){ return '<div><b>' + (m < 60 ? m : m / 60) + '</b><small>' + (m === 1 ? T('minuto') : T('minuti')) + '</small><i>' + T('{n}ª volta', { n: i + 1 }) + '</i></div>'; }).join('') + '<div class="ctr-scala-fine"><b>24</b><small>' + T('ore al massimo') + '</small></div></div>'
      + '<p class="ctr-qs">' + T('Finita l’attesa hai {n} minuti per cambiare le regole. Dopo {giorni} giorni senza richieste si riparte da un minuto.', { n: CTR_REGOLE.finestraMin, giorni: CTR_REGOLE.azzeraGiorni }) + '</p>'
      + avanti(T('Ho capito'));
  } else if (p === 'grigio'){
    const v = [[2, T('{n} ore', { n: 2 })], [6, T('{n} ore', { n: 6 })], [12, T('{n} ore', { n: 12 })], [24, T('Un giorno intero')], [0, T('Niente bianco e nero')]];
    const perm = !CTR.s || CTR.s.permessoGrigio !== false;
    h = '<h2 class="ctr-q">' + T('Se sgarri, per quanto tempo il telefono va in bianco e nero?') + '</h2><p class="ctr-qs">' + T('Tutto il telefono, anche le app che di solito restano a colori.') + '</p>'
      + '<div class="ctr-opzl">' + v.map(function(x){ return ctrOpz(!w.grigioMio && w.grigioOre === x[0], 'CTR.w.grigioMio=false;CTR.w.grigioOre=' + x[0], x[1]); }).join('')
      + ctrOpz(w.grigioMio, 'CTR.w.grigioMio=true', T('Lo scrivo io')) + '</div>'
      + (w.grigioMio ? '<label class="ctr-l" for="ctrGrigioMio">' + T('Ore di bianco e nero') + '</label><input id="ctrGrigioMio" class="fin" type="number" inputmode="numeric" min="0" value="' + w.grigioOre + '">' : '')
      + (!perm && w.grigioOre ? '<div class="ctr-avviso"><p>' + T('Per il bianco e nero il telefono deve dare un permesso, una volta sola, dal computer.') + '</p><button type="button" class="am-link" onclick="if(typeof grOpen===\'function\')grOpen()">' + T('Come si dà il permesso') + '</button></div>' : '')
      + avanti();
  } else if (p === 'soldi'){
    /* 0.9.337, Andrea: "il contratto di abitudine e il patto con il Dreambrother sono la stessa cosa: un contratto non lo fai da solo,
       lo fai con un garante". Il garante c'e' sempre; i soldi sono la sua parte, e possono anche essere niente. */
    const s = w.soldi; s.tipo = 'amico';
    h = '<h2 class="ctr-q">' + T('Chi è il tuo garante?') + '</h2><p class="ctr-qs">' + T('Un amico, un fratello, tua madre. Firma il contratto con te dalla sua app.') + '</p>'
      + '<input id="ctrSoldiA" class="fin" placeholder="' + ctrEsc(T('Il suo nome')) + '" value="' + ctrEsc(s.a) + '">'
      + '<label class="ctr-l">' + T('Se sgarri, quanto gli dai per ogni giorno con uno sgarro?') + '</label>'
      + '<div class="ctr-euro">' + [[0, T('Niente, basta la parola')], [2, ctrEuro(2)], [5, ctrEuro(5)], [10, ctrEuro(10)], [20, ctrEuro(20)]].map(function(e){ return ctrOpz(!s.mio && s.euro === e[0], 'CTR.w.soldi.mio=false;CTR.w.soldi.euro=' + e[0], e[1]); }).join('') + ctrOpz(s.mio, 'CTR.w.soldi.mio=true', T('Lo scrivo io')) + '</div>'
      + (s.mio ? '<input id="ctrEuroMio" class="fin" type="number" inputmode="numeric" min="0" placeholder="' + ctrEsc(T('Euro')) + '" value="' + s.euro + '">' : '')
      + avanti();
  } else if (p === 'nonpaga'){
    /* 22/11/2026, Andrea: "se l'utente non salda, un punto al vecchio se': se non mantiene la parola data non sta cambiando, sta tenendo
       al sicuro il suo paradigma nella zona di comfort e manca di rispetto al nuovo se'. Poi la penitenza la sceglie lui" */
    const n = w.nonPaga, g = w.soldi.a || T('il tuo garante');
    const riga = function(tit, opz, campo){ return '<label class="ctr-l">' + tit + '</label><div class="ctr-opzl">' + opz.map(function(x){ return ctrOpz(n[campo] === x[0], 'CTR.w.nonPaga.' + campo + '=' + String(x[0]), x[1]); }).join('') + '</div>'; };
    h = '<h2 class="ctr-q">' + T('E se non paghi {chi} entro 48 ore?', { chi: ctrEsc(g) }) + '</h2><p class="ctr-qs">' + T('Prendi sempre un punto al vecchio te. Non hai mantenuto la parola data. In più scegli tu cosa ti costa.') + '</p>'
      + riga(T('Il telefono in bianco e nero'), [[0, T('No')], [12, T('{n} ore', { n: 12 })], [24, T('Un giorno')], [48, T('Due giorni')]], 'grigioOre')
      + riga(T('La modalità severa, accesa da sola'), [[0, T('No')], [2, T('{n} ore', { n: 2 })], [6, T('{n} ore', { n: 6 })], [12, T('{n} ore', { n: 12 })]], 'severaOre')
      + riga(T('La serie riparte da zero'), [[false, T('No')], [true, T('Sì')]], 'serie')
      + avanti();
  } else if (p === 'soldi_vecchio'){
    const s = w.soldi;
    h = '<h2 class="ctr-q">Se sgarri, a chi vanno i tuoi soldi?</h2><p class="ctr-qs">Conta un giorno alla volta:<br>più sgarri nello stesso giorno costano una volta sola.</p>'
      + '<div class="ctr-opzl">' + ctrOpz(s.tipo === 'amico', 'CTR.w.soldi.tipo=\'amico\'', 'A un amico che fa da garante') + ctrOpz(s.tipo === 'beneficenza', 'CTR.w.soldi.tipo=\'beneficenza\'', 'In beneficenza') + ctrOpz(s.tipo === 'nessuno', 'CTR.w.soldi.tipo=\'nessuno\'', 'Niente soldi') + '</div>';
    if (s.tipo !== 'nessuno'){
      h += '<label class="ctr-l" for="ctrSoldiA">' + (s.tipo === 'amico' ? 'Come si chiama il tuo amico?' : 'A chi vuoi donare?') + '</label>'
        + '<input id="ctrSoldiA" class="fin" placeholder="' + (s.tipo === 'amico' ? 'Il suo nome' : 'Per esempio, la Croce Rossa della tua città') + '" value="' + ctrEsc(s.a) + '">'
        + '<label class="ctr-l">Quanto per ogni giorno con uno sgarro?</label>'
        + '<div class="ctr-euro">' + [2, 5, 10, 20].map(function(e){ return ctrOpz(!s.mio && s.euro === e, 'CTR.w.soldi.mio=false;CTR.w.soldi.euro=' + e, e + ' €'); }).join('') + ctrOpz(s.mio, 'CTR.w.soldi.mio=true', 'Lo scrivo io') + '</div>'
        + (s.mio ? '<input id="ctrEuroMio" class="fin" type="number" inputmode="numeric" min="1" placeholder="Euro" value="' + s.euro + '">' : '')
        + '<p class="ctr-onesto">L’app non tocca i soldi:<br>ogni sgarro resta scritto con la sua cifra, e li paghi tu.' + (s.tipo === 'amico' ? ' Il tuo amico firma il patto dalla sua app.' : '') + '</p>';
    }
    h += avanti();
  } else {
    const nome = (typeof nvNome === 'function' && nvNome()) || '';
    const s = w.soldi;
    const pen = [];
    pen.push(T('aspetterò prima di cambiare le regole, e ogni volta l’attesa raddoppierà'));
    if (w.grigioOre) pen.push(T('il mio telefono andrà in bianco e nero per {durata}', { durata: ctrDurata(w.grigioOre * 60) }));
    if (s.tipo !== 'nessuno' && s.euro > 0) pen.push(s.tipo === 'amico' ? T('darò a {chi} {euro} per ogni giorno con uno sgarro, entro 48 ore', { chi: s.a, euro: ctrEuro(s.euro) }) : T('donerò {euro} a {chi} per ogni giorno con uno sgarro, entro 48 ore', { chi: s.a, euro: ctrEuro(s.euro) }));
    if (s.tipo === 'amico' && !(s.euro > 0)) pen.push(T('{chi} lo saprà, perché è il mio garante', { chi: s.a }));
    const nonPaga = s.tipo === 'amico' && s.euro > 0 ? '<p>' + ctrEsc(T('Se non pago {chi} entro 48 ore. {penitenza}.', { chi: s.a, penitenza: ctrNonPagaTxt(w, true) })) + '</p>' : '';
    h = '<h2 class="ctr-q">' + T('Il tuo contratto') + '</h2>'
      + '<div class="ctr-carta"><p>' + ctrEsc(ctrFraseIo(w.impegno, nome)) + '</p>'
      + '<p>' + ctrEsc(ctrLimiteTxt(w)) + '.</p>'
      + '<p>' + ctrEsc(T('Se sgarro, {penitenze}.', { penitenze: pen.join('; ') })) + '</p>' + nonPaga + '</div>'
      + '<div class="md-row ctr-durata"><span>' + T('Quanto dura') + '</span><div class="md-step"><button type="button" onclick="CTR.w.giorni=Math.max(7,CTR.w.giorni-(CTR.w.giorni>30?30:7));ctrWPaint()" aria-label="' + T('Meno') + '">−</button><b>' + T('{n} giorni', { n: w.giorni }) + '</b><button type="button" onclick="CTR.w.giorni=Math.min(365,CTR.w.giorni+(CTR.w.giorni>=30?30:7));ctrWPaint()" aria-label="' + T('Più') + '">+</button></div></div>'
      /* 0.9.337, Andrea: "l'utente deve poterlo firmare: disegnare la firma, o farla firmare all'app, come nei contratti digitali" */
      + '<div class="ctr-firme"><div class="ctr-firma-box"><canvas id="ctrFirmaC" width="600" height="200" aria-label="' + ctrEsc(T('Firma qui con il dito')) + '"></canvas>'
      +   (w.firma ? '' : '<span class="ctr-firma-ph">' + T('Firma qui con il dito') + '</span>') + '<i class="ctr-firma-riga"></i><small>' + ctrEsc(nome || T('La tua firma')) + '</small></div>'
      +   '<div class="ctr-firma-az"><button type="button" class="am-link" onclick="ctrFirmaAuto()">' + T('Firma con il mio nome') + '</button><button type="button" class="am-link" onclick="ctrFirmaCancella()">' + T('Cancella') + '</button></div>'
      +   '<div class="ctr-firma-gar"><i>' + ctrEsc(s.a || T('Il tuo garante')) + '</i><small>' + T('firma del garante, dalla sua app') + '</small></div></div>'
      + '<button type="button" class="am-cta ctr-avanti" id="ctrFirmaBtn"' + (w.firma ? '' : ' disabled') + ' onclick="ctrFirma()">' + T('Firma il contratto') + '</button>';
  }
  host.innerHTML = '<div class="ctr-w">' + h + '</div>';
  if (p === 'app') ctrAppLista();
  if (p === 'firma') ctrFirmaPad();
  ctrGenioScena(host);
}
/* LA FIRMA: si disegna con il dito, o la scrive l'app con il nome in corsivo. Resta nel contratto come immagine. */
function ctrFirmaPad(){
  const c = document.getElementById('ctrFirmaC'); if (!c || !CTR.w) return;
  const g = c.getContext('2d');
  if (CTR.w.firma){ const im = new Image(); im.onload = function(){ g.clearRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0); }; im.src = CTR.w.firma; }
  g.lineWidth = 5; g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = '#001E44';
  let giu = false, ultimo = null;
  const pt = function(e){ const r = c.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * c.width, (e.clientY - r.top) / r.height * c.height]; };
  c.addEventListener('pointerdown', function(e){ e.preventDefault(); giu = true; ultimo = pt(e); try{ c.setPointerCapture(e.pointerId); }catch(_){ } const ph = c.parentNode.querySelector('.ctr-firma-ph'); if (ph) ph.remove(); });
  c.addEventListener('pointermove', function(e){ if (!giu) return; const p = pt(e); g.beginPath(); g.moveTo(ultimo[0], ultimo[1]); g.lineTo(p[0], p[1]); g.stroke(); ultimo = p; });
  const fine = function(){ if (!giu) return; giu = false; CTR.w.firma = c.toDataURL('image/png'); const b = document.getElementById('ctrFirmaBtn'); if (b) b.disabled = false; };
  c.addEventListener('pointerup', fine); c.addEventListener('pointercancel', fine);
  c.style.touchAction = 'none';
}
function ctrFirmaAuto(){
  const c = document.getElementById('ctrFirmaC'); if (!c || !CTR.w) return;
  const nome = ((typeof nvNome === 'function' && nvNome()) || T('Io')).trim();
  const g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height);
  g.fillStyle = '#001E44'; g.font = 'italic 84px "Caveat","DM Caveat","Segoe Print",cursive'; g.textBaseline = 'middle';
  const w = g.measureText(nome).width; g.fillText(nome, Math.max(20, (c.width - w) / 2), c.height / 2);
  const ph = c.parentNode.querySelector('.ctr-firma-ph'); if (ph) ph.remove();
  CTR.w.firma = c.toDataURL('image/png');
  const b = document.getElementById('ctrFirmaBtn'); if (b) b.disabled = false;
  try{ flVibra(10); }catch(_){ }
}
function ctrFirmaCancella(){ if (!CTR.w) return; CTR.w.firma = ''; ctrWPaint(); }
/* IL GENIO CHE PARLA (0.9.337, Andrea: "i passi del contratto fanno cagare: ci vuole il Genio che parla sul cielo notturno della
   foresta, con le risposte su due colonne e le emoji"). La domanda diventa la sua nuvoletta; le scelte vanno in griglia. */
const CTR_EMO = { 'Neanche un minuto': '🚫', '15 minuti': '⏱️', '30 minuti': '🕧', 'Un’ora': '🕐', 'Lo scrivo io': '✍️', '2 ore': '🌗', '6 ore': '🌘', '12 ore': '🌑', 'Un giorno intero': '📅', 'Niente bianco e nero': '🎨', 'Niente, basta la parola': '🤝', '2 €': '💶', '5 €': '💶', '10 €': '💶', '20 €': '💶' };
/** CTR_EMO e' scritto con le etichette italiane: qui le stesse etichette come le vede chi legge (tradotte, euro nel suo formato). */
function ctrEmoTradotte(){
  const out = {};
  Object.keys(CTR_EMO).forEach(function(k){
    let m, t;
    if ((m = /^(\d+) €$/.exec(k))) t = ctrEuro(+m[1]);
    else if ((m = /^(\d+) minuti$/.exec(k))) t = T('{n} minuti', { n: +m[1] });
    else if ((m = /^(\d+) ore$/.exec(k))) t = T('{n} ore', { n: +m[1] });
    else t = T(k);
    out[String(t).trim()] = CTR_EMO[k];
  });
  return out;
}
function ctrGenioScena(host){
  const q = host.querySelector('.ctr-q'); if (!q || host.querySelector('.ctr-genio')) return;
  const s = host.querySelector('.ctr-qs');
  const box = document.createElement('div'); box.className = 'ctr-genio';
  box.innerHTML = '<img src="img/genio/genio-' + (CTR_PASSI[CTR.passo] === 'firma' ? 'rivela' : 'pensa') + '.png" alt=""><div class="ctr-fum"></div>';
  q.parentNode.insertBefore(box, q);
  const f = box.querySelector('.ctr-fum'); f.appendChild(q); if (s) f.appendChild(s);
  const emo = ctrEmoTradotte();
  host.querySelectorAll('.ctr-opzl .ctr-opz, .ctr-euro .ctr-opz').forEach(function(b){ const t = b.textContent.trim(); if (emo[t] && !b.querySelector('.ctr-e')) b.insertAdjacentHTML('afterbegin', '<span class="ctr-e">' + emo[t] + '</span>'); });
}
function ctrMinuscola(t){ t = String(t || ''); return t.charAt(0).toLowerCase() + t.slice(1); }
/** "Aprire Instagram appena sveglio" -> "Mi impegno a non aprire Instagram appena sveglio" (anche se chi scrive comincia con "non" o "smettere di"). */
/** I pezzi dell'impegno, uno per riga. In italiano senza "non", "smettere di", "basta" e con la minuscola (la frase li aggiunge);
    nelle altre lingue come li ha scritti chi si impegna. */
function ctrFrasePezzi(impegno){
  const it = ctrIt();
  const pulisci = function(r){ return it ? ctrMinuscola(r).replace(/^(non\s+|smettere\s+di\s+|smetto\s+di\s+|basta\s+)/i, '').replace(/^più\s+/i, '') : r; };
  /* 0.9.382: piu' punti elenco diventano un elenco nella frase ("aprire Instagram appena sveglio e a non scorrere TikTok a letto") */
  const pz = String(impegno || '').split('\n').map(function(r){ return r.replace(/^\s*[•\-]\s*/, '').trim().replace(/[.!]+$/, ''); }).filter(Boolean).map(pulisci);
  if (pz.length > 1) return pz;
  return [pulisci(String(impegno || '').trim().replace(/^\s*[•\-]\s*/, '').replace(/[.!]+$/, ''))];
}
function ctrFrase(impegno){
  const pz = ctrFrasePezzi(impegno);
  if (pz.length > 1) return T('Mi impegno a non {lista} e a non {ultimo}', { lista: pz.slice(0, -1).join(', '), ultimo: pz[pz.length - 1] });
  return T('Mi impegno a non {cosa}', { cosa: pz[0] });
}
/** Il titolo del patto sul server: "Non aprire Instagram appena sveglio". */
function ctrTitoloPatto(impegno){
  const pz = ctrFrasePezzi(impegno);
  if (pz.length > 1) return T('Non {lista} e a non {ultimo}', { lista: pz.slice(0, -1).join(', '), ultimo: pz[pz.length - 1] });
  return T('Non {cosa}', { cosa: pz[0] });
}
/** La prima riga del contratto: "Io, Andrea, mi impegno a non ...". */
function ctrFraseIo(impegno, nome){
  const pz = ctrFrasePezzi(impegno);
  if (pz.length > 1){
    const v = { nome: nome, lista: pz.slice(0, -1).join(', '), ultimo: pz[pz.length - 1] };
    return nome ? T('Io, {nome}, mi impegno a non {lista} e a non {ultimo}.', v) : T('Io mi impegno a non {lista} e a non {ultimo}.', v);
  }
  return nome ? T('Io, {nome}, mi impegno a non {cosa}.', { nome: nome, cosa: pz[0] }) : T('Io mi impegno a non {cosa}.', { cosa: pz[0] });
}

/* le app: prima quelle che blocchi gia', poi tutte */
async function ctrAppCarica(){
  let tutte = [], bloccate = [];
  try{ const r = typeof flApps === 'function' ? await flApps() : null; tutte = ((r && r.apps) || []).filter(function(a){ return a && a.packageName && !a.system && !/^com\.dreambrothers\./.test(a.packageName) && !/focus\s*lock|dream\s*map/i.test(String(a.label || '')); }); }catch(_){ }
  /* 0.9.343, Andrea: "appare FocusLock al posto di DreamMap": il contratto non vale sulla stessa app che lo fa rispettare */
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getRulesFull){ const r = await NATIVE.getRulesFull(); bloccate = (r && r.apps) || []; } }catch(_){ }
  const b = {}; bloccate.forEach(function(p){ b[String(p).toLowerCase()] = 1; });
  tutte.sort(function(x, y){ return (b[y.packageName] || 0) - (b[x.packageName] || 0) || String(x.label).localeCompare(String(y.label)); });
  CTR.appTutte = tutte.map(function(a){ return { p: a.packageName, n: a.label || a.packageName, b: !!b[a.packageName] }; });
  if (CTR_PASSI[CTR.passo] === 'app') ctrAppLista();
}
function ctrAppLista(){
  const host = document.getElementById('ctrAppL'); if (!host || !CTR.w) return;
  if (!CTR.appTutte){ host.innerHTML = '<p class="ctr-carica">' + T('Un attimo…') + '</p>'; return; }
  const q = String(CTR.cerca || '').trim().toLowerCase();
  const scelte = {}; CTR.w.apps.forEach(function(a){ scelte[a.p] = 1; });
  const l = CTR.appTutte.filter(function(a){ return !q || a.n.toLowerCase().indexOf(q) >= 0; }).slice(0, 60);
  if (!l.length){ host.innerHTML = '<p class="ctr-carica">' + (CTR.appTutte.length ? T('Nessuna app con questo nome.') : T('Sul telefono qui compaiono le tue app.')) + '</p>'; return; }
  /* 0.9.343, Andrea: "le app appaiono senza immagine": l'icona vera, come nell'elenco del blocco */
  host.innerHTML = l.map(function(a){ return '<button type="button" class="ctr-app' + (scelte[a.p] ? ' on' : '') + '" onclick="ctrAppScegli(\'' + ctrEsc(a.p) + '\')"><em class="ub-appico ub-appico-fb ctr-ico">' + ctrEsc((a.n || '?').trim().charAt(0).toUpperCase()) + '<img class="ub-appico ub-appico-img" data-pkg="' + ctrEsc(a.p) + '" alt=""></em><span><b>' + ctrEsc(a.n) + '</b>' + (a.b ? '<small>' + T('La blocchi già') + '</small>' : '') + '</span><i aria-hidden="true"></i></button>'; }).join('');
  try{ if (typeof ubFillIcons === 'function') ubFillIcons(host); }catch(_){ }
}
function ctrAppScegli(pkg){
  const w = CTR.w; const i = w.apps.findIndex(function(a){ return a.p === pkg; });
  if (i >= 0) w.apps.splice(i, 1);
  else { const a = (CTR.appTutte || []).filter(function(x){ return x.p === pkg; })[0]; if (a) w.apps.push({ p: a.p, n: a.n }); }
  const y = (document.getElementById('s-contratto-nuovo') || {}).scrollTop || 0;
  ctrWPaint();
  try{ document.getElementById('s-contratto-nuovo').scrollTop = y; const c = document.getElementById('ctrCerca'); if (c && CTR.cerca) c.focus(); }catch(_){ }
}
function ctrAppTogli(pkg){ ctrAppScegli(pkg); }

async function ctrFirma(){
  const w = CTR.w; if (!w) return;
  try{ if (w.firma) localStorage.setItem('fl_firma_mia', w.firma); }catch(_){ }
  try{ if (w.invece){ const l = ctrPiaceri().filter(function(x){ return x !== w.invece; }); l.unshift(w.invece); localStorage.setItem('fl_piaceri', JSON.stringify(l.slice(0, 12))); } }catch(_){ }
  try{ ctrPromessaSulBlocco(w); }catch(_){ }
  const k = { impegno: w.impegno, dopo: '', invece: ctrAlPostoTesto(w), alPosto: (w.alPosto || []).slice(), frase: ctrFrase(w.impegno), apps: w.apps, limiteMin: w.limiteMin, grigioOre: w.grigioOre, giorni: w.giorni,
    soldi: { tipo: 'amico', a: w.soldi.a, euro: w.soldi.euro, tetto: Math.min(500, Math.max(w.soldi.euro, w.soldi.euro * 10)) }, nonPaga: ctrNonPaga(w) };
  const mod = w.modifica || null;
  if (mod){
    try{ const m = ctrMotore(); if (CTR.s && CTR.s.inAttesaGarante && typeof m.contrattoRitira === 'function') CTR.s = await m.contrattoRitira(); }catch(_){ }
    if (mod.pattoId && typeof patApi === 'function'){ try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: mod.pattoId }); }catch(_){ } }
  }
  try{ CTR.s = await ctrMotore().contrattoFirma({ contratto: k }); }
  catch(e){ toast(String((e && e.message) || T('Il contratto non si è salvato:\nriprova'))); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  CTR.w = null; CTR.passo = 0;
  if (mod && typeof patApri === 'function'){
    toast(T('Patto modificato'));
    if (k.soldi.tipo !== 'nessuno') await ctrPattoCrea(CTR.s && CTR.s.contratto);
    patApri(); return;
  }
  goId('s-contratto'); ctrPaint();
  toast(T('Contratto firmato'));
  if (k.soldi.tipo !== 'nessuno') await ctrPattoCrea(CTR.s && CTR.s.contratto);
}

/* ---------------------------------------------------------------------------------------
   DOVE SI TROVA: la Protezione (dopo la modalita' severa), la pagina della modalita' severa,
   la schermata di blocco (pulsante "Rileggi il contratto" -> apri "contratto")
   --------------------------------------------------------------------------------------- */
function ctrPortaHtml(){
  const s = CTR.s, on = !!(s && s.attivo);
  const oggi = on ? (s.sgarri || []).filter(function(x){ return x.g === new Date().toISOString().slice(0, 10) || new Date(x.t).toDateString() === new Date().toDateString(); }).length : 0;
  const sub = !on ? T('Scrivi cosa non vuoi più fare e scegli le penitenze se sgarri')
    : (s.grigioFino > Date.now() ? T('Bianco e nero fino alle {ora}', { ora: ctrOra(s.grigioFino) }) : (oggi ? (oggi === 1 ? T('Oggi hai sgarrato una volta') : T('Oggi hai sgarrato {n} volte', { n: oggi })) : T('Attivo fino al {data}', { data: ctrData((s.contratto || {}).fineAt) })));
  return '<button type="button" class="ctr-porta' + (on ? ' on' : '') + '" onclick="ctrApri()"><span class="ctr-emo">' + CTR_ICO + '</span><b>' + T('Contratto di abitudine') + '</b><small>' + ctrEsc(sub) + '</small></button>';
}
function ctrPortePaint(){
  ['ctrBlHost', 'ctrSevHost'].forEach(function(id){ const h = document.getElementById(id); if (h) h.innerHTML = ctrPortaHtml(); });
}
function ctrPorteMetti(schermo){
  try{
    /* 0.9.335, Andrea: "il contratto d'abitudine non deve comparire nella sezione della modalita' severa, ma nella sua pagina" */
    if (schermo === 's-blocco'){ const vecchio = document.getElementById('ctrBlHost'); if (vecchio) vecchio.remove(); }
    if (schermo === 's-severa-pagina'){
      const box = document.getElementById('sevTabBox');
      let h = document.getElementById('ctrSevHost');
      if (!h && box && box.parentNode){ h = document.createElement('div'); h.id = 'ctrSevHost'; h.className = 'ctr-porta-host'; box.parentNode.insertBefore(h, box.nextSibling); }
    }
    ctrPortePaint();
  }catch(_){ }
}
document.addEventListener('fl:screen', function(e){
  const id = e && e.detail;
  if (id === 's-blocco' || id === 's-severa-pagina'){ setTimeout(function(){ ctrPorteMetti(id); ctrCarica().then(ctrPortePaint); }, 60); }
  if (id === 's-contratto' && CTR.s) ctrPaint();
});
setTimeout(function(){ ctrCarica().catch(function(){ }); }, 3000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) ctrCarica().then(function(){ if (document.getElementById('s-contratto') && document.getElementById('s-contratto').classList.contains('active')) ctrPaint(); }).catch(function(){ }); });
/* il conto alla rovescia sulla pagina del contratto */
setInterval(function(){
  const el = document.getElementById('ctrStatoConto'), s = CTR.s; if (!el || !s) return;
  const ora = Date.now();
  if (s.attesaFino > ora) el.textContent = ctrConto(s.attesaFino - ora);
  else if (s.finestraFino > ora && s.attesaFino > 0) el.textContent = ctrConto(s.finestraFino - ora);
  else if (el.dataset.f !== '1'){ el.dataset.f = '1'; ctrPaint(); }
  ctrGrigioWeb();
}, 1000);

(function(){
  const css = [
    '#s-contratto .ctr-top,#s-contratto-nuovo .ctr-top{justify-content:space-between}#s-contratto .ctr-top .blk-title,#s-contratto-nuovo .ctr-top .blk-title{flex:1;text-align:center}',
    '.ctr-i{color:var(--muted)}',
    '.ctr-vuota{visibility:hidden}',
    'html.ctr-grigio{filter:grayscale(1)}',
    '.ctr-carica{text-align:center;font:600 13px var(--font-body);color:var(--muted);margin:16px 0}',
    '.ctr-emo{display:inline-grid;place-items:center;width:64px;height:64px;border-radius:50%;background:#fff;box-shadow:0 6px 20px rgba(0,30,68,.12);font-size:32px;line-height:1}',
    '.ctr-emo-scuro{margin-bottom:26px}',
    '.ctr-vuoto{display:flex;flex-direction:column;align-items:center;text-align:center;padding:12px 4px 8px}',
    '.ctr-vuoto h2{margin:20px 0 10px;font:800 24px/1.25 var(--font-display);color:var(--navy);text-wrap:balance}body.dark .ctr-vuoto h2{color:#fff}',
    '.ctr-vuoto > p{margin:0 0 24px;max-width:32ch;font:500 15px/1.5 var(--font-body);color:var(--muted)}',
    '.ctr-cta{width:100%;margin-top:28px}',
    '.ctr-pen{display:flex;flex-direction:column;gap:10px;width:100%}',
    '.ctr-pr{display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line);text-align:left}body.dark .ctr-pr{background:#12203A;border-color:#22345A}',
    '.ctr-pr > i{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font:800 14px var(--font-body);font-style:normal;color:#0075E3;background:rgba(0,117,227,.1)}body.dark .ctr-pr > i{color:#7CC4FF;background:rgba(124,196,255,.14)}',
    '.ctr-pr b{display:block;font:700 15px/1.35 var(--font-body);color:var(--navy)}body.dark .ctr-pr b{color:#fff}',
    '.ctr-pr small{display:block;margin-top:3px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.ctr-pr.on{border-color:#E63946}.ctr-pr.on > i{color:#fff;background:#E63946}',
    '.ctr-stato{display:flex;flex-direction:column;align-items:center;gap:10px;width:100%;margin:4px 0 22px;padding:22px 18px;border-radius:24px;border:1px solid var(--line);background:var(--card,#fff);text-align:center;cursor:default}body.dark .ctr-stato{background:#12203A;border-color:#22345A}',
    '.ctr-stato small{font:700 13px var(--font-body);color:var(--muted)}.ctr-stato span{font:500 12.5px var(--font-body);color:var(--muted)}.ctr-stato .am-cta{width:100%;margin:4px 0 0}',
    '.ctr-stato.attesa,.ctr-stato.aperta{cursor:pointer;background:linear-gradient(180deg,#0B2A5C,#001E44);border-color:transparent}.ctr-stato.attesa small,.ctr-stato.aperta small,.ctr-stato.attesa span,.ctr-stato.aperta span{color:rgba(220,234,255,.82)}',
    '.ctr-stato b{font:800 40px/1 var(--font-body);color:#2F9BFF;font-variant-numeric:tabular-nums}.ctr-stato.aperta b{color:#7CC4FF}',
    '.ctr-foglio{padding:20px 18px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .ctr-foglio{background:#12203A;border-color:#22345A}',
    '.ctr-eti{display:block;font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}body.dark .ctr-eti{color:#7CC4FF}',
    '.ctr-impegno{margin:12px 0 0;font:800 20px/1.3 var(--font-display);color:var(--navy)}body.dark .ctr-impegno{color:#fff}',
    '.ctr-lim{margin:10px 0 0;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    '.ctr-sez{margin:28px 0 12px;font:800 17px var(--font-display);color:var(--navy);text-align:center}body.dark .ctr-sez{color:#fff}',
    '.ctr-patto{margin-top:12px;padding:14px 16px;border-radius:18px;border:1px dashed var(--line);text-align:center}.ctr-patto p{margin:0 0 8px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.ctr-patto .am-cta{width:100%}',
    '.ctr-nessuno{margin:0;text-align:center;font:500 14px var(--font-body);color:var(--muted)}',
    '.ctr-storico{display:flex;flex-direction:column;gap:8px}',
    '.ctr-sg{padding:14px 16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);border-left:4px solid #E63946;text-align:left}body.dark .ctr-sg{background:#12203A;border-color:#22345A;border-left-color:#E63946}',
    '.ctr-sg b{display:block;font:700 14.5px/1.35 var(--font-body);color:var(--navy)}body.dark .ctr-sg b{color:#fff}',
    '.ctr-sg small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}.ctr-sg .ctr-sg-pen{color:#E63946;font-weight:600}',
    '.ctr-strappa{display:block;margin:32px auto 0;border:0;background:transparent;font:600 14px var(--font-body);color:var(--muted);text-decoration:underline;text-underline-offset:3px;cursor:pointer;padding:10px}',
    '.ctr-velo{position:fixed;inset:0;z-index:9000;background:rgba(0,12,30,.55);display:flex;align-items:flex-end;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s}.ctr-velo.open{opacity:1;pointer-events:auto}body.dark .ctr-velo{background:rgba(0,0,0,.72)}',
    '.ctr-sheet{position:relative;width:100%;max-width:520px;box-sizing:border-box;padding:28px 22px calc(26px + env(safe-area-inset-bottom,0px));border-radius:26px 26px 0 0;background:var(--card,#fff);text-align:center;transform:translateY(30px);transition:transform .25s}.ctr-velo.open .ctr-sheet{transform:none}body.dark .ctr-sheet{background:#12203A}',
    '.ctr-sheet h3{margin:16px 0 18px;font:800 21px var(--font-display);color:var(--navy)}body.dark .ctr-sheet h3{color:#fff}',
    '.ctr-x{position:absolute;top:12px;right:12px;width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}',
    '.ctr-def{margin:0 0 16px}.ctr-def b{display:block;font:700 15px var(--font-body);color:var(--navy)}body.dark .ctr-def b{color:#fff}.ctr-def p{margin:4px auto 0;max-width:34ch;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}',
    '.ctr-foglio-nota{margin:6px 0 0;font:600 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.ctr-w{display:flex;flex-direction:column;gap:16px;align-items:stretch;text-align:center}.ctr-w > .ctr-emo{align-self:center}',
    '.ctr-q{margin:6px 0 0;font:800 24px/1.25 var(--font-display);color:var(--navy);text-align:center;text-wrap:balance}body.dark .ctr-q{color:#fff}',
    /* 0.9.337: il contratto si scrive con il Genio, sul cielo notturno della foresta (come le sue domande), risposte su due colonne */
    '#s-contratto-nuovo{background:linear-gradient(180deg,rgba(6,23,58,.55),rgba(0,19,43,.92) 70%),url(img/dream-night.jpg) center top/cover no-repeat,#001E44!important}',
    '#s-contratto-nuovo .ctr-top .blk-title{color:#fff}#s-contratto-nuovo .ctr-top .iconbtn{background:rgba(255,255,255,.14);color:#fff}#s-contratto-nuovo .ctr-prog{background:rgba(255,255,255,.15)}',
    '.ctr-genio{display:flex;align-items:flex-end;gap:10px;margin:4px 0 18px}.ctr-genio img{flex:none;width:86px;height:auto;filter:drop-shadow(0 8px 18px rgba(140,198,255,.4));animation:ctrGenio 4s ease-in-out infinite}@keyframes ctrGenio{50%{transform:translateY(-6px)}}',
    '.ctr-fum{position:relative;flex:1;min-width:0;padding:14px 16px;border-radius:20px 20px 20px 6px;background:#fff;box-shadow:0 10px 28px rgba(0,0,0,.3)}.ctr-fum .ctr-q{margin:0;font-size:19px;text-align:left;color:#001E44!important}.ctr-fum .ctr-qs{margin:6px 0 0;text-align:left;font-size:13.5px;color:#4A5A75!important}',
    '#s-contratto-nuovo .ctr-opzl{display:grid;grid-template-columns:1fr 1fr;gap:10px}#s-contratto-nuovo .ctr-euro{grid-template-columns:1fr 1fr}#s-contratto-nuovo .ctr-euro .ctr-opz:last-child{grid-column:auto}',
    '#s-contratto-nuovo .ctr-opz{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:84px;padding:12px 8px;border:1.5px solid rgba(188,224,255,.35);background:rgba(255,255,255,.08);color:#fff}#s-contratto-nuovo .ctr-opz.on{background:#F0FBFF;border-color:#0075E3;color:#001E44}',
    '.ctr-e{font-size:26px;line-height:1}#s-contratto-nuovo .ctr-l{color:#BFD3EC}#s-contratto-nuovo .ctr-scala div{background:rgba(255,255,255,.08);color:#fff}#s-contratto-nuovo .ctr-emo{display:none}',
    '#s-contratto-nuovo .ctr-esempi button{background:rgba(255,255,255,.08);color:#fff;border-color:rgba(188,224,255,.35)}',
    /* la firma */
    '.ctr-firme{margin:18px 0 6px;padding:16px;border-radius:20px;background:#FBF8F0;color:#3b2d20}.ctr-firma-box{position:relative;height:120px}.ctr-firma-box canvas{position:absolute;inset:0;width:100%;height:100%;cursor:crosshair}',
    '.ctr-firma-ph{position:absolute;left:0;right:0;top:36px;text-align:center;font:600 14px var(--font-body);color:#8a6a4a;pointer-events:none}.ctr-firma-riga{position:absolute;left:8px;right:8px;bottom:22px;height:1.5px;background:#8a6a4a}',
    '.ctr-firma-box small,.ctr-firma-gar small{position:absolute;left:0;right:0;bottom:0;text-align:center;font:700 11px var(--font-body);letter-spacing:.06em;color:#8a6a4a}.ctr-firma-az{display:flex;justify-content:center;gap:16px;margin:6px 0 10px}',
    '.ctr-firma-gar{position:relative;height:56px;border-top:1px dashed rgba(138,106,74,.4);padding-top:8px;text-align:center}.ctr-firma-gar i{font:500 24px "Caveat","DM Caveat","Segoe Print",cursive;color:#8a6a4a;opacity:.7}',
    '#ctrFirmaBtn[disabled]{opacity:.45}.pat-firma-img{display:block;height:46px;margin:0 auto -4px;object-fit:contain}',
    '.ctr-qs{margin:0;font:500 14.5px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.ctr-campo{min-height:90px;resize:none;margin:0;width:100%;box-sizing:border-box}',
    '.ctr-esempi{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.ctr-esempi button{border:1px dashed var(--line);background:transparent;border-radius:99px;padding:9px 13px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .ctr-esempi button{color:#fff;border-color:#22345A}',
    '.ctr-avanti{margin-top:12px}',
    '.ctr-scelte{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.ctr-scelte button{border:0;border-radius:99px;padding:8px 14px;background:#0075E3;color:#fff;font:700 13px var(--font-body);cursor:pointer}',
    '.ctr-appl{display:flex;flex-direction:column;gap:8px;max-height:46vh;overflow:auto;padding:2px}',
    '.ctr-app{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:13px 14px;border-radius:14px;border:1.5px solid var(--line);background:var(--card,#fff);cursor:pointer}body.dark .ctr-app{background:#12203A;border-color:#22345A}',
    '.ctr-app .ctr-ico{flex:none;width:40px;height:40px;border-radius:10px;font-style:normal;overflow:hidden}',
    '.ctr-app span{flex:1}.ctr-app b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .ctr-app b{color:#fff}.ctr-app small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.ctr-app i{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--line)}.ctr-app.on{border-color:#0075E3}.ctr-app.on i{border-color:#0075E3;background:#0075E3 url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27%3E%3Cpath d=%27M6 12l4 4 8-8%27 fill=%27none%27 stroke=%27white%27 stroke-width=%273%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27/%3E%3C/svg%3E") center/16px no-repeat}',
    '.ctr-opzl{display:flex;flex-direction:column;gap:10px}.ctr-euro{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.ctr-euro .ctr-opz{padding:12px 4px;font-size:14px}.ctr-euro .ctr-opz:last-child{grid-column:1/-1}',
    '.ctr-opz{width:100%;padding:15px 16px;border-radius:16px;border:1.5px solid var(--line);background:var(--card,#fff);font:700 15px var(--font-body);color:var(--navy);cursor:pointer;text-align:center}body.dark .ctr-opz{background:#12203A;border-color:#22345A;color:#fff}',
    '.ctr-opz.on{border-color:#0075E3;background:rgba(0,117,227,.1);color:#0075E3}body.dark .ctr-opz.on{color:#7CC4FF;border-color:#3F9FF4;background:rgba(63,159,244,.16)}',
    '.ctr-l{display:block;margin:6px 0 -6px;font:700 13.5px var(--font-body);color:var(--navy);text-align:center}body.dark .ctr-l{color:#fff}',
    '.ctr-w input.fin{margin:0;width:100%;box-sizing:border-box;text-align:center}',
    '.ctr-avviso{padding:14px 16px;border-radius:16px;background:rgba(230,57,70,.08);border:1px solid rgba(230,57,70,.35)}.ctr-avviso p{margin:0 0 6px;font:600 13.5px/1.45 var(--font-body);color:var(--navy)}body.dark .ctr-avviso p{color:#fff}',
    '.ctr-onesto{margin:4px 0 0;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);font:500 12.5px/1.45 var(--font-body);color:var(--muted)}body.dark .ctr-onesto{background:#0F1B33}',
    '.ctr-scala{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.ctr-scala > div{padding:12px 4px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .ctr-scala > div{background:#12203A;border-color:#22345A}',
    '.ctr-scala b{display:block;font:800 22px var(--font-body);color:#0075E3}body.dark .ctr-scala b{color:#7CC4FF}.ctr-scala small{display:block;font:600 11.5px var(--font-body);color:var(--muted)}.ctr-scala i{display:block;margin-top:4px;font:600 10.5px var(--font-body);font-style:normal;color:var(--muted)}',
    '.ctr-scala .ctr-scala-fine{grid-column:span 2;border-color:#E63946}.ctr-scala .ctr-scala-fine b{color:#E63946}',
    '.ctr-carta{padding:22px 20px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .ctr-carta{background:#12203A;border-color:#22345A}.ctr-carta p{margin:0 0 12px;font:500 15px/1.6 var(--font-body);color:var(--navy)}body.dark .ctr-carta p{color:#fff}.ctr-carta p:first-child{font:700 17px/1.5 var(--font-body)}.ctr-carta p:last-child{margin:0}',
    '.ctr-durata{margin:0}',
    '.ctr-firma{margin-top:16px}',
    '.ctr-porta-host{margin:18px 0 6px}#ctrBlHost{margin:-8px 18px 24px}',
    '.ctr-porta{display:flex;flex-direction:column;align-items:center;gap:6px;width:100%;padding:20px 18px;border-radius:22px;border:1px solid var(--line);background:var(--card,#fff);text-align:center;cursor:pointer}body.dark .ctr-porta{background:#12203A;border-color:#22345A}',
    '.ctr-porta .ctr-emo{width:52px;height:52px;font-size:26px;margin-bottom:6px}.ctr-porta b{font:800 17px var(--font-display);color:var(--navy)}body.dark .ctr-porta b{color:#fff}.ctr-porta small{font:500 13px/1.4 var(--font-body);color:var(--muted);max-width:30ch}',
    '.ctr-porta.on{border-color:#0075E3}',
    '#ctrA{min-height:100%;display:flex}#ctrA > .ef{flex:1}',
    '.ctr-stato-giu{margin:28px 0 0}.ctr-chiedi{width:100%;min-height:52px;border:1.5px solid #0075E3;border-radius:26px;background:transparent;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}body.dark .ctr-chiedi{color:#7CC4FF;border-color:#3F9FF4}',
    '#s-contratto-attesa{padding:0!important;background:linear-gradient(180deg,#0B2A5C 0%,#001E44 38%,#00132D 100%)}',
    '.ctr-a .ef-anello > span{display:flex;align-items:center;justify-content:center}.ctr-a-dentro{display:flex;flex-direction:column;align-items:center}.ctr-a-dentro .ef-tempo{margin:0}.ctr-a-dentro small{margin-top:8px;font:600 13px var(--font-body);color:rgba(220,234,255,.75)}',
    '.ctr-a .ctr-a-pross{margin-top:16px;font-size:14px;color:rgba(220,234,255,.6)}',
    '.ctr-stampa{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:52px;margin:24px 0 8px;border:1.5px solid #0075E3;border-radius:26px;background:transparent;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}body.dark .ctr-stampa{color:#7CC4FF;border-color:#3F9FF4}',
    '.ctr-attesa-g{display:flex;flex-direction:column;align-items:center;gap:10px;margin:8px 0 22px;padding:24px 20px;border-radius:22px;background:linear-gradient(180deg,#0B2A5C,#001E44);color:#fff;text-align:center}',
    '.ctr-attesa-g .ctr-emo{width:56px;height:56px;font-size:28px;margin-bottom:4px}.ctr-attesa-g b{font:800 18px/1.35 var(--font-display);color:#fff}.ctr-attesa-g p{margin:0 0 6px;font:500 14px/1.5 var(--font-body);color:#BCE0FF}.ctr-attesa-g .am-cta{margin-top:6px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
(function(){ const st = document.createElement('style'); st.textContent = '.ctr-diploma{margin:4px 0 26px;border-radius:18px;overflow:hidden;box-shadow:0 10px 30px rgba(0,30,68,.18);background:#FBF8F1;min-height:200px}.ctr-diploma img{display:block;width:100%;height:auto}.ctr-diploma-c{padding:80px 20px;text-align:center;font:600 14px var(--font-body);color:#4A5B74}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style');
  st.textContent = '.ctr-opzl.ctr-chips{display:flex!important;flex-direction:row!important;flex-wrap:wrap;justify-content:center;gap:8px!important;grid-template-columns:none!important}.ctr-opzl.ctr-chips .ctr-opz{width:auto!important;min-width:0!important;flex:0 0 auto!important;margin:0!important;padding:11px 16px!important;border-radius:99px!important;min-height:0!important}';
  document.head.appendChild(st); })();

/* ---------- 0.9.382: i preset che si sommano e le promesse sulla schermata di blocco ---------- */
/** Un esempio toccato si aggiunge come punto elenco sotto a quelli gia' scritti (non sostituisce piu' il testo). */
function ctrEsempioAggiungi(t){
  const ta = document.getElementById('ctrImpegno'); if (!ta) return;
  const righe = String(ta.value || '').split('\n').map(function(r){ return r.replace(/^\s*[•\-]\s*/, '').trim(); }).filter(Boolean);
  if (righe.indexOf(t) >= 0) return;
  righe.push(t);
  ta.value = righe.map(function(r){ return '• ' + r; }).join('\n');
  try{ flVibra(6); }catch(_){ }
  if (CTR.w) CTR.w.impegno = ta.value.trim();
}
function ctrAlPosto(k){
  ctrLeggiCampi();
  const w = CTR.w; if (!w) return;
  if (!w.alPosto) w.alPosto = [];
  const i = w.alPosto.indexOf(k);
  if (i >= 0) w.alPosto.splice(i, 1); else w.alPosto.push(k);
  w.invece = '';
  try{ flVibra(6); }catch(_){ }
  ctrWPaint();
}
function ctrAlPostoVoci(w){ const t = (typeof RNG_PREMI !== 'undefined' ? RNG_PREMI : []); return (w.alPosto || []).map(function(k){ return t.filter(function(x){ return x[0] === k; })[0]; }).filter(Boolean); }
function ctrAlPostoTesto(w){
  const v = ctrAlPostoVoci(w);
  if (!v.length) return w.invece || '';
  if (v.length === 1) return T(v[0][3]);
  return T('giro la ruota e faccio una di queste: {lista}', { lista: v.map(function(x){ return ctrIt() ? ctrMinuscola(x[2]) : T(x[2]); }).join(', ') });
}
/** Alla firma: per ogni app del contratto la schermata di blocco mostra la promessa (con la ruota, il rompicapo, il cruciverba). */
function ctrPromessaSulBlocco(w){
  const v = ctrAlPostoVoci(w), apps = (w.apps || []).map(function(a){ return a.p || a; }).filter(Boolean);
  if (!apps.length || (!v.length && !w.invece)) return;
  let s;
  /* 0.9.387, Andrea (BUG-106): sulla schermata di blocco le card con le emoji: ogni voce porta l'emoji della sua card */
  if (v.length >= 2) s = '@ruota ' + v.map(function(x){ return typeof rngVoceRuota === 'function' ? rngVoceRuota(x[1], T(x[3])) : x[1] + ' ' + T(x[3]); }).join('|').replace(/[ \t]+/g, ' ') + '\n' + T('Giro la ruota e faccio quello che esce.');
  else if (v.length === 1) s = (v[0][0] === 'rompicapo' ? '@rompicapo ' : (v[0][0] === 'cruciverba' ? '@cruciverba ' : '')) + T(v[0][3]).replace(/[.\s]+$/, '') + '.';
  else s = String(w.invece).replace(/[.\s]+$/, '') + '.';
  const m = JSON.parse(localStorage.getItem('fl_sostituzioni') || '{}') || {};
  apps.forEach(function(p){ m[p] = s; });
  localStorage.setItem('fl_sostituzioni', JSON.stringify(m));
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ sostituzioni: JSON.stringify(m) }).catch(function(){ });
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.ctr-alp{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:22px 0 4px}'
  + '.ctr-alp-c{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;min-height:112px;padding:16px 12px;border-radius:20px;border:2px solid #E3EAF4;background:#fff;color:#0E2350;text-align:center;font:inherit;cursor:pointer;box-shadow:0 4px 14px rgba(0,30,68,.06)}'
  + '.ctr-alp-c > span{font-size:30px;line-height:1}.ctr-alp-c b{font:700 14px/1.3 var(--font-body)}'
  + '.ctr-alp-c.on{border-color:#0075E3;background:#EAF4FF;box-shadow:0 0 0 3px rgba(0,117,227,.15)}'
  + '.ctr-alp-altre{display:block;margin:16px auto 0;border:0;background:none;font:700 14px var(--font-body);color:#0075E3;text-decoration:underline;text-underline-offset:3px;cursor:pointer}'
  + '.ctr-alp-ruota{display:flex;align-items:center;gap:12px;margin:18px 0 0;padding:14px 16px;border-radius:16px;background:linear-gradient(135deg,#E3F2FD,#FDECEF)}.ctr-alp-ruota span{font-size:26px}.ctr-alp-ruota p{margin:0;font:600 14px/1.4 var(--font-body);color:#0E2350}'
  + '.ctr-alp-mia{margin-top:22px}'
  /* card bianche in tutti e due i temi (la scena del contratto e' scura): testo scuro fisso */
  + 'body.dark .ctr-alp-c{background:#fff!important;border-color:#E3EAF4!important;color:#0E2350!important}body.dark .ctr-alp-c.on{background:#EAF4FF!important;border-color:#0075E3!important}body.dark .ctr-alp-c b{color:#0E2350!important}body .ctr-alp-ruota p{color:#0E2350!important}';
  document.head.appendChild(st); })();
/* 22/11/2026: quando arriva la traduzione (lingua.js) le pagine del contratto si ridisegnano */
if (typeof ltAlCambio === 'function') ltAlCambio(function(){ if (document.getElementById('ctrBody') && CTR.s) ctrPaint(); if (document.getElementById('ctrW') && CTR.w) ctrWPaint(); });

/* ---------------------------------------------------------------------------------------
   0.9.401 (BUG-202), Andrea: "nel contratto d'abitudine, se l'utente dice che gli piace ascoltare musica, prima di passare al passo
   dopo sceglie quale: un file dal telefono oppure un link YouTube. Cosi', quando la ruota la fa uscire, un pulsante la fa partire
   subito". Con la card della musica scelta compare la domanda con le due strade; Avanti non va avanti finche' non ne hai scelta una
   (ctrControlla). Il file lo salva canzoneSalvaFile, il link canzoneSalvaLink (rientro-genio.js): tutti e due arrivano alla
   schermata di blocco.
   --------------------------------------------------------------------------------------- */
/** La card della musica e' scelta ma la musica no. */
function ctrCanzoneManca(w){
  if (!w || !(w.alPosto || []).length || w.alPosto.indexOf('musica') < 0) return false;
  const f = typeof canzoneScelta === 'function' ? canzoneScelta() : null;
  const l = typeof canzoneLink === 'function' ? canzoneLink() : null;
  return !f && !l;
}
function ctrCanzoneHtml(){
  const f = typeof canzoneScelta === 'function' ? canzoneScelta() : null;
  const l = typeof canzoneLink === 'function' ? canzoneLink() : null;
  let testa;
  if (f) testa = '<p class="ctr-cz-t"><span aria-hidden="true">🎵</span> ' + ctrEsc(T('La tua canzone è {titolo}.', { titolo: f.titolo || T('il file scelto') })) + '</p><p class="ctr-cz-s">' + T('Quando esce sulla ruota, parte da sola.') + '</p>';
  else if (l) testa = '<p class="ctr-cz-t"><span aria-hidden="true">▶️</span> ' + T('La tua musica è un link di YouTube.') + '</p><p class="ctr-cz-s">' + T('Quando esce sulla ruota, la fai partire con un tocco.') + '</p>';
  else testa = '<p class="ctr-cz-t">' + T('Quale <em>musica</em> vuoi ascoltare?') + '</p><p class="ctr-cz-s">' + T('Quando esce sulla ruota, la fai partire con un tocco.') + '</p>';
  const scelta = !!(f || l);
  return '<div class="ctr-canzone" id="ctrCanzone">' + testa
    + '<div class="ctr-cz-opz">'
    + canzoneBottone('ctr-cz-b' + (f ? ' on' : ''), '<span aria-hidden="true">📁</span>' + T(scelta && f ? 'Cambia file' : 'Un file dal telefono'), 'contratto')
    + '<button type="button" class="ctr-cz-b' + (l || CTR.czLink ? ' on' : '') + '" onclick="ctrCanzoneLinkApri()"><span aria-hidden="true">▶️</span>' + T(l ? 'Cambia link' : 'Un link di YouTube') + '</button>'
    + '</div>'
    + (CTR.czLink ? '<div class="ctr-cz-link"><input id="ctrCzLink" class="fin" type="url" inputmode="url" autocomplete="off" placeholder="' + ctrEsc(T('Incolla qui il link di YouTube')) + '" value="' + ctrEsc(l ? l.url : '') + '">'
      + '<button type="button" class="ctr-cz-ok" onclick="ctrCanzoneLinkOk()">' + T('Usa questo link') + '</button></div>' : '')
    + '</div>';
}
function ctrCanzoneLinkApri(){
  ctrLeggiCampi();
  CTR.czLink = !CTR.czLink;
  ctrWPaint();
  if (CTR.czLink) setTimeout(function(){ const i = document.getElementById('ctrCzLink'); if (i){ try{ i.focus(); }catch(_){ } ctrCanzoneMostra(); } }, 60);
}
function ctrCanzoneLinkOk(){
  const i = document.getElementById('ctrCzLink');
  if (typeof canzoneSalvaLink !== 'function') return;
  const c = canzoneSalvaLink(i ? i.value : '');
  if (!c) return;
  CTR.czLink = false;
  try{ flVibra(10); toast('▶️ ' + T('Il link è salvato')); }catch(_){ }
  ctrLeggiCampi();
  ctrWPaint();
}
/** Porta la domanda della musica in vista (sotto le card puo' stare fuori dallo schermo). */
function ctrCanzoneMostra(){
  try{ const b = document.getElementById('ctrCanzone'); if (b) b.scrollIntoView({ behavior: 'smooth', block: 'center' }); }catch(_){ }
}
/* toccata la card della musica, la domanda compare subito sotto: la si porta in vista */
(function(){
  if (typeof ctrAlPosto !== 'function' || ctrAlPosto.__cz) return;
  const vero = ctrAlPosto;
  const g = function(k){
    const r = vero.apply(this, arguments);
    try{ if (k === 'musica' && CTR.w && (CTR.w.alPosto || []).indexOf('musica') >= 0 && ctrCanzoneManca(CTR.w)) setTimeout(ctrCanzoneMostra, 80); }catch(_){ }
    return r;
  };
  g.__cz = true;
  ctrAlPosto = g;
})();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* il riquadro chiaro c'era gia' (rientro-genio.js, .ctr-canzone): qui la domanda, le due strade staccate e il campo del link */
  '#ctrCanzone{align-items:stretch;gap:0;margin-top:20px;padding:18px 16px;text-align:left}'
  + '#ctrCanzone .ctr-cz-t{margin:0;font:800 16px/1.35 var(--font-body)}#ctrCanzone .ctr-cz-t em{font-style:normal;color:#0075E3}'
  + '#ctrCanzone .ctr-cz-s{margin:6px 0 0;font:500 13.5px/1.45 var(--font-body);color:#3D5478!important}'
  + '#ctrCanzone .ctr-cz-opz{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px}'
  + '#ctrCanzone .ctr-cz-b{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:84px;padding:12px 10px;border-radius:16px;border:2px solid #D5E3F3;background:#fff;color:#0E2350;font:700 13.5px/1.3 var(--font-body);text-align:center;cursor:pointer;box-shadow:0 3px 10px rgba(0,30,68,.06)}'
  + '#ctrCanzone .ctr-cz-b > span{font-size:24px;line-height:1}'
  + '#ctrCanzone .ctr-cz-b.on{border-color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.15)}'
  + '#ctrCanzone .ctr-cz-link{display:flex;flex-direction:column;gap:10px;margin-top:14px}#ctrCanzone .ctr-cz-link .fin{margin:0;background:#fff;color:#0E2350;border-color:#D5E3F3}'
  + '#ctrCanzone .ctr-cz-ok{align-self:stretch;padding:13px 18px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 14.5px var(--font-body);cursor:pointer}'
  /* il riquadro resta chiaro anche nel tema scuro: testo scuro fisso */
  + 'body.dark #ctrCanzone{background:#EAF4FF!important;color:#0E2350!important}body.dark #ctrCanzone .ctr-cz-t{color:#0E2350!important}body.dark #ctrCanzone .ctr-cz-t em{color:#0075E3!important}'
  + 'body.dark #ctrCanzone .ctr-cz-b{background:#fff!important;color:#0E2350!important;border-color:#D5E3F3!important}body.dark #ctrCanzone .ctr-cz-b.on{border-color:#0075E3!important}'
  + 'body.dark #ctrCanzone .ctr-cz-link .fin{background:#fff!important;color:#0E2350!important;border-color:#D5E3F3!important}body.dark #ctrCanzone .ctr-cz-ok{background:#0075E3!important;color:#fff!important}';
  document.head.appendChild(st); })();
