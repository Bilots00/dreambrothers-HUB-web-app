/* ===========================================================================================
   LE NOTE FRA TELEFONO E COMPUTER: LO SPECCHIO (0.9.359, rifatto nella 0.9.391)

   Andrea, 14/11: "le note del PC, quando clicco la shortcut I miei appunti, non sono sincronizzate con quelle che scrivo dal
   telefono: quelle del PC sono rimaste indietro. Devono essere sincronizzate, come tutte le altre sezioni dell'app".
   Andrea, 25/11 sera: "Ho creato una nota di prova sul telefono e sul DreamMap Desktop non c'è; le note del PC sono in ordine
   diverso da quelle del telefono. Non è uno specchio. Risolvi."

   COME FUNZIONA. Ogni nota e' una riga sul server, sotto la chiave del piano (fl_piano_chiave), uguale su telefono e PC
   (dreammapPiano.ts, note-sync):
   - si mandano le note cambiate qui (mod piu' recente di quanto il server sa, in fl_note_sync_visti) e si prendono quelle
     cambiate altrove (dopo l'ultimo seq letto, fl_note_sync_seq); per ogni nota vince la modifica piu' recente;
   - una nota e' tolta qui se va nel cestino, oppure se c'era all'ultimo giro e adesso non c'e' piu' (spostata nel caveau,
     scartata vuota, unita a un doppione): l'elenco dell'ultimo giro sta in fl_note_sync_ids;
   - una nota tolta sull'altro dispositivo qui va nel cestino, da cui si rimette per 30 giorni: niente si perde;
   - una nota cambiata altrove DOPO che l'avevi tolta torna (la modifica piu' recente vince anche qui);
   - le immagini (nimg:, nel magazzino del telefono) salgono sul server una volta e nella nota diventano un indirizzo.

   0.9.391, LE CAUSE DEL "NON E' UNO SPECCHIO":
   1. con le note aperte a schermo il giro non faceva niente, ne' in uscita ne' in entrata ("la replica riscriverebbe sopra"):
      chi scrive e resta nelle note non mandava niente, e il PC con le note aperte non riceveva niente;
   2. le note aperte dall'icona sulla Home del telefono (NoteActivity, note/index.html?app=sola) non avevano nessuna
      sincronizzazione: questo file non c'era. Una nota scritta li' partiva solo riaprendo DreamMap, e mai se DreamMap restava
      sulle note o in sottofondo;
   3. un errore nel prendere le novita' dal server fermava tutto il giro, anche l'invio delle note scritte qui; e un giro
      rimasto appeso (rete che non risponde) bloccava tutti i giri dopo fino alla chiusura dell'app.
   ADESSO: la replica (www/note/app.js, notes-provider) non riscrive piu' sopra a nessuno: prima di scrivere unisce la sua copia
   con quella in memoria (vince la modifica piu' recente, nota per nota), e quando la memoria cambia (evento storage, o
   __noteAggiorna chiamata da qui) si aggiorna da sola, tranne la nota aperta nell'editor, che resta com'e' finche' non la
   chiudi. Quindi il giro scrive anche con le note aperte, e:
   - appena la replica salva una nota (__noteScritte) il giro parte dopo 1,5 s, anche con le note aperte;
   - con le note aperte un giro ogni 12 s, se no ogni 90 s; subito (1,5 s) quando l'app torna davanti;
   - una nota appena scritta parte anche se l'app va in sottofondo subito dopo (per 60 s);
   - questo file gira sia in DreamMap sia nelle note aperte dall'icona (note/index.html lo carica con ?app=sola).
   =========================================================================================== */
const MN_SYNC_SEQ = 'fl_note_sync_seq', MN_SYNC_VISTE = 'fl_note_sync_visti', MN_SYNC_IDS = 'fl_note_sync_ids', MN_IMG_URL = 'fl_note_img_url';
const MN_SERVER = 'https://meta-ai-media-buyer-production.up.railway.app';
const NS = { sync: false, syncDa: 0, scrittaAt: 0, ultimoGiro: 0 };
/* le note aperte dall'icona sulla Home: questa pagina e' la replica stessa, senza DreamMap intorno */
const NS_SOLA = (function(){ try{ return /\/note\//.test(location.pathname) && /[?&]app=sola/.test(location.search); }catch(_){ return false; } })();

/* ---- le note e il cestino: le funzioni della Mappa (mappa-note.js) se ci sono, se no le stesse letture qui ---- */
function nsLista(){
  if (typeof mnLista === 'function') return mnLista();
  try{ const l = JSON.parse(localStorage.getItem('fl_note_v1') || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; }
}
function nsSalvaLista(l){
  try{ localStorage.setItem('fl_note_v1', JSON.stringify(l)); localStorage.setItem('fl_note_v1_at', String(Date.now())); return true; }catch(_){ return false; }
}
function nsCestino(){
  if (typeof mnCestino === 'function') return mnCestino();
  let l = []; try{ l = JSON.parse(localStorage.getItem('fl_note_cestino') || '[]'); }catch(_){ l = []; }
  const limite = Date.now() - 30 * 864e5;
  return (Array.isArray(l) ? l : []).filter(function(n){ return n && n.id && (n.via || 0) > limite; });
}
function nsCestinoSalva(l){
  if (typeof mnCestinoSalva === 'function') return mnCestinoSalva(l);
  try{ localStorage.setItem('fl_note_cestino', JSON.stringify(l)); }catch(_){ }
}
function nsAvvisa(m){ try{ if (typeof toast === 'function') toast(m); }catch(_){ } }
function nsDipingi(){ try{ if (typeof mnPaint === 'function') mnPaint(); }catch(_){ } }
/* la replica si aggiorna da sola con l'evento storage; nella stessa pagina (note dall'icona) l'evento non arriva: la si chiama */
function nsAvvisaReplica(){
  try{ if (typeof window.__noteAggiorna === 'function') window.__noteAggiorna(); }catch(_){ }
  try{ const f = document.getElementById('noFrame'); const w = f && f.contentWindow; if (w && w !== window && typeof w.__noteAggiorna === 'function') w.__noteAggiorna(); }catch(_){ }
}

function mnChiave(){ let k = ''; try{ k = localStorage.getItem('fl_piano_chiave') || ''; }catch(_){ } return /^[A-Za-z0-9_-]{32,64}$/.test(k) ? k : ''; }
async function mnApi(method, path, body){
  if (typeof frApi === 'function'){
    try{ return await frApi(method, path, body); }
    catch(e){ if (!/offline/.test(String(e && e.message || e))) throw e; }
  } else {
    /* note dall'icona: niente friends.js, ma lo stesso ponte del telefono (index.html mette window.NATIVE) */
    const nat = (typeof NATIVE !== 'undefined' && NATIVE) || window.NATIVE || null;
    if (nat && typeof nat.publicApi === 'function'){
      const r = await nat.publicApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
      if (r && r.error) throw new Error(String(r.error));
      return r || {};
    }
  }
  const r = await fetch(MN_SERVER + path, { method: method, cache: 'no-store', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(function(){ return {}; });
  if (!r.ok || (j && j.error)) throw new Error((j && j.error) || ('http ' + r.status));
  return j;
}
function mnLeggiJson(k, def){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; }catch(_){ return def; } }
function mnScriviJson(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); return true; }catch(_){ return false; } }
/* le note sono aperte a schermo (adesso decide solo quanto spesso si fa il giro) */
function mnNoteAperte(){
  if (NS_SOLA) return true;
  try{ return !!MN.aperto || (typeof order !== 'undefined' && order[cur] === 's-note'); }catch(_){ return false; }
}
function mnSyncNascosto(){ try{ return typeof mwQuiComputer === 'function' && !!mwQuiComputer(); }catch(_){ return false; } }

/* ---- le immagini: dal magazzino del telefono (IndexedDB della replica) al server, una volta sola ---- */
function mnImgDb(){
  return new Promise(function(ok){
    try{
      const r = indexedDB.open('fl-note-sicure');
      r.onupgradeneeded = function(){ try{ r.transaction.abort(); }catch(_){ } };   // non esiste: la crea la replica, non noi
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ok(null); };
      r.onblocked = function(){ ok(null); };
    }catch(_){ ok(null); }
  });
}
function mnImgLeggi(db, k){
  return new Promise(function(ok){
    try{ const q = db.transaction('immagini', 'readonly').objectStore('immagini').get(k); q.onsuccess = function(){ ok(typeof q.result === 'string' ? q.result : null); }; q.onerror = function(){ ok(null); }; }catch(_){ ok(null); }
  });
}
/** L'html della nota con le immagini come indirizzi del server; null se un'immagine non e' salita (si riprova dopo). */
async function mnHtmlPerIlServer(html, k, stato){
  const imp = String(html || '').match(/nimg:[a-z0-9]+/g);
  if (!imp) return html;
  const mappa = stato.url;
  for (const x of Array.from(new Set(imp))){
    const h = x.slice(5);
    if (mappa[h]) continue;
    if (stato.db === undefined) stato.db = await mnImgDb();
    if (!stato.db) return null;
    const dato = await mnImgLeggi(stato.db, h);
    const m = dato && dato.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!m) return null;
    try{
      const r = await mnApi('POST', '/api/focuslock/piano/' + k + '/img', { mime: m[1].toLowerCase(), b64: m[2] });
      if (!r || !r.url) return null;
      mappa[h] = /^https?:/.test(r.url) ? r.url : MN_SERVER + r.url;
      stato.cambiate = true;
    }catch(_){ return null; }
  }
  return String(html).replace(/nimg:([a-z0-9]+)/g, function(t, h){ return mappa[h] || t; });
}

/* ---- 1. le novita' dal server, scritte nella memoria in un colpo solo (lettura, unione, scrittura: niente attese in mezzo) ---- */
async function nsRicevi(k, visti, fuori){
  const tolteOra = {}; fuori.forEach(function(t){ tolteOra[t.id] = t.mod; });
  const perId = {}; nsLista().forEach(function(n){ if (n && n.id) perId[n.id] = n; });
  const nelCestino = {}; nsCestino().forEach(function(n){ nelCestino[n.id] = n; });
  let dopo = +localStorage.getItem(MN_SYNC_SEQ) || 0;
  const metti = {}, togli = {}, daTogliere = [], dalCestino = {};
  let giri = 0;
  for (;;){
    const r = await mnApi('GET', '/api/focuslock/piano/' + k + '/note-sync?dopo=' + dopo);
    (r.note || []).forEach(function(x){
      if (!x || !x.id) return;
      const qui = perId[x.id];
      const v = visti[x.id] || 0;
      if (!x.via && ((v < 0 && -v >= x.mod) || (tolteOra[x.id] && tolteOra[x.id] >= x.mod))) return;   // tolta qui dopo quella modifica
      if (x.via){
        visti[x.id] = -x.mod;
        if (qui && (qui.mod || 0) <= x.mod){
          /* tolta sull'altro dispositivo: qui va nel cestino, si rimette per 30 giorni */
          delete metti[x.id]; togli[x.id] = { id: x.id, mod: x.mod }; delete perId[x.id];
        }
        return;
      }
      let nota = null; try{ nota = JSON.parse(x.dati); }catch(_){ nota = null; }
      if (!nota || nota.id !== x.id) return;
      const c = nelCestino[x.id];
      if (c && (c.via || 0) >= x.mod){ daTogliere.push({ id: x.id, via: 1, mod: c.via }); return; }   // tolta qui dopo quella modifica
      if (c) dalCestino[x.id] = 1;                                                                       // cambiata altrove dopo che l'avevi tolta: torna
      if (!qui || (qui.mod || 0) < x.mod){
        nota.mod = x.mod;
        metti[x.id] = nota; delete togli[x.id]; perId[x.id] = nota;
      }
      visti[x.id] = Math.max(visti[x.id] > 0 ? visti[x.id] : 0, x.mod);
    });
    dopo = r.seq || dopo;
    if (!r.piu || ++giri > 30) break;
  }
  /* la scrittura: si rilegge la memoria ADESSO (la replica puo' aver salvato mentre si aspettava il server) e per ogni nota
     vince ancora la modifica piu' recente */
  const ids = Object.keys(metti), via = Object.keys(togli);
  if (ids.length || via.length){
    let l = nsLista(); const ora = {}; l.forEach(function(n, i){ if (n && n.id) ora[n.id] = i; });
    let arrivate = 0, cambiate = 0; const tolte = [];
    ids.forEach(function(id){
      const i = ora[id], nota = metti[id];
      if (i === undefined){ ora[id] = l.length; l.push(nota); arrivate++; cambiate++; }
      else if ((l[i].mod || 0) < nota.mod){ l[i] = nota; cambiate++; }
    });
    via.forEach(function(id){
      const i = ora[id]; if (i === undefined) return;
      const n = l[i]; if (!n || (n.mod || 0) > togli[id].mod) return;   // cambiata qui intanto: resta
      tolte.push(n); l[i] = null; cambiate++;
    });
    l = l.filter(Boolean);
    if (cambiate){
      if (!nsSalvaLista(l)){ nsAvvisa('Il telefono è pieno: alcune note dell’altro dispositivo non sono entrate'); return; }
      nsAvvisaReplica();
      nsDipingi();
      if (arrivate) nsAvvisa(arrivate === 1 ? '1 nota arrivata dall’altro dispositivo' : arrivate + ' note arrivate dall’altro dispositivo');
    }
    let cestino = nsCestino(), cestinoCambiato = false;
    if (tolte.length){
      const t = {}; tolte.forEach(function(n){ t[n.id] = 1; });
      const adesso = Date.now();
      cestino = tolte.map(function(n){ return Object.assign({}, n, { via: adesso }); }).concat(cestino.filter(function(c){ return !t[c.id]; }));
      cestinoCambiato = true;
    }
    if (Object.keys(dalCestino).some(function(id){ return metti[id]; })){
      cestino = cestino.filter(function(c){ return !(dalCestino[c.id] && metti[c.id]); }); cestinoCambiato = true;
    }
    if (cestinoCambiato) nsCestinoSalva(cestino);
  }
  try{ localStorage.setItem(MN_SYNC_SEQ, String(dopo)); }catch(_){ }
  if (daTogliere.length){ try{ await mnApi('POST', '/api/focuslock/piano/' + k + '/note-sync', { note: daTogliere }); daTogliere.forEach(function(t){ visti[t.id] = -t.mod; }); }catch(_){ } }
}

/* ---- il giro ---- */
let MN_SYNC_T = 0;
function mnSyncPresto(ms){ clearTimeout(MN_SYNC_T); MN_SYNC_T = setTimeout(function(){ mnSync().catch(function(){ }); }, ms || 4000); }
function nsErrore(e){ try{ localStorage.setItem('fl_note_sync_err', JSON.stringify({ at: Date.now(), msg: String(e && e.message || e).slice(0, 200) })); }catch(_){ } }
async function mnSync(){
  /* un giro rimasto appeso (rete che non risponde) non blocca piu' tutti gli altri: dopo 2 minuti se ne fa un altro */
  if (NS.sync && Date.now() - NS.syncDa < 120000) return;
  /* in sottofondo il telefono non sincronizza (batteria), tranne una nota scritta un attimo fa; il PC si' (sta nascosto) */
  if (document.hidden && !mnSyncNascosto() && !(Date.now() - NS.scrittaAt < 60000)) return;
  const k = mnChiave(); if (!k) return;
  const giro = Date.now();
  NS.sync = true; NS.syncDa = giro; NS.ultimoGiro = giro;
  try{
    const visti = mnLeggiJson(MN_SYNC_VISTE, {}) || {};
    const stato = { url: mnLeggiJson(MN_IMG_URL, {}) || {}, cambiate: false };
    /* 0. LE NOTE TOLTE QUI SENZA CESTINO: c'erano all'ultimo giro e adesso no (caveau, nota vuota scartata, doppione unito) */
    const fuori = [];
    {
      const ora = {}; nsLista().forEach(function(n){ if (n && n.id) ora[n.id] = 1; });
      const nelC = {}; nsCestino().forEach(function(c){ nelC[c.id] = 1; });
      (mnLeggiJson(MN_SYNC_IDS, []) || []).forEach(function(id){
        if (!ora[id] && !nelC[id] && !((visti[id] || 0) < 0)) fuori.push({ id: id, via: 1, mod: Date.now() });
      });
    }
    /* 0.9.388, Andrea 24/11: "nelle note non c'ho più tutte le note che avevo nella vecchia DreamMap". LA CAUSA: il backup JSON salta
       fl_note_v1 (sopra 700 KB) ma portava l'elenco dell'ultimo giro (fl_note_sync_ids). La nuova app aveva l'elenco e nessuna nota, e qui
       sopra le ha date tutte per tolte: il server e il PC le hanno spostate nel cestino. IL FRENO: tante note sparite in un colpo, senza
       che l'utente le abbia messe nel cestino, non sono una scelta dell'utente. Non si manda niente: si riparte dall'elenco di adesso e si
       rilegge tutto dal server. */
    {
      const giroPrima = (mnLeggiJson(MN_SYNC_IDS, []) || []).length;
      if (fuori.length >= 5 && fuori.length * 3 > giroPrima){
        try{ localStorage.setItem('fl_note_sync_freno', JSON.stringify({ at: Date.now(), tolte: fuori.length, giro: giroPrima })); }catch(_){ }
        mnScriviJson(MN_SYNC_IDS, nsLista().filter(function(n){ return n && n.id; }).map(function(n){ return n.id; }));
        try{ localStorage.setItem(MN_SYNC_SEQ, '0'); }catch(_){ }
        fuori.length = 0;
      }
    }
    /* 1. LE NOVITA' DAL SERVER. 0.9.391: se il server non risponde, le note scritte qui partono lo stesso (punto 2) */
    try{ await nsRicevi(k, visti, fuori); }catch(e){ nsErrore(e); }
    /* 2. QUELLO CHE QUI E' PIU' NUOVO DI QUANTO IL SERVER SA (dopo le note tolte senza cestino, gia' in fuori) */
    nsLista().forEach(function(n){
      if (!n || !n.id) return;
      const m = n.mod || 0, v = visti[n.id] || 0;
      if (m > Math.abs(v) || (v === 0 && m === 0)) fuori.push(n);
    });
    nsCestino().forEach(function(c){
      const v = visti[c.id] || 0;
      if (v < 0 && -v >= (c.via || 0)) return;                 // la sua uscita il server la sa gia'
      if (v > 0 && v > (c.via || 0)) return;                    // cambiata altrove dopo: non la si toglie
      fuori.push({ id: c.id, via: 1, mod: c.via || Date.now() });
    });
    for (let i = 0; i < fuori.length; i += 25){
      const lotto = [];
      for (const n of fuori.slice(i, i + 25)){
        if (n.via && !n.title && n.html === undefined){ lotto.push(n); continue; }
        const html = await mnHtmlPerIlServer(n.html, k, stato);
        if (html === null) continue;                            // un'immagine non e' salita: questa nota riprova al prossimo giro
        const mod = n.mod || Date.now();
        lotto.push({ id: n.id, mod: mod, via: 0, dati: JSON.stringify(Object.assign({}, n, { html: html, mod: mod })) });
      }
      if (!lotto.length) continue;
      const r = await mnApi('POST', '/api/focuslock/piano/' + k + '/note-sync', { note: lotto });
      const ok = {}; ((r && r.esiti) || []).forEach(function(e){ if (e && e.ok) ok[e.id] = 1; });
      lotto.forEach(function(n){ if (ok[n.id]) visti[n.id] = n.via ? -n.mod : n.mod; });
    }
    mnScriviJson(MN_SYNC_VISTE, visti);
    if (stato.cambiate) mnScriviJson(MN_IMG_URL, stato.url);
    /* l'elenco di questo giro: le note che ci sono, piu' quelle tolte il cui segno non e' ancora arrivato al server (riprova) */
    const ids = {}; nsLista().forEach(function(n){ if (n && n.id) ids[n.id] = 1; });
    fuori.forEach(function(t){ if (t.via && !((visti[t.id] || 0) < 0) && !t.title) ids[t.id] = 1; });
    mnScriviJson(MN_SYNC_IDS, Object.keys(ids));
    try{ localStorage.setItem('fl_note_sync_at', String(Date.now())); }catch(_){ }
  }catch(e){
    nsErrore(e);
  }finally{ if (NS.syncDa === giro) NS.sync = false; }
}

/* ---- quando ---- */
/* la replica ha appena salvato (notes-provider, dopo ogni scrittura): si manda subito, anche con le note aperte */
window.__noteScritte = function(){ NS.scrittaAt = Date.now(); mnSyncPresto(1500); };
/* la replica dentro DreamMap (iframe) scrive nella stessa memoria: qui arriva l'evento storage */
try{ window.addEventListener('storage', function(e){ if (e && e.key === 'fl_note_v1'){ NS.scrittaAt = Date.now(); mnSyncPresto(1500); } }); }catch(_){ }
/* all'avvio (dopo le note importate e il recupero, nella Mappa), quando l'app torna davanti, e a giri: ogni 12 s con le note
   aperte, ogni 90 s se no. 0.9.389, Andrea 25/11: "le note del PC sono diverse da quelle che avevo sul telefono". Il programma del
   PC sta quasi sempre nascosto (nell'area di notifica): sul computer si sincronizza anche nascosto; sul telefono no (batteria). */
setTimeout(function(){ mnSync().catch(function(){ }); }, NS_SOLA ? 2500 : 9000);
setInterval(function(){
  if (document.hidden && !mnSyncNascosto()) return;
  const passo = mnNoteAperte() ? 12000 : 90000;
  if (Date.now() - NS.ultimoGiro >= passo) mnSync().catch(function(){ });
}, 4000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) mnSyncPresto(1500); });
/* nella Mappa: dopo ogni scrittura della Mappa e appena chiudi le note */
(function(){
  if (NS_SOLA) return;
  if (typeof mnSalva === 'function'){ const salva = mnSalva; window.mnSalva = mnSalva = function(){ const r = salva.apply(this, arguments); mnSyncPresto(4000); return r; }; }
  if (typeof noChiudi === 'function'){ const chiudi = noChiudi; window.noChiudi = noChiudi = function(){ const r = chiudi.apply(this, arguments); mnSyncPresto(1500); return r; }; }
  const indietro = typeof BACK_TO !== 'undefined' ? BACK_TO['s-note'] : null;
  if (typeof indietro === 'function') BACK_TO['s-note'] = function(){ const r = indietro.apply(this, arguments); mnSyncPresto(1500); return r; };
})();
