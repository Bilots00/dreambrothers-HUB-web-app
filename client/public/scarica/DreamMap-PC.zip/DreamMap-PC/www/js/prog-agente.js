/* ===========================================================================================
   I PROGRAMMI CREATI DAL TUO AGENTE PERSONALE (0.9.395)

   Andrea, 26/11: "il genio nella revisione prima di chiedere di creare un programma o un blocco dovrebbe PRIMA chiedere se
   un'app e' PRODUTTIVA e chiedere all'utente di catalogarla sia su pc che sul telefono, e mostrargli il LINK al programma
   (cosi' che l'utente possa aprirlo e CONTROLLARE LE CONDIZIONI del blocco e del programma creato)". In un Rientra in rotta
   il Genio aveva creato "Protezione tempo libero", che blocca TELEGRAM (per lui un'app per lavorare), senza chiedere niente;
   poi in chat ha detto di averlo tolto, e il programma era ancora li'.

   Qui, in un posto solo, quello che serve al Rientra in rotta (rientro-genio.js) e alla chat (agente.js):
     - il giudizio delle app (insGiudizioApp, insights.js): un'app produttiva o neutra non entra mai in un programma del Genio;
       una non classificata si chiede prima;
     - la scheda del programma con le sue condizioni (app, orari, giorni, limiti), "Mostra il programma", "Va bene così" e
       "Cambialo". Finche' non e' confermato il programma e' "da confermare" (daConfermare): la Modalità severa non lo chiude a
       chiave e si toglie senza punti al vecchio te; confermato, vale la Modalità severa come per tutti;
     - il passaggio, una volta sola, dei programmi creati dal Genio PRIMA della 0.9.395 (come quello di Andrea);
     - quello che il tuo agente deve sapere per rispondere onesto: la Modalità severa, il pass d'emergenza, lo Sblocco di
       emergenza (la frase da scrivere, l'attesa che raddoppia), i programmi con il loro stato, il giudizio delle app.
   =========================================================================================== */
const PGA = { pass: null, passAt: 0 };
const PGA_GIORNI = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'];
const PGA_NOMI_NOTI = { 'com.instagram.android': 'Instagram', 'com.zhiliaoapp.musically': 'TikTok', 'com.ss.android.ugc.trill': 'TikTok', 'com.google.android.youtube': 'YouTube',
  'com.facebook.katana': 'Facebook', 'com.whatsapp': 'WhatsApp', 'org.telegram.messenger': 'Telegram', 'com.snapchat.android': 'Snapchat', 'com.twitter.android': 'X',
  'com.reddit.frontpage': 'Reddit', 'com.netflix.mediaclient': 'Netflix', 'tv.twitch.android.app': 'Twitch', 'com.instagram.barcelona': 'Threads', 'com.pinterest': 'Pinterest',
  'com.linkedin.android': 'LinkedIn', 'com.spotify.music': 'Spotify', 'com.android.chrome': 'Chrome', 'com.discord': 'Discord', 'com.facebook.orca': 'Messenger' };
function pgaEsc(s){ return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function pgaLista(){ return (typeof PROGRAMS !== 'undefined' && Array.isArray(PROGRAMS)) ? PROGRAMS : []; }
function pgaIdx(pid){ return pgaLista().findIndex(function(x){ return x && x.id === pid; }); }
function pgaProg(pid){ const i = pgaIdx(pid); return i >= 0 ? pgaLista()[i] : null; }

/* ---------- il giudizio delle app ---------- */
function pgaNomeApp(pkg, nomi){
  if (nomi && nomi[pkg]) return nomi[pkg];
  try{ const a = (typeof APPS_CACHE !== 'undefined' ? APPS_CACHE : []).filter(function(x){ return x && x.packageName === pkg; })[0]; if (a && a.label) return a.label; }catch(_){ }
  return PGA_NOMI_NOTI[pkg] || pkg;
}
function pgaGiudizio(pkg, nome){ try{ return (typeof insGiudizioApp === 'function') ? insGiudizioApp(pkg, nome || pgaNomeApp(pkg)) : ''; }catch(_){ return ''; } }
/**
 * Le app di un programma proposto dal Genio, divise: { tenute, tolte, chiedere }.
 * tolte = produttive o neutre (non si bloccano mai); chiedere = non ancora classificate (si chiede prima).
 */
function pgaFiltraApp(pkgs, nomi){
  const out = { tenute: [], tolte: [], chiedere: [] };
  (pkgs || []).forEach(function(pkg){
    const nome = pgaNomeApp(pkg, nomi), g = pgaGiudizio(pkg, nome);
    const x = { pkg: pkg, nome: nome, giudizio: g };
    if (g === 'prod' || g === 'neutro') out.tolte.push(x);
    else { out.tenute.push(x); if (!g) out.chiedere.push(x); }
  });
  return out;
}

/* ---------- le condizioni, dette per intero ---------- */
function pgaGiorniTxt(g){
  if (!Array.isArray(g) || g.length !== 7 || g.every(Boolean)) return 'tutti i giorni';
  if (g.slice(0, 5).every(Boolean) && !g[5] && !g[6]) return 'dal lunedì al venerdì';
  if (!g.slice(0, 5).some(Boolean) && g[5] && g[6]) return 'il sabato e la domenica';
  return g.map(function(x, i){ return x ? PGA_GIORNI[i] : ''; }).filter(Boolean).join(', ');
}
/** Le righe delle condizioni: [{ k: 'Blocca', v: 'Instagram, instagram.com' }, ...] */
function pgaCondizioni(p, nomi){
  if (!p) return [];
  const r = [];
  const cosa = (p.apps || []).map(function(x){ return pgaNomeApp(x, nomi); })
    .concat(p.sites || []).concat((p.keywords || []).map(function(k){ return '"' + ((k && k.t) ? k.t : k) + '"'; }));
  r.push({ k: 'Blocca', v: cosa.length ? cosa.join(', ') : 'niente. Aggiungi un’app' });
  if (p.qh || p.qd){
    const l = [];
    if (p.qh) l.push(p.qh + ' minuti all’ora');
    if (p.qd) l.push(p.qd + ' minuti al giorno');
    r.push({ k: 'Limite', v: 'puoi usarle ' + l.join(' e al massimo ') + ', poi si bloccano' });
  } else {
    r.push({ k: 'Quando', v: p.allDay ? 'tutto il giorno' : 'dalle ' + (p.from || '00:00') + ' alle ' + (p.to || '00:00') });
  }
  r.push({ k: 'Giorni', v: pgaGiorniTxt(p.days) });
  return r;
}
function pgaCondizioniHtml(p, nomi){
  return '<div class="pga-cond">' + pgaCondizioni(p, nomi).map(function(x){ return '<div class="pga-r"><small>' + pgaEsc(x.k) + '</small><span>' + pgaEsc(x.v) + '</span></div>'; }).join('') + '</div>';
}

/* ---------- le azioni sulla scheda ---------- */
function pgaMostra(pid){
  goId('s-home'); try{ switchTab('blocco'); }catch(_){ }
  if (pid && typeof blkEvidenzia === 'function') blkEvidenzia(pid);
}
function pgaCambia(pid){
  const i = pgaIdx(pid); if (i < 0){ pgaMostra(pid); return; }
  goId('s-home'); try{ switchTab('blocco'); }catch(_){ }
  setTimeout(function(){ const j = pgaIdx(pid); if (j >= 0 && typeof editProgram === 'function') editProgram(j); }, 300);
}
async function pgaConferma(pid){
  const i = pgaIdx(pid); if (i < 0) return false;
  if (typeof blkConferma === 'function') await blkConferma(i);
  else { pgaLista()[i].daConfermare = false; try{ saveProgramsLocal(); pushRules(); }catch(_){ } }
  return true;
}
/** Si puo' togliere adesso? Con la Modalità severa accesa solo se aspetta ancora la conferma (o e' nei due minuti di tolleranza). */
function pgaSiTogli(p){ if (!p) return false; try{ return !(typeof blkBloccato === 'function' && blkBloccato(p)); }catch(_){ return true; } }
/**
 * Toglie il programma del Genio: senza punti al vecchio te (non passa da itBump: l'errore e' dell'agente).
 * Con la Modalità severa accesa e il programma gia' confermato non lo toglie, e dice il motivo vero. Restituisce 'tolto' | 'severa' | 'no' | 'manca'.
 */
async function pgaTogli(pid, chiedi){
  const p = pgaProg(pid); if (!p) return 'manca';
  if (!pgaSiTogli(p)){ try{ toast('La Modalità severa è accesa e il programma è già confermato:\nnon si può togliere'); }catch(_){ } return 'severa'; }
  if (chiedi !== false && typeof blkEliminaChiedi === 'function'){
    const ok = await blkEliminaChiedi({ titolo: 'Togli il programma', testo: blkDaConfermare(p) ? 'L’ha creato il tuo agente personale e non l’hai ancora confermato. Lo togli senza penalità.' : 'Vuoi davvero togliere il programma?', si: 'TOGLI' });
    if (!ok) return 'no';
  }
  const i = pgaIdx(pid); if (i < 0) return 'manca';
  pgaLista().splice(i, 1);
  try{ saveProgramsLocal(); }catch(_){ }
  try{ if (typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  try{ if (typeof pushRules === 'function') await pushRules(); }catch(_){ }
  try{ if (typeof syncNative === 'function') syncNative(); }catch(_){ }
  /* il motore puo' aver rifiutato: si dice la verita', non "tolto" */
  if (pgaIdx(pid) >= 0){ try{ toast('Il programma non si è tolto:\nriprova dalla pagina dei programmi'); }catch(_){ } return 'severa'; }
  try{ toast('Programma tolto'); }catch(_){ }
  return 'tolto';
}
/** Toglie un'app dal programma ancora da confermare (l'utente ha detto che per lui e' produttiva o neutra). Senza app, il programma sparisce. */
async function pgaTogliApp(pid, pkg){
  const p = pgaProg(pid); if (!p || !pgaSiTogli(p)) return false;
  p.apps = (p.apps || []).filter(function(x){ return x !== pkg; });
  if (!p.apps.length && !(p.sites || []).length && !(p.keywords || []).length){ await pgaTogli(pid, false); return true; }
  try{ saveProgramsLocal(); if (typeof renderPrograms === 'function') renderPrograms(); if (typeof pushRules === 'function') await pushRules(); }catch(_){ }
  return true;
}

/* ---------- la scheda: condizioni, Mostra il programma, Va bene così, Cambialo ----------
   dove = 'chat' (la chat del tuo agente) o 'genio' (la scena scura del Rientra in rotta). */
function pgaSchedaHtml(pid, dove, nomi){
  const p = pgaProg(pid);
  if (!p) return '';
  const conf = blkDaConfermare(p);
  const q = "'" + String(pid).replace(/[^a-z0-9_-]/gi, '') + "'";
  const fermo = 'event.stopPropagation();';
  /* le app ancora da classificare: la domanda sta qui, e la risposta va nella classificazione del Report */
  const chiedere = conf ? (p.apps || []).filter(function(x){ return !pgaGiudizio(x, pgaNomeApp(x, nomi)); }) : [];
  const domande = chiedere.map(function(pkg){
    const n = pgaEsc(pgaNomeApp(pkg, nomi)), k = "'" + String(pkg).replace(/[^a-z0-9._-]/gi, '') + "'";
    return '<div class="pga-chiedi"><p>Per te <b>' + n + '</b> è un’app che ti distrae o che usi per lavorare?</p><div class="pga-chiedi-az">'
      + '<button type="button" onclick="' + fermo + 'pgaClassifica(' + q + ',' + k + ',\'distr\',\'' + dove + '\')">Mi distrae</button>'
      + '<button type="button" onclick="' + fermo + 'pgaClassifica(' + q + ',' + k + ',\'prod\',\'' + dove + '\')">La uso per lavorare</button>'
      + '<button type="button" onclick="' + fermo + 'pgaClassifica(' + q + ',' + k + ',\'neutro\',\'' + dove + '\')">Né l’una né l’altra</button></div></div>';
  }).join('');
  const stato = conf ? 'Da confermare' : 'Confermato';
  const titolo = '<small class="pga-stato' + (conf ? ' conf' : '') + '">' + stato + '</small><b class="pga-nome">' + pgaEsc(p.name || 'Programma') + '</b>';
  const nota = conf ? '<p class="pga-nota">Controlla le condizioni. Finché non lo confermi puoi cambiarlo o toglierlo senza penalità, anche con la Modalità severa accesa.</p>' : '';
  if (dove === 'genio'){
    return '<div class="rng-patto rng-prog pga-scheda" data-pga="' + pgaEsc(pid) + '">' + titolo + pgaCondizioniHtml(p, nomi) + nota + domande
      + '<button type="button" class="gn-link pga-mostra" onclick="' + fermo + 'rngChiudiSoft();pgaMostra(' + q + ')">Mostra il programma</button></div>'
      + (conf ? '<div class="or-grid one"><button type="button" class="or-a main" onclick="' + fermo + 'rngProgOk(' + q + ')">Va bene così</button></div>'
        + '<button type="button" class="gn-link" onclick="' + fermo + 'rngChiudiSoft();pgaCambia(' + q + ')">Cambialo</button>'
        : '<div class="or-grid one"><button type="button" class="or-a main" onclick="' + fermo + 'rnScelto();rngChiudi()">Torno al sogno</button></div>');
  }
  return '<div class="pga-scheda-in" data-pga="' + pgaEsc(pid) + '">' + titolo + pgaCondizioniHtml(p, nomi) + nota + domande
    + '<div class="ag-prog-az"><button type="button" class="jd-applica ag-applica" onclick="pgaMostra(' + q + ')"><span>Mostra il programma</span></button>'
    + (conf ? '<button type="button" class="jd-applica ag-applica pga-ok" onclick="pgaConfermaChat(' + q + ')"><span>Va bene così</span></button>'
      + '<button type="button" class="ag-prog-no" onclick="pgaCambia(' + q + ')">Cambialo</button>' : '') + '</div></div>';
}
/** La risposta alla domanda sull'app: si salva nella classificazione del Report; se e' produttiva o neutra l'app esce dal programma. */
async function pgaClassifica(pid, pkg, cat, dove){
  try{ if (typeof insGiudizioSalva === 'function') insGiudizioSalva(pkg, cat); }catch(_){ }
  try{ flVibra(12); }catch(_){ }
  if (cat !== 'distr'){
    await pgaTogliApp(pid, pkg);
    try{ toast(pgaNomeApp(pkg) + ' non è più nel programma:\nper te non è una distrazione'); }catch(_){ }
  }
  pgaRidisegna(pid, dove);
}
async function pgaConfermaChat(pid){ await pgaConferma(pid); pgaRidisegna(pid, 'chat'); }
function pgaRidisegna(pid, dove){
  /* nella chat si ridisegna il messaggio intero (con il suo "Toglilo"), nella scena del Genio solo la scheda */
  if (dove === 'chat' && typeof agRidisegna === 'function'){ try{ agRidisegna(); return; }catch(_){ } }
  try{
    document.querySelectorAll('[data-pga="' + String(pid).replace(/"/g, '') + '"]').forEach(function(el){
      const h = pgaSchedaHtml(pid, dove);
      if (dove === 'genio'){
        /* solo la scheda: i pulsanti sotto (Va bene così, Cambialo, Non lo voglio) restano */
        const tmp = document.createElement('div'); tmp.innerHTML = h || '';
        const nuova = tmp.querySelector('.pga-scheda');
        el.outerHTML = nuova ? nuova.outerHTML : '<p class="pga-nota">Il programma non c’è più:<br>nessuna delle app ti distrae.</p>';
        return;
      }
      el.outerHTML = h || '<p class="pga-nota">Il programma non c’è più.</p>';
    });
  }catch(_){ }
}

/* ---------- i programmi del Genio di prima della 0.9.395 ----------
   Andrea: "Protezione tempo libero" (il nome l'ha scelto il modello del Rientra in rotta) blocca Telegram, la Modalità severa e'
   accesa per 21 giorni: deve poterlo togliere senza punti. Prima della 0.9.395 il segno `agente: true` si perdeva rileggendo i
   programmi dal motore (scheduleToProgram teneva solo l'icona): per riconoscerli si usano tutte le tracce che restano. */
const PGA_MIGRA_KEY = 'fl_pga_migra_395';
function pgaIdTempo(id){ const m = /^p([0-9a-z]{7,9})[0-9a-z]{5}$/.exec(String(id || '')); if (!m) return 0; const t = parseInt(m[1], 36); return t > 1.6e12 && t < 4e12 ? t : 0; }
/** Il segno che lo riconosce come programma del Genio, o '' se non e' suo. */
function pgaTracciaGenio(p){
  if (!p) return '';
  if (p.daAgente || p.agente) return 'segno agente';
  /* 1. la chat: fl_ag_prog ricorda l'id di ogni programma creato da un messaggio */
  try{ const f = JSON.parse(localStorage.getItem('fl_ag_prog') || '{}') || {}; if (Object.keys(f).some(function(k){ return f[k] === p.id; })) return 'chat (fl_ag_prog)'; }catch(_){ }
  /* 2. il registro del Rientra in rotta: rngAiSalva scrive 'Programma "Nome" dalle ... alle ...', subito dopo averlo creato */
  let reg = [];
  try{ reg = JSON.parse(localStorage.getItem('fl_rientri') || '[]') || []; }catch(_){ reg = []; }
  const nome = String(p.name || '').trim();
  if (nome && reg.some(function(x){ return x && String(x.contromisura || '').indexOf('Programma "' + nome + '"') === 0; })) return 'registro del rientro (nome)';
  const t = pgaIdTempo(p.id);
  if (t && reg.some(function(x){ return x && x.at && x.rimedio === 'programma' && Math.abs(x.at - t) < 3 * 60000; })) return 'registro del rientro (ora di creazione)';
  /* 3. l'icona del Genio: frProgrammaDaAgente da' 🔮 ai programmi a orario, e l'icona e' l'unica cosa che sopravviveva */
  if (p.icon === '🔮') return 'icona del Genio';
  /* 4. i nomi scritti dall'app */
  if (/^(Il mio patto:|Rientro in rotta:)/.test(nome) || ['Il mio rientro', 'Dal tuo agente personale', 'Blocco rapido del tuo agente personale'].indexOf(nome) >= 0) return 'nome scritto dal Genio';
  /* 5. l'ultima risorsa: un programma a orario di sole app, tutti i giorni, nato entro mezz'ora da un Rientra in rotta */
  const soloApp = (p.apps || []).length && !(p.sites || []).length && !(p.keywords || []).length && p.type === 'ora' && !p.allDay && !p.qh && !p.qd;
  if (soloApp && t && reg.some(function(x){ return x && x.at && t >= x.at - 60000 && t - x.at < 30 * 60000; })) return 'nato durante un rientro';
  return '';
}
/** Una volta sola: i programmi del Genio di prima diventano "da confermare". Restituisce [{ id, nome, traccia }]. */
async function pgaMigra395(){
  let fatti = {};
  try{ fatti = JSON.parse(localStorage.getItem(PGA_MIGRA_KEY) || '{}') || {}; }catch(_){ fatti = {}; }
  if (fatti.finito) return [];
  const segnati = [];
  pgaLista().forEach(function(p){
    if (!p || !p.id || fatti[p.id] || p.daAgente) return;
    const tr = pgaTracciaGenio(p);
    if (!tr) return;
    p.daAgente = true; p.daConfermare = true;
    segnati.push({ id: p.id, nome: p.name || '', traccia: tr });
  });
  if (segnati.length){
    try{ saveProgramsLocal(); }catch(_){ }
    try{ if (typeof pushRules === 'function') await pushRules(); }catch(_){ }
    try{ if (typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  }
  /* si segna fatto solo quello che il motore ha davvero accettato (dopo pushRules la lista e' riletta dal motore) */
  let tutti = true;
  segnati.forEach(function(x){ const q = pgaProg(x.id); if (q && q.daConfermare) fatti[x.id] = x.traccia; else if (q) tutti = false; });
  if (tutti) fatti.finito = Date.now();
  try{ localStorage.setItem(PGA_MIGRA_KEY, JSON.stringify(fatti)); }catch(_){ }
  return segnati;
}
/* dopo l'avvio, quando i programmi sono gia' stati riletti dal motore (blkHydrateBoot) */
setTimeout(function(){ pgaMigra395().then(function(l){ if (l && l.length) try{ toast(l.length === 1 ? '“' + l[0].nome + '” aspetta la tua conferma:\npuoi toglierlo senza penalità' : l.length + ' programmi del tuo agente aspettano la tua conferma'); }catch(_){ } }).catch(function(){ }); }, 6000);

/* ---------- quello che il tuo agente deve sapere per rispondere onesto ---------- */
async function pgaAggiorna(){
  if (Date.now() - PGA.passAt < 30000) return;
  try{ if (typeof sevLoadState === 'function') await sevLoadState(); }catch(_){ }
  try{ if (typeof efPassDisponibile === 'function'){ PGA.pass = await efPassDisponibile(); PGA.passAt = Date.now(); } }catch(_){ }
}
/** La Modalità severa e lo Sblocco di emergenza, con i numeri veri di adesso. */
function pgaSevera(){
  let accesa = false; try{ accesa = (typeof efSeveraAccesa === 'function') ? efSeveraAccesa() : !!(typeof blkEditLocked === 'function' && blkEditLocked()); }catch(_){ }
  let c = { n: 0, p: 0 }; try{ if (typeof efConto === 'function') c = efConto(); }catch(_){ }
  const attesa = Math.min(256, Math.pow(2, c.n));
  return { accesa: accesa, pass: PGA.pass, volteMese: c.n + c.p, attesaMin: attesa, prossimaMin: Math.min(256, attesa * 2),
           frase: c.n >= 1, testo: (typeof EF_TESTO !== 'undefined') ? EF_TESTO : '' };
}
function pgaMinTxt(m){ return m === 1 ? '1 minuto' : m + ' minuti'; }
function pgaBrief(){
  const r = [];
  const s = pgaSevera();
  const lista = pgaLista().filter(function(p){ return p && !p.grey && !p.sound; });
  r.push('I PROGRAMMI DI BLOCCO E LA MODALITÀ SEVERA (dati veri dell’app, adesso):');
  if (!s.accesa) r.push('- La Modalità severa è spenta: ogni programma si cambia, si mette in pausa o si toglie dalla sua pagina (pulsante con {"apri": "programma", "nome": "..."}).');
  else {
    r.push('- La Modalità severa è ACCESA: nessun programma confermato si può togliere, mettere in pausa o allentare, né da lui né da te. Tu non puoi cambiarla.');
    if (s.pass === true) r.push('- Ha ancora il pass d’emergenza (uno solo): nello Sblocco di emergenza lo tiene premuto e la Modalità severa si spegne subito, senza domande.');
    else r.push('- Il pass d’emergenza ' + (s.pass === false ? 'è già stato usato' : 'non risulta disponibile') + '. Lo Sblocco di emergenza (Profilo, Aiuto e altro): sei domande, '
      + (s.frase ? 'poi deve scrivere esattamente questa frase (senza incollarla): "' + s.testo + '", ' : '')
      + 'poi un’attesa di ' + pgaMinTxt(s.attesaMin) + ' restando sulla schermata. L’attesa raddoppia ogni volta nel mese: la prossima sarà di ' + pgaMinTxt(s.prossimaMin) + '. Questo mese l’ha già usato ' + s.volteMese + (s.volteMese === 1 ? ' volta' : ' volte') + '.');
    r.push('- Spegnere la Modalità severa con lo Sblocco di emergenza costa sempre un punto al vecchio te. Il pulsante che apre lo Sblocco di emergenza: {"apri": "emergenza"}.');
  }
  if (!lista.length) r.push('- Programmi: nessuno.');
  lista.slice(0, 12).forEach(function(p){
    const st = p.daConfermare ? 'DA CONFERMARE (l’hai creato tu, agente: si cambia o si toglie senza penalità anche con la Modalità severa accesa)'
      : (p.on === false ? 'in pausa' : (s.accesa ? 'confermato, chiuso dalla Modalità severa' : 'attivo'));
    r.push('- Programma "' + (p.name || 'Programma') + '": ' + pgaCondizioni(p).map(function(x){ return x.k.toLowerCase() + ' ' + x.v; }).join('; ') + '. Stato: ' + st + '.');
  });
  /* il giudizio delle app: quello del Report, sul telefono e sul computer */
  const visti = {}, giud = [];
  let cats = {}; try{ cats = (typeof insCatsBase === 'function') ? insCatsBase() : {}; }catch(_){ }
  lista.forEach(function(p){ (p.apps || []).forEach(function(x){ visti[x] = 1; }); });
  Object.keys(cats).forEach(function(x){ visti[x] = 1; });
  Object.keys(visti).slice(0, 40).forEach(function(pkg){ const n = pgaNomeApp(pkg); giud.push(n + ' = ' + ((typeof INS_GIUDIZIO_TXT !== 'undefined' ? INS_GIUDIZIO_TXT : {})[pgaGiudizio(pkg, n)] || 'non classificata')); });
  /* e quelle classificate sul computer (i totali di ogni giorno che il computer pubblica, top[].c) */
  try{
    const pc = {}, g = (typeof PC !== 'undefined' && PC && PC.doc && PC.doc.giorni) || {};
    Object.keys(g).sort().forEach(function(k){ ((g[k] && g[k].top) || []).forEach(function(t){ const c = /^prod/i.test(t && t.c) ? 'produttiva' : /^distr/i.test(t && t.c) ? 'distraente' : /^neut/i.test(t && t.c) ? 'neutra' : ''; if (c && t.k) pc[String(t.k).replace(/\.exe$/i, '')] = c; }); });
    Object.keys(pc).slice(0, 20).forEach(function(n){ giud.push(n + ' = ' + pc[n] + ' (sul computer)'); });
  }catch(_){ }
  r.push('- Come ha classificato le sue app (Report, telefono e computer): ' + (giud.length ? giud.join(', ') : 'nessuna ancora') + '. Ogni app che non è in questo elenco è non classificata.');
  return r.join('\n');
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.pga-cond{display:flex;flex-direction:column;gap:8px;margin:12px 0 4px;text-align:left}',
    '.pga-r{display:flex;flex-direction:column;gap:2px}.pga-r small{font:800 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;opacity:.7}.pga-r span{font:700 14.5px/1.4 var(--font-body)}',
    '.pga-stato{display:inline-block;padding:4px 10px;border-radius:99px;background:#DFF3E6;color:#137A50;font:800 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase}.pga-stato.conf{background:#FFEBD1;color:#9A5B00}',
    '.pga-nome{display:block;margin-top:8px;font:800 16.5px/1.35 var(--font-body)}',
    '.pga-nota{margin:10px 0 0;font:600 13px/1.5 var(--font-body);opacity:.85}',
    '.pga-chiedi{margin:14px 0 0;padding:12px;border-radius:14px;background:rgba(0,117,227,.09);text-align:left}.pga-chiedi p{margin:0;font:600 14px/1.45 var(--font-body)}',
    '.pga-chiedi-az{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.pga-chiedi-az button{border:0;border-radius:99px;padding:9px 13px;background:#0075E3;color:#fff;font:700 13px var(--font-body);cursor:pointer}',
    '.pga-mostra{display:block;margin:12px auto 0}',
    '.pga-scheda-in{margin-top:4px}'
  ].join('');
  document.head.appendChild(st);
})();
