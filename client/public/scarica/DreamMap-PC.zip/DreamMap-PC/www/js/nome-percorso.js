/* ===========================================================================================
   ROADMAP O PERCORSO, SECONDO CHI LEGGE (0.9.364)

   Andrea: "per gli utenti giovani voglio che si chiami sempre roadmap: si capisce, come Black
   Friday. Per gli utenti piu' adulti, i boomer, va bene percorso. In base all'eta', che si deduce
   dalla data di nascita". Nel codice il nome e' uno solo ("il percorso", 0.9.361): qui, per chi ha
   meno di 55 anni (o non ha detto l'eta'), le scritte a schermo diventano "la roadmap", con articoli
   e accordi giusti. Le frasi lunghe vengono prima delle corte, cosi' "il tuo percorso e' pronto"
   diventa "la tua roadmap e' pronta" e non "la tua roadmap e' pronto".
   =========================================================================================== */
/* 0.9.402 BUG-225, Andrea: "Del mio roadmap ricordo piu' le cadute che i passi fatti. Percorso e roadmap non sono sinonimi: la roadmap
   e' quella della scheda Mappa, il mio percorso (di vita) resta percorso". Prima quello che non era nell'elenco cadeva sull'ultima riga
   (percorso -> roadmap) e restavano gli articoli al maschile: "del mio roadmap". Adesso:
   1. le frasi dove percorso vuol dire un'altra cosa (la vita, i ricordi, la strada verso il sogno, un percorso di studi) non si toccano;
   2. le frasi fatte, che hanno l'aggettivo lontano dalla parola (Il tuo percorso e' pronto), si cambiano intere;
   3. in tutte le altre si cambia la parola con quello che le sta intorno: articolo, possessivo e aggettivo (il mio percorso nuovo ->
      la mia roadmap nuova). Se davanti c'e' un articolo che non si sa accordare, la frase resta com'e': meglio percorso che un errore.
   La prova: node tools/test-nome-percorso-402.js (passa tutte le frasi di www e fallisce su "del mio roadmap"). */
const NP_TIENI = [
  /percors[oi] (di|della|dello|nella) (vita|crescita|studi|studio|cura|guarigione|fede|formazione|carriera|scuola|terapia|coppia)/i,
  /ricord[oaie]\b/i,
  /\bfa(nno)? parte del( mio| tuo| suo| nostro)? percorso/i,
  /percorso (gi[aà]'? )?tracciat/i,
  /percorso verso/i,
  /copiare il percorso/i,
  /percorsi? (della|delle|dei) luc/i,
  /percorso passa da|nelle impostazioni|percorso dell['’]albero/i
];
const NP_FRASI = [
  ['Il tuo percorso è pronto', 'La tua roadmap è pronta'],
  ['Il percorso è aggiornato', 'La roadmap è aggiornata'],
  ['Il percorso è cambiato', 'La roadmap è cambiata'],
  ['Il percorso è questo, eccolo', 'La roadmap è questa, eccola'],
  ['Il percorso non è ancora pronto', 'La roadmap non è ancora pronta'],
  ['Il percorso, aggiornato dalla tua AI', 'La roadmap, aggiornata dalla tua AI'],
  ['Aggiorna il percorso da solo', 'Aggiorna la roadmap da sola'],
  ['il percorso compare qui da solo', 'la roadmap compare qui da sola'],
  ['lo costruisce dal tuo sogno', 'la costruisce dal tuo sogno'],
  ['Un percorso solo tuo', 'Una roadmap solo tua'],
  ['VAI AL PERCORSO', 'VAI ALLA ROADMAP']
];
/* le parole davanti: l'articolo (anche con la preposizione), il possessivo, l'aggettivo che sta prima del nome */
const NP_DET = { il: 'la', un: 'una', del: 'della', dal: 'dalla', al: 'alla', nel: 'nella', sul: 'sulla', col: 'con la', questo: 'questa',
  quel: 'quella', quello: 'quella', nessun: 'nessuna', nessuno: 'nessuna', ogni: 'ogni' };
const NP_POSS = { mio: 'mia', tuo: 'tua', suo: 'sua', nostro: 'nostra', vostro: 'vostra', loro: 'loro' };
const NP_AGG_PRIMA = { nuovo: 'nuova', vero: 'vera', primo: 'prima', vecchio: 'vecchia', intero: 'intera', stesso: 'stessa', solito: 'solita', prossimo: 'prossima' };
/* le parole dopo: i verbi che tengono l'accordo (e' pronto, non e' ancora pronto, e' stato fatto) e l'aggettivo */
const NP_PONTE = { 'è': 1, "e'": 1, 'era': 1, 'sarà': 1, 'resta': 1, 'rimane': 1, 'sembra': 1, non: 1, ancora: 1, 'già': 1, "gia'": 1, adesso: 1, ora: 1, 'più': 1, molto: 1, troppo: 1 };
const NP_AGG_DOPO = /^(nuov|inter|pront|complet|ver|lung|cort|giust|scritt|fatt|propost|stess|tu|mi|su|nostr|[a-zàèéìòù]+(?:at|it|ut))o$/i;
/* le parole in -ato, -ito, -uto che sono nomi o avverbi, non aggettivi: restano come sono */
const NP_NOMI = /^(subito|dito|minuto|aiuto|tributo|contributo|istituto|merito|invito|sito|partito|risultato|mercato|lato|dato|fiato|piatto|tratto|attimo|spirito)$/i;
const NP_HAS = function(o, k){ return Object.prototype.hasOwnProperty.call(o, k); };
function npMaiusc(orig, nuovo){
  if (orig === orig.toUpperCase() && orig !== orig.toLowerCase()) return nuovo.toUpperCase();
  if (orig.charAt(0) !== orig.charAt(0).toLowerCase()) return nuovo.charAt(0).toUpperCase() + nuovo.slice(1);
  return nuovo;
}
/** La parola accordata, o null. Quello che le sta attaccato davanti (un tag, una virgoletta, una parentesi) resta com'e'. */
function npFemm(w, mappa){
  const m = /^(.*[^A-Za-zÀ-ÿ'’]|)([A-Za-zÀ-ÿ'’]+)$/.exec(String(w || '')); if (!m) return null;
  const k = m[2].toLowerCase();
  return NP_HAS(mappa, k) ? m[1] + npMaiusc(m[2], mappa[k]) : null;
}
/* "del percorso spuntato": dopo una preposizione l'aggettivo di solito e' della parola prima (il passo spuntato), non del percorso. Li' si
   accordano solo gli aggettivi che dicono com'e' il percorso */
const NP_PREP = /^(del|dal|al|nel|sul|col)$/i;
const NP_AGG_SUO = /^(nuov|inter|complet|ver|stess|lung|cort|giust)o$/i;
/** Una occorrenza di "percorso" con le parole intorno: prima = le parole davanti (con gli spazi), dopo = quelle dietro. null = non si tocca. */
function npAccorda(prima, parola, dopo, ap, ch){
  const pz = prima.split(/(\s+)/);
  let i = pz.length - 1; while (i >= 0 && !/\S/.test(pz[i])) i--;
  /* l'aggettivo davanti al nome ("il nuovo percorso"), poi il possessivo, poi l'articolo */
  let w = i >= 0 ? npFemm(pz[i], NP_AGG_PRIMA) : null; if (w){ pz[i] = w; i -= 2; }
  w = i >= 0 ? npFemm(pz[i], NP_POSS) : null; if (w){ pz[i] = w; i -= 2; }
  const det = i >= 0 ? String(pz[i]).replace(/^.*[^A-Za-zÀ-ÿ'’]/, '') : '';
  w = i >= 0 ? npFemm(pz[i], NP_DET) : null;
  if (w){ pz[i] = w; if (i >= 2 && /^tutto$/i.test(pz[i - 2])) pz[i - 2] = npMaiusc(pz[i - 2], 'tutta'); }
  else if (/^(lo|gli|i|dei|degli|ai|agli|nei|sui|dai|questi|quei|dello|allo|nello|sullo|dallo)$/i.test(det)) return null;
  const prep = NP_PREP.test(det);
  const R = parola === 'PERCORSO' ? 'ROADMAP' : (parola.charAt(0) === 'P' ? 'Roadmap' : 'roadmap');
  const dz = dopo.split(/(\s+)/);
  for (let j = 1; j < dz.length; j += 2){
    const x = dz[j + 1] || '', nudo = x.replace(/[.,;:!?)»”"’']+$/, ''), coda = x.slice(nudo.length);
    if (!nudo) break;
    if (NP_HAS(NP_PONTE, nudo.toLowerCase())){ if (coda) break; continue; }
    if (/^stato$/i.test(nudo)){ dz[j + 1] = npMaiusc(nudo, 'stata') + coda; if (coda) break; continue; }
    if (NP_AGG_DOPO.test(nudo) && !NP_NOMI.test(nudo) && (!prep || NP_AGG_SUO.test(nudo))) dz[j + 1] = nudo.slice(0, -1) + (nudo.slice(-1) === 'O' ? 'A' : 'a') + coda;
    break;
  }
  return pz.join('') + (ap || '') + R + (ch || '') + dz.join('');
}
function npEta(){
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null') || {};
    let b = u.birth || ''; if (!b && typeof scFuture === 'function') b = (scFuture() || {}).birth || '';
    const t = Date.parse(b); if (!t) return null;
    return Math.floor((Date.now() - t) / (365.25 * 86400000));
  }catch(_){ return null; }
}
/* "roadmap" per chi ha meno di 55 anni o non l'ha detto; "percorso" da 55 in su */
function npRoadmap(){ const e = npEta(); return !(e !== null && e >= 55); }
function npTesto(t){
  if (!t || t.indexOf('ercors') < 0 && t.indexOf('ERCORSO') < 0) return t;
  for (let i = 0; i < NP_TIENI.length; i++) if (NP_TIENI[i].test(t)) return t;
  for (let i = 0; i < NP_FRASI.length; i++) if (t.indexOf(NP_FRASI[i][0]) >= 0) t = t.split(NP_FRASI[i][0]).join(NP_FRASI[i][1]);
  return t.replace(/((?:(?!percorso\b|Percorso\b|PERCORSO\b)\S+\s+){0,3})([*«“"(]?)\b(percorso|Percorso|PERCORSO)\b([*»”")]?)((?:\s+(?!percorso\b|Percorso\b|PERCORSO\b)\S+){0,4})/g, function(tutto, prima, ap, parola, ch, dopo){
    /* l'asterisco o la virgoletta attaccati alla parola ("ricalcoli il *percorso*") non cambiano l'accordo */
    const r = npAccorda(prima, parola, dopo, ap, ch);
    return r == null ? tutto : r;
  });
}
/* 0.9.372, Andrea: "la roadmap e' quella con le tappe, nella scheda Mappa; il percorso e' la strada verso il sogno. Nessuno dice sono al 3%
   della roadmap: nel pannello dell'arrivo previsto e' il percorso". Quello che sta dentro a [data-percorso] non si traduce */
function npTieni(n){ const e = n && (n.nodeType === 1 ? n : n.parentElement); return !!(e && e.closest && e.closest('[data-percorso]')); }
function npNodo(n){
  if (npTieni(n)) return;
  if (n.nodeType === 3){ const v = n.nodeValue; if (v && v.indexOf('ercors') >= 0 || v && v.indexOf('ERCORSO') >= 0){ const w = npTesto(v); if (w !== v) n.nodeValue = w; } return; }
  if (n.nodeType !== 1) return;
  const tag = n.tagName; if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA') return;
  ['placeholder', 'aria-label', 'title'].forEach(function(a){ const v = n.getAttribute && n.getAttribute(a); if (v && v.indexOf('ercors') >= 0){ const w = npTesto(v); if (w !== v) n.setAttribute(a, w); } });
  const it = document.createTreeWalker(n, NodeFilter.SHOW_TEXT, null); let x;
  while ((x = it.nextNode())){ const v = x.nodeValue; if (v && (v.indexOf('ercors') >= 0 || v.indexOf('ERCORSO') >= 0) && !npTieni(x)){ const w = npTesto(v); if (w !== v) x.nodeValue = w; } }
}
(function(){
  if (typeof document === 'undefined') return;
  let coda = [], attesa = 0;
  const lavora = function(){ attesa = 0; if (!npRoadmap()){ coda = []; return; } const l = coda; coda = []; l.forEach(function(n){ try{ if (n.isConnected) npNodo(n); }catch(_){ } }); };
  const metti = function(n){ coda.push(n); if (!attesa) attesa = requestAnimationFrame(lavora); };
  const parti = function(){
    try{ metti(document.body); }catch(_){ }
    try{ new MutationObserver(function(ms){ ms.forEach(function(m){ if (m.type === 'characterData') metti(m.target); else m.addedNodes.forEach(metti); }); }).observe(document.body, { childList: true, subtree: true, characterData: true }); }catch(_){ }
  };
  if (document.body) parti(); else document.addEventListener('DOMContentLoaded', parti);
})();
if (typeof module !== 'undefined' && module.exports) module.exports = { npTesto, npAccorda, NP_TIENI, NP_FRASI };
