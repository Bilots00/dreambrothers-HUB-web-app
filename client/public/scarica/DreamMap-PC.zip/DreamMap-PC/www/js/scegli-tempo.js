/* ===========================================================================================
   SCEGLI IL TEMPO (0.9.393): UN componente solo, "−  tempo  +", per il timer del Full Focus e per le card delle sessioni.
   0.9.393, Andrea: "voglio che il meno e il piu' siano gia' visibili e che solo cliccando sul tempo al centro tra il meno e il piu'
   compaiano i preset del tempo e che il testo diventi modificabile dalla tastiera, per scegliere un altro tempo. Deve essere uguale
   anche nelle card delle sessioni". E sulle card: "non voglio l'icona della matita (che non fa stare il tempo centrato); i pulsanti
   meno e piu' sono troppo distanziati tra loro, non hanno abbastanza ombra, non sono ben visibili".
   Quindi: − e + SEMPRE visibili, tondi, vicini al tempo e con l'ombra, icone SVG; il tempo in mezzo, centrato; un tocco sul tempo
   fa comparire i preset e lo rende un campo da tastiera numerica.

   Uso:
     sctHtml('chi', { val: 30, min: 5, max: 180, passo: 5, minScritto: 1, preset: [[15,'15m'],[30,'30m'],[60,'1h']],
                      testo: function(v){ return v + ' min'; }, unita: 'min', grande: false,
                      cambia: function(v, come){ }, oltre: function(max){ return 'Al tuo livello arrivi a ' + max + ' minuti'; } })
     sctAggiorna('chi', v)   il valore e' cambiato da fuori (il righello del Full Focus): si aggiornano il numero e i preset.
   come: 'passo' (− o +), 'preset', 'mio' (scritto da tastiera). Prefisso sct-.
   =========================================================================================== */
/* 0.9.400 BUG-182, Andrea: "piu' e meno compaiono SOLO toccando il tempo, grande e sottolineato a puntini: non tutti i controlli
   insieme" (lezione 273). E: "le stime partono strette (legge di Parkinson; chi ha l'ADHD senza tempi stretti non sente la
   scadenza): preset di base 15, 25, 60, mai 90; prima i 2-3 tempi che l'utente sceglie piu' spesso per quel tipo di task, poi
   quelli di base; al massimo 5, scorrevoli con la sfumatura ai lati se sono piu' di 3" (lezione 272).
   Quindi, da qui:
     - chiuso: solo il tempo, grande, sottolineato a puntini (e i preset se presetSempre);
     - primo tocco sul tempo: compaiono − e + e i preset; secondo tocco: il numero si scrive da tastiera;
     - un tocco fuori, o un preset, lo richiude.
   Opzioni nuove: cat (la categoria della task: i preset imparano dalle scelte, sctRicorda), presetSempre, scuro (testo bianco su
   un pannello scuro, la classe condivisa .sct-pan). I preset possono essere numeri: l'etichetta la scrive sctEtichetta. */
/* 0.9.402 BUG-232, Andrea: "mai tre controlli insieme: un tempo mostra o i preset, o tastiera e −/+" (lezione 330) e "il pannello scuro
   del tempo sta solo dove e' stato chiesto (tappa della roadmap in Full Focus)" (lezione 331). Quindi, da qui:
     - chiuso: il tempo, grande e sottolineato a puntini, e sotto i preset (se ce ne sono);
     - un tocco sul tempo: compaiono insieme la tastiera e − e +, e i preset spariscono;
     - un tocco sull'unita' ("minuti"), Invio, o un tocco fuori: la tastiera si chiude, − e + spariscono, tornano i preset.
   Quali preset (opzione pres):
     'mai'    nessuno (le card delle sessioni di Per te e Dopamine detox, le righe di START);
     'storia' solo i tempi che l'utente ha gia' scelto almeno SCT_SOGLIA volte per quella categoria o quel tag (la tappa della roadmap);
     'base'   sempre: prima i tempi scelti piu' spesso, poi 15, 25, 60 (solo il timer del Full Focus).
   Il pannello scuro (.sct-pan, opzione scuro) lo usa solo la tappa della roadmap (sentiero-mappa.js). */
const SCT = {};
const SCT_BASE = [15, 25, 60];
const SCT_SOGLIA = 3;
const SCT_MEM = 'fl_tempi_cat';
/** L'etichetta corta di un preset: 15m, 1h, 1h 30m; nei digiuni 1 giorno, 3 giorni. */
function sctEtichetta(v, unita){
  v = Math.round(+v || 0);
  if (unita === 'giorni') return v === 1 ? '1 giorno' : v + ' giorni';
  const h = Math.floor(v / 60), m = v % 60;
  return h ? h + 'h' + (m ? ' ' + m + 'm' : '') : v + 'm';
}
/** La categoria di una task: l'emoji che le da' START (stEmojiDi, la stessa del popover della Mappa); senza un'emoji sua, il tag. */
function sctCategoria(testo, tag){
  try{
    if (testo && typeof stEmojiDi === 'function'){ const e = stEmojiDi(testo); if (e && e.ico && e.ico !== '🎯') return e.ico; }
  }catch(_){ }
  return 'tag:' + (tag || 'lavoro');
}
function sctMemoria(){ try{ const m = JSON.parse(localStorage.getItem(SCT_MEM) || '{}'); return (m && typeof m === 'object') ? m : {}; }catch(_){ return {}; } }
/** Una sessione partita con quel tempo: la si ricorda per la sua categoria (le ultime 20). */
function sctRicorda(cat, v){
  v = Math.round(+v || 0); if (!cat || !(v > 0)) return;
  const m = sctMemoria(); const l = Array.isArray(m[cat]) ? m[cat] : [];
  l.push({ v: v, at: Date.now() }); m[cat] = l.slice(-20);
  try{ localStorage.setItem(SCT_MEM, JSON.stringify(m)); }catch(_){ }
}
/** I preset di una categoria: prima i (al massimo 3) tempi scelti piu' spesso, poi quelli di base senza doppioni; al massimo 5. */
function sctPresetPer(cat, base, max){
  base = (base && base.length ? base : SCT_BASE).map(function(x){ return Array.isArray(x) ? +x[0] : +x; });
  const l = cat ? (sctMemoria()[cat] || []) : [];
  const conto = {};
  l.forEach(function(x){ if (!x || !(+x.v > 0)) return; const k = +x.v; conto[k] = conto[k] || { v: k, n: 0, at: 0 }; conto[k].n++; conto[k].at = Math.max(conto[k].at, +x.at || 0); });
  const miei = Object.keys(conto).map(function(k){ return conto[k]; })
    .filter(function(x){ return !max || x.v <= max; })
    .sort(function(a, b){ return (b.n - a.n) || (b.at - a.at); }).slice(0, 3).map(function(x){ return x.v; });
  const out = miei.slice();
  base.forEach(function(v){ if (out.indexOf(v) < 0) out.push(v); });
  return out.slice(0, 5);
}
/** 0.9.402 BUG-232: i preset nati dalla cronologia: solo i tempi scelti almeno SCT_SOGLIA volte per quella categoria, i piu' scelti prima. */
function sctPresetStoria(cat, max){
  const l = cat ? (sctMemoria()[cat] || []) : [];
  const conto = {};
  l.forEach(function(x){ if (!x || !(+x.v > 0)) return; const k = +x.v; conto[k] = conto[k] || { v: k, n: 0, at: 0 }; conto[k].n++; conto[k].at = Math.max(conto[k].at, +x.at || 0); });
  return Object.keys(conto).map(function(k){ return conto[k]; })
    .filter(function(x){ return x.n >= SCT_SOGLIA && (!max || x.v <= max); })
    .sort(function(a, b){ return (b.n - a.n) || (b.at - a.at); }).slice(0, 5).map(function(x){ return x.v; });
}
const SCT_SVG = {
  meno: '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 12h12" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>',
  piu: '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 12h12M12 6v12" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>'
};
function sctEsc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function sctTesto(s, v){ return typeof s.testo === 'function' ? s.testo(v) : v + ' ' + (s.unita || 'min'); }
function sctId(chi, k){ return 'sct-' + chi + (k ? '-' + k : ''); }
function sctEl(chi, k){ try{ return document.getElementById(sctId(chi, k)); }catch(_){ return null; } }

/* 0.9.403 BUG-292, Andrea: "nel pannello scuro della tappa (matita) − e + ci sono subito, ai lati del tempo; toccando il numero − e +
   spariscono, compaiono i preset (dalla cronologia) e si apre la tastiera; la sottolineatura a puntini solo sul numero, mai su min".
   Opzione pmFuori (di base vale come scuro, che usa solo la tappa): chiuso − tempo +, aperto preset e tastiera. La sottolineatura sta
   sul solo numero in ogni uso del componente (sctValHtml) */
function sctValHtml(s, v){
  const t = sctTesto(s, v), m = /^([\d.,]+)(\s+\S.*)$/.exec(t);
  return m ? '<span class="sct-num">' + sctEsc(m[1]) + '</span>' + sctEsc(m[2]) : sctEsc(t);
}
function sctHtml(chi, o){
  const s = SCT[chi] = Object.assign({ min: 1, max: 180, passo: 5, preset: [], unita: 'min' }, o || {});
  s.val = +s.val || s.min;
  if (s.pmFuori === undefined) s.pmFuori = !!s.scuro;
  /* 0.9.402 BUG-232: quali preset (mai, dalla cronologia, o di base) lo dice pres; il vecchio presetSempre vale 'base' */
  s.pres = s.pres || (s.presetSempre ? 'base' : 'mai');
  let pres = s.pres === 'base' ? ((s.cat !== undefined) ? sctPresetPer(s.cat, s.preset, s.max) : (s.preset || []))
    : s.pres === 'storia' ? sctPresetStoria(s.cat, s.max) : [];
  pres = pres.slice(0, 5).map(function(x){ return Array.isArray(x) ? x : [+x, sctEtichetta(x, s.unita)]; });
  s.presetUsati = pres;
  /* 0.9.404 BUG-311, Andrea: "minuti diventa min", in ogni uso del componente */
  const unitaVis = (s.unitaScritta === 'minuti' || (!s.unitaScritta && s.unita === 'min')) ? 'min' : (s.unitaScritta || s.unita);
  const a = sctEsc(chi);
  return '<div class="sct' + (s.grande ? ' sct-grande' : '') + (s.scuro ? ' sct-scuro' : '') + (s.pmFuori ? ' sct-pmfuori' : '') + '" id="' + sctId(chi) + '">'
    + '<div class="sct-riga">'
    +   '<button type="button" class="sct-pm" aria-label="Meno tempo" onmousedown="event.preventDefault()" onclick="sctPasso(\'' + a + '\',-1)">' + SCT_SVG.meno + '</button>'
    +   '<button type="button" class="sct-val" id="' + sctId(chi, 'v') + '" aria-label="Cambia il tempo" aria-expanded="false" onclick="sctTocca(\'' + a + '\')">' + sctValHtml(s, s.val) + '</button>'
    +   '<span class="sct-in-w" id="' + sctId(chi, 'w') + '" hidden><input class="sct-in" id="' + sctId(chi, 'in') + '" type="number" inputmode="numeric" min="' + (s.minScritto || s.min) + '" max="' + s.max + '"'
    +     ' value="' + s.val + '" aria-label="Quanto tempo" data-no-mic data-no-dettatura enterkeyhint="done" oninput="sctBozza(\'' + a + '\',this.value)" onblur="sctScritto(\'' + a + '\',this.value)" onkeydown="if(event.key===\'Enter\'){event.preventDefault();this.blur();}">'
    /* l'unita' si tocca: chiude la tastiera, toglie − e + e fa tornare i preset (0.9.402 BUG-232) */
    +     '<button type="button" class="sct-unita" aria-label="Chiudi la tastiera" onclick="sctChiudi(\'' + a + '\')">' + sctEsc(unitaVis) + '</button></span>'
    +   '<button type="button" class="sct-pm" aria-label="Più tempo" onmousedown="event.preventDefault()" onclick="sctPasso(\'' + a + '\',1)">' + SCT_SVG.piu + '</button>'
    + '</div>'
    + (pres.length ? '<div class="sct-pres' + (pres.length > 3 ? ' scorre fl-fade-x' : '') + '" id="' + sctId(chi, 'p') + '">' + pres.map(function(x){
        return '<button type="button" class="' + (s.val === x[0] ? 'on' : '') + '" data-v="' + x[0] + '" onmousedown="event.preventDefault()" onclick="sctPreset(\'' + a + '\',' + x[0] + ')"' + (x[0] > s.max ? ' disabled' : '') + '>' + sctEsc(x[1]) + '</button>';
      }).join('') + '</div>' : '')
    + '</div>';
}
/* il valore nuovo: si scrive nel componente, poi lo si dice a chi lo usa */
function sctMetti(chi, v, come){
  const s = SCT[chi]; if (!s) return;
  /* 0.9.404 BUG-311, Andrea: "dopo una scelta a mano i preset spariscono, e tornano alla prossima apertura" (sctHtml rifa' il componente) */
  if (come === 'mio' || come === 'passo'){ const box = sctEl(chi); if (box) box.classList.add('sct-mano'); }
  if (v === s.val){ sctAggiorna(chi, v); return; }
  s.val = v; sctAggiorna(chi, v);
  if (typeof s.cambia === 'function') s.cambia(v, come);
}
function sctAggiorna(chi, v){
  const s = SCT[chi]; if (!s) return;
  s.val = +v;
  const l = sctEl(chi, 'v'); if (l){ const h = sctValHtml(s, s.val); if (h.indexOf('<span') >= 0) l.innerHTML = h; else l.textContent = sctTesto(s, s.val); }
  const i = sctEl(chi, 'in'); if (i) i.value = s.val;
  const p = sctEl(chi, 'p'); if (p) Array.prototype.forEach.call(p.querySelectorAll('button'), function(b){ b.classList.toggle('on', +b.getAttribute('data-v') === s.val); });
}
/* mentre si scrive, il − e il + partono dal numero scritto (e la tastiera resta aperta: onmousedown non toglie il fuoco al campo) */
function sctScrivendo(chi){ const w = sctEl(chi, 'w'); return !!(w && !w.hidden); }
function sctPasso(chi, d){
  const s = SCT[chi]; if (!s) return;
  let base = s.val;
  if (sctScrivendo(chi)){ const i = sctEl(chi, 'in'), t = parseInt(i && i.value, 10); if (isFinite(t) && t >= 1) base = Math.max(s.minScritto || s.min, Math.min(s.max, t)); }
  const n = Math.max(s.min, Math.min(s.max, Math.round(base / s.passo) * s.passo + d * s.passo));
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  if (n === s.val && d > 0 && n === s.max && typeof s.oltre === 'function'){ try{ toast(s.oltre(s.max)); }catch(_){ } }
  sctMetti(chi, n, 'passo');
}
/* il tocco sul tempo (0.9.402 BUG-232): compaiono insieme la tastiera e − e +, e i preset spariscono (mai tre controlli insieme) */
function sctTocca(chi){
  const s = SCT[chi], box = sctEl(chi); if (!s || !box) return;
  const l = sctEl(chi, 'v'), w = sctEl(chi, 'w'), i = sctEl(chi, 'in');
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  box.classList.add('aperto');
  if (!l || !w || !i) return;
  l.setAttribute('aria-expanded', 'true');
  i.value = s.val; l.hidden = true; w.hidden = false;
  try{ i.focus(); i.select(); }catch(_){ }
}
/** Richiude il componente: via la tastiera, via − e +, tornano il tempo e i preset. "aperto" si toglie per primo, cosi' il blur del
    campo (che tiene il numero scritto, sctScritto) non la richiama una seconda volta. */
function sctChiudi(chi){
  const box = sctEl(chi); if (!box || !box.classList.contains('aperto')) return;
  box.classList.remove('aperto');
  const w = sctEl(chi, 'w'), l = sctEl(chi, 'v'), i = sctEl(chi, 'in');
  /* 0.9.404 BUG-311, Andrea: "il numero scritto con la tastiera si salva anche toccando fuori, non solo con Vai". Si tiene qui, prima
     di togliere il fuoco: il blur non arriva sempre (tasto indietro, il foglio che si chiude, il campo nascosto) */
  if (w && !w.hidden && i){ sctTieni(chi, i.value); try{ i.blur(); }catch(_){ } }
  if (w) w.hidden = true; if (l){ l.hidden = false; l.setAttribute('aria-expanded', 'false'); }
}
/* un tocco fuori dal componente lo richiude */
if (typeof document !== 'undefined') document.addEventListener('pointerdown', function(e){
  try{
    Array.prototype.forEach.call(document.querySelectorAll('.sct.aperto'), function(box){
      if (box.contains(e.target)) return;
      const chi = String(box.id || '').replace(/^sct-/, ''); if (chi) sctChiudi(chi);
    });
  }catch(_){ }
}, true);
/* il numero scritto, al blur del campo (Invio, un tocco su "minuti" o fuori): si tiene, e il componente si richiude */
/** Tiene il numero scritto (gli estremi del componente, e il cartello se si va oltre il massimo). Non chiude niente. */
function sctTieni(chi, v){
  const s = SCT[chi]; if (!s) return;
  const letto = parseInt(v, 10);
  if (!isFinite(letto) || letto < 1){ sctAggiorna(chi, s.val); return; }
  const n = Math.max(s.minScritto || s.min, Math.min(s.max, letto));
  if (letto > s.max && typeof s.oltre === 'function'){ try{ toast(s.oltre(s.max)); }catch(_){ } }
  sctMetti(chi, n, 'mio');
}
/* 0.9.404 BUG-311: mentre si scrive il numero si tiene gia' (senza toccare il campo, senza cartelli): qualunque cosa chiuda la
   tastiera, il tempo scritto resta. Fuori dagli estremi aspetta la fine (sctTieni li sistema) */
function sctBozza(chi, v){
  const s = SCT[chi]; if (!s) return;
  const n = parseInt(v, 10);
  if (!isFinite(n) || n < (s.minScritto || s.min) || n > s.max || n === s.val) return;
  s.val = n;
  const box = sctEl(chi); if (box) box.classList.add('sct-mano');
  const l = sctEl(chi, 'v'); if (l){ const h = sctValHtml(s, n); if (h.indexOf('<span') >= 0) l.innerHTML = h; else l.textContent = sctTesto(s, n); }
  if (typeof s.cambia === 'function'){ try{ s.cambia(n, 'mio'); }catch(_){ } }
}
/** Chiude (e tiene) ogni componente aperto: lo chiama chi chiude il foglio che lo contiene. */
function sctChiudiTutti(){
  try{ Array.prototype.forEach.call(document.querySelectorAll('.sct.aperto'), function(box){ const chi = String(box.id || '').replace(/^sct-/, ''); if (chi) sctChiudi(chi); }); }catch(_){ }
}
function sctScritto(chi, v){
  const s = SCT[chi]; if (!s) return;
  /* gia' chiuso (e tenuto) da sctChiudi: il blur che arriva dopo non lo rifa' */
  const box = sctEl(chi); if (box && !box.classList.contains('aperto')) return;
  sctTieni(chi, v);
  sctChiudi(chi);
  const l = sctEl(chi, 'v'), w = sctEl(chi, 'w');
  if (w) w.hidden = true; if (l) l.hidden = false;
}
/* un preset: si vede solo a componente chiuso, quindi basta cambiare il valore */
function sctPreset(chi, v){
  const s = SCT[chi]; if (!s) return;
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  const n = Math.max(s.min, Math.min(s.max, +v));
  /* 0.9.403 BUG-292: con pmFuori il preset si tocca a tastiera aperta: il campo prende il preset prima di chiudersi (il suo blur tiene
     il numero scritto, sctScritto) */
  const i = sctEl(chi, 'in'); if (s.pmFuori && i) i.value = n;
  sctMetti(chi, n, 'preset');
  if (s.pmFuori) sctChiudi(chi);
}

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.sct{display:flex;flex-direction:column;align-items:center;margin:10px 0 22px}.sct [hidden]{display:none!important}'
  + '.sct-riga{display:flex;align-items:center;justify-content:center;gap:10px}'
  /* tondi, pieni, con l'ombra: si vedono anche su un foglio bianco */
  + '.sct-pm{flex:none;width:42px;height:42px;padding:0;border-radius:50%;border:1px solid rgba(0,30,68,.08);background:var(--card,#fff);color:var(--navy,#001E44);display:flex;align-items:center;justify-content:center;cursor:pointer;'
  +   'box-shadow:0 4px 12px rgba(0,30,68,.18),0 1px 3px rgba(0,30,68,.14);transition:transform .12s,box-shadow .12s}'
  + '.sct-pm:active{transform:scale(.92);box-shadow:0 2px 6px rgba(0,30,68,.2)}'
  + 'body.dark .sct-pm{background:#1B2C4F;color:#fff;border-color:rgba(255,255,255,.12);box-shadow:0 4px 14px rgba(0,0,0,.55),0 1px 3px rgba(0,0,0,.4)}'
  + '.sct-val{border:0;background:none;padding:4px 6px;min-width:76px;text-align:center;font:800 18px/1.2 var(--font-body);color:var(--navy,#001E44);cursor:pointer;'
  +   'text-decoration:underline dotted rgba(0,117,227,.55);text-decoration-thickness:2px;text-underline-offset:6px}'
  + 'body.dark .sct-val{color:#fff}'
  + '.sct-in-w{display:inline-flex;align-items:baseline;justify-content:center;gap:4px;min-width:76px}'
  + '.sct-in{width:2.6em;padding:4px 0;text-align:center;font:800 18px/1.2 var(--font-body);color:var(--navy,#001E44);border:0;border-bottom:2px solid #0075E3;background:transparent;outline:none;-moz-appearance:textfield}'
  + '.sct-in::-webkit-outer-spin-button,.sct-in::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}'
  + 'body.dark .sct-in{color:#fff}'
  + '.sct-grande .sct-riga{gap:14px}.sct-grande .sct-pm{width:48px;height:48px}'
  + '.sct-grande .sct-val,.sct-grande .sct-in{font:700 44px/1.1 var(--font-body)}.sct-grande .sct-in{width:2.4em}'
  + '.sct-pres{display:flex;justify-content:center;flex-wrap:wrap;gap:10px;margin:14px 0 2px}.sct.aperto .sct-pres{display:none!important}'
  + '.sct-pres button{min-width:72px;padding:10px 16px;border-radius:99px;border:1.5px solid var(--line,#DCE6F2);background:var(--card,#fff);color:var(--navy,#001E44);font:700 15px var(--font-body);cursor:pointer}'
  + '.sct-pres button.on{background:#001E44;border-color:#001E44;color:#fff}.sct-pres button:disabled{opacity:.4}'
  + 'body.dark .sct-pres button{background:#12203A;border-color:#22345A;color:#fff}body.dark .sct-pres button.on{background:#0075E3;border-color:#0075E3}';
  document.head.appendChild(st); })();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* 0.9.400 BUG-182: − e + solo col componente aperto; il tempo grande, sottolineato a puntini, e' l'invito a toccarlo */
  '.sct:not(.aperto) .sct-pm{display:none}'
  + '.sct-val{text-decoration-thickness:2px;text-underline-offset:7px}'
  /* piu' di tre preset: una riga sola che scorre. E' una riga come le altre dell'app: righe-scorrevoli.js la allarga fino al bordo
     del pannello (nessuna pill tagliata a meta') e scorre.js le mette la sfumatura dal lato verso cui si scorre (fl-fade-x) */
  + '.sct-pres.scorre{display:flex;align-self:stretch;flex-wrap:nowrap;justify-content:flex-start;overflow-x:auto;overflow-y:hidden;padding-top:4px;padding-bottom:8px;box-sizing:border-box;scrollbar-width:none;-webkit-overflow-scrolling:touch}'
  + '.sct-pres.scorre::-webkit-scrollbar{display:none}.sct-pres.scorre button{flex:0 0 auto;white-space:nowrap}'
  + '.sct{max-width:100%}'
  /* 0.9.402 BUG-232: il tempo sta sempre su una riga ("1h 30m" andava a capo); l'unita' accanto al campo e' un pulsante sottolineato */
  + '.sct-val{white-space:nowrap;flex:0 0 auto}.sct-riga{flex-wrap:nowrap;max-width:100%}'
  + '.sct-unita{flex:none;border:0;background:none;padding:8px 2px;margin:0;font:700 14px var(--font-body);color:var(--muted);text-decoration:underline;text-underline-offset:4px;cursor:pointer;white-space:nowrap}'
  + '.sct-grande .sct-unita{font-size:18px}.sct-scuro .sct-unita{color:#BCE0FF}body.dark .sct-unita{color:#A7B6CC}body.dark .sct-scuro .sct-unita{color:#BCE0FF}'
  /* sul pannello scuro (.sct-pan): testo bianco, − e + chiari, preset trasparenti */
  + '.sct-scuro .sct-val,.sct-scuro .sct-in{color:#fff}.sct-scuro .sct-val{text-decoration-color:rgba(140,198,255,.8)}.sct-scuro .sct-in{border-bottom-color:#8CC6FF}'
  + '.sct-scuro .sct-pm{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.22);color:#fff;box-shadow:0 4px 14px rgba(0,0,0,.35)}'
  + '.sct-scuro .sct-pres button{background:rgba(255,255,255,.08);border-color:rgba(188,224,255,.3);color:#fff}'
  + 'body.dark .sct-scuro .sct-pres button{background:rgba(255,255,255,.08);border-color:rgba(188,224,255,.3);color:#fff}'
  /* il pannello scuro condiviso di "Quanto dura la sessione" (Mappa, card delle sessioni) */
  + '.sct-pan{margin:0 0 22px;padding:18px 14px 16px;border-radius:20px;background:linear-gradient(160deg,#0B3E86,#001E44);color:#fff;text-align:center;box-shadow:0 10px 26px rgba(0,30,68,.22)}'
  + 'body.dark .sct-pan{background:linear-gradient(160deg,#123B7A,#061733);box-shadow:0 0 0 1px rgba(188,224,255,.16)}'
  + '.sct-pan-t{display:block;margin:0 0 4px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#BCE0FF}'
  + '.sct-pan .sct{margin:6px 0 0}.sct-pan.stt-pan{margin:16px 0 0}';
  document.head.appendChild(st); })();
/* 0.9.403 BUG-292: la sottolineatura a puntini sul solo numero; pmFuori (pannello scuro della tappa): chiuso − tempo +, aperto preset e
   tastiera (mai tre controlli insieme, lezione 330) */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* 0.9.404 BUG-311, Andrea: "a riposo la sottolineatura a puntini comprende anche min" (il timer, le card di Per te e Dopamine detox, le
     tappe della roadmap): torna su tutto il tempo. E a tastiera aperta la riga sotto va da un capo all'altro, numero e "min" insieme */
  '.sct-val .sct-num{text-decoration:none}body.dark .sct-val{text-decoration-color:rgba(140,198,255,.7)}.sct-scuro .sct-val{text-decoration-color:rgba(140,198,255,.8)}'
  + '.sct-in-w{box-sizing:border-box;padding:0 4px;border-bottom:2px solid #0075E3}.sct-in{border-bottom:0!important}.sct-unita{text-decoration:none!important}'
  + '.sct-scuro .sct-in-w{border-bottom-color:#8CC6FF}body.dark .sct-in-w{border-bottom-color:#8CC6FF}'
  + '.sct.sct-mano .sct-pres{display:none!important}'
  + '.sct.sct-pmfuori:not(.aperto) .sct-pm{display:flex}.sct.sct-pmfuori.aperto .sct-pm{display:none}'
  + '.sct.sct-pmfuori:not(.aperto) .sct-pres{display:none!important}.sct.sct-pmfuori.aperto .sct-pres{display:flex!important}';
  document.head.appendChild(st); })();
