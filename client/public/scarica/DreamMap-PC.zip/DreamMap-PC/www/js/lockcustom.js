/* =========================================================================================
   LA SCHERMATA DI BLOCCO PERSONALIZZATA, COPIATA DA APPBLOCK (0.9.283-284)

   0.9.284, Andrea: "hai messo icona, colore, testi e preferenze tutti nella stessa pagina, sotto
   al radio button, con un'anteprima quadrata: horror vacui. Devi scomporre in pagine separate,
   come AppBlock". Ritratto dal vero degli screenshot di AppBlock:
   - la pagina del programma ("Schermata di blocco"): Predefinita (con il collegamento a
     Personalizza) oppure Personalizzata (porta alla sua pagina);
   - "Personalizzate": X, titolo, Salva; l'anteprima grande come il telefono; in basso quattro
     pulsanti: Icona, Colore, Testo, Preferenze;
   - ogni pulsante apre la sua pagina con X e Salva: "Modifica testo" con Titolo, Sottotitolo e
     Pulsante di uscita (icona a sinistra, X per cancellare, "48 (massimo 60)"); "Preferenze" con
     Motivo del blocco (solo nei programmi), Scadenza schermata di blocco (meno, i secondi scritti
     da tastiera, piu', come nel foglio di START), Apri contatore, e nei programmi la pagina da
     aprire dopo il blocco.
   Dove vive: SETTINGS.lockCustom (Personalizza, stile "Personalizzata") e
   SETTINGS.schermateProgrammi[id] (modo "propria"); le legge BlockOverlay.buildCustom.
   ========================================================================================= */
const LC_DEF = { ico: 'app', emoji: '🛡️', colore: '#2F8FF0', titolo: '', sotto: '', bottone: 'Chiudi', scadenza: 0, contatore: false, motivo: true, url: '' };
const LC_COLORI = [['#2F8FF0', 'Blu'], ['#0075E3', 'Blu intenso'], ['#0E2350', 'Notte'], ['#5BC0F8', 'Azzurro'], ['#E5484D', 'Rosso'], ['#FF6FA8', 'Rosa'], ['grad', 'Rosa e azzurro']];
/* 0.9.375, Andrea: "i gradienti in un'altra sezione: due schede, Colore e Gradienti". I gradienti pronti, con i colori del brand */
const LC_GRADIENTI = [['grad', 'Rosa e azzurro'], ['grad:#0075E3,#001E44,160', 'Notte blu'], ['grad:#3F9FF4,#C8EFFD,160', 'Cielo'], ['grad:#E63946,#0075E3,135', 'Fuoco e mare'], ['grad:#001E44,#E63946,160', 'Tramonto']];
const LC_EMOJI = ['🛡️', '🚀', '🎯', '🔥', '🏆', '💎', '🧠', '⭐', '🌱', '⛔', '⏳', '🦁', '🗻', '📚', '💪'];
const LC = { ctx: 'globale', cfg: null, salvato: '', sub: '', tmp: null };
function lcEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function lcParse(v){ if (v && typeof v === 'object') return v; try{ return JSON.parse(v || '{}') || {}; }catch(_){ return {}; } }
function lcCfgGlobale(){ return Object.assign({}, LC_DEF, lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.lockCustom : '')); }
function lcProgDi(id){ const m = lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.schermateProgrammi : ''); return Object.assign({ modo: 'globale' }, LC_DEF, (id && m[id]) || {}); }
function lcSfondo(c){
  /* 0.9.367: anche un colore e un gradiente scelti dall'utente ("grad:#aaaaaa,#bbbbbb") */
  if (/^grad:/.test(c || '')){ const d = String(c).slice(5).split(','); return 'linear-gradient(' + (isFinite(+d[2]) && d[2] !== undefined && d[2] !== '' ? +d[2] : 160) + 'deg,' + (d[0] || '#0075E3') + ',' + (d[1] || '#E63946') + ')'; }
  return c === 'grad' ? 'linear-gradient(160deg,#FF8AC2,#5BC0F8)' : (c || '#2F8FF0');
}
/* 0.9.371, Andrea: "non voglio Pronti e I tuoi colori separati: tutti i colori, poi il colore personalizzato e il gradiente. Il popup per
   scegliere il colore fa schifo (quattro quadratini): voglio il ventaglio della replica di Samsung Notes. E il gradiente con i due
   pallini sotto e' una merda: come le impostazioni del gradiente di Shopify". Una griglia sola; il colore personalizzato apre il
   selettore con Campioni e Spettro; il gradiente apre l'anteprima con i due punti sulla barra, la direzione e lo stesso selettore */
function lcMieiColori(c){
  const tuo = /^#/.test(c || '') && !LC_COLORI.some(function(x){ return x[0] === c; }) ? c : '';
  const gr = /^grad:/.test(c || '');
  /* 0.9.375, Andrea: "Colore personalizzato e Gradiente personalizzato vanno a capo: Il tuo colore, Il tuo gradiente" */
  const grTuo = gr && !LC_GRADIENTI.some(function(x){ return x[0] === c; });
  if (LC.colTab === 'grad') return '<button type="button" class="' + (grTuo ? 'on' : '') + '" onclick="lcPickGrad()"><i style="background:' + (grTuo ? lcSfondo(c) : 'linear-gradient(135deg,#0075E3,#E63946)') + '"></i><span>Il tuo gradiente</span></button>';
  return '<button type="button" class="' + (tuo ? 'on' : '') + '" onclick="lcPickColore()"><i style="background:' + (tuo || 'conic-gradient(#E63946,#FFC53D,#3F9FF4,#0075E3,#E63946)') + '"></i><span>Il tuo colore</span></button>';
}
/* ---- il selettore del colore (come la replica di Samsung Notes) ---- */
const LCP = { modo: 'colore', vista: 'campioni', a: '#3F9FF4', b: '#E63946', ang: 135, stop: 0, prima: '' };
function lcHsl(h, s, l){ s /= 100; l /= 100; const k = function(n){ return (n + h / 30) % 12; }; const a = s * Math.min(l, 1 - l); const f = function(n){ return l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); }; return '#' + [f(0), f(8), f(4)].map(function(v){ return Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0'); }).join('').toUpperCase(); }
const LCP_TINTE = [25, 48, 60, 80, 130, 165, 185, 200, 220, 245, 275, 310], LCP_LUCI = [92, 85, 78, 70, 62, 55, 48, 41, 34, 27, 21, 15, 10];
const LCP_GRIGLIA = LCP_LUCI.map(function(l, r){ return [lcHsl(0, 0, 100 - r * (100 / 12))].concat(LCP_TINTE.map(function(h){ return lcHsl(h, r < 2 ? 100 : 90, l); })); });
function lcPickColore(){ const c = LC.tmp && LC.tmp.colore; LCP.modo = 'colore'; LCP.a = /^#/.test(c || '') ? String(c).toUpperCase() : '#3F9FF4'; LCP.prima = LCP.a; LCP.stop = 0; lcPickApri(); }
function lcPickGrad(){ const c = LC.tmp && LC.tmp.colore; const d = /^grad:/.test(c || '') ? String(c).slice(5).split(',') : ['#0075E3', '#E63946', '135']; LCP.modo = 'grad'; LCP.a = (d[0] || '#0075E3').toUpperCase(); LCP.b = (d[1] || '#E63946').toUpperCase(); LCP.ang = isFinite(+d[2]) && d[2] ? +d[2] : 135; LCP.stop = 0; lcPickApri(); }
function lcPickOra(){ return LCP.modo === 'grad' && LCP.stop === 1 ? LCP.b : LCP.a; }
function lcPickApri(){
  let w = document.getElementById('lcPick');
  if (!w){ w = document.createElement('div'); w.id = 'lcPick'; w.className = 'lcp-w'; (document.getElementById('phone') || document.body).appendChild(w); w.addEventListener('click', function(e){ if (e.target === w) lcPickChiudi(); }); }
  lcPickPaint(); w.classList.add('open');
}
function lcPickChiudi(){ const w = document.getElementById('lcPick'); if (w) w.classList.remove('open'); }
function lcPickPaint(){
  const w = document.getElementById('lcPick'); if (!w) return;
  const ora = lcPickOra(), gr = LCP.modo === 'grad';
  const sel = LCP.vista === 'campioni'
    ? '<div class="lcp-grid">' + LCP_GRIGLIA.map(function(r){ return r.map(function(c){ return '<button type="button" style="background:' + c + '" class="' + (c === ora ? 'on' : '') + '" onclick="lcPickMetti(\'' + c + '\')" aria-label="' + c + '"></button>'; }).join(''); }).join('') + '</div>'
    : '<div class="lcp-spettro" id="lcpSpettro"><span class="lcp-punto" id="lcpPunto" hidden></span></div>';
  const testa = gr
    ? '<div class="lcp-anteprima" style="background:linear-gradient(' + LCP.ang + 'deg,' + LCP.a + ',' + LCP.b + ')"></div>'
      + '<div class="lcp-barra" style="background:linear-gradient(90deg,' + LCP.a + ',' + LCP.b + ')"><button type="button" class="lcp-stop' + (LCP.stop === 0 ? ' on' : '') + '" style="left:0;background:' + LCP.a + '" onclick="lcPickStop(0)" aria-label="Primo colore"></button><button type="button" class="lcp-stop' + (LCP.stop === 1 ? ' on' : '') + '" style="left:100%;background:' + LCP.b + '" onclick="lcPickStop(1)" aria-label="Secondo colore"></button></div>'
      + '<div class="lcp-dir"><span>Direzione</span><input type="range" min="0" max="315" step="45" value="' + LCP.ang + '" oninput="lcPickAng(this.value)" aria-label="Direzione"><b id="lcpAng">' + LCP.ang + '°</b></div>'
    : '';
  w.innerHTML = '<div class="lcp"><button type="button" class="lcp-x" aria-label="Chiudi" onclick="lcPickChiudi()">' + LC_ICO.x + '</button>'
    + '<h3>' + (gr ? 'Il tuo gradiente' : 'Il tuo colore') + '</h3>' + testa
    + '<div class="lcp-tab" role="tablist"><button type="button" role="tab" aria-selected="' + (LCP.vista === 'campioni') + '" onclick="lcPickVista(\'campioni\')">Campioni</button><button type="button" role="tab" aria-selected="' + (LCP.vista === 'spettro') + '" onclick="lcPickVista(\'spettro\')">Spettro</button></div>'
    + sel
    + '<div class="lcp-val"><span class="lcp-cmp"><i style="background:' + (gr ? (LCP.stop ? LCP.b : LCP.a) : LCP.prima) + '"></i><i id="lcpNuovo" style="background:' + ora + '"></i></span><label><span>Esadecimale</span><input id="lcpHex" value="' + ora + '" maxlength="7" autocomplete="off" spellcheck="false" data-no-mic data-no-dettatura oninput="lcPickHex(this.value)"></label></div>'
    + '<button type="button" class="cta lcp-ok" onclick="lcPickUsa()">' + (gr ? 'Usa questo gradiente' : 'Usa questo colore') + '</button></div>';
  const sp = document.getElementById('lcpSpettro');
  if (sp){
    const tocca = function(e){ const r = sp.getBoundingClientRect(); const x = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), y = Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)); const p = document.getElementById('lcpPunto'); if (p){ p.hidden = false; p.style.left = (x * 100) + '%'; p.style.top = (y * 100) + '%'; } lcPickMetti(lcHsl(x * 360, 100, (1 - y) * 100), true); };
    sp.addEventListener('pointerdown', function(e){ try{ sp.setPointerCapture(e.pointerId); }catch(_){ } tocca(e); });
    sp.addEventListener('pointermove', function(e){ if (e.buttons || e.pointerType !== 'mouse') tocca(e); });
  }
}
function lcPickVista(v){ LCP.vista = v; lcPickPaint(); }
function lcPickStop(i){ LCP.stop = i; lcPickPaint(); }
function lcPickAng(v){ LCP.ang = +v || 0; const a = document.querySelector('#lcPick .lcp-anteprima'); if (a) a.style.background = 'linear-gradient(' + LCP.ang + 'deg,' + LCP.a + ',' + LCP.b + ')'; const b = document.getElementById('lcpAng'); if (b) b.textContent = LCP.ang + '°'; }
/* dallo spettro il colore cambia mentre il dito si muove: si aggiorna solo quello che cambia, senza ridisegnare il foglio */
function lcPickMetti(c, leggero){
  if (LCP.modo === 'grad' && LCP.stop === 1) LCP.b = c; else LCP.a = c;
  if (!leggero){ lcPickPaint(); return; }
  const n = document.getElementById('lcpNuovo'); if (n) n.style.background = c;
  const h = document.getElementById('lcpHex'); if (h) h.value = c;
  if (LCP.modo === 'grad'){ const a = document.querySelector('#lcPick .lcp-anteprima'); if (a) a.style.background = 'linear-gradient(' + LCP.ang + 'deg,' + LCP.a + ',' + LCP.b + ')'; const br = document.querySelector('#lcPick .lcp-barra'); if (br) br.style.background = 'linear-gradient(90deg,' + LCP.a + ',' + LCP.b + ')'; const s = document.querySelectorAll('#lcPick .lcp-stop'); if (s[LCP.stop]) s[LCP.stop].style.background = c; }
}
function lcPickHex(v){ v = String(v || '').trim().toUpperCase(); if (v && v[0] !== '#') v = '#' + v; if (/^#[0-9A-F]{6}$/.test(v)) lcPickMetti(v, true); }
function lcPickUsa(){ lcPickChiudi(); if (LCP.modo === 'grad') lcTmp('colore', 'grad:' + LCP.a + ',' + LCP.b + ',' + LCP.ang); else lcTmp('colore', LCP.a); }

/* le icone, a linea come quelle di AppBlock */
const LC_ICO = {
  x: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  icona: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M8.2 14.2c1 1.5 2.3 2.2 3.8 2.2s2.8-.7 3.8-2.2"/><circle cx="9" cy="9.8" r=".9" fill="currentColor"/><circle cx="15" cy="9.8" r=".9" fill="currentColor"/></svg>',
  colore: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h4v15a2 2 0 0 1-4 0z"/><path d="M9 7.5l3.2-3.2 2.8 2.8-6 6"/><path d="M13 21H7.5"/><path d="M13.5 15H21v6h-8z"/></svg>',
  testo: '<svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor"><text x="1" y="18.5" font-size="15" font-family="Georgia,serif">Aa</text></svg>',
  pref: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="8.5" cy="8.5" r="2.4"/><path d="M8.5 2.8v1.6M8.5 12.6v1.6M2.8 8.5h1.6M12.6 8.5h1.6M4.5 4.5l1.1 1.1M11.4 11.4l1.1 1.1M4.5 12.5l1.1-1.1M11.4 5.6l1.1-1.1"/><circle cx="16.5" cy="16.5" r="2.2"/><path d="M16.5 11.8v1.5M16.5 19.7v1.5M11.8 16.5h1.5M19.7 16.5h1.5M13.2 13.2l1 1M18.8 18.8l1 1M13.2 19.8l1-1M18.8 14.2l1-1"/></svg>',
  scudo: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>',
  timer: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 1.5M9.5 2.5h5"/></svg>',
  barre: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M8 16v-4M12 16V8M16 16v-6"/></svg>',
  link: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1"/><path d="M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/></svg>',
  tt: '<b class="lc-tt">Tt</b>',
  righe: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg>',
  pulsante: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="6" width="18" height="12" rx="2.5"/><path d="M8 12h8"/></svg>',
  freccia: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>'
};

/* ---------- l'anteprima: la schermata vera, in piccolo ---------- */
function lcIconaHtml(c, classe){
  if (c.ico === 'nessuna') return '';
  if (c.ico === 'emoji') return '<div class="' + classe + ' emo">' + lcEsc(c.emoji || '🛡️') + '</div>';
  if (c.ico === 'img'){
    const img = (typeof SETTINGS !== 'undefined' && SETTINGS.blockImage) ? String(SETTINGS.blockImage).replace(/"/g, '') : '';
    return '<div class="' + classe + ' img"' + (img ? ' style="background-image:url(' + img + ')"' : '') + '></div>';
  }
  /* l'icona dell'app bloccata, con il segno di DreamMap sopra (come lo scudo di AppBlock) */
  return '<div class="' + classe + ' app"><span>📷</span><i>' + LC_ICO.scudo + '</i></div>';
}
function lcSchermataHtml(c, conMotivo){
  const tit = (c.titolo || '').trim() || 'Instagram è bloccata';
  return lcIconaHtml(c, 'lc-s-ico')
    + '<h4 class="lc-s-tit">' + lcEsc(tit.replace('{app}', 'Instagram')) + '</h4>'
    + ((c.sotto || '').trim() ? '<p class="lc-s-sotto">' + lcEsc(c.sotto.replace('{app}', 'Instagram')) + '</p>' : '')
    + (!conMotivo || c.motivo !== false ? '<p class="lc-s-mot">Bloccata dal programma Social.</p>' : '')
    + (c.contatore ? '<p class="lc-s-cont"><b>Hai provato ad aprirla</b><br>3× quest’ora  |  41× in totale</p>' : '')
    + '<span class="lc-s-btn">' + lcEsc((c.bottone || '').trim() || 'Chiudi') + (c.scadenza ? ' · ' + c.scadenza + 's' : '') + '</span>';
}
/* per il carosello e per "Vedi a schermo intero" di Personalizza: la stessa schermata, nel loro riquadro */
function lcAnteprimaHtml(c, conMotivo){
  return '<div class="prev lc-prev-ls" style="background:' + lcSfondo(c.colore) + '">' + lcSchermataHtml(c, conMotivo) + '</div>';
}

/* ---------- la pagina "Personalizzate" ---------- */
function lcEdApri(ctx){
  LC.ctx = ctx === 'programma' ? 'programma' : 'globale';
  if (LC.ctx === 'programma'){
    const d = (typeof DRAFT !== 'undefined' && DRAFT) ? DRAFT : {};
    LC.cfg = Object.assign({}, LC_DEF, d.schermata || lcProgDi(d.id), { modo: 'propria' });
    if (!LC.cfg.url && d.redirectUrl) LC.cfg.url = d.redirectUrl;
  } else LC.cfg = lcCfgGlobale();
  LC.salvato = JSON.stringify(LC.cfg);
  /* 0.9.393, Andrea: "il pulsante Salva sempre sticky e solo quando l'utente fa una modifica [...] OVUNQUE". Il Salva dell'editor non sta
     piu' in alto a destra: sta nella fascia comune in fondo (registry.js, flPiede) e compare quando la schermata e' cambiata (lcSporco) */
  try{ if (typeof flPiedeApri === 'function') flPiedeApri('lc-ed', function(){ return lcSporco() ? '1' : ''; }); }catch(_){ }
  goId('s-lc-ed');
  lcEdPaint();
}
function lcEdPaint(){
  const h = document.getElementById('lcEdBody'); if (!h || !LC.cfg) return;
  const conMotivo = LC.ctx === 'programma';
  h.innerHTML = '<div class="lc-top"><button type="button" class="lc-top-x" onclick="lcEdChiudi()" aria-label="Chiudi">' + LC_ICO.x + '</button><b>Personalizzate</b></div>'
    + '<div class="lc-ed-w"><div class="lc-ed-prev" style="background:' + lcSfondo(LC.cfg.colore) + '">' + lcSchermataHtml(LC.cfg, conMotivo) + '</div></div>'
    + '<div class="lc-tabs">'
    + [['icona', 'Icona'], ['colore', 'Colore'], ['testo', 'Testo'], ['pref', 'Preferenze']].map(function(t){ return '<button type="button" onclick="lcSubApri(\'' + t[0] + '\')">' + LC_ICO[t[0]] + '<span>' + t[1] + '</span></button>'; }).join('')
    + '</div>'
    /* 0.9.393: il Salva in fondo, nella fascia comune: compare solo quando la schermata e' cambiata (lcEdApri, flPiedeApri) */
    + '<div class="lc-piede"><button type="button" class="cta fl-salva" data-fl="lc-ed" onclick="lcEdSalva()">Salva</button></div>';
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.lc-ed > .lc-tabs:has(~ .fl-piede:not(.fl-salva-attesa)){padding-bottom:8px}'; document.head.appendChild(st); })();
function lcSporco(){ return LC.cfg && JSON.stringify(LC.cfg) !== LC.salvato; }
function lcEdSalva(){
  const c = Object.assign({}, LC.cfg);
  if (LC.ctx === 'programma'){
    c.modo = 'propria';
    if (typeof DRAFT !== 'undefined' && DRAFT){
      DRAFT.schermata = c;
      DRAFT.redirectUrl = String(c.url || '').trim();
      const r = document.getElementById('edRedirect'); if (r) r.value = DRAFT.redirectUrl;
      /* un programma che esiste gia' la usa da subito; uno nuovo la salva insieme al programma */
      if (DRAFT.id && DRAFT.idx >= 0) lcSalvaProgramma(DRAFT.id, c);
    }
  } else {
    const v = JSON.stringify(c);
    if (typeof SETTINGS !== 'undefined'){ SETTINGS.lockCustom = v; SETTINGS.lockStyle = 'custom'; }
    try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ lockCustom: v, lockStyle: 'custom' }); }catch(_){ }
  }
  LC.salvato = JSON.stringify(LC.cfg);
  /* 0.9.393: la schermata del programma e' cambiata: il Salva del programma (#s-editor) compare */
  if (LC.ctx === 'programma'){ try{ FL_SALVA.sporca['s-editor'] = true; }catch(_){ } }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Schermata di blocco salvata');
  plkRigaPaint();
  lcIndietro();
}
/* si torna alla pagina di prima dalla storia (non da flIndietro: il tasto indietro di queste pagine chiama proprio
   lcEdChiudi e lcSubChiudi, e passare di nuovo da li' girerebbe all'infinito) */
function lcTorna(fallback){ const qui = order[cur]; if (!(typeof navTornaDietro === 'function' && navTornaDietro(qui))) goId(fallback); }
function lcIndietro(){ lcTorna(LC.ctx === 'programma' ? 's-prog-lock' : 's-lockscreen'); setTimeout(function(){ try{ plkPaint(); if (typeof lockScreenPaint === 'function' && order[cur] === 's-lockscreen') lockScreenPaint(); }catch(_){ } }, 60); }
function lcEdChiudi(){
  if (!lcSporco()){ lcIndietro(); return; }
  lcChiedi('Vuoi salvare le modifiche alla schermata di blocco?', 'Salva', function(){ lcEdSalva(); }, 'Esci senza salvare', function(){ LC.salvato = JSON.stringify(LC.cfg); lcIndietro(); });
}
/* la domanda prima di perdere delle modifiche: due pulsanti, ognuno col suo esito scritto */
function lcChiedi(testo, si, fSi, no, fNo){
  const w = document.createElement('div'); w.className = 'lc-chiedi';
  w.innerHTML = '<div class="lc-chiedi-in"><p>' + lcEsc(testo) + '</p><button type="button" class="cta">' + lcEsc(si) + '</button><button type="button" class="lc-chiedi-no">' + lcEsc(no) + '</button></div>';
  const via = function(){ w.remove(); };
  w.querySelector('.cta').onclick = function(){ via(); fSi(); };
  w.querySelector('.lc-chiedi-no').onclick = function(){ via(); fNo(); };
  w.addEventListener('click', function(e){ if (e.target === w) via(); });
  (document.getElementById('phone') || document.body).appendChild(w);
}

/* ---------- le sottopagine: Icona, Colore, Testo, Preferenze ---------- */
/* 0.9.393, Andrea: "il pulsante Salva [...] deve comparire solo se l'utente modifica qualcosa [...] OVUNQUE nell'app". Colori, icone e testi si scelgono
   toccando: il Salva guarda la bozza (registry.js, flPiede) */
function lcSubApri(k){ LC.sub = k; LC.tmp = Object.assign({}, LC.cfg); try{ if (typeof flPiedeApri === 'function') flPiedeApri('lc-sub', function(){ return JSON.stringify(LC.tmp || null); }); }catch(_){ } goId('s-lc-sub'); lcSubPaint(); }
function lcSubSalva(){ LC.colTab = ''; LC.cfg = Object.assign({}, LC.tmp); try{ flVibra(10); }catch(_){ } lcTorna('s-lc-ed'); setTimeout(lcEdPaint, 30); }
function lcSubChiudi(){ LC.tmp = null; LC.colTab = ''; lcTorna('s-lc-ed'); setTimeout(lcEdPaint, 30); }
function lcSubX(){ LC.tmp = null; LC.colTab = ''; goId('s-lc-ed'); setTimeout(function(){ lcEdPaint(); lcEdChiudi(); }, 40); }
const LC_ICO_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/></svg>';
function lcSubPaint(){
  const h = document.getElementById('lcSubBody'); if (!h || !LC.tmp) return;
  const c = LC.tmp, k = LC.sub;
  const titolo = { icona: 'Icona', colore: 'Colore', testo: 'Modifica testo', pref: 'Preferenze' }[k] || '';
  let corpo = '';
  if (k === 'icona'){
    const voce = function(v, t){ return '<button type="button" class="lc-opt' + (c.ico === v ? ' on' : '') + '" onclick="lcTmp(\'ico\',\'' + v + '\')"><span>' + t + '</span><i></i></button>'; };
    corpo = voce('app', 'L’icona dell’app bloccata') + voce('emoji', 'Un’emoji') + voce('img', 'La tua immagine') + voce('nessuna', 'Nessuna icona');
    if (c.ico === 'emoji') corpo += '<div class="lc-emo">' + LC_EMOJI.map(function(e){ return '<button type="button" class="' + (c.emoji === e ? 'on' : '') + '" onclick="lcTmp(\'emoji\',\'' + e + '\')">' + e + '</button>'; }).join('') + '</div>';
    if (c.ico === 'img') corpo += '<button type="button" class="lc-img-btn" onclick="lcImmagine()">' + ((typeof SETTINGS !== 'undefined' && SETTINGS.blockImage) ? 'Cambia l’immagine' : 'Scegli l’immagine') + '</button>';
  } else if (k === 'colore'){
    if (!LC.colTab) LC.colTab = (c.colore === 'grad' || /^grad:/.test(c.colore || '')) ? 'grad' : 'col';
    const lista = LC.colTab === 'grad' ? LC_GRADIENTI : LC_COLORI.filter(function(x){ return x[0] !== 'grad'; });
    corpo = '<div class="lc-coltab" role="tablist">' + [['col', 'Colori'], ['grad', 'Gradienti']].map(function(t){ return '<button type="button" role="tab" aria-selected="' + (LC.colTab === t[0]) + '" class="' + (LC.colTab === t[0] ? 'on' : '') + '" onclick="LC.colTab=\'' + t[0] + '\';lcSubPaint()">' + t[1] + '</button>'; }).join('') + '</div>'
      + '<div class="lc-col">' + lista.map(function(x){ return '<button type="button" class="' + (c.colore === x[0] ? 'on' : '') + '" onclick="lcTmp(\'colore\',\'' + x[0] + '\')" aria-label="' + x[1] + '"><i style="background:' + lcSfondo(x[0]) + '"></i><span>' + x[1] + '</span></button>'; }).join('')
      + lcMieiColori(c.colore) + '</div>';
  } else if (k === 'testo'){
    const campo = function(chiave, lab, ico, max, ph){
      const v = c[chiave] || '';
      return '<p class="lc-lab">' + lab + '</p><div class="lc-campo"><span class="lc-campo-ico">' + ico + '</span><textarea rows="1" maxlength="' + max + '" placeholder="' + lcEsc(ph) + '" oninput="lcTesto(\'' + chiave + '\',this)">' + lcEsc(v) + '</textarea>'
        + '<button type="button" class="lc-campo-x" onclick="lcTestoVia(\'' + chiave + '\')" aria-label="Cancella">' + LC_ICO.x + '</button></div><small class="lc-conta" id="lcN_' + chiave + '">' + v.length + ' (massimo ' + max + ')</small>';
    };
    corpo = campo('titolo', 'Titolo', LC_ICO.tt, 60, 'Instagram è bloccata') + campo('sotto', 'Sottotitolo', LC_ICO.righe, 100, 'Ogni volta che lo vedo, ricordo perché ho iniziato.') + campo('bottone', 'Pulsante di uscita', LC_ICO.pulsante, 20, 'Chiudi');
  } else if (k === 'pref'){
    /* 0.9.367, Andrea: "il + esce dal pannello della scadenza, i secondi sono distanti dal numero, e c'e' tanto testo". Ogni card: icona,
       titolo e una riga corta DENTRO la card; l'interruttore a destra; la scadenza ha il contatore su una riga sua, dentro la card */
    const riga = function(ico, t, destra, desc, clic, sotto){ return '<div class="lc-pref' + (sotto ? ' lc-pref-col' : '') + '"' + (clic ? ' onclick="' + clic + '" role="button"' : '') + '><div class="lc-pref-r"><span class="lc-pref-ico">' + ico + '</span><span class="lc-pref-tx"><b>' + t + '</b><small>' + desc + '</small></span>' + (sotto ? '' : destra) + '</div>' + (sotto ? destra : '') + '</div>'; };
    const sw = function(on){ return '<span class="lc-sw' + (on ? ' on' : '') + '"><i></i></span>'; };
    /* 0.9.373, Andrea: "il motivo del blocco non nelle Preferenze della schermata: nelle impostazioni del programma (l'ingranaggio), come nel
       Blocco rapido". Sta nel foglio Impostazioni del programma (blocco.js, swMotivo) */
    corpo += riga(LC_ICO.timer, 'Scadenza schermata di blocco',
      '<div class="stt-qty lc-qty" onclick="event.stopPropagation()"><button type="button" onclick="lcScad(-5)" aria-label="Meno">−</button><input id="lcScadIn" type="number" inputmode="numeric" min="0" max="120" value="' + (c.scadenza || 0) + '" oninput="lcScadScritto(this.value)" onfocus="this.select()"><span>s</span><button type="button" onclick="lcScad(5)" aria-label="Più">+</button></div>',
      'Quanti secondi aspetti prima di poterla chiudere.', '', true);
    corpo += riga(LC_ICO.barre, 'Mostra quante volte provi ad aprirla', sw(!!c.contatore), 'Quante volte hai provato ad aprirla oggi.', 'lcTmp(\'contatore\',' + (c.contatore ? 'false' : 'true') + ')');
    if (LC.ctx === 'programma') corpo += '<div class="lc-pref lc-pref-url"><span class="lc-pref-ico">' + LC_ICO.link + '</span><div><b>Pagina dopo il blocco</b><input class="fin" inputmode="url" autocomplete="off" placeholder="Vuota: quella di Personalizza" value="' + lcEsc(c.url || '') + '" oninput="LC.tmp.url=this.value.trim()"></div></div><small class="lc-pref-url-d">Si apre quando chiudi la schermata.</small>';
  }
  /* 0.9.375, Andrea: "il titolo al centro, Salva fisso in basso e non in alto a destra; in alto a destra sempre la X, in alto a sinistra la
     freccia per tornare indietro". La freccia torna a Personalizzate, la X chiude la personalizzazione */
  h.innerHTML = '<div class="lc-top lc-top3"><button type="button" class="lc-top-b" onclick="lcSubChiudi()" aria-label="Indietro">' + LC_ICO_INDIETRO + '</button><b>' + titolo + '</b><button type="button" class="lc-top-x" onclick="lcSubX()" aria-label="Chiudi">' + LC_ICO.x + '</button></div><div class="lc-sub">' + corpo + '</div>'
    + '<div class="lc-piede"><button type="button" class="cta fl-salva" data-fl="lc-sub" onclick="lcSubSalva()">Salva</button></div>';
  h.querySelectorAll('.lc-campo textarea').forEach(lcCresci);
}
function lcTmp(k, v){ if (!LC.tmp) return; LC.tmp[k] = v; try{ flVibra(8); }catch(_){ } lcSubPaint(); }
function lcCresci(t){ t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight) + 'px'; }
function lcTesto(k, el){ LC.tmp[k] = el.value; lcCresci(el); const n = document.getElementById('lcN_' + k); if (n) n.textContent = el.value.length + ' (massimo ' + el.maxLength + ')'; }
function lcTestoVia(k){ LC.tmp[k] = ''; lcSubPaint(); const t = document.querySelector('#lcSubBody textarea[oninput*="' + k + '"]'); if (t) t.focus(); }
function lcScad(d){ LC.tmp.scadenza = Math.max(0, Math.min(120, (+LC.tmp.scadenza || 0) + d)); const i = document.getElementById('lcScadIn'); if (i) i.value = LC.tmp.scadenza; try{ flVibra(8); }catch(_){ } }
function lcScadScritto(v){ const n = Math.round(+v); LC.tmp.scadenza = isFinite(n) ? Math.max(0, Math.min(120, n)) : 0; }
async function lcImmagine(){ if (typeof lockPick === 'function'){ await lockPick(); } lcSubPaint(); }

/* ---------- Personalizza: lo stile "Personalizzata" porta alla sua pagina ---------- */
function lsCustomPaint(){
  const box = document.getElementById('lsCustomBox'); if (!box) return;
  const on = (typeof SETTINGS !== 'undefined' && SETTINGS.lockStyle) === 'custom';
  box.hidden = !on;
  box.innerHTML = on ? '<button type="button" class="lc-vai" onclick="lcEdApri(\'globale\')"><span class="lc-vai-ico">' + LC_ICO.testo + '</span><span><b>Personalizza la schermata</b><small>Icona, colore, testi e preferenze</small></span>' + LC_ICO.freccia + '</button>' : '';
}

/* ---------- il programma: Predefinita o Personalizzata ---------- */
function plkTesto(){ const c = (typeof DRAFT !== 'undefined' && DRAFT && DRAFT.schermata) || null; return c && c.modo === 'propria' ? 'Personalizzata' : 'Predefinita'; }
function plkRigaPaint(){ const t = document.getElementById('edLockTxt'); if (t) t.textContent = plkTesto(); }
async function plkApri(){
  try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
  if (!DRAFT.schermata) DRAFT.schermata = lcProgDi(DRAFT.id);
  goId('s-prog-lock'); plkPaint();
}
function plkPaint(){
  const h = document.getElementById('plkBody'); if (!h || typeof DRAFT === 'undefined' || !DRAFT) return;
  const c = DRAFT.schermata || lcProgDi(DRAFT.id), propria = c.modo === 'propria';
  h.innerHTML = '<div class="pd-ops">'
    + '<div class="pd-op' + (propria ? '' : ' on') + '" role="button" onclick="plkModo(\'globale\')"><i></i><span><b>Predefinita</b><small>La schermata impostata in Personalizza, uguale per tutti i blocchi.</small>'
    +   (propria ? '' : '<button type="button" class="plk-vai" onclick="event.stopPropagation();goId(\'s-lockscreen\');if(typeof lockScreenPaint===\'function\')lockScreenPaint()">Modifica la schermata predefinita' + LC_ICO.freccia + '</button>') + '</span></div>'
    + '<div class="pd-op' + (propria ? ' on' : '') + '" role="button" onclick="plkModo(\'propria\')"><i></i><span><b>Personalizzata</b><small>Solo per questo programma:<br>icona, colore, testi e preferenze.</small>'
    +   (propria ? '<button type="button" class="plk-vai" onclick="event.stopPropagation();lcEdApri(\'programma\')">Personalizza la schermata' + LC_ICO.freccia + '</button>' : '') + '</span></div>'
    + '</div>';
}
function plkModo(m){
  const prima = (DRAFT.schermata || lcProgDi(DRAFT.id)).modo;
  DRAFT.schermata = Object.assign({}, DRAFT.schermata || lcProgDi(DRAFT.id), { modo: m === 'propria' ? 'propria' : 'globale' });
  try{ flVibra(8); }catch(_){ }
  if (DRAFT.id && DRAFT.idx >= 0) lcSalvaProgramma(DRAFT.id, DRAFT.schermata);
  plkPaint(); plkRigaPaint();
  /* scegliere "Personalizzata" porta subito alla sua pagina */
  if (m === 'propria' && prima !== 'propria') lcEdApri('programma');
}
function plkIndietro(){ plkRigaPaint(); if (typeof flIndietro === 'function') flIndietro(); else goId('s-editor'); }
/** Al salvataggio del programma: la sua schermata va nel motore (solo se e' "propria"). */
function lcSalvaProgramma(id, cfg){
  if (!id) return;
  const m = lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.schermateProgrammi : '');
  if (cfg && cfg.modo === 'propria'){ const c = Object.assign({}, cfg); m[id] = c; } else delete m[id];
  const v = JSON.stringify(m); if (typeof SETTINGS !== 'undefined') SETTINGS.schermateProgrammi = v;
  try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ schermateProgrammi: v }); }catch(_){ }
}

const LC_INDIETRO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>';
registerScreen('s-prog-lock',
  '<div class="topbar"><button class="iconbtn" onclick="plkIndietro()" aria-label="Indietro">' + LC_INDIETRO + '</button><b class="blk-title">Schermata di blocco</b></div>'
  + '<div id="plkBody"></div><div class="spacer"></div>', { back: 's-editor' });
registerScreen('s-lc-ed', '<div id="lcEdBody" class="lc-ed fl-scorre"></div>', { back: function(){ lcEdChiudi(); return null; } });
registerScreen('s-lc-sub', '<div id="lcSubBody" class="lc-subw"></div>', { back: function(){ lcSubChiudi(); return null; } });
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* le pagine: niente imbottitura dello schermo, ci pensano loro */
    '#s-lc-ed,#s-lc-sub{padding:0;background:var(--bg)}',
    '.lc-ed{position:absolute;inset:0;display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}',
    '.lc-subw{position:absolute;inset:0;overflow-y:auto;padding-top:env(safe-area-inset-top,0px)}',
    '.lc-top{display:flex;align-items:center;gap:10px;padding:14px 16px 10px;flex:none}',
    '.lc-top b{flex:1;font:800 22px var(--font-body);color:var(--navy);text-align:left;margin-left:6px}',
    '.lc-top-x,.lc-top-ok{border:0;background:none;color:#2F8FF0;cursor:pointer;padding:6px;display:flex;align-items:center}',
    '.lc-top-ok{font:800 18px var(--font-body)}',
    /* l'anteprima grande come il telefono, al centro */
    '.lc-ed-w{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:6px 0 10px}',
    '.lc-ed-prev{height:100%;max-height:640px;aspect-ratio:.565;max-width:84vw;border-radius:30px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px 22px;box-sizing:border-box;color:#fff;box-shadow:0 18px 40px rgba(0,30,68,.22);overflow:hidden}',
    '.lc-s-ico{position:relative;width:96px;height:96px;border-radius:50%;margin-bottom:26px;flex:none}',
    '.lc-s-ico.app{background:radial-gradient(circle at 30% 107%,#fdf497 0%,#fd5949 45%,#d6249f 60%,#285AEB 90%);display:flex;align-items:center;justify-content:center;font-size:44px}',
    '.lc-s-ico.app i{position:absolute;left:-14px;top:-12px;width:42px;height:42px;border-radius:50%;background:#2F8FF0;color:#fff;display:flex;align-items:center;justify-content:center;border:3px solid rgba(255,255,255,.95)}',
    '.lc-s-ico.app i svg{width:22px;height:22px}',
    '.lc-s-ico.emo{background:none;font-size:72px;line-height:96px;width:auto}',
    '.lc-s-ico.img{border-radius:22px;background:rgba(255,255,255,.3) center/cover}',
    '.lc-s-tit{margin:0;font:800 28px/1.18 var(--font-body);color:#fff;overflow-wrap:anywhere}',
    '.lc-s-sotto{margin:16px 0 0;font:500 16px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.lc-s-mot{margin:16px 0 0;font:500 15px/1.45 var(--font-body);color:rgba(255,255,255,.72)}',
    '.lc-s-cont{margin:14px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.78)}.lc-s-cont b{color:#fff}',
    '.lc-s-btn{margin-top:26px;min-width:45%;padding:15px 28px;border-radius:99px;background:rgba(255,255,255,.28);font:800 17px var(--font-body);color:#fff;box-sizing:border-box}',
    /* i quattro pulsanti in basso */
    '.lc-tabs{flex:none;display:grid;grid-template-columns:repeat(4,1fr);padding:8px 8px calc(env(safe-area-inset-bottom,0px) + 14px);border-top:1px solid var(--line)}',
    '.lc-tabs button{border:0;background:none;color:var(--navy);display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px 0;cursor:pointer;font:600 15px var(--font-body)}',
    /* le sottopagine */
    '.lc-sub{padding:8px 18px 40px}',
    '.lc-lab{margin:22px 4px 10px;font:800 18px var(--font-body);color:var(--navy)}.lc-lab:first-child{margin-top:8px}',
    '.lc-campo{display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:26px;background:var(--card);border:1px solid var(--line)}',
    '.lc-campo:focus-within{border-color:#2F8FF0;box-shadow:0 0 0 2px #2F8FF0 inset}',
    '.lc-campo-ico{flex:none;width:30px;display:flex;justify-content:center;color:#2F8FF0}.lc-tt{font:700 22px var(--font-body);color:#2F8FF0}',
    '.lc-campo textarea{flex:1;border:0;background:none;resize:none;font:500 17px/1.35 var(--font-body);color:var(--navy);outline:none;padding:0;min-height:24px;overflow:hidden}',
    '.lc-campo-x{flex:none;border:0;background:none;color:var(--muted);cursor:pointer;padding:2px;display:flex}.lc-campo-x svg{width:20px;height:20px}',
    '.lc-conta{display:block;text-align:right;margin:8px 4px 0;font:500 14px var(--font-body);color:var(--muted)}',
    '.lc-pref{display:flex;flex-direction:column;gap:16px;padding:18px;border-radius:22px;background:var(--card);border:1px solid var(--line);margin-top:16px;cursor:pointer;box-sizing:border-box;overflow:hidden}',
    '.lc-pref-r{display:flex;align-items:center;gap:14px;min-width:0}',
    '.lc-pref-tx{flex:1;min-width:0}.lc-pref-tx b{display:block;font:700 16.5px/1.3 var(--font-body);color:var(--navy)}.lc-pref-tx small{display:block;margin-top:4px;font:500 13.5px/1.4 var(--font-body);color:var(--muted)}',
    '.lc-pref-col{cursor:default}.lc-pref-col .lc-qty{align-self:center;display:flex;align-items:center;gap:14px}',
    '.lc-pref-col .lc-qty button{width:44px!important;height:44px;border-radius:50%;flex:none;font:600 22px/1 var(--font-body)}',
    '.lc-pref-col .lc-qty input{width:64px!important;text-align:right;font:800 22px var(--font-display);border:0;background:none;color:var(--navy);padding:0}.lc-pref-col .lc-qty span{font:600 15px var(--font-body);color:var(--muted);margin-left:-10px}',
    '.lc-pref-url-d{display:block;margin-top:8px;font:500 13.5px var(--font-body);color:var(--muted)}',
    '.lc-col-t{margin:26px 0 14px;font:800 15px var(--font-display);color:var(--navy)}.lc-col-t:first-child{margin-top:6px}body.dark .lc-col-t{color:#fff}',
    '.lc-col-mio label,.lc-col-mio .lc-grad{position:relative;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;font:600 13.5px var(--font-body);color:var(--navy)}',
    '.lc-col-mio label i,.lc-col-mio .lc-grad i{width:66px;height:66px;border-radius:50%;box-shadow:0 0 0 1px var(--line)}.lc-col-mio .on i{box-shadow:0 0 0 4px var(--bg),0 0 0 7px #2F8FF0}',
    '.lc-col-mio label input{position:absolute;inset:0;opacity:0;cursor:pointer}',
    '.lc-pref.lc-pref-url{flex-direction:row}.lc-grad-due input{-webkit-appearance:none;appearance:none}.lc-grad-due input::-webkit-color-swatch-wrapper{padding:0}.lc-grad-due input::-webkit-color-swatch{border:0;border-radius:50%}',
    '.lc-grad-due{display:flex;gap:8px}.lc-grad-due input{width:34px;height:34px;padding:0;border:1px solid var(--line);border-radius:50%;background:none;cursor:pointer}',
    '.lc-pref-ico{flex:none;color:#2F8FF0;display:flex}.lc-pref > b{flex:1;font:600 18px/1.3 var(--font-body);color:var(--navy)}',
    '.lc-pref-d{margin:10px 6px 0;font:500 14.5px/1.45 var(--font-body);color:var(--muted)}',
    '.lc-pref-url{cursor:default;align-items:flex-start}.lc-pref-url > div{flex:1}.lc-pref-url b{display:block;font:600 18px var(--font-body);color:var(--navy);margin-bottom:10px}.lc-pref-url .fin{width:100%;box-sizing:border-box}',
    '.lc-sw{flex:none;width:52px;height:32px;border-radius:99px;background:#C9D6E6;position:relative;transition:background .2s}',
    '.lc-sw i{position:absolute;top:4px;left:4px;width:24px;height:24px;border-radius:50%;background:#fff;transition:transform .2s}',
    '.lc-sw.on{background:#2F8FF0}.lc-sw.on i{transform:translateX(20px)}body.dark .lc-sw{background:#33415C}body.dark .lc-sw.on{background:#2F8FF0}',
    '.lc-qty{flex:none}.lc-qty button{width:40px!important}.lc-qty input{width:46px!important}',
    /* 0.9.371, Andrea: "lo 0 e' attaccato al piu' e il meno e' lontanissimo; meno e piu' giganti". Il numero e la s stanno al centro,
       stretti fra loro; meno e piu' sono piu' piccoli e alla stessa distanza dal numero */
    '.lc-pref-col .lc-qty{gap:18px!important;justify-content:center}.lc-pref-col .lc-qty button{width:42px!important;height:42px!important;font-size:22px!important}',
    '.lc-pref-col .lc-qty input{width:auto!important;field-sizing:content;min-width:1.2ch;text-align:center!important;padding:0!important}.lc-pref-col .lc-qty span{margin:0 0 0 -14px!important}',
    /* il selettore del colore */
    '.lcp-w{position:absolute;inset:0;z-index:130;background:rgba(0,14,34,.55);display:none;align-items:flex-end}.lcp-w.open{display:flex}',
    '.lcp{position:relative;width:100%;max-height:92%;overflow-y:auto;box-sizing:border-box;background:var(--card);border-radius:28px 28px 0 0;padding:22px 20px calc(20px + env(safe-area-inset-bottom))}',
    '.lcp h3{margin:2px 0 26px;text-align:center;font:800 20px var(--font-display);color:var(--navy)}body.dark .lcp h3{color:#fff}',
    '.lcp-x{position:absolute;top:16px;right:16px;width:38px;height:38px;border:0;border-radius:50%;background:var(--bg);color:var(--navy);display:grid;place-items:center;cursor:pointer}.lcp-x svg{width:18px;height:18px}body.dark .lcp-x{background:rgba(255,255,255,.1);color:#fff}',
    '.lcp-tab{display:grid;grid-template-columns:1fr 1fr;padding:3px;border-radius:20px;background:var(--bg);margin:0 0 16px}.lcp-tab button{height:36px;border:0;border-radius:17px;background:none;color:var(--muted);font:700 14.5px var(--font-body);cursor:pointer}.lcp-tab button[aria-selected="true"]{background:var(--card);color:var(--navy);box-shadow:0 1px 4px rgba(0,30,68,.15)}body.dark .lcp-tab button[aria-selected="true"]{background:#24395E;color:#fff}',
    '.lcp-grid{display:grid;grid-template-columns:repeat(13,minmax(0,1fr));gap:2px;border-radius:12px;overflow:hidden}.lcp-grid button{aspect-ratio:1;border:0;padding:0;cursor:pointer}.lcp-grid button.on{outline:2.5px solid #fff;outline-offset:-2.5px;box-shadow:0 0 0 2px #001E44 inset;position:relative;z-index:1}',
    '.lcp-spettro{position:relative;aspect-ratio:1.15;border-radius:14px;touch-action:none;cursor:crosshair;background:linear-gradient(to bottom,#fff 0%,#fff0 50%,#0000 50%,#000 100%),linear-gradient(to right,#f00,#ff0 16.6%,#0f0 33.3%,#0ff 50%,#00f 66.6%,#f0f 83.3%,#f00)}',
    '.lcp-punto{position:absolute;width:24px;height:24px;margin:-12px 0 0 -12px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 1px rgba(0,0,0,.5),0 2px 6px rgba(0,0,0,.5);pointer-events:none}.lcp-punto[hidden]{display:none}',
    '.lcp-val{display:flex;align-items:center;gap:14px;margin-top:18px}.lcp-cmp{flex:none;display:grid;grid-template-columns:1fr 1fr;width:64px;height:48px;border-radius:12px;overflow:hidden;box-shadow:inset 0 0 0 1px var(--line)}.lcp-cmp i{display:block}',
    '.lcp-val label{flex:1;min-width:0;display:flex;align-items:center;gap:10px;font:600 14px var(--font-body);color:var(--muted)}.lcp-val input{flex:1 1 auto;width:0!important;min-width:0;height:44px;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;background:var(--bg);color:var(--navy);font:700 16px var(--font-body);text-align:center;letter-spacing:.04em}body.dark .lcp-val input{color:#fff}',
    '.lcp-ok{margin-top:32px!important;width:100%}',
    '.lcp-anteprima{height:120px;border-radius:18px;box-shadow:inset 0 0 0 1px rgba(0,30,68,.08)}',
    '.lcp-barra{position:relative;height:18px;margin:26px 14px 0;border-radius:99px}.lcp-stop{position:absolute;top:50%;width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 1px rgba(0,30,68,.3),0 2px 6px rgba(0,30,68,.3);cursor:pointer;padding:0}.lcp-stop.on{box-shadow:0 0 0 3px #0075E3,0 2px 8px rgba(0,30,68,.35)}',
    '.lcp-dir{display:flex;align-items:center;gap:14px;margin:26px 0 30px;font:600 14px var(--font-body);color:var(--muted)}.lcp-dir input{flex:1;accent-color:#0075E3}.lcp-dir b{min-width:44px;text-align:right;font:800 15px var(--font-body);color:var(--navy)}body.dark .lcp-dir b{color:#fff}',
    '.lc-opt{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:12px;padding:18px;border-radius:26px;background:var(--card);border:1px solid var(--line);font:600 17px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    '.lc-opt i{width:22px;height:22px;border-radius:50%;border:2px solid #9DB8D6;flex:none;box-sizing:border-box}.lc-opt.on{border-color:#2F8FF0}.lc-opt.on i{border:7px solid #2F8FF0}',
    '.lc-emo{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:16px}',
    '.lc-emo button{aspect-ratio:1;border-radius:18px;border:1.5px solid var(--line);background:var(--card);font-size:30px;cursor:pointer}.lc-emo button.on{border-color:#2F8FF0;box-shadow:0 0 0 2px #2F8FF0 inset}',
    '.lc-img-btn{margin-top:16px;width:100%;padding:16px;border-radius:99px;border:0;background:#2F8FF0;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.lc-col{display:grid;grid-template-columns:repeat(3,1fr);gap:18px 10px;margin-top:10px}',
    '.lc-col button{border:0;background:none;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;font:600 13.5px var(--font-body);color:var(--navy)}',
    '.lc-col button i{width:66px;height:66px;border-radius:50%;box-shadow:0 0 0 1px var(--line)}.lc-col button.on i{box-shadow:0 0 0 4px var(--bg),0 0 0 7px #2F8FF0}',
    /* il collegamento in Personalizza e nel programma */
    '.lc-vai{display:flex;align-items:center;gap:14px;width:100%;margin-top:14px;padding:16px 18px;border-radius:20px;border:1.5px solid var(--line);background:var(--card);color:var(--navy);cursor:pointer;text-align:left}',
    '.lc-vai > span:nth-child(2){flex:1}.lc-vai b{display:block;font:800 16px var(--font-body)}.lc-vai small{display:block;font:500 13.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.lc-vai-ico{color:#2F8FF0;display:flex}.lc-vai > svg{color:var(--muted)}',
    '.plk-vai{display:flex;align-items:center;gap:4px;margin-top:12px;padding:0;border:0;background:none;color:#2F8FF0;font:800 14.5px var(--font-body);cursor:pointer}',
    'body.dark .plk-vai,body.dark .lc-top-x,body.dark .lc-top-ok{color:#7FC0FF}',
    /* il carosello e lo schermo intero di Personalizza */
    '.ls-card .prev.lc-prev-ls{padding:18px 14px}.ls-card .lc-prev-ls .lc-s-ico{width:52px;height:52px;margin-bottom:12px;font-size:24px}.ls-card .lc-prev-ls .lc-s-ico.emo{font-size:40px;line-height:52px}.ls-card .lc-prev-ls .lc-s-ico.app i{width:24px;height:24px;left:-8px;top:-6px;border-width:2px}.ls-card .lc-prev-ls .lc-s-ico.app i svg{width:12px;height:12px}',
    '.ls-card .lc-prev-ls .lc-s-tit{font-size:17px}.ls-card .lc-prev-ls .lc-s-sotto,.ls-card .lc-prev-ls .lc-s-mot,.ls-card .lc-prev-ls .lc-s-cont{font-size:11px;margin-top:8px}.ls-card .lc-prev-ls .lc-s-btn{margin-top:14px;padding:8px 16px;font-size:11px;min-width:0}',
    '.ls-card .prev.lc-prev-ls p{margin-top:8px}',
    '.ls-full .prev.lc-prev-ls{height:100%;min-height:100%;border-radius:0;padding:40px 28px}',
    '.ls-full .prev.lc-prev-ls .lc-s-ico{width:96px;height:96px;margin-bottom:28px;font-size:44px}.ls-full .prev.lc-prev-ls .lc-s-ico.emo{font-size:76px;line-height:96px}',
    '.ls-full .prev.lc-prev-ls h4.lc-s-tit{font-size:30px;line-height:1.2;margin:0}',
    '.ls-full .prev.lc-prev-ls p.lc-s-sotto{margin-top:16px;font-size:17px;color:rgba(255,255,255,.85)}',
    '.ls-full .prev.lc-prev-ls p.lc-s-mot{margin-top:18px;font-size:15px;color:rgba(255,255,255,.75)}',
    '.ls-full .prev.lc-prev-ls p.lc-s-cont{margin-top:16px;font-size:15px}',
    '.ls-full .prev.lc-prev-ls .lc-s-btn{margin-top:34px;padding:16px 34px;font-size:17px}',
    /* la domanda prima di perdere le modifiche */
    '.lc-chiedi{position:fixed;inset:0;z-index:9900;background:rgba(6,16,43,.5);display:flex;align-items:flex-end;justify-content:center}',
    '.lc-chiedi-in{width:100%;max-width:520px;background:var(--card);border-radius:24px 24px 0 0;padding:24px 20px calc(env(safe-area-inset-bottom,0px) + 22px);display:flex;flex-direction:column;gap:10px}',
    '.lc-chiedi-in p{margin:0 0 8px;font:700 17px/1.4 var(--font-body);color:var(--navy);text-align:center}',
    '.lc-chiedi-no{border:0;background:none;padding:12px;font:700 15px var(--font-body);color:var(--muted);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function(){ const st = document.createElement('style'); st.textContent = '.lc-subw{display:flex;flex-direction:column}.lc-subw > .lc-sub{flex:1 0 auto}'
  + '.lc-top3{position:relative;justify-content:space-between}.lc-top3 b{position:absolute;left:64px;right:64px;margin:0!important;text-align:center!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}'
  + '.lc-top-b{width:42px;height:42px;border:0;border-radius:50%;background:#E3ECF7;color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}body.dark .lc-top-b{background:#1B2C4F;color:#fff}'
  + '.lc-piede{position:sticky;bottom:0;z-index:3;flex:none;padding:14px 18px calc(16px + env(safe-area-inset-bottom,0px));background:var(--bg);box-shadow:0 -10px 18px -6px var(--bg)}.lc-piede .cta{margin:0;width:100%}'
  + '.lc-coltab{display:flex;gap:4px;margin:2px 0 22px;padding:5px;border-radius:999px;background:#E9EEF5}.lc-coltab button{flex:1;border:0;border-radius:999px;padding:11px 6px;background:transparent;color:#5B6B85;font:700 14.5px var(--font-body);cursor:pointer}.lc-coltab button.on{background:#001E44;color:#fff}'
  + 'body.dark .lc-coltab{background:rgba(255,255,255,.08)}body.dark .lc-coltab button{color:rgba(232,241,255,.7)}body.dark .lc-coltab button.on{background:#0075E3;color:#fff}'
  + '.lc-col button span{white-space:nowrap}'; document.head.appendChild(st); })();
