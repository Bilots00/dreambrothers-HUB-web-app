/* 0.9.374: l'icona del tempo di schermo (memoria.js); qui di riserva, per chi carica questo file da solo (i test) */
var FL_ICO_SCHERMO = (typeof FL_ICO_SCHERMO !== 'undefined' && FL_ICO_SCHERMO) || '<svg class="fl-ico-schermo" viewBox="0 0 24 24" width="1.05em" height="1.05em" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="vertical-align:-.16em;flex:none"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2.2"/></svg>';
/* scores.js - the numbers of the day, and the two places they live.

   The Profile opens on the night sky of the wishlist page: the name under a starfield, then a
   slideshow that rotates on its own between the phrase of the day (typed out letter by letter,
   ending on a "Vedi dettagli" that opens Ispirazione quotidiana) and the day's focus hours and
   streak. Below it, the report: today's screen time against yesterday, blocked and unlocks
   with their explanations, and where the attention went.

   The four scores live at the top of the Blocco tab, each ring filling to its own percentage
   every time that tab is opened.

   Every figure is read from the engine's getDayReport(); a score whose inputs are missing is
   shown as "-", never as a guess. The formulas are written down in SC_META where the user can
   read them. */

const SC_DAY_MS = 86400000;
const SC_H = 3600000;
const SC = { mem: {}, view: 'total', dayOff: 0, tipTimer: 0, typed: false, slide: 0,
             rotate: 0, held: 0, quotes: null, insDay: 0 };

/* Packages that count as distracting until the user says otherwise from the Report tab. */
const SC_DEFAULT_DISTRACT = ['com.instagram.android','com.instagram.lite','com.zhiliaoapp.musically','com.ss.android.ugc.trill',
  'com.facebook.katana','com.facebook.lite','com.google.android.youtube','com.twitter.android','com.snapchat.android',
  'com.reddit.frontpage','tv.twitch.android.app','com.pinterest','com.netflix.mediaclient','com.tumblr','com.discord',
  'com.tinder','com.badoo.mobile','com.disney.disneyplus','com.amazon.avod.thirdpartyclient','com.twitch.android.app'];

/* When the store cannot be reached the day still has a phrase. */
/* LA SCORTA DELL'APP.
   Serve quando il sito non risponde, e serve anche quando l'elenco che arriva ha poche frasi
   LEGGIBILI: in tutti e due i casi e' quella che tiene in piedi la pagina. Con sei frasi si
   ripeteva ogni sei giorni, che e' un difetto diverso dallo stesso problema; diciotto fanno
   quasi tre settimane. Tutte corte, perche' e' il loro mestiere: devono stare sulla schermata
   di blocco senza finire sotto all'orologio. */
const SC_FALLBACK_QUOTES = [
  'Il futuro dipende da quello che fai oggi. ~ Mahatma Gandhi',
  'Se il tuo domani sarà uguale a quello di ieri, avrai vissuto un giorno solo. ~ Gianluca Liguori',
  'La felicità è quando ciò che pensi, ciò che dici e ciò che fai sono in armonia. ~ Mahatma Gandhi',
  'Non è che abbiamo poco tempo. È che ne perdiamo molto. ~ Seneca',
  'La disciplina è scegliere tra ciò che vuoi ora e ciò che vuoi di più. ~ Abraham Lincoln',
  'Ogni volta che dici sì a una distrazione, dici no a qualcosa che conta. ~ Anonimo',
  'Siamo ciò che facciamo ripetutamente. ~ Aristotele',
  'Il modo per iniziare è smettere di parlare e cominciare a fare. ~ Walt Disney',
  'Un idiota con un piano può battere un genio senza un piano. ~ Warren Buffett',
  'Mentre si rimanda, la vita passa. ~ Seneca',
  'Chi insegue due conigli non ne prende nessuno. ~ Proverbio',
  'Un viaggio di mille miglia comincia con un passo. ~ Lao Tzu',
  'Non importa quanto vai piano, purché tu non ti fermi. ~ Confucio',
  'Chi è dappertutto non è in nessun posto. ~ Seneca',
  'Comincia. Il coraggio ha in sé genio e potere. ~ Goethe',
  'Il tempo perduto non si ritrova mai più. ~ Benjamin Franklin',
  'La conoscenza non basta. Bisogna applicarla. ~ Bruce Lee',
  'La disciplina è il ponte fra i sogni e i risultati. ~ Proverbio',
  'Nessuno ti restituirà gli anni. ~ Seneca',
  'Prima il necessario, poi il possibile. E all\'improvviso stai facendo l\'impossibile. ~ Francesco d\'Assisi'
];
const SC_MONTHS = ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

function scIsDistracting(pkg){
  let c = null;
  try{ c = (typeof insCats === 'function') ? insCats()[pkg] : null; }catch(_){ c = null; }
  if (c) return c === 'distr';
  return SC_DEFAULT_DISTRACT.indexOf(pkg) >= 0;
}
/* I NAVIGATORI (0.9.204). Waze e Google Maps misurano la strada, non il telefono in mano: il loro
   tempo non entra nel tempo di schermo della panoramica. Dalla lista «Dove va la tua attenzione?»
   escono solo se lo scegli dal menu ⋯. Le altre app escluse dal Report restano qui: la panoramica
   dice dove va l'attenzione, il Report cosa conti. */
const SC_NAV_PKG = /waze|google\.android\.apps\.maps|\.maps$|navigat|sygic|tomtom|here\.app|osmand|mapfactor|magicearth|moovit|citymapper/i;
function scIsNav(a){ return SC_NAV_PKG.test(String((a && a.packageName) || '')) || /^(waze|google maps|maps|mappe|here wego|moovit)$/i.test(String((a && a.label) || '').trim()); }
function scNavMs(rows){ return (rows || []).filter(scIsNav).reduce(function(t, a){ return t + (a.ms || 0); }, 0); }
function scNavNascosti(){ try{ return localStorage.getItem('fl_nav_nascondi') === '1'; }catch(_){ return false; } }
function scNavNascondiSet(on){ try{ localStorage.setItem('fl_nav_nascondi', on ? '1' : '0'); }catch(_){ } scMenusClose(); scBlockScores(); }
/** Le righe della panoramica: sempre le prime cinque (i navigatori restano, salvo scelta). */
function scRigheAttenzione(rows){ const r = (rows || []).filter(function(a){ return !a.launcher && (!scNavNascosti() || !scIsNav(a)); }); return r.slice(0, 5); }
function scExcluded(){ try{ return (typeof insExcl === 'function') ? insExcl() : []; }catch(_){ return []; } }
/* 0.9.286: la mezzanotte di un altro giorno si trova spostando la data, non togliendo 24 ore: il 25 ottobre
   (si torna all'ora solare) dura 25 ore, e "oggi + 7 x 24 ore" cadeva alle 23 del giorno prima. La scorta
   delle frasi del telefono finiva con i giorni sfasati di uno. */
function scDayStart(off){ const d = new Date(); d.setHours(0,0,0,0); if (off) d.setDate(d.getDate() - off); return d.getTime(); }
function scKey(ts){ const d = new Date(ts); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); }
function scClamp(x){ return Math.max(0, Math.min(1, x)); }
function scMinOfDay(ts){ const d = new Date(ts); return d.getHours() * 60 + d.getMinutes(); }
function scFmt(ms){
  ms = Math.max(0, Math.round(ms || 0));
  const m = Math.floor(ms / 60000), h = Math.floor(m / 60);
  if (h > 0) return h + 'h ' + String(m % 60).padStart(2,'0') + 'm';
  if (m > 0) return m + 'm';
  return Math.floor(ms / 1000) + 's';
}
/* 0.9.365, Andrea: "34 ore e 4 minuti: nessuno ragiona in 34 ore. Prima i giorni e le ore, poi le ore totali". Oltre le 24 ore il
   numero grande dice giorni e ore ("1 giorno e 10 ore"), e sotto, piccolo, il totale in ore */
function scFmtGiorni(ms){
  const m = Math.round((ms || 0) / 60000), g = Math.floor(m / 1440), h = Math.round((m - g * 1440) / 60);
  if (g < 1) return scFmtShort(ms);
  return g + (g === 1 ? ' giorno' : ' giorni') + (h ? ' e ' + h + (h === 1 ? ' ora' : ' ore') : '');
}
/* 0.9.401 BUG-194, Andrea: "46h 30min in tutto e' inutile, e 1 giorno e 23 ore va a capo". Bastano giorni e ore, e il numero grande
   non va mai a capo (lezione 293): resta su una riga e, se non ci sta, si rimpicciolisce lui (scGrandeAdatta) */
function scGrandeGiorni(ms){
  if ((ms || 0) < 86400000) return '<b class="rep-big rep-big-1">' + scFmtShort(ms) + '</b>';
  return '<b class="rep-big rep-big-g rep-big-1">' + scFmtGiorni(ms) + '</b>';
}
function scFmtShort(ms){
  const m = Math.round((ms || 0) / 60000), h = Math.floor(m / 60);
  if (h > 0) return m % 60 ? h + 'h ' + (m % 60) + 'min' : h + 'h';
  return m + 'min';
}
function scDistractions(r){
  const ex = scExcluded();
  return (r && r.top || []).filter(a => ex.indexOf(a.packageName) < 0 && !a.launcher && scIsDistracting(a.packageName))
                            .reduce((s, a) => s + (a.ms || 0), 0);
}

/* ---------------------------------------------------------------------------------------
   DATA
   --------------------------------------------------------------------------------------- */

/* IL CANCELLO NON E' PIU' «il motore sa misurare», MA «c'e' una giornata da mostrare».
   Sul computer `getDayReport` non esiste: con la vecchia domanda questi pannelli sparivano
   del tutto, e chi guardava vedeva una scheda mezza vuota senza capire perche'. La giornata
   la misura il telefono e la pubblica; qui basta averla. */
function scHaGiornata(){
  try{
    if (NATIVE && typeof NATIVE.getDayReport === 'function') return true;
    return !!(typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.rep);
  }catch(_){ return false; }
}

let SC_PC_LETTO = 0;
const SC_IN_CORSO = {};
async function scReport(off){
  const start = scDayStart(off);
  const key = scKey(start);
  /* PRIMA DI QUALUNQUE GIUDIZIO SULLA NOTTE, il primo segno di vita sul computer. Era letto
     solo dalla pagina del punteggio: le pillole del Profilo e il rapporto pubblicato al
     computer partivano senza, e la sveglia restava quella del telefono (11:03). */
  if ((off || 0) === 0 && Date.now() - SC_PC_LETTO > 3 * 60000){
    SC_PC_LETTO = Date.now();
    try{ if (typeof dpLeggiComputer === 'function') await dpLeggiComputer(); }catch(_){ }
  }
  if (off > 0){
    /* un giorno salvato prima del motore unico del sonno (0.9.236) si rilegge una volta */
    try{ const c = localStorage.getItem('fl_dayrep_' + key); if (c){ const v = JSON.parse(c); if (v && v.granted && (v.sonnoV === SN_V || snQuiComputer())) return v; } }catch(_){ }
  }
  const mem = SC.mem[key];
  if (mem && Date.now() - mem.t < 45000) return mem.v;
  /* chi arriva mentre il giorno si sta leggendo aspetta la stessa lettura: il motore risponde a
     una domanda alla volta, e dieci domande uguali in fila facevano scadere quelle dopo */
  if (SC_IN_CORSO[key]) return SC_IN_CORSO[key];
  if (!NATIVE || !NATIVE.getDayReport) return null;
  SC_IN_CORSO[key] = (async function(){
    let r = null;
    try{ r = await NATIVE.getDayReport({ dayStart: start }); }catch(_){ r = null; }
    if (!r) return null;
    /* LA NOTTE DAL MOTORE UNICO, sempre dal telefono: anche quando il Report guarda il
       computer o i due insieme e questo rapporto e' una ricostruzione (sonno.js) */
    try{ r = await snConNotte(r, start); }catch(_){ }
    return r;
  })();
  let r = null;
  try{ r = await SC_IN_CORSO[key]; }finally{ delete SC_IN_CORSO[key]; }
  if (!r) return null;
  SC.mem[key] = { t: Date.now(), v: r };
  if (off > 0 && r.granted){
    try{
      const slim = Object.assign({}, r, { top: (r.top || []).map(a => ({ packageName: a.packageName, label: a.label, ms: a.ms, launcher: !!a.launcher })) });
      localStorage.setItem('fl_dayrep_' + key, JSON.stringify(slim));
    }catch(_){ }
  }
  return r;
}

/**
 * LA GIORNATA DEI TRE PUNTEGGI: sempre quella del telefono (0.9.302).
 *
 * <p>Sonno, Focus e Riposo li misura il telefono ("I PUNTEGGI RESTANO DEL TELEFONO", motore-web.js), qualunque
 * dispositivo sia scelto nei tre puntini del pannello. La 0.9.301 l'aveva corretto solo nella card del Profilo:
 * toccando un punteggio, la pagina del dettaglio leggeva ancora scReport, cioe' la sorgente scelta. Con "solo il
 * computer" e il computer che oggi non aveva mandato niente, il rapporto tornava { granted: false, senzaDati } e la
 * pagina diceva "Serve l'accesso ai dati di utilizzo" a chi l'accesso l'aveva dato; con il computer acceso giudicava
 * il sonno e il riposo sui programmi del PC. Le medie dei sette giorni avevano lo stesso difetto.</p>
 *
 * <p>Sul telefono si chiede al suo motore vero (mwReportVero), con la notte del motore unico; sul computer la
 * giornata di oggi e' quella che il telefono ha pubblicato (specchio-web.js, SW_GIORNO).</p>
 */
/* 0.9.303: sul computer la giornata del telefono arriva dall'account. Se il computer non e' piu' collegato (il 28/10 lo era
   stato fino al 20/10, poi Google ha chiesto di nuovo l'accesso) la colpa non e' del telefono: lo si dice, e si offre
   l'accesso (specchio-web.js, SW_GIORNO.errore). */
function scPcScollegato(){
  try{ return typeof mwMotoreVero === 'function' && !mwMotoreVero() && typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.errore === 'accesso'; }
  catch(_){ return false; }
}
async function scPcAccedi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.googleSignIn) return;
    const r = await NATIVE.googleSignIn();
    /* 0.9.389 (BUG-119): dopo un accesso riuscito il segno "accesso mancante" si toglie subito */
    if (r && r.signedIn){ try{ if (typeof agAccessoSegna === 'function') agAccessoSegna(true); }catch(_){ } }
    if (r && r.signedIn && typeof toast === 'function') toast('Collegato: ' + r.email);
  }catch(e){ if (typeof toast === 'function') toast(e && e.message ? e.message : 'Accesso non riuscito'); return; }
  try{ if (typeof swSincronizza === 'function') await swSincronizza(true); }catch(_){ }
  try{ scoresRefresh(); }catch(_){ }
  try{ if (document.getElementById('scBody')) scRender(); }catch(_){ }
}

const SC_MEM_TEL = {};
async function scReportPunteggi(off){
  off = off || 0;
  const vero = typeof mwMotoreVero === 'function' && mwMotoreVero();
  if (!vero){
    /* il computer: oggi e' la giornata pubblicata dal telefono, gli altri giorni quello che si sa */
    try{
      if (off === 0 && typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.rep && SW_GIORNO.rep.dayStart === scDayStart(0)) return SW_GIORNO.rep;
    }catch(_){ }
    return await scReport(off);
  }
  /* il telefono con la sua sorgente: e' gia' la lettura del suo motore (e la cache e' la stessa) */
  if (typeof mwFonte !== 'function' || mwFonte() === 'telefono' || typeof mwReportVero !== 'function') return await scReport(off);
  const start = scDayStart(off), key = scKey(start);
  const m = SC_MEM_TEL[key];
  if (m && (off > 0 || Date.now() - m.t < 45000)) return m.v;
  let v = await mwReportVero(start);
  if (v && v.granted){ try{ v = await snConNotte(v, start); }catch(_){ } }
  if (v) SC_MEM_TEL[key] = { t: Date.now(), v: v };
  return v;
}

/*
 * The three scores, recalibrated on a real day.
 *
 * The first formulas were built on the calendar day, and a night that crossed midnight broke
 * all three at once: bed at 04:00, up at 10:00, on the phone all day. Sleep came out as "not
 * measured" (the day's first use was at 00:10), Rest came out 100 (the six hours asleep were
 * counted as time awake and away from the phone), Focus came out 47 for a day with almost no
 * distracting apps in it. The reference app read the same day as 25 / 90 / 25.
 *
 * The engine now hands over the night as a night (sleepMs, sleepStart, wakeAt) and the waking
 * day measured from waking (awakeScreenMs, awakeGapMs), and each score reads its own thing:
 *   Sonno   how long the night was, and how late it began. An inverted U (SC_SONNO_CURVA):
 *           4h or less = 0, 7h30-8h30 = 100, then down again (10h = 78, 12h = 50); bed after
 *           01:00 costs 8, after 03:00 costs 12. Six hours begun at 04:00 is 58.
 *   Focus   how much went to distracting apps, first of all; total screen time and pickups
 *           weigh less. A long day of work on the phone with no social in it stays high.
 *   Riposo  how much of the waking day was spent off the screen, and the longest break in it.
 *           A day spent entirely on the phone is low, however long the night was.
 */
/**
 * IL PRIMO SEGNO DI VITA, ovunque sia.
 *
 * <p>La notte finiva al primo sblocco del TELEFONO. Chi si alza alle otto e va dritto al
 * computer lascia il telefono fermo fino a mezza mattina: il 22/09 il punteggio leggeva la
 * notte da 01:22 a 11:03 — nove ore e quarantuno — e dava 92, mentre le ore dormite erano
 * sei e mezza. Il computer pubblica il suo primo segno di vita della giornata (`fl:pc-grani`,
 * scritto dal computer stesso): se e' piu' presto, la notte finisce li'.</p>
 */
/* LA SVEGLIA DAL COMPUTER E' UNA SCELTA (0.9.202, Andrea): di serie conta solo il telefono.
   Chi lavora al computer appena sveglio la accende dalla pagina del punteggio Sonno. */
function scSvegliaPcOn(){ try{ return localStorage.getItem('fl_sveglia_pc') === '1'; }catch(_){ return false; } }
function scSvegliaPcSet(on){ try{ localStorage.setItem('fl_sveglia_pc', on ? '1' : '0'); }catch(_){ } }
/* Un primo segno di vita del COMPUTER prima delle quattro non e' una sveglia: e' la sera
   (0.9.202). Vale solo per il computer: per il telefono decide il motore del sonno. */
const SC_SVEGLIA_MIN = 4 * 60;
function scPcSveglia(r){
  try{
    if (!scSvegliaPcOn()) return 0;
    if (typeof dpComputerPrimo !== 'function' || typeof dpChiave !== 'function') return 0;
    if (!r || !r.dayStart) return 0;
    const p = dpComputerPrimo(dpChiave(r.dayStart));
    if (!p) return 0;
    /* dentro alla giornata, e dopo il momento in cui la notte e' cominciata */
    if (p < r.dayStart || p > r.dayStart + 86400000) return 0;
    if (r.sleepStart && p <= r.sleepStart) return 0;
    if (scMinOfDay(p) < SC_SVEGLIA_MIN) return 0;
    return p;
  }catch(_){ return 0; }
}

/* IL SONNO E' UNA COLLINA, NON UNA SCALA (12/10/2026, Andrea).
   Prima otto ore valevano 100 e ogni ora in piu' restava 100: undici ore e mezza prendevano il
   voto pieno. Dormire molto oltre le nove ore e mezza sballa l'orologio del corpo e di solito
   lascia piu' intontiti, quindi sopra le otto ore e mezza il punteggio scende di nuovo.
   [ore, punti]: fra due righe si va in linea retta; sotto la prima 0, sopra l'ultima 0. */
/* 0.9.236: la collina vive in sonno-motore.js (SN_CURVA), con il resto del conto della notte. */
const SC_SONNO_CURVA = SN_CURVA;
/* Da qui in su il punteggio scende perche' hai dormito TROPPO (serve all'etichetta). */
const SC_SONNO_TROPPO_H = 8.5;
function scSonnoPunti(ore){ return snCurva(ore); }

function scCompute(r){
  if (!r || !r.granted) return null;
  /* SUL COMPUTER I TRE PUNTEGGI SONO QUELLI DEL TELEFONO. Sonno, Focus e Riposo li misura il
     telefono: qui si giudica la giornata che ha spedito lui, qualunque sorgente sia scelta
     per i rapporti. Un computer acceso e lasciato li' direbbe zero riposo. */
  try{
    if (typeof mwSoloWeb === 'function' && mwSoloWeb() && typeof SW_GIORNO !== 'undefined'
        && SW_GIORNO && SW_GIORNO.rep && SW_GIORNO.rep.dayStart === r.dayStart && !r.daTelefono){
      r = SW_GIORNO.rep;
    }
  }catch(_){ }
  const now = Date.now();
  const today = r.dayStart === scDayStart(0);
  const screen = r.screenMs || 0;
  const distr = scDistractions(r);
  const pickups = r.pickups || 0;
  const gap = r.longestGapMs || 0;
  /* LA NOTTE E' QUELLA DEL MOTORE UNICO (sonno-motore.js), arrivata dentro al rapporto
     (scReport -> snConNotte). Niente piu' conti qui: la vecchia regola "un risveglio prima
     delle quattro e' la sera" e il ripiego sul primo uso del giorno di calendario sono finiti
     li', e il ripiego era proprio il "Primo sblocco 00:00" del 13/10: un uso cominciato prima
     di mezzanotte, tagliato alle 00:00. Un rapporto ricostruito in pagina (sorgente del
     Report "computer" o "insieme") non sa niente della notte: senza la notte del motore,
     la notte non c'e'. */
  const n = r.notte || null;
  let notte = n;
  let wake = n ? (n.sveglia || 0) : (r.daMotoreWeb ? 0 : (r.wakeAt || 0));
  let sleepMs = n ? (n.ok ? (n.sonnoMs || 0) : 0) : (r.daMotoreWeb ? 0 : (r.sleepMs || 0));
  const sleepStart = n ? (n.inizio || 0) : (r.daMotoreWeb ? 0 : (r.sleepStart || r.prevLastUse || 0));
  if (!n && sleepMs > 0) notte = { ok: true, inizio: sleepStart, sveglia: wake, sonnoMs: sleepMs, effettivoMs: sleepMs, interruzioni: [] };
  const pcSveglia = scPcSveglia(r);
  if (pcSveglia && sleepStart && pcSveglia > sleepStart && (!wake || pcSveglia < wake)){
    wake = pcSveglia;
    const prima = ((notte && notte.interruzioni) || []).filter(function(x){ return x.at < pcSveglia; });
    sleepMs = Math.max(0, pcSveglia - sleepStart - prima.reduce(function(t, x){ return t + x.ms; }, 0));
    notte = { ok: true, inizio: sleepStart, sveglia: pcSveglia, sonnoMs: sleepMs, effettivoMs: sleepMs, interruzioni: prima, svegliaDa: 'computer' };
  }
  const awakeFrom = r.awakeFrom || wake || r.firstUse || 0;
  const end = r.lastUse ? (today ? now : r.lastUse) : 0;
  const span = (awakeFrom && end) ? Math.max(0, end - awakeFrom) : 0;
  const awakeScreen = (typeof r.awakeScreenMs === 'number') ? r.awakeScreenMs : screen;
  const offline = Math.max(0, span - awakeScreen);
  const awakeGap = r.awakeGapMs || 0;
  const o = { screenMs: screen, distrMs: distr, pickups: pickups, gapMs: gap, spanMs: span, offlineMs: offline,
              sleepMs: sleepMs, first: wake, last: r.lastUse || 0,
              prevLast: sleepStart, sleepStart: sleepStart, wake: wake, notte: notte,
              sveglia: wake, daComputer: !!(pcSveglia && pcSveglia === wake),
              blocks: r.blocks || 0, sessions: r.sessions || 0, hasUse: !!(r.firstUse || screen > 0) };
  /* il voto: la collina sulle ore (il sonno leggero dopo una sveglia rimandata vale meta'),
     meno l'ora tarda del letto, meno un poco per ogni interruzione (snPunteggio) */
  o.sleep = (o.sleepMs > 0 && notte) ? snPunteggio(Object.assign({}, notte, { ok: true, sonnoMs: o.sleepMs })) : null;
  if (o.hasUse){
    const f = 100 - 70 * scClamp(distr / (3 * SC_H)) - 20 * scClamp(screen / (10 * SC_H))
                  - 10 * scClamp((pickups - 30) / 70);
    o.focus = Math.round(Math.max(0, Math.min(100, f)));
  } else o.focus = null;
  // Rest reads the whole day so far, not only the stretch since waking: at 10:42 someone who
  // slept until 10:30 has rested all night, and a score that read "—" for the first hour of
  // every day was the score nobody understood. Share of the day spent off the screen: a
  // quarter is 0, four fifths is 100 (Opal's 70 sits at about 62%).
  const dayEnd = today ? now : (r.dayStart ? r.dayStart + 86400000 : 0);
  const elapsed = (r.dayStart && dayEnd) ? Math.max(0, dayEnd - r.dayStart) : 0;
  o.elapsedMs = elapsed; o.dayOfflineMs = Math.max(0, elapsed - screen); o.awakeGapMs = awakeGap;
  if (elapsed >= 60 * 60000){
    const ratio = o.dayOfflineMs / elapsed;
    o.rest = Math.round(Math.max(0, Math.min(100, (ratio - 0.25) / 0.55 * 100)));
  } else o.rest = null;
  const parts = [o.sleep, o.focus, o.rest].filter(v => v !== null);
  o.total = parts.length ? Math.round(parts.reduce((a, b) => a + b, 0) / parts.length) : null;
  return o;
}

async function scAverages(off){
  const acc = {}, n = {};
  const add = (k, v) => { if (v === null || v === undefined) return; acc[k] = (acc[k] || 0) + v; n[k] = (n[k] || 0) + 1; };
  for (let i = 1; i <= 7; i++){
    const r = await scReportPunteggi(off + i);
    const c = scCompute(r);
    if (!c || !c.hasUse) continue;
    add('screenMs', c.screenMs); add('distrMs', c.distrMs); add('pickups', c.pickups);
    add('gapMs', c.awakeGapMs > 0 ? c.awakeGapMs : c.gapMs); add('offlineMs', c.elapsedMs > 0 ? c.dayOfflineMs : null);
    add('sleepMs', c.sleepMs > 0 ? c.sleepMs : null);
    add('firstMin', c.first ? scMinOfDay(c.first) : null);
    add('lastMin', c.prevLast ? ((scMinOfDay(c.prevLast) + 12 * 60) % (24 * 60)) : null);
    add('blocks', c.blocks);
  }
  const out = {};
  Object.keys(acc).forEach(k => { out[k] = acc[k] / n[k]; });
  out.days = Math.max.apply(null, [0].concat(Object.keys(n).map(k => n[k])));
  return out;
}

/* ---------------------------------------------------------------------------------------
   THE PHRASE OF THE DAY - the store's own list, the store's own arithmetic
   --------------------------------------------------------------------------------------- */

/* The cache is keyed on the day, not on twenty-four elapsed hours: a phrase fetched at 23:50
   has to change at midnight, like the website's does. */
/* 0.9.337, Andrea: "la frase di Bob Marley sui soldi continua a comparire: non la voglio piu' vedere". Arriva dalle frasi del
   giorno del sito, o dalla memoria di ieri: si scarta qui, da qualunque fonte, e anche sul server (dreammapQuotes.ts). */
const SC_BANDITE = /marley|povere|poveri|ricco non|uomo ricco|poor man|so poor|rich man/i;
function scPulisci(o){
  if (!o) return o;
  if (o.today && SC_BANDITE.test(o.today)) o.today = '';
  if (Array.isArray(o.list)) o.list = o.list.filter(function(q){ return !SC_BANDITE.test(typeof q === 'string' ? q : JSON.stringify(q)); });
  return o;
}
async function scQuotes(){
  const day = scKey(scDayStart(0));
  if (SC.quotes && SC.quotes.day === day) return SC.quotes;
  let cached = null;
  try{ cached = JSON.parse(localStorage.getItem('fl_quotes') || 'null'); }catch(_){ cached = null; }
  scPulisci(cached);
  if (cached && cached.day === day && (cached.today || (cached.list || []).length)){ SC.quotes = cached; return cached; }
  let got = null;
  if (NATIVE && NATIVE.publicApi){
    try{
      const j = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/quotes' });
      /* 0.9.288: la frase "di oggi" del server vale solo se il server parla dello stesso giorno. Prima si teneva per
         tutta la giornata anche quando arrivava dalla memoria di ieri (alle 8 c'era ancora la frase del giorno prima). */
      if (j && (j.today || (j.quotes && j.quotes.length))) got = { day: day, today: (!j.day || j.day === day) ? (j.today || '') : '', list: j.quotes || [], serverDay: j.day || '' };
    }catch(_){ }
  }
  if (!got){
    if (cached && (cached.today || (cached.list || []).length)) return cached;   // ieri è meglio di niente
    got = { day: day, today: '', list: SC_FALLBACK_QUOTES, fallback: true };
  } else {
    if (!got.serverDay || got.serverDay === day){ try{ localStorage.setItem('fl_quotes', JSON.stringify(got)); }catch(_){ } }
  }
  SC.quotes = scPulisci(got);
  return got;
}
/* ---------------------------------------------------------------------------------------
   QUANTO PUO' ESSERE LUNGA UNA FRASE

   Il limite non e' un gusto: e' una misura. Sulla schermata di blocco la frase sta sotto
   all'orologio e ha quattro righe scarse prima di finire fuori — circa centosettanta
   caratteri a corpo normale su uno schermo da telefono. Oltre, l'ultima parte non si legge, e
   una frase che finisce a meta' e' peggio di una frase che non c'e'.

   Il taglio tiene dentro le brevi e le medio-lunghe, e lascia fuori solo i racconti: chi ha
   scritto un pezzo da millecinquecento caratteri non stava scrivendo una frase del giorno.
   --------------------------------------------------------------------------------------- */
const SC_MAX_LEN = 170;
/* E una lunghezza MINIMA, che serve per una ragione diversa e altrettanto concreta.
   La traduzione italiana dell'elenco e' uscita dallo strumento di traduzione con qualche
   pezzo rotto: fra le 276 frasi ce ne sono tre che sono solo frammenti — «.», «.»,
   «. Sognano."» — rimasti attaccati alla frase sbagliata. Ventidue altre cominciano con un
   punto e uno spazio di troppo, e quelle non sono rotte: sono buone, con davanti della
   sporcizia. Quindi due trattamenti diversi: le prime si scartano, le seconde si puliscono.
   «"Pensa, credi, sogna e osa."» sta in ventotto caratteri ed e' una frase intera: la soglia
   deve stare sotto, o si butterebbe via la piu' bella. */
const SC_MIN_LEN = 20;
const SC_MIN_POOL = 20;

/** Via la punteggiatura orfana in testa, che arriva dalla traduzione e non dall'autore. */
function scPulisci(raw){
  return String(raw || '').replace(/^[\s.,;:)\]}’”]+/, '').trim();
}

/** Da scartare: troppo lunga per la schermata di blocco, o troppo corta per essere una frase. */
function scTroppoLunga(raw){
  const p = scSplitQuote(raw);
  return !p || p.text.length > SC_MAX_LEN || p.text.length < SC_MIN_LEN;
}

/**
 * La frase del giorno `off`, cercando dall'indice in avanti finche' non se ne trova una che
 * ci sta.
 *
 * <p>NON si filtra l'elenco: filtrarlo sposterebbe tutti gli indici, e l'indice e' l'unica
 * cosa che tiene l'app allineata a quello che il sito ha mostrato quel giorno. Si parte
 * dall'indice giusto e, se quella frase e' un racconto, si prende la successiva — il che vuol
 * dire che nei giorni normali, che sono la grande maggioranza, l'app dice esattamente quello
 * che diceva il sito.</p>
 */
function scDalGiorno(list, off){
  const n = list.length;
  if (!n) return null;
  const giorno = Math.floor(scDayStart(off) / 1000 / 86400);
  const i0 = ((giorno % n) + n) % n;
  /* ELENCO CORTO: si filtra e si allunga con la scorta.
     Qui prima c'era `if (n < SC_MIN_POOL) return scSplitQuote(list[i0])` — cioe' «se l'elenco
     e' corto, non controllare la lunghezza». Una rete di sicurezza messa DAVANTI al cancello
     invece che dietro: bastava che la chiamata al server fallisse e tornasse la copia di ieri
     (una frase sola) perche' tutti e sette i giorni mostrassero la stessa frase da
     trecentoventi caratteri, illeggibile sulla schermata di blocco.
     Con un elenco corto l'allineamento con il sito non esiste comunque — il sito ha il suo
     elenco intero — quindi qui si puo' filtrare senza perdere niente. */
  if (n < SC_MIN_POOL){
    const scorta = list.filter(function(q){ return !scTroppoLunga(q); }).concat(SC_FALLBACK_QUOTES);
    if (!scorta.length) return null;
    return scSplitQuote(scorta[((giorno % scorta.length) + scorta.length) % scorta.length]);
  }

  if (!scTroppoLunga(list[i0])) return scSplitQuote(list[i0]);

  /* SI SALTA A MEZZO ELENCO, non alla successiva.
     Prendere semplicemente «quella dopo» fa una cosa brutta: se la frase del giorno D e'
     lunga e quella di D+1 va bene, D mostra la frase di D+1 e il giorno dopo la rimostra.
     Misurato su un anno: 71 giorni su 366 uguali al giorno prima. Saltando a meta' elenco il
     sostituto finisce lontano da qualsiasi vicino, e due giorni consecutivi atterrano su due
     posizioni diverse: 2 ripetizioni su 366, con gli stessi 294 giorni identici al sito. */
  const base = (i0 + Math.floor(n / 2)) % n;
  for (let k = 0; k < n; k++){
    const c = list[(base + k) % n];
    if (!scTroppoLunga(c)) return scSplitQuote(c);
  }
  /* Tutte lunghe: meglio la scorta che una frase illeggibile. Non si torna MAI su list[i0]. */
  return scSplitQuote(SC_FALLBACK_QUOTES[((giorno % SC_FALLBACK_QUOTES.length) + SC_FALLBACK_QUOTES.length) % SC_FALLBACK_QUOTES.length]);
}

/* Splits "testo ~ autore". */
function scSplitQuote(raw){
  const chosen = scPulisci(raw);
  if (!chosen) return null;
  const parts = chosen.split('~');
  if (parts.length > 1) return { text: parts.slice(0, -1).join('~').trim(), author: parts[parts.length - 1].trim() || 'Anonimo' };
  return { text: chosen, author: 'Anonimo' };
}
/**
 * La frase di un giorno, con la stessa aritmetica del sito.
 *
 * <p>NIENTE ORDINAMENTO. Qui c'era `sort((a,b) => a.length - b.length)`, messo per rispecchiare
 * il `{% assign quotes = quotes | sort: 'size' %}` del tema. Quel Liquid pero' non ordina per
 * lunghezza: `sort: 'proprieta''` legge `item['proprieta'']`, e su una STRINGA Ruby quella e'
 * una ricerca di sottostringa — `"una frase"["size"]` e' nil a meno che dentro non ci sia
 * scritto «size», e su 276 frasi non succede mai. L'elenco resta nell'ordine in cui arriva.
 *
 * <p>Verificato il 17/09/2026 sull'elenco vero: la frase che il sito mostrava oggi sta alla
 * posizione 13 dell'ordine originale, e i giorni dall'epoch modulo 276 fanno 13. Con
 * l'ordinamento per lunghezza usciva la posizione 60, cioe' un'altra frase — ed e' quello che
 * l'app avrebbe mostrato per ogni giorno passato.</p>
 */
/* 0.9.286, Andrea: "fai in modo che compaiano anche come frasi del giorno, oltre alle frasi del mio sito".
   Le frasi scelte da lui passano davanti a quella del sito in giorni fissi: i primi giorni dal 20 ottobre una
   dopo l'altra, poi una ogni sette giorni, a turno. Gli altri giorni restano quelli del sito, con il suo indice.
   Le usa anche frasi-obiettivo.js: compaiono pure con "solo frasi sul mio obiettivo" acceso. */
const SC_SCELTE = [
  '"Concentrarsi vuol dire saper dire di no." ~ Steve Jobs',
  '"Il successo è andare da un fallimento all’altro senza perdere l’entusiasmo." ~ Winston Churchill',
  '"Siamo ciò che facciamo ripetutamente; l’eccellenza, quindi, non è un atto, ma un’abitudine." ~ Will Durant',
  /* 0.9.289, Andrea */
  '"Quanto tempo hai intenzione di aspettare prima di pretendere il meglio per te stesso?" ~ Epitteto',
  /* 0.9.296, Andrea (22/10/2026): in italiano per chi usa il telefono in italiano, l'originale per chi lo usa in inglese */
  { it: '"Non ci sono limiti. Ci sono solo plateau. Non devi restarci, devi andare oltre." ~ Bruce Lee', en: '"There are no limits. There are only plateaus, and you must not stay there, you must go beyond them." ~ Bruce Lee' },
  { it: '"Le paure che non affrontiamo diventano i nostri limiti. Le occasioni che non cogliamo diventano i nostri muri." ~ Robin Sharma', en: '"The fears we don\u2019t face become our limits. The opportunities we don\u2019t seize become our walls." ~ Robin Sharma' },
  { it: '"Tutto quello che non stai cambiando, lo stai scegliendo." ~ Laurie Buchanan', en: '"Whatever you are not changing, you are choosing." ~ Laurie Buchanan' },
  { it: '"Noi siamo quello che scegliamo di essere. Ora scegli!" ~ Green Goblin', en: '"We are who we choose to be. Now choose!" ~ Green Goblin' },
  /* 0.9.306, Andrea (29/10/2026) */
  { it: '"Non aspettare il momento perfetto. Prendi il momento e rendilo perfetto." ~ Zoey Sayward', en: '"Don\u2019t wait for the perfect moment. Take the moment and make it perfect." ~ Zoey Sayward' },
  { it: '"La vita si restringe o si espande in proporzione al proprio coraggio." ~ Anaïs Nin', en: '"Life shrinks or expands in proportion to one\u2019s courage." ~ Anaïs Nin' },
  { it: '"Tutto ciò che hai sempre voluto è dall’altra parte della paura." ~ George Addair', en: '"Everything you\u2019ve ever wanted is on the other side of fear." ~ George Addair' },
  { it: '"L’unico limite a ciò che realizzeremo domani saranno i nostri dubbi di oggi." ~ Franklin D. Roosevelt', en: '"The only limit to our realization of tomorrow will be our doubts of today." ~ Franklin D. Roosevelt' },
  { it: '"Ogni battaglia viene vinta o persa prima ancora di essere combattuta." ~ Sun Tzu', en: '"Every battle is won or lost before it is ever fought." ~ Sun Tzu' },
  { it: '"Se conosci il nemico e conosci te stesso, non devi temere il risultato di cento battaglie." ~ Sun Tzu', en: '"If you know the enemy and know yourself, you need not fear the result of a hundred battles." ~ Sun Tzu' },
  /* 0.9.343, Andrea (09/11/2026) */
  { it: '"Quando cominci a camminare sulla via, la via appare." ~ Rumi', en: '"As you start to walk out on the way, the way appears." ~ Rumi' },
  /* 0.9.347, Andrea: la frase di Carl Jung dello screenshot di Brain.fm */
  { it: '"Il conflitto esiste solo come opportunità per innalzare la nostra coscienza." ~ Carl Jung', en: '"Conflict exists strictly as an opportunity to raise our consciousness." ~ Carl Jung' },
  /* 0.9.348, Andrea: le frasi di Nader, Carnegie, Angelou e Platone */
  { it: '"Il compito di chi guida è creare altri leader, non altri seguaci." ~ Ralph Nader', en: '"The function of leadership is to produce more leaders, not more followers." ~ Ralph Nader' },
  { it: '"Raramente le persone hanno successo se non si divertono in quello che fanno." ~ Dale Carnegie', en: '"People rarely succeed unless they have fun in what they are doing." ~ Dale Carnegie' },
  { it: '"Chiedi quello che vuoi, e preparati a ottenerlo." ~ Maya Angelou', en: '"Ask for what you want and be prepared to get it." ~ Maya Angelou' },
  { it: '"L’inizio è la parte più importante del lavoro." ~ Platone', en: '"The beginning is the most important part of the work." ~ Plato' },
  { it: '"Puoi avere la nave migliore del mondo, l’aereo migliore del mondo, ma se il capitano o il pilota non sa dove andare, la nave andrà alla deriva e non arriverà mai da nessuna parte." ~ Arnold Schwarzenegger', en: '"You can have the best ship in the world, you can have the best airplane in the world, but if the captain or the pilot doesn\u2019t know where to go, that ship will drift around and is never going to end up anywhere." ~ Arnold Schwarzenegger' },
  /* 0.9.394, Andrea: la frase di Buddha dello screenshot dei suoni per concentrarsi (anche al caricamento e fra le frasi del giorno) */
  { it: '"Dubita di tutto. Trova la tua luce." ~ Buddha', en: '"Doubt everything. Find your own light." ~ Buddha' },
  /* 0.9.397, Andrea: le frasi su sogni, parole e azioni, in tutte e tre le liste (caricamento, suoni per concentrarsi, frasi del giorno).
     Le inglesi sono tradotte dal 0.9.401 (BUG-204); l'autore e' quello verificato, altrimenti Anonimo */
  { it: '"Vi hanno detto di essere realisti. Ma chi sogna in grande cambia il mondo. Chi è realista, di solito, diventa commercialista." ~ Anonimo', en: '"They told you to be realistic. But those who dream big change the world. Those who are realistic usually become accountants." ~ Anonimo' },
  { it: '"Viviamo in un’epoca in cui se dici \'voglio cambiare il mondo\' ti ridono in faccia. E invece dovremmo abituarci a farlo tutti i giorni." ~ Anonimo', en: '"We live in an age when, if you say \'I want to change the world\', people laugh in your face. And yet we should get used to doing it every day." ~ Anonimo' },
  { it: '"Il tuo dovere reale è di salvare il tuo sogno." ~ Amedeo Modigliani', en: '"Your real duty is to save your dream." ~ Amedeo Modigliani' },
  { it: '"Il sogno non è fuori, è dentro di noi. Guardando la Luna per sognare, fuori ne vediamo solo il riflesso." ~ Anonimo', en: '"The dream is not outside, it is within us: when we look at the Moon to dream, outside we only see its reflection." ~ Anonimo' },
  { it: '"Tu sei ciò che fai, non ciò che dici che farai." ~ Anonimo', en: '"You are what you do, not what you say you’ll do." ~ Anonimo' },
  { it: '"Le parole dimostrano chi vuoi essere, le azioni chi sei davvero." ~ Anonimo', en: '"Words show who you want to be; actions show who you really are." ~ Anonimo' },
  { it: '"Quello che pensi diventi, quello che dici attrai, quello che fai ritorna. Niente accade per caso." ~ Anonimo', en: '"What you think, you become; what you say, you attract; what you do comes back to you. Nothing happens by chance." ~ Anonimo' },
  { it: '"Le persone possono dubitare di ciò che dici, ma crederanno a ciò che fai." ~ Charles H. Spurgeon', en: '"Men may doubt what you say, but they will believe what you do." ~ Charles H. Spurgeon' },
  { it: '"Quando non sai più che fare, chiedi aiuto a DreamMap." ~ DreamMap', en: '"When you don’t know what to do anymore, ask DreamMap for help." ~ DreamMap' },
  { it: '"Quando non sai più che fare, lascia fare a Dio." ~ Anonimo', en: '"When you don’t know what to do anymore, let God do it." ~ Anonimo' },
  { it: '"Le azioni mostrano chi sei davvero più delle parole. Ogni azione è una scelta, e ogni scelta è un voto per l’identità che vuoi." ~ Anonimo', en: '"Actions show who you really are more than words. Every action is a choice, and every choice is a vote for the identity you want." ~ Anonimo' },
  { it: '"Quello che fai grida più forte di quello che dici." ~ Anonimo', en: '"What you do shouts louder than what you say." ~ Anonimo' },
  { it: '"Il dialogo interiore conta, ma le tue azioni parleranno sempre più forte delle parole che ti ripeti o che racconti agli altri." ~ Anonimo', en: '"Your inner dialogue matters, but your actions will always speak louder than the words you repeat to yourself or tell others." ~ Anonimo' },
  { it: '"Stai attento ai tuoi pensieri, perché diventeranno le tue parole. Stai attento alle tue parole, perché diventeranno le tue azioni. Stai attento alle tue azioni, perché diventeranno le tue abitudini. Stai attento alle tue abitudini, perché diventeranno il tuo carattere. Stai attento al tuo carattere, perché diventerà il tuo destino." ~ Anonimo', en: '"Watch your thoughts, for they become words. Watch your words, for they become actions. Watch your actions, for they become habits. Watch your habits, for they become character. Watch your character, for it becomes your destiny." ~ Anonimo' },
  { it: '"Dirsi onesti, coraggiosi o affidabili conta poco se i gesti di ogni giorno vanno nella direzione opposta." ~ Anonimo', en: '"Calling yourself honest, brave or reliable counts for little if your everyday actions go the opposite way." ~ Anonimo' },
  { it: '"Le persone si fidano di ciò che ti vedono fare, non di ciò che ti sentono dire." ~ Anonimo', en: '"People trust what they see you do, not what they hear you say." ~ Anonimo' },
  { it: '"L’identità si costruisce agendo. Sono le abitudini e le scelte concrete a definire il carattere." ~ Anonimo', en: '"Identity is built by acting: habits and concrete choices are what define character." ~ Anonimo' },
  { it: '"Allineare parole e comportamenti ti rende credibile, anche quando costa fatica." ~ Anonimo', en: '"Aligning your words and your behaviour makes you credible, even when it takes effort." ~ Anonimo' },
  /* 0.9.401 BUG-204, Andrea: "ogni frase in inglese va tradotta bene". Le sei frasi che restavano in inglese hanno l'italiano; l'originale resta per chi ha il telefono in inglese */
  { it: '"Il tuo peggior nemico non può farti del male quanto i tuoi pensieri, se non li sorvegli." ~ Buddha', en: '"Your worst enemy cannot harm you as much as your own unguarded thoughts." ~ Buddha' },
  { it: '"Scala la montagna per vedere il mondo, non perché il mondo veda te." ~ David McCullough Jr.', en: '"Climb the mountain so you can see the world, not so the world can see you." ~ David McCullough Jr.' },
  { it: '"Preoccupati di quello che pensano gli altri e sarai sempre loro prigioniero." ~ Anonimo', en: '"Care about what other people think and you will always be their prisoner." ~ Anonimo' },
  { it: '"Se vuoi elevare te stesso, eleva qualcun altro." ~ Booker T. Washington', en: '"If you want to lift yourself up, lift up someone else." ~ Booker T. Washington' },
  { it: '"Il nostro potenziale è sconfinato quando abbiamo il coraggio di crederci." ~ Anonimo', en: '"Our potential is boundless when we have the courage to believe in it." ~ Anonimo' },
  { it: '"Se l’occasione non bussa, costruisci una porta." ~ Anonimo', en: '"If opportunity doesn’t knock, build a door." ~ Anonimo' },
  { it: '"La caverna in cui hai paura di entrare custodisce il tesoro che cerchi." ~ Joseph Campbell', en: '"The cave you fear to enter holds the treasure you seek." ~ Joseph Campbell' },
  /* 0.9.401 BUG-204, Andrea: Van Gogh (lo scrive al fratello Theo nel 1884, riprendendo Zola) e la Bhagavad Gita (17,3), in tutte e tre le liste */
  { it: '"Preferisco morire di passione che di noia." ~ Vincent van Gogh', en: '"I would rather die of passion than of boredom." ~ Vincent van Gogh' },
  { it: '"L’uomo è fatto della sua fede. Come crede, così è." ~ Bhagavad Gita', en: '"Man is made by his belief. As he believes, so he is." ~ Bhagavad Gita' },
  /* 0.9.402 BUG-210, Andrea: le due frasi di Denzel Washington, dal discorso ai laureati della Dillard University (New Orleans, 2015).
     La seconda nella traduzione di Andrea; niente due punti (dopo i due punti si va a capo), in tutte e tre le liste */
  { it: '"Non confondere mai il movimento con il progresso, perché puoi correre sul posto e non arrivare da nessuna parte." ~ Denzel Washington', en: '"Never confuse movement with progress, because you can run in place and not get anywhere." ~ Denzel Washington' },
  { it: '"I sogni senza obiettivi sono solo sogni e, alla fine, alimentano la delusione." ~ Denzel Washington', en: '"Dreams without goals are just dreams, and they ultimately fuel disappointment." ~ Denzel Washington' },
  /* 0.9.402 BUG-257, Andrea: le due frasi sul diavolo e sul passato, in tutte e tre le liste (di autore incerto: Anonimo) */
  { it: '"Quando il diavolo ti ricorda il tuo passato, ricordagli il suo futuro." ~ Anonimo', en: '"When the devil reminds you of your past, remind him of his future." ~ Anonimo' },
  { it: '"Se il diavolo ti invita sempre a guardare il tuo passato, ci deve essere qualcosa di meraviglioso nel tuo futuro che non vuole che tu veda." ~ Anonimo', en: '"If the devil is always inviting you to look at your past, there must be something wonderful in your future that he doesn’t want you to see." ~ Anonimo' }
];
function scScelta(x){ return (x && typeof x === 'object') ? ((typeof flTesto === 'function') ? flTesto(x) : (x.it || x.en)) : x; }
const SC_SCELTE_DAL = new Date(2026, 9, 20).getTime();
/* 0.9.397, Andrea: "i giorni passati non devono cambiare frase". Il giro usa la lunghezza della lista (una dopo l'altra
   finche' g < n, poi una ogni sette giorni), quindi ogni frase aggiunta in fondo spostava anche i giorni gia' visti: con le
   25 frasi nuove la pagina della frase del giorno dall'11 al 26 novembre mostrava frasi diverse da quelle di allora.
   Ogni gruppo di frasi ha la sua data di arrivo: prima di quella data il giro usa solo le prime `prima` frasi, cioe' la
   lista com'era. La data e' il primo giorno in cui questo codice gira sul telefono (salvata una volta sola), cosi' anche chi
   aggiorna l'app dopo una settimana vede i giorni passati come li ha visti; senza memoria vale la data scritta qui.
   Per un gruppo nuovo: una riga in piu' qui sotto, con quante frasi c'erano prima e una chiave nuova. */
const SC_SCELTE_ARRIVI = [
  { prima: 22, chiave: 'fl_scelte_arrivo_397', dal: new Date(2026, 10, 27).getTime() },
  /* 0.9.401 BUG-204: Van Gogh e la Bhagavad Gita */
  { prima: 47, chiave: 'fl_scelte_arrivo_401', dal: new Date(2026, 10, 28).getTime() },
  /* 0.9.402 BUG-210: le due frasi di Denzel Washington */
  { prima: 49, chiave: 'fl_scelte_arrivo_402', dal: new Date(2026, 10, 29).getTime() },
  /* 0.9.402 BUG-257: le due frasi sul diavolo e sul passato, con la loro data di arrivo */
  { prima: 51, chiave: 'fl_scelte_arrivo_402b', dal: new Date(2026, 10, 29).getTime() }
];
function scScelteArrivo(l){
  let t = 0;
  try{
    t = +localStorage.getItem(l.chiave) || 0;
    if (!t){ t = scDayStart(0); localStorage.setItem(l.chiave, String(t)); }
  }catch(_){ t = 0; }
  return t || l.dal;
}
/** Quante frasi di SC_SCELTE erano gia' arrivate il giorno che comincia a `inizio`. */
function scScelteQuante(inizio){
  let n = SC_SCELTE.length;
  SC_SCELTE_ARRIVI.forEach(function(l){ if (inizio < scScelteArrivo(l)) n = Math.min(n, l.prima); });
  return n;
}
/** La frase scelta da Andrea per il giorno che comincia a `inizio` (una mezzanotte), o null. */
function scSceltaDelGiorno(inizio){
  const n = scScelteQuante(inizio); if (!n) return null;
  const g = Math.round((inizio - SC_SCELTE_DAL) / SC_DAY_MS);
  if (g < 0) return null;
  if (g < n) return scScelta(SC_SCELTE[g]);
  if (g % 7 === 0) return scScelta(SC_SCELTE[(g / 7) % n]);
  return null;
}
/* 0.9.401 BUG-204: la frase del giorno di oggi (e quella di domani) si segnano nel registro delle frasi (boot.js, flFraseSegna):
   la frase di caricamento, quella dei suoni e le citazioni di START le saltano. Lei non cambia mai: e' la stessa del sito e della
   schermata di blocco. */
function scQuoteFor(q, off){
  const pick = scQuoteForCalc(q, off);
  if (!off && typeof flFraseSegna === 'function'){
    try{
      scFraseSegna(pick, 0);
      const k = scKey(scDayStart(0));
      if (SC.fraseDomani !== k){ SC.fraseDomani = k; scFraseSegna(scQuoteForCalc(q, -1), 1); }
    }catch(_){ }
  }
  return pick;
}
/** Segna nel registro una frase del giorno, in italiano e in inglese se e' una delle frasi scelte da Andrea. */
function scFraseSegna(pick, giorno){
  if (!pick || !pick.text) return;
  const testi = [pick.text];
  SC_SCELTE.forEach(function(x){
    if (!x || typeof x !== 'object') return;
    const it = scSplitQuote(x.it), en = scSplitQuote(x.en);
    if ((it && it.text === pick.text) || (en && en.text === pick.text)){ if (it) testi.push(it.text); if (en) testi.push(en.text); }
  });
  flFraseSegna('giorno', testi, giorno);
}
function scQuoteForCalc(q, off){
  const scelta = scSceltaDelGiorno(scDayStart(off));
  if (scelta) return scSplitQuote(scelta);
  /* Anche OGGI passa dal taglio: se il sito sta mostrando un racconto da millecento caratteri,
     l'app prende la successiva. Preferisco una frase diversa dal sito a una che sulla
     schermata di blocco finisce sotto all'orologio. */
  if (!off && q.today && !scTroppoLunga(q.today)) return scSplitQuote(q.today);
  const list = (q.list || []).map(s => String(s).trim()).filter(Boolean);
  /* Un elenco di una voce sola NON vuol dire «quella frase tutti i giorni»: e' esattamente
     come sono finiti sette giorni di fila con la stessa citazione lunghissima. Si passa da
     scDalGiorno, che con un elenco corto usa la scorta e fa variare i giorni. */
  return scDalGiorno(list.length ? list : [], off);
}

/* ---------------------------------------------------------------------------------------
   PROFILE - the night sky
   --------------------------------------------------------------------------------------- */

function scStars(){
  const host = document.getElementById('profStars');
  if (!host || host.childElementCount) return;
  let html = '';
  for (let i = 0; i < 70; i++){
    const big = i % 5 === 0;
    html += '<i class="star' + (big ? ' big' : '') + '" style="left:' + (Math.random() * 100).toFixed(1) + '%;top:' + (Math.random() * 100).toFixed(1)
      + '%;animation-delay:' + (-Math.random() * 6).toFixed(2) + 's;animation-duration:' + (4 + Math.random() * 5).toFixed(2) + 's"></i>';
  }
  host.innerHTML = html;
}

function scStreak(){
  let up = false, n = 0;
  try{
    if (typeof blkProtectionUp === 'function' && typeof blkStreak === 'function'){
      up = blkProtectionUp();
      if (up || (typeof BLK_QUICK_KNOWN === 'undefined' || BLK_QUICK_KNOWN)) n = blkStreak(up);
    }
  }catch(_){ }
  return { up: up, days: up ? n : 0 };
}

async function scoresRefresh(){
  const host = document.getElementById('profSlides');
  scStars();
  if (typeof flSetBleed === 'function') flSetBleed();
  if (!host) return;
  if (!scHaGiornata()){ host.innerHTML = ''; return; }
  /* 0.9.301: i tre punteggi li misura il telefono (motore-web.js, "I PUNTEGGI RESTANO DEL TELEFONO"). Con i dati del
     computer scelti nel pannello, qui arrivava il rapporto del computer, e se il computer oggi era spento usciva
     "Abilita l'accesso ai dati di utilizzo" con il permesso gia' concesso. 0.9.302: la stessa lettura vale per la
     pagina del dettaglio e per le medie (scReportPunteggi). */
  const r = await scReportPunteggi(0);
  /* una lettura fallita (il motore occupato) non e' un permesso negato: si riprova fra poco */
  if (!r){ if (!scoresRefresh._riprova) scoresRefresh._riprova = setTimeout(function(){ scoresRefresh._riprova = 0; scoresRefresh(); }, 2000); return; }
  if (!r.granted){
    host.innerHTML = r.senzaDati
      ? (scPcScollegato()
        ? '<div class="sc-grant" onclick="scPcAccedi()"><b>Il tuo punteggio del giorno</b><small>Il computer non è più collegato al tuo account, quindi non riceve i punteggi del telefono. Tocca qui per accedere con Google.</small></div>'
        : '<div class="sc-grant"><b>Il tuo punteggio del giorno</b><small>Lo misura il telefono:<br>oggi non ha ancora mandato i suoi dati.</small></div>')
      : '<div class="sc-grant" onclick="openPerm(\'usage\')"><b>Il tuo punteggio del giorno</b><small>Abilita l\'accesso ai dati di utilizzo per vederlo.</small></div>';
    return;
  }
  host.innerHTML = scSkyHtml(scCompute(r));
  scAnimateArcs(host);
}

function scSkyHtml(sc){
  const v = x => (x === null || x === undefined) ? '\u2014' : x;
  const pill = (k, ico, label) =>
    '<div class="bs-pill" onclick="scOpen(\'' + k + '\')"><div class="cap">'
    + '<svg class="arc"><path data-pct="' + (sc[k] === null || sc[k] === undefined ? 0 : sc[k]) + '"/></svg>'
    + '<span class="ic">' + ico + '</span><b>' + v(sc[k]) + '</b></div><small>' + label + '</small></div>';
  return '<div class="bh-scorebox prof-scorebox">'
    + '<div class="bh-sc-total" onclick="scOpen(\'total\')"><small>PUNTEGGIO</small>'
    +   '<b>' + v(sc.total) + '<span class="caret">\u25be</span></b></div>'
    + '<div class="bh-bracket"><i></i><i></i><i></i></div>'
    + '<div class="bh-row">' + pill('sleep', '\uD83C\uDF19', 'Sonno') + pill('focus', '\u23F3', 'Focus') + pill('rest', '\uD83C\uDF32', 'Riposo') + '</div>'
    + '</div>';
}

/* I record personali: aggiornati qui, mostrati SOLO dentro ai due tooltip. Una riga in più
   nel cielo era una riga in più da leggere; il record è una cosa che si va a cercare. */
function scRecords(focusH, streakDays){
  let rec = null; try{ rec = JSON.parse(localStorage.getItem('fl_records') || 'null'); }catch(_){ }
  rec = rec || { focusH: 0, streak: 0 };
  if (focusH > rec.focusH || streakDays > rec.streak){
    rec = { focusH: Math.max(rec.focusH, focusH), streak: Math.max(rec.streak, streakDays) };
    try{ localStorage.setItem('fl_records', JSON.stringify(rec)); }catch(_){ }
  }
  return rec;
}
/* Quante volte hai ascoltato il mantra, e da quanti giorni di fila: lo conta il servizio
   (MantraLog), perché il gesto avviene sulla card a schermo, non dentro all'app. */
let SC_MANTRA = { days: 0, total: 0, today: false, best: 0, bestDay: 0, todayN: 0 };
async function scMantraLoad(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getMantraLog) return SC_MANTRA;
  try{
    const r = await NATIVE.getMantraLog();
    SC_MANTRA = { days: (r && r.days) || 0, total: (r && r.total) || 0, today: !!(r && r.today),
                  best: (r && r.best) || 0, bestDay: (r && r.bestDay) || 0, todayN: (r && r.todayN) || 0 };
  }catch(_){ }
  return SC_MANTRA;
}
function scFocusHtml(sc, streak){
  const focusH = sc && sc.spanMs > 0 ? Math.floor(sc.offlineMs / SC_H) : 0;
  // I giorni di blocco stanno già in fondo alla scheda ("Il primo passo"): qui in cielo vale
  // di più la costanza del mantra, che è l'unica cosa che si sceglie di fare ogni giorno.
  const days = SC_MANTRA.days;
  const rec = scRecords(focusH, days);
  const cmp = '<button type="button" class="sc-tipbtn" onclick="scTipHide();if(typeof frOpen===\'function\')frOpen()">Confronta con gli amici</button>';
  const t1 = 'Le ore di oggi passate da sveglio senza toccare il telefono. Dal primo sblocco della mattina a adesso, tolto il tempo di schermo.\n\nIl tuo record: ' + rec.focusH + (rec.focusH === 1 ? ' ora' : ' ore') + '.';
  /* IL RECORD, ACCANTO ALLA STRISCIA. La striscia viva dice come stai andando adesso; il
     record dice di cosa sei stato capace — ed e' l'unica frase che serve il giorno dopo averne
     persa una lunga. Sono due numeri diversi, e vanno detti tutti e due. */
  const recStreak = Math.max(rec.streak, SC_MANTRA.best);
  const t2 = 'Giorni di fila in cui hai ascoltato il tuo mantra, toccando il play sulla card che compare a schermo. Ogni ascolto vale molti punti.'
    + '\n\nIn tutto: ' + SC_MANTRA.total + (SC_MANTRA.total === 1 ? ' ascolto' : ' ascolti') + '.'
    + '\nRecord di giorni di fila: ' + recStreak + (recStreak === 1 ? ' giorno' : ' giorni') + '.'
    + (SC_MANTRA.bestDay ? '\nRecord di ascolti in un giorno solo: ' + SC_MANTRA.bestDay + '.' : '')
    + (SC_MANTRA.todayN ? '\nOggi: ' + SC_MANTRA.todayN + (SC_MANTRA.todayN === 1 ? ' ascolto' : ' ascolti') + '.' : '')
    + (SC_MANTRA.today ? '' : '\n\nOggi non l\'hai ancora ascoltato.');
  return '<div class="pf-stat sev-rise" style="--d:.62s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t1)) + ', ' + esc(JSON.stringify(cmp)) + ')">'
    +   '<span class="ico glow-mint">⏳</span><b class="num mint">' + focusH + '</b><small>ORE DI FOCUS<i class="q">i</i></small></div>'
    + '<div class="pf-stat sev-rise" style="--d:.78s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t2)) + ', ' + esc(JSON.stringify(cmp)) + ')">'
    +   '<span class="ico glow-fire">🔥</span><b class="num gold">' + days + '</b><small>MANTRA DI FILA<i class="q">i</i></small></div>';
}
/* Letter by letter, with the blinking caret of the website; at the end the button appears. */
function scTypeQuote(){
  const el = document.getElementById('bhQuote');
  if (!el || SC.typing) return;
  const text = el.dataset.text || '';
  if (!text) return;
  SC.typing = true;
  // Hold the slideshow while the letters appear: the section rotates every 7 seconds and a
  // phrase cut in half mid-word is worse than no animation at all.
  try{ if (typeof FL_HEROES !== 'undefined' && FL_HEROES.blocco) FL_HEROES.blocco.held = Date.now(); }catch(_){ }
  el.innerHTML = '';
  /* Il suono della macchina da scrivere, lo stesso della pagina Wishlist del sito: la frase
     del giorno si animava in silenzio, e un'animazione muta sembra un rendering lento. */
  if (typeof itTypeSound === 'function') itTypeSound(true);
  el.classList.toggle('long', text.length > 105);
  // Exactly the site's karaoke (wishlist.js): the letters are ADDED one at a time in front
  // of the caret, so the caret is always right after the last letter. The first version put
  // every letter in place invisible and only revealed them: the caret sat at the end of the
  // whole phrase from the first frame, waiting.
  const chars = Array.from(text);
  const cur = document.createElement('span'); cur.className = 'typewriter-cursor'; cur.textContent = '|';
  el.appendChild(cur);
  let i = 0;
  const step = function(){
    if (!document.body.contains(el)){ SC.typing = false; if (typeof itTypeSound === 'function') itTypeSound(false); return; }
    if (i < chars.length){
      const sp = document.createElement('span'); sp.className = 'typewriter-char visible'; sp.textContent = chars[i++];
      el.insertBefore(sp, cur);
      if ((i & 7) === 0) scHeroFit();
      setTimeout(step, 55);
      return;
    }
    SC.typing = false; SC.typed = true;
    if (typeof itTypeSound === 'function') itTypeSound(false);
    setTimeout(function(){ cur.remove(); }, 1600);
    scShowDetails();
  };
  step();
}
function scQuotePreview(text){
  const el = document.getElementById('bhQuote');
  if (!el) return;
  /* Dieci caratteri tagliavano a meta' della prima parola e l'anteprima non diceva niente.
     Sessanta sono una riga e mezza: abbastanza per capire di che parla, non abbastanza per
     togliere il gusto di aprirla. */
  /* 0.9.381, Andrea: "a differenza del mio tema non voglio il pulsante Scopri di piu': il testo si anima da solo, a macchina da scrivere,
     quando l'utente arriva su quella slide". Finche' la slide non e' davanti resta vuoto (il pannello nero con il bagliore e' gia' li') */
  void text;
  el.innerHTML = '<span class="typewriter-cursor">|</span>';
  scHeroFit();
}
document.addEventListener('fl:slide', function(e){
  const d = e.detail || {};
  if (d.key !== 'rotta') return;
  const el = document.getElementById('bhQuote');
  const sl = el && el.closest ? el.closest('.bh-slide') : null;
  const qui = sl && String(sl.getAttribute('data-i')) === String(d.i);
  if (!qui){ scHeroFit(true); return; }
  if (!el || !el.dataset.text) return;
  if (SC.typed){ el.textContent = el.dataset.text; scShowDetails(); scHeroFit(); }
  else setTimeout(function(){ try{ scTypeQuote(); }catch(_){ } }, 350);
});
function scShowDetails(){
  const b = document.getElementById('bhQuoteBtn');
  if (b){ b.hidden = false; b.classList.add('bh-cta--glow'); b.classList.add('bh-q-in'); }
  scHeroFit();
  try{ if (typeof nvHeroPareggia === 'function') setTimeout(nvHeroPareggia, 600); }catch(_){ }
}
/* La slide si allunga con la frase, come il riquadro della pagina Wishlist: il pulsante
   "Vedi dettagli" finiva sopra alle tre lineette perche' l'altezza era fissa a 340. */
function scHeroFit(reset){
  const host = document.getElementById('blkHero');
  if (!host) return;
  if (reset){ host.style.setProperty('--bh-h', '340px'); return; }
  const box = host.querySelector('.bh-slide[data-i="2"] .bh-quote');
  let need = 0;
  if (box){
  /* Si misura il CONTENUTO, non il contenitore: .bh-quote e' assoluto e alto quanto la
     pista, quindi il suo scrollHeight e' sempre almeno l'altezza corrente — misurarlo e
     aggiungerci otto pixel faceva crescere la slide a ogni lettera, fino a 3600px. */
  const cs = getComputedStyle(box);
  need = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
  Array.prototype.forEach.call(box.children, function(k){
    if (k.hidden) return;
    const ks = getComputedStyle(k);
    need += k.offsetHeight + (parseFloat(ks.marginTop) || 0) + (parseFloat(ks.marginBottom) || 0);
  });
  }
  /* 0.9.367, Andrea: "le due barre sottili delle slide si sovrappongono a notti nella scatola e serie piu' lunga: non deve
     mai succedere". Ogni slide col testo centrato (la Focus Box) conta: il suo contenuto piu' lo spazio sotto, fino a
     sopra alle lineette (che stanno a 64px dal fondo) con 24px di margine */
  let altre = 0;
  try{
    host.querySelectorAll('.bh-slide.fb-slide .fb-slide-pan').forEach(function(p){
      if (!p.offsetHeight) return;
      altre = Math.max(altre, p.offsetHeight + 62 + 64 + 3 + 24);   /* 0.9.368: 62px sopra, sotto alla matita in alto a destra */
    });
  }catch(_){ }
  host.style.setProperty('--bh-h', Math.max(340, Math.ceil(need), Math.ceil(altre)) + 'px');
}

/* ---------------------------------------------------------------------------------------
   PROFILE - the report under the screen time
   --------------------------------------------------------------------------------------- */

/* The three quantities the panel can show. The choice is remembered: the panel is the first
   thing on the Blocco tab and should open on what the person looked at last. */
/* La quinta voce e' la riserva di dopamina: qui SOLO la giornata di oggi. Il confronto fra
   settimana e mese vive nella scheda Profilo — qui si entra per sapere come si sta adesso. */
const SC_METRICS = [['screen', FL_ICO_SCHERMO + ' Tempo di schermo'], ['launch', '🚀 Avvii dell\'app'], ['web', '🌐 Tempo di navigazione'], ['notif', '🔔 Notifiche'], ['dopa', '🧠 Riserva di dopamina']];
function scRepMetric(){
  if (!SC.metric){ try{ SC.metric = localStorage.getItem('fl_rep_metric') || 'screen'; }catch(_){ SC.metric = 'screen'; } }
  if (!SC_METRICS.some(x => x[0] === SC.metric)) SC.metric = 'screen';
  return SC.metric;
}
function scRepSetMetric(m){
  SC.metric = m;
  try{ localStorage.setItem('fl_rep_metric', m); }catch(_){ }
  document.querySelectorAll('#blkReport .rep-metrics button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  scBlockScores();
}
/* The choice now lives inside the panel, behind the three dots in its corner: the row of
   pills above it was one more strip between the sky and the number. */
function scRepMetricsHtml(){ return ''; }
/* 0.9.302: LO STESSO PANNELLO IN DUE POSTI. Il pannello di "Proteggi i tuoi sogni" (dove 'blk') e la sua copia nella
   rivelazione della revisione e del Rientra in rotta (dove 'cv', conversa.js) escono dalla stessa funzione
   (scPannelloHtml): stessi dati, stessa sorgente, stessi tre puntini. La metrica e il dispositivo sono una scelta
   sola per tutti e due; il periodo della copia e' quello della revisione (oggi, la settimana...). Gli id dei menu
   hanno un prefisso per pannello, cosi' i tre puntini aprono il menu del pannello toccato e non quello dell'altro. */
function scVista(v){ return v || { metric: scRepMetric(), range: scRepRange(), dove: 'blk' }; }
function scMenuId(base, v){ return (v && v.dove === 'cv') ? 'cv' + base.charAt(0).toUpperCase() + base.slice(1) : base; }
function scRepMenuHtml(v){
  v = scVista(v);
  const m = scRepMetric();
  const dove = v.dove === 'cv' ? ',\'cv\'' : '';
  return '<div class="rep-scrim" id="' + scMenuId('repScrim', v) + '" hidden onclick="scMenusClose()"></div>'
    + '<button type="button" class="rep-more" onclick="scRepMenuToggle(event' + dove + ')" aria-label="Cosa mostrare">⋯</button>'
    + '<div class="rep-menu" id="' + scMenuId('repMenu', v) + '" hidden>' + SC_METRICS.map(x =>
      '<button type="button"' + (x[0] === m ? ' class="on"' : '') + ' onclick="scRepSetMetric(\'' + x[0] + '\')">' + x[1] + '</button>').join('')
      /* DA DOVE ARRIVANO QUESTI NUMERI. La voce compare solo a chi ha davvero i due
         dispositivi collegati allo stesso account: a tutti gli altri sarebbe una domanda
         senza risposte. */
      /* 0.9.280, Andrea: le due levette (tempo dietro al blocco schermo, Maps e Waze) stanno nelle impostazioni del Report */
      + ((typeof mwMenuHtml === 'function') ? mwMenuHtml() : '') + '</div>';
}
/* Il periodo. Oggi, ieri, sette giorni, il mese, l'anno, da sempre: il confronto che serve
   e' con ieri e con la propria storia, non con un semestre. */
const SC_RANGES = [['today', 'Oggi'], ['yesterday', 'Ieri'], ['7d', 'Ultimi 7 giorni'], ['30d', 'Ultimo mese'], ['365d', 'Ultimo anno'], ['all', 'Da sempre']];
function scRepRange(){
  if (!SC.range){ try{ SC.range = localStorage.getItem('fl_rep_range') || 'today'; }catch(_){ SC.range = 'today'; } }
  if (!SC_RANGES.some(x => x[0] === SC.range)) SC.range = 'today';
  return SC.range;
}
function scRepSetRange(r){
  SC.range = r;
  try{ localStorage.setItem('fl_rep_range', r); }catch(_){ }
  scBlockScores();
}
/* from/to della finestra, la finestra precedente per il confronto, e la grana delle barre. */
function scRangeWindow(r){
  const now = Date.now(), d0 = scDayStart(0);
  if (r === 'yesterday') return { from: scDayStart(1), to: d0, pfrom: scDayStart(2), pto: scDayStart(1), bucket: 'hour', label: 'ieri', vs: 'l\'altro ieri' };
  if (r === '7d') return { from: scDayStart(6), to: now, pfrom: scDayStart(13), pto: scDayStart(6), bucket: 'day', label: 'negli ultimi 7 giorni', vs: 'la settimana prima' };
  if (r === '30d') return { from: scDayStart(29), to: now, pfrom: scDayStart(59), pto: scDayStart(29), bucket: 'day', label: 'nell\'ultimo mese', vs: 'il mese prima' };
  if (r === '365d') return { from: scDayStart(364), to: now, pfrom: scDayStart(729), pto: scDayStart(364), bucket: 'day', months: true, label: 'nell\'ultimo anno', vs: 'l\'anno prima' };
  /* 0.9.302: il periodo della revisione del trimestre (la copia del pannello in conversa.js) */
  if (r === '90d') return { from: scDayStart(89), to: now, pfrom: scDayStart(179), pto: scDayStart(89), bucket: 'day', label: 'negli ultimi tre mesi', vs: 'i tre mesi prima' };
  if (r === 'all') return { from: scDayStart(399), to: now, pfrom: 0, pto: 0, bucket: 'day', months: true, label: 'da sempre', vs: '' };
  return { from: d0, to: now, pfrom: scDayStart(1), pto: d0, bucket: 'hour', label: 'oggi', vs: 'ieri' };
}
/* L'intestazione del pannello E il selettore del periodo sono la stessa cosa.
   Prima erano due: una scritta al centro che diceva "di oggi", e un pulsantino in alto a
   sinistra che diceva la stessa parola occupando un angolo. Ne basta uno, e sta dove si
   guarda per primo. */
function scRangeBtn(label, v){
  v = scVista(v);
  const r = v.range;
  /* la copia del pannello nella revisione del trimestre parte dagli ultimi tre mesi: la voce c'e' solo li' */
  const voci = r === '90d' ? SC_RANGES.slice(0, 4).concat([['90d', 'Ultimi tre mesi']], SC_RANGES.slice(4)) : SC_RANGES;
  const cur = (voci.filter(x => x[0] === r)[0] || voci[0])[1];
  const cv = v.dove === 'cv';
  /* 0.9.400 BUG-176, Andrea: "Ultimi 7 giorni sta sulla riga del titolo Tempo al computer e quasi tocca i tre puntini". Il titolo su una
     riga sua (che va a capo prima di arrivare al pulsante \u22ef), il periodo sotto, sottolineato a puntini con la freccina: si capisce che
     e' un menu a tendina. Vale per tutte le varianti (tempo di schermo, computer, avvii, notifiche, navigazione) */
  return '<button type="button" class="rep-rangebtn" onclick="scRangeMenuToggle(event' + (cv ? ',\'cv\'' : '') + ')" aria-label="' + esc(String(label).replace(/<[^>]*>/g, '')) + ', ' + cur + ': cambia il periodo">'
    + '<b class="rep-rb-t">' + label + '</b><span class="rep-rb-p">' + cur + '<i></i></span></button>'
    + '<div class="rep-menu rep-rangemenu" id="' + scMenuId('repRangeMenu', v) + '" hidden>' + voci.map(x =>
      '<button type="button"' + (x[0] === r ? ' class="on"' : '') + ' onclick="' + (cv ? 'cvPanPeriodo' : 'scRepSetRange') + '(\'' + x[0] + '\')">' + x[1] + '</button>').join('') + '</div>';
}
function scRangeMenuHtml(){
  const r = scRepRange();
  const cur = (SC_RANGES.filter(x => x[0] === r)[0] || SC_RANGES[0])[1];
  return '<button type="button" class="rep-range" onclick="scRangeMenuToggle(event)">' + cur + ' <i></i></button>'
    + '<div class="rep-menu rep-rangemenu" id="repRangeMenu" hidden>' + SC_RANGES.map(x =>
      '<button type="button"' + (x[0] === r ? ' class="on"' : '') + ' onclick="scRepSetRange(\'' + x[0] + '\')">' + x[1] + '</button>').join('') + '</div>';
}

/* ---- il grafico a barre: le ore del giorno, o i giorni, o i mesi ----
   Lo stesso disegno dell'app di riferimento: barre chiare, righe di griglia con i valori a
   destra, le etichette dell'asse sotto, e la barra dell'ora corrente segnata. */
function scChartHtml(buckets, win, fmt, tocco, storia){
  if (!buckets || !buckets.length) return '';
  /* 0.9.299: nel grafico di oggi del pannello "Dove va la tua attenzione?" un'ora si tocca (scOraTap) */
  /* 0.9.400 BUG-174: nel tempo di schermo una barra (un'ora o un giorno) apre la storia di quel pezzo di giornata (scBarStoria): le
     attivita' vere, una per pagina. Le altre metriche (avvii, notifiche, navigazione) tengono il filtro dell'ora */
  const conStoria = !!storia && !win.months;
  if (conStoria){ SC.stoBuckets = buckets; SC.stoWin = win; }
  /* 0.9.401 BUG-184: la giornata delle barre si legge adesso, non al tocco (stoPrecarica): la storia di una barra si apre subito */
  if (conStoria){ try{ stoPrecaricaPresto(win, win.bucket === 'day'); }catch(_){ } }
  const conTocco = !!tocco && !conStoria && win.bucket === 'hour';
  if (conTocco) SC.oggiBuckets = buckets;
  const oraSel = conTocco && scOraAttiva() ? SC.oraSel : -1;
  if (conTocco){ try{ scOraPrecarica(buckets); }catch(_){ } }
  let bars = buckets.map(b => ({ t: b.start, v: b.v || 0 }));
  let labels = [];
  if (win.bucket === 'hour'){
    labels = bars.map((b, i) => (i % 6 === 0 ? ('0' + new Date(b.t).getHours()).slice(-2) + ':00' : ''));
  } else if (win.months){
    const byM = {};
    bars.forEach(b => { const d = new Date(b.t); const k = d.getFullYear() * 100 + d.getMonth(); byM[k] = byM[k] || { t: b.t, v: 0 }; byM[k].v += b.v; });
    bars = Object.keys(byM).sort().map(k => byM[k]);
    labels = bars.map(b => 'GFMAMGLASOND'.charAt(new Date(b.t).getMonth()));
  } else if (bars.length <= 7){
    labels = bars.map(b => 'DLMMGVS'.charAt(new Date(b.t).getDay()));
  } else {
    labels = bars.map((b, i) => (i % 5 === 0 ? String(new Date(b.t).getDate()) : ''));
  }
  const max = Math.max(1, Math.max.apply(null, bars.map(b => b.v)));
  const nowT = Date.now();
  const step = win.bucket === 'hour' ? 3600000 : 86400000;
  const grid = [1, .66, .33].map(k => '<i class="g" style="bottom:' + Math.round(k * 100) + '%"><span>' + fmt(max * k) + '</span></i>').join('');
  return '<div class="rp-chart" onclick="scGraficoTap(event)">'
    + '<div class="rp-bars' + (oraSel >= 0 ? ' con-sel' : '') + '">' + grid + bars.map((b, i) => {
        const h = Math.max(b.v > 0 ? 3 : 1, Math.round(b.v / max * 100));
        const now = !win.months && nowT >= b.t && nowT < b.t + step;
        return '<b class="' + (now ? 'now' : '') + (i === oraSel ? ' sel' : '') + '" style="height:' + h + '%"'
          + (conTocco ? ' onclick="scOraTap(event,' + i + ')"' : '') + (conStoria && b.v > 0 ? ' onclick="scBarStoria(event,' + i + ')"' : '') + '></b>';
      }).join('') + '</div>'
    + '<div class="rp-axis">' + labels.map(l => '<span>' + l + '</span>').join('') + '</div>'
    + '</div>';
}
function scFmtCount(v){ return String(Math.round(v)); }
/* il tocco su una barra del grafico di oggi: quell'ora in evidenza, le altre sbiadite; lo stesso tocco la toglie */
/* 0.9.300, Andrea: "scegliendo dai tre puntini le app, la navigazione o le notifiche non si puo' piu' filtrare ora per
   ora". Ogni metrica di oggi si filtra per ora: avvii, navigazione e notifiche leggono la loro ora con la stessa
   lettura del pannello, ristretta a quell'ora. La selezione vale solo per la metrica in cui e' stata fatta. */
function scOraAttiva(){ return SC.oraSel != null && SC.oraDay === scDayStart(0) && SC.oraMetric === scRepMetric(); }
function scOraVia(){ SC.oraSel = null; SC.oraApps = null; SC.oraRighe = null; SC.oraMetric = null; }
/* 0.9.401 BUG-184, Andrea: "toccando la barra di una fascia oraria i dati di quella fascia ci mettono troppo ad aggiornarsi". Il tocco
   aspettava due cose in fila: le app di quell'ora chieste al motore, e poi TUTTO il pannello riletto da capo (scBlockScores: il rapporto
   del giorno, il grafico, il confronto con ieri), cioe' quattro o cinque domande al motore per accendere una barra. Adesso:
   - la barra si accende SUBITO, prima di qualunque lettura (scOraAccendi);
   - le app di ogni ora si tengono da parte (SC_ORA_MEM: un'ora passata non cambia piu', quella in corso vale un minuto), e le ore piu'
     recenti si leggono appena il grafico compare (scOraPrecarica), cosi' di solito al tocco sono gia' pronte;
   - il pannello si ridisegna con i numeri che ha gia' letto (SC.soloRidisegno, scPannelloHtml), senza richiederli al motore. */
const SC_ORA_MEM = {};
function scOraChiave(metric, b){ return metric + '|' + b.start; }
function scOraPronte(metric, b){
  const e = SC_ORA_MEM[scOraChiave(metric, b)];
  if (!e || !e.righe) return null;
  const finita = b.start + 3600000 <= e.t;
  return (finita || Date.now() - e.t < 60000) ? e.righe : null;
}
function scOraLeggi(metric, b){
  const k = scOraChiave(metric, b), e = SC_ORA_MEM[k];
  const pronte = scOraPronte(metric, b);
  if (pronte) return Promise.resolve(pronte);
  if (e && e.pr) return e.pr;
  const da = b.start, a = Math.min(Date.now(), b.start + 3600000);
  const pr = (async function(){
    let righe = [];
    try{
      if (metric === 'launch') righe = ((await NATIVE.getTopApps({ from: da, to: a, limit: 5, by: 'launches', icons: 5 })) || {}).apps || [];
      else if (metric === 'web') righe = ((await NATIVE.getWebTime({ from: da, to: a, bucket: 'none', limit: 5 })) || {}).sites || [];
      else if (metric === 'notif') righe = ((await NATIVE.getNotifications({ from: da, to: a, limit: 5 })) || {}).apps || [];
      else righe = ((await NATIVE.getTopApps({ from: da, to: a, limit: 9, by: 'ms', icons: 12 })) || {}).apps || [];
    }catch(_){ righe = null; }
    if (righe) SC_ORA_MEM[k] = { t: Date.now(), righe: righe }; else delete SC_ORA_MEM[k];
    return righe || [];
  })();
  SC_ORA_MEM[k] = { pr: pr };
  return pr;
}
/** Le ultime ore con qualcosa dentro, lette in fila appena il grafico di oggi compare (le piu' recenti prima). */
function scOraPrecarica(buckets){
  clearTimeout(SC.oraPreT);
  const metric = scRepMetric();
  SC.oraPreT = setTimeout(async function(){
    const l = (buckets || []).filter(function(b){ return b && b.v > 0 && !scOraPronte(metric, b); }).slice(-6).reverse();
    for (let i = 0; i < l.length; i++){ if (scRepMetric() !== metric) return; try{ await scOraLeggi(metric, l[i]); }catch(_){ } }
  }, 900);
}
/** La barra toccata si accende subito, le altre si spengono: prima ancora di leggere le app di quell'ora. */
function scOraAccendi(i){
  try{
    document.querySelectorAll('#blkReport .rp-bars').forEach(function(r){
      const bb = r.querySelectorAll('b'); if (!bb[i]) return;
      r.classList.add('con-sel'); bb.forEach(function(x, k){ x.classList.toggle('sel', k === i); });
    });
  }catch(_){ }
}
async function scOraTap(ev, i){
  try{ if (ev) ev.stopPropagation(); }catch(_){ }
  const b = (SC.oggiBuckets || [])[i];
  if (!b) return;
  const metric = scRepMetric();
  if (SC.oraSel === i && scOraAttiva()){ scOraVia(); }
  else {
    if (!(b.v > 0)) return;
    try{ if (typeof flVibra === 'function') flVibra([8]); }catch(_){ }
    let righe = scOraPronte(metric, b);
    if (!righe){ scOraAccendi(i); righe = await scOraLeggi(metric, b); }
    if (scRepMetric() !== metric) return;
    SC.oraSel = i; SC.oraDay = scDayStart(0); SC.oraMetric = metric; SC.oraRighe = righe;
    SC.oraApps = metric === 'screen' ? righe : null;
  }
  SC.soloRidisegno = true;
  try{ await scBlockScores(); }catch(_){ }
}
/* "Toccando fuori dalla barra deve tornare a mostrare tutto": un tocco in qualunque altro punto toglie il filtro.
   Il tocco sulle barre si ferma in scOraTap (stopPropagation) e non arriva fin qui. */
document.addEventListener('click', function(e){
  if (typeof SC === 'undefined' || SC.oraSel == null) return;
  /* i menu del pannello (tre puntini, periodo) si aprono senza togliere il filtro: ridisegnare li chiuderebbe */
  try{ if (e && e.target && e.target.closest && e.target.closest('.rep-more,.rep-rangebtn,.rep-menu,.rep-scrim')) return; }catch(_){ }
  scOraVia();
  SC.soloRidisegno = true;
  try{ scBlockScores(); }catch(_){ }
});
document.addEventListener('fl:tab', function(){ if (typeof SC !== 'undefined') scOraVia(); });
/* la fascia scritta come nel Report: "13:00 - 14:00" */
function scOraFascia(start){
  const hh = new Date(start).getHours();
  return String(hh).padStart(2, '0') + ':00 - ' + String((hh + 1) % 24).padStart(2, '0') + ':00';
}
function scFmtMin(ms){ const m = Math.round(ms / 60000); return m >= 60 ? Math.floor(m / 60) + 'h' : m + 'm'; }

/* Un solo motore per i due menu del pannello, con il suo velo.
   Prima ognuno si apriva per conto suo, senza niente dietro: il menu galleggiava sopra alla
   pagina e l'occhio continuava a leggere i numeri sotto invece delle voci. E soprattutto le
   voci stavano DENTRO a .rep-top, che porta al Report: sceglierne una faceva due cose — la
   scelta e il salto di pagina — e si finiva su una schermata che nessuno aveva chiesto. */
/* 0.9.302: i menu del pannello copiato nella rivelazione (conversa.js) hanno il prefisso cv: cvRepMenu, cvRepRangeMenu */
const SC_MENU_COPPIE = { repMenu: 'repRangeMenu', repRangeMenu: 'repMenu', cvRepMenu: 'cvRepRangeMenu', cvRepRangeMenu: 'cvRepMenu' };
function scMenuOpen(id){
  const m = document.getElementById(id);
  if (!m) return;
  const cv = id.indexOf('cv') === 0;
  const other = document.getElementById(SC_MENU_COPPIE[id] || 'repMenu');
  if (other) other.hidden = true;
  const wasOpen = !m.hidden;
  scMenusClose();
  if (wasOpen) return;
  m.hidden = false;
  /* 0.9.280, Andrea: "l'overlay scuro non copre l'intestazione". Velo e menu erano chiusi dentro al
     pannello, sotto all'intestazione: escono nel telefono (come i menu dei tre puntini delle mappe),
     e alla chiusura tornano al loro posto. */
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : null;
  if (casa && typeof flMenuFissa === 'function'){
    const v = document.createElement('div'); v.id = 'repVeil'; v.className = 'arb-veil';
    v.addEventListener('click', function(e){ e.stopPropagation(); scMenusClose(); });
    casa.appendChild(v);
    m._casa = m.parentElement;
    flMenuFissa(m, m._casa && m._casa.querySelector(/RangeMenu$/.test(id) ? '.rep-rangebtn,.rep-range' : '.rep-more'));
  } else {
    const sc = document.getElementById(cv ? 'cvRepScrim' : 'repScrim');
    if (sc){ sc.hidden = false; requestAnimationFrame(function(){ sc.classList.add('in'); }); }
  }
  setTimeout(function(){
    document.addEventListener('click', function once(){ scMenusClose(); document.removeEventListener('click', once); });
  }, 0);
}
function scMenusClose(){
  ['repMenu', 'repRangeMenu', 'cvRepMenu', 'cvRepRangeMenu'].forEach(function(k){ document.querySelectorAll('#' + k).forEach(function(e){
    e.hidden = true;
    if (e.classList.contains('fl-menu-fisso')){
      e.classList.remove('fl-menu-fisso'); e.style.left = ''; e.style.top = '';
      if (e._casa && document.contains(e._casa) && !e._casa.querySelector('#' + k)) e._casa.appendChild(e); else e.remove();
    }
  }); });
  const vv = document.getElementById('repVeil'); if (vv) vv.remove();
  ['repScrim', 'cvRepScrim'].forEach(function(k){ const sc = document.getElementById(k); if (sc){ sc.classList.remove('in'); sc.hidden = true; } });
}
function scRepMenuToggle(ev, dove){ if (ev) ev.stopPropagation(); scMenuOpen(dove === 'cv' ? 'cvRepMenu' : 'repMenu'); }
function scRangeMenuToggle(ev, dove){ if (ev) ev.stopPropagation(); scMenuOpen(dove === 'cv' ? 'cvRepRangeMenu' : 'repRangeMenu'); }
/* Il pannello porta al Report, ma non quando il tocco e' finito su un pulsante o dentro a un
   menu: quelli hanno gia' un loro mestiere. */
/* 0.9.305, Andrea: nel pannello di "Proteggi i tuoi sogni" un tocco sul grafico che NON cade su una barra porta al Report.
   Una barra che ha un suo mestiere (l'ora di oggi: scOraTap) lo fa e ferma il tocco li'. Solo nel pannello vero
   (#blkReport): la copia nella revisione (conversa.js) sta dentro a un racconto che non si interrompe. */
/* 0.9.401 BUG-184, Andrea: "spesso, anche senza volerlo, si apre la pagina Report dal pannello". Un tocco sul grafico cambia il grafico,
   non la pagina (lezione 280): il Report si apre solo quando lo chiedi, alla fine delle storie di "Rivedi la giornata" (stoGiornata). */
function scGraficoTap(ev){ }
/* Il pannello sta nella pagina "Proteggi i tuoi sogni" (s-blocco), fuori dalla Home: switchTab da solo cambiava la
   scheda dietro, e a schermo non succedeva niente. Prima si torna alla Home, poi si apre il Report. */
function scVaiAlReport(){
  try{ if (typeof order !== 'undefined' && order[cur] !== 's-home' && typeof goId === 'function') goId('s-home'); }catch(_){ }
  switchTab('insights');
}
/* 0.9.401 BUG-184: nemmeno il tocco sull'intestazione del pannello porta piu' al Report (vedi scGraficoTap) */
function scTopTap(ev){ }
/* "rispetto a ieri", the same way for every quantity: nothing when yesterday is unknown. */
/* 0.9.302: "rispetto a la settimana prima", "Nessun dato su il mese prima": la preposizione si unisce all'articolo */
function scPrep(p, who){
  /* 0.9.402 BUG-260: anche "di" (della settimana prima, dell'altro ieri, di ieri) per il testo corto del badge */
  if (p === 'di' && !/^(la|il|i|l') ?/.test(who)) return 'di ' + who;
  const a = p === 'su' ? 'su' : (p === 'di' ? 'de' : 'a');
  let m;
  if ((m = /^la (.*)$/.exec(who))) return a + 'lla ' + m[1];
  if ((m = /^il (.*)$/.exec(who))) return a + 'l ' + m[1];
  if ((m = /^l'(.*)$/.exec(who))) return a + "ll'" + m[1];
  if ((m = /^i (.*)$/.exec(who))) return a + 'i ' + m[1];
  return a + ' ' + who;
}
function scDelta(cur, prev, fmt, unit, vs){
  const who = vs || 'ieri';
  if (!who) return '';
  if (prev === null || prev === undefined) return '<span class="rep-badge flat">Nessun dato ' + scPrep('su', who) + '</span>';
  const diff = cur - prev;
  if (Math.abs(diff) < (unit || 1)) return '<span class="rep-badge flat">= come ' + who + '</span>';
  /* 0.9.402 BUG-260: il badge non va mai a capo. Se il testo intero non ci sta, si accorcia ("2h 7min meno dell'altro ieri") e, solo se
     ancora non basta, si rimpicciolisce (scBadgeAdatta, che misura il pannello vero) */
  const fr = (diff > 0 ? '↗ ' : '↘ ') + fmt(Math.abs(diff));
  const corto = fr + (diff > 0 ? ' più ' : ' meno ') + scPrep('di', SC_VS_CORTO[who] || who);
  return '<span class="rep-badge ' + (diff > 0 ? 'up' : 'down') + '" data-corto="' + esc(corto) + '">' + fr + ' rispetto ' + scPrep('a', who) + '</span>';
}
const SC_VS_CORTO = { 'la settimana prima': 'i 7 giorni prima', 'i tre mesi prima': 'i 3 mesi prima' };
/* 0.9.402 BUG-260, Andrea: "il badge verde o rosso del confronto non va mai a capo; se serve, il testo si accorcia" (lezione 360). Si misura
   il badge nel pannello vero: se il testo intero sborda, quello corto (data-corto); se sborda ancora, un carattere piu' piccolo, fino a 10 px */
function scBadgeAdatta(root){
  try{
    (root || document).querySelectorAll('.rep-top .rep-badge').forEach(function(b){
      if (!(b.clientWidth > 0)) return;            /* non ancora a schermo (un pannello nascosto): si misura alla prossima */
      const sborda = function(){ return b.scrollWidth > b.clientWidth + 1; };
      if (b.dataset.lungo && b.textContent !== b.dataset.lungo){ b.textContent = b.dataset.lungo; b.style.fontSize = ''; }
      if (!sborda()) return;
      const c = b.getAttribute('data-corto');
      if (c){ b.dataset.lungo = b.textContent; b.textContent = c; }
      let px = 12;
      while (sborda() && px > 10){ px -= 0.5; b.style.fontSize = px + 'px'; }
    });
  }catch(_){ }
}
function scBadgeAdattaPresto(){
  if (typeof requestAnimationFrame !== 'function') return;
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ scBadgeAdatta(); }); });
  [400, 1200].forEach(function(ms){ setTimeout(function(){ scBadgeAdatta(); }, ms); });
}
if (typeof window !== 'undefined' && window.addEventListener){
  let scBaT = 0;
  window.addEventListener('resize', function(){ clearTimeout(scBaT); scBaT = setTimeout(function(){ scBadgeAdatta(); }, 120); });
  document.addEventListener('fl:tab', function(){ setTimeout(function(){ scBadgeAdatta(); }, 60); });
}
async function scNotifSettings(pkg){
  if (NATIVE && NATIVE.openAppNotificationSettings){
    try{ await NATIVE.openAppNotificationSettings({ packageName: pkg }); return; }catch(_){ }
  }
  scOpenApp(pkg);
}
/* The small arrow inside a card: fewer than yesterday is green, more is red. */
function scMini(cur, prev){
  if (prev === null || prev === undefined || prev === cur) return '';
  return '<em class="' + (cur < prev ? 'down' : 'up') + '">' + (cur < prev ? '↘ ' : '↗ ') + Math.abs(cur - prev) + '</em>';
}
function scReportRow(onclick, icon, name, width, value){
  return '<div class="rep-row"' + (onclick ? ' onclick="' + onclick + '"' : '') + '>' + icon
    + '<div class="nm"><span>' + name + '</span><i class="track"><b style="width:' + Math.max(4, Math.round(width * 100)) + '%"></b></i></div>'
    + '<b class="tm">' + value + '</b></div>';
}

/* `x` carries the figures of the chosen metric when it is not the screen time:
   { cur, prev, rows } — today's total, yesterday's (null when unknown), the top rows. */
function scReportHtml(r, y, x, v){
  v = scVista(v);
  const metric = scRepMetric();
  const win = scRangeWindow(v.range);
  const screen = r.screenMs || 0;
  const yOk = !!(y && y.granted);
  let top, title, rows, empty, chart = '', extra = '';
  if (metric === 'launch' && x){
    const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
    top = scRangeBtn('🚀 Avvii dell\'app', v) + '<b class="rep-big">' + (sel ? (sel.v || 0) : x.cur) + '</b>'
      + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, n => n + (n === 1 ? ' avvio' : ' avvii'), 1, win.vs));
    chart = scChartHtml(x.buckets, win, scFmtCount, true);
    const righeL = sel ? (SC.oraRighe || []) : x.rows;
    const max = righeL.length ? (righeL[0].launches || 1) : 1;
    title = 'Le app che apri più spesso' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
    rows = righeL.slice(0, 5).map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.launches || 0) / max, (a.launches || 0) + (a.launches === 1 ? ' avvio' : ' avvii'))).join('');
    empty = sel ? 'In quest\'ora nessuna app aperta.' : 'Nessuna app aperta, oggi.';
  } else if (metric === 'web' && x){
    const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
    top = scRangeBtn('🌐 Navigazione', v) + '<b class="rep-big">' + scFmtShort(sel ? (sel.v || 0) : x.cur) + '</b>'
      + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, scFmtShort, 60000, win.vs));
    chart = scChartHtml(x.buckets, win, scFmtMin, true);
    const righeW = sel ? (SC.oraRighe || []) : x.rows;
    const max = righeW.length ? (righeW[0].ms || 1) : 1;
    title = 'Dove navighi di più' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
    rows = righeW.slice(0, 5).map(w => scReportRow('',
      (typeof flFavHtml === 'function' ? flFavHtml(w.host, 'big') : '<span class="ico">' + esc(w.host.charAt(0).toUpperCase()) + '</span>'),
      esc(w.host), (w.ms || 0) / max, scFmtShort(w.ms || 0))).join('');
    empty = sel ? 'In quest\'ora nessun sito registrato.' : 'Nessun sito registrato, oggi. Il tempo per sito si misura mentre navighi nei browser supportati.';
  } else if (metric === 'notif' && x){
    if (x.granted === false){
      top = scRangeBtn('🔔 Notifiche', v) + '<b class="rep-big">\u2014</b><span class="rep-badge flat">Serve l\'accesso alle notifiche</span>';
      title = 'Chi ti ha scritto di più'; rows = '';
      empty = '<a href="#" onclick="openPerm(\'notif\');return false">Abilita l\'accesso alle notifiche</a> per contare quante ne arrivano e da quali app.';
    } else {
      const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
      top = scRangeBtn('🔔 Notifiche', v) + '<b class="rep-big">' + (sel ? (sel.v || 0) : x.cur) + '</b>'
        + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, n => n + (n === 1 ? ' notifica' : ' notifiche'), 1, win.vs));
      chart = scChartHtml(x.buckets, win, scFmtCount, true);
      const righeN = sel ? (SC.oraRighe || []) : x.rows;
      const max = righeN.length ? (righeN[0].count || 1) : 1;
      title = 'Chi ti ha scritto di più' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
      /* Toccare l'app porta alla SUA pagina delle notifiche di Android: la lista non e' una
         classifica, e' l'elenco di cosa spegnere. */
      rows = righeN.slice(0, 5).map(a => scReportRow('scNotifSettings(\'' + esc(a.packageName) + '\')',
        a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
        esc(a.label || a.packageName), (a.count || 0) / max, (a.count || 0) + (a.count === 1 ? ' notifica' : ' notifiche'))).join('');
      empty = sel ? 'In quest\'ora nessuna notifica.' : 'Nessuna notifica, oggi.';
    }
  /* 0.9.292, Andrea: "da quando hai messo il grafico di oggi non compare piu' nessun dato su dove va la tua attenzione".
     Il grafico di oggi arrivava in x ({oggi}) e questo ramo, pensato per gli altri periodi, lo prendeva per buono: niente
     righe e "Nessuna app ha superato il minuto". I dati c'erano tutti: oggi le righe tornano da r.top. */
  } else if (metric === 'screen' && x && !x.oggi){
    extra = '';
    const navX = scNavMs(x.rows || []);
    top = scRangeBtn(scTitoloSchermo(), v) + scGrandeGiorni(Math.max(0, x.cur - navX)) + scDelta(Math.max(0, x.cur - navX), x.prev, scFmtShort, 60000, win.vs);
    chart = scChartHtml(x.buckets, win, scFmtMin, false, true);
    const righeS = scRigheAttenzione(x.rows || []);
    const max = righeS.length ? (righeS[0].ms || 1) : 1;
    title = 'Dove va la tua attenzione?';
    rows = righeS.slice(0, 5).map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.ms || 0) / max, scFmtShort(a.ms || 0))).join('');
    empty = 'Nessuna app ha superato il minuto.';
  } else {
    const navT = scNavMs(r.top || []), navY = yOk ? scNavMs(y.top || []) : 0;
    top = scRangeBtn(scTitoloSchermo(), v) + '<b class="rep-big">' + scFmtShort(Math.max(0, screen - navT)) + '</b>' + scDelta(Math.max(0, screen - navT), yOk && (y.screenMs || 0) > 0 ? Math.max(0, y.screenMs - navY) : null, scFmtShort, 60000);
    const apps = scRigheAttenzione(r.top || []);
    const max = apps.length ? apps[0].ms : 1;
    title = 'Dove va la tua attenzione?';
    rows = apps.map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), a.ms / max, scFmtShort(a.ms))).join('');
    empty = 'Nessuna app ha superato il minuto, oggi.';
    /* IL TEMPO DIETRO AL BLOCCO SCHERMO. Una sveglia che suona, una notifica che accende lo
       schermo, un lettore musicale: il telefono porta davanti un'app senza che nessuno la usi.
       Di serie non si conta — altre app di misura lo contano, e i totali non tornano. Qui si
       dice quanto e', e si lascia scegliere. */
    const lk = r.lockedMs || 0, conta = !!r.countLocked;
    /* Il tempo dietro al blocco schermo non si dice piu' qui: si sceglie dal menu ⋯ del
       pannello (di serie non si conta). */
    SC.countLocked = conta; SC.lockedMs = lk;
  }
  const blocks = r.blocks || 0, yb = yOk ? (y.blocks || 0) : null;
  const pickups = r.pickups || 0, yp = yOk ? (y.pickups || 0) : null;
  /* Le due card (bloccato oggi, sblocchi) restano solo sul tempo di schermo di oggi. Per tutto
     il resto al loro posto c'e' il grafico: in quale ora, in quale giorno. */
  const oggiChart = !chart && x && x.oggi && x.oggi.length ? scChartHtml(x.oggi, win, scFmtMin, true, scRepMetric() === 'screen') : '';
  /* L'ORA SCELTA (0.9.299), come nel Report: il numero, il titolo e le app di quell'ora sola */
  if (!chart && x && x.oggi && scOraAttiva() && SC.oraApps && x.oggi[SC.oraSel]){
    const hh = new Date(x.oggi[SC.oraSel].start).getHours();
    const fascia = String(hh).padStart(2, '0') + ':00 - ' + String((hh + 1) % 24).padStart(2, '0') + ':00';
    top = scRangeBtn(FL_ICO_SCHERMO + ' Tempo di schermo', v) + '<b class="rep-big">' + scFmtShort(x.oggi[SC.oraSel].v || 0) + '</b><span class="rep-badge flat">' + fascia + '</span>';
    const appsO = scRigheAttenzione(SC.oraApps);
    const maxO = appsO.length ? (appsO[0].ms || 1) : 1;
    title = 'Dove va la tua attenzione? \u00b7 ' + fascia;
    rows = appsO.map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.ms || 0) / maxO, scFmtShort(a.ms || 0))).join('');
    empty = 'In quest\'ora nessuna app ha superato il minuto.';
  }
  const cards = chart ? chart
    : (oggiChart ? '<div class="rep-solo-prot">' + oggiChart + '</div>' : '')
    + '<div class="rep-cards' + (oggiChart ? ' rep-solo-dream' : '') + '">'
    + '<div class="rep-card"><small>Bloccato oggi<i onclick="scTipAt(this, SC_TIPS.blocked)">i</i></small><b>' + blocks + scMini(blocks, yb) + '</b></div>'
    + '<div class="rep-card"><small>Sblocchi<i onclick="scTipAt(this, SC_TIPS.pickups)">i</i></small><b>' + pickups + scMini(pickups, yp) + '</b></div>'
    + '</div>';
  return '<div class="rep-panel">' + scRepMenuHtml(v)
    + '<div class="rep-top" onclick="scTopTap(event)">' + top + '</div>'
    + cards
    + '<div class="rep-att"><b>' + title + '</b>'
    + (rows || '<p class="hintline" style="padding:6px 0 0">' + empty + '</p>') + '</div>'
    + extra
    /* 0.9.400 BUG-174: in fondo al pannello, la storia di tutta la giornata (solo le attivita' principali) */
    + '<button type="button" class="rep-rivedi" onclick="event.stopPropagation();stoGiornata(' + (v.range === 'yesterday' ? 1 : 0) + ')">'
    +   '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M4 2.5v11l9-5.5z" fill="currentColor"/></svg>Rivedi la giornata</button>'
    + '</div>';
}
/* La scelta vale per tutto: la pillola in cima, la bolla del motore, i punteggi. Le giornate
   gia' lette si buttano, altrimenti ieri resterebbe misurato con l'altra regola. */
async function scLockedToggle(on){
  SC.countLocked = !!on;
  try{ if (typeof settingsSave === 'function') await settingsSave({ usageCountLocked: !!on }); }catch(_){ }
  SC.mem = {};
  Object.keys(SC_MEM_TEL).forEach(function(k){ delete SC_MEM_TEL[k]; });
  try{ Object.keys(localStorage).forEach(function(k){ if (k.indexOf('fl_dayrep_') === 0) localStorage.removeItem(k); }); }catch(_){ }
  try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ }
  try{ if (typeof flHeaderSync === 'function') flHeaderSync(); }catch(_){ }
}
const SC_TIPS = {
  blocked: 'Ogni volta che un\'app o un sito bloccato ha provato ad aprirsi, l\'abbiamo bloccato. Questo è il tuo totale di oggi.',
  pickups: 'Quante volte hai sbloccato il telefono oggi. Più sblocchi di solito significano più occasioni di distrazione.'
};

/* A real tooltip: a dark bubble floating over the page, its arrow on the "i" it explains. */
function scTipAt(anchor, text, extra){
  if (!anchor) return;
  const phone = document.getElementById('phone');
  let tip = document.getElementById('scTip');
  if (!tip){
    tip = document.createElement('div');
    tip.id = 'scTip';
    tip.className = 'sc-tip';
    tip.innerHTML = '<i class="arrow"></i><span class="txt"></span>';
    phone.appendChild(tip);
    document.addEventListener('touchstart', function(ev){ if (tip.style.display === 'block' && !tip.contains(ev.target)) scTipHide(); }, { passive: true });
  }
  clearTimeout(SC.tipTimer);
  SC.held = Date.now();
  if (tip.style.display === 'block' && tip.dataset.for === text){ scTipHide(); return; }
  tip.dataset.for = text;
  const box = tip.querySelector('.txt');
  /* DUE COSE DIVERSE NELLO STESSO FUMETTO: la spiegazione, che e' prosa e si legge da
     sinistra, e i numeri, che si guardano. La riga vuota che gia' li divideva nel testo
     diventa il taglio fra i due blocchi, e i numeri vanno al centro. */
  const pezzi = String(text).split('\n\n');
  box.textContent = pezzi[0];
  if (pezzi.length > 1){
    /* I record sono un ELENCO: a sinistra, un punto davanti a ognuno. Centrati, righe di
       lunghezza diversa fanno uno zig-zag che l'occhio non riesce a scorrere. */
    const ul = document.createElement('ul');
    ul.className = 'dati';
    pezzi.slice(1).join('\n').split('\n').forEach(function(r){
      r = String(r).trim();
      if (!r) return;
      const li = document.createElement('li');
      li.textContent = r;
      ul.appendChild(li);
    });
    box.appendChild(ul);
  }
  if (extra) box.insertAdjacentHTML('beforeend', extra);
  tip.style.display = 'block';
  const pr = phone.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
  const width = Math.min(pr.width - 24, 290);
  tip.style.width = width + 'px';
  let left = ar.left + ar.width / 2 - pr.left - width / 2;
  left = Math.max(12, Math.min(pr.width - width - 12, left));
  tip.style.left = left + 'px';
  tip.style.top = (ar.bottom - pr.top + 10) + 'px';
  tip.querySelector('.arrow').style.left = (ar.left + ar.width / 2 - pr.left - left - 7) + 'px';
  SC.tipTimer = setTimeout(scTipHide, extra ? 12000 : 7000);
}
function scTipHide(){ const t = document.getElementById('scTip'); if (t) t.style.display = 'none'; }
function scOpenApp(pkg){
  /* da dove si arriva (0.9.203): tornando indietro si torna LI', non nel Report */
  try{ const b = document.getElementById('s-blocco'); INS.detailFrom = (b && b.classList.contains('active')) ? 'blocco' : ''; }catch(_){ }
  if (typeof insOpenDetail === 'function'){ INS.dayOff = 0; insOpenDetail(pkg); }
  else switchTab('insights');
}
document.addEventListener('fl:tab', function(e){
  scTipHide();
  if (!e) return;
  if (e.detail === 'profilo') scoresRefresh();
  // Blocco owns the phrase of the day and the screen time; the Profile owns the score.
  if (e.detail === 'blocco'){ scBlockScores(); if (typeof blkHeroReplay === 'function') blkHeroReplay(); }
  // Coming to Modalita severa re-reads the streak and the two figures in its sky.
  if (e.detail === 'severa' && typeof sevSyncTab === 'function') sevSyncTab();
  // The Report closes on what this pace costs over the years that are left.
  if (e.detail === 'severa') setTimeout(scLifePaint, 260);
});

/* ---------------------------------------------------------------------------------------
   BLOCCO TAB - the phrase of the day in the slideshow, the screen time under it
   --------------------------------------------------------------------------------------- */

/** Il pannello quando il dispositivo scelto non ha ancora mandato niente oggi. */
function scSenzaDatiHtml(r, v){
  const pc = r && r.fonte === 'computer';
  const quiPc = typeof mwQuiComputer === 'function' && mwQuiComputer();
  const altro = pc ? !quiPc : quiPc;
  return '<div class="rep-panel rep-senza">' + scRepMenuHtml(v)
    + '<div class="rep-top"><b class="rep-senza-t">' + (pc ? '💻 Il computer' : (r && r.fonte === 'insieme' ? '🔗 Telefono e computer' : '📱 Il telefono')) + '</b>'
    + '<p class="rep-senza-p">' + (altro ? (pc ? 'Oggi il computer non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul computer.' : 'Oggi il telefono non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul telefono.') : 'Oggi non ci sono ancora dati da mostrare.') + '</p>'
    + (pc && !quiPc && typeof mwScegli === 'function' ? '<button type="button" class="rep-senza-b" onclick="mwScegli(\'telefono\')">📱 Mostra i dati del telefono</button>' : '')
    + '</div></div>';
}
async function scBlockScores(){
  if (typeof blkHeroEnsure !== 'function') return;
  blkHeroEnsure();

  // 1. the phrase, into the first slide
  const el = document.getElementById('bhQuote'), au = document.getElementById('bhQuoteAuthor');
  if (el){
    scQuotes().then(function(q){
      const pick = scQuoteFor(q, 0);
      if (!pick) return;
      el.dataset.text = pick.text;
      if (au) au.textContent = '~ ' + pick.author;
      /* Come sulla pagina Wishlist del sito: i primi dieci caratteri e "Scopri di piu'". La
         frase si scrive a macchina — col suo suono — solo quando la si chiede. Prima partiva
         da sola a ogni rotazione delle slide, e il suono di una macchina da scrivere che
         parte mentre stai facendo altro non e' un effetto, e' un disturbo. */
      if (SC.typed){ el.textContent = pick.text; scShowDetails(); }
      else scQuotePreview(pick.text);
      scLockQuoteDaily(q);
    });
  }

  // 2. the screen time, between the sky and the quick block
  const rep = (typeof blkReportEnsure === 'function') ? blkReportEnsure() : null;
  if (!rep) return;
  const out = await scPannelloHtml(scVista());
  /* 0.9.291, Andrea: "entrando in un programma e uscendo sparisce il pannello della panoramica". Salvando un programma
     il motore e' occupato a riscrivere le regole e la lettura del giorno torna vuota: quel vuoto cancellava il
     pannello. Una lettura fallita non e' un "permesso negato": il pannello resta com'era e si riprova fra poco. */
  if (out.riprova){
    if (!scBlockScores._riprova){ scBlockScores._riprova = setTimeout(function(){ scBlockScores._riprova = 0; scBlockScores(); }, 1500); }
    return;
  }
  if (out.annulla) return;   // the person switched again while we were reading
  rep.innerHTML = out.html;
  if (out.dopa){ try{ if (typeof dpVivo === 'function') dpVivo(); }catch(_){ } }
  /* 0.9.302: la copia del pannello nella rivelazione (conversa.js) segue ogni cambio: metrica, dispositivo, ora toccata */
  try{ if (typeof cvPanRidisegna === 'function') cvPanRidisegna(); }catch(_){ }
}

/**
 * IL PANNELLO "DOVE VA LA TUA ATTENZIONE?", per chiunque lo mostri (0.9.302).
 *
 * <p>Prima viveva dentro a scBlockScores e la rivelazione della revisione e del Rientra in rotta (conversa.js) se ne
 * era fatto un altro a mano: niente tre puntini, il titolo "Oggi sul telefono" fisso, e i numeri chiesti al motore
 * senza passare dal rapporto del giorno. Con i dati del computer scelti e il computer che oggi non aveva mandato
 * niente, la copia diceva "0min" e "Nessuna app ha superato il minuto" mentre "Proteggi i tuoi sogni" diceva il vero.
 * Adesso il pannello e' uno: `v` dice solo dove sta (dove), su quale periodo (range) e quale metrica.</p>
 *
 * Torna { html } da mettere a schermo, { riprova } se il motore non ha risposto, { annulla } se nel frattempo la
 * scelta e' cambiata, { negato } se manca il permesso di misura.
 */
async function scPannelloHtml(v){
  v = scVista(v);
  if (!scHaGiornata()) return { html: '' };
  /* 0.9.401 BUG-184: un'ora toccata (o tolta) ridisegna il pannello con i numeri gia' letti, senza richiederli al motore */
  const solo = !!SC.soloRidisegno; SC.soloRidisegno = false;
  const memoK = scRepMetric() + '|' + v.range + '|' + (v.dove || '');
  const memo = SC.panMem && SC.panMem[memoK];
  if (solo && memo && Date.now() - memo.t < 300000 && scRepMetric() !== 'dopa'){ scBadgeAdattaPresto(); return { html: scRepMetricsHtml() + scReportHtml(memo.r, memo.y, memo.x, v) }; }
  let r = await scReport(0);
  if (!r) return { riprova: true };
  /* 0.9.301: il dispositivo scelto oggi non ha dati (il computer spento): il pannello resta, con i tre puntini per
     cambiare sorgente e una frase vera. Prima spariva, e con lui la strada per tornare ai dati del telefono.
     0.9.302: vale per oggi. Sugli altri periodi i giorni passati ci sono (i totali che il computer pubblica). */
  if (!r.granted && r.senzaDati){
    if (v.range === 'today') return { html: scSenzaDatiHtml(r, v) };
    r = { granted: true, dayStart: scDayStart(0), screenMs: 0, top: [], blocks: 0, pickups: 0 };
  }
  if (!r.granted) return { html: '', negato: true };
  const y = await scReport(1);
  // the other two quantities are fetched only when they are the ones on screen
  let x = null;
  const metric = scRepMetric();
  const range = v.range;
  const win = scRangeWindow(range);
  try{
    if (metric === 'launch' && NATIVE.getScreenTimeRange && NATIVE.getTopApps){
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      const b = win.pto ? await NATIVE.getScreenTimeRange({ from: win.pfrom, to: win.pto, bucket: 'none' }) : null;
      const t = await NATIVE.getTopApps({ from: win.from, to: win.to, limit: 5, by: 'launches' });
      x = { cur: a.launches || 0, prev: b && (y && y.granted) ? (b.launches || 0) : null, rows: t.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.launches || 0 })) };
    } else if (metric === 'web' && NATIVE.getWebTime){
      const a = await NATIVE.getWebTime({ from: win.from, to: win.to, bucket: win.bucket, limit: 5 });
      const b = win.pto ? await NATIVE.getWebTime({ from: win.pfrom, to: win.pto, bucket: 'none', limit: 1 }) : null;
      x = { cur: a.ms || 0, prev: b ? (b.ms || 0) : null, rows: a.sites || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    } else if (metric === 'notif' && NATIVE.getNotifications){
      const a = await NATIVE.getNotifications({ from: win.from, to: win.to, bucket: win.bucket, limit: 5 });
      const b = win.pto ? await NATIVE.getNotifications({ from: win.pfrom, to: win.pto, limit: 1 }) : null;
      x = { granted: a.granted !== false, cur: a.total || 0, prev: (a.granted === false || !b) ? null : (b.total || 0), rows: a.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.count || 0 })) };
    } else if (metric === 'screen' && range === 'today' && NATIVE.getScreenTimeRange){
      /* 0.9.290, Andrea: "nella pagina Proteggi i tuoi sogni voglio il grafico anche per oggi; i due pannelli Bloccato
         oggi e Sblocchi restano solo nella panoramica di Dream". Il grafico di oggi si legge sempre: lo stesso pannello
         passa da una pagina all'altra e lo foglio di stile mostra quello giusto. */
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      x = { oggi: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    } else if (metric === 'screen' && range !== 'today' && NATIVE.getScreenTimeRange && NATIVE.getTopApps){
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      const b = win.pto ? await NATIVE.getScreenTimeRange({ from: win.pfrom, to: win.pto, bucket: 'none' }) : null;
      const t = await NATIVE.getTopApps({ from: win.from, to: win.to, limit: 9, by: 'ms' });
      x = { cur: a.ms || 0, prev: b ? (b.ms || 0) : null, rows: t.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    }
  }catch(_){ x = null; }
  if (scRepMetric() !== metric || (v.dove !== 'cv' && scRepRange() !== range)) return { annulla: true };
  if (metric === 'dopa' && typeof dpCardHtml === 'function'){
    let d = null;
    try{ d = await dpCalcola(); }catch(_){ d = null; }
    if (scRepMetric() !== 'dopa') return { annulla: true };
    return { html: '<div class="rep-panel rep-dopa">' + scRepMenuHtml(v) + dpCardHtml(d, 'panoramica', 'giorno') + '</div>', dopa: true };
  }
  SC.panMem = SC.panMem || {}; SC.panMem[memoK] = { t: Date.now(), r: r, y: y, x: x };
  scBadgeAdattaPresto();   /* 0.9.402 BUG-260: il badge del confronto si misura appena il pannello e' a schermo */
  return { html: scRepMetricsHtml() + scReportHtml(r, y, x, v) };
}

/* The outline of a rounded rectangle, from the top centre, clockwise: the arc has to start
   where a gauge starts and travel the way a clock does. */
function scRoundedPath(w, h, r){
  return 'M' + (w / 2) + ' 0'
    + 'H' + (w - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + w + ' ' + r
    + 'V' + (h - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + (w - r) + ' ' + h
    + 'H' + r + 'A' + r + ' ' + r + ' 0 0 1 0 ' + (h - r)
    + 'V' + r + 'A' + r + ' ' + r + ' 0 0 1 ' + r + ' 0Z';
}
/*
 * Each ring draws itself from nothing to its percentage.
 *
 * The first attempt drew an SVG <rect> in a viewBox with preserveAspectRatio="none" and then
 * rotated it -90deg to start the stroke at the top. Both were wrong: the stretch distorted
 * the stroke, and rotating a wide rectangle by a quarter turn stands it on end - which is the
 * vertical capsule that appeared around "Focus". The path is now built from the pill's real
 * size in pixels, so there is nothing to stretch and nothing to rotate.
 */
function scAnimateArcs(root){
  if (!root) return;
  root.querySelectorAll('.bs-pill .cap').forEach(function(cap){
    const svg = cap.querySelector('svg.arc'), path = cap.querySelector('svg.arc path');
    if (!svg || !path) return;
    const w = cap.clientWidth, h = cap.clientHeight;
    if (!w || !h) return;
    const r = h / 2;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    path.setAttribute('d', scRoundedPath(w, h, r));
    let len = 2 * (w + h);
    try{ if (path.getTotalLength) len = path.getTotalLength() || len; }catch(_){ }
    const pct = Math.max(0, Math.min(100, +path.dataset.pct || 0));
    path.style.transition = 'none';
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    // one frame with the ring empty, so the browser has something to animate away from
    requestAnimationFrame(function(){
      requestAnimationFrame(function(){
        path.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)';
        path.style.strokeDashoffset = len * (1 - pct / 100);
      });
    });
  });
}

/* ---------------------------------------------------------------------------------------
   ISPIRAZIONE QUOTIDIANA
   --------------------------------------------------------------------------------------- */

registerScreen('s-inspire',
  '<div class="insp-sky">'
  + '<div class="topbar insp-bar"><button class="iconbtn light" onclick="goId(\'s-home\')">‹</button><b>Ispirazione quotidiana</b></div>'
  + '<div class="insp-days" id="inspDays"></div>'
  + '<div class="insp-body" id="inspBody"></div>'
  + '<div class="insp-acts"><button class="insp-act" onclick="scInspireShare()" aria-label="Condividi">'
  +   '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'
  +     '<g transform="translate(-1,0)"><circle cx="17.2" cy="5" r="2.8"></circle><circle cx="6" cy="12" r="2.8"></circle>'
  +     '<circle cx="17.2" cy="19" r="2.8"></circle><line x1="9" y1="13" x2="14.7" y2="17"></line>'
  +     '<line x1="14.7" y1="7" x2="9" y2="10"></line></g></svg></button></div>'
  + '<div class="insp-share-menu" id="inspShareMenu" hidden>'
  +   '<button type="button" onclick="scShareImage()"><b>Immagine con la frase</b><small>per le storie, con lo sfondo del giorno</small></button>'
  +   '<button type="button" onclick="scShareText()"><b>Solo il testo</b><small>frase e autore, da incollare ovunque</small></button>'
  + '</div>'
  + '<p class="insp-credit" id="inspCredit"></p>'
  + '<div class="insp-lock"><div><b>Aggiorna citazione su schermata di blocco</b><small id="inspLockSub">Ogni giorno la frase nuova diventa il tuo sfondo di blocco.</small></div>'
  + '<button class="switch" id="inspLockSw" onclick="scToggleLockQuote()"></button></div>'
  /* 0.9.264 (Premium): al posto della frase del giorno, le frasi sul tuo obiettivo scritte dall'agente (frasi-obiettivo.js) */
  + '<div class="insp-lock" id="foRiga"></div></div>',
  { back: function(){ switchTab('profilo'); return 's-home'; } });

/* 0.9.373, Andrea: "aprendo l'Ispirazione quotidiana l'immagine di sfondo cambia sotto gli occhi (la frase con la parola sogno prende un
   quadro del negozio): va caricata prima". La frase e il quadro di oggi si scelgono e si scaricano qualche secondo dopo l'avvio; aprendo
   la pagina il cielo e' gia' quello giusto, e se non e' ancora pronto resta scuro finche' non lo e' (mai prima un'immagine e poi un'altra) */
async function scInspirePrecarica(){
  try{
    const q = await scQuotes(); const pick = scQuoteFor(q, 0);
    const bgs = await scBackgrounds(); const bg = scPickBg(bgs, 0, pick);
    if (!bg) return;
    const im = new Image(); im.onload = function(){ SC.insPre = bg; }; im.src = bg.image;
  }catch(_){ }
}
setTimeout(function(){ try{ scInspirePrecarica(); }catch(_){ } }, 5000);
async function scOpenInspire(){
  SC.insDay = 0;
  try{ const sky = document.querySelector('.insp-sky'); if (sky){ sky.style.backgroundImage = SC.insPre ? 'linear-gradient(180deg,rgba(3,10,26,.5),rgba(3,10,26,.86)),url("' + SC.insPre.image + '")' : ''; } }catch(_){ }
  goId('s-inspire');
  // no starfield here: the twinkling pulled the eye off the phrase, which is the whole page
  scInspirePaint();
  try{ if (typeof foRigaPaint === 'function') foRigaPaint(); }catch(_){ }
  if (NATIVE && NATIVE.getLockQuote){
    try{
      const st = await NATIVE.getLockQuote();
      const sw = document.getElementById('inspLockSw');
      if (sw) sw.className = 'switch' + (st && st.on ? ' on' : '');
      try{ if (st && st.on) localStorage.setItem('fl_lockquote_on', '1'); }catch(_){ }
      const sub = document.getElementById('inspLockSub');
      if (sub && st && !st.supported) sub.textContent = 'Non disponibile su questa versione di Android.';
    }catch(_){ }
  }
}
/* ---- the background of the day: one of the store's own artworks ----------------------------

   The images come from /api/focuslock/backgrounds, which reads the motivational, spiritual and
   landscape collections of the shop. The day picks its picture with the same arithmetic the
   phrase uses (epoch day modulo the list), so everyone sees the same artwork on the same day,
   and yesterday's chip shows yesterday's. Without network the night sky stays. */
const SC_BG_URL = 'https://meta-ai-media-buyer-production.up.railway.app/api/focuslock/backgrounds';
async function scBackgrounds(){
  // Only a list with something in it is worth remembering: an empty answer (the server was
  // restarting, the phone was offline for a second) must be asked again next time, not kept
  // for the whole session as "there are no pictures".
  if (SC.bgs && SC.bgs.length) return SC.bgs;
  const day = scKey(scDayStart(0));
  try{
    const c = JSON.parse(localStorage.getItem('fl_bgs') || 'null');
    if (c && c.day === day && Array.isArray(c.items) && c.items.length){ SC.bgs = c.items; return SC.bgs; }
  }catch(_){ }
  try{
    // Through the native client, like the quotes: a fetch from the WebView is a cross-origin
    // request the server does not answer for, and it failed on every phone.
    let j = null;
    if (NATIVE && NATIVE.publicApi) j = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/backgrounds' });
    else { const r = await fetch(SC_BG_URL, { cache: 'no-store' }); j = await r.json(); }
    if (j && Array.isArray(j.items) && j.items.length){
      SC.bgs = j.items;
      try{ localStorage.setItem('fl_bgs', JSON.stringify({ day: day, items: j.items })); }catch(_){ }
      return SC.bgs;
    }
  }catch(_){ }
  // stale copy beats no copy
  try{ const c = JSON.parse(localStorage.getItem('fl_bgs') || 'null'); if (c && c.items && c.items.length){ SC.bgs = c.items; return SC.bgs; } }catch(_){ }
  SC.bgs = [];
  return SC.bgs;
}
/* ---------------------------------------------------------------------------------------
   Lo sfondo del giorno.

   Nessuna intelligenza artificiale: la scelta è una riga di aritmetica. Un'opera dello store
   compare SOLO se il titolo (inglese) contiene una parola della frase del giorno — le frasi
   sono italiane, quindi le parole passano da un piccolo vocabolario italiano→inglese scritto
   a mano qui sotto. Se nessun quadro corrisponde, lo sfondo è uno degli otto paesaggi
   minimal disegnati dall'app (www/img/bg), scelti a rotazione per giorno.
   --------------------------------------------------------------------------------------- */
const SC_MIN_BGS = [
  { image: 'img/bg/alba.jpg',     title: 'Alba',              minimal: true },
  { image: 'img/bg/montagne.jpg', title: 'Montagne',          minimal: true },
  { image: 'img/bg/mare.jpg',     title: 'Mare',              minimal: true },
  { image: 'img/bg/foresta.jpg',  title: 'Foresta',           minimal: true },
  { image: 'img/bg/dune.jpg',     title: 'Dune',              minimal: true },
  { image: 'img/bg/aurora.jpg',   title: 'Aurora',            minimal: true },
  { image: 'img/bg/nebbia.jpg',   title: 'Nebbia',            minimal: true },
  { image: 'img/bg/luna.jpg',     title: 'Luna',              minimal: true }
];
const SC_IT_EN = {
  sogno:['dream'], sogni:['dream','dreams'], sognare:['dream'], sognatore:['dreamer'],
  tempo:['time'], ora:['now'], oggi:['today'], domani:['tomorrow'], futuro:['future'],
  fuoco:['fire','burn'], luce:['light'], buio:['dark'], notte:['night'], giorno:['day'],
  stella:['star'], stelle:['stars','star'], cielo:['sky'], luna:['moon'], sole:['sun','sunrise'],
  mare:['sea','ocean'], onda:['wave'], onde:['waves'], montagna:['mountain'], montagne:['mountains'],
  vetta:['peak','summit'], strada:['road'], cammino:['path'], viaggio:['journey'], passo:['step'],
  silenzio:['silence'], calma:['calm'], pace:['peace'], respiro:['breathe','breath'],
  liberta:['freedom'], libero:['free'], coraggio:['courage','brave'], paura:['fear','fearless'],
  mente:['mind','mindset'], pensiero:['thought'], anima:['soul'], cuore:['heart'],
  forza:['strength','power'], forte:['strong'], disciplina:['discipline'], abitudine:['habit'],
  focus:['focus'], concentrazione:['focus','focused'], attenzione:['attention'],
  successo:['success'], vittoria:['victory','win'], vincere:['win'], obiettivo:['goal'], obiettivi:['goals'],
  lavoro:['work','hustle'], fatica:['grind'], pazienza:['patience'], costanza:['consistency'],
  crescita:['growth'], crescere:['grow'], vita:['life','live'], vivere:['live'],
  credere:['believe'], fede:['faith'], speranza:['hope'], amore:['love'], passione:['passion'],
  energia:['energy'], destino:['destiny'], inizio:['start','beginning'], iniziare:['start','begin'],
  mai:['never'], sempre:['always'], possibile:['possible'], impossibile:['impossible'],
  foresta:['forest'], albero:['tree'], alberi:['trees'], ali:['wings'], volare:['fly'],
  casa:['home'], terra:['earth'], mondo:['world'], universo:['universe'], magia:['magic'],
  ricordo:['memory'], memoria:['memory'], errore:['mistake'], cadere:['fall'], rialzarsi:['rise'],
  salire:['rise','climb'], sorriso:['smile'], gratitudine:['gratitude'], scelta:['choice'], scegliere:['choose']
};
function scWords(t){
  return String(t || '').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length >= 3);
}
/* The English tokens a phrase is about: its own words (some phrases are English already)
   plus the translations of the Italian ones. */
function scEnTokens(text){
  const out = {};
  scWords(text).forEach(w => {
    if (w.length >= 4) out[w] = 1;
    (SC_IT_EN[w] || []).forEach(e => { out[e] = 1; });
    // "sogni" and "sogno" both reach "sogn-": a light stem for the commonest endings
    const stem = w.replace(/(are|ere|ire|zione|mente|i|o|e|a)$/, '');
    if (stem.length >= 4) (SC_IT_EN[stem] || []).forEach(e => { out[e] = 1; });
  });
  return Object.keys(out);
}
function scMatchesQuote(item, tokens){
  const words = scWords((item.title || '') + ' ' + (item.handle || '').replace(/-/g, ' '));
  const set = {};
  words.forEach(w => { set[w] = 1; if (w.endsWith('s')) set[w.slice(0, -1)] = 1; else set[w + 's'] = 1; });
  return tokens.some(t => set[t] === 1);
}
/* `list` are the store's works, `quote` the phrase of the day. Same day, same picture, for
   everyone: the index is the epoch day. */
function scPickBg(list, off, quote){
  const epochDay = Math.floor(scDayStart(off) / SC_DAY_MS);
  const pickFrom = arr => arr[((epochDay % arr.length) + arr.length) % arr.length];
  if (list && list.length && quote && quote.text){
    const tokens = scEnTokens(quote.text + ' ' + (quote.author || ''));
    const hits = list.filter(it => scMatchesQuote(it, tokens));
    if (hits.length) return pickFrom(hits);
  }
  return pickFrom(SC_MIN_BGS);
}
/* kept for any older call site */
function scBgFor(list, off){ return scPickBg(list, off, null); }
function scInspireBg(bg){
  const sky = document.querySelector('.insp-sky');
  if (!sky) return;
  if (!bg){ sky.style.backgroundImage = ''; return; }
  if (sky.style.backgroundImage.indexOf(bg.image) >= 0) return;
  // paint only once the picture is in, so the sky never flashes empty between two days
  const im = new Image();
  im.onload = function(){
    sky.style.backgroundImage = 'linear-gradient(180deg,rgba(3,10,26,.5),rgba(3,10,26,.86)),url("' + bg.image + '")';
  };
  im.src = bg.image;
}

async function scInspirePaint(){
  const q = await scQuotes();
  const days = document.getElementById('inspDays'), body = document.getElementById('inspBody');
  if (!days || !body) return;
  /* LE FRASI DEI GIORNI PASSATI SONO PREMIUM (Andrea, 30/09): i sei giorni prima di oggi
     portano il lucchetto per chi non ce l'ha. Oggi e' di tutti. */
  const prem = (typeof adsUserIsPremium === 'function') ? adsUserIsPremium() : false;
  let chips = '';
  for (let off = 6; off >= 0; off--){
    const d = new Date(scDayStart(off));
    const chiuso = off > 0 && !prem;
    chips += '<button class="insp-day' + (off === SC.insDay ? ' on' : '') + (chiuso ? ' chiuso' : '') + '" onclick="scInspireDay(' + off + ')">' + d.getDate() + (chiuso ? '<i class="insp-lock-ico">🔒</i>' : '') + '</button>';
  }
  days.innerHTML = chips;
  const pick = scQuoteFor(q, SC.insDay);
  const d = new Date(scDayStart(SC.insDay));
  body.innerHTML = '<div class="insp-date"><b>' + d.getDate() + '</b><span>' + SC_MONTHS[d.getMonth()] + ' ' + d.getFullYear() + '</span></div>'
    + (pick
        ? '<p class="insp-quote" id="inspQuote">' + flHeroLine(pick.text, 0) + '</p><p class="insp-author">~ ' + esc(pick.author) + '</p>'
        : '<p class="insp-quote">Per questo giorno non ho ancora una frase.</p>');
  scInspireMenu(false);
  const bgs = await scBackgrounds();
  const bg = scPickBg(bgs, SC.insDay, pick);
  SC.insBg = bg;
  scInspireBg(bg);
  const credit = document.getElementById('inspCredit');
  if (credit){
    credit.innerHTML = !bg ? ''
      /* 0.9.302, Andrea: gli sfondi disegnati dall'app non si firmano ("Sfondo Aurora · disegnato da DreamMap" via) */
      : (bg.minimal ? ''
                    : 'Opera: <b>' + esc(bg.title) + '</b> · parla di questa frase · dream-brothers.com');
    credit.onclick = (bg && !bg.minimal) ? function(){ if (typeof ufOpenUrl === 'function') ufOpenUrl(bg.url); } : null;
  }
}
function scInspireDay(off){
  if (off > 0 && !((typeof adsUserIsPremium === 'function') && adsUserIsPremium())){
    toast('Le frasi dei giorni scorsi si aprono con Premium');
    try{ if (typeof premiumBuy === 'function') premiumBuy(); }catch(_){ }
    return;
  }
  SC.insDay = off; scInspirePaint();
}

/* ---- sharing: the words alone, or the picture with the words on it ----------------------- */
function scInspireMenu(open){
  const m = document.getElementById('inspShareMenu');
  if (!m) return;
  if (typeof open !== 'boolean') open = m.hidden;
  m.hidden = !open;
}
/* The store's phrases arrive already wrapped in quotation marks; a second pair printed
   ""…"" on the story. Quote only what is not quoted. */
function scQuoted(t){ return /^["“«]/.test(t) ? t : '"' + t + '"'; }
function scShareCaption(pick){
  return scQuoted(pick.text) + '\n~ ' + pick.author + '\n\n— la mia ispirazione di oggi su DreamMap';
}
async function scShareText(){
  scInspireMenu(false);
  const q = await scQuotes();
  const pick = scQuoteFor(q, SC.insDay);
  if (!pick){ toast('Niente da condividere'); return; }
  const txt = scShareCaption(pick);
  try{
    if (NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: txt, title: 'Frase del giorno' }); return; }
    if (navigator.share){ await navigator.share({ text: txt }); return; }
    if (navigator.clipboard){ await navigator.clipboard.writeText(txt); toast('Copiata negli appunti'); return; }
  }catch(_){ return; }
  toast('Condivisione non disponibile qui');
}
/* A 1080x1920 story: the day's artwork, the veil, the phrase set large, the author, the mark. */
async function scShareImage(){
  scInspireMenu(false);
  const q = await scQuotes();
  const pick = scQuoteFor(q, SC.insDay);
  if (!pick){ toast('Niente da condividere'); return; }
  toast('Preparo l\'immagine…');
  const W = 1080, H = 1920;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  const bg = SC.insBg;
  const paintBase = () => {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#020926'); g.addColorStop(.35, '#06214F'); g.addColorStop(.65, '#1B4E8C'); g.addColorStop(1, '#08295B');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  };
  const drawCover = (im) => {
    const s = Math.max(W / im.width, H / im.height);
    const w = im.width * s, h = im.height * s;
    ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
  };
  const loadImg = (src) => new Promise((ok, ko) => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => ok(im); im.onerror = ko; im.src = src; });
  try{
    if (bg) drawCover(await loadImg(bg.image)); else drawCover(await loadImg('img/dream-night.jpg'));
  }catch(_){ paintBase(); }
  // the veil, so the words read on any picture
  const veil = ctx.createLinearGradient(0, 0, 0, H);
  veil.addColorStop(0, 'rgba(3,10,26,.55)'); veil.addColorStop(.5, 'rgba(3,10,26,.62)'); veil.addColorStop(1, 'rgba(3,10,26,.9)');
  ctx.fillStyle = veil; ctx.fillRect(0, 0, W, H);
  // the words
  ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
  const wrap = (text, font, maxW) => {
    ctx.font = font;
    const words = text.split(' '), lines = []; let line = '';
    words.forEach(w => { const t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line){ lines.push(line); line = w; } else line = t; });
    if (line) lines.push(line);
    return lines;
  };
  const quote = scQuoted(pick.text);
  let size = 72;
  let lines = wrap(quote, '700 ' + size + 'px Poppins, sans-serif', W - 240);
  while (lines.length > 8 && size > 44){ size -= 4; lines = wrap(quote, '700 ' + size + 'px Poppins, sans-serif', W - 240); }
  const lh = size * 1.32;
  let y = H / 2 - (lines.length * lh) / 2 + size * 0.35;
  ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 6;
  ctx.font = '700 ' + size + 'px Poppins, sans-serif';
  lines.forEach(l => { ctx.fillText(l, W / 2, y); y += lh; });
  ctx.font = 'italic 500 40px Poppins, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.88)';
  ctx.fillText('~ ' + pick.author, W / 2, y + 30);
  ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
  // the mark at the foot
  ctx.font = '800 34px Montserrat, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.9)';
  ctx.fillText('DreamMap', W / 2, H - 150);
  ctx.font = '500 26px Poppins, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.6)';
  ctx.fillText(bg ? 'Opera: ' + bg.title + ' · dream-brothers.com' : 'dream-brothers.com', W / 2, H - 104);
  let data;
  try{ data = cv.toDataURL('image/png'); }
  catch(e){ toast('Non riesco a comporre l\'immagine con questo sfondo'); return; }
  const caption = scShareCaption(pick) + (bg ? '\n' + bg.url : '');
  try{
    if (NATIVE && NATIVE.shareImage){ await NATIVE.shareImage({ base64: data, title: 'Frase del giorno', text: caption }); return; }
    if (navigator.share && navigator.canShare){
      const blob = await (await fetch(data)).blob();
      const file = new File([blob], 'focuslock-frase.png', { type: 'image/png' });
      if (navigator.canShare({ files: [file] })){ await navigator.share({ files: [file], text: caption }); return; }
    }
  }catch(_){ return; }
  toast('Condivisione immagine non disponibile qui');
}
/* kept as the button's entry point: it opens the two choices */
function scInspireShare(){ scInspireMenu(); }
async function scToggleLockQuote(){
  const sw = document.getElementById('inspLockSw');
  if (!sw) return;
  const on = !sw.classList.contains('on');
  if (!NATIVE || !NATIVE.setLockQuote){ toast('Disponibile nell\'app installata'); return; }
  if (!on){
    try{ await NATIVE.setLockQuote({ on: false }); }catch(_){ }
    try{ localStorage.removeItem('fl_lockquote_on'); }catch(_){ }
    try{ const fo = JSON.parse(localStorage.getItem('fl_frasi_obiettivo') || 'null'); if (fo && fo.on){ fo.on = false; localStorage.setItem('fl_frasi_obiettivo', JSON.stringify(fo)); if (typeof foRigaPaint === 'function') foRigaPaint(); } }catch(_){ }
    sw.className = 'switch';
    toast('Lo sfondo di blocco resta quello che c\'è ora');
    return;
  }
  const q = await scQuotes();
  const pick = scQuoteFor(q, 0);
  if (!pick){ toast('Non ho ancora una frase da mettere'); return; }
  try{
    await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: scKey(scDayStart(0)) });
    sw.className = 'switch on';
    try{ localStorage.setItem('fl_lockquote_on', '1'); }catch(_){ }
    try{ if (typeof rscPaint === 'function') rscPaint(); }catch(_){ }
    toast('Fatto:\nguarda la schermata di blocco');
  }catch(e){ toast(e && e.message ? e.message : 'Non riuscito'); }
}
/* Once a day, silently: the switch promised a phrase that changes, not one frozen on the day
   it was turned on. */
async function scLockQuoteDaily(q){
  if (!NATIVE || !NATIVE.getLockQuote || !NATIVE.setLockQuote) return;
  try{
    const st = await NATIVE.getLockQuote();
    if (!st || !st.on) return;
    const today = scKey(scDayStart(0));
    const pick = scQuoteFor(q, 0);
    if (!pick) return;
    /* LA SCORTA.
       A mezzanotte questa pagina non esiste: l'app e' chiusa, e la frase sullo sfondo restava
       quella del giorno prima finche' qualcuno non la riapriva. Adesso il telefono si porta
       avanti tre settimane di frasi e se la cava da solo, con la sua sveglia. */
    const pool = scLockPool(q);
    if (st.day === today){
      try{ await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: today, pool: pool }); }catch(_){ }
      return;
    }
    await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: today, pool: pool });
  }catch(_){ }
}

/* Le frasi dei prossimi ventuno giorni, nello stesso ordine che userebbe questa pagina.

   Se il server ne ha mandata una sola, la scorta si costruisce sull'elenco di riserva che l'app
   si porta dentro: una scorta con dentro solo oggi non e' una scorta, ed e' esattamente il caso
   in cui domani lo sfondo resterebbe fermo a ieri. */
function scLockPool(q){
  const out = [];
  /* La stessa funzione che usa la pagina, per tutti e ventuno i giorni: due aritmetiche
     diverse per la stessa cosa divergono sempre, e qui divergerebbero in silenzio — la
     schermata di blocco direbbe una frase e l'app un'altra, lo stesso giorno. */
  const vuoto = ((q && q.list) || []).filter(Boolean).length < 2;
  const qq = vuoto ? { today: '', list: SC_FALLBACK_QUOTES.slice() } : q;
  for (let i = 0; i < 21; i++){
    try{
      const p = scQuoteFor(qq, -i);
      if (!p) continue;
      out.push({ d: scKey(scDayStart(-i)), t: p.text, a: p.author || '' });
    }catch(_){ }
  }
  return out;
}

/* ---------------------------------------------------------------------------------------
   BREAKDOWN SCREEN
   --------------------------------------------------------------------------------------- */

registerScreen('s-score',
  /* 0.9.281, Andrea (come la pagina Sleep che ha mandato): il titolo del punteggio, le tab Giorno, Settimana,
     Mese, Anno, sotto le frecce dei giorni, poi il tachimetro, il pannello con la spiegazione e i fattori. */
  '<div class="topbar sc-top"><button class="iconbtn" onclick="scClose()">‹</button><b class="sc-titolo" id="scTitolo">Punteggio</b></div>'
  + '<div class="sc-per" id="scPer"></div>'
  + '<div class="sc-daynav"><button class="iconbtn" id="scBack" onclick="scStep(1)">‹</button><b id="scDayLbl">Oggi</b><button class="iconbtn" id="scFwd" onclick="scStep(-1)">›</button></div>'
  + '<div id="scBody"><div class="ins-load">Leggo i dati…</div></div>',
  { back: function(){ return 's-home'; } });

function scClose(){ /* 0.9.282: indietro torna da dove eri (il Profilo), non a Proteggi i tuoi sogni */ if (typeof flIndietro === 'function') flIndietro(); else goId('s-home'); }
/* 0.9.276, Andrea: i giorni passati dei tre punteggi (sonno, focus, riposo) sono Premium. Il report resta per tutti. */
function scPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function scStep(dir){
  if (dir > 0 && !scPremium()){
    try{ toast('I giorni passati dei punteggi sono con Premium'); }catch(_){ }
    try{ if (typeof pwUpsellApri === 'function') pwUpsellApri(); }catch(_){ }
    return;
  }
  SC.dayOff = Math.max(0, Math.min(14, SC.dayOff + dir)); scRender();
}
async function scOpen(kind){
  SC.view = kind || 'total';
  SC.dayOff = 0; SC.periodo = 'giorno';
  goId('s-score');
  scRender();
}

const SC_META = {
  /* 0.9.276, Andrea: "una pappardella lunghissima che nessuno leggera' mai". Una frase sotto al titolo; come
     si calcola sta in un foglio a parte, a punti, solo per chi lo vuole sapere. */
  total: { name: 'Punteggio', q: 'Cos\'è il Punteggio?', breve: 'Sonno, focus e riposo in un solo numero. La media dei tre.',
    come: [['🧮', 'La media', 'Dei tre punteggi che oggi hanno dati.'], ['🤝', 'Cosa racconta', 'Quanto la tecnologia, oggi, è stata dalla tua parte.']] },
  sleep: { name: 'Sonno', q: 'Cos\'è il punteggio Sonno?', breve: 'Quanto hai dormito. Il massimo è fra 7 ore e mezza e 8 ore e mezza.',
    come: [['🌙', 'Quando comincia la notte', 'Dall\'ultima volta che usi il telefono la sera.'],
           ['☀️', 'Quando finisce', 'Quando spegni la sveglia e usi il telefono per qualche minuto. Un\'occhiata nella notte non conta.'],
           ['🎯', 'Il punteggio pieno', 'Fra 7 ore e mezza e 8 ore e mezza. Sei ore valgono 70, dieci ore 78.'],
           ['⏰', 'Cosa toglie punti', 'Andare a letto dopo l\'una (8 punti), dopo le tre (12), e ogni risveglio (2).']] },
  focus: { name: 'Focus', q: 'Cos\'è il punteggio Focus?', breve: 'Quanto del tuo tempo è finito nelle app che distraggono.',
    come: [['📱', 'Le app che distraggono', 'Pesano più di tutto il resto.'], ['🔓', 'Schermo e sblocchi', 'Contano meno.'], ['💼', 'Il lavoro', 'Una giornata lunga al telefono per lavorare, senza social, resta alta.']] },
  rest:  { name: 'Riposo', q: 'Cos\'è il punteggio Riposo?', breve: 'Quanto della giornata hai passato lontano dallo schermo.',
    come: [['🌿', 'Da mezzanotte a adesso', 'La notte a riposo conta, il telefono in mano no.'], ['🎯', 'Il punteggio', 'Un quarto del tempo lontano vale 0, quattro quinti valgono 100.']] }
};
/* 0.9.400 BUG-173: il perche' di un punteggio in una riga, con gli stessi fatti della pagina del punteggio (scCompute, il motore del sonno).
   Lo usa la lettura del Genio sotto a ogni numero: "un numero che giudica ha sempre il suo perche'". Testo semplice, niente html. */
function scPercheRiga(k, c){
  if (!c) return '';
  if (k === 'sleep'){
    const n = c.notte;
    if (!(c.sleepMs > 0)) return (typeof snFraseManca === 'function') ? snFraseManca(n || { motivo: 'dati' }) : 'Stanotte il telefono non ha visto una notte intera.';
    const ora = function(t){ return (typeof snOra === 'function') ? snOra(t) : new Date(t).toTimeString().slice(0, 5); };
    return 'Hai dormito ' + scFmt(c.sleepMs) + (n && n.inizio ? ', a letto alle ' + ora(n.inizio) : '') + (c.wake ? ' e in piedi alle ' + ora(c.wake) : '') + '.';
  }
  if (k === 'focus'){
    if (!c.hasUse) return 'Oggi il telefono non è ancora stato usato.';
    return (c.distrMs >= 60000 ? scFmt(c.distrMs) + ' nelle app che distraggono' : 'Quasi niente nelle app che distraggono') + ', ' + scFmt(c.screenMs) + ' di schermo in tutto.';
  }
  if (k === 'rest'){
    if (!(c.elapsedMs >= 60 * 60000)) return 'Si misura dopo la prima ora della giornata.';
    return 'Lontano dallo schermo per ' + scFmt(c.dayOfflineMs) + ' su ' + scFmt(c.elapsedMs) + ' di oggi.';
  }
  return '';
}
function scComeApri(k){
  const m = SC_META[k] || SC_META.total;
  if (typeof stgFoglio !== 'function') return;
  stgFoglio('<small class="stg-eti">Come si calcola</small><h2 class="stg-h">Il punteggio ' + (k === 'total' ? '' : m.name) + '</h2>'
    + flInfoRighe(m.come)
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho capito</button>');
}

function scScoresHtml(sc, selected){
  const v = x => (x === null || x === undefined) ? '—' : x;
  const pill = (k, ico, label) =>
    '<div class="sc-pill' + (selected === k ? ' on' : (selected ? ' dim' : '')) + '" onclick="scOpen(\'' + k + '\')">'
    + '<div class="cap"><span class="ic">' + ico + '</span><b>' + v(sc[k]) + '</b></div><small>' + label + '</small></div>';
  return '<div class="sc-wrap">'
    + '<div class="sc-total' + (selected && selected !== 'total' ? ' dim' : '') + '" onclick="scOpen(\'total\')"><small>Punteggio</small><b>' + v(sc.total) + '</b></div>'
    + '<div class="sc-bracket"><i></i><i></i><i></i></div>'
    + '<div class="sc-row">' + pill('sleep', '🌙', 'Sonno') + pill('focus', '⏳', 'Focus') + pill('rest', '🌲', 'Riposo') + '</div>'
    + '</div>';
}

const SC_PER_NOME = { giorno: 'Giorno', settimana: 'Settimana', mese: 'Mese', anno: 'Anno' };
const SC_PER_TXT = { giorno: 'Oggi', settimana: 'Ultimi 7 giorni', mese: 'Ultimi 30 giorni', anno: 'Ultimo anno' };
const SC_PER_GIORNI = { giorno: 1, settimana: 7, mese: 30, anno: 365 };
function scPeriodo(k){
  if (k !== 'giorno' && !scPremium()){
    try{ toast('Le medie della settimana, del mese e dell\'anno sono con Premium'); }catch(_){ }
    try{ if (typeof pwUpsellApri === 'function') pwUpsellApri(); }catch(_){ }
    return;
  }
  SC.periodo = k; SC.dayOff = 0; scRender();
}
/* LA MEDIA DEL PERIODO: il voto di ogni giorno con dati. Per l'anno un giorno ogni sette (52 letture invece di 365). */
async function scMediaPeriodo(k, giorni){
  const passo = giorni > 60 ? 7 : 1;
  let t = 0, n = 0;
  for (let i = 0; i < giorni; i += passo){
    try{ const c = scCompute(await scReportPunteggi(i)); const v = c ? c[k] : null; if (v !== null && v !== undefined && !isNaN(v)){ t += v; n++; } }catch(_){ }
  }
  return { v: n ? Math.round(t / n) : null, n: n };
}
function scGiudizio(v){
  if (v === null || v === undefined) return { t: 'Nessun dato', c: '#9DB7D6' };
  if (v >= 85) return { t: 'Ottimale', c: '#2ECC71' };
  if (v >= 70) return { t: 'Buono', c: '#4FB8FF' };
  if (v >= 50) return { t: 'Discreto', c: '#F5A623' };
  return { t: 'Da migliorare', c: '#E63946' };
}
/* IL TACHIMETRO: un arco di 240 gradi, pieno quanto il voto, con la tacca bianca alla fine.
   0.9.315, Andrea: 1) la punta arrotondata superava la tacca di mezzo spessore: adesso il riempimento finisce piatto, esattamente
   sotto la tacca; 2) un voto basso non puo' essere azzurro: l'arco comincia rosso e diventa blu lungo la strada, passando per il
   chiaro per non fare mai il viola. Gli stessi colori per sonno, focus e riposo. */
const SC_ARCO_COL = [[0, [230, 57, 70]], [.3, [236, 96, 104]], [.44, [245, 190, 190]], [.54, [176, 216, 252]], [.68, [63, 159, 244]], [1, [0, 117, 227]]];
function scArcoColore(u){
  let i = 0; while (i < SC_ARCO_COL.length - 2 && u > SC_ARCO_COL[i + 1][0]) i++;
  const a = SC_ARCO_COL[i], b = SC_ARCO_COL[i + 1], k = Math.max(0, Math.min(1, (u - a[0]) / (b[0] - a[0])));
  return 'rgb(' + a[1].map(function(x, j){ return Math.round(x + (b[1][j] - x) * k); }).join(',') + ')';
}
function scGaugeHtml(v, k, per, giorniMedia, c){
  const meta = SC_META[k] || SC_META.total, g = scGiudizio(v);
  const R = 80, cx = 100, cy = 100, a0 = 150, sweep = 240;
  const pt = function(a){ const r = a * Math.PI / 180; return [cx + R * Math.cos(r), cy + R * Math.sin(r)]; };
  const arco = function(da, a){ const p = pt(da), q = pt(a), large = (a - da) > 180 ? 1 : 0; return 'M' + p[0].toFixed(2) + ' ' + p[1].toFixed(2) + ' A' + R + ' ' + R + ' 0 ' + large + ' 1 ' + q[0].toFixed(2) + ' ' + q[1].toFixed(2); };
  const f = (v === null || v === undefined) ? 0 : Math.max(0, Math.min(100, v)) / 100;
  const fine = a0 + sweep * f, tac = pt(fine), tacIn = [cx + (R - 12) * Math.cos(fine * Math.PI / 180), cy + (R - 12) * Math.sin(fine * Math.PI / 180)], tacOut = [cx + (R + 12) * Math.cos(fine * Math.PI / 180), cy + (R + 12) * Math.sin(fine * Math.PI / 180)];
  let frase = '', fraseHtml = '';
  if (v !== null && v !== undefined){
    const quando = per === 'giorno' ? (SC.dayOff === 0 ? 'Oggi' : (SC.dayOff === 1 ? 'Ieri' : 'Quel giorno')) : ({ settimana: 'Negli ultimi 7 giorni', mese: 'Negli ultimi 30 giorni', anno: 'Nell\'ultimo anno' }[per]);
    const cosa = { sleep: 'il tuo sonno', focus: 'il tuo focus', rest: 'il tuo riposo', total: 'la tua giornata' }[k] || 'il punteggio';
    frase = quando + ' ' + cosa + ' è ' + (per === 'giorno' ? 'stato ' : 'stato in media ') + g.t.toLowerCase() + '.';
    /* 0.9.363, Andrea (seconda volta): "gli orari, a letto e sveglia, in blu: li hai lasciati neri". La riga della notte
       arrivava qui senza i tag, quindi senza colore. Ora resta HTML, gia' sicuro (scNotteRighe passa tutto da esc) */
    if (k === 'sleep' && per === 'giorno' && c && typeof scNotteRighe === 'function'){ const n = scNotteRighe(c).replace(/<\/?p[^>]*>/g, ''); if (n) fraseHtml = ' ' + n; }
    if (per !== 'giorno' && giorniMedia) frase += ' Media di ' + giorniMedia + (giorniMedia === 1 ? ' giorno' : ' giorni') + ' con dati.';
  }
  return '<div class="sc-gauge">'
    + '<svg viewBox="0 0 200 175" aria-hidden="true">' + scArcoTacche(f, a0, sweep, arco)
    + (f > 0 ? '<line x1="' + tacIn[0].toFixed(2) + '" y1="' + tacIn[1].toFixed(2) + '" x2="' + tacOut[0].toFixed(2) + '" y2="' + tacOut[1].toFixed(2) + '" class="sc-g-tac"/>' : '')
    + '</svg>'
    + '<div class="sc-g-mid"><b>' + (v === null || v === undefined ? '—' : v) + '</b><span><i style="background:' + g.c + '"></i>' + g.t + '</span></div></div>'
    + '<div class="sc-panel">' + (frase ? '<p class="sc-panel-f">' + esc(frase) + fraseHtml + '</p>' : '')
    + '<p class="sc-panel-q"><b>' + meta.q + '</b><button type="button" class="dp-i sc-i" onclick="scComeApri(\'' + (k || 'total') + '\')" aria-label="Come si calcola">i</button></p><p class="sc-panel-t">' + meta.breve + '</p></div>';
}
/* 0.9.319, Andrea: i colori del tachimetro della Dopamina, dal rosso al verde, come un semaforo, e a tacche: sei fasce staccate. La parte
   non ancora raggiunta resta pallida, dello stesso colore. */
const SC_TACCHE = ['#E63946', '#F0603C', '#F5921E', '#F2C21B', '#A8C93A', '#22C55E'];
function scArcoTacche(f, a0, sweep, arco){
  const pezzo = sweep / SC_TACCHE.length, fine = a0 + sweep * f;
  return SC_TACCHE.map(function(c, i){
    const a = a0 + i * pezzo + (i ? 1.4 : 0), z = a0 + (i + 1) * pezzo - (i < SC_TACCHE.length - 1 ? 1.4 : 0);
    return '<path d="' + arco(a, z) + '" class="sc-g-fill" stroke="' + c + '" stroke-opacity=".2"/>'
      + (fine > a ? '<path d="' + arco(a, Math.min(z, fine)) + '" class="sc-g-fill" stroke="' + c + '"/>' : '');
  }).join('');
}
/* il riempimento: tanti pezzi corti, ognuno del colore del suo punto dell'arco; la partenza e' tonda, la fine piatta */
function scArcoPieno(f, a0, sweep, arco, pt){
  if (!(f > 0)) return '';
  const passo = 2, fine = a0 + sweep * f, inizio = pt(a0);
  let h = '<circle cx="' + inizio[0].toFixed(2) + '" cy="' + inizio[1].toFixed(2) + '" r="7" fill="' + scArcoColore(0) + '"/>';
  for (let a = a0; a < fine; a += passo){
    const z = Math.min(fine, a + passo);
    /* ogni pezzo si appoggia sul successivo per non lasciare fessure; l'ultimo si ferma alla tacca */
    h += '<path d="' + arco(a, z < fine ? z + .4 : z) + '" class="sc-g-fill" stroke="' + scArcoColore((a - a0) / sweep) + '"/>';
  }
  return h;
}
const SC_PAG = {};
(function(){ const st = document.createElement('style'); st.textContent = '#scBody .sc-load{margin-top:22px}#scBody{padding-left:10px;padding-right:10px}.sc-ora{color:#0075E3!important;font-weight:800}body.dark .sc-ora{color:#8CC6FF!important}#scBody .sc-ora{color:#0075E3;font-weight:800}body.dark #scBody .sc-ora{color:#8CC6FF}'; document.head.appendChild(st); })();
async function scRender(){
  const body = document.getElementById('scBody');
  const lbl = document.getElementById('scDayLbl'), fwd = document.getElementById('scFwd');
  if (!body) return;
  /* 0.9.374, Andrea: "troppe schede: niente Anno nella Dopamina e nei tre punteggi, l'anno si vede nella revisione annuale" */
  /* 0.9.379, Andrea: "nei tre punteggi del profilo ci sono solo Giorno, Settimana e Mese: voglio anche l'anno" */
  const per = SC.periodo || 'giorno';
  /* 0.9.308, Andrea: dall'altro ieri in poi l'etichetta diceva solo "28 ottobre". Sempre col giorno della settimana: "mercoledì 28 ottobre". */
  if (lbl) lbl.textContent = per !== 'giorno' ? SC_PER_TXT[per] : (SC.dayOff === 0 ? 'Oggi' : (SC.dayOff === 1 ? 'Ieri' : new Date(scDayStart(SC.dayOff)).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })));
  if (fwd) fwd.disabled = SC.dayOff === 0;
  const bk = document.getElementById('scBack'); if (bk) bk.style.visibility = per === 'giorno' ? '' : 'hidden'; if (fwd) fwd.style.visibility = per === 'giorno' ? '' : 'hidden';
  const tit = document.getElementById('scTitolo'); if (tit) tit.textContent = (SC_META[SC.view] || SC_META.total).name;
  const pb = document.getElementById('scPer'); if (pb) pb.innerHTML = Object.keys(SC_PER_TXT).map(function(k){ return '<button type="button" class="' + (k === per ? 'on' : '') + '" onclick="scPeriodo(\'' + k + '\')">' + SC_PER_NOME[k] + '</button>'; }).join('');
  /* 0.9.348, Andrea: "toccando il punteggio del sonno ci mette troppo a leggere i dati, il Report e' molto piu' veloce". Come il Report:
     si mostra SUBITO l'ultima pagina disegnata per questa vista (in memoria e sul telefono), e intanto si ricalcola; il computer si
     aspetta al massimo un secondo e mezzo, in parallelo, non prima di tutto il resto */
  const scK = 'fl_sc_pag_' + SC.view + '_' + per + '_' + SC.dayOff;
  let gia = SC_PAG[scK]; if (!gia){ try{ const o = JSON.parse(localStorage.getItem(scK) || 'null'); if (o && o.g === new Date().toDateString()) gia = o.h; }catch(_){ } }
  body.innerHTML = gia || '<div class="ins-load sc-load">Leggo i dati…</div>';
  /* Prima di giudicare la notte: il primo segno di vita sul computer. Senza, la sveglia
     resta quella del telefono e chi si alza e va alla scrivania si vede regalare ore. */
  try{ if (typeof dpLeggiComputer === 'function') await Promise.race([dpLeggiComputer(), new Promise(function(ok){ setTimeout(ok, 1500); })]); }catch(_){ }
  const r = await scReportPunteggi(SC.dayOff);
  /* una lettura fallita (il motore occupato) non e' un permesso negato: si riprova fra poco */
  if (!r){ if (!scRender._riprova) scRender._riprova = setTimeout(function(){ scRender._riprova = 0; if (document.getElementById('scBody')) scRender(); }, 2000); return; }
  if (!r.granted){
    body.innerHTML = r.senzaDati
      ? (scPcScollegato()
        ? '<div class="ins-miss">Il computer non è più collegato al tuo account, quindi non riceve i punteggi del telefono.<button type="button" class="cta" style="display:block;margin:14px auto 0" onclick="scPcAccedi()">Accedi con Google</button></div>'
        : '<div class="ins-miss">I punteggi li misura il telefono, e oggi non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul telefono.</div>')
      : '<div class="ins-miss">Serve l\'accesso ai dati di utilizzo.</div>';
    return;
  }
  const c = scCompute(r);
  const avg = await scAverages(SC.dayOff);
  const meta = SC_META[SC.view] || SC_META.total;
  /* il voto da mostrare: quello del giorno, o la media del periodo */
  let voto = c ? c[SC.view] : null, giorniMedia = 0;
  if (per !== 'giorno'){ const m = await scMediaPeriodo(SC.view, SC_PER_GIORNI[per]); voto = m.v; giorniMedia = m.n; }
  let html = scGaugeHtml(voto, SC.view, per, giorniMedia, c);
  /* LE TACCHETTE STANNO SOPRA AL TITOLO. Sono il giudizio della notte in una parola sola:
     appiccicate al numero, dentro alla riga della metrica, arrivavano dopo tre paragrafi. */
  /* 0.9.280, Andrea: "Eccellente" sopra a "Cos'e' il punteggio Sonno?" non lo vuole: il numero dice gia' tutto */
  /* una riga vuota nel testo e' un paragrafo nuovo: niente muro di testo */
  /* 0.9.279, Andrea: niente pulsante "Come si calcola": la "i" tonda delle slide, accanto al titolo */
  html += '<h3 class="sc-ff">Fattori di valutazione</h3>';
  html += scMetrics(SC.view, c, avg);
  /* 0.9.315, Andrea: nel Riposo c'era anche il tachimetro della dopamina, e con "100" sopra e "53,2" sotto non si capiva quale
     guardare. In questa pagina il numero e' uno solo. La dopamina ha la sua pagina: qui resta la strada per arrivarci, senza voto. */
  if (SC.view === 'rest' && SC.dayOff === 0 && typeof dpApri === 'function'){
    html += '<button type="button" class="sc-dopa-riga" onclick="dpApri()"><span>🧠</span><div><b>Riserva di dopamina</b><small>Guarda cosa l’ha alzata e cosa l’ha abbassata oggi</small></div><svg viewBox="0 0 8 12" width="8" height="12" aria-hidden="true"><path fill="none" d="M1 1l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>';
  }
  html += '<p class="sc-foot">Le medie sono degli ultimi ' + (avg.days || 0) + ' giorni con dati. Tutto è misurato dal telefono; niente è stimato.</p>';
  body.innerHTML = html;
  try{ SC_PAG[scK] = html; localStorage.setItem(scK, JSON.stringify({ g: new Date().toDateString(), h: html })); }catch(_){ }
}

function scMetric(label, value, avgValue, fmt, better, extra){
  const has = value !== null && value !== undefined;
  const hasAvg = avgValue !== null && avgValue !== undefined && !isNaN(avgValue);
  let delta = '';
  let cls = 'flat';
  if (has && hasAvg){
    const d = value - avgValue;
    /* 'otto': il sonno e' meglio quanto piu' e' vicino alle otto ore, non quanto piu' e' lungo */
    const good = better === 'otto' ? Math.abs(value - 8 * SC_H) < Math.abs(avgValue - 8 * SC_H)
               : better === 'higher' ? d > 0 : d < 0;
    const tiny = Math.abs(d) < (fmt === scFmt ? 60000 : 0.5);
    cls = tiny ? 'flat' : (good ? 'good' : 'bad');
    delta = '<span class="delta ' + cls + '">' + (tiny ? '=' : (d > 0 ? '▲ ' : '▼ ')) + (tiny ? '' : fmt(Math.abs(d))) + '</span>';
  }
  let bar = '';
  if (has && hasAvg && avgValue > 0){
    const pos = scClamp(value / (2 * avgValue)) * 100;
    const left = Math.min(pos, 50), width = Math.abs(pos - 50);
    bar = '<div class="sc-bar"><i class="fill ' + cls + '" style="left:' + left + '%;width:' + width + '%"></i><span class="mark"></span></div><small class="sc-avg">MEDIA</small>';
  }
  return '<div class="sc-met"><div class="head"><b>' + label + '</b><span class="val">' + (has ? fmt(value) : '—') + '</span>' + delta + '</div>' + (extra || '') + bar + '</div>';
}
/** Sotto al numero del Sonno, la notte detta a parole: dal motore unico (sonno-motore.js). */
function scNotteRighe(c){
  const n = c && c.notte;
  if (!(c && c.sleepMs > 0)) return '<p class="sc-none">' + esc(snFraseManca(n || { motivo: 'dati' })) + '</p>';
  if (!n || !n.inizio || !c.wake) return '';
  /* 0.9.350, Andrea: "l'ora in cui sono andato a dormire e quella della sveglia in azzurro, che saltino subito all'occhio" */
  const ora = function(x){ return '<b class="sc-ora">' + esc(snOra(x)) + '</b>'; };
  let t = 'A letto alle ' + ora(n.inizio) + ', sveglia alle ' + ora(c.wake)
    + esc(n.svegliaDa === 'sveglia' ? ', quando hai spento la sveglia.' : '.');
  const i = snFraseInterruzioni(n), l = snFraseLeggero(n);
  if (i) t += ' ' + esc(i);
  if (l) t += ' ' + esc(l);
  return '<p class="sc-none">' + t + '</p>';
}
function scSleepBars(ms){
  const n = ms ? Math.max(1, Math.min(6, Math.round(ms / SC_H / 9 * 6))) : 0;
  /* «Eccellente» solo dove il punteggio e' pieno: undici ore e mezza dicevano «Eccellente» */
  const q = !ms ? '' : (ms > 9.5 * SC_H ? 'Troppo lungo' : ms > SC_SONNO_TROPPO_H * SC_H ? 'Buono'
            : ms >= 7.5 * SC_H ? 'Eccellente' : ms >= 6.5 * SC_H ? 'Buono' : ms >= 5 * SC_H ? 'Corto' : 'Poco');
  let b = '<div class="sc-sleep"><span class="q">' + q + '</span><div class="bars">';
  for (let i = 0; i < 6; i++) b += '<i class="' + (i < n ? 'on' : '') + '"></i>';
  return b + '</div></div>';
}
function scMetrics(view, c, avg){
  const min = v => String(Math.floor(v / 60)).padStart(2,'0') + ':' + String(Math.round(v % 60)).padStart(2,'0');
  const fmtMinDelta = v => Math.round(v) + ' min';
  const firstMin = c.first ? scMinOfDay(c.first) : null;
  const lastMin = c.prevLast ? ((scMinOfDay(c.prevLast) + 12 * 60) % (24 * 60)) : null;
  const hasSpan = c.spanMs > 0;
  let h = '';
  if (view === 'total'){
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Distrazioni', c.distrMs, avg.distrMs, scFmt, 'lower');
    h += scMetric('Sonno', c.sleepMs > 0 ? c.sleepMs : null, avg.sleepMs, scFmt, 'otto', c.sleepMs > 0 ? scSleepBars(c.sleepMs) : '');
    h += scMetric('Sblocchi del telefono', c.hasUse ? c.pickups : null, avg.pickups, v => Math.round(v), 'lower');
  } else if (view === 'sleep'){
    /* Le tacchette salgono in cima alla pagina (scRender): qui sotto resta il numero. */
    /* 0.9.284, Andrea: la notte detta a parole sta SOLO nel pannello in alto; qui si ripeteva. Resta solo il perche' manca. */
    h += scMetric('Sonno', c.sleepMs > 0 ? c.sleepMs : null, avg.sleepMs, scFmt, 'otto', c.sleepMs > 0 ? '' : scNotteRighe(c));
    /* 0.9.236: "Primo sblocco" diceva 00:00 (il primo uso del giorno di calendario, tagliato a
       mezzanotte). Adesso e' la sveglia del motore del sonno, o niente. */
    h += scMetric(c.daComputer ? 'Sveglia (dal computer)' : 'Sveglia', firstMin, avg.firstMin, v => (typeof v === 'number' && v > 24 * 60 ? fmtMinDelta(v) : min(v)), 'higher');
    h += scMetric('Ultimo uso della sera', lastMin, avg.lastMin, v => min((v + 12 * 60) % (24 * 60)), 'lower');
    /* la scelta vive qui, accanto al numero che cambia (0.9.202) */
    h += '<div class="sc-opt"><div><b>La sveglia la segna anche il computer</b><small>Se al mattino apri prima il computer, la notte finisce lì. Spento:<br>conta solo il telefono.</small></div>'
      + '<button type="button" class="switch' + (scSvegliaPcOn() ? ' on' : '') + '" onclick="scSvegliaPcSet(!scSvegliaPcOn());this.classList.toggle(\'on\');if(typeof scRender===\'function\')scRender()"></button></div>';
  } else if (view === 'focus'){
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Distrazioni', c.distrMs, avg.distrMs, scFmt, 'lower');
    h += scMetric('Focus più lungo', c.awakeGapMs > 0 ? c.awakeGapMs : (c.gapMs > 0 ? c.gapMs : null), avg.gapMs, scFmt, 'higher');
    h += scMetric('Sblocchi del telefono', c.hasUse ? c.pickups : null, avg.pickups, v => Math.round(v), 'lower');
  } else {
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Offline (oggi)', c.elapsedMs > 0 ? c.dayOfflineMs : null, avg.offlineMs, scFmt, 'higher');
    // the longest break while awake: the night is the Sleep score's, not a "focus" of six hours
    h += scMetric('Focus più lungo', c.awakeGapMs > 0 ? c.awakeGapMs : (c.gapMs > 0 ? c.gapMs : null), avg.gapMs, scFmt, 'higher');
  }
  return h;
}

/* ---------------------------------------------------------------------------------------
   SE CONTINUI COSÌ - what this pace costs over the years that are left

   The rest of the Report answers "how much today". This answers "how much of my life", which
   is the only version of the number that changes behaviour. It sits at the foot of the tab,
   after every figure it is built on.

   The arithmetic is deliberately simple and it is written on screen, because a projection
   nobody can check is a scare story:
      hours a day   the average of the last seven days (today alone is too noisy)
      years left    LIFE_SPAN - the age the user typed in
      years lost    years left * hours a day / 24
   LIFE_SPAN is a round 80 and WAKE_H a round 16. Both are averages, both are stated under the
   figure, and neither is dressed up as a fact about this person.
   --------------------------------------------------------------------------------------- */

const SC_AGE_KEY = 'fl_age';
const SC_LIFE_SPAN = 80;   // the horizon the estimate is drawn against
const SC_WAKE_H = 16;      // hours awake in an average day
const SC_LIFE_MIN_DAYS = 3;  // full days of measurement before the estimate means anything

function scAgeGet(){
  let v = 0;
  try{ v = parseInt(localStorage.getItem(SC_AGE_KEY) || '0', 10); }catch(_){ v = 0; }
  return (v >= 10 && v <= 99) ? v : 0;
}

/* The host is appended to the tab and kept last, the same way the streak panel is in Severa:
   insights.js rewrites its own containers and would otherwise carry this away with them. */
/* Il posto è scritto nell'HTML, subito sotto al cielo: è la prima cosa che si legge scendendo,
   prima ancora del lucchetto. Qui si riempie e basta. */
function scLifeEnsure(){ return document.getElementById('scLife'); }

function scAgeSave(){
  const i = document.getElementById('scAgeInput');
  const n = i ? parseInt(i.value, 10) : NaN;
  if (!(n >= 10 && n <= 99)){ toast('Scrivi un\'età fra 10 e 99'); return; }
  try{ localStorage.setItem(SC_AGE_KEY, String(n)); }catch(_){ }
  scLifePaint();
}
function scAgeEdit(){
  try{ localStorage.removeItem(SC_AGE_KEY); }catch(_){ }
  scLifePaint();
}

/* One decimal, comma as the separator, because the app speaks Italian. */
function scNum(x, dec){
  const s = (Math.round(x * Math.pow(10, dec)) / Math.pow(10, dec)).toFixed(dec);
  return s.replace('.', ',');
}

async function scLifePaint(){
  const el = scLifeEnsure();
  if (!el) return;
  if (!scHaGiornata()){ el.innerHTML = ''; return; }
  /* 0.9.288: "Prevedi il tuo futuro" e' uno dei giochi del Genio: spento con la stagione di spinta */
  if (typeof flSezioneBloccata === 'function' && flSezioneBloccata('genio-giochi')){ el.innerHTML = ''; return; }

  /* 0.9.304, Andrea: niente piu' titolo "Prevedi il tuo futuro" ne' la frase di F.M. Alexander sopra al pannello:
     il pannello sta nella scheda Identita' del pannello di Dream (rotta-tab.js), e la frase va nella lettura del Genio */
  const wrap = inner => '<div class="life-wrap"><div class="life">' + inner + '</div></div>';

  /*
   * Nel pannello resta UN elemento (regola OEOF): prima della lettura, l'invito; dopo, il
   * nome di chi stai diventando. Domande, numeri e Jung vivono a schermo intero, uno per volta.
   */
  /* 22/11/2026: conta solo la lettura vera (quella dell'intro, sui telefoni che l'avevano gia', non conosceva ancora nessuno) */
  let last = (typeof orLast === 'function') ? orLast() : null;
  if (last && (last.intro || !last.profile)) last = null;
  if (!last){
    el.innerHTML = wrap('<b class="life-t">Pensa alla persona che vuoi diventare</b>'
      + '<p class="life-p">Ti farò qualche domanda. Alcune risposte le conosco già:<br>le ho lette nel tuo telefono.</p>'
      + scLetturaBtn('Sfidami · ti dirò chi stai diventando'));
    return;
  }
  const prof = orProfile(last.profile);
  /* non un'etichetta su chi sei: dove porta la strada di adesso */
  /* 0.9.350, Andrea: "Se continui cosi' rischi di diventare sembra girarci intorno, e per chi sta diventando la persona che vuole e' un
     controsenso. Stai diventando, diretto; Se continui cosi' rischi di diventare solo per i profili negativi, e solo se ha chiesto di
     sentirsi dire le cose in modo piu' morbido" (fl_tono = 'morbido') */
  /* 0.9.352: la scelta c'e', nella storia (episodio 4, "Per cambiare un'abitudine, che regola reggi meglio?"): chi ha scelto
     "Una regola morbida, che posso adattare" se le sente dire con piu' tatto */
  /* 22/11/2026, Andrea: una formula sola, ovunque (genio-lettura.js, fraseProfiloKick): "Stai diventando" per i profili che portano
     avanti, "Se continui così, rischi di diventare" per tutti gli altri */
  el.innerHTML = wrap('<b class="life-t">' + ((typeof fraseProfiloKick === 'function') ? fraseProfiloKick(prof) : 'Stai diventando') + '</b>'
    + '<div class="life-who">' + prof.ico + '</div>'
    + '<div class="life-big who">' + esc(prof.name) + '</div>'
    /* 0.9.376, Andrea: "la probabilita' e' quella di realizzare il sogno con chi sei oggi, non di diventare la persona che chiude Telegram;
       e la percentuale in azzurro, non solo in grassetto" */
    + '<p class="life-p">Oggi hai il <strong class="life-pct">' + last.pct + '%</strong> di probabilità di realizzare il tuo sogno, con le abitudini e le convinzioni di oggi.</p>'
    /* 0.9.305, Andrea: tre pulsanti si contendevano il focus. Qui restano "Rifai la lettura" (il principale) e
       "Quanti anni ti costa"; "Ricalcola il percorso" compare solo alla fine della lettura, come proposta (oracle.js) */
    + scLetturaBtn('Rifai la lettura')
    + '<div class="life-links"><button class="life-edit" onclick="scFutureStory()">Quanti anni ti costa</button></div>');
}

/* ---- Jung, l'ultimo passo del racconto ------------------------------------------------

   L'immagine originale aveva la frase stampata sopra, in inglese. Il ritratto qui è nudo e la
   frase la scrive l'app, nella lingua del telefono: chi ha il telefono in spagnolo la legge in
   spagnolo. */
const SC_JUNG = {
  it: "Finché non rendi cosciente l'inconscio, esso guiderà la tua vita e tu lo chiamerai destino.",
  en: 'Until you make the unconscious conscious, it will direct your life and you will call it fate.',
  es: 'Hasta que hagas consciente lo inconsciente, dirigirá tu vida y lo llamarás destino.',
  fr: "Tant que vous ne rendez pas l'inconscient conscient, il dirigera votre vie et vous appellerez cela le destin.",
  de: 'Bis du das Unbewusste bewusst machst, wird es dein Leben lenken und du wirst es Schicksal nennen.',
  pt: 'Até que você torne o inconsciente consciente, ele dirigirá a sua vida e você vai chamá-lo de destino.'
};
function scJungText(){
  let l = 'en';
  try{ l = String(navigator.language || 'en').slice(0, 2).toLowerCase(); }catch(_){ }
  return SC_JUNG[l] || SC_JUNG.en;
}

/* Il racconto degli anni: un passo, un dato, una frase intera. Jung chiude.
   Si calcola qui, quando serve: prima stava dentro al pannello e restava lì a metà. */
async function scFutureStory(){
  if (typeof fuOpen !== 'function') return;
  const f = scFuture();
  if (!f.birth){
    // La data si chiede QUI, una volta, e finisce nel profilo: non si richiede mai più.
    fuOpen([{ birth: true, kicker: 'Una cosa sola, una volta sola', line: 'Per contare gli anni che hai davanti mi serve la tua data di nascita. Resta sul telefono e non te la richiedo più.',
      onSave: function(v){ scFutureSetBirth(v); const g = scFuture(); g.birth = v; scStore('fl_future', JSON.stringify(g)); scFutureStory(); } }]);
    return;
  }
  const avg = await scAverages(0);
  const days = (avg && avg.days) || 0;
  if (days < SC_LIFE_MIN_DAYS){
    const missing = SC_LIFE_MIN_DAYS - days;
    fuOpen([{ kicker: 'Ancora un po\' di pazienza', big: String(missing), unit: missing === 1 ? 'giorno' : 'giorni',
      line: 'Per dirti quanti anni ti costa il ritmo di adesso mi servono almeno ' + SC_LIFE_MIN_DAYS + ' giorni interi di misure. Su un giorno solo il conto direbbe qualunque cosa, e sarebbe falso.' }]);
    return;
  }
  const age = scAgeExact(f.birth);
  const left = Math.max(0, SC_LIFE_SPAN - age);
  const h = avg.screenMs / SC_H;
  let goalMin = f.goalMin || 0;
  try{ if (!goalMin) goalMin = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ }
  if (!goalMin) goalMin = 120;
  const goalH = goalMin / 60;
  const years = left * h / 24;
  const yearsGoal = left * goalH / 24;
  const back = Math.max(0, years - yearsGoal);
  const backH = back * 365 * 24;
  const backPerYear = left > 0 ? backH / left : 0;
  const daysPerYear = h * 365 / 24;
  const wakePct = Math.min(100, h / SC_WAKE_H * 100);
  const odds = await scSuccessOdds();
  const it = n => Math.round(n).toLocaleString('it-IT');
  const goalTxt = scNum(goalH, 1).replace(',0', '') + (goalH === 1 ? ' ora' : ' ore');
  const last = (typeof orLast === 'function') ? orLast() : null;
  const want = last ? orTargetName(last.target) : '';

  const steps = [];
  steps.push({ kicker: 'Il tempo che hai davanti', big: String(left), unit: 'anni',
    line: 'Hai ' + age + ' anni. Se la vita dura ' + SC_LIFE_SPAN + ', te ne restano ' + left + '.' });
  steps.push({ kicker: 'Se continui così', big: scNum(years, 1), unit: 'anni', tone: 'warn',
    line: 'Ne passerai <strong>' + scNum(years, 1) + '</strong> davanti a uno schermo. È la tua media di adesso, ' + scFmtShort(avg.screenMs) + ' al giorno, portata avanti fino alla fine.' });
  steps.push({ kicker: 'Ogni anno', big: it(daysPerYear), unit: 'giorni', tone: 'warn',
    line: 'Sono <strong>' + it(daysPerYear) + ' giorni interi</strong> all\'anno passati sullo schermo, dal primo minuto all\'ultimo, senza dormire.' });
  steps.push({ kicker: 'Delle tue ore da sveglio', big: Math.round(wakePct) + '%', tone: 'warn',
    line: (wakePct >= 30 ? 'Quasi un terzo' : 'Una parte') + ' di ogni giornata se ne va lì. Il resto è quello che avanza.' });
  steps.push({ kicker: 'Se tieni il tuo obiettivo', big: scNum(yearsGoal, 1), unit: 'anni', tone: 'good',
    line: 'A ' + goalTxt + ' al giorno ne passeresti <strong>' + scNum(yearsGoal, 1) + '</strong>, non ' + scNum(years, 1) + '.' });
  steps.push({ kicker: 'Ti riprendi', big: scLifeSpan(back), tone: 'good',
    line: '<strong>' + scLifeSpan(back) + '</strong> di vita che tornano tuoi' + (want ? ', per diventare <strong>' + esc(want) + '</strong>.' : '.') });
  steps.push({ kicker: 'Ogni anno', big: it(backPerYear), unit: 'ore', tone: 'good',
    line: '<strong>' + it(backPerYear) + ' ore</strong> all\'anno che tornano tue:<br>il tempo di leggere ' + it(backPerYear / 6) + ' libri, o ' + scNum(backPerYear / 10000 * 100, 0) + '% delle diecimila ore che fanno un maestro.' });
  steps.push({ kicker: 'Le tue probabilità di riuscirci, oggi', big: String(odds.pct), unit: '%',
    tone: odds.pct >= 55 ? 'good' : (odds.pct >= 35 ? '' : 'warn'),
    line: 'Con le abitudini che hai adesso. Non è un oroscopo. È la somma di quello che hai fatto finora, e si muove ogni volta che fai qualcosa.' });
  steps.push({ kicker: 'Da dove viene quel numero', list: odds.why.map(w => [w[0], w[1]]) });
  steps.push({ img: 'img/jung.jpg', quote: scJungText(), by: '— Carl Jung' });
  fuOpen(steps);
}

/* ---- le risposte, su questo telefono ---- */
function scFuture(){
  let f = null;
  try{ f = JSON.parse(localStorage.getItem('fl_future') || 'null'); }catch(_){ f = null; }
  f = f || {};
  // La data di nascita è del profilo: si scrive una volta sola, toccando la propria immagine.
  if (!f.birth){
    try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); if (u && u.birth) f.birth = u.birth; }catch(_){ }
  }
  // chi aveva già scritto solo l'età non la riscrive: diventa un 1° gennaio approssimato
  if (!f.birth){
    let old = 0; try{ old = parseInt(localStorage.getItem(SC_AGE_KEY) || '0', 10) || 0; }catch(_){ }
    if (old >= 10 && old <= 99) f.birth = (new Date().getFullYear() - old) + '-01-01';
  }
  if (!f.goalMin){ try{ f.goalMin = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ f.goalMin = 0; } }
  return f;
}
function scFutureSave(){
  const b = document.getElementById('fuBirth'), w = document.getElementById('fuWant');
  const birth = b ? b.value : '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birth)){ toast('Scegli la tua data di nascita'); return; }
  const age = scAgeExact(birth);
  if (age === null || age < 8 || age > 110){ toast('Controlla la data:\nnon torna'); return; }
  const f = scFuture();
  f.birth = birth;
  f.want = w ? w.value.trim().slice(0, 70) : '';
  if (!f.goalMin) f.goalMin = 120;
  if (!scStore('fl_future', JSON.stringify(f))){ toast('Memoria piena:\nnon sono riuscito a salvare'); return; }
  scFutureSetBirth(birth);
  scLifePaint();
}
/* La data finisce anche nel profilo, che è il posto dove l'utente la cerca. */
function scFutureSetBirth(birth){
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null') || { local: true };
    if (u.birth !== birth){ u.birth = birth; scStore('fl_user', JSON.stringify(u)); }
  }catch(_){ }
}
/* localStorage pieno: le immagini del perché e le cache dei giorni lo riempiono davvero, e
   un salvataggio che fallisce in silenzio è il motivo per cui la data di nascita "non si
   salvava mai". Si buttano le cache e si riprova una volta. */
function scStore(key, value){
  try{ localStorage.setItem(key, value); return true; }catch(_){ }
  try{
    const drop = [];
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (k && (k.indexOf('fl_dayrep_') === 0 || k === 'fl_bgs')) drop.push(k);
    }
    drop.forEach(k => { try{ localStorage.removeItem(k); }catch(__){ } });
    localStorage.setItem(key, value);
    return true;
  }catch(_){ return false; }
}
function scFutureGoal(min){
  const f = scFuture();
  f.goalMin = min;
  scStore('fl_future', JSON.stringify(f));
  const host = document.getElementById('fuGoal');
  if (host) host.innerHTML = scFutureGoalChips(min);
}
function scFutureGoalChips(cur){
  return [60, 90, 120, 180, 240].map(m =>
    '<button type="button" class="life-chip' + (cur === m ? ' on' : '') + '" onclick="scFutureGoal(' + m + ')">'
    + (m % 60 === 0 ? (m / 60) + 'h' : Math.floor(m / 60) + 'h' + (m % 60)) + '</button>').join('');
}
/* La data di nascita si scrive una volta e resta: la versione precedente la cancellava a ogni
   "cambia le risposte", e la pagina la richiedeva ogni volta. Adesso "cambiare" vuol dire
   rifare la lettura dell'oracolo; la data la si tocca solo dal profilo. */
function scFutureEdit(){ if (typeof orOpen === 'function') orOpen(); }
/* Anni compiuti, non "anno corrente meno anno di nascita". */
function scAgeExact(birth){
  if (!birth || !/^\d{4}-\d{2}-\d{2}$/.test(birth)) return null;
  const b = new Date(birth + 'T00:00:00');
  if (isNaN(b)) return null;
  const now = new Date();
  let a = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) a--;
  return a;
}
/* "2 anni e 4 mesi", "7 mesi": gli anni da soli, sotto l'unità, non dicono niente. */
function scLifeSpan(years){
  const months = Math.round(years * 12);
  const y = Math.floor(months / 12), mo = months % 12;
  if (y <= 0) return mo + (mo === 1 ? ' mese' : ' mesi');
  if (mo === 0) return y + (y === 1 ? ' anno' : ' anni');
  return y + (y === 1 ? ' anno' : ' anni') + ' e ' + mo + (mo === 1 ? ' mese' : ' mesi');
}

/* ---- quante probabilità hai di riuscirci ----------------------------------------------

   Niente oroscopi: ogni punto viene da una cosa che è successa. I giorni di fila in Modalità
   severa e le sessioni di concentrazione portate a termine aggiungono; le pause del piano
   (blocco rapido messo in pausa, programmi spenti) tolgono. L'elenco degli ingredienti è
   sotto il numero, perché un numero che non si può controllare non serve a nessuno. */
async function scSuccessOdds(){
  const why = [];
  let pct = 40;

  let streak = 0;
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (st && st.start && typeof blkDaysBetween === 'function' && typeof blkToday === 'function'){
      streak = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
    }
  }catch(_){ }
  const sPts = Math.min(25, Math.round(streak * 2.5));
  if (sPts) why.push([streak + (streak === 1 ? ' giorno di fila con il piano attivo' : ' giorni di fila con il piano attivo'), '+' + sPts]);

  let ff7 = 0;
  try{
    const since = Date.now() - 7 * 86400000;
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(x => { if (x && x.ok && x.at >= since) ff7++; });
  }catch(_){ }
  const fPts = Math.min(15, ff7 * 3);
  if (fPts) why.push([ff7 + (ff7 === 1 ? ' sessione FullFocus questa settimana' : ' sessioni FullFocus questa settimana'), '+' + fPts]);

  // giorni degli ultimi sette in cui sei rimasto sotto il tuo obiettivo
  let under = 0, goalMin = scFuture().goalMin || 0;
  if (goalMin > 0){
    for (let i = 1; i <= 7; i++){
      const r = await scReport(i);
      if (r && r.granted && r.screenMs > 0 && r.screenMs / 60000 <= goalMin) under++;
    }
  }
  const uPts = Math.min(10, under * 2.5);
  if (uPts) why.push([under + (under === 1 ? ' giorno sotto il tuo obiettivo' : ' giorni sotto il tuo obiettivo'), '+' + Math.round(uPts)]);

  let breaks = 0;
  try{
    const since = Date.now() - 30 * 86400000;
    (JSON.parse(localStorage.getItem('fl_breaks') || '[]') || []).forEach(t => { if (t >= since) breaks++; });
  }catch(_){ }
  const bPts = Math.min(35, breaks * 5);
  if (bPts) why.push([breaks + (breaks === 1 ? ' volta che hai messo in pausa il piano (30 giorni)' : ' volte che hai messo in pausa il piano (30 giorni)'), '−' + bPts]);

  pct = pct + sPts + fPts + Math.round(uPts) - bPts;
  pct = Math.max(5, Math.min(95, Math.round(pct)));
  if (!why.length) why.push(['Non hai ancora abbastanza storia, si parte da qui', '40']);
  return { pct: pct, why: why };
}

/* ---------------------------------------------------------------------------------------
   STYLE
   --------------------------------------------------------------------------------------- */
(function scStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '@property --angle{syntax:"<angle>";initial-value:0deg;inherits:false}',
    /* the night sky, edge to edge: the tab pads by 18 and the screen by 22, so it has to give
       back 40 on each side to touch the glass */
    '.prof-sky{position:relative;margin:0 calc(-1 * var(--bleed, 40px));padding:22px 26px 78px;overflow:hidden;',
    '  background:linear-gradient(180deg,rgba(2,9,38,.5),rgba(2,9,38,.74)),url("img/dream-night.jpg") center/cover no-repeat,linear-gradient(180deg,#020926 0%,#06214F 30%,#1B4E8C 62%,#0C3A76 82%,#08295B 100%);background-color:#020926}',
    '.starfield{position:absolute;inset:0;pointer-events:none;z-index:0;overflow:hidden}',
    '.prof-sky > *:not(.starfield):not(.prof-clouds){position:relative;z-index:1}',
    '.star{position:absolute;background:#fff;width:1.2px;height:1.2px;border-radius:50%;opacity:.18;animation:twinkle 6s linear infinite both}',
    '.star.big{width:2px;height:2px;opacity:.35}',
    '@keyframes twinkle{0%,100%{opacity:.15;transform:scale(1)}50%{opacity:1;transform:scale(1.7)}}',
    '.prof-clouds{position:absolute;left:0;right:0;bottom:-1px;z-index:2;line-height:0;color:var(--bg);pointer-events:none}',
    '.prof-clouds svg{display:block;width:100%;height:64px}',
    '.prof-sky .prof-hero{padding:6px 8px 0}',
    '.prof-sky .prof-hero .av{width:78px;height:78px;font-size:32px;cursor:pointer;box-shadow:0 0 0 4px rgba(255,255,255,.14),0 12px 30px rgba(0,0,0,.4)}',
    '.prof-sky .prof-hero h2{color:#fff;font-size:31px;margin:14px 0 2px;text-shadow:0 2px 12px rgba(0,0,0,.5)}',
    /* la riga che ruota (data, mantra dell'inizio, mantra di adesso) parla con la stessa
       voce del livello: stesso azzurro, niente corsivo, niente gerarchia inventata */
    '.prof-sky .prof-hero .since{color:#9EC1FF;font-style:normal;font-weight:600;min-height:34px;padding:0 18px}',
    '.prof-sky .prof-hero small{color:rgba(255,255,255,.6)}',
    /* the black box with the spinning glow of .wishlist-quote */
    '.pf-box{position:relative;margin-top:18px;border-radius:25px;background:#000;color:#fff;padding:16px 0 12px;z-index:1}',
    '.pf-box::before{content:"";position:absolute;inset:-8px;border-radius:25px;background-image:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(12px);animation:spin 3s linear infinite;z-index:-3;pointer-events:none}',
    '.pf-box::after{content:"";position:absolute;inset:0;background:#000;border-radius:25px;z-index:-2;pointer-events:none}',
    '@keyframes spin{from{--angle:0deg}to{--angle:360deg}}',
    '.pf-track{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;scrollbar-width:none}',
    '.pf-track::-webkit-scrollbar{display:none}',
    '.pf-slide{flex:0 0 100%;scroll-snap-align:start;box-sizing:border-box;padding:6px 20px 4px;min-height:170px;text-align:center}',
    '.pf-dots{display:flex;justify-content:center;gap:6px;margin-top:10px}',
    '.pf-dots i{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.3)}.pf-dots i.on{background:#fff}',
    '.pf-opal{display:flex;justify-content:space-around;align-items:flex-start;padding-top:22px}',
    '.pf-stat{text-align:center;cursor:pointer}',
    '.pf-stat .ico{display:block;font-size:46px;line-height:1}',
    '.pf-stat .glow-mint{filter:drop-shadow(0 0 14px rgba(140,240,200,.9)) drop-shadow(0 0 4px rgba(140,240,200,.9))}',
    '.pf-stat .glow-fire{filter:drop-shadow(0 0 14px rgba(255,150,40,.9)) drop-shadow(0 0 4px rgba(255,200,80,.9))}',
    '.pf-stat .num{display:block;font:800 34px/1.1 var(--font-display);margin-top:10px}',
    '.pf-stat .num.mint{color:#8CF0C8}.pf-stat .num.gold{color:#F5C542}',
    /* IL PUNTEGGIO DEL NUOVO TE HA UN COLORE SUO, e non e' il verde delle ore di focus.
       Passa da una variabile perche' si cambia dalle impostazioni: il verde dice «va bene
       cosi'», l'azzurro dice «continua», e quale delle due funzioni su una persona si scopre
       solo provandole per qualche settimana. */
    '.pf-stat .num.neo{color:var(--neo-soft,#4FB8FF)}',
    '.pf-stat .num.neo + small{color:var(--neo-soft,#4FB8FF)}',
    '.pf-stat .glow-neo{filter:drop-shadow(0 0 14px var(--neo-glow,rgba(79,184,255,.9))) drop-shadow(0 0 4px var(--neo-glow,rgba(79,184,255,.9)))}',
    '.pf-stat small{display:flex;align-items:center;justify-content:center;gap:5px;font:700 11px var(--font-body);letter-spacing:.12em;margin-top:4px}',
    '.pf-stat .num.mint + small{color:#8CF0C8}.pf-stat .num.gold + small{color:#F5C542}',
    '.pf-stat i.q{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;width:14px;height:14px;border-radius:50%;border:1px solid currentColor;font:700 9px/1 var(--font-body);font-style:normal;opacity:.8;margin-left:4px;vertical-align:middle;padding-top:1px}',
    /* The day's score, in the sky under the name. The padding above it is the point: it is
       the first thing the eye lands on after the name, and it needs room to be read as a
       result rather than as a caption of the portrait. */
    '.prof-scorebox{display:flex;flex-direction:column;align-items:center;text-align:center;color:#fff;padding:46px 22px 8px}',
    '.pf-quote{font-weight:700}',
    '.pf-quote strong{display:block;font-size:14px;margin-bottom:12px}',
    '.pf-text{display:block;font-size:1.2em;line-height:1.45;min-height:52px}',
    '.pf-author{display:block;font-style:italic;font-weight:500;margin-top:10px;color:rgba(255,255,255,.85);text-align:center}',
    '.pf-details{margin-top:14px;border:none;border-radius:99px;background:rgba(255,255,255,.14);color:#fff;font:700 12.5px var(--font-body);padding:9px 18px;cursor:pointer;backdrop-filter:blur(6px)}',
    '.typewriter-char{opacity:0;display:inline;transition:opacity .05s linear}.typewriter-char.visible{opacity:1}',
    '.typewriter-cursor{display:inline;color:#fff;animation:blink-caret .8s step-end infinite;font-weight:normal!important}',
    '@keyframes blink-caret{from,to{opacity:0}50%{opacity:1}}',
    /* the scores at the top of the Blocco tab */
    '.blk-scores{margin:14px 0 4px;text-align:center}',
    '.bs-total{display:inline-block;cursor:pointer}',
    '.bs-total small{display:block;font:600 12px var(--font-body);color:var(--muted)}',
    '.bs-total b{display:block;font:800 38px/1 var(--font-display);color:var(--navy)}',
    '.bs-total .caret{font-size:15px;color:var(--blue);margin-left:4px;vertical-align:middle}',
    '.bs-row{display:flex;justify-content:space-around;gap:8px;margin-top:2px}',
    '.bs-pill{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer}',
    '.bs-pill .cap{position:relative;display:flex;align-items:center;justify-content:center;gap:6px;width:100%;height:44px;border-radius:22px;background:#EEF4FF;font:800 18px var(--font-display);color:var(--navy)}',
    '.bs-pill .cap .ic{font-size:15px}',
    '.bs-pill .arc{position:absolute;inset:0;width:100%;height:100%;overflow:visible}',
    '.bs-pill .arc rect{fill:none;stroke:var(--blue);stroke-width:3;stroke-linecap:round;transform:rotate(-90deg);transform-origin:50% 50%}',
    '.bs-pill small{font:600 12px var(--font-body);color:var(--muted)}',
    'body.dark .bs-pill .cap{background:#1B2E52;color:#fff}body.dark .bs-total b{color:#fff}',
    /* scores, shared with the breakdown screen */
    '.sc-wrap{margin:6px 0}',
    '.sc-total{display:inline-block;cursor:pointer}',
    '.sc-total small{display:block;font:600 12px var(--font-body);color:var(--muted)}',
    '.sc-total b{display:block;font:800 40px/1 var(--font-display);color:var(--navy)}',
    '.sc-wrap{text-align:center}',
    '.sc-bracket{display:flex;justify-content:center;height:16px;margin:6px 0 4px;position:relative}',
    '.sc-bracket::before{content:"";position:absolute;left:18%;right:18%;top:8px;border-top:1.5px solid var(--line)}',
    '.sc-bracket::after{content:"";position:absolute;left:50%;top:0;height:8px;border-left:1.5px solid var(--line)}',
    '.sc-bracket i{position:absolute;top:8px;height:8px;border-left:1.5px solid var(--line)}',
    '.sc-bracket i:nth-child(1){left:18%}.sc-bracket i:nth-child(2){left:50%}.sc-bracket i:nth-child(3){right:18%}',
    '.sc-row{display:flex;justify-content:space-around;gap:8px}',
    '.sc-pill{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;transition:opacity .25s,filter .25s}',
    '.sc-opt{display:flex;align-items:center;gap:14px;margin:18px 0 6px;padding:14px 16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sc-opt{background:#12203A;border-color:#22345A}.sc-opt > div{flex:1}.sc-opt b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .sc-opt b{color:#fff}.sc-opt small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.sc-pill .cap{display:flex;align-items:center;gap:6px;padding:9px 16px;border-radius:99px;background:#EEF4FF;border:2px solid transparent;font:800 18px var(--font-display);color:var(--navy)}',
    '.sc-pill .cap .ic{font-size:15px}',
    '.sc-pill small{font:600 12px var(--font-body);color:var(--muted)}',
    '.sc-pill.on .cap{border-color:var(--blue);background:#E6F2FD;box-shadow:0 0 0 3px rgba(0,117,227,.12)}',
    '.sc-pill.on small{color:var(--blue)}',
    '.sc-pill.dim,.sc-total.dim{opacity:.35;filter:blur(1.2px)}',
    /* 0.9.301, Andrea: titolo sopra e testo sotto, al centro (prima titolo a sinistra e testo a destra) */
    '.sc-grant{display:flex;flex-direction:column;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);border-radius:16px;padding:16px 18px;margin:16px 0 4px;cursor:pointer;text-align:center;color:#fff}',
    '.sc-grant b{font:800 16px var(--font-body);display:block;color:#fff}',
    '.sc-grant small{display:block;font:500 13px/1.45 var(--font-body);color:rgba(255,255,255,.85)}',
    '.rep-senza .rep-top{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;padding:22px 18px 20px}.rep-senza-t{font:800 17px var(--font-body);color:var(--navy,#14234A)}',
    '.rep-senza-p{margin:0;font:500 14px/1.5 var(--font-body);color:var(--muted,#5B6B86);max-width:300px}',
    '.rep-senza-b{margin-top:6px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 14px var(--font-body);padding:11px 18px;cursor:pointer}',
    'body.dark .rep-senza-t{color:#fff}body.dark .rep-senza-p{color:#B9C7DD}',
    '.sc-grant .chev{margin-left:auto;color:#fff}',
    '.sc-daynav{display:flex;align-items:center;justify-content:center;gap:6px;margin:0 auto}',
    '.sc-daynav b{font:700 15px var(--font-display);color:var(--navy);min-width:60px;text-align:center}',
    '.sc-daynav .iconbtn:disabled{opacity:.3}',
    '.sc-q{font:800 17px var(--font-display);color:var(--navy);margin:22px 0 6px}',
    '.sc-top{position:relative}.sc-titolo{position:absolute;left:56px;right:56px;text-align:center;font:800 19px var(--font-display);color:var(--navy)}body.dark .sc-titolo{color:#fff}',
    '.sc-per{display:flex;gap:4px;margin:4px 16px 14px;padding:4px;border-radius:14px;background:rgba(0,30,68,.06)}body.dark .sc-per{background:rgba(255,255,255,.06)}',
    '.sc-per button{flex:1;border:0;border-radius:10px;padding:9px 4px;background:transparent;font:700 14px var(--font-body);color:var(--muted);cursor:pointer}',
    '.sc-per button.on{background:var(--card,#fff);color:var(--navy);box-shadow:0 2px 8px rgba(0,30,68,.1)}body.dark .sc-per button.on{background:#1C2B4D;color:#fff}',
    '.sc-gauge{position:relative;width:min(78vw,300px);margin:6px auto 0}.sc-gauge svg{display:block;width:100%;height:auto}',
    '.sc-g-track{fill:none;stroke:rgba(0,30,68,.1);stroke-width:14;stroke-linecap:round}body.dark .sc-g-track{stroke:rgba(255,255,255,.12)}',
    '.sc-g-track.pieno{stroke-linecap:butt}',
    '.sc-g-fill{fill:none;stroke-width:14;stroke-linecap:butt}.sc-g-tac{stroke:#fff;stroke-width:4;stroke-linecap:round;filter:drop-shadow(0 1px 2px rgba(0,0,0,.35))}',
    '.sc-g-mid{position:absolute;left:0;right:0;top:34%;text-align:center}.sc-g-mid b{display:block;font:900 54px/1 var(--font-display);color:var(--navy)}body.dark .sc-g-mid b{color:#fff}',
    '.sc-g-mid span{display:inline-flex;align-items:center;gap:6px;margin-top:8px;font:700 14px var(--font-body);color:var(--muted)}.sc-g-mid i{width:8px;height:8px;border-radius:2px}',
    '.sc-panel{margin:8px 0 0;padding:16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sc-panel{background:#14234A;border-color:rgba(255,255,255,.1)}',
    '.sc-panel-f{margin:0 0 14px;font:600 15px/1.55 var(--font-body);color:var(--navy)}body.dark .sc-panel-f{color:#fff}',
    '.sc-panel-q{display:flex;align-items:center;gap:8px;margin:0}.sc-panel-q b{font:800 15px var(--font-display);color:var(--navy)}body.dark .sc-panel-q b{color:#fff}',
    '.sc-panel-t{margin:6px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.sc-ff{margin:28px 0 4px;font:800 18px var(--font-display);color:var(--navy)}body.dark .sc-ff{color:#fff}',
    '.sc-i{width:24px;height:24px;margin-left:10px;font-size:12px;vertical-align:2px}',
    '.sc-txt{font:500 13px/1.6 var(--font-body);color:var(--muted);margin:0 0 16px}',
    '.sc-met{padding:14px 0;border-bottom:1px solid var(--line)}',
    '.sc-met .head{display:flex;align-items:baseline;gap:10px}',
    '.sc-met .head b{font:800 15px var(--font-display);color:var(--navy)}',
    '.sc-met .head .val{font:600 14px var(--font-body);color:var(--muted)}',
    '.sc-met .delta{margin-left:auto;font:800 13px var(--font-body)}',
    '.sc-met .delta.good{color:#0E7C6B}.sc-met .delta.bad{color:var(--red)}.sc-met .delta.flat{color:var(--muted)}',
    /* 0.9.295, Andrea: "nei fattori di valutazione, nel Giorno, le frecce e i numeri sono bianchi finche' non cambio periodo".
       Al buio il verde scuro (#0E7C6B) su fondo blu notte non si leggeva, e il guardiano del contrasto (darkfix.js) lo
       ridipingeva di bianco al primo disegno; cambiando periodo il pannello si ridisegnava dopo il suo passaggio. Al buio i
       colori sono quelli chiari, e il guardiano non ha niente da correggere. */
    'body.dark .sc-met .delta.good{color:#3DDC97!important}body.dark .sc-met .delta.bad{color:#FF7A85!important}body.dark .sc-met .delta.flat{color:#9FB2D0!important}',
    '.sc-bar{position:relative;height:10px;border-radius:99px;background:#EDF3FA;margin-top:12px;overflow:hidden}',
    '.sc-bar .fill{position:absolute;top:0;bottom:0;border-radius:99px}',
    '.sc-bar .fill.good{background:linear-gradient(90deg,#9FE3D2,#14A38B)}.sc-bar .fill.bad{background:linear-gradient(90deg,#FFC2C8,#E63946)}.sc-bar .fill.flat{background:#C3D3E4}',
    '.sc-bar .mark{position:absolute;left:50%;top:-2px;bottom:-2px;width:3px;background:#fff;box-shadow:0 0 0 1px rgba(0,30,68,.25);border-radius:2px}',
    '.sc-avg{display:block;text-align:center;font:700 9.5px var(--font-body);letter-spacing:.08em;color:var(--faint);margin-top:4px}',
    '.sc-sleep{display:flex;align-items:center;gap:10px;margin-top:8px}',
    '.sc-sleep .q{font:800 13px var(--font-body);color:#0E7C6B;margin-left:auto;order:2}',
    '.sc-sleep .bars{display:flex;gap:5px;flex:1}',
    '.sc-sleep .bars i{flex:1;height:7px;border-radius:99px;background:#EDF3FA}.sc-sleep .bars i.on{background:#14A38B}',
    '.sc-none{font:500 12px/1.5 var(--font-body);color:var(--muted);margin:6px 0 0}',
    '.sc-foot{font:500 11.5px/1.5 var(--font-body);color:var(--faint);margin:16px 0 0;text-align:center}',
    /* tooltip */
    '.sc-tip{display:none;position:absolute;z-index:120;background:#22314A;color:#fff;font:500 13px/1.5 var(--font-body);border-radius:12px;padding:12px 14px;box-shadow:0 12px 30px rgba(0,30,68,.35)}',
    '.sc-tipbtn{display:block;width:100%;margin-top:12px;border:0;border-radius:99px;background:#fff;color:#0B1A3A;padding:10px;font:800 12px var(--font-body);cursor:pointer}',
    '.sc-tip .txt{white-space:pre-line;display:block;text-align:center}',
    '.sc-tip .dati{display:block;margin:12px 0 0;padding:11px 0 0 18px;text-align:left;list-style:disc;',
      'border-top:1px solid rgba(255,255,255,.16);font:600 13px/1.75 var(--font-body);color:#fff}',
    '.sc-tip .dati li{padding-left:2px}',
    '.sc-tip .dati li::marker{color:#4FB8FF}',
    '.sc-tip .arrow{position:absolute;top:-7px;width:14px;height:14px;background:#22314A;transform:rotate(45deg);border-radius:2px}',
    /* report panel */
    '.rep-panel{background:#fff;border:1px solid var(--line);border-radius:22px;padding:18px 16px;margin:18px 0;position:relative}',
    /* La riserva di dopamina dentro alla panoramica: la card e' gia' una card, qui serve
       solo l'aria sopra ai tre puntini. */
    '.rep-dopa{padding-top:34px}',
    '.sc-dopa-riga{display:flex;align-items:center;gap:14px;width:100%;margin:22px 0 4px;padding:16px;box-sizing:border-box;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);color:var(--navy);text-align:left;font:inherit;cursor:pointer}',
    '.sc-dopa-riga > span{font-size:24px;line-height:1}.sc-dopa-riga > div{flex:1;min-width:0}',
    '.sc-dopa-riga b{display:block;font:800 16px var(--font-body);color:var(--navy)}.sc-dopa-riga small{display:block;margin-top:3px;font:500 13.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sc-dopa-riga svg{flex:none;color:var(--muted)}',
    /* il titoletto di sezione dentro ai menu (categorie, da dove) */
    '.rep-menu .arb-mtit,.ins-menu .arb-mtit{margin:8px 10px 4px;font:800 9.5px var(--font-body);',
      'letter-spacing:.14em;text-transform:uppercase;color:var(--faint)}',
    '.rep-menu .arb-mtit:first-child,.ins-menu .arb-mtit:first-child{margin-top:2px}',
    /* il verdetto della notte, in cima: una riga di tacchette e una parola */
    '.sc-verdetto{margin:16px 0 4px;display:flex;justify-content:center}',
    '.sc-verdetto .sc-sleep{margin:0}',
    '.rep-more{position:absolute;top:10px;right:10px;width:34px;height:34px;border-radius:50%;border:1px solid var(--line);background:#fff;color:var(--navy);font:800 18px/1 var(--font-body);cursor:pointer;z-index:2}',
    '.rep-scrim{position:fixed;inset:0;z-index:4;background:rgba(3,10,26,.55);opacity:0;transition:opacity .2s ease}',
    '.rep-scrim.in{opacity:1}',
    '.rep-scrim[hidden]{display:none}',
    '.rep-menu{position:absolute;top:48px;right:10px;z-index:5;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 12px 30px rgba(0,30,68,.18);padding:6px;min-width:210px}',
    '.rep-menu[hidden]{display:none}',
    '.rep-menu button{display:block;width:100%;text-align:left;border:0;background:none;border-radius:10px;padding:11px 12px;font:600 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.rep-menu button.on{background:var(--blue-soft);color:var(--blue)}',
    'body.dark .rep-more,body.dark .rep-menu{background:#12203A;border-color:#22345A;color:#fff}body.dark .rep-menu button{color:#fff}',
    '.rep-top{text-align:center}',
    '.rep-top small{display:block;font:600 13px var(--font-body);color:var(--muted)}',
    '.rep-big{display:block;font:800 40px/1.15 var(--font-display);color:var(--navy);margin:4px 0 8px}',
    '.rep-big-g{font-size:32px;margin-bottom:2px}.rep-big-tot{display:block;margin:0 0 10px;font:600 13.5px var(--font-body);color:var(--muted)}',
    '.rep-badge{display:inline-block;font:700 12px var(--font-body);padding:5px 12px;border-radius:99px}',
    '.rep-badge.up{color:var(--red);background:var(--red-soft)}.rep-badge.down{color:#0E7C6B;background:#E2F6F2}.rep-badge.flat{color:var(--muted);background:rgba(0,30,68,.07)}',
    /* il periodo: un'intestazione che si tocca, non un francobollo in un angolo */
    '.rep-rangebtn{display:inline-flex;align-items:center;gap:7px;margin:0 auto;border:0;background:none;color:var(--muted);font:600 13px var(--font-body);cursor:pointer;padding:4px 8px}',
    '.rep-rangebtn i{width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:5px solid currentColor;opacity:.8}',
    '.rep-rangemenu{left:50%;right:auto;transform:translateX(-50%);top:54px}',
    /* il grafico: barre chiare, griglia con i valori a destra, l'ora corrente segnata */
    '.rp-chart{margin-top:20px}',
    '.rep-panel .rep-solo-prot{display:none}#tab-blocco .rep-panel .rep-solo-prot{display:block}#tab-blocco .rep-panel .rep-solo-dream{display:none}',
    '.rp-bars{position:relative;display:flex;align-items:flex-end;gap:3px;height:120px;padding-right:34px;border-bottom:1px solid var(--line)}',
    /* 0.9.290, Andrea: "i minuti escono dal pannello". La riga arrivava fino al bordo e l'etichetta stava 34 px piu' in la':
       la riga si ferma prima della colonna delle etichette, e l'etichetta resta dentro. */
    '.rp-bars .g{position:absolute;left:0;right:34px;border-top:1px solid rgba(0,30,68,.08);pointer-events:none}',
    '.rp-bars .g span{position:absolute;right:-34px;top:-8px;width:30px;text-align:left;font:600 10px var(--font-body);color:var(--muted)}',
    '.rp-bars > b{flex:1;min-width:0;border-radius:3px 3px 0 0;background:#BCE0FF;transition:height .5s cubic-bezier(.2,.8,.2,1)}',
    '.rp-bars > b.now{background:var(--blue,#006FCF);box-shadow:0 0 0 1px rgba(0,111,207,.35)}',
    '.rp-bars > b[onclick]{cursor:pointer;transition:height .5s cubic-bezier(.2,.8,.2,1),opacity .25s}.rp-bars.con-sel > b{opacity:.3}.rp-bars.con-sel > b.sel{opacity:1;background:var(--blue,#006FCF)}',
    'body.dark .rp-bars > b:not(.now):not(.sel){background:rgba(140,198,255,.24)}body.dark .rp-bars .g{border-top-color:rgba(255,255,255,.08)}',
    '.rp-axis{display:flex;gap:3px;padding-right:34px;margin-top:6px}',
    '.rp-axis span{flex:1;min-width:0;text-align:center;font:600 10px var(--font-body);color:var(--muted);white-space:nowrap;overflow:visible}',
    '.rep-cards{display:flex;gap:10px;margin-top:16px}',
    '.rep-card{flex:1;border:1px solid var(--line);border-radius:14px;padding:12px 14px}',
    '.rep-card small{display:flex;align-items:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.rep-metrics{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin:0 calc(-1 * var(--bleed, 0px)) 12px;padding:2px var(--bleed, 0px) 4px}',
    '.rep-metrics::-webkit-scrollbar{display:none}',
    '.rep-metrics button{flex:0 0 auto;border:1px solid var(--line);background:#fff;border-radius:99px;padding:8px 14px;font:700 12px var(--font-body);color:var(--muted);white-space:nowrap;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.rep-metrics button.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .rep-metrics button{background:#12203A;border-color:#22345A}',
    'body.dark .rep-metrics button.on{background:var(--blue);border-color:var(--blue)}',
    '.rep-card small i{margin-left:auto;width:18px;height:18px;border-radius:50%;border:1.5px solid var(--faint);color:var(--faint);font:700 10px/16px var(--font-body);text-align:center;font-style:normal;cursor:pointer}',
    '.rep-card b{display:flex;align-items:center;gap:8px;font:800 24px var(--font-display);color:var(--navy);margin-top:6px}',
    '.rep-card b em{font:700 12px var(--font-body);font-style:normal;padding:3px 8px;border-radius:99px}',
    '.rep-card b em.down{color:#0E7C6B;background:#E2F6F2}.rep-card b em.up{color:var(--red);background:var(--red-soft)}',
    '.rep-att{margin-top:18px}',
    '.rep-att > b{display:block;font:800 16px var(--font-display);color:var(--navy);margin-bottom:12px}',
    '.rep-row{display:flex;align-items:center;gap:12px;padding:8px 0;cursor:pointer}',
    '.rep-row img,.rep-row .ico{width:36px;height:36px;border-radius:10px;flex:none;object-fit:cover}',
    '.rep-row .ico{background:var(--blue);color:#fff;display:flex;align-items:center;justify-content:center;font:800 15px var(--font-display)}',
    '.rep-row .nm{flex:1;min-width:0}',
    '.rep-row .nm span{display:block;font:600 13px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.rep-row .track{display:block;height:4px;margin-top:6px;border-radius:99px;background:repeating-linear-gradient(90deg,#D6E1EE 0 6px,transparent 6px 10px)}',
    '.rep-row .track b{display:block;height:100%;border-radius:99px;background:var(--navy)}',
    '.rep-row .tm{font:800 13px var(--font-body);color:var(--navy);flex:none}',
    'body.dark .rep-panel,body.dark .rep-card{background:#12203A;border-color:#22345A}',
    'body.dark .rep-big,body.dark .rep-att > b,body.dark .rep-row .nm span,body.dark .rep-row .tm,body.dark .rep-card b,body.dark .sc-total b,body.dark .sc-q,body.dark .sc-met .head b{color:#fff}',
    'body.dark .sc-pill .cap{background:#1B2E52;color:#fff}body.dark .rep-row .track b{background:#8FB4FF}',
    /* Ispirazione quotidiana */
    '#s-inspire{padding:0}',
    '.insp-sky{position:relative;flex:1;overflow-y:auto;display:flex;flex-direction:column;padding:22px 22px calc(24px + env(safe-area-inset-bottom));',
    '  background:linear-gradient(180deg,rgba(3,10,26,.45),rgba(3,10,26,.82)),url("img/dream-night.jpg") center/cover no-repeat,#0A1830}',
    '.insp-sky > *:not(.starfield){position:relative;z-index:1}',
    '.insp-bar b{font:700 15px var(--font-display);color:#fff;flex:1;min-width:0;text-align:center;margin-right:48px}',
    '.insp-bar .iconbtn.light{background:rgba(255,255,255,.15);color:#fff}',
    '.insp-days{display:flex;gap:8px;justify-content:center;margin:8px 0 26px;flex-wrap:wrap}',
    '.insp-day{width:38px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.22);background:rgba(255,255,255,.1);color:#fff;font:700 14px var(--font-body);cursor:pointer}',
    '.insp-day{position:relative}.insp-day.chiuso{opacity:.78;padding-bottom:12px}.insp-lock-ico{position:absolute;left:50%;bottom:3px;transform:translateX(-50%);font-size:9px;line-height:1;font-style:normal}',
    '.insp-day.on{background:#fff;color:#0A1830;border-color:#fff}',
    '.insp-date{text-align:center;color:#fff;margin-bottom:20px}',
    '.insp-date b{display:block;font:800 42px/1 var(--font-display)}',
    '.insp-date span{font:600 13px var(--font-body);opacity:.85}',
    /* Lo stesso carattere della frase del giorno sulla pagina Wishlist del sito: Poppins
       in grassetto, 1.4em del corpo (19.5px), interlinea 1.714. Non un serif diverso. */
    '.insp-quote{font:700 19.5px/1.714 var(--font-body);color:#fff;text-align:center;text-shadow:0 2px 12px rgba(0,0,0,.45);margin:0}',
    '.insp-quote .ln > i{animation:bhLine .85s cubic-bezier(.22,.61,.36,1) forwards;animation-delay:.15s}',
    '.insp-author{font:italic 500 14px var(--font-body);color:rgba(255,255,255,.85);text-align:center;margin-top:16px}',
    '.insp-acts{display:flex;justify-content:center;gap:14px;margin:28px 0}',
    '.insp-act{width:46px;height:46px;border-radius:50%;border:none;background:rgba(255,255,255,.16);color:#fff;font-size:18px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}',
    /* 0.9.267, Andrea: i due blocchi si toccavano ed erano trasparenti (poco leggibili): fondo scuro e 12 px di aria */
    '.insp-lock{display:flex;align-items:center;gap:12px;background:rgba(10,30,70,.78);border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:14px;margin-top:auto}',
    '.insp-lock + .insp-lock,.insp-lock + #foRiga,#foRiga > .insp-lock{margin-top:12px}',
    '.insp-lock > div{flex:1;min-width:0}',
    '.insp-lock b{display:block;font:700 13.5px/1.35 var(--font-body);color:#fff}',
    '.insp-lock small{display:block;font:500 11.5px/1.45 var(--font-body);color:rgba(255,255,255,.75);margin-top:3px}',
    /* the two ways to share, under the share button */
    '.insp-share-menu{display:flex;flex-direction:column;gap:8px;margin:-14px 0 18px}',
    '.insp-share-menu[hidden]{display:none}',
    '.insp-share-menu button{display:block;width:100%;text-align:left;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.12);border-radius:14px;padding:12px 16px;color:#fff;cursor:pointer;backdrop-filter:blur(6px)}',
    '.insp-share-menu b{display:block;font:700 13.5px var(--font-body)}',
    '.insp-share-menu small{display:block;font:500 11.5px var(--font-body);color:rgba(255,255,255,.7);margin-top:2px}',
    '.insp-credit{margin:0 0 14px;text-align:center;font:500 11px var(--font-body);color:rgba(255,255,255,.55);cursor:pointer}',
    '.insp-credit b{font-weight:700;color:rgba(255,255,255,.8)}',
    /* "Se continui cosi": the closing panel of the Report */
    /* l'aura della bolla della Modalità severa, intorno alla card: la stessa luce che gira */
    '.life-intro{padding:22px 0 4px}',
    '.life-sub{margin:10px 18px 16px;font:italic 600 13px/1.6 var(--font-body);color:var(--muted);text-align:center}',
    '.life-sub i{display:block;margin-top:6px;font:600 12px var(--font-body);font-style:normal;color:var(--faint)}',
    /* Jung: il ritratto a destra, la frase nella nebbia a sinistra, nella lingua del telefono */
    '.jung{position:relative;margin:24px -6px -6px;border-radius:18px;overflow:hidden;aspect-ratio:3/2;',
    '  background:url("img/jung.jpg") center/cover no-repeat;animation:sevRise .9s ease-out both;animation-delay:.35s}',
    '.jung-in{position:absolute;inset:0;width:56%;display:flex;flex-direction:column;justify-content:center;padding:16px 8px 16px 16px;text-align:left}',
    /* un velo chiaro sotto le parole: la nebbia dell'illustrazione cambia tono, il testo no */
    '.jung-in::before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(238,243,240,.82),rgba(238,243,240,.68) 72%,rgba(238,243,240,0));z-index:0}',
    '.jung-in p,.jung-in small{position:relative;z-index:1}',
    '.jung-in p{margin:0;font:700 13px/1.45 var(--font-display);color:#0F2B33;letter-spacing:.1px}',
    '.jung-in small{display:block;margin-top:10px;font:800 11px var(--font-body);color:#1C4652}',
    '@media (min-width:400px){.jung-in p{font-size:14.5px}}',
    '.rep-locked{margin:12px 0 0;padding-top:10px;border-top:1px solid var(--line);font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.rep-locked b{color:var(--navy);font-weight:800}',
    'body.dark .rep-locked b{color:#fff}',
    '.rep-locked button{border:0;background:none;padding:0;margin-left:4px;font:800 12px var(--font-body);color:var(--blue,#0075E3);cursor:pointer;text-decoration:underline}',
    '.life-wrap{position:relative;margin:6px 0 14px;isolation:isolate}',
    /* Lo stesso meccanismo della bolla (.pf-box::before): non gira l'elemento, gira l'ANGOLO del
       conic-gradient, che è una proprietà registrata (@property --angle) e quindi animabile.
       Prima c'era "from 0deg" con un'animazione che non esisteva: il gradiente restava fermo. */
    '.life-wrap::before{content:"";position:absolute;inset:-8px;border-radius:30px;z-index:-1;pointer-events:none;',
    '  background:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(13px);animation:spin 3s linear infinite}',
    /* "Il primo passo" chiude la scheda, staccato dal pannello del futuro */
    '#sevStreakFoot{margin:72px 0 48px}',
    '.life{background:var(--navy);color:#fff;border-radius:22px;padding:30px 22px 24px;margin:0;text-align:center;position:relative;z-index:1}',
    '.life-q{margin:18px 0 0;text-align:left}',
    '.life-q label{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.66);margin-bottom:8px}',
    '.life-q input{width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.08);border-radius:14px;padding:13px 16px;font:600 15px var(--font-body);color:#fff}',
    '.life-q input::placeholder{color:rgba(255,255,255,.4);font-weight:500}',
    '.life-chips{display:flex;gap:8px;flex-wrap:wrap}',
    '.life-chip{border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.06);border-radius:99px;padding:10px 16px;font:700 13px var(--font-body);color:#fff;cursor:pointer}',
    '.life-chip.on{background:#fff;color:var(--navy);border-color:#fff}',
    '.life-go{width:100%;margin-top:20px;border:0;border-radius:99px;background:#fff;color:var(--navy);padding:15px;font:800 14px var(--font-body);letter-spacing:.04em;cursor:pointer}',
    '.life-go + .life-edit{margin-top:12px}',
    '.life-who{margin-top:14px;font-size:64px;line-height:1;filter:drop-shadow(0 8px 18px rgba(0,0,0,.35))}',
    '.life-big.who{font-size:30px;line-height:1.15;margin-top:10px;color:#fff}',
    /* 0.9.305: in scuro darkfix.js tinge di verde ogni .life-big: il nome di chi rischi di diventare resta bianco come in chiaro (il verde e' solo per i miglioramenti) */
    'body.dark .life-big.who{color:#fff !important}',
    '.life-links{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px}',
    '.life-links .life-edit{margin-top:0}',
    '.life-alt{margin-top:26px;padding-top:22px;border-top:1px solid rgba(255,255,255,.16)}',
    '.life-big.alt{color:#9EC1FF}',
    '.life-odds{margin-top:26px;padding:20px 16px 16px;border-radius:18px;background:rgba(255,255,255,.07)}',
    '.life-oddsnum{font:800 52px/1 var(--font-display);font-style:italic;color:#8CF0C8}',
    '.life-oddsnum span{font-size:22px;margin-left:2px}',
    '.life-odds > b{display:block;margin-top:6px;font:700 13px var(--font-body);color:#fff}',
    '.life-why{list-style:none;margin:14px 0 10px;padding:0;text-align:left}',
    '.life-why li{display:flex;gap:10px;align-items:baseline;padding:7px 0;font:500 12.5px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.life-why i{font-style:normal;font-weight:800;min-width:38px;color:#8CF0C8}',
    '.life-why li:has(i:first-child) i{}',
    '.life-odds small{display:block;font:500 11px/1.5 var(--font-body);color:rgba(255,255,255,.55)}',
    '.life-t{display:block;font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.66)}',
    '.life-big{margin-top:14px;font:800 56px/1 var(--font-display);font-style:italic;color:#8CF0C8}',
    '.life-big span{font:800 18px var(--font-display);font-style:italic;color:rgba(255,255,255,.8);margin-left:8px}',
    '.life-p{margin:14px 0 0;font:500 14px/1.6 var(--font-body);color:rgba(255,255,255,.88)}',
    '.life-p strong{font-weight:800;color:#fff}',
    '.life-list{list-style:none;margin:22px 0 0;padding:0;border-top:1px solid rgba(255,255,255,.16)}',
    '.life-list li{display:flex;gap:8px;align-items:baseline;justify-content:center;text-align:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1);font:500 13px var(--font-body);color:rgba(255,255,255,.78)}',
    '.life-list b{font:800 15px var(--font-display);color:#fff;flex:none}',
    '.life-note{display:block;margin-top:22px;font:500 11px/1.5 var(--font-body);color:rgba(255,255,255,.52)}',
    '.life-edit{margin-top:14px;border:1px solid rgba(255,255,255,.24);background:none;border-radius:99px;padding:8px 16px;font:700 11.5px var(--font-body);color:#fff;cursor:pointer}',
    '.life-ask{display:flex;gap:10px;margin-top:16px;justify-content:center}',
    '.life-ask input{flex:1;min-width:0;border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.08);border-radius:14px;padding:13px 16px;font:700 16px var(--font-body);color:#fff}',
    '.life-ask input::placeholder{color:rgba(255,255,255,.45);font-weight:500}',
    '.life-ask button{flex:none;border:0;border-radius:14px;background:var(--blue);color:#fff;padding:13px 20px;font:800 13px var(--font-body);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();
/* 0.9.291: tornando a Proteggi i tuoi sogni (anche con indietro) la panoramica si rilegge se era rimasta vuota */
document.addEventListener('fl:screen', function(e){
  if (e.detail !== 's-blocco') return;
  const rep = document.getElementById('blkReport');
  if (!rep || !rep.children.length){ try{ scBlockScores(); }catch(_){ } }
});
/* 0.9.346, Andrea: "se ho scelto il PC deve comparire l'emoji del PC, altrimenti non si capisce cosa sto guardando" */
function scTitoloSchermo(){
  let f = 'telefono'; try{ if (typeof mwFonte === 'function') f = mwFonte(); }catch(_){ }
  return f === 'computer' ? '💻 Tempo al computer' : (f === 'insieme' ? '📱💻 Tempo di schermo' : FL_ICO_SCHERMO + ' Tempo di schermo');
}

/* 0.9.372, Andrea: "le schede Giorno, Settimana, Mese, Anno (Dopamina e i tre punteggi) devono avere la scheda attiva scura e le altre
   bianche, con gli angoli tondi, come le schede che scorrono del mio tema: se tutto e' grigio non si vede cosa conta" */
(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  /* 0.9.374, Andrea: "quelle pill fanno schifo: le voglio incastonate in un contenitore grigio, come nella sezione delle schede video
     del mio tema, con spazio vero dentro, e solo Giorno, Settimana, Mese". Contenitore grigio, la scheda attiva bianca, nessun bordo
     sulle altre, margine di lato dalla pagina. */
  /* 0.9.376, Andrea: "erano meglio le schede di prima con gli angoli quadrati: ti avevo chiesto solo il contenitore scuro e la scheda bianca" */
  st.textContent = '.sc-per{display:flex!important;gap:4px!important;margin:6px 22px 16px!important;padding:4px!important;border-radius:14px!important;background:#001E44!important;border:0!important}'
    + '.sc-per button{flex:1 1 0!important;min-width:0!important;border:0!important;border-radius:10px!important;background:transparent!important;color:rgba(232,241,255,.78)!important;box-shadow:none!important;padding:10px 4px!important;font:700 14.5px var(--font-body)!important;white-space:nowrap!important;text-align:center!important}'
    /* 0.9.375, Andrea: "Settimana non sta neanche dentro la sua scheda, e te l'avevo detto di metterla scura": la scheda attiva e' blu notte */
    + '.sc-per button.on{background:#fff!important;color:#001E44!important;box-shadow:0 2px 8px rgba(0,0,0,.15)!important}'
    + 'body.dark .sc-per{background:rgba(255,255,255,.1)!important}'
    + 'body.dark .sc-per button{color:rgba(232,241,255,.7)!important}'
    + 'body.dark .sc-per button.on{background:#fff!important;color:#001E44!important}';
  document.head.appendChild(st);
})();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.life-p strong.life-pct{color:#8CC6FF!important;font-weight:800}body:not(.dark) .life-p strong.life-pct{color:#0075E3!important}.psc-io .life-p strong.life-pct{color:#8CC6FF!important}'; document.head.appendChild(st); })();

/* 0.9.378, Andrea: "con quattro schede Settimana esce dalla sua scheda, Mese e' attaccato a Settimana e lontano da Anno". Con tre schede
   la larghezza uguale bastava; con quattro ogni scheda prende lo spazio del suo testo e il resto si divide in parti uguali, cosi' lo
   spazio fra le parole e' lo stesso e nessun testo esce */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.sc-per button{flex:1 1 auto!important;min-width:max-content!important;padding:10px 8px!important;font-size:14px!important}.sc-per{margin-left:16px!important;margin-right:16px!important}'; document.head.appendChild(st); })();

/* 0.9.379, Andrea: "la lettura del Genio nella scheda Identita' deve essere bloccata finche' l'utente non mappa il suo ambiente". Serve
   almeno un posto descritto (la casa o un luogo con persone o inneschi): senza, il pulsante porta alla scheda Ambiente */
function scAmbienteMappato(){
  try{
    const c = (typeof pscCasa === 'function') ? pscCasa() : {};
    if ((c.inneschi != null && c.inneschi !== '') || c.inneschiNo || c.persone != null) return true;
    const l = (typeof pscLuoghi === 'function') ? pscLuoghi() : [];
    return l.some(function(x){ return x && (x.inneschi != null || x.inneschiNo || x.persone != null); });
  }catch(_){ return true; }
}
/* 0.9.380, Andrea: "Segna il tuo ambiente non vuol dire niente: fai partire la lettura e fai dentro le domande sull'ambiente" */
function scLetturaBtn(t){
  if (true) return '<button class="life-go" onclick="orOpen()">' + t + '</button>';
  return '<button class="life-go life-chiusa" onclick="scLetturaChiusa()">🔒 ' + t + '</button><p class="life-p life-nota">Prima segna il tuo ambiente:<br>le persone e le cose che hai intorno.</p>';
}
function scLetturaChiusa(){
  try{ flVibra(8); }catch(_){ }
  try{ if (typeof PST !== 'undefined' && typeof pstVaiAai === 'function'){ pstVaiAai('ambiente'); } }catch(_){ }
  try{ const el = document.querySelector('.psc-amb'); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
  try{ toast('Segna il tuo ambiente:\npoi il Genio può leggerti'); }catch(_){ }
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.life-go.life-chiusa{opacity:.85}.life-nota{margin-top:10px!important;font-size:13.5px!important}'; document.head.appendChild(st); })();

/* 0.9.381, Andrea: "la frase del giorno, nella quarta slide della scheda Sogno, con lo stesso pannello nero e il bagliore intorno della pagina
   Wishlist del mio tema". Il pannello e il bagliore che gira del tema (assets/wishlist.css, .wishlist-quote), con i colori del brand al
   posto del viola, e il blu notte del brand al posto del nero */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '#nvHero .bh-quote,.nv-bf .bh-quote{justify-content:center}'
  + '.bh-slide .bh-quote .bh-q-panel{position:relative;z-index:1;width:100%;max-width:340px;box-sizing:border-box;padding:22px 20px;border-radius:25px;background:#000F24;color:#fff}'
  + '.bh-slide .bh-quote .bh-q-panel::before{content:"";position:absolute;inset:-8px;border-radius:25px;background-image:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(12px);animation:spin 3s linear infinite;z-index:-2;pointer-events:none}'
  + '.bh-slide .bh-quote .bh-q-panel::after{content:"";position:absolute;inset:0;border-radius:25px;background:#000F24;z-index:-1;pointer-events:none}'
  + '.bh-slide .bh-quote .bh-q-panel .bh-q-text{text-shadow:none;min-height:1.7em}';
  document.head.appendChild(st); })();

/* ===========================================================================================
   LA STORIA DELLA GIORNATA (0.9.400, BUG-174)

   Andrea: "0:00-6:00 58% al vecchio te, senza dire che cosa stavo facendo all'una di notte". Un numero che giudica ha sempre il suo
   perche'. Toccando una fascia oraria delle statistiche della partita (pstPossessoHtml, partita-stats.js), una barra del grafico di
   "Dove va la tua attenzione?" (scChartHtml) o "Rivedi la giornata" in fondo al pannello, si apre una STORIA come quelle di Instagram:
   a schermo intero, le barre di avanzamento in alto, una pagina ogni cinque secondi, un tocco a destra va avanti e a sinistra indietro,
   il dito tenuto giu' la ferma, uno scorrimento verso il basso (o la X) la chiude, e alla fine si chiude da sola.

   UNA FUNZIONE SOLA (stoApri) per i tre posti. Ogni pagina e' un'attivita' vera: da che ora a che ora (con l'orologio che gira), l'app o il
   programma, cosa c'era dentro quando il telefono lo sa (la radiografia della Timeline: il sito o il titolo della pagina, tlRadiografia),
   quanto e' durata, e se era del vecchio te (le app che distraggono), del nuovo te (lavoro e Full Focus) o di nessuno dei due. Le stesse
   regole del possesso della partita: un granello con il peso di distrazione da 0,8 in su e' del vecchio te, fino a 0,05 del nuovo te.

   I DATI SONO QUELLI CHE CI SONO GIA': i granelli del motore della dopamina (dpGraniTelefono: la cronologia d'uso di questo dispositivo),
   quelli che l'altro dispositivo ha pubblicato oggi (dpGraniComputer sul telefono, dpGraniPubblicati sul computer) e il registro del
   Full Focus (fl_ff_hist). Dove non c'e' niente la storia lo dice, con il motivo vero: mai un'attivita' inventata.

   NIENTE MICRO SWITCHING. Di serie i passaggi sotto ai dieci secondi non contano, due pezzi della stessa app a meno di tre minuti di
   distanza sono una cosa sola, e un'attivita' sotto al minuto non diventa una pagina. La schermata Home (dmSchermataHome, di qualunque
   marca), il blocco schermo, la tastiera e la barra di sistema non sono attivita' (lezione 261). Dai tre puntini della storia si sceglie il
   dettaglio al secondo e si includono Home e blocco schermo; la scelta resta (fl_storia_opz).
   =========================================================================================== */
const STO_OPZ_K = 'fl_storia_opz';
const STO_PAG_MS = 5000;
const STO = { on: false, cfg: null, grezzi: null, motivo: '', pag: [], voci: [], i: 0, fine: -1, t0: 0, fatto: 0, raf: 0, ferma: false, giu: null, icone: {}, cosa: [] };
const STO_SISTEMA = /systemui|keyguard|lockscreen|lockapp|inputmethod|keyboard|honeyboard|^(idle|lock|locked|inattivo|schermo bloccato)$/i;

/* 0.9.402 BUG-231, Andrea: "nelle impostazioni delle storie si filtra per mattina, pomeriggio, sera o notte, oppure da un'ora a un'altra
   scelte dall'utente". Il filtro vale per ogni storia (Rivedi la giornata, le fasce del possesso, le barre del grafico) e resta salvato
   in fl_storia_opz: { secondi, home, parte: 'tutto' | 'mattina' | 'pomeriggio' | 'sera' | 'notte' | 'ore', dalle, alle }.
   Di serie tutto il giorno, cioe' come prima. Un'attivita' a cavallo del bordo (dalle 11:50 alle 12:20) si taglia: conta solo il pezzo
   dentro le ore scelte. */
const STO_PARTI = [
  { k: 'tutto', t: 'Tutto il giorno', em: '🕛', h: [0, 24] },
  { k: 'mattina', t: 'Mattina', em: '🌅', h: [6, 12] },
  { k: 'pomeriggio', t: 'Pomeriggio', em: '☀️', h: [12, 18] },
  { k: 'sera', t: 'Sera', em: '🌆', h: [18, 24] },
  { k: 'notte', t: 'Notte', em: '🌙', h: [0, 6] },
  { k: 'ore', t: 'Scegli le ore', em: '⏱️', h: null }
];
function stoOraN(v, min, max, d){ const n = Math.round(+v); return (v === null || v === undefined || v === '' || !isFinite(n)) ? d : Math.max(min, Math.min(max, n)); }
function stoOpz(){
  let o = {};
  try{ o = JSON.parse(localStorage.getItem(STO_OPZ_K) || 'null') || {}; }catch(_){ o = {}; }
  const parte = STO_PARTI.some(function(x){ return x.k === o.parte; }) ? o.parte : 'tutto';
  return { secondi: !!o.secondi, home: !!o.home, parte: parte, dalle: stoOraN(o.dalle, 0, 23, 9), alle: stoOraN(o.alle, 1, 24, 17) };
}
function stoOpzSet(k, v){ const o = stoOpz(); o[k] = (k === 'secondi' || k === 'home') ? !!v : v; try{ localStorage.setItem(STO_OPZ_K, JSON.stringify(o)); }catch(_){ } }
/** Le ore scelte [dalle, alle] (alle puo' essere minore di dalle: dalle 22 alle 2), o null per tutto il giorno. */
function stoOreScelte(opz){
  opz = opz || stoOpz();
  if (opz.parte === 'ore') return opz.dalle % 24 === opz.alle % 24 ? null : [opz.dalle, opz.alle];
  const p = STO_PARTI.filter(function(x){ return x.k === opz.parte; })[0];
  return (!p || !p.h || (p.h[0] === 0 && p.h[1] === 24)) ? null : p.h.slice();
}
/** Il filtro scritto per le persone: "Mattina, dalle 6 alle 12", o '' per tutto il giorno. */
function stoOreTxt(opz){
  opz = opz || stoOpz();
  const h = stoOreScelte(opz); if (!h) return '';
  const p = STO_PARTI.filter(function(x){ return x.k === opz.parte; })[0];
  return (opz.parte === 'ore' ? 'Dalle ' + h[0] + ' alle ' + h[1] : p.t + ', dalle ' + h[0] + ' alle ' + h[1]);
}
/** I pezzi di [s, e) che cadono nelle ore scelte, giorno per giorno (con l'ora legale: si usa setHours, non i millisecondi). */
function stoTagliaOre(s, e, h){
  if (!h) return [[s, e]];
  const out = [];
  const alle = function(d, ora){ if (ora >= 24) return stoDomani(d); const x = new Date(d); x.setHours(ora, 0, 0, 0); return x.getTime(); };
  for (let d = stoMezzanotte(s), n = 0; d < e && n < 400; d = stoDomani(d), n++){
    const iv = h[0] < h[1] ? [[alle(d, h[0]), alle(d, h[1])]] : [[d, alle(d, h[1])], [alle(d, h[0]), stoDomani(d)]];
    iv.forEach(function(r){ const a = Math.max(s, r[0]), b = Math.min(e, r[1]); if (b > a) out.push([a, b]); });
  }
  return out;
}
/** La schermata Home, il blocco schermo, la tastiera, la barra di sistema: non sono attivita'. */
function stoNonAttivita(g){
  const p = String((g && g.p) || ''), l = String((g && g.l) || '');
  return (typeof dmSchermataHome === 'function' && dmSchermataHome(p, l)) || STO_SISTEMA.test(p) || STO_SISTEMA.test(l);
}
function stoNome(g){ const l = String(g.l || g.p || ''); return (typeof dmNomeBello === 'function') ? dmNomeBello(l) : l; }
function stoOra(t, sec){ const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0') + (sec ? ':' + String(d.getSeconds()).padStart(2, '0') : ''); }
function stoDur(ms, sec){
  const s = Math.max(0, Math.round((ms || 0) / 1000));
  if (s < 60) return s + (s === 1 ? ' secondo' : ' secondi');
  const m = sec ? Math.floor(s / 60) : Math.round(s / 60), h = Math.floor(m / 60), r = m % 60;
  let t = h ? h + (h === 1 ? ' ora' : ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '') : m + (m === 1 ? ' minuto' : ' minuti');
  if (sec && s % 60) t += ' e ' + (s % 60) + ' secondi';
  return t;
}
function stoGiornoTxt(t){
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const d = new Date(t); d.setHours(0, 0, 0, 0);
  const g = Math.round((d0 - d) / 86400000);
  if (g === 0) return 'Oggi';
  if (g === 1) return 'Ieri';
  const s = d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' });
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function stoNellaFascia(t, f){
  if (!f) return true;
  const h = new Date(t).getHours();
  return f[0] <= f[1] ? (h >= f[0] && h < f[1]) : (h >= f[0] || h < f[1]);
}
/** Vecchio te, nuovo te o nessuno dei due, dal peso di distrazione medio (le regole del possesso della partita). */
function stoChi(di){ return di >= 0.8 ? 'old' : (di <= 0.05 ? 'neo' : 'nessuno'); }

/**
 * Le attivita' da raccontare: granelli -> attivita' unite, filtrate e ordinate.
 * grani = [{ p, l, s, ms, di, dev }], ff = [{ s, e }], opz = { secondi, home }, cfg = { da, a, fascia, principali }.
 * Torna { voci: [...], tolte: quante attivita' brevi o di sistema sono rimaste fuori }.
 * 0.9.401: i granelli possono arrivare da una lettura piu' larga (la giornata intera, gia' pronta): si tagliano al bordo della finestra.
 */
function stoAttivita(grani, ff, opz, cfg){
  const sec = !!opz.secondi;
  const minG = sec ? 0 : 10000, unisci = sec ? 2000 : 180000, minA = sec ? 0 : (cfg.principali ? 300000 : 60000);
  let tolte = 0;
  const l = [];
  const ore = stoOreScelte(opz);
  (grani || []).forEach(function(g0){
    if (!g0 || !(g0.ms > 0) || g0.s + g0.ms <= cfg.da || g0.s >= cfg.a) return;
    let g1 = g0;
    if (g1.s < cfg.da || g1.s + g1.ms > cfg.a){ const s = Math.max(g1.s, cfg.da); g1 = Object.assign({}, g0, { s: s, ms: Math.min(g0.s + g0.ms, cfg.a) - s }); }
    /* 0.9.402 BUG-231: solo il pezzo dentro la parte del giorno scelta */
    stoTagliaOre(g1.s, g1.s + g1.ms, ore).forEach(function(r){
      const g = (r[0] === g1.s && r[1] === g1.s + g1.ms) ? g1 : Object.assign({}, g1, { s: r[0], ms: r[1] - r[0] });
      if (!stoNellaFascia(g.s, cfg.fascia)) return;
      if (!opz.home && stoNonAttivita(g)){ tolte++; return; }
      if (g.ms < minG){ tolte++; return; }
      l.push(g);
    });
  });
  l.sort(function(a, b){ return a.s - b.s; });
  const out = [];
  l.forEach(function(g){
    const dev = g.dev || 'telefono';
    let prima = null;
    for (let k = out.length - 1; k >= 0; k--){ if (out[k].dev === dev){ prima = out[k]; break; } }
    if (prima && prima.p === g.p && g.s - prima.e <= unisci){
      prima.e = Math.max(prima.e, g.s + g.ms); prima.ms += g.ms; prima.diMs += (+g.di || 0) * g.ms; prima.pezzi++; return;
    }
    out.push({ p: g.p, l: stoNome(g), dev: dev, s: g.s, e: g.s + g.ms, ms: g.ms, diMs: (+g.di || 0) * g.ms, pezzi: 1 });
  });
  let voci = out.filter(function(v){ if (v.ms < minA){ tolte++; return false; } return true; });
  voci.forEach(function(v){ v.chi = stoChi(v.diMs / Math.max(1, v.ms)); });
  (ff || []).forEach(function(x){
    if (!(x.e > cfg.da && x.s < cfg.a)) return;
    stoTagliaOre(x.s, x.e, ore).forEach(function(r){
      if (!stoNellaFascia(r[0], cfg.fascia)) return;
      voci.push({ ff: true, p: 'fullfocus', l: 'Full Focus', dev: 'telefono', s: r[0], e: r[1], ms: r[1] - r[0], chi: 'neo', pezzi: 1 });
    });
  });
  /* la giornata intera: solo le attivita' principali, al massimo quaranta pagine (le piu' lunghe, poi di nuovo in ordine di ora) */
  if (cfg.principali && voci.length > 40){ tolte += voci.length - 40; voci = voci.slice().sort(function(a, b){ return b.ms - a.ms; }).slice(0, 40); }
  voci.sort(function(a, b){ return a.s - b.s; });
  return { voci: voci, tolte: tolte };
}
/** Le sessioni di Full Focus della finestra (le stesse regole delle statistiche della partita, pstDati). */
function stoFF(da, a){
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ h = []; }
  return h.filter(function(x){ return x && x.at && !x.stornato && !x.meditazione && x.tag !== 'meditazione' && !x.daSola; }).map(function(x){
    const min = x.spentMs ? x.spentMs / 60000 : (x.ok ? (+x.min || 25) : 0);
    const s = +x.start || (x.at - min * 60000);
    return { s: s, e: s + min * 60000 };
  }).filter(function(x){ return x.e > x.s && x.e > da && x.s < a; });
}
/** Legge i granelli della finestra: questo dispositivo, e oggi anche quelli pubblicati dall'altro. null = niente permesso. */
async function stoLeggi(da, a){
  const qui = (typeof mwQuiComputer === 'function' && mwQuiComputer()) ? 'computer' : 'telefono';
  let mie = null;
  try{ if (typeof dpGraniTelefono === 'function') mie = await dpGraniTelefono(da, a); }catch(_){ mie = null; }
  let tutti = Array.isArray(mie) ? mie.map(function(g){ return Object.assign({}, g, { dev: qui }); }) : null;
  const oggi = (typeof scDayStart === 'function') ? scDayStart(0) : new Date().setHours(0, 0, 0, 0);
  if (a > oggi){
    let altri = null;
    try{
      if (qui === 'telefono' && typeof dpGraniComputer === 'function') altri = await dpGraniComputer(oggi);
      else if (qui === 'computer' && typeof dpGraniPubblicati === 'function') altri = await dpGraniPubblicati(oggi);
    }catch(_){ altri = null; }
    if (Array.isArray(altri) && altri.length){
      const dev = qui === 'telefono' ? 'computer' : 'telefono';
      tutti = (tutti || []).concat(altri.map(function(g){ return Object.assign({}, g, { dev: dev }); }));
    }
  }
  return tutti;
}

/* ---- I DATI GIA' PRONTI (0.9.401, BUG-184) ----
   Andrea: "toccando la barra di una fascia oraria i dati di quella fascia ci mettono troppo ad aggiornarsi". Ogni tocco chiedeva al
   motore la cronologia della finestra, poi le icone e cosa c'era dentro, aspettando fino a due secondi e mezzo prima di mostrare la prima
   pagina. Adesso la giornata si legge UNA volta, appena il pannello compare (stoPrecarica), e ogni barra, ogni fascia e "Rivedi la
   giornata" ne prendono il pezzo che serve: la storia si apre subito. Le icone e il titolo dei siti arrivano dopo, senza fermare niente.
   Una lettura vale per tutte le finestre che finiscono prima di quando e' stata fatta (un'ora gia' passata non cambia piu'); per l'ora
   in corso vale 45 secondi. Fino a due giorni si legge giorno per giorno, oltre (la fascia oraria della settimana) tutta la finestra. */
const STO_CACHE = { g: {}, cosa: {}, tm: 0 };
const STO_FRESCO = 45000;
function stoMezzanotte(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
function stoDomani(d0){ const d = new Date(d0); d.setDate(d.getDate() + 1); return d.getTime(); }
function stoGiorni(da, a){ const out = []; for (let d = stoMezzanotte(da), n = 0; d < a && n < 400; d = stoDomani(d), n++) out.push(d); return out; }
/** I pezzi da leggere per una finestra: un giorno alla volta fino a due giorni, la finestra intera oltre. */
function stoPezzi(da, a){
  const gg = stoGiorni(da, a);
  if (gg.length <= 2) return gg.map(function(d){ return { k: 'g' + d, da: d, fine: stoDomani(d) }; });
  const ult = gg[gg.length - 1];
  return [{ k: 'r' + da + '-' + ult, da: da, fine: stoDomani(ult) }];
}
/** La lettura e copre la finestra fino ad a? */
function stoCopre(e, a){ return !!e && ('v' in e) && (a <= e.fino + 1000 || Date.now() - e.t < STO_FRESCO); }
function stoPezzoLeggi(p){
  const e = STO_CACHE.g[p.k];
  if (stoCopre(e, Math.min(Date.now(), p.fine))) return Promise.resolve(e.v);
  if (e && e.pr) return e.pr;
  const fino = Math.min(Date.now(), p.fine);
  const pr = stoLeggi(p.da, fino).then(function(v){ STO_CACHE.g[p.k] = { t: Date.now(), fino: fino, v: v }; return v; },
    function(){ delete STO_CACHE.g[p.k]; return null; });
  STO_CACHE.g[p.k] = { pr: pr };
  return pr;
}
function stoUnisci(l){ let out = null; l.forEach(function(v){ if (Array.isArray(v)) out = (out || []).concat(v); }); return out; }
/** Subito: i granelli della finestra se sono gia' stati letti, undefined se no. null = niente permesso. */
function stoGraniPronti(da, a){
  const ps = stoPezzi(da, a), l = [];
  for (let i = 0; i < ps.length; i++){ const e = STO_CACHE.g[ps[i].k]; if (!stoCopre(e, Math.min(a, ps[i].fine))) return undefined; l.push(e.v); }
  return stoUnisci(l);
}
async function stoGraniDi(da, a){
  const l = await Promise.all(stoPezzi(da, a).map(function(p){ const e = STO_CACHE.g[p.k]; return stoCopre(e, Math.min(a, p.fine)) ? e.v : stoPezzoLeggi(p); }));
  return stoUnisci(l);
}
/** Cosa c'era dentro le app (il sito, la ricerca, il titolo del video): la radiografia della Timeline, giorno per giorno, tenuta da parte. */
function stoIso(t){ const x = new Date(t); return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); }
function stoCosaGiorno(d0){
  const e = STO_CACHE.cosa[d0];
  if (stoCopre(e, Math.min(Date.now(), stoDomani(d0)))) return Promise.resolve(e.v);
  if (e && e.pr) return e.pr;
  if (typeof tlRadiografia !== 'function') return Promise.resolve([]);
  const fino = Math.min(Date.now(), stoDomani(d0));
  const pr = Promise.resolve(tlRadiografia(stoIso(d0), d0, fino)).then(function(ev){
    const v = Array.isArray(ev) ? ev.filter(function(x){ return x && x.cosa; }) : [];
    STO_CACHE.cosa[d0] = { t: Date.now(), fino: fino, v: v }; return v;
  }, function(){ delete STO_CACHE.cosa[d0]; return []; });
  STO_CACHE.cosa[d0] = { pr: pr };
  return pr;
}
function stoCosaPronta(da, a){
  const gg = stoGiorni(da, a).slice(-8); let out = [];
  for (let i = 0; i < gg.length; i++){ const e = STO_CACHE.cosa[gg[i]]; if (!stoCopre(e, Math.min(a, stoDomani(gg[i])))) return undefined; out = out.concat(e.v); }
  return out;
}
async function stoCosa(da, a){
  const l = await Promise.all(stoGiorni(da, a).slice(-8).map(stoCosaGiorno));
  return l.reduce(function(t, x){ return t.concat(x || []); }, []);
}
/* LE ICONE VERE (0.9.401, BUG-198). Andrea: "la C di Chiama: mostra la vera icona dell'app, per Chiama il telefono, mai una lettera".
   Le icone arrivavano solo dalla classifica del motore (getTopApps, le prime quaranta app per tempo): un'app fuori classifica, o una che
   Android non mette fra quelle "lanciabili" come la schermata della chiamata, restava con l'iniziale. Adesso si cercano come nel resto
   dell'app: la cache delle icone (INS_ICONE), poi wkIcona (settimana.js: il motore di qui, le icone pubblicate dall'altro dispositivo, il
   disegno delle app note). Per il telefono e le chiamate, se l'icona propria manca, quella del compositore; e se nemmeno quella c'e', 📞. */
const STO_ICO_ATT = {}, STO_ICO_PROVATE = {};
const STO_DIALER = ['com.samsung.android.dialer', 'com.google.android.dialer', 'com.android.dialer', 'com.samsung.android.incallui', 'com.android.incallui', 'com.android.contacts'];
function stoETelefono(p, l){
  return /dialer|incallui|callui|telecom|android\.phone|\.phone$|contacts/i.test(String(p || ''))
    || /^(chiama|chiamate|chiamata|telefono|phone|contatti|dialer)$/i.test(String(l || '').trim());
}
function stoIcoValida(u){ return !!u && (String(u).indexOf('data:image') === 0 || /^img\//.test(String(u))); }
function stoIconaSubito(p){
  if (stoIcoValida(STO.icone[p])) return STO.icone[p];
  try{ if (typeof INS_ICONE !== 'undefined' && stoIcoValida(INS_ICONE[p])) return INS_ICONE[p]; }catch(_){ }
  try{ if (typeof WK_ICONE !== 'undefined' && stoIcoValida(WK_ICONE[p])) return WK_ICONE[p]; }catch(_){ }
  return '';
}
function stoIconaCarica(p, l){
  const pronta = stoIconaSubito(p);
  if (pronta) return Promise.resolve(pronta);
  if (STO_ICO_PROVATE[p]) return Promise.resolve('');
  if (STO_ICO_ATT[p]) return STO_ICO_ATT[p];
  STO_ICO_ATT[p] = (async function(){
    let ic = '';
    try{
      if (typeof wkIcona === 'function') ic = await wkIcona(p, l);
      else if (typeof insIcona === 'function') ic = await insIcona(p);
    }catch(_){ ic = ''; }
    if (!stoIcoValida(ic) && stoETelefono(p, l) && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getAppIcon){
      for (let i = 0; i < STO_DIALER.length && !stoIcoValida(ic); i++){
        if (STO_DIALER[i] === p) continue;
        try{ const r = await NATIVE.getAppIcon({ packageName: STO_DIALER[i] }); const u = (r && (r.icon || r.dataUri || r.png)) || ''; if (stoIcoValida(u)) ic = u; }catch(_){ }
      }
    }
    if (stoIcoValida(ic)) STO.icone[p] = ic; else ic = '';
    STO_ICO_PROVATE[p] = 1;
    delete STO_ICO_ATT[p];
    return ic;
  })();
  return STO_ICO_ATT[p];
}
/** Le icone delle app della finestra in un colpo solo (sul telefono il motore le da' con la classifica). */
async function stoIcone(da, a){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return;
    const r = await NATIVE.getTopApps({ from: da, to: a, limit: 40, by: 'ms', icons: 40 });
    ((r && r.apps) || []).forEach(function(x){ if (x && x.packageName && stoIcoValida(x.icon)) STO.icone[x.packageName] = x.icon; });
  }catch(_){ }
}
/** Le tessere senza icona della pagina a schermo prendono l'icona appena c'e'. */
function stoIconeDom(root){
  const c = root || document.getElementById('stoCorpo'); if (!c) return;
  c.querySelectorAll('[data-sto-ico]').forEach(function(el){
    const ic = stoIconaSubito(el.getAttribute('data-sto-ico')); if (!ic) return;
    const img = document.createElement('img'); img.className = 'sto-ico'; img.alt = ''; img.src = ic;
    el.replaceWith(img);
  });
}
/** Prepara la giornata del pannello prima del tocco: la cronologia, poi le icone delle app piu' usate e cosa c'era dentro. */
function stoPrecaricaPresto(win, perGiorno){
  if (!win || !(win.to > win.from)) return;
  clearTimeout(STO_CACHE.tm);
  STO_CACHE.tm = setTimeout(function(){ stoPrecarica(win.from, win.to, perGiorno).catch(function(){ }); }, 700);
}
/** perGiorno: le barre dei giorni aprono un giorno alla volta, quindi si leggono i giorni (gli ultimi sette, il telefono non ne tiene di piu'). */
async function stoPrecarica(da, a, perGiorno){
  const ps = (perGiorno ? stoGiorni(Math.max(da, stoMezzanotte(a - 1) - 6 * 86400000), a).map(function(d){ return { k: 'g' + d, da: d, fine: stoDomani(d) }; }) : stoPezzi(da, a)).reverse();
  for (let i = 0; i < ps.length; i++){ try{ await stoPezzoLeggi(ps[i]); }catch(_){ } }
  const gr = stoUnisci(ps.map(function(p){ return (STO_CACHE.g[p.k] || {}).v; })) || [];
  const perApp = {};
  gr.forEach(function(g){ if (g && g.p && !stoNonAttivita(g)){ const x = perApp[g.p] = perApp[g.p] || { p: g.p, l: stoNome(g), ms: 0 }; x.ms += g.ms || 0; } });
  const top = Object.keys(perApp).map(function(k){ return perApp[k]; }).sort(function(x, y){ return y.ms - x.ms; }).slice(0, 24);
  if (top.some(function(x){ return !stoIconaSubito(x.p); })) await stoIcone(ps.length ? ps[ps.length - 1].da : da, a);
  for (let i = 0; i < top.length; i++){ if (!stoIconaSubito(top[i].p)){ try{ await stoIconaCarica(top[i].p, top[i].l); }catch(_){ } } }
  try{ await stoCosaGiorno(stoMezzanotte(a - 1)); }catch(_){ }
}
function stoCosaDi(v){
  if (v.ff || !STO.cosa.length) return '';
  let best = null, bestMs = -1;
  STO.cosa.forEach(function(e){
    if (e.pkg !== v.p) return;
    const fine = e.t + (e.durMs || 0);
    if (fine < v.s - 1000 || e.t > v.e + 1000) return;
    const ms = Math.min(fine, v.e) - Math.max(e.t, v.s);
    if (ms > bestMs){ bestMs = ms; best = e; }
  });
  return best ? String(best.cosa).slice(0, 90) : '';
}

/* ---- le pagine ---- */
function stoOrologio(v){
  const d = new Date(v.s), m0 = d.getMinutes() + d.getSeconds() / 60, h0 = (d.getHours() % 12) + m0 / 60;
  const durMin = Math.max(0, (v.e - v.s) / 60000);
  const am = m0 * 6, ah = h0 * 30;
  return '<svg class="sto-oro" viewBox="0 0 64 64" width="64" height="64" aria-hidden="true">'
    + '<circle cx="32" cy="32" r="29" fill="rgba(255,255,255,.08)" stroke="rgba(255,255,255,.55)" stroke-width="2"/>'
    + [0, 1, 2, 3].map(function(k){ const a = k * Math.PI / 2; return '<line x1="' + (32 + 24 * Math.sin(a)).toFixed(1) + '" y1="' + (32 - 24 * Math.cos(a)).toFixed(1) + '" x2="' + (32 + 27 * Math.sin(a)).toFixed(1) + '" y2="' + (32 - 27 * Math.cos(a)).toFixed(1) + '" stroke="rgba(255,255,255,.6)" stroke-width="2" stroke-linecap="round"/>'; }).join('')
    + '<g class="sto-lancia h" style="--da:' + ah.toFixed(1) + 'deg;--a:' + (ah + durMin * 0.5).toFixed(1) + 'deg"><line x1="32" y1="32" x2="32" y2="17" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/></g>'
    + '<g class="sto-lancia m" style="--da:' + am.toFixed(1) + 'deg;--a:' + (am + durMin * 6).toFixed(1) + 'deg"><line x1="32" y1="32" x2="32" y2="9" stroke="#8CC6FF" stroke-width="2.4" stroke-linecap="round"/></g>'
    + '<circle cx="32" cy="32" r="3" fill="#fff"/></svg>';
}
const STO_CHI = { old: ['😈', 'Vecchio te'], neo: ['🚀', 'Nuovo te'], nessuno: ['⚪', 'Né il vecchio né il nuovo te'] };
/* LA CATEGORIA DELL'APP (0.9.401, BUG-198). Andrea: "tutte uguali: il colore del pannello e un'emoji seguono la categoria che l'utente ha
   dato all'app, cosi' ogni storia si riconosce". La categoria e' quella scelta nel Report ("Questa app e' per me", insCats con le fasce
   orarie, poi insGiudizioApp per i programmi del computer); un'app mai classificata prende quella che dice il suo peso di distrazione.
   La faccina e' la stessa delle carte del Report (insFaccia): felice produttiva, dritta normale, triste distrattiva. */
const STO_CAT = { distr: ['🙁', 'Distrattiva'], neutro: ['😐', 'Normale'], prod: ['🙂', 'Produttiva'] };
function stoCatDi(v){
  if (v.ff) return 'prod';
  let c = '';
  try{ if (typeof insCats === 'function') c = (insCats(v.s + (v.e - v.s) / 2) || {})[v.p] || ''; }catch(_){ c = ''; }
  if (!STO_CAT[c]){ try{ if (typeof insGiudizioApp === 'function') c = insGiudizioApp(v.p, v.l) || ''; }catch(_){ c = ''; } }
  if (!STO_CAT[c]) c = v.chi === 'old' ? 'distr' : (v.chi === 'neo' ? 'prod' : 'neutro');
  return c;
}
function stoFacciaHtml(c){
  return (typeof insFaccia === 'function') ? '<i class="sto-fac" aria-hidden="true">' + insFaccia(c) + '</i>' : '<i class="sto-fac e" aria-hidden="true">' + STO_CAT[c][0] + '</i>';
}
function stoIcoHtml(v){
  if (v.ff) return '<span class="sto-ico e">🎯</span>';
  const ic = stoIconaSubito(v.p);
  if (ic) return '<img class="sto-ico" src="' + ic + '" alt="">';
  /* in attesa dell'icona vera: il telefono ha gia' la sua cornetta, le altre una tessera che diventa l'icona appena arriva */
  if (stoETelefono(v.p, v.l)) return '<span class="sto-ico e" data-sto-ico="' + esc(v.p) + '">📞</span>';
  return '<span class="sto-ico" data-sto-ico="' + esc(v.p) + '">' + esc(String(v.l || '?').charAt(0).toUpperCase()) + '</span>';
}
/* LA PAGINA (0.9.401, BUG-198). Andrea: "tutto ammassato, nessuna gerarchia, tutte uguali". Al centro, un elemento alla volta:
   - in alto l'orologio che gira (com'era: piace) con l'ora e il dispositivo;
   - poi il pannello dell'app, nel colore della sua categoria: l'icona vera, il nome e i minuti VICINI, perche' sono una cosa sola;
   - staccato sotto, chi ha avuto quel tempo: vecchio te e nuovo te affiancati, acceso solo quello vero (lezione 297, Pleasantville).
   Gli elementi compaiono uno dopo l'altro (sto-a, --d: 0, 220, 400, 560, 760, 1000 ms), mai tutto insieme. */
function stoPaginaHtml(v, sec, piuGiorni){
  const cosa = stoCosaDi(v);
  const cat = stoCatDi(v), ct = STO_CAT[cat];
  const chi = v.chi || 'nessuno';
  const lato = function(k){ return '<span class="' + k + (chi === k ? ' on' : '') + '">' + STO_CHI[k][0] + ' ' + STO_CHI[k][1] + '</span>'; };
  return '<div class="sto-pag sto-att-p cat-' + cat + '">'
    + '<div class="sto-quando sto-a" style="--d:0ms">' + stoOrologio(v) + '<div><b>' + stoOra(v.s, sec) + ' – ' + stoOra(v.e, sec) + '</b>'
    +   '<small>' + esc((piuGiorni ? stoGiornoTxt(v.s) + ' · ' : '') + (v.dev === 'computer' ? '💻 Sul computer' : '📱 Sul telefono')) + '</small></div></div>'
    + '<div class="sto-cosa sto-a" style="--d:220ms">'
    +   '<span class="sto-cat">' + stoFacciaHtml(cat) + ct[1] + '</span>'
    +   '<span class="sto-a sto-pop" style="--d:400ms">' + stoIcoHtml(v) + '</span>'
    +   '<b class="sto-app sto-a" style="--d:560ms">' + esc(v.l) + '</b>'
    +   (cosa ? '<p class="sto-tit sto-a" style="--d:620ms">' + esc(cosa) + '</p>' : '')
    +   '<p class="sto-dur sto-a" style="--d:760ms">' + esc(stoDur(v.ms, sec)) + (v.pezzi > 1 && !sec ? '<small>' + v.pezzi + ' aperture unite</small>' : '') + '</p>'
    + '</div>'
    + '<div class="sto-chi-w sto-a" style="--d:1000ms"><div class="sto-bil">' + lato('old') + lato('neo') + '</div>'
    +   (chi === 'nessuno' ? '<small>' + STO_CHI.nessuno[1] + '</small>' : '') + '</div>'
    + '</div>';
}
function stoCopertinaHtml(voci, tolte){
  const tot = { old: 0, neo: 0, nessuno: 0 };
  voci.forEach(function(v){ tot[v.chi || 'nessuno'] += v.ms; });
  let d = 360;
  const riga = function(k){ if (!(tot[k] > 0)) return ''; d += 200; return '<div class="sto-cop-r ' + k + ' sto-a" style="--d:' + d + 'ms"><span>' + STO_CHI[k][0] + ' ' + STO_CHI[k][1] + '</span><b>' + esc(stoDur(tot[k], false)) + '</b></div>'; };
  const righe = riga('old') + riga('neo') + riga('nessuno');
  return '<div class="sto-pag sto-cop">'
    + '<b class="sto-cop-n sto-a" style="--d:0ms">' + voci.length + '</b><p class="sto-cop-t sto-a" style="--d:180ms">' + (voci.length === 1 ? 'attività' : 'attività, una per pagina') + '</p>'
    + '<div class="sto-cop-l">' + righe + '</div>'
    + (tolte && !stoOpz().secondi ? '<p class="sto-cop-nota sto-a" style="--d:' + (d + 220) + 'ms">Ho unito o tolto ' + tolte + (tolte === 1 ? ' passaggio breve' : ' passaggi brevi') + ' (e la schermata Home). Li vedi dai tre puntini.</p>' : '')
    + '</div>';
}
function stoVuotaHtml(){
  const vecchio = STO.cfg && STO.cfg.a < Date.now() - 7 * 86400000;
  /* 0.9.402 BUG-231: se la parte del giorno scelta lascia fuori tutto, lo si dice e si offre di tornare a tutto il giorno */
  const filtro = STO.motivo !== 'permesso' && !vecchio && stoOreScelte() ? stoOreTxt() : '';
  const t = STO.motivo === 'permesso' ? 'Senza l’accesso ai dati di utilizzo non vedo quali app apri.'
    : (vecchio ? 'Il telefono tiene la cronologia delle app per circa una settimana, e questa è più vecchia.'
    : (filtro ? 'Stai guardando solo una parte del giorno (' + filtro.charAt(0).toLowerCase() + filtro.slice(1) + '), e in queste ore non c’è niente.'
    : (STO.tolte ? 'C’erano solo passaggi di pochi secondi o la schermata Home. Dai tre puntini li puoi vedere tutti.' : 'In questo momento il telefono non è stato usato.')));
  return '<div class="sto-pag sto-vuota"><span class="sto-a" style="--d:0ms" aria-hidden="true">🫥</span><b class="sto-a" style="--d:180ms">Qui non ho visto attività</b><p class="sto-a" style="--d:360ms">' + esc(t) + '</p>'
    + (filtro ? '<button type="button" class="sto-cta sto-a" style="--d:540ms" onclick="event.stopPropagation();stoParte(\'tutto\')">Mostra tutto il giorno</button>' : '') + '</div>';
}
/* L'ULTIMA PAGINA DI "RIVEDI LA GIORNATA" (0.9.401, BUG-184). Il Report dettagliato si apre solo se lo chiedi qui: il tocco sul pannello
   non ci porta piu'. Questa pagina non scorre da sola: resta finche' scegli. */
function stoFineHtml(){
  return '<div class="sto-pag sto-fine">'
    + '<span class="sto-fine-e sto-a" style="--d:0ms" aria-hidden="true">📊</span>'
    + '<b class="sto-a" style="--d:200ms">Vuoi vedere tutti i numeri?</b>'
    + '<p class="sto-a" style="--d:400ms">Il Report ha ogni app della giornata, ora per ora.</p>'
    + '<button type="button" class="sto-cta sto-a" style="--d:600ms" onclick="event.stopPropagation();stoReport()">Apri il Report</button>'
    + '<button type="button" class="sto-cta2 sto-a" style="--d:700ms" onclick="event.stopPropagation();stoChiudi()">Chiudi</button>'
    + '</div>';
}
function stoReport(){
  const off = (STO.cfg && STO.cfg.off) || 0;
  stoChiudi(true);
  try{ if (typeof INS !== 'undefined' && INS){ INS.view = 'giorno'; INS.dayOff = off; } }catch(_){ }
  try{ if (typeof scVaiAlReport === 'function') scVaiAlReport(); else switchTab('insights'); }catch(_){ }
}
function stoCalcola(){
  const opz = stoOpz();
  const r = STO.grezzi ? stoAttivita(STO.grezzi, stoFF(STO.cfg.da, STO.cfg.a), opz, STO.cfg) : { voci: [], tolte: 0 };
  STO.tolte = r.tolte; STO.voci = r.voci;
  const piuGiorni = (STO.cfg.a - STO.cfg.da) > 86400000 + 3600000;
  STO.pag = r.voci.length ? [stoCopertinaHtml(r.voci, r.tolte)].concat(r.voci.map(function(v){ return stoPaginaHtml(v, opz.secondi, piuGiorni); })) : [stoVuotaHtml()];
  STO.fine = -1;
  if (STO.cfg.report){ STO.pag.push(stoFineHtml()); STO.fine = STO.pag.length - 1; }
}

/* ---- il lettore ---- */
/**
 * Apre la storia. cfg = { titolo, sotto, da, a, fascia: [dalle, alle] | null, principali: true per la giornata intera,
 * report: true per offrire il Report nell'ultima pagina, off: 0 oggi / 1 ieri }.
 */
async function stoApri(cfg){
  if (!cfg || !(cfg.a > cfg.da)) return;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  stoChiudi(true);
  STO.cfg = cfg; STO.on = true; STO.i = 0; STO.pag = []; STO.voci = []; STO.grezzi = null; STO.cosa = []; STO.motivo = ''; STO.fine = -1;
  let w = document.getElementById('stoWrap');
  if (!w){ w = document.createElement('div'); w.id = 'stoWrap'; w.className = 'sto'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true'); document.body.appendChild(w); }
  const pronti = stoGraniPronti(cfg.da, cfg.a);
  w.innerHTML = '<div class="sto-barre" id="stoBarre"></div>'
    + '<div class="sto-testa"><div><b>' + esc(cfg.titolo || 'La tua giornata') + '</b><small id="stoSotto">' + esc(stoSottoTxt(cfg)) + '</small></div>'
    + '<button type="button" class="sto-btn" onclick="event.stopPropagation();stoMenu()" aria-label="Cosa mostrare">⋯</button>'
    + '<button type="button" class="sto-btn" onclick="event.stopPropagation();stoChiudi()" aria-label="Chiudi">✕</button></div>'
    + '<div class="sto-corpo" id="stoCorpo">' + (pronti === undefined ? '<div class="sto-pag sto-att"><i></i><p>Sto mettendo in fila le attività…</p></div>' : '') + '</div>'
    + '<div class="sto-menu" id="stoMenu" hidden></div>';
  w.hidden = false; requestAnimationFrame(function(){ w.classList.add('in'); });
  document.body.classList.add('sto-aperta');
  stoGesti(w);
  const t = STO.cfg;
  if (pronti !== undefined){ stoPronti(t, pronti); return; }
  const grezzi = await stoGraniDi(t.da, t.a);
  if (!STO.on || STO.cfg !== t) return;
  stoPronti(t, grezzi);
}
/** La riga sotto il titolo della storia: quella del posto da cui si apre, e la parte del giorno scelta (0.9.402 BUG-231). */
function stoSottoTxt(cfg){
  const f = stoOreTxt(), s = (cfg && cfg.sotto) || '';
  return f ? (s ? s + ' · ' : '') + f : s;
}
function stoPronti(t, grezzi){
  if (grezzi === null) STO.motivo = 'permesso';
  STO.grezzi = grezzi || [];
  STO.cosa = stoCosaPronta(t.da, t.a) || [];
  stoCalcola();
  stoVai(0);
  stoCompleta(t);
}
/** Dopo la prima pagina: le icone che mancano e cosa c'era dentro le app. Le pagine dopo li hanno; quella a schermo prende l'icona. */
async function stoCompleta(t){
  const manca = {};
  STO.voci.forEach(function(v){ if (!v.ff && !stoIconaSubito(v.p)) manca[v.p] = v.l; });
  Object.keys(manca).forEach(function(p){
    stoIconaCarica(p, manca[p]).then(function(ic){ if (ic && STO.on && STO.cfg === t){ stoCalcola(); stoIconeDom(); } }).catch(function(){ });
  });
  if (stoCosaPronta(t.da, t.a) === undefined){
    let l = [];
    try{ l = await stoCosa(t.da, t.a); }catch(_){ l = []; }
    if (!STO.on || STO.cfg !== t || !l.length) return;
    STO.cosa = l; stoCalcola();
  }
}
function stoBarreHtml(){
  return STO.pag.map(function(_, k){ return '<i><b style="width:' + (k < STO.i ? 100 : 0) + '%"></b></i>'; }).join('');
}
function stoVai(i){
  if (!STO.on) return;
  if (i >= STO.pag.length){ stoChiudi(); return; }
  STO.i = Math.max(0, i);
  const c = document.getElementById('stoCorpo'), b = document.getElementById('stoBarre');
  if (b) b.innerHTML = stoBarreHtml();
  if (c){
    c.innerHTML = STO.pag[STO.i];
    stoIconeDom(c);
    /* l'orologio gira da quando l'attivita' e' cominciata a quando e' finita */
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ const p = c.querySelector('.sto-pag'); if (p) p.classList.add('gira'); }); });
  }
  STO.fatto = 0; STO.t0 = performance.now();
  cancelAnimationFrame(STO.raf); STO.raf = requestAnimationFrame(stoTic);
}
function stoTic(now){
  if (!STO.on) return;
  if (!STO.ferma){
    /* l'ultima pagina di "Rivedi la giornata" aspetta la scelta: la sua barra si riempie e la storia resta aperta */
    const p = Math.min(1, (STO.fatto + now - STO.t0) / (STO.i === STO.fine ? 700 : STO_PAG_MS));
    const b = document.querySelectorAll('#stoBarre i b')[STO.i]; if (b) b.style.width = (p * 100).toFixed(1) + '%';
    if (p >= 1){ if (STO.i === STO.fine) return; stoVai(STO.i + 1); return; }
  }
  STO.raf = requestAnimationFrame(stoTic);
}
function stoFerma(si){
  if (si && !STO.ferma){ STO.fatto += performance.now() - STO.t0; STO.ferma = true; }
  else if (!si && STO.ferma){ STO.t0 = performance.now(); STO.ferma = false; }
}
function stoGesti(w){
  if (w._gesti) return; w._gesti = true;
  w.addEventListener('pointerdown', function(e){
    if (!STO.on || (e.target.closest && e.target.closest('button,.sto-menu'))) return;
    STO.giu = { x: e.clientX, y: e.clientY, t: performance.now() }; stoFerma(true);
  });
  w.addEventListener('pointermove', function(e){
    if (!STO.giu) return;
    const dy = e.clientY - STO.giu.y; const c = document.getElementById('stoCorpo');
    if (c && dy > 0) c.style.transform = 'translateY(' + Math.min(dy, 220) + 'px)';
  });
  const su = function(e){
    if (!STO.giu) return;
    const g = STO.giu; STO.giu = null;
    const dy = e.clientY - g.y, dx = e.clientX - g.x, dt = performance.now() - g.t;
    const c = document.getElementById('stoCorpo'); if (c) c.style.transform = '';
    if (dy > 80 && Math.abs(dy) > Math.abs(dx)){ stoChiudi(); return; }
    if (!document.getElementById('stoMenu') || document.getElementById('stoMenu').hidden) stoFerma(false);
    if (dt < 350 && Math.abs(dx) < 30 && Math.abs(dy) < 30){
      const r = w.getBoundingClientRect();
      stoVai(e.clientX - r.left < r.width / 3 ? STO.i - 1 : STO.i + 1);
    }
  };
  w.addEventListener('pointerup', su);
  w.addEventListener('pointercancel', function(){ STO.giu = null; const c = document.getElementById('stoCorpo'); if (c) c.style.transform = ''; stoFerma(false); });
  document.addEventListener('keydown', function(e){ if (!STO.on) return; if (e.key === 'Escape') stoChiudi(); else if (e.key === 'ArrowRight') stoVai(STO.i + 1); else if (e.key === 'ArrowLeft') stoVai(STO.i - 1); });
}
/* i tre puntini: il dettaglio al secondo e la schermata Home con il blocco schermo */
function stoMenu(){
  const m = document.getElementById('stoMenu'); if (!m) return;
  if (!m.hidden){ m.hidden = true; stoFerma(false); return; }
  m.innerHTML = stoMenuHtml();
  m.hidden = false; stoFerma(true);
}
/* 0.9.402 BUG-223, Andrea: "ogni interruttore dice cosa fa, con il verbo: una frase senza verbo e' linguaggio da AI" (lezione 321).
   0.9.402 BUG-231: sotto i due interruttori, la parte del giorno da vedere (sei card, la scelta con il bagliore .fl-sel) e, per
   "Scegli le ore", dalle e alle */
function stoMenuHtml(){
  const o = stoOpz();
  const sw = function(k, t, s){ return '<button type="button" class="sto-opz" onclick="event.stopPropagation();stoOpzCambia(\'' + k + '\')"><div><b>' + t + '</b><small>' + s + '</small></div><i class="switch' + (o[k] ? ' on' : '') + '"></i></button>'; };
  const parti = STO_PARTI.map(function(p){
    const on = p.k === o.parte;
    return '<button type="button" class="sto-pt' + (on ? ' fl-sel' : '') + '" aria-pressed="' + on + '" onclick="event.stopPropagation();stoParte(\'' + p.k + '\')">'
      + '<span aria-hidden="true">' + p.em + '</span><b>' + p.t + '</b>' + (p.h && p.k !== 'tutto' ? '<small>' + p.h[0] + '–' + p.h[1] + '</small>' : '') + '</button>';
  }).join('');
  const sel = function(k, da, a, v){
    let h = '';
    for (let i = da; i <= a; i++) h += '<option value="' + i + '"' + (i === v ? ' selected' : '') + '>' + i + ':00</option>';
    return '<select onclick="event.stopPropagation()" onchange="stoOreCambia(\'' + k + '\',this.value)" aria-label="' + (k === 'dalle' ? 'Dalle' : 'Alle') + '">' + h + '</select>';
  };
  return sw('secondi', 'Mostra anche i passaggi di pochi secondi', 'Ogni volta che apri un’app diventa una pagina sua.')
    + sw('home', 'Mostra anche Home, blocco schermo e tastiera', 'Di solito restano fuori, perché non sono attività.')
    + '<div class="sto-parte"><b>Scegli quale parte del giorno vedere</b><small>Vale per Rivedi la giornata e per tutte le storie.</small>'
    +   '<div class="sto-parti">' + parti + '</div>'
    +   (o.parte === 'ore' ? '<div class="sto-ore"><span>Dalle</span>' + sel('dalle', 0, 23, o.dalle) + '<span>alle</span>' + sel('alle', 1, 24, o.alle) + '</div>' : '')
    + '</div>';
}
/** Una parte del giorno: si salva e la storia riparte. "Scegli le ore" lascia il menu aperto per dalle e alle. */
function stoParte(k){
  if (!STO_PARTI.some(function(x){ return x.k === k; })) return;
  stoOpzSet('parte', k);
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  stoRifai(k === 'ore');
}
function stoOreCambia(k, v){
  stoOpzSet(k, k === 'dalle' ? stoOraN(v, 0, 23, 9) : stoOraN(v, 1, 24, 17));
  stoRifai(true);
}
/** Ricalcola la storia con le opzioni nuove: dalla prima pagina, con il menu aperto (ridisegnato) o chiuso. */
function stoRifai(menuAperto){
  if (!STO.on) return;
  const s = document.getElementById('stoSotto'); if (s) s.textContent = stoSottoTxt(STO.cfg);
  const m = document.getElementById('stoMenu');
  stoCalcola();
  if (menuAperto && m){ m.innerHTML = stoMenuHtml(); m.hidden = false; STO.ferma = true; stoVai(0); return; }
  if (m) m.hidden = true;
  STO.ferma = false; stoVai(0);
}
function stoOpzCambia(k){
  stoOpzSet(k, !stoOpz()[k]);
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  stoRifai(false);
}
function stoChiudi(subito){
  STO.on = false; STO.ferma = false; STO.giu = null; cancelAnimationFrame(STO.raf);
  document.body.classList.remove('sto-aperta');
  const w = document.getElementById('stoWrap'); if (!w) return;
  if (subito){ w.classList.remove('in'); w.hidden = true; w.innerHTML = ''; return; }
  w.classList.remove('in'); setTimeout(function(){ if (!STO.on){ w.hidden = true; w.innerHTML = ''; } }, 240);
}

/* ---- i tre posti da cui si apre ---- */
/** Una fascia oraria del possesso della partita (PST_FASCE[i]) nel periodo da-a. */
function stoFascia(i, da, a){
  const f = (typeof PST_FASCE !== 'undefined' && PST_FASCE[i]) || [0, 24];
  const giorni = Math.round((a - da) / 86400000);
  stoApri({ titolo: f[0] + ':00 – ' + f[1] + ':00', sotto: giorni <= 1 ? 'Oggi' : 'Negli ultimi ' + giorni + ' giorni', da: da, a: a, fascia: f });
}
/** Una barra del grafico di "Dove va la tua attenzione?": un'ora di oggi (o di ieri), oppure un giorno. */
function scBarStoria(ev, i){
  try{ if (ev) ev.stopPropagation(); }catch(_){ }
  const b = (SC.stoBuckets || [])[i], win = SC.stoWin; if (!b || !win) return;
  const ora = win.bucket === 'hour', da = b.start, a = Math.min(Date.now(), b.start + (ora ? 3600000 : 86400000));
  stoApri({ titolo: ora ? scOraFascia(b.start).replace(' - ', ' – ') : stoGiornoTxt(b.start), sotto: ora ? stoGiornoTxt(b.start) : 'Le attività principali', da: da, a: a, principali: !ora });
}
/** "Rivedi la giornata", in fondo al pannello: le attivita' principali di oggi (di ieri, se il pannello guarda ieri). L'ultima pagina
    offre il Report (0.9.401, BUG-184): e' l'unica strada dal pannello al Report. */
function stoGiornata(off){
  const d = (typeof scDayStart === 'function') ? scDayStart(off || 0) : new Date().setHours(0, 0, 0, 0);
  stoApri({ titolo: off ? 'La giornata di ieri' : 'La tua giornata', sotto: 'Le attività principali', da: d, a: off ? d + 86400000 : Date.now(), principali: true, report: true, off: off ? 1 : 0 });
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* la storia e' sempre scura, di giorno e di notte, come le storie di Instagram: i colori sono fissi */
  '.sto{position:fixed;inset:0;z-index:10060;display:flex;flex-direction:column;background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C);color:#fff;opacity:0;transform:scale(.98);transition:opacity .22s,transform .22s;touch-action:none;-webkit-user-select:none;user-select:none}'
  + '.sto.in{opacity:1;transform:none}.sto[hidden]{display:none}'
  + '.sto-barre{display:flex;gap:4px;padding:calc(env(safe-area-inset-top,0px) + 10px) 12px 0}.sto-barre i{flex:1;height:3px;border-radius:2px;background:rgba(255,255,255,.28);overflow:hidden}.sto-barre b{display:block;height:100%;background:#fff}'
  + '.sto-testa{display:flex;align-items:center;gap:8px;padding:12px 10px 0 16px}.sto-testa > div{flex:1;min-width:0}.sto-testa b{display:block;font:800 16px/1.25 var(--font-display);color:#fff}.sto-testa small{display:block;margin-top:2px;font:600 12.5px var(--font-body);color:rgba(232,241,255,.7)}'
  + '.sto-btn{flex:none;width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.1);color:#fff;font:800 18px/1 var(--font-body);cursor:pointer}'
  + '.sto-corpo{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:20px 24px 40px;transition:transform .2s;overflow:hidden}'
  + '.sto-pag{width:100%;max-width:400px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:22px}'
  /* un elemento dopo l'altro: ognuno sale e si accende al suo turno (--d) */
  + '.sto-a{animation:stoEntra .5s cubic-bezier(.2,.8,.2,1) var(--d,0ms) both}'
  + '@keyframes stoEntra{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}'
  + '.sto-pop{display:block;animation-name:stoPop}@keyframes stoPop{0%{opacity:0;transform:scale(.6)}70%{opacity:1;transform:scale(1.06)}100%{opacity:1;transform:none}}'
  + '.sto-quando{display:flex;align-items:center;gap:14px;text-align:left}.sto-quando b{display:block;font:800 26px/1.1 var(--font-display);color:#fff}.sto-quando small{display:block;margin-top:6px;font:600 13px var(--font-body);color:rgba(232,241,255,.72)}'
  + '.sto-oro{flex:none}.sto-lancia{transform-origin:32px 32px;transform:rotate(var(--da));transition:transform 1.5s cubic-bezier(.45,0,.2,1) .15s}.sto-pag.gira .sto-lancia{transform:rotate(var(--a))}'
  /* la pagina di un'attivita': orologio -> 38px -> pannello dell'app -> 38px -> vecchio te / nuovo te */
  + '.sto-att-p{gap:38px}'
  + '.sto-cosa{position:relative;display:flex;flex-direction:column;align-items:center;width:100%;padding:38px 20px 28px;margin-top:6px;border-radius:26px;background:linear-gradient(170deg,#1D3352,#0E1C33);border:1px solid rgba(255,255,255,.16);box-sizing:border-box;box-shadow:0 18px 40px rgba(0,0,0,.35)}'
  + '.sto-cat{position:absolute;top:0;left:50%;transform:translate(-50%,-50%);display:inline-flex;align-items:center;gap:6px;padding:6px 13px 6px 7px;border-radius:99px;white-space:nowrap;font:800 12.5px var(--font-body);letter-spacing:.02em;background:#8CC6FF;color:#001E44;box-shadow:0 6px 16px rgba(0,0,0,.3)}'
  + '.sto-fac{flex:none;width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:rgba(255,255,255,.9);color:inherit;font-style:normal;font-size:15px;line-height:1}.sto-fac svg{width:20px;height:20px}'
  + '.sto-att-p.cat-distr .sto-cosa{background:linear-gradient(170deg,#62182A,#2A0A15);border-color:rgba(255,138,147,.38)}.sto-att-p.cat-distr .sto-cat{background:#E63946;color:#fff}.sto-att-p.cat-distr .sto-fac{color:#E63946}'
  + '.sto-att-p.cat-prod .sto-cosa{background:linear-gradient(170deg,#0A4C9E,#00265A);border-color:rgba(140,198,255,.42)}.sto-att-p.cat-prod .sto-cat{background:#0075E3;color:#fff}.sto-att-p.cat-prod .sto-fac{color:#0075E3}'
  + '.sto-att-p.cat-neutro .sto-fac{color:#3F7FC0}'
  + '.sto-ico{width:72px;height:72px;border-radius:18px;object-fit:cover;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.14);font:800 30px var(--font-display);color:#fff;box-shadow:0 8px 20px rgba(0,0,0,.3)}.sto-ico.e{background:rgba(255,255,255,.1);font-size:44px;box-shadow:none}'
  + '.sto-app{margin-top:16px;font:800 23px/1.2 var(--font-display);color:#fff;overflow-wrap:anywhere}.sto-tit{margin:8px 0 0;max-width:30ch;font:600 15px/1.45 var(--font-body);color:rgba(232,241,255,.82);overflow-wrap:anywhere}'
  + '.sto-dur{margin:18px 0 0;font:800 32px/1.1 var(--font-display);color:#fff}.sto-dur small{display:block;margin-top:8px;font:600 12.5px var(--font-body);color:rgba(232,241,255,.62)}'
  /* vecchio te / nuovo te: una bilancia a due lati, acceso solo quello vero */
  + '.sto-chi-w{display:flex;flex-direction:column;align-items:center;gap:12px}.sto-chi-w small{font:600 13px var(--font-body);color:rgba(232,241,255,.7)}'
  + '.sto-bil{display:flex;gap:4px;padding:4px;border-radius:99px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12)}'
  + '.sto-bil span{padding:10px 16px;border-radius:99px;white-space:nowrap;font:800 14px var(--font-body);color:rgba(232,241,255,.75);filter:grayscale(1);opacity:.5}'
  + '.sto-bil span.on{filter:none;opacity:1}.sto-bil span.old.on{background:rgba(230,57,70,.24);color:#FF9AA2;box-shadow:inset 0 0 0 1px rgba(255,138,147,.55)}.sto-bil span.neo.on{background:rgba(63,159,244,.24);color:#A8D4FF;box-shadow:inset 0 0 0 1px rgba(140,198,255,.6)}'
  + '.sto-cop{gap:0}.sto-cop-n{font:900 68px/1 var(--font-display);color:#fff}.sto-cop-t{margin:10px 0 30px;font:700 15px var(--font-body);color:#BCE0FF}'
  + '.sto-cop-l{width:100%;display:flex;flex-direction:column;gap:12px}.sto-cop-r{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:15px 18px;border-radius:16px;background:rgba(255,255,255,.07)}.sto-cop-r span{font:700 14.5px var(--font-body);color:#fff;text-align:left}.sto-cop-r b{flex:none;font:800 15px var(--font-display)}'
  + '.sto-cop-r.old b{color:#FF8A93}.sto-cop-r.neo b{color:#8CC6FF}.sto-cop-r.nessuno b{color:rgba(232,241,255,.8)}'
  + '.sto-cop-nota{margin:26px 0 0;max-width:34ch;font:500 13px/1.5 var(--font-body);color:rgba(232,241,255,.7)}'
  + '.sto-vuota{gap:0}.sto-vuota span{font-size:56px;line-height:1}.sto-vuota b{margin-top:16px;font:800 21px/1.3 var(--font-display);color:#fff}.sto-vuota p{margin:12px 0 0;max-width:32ch;font:500 15px/1.5 var(--font-body);color:rgba(232,241,255,.8)}'
  + '.sto-fine{gap:0}.sto-fine-e{font-size:58px;line-height:1}.sto-fine b{margin-top:18px;font:800 23px/1.25 var(--font-display);color:#fff}.sto-fine p{margin:12px 0 0;max-width:30ch;font:500 15px/1.5 var(--font-body);color:rgba(232,241,255,.8)}'
  + '.sto-cta{width:100%;max-width:320px;min-height:54px;margin-top:36px;border:0;border-radius:27px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.35)}'
  + '.sto-cta2{margin-top:10px;padding:10px 18px;border:0;background:none;color:rgba(232,241,255,.75);font:700 14.5px var(--font-body);cursor:pointer}'
  + '.sto-att i{width:34px;height:34px;border-radius:50%;border:3px solid rgba(255,255,255,.2);border-top-color:#8CC6FF;animation:stoGira 1s linear infinite}.sto-att p{margin:0;font:600 15px var(--font-body);color:rgba(232,241,255,.8)}@keyframes stoGira{to{transform:rotate(360deg)}}'
  + '.sto-menu{position:absolute;top:calc(env(safe-area-inset-top,0px) + 66px);right:12px;left:12px;max-width:360px;margin-left:auto;padding:6px;border-radius:18px;background:#12203A;border:1px solid #22345A;box-shadow:0 16px 40px rgba(0,0,0,.45)}.sto-menu[hidden]{display:none}'
  + '.sto-opz{display:flex;align-items:center;gap:12px;width:100%;padding:12px;border:0;border-radius:12px;background:none;color:#fff;text-align:left;cursor:pointer}.sto-opz div{flex:1;min-width:0}.sto-opz b{display:block;font:700 14.5px var(--font-body);color:#fff}.sto-opz small{display:block;margin-top:3px;font:500 12.5px/1.4 var(--font-body);color:rgba(232,241,255,.7)}.sto-opz .switch{display:block;flex:none;pointer-events:none}'
  /* 0.9.402 BUG-231: la parte del giorno nel menu dei tre puntini. Il menu scorre se non ci sta; la scelta ha il bagliore del brand */
  + '.sto{--fl-sel-sfondo:#14305E;--fl-sel-testo:#fff;--fl-sel-bordo:#3F9FF4}'
  + '.sto-menu{max-height:calc(100% - env(safe-area-inset-top,0px) - 84px);overflow-y:auto;overscroll-behavior:none;touch-action:pan-y;box-sizing:border-box}'
  + '.sto-parte{margin:6px 6px 4px;padding:16px 6px 8px;border-top:1px solid rgba(255,255,255,.1)}.sto-parte > b{display:block;font:700 14.5px var(--font-body);color:#fff}.sto-parte > small{display:block;margin-top:3px;font:500 12.5px/1.4 var(--font-body);color:rgba(232,241,255,.7)}'
  + '.sto-parti{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:14px}'
  + '.sto-pt{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;min-height:76px;padding:10px 4px;border:1px solid rgba(255,255,255,.14);border-radius:14px;background:rgba(255,255,255,.06);color:#fff;text-align:center;cursor:pointer;box-sizing:border-box}'
  + '.sto-pt span{font-size:20px;line-height:1}.sto-pt b{font:800 12.5px/1.2 var(--font-body);color:inherit}.sto-pt small{font:600 11.5px var(--font-body);color:rgba(232,241,255,.68)}.sto-pt.fl-sel small{color:#BCE0FF}'
  + '.sto-ore{display:flex;align-items:center;flex-wrap:wrap;gap:8px 10px;margin-top:14px;font:700 14px var(--font-body);color:#fff}'
  + '.sto-ore select{min-width:88px;min-height:42px;padding:0 12px;border:1px solid rgba(255,255,255,.22);border-radius:12px;background:#1B2C4C;color:#fff;font:700 15px var(--font-body);color-scheme:dark;cursor:pointer}'
  /* lezione 307: un testo cliccabile senza forma di pulsante e' sottolineato */
  + '.sto-cta2{text-decoration:underline;text-underline-offset:3px}'
  + '@media (max-height:640px){.sto-att-p{gap:26px}.sto-cosa{padding:32px 18px 22px}.sto-ico{width:60px;height:60px}.sto-dur{font-size:28px;margin-top:14px}}'
  + '@media (prefers-reduced-motion:reduce){.sto-lancia{transition:none}.sto-a{animation:none}}';
  document.head.appendChild(st); })();

/* 0.9.400 BUG-176: il titolo del pannello su una riga sua, lontano dal pulsante dei tre puntini (anche a 360 px), e sotto il periodo,
   sottolineato a puntini con la freccina del menu a tendina. 0.9.400 BUG-174: "Rivedi la giornata" in fondo al pannello */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.rep-panel > .rep-top{padding-left:44px;padding-right:44px}.rep-senza .rep-top{padding-left:44px;padding-right:44px}'
  + '.rep-rangebtn{display:flex;flex-direction:column;align-items:center;gap:5px;max-width:100%;margin:0 auto;padding:2px 0 4px;border:0;background:none;cursor:pointer}'
  + '.rep-rangebtn .rep-rb-t{display:block;max-width:100%;font:800 15.5px/1.3 var(--font-display);color:var(--navy);overflow-wrap:anywhere}'
  + '.rep-rangebtn .rep-rb-p{display:inline-flex;align-items:center;gap:6px;font:600 13px var(--font-body);color:var(--muted);text-decoration:underline dotted;text-decoration-thickness:1.5px;text-underline-offset:4px}'
  + '.rep-rangebtn .rep-rb-p i{width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:5px solid currentColor;opacity:.8}'
  + 'body.dark .rep-rangebtn .rep-rb-t{color:#fff}'
  /* 0.9.401 BUG-184, Andrea: "Rivedi la giornata diventa testo bianco su sfondo blu del brand: il rosso resta per altro" (lezione 281).
     Il blu del brand e' lo stesso nei due temi, quindi anche il bianco del testo e' fisso */
  + '.rep-rivedi{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:50px;margin:20px 0 0;padding:13px 16px;border-radius:25px;border:0;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.28)}'
  + '.rep-rivedi svg{flex:none}.rep-rivedi:active{transform:scale(.98)}body.dark .rep-rivedi{background:#0075E3;color:#fff;box-shadow:none}'
  /* 0.9.401 BUG-194: il numero grande non va mai a capo. Sta su una riga sola, puo' usare anche lo spazio sotto ai tre puntini (che sono
     piu' in alto, accanto al titolo) e, se proprio non ci sta, si rimpicciolisce con la larghezza del pannello. Il badge del confronto
     invece puo' andare a capo */
  + '.rep-top{container-type:inline-size}.rep-top .rep-big-1{white-space:nowrap}.rep-panel > .rep-top .rep-big-1{margin-left:-32px;margin-right:-32px}'
  + '.rep-top .rep-big-g{font-size:min(32px,calc(100cqi / 9.3));margin-bottom:10px}.rep-panel > .rep-top .rep-big-g{font-size:min(32px,calc((100cqi + 64px) / 9.3))}'
  + '.rep-top .rep-badge{max-width:100%;box-sizing:border-box;white-space:normal;line-height:1.35}'
  + '.pst-pr.tocca{cursor:pointer;border-radius:10px;transition:background .15s}.pst-pr.tocca:active{background:rgba(140,198,255,.12)}';
  document.head.appendChild(st); })();

/* 0.9.402 BUG-260, Andrea: "Navigazione e Ieri vanno a capo anche quando c'e' spazio" (lezione 360). Il periodo sottolineato a puntini
   sta sulla riga del titolo quando ci sta, e va sotto solo se il titolo arriva vicino ai tre puntini: e' la fila che va a capo da sola
   (flex-wrap), misurata dal browser sulla larghezza vera, non una regola fissa. Il margine dai tre puntini e' il padding di .rep-top (44 px).
   Il badge del confronto sta su una riga sola: puo' usare anche lo spazio sotto ai tre puntini (che sono piu' in alto), resta centrato,
   e se sborda lo accorcia scBadgeAdatta */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.rep-top .rep-rangebtn{flex-direction:row;flex-wrap:wrap;justify-content:center;align-items:baseline;column-gap:8px;row-gap:5px}'
  + '.rep-top .rep-rangebtn .rep-rb-t{min-width:0}.rep-top .rep-rangebtn .rep-rb-p{flex:none;white-space:nowrap}'
  + '.rep-top .rep-badge{display:block;width:max-content;max-width:100%;margin-left:auto;margin-right:auto;white-space:nowrap;overflow:hidden;text-overflow:clip}'
  + '.rep-panel > .rep-top .rep-badge{max-width:calc(100% + 64px);margin-left:50%;margin-right:0;transform:translateX(-50%)}';
  document.head.appendChild(st); })();
