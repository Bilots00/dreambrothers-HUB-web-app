/* ===========================================================================================
   IL SENTIERO DI OGGI — tre tappe al giorno, una serie da non spezzare, uno scrigno (0.9.176)

   Quello che Duolingo fa con una lingua, qui si fa con un sogno. La lezione di cinque minuti
   diventa tre tappe che l'app misura da sola o quasi:
     1. le domande del Genio     (la lettura a episodi, poi la stagione 2, poi il check)
     2. la riga del foglio        (una sessione di Full Focus portata a termine, oggi)
     3. la missione verso il sogno (un'azione concreta da 10-25 minuti, dal catalogo del sogno)
   Ogni tappa vale esperienza (livelli) e un feedback immediato che NON e' sempre uguale: quattro
   volte su cinque un colpetto e due parole, una su cinque una festa con una frase del Genio.
   A tre tappe su tre si apre lo scrigno: dentro c'e' una cosa diversa ogni volta.

   LA SERIE (streak): un giorno conta se almeno una tappa e' fatta. La soglia e' bassa apposta:
   una serie che si spezza per una giornata storta insegna a mollare, una che regge insegna a
   tornare. Ogni sette giorni di fila si guadagna un gettone che copre un giorno saltato. La
   sera, alle 21:30, se la serie e' a rischio, il Genio lo dice con una notifica (Avvisi.java).

   IL PERCORSO E' LINEARE: nessun menu, nessuna scelta da fare. Si tocca la prossima tappa.

   I testi (etichette, frasi dei premi, missioni, domande della stagione 2 e del check) vivono
   in content/sentiero.json e li scrive il Copywriter (ruolo nel company brain), non il codice.
   =========================================================================================== */

const SN_KEY = 'fl_sentiero';
const SN_XP = { q: 0, m: 0, x: 0, scrigno: 0 };   /* l'esperienza la danno i nodi del sentiero (sentiero-mappa.js) */
const SN_AVVISO_ID = 7;
const SN = { cfg: null, caricato: false, festaT: 0 };

/* ---------- lo stato ---------- */
function snOggi(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function snIeri(){ return snOggi(Date.now() - 86400000); }
function snStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(SN_KEY) || 'null'); }catch(_){ }
  if (!s) s = {};
  s.giorni = s.giorni || {}; s.xp = s.xp || 0;
  s.serie = Object.assign({ n: 0, ultimo: '', gettoni: 0, max: 0, persa: '', coperto: '' }, s.serie || {});
  s.missioni = Object.assign({ fatte: [], salta: 0, saltaGiorno: '', corrente: null }, s.missioni || {});
  return s;
}
function snSalva(s){ try{ localStorage.setItem(SN_KEY, JSON.stringify(s)); }catch(_){ } }
function snGiorno(s, k){ k = k || snOggi(); if (!s.giorni[k]) s.giorni[k] = {}; return s.giorni[k]; }
function snXp(){ return snStato().xp || 0; }
function snEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x == null ? '' : x); }

/* i testi: dal JSON, con una riga di riserva se il file non e' ancora arrivato */
const SN_RISERVA = {
  titolo: 'Il percorso di oggi', tappa_domande: 'Le domande del Genio', tappa_mossa: 'La riga del foglio in Full Focus', tappa_missione: 'La missione verso il sogno',
  tutte_fatte: 'Tre su tre. Oggi hai camminato verso il sogno, e la sfera lo sa.', scrigno_titolo: 'La mystery box', scrigno_apri: 'Aprila',
  serie_etichetta: 'giorni in rotta', serie_rischio: 'La tua serie di {n} giorni si spegne a mezzanotte. Una tappa basta.',
  serie_persa: 'La serie si è spezzata. Non conta quante volte cade. Conta che oggi riparte.', pausa_guadagnata: 'Hai guadagnato un congelamento della serie. Copre un giorno di tappe saltato, una volta.',
  premi_rari: ['La sfera ha fatto una luce che non le avevo mai visto.', 'Questo passo lo ricorderò io per te.', 'Il vecchio te oggi non ha toccato palla.', 'Un giorno così vale una settimana di quelli tiepidi.', 'Ho aggiornato la previsione. In meglio.'],
  premi_normali: ['Fatto.', 'Un passo.', 'Segnato.', 'Avanti così.', 'Lo vedo.'],
  missione_fatta_btn: 'Fatta', missione_focus_btn: 'In Full Focus', missione_cambia: 'Un\'altra',
  check_titolo: 'Il check della settimana', check_tema: 'come è andata la settimana', check_chiusura: 'Sette giorni letti. *Tocca la sfera.*'
};
function snT(k, v){
  let s = (SN.cfg && SN.cfg.sentiero && SN.cfg.sentiero[k] != null) ? SN.cfg.sentiero[k] : SN_RISERVA[k];
  if (Array.isArray(s)) return s;
  s = String(s == null ? '' : s);
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  return s;
}
function snAccendi(s){ return snEsc(s).replace(/\*([^*]+)\*/g, '<b>$1</b>'); }

/* ---------- il contenuto ---------- */
async function snCarica(){
  if (SN.caricato) return SN.cfg;
  SN.caricato = true;
  try{
    const r = await fetch('content/sentiero.json', { cache: 'no-cache' });
    if (r.ok) SN.cfg = await r.json();
  }catch(_){ SN.cfg = null; }
  snInnestaDomande();
  try{ if (typeof nvPaint === 'function' && document.getElementById('nvTop')) nvPaint(); }catch(_){ }
  try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ }
  return SN.cfg;
}
/* la stagione 2 entra nella lettura a episodi (domande.js) dopo il finale: stessa scena,
   stesse regole, altri sette giorni */
function snInnestaDomande(){
  try{
    if (!SN.cfg || typeof DQ_EPISODI === 'undefined') return;
    (SN.cfg.stagione2 || []).forEach(function(ep){
      if (!ep || !ep.n) return;
      if (DQ_EPISODI.some(function(e){ return e.n === ep.n; })) return;
      ep.stagione = 2;
      DQ_EPISODI.push(ep);
    });
  }catch(_){ }
}
function snMissioniDi(){
  let k = 'scrivo';
  try{ k = (typeof gnDati === 'function' && gnDati().sognoK) || 'scrivo'; }catch(_){ }
  const m = (SN.cfg && SN.cfg.missioni) || {};
  /* 0.9.382, Andrea: "se ho scelto l'e-commerce non mi devi proporre Scrivi in una riga cosa vendi e a chi: non e' network marketing".
     Dentro la carta progetto ogni sogno preciso ha i suoi passi; la lista generica resta per chi non ha scelto */
  try{
    const det = (typeof gnDati === 'function' && gnDati().sognoDettaglio) || '';
    if (SN_MIS_DETTAGLIO[det]) return SN_MIS_DETTAGLIO[det];
  }catch(_){ }
  return m[k] || m.scrivo || [];
}
/* 0.9.390 (BUG-122), Andrea: "Guarda quali prodotti hanno venduto di più nell'ultimo mese, 45 minuti: non ci vogliono 45 minuti. Lo legge
   l'intelligenza artificiale collegata al business in 2 secondi, mentre l'utente dorme. Devi togliere decisioni all'utente e fare passi
   concreti: quello è un micro step, non un passo da prenotare nel calendario". Un passo di serie e' un'azione che fa avanzare (produrre,
   lanciare, vendere, contattare, pubblicare, costruire). Guardare, controllare, cercare, leggere numeri lo fa l'AI: al massimo e' una riga
   dentro al passo vero che usa quel dato. Il tempo e' quello che il compito richiede davvero. Lo controlla tools/test-passi-azione.js. */
/* 0.9.402 (BUG-255), Andrea: per i sogni di business le tappe di base seguono il 4-4-4 di Alex Hormozi per chi parte da zero: prima
   Promote (far sapere che esisti, validare l'interesse), poi Deliver (dare ai clienti quello che hai promesso), poi Build (sistemi,
   procedure, l'offerta migliorata con i feedback veri). Il contesto conta: chi ha gia' un'attivita' avviata (il sogno e' "Far crescere",
   gnSognoCrescita in genio-intro.js) parte dalla consegna, perche' "un ottimo marketing fa fallire piu' in fretta un cattivo prodotto".
   Le ore per parte non sono obbligatorie: chi ne dedica meno arriva dopo, e l'arrivo previsto (eta-motore.js, il ritmo in ore) lo mostra.
   Il campo fase dice la parte di ogni passo. Le liste del negozio restano lunghe come prima (6): la tappa missione legge il passo per
   posizione (sdMisIndice) e le missioni fatte sono posizioni (snStato().missioni.fatte), quindi le tappe gia' fatte restano fatte.
   La stessa regola la segue l'agente quando scrive la roadmap (server, dreammapRegolaBusiness.ts). Lo controlla tools/test-hormozi-402.js. */
const SN_MIS_NEGOZIO = [
  { t: 'Pubblica una foto del tuo prodotto sui social, con il prezzo (15 min)', s: 'Prima di costruire il negozio si fa sapere che esisti. Conta chi ti scrive per comprarlo, non i like.', min: 15, fase: 'promote' },
  { t: 'Manda la foto del prodotto a cinque persone che potrebbero comprarlo (15 min)', s: 'Chiedi se lo comprerebbero, e a quanto. Un sì prima del negozio vale più di un negozio perfetto.', min: 15, fase: 'promote' },
  { t: 'Carica nel negozio i primi tre prodotti, con nome e prezzo (20 min)', s: 'Quelli che hanno avuto più risposte. Il prezzo lo fissi con quanto ti resta in tasca. Se hai il tuo agente personale, il conto lo fa lui.', min: 20, fase: 'deliver' },
  { t: 'Imposta spedizioni e resi nel negozio (20 min)', s: 'È la prima cosa che il cliente controlla prima di comprare.', min: 20, fase: 'deliver' },
  { t: 'Apri il negozio e manda il link a chi ti ha detto sì (15 min)', s: 'Prima fai un ordine di prova. Dove ti blocchi tu, si blocca anche lui. Poi togli la password. Un negozio chiuso non vende, anche se è perfetto.', min: 15, fase: 'deliver' },
  { t: 'Rifai la scheda del prodotto con le domande dei primi clienti (25 min)', s: 'Quello che ti chiedono è quello che manca nella scheda. Si costruisce sui feedback veri, non su quelli immaginati.', min: 25, fase: 'build' }
];
const SN_MIS_NEGOZIO_CRESCI = [
  { t: 'Sistema la cosa di cui i clienti si lamentano più spesso (30 min)', s: 'Ritardi, pacchi rovinati, resi lenti. Prima si sistema la consegna, poi si spinge il marketing. Un ottimo marketing fa fallire più in fretta un cattivo prodotto. Se la tua AI è collegata al negozio, i reclami li mette in fila lei.', min: 30, fase: 'deliver' },
  { t: 'Chiedi una recensione a tre clienti contenti (10 min)', s: 'Le recensioni vendono al posto tuo.', min: 10, fase: 'deliver' },
  { t: 'Scrivi ai clienti che hanno comprato una volta sola (20 min)', s: 'Chi ha già comprato ricompra più facilmente di uno sconosciuto.', min: 20, fase: 'promote' },
  { t: 'Metti in prima pagina il prodotto che ha venduto di più nell’ultimo mese (15 min)', s: 'La classifica delle vendite te la dà il negozio in un secondo, o la tua AI se è collegata al negozio. Non va studiata. Il passo è dare più spazio a quello che già funziona.', min: 15, fase: 'promote' },
  { t: 'Gira e pubblica un video con il tuo prodotto migliore (30 min)', s: 'Mostralo mentre risolve il problema, non solo in vetrina.', min: 30, fase: 'promote' },
  { t: 'Togli un passaggio in più dal carrello del negozio (20 min)', s: 'Un campo inutile, un costo che compare solo alla fine, una pagina di troppo. Dove si fermano i clienti lo dice il negozio nei suoi rapporti. Ogni ostacolo tolto è una vendita in più.', min: 20, fase: 'build' }
];
/* chi fa gia' crescere un'attivita' o un prodotto (prima prendeva la lista di chi parte da zero, content/sentiero.json "progetto"):
   prima la consegna, poi i clienti nuovi, poi i sistemi. Lunga come quella (8), per la stessa ragione delle posizioni. */
const SN_MIS_ATTIVITA_CRESCI = [
  { t: 'Chiedi a tre clienti cosa li ha delusi, anche poco (15 min)', s: 'Un’attività avviata parte dalla consegna. Prima si sistema quello che dai, poi si cercano clienti nuovi. Un ottimo marketing fa fallire più in fretta un cattivo prodotto.', min: 15, fase: 'deliver' },
  { t: 'Sistema la cosa di cui i clienti si lamentano più spesso (30 min)', s: 'Un ritardo, una risposta che non arriva, un passaggio confuso. Se hai il tuo agente personale, i reclami li mette in fila lui. Tu scegli cosa sistemare.', min: 30, fase: 'deliver' },
  { t: 'Chiedi una recensione a tre clienti contenti (10 min)', s: 'Le recensioni vendono al posto tuo.', min: 10, fase: 'deliver' },
  { t: 'Scrivi ai clienti che hanno comprato una volta sola (20 min)', s: 'Chi ha già comprato ricompra più facilmente di uno sconosciuto.', min: 20, fase: 'promote' },
  { t: 'Chiedi a tre clienti contenti di presentarti una persona (15 min)', s: 'Un cliente contento che ti presenta qualcuno vale più di cento inserzioni.', min: 15, fase: 'promote' },
  { t: 'Gira e pubblica un video su un cliente che hai aiutato (30 min)', s: 'Mostra il prima e il dopo. Si fa sapere che esisti con una prova vera.', min: 30, fase: 'promote' },
  { t: 'Scrivi i passi che ripeti per ogni cliente, in una lista (20 min)', s: 'È la tua prima procedura. La prossima volta la segui, o la passi a qualcuno.', min: 20, fase: 'build' },
  { t: 'Cambia l’offerta con quello che ti hanno detto i clienti (20 min)', s: 'Si costruisce su quello che i clienti chiedono davvero, non su quello che immagini tu.', min: 20, fase: 'build' }
];
const SN_MIS_DETTAGLIO = { 'Aprire il mio negozio online': SN_MIS_NEGOZIO, 'Far crescere il mio negozio online': SN_MIS_NEGOZIO_CRESCI,
  'Far crescere la mia attività': SN_MIS_ATTIVITA_CRESCI, 'Far crescere le vendite del mio prodotto': SN_MIS_ATTIVITA_CRESCI };
/** Il passo di un catalogo che comincia con `inizio` (i sostituti sotto puntano al testo, non alla posizione, che puo' cambiare). */
function snMisCon(lista, inizio){ return lista.filter(function(m){ return m.t.indexOf(inizio) === 0; })[0] || lista[0]; }
const SN_PASSI_SOSTITUITI = {
  'Guarda quali prodotti hanno venduto di più nell’ultimo mese': snMisCon(SN_MIS_NEGOZIO_CRESCI, 'Metti in prima pagina'),
  'Guarda come vendono tre negozi online del tuo settore': snMisCon(SN_MIS_NEGOZIO, 'Carica nel negozio'),
  'Calcola il margine di un prodotto': snMisCon(SN_MIS_NEGOZIO, 'Carica nel negozio'),
  'Scegli i primi tre prodotti da mettere in vendita': snMisCon(SN_MIS_NEGOZIO, 'Carica nel negozio'),
  'Controlla dove i visitatori abbandonano il carrello': snMisCon(SN_MIS_NEGOZIO_CRESCI, 'Togli un passaggio'),
  'Migliora le foto e il titolo del prodotto che vende di più': snMisCon(SN_MIS_NEGOZIO, 'Rifai la scheda'),
  'Prepara un contenuto per i social con il tuo prodotto migliore': snMisCon(SN_MIS_NEGOZIO_CRESCI, 'Gira e pubblica'),
  'Guarda cosa fanno tre concorrenti': { t: 'Scrivi cosa offri tu che i concorrenti non danno (15 min)', min: 15 },
  'Fai la lista di 10 possibili clienti': { t: 'Scrivi a tre persone che potrebbero comprare (15 min)', min: 15 },
  'Guarda come lavora chi ci vive già': { t: 'Rifai un lavoro di chi ci vive già, a modo tuo (20 min)', min: 20 },
  'Trova chi paga per questa cosa, e come': { t: 'Scrivi a chi vive già di questa passione (15 min)', min: 15 },
  'Scrivi cosa hai mangiato oggi, tutto': { t: 'Togli di casa i dolci e gli snack (10 min)', min: 10 },
  'Rivedi 3 tuoi video e segna un errore': { t: 'Rifai il video che ti è venuto peggio (25 min)', min: 25 },
  'Leggi un passo e fermati su una riga': { t: 'Prega su una riga di un testo sacro (10 min)', min: 10 },
  'Trova 3 persone che vivono già così': { t: 'Scrivi a una persona che lavora già da dove vuole (15 min)', min: 15 },
  'Cerca chi ha già realizzato un sogno come il tuo, e come ci è riuscito': { t: 'Scrivi a chi ha già realizzato un sogno come il tuo (15 min)', min: 15 }
};
/** Il passo di serie che sostituisce un testo vecchio di sola raccolta dati, oppure null. */
function snPassoSostituito(t){
  const k = String(t || '').replace(/\s*\(\d+\s*min\)\s*$/i, '').trim();
  const n = SN_PASSI_SOSTITUITI[k] || SN_PASSI_SOSTITUITI[k.replace(/'/g, '’')] || null;
  /* il sottotitolo dei passi nuovi delle missioni per sogno sta in content/sentiero.json */
  let x = null;
  try{ if (n && !n.s && SN.cfg && SN.cfg.missioni) Object.keys(SN.cfg.missioni).some(function(c){ x = (SN.cfg.missioni[c] || []).filter(function(m){ return m && m.t === n.t; })[0] || null; return !!x; }); }catch(_){ x = null; }
  return x || n;
}

/* ---------- le tappe ---------- */
/* La lettura: l'episodio di oggi (stagione 1 o 2), oppure il check della settimana quando
   e' il suo giorno. null = oggi non c'e' niente da chiedere. */
function snDomandeOggi(){
  /* 0.9.300: l'episodio di oggi e' quello della serie del Genio (episodi.js), in Dream */
  try{
    if (typeof epiOggi === 'function' && typeof EPI !== 'undefined' && EPI.cfg){
      if (epiVistoOggi()) return { tipo: 'fatto' };
      const o = epiOggi();
      if (o.x && (o.st.k === 'da-vedere' || o.st.k === 'in-corso')) return { tipo: 'episodio', ep: { n: o.x.n, titolo: o.x.titolo, stagione: o.x.s } };
      if (snCheckDovuto()) return { tipo: 'check' };
      return null;
    }
  }catch(_){ }
  if (typeof dqProssimo !== 'function') return null;
  if (dqFattoOggi()) return { tipo: 'fatto' };
  const ep = dqProssimo();
  if (ep) return { tipo: 'episodio', ep: ep };
  if (snCheckDovuto()) return { tipo: 'check' };
  return null;
}
function snCheckDovuto(){
  if (!SN.cfg || !(SN.cfg.check || []).length) return false;
  const s = dqStato();
  let ultimo = 0;
  Object.keys(s.fatti).forEach(function(n){ const f = s.fatti[n]; if (f && f.at > ultimo) ultimo = f.at; });
  if (s.finale && s.finale > ultimo) ultimo = s.finale;
  return ultimo > 0 && Date.now() - ultimo >= 6.5 * 86400000;
}
function snCheckSettimana(){ return Math.floor(Date.now() / (7 * 86400000)); }
function snCheckApri(){
  if (!SN.cfg || typeof GN === 'undefined') return;
  const w = snCheckSettimana();
  const ep = { n: 'ck' + w, check: true, titolo: snT('check_titolo'), tema: snT('check_tema'), chiusura: snT('check_chiusura'),
    domande: (SN.cfg.check || []).map(function(q){ return Object.assign({}, q, { id: q.id + '_w' + w }); }) };
  GN.on = true; GN.modo = 'dq'; DQ.ep = ep; DQ.i = 0; DQ.tass = false;
  GN.audio = true;
  goId('s-genio'); dqBarra(); gnVai('dq');
}
function snTappaQ(){
  const d = snDomandeOggi();
  if (!d) return { stato: 'niente' };
  if (d.tipo === 'fatto') return { stato: 'fatta' };
  return { stato: 'da-fare', dettaglio: d };
}
/* La mossa: una sessione di Full Focus portata a termine oggi. La misura il telefono. */
function snSessioneOggi(){
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const alba = new Date(); alba.setHours(0, 0, 0, 0);
  /* 0.9.389 (BUG-115), Andrea: "il punto per essere assegnato deve essere dentro la pagina di Full Focus": una sessione andata avanti da sola non conta (ffPuntoValido) */
  return h.filter(function(x){ return (typeof ffPuntoValido === 'function' ? ffPuntoValido(x) : (x && x.ok)) && !x.meditazione && x.at >= alba.getTime(); });
}
function snTappaM(){ return { stato: snSessioneOggi().length ? 'fatta' : 'da-fare' }; }
/* La missione: dal catalogo del sogno, in ordine; «un'altra» ne salta una (tre al giorno). */
function snMissione(){
  const lista = snMissioniDi(); if (!lista.length) return null;
  const s = snStato(), m = s.missioni;
  if (m.saltaGiorno !== snOggi()){ m.salta = 0; m.saltaGiorno = snOggi(); }
  const i = (m.fatte.length + m.salta) % lista.length;
  const mis = Object.assign({ i: i }, lista[i]);
  if (!m.corrente || m.corrente.i !== i || m.corrente.giorno !== snOggi()){ m.corrente = { i: i, t: mis.t, giorno: snOggi() }; snSalva(s); }
  return mis;
}
function snMissioneCambia(){
  const s = snStato(); if (s.missioni.saltaGiorno !== snOggi()){ s.missioni.salta = 0; s.missioni.saltaGiorno = snOggi(); }
  if (s.missioni.salta >= 3){ toast('Tre cambi al giorno. Questa è la tua.'); return; }
  s.missioni.salta++; snSalva(s); snPaint();
}
function snMissioneFocus(){
  const mis = snMissione(); if (!mis) return;
  try{ const p = ffPref(); p.intent = mis.t.slice(0, 250); if (mis.min) p.minutes = Math.max(10, Math.min(90, mis.min)); ffSavePref(); }catch(_){ }
  try{ ffOpen(); }catch(_){ }
}
function snMissioneFatta(){
  const s = snStato(), g = snGiorno(s); if (g.x) return;
  const mis = snMissione();
  if (mis && s.missioni.fatte.indexOf(mis.i) < 0) s.missioni.fatte.push(mis.i);
  snSalva(s);
  snTick();
}
function snTappaX(){
  const s = snStato(), g = snGiorno(s);
  if (g.x) return { stato: 'fatta' };
  /* fatta dentro Full Focus: la sessione di oggi con l'intento della missione */
  const mis = snMissione(); if (!mis) return { stato: 'niente' };
  const ok = snSessioneOggi().some(function(x){ return x.intent && mis.t && x.intent.slice(0, 40) === mis.t.slice(0, 40); });
  if (ok){ if (s.missioni.fatte.indexOf(mis.i) < 0) s.missioni.fatte.push(mis.i); snSalva(s); return { stato: 'fatta', auto: true }; }
  return { stato: 'da-fare', mis: mis };
}

/* ---------- il conto: chi e' passato oggi, la serie, lo scrigno ---------- */
function snTick(){
  const s = snStato(), k = snOggi(), g = snGiorno(s, k);
  const t = { q: snTappaQ(), m: snTappaM(), x: snTappaX() };
  const nuove = [];
  ['q', 'm', 'x'].forEach(function(c){
    if (t[c].stato === 'fatta' && !g[c]){ g[c] = Date.now(); s.xp += SN_XP[c]; nuove.push(c); }
  });
  /* la serie: un giorno conta con una tappa; il gettone copre un giorno saltato */
  const fatteOggi = ['q', 'm', 'x', 'e'].filter(function(c){ return g[c]; }).length;   /* 'e' = un esercizio a tempo (esercizi.js) */
  const se = s.serie;
  if (se.ultimo && se.ultimo !== k && se.ultimo !== snIeri() && se.n > 0){
    const salto = Math.round((new Date(k + 'T12:00:00') - new Date(se.ultimo + 'T12:00:00')) / 86400000) - 1;
    /* 0.9.351: i congelamenti li consuma una sola funzione, quella della mappa (sdCopriBuchi). Prima li scalavano tutte e due per lo
       stesso giorno saltato: uno appena guadagnato spariva subito e il foglio diceva 0 su 2 */
    let copertoMappa = false; try{ copertoMappa = !!(sdStato().coperti || {})[snIeri()]; }catch(_){ }
    if (salto === 1 && (copertoMappa || se.gettoni > 0)){ se.coperto = snIeri(); se.ultimo = snIeri(); }
    else { se.persa = k; se.n = 0; se.ultimo = ''; }
  }
  if (fatteOggi > 0 && se.ultimo !== k){
    se.n = (se.ultimo === snIeri()) ? se.n + 1 : 1;
    se.ultimo = k;
    if (se.n > se.max) se.max = se.n;
    /* 0.9.323, Andrea (Duolingo): "si guadagna per aver studiato anche oggi, non una volta a settimana: all'inizio deve essere piu' facile salvarsi".
       Al secondo e al quarto giorno, poi ogni cinque */
    if ((se.n === 2 || se.n === 4 || (se.n > 4 && (se.n - 4) % 5 === 0)) && se.gettoni < 2){ se.gettoni++; g.gettone = Date.now(); try{ localStorage.setItem('fl_gelo_oggi', snOggi ? snOggi() : ''); }catch(_){ } }
  }
  snSalva(s);
  /* la festa la fa la fine tappa del sentiero, non piu' qui */
  snAvviso();
  if (nuove.length) try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  return { tappe: t, giorno: g, serie: se, nuove: nuove };
}
function snTappeDisponibili(t){ return ['q', 'm', 'x'].filter(function(c){ return t[c].stato !== 'niente'; }); }
function snTutteFatte(t){ const d = snTappeDisponibili(t); return d.length > 0 && d.every(function(c){ return t[c].stato === 'fatta'; }); }

/* la notifica delle 21:30: solo se la serie vale qualcosa e oggi non si e' ancora mosso niente.
   0.9.310: confluita negli avvisi della serie delle 20, 22 e 23 (serie-avvisi.js, SerieAvvisi.java), che contano la
   serie vera della mappa (sdSerieMappa) e non questa: qui si toglie l'avviso vecchio e si aggiornano quelli nuovi. */
function snAvviso(){
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.avvisoAnnulla) NATIVE.avvisoAnnulla({ id: SN_AVVISO_ID }); }catch(_){ }
  try{ if (typeof svaSync === 'function') svaSync(); }catch(_){ }
}

/* ---------- la festa: quattro volte su cinque un colpetto, una su cinque una frase del Genio ---------- */
function snFesta(tappa, xpO){
  const rara = Math.random() < 0.2;
  const frasi = rara ? snT('premi_rari') : snT('premi_normali');
  const frase = frasi[Math.floor(Math.random() * frasi.length)] || '';
  const xp = (xpO != null) ? xpO : (SN_XP[tappa] || 0);
  let el = document.getElementById('snFesta');
  if (!el){ el = document.createElement('div'); el.id = 'snFesta'; (document.getElementById('phone') || document.body).appendChild(el); }
  el.className = 'sn-festa' + (rara ? ' rara' : '');
  el.innerHTML = '<div class="sn-festa-in">' + (rara ? '<img src="img/genio/genio-rivela.png" alt="">' : '') + '<b class="sn-xp">+' + xp + '</b><span>' + snAccendi(frase) + '</span></div>'
    + (rara ? '<i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>' : '');
  try{
    if (typeof gnAu !== 'undefined'){ if (rara) gnAu.punto(); else gnAu.scelta(3 + Math.floor(Math.random() * 3)); }
    flVibra(rara ? [30, 40, 80] : 18);
  }catch(_){ }
  clearTimeout(SN.festaT);
  el.hidden = false;
  SN.festaT = setTimeout(function(){ el.hidden = true; }, rara ? 3200 : 1600);
}

/* ---------- lo scrigno: a tre su tre, una cosa diversa ogni volta ---------- */
function snScrignoApri(){
  const s = snStato(), g = snGiorno(s);
  if (g.scrigno) return;
  const r = Math.random();
  let premio;
  const suoni = ['sound:ocean', 'sound:wind', 'sound:fire', 'sound:night', 'sound:cafe'].filter(function(x){ try{ return !lvHas(x); }catch(_){ return false; } });
  if (r < 0.12 && suoni.length){ const sg = suoni[0]; try{ lvGrantExtra(sg); }catch(_){ } premio = { tipo: 'suono', t: 'Un suono nuovo per il Full Focus', s: { 'sound:ocean': 'Oceano', 'sound:wind': 'Vento', 'sound:fire': 'Camino', 'sound:night': 'Foresta notturna', 'sound:cafe': 'Caffè' }[sg] }; }
  else if (r < 0.27 && s.serie.gettoni < 2){ s.serie.gettoni++; premio = { tipo: 'gettone', t: 'Un gettone', s: 'Copre un giorno saltato. La serie non si spezza.' }; }
  else if (r < 0.5){ const frasi = snT('premi_rari'); premio = { tipo: 'frase', t: 'Una frase del Genio', s: frasi[Math.floor(Math.random() * frasi.length)] || '' }; }
  else { const xp = 20 + Math.floor(Math.random() * 5) * 10; s.xp += xp; premio = { tipo: 'xp', t: '+' + xp + ' esperienza', s: 'Va sul tuo livello, adesso.' }; }
  g.scrigno = Date.now(); g.premio = premio;
  snSalva(s);
  try{ if (typeof gnAu !== 'undefined') gnAu.punto(); flVibra([20, 30, 60]); }catch(_){ }
  try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  snPaint(true);
}

/* ---------- la card nella Rotta ---------- */
function snCardHtml(){
  if (!SN.caricato) snCarica();
  const r = snTick();
  const t = r.tappe, g = r.giorno, se = r.serie;
  const disp = snTappeDisponibili(t), fatte = disp.filter(function(c){ return t[c].stato === 'fatta'; }).length;
  const tutte = snTutteFatte(t);
  const xpOggi = ['q', 'm', 'x'].reduce(function(a, c){ return a + (g[c] ? SN_XP[c] : 0); }, 0) + (g.premio && g.premio.tipo === 'xp' ? parseInt(g.premio.t, 10) || 0 : 0);
  /* tappa 1: le domande */
  let q1 = '', b1 = '';
  let pct = 0; try{ pct = dqConoscenza(); }catch(_){ }
  if (t.q.stato === 'fatta'){ q1 = 'Fatte. Il Genio ti conosce al ' + pct + '%.'; }
  else if (t.q.stato === 'niente'){ q1 = 'Oggi niente domande. Il check della settimana arriva da solo.'; }
  else if (t.q.dettaglio.tipo === 'check'){ q1 = 'Sette domande per misurare la settimana.'; b1 = '<button type="button" class="sn-go" onclick="snCheckApri()">Rispondi</button>'; }
  else { const ep = t.q.dettaglio.ep; q1 = (ep.stagione === 2 ? 'Stagione 2 · ' : '') + 'Episodio ' + ep.n + ' · ' + snEsc(ep.titolo) + ' · due minuti.'; b1 = '<button type="button" class="sn-go" onclick="' + (typeof epiTocca === 'function' ? 'epiTocca(' + (ep.stagione || 1) + ',' + ep.n + ')' : 'dqApri()') + '">' + (ep.n === 1 ? 'Comincia' : 'Rispondi') + '</button>'; }
  /* tappa 2: la riga del foglio */
  let q2 = '', b2 = '';
  if (t.m.stato === 'fatta'){ const n = snSessioneOggi().length; q2 = n + (n === 1 ? ' sessione portata a termine oggi.' : ' sessioni portate a termine oggi.'); }
  else { let riga = ''; try{ riga = (typeof nvTask === 'function') ? (nvTask() || '') : ''; }catch(_){ } q2 = riga ? '«' + snEsc(riga) + '»' : 'Il foglio è vuoto. Scrivi la riga di oggi.'; b2 = riga ? '<button type="button" class="sn-go" onclick="if(typeof stGoFocus===\'function\')stGoFocus();else ffOpen()">▶ Inizia</button>' : '<button type="button" class="sn-go sec" onclick="switchTab(\'sveglia\')">Apri il foglio</button>'; }
  /* tappa 3: la missione */
  let q3 = '', b3 = '';
  if (t.x.stato === 'fatta'){ const m = snStato().missioni.corrente; q3 = 'Fatta' + (m && m.t ? ': ' + snEsc(m.t) : '') + '.'; }
  else if (t.x.stato === 'niente'){ q3 = 'Il catalogo delle missioni sta arrivando.'; }
  else { const mis = t.x.mis; q3 = '<b class="sn-mis">' + snEsc(mis.t) + '</b>' + (mis.s ? '<span class="sn-mis-s">' + snEsc(mis.s) + '</span>' : '');
    b3 = '<div class="sn-btns"><button type="button" class="sn-go" onclick="snMissioneFocus()">' + snEsc(snT('missione_focus_btn')) + '</button><button type="button" class="sn-go sec" onclick="snMissioneFatta()">' + snEsc(snT('missione_fatta_btn')) + '</button><button type="button" class="sn-link" onclick="snMissioneCambia()">' + snEsc(snT('missione_cambia')) + '</button></div>'; }
  const riga = function(n, c, titolo, testo, btn){
    const st = t[c].stato;
    return '<div class="sn-tappa ' + st + '"><div class="sn-cerchio">' + (st === 'fatta' ? '✓' : (st === 'niente' ? '·' : n)) + '</div><div class="sn-corpo"><small>' + snEsc(titolo) + '</small><p>' + testo + '</p>' + (btn || '') + '</div></div>';
  };
  let fondo = '';
  if (tutte){
    if (g.scrigno && g.premio) fondo = '<div class="sn-premio"><span>🎁</span><div><small>' + snEsc(g.premio.t) + '</small><b>' + snAccendi(g.premio.s || '') + '</b></div></div>';
    else fondo = '<div class="sn-scrigno" onclick="snScrignoApri()"><span class="sn-scrigno-ico">🎁</span><div><small>' + snEsc(snT('scrigno_titolo')) + '</small><b>' + snAccendi(snT('tutte_fatte')) + '</b></div><button type="button" class="sn-go">' + snEsc(snT('scrigno_apri')) + '</button></div>';
  } else if (se.persa === snOggi() && !fatte){
    fondo = '<p class="sn-nota">' + snAccendi(snT('serie_persa')) + '</p>';
  } else if (g.gettone && snOggi(g.gettone) === snOggi()){
    fondo = '<p class="sn-nota">' + snAccendi(snT('pausa_guadagnata')) + '</p>';
  }
  return '<div class="sn-card">'
    + '<div class="sn-top"><div><small>' + snEsc(snT('titolo')) + '</small><b>' + fatte + ' di ' + disp.length + (xpOggi ? ' · +' + xpOggi : '') + '</b></div>'
    +   '<div class="sn-serie' + (se.n > 0 ? ' on' : '') + '"><span>🔥</span><b>' + se.n + '</b><small>' + snEsc(se.n === 1 ? snT('serie_etichetta').replace(/^giorni/i, 'giorno') : snT('serie_etichetta')) + '</small>' + (se.gettoni ? '<i title="Gettoni">🛡️×' + se.gettoni + '</i>' : '') + '</div></div>'
    + '<div class="sn-linea"><i style="width:' + (disp.length ? Math.round(fatte / disp.length * 100) : 0) + '%"></i></div>'
    + riga(1, 'q', snT('tappa_domande'), q1, b1)
    + riga(2, 'm', snT('tappa_mossa'), q2, b2)
    + riga(3, 'x', snT('tappa_missione'), q3, b3)
    + fondo
    + '</div>';
}
function snPaint(){ try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ } }

/* ---------- il tassello della stagione 2 e del check: la mappa degli ostacoli ---------- */
function snTasselloHtml(n){
  const nome = (typeof gnNome === 'function') ? gnNome() : '';
  let ost = []; try{ ost = dqOstacoli().slice(0, 3); }catch(_){ }
  const pesi = (function(){ try{ return dqStato().pesi || {}; }catch(_){ return {}; } })();
  const max = Math.max(1, ost.length ? Math.abs(pesi[ost[0].k] || 1) : 1);
  const barre = ost.map(function(o, i){ const v = Math.max(8, Math.round(Math.abs(pesi[o.k] || 0) / max * 100)); return '<div class="sn-ost"><span>' + snEsc(o.t) + '</span><div><i style="width:' + v + '%"></i></div></div>'; }).join('');
  const check = String(n).indexOf('ck') === 0;
  const kicker = check ? 'Il check' : 'Stagione 2 · Giorno ' + (n - 7);
  const titolo = check ? 'Cosa ti tiene fermo, questa settimana' : 'La tua mappa degli ostacoli, oggi';
  const frase = check ? 'Ogni settimana la misuro di nuovo. Quello che si abbassa, si abbassa perché lo stai facendo tu.' : 'Le risposte di oggi hanno spostato i pesi. Quello in cima è quello su cui lavoriamo per primo.';
  return '<div class="dq-tass"><small>' + snEsc(kicker) + '</small><b class="dq-t">' + snEsc(titolo) + '</b>' + barre + '<p class="dq-p">' + snEsc(frase) + '</p>'
    + '<button type="button" class="or-a main" onclick="event.stopPropagation();dqChiudi()">' + (nome ? 'Grazie, Genio' : 'Ho capito') + '</button></div>';
}

/* ---------- lo stile ---------- */
(function(){
  const css = [
    '.sn-card{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:16px;display:flex;flex-direction:column;gap:10px}body.dark .sn-card{background:#12203A;border-color:#22345A}',
    '.sn-top{display:flex;align-items:center;justify-content:space-between;gap:10px}.sn-top small{display:block;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.sn-top b{display:block;font:800 18px var(--font-display);color:var(--navy)}body.dark .sn-top b{color:#fff}',
    '.sn-serie{display:flex;align-items:center;gap:5px;padding:6px 10px;border-radius:99px;background:var(--bg,#F4F9FF);color:var(--muted);font:700 12px var(--font-body)}.sn-serie.on{background:#FFF1D6;color:#A86A00}body.dark .sn-serie{background:rgba(255,255,255,.06)}body.dark .sn-serie.on{background:rgba(140,198,255,.16);color:#8CC6FF}',
    '.sn-serie span{font-size:15px}.sn-serie b{font:800 16px var(--font-display)}.sn-serie i{font-style:normal;margin-left:4px;font-size:11px}',
    '.sn-linea{height:8px;border-radius:4px;background:var(--blue-soft,#E3F1FF);overflow:hidden}.sn-linea i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#3F9FF4,#0075E3);transition:width .5s}body.dark .sn-linea{background:rgba(255,255,255,.1)}',
    '.sn-tappa{display:flex;gap:12px;padding:10px 0;border-top:1px solid var(--line)}body.dark .sn-tappa{border-color:#22345A}',
    '.sn-cerchio{width:34px;height:34px;flex:none;border-radius:50%;border:2px solid #0075E3;color:#0075E3;display:flex;align-items:center;justify-content:center;font:800 14px var(--font-display);background:transparent}',
    '.sn-tappa.fatta .sn-cerchio{background:#1B9E6A;border-color:#1B9E6A;color:#fff}.sn-tappa.niente .sn-cerchio{border-color:var(--line);color:var(--muted)}',
    '.sn-corpo{flex:1;min-width:0}.sn-corpo small{display:block;font:700 12.5px var(--font-body);color:var(--navy)}body.dark .sn-corpo small{color:#fff}',
    '.sn-corpo p{margin:3px 0 0;font:500 13px/1.45 var(--font-body);color:var(--muted)}.sn-tappa.fatta .sn-corpo p{color:#1B9E6A}body.dark .sn-tappa.fatta .sn-corpo p{color:#8CF0C8}',
    '.sn-mis{display:block;font:700 14px/1.35 var(--font-body);color:var(--navy)}body.dark .sn-mis{color:#fff}.sn-mis-s{display:block;margin-top:2px}',
    '.sn-btns{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px}',
    '.sn-go{border:0;border-radius:99px;background:#0075E3;color:#fff;padding:9px 16px;font:700 13px var(--font-body);cursor:pointer;margin-top:8px}.sn-btns .sn-go{margin-top:0}',
    '.sn-go.sec{background:var(--blue-soft,#E3F1FF);color:#0075E3}body.dark .sn-go.sec{background:rgba(79,168,255,.16);color:#8CC6FF}',
    '.sn-link{border:0;background:none;color:var(--muted);font:600 12px var(--font-body);cursor:pointer;padding:6px 0}',
    '.sn-nota{margin:0;padding:10px 12px;border-radius:14px;background:var(--bg,#F4F9FF);font:500 13px/1.45 var(--font-body);color:var(--navy)}body.dark .sn-nota{background:rgba(255,255,255,.06);color:#EEF4FF}.sn-nota b{color:#0075E3}body.dark .sn-nota b{color:#8CC6FF}',
    '.sn-scrigno{display:flex;align-items:center;gap:12px;padding:12px;border-radius:18px;background:linear-gradient(135deg,#FFF1D6,#FFE1A8);cursor:pointer;color:#5A3D00}.sn-scrigno-ico{font-size:34px;animation:snScuoti 1.6s ease-in-out infinite}.sn-scrigno div{flex:1;min-width:0}.sn-scrigno small{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase}.sn-scrigno b{display:block;font:600 13px/1.4 var(--font-body)}.sn-scrigno .sn-go{margin:0;background:#A86A00}',
    '@keyframes snScuoti{0%,100%{transform:rotate(0)}10%{transform:rotate(-8deg)}20%{transform:rotate(8deg)}30%{transform:rotate(-5deg)}40%{transform:rotate(0)}}',
    '.sn-premio{display:flex;align-items:center;gap:12px;padding:12px;border-radius:18px;background:var(--bg,#F4F9FF)}body.dark .sn-premio{background:rgba(255,255,255,.06)}.sn-premio span{font-size:30px}.sn-premio small{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}.sn-premio b{display:block;font:600 13px/1.4 var(--font-body);color:var(--navy)}body.dark .sn-premio b{color:#EEF4FF}',
    '.sn-ost{margin-top:8px;text-align:left}.sn-ost span{display:block;font:700 12px var(--font-body);color:#0E2350}body.dark .sn-ost span{color:#EEF4FF}.sn-ost div{height:8px;border-radius:4px;background:#E3F1FF;overflow:hidden;margin-top:3px}body.dark .sn-ost div{background:rgba(255,255,255,.14)}.sn-ost i{display:block;height:100%;background:linear-gradient(90deg,#E5515F,#FF8A5B);border-radius:4px}',
    /* la festa: sopra a tutto, per un attimo */
    '.sn-festa{position:absolute;inset:0;z-index:70;display:flex;align-items:center;justify-content:center;pointer-events:none}.sn-festa[hidden]{display:none}',
    '.sn-festa-in{display:flex;flex-direction:column;align-items:center;gap:4px;padding:16px 26px;border-radius:22px;background:rgba(14,35,80,.92);color:#fff;animation:snPop .5s cubic-bezier(.2,1.4,.4,1) both;box-shadow:0 12px 40px rgba(0,0,0,.35)}',
    '.sn-festa-in .sn-xp{font:900 34px/1 var(--font-display);color:#8CF0C8}.sn-festa-in span{font:600 14px/1.4 var(--font-body);text-align:center;max-width:250px}.sn-festa-in span b{font-weight:800;color:#8CC6FF}.sn-festa-in img{height:90px;margin-bottom:6px}',
    '.sn-festa.rara .sn-festa-in{background:linear-gradient(160deg,#0E2350,#1C3F8A);border:2px solid #8CC6FF}.sn-festa.rara .sn-xp{color:#FFD98A;font-size:40px}',
    '@keyframes snPop{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:scale(1)}}',
    '.sn-festa i{position:absolute;top:40%;left:50%;width:10px;height:10px;border-radius:2px;background:#FFD98A;animation:snCori 1.6s ease-out forwards}',
    '.sn-festa i:nth-child(2){background:#8CF0C8;--dx:-120px;--dy:-160px}.sn-festa i:nth-child(3){background:#3F9FF4;--dx:120px;--dy:-140px}.sn-festa i:nth-child(4){background:#E5515F;--dx:-70px;--dy:-200px}.sn-festa i:nth-child(5){background:#FFD98A;--dx:80px;--dy:-210px}.sn-festa i:nth-child(6){background:#3F9FF4;--dx:-150px;--dy:-60px}.sn-festa i:nth-child(7){background:#8CF0C8;--dx:150px;--dy:-70px}.sn-festa i:nth-child(8){background:#3F9FF4;--dx:-30px;--dy:-230px}.sn-festa i:nth-child(9){background:#E5515F;--dx:40px;--dy:-120px}',
    '@keyframes snCori{0%{transform:translate(0,0) rotate(0);opacity:1}100%{transform:translate(var(--dx,60px),calc(var(--dy,-160px) + 240px)) rotate(540deg);opacity:0}}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  document.addEventListener('DOMContentLoaded', function(){ snCarica(); setTimeout(function(){ try{ snTick(); }catch(_){ } }, 4000); });
  document.addEventListener('fl:piano', function(){ setTimeout(function(){ try{ snTick(); }catch(_){ } }, 200); });
})();
