/* LE ANTEPRIME DELLE SCHERMATE DI BLOCCO "CON I NUMERI" (0.9.298, rifatte nel 0.9.303).
   Le disegna Personalizza > Stile della schermata di blocco (settings.js, lsPreview); la schermata vera e' nel nativo
   (BlockOverlay.rottaCard, carburanteCard, contrattoCard, partitaCard). Stessa sequenza, stessi testi.

   0.9.303, Andrea: "l'anteprima Uscita di rotta e' un bordello: troppo testo, gerarchia sbagliata. Togli i voti per il
   vecchio te, 'se diventa abitudine' e '8 min su Instagram non sono 8 min'. Il badge della combo e quello del tempo
   sono troppi: sullo STESSO badge rosso prima la combo, poi il tempo; toccandolo si apre il dettaglio. Il carburante
   diventa uno stile suo. E due stili nuovi: Contratto e Partita". Una cosa per schermata (OEOF):
     - Uscita di rotta: la card dell'arrivo della scheda Sogno, con il badge e l'aereo sulla linea Oggi-Sogno;
     - Carburante: il tachimetro della riserva (lo stesso di dopamina.js) e quanto costa quella trappola;
     - Contratto: la frase del contratto di abitudine, il tentativo di oggi, la penitenza;
     - Partita: il punteggio vecchio te contro nuovo te e gli ultimi punti (solo con la regola dei tentativi accesa).
   Il prezzo dell'uscita di rotta e' quello della schermata vera: durata media di un'apertura + tempo per tornare
   concentrati + qualita' persa dopo il rientro (porte.js, etaCostoRientro), diviso per i minuti di lavoro di un giorno.
   La combo non moltiplica l'arrivo: abbassa la qualita' dopo il rientro, e da li' il prezzo sale. */
const FR_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const FR_X = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
function frEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function frDurata(min){
  min = Math.max(0, Math.round(min));
  if (min >= 1440){ const g = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60); return g + 'g' + (h ? ' ' + h + 'h' : ''); }
  if (min < 60) return min + ' min';
  const h = Math.floor(min / 60), m = min % 60; return h + 'h' + (m ? ' ' + m + 'min' : '');
}
function frVirgola(v){ return Math.abs(v - Math.round(v)) < 0.05 ? String(Math.round(v)) : String(Math.round(v * 10) / 10).replace('.', ','); }
function frDec(v){ return (Math.round(v * 10) / 10).toFixed(1).replace('.', ','); }
function frLivello(n){ return n <= 2 ? 1 : n <= 4 ? 2 : n <= 7 ? 3 : n <= 9 ? 4 : 5; }
function frPedaggi(){ try{ return JSON.parse(localStorage.getItem('fl_pedaggi') || 'null'); }catch(_){ return null; } }

/* 0.9.308: IL PREZZO DI UN'APERTURA, copia di RottaBivio.prezzo (il nativo, provato da RottaBivioTest).
   Il navigatore a giornata chiusa sposta l'arrivo di (1 - fatto / previsto) giorni col previsto di un giorno di lavoro,
   e al massimo di un giorno: X minuti di lavoro persi valgono X / (minuti del piano di un giorno di lavoro) giorni.
   Fuori dalle ore del piano non si perde lavoro: contano i minuti nell'app, sulla prossima giornata di lavoro; se le ore
   del piano cominciano prima che finisca la coda dell'apertura, conta il lavoro perso dentro, se e' di piu'. */
const FR_FINESTRA = 15;
function frPrezzo(inOrario, minAlla, sess, lag, resEff, piano, gia){
  const p = { inOrario: !!inOrario, minAlla: minAlla, piano: Math.max(15, Math.round(piano || 0)), vicina: false };
  p.pieno = Math.round(sess + lag + FR_FINESTRA * (1 - Math.max(0.5, Math.min(1, resEff))));
  if (p.inOrario) p.costo = p.pieno;
  else {
    const dentro = minAlla >= 0 ? p.pieno - minAlla : 0;
    p.vicina = dentro > sess;
    p.costo = Math.max(Math.max(1, sess), dentro);
  }
  p.frazione = p.costo / p.piano;
  p.gia = Math.max(0, +gia || 0);
  const resta = Math.max(0, 1 - p.gia);
  p.tetto = p.frazione > resta + 1e-9;
  p.giorni = Math.min(p.frazione, resta);
  p.spostaMs = Math.round(p.giorni * 86400000);
  return p;
}
/** Minuti all'inizio delle prossime ore del piano: 0 dentro, -1 se non ce ne sono (giorni[] come Date.getDay()). */
function frMinAllaFinestra(giorni, da, a, t){
  if (!Array.isArray(giorni) || giorni.length !== 7) return -1;
  const ora = new Date(t || Date.now());
  const h = ora.getHours() + ora.getMinutes() / 60;
  for (let d = 0; d <= 8; d++){
    const c = new Date(ora.getTime()); c.setDate(c.getDate() + d);
    if (!giorni[c.getDay()]) continue;
    if (d === 0){ if (h >= da && h < a) return 0; if (h >= a) continue; }
    c.setHours(da, 0, 0, 0);
    return Math.max(0, Math.round((c.getTime() - ora.getTime()) / 60000));
  }
  return -1;
}
/** Il giorno su cui va il prezzo (come etaKey): oggi, o quello delle prossime ore del piano. */
function frGiornoDelPrezzo(p, adesso){
  const t = (adesso || Date.now()) + (!p || p.inOrario || p.minAlla < 0 ? 0 : p.minAlla * 60000);
  return (typeof etaKey === 'function') ? etaKey(t) : new Date(t).toISOString().slice(0, 10);
}

/** I numeri dell'uscita di rotta per un'app e la n-esima apertura di oggi (n = 5 nell'anteprima). */
function frCalcola(pkg, n){
  const ped = frPedaggi();
  const star = (ped && ped['*']) || {}, mio = (ped && pkg && ped[pkg]) || {};
  let arrivo = +star.arrivo || 0, pct = isFinite(star.pct) ? +star.pct : 0;
  try{ const a = (typeof etaArrivo === 'function') ? etaArrivo() : null; if (a && a.at){ arrivo = a.at; if (isFinite(a.pct)) pct = a.pct; } }catch(_){ }
  try{ if (typeof hdPercorso === 'function'){ const h = hdPercorso(); if (h && isFinite(h.pct)) pct = h.pct; } }catch(_){ }
  /* i minuti del piano in un giorno di lavoro (quelli del navigatore), come pianoG del nativo */
  let piano = 0, giorni = Array.isArray(star.giorni) && star.giorni.length === 7 ? star.giorni : null;
  try{ if (typeof etaPiano === 'function'){ const p = etaPiano(); if (p && p.nGiorni) piano = p.oreSettimana * 60 / p.nGiorni; if (!giorni && Array.isArray(p.giorni)) giorni = p.giorni; } }catch(_){ }
  if (!piano) piano = +star.pianoG || +star.piano || 120;
  piano = Math.max(15, Math.round(piano));
  if (!giorni) giorni = [1, 1, 1, 1, 1, 1, 1];
  let da = isFinite(star.da) ? +star.da : 8, aOra = isFinite(star.a) ? +star.a : 22;
  try{ if (typeof ETA_CFG !== 'undefined' && ETA_CFG.finestraGiorno){ da = ETA_CFG.finestraGiorno.da; aOra = ETA_CFG.finestraGiorno.a; } }catch(_){ }
  const sess = Math.max(1, +mio.s || 8), lag = Math.max(1, +star.lag || 10), res = Math.max(0.5, Math.min(1, +star.res || 0.7));
  /* dentro alle ore del piano = la prossima finestra e' adesso: la stessa regola di etaCostoRientroOrario e del nativo */
  const minAlla = frMinAllaFinestra(giorni, da, aOra);
  const inOrario = minAlla === 0;
  const livello = frLivello(n);
  const resEff = Math.max(0.5, res - 0.03 * (n - 1));
  const p0 = frPrezzo(inOrario, minAlla, sess, lag, resEff, piano, 0);
  const giorno = frGiornoDelPrezzo(p0);
  let gia = 0; try{ gia = ((typeof etaRottaGiorni === 'function') ? etaRottaGiorni() : {})[giorno] || 0; }catch(_){ }
  const pr = frPrezzo(inOrario, minAlla, sess, lag, resEff, piano, gia);
  const resta = Math.max(0, arrivo - Date.now());
  const muove = pr.spostaMs > 0;
  const pct1 = muove ? Math.max(0, pct - Math.max(0.012, resta ? pr.spostaMs / resta * (1 - pct) : 0.012)) : pct;
  let boll = null; try{ boll = (typeof etaBollino === 'function') ? etaBollino() : null; }catch(_){ }
  return { arrivo: arrivo, pct: pct, pct1: pct1, piano: piano, sess: sess, lag: lag, costo: pr.costo, spostaMs: pr.spostaMs, inOrario: inOrario,
           vicina: pr.vicina, minAlla: minAlla, giorno: giorno, p: pr, n: n, livello: livello, mis: !!star.mis, boll: boll };
}

/* ---------------------------------------------------------------------------------------
   1. USCITA DI ROTTA
   --------------------------------------------------------------------------------------- */
let FR_ULTIMO = null;   // i numeri dell'ultima anteprima disegnata: li legge il popover del badge
/* 0.9.307, Andrea: "l'anteprima deve essere IDENTICA alla schermata vera". Prima era una card bassa e quadrata, senza la
   copertina, coi caratteri dell'app e il pulsante stretto. Ora e' la copia di BlockOverlay.rottaCard, pezzo per pezzo:
   titolo 26, riga 15, card che si prende tutta l'altezza che resta (peso 1), copertina scelta nella scheda Sogno
   (ptCopertina, la stessa che porte.js manda al telefono) con lo stesso velo, ARRIVO PREVISTO 12, giorno 40 e anno 30,
   badge, linea Oggi-Sogno con l'aereo, "41% del percorso" tutto in grassetto, pulsante largo quanto lo schermo o il bivio.
   Il carattere e' quello di sistema, come le TextView del nativo. Le misure sono in dp moltiplicate per --u: a schermo
   intero --u vale 1px, nella card del carosello e' la stessa schermata rimpicciolita. Anche i tempi sono quelli del
   nativo: card a 450 ms, badge a 1200, aereo da tTempo per 1400 ms, pulsante a rottaFineMs. */
function frCopertinaFondo(){
  let k = 'asset:img/dream-night.jpg', d = '';
  try{ if (typeof ptCopertina === 'function'){ const c = ptCopertina() || {}; k = c.k || k; d = c.d || ''; } }catch(_){ }
  /* va dentro a style="...": apici singoli nell'url, e niente virgolette o apici dal valore */
  const pulito = function(v){ return String(v).replace(/["'\\<>]/g, ''); };
  if (k === 'file') return d ? "url('" + pulito(d) + "')" : "url('img/dream-night.jpg')";
  if (k.indexOf('grad:') === 0){ const p = k.slice(5).split(','); return 'linear-gradient(135deg,' + pulito(p[0].trim()) + ',' + pulito((p[1] || p[0]).trim()) + ')'; }
  return "url('" + pulito(k.replace(/^asset:/, '')) + "')";
}
function frAnteprimaHtml(){
  const app = 'Instagram', x = frCalcola('com.instagram.android', 5);
  FR_ULTIMO = Object.assign({ app: app }, x);
  const d0 = new Date(x.arrivo || Date.now() + 400 * 86400000), d1 = new Date(d0.getTime() + x.spostaMs);
  /* "17 Luglio": il mese come lo scrive il telefono sulla schermata vera */
  const mese = function(d){ const m = FR_MESI[d.getMonth()]; return m.charAt(0).toUpperCase() + m.slice(1); };
  const data = function(d){ return '<b>' + d.getDate() + ' ' + mese(d) + '</b><span>' + d.getFullYear() + '</span>'; };
  const f0 = Math.max(0, Math.min(1, x.pct)), f1 = Math.max(0, Math.min(1, x.pct1));
  const perc = function(v){ return (typeof mpPercTxt === 'function') ? mpPercTxt(v) : String(Math.round(v * 100)); };
  const combo = x.inOrario && x.livello >= 2;
  /* 0.9.308: il prezzo c'e' sempre (fuori dalle ore del piano va sulla prossima giornata di lavoro): niente piu' "La rotta
     non cambia". Sopra al prezzo il bollino di Dream, stesso testo e colore della scheda Sogno (eta.js, etaBollino). */
  const muove = x.spostaMs > 0;
  const b = x.boll;
  /* 0.9.321: un badge solo. Prima lo spostamento rispetto a ieri (se c'e'), poi il prezzo di questa apertura */
  const ieri = (b && b.txt && b.giorni) ? b.txt : '';
  const sotto = x.inOrario ? 'Se la apri adesso, il tuo arrivo si sposta.'
    : x.vicina ? 'Le ore del piano cominciano fra ' + frDurata(x.minAlla) + ': se la apri adesso, il tuo arrivo si sposta.'
    : 'Sei fuori dalle ore del piano, ma aprirla adesso pesa sulla prossima giornata di lavoro.';
  /* i tempi del nativo: tBadge = 1200, tTempo = tBadge + 1900 con la combo (+200 senza), fine = tTempo + 1550 */
  const tTempo = (combo || (b && b.txt && b.giorni)) ? 3100 : 1400, tFine = tTempo + 1550;
  const tempo = muove ? '+' + frDurata(Math.max(1, Math.round(x.spostaMs / 60000))) + ' se la apri adesso' : 'Oggi l’arrivo ha già perso un giorno';
  const info = '<i class="fr-i" aria-hidden="true">i</i>';
  return '<div class="prev rotta fr' + (muove ? ' in' : '') + '" style="--tt:' + tTempo + 'ms;--tf:' + tFine + 'ms;--tc:' + (tTempo - 200) + 'ms">'
    /* 0.9.308: la (i) accanto al titolo apre il motivo del blocco (BlockOverlay.motivoRighe) */
    + '<h4 class="fr-tit">' + app + ' è fuori rotta<button type="button" class="fr-ti" onclick="event.stopPropagation();frMotivoApri(\'' + app + '\')" aria-label="Perché ' + app + ' è bloccata">i</button></h4>'
    + '<p class="fr-sotto">' + frUnito(sotto) + '</p>'
    + '<div class="fr-arr" style="--f0:' + f0 + ';--f1:' + f1 + '">'
    +   '<i class="fr-cop" style="background-image:' + frCopertinaFondo() + '"></i><i class="fr-ombra"></i>'
    +   '<div class="fr-cin">'
    +     '<small class="fr-arr-eti">ARRIVO PREVISTO</small>'
    +     '<div class="fr-data"><div class="a">' + data(d0) + '</div>' + (muove ? '<div class="b">' + data(d1) + '</div>' : '') + '</div>'
    /* il prospetto: uno solo. Prima la combo, poi il tempo; si tocca per il dettaglio */
    +     '<button type="button" class="fr-bol' + (ieri || combo ? ' combo' : '') + '" onclick="event.stopPropagation();frComboApri()" aria-label="Perché il tuo arrivo si sposta">'
    +       (ieri ? '<span class="a">' + frEsc(ieri) + info + '</span>' : combo ? '<span class="a">Combo ×' + x.livello + ' (' + x.n + 'ª apertura di oggi)' + info + '</span>' : '')
    +       '<span class="b">' + frUnito(tempo) + info + '</span></button>'
    +     '<div class="fr-rotta"><span>Oggi</span><div class="fr-linea"><i></i><em>' + ((typeof NV_AEREO !== 'undefined') ? NV_AEREO : '✈') + '</em></div><span>Sogno</span></div>'
    +     '<p class="fr-perc"><span class="a">' + perc(x.pct) + '% del percorso</span>' + (muove ? '<span class="b">' + perc(x.pct1) + '% del percorso</span>' : '') + '</p>'
    +   '</div>'
    + '</div>'
    /* 0.9.305: il bivio sotto alla card (BlockOverlay.bivioRotta); 0.9.308: sempre, anche fuori dalle ore del piano */
    + frBivioHtml(app, x) + '</div>';
}
/* 0.9.305, Andrea: "la schermata resta li' senza un pulsante per chiuderla: sotto alla card voglio un bivio". Nell'anteprima
   i due pannelli si vedono e basta; sulla schermata vera si toccano (una volta al giorno per app, RottaBivio.java). */
function frBivioHtml(app, x){
  const prezzo = frUnito(frDurata(Math.max(1, Math.round(x.spostaMs / 60000))));
  return '<div class="fr-bivio">'
    + '<span class="fr-bv blu"><i aria-hidden="true">🛡️</i><b>Blinda il nuovo te</b><small>Il blocco di ' + frEsc(app) + ' raddoppia e parli con il Genio.</small></span>'
    + '<span class="fr-bv rosso"><i aria-hidden="true">🔓</i><b>Apri comunque</b><small>Il tuo arrivo slitta di ' + prezzo + '.</small></span>'
    + '</div>';
}

/* IL POPOVER DEL BADGE (come la schermata vera, BlockOverlay.apriPerche).
   0.9.304, Andrea: "chi cazzo ci legge tutta quella pappardella". Come il foglio della stagione di spinta (stagione.js):
   il titolo, una frase, poi 3 righe (4 con la combo), ognuna con l'emoji in una bolla bianca e una frase corta.
   I numeri sono quelli dell'anteprima (frCalcola): durata media dell'apertura, tempo per tornare concentrati, costo, arrivo. */
function frComboApri(){
  const x = FR_ULTIMO || Object.assign({ app: 'Instagram' }, frCalcola('com.instagram.android', 5));
  const ore = frDurata(x.spostaMs / 60000), prezzo = '+' + ore;
  const riga = function(emoji, frase){ return '<li><i aria-hidden="true">' + emoji + '</i><span>' + frase + '</span></li>'; };
  const lead = (x.inOrario || x.vicina) ? 'Ogni apertura costa più del tempo che passi nell’app.' : 'Anche fuori dalle ore del piano un’apertura ha un prezzo.';
  let h = '<h3>' + (x.livello >= 2 && x.inOrario ? 'Combo ×' + x.livello + ', ' + prezzo + ' sul tuo arrivo' : prezzo + ' sul tuo arrivo') + '</h3>'
    + '<p class="fr-lead">' + lead + '</p><ul class="fr-righe">';
  frRighe(x).forEach(function(r){ h += riga(r[0], r[1]); });
  h += '</ul><button type="button" class="fr-piu" aria-expanded="false" onclick="frStudiApri(this)">Scopri di più<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>'
    + '<ul class="fr-righe fr-studi" id="frStudi" hidden>';
  frStudi(x).forEach(function(r){ h += riga(r[0], r[1]); });
  frFoglio(frUnito(h) + '</ul><button type="button" class="fr-ok" onclick="frFoglioChiudi()">Ho capito</button>');
}
/* «2h 43min» e «8 min» non si spezzano a fine riga (come RottaBivio.unito) */
function frUnito(s){ return String(s).replace(/(\d)h (\d)/g, '$1h\u00A0$2').replace(/(\d) min/g, '$1\u00A0min'); }
/* 0.9.308, Andrea: "24 min sono il 16% di 2h 30min, e il 16% di un giorno sono 3h 50min: e' forzato". Il conto lo rifa' un
   bambino: quanti minuti perdi, la strada di un giorno (le ore le hai scelte tu), che pezzo di quella strada sono ("circa
   un sesto") e di quanto arrivi dopo ("un sesto di giorno, cioe' 3h 50min"). Stessi testi di RottaBivio.righe/conto. */
const FR_FRAZ = [[1 / 2, 'metà'], [1 / 3, 'un terzo'], [2 / 3, 'due terzi'], [1 / 4, 'un quarto'], [3 / 4, 'tre quarti'], [1 / 5, 'un quinto'], [2 / 5, 'due quinti'], [3 / 5, 'tre quinti'], [4 / 5, 'quattro quinti'], [1 / 6, 'un sesto'], [5 / 6, 'cinque sesti'], [1 / 8, 'un ottavo'], [1 / 10, 'un decimo'], [1 / 12, 'un dodicesimo']];
function frFrazione(f){
  let best = null, err = 1;
  FR_FRAZ.forEach(function(q){ const e = Math.abs(f - q[0]) / q[0]; if (e < err){ err = e; best = q; } });
  if (!best || err > 0.08) return null;
  return [best[1], err <= 0.01 ? '' : 'circa '];
}
function frConto(p){
  const c = frDurata(p.costo) + ((p.costo === 1 || p.costo === 60 || p.costo === 1440) ? ' è' : ' sono');
  const quanto = frDurata(Math.max(1, Math.round(p.spostaMs / 60000)));
  if (p.tetto && p.giorni <= 0) return 'Oggi il tuo arrivo si è già spostato di un giorno intero, il massimo per una giornata: questa apertura non lo sposta oltre.';
  if (p.frazione >= 1) return c + ' tutta la strada di un giorno' + (p.frazione > 1.005 ? ', e anche di più' : '') + '. Una giornata sposta l’arrivo al massimo di un giorno: arrivi ' + quanto + ' più tardi.';
  let pezzo, giorno;
  const fr = frFrazione(p.frazione);
  if (fr){ pezzo = fr[1] + fr[0]; giorno = fr[0] === 'metà' ? fr[1] + 'mezza giornata' : fr[1] + fr[0] + ' di giorno'; }
  else { const pc = frPerc(p.frazione); pezzo = frArt(pc) + pc; giorno = frArt(pc) + pc + ' di un giorno'; }
  if (p.tetto) return c + ' ' + pezzo + ' di quella strada, ma una giornata sposta l’arrivo al massimo di un giorno, e ne mancavano ' + quanto + ': arrivi ' + quanto + ' più tardi.';
  return c + ' ' + pezzo + ' di quella strada: arrivi ' + giorno + ' più tardi, cioè ' + quanto + '.';
}
function frRighe(x){
  const app = frEsc(x.app || 'questa app');
  const p = x.p || frPrezzo(x.inOrario !== false, x.minAlla || 0, x.sess, x.lag, 0.7, x.piano, 0);
  const dopo = Math.max(0, p.pieno - x.sess - x.lag);
  /* 0.9.310, Andrea: "il massimo sono tre righe". Stessi testi di RottaBivio.righe. */
  const coda = frDurata(x.sess) + ' su ' + app + ' + ' + frDurata(x.lag) + ' per tornare concentrato'
    + (dopo > 0 ? ' + ' + frDurata(dopo) + ' con la testa ancora lì' : '');
  const r = [];
  if (p.inOrario) r.push(['📱', coda + ' = ' + frDurata(p.costo) + ' di lavoro perso' + (x.livello >= 2 ? ' (è la ' + x.n + 'ª app fuori rotta di oggi).' : '.')]);
  else if (p.vicina) r.push(['⏰', 'Le ore del piano cominciano fra ' + frDurata(p.minAlla) + ': di questa apertura, ' + frDurata(p.costo) + ' finiscono nel tempo di lavoro.']);
  else r.push(['🌙', 'Adesso non perdi lavoro, ma ' + frDurata(p.costo) + ' su ' + app + ' li togli al riposo.']);
  r.push(['📅', 'Il tuo piano è ' + frDurata(p.piano) + ' al giorno, la strada di un giorno di lavoro. ' + frConto(p)]);
  const oggi = p.inOrario || (p.vicina && p.minAlla < 1440);
  r.push(['⏩', (oggi ? 'Se oggi lavori al sogno ' : 'Se nella prossima giornata di lavoro fai ') + frDurata(p.costo) + ' in più del piano, la data torna dov’era.']);
  return r;
}
/* «16%», «11,3%»: un decimale solo quando serve, cosi' chi rifa' il conto (11,3% di 24 ore) trova lo stesso numero. */
function frPerc(f){ const v = Math.round(f * 1000) / 10; return (Math.abs(v - Math.round(v)) < 0.05 ? String(Math.round(v)) : String(v).replace('.', ',')) + '%'; }
/* "l'11%", "l'8%", "l'1%" ma "il 16%": l'articolo segue il suono del numero (RottaBivio.art). */
function frArt(pc){ return /^(8|11|1[,%])/.test(pc) ? 'l’' : 'il '; }
/* Gli studi dietro ai numeri, sotto "Scopri di piu'" (come il respiro, 0.9.306). Fuori orario anche quello della sera. */
function frStudi(x){
  const r = [];
  if (x && x.inOrario === false && !x.vicina) r.push(['😴', 'Chi usa uno schermo la sera si addormenta più tardi ed è meno sveglio la mattina dopo: lo ha misurato Anne-Marie Chang ad Harvard nel 2015.']);
  r.push(['📚', 'Dopo un’interruzione servono in media 23 minuti per tornare concentrati: lo ha misurato Gloria Mark all’Università della California. '
      + (x.mis ? 'DreamMap usa il tuo tempo, misurato nelle tue sessioni: ' + frDurata(x.lag) + '.' : 'DreamMap usa una stima più prudente: ' + frDurata(x.lag) + '.')]);
  r.push(['🧠', 'Sophie Leroy lo chiama residuo di attenzione: dopo un cambio, una parte della testa resta sulla cosa di prima e lavori peggio. Per questo contano anche i 15 minuti dopo.']);
  return r;
}
/* 0.9.308: il motivo del blocco (la (i) accanto al titolo). Nell'anteprima: il programma vero che blocca l'app, se c'e'. */
function frMotivoApri(app){
  const nome = app || 'Instagram', pkg = 'com.instagram.android';
  let prog = null;
  try{ if (typeof PROGRAMS !== 'undefined') prog = PROGRAMS.filter(function(p){ return p && p.on !== false && (p.apps || []).indexOf(pkg) >= 0; })[0] || null; }catch(_){ }
  const riga = function(emoji, frase){ return '<li><i aria-hidden="true">' + emoji + '</i><span>' + frase + '</span></li>'; };
  let righe = prog
    ? riga('🛡️', 'L’ha bloccata il programma "' + frEsc(prog.name || 'senza nome') + '".') + (prog.allDay ? riga('🕒', 'È in vigore tutto il giorno.') : (prog.from && prog.to ? riga('🕒', 'È in vigore dalle ' + frEsc(prog.from) + ' alle ' + frEsc(prog.to) + '.') : ''))
    : riga('🛡️', 'Qui vedi il programma che ha bloccato l’app.') + riga('🕒', 'E quando è in vigore, oppure la parola chiave o il sito che l’ha fatto scattare.');
  frFoglio('<h3>Perché ' + frEsc(nome) + ' è bloccata</h3><p class="fr-lead">È la regola che hai scelto tu.</p><ul class="fr-righe">' + righe + '</ul>'
    + '<p class="fr-lead fr-nota">Se non vuoi vederlo, spegni Motivo del blocco nelle Preferenze della schermata di blocco del programma.</p>'
    + '<button type="button" class="fr-ok" onclick="frFoglioChiudi()">Ho capito</button>');
}
function frStudiApri(b){
  const box = document.getElementById('frStudi'); if (!box) return;
  const apri = box.hidden; box.hidden = !apri;
  if (b){ b.setAttribute('aria-expanded', apri ? 'true' : 'false'); b.classList.toggle('su', apri); }
  try{ flVibra(8); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   0.9.305: IL BIVIO DELLA SCHERMATA VERA, DENTRO DREAMMAP
   La schermata nativa apre DreamMap con l'extra "apri" = "rotta-blinda:{...}" o "rotta-apri:{...}" (assenze.js,
   flApriDaNotificaK, passa da qui). I numeri sono quelli della schermata: app, programma che la blocca, prezzo.
   --------------------------------------------------------------------------------------- */
function frApriDaBlocco(k){
  /* 0.9.400 BUG-169: anche "rotta-rettifica" (il programma scelto "Rettificabile anche in Modalità severa", dal bivio) */
  const m = /^rotta-(blinda|apri|rettifica):([\s\S]*)$/.exec(String(k || ''));
  if (!m) return false;
  let d = null; try{ d = JSON.parse(m[2]); }catch(_){ d = null; }
  if (!d || !d.pkg) return true;
  if (m[1] === 'blinda') frBlinda(d); else if (m[1] === 'rettifica') frRettifica(d); else frApriComunque(d);
  return true;
}
/* BLINDA IL NUOVO TE: il programma che blocca l'app si duplica ("Blindato: Instagram", la volta dopo i blocchi sono due) e
   si apre la chat del Genio di Rientra in rotta. La distrazione l'ha gia' chiusa il telefono (Home). */
async function frBlinda(d){
  const nome = d.nome || 'questa app';
  const cosa = String(d.parola || '').trim() || String(d.sito || '').trim() || nome;
  /* 0.9.308: ogni giorno la scelta vale un punto. Blinda = +1 al nuovo te (una volta al giorno per app) */
  frRottaPunto(d.pkg, nome, 'neo');
  let esito = false; try{ esito = await frBlindaProgramma(d); }catch(_){ esito = false; }
  try{
    if (typeof toast === 'function'){
      if (esito === true) toast('"Blindato: ' + cosa + '" è attivo: adesso i blocchi di ' + cosa + ' sono due.');
      else if (esito === 'gia') toast('"Blindato: ' + cosa + '" è già attivo: i blocchi di ' + cosa + ' restano due.');
      else if (esito === 'rifiutato') toast('Non riesco ad aggiungere "Blindato: ' + cosa + '", perché la Modalità severa non lo lascia cambiare adesso.');
    }
  }catch(_){ }
  try{ if (typeof rnApri === 'function') rnApri({ tipo: 'blocco', app: d.pkg, appNome: nome }); }catch(_){ }
}
/** Il programma duplicato: true se creato, 'gia' se c'era gia', false se i programmi non ci sono (anteprima nel browser). */
async function frBlindaProgramma(d){
  if (typeof PROGRAMS === 'undefined' || typeof saveProgramsLocal !== 'function') return false;
  /* prima si rilegge il motore: e' lui che decide quali programmi esistono (blocco.js, hydrateProgramsFromEngine) */
  try{ if (typeof hydrateProgramsFromEngine === 'function') await hydrateProgramsFromEngine(); }catch(_){ }
  /* 0.9.313: scattato per una parola chiave o per un sito si duplica quella regola, MAI l'app intera (il browser) */
  const parola = String(d.parola || '').trim(), sito = String(d.sito || '').trim(), termine = parola || sito;
  const nome = 'Blindato: ' + (termine || d.nome || d.pkg);
  const esiste = function(){ return PROGRAMS.some(function(p){ return p && p.name === nome && (termine || (p.apps || []).indexOf(d.pkg) >= 0); }); };
  if (esiste()) return 'gia';
  const kwTesto = function(k){ return String((k && k.t !== undefined) ? k.t : k).trim().toLowerCase(); };
  let orig = d.sid ? PROGRAMS.filter(function(p){ return p && p.id === d.sid; })[0] : null;
  if (!orig && parola) orig = PROGRAMS.filter(function(p){ return p && p.on !== false && (p.keywords || []).some(function(k){ return kwTesto(k) === parola.toLowerCase(); }); })[0] || null;
  if (!orig && sito) orig = PROGRAMS.filter(function(p){ return p && p.on !== false && (p.sites || []).indexOf(sito) >= 0; })[0] || null;
  if (!orig && !termine) orig = PROGRAMS.filter(function(p){ return p && p.on !== false && (p.apps || []).indexOf(d.pkg) >= 0; })[0] || null;
  let copia;
  if (orig) copia = JSON.parse(JSON.stringify(orig));
  else if (termine){
    /* la parola o il sito stavano nella lista di blocco o nel blocco rapido, che valgono sempre */
    copia = { type: 'ora', from: '00:00', to: '23:59', allDay: true, blockLaunch: true, blockNotifications: true };
  } else {
    /* bloccata da altro (blocco rapido, modalita' severa): il duplicato vale nelle ore del piano, quelle in cui aprire costa */
    const st = (frPedaggi() || {})['*'] || {};
    const hh = function(h){ h = Math.max(0, Math.min(23, Math.round(+h || 0))); return String(h).padStart(2, '0') + ':00'; };
    copia = { type: 'ora', from: hh(isFinite(st.da) ? st.da : 8), to: hh(isFinite(st.a) ? st.a : 22), allDay: false, blockLaunch: true, blockNotifications: true };
  }
  copia.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  delete copia.idx; delete copia.grazia; delete copia.activeNow;
  copia.on = true; copia.name = nome; copia.icon = '🛡️';
  /* 0.9.400 BUG-169: il blocco blindato raddoppia la protezione: non si rettifica, e il bivio lo tiene solo se l'aveva l'originale */
  copia.rettifica = false; copia.bivio = !!(orig && orig.bivio);
  copia.apps = termine ? [] : [d.pkg];
  copia.sites = (!parola && sito) ? [sito] : [];
  copia.keywords = [];
  if (parola){
    const trovata = ((orig && orig.keywords) || []).filter(function(k){ return kwTesto(k) === parola.toLowerCase(); })[0];
    copia.keywords = [trovata !== undefined ? trovata : parola];
    try{ if (typeof ubNormalizeKeywordList === 'function') copia.keywords = ubNormalizeKeywordList(copia.keywords); }catch(_){ }
  }
  copia.allow = [];
  if (!Array.isArray(copia.days) || copia.days.length !== 7) copia.days = [true, true, true, true, true, true, true];
  PROGRAMS.push(copia); saveProgramsLocal();
  try{ if (typeof pushRules === 'function') await pushRules(); }catch(_){ }
  try{ if (typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  /* 0.9.308: pushRules rilegge il motore; se il motore l'ha rifiutato (modalita' severa) il programma non c'e' piu' */
  if (!esiste()) return 'rifiutato';
  return true;
}
/* 0.9.308: IL PUNTO DEL BIVIO. Ogni giorno, per ogni app, la scelta vale un punto nella partita vecchio te contro nuovo te:
   Blinda il nuovo te = +1 al nuovo te, Apri comunque (confermato nella scena della farfalla) = +1 al vecchio te.
   Una volta sola al giorno per app (fl_rotta_punti), come il bivio (RottaBivio). */
const FR_PUNTI = 'fl_rotta_punti';
/* 0.9.400 BUG-169: non piu' un punto solo al giorno per app. Ogni entrata vale un punto al vecchio te (ogni volta e' una scelta);
   il nuovo te prende un punto per ogni volta che resta fuori, ma mai piu' di uno in piu' delle entrate di oggi in quell'app: tornare
   in rotta dopo essere entrati conta, toccare "Resto in rotta" dieci volte di fila per fare punti no. */
function frPuntiConti(v){
  if (v && typeof v === 'object') return { old: Math.max(0, +v.old || 0), neo: Math.max(0, +v.neo || 0) };
  if (v === 'old') return { old: 1, neo: 0 };
  if (v === 'neo') return { old: 0, neo: 1 };
  return { old: 0, neo: 0 };
}
function frPuntoAmmesso(conti, chi){ return chi === 'old' || conti.neo <= conti.old; }
function frRottaPunto(pkg, nome, chi){
  if (!pkg) return false;
  const oggi = (typeof etaOggiK === 'function') ? etaOggiK() : new Date().toISOString().slice(0, 10);
  let m = null; try{ m = JSON.parse(localStorage.getItem(FR_PUNTI) || 'null'); }catch(_){ m = null; }
  if (!m || m.k !== oggi) m = { k: oggi, p: {} };
  const conti = frPuntiConti(m.p[pkg]);
  if (!frPuntoAmmesso(conti, chi)) return false;
  conti[chi === 'neo' ? 'neo' : 'old']++;
  m.p[pkg] = conti;
  try{ localStorage.setItem(FR_PUNTI, JSON.stringify(m)); }catch(_){ }
  const motivo = chi === 'neo' ? 'Hai blindato il nuovo te su ' + nome : 'Fuori rotta: hai aperto ' + nome + ' comunque';
  try{ if (typeof mgLog === 'function') mgLog(chi, motivo, { punti: 1, rotta: pkg }); }catch(_){ }
  try{ if (chi === 'neo'){ if (typeof mtFocusPoint === 'function') mtFocusPoint(); } else if (typeof mtOldPoint === 'function') mtOldPoint(); }catch(_){ }
  try{ if (typeof frPartitaSpingi === 'function') frPartitaSpingi(); }catch(_){ }
  return true;
}
/** La scelta del bivio sul telefono (RottaBivio): '' = tolta, 'apri' = aperta e pagata. */
function frSceltaNativa(pkg, scelta){
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.rottaScelta) return NATIVE.rottaScelta({ pkg: pkg, scelta: scelta || '' }).catch(function(){ }); }catch(_){ }
  return Promise.resolve();
}
/* APRI COMUNQUE: la conferma e' la scena dell'effetto farfalla (farfalla.js). Solo tenendo premuto "Entro ..." il prezzo va
   sull'arrivo (eta.js, etaRottaPagata) e l'app si apre (NATIVE.rottaApriComunque).

   0.9.400 BUG-169, Andrea: "ho scelto di entrare comunque in Duolingo, dopo qualche minuto il blocco mi ha cacciato in mezzo alla
   lezione e mi ha lasciato solo Torno in rotta: ho perso la lezione e la lega". Prima della scena si sceglie PER QUANTO (5, 10, 15,
   30 minuti, o finche' esci dall'app, al massimo 45): per quel tempo il blocco non interrompe, e ogni durata ha il suo prezzo (lo
   stesso conto della schermata, con i minuti scelti). Finita la finestra la schermata di blocco ripresenta il bivio, a un prezzo
   piu' alto (RottaBivio.resEffDopo): mai un muro. */
let FR_DURATE = null;
/** Il prezzo dei minuti scelti: lo stesso conto della schermata (RottaBivio.prezzo, frPrezzo) con i minuti al posto della durata media. */
function frPrezzoPer(d, minuti){
  minuti = Math.max(1, Math.round(+minuti || 0));
  if (d && !d.generico && isFinite(+d.lag) && +d.piano > 0){
    const p = frPrezzo(!!d.inOrario, isFinite(+d.minAlla) ? +d.minAlla : 0, minuti, +d.lag, isFinite(+d.res) ? +d.res : 0.7, +d.piano, +d.gia || 0);
    p.giornoK = d.giorno || '';
    return p;
  }
  /* il bivio delle altre schermate di blocco: il prezzo sull'arrivo c'e' solo se DreamMap conosce l'arrivo (i pedaggi) */
  const ped = frPedaggi();
  if (!d || !ped || !ped['*'] || !(+ped['*'].arrivo > 0)) return null;
  let c = null; try{ c = frCalcola(d.pkg, 1); }catch(_){ c = null; }
  if (!c) return null;
  const res = Math.max(0.5, Math.min(1, +ped['*'].res || 0.7));
  const resEff = Math.max(0.5, res - 0.1 * Math.max(0, +d.entrate || 0));
  let gia = 0; try{ gia = ((typeof etaRottaGiorni === 'function') ? etaRottaGiorni() : {})[c.giorno] || 0; }catch(_){ gia = 0; }
  const p = frPrezzo(c.inOrario, c.minAlla, minuti, c.lag, resEff, c.piano, gia);
  p.giornoK = c.giorno;
  return p;
}
function frPrezzoMin(p){ return frUnito(frDurata(Math.max(1, Math.round(p.spostaMs / 60000)))); }
function frPrezzoRiga(p){
  if (!p) return '+1 punto al vecchio te.';
  if (!(p.spostaMs > 0)) return 'Oggi l’arrivo ha già perso un giorno, quindi non si sposta oltre.';
  return 'Il tuo arrivo slitta di ' + frPrezzoMin(p) + '.';
}
/** Le scelte del foglio "Per quanto tempo": le durate della schermata, poi "Finche' esco". */
function frDurateScelte(d){
  const durate = (Array.isArray(d.durate) && d.durate.length ? d.durate : [5, 10, 15, 30]).map(function(x){ return Math.max(5, Math.min(60, Math.round(+x || 0))); });
  const max = Math.max(5, Math.min(60, Math.round(+d.finoMax || 45)));
  const l = durate.map(function(m){ return { min: m, fino: false, p: frPrezzoPer(d, m) }; });
  /* "finche' esco" si paga per il massimo: e' il conto onesto di quanto puo' durare */
  l.push({ min: max, fino: true, p: frPrezzoPer(d, max) });
  return l;
}
function frDurateHtml(d){
  const nome = d.nome || 'questa app';
  const ico = ['⏱️', '⏳', '🕒', '🕧'];
  FR_DURATE = { d: d, scelte: frDurateScelte(d) };
  let html = '<h3>Per <span class="fr-blu">quanto tempo</span> entri in ' + frEsc(nome) + '?</h3>'
    + '<p class="fr-lead">Per quel tempo il blocco non ti interrompe.<br>Poi torna il bivio, e scegli di nuovo.</p><div class="fr-durate">';
  FR_DURATE.scelte.forEach(function(sc, i){
    const tit = sc.fino ? 'Finché esco da ' + nome : sc.min + ' minuti';
    const sotto = sc.fino ? 'Finisce quando esci, al massimo dopo ' + sc.min + ' minuti. ' + frPrezzoRiga(sc.p) : frPrezzoRiga(sc.p);
    html += '<button type="button" class="fr-dur" onclick="frDurataScelta(' + i + ')"><i>' + (sc.fino ? '🎓' : (ico[i] || '⏱️')) + '</i>'
      + '<span><b>' + frEsc(tit) + '</b><small>' + frEsc(frUnito(sotto)) + '</small></span></button>';
  });
  html += '</div>';
  /* "Rettificabile anche in Modalità severa", scelto prima: dal bivio si rivede il programma */
  if (d.rett) html += '<button type="button" class="fr-piu fr-rett" onclick="frDurataRettifica()">✏️ ' + (d.rett.rapido ? 'Togli ' + frEsc(nome) + ' dal Blocco rapido' : 'Rivedi i minuti del programma') + '</button>';
  return html;
}
function frDurataScelta(i){
  const x = FR_DURATE; if (!x || !x.scelte[i]) return;
  try{ flVibra(8); }catch(_){ }
  frFoglioChiudi();
  frScenaEntra(x.d, x.scelte[i]);
}
function frDurataRettifica(){
  const x = FR_DURATE; if (!x || !x.d || !x.d.rett) return;
  frFoglioChiudi();
  frRettifica(Object.assign({ pkg: x.d.pkg, nome: x.d.nome }, x.d.rett));
}
function frApriComunque(d){
  /* 0.9.308: il telefono ha segnato "apri" al tocco; vale solo se lo confermi nella scena. Fino ad allora il bivio e' aperto:
     chi sceglie "Resto in rotta" (o chiude la scena) non ha aperto niente, e la prossima volta rivede il bivio. */
  frSceltaNativa(d.pkg, '');
  frFoglio(frDurateHtml(d));
}
/** La scena della farfalla per la durata scelta: "Entro in Duolingo" o "Resto in rotta" (+1 punto al nuovo te). */
function frScenaEntra(d, sc){
  const nome = d.nome || 'questa app';
  const quanto = sc.fino ? 'finché esci (al massimo ' + sc.min + ' minuti)' : 'per ' + sc.min + ' minuti';
  const prezzo = sc.p && sc.p.spostaMs > 0 ? frPrezzoMin(sc.p) : '';
  if (typeof faScena !== 'function'){ frPagaEApri(d, sc); return; }
  let punto = false;
  faScena({
    kick: 'Effetto farfalla',
    titolo: prezzo ? 'Entrare in ' + nome + ' ' + quanto + ' sposta il tuo arrivo di ' + prezzo + '.' : 'Entrare in ' + nome + ' ' + quanto + ' dà un punto al vecchio te.',
    sotto: '',
    bivio: true,
    opzioni: [
      { k: 'resto', ico: '🛡️', n: 'Resto in rotta', s: '+1 punto al nuovo te.', colore: '#4FB8FF', tinta: 'blu' },
      { k: 'apro', ico: '🔓', n: 'Entro in ' + nome, s: prezzo ? 'Il tuo arrivo slitta di ' + prezzo + '.' : '+1 punto al vecchio te.', colore: '#FF5A66', tinta: 'rosso', cartello: prezzo ? '+' + prezzo : '+1 vecchio te' }
    ],
    senzaFarfalle: function(k){ return k === 'apro'; },
    onScelta: function(k){ if (k === 'apro') frPagaEApri(d, sc); else punto = frRottaPunto(d.pkg, nome, 'neo'); },
    dopoTitolo: function(){ return 'Sei rimasto in rotta'; },
    dopoSotto: function(){ return (punto ? '+1 punto al nuovo te. ' : '') + nome + ' resta chiusa e il tuo arrivo non cambia.'; },
    poi: function(k){ if (k === 'resto'){ try{ goId('s-home'); switchTab('rotta'); }catch(_){ } } }
  });
}
async function frPagaEApri(d, sc){
  const nome = d.nome || 'questa app';
  sc = sc || { min: Math.max(5, Math.round(+d.sess || 5)), fino: false, p: null };
  const N = (typeof NATIVE !== 'undefined' && NATIVE) ? NATIVE : null;
  /* 0.9.400 BUG-169: prima si chiede al telefono se il bivio e' ancora aperto (l'offerta della schermata di blocco, 15 minuti).
     Scaduto, non si paga niente e non si apre niente: si riapre l'app e si sceglie di nuovo. */
  if (N && N.rottaApriComunque){
    let prova = null; try{ prova = await N.rottaApriComunque({ pkg: d.pkg, prova: true }); }catch(_){ prova = null; }
    if (prova && prova.ok === false){ if (typeof toast === 'function') toast('Il bivio di ' + nome + ' è scaduto. Riapri ' + nome + ' e scegli di nuovo.'); return; }
  }
  /* il prezzo dei minuti scelti, sul giorno detto dalla schermata (fuori orario: la prossima giornata di lavoro) */
  const p = sc.p;
  const sposta = p ? p.spostaMs : (+d.sposta || 0), costo = p ? p.costo : (+d.costo || 0), giorno = (p && p.giornoK) || d.giorno || '';
  try{ if (sposta > 0 && typeof etaRottaPagata === 'function') etaRottaPagata(nome, sposta, costo, giorno); }catch(_){ }
  await frSceltaNativa(d.pkg, 'apri');
  frRottaPunto(d.pkg, nome, 'old');
  try{ if (typeof etaRidipingi === 'function') etaRidipingi(true); }catch(_){ }
  /* la stella della schermata nativa (arrivo, percentuale) si aggiorna subito: la prossima schermata dice la data nuova */
  try{ if (typeof ptRottaStella === 'function') await ptRottaStella(); }catch(_){ }
  try{
    if (N && N.rottaApriComunque){
      const r = await N.rottaApriComunque({ pkg: d.pkg, minuti: sc.min, finoAUscita: !!sc.fino });
      if (r && r.ok === false && typeof toast === 'function') toast('Non riesco ad aprire ' + nome + '. Aprila dalla schermata Home: per ' + (sc.fino ? 'questa volta' : sc.min + ' minuti') + ' il blocco non ti ferma.');
    }
  }catch(_){ if (typeof toast === 'function') toast('Non riesco ad aprire ' + nome + '. Aprila dalla schermata Home.'); }
}

/* ---------------------------------------------------------------------------------------
   0.9.400 BUG-169: RETTIFICABILE ANCHE IN MODALITÀ SEVERA. Andrea: "Gmail a 15 minuti al giorno è troppo poco, voglio poterlo
   correggere". Solo per il programma (o il Blocco rapido) che l'ha scelto PRIMA di accendere la Modalità severa: dal bivio si
   cambiano i minuti del limite (al giorno o all'ora); il motore lascia passare solo quello (FocusLockPlugin.weakensAnySchedule).
   Dal Blocco rapido, che non ha minuti, si toglie l'app.
   --------------------------------------------------------------------------------------- */
let FR_RETT = null;
const FR_RETT_GIORNO = [10, 15, 21, 30, 45, 60, 90];
const FR_RETT_ORA = [5, 10, 15, 20, 30];
async function frRettifica(d){
  const nome = d.nome || 'questa app';
  if (d.rapido){
    FR_RETT = { d: d, rapido: true };
    frFoglio('<h3>Togli ' + frEsc(nome) + ' dal <span class="fr-blu">Blocco rapido</span>?</h3>'
      + '<p class="fr-lead">Lo puoi fare anche con la Modalità severa accesa, perché l’hai scelto tu prima di accenderla.<br>I tuoi programmi restano come sono.</p>'
      + '<button type="button" class="fr-ok" onclick="frRettificaSalva()">Togli ' + frEsc(nome) + '</button>');
    return;
  }
  try{ if (typeof hydrateProgramsFromEngine === 'function') await hydrateProgramsFromEngine(); }catch(_){ }
  const lista = (typeof PROGRAMS !== 'undefined' && Array.isArray(PROGRAMS)) ? PROGRAMS : [];
  const p = lista.filter(function(x){ return x && x.id === d.sid; })[0];
  if (!p){ if (typeof toast === 'function') toast('Non trovo il programma "' + (d.prog || nome) + '".'); return; }
  const ora = !!(p.qh && !p.qd);
  FR_RETT = { d: d, id: p.id, nome: p.name || d.prog || nome, tipo: ora ? 'ora' : 'giorno', min: ora ? +p.qh : (+p.qd || 15), prima: { qd: +p.qd || 0, qh: +p.qh || 0 } };
  frFoglio(frRettificaHtml());
}
function frRettificaFrase(qd, qh){
  const b = [];
  if (qd > 0) b.push(qd + ' minuti al giorno');
  if (qh > 0) b.push(qh + ' minuti all’ora');
  return b.length ? b.join(' e ') : 'nessun limite';
}
function frRettificaHtml(){
  const x = FR_RETT; if (!x) return '';
  const lista = x.tipo === 'ora' ? FR_RETT_ORA : FR_RETT_GIORNO;
  const valori = lista.indexOf(x.min) < 0 ? lista.concat([x.min]).sort(function(a, b){ return a - b; }) : lista;
  return '<h3>Rivedi i <span class="fr-blu">minuti</span> di "' + frEsc(x.nome) + '"</h3>'
    + '<p class="fr-lead">Adesso:<br>' + frEsc(frRettificaFrase(x.prima.qd, x.prima.qh)) + '.</p>'
    + '<div class="fr-tipi">'
    + '<button type="button" class="fr-tipo' + (x.tipo === 'giorno' ? ' on' : '') + '" onclick="frRettificaTipo(\'giorno\')"><i>📅</i><b>Al giorno</b></button>'
    + '<button type="button" class="fr-tipo' + (x.tipo === 'ora' ? ' on' : '') + '" onclick="frRettificaTipo(\'ora\')"><i>⏰</i><b>All’ora</b></button></div>'
    + '<div class="fr-chips">' + valori.map(function(m){ return '<button type="button" class="fr-chip' + (m === x.min ? ' on' : '') + '" onclick="frRettificaMin(' + m + ')">' + m + ' min</button>'; }).join('') + '</div>'
    + '<p class="fr-nota">Lo puoi cambiare anche con la Modalità severa accesa, perché l’hai scelto tu prima di accenderla. Il resto del programma resta com’è.</p>'
    + '<button type="button" class="fr-ok" onclick="frRettificaSalva()">Salva: ' + x.min + ' minuti ' + (x.tipo === 'ora' ? 'all’ora' : 'al giorno') + '</button>';
}
function frRettificaTipo(t){
  const x = FR_RETT; if (!x || x.rapido) return;
  if (x.tipo !== t){ x.tipo = t; x.min = t === 'ora' ? 10 : 30; }
  const f = document.querySelector('#frFoglio .fr-sheet');
  if (f) f.innerHTML = '<button type="button" class="fr-x" onclick="frFoglioChiudi()" aria-label="Chiudi">' + FR_X + '</button>' + frRettificaHtml();
}
function frRettificaMin(m){
  const x = FR_RETT; if (!x || x.rapido) return;
  x.min = Math.max(1, Math.round(+m || 0));
  frRettificaTipo(x.tipo);
}
async function frRettificaSalva(){
  const x = FR_RETT; if (!x) return;
  const nome = (x.d && x.d.nome) || 'questa app';
  if (x.rapido){
    let ok = false;
    try{
      if (typeof loadQuick === 'function') await loadQuick();
      if (typeof QUICK !== 'undefined' && typeof blkNative === 'function'){
        const apps = (QUICK.apps || []).filter(function(a){ return a !== x.d.pkg; });
        const r = await blkNative('setQuickBlock', { enabled: QUICK.enabled, apps: apps, sites: QUICK.sites || [], keywords: QUICK.keywords || [], bivio: !!QUICK.bivio, rettifica: !!QUICK.rettifica }, true);
        if (r !== null){ QUICK.apps = apps; ok = true; }
      }
    }catch(_){ ok = false; }
    frFoglioChiudi();
    if (typeof toast === 'function') toast(ok ? nome + ' non è più nel Blocco rapido.' : 'Non riesco a togliere ' + nome + ' dal Blocco rapido adesso.');
    return;
  }
  const lista = (typeof PROGRAMS !== 'undefined' && Array.isArray(PROGRAMS)) ? PROGRAMS : null;
  const p = lista ? lista.filter(function(q){ return q && q.id === x.id; })[0] : null;
  if (!p || typeof pushRules !== 'function'){ frFoglioChiudi(); if (typeof toast === 'function') toast('Anteprima nel browser: il programma non cambia.'); return; }
  if (x.tipo === 'ora'){ p.qh = x.min; p.qd = null; } else { p.qd = x.min; p.qh = null; }
  try{ if (typeof saveProgramsLocal === 'function') saveProgramsLocal(); }catch(_){ }
  try{ await pushRules(); }catch(_){ }
  /* pushRules rilegge il motore: se l'ha rifiutato, il programma e' tornato com'era */
  const dopo = (typeof PROGRAMS !== 'undefined' ? PROGRAMS : []).filter(function(q){ return q && q.id === x.id; })[0];
  const fatto = !!dopo && (x.tipo === 'ora' ? +dopo.qh === x.min && !dopo.qd : +dopo.qd === x.min && !dopo.qh);
  try{ if (typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  frFoglioChiudi();
  if (typeof toast === 'function') toast(fatto ? '"' + x.nome + '" adesso è ' + frRettificaFrase(x.tipo === 'giorno' ? x.min : 0, x.tipo === 'ora' ? x.min : 0) + '.'
    : 'La Modalità severa non lascia cambiare "' + x.nome + '" adesso.');
}

/* ---------------------------------------------------------------------------------------
   0.9.400 BUG-169: I PUNTI SCELTI SULLA SCHERMATA DI BLOCCO. "Torno in rotta" e "Resto in rotta" non aprono DreamMap: il punto
   al nuovo te aspetta nel telefono (RottaBivio.puntoInAttesa) e si prende qui, quando DreamMap torna davanti.
   --------------------------------------------------------------------------------------- */
let FR_PUNTI_IN_CORSO = false;
async function frPuntiInAttesa(){
  const N = (typeof NATIVE !== 'undefined' && NATIVE) ? NATIVE : null;
  if (FR_PUNTI_IN_CORSO || !N || !N.rottaPuntiInAttesa) return 0;
  FR_PUNTI_IN_CORSO = true;
  let n = 0;
  try{
    const r = await N.rottaPuntiInAttesa({});
    const l = (r && Array.isArray(r.punti)) ? r.punti : [];
    const nomi = [];
    l.forEach(function(x){
      if (!x || !x.pkg) return;
      const chi = x.chi === 'old' ? 'old' : 'neo';
      if (frRottaPunto(x.pkg, x.nome || 'questa app', chi) && chi === 'neo'){ n++; if (nomi.indexOf(x.nome) < 0 && x.nome) nomi.push(x.nome); }
    });
    if (n && typeof toast === 'function') toast('+' + n + (n === 1 ? ' punto' : ' punti') + ' al nuovo te, perché sei rimasto fuori da ' + (nomi.join(', ') || 'un’app bloccata') + '.');
  }catch(_){ }
  FR_PUNTI_IN_CORSO = false;
  return n;
}
(function(){
  if (typeof document === 'undefined' || !document.addEventListener) return;
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(frPuntiInAttesa, 400); });
  setTimeout(frPuntiInAttesa, 3000);
})();
function frFoglio(html){
  let f = document.getElementById('frFoglio');
  if (!f){
    f = document.createElement('div'); f.id = 'frFoglio'; f.className = 'fr-velo';
    f.addEventListener('click', function(e){ if (e.target === f) frFoglioChiudi(); });
    document.body.appendChild(f);
  }
  f.innerHTML = '<div class="fr-sheet" role="dialog"><button type="button" class="fr-x" onclick="frFoglioChiudi()" aria-label="Chiudi">' + FR_X + '</button>' + html + '</div>';
  requestAnimationFrame(function(){ f.classList.add('open'); });
}
function frFoglioChiudi(){ const f = document.getElementById('frFoglio'); if (f) f.classList.remove('open'); }

/* ---------------------------------------------------------------------------------------
   2. CARBURANTE: il tachimetro e quanto costa quella trappola
   Il costo di una visita e' lo stesso conto di porte.js (ptPedaggiSync) e di Trappola.costo nel nativo.
   La storia (l'ultima caduta, la durata media) la legge il telefono: NATIVE.trappola, come la schermata vera.
   --------------------------------------------------------------------------------------- */
function frCarbCosto(min){
  if (!(min > 0)) return 0;
  let c = null; try{ c = (typeof DM_CFG !== 'undefined') ? DM_CFG : null; }catch(_){ }
  const alto = (c && c.altoMinMin) || 10, deb = (c && c.debito) || [3, 8], per = (c && c.piccoMinPer) || [10, 60], cm = (c && c.costoMedioMin) || 0.06;
  if (min < alto) return Math.max(0.2, Math.round(min * cm * 8 * 10) / 10);
  return Math.round((deb[0] + (deb[1] - deb[0]) * Math.max(0, Math.min(1, (min - per[0]) / (per[1] - per[0])))) * 10) / 10;
}
function frMinuti(m){
  m = Math.max(1, Math.round(m));
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60, s = h === 1 ? '1 ora' : h + ' ore';
  return r ? s + ' e ' + (r === 1 ? '1 minuto' : r + ' minuti') : s;
}
function frQuando(at, conOra){
  const d = new Date(at), oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const g0 = new Date(at); g0.setHours(0, 0, 0, 0);
  const giorni = Math.round((oggi.getTime() - g0.getTime()) / 86400000);
  const ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  const sett = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
  let g;
  if (giorni <= 0) g = 'oggi'; else if (giorni === 1) g = 'ieri'; else if (giorni < 7) g = sett[d.getDay()];
  else return 'il ' + d.getDate() + ' ' + FR_MESI[d.getMonth()];
  return conOra ? g + ' alle ' + ora : g;
}
const FR_TRAP = {};
function frTrappolaCarica(pkg){
  if (FR_TRAP[pkg] !== undefined) return;
  FR_TRAP[pkg] = null;
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.trappola) return;
    NATIVE.trappola({ pkg: pkg }).then(function(s){
      FR_TRAP[pkg] = s || null;
      /* i numeri veri sono arrivati: se la pagina e' aperta, l'anteprima si ridisegna con quelli */
      try{ const h = document.getElementById('lsStyles'); if (h && h.offsetParent && typeof lockScreenPaint === 'function') lockScreenPaint(); }catch(_){ }
    }).catch(function(){ });
  }catch(_){ }
}
let FR_STORICO = null;
function frStoricoApri(){
  const s = FR_STORICO; if (!s || typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Lo storico con ' + s.app + '</h3>'
    + s.righe.map(function(r){ return '<p class="fr-sto-r">' + r + '</p>'; }).join('')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
(function(){ const st = document.createElement('style'); st.textContent = '.fr-cinfo{display:block;margin:6px auto 0;padding:8px 14px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);cursor:pointer}.fr-sto-r{margin:0 0 12px;font:500 15px/1.5 var(--font-body);color:var(--muted)}'; document.head.appendChild(st); })();
function frCarbAnteprimaHtml(){
  const app = 'Instagram', pkg = 'com.instagram.android';
  frTrappolaCarica(pkg);
  const ped = frPedaggi() || {}, star = ped['*'] || {}, mio = ped[pkg] || {};
  let L = null;
  try{ if (typeof DP !== 'undefined' && DP && typeof DP.L === 'number') L = DP.L; }catch(_){ }
  if (L == null && isFinite(star.L)) L = +star.L;
  const s = FR_TRAP[pkg] || {};
  let media = +s.mediaMin || 0; if (!media && +mio.s > 0) media = +mio.s;
  const stima = !(media > 0);
  const previsto = frCarbCosto(stima ? 5 : media);
  const L1 = L != null ? Math.max(0, L - previsto) : null;
  const gauge = (typeof dpGaugeSvg === 'function') ? dpGaugeSvg(L != null ? L : 50) : '';
  const col = function(v){ return (typeof dpFascia === 'function') ? dpFascia(v) : '#fff'; };
  const banda = function(v){ return v >= 56 ? 'Alta' : v >= 44 ? 'Base' : 'Bassa'; };
  let ultima = '';
  if (s.ultimaAt) ultima = 'L’ultima volta, ' + frQuando(s.ultimaAt, !s.perGiorno) + ', ci sei rimasto ' + frMinuti(s.ultimaMin) + ': −' + frDec(frCarbCosto(s.ultimaMin)) + ' di carburante.';
  else if (stima) ultima = 'È una stima: la tua storia con ' + app + ' non c’è ancora.';
  const sotto = stima ? 'Una visita di 5 minuti costa circa −' + frDec(previsto) + ' di carburante.' : 'Di solito ci resti ' + frMinuti(media) + (s.perGiorno ? ' al giorno.' : '.');
  return '<div class="prev carb' + (L == null ? ' senza' : '') + '" style="--rot:' + (-previsto * 1.8) + 'deg">'
    + '<h4>' + app + ' ti costa carburante</h4>'
    + '<div class="fr-tach">' + gauge + '</div>'
    + (L != null ? '<div class="fr-cnum"><span class="a" style="color:' + col(L) + '">' + frDec(L) + '<small>' + banda(L) + '</small></span><span class="b" style="color:' + col(L1) + '">' + frDec(L1) + '<small>' + banda(L1) + '</small></span></div>' : '')
    + '<span class="fr-cbadge">' + (stima ? 'Circa −' : '−') + frDec(previsto) + ' se la apri adesso</span>'
    /* 0.9.347: al posto dell'ultima volta, dove arrivi stasera; l'ultima volta e il solito dietro alla (i) */
    + (function(){
        let sera = '';
        try{
          const d = (typeof DP !== 'undefined' && DP) ? DP.dett : null;
          const pr = (d && typeof ccProiezione === 'function') ? ccProiezione(d) : null;
          if (L != null && new Date().getHours() < 23) sera = pr ? 'Se continui di questo passo, stasera arrivi a ' + frDec(Math.max(0, pr.fine - previsto)) + ' di carburante.' : 'Se la apri adesso, da qui a stasera parti da ' + frDec(L1) + ' di carburante.';
        }catch(_){ }
        FR_STORICO = { app: app, righe: [ultima, sotto].filter(Boolean) };
        return (sera ? '<p class="fr-cult">' + sera + '</p>' : '') + '<button type="button" class="fr-cinfo" onclick="event.stopPropagation();frStoricoApri()">ⓘ  Lo storico con ' + app + '</button>';
      })()
    + '<span class="btn">Torna a quello che conta</span></div>';
}

/* 0.9.324: l'anteprima dell'uscita di rotta come la schermata vera (BlockOverlay.prezzoDiAdesso): un carosello senza schede */
function frStoriaPonteSvg(){
  return '<svg viewBox="0 0 320 210" width="100%" aria-hidden="true" font-family="sans-serif" text-anchor="middle"><text x="60" y="22" fill="#fff" font-size="12" font-weight="800">PAURA E DUBBIO</text><text x="60" y="38" fill="#BFD3EC" font-size="10.5">Indecisione, rimando</text><text x="260" y="22" fill="#8DF0CF" font-size="12" font-weight="800">FIDUCIA E FEDE</text><text x="260" y="38" fill="#BFD3EC" font-size="10.5">Decisione, velocità</text>'
    + '<path d="M0 130H80l-7 16 9 14-14 18 8 22-16 10" fill="none" stroke="#fff" stroke-width="2.200" stroke-linejoin="round"/><rect x="240" y="130" width="80" height="12" fill="#8DF0CF"/>'
    + '<path d="M80 130Q160 80 240 130" fill="none" stroke="#fff" stroke-width="3" stroke-dasharray="8 6"/><text x="160" y="68" fill="#fff" font-size="12.500" font-weight="800">LA DECISIONE</text><path d="M128 80h64m-7-6 7 6-7 6" fill="none" stroke="#fff" stroke-width="2.400" stroke-linecap="round"/>'
    + '<g stroke="#fff" stroke-width="4" stroke-linecap="round" fill="none"><circle cx="50" cy="94" r="6" fill="#fff" stroke="none"/><path d="M50 102v18M50 120l-7 10M50 120l7 10M50 106l9 9M50 106l-7 9"/></g><text x="32" y="196" fill="#fff" font-size="11.500" font-weight="800">Tu sei qui</text>'
    + '<g stroke="#8DF0CF" stroke-width="4" stroke-linecap="round" fill="none"><circle cx="262" cy="94" r="6" fill="#8DF0CF" stroke="none"/><path d="M262 102v18M262 120l-7 10M262 120l7 10M262 106l9 9M262 106l-7 9"/></g><path d="M300 130V82" stroke="#8DF0CF" stroke-width="2"/><path d="M300 82l-16 7 16 7z" fill="#8DF0CF"/><text x="276" y="166" fill="#8DF0CF" font-size="11.500" font-weight="800">Il tuo sogno</text></svg>';
}
function frStoriaBarreSvg(){
  const v = [38, 52, 24, 61, 44, 70, 33], g = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
  return '<svg viewBox="0 0 320 150" width="100%" aria-hidden="true" font-family="sans-serif" text-anchor="middle">' + v.map(function(x, i){ const X = 8 + i * 44; return '<rect x="' + X + '" y="' + (122 - x * 1.4) + '" width="36" height="' + (x * 1.4) + '" rx="6" fill="' + (i === 6 ? '#E63946' : 'rgba(140,198,255,.47)') + '"/><text x="' + (X + 18) + '" y="142" font-size="11" fill="#BFD3EC">' + g[i] + '</text>'; }).join('') + '</svg>';
}
function frStoriaTrappolaSvg(){
  const c = [50, 100, 150, 200, 250].map(function(x){ return '<circle cx="' + x + '" cy="98" r="13" fill="none" stroke="#E63946" stroke-width="3.400"/>'; }).join('');
  return '<svg viewBox="0 0 320 150" width="100%" aria-hidden="true" font-family="sans-serif"><path d="M8 111C110 100 190 60 300 16" fill="none" stroke="#8DF0CF" stroke-width="3" stroke-dasharray="7 7"/><path d="M8 111H300" stroke="#E63946" stroke-width="3.400"/>' + c + '<circle cx="300" cy="16" r="6" fill="#8DF0CF"/><circle cx="300" cy="111" r="6" fill="#E63946"/><circle cx="8" cy="111" r="6" fill="#fff"/><text x="4" y="134" fill="#fff" font-size="12" font-weight="700">Oggi</text><text x="316" y="134" text-anchor="end" fill="#fff" font-size="12" font-weight="700">Fra un anno, se non cambi</text><text x="288" y="20" text-anchor="end" fill="#8DF0CF" font-size="12" font-weight="700">Il tuo sogno</text></svg>';
}
function frStoriaSlide(tit, art, t1, t2){ return '<div class="fr-st-s"><b class="fr-st-t">' + tit + '</b><div class="fr-st-a">' + art + '</div><p class="fr-st-1">' + t1 + '</p><p class="fr-st-2">' + t2 + '</p></div>'; }
function frPrezzoAnteprimaHtml(){
  const su = (typeof ptStoriaSbloccata === 'function') && ptStoriaSbloccata();
  const l = [];
  /* 0.9.344, Andrea: "togli la slide con paura, dubbio, fiducia e fede: metti semplicemente il contatore del carburante e il ricalcolo della rotta" */
  l.push('<div class="fr-st-s">' + frCarbAnteprimaHtml() + '</div>');
  if (false){
    l.push(frStoriaSlide('Le tue ultime scelte', frStoriaBarreSvg(), '5 ore su Instagram in sette giorni.', 'Ognuna di queste barre è una decisione, anche quando non sembrava.'));
    l.push(frStoriaSlide('Se non cambi niente', frStoriaTrappolaSvg(), 'In un anno sono 260 ore su Instagram.', 'Riempi la bottiglia, ma il collo resta chiuso. Fra un anno saresti ancora qui.'));
  }
  l.push('<div class="fr-st-s">' + frAnteprimaHtml() + '</div>');
  return '<div class="fr-st" data-fr-pz><div class="fr-st-car" onscroll="frStoriaDot(this)">' + l.join('') + '</div><div class="fr-st-dots">' + l.map(function(_, i){ return '<i class="' + (i ? '' : 'on') + '"></i>'; }).join('') + '</div>'
    + '</div>';
}
function frStoriaDot(c){ const d = c.nextElementSibling, i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)); if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); }

/* ---------------------------------------------------------------------------------------
   3. CONTRATTO: la frase, il tentativo di oggi, la penitenza
   --------------------------------------------------------------------------------------- */
function frContrattoAttivo(){ try{ return typeof CTR !== 'undefined' && CTR.s && CTR.s.attivo; }catch(_){ return false; } }
function frContrattoAnteprimaHtml(){
  try{ if (typeof CTR !== 'undefined' && !CTR.s && typeof ctrCarica === 'function' && !frContrattoAnteprimaHtml.chiesto){ frContrattoAnteprimaHtml.chiesto = 1; ctrCarica().then(function(){ try{ const h = document.getElementById('lsStyles'); if (h && h.offsetParent && typeof lockScreenPaint === 'function') lockScreenPaint(); }catch(_){ } }); } }catch(_){ }
  const vero = frContrattoAttivo();
  const k = vero ? (CTR.s.contratto || {}) : { impegno: 'Aprire Instagram appena sveglio', grigioOre: 2, soldi: { tipo: 'amico', euro: 5, a: 'il tuo garante' }, apps: [{ p: 'com.instagram.android', n: 'Instagram' }] };
  let frase = String(k.frase || '').trim();
  if (!frase && typeof ctrFrase === 'function') frase = ctrFrase(k.impegno || '');
  const tent = (typeof CTR_REGOLE !== 'undefined' && CTR_REGOLE.tentativi) || 3;
  const p0 = ((k.apps || [])[0] || {}).p || '';
  let n = 1; try{ if (vero) n = (+((CTR.s.tentativi || {})[String(p0).toLowerCase()]) || 0) + 1; }catch(_){ }
  const sgarro = n >= tent;
  const conto = sgarro ? 'Oggi è il tentativo numero ' + n + ': conta come sgarro.'
    : n === tent - 1 ? 'Oggi è il tentativo numero ' + n + '. Al prossimo conta come sgarro.'
    : 'Oggi è il tentativo numero ' + n + '. Dal ' + tent + '° conta come sgarro.';
  const pen = [];
  if (+k.grigioOre > 0) pen.push('il telefono va in bianco e nero per ' + ((typeof ctrDurata === 'function') ? ctrDurata(k.grigioOre * 60) : k.grigioOre + ' ore'));
  const so = k.soldi || {};
  if (so.tipo && so.tipo !== 'nessuno') pen.push((so.tipo === 'beneficenza' ? 'doni ' + so.euro + ' € in beneficenza a ' + (so.a || 'un ente') : 'paghi ' + so.euro + ' € a ' + (so.a || 'chi fa da garante')));
  if (!pen.length) pen.push('le regole si cambiano solo dopo un’attesa');
  let lista = pen.length === 1 ? pen[0] : pen[0] + ' e ' + pen[1];
  lista = lista.charAt(0).toUpperCase() + lista.slice(1) + '.';
  return '<div class="prev ctrl">'
    + '<small class="fr-eti">' + (vero ? 'Il tuo contratto' : 'Esempio di contratto') + '</small>'
    + '<h4>“' + frEsc(frase || 'Il tuo contratto di abitudine') + '”</h4>'
    + '<p class="fr-tent">' + conto + '</p>'
    + '<div class="fr-pen' + (sgarro ? ' on' : '') + '"><small>' + (sgarro ? 'La penitenza è scattata' : 'Se sgarri') + '</small><b>' + frEsc(lista) + '</b></div>'
    + '<span class="btn">Mantengo il contratto</span></div>';
}

/* ---------------------------------------------------------------------------------------
   4. PARTITA: il punteggio e gli ultimi punti. C'e' solo con la regola "un punto al vecchio te a ogni tentativo"
   (regole-misura.js, quando: 'tentativo'). I tentativi li vede il telefono (la cronologia dei blocchi): qui diventano
   punti veri con la stessa regola (rgmSegna), e il tabellone torna al telefono per la schermata (lockPartita).
   --------------------------------------------------------------------------------------- */
const FR_TENT_VISTI = 'fl_partita_tent_visti';
const FR_TENT_TIPI = { app: 1, sito: 1, funzione: 1, parola: 1, adulti: 1 };
function frPartitaRegola(){
  try{ if (typeof rgmLeggi !== 'function') return null; return rgmLeggi().filter(function(r){ return r.on && r.quando === 'tentativo' && r.chi === 'old'; })[0] || null; }catch(_){ return null; }
}
function frPartitaDisponibile(){ return !!frPartitaRegola(); }
function frPunteggio(){ try{ const s = (typeof mtRoll === 'function') ? mtRoll() : null; return s ? { old: +s.old || 0, neo: +s.neo || 0 } : { old: 0, neo: 0 }; }catch(_){ return { old: 0, neo: 0 }; } }
function frMotivoTxt(e){
  let m = String((e && e.motivo) || '').trim();
  if (/^regola su misura:/i.test(m)){
    let r = null; try{ r = (typeof rgmLeggi === 'function') ? rgmLeggi().filter(function(x){ return x.id === e.regola; })[0] : null; }catch(_){ }
    const tra = m.match(/\(([^)]*)\)\s*$/);
    if (r && r.quando === 'tentativo') return 'Hai provato ad aprire ' + (tra ? tra[1] : 'un’app bloccata');
    m = m.replace(/^regola su misura:\s*/i, '').replace(/\s*\([^)]*\)\s*$/, '');
  }
  m = m.replace(/[«»]/g, '"');
  if (m.length > 70) m = m.slice(0, 67).replace(/\s+\S*$/, '') + '...';
  return m.charAt(0).toUpperCase() + m.slice(1);
}
/** Gli ultimi tre punti del registro della partita, dal piu' recente. */
function frPartitaUltimi(){
  let ev = [];
  try{ (typeof mgHist === 'function' ? mgHist() : []).slice(-3).forEach(function(g){ (g.eventi || []).forEach(function(e){ if (e && (e.chi === 'old' || e.chi === 'neo')) ev.push(e); }); }); }catch(_){ }
  ev.sort(function(a, b){ return (b.at || 0) - (a.at || 0); });
  return ev.slice(0, 3).map(function(e){ return { c: e.chi, m: frMotivoTxt(e), t: e.at || 0, p: +e.punti || 1 }; });
}
function frOra(t){ const d = new Date(t); const oggi = new Date().toDateString() === d.toDateString(); return oggi ? String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') : frQuando(t, true); }
function frPartitaAnteprimaHtml(){
  const s = frPunteggio(), r = frPartitaRegola(), punti = Math.max(1, Math.min(3, +(r && r.punti) || 1));
  const stemma = function(l){ return (typeof slCrestTag === 'function') ? slCrestTag(l, 34) : (l === 'Old' ? '🕳️' : '🚀'); };
  const righe = frPartitaUltimi().map(function(u){
    return '<li class="' + (u.c === 'old' ? 'old' : 'neo') + '"><b>' + (u.c === 'old' ? 'Vecchio te' : 'Nuovo te') + ' +' + u.p + '</b><span>' + frEsc(u.m) + '</span><i>' + frOra(u.t) + '</i></li>';
  }).join('');
  return '<div class="prev partita">'
    + '<small class="fr-eti">La partita</small>'
    + '<div class="fr-tab">'
    +   '<div class="fr-sq old"><span class="fr-stemma">' + stemma('Old') + '</span><b><span class="a">' + s.old + '</span><span class="b">' + (s.old + punti) + '</span></b><small>Il vecchio te</small></div>'
    +   '<i class="fr-vs" aria-hidden="true"></i>'
    +   '<div class="fr-sq neo"><span class="fr-stemma">' + stemma('Neo') + '</span><b>' + s.neo + '</b><small>Il nuovo te</small></div>'
    + '</div>'
    + '<p class="fr-punto">' + (punti === 1 ? 'Un punto' : punti + ' punti') + ' al vecchio te: hai provato ad aprire Instagram.</p>'
    + (righe ? '<div class="fr-ultimi"><small class="fr-eti">Ultimi punti</small><ul>' + righe + '</ul></div>' : '')
    + '<span class="btn">Torna a quello che conta</span></div>';
}

/* I tentativi fermati dal telefono diventano punti al vecchio te: una volta sola ciascuno (il segno e' FR_TENT_VISTI). */
let FR_TENT_GIRA = false;
async function frPartitaTentativi(){
  if (FR_TENT_GIRA) return;
  const r = frPartitaRegola();
  if (!r){ frPartitaSpingi(); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getRegistroBlocchi) return;
  FR_TENT_GIRA = true;
  try{
    let visti = 0; try{ visti = +localStorage.getItem(FR_TENT_VISTI) || 0; }catch(_){ }
    /* la prima volta si parte dall'accensione della regola (al massimo un giorno indietro): niente punti retroattivi */
    if (!visti) visti = Math.max(+r.at || Date.now(), Date.now() - 86400000);
    const res = await NATIVE.getRegistroBlocchi({ days: 2 });
    const nuovi = ((res && res.items) || []).filter(function(x){ return x && +x.t > visti && FR_TENT_TIPI[x.k || 'app']; })
      .sort(function(a, b){ return a.t - b.t; }).slice(-30);
    nuovi.forEach(function(x){
      const cosa = (x.k === 'sito' && x.c) ? x.c : (x.k === 'funzione' && x.c) ? x.c : (x.n || x.c || 'un’app bloccata');
      const t0 = Date.now();
      try{ if (typeof rgmSegna === 'function') rgmSegna('tentativo', cosa, +x.t); }catch(_){ }
      /* nel registro della partita il punto porta l'ora del tentativo, non quella in cui l'app l'ha contato */
      try{
        if (typeof mgToday === 'function' && typeof mgWriteToday === 'function'){
          const g = mgToday(); let c = false;
          (g.eventi || []).forEach(function(e){ if (e.regola === r.id && e.at >= t0 && !e.tent){ e.at = +x.t; e.tent = 1; c = true; } });
          if (c) mgWriteToday(g);
        }
      }catch(_){ }
      visti = Math.max(visti, +x.t);
    });
    try{ localStorage.setItem(FR_TENT_VISTI, String(visti)); }catch(_){ }
  }catch(_){ }
  FR_TENT_GIRA = false;
  frPartitaSpingi();
}
/* Il tabellone e la regola al telefono: la schermata Partita li mostra anche quando l'app e' chiusa. */
function frPartitaSpingi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setSettings) return;
    const r = frPartitaRegola(), s = frPunteggio();
    let visti = 0; try{ visti = +localStorage.getItem(FR_TENT_VISTI) || 0; }catch(_){ }
    const o = r ? { on: true, punti: Math.max(1, Math.min(3, +r.punti || 1)), visti: visti || Date.now(), old: s.old, neo: s.neo, ultimi: frPartitaUltimi() } : { on: false };
    const j = JSON.stringify(o);
    if (j === frPartitaSpingi.ultimo) return;
    frPartitaSpingi.ultimo = j;
    NATIVE.setSettings({ lockPartita: j }).catch(function(){ });
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){
  if (document.hidden) frPartitaSpingi();
  else setTimeout(frPartitaTentativi, 1200);
});
document.addEventListener('fl:regole', function(){ setTimeout(frPartitaTentativi, 300); });
setTimeout(frPartitaTentativi, 7000);

(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* 0.9.326, Andrea: "quel blocco appare larghissimo perche' mostra tutte le slide". width:0 + min-width:100%: il carosello non impone la sua larghezza alla carta */
    '.ls-card{min-width:0}.ls-card .fr-st{--u:.62px;flex:1 0 auto;min-height:392px;box-sizing:border-box;padding:10px;border-radius:16px;background:#001E44;overflow:hidden}.ls-full .fr-st{background:#001E44}.fr-st{display:flex;flex-direction:column;width:0;min-width:100%;min-height:0}.ls-full .fr-st{height:100%;flex:1}.ls-full .fr-st-car{flex:1}.fr-st-s{display:flex;flex-direction:column;justify-content:center}.fr-st-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.fr-st-car::-webkit-scrollbar{display:none}.fr-st-s{flex:0 0 100%;box-sizing:border-box;scroll-snap-align:center;min-width:0;padding:6px 4px;text-align:center}',
    '.fr-st-t{display:block;margin:6px 0 16px;font:800 calc(28 * var(--u,1px)) sans-serif;color:#fff}.fr-st-a{margin-bottom:14px}.fr-st-1{margin:0 0 8px;font:700 calc(18 * var(--u,1px))/1.25 sans-serif;color:#fff}.fr-st-2{margin:0;font:400 calc(15 * var(--u,1px))/1.3 sans-serif;color:#BCE0FF}',
    '.fr-st-dots{display:flex;justify-content:center;gap:8px;padding:12px 0}.fr-st-dots i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.35)}.fr-st-dots i.on{background:#fff}.fr-st-lock{margin:2px 0 8px;font:600 calc(13 * var(--u,1px)) sans-serif;color:#BCE0FF;text-align:center}',
    /* ---- Uscita di rotta ---- */
    /* 0.9.307: la copia di BlockOverlay.rottaCard. Le misure sono i dp del nativo per --u (1px a schermo intero, rimpicciolita
       nella card del carosello). Carattere di sistema (sans-serif), come le TextView. .fr-card resta per scrigni.js. */
    '.fr-card{box-sizing:border-box;width:100%;border-radius:20px;background:linear-gradient(180deg,#132C63,#0A1B44);padding:14px 12px 12px;display:flex;flex-direction:column;align-items:center;border:2px solid #E63946;opacity:0;animation:frDentro .4s ease .45s forwards}',
    '@keyframes frDentro{to{opacity:1}}@keyframes frVia{to{opacity:0}}',
    '@keyframes frPop{from{transform:scale(0)}to{transform:scale(1)}}',
    /* entra(): da trasparente e 12dp piu' in basso, 320 ms */
    '@keyframes frEntra{from{opacity:0;transform:translateY(calc(12 * var(--u,1px)))}to{opacity:1;transform:none}}',
    '.prev.fr{--u:1px;justify-content:flex-start!important;align-items:stretch!important;text-align:center;font-family:sans-serif;padding:calc(20 * var(--u)) calc(24 * var(--u))!important}',
    '.ls-card .prev.fr{--u:.62px}',
    /* a schermo intero: sotto alla barra di stato 20dp, ai lati 24dp; in fondo l'aria per la riga Anteprima */
    '.ls-full .prev.fr{padding:calc(env(safe-area-inset-top,0px) + 20px) 24px calc(env(safe-area-inset-bottom,0px) + 32px)!important;overflow-y:auto}',
    /* la riga Anteprima sta piu' in basso del solito: il pulsante resta quasi dove sta sulla schermata vera (20dp dal fondo) */
    '.ls-full .prev.fr ~ .ls-foot,.ls-full .fr-pr ~ .ls-foot{display:none}',
    /* le TextView del nativo hanno l'interlinea del carattere con il suo margine (includeFontPadding): 1,33 volte la misura */
    /* la X dell'anteprima (sulla schermata vera non c'e') sta nell'angolo, piu' piccola, per non toccare il titolo; sui
       telefoni stretti il titolo scende sotto la X */
    '.ls-full .prev.fr ~ .ls-x{top:calc(env(safe-area-inset-top,0px) + 8px);right:8px;width:34px;height:34px;font-size:15px}',
    '@media (max-width:359px){.ls-full .prev.fr{padding-top:calc(env(safe-area-inset-top,0px) + 48px)!important}}',
    '.prev.fr > h4.fr-tit{margin:0;font:700 calc(26 * var(--u))/1.33 sans-serif;color:#fff;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) 0s forwards}',
    '.prev.fr > p.fr-sotto{margin:calc(8 * var(--u)) 0 calc(22 * var(--u));font:400 calc(15 * var(--u))/1.33 sans-serif;color:#8FB6DC;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .2s forwards}',
    /* la card prende tutta l'altezza che resta fra la riga e il pulsante (peso 1), mai meno del suo contenuto */
    '.fr-arr{position:relative;flex:1 0 auto;margin:0 calc(2 * var(--u));border-radius:calc(26 * var(--u));border:calc(2 * var(--u)) solid #3F9FF4;background:linear-gradient(180deg,#132C63,#0A1B44);overflow:hidden;opacity:0;animation:frDentro .35s ease .45s forwards}',
    '.prev.fr.in .fr-arr{border-color:#E63946}',
    '.fr-cop,.fr-ombra{position:absolute;inset:0;display:block}',
    '.fr-cop{background-size:cover;background-position:center}',
    /* il velo del nativo: #33020926, #66020926, #E6020926 dall'alto in basso */
    '.fr-ombra{background:linear-gradient(180deg,rgba(2,9,38,.2),rgba(2,9,38,.4),rgba(2,9,38,.9))}',
    '.fr-cin{position:relative;display:flex;flex-direction:column;align-items:center;padding:calc(26 * var(--u)) calc(20 * var(--u)) calc(22 * var(--u))}',
    '.prev.fr .fr-arr-eti{display:block;font:700 calc(12 * var(--u))/1.33 sans-serif;letter-spacing:.16em;color:#C8EFFD;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .45s forwards}',
    '.prev.fr .fr-data{display:grid;margin-top:calc(8 * var(--u))}.prev.fr .fr-data > div{grid-area:1/1}',
    '.prev.fr .fr-data b{display:block;font:700 calc(40 * var(--u))/1.33 sans-serif;color:#fff;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .6s forwards}',
    '.prev.fr .fr-data span{display:block;font:400 calc(30 * var(--u))/1.33 sans-serif;color:#BFE0FF;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .75s forwards}',
    '.prev.fr.in .fr-data .a{animation:frVia .25s ease calc(var(--tt) + 700ms) forwards}.prev.fr .fr-data .b{opacity:0;animation:frDentro .25s ease calc(var(--tt) + 700ms) forwards}',
    /* il badge: le due scritte nella stessa cella, la combo esce e il tempo entra (0.9.304: largo al massimo quanto la card, va a capo) */
    '.prev.fr .fr-bol{display:grid;justify-items:center;align-self:center;max-width:100%;margin:calc(16 * var(--u)) 0 0;padding:0;border:0;background:none;cursor:pointer;font-family:sans-serif;transform:scale(0);animation:frPop .38s cubic-bezier(.3,1.8,.5,1) 1.2s forwards}',
    /* 0.9.308: il prospetto e' contornato di rosso su fondo velato: vicino al bollino rosso di Dream non ha lo stesso colore */
    '.prev.fr .fr-bol > span{grid-area:1/1;max-width:100%;display:inline-flex;align-items:center;justify-content:center;gap:calc(6 * var(--u));text-align:center;text-wrap:balance;border-radius:99px;padding:calc(5 * var(--u)) calc(12 * var(--u));background:rgba(255,255,255,.15);border:calc(2 * var(--u)) solid #E63946;color:#fff;font:700 calc(13 * var(--u))/1.33 sans-serif}',
    /* il bollino di Dream (rotta-tab.js, .nv-pill): rosso se la data e' andata avanti, verde se e' tornata indietro, grigio se e' la stessa */
    '.prev.fr .fr-dpill{align-self:center;margin:calc(14 * var(--u)) 0 0;padding:calc(6 * var(--u)) calc(14 * var(--u));border-radius:99px;background:rgba(255,255,255,.2);color:#fff;font:700 calc(13 * var(--u))/1.33 sans-serif;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .9s forwards}',
    '.prev.fr .fr-dpill.su{background:#E63946}.prev.fr .fr-dpill.giu{background:#1B9E6A}',
    '.prev.fr .fr-dpill + .fr-bol{margin-top:calc(10 * var(--u))}',
    /* la (i) del motivo del blocco accanto al titolo */
    '.prev.fr .fr-ti{display:inline-flex;align-items:center;justify-content:center;vertical-align:middle;width:calc(22 * var(--u));height:calc(22 * var(--u));margin:0 0 calc(4 * var(--u)) calc(8 * var(--u));padding:0;border:calc(1.5 * var(--u)) solid #fff;border-radius:50%;background:none;color:#fff;font:700 calc(13 * var(--u))/1 sans-serif;cursor:pointer}',
    '.fr-nota{margin:22px 0 0!important;font-size:13px!important;color:#8FB6DC!important}',
    '.prev.fr .fr-bol.grigio{cursor:default}.prev.fr .fr-bol.grigio > span{background:#5B6B86}',
    '.prev.fr .fr-bol.combo .a{animation:frVia .18s ease var(--tc) forwards}.prev.fr .fr-bol.combo .b{opacity:0;animation:frDentro .22s ease calc(var(--tc) + 180ms) forwards}',
    '.prev.fr .fr-i{flex:none;display:inline-flex;align-items:center;justify-content:center;width:calc(16 * var(--u));height:calc(16 * var(--u));border:calc(1 * var(--u)) solid #fff;border-radius:50%;font:700 calc(10 * var(--u))/1 sans-serif;font-style:normal}',
    /* la linea Oggi-Sogno: pista alta 28dp con 10dp ai lati, linea di 2dp, l'aereo (24dp) parte da sinistra e va a (larghezza - 24) x pct */
    '.prev.fr .fr-rotta{align-self:stretch;display:flex;align-items:center;margin-top:calc(20 * var(--u));font:400 calc(13 * var(--u))/1.33 sans-serif;color:#C8EFFD;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) .9s forwards}',
    '.fr-linea{position:relative;flex:1;height:calc(28 * var(--u));margin:0 calc(10 * var(--u))}',
    '.fr-linea::before{content:"";position:absolute;left:0;right:0;top:50%;height:calc(2 * var(--u));margin-top:calc(-1 * var(--u));background:rgba(255,255,255,.25)}',
    '.fr-linea i{position:absolute;left:0;top:50%;height:calc(2 * var(--u));margin-top:calc(-1 * var(--u));background:#3F9FF4;width:calc(100% * var(--f0))}',
    '.prev.fr.in .fr-linea i{background:#E63946;animation:frIndW 1.4s cubic-bezier(.2,.8,.3,1) var(--tt) forwards}',
    /* 0.9.302: lo stesso aereo della scheda Sogno (NV_AEREO, rotta-tab.js), girato di 90 gradi verso il sogno */
    '.fr-linea em{position:absolute;top:50%;left:calc((100% - 24 * var(--u)) * var(--f0));width:calc(24 * var(--u));height:calc(24 * var(--u));margin-top:calc(-12 * var(--u));display:block;transform:rotate(90deg);font-style:normal;line-height:1;color:#fff}',
    '.prev.fr.in .fr-linea em{animation:frIndA 1.4s cubic-bezier(.2,.8,.3,1) var(--tt) forwards}',
    '.fr-linea em svg{display:block;width:100%;height:100%}',
    '@keyframes frIndW{to{width:calc(100% * var(--f1))}}@keyframes frIndA{to{left:calc((100% - 24 * var(--u)) * var(--f1))}}',
    '.prev.fr .fr-perc{display:grid;margin:calc(6 * var(--u)) 0 0!important;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) 1.05s forwards}',
    '.prev.fr .fr-perc span{grid-area:1/1;font:700 calc(14 * var(--u))/1.33 sans-serif;color:#fff}',
    '.prev.fr.in .fr-perc .a{animation:frVia .25s ease calc(var(--tt) + 700ms) forwards}.prev.fr .fr-perc .b{opacity:0;animation:frDentro .25s ease calc(var(--tt) + 700ms) forwards}',
    /* il pulsante: largo quanto lo schermo meno i 24dp, 14dp sopra e sotto al testo 16 medio (alto 49dp come il Button); entra quando la schermata ha finito */
    '.prev.fr span.btn.fr-btn{display:block;align-self:stretch;margin:calc(18 * var(--u)) 0 0;padding:calc(14 * var(--u)) calc(24 * var(--u));border-radius:50px;background:#0075E3;color:#fff;font:500 calc(16 * var(--u))/1.33 sans-serif;text-align:center;opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) var(--tf) forwards}',
    '.prev.carb .btn,.prev.ctrl .btn,.prev.partita .btn{opacity:0;animation:frDentro .35s ease 4.4s forwards}',
    '.fr-pz{display:flex;flex-direction:column;background:#001E44;border-radius:16px;overflow:hidden}.ls-full .fr-pz{height:100%;border-radius:0;overflow-y:auto}.fr-pz > div[hidden]{display:none}',
    '.fr-pz-tabs{flex:none;display:flex;padding:calc(env(safe-area-inset-top,0px) + 6px) 10px 0;border-bottom:1px solid rgba(255,255,255,.12)}.ls-full .fr-pz-tabs{padding-top:calc(env(safe-area-inset-top,0px) + 54px)}',
    '.fr-pz-tabs button{flex:1;min-width:0;display:flex;align-items:center;justify-content:center;gap:6px;min-height:44px;padding:4px 2px 8px;border:0;border-bottom:3px solid transparent;margin-bottom:-1px;background:none;color:rgba(255,255,255,.6);font:800 12px/1.2 var(--font-body);cursor:pointer}.fr-pz-tabs button.on{color:#fff;border-bottom-color:#3F9FF4}',
    '.fr-pz-tabs i{display:none;flex:none;width:22px;height:22px;border-radius:11px;background:#fff;align-items:center;justify-content:center;font-style:normal;font-size:12px;line-height:1}.fr-pz-tabs button.on i{display:inline-flex}',
    /* 0.9.305: il bivio sotto alla card (BlockOverlay.bivioRotta): due pannelli affiancati alti uguali, blu pieno e bianco velato contornato di rosso */
    '.prev.fr .fr-bivio{display:grid;grid-template-columns:1fr 1fr;gap:calc(12 * var(--u));margin-top:calc(18 * var(--u));opacity:0;animation:frEntra .32s cubic-bezier(.2,.8,.3,1) var(--tf) forwards}',
    '.prev.fr .fr-bv{min-width:0;display:flex;flex-direction:column;align-items:center;text-align:center;border-radius:calc(22 * var(--u));padding:calc(14 * var(--u)) calc(12 * var(--u)) calc(16 * var(--u))}',
    '.prev.fr .fr-bv.blu{background:#0075E3}.prev.fr .fr-bv.rosso{background:rgba(255,255,255,.08);border:calc(2 * var(--u)) solid #E63946;padding:calc(12 * var(--u)) calc(10 * var(--u)) calc(14 * var(--u))}',
    '.prev.fr .fr-bv i{width:calc(40 * var(--u));height:calc(40 * var(--u));border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:calc(20 * var(--u));line-height:1}',
    '.prev.fr .fr-bv b{margin-top:calc(8 * var(--u));font:700 calc(16 * var(--u))/1.33 sans-serif;color:#fff}',
    '.prev.fr .fr-bv small{margin-top:calc(4 * var(--u));font:400 calc(13 * var(--u))/1.46 sans-serif;text-wrap:balance}.prev.fr .fr-bv.blu small{color:#E3F1FF}.prev.fr .fr-bv.rosso small{color:#FFB4BA}',
    /* ---- Carburante ---- */
    '.fr-tach{width:78%;max-width:230px;margin:6px auto 0;color:#fff}',
    '.fr-tach svg{display:block;width:100%;height:auto}',
    '.fr-tach .dp-ago{color:#fff}.fr-tach .dp-ago line{stroke:#fff}.fr-tach .dp-ago circle{fill:#fff}',
    '.fr-tach .dp-ax{font:800 9px var(--font-body);fill:rgba(255,255,255,.6)}',
    '.fr-tach .dp-ago{transform-origin:100px 100px;animation:frAgo 1.1s ease 1.1s forwards}',
    '@keyframes frAgo{to{transform:rotate(var(--rot))}}',
    '.prev.carb.senza .dp-ago{display:none}',
    '.fr-cnum{display:grid;margin-top:2px}',
    '.fr-cnum > span{grid-area:1/1;font:900 34px/1.05 var(--font-display);display:flex;flex-direction:column;align-items:center}',
    '.fr-cnum small{font:800 11px var(--font-body);color:#8FB6DC;margin-top:2px}',
    '.fr-cnum .a{animation:frVia .3s ease 2.1s forwards}.fr-cnum .b{opacity:0;animation:frDentro .3s ease 2.1s forwards}',
    '.fr-cbadge{margin-top:10px;border-radius:99px;padding:6px 13px;background:#E63946;color:#fff;font:800 11.5px var(--font-body);transform:scale(0);animation:frPop .45s cubic-bezier(.3,1.8,.5,1) 1.6s forwards}',
    '.prev.carb .fr-cult{margin-top:12px!important;color:#fff!important;font:600 11.5px/1.45 var(--font-body)!important;opacity:0;animation:frDentro .4s ease 2.6s forwards}',
    '.prev.carb .fr-cmed{margin-top:6px!important;opacity:0;animation:frDentro .4s ease 3s forwards}',
    /* ---- Contratto ---- */
    '.fr-eti{display:block;font:800 10px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#C8EFFD;margin-bottom:8px}',
    '.prev.ctrl h4{font-size:20px!important;line-height:1.25!important;margin-bottom:14px!important}',
    '.prev.ctrl .fr-tent{font:600 12px/1.45 var(--font-body)!important;color:#C8EFFD!important}',
    '.fr-pen{margin-top:14px;width:100%;box-sizing:border-box;border-radius:14px;padding:10px 12px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);display:flex;flex-direction:column;gap:4px}',
    '.fr-pen small{font:800 10.5px var(--font-body);color:#C8EFFD}.fr-pen b{font:800 12.5px/1.35 var(--font-body);color:#fff}',
    '.fr-pen.on{background:rgba(230,57,70,.18);border:2px solid #E63946}.fr-pen.on small{color:#FFB4BA}',
    /* ---- Partita ---- */
    '.fr-tab{display:flex;align-items:flex-start;justify-content:center;gap:6px;width:100%;margin-top:4px}',
    '.fr-sq{flex:1;display:flex;flex-direction:column;align-items:center;min-width:0}',
    '.fr-stemma{width:44px;height:44px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;overflow:hidden}',
    '.fr-stemma img{width:100%!important;height:100%!important;object-fit:cover}',
    '.fr-sq b{display:grid;font:900 46px/1.05 var(--font-display);margin-top:6px}.fr-sq b > span{grid-area:1/1}',
    '.fr-sq.old b{color:#FF5A66}.fr-sq.neo b{color:#3F9FF4}',
    '.fr-sq.old .a{animation:frVia .15s ease 1.2s forwards}.fr-sq.old .b{opacity:0;animation:frGol .5s cubic-bezier(.3,1.8,.5,1) 1.2s forwards}',
    '@keyframes frGol{from{opacity:1;transform:scale(1.7)}to{opacity:1;transform:scale(1)}}',
    '.fr-sq small{font:800 9.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#C8EFFD}',
    '.fr-vs{flex:0 0 16px;height:4px;border-radius:2px;background:#8FB6DC;margin-top:78px}',
    '.prev.partita .fr-punto{margin-top:12px!important;color:#fff!important;font:700 12px/1.4 var(--font-body)!important;opacity:0;animation:frDentro .4s ease 1.7s forwards}',
    '.fr-ultimi{width:100%;margin-top:14px;opacity:0;animation:frDentro .4s ease 2.1s forwards}',
    '.fr-ultimi ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}',
    '.fr-ultimi li{display:flex;flex-direction:column;align-items:center;font:500 10.5px/1.35 var(--font-body);color:#C8EFFD}',
    '.fr-ultimi li b{font:800 10.5px var(--font-body)}.fr-ultimi li.old b{color:#FFB4BA}.fr-ultimi li.neo b{color:#BCE0FF}',
    '.fr-ultimi li i{font-style:normal;color:#8FB6DC;font-size:10px}',
    /* ---- il popover del badge ---- */
    '.fr-velo{position:fixed;inset:0;z-index:10050;background:rgba(0,8,20,.62);display:flex;align-items:flex-end;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s}',
    '.fr-velo.open{opacity:1;pointer-events:auto}',
    '.fr-sheet{position:relative;width:100%;max-width:520px;box-sizing:border-box;max-height:86vh;overflow-y:auto;background:#1C2E5A;border:1px solid rgba(255,255,255,.2);border-bottom:0;color:#fff;border-radius:26px 26px 0 0;padding:22px 22px calc(env(safe-area-inset-bottom,0px) + 26px);transform:translateY(100%);transition:transform .3s cubic-bezier(.2,.8,.2,1);text-align:center}',
    '.fr-velo.open .fr-sheet{transform:none}',
    '.fr-x{position:absolute;top:12px;right:12px;width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.fr-sheet h3{margin:14px 40px 8px;font:900 22px/1.2 var(--font-display);color:#fff;text-wrap:balance}',
    '.fr-lead{margin:0 0 22px;font:500 15px/1.45 var(--font-body);color:#C8EFFD;text-wrap:balance}',
    '.fr-righe{list-style:none;margin:0 auto;padding:0;max-width:380px;display:flex;flex-direction:column;gap:18px;text-align:left}',
    '.fr-righe li{display:flex;align-items:center;gap:14px}',
    '.fr-righe i{flex:none;width:44px;height:44px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:21px;line-height:1;box-shadow:0 4px 12px rgba(0,8,20,.3)}',
    '.fr-righe span{flex:1;min-width:0;font:700 15.5px/1.4 var(--font-body);color:#fff}',
    '.fr-ok{display:block;width:100%;margin-top:26px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 15px var(--font-body);padding:15px;cursor:pointer}',
    '.fr-piu{display:inline-flex;align-items:center;gap:6px;margin:22px auto 0;padding:8px 14px;border:0;border-radius:50px;background:rgba(255,255,255,.1);color:#BCE0FF;font:800 14px var(--font-body);cursor:pointer}',
    '.fr-piu svg{transition:transform .2s}.fr-piu.su svg{transform:rotate(180deg)}',
    '.fr-studi{margin-top:18px!important}.fr-studi span{font-weight:600!important;font-size:14.5px!important;color:#E3F1FF!important}',
    /* ---- 0.9.400 BUG-169: per quanto tempo entri, e la rettifica del programma (fogli scuri anche con il tema chiaro) ---- */
    '.fr-blu{color:#4FB8FF}',
    '.fr-durate{display:flex;flex-direction:column;gap:10px;max-width:420px;margin:0 auto;text-align:left}',
    '.fr-dur{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;padding:13px 16px;border:1px solid rgba(255,255,255,.22);border-radius:18px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer;text-align:left;transition:box-shadow .15s,background .15s}',
    '.fr-dur:active,.fr-dur:focus-visible{background:rgba(47,140,255,.18);box-shadow:0 0 0 2px #2f8cff,0 0 14px rgba(47,140,255,.55);outline:0}',
    '.fr-dur i{flex:none;width:42px;height:42px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:21px;line-height:1;box-shadow:0 4px 12px rgba(0,8,20,.3)}',
    '.fr-dur span{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
    '.fr-dur b{font:800 16px/1.25 var(--font-body);color:#fff}.fr-dur small{font:600 13px/1.35 var(--font-body);color:#C8EFFD}',
    '.fr-rett{margin-top:18px!important}',
    '.fr-tipi{display:flex;gap:10px;max-width:420px;margin:0 auto 14px}',
    '.fr-tipo{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border:1px solid rgba(255,255,255,.22);border-radius:16px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer}',
    '.fr-tipo i{font-style:normal;font-size:20px;filter:drop-shadow(0 0 2px #fff)}.fr-tipo b{font:800 15px var(--font-body);color:#fff}',
    '.fr-tipo.on,.fr-chip.on{background:rgba(47,140,255,.2);border-color:#2f8cff;box-shadow:0 0 0 2px #2f8cff,0 0 14px rgba(47,140,255,.55)}',
    '.fr-chips{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;max-width:420px;margin:0 auto}',
    '.fr-chip{min-width:64px;padding:10px 12px;border:1px solid rgba(255,255,255,.22);border-radius:99px;background:rgba(255,255,255,.08);color:#fff;font:800 14px var(--font-body);cursor:pointer}',
    '.fr-nota{max-width:420px;margin:16px auto 0;font:500 13px/1.45 var(--font-body);color:#C8EFFD}',
    /* ---- a schermo intero tutto piu' grande ---- */
    '.ls-full .prev.carb,.ls-full .prev.ctrl,.ls-full .prev.partita{padding-top:64px!important;justify-content:center!important}',
    '.ls-full .fr-cbadge{font-size:15px;padding:9px 16px}',
    '.ls-full .fr-tach{max-width:300px}.ls-full .fr-cnum > span{font-size:48px}',
    '.ls-full .prev.carb .fr-cult{font-size:15px!important}.ls-full .prev.carb .fr-cmed{font-size:14px!important}',
    '.ls-full .prev.ctrl h4{font-size:28px!important}.ls-full .prev.ctrl .fr-tent{font-size:16px!important}.ls-full .fr-pen b{font-size:16px}.ls-full .fr-pen small{font-size:13px}',
    '.ls-full .fr-sq b{font-size:72px}.ls-full .fr-stemma{width:60px;height:60px;font-size:32px}.ls-full .fr-vs{flex-basis:24px;margin-top:112px}.ls-full .fr-sq small{font-size:12px}',
    '.ls-full .fr-eti{font-size:12px;margin-bottom:12px}',
    '.ls-full .prev.partita .fr-punto{font-size:16px!important}.ls-full .fr-ultimi li,.ls-full .fr-ultimi li b{font-size:13.5px}'
  ].join('');
  document.head.appendChild(st);
})();
