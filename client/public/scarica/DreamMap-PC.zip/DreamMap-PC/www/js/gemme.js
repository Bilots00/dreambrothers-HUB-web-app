/* ===========================================================================================
   LE GEMME, "RICEVI ALTRE" E LA MISSIONE DEL WEEKEND (0.9.367)

   Andrea: "voglio che ci sia sempre il pulsante Ricevi altre X monete, come su Duolingo, guardando una pubblicita'. E le gemme,
   come in Clash Royale e Duolingo: comprano quello che le monete non comprano, aumentano la variabilita' della ricompensa e sono
   piu' preziose". E: "su Duolingo, alla fine di una lezione, c'e' l'aggiornamento della Missione del weekend con lo scrigno e
   Invia un regalo alla persona con cui fai la missione".

   COME FUNZIONA SU DUOLINGO (dalle stringhe dell'app 5.141.12, presa da BlueStacks il 18/11/2026):
   - le gemme si guadagnano con la ricompensa del giorno ("Torna domani per nuove ricompense"), i forzieri, le missioni, la
     Missione di Gruppo con un amico; dopo un premio "Guarda un annuncio per raddoppiare il tuo premio" / "Ricevi altre 15";
   - si spendono per le Congelazioni slancio, le ricariche delle vite, il Livello leggendario, ritentare una sfida.

   IN DREAMMAP:
   - le MONETE restano quelle di sempre (temi, suoni, congelamenti, pozioni da 15 minuti);
   - le GEMME (💎) sono rare e variabili: la ricompensa della prima tappa del giorno (di solito 5, a volte 10, raro 20, rarissimo
     50), lo scrigno della Missione del weekend, la missione del mese, i video a premio. Comprano solo cose che le monete non
     comprano: un giorno di Premium, riparare la serie spezzata ieri, la pozione da 30 minuti, uno scrigno d'oro;
   - "RICEVI ALTRE": dopo ogni premio di monete o di gemme, un video a premio (ads.js, adsRicompensa) ne da' il triplo. Con
     Premium non ci sono video: l'extra arriva gratis. Dove i video non esistono (il PC) il pulsante non c'e'.
   - la MISSIONE DEL WEEKEND: sabato e domenica, sei tappe in due, con un amico (quello piu' attivo) o, senza amici, da solo.
     Dopo ogni tappa del weekend la schermata "Aggiornamento Missione del weekend!" con la barra, le tappe di tutti e due, la
     missione del mese sotto, "Invia un regalo" e, a missione fatta, "Apri lo scrigno". Nei giorni feriali, alla prima tappa
     del giorno, l'aggiornamento della missione del mese.
   =========================================================================================== */
const GM_K = 'fl_gemme';
const WM_K = 'fl_wm';
const WM_OBIETTIVO = 6;
const GM_ICO = '<svg class="gm-ico" viewBox="0 0 24 24" width="1em" height="1em" aria-hidden="true"><path d="M7 3h10l4 6-9 12L3 9z" fill="#3F9FF4"/><path d="M7 3l5 6 5-6M3 9h18M12 9v12" fill="none" stroke="#C8EFFD" stroke-width="1.3" stroke-linejoin="round"/><path d="M7 3h10l4 6H3z" fill="#8CC6FF" opacity=".55"/></svg>';
const GM_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

function gmEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function gmK(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function gmSt(){ let s = null; try{ s = JSON.parse(localStorage.getItem(GM_K) || 'null'); }catch(_){ } s = s || {}; s.n = +s.n || 0; s.log = s.log || []; return s; }
function gmSalva(s){ try{ localStorage.setItem(GM_K, JSON.stringify(s)); }catch(_){ } }
function gmSaldo(){ return gmSt().n; }
function gmDai(n, perche){
  n = Math.max(0, Math.round(n || 0)); if (!n) return;
  const s = gmSt(); s.n += n; s.log.push({ at: Date.now(), d: n, p: perche || '' }); s.log = s.log.slice(-80); gmSalva(s);
  gmSaldiAggiorna();
}
function gmSpendi(n, perche){
  const s = gmSt();
  if (s.n < n){ gmPocheApri(n - s.n); return false; }
  s.n -= n; s.log.push({ at: Date.now(), d: -n, p: perche || '' }); s.log = s.log.slice(-80); gmSalva(s);
  gmSaldiAggiorna();
  return true;
}
function gmSaldiAggiorna(){ try{ document.querySelectorAll('[data-gm-saldo]').forEach(function(x){ x.textContent = String(gmSaldo()); }); }catch(_){ } }
function gmVibra(p){ try{ if (typeof flVibra === 'function') flVibra(p || 12); }catch(_){ } }
function gmPremium(){ try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; } }
/** Si puo' offrire "Ricevi altre"? Con Premium si (gratis), senza Premium solo se il video a premio esiste. */
function gmExtraPossibile(){
  if (gmPremium()) return true;
  try{ return typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile(); }catch(_){ return false; }
}
/** Le gemme che mancano: il foglio dice quante e dove si prendono. */
function gmPocheApri(mancano){
  if (typeof inSheet !== 'function'){ if (typeof toast === 'function') toast('Ti mancano ' + mancano + ' gemme'); return; }
  inSheet('<div class="en-foglio gm-poche"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<span class="gm-poche-e">' + GM_ICO + '</span><h3>Ti mancano ' + mancano + ' gemme</h3>'
    + '<p class="gm-poche-s">Le guadagni con la prima tappa di ogni giorno, la Missione del weekend e la missione del mese.</p>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}

/* ---------------------------------------------------------------- LA SCHERMATA DEL PREMIO
   Come Duolingo: in alto a destra il saldo, al centro "+5 gemme" e il mucchietto, in basso "▶ RICEVI ALTRE 15 GEMME" e
   "NO, GRAZIE". o = { tipo: 'gemme'|'monete', n, extra, poi } */
const GM = { o: null };
/* 0.9.369, Andrea: "nella mystery box la moneta e' l'emoji, qui un'altra moneta disegnata: due monete diverse". Le monete sono la stessa
   emoji 🪙 della mystery box, una sopra l'altra */
function gmMucchioSvg(tipo, n){
  if (tipo === 'monete'){
    const q = Math.max(3, Math.min(7, Math.round(Math.log2((n || 1) + 1)) + 2));
    const pos = [[50, 58], [30, 66], [70, 66], [40, 44], [60, 44], [20, 54], [80, 54]].slice(0, q);
    return '<div class="gm-mucchio gm-muc-m" aria-hidden="true">' + pos.map(function(p, i){ return '<span style="left:' + p[0] + '%;top:' + p[1] + '%;--i:' + i + '">🪙</span>'; }).join('') + '</div>';
  }
  const quanti = Math.max(3, Math.min(7, Math.round(Math.log2((n || 1) + 1)) + 2));
  const pos = [[60, 70], [36, 82], [84, 82], [48, 58], [72, 58], [24, 70], [96, 70]].slice(0, quanti);
  const pezzo = function(p, i){
    if (tipo === 'monete') return '<g transform="translate(' + p[0] + ' ' + p[1] + ')" style="--i:' + i + '"><ellipse rx="17" ry="17" fill="#FFC53D" stroke="#C98A00" stroke-width="2"/><ellipse rx="10" ry="10" fill="none" stroke="#C98A00" stroke-width="2" opacity=".6"/></g>';
    return '<g transform="translate(' + p[0] + ' ' + p[1] + ')" style="--i:' + i + '"><path d="M-12 -14h24l9 13-21 25-21-25z" fill="#3F9FF4"/><path d="M-12 -14h24l9 13h-42z" fill="#8CC6FF"/><path d="M-7 -9h8l-3 6h-8z" fill="#F0FBFF" opacity=".9"/></g>';
  };
  return '<svg class="gm-mucchio" viewBox="0 0 120 120" aria-hidden="true"><ellipse cx="60" cy="100" rx="48" ry="9" fill="rgba(0,0,0,.28)"/>' + pos.map(pezzo).join('') + '</svg>';
}
function gmPremio(o){
  GM.o = o;
  let w = document.getElementById('gmPremio');
  if (!w){ w = document.createElement('div'); w.id = 'gmPremio'; w.className = 'gm-pr'; (document.getElementById('phone') || document.body).appendChild(w); }
  const gem = o.tipo !== 'monete';
  const saldo = gem ? gmSaldo() : ((typeof ffCoins === 'function') ? ffCoins() : 0);
  const extraOk = o.extra > 0 && gmExtraPossibile();
  const premium = gmPremium();
  w.innerHTML = '<div class="gm-pr-in">'
    + '<div class="gm-pr-saldo">' + (gem ? GM_ICO : '<span>🪙</span>') + '<b id="gmPrSaldo">' + saldo + '</b></div>'
    + '<h2 class="gm-pr-t' + (gem ? '' : ' mon') + '">+' + o.n + ' ' + (gem ? 'gemme' : 'monete') + '</h2>'
    + (o.sotto ? '<p class="gm-pr-s">' + gmEsc(o.sotto) + '</p>' : '')
    + '<div class="gm-pr-art">' + gmMucchioSvg(o.tipo, o.n) + '</div>'
    + '<div class="gm-pr-bot">'
    + (extraOk ? '<button type="button" class="gm-pr-cta" onclick="gmPremioExtra()">' + (premium ? '👑 ' : '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M7 4.5v15l12-7.5z" fill="currentColor"/></svg>') + '<span>' + (premium ? 'Prendi altre ' : 'Ricevi altre ') + o.extra + ' ' + (gem ? 'gemme' : 'monete') + (premium ? ' con Premium' : '') + '</span></button>' : '')
    + '<button type="button" class="' + (extraOk ? 'gm-pr-no' : 'gm-pr-cta') + '" onclick="gmPremioFine()">' + (extraOk ? 'No, grazie' : 'Continua') + '</button>'
    + (extraOk && !premium ? '<small class="gm-pr-nota">Guardi un breve video e le monete in più sono tue.</small>' : '')
    + '</div></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  gmVibra([12, 30, 12]);
  try{ if (typeof gnAu !== 'undefined' && gnAu.punto) gnAu.punto(); }catch(_){ }
}
function gmPremioDai(o, n){
  if (o.tipo === 'monete'){ try{ if (typeof ffAddCoins === 'function') ffAddCoins(n); }catch(_){ } }
  else gmDai(n, o.perche || 'premio');
}
function gmPremioExtra(){
  const o = GM.o; if (!o) return;
  const dai = function(){
    gmPremioDai(o, o.extra);
    const b = document.getElementById('gmPrSaldo'); if (b) b.textContent = String(o.tipo === 'monete' ? ((typeof ffCoins === 'function') ? ffCoins() : 0) : gmSaldo());
    const t = document.querySelector('#gmPremio .gm-pr-t'); if (t) t.textContent = '+' + (o.n + o.extra) + ' ' + (o.tipo === 'monete' ? 'monete' : 'gemme');
    const a = document.querySelector('#gmPremio .gm-pr-art'); if (a) a.innerHTML = gmMucchioSvg(o.tipo, o.n + o.extra);
    const bot = document.querySelector('#gmPremio .gm-pr-bot'); if (bot) bot.innerHTML = '<button type="button" class="gm-pr-cta" onclick="gmPremioFine()">Continua</button>';
    gmVibra([20, 40, 60]);
  };
  /* 0.9.369, Andrea: "ho ricevuto le monete senza vedere il video". In questa build Premium e' acceso per le prove (FL_DEBUG_PREMIUM, profile.js),
     e con Premium il video non c'e'. Adesso il pulsante lo dice chiaro, e la frase sotto dice da dove vengono le monete in piu' */
  const dopo = function(viaVideo){ dai(); const s0 = document.querySelector('#gmPremio .gm-pr-s'); if (s0) s0.textContent = o.n + ' con la tappa, ' + o.extra + (viaVideo ? ' con il video.' : ' con Premium.'); };
  if (gmPremium()){ dopo(false); return; }
  try{ adsRicompensa(function(){ dopo(true); }); }catch(_){ }
}
function gmPremioFine(){
  const w = document.getElementById('gmPremio'); const o = GM.o; GM.o = null;
  if (w){ w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 200); }
  if (o && typeof o.poi === 'function') setTimeout(function(){ try{ o.poi(); }catch(_){ } }, 120);
}

/* ---------------------------------------------------------------- DOPO LA TAPPA
   Nell'ordine: le monete della tappa (se ce ne sono) con il loro "Ricevi altre", la ricompensa di gemme della prima tappa del
   giorno, poi l'aggiornamento delle missioni (weekend o mese). Ritorna true se si prende in carico il seguito. */
function gmRoll(){
  const r = Math.random();
  return r < 0.02 ? 50 : (r < 0.10 ? 20 : (r < 0.30 ? 10 : 5));
}
function gmDopoTappa(poi){
  const fine = (typeof SD !== 'undefined' && SD.fine) ? SD.fine : null;
  const det = fine ? (fine.det || {}) : {};
  const passi = [];
  if (fine && det.monete > 0 && !fine.gmMon){
    fine.gmMon = true;
    passi.push(function(dopo){ gmPremio({ tipo: 'monete', n: det.monete, extra: det.monete * 2, sotto: 'Le hai guadagnate con questa tappa.', poi: dopo }); });
  }
  const s = gmSt(), oggi = gmK();
  if (s.giorno !== oggi){
    s.giorno = oggi; gmSalva(s);
    const n = gmRoll();
    gmDai(n, 'prima tappa del giorno');
    passi.push(function(dopo){ gmPremio({ tipo: 'gemme', n: n, extra: n * 3, perche: 'video a premio', sotto: n >= 20 ? 'Oggi ti è andata bene: è una ricompensa rara.' : 'Usale nel negozio. Torna domani per nuove ricompense!', poi: dopo }); });
  }
  if (wmDaMostrare()) passi.push(function(dopo){ wmAggiornamento(dopo); });
  if (!passi.length) return false;
  let i = 0;
  const vai = function(){ const p = passi[i++]; if (p) p(vai); else if (typeof poi === 'function') poi(); };
  vai();
  return true;
}

/* ---------------------------------------------------------------- LA MISSIONE DEL WEEKEND */
/** Il sabato del weekend in corso ('aaaa-mm-gg'), o '' nei giorni feriali. */
function wmSabato(t){ const d = new Date(t || Date.now()); const g = d.getDay(); if (g !== 6 && g !== 0) return ''; d.setDate(d.getDate() - (g === 0 ? 1 : 0)); return gmK(d.getTime()); }
function wmGiorni(sab){ const p = sab.split('-'); const d = new Date(+p[0], +p[1] - 1, +p[2], 12); return [gmK(d.getTime()), gmK(d.getTime() + 86400000)]; }
function wmSt(){ let s = null; try{ s = JSON.parse(localStorage.getItem(WM_K) || 'null'); }catch(_){ } s = s || {}; s.pg = s.pg || {}; return s; }
function wmSalva(s){ try{ localStorage.setItem(WM_K, JSON.stringify(s)); }catch(_){ } }
function wmAmici(){ try{ return (typeof FR !== 'undefined' && FR.amici && FR.amici.amici) || []; }catch(_){ return []; } }
/** Lo stato del weekend: con chi, quante tappe a testa, se lo scrigno e' stato aperto. */
function wmDati(){
  const sab = wmSabato(); if (!sab) return null;
  const s = wmSt();
  if (s.k !== sab){
    /* un weekend nuovo: il compagno e' l'amico piu' attivo della settimana; senza amici si gioca da soli */
    const am = wmAmici().slice().sort(function(a, b){ return (+b.score7 || 0) - (+a.score7 || 0); })[0];
    s.k = sab; s.pg = {}; s.presa = 0; s.viste = 0; s.compagno = am ? { device: am.device, nome: am.nome } : null;
    wmSalva(s);
  }
  const giorni = wmGiorni(sab);
  let mie = 0;
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; giorni.forEach(function(k){ if (g[k] > 0) mie += g[k]; }); }catch(_){ }
  let suoi = 0;
  if (s.compagno){
    const a = wmAmici().filter(function(x){ return x.device === s.compagno.device; })[0];
    if (a){
      let oggiSuoi = null; try{ oggiSuoi = (typeof frMetVal === 'function') ? frMetVal(a.metriche, 'tappe', 'oggi') : null; }catch(_){ }
      const k = gmK();
      if (oggiSuoi != null && giorni.indexOf(k) >= 0){ s.pg[k] = Math.max(+s.pg[k] || 0, +oggiSuoi || 0); wmSalva(s); }
      s.compagno.donoOggi = !!a.donoOggi;
    }
    giorni.forEach(function(k){ suoi += +s.pg[k] || 0; });
  }
  const tot = mie + suoi;
  return { k: sab, compagno: s.compagno, mie: mie, suoi: suoi, tot: Math.min(WM_OBIETTIVO, tot), fatta: tot >= WM_OBIETTIVO, presa: !!s.presa, viste: +s.viste || 0, donoOggi: s.compagno && s.compagno.donoOggi };
}
/** Si mostra: nel weekend dopo ogni tappa finche' lo scrigno non e' aperto; nei feriali la missione del mese, una volta al giorno. */
function wmDaMostrare(){
  const d = wmDati();
  if (d) return !d.presa;
  if (typeof mdmDati !== 'function') return false;
  const s = wmSt(); if (s.meseVisto === gmK()) return false;
  const m = mdmDati(); if (m.fatta) return false;   /* completata: la apre la schermata delle missioni (sdMisApri) */
  return m.n > 0;
}
function wmBarra(n, tot, scrigno){
  const pct = Math.max(0, Math.min(100, n / Math.max(1, tot) * 100));
  return '<div class="wm-bar-w"><div class="wm-bar"><i style="--p:' + pct.toFixed(1) + '%"></i><span>' + n + '/' + tot + '</span></div>' + (scrigno ? '<img class="wm-scr" src="img/mystery/chiusa.webp" alt="">' : '') + '</div>';
}
function wmAggiornamento(poi){
  const d = wmDati();
  const m = (typeof mdmDati === 'function') ? mdmDati() : null;
  let w = document.getElementById('wmAgg');
  if (!w){ w = document.createElement('div'); w.id = 'wmAgg'; w.className = 'wm'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.__poi = poi;
  const meseRiga = m ? '<div class="wm-mese"><div><b>Missione di ' + gmEsc(m.mese) + '</b><small>' + m.n + '/' + m.tot + ' tappe</small></div><span class="wm-mese-e" aria-hidden="true">⭐</span></div>' : '';
  let corpo, bot;
  if (d){
    const io = (typeof dsoTu === 'function') ? dsoTu('wm-av') : '<span class="wm-av">Tu</span>';
    const lui = d.compagno ? ((typeof dsoAv === 'function') ? dsoAv(d.compagno.nome, d.compagno.device, 'wm-av') : '<span class="wm-av">' + gmEsc(String(d.compagno.nome).charAt(0)) + '</span>') : '';
    const s = wmSt(); s.viste = d.tot; wmSalva(s);
    corpo = '<h2 class="wm-t">Aggiornamento<br>Missione del weekend!</h2>'
      + '<div class="wm-scena' + (d.compagno ? '' : ' solo') + '">' + io + (d.compagno ? lui : '') + '</div>'
      + wmBarra(d.tot, WM_OBIETTIVO, true)
      + '<div class="wm-righe"><div><i class="wm-pt io"></i><b>Tu</b><small>' + d.mie + (d.mie === 1 ? ' tappa' : ' tappe') + '</small></div>'
      + (d.compagno ? '<div><i class="wm-pt"></i><b>' + gmEsc(d.compagno.nome) + '</b><small>' + d.suoi + (d.suoi === 1 ? ' tappa' : ' tappe') + '</small></div>' : '')
      + '</div>' + (meseRiga ? '<hr class="wm-hr">' + meseRiga : '');
    if (d.fatta && !d.presa) bot = '<button type="button" class="wm-cta" onclick="wmScrigno()">Apri lo scrigno</button>';
    else bot = (d.compagno && !d.donoOggi ? '<button type="button" class="wm-cta" onclick="wmRegalo(this)">🎁 Invia un regalo a ' + gmEsc(d.compagno.nome) + '</button>' : '')
      + '<button type="button" class="' + (d.compagno && !d.donoOggi ? 'wm-no' : 'wm-cta') + '" onclick="wmFine()">Continua</button>';
  } else {
    const s = wmSt(); s.meseVisto = gmK(); wmSalva(s);
    corpo = '<h2 class="wm-t">Aggiornamento<br>Missione di ' + gmEsc(m.mese) + '</h2>'
      + '<div class="wm-scena solo"><span class="wm-grande" aria-hidden="true">⭐</span></div>'
      + wmBarra(m.n, m.tot, true)
      + '<p class="wm-sotto">Mancano ' + (m.tot - m.n) + ' tappe allo scrigno del mese.</p>';
    bot = '<button type="button" class="wm-cta" onclick="wmFine()">Continua</button>';
  }
  w.innerHTML = '<div class="wm-in">' + corpo + '<div class="wm-bot">' + bot + '</div></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); requestAnimationFrame(function(){ w.classList.add('va'); }); });
  gmVibra(12);
}
function wmFine(){
  const w = document.getElementById('wmAgg'); if (!w) return;
  const poi = w.__poi; w.__poi = null;
  w.classList.remove('in', 'va'); setTimeout(function(){ w.hidden = true; }, 200);
  if (typeof poi === 'function') setTimeout(function(){ try{ poi(); }catch(_){ } }, 120);
}
async function wmRegalo(btn){
  const d = wmDati(); if (!d || !d.compagno) return;
  try{ if (typeof frDonoManda === 'function') await frDonoManda(d.compagno.device, d.compagno.nome, null); }catch(_){ }
  if (btn){ btn.outerHTML = ''; }
  const no = document.querySelector('#wmAgg .wm-no'); if (no) no.className = 'wm-cta';
}
function wmScrigno(){
  const s = wmSt(); if (s.presa) return;
  s.presa = Date.now(); wmSalva(s);
  const w = document.getElementById('wmAgg'); const poi = w ? w.__poi : null; if (w){ w.__poi = null; w.hidden = true; w.classList.remove('in', 'va'); }
  const gemme = function(){ gmDai(20, 'missione del weekend'); gmPremio({ tipo: 'gemme', n: 20, extra: 40, perche: 'video a premio', sotto: 'La Missione del weekend è completata.', poi: poi }); };
  try{
    if (typeof scrApriPremio === 'function'){ scrApriPremio('oro', { titolo: 'Scrigno della Missione del weekend', onChiudi: gemme }); return; }
  }catch(_){ }
  gemme();
}

/* ---------------------------------------------------------------- IL NEGOZIO DELLE GEMME */
function gmSerieDaRiparare(){
  try{
    if (typeof sdGiorniFatti !== 'function' || typeof sdStato !== 'function') return null;
    const g = sdGiorniFatti();
    const ieri = gmK(Date.now() - 86400000), prima = gmK(Date.now() - 2 * 86400000);
    if (g[ieri]) return null;               /* ieri fatto o gia' coperto */
    if (!(g[prima] > 0 || g[prima] === -1)) return null;   /* non c'era una serie da salvare */
    return ieri;
  }catch(_){ return null; }
}
function gmNegozioHtml(){
  const riga = (typeof ngCardRiga === 'function') ? ngCardRiga : function(i, t, p, a){ return '<div class="ng-card"><span class="ng-card-i grande">' + i + '</span><div><b>' + t + '</b><p>' + p + '</p>' + (a || '') + '</div></div>'; };
  const btn = function(prezzo, az){ return '<button type="button" class="ng-az gm-az" onclick="' + az + '">' + GM_ICO + ' ' + prezzo + '</button>'; };
  const rip = gmSerieDaRiparare();
  return '<h2 class="ng-t">Con le gemme <span class="gm-ng-saldo">' + GM_ICO + ' <i data-gm-saldo>' + gmSaldo() + '</i></span></h2>'
    + '<p class="gm-ng-s">Comprano quello che le monete non comprano.</p>'
    + riga('🩹', 'Ripara la serie', rip ? 'Ieri hai saltato le tappe: la serie torna intera.' : 'Se salti un giorno, il giorno dopo la rimetti a posto.', rip ? btn(150, 'gmCompra(\'ripara\')') : '<small class="ng-attive">La serie è intera</small>')
    + (gmPremium() ? '' : riga('👑', 'Un giorno di Premium', 'Per 24 ore: niente annunci, l’agente, il percorso intero.', btn(250, 'gmCompra(\'premium\')')))
    + riga('🧪', 'Pozione XP tripli da 30 minuti', 'Il doppio del tempo della pozione a monete.', btn(40, 'gmCompra(\'pozione\')'))
    + riga('🎁', 'Scrigno d’oro', 'Monete, suoni e frasi che una sessione corta non dà.', btn(100, 'gmCompra(\'scrigno\')'));
}
function gmCompra(k){
  const rid = function(){ try{ if (typeof ngRidisegna === 'function') ngRidisegna(); }catch(_){ } };
  if (k === 'ripara'){
    const ieri = gmSerieDaRiparare(); if (!ieri) return;
    if (!gmSpendi(150, 'ripara la serie')) return;
    try{ const s = sdStato(); s.coperti = s.coperti || {}; s.coperti[ieri] = Date.now(); sdSalva(s); }catch(_){ }
    gmVibra([20, 40, 60]); if (typeof toast === 'function') toast('🩹 Serie riparata: ieri è coperto'); rid(); return;
  }
  if (k === 'premium'){
    if (!gmSpendi(250, 'un giorno di Premium')) return;
    try{ const cur = Date.parse(localStorage.getItem('fl_premium_until') || '') || 0; const da = Math.max(cur, Date.now()); localStorage.setItem('fl_premium_until', new Date(da + 86400000).toISOString()); if (typeof Premium !== 'undefined' && Premium._notify) Premium._notify(); }catch(_){ }
    gmVibra([20, 40, 60]); if (typeof toast === 'function') toast('👑 Premium attivo per 24 ore'); rid(); return;
  }
  if (k === 'pozione'){
    if (typeof sdBoostDai !== 'function' || !gmSpendi(40, 'pozione 30 minuti')) return;
    sdBoostDai(30, 3); gmVibra([20, 40, 60]); if (typeof toast === 'function') toast('Per 30 minuti ogni tappa vale il triplo'); rid(); return;
  }
  if (k === 'scrigno'){
    if (typeof scrApriPremio !== 'function' || !gmSpendi(100, 'scrigno d’oro')) return;
    scrApriPremio('oro', { titolo: 'Scrigno d’oro', onChiudi: rid }); return;
  }
}

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.gm-ico{display:inline-block;vertical-align:-.15em}',
    '.ng-gem{margin-right:14px;color:#8CC6FF}.ng-gem i{font-style:normal}',
    '.gm-pr,.wm{position:fixed;inset:0;z-index:9800;background:#001E44;color:#fff;opacity:0;transition:opacity .2s;overflow-y:auto}.gm-pr.in,.wm.in{opacity:1}.gm-pr[hidden],.wm[hidden]{display:none}',
    '.gm-pr-in,.wm-in{min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 22px) 24px calc(env(safe-area-inset-bottom,0px) + 26px)}',
    '.gm-pr-saldo{align-self:flex-end;display:flex;align-items:center;gap:8px;font:800 19px var(--font-display);color:#8CC6FF}.gm-pr-saldo .gm-ico,.gm-pr-saldo span{font-size:24px}',
    '.gm-pr-t{margin:56px 0 0;font:900 34px/1.1 var(--font-display);color:#8CC6FF}.gm-pr-t.mon{color:#FFC53D}',
    '.gm-pr-s{margin:14px 0 0;max-width:30ch;font:600 15px/1.45 var(--font-body);color:#C8EFFD}',
    '.gm-pr-art{flex:1;display:flex;align-items:center;justify-content:center;width:100%;min-height:200px}',
    '.gm-muc-m{position:relative;width:min(260px,70vw);aspect-ratio:1.4}.gm-muc-m span{position:absolute;transform:translate(-50%,-50%);font-size:64px;line-height:1;animation:gmCade .5s cubic-bezier(.3,1.4,.5,1) both;animation-delay:calc(var(--i) * 70ms);filter:drop-shadow(0 6px 10px rgba(0,0,0,.3))}',
    '.gm-mucchio{width:min(260px,70vw);height:auto}.gm-mucchio g{animation:gmCade .5s cubic-bezier(.3,1.4,.5,1) both;animation-delay:calc(var(--i) * 70ms)}',
    '@keyframes gmCade{from{opacity:0;transform:translateY(-40px)}}',
    '.gm-mucchio g{transform-box:fill-box}',
    '.gm-pr-bot,.wm-bot{width:100%;display:flex;flex-direction:column;align-items:center;gap:12px;margin-top:32px}',
    '.gm-pr-cta,.wm-cta{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:56px;border:0;border-radius:16px;background:#3F9FF4;color:#001E44;font:900 16px var(--font-body);letter-spacing:.02em;text-transform:uppercase;box-shadow:0 5px 0 #0075E3;cursor:pointer}',
    '.gm-pr-cta:active,.wm-cta:active{transform:translateY(4px);box-shadow:0 1px 0 #0075E3}',
    '.gm-pr-no,.wm-no{min-height:48px;border:0;background:none;color:#8CC6FF;font:900 15px var(--font-body);letter-spacing:.04em;text-transform:uppercase;cursor:pointer}',
    '.gm-pr-nota{font:600 12.5px var(--font-body);color:#C8EFFD}',
    '.wm-t{margin:18px 0 0;font:900 26px/1.2 var(--font-display);background:linear-gradient(90deg,#E63946,#3F9FF4);-webkit-background-clip:text;background-clip:text;color:transparent}',
    '.wm-scena{display:flex;justify-content:center;align-items:flex-end;gap:26px;width:100%;margin:30px 0 0;padding:26px 0 0;border-radius:22px;background:linear-gradient(180deg,rgba(63,159,244,.18),rgba(230,57,70,.12))}',
    '.wm-scena .wm-av,.wm-scena .am-av{width:96px!important;height:96px!important;font-size:38px!important;border-radius:50% 50% 18px 18px!important;margin-bottom:0}',
    '.wm-grande{font-size:84px;line-height:1;padding-bottom:18px}',
    '.wm-bar-w{display:flex;align-items:center;gap:12px;width:100%;margin:28px 0 0}',
    '.wm-bar{position:relative;flex:1;height:22px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}',
    '.wm-bar i{position:absolute;left:0;top:0;bottom:0;width:0;border-radius:99px;background:linear-gradient(90deg,#E63946,#3F9FF4);transition:width 1s cubic-bezier(.2,.8,.2,1) .25s}',
    '.wm.va .wm-bar i{width:var(--p)}',
    '.wm-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:800 13px var(--font-body);color:#fff}',
    '.wm-scr{width:46px;height:46px;object-fit:contain;flex:none}',
    '.wm-righe{width:100%;margin-top:24px;display:flex;flex-direction:column;gap:12px}',
    '.wm-righe > div{display:flex;align-items:center;gap:10px}.wm-righe b{flex:1;text-align:left;font:800 16px var(--font-body);color:#fff}.wm-righe small{font:600 15px var(--font-body);color:#C8EFFD}',
    '.wm-pt{width:10px;height:10px;border-radius:50%;background:#3F9FF4}.wm-pt.io{background:#E63946}',
    '.wm-hr{width:100%;border:0;border-top:1px solid rgba(255,255,255,.14);margin:24px 0}',
    '.wm-mese{display:flex;align-items:center;gap:12px;width:100%;text-align:left}.wm-mese > div{flex:1}.wm-mese b{display:block;font:800 16px var(--font-body);color:#fff}.wm-mese small{display:block;margin-top:4px;font:600 14px var(--font-body);color:#C8EFFD}.wm-mese-e{font-size:36px}',
    '.wm-sotto{margin:18px 0 0;font:600 15px var(--font-body);color:#C8EFFD}',
    '.wm-bot{margin-top:auto;padding-top:32px}',
    '.gm-ng-saldo{float:right;font:800 15px var(--font-body);color:#0075E3}body.dark .gm-ng-saldo{color:#8CC6FF}',
    '.gm-ng-s{margin:-6px 0 14px;font:500 13.5px var(--font-body);color:var(--muted)}',
    '.gm-az{display:inline-flex;align-items:center;gap:6px}',
    '.gm-poche{text-align:center}.gm-poche-e{display:block;font-size:52px;margin:6px 0 16px}.gm-poche-s{margin:10px 0 28px!important;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}'
  ].join('');
  document.head.appendChild(st);
})();
