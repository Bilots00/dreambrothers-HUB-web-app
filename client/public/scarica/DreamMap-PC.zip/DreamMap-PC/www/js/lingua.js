/* ===========================================================================================
   I TESTI NELLA LINGUA DI CHI LEGGE (22/11/2026, Andrea: "vogliamo togliere qualsiasi frizione:
   se l'utente e' giapponese, rispondere in giapponese, non in inglese")

   Nel codice ogni frase resta scritta in italiano, intera, con i segnaposto:
       T('Devi {euro} a {chi}', { euro: patEuro(x), chi: nome })
   Una frase intera, non pezzi incollati: l'ordine delle parole cambia da lingua a lingua.
   Dentro T() solo testo, {segnaposto} e al massimo <b> <i>; i tag con attributi restano fuori.

   tools/estrai-testi.mjs raccoglie tutte le T('...') in un pacco (content/testi-<pacco>.it.json, copiato
   sul server). Il server lo traduce una volta per lingua con Claude (dreammapTraduzioni.ts) e lo tiene;
   qui il pacco tradotto si scarica una volta e resta nel telefono. In italiano, o finche' il pacco non
   e' arrivato, T() mostra l'italiano.
   =========================================================================================== */
const LT = { testi: {}, firme: {}, attesi: {}, ridisegna: [] };
/** La chiave di una frase: la stessa funzione e' in tools/estrai-testi.mjs. */
function ltChiave(it){
  let h = 5381; const s = String(it);
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return 'k' + (h >>> 0).toString(36);
}
function ltLingua(){
  try{ return String((typeof flLocale === 'function') ? flLocale() : (navigator.language || 'it')); }catch(_){ return 'it'; }
}
function ltItaliano(){ return /^it\b/i.test(ltLingua()); }
function ltRiempi(s, v){
  return !v ? s : String(s).replace(/\{([a-zA-Z]+)\}/g, function(m, k){ return Object.prototype.hasOwnProperty.call(v, k) ? String(v[k]) : m; });
}
/** La frase nella lingua di chi legge, con i segnaposto riempiti. */
function T(it, v){
  let s = it;
  if (!ltItaliano()){
    const k = ltChiave(it);
    for (const p in LT.testi){ const t = LT.testi[p]; if (t && typeof t[k] === 'string'){ s = t[k]; break; } }
  }
  return ltRiempi(s, v);
}
/** Quando arriva una traduzione si ridisegna la pagina che la usa. */
function ltAlCambio(fn){ if (typeof fn === 'function') LT.ridisegna.push(fn); }
async function ltCarica(pacco){
  if (ltItaliano() || LT.attesi[pacco]) return LT.attesi[pacco];
  const l = ltLingua(), K = 'fl_testi_' + pacco + '_' + l;
  try{ const c = JSON.parse(localStorage.getItem(K) || 'null'); if (c && c.testi){ LT.testi[pacco] = c.testi; LT.firme[pacco] = c.firma; } }catch(_){ }
  LT.attesi[pacco] = (async function(){
    try{
      const base = (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app';
      const r = await fetch(base + '/api/focuslock/testi/' + encodeURIComponent(pacco) + '?lingua=' + encodeURIComponent(l));
      if (!r.ok) return;
      const j = await r.json();
      if (!j || !j.testi || j.firma === LT.firme[pacco]) return;
      LT.testi[pacco] = j.testi; LT.firme[pacco] = j.firma;
      try{ localStorage.setItem(K, JSON.stringify({ firma: j.firma, testi: j.testi })); }catch(_){ }
      LT.ridisegna.forEach(function(fn){ try{ fn(); }catch(_){ } });
    }catch(_){ /* senza rete resta l'ultima traduzione, o l'italiano */ }
  })();
  return LT.attesi[pacco];
}
/** I soldi scritti come li scrive chi legge: 5 €, €5, 5 €... */
function ltEuro(cent){
  const c = +cent || 0;
  try{ return new Intl.NumberFormat(ltLingua(), { style: 'currency', currency: 'EUR', minimumFractionDigits: c % 100 ? 2 : 0, maximumFractionDigits: 2 }).format(c / 100); }
  catch(_){ return (c / 100) + ' €'; }
}
/** Una data come la scrive chi legge. */
function ltData(ms, opz){
  try{ return new Date(ms).toLocaleDateString(ltLingua(), opz || { weekday: 'short', day: 'numeric', month: 'short' }); }
  catch(_){ return new Date(ms).toDateString(); }
}
setTimeout(function(){ ltCarica('patto'); }, 1500);
