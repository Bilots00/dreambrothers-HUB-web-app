/* ===========================================================================================
   CI E' RICASCATO (0.9.390, Andrea, BUG-123)

   Andrea: "Se risulta che un'app ha preso tante ore per 2 giorni di fila, o piu' volte nella stessa
   settimana, e l'utente aveva gia' provato a bloccarla, il Genio non deve riproporre la stessa risposta
   scriptata (Cosa cambi da domani? Blocco Instagram nelle ore di lavoro: avevo gia' provato). Deve
   comparire una schermata che gli dice: avevi detto che l'avresti fatto oggi. E dargli la possibilita' di
   attivare la modalita' severa, perche' il blocco non ha funzionato visto che ha modificato le regole di
   un programma. Altrimenti il blocco resta sempre negoziabile."

   Tre pezzi, ognuno in UNA funzione:
   - ricCaso(o): decide il caso "ci e' ricascato". Pura (niente telefono, niente memoria): la provano i
     test con giorni finti (tools/test-ricascato-390.js).
       SOGLIA: 2 ore in un giorno (RIC_SOGLIA_MIN = 120) su UNA app che distrae. Due ore su una sola app
       sono un pomeriggio di lavoro perso, e stanno sopra il tempo medio che passa una persona su tutti i
       social insieme: sotto, la schermata accuserebbe giornate normali. Una soglia fissa e non "rispetto
       alla tua media", perche' chi ci passa gia' 4 ore al giorno avrebbe una media che lo assolve sempre.
       QUANDO: 2 giorni di fila sopra soglia, oppure almeno 3 giorni sugli ultimi 7 (oggi compreso). In
       tutti e due i casi l'ultimo giorno sopra soglia e' oggi o ieri: una ricaduta di cinque giorni fa
       non e' la sera di oggi.
       E UN TENTATIVO DI BLOCCO PRIMA DELL'ULTIMA RICADUTA, negli ultimi 14 giorni: una revisione in cui
       ha scelto "Blocco X" o "Tolgo X dal telefono", un Rientra in rotta con "Blocco X", un programma su X
       spento, oppure X tolta da un programma, un programma su X spento o cancellato, orari o limiti
       allargati (il registro fl_blk_allentati, scritto da saveProgramsLocal in blocco.js).
   - ricCerca(d0, oggi): raccoglie i minuti per app degli ultimi 7 giorni (NATIVE.getTopApps, un giorno
     per volta, solo le app che distraggono: rvSoloDistr, la stessa scelta della revisione) e i tentativi,
     e chiama ricCaso.
   - ricPosterApri(caso): la schermata. Grafica nostra, solo tipografia: grande testo scuro su fondo
     chiaro, come un cartellone. Sotto, in piccolo, il fatto vero, e la proposta: la modalita' severa che
     c'e' gia' (severe.js, StrictMode.java), per 3 o 7 giorni, con l'uscita onesta e lenta del metodo
     Pausa: chiedi di uscire e aspetti 24 ore (il massimo che il motore accetta). Nessun codice Java nuovo:
     il motore gia' scade da solo a strictUntil (StrictMode.levelAt) con qualunque metodo.
   =========================================================================================== */
const RIC_SOGLIA_MIN = 120;
const RIC_FINESTRA = 7;
const RIC_VOLTE = 3;
const RIC_TENT_GIORNI = 14;
const RIC_ATTESA_MIN = 1440;
const RIC_GIORNI = [3, 7];
const RIC_LOG_K = 'fl_blk_allentati';
const RIC_GIORNI_SETT = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
const RIC_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const RIC = { caso: null, giorni: 3, fatta: null, occupato: false };

/* ---------- i giorni come 'AAAA-MM-GG' ---------- */
function ricKey(d){ return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
function ricData(g){ const p = String(g || '').split('-'); return new Date(+p[0], (+p[1] || 1) - 1, +p[2] || 1, 12, 0, 0, 0); }
function ricPiu(g, n){ const d = ricData(g); d.setDate(d.getDate() + n); return ricKey(d); }
function ricNorm(s){ return String(s || '').trim().toLowerCase(); }

/**
 * IL CASO. o = {
 *   oggi: 'AAAA-MM-GG' (il giorno della revisione),
 *   giorni: [{ g: 'AAAA-MM-GG', app: { pkg: minuti } }]   (in qualunque ordine; quelli fuori dagli ultimi 7 non contano),
 *   nomi: { pkg: 'Instagram' },
 *   tentativi: [{ pkg, nome, g: 'AAAA-MM-GG' o '' se non si sa quando, tipo: 'revisione'|'rientro'|'sospeso'|'allentato', cosa }]
 * }
 * Torna null, oppure { pkg, nome, sopra: [{ g, min }] dal piu' vecchio, fila, volte, oggiMin, ieriMin, tentativo }.
 */
function ricCaso(o){
  o = o || {};
  const oggi = o.oggi; if (!oggi) return null;
  const ieri = ricPiu(oggi, -1), primo = ricPiu(oggi, -(RIC_FINESTRA - 1)), limiteTent = ricPiu(oggi, -RIC_TENT_GIORNI);
  const perPkg = {};
  (o.giorni || []).forEach(function(d){
    if (!d || !d.g || d.g < primo || d.g > oggi) return;
    Object.keys(d.app || {}).forEach(function(pkg){
      const m = +d.app[pkg] || 0;
      (perPkg[pkg] = perPkg[pkg] || {})[d.g] = Math.max(m, (perPkg[pkg][d.g] || 0));
    });
  });
  const nomi = o.nomi || {};
  let meglio = null;
  Object.keys(perPkg).forEach(function(pkg){
    const giorni = perPkg[pkg];
    const sopra = Object.keys(giorni).filter(function(g){ return giorni[g] >= RIC_SOGLIA_MIN; }).sort();
    if (!sopra.length) return;
    const ultimo = sopra[sopra.length - 1];
    if (ultimo !== oggi && ultimo !== ieri) return;
    const fila = sopra.some(function(g, i){ return i > 0 && ricPiu(sopra[i - 1], 1) === g && g >= ieri; });
    if (!fila && sopra.length < RIC_VOLTE) return;
    const nome = nomi[pkg] || pkg;
    const tent = (o.tentativi || []).filter(function(t){
      if (!t) return false;
      const stessa = (t.pkg && t.pkg === pkg) || (t.nome && ricNorm(t.nome) === ricNorm(nome));
      if (!stessa) return false;
      if (!t.g) return true;                         // un programma spento oggi: non si sa da quando, ma c'era prima
      return t.g >= limiteTent && t.g < ultimo;     // prima dell'ultima ricaduta, negli ultimi 14 giorni
    }).sort(function(a, b){ return String(b.g || '').localeCompare(String(a.g || '')); });
    if (!tent.length) return;
    const tot = sopra.reduce(function(s, g){ return s + giorni[g]; }, 0);
    const c = { pkg: pkg, nome: nome, sopra: sopra.map(function(g){ return { g: g, min: giorni[g] }; }), fila: fila, volte: sopra.length,
      oggiMin: giorni[oggi] || 0, ieriMin: giorni[ieri] || 0, tentativo: tent[0], oggi: oggi, tot: tot };
    if (!meglio || tot > meglio.tot) meglio = c;
  });
  return meglio;
}

/* ---------- le parole ---------- */
/** 'Oggi', 'Ieri', 'Venerdì' (fino a 6 giorni fa), altrimenti 'Il 12 novembre'. */
function ricQuando(g, oggi){
  if (!g) return '';
  if (g === oggi) return 'Oggi';
  if (g === ricPiu(oggi, -1)) return 'Ieri';
  const d = ricData(g);
  if (g >= ricPiu(oggi, -6)) return RIC_GIORNI_SETT[d.getDay()];
  return 'Il ' + d.getDate() + ' ' + RIC_MESI[d.getMonth()];
}
/** '3 ore e 10', '2 ore', '45 minuti': il tempo come si dice a voce. */
function ricOre(min){
  min = Math.round(min || 0);
  if (min < 60) return min + (min === 1 ? ' minuto' : ' minuti');
  const h = Math.floor(min / 60), m = min % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (m ? ' e ' + m : '');
}
function ricMinuscola(s){ return s ? s.charAt(0).toLowerCase() + s.slice(1) : s; }
/** La frase del tentativo: "Venerdì hai scelto di bloccare Instagram." */
function ricTentFrase(c){
  const t = c.tentativo || {}, q = ricQuando(t.g, c.oggi), n = c.nome;
  if (t.tipo === 'allentato'){
    const cosa = { tolta: 'hai tolto ' + n + ' da un blocco', spento: 'hai spento il blocco su ' + n, cancellato: 'hai cancellato il blocco su ' + n, orari: 'hai allargato il blocco su ' + n }[t.cosa] || 'hai allentato il blocco su ' + n;
    return (q ? q + ' ' : '') + cosa + '.';
  }
  if (t.tipo === 'sospeso') return 'Il tuo blocco su ' + n + ' è spento.';
  const scelta = t.cosa === 'elimina' ? 'di togliere ' + n + ' dal telefono' : 'di bloccare ' + n;
  return (q ? q + ' hai scelto ' : 'Avevi scelto ') + scelta + '.';
}
/** La frase dei numeri: "Ieri 3 ore e 10, oggi 2 ore e 40." oppure, con 3 giorni nella settimana, gli ultimi due e il conto. */
function ricNumeriFrase(c){
  const ult = c.sopra.slice(-2);
  const pezzi = ult.map(function(x, i){ const q = ricQuando(x.g, c.oggi); return (i ? ricMinuscola(q) : q) + ' ' + ricOre(x.min); });
  let s = pezzi.join(', ') + '.';
  if (c.volte >= RIC_VOLTE) s += ' In una settimana, ' + c.volte + ' giorni sopra le 2 ore.';
  return s;
}
/* 0.9.390, Andrea: "Ieri hai detto domani non si usa: in italiano nessuno lo dice, e' una traduzione letterale. Scrivi come parla un
   italiano: Ieri avevi detto: lo faccio domani." Il giorno e' quello vero del tentativo (Ieri, Venerdi', Il 12 novembre); se non si sa
   (un blocco spento), senza giorno. Dopo i due punti si va a capo. */
function ricTitolo(c){
  const t = (c && c.tentativo) || {}, q = ricQuando(t.g, c && c.oggi);
  return (q ? q + ' avevi detto' : 'Avevi detto') + ':\nlo faccio domani.';
}

/* ---------- i tentativi di blocco, dalla memoria dell'app ---------- */
function ricLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
/** "Blocco Instagram nelle ore di lavoro", "Tolgo Instagram dal telefono", "Blocco X nelle ore in cui lavoro" (Rientra in rotta). */
function ricDaTesto(t){
  const s = String(t || '').trim();
  let m = s.match(/^Blocco\s+(.+?)\s+nelle ore\b/i); if (m) return { nome: m[1], cosa: 'blocca' };
  m = s.match(/^Tolgo\s+(.+?)\s+dal telefono\b/i); if (m) return { nome: m[1], cosa: 'elimina' };
  return null;
}
function ricTentativi(){
  const out = [];
  const gAt = function(at){ return at ? ricKey(new Date(at)) : ''; };
  ricLeggi('fl_revisioni', []).forEach(function(x){
    if (!x) return;
    const d = ricDaTesto(x.contromisura);
    if (x.contromisuraPkg || d) out.push({ pkg: x.contromisuraPkg || '', nome: (d && d.nome) || '', g: x.giorno || gAt(x.at), tipo: 'revisione', cosa: x.contromisuraK === 'elimina' || (d && d.cosa === 'elimina') ? 'elimina' : 'blocca' });
  });
  ricLeggi('fl_rientri', []).forEach(function(x){
    const d = x && ricDaTesto(x.contromisura || x.rimedio);
    if (d) out.push({ pkg: x.app || '', nome: x.appNome || d.nome, g: gAt(x.at), tipo: 'rientro', cosa: d.cosa });
  });
  ricLeggi(RIC_LOG_K, []).forEach(function(x){ if (x && x.pkg) out.push({ pkg: x.pkg, nome: '', g: gAt(x.at), tipo: 'allentato', cosa: x.cosa }); });
  const progs = (typeof PROGRAMS !== 'undefined' && Array.isArray(PROGRAMS)) ? PROGRAMS : ricLeggi('fl_programs', []);
  (progs || []).forEach(function(p){ if (p && p.on === false) (p.apps || []).forEach(function(pkg){ out.push({ pkg: pkg, nome: '', g: '', tipo: 'sospeso' }); }); });
  return out;
}

/* ---------- il registro delle regole allentate (lo scrive saveProgramsLocal, blocco.js) ---------- */
function ricDurata(p){
  if (!p || p.allDay || p.type === 'sempre') return 1440;
  const m = function(s){ const x = String(s || '00:00').split(':'); return (+x[0] || 0) * 60 + (+x[1] || 0); };
  const a = m(p.from), b = m(p.to);
  return b > a ? b - a : (b === a ? 1440 : 1440 - a + b);
}
/** Pura: cosa e' stato allentato fra due elenchi di programmi. [{ pkg, cosa: 'tolta'|'spento'|'cancellato'|'orari' }] */
function ricAllentati(prima, dopo){
  const out = [], perId = {};
  (dopo || []).forEach(function(p){ if (p && p.id) perId[p.id] = p; });
  (prima || []).forEach(function(a){
    if (!a || !a.id || a.grey || a.sound || a.on === false) return;
    const apps = (a.apps || []).filter(Boolean);
    if (!apps.length) return;
    const b = perId[a.id];
    if (!b){ apps.forEach(function(pkg){ out.push({ pkg: pkg, cosa: 'cancellato' }); }); return; }
    if (b.on === false){ apps.forEach(function(pkg){ out.push({ pkg: pkg, cosa: 'spento' }); }); return; }
    const rimaste = b.apps || [];
    apps.forEach(function(pkg){ if (rimaste.indexOf(pkg) < 0) out.push({ pkg: pkg, cosa: 'tolta' }); });
    const giorniVia = (a.days || []).some(function(v, i){ return v && b.days && b.days[i] === false; });
    const quota = function(p){ return +p.qd || +p.qh || 0; };
    const largo = giorniVia || ricDurata(b) < ricDurata(a) || (quota(b) > quota(a) && quota(a) > 0) || (!quota(a) && quota(b) > 0);
    if (largo) apps.forEach(function(pkg){ if (rimaste.indexOf(pkg) >= 0) out.push({ pkg: pkg, cosa: 'orari' }); });
  });
  return out;
}
/** Chiamata da saveProgramsLocal prima di scrivere: confronta con la copia di prima e annota quello che si e' allentato (30 giorni). */
function ricRegistraAllentati(primaJson, dopo){
  let prima = []; try{ prima = JSON.parse(primaJson || '[]') || []; }catch(_){ prima = []; }
  const nuovi = ricAllentati(prima, dopo); if (!nuovi.length) return;
  const ora = Date.now(), limite = ora - 30 * 86400000;
  const l = ricLeggi(RIC_LOG_K, []).filter(function(x){ return x && x.at >= limite; });
  nuovi.forEach(function(x){ l.push({ at: ora, pkg: x.pkg, cosa: x.cosa }); });
  try{ localStorage.setItem(RIC_LOG_K, JSON.stringify(l.slice(-200))); }catch(_){ }
}

/* ---------- i minuti degli ultimi 7 giorni, dal telefono ---------- */
async function ricCerca(d0, oggi){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return null;
  const base = new Date(d0.getTime()), ora = Date.now(), nomi = {};
  const giri = [];
  for (let i = 0; i < RIC_FINESTRA; i++){
    const da = new Date(base.getTime()); da.setDate(da.getDate() - i);
    const a = new Date(da.getTime()); a.setDate(a.getDate() + 1);
    giri.push(Promise.resolve(NATIVE.getTopApps({ from: da.getTime(), to: Math.min(ora, a.getTime()), limit: 40, icons: 0 })).then(function(r){
      const app = {};
      const lista = (typeof rvSoloDistr === 'function') ? rvSoloDistr((r && r.apps) || []) : [];
      lista.forEach(function(x){ app[x.pkg] = (app[x.pkg] || 0) + x.min; nomi[x.pkg] = x.nome; });
      return { g: i === 0 ? oggi : ricPiu(oggi, -i), app: app };
    }, function(){ return null; }));
  }
  const giorni = (await Promise.all(giri)).filter(Boolean);
  return ricCaso({ oggi: oggi, giorni: giorni, nomi: nomi, tentativi: ricTentativi() });
}

/* ---------- la schermata ---------- */
function ricEsc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); }
function ricBr(s){ return ricEsc(s).replace(/\n/g, '<br>'); }
/** La data di fine, detta per esteso: "sabato 28 novembre alle 21:40". */
function ricFine(at){
  const d = new Date(at);
  return RIC_GIORNI_SETT[d.getDay()].toLowerCase() + ' ' + d.getDate() + ' ' + RIC_MESI[d.getMonth()] + ' alle ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
}
function ricSeveraAccesa(){ try{ return typeof sevState !== 'undefined' && !!sevState && (sevState.level || 0) >= 1; }catch(_){ return false; } }
/** L'HTML della schermata. Funzione pura dello stato: la provano i test. */
function ricPosterHtml(c, giorni, fatta, accesa){
  const X = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  if (fatta){
    return '<div class="ric-in">'
      + '<h1 class="ric-h">Fatto.</h1>'
      + '<p class="ric-fatto">Fino a ' + ricEsc(ricFine(fatta.fino)) + ' i tuoi blocchi restano come sono, anche quello su ' + ricEsc(c.nome) + '.</p>'
      + '<p class="ric-riga">Se proprio devi uscire prima:<br>lo chiedi dalla pagina della modalità severa e aspetti 24 ore.</p>'
      + '<div class="ric-azioni"><button type="button" class="ric-cta" onclick="ricContinua()">Continua</button></div>'
      + '</div>';
  }
  return '<div class="ric-in">'
    + '<button type="button" class="ric-x" aria-label="Chiudi" onclick="ricAltro()">' + X + '</button>'
    + '<h1 class="ric-h">' + ricBr(ricTitolo(c)) + '</h1>'
    + '<p class="ric-fatto">' + ricEsc(ricTentFrase(c)) + '<br>' + ricEsc(ricNumeriFrase(c)) + '</p>'
    + '<div class="ric-proposta">'
    +   '<p class="ric-riga">' + (accesa
          ? 'La modalità severa è già accesa. Allungala di ' + giorni + ' giorni. Per tutto quel tempo nessun blocco si allenta, nemmeno quello su ' + ricEsc(c.nome) + '.'
          : 'Per ' + giorni + ' giorni non potrai togliere né allentare i tuoi blocchi, nemmeno quello su ' + ricEsc(c.nome) + '.') + '</p>'
    +   '<div class="ric-giorni" role="group" aria-label="Per quanti giorni">' + RIC_GIORNI.map(function(n){
          return '<button type="button" class="ric-g' + (n === giorni ? ' on' : '') + '" aria-pressed="' + (n === giorni) + '" onclick="ricGiorni(' + n + ')">' + n + ' giorni</button>';
        }).join('') + '</div>'
    +   '<div class="ric-azioni"><button type="button" class="ric-cta" onclick="ricAttiva()"' + (RIC.occupato ? ' disabled' : '') + '>' + (accesa ? 'Allunga la modalità severa' : 'Attiva la modalità severa') + '</button>'
    +   '<button type="button" class="ric-alt" onclick="ricAltro()">Scelgo un altro cambiamento</button></div>'
    +   (accesa ? '' : '<p class="ric-nota">Se proprio devi uscire prima, lo chiedi e aspetti 24 ore.</p>')
    + '</div></div>';
}
function ricPosterApri(c){
  if (!c) return;
  RIC.caso = c; RIC.fatta = null; RIC.occupato = false;
  ricPosterPaint();
}
function ricPosterPaint(){
  if (typeof document === 'undefined' || !RIC.caso) return;
  let w = document.getElementById('ricPoster');
  if (!w){
    w = document.createElement('div'); w.id = 'ricPoster'; w.className = 'ric-poster'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true');
    (document.getElementById('phone') || document.body).appendChild(w);
  }
  w.innerHTML = ricPosterHtml(RIC.caso, RIC.giorni, RIC.fatta, ricSeveraAccesa());
}
function ricPosterChiudi(){ if (typeof document === 'undefined') return; const w = document.getElementById('ricPoster'); if (w) w.remove(); }
function ricGiorni(n){ RIC.giorni = RIC_GIORNI.indexOf(n) >= 0 ? n : 3; ricPosterPaint(); }
/* l'alternativa: la domanda della sera, ma senza la risposta che ha gia' fallito (rvEntra, passo 'sistema') */
function ricAltro(){ ricPosterChiudi(); if (typeof rvVai === 'function') rvVai('sistema'); }
function ricContinua(){ ricPosterChiudi(); if (typeof rvVai === 'function') rvVai('imprevisto'); }

/** Il blocco sull'app, se non c'e' piu': senza, la modalita' severa chiuderebbe a chiave un elenco in cui l'app non e'. */
async function ricBloccoSullApp(c){
  const progs = (typeof PROGRAMS !== 'undefined' && Array.isArray(PROGRAMS)) ? PROGRAMS : [];
  if (progs.some(function(p){ return p && p.on !== false && (p.apps || []).indexOf(c.pkg) >= 0; })) return 'c-era';
  if (typeof frBlindaProgramma !== 'function') return false;
  try{ return await frBlindaProgramma({ pkg: c.pkg, nome: c.nome }); }catch(_){ return false; }
}
/**
 * Arma la modalita' severa che c'e' gia' (sevArm, severe.js) per `giorni` giorni, con il metodo Pausa a 24 ore.
 * La bozza dell'utente (il metodo scelto nella pagina della modalita' severa) torna com'era: questa e' una sessione a parte.
 * Torna { fino } oppure null se il motore non l'ha accesa.
 */
async function ricSeveraArma(giorni){
  const min = giorni * 1440;
  if (ricSeveraAccesa() && typeof sevProlungaMin === 'function'){
    await sevProlungaMin(min);
    return ricSeveraAccesa() ? { fino: +(sevState && sevState.strictUntil) || (Date.now() + min * 60000) } : null;
  }
  if (typeof sevArm !== 'function' || typeof sevFreshDraft !== 'function') return null;
  let admin = false; try{ admin = typeof sevAdminAttivo === 'function' && await sevAdminAttivo(); }catch(_){ admin = false; }
  const prima = sevDraft; let primaSalvata = null; try{ primaSalvata = localStorage.getItem(SEV_DRAFT_KEY); }catch(_){ }
  const d = sevFreshDraft(1);
  d.method = SEV_M.PAUSE; d.pauseMinutes = RIC_ATTESA_MIN; d.timerMin = min; d.opts.uninstall = !!admin;
  sevDraft = d;
  try{ await sevArm({ resta: true }); }
  finally{
    sevDraft = prima;
    try{ if (primaSalvata == null) localStorage.removeItem(SEV_DRAFT_KEY); else localStorage.setItem(SEV_DRAFT_KEY, primaSalvata); }catch(_){ }
  }
  return ricSeveraAccesa() ? { fino: +(sevState && sevState.strictUntil) || (Date.now() + min * 60000) } : null;
}
async function ricAttiva(){
  const c = RIC.caso; if (!c || RIC.occupato) return;
  RIC.occupato = true; ricPosterPaint();
  let r = null;
  try{
    await ricBloccoSullApp(c);
    r = await ricSeveraArma(RIC.giorni);
  }catch(_){ r = null; }
  RIC.occupato = false;
  if (!r){ ricPosterPaint(); if (typeof toast === 'function') toast('La modalità severa non si è accesa:\nriprova'); return; }
  RIC.fatta = r;
  try{
    if (typeof RV !== 'undefined'){ RV.r.sistema = 'severa'; RV.r.sistemaTesto = 'Modalità severa per ' + RIC.giorni + ' giorni sui blocchi di ' + c.nome; RV.r.sistemaPkg = c.pkg; }
  }catch(_){ }
  ricPosterPaint();
  try{ if (typeof flVibra === 'function') flVibra([20, 40, 30]); }catch(_){ }
}

(function ricStile(){
  if (typeof document === 'undefined' || !document.head) return;
  const st = document.createElement('style');
  /* il cartellone: carta chiara, inchiostro scuro, una sola grande frase. Colori fissi anche col tema scuro: e' un manifesto */
  st.textContent = '.ric-poster{position:absolute;inset:0;z-index:99985;background:#F3EFE6;color:#101418;display:flex;overflow-y:auto}'
    + '.ric-in{position:relative;display:flex;flex-direction:column;justify-content:flex-end;min-height:100%;width:100%;box-sizing:border-box;padding:72px 24px calc(26px + env(safe-area-inset-bottom,0px))}'
    + '.ric-x{position:absolute;top:18px;right:16px;width:42px;height:42px;border:0;border-radius:50%;background:rgba(16,20,24,.07);color:#101418;display:grid;place-items:center;cursor:pointer}'
    + '.ric-h{margin:0 0 22px;text-align:left;font:900 46px/1.02 var(--font-display);font-style:normal;letter-spacing:-.02em;color:#101418}'
    + '.ric-fatto{margin:0 0 28px;font:600 15.5px/1.55 var(--font-body);color:#3B4148}'
    + '.ric-proposta{border-top:2px solid #101418;padding-top:18px}'
    + '.ric-riga{margin:0 0 14px;font:600 14.5px/1.5 var(--font-body);color:#101418}'
    + '.ric-giorni{display:flex;gap:8px;margin:0 0 16px}'
    + '.ric-g{flex:1;padding:11px 8px;border:2px solid #101418;border-radius:12px;background:transparent;color:#101418;font:800 14px var(--font-body);cursor:pointer}'
    + '.ric-g.on{background:#101418;color:#F3EFE6}'
    + '.ric-azioni{display:flex;flex-direction:column;gap:6px}'
    + '.ric-cta{width:100%;padding:17px 16px;border:0;border-radius:14px;background:#101418;color:#F3EFE6;font:800 16px var(--font-body);cursor:pointer}'
    + '.ric-cta[disabled]{opacity:.55}'
    + '.ric-alt{padding:12px;border:0;background:none;color:#101418;font:700 14.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}'
    + '.ric-nota{margin:6px 0 0;text-align:center;font:500 12.5px/1.5 var(--font-body);color:#5B6168}';
  document.head.appendChild(st);
})();
