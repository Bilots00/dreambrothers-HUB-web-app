# DreamMap per PC - installa o aggiorna, su questo computer o su un altro.
#
# E' L'UNICO MODO DI METTERE DREAMMAP SU UN PC, anche per aggiornare quello di Andrea.
# Niente piu' "copio FocusLock.dll a mano": e' cosi' che il 26/11/2026 il PC e' rimasto con la
# libreria WebView2.WinForms vecchia accanto a un DreamMap compilato per quella nuova, e il
# pannello non si apriva piu' (BUG-178). Qui la cartella app si sostituisce TUTTA, e prima di
# toccare niente si controlla che il pacchetto abbia ogni pezzo elencato nel deps.json.
#
# Cosa fa, in ordine:
#   1. controlla il pacchetto (ogni libreria del deps.json c'e', nella versione giusta);
#   2. controlla .NET 8 Desktop Runtime e WebView2; se mancano li scarica da Microsoft;
#   3. ferma DreamMap (e il vecchio FocusLock), mette da parte la cartella app com'era
#      (app.bak-AAAAMMGG-HHMM) e copia quella nuova;
#   4. la pagina del telefono (www) solo se quella del pacchetto e' piu' recente;
#      le regole solo se qui non ce ne sono: i dati dell'utente non si toccano mai;
#   5. avvio automatico "DreamMap AutoStart" (al posto di "FocusLock AutoStart"), la voce
#      DreamMap nel menu Start, e in Win+R sia "dream" sia "focus";
#   6. avvia DreamMap e controlla che resti acceso; se non parte, rimette la versione di prima.
#
# Le cartelle dei dati restano C:\ProgramData\FocusLock e %LOCALAPPDATA%\FocusLock: non si
# vedono, e ci scrivono anche altri strumenti (la pagina del telefono, l'accesso Google).
#
#   -SoloControllo   controlla il pacchetto e basta (lo usa costruisci.ps1)
#   -Prova           fa tutto tranne fermare e avviare il programma
param(
  [string]$dest = 'C:\ProgramData\FocusLock',
  [switch]$SoloControllo,
  [switch]$Prova
)
$ErrorActionPreference = 'Stop'
$qui      = Split-Path -Parent $MyInvocation.MyCommand.Path
$pacchetto = Join-Path $qui 'app'
$exeNome  = 'DreamMap.exe'
$exe      = Join-Path $dest "app\$exeNome"
$nomeTask = 'DreamMap AutoStart'
$vecchioTask = 'FocusLock AutoStart'

function Passo($t){ Write-Host ''; Write-Host ('>> ' + $t) -ForegroundColor Cyan }

# ---------- i pezzi del pacchetto ----------
# Stessa regola di Dipendenze.cs nel programma: ogni file "runtime" e "native" del deps.json
# deve esserci, e un assembly non puo' essere piu' vecchio della versione scritta li'.
function Controlla-Pacchetto([string]$cartella) {
  $problemi = @()
  $deps = Get-ChildItem -Path $cartella -Filter '*.deps.json' -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $deps) { return @("manca il file deps.json in $cartella") }
  $j = Get-Content $deps.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach ($target in $j.targets.PSObject.Properties) {
    foreach ($lib in $target.Value.PSObject.Properties) {
      foreach ($tipo in @('runtime', 'native')) {
        $files = $lib.Value.$tipo
        if (-not $files) { continue }
        foreach ($f in $files.PSObject.Properties) {
          $p = Join-Path $cartella $f.Name
          if (-not (Test-Path $p)) { $problemi += "manca $($f.Name)"; continue }
          $voluta = $f.Value.assemblyVersion
          if ($tipo -eq 'runtime' -and $voluta) {
            try {
              $trovata = [Reflection.AssemblyName]::GetAssemblyName($p).Version
              if ($trovata -lt [Version]$voluta) { $problemi += "$($f.Name): c'e' la $trovata, serve la $voluta" }
            } catch { $problemi += "$($f.Name): non leggibile" }
          }
        }
      }
    }
  }
  if (-not (Test-Path (Join-Path $cartella 'WebView2Loader.dll')) -and
      -not (Test-Path (Join-Path $cartella 'runtimes\win-x64\native\WebView2Loader.dll'))) {
    $problemi += 'manca WebView2Loader.dll'
  }
  if (-not (Test-Path (Join-Path $cartella $exeNome))) { $problemi += "manca $exeNome" }
  return $problemi
}

Passo 'Controllo il pacchetto'
$problemi = @(Controlla-Pacchetto $pacchetto)
if ($problemi.Count -gt 0) {
  $problemi | ForEach-Object { Write-Host ('   ' + $_) -ForegroundColor Red }
  throw 'Il pacchetto di DreamMap e'' incompleto: non installo niente. Scarica di nuovo DreamMap-PC.zip.'
}
Write-Host 'OK: ci sono tutti i pezzi'
if ($SoloControllo) { return }

# ---------- i due componenti di Microsoft ----------
Passo 'Controllo .NET 8 Desktop Runtime'
# Dove lo cerca DreamMap.exe: DOTNET_ROOT, la cartella registrata, Programmi\dotnet.
$radici = @($env:DOTNET_ROOT, (Join-Path $env:ProgramFiles 'dotnet'))
try { $radici += (Get-ItemProperty 'HKLM:\SOFTWARE\dotnet\Setup\InstalledVersions\x64' -ErrorAction Stop).InstallLocation } catch {}
function Trova-Net8 { $radici | Where-Object { $_ } | ForEach-Object {
    Get-ChildItem (Join-Path $_ 'shared\Microsoft.WindowsDesktop.App') -Directory -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -like '8.*' } } }
if (-not (Trova-Net8)) {
  Write-Host 'Manca: lo scarico da Microsoft e lo installo (qualche minuto)...'
  $tmp = Join-Path $env:TEMP 'windowsdesktop-runtime-8-x64.exe'
  Invoke-WebRequest 'https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe' -OutFile $tmp -UseBasicParsing
  Start-Process $tmp -ArgumentList '/install','/quiet','/norestart' -Wait
  Remove-Item $tmp -ErrorAction SilentlyContinue
  if (-not (Trova-Net8)) { throw '.NET 8 Desktop Runtime non si e'' installato. Installalo a mano da https://dotnet.microsoft.com/download/dotnet/8.0 (Windows Desktop Runtime x64) e rilancia.' }
}
Write-Host 'OK'

Passo 'Controllo WebView2'
$wv = @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}') |
      Where-Object { Test-Path $_ }
if (-not $wv) {
  Write-Host 'Manca: lo scarico da Microsoft e lo installo...'
  $tmp = Join-Path $env:TEMP 'MicrosoftEdgeWebview2Setup.exe'
  Invoke-WebRequest 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $tmp -UseBasicParsing
  Start-Process $tmp -ArgumentList '/silent','/install' -Wait
  Remove-Item $tmp -ErrorAction SilentlyContinue
}
Write-Host 'OK'

# ---------- l'app ----------
Passo 'Fermo DreamMap'
function Ferma-DreamMap {
  foreach ($t in @($nomeTask, $vecchioTask)) {
    try { Stop-ScheduledTask -TaskName $t -ErrorAction Stop } catch {}
  }
  Get-Process -Name 'DreamMap','FocusLock' -ErrorAction SilentlyContinue |
    Where-Object { -not $_.Path -or $_.Path -like "$dest\app\*" } |
    Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
}
if (-not $Prova) { Ferma-DreamMap }
Write-Host 'OK'

Passo "Copio DreamMap in $dest\app"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$appDir = Join-Path $dest 'app'
$backup = $null
if (Test-Path $appDir) {
  # La versione di prima resta intera accanto: e' quella che si rimette se la nuova non parte.
  $backup = Join-Path $dest ('app.bak-' + (Get-Date -Format 'yyyyMMdd-HHmm'))
  if (Test-Path $backup) { $backup += '-' + (Get-Random -Maximum 999) }
  Move-Item -LiteralPath $appDir -Destination $backup
  Write-Host "La versione di prima e' in $backup"
}
Copy-Item -LiteralPath $pacchetto -Destination $appDir -Recurse -Force
$problemi = @(Controlla-Pacchetto $appDir)
if ($problemi.Count -gt 0) {
  Remove-Item -LiteralPath $appDir -Recurse -Force
  if ($backup) { Move-Item -LiteralPath $backup -Destination $appDir }
  throw ('La copia non e'' riuscita (' + ($problemi -join '; ') + '): ho rimesso la versione di prima.')
}
Write-Host 'OK'

Passo 'Pagina del telefono e regole'
$wwwPacchetto = Join-Path $qui 'www'
$wwwDest = Join-Path $dest 'www'
if (Test-Path (Join-Path $wwwPacchetto 'index.html')) {
  $nuovo = (Get-Item (Join-Path $wwwPacchetto 'index.html')).LastWriteTime
  $vecchio = if (Test-Path (Join-Path $wwwDest 'index.html')) { (Get-Item (Join-Path $wwwDest 'index.html')).LastWriteTime } else { [DateTime]::MinValue }
  if ($nuovo -gt $vecchio) {
    if (Test-Path $wwwDest) { Move-Item -LiteralPath $wwwDest -Destination ($wwwDest + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmm')) }
    Copy-Item -LiteralPath $wwwPacchetto -Destination $wwwDest -Recurse -Force
    Write-Host 'Pagina del telefono aggiornata.'
  } else {
    Write-Host 'La pagina del telefono qui e'' gia'' la stessa o piu'' nuova: la lascio.'
  }
}
if (Test-Path (Join-Path $dest 'rules.json')) {
  Write-Host 'Qui ci sono gia'' delle regole: le lascio come sono.'
} elseif (Test-Path (Join-Path $qui 'rules.json')) {
  Copy-Item (Join-Path $qui 'rules.json') $dest -Force
  Write-Host 'Messe le regole del pacchetto.'
} else {
  Write-Host 'Nessuna regola: DreamMap parte con quelle di esempio, spente.'
}

# ---------- avvio automatico, menu Start, Win+R ----------
Passo 'Avvio automatico a ogni accesso'
$utente  = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
function Registra-Task([string]$percorsoExe) {
  $azione  = New-ScheduledTaskAction -Execute $percorsoExe -WorkingDirectory (Split-Path $percorsoExe)
  $innesco = New-ScheduledTaskTrigger -AtLogOn -User $utente
  $innesco.Delay = 'PT15S'
  $chi     = New-ScheduledTaskPrincipal -UserId $utente -LogonType Interactive -RunLevel Limited
  $regole  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
               -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
  Register-ScheduledTask -TaskName $nomeTask -Action $azione -Trigger $innesco -Principal $chi -Settings $regole `
    -Description 'Avvia DreamMap in background a ogni accesso, cosi i blocchi sono sempre attivi.' -Force | Out-Null
}
Registra-Task $exe
if (Get-ScheduledTask -TaskName $vecchioTask -ErrorAction SilentlyContinue) {
  Unregister-ScheduledTask -TaskName $vecchioTask -Confirm:$false
  Write-Host "Tolto il vecchio '$vecchioTask'."
}
Write-Host 'OK'

Passo 'Menu Start e Win+R'
$programmi = [Environment]::GetFolderPath('Programs')
$sh = New-Object -ComObject WScript.Shell
$lnk = $sh.CreateShortcut((Join-Path $programmi 'DreamMap.lnk'))
$lnk.TargetPath = $exe
$lnk.WorkingDirectory = Split-Path $exe
$lnk.Description = 'DreamMap'
$lnk.Save()
$vecchioLnk = Join-Path $programmi 'FocusLock.lnk'
if (Test-Path $vecchioLnk) { Remove-Item $vecchioLnk -Force }
# Collegamenti fatti a mano (Desktop, barra delle applicazioni) al vecchio FocusLock.exe:
# puntati al nuovo exe e rinominati, altrimenti diventano icone morte.
$posti = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
           (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'))
foreach ($posto in $posti) {
  Get-ChildItem $posto -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
    try {
      $l = $sh.CreateShortcut($_.FullName)
      if ($l.TargetPath -like "$dest\app\FocusLock.exe") {
        $l.TargetPath = $exe; $l.WorkingDirectory = Split-Path $exe; $l.Save()
        if ($_.BaseName -eq 'FocusLock') { Rename-Item $_.FullName 'DreamMap.lnk' -ErrorAction SilentlyContinue }
        Write-Host "Aggiornato il collegamento $($_.FullName)"
      }
    } catch {}
  }
}
# Win+R cerca nei percorsi del PATH: WindowsApps dell'utente c'e' sempre da Windows 10 in poi.
$winApps = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
New-Item -ItemType Directory -Force -Path $winApps | Out-Null
$righe = "@echo off`r`nrem Win+R -> DreamMap (installato da tools\pc-installer\installa.ps1)`r`nstart `"`" `"$exe`"`r`n"
foreach ($nome in @('dream.cmd', 'focus.cmd')) {
  [IO.File]::WriteAllText((Join-Path $winApps $nome), $righe, [Text.Encoding]::ASCII)
}
Write-Host 'OK: menu Start "DreamMap", Win+R "dream" (e "focus" per abitudine)'

# ---------- via ----------
if ($Prova) { Write-Host 'PROVA: niente avvio'; return }
Passo 'Avvio DreamMap'
function Acceso { Get-Process -Name 'DreamMap' -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe } }
Start-ScheduledTask -TaskName $nomeTask
Start-Sleep -Seconds 3
if (-not (Acceso)) { Start-Process $exe -WorkingDirectory (Split-Path $exe) }
# Deve restare acceso, non solo partire: un pezzo che manca si vede nei primi secondi.
Start-Sleep -Seconds 8
if (-not (Acceso)) {
  Write-Host 'DreamMap non resta acceso: rimetto la versione di prima.' -ForegroundColor Yellow
  if ($backup) {
    Ferma-DreamMap
    Move-Item -LiteralPath $appDir -Destination ($appDir + '.non-parte-' + (Get-Date -Format 'yyyyMMdd-HHmm'))
    Move-Item -LiteralPath $backup -Destination $appDir
    $vecchioExe = @('DreamMap.exe', 'FocusLock.exe') | ForEach-Object { Join-Path $appDir $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
    if ($vecchioExe) { Registra-Task $vecchioExe; Start-ScheduledTask -TaskName $nomeTask }
  }
  throw 'La nuova versione di DreamMap non parte. Il motivo e'' in C:\ProgramData\FocusLock\diagnostics.log.'
}
Write-Host ''
Write-Host 'Fatto. DreamMap e'' acceso: l''icona e'' vicino all''orologio, e da ora parte da solo a ogni accesso.' -ForegroundColor Green
