# Analisi onboarding AppBlock (v7.19.2) → replica FocusLock Mobile

Analisi condotta il 16/08/2026 navigando l'app AppBlock reale dentro BlueStacks 5 (Android, lingua IT).
Obiettivo: replicare la **struttura del funnel** (non i testi/asset, che sono stati riscritti in chiave FocusLock).

## Il funnel completo osservato (16 schermate)

| # | Schermata | Pattern psicologico | Replica FocusLock |
|---|-----------|--------------------|-------------------|
| 1 | Welcome: logo animato, promessa "riprendi il controllo del tempo schermo", CTA unica, link "Sei già iscritto?" | Promessa di valore prima di qualsiasi richiesta | ✅ S0 |
| 2 | Auth: Google / Facebook / Apple / Email + **"Continua senza account"** in fondo | Frizione minima: l'account non è obbligatorio | ✅ S1 |
| 3 | Quiz intro: "adatteremo l'app alle tue esigenze" + rassicurazione privacy + "Policy sui dati" + possibilità di saltare | Personalizzazione percepita + trasparenza | ✅ S2 |
| 4 | Q1 slider: ore/giorno al telefono (1→12+) | Auto-diagnosi, investimento leggero | ✅ S3 (+ conversione in "giorni/anno persi" = loss framing) |
| 5 | Permesso usage access: grafico a barre "misterioso" con "?" + "Concedi l'autorizzazione" / "Continua senza rapporto" | **Curiosity gap** prima della richiesta permesso; fallback sempre presente | ✅ S6 |
| 6 | Transizione: "Esploriamo cosa succede quando riprendi il controllo" | Pacing narrativo | ✅ (fuso in S7) |
| 7 | Demo animata 1: mockup telefono pieno di app "Immagina il momento in cui scegli di concentrarti" | Visualizzazione del problema | ✅ S7 |
| 8 | Demo animata 2: tutte le icone si spengono tranne una ("Decidi tu: Instagram può aspettare") | Il prodotto = controllo | ✅ (fuso in S8) |
| 9 | Demo INTERATTIVA: "premi senza pensarci" → l'utente tocca l'icona → appare la schermata "Bloccato da AppBlock" con contatore tentativi (2× oggi, 23× totale) | **Il momento "aha" simulato**: l'utente prova il valore prima di qualsiasi paywall | ✅ S8 |
| 10 | Blocco personalizzato: "Vai ad abbracciare Emma e Liam" — schermata di blocco con messaggio personale | Emozione + funzione premium teaser | ✅ S9 |
| 11 | Recap benefici: 5 checkmark + micro-interazione **"trascina il logo per continuare"** | Commitment fisico prima del paywall (foot-in-the-door) | ✅ S10 (drag del lucchetto) |
| 12 | **PAYWALL**: "7 giorni gratis" · 2,33 €/mese fatturato annuale · 15M+ utenti · 4.8★ · carosello recensioni · "✓ Nessun pagamento dovuto ora" · CTA trial · "Vedi tutti i piani" · X per chiudere | Trial-first, social proof massiccio, risk reversal. Posizionato DOPO il valore dimostrato | ✅ S11 |
| 13 | Post-rifiuto: si va comunque avanti → "Creiamo il tuo primo blocco" | Nessun vicolo cieco: l'attivazione continua anche senza acquisto | ✅ S12 |
| 14 | Metodo di blocco: 4 card (Ora / Limite di utilizzo / Numero di avvii / Posizione) con tag d'uso; "Imposta il blocco più tardi" | Scelta guidata, non form | ✅ S12 |
| 15 | Config orari: fascia 12:00–14:00 default, toggle "tutto il giorno", giorni L–D, **"Altri intervalli" gated Premium 👑**, preview "attivo per 2h" | Default pre-compilati (zero brain cycles) + gating Premium visibile ma non bloccante | ✅ S13 |
| 16 | Selezione app da bloccare (checklist con ricerca) → schermata autorizzazioni (usage + notifiche, pulsanti "Abilita" singoli) → recap "Prima pianificazione pronta · 2h a settimana guadagnate · inizia tra 20m" → "Concentriamoci" → home | Permission priming contestuale + quantificazione del guadagno + countdown urgency | ✅ S14, S15, S16 |

### Home post-onboarding di AppBlock
- Banner rosso permessi mancanti ("Il blocco non può funzionare" + Abilita) — recovery loop
- **Blocco rapido** con grande pulsante "Inizia" (azione a 1 tocco)
- Timer & Pomodoro gated Premium 👑
- Sezione **Programmi** con il blocco appena creato
- Sezione **Modelli** (template pronti)
- Banner giallo "7 giorni di Premium gratuiti" (paywall re-entry permanente)
- Bottom nav: Blocco / Utilizzo / Approfondimenti / Profilo

## Perché questo funnel converte (lettura Hook Model)

1. **Trigger** → il quiz fa nominare all'utente il proprio trigger interno (noia, stress, letto). FocusLock S5 lo chiede esplicitamente.
2. **Action** → ogni schermata ha UNA sola azione primaria; account facoltativo; default pre-compilati.
3. **Variable Reward** → la demo interattiva simula la ricompensa ("bloccato!") con contatore tentativi; il report "tempo reale sullo schermo" è un curiosity gap.
4. **Investment** → slider, selezioni del quiz, drag del logo, creazione del primo blocco: micro-investimenti crescenti PRIMA del paywall, che arriva solo a valore dimostrato (schermata 12 di 16).
5. **Paywall trial-first** dopo l'investimento, mai prima; chi rifiuta non viene punito ma portato comunque all'attivazione (il trial resta visibile in home).

## Adattamenti FocusLock (differenziazione, non solo replica)

- **7 categorie di dipendenza native** nel quiz e nella selezione blocchi: Social, Gambling/Betting (blocco rinforzato), Videogiochi, Contenuti per adulti (blocco totale), Doomscrolling/Discover, Binge watching, Musica & rumore digitale (modalità Detox).
- **Cross-device come claim unico**: "Sincronizzato col tuo PC — FocusLock Desktop protegge anche il computer" (AppBlock non ce l'ha come leva primaria in onboarding).
- Branding: **brand kit DreamBrothers** — Primary blue `#0075E3`, Contrast red `#E63946` (stati attivi, PRO, CTA paywall), Navy `#001E44` (superfici scure), Dream Gradient (rosa→lavanda→blu→ciano) su hero e card firma. Font: Montserrat Extra Bold Italic (display) + Poppins (body).
- v0.2: 4 tab funzionanti (Blocco / Utilizzo / Progressi / Profilo), login Google/Facebook/Apple/Email con sheet OAuth (mock — in produzione: Firebase Auth / Credential Manager con i client ID del progetto), **Modalità Severa** a 3 livelli (Normale / Severa PIN+attesa / Estrema anti-bypass e anti-disinstallazione), PWA installabile (manifest + service worker + icone).
- L'abbonamento PRO copre **app mobile + programma desktop** insieme (differenziatore vs AppBlock, esplicito nel paywall).
- Tutti i testi riscritti in italiano originale (nessun copy AppBlock riutilizzato).

## Prezzi osservati (riferimento posizionamento)
- AppBlock: 7 giorni gratis → ~2,33 €/mese fatturazione annuale (~27,99 €/anno), claim 15M+ utenti, 4.8★.
- FocusLock prototipo: 7 giorni gratis → 2,49 €/mese (29,99 €/anno) — placeholder da validare.

## File del progetto
- `index.html` — prototipo interattivo completo (18 schermate, mobile-first, self-contained).
- Avvio rapido: `python -m http.server 8123 -d C:/Users/utente/FocusLock-Mobile` → http://localhost:8123

## Prossimi passi consigliati
1. Validare copy e prezzi del paywall.
2. Port nativo: Kotlin/Jetpack Compose oppure shell Capacitor sopra questo HTML (più veloce per lo store).
3. Implementazione reale dei blocchi Android: UsageStatsManager + AccessibilityService + NotificationListenerService (le stesse 2 autorizzazioni viste in AppBlock).
4. Deep-link di sincronizzazione con FocusLock Desktop (rules.json condiviso via cloud).
