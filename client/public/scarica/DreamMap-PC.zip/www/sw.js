const CACHE = "focuslock-v201";   // bump on every release: a stale module is worse than no cache
const ASSETS = [
  "./", "./index.html", "./manifest.json",
  "./icons/icon-192.png", "./icons/icon-512.png",
  // CSS and JS used to live inside index.html. Since the split they are separate requests,
  // and anything not precached here falls through to the index.html fallback below - which
  // would hand back HTML in place of a script and kill the app offline.
  "./css/app.css",
  // registry.js MUST be here: it defines registerScreen(), and every module calls it while
  // loading. Offline it fell through to Response.error() and the whole app failed to start.
  "./js/registry.js", "./js/premium-funnel.js",
  "./js/native.js", "./js/onboarding.js", "./js/perms.js", "./js/blocco.js",
  "./js/blocklist.js", "./js/categories.js", "./js/levels.js", "./js/fullfocus.js", "./js/piano.js", "./js/silenzio.js", "./js/diario.js", "./js/ff-cicli.js", "./js/ff-schede.js", "./js/fuori-rotta.js", "./js/io-futuro-livello.js", "./content/io-futuro.json", "./js/why.js", "./js/friends.js", "./js/dream-social.js", "./js/dream-storia.js", "./js/dream-atmos.js", "./js/report-confronto.js", "./js/ponte.js", "./js/collo.js", "./js/sfide.js", "./js/insieme.js", "./js/porte.js", "./js/rotta-tab.js", "./js/mappa-tab.js", "./js/costruisci.js", "./js/start-costruisci.js", "./js/domande.js", "./js/episodi.js", "./js/episodi-scroll.js", "./js/vendor/gsap.min.js", "./js/vendor/ScrollTrigger.min.js", "./content/episodi.json", "./js/genio-motore.js", "./js/genio-sfida.js", "./js/iofuturo-chiamata.js", "./js/vendor/elevenlabs-client.js", "./content/genio-persone.json", "./content/genio-libri.json", "./content/genio-personaggi.json", "./content/genio-film.json", "./js/modelli.js", "./js/riscaldamento.js", "./js/sentiero.js", "./js/sentiero-mappa.js", "./js/intestazione.js", "./js/qr.js", "./js/blocchi.js", "./js/oracolo-tappa.js", "./js/assenze.js", "./js/respiro.js", "./js/sfide-dream.js", "./js/reset.js", "./js/ulisse.js", "./js/rientro.js", "./js/esci-livello.js", "./js/carburante.js", "./js/aiuto.js", "./content/blocchi.json", "./js/esercizi.js", "./content/esercizi.json", "./js/partita.js", "./js/partita-stats.js", "./js/notion-ponte.js", "./js/mappa-foglio.js", "./js/calendario.js", "./js/riga-foglio.js", "./js/roadmap-livelli.js", "./js/perche.js", "./js/rientro-genio.js", "./js/rompicapo.js", "./content/rompicapi.json", "./js/lockcustom.js", "./js/gioco.js", "./js/regole-misura.js", "./js/turni.js", "./js/report-blocchi.js", "./js/statistiche-globali.js", "./content/medie-globali.json", "./js/dream-mese.js", "./js/coppia.js", "./js/patto.js", "./js/contratto.js", "./js/vita-settimane.js", "./js/fine-tappa.js", "./js/memoria.js", "./js/testo.js", "./js/emergenza.js", "./js/bivio.js", "./js/app-installate.js", "./js/memoria-ai.js", "./js/revisione.js", "./js/conversa.js", "./content/consapevolezza.json", "./js/mappa-note.js", "./js/mappa-pagina.js", "./js/ritmo.js", "./js/intervista.js", "./js/modalita.js", "./note/index.html", "./note/app.js", "./note/app.css", "./js/chevron.js", "./js/dettatura.js", "./notion/index.html", "./notion/app.js", "./notion/app.css", "./notion/dolomites-cover.jpg","./js/severe.js", "./js/insights.js", "./js/profile.js",
  "./js/csv.js", "./js/ads.js", "./js/nav.js",
  "./js/locale.js", "./js/sonno-motore.js", "./js/sonno.js", "./js/focusbox.js"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE && !/^(fx-|snd-)/.test(k)).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", e => {
  /* Le tessere della cartina: la stessa immagine non cambia, quindi prima la copia sul telefono e la rete solo la prima volta.
     Sono risposte opache (r.ok e' falso): vanno salvate qui, sotto al ramo generale non ci finirebbero mai. */
  if (e.request.method === "GET" && /(^|\.)(arcgisonline\.com|tile\.openstreetmap\.org)$/.test(new URL(e.request.url).hostname)) {
    e.respondWith(caches.open("fx-tessere").then(c => c.match(e.request).then(m => m || fetch(e.request).then(r => { c.put(e.request, r.clone()); return r; }))));
    return;
  }
  e.respondWith(
    fetch(e.request)
      .then(r => {
        const copy = r.clone();
        if (e.request.method === "GET" && r.ok) caches.open(CACHE).then(c => c.put(e.request, copy));
        return r;
      })
      .catch(() => caches.match(e.request).then(
        // Only a navigation may fall back to the shell; returning index.html for a .js or .css
        // request would be served as the wrong type and break the page instead of saving it.
        m => m || (e.request.mode === "navigate" ? caches.match("./index.html") : Response.error())
      ))
  );
});
