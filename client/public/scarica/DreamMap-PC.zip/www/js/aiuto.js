/* ===========================================================================================
   AIUTO SU UNA COSA DA FARE (0.9.206)

   Dalla «i» di una riga del foglio: quando non sai da dove partire, due porte.
   1. UN TUTORIAL: un video che mostra come si fa, dentro all'app (YouTube in una cornice
      «nocookie», con la ricerca gia' impostata: niente app di YouTube, niente consigliati).
      Con un conto alla rovescia: si guarda per un tempo deciso prima (20 minuti di serie, 25
      al massimo), poi la porta e' il Full Focus. Studiare non deve diventare la scusa.
   2. IL TUO AGENTE (Premium): gli scrivi cosa ti blocca, lui risponde con i passi e con la
      ricerca giusta per il tutorial. Tre aiuti al giorno: il costo si regge cosi'.
   =========================================================================================== */
const AI = { task: '', min: 20, t0: 0, timer: 0, query: '' };
const AI_MAX_GIORNO = 3;
function aiEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function aiGiorno(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function aiUsati(){ try{ const v = JSON.parse(localStorage.getItem('fl_aiuti') || '{}'); return v[aiGiorno()] || 0; }catch(_){ return 0; } }
function aiSegna(){ try{ const o = {}; o[aiGiorno()] = aiUsati() + 1; localStorage.setItem('fl_aiuti', JSON.stringify(o)); }catch(_){ } }
function aiPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }

registerScreen('s-aiuto',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-riga\')">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Una mano</b></div>'
  + '<div id="aiBody"></div><div class="spacer"></div>', { back: 's-riga' });
registerScreen('s-aiuto-video',
  '<div class="ai-vid-wrap"><div class="topbar ai-vid-top"><button class="iconbtn" onclick="aiVideoChiudi()">‹</button><b class="blk-title" style="flex:1;text-align:center">Il tutorial</b><span class="ai-cd" id="aiCd">20:00</span></div>'
  + '<div class="ai-frame"><iframe id="aiFrame" src="about:blank" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>'
  + '<div id="aiVidBody"></div></div>', { back: function(){ aiVideoFerma(); return 's-aiuto'; } });

function aiApri(task){
  AI.task = String(task || '').trim();
  goId('s-aiuto'); aiPaint();
}
function aiPaint(){
  const h = document.getElementById('aiBody'); if (!h) return;
  const usati = aiUsati(), prem = aiPremium();
  h.innerHTML = '<div class="ai-task"><small>La cosa da fare</small><b>' + aiEsc(AI.task || 'La tua priorità') + '</b></div>'
    /* 1 · il tutorial */
    + '<div class="ai-sez"><div class="ai-sez-h"><span>🎥</span><div><b>Guarda come si fa</b><small>Un video che ti mostra i passi. Lo guardi qui, con un tempo deciso prima: poi si fa.</small></div></div>'
    + '<input class="fin" id="aiQuery" placeholder="Cosa vuoi imparare? es. come aprire una partita IVA" value="' + aiEsc(AI.query || aiQueryDa(AI.task)) + '" autocomplete="off">'
    + '<div class="ai-min"><span>Tempo per guardare</span>' + [10, 15, 20, 25].map(function(m){ return '<button type="button" class="' + (AI.min === m ? 'on' : '') + '" onclick="AI.min=' + m + ';aiPaint()">' + m + ' min</button>'; }).join('') + '</div>'
    + '<button type="button" class="cta" onclick="aiVideoVia()">Trova il tutorial</button>'
    + '<p class="ai-nota">Alla fine del tempo si apre il Full Focus: il tutorial serve a partire, non a rimandare.</p></div>'
    /* 2 · l'agente */
    + '<div class="ai-sez"><div class="ai-sez-h"><span>🧞</span><div><b>Chiedi al tuo agente personale</b><small>Gli dici dove ti blocchi. Lui conosce la tua rotta e risponde con i passi, e con il tutorial giusto.</small></div></div>'
    + (prem
        ? '<textarea class="fin" id="aiDomanda" rows="3" placeholder="Dove ti blocchi? es. non so da dove cominciare, mi serve l’ordine dei passi"></textarea>'
          + '<button type="button" class="cta" id="aiChiedi" onclick="aiChiedi()"' + (usati >= AI_MAX_GIORNO ? ' disabled' : '') + '>' + (usati >= AI_MAX_GIORNO ? 'Aiuti di oggi finiti' : 'Chiedi (' + (AI_MAX_GIORNO - usati) + ' oggi)') + '</button>'
          + '<div id="aiRisposta"></div>'
        : '<button type="button" class="cta ai-prem" onclick="go(11)">🔒 Con Premium · Chiedi al tuo agente personale</button><p class="ai-nota">Tre aiuti al giorno, con i passi scritti da chi conosce la tua rotta.</p>')
    + '</div>';
}
/* 0.9.290: la ricerca e' la cosa da fare detta in breve: niente minuti fra parentesi, niente coda dopo la virgola
   ("una pagina sola"), al massimo nove parole. YouTube trova meglio "come scrivere una pagina di vendita" che la frase intera. */
function aiQueryDa(task){
  let t = String(task || '').replace(/[«»"]/g, '').replace(/\s*\([^)]*\)\s*/g, ' ').trim();
  if (typeof flAccenti === 'function') t = flAccenti(t);
  t = t.split(/[,:;]/)[0].trim().split(/\s+/).slice(0, 9).join(' ');
  return t ? 'come ' + t.charAt(0).toLowerCase() + t.slice(1) : '';
}
async function aiChiedi(){
  const inp = document.getElementById('aiDomanda'); const btn = document.getElementById('aiChiedi'); const out = document.getElementById('aiRisposta');
  const dom = inp ? inp.value.trim() : '';
  if (!dom){ toast('Scrivi dove ti blocchi'); return; }
  if (aiUsati() >= AI_MAX_GIORNO){ toast('Gli aiuti di oggi sono finiti: domani ne hai altri tre'); return; }
  if (btn){ btn.disabled = true; btn.textContent = 'Il tuo agente personale ci pensa…'; }
  if (out) out.innerHTML = '<p class="ai-nota">Sta leggendo la tua rotta…</p>';
  let ctx = {}; try{ const d = (typeof agDati === 'function') ? agDati() : {}; ctx = { sogno: d.sogno || '', profilo: d.profilo || '', freno: (typeof bqPerAgente === 'function') ? bqPerAgente() : '' }; }catch(_){ }
  try{
    const r = await frApi('POST', '/api/focuslock/aiuto', { device: frDevice(), task: AI.task, domanda: dom, contesto: ctx });
    aiSegna();
    const passi = (r && r.passi) || [], q = (r && r.query) || [];
    AI.query = q[0] || AI.query;
    if (out) out.innerHTML = '<div class="ai-ris">' + (r && r.nota ? '<p class="ai-ris-nota">' + aiEsc(r.nota) + '</p>' : '')
      + (passi.length ? '<ol class="ai-passi">' + passi.map(function(p){ return '<li>' + aiEsc(p) + '</li>'; }).join('') + '</ol>' : '<p class="ai-nota">Nessun passo: riprova con una domanda più precisa.</p>')
      + (q.length ? '<button type="button" class="cta" onclick="AI.query=' + JSON.stringify(q[0]).replace(/"/g, '&quot;') + ';aiVideoVia()">🎥 Guarda il tutorial consigliato</button>' : '')
      + '<button type="button" class="sd-btn-link" onclick="aiPassiNelFoglio()">Metti i passi nella riga</button></div>';
    AI.passi = passi;
  }catch(e){ if (out) out.innerHTML = '<p class="ai-nota">Il tuo agente personale non risponde adesso: ' + aiEsc((e && e.message) || 'riprova fra poco') + '</p>'; }
  aiPaint(); const o2 = document.getElementById('aiRisposta'); if (o2 && out) o2.innerHTML = out.innerHTML;
}
function aiPassiNelFoglio(){
  if (!(AI.passi && AI.passi.length) || typeof stMetaSave !== 'function' || typeof STR === 'undefined') return;
  try{ const m = stMeta(STR.line, STR.day); stMetaSave(STR.line, STR.day, { micro: (m.micro || []).concat(AI.passi) }); toast('Passi aggiunti alla riga'); }catch(_){ }
}
/* ---- il video, dentro all'app, con il conto alla rovescia ----
   0.9.290, Andrea: "dice Questo video non e' disponibile, e sotto: se qui non si vede il tuo telefono blocca YouTube.
   Si deve vedere, punto". La cornice riceveva la RICERCA di YouTube (listType=search), che YouTube ha spento: il
   lettore rispondeva sempre "non disponibile". Adesso il server cerca i video veri (/api/focuslock/tutorial: solo
   quelli che si possono incorporare), la cornice mostra il primo e sotto ci sono gli altri e il campo per cercare di nuovo. */
function aiVideoVia(q0){
  const inp = document.getElementById('aiQuery'); const q = (typeof q0 === 'string' && q0.trim()) || (inp && inp.value.trim()) || AI.query || aiQueryDa(AI.task);
  if (!q){ toast('Scrivi cosa vuoi imparare'); return; }
  AI.query = q;
  if (!(document.querySelector('.screen.active') && document.querySelector('.screen.active').id === 's-aiuto-video')) goId('s-aiuto-video');
  if (!AI.t0 || !AI.timer){ AI.t0 = Date.now(); clearInterval(AI.timer); AI.timer = setInterval(aiTick, 1000); aiTick(); }
  aiVideoCerca(q);
}
function aiVideoId(id){
  if (!id) return;
  if (!(document.querySelector('.screen.active') && document.querySelector('.screen.active').id === 's-aiuto-video')) goId('s-aiuto-video');
  if (!AI.t0 || !AI.timer){ AI.t0 = Date.now(); clearInterval(AI.timer); AI.timer = setInterval(aiTick, 1000); aiTick(); }
  AI.video = AI.video && AI.video.length ? AI.video : [{ id: id, t: '', ch: '', dur: '' }];
  aiVideoMetti(id);
}
async function aiVideoCerca(q){
  const b = document.getElementById('aiVidBody');
  AI.video = [];
  if (b) b.innerHTML = '<p class="ai-cerca-st">Cerco il video giusto…</p>';
  const f = document.getElementById('aiFrame'); if (f) f.src = 'about:blank';
  const path = '/api/focuslock/tutorial?q=' + encodeURIComponent(q);
  let r = null;
  try{ r = await frApi('GET', path); }
  catch(_){ try{ const base = (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app'; r = await (await fetch(base + path)).json(); }catch(__){ r = null; } }
  if (AI.query !== q) return;
  AI.video = (r && Array.isArray(r.video)) ? r.video : [];
  if (!AI.video.length){ aiVideoPaint(r ? 'Nessun video per questa ricerca: prova con parole diverse.' : 'Non riesco a cercare adesso: controlla la connessione e riprova.'); return; }
  aiVideoMetti(AI.video[0].id);
}
function aiVideoMetti(id){
  AI.id = id;
  const f = document.getElementById('aiFrame');
  if (f) f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?rel=0&modestbranding=1&playsinline=1&autoplay=1';
  aiVideoPaint('');
}
function aiVideoPaint(nota){
  const b = document.getElementById('aiVidBody'); if (!b) return;
  const cur = (AI.video || []).filter(function(v){ return v.id === AI.id; })[0];
  const altri = (AI.video || []).filter(function(v){ return v.id !== AI.id; });
  b.innerHTML = (cur && cur.t ? '<h3 class="ai-vid-t">' + aiEsc(cur.t) + '</h3><p class="ai-vid-ch">' + aiEsc(cur.ch || '') + (cur.dur ? ' · ' + aiEsc(cur.dur) : '') + '</p>' : '')
    + (nota ? '<p class="ai-cerca-st">' + aiEsc(nota) + '</p>' : '')
    + '<button type="button" class="cta" onclick="aiFullFocus()">Ho visto abbastanza: Full Focus</button>'
    + (altri.length ? '<p class="ai-vid-eti">Altri video</p><div class="ai-vid-lista">' + altri.map(function(v){
        return '<button type="button" class="ai-vid-alt" onclick="aiVideoMetti(\'' + aiEsc(v.id) + '\')"><img src="https://i.ytimg.com/vi/' + aiEsc(v.id) + '/mqdefault.jpg" alt="" loading="lazy"><span><b>' + aiEsc(v.t) + '</b><small>' + aiEsc(v.ch || '') + (v.dur ? ' · ' + aiEsc(v.dur) : '') + '</small></span></button>';
      }).join('') + '</div>' : '')
    + '<p class="ai-vid-eti">Cerca un altro video</p><div class="ai-vid-cerca"><input class="fin" id="aiQuery2" value="' + aiEsc(AI.query || '') + '" autocomplete="off" data-no-mic onkeydown="if(event.key===\'Enter\'){event.preventDefault();aiVideoVia(this.value)}"><button type="button" onclick="aiVideoVia(document.getElementById(\'aiQuery2\').value)" aria-label="Cerca"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg></button></div>';
}
function aiTick(){
  const el = document.getElementById('aiCd'); if (!el) return;
  const left = Math.max(0, AI.min * 60 - Math.round((Date.now() - AI.t0) / 1000));
  el.textContent = Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
  el.classList.toggle('fine', left <= 60);
  if (left <= 0){ aiVideoFerma(); aiFullFocus(true); }
}
function aiVideoFerma(){ clearInterval(AI.timer); AI.timer = 0; AI.t0 = 0; const f = document.getElementById('aiFrame'); if (f) f.src = 'about:blank'; }
function aiVideoChiudi(){ aiVideoFerma(); goId('s-aiuto'); }
function aiFullFocus(scaduto){
  aiVideoFerma();
  try{ flVibra([30, 40, 90]); }catch(_){ }
  if (scaduto) toast('Tempo finito: ora si fa');
  goId('s-home');
  try{ switchTab('sveglia'); }catch(_){ }
  setTimeout(function(){ try{ if (typeof stGoFocus === 'function') stGoFocus(); }catch(_){ } }, 300);
}

(function(){
  const css = [
    '#aiBody{padding:0 18px}.ai-task{margin:16px 0 8px;padding:14px 16px;border-radius:16px;background:rgba(0,117,227,.08)}.ai-task small{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.ai-task b{display:block;margin-top:4px;font:800 16px/1.35 var(--font-body);color:var(--navy)}body.dark .ai-task b{color:#fff}',
    '.ai-sez{margin-top:26px;padding:18px 16px;border:1px solid var(--line);border-radius:20px;background:var(--card,#fff)}body.dark .ai-sez{background:#12203A;border-color:#22345A}.ai-sez-h{display:flex;gap:12px;align-items:flex-start;margin-bottom:14px}.ai-sez-h > span{font-size:30px;line-height:1}.ai-sez-h b{display:block;font:800 16px var(--font-body);color:var(--navy)}body.dark .ai-sez-h b{color:#fff}.ai-sez-h small{display:block;margin-top:4px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.ai-sez .fin{margin:0 0 12px}.ai-sez .cta{width:100%}.ai-min{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:0 0 14px}.ai-min span{flex:1 0 100%;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:4px}.ai-min button{flex:1;border:1.5px solid var(--line);border-radius:10px;background:transparent;padding:9px 4px;font:700 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .ai-min button{color:#fff;border-color:#22345A}.ai-min button.on{border-color:#0075E3;background:rgba(0,117,227,.12);color:#0075E3}',
    '.ai-nota{margin:12px 0 0;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}.ai-prem{background:#E71D4F}.ai-ris{margin-top:14px}.ai-ris-nota{margin:0 0 10px;font:600 14px/1.5 var(--font-body);color:var(--navy)}body.dark .ai-ris-nota{color:#fff}.ai-passi{margin:0 0 14px;padding-left:20px}.ai-passi li{margin:0 0 8px;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .ai-passi li{color:#fff}',
    '.ai-vid-wrap{display:flex;flex-direction:column;min-height:100%}.ai-vid-top{padding-right:14px}.ai-cd{min-width:62px;text-align:center;padding:6px 10px;border-radius:99px;background:#001E44;color:#fff;font:800 14px var(--font-body);font-variant-numeric:tabular-nums}.ai-cd.fine{background:#E63946;animation:aiPulsa 1s ease-in-out infinite}@keyframes aiPulsa{50%{transform:scale(1.06)}}',
    '.ai-frame{position:relative;width:100%;aspect-ratio:16/9;background:#000}.ai-frame iframe{position:absolute;inset:0;width:100%;height:100%;border:0}#aiVidBody{padding:20px 18px 28px}.ai-vid-q{margin:0 0 8px;font:600 14px var(--font-body);color:var(--navy)}body.dark .ai-vid-q{color:#fff}#aiVidBody .cta{width:100%;margin-top:24px}',
    '.ai-vid-t{margin:0;font:800 17px/1.35 var(--font-body);color:var(--navy)}body.dark .ai-vid-t{color:#fff}.ai-vid-ch{margin:8px 0 0;font:600 13px var(--font-body);color:var(--muted)}.ai-cerca-st{margin:4px 0 0;font:600 14px/1.5 var(--font-body);color:var(--muted)}',
    '.ai-vid-eti{margin:28px 0 12px;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}',
    '.ai-vid-lista{display:flex;flex-direction:column;gap:12px}.ai-vid-alt{display:flex;gap:12px;align-items:flex-start;width:100%;padding:0;border:0;background:none;text-align:left;cursor:pointer}.ai-vid-alt img{flex:none;width:128px;aspect-ratio:16/9;object-fit:cover;border-radius:10px;background:#0E2350}.ai-vid-alt span{min-width:0}.ai-vid-alt b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font:700 14px/1.35 var(--font-body);color:var(--navy)}body.dark .ai-vid-alt b{color:#fff}.ai-vid-alt small{display:block;margin-top:6px;font:600 12px var(--font-body);color:var(--muted)}',
    '.ai-vid-cerca{display:flex;gap:10px}.ai-vid-cerca .fin{flex:1;margin:0}.ai-vid-cerca button{flex:none;width:48px;border:0;border-radius:14px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
