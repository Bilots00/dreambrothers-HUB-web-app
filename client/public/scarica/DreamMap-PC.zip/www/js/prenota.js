/* ===========================================================================================
   IL PUNTO PRENOTATO — il pre-commitment, e le decisioni a tempo del tuo agente personale

   IL TRUCCO DEL BARATTOLO. Andrea metteva la pallina nel barattolo PRIMA di fare la cosa: la
   micro-decisione di metterla lo obbligava, per coerenza, a fare la cosa subito dopo. Qui il
   barattolo e' il tabellone: il punto va al nuovo te nel momento in cui decidi, ma e' solo
   PRENOTATO. Si conferma chiudendo la task in una sessione FullFocus entro oggi (chiusa entro
   un'ora vale doppio, come un tiro da tre), e a fine giornata, se la task e' ancora aperta,
   torna indietro con il suo motivo scritto nel registro.

   DUE PORTE:
     · dopo la chiamata dei sogni (dreamcall.js): il pannello olografico del primo passo,
       «parti prima di sentirti pronto» — la stessa cornice della proroga della severa;
     · le decisioni del tuo agente personale (Jordan, via jordan.js): una scelta vera fra due strade,
       con un conto alla rovescia che si vede tre secondi e poi sparisce. Risposta in tempo =
       punto prenotato; lo tieni se mantieni la decisione, e l'agente puo' revocarlo con una
       riga di motivo (`revoche` nel verdetto) se torni indietro.

   Le persone che riescono decidono in fretta e cambiano idea lentamente; le altre ci mettono
   settimane a decidere e disfano tutto subito. Questo modulo allena la prima abitudine.
   =========================================================================================== */

const PK_KEY = 'fl_prenotazioni';            // [{ id, tipo, testo, at, giorno, scade, stato, punti, decId, scelta, motivo }]
const PK_RISP_KEY = 'fl_decisioni_risposte'; // [{ id, scelta, testo, domanda, at, inTempo, secondi }]
const PK_DOPPIO_MIN = 60;                    // entro quanti minuti la task chiusa vale doppio
const PK_TIMER_VISTA_MS = 3000;              // il conto alla rovescia si vede cosi', poi sparisce
const PK = { task: '', dec: null, scadeAt: 0, timer: 0, mostrata: {} };

function pkLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function pkScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function pkKey(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function pkNorm(s){ return String(s || '').toLowerCase().replace(/[^a-z0-9àèéìòù]+/g, ' ').trim(); }
function pkEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x); }
function pkLista(){ return pkLeggi(PK_KEY, []) || []; }
function pkSalva(l){ pkScrivi(PK_KEY, l.slice(-200)); }
function pkAperte(tipo){ return pkLista().filter(function(x){ return x && x.stato === 'prenotato' && (!tipo || x.tipo === tipo); }); }

/* ---------------------------------------------------------------------------------------
   IL TABELLONE: il punto si mette subito, e si toglie con il motivo
   --------------------------------------------------------------------------------------- */
function pkSegna(motivo){
  try{ if (typeof mgLog === 'function') mgLog('neo', motivo); }catch(_){ }
  try{ if (typeof mtFocusPoint === 'function') mtFocusPoint(); }catch(_){ }
}
/** −1 al nuovo te. Il registro lo scrive come «revoca», e il tabellone condiviso lo sa. */
function pkTogli(motivo){
  try{
    if (typeof mtRoll !== 'function' || typeof mtWrite !== 'function') return;
    const s = mtRoll();
    s.neo = Math.max(0, (s.neo || 0) - 1);
    mtWrite(MT_KEY, s);
    if (typeof mgLog === 'function') mgLog('revoca', motivo);
    /* il conto di questo dispositivo sul tabellone condiviso scende con lui: altrimenti alla
       prossima sincronizzazione il punto tornerebbe da solo */
    try{
      if (typeof lsMine === 'function' && typeof lsWrite === 'function'){
        const m = lsMine();
        m.neo = Math.max(0, (m.neo || 0) - 1);
        if (m.seen) m.seen.neo = Math.max(0, (m.seen.neo || 0) - 1);
        lsWrite(m);
        if (typeof lsPushSoon === 'function') lsPushSoon();
      }
    }catch(_){ }
    if (typeof mtPaint === 'function') mtPaint();
    pkCartello(motivo);
  }catch(_){ }
}
/** Il cartello della revoca: come quello del gol, ma dice cosa e' stato tolto e perche'. */
function pkCartello(motivo){
  if (typeof document === 'undefined') return;
  const el = document.getElementById('goalWrap');
  if (!el || typeof mtState !== 'function') return;
  const s = mtState();
  el.innerHTML =
      '<div class="gl-scrim" onclick="mtGoalClose()"></div>'
    + '<div class="gl-card loro" onclick="mtGoalApri(event)">'
    +   '<div class="gl-ico">↩</div>'
    +   '<b class="gl-k">Punto revocato al nuovo te</b>'
    +   '<div class="gl-score"><span class="old">' + (s.old || 0) + '</span><i>–</i><span class="neo">' + (s.neo || 0) + '</span></div>'
    +   '<p class="gl-p">Era prenotato. Non e’ stato mantenuto.</p>'
    +   '<p class="gl-p" style="margin-top:8px;font-weight:700">Motivo: ' + pkEsc(motivo) + '</p>'
    + '</div>';
  el.hidden = false;
  el.classList.add('open');
  requestAnimationFrame(function(){ el.classList.add('in'); });
  try{ clearTimeout(MT_GOAL_T); MT_GOAL_T = setTimeout(mtGoalClose, 9000); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   PRENOTARE, CONFERMARE, REVOCARE
   --------------------------------------------------------------------------------------- */
function pkPrenota(tipo, testo, extra, adesso){
  const at = adesso || Date.now();
  const r = Object.assign({
    id: 'p' + at.toString(36) + Math.floor(Math.random() * 1000).toString(36),
    tipo: tipo, testo: String(testo || '').trim(), at: at, giorno: pkKey(at),
    scade: tipo === 'passo' ? at + PK_DOPPIO_MIN * 60000 : 0, stato: 'prenotato', punti: 1
  }, extra || {});
  const l = pkLista(); l.push(r); pkSalva(l);
  if (tipo === 'punto'){ pkSegna('Punto prenotato: "' + r.testo + '" alle ' + pkOra(r.inizio) + '. Resta se lo fai entro la fine dell’appuntamento'); return r; }
  pkSegna(tipo === 'passo'
    ? 'Punto prenotato: «' + r.testo + '». Vale se la chiudi in FullFocus entro oggi'
    : 'Decisione presa in tempo: «' + (r.scelta || r.testo) + '». Vale se la mantieni');
  return r;
}
function pkConferma(id, quando){
  const l = pkLista();
  const r = l.filter(function(x){ return x.id === id && x.stato === 'prenotato'; })[0];
  if (!r) return null;
  quando = quando || Date.now();
  r.stato = 'confermato'; r.confermataAt = quando;
  const prima = !!(r.scade && quando <= r.scade);
  if (prima){ r.punti = 2; }
  pkSalva(l);
  if (prima) pkSegna('Chiusa prima della scadenza: punto doppio («' + r.testo + '»)');
  else if (typeof toast === 'function') toast('Punto confermato: «' + r.testo + '»');
  return r;
}
function pkRevoca(id, motivo){
  const l = pkLista();
  const r = l.filter(function(x){ return x.id === id && x.stato === 'prenotato'; })[0];
  if (!r) return null;
  r.stato = 'revocato'; r.motivo = String(motivo || ''); r.revocataAt = Date.now();
  pkSalva(l);
  pkTogli(r.motivo);
  return r;
}
/** La task chiusa (la risposta «Si', completata», o una riga spuntata con la prova). */
function pkConfermaTask(testo, quando){
  const n = pkNorm(testo);
  const aperte = pkAperte('passo');
  let r = aperte.filter(function(x){ return n && pkNorm(x.testo) === n; })[0];
  /* senza un testo che combacia, vale la prenotazione di oggi: era quella la task */
  if (!r) r = aperte.filter(function(x){ return x.giorno === pkKey(quando || Date.now()); })[0];
  return r ? pkConferma(r.id, quando) : null;
}
/** Dopo una sessione FullFocus chiusa bene con quella intenzione. */
function pkDopoSessione(){
  let ultima = null;
  try{ ultima = (pkLeggi('fl_ff_hist', []) || []).filter(function(x){ return x && x.ok; }).slice(-1)[0]; }catch(_){ }
  if (!ultima || Date.now() - ultima.at > 30 * 60000 || !ultima.intent) return;
  const n = pkNorm(ultima.intent);
  const r = pkAperte('passo').filter(function(x){ return pkNorm(x.testo) === n; })[0];
  if (r) pkConferma(r.id, ultima.at);
}
/** A fine giornata quello che e' rimasto aperto torna indietro. */
function pkControlla(adesso){
  const ora = adesso || Date.now();
  const oggi = pkKey(ora);
  pkAperte('passo').forEach(function(r){
    if (r.giorno < oggi) pkRevoca(r.id, 'Task «' + r.testo + '» non chiusa entro fine giornata: il punto prenotato torna indietro');
  });
  pkPuntiControlla(ora);
}

/* ---------------------------------------------------------------------------------------
   LA PORTA 3 (0.9.242): "PRENOTA IL PUNTO", i passi di domani messi a un'ora precisa

   Dal sistema di Davie Fogarty: le cose importanti di domani si mettono in calendario a un'ora
   precisa, la sera prima. Prenotarle e' gia' un micro-impegno, e vale subito +1 al nuovo te.
   Se l'ora dell'appuntamento passa e il passo non e' fatto, il punto torna indietro con il suo
   motivo scritto. Si apre dalla scheda Domani del piano della Roadmap e dalla fine della
   revisione della sera. L'appuntamento va nel calendario di DreamMap (calendario.js) e, se e'
   collegato, in quello del telefono.
   --------------------------------------------------------------------------------------- */
/* 0.9.294, Andrea: "si prenota un punto per una sola task, la prossima, non 200": un punto al giorno, e solo il passo
   che viene adesso nella roadmap */
const PK_PUNTI_MAX = 1;
const PK_PUNTO = { scelto: -1, ora: '09:00', durata: 60, voci: [], giorno: '' };
function pkOra(ms){ const d = new Date(ms || Date.now()); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function pkDomaniKey(){ return pkKey(Date.now() + 86400000); }
/** Il passo e' fatto? Nella roadmap (fl_orizzonti), fra le righe spuntate di quel giorno, o in una sessione chiusa con quell'intenzione. */
function pkPuntoFatto(r){
  const n = pkNorm(r.testo);
  try{
    if (typeof ozAnello === 'function'){
      const k = ['oggi', 'settimana', 'mese', 'anno', 'cinque'];
      for (let i = 0; i < k.length; i++){
        const p = (ozAnello(k[i]).passi || []).filter(function(x){ return x && pkNorm(x.t) === n; })[0];
        if (p && p.fatto) return true;
      }
    }
  }catch(_){ }
  try{ if ((pkLeggi('fl_notes_done', []) || []).some(function(x){ return x && x.day === r.giorno && pkNorm(x.text) === n; })) return true; }catch(_){ }
  try{ if ((pkLeggi('fl_ff_hist', []) || []).some(function(x){ return x && x.ok && x.at >= r.at && pkNorm(x.intent) === n; })) return true; }catch(_){ }
  return false;
}
function pkPuntiControlla(ora){
  pkAperte('punto').forEach(function(r){
    if (pkPuntoFatto(r)){
      const l = pkLista(); const x = l.filter(function(y){ return y.id === r.id; })[0];
      if (x){ x.stato = 'confermato'; x.confermataAt = ora; pkSalva(l); }
      if (typeof toast === 'function') toast('Punto confermato: "' + r.testo + '"');
      return;
    }
    if (r.fine && ora > r.fine) pkRevoca(r.id, 'Il passo "' + r.testo + '" era prenotato per le ' + pkOra(r.inizio) + ' e non è stato fatto in tempo: il punto torna indietro');
  });
}
/** I passi proposti per domani: quelli del piano della Roadmap, poi quelli aperti della settimana. */
function pkPuntoVoci(){
  let l = [];
  try{ if (typeof rmpPassi === 'function') l = (rmpPassi().domani || []).filter(function(x){ return !x.fatto && x.t; }).map(function(x){ return { t: x.t, k: x.k, j: x.j }; }); }catch(_){ }
  try{
    if (typeof ozAnello === 'function') ['settimana', 'mese'].forEach(function(k){
      (ozAnello(k).passi || []).forEach(function(p, j){ if (p && p.t && !p.fatto && !l.some(function(x){ return pkNorm(x.t) === pkNorm(p.t); })) l.push({ t: p.t, k: k, j: j }); });
    });
  }catch(_){ }
  /* gia' prenotati per domani: non si prenotano due volte */
  const gia = pkLista().filter(function(x){ return x.tipo === 'punto' && x.giorno === pkDomaniKey() && x.stato !== 'revocato'; }).map(function(x){ return pkNorm(x.testo); });
  /* 0.9.347, Andrea: "Scegliere lo strumento di intelligenza artificiale per i video non e' una tappa". Un passo che e' solo una scelta da
     due secondi non viene proposto come passo di domani, se ce n'e' uno di lavoro vero */
  const veri = l.filter(function(x){ return gia.indexOf(pkNorm(x.t)) < 0; });
  const lavoro = veri.filter(function(x){ return !pkMicroScelta(x.t); });
  return (lavoro.length ? lavoro : veri).slice(0, (typeof pkPianificaIo === 'function' && pkPianificaIo()) ? 8 : 1);
}
function pkMicroScelta(t){ return /^\s*(scegliere|decidere|valutare|confrontare|individuare|selezionare)\b[^.]{0,60}\b(strumento|tool|app|applicazione|piattaforma|software|programma|servizio|corso|tema|colore|font|nome|fornitore)\b/i.test(String(t || '')); }
/* 0.9.276, Andrea: "se ho scelto di non pianificare, che cazzo mi viene a chiedere cosa fai domani? Non devo
   scriverlo io il passo: lo pianifica il Genio o l'agente". Chi segue la strada del Genio riceve il passo gia'
   scelto (dalla Roadmap, poi dalla mappa) e decide solo l'ora. Chi pianifica da se' sceglie o scrive. */
function pkPianificaIo(){ try{ const u = (typeof faStrada === 'function') ? faStrada() : null; return !!(u && u.scelta === 'mia'); }catch(_){ return false; } }
function pkPassoDalSentiero(){
  try{
    const p = (typeof sdPrimoLeggi === 'function') ? sdPrimoLeggi() : null;
    if (p && p.t && !p.fatto && !p.tutte) return { t: p.t, min: p.min || 30 };
    if (typeof sdTutti === 'function' && typeof sdMissione === 'function'){
      const s = sdStato();
      const nd = sdTutti().filter(function(x){ return x.tipo === 'mis' && !sdNodoFatto(x, s); })[0];
      const m = nd && sdMissione(nd);
      if (m && m.t) return { t: m.t.replace(/\s*\(\d+ min\)$/, ''), min: m.min || 30 };
    }
  }catch(_){ }
  return null;
}
function pkPuntiDomani(){ return pkLista().filter(function(x){ return x.tipo === 'punto' && x.giorno === pkDomaniKey() && x.stato !== 'revocato'; }); }
/* 0.9.347, Andrea: "il Taglia lo farei fare nella revisione serale prima di prenotare il punto del giorno dopo: se quel giorno ha scritto
   delle idee nelle note, o se ha il blocco del focus del sabotatore invisibile (troppa carne al fuoco, non trova la priorita'). Non solo le
   idee: anche le abitudini che non c'entrano con il sogno". Una volta al giorno al massimo; si puo' saltare. */
function pkGiornoInizio(){ const d = new Date(); if (d.getHours() < 5) d.setDate(d.getDate() - 1); d.setHours(0, 0, 0, 0); return d.getTime(); }
function pkTagliaServe(){
  try{
    const d0 = pkGiornoInizio();
    const st = (typeof esStato === 'function') ? esStato() : null;
    if (st && (st.storia || []).some(function(x){ return x.tipo === 'taglia' && x.at >= d0; })) return '';
    if (PK_PUNTO.tagliaSaltata === d0) return '';
    let focus = false; try{ const b = JSON.parse(localStorage.getItem('fl_bq') || localStorage.getItem('fl_blocchi') || 'null'); focus = !!(b && b.primario === 'dispersione'); }catch(_){ }
    let idee = []; try{ idee = (typeof mnIdeePerTaglia === 'function') ? mnIdeePerTaglia(8) : []; }catch(_){ idee = []; }
    let toccata = false; try{ const n = (typeof mnInbox === 'function') ? mnInbox() : null; const t = n && (n.mod || n.m || n.u || n.updatedAt || n.agg || n.at || 0); toccata = +t >= d0; }catch(_){ }
    if (idee.length >= 3 && (toccata || focus)) return 'oggi';
    if (focus) return 'abitudini';
    return '';
  }catch(_){ return ''; }
}
function pkTagliaHtml(arco){
  const idee = arco === 'oggi';
  return '<div class="pkg pkt"><small class="stg-eti">Prima del passo di domani</small>'
    + '<div class="pkt-ico" aria-hidden="true">✂️</div>'
    + '<h2 class="stg-h">' + (idee ? 'Taglia la carne al fuoco' : 'Taglia quello che non serve') + '</h2>'
    + '<p class="stg-p">' + (idee ? 'Oggi nelle tue note sono arrivate idee nuove.' : 'Oggi il telefono ti ha portato da altre parti.') + '</p>'
    + '<p class="stg-p">' + (idee ? 'In 60 secondi tieni solo quella che ti avvicina di più al sogno.' : 'In 60 secondi tagli le abitudini che non c’entrano con il sogno.') + '</p>'
    + '<button type="button" class="stg-cta" onclick="pkTagliaVia(\'' + arco + '\')">Taglia adesso</button>'
    + '<button type="button" class="stg-link" onclick="PK_PUNTO.tagliaSaltata=pkGiornoInizio();stgFoglioCorpo(pkPuntoHtml())">Salta, scelgo il passo</button></div>';
}
function pkTagliaVia(arco){
  try{ stgFoglioChiudi(); }catch(_){ }
  if (typeof esApri !== 'function'){ pkPuntoApri(); return; }
  ES.dopo = function(){ PK_PUNTO.tagliaSaltata = pkGiornoInizio(); pkPuntoApri(); };
  esApri({ id: 'sera-taglia-' + pkGiornoInizio(), es: 'taglia', arco: arco });
}
function pkPuntoApri(){
  PK_PUNTO.voci = pkPuntoVoci(); PK_PUNTO.durata = 60; PK_PUNTO.fase = 'passo';
  if (!PK_PUNTO.voci.length){ const x = pkPassoDalSentiero(); if (x){ PK_PUNTO.voci = [{ t: x.t }]; PK_PUNTO.durata = x.min >= 45 ? 60 : 30; } }
  PK_PUNTO.scelto = PK_PUNTO.voci.length ? 0 : -1;
  if (typeof stgFoglio !== 'function') return;
  const taglia = (new Date().getHours() >= 17 || new Date().getHours() < 5) ? pkTagliaServe() : '';
  stgFoglio(taglia ? pkTagliaHtml(taglia) : pkPuntoHtml());
}
function pkPuntoHtml(){
  const fatti = pkPuntiDomani();
  const pieno = fatti.length >= PK_PUNTI_MAX;
  const gia = fatti.length ? '<div class="pkp-gia"><small>Già prenotati per domani</small>' + fatti.map(function(x){ return '<p>' + pkOra(x.inizio) + ', ' + pkEsc(x.testo) + '</p>'; }).join('') + '</div>' : '';
  if (pieno) return '<small class="stg-eti">Prenota il punto</small><h2 class="stg-h">Il punto di domani è già prenotato</h2>' + gia
    + '<p class="stg-p">Si prenota un passo alla volta. Adesso fallo valere.</p><button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Va bene</button>';
  /* LA STRADA DEL GENIO: un passo alla volta, gia' scelto. Prima il passo, poi l'ora (OEOF). */
  if (!pkPianificaIo() && PK_PUNTO.voci.length){
    const v = PK_PUNTO.voci[Math.max(0, PK_PUNTO.scelto)];
    if (PK_PUNTO.fase !== 'ora'){
      return '<div class="pkg"><small class="stg-eti">Il passo di domani</small>'
        /* 0.9.353, Andrea: "a nessuno piace che qualcuno scelga per lui: uno si vuole sentire protagonista, non spettatore" */
        + '<h2 class="stg-h">Il tuo prossimo passo</h2>'
        + '<div class="pkg-passo"><b>' + pkEsc(v.t) + '</b></div>'
        + '<button type="button" class="stg-cta" onclick="PK_PUNTO.fase=\'ora\';stgFoglioCorpo(pkPuntoHtml())">Scelgo quando farlo</button>'
        + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>'
        + '</div>';
    }
    /* 0.9.347, Andrea: "chiede a che ora lo fai senza la possibilita' di scegliere un altro orario, come se fosse obbligato". C'e' "Un'altra ora" */
    const ore = ['08:00', '09:00', '11:00', '15:00', '18:00'];
    const libera = !!PK_PUNTO.oraLibera || ore.indexOf(PK_PUNTO.ora) < 0;
    return '<div class="pkg"><small class="stg-eti">Il passo di domani</small>'
      + '<h2 class="stg-h">A che ora lo fai?</h2>'
      + '<div class="pkg-sotto">' + pkEsc(v.t) + '</div>'
      + '<div class="stg-chips pkg-ore">' + ore.map(function(o){ return '<button type="button" class="stg-chip' + (!libera && PK_PUNTO.ora === o ? ' on' : '') + '" onclick="PK_PUNTO.oraLibera=false;PK_PUNTO.ora=\'' + o + '\';stgFoglioCorpo(pkPuntoHtml())">' + o.replace(/^0/, '') + '</button>'; }).join('')
      + '<button type="button" class="stg-chip pkg-altra' + (libera ? ' on' : '') + '" onclick="PK_PUNTO.oraLibera=true;stgFoglioCorpo(pkPuntoHtml());setTimeout(function(){ const i=document.getElementById(\'pkpOra\'); if(i){ try{ i.showPicker(); }catch(_){ i.focus(); } } },120)">Un’altra ora</button></div>'
      + (libera ? '<input type="time" class="stg-in pkg-ora-libera" id="pkpOra" value="' + PK_PUNTO.ora + '" onchange="PK_PUNTO.ora=this.value">' : '<input type="hidden" id="pkpOra" value="' + PK_PUNTO.ora + '">')
      + '<button type="button" class="stg-cta" onclick="pkPuntoConferma()">Prenoto il punto</button>'
      + '<button type="button" class="stg-link" onclick="PK_PUNTO.fase=\'passo\';stgFoglioCorpo(pkPuntoHtml())">Indietro</button>'
      + '</div>';
  }
  const voci = PK_PUNTO.voci.map(function(x, i){
    return '<button type="button" class="pkp-voce' + (PK_PUNTO.scelto === i ? ' on' : '') + '" onclick="pkPuntoScegli(' + i + ')"><span class="pkp-r"></span><b>' + pkEsc(x.t) + '</b></button>';
  }).join('');
  return '<small class="stg-eti">Prenota il punto</small><h2 class="stg-h">Cosa fai domani, e a che ora?</h2>'
    + '<p class="stg-p">Scegli un passo e mettilo in calendario. Prenotarlo vale subito <b>+1 al nuovo te</b>. Se l’ora passa e il passo non è fatto, il punto torna indietro.</p>'
    + gia
    + (voci ? '<div class="pkp-voci">' + voci + '</div>' : '')
    + '<label class="stg-q">' + (voci ? 'Oppure scrivi tu il passo' : 'Scrivi il passo di domani') + '</label>'
    + '<input class="stg-in" id="pkpTesto" placeholder="Per esempio: chiamo tre clienti" oninput="pkPuntoScritto(this)">'
    + '<div class="pkp-ora"><label class="stg-q">A che ora</label><input type="time" class="stg-in pkp-time" id="pkpOra" value="' + PK_PUNTO.ora + '"></div>'
    + '<label class="stg-q">Quanto dura</label><div class="stg-chips">' + [[30, 'Mezz’ora'], [60, 'Un’ora'], [90, 'Un’ora e mezza'], [120, 'Due ore']].map(function(d){ return '<button type="button" class="stg-chip' + (PK_PUNTO.durata === d[0] ? ' on' : '') + '" onclick="pkPuntoDurata(' + d[0] + ',this)">' + d[1] + '</button>'; }).join('') + '</div>'
    + '<button type="button" class="stg-cta" onclick="pkPuntoConferma()">Prenoto il punto</button>'
    + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>';
}
function pkPuntoScegli(i){
  PK_PUNTO.scelto = i;
  const t = document.getElementById('pkpTesto'); if (t) t.value = '';
  document.querySelectorAll('#stgVelo .pkp-voce').forEach(function(b, k){ b.classList.toggle('on', k === i); });
}
function pkPuntoScritto(el){ if (String(el.value || '').trim()){ PK_PUNTO.scelto = -1; document.querySelectorAll('#stgVelo .pkp-voce').forEach(function(b){ b.classList.remove('on'); }); } }
function pkPuntoDurata(m, btn){ PK_PUNTO.durata = m; document.querySelectorAll('#stgVelo .stg-chips .stg-chip').forEach(function(b){ b.classList.toggle('on', b === btn); }); }
function pkPuntoConferma(){
  const scritto = String((document.getElementById('pkpTesto') || {}).value || '').replace(/\s+/g, ' ').trim();
  const voce = scritto ? { t: scritto } : PK_PUNTO.voci[PK_PUNTO.scelto];
  if (!voce || !voce.t){ if (typeof toast === 'function') toast('Scegli un passo o scrivilo tu.'); return; }
  const hm = String((document.getElementById('pkpOra') || {}).value || PK_PUNTO.ora).split(':');
  const h = +hm[0], m = +hm[1];
  if (isNaN(h) || isNaN(m)){ if (typeof toast === 'function') toast('Scegli l’ora.'); return; }
  PK_PUNTO.ora = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  const d = new Date(Date.now() + 86400000); d.setHours(h, m, 0, 0);
  const inizio = d.getTime(), fine = inizio + PK_PUNTO.durata * 60000;
  let ev = null;
  try{ if (typeof calSalvaEvento === 'function') ev = calSalvaEvento({ titolo: voce.t, inizio: inizio, fine: fine, colore: '#3F9FF4', descr: 'Punto prenotato in DreamMap: fallo entro la fine dell’appuntamento e il punto resta al nuovo te.' }); }catch(_){ }
  const r = pkPrenota('punto', voce.t, { k: voce.k || '', j: voce.j != null ? voce.j : -1, evId: ev ? ev.id : '', inizio: inizio, fine: fine, scade: fine, giorno: pkKey(inizio) });
  try{ flVibra([20, 40, 30]); }catch(_){ }
  PK_PUNTO.ultimo = r;
  if (typeof stgFoglioCorpo === 'function') stgFoglioCorpo(pkDopoHtml(r));
  try{ if (typeof rmpPaint === 'function') rmpPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LA PORTA 1: dopo la chiamata dei sogni — il primo passo, prima di sentirsi pronti
   --------------------------------------------------------------------------------------- */
function pkTaskDiOggi(){
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    const tx = one && !one.done && one.task && (one.task.text || one.task);
    if (tx) return String(tx).trim();
  }catch(_){ }
  try{ const m = (typeof stMissione === 'function') ? stMissione() : null; if (m && m.t) return String(m.t).trim(); }catch(_){ }
  return '';
}
function pkDopoChiamata(){
  try{
    if (typeof decOpen !== 'function' || (typeof DEC !== 'undefined' && DEC.open)) return;
    const oggi = pkKey(Date.now());
    if (pkLista().some(function(x){ return x.tipo === 'passo' && x.giorno === oggi; })) return;   // una al giorno
    const task = pkTaskDiOggi();
    if (!task) return;
    PK.task = task;
    decOpen('custom', {
      kicker: 'Il primo passo di oggi',
      title: 'PARTI PRIMA<br>DI SENTIRTI PRONTO',
      line: '«' + pkEsc(task) + '».<br>Non serve sapere come: serve cominciare. <b>Il punto lo prenoti adesso</b> e lo confermi chiudendo la task in una sessione FullFocus entro oggi. Chiusa entro ' + PK_DOPPIO_MIN + ' minuti vale <b>doppio</b>.',
      left: 'NON<br>OGGI', right: 'PRENOTO<br>IL PUNTO',
      leftAct: 'pkPassoNo()', rightAct: 'pkPassoSi()',
      foot: 'Rimandare non costa un punto. Costa un giorno.'
    });
  }catch(_){ }
}
function pkPassoSi(){
  const r = pkPrenota('passo', PK.task);
  try{ if (typeof decVote === 'function') decVote('passo', true, 0); }catch(_){ }
  if (typeof decResultCon === 'function') decResultCon(
    'Punto prenotato: <b>+1 al nuovo te</b>, sul tabellone da adesso.<br>Hai <b>' + PK_DOPPIO_MIN + ' minuti</b> per farlo valere doppio. Se a fine giornata «' + pkEsc(r.testo) + '» e’ ancora aperta, torna indietro.',
    1, true,
    ['<button type="button" class="dec-opt no" onclick="decClose()">PIÙ TARDI</button>',
     '<button type="button" class="dec-opt yes" onclick="pkPartiAdesso()">PARTI<br>ADESSO</button>'],
    'Prenotato');
}
function pkPassoNo(){
  try{ if (typeof decVote === 'function') decVote('passo', false, 0); }catch(_){ }
  if (typeof decClose === 'function') decClose();
}
/** Parte la sessione FullFocus su quella task, intensiva: e' cosi' che il punto si conferma. */
function pkPartiAdesso(){
  if (typeof decClose === 'function') decClose();
  try{
    if (typeof ffPref === 'function'){
      const p = ffPref(); p.intent = PK.task; p.intensive = true;
      if (typeof ffSavePref === 'function') ffSavePref();
    }
    if (typeof stSaltaSync === 'function') stSaltaSync();
    if (typeof ffOpen === 'function') ffOpen();
  }catch(_){ }
}
/* ---------------------------------------------------------------------------------------
   LA PORTA 2: le decisioni del tuo agente personale, con il conto alla rovescia che sparisce
   --------------------------------------------------------------------------------------- */
function pkDecMin(){
  try{ const c = (typeof mgCfg === 'function') ? mgCfg() : {}; const n = parseFloat(c.decMin); return n > 0 ? n : 1; }catch(_){ return 1; }
}
function pkRisposte(){ return pkLeggi(PK_RISP_KEY, []) || []; }
/** Le decisioni che l'agente ha depositato e a cui non ho ancora risposto (tre giorni al massimo). */
function pkDecisioniPendenti(){
  let v = null;
  try{ v = (typeof jdCache === 'function') ? (jdCache() || {}).verdetto : null; }catch(_){ }
  if (!v || !Array.isArray(v.decisioni)) return [];
  /* 0.9.278, Andrea: "Domani apri prima Claude per il tool o la telecamera per l'UGC? Io non devo fare nessun video".
     Le decisioni arrivavano da Jordan, l'agente sul VPS, che vede solo i numeri della giornata e non quello che sa il
     Genio. Nell'app si mostrano solo le decisioni scritte dal tuo agente personale (fonte "agente"), che conosce la tua roadmap. */
  if (!v.decisioni.some(function(d){ return d && d.fonte === 'agente'; })) return [];
  const risposte = {}; pkRisposte().forEach(function(r){ risposte[r.id] = 1; });
  const vecchio = (v.at || 0) < Date.now() - 3 * 86400000;
  return v.decisioni.filter(function(d){
    if (!(d && d.id && d.domanda && d.a && d.b && !risposte[d.id] && !vecchio)) return false;
    /* UNA DECISIONE CHE NOMINA UN'APP PRODUTTIVA NON SI MOSTRA. «Domani blocchi Claude Code»
       e' arrivata davvero: l'agente vedeva l'app in cima al tempo del computer. Il filtro sta
       qui perche' e' l'app a sapere cosa e' produttivo, e a decidere cosa mostrare. */
    /* «SILENZI CLAUDE CODE» (1/10): il filtro guardava solo blocca/limita/rinuncia/chiudi/spegni,
       e «silenzia» passava. Adesso basta che la decisione nomini un'app produttiva o neutra
       insieme a QUALSIASI verbo che la tolga di mezzo. */
    try{ const tx = d.domanda + ' ' + d.a + ' ' + d.b; if (typeof jdNominaProtetta === 'function' && /blocc|limit|rinunc|chiud|spegn|silenz|mut[ao]|ferm|paus|stop|riduc|tagli|rinvi|evit|lasci|senza|niente|proibi|viet/i.test(tx) && jdNominaProtetta(tx)) return false; }catch(_){ }
    return true;
  });
}
function pkDecisioneApri(d){
  if (typeof decOpen !== 'function' || (typeof DEC !== 'undefined' && DEC.open)) return;
  PK.dec = d;
  PK.scadeAt = Date.now() + pkDecMin() * 60000;
  decOpen('custom', {
    kicker: d.kicker || 'Il tuo agente personale ti chiede',
    title: 'DECIDI ADESSO',
    line: pkEsc(d.domanda),
    left: pkEsc(d.a), right: pkEsc(d.b), leftClass: 'yes',
    leftAct: 'pkRisposta(\'a\')', rightAct: 'pkRisposta(\'b\')',
    extra: '<div class="dec-timer" id="pkTimer">' + pkMmSs(PK.scadeAt - Date.now()) + '</div>',
    foot: ''
  });
  pkTimerAvvia();
}
function pkMmSs(ms){ const s = Math.max(0, Math.ceil(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
/* Il conto alla rovescia si vede tre secondi — il tempo di capire che c'e' — poi sparisce:
   sotto pressione non si decide, si scappa. Torna solo quando e' scaduto. */
function pkTimerAvvia(){
  clearInterval(PK.timer);
  const t0 = Date.now();
  PK.timer = setInterval(function(){
    const el = (typeof document !== 'undefined') ? document.getElementById('pkTimer') : null;
    if (!el || (typeof DEC !== 'undefined' && !DEC.open)){ clearInterval(PK.timer); return; }
    const resta = PK.scadeAt - Date.now();
    if (resta <= 0){ el.textContent = 'TEMPO SCADUTO'; el.classList.add('scaduto'); el.classList.remove('via'); clearInterval(PK.timer); return; }
    el.textContent = pkMmSs(resta);
    if (Date.now() - t0 > PK_TIMER_VISTA_MS) el.classList.add('via');
  }, 250);
}
function pkRisposta(k){
  const d = PK.dec; if (!d) return;
  clearInterval(PK.timer);
  const adesso = Date.now();
  const inTempo = adesso <= PK.scadeAt;
  const secondi = Math.max(1, Math.round((adesso - (PK.scadeAt - pkDecMin() * 60000)) / 1000));
  const scelta = k === 'a' ? d.a : d.b;
  const l = pkRisposte();
  l.push({ id: d.id, scelta: k, testo: scelta, domanda: d.domanda, at: adesso, inTempo: inTempo, secondi: secondi });
  pkScrivi(PK_RISP_KEY, l.slice(-100));
  let r = null;
  if (inTempo) r = pkPrenota('decisione', d.domanda, { decId: d.id, scelta: scelta }, adesso);
  if (typeof decResultCon === 'function') decResultCon(
    inTempo
      ? 'Deciso in <b>' + secondi + ' secondi</b>: <b>' + pkEsc(scelta) + '</b>.<br>+1 al nuovo te, prenotato: lo tieni se la decisione la mantieni. Se torni indietro, torna indietro anche lui.'
      : 'Deciso: <b>' + pkEsc(scelta) + '</b>. Fuori tempo, nessun punto. La decisione però e’ presa: adesso tienila.',
    inTempo ? 1 : null, true,
    ['<button type="button" class="dec-opt yes" onclick="decClose()">VADO</button>'],
    inTempo ? 'Prenotato' : 'Registrato');
  PK.dec = null;
  try{ if (typeof jdDeposita === 'function') jdDeposita(true); }catch(_){ }
}
/** Il verdetto dell'agente: le revoche (decisione non mantenuta) e le nuove decisioni. */
function pkDaVerdetto(v){
  if (!v) return;
  try{
    (Array.isArray(v.revoche) ? v.revoche : []).forEach(function(x){
      if (!x || !x.id) return;
      const r = pkLista().filter(function(p){ return p.decId === x.id && p.stato === 'prenotato'; })[0];
      if (r) pkRevoca(r.id, 'Decisione non mantenuta: ' + (x.motivo || 'sei tornato indietro'));
    });
  }catch(_){ }
  const pend = pkDecisioniPendenti();
  if (pend.length && !PK.mostrata[pend[0].id]){ PK.mostrata[pend[0].id] = 1; setTimeout(function(){ pkDecisioneApri(pend[0]); }, 800); }
}
/** Quello che va depositato per l'agente: le prenotazioni recenti e le risposte date. */
function pkPerAgente(){
  const da = Date.now() - 7 * 86400000;
  return {
    prenotazioni: pkLista().filter(function(x){ return x.at >= da; }).map(function(x){
      return { id: x.id, tipo: x.tipo, testo: x.testo, stato: x.stato, at: x.at, punti: x.punti, decId: x.decId || '', scelta: x.scelta || '', motivo: x.motivo || '' };
    }),
    decisioniRisposte: pkRisposte().filter(function(x){ return x.at >= da; })
  };
}

/* ---------------------------------------------------------------------------------------
   I GANCI
   --------------------------------------------------------------------------------------- */
if (typeof document !== 'undefined'){
  /* la riga spuntata con la prova (sessione vista) conferma la prenotazione con quel testo */
  document.addEventListener('fl:spunta', function(){
    try{
      const oggi = pkKey();
      const done = (pkLeggi('fl_notes_done', []) || []).filter(function(x){ return x && x.day === oggi && x.verified; });
      pkAperte('passo').forEach(function(r){
        const d = done.filter(function(x){ return pkNorm(x.text) === pkNorm(r.testo); })[0];
        if (d) pkConferma(r.id, d.at || Date.now());
      });
    }catch(_){ }
  });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) pkControlla(); });
  setTimeout(pkControlla, 2500);
  setInterval(pkControlla, 10 * 60000);
  /* le decisioni in sospeso si presentano quando si apre una scheda, mai da sole */
  document.addEventListener('fl:tab', function(e){
    if (['blocco', 'severa', 'sveglia'].indexOf(e.detail) < 0) return;
    setTimeout(function(){
      const pend = pkDecisioniPendenti();
      if (pend.length && !PK.mostrata[pend[0].id]){ PK.mostrata[pend[0].id] = 1; pkDecisioneApri(pend[0]); }
    }, 2200);
  });
  document.addEventListener('DOMContentLoaded', function(){
    if (typeof jdLeggi === 'function' && !jdLeggi.__pk){
      const orig = jdLeggi;
      const w = async function(f){ const v = await orig(f); try{ pkDaVerdetto(v); }catch(_){ } return v; };
      w.__pk = true; w.__rev = orig.__rev; jdLeggi = w;
    }
  });

  (function pkStile(){
    const st = document.createElement('style');
    st.textContent = [
      '.dec-sub{display:block;margin-top:6px;font:500 12.5px/1.5 var(--font-body);color:rgba(226,243,255,.62)}',
      '.dec-timer{margin-top:16px;font:800 30px/1 var(--font-display);font-style:italic;letter-spacing:.06em;color:#EAF6FF;text-shadow:0 0 18px rgba(90,200,255,.7);transition:opacity .6s ease}',
      '.dec-timer.via{opacity:0}',
      '.dec-timer.scaduto{font-size:16px;letter-spacing:.2em;color:#FF9AA2;text-shadow:0 0 18px rgba(240,80,110,.5)}',
      '.pz-r.revoca i{filter:grayscale(1);opacity:.6}',
      '.pkp-voci{display:grid;gap:8px;margin:4px 0 6px}',
      '.pkp-voce{display:flex;align-items:center;gap:12px;width:100%;padding:14px;border-radius:14px;border:1.5px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#FFFFFF;text-align:left}',
      '.pkp-voce b{flex:1;font:700 15.5px/1.4 var(--font-body)}',
      '.pkp-r{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.5)}',
      '.pkp-voce.on{border-color:#8CC6FF;background:rgba(140,198,255,.1)}.pkp-voce.on .pkp-r{border-color:#8CC6FF;box-shadow:inset 0 0 0 4px #14234A;background:#BCE0FF}',
      '.pkp-gia{padding:12px 14px;border-radius:14px;background:rgba(0,117,227,.18);margin:0 0 12px}.pkp-gia small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.pkp-gia p{margin:4px 0 0;font:600 15px/1.4 var(--font-body);color:#FFFFFF}',
      '.pkp-time{color-scheme:dark;max-width:180px}',
      '.pkg{display:flex;flex-direction:column;padding-top:6px}.pkg .stg-h{margin:10px 0 24px}',
      '.pkg-passo{padding:22px 18px;border-radius:20px;background:var(--dream);color:#0E2350;margin:0 0 32px}.pkg-passo b{display:block;font:800 19px/1.4 var(--font-display,var(--font-body))}',
      '.pkg-sotto{margin:-10px 0 24px;font:600 15px/1.45 var(--font-body);color:var(--muted,#4A5A72)}',
      '.pkg-ore{gap:10px;margin:0 0 32px}.pkg .stg-cta{margin-top:0}.pkg .stg-link{margin-top:10px}',
      '.rmp-prenota{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:4px 8px;width:100%;margin-top:12px;padding:14px;border:0;border-radius:14px;background:#0075E3;color:#FFFFFF;font:800 16px var(--font-body)}',
      '.rmp-prenota small{flex-basis:100%;text-align:center;font:600 13px var(--font-body);opacity:.85}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { pkPrenota: pkPrenota, pkConferma: pkConferma, pkRevoca: pkRevoca, pkConfermaTask: pkConfermaTask,
                     pkControlla: pkControlla, pkLista: pkLista, pkAperte: pkAperte, pkDaVerdetto: pkDaVerdetto,
                     pkDecisioniPendenti: pkDecisioniPendenti, pkRisposta: pkRisposta, PK: PK, PK_DOPPIO_MIN: PK_DOPPIO_MIN,
                     pkPuntiControlla: pkPuntiControlla, pkPuntoFatto: pkPuntoFatto };
}

/* ===========================================================================================
   0.9.344 — DOPO LA PRENOTAZIONE: PREPARARSI E BLINDARE
   Andrea: "prenotando il punto non c'e' modo di vedere il tutorial di quel passo o di farlo scomporre. E mi e' capitato di
   prenotare e perdermi lo stesso: servono le sponde del bowling, che rendono impossibile uscire dalla pista". Dopo "Prenoto il
   punto" il foglio propone quattro cose: i passi, il tutorial, parlarne con l'agente, e blindare il passo (domani, in quell'ora,
   le app che distraggono si bloccano da sole; il blocco sparisce quando l'ora e' passata).
   =========================================================================================== */
function pkBlindati(){ return pkLeggi('fl_blinda', {}) || {}; }
function pkHHMM(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function pkDopoHtml(r){
  const bl = !!pkBlindati()[r.id];
  const voce = function(ico, t, s, js){ return '<button type="button" class="pkd-v" onclick="' + js + '"><span aria-hidden="true">' + ico + '</span><div><b>' + t + '</b><small>' + s + '</small></div></button>'; };
  /* 0.9.347, Andrea: "quattro opzioni sono troppe, al massimo due, una a fianco all'altra. Parlane con il tuo agente e' superflua: scomporlo
     in passi E' parlarne con il tuo agente. E se tocco Scomponi o Tutorial il messaggio deve partire da solo, non restare nel campo".
     Due card affiancate; "Blinda il passo" resta sotto come interruttore, perche' non e' una cosa da fare: e' una protezione. */
  void voce;
  const card = function(ico, t, s, js){ return '<button type="button" class="pkd-c" onclick="' + js + '"><span aria-hidden="true">' + ico + '</span><b>' + t + '</b><small>' + s + '</small></button>'; };
  return '<small class="stg-eti">Prenotato</small><h2 class="stg-h">+1 al nuovo te</h2>'
    + '<div class="stg-ob"><small>Domani alle ' + pkOra(r.inizio) + '</small><b>' + pkEsc(r.testo) + '</b></div>'
    + '<p class="pkd-t">Preparati adesso, così domani parti subito</p>'
    + '<div class="pkd-due">'
    + card('🧩', 'Scomponilo in passi', 'Il tuo agente lo divide in tre passi piccoli', 'pkDopo(\'passi\')')
    + card('🎥', 'Guarda un tutorial', 'Il tuo agente trova il video giusto', 'pkDopo(\'video\')')
    + '</div><div class="pkd-l">'
    + '<button type="button" class="pkd-v pkd-bl' + (bl ? ' on' : '') + '" onclick="pkBlinda()" aria-pressed="' + (bl ? 'true' : 'false') + '"><span aria-hidden="true">🛡️</span><div><b>' + (bl ? 'Il passo è blindato' : 'Blinda il passo') + '</b>'
    + '<small>Domani dalle ' + pkOra(r.inizio) + ' alle ' + pkOra(r.fine) + ' le app che ti distraggono ' + (bl ? 'restano bloccate.' : 'si bloccano da sole.') + '</small></div><i class="pkd-sw" aria-hidden="true"></i></button>'
    + '</div><button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho finito</button>';
}
function pkAppDistraggono(){
  const out = {};
  try{ (typeof APPS_CACHE !== 'undefined' ? APPS_CACHE : []).forEach(function(a){ if (a && a.packageName && typeof scIsDistracting === 'function' && scIsDistracting(a.packageName)) out[a.packageName] = 1; }); }catch(_){ }
  try{ if (!Object.keys(out).length && typeof SC_DEFAULT_DISTRACT !== 'undefined') SC_DEFAULT_DISTRACT.forEach(function(p){ out[p] = 1; }); }catch(_){ }
  try{ const c = (typeof insCats === 'function') ? insCats() : {}; Object.keys(c).forEach(function(p){ if (c[p] === 'distr') out[p] = 1; }); }catch(_){ }
  try{ if (typeof QUICK !== 'undefined') (QUICK.apps || []).forEach(function(p){ out[p] = 1; }); }catch(_){ }
  delete out['com.dreambrothers.focuslock'];
  return Object.keys(out);
}
function pkProgrammaTogli(pid){
  try{
    if (typeof PROGRAMS === 'undefined') return;
    const i = PROGRAMS.findIndex(function(x){ return x.id === pid; }); if (i < 0) return;
    PROGRAMS.splice(i, 1); saveProgramsLocal();
    try{ renderPrograms(); }catch(_){ } try{ pushRules(); }catch(_){ } try{ syncNative(); }catch(_){ }
  }catch(_){ }
}
function pkBlinda(){
  const r = PK_PUNTO.ultimo; if (!r) return;
  const m = pkBlindati();
  if (m[r.id]){ pkProgrammaTogli(m[r.id].pid); delete m[r.id]; pkScrivi('fl_blinda', m); try{ flVibra(10); }catch(_){ } }
  else {
    const app = pkAppDistraggono();
    if (!app.length || typeof frProgrammaDaAgente !== 'function'){ if (typeof toast === 'function') toast('Non trovo app da bloccare. Nel Report segna quali app ti distraggono, poi riprova.'); return; }
    const giorni = [false, false, false, false, false, false, false]; giorni[(new Date(r.inizio).getDay() + 6) % 7] = true;
    const pid = frProgrammaDaAgente({ nome: 'Passo blindato', app: app, dalle: pkHHMM(r.inizio), alle: pkHHMM(r.fine), giorni: giorni, zitto: true }, false);
    if (!pid){ if (typeof toast === 'function') toast('Il blocco non si è creato: riprova fra un attimo.'); return; }
    try{ const p = PROGRAMS.filter(function(x){ return x.id === pid; })[0]; if (p){ p.icon = '🛡️'; p.blindato = r.id; saveProgramsLocal(); try{ renderPrograms(); }catch(_){ } } }catch(_){ }
    m[r.id] = { pid: pid, fine: r.fine }; pkScrivi('fl_blinda', m);
    try{ flVibra([14, 40, 14]); }catch(_){ }
  }
  if (typeof stgFoglioCorpo === 'function') stgFoglioCorpo(pkDopoHtml(r));
}
/* un passo blindato dura solo la sua ora: passata quella, il blocco si toglie da solo */
function pkBlindaPulisci(){
  try{
    const m = pkBlindati(); let cambiato = false;
    Object.keys(m).forEach(function(id){ if (m[id] && m[id].fine && Date.now() > m[id].fine + 60000){ pkProgrammaTogli(m[id].pid); delete m[id]; cambiato = true; } });
    if (cambiato) pkScrivi('fl_blinda', m);
  }catch(_){ }
}
setTimeout(pkBlindaPulisci, 9000); setInterval(pkBlindaPulisci, 5 * 60000);
function pkDopo(tipo){
  const r = PK_PUNTO.ultimo; if (!r) return;
  const t = String(r.testo || '');
  const via = function(){
    if (tipo === 'chat'){
      /* la domanda si scrive nel campo: parte solo quando la manda lui */
      if (typeof agApri === 'function'){ agApri(); setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza('Domani alle ' + pkOra(r.inizio) + ' faccio questa cosa: "' + t + '". Da dove mi conviene partire?'); }catch(_){ } }, 400); }
      return;
    }
    const testo = tipo === 'video'
      ? 'Trovami un tutorial video che mostri come fare questa cosa, e dimmi quanto tempo darmi per guardarlo: "' + t + '"'
      : 'Scomponi questa cosa da fare in 3 passi al massimo, da pochi minuti ciascuno, così so da dove partire: "' + t + '"';
    /* 0.9.347: questi due partono da soli (Andrea: "deve scomporlo e cercare il tutorial, mandando direttamente il messaggio") */
    if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo, { invia: true, titolo: tipo === 'video' ? 'Il tutorial di domani' : 'Il passo di domani in tre passi' });
  };
  try{ stgFoglioChiudi(); }catch(_){ }
  /* dentro una revisione: prima la revisione si chiude con la sua schermata di fine, poi parte la richiesta */
  if (typeof rvfInRevisione === 'function' && rvfInRevisione()){ RVF.dopo = via; rvfChiudiRevisione(); }
  else setTimeout(via, 280);
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.pkd-t{margin:22px 0 12px;text-align:center;font:800 15px/1.35 var(--font-display);color:var(--navy)}body.dark .pkd-t{color:#fff}',
    '.pkd-l{display:flex;flex-direction:column;gap:10px;margin-bottom:22px}',
    /* 0.9.347: le due scelte affiancate, e l'ora libera */
    '.pkt{text-align:center}.pkt-ico{font-size:54px;line-height:1;margin:10px 0 16px}.pkt .stg-p{margin:0 0 8px}.pkt .stg-p + .stg-cta{margin-top:18px}',
    '.pkd-due{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:0 0 16px}',
    '.pkd-c{display:flex;flex-direction:column;align-items:center;gap:8px;padding:18px 12px;border-radius:20px;border:1.5px solid #C8EFFD;background:#F0FBFF;text-align:center;cursor:pointer;box-shadow:0 6px 16px rgba(0,117,227,.08);font-family:var(--font-body)}',
    '.pkd-c span{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;background:#fff;font-size:26px;box-shadow:0 4px 10px rgba(0,117,227,.12)}',
    '.pkd-c b{font:800 15px/1.25 var(--font-body);color:var(--navy)}.pkd-c small{font:500 12.5px/1.35 var(--font-body);color:var(--muted)}.pkd-c:active{transform:scale(.97)}',
    'body.dark .pkd-c{background:#12203A;border-color:#22345A}body.dark .pkd-c span{background:#0B1830}',
    '.pkg-ore .pkg-altra{padding-left:16px;padding-right:16px}.pkg-ora-libera{display:block;width:100%;box-sizing:border-box;margin:4px 0 18px;font:700 20px var(--font-body);text-align:center}',
    '.pkd-v{display:flex;align-items:center;gap:14px;width:100%;padding:14px 16px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer;font:inherit;color:var(--navy)}.pkd-v > span{flex:none;width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;background:#E3F1FF}',
    '.pkd-v > div{flex:1;min-width:0}.pkd-v b{display:block;font:800 15.5px/1.3 var(--font-body);color:var(--navy)}.pkd-v small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.pkd-sw{flex:none;position:relative;width:46px;height:28px;border-radius:99px;background:#C9D9EE;transition:background .2s}.pkd-sw::after{content:"";position:absolute;left:3px;top:3px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,30,68,.25);transition:transform .2s}',
    '.pkd-bl.on{border-color:#0075E3;background:rgba(0,117,227,.06)}.pkd-bl.on .pkd-sw{background:#0075E3}.pkd-bl.on .pkd-sw::after{transform:translateX(18px)}',
    'body.dark .pkd-v{background:#12203A;border-color:#22345A}body.dark .pkd-v b{color:#fff}body.dark .pkd-v > span{background:#1B2C4F}body.dark .pkd-sw{background:#2C4170}'
  ].join('\n');
  document.head.appendChild(st);
})();
