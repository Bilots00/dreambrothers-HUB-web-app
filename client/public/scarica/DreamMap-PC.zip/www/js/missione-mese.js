/* ===========================================================================================
   LA MISSIONE DEL MESE (0.9.310, Andrea, screenshot 748 di Duolingo: dopo "Hai completato tutte
   le missioni giornaliere!", sotto alle tre missioni, il riquadro "Missione di ottobre 20/20",
   prima di "Apri forziere")

   La missione: "Completa 20 tappe della mappa" nel mese. Il conto e' VERO: le tappe fatte nel
   mese, contate come la serie (sdGiorniFatti di sentiero-mappa.js: ogni tappa della mappa con la
   sua data, le mystery box escluse, i giorni coperti da una congelazione no). Mai inventato.

   L'OBIETTIVO: 20 tappe. Chi arriva a meta' mese non puo' farne 20 in dieci giorni senza correre:
   se al primo sguardo del mese mancano meno di 20 giorni alla fine, l'obiettivo e' un giorno per
   giorno che resta (minimo 5). Si scrive la prima volta che la missione compare e non cambia piu'
   per tutto il mese (fl_mdm.tot), cosi' nessun numero si sposta sotto agli occhi.

   IL PREMIO: una mystery box con il premio garantito EPICO (un giorno di Premium) o, a chi e' gia'
   Premium, LEGGENDARIO (+120 monete): SD_BOX_GARANZIA 'premium' di sentiero-mappa.js. Si apre
   appena la missione e' completata, dalla schermata delle missioni o dalla scheda Sfide; se il
   mese finisce prima di averla aperta, resta da aprire per tutto il mese dopo.

   Dove si vede: la schermata delle missioni (s-sd-missioni, sdMisApri) sotto alle tre missioni
   del giorno, sempre scura; la scheda Sfide di Amici (sfMissioniHtml), sotto alle giornaliere.
   =========================================================================================== */
const MDM_KEY = 'fl_mdm';                  /* { tot: {'aaaa-mm': n}, prese: {'aaaa-mm': ms}, viste: {k, n} } */
const MDM_OBIETTIVO = 20;
const MDM_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const MDM_STELLA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.2l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z" fill="#FFC53D" stroke="#C98A00" stroke-width="1.2" stroke-linejoin="round"/></svg>';

function mdmEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function mdmLeggi(){ let s = null; try{ s = JSON.parse(localStorage.getItem(MDM_KEY) || 'null'); }catch(_){ } s = s || {}; s.tot = s.tot || {}; s.prese = s.prese || {}; s.viste = s.viste || {}; return s; }
function mdmSalva(s){ try{ localStorage.setItem(MDM_KEY, JSON.stringify(s)); }catch(_){ } }
function mdmK(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
function mdmPrima(k){ const p = k.split('-'); const d = new Date(+p[0], +p[1] - 2, 15); return mdmK(d.getTime()); }
/** Il primo giorno del mese dopo, in parole: "1° dicembre". */
function mdmProssimo(k){ const p = k.split('-'); return '1° ' + MDM_MESI[(+p[1]) % 12]; }

/** L'obiettivo del mese k: scritto una volta, poi fisso. */
function mdmTot(k){
  const s = mdmLeggi();
  if (s.tot[k]) return s.tot[k];
  if (k !== mdmK()) return MDM_OBIETTIVO;
  const oggi = new Date();
  const giorniMese = new Date(oggi.getFullYear(), oggi.getMonth() + 1, 0).getDate();
  const restano = giorniMese - oggi.getDate() + 1;
  const tot = restano >= MDM_OBIETTIVO ? MDM_OBIETTIVO : Math.max(5, restano);
  s.tot[k] = tot; mdmSalva(s);
  return tot;
}
/** Le tappe della mappa fatte nel mese k: i giorni veri della serie, con il loro numero di tappe. */
function mdmConta(k){
  let g = {}; try{ g = sdGiorniFatti(); }catch(_){ return 0; }
  let n = 0;
  Object.keys(g).forEach(function(d){ if (d.indexOf(k + '-') === 0 && g[d] > 0) n += g[d]; });
  return n;
}
function mdmDati(k){
  k = k || mdmK();
  const p = k.split('-');
  const tot = mdmTot(k), conta = mdmConta(k), s = mdmLeggi();
  const n = Math.min(tot, conta);
  return { k: k, mese: MDM_MESI[(+p[1]) - 1], tot: tot, n: n, fatta: n >= tot, presa: !!s.prese[k] };
}
/** Le missioni del mese completate e non ancora riscosse: quella di adesso e quella del mese prima. */
function mdmDaRiscuotere(){
  const cur = mdmK(), prima = mdmPrima(cur), s = mdmLeggi();
  const out = [];
  if (s.tot[prima]){ const d = mdmDati(prima); if (d.fatta && !d.presa) out.push(d); }
  const d = mdmDati(cur); if (d.fatta && !d.presa) out.push(d);
  return out;
}
/** Segna riscosse le missioni completate e da' gli id delle loro mystery box (premio garantito). */
function mdmRiscuoti(){
  const da = mdmDaRiscuotere(); if (!da.length) return [];
  const s = mdmLeggi();
  const ids = da.map(function(d){
    s.prese[d.k] = Date.now();
    const id = 'sc:mese:' + d.k;
    try{ if (typeof SD_BOX_GARANZIA !== 'undefined') SD_BOX_GARANZIA[id] = 'premium'; }catch(_){ }
    return id;
  });
  mdmSalva(s);
  return ids;
}
/** La missione del mese appena completata e mai vista completata: la schermata delle missioni si apre per lei. */
function mdmNuovaFatta(){ const d = mdmDati(), v = mdmLeggi().viste; return d.fatta && !d.presa && !(v.k === d.k && v.n >= d.tot); }
/** Dalla scheda Sfide: apre le mystery box delle missioni del mese completate. */
function mdmApri(){
  const ids = mdmRiscuoti(); if (!ids.length) return;
  try{ flVibra([20, 30, 60]); }catch(_){ }
  if (typeof sdScrignoApri !== 'function'){ toast('Missione del mese completata'); return; }
  if (typeof SD !== 'undefined'){ SD.codaScrigni = ids.slice(1); }
  sdScrignoApri(ids[0]);
}

/**
 * Il riquadro. modo 'scuro' = la schermata delle missioni (classi sd-mis-r / sd-mis-bar: la barra sale con le
 * altre, con lo stesso suono); 'sfide' = la scheda Sfide, chiara o scura come la pagina.
 */
function mdmBoxHtml(modo, k){
  const d = mdmDati(k);
  const pct = Math.round(d.n / d.tot * 100);
  const sotto = d.presa ? 'Completata: la prossima arriva il ' + mdmProssimo(d.k) + '.'
    : (d.fatta ? (modo === 'sfide' ? 'Completata: tocca per aprire la mystery box.' : 'Completata: la mystery box ti aspetta.')
    : 'Completa ' + d.tot + ' tappe della mappa');
  const med = '<span class="mdm-med' + (modo === 'scuro' ? ' sd-mis-ico' : '') + (d.fatta && !d.presa ? ' pronto' : '') + '"><img src="img/genio/genio-saluta.png" alt="">' + (d.fatta ? '<i class="mdm-stella">' + MDM_STELLA + '</i>' : '') + '</span>';
  if (modo === 'scuro'){
    const v = mdmLeggi(); const prima = (v.viste.k === d.k) ? Math.min(d.n, v.viste.n || 0) : 0;
    v.viste = { k: d.k, n: d.n }; mdmSalva(v);
    const da = Math.round(prima / d.tot * 100);
    return '<div class="sd-mis-r mdm-box' + (d.fatta ? ' fatta' : '') + '"><div class="mdm-testo"><b>Missione di ' + d.mese + '</b><small>' + mdmEsc(sotto) + '</small>'
      + '<div class="sd-mis-riga"><div class="sd-mis-bar"><i style="width:' + da + '%" data-a="' + pct + '"></i><span>' + d.n + '/' + d.tot + '</span></div></div></div>' + med + '</div>';
  }
  const tocca = d.fatta && !d.presa;
  return '<div class="mdm-box sf' + (d.fatta ? ' fatta' : '') + (tocca ? ' tocca' : '') + '"' + (tocca ? ' role="button" onclick="mdmApri()"' : '') + '><div class="mdm-testo"><b>Missione di ' + d.mese + '</b><small>' + mdmEsc(sotto) + '</small>'
    + '<div class="mdm-bar"><i style="width:' + pct + '%"></i><span>' + d.n + '/' + d.tot + '</span></div></div>' + med + '</div>';
}
/** La sezione della scheda Sfide: il titolo con i giorni che restano, la missione del mese prima se da aprire, e quella di adesso. */
function mdmSezioneHtml(){
  try{
    const cur = mdmK(), oggi = new Date();
    const restano = new Date(oggi.getFullYear(), oggi.getMonth() + 1, 0).getDate() - oggi.getDate() + 1;
    const vecchie = mdmDaRiscuotere().filter(function(d){ return d.k !== cur; });
    if (typeof dsoMeseHtml === 'function'){ if (!vecchie.length) return ''; return '<div class="mdm-col">' + vecchie.map(function(d){ return mdmBoxHtml('sfide', d.k); }).join('') + '</div>'; }
    return '<div class="am-sect"><b>Missione del mese</b><span>⏱ ' + (restano === 1 ? 'ultimo giorno' : restano + ' giorni') + '</span></div>'
      + '<div class="mdm-col">' + vecchie.map(function(d){ return mdmBoxHtml('sfide', d.k); }).join('') + mdmBoxHtml('sfide', cur) + '</div>';
  }catch(_){ return ''; }
}

(function mdmStile(){
  const st = document.createElement('style');
  st.textContent = [
    /* la schermata delle missioni (sempre scura): bordo azzurro, barra azzurra, il Genio in un tondo bianco */
    /* il titolo della schermata resta d'oro anche in scuro (body.dark h2 di app.css lo faceva bianco) */
    'body.dark #sdMis .sd-mis-in h2{color:#FFB020}',
    '#sdMis .mdm-box{display:flex;align-items:center;gap:14px;flex:none;padding:16px 16px;border:2px solid #3F9FF4;border-radius:22px;background:#14234A;box-shadow:0 0 0 4px rgba(63,159,244,.10)}',
    '#sdMis .mdm-testo{flex:1;min-width:0;text-align:center}',
    '#sdMis .mdm-box b{margin:0 0 4px;font:900 17px var(--font-body);color:#fff}',
    '#sdMis .mdm-box small{display:block;margin-bottom:10px;font:700 13px var(--font-body);color:#BCE0FF}',
    '#sdMis .mdm-box .sd-mis-bar i{background:linear-gradient(180deg,#8CC6FF,#3F9FF4)}',
    '#sdMis .mdm-box.fatta .sd-mis-bar i{background:linear-gradient(180deg,#3F9FF4,#0075E3)}',
    /* il medaglione: tondo bianco (l'immagine non si mimetizza sul blu), anello azzurro, stella d'oro a missione fatta */
    '.mdm-med{position:relative;flex:none;width:66px;height:66px;border-radius:50%;background:#fff;border:3px solid #8CC6FF;display:flex;align-items:center;justify-content:center;font-size:0;filter:none !important}',
    '.mdm-med img{width:54px;height:54px;object-fit:contain;border-radius:50%}',
    '.mdm-stella{position:absolute;right:-6px;top:-6px;width:26px;height:26px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.25)}.mdm-stella svg{width:20px;height:20px}',
    '.mdm-box.fatta .mdm-med{border-color:#3F9FF4}',
    /* la scheda Sfide, chiara e scura */
    '.mdm-col{display:flex;flex-direction:column;gap:10px}',
    '.mdm-box.sf{display:flex;align-items:center;gap:14px;padding:14px 14px;border-radius:16px;background:var(--card,#fff);border:2px solid #3F9FF4}',
    'body.dark .mdm-box.sf{background:#12203A;border-color:#3F9FF4}',
    '.mdm-box.sf .mdm-testo{flex:1;min-width:0;text-align:center}',
    '.mdm-box.sf b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .mdm-box.sf b{color:#fff}',
    '.mdm-box.sf small{display:block;margin-top:2px;font:600 12.5px var(--font-body);color:var(--muted)}body.dark .mdm-box.sf small{color:#BCE0FF}',
    '.mdm-bar{position:relative;height:18px;border-radius:99px;background:rgba(0,117,227,.12);margin-top:8px;overflow:hidden}body.dark .mdm-bar{background:#22345A}',
    '.mdm-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(180deg,#8CC6FF,#3F9FF4);transition:width .4s}',
    '.mdm-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:800 11px var(--font-body);color:#0E2350}',
    '.mdm-box.sf .mdm-med{width:56px;height:56px}.mdm-box.sf .mdm-med img{width:46px;height:46px}',
    '.mdm-box.tocca{cursor:pointer}.mdm-box.tocca .mdm-med{animation:mdmSalta 1.1s ease-in-out infinite}',
    '@keyframes mdmSalta{50%{transform:translateY(-5px) rotate(-5deg)}}'
  ].join('\n');
  document.head.appendChild(st);
})();
