/* ===========================================================================================
   IL CAROSELLO DELLA SCHEDA PROFILO

   Sotto alle due card c'era un pannello solo — il tempo risparmiato — e faceva una cosa sola:
   dire quanto hai guadagnato. È una bella notizia, ma da sola non insegna niente, perché non
   dice se stai migliorando né da quanto stai tenendo botta.

   Quattro schede, una per domanda, in quest'ordine:

     0. DOVE STA ANDANDO LA MIA ENERGIA — la riserva di dopamina di oggi (dopamina.js), che
        si muove in tempo reale: scende dentro alle app che spremono, risale nel silenzio. E'
        la prima perche' e' l'unica che parla di ADESSO, e adesso e' l'unico momento in cui si
        puo' ancora cambiare qualcosa.
     1. DOVE STO ANDANDO — la media del tempo sullo schermo, e la curva. È la prima perché è
        l'unica che può dire «stai peggiorando» mentre sta succedendo. Prima di due settimane
        di dati non c'è nessuna curva da mostrare, e dirlo — «torna fra N giorni» — è più
        onesto che disegnare una linea inventata su tre punti.
     2. QUANTO HO GUADAGNATO — il tempo risparmiato, il numero grande al centro.
     3. DA QUANTO STO TENENDO — il record di settimane o mesi consecutivi con la Modalità
        severa accesa (o, senza Premium, con i blocchi mai messi in pausa). È l'ultima perché
        è quella che conta di più e va lasciata addosso: un record si guarda alla fine.

   Il numero grande al centro, non a sinistra: con una cifra sola e grossa l'occhio non deve
   cercare da dove comincia la riga, e il menù delle opzioni non gli sta davanti — sta nei tre
   puntini in alto a destra, dove sta in tutte le altre schede di questa app.
   =========================================================================================== */

let PFC_I = 0;

/* ---------------------------------------------------------------------------------------
   Scheda 1 — la media del tempo sullo schermo
   --------------------------------------------------------------------------------------- */

const PFC_MIN_GIORNI = 14;
/* Un giorno dura ventiquattro ore. Sembra ovvio, e invece era l'unica cosa che nessuno
   controllava: da qualche parte fra il motore e questa curva e' arrivata una media giornaliera
   di 285 ore, ed e' finita dritta sullo schermo come «278 ore in meno». */
const PFC_MAX_GIORNO_MS = 24 * 3600000;

/** Da quando quest'app esiste su questo telefono. Zero se non lo sappiamo. */
function pfcPrimoAvvio(){ return (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0; }

/** Da quanti giorni l'app e' su questo telefono. */
function pfcGiorniDaInstallazione(){
  return (typeof flGiorniDaPrimoAvvio === 'function') ? flGiorniDaPrimoAvvio() : 0;
}

/**
 * Le medie settimanali, dalle sessioni che il motore ha misurato.
 *
 * <p>Solo dal primo avvio in poi. I dati di utilizzo li tiene Android e riguardano il
 * telefono, non quest'app: esistono anche per i mesi prima dell'installazione, e usarli
 * vorrebbe dire confrontare l'oggi con un «prima» che non e' mai stato vissuto qui.</p>
 */
/* 0.9.306, Andrea: "la seconda slide del Profilo impiega troppo all'apertura dell'app, il Report invece e' subito".
   LA CAUSA: la curva chiedeva al motore 56 giornate UNA ALLA VOLTA (scReport: getDayReport, piu' la notte di ogni
   giorno letta dalla cronologia), in coda dietro a tutte le letture dell'avvio, anche i giorni prima che l'app ci
   fosse (il controllo del primo avvio veniva DOPO la lettura). Il Report legge le stesse settimane con UNA domanda
   sola, i giorni come secchielli (getScreenTimeRange a giorni), e la tiene in cache.
   Adesso: i giorni prima del primo avvio non si chiedono; i giorni gia' letti si prendono dalla memoria
   (fl_dayrep_, gli stessi del Report del giorno); quelli che mancano arrivano dalla STESSA lettura dei sessanta
   giorni della Tendenza del Report (stessa domanda, stessa chiave di cache). E la scheda mostra subito l'ultima
   versione disegnata (pfcRicorda), come il Report. */
/* i giorni passati letti dalla lettura unica: un giorno chiuso non cambia piu', e la volta dopo non si richiede */
const PFC_GIORNI_KEY = 'fl_pfc_giorni';
function pfcGiorniLetti(){ try{ const v = JSON.parse(localStorage.getItem(PFC_GIORNI_KEY) || '{}'); return v && typeof v === 'object' ? v : {}; }catch(_){ return {}; } }
function pfcGiornoSalvato(off, vero){
  try{
    const k = (typeof scKey === 'function' && typeof scDayStart === 'function') ? scKey(scDayStart(off)) : '';
    if (!k) return null;
    const m = (typeof SC !== 'undefined' && SC && SC.mem) ? SC.mem[k] : null;
    if (m && m.v && m.v.granted && (off > 0 || Date.now() - m.t < 45000)) return +m.v.screenMs || 0;
    if (off > 0){
      const v = JSON.parse(localStorage.getItem('fl_dayrep_' + k) || 'null');
      if (v && v.granted) return +v.screenMs || 0;
      const l = vero ? pfcGiorniLetti() : {};
      if (typeof l[k] === 'number') return l[k];
    }
  }catch(_){ }
  return null;
}
/** Il tempo sullo schermo dei giorni 0..n-1 (0 = oggi): un numero, o null se quel giorno non si sa. */
async function pfcGiorniMs(n){
  const out = new Array(n).fill(null);
  const nato = pfcPrimoAvvio();
  const vero = (typeof mwMotoreVero !== 'function' || mwMotoreVero()) && (typeof mwFonte !== 'function' || mwFonte() === 'telefono');
  const mancano = [];
  for (let off = 0; off < n; off++){
    if (nato && typeof scDayStart === 'function' && scDayStart(off) + 86400000 <= nato) continue;   // prima dell'app: non si chiede
    const v = pfcGiornoSalvato(off, vero);
    if (v !== null) out[off] = v; else if (off > 0) mancano.push(off);
  }
  /* oggi: la giornata che leggono tutti (scReport, una domanda sola e gia' condivisa) */
  if (out[0] === null){ try{ const r = await scReport(0); if (r && r.granted) out[0] = +r.screenMs || 0; }catch(_){ } }
  if (!mancano.length) return out;
  if (vero && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getScreenTimeRange){
    try{
      const ora = Date.now();
      const d0 = new Date(ora); d0.setHours(0, 0, 0, 0);
      const da = new Date(d0); da.setDate(da.getDate() - 59);
      const chiave = 'trend:' + da.getFullYear() + '-' + String(da.getMonth() + 1).padStart(2, '0') + '-' + String(da.getDate()).padStart(2, '0');
      const leggi = function(){ return NATIVE.getScreenTimeRange({ from: da.getTime(), to: ora, bucket: 'day' }); };
      const r = (typeof insGet === 'function') ? await insGet(chiave, leggi) : await leggi();
      const per = {};
      if (!(r && (r.dettaglioPerso || r.approx))) (r && r.buckets || []).forEach(function(b){ const g = new Date(b.start); g.setHours(0, 0, 0, 0); per[g.getTime()] = (per[g.getTime()] || 0) + (+b.ms || 0); });
      const letti = pfcGiorniLetti();
      mancano.forEach(function(off){ const k = scDayStart(off); if (per[k] != null){ out[off] = per[k]; letti[scKey(k)] = per[k]; } });
      try{ const tieni = {}; Object.keys(letti).sort().slice(-70).forEach(function(x){ tieni[x] = letti[x]; }); localStorage.setItem(PFC_GIORNI_KEY, JSON.stringify(tieni)); }catch(_){ }
      return out;
    }catch(_){ /* se la lettura unica non risponde, si torna ai giorni uno per uno */ }
  }
  for (const off of mancano){
    try{ const r = await scReport(off); if (r && r.granted) out[off] = +r.screenMs || 0; }catch(_){ }
  }
  return out;
}
async function pfcCurva(){
  const out = [];
  if (typeof scReport !== 'function') return out;
  const nato = pfcPrimoAvvio();
  /* Otto settimane: abbastanza per vedere una tendenza, poche abbastanza da non far aspettare
     mezzo secondo chi apre la scheda. */
  const giorni56 = await pfcGiorniMs(56);
  for (let w = 7; w >= 0; w--){
    let ms = 0, giorni = 0;
    for (let d = 0; d < 7; d++){
      const off = w * 7 + d;
      const v = giorni56[off];
      if (!(v > 0)) continue;
      if (nato && (typeof scDayStart === 'function') && scDayStart(off) < nato) continue;
      /* Un giorno impossibile si BUTTA, non si arrotonda: arrotondarlo a 24 ore lascerebbe
         comunque un dato inventato dentro a una media di dati veri. */
      if (v > PFC_MAX_GIORNO_MS) continue;
      ms += v; giorni++;
    }
    out.push({ w: w, media: giorni ? ms / giorni : 0, giorni: giorni });
  }
  return out;
}

/**
 * I sei mesi davanti, in discesa.
 *
 * <p>Un segnaposto, e si vede che lo e': tratteggiata, senza riempimento, sotto a una riga che
 * dice quando arriveranno i numeri veri. Parte dal mese corrente perche' e' l'unico punto che
 * chi guarda riconosce.</p>
 */
function pfcCurvaAttesa(){
  const out = [];
  const oggi = new Date();
  for (let m = 0; m < 6; m++){
    const d = new Date(oggi.getFullYear(), oggi.getMonth() + m, 1);
    out.push({ quando: d.getTime(), media: (6.2 - m * 0.85) * 3600000, giorni: 0 });
  }
  return out;
}

function pfcGiorniVisti(curva){
  const conDati = curva.reduce(function(s, x){ return s + x.giorni; }, 0);
  const daNascita = pfcGiorniDaInstallazione();
  /* Il piu' PICCOLO dei due. Un giorno senza dati non conta, ma nemmeno un giorno di dati
     che l'app non ha vissuto: bastava uno dei due controlli a mancare perche' la curva
     partisse su una storia che non era la sua. */
  return pfcPrimoAvvio() ? Math.min(conDati, daNascita) : conDati;
}

function pfcOreTxt(ms){
  const h = Math.floor(ms / 3600000), m = Math.round((ms % 3600000) / 60000);
  return h + 'h ' + String(m).padStart(2, '0') + 'm';
}

const PFC_MESI = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];

/**
 * La curva, con gli assi.
 *
 * <p>`preserveAspectRatio="none"` NON si puo' usare qui: schiaccia anche il testo, e le ore
 * a destra verrebbero fuori stirate. Il disegno quindi tiene le sue proporzioni, e la
 * larghezza del riquadro fa il resto.</p>
 *
 * <p>La scala delle ore parte SEMPRE da zero e arriva a un'ora intera: una scala che comincia
 * dal minimo dei dati fa sembrare una montagna una differenza di venti minuti — ed e' il modo
 * piu' comune di mentire con un grafico onesto.</p>
 */
function pfcSvg(curva, opts){
  opts = opts || {};
  const punti = curva.map(function(x){ return x.media; });
  const oreMax = Math.max(1, Math.ceil(Math.max.apply(null, punti.concat([0])) / 3600000));
  const max = oreMax * 3600000;

  const W = 320, H = 150;
  /* MARGINI UGUALI, o il disegno non e' al centro. Prima a destra c'erano 40 pixel per le ore
     e a sinistra 6: l'area del disegno stava spostata a sinistra di 17 pixel rispetto al
     riquadro, e si vedeva. Le ore adesso stanno dentro, sopra alla riga, a destra. */
  const L = 12, R = 12, T = 10, B = 24;
  const x0 = L, x1 = W - R, y0 = T, y1 = H - B;
  const xi = function(i){ return x0 + i * ((x1 - x0) / Math.max(1, punti.length - 1)); };
  const yi = function(v){ return y1 - (Math.min(v, max) / max) * (y1 - y0); };

  /* Quattro righe orizzontali, ai quarti: e' il numero che si legge in un colpo d'occhio
     senza contare. Opal ne usa quattro per lo stesso motivo. */
  let griglia = '';
  for (let k = 0; k <= 3; k++){
    const ore = Math.round(oreMax * k / 3);
    const y = yi(ore * 3600000);
    griglia += '<line x1="' + x0 + '" y1="' + y.toFixed(1) + '" x2="' + x1 + '" y2="' + y.toFixed(1) + '"'
      + ' stroke="currentColor" stroke-opacity=".14" stroke-width="1"/>'
      + '<text x="' + x1 + '" y="' + (y - 3).toFixed(1) + '" class="pfc-ax pfc-ax-h">' + ore + 'h</text>';
  }

  /* I MESI, uno per punto quando i punti SONO mesi, e uno per cambio quando sono settimane.
     Ogni punto si porta dietro la propria data (`quando`): leggerla dall'indice funzionava
     solo finche' la curva era settimanale, e si vedeva — due etichette ammucchiate a sinistra
     invece di una fila distanziata. */
  let mesi = '';
  let ultimo = -1;
  curva.forEach(function(p, i){
    const d = new Date(p.quando || (Date.now() - (p.w || 0) * 7 * 86400000));
    if (d.getMonth() === ultimo) return;
    ultimo = d.getMonth();
    mesi += '<text x="' + xi(i).toFixed(1) + '" y="' + (H - 6) + '" class="pfc-ax pfc-ax-m">'
      + PFC_MESI[d.getMonth()] + '</text>';
  });

  const linea = punti.map(function(v, i){ return (i ? 'L' : 'M') + xi(i).toFixed(1) + ' ' + yi(v).toFixed(1); }).join(' ');
  const area = linea + ' L' + xi(punti.length - 1).toFixed(1) + ' ' + y1 + ' L' + xi(0).toFixed(1) + ' ' + y1 + ' Z';

  return '<svg class="pfc-svg" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">'
    + '<defs><linearGradient id="pfcG" x1="0" y1="0" x2="0" y2="1">'
    +   '<stop offset="0%" stop-color="var(--neo-soft,#4FB8FF)" stop-opacity=".38"/>'
    +   '<stop offset="100%" stop-color="var(--neo-soft,#4FB8FF)" stop-opacity="0"/></linearGradient></defs>'
    + griglia + mesi
    /* Senza dati niente riempimento: un'area piena sotto a una curva che non esiste e' la
       parte che piu' di tutte fa sembrare veri dei numeri che non ci sono. */
    + (opts.tratteggiata ? '' : '<path d="' + area + '" fill="url(#pfcG)"/>')
    + '<path d="' + linea + '" fill="none" stroke="' + (opts.tratteggiata ? 'currentColor' : 'var(--neo-soft,#4FB8FF)')
    +   '" stroke-opacity="' + (opts.tratteggiata ? '.42' : '1') + '" stroke-width="2.5"'
    +   (opts.tratteggiata ? ' stroke-dasharray="6 5"' : '')
    +   ' stroke-linecap="round" stroke-linejoin="round"/>'
    + '</svg>';
}

async function pfcSlideMedia(){
  const curva = await pfcCurva();
  const visti = pfcGiorniVisti(curva);
  const ultima = curva.length ? curva[curva.length - 1].media : 0;

  if (visti < PFC_MIN_GIORNI){
    /* IL VIAGGIO È APPENA COMINCIATO, e va detto così. Una curva costruita su quattro giorni
       non è una tendenza: è rumore disegnato bene, e il primo consiglio sbagliato che ne esce
       costa più di tutte le settimane che si sono risparmiate aspettando. */
    const mancano = Math.max(1, PFC_MIN_GIORNI - visti);
    return '<p class="pfc-eyebrow">Tempo medio sullo schermo</p>'
      + '<h4 class="pfc-h">Il tuo viaggio comincia con le prime due settimane.</h4>'
      /* L'unica cosa di questa schermata su cui si puo' fare qualcosa — aspettare, e tornare.
         In grassetto nero stava allo stesso livello del resto; in blu sottolineato si vede
         che è il punto. */
      + '<p class="pfc-line">Torna <b class="pfc-quando">fra ' + mancano + (mancano === 1 ? ' giorno' : ' giorni') + '</b>: '
      + 'da lì in poi la curva dice qualcosa di vero.</p>'
      /* LA CURVA D'ATTESA GUARDA AVANTI, e a mesi.
         Non e' la storia che non c'e' ancora: e' dove si arriva continuando. Per questo i mesi
         sono quelli che verranno, uno per punto, distanziati uguali — con otto punti
         settimanali stavano tutti dentro a due mesi e uscivano ammucchiati a sinistra. */
      + '<div class="pfc-ghost">' + pfcSvg(pfcCurvaAttesa(), { tratteggiata: true }) + '</div>';
  }

  /* IL CONFRONTO SI FA CON LA SETTIMANA PIU' VECCHIA CHE ESISTE DAVVERO, e lo si dice.
     «Rispetto a otto settimane fa» era scritto sempre, anche quando otto settimane fa non
     c'era niente: una frase fissa sopra a un numero variabile e' il modo piu' semplice di
     raccontare una cosa falsa senza accorgersene. */
  let base = null;
  for (let i = 0; i < curva.length - 1; i++){
    if (curva[i].giorni > 0 && curva[i].media > 0){ base = curva[i]; break; }
  }
  if (!base){
    return '<p class="pfc-eyebrow">Tempo medio sullo schermo</p>'
      + '<b class="pfc-big">' + pfcOreTxt(ultima) + '</b>'
      + '<p class="pfc-line">Ancora nessuna settimana con cui confrontarlo: questa è la prima.</p>'
      + pfcSvg(curva);
  }
  const delta = ultima - base.media;
  const sett = base.w;
  const quando = sett === 1 ? 'alla settimana scorsa'
    : 'a ' + sett + ' settimane fa';
  return '<p class="pfc-eyebrow">Tempo medio sullo schermo</p>'
    + '<b class="pfc-big">' + pfcOreTxt(ultima) + '</b>'
    + '<p class="pfc-line">'
    + (delta < 0 ? '<b class="giu">↓ ' + pfcOreTxt(-delta) + ' in meno</b>' : '<b class="su">↑ ' + pfcOreTxt(delta) + ' in più</b>')
    + ' rispetto ' + quando + '.</p>'
    + pfcSvg(curva);
}

/* ---------------------------------------------------------------------------------------
   Scheda 3 — da quanto stai tenendo
   --------------------------------------------------------------------------------------- */

const PFC_TFS = [['mese', 'Mesi'], ['settimana', 'Settimane'], ['anno', 'Anni'], ['giorno', 'Giorni']];

function pfcTf(){
  try{ const v = localStorage.getItem('fl_pfc_tf'); return PFC_TFS.some(x => x[0] === v) ? v : 'mese'; }
  catch(_){ return 'mese'; }
}
function pfcSetTf(v){
  try{ localStorage.setItem('fl_pfc_tf', v); }catch(_){ }
  pfcMenuClose();
  pfcPaint();
}

/** Da quanti giorni la difesa è accesa senza interruzioni. */
function pfcGiorniTenuti(){
  /* La Modalità severa tiene una data d'inizio; senza Premium vale la stessa cosa misurata
     sui blocchi: il giorno dell'ultima interruzione è il giorno in cui la serie si è rotta. */
  let da = 0;
  try{
    const sev = JSON.parse(localStorage.getItem('fl_strict') || 'null');
    if (sev && sev.since) da = Math.max(da, Math.floor((Date.now() - +sev.since) / 86400000));
  }catch(_){ }
  if (!da){
    try{
      const log = (typeof itLog === 'function') ? itLog() : {};
      const giorni = Object.keys(log).sort();
      const ultimo = giorni.length ? giorni[giorni.length - 1] : '';
      let inizio = '';
      try{ inizio = localStorage.getItem('fl_first_run') || ''; }catch(_){ }
      /* 0.9.288: fl_first_run puo' essere un numero: lo legge flPrimoAvvio (registry.js) */
      const t0 = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0;
      const base = ultimo ? new Date(ultimo + 'T00:00:00') : (t0 ? new Date(t0) : (inizio ? new Date(inizio) : null));
      if (base && !isNaN(base)) da = Math.max(0, Math.floor((Date.now() - base.getTime()) / 86400000));
    }catch(_){ }
  }
  return da;
}

function pfcRecord(giorni){
  let best = 0;
  try{ best = +localStorage.getItem('fl_pfc_best') || 0; }catch(_){ }
  if (giorni > best){
    best = giorni;
    try{ localStorage.setItem('fl_pfc_best', String(best)); }catch(_){ }
  }
  return best;
}

function pfcNumero(giorni, tf){
  if (tf === 'giorno') return { n: giorni, u: giorni === 1 ? 'giorno' : 'giorni' };
  if (tf === 'settimana'){ const n = Math.floor(giorni / 7); return { n: n, u: n === 1 ? 'settimana' : 'settimane' }; }
  if (tf === 'anno'){ const n = Math.floor(giorni / 365); return { n: n, u: n === 1 ? 'anno' : 'anni' }; }
  const n = Math.floor(giorni / 30);
  return { n: n, u: n === 1 ? 'mese' : 'mesi' };
}

/* La frase sotto il numero. Cambia con il risultato, come fa Wispr Flow: un numero senza una
   frase è una statistica, un numero con la frase giusta è un motivo per non rompere la serie. */
function pfcFrase(giorni){
  if (giorni >= 365) return 'Un anno intero. Non stai più resistendo: sei diventato un\'altra persona.';
  if (giorni >= 180) return 'Sei mesi. Da qui in giù non si torna per sbaglio.';
  if (giorni >= 90) return 'Tre mesi. Stai diventando una leggenda vivente.';
  if (giorni >= 30) return 'Un mese pieno. Quello che hai costruito adesso ti appartiene.';
  if (giorni >= 7) return 'Più di una settimana. La parte difficile è già dietro di te.';
  if (giorni >= 1) return 'La serie è partita. Il primo giorno è quello che costa di più.';
  return 'La serie comincia il giorno in cui non interrompi niente.';
}

function pfcSlideSerie(){
  const giorni = pfcGiorniTenuti();
  const best = pfcRecord(giorni);
  const tf = pfcTf();
  const ora = pfcNumero(giorni, tf);
  const rec = pfcNumero(best, tf);
  return '<p class="pfc-eyebrow">Difesa attiva, senza interruzioni</p>'
    + '<b class="pfc-big">' + ora.n + ' <small>' + ora.u + '</small></b>'
    + '<p class="pfc-line">' + pfcFrase(giorni) + '</p>'
    + (best > giorni ? '<p class="pfc-rec">Il tuo record: <b>' + rec.n + ' ' + rec.u + '</b></p>' : '');
}

/* ---------------------------------------------------------------------------------------
   Il menù dei tre puntini — lo stesso di tutte le altre schede
   --------------------------------------------------------------------------------------- */

function pfcMenuClose(){
  const m = document.getElementById('pfcMenu');
  if (m) m.remove();
  const v = document.getElementById('pfcVeil');
  if (v) v.remove();
}

function pfcMenuOpen(ev){
  if (ev) ev.stopPropagation();
  if (document.getElementById('pfcMenu')){ pfcMenuClose(); return; }
  const host = document.getElementById('pfcCard');
  if (!host) return;
  if (!document.getElementById('pfcVeil')){
    const v = document.createElement('div');
    v.id = 'pfcVeil';
    v.className = 'arb-veil';
    v.addEventListener('click', function(e){ e.stopPropagation(); pfcMenuClose(); });
    (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(v);
  }
  const m = document.createElement('div');
  m.className = 'arb-menu';
  m.id = 'pfcMenu';
  m.innerHTML = (PFC_I === 0 && typeof DP_VISTE !== 'undefined'
      ? DP_VISTE.map(function(t){
          return '<button type="button" class="' + (t[0] === dpVista() ? 'on' : '') + '" onclick="pfcDpVista(\'' + t[0] + '\')">'
            + t[1] + '</button>'; })
      : PFC_I === 3
      ? PFC_TFS.map(function(t){
          return '<button type="button" class="' + (t[0] === pfcTf() ? 'on' : '') + '" onclick="pfcSetTf(\'' + t[0] + '\')">'
            + t[1] + '</button>'; })
      : (typeof UF_SAVED_TFS !== 'undefined' ? UF_SAVED_TFS : []).map(function(t){
          return '<button type="button" class="' + (t[0] === ufSavedTf() ? 'on' : '') + '" onclick="pfcSavedTf(\'' + t[0] + '\')">'
            + t[1] + '</button>'; })
    ).join('');
  host.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || host.querySelector('.pb-dots'));
}

function pfcDpVista(v){
  pfcMenuClose();
  if (typeof dpSetVista === 'function') dpSetVista(v);
  pfcPaint();
}
function pfcSavedTf(v){
  pfcMenuClose();
  if (typeof ufSavedSetTf === 'function') ufSavedSetTf(v);
}

/* ---------------------------------------------------------------------------------------
   Il carosello
   --------------------------------------------------------------------------------------- */

/* PERCHE' LAGGAVA E SALTAVA UNA SCHEDA (0.9.305).
   Prima pfcGo cambiava PFC_I SUBITO e poi aspettava pfcPaint, che calcolava il corpo della
   scheda nuova PRIMA di disegnare: la "Tempo medio sullo schermo" chiede al motore 56 giorni,
   uno alla volta, e passava un secondo e mezzo con il dito gia' alzato e niente che si muoveva.
   Chi ritoccava in quel momento partiva da PFC_I gia' a 1 e finiva sulla 2: dalla Riserva di
   dopamina a "Tempo risparmiato", saltando la scheda di mezzo. E i due disegni in volo finivano
   in ordine sparso: l'ultimo a rispondere scriveva il suo corpo sotto ai puntini dell'altro.
   Adesso il pannello si costruisce una volta sola e ogni scheda ha il suo corpo gia' pronto
   (PFC_HTML): lo scorrimento disegna subito quello che c'e', e i dati freschi arrivano dopo, al
   loro posto, senza muovere niente. Le schede vicine si preparano in sottofondo appena il
   Profilo si apre, cosi' la prima volta non costa piu' delle altre. */
const PFC_N = 4;
const PFC_HTML = [null, null, null, null];   // l'ultimo corpo calcolato di ogni scheda
/* 0.9.306: l'ultimo corpo di ogni scheda resta anche fra un'apertura e l'altra (lo stesso giorno), come la pagina
   del Report (fl_ins_cache_*): la scheda si vede subito e il conto fresco arriva dopo, al suo posto */
const PFC_RICORDA_KEY = 'fl_pfc_corpi';
function pfcOggi(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
(function pfcRicordaLeggi(){
  try{
    const v = JSON.parse(localStorage.getItem(PFC_RICORDA_KEY) || 'null');
    if (v && v.giorno === pfcOggi() && Array.isArray(v.html)) v.html.forEach(function(h, i){ if (i < PFC_N && typeof h === 'string' && h) PFC_HTML[i] = h; });
  }catch(_){ }
})();
function pfcRicorda(){
  try{ localStorage.setItem(PFC_RICORDA_KEY, JSON.stringify({ giorno: pfcOggi(), html: PFC_HTML.slice() })); }catch(_){ }
}
const PFC_AT = [0, 0, 0, 0];                 // quando e' stato calcolato
const PFC_GEN = [0, 0, 0, 0];                // l'ultimo calcolo partito: quelli prima non scrivono
const PFC_FRESCO_MS = 60000;
const PFC_TITOLI = ['Riserva di dopamina', 'Tempo medio sullo schermo', 'Tempo risparmiato', 'Difesa attiva, senza interruzioni'];
const PFC_SLIDE_MS = 420;

async function pfcCorpo(i){
  if (i === 0) return (typeof dpCardHtml === 'function') ? dpCardHtml(await dpCalcola(), 'profilo') : '';
  if (i === 1) return await pfcSlideMedia();
  if (i === 2) return (typeof ufSavedHtml === 'function') ? await ufSavedHtml() : '';
  return pfcSlideSerie();
}

/** Il pannello, costruito UNA volta: cornice, tre puntini, corpo e pallini. Poi si cambia solo il dentro. */
function pfcCard(){
  const host = document.getElementById('profSaved');
  if (!host) return null;
  let card = document.getElementById('pfcCard');
  if (card && host.contains(card)) return card;
  host.innerHTML = '<div class="pfc" id="pfcCard">'
    + '<button type="button" class="arb-dots" onclick="pfcMenuOpen(event)" aria-label="Opzioni">⋯</button>'
    + '<div class="pfc-body"></div>'
    + '<div class="pfc-dots">'
    +   [0, 1, 2, 3].map(function(i){
          return '<button type="button" onclick="pfcGo(' + i + ')" aria-label="Scheda ' + (i + 1) + '"></button>';
        }).join('')
    + '</div></div>';
  card = document.getElementById('pfcCard');
  pfcSwipe(card);
  return card;
}

/** Mette a schermo la scheda PFC_I con quello che c'e' gia' in mano: niente attese. */
function pfcMostra(card){
  const body = card && card.querySelector('.pfc-body:not(.pfc-old)');
  if (!body) return;
  const h = PFC_HTML[PFC_I];
  /* la prima volta in assoluto, prima che il motore risponda: il titolo della scheda e una riga
     che respira, mai la scheda di prima sotto ai pallini di quella nuova */
  const html = h !== null ? h : '<p class="pfc-eyebrow">' + PFC_TITOLI[PFC_I] + '</p><span class="pfc-attesa" aria-hidden="true"></span>';
  if (body.__pfcH !== html){ body.innerHTML = html; body.__pfcH = html; }
  card.querySelectorAll('.pfc-dots button').forEach(function(b, i){ b.classList.toggle('on', i === PFC_I); });
  /* I tre puntini valgono solo dove c'è davvero qualcosa da scegliere: sulla media del tempo
     non c'è nessun periodo da cambiare, e un menù che si apre vuoto è peggio di nessun menù. */
  const dots = card.querySelector('.arb-dots');
  if (dots) dots.style.display = PFC_I === 1 ? 'none' : '';
  if (PFC_I === 0 && typeof dpVivo === 'function') dpVivo();
}

/** Calcola il corpo della scheda i e, se e' quella a schermo, lo mette al suo posto. */
async function pfcCalcola(i){
  const g = ++PFC_GEN[i];
  let html = null;
  try{ html = await pfcCorpo(i); }catch(_){ html = null; }
  if (g !== PFC_GEN[i] || html === null) return;   // un calcolo piu' nuovo e' gia' partito
  PFC_HTML[i] = html; PFC_AT[i] = Date.now();
  pfcRicorda();
  if (i === PFC_I) pfcMostra(pfcCard());
}

/* Le altre schede si preparano in sottofondo, una alla volta (il motore risponde a una domanda
   per volta): prima le due vicine, poi quella di fronte. */
let PFC_PRE = null;
function pfcPrecarica(){
  if (PFC_PRE) return PFC_PRE;
  PFC_PRE = (async function(){
    try{
      for (const k of [1, PFC_N - 1, 2]){
        const i = (PFC_I + k) % PFC_N;
        if (PFC_HTML[i] === null || Date.now() - PFC_AT[i] > PFC_FRESCO_MS) await pfcCalcola(i);
      }
    }catch(_){ }
    finally{ PFC_PRE = null; }
  })();
  return PFC_PRE;
}

/* IN GIRO: dopo l'ultima si torna alla prima continuando a scorrere, e dalla prima indietro
   si va all'ultima. `dir` e' il verso del dito (1 = avanti); per i pallini lo dice l'ordine. */
function pfcGo(i, dir){
  const nuovo = ((i % PFC_N) + PFC_N) % PFC_N;
  if (nuovo === PFC_I) return;
  const d = dir || (nuovo > PFC_I ? 1 : -1);
  pfcMenuClose();
  const card = pfcCard();
  const body = card && card.querySelector('.pfc-body:not(.pfc-old)');
  const vecchio = body ? { html: body.innerHTML, top: body.offsetTop, h: body.offsetHeight } : null;
  PFC_I = nuovo;
  pfcMostra(card);
  if (vecchio) pfcScorri(card, d, vecchio);
  if (PFC_HTML[nuovo] === null || Date.now() - PFC_AT[nuovo] > PFC_FRESCO_MS) pfcCalcola(nuovo).then(pfcPrecarica);
}

/* LE SCHEDE SCORRONO DI LATO: la vecchia esce dal lato verso cui hai spinto e la nuova entra
   dall'altro. Uno scorrimento nuovo a meta' di quello di prima lo chiude e riparte. */
let PFC_ANIM = 0;
function pfcScorri(card, dir, vecchio){
  try{
    const body = card && card.querySelector('.pfc-body:not(.pfc-old)');
    if (!body || !vecchio || typeof body.animate !== 'function') return;
    card.querySelectorAll('.pfc-old').forEach(function(g){ g.remove(); });
    if (body.getAnimations) body.getAnimations().forEach(function(a){ a.cancel(); });
    const w = card.clientWidth || body.offsetWidth;
    const ghost = document.createElement('div');
    ghost.className = 'pfc-body pfc-old';
    ghost.setAttribute('aria-hidden', 'true');
    ghost.innerHTML = vecchio.html;
    ghost.querySelectorAll('[id]').forEach(function(e){ e.removeAttribute('id'); });
    ghost.style.cssText = 'position:absolute;left:' + body.offsetLeft + 'px;top:' + vecchio.top + 'px;width:' + body.offsetWidth + 'px;height:' + vecchio.h + 'px;pointer-events:none';
    card.insertBefore(ghost, body);
    card.classList.add('pfc-anim');
    const ease = 'cubic-bezier(.22,.61,.36,1)';
    body.animate([{ transform: 'translateX(' + (dir * w) + 'px)' }, { transform: 'none' }], { duration: PFC_SLIDE_MS, easing: ease });
    ghost.animate([{ transform: 'none' }, { transform: 'translateX(' + (-dir * w) + 'px)' }], { duration: PFC_SLIDE_MS, easing: ease, fill: 'forwards' });
    const n = ++PFC_ANIM;
    setTimeout(function(){ ghost.remove(); if (n === PFC_ANIM) card.classList.remove('pfc-anim'); }, PFC_SLIDE_MS + 30);
  }catch(_){ }
}

/* Chi chiama da fuori (dati nuovi, mezzanotte, tema, un periodo scelto) vuole la scheda a
   schermo ricalcolata: si disegna subito quello che c'e' e si rifà il conto. */
async function pfcPaint(){
  const card = pfcCard();
  if (!card) return;
  pfcMostra(card);
  await pfcCalcola(PFC_I);
  /* le altre si preparano solo con il Profilo davanti: all'avvio il motore serve a chi e' a schermo */
  const tab = document.getElementById('tab-profilo');
  if (tab && tab.classList.contains('on')) pfcPrecarica();
}

/* Cambiare da dove arrivano i numeri rende vecchie tutte le schede, non solo quella a schermo. */
document.addEventListener('fl:fonte', function(){ for (let i = 0; i < PFC_N; i++) PFC_AT[i] = 0; });

/* Si scorre col dito, come tutte le altre file di questa app. Quaranta pixel di soglia: sotto
   quelli è un tocco, e un tocco non deve mai far cambiare scheda per sbaglio. Il pannello si
   costruisce una volta, quindi l'ascolto si aggancia una volta sola. */
function pfcSwipe(el){
  if (!el || el.__pfcSwipe) return;
  el.__pfcSwipe = true;
  let x0 = 0, y0 = 0;
  el.addEventListener('touchstart', function(e){
    const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY;
  }, { passive: true });
  el.addEventListener('touchend', function(e){
    const t = e.changedTouches[0];
    const dx = t.clientX - x0, dy = t.clientY - y0;
    if (Math.abs(dx) < 40 || Math.abs(dx) < Math.abs(dy)) return;
    if (dx < 0) pfcGo(PFC_I + 1, 1); else pfcGo(PFC_I - 1, -1);
  }, { passive: true });
}

(function pfcStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* IL RESPIRO. Il pannello stava incollato alle due card sopra e al report sotto: tre
       blocchi attaccati si leggono come un blocco solo, e il carosello smetteva di sembrare
       una cosa a parte con cui si puo' interagire. */
    '.pfc{position:relative;background:#fff;border:1px solid var(--line);border-radius:20px;',
      'padding:24px 18px 16px;margin:26px 0 22px;text-align:center;min-height:250px;',
      'display:flex;flex-direction:column;touch-action:pan-y}',
    'body.dark .pfc{background:#12203A;border-color:#22345A}',
    /* durante lo scorrimento il pannello taglia quello che esce dai bordi */
    '.pfc.pfc-anim{overflow:hidden}.pfc.pfc-anim .arb-dots{z-index:3}',
    '.pfc-old{display:flex;flex-direction:column;align-items:center;justify-content:center;margin:0}',
    /* la prima volta, prima che il motore risponda: una riga che respira sotto al titolo */
    '.pfc-attesa{display:block;width:62%;height:12px;border-radius:99px;margin:26px auto 0;background:var(--line);animation:pfcRespira 1.1s ease-in-out infinite alternate}',
    '@keyframes pfcRespira{from{opacity:.35}to{opacity:.9}}',
    /* Il corpo e' una colonna centrata: cosi' anche una frase lunga due righe resta al centro
       del pannello invece di appoggiarsi in alto a sinistra. */
    '.pfc-body{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}',
    '.pfc-body > *{max-width:100%}',
    '.pfc-eyebrow{font:800 9.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;',
      'color:var(--muted);margin:0 0 18px;padding:0 10px}',
    /* L'emoji sopra al numero ha bisogno di stare per conto suo: incollata al titolo sembrava
       parte della scritta, incollata al numero glielo faceva toccare. */
    '.pfc-body .saved-emoji{display:block;font-size:46px;line-height:1;margin:2px 0 14px}',
    '.pfc-body .saved-note{display:block;margin-top:16px;font:500 11px/1.5 var(--font-body);',
      'color:var(--faint);max-width:22em}',
    /* IL NUMERO GRANDE, AL CENTRO. È l'unica cosa che questa scheda deve consegnare, e va
       consegnata prima di qualsiasi spiegazione. */
    '.pfc-big{display:block;font:800 40px/1.06 var(--font-display);font-style:italic;color:var(--navy);',
      'margin:6px 0 2px}',
    '.pfc-big small{font-size:17px;font-style:normal;color:var(--muted)}',
    'body.dark .pfc-big{color:#fff}',
    '.pfc-h{font:800 18px/1.3 var(--font-display);color:var(--navy);margin:2px 0 8px}',
    'body.dark .pfc-h{color:#fff}',
    '.pfc-line{font:500 12.5px/1.6 var(--font-body);color:var(--muted);margin:14px auto 0;',
      'max-width:22em;text-align:center}',
    '.pfc-line b{font-weight:800;color:var(--navy)}',
    'body.dark .pfc-line b{color:#fff}',
    '.pfc-line b.giu{color:#1B9E6A}.pfc-line b.su{color:#E5515F}',
    /* «Fra 14 giorni» in grassetto e basta: blu e sottolineato sembrava un link, e un link
       che non porta da nessuna parte e' una promessa mancata. `--navy` e' il colore del testo
       in tutti e due i temi. Dopo `.pfc-line b` e la sua variante scura, o perde per cascata. */
    '.pfc-line b.pfc-quando,body.dark .pfc-line b.pfc-quando{color:var(--navy);font-weight:800;',
      'text-decoration:none}',
    '.pfc-rec{font:700 11.5px var(--font-body);color:var(--muted);margin:14px 0 0;text-align:center}',
    /* L'altezza la decide il viewBox (320x150): fissarla a 110px con proporzioni libere
       schiacciava il disegno, e le ore a destra venivano fuori stirate. */
    /* `var(--navy)` e non `#fff`: in chiaro questo pannello e' una card BIANCA, e un grafico
       bianco su bianco e' un grafico che non c'e'. La variabile ribalta il colore insieme al
       tema, che e' l'unica cosa che qui funziona in tutti e due i casi. */
    '.pfc-svg{display:block;width:100%;height:auto;margin-top:14px;color:var(--navy);overflow:visible}',

    '.pfc-ax{fill:currentColor;fill-opacity:.5;font:600 9px var(--font-body)}',
    '.pfc-ax-m{text-anchor:middle}',
    '.pfc-ax-h{text-anchor:end}',
    /* La curva di attesa e' gia' tratteggiata e gia' smorzata: spegnerla ancora renderebbe
       illeggibili anche le ore e i mesi, che invece sono veri. */
    '.pfc-ghost{opacity:.85}',
    '.pfc-dots{display:flex;justify-content:center;gap:7px;margin-top:14px}',
    '.pfc-dots button{width:7px;height:7px;padding:0;border:0;border-radius:50%;cursor:pointer;',
      'background:var(--line)}',
    '.pfc-dots button.on{background:#0075E3;width:18px;border-radius:99px}',
    /* I TRE PUNTINI SI DEVONO VEDERE. Sul pannello scuro dell'arbitro il bottone bianco
       trasparente funziona; qui il pannello e' chiaro, e un bottone bianco su bianco e' un
       comando che non esiste — nessuno sa che il periodo si puo' cambiare. */
    '.pfc .arb-dots{background:rgba(0,30,68,.07);border:1px solid var(--line);color:var(--navy)}',
    'body.dark .pfc .arb-dots{background:rgba(255,255,255,.12);border-color:#2A3A57;color:#fff}',

    /* --------------------------------------------------------- il pannello del report
       Quello di AppBlock: due numeri affiancati — la media della settimana scorsa e oggi —
       e sotto, separata da una riga, la porta per il report. Il vecchio pannello aveva solo
       la porta: un rettangolo grande che diceva «Report» e nient'altro, cioè occupava lo
       spazio di un'informazione per mostrare un'etichetta. */
    '.pfr{background:linear-gradient(135deg,#0B2A55,#001E44);color:#fff;border-radius:20px;',
      'padding:18px 18px 6px;margin:14px 0 4px;-webkit-tap-highlight-color:transparent}',
    '.pfr-two{cursor:pointer}',
    '.pfr-two:active,.pfr-go:active{opacity:.85}',
    '.pfr-two{display:flex;align-items:stretch}',
    '.pfr-two > div{flex:1;text-align:center;padding:4px 6px 14px}',
    '.pfr-two .sep{flex:0 0 1px;background:rgba(255,255,255,.16);margin:6px 0 14px;padding:0}',
    '.pfr-two small{display:block;font:600 11px var(--font-body);color:rgba(200,218,242,.72)}',
    '.pfr-two b{display:block;margin-top:7px;font:800 24px/1 var(--font-display)}',
    '.pfr-two .pfr-tr{display:inline-block;width:15px;height:15px;vertical-align:-1px;margin-right:2px}',
    '.pfr-two b.giu{color:#8CF0C8}.pfr-two b.su{color:#FF8A9B}',
    '.pfr-da{margin:-4px 8px 14px;text-align:center;font:500 11.5px/1.5 var(--font-body);color:rgba(200,218,242,.78)}',
    '.pfr-go{display:flex;align-items:center;gap:11px;border-top:1px solid rgba(255,255,255,.14);',
      'padding:15px 2px;cursor:pointer}',
    '.pfr-go span.ic{font-size:17px;line-height:1}',
    '.pfr-go b{flex:1;text-align:left;font:700 13.5px var(--font-body);color:#fff}',
    /* LA FRECCIA GUARDAVA IN BASSO A DESTRA. Era uno <span class="go">: la regola globale .go
       (css/app.css) ci disegna gia' un chevron verso destra con una maschera, e qui sopra gli si
       aggiungeva rotate(45deg) per il vecchio chevron fatto coi bordi. Due frecce in una, girata
       di 45 gradi. Adesso e' un SVG suo, senza classi condivise e senza nessuna rotazione. */
    '.pfr-chev{width:20px;height:20px;flex:none;color:rgba(255,255,255,.75);transform:none}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ===========================================================================================
   IL PANNELLO DEL REPORT, COME QUELLO DI APPBLOCK

   Prima era un rettangolo che diceva «Report» e una riga di spiegazione: occupava lo spazio di
   un'informazione per mostrare un'etichetta. AppBlock ci mette due numeri — la media della
   settimana scorsa e quella di oggi, con la freccia — e sotto la porta per il report vero. La
   differenza è tutta lì: da un cartello si passa oltre, da un confronto no.

   E la porta non va più dritta al report: passa prima dal flusso settimanale, perché il report
   è una tabella e la tabella non ha mai cambiato le abitudini di nessuno.
   =========================================================================================== */
async function pfrPaint(){
  const host = document.getElementById('profReportBox');
  if (!host) return;
  if (typeof scReport !== 'function'){ host.innerHTML = ''; return; }

  /* «22 ORE AL GIORNO» NON ESISTONO. La media leggeva i giorni da 7 a 13 fa: Android tiene gli
     eventi di utilizzo dettagliati per circa una settimana, e oltre quella soglia la macchina a
     stati del motore vede un'app aperta senza mai vederla chiusa, e le conta ore che non ci
     sono. Adesso: gli ultimi sette giorni interi (ieri compreso), e un giorno sopra le 18 ore
     non e' un giorno, e' un errore: si scarta, e si butta anche la sua copia in cache. */
  let oggi = 0, media = 0, giorni = 0, da = '', ripiego = false;
  const TETTO = 18 * 3600000;
  /* il disegno di prima si tiene per dispositivo: fl_pfr_cache il telefono lo copia sul computer
     insieme a tutte le sue chiavi (specchio-web.js), e sul computer comparivano i suoi numeri */
  const pc = pfrQuiComputer();
  const CACHE = pc ? 'fl_pfr_cache_pc' : 'fl_pfr_cache';
  try{ const vec = localStorage.getItem(CACHE); if (vec && !host.innerHTML) host.innerHTML = vec; }catch(_){ }
  if (pc){
    const n = await pfrNumeriComputer(TETTO);
    oggi = n.oggi; media = n.media; da = n.da; ripiego = n.ripiego;
  } else try{
    const tutti = await Promise.all([0, 1, 2, 3, 4, 5, 6, 7].map(function(d){ return scReport(d).catch(function(){ return null; }); }));
    const r0 = tutti[0];
    if (r0 && r0.granted) oggi = Math.min(r0.screenMs || 0, TETTO);
    for (let d = 1; d <= 7; d++){
      const r = tutti[d];
      if (!r || !r.granted || !(r.screenMs > 0)) continue;
      if (r.screenMs > TETTO){ try{ localStorage.removeItem('fl_dayrep_' + scKey(scDayStart(d))); }catch(_){ } continue; }
      media += r.screenMs; giorni++;
    }
    media = giorni ? media / giorni : 0;
  }catch(_){ }

  const giu = media > 0 && oggi < media;
  /* TUTTO IL PANNELLO E' LA PORTA, non solo la riga in fondo: chi tocca i due numeri vuole
     sapere da dove vengono, e il report e' la risposta. */
  /* 0.9.260, Andrea, come AppBlock: i due numeri portano al Report; solo la riga in fondo apre il report settimanale */
  host.innerHTML = '<div class="pfr">'
    + (media > 0
        ? '<div class="pfr-two" role="button" tabindex="0" onclick="switchTab(\'insights\')">'
          + '<div><small>Media sett. scorsa</small><b>' + pfcOreTxt(media) + '</b></div>'
          + '<i class="sep"></i>'
          + '<div><small>Oggi</small><b class="' + (giu ? 'giu' : 'su') + '">'
          +   pfrFreccia(giu) + pfcOreTxt(oggi) + '</b></div>'
          + '</div>'
          /* sul computer si dice di chi sono i numeri: possono essere i suoi o quelli del telefono */
          + (pc && da ? '<p class="pfr-da">' + pfrDaTesto(da, ripiego) + '</p>' : '')
        : '')
    + '<div class="pfr-go" role="button" tabindex="0" onclick="wkOpen()">'
    +   '<span class="ic">📊</span><b>Report settimanale</b><i class="pfr-nuovo" id="pfrNuovo"' + (typeof wkDaVedere === 'function' && wkDaVedere() ? '' : ' hidden') + '>Nuovo</i>'
    +   '<svg class="pfr-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>'
    + '</div></div>';
  try{ localStorage.setItem(CACHE, host.innerHTML); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   IL REPORT SETTIMANALE SUL COMPUTER (0.9.305)

   Andrea: "sul PC il Report settimanale non mostra nessun numero, e il telefono e' collegato".
   LA CAUSA. Il pannello chiedeva i giorni passati a scReport, che sul computer passa da
   mwDayReport (motore-web.js): con la sorgente "telefono" (la scelta e' una sola per i due
   dispositivi, e sul PC di Andrea vale "telefono") i giorni passati non hanno nessun ripiego e
   tornano "senza dati", e oggi arriva solo se il telefono ha pubblicato i suoi granelli. Media a
   zero, e il pannello nasconde i due numeri.
   ADESSO, sul computer, i numeri si prendono dalle due righe dell'account che ci sono gia':
   - i totali del COMPUTER (fl:pc-usage, li scrive il programma del PC ogni dieci minuti);
   - i totali del TELEFONO (fl:mobile-usage, li scrive il telefono), come fa il carburante, che
     sul computer legge la giornata che il telefono ha pubblicato (dpLeggiTelefono).
   Bastano quelli del computer (almeno PFR_PC_BASTA giorni della settimana scorsa): si mostrano
   quelli. Altrimenti si mostrano quelli del telefono, e si dice. Con la sorgente "telefono"
   scelta nel Report l'ordine si rovescia, cosi' il pannello e il Report dicono la stessa cosa.
   Mai mescolati: media e oggi arrivano sempre dallo stesso dispositivo.
   --------------------------------------------------------------------------------------- */
const PFR_PC_BASTA = 3;
/** Di chi sono i numeri del pannello, detto sul computer in una frase intera. */
function pfrDaTesto(da, ripiego){
  if (da === 'telefono') return 'Questo è il tempo che hai passato sul telefono'
    + (ripiego ? ': il computer ha ancora pochi giorni di dati.' : '.');
  return 'Questo è il tempo che hai passato al computer'
    + (ripiego ? ': il telefono ha ancora pochi giorni di dati.' : '.');
}
function pfrQuiComputer(){
  try{ return (typeof mwQuiComputer === 'function') ? mwQuiComputer() : ((typeof pcQui === 'function') && pcQui() === 'desktop'); }
  catch(_){ return false; }
}
async function pfrNumeriComputer(TETTO){
  try{ if (typeof pcSync === 'function') await pcSync(false); }catch(_){ }
  try{ if (typeof pcAltroSync === 'function') await pcAltroSync(false); }catch(_){ }
  const chiave = function(off){ return (typeof pcChiave === 'function') ? pcChiave(off) : ''; };
  const minuti = function(g){ return (g && +g.m > 0) ? +g.m * 60000 : 0; };
  const delPc = function(off){ try{ return minuti((typeof pcGiorno === 'function') ? pcGiorno(off) : null); }catch(_){ return 0; } };
  let docTel = null;
  try{ docTel = (typeof PC_ALTRO !== 'undefined' && PC_ALTRO && PC_ALTRO.doc) || null; }catch(_){ docTel = null; }
  const delTel = function(off){ return minuti(docTel && docTel.giorni ? docTel.giorni[chiave(off)] : null); };
  const settimana = function(f){
    let s = 0, n = 0;
    for (let d = 1; d <= 7; d++){ const ms = f(d); if (ms > 0 && ms <= TETTO){ s += ms; n++; } }
    return { media: n ? s / n : 0, giorni: n };
  };
  const sPc = settimana(delPc), sTel = settimana(delTel);
  /* oggi del telefono: la giornata che ha pubblicato con la riserva di dopamina e' piu' fresca
     della riga dei totali, che il telefono riscrive al massimo ogni sei ore */
  let oggiTel = delTel(0);
  try{
    const mezzanotte = new Date(); mezzanotte.setHours(0, 0, 0, 0);
    const r = (typeof SW_GIORNO !== 'undefined' && SW_GIORNO) ? SW_GIORNO.rep : null;
    if (r && r.dayStart === mezzanotte.getTime() && r.screenMs > 0) oggiTel = r.screenMs;
  }catch(_){ }
  /* l'ordine lo decide la scelta "da dove arrivano i numeri" del Report (una sola per i due
     dispositivi): con "telefono" prima il telefono, altrimenti prima il computer, come chiesto da
     Andrea. Chi viene prima vince se ha almeno PFR_PC_BASTA giorni; se no ripiega sull'altro. */
  const pc = { da: 'computer', s: sPc, oggi: Math.min(delPc(0), TETTO) };
  const tel = { da: 'telefono', s: sTel, oggi: Math.min(oggiTel, TETTO) };
  let fonte = '';
  try{ fonte = (typeof mwFonte === 'function') ? mwFonte() : ''; }catch(_){ fonte = ''; }
  const ordine = fonte === 'telefono' ? [tel, pc] : [pc, tel];
  let scelto = ordine.filter(function(x){ return x.s.giorni >= PFR_PC_BASTA; })[0]
    || ordine.slice().sort(function(a, b){ return b.s.giorni - a.s.giorni; })[0];
  if (!scelto || !scelto.s.giorni) return { da: '', media: 0, oggi: 0, ripiego: false };
  return { da: scelto.da, media: scelto.s.media, oggi: scelto.oggi, ripiego: scelto !== ordine[0] };
}

/* la freccia della tendenza di oggi: in basso se si scende, in alto se si sale (SVG, mai caratteri) */
function pfrFreccia(giu){
  return '<svg class="pfr-tr" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
    + (giu ? '<path d="M7 7l10 10"/><path d="M17 9v8H9"/>' : '<path d="M7 17L17 7"/><path d="M9 7h8v8"/>') + '</svg>';
}

/* Le due cose si ridisegnano insieme, quando la scheda Profilo torna davanti. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'profilo') return;
  pfcPaint();
  pfrPaint();
});
setTimeout(function(){ pfcPaint(); pfrPaint(); }, 2600);
/* il badge Nuovo: la riga si salva in cache, quindi si riallinea a ogni ritorno sulla scheda */
function pfrNuovoAgg(){ const b = document.getElementById('pfrNuovo'); if (b && typeof wkDaVedere === 'function') b.hidden = !wkDaVedere(); }
document.addEventListener('fl:tab', function(){ setTimeout(pfrNuovoAgg, 80); });
document.addEventListener('fl:screen', function(){ setTimeout(pfrNuovoAgg, 80); });
(function(){
  const st = document.createElement('style');
  st.textContent = '.pfr-nuovo{flex:none;margin-left:8px;margin-right:auto;padding:3px 9px;border-radius:99px;background:#0075E3;color:#fff;font:800 11px var(--font-body);font-style:normal}.pfr-nuovo[hidden]{display:none}';
  document.head.appendChild(st);
})();
