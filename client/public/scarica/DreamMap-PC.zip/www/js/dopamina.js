/* ===========================================================================================
   LA DOPAMINA STIMATA — la riserva, da 0 a 100, con la base a 50

   COSA MISURA. Non la dopamina nel cervello: nessun telefono la vede. Misura quello che il
   telefono e il computer vedono davvero — quali app, quando, per quanto, i passi, il sonno,
   le notifiche — e lo traduce con un modello che si comporta come il sistema della
   ricompensa. E' un modello concettuale, dichiarato tale: deve essere credibile e coerente.

   DOVE STA COSA
     · dopamina-config.js   TUTTI i numeri del modello, commentati. Si tara li'.
     · dopamina-motore.js   il motore puro: riceve i fatti della giornata, restituisce il
                            punteggio, la curva e le voci di «Cosa l'ha mossa». Si prova fuori
                            dall'app: node tools/test-dopamina.js
     · questo file          raccoglie i fatti (cronologia, sonno, passi, notifiche, spunte),
                            chiama il motore, tiene la storia, parla con l'altro dispositivo,
                            disegna.

   DUE GRANDEZZE. La RISERVA (il tachimetro) sale solo con lo sforzo sano; la STIMOLAZIONE
   (la curva sotto) mostra i picchi e i crolli. Lo scroll accende la seconda e abbassa la prima.

   UN CALCOLO SOLO. Prima il numero grande, la curva e gli insight uscivano da tre formule
   diverse (dpLivello, dpOggiCurva, dpEventi) e non tornavano mai: la somma delle voci non
   era la differenza fra il numero di stamattina e quello di adesso. Adesso escono tutti e tre
   dalla stessa simulazione, e il motore controlla che partenza + somma delle voci = adesso.
   =========================================================================================== */

const DP = { L: null, dett: null, at: 0, timer: 0, inCorso: null, grigio: null };
const DP_FINE_KEY = 'fl_dopa_fine';          // { giorno, S, P, D, at } l'ultimo calcolo
/* 0.9.306, Andrea: "toccando il carburante appena aperta l'app resta su 'Leggo la giornata' troppo a lungo".
   LA CAUSA: all'avvio il numero non c'era finche' il calcolo di oggi non finiva, e il calcolo aspettava prima la
   storia dei trenta giorni (dpStoria: fino a quattro giornate intere lette dal telefono, una alla volta, in coda
   con tutte le altre letture dell'avvio). Il Report invece mostra subito l'ultima pagina disegnata e la rifa' dopo.
   Adesso anche qui: l'ultimo numero di oggi e l'ultima pagina disegnata restano in memoria e si mostrano subito;
   il calcolo legge solo ieri prima di oggi, e il resto della storia lo fa dopo, in sottofondo. */
const DP_ULTIMO_KEY = 'fl_dopa_ultimo';      // { giorno, L, at } l'ultimo numero mostrato
const DP_PAGINA_KEY = 'fl_dopa_pagina';      // { giorno, html } l'ultima pagina "Dopamina, oggi" disegnata
(function dpUltimoValore(){
  try{
    const u = JSON.parse(localStorage.getItem(DP_ULTIMO_KEY) || 'null');
    const d = new Date(); d.setHours(0, 0, 0, 0);
    const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (u && u.giorno === k && typeof u.L === 'number') DP.L = u.L;
  }catch(_){ }
})();
const DP_GIORNI_KEY = 'fl_dopa_giorni_v2';   // { 'YYYY-MM-DD': { S, P, D, fine, n, top, su } } i giorni chiusi
const DP_DAY = 86400000;
/* 0.9.308, Andrea: la pagina Dopamina con Giorno | Settimana | Mese | Anno. La storia dei giorni chiusi ne tiene
   quaranta (con il dettaglio di ognuno, e il telefono non rilegge la cronologia di mesi fa): per l'anno resta qui,
   per ogni giorno chiuso, SOLO il livello con cui e' finito. Due anni, una ventina di KB. Mai un numero inventato:
   un giorno che non e' qui e' un giorno senza dati, e la pagina lo dice. */
const DP_ANNI_KEY = 'fl_dopa_anni';         // { 'YYYY-MM-DD': fine } il livello finale di ogni giorno chiuso
const DP_ANNI_MAX = 760;
function dpAnni(){ try{ return JSON.parse(localStorage.getItem(DP_ANNI_KEY) || '{}') || {}; }catch(_){ return {}; } }
/** Copia nell'archivio il livello finale dei giorni chiusi di una storia (solo quelli letti davvero). */
function dpArchivia(storia){
  try{
    if (!storia) return;
    const a = dpAnni(), oggi = dpChiave(Date.now());
    let cambiati = 0;
    Object.keys(storia).forEach(function(k){
      const r = storia[k];
      if (k >= oggi || !r || !r.n || typeof r.fine !== 'number' || isNaN(r.fine)) return;
      const v = Math.round(r.fine * 10) / 10;
      if (a[k] !== v){ a[k] = v; cambiati++; }
    });
    if (!cambiati) return;
    const tieni = {};
    Object.keys(a).sort().slice(-DP_ANNI_MAX).forEach(function(k){ tieni[k] = a[k]; });
    localStorage.setItem(DP_ANNI_KEY, JSON.stringify(tieni));
  }catch(_){ }
}
(function dpArchivioAvvio(){
  /* chi aveva gia' la storia dei quaranta giorni la ritrova subito nell'anno */
  try{ dpArchivia(JSON.parse(localStorage.getItem(DP_GIORNI_KEY) || '{}')); }catch(_){ }
})();

/* ---------------------------------------------------------------------------------------
   I PESI: l'indice dopaminergico di ogni app (0…1). Il motore lo divide in categorie:
   da 0,8 in su alta intensita' (video brevi, social, giochi), fino a 0,1 produttiva, in
   mezzo media (messaggi, navigazione, app non categorizzate).
   --------------------------------------------------------------------------------------- */
const DP_PESI = { social: .95, video: .85, games: .95, bet: 1, adult: 1, dating: .8, shop: .6, news: .5, sport: .5, msg: .35 };
/* Un'app audio/video lunga senza altri stimoli intorno e' sottofondo: la musica mentre lavori
   non e' binge watching. Vale il 40% e scende di categoria. */
const DP_ASCOLTO_MIN = 15, DP_ASCOLTO = 0.4;

/* Le app dove si puo' ASCOLTARE senza guardare: qui il granello lungo e' sottofondo. */
const DP_AUDIO = [
  'com.google.android.youtube', 'com.google.android.apps.youtube.music', 'com.spotify.music',
  'com.soundcloud.android', 'com.google.android.apps.podcasts', 'com.audible.application',
  'deezer.android.app', 'com.amazon.mp3', 'com.aspiro.tidal', 'com.apple.android.music',
  'tunein.player', 'fm.castbox.audiobook.radio.podcast', 'com.clearchannel.iheartradio.controller',
  'com.spotify.lite', 'com.bambuna.podcastaddict'
];

let DP_MAPPA = null;
function dpMappa(){
  if (DP_MAPPA) return DP_MAPPA;
  const m = {};
  try{
    (typeof FL_CATS !== 'undefined' ? FL_CATS : []).forEach(function(c){
      const w = DP_PESI[c.id];
      if (!w) return;
      let apps = c.apps || [];
      try{ if (typeof flCatItems === 'function'){ const it = flCatItems(c); if (it && it.apps) apps = it.apps; } }catch(_){ }
      apps.forEach(function(p){ if (!(m[p] > w)) m[p] = w; });
    });
  }catch(_){ }
  DP_MAPPA = m;
  return m;
}
/**
 * L'indice dopaminergico di un'app (0…1). Le categorie scelte a mano vincono sulle liste;
 * poi il nome del pacchetto e l'etichetta passano dalle stesse espressioni del computer
 * (`com.supercell.clashroyale` e' un gioco perche' si chiama cosi'); chi resta sconosciuto
 * pesa poco ma non zero.
 */
function dpPeso(pkg, cats, ex, label){
  if (!pkg || (ex && ex.indexOf(pkg) >= 0)) return 0;
  if (pkg.indexOf('com.dreambrothers.focuslock') === 0) return 0;
  const c = cats[pkg];
  if (c === 'prod') return .05;
  if (c === 'distr') return 1;
  const m = dpMappa();
  if (m[pkg] !== undefined) return m[pkg];
  const p = dpPattern(pkg + ' ' + (label || ''));
  if (p !== null) return p;
  if (typeof INS_BROWSERS !== 'undefined' && INS_BROWSERS.indexOf(pkg) >= 0) return .3;
  if (c === 'neutro') return .15;
  return .22;
}

/* I nomi che arrivano dal computer sono domini e programmi, non pacchetti Android: si pesano
   per nome, con le stesse liste. */
const DP_NOMI = [
  [/tiktok|instagram|facebook|pinterest|twitter|x\.com|snapchat|reddit|threads|9gag|tumblr/, .95],
  [/youtube|netflix|twitch|primevideo|disney|dailymotion|vimeo|crunchyroll|kick\.com/, .85],
  [/steam|epicgames|battle\.net|riot|league|valorant|fortnite|roblox|minecraft|supercell|clash|discord/, .95],
  [/bet365|sisal|snai|eurobet|lottomatica|betfair|pokerstars|planetwin|goldbet/, 1],
  [/pornhub|xvideos|xnxx|onlyfans|redtube|youporn|chaturbate|stripchat/, 1],
  [/tinder|badoo|bumble|meetic|grindr|happn/, .8],
  [/amazon|ebay|aliexpress|temu|shein|zalando|subito|vinted/, .6],
  [/repubblica|corriere|ansa|fanpage|ilfattoquotidiano|tgcom|news\.google|gazzetta|corrieredellosport|tuttosport/, .5],
  [/whatsapp|telegram|messenger|signal|skype|viber/, .35]
];
/** Il peso che le espressioni riconoscono in un nome, o null se non lo riconoscono. */
function dpPattern(nome){
  const n = String(nome || '').toLowerCase();
  for (let i = 0; i < DP_NOMI.length; i++){ if (DP_NOMI[i][0].test(n)) return DP_NOMI[i][1]; }
  return null;
}
/* GLI STRUMENTI DI LAVORO NON COSTANO. Claude, ChatGPT, l'editor di codice, Word: senza una
   categoria scelta a mano finivano nel «medio» (0,15) e ogni ora di lavoro toglieva riserva.
   Un nome che dice lavoro vale produttivo anche se nessuno l'ha mai etichettato. */
const DP_LAVORO = /claude|chatgpt|openai|gemini|copilot|perplexity|visual studio|vs ?code|cursor|intellij|pycharm|webstorm|android studio|xcode|terminal|powershell|cmd\.exe|git ?bash|word|excel|powerpoint|outlook|onenote|notion|obsidian|evernote|trello|asana|jira|slack|teams|zoom|google docs|docs\.google|sheets\.google|drive\.google|figma|canva|photoshop|illustrator|indesign|premiere|davinci|blender|capcut|shopify|wordpress|github|gitlab|stackoverflow|kindle|udemy|coursera|duolingo|focuslock|focus2dream|dream map/;
function dpPesoNome(nome, cat){
  if (cat === 'Distracting') return 1;
  if (cat === 'Productive') return .05;
  const p = dpPattern(nome);
  if (p !== null) return p;
  if (DP_LAVORO.test(String(nome || '').toLowerCase())) return .05;
  return .15;
}

/* Lo schermo in bianco e nero: quali app, e se la modalita' e' accesa. Si legge una volta e
   si tiene per un minuto. */
async function dpGrigio(){
  if (DP.grigio && Date.now() - DP.grigio.at < 60000) return DP.grigio;
  let on = false, apps = [], modo = 'lista', colori = [];
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.greyState){
      const r = await NATIVE.greyState();
      if (r){ on = !!r.on && r.granted !== false; apps = r.apps || []; modo = r.mode || 'lista'; colori = r.colorApps || []; }
    }
  }catch(_){ }
  DP.grigio = { on: on, apps: apps, modo: modo, colori: colori, at: Date.now() };
  return DP.grigio;
}
/** Un granello in bianco e nero: a eccezioni lo e' tutto tranne le app scelte. */
function dpInGrigio(g, grigio){
  if (!grigio || !grigio.on || g.dev !== 'telefono') return false;
  return grigio.modo === 'eccezioni' ? (grigio.colori || []).indexOf(g.p) < 0 : (grigio.apps || []).indexOf(g.p) >= 0;
}

/* ---------------------------------------------------------------------------------------
   LE FONTI
   --------------------------------------------------------------------------------------- */
function dpMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function dpChiave(ts){ const d = new Date(ts); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

/** I granelli di una finestra, pesati. Null se il dispositivo non li da'. */
async function dpGraniTelefono(from, to){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return null;
  let d = null;
  try{ d = await NATIVE.getTimeline({ from: from, to: to, minMs: 0, limit: 30000 }); }catch(_){ return null; }
  if (!d || !d.granted) return null;
  /* da qui in poi il permesso c'e': una giornata vuota torna [] e non null */
  const cats = (typeof insCats === 'function') ? insCats(null) : {};
  const dpFasce = (typeof insFasce === 'function' && typeof insFasciaCat === 'function') ? insFasce() : {};
  const ex = (typeof insExcl === 'function') ? insExcl() : [];
  const grezzi = (d.grani || []).slice().sort(function(a, b){ return a.s - b.s; });
  const fusi = [];
  grezzi.forEach(function(x){
    const u = fusi[fusi.length - 1];
    if (u && u.p === x.p && x.s - (u.s + u.ms) <= 2000){ u.ms = Math.max(u.ms, x.s + (x.ms || 0) - u.s); return; }
    fusi.push({ p: x.p, l: x.l || x.p, s: x.s, ms: x.ms || 0 });
  });
  /* SOLO LA GIORNATA CHIESTA: quello che sborda si taglia al bordo. */
  const g = [];
  fusi.forEach(function(x){
    if (x.s + x.ms <= from || x.s >= to) return;
    let s = x.s, ms = x.ms;
    if (s < from){ ms -= (from - s); s = from; }
    if (s + ms > to) ms = to - s;
    if (!(ms > 0)) return;
    /* le fasce orarie della categoria (0.9.212): vale quella dell'ora in cui l'app era aperta */
    const fasce = dpFasce[x.p];
    const catsOra = fasce ? Object.assign({}, cats, (function(){ const o = {}; const c = insFasciaCat(fasce, s + ms / 2); if (c) o[x.p] = c; return o; })()) : cats;
    g.push({ p: x.p, l: x.l, s: s, ms: ms, di: dpPeso(x.p, catsOra, ex, x.l), fonte: 'telefono', dev: 'telefono' });
  });
  dpAscolto(g);
  return g;
}

/**
 * L'ASCOLTO: un granello audio/video di quindici minuti o piu' e' sottofondo, se nei suoi
 * minuti non c'e' nient'altro ad alta intensita'. Vale il 40%: esce dalla categoria «alta».
 */
function dpAscolto(g){
  g.forEach(function(x, i){
    if (DP_AUDIO.indexOf(x.p) < 0 || x.ms < DP_ASCOLTO_MIN * 60000) return;
    const fine = x.s + x.ms;
    const altri = g.some(function(y, j){ return j !== i && y.di >= 0.8 && y.s < fine && y.s + y.ms > x.s; });
    if (!altri){ x.di = x.di * DP_ASCOLTO; x.ascolto = true; }
  });
}

function dpLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }

/**
 * Le sessioni FullFocus di una finestra: minuti fatti davvero, meditazione o lavoro, e la
 * risposta alla domanda «hai completato la task?». Anche le sessioni mollate: valgono per i
 * minuti fatti, se sono almeno dieci (lo decide il motore).
 */
function dpFF(from, to){
  return (dpLeggi('fl_ff_hist', []) || []).filter(function(x){ return x && x.at > from && x.at <= to; }).map(function(x){
    const min = x.spentMs ? x.spentMs / 60000 : (x.ok ? (x.min || 25) : 0);
    const s = x.start || (x.at - min * 60000);
    return { s: s, e: x.at, min: min, ok: !!x.ok, tipo: (x.meditazione || x.tag === 'meditazione') ? 'meditazione' : 'lavoro',
             completata: !!x.completata && !!x.ok, stornato: x.stornato || null, l: x.task || x.intent || '' };
  });
}

function dpNorm(s){ return String(s || '').toLowerCase().replace(/[^a-z0-9\u00e0-\u00ff]+/g, ' ').trim(); }
/**
 * Le attivita' portate a termine in una finestra, con l'ora: le righe del piano spuntate e la
 * priorita' del giorno. Una cosa fatta per la PRIMA volta (mai vista fra quelle completate nei
 * giorni prima) e' una novita' sana e vale di piu'. La priorita' completata con la domanda di
 * FullFocus non si conta qui: il suo completamento lo paga gia' FullFocus.
 */
function dpSpunteFra(from, to){
  const out = [];
  try{
    const k0 = dpChiave(from);
    const done = dpLeggi('fl_notes_done', []) || [];
    const oneH = dpLeggi('fl_one_hist', []) || [];
    const visti = {};
    done.forEach(function(x){ if (x && x.day && x.day < k0) visti[dpNorm(x.text)] = 1; });
    oneH.forEach(function(x){ if (x && x.doneAt && x.doneAt < from) visti[dpNorm(x.task && (x.task.text || x.task))] = 1; });
    const conFF = dpFF(from, to).filter(function(f){ return f.completata; }).map(function(f){ return f.e; });
    const nuova = function(testo){ const n = dpNorm(testo); return n.length > 3 && !visti[n] && Object.keys(visti).length >= 5; };
    done.forEach(function(x){
      if (x && x.day === k0 && x.at >= from && x.at < to) out.push({ t: x.at, l: x.text || '', nuova: nuova(x.text) });
    });
    oneH.forEach(function(x){
      if (!x || !(x.doneAt >= from && x.doneAt < to)) return;
      if (conFF.some(function(e){ return Math.abs(x.doneAt - e) < 30 * 60000; })) return;
      const testo = (x.task && (x.task.text || x.task)) || '';
      out.push({ t: x.doneAt, l: String(testo), nuova: nuova(testo) });
    });
  }catch(_){ }
  return out;
}

/* ---- i check-in, le occhiate ai progressi, la serie, le fasce pianificate ---- */
const DP_CHECKIN_KEY = 'fl_dopa_checkin';     // [{ t, tipo }]
const DP_VISTE_KEY = 'fl_if_viste';           // [t] le letture del messaggio dal tuo Io Futuro (iofuturo.js)
function dpCheckin(from, to){ return (dpLeggi(DP_CHECKIN_KEY, []) || []).filter(function(c){ return c && c.t >= from && c.t < to; }); }
function dpDocciaOggi(){ const f = dpMezzanotte(); return dpCheckin(f, f + DP_DAY).some(function(c){ return c.tipo === 'doccia'; }); }
function dpDoccia(){
  if (dpDocciaOggi()) return;
  const l = dpLeggi(DP_CHECKIN_KEY, []) || [];
  l.push({ t: Date.now(), tipo: 'doccia', self_reported: true });
  try{ localStorage.setItem(DP_CHECKIN_KEY, JSON.stringify(l.slice(-120))); }catch(_){ }
  dpCalcola(true).then(function(){ dpRidipingi(); dpDettaglioPaint(); });
}
function dpViste(from, to){ return (dpLeggi(DP_VISTE_KEY, []) || []).filter(function(t){ return t >= from && t < to; }); }
/** I giorni di fila con il piano: la stessa serie della partita. */
function dpSerie(){ try{ return (typeof mtState === 'function') ? (mtState().streak || 0) : 0; }catch(_){ return 0; } }
/**
 * Le fasce pianificate di un giorno: i programmi a orario accesi quel giorno, e le sessioni
 * FullFocus. E' dentro a queste che una novita' fuori dal piano pesa.
 */
function dpPianificato(from){
  const out = [];
  const dow = (new Date(from).getDay() + 6) % 7;        // 0 = lunedi', come i programmi
  (dpLeggi('fl_programs', []) || []).forEach(function(p){
    if (!p || p.on === false || p.allDay || !(p.type === 'ora' || (p.type === 'combo' && p.useTime))) return;
    if (Array.isArray(p.days) && !p.days[dow]) return;
    const hm = function(s){ const m = /^(\d{1,2}):(\d{2})/.exec(String(s || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; };
    const a = hm(p.from), b = hm(p.to);
    if (a === null || b === null || a === b) return;
    if (b > a) out.push({ s: from + a * 60000, e: from + b * 60000 });
    else { out.push({ s: from, e: from + b * 60000 }); out.push({ s: from + a * 60000, e: from + DP_DAY }); }
  });
  dpFF(from, from + DP_DAY).forEach(function(f){ out.push({ s: f.s, e: f.e }); });
  return out;
}

/**
 * La notte di un rapporto come intervallo. Il punteggio Sonno la legge gia' con il primo segno
 * di vita sul computer (chi si alza e va dritto al computer non ha dormito fino alle undici):
 * si prende da li', cosi' la riserva e il punteggio Sonno raccontano la stessa notte.
 */
function dpSonni(rep){
  try{
    if (!rep || !rep.granted || typeof scCompute !== 'function') return [];
    const c = scCompute(rep);
    if (!c || !(c.sleepMs > 0) || !c.wake) return [];
    /* la notte del motore unico del sonno (0.9.236): dall'inizio vero, non "sveglia meno ore
       dormite", che con le interruzioni tolte comincerebbe qualche minuto dopo */
    return [{ s: c.sleepStart || (c.wake - c.sleepMs), e: c.wake }];
  }catch(_){ return []; }
}

/** Passi, allenamenti, notifiche una per una e app installate: solo il telefono li ha. */
async function dpFattiNativi(from, to){
  const out = { passi: [], notif: [], passiStato: null, allenamenti: [], installazioni: [] };
  if (typeof NATIVE === 'undefined' || !NATIVE) return out;
  /* 0.9.306: le quattro domande partono insieme e si mettono in coda subito, invece di aspettare ognuna il suo
     turno dietro a tutte le letture dell'avvio (il ponte del telefono risponde a una domanda per volta) */
  const chiedi = function(n){ return NATIVE[n] ? NATIVE[n]({ from: from, to: to }).catch(function(){ return null; }) : Promise.resolve(null); };
  const pr = { getSteps: chiedi('getSteps'), getWorkouts: chiedi('getWorkouts'), getInstalls: chiedi('getInstalls'), getNotifLog: chiedi('getNotifLog') };
  try{
    if (NATIVE.getSteps){
      const r = await pr.getSteps;
      if (r){
        out.passi = (r.minuti || []).map(function(m){ return { t: +m.t, n: +m.n }; });
        out.passiStato = { available: !!r.available, granted: !!r.granted, totale: r.totale || 0, fonte: r.fonte || '',
                           health: !!r.health, healthSteps: !!r.healthSteps, healthWorkouts: !!r.healthWorkouts };
      }
    }
  }catch(_){ }
  try{
    if (NATIVE.getWorkouts){
      const r = await pr.getWorkouts;
      out.allenamenti = ((r && r.items) || []).map(function(x){ return { s: +x.s, e: +x.e, tipo: x.tipo, l: dpAllenamentoNome(x.tipo, x.l) }; });
    }
  }catch(_){ }
  try{
    if (NATIVE.getInstalls){
      const r = await pr.getInstalls;
      out.installazioni = ((r && r.items) || []).map(function(x){ return { t: +x.t, p: x.p, l: x.l }; });
    }
  }catch(_){ }
  try{
    if (NATIVE.getNotifLog){
      const r = await pr.getNotifLog;
      out.notif = ((r && r.items) || []).map(function(x){ return { t: +x.t, p: x.p }; });
    }
  }catch(_){ }
  return out;
}

/* I tipi di allenamento di Health Connect che contano di piu' qui; gli altri restano «Allenamento». */
const DP_ALLENA = { 56: 'Corsa', 57: 'Corsa sul tapis roulant', 16: 'Ballo', 70: 'Pesi', 81: 'Pesi', 8: 'Bici', 9: 'Bici da camera',
                    74: 'Nuoto', 73: 'Nuoto', 83: 'Yoga', 36: 'HIIT', 10: 'Bootcamp', 13: 'Calisthenics' };
function dpAllenamentoNome(tipo, titolo){ return titolo || DP_ALLENA[tipo] || 'Allenamento'; }

/* ---------------------------------------------------------------------------------------
   LA STORIA: i giorni chiusi, per la settimana, il mese e la partenza di oggi.
   Ogni giorno passato si simula UNA volta con la sua cronologia intera, partendo da come e'
   finito il giorno prima, e si tiene come stato finale (S, P, D) e punteggio.
   --------------------------------------------------------------------------------------- */
function dpGiorni(){ try{ return JSON.parse(localStorage.getItem(DP_GIORNI_KEY) || '{}') || {}; }catch(_){ return {}; } }
function dpR2(v){ return Math.round((v || 0) * 100) / 100; }

async function dpStoria(n){
  const g = dpGiorni();
  const oggi = dpMezzanotte();
  let scritti = 0;
  for (let i = 1; i <= n; i++){
    const from = oggi - i * DP_DAY, to = from + DP_DAY;
    const k = dpChiave(from);
    if (g[k]) continue;
    const grani = await dpGraniTelefono(from, to);
    if (!grani) break;                      // niente permesso: niente storia
    const prima = g[dpChiave(from - 1)];
    let sonni = [];
    try{
      if (typeof scReport === 'function'){
        /* la notte che finisce questa mattina e quella che comincia questa sera */
        sonni = dpSonni(await scReport(i)).concat(dpSonni(await scReport(i - 1)));
      }
    }catch(_){ }
    const nat = await dpFattiNativi(from, to);
    const r = dmSimula({
      from: from, to: to, cfg: DM_CFG,
      s0: prima && prima.n ? prima.S : DM_CFG.base, p0: prima && prima.n ? prima.P : 0, d0: prima && prima.n ? prima.D : 0,
      grani: grani, sonni: sonni, ff: dpFF(from, to), passi: nat.passi, notif: nat.notif, allenamenti: nat.allenamenti,
      spunte: dpSpunteFra(from, to), checkin: dpCheckin(from, to), viste: dpViste(from, to),
      installazioni: nat.installazioni, pianificato: dpPianificato(from)
    });
    g[k] = { S: dpR2(r.S), P: dpR2(r.P), D: dpR2(r.D), fine: dpR2(r.score), n: grani.length, fasce: r.fasce,
             top: r.giu[0] ? { l: r.giu[0].l, delta: dpR2(r.giu[0].delta) } : null,
             su: r.su[0] ? { l: r.su[0].l, delta: dpR2(r.su[0].delta) } : null };
    scritti++;
    if (scritti >= 4) break;                // quattro giornate per apertura: il resto dopo
  }
  if (scritti){
    /* se ne tengono quaranta: la settimana e il mese non ne chiedono di piu' */
    const tieni = {};
    Object.keys(g).sort().slice(-40).forEach(function(k){ tieni[k] = g[k]; });
    try{ localStorage.setItem(DP_GIORNI_KEY, JSON.stringify(tieni)); }catch(_){ }
    dpArchivia(tieni);
    return tieni;
  }
  return g;
}

/**
 * Da dove parte oggi: lo stato con cui e' finito ieri. Prima la storia (ieri letto intero),
 * poi l'ultimo calcolo di ieri, poi la base.
 */
function dpPartenza(mezzanotte, storia){
  const kIeri = dpChiave(mezzanotte - 1);
  try{
    const ieri = storia && storia[kIeri];
    if (ieri && ieri.n && typeof ieri.S === 'number') return { S: ieri.S, P: ieri.P || 0, D: ieri.D || 0, ieri: ieri };
  }catch(_){ }
  try{
    const chiavi = [DP_FINE_KEY, DP_FINE_KEY + '_ieri'];
    for (let i = 0; i < chiavi.length; i++){
      const f = JSON.parse(localStorage.getItem(chiavi[i]) || 'null');
      if (f && f.giorno === kIeri && typeof f.S === 'number') return { S: f.S, P: f.P || 0, D: f.D || 0 };
    }
  }catch(_){ }
  return { S: DM_CFG.base, P: 0, D: 0 };
}

/* ---------------------------------------------------------------------------------------
   IL CALCOLO DI OGGI
   --------------------------------------------------------------------------------------- */
async function dpCalcola(forza){
  if (DP.inCorso) return DP.inCorso;
  if (!forza && DP.dett && Date.now() - DP.at < 20000) return DP.dett;
  DP.inCorso = (async function(){
    try{ return await dpCalcolaOra(); }
    finally{ DP.inCorso = null; }
  })();
  return DP.inCorso;
}

async function dpCalcolaOra(){
  const from = dpMezzanotte(), to = Date.now(), giorno = dpChiave(from);
  let qui = 'mobile';
  try{ qui = (typeof pcQui === 'function') ? pcQui() : 'mobile'; }catch(_){ }

  /* 0.9.306: sul telefono tutte le letture del calcolo partono INSIEME, qui. Prima partivano una dopo l'altra, e
     ognuna aspettava il suo turno in fondo alla coda del ponte nativo, dietro alle letture di tutte le altre
     schermate che si aprono all'avvio: dieci attese in fila invece di una. */
  const pre = qui === 'desktop' ? null : {
    locali: dpGraniTelefono(from, to),
    cg: dpGraniComputer(from).catch(function(){ return null; }),
    storia: dpStoria(1).catch(function(){ return dpGiorni(); }),
    rep: (typeof scReport === 'function') ? scReport(0).catch(function(){ return null; }) : Promise.resolve(null),
    notif: (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getNotifications) ? NATIVE.getNotifications({ dayStart: from, limit: 1 }).catch(function(){ return null; }) : Promise.resolve(null),
    nat: dpFattiNativi(from, to)
  };

  /* I GRANELLI DI QUESTO DISPOSITIVO: sul telefono le app, sul computer programmi e siti. */
  const locali = pre ? await pre.locali : await dpGraniTelefono(from, to);
  const permesso = locali !== null;
  let grani = [];
  const fonti = [];
  if (locali && locali.length){
    if (qui === 'desktop'){
      locali.forEach(function(g){ g.fonte = 'computer'; g.dev = 'computer'; });
      await dpRipesaComputer(locali);
    }
    grani = grani.concat(locali);
    fonti.push(qui === 'desktop' ? 'computer' : 'telefono');
  }

  /* I GRANELLI DELL'ALTRO DISPOSITIVO, SOLO CON L'ORA VERA.
     BUG 1 — prima, quando l'altro non aveva pubblicato la sua cronologia, si prendeva la sua
     riga aggregata (minuti per app, senza orario) e la si spalmava dalle 08:00 in pezzi da
     dieci minuti tutti uguali (dpGraniRiga): Claude «alle 08:00, 08:21, 08:42», tutto in
     contemporanea. Un minuto senza orario non e' un fatto: adesso non entra. */
  let tel = null;
  if (qui === 'desktop'){
    tel = await dpLeggiTelefono();
    /* UN NUMERO SOLO. Il telefono ha tutto (riprese, notifiche, passi, sonno, e i granelli del
       computer con l'ora vera): se ha pubblicato da poco il suo calcolo, qui si mostra quello. */
    if (tel && tel.giorno === giorno && tel.ris && to - (tel.at || 0) < 10 * 60000){
      const d = dpDaTelefono(tel, from, permesso);
      /* 0.9.306, Andrea: "dopo un respiro la schermata dice 39, l'intestazione resta 36". LA CAUSA, sul computer: qui
         si mostrava il calcolo del telefono com'era, e il telefono il respiro fatto qui non l'aveva mai visto (lo
         specchio va solo dal telefono al computer, e copiandosi sopra cancellava anche il check-in di qui). Adesso il
         check-in del computer viaggia con i suoi granelli (dpPubblicaComputer), il telefono lo conta, e finche' non
         l'ha contato si aggiunge qui. */
      const visti = Array.isArray(tel.ckPc) ? tel.ckPc : [];
      const miei = dpCheckin(from, Date.now() + 1).filter(function(c){ return c.tipo === 'tempo' && c.dev === 'computer' && c.delta > 0 && visti.indexOf(c.t) < 0; });
      const piu = miei.reduce(function(a, c){ return a + Math.min(45, c.delta); }, 0);
      if (piu > 0) d.riserva = Math.min(DM_CFG.max, d.riserva + piu);
      DP.dett = d; DP.L = d.riserva; DP.at = to;
      dpAvvisa(d);
      dpPubblicaComputer(d, locali || []);
      return d;
    }
    const tg = await dpGraniPubblicati(from);
    if (tg && tg.length){ grani = grani.concat(tg); fonti.push('telefono'); }
  } else {
    const cg = pre ? await pre.cg : await dpGraniComputer(from);
    if (cg && cg.length){ grani = grani.concat(cg); fonti.push('computer'); }
  }
  const grigio = await dpGrigio();
  grani.forEach(function(g){ g.grigio = dpInGrigio(g, grigio); });

  let storia = {};
  /* prima di oggi serve solo ieri (la partenza): gli altri giorni li legge dpStoriaDopo, in sottofondo */
  try{ storia = pre ? await pre.storia : await dpStoria(1); }catch(_){ storia = dpGiorni(); }
  if (tel && tel.storia){ storia = Object.assign({}, storia, tel.storia); dpArchivia(tel.storia); }
  const st0 = dpPartenza(from, storia);

  /* i fatti che non sono granelli */
  let rep = null;
  try{ if (pre) rep = await pre.rep; else if (typeof scReport === 'function') rep = await scReport(0); }catch(_){ }
  if (qui === 'desktop' && tel && tel.giorno === giorno && tel.rep) rep = tel.rep;
  let notifiche = 0;
  try{
    if (qui !== 'desktop' && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getNotifications){
      const nn = pre ? await pre.notif : await NATIVE.getNotifications({ dayStart: from, limit: 1 });
      if (nn && nn.granted !== false) notifiche = nn.total || 0;
    }
  }catch(_){ }
  const nat = qui === 'desktop' ? { passi: [], notif: [], passiStato: null, allenamenti: [], installazioni: [] } : await pre.nat;

  /* 0.9.306: il carburante guadagnato sul computer (un respiro, una task chiusa nel tempo) arriva con i suoi granelli */
  const ckPc = qui === 'desktop' ? [] : dpCheckinComputer(giorno, from, to);
  const sonni = dpSonni(rep);
  const ris = dmSimula({
    from: from, to: to, cfg: DM_CFG, s0: st0.S, p0: st0.P, d0: st0.D,
    grani: grani, sonni: sonni, ff: dpFF(from, to), passi: nat.passi, notif: nat.notif, allenamenti: nat.allenamenti,
    spunte: dpSpunteFra(from, to), checkin: dpCheckin(from, to).concat(ckPc), viste: dpViste(from, to), serie: dpSerie(),
    installazioni: nat.installazioni, pianificato: dpPianificato(from),
    riprese: (rep && rep.granted && rep.pickups) || 0, notifiche: notifiche
  });

  const d = {
    from: from, to: to, giorno: giorno, grani: grani, ris: ris, riserva: dpConTardivi(ris.score, to),
    fonti: fonti, autorita: 'qui', storia: storia, ieri: st0.ieri || null, passi: nat.passiStato,
    grigio: !!(grigio && grigio.on), senzaDati: !fonti.length && !permesso, vuoto: !fonti.length && permesso, at: to,
    ckPc: ckPc.map(function(c){ return c.t; }),
    svegliato: sonni.some(function(z){ return z.e > from && z.e <= to; })
  };
  DP.dett = d; DP.L = d.riserva; DP.at = to;
  dpAvvisa(d);
  dpStoriaDopo();
  /* IL DEBITO DI IERI NON SI PERDE A MEZZANOTTE: l'ultimo calcolo di ieri resta in una chiave sua. */
  try{
    const prev = JSON.parse(localStorage.getItem(DP_FINE_KEY) || 'null');
    if (prev && prev.giorno && prev.giorno !== giorno) localStorage.setItem(DP_FINE_KEY + '_ieri', JSON.stringify(prev));
    localStorage.setItem(DP_FINE_KEY, JSON.stringify({ giorno: giorno, S: ris.S, P: ris.P, D: ris.D, at: to }));
  }catch(_){ }
  if (qui === 'desktop') dpPubblicaComputer(d, locali || []);
  else dpPubblica(d, locali || []);
  return d;
}

/**
 * 0.9.306: il carburante guadagnato MENTRE il calcolo girava. Il calcolo legge i check-in all'inizio; un respiro
 * finito a meta' calcolo arrivava dopo, e questo calcolo (vecchio) riportava l'intestazione al numero di prima
 * finche' non ne finiva un altro: "+3, 39" nella schermata del respiro e "36" in alto per diversi secondi.
 * Quei punti si aggiungono qui; il calcolo dopo li conta al loro minuto.
 */
function dpConTardivi(score, to){
  try{
    const piu = dpCheckin(to, Date.now() + 1).filter(function(c){ return c.tipo === 'tempo' && c.delta > 0; })
      .reduce(function(a, c){ return a + Math.min(45, c.delta); }, 0);
    return piu > 0 ? Math.min(DM_CFG.max, score + piu) : score;
  }catch(_){ return score; }
}
/** Sul telefono: i check-in di oggi fatti sul computer, che il computer pubblica con i suoi granelli. */
function dpCheckinComputer(giorno, from, to){
  try{
    if (!DP_PC || DP_PC.giorno !== giorno || !Array.isArray(DP_PC.ck)) return [];
    const miei = dpCheckin(from, to);
    return DP_PC.ck.filter(function(c){
      return c && c.tipo === 'tempo' && c.t >= from && c.t < to && c.delta > 0
        && !miei.some(function(m){ return m.t === c.t && m.delta === c.delta; });
    }).map(function(c){ return { t: +c.t, tipo: 'tempo', delta: +c.delta, l: c.l || 'Dal computer', nota: c.nota || '', dev: 'computer' }; });
  }catch(_){ return []; }
}
/** Il numero nuovo va dappertutto dove si vede: intestazione, scheda del Profilo, e resta per il prossimo avvio. */
function dpAvvisa(d){
  try{ localStorage.setItem(DP_ULTIMO_KEY, JSON.stringify({ giorno: d.giorno, L: d.riserva, at: d.at })); }catch(_){ }
  try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  try{ if (typeof PFC_HTML !== 'undefined' && PFC_HTML && PFC_HTML[0] !== null) PFC_HTML[0] = dpCardHtml(d, 'profilo'); }catch(_){ }
  try{ dpBollaSync(); }catch(_){ }
}

/* LA BOLLA DEL CARBURANTE (0.9.311). Fuori dall'app la pagina non gira: qui si manda al telefono l'ultimo numero
   dell'intestazione (DP.L), con il debito e l'ora, e da li' il telefono continua il conto con gli stessi numeri del
   motore (CarburanteStima.java). Riaperta l'app, il calcolo vero sostituisce la stima.
   I pesi delle app viaggiano solo quando cambiano: sono gli stessi di dpPeso, cosi' una categoria scelta a mano vale
   anche fuori. Spenta di serie: la accende solo chi la sceglie nelle Impostazioni. */
const DP_BOLLA_KEY = 'fl_dopa_bolla';
let DP_BOLLA_PESI = '', DP_BOLLA_DETTA = null;
function dpBollaOn(){ try{ return localStorage.getItem(DP_BOLLA_KEY) === '1'; }catch(_){ return false; } }
function dpBollaPesi(d){
  const cats = (typeof insCats === 'function') ? insCats(null) : {};
  const ex = (typeof insExcl === 'function') ? insExcl() : [];
  const nomi = {};
  ((d && d.grani) || []).forEach(function(g){ if (g.dev === 'telefono' && g.p) nomi[g.p] = g.l || ''; });
  Object.keys(dpMappa()).concat(Object.keys(cats), ex, (typeof INS_BROWSERS !== 'undefined' ? INS_BROWSERS : [])).forEach(function(p){ if (p && !(p in nomi)) nomi[p] = ''; });
  const pesi = {};
  Object.keys(nomi).forEach(function(p){ pesi[p] = dpPeso(p, cats, ex, nomi[p]); });
  return pesi;
}
function dpBollaSync(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.carburanteBolla){ dpBollaDentro(0); return; }
  if (typeof pcQui === 'function' && pcQui() === 'desktop'){ dpBollaDentro(0); return; }
  if (!dpBollaOn()){
    if (DP_BOLLA_DETTA !== false) NATIVE.carburanteBolla({ on: false }).catch(function(){ });
    DP_BOLLA_DETTA = false;
    return;
  }
  const d = DP.dett;
  if (!d || !d.ris || typeof DP.L !== 'number') return;
  const dati = { on: true, giorno: d.giorno, at: d.at, L: DP.L, D: d.ris.D || 0, sv: !!d.svegliato,
                 noia: (d.ris.voci || []).filter(function(v){ return v.tipo === 'noia'; }).length };
  const pesi = dpBollaPesi(d);
  const grigio = DP.grigio || null;
  const firma = JSON.stringify([pesi, grigio && [grigio.on, grigio.modo, grigio.apps, grigio.colori]]);
  if (firma !== DP_BOLLA_PESI){
    DP_BOLLA_PESI = firma;
    dati.pesi = pesi;
    dati.pat = DP_NOMI.map(function(x){ return [x[0].source, x[1]]; });
    dati.audio = DP_AUDIO;
    dati.gr = { on: !!(grigio && grigio.on), modo: (grigio && grigio.modo) || 'lista', apps: grigio ? ((grigio.modo === 'eccezioni' ? grigio.colori : grigio.apps) || []) : [] };
  }
  DP_BOLLA_DETTA = true;
  /* la risposta dice fin dove la bolla sopra alle altre app ha gia' parlato: dentro all'app non si ripete */
  NATIVE.carburanteBolla(dati).then(function(r){ dpBollaDentro((r && +r.dettoFino) || 0); }).catch(function(){ DP_BOLLA_PESI = ''; });
}
/* 0.9.315, Andrea: "nella pagina vedo tanti -0,6 e la bolla non me li ha mai detti". Quello che e' successo mentre l'app era chiusa
   o sul computer (la dispersione conta anche quello) si dice appena si rientra: una bolla con la variazione e il motivo. */
const DP_BOLLA_VISTE = 'fl_dopa_bolla_viste';
const DP_BOLLA_NO = { sessione: 0, dopo: 1, ritorno: 1, uso: 1, minori: 1, sonno: 1, tempo: 1, spunta: 1 };
const DP_BOLLA_TAPPO = 2;
function dpBollaMotivo(v){
  if (v.tipo === 'sessione') return v.l + ': ' + String(v.nota || '').split(' · ')[0];
  if (v.tipo === 'dispersione') return v.nota;
  return v.l + (v.nota ? ': ' + v.nota : '');
}
function dpBollaEventi(d){
  return ((d.ris && d.ris.voci) || []).filter(function(v){ return !DP_BOLLA_NO[v.tipo] && Math.abs(v.delta) >= .05; });
}
function dpBollaDentro(dettoFino){
  if (!dpBollaOn()) return;
  const d = DP.dett; if (!d || !d.ris) return;
  if (typeof FF !== 'undefined' && FF && FF.run) return;
  let st = null; try{ st = JSON.parse(localStorage.getItem(DP_BOLLA_VISTE) || 'null'); }catch(_){ }
  const chiave = function(v){ return v.tipo + ':' + v.t; }, ev = dpBollaEventi(d);
  const primo = !st || st.giorno !== d.giorno;
  const viste = primo ? [] : (st.k || []);
  /* la prima volta (o il primo calcolo del giorno, se e' appena passata la mezzanotte) non si recupera il passato lontano */
  const nuove = ev.filter(function(v){ return viste.indexOf(chiave(v)) < 0 && (v.fine || v.t) > dettoFino && !(primo && !st); });
  try{ localStorage.setItem(DP_BOLLA_VISTE, JSON.stringify({ giorno: d.giorno, k: ev.map(chiave).slice(-80) })); }catch(_){ }
  if (!nuove.length) return;
  const somma = nuove.reduce(function(a, v){ return a + v.delta; }, 0);
  const ultima = nuove[nuove.length - 1];
  dpBollaMostra(d.riserva, somma, nuove.length > DP_BOLLA_TAPPO ? nuove.length + ' cambiamenti: tocca per vederli' : (nuove.length === 2 ? dpBollaMotivo(ultima) + ', e un altro' : dpBollaMotivo(ultima)));
}
function dpBollaMostra(livello, delta, motivo){
  let w = document.getElementById('dpBollaV');
  if (!w){ w = document.createElement('button'); w.type = 'button'; w.id = 'dpBollaV'; w.className = 'dp-bolla'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.onclick = function(){ w.classList.remove('in'); try{ if (typeof ccApri === 'function') ccApri(); else dpApri(); }catch(_){ } };
  const giu = delta < 0, val = Math.abs(delta).toFixed(1).replace('.', ',');
  /* 0.9.317, Andrea: "quella freccia rossa fa schifo". Il piccolo tachimetro, il livello, e la variazione in una pillola */
  w.innerHTML = '<span class="dp-bolla-i">' + dpGaugeSvgPiccolo(livello) + '</span><span class="dp-bolla-t"><span class="dp-bolla-r"><b>Carburante ' + Number(livello).toFixed(1).replace('.', ',') + '</b><em class="' + (giu ? 'giu' : 'su') + '">' + (giu ? '−' : '+') + val + '</em></span><small>' + esc(motivo) + '</small></span>';
  w.classList.remove('in'); void w.offsetWidth; w.classList.add('in');
  clearTimeout(dpBollaMostra.t); dpBollaMostra.t = setTimeout(function(){ w.classList.remove('in'); }, 6000);
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.dp-bolla{position:fixed;left:10px;top:calc(env(safe-area-inset-top,0px) + 8px);z-index:9700;display:flex;align-items:center;gap:10px;max-width:calc(100% - 20px);padding:9px 14px 9px 10px;border:1px solid rgba(140,198,255,.28);border-radius:20px;background:linear-gradient(135deg,#0E2350,#14306B);box-shadow:0 10px 26px rgba(0,30,68,.38);text-align:left;cursor:pointer;opacity:0;transform:translateY(-12px);pointer-events:none;transition:opacity .22s,transform .22s}'
    + '.dp-bolla.in{opacity:1;transform:none;pointer-events:auto}'
    + '.dp-bolla-i{flex:none;width:44px;color:#fff;line-height:0}.dp-bolla-i svg{display:block;width:100%;height:auto}'
    + '.dp-bolla-t{min-width:0;flex:1}.dp-bolla-r{display:flex;align-items:center;gap:8px}.dp-bolla-r b{font:800 14.5px var(--font-body);color:#fff;white-space:nowrap}'
    + '.dp-bolla-r em{flex:none;padding:2px 9px;border-radius:99px;font:800 12.5px var(--font-body);font-style:normal;color:#fff}.dp-bolla-r em.giu{background:#E63946}.dp-bolla-r em.su{background:#0075E3}'
    + '.dp-bolla-t small{display:block;margin-top:3px;font:600 12.5px/1.3 var(--font-body);color:#BCE0FF;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}';
  document.head.appendChild(st);
})();
function dpBollaPaint(){
  const sw = document.getElementById('dpBollaSw'); if (sw) sw.className = 'switch' + (dpBollaOn() ? ' on' : '');
  const hint = document.getElementById('dpBollaHint');
  if (!hint) return;
  if (!dpBollaOn()){ hint.hidden = true; return; }
  (async function(){
    let ok = true;
    try{ if (NATIVE && NATIVE.isUsageAccessGranted){ const t = await NATIVE.isUsageAccessGranted(); ok = !!(t && t.granted); } }catch(_){ }
    hint.hidden = ok;
  })();
}
async function dpBollaToggle(){
  try{ localStorage.setItem(DP_BOLLA_KEY, dpBollaOn() ? '0' : '1'); }catch(_){ }
  dpBollaPaint();
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  /* i pesi vanno rimandati: la parte nativa potrebbe non averli mai visti */
  DP_BOLLA_PESI = '';
  if (dpBollaOn() && !DP.dett){ try{ await dpCalcola(false); }catch(_){ } }
  dpBollaSync();
}
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-settings') setTimeout(dpBollaPaint, 30); });
/* uscendo dall'app il telefono deve avere il numero di adesso, anche quello appena salito con un respiro (fcAggiungi) */
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden'){ try{ dpBollaSync(); }catch(_){ } } });
/** Il resto della storia (fino a trenta giorni), dopo il calcolo di oggi e senza farlo aspettare. */
let DP_STORIA_DOPO = null;
function dpStoriaDopo(){
  if (DP_STORIA_DOPO) return;
  DP_STORIA_DOPO = setTimeout(async function(){
    try{
      const prima = Object.keys(dpGiorni()).length;
      const st = await dpStoria(30);
      if (DP.dett && Object.keys(st).length !== prima){ DP.dett.storia = Object.assign({}, st, DP.dett.storia || {}); dpRidipingi(); }
      if (Object.keys(st).length !== prima) dpPgRidipingi();
    }catch(_){ }
    DP_STORIA_DOPO = null;
  }, 1500);
}

/** Sul computer: il calcolo che il telefono ha pubblicato, com'e'. */
function dpDaTelefono(tel, from, permesso){
  const r = dpRisEspandi(tel.ris, from);
  return {
    from: from, to: tel.at, giorno: tel.giorno, grani: [], ris: r, riserva: r.score,
    fonti: ['telefono', 'computer'], autorita: 'telefono', storia: tel.storia || {}, ieri: null, passi: null,
    grigio: false, senzaDati: false, vuoto: false, at: tel.at
  };
}

/**
 * I granelli del computer arrivano dal suo motore con il nome del programma o del sito, ma
 * senza la categoria che l'utente ha scelto nel pannello del computer. Quella sta nella riga
 * aggregata (`fl:pc-usage`), voce per voce: si prende di li' e si riapplica.
 */
async function dpRipesaComputer(grani){
  let mappa = {};
  try{
    if (typeof pcSync === 'function') await pcSync();
    const pc = (typeof pcGiorno === 'function') ? pcGiorno(0) : null;
    (pc && pc.top || []).forEach(function(t){ if (t && t.k) mappa[String(t.k).toLowerCase()] = t.c; });
  }catch(_){ }
  /* la categoria scelta sul telefono vale anche per lo stesso nome sul computer */
  let telefono = {};
  try{
    const cats = (typeof insCats === 'function') ? insCats() : {};
    const nomi = JSON.parse(localStorage.getItem('fl_app_nomi') || '{}') || {};
    Object.keys(cats).forEach(function(pkg){
      const l = String(nomi[pkg] || '').toLowerCase(); if (!l) return;
      telefono[l] = cats[pkg] === 'prod' ? 'Productive' : (cats[pkg] === 'distr' ? 'Distracting' : 'Neutral');
    });
  }catch(_){ }
  grani.forEach(function(g){
    const nome = String(g.l || g.p).toLowerCase();
    const c = mappa[nome] || mappa[String(g.p || '').toLowerCase()] || telefono[nome] || null;
    g.di = dpPesoNome(g.l || g.p, c);
  });
}

/* ---------------------------------------------------------------------------------------
   IL PONTE: il telefono pubblica, il computer legge
   --------------------------------------------------------------------------------------- */
const DP_SLOT = 'fl:dopamina';
const DP_PUB_OGNI = 60000;         // ogni minuto: telefono e computer devono dire la stessa cosa adesso
const DP_GR_MAX = 500, DP_GR_MIN_MS = 20000;
let DP_PUB_AT = 0, DP_TEL = null, DP_TEL_AT = 0;

/** I granelli in forma compatta: [pacchetto, etichetta, secondi da mezzanotte, secondi, di, 100, grigio]. */
function dpComprimi(grani, from){
  const out = [];
  (grani || []).forEach(function(g){
    if (!g || !(g.ms >= DP_GR_MIN_MS)) return;
    if (g.s < from || g.s >= from + DP_DAY) return;
    out.push([g.p, g.l === g.p ? '' : (g.l || ''), Math.round((g.s - from) / 1000), Math.round(g.ms / 1000),
              Math.round((g.di || 0) * 100), 100, g.grigio ? 1 : 0]);
  });
  return out.slice(-DP_GR_MAX);
}
function dpEspandi(gr, from, dev){
  /* chi legge scarta lo stesso: una riga di una versione vecchia puo' portare offset fuori giornata */
  return (gr || []).filter(function(a){ return a && a[2] >= 0 && a[2] < 86400; }).map(function(a){
    /* le versioni vecchie mandavano un moltiplicatore di ritmo: qui non serve piu', si tiene l'indice */
    return { p: a[0], l: a[1] || a[0], s: from + a[2] * 1000, ms: a[3] * 1000,
             di: (a[4] || 0) / 100, grigio: !!a[6], fonte: dev || 'telefono', dev: dev || 'telefono' };
  });
}
/** Il risultato del motore in forma da spedire: gli orari diventano minuti da mezzanotte. */
function dpRisComprimi(r, from){
  const m = function(t){ return Math.round((t - from) / 60000); };
  return {
    start: dpR2(r.start), score: dpR2(r.score), S: dpR2(r.S), P: dpR2(r.P), D: dpR2(r.D),
    punti: r.punti.map(function(p){ return [m(p.t), dpR2(p.v), dpR2(p.s)]; }),
    voci: r.voci.slice(-160).map(function(v){ return { tipo: v.tipo, t: m(v.t), fine: m(v.fine || v.t), delta: Math.round(v.delta * 1000) / 1000,
                                                       dev: v.dev, min: v.min, l: v.l, nota: v.nota, causa: v.causa }; }),
    contatori: r.contatori, su: r.su, giu: r.giu
  };
}
function dpRisEspandi(c, from){
  const t = function(m){ return from + m * 60000; };
  const voci = (c.voci || []).map(function(v){ return Object.assign({}, v, { t: t(v.t), fine: t(v.fine) }); });
  return {
    start: c.start, score: c.score, S: c.S, P: c.P, D: c.D,
    punti: (c.punti || []).map(function(p){ return { t: t(p[0]), v: p[1], s: p[2] || 0 }; }),
    voci: voci, contatori: c.contatori || {}, su: c.su || [], giu: c.giu || [], errori: [],
    somma: voci.reduce(function(a, v){ return a + v.delta; }, 0)
  };
}

async function dpPubblica(d, grani){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupSave) return;
    if (Date.now() - DP_PUB_AT < DP_PUB_OGNI) return;
    DP_PUB_AT = Date.now();
    const storia = {};
    const g = dpGiorni();
    Object.keys(g).sort().slice(-31).forEach(function(k){ storia[k] = g[k]; });
    /* LA GIORNATA, per il computer che non puo' misurarla: senza, li' non compaiono ne' il
       pannello di panoramica del Blocco ne' i tre punteggi del Profilo. */
    let rep = null, sc = null;
    try{
      if (typeof scReport === 'function'){
        /* 0.9.302: la giornata del TELEFONO, anche quando sul telefono e' scelta la sorgente "computer": prima partiva
           il rapporto della sorgente scelta, e il computer riceveva i propri programmi come "la giornata del telefono" */
        const r0 = (typeof scReportPunteggi === 'function') ? await scReportPunteggi(0) : await scReport(0);
        if (r0 && r0.granted){
          rep = {
            granted: true, dayStart: r0.dayStart, screenMs: r0.screenMs || 0, pickups: r0.pickups || 0,
            blocks: r0.blocks || 0, sessions: r0.sessions || 0, firstUse: r0.firstUse || 0,
            lastUse: r0.lastUse || 0, wakeAt: r0.wakeAt || 0, awakeFrom: r0.awakeFrom || 0,
            sleepMs: r0.sleepMs || 0, sleepStart: r0.sleepStart || 0, longestGapMs: r0.longestGapMs || 0,
            notte: r0.notte || null, sonnoV: r0.sonnoV || 0,
            awakeScreenMs: r0.awakeScreenMs, awakeGapMs: r0.awakeGapMs || 0,
            lockedMs: r0.lockedMs || 0, countLocked: !!r0.countLocked,
            top: (r0.top || []).slice(0, 8).map(function(a){
              return { packageName: a.packageName, label: a.label, ms: a.ms, launcher: !!a.launcher }; }),
            daTelefono: true
          };
          if (typeof scCompute === 'function'){
            const c = scCompute(r0);
            if (c) sc = { sleep: c.sleep, focus: c.focus, rest: c.rest, total: c.total };
          }
        }
      }
    }catch(_){ }
    /* 0.9.302: le icone delle app di oggi e i launcher, per il computer che mostra queste righe (motore-web.js) */
    let im = { ico: {}, lnc: [] };
    try{ if (typeof mwIcoMappa === 'function') im = await mwIcoMappa(grani); }catch(_){ }
    await NATIVE.backupSave({
      web: { dopamina: { giorno: dpChiave(d.from), at: d.at, riserva: d.riserva, S: d.ris.S, P: d.ris.P, D: d.ris.D, ckPc: d.ckPc || [],
                         gr: dpComprimi(grani, d.from), storia: storia, rep: rep, sc: sc,
                         ris: dpRisComprimi(d.ris, d.from), done: dpSpunteOggi(d.from), ico: im.ico, lnc: im.lnc } },
      slot: DP_SLOT, slotName: 'Dopamina'
    });
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   E IL COMPUTER PUBBLICA I SUOI, di granelli: con l'ora vera, e il primo segno di vita del
   giorno (la notte e' finita li', anche se il telefono e' rimasto fermo fino alle undici).
   --------------------------------------------------------------------------------------- */
const DP_SLOT_PC = 'fl:pc-grani';
let DP_PUB_PC_AT = 0, DP_PC = null, DP_PC_AT = 0;

async function dpPubblicaComputer(d, grani){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupSave) return;
    if (Date.now() - DP_PUB_PC_AT < DP_PUB_OGNI) return;
    DP_PUB_PC_AT = Date.now();
    let primo = 0, ultimo = 0;
    (grani || []).forEach(function(g){
      if (!(g.ms > 0)) return;
      if (!primo || g.s < primo) primo = g.s;
      if (g.s + g.ms > ultimo) ultimo = g.s + g.ms;
    });
    const pcgrani = { giorno: dpChiave(d.from), at: Date.now(), primo: primo, ultimo: ultimo, gr: dpComprimi(grani, d.from) };
    /* 0.9.306: il carburante guadagnato qui (respiro, task chiusa nel tempo), perche' il telefono lo conti */
    try{ pcgrani.ck = dpCheckin(d.from, Date.now() + 1).filter(function(c){ return c.tipo === 'tempo' && c.dev === 'computer'; }).slice(-60); }catch(_){ }
    /* 0.9.302: le icone dei programmi di oggi, per il telefono che mostra queste righe (motore-web.js) */
    try{ if (typeof mwIcoMappa === 'function') pcgrani.ico = (await mwIcoMappa(grani)).ico; }catch(_){ }
    /* PERCHE' IL TELEFONO NON VEDEVA MAI IL COMPUTER (28/09/2026). Il programma desktop non
       conosce il campo `slot` di backupSave: i granelli finivano nella riga di backup del
       computer, non nella riga di sistema `fl:pc-grani` che il telefono cerca. Il telefono
       quindi non trovava ne' i numeri del computer ne' il segno «ci sono due dispositivi», e
       i tre puntini del Report («Dati del computer / del telefono / tutti e due») non
       comparivano. La riga si scrive ora direttamente, come fa il foglio (foglio-sync.js),
       con accountApi, che c'e' su tutti e due. backupSave resta solo come ripiego. */
    if (NATIVE.accountApi){
      await NATIVE.accountApi({ method: 'PUT', path: '/api/focuslock/backups', body: JSON.stringify({
        deviceId: DP_SLOT_PC, deviceName: 'Computer, ora per ora', appVersion: 'pc-grani',
        summary: { programs: 0, apps: 0, sites: 0, keywords: 0 }, backup: { web: { pcgrani: pcgrani } } }) });
    } else {
      await NATIVE.backupSave({ web: { pcgrani: pcgrani }, slot: DP_SLOT_PC, slotName: 'Computer, ora per ora' });
    }
  }catch(_){ }
}

async function dpLeggiComputer(){
  if (DP_PC && Date.now() - DP_PC_AT < DP_PUB_OGNI) return DP_PC;
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return DP_PC;
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === DP_SLOT_PC; })[0];
    if (!riga) return DP_PC;
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const p = (pieno && pieno.payload) || null;
    const v = p && ((p.web && p.web.pcgrani) || p.pcgrani);
    if (v && v.giorno){ DP_PC = v; DP_PC_AT = Date.now(); }
  }catch(_){ }
  return DP_PC;
}

/** I granelli veri del computer per oggi, o null se il computer non li ha pubblicati. */
async function dpGraniComputer(from){
  const v = await dpLeggiComputer();
  if (!v || v.giorno !== dpChiave(from) || !Array.isArray(v.gr) || !v.gr.length) return null;
  return dpEspandi(v.gr, from, 'computer');
}

/** Il primo segno di vita sul computer, oggi. Zero se non si sa. */
function dpComputerPrimo(giorno){
  if (!DP_PC || DP_PC.giorno !== giorno) return 0;
  return DP_PC.primo || 0;
}

/** I granelli che il telefono ha pubblicato per oggi, gia' pronti da simulare. */
async function dpGraniPubblicati(from){
  const t = await dpLeggiTelefono();
  if (!t || t.giorno !== dpChiave(from) || !Array.isArray(t.gr) || !t.gr.length) return null;
  return dpEspandi(t.gr, from, 'telefono');
}
/** Le spunte di oggi, per il computer: giorno, testo, ora. */
function dpSpunteOggi(from){
  try{
    const k0 = dpChiave(from);
    return (JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [])
      .filter(function(x){ return x && x.day === k0; })
      .map(function(x){ return { day: x.day, text: x.text, at: x.at }; }).slice(-60);
  }catch(_){ return []; }
}
/** Sul computer: le spunte che il telefono ha pubblicato entrano nel registro locale, una volta ciascuna. */
function dpAdottaSpunte(done, giorno){
  if (!Array.isArray(done)) return;
  try{
    const d = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
    let nuove = 0;
    done.forEach(function(x){
      if (!x || x.day !== giorno || !x.text) return;
      if (d.some(function(m){ return m.day === x.day && m.text === x.text; })) return;
      d.push({ day: x.day, text: x.text, at: x.at || Date.now(), da: 'telefono' }); nuove++;
    });
    /* e quelle che il telefono ha RITIRATO spariscono anche qui */
    const loro = {}; done.forEach(function(x){ if (x && x.text) loro[x.day + '\u0000' + x.text] = 1; });
    const out = d.filter(function(m){ return !(m && m.day === giorno && m.da === 'telefono' && !loro[m.day + '\u0000' + m.text]); });
    if (nuove || out.length !== d.length){
      localStorage.setItem('fl_notes_done', JSON.stringify(out.slice(-400)));
      try{ document.dispatchEvent(new CustomEvent('fl:spunta')); }catch(_){ }
    }
  }catch(_){ }
}
async function dpLeggiTelefono(){
  if (DP_TEL && Date.now() - DP_TEL_AT < DP_PUB_OGNI) return DP_TEL;
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return DP_TEL;
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === DP_SLOT; })[0];
    if (!riga) return DP_TEL;
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const p = (pieno && pieno.payload) || null;
    const d = p && ((p.web && p.web.dopamina) || p.dopamina);
    if (d && d.giorno){
      DP_TEL = d; DP_TEL_AT = Date.now();
      if (typeof pcQui === 'function' && pcQui() === 'desktop') dpAdottaSpunte(d.done, d.giorno);
    }
  }catch(_){ }
  return DP_TEL;
}

/* ---------------------------------------------------------------------------------------
   IL QUADRANTE
   Una scala sola, da 0 a 100, con tre parole: Bassa, Base, Alta. Il numero ha un decimale:
   il modello si muove di pochi decimi alla volta, e un numero intero li nascondeva.
   --------------------------------------------------------------------------------------- */
const DP_VISTE = [['giorno', 'Giorno'], ['settimana', 'Settimana'], ['mese', 'Mese'], ['panoramica', 'Panoramica']];
const DP_VISTA_KEY = 'fl_dopa_vista';
function dpVista(){ try{ const v = localStorage.getItem(DP_VISTA_KEY) || 'settimana'; return DP_VISTE.some(function(x){ return x[0] === v; }) ? v : 'settimana'; }catch(_){ return 'settimana'; } }
function dpSetVista(v){ try{ localStorage.setItem(DP_VISTA_KEY, v); }catch(_){ } }

function dpBanda(L){
  if (L >= DM_CFG.bandaAlta) return { k: 'alta', t: 'Alta', col: '#1B9E6A' };
  if (L >= DM_CFG.bandaBase) return { k: 'media', t: 'Base', col: '#E0A400' };
  return { k: 'bassa', t: 'Bassa', col: '#E63946' };
}
function dpLoc(){ try{ return (typeof flLocale === 'function') ? flLocale() : 'it-IT'; }catch(_){ return 'it-IT'; } }
/** Un decimale, con la virgola della lingua di chi legge. */
function dpNum(v){
  const x = Math.round((v || 0) * 10) / 10;
  try{ return x.toLocaleString(dpLoc(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }catch(_){ return x.toFixed(1); }
}
/** Un delta con il segno sempre scritto: +0,5 / −1,2. */
function dpDelta(v){
  const x = Math.round((v || 0) * 10) / 10;
  if (x === 0) return dpNum(0);
  return (x > 0 ? '+' : '−') + dpNum(Math.abs(x));
}
function dpPunto(a, r){ const k = a * Math.PI / 180; return [(100 + r * Math.cos(k)).toFixed(2), (100 - r * Math.sin(k)).toFixed(2)]; }
function dpArco(a0, a1, r0, r1){
  const A = dpPunto(a0, r1), B = dpPunto(a1, r1), C = dpPunto(a1, r0), Dd = dpPunto(a0, r0);
  return 'M' + A[0] + ' ' + A[1] + ' A' + r1 + ' ' + r1 + ' 0 0 1 ' + B[0] + ' ' + B[1]
    + ' L' + C[0] + ' ' + C[1] + ' A' + r0 + ' ' + r0 + ' 0 0 0 ' + Dd[0] + ' ' + Dd[1] + ' Z';
}
/* dal rosso (sinistra, riserva bassa) al verde (destra, riserva alta) */
const DP_FASCE = ['#E63946', '#F0603C', '#F5921E', '#F2C21B', '#A8C93A', '#1B9E6A'];
/* IL COLORE DI UN VALORE E' QUELLO DELLA TACCA DEL QUADRANTE su cui sta la lancetta: le barre
   della settimana, il pallino del mese e il numero grande lo prendono da qui. Prima le barre
   usavano le tre fasce delle parole (rosso sotto 44) e il mercoledi' veniva rosso mentre la
   lancetta stava sull'arancione. */
function dpFascia(v){ return DP_FASCE[Math.max(0, Math.min(5, Math.floor(Math.max(0, Math.min(99.99, v)) / 100 * 6)))]; }
function dpGaugeSvg(L){
  let fasce = '';
  for (let i = 0; i < 6; i++){
    fasce += '<path d="' + dpArco(180 - i * 30, 180 - (i + 1) * 30 + 1.2, 60, 88) + '" fill="' + DP_FASCE[i] + '"/>';
  }
  const ang = 180 - Math.max(0, Math.min(100, L)) * 1.8;
  const P = dpPunto(ang, 76);
  return '<svg class="dp-svg" viewBox="0 -14 200 126" aria-hidden="true">'
    + fasce
    + '<line x1="100" y1="12" x2="100" y2="2" stroke="currentColor" stroke-opacity=".55" stroke-width="2"/>'
    + '<text x="100" y="-3" class="dp-ax" text-anchor="middle">BASE</text>'
    + '<text x="12" y="108" class="dp-ax">BASSA</text>'
    + '<text x="188" y="108" class="dp-ax" text-anchor="end">ALTA</text>'
    + '<g class="dp-ago"><line x1="100" y1="100" x2="' + P[0] + '" y2="' + P[1] + '" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/>'
    + '<circle cx="100" cy="100" r="6" fill="currentColor"/></g>'
    + '</svg>';
}
/* il tachimetro piccolo della bolla: le stesse fasce, senza scritte */
function dpGaugeSvgPiccolo(L){
  let fasce = '';
  for (let i = 0; i < 6; i++) fasce += '<path d="' + dpArco(180 - i * 30, 180 - (i + 1) * 30 + 1.2, 60, 92) + '" fill="' + DP_FASCE[i] + '"/>';
  const P = dpPunto(180 - Math.max(0, Math.min(100, L)) * 1.8, 74);
  return '<svg viewBox="4 4 192 106" aria-hidden="true">' + fasce + '<line x1="100" y1="100" x2="' + P[0] + '" y2="' + P[1] + '" stroke="#fff" stroke-width="9" stroke-linecap="round"/><circle cx="100" cy="100" r="10" fill="#fff"/></svg>';
}
function dpBigHtml(L){
  const b = dpBanda(L);
  return '<b class="pfc-big dp-big"><span style="color:' + (dpFascia(L) === '#F2C21B' ? '#3F9FF4' : dpFascia(L)) + '">' + dpNum(L) + '</span> <small>' + b.t + '</small></b>';
}
function dpMin(ms){ return (typeof scFmtShort === 'function') ? scFmtShort(ms) : Math.round(ms / 60000) + ' min'; }
function dpEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x); }
function dpWs(){ return (typeof flWeekStart === 'function') ? flWeekStart() : 1; }
const DP_DOW = ['D', 'L', 'M', 'M', 'G', 'V', 'S'];

/* Il punteggio con cui e' finito un giorno passato. */
function dpRiservaFine(rec){
  if (!rec || !rec.n || typeof rec.fine !== 'number') return null;
  return rec.fine;
}

/* ---------- Giorno ---------- */
/** Una riga: cosa la sta tirando giu' e cosa su, con i punti. */
function dpRigaOggi(d){
  const r = d.ris;
  if (!r) return '';
  const ult = r.voci[r.voci.length - 1];
  const inSess = ult && ult.tipo === 'sessione' && d.to - (ult.fine || ult.t) < 3 * 60000;
  const giu = r.giu[0], su = r.su[0];
  let riga;
  if (inSess) riga = 'Picco in corso su <b>' + dpEsc(ult.l) + '</b>: il conto arriva quando esci.';
  else if (giu) riga = 'La tira giù <b>' + dpEsc(giu.l) + '</b> (' + dpDelta(giu.delta) + ').';
  else riga = 'Oggi niente l’ha tirata giù.';
  if (su && !inSess) riga += ' La tira su <b>' + dpEsc(su.l) + '</b> (' + dpDelta(su.delta) + ').';
  return '<p class="pfc-line">' + riga + '</p>';
}
/** La curva di oggi: sono i punti della simulazione, gli stessi del numero grande. */
function dpOggiCurva(d){ return (d.ris && d.ris.punti) || []; }
/**
 * LA STIMOLAZIONE: i picchi e i crolli, sotto al tachimetro. Una scala sua, con lo zero in
 * mezzo: sopra e' stimolazione rapida (non e' un buon segno), sotto e' il crollo che segue.
 */
function dpStimSvg(punti, W, H, etichette){
  const n = punti.length;
  if (n < 2) return '';
  const m = Math.max(4, Math.max.apply(null, punti.map(function(p){ return Math.abs(p.s || 0); }))) * 1.15;
  const xi = function(i){ return 8 + i * (W - 16) / Math.max(1, n - 1); };
  const yi = function(v){ return 6 + (m - v) / (2 * m) * (H - 22); };
  let linea = '';
  punti.forEach(function(p, i){ linea += (i ? 'L' : 'M') + xi(i).toFixed(1) + ' ' + yi(p.s || 0).toFixed(1); });
  const z = yi(0).toFixed(1);
  const sopra = 'M' + xi(0).toFixed(1) + ' ' + z + ' ' + punti.map(function(p, i){ return 'L' + xi(i).toFixed(1) + ' ' + yi(Math.max(0, p.s || 0)).toFixed(1); }).join(' ') + ' L' + xi(n - 1).toFixed(1) + ' ' + z + ' Z';
  const sotto = 'M' + xi(0).toFixed(1) + ' ' + z + ' ' + punti.map(function(p, i){ return 'L' + xi(i).toFixed(1) + ' ' + yi(Math.min(0, p.s || 0)).toFixed(1); }).join(' ') + ' L' + xi(n - 1).toFixed(1) + ' ' + z + ' Z';
  let lab = '';
  (etichette || []).forEach(function(e){ lab += '<text x="' + xi(e[0]).toFixed(1) + '" y="' + (H - 3) + '" class="pfc-ax pfc-ax-m">' + e[1] + '</text>'; });
  return '<svg class="pfc-svg dp-curva" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">'
    + '<path d="' + sopra + '" fill="#E63946" fill-opacity=".22"/>'
    + '<path d="' + sotto + '" fill="#7A8BA6" fill-opacity=".22"/>'
    + '<line x1="8" x2="' + (W - 8) + '" y1="' + z + '" y2="' + z + '" stroke="currentColor" stroke-opacity=".25" stroke-dasharray="3 4"/>'
    + '<path d="' + linea + '" fill="none" stroke="#E63946" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    + lab + '</svg>';
}
const DP_STIM_LEGENDA = '<p class="dp-legenda">Picchi alti = stimolazione rapida. Il tachimetro sale solo con lo sforzo.</p>';
function dpStimHtml(d, H){
  const oggi = dpOggiCurva(d);
  if (oggi.length < 2) return '<p class="dp-sotto">Stimolazione</p><p class="pfc-line">La curva parte con i primi dieci minuti.</p>';
  return '<p class="dp-sotto">Stimolazione</p>'
    + '<div class="dp-tap" onclick="dpApri()">' + dpStimSvg(oggi, 320, H || 80, dpOreTicks(oggi)) + '</div>'
    + DP_STIM_LEGENDA;
}
function dpGiornoHtml(d){
  const oggi = dpOggiCurva(d);
  const et = dpOreTicks(oggi);
  return dpRigaOggi(d)
    + DP_PORTA_SEGNA
    + '<p class="dp-sotto">Riserva di dopamina, ora per ora</p>'
    + '<div class="dp-tap" onclick="dpApri()">' + (oggi.length > 1 ? dpCurvaSvg(oggi, 320, 90, et) : '<p class="pfc-line">La curva parte con i primi dieci minuti.</p>') + '</div>'
    + dpStimHtml(d, 70);
}
/* La porta per il dettaglio sta sopra al grafico, in ogni vista: una riga di testo azzurro. */
const DP_PORTA_SEGNA = '<!--porta-->';
function dpPortaHtml(){
  return '<p class="dp-sotto dp-portariga"><span class="dp-link" onclick="dpApri()">Vedi cosa l\'ha mossa ' + DP_PG_DX + '</span></p>';
}
/* sei tacche al giorno: ogni quattro ore, come sull'orologio del rapporto */
function dpOreTicks(punti){
  const et = [];
  punti.forEach(function(p, i){ const h = new Date(p.t).getHours(); if (i === 0 || (h % 4 === 0 && new Date(punti[i - 1].t).getHours() !== h)) et.push([i, String(h).padStart(2, '0')]); });
  /* la prima tacca e un'ora tonda troppo vicine si coprono: vince l'ora tonda */
  if (et.length > 1 && et[1][0] - et[0][0] < punti.length / 10) et.shift();
  return et;
}

/* ---------- Settimana: sette barre, dal primo giorno scelto ---------- */
function dpSettimana(d){
  const oggi = dpMezzanotte();
  const dow = new Date(oggi).getDay();
  const indietro = (dow - dpWs() + 7) % 7;
  const barre = [];
  for (let i = 0; i < 7; i++){
    const t = oggi - (indietro - i) * DP_DAY;
    const k = dpChiave(t);
    let v = null;
    if (t === oggi) v = d.riserva;
    else if (t < oggi) v = dpRiservaFine(d.storia[k]);
    barre.push({ v: v, oggi: t === oggi, futuro: t > oggi, g: new Date(t).getDay() });
  }
  return barre;
}
function dpSettimanaHtml(d, compatta, soloBarre){
  const barre = dpSettimana(d);
  const vivi = barre.filter(function(b){ return b.v !== null; });
  const media = vivi.length ? vivi.reduce(function(a, b){ return a + b.v; }, 0) / vivi.length : null;
  return '<div class="dp-sett' + (compatta ? ' compatta' : '') + '">' + barre.map(function(b){
    const h = b.v === null ? 3 : Math.max(4, Math.round(b.v / 100 * (compatta ? 34 : 60)));
    const col = b.v === null ? '' : 'background:' + dpFascia(b.v) + ';';
    return '<div class="dp-bar' + (b.oggi ? ' oggi' : '') + (b.futuro ? ' futuro' : '') + '"><i style="' + col + 'height:' + h + 'px"></i><span>' + DP_DOW[b.g] + '</span></div>';
  }).join('') + '</div>'
  + ((compatta || soloBarre) ? '' : '<p class="pfc-line">' + (media !== null ? 'Riserva di dopamina media della settimana: <b>' + dpNum(media) + '</b>' + (vivi.length < 7 ? ' su ' + vivi.length + (vivi.length === 1 ? ' giorno' : ' giorni') : '') + '.' : 'La settimana si riempie un giorno alla volta.') + '</p>');
}

/* ---------- Mese: la curva dei trenta giorni ---------- */
function dpMese(d){
  const oggi = dpMezzanotte();
  const punti = [];
  for (let i = 29; i >= 0; i--){
    const t = oggi - i * DP_DAY, k = dpChiave(t);
    punti.push({ v: i === 0 ? d.riserva : dpRiservaFine(d.storia[k]), t: t });
  }
  return punti;
}
function dpCurvaSvg(punti, W, H, etichette){
  const n = punti.length;
  const xi = function(i){ return 8 + i * (W - 16) / Math.max(1, n - 1); };
  /* LA SCALA SEGUE I NUMERI. Il modello si muove di pochi punti intorno alla base: su una
     scala 0-100 una giornata intera era una riga piatta. Si guarda la fascia dove stanno i
     valori (almeno venti punti), con la base sempre dentro. */
  const vals = punti.filter(function(p){ return p.v !== null; }).map(function(p){ return p.v; }).concat([DM_CFG.base]);
  let lo = Math.min.apply(null, vals) - 3, hi = Math.max.apply(null, vals) + 3;
  if (hi - lo < 20){ const c = (hi + lo) / 2; lo = c - 10; hi = c + 10; }
  lo = Math.max(0, lo); hi = Math.min(100, hi);
  const yi = function(v){ return 6 + (hi - v) / Math.max(1, hi - lo) * (H - 22); };
  let linea = '', area = '', primo = true, ultimoX = null;
  punti.forEach(function(p, i){
    if (p.v === null) return;
    const x = xi(i), y = yi(p.v);
    linea += (primo ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1);
    if (primo) area = 'M' + x.toFixed(1) + ' ' + (H - 16) + ' L' + x.toFixed(1) + ' ' + y.toFixed(1);
    else area += ' L' + x.toFixed(1) + ' ' + y.toFixed(1);
    ultimoX = x; primo = false;
  });
  if (ultimoX !== null) area += ' L' + ultimoX.toFixed(1) + ' ' + (H - 16) + ' Z';
  /* la linea della base, a 50 */
  const griglia = '<line x1="8" x2="' + (W - 8) + '" y1="' + yi(DM_CFG.base).toFixed(1) + '" y2="' + yi(DM_CFG.base).toFixed(1) + '" stroke="currentColor" stroke-opacity=".18" stroke-dasharray="3 4"/>';
  let lab = '';
  (etichette || []).forEach(function(e){ lab += '<text x="' + xi(e[0]).toFixed(1) + '" y="' + (H - 3) + '" class="pfc-ax pfc-ax-m">' + e[1] + '</text>'; });
  const ult = punti[n - 1];
  const pallino = ult && ult.v !== null ? '<circle cx="' + xi(n - 1).toFixed(1) + '" cy="' + yi(ult.v).toFixed(1) + '" r="3.5" fill="' + dpFascia(ult.v) + '"/>' : '';
  return '<svg class="pfc-svg dp-curva" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">'
    + '<defs><linearGradient id="dpG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#0075E3" stop-opacity=".3"/><stop offset="100%" stop-color="#0075E3" stop-opacity="0"/></linearGradient></defs>'
    + griglia
    + (area ? '<path d="' + area + '" fill="url(#dpG)"/>' : '')
    + (linea ? '<path d="' + linea + '" fill="none" stroke="#0075E3" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>' : '')
    + pallino + lab + '</svg>';
}
function dpMeseHtml(d, compatta){
  const punti = dpMese(d);
  const vivi = punti.filter(function(p){ return p.v !== null; });
  const media = vivi.length ? vivi.reduce(function(a, p){ return a + p.v; }, 0) / vivi.length : null;
  const et = [];
  [0, 7, 14, 21].forEach(function(i){ const dd = new Date(punti[i].t); et.push([i, dd.getDate() + '/' + (dd.getMonth() + 1)]); });
  et.push([29, 'oggi']);
  return dpCurvaSvg(punti, 320, compatta ? 90 : 130, et)
    + (compatta ? '' : '<p class="pfc-line">' + (vivi.length >= 3
        ? 'Riserva di dopamina media degli ultimi ' + vivi.length + ' giorni: <b>' + dpNum(media) + '</b>. ' + dpSaluteTxt(d)
        : 'La curva del mese si disegna un giorno alla volta: servono almeno tre giornate chiuse.') + '</p>');
}
function dpPanoramicaHtml(d){
  const oggi = dpOggiCurva(d);
  const et = dpOreTicks(oggi);
  return '<p class="dp-sotto">Riserva di dopamina, ora per ora</p>'
    + (oggi.length > 1 ? dpCurvaSvg(oggi, 320, 90, et) : '<p class="pfc-line">La curva di oggi parte con i primi dieci minuti.</p>')
    + dpStimHtml(d, 70)
    + '<p class="dp-sotto">La settimana</p>' + dpSettimanaHtml(d, true)
    + '<p class="dp-sotto">Il mese</p>' + dpMeseHtml(d, true);
}
/** Questa settimana contro il mese: sopra, sotto o in linea. */
function dpSaluteTxt(d){
  const media = function(n){
    const v = []; const oggi = dpMezzanotte();
    for (let i = 1; i <= n; i++){ const x = dpRiservaFine(d.storia[dpChiave(oggi - i * DP_DAY)]); if (x !== null) v.push(x); }
    return v.length ? v.reduce(function(a, b){ return a + b; }, 0) / v.length : null;
  };
  const m7 = media(7), m30 = media(30);
  if (m7 === null || m30 === null) return '';
  /* 0.9.353: una frase con il soggetto, e niente testo dopo i due punti sulla stessa riga */
  if (m7 > m30 + 2) return 'Questa settimana la riserva è più alta della media del mese.';
  if (m7 < m30 - 2) return 'Questa settimana la riserva è più bassa della media del mese.';
  return 'Questa settimana la riserva è in linea con la media del mese.';
}

/* La «i» apre una pagina, non un tooltip: una spiegazione si legge a paragrafi. */
function dpInfo(ev){
  if (ev && ev.stopPropagation) ev.stopPropagation();
  goId('s-dopamina-info');
  /* 0.9.353: ogni volta che la apri, le parole ripartono spente e si accendono mentre scorri (come l'Academy) */
  requestAnimationFrame(function(){ dpLeggiScrub(document.querySelector('#s-dopamina-info .dpl'), true); });
}
function dpApri(){
  /* 0.9.308: si apre sempre su Giorno, oggi (come i tre punteggi) */
  DP_PG.per = 'giorno'; DP_PG.off = 0;
  goId('s-dopamina');
  dpPagina();
}

/**
 * La scheda intera. `dove` = 'profilo', 'riposo', 'panoramica'. Il `data-dove` serve anche a
 * ridipingerla: solo questa scheda, mai il contenitore (li' accanto ci sono altri comandi).
 */
function dpCardHtml(d, dove, forza){
  const testa = '<p class="pfc-eyebrow">Riserva di dopamina<button type="button" class="dp-i" onclick="dpInfo(event)" aria-label="Come si calcola">i</button></p>';
  if (!d || d.senzaDati){
    return '<div class="dp" data-dove="' + dove + '">' + testa + dpGaugeSvg(50)
      + '<p class="pfc-line">Serve l\'accesso ai dati di utilizzo: senza, la lancetta non ha niente da leggere.</p></div>';
  }
  const v = forza || dpVista();
  /* 0.9.358, Andrea: "nella scheda Profilo i grafici sono l'uno sotto l'altro ed e' illeggibile, nessuno se li guardera'
     mai cosi'". Sotto al numero c'e' il carosello: una slide per grafico, quelle del periodo scelto dai tre puntini. */
  const corpo = dpGaugeSvg(d.riserva) + dpBigHtml(d.riserva)
    + (v === 'giorno' ? dpRigaOggi(d) : '')
    + dpPortaHtml()
    + dpCaroselloHtml(d, dove, v, false);
  const chip = (dove === 'riposo' && !forza)
    ? '<div class="dp-chip">' + DP_VISTE.map(function(x){ return '<button type="button" class="' + (x[0] === v ? 'on' : '') + '" onclick="dpSetVista(\'' + x[0] + '\');dpRidipingi()">' + x[1] + '</button>'; }).join('') + '</div>'
    : '';
  return '<div class="dp" data-dove="' + dove + '"' + (forza ? ' data-forza="' + forza + '"' : '') + '>' + testa + corpo + chip + '</div>';
}
/**
 * La riserva di UN GIORNO PASSATO, per la pagina del Riposo quando si usano le freccette.
 */
async function dpCardGiorno(off){
  if (!(off > 0)) return '';
  const t = dpMezzanotte() - off * DP_DAY;
  let storia = {};
  try{ storia = await dpStoria(Math.max(7, off + 1)); }catch(_){ storia = dpGiorni(); }
  const rec = storia[dpChiave(t)];
  const L = dpRiservaFine(rec);
  const testa = '<p class="pfc-eyebrow">Riserva di dopamina<button type="button" class="dp-i" onclick="dpInfo(event)" aria-label="Come si calcola">i</button></p>';
  if (L === null){
    return '<div class="dp" data-dove="giorno-passato">' + testa + dpGaugeSvg(50)
      + '<p class="pfc-line">Di questo giorno non c’è una cronologia da leggere.</p></div>';
  }
  let riga = rec.top ? 'La tirava giù <b>' + dpEsc(rec.top.l) + '</b> (' + dpDelta(rec.top.delta) + ').' : 'Niente la tirava giù, quel giorno.';
  if (rec.su) riga += ' La tirava su <b>' + dpEsc(rec.su.l) + '</b> (' + dpDelta(rec.su.delta) + ').';
  return '<div class="dp" data-dove="giorno-passato">' + testa + dpGaugeSvg(L) + dpBigHtml(L)
    + '<p class="pfc-line">' + riga + '</p></div>';
}

/* ---------------------------------------------------------------------------------------
   LE DUE PAGINE
   Il dettaglio: cosa ha mosso il numero, voce per voce, in ordine di tempo. E «Cosa misura».
   --------------------------------------------------------------------------------------- */
/* 0.9.308, Andrea: "Dopamina, oggi" diventa "Dopamina", con le linguette Giorno | Settimana | Mese | Anno e le frecce
   per andare indietro, come la pagina dei tre punteggi (s-score in scores.js: stesse classi sc-top, sc-per, sc-daynav). */
const DP_PG_SX = '<svg class="fl-chev" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>';
const DP_PG_DX = '<svg class="fl-chev" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
/* 0.9.353, Andrea: "in alto il pulsante indietro e' una chevron, e sotto c'e' un'altra chevron per cambiare giorno: due icone uguali
   per due cose diverse". L'indietro diventa la freccia della Timeline; le chevron restano solo per passare da un giorno all'altro. */
const DP_INDIETRO = '<svg viewBox="0 0 17 14" width="18" height="15" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const DP_PUNTINI = '<svg viewBox="0 0 18 4" width="16" height="4" aria-hidden="true"><circle cx="2" cy="2" r="2" fill="currentColor"/><circle cx="9" cy="2" r="2" fill="currentColor"/><circle cx="16" cy="2" r="2" fill="currentColor"/></svg>';
const DP_AVANTI = '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M0 7h15M9 1l6 6-6 6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
registerScreen('s-dopamina',
  '<div class="topbar sc-top"><button class="iconbtn" onclick="if(typeof flIndietro===\'function\')flIndietro();else goId(\'s-home\')" aria-label="Indietro">' + DP_INDIETRO + '</button><b class="sc-titolo">Dopamina</b>'
  + '<button type="button" class="dp-i dp-i-top" onclick="dpInfo(event)" aria-label="Come si calcola">i</button></div>'
  + '<div class="sc-per" id="dpPer"></div>'
  + '<div class="sc-daynav dp-pg-nav"><button class="iconbtn" id="dpPgBack" onclick="dpPgPasso(1)" aria-label="Periodo precedente">' + DP_PG_SX + '</button><b id="dpPgLbl">Oggi</b><button class="iconbtn" id="dpPgFwd" onclick="dpPgPasso(-1)" aria-label="Periodo successivo">' + DP_PG_DX + '</button></div>'
  + '<div id="dpDett" class="dp-page"></div>', { back: 's-home' });

/* ---------------------------------------------------------------------------------------
   I PERIODI DELLA PAGINA DOPAMINA
   Giorno 0 = la pagina di oggi che c'era gia' (subito dall'ultima disegnata, poi il calcolo).
   Un giorno passato, la settimana, il mese e l'anno si leggono SOLO dalla memoria: la storia
   dei giorni chiusi (fl_dopa_giorni_v2, col dettaglio) e l'archivio dei livelli finali
   (fl_dopa_anni). Niente letture del telefono: si disegnano all'istante.
   --------------------------------------------------------------------------------------- */
const DP_PG = { per: 'giorno', off: 0 };
const DP_PG_NOME = { giorno: 'Giorno', settimana: 'Settimana', mese: 'Mese', anno: 'Anno' };
const DP_PG_MESI = ['G', 'F', 'M', 'A', 'M', 'G', 'L', 'A', 'S', 'O', 'N', 'D'];

/** Il livello finale di ogni giorno chiuso che c'e' in memoria: { 'YYYY-MM-DD': numero }. */
function dpPgDati(){
  const a = Object.assign({}, dpAnni());
  const oggi = dpChiave(Date.now());
  const metti = function(st){
    Object.keys(st || {}).forEach(function(k){ const v = dpRiservaFine(st[k]); if (v !== null && k < oggi) a[k] = Math.round(v * 10) / 10; });
  };
  metti(dpGiorni());
  if (DP.dett && DP.dett.storia) metti(DP.dett.storia);
  return a;
}
/** Il record intero di un giorno chiuso (con cosa l'ha tirata giu' e su), se c'e' ancora. */
function dpPgRecord(k){
  const g = dpGiorni();
  if (g[k] && g[k].n) return g[k];
  const s = DP.dett && DP.dett.storia;
  return (s && s[k] && s[k].n) ? s[k] : null;
}
/** Il numero di oggi: quello del calcolo, o l'ultimo mostrato oggi. */
function dpPgOggi(){
  if (DP.dett && typeof DP.dett.riserva === 'number' && DP.dett.giorno === dpChiave(Date.now()) && !DP.dett.senzaDati) return DP.dett.riserva;
  return typeof DP.L === 'number' ? DP.L : null;
}
function dpPgGiornoT(off){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - off); return d.getTime(); }
function dpPgAnnoNow(){ return new Date().getFullYear(); }
/** "Oggi", "Ieri", poi sempre col giorno della settimana: "mercoledì 28 ottobre" (con l'anno se non e' quest'anno). */
function dpPgDataTxt(t, minuscolo){
  const oggi = dpMezzanotte(), g = Math.round((oggi - dpMezzanotte(t)) / DP_DAY);
  if (g === 0) return minuscolo ? 'oggi' : 'Oggi';
  if (g === 1) return minuscolo ? 'ieri' : 'Ieri';
  const d = new Date(t), o = { weekday: 'long', day: 'numeric', month: 'long' };
  if (d.getFullYear() !== dpPgAnnoNow()) o.year = 'numeric';
  try{ return d.toLocaleDateString(dpLoc(), o); }catch(_){ return d.toLocaleDateString('it-IT', o); }
}
function dpPgMeseTxt(d, conAnno){
  let s = '';
  try{ s = d.toLocaleDateString(dpLoc(), conAnno ? { month: 'long', year: 'numeric' } : { month: 'long' }); }catch(_){ s = d.toLocaleDateString('it-IT', { month: 'long' }); }
  return s;
}
function dpPgMaiuscola(s){ return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

/** Il periodo (per, off): primo e ultimo giorno (mezzanotti) e l'etichetta fra le frecce. */
function dpPgPeriodo(per, off){
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  let a, b, lbl;
  if (per === 'settimana'){
    const indietro = (oggi.getDay() - dpWs() + 7) % 7;
    a = new Date(oggi); a.setDate(a.getDate() - indietro - 7 * off);
    b = new Date(a); b.setDate(b.getDate() + 6);
    if (off === 0) lbl = 'Questa settimana';
    else if (off === 1) lbl = 'La settimana scorsa';
    else {
      const anno = b.getFullYear() !== dpPgAnnoNow() || a.getFullYear() !== b.getFullYear();
      const da = a.getMonth() === b.getMonth() ? String(a.getDate()) : a.getDate() + ' ' + dpPgMeseTxt(a, anno && a.getFullYear() !== b.getFullYear());
      lbl = 'Dal ' + da + ' al ' + b.getDate() + ' ' + dpPgMeseTxt(b, anno);
    }
  } else if (per === 'mese'){
    a = new Date(oggi.getFullYear(), oggi.getMonth() - off, 1);
    b = new Date(a.getFullYear(), a.getMonth() + 1, 0);
    lbl = dpPgMaiuscola(dpPgMeseTxt(a, true));
  } else if (per === 'anno'){
    a = new Date(oggi.getFullYear() - off, 0, 1);
    b = new Date(oggi.getFullYear() - off, 11, 31);
    lbl = String(a.getFullYear());
  } else {
    a = new Date(dpPgGiornoT(off)); b = new Date(a);
    lbl = dpPgDataTxt(a.getTime());
  }
  return { a: a.getTime(), b: b.getTime(), lbl: lbl };
}
/** I giorni di un periodo con il loro livello: v null = nessun dato (o giorno che deve ancora venire). */
function dpPgGiorni(per, off, dati, vOggi){
  const p = dpPgPeriodo(per, off), kOggi = dpChiave(Date.now()), out = [];
  const d = new Date(p.a);
  while (d.getTime() <= p.b){
    const k = dpChiave(d.getTime());
    const futuro = k > kOggi;
    const v = futuro ? null : (k === kOggi ? vOggi : (dati[k] !== undefined ? dati[k] : null));
    out.push({ k: k, t: d.getTime(), v: v, futuro: futuro, oggi: k === kOggi });
    d.setDate(d.getDate() + 1);
  }
  return out;
}
function dpPgMedia(lista){
  const vivi = lista.filter(function(x){ return x.v !== null; });
  return vivi.length ? vivi.reduce(function(s, x){ return s + x.v; }, 0) / vivi.length : null;
}
/** Il primo giorno con un dato (la chiave), o null se non ce n'e' nessuno. */
function dpPgPrimo(dati, vOggi){
  const ks = Object.keys(dati).sort();
  if (ks.length) return ks[0];
  return vOggi !== null ? dpChiave(Date.now()) : null;
}
function dpPgChiaveT(k){ const p = k.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]).getTime(); }

/* ---------- le barre: una per giorno (settimana, mese) o per mese (anno), sulla scala intera 0-100 ---------- */
function dpPgBarreSvg(barre, opt){
  opt = opt || {};
  /* a destra resta lo spazio per la scritta BASE: sopra alle barre copriva l'ultima */
  const W = 320, H = opt.valori ? 122 : 104, su = opt.valori ? 16 : 8, giu = opt.doppia ? 28 : 18, dx = 34;
  const n = barre.length, slot = (W - 8 - dx) / n;
  const bw = Math.max(3, Math.min(26, slot * 0.64));
  const y = function(v){ return su + (100 - Math.max(0, Math.min(100, v))) / 100 * (H - su - giu); };
  const y0 = y(0), yb = y(DM_CFG.base);
  let h = '<line x1="8" x2="' + (W - dx + 2) + '" y1="' + yb.toFixed(1) + '" y2="' + yb.toFixed(1) + '" stroke="currentColor" stroke-opacity=".22" stroke-dasharray="3 4"/>'
    + '<text x="' + W + '" y="' + (yb + 3).toFixed(1) + '" text-anchor="end" class="dp-pg-ax">BASE</text>'
    + '<line x1="8" x2="' + (W - dx + 2) + '" y1="' + y0.toFixed(1) + '" y2="' + y0.toFixed(1) + '" stroke="currentColor" stroke-opacity=".14"/>';
  barre.forEach(function(b, i){
    const cx = 8 + slot * (i + 0.5), x = cx - bw / 2;
    let g = '';
    if (b.v !== null){
      const yt = y(b.v);
      /* 0.9.353: opt.col, il colore delle barre nel pannello scuro (solo colori del brand); la pagina dei periodi resta com'era */
      g += '<rect x="' + x.toFixed(1) + '" y="' + yt.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(2, y0 - yt).toFixed(1) + '" rx="' + Math.min(4, bw / 3).toFixed(1) + '" fill="' + (opt.col ? opt.col(b.v) : dpFascia(b.v)) + '"/>';
      if (opt.valori) g += '<text x="' + cx.toFixed(1) + '" y="' + (yt - 4).toFixed(1) + '" text-anchor="middle" class="dp-pg-val">' + dpNum(b.v) + '</text>';
    } else if (!b.futuro){
      /* un giorno senza dati: un trattino a terra, mai una barra inventata */
      g += '<rect x="' + x.toFixed(1) + '" y="' + (y0 - 3).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="3" rx="1.5" fill="currentColor" fill-opacity=".18"/>';
    }
    if (b.lab) g += '<text x="' + cx.toFixed(1) + '" y="' + (H - (opt.doppia ? 15 : 4)) + '" text-anchor="middle" class="dp-pg-ax' + (b.oggi ? ' oggi' : '') + '">' + b.lab + '</text>';
    if (b.lab2) g += '<text x="' + cx.toFixed(1) + '" y="' + (H - 3) + '" text-anchor="middle" class="dp-pg-ax' + (b.oggi ? ' oggi' : '') + '">' + b.lab2 + '</text>';
    /* tutta la colonna si tocca: porta al giorno (o al mese) */
    if (b.vai && !b.futuro) g = '<g class="dp-pg-col" onclick="' + b.vai + '"><rect x="' + (cx - slot / 2).toFixed(1) + '" y="0" width="' + slot.toFixed(1) + '" height="' + H + '" fill="transparent"/>' + g + '</g>';
    h += g;
  });
  return '<svg class="dp-pg-svg" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Riserva di dopamina per ' + (opt.cosa || 'giorno') + '">' + h + '</svg>';
}

/* ---------- le frasi sotto al grafico: sempre vere, e dicono quando mancano i dati ---------- */
function dpPgFrasi(lista, primo, cosaPeriodo, prec){
  /* si contano i giorni da quando il carburante e' registrato: prima non mancano dati, non esistevano */
  const trascorsi = lista.filter(function(x){ return !x.futuro && (!primo || x.k >= primo); });
  const con = trascorsi.filter(function(x){ return x.v !== null; });
  const r = [];
  if (con.length === trascorsi.length) r.push(con.length === 1 ? 'C’è il dato di un giorno solo.' : 'Ci sono i dati di tutti i ' + con.length + ' giorni.');
  else r.push('Ci sono i dati di ' + con.length + (con.length === 1 ? ' giorno' : ' giorni') + ' su ' + trascorsi.length + '.');
  if (primo && lista.length && primo > lista[0].k && primo <= lista[lista.length - 1].k) r.push('Il carburante è registrato da ' + dpPgDataTxt(dpPgChiaveT(primo), true) + '.');
  if (prec !== null && prec !== undefined){
    const m = dpPgMedia(lista), dd = Math.round((m - prec) * 10) / 10;
    if (Math.abs(dd) < 0.1) r.push('La media è uguale a quella ' + cosaPeriodo + '.');
    else r.push('La media è più ' + (dd > 0 ? 'alta' : 'bassa') + ' di <b>' + dpNum(Math.abs(dd)) + '</b> ' + (Math.abs(dd) === 1 ? 'punto' : 'punti') + ' rispetto a quella ' + cosaPeriodo + '.');
  }
  return r;
}
function dpPgVuotoHtml(testo, primo){
  const quando = primo ? 'Il carburante è registrato da ' + dpPgDataTxt(dpPgChiaveT(primo), true) + '.'
    : 'Il carburante si registra un giorno alla volta, da quando DreamMap legge l’uso del telefono.';
  return '<div class="dp-card dp dp-pg-vuoto"><p class="pfc-eyebrow">Riserva di dopamina</p><b class="dp-pg-vuoto-t">' + testo + '</b><p class="pfc-line">' + quando + '</p></div>';
}

/* ---------- Giorno passato ---------- */
function dpPgGiornoHtml(off, dati, primo){
  const t = dpPgGiornoT(off), k = dpChiave(t);
  const v = dati[k] !== undefined ? dati[k] : null;
  if (v === null) return dpPgVuotoHtml('Di questo giorno non ci sono dati del carburante.', primo);
  const rec = dpPgRecord(k);
  let riga;
  if (rec){
    riga = rec.top ? 'La tirava giù <b>' + dpEsc(rec.top.l) + '</b> (' + dpDelta(rec.top.delta) + ').' : 'Quel giorno niente l’ha tirata giù.';
    if (rec.su) riga += ' La tirava su <b>' + dpEsc(rec.su.l) + '</b> (' + dpDelta(rec.su.delta) + ').';
  } else riga = 'Di questo giorno resta il livello con cui è finito: il dettaglio ora per ora non c’è più.';
  const kPrima = dpChiave(dpPgGiornoT(off + 1));
  let confronto = '';
  if (dati[kPrima] !== undefined){
    const dd = Math.round((v - dati[kPrima]) * 10) / 10;
    confronto = Math.abs(dd) < 0.1 ? 'È finita allo stesso livello del giorno prima.'
      : 'È finita ' + dpNum(Math.abs(dd)) + (Math.abs(dd) === 1 ? ' punto più ' : ' punti più ') + (dd > 0 ? 'in alto' : 'in basso') + ' del giorno prima.';
  }
  return '<div class="dp-card dp"><p class="pfc-eyebrow">Riserva di dopamina a fine giornata</p>' + dpGaugeSvg(v) + dpBigHtml(v)
    + '<p class="pfc-line">' + riga + '</p>' + (confronto ? '<p class="pfc-line dp-pg-conf">' + confronto + '</p>' : '') + '</div>';
}

/* ---------- Settimana, Mese ---------- */
function dpPgGiorniHtml(per, off, dati, vOggi, primo){
  const lista = dpPgGiorni(per, off, dati, vOggi);
  const media = dpPgMedia(lista);
  const nomeVuoto = per === 'settimana' ? 'Di questa settimana non ci sono dati del carburante.' : 'Di questo mese non ci sono dati del carburante.';
  if (media === null) return dpPgVuotoHtml(nomeVuoto, primo);
  const offOggi = function(t){ return Math.round((dpMezzanotte() - t) / DP_DAY); };
  const barre = lista.map(function(x){
    const g = new Date(x.t);
    const b = { v: x.v, futuro: x.futuro, oggi: x.oggi, vai: 'dpPgVai(\'giorno\',' + offOggi(x.t) + ')' };
    if (per === 'settimana'){ b.lab = DP_DOW[g.getDay()]; b.lab2 = String(g.getDate()); }
    else if ([1, 8, 15, 22, 29].indexOf(g.getDate()) >= 0) b.lab = String(g.getDate());
    return b;
  });
  const prec = dpPgMedia(dpPgGiorni(per, off + 1, dati, vOggi));
  const frasi = dpPgFrasi(lista, primo, per === 'settimana' ? 'della settimana precedente' : 'del mese precedente', prec);
  const vivi = lista.filter(function(x){ return x.v !== null; });
  if (vivi.length >= 2){
    const top = vivi.slice().sort(function(a, b){ return b.v - a.v; })[0];
    frasi.push('Il giorno con la riserva più alta è ' + (top.oggi ? 'oggi' : 'stato ' + dpPgDataTxt(top.t, true)) + '.');
  }
  return '<div class="dp-card dp"><p class="pfc-eyebrow">Riserva di dopamina media</p>' + dpGaugeSvg(media) + dpBigHtml(media)
    + '<p class="dp-sotto">Giorno per giorno</p>'
    + dpPgBarreSvg(barre, { valori: per === 'settimana', doppia: per === 'settimana', cosa: 'giorno' })
    + frasi.map(function(f){ return '<p class="pfc-line dp-pg-f">' + f + '</p>'; }).join('')
    + '</div>';
}

/* ---------- Anno: dodici barre, la media di ogni mese ---------- */
function dpPgAnnoHtml(off, dati, vOggi, primo){
  const lista = dpPgGiorni('anno', off, dati, vOggi);
  const media = dpPgMedia(lista);
  if (media === null) return dpPgVuotoHtml('Di quest’anno non ci sono dati del carburante.', primo);
  const ora = new Date(), anno = ora.getFullYear() - off;
  const mesi = [];
  for (let m = 0; m < 12; m++){
    const dentro = lista.filter(function(x){ return new Date(x.t).getMonth() === m; });
    const futuro = dentro.every(function(x){ return x.futuro; });
    mesi.push({ m: m, v: dpPgMedia(dentro), futuro: futuro, oggi: anno === ora.getFullYear() && m === ora.getMonth(),
                lab: DP_PG_MESI[m], vai: 'dpPgVai(\'mese\',' + ((ora.getFullYear() - anno) * 12 + ora.getMonth() - m) + ')' });
  }
  const prec = dpPgMedia(dpPgGiorni('anno', off + 1, dati, vOggi));
  const frasi = dpPgFrasi(lista, primo, 'dell’anno precedente', prec);
  const vivi = mesi.filter(function(x){ return x.v !== null; });
  if (vivi.length >= 2){
    const top = vivi.slice().sort(function(a, b){ return b.v - a.v; })[0];
    frasi.push('Il mese con la riserva più alta è ' + (top.oggi ? 'questo' : 'stato ' + dpPgMeseTxt(new Date(anno, top.m, 1), false)) + '.');
  }
  return '<div class="dp-card dp"><p class="pfc-eyebrow">Riserva di dopamina media</p>' + dpGaugeSvg(media) + dpBigHtml(media)
    + '<p class="dp-sotto">Mese per mese</p>'
    + dpPgBarreSvg(mesi, { cosa: 'mese' })
    + frasi.map(function(f){ return '<p class="pfc-line dp-pg-f">' + f + '</p>'; }).join('')
    + '</div>';
}

function dpPgVistaOggi(){ return DP_PG.per === 'giorno' && DP_PG.off === 0; }
/** Si puo' andare ancora indietro finche' il periodo prima contiene il primo giorno con dati (o viene dopo). */
function dpPgPuoIndietro(primo){
  if (!primo) return false;
  if (DP_PG.per === 'anno' && DP_PG.off >= 10) return false;
  const p = dpPgPeriodo(DP_PG.per, DP_PG.off + 1);
  return dpChiave(p.b) >= primo;
}
/** La pagina intera: linguette, frecce, etichetta e corpo. */
function dpPagina(){
  const host = document.getElementById('dpDett');
  if (!host) return;
  const pb = document.getElementById('dpPer');
  if (pb) pb.innerHTML = Object.keys(DP_PG_NOME).map(function(k){ return '<button type="button" class="' + (k === DP_PG.per ? 'on' : '') + '" onclick="dpPgVai(\'' + k + '\',0)">' + DP_PG_NOME[k] + '</button>'; }).join('');
  const dati = dpPgDati(), vOggi = dpPgOggi(), primo = dpPgPrimo(dati, vOggi);
  const p = dpPgPeriodo(DP_PG.per, DP_PG.off);
  const lbl = document.getElementById('dpPgLbl'); if (lbl) lbl.textContent = p.lbl;
  const fwd = document.getElementById('dpPgFwd'); if (fwd) fwd.disabled = DP_PG.off === 0;
  const bk = document.getElementById('dpPgBack'); if (bk) bk.disabled = !dpPgPuoIndietro(primo);
  if (dpPgVistaOggi()){
    if (host.dataset.vista !== 'oggi'){ host.innerHTML = ''; host.dataset.vista = 'oggi'; }
    dpDettaglioPaint();
    return;
  }
  host.dataset.vista = DP_PG.per + DP_PG.off;
  if (DP_PG.per === 'giorno') host.innerHTML = dpPgGiornoHtml(DP_PG.off, dati, primo);
  else if (DP_PG.per === 'anno') host.innerHTML = dpPgAnnoHtml(DP_PG.off, dati, vOggi, primo);
  else host.innerHTML = dpPgGiorniHtml(DP_PG.per, DP_PG.off, dati, vOggi, primo);
  /* il numero di oggi non c'e' ancora (prima apertura della giornata): arriva col calcolo, e si ridisegna */
  if (vOggi === null && DP_PG.per !== 'giorno') dpCalcola().then(dpPgRidipingi).catch(function(){ });
}
function dpPgVai(per, off){
  if (!DP_PG_NOME[per]) return;
  DP_PG.per = per; DP_PG.off = Math.max(0, off | 0);
  dpPagina();
  try{ const sc = document.getElementById('s-dopamina'); if (sc && sc.scrollTo) sc.scrollTo(0, 0); }catch(_){ }
}
function dpPgPasso(dir){
  if (dir > 0){ const bk = document.getElementById('dpPgBack'); if (bk && bk.disabled) return; }
  DP_PG.off = Math.max(0, DP_PG.off + dir);
  dpPagina();
}
/** Ridisegna la vista di un periodo se e' a schermo (la vista di oggi la ridisegna dpDettaglioPaint). */
function dpPgRidipingi(){
  try{
    const sc = document.getElementById('s-dopamina');
    if (!sc || !sc.classList.contains('active') || dpPgVistaOggi()) return;
    dpPagina();
  }catch(_){ }
}

function dpOra(t){ const x = new Date(t); return String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); }
const DP_DEV = { telefono: '📱 telefono', computer: '💻 computer' };
function dpDevTxt(dev){
  if (!dev) return '';
  return dev.split(' + ').map(function(x){ return DP_DEV[x] || x; }).join(' + ');
}
/** Una riga di «Cosa l'ha mossa»: ora · causa · durata · dispositivo · punti. */
function dpVoceHtml(v){
  const ora = (v.fine && v.fine - v.t >= 60000) ? dpOra(v.t) + '–' + dpOra(v.fine) : dpOra(v.t);
  const nota = [ora];
  if (v.nota) nota.push(dpEsc(v.nota));
  if (v.dev) nota.push(dpDevTxt(v.dev));
  return '<div class="dp-evr' + (v.delta > 0 ? ' buono' : '') + '">'
    + '<b class="dp-evn">' + dpDelta(v.delta) + '</b>'
    + '<div><b>' + dpEsc(v.l) + '</b><small>' + nota.join(' · ') + '</small></div>'
    + '</div>';
}
function dpClassificaHtml(lista, titolo, vuoto){
  return '<div class="dp-cl"><b class="dp-cl-t">' + titolo + '</b>'
    + (lista.length ? lista.map(function(x){ return '<p><span>' + dpEsc(x.l) + '</span><b class="' + (x.delta > 0 ? 'su' : 'giu') + '">' + dpDelta(x.delta) + '</b></p>'; }).join('')
      : '<p class="dp-cl-0">' + vuoto + '</p>')
    + '</div>';
}
/* 0.9.351, Andrea: "la pagina della dopamina confonde: e' troppo lunga, troppi pannelli uno sopra l'altro, e si toccano"
   ("Cosa l'ha alzata" incollato all'ultima app). Adesso in cima resta solo il tachimetro con il numero; sotto, UN pannello
   a schede nello stile delle statistiche della partita (partita-stats.js: .pst, .pst-kick, .pst-tabs, .pst-corpo).
   Le schede si cambiano senza ridisegnare (si nascondono e si mostrano), cosi' vale anche per l'ultima pagina in memoria;
   l'ultima scelta resta in fl_dopa_scheda. Ogni scheda tiene al massimo sei righe: il resto si apre a richiesta. */
const DP_PAN_KEY = 'fl_dopa_scheda';
/* 0.9.358, Andrea: "la scheda Conto non voglio che si chiami Conto, ma Riepilogo, e sara' la prima, in quanto i grafici ti ho
   detto di rimetterli nel pannello bianco dove c'e' il tachimetro". La scheda Grafici non c'e' piu': i grafici stanno nel
   pannello bianco, sotto a "Scopri di piu'". Chi aveva salvato Grafici o Conto riparte una volta dal Riepilogo. */
const DP_PAN = [['riepilogo', 'Riepilogo'], ['cause', 'Cause'], ['abitudini', 'Abitudini']];
(function dpPanPrimaVolta(){
  try{ if (localStorage.getItem('fl_dopa_scheda_v') !== '358'){ localStorage.setItem(DP_PAN_KEY, 'riepilogo'); localStorage.setItem('fl_dopa_scheda_v', '358'); } }catch(_){ }
})();
let DP_PAN_MOM = false;                       // i momenti di oggi aperti, anche quando la pagina si ridisegna
function dpPanScheda(){
  try{ const v = localStorage.getItem(DP_PAN_KEY); return DP_PAN.some(function(x){ return x[0] === v; }) ? v : 'riepilogo'; }catch(_){ return 'riepilogo'; }
}
function dpPanMostra(k){
  const box = document.getElementById('dpPan');
  if (!box) return;
  box.querySelectorAll('.pst-tab').forEach(function(b){ const on = b.getAttribute('data-k') === k; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
  box.querySelectorAll('.dp-pan-s').forEach(function(s){ s.hidden = s.getAttribute('data-k') !== k; });
  const row = box.querySelector('.pst-tabs'), on = box.querySelector('.pst-tab.on');
  if (row && on && row.scrollWidth > row.clientWidth) row.scrollLeft = Math.max(0, on.offsetLeft - (row.clientWidth - on.offsetWidth) / 2);
}

/* ---------------------------------------------------------------------------------------
   I GRAFICI A CAROSELLO: una slide per grafico
   0.9.358, Andrea: "i grafici comparivano nel pannello bianco sotto al tachimetro, sotto al pulsante Scopri di piu':
   ripristinali li'. Nel Profilo sono uno sotto l'altro ed e' illeggibile, nessuno se li guardera' mai: scorrevoli, grafico
   per grafico. La settimana in una slide, il mese in una slide, la stimolazione in una slide, la riserva ora per ora in
   un'altra, in base al time frame che l'utente ha scelto (panoramica, mese, settimana o giorno)".
   Lo stesso carosello vive nel pannello bianco della pagina Dopamina e in ogni scheda della riserva (Profilo, Riposo,
   Report). Il periodo e' uno solo (dpVista): lo si sceglie dai tre puntini, nella pagina come nel Profilo.
   Ogni carosello ha il suo nome (data-car): la slide guardata resta anche quando la scheda si ridisegna.
   --------------------------------------------------------------------------------------- */
const DP_GRAF_SLIDE = { giorno: ['riserva', 'stim'], settimana: ['sett'], mese: ['mese'], panoramica: ['riserva', 'stim', 'sett', 'mese'] };
const DP_CAR_IX = {};                         // per ogni carosello, la slide guardata
const DP_CAR_V = {};                          // per ogni carosello, il periodo con cui e' stato disegnato
let DP_CAR_TOCCO = 0;                         // l'ultimo tocco su un carosello: il ridisegno aspetta che il dito si alzi
function dpCarToccato(){ return Date.now() - DP_CAR_TOCCO < 1200; }
/** Una slide: il titolo, il grafico, una riga sotto. */
function dpGrSlide(tipo, d, car, i){
  /* ogni grafico ha il suo gradiente: con lo stesso id di un grafico nascosto il telefono non lo disegna */
  const gid = function(svg){ return svg.split('dpG').join('dpG' + car + i); };
  const sl = function(tit, corpo, nota){
    return '<section class="dp-car-s dp-car-' + tipo + '"><p class="dp-car-t">' + tit + '</p>' + corpo + (nota ? '<p class="dp-car-n">' + nota + '</p>' : '') + '</section>';
  };
  const vuoto = function(t){ return '<p class="dp-car-0">' + t + '</p>'; };
  const oggi = dpOggiCurva(d), et = dpOreTicks(oggi);
  if (tipo === 'riserva'){
    return oggi.length > 1
      ? sl('Riserva di dopamina, ora per ora', gid(dpCurvaSvg(oggi, 320, 110, et)), 'La riga tratteggiata è la base, cioè ' + DM_CFG.base + '.')
      : sl('Riserva di dopamina, ora per ora', vuoto('La curva parte dopo i primi dieci minuti della giornata.'), '');
  }
  if (tipo === 'stim'){
    return oggi.length > 1
      ? sl('Stimolazione, ora per ora', dpStimSvg(oggi, 320, 90, et), 'I picchi alti sono stimolazione rapida.<br>Il tachimetro sale solo con lo sforzo.')
      : sl('Stimolazione, ora per ora', vuoto('La curva parte dopo i primi dieci minuti della giornata.'), '');
  }
  if (tipo === 'sett'){
    const vivi = dpSettimana(d).filter(function(b){ return b.v !== null; });
    if (!vivi.length) return sl('La settimana', vuoto('La settimana si riempie un giorno alla volta.'), '');
    const media = vivi.reduce(function(a, b){ return a + b.v; }, 0) / vivi.length;
    return sl('La settimana', dpSettimanaHtml(d, false, true), 'La media di questa settimana è <b>' + dpNum(media) + '</b>.');
  }
  /* il mese: gli ultimi trenta giorni, come prima nel Profilo */
  const punti = dpMese(d), vivi = punti.filter(function(p){ return p.v !== null; });
  if (vivi.length < 3) return sl('Il mese', vuoto('La curva del mese compare quando ci sono almeno tre giorni.'), '');
  const media = vivi.reduce(function(a, p){ return a + p.v; }, 0) / vivi.length;
  const etm = [];
  [0, 7, 14, 21].forEach(function(j){ const g = new Date(punti[j].t); etm.push([j, g.getDate() + '/' + (g.getMonth() + 1)]); });
  etm.push([29, 'oggi']);
  const salute = dpSaluteTxt(d);
  return sl('Il mese', gid(dpCurvaSvg(punti, 320, 110, etm)),
    'La media degli ultimi 30 giorni è <b>' + dpNum(media) + '</b>.' + (salute ? '<br>' + salute : ''));
}
/**
 * Il carosello dei grafici. `car` e' il suo nome (pagina, profilo, riposo, panoramica), `vista` il periodo;
 * con `menu` porta i tre puntini per cambiare periodo (nella pagina: nel Profilo li ha gia' la scheda).
 */
function dpCaroselloHtml(d, car, vista, menu){
  const v = DP_GRAF_SLIDE[vista] ? vista : 'giorno', tipi = DP_GRAF_SLIDE[v];
  if (DP_CAR_V[car] !== v){ DP_CAR_V[car] = v; DP_CAR_IX[car] = 0; }
  const ix = Math.min(DP_CAR_IX[car] || 0, tipi.length - 1);
  const nome = (DP_VISTE.filter(function(x){ return x[0] === v; })[0] || ['', ''])[1];
  return '<div class="dp-gr" data-car="' + car + '" data-vista="' + v + '">'
    + (menu ? '<button type="button" class="arb-dots dp-gr-menu" onclick="dpGrMenu(event)" aria-label="Scegli il periodo dei grafici (' + nome + ')">⋯</button>' : '')
    + '<div class="dp-car" data-car="' + car + '" onscroll="dpCarScorri(this)">' + tipi.map(function(t, i){ return dpGrSlide(t, d, car, i); }).join('') + '</div>'
    + (tipi.length > 1 ? '<div class="dp-car-d">' + tipi.map(function(t, i){
        return '<button type="button" class="' + (i === ix ? 'on' : '') + '" onclick="dpCarVai(this,' + i + ')" aria-label="Grafico ' + (i + 1) + ' di ' + tipi.length + '"><i></i></button>';
      }).join('') + '</div>' : '')
    + '</div>';
}
function dpCarIdx(c){ return Math.max(0, Math.min(c.children.length - 1, Math.round(c.scrollLeft / Math.max(1, c.clientWidth)))); }
/* il carosello e' alto quanto la slide che guardi: le slide hanno ognuna la sua altezza */
function dpCarAltezza(c, i){
  const s = c && c.children[i];
  if (!s) return;
  const h = s.offsetHeight;
  if (h && c.style.height !== h + 'px') c.style.height = h + 'px';
}
/* i pallini si aggiornano a ogni movimento del dito: passata meta' slide, si accende il pallino dopo */
function dpCarScorri(c){
  if (!c || !c.clientWidth) return;
  const i = dpCarIdx(c);
  DP_CAR_IX[c.getAttribute('data-car')] = i;
  const dd = c.parentNode && c.parentNode.querySelector('.dp-car-d');
  if (dd) Array.prototype.forEach.call(dd.children, function(b, k){ b.classList.toggle('on', k === i); });
  dpCarAltezza(c, i);
}
function dpCarVai(btn, i){
  const g = btn && btn.closest ? btn.closest('.dp-gr') : null, c = g && g.querySelector('.dp-car');
  if (!c) return;
  DP_CAR_TOCCO = Date.now();
  try{ c.scrollTo({ left: i * c.clientWidth, behavior: 'smooth' }); }catch(_){ c.scrollLeft = i * c.clientWidth; }
}
/** Dopo ogni disegno: ogni carosello torna sulla slide che guardavi e prende la sua altezza. */
function dpCarPrepara(){
  document.querySelectorAll('.dp-car').forEach(function(c){
    if (!c.clientWidth) return;
    if (!c.__dp){
      c.__dp = 1;
      const tocco = function(){ DP_CAR_TOCCO = Date.now(); };
      c.addEventListener('touchstart', tocco, { passive: true });
      c.addEventListener('touchmove', tocco, { passive: true });
      c.addEventListener('pointerdown', tocco, { passive: true });
    }
    const i = Math.min(DP_CAR_IX[c.getAttribute('data-car')] || 0, c.children.length - 1);
    if (Math.abs(c.scrollLeft - i * c.clientWidth) > 2) c.scrollLeft = i * c.clientWidth;
    dpCarScorri(c);
  });
}
window.addEventListener('resize', function(){ try{ dpCarPrepara(); }catch(_){ } });
/* una scheda nascosta non ha misure: il carosello si sistema quando si vede */
document.addEventListener('fl:tab', function(){ setTimeout(function(){ try{ dpCarPrepara(); }catch(_){ } }, 60); });
document.addEventListener('fl:screen', function(){ setTimeout(function(){ try{ dpCarPrepara(); }catch(_){ } }, 60); });
/* i tre puntini del pannello bianco: lo stesso menu della scheda della riserva nel Profilo (profcaro.js, pfcMenuOpen) */
function dpGrMenuChiudi(){
  ['dpGrMenu', 'dpGrVelo'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
}
function dpGrMenu(ev){
  if (ev && ev.stopPropagation) ev.stopPropagation();
  if (document.getElementById('dpGrMenu')){ dpGrMenuChiudi(); return; }
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const velo = document.createElement('div');
  velo.id = 'dpGrVelo'; velo.className = 'arb-veil';
  velo.addEventListener('click', function(e){ e.stopPropagation(); dpGrMenuChiudi(); });
  casa.appendChild(velo);
  const m = document.createElement('div');
  m.id = 'dpGrMenu'; m.className = 'arb-menu';
  const v = dpVista();
  m.innerHTML = DP_VISTE.map(function(t){ return '<button type="button" class="' + (t[0] === v ? 'on' : '') + '" onclick="dpGrScegli(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('');
  casa.appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.dp-gr-menu'));
}
function dpGrScegli(v){
  dpGrMenuChiudi();
  if (!DP_GRAF_SLIDE[v]) return;
  dpSetVista(v);
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const g = document.querySelector('#dpDett .dp-gr[data-car="pagina"]');
  if (g && DP.dett && DP.dett.ris && !DP.dett.senzaDati){
    const tmp = document.createElement('div');
    tmp.innerHTML = dpCaroselloHtml(DP.dett, 'pagina', v, true);
    if (tmp.firstElementChild) g.parentNode.replaceChild(tmp.firstElementChild, g);
    dpCarPrepara();
    dpPaginaRicorda();
  } else dpDettaglioPaint();
  /* il periodo e' lo stesso della scheda nel Profilo: cambia anche lei */
  try{ if (typeof PFC_HTML !== 'undefined' && PFC_HTML && PFC_HTML[0] !== null && DP.dett) PFC_HTML[0] = dpCardHtml(DP.dett, 'profilo'); }catch(_){ }
  dpRidipingi();
}
function dpPanVai(k){
  if (!DP_PAN.some(function(x){ return x[0] === k; })) return;
  try{ localStorage.setItem(DP_PAN_KEY, k); }catch(_){ }
  dpPanMostra(k);
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
}
function dpPanMomenti(btn){
  const box = document.getElementById('dpPan'), l = box && box.querySelector('.dp-pmom-l');
  if (!l) return;
  DP_PAN_MOM = l.hidden;
  l.hidden = !DP_PAN_MOM;
  if (btn){ btn.setAttribute('aria-expanded', String(DP_PAN_MOM)); const s = btn.querySelector('span'); if (s) s.textContent = DP_PAN_MOM ? btn.getAttribute('data-chiudi') : btn.getAttribute('data-apri'); }
}
function dpNomi(t){ return (typeof dmNomiNelTesto === 'function') ? dmNomiNelTesto(t) : t; }
/** Una riga del pannello: a sinistra cosa (testo gia' pronto), a destra il valore. */
function dpPanRiga(l, s, v, cls, o){
  o = o || {};
  return '<div class="dp-pr' + (o.tocca ? ' tocca' : '') + '"' + (o.tocca ? ' role="button" tabindex="0" onclick="' + o.tocca + '"' : '') + '>'
    + '<div class="dp-pr-l"><b>' + l + '</b>' + (s ? '<small>' + s + '</small>' : '') + '</div>'
    + (v !== '' && v !== undefined ? '<em class="dp-pv ' + (cls || 'n') + '">' + v + '</em>' : '')
    + (o.dopo || '') + '</div>';
}
/** Un delta come pillola: blu se alza, rossa se abbassa. */
function dpPanCls(delta){ const x = Math.round((delta || 0) * 10) / 10; return x > 0 ? 'su' : (x < 0 ? 'giu' : 'n'); }
function dpPanVoce(v){
  const ora = (v.fine && v.fine - v.t >= 60000) ? 'Dalle ' + dpOra(v.t) + ' alle ' + dpOra(v.fine) : 'Alle ' + dpOra(v.t);
  const nota = [ora];
  if (v.nota) nota.push(dpEsc(dpNomi(v.nota)));
  if (v.dev) nota.push(dpDevTxt(v.dev));
  return dpPanRiga(dpEsc(dpNomi(v.l || '')), nota.join(' · '), dpDelta(v.delta), dpPanCls(v.delta));
}
/** Le finestre migliori in una frase per la riga di Abitudini. */
function dpFinestreTesto(d){
  const f = dpFinestre(d.storia || {});
  const hh = function(h){ return String(h % 24).padStart(2, '0'); };
  if (!f.pronto) return 'Le scopri dopo ' + DM_CFG.finestreGiorniMin + ' giorni di dati. Oggi sei al giorno ' + Math.max(1, f.giorni) + '.';
  if (!f.fasce.length) return 'Servono ancora un po’ di sessioni per trovarle.';
  return 'Rendi di più ' + f.fasce.map(function(x){ return 'fra le ' + hh(x.da) + ' e le ' + hh(x.a); }).join(' e ') + '. Metti lì le cose più difficili.';
}
/** Il pannello a schede sotto al tachimetro. */
function dpPannelloHtml(d){
  const r = d.ris, k = dpPanScheda();
  const sez = function(id, html){ return '<div class="dp-pan-s" data-k="' + id + '"' + (id === k ? '' : ' hidden') + '>' + html + '</div>'; };
  const vuoto = function(t){ return '<p class="dp-p0">' + t + '</p>'; };

  /* IL RIEPILOGO (fino alla 0.9.357 si chiamava Conto). 0.9.353, Andrea: "la fila con notifiche, riprese in mano e cambi d'app sono troppi numeri attaccati, a nessuno frega".
     Restano la partenza e l'adesso, centrati, con la differenza centrata SOPRA (mai di fianco), e le app che sono costate di piu'.
     L'adesso e' il numero del tachimetro in cima, anche con il carburante arrivato a calcolo gia' partito. */
  const ora = typeof d.riserva === 'number' ? d.riserva : r.score;
  const dd = ora - r.start;
  const app = (typeof ccApp === 'function') ? ccApp(d).slice(0, 4) : [];
  const riepilogo = '<div class="dp-pc"><em class="dp-pv ' + dpPanCls(dd) + '">' + dpDelta(dd) + '</em>'
    + '<div class="dp-pc-r"><div><small>Partenza</small><b>' + dpNum(r.start) + '</b></div>' + DP_AVANTI
    + '<div><small>Adesso</small><b>' + dpNum(ora) + '</b></div></div></div>'
    + '<div class="dp-pg"><p class="dp-pk">Le app che ti sono costate di più</p>'
    + (app.length ? '<div class="dp-prs">' + app.map(function(x){
        const quanto = (typeof ccMin === 'function' ? ccMin(x.min) : dpMin(x.ms)) + ' in ' + x.ap + (x.ap === 1 ? ' volta' : ' volte');
        return dpPanRiga(dpEsc(dpNomi(x.nome)), dpEsc(quanto), '−' + dpNum(x.costo), 'giu');
      }).join('') + '</div>' : vuoto('Oggi nessuna app ti è costata carburante.'))
    + '</div>';

  /* LE CAUSE: cosa l'ha alzata e cosa l'ha abbassata, tre per parte; i momenti uno per uno solo a richiesta */
  const gruppo = function(lista, tit, niente){
    return '<div class="dp-pg"><p class="dp-pk">' + tit + '</p>'
      + (lista.length ? '<div class="dp-prs">' + lista.slice(0, 3).map(function(x){ return dpPanRiga(dpEsc(dpNomi(x.l)), '', dpDelta(x.delta), dpPanCls(x.delta)); }).join('') + '</div>' : vuoto(niente))
      + '</div>';
  };
  const voci = r.voci.filter(function(v){ return Math.abs(v.delta) >= 0.05; }).sort(function(a, b){ return b.t - a.t; });
  const apri = voci.length === 1 ? 'Vedi il momento di oggi' : 'Vedi i momenti di oggi, uno per uno';
  const momenti = voci.length
    ? '<button type="button" class="pst-link dp-pmom" onclick="dpPanMomenti(this)" aria-expanded="' + DP_PAN_MOM + '" data-apri="' + apri + '" data-chiudi="Nascondi i momenti"><span>' + (DP_PAN_MOM ? 'Nascondi i momenti' : apri) + '</span></button>'
      + '<div class="dp-prs dp-pmom-l"' + (DP_PAN_MOM ? '' : ' hidden') + '>' + voci.map(dpPanVoce).join('') + '</div>'
    : '';
  const cause = gruppo(r.su || [], 'Cosa l’ha alzata', 'Oggi ancora niente l’ha alzata.')
    + gruppo(r.giu || [], 'Cosa l’ha abbassata', 'Oggi ancora niente l’ha abbassata.')
    + momenti;

  /* LE ABITUDINI: passi, doccia fredda, finestre migliori */
  const ab = [];
  const ps = d.passi;
  const pc = (typeof pcQui === 'function' && pcQui() === 'desktop');
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getSteps){
    ab.push(dpPanRiga('🚶 Passi di oggi', 'Tocca per vedere come li conta l’app.', ((ps && ps.totale) || 0).toLocaleString(dpLoc()), 'n', { tocca: 'dpPassiApri()', dopo: DP_PG_DX }));
  }
  if (ps && ((ps.health && !(ps.healthSteps && ps.healthWorkouts)) || (!ps.health && ps.available && !ps.granted))){
    ab.push(dpPanRiga('🔓 Passi e allenamenti', 'Camminare e allenarti alzano la riserva.', '', '', { dopo: '<button type="button" class="dp-pbtn" onclick="dpAttivaPassi()">Attiva</button>' }));
  }
  if (!pc){
    ab.push(dpDocciaOggi()
      ? dpPanRiga('🚿 Doccia fredda di oggi', 'L’hai segnata.', dpDelta(DM_CFG.doccia), 'su')
      : dpPanRiga('🚿 Doccia fredda di oggi', 'Una al giorno, la segni tu.', '', '', { dopo: '<button type="button" class="dp-pbtn" onclick="dpDoccia()">Fatta</button>' }));
  }
  ab.push(dpPanRiga('⏰ Le tue finestre migliori', dpFinestreTesto(d), ''));
  const abitudini = '<div class="dp-prs">' + ab.join('') + '</div>';

  const tabs = '<div class="pst-tabs" role="tablist">' + DP_PAN.map(function(t){
    return '<button type="button" role="tab" data-k="' + t[0] + '" aria-selected="' + (t[0] === k) + '" class="pst-tab' + (t[0] === k ? ' on' : '') + '" onclick="dpPanVai(\'' + t[0] + '\')">' + t[1] + '</button>';
  }).join('') + '</div>';
  return '<div class="pst dp-pan" id="dpPan"><p class="pst-kick">La tua dopamina di oggi</p>' + tabs
    + '<div class="pst-corpo dp-pan-c">' + sez('riepilogo', riepilogo) + sez('cause', cause) + sez('abitudini', abitudini) + '</div>'
    + (d.autorita === 'telefono' ? '<p class="pst-nota">Il calcolo arriva dal telefono.</p>' : '')
    + '</div>';
}
async function dpDettaglioPaint(){
  const host = document.getElementById('dpDett');
  if (!host) return;
  /* 0.9.308: su un altro periodo la pagina di oggi non si scrive sopra (il carburante, una spunta, il calcolo che finisce) */
  if (!dpPgVistaOggi()){ dpPgRidipingi(); return; }
  if (!host.innerHTML){
    /* l'ultima pagina di oggi, subito (come il Report); il calcolo la rifa' appena finisce.
       0.9.358: solo se e' gia' la pagina con i grafici nel pannello bianco (data-car="pagina"), non quella delle versioni prima */
    let vecchia = null; try{ vecchia = JSON.parse(localStorage.getItem(DP_PAGINA_KEY) || 'null'); }catch(_){ }
    const buona = vecchia && vecchia.giorno === dpChiave(Date.now()) && vecchia.html && vecchia.html.indexOf('data-car="pagina"') >= 0;
    host.innerHTML = buona ? vecchia.html : '<div class="ins-load">Leggo la giornata…</div>';
    dpPanMostra(dpPanScheda());
  }
  const d = await dpCalcola();
  if (!document.body.contains(host)) return;
  if (!dpPgVistaOggi()){ dpPgRidipingi(); return; }
  if (!d || d.senzaDati){ host.innerHTML = '<p class="hintline">Serve l\'accesso ai dati di utilizzo.</p>'; return; }
  /* 0.9.353: col dito sul carosello la pagina non si riscrive sotto il dito (lo scorrimento si spezzerebbe): aspetta che si alzi */
  if (dpCarToccato()){ setTimeout(dpDettaglioPaint, 1300); return; }
  const r = d.ris;
  /* in cima solo il tachimetro: le cause stanno nel pannello sotto, una volta sola */
  const ult = r.voci[r.voci.length - 1];
  const inSess = ult && ult.tipo === 'sessione' && d.to - (ult.fine || ult.t) < 3 * 60000;
  const sx = (host.querySelector('.pst-tabs') || {}).scrollLeft || 0;
  host.innerHTML =
      '<div class="dp-card dp dp-testa">' + dpGaugeSvg(d.riserva) + dpBigHtml(d.riserva)
    +   (inSess ? '<p class="pfc-line">Picco in corso su <b>' + dpEsc(dpNomi(ult.l)) + '</b>.<br>Il conto arriva quando esci.</p>' : '')
    +   '<button type="button" class="dp-scopri-l" onclick="dpScopri()"><span>Scopri di più</span>' + DP_PG_DX + '</button>'
    /* 0.9.358, Andrea: i grafici stanno qui, nel pannello bianco sotto al tachimetro e sotto a "Scopri di piu'" */
    +   dpCaroselloHtml(d, 'pagina', dpVista(), true)
    + '</div>'
    + dpPannelloHtml(d);
  const row = host.querySelector('.pst-tabs'); if (row && sx) row.scrollLeft = sx;
  dpCarPrepara();
  dpPaginaRicorda();
}
/** L'ultima pagina di oggi resta in memoria, per mostrarla subito alla prossima apertura. */
function dpPaginaRicorda(){
  const host = document.getElementById('dpDett');
  if (!host || !dpPgVistaOggi() || !host.querySelector('#dpPan')) return;
  try{ localStorage.setItem(DP_PAGINA_KEY, JSON.stringify({ giorno: (DP.dett && DP.dett.giorno) || dpChiave(Date.now()), html: host.innerHTML })); }catch(_){ }
}
/**
 * I permessi per i passi, in due tempi: prima «Attività fisica» (il contapassi del telefono,
 * in tempo reale), poi Health Connect (gli allenamenti). Dopo la finestra di sistema si
 * aspetta che l'app torni davanti e si richiama: e' il telefono a dire quando ha finito.
 */
function dpAttesaRitorno(ms){
  return new Promise(function(ok){
    let fatto = false;
    const fine = function(){ if (fatto) return; fatto = true; document.removeEventListener('visibilitychange', su); ok(); };
    const su = function(){ if (!document.hidden) setTimeout(fine, 250); };
    document.addEventListener('visibilitychange', su);
    setTimeout(fine, ms || 6000);
  });
}
async function dpAttivaPassi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.requestSteps) return;
    for (let giro = 0; giro < 3; giro++){
      const r = await NATIVE.requestSteps();
      if (!r) break;
      if (r.asked){ await dpAttesaRitorno(6000); continue; }
      break;
    }
  }catch(_){ }
  await dpCalcola(true);
  dpDettaglioPaint();
}

/* «Cosa misura»: i numeri arrivano dal file dei parametri, cosi' la pagina non mente mai. */
function dpInfoHtml(){
  const c = DM_CFG, n = function(v){ return dpNum(v); };
  const s0 = c.sonno[0];
  const camm = c.camm.slice().sort(function(a, b){ return a[0] - b[0]; });
  const all = c.allenamento.slice().sort(function(a, b){ return a[0] - b[0]; });
  const ffb = function(m){ return dpDelta(dmFFBonus(m, c)); };
  /* 0.9.353, Andrea: "Cosa misura e' su uno sfondo grigio, coi paragrafi distanziati male: confonde". Adesso e' come i testi
     dell'Academy: un blocco per idea, l'emoji sopra al titolo, una o due frasi, le parole che si accendono scorrendo. */
  const blocchi = [
    { e: '🎢', t: 'La stimolazione', p: [
      'La curva della **stimolazione** mostra i picchi rapidi e i crolli che arrivano dopo.'] },
    { e: '📱', t: 'Video brevi, social e giochi', p: [
      'Bastano ' + c.altoMinMin + ' minuti per accendere un picco sulla curva della stimolazione.',
      'Alla riserva lasciano un **debito** da ' + c.debito[0] + ' a ' + c.debito[1] + ' punti, che se ne va piano.'] },
    { e: '🎯', t: 'Full Focus', p: [
      '25 minuti valgono **' + ffb(25) + '**, 45 minuti **' + ffb(45) + '** e 90 minuti **' + ffb(90) + '**.',
      'Se completi la task, guadagni altri **' + dpDelta(c.ffCompletata) + '**.'] },
    { e: '😴', t: 'Il sonno', p: [
      'Dopo ' + s0[0] + ' ore di sonno recuperi il **' + Math.round(s0[1] * 100) + '%** di quello che ti manca per tornare a ' + c.base + '.',
      'Se dormi meno di ' + c.sonno[c.sonno.length - 1][0] + ' ore, perdi **' + n(-c.sonnoCorto) + '** punti.'] },
    { e: '🚶', t: 'Il movimento', p: [
      'Una camminata senza telefono vale **' + dpDelta(camm[0][1]) + '** in ' + camm[0][0] + ' minuti e **' + dpDelta(camm[1][1]) + '** in ' + camm[1][0] + '.',
      'Un allenamento vale **' + dpDelta(all[0][1]) + '** da ' + all[0][0] + ' minuti e **' + dpDelta(all[1][1]) + '** da ' + all[1][0] + '.'] },
    { e: '✅', t: 'Le cose fatte', p: [
      'Ogni attività del piano vale **' + dpDelta(c.spunta) + '**. Una cosa nuova, la prima volta, vale **' + dpDelta(c.novitaSana) + '**.',
      'Ogni giorno di fila con il piano aggiunge **' + dpDelta(c.serieGiorno) + '**, fino a **+' + n(c.serieMax) + '**.'] },
    { e: '🍃', t: 'Le pause', p: [
      c.noiaMin + ' minuti senza schermi valgono **' + dpDelta(c.noia) + '**. Annoiarsi ti fa bene.'] },
    { e: '🔀', t: 'Cosa la abbassa', p: [
      'La abbassano i salti da un’app all’altra, le risposte sempre immediate e i social appena sveglio.',
      'Fra mezzanotte e le ' + c.notteA + ' ogni penalità **pesa il doppio**.'] }
  ];
  return '<div class="dpl">'
    + '<span class="dpl-hero" aria-hidden="true">🧠</span>'
    + '<h2 class="dpl-h1">Il tachimetro parte da ' + c.base + '</h2>'
    + '<section class="dpl-b"><p class="dpl-p">' + dpParole('Misura la tua **riserva di dopamina**, cioè la voglia di iniziare le cose.') + '</p>'
    + '<p class="dpl-p">' + dpParole('Sale solo quando fai uno sforzo sano. **Lo scroll non la alza mai.**') + '</p></section>'
    + dpBlocchiHtml(blocchi)
    + '<div class="dpl-fine"><p class="dpl-p">' + dpParole('È un modello che ti motiva, non una misura medica.') + '</p>'
    + '<p class="dpl-p">' + dpParole('La partenza più tutti i momenti della scheda Cause danno il numero di adesso.') + '</p></div>'
    + '</div>';
}
/* ---------------------------------------------------------------------------------------
   LE PAGINE DA LEGGERE: "Cosa misura" e "Scopri di piu'", come i testi dell'Academy (academy.js, acStoriaHtml e
   acScrubMonta): il fondo del brand, un blocco per idea con l'emoji sopra e il titolo, una o due frasi per paragrafo,
   le parole che si accendono mentre scorri.
   --------------------------------------------------------------------------------------- */
/** Un paragrafo con le parole che si accendono: **grassetto**, e dopo i due punti si va a capo. */
function dpParole(testo){
  return String(testo || '').replace(/(\d)\s*[–—]\s*(\d)/g, '$1-$2').split(/(\*\*[^*]+\*\*)/).map(function(pezzo){
    if (!pezzo) return '';
    const b = /^\*\*[^*]+\*\*$/.test(pezzo);
    const w = dpEsc(b ? pezzo.slice(2, -2) : pezzo).replace(/:\s+/g, ':\n').split(/(\s+)/).map(function(p){
      if (!p) return '';
      if (/^\s+$/.test(p)) return p.indexOf('\n') >= 0 ? '<br>' : ' ';
      return '<span class="dpw">' + p + '</span>';
    }).join('');
    return b ? '<b>' + w + '</b>' : w;
  }).join('');
}
/** I blocchi: [{ e: emoji, t: titolo gia' pronto, p: [paragrafi] }]. */
function dpBlocchiHtml(blocchi){
  return blocchi.map(function(b){
    return '<section class="dpl-b">' + (b.e ? '<span class="dpl-e" aria-hidden="true">' + b.e + '</span>' : '')
      + (b.t ? '<h3 class="dpl-h">' + b.t + '</h3>' : '')
      + b.p.map(function(x){ return '<p class="dpl-p">' + dpParole(x) + '</p>'; }).join('')
      + '</section>';
  }).join('');
}
/** Le frasi di una sezione a coppie: una o due frasi per paragrafo, mai di piu'. Una frase con i due punti va gia' a capo
    da sola: resta in un paragrafo suo, cosi' due idee diverse non finiscono sulla stessa riga. */
function dpCoppie(frasi){
  const out = [], capo = function(s){ return /:\s/.test(String(s || '')); };
  for (let i = 0; i < frasi.length; i++){
    if (!capo(frasi[i]) && i + 1 < frasi.length && !capo(frasi[i + 1])){ out.push(frasi[i] + ' ' + frasi[i + 1]); i++; }
    else out.push(frasi[i]);
  }
  return out;
}
/** Le parole si accendono man mano che il paragrafo sale nello schermo; titoli ed emoji arrivano quando ci si arriva. */
function dpLeggiScrub(root, daCapo){
  if (!root) return;
  let sc = root;
  while (sc && sc !== document.body && !/auto|scroll/.test(getComputedStyle(sc).overflowY)) sc = sc.parentElement;
  if (!sc || sc === document.body) sc = null;
  if (daCapo){
    root.querySelectorAll('.dpw.on').forEach(function(w){ w.classList.remove('on'); });
    root.querySelectorAll('.dpl-e.in,.dpl-h.in').forEach(function(el){ el.classList.remove('in'); });
    root.querySelectorAll('.dpl-p').forEach(function(p){ p.__k = -1; });
    if (sc) sc.scrollTop = 0;
  }
  /* la pagina si riscrive a ogni apertura (Scopri di piu'): lo scorrimento guarda sempre i blocchi a schermo adesso */
  if (sc) sc.__dplRoot = root;
  if (sc && !sc.__dpl){
    sc.__dpl = 1;
    let raf = 0;
    sc.addEventListener('scroll', function(){ if (!raf) raf = requestAnimationFrame(function(){ raf = 0; if (sc.__dplRoot) dpLeggiGiro(sc.__dplRoot, sc); }); }, { passive: true });
  }
  dpLeggiGiro(root, sc);
}
function dpLeggiGiro(root, sc){
  const vh = sc ? sc.clientHeight : window.innerHeight, top0 = sc ? sc.getBoundingClientRect().top : 0;
  const max = sc ? sc.scrollHeight - vh : 0, inFondo = !sc || max <= 4 || sc.scrollTop >= max - 6;
  let fermo = false; try{ fermo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  root.querySelectorAll('.dpl-p').forEach(function(p){
    const ws = p.__w || (p.__w = p.querySelectorAll('.dpw')), n = ws.length;
    if (!n) return;
    const r = p.getBoundingClientRect(), t = r.top - top0;
    const pg = (fermo || inFondo) ? 1 : Math.max(0, Math.min(1, (vh * 0.9 - t) / (r.height + vh * 0.32)));
    const k = Math.min(n, Math.round(pg * n * 1.25));
    if (p.__k === k) return;
    p.__k = k;
    for (let i = 0; i < n; i++) ws[i].classList.toggle('on', i < k);
  });
  root.querySelectorAll('.dpl-e,.dpl-h').forEach(function(el){
    if (el.classList.contains('in')) return;
    if (fermo || inFondo || el.getBoundingClientRect().top - top0 < vh * 0.92) el.classList.add('in');
  });
}
/* ---------------------------------------------------------------------------------------
   I PASSI DI OGGI
   La prova che il movimento viene letto davvero: da dove arrivano i passi, quanti sono, a
   che ora, quali camminate e quali allenamenti il modello ha riconosciuto.
   --------------------------------------------------------------------------------------- */
registerScreen('s-passi',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()" aria-label="Indietro">' + DP_INDIETRO + '</button><b class="blk-title">Passi di oggi</b>'
  + '<button type="button" class="dp-i dp-i-top" onclick="dpPassiPaint()" aria-label="Aggiorna">↻</button></div>'
  + '<div id="dpPassi" class="dp-page"></div>', { back: 's-dopamina' });
function dpPassiApri(){ goId('s-passi'); dpPassiPaint(); }
async function dpPassiPaint(){
  const host = document.getElementById('dpPassi');
  if (!host) return;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getSteps){
    host.innerHTML = '<div class="dp-fin"><b>📱 I passi li conta il telefono</b><small>Aprili dall’app sul telefono.</small></div>';
    return;
  }
  host.innerHTML = '<div class="ins-load">Leggo i passi…</div>';
  const from = dpMezzanotte(), to = Date.now();
  let r = null, all = [];
  try{ r = await NATIVE.getSteps({ from: from, to: to }); }catch(_){ }
  try{ if (NATIVE.getWorkouts){ const w = await NATIVE.getWorkouts({ from: from, to: to }); all = (w && w.items) || []; } }catch(_){ }
  if (!document.body.contains(host)) return;
  const minuti = ((r && r.minuti) || []).map(function(m){ return { t: +m.t, n: +m.n }; });
  const tot = minuti.reduce(function(a, m){ return a + m.n; }, 0);
  const ore = new Array(24).fill(0);
  minuti.forEach(function(m){ ore[new Date(m.t).getHours()] += m.n; });
  const max = Math.max(1, Math.max.apply(null, ore));
  const oraAdesso = new Date().getHours();
  const fonte = !r ? 'Nessuna risposta dal telefono'
    : r.fonte === 'telefono+health' ? 'Contapassi del telefono, più Health Connect'
    : r.fonte === 'health' ? 'Health Connect'
    : (r.granted ? 'Contapassi del telefono' : 'Nessuna: manca il permesso');
  /* manca qualcosa: il sensore (senza «Attività fisica» i passi arrivano solo quando l'app di
     salute li scrive) o Health Connect (senza, niente allenamenti) */
  const manca = r && (!r.sensore || (r.health && !(r.healthSteps && r.healthWorkouts)));
  const ultimo = minuti.length ? minuti[minuti.length - 1].t : 0;
  const camm = (DP.dett && DP.dett.ris && DP.dett.ris.camminate) || [];
  const obiettivo = DM_CFG.passiObiettivo;
  const loc = dpLoc();
  const barre = '<div class="dp-pbar">' + ore.map(function(n, h){
    const alt = Math.round(n / max * 100);
    return '<div class="' + (h > oraAdesso ? 'futuro' : '') + '" title="' + n + '"><i style="height:' + (n ? Math.max(4, alt) : 0) + '%"></i>'
      + (h % 6 === 0 ? '<span>' + String(h).padStart(2, '0') + '</span>' : '') + '</div>';
  }).join('') + '</div>';
  host.innerHTML =
      '<div class="dp-card dp">'
    +   '<p class="pfc-eyebrow">🚶 Passi misurati oggi</p>'
    +   '<b class="pfc-big dp-big">' + tot.toLocaleString(loc) + '</b>'
    +   '<div class="dp-pobj"><i style="width:' + Math.min(100, tot / obiettivo * 100).toFixed(1) + '%"></i></div>'
    +   '<p class="pfc-line">' + (tot >= obiettivo ? 'Obiettivo di ' + obiettivo.toLocaleString(loc) + ' passi raggiunto.' : 'Mancano <b>' + (obiettivo - tot).toLocaleString(loc) + '</b> passi all’obiettivo.') + '</p>'
    +   '<p class="dp-sotto">Ora per ora</p>' + barre
    + '</div>'
    + '<div class="dp-fin"><b>📡 Da dove arrivano</b><small>' + fonte + '.'
    +   (ultimo ? ' Ultimo passo letto alle <b>' + dpOra(ultimo) + '</b>.' : ' Oggi non è ancora arrivato nessun passo.') + '</small></div>'
    + (manca ? '<div class="dp-passi"><div><b>🔓 Permessi</b><small>' + (!r.sensore ? 'Consenti «Attività fisica»: è il contapassi del telefono, quello che conta i passi mentre cammini.' : 'Consenti passi e allenamenti in Health Connect.') + '</small></div>'
        + '<button type="button" class="btn primary" onclick="dpAttivaPassi().then(dpPassiPaint)">Attiva</button></div>' : '')
    + '<div class="sect"><b>🚶 Camminate senza telefono</b></div>'
    + (camm.length ? '<div class="dp-ev">' + camm.map(function(c){
        return '<div class="dp-evr buono"><b class="dp-evn">' + c.min + '′</b><div><b>' + dpOra(c.s) + '–' + dpOra(c.e) + '</b><small>' + c.passi.toLocaleString(loc) + ' passi</small></div></div>';
      }).join('') + '</div>'
      : '<p class="hintline">Nessuna ancora: servono almeno ' + DM_CFG.camm[DM_CFG.camm.length - 1][0] + ' minuti di passo senza usare il telefono.</p>')
    + '<div class="sect"><b>🏋️ Allenamenti</b></div>'
    + (all.length ? '<div class="dp-ev">' + all.map(function(a){
        return '<div class="dp-evr buono"><b class="dp-evn">' + Math.round((a.e - a.s) / 60000) + '′</b><div><b>' + dpEsc(dpAllenamentoNome(a.tipo, a.l)) + '</b><small>' + dpOra(a.s) + '–' + dpOra(a.e) + '</small></div></div>';
      }).join('') + '</div>'
      : '<p class="hintline">' + (r && r.healthWorkouts ? 'Nessun allenamento registrato oggi.' : 'Gli allenamenti arrivano da Health Connect.') + '</p>');
}

/* ---------------------------------------------------------------------------------------
   LE FINESTRE PRODUTTIVE
   Niente quiz sul cronotipo: si guarda in quali fasce le sessioni FullFocus riescono davvero,
   quanto durano, e dove ci si disperde di piu'. Prima di due settimane di dati non si dice
   niente: una finestra inventata e' peggio di nessuna.
   --------------------------------------------------------------------------------------- */
function dpFinestre(storia){
  const cfg = DM_CFG, oggi = dpMezzanotte();
  const ff = (dpLeggi('fl_ff_hist', []) || []).filter(function(x){
    return x && !x.meditazione && x.tag !== 'meditazione' && (x.start || x.at) > oggi - 60 * DP_DAY;
  });
  const giorni = {};
  ff.forEach(function(x){ giorni[dpChiave(x.start || x.at)] = 1; });
  Object.keys(storia || {}).forEach(function(k){ if (storia[k] && storia[k].n) giorni[k] = 1; });
  const n = Object.keys(giorni).length;
  if (n < cfg.finestreGiorniMin) return { pronto: false, giorni: n };
  const W = cfg.finestreOre, B = Math.round(24 / W);
  const st = []; for (let b = 0; b < B; b++) st.push({ tot: 0, ok: 0, min: 0, cambi: 0, gc: 0 });
  ff.forEach(function(x){
    const b = Math.floor(new Date(x.start || x.at).getHours() / W);
    st[b].tot++; if (x.ok) st[b].ok++; st[b].min += (x.spentMs || 0) / 60000;
  });
  Object.keys(storia || {}).forEach(function(k){
    const f = storia[k] && storia[k].fasce;
    if (Array.isArray(f) && f.length === B) f.forEach(function(c, b){ st[b].cambi += c; st[b].gc++; });
  });
  const voto = st.map(function(x, b){
    const cambi = x.gc ? x.cambi / x.gc : 0;
    const ok = x.tot >= 2 ? (x.ok / x.tot) * (x.min / x.tot) / (1 + cambi / 10) : null;
    return { b: b, da: b * W, a: b * W + W, voto: ok, tot: x.tot, tasso: x.tot ? x.ok / x.tot : 0, media: x.tot ? x.min / x.tot : 0, cambi: cambi };
  });
  let migliori = voto.filter(function(x){ return x.voto > 0; }).sort(function(a, b){ return b.voto - a.voto; }).slice(0, 2);
  let base = 'focus';
  if (!migliori.length){
    /* nessuna fascia con abbastanza sessioni: dove ci si disperde meno, di giorno */
    base = 'dispersione';
    migliori = voto.filter(function(x){ return x.da >= 8 && x.a <= 22 && st[x.b].gc; }).sort(function(a, b){ return a.cambi - b.cambi; }).slice(0, 2);
  }
  return { pronto: true, giorni: n, base: base, fasce: migliori.sort(function(a, b){ return a.da - b.da; }) };
}
function dpFinestreHtml(d){
  const f = dpFinestre(d.storia || {});
  const hh = function(h){ return String(h % 24).padStart(2, '0'); };
  let corpo;
  if (!f.pronto) corpo = 'Sto imparando i tuoi ritmi: giorno ' + Math.max(1, f.giorni) + ' di ' + DM_CFG.finestreGiorniMin + '.';
  else if (!f.fasce.length) corpo = 'Servono ancora un po’ di sessioni per dirlo.';
  else corpo = 'Rendi di più ' + f.fasce.map(function(x){ return 'fra le ' + hh(x.da) + ' e le ' + hh(x.a); }).join(' e ') + '. Metti lì le cose più difficili.';
  return '<div class="dp-fin"><b>⏰ Le tue finestre migliori</b><small>' + corpo + '</small></div>';
}

/* ---------------------------------------------------------------------------------------
   «SCOPRI DI PIU'»: i testi stanno in content/dopamina-scopri.json, nella lingua di chi legge.
   --------------------------------------------------------------------------------------- */
registerScreen('s-dopamina-scopri',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()" aria-label="Indietro">' + DP_INDIETRO + '</button><b class="blk-title" id="dpScopriT">Scopri di più</b></div>'
  + '<div id="dpScopri" class="dp-page dp-scopri"></div>', { back: 's-dopamina' });
let DP_SCOPRI = null;
async function dpScopri(){
  goId('s-dopamina-scopri');
  const host = document.getElementById('dpScopri');
  if (!host) return;
  try{
    if (!DP_SCOPRI) DP_SCOPRI = await (await fetch('content/dopamina-scopri.json')).json();
  }catch(_){ host.innerHTML = '<p class="hintline">Contenuto non disponibile.</p>'; return; }
  const c = (typeof flTesto === 'function') ? flTesto(DP_SCOPRI) : (DP_SCOPRI.it || DP_SCOPRI.en);
  const t = document.getElementById('dpScopriT'); if (t) t.textContent = c.titolo;
  /* 0.9.353, Andrea: "Scopri di piu' ha spaziature e paragrafi brutti". Un blocco per idea con l'emoji sopra e il titolo che
     stacca, le frasi a coppie (una o due per paragrafo), lo spazio vero fra un blocco e l'altro, come "Cosa misura" */
  host.innerHTML = '<div class="dpl">' + dpBlocchiHtml(c.sezioni.map(function(s){ return { e: s.e, t: dpEsc(s.t), p: dpCoppie(s.p || []) }; })) + '</div>';
  requestAnimationFrame(function(){ dpLeggiScrub(host.querySelector('.dpl'), true); });
}

registerScreen('s-dopamina-info',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()" aria-label="Indietro">' + DP_INDIETRO + '</button><b class="blk-title">Cosa misura</b></div>'
  + '<div class="dp-page dp-leggi">' + dpInfoHtml() + '</div>', { back: 's-home' });

/* ---------------------------------------------------------------------------------------
   RIDIPINGERE
   Si sostituisce SOLO la scheda (.dp con il suo data-dove), mai il suo contenitore. Prima si
   riscriveva l'innerHTML del genitore: nel pannello di panoramica del Blocco accanto alla
   scheda c'e' il menu ⋯, e al primo giro dell'orologio (o tornando da «Vedi cosa l'ha
   mossa», che ricalcola) il menu spariva con lei.
   --------------------------------------------------------------------------------------- */
function dpSchede(){
  return Array.prototype.slice.call(document.querySelectorAll('.dp[data-dove]'))
    .filter(function(b){ return b.dataset.dove !== 'giorno-passato'; });
}
function dpSostituisci(box, d){
  const tmp = document.createElement('div');
  tmp.innerHTML = dpCardHtml(d, box.dataset.dove, box.dataset.forza || '');
  const nuova = tmp.firstElementChild;
  if (nuova && box.parentNode) box.parentNode.replaceChild(nuova, box);
}

/** Ridipinge le schede dove sono, senza ricalcolare. */
function dpRidipingi(){
  if (!DP.dett) return;
  dpSchede().forEach(function(box){ dpSostituisci(box, DP.dett); });
  dpCarPrepara();
}

/** Dipinge la scheda dentro a `host`, e la tiene viva: ogni minuto, finche' e' a schermo. */
async function dpDipingi(host, dove, forza){
  if (!host) return;
  const d = await dpCalcola();
  if (!document.body.contains(host)) return;
  host.innerHTML = dpCardHtml(d, dove, forza);
  dpCarPrepara();
  dpVivo();
}
function dpVivo(){
  if (DP.timer) return;
  DP.timer = setInterval(async function(){
    if (!dpSchede().length){ clearInterval(DP.timer); DP.timer = 0; return; }
    if (document.hidden || dpCarToccato()) return;
    const d = await dpCalcola(true);
    if (dpCarToccato()) return;
    dpSchede().forEach(function(box){ dpSostituisci(box, d); });
    dpCarPrepara();
  }, 60000);
}

/* QUANDO L'APP TORNA DAVANTI si ricalcola subito. */
document.addEventListener('visibilitychange', function(){
  if (document.hidden) return;
  try{ dpCalcola(true); }catch(_){ }
});

/* E QUANDO SI SPUNTA UNA COSA, subito: e' il momento in cui il numero deve salire sotto gli
   occhi di chi l'ha fatta. */
document.addEventListener('fl:spunta', async function(){
  try{
    const d = await dpCalcola(true);
    dpSchede().forEach(function(box){ dpSostituisci(box, d); });
    if (document.getElementById('dpDett')) dpDettaglioPaint();
  }catch(_){ }
});

(function dpStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.dp{display:flex;flex-direction:column;align-items:center;text-align:center;width:100%}',
    '.dp-svg{display:block;width:min(100%,250px);height:auto;margin:0 auto 6px;color:var(--navy);overflow:visible}',
    'body.dark .dp-svg{color:#fff}',
    '.dp-ax{fill:currentColor;fill-opacity:.55;font:800 8.5px var(--font-body);letter-spacing:.12em}',
    '.dp-ago{filter:drop-shadow(0 2px 3px rgba(0,0,0,.25))}',
    '.dp-big small{color:var(--muted)}',
    '.dp .pfc-line{margin-top:10px}',
    '.dp-i{margin-left:8px;width:18px;height:18px;border-radius:50%;border:1px solid var(--line);background:none;',
      'color:var(--muted);font:800 10px var(--font-body);cursor:pointer;vertical-align:middle;padding:0}',
    '.dp-sett{display:flex;gap:10px;align-items:flex-end;justify-content:center;margin:12px 0 4px;height:80px}',
    '.dp-sett.compatta{height:52px;gap:8px;margin:6px 0 2px}',
    '.dp-bar{display:flex;flex-direction:column;align-items:center;gap:5px;width:24px}',
    '.dp-bar i{display:block;width:16px;border-radius:5px 5px 2px 2px;background:var(--line)}',
    '.dp-bar i.alta{background:#1B9E6A}.dp-bar i.media{background:#F2C21B}.dp-bar i.bassa{background:#E63946}',
    '.dp-bar span{font:700 10px var(--font-body);color:var(--faint)}',
    '.dp-bar.oggi span{color:var(--navy);font-weight:800}',
    '.dp-bar.futuro i{opacity:.35}',
    'body.dark .dp-bar.oggi span{color:#fff}',
    '.dp-curva{margin-top:8px}',
    '.dp-sotto{margin:14px 0 0;font:800 9.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--faint)}',
    '.dp-tap{width:100%;cursor:pointer;border-radius:12px}',
    '.dp-portariga{margin-top:14px;cursor:pointer}',
    '.dp-tap:active{background:rgba(0,117,227,.06)}',
    '.dp-link{color:var(--blue,#0075E3);letter-spacing:0;text-transform:none;font-weight:700}',
    '.dp-i-top{margin-left:auto;width:30px;height:30px;font-size:13px}',
    '.dp-page{padding:8px 16px 32px}',
    '.dp-ev{display:flex;flex-direction:column;gap:8px}',
    '.dp-evr{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:11px 14px;text-align:left}',
    'body.dark .dp-evr{background:#12203A;border-color:#22345A}',
    '.dp-evn{flex:none;min-width:52px;text-align:center;font:800 17px var(--font-display);font-style:italic;color:#E63946}',
    '.dp-evr.buono .dp-evn{color:#1B9E6A}',
    '.dp-evr div b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .dp-evr div b{color:#fff}',
    '.dp-evr div small{display:block;margin-top:2px;font:500 11.5px var(--font-body);color:var(--muted)}',
    /* il conto: partenza → adesso */
    '.dp-conto{display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;margin:4px 0 8px;font:600 14px var(--font-body);color:var(--muted)}',
    '.dp-conto b{color:var(--navy);font-weight:800}',
    'body.dark .dp-conto b{color:#fff}',
    '.dp-conto i{font-style:normal;color:var(--faint)}',
    '.dp-conto em{font:800 15px var(--font-display);font-style:italic}',
    '.dp-conto em.su{color:#1B9E6A}.dp-conto em.giu{color:#E63946}',
    '.dp-conti{margin:0 0 12px;text-align:center;font:500 12px var(--font-body);color:var(--muted)}',
    '.dp-conti b{color:var(--navy)}',
    'body.dark .dp-conti b{color:#fff}',
    /* le due classifiche, una sotto l'altra: affiancate a 360px i nomi non ci stavano */
    '.dp-cls{display:flex;flex-direction:column;gap:10px;margin:0 0 16px}',
    '.dp-cl{min-width:0;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 14px}',
    'body.dark .dp-cl{background:#12203A;border-color:#22345A}',
    '.dp-cl-t{display:block;margin:0 0 8px;font:800 12.5px var(--font-body);color:var(--navy)}',
    'body.dark .dp-cl-t{color:#fff}',
    '.dp-cl p{display:flex;justify-content:space-between;gap:8px;margin:0 0 6px;font:600 12px var(--font-body);color:var(--muted)}',
    '.dp-cl p span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.dp-cl p b{flex:none;font-weight:800}.dp-cl p b.su{color:#1B9E6A}.dp-cl p b.giu{color:#E63946}',
    '.dp-cl-0{opacity:.7}',
    '.dp-passi{display:flex;align-items:center;gap:12px;justify-content:space-between;margin:0 0 16px;padding:12px 14px;border:1px dashed var(--line);border-radius:14px;text-align:left}',
    '.dp-passi b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .dp-passi b{color:#fff}',
    '.dp-passi small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.dp-passi .btn{flex:none;width:auto;margin:0;padding:9px 16px;font-size:13px}',
    '.dp-legenda{margin:6px 0 0;font:500 11.5px/1.45 var(--font-body);color:var(--muted);text-align:center}',
    '.dp-fin{margin:0 0 16px;padding:12px 14px;border:1px solid var(--line);border-radius:14px;text-align:left;background:#fff}',
    'body.dark .dp-fin{background:#12203A;border-color:#22345A}',
    '.dp-fin b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .dp-fin b{color:#fff}',
    '.dp-fin small{display:block;margin-top:4px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    '.dp-passi-link{cursor:pointer;border-style:solid}',
    '.dp-freccia{flex:none;font:700 24px var(--font-body);color:var(--muted)}',
    '.dp-pbar{display:flex;align-items:flex-end;gap:3px;height:90px;width:100%;margin:10px 0 18px}',
    '.dp-pbar div{position:relative;flex:1;height:100%;display:flex;align-items:flex-end}',
    '.dp-pbar i{display:block;width:100%;border-radius:3px 3px 1px 1px;background:#1B9E6A}',
    '.dp-pbar div.futuro i{opacity:.3}',
    '.dp-pbar span{position:absolute;top:100%;left:0;margin-top:3px;font:700 9.5px var(--font-body);color:var(--faint)}',
    '.dp-pobj{width:100%;max-width:260px;height:8px;margin:10px auto 0;border-radius:99px;background:var(--line);overflow:hidden}',
    '.dp-pobj i{display:block;height:100%;background:#1B9E6A;border-radius:99px}',
    '.dp-nota{margin:14px 0 0;text-align:center;font:500 11.5px var(--font-body);color:var(--faint)}',
    /* le pagine che usano ancora .dp-info (la guida della Timeline in eta.js, il consenso e la guida dell'Io Futuro in
       iofuturo.js): paragrafi corti, titoli che si vedono. "Cosa misura" dal 0.9.353 ha i suoi blocchi (.dpl) */
    '.dp-info{max-width:34em}',
    '.dp-hero{font-size:56px;text-align:center;margin:14px 0 6px}',
    '.dp-info h2{margin:0 0 10px;font:800 21px/1.25 var(--font-display);color:var(--navy);text-align:center}',
    '.dp-info h3{margin:22px 0 6px;font:800 15px var(--font-body);color:var(--navy)}',
    'body.dark .dp-info h2,body.dark .dp-info h3{color:#fff}',
    '.dp-info p{margin:0 0 8px;font:500 14px/1.55 var(--font-body);color:var(--muted)}',
    '.dp-info p b{color:var(--navy);font-weight:800}',
    'body.dark .dp-info p b{color:#fff}',
    '.dp-info .dp-fine{margin-top:22px;padding-top:14px;border-top:1px solid var(--line);font-size:13px}',
    '.dp-chip{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:14px}',
    '.dp-chip button{border:1px solid var(--line);background:none;border-radius:99px;padding:6px 11px;font:700 11.5px var(--font-body);color:var(--muted);cursor:pointer}',
    '.dp-chip button.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    '.dp-card{background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px 16px 16px;margin:14px 0 6px}',
    /* 0.9.308: i periodi della pagina Dopamina (Settimana, Mese, Anno, giorni passati) */
    '.dp-pg-nav{margin-bottom:2px}.dp-pg-nav b{min-width:120px}',
    '.dp-pg-svg{display:block;width:100%;height:auto;margin:10px 0 4px;color:var(--navy);overflow:visible}body.dark .dp-pg-svg{color:#fff}',
    '.dp-pg-ax{fill:currentColor;fill-opacity:.5;font:700 9.5px var(--font-body)}.dp-pg-ax.oggi{fill-opacity:1;font-weight:800}',
    '.dp-pg-val{fill:currentColor;fill-opacity:.8;font:800 9px var(--font-body)}',
    '.dp-pg-col{cursor:pointer}',
    '.dp .dp-pg-f{margin-top:6px}.dp .dp-pg-conf{margin-top:6px}',
    '.dp-pg-f b{color:var(--navy)}body.dark .dp-pg-f b{color:#fff}',
    '.dp-pg-vuoto{padding:26px 18px 22px}.dp-pg-vuoto-t{display:block;margin:12px 0 0;font:800 16px/1.4 var(--font-body);color:var(--navy)}body.dark .dp-pg-vuoto-t{color:#fff}',
    'body.dark .dp-card{background:#12203A;border-color:#22345A}',
    /* 0.9.351: il tachimetro da solo in cima, poi il pannello a schede (scuro di proposito, come .pst: testo bianco fisso) */
    '.dp-testa{margin:14px 0 32px;padding-bottom:18px}',
    '.dp-scopri-l{display:inline-flex;align-items:center;gap:4px;margin-top:12px;border:0;background:none;color:#0075E3;font:700 14px var(--font-body);cursor:pointer;padding:6px 8px}',
    'body.dark .dp-scopri-l{color:#8CC6FF}',
    '.dp-pan{margin:0 0 8px}',
    /* 0.9.358: tre schede (Riepilogo, Cause, Abitudini), distribuite su tutta la larghezza: nessuna esce dal bordo */
    '.dp-pan .pst-tabs{justify-content:space-around;padding:0 8px}.dp-pan .pst-tab{padding:10px 8px 13px}.dp-pan .pst-tab.on::after{left:8px;right:8px}',
    '.dp-pan-c{padding-top:4px}',
    /* 0.9.353: blocco e blocco ad almeno 30px (regola di Andrea) */
    '.dp-pan-s{display:flex;flex-direction:column;gap:30px}.dp-pan-s[hidden]{display:none}',
    '.dp-pg{display:flex;flex-direction:column;gap:6px}',
    '.dp-pk{margin:0;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF;text-align:left}',
    '.dp-p0{margin:0;padding:8px 0;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.7);text-align:left}',
    '.dp-prs{display:flex;flex-direction:column}.dp-prs[hidden]{display:none}',
    '.dp-pr{display:flex;align-items:center;gap:12px;min-height:50px;padding:12px 0;border-top:1px solid rgba(255,255,255,.08);text-align:left}',
    '.dp-pr:first-child{border-top:0}',
    '.dp-pr.tocca{cursor:pointer;-webkit-tap-highlight-color:transparent}.dp-pr.tocca:active{background:rgba(255,255,255,.05)}',
    '.dp-pr-l{flex:1;min-width:0}',
    '.dp-pr-l b{display:block;font:700 14.5px/1.3 var(--font-body);color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.dp-pr-l small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:rgba(255,255,255,.62);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '.dp-pv{flex:none;font:800 16px var(--font-display);font-style:normal;font-variant-numeric:tabular-nums;color:#fff;white-space:nowrap}',
    '.dp-pv.su,.dp-pv.giu{padding:4px 11px;border-radius:99px;font:800 13.5px var(--font-body);color:#fff}',
    '.dp-pv.su{background:#0075E3}.dp-pv.giu{background:#E63946}',
    '.dp-pr .fl-chev{flex:none;margin-left:-4px;font-size:18px;color:rgba(255,255,255,.45)}',
    '.dp-pbtn{flex:none;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13.5px var(--font-body);padding:9px 18px;cursor:pointer}',
    '.dp-pmom{margin-top:-8px}',
    '.dp-pan .dp-curva{margin:4px 0 0;color:#fff}',
    '.dp-pan .pfc-ax{fill:#fff;fill-opacity:.5}',
    '.dp-pan .dp-curva path[stroke="#0075E3"]{stroke:#3F9FF4}',
    '.dp-pan .pst-nota{margin-top:6px}',
    /* 0.9.353: il conto. La differenza sta da sola, centrata sopra alla coppia partenza e adesso, mai di fianco */
    '.dp-pc{display:flex;flex-direction:column;align-items:center;gap:16px;padding:2px 0 0}',
    '.dp-pc > .dp-pv{margin:0}',
    '.dp-pc-r{display:flex;align-items:flex-end;justify-content:center;gap:20px}',
    '.dp-pc-r > div{display:flex;flex-direction:column;align-items:center;gap:8px;min-width:86px}',
    '.dp-pc-r small{font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.55)}',
    '.dp-pc-r b{font:900 30px/1 var(--font-display);font-variant-numeric:tabular-nums;color:#fff}',
    '.dp-pc-r svg{flex:none;margin-bottom:8px;color:rgba(255,255,255,.4)}',
    /* 0.9.358: i grafici in un carosello, una slide per grafico, nel pannello bianco della pagina e nella scheda della riserva
       (Profilo, Riposo, Report). Stanno su carta chiara: inchiostro del tema, come i grafici di prima nel Profilo */
    '.dp-testa{position:relative}',
    '.dp-testa .arb-dots{background:rgba(0,30,68,.07);border:1px solid var(--line);color:var(--navy)}',
    'body.dark .dp-testa .arb-dots{background:rgba(255,255,255,.12);border-color:#2A3A57;color:#fff}',
    '.dp-gr{display:flex;flex-direction:column;align-self:stretch;width:100%;min-width:0;margin-top:30px}',
    '.dp-car{display:flex;align-items:flex-start;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch;transition:height .25s ease}',
    '.dp-car::-webkit-scrollbar{display:none}',
    '.dp-car-s{flex:0 0 100%;min-width:0;box-sizing:border-box;scroll-snap-align:center;scroll-snap-stop:always;display:flex;flex-direction:column;align-items:center;text-align:center;overflow:hidden}',
    '.dp-car-t{margin:0 0 20px;padding:0 6px;font:800 10.5px/1.5 var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--faint);text-wrap:balance}',
    '.dp-car-mese text:last-of-type{text-anchor:end}.dp-car-mese text:first-of-type{text-anchor:start}',
    '.dp-car-s .dp-curva,.dp-car-s .dp-pg-svg{margin:0;width:100%}',
    '.dp-car-s .dp-sett{margin:4px auto 0}',
    '.dp-car-n{margin:16px 0 0;padding:0 6px;font:500 13px/1.5 var(--font-body);color:var(--muted);text-wrap:pretty}',
    '.dp-car-n b{color:var(--navy);font-weight:800}body.dark .dp-car-n b{color:#fff}',
    '.dp-car-0{margin:0;padding:10px 6px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.dp-car-d{display:flex;justify-content:center;gap:2px;margin-top:16px}',
    '.dp-car-d button{flex:none;width:22px;height:22px;border:0;background:none;padding:0;display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.dp-car-d i{flex:none;display:block;width:7px;height:7px;border-radius:50%;background:rgba(0,30,68,.18);transition:background .2s ease,transform .2s ease}',
    '.dp-car-d button.on i{background:#0075E3;transform:scale(1.25)}',
    'body.dark .dp-car-d i{background:rgba(255,255,255,.25)}body.dark .dp-car-d button.on i{background:#8CC6FF}',
    /* nel Profilo sotto ai pallini dei grafici ci sono quelli delle schede (le pillole): almeno 26 px fra le due file */
    '.pfc .dp-car-d{margin-bottom:26px}',
    '.dp-pan .dp-pg-svg{color:#fff}',
    '.dp-pan .dp-curva circle{fill:#8CC6FF}',
    '.dp-pan .dp-curva path[fill="#7A8BA6"]{fill:#8CC6FF}',
    /* 0.9.353: le pagine da leggere ("Cosa misura", "Scopri di piu'") sul fondo del brand, come le lezioni dell'Academy */
    '#s-dopamina-info,#s-dopamina-scopri{background:#F0FBFF}',
    'body.dark #s-dopamina-info,body.dark #s-dopamina-scopri{background:#001E44}',
    '.dpl{max-width:34em;margin:0 auto;padding:4px 4px 56px;text-align:center}',
    '.dpl-hero{display:block;font-size:56px;line-height:1;margin:16px 0 18px}',
    '.dpl-h1{margin:0 0 30px;font:800 24px/1.3 var(--font-display);color:#001E44;text-wrap:balance}',
    'body.dark .dpl-h1{color:#fff}',
    '.dpl-b{margin:0 0 52px}',
    '.dpl-e{display:block;font-size:34px;line-height:1.1;margin:0 0 12px;opacity:0;transform:translateY(18px);transition:opacity .5s ease,transform .5s ease}',
    '.dpl-h{margin:0 0 18px;font:800 21px/1.3 var(--font-display);color:#001E44;text-wrap:balance;opacity:0;transform:translateY(22px);transition:opacity .6s ease,transform .6s ease}',
    '.dpl-e.in,.dpl-h.in{opacity:1;transform:none}',
    'body.dark .dpl-h{color:#fff}',
    '.dpl-p{margin:0 auto 18px;max-width:30em;font:500 17px/1.7 var(--font-body);color:#33476A;text-wrap:pretty}',
    '.dpl-p:last-child{margin-bottom:0}',
    'body.dark .dpl-p{color:#D6E8FF}',
    '.dpl-p b{font-weight:800;color:#001E44}',
    'body.dark .dpl-p b{color:#fff}',
    '.dpw{opacity:.16;transition:opacity .28s ease}.dpw.on{opacity:1}',
    '.dpl-fine{margin:0 auto;padding-top:30px;border-top:1px solid rgba(0,117,227,.18);max-width:30em}',
    '.dpl-fine .dpl-p{font-size:14.5px;color:#5A6F92}',
    'body.dark .dpl-fine{border-top-color:rgba(140,198,255,.22)}',
    'body.dark .dpl-fine .dpl-p{color:#9FB8DA}'
  ].join('');
  document.head.appendChild(st);
})();
