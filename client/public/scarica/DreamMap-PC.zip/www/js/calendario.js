/* ===========================================================================================
   IL CALENDARIO A ORARI DELLA MAPPA (0.9.235): Mese | Settimana | Giorno

   Andrea: il calendario della scheda Calendario resta com'era (Mese, il primo che si vede); un
   interruttore in alto porta alle viste a orari come Google Calendar, Giorno e Settimana, con la
   linea rossa dell'ora di adesso. Gli eventi si creano col + o toccando un orario vuoto; un
   evento si tocca per cambiarlo o toglierlo. La rotella apre le impostazioni: collegare il
   calendario del telefono (quello che Google Calendar sincronizza con l'account Google, niente
   password) e la Chiamata dei sogni quando comincia un evento.

   I DATI (contratto con la Chiamata dei sogni, non cambiarlo):
   - localStorage `fl_cal_eventi`: [{ id, titolo, inizio(ms), fine(ms), descr, colore, chiamata,
     gcal?: { calId, eventId }, creato, mod }]
   - localStorage `fl_cal_chiamata` ('1'/'0', senza chiave = acceso): la condizione "Appuntamento con
     te stesso" della Chiamata dei sogni e la chiamata accesa di base sugli eventi nuovi
   - calEventi(), calEventiTra(da, a), calSalvaEvento(ev), calEliminaEvento(id), calChiamataGlobale()
   - dopo ogni salvataggio o eliminazione: window.calDopoModifica(ev, 'salva'|'elimina') (e (null,
     'impostazioni') quando si cambia l'interruttore della chiamata) e
     l'evento `fl:calendario` su document, con detail { ev, azione }.
   Il collegamento col telefono sta in `fl_cal_gcal`: { collegato, scrivi: {id, nome, account,
   colore}, mostra: [id] }. Sul computer (niente NATIVE) le viste e gli eventi funzionano uguale,
   solo senza il calendario del telefono.
   =========================================================================================== */
const CAL = { vista: null, giorno: null, tel: { chiave: '', lista: [], t: 0 }, carica: '', scrollChiave: '', mappa: {}, calendari: null, form: null, timer: 0 };
const CAL_H = 48; /* i pixel di un'ora nella griglia */
/* 0.9.306, Andrea: i colori degli eventi sono quelli del brand (niente giallo, verde, arancione, rosa) */
const CAL_COLORI = [['#0075E3', 'Blu'], ['#E63946', 'Rosso'], ['#3F9FF4', 'Azzurro'], ['#14234A', 'Blu notte'], ['#BCE0FF', 'Azzurro chiaro'], ['#005BB0', 'Blu scuro'], ['#C42B38', 'Rosso scuro'], ['#8CC6FF', 'Celeste']];
const CAL_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
const CAL_GBREVI = ['dom', 'lun', 'mar', 'mer', 'gio', 'ven', 'sab'];
const CAL_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

/* ---------- i dati ---------- */
function calEventi(){
  try{ const l = JSON.parse(localStorage.getItem('fl_cal_eventi') || '[]'); return Array.isArray(l) ? l.filter(function(e){ return e && e.id; }) : []; }catch(_){ return []; }
}
function calScriviTutti(l){ try{ localStorage.setItem('fl_cal_eventi', JSON.stringify(l)); }catch(_){ } }
/* `fl_cal_chiamata` e' UNA cosa sola: la condizione "Appuntamento con te stesso" della Chiamata dei
   sogni (la legge e la scrive anche dreamcall.js). Senza la chiave vale accesa. */
function calChiamataGlobale(){ try{ return localStorage.getItem('fl_cal_chiamata') !== '0'; }catch(_){ return true; } }
function calChiamataGlobaleSet(on){ try{ localStorage.setItem('fl_cal_chiamata', on ? '1' : '0'); }catch(_){ } calAvvisa(null, 'impostazioni'); }
function calNuovoId(){ return 'ev_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function calNorm(ev, vecchio){
  ev = ev || {}; const ora = Date.now();
  const inizio = Math.round(Number(ev.inizio)) || ora;
  let fine = Math.round(Number(ev.fine)) || 0; if (fine <= inizio) fine = inizio + 30 * 60000;
  const n = {
    id: String(ev.id || (vecchio && vecchio.id) || calNuovoId()),
    titolo: String(ev.titolo || '').trim() || 'Evento',
    inizio: inizio, fine: fine,
    descr: String(ev.descr || ''),
    colore: /^#[0-9a-f]{6}$/i.test(String(ev.colore || '')) ? String(ev.colore) : '#0075E3',
    chiamata: typeof ev.chiamata === 'boolean' ? ev.chiamata : (vecchio ? !!vecchio.chiamata : calChiamataGlobale()),
    /* 0.9.285: una data importante del mese compare nella prima slide della scheda Sogno (dream-mese.js) */
    importante: typeof ev.importante === 'boolean' ? ev.importante : !!(vecchio && vecchio.importante),
    creato: Number((vecchio && vecchio.creato) || ev.creato) || ora,
    mod: ora
  };
  const g = ev.gcal !== undefined ? ev.gcal : (vecchio ? vecchio.gcal : null);
  if (g && g.eventId != null && g.eventId !== '') n.gcal = { calId: g.calId, eventId: g.eventId };
  return n;
}
function calAvvisa(ev, azione){
  try{ if (typeof window.calDopoModifica === 'function') window.calDopoModifica(ev, azione); }catch(e){ try{ console.warn('calDopoModifica', e); }catch(_){ } }
  try{ document.dispatchEvent(new CustomEvent('fl:calendario', { detail: { ev: ev, azione: azione } })); }catch(_){ }
}
/** Salva (nuovo o cambiato) un evento di DreamMap e restituisce quello salvato. */
function calSalvaEvento(ev){
  const l = calEventi();
  const i = ev && ev.id ? l.findIndex(function(x){ return x.id === ev.id; }) : -1;
  const n = calNorm(ev, i >= 0 ? l[i] : null);
  if (i >= 0) l[i] = n; else l.push(n);
  calScriviTutti(l);
  calAvvisa(n, 'salva');
  calTelefonoScrivi(n);
  return n;
}
/** Toglie un evento di DreamMap (e la sua copia nel calendario del telefono). */
function calEliminaEvento(id){
  const l = calEventi(); const i = l.findIndex(function(x){ return x.id === id; });
  if (i < 0) return false;
  const ev = l.splice(i, 1)[0];
  calScriviTutti(l);
  calAvvisa(ev, 'elimina');
  calTelefonoTogli(ev);
  return true;
}
/** Gli eventi fra da e a (ms): quelli di DreamMap e quelli del calendario del telefono (dall'ultima
    lettura; la lettura nuova parte da sola e ridisegna le viste quando arriva). */
function calEventiTra(da, a){
  da = Number(da) || 0; a = Number(a) || 0;
  const loc = calEventi().filter(function(e){ return e.inizio < a && e.fine > da; });
  const nostri = {};
  loc.forEach(function(e){ if (e.gcal && e.gcal.eventId != null) nostri[String(e.gcal.eventId)] = 1; });
  const out = loc.map(function(e){ return Object.assign({}, e, { fonte: 'dreammap' }); });
  if (calCollegato()){
    const solo = calSoloDm();
    CAL.tel.lista.forEach(function(t){
      if (solo && !calDiDreamMap(t)) return;
      if (t.inizio < a && t.fine > da && !nostri[String(t.eventId)]) out.push(Object.assign({}, t, { fonte: 'telefono' }));
    });
    calTelefonoLeggi(da, a);
  }
  return out.sort(function(x, y){ return x.inizio - y.inizio; });
}
/* 0.9.290, Andrea: "con tutti gli impegni del calendario di Google la settimana e' schiacciata e non si capisce niente:
   nelle impostazioni voglio poter vedere solo le cose programmate in DreamMap". I turni scritti da DreamMap nel calendario
   del telefono (dalle foto di WhatsApp) restano: sono suoi. */
function calSoloDm(){ try{ return localStorage.getItem('fl_cal_solo_dm') === '1'; }catch(_){ return false; } }
function calDiDreamMap(t){ return /^Turno\b/.test(String(t.titolo || '')) || /turni del gruppo|DreamMap/i.test(String(t.descr || '')); }
function calSoloDmCambia(b){
  const on = !calSoloDm();
  try{ localStorage.setItem('fl_cal_solo_dm', on ? '1' : '0'); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  if (b){ b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); }
  calRidisegna();
}
/** Come calEventiTra, ma aspetta la lettura fresca del calendario del telefono. */
function calEventiTraAsync(da, a){
  return calTelefonoLeggi(da, a, true).then(function(){ return calEventiTra(da, a); }, function(){ return calEventiTra(da, a); });
}

/* ---------- il calendario del telefono (CalendarContract, FocusLockPlugin) ---------- */
/* il plugin nativo; window.__calFinto serve solo alle prove nel browser (un finto plugin) */
function calN(){ return window.__calFinto || (typeof NATIVE !== 'undefined' ? NATIVE : null); }
function calNativo(){ const n = calN(); return !!n && typeof n.calendarioEventi === 'function'; }
function calGcal(){ try{ const g = JSON.parse(localStorage.getItem('fl_cal_gcal') || 'null'); return g && typeof g === 'object' ? g : {}; }catch(_){ return {}; } }
function calGcalSalva(g){ try{ localStorage.setItem('fl_cal_gcal', JSON.stringify(g)); }catch(_){ } CAL.tel = { chiave: '', lista: [], t: 0 }; }
function calCollegato(){ const g = calGcal(); return calNativo() && !!g.collegato && !!g.scrivi && g.scrivi.id != null; }
function calTelefonoLeggi(da, a, forza){
  if (!calCollegato()) return Promise.resolve([]);
  const g = calGcal(), mostra = (g.mostra || []).slice();
  const chiave = da + '|' + a + '|' + mostra.join(',');
  if (!forza && CAL.tel.chiave === chiave && Date.now() - CAL.tel.t < 60000) return Promise.resolve(CAL.tel.lista);
  if (CAL.carica === chiave) return Promise.resolve(CAL.tel.lista);
  if (!mostra.length){ CAL.tel = { chiave: chiave, lista: [], t: Date.now() }; return Promise.resolve([]); }
  CAL.carica = chiave;
  return calN().calendarioEventi({ da: da, a: a, calendari: mostra }).then(function(r){
    CAL.carica = '';
    const lista = ((r && r.eventi) || []).map(function(t){
      return { id: 'tel_' + t.eventId + '_' + t.inizio, titolo: String(t.titolo || '(senza titolo)'), inizio: Number(t.inizio), fine: Number(t.fine), descr: String(t.descr || ''), colore: String(t.colore || '#0075E3'), chiamata: false, eventId: t.eventId, calId: t.calId, calendario: String(t.calendario || ''), tuttoIlGiorno: !!t.tuttoIlGiorno };
    });
    const prima = JSON.stringify(CAL.tel.lista);
    CAL.tel = { chiave: chiave, lista: lista, t: Date.now() };
    if (prima !== JSON.stringify(lista)) calRidisegna();
    return lista;
  }, function(e){
    CAL.carica = '';
    CAL.tel = { chiave: chiave, lista: [], t: Date.now() };
    /* il permesso e' stato tolto dalle impostazioni di Android: il collegamento si spegne */
    if (e && e.code === 'permission'){ const g2 = calGcal(); g2.collegato = false; calGcalSalva(g2); calRidisegna(); }
    return [];
  });
}
function calTelefonoScrivi(ev){
  if (!calCollegato()) return;
  const g = calGcal();
  const dati = { titolo: ev.titolo, inizio: ev.inizio, fine: ev.fine, descr: ev.descr, colore: ev.colore };
  const metti = function(){
    return calN().calendarioInserisci(Object.assign({ calId: g.scrivi.id }, dati)).then(function(r){
      if (r && r.eventId != null) calGcalSegna(ev.id, { calId: g.scrivi.id, eventId: r.eventId });
    });
  };
  const p = ev.gcal && ev.gcal.eventId != null
    ? calN().calendarioAggiorna(Object.assign({ eventId: ev.gcal.eventId }, dati)).then(function(r){ if (!r || !r.righe) return metti(); })
    : metti();
  p.then(function(){ CAL.tel.t = 0; calRidisegna(); }, function(){ try{ toast('Non sono riuscito a scriverlo nel calendario del telefono. In DreamMap è salvato.'); }catch(_){ } });
}
/** Scrive l'id del calendario del telefono sull'evento, senza riavvisare la Chiamata dei sogni. */
function calGcalSegna(id, gcal){
  const l = calEventi(); const e = l.find(function(x){ return x.id === id; }); if (!e) return;
  e.gcal = gcal; calScriviTutti(l);
}
function calTelefonoTogli(ev){
  if (!ev || !ev.gcal || ev.gcal.eventId == null || !calCollegato()) return;
  calN().calendarioElimina({ eventId: ev.gcal.eventId }).then(function(){ CAL.tel.t = 0; calRidisegna(); }, function(){ });
}

/* ---------- le date ---------- */
function calMezzanotte(d){ const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }
function calPiuGiorni(d, n){ const x = new Date(d); x.setDate(x.getDate() + n); x.setHours(0, 0, 0, 0); return x; }
function calIso(d){ d = new Date(d); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function calDaIso(iso){ const p = String(iso || '').split('-'); return p.length === 3 ? new Date(+p[0], +p[1] - 1, +p[2]) : calMezzanotte(new Date()); }
function calLunedi(d){ const x = calMezzanotte(d); return calPiuGiorni(x, -((x.getDay() + 6) % 7)); }
function calHHMM(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function calOraBreve(ms){ const d = new Date(ms); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function calDurata(min){
  min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60;
  const mm = m === 1 ? '1 minuto' : m + ' minuti';
  if (!h) return mm;
  const hh = h === 1 ? '1 ora' : h + ' ore';
  return m ? hh + ' e ' + mm : hh;
}
function calVistaOra(){
  if (!CAL.vista){ try{ CAL.vista = localStorage.getItem('fl_cal_vista') || 'mese'; }catch(_){ CAL.vista = 'mese'; } }
  if (['mese', 'settimana', 'giorno'].indexOf(CAL.vista) < 0) CAL.vista = 'mese';
  return CAL.vista;
}
function calGiornoOra(){
  if (!CAL.giorno){ const sel = typeof MF !== 'undefined' && MF.giorno; CAL.giorno = sel ? calDaIso(sel) : calMezzanotte(new Date()); }
  return CAL.giorno;
}

/* ---------- le icone ---------- */
function calIco(p, n){ return '<svg viewBox="0 0 24 24" width="' + (n || 20) + '" height="' + (n || 20) + '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; }
const CAL_I = {
  sx: '<path d="M15 18l-6-6 6-6"/>',
  dx: '<path d="M9 18l6-6-6-6"/>',
  piu: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M18 6L6 18M6 6l12 12"/>',
  ok: '<path d="M20 6L9 17l-5-5"/>',
  cestino: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
  rotella: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  telefono: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/>',
  giu: '<path d="M6 9l6 6 6-6"/>',
  cal: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'
};
/** Il testo sopra a un colore: navy sui colori chiari (il giallo), bianco sugli altri. */
function calInchiostro(hex){
  const h = String(hex || '').replace('#', ''); if (h.length !== 6) return '#fff';
  const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
  /* 0.9.306: soglia 130 (era 165): sull'azzurro #3F9FF4 il bianco non si leggeva */
  return (0.299 * r + 0.587 * g + 0.114 * b) > 130 ? '#0F2041' : '#fff';
}
/* ---------- IL COLORE DI OGNI EVENTO (0.9.306) ----------
   Andrea: "venerdi' il turno UIT1 e la tappa di DreamMap sono tutti e due blu e si mimetizzano". Ogni tipo di evento ha
   il suo colore del brand; gli eventi del calendario del telefono prendono un colore per calendario. Poi calColoriVicini
   garantisce che due eventi che si toccano o si accavallano non abbiano MAI lo stesso colore: il secondo passa al colore
   dopo nella tavolozza. */
const CAL_PAL = ['#0075E3', '#E63946', '#3F9FF4', '#14234A', '#BCE0FF', '#005BB0', '#C42B38', '#8CC6FF'];
const CAL_TIPO_COLORE = { tappa: '#0075E3', turno: '#E63946', prenotato: '#BCE0FF', settimana: '#3F9FF4', coppia: '#14234A' };
function calTipoEv(x){
  const t = String(x.titolo || ''), d = String(x.descr || '');
  if (/tappa di DreamMap|^Tappa DreamMap/i.test(t)) return 'tappa';
  if (/^Turno\b/.test(t)) return 'turno';
  if (/Punto prenotato/i.test(d)) return 'prenotato';
  if (/La settimana in DreamMap/.test(d)) return 'settimana';
  if (String(x.colore || '').toUpperCase() === '#FF6FA8') return 'coppia';
  return '';
}
function calColoreEv(x){
  const tipo = calTipoEv(x);
  if (tipo) return CAL_TIPO_COLORE[tipo];
  if (x.fonte === 'telefono'){
    const k = String(x.calId != null ? x.calId : x.calendario || ''); let h = 0;
    for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) >>> 0;
    return CAL_PAL[h % CAL_PAL.length];
  }
  return /^#[0-9a-f]{6}$/i.test(String(x.colore || '')) ? String(x.colore) : '#0075E3';
}
/** Il nome che si legge nel riquadro: "La tua tappa di DreamMap" diventa "Tappa DreamMap" (le colonne sono strette). */
function calTitoloVis(x){ return String(x.titolo || '').replace(/^La tua tappa di DreamMap/i, 'Tappa').replace(/^Fai la tua tappa/i, 'Tappa').trim() || 'Evento'; }
/** p: { ev, s, eVis } gia' disposti da calDisponi. Scrive p.colore e p.vicini (quanti eventi tocca o accavalla). */
function calColoriVicini(lista){
  const fatti = [];
  lista.slice().sort(function(a, b){ return a.s - b.s || b.eVis - a.eVis; }).forEach(function(p){
    const vicini = fatti.filter(function(q){ return q.s <= p.eVis && p.s <= q.eVis; });
    const usati = vicini.map(function(q){ return q.colore.toUpperCase(); });
    let c = calColoreEv(p.ev);
    if (usati.indexOf(c.toUpperCase()) >= 0){
      const i0 = Math.max(0, CAL_PAL.findIndex(function(x){ return x.toUpperCase() === c.toUpperCase(); }));
      for (let k = 1; k <= CAL_PAL.length; k++){ const n = CAL_PAL[(i0 + k) % CAL_PAL.length]; if (usati.indexOf(n.toUpperCase()) < 0){ c = n; break; } }
    }
    p.colore = c; p.vicini = vicini.length;
    vicini.forEach(function(q){ q.vicini = (q.vicini || 0) + 1; });
    fatti.push(p);
  });
  return lista;
}
function calAttr(s){ return String(s).replace(/[^\w-]/g, ''); }

/* ---------- il corpo della scheda Calendario (mappa-foglio.js lo chiama al posto di mfCalHtml) ----------
   0.9.286, Andrea: lo stesso calendario anche nel pannello della Roadmap (opz.dove = 'roadmap'), con la rotella.
   Al posto delle tre schede Mese | Settimana | Giorno un pulsante solo, l'icona del calendario con la freccia (come
   Vectal), che apre il menu delle viste. La Settimana mostra tre giorni: sette colonne su un telefono non si leggono. */
const CAL_VISTE = [['mese', 'Mese', 'Tutto il mese, giorno per giorno'], ['settimana', 'Settimana', 'Tre giorni alla volta'], ['giorno', 'Giorno', 'Le ore di un giorno solo']];
function calCorpo(opz){
  const v = calVistaOra();
  CAL.dove = (opz && opz.dove) || 'mappa';
  const nome = (CAL_VISTE.filter(function(x){ return x[0] === v; })[0] || CAL_VISTE[0])[1];
  const barra = '<div class="cal-barra"><div class="cal-vw"><button type="button" class="cal-vista-b" onclick="calVistaMenu(event)" aria-haspopup="menu" aria-label="Cambia vista: adesso ' + nome + '">' + calIco(CAL_I.cal, 19) + calIco(CAL_I.giu, 16) + '</button></div>'
    + '<span class="cal-spazio"></span>'
    + (v === 'mese' ? '' : '<button type="button" class="cal-piu" onclick="calNuovo()" aria-label="Nuovo evento">' + calIco(CAL_I.piu, 22) + '</button>')
    + '<button type="button" class="cal-tondo" onclick="calImpApri()" aria-label="Impostazioni del calendario">' + flIngranaggio(19) + '</button></div>';
  const vista = v === 'mese' ? (typeof mfCalHtml === 'function' ? mfCalHtml() : '') : calGrigliaHtml(v);
  return barra + vista + calSettimanaPulsante(CAL.dove);
}
/* PIANIFICA LA SETTIMANA (0.9.286, Andrea): apre la chat del tuo agente personale in un foglio, con il messaggio gia' scritto
   nel campo (parte solo quando lo mandi tu). Nella Mappa (pianifica tu) per pianificare la settimana; nella Roadmap la
   settimana l'ha gia' pianificata il Genio, quindi il pulsante c'e' solo con "Voglio poterlo modificare" acceso, e
   serve per un imprevisto: il Genio ricalcola questa settimana (o la prossima) e fa slittare quelle dopo. */
function calSettimanaPulsante(dove){
  if (typeof agPopover !== 'function') return '';
  const roadmap = dove === 'roadmap';
  if (roadmap && !(typeof rmpModificabile === 'function' && rmpModificabile())) return '';
  return '<button type="button" class="cal-sett-b" onclick="calSettimanaChat(\'' + (roadmap ? 'roadmap' : 'mappa') + '\')">'
    + calIco('<path d="M12 3l1.8 4.6L18.5 9l-4.7 1.4L12 15l-1.8-4.6L5.5 9l4.7-1.4z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>', 18)
    + '<span><b>' + (roadmap ? 'Ricalcola la settimana' : 'Pianifica la settimana') + '</b>' + (roadmap ? '<small>Per un imprevisto: il tuo agente personale sposta i passi</small>' : '') + '</span></button>';
}
function calSettimanaTesto(dove){
  const lun = calLunedi(new Date()), dom = calPiuGiorni(lun, 6);
  const dal = lun.getDate() + (lun.getMonth() === dom.getMonth() ? '' : ' ' + CAL_MESI[lun.getMonth()]), al = dom.getDate() + ' ' + CAL_MESI[dom.getMonth()];
  if (dove === 'roadmap') return 'C\u2019\u00e8 stato un imprevisto e questa settimana non posso seguire il piano della roadmap come era scritto. '
    + 'Ricalcola il percorso: ripianifica questa settimana (o la prossima, se serve) e fai slittare di conseguenza le settimane dopo. Ecco cosa \u00e8 successo: ';
  return 'Pianifichiamo insieme la mia settimana, dal ' + dal + ' al ' + al + ': metti le cose importanti nei giorni giusti, con il tempo che serve a ognuna. Le cose importanti sono: ';
}
function calSettimanaChat(dove){
  try{ flVibra(8); }catch(_){ }
  agPopover(calSettimanaTesto(dove), { titolo: dove === 'roadmap' ? 'Un imprevisto nella settimana' : 'La mia settimana' });
}
/* il menu delle viste, sotto al pulsante */
function calVistaMenu(e){
  if (e) e.stopPropagation();
  const via = document.getElementById('calVistaMenu'); if (via){ via.remove(); return; }
  const b = e && e.currentTarget ? e.currentTarget : document.querySelector('.cal-vista-b'); if (!b) return;
  const v = calVistaOra();
  const m = document.createElement('div'); m.id = 'calVistaMenu'; m.className = 'cal-vm'; m.setAttribute('role', 'menu');
  m.innerHTML = CAL_VISTE.map(function(x){
    return '<button type="button" role="menuitemradio" aria-checked="' + (x[0] === v) + '" class="' + (x[0] === v ? 'on' : '') + '" onclick="calVistaScegli(\'' + x[0] + '\')"><span><b>' + x[1] + '</b><small>' + x[2] + '</small></span>' + (x[0] === v ? calIco(CAL_I.ok, 18) : '') + '</button>';
  }).join('');
  b.parentNode.appendChild(m);
  setTimeout(function(){
    const fuori = function(ev){ if (!m.contains(ev.target)){ m.remove(); document.removeEventListener('pointerdown', fuori, true); } };
    document.addEventListener('pointerdown', fuori, true);
  }, 0);
}
function calVistaScegli(v){ const m = document.getElementById('calVistaMenu'); if (m) m.remove(); calVista(v); }
function calVista(v){
  CAL.vista = v; try{ localStorage.setItem('fl_cal_vista', v); }catch(_){ }
  if (v !== 'mese' && typeof MF !== 'undefined' && MF.giorno) CAL.giorno = calDaIso(MF.giorno);
  try{ flVibra(6); }catch(_){ }
  calRidisegna();
}
/** La griglia che si vede adesso: il calendario puo' stare sia nella Mappa sia nella Roadmap (una delle due e' nascosta). */
function calScrollVisibile(){
  const l = document.querySelectorAll('.cal-scroll');
  for (let i = 0; i < l.length; i++) if (l[i].offsetParent !== null) return l[i];
  return l[0] || null;
}
function calRidisegna(){
  const s = calScrollVisibile(), top = s ? s.scrollTop : null;
  let fatto = false;
  if (typeof RMP !== 'undefined' && RMP.tab === 'cal' && typeof rmpPaint === 'function' && document.getElementById('mppPianoRm')){ rmpPaint(); fatto = true; }
  if (typeof STN !== 'undefined' && STN.tab === 'cal' && typeof mfRidisegna === 'function'){ mfRidisegna(true); fatto = true; }
  if (!fatto) return;
  const s2 = calScrollVisibile(); if (s2 && top != null && CAL.scrollChiave === s2.getAttribute('data-k')) s2.scrollTop = top;
}
/** I giorni che la vista mostra: uno, o tre a partire dal giorno scelto (0.9.286: prima erano i sette da lunedi'). */
function calGiorniVista(v){
  const g = calMezzanotte(calGiornoOra());
  if (v === 'giorno') return [g];
  return [g, calPiuGiorni(g, 1), calPiuGiorni(g, 2)];
}
function calSposta(n){
  const v = calVistaOra();
  CAL.giorno = n === 0 ? calMezzanotte(new Date()) : calPiuGiorni(calGiornoOra(), n * (v === 'settimana' ? 3 : 1));
  try{ flVibra(6); }catch(_){ }
  calRidisegna();
}
function calApriGiorno(iso){ CAL.giorno = calDaIso(iso); CAL.vista = 'giorno'; try{ localStorage.setItem('fl_cal_vista', 'giorno'); }catch(_){ } try{ flVibra(6); }catch(_){ } calRidisegna(); }
function calTitolo(v, giorni){
  const a = giorni[0], b = giorni[giorni.length - 1];
  /* 0.9.317, Andrea: "ci deve essere Oggi, se torni indietro Ieri, poi lunedi' 2 novembre" */
  if (v === 'giorno'){
    const diff = Math.round((calMezzanotte(a).getTime() - calMezzanotte(new Date()).getTime()) / 86400000);
    if (diff === 0) return 'Oggi';
    if (diff === -1) return 'Ieri';
    if (diff === 1) return 'Domani';
    return CAL_GIORNI[a.getDay()] + ' ' + a.getDate() + ' ' + CAL_MESI[a.getMonth()];
  }
  const anno = b.getFullYear() === new Date().getFullYear() ? '' : ' ' + b.getFullYear();
  if (a.getMonth() === b.getMonth()) return a.getDate() + '-' + b.getDate() + ' ' + CAL_MESI[a.getMonth()] + anno;
  return a.getDate() + ' ' + CAL_MESI[a.getMonth()].slice(0, 3) + ' - ' + b.getDate() + ' ' + CAL_MESI[b.getMonth()].slice(0, 3) + anno;
}
/** Gli eventi di un giorno quando si accavallano, come Google Calendar (0.9.304, Andrea: "su Google Calendar uno compare
    sopra l'altro; tu invece stringi il turno e non si legge piu'").
    - Due eventi che partono quasi insieme (meno di 15 minuti di distanza) stanno uno accanto all'altro, a colonne.
    - Un evento che parte DOPO, dentro un altro gia' cominciato, gli si appoggia sopra: largo quasi quanto la colonna,
      spostato di poco a destra (CAL_RIENTRO px per livello), e quello sotto resta largo e leggibile. */
const CAL_VICINI_MIN = 15, CAL_RIENTRO = 12;
function calDisponi(evs){
  evs.sort(function(a, b){ return a.s - b.s || b.e - a.e; });
  const gruppi = [];
  evs.forEach(function(ev){
    let g = null;
    for (let i = gruppi.length - 1; i >= 0; i--){ const x = gruppi[i]; if (ev.s - x.s0 < CAL_VICINI_MIN && x.fine > ev.s){ g = x; break; } }
    if (!g){
      let liv = -1;
      gruppi.forEach(function(x){ if (x.fine > ev.s) liv = Math.max(liv, x.liv); });
      g = { s0: ev.s, fine: ev.eVis, liv: liv + 1, evs: [] };
      gruppi.push(g);
    }
    g.evs.push(ev); g.fine = Math.max(g.fine, ev.eVis);
  });
  gruppi.forEach(function(g){
    const colonne = [];
    g.evs.forEach(function(ev){
      let c = colonne.findIndex(function(f){ return f <= ev.s; });
      if (c < 0){ c = colonne.length; colonne.push(0); }
      colonne[c] = ev.eVis; ev.col = c;
    });
    g.evs.forEach(function(ev){ ev.ncol = colonne.length; ev.liv = g.liv; });
  });
  return evs;
}
function calGrigliaHtml(v){
  const giorni = calGiorniVista(v), oggi = calMezzanotte(new Date()).getTime();
  const da = giorni[0].getTime(), a = calPiuGiorni(giorni[giorni.length - 1], 1).getTime();
  const evs = calEventiTra(da, a);
  CAL.mappa = {}; evs.forEach(function(e){ CAL.mappa[e.id] = e; });
  const sett = v === 'settimana';
  /* la testa: il periodo al centro, le frecce ai suoi lati (0.9.317: niente pulsante "Oggi") */
  let h = '<div class="cal-v cal-' + v + '">'
    + '<div class="cal-h">'
    + '<button type="button" class="cal-nav" onclick="calSposta(-1)" aria-label="' + (sett ? 'I tre giorni prima' : 'Giorno prima') + '">' + calIco(CAL_I.sx) + '</button>'
    + '<b>' + calTitolo(v, giorni) + '</b>'
    + '<button type="button" class="cal-nav" onclick="calSposta(1)" aria-label="' + (sett ? 'I tre giorni dopo' : 'Giorno dopo') + '">' + calIco(CAL_I.dx) + '</button>'
    + '</div>';
  /* in Settimana, i tre giorni: si toccano per aprire quel giorno */
  if (sett){
    h += '<div class="cal-gh"><i></i>' + giorni.map(function(d){
      const iso = calIso(d);
      return '<button type="button" class="cal-gd' + (d.getTime() === oggi ? ' oggi' : '') + '" onclick="calApriGiorno(\'' + iso + '\')" aria-label="Apri ' + CAL_GIORNI[d.getDay()] + ' ' + d.getDate() + '"><span>' + CAL_GBREVI[d.getDay()] + '</span><b>' + d.getDate() + '</b></button>';
    }).join('') + '</div>';
  }
  /* gli eventi di tutto il giorno, in una riga sopra agli orari */
  const interi = giorni.map(function(d){
    const s = d.getTime(), e = calPiuGiorni(d, 1).getTime();
    return evs.filter(function(x){ return x.tuttoIlGiorno && x.inizio < e && x.fine > s; });
  });
  if (interi.some(function(l){ return l.length; })){
    h += '<div class="cal-td">' + (sett ? '<i></i>' : '<i class="cal-td-l">Tutto il giorno</i>') + interi.map(function(l){
      return '<div>' + l.map(function(x){ return '<button type="button" class="cal-chip" style="background:' + x.colore + ';color:' + calInchiostro(x.colore) + '" onclick="calApriEvento(\'' + calAttr(x.id) + '\')">' + esc(x.titolo) + '</button>'; }).join('') + '</div>';
    }).join('') + '</div>';
  }
  /* la griglia delle ore */
  let ore = '';
  for (let i = 1; i < 24; i++) ore += '<span style="top:' + (i * CAL_H) + 'px">' + String(i).padStart(2, '0') + ':00</span>';
  const ora = new Date(), minOra = ora.getHours() * 60 + ora.getMinutes();
  const cols = giorni.map(function(d){
    const s = d.getTime(), e = calPiuGiorni(d, 1).getTime(), iso = calIso(d), eOggi = s === oggi;
    const suoi = evs.filter(function(x){ return !x.tuttoIlGiorno && x.inizio < e && x.fine > s; }).map(function(x){
      const sMin = Math.max(0, (x.inizio - s) / 60000), eMin = Math.min(1440, (x.fine - s) / 60000);
      return { ev: x, s: sMin, e: eMin, eVis: Math.max(eMin, sMin + 22) };
    });
    calDisponi(suoi);
    calColoriVicini(suoi);
    /* 0.9.306, Andrea: "gli eventi sovrapposti mostrano solo 21:25 - 21:40 e non il titolo". Nel riquadro basso il titolo
       e l'ora stavano in riga e l'ora (che non va a capo) si mangiava tutto lo spazio. Adesso si legge PRIMA il titolo:
       negli eventi brevi una riga sola "Titolo · 21:25", negli altri il titolo e sotto l'orario, se c'e' spazio. */
    const blocchi = suoi.map(function(p){
      const x = p.ev, alto = Math.max(20, (p.e - p.s) * CAL_H / 60 - 2), rientro = (p.liv || 0) * CAL_RIENTRO;
      const corto = alto < 34, medio = !corto && alto < 64, tit = esc(calTitoloVis(x));
      const corpo = corto ? '<span class="cal-ev-1"><b>' + tit + '</b> · ' + calOraBreve(x.inizio) + '</span>'
        : '<b>' + tit + '</b><small>' + calOraBreve(x.inizio) + ' - ' + calOraBreve(x.fine) + '</small>';
      return '<button type="button" class="cal-ev' + (x.fonte === 'telefono' ? ' tel' : '') + (corto ? ' corto' : '') + (medio ? ' medio' : '') + (p.vicini ? ' vicino' : '') + (p.colore === '#14234A' ? ' notte' : '') + '" style="top:' + (p.s * CAL_H / 60) + 'px;height:' + alto + 'px;left:calc(' + rientro + 'px + (100% - ' + rientro + 'px) * ' + (p.col / p.ncol).toFixed(4) + ' + 1px);width:calc((100% - ' + rientro + 'px) / ' + p.ncol + ' - 3px);z-index:' + (1 + (p.liv || 0)) + ';background:' + p.colore + ';color:' + calInchiostro(p.colore) + '" onclick="event.stopPropagation();calApriEvento(\'' + calAttr(x.id) + '\')" aria-label="' + tit + ', dalle ' + calOraBreve(x.inizio) + ' alle ' + calOraBreve(x.fine) + '">'
        + corpo + '</button>';
    }).join('');
    const linea = eOggi ? '<div class="cal-adesso" style="top:' + (minOra * CAL_H / 60) + 'px"></div>' : '';
    return '<div class="cal-col' + (eOggi && sett ? ' oggi' : '') + '" data-iso="' + iso + '" onclick="calToccaVuoto(event,this)">' + blocchi + linea + '</div>';
  }).join('');
  const chiave = v + '|' + calIso(giorni[0]);
  h += '<div class="cal-scroll" data-k="' + chiave + '"><div class="cal-corpo" style="height:' + (24 * CAL_H) + 'px"><div class="cal-ore">' + ore + '</div><div class="cal-cols">' + cols + '</div></div></div>';
  if (!sett && !evs.length) h += '<p class="cal-vuoto">Tocca un orario o il + per aggiungere un evento.</p>';
  return h + '</div>';
}
/** Dopo il disegno (mfDopo): la griglia parte vicino all'ora di adesso, la prima volta che si apre. */
function calDopo(){
  const s = calScrollVisibile(); if (!s) return;
  const k = s.getAttribute('data-k');
  if (CAL.scrollChiave !== k){
    CAL.scrollChiave = k;
    const ora = new Date(), conOggi = !!s.querySelector('.cal-adesso');
    s.scrollTop = conOggi ? Math.max(0, (ora.getHours() - 1) * CAL_H) : 8 * CAL_H - 8;
  }
  if (!CAL.timer) CAL.timer = setInterval(function(){
    const l = document.querySelectorAll('.cal-adesso'); if (!l.length) return;
    const o = new Date(), m = o.getHours() * 60 + o.getMinutes();
    l.forEach(function(x){ x.style.top = (m * CAL_H / 60) + 'px'; });
  }, 60000);
}
/** Un tocco su un orario vuoto: l'evento nuovo parte da quella mezz'ora. */
function calToccaVuoto(e, col){
  const r = col.getBoundingClientRect(); const y = e.clientY - r.top;
  const min = Math.max(0, Math.min(23 * 60 + 30, Math.floor((y / CAL_H) * 2) * 30));
  const d = calDaIso(col.getAttribute('data-iso'));
  try{ flVibra(8); }catch(_){ }
  calForm(null, d.getTime() + min * 60000);
}
function calNuovo(){
  const v = calVistaOra(), oggi = calMezzanotte(new Date());
  const giorni = calGiorniVista(v);
  let d = giorni[0];
  if (giorni.some(function(x){ return x.getTime() === oggi.getTime(); })) d = oggi;
  let inizio;
  if (d.getTime() === oggi.getTime()){ const o = new Date(); o.setSeconds(0, 0); const m = o.getMinutes(); o.setMinutes(m < 30 ? 30 : 60); inizio = o.getTime(); }
  else inizio = d.getTime() + 9 * 3600000;
  calForm(null, inizio);
}
function calApriEvento(id){
  const ev = CAL.mappa[id] || calEventi().find(function(x){ return calAttr(x.id) === id; });
  if (!ev) return;
  try{ flVibra(6); }catch(_){ }
  if (ev.fonte === 'telefono') calTelefonoMostra(ev); else calForm(ev);
}

/* ---------- il foglio che sale dal basso ---------- */
function calFoglio(html, cls){
  const vecchio = document.getElementById('calVelo'); if (vecchio) vecchio.remove();
  const v = document.createElement('div'); v.id = 'calVelo'; v.className = 'cal-velo';
  v.innerHTML = '<div class="cal-foglio ' + (cls || '') + '" role="dialog" aria-modal="true">' + html + '</div>';
  v.addEventListener('click', function(e){ if (e.target === v) calChiudi(); });
  document.body.appendChild(v);
  requestAnimationFrame(function(){ v.classList.add('su'); });
  return v;
}
function calChiudi(){ const v = document.getElementById('calVelo'); if (v) v.remove(); CAL.form = null; }
/** Il tasto indietro di Android chiude il foglio aperto (nav.js). */
function calBack(){ if (document.getElementById('calVelo')){ calChiudi(); return true; } return false; }
function calTesta(titolo){ return '<div class="cal-f-h"><b>' + titolo + '</b><button type="button" class="cal-tondo" onclick="calChiudi()" aria-label="Chiudi">' + calIco(CAL_I.x, 20) + '</button></div>'; }

/* ---------- Nuovo evento / Modifica evento ---------- */
function calForm(ev, inizio){
  const nuovo = !ev;
  const s = nuovo ? inizio : ev.inizio, f = nuovo ? inizio + 30 * 60000 : ev.fine;
  CAL.form = { id: nuovo ? '' : ev.id, durata: Math.max(5, Math.round((f - s) / 60000)), colore: nuovo ? '#0075E3' : ev.colore, chiamata: nuovo ? calChiamataGlobale() : !!ev.chiamata, importante: nuovo ? false : !!ev.importante, togli: false };
  const g = calGcal();
  const dove = calCollegato() ? '<p class="cal-f-nota">' + calIco(CAL_I.cal, 15) + 'Lo scrivo anche in Google Calendar, in "' + esc(calNomeCal(g.scrivi)) + '".</p>' : '';
  const colori = CAL_COLORI.map(function(c){
    return '<button type="button" class="cal-col-c' + (c[0] === CAL.form.colore ? ' on' : '') + '" data-c="' + c[0] + '" style="background:' + c[0] + ';color:' + calInchiostro(c[0]) + '" onclick="calFormColore(\'' + c[0] + '\')" aria-label="' + c[1] + '">' + calIco(CAL_I.ok, 16) + '</button>';
  }).join('');
  const html = calTesta(nuovo ? 'Nuovo evento' : 'Modifica evento')
    + '<label class="cal-f-l" for="calFTit">Titolo</label>'
    + '<input id="calFTit" class="cal-in" type="text" maxlength="120" placeholder="Cosa farai?" value="' + (nuovo ? '' : esc(ev.titolo)) + '" autocomplete="off">'
    + '<label class="cal-f-l" for="calFData">Data</label>'
    + '<input id="calFData" class="cal-in" type="date" value="' + calIso(s) + '">'
    + '<div class="cal-f-ore"><div><label class="cal-f-l" for="calFDa">Dalle</label><input id="calFDa" class="cal-in" type="time" step="300" value="' + calHHMM(s) + '" oninput="calFormInizio()"></div>'
    + '<div><label class="cal-f-l" for="calFA">Alle</label><input id="calFA" class="cal-in" type="time" step="300" value="' + calHHMM(f) + '" oninput="calFormFine()"></div></div>'
    + '<p class="cal-f-durata" id="calFDurata">Durata: ' + calDurata(CAL.form.durata) + '</p>'
    + '<label class="cal-f-l" for="calFDescr">Descrizione</label>'
    + '<textarea id="calFDescr" class="cal-in" rows="2" placeholder="Note per te (facoltativo)">' + (nuovo ? '' : esc(ev.descr)) + '</textarea>'
    + '<span class="cal-f-l">Colore</span><div class="cal-colori">' + colori + '</div>'
    + '<div class="cal-f-riga"><div><b>Chiamata dei sogni all\'inizio</b><small>Quando l\'evento comincia, DreamMap ti chiama.</small></div>'
    + '<button type="button" class="switch' + (CAL.form.chiamata ? ' on' : '') + '" id="calFChiama" onclick="calFormChiamata()" aria-label="Chiamata dei sogni all\'inizio" aria-pressed="' + CAL.form.chiamata + '"></button></div>'
    + '<div class="cal-f-riga"><div><b>Data importante del mese</b><small>La vedi in cima alla scheda Sogno per tutto il mese.</small></div>'
    + '<button type="button" class="switch' + (CAL.form.importante ? ' on' : '') + '" id="calFImp" onclick="calFormImportante()" aria-label="Data importante del mese" aria-pressed="' + CAL.form.importante + '"></button></div>'
    + dove
    + '<button type="button" class="cal-btn" onclick="calFormSalva()">' + (nuovo ? 'Aggiungi evento' : 'Salva le modifiche') + '</button>'
    + (nuovo ? '' : '<button type="button" class="cal-btn-via" id="calFVia" onclick="calFormTogli()">' + calIco(CAL_I.cestino, 18) + 'Elimina evento</button>');
  calFoglio(html);
  if (nuovo) setTimeout(function(){ const t = document.getElementById('calFTit'); if (t) t.focus(); }, 120);
}
function calNomeCal(c){ if (!c) return ''; return c.nome && c.nome !== c.account ? c.nome : 'Calendario principale'; }
function calMinuti(v){ const p = String(v || '').split(':'); return p.length >= 2 ? (+p[0]) * 60 + (+p[1]) : NaN; }
function calFormDurataPaint(){
  const a = calMinuti((document.getElementById('calFDa') || {}).value), b = calMinuti((document.getElementById('calFA') || {}).value);
  const el = document.getElementById('calFDurata'); if (!el || isNaN(a) || isNaN(b)) return;
  let d = b - a; if (b === 0 && a > 0) d = 1440 - a;
  if (d <= 0){ el.textContent = 'L\'ora di fine deve venire dopo l\'inizio'; el.classList.add('male'); return; }
  CAL.form.durata = d; el.textContent = 'Durata: ' + calDurata(d); el.classList.remove('male');
}
/** Cambiando l'inizio la durata resta quella: si sposta anche la fine. */
function calFormInizio(){
  const da = document.getElementById('calFDa'), a = document.getElementById('calFA'); if (!da || !a || !CAL.form) return;
  const m = calMinuti(da.value); if (isNaN(m)) return;
  const f = Math.min(1440, m + CAL.form.durata) % 1440;
  a.value = String(Math.floor(f / 60)).padStart(2, '0') + ':' + String(f % 60).padStart(2, '0');
  calFormDurataPaint();
}
function calFormFine(){ calFormDurataPaint(); }
function calFormColore(c){
  if (!CAL.form) return; CAL.form.colore = c; try{ flVibra(6); }catch(_){ }
  document.querySelectorAll('.cal-col-c').forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-c') === c); });
}
function calFormChiamata(){
  if (!CAL.form) return; CAL.form.chiamata = !CAL.form.chiamata; try{ flVibra(8); }catch(_){ }
  const b = document.getElementById('calFChiama'); if (b){ b.classList.toggle('on', CAL.form.chiamata); b.setAttribute('aria-pressed', CAL.form.chiamata); }
}
function calFormImportante(){
  if (!CAL.form) return; CAL.form.importante = !CAL.form.importante; try{ flVibra(8); }catch(_){ }
  const b = document.getElementById('calFImp'); if (b){ b.classList.toggle('on', CAL.form.importante); b.setAttribute('aria-pressed', CAL.form.importante); }
}
function calFormSalva(){
  if (!CAL.form) return;
  const tit = String((document.getElementById('calFTit') || {}).value || '').trim();
  if (!tit){ try{ toast('Scrivi il titolo dell\'evento'); }catch(_){ } const t = document.getElementById('calFTit'); if (t){ t.focus(); t.classList.add('male'); } return; }
  const d = calDaIso((document.getElementById('calFData') || {}).value);
  const a = calMinuti((document.getElementById('calFDa') || {}).value), b = calMinuti((document.getElementById('calFA') || {}).value);
  if (isNaN(a) || isNaN(b)){ try{ toast('Scegli l\'ora di inizio e di fine'); }catch(_){ } return; }
  let fineMin = b; if (b === 0 && a > 0) fineMin = 1440;
  if (fineMin <= a){ try{ toast('L\'ora di fine deve venire dopo l\'inizio'); }catch(_){ } return; }
  const inizio = d.getTime() + a * 60000;
  const fine = calPiuGiorni(d, 0).getTime() + fineMin * 60000;
  const prima = CAL.form.id ? calEventi().find(function(x){ return x.id === CAL.form.id; }) : null;
  const ev = calSalvaEvento({ id: CAL.form.id || undefined, titolo: tit, inizio: inizio, fine: fine, descr: String((document.getElementById('calFDescr') || {}).value || '').trim(), colore: CAL.form.colore, chiamata: CAL.form.chiamata, importante: !!CAL.form.importante, gcal: prima ? prima.gcal : undefined, creato: prima ? prima.creato : undefined });
  try{ flVibra(14); }catch(_){ }
  calChiudi();
  /* l'evento salvato si vede: la vista va sul suo giorno */
  const v = calVistaOra();
  if (v !== 'mese'){ const gv = calGiorniVista(v); const g0 = calMezzanotte(ev.inizio).getTime(); if (!gv.some(function(x){ return x.getTime() === g0; })) CAL.giorno = calMezzanotte(ev.inizio); }
  try{ toast(prima ? 'Evento aggiornato' : 'Evento aggiunto'); }catch(_){ }
  calRidisegna();
}
/** Elimina in due tocchi: il primo chiede conferma sul pulsante stesso. */
function calFormTogli(){
  if (!CAL.form || !CAL.form.id) return;
  const b = document.getElementById('calFVia');
  if (!CAL.form.togli){ CAL.form.togli = true; if (b){ b.classList.add('conferma'); b.innerHTML = calIco(CAL_I.cestino, 18) + 'Tocca ancora per eliminarlo'; } try{ flVibra(10); }catch(_){ } return; }
  calEliminaEvento(CAL.form.id);
  try{ flVibra(14); }catch(_){ }
  calChiudi();
  try{ toast('Evento eliminato'); }catch(_){ }
  calRidisegna();
}
/** Un evento del calendario del telefono: si guarda qui, si cambia da Google Calendar. */
function calTelefonoMostra(ev){
  const d = new Date(ev.inizio);
  const quando = CAL_GIORNI[d.getDay()] + ' ' + d.getDate() + ' ' + CAL_MESI[d.getMonth()] + (ev.tuttoIlGiorno ? ', tutto il giorno' : ', dalle ' + calOraBreve(ev.inizio) + ' alle ' + calOraBreve(ev.fine));
  /* 0.9.276, Andrea: "troppe cose insieme, tutte attaccate". Titolo, quando, e basta; la descrizione si apre
     se uno la vuole leggere, il calendario d'origine sta in fondo, piccolo. Aria fra le parti. */
  const descr = String(ev.descr || '').trim();
  calFoglio(calTesta(esc(ev.titolo))
    + '<div class="cal-tel"><i style="background:' + esc(ev.colore) + '"></i><b>' + quando + '</b></div>'
    + (descr ? '<button type="button" class="cal-tel-apri" onclick="this.hidden=true;this.nextElementSibling.hidden=false">Leggi la descrizione</button>'
      + '<p class="cal-tel-d" hidden>' + esc(descr).replace(/\n+/g, '<br><br>') + '</p>' : '')
    + '<button type="button" class="cal-btn cal-tel-ok" onclick="calChiudi()">Ho capito</button>'
    + '<p class="cal-f-nota cal-tel-nota">' + calIco(CAL_I.telefono, 14) + 'Si modifica da Google Calendar</p>');
}

/* ---------- Impostazioni del calendario ---------- */
function calImpApri(){
  try{ flVibra(6); }catch(_){ }
  calFoglio(calImpHtml(), 'cal-imp');
  /* se e' collegato rilegge i calendari: se il permesso e' stato tolto, lo dice */
  if (calNativo() && calGcal().collegato && typeof calN().calendarioElenco === 'function'){
    calN().calendarioElenco().then(function(r){ CAL.calendari = (r && r.calendari) || []; calImpPaint(); }, function(e){
      if (e && e.code === 'permission'){ const g = calGcal(); g.collegato = false; calGcalSalva(g); }
      calImpPaint();
    });
  }
}
function calImpPaint(){ const f = document.querySelector('#calVelo .cal-imp'); if (f) f.innerHTML = calImpHtml(); }
function calImpHtml(){
  const g = calGcal(), coll = calCollegato();
  let h = calTesta('Impostazioni del calendario');
  const solo = calSoloDm();
  h += '<div class="cal-sez"><div class="cal-f-riga"><div><b>Solo le cose di DreamMap</b><small>Nasconde gli impegni del calendario del telefono. Restano le cose programmate in DreamMap e i tuoi turni.</small></div>'
    + '<button type="button" class="switch' + (solo ? ' on' : '') + '" onclick="calSoloDmCambia(this)" aria-label="Solo le cose di DreamMap" aria-pressed="' + solo + '"></button></div></div>';
  if (calNativo()){
    h += '<div class="cal-sez"><div class="cal-sez-h">' + calIco(CAL_I.cal, 20) + '<b>Collega a Google Calendar</b></div>'
      + '<p class="cal-stato' + (coll ? ' on' : '') + '">' + (coll ? 'Collegato a ' + esc(g.scrivi.account || '') + ' · ' + esc(calNomeCal(g.scrivi)) : 'Non collegato') + '</p>';
    if (!coll){
      h += '<p class="cal-sez-t">DreamMap usa il calendario del telefono, quello che Google Calendar tiene allineato con il tuo account. Non serve nessuna password: il telefono ti chiede solo il permesso.</p>'
        + '<button type="button" class="cal-btn" onclick="calCollega()">Collega</button>';
    } else {
      const lista = CAL.calendari || [];
      const scrivibili = lista.filter(function(c){ return c.scrivibile; });
      if (lista.length){
        h += '<p class="cal-f-l">Dove scrivo i nuovi eventi</p><div class="cal-lista">' + scrivibili.map(function(c){
          const on = String(c.id) === String(g.scrivi.id);
          return '<button type="button" class="cal-cal' + (on ? ' on' : '') + '" onclick="calScegliScrivi(\'' + calAttr(c.id) + '\')"><i style="background:' + esc(c.colore) + '"></i><span><b>' + esc(calNomeCal(c)) + '</b><small>' + esc(c.account) + '</small></span><em class="cal-radio' + (on ? ' on' : '') + '"></em></button>';
        }).join('') + '</div>'
          + '<p class="cal-f-l">Quali calendari vedo in Giorno e Settimana</p><div class="cal-lista">' + lista.map(function(c){
          const on = (g.mostra || []).map(String).indexOf(String(c.id)) >= 0;
          return '<button type="button" class="cal-cal" onclick="calScegliMostra(\'' + calAttr(c.id) + '\')"><i style="background:' + esc(c.colore) + '"></i><span><b>' + esc(calNomeCal(c)) + '</b><small>' + esc(c.account) + '</small></span><em class="cal-spunta' + (on ? ' on' : '') + '">' + (on ? calIco(CAL_I.ok, 14) : '') + '</em></button>';
        }).join('') + '</div>';
      } else {
        h += '<p class="cal-sez-t">Sto leggendo i calendari del telefono...</p>';
      }
      h += '<button type="button" class="cal-btn-2" onclick="calScollega()">Scollega</button>';
    }
    h += '</div>';
  }
  /* 0.9.302: il promemoria della tappa di ogni giorno (ritmo.js) si guarda e si prova da qui, quando vuoi */
  if (calNativo() && typeof ritmoApri === 'function'){
    h += '<div class="cal-sez"><div class="cal-sez-h">' + calIco(CAL_I.cal, 20) + '<b>Il promemoria della tappa</b></div>'
      + '<p class="cal-sez-t">Ogni giorno, all’ora che scegli, il calendario del telefono ti ricorda la tappa di DreamMap. Da qui vedi a che ora suona e puoi fare una prova.</p>'
      + '<button type="button" class="cal-btn" onclick="ritmoApri()">Apri il promemoria della tappa</button></div>';
  }
  const on = calChiamataGlobale();
  h += '<div class="cal-sez"><div class="cal-f-riga"><div><b>Chiamata dei sogni quando inizia un evento</b><small>Vale per gli eventi nuovi. In ogni evento puoi accenderla o spegnerla.</small></div>'
    + '<button type="button" class="switch' + (on ? ' on' : '') + '" onclick="calImpChiamata(this)" aria-label="Chiamata dei sogni quando inizia un evento" aria-pressed="' + on + '"></button></div></div>';
  return h;
}
function calImpChiamata(b){
  const on = !calChiamataGlobale(); calChiamataGlobaleSet(on); try{ flVibra(8); }catch(_){ }
  b.classList.toggle('on', on); b.setAttribute('aria-pressed', on);
}
function calCollega(){
  if (!calNativo() || typeof calN().calendarioCollega !== 'function') return;
  try{ flVibra(8); }catch(_){ }
  calN().calendarioCollega().then(function(r){
    const lista = (r && r.calendari) || [];
    CAL.calendari = lista;
    const scr = lista.filter(function(c){ return c.scrivibile; });
    if (!scr.length){ try{ toast('Sul telefono non c\'è un calendario in cui scrivere. Aggiungi il tuo account Google al telefono e riprova.'); }catch(_){ } calImpPaint(); return; }
    /* di base: il calendario principale di Google; si vedono quelli che il telefono gia' mostra */
    const scelto = scr.filter(function(c){ return c.google && c.principale; })[0] || scr.filter(function(c){ return c.google; })[0] || scr[0];
    const mostra = lista.filter(function(c){ return c.visibile; }).map(function(c){ return c.id; });
    if (mostra.map(String).indexOf(String(scelto.id)) < 0) mostra.push(scelto.id);
    calGcalSalva({ collegato: true, scrivi: { id: scelto.id, nome: scelto.nome, account: scelto.account, colore: scelto.colore }, mostra: mostra });
    try{ toast('Collegato a Google Calendar'); }catch(_){ }
    calImpPaint(); calRidisegna();
  }, function(e){
    try{ toast(e && e.code === 'permission' ? 'Senza il permesso del calendario non posso collegarlo. Puoi riprovare quando vuoi.' : 'Non sono riuscito a leggere i calendari del telefono.'); }catch(_){ }
    calImpPaint();
  });
}
function calScegliScrivi(id){
  const c = (CAL.calendari || []).find(function(x){ return calAttr(x.id) === id; }); if (!c) return;
  const g = calGcal(); g.scrivi = { id: c.id, nome: c.nome, account: c.account, colore: c.colore };
  g.mostra = g.mostra || []; if (g.mostra.map(String).indexOf(String(c.id)) < 0) g.mostra.push(c.id);
  calGcalSalva(g); try{ flVibra(6); }catch(_){ } calImpPaint(); calRidisegna();
}
function calScegliMostra(id){
  const c = (CAL.calendari || []).find(function(x){ return calAttr(x.id) === id; }); if (!c) return;
  const g = calGcal(); const l = (g.mostra || []).map(String), i = l.indexOf(String(c.id));
  g.mostra = (g.mostra || []).filter(function(x){ return String(x) !== String(c.id); });
  if (i < 0) g.mostra.push(c.id);
  calGcalSalva(g); try{ flVibra(6); }catch(_){ } calImpPaint(); calRidisegna();
}
function calScollega(){
  const g = calGcal(); g.collegato = false; calGcalSalva(g);
  try{ flVibra(8); }catch(_){ } try{ toast('Scollegato. Gli eventi di DreamMap restano qui.'); }catch(_){ }
  calImpPaint(); calRidisegna();
}

/* tornando nell'app (magari dopo aver cambiato qualcosa in Google Calendar) si rilegge il telefono */
document.addEventListener('visibilitychange', function(){
  if (document.visibilityState !== 'visible') return;
  CAL.tel.t = 0;
  if (calScrollVisibile()) calRidisegna();
});

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.cal-barra{display:flex;align-items:center;gap:8px;margin:0 0 10px}',
    '.cal-spazio{flex:1}',
    '.cal-vw{position:relative;flex:none}',
    '.cal-vista-b{display:flex;align-items:center;gap:2px;height:38px;padding:0 8px 0 10px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--navy);cursor:pointer}',
    '.cal-vista-b svg:last-child{opacity:.7}',
    '.cal-vm{position:absolute;left:0;top:44px;z-index:40;width:250px;max-width:calc(100vw - 48px);padding:6px;border-radius:16px;background:var(--card);border:1px solid var(--line);box-shadow:0 14px 36px rgba(14,35,80,.22);animation:calVm .14s ease-out}',
    '@keyframes calVm{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}',
    '.cal-vm button{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;border-radius:11px;padding:10px 10px;text-align:left;cursor:pointer;color:var(--navy)}',
    '.cal-vm button span{flex:1;min-width:0}.cal-vm b{display:block;font:700 15px var(--font-body);color:var(--navy)}.cal-vm small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.cal-vm button.on{background:rgba(0,117,227,.1)}.cal-vm button.on svg{color:#0075E3}',
    'body.dark .cal-vm{box-shadow:0 14px 36px rgba(0,0,0,.45)}body.dark .cal-vm button.on{background:rgba(90,174,255,.16)}',
    '.cal-sett-b{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:14px 0 4px;padding:13px 16px;border:0;border-radius:14px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 4px 14px rgba(0,117,227,.28)}',
    '.cal-sett-b span{display:flex;flex-direction:column;align-items:flex-start;text-align:left}.cal-sett-b b{font:800 15px var(--font-body);color:#fff}.cal-sett-b small{margin-top:2px;font:600 12px var(--font-body);color:rgba(255,255,255,.85)}',
    '.cal-seg{flex:1;display:flex;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:3px;gap:2px}',
    '.cal-seg button{flex:1;border:0;background:transparent;border-radius:9px;padding:8px 2px;font:700 13px var(--font-body);color:var(--muted);cursor:pointer}',
    '.cal-seg button.on{background:#0075E3;color:#fff;box-shadow:0 2px 8px rgba(0,117,227,.28)}',
    '.cal-tondo{flex:none;width:38px;height:38px;border-radius:50%;border:1px solid var(--line);background:var(--card);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.cal-h{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;gap:4px;margin:2px 0 8px}',
    '.cal-h b{display:block;text-align:center;font:800 16px var(--font-body);color:var(--navy);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cal-h b::first-letter{text-transform:uppercase}',
    '.cal-nav{border:0;background:transparent;color:var(--navy);width:44px;height:44px;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center}',
    '.cal-piu{flex:none;width:38px;height:38px;padding:0;border:0;border-radius:50%;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 3px 10px rgba(0,117,227,.35)}',
    '.cal-gh,.cal-td{display:grid;grid-template-columns:42px repeat(3,1fr);align-items:center}',
    '.cal-giorno .cal-td{grid-template-columns:42px 1fr}',
    '.cal-gd{border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:2px;padding:2px 0 6px;cursor:pointer;font-family:var(--font-body)}',
    '.cal-gd span{font:600 11.5px var(--font-body);color:var(--muted)}',
    '.cal-gd b{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:700 14px var(--font-body);color:var(--navy)}',
    '.cal-gd.oggi span{color:#0075E3}.cal-gd.oggi b{background:#0075E3;color:#fff}',
    '.cal-td{border-top:1px solid var(--line);padding:4px 0}.cal-td>div{display:flex;flex-direction:column;gap:2px;min-width:0;padding:0 1px}',
    '.cal-td-l{font:600 10.5px var(--font-body);color:var(--muted);font-style:normal;line-height:1.15}',
    '.cal-chip{border:0;border-radius:6px;padding:3px 5px;font:700 11px var(--font-body);text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}',
    /* 0.9.308, Andrea: "arrivato alla fine (o all'inizio) della giornata lo scroll si ferma". Era overscroll-behavior:contain:
       al bordo della griglia il gesto non passava mai alla pagina. Adesso, finita la giornata, scorre la Mappa. */
    '.cal-scroll{height:min(60vh,520px);overflow-y:auto;scrollbar-width:thin;overscroll-behavior-y:auto;border-top:1px solid var(--line);-webkit-overflow-scrolling:touch}',
    '.cal-corpo{position:relative;display:flex}',
    '.cal-ore{position:relative;width:42px;flex:none}',
    '.cal-ore span{position:absolute;right:6px;transform:translateY(-50%);font:600 10.5px var(--font-body);color:var(--muted)}',
    '.cal-cols{flex:1;display:flex;position:relative;min-width:0}',
    '.cal-col{flex:1;min-width:0;position:relative;border-left:1px solid var(--line);background-image:repeating-linear-gradient(to bottom,var(--line) 0,var(--line) 1px,transparent 1px,transparent ' + CAL_H + 'px);cursor:pointer}',
    '.cal-col.oggi{background-color:rgba(0,117,227,.06)}',
    '.cal-ev{position:absolute;border:0;outline:1px solid var(--card,#fff);border-radius:7px;padding:3px 5px;text-align:left;overflow:hidden;display:flex;flex-direction:column;gap:1px;cursor:pointer;box-shadow:0 1px 3px rgba(15,32,65,.18);z-index:1}',
    '.cal-ev b{font:700 12px/1.2 var(--font-body);overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;word-break:break-word}',
    '.cal-ev small{font:600 10.5px var(--font-body);opacity:.9;white-space:nowrap}',
    '.cal-ev.corto{justify-content:center;padding:1px 6px}',
    '.cal-ev-1{display:block;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:600 11px/1.2 var(--font-body)}.cal-ev .cal-ev-1 b{display:inline;font:800 11px/1.2 var(--font-body);-webkit-line-clamp:unset}',
    '.cal-settimana .cal-ev{padding:3px 5px;border-radius:6px}.cal-settimana .cal-ev b{font-size:11.5px}.cal-settimana .cal-ev small{font-size:10px}.cal-settimana .cal-ev.corto{padding:1px 5px}',
    '.cal-ev.medio b{-webkit-line-clamp:1}.cal-settimana .cal-ev.medio b{-webkit-line-clamp:2}',
    /* 0.9.306: due eventi che si toccano o si accavallano hanno un bordo chiaro fra loro (e colori diversi, calColoriVicini) */
    '.cal-ev.vicino{outline:0;box-shadow:0 0 0 1.5px #fff,0 2px 6px rgba(15,32,65,.25)}body.dark .cal-ev.vicino{box-shadow:0 0 0 1.5px #DCE8F5,0 2px 6px rgba(0,0,0,.4)}body.dark .cal-ev.notte{outline:1.5px solid #8CC6FF;outline-offset:-1.5px}',
    '.cal-adesso{position:absolute;left:-1px;right:0;height:2px;background:#E63946;z-index:2;pointer-events:none}',
    '.cal-adesso::before{content:"";position:absolute;left:-5px;top:-4px;width:10px;height:10px;border-radius:50%;background:#E63946}',
    '.cal-vuoto{font:600 13px var(--font-body);color:var(--muted);text-align:center;margin:10px 0 2px}',
    /* il foglio */
    '.cal-velo{position:fixed;inset:0;z-index:9000;background:rgba(14,35,80,.45);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .18s}',
    '.cal-velo.su{opacity:1}',
    '.cal-foglio{width:100%;max-width:520px;max-height:92vh;overflow-y:auto;background:var(--card);color:var(--navy);border-radius:22px 22px 0 0;padding:16px 18px calc(22px + env(safe-area-inset-bottom));box-shadow:0 -10px 30px rgba(14,35,80,.25);transform:translateY(24px);transition:transform .2s}',
    '.cal-velo.su .cal-foglio{transform:none}',
    '.cal-f-h{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}.cal-f-h b{font:800 19px var(--font-body);color:var(--navy)}',
    '.cal-f-l{display:block;font:700 13px var(--font-body);color:var(--muted);margin:12px 0 5px}',
    '.cal-in{width:100%;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;background:var(--bg);color:var(--navy);font:600 16px var(--font-body);padding:11px 12px;outline:none;color-scheme:light}',
    'body.dark .cal-in,body.dark .cal-scroll{color-scheme:dark}',
    '.cal-in:focus{border-color:#0075E3}.cal-in.male{border-color:#E63946}',
    'textarea.cal-in{resize:vertical;min-height:58px;font-weight:500}',
    '.cal-f-ore{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.cal-f-durata{font:700 13.5px var(--font-body);color:#0075E3;margin:8px 0 0}.cal-f-durata.male{color:#E63946}',
    '.cal-colori{display:flex;flex-wrap:wrap;gap:8px}',
    '.cal-col-c{width:34px;height:34px;border-radius:50%;border:0;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.cal-col-c svg{opacity:0}.cal-col-c.on svg{opacity:1}.cal-col-c.on{box-shadow:0 0 0 3px var(--card),0 0 0 5px #0075E3}',
    '.cal-f-riga{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px}',
    '.cal-f-riga b{display:block;font:700 15px var(--font-body);color:var(--navy)}.cal-f-riga small{display:block;font:500 12.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.cal-f-nota{display:flex;align-items:center;gap:7px;font:600 12.5px var(--font-body);color:var(--muted);margin:14px 0 0}.cal-f-nota svg{flex:none}',
    '.cal-btn{width:100%;margin-top:16px;border:0;border-radius:14px;background:#0075E3;color:#fff;font:800 16px var(--font-body);padding:14px;cursor:pointer}',
    '.cal-btn-2{width:100%;margin-top:12px;border:1.5px solid var(--line);border-radius:14px;background:transparent;color:var(--navy);font:700 15px var(--font-body);padding:12px;cursor:pointer}',
    '.cal-btn-via{width:100%;margin-top:10px;border:0;background:transparent;color:#E63946;font:700 15px var(--font-body);padding:10px;display:flex;align-items:center;justify-content:center;gap:7px;cursor:pointer;border-radius:14px}',
    '.cal-btn-via.conferma{background:#E63946;color:#fff}',
    '.cal-sez{border:1px solid var(--line);border-radius:16px;padding:14px;margin-top:12px}',
    '.cal-sez .cal-f-riga{margin-top:0}',
    '.cal-sez-h{display:flex;align-items:center;gap:8px;color:#0075E3}.cal-sez-h b{font:800 16px var(--font-body);color:var(--navy)}',
    '.cal-stato{font:700 13.5px var(--font-body);color:var(--muted);margin:8px 0 0;word-break:break-word}.cal-stato.on{color:#16804A}body.dark .cal-stato.on{color:#4CD38A}',
    '.cal-sez-t{font:500 13.5px/1.45 var(--font-body);color:var(--muted);margin:8px 0 0}',
    '.cal-lista{display:flex;flex-direction:column;gap:2px}',
    '.cal-cal{display:flex;align-items:center;gap:10px;border:0;background:transparent;padding:9px 4px;text-align:left;cursor:pointer;border-radius:10px;color:var(--navy)}',
    '.cal-cal i{width:14px;height:14px;border-radius:4px;flex:none}',
    '.cal-cal span{flex:1;min-width:0}.cal-cal b{display:block;font:700 14px var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cal-cal small{display:block;font:500 12px var(--font-body);color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.cal-radio{width:20px;height:20px;border-radius:50%;border:2px solid var(--line);flex:none;box-sizing:border-box}.cal-radio.on{border:6px solid #0075E3}',
    '.cal-spunta{width:22px;height:22px;border-radius:6px;border:2px solid var(--line);flex:none;box-sizing:border-box;display:flex;align-items:center;justify-content:center;color:#fff}.cal-spunta.on{background:#0075E3;border-color:#0075E3}',
    '.cal-tel{display:flex;gap:12px;align-items:center;margin-top:14px}.cal-tel i{width:14px;height:14px;border-radius:4px;flex:none}',
    '.cal-tel b{display:block;font:700 15px var(--font-body);color:var(--navy)}.cal-tel b::first-letter{text-transform:uppercase}.cal-tel small{display:block;font:500 13px var(--font-body);color:var(--muted);margin-top:2px}',
    '.cal-tel-d{font:500 15px/1.55 var(--font-body);color:var(--navy);margin:24px 0 0;padding:16px;border-radius:16px;background:var(--bg)}'
    + '.cal-tel-apri{display:block;margin:24px 0 0;padding:0;border:0;background:none;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}'
    + '.cal-tel-ok{margin-top:32px}.cal-tel-nota{justify-content:center;margin:14px 0 4px}'
  ].join('\n');
  document.head.appendChild(st);
})();
