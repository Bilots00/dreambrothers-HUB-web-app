/* settings.js - the drawer and everything it opens: Impostazioni (redirect, motivational
   line, language, dark mode), Schermo di blocco (custom image + reason line), Invia feedback,
   Valuta l'app, Informazioni. Everything persistent about blocking lives in the engine
   (NATIVE.getSettings/setSettings); the web-only preferences (dark mode, language) live in
   localStorage. */

const APP_STORE_ID = 'com.dreambrothers.focuslock';
let SETTINGS = { redirectUrl: '', motivation: '', blockImage: '', usageToastMin: 0, lockStyle: 'base', bubbleEveryMin: 5, limitTab: true };
const BUBBLE_CHOICES = [[0,'Spenta'],[5,'Ogni 5 min'],[10,'Ogni 10 min'],[15,'Ogni 15 min']];
const GOAL_CHOICES = [[0,'Nessuno'],[60,'1 ora'],[90,'1h 30'],[120,'2 ore'],[180,'3 ore'],[240,'4 ore'],[300,'5 ore'],[360,'6 ore']];
function goalMin(){ try{ return +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ return 0; } }
/* Niente «Spento» fra le durate: accendere e spegnere e' un interruttore, non un tempo. */
const USAGE_TOAST_CHOICES = [[10,'10 min'],[15,'15 min'],[30,'30 min'],[60,'1 ora'],[120,'2 ore'],[-1,'Personalizzato…']];
/* Il tempo con cui riaccende chi non ne aveva mai scelto uno. */
const USAGE_TOAST_DEFAULT = 30;

/* ---------------- drawer ---------------- */
(function buildDrawer(){
  const wrap = document.createElement('div');
  wrap.className = 'drawer-wrap'; wrap.id = 'drawerWrap';
  wrap.innerHTML =
    '<div class="scrim" onclick="drawerClose()"></div>' +
    '<nav class="drawer">' +
      '<div class="brand"><div class="hlogo"><img src="icons/icon-192.png" alt="" style="width:100%;height:100%;display:block;border-radius:inherit"></div>' +
        '<div><b>DREAMMAP</b><small id="drawerPlan">Versione gratuita</small></div></div>' +
      '<button class="drow" onclick="drawerGo(\'s-personalize\')"><span class="ic">🎨</span>Personalizza<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerClose(); ffOpen()"><span class="ic">🌱</span>FullFocus<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerClose(); frOpen()"><span class="ic">👥</span>Amici<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerClose(); switchTab(\'insights\')"><span class="ic">📊</span>Report<span class="arr">→</span></button>' +
      /* IL MENU A PANINO E' L'INDICE VERO DELL'APP: la barra in basso ha quattro pulsanti e
         nessuno di quelli e' il Report. Una pagina che non compare qui, per chi la cerca, non
         esiste — ed e' andata esattamente cosi'. */
      '<button class="drow" onclick="drawerClose(); blPaginaApri()"><span class="ic">🛡️</span>Blocco<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerClose(); rateApp()"><span class="ic">⭐</span>Valuta l\'app<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerClose(); ufOpenBackup()"><span class="ic">☁️</span>Backup &amp; Ripristino<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerGo(\'s-feedback\')"><span class="ic">💬</span>Aiuto e feedback<span class="arr">→</span></button>' +
      '<button class="drow" onclick="drawerGo(\'s-settings\')"><span class="ic">⚙️</span>Impostazioni<span class="arr">→</span></button>' +
      '<div class="dsep"></div>' +
      '<div class="drow" onclick="toggleDark()"><span class="ic">🌙</span>Modalità scura<span class="sw" id="darkSw"></span></div>' +
    '</nav>';
  const phone = document.getElementById('phone'); (phone || document.body).appendChild(wrap);
})();
function drawerOpen(){ const w = document.getElementById('drawerWrap'); if(w){ w.classList.add('open'); refreshDrawerPlan(); } }
function drawerClose(){ const w = document.getElementById('drawerWrap'); if(w) w.classList.remove('open'); }
function drawerGo(id){ drawerClose(); if(id === 's-feedback'){ assistenzaApri(); return; } if(id === 's-inapp'){ inappOpen(); return; } if(id === 's-account'){ profileAuth(); return; } goId(id); if(id === 's-settings') settingsPaint(); if(id === 's-lockscreen') lockScreenPaint(); if(id === 's-personalize') personalizePaint(); }
function refreshDrawerPlan(){
  const p = document.getElementById('drawerPlan');
  if(p) p.textContent = (typeof Premium !== 'undefined' && Premium.isPremium()) ? 'Versione Premium' : 'Versione gratuita';
}

/* ---------------- dark mode ---------------- */
/* Three states, like the phone: on, off, follow the system. */
function darkMode(){ try{ return localStorage.getItem('fl_dark') || 'system'; }catch(_){ return 'system'; } }
function darkResolved(mode){
  if(mode === 'on') return true;
  if(mode === 'off') return false;
  try{ return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches; }catch(_){ return false; }
}
function applyDark(mode){
  if(mode === true) mode = 'on'; if(mode === false) mode = 'off';
  try{ localStorage.setItem('fl_dark', mode); }catch(_){ }
  const on = darkResolved(mode);
  document.body.classList.toggle('dark', on);
  const sw = document.getElementById('darkSw'); if(sw) sw.classList.toggle('on', on);
  document.querySelectorAll('input[name="darkmode"]').forEach(function(r){ r.checked = r.value === mode; });
  applyDarkNative(on);
  /* Il cambio di tema si annuncia: c'e' chi deve cambiare insieme a lui e non puo' farlo con
     un foglio di stile — le immagini delle diapositive, che sono due, una per tema. */
  try{ document.dispatchEvent(new CustomEvent('fl:tema', { detail: on })); }catch(_){ }
}
/* The native window behind the page follows: otherwise every strip the WebView is not
   painting yet (keyboard going away, a resize) flashes the light background over a dark UI. */
function applyDarkNative(on){
  try{ if(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setWindowTheme) NATIVE.setWindowTheme({ dark: !!on }).catch(function(){}); }catch(_){ }
}
function toggleDark(){ applyDark(document.body.classList.contains('dark') ? 'off' : 'on'); }
applyDark(darkMode());
setTimeout(function(){ applyDarkNative(document.body.classList.contains('dark')); }, 1200);
try{ window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(){ if(darkMode() === 'system') applyDark('system'); }); }catch(_){ }
function langMode(){ try{ return localStorage.getItem('fl_lang') || 'system'; }catch(_){ return 'system'; } }
/* Il primo giorno della settimana: 1 = lunedi' (Europa), 0 = domenica (Stati Uniti). Lo usano
   il calendario della serie e i grafici della settimana. */
function flWeekStart(){ try{ return localStorage.getItem('fl_week_start') === 'sun' ? 0 : 1; }catch(_){ return 1; } }
function setWeekStart(v){
  try{ localStorage.setItem('fl_week_start', v === 'sun' ? 'sun' : 'mon'); }catch(_){ }
  toast(v === 'sun' ? 'La settimana comincia di domenica' : 'La settimana comincia di lunedì');
  try{ if (typeof serPaint === 'function') serPaint(); }catch(_){ }
}
function setLang(v){ try{ localStorage.setItem('fl_lang', v); }catch(_){ } toast(v === 'system' ? 'Lingua: come il sistema (oggi italiano)' : 'Lingua: italiano'); }

/* ---------------- rate ---------------- */
function rateApp(){
  const market = 'market://details?id=' + APP_STORE_ID;
  const web = 'https://play.google.com/store/apps/details?id=' + APP_STORE_ID;
  try{
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App && NATIVE && NATIVE.openUrl){ NATIVE.openUrl({ url: market }); return; }
  }catch(_){ }
  if (typeof ufOpenUrl === 'function') ufOpenUrl(web); else window.open(web, '_blank');
}

/* ---------------- settings (engine-backed) ---------------- */
/* 0.9.288, Andrea: "i toggle si attivano solo al secondo tocco e me li ritrovo spenti". Una lettura dal motore
   partita PRIMA di un tocco (all'apertura della pagina, al ritorno in primo piano: getSettings e' lento) arrivava DOPO
   e rimetteva in memoria il valore vecchio; il tocco seguente partiva da li' e salvava il contrario. Adesso le chiavi
   salvate mentre la lettura era in corso non vengono sovrascritte. */
const SET_TOCCATE = {};
async function settingsLoad(){
  if(!NATIVE || !NATIVE.getSettings) return SETTINGS;
  const da = Date.now();
  try{
    const r = await NATIVE.getSettings();
    if(r){
      const fresco = Object.assign({}, r);
      Object.keys(SET_TOCCATE).forEach(function(k){ if (SET_TOCCATE[k] >= da) delete fresco[k]; });
      SETTINGS = Object.assign(SETTINGS, fresco);
    }
  }catch(_){ }
  return SETTINGS;
}
async function settingsSave(patch){
  Object.keys(patch || {}).forEach(function(k){ SET_TOCCATE[k] = Date.now(); });
  Object.assign(SETTINGS, patch || {});
  if(!NATIVE || !NATIVE.setSettings){ toast('Anteprima: le impostazioni valgono nell\'app installata'); return; }
  /* SOLO LA PATCH, mai l'oggetto intero.
     SETTINGS parte dai valori di fabbrica e si riempie dal motore solo aprendo una pagina
     impostazioni: un salvataggio partito da un'altra pagina rispediva `usageToastMin: 0`,
     `lockStyle: 'base'`, `bubbleEveryMin: 5` al posto dei valori scelti, e il messaggio del
     tempo totale tornava spento a ogni riavvio. Il motore unisce le patch da se'. */
  try{ await NATIVE.setSettings(Object.assign({}, patch || {})); toast('Impostazioni salvate'); }
  catch(e){ toast(e && e.message ? e.message : 'Non salvate'); }
}

registerScreen('s-settings',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">\u2039</button><b class="blk-title">Impostazioni</b></div>' +
  /* PRIMA LA LINGUA, POI L'ASPETTO.
     Sono le due cose che si cercano appena aperta questa pagina, e stavano in fondo: chi entra
     qui per mettere l'app in scuro non vuole leggersi tre pannelli sulle bolle. */
  '<div class="sect"><b>Lingua</b></div>' +
  '<label class="langrow"><input type="radio" name="lang" value="system" onchange="setLang(this.value)">Segue il sistema<small>oggi: italiano</small></label>' +
  '<label class="langrow"><input type="radio" name="lang" value="it" onchange="setLang(this.value)">Italiano</label>' +
  '<label class="langrow" style="opacity:.55"><input type="radio" name="lang" value="en" disabled>English<small>in arrivo</small></label>' +
  '<div class="sect" style="margin-top:18px"><b>Settimana</b></div>' +
  '<label class="langrow"><input type="radio" name="weekstart" value="mon" onchange="setWeekStart(this.value)">Comincia di lunedì</label>' +
  '<label class="langrow"><input type="radio" name="weekstart" value="sun" onchange="setWeekStart(this.value)">Comincia di domenica</label>' +
  '<div class="sect" style="margin-top:18px"><b>Aspetto</b></div>' +
  '<label class="langrow"><input type="radio" name="darkmode" value="system" onchange="applyDark(this.value)">Segue il sistema</label>' +
  '<label class="langrow"><input type="radio" name="darkmode" value="off" onchange="applyDark(this.value)">Chiaro</label>' +
  '<label class="langrow"><input type="radio" name="darkmode" value="on" onchange="applyDark(this.value)">Scuro</label>' +
  /* IL BIANCO E NERO NON C'ENTRA NIENTE CON LA PARTITA: e' un effetto sullo schermo, e sta
     accanto al tema chiaro/scuro, che e' l'altra cosa che cambia come si vede il telefono. */
  '<div class="sect" style="margin-top:22px"><b>Colore dello schermo</b></div>' +
  '<div class="setrow" onclick="grOpen()"><span>\ud83c\udf11</span><b>Bianco e nero selettivo</b><small id="stGreyLbl">\u2014</small><span class="chev"></span></div>' +
  /* E «La partita» resta una porta sola. L'aspetto del tabellone e' una regola della partita
     e sta dentro a quella pagina: due voci di seguito che portano a due pagine diverse sulla
     stessa cosa erano una scelta che nessuno ha chiesto di fare. */
  '<div class="sect" style="margin-top:22px"><b>La partita</b></div>' +
  '<div class="setrow" onclick="mgOpen()"><span>\ud83c\udfc6</span><b>Regole del gioco</b><small id="stMatchLbl">\u2014</small><span class="chev"></span></div>' +
  /* LA MODALITÀ: quanti passi al giorno servono per vincere la giornata. La sceglie il Genio
     dalla data che l'utente vuole; qui si cambia — finché la Modalità severa è spenta. */
  '<div class="ps-block"><b>\ud83c\udfae Modalità della partita</b>' +
    '<p class="hintline" style="padding:4px 0 8px">Quanti passi sulla rotta servono, ogni giorno, per vincere la giornata. Con la Modalità severa accesa non si tocca.</p>' +
    '<div class="sev-chips" id="psModalita"></div>' +
    '<p class="hintline" id="psModalitaTxt" style="padding:8px 2px 0"></p></div>' +
  /* IL MONITO sta qui e non fra le notifiche: non e' un avviso, e' una conseguenza — come il
     tabellone e la retrocessione di livello. Chi si chiede «e se vado male?» lo trova dove
     stanno le altre regole di cosa succede. */
  '<div class="setrow" onclick="goId(\'s-monito\'); monPaint();"><span>\ud83c\udfac</span><b>Il filmato del futuro</b><small>Quando il Genio vede male</small><span class="chev"></span></div>' +
  /* LE TUE SCELTE (0.9.273, Andrea): l'effetto farfalla e la pillola si cambiano da qui, non da un pannello a vista.
     Le due righe si riempiono quando la pagina si apre (fsScelteDipingi). */
  '<div class="sect" style="margin-top:22px"><b>Le tue scelte</b></div>' +
  '<div class="setrow" onclick="faCambia(\'strada\')"><span>\ud83e\udd8b</span><b>La tua strada</b><small id="fsStrada">Non ancora scelta</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="faCambia(\'pillola\')"><span>\ud83d\udc8a</span><b>Modalità severa</b><small id="fsPillola">Non ancora scelta</small><span class="chev"></span></div>' +
  '<div class="sect" style="margin-top:22px"><b>Il foglio della scheda START</b></div>' +
  /* La dettatura: spiegata a gesti, perche' un video nessuno lo guarda e un manuale nessuno
     lo legge. Sei righe con un'emoji davanti, e le due sole cose che deve sapere: che e'
     Premium, e che il riconoscimento e' quello del telefono. */
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>🎙️ Dettatura vocale</b>' +
    '<small>Prendi appunti parlando, anche mentre sei in giro e non puoi digitare.</small></div>' +
    '<button class="switch" id="psDict" onclick="settingsToggleDictation()"></button></div>' +
    '<div class="blk-swrow"><div><b>✨ Appunti AI <span class="ps-prem">Premium</span></b>' +
    '<small id="psDictAiTxt">Quello che detti torna sistemato: punteggiatura, a capo, elenchi. Le parole restano le tue.</small></div>' +
    '<button class="switch" id="psDictAi" onclick="settingsToggleDictationAi()"></button></div>' +
    '<div class="setrow"><div style="flex:1;min-width:0"><b>La mia voce per l’Io futuro</b><small>Mentre detti con l’AI impara la tua voce: niente file da caricare.</small></div>' +
    '<button class="switch" id="psDictVoce" onclick="drvToggle()"></button></div>' +
    '<div class="ps-how">' +
      '<div>🎤 Tocca il microfono rosa sotto al foglio</div>' +
      '<div>🗣️ Parla: il testo compare mentre lo dici</div>' +
      '<div>✅ La spunta tiene quello che hai detto</div>' +
      '<div>❌ La X lo butta via e il foglio torna com\'era</div>' +
      '<div>📱 Usa il riconoscimento del tuo telefono: gratuito, come Win+H su Windows</div>' +
    '</div>' +
    '<p class="hintline" id="psDictTxt" style="padding:10px 2px 0"></p></div>' +
  /* ------------------------------------------------------------------ il foglio ovunque
     Tre canali, e per ognuno si dice quello che il sistema permette davvero: il computer va da
     solo con l'account, Notion ha un'API, le note del telefono no (passano dal Condividi). */
  '<div class="ps-block" style="margin-top:12px"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udcbb Lo stesso foglio sul computer</b>' +
    '<small id="psFoglioPc">Sincronizzato con DreamMap per Windows tramite il tuo account.</small></div>' +
    '<button class="btn" style="flex:none;padding:8px 12px" onclick="fsAggiorna()">Aggiorna ora</button></div></div>' +
  '<div class="ps-block" style="margin-top:12px"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udcd3 Notion</b>' +
    '<small>Una pagina tua diventa il foglio di oggi: righe e spunte nei due sensi.</small></div>' +
    '<button class="switch" id="psNotion" onclick="settingsToggleNotion()"></button></div>' +
    '<div id="psNotionBox" hidden>' +
      /* Un passo per riga, numerati: le frecce dentro una riga sola facevano perdere il filo. */
      '<ol class="fs-steps">' +
        '<li>Apri <b>notion.so/my-integrations</b> dal browser</li>' +
        '<li>Crea un\u2019integrazione interna e copia il token</li>' +
        '<li>Vai sulla pagina di Notion che vuoi usare</li>' +
        '<li>Tocca il menu in alto a destra, poi <b>Connessioni</b></li>' +
        '<li>Aggiungi l\u2019integrazione che hai appena creato</li>' +
        '<li>Torna qui e incolla token e indirizzo della pagina</li>' +
      '</ol>' +
      '<input class="fin" id="psNotionTok" type="password" placeholder="Token dell\u2019integrazione (ntn_\u2026)" autocomplete="off" style="margin-top:10px">' +
      '<input class="fin" id="psNotionPage" type="url" placeholder="https://www.notion.so/\u2026" autocomplete="off" style="margin-top:8px">' +
      '<button class="btn" style="margin-top:10px" onclick="notionSalva()">Collega la pagina</button>' +
    '</div>' +
    '<p class="hintline" id="psNotionTxt" style="padding:10px 2px 0"></p></div>' +
  '<div class="ps-block" style="margin-top:12px"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udcdd Le note del telefono</b>' +
    '<small>Lo scambio con l\u2019app di note del telefono passa dal menu Condividi, nei due sensi.</small></div>' +
    '<button class="switch" id="psNote" onclick="settingsToggleNote()"></button></div>' +
    '<div id="psNoteBox" hidden>' +
      '<p class="fs-titolo">Dal foglio alle note</p>' +
      '<ol class="fs-steps">' +
        '<li>Tocca <b>Manda il foglio alle Note</b>, qui sotto</li>' +
        '<li>Scegli la tua <b>app di note</b> nell\u2019elenco che si apre</li>' +
      '</ol>' +
      '<p class="fs-titolo">Dalle note al foglio</p>' +
      '<ol class="fs-steps">' +
        '<li>Apri la nota nella tua app di note</li>' +
        '<li>Tocca il menu in alto a destra</li>' +
        '<li>Scegli <b>Condividi</b></li>' +
        '<li>Scegli <b>File di testo</b></li>' +
        '<li>Scegli <b>DreamMap</b>: ogni riga entra nel foglio di oggi</li>' +
      '</ol>' +
      '<button class="btn" style="margin-top:10px" onclick="noteManda()">Manda il foglio alle Note</button>' +
    '</div></div>' +
  /* ------------------------------------------------------------------ il buongiorno
     Una notifica che non chiede niente e non rimprovera: la frase del giorno, all'ora che
     scegli. Spenta di serie, perche' una app che comincia a scrivere senza essere stata
     invitata si fa spegnere le notifiche tutte insieme — e con quelle se ne va anche il
     promemoria della sera, che invece serve. */
  '<div class="sect" style="margin-top:22px"><b>La mattina</b></div>' +
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83c\udf31 Buongiorno</b>' +
    '<small id="stMorningSub">La frase del giorno, appena ti svegli. Niente compiti, niente numeri.</small></div>' +
    '<button class="switch" id="stMorningSw" onclick="settingsToggleMorning()"></button></div>' +
    '<div id="stMorningBody" hidden>' +
      '<label class="set-timerow"><span>Me la mandi alle</span>' +
        '<input type="time" id="stMorningAt" value="08:00" onchange="settingsSetMorning(this.value)"></label>' +
      '<div id="ntWarnMorning"></div></div></div>' +
  /* 0.9.310, Andrea (Duolingo, 747): gli avvisi per salvare la serie, con il conto alla rovescia fino a mezzanotte.
     Accesi di serie; l'interruttore e la scritta li disegna serie-avvisi.js (svaPaint, svaToggle). */
  '<div class="sect" style="margin-top:22px"><b>La sera</b></div>' +
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udd25 Avvisi per salvare la serie</b>' +
    '<small id="svaSub">Se oggi manca ancora la tappa, alle 20, alle 22 e alle 23 arriva un avviso con il tempo che resta fino a mezzanotte.</small></div>' +
    '<button class="switch on" id="svaSw" onclick="if(typeof svaToggle===\'function\')svaToggle()"></button></div>' +
    '<div id="ntWarnSerie"></div>' +
    '<div class="blk-swrow"><div><b>\ud83e\uddde Messaggi del Genio</b><small>Ti scrive come un amico: quando non ti vede da un po\u2019 e prima che la giornata finisca.</small></div>' +
    '<button class="switch on" id="gmSw" onclick="if(typeof gmToggle===\'function\')gmToggle()"></button></div></div>' +
  '<div class="sect" style="margin-top:22px"><b>Quando un blocco scatta</b></div>' +
  '<div class="setrow" onclick="waitOpen()"><span>\u23f3</span><b>Sala d\'attesa</b><small id="stWaitLbl">\u2014</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="emgOpen()"><span>\ud83c\udfab</span><b>Pass d\'emergenza</b><small id="stEmgLbl">\u2014</small><span class="chev"></span></div>' +
  /* 0.9.291, Andrea: "nelle impostazioni non vedo Blocca le finestre fluttuanti e Proteggi dopo il riavvio". La pagina
     c'era, ma ci si arrivava solo da Notifiche: in AppBlock Blocco preferenze sta nelle Impostazioni. */
  '<div class="setrow" onclick="blockPrefsOpen()"><span>\u23f8\ufe0f</span><b>Blocco preferenze</b><small>Finestre fluttuanti \u00b7 Dopo il riavvio</small><span class="chev"></span></div>' +
  /* NIENTE PAUSE. Il report della settimana conta le volte in cui un blocco e' stato fermato a
     meta': qui si toglie proprio la possibilita'. Un programma acceso resta acceso fino alla
     sua fine, il blocco rapido fino al suo timer. Per rimetterle basta spegnere la levetta:
     non e' la Modalita' severa, e' un patto piu' leggero. */
  '<div class="ps-block" id="stNoPause" style="margin-top:10px"><div class="blk-swrow" style="margin-top:0"><div><b>\u26d4 Niente pause</b>' +
    '<small>Un blocco partito non si ferma a met\u00e0: niente pulsante per interromperlo.</small></div>' +
    '<button class="switch" id="stNoPauseSw" onclick="settingsToggleNoPause()"></button></div></div>' +
  '<div class="sect" style="margin-top:22px"><b>Sopra le altre app</b></div>' +
  '<div class="ps-block"><b>\u23f1 Bolla del tempo nell\'app</b>' +
    /* Il disegno spiega in un colpo d'occhio quello che tre righe di testo spiegavano male:
       una bolla che compare in alto quando apri un'app, con i minuti di oggi. */
    '<div class="af-demo"><div class="af-phone"><div class="af-bar"></div>' +
      '<div class="af-bubble"><span></span>4:07</div>' +
      '<div class="af-rows"><i></i><i></i><i></i></div></div></div>' +
    '<p class="hintline" style="padding:8px 0 8px">Compare per qualche secondo quando apri un\'app, e dice quanto ci sei stato oggi. Toccala per vedere il dettaglio.</p>' +
    '<div class="sev-chips" id="stBubble"></div>' +
    '<p class="hintline" id="stBubbleHint" style="padding:8px 2px 0" hidden>\u26a0\ufe0f Serve l\'accesso ai dati di utilizzo: <a href="#" onclick="openPerm(\'usage\');return false">abilitalo</a>.</p>' +
    /* LA LEVETTA STA CON LA SUA BOLLA. Era finita nel pannello del conto alla rovescia, che e'
       un'altra cosa: un'impostazione si cerca dove si parla della cosa che regola. */
    '<div class="blk-swrow"><div><b>\ud83d\udc46 Scorri via la bolla</b><small>La bolla del tempo nell\'app si manda via con un dito, di lato. Spenta, resta ferma finch\u00e9 svanisce da sola.</small></div>' +
    '<button class="switch" id="stBubbleSwipe" onclick="settingsToggleBubbleSwipe()"></button></div></div>' +
  /* LA BOLLA DEL CARBURANTE (0.9.311): dopamina.js dpBollaToggle, nativo CarburanteBolla/CarburanteStima. Spenta di serie. */
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\u26fd Bolla del carburante</b>' +
    '<small>Quando il tuo carburante sale o scende, una bolla sopra alle altre app ti dice di quanto e perch\u00e9. Toccala per vedere la giornata intera.</small></div>' +
    '<button class="switch" id="dpBollaSw" onclick="dpBollaToggle()"></button></div>' +
    '<div class="af-demo"><div class="af-phone"><div class="af-bar"></div>' +
      '<div class="af-bubble af-carb"><span>\u26fd</span>32 \u2193 \u22122</div>' +
      '<div class="af-rows"><i></i><i></i><i></i></div></div></div>' +
    '<p class="hintline" id="dpBollaHint" style="padding:8px 2px 0" hidden>\u26a0\ufe0f Serve l\'accesso ai dati di utilizzo: <a href="#" onclick="openPerm(\'usage\');return false">abilitalo</a>.</p></div>' +
  /* LE BOLLE STANNO INSIEME. Questa e' l'altra bolla che compare sopra alle altre app: che
     stesse dentro alle regole della partita voleva dire cercarla dove nessuno la cerca. */
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udccc Tabellone della partita sempre in vista</b>' +
    '<small>La pillola con il punteggio resta sopra a qualsiasi app, si trascina dove vuoi e un tocco riporta nell\'app.</small></div>' +
    '<button class="switch" id="stScorePin" onclick="mtPinToggle();settingsPaintBubble()"></button></div>' +
    '<div class="setrow" style="margin-top:12px" onclick="slOpen()"><span>\ud83c\udfdf\ufe0f</span><b>Come si veste</b><small id="stLookLbl">\u2014</small><span class="chev"></span></div></div>' +
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\u23f3 Conto alla rovescia del limite</b><small>Una linguetta sul bordo sinistro con l\'anello del tempo che resta, quando l\'app o la funzione in-App che stai usando ha un limite di utilizzo. La freccia la ripiega.</small></div>' +
    '<button class="switch on" id="stLimitTab" onclick="settingsToggleLimitTab()"></button></div></div>' +
  /* PRIMA L'INTERRUTTORE, POI LE SCELTE.
     «Spento» in mezzo a 10, 15, 30 minuti chiedeva di leggere sei opzioni per scoprire che la
     prima non era un tempo: era l'interruttore travestito da durata. Adesso l'interruttore e'
     un interruttore, e finche' e' spento non c'e' niente da leggere — ne' la spiegazione ne'
     i tempi, che riguardano una cosa che non sta succedendo. */
  '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udcac Messaggio tempo totale</b>' +
    '<small id="stToastSub">Un avviso ogni tot minuti con il tempo passato al telefono oggi.</small></div>' +
    '<button class="switch" id="stToastSw" onclick="settingsToggleToast()"></button></div>' +
    '<div id="stToastBody" hidden>' +
      '<p class="hintline" style="padding:10px 0 8px">Compare per qualche secondo sopra qualsiasi app, e dice quanto tempo hai gia\' passato al telefono oggi.</p>' +
      '<div class="sev-chips" id="stUsageToast2"></div>' +
      /* 0.9.298, Andrea: "l'obiettivo giornaliero deve stare nelle Impostazioni, dentro lo stesso pannello del messaggio
         tempo totale, e comparire solo dopo che si e' acceso l'interruttore": il messaggio colora il tempo con l'obiettivo. */
      '<div class="ps-sub" style="margin-top:18px;margin-bottom:4px">Tempo massimo al telefono, al giorno</div>' +
      '<p class="hintline" style="padding:2px 0 8px">Il contatore in alto diventa un semaforo: <span class="ps-dot ok"></span> verde sotto i tre quarti, <span class="ps-dot warn"></span> giallo quando ti avvicini, <span class="ps-dot over"></span> rosso oltre.</p>' +
      '<div class="sev-chips" id="psGoal"></div></div></div>' +
  /* IL SILENZIO E' GENERALE: vale per il mantra, la chiamata dei sogni, i promemoria e i premi.
     Sta qui, dopo le cose che compaiono sopra le altre app, perche' e' di quelle che parla. */
  '<div class="sect" style="margin-top:22px"><b>Quando tacere</b></div>' +
  '<div class="setrow" onclick="silApri()"><span>🔕</span><b>Fasce di silenzio</b><small id="stSilTxt">—</small><span class="chev"></span></div>' +
  '<p class="hintline" style="padding:8px 2px 0">Mantra, chiamata dei sogni, promemoria e premi tacciono in queste ore. Durante una telefonata tacciono sempre.</p>' +
  '<div class="spacer"></div>', { back: 's-home' });

/* Le due righe nuove devono dire in che stato sono senza doverci entrare. */
async function settingsPaintExits(){
  const m = document.getElementById('stMatchLbl');
  if (m && typeof mgCfg === 'function'){
    const c = mgCfg();
    m.textContent = c.severity + ' · ' + (c.season === 'giorno' ? 'una al giorno' : 'campionato');
  }
  const lk = document.getElementById('stLookLbl');
  if (lk) lk.textContent = (typeof SL_MODI !== 'undefined' && typeof slSkin === 'function')
      ? (SL_MODI.filter(function(x){ return x.k === slSkin(); })[0] || SL_MODI[0]).n.toLowerCase()
      : 'sempre in contrasto';
  const gr = document.getElementById('stGreyLbl');
  if (gr && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.greyState){
    try{
      const g = await NATIVE.greyState();
      const n = (g.apps || []).length + (g.sites || []).length + (g.programs || []).length;
      gr.textContent = !g.granted ? (g.on ? 'da attivare dal computer' : 'spento')
        : (g.on ? (n ? n + ' in bianco e nero' : 'acceso, elenco vuoto') : 'spento');
    }catch(_){ gr.textContent = 'non disponibile'; }
  } else if (gr) gr.textContent = 'solo nell\'app installata';

  const np = document.getElementById('stNoPauseSw');
  if (np) np.classList.toggle('on', itNoPause());
  const w = document.getElementById('stWaitLbl');
  if (w){
    const m = (typeof SETTINGS !== 'undefined' && SETTINGS.waitMode) || 'off';
    const sec = +(typeof SETTINGS !== 'undefined' && SETTINGS.waitSec) || 10;
    w.textContent = m === 'off' ? 'spenta' : (m === 'increasing' ? 'crescente, da ' + sec + 's' : sec + ' secondi');
  }
  const e = document.getElementById('stEmgLbl');
  if (e && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.emergencyState){
    try{
      const st = await NATIVE.emergencyState();
      e.textContent = st && st.available ? 'disponibile, uno solo' : 'gi\u00e0 usato';
    }catch(_){ }
  }
}

function settingsPaintUsageToast(){
  const cur = +SETTINGS.usageToastMin || 0;
  ['stUsageToast', 'stUsageToast2'].forEach(function(id){
    const host = document.getElementById(id);
    if(!host) return;
    host.innerHTML = chipsWithCustom(USAGE_TOAST_CHOICES, cur, 'settingsSetUsageToast');
  });
  const sw = document.getElementById('stToastSw');
  if (sw) sw.className = 'switch' + (cur > 0 ? ' on' : '');
  const body = document.getElementById('stToastBody');
  if (body) body.hidden = !(cur > 0);
  try{ personalizePaintGoal(); }catch(_){ }
  const sub = document.getElementById('stToastSub');
  if (sub) sub.textContent = cur > 0
      ? 'Ogni ' + (cur >= 60 ? (cur / 60) + (cur === 60 ? ' ora' : ' ore') : cur + ' minuti') + ', sopra qualsiasi app.'
      : 'Un avviso ogni tot minuti con il tempo passato al telefono oggi.';
}

/* L'interruttore ricorda l'ultimo tempo scelto: spegnere e riaccendere non deve far
   ricominciare da capo una scelta che era gia' stata fatta. */
async function settingsToggleToast(){
  const cur = +SETTINGS.usageToastMin || 0;
  if (cur > 0){
    try{ localStorage.setItem('fl_toast_last', String(cur)); }catch(_){ }
    await settingsSetUsageToast(0);
  } else {
    let ultimo = 0;
    try{ ultimo = +localStorage.getItem('fl_toast_last') || 0; }catch(_){ }
    await settingsSetUsageToast(ultimo > 0 ? ultimo : USAGE_TOAST_DEFAULT);
  }
  settingsPaintUsageToast();
}
/* ---------------------------------------------------------------------------------------
   Il buongiorno

   L'ora vive nel motore come minuti dalla mezzanotte (-1 = spento), perche' e' il motore che
   deve svegliarsi: la pagina web alle otto di mattina non c'e'.
   --------------------------------------------------------------------------------------- */
function settingsMorningMin(){
  const v = (typeof SETTINGS !== 'undefined') ? +SETTINGS.morningMin : -1;
  return isNaN(v) ? -1 : v;
}

function settingsMorningHhmm(min){
  return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0');
}

function settingsPaintMorning(){
  const min = settingsMorningMin();
  const sw = document.getElementById('stMorningSw');
  if (sw) sw.className = 'switch' + (min >= 0 ? ' on' : '');
  const body = document.getElementById('stMorningBody');
  if (body) body.hidden = min < 0;
  const at = document.getElementById('stMorningAt');
  if (at && min >= 0) at.value = settingsMorningHhmm(min);
  const sub = document.getElementById('stMorningSub');
  if (sub) sub.textContent = min >= 0
    ? 'Ogni mattina alle ' + settingsMorningHhmm(min) + '.'
    : 'La frase del giorno, appena ti svegli. Niente compiti, niente numeri.';
  if (typeof ntAvvisoPaint === 'function') ntAvvisoPaint();
}

async function settingsToggleMorning(){
  const min = settingsMorningMin();
  if (min >= 0){
    try{ localStorage.setItem('fl_morning_last', String(min)); }catch(_){ }
    await settingsSave({ morningMin: -1 });
  } else {
    /* LE OTTO, finche' non e' stata scelta un'altra ora davvero.
       `+null` vale zero, e zero passa il controllo `>= 0`: la chiave mancante scavalcava il
       valore di partenza e il buongiorno finiva a mezzanotte. Qui l'assenza si riconosce
       PRIMA di convertirla in numero, che e' l'unico momento in cui e' ancora distinguibile
       da un orario valido. */
    let ultimo = 8 * 60;
    try{
      const raw = localStorage.getItem('fl_morning_last');
      const v = (raw === null || raw === '') ? NaN : parseInt(raw, 10);
      if (!isNaN(v) && v >= 0 && v <= 1439) ultimo = v;
    }catch(_){ }
    await settingsSave({ morningMin: ultimo });
    /* Stessa regola del promemoria della sera: il permesso si chiede nel momento in cui si
       accende la cosa che ne ha bisogno. */
    if (typeof ntChiedi === 'function') await ntChiedi();
  }
  settingsPaintMorning();
}

async function settingsSetMorning(hhmm){
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || ''));
  if (!m) return;
  await settingsSave({ morningMin: Math.max(0, Math.min(1439, (+m[1]) * 60 + (+m[2]))) });
  settingsPaintMorning();
}

function settingsPaintBubble(){
  settingsPaintExits();
  const host = document.getElementById('stBubble'); if(!host) return;
  const cur = +SETTINGS.bubbleEveryMin || 0;
  host.innerHTML = BUBBLE_CHOICES.map(function(c){
    return '<button type="button" class="sev-chip' + (cur === c[0] ? ' on' : '') + '" onclick="settingsSetBubble(' + c[0] + ')">' + c[1] + '</button>';
  }).join('');
  const sw = document.getElementById('stLimitTab'); if(sw) sw.className = 'switch' + (SETTINGS.limitTab !== false ? ' on' : '');
  const bs = document.getElementById('stBubbleSwipe'); if(bs) bs.className = 'switch' + (SETTINGS.bubbleSwipe === true ? ' on' : '');
  const pin = document.getElementById('stScorePin');
  if (pin) pin.className = 'switch' + ((typeof mtPin === 'function' && mtPin()) ? ' on' : '');
  settingsPaintUsageToast();
  settingsPaintMorning();
}
async function settingsSetBubble(min){
  await settingsSave({ bubbleEveryMin: min });
  settingsPaintBubble();
  const hint = document.getElementById('stBubbleHint');
  if(hint){
    let granted = true;
    try{ if(NATIVE && NATIVE.getScreenTimeToday){ const t = await NATIVE.getScreenTimeToday(); granted = !!(t && t.granted); } }catch(_){ }
    hint.hidden = !(min > 0 && !granted);
  }
}
async function settingsToggleBubbleSwipe(){
  await settingsSave({ bubbleSwipe: !(SETTINGS.bubbleSwipe === true) });
  settingsPaintBubble();
}
async function settingsToggleLimitTab(){
  const next = !(SETTINGS.limitTab !== false);
  await settingsSave({ limitTab: next });
  settingsPaintBubble();
}

/* ---------------- Personalizza ----------------
   What the block looks like: the lock screen style, the page it sends you to, your own line,
   and the daily goal that colours the timer in the header. */
registerScreen('s-personalize',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Personalizza</b></div>' +
  '<div class="sect"><b>Schermata di blocco</b></div>' +
  '<div class="setrow" onclick="drawerGo(\'s-lockscreen\')"><span>📱</span><b>Stile della schermata</b><small id="psLockStyle">—</small><span class="chev"></span></div>' +
  /* Il reindirizzamento e la frase personale stavano qui: STESSA funzione della riga sopra,
     cosa succede quando un blocco scatta. Vivono ora tutti in una pagina sola, «Schermata
     di blocco» (s-lockscreen), invece che sparsi fra due pagine diverse. */
  '<div class="sect" style="margin-top:22px"><b>Il foglio della scheda START</b></div>' +
  '<div class="setrow" onclick="goId(\'s-settings\'); setTimeout(function(){ var e = document.getElementById(\'psNotion\'); if (e) e.scrollIntoView({ block: \'center\' }); }, 300);"><span>\ud83d\udd04</span><b>Il foglio ovunque</b><small>Computer, Notion, note del telefono</small><span class="chev"></span></div>' +
  /* L'obiettivo giornaliero (0.9.298) vive ora in Impostazioni, dentro il pannello del messaggio tempo totale. */
  /* L'arbitro non parla di mantra: assegna i punti del tabellone. Vive ora nella pagina
     della partita (Impostazioni -> La partita -> s-match), con le altre regole del gioco a
     cui appartiene davvero. */
  /* La frase di quando si sta per mollare una sessione, con un titolo di sezione tutto suo:
     prima stava sotto "Mantra sullo schermo", un'altra funzione, senza nessun nesso. */
  '<div class="sect" style="margin-top:22px"><b>Suoni dell’app</b></div>' +
  '<div class="ps-block" id="psEffetti"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Quando stai per mollare</b></div>' +
  '<div class="ps-block"><b>🌱 Se stai per arrenderti</b>' +
    '<p class="hintline" style="padding:4px 0 10px">Compare a macchina da scrivere sulla schermata che chiede se vuoi davvero arrenderti a una sessione. Lasciala vuota e usiamo il tuo mantra.</p>' +
    '<input id="psQuitNote" class="fin" placeholder="La frase che ti fa restare un minuto in più" autocomplete="off" maxlength="140" onchange="settingsSaveQuitNote()">' +
    '<div class="ps-sub" style="margin-top:16px">Con che tono</div>' +
    '<div class="sev-chips" id="psQuitTone"></div></div>' +
  '<div class="sect" style="margin-top:22px"><b>Il mantra</b></div>' +
  '<div class="ps-block"><b>\ud83d\udc64 La faccia del promemoria</b>' +
    '<p class="hintline" style="padding:4px 0 10px">Una foto tonda in cima alla card: un promemoria che arriva da una persona si legge diversamente da uno che arriva da un\'app. Se non ne scegli una vale quella del tuo perch\u00e9.</p>' +
    '<div id="psAvatar"></div></div>' +
  '<div class="ps-block"><b>✨ Il mantra della versione futura di te</b>' +
    '<p class="hintline" style="padding:4px 0 8px">Ogni tot minuti compare per qualche secondo, sopra qualsiasi app, la frase che hai scritto nella pagina «Il tuo perché» della Modalità severa.</p>' +
    '<p class="hintline ps-mantra" id="psMantraTxt"></p>' +
    '<div class="ps-sub">Ogni quanto</div>' +
    '<div class="sev-chips" id="psMantra"></div>' +
    '<div class="setrow" style="margin-top:12px" onclick="m369Apri()"><span>\u26a1</span><b>Metodo 3\u00b76\u00b79</b><small id="psM369Lbl">\u2014</small><span class="chev"></span></div>' +
    '<div class="ps-sub">Quando lo tocchi</div>' +
    '<div class="sev-chips" id="psMantraAct"></div>' +
    '<p class="hintline" id="psMantraActTxt" style="padding:8px 2px 0"></p>' +
    /* Il campanellino. Una card che compare in silenzio mentre guardi altrove non l'hai
       nemmeno vista: il suono e' quello che la trasforma in un appuntamento. */
    '<div class="blk-swrow" style="margin-top:20px"><div><b>🔔 Un campanellino quando compare</b>' +
      '<small>Un suono breve annuncia la card, così te ne accorgi anche se non stai guardando lo schermo.</small></div>' +
      '<button class="switch on" id="psMantraChime" onclick="settingsToggleMantraChime()"></button></div>' +
    /* 0.9.218: quando la card aspetta. Le due scelte stanno qui, con la cadenza: parlano di
       QUANDO compare, non del suono. */
    '<div class="ps-sub" style="margin-top:20px">Quando compare</div>' +
    '<p class="hintline" style="padding:2px 0 6px">Mai mentre scrivi, al telefono o in Full Focus: aspetta il primo momento libero.</p>' +
    '<div class="blk-swrow"><div><b>Mostralo mentre usi un’app produttiva</b>' +
      '<small>Spento, il mantra aspetta che tu esca dall’app segnata come produttiva.</small></div>' +
      '<button class="switch" id="psMantraProd" onclick="settingsToggleMantraProd()"></button></div>' +
    '<div class="blk-swrow"><div><b>Mentre guidi, il suono parte da solo</b>' +
      '<small>Con il navigatore aperto parte il suono scelto, e la card si scorre via.</small></div>' +
      '<button class="switch on" id="psMantraNavAuto" onclick="settingsToggleMantraNavAuto()"></button></div>' +
    '<div class="ps-row" style="margin-top:16px"><button type="button" class="ghostmini" style="width:100%" onclick="goId(\'s-bell\')">Suono, canale e quando tacere ›</button></div>' +
    '<div class="ps-row" style="margin-top:20px;display:flex;gap:8px">' +
      '<button type="button" class="ghostmini" style="flex:1" onclick="personalizePreviewMantra()">Guarda come appare</button>' +
      '<button type="button" class="ghostmini" style="flex:1" id="psMantraStop" onclick="personalizeStopMantraSound()">Ferma il suono</button></div></div>' +
  /* 0.9.197: la voce del tuo Io futuro, dalle tue registrazioni (si apre la pagina di iofuturo-chiamata.js) */
  '<div class="sect" style="margin-top:22px"><b>Il tuo Io futuro</b></div>' +
  '<div class="ps-block"><div class="setrow" onclick="if(typeof icVoceApri===\'function\')icVoceApri()"><span>🎙️</span><b>La sua voce, identica alla tua</b><small>Carica le tue registrazioni</small><span class="chev"></span></div></div>' +
  '<div class="sect" style="margin-top:22px"><b>La chiamata dei sogni</b></div>' +
  '<div class="ps-block" id="dcBlock"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Sveglia</b></div>' +
  '<div class="ps-block"><b>⏰ La tua frase a un\'ora precisa</b>' +
    '<p class="hintline" style="padding:4px 0 8px">Ogni giorno, all\'ora che scegli: una notifica con il tuo mantra e, se il servizio di blocco è attivo, la stessa frase al centro dello schermo. Un promemoria, non una sirena.</p>' +
    '<div class="ps-row"><input class="fin" id="psAlarmTime" type="time" step="60" onchange="personalizeSetAlarm(this.value)">' +
      '<button type="button" class="ghostmini" onclick="personalizeSetAlarm(\'\')">Spegni</button></div>' +
    '<div class="ps-row"><button type="button" class="ghostmini" onclick="personalizePickAlarmSound()">Scegli il suono</button>' +
      '<span class="ps-val" id="psAlarmSound">nessun suono</span></div>' +
    '<p class="hintline" id="psAlarmTxt" style="padding:8px 2px 0"></p></div>' +
  /* Nessun pulsante Salva qui in fondo: serviva solo ai due campi che ora vivono in
     Schermata di blocco. Tutto il resto di questa pagina si salva da solo appena lo tocchi. */
  '<div class="spacer"></div>', { back: 's-home' });

/* ---------------- Il campanellino del mantra ----------------
   Le stesse scelte dell'app di meditazione da cui viene l'idea: quale campana, su quale
   canale, e le condizioni in cui deve tacere. Le campane sono sintetizzate da noi — otto
   timbri diversi, parziali non armoniche per quelle di metallo — perché i suoni di
   un'altra app sono roba sua, non nostra. */
const BELLS = [
  ['bell1', 'Ding chiaro'], ['bell2', 'Ciotola tibetana'], ['bell3', 'Triangolo'],
  ['bell4', 'Gong'], ['bell5', 'Carillon'], ['bell6', 'Campana di tempio'],
  ['bell7', 'Ding dolce'], ['bell8', 'Due tocchi']
];
const BELL_CHANNELS = [['music', 'Musica'], ['notification', 'Notifiche'], ['alarm', 'Sveglia']];
const BELL_MUTES = [
  ['calls', 'Durante le chiamate'],
  ['rec', 'Mentre registri audio'],
  ['silent', 'Con la suoneria in silenzioso'],
  ['vibrate', 'Con la suoneria in vibrazione'],
  ['dnd', 'In Non disturbare'],
  ['flight', 'In modalità aereo']
];

registerScreen('s-bell',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-personalize\')">‹</button><b class="blk-title">Campanellino</b></div>' +
  '<div class="ps-block"><b>🔔 Il suono</b>' +
    '<p class="hintline" style="padding:4px 0 10px">Toccane uno per sentirlo. Sono otto timbri diversi: quelli di metallo hanno le parziali fuori dall\'armonia, ed è questo a farli sentire come campane invece che come flauti.</p>' +
    '<div class="sev-chips" id="psBells"></div></div>' +
  '<div class="ps-block"><b>🔊 Canale di riproduzione</b>' +
    '<p class="hintline" style="padding:4px 0 10px">Su «Notifiche» il suono segue la suoneria del telefono: se la tieni in silenzioso non lo sentirai mai. «Musica» suona lo stesso, ed è il motivo per cui è quello di serie.</p>' +
    '<div class="sev-chips" id="psBellCh"></div></div>' +
  '<div class="sect" style="margin-top:22px"><b>Quando deve tacere</b></div>' +
  '<div class="ps-block" id="psBellMutes"></div>' +
  /* le ore di silenzio sono quelle di tutta l'app: si scelgono in «Quando tacere» */
  '<div class="setrow" onclick="silApri()"><span>🔕</span><b>Fasce di silenzio</b><small>Valgono per tutta l\'app</small><span class="chev"></span></div>' +
  /* «Mentre guidi» (0.9.218) e' diventato un interruttore in Personalizza, accanto a quando
     compare il mantra: con il navigatore davanti la card si scorre via e il suono parte da solo. */
  '<div class="spacer"></div>', { back: 's-personalize' });

function bellPaint(){
  const cur = SETTINGS.mantraBell || 'bell7';
  const bells = document.getElementById('psBells');
  if (bells) bells.innerHTML = BELLS.map(function(b){
    return '<button type="button" class="sev-chip' + (cur === b[0] ? ' on' : '') + '" onclick="bellSet(\'' + b[0] + '\')">' + b[1] + '</button>';
  }).join('');
  const ch = document.getElementById('psBellCh');
  const curCh = SETTINGS.mantraChannel || 'music';
  if (ch) ch.innerHTML = BELL_CHANNELS.map(function(c){
    return '<button type="button" class="sev-chip' + (curCh === c[0] ? ' on' : '') + '" onclick="bellSetChannel(\'' + c[0] + '\')">' + c[1] + '</button>';
  }).join('');
  const mu = document.getElementById('psBellMutes');
  if (mu) mu.innerHTML = BELL_MUTES.map(function(m, i){
    const on = SETTINGS['mantraMute_' + m[0]] === true;
    return '<div class="blk-swrow"' + (i === 0 ? ' style="margin-top:0"' : '') + '><div><b>' + m[1] + '</b></div>'
      + '<button class="switch' + (on ? ' on' : '') + '" onclick="bellToggleMute(\'' + m[0] + '\')"></button></div>';
  }).join('');
  const qs = document.getElementById('psQuietSw');
  if (qs) qs.classList.toggle('on', SETTINGS.mantraQuietOn !== false);
  const f = document.getElementById('psQuietFrom'), t = document.getElementById('psQuietTo');
  if (f) f.value = bellHhmm(SETTINGS.mantraQuietFrom === undefined ? 22 * 60 : SETTINGS.mantraQuietFrom);
  if (t) t.value = bellHhmm(SETTINGS.mantraQuietTo === undefined ? 8 * 60 : SETTINGS.mantraQuietTo);
}
function bellHhmm(min){ const h = Math.floor(min / 60), m = min % 60; return ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2); }
function bellMin(v){ const p = String(v || '').split(':'); return (+p[0] || 0) * 60 + (+p[1] || 0); }
async function bellSet(id){
  await settingsSave({ mantraBell: id });
  bellPaint();
  if (NATIVE && NATIVE.previewBell){ try{ await NATIVE.previewBell({ id: id, channel: SETTINGS.mantraChannel || 'music' }); }catch(_){ } }
}
async function bellSetChannel(ch){ await settingsSave({ mantraChannel: ch }); bellPaint(); if (NATIVE && NATIVE.previewBell){ try{ await NATIVE.previewBell({ id: SETTINGS.mantraBell || 'bell7', channel: ch }); }catch(_){ } } }
async function bellToggleMute(which){ const k = 'mantraMute_' + which; const patch = {}; patch[k] = !(SETTINGS[k] === true); await settingsSave(patch); bellPaint(); }
async function bellToggleQuiet(){ await settingsSave({ mantraQuietOn: !(SETTINGS.mantraQuietOn !== false) }); bellPaint(); }
async function bellSetQuiet(){
  const f = document.getElementById('psQuietFrom'), t = document.getElementById('psQuietTo');
  await settingsSave({ mantraQuietFrom: bellMin(f && f.value), mantraQuietTo: bellMin(t && t.value) });
  bellPaint();
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-bell'){ settingsLoad().then(bellPaint); } });

/* ---- cosa succede quando si tocca il mantra: niente, un indirizzo, un suono, un video ---- */
const MANTRA_ACTS = [['none','Niente'],['url','Un indirizzo'],['sound','Un suono'],['video','Un video']];
function personalizePaintMantraAct(){
  const host = document.getElementById('psMantraAct'); if(!host) return;
  const cur = SETTINGS.mantraAction || 'none';
  host.innerHTML = MANTRA_ACTS.map(function(a){
    return '<button type="button" class="sev-chip' + (cur === a[0] ? ' on' : '') + '" onclick="personalizeSetMantraAct(\'' + a[0] + '\')">' + a[1] + '</button>';
  }).join('');
  const t = document.getElementById('psMantraActTxt');
  if(t){
    const v = SETTINGS.mantraValue || '';
    t.textContent = cur === 'none' ? 'Toccandolo si apre DreamMap.'
      : (v ? (cur === 'url' ? 'Si apre: ' + v : 'File scelto: ' + (SETTINGS.mantraName || v.split('/').pop()))
           : 'Scegli ancora cosa aprire.');
  }
}
async function personalizeSetMantraAct(kind){
  if(kind === 'none'){ await settingsSave({ mantraAction: 'none', mantraValue: '' }); personalizePaintMantraAct(); return; }
  if(kind === 'url'){
    const v = prompt('Quale indirizzo vuoi aprire?', SETTINGS.mantraValue || 'https://');
    if(v === null) return;
    const u = String(v).trim();
    if(!u || u.length < 4){ toast('Scrivi un indirizzo'); return; }
    await settingsSave({ mantraAction: 'url', mantraValue: u });
    personalizePaintMantraAct();
    return;
  }
  if(!NATIVE || !NATIVE.pickMedia){ toast('Disponibile solo nell\'app installata'); return; }
  try{
    const r = await NATIVE.pickMedia({ kind: kind === 'video' ? 'video' : 'audio' });
    if(!r || !r.uri) return;
    SETTINGS.mantraName = r.name || '';
    await settingsSave({ mantraAction: kind, mantraValue: r.uri });
    personalizePaintMantraAct();
  }catch(e){ if(e && e.code !== 'cancelled') toast('Nessun file scelto'); }
}
/* FERMARE QUELLO CHE E' PARTITO.

   Il suono del mantra puo' essere un file scelto da te, e un file scelto da te puo' durare
   un quarto d'ora. La card che lo fa partire sparisce subito dopo il tocco: da li' in avanti
   c'era della musica e niente da premere, in nessun punto del telefono. Adesso ci sono due
   modi di fermarla — questo pulsante, e il "Ferma" nella notifica che compare mentre suona,
   che e' il posto dove uno la cerca quando non ha l'app davanti. */
async function personalizeStopMantraSound(){
  if(!NATIVE || !NATIVE.mantraSoundStop){ toast('Disponibile solo nell\'app installata'); return; }
  try{ await NATIVE.mantraSoundStop(); toast('Suono fermato'); }
  catch(_){ toast('Non sono riuscito a fermarlo'); }
}

async function personalizePreviewMantra(){
  const m = (typeof whyMantra === 'function') ? whyMantra() : '';
  if(!m){ toast('Scrivi prima il mantra nel tuo perché'); return; }
  if(!NATIVE || !NATIVE.previewMantra){ toast('Disponibile solo nell\'app installata'); return; }
  try{
    const r = await NATIVE.previewMantra({ text: m });
    if(!r || !r.shown) toast('Serve il servizio di blocco attivo per mostrarlo sopra le app');
    else toast('Eccolo: appare così');
  }catch(_){ toast('Non sono riuscito a mostrarlo'); }
}

/* ---- la sveglia ---- */
function personalizePaintAlarm(){
  const t = document.getElementById('psAlarmTime');
  const min = typeof SETTINGS.alarmMin === 'number' ? SETTINGS.alarmMin : -1;
  if(t) t.value = min >= 0 ? (String(Math.floor(min/60)).padStart(2,'0') + ':' + String(min%60).padStart(2,'0')) : '';
  const s2 = document.getElementById('psAlarmSound');
  if(s2) s2.textContent = SETTINGS.alarmSound ? (SETTINGS.alarmName || 'suono scelto') : 'nessun suono';
  const txt = document.getElementById('psAlarmTxt');
  if(txt) txt.textContent = min >= 0
    ? 'Suona ogni giorno alle ' + String(Math.floor(min/60)).padStart(2,'0') + ':' + String(min%60).padStart(2,'0') + '.'
    : 'Spenta.';
}
async function personalizeSetAlarm(v){
  let min = -1;
  if(v){
    const m = String(v).match(/^(\d{1,2}):(\d{2})/);
    if(!m){ toast('Ora non valida'); return; }
    min = (+m[1]) * 60 + (+m[2]);
  }
  await settingsSave({ alarmMin: min });
  personalizePaintAlarm();
  toast(min >= 0 ? 'Sveglia impostata' : 'Sveglia spenta');
}
async function personalizePickAlarmSound(){
  if(!NATIVE || !NATIVE.pickMedia){ toast('Disponibile solo nell\'app installata'); return; }
  try{
    const r = await NATIVE.pickMedia({ kind: 'audio' });
    if(!r || !r.uri) return;
    SETTINGS.alarmName = r.name || '';
    await settingsSave({ alarmSound: r.uri });
    personalizePaintAlarm();
  }catch(e){ if(e && e.code !== 'cancelled') toast('Nessun file scelto'); }
}
const MANTRA_CHOICES = [[0,'Spento'],[15,'15 min'],[30,'30 min'],[60,'1 ora'],[120,'2 ore'],[240,'4 ore'],[-1,'Personalizzato…']];
/* A chip row where the last chip asks for a number: the chosen cadence that is not in the
   row is shown on that chip ("Ogni 45 min"). */
function chipsWithCustom(list, cur, fn){
  const known = list.some(function(c){ return c[0] === cur; });
  return list.map(function(c){
    const custom = c[0] === -1;
    const on = custom ? (!known && cur > 0) : cur === c[0];
    const label = custom && on ? 'Ogni ' + cur + ' min' : c[1];
    return '<button type="button" class="sev-chip' + (on ? ' on' : '') + '" onclick="' + fn + '(' + c[0] + ')">' + label + '</button>';
  }).join('');
}
function askMinutes(){
  const v = prompt('Ogni quanti minuti? (da 5 a 720)');
  if(v === null) return null;
  const n = Math.round(+String(v).replace(',', '.'));
  if(!(n >= 5 && n <= 720)){ toast('Scrivi un numero fra 5 e 720'); return null; }
  return n;
}
function mantraEveryMin(){
  try{
    /* sul computer una cadenza scelta li' vive in una chiave sua: lo specchio del telefono
       sovrascrive fl_mantra_min ogni giro, e non deve poter cancellare una scelta fatta qui */
    if (typeof pcQui === 'function' && pcQui() === 'desktop'){
      const pc = localStorage.getItem('fl_pc_mantra_min');
      if (pc !== null && pc !== '') return +pc || 0;
    }
    return +(localStorage.getItem('fl_mantra_min') || 0) || 0;
  }catch(_){ return 0; }
}
function personalizePaintMantra(){
  const host = document.getElementById('psMantra'); if(!host) return;
  const cur = mantraEveryMin();
  host.innerHTML = chipsWithCustom(MANTRA_CHOICES, cur, 'personalizeSetMantra');
  const t = document.getElementById('psMantraTxt');
  const m = (typeof whyMantra === 'function') ? whyMantra() : '';
  const l3 = document.getElementById('psM369Lbl');
  if (l3 && typeof m369Etichetta === 'function') l3.textContent = m369Etichetta();
  if(t) t.innerHTML = m ? '«' + esc(m) + '»' : 'Non hai ancora scritto un mantra: <a href="#" onclick="whyOpen();return false">scrivilo adesso</a>.';
}
function personalizeSetMantra(min){
  if(min === -1){ const n = askMinutes(); if(n === null) return; min = n; }
  try{
    localStorage.setItem('fl_mantra_min', String(min));
    if (typeof pcQui === 'function' && pcQui() === 'desktop') localStorage.setItem('fl_pc_mantra_min', String(min));
  }catch(_){ }
  const m = (typeof whyMantra === 'function') ? whyMantra() : '';
  if(NATIVE && NATIVE.setSettings){ try{ NATIVE.setSettings({ mantraEveryMin: min, mantraText: m }); }catch(_){ } }
  personalizePaintMantra();
  const lbl = (MANTRA_CHOICES.filter(function(c){ return c[0] === min; })[0] || [0, min + ' min'])[1];
  toast(min ? (m ? 'Il mantra comparirà ogni ' + lbl : 'Scrivi prima il mantra nel tuo perché') : 'Mantra spento');
}

async function personalizePaint(){
  /* la faccia del promemoria e il gruppo di frasi scelto */
  try{
    const av = document.getElementById('psAvatar');
    if (av){
      const d = (typeof mantraAvatarData === 'function') ? mantraAvatarData() : '';
      av.innerHTML = (d ? '<div class="ps-av" style="background-image:url(' + d + ')"></div>' : '')
        + '<div style="display:flex;gap:10px;margin-top:' + (d ? '12px' : '0') + '">'
        + '<button class="cta" style="flex:1" onclick="mantraAvatarPick()">' + (d ? 'Cambia' : 'Scegli immagine') + '</button>'
        + (d ? '<button class="ghost" style="flex:1;width:auto" onclick="mantraAvatarClear()">Rimuovi</button>' : '') + '</div>';
    }
    const lp = document.getElementById('psLockPack');
    if (lp && typeof LOCK_PACKS !== 'undefined'){
      const cur = (typeof SETTINGS !== 'undefined' && SETTINGS.lockPack) || 'base';
      const p = LOCK_PACKS.filter(function(x){ return x.k === cur; })[0];
      lp.textContent = p ? p.n : 'Predefinito';
    }
  }catch(_){ }

  if (typeof dcLoad === 'function') dcLoad().then(function(){ if (typeof dcPaint === 'function') dcPaint(); });
  await settingsLoad();
  /* stRedirect e stMotivation vivono adesso in «Schermata di blocco» (s-lockscreen), insieme
     a tutto il resto di cosa succede quando un blocco scatta: li popola lockScreenPaint(). */
  const ls = document.getElementById('psLockStyle');
  if(ls){ const st = (typeof LOCK_STYLES !== 'undefined' ? LOCK_STYLES : []).filter(function(x){ return x.k === (SETTINGS.lockStyle || 'base'); })[0]; ls.textContent = st ? st.name : 'Base'; }
  personalizePaintGoal();
  personalizePaintMantra();
  personalizePaintMantraAct();
  personalizePaintChime();
  personalizePaintMantraWhen();
  personalizePaintDictation();
  personalizePaintQuit();
  personalizePaintAlarm();
}
/* Due toni gia' scritti, perche' la pagina bianca e' il motivo per cui questi campi restano
   vuoti per sempre. Chi vuole la sua frase la scrive sopra. */
const QUIT_TONES = [
  ['dolce', 'Gentile', 'Va bene fermarsi. Ma prova a restare ancora un minuto: di solito basta quello.'],
  ['duro', 'Severo', 'Ti sei fermato mille volte prima di adesso. Stavolta vediamo cosa succede se non lo fai.']
];
function personalizePaintQuit(){
  const i = document.getElementById('psQuitNote');
  if (i) i.value = SETTINGS.quitNote || '';
  const host = document.getElementById('psQuitTone');
  if (host) host.innerHTML = QUIT_TONES.map(function(t){
    return '<button type="button" class="sev-chip' + ((SETTINGS.quitNote || '') === t[2] ? ' on' : '') + '" onclick="settingsQuitTone(\'' + t[0] + '\')">' + t[1] + '</button>';
  }).join('');
}
async function settingsSaveQuitNote(){
  const i = document.getElementById('psQuitNote');
  await settingsSave({ quitNote: i ? i.value.trim() : '' });
  personalizePaintQuit();
}
async function settingsQuitTone(k){
  const t = QUIT_TONES.filter(function(x){ return x[0] === k; })[0];
  if (!t) return;
  await settingsSave({ quitNote: t[2] });
  personalizePaintQuit();
}
function personalizePaintDictation(){
  const b = document.getElementById('psDict');
  const premium = (typeof Premium !== 'undefined') && Premium.isPremium();
  if (b) b.classList.toggle('on', SETTINGS.dictation !== false);
  const t = document.getElementById('psDictTxt');
  if (t) t.textContent = SETTINGS.dictation !== false ? 'Accesa: il microfono compare quando si apre la tastiera.' : 'Spenta.';
  const ai = document.getElementById('psDictAi');
  if (ai) ai.classList.toggle('on', premium && SETTINGS.dictationAi === true);
  const ta = document.getElementById('psDictAiTxt');
  if (ta && !premium) ta.textContent = 'Serve Premium. Quello che detti torna sistemato: punteggiatura, a capo, elenchi.';
  try{ if (typeof drvRiga === 'function') drvRiga(); }catch(_){ }
}
async function settingsToggleDictation(){
  /* dictationScelta: e' l'utente che sceglie (un "spenta" arrivato da un backup vecchio non conta, Rules.java) */
  await settingsSave({ dictation: SETTINGS.dictation === false, dictationScelta: true });
  personalizePaintDictation();
}
async function settingsToggleDictationAi(){
  const premium = (typeof Premium !== 'undefined') && Premium.isPremium();
  if (!premium){ toast('Gli appunti AI sono Premium'); if (typeof pwOpen === 'function') pwOpen(); return; }
  await settingsSave({ dictationAi: !(SETTINGS.dictationAi === true) });
  personalizePaintDictation();
  /* 0.9.321: accendendola, una volta sola, si chiede se usarla anche per la voce dell'Io futuro */
  try{ if (SETTINGS.dictationAi === true && typeof drvConsensoApri === 'function' && localStorage.getItem('fl_voce_dettatura') === null) drvConsensoApri(); }catch(_){ }
}
const REF_MINS = [[15, '15 min'], [25, '25 min'], [45, '45 min'], [60, '1 ora']];
function refPaint(){
  if (typeof refRules !== 'function') return;
  const r = refRules();
  const sw = document.getElementById('psRefSess'); if (sw) sw.classList.toggle('on', r.needSession !== false);
  const host = document.getElementById('psRefMin');
  if (host) host.innerHTML = REF_MINS.map(function(c){ return '<button type="button" class="sev-chip' + (r.minMin === c[0] ? ' on' : '') + '" onclick="refSetMin(' + c[0] + ')">' + c[1] + '</button>'; }).join('');
  const by = document.getElementById('psRefBy'); if (by) by.value = r.planBy || '00:00';
  const t = document.getElementById('psRefByTxt'); if (t) t.textContent = (r.planBy && r.planBy !== '00:00') ? 'entro le ' + r.planBy : 'entro mezzanotte';
}
function refToggleSession(){ const r = refRules(); refSave({ needSession: !(r.needSession !== false) }); refPaint(); toast(refRules().needSession ? 'Il punto vuole la sessione' : 'Basta la spunta: sei tu l\'arbitro'); }
function refSetMin(m){ refSave({ minMin: m }); refPaint(); }
function refSetPlanBy(v){ refSave({ planBy: v || '00:00' }); refPaint(); }
function personalizePaintChime(){
  const b = document.getElementById('psMantraChime');
  if (b) b.classList.toggle('on', SETTINGS.mantraChime !== false);
}
async function settingsToggleMantraChime(){
  const next = !(SETTINGS.mantraChime !== false);
  await settingsSave({ mantraChime: next });
  personalizePaintChime();
}
/* ---- quando il mantra aspetta (0.9.218) ----
   mantraProdOn: di serie spento, il mantra non compare dentro a un'app produttiva.
   mantraNavAuto: di serie acceso, con il navigatore davanti il suono parte da solo. */
function personalizePaintMantraWhen(){
  const p = document.getElementById('psMantraProd');
  if (p) p.classList.toggle('on', SETTINGS.mantraProdOn === true);
  const n = document.getElementById('psMantraNavAuto');
  if (n) n.classList.toggle('on', SETTINGS.mantraNavAuto !== false);
}
async function settingsToggleMantraProd(){
  try{ flVibra(12); }catch(_){ }
  const next = !(SETTINGS.mantraProdOn === true);
  mantraProdSync(true);
  await settingsSave({ mantraProdOn: next });
  personalizePaintMantraWhen();
}
async function settingsToggleMantraNavAuto(){
  try{ flVibra(12); }catch(_){ }
  await settingsSave({ mantraNavAuto: !(SETTINGS.mantraNavAuto !== false) });
  personalizePaintMantraWhen();
}
/* LE APP PRODUTTIVE, AL MOTORE.
   Le etichette (produttiva / neutra / distrattiva) e le loro fasce orarie vivono nella pagina
   (Report, localStorage). Il motore che decide quando mostrare il mantra e' nativo: gli si
   mandano le app produttive e le fasce, solo quando cambiano. Silenzioso: niente toast. */
function mantraProdSync(forza){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setSettings) return;
    if (typeof insCats !== 'function') return;
    const base = insCats(null) || {};
    const fasce = (typeof insFasce === 'function') ? (insFasce() || {}) : {};
    const out = { base: Object.keys(base).filter(function(p){ return base[p] === 'prod'; }).sort(), fasce: fasce };
    const json = JSON.stringify(out);
    let prima = '';
    try{ prima = localStorage.getItem('fl_mantra_prod_sent') || ''; }catch(_){ }
    if (!forza && json === prima) return;
    Promise.resolve(NATIVE.setSettings({ mantraProdApps: json })).then(function(){
      try{ localStorage.setItem('fl_mantra_prod_sent', json); }catch(_){ }
    }).catch(function(){ });
  }catch(_){ }
}
setTimeout(function(){ mantraProdSync(false); }, 6000);
document.addEventListener('fl:screen', function(){ mantraProdSync(false); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) mantraProdSync(false); });
function personalizePaintGoal(){
  const host = document.getElementById('psGoal'); if(!host) return;
  const cur = goalMin();
  host.innerHTML = GOAL_CHOICES.map(function(c){
    return '<button type="button" class="sev-chip' + (cur === c[0] ? ' on' : '') + '" onclick="personalizeSetGoal(' + c[0] + ')">' + c[1] + '</button>';
  }).join('');
}
function personalizeSetGoal(min){
  try{ localStorage.setItem('fl_goal_min', String(min)); }catch(_){ }
  // the service colours its usage message against the same goal
  if(NATIVE && NATIVE.setSettings){ try{ NATIVE.setSettings({ dailyGoalMin: min }); }catch(_){ } }
  personalizePaintGoal();
  if(typeof refreshHeaderToday === 'function') refreshHeaderToday();
  toast(min ? 'Obiettivo: ' + GOAL_CHOICES.filter(function(c){ return c[0] === min; })[0][1] + ' al giorno' : 'Nessun obiettivo');
}
(function psStyle(){
  const st = document.createElement('style');
  st.textContent = '.ps-block{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:10px}'
    + '.ps-block > b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}'
    + '.ps-dot{display:inline-block;width:10px;height:10px;border-radius:50%;vertical-align:middle;margin:0 2px}'
    + '.ps-dot.ok{background:#22B14C}.ps-dot.warn{background:#F5A623}.ps-dot.over{background:var(--red)}'
    + '.ps-sub{font:700 10.5px var(--font-body);letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin:22px 0 10px}'
    + '.ps-block{padding:18px}'
    + '.ps-prem{display:inline-block;margin-left:8px;padding:3px 9px;border-radius:99px;background:#E71D4F;color:#fff;font:800 10px var(--font-body);letter-spacing:.08em;text-transform:uppercase;vertical-align:middle}'
    + '.ps-how{margin-top:16px;display:flex;flex-direction:column;gap:10px}'
    + '.ps-how > div{font:500 13.5px/1.5 var(--font-body);color:var(--navy);padding:11px 14px;border-radius:12px;background:#F3F5F8}'
    + 'body.dark .ps-how > div{background:#0E1B33;color:#fff}'
    + '.ps-block > .hintline{padding:6px 0 2px !important;line-height:1.65}'
    + '.ps-mantra{margin:10px 0 4px;padding:12px 14px !important;background:#F4F9FF;border-radius:12px;font-style:italic;color:var(--navy)}'
    + 'body.dark .ps-mantra{background:#0E1E3A;color:#fff}'
    + '.ps-row{display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap}'
    + '.ps-row .fin{flex:1;min-width:120px;margin:0}'
    + '.ps-row .ghostmini{margin:0}'
    + '.ps-val{font:600 12px var(--font-body);color:var(--muted)}'
    + 'body.dark .ps-block{background:#12203A;border-color:#22345A}body.dark .ps-block > b{color:#fff}'
    /* LA RIGA CON UN ORARIO dentro a una card chiara. Prende i colori dal tema invece di
       scriverli: e' l'unica forma che sopravvive al passaggio in modalita' scura. */
    + '.set-timerow{display:flex;align-items:center;justify-content:space-between;gap:14px;'
    +   'margin-top:14px;padding:13px 15px;border-radius:14px;background:rgba(0,30,68,.05);cursor:pointer}'
    + 'body.dark .set-timerow{background:rgba(255,255,255,.07)}'
    + '.set-timerow > span{font:600 14px var(--font-body);color:var(--navy)}'
    + '.set-timerow input[type=time]{border:1px solid var(--line);border-radius:10px;padding:8px 10px;'
    +   'background:var(--card,#fff);color:var(--navy);font:700 15px var(--font-body);cursor:pointer}';
  document.head.appendChild(st);
})();
async function settingsSetUsageToast(min){
  if(min === -1){ const n = askMinutes(); if(n === null) return; min = n; }
  try{ if (min > 0) localStorage.setItem('fl_toast_wanted', String(min)); else localStorage.removeItem('fl_toast_wanted'); }catch(_){ }
  await settingsSave({ usageToastMin: min });
  settingsPaintUsageToast();
  const hint = document.getElementById('stUsageToastHint');
  if(hint){
    let granted = true;
    try{ if(NATIVE && NATIVE.getScreenTimeToday){ const t = await NATIVE.getScreenTimeToday(); granted = !!(t && t.granted); } }catch(_){ }
    hint.hidden = !(min > 0 && !granted);
  }
}
function settingsPaintScelte(){
  document.querySelectorAll('input[name="darkmode"]').forEach(function(r){ r.checked = r.value === darkMode(); });
  document.querySelectorAll('input[name="lang"]').forEach(function(r){ r.checked = r.value === langMode(); });
  document.querySelectorAll('input[name="weekstart"]').forEach(function(r){ r.checked = r.value === (flWeekStart() === 0 ? 'sun' : 'mon'); });
}
/* 0.9.288: la pagina si dipinge da QUALUNQUE strada ci si arrivi (prima solo dal menu: tornando indietro da un'altra
   pagina i pallini erano vuoti e gli interruttori spenti, e il primo tocco "accendeva" un valore gia' acceso) */
let SET_PAINT_T = 0;
document.addEventListener('fl:screen', function(e){
  if (e.detail === 's-settings'){ settingsPaintScelte(); clearTimeout(SET_PAINT_T); SET_PAINT_T = setTimeout(function(){ try{ settingsPaint(); }catch(_){ } }, 30); }
  if (e.detail === 's-personalize') setTimeout(function(){ try{ personalizePaint(); }catch(_){ } }, 30);
});
async function settingsPaint(){
  /* prima quello che si sa gia' (i valori in memoria), poi quello che dice il motore */
  settingsPaintScelte();
  try{ personalizePaintDictation(); settingsPaintUsageToast(); settingsPaintBubble(); }catch(_){ }
  await settingsLoad();
  try{ const s = document.getElementById('stSilTxt'); if (s && typeof silRiassunto === 'function') s.textContent = silRiassunto(); }catch(_){ }
  try{ personalizePaintDictation(); }catch(_){ }
  settingsPaintUsageToast();
  settingsPaintBubble();
  const r = document.getElementById('stRedirect'), m = document.getElementById('stMotivation');
  if(r) r.value = SETTINGS.redirectUrl || '';
  if(m) m.value = SETTINGS.motivation || '';
  document.querySelectorAll('input[name="darkmode"]').forEach(function(r){ r.checked = r.value === darkMode(); });
  document.querySelectorAll('input[name="lang"]').forEach(function(r){ r.checked = r.value === langMode(); });
  document.querySelectorAll('input[name="weekstart"]').forEach(function(r){ r.checked = r.value === (flWeekStart() === 0 ? 'sun' : 'mon'); });
}
async function settingsSaveFromForm(){
  /* 0.9.283: si salva solo quello che sta sulla pagina (l'indirizzo vive dentro "Apri l'indirizzo") */
  const r = document.getElementById('stRedirect'), m = document.getElementById('stMotivation'), patch = {};
  if (r){ let url = (r.value || '').trim(); if(url && !/^https?:\/\//i.test(url)) url = 'https://' + url; patch.redirectUrl = url; }
  if (m) patch.motivation = (m.value || '').trim();
  if (Object.keys(patch).length) await settingsSave(patch);
}

/* ---------------- Personalizza › Notifiche ----------------
   Il messaggio periodico con il tempo totale (StayFree) e i due permessi che riguardano le
   notifiche. Sta qui e non in Generale perché è di notifiche che parla. */
registerScreen('s-notifs',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Notifiche</b></div>' +
  '<div class="sect"><b>Messaggio tempo totale</b></div>' +
  '<p class="hintline" style="padding:0 2px 8px">Ogni tot minuti compare per qualche secondo, sopra qualsiasi app, un piccolo avviso con il tempo totale passato al telefono oggi. Un promemoria, non un blocco.</p>' +
  '<div class="sev-chips" id="stUsageToast"></div>' +
  '<p class="hintline" id="stUsageToastHint" style="padding:8px 2px 0" hidden>⚠️ Serve l\'accesso ai dati di utilizzo: <a href="#" onclick="openPerm(\'usage\');return false">abilitalo</a>, altrimenti l\'avviso non ha niente da dire.</p>' +
  '<div class="sect" style="margin-top:20px"><b>Notifiche bloccate</b></div>' +
  '<p class="hintline" style="padding:0 2px 8px">Quando un blocco è attivo, le notifiche delle app bloccate vengono tolte dalla tendina. Si accende e si spegne da «Cosa viene bloccato».</p>' +
  '<div class="setrow" onclick="blockPrefsOpen()"><span>⏸️</span><b>Blocco preferenze</b><small>Avvio · Notifiche</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="openPerm(\'notif\')"><span>🔔</span><b>Accesso alle notifiche</b><small id="stNotifPerm">—</small><span class="chev"></span></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

async function notifPrefsOpen(){
  goId('s-notifs');
  await settingsLoad();
  /* SI AUTORIPARA. Se l'utente lo aveva acceso (fl_toast_wanted) e il motore risponde zero
     dopo un aggiornamento, il valore voluto si rimanda al motore invece di mostrare un
     interruttore spento che l'utente non ha spento (segnalato due volte). */
  try{
    const voluto = +localStorage.getItem('fl_toast_wanted') || 0;
    if (voluto > 0 && !(+SETTINGS.usageToastMin > 0)){ await settingsSave({ usageToastMin: voluto }); }
  }catch(_){ }
  settingsPaintUsageToast();
  const el = document.getElementById('stNotifPerm');
  if(el && NATIVE && NATIVE.isNotificationAccessGranted){
    try{ const r = await NATIVE.isNotificationAccessGranted(); el.textContent = r && r.granted ? 'concesso' : 'non concesso'; }
    catch(_){ el.textContent = '—'; }
  }
}

/* ---------------- Personalizza › Blocco preferenze ---------------- */
registerScreen('s-blockprefs',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Blocco preferenze</b></div>' +
  '<div class="sect" style="margin-top:0"><b>Protezione</b></div>' +
  '<div class="ps-block">' +
    '<div class="blk-swrow"><span class="bp-ico"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2.5"/><rect x="11" y="7" width="6" height="8" rx="1.2" fill="currentColor" stroke="none"/></svg></span><div><b>Blocca le finestre fluttuanti</b><small>Un\'app bloccata non si riapre in una finestra piccola sopra le altre.</small></div>' +
    '<button class="switch" id="bpFluttuanti" onclick="bpProtezioneCambia(\'blockFloating\')"></button></div>' +
    '<div class="blk-swrow"><span class="bp-ico"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v8"/><path d="M6.6 6.6a8 8 0 1 0 10.8 0"/></svg></span><div><b>Proteggi dopo il riavvio</b><small>Appena riaccendi il telefono, DreamMap lo copre per circa un minuto mentre carica i blocchi.</small></div>' +
    '<button class="switch" id="bpRiavvio" onclick="bpProtezioneCambia(\'protectReboot\')"></button></div>' +
  '</div>' +
  '<div class="sect"><b>Cosa viene bloccato</b></div>' +
  '<p class="hintline" style="padding:0 2px 8px">Vale per il Blocco rapido e per i programmi che non lo sovrascrivono.</p>' +
  '<div class="setrow" onclick="openBlockSettings(\'quick\')"><span>⚙️</span><b>Avvio e notifiche</b><small id="bpWhat">—</small><span class="chev"></span></div>' +
  '<div class="sect" style="margin-top:18px"><b>Opzioni extra</b></div>' +
  '<div class="hintline">Valgono per tutti i tuoi blocchi.</div>' +
  '<div id="bpExtra"></div>' +
  /* 0.9.288, Andrea: "come in Blocco preferenze di AppBlock: Blocca le finestre fluttuanti e Proteggi dopo il riavvio" */
  '<div class="spacer"></div>', { back: 's-home' });
/* 0.9.292, Andrea: "le due opzioni non hanno nessuna icona: AppBlock ne ha una per ognuna" */
(function(){ const st = document.createElement('style'); st.textContent = '#s-blockprefs .switch.bloccato{opacity:.55}#s-blockprefs .bp-ico{flex:none;width:30px;display:flex;align-items:center;justify-content:center;color:#0075E3}body.dark #s-blockprefs .bp-ico{color:#4FB8FF}#s-blockprefs .blk-swrow > div{flex:1}'; document.head.appendChild(st); })();
function bpProtezionePaint(){
  const a = document.getElementById('bpFluttuanti'), b = document.getElementById('bpRiavvio');
  if (a) a.className = 'switch' + (SETTINGS.blockFloating !== false ? ' on' : '');
  if (b){ b.className = 'switch' + (SETTINGS.protectReboot === true ? ' on' : ''); b.classList.toggle('bloccato', SETTINGS.protectReboot === true && bpSeveraBlocca()); }
}
/* 0.9.335, Andrea: "in modalita' severa quel toggle non deve essere piu' modificabile: se l'ha attivato non si disattiva" */
function bpSeveraBlocca(){ try{ return typeof sevState !== 'undefined' && sevState && sevState.level > 0 && !sevState.canDisableNow; }catch(_){ return false; } }
async function bpProtezioneCambia(k){
  const ora = k === 'blockFloating' ? SETTINGS.blockFloating !== false : SETTINGS.protectReboot === true;
  if (k === 'protectReboot' && ora && bpSeveraBlocca()){ try{ flVibra([20, 40, 20]); toast('🔒 Con la modalità severa accesa la protezione dopo il riavvio resta accesa'); }catch(_){ } return; }
  const patch = {}; patch[k] = !ora;
  SETTINGS[k] = !ora; bpProtezionePaint();
  try{ flVibra(8); }catch(_){ }
  await settingsSave(patch);
  bpProtezionePaint();
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-blockprefs'){ bpProtezionePaint(); settingsLoad().then(bpProtezionePaint); } });

async function blockPrefsOpen(){
  goId('s-blockprefs');
  if(typeof loadExtra === 'function') await loadExtra();
  if(typeof renderExtraOptions === 'function') renderExtraOptions('bpExtra');
  const w = document.getElementById('bpWhat');
  if(w && typeof EXTRA !== 'undefined'){
    const bits = [];
    if(EXTRA.blockLaunch !== false) bits.push('Avvio');
    if(EXTRA.blockNotifications) bits.push('Notifiche');
    w.textContent = bits.length ? bits.join(' · ') : 'niente';
  }
}

/* ---------------- lock screen ---------------- */
registerScreen('s-lockscreen',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Schermata di blocco</b></div>' +
  /* 0.9.306, Andrea: in cima solo il titolo, centrato. Via la riga "In fondo resta sempre scritto da quale programma":
     chi vuole una schermata per un programma la crea. */
  '<p class="ls-titolo" style="margin:4px 0 14px;text-align:center;font:700 15px/1.4 var(--font-body);color:var(--ink)">Cosa vedi quando un blocco scatta.</p>' +
  '<div class="ls-scroll" id="lsStyles"></div>' +
  /* L'ANTEPRIMA VERA. Una card larga il 78% di un telefono e' un francobollo: fa vedere la
     disposizione, non l'effetto. Quella schermata pero' la si incontra in piedi, a schermo
     pieno, nel momento peggiore della giornata — ed e' li' che va guardata prima di sceglierla. */
  '<button type="button" class="ls-eye" onclick="lsFull()">\ud83d\udc41\ufe0f Vedi a schermo intero</button>' +
  '<div id="lsExtra"></div>' +
  '<div id="lsCustomBox" hidden></div>' +
  '<div id="lsPacksBox" hidden>' +
    '<div class="sect" style="margin-top:22px"><b>Che frasi</b></div>' +
    '<p class="hintline" style="padding:0 2px 12px">Il gruppo da cui pesca la schermata dinamica: cambia frase a ogni blocco, restando dentro al tema che scegli.</p>' +
    '<div id="lsPacks"></div>' +
  '</div>' +
  /* Reindirizzamento e frase personale: stanno QUI perché parlano della stessa schermata di
     cui parlano lo stile e il testo qui sopra — non in una pagina diversa. Si salvano da soli
     appena escono dal campo, come il resto della pagina. */
  '<div class="sect" style="margin-top:22px"><b>Dopo il blocco</b></div>' +
  /* 0.9.282: cosa succede alla scheda del browser bloccata. Vale per il blocco istantaneo e per i programmi:
     nel Full Focus la pagina non si tocca mai, compare solo la schermata che ti riporta alla sessione. */
  /* 0.9.283, Andrea: via "Lascia la pagina aperta" (riaprendo il browser il blocco ripartiva: non ha senso), e l'indirizzo
     sta DENTRO all'opzione che lo usa, con una riga sola di spiegazione. */
  '<div class="fld"><label>Cosa succede alla scheda bloccata nel browser</label><div class="pd-ops" id="pdOps"></div>' +
    '<div class="hint">Nel Full Focus la scheda non si tocca: compare solo la schermata che ti riporta alla sessione.</div></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

const LOCK_STYLES = [
  { k:'base',    name:'Base',     desc:'Lo scudo e il motivo del blocco.' },
  { k:'custom',  name:'Personalizzata', desc:'Icona, colore e testi scelti da te.' },
  { k:'dynamic', name:'Dinamica', desc:'Un mix di tutte le schermate, con frasi sempre nuove. Cambia a ogni blocco.' },
  { k:'text',    name:'Testo personalizzato', desc:'La frase che scrivi tu, come titolo della schermata.' },
  { k:'image',   name:'Immagine', desc:'La tua foto in alto, il motivo del blocco sotto.' },
  /* L'USCITA DI ROTTA (Premium): il prezzo prima, in giorni sul tuo arrivo. I giorni li calcola
     l'app dalle tue abitudini vere (porte.js: ptPedaggiSync), non un numero a caso. */
  /* 0.9.317, Andrea: "unisci carburante e uscita di rotta: prima il costo di adesso, poi quello nel futuro". Uno stile solo. */
  { k:'rotta',   name:'Uscita di rotta', desc:'Prima il carburante che perdi adesso, poi di quanto si sposta il tuo arrivo. Premium.', premium:true },
  /* 0.9.303, Andrea: tre stili nuovi (fuori-rotta.js e BlockOverlay). Il carburante esce dall'uscita di rotta e diventa
     uno stile suo; il contratto di abitudine; la partita, che c'e' solo con la regola dei tentativi accesa. */
  { k:'contratto',  name:'Contratto', desc:'La frase del tuo contratto di abitudine, il tentativo di oggi e la penitenza.' },
  { k:'partita',    name:'Partita', desc:'Il punteggio fra il vecchio e il nuovo te: a ogni tentativo segna il vecchio te.' }
];
/* 0.9.303: la Partita si sceglie solo con la regola "un punto al vecchio te a ogni tentativo" accesa */
function lsStiliVisibili(){
  return LOCK_STYLES.filter(function(s){ return s.k !== 'partita' || (typeof frPartitaDisponibile === 'function' && frPartitaDisponibile()); });
}
(function lsStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* scroll-padding + una card piu' stretta: la prima e l'ultima si vedono INTERE, e le
       vicine sbirciano di lato invece di sembrare mozzate a meta'. */
    /* ECCO DA DOVE VENIVA IL TAGLIO, e non era il testo ne' l'altezza della card.
       La schermata e' una colonna flessibile: quando la pagina non ci sta tutta, i suoi pezzi
       si LASCIANO STRINGERE, e il primo a cedere era proprio il carosello — 217px di altezza
       per 369px di contenuto. La card restava intera nel suo codice e mozzata sullo schermo,
       con la descrizione sotto che sembrava salirci sopra. flex:none vuol dire: questa fila
       tiene la sua altezza, e se la pagina non ci sta si scorre — che e' quello che le pagine
       fanno da sempre. */
    '.ls-scroll{flex:0 0 auto;display:flex;gap:12px;overflow-x:auto;padding:4px 2px 14px;margin:0 -2px;scrollbar-width:none;'
      + 'scroll-snap-type:x mandatory;scroll-padding-left:2px}',
    '.ls-scroll::-webkit-scrollbar{display:none}',
    /* 0.9.303, Andrea: "il nome dello stile sta per ultimo e piccolo sotto la card: deve stare in alto, grande, come titolo;
       tutte le card della stessa altezza; Cambia immagine e Rimuovi dentro il pannello dello stile". La card e' una colonna:
       il nome, l'anteprima che si allunga fino all'altezza della card piu' alta della fila, la descrizione, le azioni. */
    '.ls-card{flex:0 0 78%;scroll-snap-align:center;border:2px solid var(--line);border-radius:22px;background:#fff;padding:12px 10px 10px;cursor:pointer;position:relative;display:flex;flex-direction:column}',
    '.ls-card .ls-nome{text-align:center;font:800 20px/1.2 var(--font-display);color:var(--navy);margin:2px 6px 10px}',
    '.ls-card .prev{flex:1 0 auto;min-height:392px}',
    '.ls-azioni{display:flex;gap:8px;margin-top:6px;padding:0 2px}',
    '.ls-azioni button,.ls-inuso{box-sizing:border-box;height:44px}',
    '.ls-azioni button{flex:1;min-width:0;border-radius:12px;padding:0 8px;font:700 13px var(--font-body);cursor:pointer;border:1.5px solid var(--line);background:transparent;color:var(--navy)}',
    '.ls-azioni .ls-b1{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.ls-inuso{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:0 8px;font:800 13px var(--font-body);color:#0075E3}',
    '.ls-inuso svg{width:18px;height:18px;flex:none}',
    'body.dark .ls-card .ls-nome{color:#fff}',
    'body.dark .ls-azioni button{color:#fff;border-color:#2E4470}',
    'body.dark .ls-azioni .ls-b1{color:#fff;border-color:#0075E3}',
    'body.dark .ls-inuso{color:#8CC6FF}',
    '.ls-card.sel{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.22)}',
    /* NIENTE overflow:hidden, E UN'ALTEZZA CHE CRESCE.
       Il taglio veniva da li': su uno schermo da 360dp la card e' larga 270px, il testo del
       motivo va a tre righe e quello che non ci stava dentro ai 196px veniva rasato via —
       sembrava che la descrizione sotto si sovrapponesse alla card. Un'anteprima puo' essere
       piccola, non puo' essere mutilata: min-height fa da pavimento, non da soffitto. */
    '.ls-card .prev,.ls-full .prev{border-radius:16px;background:#001E44;color:#fff;min-height:238px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:20px 14px;position:relative}',
    '.ls-card .prev .emo,.ls-full .prev .emo{font-size:44px;margin-bottom:8px}',
    '.prev.rotta .rt-costo{font:900 46px/1 var(--font-display);color:#E63946;margin:12px 0 4px;letter-spacing:-.02em}',
    '.prev.rotta small{font:500 12px var(--font-body);color:rgba(255,255,255,.7)}.prev.rotta img{height:110px;margin:10px 0 4px}',
    '.ls-card .prev h4,.ls-full .prev h4{font:800 17px/1.25 var(--font-display);margin:0 0 6px;color:#fff}',
    '.ls-card .prev p,.ls-full .prev p{font:500 11px/1.45 var(--font-body);color:#C8EFFD;margin:0}',
    '.ls-card .prev .btn,.ls-full .prev .btn{margin-top:14px;background:#0075E3;color:#fff;border-radius:99px;padding:8px 16px;font:700 11px var(--font-body)}',
    '.ls-card .prev.img,.ls-full .prev.img{padding:0;justify-content:flex-end}',
    '.ls-card .prev.img .pic,.ls-full .prev.img .pic{flex:1;width:100%;min-height:130px;background:linear-gradient(160deg,#334E8C,#7C9CE3);background-size:cover;background-position:center}',
    '.ls-card .prev.img .under,.ls-full .prev.img .under{width:100%;border-top:1px solid rgba(200,239,253,.4);padding:12px 14px 16px}',
    '.ls-card .lbl{text-align:center;font:800 14px var(--font-display);color:var(--navy);margin:12px 0 2px}',
    /* Due righe di pavimento: senza, cambiare stile faceva saltare in alto e in basso tutta
       la fila, perche' «Base» sta su una riga e «Testo personalizzato» su due. */
    '.ls-card .dsc{text-align:center;font:500 11.5px/16px var(--font-body);color:var(--muted);padding:10px 6px 4px;min-height:48px}',
    '.ls-card .chk{position:absolute;top:14px;right:14px;width:22px;height:22px;border-radius:50%;background:#0B84FF;color:#fff;font:800 13px var(--font-body);display:none;align-items:center;justify-content:center}',
    '.ls-card.sel .chk{display:flex}',
    'body.dark .ls-card{background:#12203A;border-color:#22345A}',
    'body.dark .ls-card .lbl{color:#fff}',
    '.ls-eye{flex:0 0 auto;display:block;width:100%;margin:0 0 4px;border:1.5px solid var(--line);border-radius:14px;'
      + 'background:transparent;color:var(--navy);font:700 13.5px var(--font-body);padding:13px 16px;cursor:pointer}',
    'body.dark .ls-eye{color:#fff;border-color:#22345A}',
    /* A schermo intero e' la stessa anteprima, ingrandita: lo stesso pezzo di codice, cosi'
       quello che si vede qui e quello che si e' visto nella card non possono divergere. */
    '.ls-full{position:fixed;inset:0;z-index:9999;background:#001E44;animation:lsFullIn .22s ease-out}',
    '@keyframes lsFullIn{from{opacity:0;transform:scale(.97)}to{opacity:1;transform:none}}',
    '.ls-full .prev{height:100%;min-height:100%;border-radius:0;padding:40px 28px;justify-content:center}',
    '.ls-full .prev .emo{font-size:76px;margin-bottom:18px}',
    '.ls-full .prev h4{font-size:27px;line-height:1.24;margin-bottom:12px}',
    '.ls-full .prev p{font-size:14px}',
    '.ls-full .prev .btn{margin-top:26px;padding:13px 26px;font-size:14px}',
    '.ls-full .prev.img .pic{min-height:52vh}',
    '.ls-full .prev.img .under{padding:22px 26px 30px}',
    '.ls-x{position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:14px;width:40px;height:40px;'
      + 'border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font:700 17px var(--font-body);cursor:pointer}',
    '.ls-full .ls-foot{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 18px);'
      + 'text-align:center;font:600 11.5px var(--font-body);color:rgba(200,239,253,.62)}'
  ].join('\n');
  document.head.appendChild(st);
})();

function lsPreview(k){
  const phrase = (SETTINGS.motivation || '').trim() || 'Il futuro dipende da quello che fai oggi.';
  const reason = 'Instagram è bloccata dal programma "Serale"';
  if(k === 'custom' && typeof lcAnteprimaHtml === 'function') return lcAnteprimaHtml(lcCfgGlobale(), false);
  if(k === 'dynamic') return '<div class="prev"><div class="emo">🏁</div><h4>Procrastinazione bloccata, hai vinto!</h4><p>' + esc(reason) + '</p><span class="btn">Torna a quello che conta</span></div>';
  if(k === 'text') return '<div class="prev"><div style="font:800 34px var(--font-display);color:#C8EFFD;line-height:1">“</div><h4>' + esc(phrase) + '</h4><p>' + esc(reason) + '</p><span class="btn">Torna a quello che conta</span></div>';
  /* 0.9.298: la schermata fuori rotta rifatta (fuori-rotta.js): carburante, card dell'arrivo di Dream, combo e voti */
  if(k === 'rotta' && typeof frPrezzoAnteprimaHtml === 'function') return frPrezzoAnteprimaHtml();
  if(k === 'rotta' && typeof frAnteprimaHtml === 'function') return frAnteprimaHtml();
  /* 0.9.303: carburante, contratto e partita (fuori-rotta.js) */
  if(k === 'carburante' && typeof frCarbAnteprimaHtml === 'function') return frCarbAnteprimaHtml();
  if(k === 'contratto' && typeof frContrattoAnteprimaHtml === 'function') return frContrattoAnteprimaHtml();
  if(k === 'partita' && typeof frPartitaAnteprimaHtml === 'function') return frPartitaAnteprimaHtml();
  if(k === 'image') return '<div class="prev img"><div class="pic"' + (SETTINGS.blockImage ? ' style="background-image:url(' + SETTINGS.blockImage.replace(/"/g, '') + ')"' : '') + '></div><div class="under"><h4 style="font-size:15px">Instagram è bloccata</h4><p>dal programma "Serale" · 3 tentativi oggi</p><span class="btn">Torna a quello che conta</span></div></div>';
  /* LO SCUDO, NON IL PUNTO ROSSO. Un cerchio rosso al centro dello schermo e' il segnale di
     «hai sbagliato qualcosa» — e questa schermata non l'ha messa un antivirus, l'hai messa tu
     per proteggerti. Lo scudo dice la stessa cosa dalla parte giusta. */
  return '<div class="prev"><div class="emo">\ud83d\udee1\ufe0f</div><h4>Bloccato da DreamMap</h4><p>' + esc(reason) + '</p><span class="btn">Torna a quello che conta</span></div>';
}

/* ---------------------------------------------------------------------------------------
   L'ANTEPRIMA A SCHERMO INTERO

   Scegliere una schermata di blocco da un francobollo largo 270px e' come scegliere un quadro
   guardando la miniatura: si vede la disposizione, non l'effetto. E l'effetto e' tutto quello
   che questa schermata deve fare — compare quando la mano si e' gia' mossa, e ha due secondi.
   --------------------------------------------------------------------------------------- */
function lsFull(k){
  lsFullClose();
  const st = k || (typeof SETTINGS !== 'undefined' && SETTINGS.lockStyle) || 'base';
  const box = document.createElement('div');
  box.className = 'ls-full';
  box.id = 'lsFullBox';
  box.innerHTML = lsPreview(st)
    + '<button type="button" class="ls-x" onclick="lsFullClose()" aria-label="Chiudi">\u2715</button>'
    + '<div class="ls-foot">Anteprima \u00b7 tocca \u2715 per tornare indietro</div>';
  document.body.appendChild(box);
  /* Il tasto indietro del telefono chiude l'anteprima invece di uscire dalla pagina: qui
     dentro l'unico gesto sensato e' tornare da dove si veniva. */
  try{ window.addEventListener('popstate', lsFullClose, { once: true }); history.pushState({ lsFull: 1 }, ''); }catch(_){ }
}

function lsFullClose(){
  const b = document.getElementById('lsFullBox');
  if (b) b.remove();
}
async function lockScreenPaint(){
  await settingsLoad();
  const r = document.getElementById('stRedirect'), m = document.getElementById('stMotivation');
  if(r) r.value = SETTINGS.redirectUrl || '';
  if(m) m.value = SETTINGS.motivation || '';
  pdPaint();
  try{ if (typeof lsCustomPaint === 'function') lsCustomPaint(); }catch(_){ }
  const host = document.getElementById('lsStyles'); if(!host) return;
  const stili = lsStiliVisibili();
  let cur = SETTINGS.lockStyle || 'base';
  /* la Partita scelta e poi la regola spenta: il telefono disegna la Base, e qui si vede la Base */
  if (!stili.some(function(s){ return s.k === cur; })) cur = 'base';
  const spunta = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  const azioni = function(s){
    if (s.k !== cur) return '<div class="ls-azioni"><button type="button">Usa questo stile</button></div>';
    if (s.k === 'image') return '<div class="ls-azioni"><button type="button" class="ls-b1" onclick="event.stopPropagation();lockPick()">' + (SETTINGS.blockImage ? 'Cambia immagine' : 'Scegli immagine') + '</button>'
      + (SETTINGS.blockImage ? '<button type="button" onclick="event.stopPropagation();lockClear()">Rimuovi</button>' : '') + '</div>';
    return '<div class="ls-azioni"><span class="ls-inuso">' + spunta + 'Stile in uso</span></div>';
  };
  host.innerHTML = stili.map(function(s){
    return '<div class="ls-card' + (s.k === cur ? ' sel' : '') + '" data-k="' + s.k + '" onclick="lockPickStyle(\'' + s.k + '\')">'
      + '<b class="ls-nome">' + s.name + '</b>' + lsPreview(s.k) + '<div class="dsc">' + s.desc + '</div>' + azioni(s) + '</div>';
  }).join('');
  const extra = document.getElementById('lsExtra'); if(!extra) return;
  if(cur === 'image'){
    /* 0.9.303: Cambia immagine e Rimuovi stanno dentro la card dello stile */
    extra.innerHTML = '';
  }else if(cur === 'text'){
    /* IL CAMPO COMPARE CON LO STILE CHE LO USA, e solo con quello: una casella per una frase
       che quello stile non mostrera' mai e' una domanda senza conseguenza. */
    extra.innerHTML = '<div class="fld" style="margin-top:6px"><label>La tua frase</label>'
      + '<input class="fin" id="stMotivation" placeholder="es. Il futuro dipende da quello che fai oggi." maxlength="120" autocomplete="off" onchange="settingsSaveFromForm()">'
      + '<div class="hint">È il titolo della schermata di blocco. Senza, la schermata torna alla Base.</div></div>';
    const f = document.getElementById('stMotivation');
    if (f) f.value = SETTINGS.motivation || '';
  }else if(cur === 'rotta'){
    /* 0.9.306, Andrea: IL RICALCOLO SOTTO GLI OCCHI e' sempre acceso, niente interruttore e niente righe di spiegazione.
       Chi l'aveva spento lo ritrova acceso (lockRottaLiveForza; il nativo, Rules.lockRottaLive, risponde sempre si'). */
    extra.innerHTML = '';
    lockRottaLiveForza();
  }else{
    /* 0.9.263: con la Dinamica, l'interruttore delle frasi sul tuo obiettivo (Premium) */
    extra.innerHTML = '';
  }

  /* I temi: sono la schermata dinamica, quindi stanno qui e si vedono solo quando quella
     schermata e' quella scelta. */
  const packs = document.getElementById('lsPacksBox');
  if (packs){
    packs.hidden = cur !== 'dynamic';
    if (!packs.hidden && typeof lpPaint === 'function') lpPaint('lsPacks');
  }
  const sel = host.querySelector('.ls-card.sel');
  if(sel && sel.scrollIntoView) try{ sel.scrollIntoView({ block:'nearest', inline:'center' }); }catch(_){ }
}
/* 0.9.306: il ricalcolo sotto gli occhi e' sempre acceso. Chi l'aveva spento con l'interruttore di prima lo ritrova acceso. */
async function lockRottaLiveForza(){
  if (SETTINGS.lockRottaLive === true) return;
  SETTINGS.lockRottaLive = true;
  if(NATIVE && NATIVE.setSettings){ try{ await NATIVE.setSettings({ lockRottaLive: true }); }catch(_){ } }
}
async function lockPickStyle(k){
  const st = LOCK_STYLES.filter(function(x){ return x.k === k; })[0];
  if (st && st.premium && !(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium())){
    toast('Uscita di rotta è una schermata Premium');
    if (typeof premiumBuy === 'function') premiumBuy();
    return;
  }
  /* 0.9.303: senza un contratto di abitudine firmato la schermata Contratto non ha niente di vero da dire */
  if (k === 'contratto' && !(typeof frContrattoAttivo === 'function' && frContrattoAttivo())){
    toast('Prima firma il tuo contratto di abitudine');
    if (typeof ctrApri === 'function') ctrApri();
    return;
  }
  SETTINGS.lockStyle = k;
  if(NATIVE && NATIVE.setSettings){ try{ await NATIVE.setSettings({ lockStyle: k }); }catch(_){ } }
  await lockScreenPaint();
  if(k === 'image' && !SETTINGS.blockImage) lockPick();
}
async function lockPick(){
  if(!NATIVE || !NATIVE.pickBlockImage){ toast('Disponibile nell\'app installata'); return; }
  try{
    const r = await NATIVE.pickBlockImage();
    if(r && r.blockImage){
      SETTINGS.blockImage = r.blockImage;
      SETTINGS.lockStyle = 'image';
      try{ await NATIVE.setSettings({ lockStyle: 'image' }); }catch(_){ }
      toast('Immagine impostata'); lockScreenPaint();
    }
  }catch(e){ if(!e || e.code !== 'cancelled') toast(e && e.message ? e.message : 'Immagine non caricata'); }
}
async function lockClear(){
  if(NATIVE && NATIVE.setSettings){ try{ await NATIVE.setSettings({ blockImage: '', lockStyle: 'base' }); }catch(_){ } }
  SETTINGS.blockImage = ''; SETTINGS.lockStyle = 'base'; lockScreenPaint(); toast('Sfondo rimosso');
}

/* ---------------- Blocco in-App (StayFree's "Blocco Funzionalità") ----------------
   One screen, one app per box, one switch per feature, a daily budget and — where the engine
   has one — an exception. Everything is read from and written to the engine's catalog: the
   list of features is native (FeatureBlocks.java), because that is where the detection is.
   0.9.300, Andrea: le icone vere delle app al posto delle emoji, un testo iniziale corto, in
   ogni card il grafico ad anello degli ultimi 7 giorni per sezione (sezioni-social.js) sopra
   agli interruttori. "Ultimi blocchi riconosciuti" e "Una funzione non viene riconosciuta"
   stanno solo in Contatta l'assistenza, dopo il motivo "Problema di blocco". */
const IA_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
registerScreen('s-inapp',
  '<div class="topbar"><button class="iconbtn" aria-label="Indietro" onclick="inappIndietro()">' + IA_INDIETRO + '</button><b class="blk-title">Blocco Funzionalità</b></div>' +
  '<p class="hintline ia-intro">Blocca solo le parti delle app che ti rubano tempo, come Reels e Shorts. Il resto dell\'app resta libero.</p>' +
  /* 0.9.301, Andrea: "se ho Instagram bloccato ma un amico mi manda un reel su WhatsApp, voglio poterlo vedere, solo
     quel reel". Il motore (FocusLockService.apriContenutoAmico) lo apre in ContenutoAmicoActivity; acceso di serie. */
  '<div class="ia-app ia-amici"><div class="ia-feat"><div class="ia-feat-top"><span class="ia-fico"><svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 5.5h15v10h-8l-4.5 3.5v-3.5H4.5z"/><path d="M10.3 8.3v4.4l3.8-2.2z" fill="currentColor" stroke="none"/></svg></span>' +
    '<div><b>Apri i contenuti che ti mandano gli amici</b><small>Anche con l\'app bloccata vedi il reel o il video che ti hanno mandato, da solo, dentro DreamMap.</small></div>' +
    '<button class="switch" id="iaAmici" aria-label="Apri i contenuti che ti mandano gli amici" onclick="inappAmiciCambia()"></button></div></div></div>' +
  '<div id="inappList"><div class="hintline">Leggo…</div></div>' +
  '<div class="spacer"></div>', { back: function(){ return inappDa(); } });
/* DA DOVE SI E' ARRIVATI (0.9.188): dalla pagina «Proteggi i tuoi sogni» si torna li', non
   alla scheda Sogno. */
let INAPP_DA = 's-home';
function inappDa(){ return INAPP_DA || 's-home'; }
function inappIndietro(){ const d = inappDa(); if (d === 's-blocco' && typeof blPaginaApri === 'function') blPaginaApri(); else goId(d); }

const INAPP_LIMITS = [[0,'Sempre'],[5,'5 min'],[15,'15 min'],[30,'30 min'],[60,'1 ora']];
let INAPP = { catalog: [], settings: {}, recent: [], sez: null };
let INAPP_OPEN = {};

async function inappOpen(){
  try{ const qui = order[cur]; INAPP_DA = (qui && qui !== 's-inapp') ? qui : 's-home'; }catch(_){ INAPP_DA = 's-home'; }
  goId('s-inapp');
  inappAmiciPaint();
  try{ settingsLoad().then(inappAmiciPaint); }catch(_){ }
  if(!NATIVE || !NATIVE.getFeatureBlocks){
    document.getElementById('inappList').innerHTML = '<div class="hintline">Disponibile nell\'app installata.</div>'; return;
  }
  try{ const r = await NATIVE.getFeatureBlocks(); INAPP.catalog = r.catalog || []; INAPP.settings = r.settings || {}; INAPP.recent = r.recent || []; }
  catch(e){ toast(e && e.message ? e.message : 'Lettura non riuscita'); }
  inappPaint();
  /* il tempo per sezione degli ultimi 7 giorni (da mezzanotte di sei giorni fa): arriva dopo, l'anello si ridisegna */
  try{
    if (typeof socLeggi === 'function'){
      const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - 6);
      INAPP.sez = await socLeggi(d.getTime(), Date.now());
      inappPaint();
    }
  }catch(_){ }
}
/* "Apri i contenuti che ti mandano gli amici": acceso finche' non lo si spegne (friendLinks !== false) */
function inappAmiciPaint(){
  const b = document.getElementById('iaAmici');
  if (b) b.className = 'switch' + (SETTINGS.friendLinks !== false ? ' on' : '');
}
async function inappAmiciCambia(){
  const ora = SETTINGS.friendLinks !== false;
  SETTINGS.friendLinks = !ora; inappAmiciPaint();
  try{ flVibra(8); }catch(_){ }
  await settingsSave({ friendLinks: !ora });
  inappAmiciPaint();
}
function inappSetting(key){ return INAPP.settings[key] || { on:false, limitMin:0, exceptions:{} }; }
async function inappSave(){
  if(!NATIVE || !NATIVE.setFeatureBlocks) return;
  try{ const r = await NATIVE.setFeatureBlocks({ settings: INAPP.settings }); INAPP.catalog = r.catalog || INAPP.catalog; INAPP.settings = r.settings || INAPP.settings; INAPP.recent = r.recent || INAPP.recent; }
  catch(e){ toast(e && e.message ? e.message : 'Non salvato'); }
  inappPaint();
}
/* 0.9.312: con la modalita' severa attiva da qui si poteva spegnere una funzione bloccata (nella lista di blocco no).
   Stringere si', allentare no, come per i programmi. */
function inappChiuso(s){
  if (!s.on || typeof blkEditLocked !== 'function' || !blkEditLocked()) return false;
  try{ toast('Modalità severa attiva: i blocchi delle funzioni non si possono togliere'); }catch(_){ }
  try{ inappPaint(); }catch(_){ }
  return true;
}
function inappToggle(key){
  const s = inappSetting(key); if (inappChiuso(s)) return; s.on = !s.on; INAPP.settings[key] = s; inappSave();
}
function inappLimit(key, min){
  const s = inappSetting(key); if (inappChiuso(s)) return; s.limitMin = min; INAPP.settings[key] = s; inappSave();
}
function inappException(key, exKey){
  const s = inappSetting(key); if (inappChiuso(s)) return; s.exceptions = s.exceptions || {}; s.exceptions[exKey] = !s.exceptions[exKey]; INAPP.settings[key] = s; inappSave();
}
function inappToggleApp(pkg){ INAPP_OPEN[pkg] = !INAPP_OPEN[pkg]; inappPaint(); }

/* L'icona a sinistra di ogni interruttore, come nel modello: una per funzione. */
const IA_FICO = (function(){
  const sv = function(d){ return '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>'; };
  const storie = sv('<circle cx="12" cy="12" r="8.5" stroke-dasharray="3.2 2.6"/>');
  const reels = sv('<rect x="3.5" y="4" width="17" height="16" rx="4"/><path d="M3.5 9h17M8.5 4l2.5 5M13.5 4l2.5 5"/><path d="M10.5 12.2v4.6l4-2.3z" fill="currentColor" stroke="none"/>');
  const cerca = sv('<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>');
  const home = sv('<path d="M4 11l8-6.5 8 6.5V20h-5.5v-5h-5v5H4z"/>');
  const commenti = sv('<path d="M4.5 5.5h15v10h-8l-4.5 3.5v-3.5H4.5z"/>');
  const pip = sv('<rect x="3" y="5" width="18" height="14" rx="2.5"/><rect x="12" y="11" width="7" height="6" rx="1.2" fill="currentColor" stroke="none"/>');
  const canali = sv('<path d="M4 10v4h3l6 4V6L7 10z"/><path d="M17 9.5a3.5 3.5 0 010 5"/>');
  const ai = sv('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4" />');
  const negozio = sv('<path d="M5 8h14l-1.2 11.5H6.2z"/><path d="M9 8V6.5a3 3 0 016 0V8"/>');
  const play = sv('<rect x="4" y="3.5" width="16" height="17" rx="3"/><path d="M10 9v6l5-3z" fill="currentColor" stroke="none"/>');
  return {
    'youtube.shorts': reels, 'youtube.comments': commenti, 'youtube.pip': pip,
    'instagram.reels': reels, 'instagram.stories': storie, 'instagram.explore': cerca, 'instagram.feed': home,
    'whatsapp.status': storie, 'whatsapp.channels': canali, 'whatsapp.metaai': ai,
    'facebook.reels': reels, 'facebook.stories': storie, 'facebook.marketplace': negozio,
    'tiktok.feed': play, 'tiktok.shop': negozio, 'tiktok.comments': commenti
  };
})();

function inappPaint(){
  const host = document.getElementById('inappList'); if(!host) return;
  const apps = [];
  INAPP.catalog.forEach(function(f){ let a = apps.filter(x => x.pkg === f.pkg)[0]; if(!a){ a = { pkg:f.pkg, name:f.app, installed:f.installed, feats:[] }; apps.push(a); } a.feats.push(f); });
  if(!apps.length){ host.innerHTML = '<div class="hintline">Nessuna app in catalogo.</div>'; return; }
  host.innerHTML = apps.map(function(a){
    const onCount = a.feats.filter(f => inappSetting(f.key).on).length;
    const open = !!INAPP_OPEN[a.pkg];
    const icon = (typeof socIcona === 'function') ? socIcona(a.pkg, 'soc-ico ia-ico') : '';
    let html = '<div class="ia-app' + (open ? ' open' : '') + '"><div class="ia-head" onclick="inappToggleApp(\'' + a.pkg + '\')">'
      + icon + '<b>' + esc(a.name) + (onCount ? ' <em>(' + onCount + ')</em>' : '') + '</b>'
      + (a.installed ? '' : '<small>non installata</small>') + '<i class="ub-caret"></i></div>';
    if(open){
      html += '<div class="ia-body">';
      if (typeof socGrafico7 === 'function' && typeof socE === 'function' && socE(a.pkg)) html += socGrafico7(a.pkg, INAPP.sez);
      html += a.feats.map(function(f){
        const s = inappSetting(f.key);
        let row = '<div class="ia-feat"><div class="ia-feat-top"><span class="ia-fico">' + (IA_FICO[f.key] || '') + '</span><div><b>' + esc(f.label) + '</b><small>' + esc(f.desc) + '</small></div>'
          + '<button class="switch' + (s.on ? ' on' : '') + '" onclick="inappToggle(\'' + f.key + '\')"></button></div>';
        if(s.on && !f.noLimit){
          row += '<div class="ia-limit"><span>Limite giornaliero</span>' + INAPP_LIMITS.map(function(l){
            return '<button type="button" class="sev-chip' + ((s.limitMin || 0) === l[0] ? ' on' : '') + '" onclick="inappLimit(\'' + f.key + '\',' + l[0] + ')">' + l[1] + '</button>';
          }).join('') + '</div>';
          if(s.limitMin > 0) row += '<div class="ia-used">Oggi: ' + (f.usedTodayMin || 0) + ' min su ' + s.limitMin + '</div>';
          if(f.exceptionKey) row += '<label class="ia-exc"><input type="checkbox"' + ((s.exceptions || {})[f.exceptionKey] ? ' checked' : '') + ' onchange="inappException(\'' + f.key + '\',\'' + f.exceptionKey + '\')"> ' + esc(f.exceptionLabel) + '</label>';
        }
        return row + '</div>';
      }).join('') + '</div>';
    }
    return html + '</div>';
  }).join('');
  if (typeof socIconeRiempi === 'function') socIconeRiempi(host);
}
(function iaStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.ia-intro{padding:0 2px 16px;font-size:14px;line-height:1.5}',
    '.ia-app{background:#fff;border:1px solid var(--line);border-radius:16px;margin-bottom:12px;overflow:hidden}',
    '.ia-head{display:flex;align-items:center;gap:14px;padding:14px 16px;cursor:pointer}',
    '.ia-head .ia-ico{width:34px;height:34px;border-radius:9px}',
    '.ia-head b{flex:1;font:700 15px var(--font-body);color:var(--navy)}',
    '.ia-head b em{font-style:normal;color:var(--muted);font-weight:600}',
    '.ia-head small{font:600 10.5px var(--font-body);color:var(--faint)}',
    '.ia-app.open .ia-head .ub-caret{transform:rotate(180deg)}',
    '.ia-body{border-top:1px solid var(--line);padding:0 16px 8px}',
    '.ia-feat{padding:14px 0;border-bottom:1px solid var(--line)}',
    '.ia-feat:last-child{border-bottom:0}',
    '.ia-feat-top{display:flex;align-items:center;gap:14px}',
    '.ia-feat-top > div{flex:1;min-width:0}',
    '.ia-fico{flex:none;width:26px;height:26px;display:grid;place-items:center;color:var(--navy);opacity:.85}',
    '.ia-feat b{display:block;font:700 14px var(--font-body);color:var(--navy)}',
    '.ia-feat small{display:block;font:500 11.5px/1.45 var(--font-body);color:var(--muted);margin-top:2px}',
    '.ia-limit{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:12px 0 0 40px}',
    '.ia-limit > span{font:600 11px var(--font-body);color:var(--muted);width:100%}',
    '.ia-used{font:600 11px var(--font-body);color:var(--blue);margin:6px 0 0 40px}',
    '.ia-exc{display:flex;align-items:center;gap:8px;margin:10px 0 0 40px;font:600 12px var(--font-body);color:var(--navy)}',
    '.ia-exc input{accent-color:var(--blue);width:18px;height:18px}',
    '.ia-amici{padding:0 16px;flex:none}',
    '.ia-amici .ia-feat{border-bottom:0}',
    'body.dark .ia-app{background:#12203A;border-color:#22345A}',
    'body.dark .ia-body,body.dark .ia-feat{border-color:#22345A}',
    'body.dark .ia-head b,body.dark .ia-feat b,body.dark .ia-exc,body.dark .ia-fico{color:#fff}',
    'body.dark .ia-limit .sev-chip.on{background:#0075E3 !important;border-color:#0075E3 !important;color:#fff !important}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------------- feedback ---------------- */
const FL_BACKEND = 'https://meta-ai-media-buyer-production.up.railway.app';
/* CONTATTA L'ASSISTENZA (0.9.299). Andrea: "toccando Aiuto e feedback non voglio andare subito alla pagina: prima
   Contatta l'assistenza, Seleziona motivo (problema con Premium, problema di blocco, suggerimenti sulle funzionalita',
   altro), e solo dopo Aiuto e feedback. Lo sblocco di emergenza compare fra i motivi solo con la Modalita' severa
   accesa". Il motivo scelto entra nel messaggio, cosi' chi risponde sa gia' di cosa si parla. */
const AS_MOTIVI = [
  { k: 'premium', n: 'Problema con Premium' },
  { k: 'blocco', n: 'Problema di blocco' },
  { k: 'idee', n: 'Suggerimenti sulle funzionalità' },
  { k: 'altro', n: 'Altro' }
];
const AS_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
let AS_MOTIVO = null;
registerScreen('s-assistenza',
  '<div class="topbar"><button class="iconbtn" aria-label="Indietro" onclick="if(typeof flIndietro===\'function\')flIndietro();else goId(\'s-home\')">' + AS_INDIETRO + '</button><b class="blk-title">Contatta l\'assistenza</b></div>' +
  '<div class="as-wrap"><p class="as-sez">Seleziona motivo</p><div id="asMotivi"></div></div>' +
  '<div class="spacer"></div>', { back: 's-home' });
async function assistenzaApri(){
  goId('s-assistenza');
  assistenzaPaint();
  /* la severa si legge dal motore: se e' accesa compare lo sblocco di emergenza */
  try{ if (typeof sevLoadState === 'function'){ await sevLoadState(); assistenzaPaint(); } }catch(_){ }
}
function assistenzaPaint(){
  const box = document.getElementById('asMotivi'); if (!box) return;
  const severa = (typeof efSeveraAccesa === 'function') && efSeveraAccesa();
  box.innerHTML = AS_MOTIVI.map(function(m){
    return '<button type="button" class="as-motivo" onclick="assistenzaScegli(\'' + m.k + '\')">' + m.n + '</button>';
  }).join('') + (severa ? '<button type="button" class="as-motivo as-emg" onclick="assistenzaScegli(\'emergenza\')">Sblocco di emergenza</button>' : '');
}
function assistenzaScegli(k){
  if (k === 'emergenza'){ if (typeof emgFlussoApri === 'function') emgFlussoApri(); return; }
  AS_MOTIVO = AS_MOTIVI.filter(function(m){ return m.k === k; })[0] || null;
  goId('s-feedback');
  const et = document.getElementById('fbMotivo');
  if (et){ et.textContent = AS_MOTIVO ? AS_MOTIVO.n : ''; et.hidden = !AS_MOTIVO; }
  const t = document.getElementById('fbText');
  if (t) t.placeholder = k === 'premium' ? 'Cosa non va con Premium? Scrivici cosa vedi.'
    : k === 'blocco' ? 'Quale app o sito, e cosa succede quando dovrebbe bloccarsi?'
    : k === 'idee' ? 'Che funzione ti servirebbe? Raccontaci a cosa ti serve.'
    : 'Feedback, aiuto, richiesta di funzioni…';
  fbBloccoDipingi(); fbBloccoCarica();
}
/* PROBLEMA DI BLOCCO (0.9.300). Andrea: "Ultimi blocchi riconosciuti e Una funzione non viene
   riconosciuta devono comparire solo dentro Contatta l'assistenza, dopo il motivo Problema di
   blocco; copy piu' corto, e il pulsante Registra va ridisegnato bene". Un pulsante solo: si
   registra per 30 secondi mentre si apre la funzione, e quello che il telefono ha visto parte
   insieme al messaggio con Invia. Lo stato si vede sempre: pronto, in corso (con il tempo che
   scorre), fatto. */
const FB_PROBE_S = 30;
let FB_PROBE = { fino: 0, righe: [], recenti: [], timer: 0 };
function fbBloccoDipingi(){
  const box = document.getElementById('fbBlocco'); if (!box) return;
  const on = !!(AS_MOTIVO && AS_MOTIVO.k === 'blocco');
  box.hidden = !on;
  if (!on) return;
  const rec = (FB_PROBE.recenti || []).slice(0, 6);
  const resta = Math.max(0, Math.ceil((FB_PROBE.fino - Date.now()) / 1000));
  const inCorso = resta > 0;
  const fatto = !inCorso && FB_PROBE.righe.length > 0;
  const stato = inCorso ? 'incorso' : (fatto ? 'ok' : '');
  const pct = inCorso ? Math.round((1 - resta / FB_PROBE_S) * 100) : (fatto ? 100 : 0);
  const titolo = inCorso ? 'Sto registrando, apri la funzione' : (fatto ? 'Registrazione pronta' : 'Registra 30 secondi');
  const sotto = inCorso ? ('Mancano ' + resta + ' secondi')
    : (fatto ? FB_PROBE.righe.length + (FB_PROBE.righe.length === 1 ? ' schermata vista' : ' schermate viste') + ', parte con il messaggio'
    : 'Poi apri la funzione che non si blocca');
  box.innerHTML = '<p class="fb-b-sez">Ultimi blocchi riconosciuti</p>'
    + (rec.length
        ? '<div class="fb-b-lista">' + rec.map(function(l){ /* a schermo ora, app e funzione; il segnale tecnico (tab:, idText:...) parte solo nel messaggio */ return '<div>' + esc(String(l).split(' · ').filter(function(x){ return !/[:=]/.test(x) || /^\d{1,2}:\d{2}$/.test(x); }).join(' · ')) + '</div>'; }).join('') + '</div>'
        : '<p class="fb-b-txt">Qui compare ogni funzione fermata, con il segnale che l\'ha riconosciuta.</p>')
    + '<p class="fb-b-sez">Una funzione non si blocca?</p>'
    + '<p class="fb-b-txt">Registra mentre la apri: quello che DreamMap vede parte con il messaggio.</p>'
    + '<button type="button" class="fb-reg' + (stato ? ' ' + stato : '') + '" onclick="fbProbe()" style="--p:' + pct + '%">'
    +   '<span class="fb-reg-dot" aria-hidden="true">' + (fatto ? '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M5 12.5l4.2 4.2L19 7" fill="none" stroke="#fff" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '') + '</span>'
    +   '<span class="fb-reg-t"><b>' + titolo + '</b><small>' + sotto + '</small></span>'
    +   (fatto ? '<span class="fb-reg-di">Rifai</span>' : '')
    + '</button>';
}
async function fbBloccoCarica(){
  if (!(AS_MOTIVO && AS_MOTIVO.k === 'blocco')) return;
  if (NATIVE && NATIVE.featureProbeResult){
    try{
      const r = await NATIVE.featureProbeResult();
      FB_PROBE.recenti = (r && r.recent) || [];
      if (r && !r.recording && FB_PROBE.fino) FB_PROBE.righe = (r.lines) || [];
    }catch(_){ }
  } else if (NATIVE && NATIVE.getFeatureBlocks){
    try{ const r = await NATIVE.getFeatureBlocks(); FB_PROBE.recenti = (r && r.recent) || []; }catch(_){ }
  }
  fbBloccoDipingi();
}
async function fbProbe(){
  if (FB_PROBE.fino > Date.now()) return;
  if (!NATIVE || !NATIVE.featureProbeStart){ toast('Disponibile nell\'app installata'); return; }
  try{ await NATIVE.featureProbeStart({ seconds: FB_PROBE_S }); }catch(e){ toast(e && e.message ? e.message : 'Non riuscito'); return; }
  FB_PROBE.fino = Date.now() + FB_PROBE_S * 1000;
  FB_PROBE.righe = [];
  try{ flVibra(10); }catch(_){ }
  clearInterval(FB_PROBE.timer);
  FB_PROBE.timer = setInterval(function(){
    if (Date.now() >= FB_PROBE.fino){ clearInterval(FB_PROBE.timer); FB_PROBE.timer = 0; setTimeout(fbBloccoCarica, 600); }
    fbBloccoDipingi();
  }, 1000);
  fbBloccoDipingi();
}
/* Il testo che parte con il messaggio: i blocchi riconosciuti e le schermate viste, dopo le parole dell'utente. */
function fbBloccoAllegato(){
  if (!(AS_MOTIVO && AS_MOTIVO.k === 'blocco')) return '';
  const rec = FB_PROBE.recenti || [], righe = FB_PROBE.righe || [];
  if (!rec.length && !righe.length) return '';
  return '\n\n--- Diagnostica Blocco Funzionalità (' + (typeof APP_VERSION !== 'undefined' ? APP_VERSION : '') + ')\n'
    + (rec.length ? 'ULTIMI BLOCCHI\n' + rec.join('\n') + '\n' : '')
    + (righe.length ? 'SCHERMATE VISTE\n' + righe.slice(0, 250).join('\n') : '');
}
document.addEventListener('visibilitychange', function(){
  if (!document.hidden && FB_PROBE.fino && document.getElementById('fbBlocco') && !document.getElementById('fbBlocco').hidden) setTimeout(fbBloccoCarica, 400);
});
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.fb-blocco{margin:6px 0 18px}',
    '.fb-b-sez{margin:16px 0 8px;font:700 16px var(--font-display,var(--font-body));color:var(--blue,#0075E3)}',
    '.fb-b-txt{margin:0 0 12px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.fb-b-lista{background:var(--card,#fff);border:1px solid var(--line);border-radius:14px;padding:4px 14px}',
    '.fb-b-lista > div{font:600 12px/1.5 var(--font-body);color:var(--navy);padding:8px 0;border-bottom:1px solid var(--line);word-break:break-word}',
    '.fb-b-lista > div:last-child{border-bottom:0}',
    '.fb-reg{position:relative;overflow:hidden;display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:14px 16px;border-radius:16px;border:1.5px solid rgba(230,57,70,.35);background:var(--card,#fff);color:var(--navy);cursor:pointer;font:inherit}',
    '.fb-reg::before{content:"";position:absolute;left:0;top:0;bottom:0;width:var(--p,0%);background:rgba(230,57,70,.08);transition:width 1s linear}',
    '.fb-reg > *{position:relative}',
    '.fb-reg-dot{flex:none;width:30px;height:30px;border-radius:50%;background:#E63946;display:grid;place-items:center;box-shadow:0 0 0 5px rgba(230,57,70,.14)}',
    '.fb-reg.incorso .fb-reg-dot{animation:fbRecPulse 1.2s ease-in-out infinite}',
    '.fb-reg.ok{border-color:rgba(0,117,227,.35)}',
    '.fb-reg.ok::before{background:rgba(0,117,227,.07)}',
    '.fb-reg.ok .fb-reg-dot{background:#0075E3;box-shadow:0 0 0 5px rgba(0,117,227,.14)}',
    '.fb-reg-t{flex:1;min-width:0}',
    '.fb-reg-t b{display:block;font:700 15px var(--font-body);color:var(--navy)}',
    '.fb-reg-t small{display:block;font:500 12.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.fb-reg-di{flex:none;font:700 13px var(--font-body);color:var(--blue,#0075E3)}',
    '@keyframes fbRecPulse{0%,100%{box-shadow:0 0 0 4px rgba(230,57,70,.18)}50%{box-shadow:0 0 0 10px rgba(230,57,70,.05)}}',
    'body.dark .fb-b-lista{background:#12203A;border-color:#22345A}',
    'body.dark .fb-b-lista > div{color:#fff;border-color:#22345A}',
    'body.dark .fb-reg{background:#12203A}',
    'body.dark .fb-reg-t b{color:#fff}',
    'body.dark .fb-b-sez{color:#8CC6FF}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.as-wrap{padding:6px 2px 0}',
    '.as-sez{margin:6px 0 14px;font:700 17px var(--font-display,var(--font-body));color:var(--navy)}',
    '.as-motivo{display:block;width:100%;text-align:left;margin:0 0 12px;padding:22px 22px;border:0;border-radius:22px;background:var(--card,#fff);box-shadow:0 2px 10px rgba(0,30,68,.06);color:var(--navy);font:600 17px var(--font-body);cursor:pointer}',
    'body.dark .as-motivo{background:#1F2430;color:#fff;box-shadow:none}',
    '.as-motivo:active{transform:scale(.99)}',
    '.as-emg{color:#E63946}body.dark .as-emg{color:#FF8A93}',
    '.fb-motivo{display:inline-block;margin:0 0 12px;padding:6px 14px;border-radius:99px;background:rgba(0,117,227,.1);color:#0075E3;font:700 13px var(--font-body)}',
    'body.dark .fb-motivo{background:rgba(63,159,244,.16);color:#8CC6FF}'
  ].join('');
  document.head.appendChild(st);
})();

registerScreen('s-feedback',
  '<div class="topbar"><button class="iconbtn" aria-label="Indietro" onclick="if(typeof flIndietro===\'function\')flIndietro();else goId(\'s-assistenza\')">' + AS_INDIETRO + '</button><b class="blk-title">Aiuto e feedback</b></div>' +
  '<span class="fb-motivo" id="fbMotivo" hidden></span>' +
  '<div class="fld"><label>Indirizzo email</label><input class="fin" id="fbEmail" type="email" placeholder="per risponderti (facoltativo)" autocomplete="email"></div>' +
  '<div class="fld"><label>Messaggio</label><textarea class="fin" id="fbText" placeholder="Feedback, aiuto, richiesta di funzioni…"></textarea></div>' +
  '<div class="fb-blocco" id="fbBlocco" hidden></div>' +
  '<button class="cta" id="fbSend" onclick="feedbackSend()">Invia</button>' +
  '<p class="hintline" style="padding:12px 2px 0;text-align:center">Oppure scrivi a <a href="mailto:info@dreambrothers.it">info@dreambrothers.it</a></p>' +
  '<div class="spacer"></div>', { back: 's-assistenza' });

/* Sent from the native side, not from the WebView: a fetch() from https://localhost to our
   server is a cross-origin request, the server answers no CORS headers, and the browser
   turned that into "Nessuna connessione" for everyone, on every phone. The engine's HTTP
   client has no such wall. fetch() stays as the browser-preview fallback only. */
async function feedbackSend(){
  const text = (document.getElementById('fbText').value || '').trim();
  const email = (document.getElementById('fbEmail').value || '').trim();
  if(text.length < 3){ toast('Scrivi almeno qualche parola'); return; }
  const btn = document.getElementById('fbSend'); btn.disabled = true; btn.textContent = 'Invio…';
  const payload = { email: email, text: (AS_MOTIVO ? '[' + AS_MOTIVO.n + '] ' : '') + text + fbBloccoAllegato(), appVersion: (typeof APP_VERSION !== 'undefined' ? APP_VERSION : ''), device: navigator.userAgent.slice(0, 120), locale: navigator.language };
  try{
    let j;
    if(NATIVE && NATIVE.publicApi){
      j = await NATIVE.publicApi({ method: 'POST', path: '/api/focuslock/feedback', body: JSON.stringify(payload) });
    }else{
      const r = await fetch(FL_BACKEND + '/api/focuslock/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      j = await r.json().catch(function(){ return {}; });
      if(!r.ok) j = { error: j.error || ('Errore ' + r.status) };
    }
    if(j && j.sent){ toast('Grazie, ricevuto ✓'); document.getElementById('fbText').value = ''; FB_PROBE.righe = []; FB_PROBE.fino = 0; goId('s-home'); }
    else toast((j && j.error) || 'Invio non riuscito');
  }catch(e){ toast(e && e.message ? e.message : 'Nessuna connessione'); }
  btn.disabled = false; btn.textContent = 'Invia';
}

/* ---------------- about ---------------- */
registerScreen('s-about',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Informazioni</b></div>' +
  '<div style="text-align:center;padding:26px 0 10px"><div class="hlogo" style="width:76px;height:76px;border-radius:22px;margin:0 auto;background:var(--blue);display:grid;place-items:center;overflow:hidden"><img src="icons/icon-192.png" alt="" style="width:100%;height:100%;display:block;border-radius:inherit"></div>' +
  '<h2 style="font:800 26px var(--font-display);color:var(--navy);margin:14px 0 2px">DreamMap</h2><div id="aboutVer" style="font:600 12px var(--font-body);color:var(--muted)"></div></div>' +
  '<div class="setrow" onclick="openLegal(\'terms\')"><span>📄</span><b>Condizioni d’uso</b><span class="chev"></span></div>' +
  '<div class="setrow" onclick="openLegal(\'privacy\')"><span>🔐</span><b>Informativa sulla privacy</b><span class="chev"></span></div>' +
  '<div class="setrow" onclick="ufOpenUrl(\'https://dream-brothers.com/pages/focuslock\')"><span>🌐</span><b>Sito</b><small>dream-brothers.com</small><span class="chev"></span></div>' +
  /* RIVEDERE IL PRIMO AVVIO SENZA DISINSTALLARE. Chi ha acceso la protezione dalla
     disinstallazione non vede mai più l'intro: ogni APK nuovo entra come aggiornamento sopra
     una configurazione già fatta. Qui la si rivede quando si vuole, senza toccare nessuna
     protezione e senza cancellare le regole: si azzera solo il segno «già fatto». */
  '<div class="setrow" onclick="rivediOnboarding()"><span>🔄</span><b>Rivedi il primo avvio</b><small>dalla prima schermata</small><span class="chev"></span></div>' +
  '<p class="hintline" style="text-align:center;padding-top:18px">Fatta da DreamBrothers. Il tuo tempo è tuo.</p>' +
  '<div class="spacer"></div>', { back: 's-home' });
document.addEventListener('DOMContentLoaded', function(){
  const v = document.getElementById('aboutVer'); if(v) v.textContent = 'Versione ' + (typeof APP_VERSION !== 'undefined' ? APP_VERSION : '');
});
/* UN DATO DAL TELEFONO, invece di uno screenshot: la pagina Info dice se il tema scuro sta
   funzionando davvero, misurando un chip di prova. Se dice «da controllare», il difetto e'
   nel WebView di quel telefono e non nel foglio di stile, e si sa dove guardare. */
/**
 * Rivedere il primo avvio senza disinstallare l'app.
 *
 * <p>Chi ha acceso la protezione dalla disinstallazione non vedrebbe mai piu' l'onboarding:
 * ogni APK nuovo entra come aggiornamento sopra una configurazione gia' fatta. Qui si torna
 * alla prima schermata quando si vuole. Le regole, i programmi, i punti e le impostazioni
 * restano dove sono: si azzera solo il segno «l'ho gia' visto».</p>
 */
function rivediOnboarding(){
  /* il segno «primo avvio fatto» resta: chi chiude l'app a meta' replica torna a casa */
  try{ document.documentElement.classList.remove('fl-home'); }catch(_){ }
  if (typeof gnRivedi === 'function') gnRivedi(); else go(0);
}

function settingsScuroProva(){
  const v = document.getElementById('aboutVer'); if(!v) return;
  if(!document.body.classList.contains('dark')) return;
  try{
    const t = document.createElement('span'); t.className = 'blk-chip'; t.textContent = 'x';
    t.style.position = 'absolute'; t.style.left = '-9999px';
    document.body.appendChild(t);
    const bg = getComputedStyle(t).backgroundColor;
    t.remove();
    const m = (bg || '').match(/[\d.]+/g) || [];
    const chiaro = m.length >= 3 && (+m[0] + +m[1] + +m[2]) / 3 > 160;
    const gc = (typeof FL_CONTRASTO !== 'undefined') ? FL_CONTRASTO.length : 0;
    v.textContent += ' \u00b7 tema scuro ' + (chiaro ? 'DA CONTROLLARE (' + bg + ')' : 'ok')
      + (gc ? ' · contrasto corretto in ' + gc + (gc === 1 ? ' punto' : ' punti') : '');
  }catch(_){ }
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-about') setTimeout(settingsScuroProva, 200); });


/* What the service needs from the phone's own settings, pushed once per launch: the daily
   goal (the traffic light of the usage message) and the mantra with its cadence. Without
   this a goal chosen before the service knew about goals stayed on the phone only, and the
   message kept coming up navy. */
setTimeout(function(){
  if(!NATIVE || !NATIVE.setSettings) return;
  const patch = { dailyGoalMin: goalMin(), mantraEveryMin: mantraEveryMin() };
  /* Con il 3·6·9 acceso il mantra corrente lo sceglie il Genio: rispedire qui quello del
     «perche'» lo scavalcava a ogni apertura. */
  const genio = (typeof m369Leggi === 'function') && m369Leggi().on;
  if(!genio && typeof whyMantra === 'function') patch.mantraText = whyMantra();
  try{ NATIVE.setSettings(patch); }catch(_){ }
}, 2500);

/* LE IMPOSTAZIONI SI LEGGONO ALL'AVVIO, NON QUANDO CAPITA. `SETTINGS` partiva dai valori di
   fabbrica e si riempiva solo aprendo una pagina impostazioni: il microfono diceva «accendila
   in Personalizza» a chi l'aveva gia' accesa, e il messaggio del tempo totale tornava spento.
   Una lettura all'avvio chiude tutta la famiglia. */
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(function(){ try{ settingsLoad(); }catch(_){ } }, 700);
});
document.addEventListener('visibilitychange', function(){
  if (!document.hidden) setTimeout(function(){ try{ settingsLoad(); }catch(_){ } }, 300);
});

function settingsToggleNoPause(){
  const on = !itNoPause();
  try{ localStorage.setItem('fl_no_pause', on ? '1' : '0'); }catch(_){ }
  const b = document.getElementById('stNoPauseSw');
  if (b) b.classList.toggle('on', on);
  if (typeof toast === 'function') toast(on ? 'Fatto: i blocchi vanno fino in fondo' : 'Le pause sono di nuovo possibili');
}

/* le due scelte dell'effetto farfalla, scritte nelle Impostazioni (farfalla.js le salva) */
function fsScelteDipingi(){
  try{
    const a = document.getElementById('fsStrada'), b = document.getElementById('fsPillola');
    const u = (typeof faStrada === 'function') ? faStrada() : null;
    const p = (typeof faSevera === 'function') ? faSevera() : null;
    if (a) a.textContent = u ? (FA_NOMI[u.scelta] + ' · dal ' + new Date(u.at).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }) + ' · tocca per cambiare') : 'Non ancora scelta';
    if (b) b.textContent = p ? ((p.scelta === 'rossa' ? 'Pillola rossa' : 'Pillola blu') + ' · tocca per cambiare') : 'Non ancora scelta';
  }catch(_){ }
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-settings') fsScelteDipingi(); });
setTimeout(fsScelteDipingi, 2500);

/* 0.9.282, Andrea: "la scheda bloccata su Chrome resta aperta e riaprendo Chrome riparte il blocco". */
const PD_OPS = [
  { k: 'chiudi', t: 'Chiudi la pagina', d: 'Al suo posto si apre la pagina di Google.' },
  { k: 'vai', t: 'Apri un tuo indirizzo', d: 'La scheda passa alla pagina che scegli tu.' }
];
function pdPaint(){
  const h = document.getElementById('pdOps'); if (!h) return;
  const cur = SETTINGS.paginaDopo === 'vai' ? 'vai' : 'chiudi';
  h.innerHTML = PD_OPS.map(function(o){
    const url = o.k === 'vai' && cur === 'vai'
      ? '<span class="pd-url" onclick="event.stopPropagation()"><input class="fin" id="stRedirect" placeholder="es. https://dream-brothers.com" inputmode="url" autocomplete="off" value="' + String(SETTINGS.redirectUrl || '').replace(/"/g, '&quot;') + '" onchange="settingsSaveFromForm()"><small>Un programma può avere un suo indirizzo.</small></span>' : '';
    return '<div class="pd-op' + (o.k === cur ? ' on' : '') + '" role="button" tabindex="0" onclick="pdScegli(\'' + o.k + '\')"><i></i><span><b>' + o.t + '</b><small>' + o.d + '</small>' + url + '</span></div>';
  }).join('');
}
async function pdScegli(k){
  SETTINGS.paginaDopo = k; pdPaint();
  try{ await settingsSave({ paginaDopo: k }); }catch(_){ }
  try{ flVibra(10); }catch(_){ }
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.pd-ops{display:flex;flex-direction:column;gap:8px;margin-top:6px}'
    + '.pd-op{display:flex;gap:12px;align-items:flex-start;text-align:left;border:1.5px solid var(--line,#D8E6F5);background:var(--card);color:var(--navy);border-radius:14px;padding:12px 14px;cursor:pointer;font:inherit}'
    + '.pd-op i{flex:none;width:18px;height:18px;border-radius:50%;border:2px solid #9DB8D6;margin-top:2px}'
    + '.pd-op.on{border-color:#1E6FD9}.pd-op.on i{border:5px solid #1E6FD9}'
    + '.pd-op b{display:block;font-size:15px;font-weight:700}.pd-op small{display:block;font-size:13px;opacity:.7;margin-top:2px}'
    + '.pd-op > span{flex:1;min-width:0}.pd-url{display:block;margin-top:10px}.pd-url .fin{width:100%;box-sizing:border-box}.pd-url small{margin-top:6px}';
  document.head.appendChild(st);
})();
