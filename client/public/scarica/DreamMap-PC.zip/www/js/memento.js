/* ---------------------------------------------------------------------------------------
   MEMENTO MORI — la tua vita in settimane

   Un quadrato per ogni settimana di una vita intera. Quelle vissute sono piene, quella di
   adesso e' rossa, quelle che restano sono vuote. Nessuno deve spuntare niente: ogni domenica
   la settimana appena finita si riempie da sola, perche' si conta dalla data di nascita.

   Le settimane stanno in righe da cinquantadue (un anno), divise in quattro blocchi da tredici
   (i trimestri); le righe si raggruppano per cinque anni, con l'eta' scritta a sinistra.
   La data di nascita e' quella del profilo: se manca si chiede qui, una volta.
   --------------------------------------------------------------------------------------- */

const MM_ANNI_KEY = 'fl_mm_anni';
const MM_VISTO_KEY = 'fl_mm_visto';

registerScreen('s-memento', '<div class="topbar mm-top"><button class="iconbtn" onclick="mmIndietro()">‹</button>'
  + '<b class="blk-title">La tua vita in settimane</b></div>'
  + '<div id="mmBody"></div><div class="spacer"></div>', { back: function(){ return MM_DA || 's-home'; } });

let MM_DA = 's-home';

function mmAnni(){ try{ const v = +localStorage.getItem(MM_ANNI_KEY); return v === 90 ? 90 : 80; }catch(_){ return 80; } }
function mmSetAnni(v){ try{ localStorage.setItem(MM_ANNI_KEY, String(v)); }catch(_){ } mmPaint(); }

/** La data di nascita del profilo, o '' se non c'e'. */
function mmNascita(){
  let b = '';
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); b = (u && u.birth) || ''; }catch(_){ }
  if (!b){ try{ b = (typeof scFuture === 'function') ? (scFuture().birth || '') : ''; }catch(_){ } }
  return /^\d{4}-\d{2}-\d{2}$/.test(b) ? b : '';
}
function mmSalvaNascita(){
  const i = document.getElementById('mmBirth');
  const v = i && /^\d{4}-\d{2}-\d{2}$/.test(i.value) ? i.value : '';
  if (!v){ toast('Scegli la data'); return; }
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null') || {};
    u.birth = v;
    localStorage.setItem('fl_user', JSON.stringify(u));
  }catch(_){ }
  if (typeof scFutureSetBirth === 'function') try{ scFutureSetBirth(v); }catch(_){ }
  mmPaint();
}

/**
 * Le settimane vissute: le domeniche passate dalla nascita. Ogni domenica il conto sale di
 * uno, da solo. La settimana in corso e' quella dopo l'ultima domenica.
 */
function mmConti(){
  const b = mmNascita();
  if (!b) return null;
  const nato = new Date(b + 'T00:00:00');
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  /* la prima domenica dalla nascita in poi, e l'ultima domenica fino a oggi */
  const primaDom = new Date(nato); primaDom.setDate(primaDom.getDate() + ((7 - primaDom.getDay()) % 7));
  const ultimaDom = new Date(oggi); ultimaDom.setDate(ultimaDom.getDate() - oggi.getDay());
  const vissute = ultimaDom < primaDom ? 0 : Math.round((ultimaDom - primaDom) / (7 * 86400000)) + 1;
  const totale = mmAnni() * 52;
  const v = Math.min(vissute, totale);
  return { vissute: v, totale: totale, restano: Math.max(0, totale - v), pct: v / totale * 100 };
}

function mmOpen(da){
  MM_DA = da || 's-home';
  try{ localStorage.setItem(MM_VISTO_KEY, '1'); }catch(_){ }
  goId('s-memento');
  mmPaint('mmBody');
}
function mmIndietro(){
  goId(MM_DA || 's-home');
  if (MM_DA === 's-home' && typeof switchTab === 'function') switchTab('mappa');
}

let MM_HOST = 'mmBody';
function mmPaint(hostId){
  if (hostId) MM_HOST = hostId;
  const box = document.getElementById(MM_HOST) || document.getElementById('mmBody');
  if (!box) return;
  const c = mmConti();
  const anni = mmAnni();
  let html = '<div class="mm-hero"><div class="mm-hero-img"' + mmHeroStile() + '></div>'
    + '<button type="button" class="mm-hero-menu" onclick="mmHeroMenu()" aria-label="Cambia l’immagine"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg></button>'
    /* 0.9.322, Andrea: la spiegazione nella (i) del titolo, non sopra all'immagine */
    + '<div class="mm-hero-t"><h2>Una casella per ogni settimana <button type="button" class="mm-hero-i" onclick="mmHeroInfo()" aria-label="Come si legge">i</button></h2></div></div>';
  if (!c){
    html += '<div class="mm-nascita"><b>🎂 Quando sei nato</b>'
      + '<p>Serve una volta sola: da qui si contano le settimane.</p>'
      + '<input class="fin" id="mmBirth" type="date" max="' + new Date().toISOString().slice(0, 10) + '">'
      + '<button type="button" class="cta" onclick="mmSalvaNascita()">Mostra la mia vita</button></div>';
    box.innerHTML = html;
    return;
  }
  html += '<div class="mm-stats">'
    + '<div><b>' + c.vissute.toLocaleString('it-IT') + '</b><small>settimane vissute</small></div>'
    + '<div class="mm-pct"><b>' + c.pct.toFixed(1).replace('.', ',') + '%</b><small>della tua vita</small></div>'
    + '<div><b>' + c.restano.toLocaleString('it-IT') + '</b><small>settimane rimaste</small></div>'
    + '</div>'
    + '<div class="mm-bar"><i style="width:' + Math.min(100, c.pct).toFixed(2) + '%"></i></div>'
    + '<div class="mm-anni">Una vita di'
    + [80, 90].map(function(a){ return '<button type="button" class="' + (a === anni ? 'on' : '') + '" onclick="mmSetAnni(' + a + ')">' + a + ' anni</button>'; }).join('')
    + '</div>'
    /* 0.9.319, Andrea: il meno e il piu' come nella vista della Mappa, e sotto la legenda */
    + '<div class="mm-griglia mm-zgrid"><div class="mm-z-btn"><button type="button" onclick="mmZoom(-1)" aria-label="Allontana">−</button><button type="button" onclick="mmZoom(1)" aria-label="Avvicina">+</button></div>'
    + '<div class="mm-z-scroll"><div class="mm-z-in" style="width:' + (MM_ZOOM * 100) + '%"><canvas id="mmCanvas"></canvas></div></div>'
    + mmLegenda(c) + '</div>'
    + mmPiedeHtml();
  box.innerHTML = html;
  mmHeroLargo(box);
  /* 0.9.297: la tela di QUESTA pagina. Con la vita in settimane gia' aperta ci sono due #mmCanvas, e getElementById prendeva
     quella nascosta: la Timeline del profilo restava vuota (Andrea, 23/10). */
  requestAnimationFrame(function(){ mmRidisegna(box, c, anni); });
}
function mmMeta(c){ try{ return (typeof vsMetaIdx === 'function') ? vsMetaIdx(c) : -1; }catch(_){ return -1; } }
function mmRidisegna(box, c, anni){
  const meta = mmMeta(c);
  mmDisegna(c, anni, { canvas: box.querySelector('canvas'), pagine: (typeof vsPagineSet === 'function') ? vsPagineSet() : null, segni: meta >= 0 ? [{ settimana: meta, tipo: 'meta' }] : [] });
}
function mmLegenda(c){
  let h = ''; try{ if (typeof vsLegendaHtml === 'function') h = vsLegendaHtml(mmMeta(c) >= 0, 'mm-leg'); }catch(_){ }
  return h;
}
let MM_ZOOM = 1;
function mmZoom(d){
  const prima = MM_ZOOM; MM_ZOOM = Math.max(1, Math.min(4, Math.round(MM_ZOOM + d)));
  if (prima === MM_ZOOM) return;
  const box = document.getElementById(MM_HOST) || document.getElementById('mmBody'); if (!box) return;
  const sc = box.querySelector('.mm-z-scroll'), inn = box.querySelector('.mm-z-in'), c = mmConti(); if (!sc || !inn || !c) return;
  const fx = sc.clientWidth / 2, rx = (sc.scrollLeft + fx) / (inn.offsetWidth || 1);
  inn.style.width = (MM_ZOOM * 100) + '%';
  mmRidisegna(box, c, mmAnni());
  sc.scrollLeft = rx * inn.offsetWidth - fx;
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
}
/* 0.9.321, Andrea: "voglio poter zoomare anche con le dita". Due dita sul calendario: mentre si pizzica si allarga la tela
   esistente (costa poco), e quando si staccano si ridisegna nitida alla misura nuova. Il punto fra le dita resta li'. */
const MM_PZ = { sc: null, d0: 0, z0: 1, rx: 0, ry: 0, fx: 0, fy: 0 };
function mmDist(t){ return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
document.addEventListener('touchstart', function(e){
  if (e.touches.length !== 2 || !e.target || !e.target.closest) return;
  const sc = e.target.closest('.mm-z-scroll'); if (!sc) return;
  const inn = sc.querySelector('.mm-z-in'), cv = inn && inn.querySelector('canvas'); if (!cv) return;
  const q = sc.getBoundingClientRect();
  MM_PZ.sc = sc; MM_PZ.d0 = mmDist(e.touches); MM_PZ.z0 = MM_ZOOM;
  MM_PZ.fx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - q.left;
  MM_PZ.fy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - q.top;
  MM_PZ.rx = (sc.scrollLeft + MM_PZ.fx) / (inn.offsetWidth || 1);
  MM_PZ.ry = (sc.scrollTop + MM_PZ.fy) / (inn.offsetHeight || 1);
  cv.style.width = '100%'; cv.style.height = 'auto';
}, { passive: true });
document.addEventListener('touchmove', function(e){
  if (!MM_PZ.sc || e.touches.length !== 2) return;
  e.preventDefault();
  const inn = MM_PZ.sc.querySelector('.mm-z-in'); if (!inn) return;
  MM_ZOOM = Math.max(1, Math.min(4, MM_PZ.z0 * mmDist(e.touches) / (MM_PZ.d0 || 1)));
  inn.style.width = (MM_ZOOM * 100) + '%';
  MM_PZ.sc.scrollLeft = MM_PZ.rx * inn.offsetWidth - MM_PZ.fx;
  MM_PZ.sc.scrollTop = MM_PZ.ry * inn.offsetHeight - MM_PZ.fy;
}, { passive: false });
document.addEventListener('touchend', function(e){
  if (!MM_PZ.sc || e.touches.length >= 2) return;
  const sc = MM_PZ.sc, box = sc.closest('#' + MM_HOST) || document.getElementById(MM_HOST) || document.getElementById('mmBody');
  MM_PZ.sc = null;
  const inn = sc.querySelector('.mm-z-in'), c = mmConti(); if (!inn || !c || !box) return;
  const sl = sc.scrollLeft, st = sc.scrollTop;
  mmRidisegna(box, c, mmAnni());
  sc.scrollLeft = sl; sc.scrollTop = st;
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
}, { passive: true });
/* L'IMMAGINE DELLA TESTATA, a tutta larghezza e scelta da chi la guarda */
const MM_IMG_K = 'fl_mm_hero';
function mmHeroStile(){ let u = ''; try{ u = localStorage.getItem(MM_IMG_K) || ''; }catch(_){ } return u ? ' style="background-image:url(' + u + ');background-position:center"' : ''; }
/* 0.9.322, Andrea: "a volte il testo tocca il bordo e l'immagine e' spostata, poi cambiando scheda torna giusta". LA CAUSA: la misura si
   faceva con getBoundingClientRect mentre la pagina stava ancora entrando con l'animazione, e il margine prendeva lo spostamento
   dell'animazione. Adesso si conta da offsetLeft, che le trasformazioni non toccano. */
function mmHeroLargo(box){
  requestAnimationFrame(function(){
    const h = box.querySelector('.mm-hero'); if (!h || box.id !== 'mmBodyAcc' || !h.offsetWidth) return;
    const ph = document.getElementById('phone') || document.documentElement;
    const ml = parseFloat(getComputedStyle(h).marginLeft) || 0;
    let x = 0, e = h;
    while (e && e !== ph && e !== document.body){ x += e.offsetLeft || 0; e = e.offsetParent; }
    h.style.marginLeft = (ml - x) + 'px'; h.style.marginRight = '0'; h.style.width = ph.clientWidth + 'px'; h.style.borderRadius = '0';
  });
}
function mmHeroInfo(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>La tua vita in settimane</h3>'
    + flInfoRighe([
        ['📅', 'Una casella per ogni settimana', 'Ogni domenica se ne chiude una.'],
        ['🟦', 'Le caselle blu', 'Sono le settimane con una pagina del diario: toccale per leggerla.'],
        ['✍️', 'Una pagina nuova', 'Tocca una settimana passata e scrivi cosa è successo: diventa blu.']
      ]) + '</div>');
}
function mmHeroMenu(){
  let u = ''; try{ u = localStorage.getItem(MM_IMG_K) || ''; }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  /* 0.9.322, Andrea: un popover solo: l'immagine e le settimane pubbliche */
  inSheet('<div class="en-foglio mm-hero-f chi-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>La tua vita in settimane</h3>'
    + '<button type="button" class="en-cta" onclick="mmHeroScegli()">Cambia l’immagine</button>'
    + (u ? '<button type="button" class="en-no" onclick="mmHeroVia()">Rimetti il teschio</button>' : '')
    + (typeof vsPubblica === 'function' ? '<div class="chi-f-r" style="margin-top:14px"><div><b>Settimane pubbliche</b><small>I tuoi amici possono aprire le tue pagine dal tuo profilo.</small></div><button type="button" class="switch' + (vsPubblica() ? ' on' : '') + '" aria-label="Settimane pubbliche" onclick="vsPubblicaSet(' + (vsPubblica() ? 'false' : 'true') + ');setTimeout(mmHeroMenu,80)"></button></div>' : '')
    + '</div>');
}
function mmHeroScegli(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0]; inp.remove(); if (!f) return;
    const url = URL.createObjectURL(f), img = new Image();
    img.onload = function(){
      try{
        const k = Math.min(1, 1100 / img.width), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        localStorage.setItem(MM_IMG_K, cv.toDataURL('image/jpeg', .78));
        inSheetChiudi(); mmPaint();
      }catch(_){ try{ toast('Questa immagine è troppo pesante: provane un’altra'); }catch(_e){ } }
      URL.revokeObjectURL(url);
    };
    img.onerror = function(){ URL.revokeObjectURL(url); try{ toast('Non riesco ad aprire questa immagine'); }catch(_){ } };
    img.src = url;
  });
  document.body.appendChild(inp); inp.click();
}
function mmHeroVia(){ try{ localStorage.removeItem(MM_IMG_K); }catch(_){ } inSheetChiudi(); mmPaint(); }

/* La griglia, su tela: quattromila quadrati sono troppi per il DOM di un telefono economico. */
function mmDisegna(c, anni, opts){
  const cv = (opts && opts.canvas) || document.getElementById('mmCanvas');
  if (!cv) return;
  /* LA LARGHEZZA UTILE, non quella del riquadro: clientWidth comprende il padding, e i
     quadrati sbordavano a destra di tutto il margine interno. */
  const cs = getComputedStyle(cv.parentNode);
  const W = Math.floor((cv.parentNode.clientWidth || 340) - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0));
  const lab = 26, gapB = 5, gapBanda = 7;
  const passo = (W - lab - gapB * 3) / 52;
  const lato = Math.max(1.5, passo * 0.72);
  const bande = Math.ceil(anni / 5);
  const H = Math.ceil(anni * passo + (bande - 1) * gapBanda) + 4;
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cv.style.width = W + 'px'; cv.style.height = H + 'px';
  const g = cv.getContext('2d');
  g.scale(dpr, dpr);
  /* 0.9.296, Andrea: "al buio la vita in settimane ha lo sfondo scuro e le caselle bianche, ed e' sbagliato". La pagina e'
     un foglio di carta, come il poster del memento mori: resta di carta anche con il tema scuro. */
  /* la pagina della vita in settimane resta di carta anche al buio; la Timeline del profilo segue il tema */
  /* 0.9.305: anche la vista Memento Mori della pagina della mappa e' di carta (opts.chiaro, mappa-pagina.js): al buio
     le caselle vissute uscivano azzurre sulla carta e quelle da vivere e i numeri degli anni sparivano */
  const scuro = document.body.classList.contains('dark') && !cv.closest('#s-memento') && !(opts && opts.chiaro);
  const colPieno = scuro ? '#C9D6FF' : '#2A1F1D';
  const colVuoto = scuro ? 'rgba(255,255,255,.13)' : '#E6D6CC';
  const colOra = '#E63946';
  /* 0.9.286: le settimane con una pagina del diario (vita-settimane.js) sono blu, e si toccano per leggerla */
  const pag = (opts && opts.pagine) || null, colPag = scuro ? '#3D8BFF' : '#0075E3';
  const colTesto = scuro ? 'rgba(255,255,255,.8)' : '#3A2E2B';
  g.font = '600 10px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
  g.textAlign = 'right'; g.textBaseline = 'middle';
  let n = 0;
  for (let anno = 0; anno < anni; anno++){
    const banda = Math.floor(anno / 5);
    const y = anno * passo + banda * gapBanda;
    if (anno % 5 === 4){ g.fillStyle = colTesto; g.fillText(String(anno + 1), lab - 6, y + lato / 2); }
    for (let s = 0; s < 52; s++){
      const x = lab + s * passo + Math.floor(s / 13) * gapB;
      g.fillStyle = n < c.vissute ? (pag && pag.has(n) ? colPag : colPieno) : (n === c.vissute ? colOra : colVuoto);
      g.fillRect(x, y, lato, lato);
      n++;
    }
  }
  /* I SEGNI DEL NAVIGATORE: la settimana della prima previsione (tratteggiata) e quella della
     stima di oggi (piena). Lo chiede la Timeline del viaggio; la pagina Memento non ne ha. */
  ((opts && opts.segni) || []).forEach(function(s){
    if (!s || !(s.settimana >= 0) || s.settimana >= anni * 52) return;
    const anno = Math.floor(s.settimana / 52), sett = s.settimana % 52;
    const x = lab + sett * passo + Math.floor(sett / 13) * gapB;
    const y = anno * passo + Math.floor(anno / 5) * gapBanda;
    const r = Math.max(2, lato * 1.6), cx = x + lato / 2, cy = y + lato / 2;
    /* 0.9.279: la settimana in cui arrivi al sogno, un puntino blu pieno con un alone */
    /* 0.9.305, Andrea: il mirino quadrato blu intorno alla settimana d'arrivo, lo stesso del report (vita-settimane.js) */
    if (s.tipo === 'meta' && typeof vsMirino === 'function'){ vsMirino(g, cx, cy, lato, Math.max(lato * 1.5, 5.5), 1.6); return; }
    if (s.tipo === 'meta'){
      g.fillStyle = 'rgba(0,117,227,.22)'; g.beginPath(); g.arc(cx, cy, Math.max(5, lato * 2.4), 0, Math.PI * 2); g.fill();
      g.fillStyle = '#0075E3'; g.beginPath(); g.arc(cx, cy, Math.max(3, lato * 1.15), 0, Math.PI * 2); g.fill();
      return;
    }
    g.lineWidth = 1.5; g.strokeStyle = '#0075E3';
    if (s.tipo === 'attuale'){ g.fillStyle = '#0075E3'; g.fillRect(x, y, lato, lato); g.setLineDash([]); }
    else g.setLineDash([2, 2]);
    g.strokeRect(cx - r, cy - r, r * 2, r * 2);
    g.setLineDash([]);
  });
}

document.addEventListener('fl:tema', function(){ if (document.getElementById('mmCanvas')) mmPaint(); });

(function mmStile(){
  const css = [
    '.mm-hero{position:relative;height:190px;margin:0 -16px 18px;overflow:hidden;background:#000}',
    '.mm-hero-img{position:absolute;inset:0;background:url(img/memento-skull.jpg) 30% 45%/cover no-repeat;opacity:.85}',
    '.mm-hero::after{content:"";position:absolute;inset:0;background:rgba(0,12,32,.66)}',
    '.mm-hero-t{position:absolute;left:24px;right:24px;top:0;bottom:0;z-index:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#fff}',
    '.mm-hero-menu{position:absolute;right:12px;top:12px;z-index:2;width:40px;height:40px;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;cursor:pointer}',
    '.mm-zgrid{position:relative}.mm-z-btn{position:absolute;right:8px;top:8px;z-index:2;display:flex;gap:6px}.mm-z-btn button{width:36px;height:36px;border:0;border-radius:50%;background:#0E2350;color:#fff;font:800 20px/1 var(--font-body);cursor:pointer;box-shadow:0 4px 12px rgba(0,30,68,.25)}',
    '.mm-z-scroll{overflow:auto;scrollbar-width:none;max-height:none;touch-action:pan-x pan-y}.mm-z-scroll::-webkit-scrollbar{display:none}.mm-z-in{min-width:100%}.mm-z-in canvas{display:block}',
    '.mm-griglia .vs-leg.mm-leg{margin-top:14px;color:#14284D}body.dark .mm-griglia .vs-leg.mm-leg{color:#fff}.mm-leg-nota{display:flex;align-items:center;justify-content:center;gap:8px;margin:10px 6px 2px;font:600 12.5px/1.4 var(--font-body);color:var(--navy);text-align:center}body.dark .mm-leg-nota{color:#BCE0FF}.mm-leg-nota i{flex:none;width:11px;height:11px;border-radius:2px;background:#0075E3}.mm-leg-nota.vuota{display:block;color:var(--muted)}',
    '.mm-hero-t h2{margin:0;font:800 22px/1.15 var(--font-display);font-style:italic;color:#fff}',
    '.mm-hero-i{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;margin-left:4px;padding:0;border:1.5px solid rgba(255,255,255,.75);border-radius:50%;background:none;color:#fff;font:800 12px var(--font-body);font-style:normal;vertical-align:3px;cursor:pointer}',
    '.mm-stats{display:flex;justify-content:space-between;gap:8px;text-align:center}',
    '.mm-stats > div{flex:1}',
    '.mm-stats b{display:block;font:800 20px var(--font-display);color:var(--navy)}',
    '.mm-stats .mm-pct b{font-size:26px;color:#E63946}',
    '.mm-stats small{display:block;margin-top:2px;font:600 10.5px var(--font-body);color:var(--muted)}',
    'body.dark .mm-stats b{color:#fff}body.dark .mm-stats .mm-pct b{color:#FF6B78}',
    '.mm-bar{height:6px;margin:14px 0 12px;border-radius:99px;background:rgba(0,30,68,.1);overflow:hidden}',
    '.mm-bar i{display:block;height:100%;background:#E63946;border-radius:99px}',
    'body.dark .mm-bar{background:rgba(255,255,255,.12)}',
    '.mm-anni{display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:16px;font:600 12px var(--font-body);color:var(--muted)}',
    '.mm-anni button{border:1px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:5px 12px;font:700 12px var(--font-body);color:var(--muted);cursor:pointer}',
    '.mm-anni button.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .mm-anni button.on{background:#fff;color:#0E2350;border-color:#fff}',
    '.mm-griglia{padding:14px 12px;border-radius:18px;background:#FBF7F3;border:1px solid #EFE4DC}',
    'body.dark .mm-griglia{background:#0D0F14;border-color:#1E2330}',
    '.mm-griglia canvas{display:block}',
    /* a imbuto: ogni riga piu' corta e piu' rientrata della precedente */
    '.mm-piede{display:flex;flex-direction:column;align-items:flex-start;width:max-content;max-width:100%;margin:24px auto 4px;',
      'font:800 17px/1.3 var(--font-display);letter-spacing:.05em;text-transform:uppercase;color:var(--navy)}',
    'body.dark .mm-piede{color:#fff}',
    '.mm-piede span{padding-left:calc(var(--i) * 1.15em);white-space:nowrap}',
    '.mm-nascita{text-align:center;padding:0 4px}',
    '.mm-nascita b{display:block;font:800 16px var(--font-body);color:var(--navy)}body.dark .mm-nascita b{color:#fff}',
    '.mm-nascita p{margin:6px 0 14px;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.mm-nascita .fin{margin-bottom:14px}'
  ].join('\n');
  const s = document.createElement('style'); s.id = 'mm-style'; s.textContent = css; document.head.appendChild(s);
})();

/* LA FRASE IN FONDO, A IMBUTO E NELLA LINGUA DI CHI LEGGE. Quattro righe, ognuna con meno
   lettere e piu' rientrata della precedente: la frase si stringe come una clessidra. */
const MM_PIEDE = {
  en: ['This is your life', 'and it\u2019s ending', 'one minute', 'at a time'],
  it: ['Questa \u00e8 la tua vita', 'e sta finendo', 'un minuto', 'per volta'],
  es: ['Esta es tu vida', 'y se est\u00e1 acabando', 'un minuto', 'a la vez'],
  fr: ['C\u2019est ta vie', 'et elle s\u2019en va', 'une minute', '\u00e0 la fois'],
  de: ['Das ist dein Leben', 'und es endet', 'Minute', 'f\u00fcr Minute'],
  pt: ['Esta \u00e9 a tua vida', 'e est\u00e1 a acabar', 'um minuto', 'de cada vez']
};
function mmPiedeHtml(){
  const righe = (typeof flTesto === 'function') ? flTesto(MM_PIEDE) : MM_PIEDE.en;
  return '<p class="mm-piede">' + righe.map(function(r, i){ return '<span style="--i:' + i + '">' + r + '</span>'; }).join('') + '</p>';
}

(function(){
  const st = document.createElement('style');
  st.textContent = 'body.dark #s-memento{--bg:#F6EFE9;--card:#FFFFFF;--navy:#2A1F1D;--ink:#2A1F1D;--muted:#6B5B55;--faint:#8F7F78;--line:#E6D6CC;background:#F6EFE9!important;color:#2A1F1D}'
    + 'body.dark #s-memento .blk-title,body.dark #s-memento .mm-stats b{color:#2A1F1D}body.dark #s-memento .iconbtn{color:#2A1F1D;background:rgba(42,31,29,.08)}';
  document.head.appendChild(st);
})();
