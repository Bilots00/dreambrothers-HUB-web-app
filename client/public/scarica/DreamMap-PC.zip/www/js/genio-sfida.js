/* ===========================================================================================
   LA SFIDA DEL GENIO (0.9.190) — «Mettimi alla prova», dal pulsante bianco della copertina
   di Dream.

   L'IDEA DI ANDREA (2/10/2026): il Genio diventa credibile come quello di Akinator. Chi gioca
   pensa a un personaggio, a un libro o a un film, e il Genio lo indovina con le domande; OPPURE,
   se e' lui a chiederlo, il Genio legge lui: che tipo di persona e', dalle sue abitudini, come
   un venditore che fa una lettura a freddo. Quando il Genio indovina, arriva il patto: «adesso
   che sai cosa so fare, ascolta questa», e la data d'arrivo al sogno. Se ha indovinato a chi
   pensavi, la data che ti da' smette di sembrare un calcolo.

   NIENTE DI QUESTO E' NELL'ONBOARDING: si apre solo dal pulsante bianco (decisione di Andrea).

   I PEZZI
   · il motore: genio-motore.js (bayesiano, come Limule; gira senza internet);
   · i cataloghi: content/genio-personaggi.json, genio-libri.json, genio-film.json (costruiti da
     tools/genio-kb), content/genio-persone.json (i diciotto tipi di «Leggi me»);
   · la scena: quella del primo avvio e degli episodi (genio-intro.js), con GN.modo = 'ak';
   · il cervello grande: quando il catalogo non basta, il server (focuslockGenio.ts) chiede a
     Claude la domanda o l'ipotesi successiva. Si accende solo se sul server c'e' la chiave;
     senza, il gioco resta tutto sul telefono e non manca niente di visibile;
   · l'apprendimento: ogni partita finita con la risposta giusta si somma alle statistiche (sul
     telefono subito, sul server per tutti), e le entita' insegnate entrano nel catalogo.

   I testi sono tutti in AK_T e AK_DOM, in un posto solo, come GN_TESTI.
   =========================================================================================== */

const AK = { dom: '', kbp: null, P: null, q: null, ip: null, cache: {}, profondo: null, cron: [], libere: [], prof: null,
             ripeti: null, dati: [], daMostrare: {}, mostrate: 0, attesa: false, esito: null, sync: {} };

const AK_DOM = {
  personaggi: { ico: '🎭', t: 'Un personaggio', s: 'vero o inventato', cosa: 'personaggio',
    pensa: 'Pensa a un personaggio, vero o inventato, e tienilo per te. Quando ce l’hai in mente, tocca *Comincia*.',
    chi: 'Chi era?', ph: 'Il nome del personaggio' },
  libri: { ico: '📚', t: 'Un libro', s: 'quello che vuoi', cosa: 'libro',
    pensa: 'Pensa a un libro, uno qualsiasi, e tienilo per te. Quando ce l’hai in mente, tocca *Comincia*.',
    chi: 'Quale libro era?', ph: 'Il titolo del libro' },
  film: { ico: '🎬', t: 'Un film', s: 'o una serie TV', cosa: 'film',
    pensa: 'Pensa a un film o a una serie TV, e tienilo per te. Quando ce l’hai in mente, tocca *Comincia*.',
    chi: 'Quale film era?', ph: 'Il titolo del film o della serie' },
  app: { ico: '📱', t: 'Un\u2019app', s: 'del tuo telefono', cosa: 'app',
    pensa: 'Pensa a un\u2019app del tuo telefono, una che usi davvero, e tienila per te. Quando ce l\u2019hai in mente, tocca *Comincia*.',
    chi: 'Quale app era?' },
  persone: { ico: '🪞', t: 'Leggi me', s: 'che persona sono' },
  tappa: { ico: '🗺️', t: 'La prossima tappa', s: 'l’Oracolo del giorno' }
};

/* I CATALOGHI PRONTI. Un catalogo entra qui quando e' costruito e collaudato (tools/test-genio.js);
   finche' non c'e', la sua carta resta in vista con «in arrivo» e non si apre. */
const AK_PRONTI = { libri: true, personaggi: true, film: true };

/* I TESTI DEL GENIO, tutti qui. Regole del Brain (copy-ui-cta, regole-anti-ai): soggetto
   esplicito, un pulsante dice cosa succede, niente «non e' X, e' Y», niente trattini lunghi. */
const AK_T = {
  hub: 'Mettimi alla prova. Pensa a *una cosa sola* e tienila per te: io la indovino con qualche domanda. A cosa vuoi pensare?',
  carica: 'Un attimo, sto aprendo il mio libro dei ricordi.',
  ipotesi: 'Ci sono. Stai pensando a…',
  ipotesi_forzata: 'Non ne sono sicuro, ma ci provo. Stai pensando a…',
  vinto: 'Lo sapevo. Mi sono bastate *{n} domande*.',
  vinto_dopo: 'Eccolo. Alla fine ci sono arrivato, in *{n} domande*.',
  patto_data: 'Adesso che sai cosa so fare, leggo il tuo futuro. Ad oggi arrivi a *{sogno}* il *{data}*.',
  patto_senza: 'Adesso che sai cosa so fare, lascia che legga il tuo futuro. Mi bastano due minuti.',
  sbagliato: ['Mmm… allora mi manca un pezzo. Continuo a chiedere.', 'Quasi. Ancora qualche domanda e ci arrivo.', 'Mi hai sorpreso. Andiamo avanti, lo trovo.'],
  perso: 'Mi hai battuto, e non capita spesso. *{chi}* Scrivimelo, e la prossima volta lo indovino.',
  grazie: 'Me lo segno. La prossima volta non mi scappa.',
  grazie_nuovo: 'Questo non lo conoscevo. Adesso sì: la prossima volta che ci pensi, lo indovino.',
  profondo: 'Questo è difficile. Lasciami pensare meglio…',
  leggi_intro: 'Va bene, leggo te. Guardo le tue abitudini, ti faccio qualche domanda e ti dico *che persona sei*.',
  leggi_so: 'Prima che tu risponda, una cosa la so già. L’ho letta nel tuo telefono.',
  leggi_so2: 'Questa domanda non te la faccio. La risposta *la so già*.',
  leggi_rivela: 'Ti ho letto. Ecco chi sei.',
  leggi_chi: 'Allora dimmelo tu. Chi sei, fra questi?',
  leggi_patto_data: 'Adesso che ti ho letto, guardo dove ti portano le tue abitudini: ad oggi arrivi a *{sogno}* il *{data}*.',
  leggi_patto_senza: 'Adesso che ti ho letto, lascia che legga anche il tuo futuro. Mi bastano due minuti.',
  app_pochi: 'Per questa sfida mi servono un paio di giorni di uso del telefono in più. Intanto mettimi alla prova con un personaggio.',
  app_perso: 'Mi hai battuto. Quale app era? Toccala qui sotto.',
  app_grazie: 'Me la segno. La prossima volta ci arrivo prima.'
};
function akT(k, v){
  let s = AK_T[k] || '';
  if (Array.isArray(s)) s = s[Math.floor(Math.random() * s.length)];
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  return s;
}
function akEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }

/* ---------- l'ingresso e l'uscita ---------- */
function akApri(){
  if (typeof GN === 'undefined') return;
  GN.on = true; GN.modo = 'ak';
  let muto = false; try{ muto = localStorage.getItem('fl_intro_audio') === '0'; }catch(_){ }
  GN.audio = !muto;
  AK.dom = ''; AK.P = null; AK.ip = null; AK.esito = null;
  goId('s-genio');
  akBarra(false);
  gnVai('akHub');
  akStatoServer();
}
function akChiudi(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t){ t.hidden = true; t.classList.remove('ak-top'); }
  const g = document.getElementById('gnGenio'); if (g) g.classList.remove('luce');
  goId('s-home');
  try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}
/* il tasto indietro del telefono: durante le domande torna alla domanda prima, altrove esce */
function akTastoIndietro(){
  try{ if (typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] !== 's-genio') return false; }catch(_){ return false; }
  if (GN.typing){ GN.completa && GN.completa(); return true; }
  if (GN.step === 'akDomanda' && AK.P && AK.cron.length){ akIndietro(); return true; }
  if (GN.step === 'akPronto' || GN.step === 'akLeggiIntro'){ gnVai('akHub'); return true; }
  akChiudi();
  return true;
}

/* ---------- la barra in alto: la X, la domanda, quanto e' sicuro il Genio ---------- */
function akBarra(dentro){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false; t.classList.add('ak-top');
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  const prog = t.querySelector('.gn-prog');
  if (!dentro || !AK.P){ if (prog) prog.style.visibility = 'hidden'; return; }
  if (prog) prog.style.visibility = '';
  let conf = 0; try{ conf = gmCandidati(AK.P, 1).lista[0].p; }catch(_){ }
  if (bar) bar.style.width = Math.round(Math.max(4, conf * 100)) + '%';
  if (txt) txt.textContent = 'Domanda n° ' + (AK.cron.length + (AK.libere || []).length + 1);
}

/* ---------- i cataloghi ---------- */
function akLeggiJSON(k, def){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; }catch(_){ return def; } }
function akScriviJSON(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
/** Le statistiche imparate: quelle di questo telefono piu' quelle del server, sommate. */
function akAppresi(dom){
  const mie = akLeggiJSON('fl_genio_ap_' + dom, {});
  const srv = (akLeggiJSON('fl_genio_srv_' + dom, {}) || {}).appresi || {};
  const out = JSON.parse(JSON.stringify(srv));
  Object.keys(mie).forEach(function(e){
    const a = out[e] = out[e] || {};
    Object.keys(mie[e]).forEach(function(q){
      const c = a[q] = a[q] || [0, 0, 0, 0, 0];
      for (let r = 0; r < 5; r++) c[r] = (c[r] || 0) + (mie[e][q][r] || 0);
    });
  });
  return out;
}
async function akKb(dom){
  if (AK.cache[dom]) return AK.cache[dom];
  const r = await fetch('content/genio-' + dom + '.json', { cache: 'no-cache' });
  const kb = await r.json();
  /* le entita' imparate: dal server (validate) e da questo telefono (insegnate qui) */
  const visti = {}; kb.entita.forEach(function(e){ visti[e.id] = true; });
  const srv = (akLeggiJSON('fl_genio_srv_' + dom, {}) || {}).nuove || [];
  const mie = akLeggiJSON('fl_genio_mie_' + dom, []);
  srv.concat(mie).forEach(function(e){
    if (!e || !e.id || visti[e.id]) return;
    /* le entita' nuove del server arrivano con i conteggi delle risposte: il profilo e' la
       risposta piu' data a ogni domanda */
    if (!e.a && e.conteggi){ e = Object.assign({}, e, { a: kb.domande.map(function(q){ const c = e.conteggi[q.id]; if (!c) return '?'; let m = 0; for (let r = 1; r < 5; r++) if ((c[r] || 0) > (c[m] || 0)) m = r; return 'Yy?nN'.charAt(m); }).join('') }); }
    if (e.a && e.a.length === kb.domande.length){ kb.entita.push(e); visti[e.id] = true; }
  });
  /* a chi pensa la gente: le entita' indovinate piu' spesso partono un po' piu' in alto */
  const volte = (akLeggiJSON('fl_genio_srv_' + dom, {}) || {}).volte || {};
  kb.entita.forEach(function(e){ if (volte[e.id]) e.vinte = volte[e.id]; });
  const kbp = gmPrepara(kb, akAppresi(dom));
  AK.cache[dom] = kbp;
  return kbp;
}

/* ---------- la scena ---------- */
function akScena(classi){
  const sc = document.getElementById('gnScena'), sg = document.getElementById('s-genio');
  ['domanda', 'molte', 'carte', 'ak-rivela', 'ak-lista'].forEach(function(c){ if (sc) sc.classList.remove(c); if (sg && c === 'domanda') sg.classList.remove(c); });
  (classi || []).forEach(function(c){ if (sc) sc.classList.add(c); if (sg && c === 'domanda') sg.classList.add(c); });
  if (sc) sc.classList.add('con-top');
}
function akRisp(html){ const r = document.getElementById('gnRisp'); if (r) r.innerHTML = html; }
function akTap(si){ const t = document.getElementById('gnTap'); if (t) t.hidden = !si; }
/** LE DOMANDE NON SI BATTONO A MACCHINA LENTA. Akinator le mostra subito: venti domande a
 *  quaranta millesimi a lettera sarebbero un minuto di attesa a partita. Qui 14 ms a lettera,
 *  senza pause, e un tocco le completa. Le battute del Genio restano alla velocita' di sempre. */
function akScriviVeloce(testo, dopo){
  const el = document.getElementById('gnTesto'), fr = document.getElementById('gnFreccia');
  if (!el) return;
  clearTimeout(GN.typing); clearInterval(GN.typing); GN.typing = null;
  if (fr) fr.hidden = true;
  const parti = gnParti(testo);
  let i = 0;
  const fine = function(){ clearTimeout(GN.typing); GN.typing = null; el.innerHTML = parti.html; if (dopo) dopo(); };
  const passo = function(){
    i += 2;
    if (i % 4 === 0) gnAu.tick();
    el.innerHTML = gnParti(testo, i).html;
    if (i >= parti.n){ fine(); return; }
    GN.typing = setTimeout(passo, 28);
  };
  el.innerHTML = '';
  GN.typing = setTimeout(passo, 28);
  GN.completa = fine;
}
const AK_ORDINE = ['ps', 'pn', 'si', 'ns', 'no'];   /* sempre negli stessi posti (regola di Andrea) */
function akCinque(fn){
  return '<div class="or-grid ak-cinque">' + AK_ORDINE.map(function(r){
    return '<button type="button" class="or-a" onclick="event.stopPropagation();' + fn + '(\'' + r + '\')">' + GM_ETICHETTE[r] + '</button>';
  }).join('') + '</div>';
}
function akPosa(){
  const P = AK.P; if (!P) return 'saluta';
  let conf = 0; try{ conf = gmCandidati(P, 1).lista[0].p; }catch(_){ }
  if (P.n >= 4 && conf >= 0.55) return 'rivela';
  const u = P.chieste.length ? P.risposte[P.chieste[P.chieste.length - 1]] : null;
  if (u === 'si' || u === 'ps') return 'saluta';
  return 'pensa';
}
/** Il testo della domanda: per le serie TV «La tua serie…», con gli accordi giusti. */
function akTesto(q){
  if (AK.dom !== 'film' || !AK.P) return q.t;
  const s = AK.P.risposte.serie;
  if (s !== 'si' && s !== 'ps') return q.t;
  if (q.ts) return q.ts;
  return q.t.replace(/^Il tuo film/, 'La tua serie').replace(/^Nel tuo film/, 'Nella tua serie').replace(/del tuo film/g, 'della tua serie')
    .replace(/^Dal tuo film/, 'Dalla tua serie').replace(/un film d'/g, 'una serie d\'').replace(/un film di /g, 'una serie di ')
    .replace(/ è italiano\?/, ' è italiana?').replace(/ è americano\?/, ' è americana?').replace(/ è britannico\?/, ' è britannica?')
    .replace(/ è spagnolo o latinoamericano\?/, ' è spagnola o latinoamericana?').replace(/ è coreano\?/, ' è coreana?')
    .replace(/ è uscito /, ' è uscita ').replace(/ è ambientato /, ' è ambientata ').replace(/ è tratto /, ' è tratta ')
    .replace(/ è adatto /, ' è adatta ').replace(/ è molto violento\?/, ' è molto violenta?').replace(/ lo passano /, ' la passano ');
}
const AK_SOLO_FILM = { lungo: 1, cinepanettone: 1, oscar: 1, incassi: 1 };

/* ---------- i passi ---------- */
if (typeof GN_PASSI !== 'undefined'){
  /* LA SCELTA: le quattro carte in due colonne, come le scelte del primo avvio */
  GN_PASSI.akHub = { entra: function(){
    akScena(['molte', 'carte']); akBarra(false);
    gnPosa('saluta');
    try{ gnAu.musica(); }catch(_){ }
    gnScrivi(akT('hub'), function(){
      const carte = ['personaggi', 'libri', 'film'].concat(akAppPossibile() ? ['app'] : []).concat(['persone']);
      akRisp('<div class="gn-carta"><div class="gn-cards">' + carte.map(function(k){
        const d = AK_DOM[k];
        const largo = k === 'persone' && carte.length % 2 === 1;
        const presto = AK_PRONTI[k] === false;
        return '<button type="button" class="gn-card' + (k === 'persone' ? ' ak-me' : '') + (largo ? ' ak-largo' : '') + (presto ? ' ak-presto' : '') + '"' + (presto ? ' disabled' : '') + ' onclick="event.stopPropagation();akScegli(\'' + k + '\')"><span>' + d.ico + '</span><b>' + akEsc(d.t) + '</b><small>' + akEsc(presto ? 'in arrivo' : d.s) + '</small></button>';
      }).join('') + '</div></div>');
    });
  } };
  GN_PASSI.akPronto = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('pensa');
    const d = AK_DOM[AK.dom];
    gnScrivi(d.pensa, function(){
      akRisp('<div class="or-grid one"><button type="button" class="or-a main" id="akVia" onclick="event.stopPropagation();akComincia()"' + (AK.kbp ? '' : ' disabled') + '>' + (AK.kbp ? 'Comincia' : 'Un attimo…') + '</button></div>');
    });
  } };
  GN_PASSI.akDomanda = { entra: function(){ akDisegnaDomanda(); } };
  GN_PASSI.akIpotesi = { entra: function(){ akDisegnaIpotesi(); } };
  GN_PASSI.akVinto = { entra: function(){
    akScena(['molte']); akBarra(false);
    gnPosa('rivela');
    const n = AK.P ? AK.P.n : 0;
    gnScrivi(akT(AK.P && AK.P.tentativi ? 'vinto_dopo' : 'vinto', { n: n }), function(){ akTap(true); });
    akRisp(akCartaHtml(AK.ip.e, true));
  }, tocco: function(){ gnVai('akPatto'); } };
  GN_PASSI.akPatto = { entra: function(){ akDisegnaPatto(); } };
  GN_PASSI.akSbagliato = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('triste'); try{ gnAu.triste(); }catch(_){ }
    gnScrivi(akT('sbagliato'), function(){ akTap(true); });
  }, tocco: function(){ const dopo = AK.dopoSbaglio || 'akDomanda'; AK.dopoSbaglio = null; gnVai(dopo); } };
  GN_PASSI.akPerso = { entra: function(){ akDisegnaPerso(); } };
  GN_PASSI.akGrazie = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('saluta');
    gnScrivi(akT(AK.dom === 'app' ? 'app_grazie' : (AK.esito === 'nuovo' ? 'grazie_nuovo' : 'grazie')), function(){
      akRisp('<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();akAncora()">Gioca ancora</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();akChiudi()">Torna alla scheda Sogno</button></div>');
    });
  } };
  GN_PASSI.akProfondo = { entra: function(){ akDisegnaProfondo(); } };
  GN_PASSI.akLibera = { entra: function(){
    akScena(['domanda']); akBarra(true);
    gnPosa('pensa');
    akScriviVeloce(AK.prof.q || '');
    akRisp(akCinque('akRispostaLibera'));
  } };
  /* «LEGGI ME» */
  GN_PASSI.akLeggiIntro = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('saluta');
    gnScrivi(akT('leggi_intro'), function(){ akTap(true); });
  }, tocco: function(){ akLeggiParti(); } };
  GN_PASSI.akLeggiSo = { entra: function(){
    akScena(['molte']); akBarra(false);
    gnPosa('rivela');
    const f = AK.fatto;
    gnScrivi(akT(AK.mostrate ? 'leggi_so2' : 'leggi_so'), function(){
      akRisp('<div class="or-fatto ak-fatto">' + (f.big ? '<b>' + akEsc(f.big) + '</b>' : '') + '<small>' + f.say + '</small></div>'
        + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();akFattoOk()">Confermo</button></div>');
    });
  } };
  GN_PASSI.akLeggiRivela = { entra: function(){ akDisegnaLettura(); } };
  GN_PASSI.akLeggiChi = { entra: function(){
    akScena(['molte', 'ak-lista']); akBarra(false);
    gnPosa('pensa');
    gnScrivi(akT('leggi_chi'), function(){
      akRisp('<div class="or-scelte ak-scelte">' + AK.kbp.kb.entita.map(function(e){
        return '<button type="button" class="or-scelta" onclick="event.stopPropagation();akSonoIo(\'' + e.id + '\')"><span>' + e.ico + '</span><div><b>' + akEsc(e.n) + '</b><small>' + akEsc(e.frase) + '</small></div></button>';
      }).join('') + '</div>');
    });
  } };
}

/* ---------- la partita ---------- */
async function akScegli(dom){
  try{ gnAu.scelta(1); gnVibra(18); }catch(_){ }
  AK.dom = dom; AK.kbp = null; AK.P = null; AK.cron = []; AK.libere = []; AK.prof = null; AK.ip = null; AK.esito = null;
  /* 0.9.207: la prossima tappa (oracolo-tappa.js) */
  if (dom === 'tappa'){ if (typeof orcApri === 'function') orcApri(); return; }
  if (dom === 'persone'){ gnVai('akLeggiIntro'); akKb('persone').then(function(k){ AK.kbp = k; }).catch(function(){ }); return; }
  gnVai('akPronto');
  if (dom === 'app'){
    let k = null; try{ k = await akAppKb(); }catch(_){ k = null; }
    if (GN.step !== 'akPronto') return;
    if (!k){ gnPosa('triste'); gnScrivi(akT('app_pochi'), function(){ akRisp('<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();akAncora()">Torna alle sfide</button></div>'); }); return; }
    AK.kbp = k;
    const b = document.getElementById('akVia'); if (b){ b.disabled = false; b.textContent = 'Comincia'; }
    return;
  }
  try{
    AK.kbp = await akKb(dom);
    akSincronizza(dom);
    const b = document.getElementById('akVia'); if (b){ b.disabled = false; b.textContent = 'Comincia'; }
  }catch(_){
    toast('Non riesco ad aprire il catalogo. Riprova fra poco.');
    gnVai('akHub');
  }
}
function akComincia(){
  if (!AK.kbp) return;
  try{ gnAu.scelta(2); gnVibra(18); }catch(_){ }
  AK.P = gmNuova(AK.kbp);
  AK.cron = []; AK.libere = []; AK.prof = null; AK.ripeti = null;
  gnVai('akDomanda');
}
function akDisegnaDomanda(){
  const P = AK.P; if (!P){ gnVai('akHub'); return; }
  const persone = AK.dom === 'persone';
  /* e' ora di provare a indovinare? */
  if (!AK.ripeti){
    if (persone){
      const c = gmCandidati(P, 2).lista, fatte = AK.cron.length + AK.mostrate;
      if ((fatte >= 7 && P.n >= 10 && c[0] && c[0].p >= 0.7) || fatte >= 15){ gnVai('akLeggiRivela'); return; }
    } else if (AK.dom === 'app'){
      /* poche decine di app: si prova presto, e al limite si prova comunque */
      const c = gmCandidati(P, 2).lista, t1 = c[0];
      const lim = [9, 13, 17][Math.min(P.tentativi, 2)];
      if (t1 && ((t1.p >= 0.8 && P.n >= 3) || P.n >= lim)){ AK.ip = { tipo: 'ipotesi', e: t1.e, p: t1.p, forzata: t1.p < 0.5 }; gnVai('akIpotesi'); return; }
    } else {
      const ip = gmIpotesi(P);
      if (ip && ip.tipo === 'ipotesi'){ AK.ip = ip; gnVai('akIpotesi'); return; }
      if (ip && ip.tipo === 'ignoto' && akProfondoOk() && !AK.prof){ gnVai('akProfondo'); return; }
    }
  }
  if (AK.dom === 'film' && (P.risposte.serie === 'si' || P.risposte.serie === 'ps')) P.vietate = AK_SOLO_FILM;
  const q = AK.ripeti || gmProssima(P);
  AK.ripeti = null;
  if (!q){
    const c = gmCandidati(P, 1).lista[0];
    if (c && !persone){ AK.ip = { tipo: 'ipotesi', e: c.e, p: c.p, forzata: true }; gnVai('akIpotesi'); }
    else if (persone) gnVai('akLeggiRivela');
    else gnVai('akPerso');
    return;
  }
  /* «Leggi me»: se la risposta la sa gia' il telefono, il Genio lo dice invece di chiederla */
  if (persone && AK.daMostrare[q.id] && AK.mostrate < 3){
    AK.fatto = AK.daMostrare[q.id]; AK.fatto.q = q.id; delete AK.daMostrare[q.id];
    gnVai('akLeggiSo'); return;
  }
  AK.q = q;
  akScena(['domanda']); akBarra(true);
  gnPosa(akPosa());
  akScriviVeloce(akTesto(q));
  const indietro = AK.cron.length ? '<button type="button" class="ak-indietro" onclick="event.stopPropagation();akIndietro()" aria-label="Torna alla domanda prima">'
    + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' : '';
  akRisp(indietro + akCinque('akRisposta'));
}
function akRisposta(r){
  if (!AK.P || !AK.q || AK.attesa) return;
  try{ gnAu.scelta(AK_ORDINE.indexOf(r) + 1); gnVibra(14); }catch(_){ }
  AK.cron.push(AK.q);
  gmRispondi(AK.P, AK.q.id, r);
  /* la pausa in cui il Genio «pensa»: e' quella che fa sembrare che stia davvero leggendo */
  AK.attesa = true;
  const g = document.querySelector('#gnRisp .or-grid'); if (g) g.classList.add('off');
  gnPosa('pensa');
  setTimeout(function(){ AK.attesa = false; if (GN.step === 'akDomanda') gnVai('akDomanda'); }, 360);
}
function akIndietro(){
  if (!AK.P || !AK.cron.length) return;
  if (!gmAnnulla(AK.P)) return;
  AK.ripeti = AK.cron.pop();
  try{ gnAu.scelta(0); }catch(_){ }
  gnVai('akDomanda');
}

/* ---------- l'ipotesi ---------- */
function akIniziali(n){ return String(n || '?').replace(/^(il|lo|la|i|gli|le|l')\s+/i, '').split(/\s+/).filter(Boolean).slice(0, 2).map(function(w){ return w.charAt(0).toUpperCase(); }).join(''); }
/** La carta di chi/cosa il Genio ha indovinato: la foto se e' libera (Wikimedia Commons, con
 *  l'autore), altrimenti una copertina disegnata: iniziali, libro, locandina. */
function akCartaHtml(e, vinta){
  const dom = AK.dom;
  const foto = e.img ? '<img class="ak-foto" src="' + akEsc(e.img) + '" alt="" referrerpolicy="no-referrer" onerror="this.parentNode.classList.add(\'senza\');this.remove()">' : '';
  let viso;
  if (dom === 'libri') viso = '<div class="ak-libro"><b>' + akEsc(e.n) + '</b><small>' + akEsc(String(e.d || '').replace(/^di /, '')) + '</small></div>';
  else if (dom === 'film') viso = '<div class="ak-poster"><i>🎬</i><b>' + akEsc(e.n) + '</b><small>' + akEsc(e.d || '') + '</small></div>';
  else if (dom === 'app') viso = '<div class="ak-viso ak-app' + (foto ? '' : ' senza') + '">' + foto + '<span>' + akEsc(akIniziali(e.n)) + '</span></div>';
  else viso = '<div class="ak-viso' + (foto ? '' : ' senza') + '">' + foto + '<span>' + akEsc(e.ico || akIniziali(e.n)) + '</span></div>';
  return '<div class="ak-carta' + (vinta ? ' vinta' : '') + '">' + (vinta ? '<div class="ak-stelle"><i></i><i></i><i></i><i></i><i></i><i></i></div>' : '')
    + viso
    + (dom === 'libri' || dom === 'film' ? '' : '<b class="ak-nome">' + akEsc(e.n) + '</b>' + (e.d ? '<small class="ak-desc">' + akEsc(e.d) + '</small>' : ''))
    + (e.cr && foto ? '<i class="ak-cr">' + akEsc(e.cr) + '</i>' : '')
    + '</div>';
}
function akDisegnaIpotesi(){
  const ip = AK.ip; if (!ip){ gnVai('akDomanda'); return; }
  akScena(['molte', 'ak-rivela']); akBarra(false);
  gnPosa('pensa');
  akRisp('');
  akScriviVeloce('Mmm…');
  const g = document.getElementById('gnGenio');
  try{
    gnAu.crescendo(1300, function(){
      if (GN.step !== 'akIpotesi') return;
      gnPosa('rivela'); if (g) g.classList.add('luce');
      gnScrivi(akT(ip.forzata ? 'ipotesi_forzata' : 'ipotesi'), function(){
        if (g) g.classList.remove('luce');
        akRisp(akCartaHtml(ip.e, false)
          + '<div class="or-grid ak-due"><button type="button" class="or-a main" onclick="event.stopPropagation();akSi()">Sì, hai indovinato</button>'
          + '<button type="button" class="or-a" onclick="event.stopPropagation();akNo()">No, non è questo</button></div>');
      });
    });
  }catch(_){ }
}
function akSi(){
  try{ gnAu.punto(); gnVibra([30, 40, 90]); }catch(_){ }
  const e = AK.ip.e;
  AK.esito = 'vinto';
  akRegistra('vinto', AK.ip.esterna ? null : e.id, AK.ip.esterna ? e.n : null, AK.ip.esterna ? e : null);
  gnVai('akVinto');
}
function akNo(){
  const e = AK.ip.e;
  if (AK.ip.esterna){
    AK.prof.esclusi.push(e.n);
    AK.prof.tentativi++;
    if (AK.prof.tentativi >= 3){ gnVai('akPerso'); return; }
    AK.dopoSbaglio = 'akProfondo';
    gnVai('akSbagliato');
    return;
  }
  gmRifiuta(AK.P, e.id);
  if (gmFinita(AK.P)){
    if (AK.dom !== 'app' && akProfondoOk() && !AK.prof){ gnVai('akProfondo'); return; }
    gnVai('akPerso'); return;
  }
  gnVai('akSbagliato');
}

/* ---------- il patto: la data d'arrivo ---------- */
function akDataTxt(t){
  const d = new Date(t);
  const mesi = (typeof NV_MESI !== 'undefined') ? NV_MESI : ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  return d.getDate() + ' ' + mesi[d.getMonth()] + ' ' + d.getFullYear();
}
function akDisegnaPatto(){
  akScena(['molte']); akBarra(false);
  gnPosa('rivela');
  let a = null; try{ a = (typeof nvArrivo === 'function') ? nvArrivo() : null; }catch(_){ }
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  /* dentro alla frase il sogno perde la maiuscola: «arrivi a diventare un supereroe» */
  if (sogno && !/^[A-ZÀ-Ý]{2}/.test(sogno)) sogno = sogno.charAt(0).toLowerCase() + sogno.slice(1);
  const leggi = AK.dom === 'persone';
  if (a && a.at && isFinite(a.at)){
    const data = akDataTxt(a.at);
    gnScrivi(akT(leggi ? 'leggi_patto_data' : 'patto_data', { sogno: sogno || 'il tuo sogno', data: data }), function(){
      const prob = a.pTarget == null ? null : Math.round(a.pTarget <= 1 ? a.pTarget * 100 : a.pTarget);
      akRisp('<div class="ak-data"><small>Arrivo previsto</small><b>' + akEsc(data.replace(/ (\d{4})$/, '')) + '</b><span>' + new Date(a.at).getFullYear() + '</span>'
          + (prob != null ? '<p>Ad oggi, la probabilità di arrivarci entro la data che hai scelto è del <b>' + prob + '%</b>.</p>' : '') + '</div>'
        + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();akRicalcola()">Ricalcola il percorso</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();akAncora()">Gioca ancora</button></div>');
    });
  } else {
    gnScrivi(akT(leggi ? 'leggi_patto_senza' : 'patto_senza'), function(){
      akRisp('<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();akLettura()">Leggimi il futuro</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();akAncora()">Gioca ancora</button></div>');
    });
  }
}
function akRicalcola(){ akChiudi(); setTimeout(function(){ try{ if (typeof orPlanOpen === 'function') orPlanOpen(); }catch(_){ } }, 300); }
function akLettura(){ akChiudi(); setTimeout(function(){ try{ if (typeof orOpen === 'function') orOpen(); }catch(_){ } }, 300); }
function akAncora(){ AK.P = null; AK.ip = null; gnVai('akHub'); }

/* ---------- quando il Genio perde: chi era? ---------- */
function akDisegnaPerso(){
  akScena(['molte', 'ak-lista']); akBarra(false);
  gnPosa('triste'); try{ gnAu.triste(); }catch(_){ }
  if (AK.dom === 'app'){
    gnScrivi(akT('app_perso'), function(){
      akRisp('<div class="ak-app-griglia">' + AK.kbp.kb.entita.slice(0, 24).map(function(e){
        return '<button type="button" class="ak-app-voce" onclick="event.stopPropagation();akAppEra()">' + (e.img ? '<img src="' + akEsc(e.img) + '" alt="">' : '<span>' + akEsc(akIniziali(e.n)) + '</span>') + '<small>' + akEsc(e.n) + '</small></button>';
      }).join('') + '</div>');
    });
    return;
  }
  const d = AK_DOM[AK.dom] || AK_DOM.personaggi;
  gnScrivi(akT('perso', { chi: d.chi }), function(){
    akRisp('<input type="text" class="gn-campo ak-campo" id="akChi" placeholder="' + akEsc(d.ph) + '" autocomplete="off" oninput="akCercaChi()" onclick="event.stopPropagation()">'
      + '<div class="ak-trovati" id="akTrovati"></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();akRegistra(\'perso\');akChiudi()">Preferisco non dirlo</button>');
    setTimeout(function(){ try{ document.getElementById('akChi').focus(); }catch(_){ } }, 300);
  });
}
function akCercaChi(){
  const el = document.getElementById('akChi'), box = document.getElementById('akTrovati');
  if (!el || !box || !AK.kbp) return;
  const testo = el.value.trim();
  if (testo.length < 2){ box.innerHTML = ''; return; }
  const trovati = gmCerca(AK.kbp.kb, testo, 5);
  const esatto = trovati.some(function(e){ return gmNorm(e.n) === gmNorm(testo); });
  box.innerHTML = trovati.map(function(e){
    return '<button type="button" class="ak-trovato" onclick="event.stopPropagation();akInsegna(\'' + e.id + '\')"><b>' + akEsc(e.n) + '</b>' + (e.d ? '<small>' + akEsc(e.d) + '</small>' : '') + '</button>';
  }).join('')
    + (esatto ? '' : '<button type="button" class="ak-trovato nuovo" onclick="event.stopPropagation();akInsegna(null)"><b>«' + akEsc(testo) + '»</b><small>Non è in elenco: lo insegno al Genio</small></button>');
}
function akInsegna(eid){
  const el = document.getElementById('akChi');
  const nome = el ? el.value.trim() : '';
  if (eid){
    AK.esito = 'insegnato';
    akRegistra('insegnato', eid, null);
  } else {
    if (nome.length < 2) return;
    const e = gmEntitaDaRisposte(AK.kbp.kb, nome, AK.P ? AK.P.risposte : {});
    const mie = akLeggiJSON('fl_genio_mie_' + AK.dom, []).filter(function(x){ return x.id !== e.id; });
    mie.push(e); akScriviJSON('fl_genio_mie_' + AK.dom, mie.slice(-200));
    AK.esito = 'nuovo';
    akRegistra('nuovo', null, nome);
  }
  delete AK.cache[AK.dom];
  try{ gnAu.punto(); }catch(_){ }
  gnVai('akGrazie');
}

/* ---------- imparare e mandare al server ---------- */
function akDev(){
  let d = ''; try{ d = localStorage.getItem('fl_genio_dev') || ''; }catch(_){ }
  if (!d){ d = 'd' + Math.random().toString(36).slice(2) + Date.now().toString(36); try{ localStorage.setItem('fl_genio_dev', d); }catch(_){ } }
  return d;
}
/** Una partita finita. Se la risposta giusta e' nota, le risposte si sommano alle sue
 *  statistiche (subito, su questo telefono), e la partita va in coda per il server. */
function akRegistra(esito, eid, nome, esterna){
  if (AK.dom === 'app') return;          /* le app sono del telefono: niente esce */
  const P = AK.P;
  const risposte = P ? Object.assign({}, P.risposte) : {};
  if (eid && Object.keys(risposte).length){
    const k = 'fl_genio_ap_' + AK.dom;
    akScriviJSON(k, gmImpara(akLeggiJSON(k, {}), eid, risposte));
    delete AK.cache[AK.dom];
  }
  if (AK.dom === 'persone') return;     /* le letture restano sul telefono */
  /* a cosa ha pensato: resta sul telefono, e lo sa il suo Io futuro quando lo chiama */
  try{
    let nm = nome || (esterna && esterna.n) || '';
    if (!nm && eid){ const x = ((AK.kbp && AK.kbp.kb.entita) || []).concat(akLeggiJSON('fl_genio_mie_' + AK.dom, [])).filter(function(e){ return e && e.id === eid; })[0]; nm = x ? x.n : ''; }
    if (nm && esito !== 'perso'){ const st = akLeggiJSON('fl_genio_pensati', []); st.push({ dom: AK.dom, n: nm, esito: esito, at: Date.now() }); akScriviJSON('fl_genio_pensati', st.slice(-30)); }
  }catch(_){ }
  /* 0.9.317, Andrea: "se l'utente ha spuntato la casella, le sue risposte addestrano il Genio di tutti": senza, resta tutto sul telefono */
  if (typeof gfConsenso === 'function' && !gfConsenso()) return;
  const rec = { dominio: AK.dom, esito: esito, entita: eid || null, nome: nome || null, risposte: risposte,
                libere: (AK.libere || []).slice(0, 20), n: P ? P.n : 0, tentativi: P ? P.tentativi : 0,
                kbv: (AK.kbp && AK.kbp.kb.v) || 0, dev: akDev(), at: Date.now() };
  if (esterna) rec.esterna = { n: esterna.n, d: esterna.d || '', w: esterna.w || '' };
  const coda = akLeggiJSON('fl_genio_coda', []); coda.push(rec);
  akScriviJSON('fl_genio_coda', coda.slice(-40));
  akSvuotaCoda();
}
function akServer(){ return (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app'; }
/* DAL TELEFONO SI PASSA DAL CANALE NATIVO (NATIVE.publicApi): un fetch() dalla WebView
   (https://localhost) verso il server e' una chiamata fra origini diverse, e sui telefoni
   falliva. fetch() resta per il computer e per le prove nel browser (il server risponde con
   i permessi CORS solo sulle rotte del Genio). */
async function akFetch(path, opz, ms){
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi){
      const j = await Promise.race([
        NATIVE.publicApi({ method: (opz && opz.method) || 'GET', path: path, body: (opz && opz.body) || '' }),
        new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, ms || 9000); })
      ]);
      return j || null;
    }
  }catch(_){ return null; }
  const c = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  const t = c ? setTimeout(function(){ try{ c.abort(); }catch(_){ } }, ms || 9000) : null;
  try{
    const r = await fetch(akServer() + path, Object.assign({}, opz || {}, c ? { signal: c.signal } : {}));
    if (!r.ok) return null;
    return await r.json();
  }catch(_){ return null; } finally { if (t) clearTimeout(t); }
}
async function akSvuotaCoda(){
  if (AK.svuoto) return; AK.svuoto = true;
  try{
    let coda = akLeggiJSON('fl_genio_coda', []);
    while (coda.length){
      const j = await akFetch('/api/focuslock/genio/partita', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(coda[0]) }, 8000);
      if (!j || j.ok !== true) break;      /* solo un «ok» del server toglie la partita dalla coda */
      coda.shift(); akScriviJSON('fl_genio_coda', coda);
    }
  }finally{ AK.svuoto = false; }
}
/** Le statistiche e le entita' nuove imparate da tutti: una volta ogni dodici ore. */
async function akSincronizza(dom){
  const k = 'fl_genio_srv_' + dom;
  const vecchio = akLeggiJSON(k, null);
  if (vecchio && Date.now() - (vecchio.at || 0) < 12 * 3600000) return;
  const j = await akFetch('/api/focuslock/genio/appresi?dominio=' + encodeURIComponent(dom), null, 9000);
  if (!j || !j.ok) return;
  akScriviJSON(k, { at: Date.now(), appresi: j.appresi || {}, volte: j.volte || {}, nuove: j.nuove || [] });
  delete AK.cache[dom];
}
async function akStatoServer(){
  if (AK.profondo !== null && Date.now() - (AK.statoAt || 0) < 30 * 60000) return;
  const j = await akFetch('/api/focuslock/genio/stato', null, 6000);
  AK.profondo = !!(j && j.profondo); AK.statoAt = Date.now();
  akSvuotaCoda();
}

/* ---------- il cervello grande (server + Claude) ---------- */
function akTrascritto(){
  const P = AK.P, kb = AK.kbp.kb, out = [];
  if (P) P.chieste.forEach(function(id){ const q = kb.domande[AK.kbp.qi[id]]; if (q) out.push({ d: akTesto(q), r: GM_ETICHETTE[P.risposte[id]] }); });
  (AK.libere || []).forEach(function(x){ out.push({ d: x.d, r: GM_ETICHETTE[x.r] }); });
  return out;
}
async function akDisegnaProfondo(){
  akScena(['molte']); akBarra(false);
  gnPosa('pensa');
  const g = document.getElementById('gnGenio'); if (g) g.classList.add('luce');
  akRisp('');
  if (!AK.prof) AK.prof = { passi: 0, esclusi: (AK.P ? AK.P.rifiutate.map(function(id){ const k = AK.kbp.ei[id]; return k == null ? id : AK.kbp.kb.entita[k].n; }) : []), tentativi: 0, q: '' };
  gnScrivi(akT('profondo'), function(){ });
  const cand = gmCandidati(AK.P, 5).lista.map(function(c){ return { n: c.e.n, p: Math.round(c.p * 100) / 100 }; });
  const j = await akFetch('/api/focuslock/genio/pensa', { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ dominio: AK.dom, domande: akTrascritto(), esclusi: AK.prof.esclusi, candidati: cand, passo: AK.prof.passi, dev: akDev() }) }, 30000);
  if (g) g.classList.remove('luce');
  if (GN.step !== 'akProfondo') return;
  AK.prof.passi++;
  if (j && j.tipo === 'ipotesi' && j.nome){
    AK.ip = { tipo: 'ipotesi', esterna: true, e: { id: 'x_' + gmNorm(j.nome).replace(/ /g, '_'), n: j.nome, d: j.descrizione || '', w: j.wiki || '', img: j.img || '', cr: j.cr || '' } };
    gnVai('akIpotesi'); return;
  }
  if (j && j.tipo === 'domanda' && j.testo && AK.prof.passi <= 14){
    AK.prof.q = String(j.testo).slice(0, 160);
    gnVai('akLibera'); return;
  }
  /* il cervello grande non risponde: si torna al catalogo, e se il catalogo e' finito si perde */
  AK.profondo = false;
  if (AK.P && gmFinita(AK.P)) gnVai('akPerso'); else gnVai('akDomanda');
}
function akRispostaLibera(r){
  try{ gnAu.scelta(AK_ORDINE.indexOf(r) + 1); gnVibra(14); }catch(_){ }
  AK.libere.push({ d: AK.prof.q, r: r });
  gnVai('akProfondo');
}

/* ---------- il cervello grande e' dei Premium ----------
   Il gioco sul telefono e' gratis per tutti: non costa niente a nessuno. Claude invece si paga
   a consumo, ed e' l'unica parte riservata a Premium. Chi non e' Premium non vede nessun muro e
   nessuna offerta: il Genio continua con il suo catalogo, come sempre. */
function akPremium(){ try{ return (typeof Premium !== 'undefined' && Premium.isPremium) ? !!Premium.isPremium() : false; }catch(_){ return false; } }
function akProfondoOk(){ return !!AK.profondo && akPremium(); }

/* ---------- «PENSA A UN'APP DEL TUO TELEFONO»: la prova del 9 ----------
   Il catalogo sono le app che usi davvero, e le risposte giuste il Genio le conosce gia': le
   ha lette nel telefono (aperture, ore, notte, mattina). Poche decine di candidate, quattro o
   cinque domande, e una carta con l'icona vera e un dato esatto («ieri l'hai aperta 23
   volte»). Niente esce dal telefono. */
function akAppPossibile(){ try{ return typeof NATIVE !== 'undefined' && !!NATIVE && typeof NATIVE.getTimeline === 'function'; }catch(_){ return false; } }
const AK_APP_ESCLUSE = /launcher|\.home$|systemui|inputmethod|keyboard|honeyboard|packageinstaller|permissioncontroller|com\.dreambrothers\.focuslock|android\.settings$|com\.android\.settings/i;
const AK_APP_CAT = {
  social: /instagram|facebook\.katana|facebook\.lite|tiktok|musically|ugc\.trill|snapchat|twitter|com\.x\.|threads|reddit|bereal|linkedin|pinterest|tumblr/i,
  video: /youtube|tiktok|musically|ugc\.trill|netflix|primevideo|amazon\.avod|disney|twitch|raiplay|mediaset|infinity|dazn|vimeo|crunchyroll|instagram|hbo|max\.|paramount|nowtv|sky/i,
  messaggi: /whatsapp|telegram|messenger|orca|signal|viber|discord|messaging|\.mms|sms|instagram|snapchat|skype|teams|slack|line\./i,
  gioco: /game|games|supercell|king\.|rovio|miniclip|playrix|zynga|epicgames|roblox|mojang|minecraft|\.ea\.|activision|nintendo|clash|brawl|chess|pokemon|niantic|moonactive|voodoo|ketchapp|gameloft|mihoyo|hoyoverse|tencent/i,
  musica: /spotify|music|deezer|soundcloud|shazam|audible|podcast|tidal|amazon\.mp3|radio/i,
  lavoro: /docs|sheets|slides|apps\.docs|drive|office|word|excel|powerpoint|notion|trello|asana|slack|teams|zoom|meet|gmail|outlook|calendar|keep|evernote|classroom|duolingo|chatgpt|openai|claude|anthropic|gemini|copilot|linkedin|mail|todoist|ticktick|canva/i,
  acquisti: /amazon\.mshop|shopping|ebay|vinted|zalando|shein|temu|aliexpress|wish|subito|etsy|ikea|lidl|esselunga|glovo|deliveroo|justeat|ubereats/i,
  browser: /chrome|firefox|browser|opera|brave|\.edge|duckduckgo|sbrowser/i,
  ai: /chatgpt|openai|claude|anthropic|gemini|bard|copilot|perplexity|character|mistral|deepseek/i,
  foto: /camera|gallery|photos|lightroom|snapseed|vsco|picsart|canva|capcut|inshot/i
};
const AK_APP_DOMANDE = [
  { id: 'oggi', t: 'La tua app l\u2019hai già aperta oggi?' },
  { id: 'ieri30', t: 'Ieri sei stato nella tua app più di mezz\u2019ora?' },
  { id: 'ogni_giorno', t: 'La tua app la apri tutti i giorni?' },
  { id: 'dieci', t: 'La tua app la apri più di dieci volte al giorno?' },
  { id: 'notte', t: 'La tua app la usi anche dopo le undici di sera?' },
  { id: 'mattina', t: 'La tua app è tra le prime che apri appena sveglio?' },
  { id: 'top3', t: 'La tua app è una delle tre che usi di più?' },
  { id: 'lunga', t: 'Nella tua app resti anche più di dieci minuti di fila?' },
  { id: 'lampo', t: 'La tua app la apri e la richiudi in pochi secondi, tante volte?' },
  { id: 'social', t: 'La tua app è un social network?' },
  { id: 'video', t: 'Nella tua app guardi dei video?' },
  { id: 'messaggi', t: 'Nella tua app scrivi dei messaggi?' },
  { id: 'gioco', t: 'La tua app è un gioco?' },
  { id: 'musica', t: 'Nella tua app ascolti musica o podcast?' },
  { id: 'lavoro', t: 'La tua app la usi per studiare o lavorare?' },
  { id: 'google', t: 'La tua app è di Google?' },
  { id: 'acquisti', t: 'Nella tua app fai acquisti o ordini?' },
  { id: 'browser', t: 'La tua app serve per navigare su internet?' },
  { id: 'ai', t: 'La tua app è un\u2019intelligenza artificiale?' },
  { id: 'foto', t: 'La tua app serve per fare foto o montare video?' }
];
function akSoglia(v, alto, medioAlto, medioBasso){ return v >= alto ? 'Y' : (v >= medioAlto ? 'y' : (v >= medioBasso ? 'n' : 'N')); }
/** Le app degli ultimi sette giorni, con i loro numeri, e il catalogo per il motore. */
async function akAppKb(){
  if (!akAppPossibile()) return null;
  const GIORNO = 86400000, oggi0 = (typeof tlGiorno === 'function') ? tlGiorno(0) : (function(){ const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); })();
  const app = {};
  let giorni = 0;
  for (let off = 0; off < 7; off++){
    const from = (typeof tlGiorno === 'function') ? tlGiorno(off) : oggi0 - off * GIORNO;
    let d = null; try{ d = await NATIVE.getTimeline({ from: from, to: from + GIORNO, minMs: 0, limit: 1800 }); }catch(_){ d = null; }
    if (!d || !d.granted) continue;
    const g = d.grani || [];
    if (g.length) giorni++;
    const primeDelGiorno = [];
    g.forEach(function(x){
      const pk = String(x.p || ''), lb = String(x.l || pk);
      if (!pk || AK_APP_ESCLUSE.test(pk) || /launcher|^one ui|home$/i.test(lb)) return;
      const a = app[pk] = app[pk] || { p: pk, l: lb, ms: 0, n: 0, giorni: {}, oggi: 0, ieriMs: 0, ieriN: 0, notte: {}, mattina: 0, lampi: 0, max: 0 };
      const ms = x.ms || 0, h = new Date(x.s).getHours();
      a.ms += ms; a.n++; a.giorni[off] = 1;
      if (off === 0) a.oggi++;
      if (off === 1){ a.ieriMs += ms; a.ieriN++; }
      if (h >= 23 || h < 5) a.notte[off] = 1;
      if (ms < 30000) a.lampi++;
      if (ms > a.max) a.max = ms;
      if (h >= 5 && primeDelGiorno.length < 3 && primeDelGiorno.indexOf(pk) < 0) primeDelGiorno.push(pk);
    });
    primeDelGiorno.forEach(function(pk){ if (app[pk]) app[pk].mattina++; });
  }
  const lista = Object.keys(app).map(function(k){ return app[k]; }).filter(function(a){ return a.n >= 2; })
    .sort(function(a, b){ return b.ms - a.ms; }).slice(0, 40);
  if (lista.length < 6 || !giorni) return null;
  /* le icone vere, dalle app piu' usate della settimana */
  const icone = {};
  try{
    const t = NATIVE.getTopApps ? await NATIVE.getTopApps({ from: oggi0 - 6 * GIORNO, to: Date.now(), limit: 40, icons: 40 }) : null;
    ((t && t.apps) || []).forEach(function(x){ if (x.packageName && x.icon) icone[x.packageName] = x.icon; if (x.packageName && x.label && app[x.packageName]) app[x.packageName].l = x.label; });
  }catch(_){ }
  const entita = lista.map(function(a, rank){
    const nG = Object.keys(a.giorni).length, perGiorno = a.n / Math.max(1, giorni);
    const r = {
      oggi: a.oggi > 0 ? 'Y' : 'N',
      ieri30: akSoglia(a.ieriMs / 60000, 40, 30, 20),
      ogni_giorno: akSoglia(nG / Math.max(1, giorni), 0.85, 0.7, 0.4),
      dieci: akSoglia(perGiorno, 12, 8, 4),
      notte: Object.keys(a.notte).length >= 2 ? 'Y' : (Object.keys(a.notte).length === 1 ? 'y' : 'N'),
      mattina: a.mattina >= 2 ? 'Y' : (a.mattina === 1 ? 'y' : 'N'),
      top3: rank < 3 ? 'Y' : (rank < 5 ? 'n' : 'N'),
      lunga: akSoglia(a.max / 60000, 10, 6, 3),
      lampo: (a.lampi >= 5 && a.lampi / a.n >= 0.5) ? 'Y' : (a.lampi / a.n >= 0.3 ? 'y' : 'n'),
      google: /^com\.google\./i.test(a.p) || /^com\.android\.chrome$/i.test(a.p) ? 'Y' : 'N'
    };
    let qualcuna = false;
    Object.keys(AK_APP_CAT).forEach(function(c){ const si = AK_APP_CAT[c].test(a.p + ' ' + a.l); if (si) qualcuna = true; r[c] = si ? 'Y' : 'n'; });
    if (!qualcuna){ r.lavoro = '?'; }
    const fatto = a.ieriN > 0
      ? 'Ieri l\u2019hai aperta ' + a.ieriN + (a.ieriN === 1 ? ' volta' : ' volte') + ', per ' + ((typeof tlDur === 'function') ? tlDur(a.ieriMs) : Math.round(a.ieriMs / 60000) + ' minuti') + '.'
      : 'Questa settimana l\u2019hai aperta ' + a.n + ' volte.';
    return { id: a.p.replace(/[^a-z0-9_]+/gi, '_').toLowerCase().slice(0, 80), n: a.l, d: fatto, img: icone[a.p] || '', pop: rank < 3 ? 5 : (rank < 10 ? 4 : 3), r: r };
  });
  return gmPrepara({ v: 1, dominio: 'app', domande: AK_APP_DOMANDE, entita: entita });
}
function akAppEra(){
  AK.esito = 'insegnato';
  try{ gnAu.punto(); }catch(_){ }
  gnVai('akGrazie');
}

/* ---------- «LEGGI ME»: la lettura a freddo, con quello che il telefono sa ---------- */
function akRispDq(id){ try{ const r = (typeof dqRisp === 'function') ? dqRisp(id) : null; return r ? r.v : null; }catch(_){ return null; } }
function akOra(min){ min = ((Math.round(min) % 1440) + 1440) % 1440; return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }
/** Le risposte che il Genio conosce gia': dai dati del telefono (con la frase da dire) e dagli
 *  episodi della lettura (in silenzio). {q, r, peso, say?, big?} */
function akZodiaco(iso){
  const m = /^\d{4}-(\d{2})-(\d{2})$/.exec(iso || ''); if (!m) return null;
  const mm = +m[1], dd = +m[2];
  const Z = [['capricorno', 'Capricorno', 'chi arriva in cima lo fa un passo alla volta, e tu lo sai'], ['acquario', 'Acquario', 'le regole le riscrivi quando non ti stanno'], ['pesci', 'Pesci', 'senti tutto, anche quello che gli altri non dicono'], ['ariete', 'Ariete', 'parti prima di essere pronto, ed è la tua forza'], ['toro', 'Toro', 'quando ti ci metti non ti sposta nessuno'], ['gemelli', 'Gemelli', 'due idee alla volta, e la noia è il nemico'], ['cancro', 'Cancro', 'proteggi quello a cui tieni, anche troppo'], ['leone', 'Leone', 'vuoi che il risultato si veda, e si vedrà'], ['vergine', 'Vergine', 'il dettaglio lo vedi prima di tutti'], ['bilancia', 'Bilancia', 'decidere ti costa, scegliere bene ti riesce'], ['scorpione', 'Scorpione', 'tutto o niente, mai a metà'], ['sagittario', 'Sagittario', 'la strada ti attira più della meta']];
  const lim = [[1, 19], [2, 18], [3, 20], [4, 19], [5, 20], [6, 20], [7, 22], [8, 22], [9, 22], [10, 22], [11, 21], [12, 21]];
  let i = mm - 1; if (dd > lim[i][1]) i = (i + 1) % 12;
  return { k: Z[i][0], n: Z[i][1], t: Z[i][2] };
}
async function akLeggiDati(){
  const out = [];
  const metti = function(q, r, peso, say, big){ if (!out.some(function(x){ return x.q === q; })) out.push({ q: q, r: r, peso: peso, say: say || '', big: big || '' }); };
  /* LO ZODIACO (0.9.208): dalla data di nascita del profilo, senza chiederla */
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); const b = u && u.birth ? String(u.birth) : '';
    const z = akZodiaco(b);
    if (z) metti('zodiaco', z.k, 0.3, 'Sei nato sotto il segno del <strong>' + z.n + '</strong>: ' + z.t, z.n);
  }catch(_){ }
  /* IL TELEFONO: medie degli ultimi sette giorni */
  try{
    const avg = (typeof scAverages === 'function') ? await scAverages(0) : null;
    if (avg && avg.days >= 2){
      if (avg.lastMin != null){
        const sera = (avg.lastMin + 720) % 1440;            /* lastMin e' spostato di dodici ore */
        if (sera >= 60 && sera < 300) metti('notte', 'si', 0.9, 'In media, negli ultimi sette giorni, hai toccato il telefono per l’ultima volta alle <strong>' + akOra(sera) + '</strong>.', akOra(sera));
        else if (sera >= 1260 && sera <= 1410) metti('notte', 'no', 0.8, 'In media, negli ultimi sette giorni, la sera hai lasciato il telefono alle <strong>' + akOra(sera) + '</strong>.', akOra(sera));
      }
      if (avg.sleepMs > 0){
        const h = avg.sleepMs / 3600000;
        if (h < 6) metti('sonno_poco', 'si', 0.9, 'Negli ultimi sette giorni hai dormito, in media, <strong>' + h.toFixed(1).replace('.', ',') + ' ore</strong> a notte.', h.toFixed(1).replace('.', ',') + ' ore');
        else if (h >= 7) metti('sonno_poco', 'no', 0.8, 'Negli ultimi sette giorni hai dormito, in media, <strong>' + h.toFixed(1).replace('.', ',') + ' ore</strong> a notte.', h.toFixed(1).replace('.', ',') + ' ore');
      }
      if (avg.firstMin != null){
        if (avg.firstMin < 400) metti('mattina', 'ps', 0.7, 'In media prendi il telefono per la prima volta alle <strong>' + akOra(avg.firstMin) + '</strong>.', akOra(avg.firstMin));
        else if (avg.firstMin > 570) metti('mattina', 'pn', 0.7, 'In media prendi il telefono per la prima volta alle <strong>' + akOra(avg.firstMin) + '</strong>.', akOra(avg.firstMin));
      }
    }
  }catch(_){ }
  /* IERI, app per app: le aperture lampo e i social */
  try{
    const tl = (typeof tlRiassuntoDi === 'function') ? await tlRiassuntoDi(1) : null;
    if (tl && tl.riprese){
      const ab = (tl.perApp || []).filter(function(a){ return a.lampi >= 8 && !/launcher|\.home$|systemui|inputmethod|keyboard|honeyboard/i.test(String(a.p || '')); })
        .sort(function(a, b){ return b.lampi - a.lampi; })[0];
      if (ab) metti('noia', 'si', 0.9, 'Ieri hai aperto <strong>' + akEsc(ab.l || ab.p) + '</strong> ' + ab.n + ' volte, e ' + ab.lampi + ' di quelle sei uscito entro mezzo minuto.', ab.n + ' volte');
      const soc = (tl.perApp || []).filter(function(a){ return /instagram|tiktok|musically|facebook|snapchat|twitter|threads|reddit|bereal/i.test(String(a.p || '') + ' ' + String(a.l || '')); });
      const ms = soc.reduce(function(s, a){ return s + (a.ms || 0); }, 0);
      if (ms >= 2 * 3600000) metti('social', 'si', 0.9, 'Ieri sui social hai passato <strong>' + (typeof tlDur === 'function' ? tlDur(ms) : Math.round(ms / 60000) + ' min') + '</strong>.', (typeof tlDur === 'function' ? tlDur(ms) : ''));
      else if (soc.length && ms < 40 * 60000) metti('social', 'no', 0.7, 'Ieri sui social sei stato meno di <strong>quaranta minuti</strong>.', '');
      if (tl.notte >= 30 * 60000) metti('notte', 'si', 0.9, 'Ieri, fra mezzanotte e le cinque, hai passato <strong>' + (typeof tlDur === 'function' ? tlDur(tl.notte) : '') + '</strong> sullo schermo.', '');
    }
  }catch(_){ }
  /* LE SESSIONI DI FULL FOCUS delle ultime due settimane */
  try{
    const h = akLeggiJSON('fl_ff_hist', []).filter(function(x){ return x && x.ok && x.at >= Date.now() - 14 * 86400000; });
    if (h.length >= 8) metti('costante', 'si', 0.8, 'Nelle ultime due settimane hai fatto <strong>' + h.length + ' sessioni</strong> di Full Focus.', String(h.length));
    else if (h.length <= 1) metti('costante', 'pn', 0.5);
  }catch(_){ }
  /* GLI EPISODI DELLA LETTURA: risposte gia' date, in silenzio */
  const v = akRispDq;
  const mappa = [
    ['e2q3', { 'Il telefono': ['risveglio_tel', 'si'], 'Solo la sveglia': ['risveglio_tel', 'no'], 'Il caffè': ['risveglio_tel', 'no'], 'Un libro o un quaderno': ['risveglio_tel', 'no'] }],
    ['e2q1', { 'Mattina presto': ['mattina', 'si'], 'Sera tardi': ['mattina', 'no'], 'Pomeriggio': ['mattina', 'pn'] }],
    ['e2q5', { 'Meno di 5': ['sonno_poco', 'si'], '5 o 6': ['sonno_poco', 'ps'], '7 o 8': ['sonno_poco', 'no'], 'Più di 8': ['sonno_poco', 'no'] }],
    ['e2q6', { 'Una serie o dei video': ['serie_notte', 'si'], 'Il telefono': ['serie_notte', 'ps'], 'Il mio sogno': ['serie_notte', 'no'] }],
    ['e3q4', { 'Sì': ['perfetto', 'si'], 'Probabilmente sì': ['perfetto', 'ps'], 'Probabilmente no': ['perfetto', 'pn'], 'No': ['perfetto', 'no'] }],
    ['e3q3', { 'A metà, quando si fa dura': ['spinta', 'si'] }],
    ['e3q5', { 'Mi arrabbio con me': ['severo', 'si'], 'Recupero di notte': ['notte', 'ps'] }],
    ['e6q2', { 'Una scadenza': ['scadenza', 'si'], 'Una sfida con qualcuno': ['sfida', 'si'], 'Vedere i progressi': ['numeri', 'si'] }],
    ['e1q4', { 'Sì': ['raccontato', 'si'], 'Probabilmente sì': ['raccontato', 'ps'], 'Probabilmente no': ['raccontato', 'pn'], 'No': ['raccontato', 'no'] }],
    ['e5q4', { 'Mi spinge': ['spinto', 'si'], 'Mi prende in giro': ['spinto', 'no'], 'Non lo sa nessuno': ['raccontato', 'no'] }],
    ['e1q2', { 'Sì': ['passo', 'si'], 'Probabilmente sì': ['passo', 'ps'], 'Probabilmente no': ['passo', 'pn'], 'No': ['passo', 'no'] }],
    ['e4q1', { 'Sì': ['mollato', 'ps'], 'No': ['mollato', 'no'] }],
    ['e4q5', { 'Una regola morbida, che posso adattare': ['regole', 'ps'], 'Una regola dura e chiara': ['regole', 'pn'] }],
    ['e1q6', { 'Voglio dare di più a chi amo': ['altri_prima', 'ps'] }]
  ];
  mappa.forEach(function(m){ const x = v(m[0]); const t = x != null && m[1][x]; if (t) metti(t[0], t[1], 0.8); });
  try{ const s = v('e1q5'); if (typeof s === 'number'){ if (s >= 8) metti('ci_credi', 'si', 0.8); else if (s <= 4) metti('ci_credi', 'no', 0.8); } }catch(_){ }
  /* LA LETTURA DEL FUTURO (oracle.js) e il primo avvio */
  try{
    const o = (typeof orLast === 'function') ? orLast() : null;
    if (o){
      if ((o.trigger || []).some(function(t){ return t === 'noia' || t === 'morti'; })) metti('noia', 'si', 0.8);
      if ((o.trigger || []).indexOf('letto') >= 0) metti('risveglio_tel', 'ps', 0.6);
      if (o.target === 'arte') metti('creare', 'si', 0.9);
      if (o.target === 'lavoro') metti('impresa', 'si', 0.9);
      const a = o.answers || {};
      if (a.q11 != null) metti('corpo', a.q11 >= .75 ? 'si' : (a.q11 <= .25 ? 'no' : 'ns'), 0.8);
    }
  }catch(_){ }
  try{
    const g = (typeof gnDati === 'function') ? gnDati() : null;
    if (g && g.quando){ const m = +g.quando; if (m > 0 && m <= 12) metti('fretta', 'si', 0.7); else if (m >= 24) metti('fretta', 'no', 0.7); }
  }catch(_){ }
  return out;
}
async function akLeggiParti(){
  /* i dati si leggono adesso: qualche istante, e il Genio intanto «guarda» */
  akTap(false); gnPosa('pensa'); akScriviVeloce('Mmm… fammi guardare.');
  try{ AK.kbp = AK.kbp || await akKb('persone'); }catch(_){ toast('Non riesco ad aprire la lettura. Riprova fra poco.'); gnVai('akHub'); return; }
  AK.P = gmNuova(AK.kbp, { ignoto: 0.0001 });
  AK.cron = []; AK.mostrate = 0; AK.daMostrare = {};
  let dati = []; try{ dati = await akLeggiDati(); }catch(_){ }
  AK.dati = dati;
  /* i fatti con una frase da dire: il primo subito (con «Confermo»), altri due quando il motore
     vorrebbe fare proprio quella domanda. Il resto si applica in silenzio. */
  const conFrase = dati.filter(function(x){ return x.say; });
  dati.forEach(function(x){ if (conFrase.indexOf(x) < 0 || conFrase.indexOf(x) > 2) gmRispondi(AK.P, x.q, x.r, x.peso); });
  AK.P.storia = [];
  conFrase.slice(1, 3).forEach(function(x){ AK.daMostrare[x.q] = x; });
  if (conFrase[0]){ AK.fatto = conFrase[0]; AK.fatto.q = conFrase[0].q; gnVai('akLeggiSo'); return; }
  gnVai('akDomanda');
}
function akFattoOk(){
  const f = AK.fatto; if (!f) return;
  try{ gnAu.scelta(2); gnVibra(14); }catch(_){ }
  gmRispondi(AK.P, f.q, f.r, f.peso);
  AK.P.storia = [];
  AK.mostrate++; AK.fatto = null;
  gnVai('akDomanda');
}
function akLetturaHtml(e){
  /* due fatti veri dentro alla lettura: e' la differenza fra un oroscopo e una lettura */
  const fatti = (AK.dati || []).filter(function(x){ return x.say; }).slice(0, 2);
  return '<div class="ak-lettura"><div class="ak-l-top"><span>' + e.ico + '</span><div><small>Sei</small><b>' + akEsc(e.n) + '</b></div></div>'
    + '<p class="ak-l-frase">' + akEsc(e.frase) + '</p>'
    + (fatti.length ? '<ul class="ak-l-fatti">' + fatti.map(function(x){ return '<li>' + x.say + '</li>'; }).join('') + '</ul>' : '')
    + '<div class="ak-l-riga"><i>💪</i><p><b>La tua forza.</b> ' + akEsc(e.forza) + '</p></div>'
    + '<div class="ak-l-riga"><i>⚠️</i><p>' + akEsc(e.rischio) + '</p></div>'
    + '<div class="ak-l-riga mossa"><i>🎯</i><p><b>La tua mossa.</b> ' + akEsc(e.mossa) + '</p></div></div>';
}
function akDisegnaLettura(){
  const c = gmCandidati(AK.P, 2).lista[0]; if (!c){ gnVai('akHub'); return; }
  AK.lettura = c.e;
  akScena(['molte', 'ak-rivela', 'ak-lista']); akBarra(false);
  gnPosa('pensa'); akRisp(''); akScriviVeloce('Mmm…');
  const g = document.getElementById('gnGenio');
  gnAu.crescendo(1300, function(){
    if (GN.step !== 'akLeggiRivela') return;
    gnPosa('rivela'); if (g) g.classList.add('luce');
    gnScrivi(akT('leggi_rivela'), function(){
      if (g) g.classList.remove('luce');
      akRisp(akLetturaHtml(c.e)
        + '<div class="or-grid ak-tre"><button type="button" class="or-a main" onclick="event.stopPropagation();akLetturaOk(\'si\')">Sì, sono io</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();akLetturaOk(\'parte\')">Solo in parte</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();gnVai(\'akLeggiChi\')">No, non sono io</button></div>');
    });
  });
}
function akLetturaOk(come){
  try{ gnAu.punto(); }catch(_){ }
  const e = AK.lettura;
  akScriviJSON('fl_genio_lettura', { id: e.id, n: e.n, at: Date.now(), conferma: come, risposte: AK.P ? AK.P.risposte : {} });
  if (come === 'si') akRegistra('vinto', e.id, null);
  gnVai('akPatto');
}
function akSonoIo(id){
  const k = AK.kbp.ei[id]; if (k == null) return;
  AK.lettura = AK.kbp.kb.entita[k];
  akScriviJSON('fl_genio_lettura', { id: id, n: AK.lettura.n, at: Date.now(), conferma: 'scelto', risposte: AK.P ? AK.P.risposte : {} });
  akRegistra('insegnato', id, null);
  try{ gnAu.punto(); }catch(_){ }
  gnVai('akPatto');
}

(function(){
  const css = [
    /* la barra in alto della sfida: la X, il numero della domanda, quanto e' sicuro il Genio */
    '.gn-top.ak-top .gn-prog i{background:linear-gradient(90deg,#8CC6FF,#0075E3)}',
    /* le quattro carte: «Leggi me» ha il bordo azzurro, e' la carta che riguarda te */
    '.gn-card.ak-me{border-color:#8CC6FF;background:linear-gradient(180deg,#F0F8FF,#fff)}body.dark .gn-card.ak-me{border-color:#3F9FF4;background:#0B1830}',
    '.gn-card.ak-presto{opacity:.45;cursor:default}',
    '.gn-card.ak-largo{grid-column:1 / -1;flex-direction:row;justify-content:center;gap:12px;padding:12px 10px}.gn-card.ak-largo span{font-size:26px}',
    '.ak-viso.ak-app{border-radius:30px;background:#fff;padding:16px;box-sizing:border-box}.ak-viso.ak-app .ak-foto{position:static;width:100%;height:100%;object-fit:contain}.ak-viso.ak-app.senza{background:linear-gradient(135deg,#3F9FF4,#005BB0)}',
    '.ak-app-griglia{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;background:#F6F8FC;border-radius:22px;padding:14px}body.dark .ak-app-griglia{background:#141C2C}',
    '.ak-app-voce{display:flex;flex-direction:column;align-items:center;gap:5px;border:0;background:none;cursor:pointer;padding:4px 0;min-width:0}',
    '.ak-app-voce img,.ak-app-voce span{width:46px;height:46px;border-radius:13px}.ak-app-voce span{display:flex;align-items:center;justify-content:center;background:#0075E3;color:#fff;font:800 16px var(--font-display)}',
    '.ak-app-voce small{max-width:100%;font:600 10.5px var(--font-body);color:#0E2350;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .ak-app-voce small{color:#EEF4FF}',
    /* la freccia per tornare alla domanda prima: sopra ai pulsanti, a sinistra */
    '.ak-indietro{align-self:flex-start;width:40px;height:40px;border-radius:50%;border:1px solid rgba(255,255,255,.28);background:rgba(255,255,255,.14);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;margin-bottom:2px}',
    '.ak-indietro:active{transform:scale(.94)}',
    '.gn-risp .or-grid.ak-due{grid-template-columns:1fr 1fr}.gn-risp .or-grid.ak-due .or-a{grid-column:auto;font-size:14px;padding:15px 6px}',
    '.gn-risp .or-grid.ak-tre{grid-template-columns:1fr 1fr}.gn-risp .or-grid.ak-tre .or-a{grid-column:auto;font-size:13.5px;padding:14px 6px}.gn-risp .or-grid.ak-tre .or-a:first-child{grid-column:1 / -1}',
    /* la rivelazione: il Genio si fa piccolo, la carta prende la scena */
    '.gn.ak-rivela .gn-sopra{height:20vh !important;min-height:110px !important}',
    '.gn.ak-lista .gn-risp{justify-content:flex-start}',
    '.ak-carta{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;background:#fff;border:2px solid #0E2350;border-radius:22px;padding:18px 16px;color:#0E2350;animation:akCarta .55s cubic-bezier(.2,1.3,.4,1) both;margin-bottom:10px}',
    'body.dark .ak-carta{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '@keyframes akCarta{from{opacity:0;transform:scale(.86) translateY(14px)}to{opacity:1;transform:none}}',
    '.ak-viso{position:relative;width:128px;height:128px;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#3F9FF4,#005BB0);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 22px rgba(14,35,80,.25)}',
    '.ak-viso .ak-foto{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:center 22%}',
    '.ak-viso span{font:900 46px var(--font-display);color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.3)}',
    '.ak-viso:not(.senza) span{display:none}',
    '.ak-nome{display:block;margin-top:12px;font:900 26px/1.15 var(--font-display)}',
    '.ak-desc{display:block;margin-top:4px;font:600 13px/1.4 var(--font-body);color:#6A7B99}body.dark .ak-desc{color:#9FB6CF}',
    '.ak-cr{display:block;margin-top:8px;font:500 9.5px/1.3 var(--font-body);font-style:normal;color:#8B99AC}',
    /* il libro: una copertina disegnata */
    '.ak-libro{width:150px;min-height:200px;border-radius:4px 12px 12px 4px;background:linear-gradient(135deg,#0E2350,#005BB0);box-shadow:inset 8px 0 0 rgba(255,255,255,.12),0 10px 26px rgba(14,35,80,.35);display:flex;flex-direction:column;justify-content:center;padding:18px 14px;text-align:center;color:#fff}',
    '.ak-libro b{font:700 20px/1.2 Georgia,serif}.ak-libro small{margin-top:12px;font:600 11.5px/1.35 var(--font-body);color:#8CC6FF}',
    /* il film: una locandina */
    '.ak-poster{width:170px;min-height:220px;border-radius:12px;background:radial-gradient(120% 80% at 50% 0%,#005BB0,#0F2041 70%);box-shadow:0 10px 26px rgba(0,0,0,.4);display:flex;flex-direction:column;justify-content:flex-end;padding:16px 12px;text-align:center;color:#fff}',
    '.ak-poster i{font-style:normal;font-size:34px;margin-bottom:auto;padding-top:10px}.ak-poster b{font:900 21px/1.15 var(--font-display);text-transform:uppercase;letter-spacing:.02em}.ak-poster small{margin-top:8px;font:600 11px/1.35 var(--font-body);color:#BCE0FF}',
    /* le stelline quando ha indovinato */
    '.ak-stelle{position:absolute;inset:0;pointer-events:none}',
    '.ak-stelle i{position:absolute;left:50%;top:40%;width:10px;height:10px;border-radius:50%;background:#8CC6FF;box-shadow:0 0 12px #8CC6FF;opacity:0;animation:akStella 1.1s ease-out forwards}',
    '.ak-stelle i:nth-child(1){--x:-120px;--y:-70px}.ak-stelle i:nth-child(2){--x:120px;--y:-60px}.ak-stelle i:nth-child(3){--x:-90px;--y:60px}.ak-stelle i:nth-child(4){--x:100px;--y:70px;animation-delay:.1s}.ak-stelle i:nth-child(5){--x:0px;--y:-100px;animation-delay:.15s}.ak-stelle i:nth-child(6){--x:-10px;--y:100px;animation-delay:.2s}',
    '@keyframes akStella{0%{opacity:1;transform:translate(-50%,-50%) scale(.4)}100%{opacity:0;transform:translate(calc(-50% + var(--x)),calc(-50% + var(--y))) scale(1.2)}}',
    /* la data del patto */
    '.ak-data{background:#fff;border:2px solid #0E2350;border-radius:22px;padding:20px 16px;text-align:center;color:#0E2350;animation:akCarta .55s cubic-bezier(.2,1.3,.4,1) both;margin-bottom:10px}',
    'body.dark .ak-data{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.ak-data small{display:block;font:700 11px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#0075E3}',
    '.ak-data > b{display:block;margin-top:6px;font:900 36px/1 var(--font-display)}',
    '.ak-data > span{display:block;font:300 30px/1.1 var(--font-display);color:#5B6B85}body.dark .ak-data > span{color:#BFE0FF}',
    '.ak-data p{margin:12px 0 0;font:500 13.5px/1.5 var(--font-body)}.ak-data p b{font-weight:800}',
    /* «chi era?»: il campo e i nomi trovati */
    '.ak-campo{text-align:left}',
    '.ak-trovati{display:flex;flex-direction:column;gap:8px;margin-top:10px}',
    '.ak-trovato{display:flex;flex-direction:column;align-items:flex-start;gap:2px;width:100%;border:1.5px solid #C9D6EA;border-radius:14px;background:#fff;color:#0E2350;padding:11px 14px;cursor:pointer;text-align:left}',
    'body.dark .ak-trovato{background:#141C2C;border-color:#25314A;color:#EEF4FF}',
    '.ak-trovato b{font:800 14px var(--font-body)}.ak-trovato small{font:500 11.5px var(--font-body);color:#6A7B99}',
    '.ak-trovato.nuovo{border-style:dashed;border-color:#0075E3}',
    /* «Leggi me» */
    '.ak-fatto{margin:0 0 10px;text-align:center}',
    '.ak-lettura{background:#fff;border:2px solid #0E2350;border-radius:22px;padding:18px 16px;color:#0E2350;animation:akCarta .55s cubic-bezier(.2,1.3,.4,1) both;margin-bottom:10px;text-align:left}',
    'body.dark .ak-lettura{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.ak-l-top{display:flex;align-items:center;gap:12px}.ak-l-top span{font-size:44px;line-height:1}',
    '.ak-l-top small{display:block;font:700 10.5px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#0075E3}',
    '.ak-l-top b{display:block;font:900 23px/1.15 var(--font-display)}',
    '.ak-l-frase{margin:12px 0 0;font:600 15px/1.55 var(--font-body)}',
    '.ak-l-fatti{list-style:none;margin:10px 0 0;padding:0}.ak-l-fatti li{padding:9px 12px;margin-top:6px;border-radius:12px;background:#EEF4FF;font:500 13px/1.45 var(--font-body)}body.dark .ak-l-fatti li{background:rgba(63,159,244,.14)}',
    '.ak-l-riga{display:flex;gap:10px;margin-top:10px}.ak-l-riga i{font-style:normal;font-size:18px;line-height:1.3;flex:none}.ak-l-riga p{margin:0;font:500 13.5px/1.5 var(--font-body)}',
    '.ak-l-riga.mossa{padding:10px 12px;border-radius:14px;background:#FFF6DC}body.dark .ak-l-riga.mossa{background:rgba(255,217,138,.12)}',
    '.ak-scelte .or-scelta{background:#fff}body.dark .ak-scelte .or-scelta{background:#141C2C;border-color:#25314A}body.dark .ak-scelte .or-scelta b{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
