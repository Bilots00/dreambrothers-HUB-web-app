/* ===========================================================================================
   IL MONITO — sei secondi di futuro, e sono una punizione

   «We are what we choose to be. Now choose.»

   COS'È. Quando il Genio finisce la lettura e la probabilità di arrivare dove hai detto è
   sotto una certa soglia, lo schermo non torna alla scheda: si fa nero e parte un filmato.
   Non è un premio e non è motivazione generica — è la scena di Scrooge davanti alla propria
   lapide, portata dentro a un'app. Il Fantasma del Natale Futuro non lo consolava: gli faceva
   vedere dove stava andando, e quello è bastato a cambiargli la vita in una notte.

   PERCHÉ DEVE RESTARE RARO, ed è la regola più importante di questo file. Un filmato che
   arriva dopo ogni lettura diventa la sigla di un programma: la prima volta ti si gela il
   sangue, la quinta lo salti. La forza di questa cosa sta tutta nel non aspettarsela. Quindi:

     · MAI più di una volta a trimestre da sola;
     · l'eccezione è la PRESCRIZIONE — quando il Genio la mette esplicitamente fra i passi del
       percorso perché stai uscendo di strada. Quella non aspetta il trimestre, perché è il
       momento in cui serve;
     · e comunque mai due volte nella stessa settimana, nemmeno prescritta: due volte in sette
       giorni non è un monito, è un rimprovero, e a un rimprovero ci si abitua.

   IL FILMATO SI CAMBIA. Quello di serie è un segnaposto, e lo dice: la versione che funziona
   davvero è la tua faccia e la tua voce nel futuro che stai costruendo. Dalle impostazioni se
   ne carica uno proprio; il video su misura è il mestiere della sala di montaggio, non di
   questo file, che sa solo proiettare.
   =========================================================================================== */

const MON_KEY = 'fl_monito';
/* Il filmato di serie: una vita intera in quadrati, uno per settimana. Quello di prima
   (Now choose) resta solo come video scelto a mano per la chiamata dei sogni. */
const MON_VIDEO_DEF = 'video/nightmare.mp4';
/* LA FRASE FINALE, NELLA LINGUA DI CHI GUARDA. Era scritta in inglese per tutti: a chi usa
   il telefono in italiano arrivava in una lingua che non e' la sua, proprio nel momento in
   cui deve arrivare dritta. */
const MON_FRASI = {
  en: ['One day you will wake up & there won\u2019t be any more time to do the things you\u2019ve always wanted.', 'Do it now.'],
  it: ['Un giorno ti sveglierai e non ci sarà più tempo per fare le cose che hai sempre voluto fare.', 'Falle ora.'],
  es: ['Un d\u00eda despertar\u00e1s y ya no habr\u00e1 tiempo para hacer las cosas que siempre quisiste.', 'Hazlo ahora.'],
  fr: ['Un jour tu te r\u00e9veilleras et il n\u2019y aura plus de temps pour faire ce que tu as toujours voulu.', 'Fais-le maintenant.'],
  de: ['Eines Tages wachst du auf und es bleibt keine Zeit mehr f\u00fcr die Dinge, die du immer wolltest.', 'Tu es jetzt.'],
  pt: ['Um dia vais acordar e j\u00e1 n\u00e3o haver\u00e1 tempo para fazer as coisas que sempre quiseste.', 'Faz agora.']
};
/* L'AUTORE, sotto alla frase, dopo che la macchina da scrivere ha finito. */
const MON_AUTORE = '⁓ Paulo Coelho';
/* Fra virgolette, come ogni citazione dell'app (Andrea, 30/10/2026): la prima riga apre,
   l'ultima chiude, cosi' l'a capo di "Falle ora." resta dentro la frase. */
function monFrase(){
  const r = ((typeof flTesto === 'function') ? flTesto(MON_FRASI) : MON_FRASI.en).slice();
  r[0] = '"' + r[0];
  r[r.length - 1] = r[r.length - 1] + '"';
  return r;
}

/* Sotto questa probabilità di riuscita il Genio può prescrivere il monito.
   Cinquanta: non è una soglia scelta per fare effetto — è il punto in cui la cosa più probabile
   diventa il fallimento, e dirlo a parole non è mai bastato a nessuno. */
const MON_SOGLIA = 50;

const MON_TRIMESTRE_MS = 90 * 86400000;
const MON_MIN_MS = 7 * 86400000;      // il pavimento: mai due volte in una settimana

function monStato(){
  try{
    const v = JSON.parse(localStorage.getItem(MON_KEY) || 'null') || {};
    return { vistoIl: v.vistoIl || 0, volte: v.volte || 0, video: v.video || '',
             attivo: v.attivo !== false, prescritto: !!v.prescritto };
  }catch(_){ return { vistoIl: 0, volte: 0, video: '', attivo: true, prescritto: false }; }
}
function monSalva(p){
  const s = Object.assign(monStato(), p || {});
  try{ localStorage.setItem(MON_KEY, JSON.stringify(s)); }catch(_){ }
  return s;
}

/** Il filmato da proiettare: il tuo, se ne hai caricato uno. */
function monVideo(){
  const s = monStato();
  return s.video || MON_VIDEO_DEF;
}

/**
 * Si può proiettare adesso?
 *
 * @param prescritto vero quando è il Genio a chiederlo dentro al percorso. Salta l'attesa del
 *        trimestre — ma non quella della settimana, che non si salta mai.
 */
function monPuo(prescritto){
  const s = monStato();
  if (!s.attivo) return false;
  const passato = Date.now() - (s.vistoIl || 0);
  if (s.vistoIl && passato < MON_MIN_MS) return false;
  if (prescritto) return true;
  return !s.vistoIl || passato >= MON_TRIMESTRE_MS;
}

/* ---------------------------------------------------------------------------------------
   LA PROIEZIONE

   Nero pieno, niente bordi, niente pulsanti per i primi secondi. Un pulsante «chiudi» subito
   disponibile trasformerebbe sei secondi in mezzo secondo, e il senso di questa cosa è
   esattamente che devi restarci dentro. Dopo la fine compare la scelta, ed è una scelta vera:
   due strade, nessuna delle due è «ok».
   --------------------------------------------------------------------------------------- */
let MON_RITORNO = 's-home';
function monApri(opz){
  opz = opz || {};
  if (document.getElementById('monWrap')) return;
  MON_RITORNO = opz.ritorno || 's-home';

  const box = document.createElement('div');
  box.id = 'monWrap';
  box.className = 'mon-wrap';
  box.innerHTML = '<video id="monVid" class="mon-vid" playsinline autoplay preload="auto">'
    + '<source src="' + monVideo().replace(/"/g, '') + '" type="video/mp4"></video>'
    + monFineHtml(!opz.manuale);
  document.body.appendChild(box);
  document.body.classList.add('mon-on');

  const v = document.getElementById('monVid');
  let finito = false;
  const fine = function(){
    if (finito) return;
    finito = true;
    if (v){ try{ v.muted = true; v.pause(); }catch(_){ } v.classList.add('via'); }
    monFineParti();
  };
  if (v){
    v.addEventListener('ended', fine);
    v.addEventListener('error', fine);
    /* La rete di sicurezza misura il filmato, non un numero fisso: con nove secondi fissi un
       video da un minuto veniva tagliato a meta'. */
    v.addEventListener('loadedmetadata', function(){
      const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : 70;
      setTimeout(fine, Math.max(3000, (dur - (opz.da || 0)) * 1000 + 4000));
    });
    try{ const p = v.play(); if (p && p.catch) p.catch(function(){ fine(); }); }catch(_){ fine(); }
  } else fine();

  /* Conta per la rarita' del Genio solo quando e' lui a proiettarlo: guardarlo da soli dalla
     sala non deve togliergli la possibilita' di mostrarlo quando serve. */
  if (!opz.manuale) monSegnaVisto();
  if (typeof scGoalHaptic === 'function') try{ scGoalHaptic(); }catch(_){ }
  if (v && opz.da > 0) try{ v.currentTime = opz.da; }catch(_){ }
}

/**
 * LA SCHERMATA NERA, dopo il filmato.
 *
 * <p>Nero pieno e testo bianco, in chiaro e in scuro: e' l'unico punto dell'app che non segue
 * il tema, perche' il contrasto qui e' il messaggio. La frase arriva lettera per lettera, alla
 * velocita' della frase del giorno, e solo quando e' finita compaiono le uscite: la prima
 * porta alla vita in settimane, che e' la domanda che il filmato ha appena fatto.</p>
 */
function monFineHtml(genio){
  return '<div class="mon-fine" id="monFine" hidden>'
    +   '<p class="mon-tw" id="monTw"></p>'
    +   '<p class="mon-autore" id="monAutore" hidden>' + MON_AUTORE + '</p>'
    +   '<div class="mon-azioni" id="monAzioni" hidden>'
    +     '<button type="button" class="mon-cta" onclick="monMemento()">\u231b La tua vita in settimane</button>'
    +     (genio ? '<button type="button" class="mon-ghost" onclick="monScelgo()">Cambio strada. Fammi vedere come</button>' : '')
    +     '<button type="button" class="mon-ghost" data-chiudi onclick="monChiudi()">' + (MON_RITORNO === 's-genio' ? 'Torno alla scelta' : 'Chiudi') + '</button>'
    +   '</div>'
    + '</div>';
}
/** Solo la schermata nera: quando il filmato e' finito nello schermo piccolo della sala. */
function monFineApri(genio){
  if (document.getElementById('monWrap')) return;
  const box = document.createElement('div');
  box.id = 'monWrap';
  box.className = 'mon-wrap';
  box.innerHTML = monFineHtml(!!genio);
  document.body.appendChild(box);
  document.body.classList.add('mon-on');
  monFineParti();
}
function monFineParti(){
  try{ localStorage.setItem('fl_mm_visto', '1'); }catch(_){ }
  const f = document.getElementById('monFine');
  if (f) f.hidden = false;
  const tw = document.getElementById('monTw');
  if (!tw) return;
  monBatti(tw, monFrase(), function(){
    const au = document.getElementById('monAutore');
    if (au) au.hidden = false;
    const a = document.getElementById('monAzioni');
    if (a) a.hidden = false;
  });
  if (typeof cnPaint === 'function') try{ cnPaint(); }catch(_){ }
}
/* La macchina da scrivere della frase del giorno (55 ms a lettera, il cursore davanti),
   con gli a capo del manifesto. */
function monBatti(el, righe, dopo){
  el.innerHTML = '';
  const cur = document.createElement('span');
  cur.className = 'typewriter-cursor'; cur.textContent = '|';
  el.appendChild(cur);
  const testo = righe.join('\n');
  let i = 0;
  const passo = function(){
    if (!document.body.contains(el)) return;
    if (i < testo.length){
      const ch = testo[i++];
      if (ch === '\n') el.insertBefore(document.createElement('br'), cur);
      else { const sp = document.createElement('span'); sp.className = 'typewriter-char visible'; sp.textContent = ch; el.insertBefore(sp, cur); }
      setTimeout(passo, typeof CIT_MS === 'number' ? CIT_MS : 55);
      return;
    }
    setTimeout(function(){ try{ cur.remove(); }catch(_){ } }, 1600);
    if (dopo) setTimeout(dopo, 700);
  };
  setTimeout(passo, 600);
}
function monMemento(){
  monChiudi();
  if (typeof mmOpen === 'function') mmOpen(MON_RITORNO || 's-home');
}

/** Visto: qui, o nello schermo piccolo della sala. Vale la stessa rarita'. */
function monSegnaVisto(){
  monSalva({ vistoIl: Date.now(), volte: monStato().volte + 1, prescritto: false });
}

function monChiudi(){
  const b = document.getElementById('monWrap');
  const v = document.getElementById('monVid');
  if (v){ try{ v.muted = true; v.pause(); }catch(_){ } }
  if (b) b.remove();
  document.body.classList.remove('mon-on');
}

/** «Cambio strada»: porta dove si cambia davvero, cioè nel piano. */
function monScelgo(){
  monChiudi();
  if (typeof ozOpen === 'function') ozOpen();
  else if (typeof switchTab === 'function') switchTab('sveglia');
}

/**
 * Il gancio del Genio: chiamato alla fine della lettura.
 *
 * <p>Non decide qui se la persona sta andando male — lo ha già deciso l'oracolo, e questa
 * funzione si limita a rispettare le due regole di rarità. Torna vero se ha proiettato.</p>
 */
function monDopoLettura(pct, prescritto){
  if (typeof pct === 'number' && pct >= MON_SOGLIA && !prescritto) return false;
  if (!monPuo(!!prescritto)) return false;
  /* Un attimo dopo la rivelazione, non sopra: il numero deve avere il tempo di essere letto,
     altrimenti il filmato sembra la reazione dell'app invece della conseguenza del numero. */
  setTimeout(function(){ monApri(); }, 1400);
  return true;
}

/** La prescrizione: il Genio la mette fra i passi quando serve, e vale subito. */
function monPrescrivi(){
  monSalva({ prescritto: true });
}
function monPrescritto(){ return monStato().prescritto; }

/** Il passo del percorso, quando il Genio decide di prescriverlo. */
function monPasso(){
  /* 0.9.309: nelle tre mosse della lettura il tocco e' una scelta esplicita, e il filmato parte a tutto schermo
     (orGoTrailer in oracle.js). "Sei secondi" era falso: il filmato di serie dura un minuto, e quello caricato
     dall'utente puo' durare quanto vuole. */
  return { ico: '🎬', t: 'Guarda dove stai andando',
           s: (monStato().video ? 'Il tuo filmato ti mostra' : 'In un minuto vedi') + ' dove ti porta la strada di adesso, se non cambi niente.',
           go: (typeof orGoTrailer === 'function') ? 'orGoTrailer()' : 'cnVaiAlTrailer()' };
}

/* ---------------------------------------------------------------------------------------
   LE IMPOSTAZIONI — il filmato è tuo
   --------------------------------------------------------------------------------------- */
function monToggle(){
  const s = monStato();
  monSalva({ attivo: !s.attivo });
  if (typeof monPaint === 'function') monPaint();
  if (typeof toast === 'function') toast(!s.attivo ? 'Il filmato del futuro è acceso' : 'Il filmato del futuro è spento');
}

async function monScegliVideo(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickMedia){
      if (typeof toast === 'function') toast('Disponibile nell\'app installata');
      return;
    }
    const r = await NATIVE.pickMedia({ kind: 'video' });
    const uri = r && (r.uri || r.dataUri || r.path);
    if (!uri) return;
    monSalva({ video: uri });
    monPaint();
    if (typeof toast === 'function') toast('Filmato cambiato');
  }catch(_){ }
}

function monRipristina(){
  monSalva({ video: '' });
  monPaint();
  if (typeof toast === 'function') toast('Tornato al filmato di serie');
}

function monPaint(){
  const el = document.getElementById('monBody');
  if (!el) return;
  const s = monStato();
  const quando = s.vistoIl
    ? new Date(s.vistoIl).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' })
    : null;

  el.innerHTML = '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div>'
    +   '<b>🎬 Il filmato del futuro</b>'
    +   '<small>Dopo una lettura del Genio andata male, sei secondi a schermo intero su dove '
    +     'stai andando. Al massimo una volta a trimestre — o quando è il Genio a prescriverlo '
    +     'perché sei uscito di strada.</small></div>'
    +   '<button class="switch' + (s.attivo ? ' on' : '') + '" onclick="monToggle()"></button></div></div>'

    + '<div class="sect" style="margin-top:22px"><b>Il filmato</b></div>'
    + '<p class="hintline" style="padding:0 2px 12px">Quello di serie è un segnaposto. Quello che '
    + 'funziona davvero sei <b>tu</b> nel futuro che stai costruendo — la tua faccia, la tua voce.</p>'
    + '<div class="mon-prev"><video class="mon-prev-vid" src="' + monVideo().replace(/"/g, '') + '" '
    +   'muted playsinline controls preload="metadata"></video></div>'
    + '<div class="mon-azioni">'
    +   '<button type="button" class="btn ghost" onclick="monScegliVideo()">Carica il tuo ›</button>'
    +   (s.video ? '<button type="button" class="btn ghost" onclick="monRipristina()">Rimetti quello di serie</button>' : '')
    + '</div>'

    + '<div class="sect" style="margin-top:22px"><b>Provalo adesso</b></div>'
    + '<p class="hintline" style="padding:0 2px 12px">Lo vedi una volta qui senza aspettare che '
    + 'succeda davvero. Guardarlo da qui <b>non</b> consuma il turno del trimestre.</p>'
    + '<button type="button" class="btn primary" onclick="monProva()">Proietta ›</button>'
    + (quando ? '<p class="hintline" style="padding:12px 2px 0">Ultima volta: ' + quando
        + ' · ' + s.volte + (s.volte === 1 ? ' volta in tutto' : ' volte in tutto') + '</p>' : '')
    + '<div class="spacer"></div>';
}

/** La prova: proietta e RIMETTE il contatore com'era, perché una prova non è un monito. */
function monProva(){
  const prima = monStato();
  monApri();
  setTimeout(function(){ monSalva({ vistoIl: prima.vistoIl, volte: prima.volte }); }, 50);
}

registerScreen('s-monito',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-settings\')">‹</button>'
  + '<b class="blk-title">🎬 Il filmato del futuro</b></div>'
  + '<p class="hintline" style="padding:0 2px 14px">Il Fantasma del Natale Futuro non consolava '
  + 'Scrooge: gli faceva vedere dove stava andando. Questa è la stessa cosa, in sei secondi.</p>'
  + '<div id="monBody"></div>', { back: 's-settings' });

(function monStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.mon-wrap{position:fixed;inset:0;z-index:99999;background:#000;display:flex;',
      'align-items:center;justify-content:center;flex-direction:column}',
    'body.mon-on{overflow:hidden}',
    '.mon-vid{width:100%;max-height:100vh;object-fit:contain;background:#000}',
    /* La scelta compare SOPRA al nero, non in una pagina nuova: uscire dal filmato e trovarsi
       nella scheda di prima toglierebbe alla scena tutto quello che ha appena fatto. */
    '.mon-fine{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;',
      'justify-content:center;gap:10px;padding:32px 40px;background:rgba(0,0,0,.88);',
      'text-align:center;animation:monIn .5s ease-out}',
    '@keyframes monIn{from{opacity:0}to{opacity:1}}',
    '.mon-frase{margin:0;font:800 22px/1.35 var(--font-display);color:#fff}',
    '.mon-sotto{margin:0 0 14px;font:500 13.5px/1.6 var(--font-body);color:rgba(255,255,255,.72);',
      'max-width:420px}',
    '.mon-cta{border:0;border-radius:99px;padding:14px 22px;background:#fff;color:#0B1524;',
      'font:800 14px var(--font-body);cursor:pointer}',
    '.mon-ghost{border:0;background:none;color:rgba(255,255,255,.55);',
      'font:700 12px var(--font-body);cursor:pointer;padding:10px}',
    '.mon-prev{border-radius:16px;overflow:hidden;background:#000;border:1.5px solid var(--line)}',
    '.mon-prev-vid{display:block;width:100%;max-height:220px;object-fit:contain;background:#000}',
    '.mon-azioni{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}',
    '.mon-azioni .btn{flex:1 1 auto}'
  ].join('');
  document.head.appendChild(st);
})();

(function monStileFine(){
  const css = [
    '.mon-vid.via{opacity:0;transition:opacity .8s ease}',
    '#monWrap .mon-fine{position:absolute;inset:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 44px;text-align:center}',
    '#monWrap .mon-fine[hidden]{display:none}',
    '.mon-tw{margin:0;color:#fff;font:800 30px/1.18 var(--font-display);font-style:italic;letter-spacing:.01em;text-transform:uppercase}',
    '.mon-tw .typewriter-cursor{color:#fff}',
    '.mon-azioni{display:flex;flex-direction:column;gap:10px;width:100%;max-width:320px;margin-top:40px}',
    '.mon-azioni[hidden]{display:none}',
    '.mon-azioni .mon-cta{background:#fff;color:#000}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function monStileFrase(){
  const css = [
    /* IL FONT DELLA FRASE DEL GIORNO (la terza diapositiva del Blocco), non il titolo corsivo */
    '.mon-tw{font:700 21px/1.6 var(--font-body) !important;font-style:normal !important;text-transform:none !important;letter-spacing:0 !important;max-width:17em}',
    '.mon-autore{margin:16px 0 0;font:600 14px var(--font-body);letter-spacing:.06em;color:rgba(255,255,255,.72)}',
    '.mon-autore[hidden]{display:none}',
    'body.dark .mon-autore{color:rgba(0,0,0,.62)}',
    /* IN CONTRASTO CON L'APP: in chiaro nero su bianco al contrario — sfondo nero e testo
       bianco; in scuro sfondo bianco e testo nero. Chi arriva da un'app scura deve sentire
       lo stacco, e lo stesso chi arriva da un'app chiara. */
    'body.dark #monWrap .mon-fine{background:#fff}',
    'body.dark .mon-tw,body.dark .mon-tw .typewriter-cursor{color:#000}',
    'body.dark .mon-azioni .mon-cta{background:#000;color:#fff}',
    'body.dark .mon-azioni .mon-ghost{color:#000;border-color:rgba(0,0,0,.35)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
