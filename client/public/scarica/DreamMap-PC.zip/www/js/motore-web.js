/* ===========================================================================================
   IL MOTORE DI MISURA, SCRITTO IN PAGINA — e la scelta di quale dispositivo guardare

   IL DIFETTO. Sul computer il pannello di panoramica del Blocco, i tre punteggi del Profilo,
   il tempo risparmiato e la pagina Report erano vuoti o rotti («NATIVE.getScreenTimeRange is
   not a function»). La causa e' una sola: quelle quattro schermate chiedono al motore quattro
   cose — `getDayReport`, `getScreenTimeRange`, `getTopApps`, `getWebTime` — e il programma del
   computer non ne implementa nessuna. Ne implementa una sola, `getTimeline`, che pero' e' la
   piu' ricca di tutte: la cronologia al granello, con nome e orario di ogni cosa aperta.

   LA SOLUZIONE. Le altre quattro si ricavano dalla prima, qui, in pagina. Un granello ha un
   nome, un inizio e una durata: da un elenco di granelli si tirano fuori il totale, la
   classifica, i secchielli orari e i siti — che e' esattamente quello che quelle schermate
   chiedono. Cosi' il computer smette di essere una scheda mezza vuota senza che nessuno debba
   ricompilare il programma.

   E GIA' CHE SI PASSA DI QUI, LA DOMANDA GIUSTA. Il tempo di schermo del telefono, sul
   computer, e' la risposta a una domanda che nessuno ha fatto: chi apre l'app sul computer
   vuole sapere quanto ha passato AL COMPUTER, su quali programmi, su quali siti. Quindi la
   sorgente si sceglie — computer, telefono, o i due insieme — e la scelta vale per tutte le
   schermate che leggono l'uso. Di serie ognuno guarda se stesso, che e' l'unica risposta che
   non ha bisogno di essere spiegata.

   I PUNTEGGI RESTANO DEL TELEFONO. Sonno, Focus e Riposo no: quelli non cambiano dispositivo.
   Un computer acceso e lasciato li' mentre si e' in un'altra stanza direbbe «zero riposo» per
   un pomeriggio passato lontano da ogni schermo, e il sonno il computer non lo vede proprio.
   Li misura il telefono e basta, e il computer li mostra come glieli manda lui.
   =========================================================================================== */

const MW_FONTE_KEY = 'fl_rep_fonte';
const MW_FONTI = [['computer', '💻 Dati del computer'],
                  ['telefono', '📱 Dati del telefono'],
                  ['insieme',  '🔗 Tutti e due insieme']];

/** Questo dispositivo e' il computer? */
function mwQuiComputer(){
  try{ return (typeof pcQui === 'function') && pcQui() === 'desktop'; }catch(_){ return false; }
}
/**
 * Questo dispositivo ha un motore di misura VERO, o solo la ricostruzione scritta qui?
 *
 * <p>Serve a tre posti che prima riconoscevano il computer chiedendo «esiste getDayReport?».
 * Da adesso quella funzione esiste sempre, perche' gliela mettiamo noi: la domanda giusta e'
 * se sotto c'e' il motore del sistema operativo o la nostra aritmetica.</p>
 */
function mwSoloWeb(){
  try{ return typeof MW_NATIVO.getDayReport !== 'function'; }catch(_){ return true; }
}
function mwMotoreVero(){ return !mwSoloWeb(); }

/** Il rapporto del motore VERO, senza passare dalla sorgente scelta. Null se qui non c'e'. */
async function mwReportVero(dayStart){
  try{
    if (!MW_NATIVO.getDayReport) return null;
    return await MW_NATIVO.getDayReport({ dayStart: dayStart });
  }catch(_){ return null; }
}

function mwFonte(){
  let v = '';
  try{ v = localStorage.getItem(MW_FONTE_KEY) || ''; }catch(_){ }
  if (MW_FONTI.some(function(x){ return x[0] === v; })) return v;
  return mwQuiComputer() ? 'computer' : 'telefono';
}
function mwSetFonte(v, daAltro){
  try{ localStorage.setItem(MW_FONTE_KEY, v); }catch(_){ }
  /* 0.9.303: la scelta e' una sola per telefono e computer. Chi la cambia qui la manda all'altro (mwSceltaPubblica);
     quella arrivata dall'altro non si rimanda indietro. */
  if (!daAltro){ mwSceltaTimbro(); mwSceltaPubblica(); }
  try{ document.dispatchEvent(new CustomEvent('fl:fonte', { detail: v })); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   TUTTI E DUE INSIEME, SENZA DOPPIONI (0.9.303)

   Andrea: "con tutti e due insieme un'ora puo' fare 101 minuti". LA CAUSA: mwGrani mette in fila i granelli del
   telefono e quelli del computer, e mwSomma li sommava uno per uno. Se il telefono e' in mano mentre il computer resta
   acceso su una pagina, quei minuti c'erano due volte: nel totale del giorno e nelle fasce orarie (mwSecchielli passa
   da mwSomma), fino a superare i sessanta minuti in un'ora.
   Adesso, di serie, il totale e' l'UNIONE degli intervalli: il tempo in cui usi i due insieme conta una volta sola.
   I minuti di ogni app restano quelli dell'app (Instagram sul telefono e un programma sul computer, nello stesso
   quarto d'ora, hanno ciascuno il suo quarto d'ora). Si spegne da "Cosa misura il report" (report.js).
   --------------------------------------------------------------------------------------- */
const MW_UNIONE_KEY = 'fl_rep_unione';
function mwUnioneOn(){ try{ return localStorage.getItem(MW_UNIONE_KEY) !== '0'; }catch(_){ return true; } }
function mwUnioneSet(on, daAltro){
  try{ localStorage.setItem(MW_UNIONE_KEY, on ? '1' : '0'); }catch(_){ }
  if (!daAltro){ mwSceltaTimbro(); mwSceltaPubblica(); }
  try{ document.dispatchEvent(new CustomEvent('fl:fonte', { detail: mwFonte() })); }catch(_){ }
}
/** Il tempo coperto da almeno un granello fra `from` e `to`: i pezzi che si sovrappongono contano una volta. */
function mwUnione(grani, from, to){
  const pezzi = [];
  (grani || []).forEach(function(g){
    const s = Math.max(g.s, from), e = Math.min(g.s + g.ms, to);
    if (e > s) pezzi.push([s, e]);
  });
  pezzi.sort(function(a, b){ return a[0] - b[0]; });
  let ms = 0, cs = -1, ce = -1;
  pezzi.forEach(function(p){
    if (p[0] > ce){ if (ce > cs) ms += ce - cs; cs = p[0]; ce = p[1]; }
    else if (p[1] > ce) ce = p[1];
  });
  if (ce > cs) ms += ce - cs;
  return ms;
}

/* ---------------------------------------------------------------------------------------
   UNA SCELTA SOLA PER TELEFONO E COMPUTER (0.9.303)

   Fino al 0.9.302 la scelta "telefono / computer / tutti e due" restava su ogni dispositivo (specchio-web.js non la
   copiava). Decisione di Andrea: una scelta sola, uguale sui due. Viaggia in una riga di sistema dell'account,
   `fl:rep-scelta`, che scrivono TUTTI E DUE (lo specchio va solo dal telefono al computer): dentro c'e' la scelta,
   l'interruttore dei doppioni e il momento in cui e' stata fatta. Vince la piu' recente. Finche' nessuno ha scelto,
   ognuno guarda se stesso, come prima.
   --------------------------------------------------------------------------------------- */
const MW_SCELTA_SLOT = 'fl:rep-scelta';
const MW_SCELTA_T = 'fl_rep_scelta_t';
let MW_SCELTA_VISTA = '', MW_SCELTA_PUB = 0;
function mwSceltaTimbro(){ try{ localStorage.setItem(MW_SCELTA_T, String(Date.now())); }catch(_){ } }
function mwSceltaPubblica(){
  clearTimeout(MW_SCELTA_PUB);
  MW_SCELTA_PUB = setTimeout(async function(){
    try{
      if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return;
      let f = '', t = 0;
      try{ f = localStorage.getItem(MW_FONTE_KEY) || ''; t = +localStorage.getItem(MW_SCELTA_T) || 0; }catch(_){ }
      if (!t) return;
      await NATIVE.accountApi({ method: 'PUT', path: '/api/focuslock/backups', body: JSON.stringify({
        deviceId: MW_SCELTA_SLOT, deviceName: 'Scelte del report', appVersion: 'rep-scelta',
        summary: { programs: 0, apps: 0, sites: 0, keywords: 0 },
        backup: { web: { repscelta: { f: f, u: mwUnioneOn() ? 1 : 0, t: t } } } }) });
    }catch(_){ }
  }, 800);
}
/** Legge la scelta fatta sull'altro dispositivo e, se e' piu' recente della nostra, la adotta. */
async function mwSceltaLeggi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return false;
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === MW_SCELTA_SLOT; })[0];
    let mioT = 0; try{ mioT = +localStorage.getItem(MW_SCELTA_T) || 0; }catch(_){ }
    if (!riga){
      /* nessuno ha ancora scritto la riga: se qui c'e' una scelta fatta a mano (prima del 0.9.303), parte questa */
      let f = ''; try{ f = localStorage.getItem(MW_FONTE_KEY) || ''; }catch(_){ }
      if (f && mwDueDispositivi()){ if (!mioT) mwSceltaTimbro(); mwSceltaPubblica(); }
      return false;
    }
    const quando = String(riga.updatedAt || '');
    if (quando && quando === MW_SCELTA_VISTA) return false;
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const p = (pieno && pieno.payload) || null;
    const s = p && ((p.web && p.web.repscelta) || p.repscelta);
    MW_SCELTA_VISTA = quando;
    /* la nostra e' piu' recente (cambiata senza rete, o la spedizione non e' riuscita): riparte la nostra */
    if (mioT && (!s || +s.t < mioT)){ mwSceltaPubblica(); return false; }
    if (!s || !(+s.t > mioT)) return false;
    const valida = MW_FONTI.some(function(x){ return x[0] === s.f; });
    let cambiata = false;
    try{
      localStorage.setItem(MW_SCELTA_T, String(+s.t));
      if (valida && (localStorage.getItem(MW_FONTE_KEY) || '') !== s.f){ localStorage.setItem(MW_FONTE_KEY, s.f); cambiata = true; }
      const u = s.u === 0 ? '0' : '1';
      if ((localStorage.getItem(MW_UNIONE_KEY) || '1') !== u){ localStorage.setItem(MW_UNIONE_KEY, u); cambiata = true; }
    }catch(_){ }
    /* ridisegna come un cambio fatto qui (lo stesso evento), senza rimandarlo all'altro */
    if (cambiata){
      try{ document.dispatchEvent(new CustomEvent('fl:fonte', { detail: mwFonte() })); }catch(_){ }
      try{ if (typeof rpStatPaint === 'function' && document.getElementById('rpStatBody')) rpStatPaint(); }catch(_){ }
    }
    return cambiata;
  }catch(_){ return false; }
}
/**
 * La scelta si offre solo a chi ha davvero due dispositivi collegati allo stesso account.
 *
 * <p>PERCHE' I TRE PUNTINI NON COMPARIVANO. La risposta si basava sulla cache dell'ALTRO
 * dispositivo, che veniva riempita solo quando si sceglieva la sua sorgente: sul computer,
 * con la sorgente «computer», i granelli del telefono non venivano mai letti, e la domanda
 * «ne hai due?» rispondeva no per sempre. Adesso all'avvio si leggono tutte e due le fonti,
 * e la prima volta che l'altro dispositivo risulta esistere si scrive un segno su disco:
 * da li' in poi il pulsante c'e' subito, prima ancora che la rete risponda.</p>
 */
const MW_DUE_KEY = 'fl_due_dispositivi';
function mwDueDispositivi(){
  try{
    if (localStorage.getItem(MW_DUE_KEY) === '1') return true;
    /* i totali dell'altro dispositivo gia' letti una volta (pcdati.js) bastano come prova,
       e sono su disco: il pulsante c'e' dal primo disegno, senza aspettare la rete */
    try{
      const c = JSON.parse(localStorage.getItem('fl_altro_usage') || 'null');
      if (c && c.doc && c.doc.giorni && Object.keys(c.doc.giorni).length){ localStorage.setItem(MW_DUE_KEY, '1'); return true; }
    }catch(_){ }
    const altro = mwQuiComputer() ? mwGraniTelefonoCache() : mwGraniComputerCache();
    return !!(altro && altro.length);
  }catch(_){ return false; }
}

/**
 * C'E' UN SECONDO DISPOSITIVO SU QUESTO ACCOUNT? La domanda giusta, finalmente.
 *
 * <p>Prima la risposta era «l'altro dispositivo ha dei granelli PER OGGI». Sul computer
 * funzionava, perche' il telefono pubblica tutto il giorno; sul telefono no, perche' il
 * computer di notte e' spento e di giorno pubblica solo quando e' acceso. Stessa app,
 * stesso account, e il pulsante compariva su uno solo dei due: non era un capriccio del
 * telefono, era la domanda a essere sbagliata.</p>
 *
 * <p>Qui si chiede solo se la RIGA dell'altro dispositivo esiste nell'account — che e'
 * quello che «ho due dispositivi» vuol dire davvero. Una volta trovata, il segno resta su
 * disco e il pulsante c'e' da subito, anche prima che la rete risponda.</p>
 */
async function mwCercaAltro(){
  try{
    if (localStorage.getItem(MW_DUE_KEY) === '1') return true;
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return false;
    /* PERCHE' SUL TELEFONO IL PULSANTE ARRIVAVA IN RITARDO (0.9.171). Si cercava UNA riga
       sola dell'altro dispositivo, `fl:pc-grani`, e una volta sola, 1,2 secondi dopo
       l'avvio. Il computer pero' da mesi scrive anche `fl:pc-usage` (i totali dei giorni, la
       stessa riga da cui usciva il pannello «Il tuo computer»): la prova che il computer c'era
       stava gia' nell'account, e non la si guardava. E se al primo giro la riga non c'era
       ancora, nessuno richiedeva piu': il pulsante compariva solo quando, minuti dopo, il
       giro dei granelli se ne accorgeva per conto suo. Adesso vale qualunque riga dell'altro
       dispositivo, e finche' non si trova si richiede ogni minuto. */
    const suoi = mwQuiComputer() ? ['fl:dopamina', 'fl:mobile-usage', 'fl:mobile-rules'] : ['fl:pc-grani', 'fl:pc-usage'];
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const righe = (lista && lista.backups) || [];
    const ce = righe.some(function(x){ return x && suoi.indexOf(x.deviceId) >= 0; });
    if (!ce) return false;
    mwSegnaAltro([1]);
    return true;
  }catch(_){ return false; }
}
function mwSegnaAltro(grani){
  if (!grani || !grani.length) return;
  try{
    if (localStorage.getItem(MW_DUE_KEY) === '1') return;
    localStorage.setItem(MW_DUE_KEY, '1');
    /* la prima volta: le schermate che hanno il pulsante si ridisegnano. Il Report senza
       forceRender riusava il disegno di prima, quello senza i tre puntini. */
    try{ if (typeof INS !== 'undefined' && INS) INS.forceRender = true; }catch(_){ }
    ['insRender', 'scBlockScores'].forEach(function(n){ try{ if (typeof window[n] === 'function') window[n](); }catch(_){ } });
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   I GRANELLI — da qui esce tutto il resto
   --------------------------------------------------------------------------------------- */
const MW = { pc: null, pcDay: 0, tel: null, telDay: 0, at: 0 };

function mwMezzanotte(off){
  const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (off || 0));
  return d.getTime();
}
function mwChiave(t){ return (typeof dpChiave === 'function') ? dpChiave(t) : String(t); }

function mwGraniComputerCache(){ return MW.pc; }
function mwGraniTelefonoCache(){ return MW.tel; }

/** I granelli del COMPUTER per oggi: il suo motore se siamo li', il ponte se siamo altrove. */
async function mwGraniComputer(from){
  const giorno = mwChiave(from);
  /* 0.9.341: ognuna delle due cache ha il suo orologio. Con uno solo (MW.at), chiedere il telefono rinfrescava anche il
     computer: con "tutti e due insieme" i dati del computer potevano restare quelli vecchi per sempre */
  if (MW.pc && MW.pcDay === giorno && Date.now() - (MW.atPc || 0) < 60000) return MW.pc;
  let g = null;
  if (mwQuiComputer()){
    try{
      if (typeof dpGraniTelefono === 'function') g = await dpGraniTelefono(from, Date.now());
      if (g) g.forEach(function(x){ x.fonte = 'computer'; });
    }catch(_){ g = null; }
  }
  if (!g || !g.length){
    try{ g = (typeof dpGraniComputer === 'function') ? await dpGraniComputer(from) : null; }catch(_){ g = null; }
    if (!mwQuiComputer()) mwSegnaAltro(g);
  }
  MW.pc = g || []; MW.pcDay = giorno; MW.atPc = Date.now(); MW.at = Date.now();
  return MW.pc;
}

/** I granelli del TELEFONO per oggi: il suo motore se siamo li', il ponte se siamo altrove. */
async function mwGraniTelefono(from){
  const giorno = mwChiave(from);
  if (MW.tel && MW.telDay === giorno && Date.now() - (MW.atTel || 0) < 60000) return MW.tel;
  let g = null;
  if (!mwQuiComputer()){
    try{ if (typeof dpGraniTelefono === 'function') g = await dpGraniTelefono(from, Date.now()); }catch(_){ g = null; }
  }
  if (!g || !g.length){
    try{ g = (typeof dpGraniPubblicati === 'function') ? await dpGraniPubblicati(from) : null; }catch(_){ g = null; }
    if (mwQuiComputer()) mwSegnaAltro(g);
  }
  MW.tel = g || []; MW.telDay = giorno; MW.atTel = Date.now(); MW.at = Date.now();
  return MW.tel;
}

/** I granelli della sorgente scelta, per la giornata che comincia a `from`. */
async function mwGrani(from){
  const f = mwFonte();
  if (f === 'telefono') return await mwGraniTelefono(from);
  if (f === 'computer') return await mwGraniComputer(from);
  const a = await mwGraniComputer(from), b = await mwGraniTelefono(from);
  return (a || []).concat(b || []).sort(function(x, y){ return x.s - y.s; });
}

/* ---------------------------------------------------------------------------------------
   DA GRANELLI A NUMERI
   --------------------------------------------------------------------------------------- */

/** Un sito o un programma: il nome che si mostra, e la chiave con cui si somma. */
function mwNome(g){ return String(g.l || g.p || '?'); }
function mwSito(g){
  const n = mwNome(g).toLowerCase();
  return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(n) ? n : '';
}

function mwSomma(grani, from, to){
  let ms = 0, primo = 0, ultimo = 0, buco = 0, prevFine = 0;
  const per = {}, siti = {};
  (grani || []).forEach(function(g){
    const s = Math.max(g.s, from), e = Math.min(g.s + g.ms, to);
    if (!(e > s)) return;
    const d = e - s;
    ms += d;
    if (!primo || s < primo) primo = s;
    if (e > ultimo) ultimo = e;
    if (prevFine && s - prevFine > buco) buco = s - prevFine;
    if (e > prevFine) prevFine = e;
    const k = mwNome(g);
    if (!per[k]) per[k] = { packageName: g.p || k, label: k, ms: 0, launches: 0, fonte: g.fonte || g.dev || '' };
    per[k].ms += d; per[k].launches++;
    const h = mwSito(g);
    if (h){ siti[h] = (siti[h] || 0) + d; }
  });
  const top = Object.keys(per).map(function(k){ return per[k]; })
    .sort(function(a, b){ return b.ms - a.ms; });
  const web = Object.keys(siti).map(function(h){ return { host: h, ms: siti[h] }; })
    .sort(function(a, b){ return b.ms - a.ms; });
  /* 0.9.303: con telefono e computer insieme il totale e' l'unione degli intervalli (vedi mwUnione) */
  if (mwFonte() === 'insieme' && mwUnioneOn()) ms = mwUnione(grani, from, to);
  return { ms: ms, top: top, siti: web, primo: primo, ultimo: ultimo, buco: buco,
           launches: top.reduce(function(a, x){ return a + x.launches; }, 0) };
}

/* ---------------------------------------------------------------------------------------
   TUTTI E DUE INSIEME, ANCHE QUANDO IL COMPUTER MANDA SOLO IL TOTALE (0.9.341)

   Andrea: "con tutti e due insieme vedo 51 minuti, che sono quelli del telefono; il computer ne ha 30: 51 + 30 non fa
   51". LA CAUSA: con "insieme" si sommavano solo i granelli (l'uso ora per ora). Il programma del computer scrive da
   solo, ogni dieci minuti, il totale del giorno (fl:pc-usage), ma i granelli li pubblica solo quando la pagina di
   DreamMap sul computer li calcola: spesso, quindi, al telefono arriva il totale e non i granelli. "Dati del computer"
   ripiegava sul totale (30 minuti); "insieme" no, e restava il telefono da solo.
   Adesso, sul telefono, quello che manca ai granelli del computer per arrivare al suo totale di oggi si aggiunge al
   totale e alle righe delle app.
   --------------------------------------------------------------------------------------- */
function mwPcGraniMs(grani, from, to){
  let ms = 0;
  (grani || []).forEach(function(g){ if ((g.fonte || g.dev) !== 'computer') return; const a = Math.max(g.s, from), b = Math.min(g.s + g.ms, to); if (b > a) ms += b - a; });
  return ms;
}
async function mwCompletaComputer(r, grani, from, to){
  if (!r || mwFonte() !== 'insieme' || mwQuiComputer()) return r;
  if (Math.round((mwMezzanotte(0) - from) / 86400000) !== 0 && from !== mwMezzanotte(0)) return r;
  try{ if (typeof pcSync === 'function') await pcSync(false); }catch(_){ }
  const agg = mwGiornoAggregato(0); if (!agg || !(agg.ms > 0)) return r;
  const manca = agg.ms - mwPcGraniMs(grani, from, to);
  if (manca < 60000) return r;
  r.ms += manca;
  const chiave = function(x){ return String(x.label || x.packageName || '').toLowerCase(); };
  agg.top.forEach(function(t){
    const gia = r.top.filter(function(x){ return x.fonte === 'computer' && chiave(x) === chiave(t); })[0];
    if (gia) gia.ms = Math.max(gia.ms, t.ms); else r.top.push(Object.assign({}, t));
  });
  r.top.sort(function(a, b){ return b.ms - a.ms; });
  return r;
}

/** I secchielli: 'hour' per una giornata, 'day' per una finestra piu' lunga. */
function mwSecchielli(grani, from, to, bucket){
  const passo = bucket === 'day' ? 86400000 : 3600000;
  const out = [];
  for (let t = from; t < to; t += passo){
    const fine = Math.min(t + passo, to);
    const r = mwSomma(grani, t, fine);
    out.push({ start: t, ms: r.ms, launches: r.launches, count: 0 });
  }
  return out;
}

/* I giorni passati non hanno granelli: il computer pubblica per trenta giorni solo i totali
   (fl:pc-usage). Bastano per la settimana e per la tendenza, che sono fatte di giorni. */
function mwGiornoAggregato(off){
  try{
    const g = (typeof pcGiorno === 'function') ? pcGiorno(off) : null;
    if (!g) return null;
    return { ms: (g.m || 0) * 60000,
             top: (g.top || []).map(function(t){ return { packageName: t.k, label: t.k, ms: (t.m || 0) * 60000, launches: 0, fonte: 'computer' }; }) };
  }catch(_){ return null; }
}

/* ---------------------------------------------------------------------------------------
   LE ICONE (0.9.302)

   Andrea: "con i dati del PC o di tutti e due, nelle app piu' usate compaiono Chrome, DreamMap, Telegram, WhatsApp,
   One UI Home con la lettera iniziale invece dell'icona; con solo il telefono le icone ci sono". LA CAUSA: con la
   sorgente "telefono" risponde il motore del telefono, che mette l'icona in ogni riga. Con "computer" o "insieme" le
   righe le scrive mwSomma dai granelli, e un granello ha un nome e un orario, non un'icona: la riga arrivava senza,
   e il pannello disegnava la lettera. E senza il segno "launcher" la schermata Home (One UI Home) finiva fra le app.
   Adesso ogni riga prende l'icona dal dispositivo da cui arriva: quella di qui la chiede al suo motore (getAppIcon:
   Android per le app, il ponte del PC per i programmi), quella dell'altro dispositivo la legge dalla mappa di icone
   che l'altro pubblica insieme ai suoi granelli (mwIcoMappa). Un sito ha la sua icona di sito.
   --------------------------------------------------------------------------------------- */
const MW_ICO = {};
const MW_LNC = { set: null, at: 0 };
function mwQui(){ return mwQuiComputer() ? 'computer' : 'telefono'; }
/** La mappa { pacchetto: icona } e l'elenco dei launcher che l'ALTRO dispositivo ha pubblicato. */
function mwAltroPub(){
  try{
    if (mwQuiComputer()) return (typeof DP_TEL !== 'undefined' && DP_TEL) || null;
    return (typeof DP_PC !== 'undefined' && DP_PC) || null;
  }catch(_){ return null; }
}
/** I launcher del telefono (la schermata Home): il motore li segna nelle sue righe, i granelli no. */
async function mwLauncherTel(){
  if (mwQuiComputer()){ const a = mwAltroPub(); return new Set((a && a.lnc) || []); }
  if (MW_LNC.set && Date.now() - MW_LNC.at < 10 * 60000) return MW_LNC.set;
  const set = new Set();
  try{
    if (MW_NATIVO.getTopApps){
      const t = await MW_NATIVO.getTopApps({ from: mwMezzanotte(0), to: Date.now(), limit: 60, by: 'ms', icons: 0 });
      ((t && t.apps) || []).forEach(function(a){ if (a && a.launcher) set.add(a.packageName); });
    }
  }catch(_){ }
  MW_LNC.set = set; MW_LNC.at = Date.now();
  return set;
}
async function mwIcona(pkg, fonte, nome){
  if (nome && mwSito({ l: nome })){
    try{ if (typeof insSitoIcona === 'function') return insSitoIcona(nome) || ''; }catch(_){ }
    return '';
  }
  const da = fonte || mwQui();
  const k = da + '|' + pkg;
  if (MW_ICO[k] !== undefined) return MW_ICO[k];
  let ico = '';
  if (da === mwQui()){
    try{ if (NATIVE && NATIVE.getAppIcon){ const r = await NATIVE.getAppIcon({ packageName: pkg }); ico = (r && r.icon) || ''; } }catch(_){ ico = ''; }
    MW_ICO[k] = ico;
  } else {
    const a = mwAltroPub();
    ico = (a && a.ico && a.ico[pkg]) || '';
    /* 0.9.341, Andrea: "per Claude e Photos vedo la lettera C e la P invece dell'icona". LA CAUSA: la mappa delle icone
       arriva con i granelli del computer, che spesso mancano, ed e' scritta per nome di processo (claude.exe), mentre le
       righe del totale portano il nome del programma (Claude). Si cerca anche per nome, nella mappa di oggi e in quella
       tenuta da un giorno all'altro, e per i programmi piu' comuni c'e' l'icona del loro sito. */
    if (!ico) ico = mwIcoPerNome(a && a.ico, nome || pkg) || mwIcoPerNome(mwIcoTenute(), nome || pkg) || mwIcoNota(nome || pkg);
    if (a && a.ico) mwIcoTieni(a.ico);
    if (ico) MW_ICO[k] = ico;            // la mappa dell'altro puo' arrivare dopo: un buco non si ricorda
  }
  return ico;
}
function mwBase(n){ return String(n || '').toLowerCase().replace(/\.exe$/, '').replace(/[^a-z0-9]+/g, ''); }
function mwIcoPerNome(mappa, nome){
  if (!mappa || !nome) return '';
  const b = mwBase(nome); if (!b) return '';
  const k = Object.keys(mappa).filter(function(x){ const y = mwBase(String(x).split(/[\\/]/).pop()); return y && (y === b || y.indexOf(b) === 0 || b.indexOf(y) === 0); })[0];
  return k ? mappa[k] : '';
}
function mwIcoTenute(){ try{ return JSON.parse(localStorage.getItem('fl_pc_ico') || '{}') || {}; }catch(_){ return {}; } }
function mwIcoTieni(m){
  try{ const t = mwIcoTenute(); let cambi = 0; Object.keys(m || {}).forEach(function(k){ if (m[k] && t[k] !== m[k]){ t[k] = m[k]; cambi++; } }); if (cambi) localStorage.setItem('fl_pc_ico', JSON.stringify(t)); }catch(_){ }
}
const MW_ICO_NOTE = { claude: 'claude.ai', chatgpt: 'chatgpt.com', chrome: 'google.com', googlechrome: 'google.com', msedge: 'microsoft.com', edge: 'microsoft.com',
  photos: 'microsoft.com', foto: 'microsoft.com', explorer: 'microsoft.com', esplorafile: 'microsoft.com', word: 'office.com', excel: 'office.com', powerpoint: 'office.com', outlook: 'outlook.com',
  code: 'code.visualstudio.com', visualstudiocode: 'code.visualstudio.com', spotify: 'spotify.com', telegram: 'telegram.org', whatsapp: 'whatsapp.com', discord: 'discord.com',
  notion: 'notion.so', figma: 'figma.com', slack: 'slack.com', zoom: 'zoom.us', teams: 'microsoft.com', firefox: 'mozilla.org', obs: 'obsproject.com', obs64: 'obsproject.com',
  capcut: 'capcut.com', photoshop: 'adobe.com', premiere: 'adobe.com', davinciresolve: 'blackmagicdesign.com', resolve: 'blackmagicdesign.com', steam: 'steampowered.com', youtube: 'youtube.com' };
function mwIcoNota(nome){
  const b = mwBase(nome); if (!b) return '';
  const k = Object.keys(MW_ICO_NOTE).filter(function(x){ return b === x || b.indexOf(x) === 0; })[0];
  if (!k) return '';
  try{ if (typeof insSitoIcona === 'function') return insSitoIcona(MW_ICO_NOTE[k]) || ''; }catch(_){ }
  return '';
}
/** Le icone (e il segno launcher) alle prime `n` righe ricostruite dai granelli. */
async function mwArricchisci(righe, n){
  const lista = (righe || []).slice(0, n || 12);
  let lnc = null;
  for (let i = 0; i < lista.length; i++){
    const a = lista[i];
    if (!a) continue;
    if ((a.fonte || mwQui()) === 'telefono'){
      if (!lnc) lnc = await mwLauncherTel();
      if (lnc.has(a.packageName)) a.launcher = true;
    }
    if (!a.icon){ try{ a.icon = await mwIcona(a.packageName, a.fonte, a.label); }catch(_){ } }
  }
  return righe;
}
/** Un'icona piccola da spedire all'altro dispositivo: 48 px bastano per una riga da 36. */
function mwIcoPiccola(uri){
  return new Promise(function(ok){
    try{
      if (!uri || !/^data:image\/(png|jpe?g|webp)/.test(uri)){ ok(uri && uri.length < 12000 ? uri : ''); return; }
      const img = new Image();
      img.onload = function(){
        try{ const lato = Math.min(48, img.naturalWidth || 48); const c = document.createElement('canvas'); c.width = c.height = lato; c.getContext('2d').drawImage(img, 0, 0, lato, lato); ok(c.toDataURL('image/png')); }
        catch(_){ ok(''); }
      };
      img.onerror = function(){ ok(''); };
      img.src = uri;
    }catch(_){ ok(''); }
  });
}
const MW_ICO_PUB = {};
/**
 * La mappa di icone che questo dispositivo pubblica insieme ai suoi granelli (dopamina.js): le prime dodici app o
 * programmi della giornata, piu' l'elenco dei launcher del telefono. Chi guarda dall'altro dispositivo le usa.
 */
async function mwIcoMappa(grani){
  const per = {};
  (grani || []).forEach(function(g){ if (g && g.p && !mwSito(g)) per[g.p] = (per[g.p] || 0) + (g.ms || 0); });
  const primi = Object.keys(per).sort(function(a, b){ return per[b] - per[a]; }).slice(0, 12);
  const ico = {};
  for (let i = 0; i < primi.length; i++){
    const pkg = primi[i];
    if (MW_ICO_PUB[pkg] === undefined){
      let u = '';
      try{ if (NATIVE && NATIVE.getAppIcon){ const r = await NATIVE.getAppIcon({ packageName: pkg }); u = (r && r.icon) || ''; } }catch(_){ u = ''; }
      MW_ICO_PUB[pkg] = u ? await mwIcoPiccola(u) : '';
    }
    if (MW_ICO_PUB[pkg]) ico[pkg] = MW_ICO_PUB[pkg];
  }
  let lnc = [];
  if (!mwQuiComputer()){ try{ lnc = Array.from(await mwLauncherTel()); }catch(_){ lnc = []; } }
  return { ico: ico, lnc: lnc };
}

/* ---------------------------------------------------------------------------------------
   LE QUATTRO FUNZIONI CHE LE SCHERMATE CHIEDONO
   --------------------------------------------------------------------------------------- */
let MW_NATIVO = {};

async function mwDayReport(a){
  const dayStart = (a && a.dayStart) || mwMezzanotte(0);
  const oggi = dayStart === mwMezzanotte(0);
  const fine = oggi ? Date.now() : dayStart + 86400000;
  const off = Math.round((mwMezzanotte(0) - dayStart) / 86400000);

  let r = null;
  if (oggi){
    const g = await mwGrani(dayStart);
    if (g && g.length) r = await mwCompletaComputer(mwSomma(g, dayStart, fine), g, dayStart, fine);
  }
  if (!r && mwFonte() !== 'telefono'){
    /* 0.9.305: i totali del computer stanno in PC.doc, che si riempie solo con pcSync (dalla cache su disco, se fresca):
       chi chiedeva un giorno passato prima che qualcun altro l'avesse chiamata riceveva "senza dati" */
    try{ if (typeof pcSync === 'function' && typeof PC !== 'undefined' && PC && !PC.doc) await pcSync(false); }catch(_){ }
    const agg = mwGiornoAggregato(off);
    if (agg) r = { ms: agg.ms, top: agg.top, siti: [], primo: 0, ultimo: 0, buco: 0, launches: 0 };
  }
  /* 0.9.305, Andrea: "sul PC il Report settimanale e' vuoto, e il telefono e' collegato". LA CAUSA: sul computer con
     la sorgente "telefono" un giorno passato non aveva nessun ripiego (i granelli del telefono ci sono solo per oggi) e
     tornava senzaDati: sette giorni vuoti. Il telefono pero' pubblica i totali di ogni giorno (fl:mobile-usage,
     pcdati.js) e la giornata di oggi (fl:dopamina, specchio-web.js): si usano quelli, come fa il carburante. */
  if (!r && mwQuiComputer() && mwFonte() === 'telefono'){
    try{
      const g = (typeof SW_GIORNO !== 'undefined' && SW_GIORNO) ? SW_GIORNO.rep : null;
      if (oggi && g && g.granted && g.dayStart === dayStart) return g;
      if (typeof pcAltroSync === 'function') await pcAltroSync(false);
      const doc = (typeof PC_ALTRO !== 'undefined' && PC_ALTRO) ? PC_ALTRO.doc : null;
      const t = (doc && doc.giorni && typeof pcChiave === 'function') ? doc.giorni[pcChiave(off)] : null;
      if (t && t.m > 0) r = { ms: t.m * 60000, siti: [], primo: 0, ultimo: 0, buco: 0, launches: 0,
        top: (t.top || []).map(function(x){ return { packageName: x.k, label: x.k, ms: (x.m || 0) * 60000, launches: 0, fonte: 'telefono' }; }) };
    }catch(_){ }
  }
  /* 0.9.301, Andrea: "passando ai dati del PC il pannello di panoramica sparisce, e il Profilo mi chiede il permesso che
     ho gia' dato". LA CAUSA: qui "il computer oggi non ha mandato niente" usciva come { granted: false }, la stessa
     risposta di "permesso negato". Il pannello si svuotava (e con lui i tre puntini per tornare al telefono) e il
     Profilo chiedeva un permesso che c'e'. Adesso il vuoto si dice per quello che e': senzaDati, con la sorgente. */
  if (!r) return { granted: false, senzaDati: true, fonte: mwFonte(), dayStart: dayStart };
  try{ await mwArricchisci(r.top, 12); }catch(_){ }

  /* Quello che il computer non puo' sapere resta vuoto invece di essere inventato: sblocchi,
     blocchi e notifiche di Windows non passano da nessuna parte che possiamo leggere. */
  return {
    granted: true, dayStart: dayStart, screenMs: r.ms, top: r.top.slice(0, 12),
    pickups: 0, blocks: 0, sessions: 0,
    firstUse: r.primo, lastUse: r.ultimo, longestGapMs: r.buco,
    awakeScreenMs: r.ms, awakeGapMs: r.buco, sleepMs: 0, sleepStart: 0, wakeAt: r.primo,
    lockedMs: 0, countLocked: false, daMotoreWeb: true, siti: r.siti
  };
}

async function mwScreenTimeRange(a){
  const from = (a && a.from) || mwMezzanotte(0);
  const to = (a && a.to) || Date.now();
  const bucket = (a && a.bucket) || 'none';
  const giorni = Math.round((to - from) / 86400000);
  /* Una finestra lunga si fa con i totali dei giorni, che sono l'unica cosa che c'e'. */
  if (giorni > 1 && bucket === 'day'){
    const buckets = [];
    let tot = 0;
    for (let t = from; t < to; t += 86400000){
      const off = Math.round((mwMezzanotte(0) - t) / 86400000);
      let ms = 0;
      if (off === 0){ const g0 = await mwGrani(mwMezzanotte(0)); const r = await mwCompletaComputer(mwSomma(g0, t, Math.min(t + 86400000, to)), g0, t, Math.min(t + 86400000, to)); ms = r.ms; }
      else { const agg = mwGiornoAggregato(off); ms = agg ? agg.ms : 0; }
      tot += ms;
      /* 0.9.331, Andrea: "il tuo telefono dice 0 minuti". Chi legge .minutes (l'onboarding, il rapporto) riceveva sempre zero con la sorgente computer o "tutti e due" */
      buckets.push({ start: t, ms: ms, minutes: Math.floor(ms / 60000), launches: 0 });
    }
    return { ms: tot, minutes: Math.floor(tot / 60000), launches: 0, buckets: buckets };
  }
  const g = await mwGrani(mwMezzanotte(Math.round((mwMezzanotte(0) - from) / 86400000)));
  const r = (from === mwMezzanotte(0)) ? await mwCompletaComputer(mwSomma(g, from, to), g, from, to) : mwSomma(g, from, to);
  return { ms: r.ms, minutes: Math.floor(r.ms / 60000), launches: r.launches,
           buckets: bucket === 'none' ? [] : mwSecchielli(g, from, to, bucket).map(function(b){ return Object.assign({ minutes: Math.floor((b.ms || 0) / 60000) }, b); }) };
}

async function mwTopApps(a){
  const from = (a && a.from) || mwMezzanotte(0);
  const to = (a && a.to) || Date.now();
  const lim = (a && a.limit) || 5;
  const g = await mwGrani(mwMezzanotte(Math.round((mwMezzanotte(0) - from) / 86400000)));
  const r = (from === mwMezzanotte(0)) ? await mwCompletaComputer(mwSomma(g, from, to), g, from, to) : mwSomma(g, from, to);
  const per = (a && a.by) === 'launches'
    ? r.top.slice().sort(function(x, y){ return y.launches - x.launches; })
    : r.top;
  const apps = per.slice(0, lim);
  try{ await mwArricchisci(apps, Math.min(lim, 12)); }catch(_){ }
  return { apps: apps };
}

async function mwWebTime(a){
  const from = (a && a.from) || mwMezzanotte(0);
  const to = (a && a.to) || Date.now();
  const lim = (a && a.limit) || 5;
  const g = await mwGrani(mwMezzanotte(Math.round((mwMezzanotte(0) - from) / 86400000)));
  const soli = (g || []).filter(function(x){ return !!mwSito(x); });
  const r = mwSomma(soli, from, to);
  return { ms: r.ms, sites: r.siti.slice(0, lim),
           buckets: (a && a.bucket && a.bucket !== 'none') ? mwSecchielli(soli, from, to, a.bucket) : [] };
}

/* ---------------------------------------------------------------------------------------
   L'INNESTO

   Si mettono nelle mani del motore, non nelle schermate: le schermate sono quindici e
   chiamano queste quattro funzioni in trenta punti. Se il motore vero c'e' e la sorgente e'
   il telefono, si lascia rispondere lui — e' piu' preciso di qualunque ricostruzione.
   --------------------------------------------------------------------------------------- */
(function mwInnesta(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || NATIVE.__mw) return;
    ['getDayReport', 'getScreenTimeRange', 'getTopApps', 'getWebTime', 'getNotifications']
      .forEach(function(k){ if (typeof NATIVE[k] === 'function') MW_NATIVO[k] = NATIVE[k].bind(NATIVE); });

    const via = function(k, mio){
      return async function(a){
        /* Il motore vero risponde quando la domanda e' sua: sorgente telefono, su un telefono. */
        if (MW_NATIVO[k] && mwFonte() === 'telefono' && !mwQuiComputer()){
          try{ return await MW_NATIVO[k](a); }catch(e){ /* e se non risponde, si ricostruisce */ }
        }
        return await mio(a);
      };
    };
    NATIVE.getDayReport = via('getDayReport', mwDayReport);
    NATIVE.getScreenTimeRange = via('getScreenTimeRange', mwScreenTimeRange);
    NATIVE.getTopApps = via('getTopApps', mwTopApps);
    NATIVE.getWebTime = via('getWebTime', mwWebTime);
    /* Le notifiche di Windows non passano da nessuna parte: si dice, non si inventa. */
    NATIVE.getNotifications = via('getNotifications', async function(){ return { granted: false, total: 0, apps: [], buckets: [] }; });
    NATIVE.__mw = true;
  }catch(_){ /* motore non estendibile: resta tutto com'era */ }
})();

/* Cambiare sorgente ridisegna quello che c'e' a schermo. */
document.addEventListener('fl:fonte', function(){
  MW.pc = null; MW.tel = null; MW.at = 0;
  /* LA CACHE DEL REPORT NON SI SVUOTAVA. Le sue chiavi dicono il giorno, non la sorgente:
     «day:1790…:t» era lo stesso identico nome per i numeri del telefono e per quelli del
     computer. Cambiando sorgente la domanda era nuova, ma la risposta in cache era vecchia,
     e restava li' finche' non scadeva da sola. Da fuori sembrava un'app lentissima; era
     un'app che rispondeva subito, con il dato di prima. */
  try{ if (typeof INS_CACHE !== 'undefined' && INS_CACHE) INS_CACHE.clear(); }catch(_){ }
  try{ if (typeof INS !== 'undefined' && INS) INS.forceRender = true; }catch(_){ }
  try{ if (typeof SC !== 'undefined' && SC) SC.mem = {}; }catch(_){ }
  try{ Object.keys(localStorage).forEach(function(k){ if (k.indexOf('fl_dayrep_') === 0) localStorage.removeItem(k); }); }catch(_){ }
  ['scBlockScores', 'scLifePaint', 'insRender', 'scRender', 'pfcPaint', 'insWarm']
    .forEach(function(n){ try{ if (typeof window[n] === 'function') window[n](); }catch(_){ } });
});

/** Le voci del menu «da dove arrivano questi numeri», o stringa vuota se il secondo non c'e'. */
function mwMenuHtml(){
  if (!mwDueDispositivi()) return '';
  const f = mwFonte();
  return '<p class="arb-mtit">Da dove</p>'
    + MW_FONTI.map(function(x){
        return '<button type="button" class="' + (x[0] === f ? 'on' : '') + '" onclick="mwScegli(\'' + x[0] + '\')">'
          + x[1] + '</button>';
      }).join('');
}
function mwScegli(v){
  try{ if (typeof scMenusClose === 'function') scMenusClose(); }catch(_){ }
  try{ if (typeof insMenuClose === 'function') insMenuClose(); }catch(_){ }
  try{ if (typeof insFonteChiudi === 'function') insFonteChiudi(); }catch(_){ }
  mwSetFonte(v);
}
/** L'etichetta corta, per dire sotto a un numero da dove arriva. */
function mwEtichetta(){
  const f = mwFonte();
  return f === 'computer' ? 'computer' : (f === 'insieme' ? 'telefono + computer' : 'telefono');
}

/* All'avvio si scaldano TUTTE E DUE le fonti: la propria per i numeri, l'altra per sapere se
   esiste. Poi ogni cinque minuti, che e' il passo con cui l'altro pubblica. */
function mwScalda(){
  try{ mwGraniComputer(mwMezzanotte(0)); }catch(_){ }
  try{ mwGraniTelefono(mwMezzanotte(0)); }catch(_){ }
}
setTimeout(mwScalda, 400);
setTimeout(mwCercaAltro, 600);
/* finche' l'altro dispositivo non si trova, si richiede: puo' collegarsi a app gia' aperta */
setInterval(function(){
  try{ if (!document.hidden && localStorage.getItem(MW_DUE_KEY) !== '1') mwCercaAltro(); }catch(_){ }
}, 60000);
setInterval(function(){ if (!document.hidden) mwScalda(); }, 60000);
/* la scelta fatta sull'altro dispositivo: all'avvio, ogni minuto e quando l'app torna davanti (solo con due dispositivi) */
setTimeout(function(){ if (mwDueDispositivi()) mwSceltaLeggi(); }, 900);
setInterval(function(){ if (!document.hidden && mwDueDispositivi()) mwSceltaLeggi(); }, 60000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden && mwDueDispositivi()) mwSceltaLeggi(); });
/* 0.9.331: il telefono vero, qualunque sorgente sia scelta nel Report. Serve dove lo schermo dice "sul telefono" (l'onboarding, il primo ladro) */
function mwTelefono(k, a){
  if (MW_NATIVO[k] && !mwQuiComputer()) return MW_NATIVO[k](a);
  return NATIVE[k](a);
}
