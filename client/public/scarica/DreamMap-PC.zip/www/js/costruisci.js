/* ===========================================================================================
   COSTRUISCI LA TUA MAPPA — la personalizzazione della prima schermata (0.9.172)

   Dal prototipo di Claude Design («DreamMap Prototipo», pagina Personalizza). Si apre dalla
   matita sulla card dell'arrivo previsto e da «Nuova pagina» nella Mappa.

   COSA SI PUO' TOCCARE, E COSA NO. La copertina (le immagini nostre, quattro sfumature, o una
   foto dalla galleria), l'icona del sogno, il colore, il nome del sogno in una riga, e i
   blocchi della Rotta: spostarli, toglierli, rimetterli. Niente font, niente margini, niente
   colori liberi: la veste e' una sola ed e' decisa qui. E' l'effetto IKEA dentro a binari
   stretti: si sente di aver costruito la propria pagina, ma non si puo' passare la sera a
   fare il designer.

   QUANDO SI APRE. Dopo la prima mossa fatta oggi (una riga spuntata o un Full Focus portato
   a termine). Il primo giorno, quando non c'e' ancora nessuna storia, e' aperta: la si
   costruisce la prima volta. Mai durante una sessione di Full Focus. E' la regola scelta
   in 0.9.172 (vedi il diario): la personalizzazione e' il premio della mossa, non la
   scusa per rimandarla. La Modalita' severa non c'entra: quella parla dei blocchi.
   =========================================================================================== */

const CST_KEY = 'fl_mappa_cfg';
const CST_IMG_KEY = 'fl_mappa_cover_img';
const CST_COPERTINE = [
  { k: 'img/dream-night.jpg', n: 'Notte' }, { k: 'img/bg/montagne.jpg', n: 'Montagne' }, { k: 'img/bg/aurora.jpg', n: 'Aurora' },
  { k: 'img/bg/mare.jpg', n: 'Mare' }, { k: 'img/bg/take-flight.jpg', n: 'In volo' }, { k: 'img/bg/luna.jpg', n: 'Luna' },
  { k: 'img/bg/alba.jpg', n: 'Alba' }, { k: 'img/bg/dune.jpg', n: 'Dune' }, { k: 'img/bg/foresta.jpg', n: 'Foresta' },
  { k: 'img/oblo/tramonto.jpg', n: 'Oblò' }
];
const CST_SFUMATURE = [
  { k: 'grad:#0B3F7A,#001E44', n: 'Blu notte' }, { k: 'grad:#0E2350,#C42B38', n: 'Rosso notte' },
  { k: 'grad:#0A4D68,#05BFDB', n: 'Laguna' }, { k: 'grad:#2C1810,#C2410C', n: 'Brace' }
];
const CST_ICONE = ['🎯', '🚀', '✈️', '🎓', '🏋️', '🎵', '💎', '⛵', '💰', '🏠', '📚', '🧘', '🎬', '🌍', '💻', '❤️'];
/* 0.9.265, Andrea: il tondo con l'icona del sogno di serie e' TRASPARENTE come la matita accanto; il blu resta
   una scelta. Troppi colori diversi nello stesso pannello non dicono qual e' il colore del brand. */
const CST_TEMI = [
  { k: 'vetro', n: 'Trasparente', c: 'rgba(255,255,255,.16)', sw: 'linear-gradient(135deg,#C9D9EE,#EAF3FE)' },
  { k: 'blu', n: 'Blu', c: '#0075E3' }, { k: 'notte', n: 'Notte', c: '#001E44' },
  { k: 'cielo', n: 'Cielo', c: '#3F9FF4' }, { k: 'abisso', n: 'Abisso', c: '#00468C' }
];
/* i blocchi della pagina Dream (0.9.186: TUTTI, nell'ordine di serie) */
const CST_BLOCCHI = [
  /* fisso: qui c'e' la matita che apre questa pagina. Toglierlo vorrebbe dire non poter piu' tornare qui */
  /* 0.9.304: il pannello a schede (rotta-tab.js) ha preso il posto dell'interruttore, della serie del Genio, della
     prossima mossa e di "Prevedi il tuo futuro" (il blocco nvFuturo non c'e' piu': cstCfg lo toglie dalle liste vecchie) */
  { id: 'nvArrBlock', ico: '🧭', n: 'Il tuo viaggio', s: 'La tua storia, il sogno con la data d\u2019arrivo, la Mappa con la prossima tappa e chi stai diventando', fisso: true },
  { id: 'nvHero', ico: '🎞️', n: 'Lo slideshow', s: 'L\u2019arrivo previsto, la sfida del Genio e la frase del giorno' },
  { id: 'nvTop', ico: '🔮', n: 'Il rientro in rotta', s: 'Il Genio ti aiuta a rientrare quando la data d\u2019arrivo si sposta' },
  { id: 'nvChips', ico: '↔️', n: 'Le scorciatoie', s: 'Protezione, umore, respiro guidato, ispirazione, appunti, suoni, Report' },
  /* 0.9.301, Andrea: il pannello di panoramica esce da Dream e diventa un blocco facoltativo. Di serie resta nella pagina
     "Proteggi i tuoi sogni", nelle revisioni e nel Rientra in rotta; qui lo rimette chi lo vuole (diSerie: false) */
  { id: 'nvTempo', ico: '⏱️', n: 'Dove va la tua attenzione?', s: 'Il tempo sul telefono di oggi, ora per ora', diSerie: false },
  { id: 'nvSfide', ico: '🏆', n: 'Le sfide', s: 'Il sabotatore, il rimpianto futuro, la prossima tappa' },
  { id: 'nvChiama', ico: '📞', n: 'Chiama il tuo Io futuro', s: 'La chiamata dal te che ce l\u2019ha fatta' },
  { id: 'nvSveglia', ico: '🎥', n: 'Videochiama il tuo Io futuro', s: 'In arrivo' },
  { id: 'nvGuida', ico: '🧞', n: 'Il tuo agente personale', s: 'Ottieni una guida 1-1' },
  { id: 'spDream', ico: '🫧', n: 'Le persone in cammino e la missione', s: 'Quante persone lavorano al loro sogno adesso, e la catena dei sogni', solo: function(){ return typeof flAdmin === 'function' && flAdmin(); } },
  { id: 'nvConsigli', ico: '✨', n: 'Consigliato per te', s: 'Respiri, suoni e sessioni scelti per te' },
  { id: 'nvRecenti', ico: '🎧', n: 'Ascoltati di recente', s: 'I suoni che hai ascoltato, da riprendere' },
  /* 0.9.306, Andrea: "Le tue pagine" della Mappa si puo' mettere anche in Dream; lo disegna dream-extra.js con lo
     stesso html della Mappa (mppPagineHtml).
     0.9.309: e' gia' nella pagina quando finisce l'onboarding, e di serie e' l'ultimo blocco di Dream.
     0.9.318, Andrea: "di default in fondo, ma l'utente deve poterlo spostare": niente piu' blocchi fissati in fondo. */
  { id: 'nvPagine', ico: '📄', n: 'Le tue pagine', s: 'Il sogno, il piano, il diario di viaggio, i suoni e le tue pagine' }
  /* 0.9.305, Andrea: "Parla con il Genio" (nvBottom, la barra per scrivergli) tolto da Dream: cstCfg lo toglie anche
     dalle liste salvate, perche' tiene solo i blocchi di questo elenco */
];

function cstCfg(){
  let c = {}; try{ c = JSON.parse(localStorage.getItem(CST_KEY) || '{}') || {}; }catch(_){ }
  if (!c.cover) c.cover = 'img/dream-night.jpg';
  if (!c.icon) c.icon = '🎯';
  /* tv 2: prima di 0.9.265 il blu era messo di serie anche a chi non l'aveva scelto */
  if (!c.tema || (c.tv !== 2 && c.tema === 'blu')) c.tema = 'vetro';
  if (typeof c.nome !== 'string') c.nome = '';
  /* DALLA 0.9.186 I BLOCCHI SONO TUTTI: chi aveva la lista vecchia (quattro blocchi) riparte
     dall'ordine di serie, tenendo quelli che aveva tolto. Le porte erano un blocco solo. */
  if (c.bv !== 2){
    const vecchi = Array.isArray(c.blocchi) ? c.blocchi : [];
    const spento = function(id){ const v = vecchi.filter(function(x){ return x.id === id; })[0]; return !!(v && v.on === false); };
    c.blocchi = CST_BLOCCHI.map(function(b){ return { id: b.id, on: b.diSerie !== false && !(spento(b.id) || ((b.id === 'nvChiama' || b.id === 'nvSveglia') && spento('nvPorte'))) }; });
    c.bv = 2;
    try{ localStorage.setItem(CST_KEY, JSON.stringify(c)); }catch(_){ }
  }
  /* 0.9.301: una volta sola, il pannello di panoramica si toglie da Dream anche a chi lo aveva (scelta di Andrea);
     da Personalizza si rimette con "Aggiungi" e da li' resta com'e' */
  if (c.tempo301 !== 1){
    c.tempo301 = 1;
    (c.blocchi || []).forEach(function(b){ if (b.id === 'nvTempo') b.on = false; });
    try{ localStorage.setItem(CST_KEY, JSON.stringify(c)); }catch(_){ }
  }
  /* 0.9.309: una volta sola, "Le tue pagine" entra acceso in fondo a Dream anche per chi c'era gia' (prima era spento
     di serie). Chi lo toglie da Personalizza dopo questa versione lo trova tolto: pag309 non lo riaccende piu'. */
  if (c.pag309 !== 1){
    c.pag309 = 1;
    if (!Array.isArray(c.blocchi)) c.blocchi = [];
    const vp = c.blocchi.filter(function(b){ return b && b.id === 'nvPagine'; })[0];
    if (vp) vp.on = true; else c.blocchi.push({ id: 'nvPagine', on: true });
    try{ localStorage.setItem(CST_KEY, JSON.stringify(c)); }catch(_){ }
  }
  c.blocchi = c.blocchi.filter(function(b){ return CST_BLOCCHI.some(function(x){ return x.id === b.id; }); });
  c.blocchi.forEach(function(b){ if (CST_BLOCCHI.some(function(x){ return x.id === b.id && x.fisso; })) b.on = true; });
  /* le sfide (0.9.210) entrano subito dopo le scorciatoie, non in fondo */
  if (!c.blocchi.some(function(x){ return x.id === 'nvSfide'; })){ const iC = c.blocchi.map(function(x){ return x.id; }).indexOf('nvChips'); c.blocchi.splice(iC >= 0 ? iC + 1 : c.blocchi.length, 0, { id: 'nvSfide', on: true }); }
  /* 0.9.242: un blocco nuovo entra subito dopo quello che lo precede nell'elenco, non in fondo */
  CST_BLOCCHI.forEach(function(b, i){
    if (c.blocchi.some(function(x){ return x.id === b.id; })) return;
    const prima = i > 0 ? c.blocchi.findIndex(function(x){ return x.id === CST_BLOCCHI[i - 1].id; }) : -1;
    if (prima >= 0) c.blocchi.splice(prima + 1, 0, { id: b.id, on: b.diSerie !== false }); else c.blocchi.push({ id: b.id, on: b.diSerie !== false });
  });
  /* 0.9.309: i blocchi `ultimo` (Le tue pagine) stanno sempre in fondo, qualunque ordine sia salvato */
  const inFondo = c.blocchi.filter(function(b){ return cstUltimo(b.id); });
  if (inFondo.length) c.blocchi = c.blocchi.filter(function(b){ return !cstUltimo(b.id); }).concat(inFondo);
  return c;
}
function cstUltimo(id){ return CST_BLOCCHI.some(function(x){ return x.id === id && x.ultimo; }); }
function cstSalva(c){ try{ localStorage.setItem(CST_KEY, JSON.stringify(c)); }catch(_){ } cstApplica(); }
function cstTema(){ const k = cstCfg().tema; return CST_TEMI.filter(function(t){ return t.k === k; })[0] || CST_TEMI[0]; }
function cstIcona(){ return cstCfg().icon || '🎯'; }
/** Il CSS dello sfondo scelto: un'immagine, una sfumatura, o la foto caricata. */
function cstCoverCss(){
  const c = cstCfg().cover;
  if (c === 'mia'){ let d = ''; try{ d = localStorage.getItem(CST_IMG_KEY) || ''; }catch(_){ } return d ? "url('" + d + "')" : "url('img/dream-night.jpg')"; }
  if (c.indexOf('grad:') === 0){ const p = c.slice(5).split(','); return 'linear-gradient(160deg,' + p[0] + ',' + p[1] + ')'; }
  return "url('" + c + "')";
}
function cstBlocchi(){ return cstCfg().blocchi; }

/* ---- la regola d'apertura ---- */
/* LA PAGINA SI PUO' SEMPRE MODIFICARE, salvo una scelta: chi accende la Modalita' severa puo'
   chiedere che si blocchi anche la pagina del sogno (`fl_cst_blocco` = 'severa'). Prima si
   apriva solo dopo la prima mossa del giorno: Andrea l'ha tolto, il limite lo decide lui. */
function cstBloccoSevera(){ try{ return localStorage.getItem('fl_cst_blocco') === 'severa'; }catch(_){ return false; } }
function cstBloccoSeveraSet(on){ try{ localStorage.setItem('fl_cst_blocco', on ? 'severa' : 'mai'); }catch(_){ } }
function cstSeveraAccesa(){ try{ return !!(typeof sevState !== 'undefined' && sevState && sevState.level > 0); }catch(_){ return false; } }
function cstAperto(){
  try{ if (typeof FF !== 'undefined' && FF && FF.run) return { ok: false, perche: 'Sei in una sessione di Full Focus. La mappa aspetta.' }; }catch(_){ }
  if (cstBloccoSevera() && cstSeveraAccesa()) return { ok: false, perche: 'L\'hai deciso tu: con la Modalità severa accesa la pagina del sogno resta com\'è.' };
  return { ok: true };
}

function cstApri(sez, forza){
  const a = forza ? { ok: true } : cstAperto();
  if (!a.ok){ toast(a.perche); if (typeof stGoFocus === 'function' && /Full Focus/.test(a.perche) === false) { /* niente: la mossa la sceglie lui */ } return; }
  goId('s-costruisci');
  cstPaint();
  if (sez){ setTimeout(function(){ const el = document.getElementById('cst-' + sez); if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 350); }
}
function cstNuovaPagina(){
  const a = cstAperto();
  if (!a.ok){ toast(a.perche); return; }
  cstApri('blocchi');
  setTimeout(function(){ toast('Nuova pagina: parti da un blocco qui sotto'); }, 400);
}
function cstFatto(){ goId('s-home'); if (typeof switchTab === 'function') switchTab('rotta'); toast('Salvato'); }

registerScreen('s-costruisci',
  '<div class="topbar cst-top"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button>'
  + '<b class="blk-title cst-tit">Personalizza la scheda Sogno</b></div>'
  + '<div id="cstBody"></div>'
  /* «Salva» in fondo alla pagina (0.9.186): in alto finiva sopra al titolo */
  + '<button type="button" class="cta cst-salva" onclick="cstFatto()">Salva</button><div class="spacer"></div>'
  + '<input type="file" id="cstFile" accept="image/*" hidden onchange="cstCarica(this)">', { back: 's-home' });

function cstPaint(){
  const box = document.getElementById('cstBody'); if (!box) return;
  const c = cstCfg(), tema = cstTema();
  let nome = c.nome; try{ if (!nome && typeof nvSogno === 'function') nome = nvSogno(); }catch(_){ }
  let arrivo = ''; try{ const a = etaArrivo(); if (a && isFinite(a.at) && !(typeof evVelata === 'function' && evVelata())){ const d = new Date(a.at); arrivo = d.getDate() + ' ' + NV_MESI[d.getMonth()] + ' ' + d.getFullYear(); } }catch(_){ }
  const cop = function(k, n, css){
    return '<button type="button" class="cst-cop' + (c.cover === k ? ' on' : '') + '" style="background:' + css + ' center/cover" onclick="cstSet(\'cover\',\'' + k + '\')" aria-label="' + esc(n) + '"></button>';
  };
  let mia = ''; try{ mia = localStorage.getItem(CST_IMG_KEY) || ''; }catch(_){ }
  const blocchi = c.blocchi.map(function(b, i){
    const d = CST_BLOCCHI.filter(function(x){ return x.id === b.id; })[0]; if (!d || (d.solo && !d.solo())) return '';
    const ult = !!d.ultimo, primaUlt = !!(c.blocchi[i + 1] && cstUltimo(c.blocchi[i + 1].id));
    return '<div class="cst-bl' + (b.on ? '' : ' off') + '">'
      + '<span class="cst-bl-ico">' + d.ico + '</span>'
      + '<div><b>' + esc(d.n) + '</b><small>' + esc(b.on ? (d.fisso ? 'Qui c\u2019è la matita: resta sempre' : (ult ? 'Resta sempre in fondo alla pagina' : d.s)) : (d.diSerie === false ? 'Blocco facoltativo' : 'Tolto dalla pagina')) + '</small></div>'
      + (b.on
          ? (ult ? '' : '<button type="button" class="cst-mini" aria-label="Su" onclick="cstSposta(' + i + ',-1)"' + (i === 0 ? ' disabled' : '') + '><span class="chev su"></span></button>'
            + '<button type="button" class="cst-mini" aria-label="Giù" onclick="cstSposta(' + i + ',1)"' + (i === c.blocchi.length - 1 || primaUlt ? ' disabled' : '') + '><span class="chev giu"></span></button>')
            + (d.fisso ? '<span class="cst-mini lucchetto" aria-label="Resta sempre">🔒</span>' : '<button type="button" class="cst-mini x" aria-label="Togli" onclick="cstTogli(' + i + ')">✕</button>')
          : '<button type="button" class="cst-rimetti" onclick="cstRimetti(' + i + ')">' + (d.diSerie === false ? 'Aggiungi' : 'Rimetti') + '</button>')
      + '</div>';
  }).join('');
  box.innerHTML =
      '<div class="cst-prev"><div class="cst-prev-cov" style="background:' + cstCoverCss() + ' center/cover"><i style="background:linear-gradient(180deg,' + cstRgba(tema.c, .25) + ',' + cstRgba(tema.c, .55) + ' 45%,rgba(0,19,43,.92))"></i></div>'
    +   '<div class="cst-prev-in"><span class="cst-prev-ico" style="background:' + tema.c + '">' + c.icon + '</span>'
    +     '<b>' + esc(nome || 'Il tuo sogno') + '</b>' + (arrivo ? '<small>Arrivo previsto il ' + esc(arrivo) + '</small>' : '') + '</div></div>'
    + '<h3 class="cst-h" id="cst-copertina">Copertina</h3>'
    + '<div class="cst-cops">'
    +   (mia ? cop('mia', 'La tua foto', 'url(' + mia + ')') : '')
    +   CST_COPERTINE.map(function(x){ return cop(x.k, x.n, 'url(' + x.k + ')'); }).join('')
    +   CST_SFUMATURE.map(function(x){ const p = x.k.slice(5).split(','); return cop(x.k, x.n, 'linear-gradient(160deg,' + p[0] + ',' + p[1] + ')'); }).join('')
    + '</div>'
    + '<button type="button" class="cst-galleria" onclick="document.getElementById(\'cstFile\').click()">📷 ' + (mia ? 'Cambia la tua foto' : 'Una foto dalla galleria') + '</button>'
    + '<h3 class="cst-h" id="cst-icona">Icona del sogno</h3>'
    + '<div class="cst-icone">' + CST_ICONE.map(function(e){ return '<button type="button" class="cst-ico' + (c.icon === e ? ' on' : '') + '" style="' + (c.icon === e ? 'background:' + (tema.sw || tema.c) : '') + '" onclick="cstSet(\'icon\',\'' + e + '\')">' + e + '</button>'; }).join('') + '</div>'
    + '<h3 class="cst-h" id="cst-colore">Colore</h3>'
    + '<div class="cst-temi">' + CST_TEMI.map(function(t){ return '<button type="button" class="cst-tema' + (c.tema === t.k ? ' on' : '') + '" onclick="cstSet(\'tema\',\'' + t.k + '\')"><span style="background:' + (t.sw || t.c) + ';box-shadow:' + (c.tema === t.k ? '0 0 0 3px var(--bg,#F4F9FF),0 0 0 6px ' + (t.sw ? '#9FB6D8' : t.c) : 'none') + '"></span>' + t.n + '</button>'; }).join('') + '</div>'
    + '<h3 class="cst-h" id="cst-nome">Il nome del sogno</h3>'
    + '<div class="fld"><input class="fin" id="cstNome" maxlength="26" placeholder="' + esc(nome || 'es. Libertà economica') + '" value="' + esc(c.nome) + '" onchange="cstSet(\'nome\',this.value)" autocomplete="off">'
    +   '<div class="hint">Corto, su una riga: è quello che leggi ogni mattina sopra alla data.</div></div>'
    + '<h3 class="cst-h" id="cst-blocco">Con la Modalità severa</h3>'
    + '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>Blocca anche questa pagina</b><small>Con la Modalità severa accesa, copertina e blocchi restano come sono. Niente da sistemare mentre dovresti agire.</small></div>'
    +   '<button class="switch' + (cstBloccoSevera() ? ' on' : '') + '" onclick="cstBloccoSeveraSet(!cstBloccoSevera());this.classList.toggle(\'on\')"></button></div></div>'
    + '<h3 class="cst-h" id="cst-slide">Le slide dello slideshow</h3>'
    + '<button type="button" class="cst-galleria" onclick="flSlideFoglio(\'rotta\',\'Le slide della scheda Sogno\')">🎞️ Scegli quali slide vedere</button>'
    + '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>Una slide nuova a ogni apertura</b><small>Ogni volta che apri l’app la scheda Sogno parte dalla slide dopo: la prima, poi la seconda, poi la terza, e di nuovo da capo.</small></div>'
    +   '<button class="switch' + (nvRuotaOn() ? ' on' : '') + '" onclick="nvRuotaSet(!nvRuotaOn());this.classList.toggle(\'on\')"></button></div></div>'
    + '<h3 class="cst-h" id="cst-blocchi">I blocchi della pagina</h3>'
    + '<p class="cst-p">Le frecce spostano, la ✕ toglie, "Rimetti" e "Aggiungi" mettono il blocco nella pagina. Chiama e Sveglia si spostano anche nella pagina: tienile premute e trascinale.</p>'
    + '<div class="cst-bls">' + blocchi + '</div>';
}
function cstRgba(hex, a){
  const h = String(hex).replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(function(x){ return x + x; }).join('') : h, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}
function cstSet(k, v){
  const c = cstCfg();
  if (k === 'nome') v = String(v || '').trim().slice(0, 26);
  c[k] = v;
  if (k === 'tema') c.tv = 2;
  cstSalva(c);
  cstPaint();
  if (k === 'nome' && typeof nvPaint === 'function') nvPaint();
}
function cstSposta(i, d){
  const c = cstCfg(); const j = i + d;
  if (j < 0 || j >= c.blocchi.length) return;
  if (cstUltimo(c.blocchi[i].id) || cstUltimo(c.blocchi[j].id)) return;
  const t = c.blocchi[i]; c.blocchi[i] = c.blocchi[j]; c.blocchi[j] = t;
  cstSalva(c); cstPaint();
}
function cstTogli(i){ const c = cstCfg(); const d = c.blocchi[i] && CST_BLOCCHI.filter(function(x){ return x.id === c.blocchi[i].id; })[0]; if (d && d.fisso) return; if (c.blocchi[i]) c.blocchi[i].on = false; cstSalva(c); cstPaint(); }
function cstRimetti(i){ const c = cstCfg(); if (c.blocchi[i]) c.blocchi[i].on = true; cstSalva(c); cstPaint(); }

/* LA FOTO DALLA GALLERIA: ridotta a 1080px di lato lungo e salvata come JPEG. Una foto da
   telefono intera sono 4-8 MB: non starebbe in localStorage e rallenterebbe ogni apertura. */
function cstCarica(inp){
  const f = inp && inp.files && inp.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = function(){
    const img = new Image();
    img.onload = function(){
      const M = 1080, s = Math.min(1, M / Math.max(img.width, img.height));
      const cv = document.createElement('canvas'); cv.width = Math.round(img.width * s); cv.height = Math.round(img.height * s);
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      let d = ''; try{ d = cv.toDataURL('image/jpeg', .82); }catch(_){ }
      if (!d){ toast('Non riesco a leggere questa foto'); return; }
      try{ localStorage.setItem(CST_IMG_KEY, d); }catch(_){ toast('La foto è troppo grande per essere salvata'); return; }
      cstSet('cover', 'mia');
    };
    img.src = r.result;
  };
  r.readAsDataURL(f);
  inp.value = '';
}

/* ---- dove si vede: la card della Rotta, la card del sogno nella Mappa, l'ordine dei blocchi ---- */
function cstApplica(){
  const c = cstCfg(), tema = cstTema();
  /* la copertina scelta va sul pannello dell'arrivo e sulla sua slide */
  [document.getElementById('nvArrCard'), document.querySelector('#nvHero .nv-arr-s')].forEach(function(s0){
    if (s0){ s0.style.setProperty('--bh-img', cstCoverCss()); s0.style.setProperty('--bh-pos', 'center 70%'); }
  });
  ['nvArrivo', 'nvArrivoSlide'].forEach(function(id){ const arr = document.getElementById(id); if (arr) arr.style.setProperty('--nv-tinta', tema.c); });
  document.querySelectorAll('.mpp-pag.cover').forEach(function(el){ el.style.background = '#001E44 ' + cstCoverCss() + ' center 75%/cover'; });
  cstOrdinaBlocchi();
  try{ if (typeof hdrDreamApply === 'function') hdrDreamApply(); }catch(_){ }
}
/* i blocchi: si rimettono dentro a .nv-page nell'ordine scelto, senza toccarne il contenuto */
function cstOrdinaBlocchi(){
  const page = document.querySelector('#tab-rotta .nv-page'); if (!page) return;
  if (CST_DRAG.on) return;
  const ordine = [];
  cstCfg().blocchi.forEach(function(b){
    const el = document.getElementById(b.id); if (!el) return;
    if (el.hidden !== !b.on) el.hidden = !b.on;
    ordine.push(el);
  });
  const piede0 = page.querySelector(':scope > .hd-piede'); if (piede0) ordine.push(piede0);
  /* 0.9.265: si sposta solo se l'ordine e' cambiato (flOrdina, scorre.js) */
  if (typeof flOrdina === 'function') flOrdina(page, ordine); else ordine.forEach(function(e){ page.appendChild(e); });
  /* 0.9.326, Andrea: "tutti i blocchi della scheda Sogno trascinabili" */
  CST_BLOCCHI.forEach(function(b){ const el = document.getElementById(b.id); if (el && el.parentElement === page) cstTrascinabile(el); });
  /* il piede «Personalizza» resta in fondo (0.9.204) */
  const piede = page.querySelector(':scope > .hd-piede'); if (piede && page.lastElementChild !== piede) page.appendChild(piede);
}

/* TIENI PREMUTO E TRASCINA (0.9.187), come le app della schermata Home di Android: dopo mezzo
   secondo la card si alza (vibra), segue il dito, e i blocchi le fanno posto. Lasciandola,
   l'ordine nuovo e' quello della pagina, e si salva. Il tocco breve resta un tocco. */
const CST_DRAG = { on: false, el: null, dx: 0, dy: 0, fine: 0, x: 0, y: 0, raf: 0 };
/* 0.9.326, Andrea: "quando si tiene premuto la pagina non scorre: dovrebbe scorrere verso l'alto o verso il basso a seconda di dove viene trascinato il blocco" */
function cstScroller(el){
  let p = el.parentElement;
  while (p && p !== document.body){ const o = getComputedStyle(p).overflowY; if ((o === 'auto' || o === 'scroll') && p.scrollHeight > p.clientHeight + 4) return p; p = p.parentElement; }
  return document.scrollingElement || document.documentElement;
}
function cstTrascinabile(el){
  if (el.dataset.trascina) return;
  el.dataset.trascina = '1';
  let timer = 0, x0 = 0, y0 = 0;
  const parti = function(x, y){
    CST_DRAG.on = true; CST_DRAG.el = el;
    const r = el.getBoundingClientRect(); CST_DRAG.dx = x - r.left; CST_DRAG.dy = y - r.top;
    el.classList.add('cst-alzato');
    try{ flVibra(18); }catch(_){ }
    CST_DRAG.x = x; CST_DRAG.y = y;
    const sc = cstScroller(el);
    const giro = function(){
      if (!CST_DRAG.on || CST_DRAG.el !== el) return;
      const q = sc.getBoundingClientRect ? sc.getBoundingClientRect() : { top: 0, bottom: innerHeight };
      const alto = Math.max(q.top, 0) + 110, basso = Math.min(q.bottom, innerHeight) - 130;
      let v = 0;
      if (CST_DRAG.y < alto) v = -Math.min(18, (alto - CST_DRAG.y) / 5);
      else if (CST_DRAG.y > basso) v = Math.min(18, (CST_DRAG.y - basso) / 5);
      if (v){ const prima = sc.scrollTop; sc.scrollTop += v; if (sc.scrollTop !== prima) segui(CST_DRAG.x, CST_DRAG.y); }
      CST_DRAG.raf = requestAnimationFrame(giro);
    };
    CST_DRAG.raf = requestAnimationFrame(giro);
  };
  const segui = function(x, y){
    CST_DRAG.x = x; CST_DRAG.y = y;
    const page = el.parentElement; if (!page) return;
    el.style.transform = '';
    el.style.pointerEvents = 'none';
    /* il dito puo' stare sopra alla barra in basso: conta il blocco che c'e' sotto */
    let bersaglio = null;
    (document.elementsFromPoint(x, y) || []).some(function(n){ bersaglio = n.closest ? n.closest('#tab-rotta .nv-page > *') : null; return !!bersaglio; });
    el.style.pointerEvents = '';
    if (bersaglio && bersaglio !== el && !bersaglio.hidden){
      const rb = bersaglio.getBoundingClientRect();
      const meta = (bersaglio.id === 'nvChiama' || bersaglio.id === 'nvSveglia') ? (x > rb.left + rb.width / 2) : (y > rb.top + rb.height / 2);
      const dopo = meta ? bersaglio.nextSibling : bersaglio;
      if (dopo !== el && el.nextSibling !== dopo) page.insertBefore(el, dopo);
    }
    const r = el.getBoundingClientRect();
    /* un blocco alto non deve coprire la pagina che scorre: resta un dito sopra al punto dove lo tieni */
    const dy = Math.min(CST_DRAG.dy, 70);
    el.style.transform = 'translate(' + (x - CST_DRAG.dx - r.left) + 'px,' + (y - dy - r.top) + 'px) scale(' + (r.height > 320 ? '.98' : '1.05') + ')';
  };
  const chiudi = function(){
    clearTimeout(timer);
    if (!CST_DRAG.on || CST_DRAG.el !== el) return;
    CST_DRAG.on = false; CST_DRAG.el = null; CST_DRAG.fine = Date.now();
    cancelAnimationFrame(CST_DRAG.raf);
    el.classList.remove('cst-alzato'); el.style.transform = '';
    const page = el.parentElement; if (!page) return;
    const ordine = Array.prototype.map.call(page.children, function(c){ return c.id; }).filter(function(id){ return CST_BLOCCHI.some(function(b){ return b.id === id; }); });
    const c = cstCfg();
    c.blocchi = ordine.map(function(id){ const v = c.blocchi.filter(function(b){ return b.id === id; })[0]; return v || { id: id, on: true }; })
      .concat(c.blocchi.filter(function(b){ return ordine.indexOf(b.id) < 0; }));
    try{ localStorage.setItem(CST_KEY, JSON.stringify(c)); }catch(_){ }
    /* 0.9.309: lasciata sotto a "Le tue pagine", la card torna sopra: quel blocco resta sempre l'ultimo */
    try{ cstOrdinaBlocchi(); }catch(_){ }
  };
  el.addEventListener('touchstart', function(e){ const p = e.touches[0]; x0 = p.clientX; y0 = p.clientY; clearTimeout(timer); timer = setTimeout(function(){ parti(x0, y0); }, 480); }, { passive: true });
  el.addEventListener('touchmove', function(e){
    const p = e.touches[0];
    if (!CST_DRAG.on){ if (Math.abs(p.clientX - x0) > 8 || Math.abs(p.clientY - y0) > 8) clearTimeout(timer); return; }
    e.preventDefault(); segui(p.clientX, p.clientY);
  }, { passive: false });
  el.addEventListener('touchend', chiudi); el.addEventListener('touchcancel', chiudi);
  /* col mouse (il gemello sul computer): stesso gesto */
  el.addEventListener('mousedown', function(e){ x0 = e.clientX; y0 = e.clientY; clearTimeout(timer); timer = setTimeout(function(){ parti(x0, y0); }, 480); });
  document.addEventListener('mousemove', function(e){ if (CST_DRAG.on && CST_DRAG.el === el) segui(e.clientX, e.clientY); else if (Math.abs(e.clientX - x0) > 8 || Math.abs(e.clientY - y0) > 8) clearTimeout(timer); });
  document.addEventListener('mouseup', chiudi);
  /* il tocco che chiude un trascinamento non apre la porta */
  el.addEventListener('click', function(e){ if (Date.now() - CST_DRAG.fine < 400){ e.stopPropagation(); e.preventDefault(); } }, true);
  el.addEventListener('contextmenu', function(e){ e.preventDefault(); });
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'rotta' || e.detail === 'mappa') setTimeout(cstApplica, 80); });
setTimeout(cstApplica, 1500);

(function(){
  const css = [
    '.cst-top{position:relative}',
    '.cst-tit{flex:1;text-align:center;margin-right:48px}',
    '.cst-salva{margin-top:28px}',
    '.cst-prev{border-radius:24px;overflow:hidden;background:var(--card,#fff);border:1px solid var(--line)}',
    'body.dark .cst-prev{background:#12203A;border-color:#22345A}',
    '.cst-prev-cov{height:132px;position:relative}.cst-prev-cov i{position:absolute;inset:0}',
    '.cst-prev-in{display:flex;flex-direction:column;align-items:center;text-align:center;padding:0 20px 20px;margin-top:-32px;position:relative}',
    '.cst-prev-ico{width:64px;height:64px;border-radius:32px;border:4px solid var(--card,#fff);display:flex;align-items:center;justify-content:center;font-size:30px}',
    'body.dark .cst-prev-ico{border-color:#12203A}',
    '.cst-prev-in b{margin-top:8px;font:800 20px var(--font-display);color:var(--navy);max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .cst-prev-in b{color:#fff}',
    '.cst-prev-in small{margin-top:2px;font:500 13px var(--font-body);color:var(--muted)}',
    '.cst-h{margin:28px 0 12px;text-align:center;font:700 15px var(--font-display);color:var(--navy)}body.dark .cst-h{color:#fff}',
    '.cst-p{margin:-6px 0 12px;text-align:center;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    /* l'anello blu della copertina scelta sporge di 6 px e la copertina cresce del 6%: serve spazio, o viene tagliato */
    '.cst-cops{display:flex;gap:14px;overflow-x:auto;overflow-y:visible;scrollbar-width:none;padding:14px 14px;margin:0 -14px}',
    '.cst-cops::-webkit-scrollbar{display:none}',
    '.cst-cop{flex:none;width:64px;height:64px;border-radius:16px;border:0;cursor:pointer;transition:transform .25s cubic-bezier(.3,1.6,.5,1),box-shadow .2s}',
    '.cst-cop.on{transform:scale(1.06);box-shadow:0 0 0 3px var(--bg,#F4F9FF),0 0 0 6px var(--blue,#0075E3)}',
    '.cst-galleria{display:block;margin:12px auto 0;border:1.5px solid var(--line);border-radius:99px;background:transparent;padding:10px 18px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .cst-galleria{color:#fff;border-color:#22345A}',
    '.cst-icone{display:grid;grid-template-columns:repeat(8,1fr);gap:6px}',
    '.cst-ico{aspect-ratio:1;border-radius:50%;border:0;background:var(--card,#fff);font-size:20px;cursor:pointer;transition:transform .25s cubic-bezier(.3,1.6,.5,1),background .2s}',
    'body.dark .cst-ico{background:#12203A}',
    '.cst-ico.on{transform:scale(1.1)}',
    '.cst-temi{display:flex;justify-content:center;gap:16px}',
    '.cst-tema{display:flex;flex-direction:column;align-items:center;gap:6px;border:0;background:none;font:500 11px var(--font-body);color:var(--muted);cursor:pointer}',
    '.cst-tema span{width:44px;height:44px;border-radius:22px;transition:transform .25s cubic-bezier(.3,1.6,.5,1)}.cst-tema.on span{transform:scale(1.1)}',
    '.cst-bls{display:flex;flex-direction:column;gap:8px}',
    '.cst-bl{display:flex;align-items:center;gap:10px;background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:12px 12px 12px 16px}',
    'body.dark .cst-bl{background:#12203A;border-color:#22345A}',
    '.cst-bl.off{opacity:.6}',
    '.cst-bl-ico{font-size:20px;flex:none;width:26px;text-align:center}',
    '.cst-bl > div{flex:1;min-width:0}.cst-bl b{display:block;font:600 14px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .cst-bl b{color:#fff}',
    '.cst-bl small{display:block;font:500 11.5px var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.cst-mini{width:32px;height:32px;flex:none;border-radius:16px;border:0;background:var(--bg,#F4F9FF);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .cst-mini{background:rgba(255,255,255,.08);color:#fff}',
    '.cst-mini[disabled]{opacity:.3}',
    '.cst-mini .chev.su{transform:rotate(-90deg)}.cst-mini .chev.giu{transform:rotate(90deg)}',
    '.cst-mini.x{font:700 13px var(--font-body);color:var(--muted)}',
    '.cst-alzato{position:relative;z-index:30;transition:none !important}.cst-alzato .pt-mini{box-shadow:0 18px 40px rgba(0,30,68,.35)}',
    '.cst-mini.lucchetto{background:transparent;font-size:14px}',
    '.cst-rimetti{flex:none;border:0;border-radius:99px;background:var(--blue-soft,#E3F1FF);color:var(--blue,#0075E3);padding:8px 14px;font:700 12px var(--font-body);cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
