/* onboarding.js - screens s0..s16, corsia U-E.
 *
 * The mock OAuth sheet, the hours slider, the multiple-choice questions, the tap-to-block demo,
 * the drag-to-continue lock, the schedule editor and the final summary.
 *
 * Two things changed shape here. First, the answers are now KEPT: s4, s5, s12, s13 and s14 all
 * wrote to nothing, so by s16 the app knew nothing about the person it had just interviewed and
 * the summary was a set of hardcoded strings (G89). Everything now lands in one object, ONB,
 * and the summary is computed from it. Second, index.html is frozen and shared by six lanes, so
 * the markup that had to change (the fixed 12:00/14:00 spans, the missing way out of s10, the
 * legal links with no href) is adjusted from here, at load time, instead of being edited there.
 */

/* ============================================================================
 * THE ANSWERS — one object, one key, saved on every change
 * ========================================================================== */

const ONB_KEY = 'fl_onboarding';
const ONB_DEFAULT = {
  estimate: null,          // s3, hours/day guess
  problems: [],            // s4
  triggers: [],            // s5
  method: null,            // s12, what the user picked
  methodEffective: 'ora',  // what we can actually build today (see pickMethod)
  from: '12:00', to: '14:00', allDay: false,
  days: [false,false,false,false,false,false,true],   // 0 = lunedì, like Schedule on the native side
  quotaDay: 30,            // minutes/day when method is "limite"
  categories: ['social','discover'],                  // s14 starts with these two ticked
  configured: false        // true once the user has actually walked s12 -> s13 -> s14
};
let ONB = (function(){
  try{
    const raw = JSON.parse(localStorage.getItem(ONB_KEY) || 'null');
    return raw ? Object.assign({}, ONB_DEFAULT, raw) : Object.assign({}, ONB_DEFAULT);
  }catch(e){ return Object.assign({}, ONB_DEFAULT); }
})();
function onbSave(){ try{ localStorage.setItem(ONB_KEY, JSON.stringify(ONB)); }catch(e){} }

/* The keys behind the choice cards, in the order they appear in index.html. Reading the label
   text would break the moment a word is edited; an index is stable and leaves the copy free. */
/* DOM order of the rows in #s4 / #s5: most common first. Keep in sync with index.html. */
const PROBLEM_KEYS = ['social','binge','doomscroll','games','adult','gambling'];
const TRIGGER_KEYS = ['letto','noia','vuoti','stress','studio'];
const CATEGORY_KEYS = ['social','discover','gambling','streaming','musica'];

/* What each s14 category actually blocks. This is the whole reason the last screen can claim
   "5 categorie bloccate" honestly: the program built at the end contains exactly this.
   The package names are the well-known ones; a package that is not installed simply never
   matches, so listing it costs nothing and covers the user who installs it tomorrow. */
const CATEGORIES = {
  social: {
    label: 'Social network',
    apps: ['com.instagram.android','com.zhiliaoapp.musically','com.facebook.katana',
           'com.twitter.android','com.snapchat.android','com.instagram.barcelona'],
    sites: ['instagram.com','tiktok.com','facebook.com','x.com','twitter.com','threads.net','snapchat.com']
  },
  discover: {
    label: 'Google Discover e News',
    apps: [],
    sites: ['news.google.com','discover.google.com']
  },
  gambling: {
    label: 'Gambling e scommesse',
    apps: [],
    sites: ['bet365.com','sisal.it','snai.it','eurobet.it','goldbet.it','betflag.it',
            'pokerstars.it','williamhill.com','casino','scommesse']
  },
  streaming: {
    label: 'Streaming',
    apps: ['com.netflix.mediaclient','com.google.android.youtube','com.disney.disneyplus'],
    sites: ['netflix.com','youtube.com','primevideo.com','disneyplus.com']
  },
  musica: {
    label: 'Musica e messaggistica',
    apps: ['com.spotify.music','com.whatsapp'],
    sites: ['spotify.com','web.whatsapp.com']
  }
};

/* The first problem they admitted to becomes the name of their first program. Calling it
   "Programma 1" would throw away the only piece of personalisation the quiz actually produced. */
const NAME_BY_PROBLEM = {
  social:'Meno social', gambling:'Stop alle scommesse', games:'Meno gaming',
  adult:'Contenuti puliti', doomscroll:'Stop al doomscrolling', binge:'Meno streaming'
};

/* ============================================================================
 * AUTH (mock OAuth — in produzione: Firebase Auth / Credential Manager)
 * ========================================================================== */
const SHEETS={
  google:`
    <div class="grab"></div>
    <h3>Scegli un account</h3>
    <div class="ssub">per continuare su DreamMap</div>
    <button class="acct" onclick="login('Andrea','andrea.bilotta00@gmail.com','google')">
      <span class="av" style="background:#005BB0">A</span>
      <span><b>Andrea Bilotta</b><small>andrea.bilotta00@gmail.com</small></span>
    </button>
    <button class="acct" onclick="toast('Aggiungi account: disponibile nella build nativa')">
      <span class="av" style="background:#C7D6E6;color:#4A5A72">+</span>
      <span><b>Usa un altro account</b><small>Aggiungi un account Google</small></span>
    </button>
    <button class="ghost cancel" onclick="closeSheet()">Annulla</button>`,
  facebook:`
    <div class="grab"></div>
    <h3>Continua con Facebook</h3>
    <div class="ssub">DreamMap riceverà: nome, foto del profilo e indirizzo email</div>
    <button class="acct" onclick="login('Andrea','andrea.bilotta00@gmail.com','facebook')">
      <span class="av" style="background:#1877F2">A</span>
      <span><b>Continua come Andrea</b><small>Account Facebook collegato</small></span>
    </button>
    <button class="ghost cancel" onclick="closeSheet()">Annulla</button>`,
  apple:`
    <div class="grab"></div>
    <h3>Accedi con Apple</h3>
    <div class="ssub">Userai il tuo ID Apple per creare l'account</div>
    <button class="acct" onclick="login('Andrea','nascosta@privaterelay.appleid.com','apple')">
      <span class="av" style="background:#0A1A2F"></span>
      <span><b>Continua con Face ID</b><small>Nascondi la mia email</small></span>
    </button>
    <button class="ghost cancel" onclick="closeSheet()">Annulla</button>`,
  email:`
    <div class="grab"></div>
    <h3>Entra con la tua email</h3>
    <div class="ssub">Ti invieremo un link magico, niente password</div>
    <input type="email" id="emailIn" placeholder="nome@email.com" autocomplete="email">
    <button class="cta" style="padding:14px" onclick="emailLogin()">Inviami il link</button>
    <button class="ghost cancel" onclick="closeSheet()">Annulla</button>`
};
/* Signing up and coming back are not the same journey: the quiz personalises a NEW account,
   so someone who already has one must land on the home shell instead of being asked again.
   This is what "Ho già un account" was doing wrong — it walked them into the questions. */
let authIntent = "signup";

/* "Skip the setup questions" means exactly that: straight into the app. It used to go to
   screen 6, which is the very next question. */
function skipOnboardingQuestions(){
  ONB.skipped = true; onbSave();
  localStorage.setItem('fl_onboarded','1');
  skipAll();
}
function existingAccount(){ authIntent = "login"; openSheet("google"); }

function openSheet(kind){
  if(kind === 'google' && NATIVE && NATIVE.googleSignIn){ nativeGoogleLogin(); return; }
  document.getElementById("sheet").innerHTML=SHEETS[kind];
  document.getElementById("sheetwrap").classList.add("open");
}
function closeSheet(){authIntent="signup";document.getElementById("sheetwrap").classList.remove("open")}
function login(name,mail,provider){
  // Read the intent before closeSheet() clears it — closing the sheet is also how the user
  // abandons a login, so that reset has to happen there.
  const returning = authIntent === "login";
  /* SI UNISCE, NON SI SOSTITUISCE. Qui si scrivevano solo nome, email e provider: ogni
     accesso con Google cancellava il mantra dell'inizio e la data di nascita, che vivono
     nello stesso oggetto. */
  let u0 = {}; try{ u0 = JSON.parse(localStorage.getItem("fl_user") || "{}") || {}; }catch(_){ u0 = {}; }
  /* IL NOME SCELTO A MANO VINCE. Chi ha scritto «Andrea» nel profilo non vuole tornare
     «Andrea Bilotta» a ogni accesso con Google: l'account porta mail e provider, il nome
     resta quello del profilo (profileSaveName lo marca con `local`). */
  if (u0 && u0.local && u0.name) name = u0.name;
  localStorage.setItem("fl_user",JSON.stringify(Object.assign({}, u0, {name,mail,provider})));
  closeSheet();
  toast("Accesso effettuato come "+name+" ✓");
  renderProfile();
  if(returning){ setTimeout(skipAll,450); return; }
  if(cur<=1)setTimeout(()=>go(2),450);
}
/* The real thing, through Play Services. The account it returns is the same one the backup
   screen reads, so "Continua con Google" here IS the Drive sign-in: nobody is asked twice.
   And, like AppBlock, if that account already holds a backup it is offered right away. */
async function nativeGoogleLogin(){
  let r = null;
  try{ r = await NATIVE.googleSignIn(); }
  catch(e){ toast(e && e.message ? e.message : 'Accesso Google non riuscito'); return; }
  if(!(r && r.signedIn)) return;
  const mail = r.email || '';
  const name = (r.name || '').trim() || mail.split('@')[0] || 'Tu';
  login(name, mail, 'google');
  setTimeout(offerRestoreFromDrive, 900);
}
async function offerRestoreFromDrive(){
  // Right after a fresh sign-in the first token can take a moment: one quiet retry, and no
  // error toast on top of "Accesso effettuato" - the Backup screen is where errors are shown.
  let r = null;
  for (let attempt = 0; attempt < 2 && !r; attempt++){
    try{ r = await NATIVE.backupList(); }
    catch(e){ console.warn('backupList', e); await new Promise(function(res){ setTimeout(res, 1500); }); }
  }
  if(!r) return;
  const list = (r && r.backups) || [];
  if(!list.length) return;
  const b = list.find(function(x){ return x.deviceId === r.thisDevice; }) || list[0];
  const who = b.deviceName || b.deviceId || 'un telefono';
  const when = (typeof ufWhen === 'function') ? ufWhen(b.updatedAt || b.createdAt) : '';
  const ok = (typeof blkConfirm === 'function')
    ? await blkConfirm('Ho trovato il tuo backup', 'Da ' + who + (when ? ', salvato il ' + when : '') + ': ' + (b.programs||0) + ' programmi, ' + (b.apps||0) + ' app, ' + (b.sites||0) + ' siti. Vuoi ripristinarli su questo telefono?', 'Ripristina', false)
    : window.confirm('Ho trovato un backup da ' + who + '. Ripristinare?');
  if(!ok) return;
  try{
    const done = await NATIVE.backupRestore({ id: b.id, apply: true });
    if(done && done.applied){
      const g = done.restored || {};
      toast('Ripristinati: ' + (g.programs||0) + ' programmi, ' + (g.sites||0) + ' siti, ' + (g.keywords||0) + ' parole');
      localStorage.setItem('fl_onboarded','1');
      setTimeout(function(){ location.reload(); }, 1400);
    } else if(done && done.refusal){ toast(done.refusal); }
  }catch(e){ toast(e && e.message ? e.message : 'Ripristino non riuscito'); }
}
function emailLogin(){
  const v=document.getElementById("emailIn").value.trim();
  if(!v||!v.includes("@")){toast("Inserisci un'email valida");return}
  login(v.split("@")[0],v,"email");
}

/* ============================================================================
 * QUIZ
 * ========================================================================== */
function hoursChange(el){
  const v=+el.value;
  el.style.setProperty("--fill",((v-1)/11*100)+"%");
  window.__estimateHours=v;
  localStorage.setItem('fl_estimate',v);          // insights.js reads this one for the reveal
  ONB.estimate=v; onbSave();
  document.getElementById("hoursOut").innerHTML=v+(v>=12?"+":"")+"<small>h</small>";
  const days=Math.round(v*365/24);
  document.getElementById("hoursNote").textContent="Circa "+days+" giorni all'anno di schermo";
}

/* One handler for three screens, so it has to know which one it is on. The answers to s4 and
   s5 used to vanish the instant the user pressed Continua; now every tap is written down. */
/* The <label> owns the toggle now: pick() only mirrors the checkbox into the .sel class the
   rest of the file reads, then saves. Driven by the change event, never by a click handler,
   so it does not matter which child the finger landed on. */
document.addEventListener('change', function(e){
  const inp = e.target;
  if(!inp || !inp.classList || !inp.classList.contains('choice-in')) return;
  const row = inp.closest('.choice');
  if(row) pick(row);
});
function pick(el){
  const inp = el.querySelector('.choice-in');
  if(inp) el.classList.toggle("sel", inp.checked);
  else el.classList.toggle("sel");
  const wrap=el.closest(".screen");
  if(!wrap) return;
  if(wrap.id==="s4"){
    ONB.problems = selectedKeys(wrap, PROBLEM_KEYS); onbSave();
    const next=wrap.querySelector(".cta");
    if(next) next.disabled = ONB.problems.length===0;
  }
  if(wrap.id==="s5"){  ONB.triggers   = selectedKeys(wrap, TRIGGER_KEYS);  onbSave(); }
  if(wrap.id==="s14"){ ONB.categories = selectedKeys(wrap, CATEGORY_KEYS); onbSave(); }
}
function selectedKeys(wrap, keys){
  const out=[];
  wrap.querySelectorAll('.choice').forEach((c,i)=>{ if(c.classList.contains('sel') && keys[i]) out.push(keys[i]); });
  return out;
}
/* Going back to a question must show what was answered, not an empty screen. */
function paintChoices(screenId, keys, chosen){
  const wrap=document.getElementById(screenId);
  if(!wrap) return;
  wrap.querySelectorAll('.choice').forEach((c,i)=>{
    const on = keys[i] ? chosen.indexOf(keys[i])>=0 : false;
    c.classList.toggle('sel', on);
    const inp = c.querySelector('.choice-in'); if(inp) inp.checked = on;
  });
  if(screenId==='s4'){ const n=wrap.querySelector('.cta'); if(n) n.disabled = chosen.length===0; }
}

function demoBlock(){
  document.getElementById("blockover").classList.add("show");
  const hint=document.querySelector("#s8 .tap-hint"); if(hint) hint.style.display="none";
  document.getElementById("demoNext").disabled=false;
}

/* ============================================================================
 * S10 — DRAG, WITH A WAY OUT (G88)
 *
 * The screen had no button at all: if the pointer events did not land (an OEM WebView, a
 * stylus, a tester on a desktop mouse, someone with a motor impairment) the onboarding was over
 * for good. The drag stays, because it is the nicer gesture; what changes is that it is no
 * longer the only exit.
 * ========================================================================== */
(function(){
  const ball=document.getElementById("dragball");
  const track=document.getElementById("dragtrack");
  if(!ball||!track) return;
  let startX=0,dx=0,drag=false,done=false;
  const max=()=>Math.max(0, track.clientWidth-ball.clientWidth-16);

  document.addEventListener('fl:screen', function(e){ if(e.detail === 's10'){ done=false; reset(); } });
  function finish(){
    if(done) return; done=true;
    ball.style.transition="transform .18s ease";
    ball.style.transform="translateX("+max()+"px)";
    setTimeout(()=>go(12),160);   // v1: no paywall — s11 is skipped, index kept so every other go(N) stays valid
  }
  function reset(){
    drag=false; dx=0;
    ball.style.transition="transform .3s";
    ball.style.transform="";
    setTimeout(()=>ball.style.transition="",320);
  }
  ball.addEventListener("pointerdown",e=>{
    drag=true; startX=e.clientX-dx;
    try{ ball.setPointerCapture(e.pointerId); }catch(err){}
  });
  ball.addEventListener("pointermove",e=>{
    if(!drag)return;
    dx=Math.min(Math.max(0,e.clientX-startX),max());
    ball.style.transform="translateX("+dx+"px)";
    if(dx>=max()-4){ drag=false; finish(); }
  });
  // pointercancel matters: a scroll gesture steals the pointer, and without this the ball is
  // left stranded halfway across the track with drag still true.
  ["pointerup","pointercancel","lostpointercapture"].forEach(ev=>
    ball.addEventListener(ev,()=>{ if(!done && dx<max()-4) reset(); else drag=false; }));
  // Tapping the track counts as the same intent. Cheap, and it rescues the whole screen when
  // the drag does not track for whatever reason.
  track.addEventListener("click",e=>{ if(e.target!==ball) finish(); });

  const zone=document.querySelector("#s10 .dragzone");
  if(zone && !document.getElementById('ue-drag-skip')){
    const b=document.createElement('button');
    b.className='ghost'; b.id='ue-drag-skip';
    b.style.marginTop='10px';
    b.textContent='Non riesci a trascinare? Tocca qui per continuare';
    b.onclick=finish;
    zone.appendChild(b);
  }
})();

/* ============================================================================
 * S12 — THE METHOD IS RECORDED
 *
 * All four cards called go(13) and nothing else, so the choice existed only in the user's head.
 * Two of the four (aperture, posizione) have no engine behind them yet: recording the wish and
 * saying plainly what will be built instead is the honest version of a card that pretends.
 * ========================================================================== */
const METHOD_KEYS = ['ora','limite','aperture','posizione'];
function pickMethod(key){
  ONB.method = key;
  ONB.methodEffective = (key==='ora' || key==='limite') ? key : 'ora';
  onbSave();
  document.querySelectorAll('#s12 .mcard').forEach((c,i)=>c.classList.toggle('ue-sel', METHOD_KEYS[i]===key));
  if(key==='aperture')  toast('Il conteggio delle aperture arriverà: intanto impostiamo una fascia oraria');
  if(key==='posizione') toast('La posizione la aggiungi dal programma (tipo Posizione): intanto una fascia oraria');
  syncS13();
}
(function(){
  document.querySelectorAll('#s12 .mcard').forEach((card,i)=>{
    // The inline onclick="go(13)" in index.html still runs; this listener only records. Adding
    // instead of replacing is what lets a frozen markup file and a live module coexist.
    card.addEventListener('click',()=>pickMethod(METHOD_KEYS[i]||'ora'));
  });
})();

/* ============================================================================
 * S13 — THE SCHEDULE IS EDITABLE
 *
 * The hours were two <span>s, the day buttons and the all-day switch only toggled a CSS class,
 * and the "2h a settimana" line was a constant. All four are now real inputs over ONB.
 * ========================================================================== */
const UE_DAY_SHORT = ['lun','mar','mer','gio','ven','sab','dom'];
const UE_DAY_FULL  = ['lunedì','martedì','mercoledì','giovedì','venerdì','sabato','domenica'];

function minutesOfDay(hhmm){
  const m=/^(\d{1,2}):(\d{2})$/.exec(String(hhmm||'')); if(!m) return 0;
  return (+m[1])*60 + (+m[2]);
}
function windowMinutes(){
  if(ONB.allDay) return 1440;
  const d=(minutesOfDay(ONB.to)-minutesOfDay(ONB.from)+1440)%1440;
  return d===0 ? 1440 : d;      // same start and end reads as "the whole day", not "zero"
}
function dayCount(){ return ONB.days.filter(Boolean).length; }
function ueDaysLabel(){
  const d=ONB.days, n=dayCount();
  if(n===0) return 'Nessun giorno';
  if(n===7) return 'Tutti i giorni';
  if(d[0]&&d[1]&&d[2]&&d[3]&&d[4]&&!d[5]&&!d[6]) return 'Giorni feriali';
  if(!d[0]&&!d[1]&&!d[2]&&!d[3]&&!d[4]&&d[5]&&d[6]) return 'Fine settimana';
  if(n===1) return 'Ogni '+UE_DAY_FULL[d.indexOf(true)];
  return d.map((v,i)=>v?UE_DAY_SHORT[i]:null).filter(Boolean).join(' · ');
}
function weeklyMinutes(){
  return ONB.methodEffective==='limite'
    ? ONB.quotaDay*dayCount()
    : windowMinutes()*dayCount();
}

function initS13(){
  const s13=document.getElementById('s13');
  if(!s13 || s13.dataset.ueReady) return;
  s13.dataset.ueReady='1';

  const row=s13.querySelector('.timerow');
  if(row){
    /* Hidden inputs keep holding the values (the listeners below are unchanged); the visible
       control is the app's own two-column wheel, the same one the editor uses. A native
       <input type=time> opens the system clock, which on One UI is an analog dial. */
    /* Hidden inputs keep holding the values (the listeners below are unchanged); the visible
       control is the app's own two-column wheel, the same one the editor uses. A native
       <input type=time> opens the system clock, which on One UI is an analog dial.
       Built with the DOM: the handlers travel as functions, so there are no nested quotes. */
    row.innerHTML = '';
    const mkTime = function(id, label, value, title){
      const hidden = document.createElement('input');
      hidden.type = 'hidden'; hidden.id = id; hidden.value = value;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'blk-timefield';
      btn.innerHTML = '<span class="flbl">' + label + '</span><b id="' + id + 'Lbl">' + value + '</b>';
      btn.addEventListener('click', function(){
        blkOpenTime(id, { labelId: id + 'Lbl', title: title });
      });
      row.appendChild(hidden);
      row.appendChild(btn);
    };
    mkTime('ue-from', 'Dalle', '12:00', 'Dalle che ora?');
    const dash = document.createElement('span');
    dash.style.color = 'var(--faint)';
    dash.textContent = '—';
    row.appendChild(dash);
    mkTime('ue-to', 'Alle', '14:00', 'Fino a che ora?');
                  + '<span class="flbl">Alle</span><b id="ue-toLbl">14:00</b></button>';
    ['ue-from','ue-to'].forEach(id=>{
      const el=document.getElementById(id);
      // 'input' rather than 'change': the Android time picker fires input as the wheel moves,
      // and the weekly total under the card should follow, not wait for a blur.
      el.addEventListener('input',()=>{
        if(id==='ue-from') ONB.from=el.value||'12:00'; else ONB.to=el.value||'14:00';
        onbSave(); syncS13();
      });
    });
  }

  const sw=s13.querySelector('.switch');
  if(sw) sw.addEventListener('click',()=>{ ONB.allDay=sw.classList.contains('on'); onbSave(); syncS13(); });

  s13.querySelectorAll('.day').forEach((b,i)=>{
    b.addEventListener('click',()=>{ ONB.days[i]=b.classList.contains('on'); onbSave(); syncS13(); });
  });

  // Pressing Continua here is the moment the schedule stops being a draft, and it is the only
  // signal s16 needs to know whether it has something real to describe. Reading it from the
  // button rather than from "did screen s14 appear" matters: a screen walked past in the same
  // tick is not observable, and the summary would silently fall back to "nessun programma".
  const nextBtn=s13.querySelector('.cta');
  if(nextBtn) nextBtn.addEventListener('click',()=>{ ONB.configured=true; onbSave(); });

  // The daily budget only makes sense for "Limite di utilizzo"; asking for a time range there
  // and then printing "12:00 — 14:00" in the summary is how s16 ended up describing something
  // the user had never chosen.
  const panels=s13.querySelectorAll('.panelcard');
  const quota=document.createElement('div');
  quota.className='panelcard ue-quota';
  quota.id='ue-quota';
  quota.hidden=true;
  quota.innerHTML='<div class="rowline"><span>Budget giornaliero</span><span id="ue-quotaLbl">30m al giorno</span></div>'
    + '<div class="ue-quotarow">'
    + '<button class="ue-qbtn" type="button" onclick="quotaStep(-15)">&minus;</button>'
    + '<input class="fin ue-qin" id="ue-quotaIn" type="number" min="5" max="480" step="5" value="30" inputmode="numeric">'
    + '<button class="ue-qbtn" type="button" onclick="quotaStep(15)">+</button>'
    + '</div>'
    + '<p class="hintline" style="margin:10px 0 0">Quanti minuti al giorno ti concedi, nei giorni selezionati.</p>';
  if(panels[0] && panels[0].parentNode) panels[0].parentNode.insertBefore(quota, panels[0].nextSibling);
  const qin=quota.querySelector('#ue-quotaIn');
  if(qin) qin.addEventListener('input',()=>{ ONB.quotaDay=clampQuota(qin.value); onbSave(); syncS13(); });
}
function clampQuota(v){ v=parseInt(v,10); if(!v||v<5) v=5; if(v>480) v=480; return v; }
function quotaStep(delta){ ONB.quotaDay=clampQuota(ONB.quotaDay+delta); onbSave(); syncS13(); }

function syncS13(){
  const s13=document.getElementById('s13'); if(!s13) return;
  const limite = ONB.methodEffective==='limite';

  const f=document.getElementById('ue-from'), t=document.getElementById('ue-to');
  if(f && document.activeElement!==f) f.value=ONB.from;
  if(t && document.activeElement!==t) t.value=ONB.to;
  if(f) f.disabled=!!ONB.allDay;
  if(t) t.disabled=!!ONB.allDay;

  const sw=s13.querySelector('.switch'); if(sw) sw.classList.toggle('on', !!ONB.allDay);
  s13.querySelectorAll('.day').forEach((b,i)=>b.classList.toggle('on', !!ONB.days[i]));

  const panels=s13.querySelectorAll('.panelcard');
  if(panels[0]) panels[0].hidden=limite;          // no hours to pick when it is a daily budget
  const quota=document.getElementById('ue-quota');
  if(quota){
    quota.hidden=!limite;
    const qin=document.getElementById('ue-quotaIn');
    if(qin && document.activeElement!==qin) qin.value=ONB.quotaDay;
    const qlbl=document.getElementById('ue-quotaLbl');
    if(qlbl) qlbl.textContent=fmtMin(ONB.quotaDay)+' al giorno';
  }

  const title=s13.querySelector('.q-title');
  if(title) title.textContent = limite
    ? 'Quanto tempo al giorno vuoi concederti?'
    : 'Quando deve essere attivo il blocco?';

  // The days card is the one whose first span reads "Giorni"; its second span was the frozen
  // string "Ogni domenica" no matter what was selected.
  s13.querySelectorAll('.panelcard .rowline').forEach(r=>{
    const spans=r.querySelectorAll('span');
    if(spans[0] && spans[0].textContent.trim()==='Giorni' && spans[1]) spans[1].textContent=ueDaysLabel();
  });

  const legal=s13.querySelector('p.legal');
  if(legal){
    if(dayCount()===0){
      legal.textContent='Nessun giorno selezionato: il programma non si attiverebbe mai.';
      legal.style.color='var(--red)';
    }else{
      legal.style.color='';
      legal.textContent = limite
        ? 'Budget di '+fmtMin(ONB.quotaDay)+' al giorno · '+fmtMin(weeklyMinutes())+' a settimana'
        : 'Il programma sarà attivo per '+fmtMin(weeklyMinutes())+' a settimana';
    }
  }
}

/* ============================================================================
 * S16 — THE SUMMARY IS COMPUTED (G89)
 *
 * It used to read: "Vita reale > scroll · 12:00 — 14:00 · dom · 5 categorie bloccate ·
 * 2h a settimana · Sincronizzato col tuo PC". Not one of those six values came from the user,
 * and the last one promised a sync with no backend behind it (R8). Every line below is derived,
 * and the sync line is gone.
 * ========================================================================== */

function programName(){
  for(let i=0;i<ONB.problems.length;i++){
    const n=NAME_BY_PROBLEM[ONB.problems[i]];
    if(n) return n;
  }
  return 'Il mio primo blocco';
}
function categoryLabels(){
  return ONB.categories.map(k=>CATEGORIES[k] && CATEGORIES[k].label).filter(Boolean);
}
/* When does this thing actually switch on? Walked forward day by day rather than solved in
   closed form, because a window that wraps past midnight (22:00 -> 08:00) is the normal case
   here, not the exception. */
function nextActivation(){
  if(dayCount()===0) return {state:'none'};
  const now=new Date();
  const nowMin=now.getHours()*60+now.getMinutes();
  const idx=d=>(d+6)%7;                        // JS Sunday=0 -> our Monday=0
  const start=ONB.allDay?0:minutesOfDay(ONB.from);
  const dur=windowMinutes();
  // still inside a window that opened today, or yesterday and ran past midnight?
  for(let back=0;back<=1;back++){
    const d=new Date(now); d.setDate(d.getDate()-back);
    if(!ONB.days[idx(d.getDay())]) continue;
    const s=start-back*1440;
    if(nowMin>=s && nowMin<s+dur) return {state:'now', left:(s+dur)-nowMin};
  }
  for(let k=0;k<8;k++){
    const d=new Date(now); d.setDate(d.getDate()+k);
    if(!ONB.days[idx(d.getDay())]) continue;
    const s=start+k*1440;
    if(s>nowMin) return {state:'next', inMin:s-nowMin, day:idx(d.getDay())};
  }
  return {state:'none'};
}
function activationBadge(){
  if(ONB.methodEffective==='limite') return '⏳ ' + fmtMin(ONB.quotaDay) + ' al giorno';
  const a=nextActivation();
  if(a.state==='none') return '⚠️ Nessun giorno selezionato';
  if(a.state==='now')  return '🔒 Attivo adesso · ancora ' + fmtMin(a.left);
  if(a.inMin<60)       return '⏱ Inizia tra ' + Math.max(1,Math.round(a.inMin)) + ' min';
  if(a.inMin<1440)     return '⏱ Inizia tra ' + fmtMin(a.inMin);
  return '⏱ Inizia ' + UE_DAY_FULL[a.day] + ' alle ' + ONB.from;
}

async function buildSummary(){
  const s16=document.getElementById('s16'); if(!s16) return;
  const card=s16.querySelector('.sumcard');
  // The three rows sit between the summary card and the spacer; the spacer is the stable
  // anchor to rebuild against, because the rows themselves are about to be removed.
  const anchor=s16.querySelector('.spacer');
  Array.prototype.slice.call(s16.querySelectorAll('.sumrow')).forEach(r=>r.remove());

  const kicker=s16.querySelector('.kicker');
  const h1=s16.querySelector('h1');

  const cta=s16.querySelector('.cta');
  s16.classList.toggle('s16-solo', !ONB.configured);
  if(!ONB.configured){
    /* 0.9.293, Andrea: "Tutto pronto, DreamMap e' installato, nessun programma, hai detto... troppe cose insieme, e' la
       pagina della vecchia FocusLock". Una cosa sola: e' pronto, e dove si comincia. */
    const st = ONB.stato;
    const riga = st === 'Ci provo, ma non sono costante' ? 'La costanza nasce da un sistema, e adesso ce l’hai.'
      : st === 'Mi sento bloccato' ? 'Da oggi non sei più da solo a spingere.'
      : 'La prima tappa del tuo sogno ti aspetta nella Mappa.';
    if(kicker) kicker.textContent='';
    if(h1) h1.innerHTML='Tutto <span class="hl">pronto</span>.';
    if(card) card.outerHTML='<p class="s16-riga">'+esc(riga)+'</p>';
    if(cta){ cta.textContent='Inizia'; cta.onclick=function(){ go(17); startConfetti(); try{ switchTab('mappa'); }catch(_){ } }; }
    return;
  }else{
    if(kicker) kicker.textContent='Primo blocco pronto';
    if(h1) h1.innerHTML='La tua pianificazione è <span class="hl">attiva</span>.';
    if(card) card.innerHTML=
      '<span class="badgei">'+esc(activationBadge())+'</span>'
      +'<h3>'+esc(programName())+'</h3>'
      +'<div class="trange">'+esc(ONB.methodEffective==='limite'
          ? fmtMin(ONB.quotaDay)+' al giorno'
          : (ONB.allDay ? 'Tutto il giorno' : ONB.from+' — '+ONB.to))+'</div>'
      +'<div class="ue-sumdays">'+esc(ueDaysLabel())+'</div>';
    ensureFirstProgram();
  }

  const out=[];
  if(ONB.configured){
    const labels=categoryLabels();
    out.push(['🚫',
      labels.length ? labels.length+(labels.length===1?' categoria bloccata':' categorie bloccate')
                    : 'Nessuna categoria selezionata',
      labels.length ? labels.join(', ')
                    : 'Aggiungi app, siti o parole chiave dalla scheda Blocco', null]);
    out.push(['🧠', fmtMin(weeklyMinutes())+' a settimana',
      ONB.methodEffective==='limite'
        ? 'Il budget che ti sei dato, sui '+dayCount()+' giorni scelti'
        : 'Tempo in cui il blocco sarà attivo, sui '+dayCount()+' giorni scelti', null]);
  }
  // Replaces "Sincronizzato col tuo PC", a sync that has no backend behind it (R8). What goes
  // in its place is the one thing the user most needs to know at this exact moment.
  out.push(await serviceStateLine());
  out.push(['🔒','Tutto resta sul telefono',
            'Le tue regole e ciò che il servizio legge non escono dal dispositivo', null]);

  const frag=document.createDocumentFragment();
  out.forEach(r=>{
    const div=document.createElement('div');
    div.className='sumrow';
    div.innerHTML='<span class="si">'+r[0]+'</span><span>'+esc(r[1])+'<small>'+esc(r[2])+'</small></span>';
    if(r[3]){ div.style.cursor='pointer'; div.onclick=r[3]; }
    frag.appendChild(div);
  });
  if(anchor) s16.insertBefore(frag, anchor); else s16.appendChild(frag);
}

/* The engine is the only thing that can say whether any of this will actually happen. */
async function serviceStateLine(){
  if(!NATIVE) return ['🖥️','Anteprima nel browser',
                      'Il motore di blocco esiste solo nell' + String.fromCharCode(39) + 'app installata', null];
  try{
    const acc=await NATIVE.isServiceEnabled();
    if(acc.enabled) return ['🛡️','Protezione attiva','Il servizio di blocco è acceso', null];
  }catch(e){}
  return ['🛡️','Protezione da attivare',
          'Il servizio di blocco non è ancora acceso: tocca per farlo',
          function(){ openPerm('accessibility'); }];
}

/* The onboarding used to end without creating anything: the home screen showed "Nessun
   programma" one second after a screen that said "la tua pianificazione è attiva". This turns
   the answers into a real, editable program, through the Blocco lane's own store and its own
   push to the engine — guarded, because that module is being worked on in parallel. */
function ensureFirstProgram(){
  if(typeof PROGRAMS === 'undefined' || typeof saveProgramsLocal !== 'function') return;
  const apps={}, sites={};
  ONB.categories.forEach(k=>{
    const c=CATEGORIES[k]; if(!c) return;
    c.apps.forEach(a=>{ apps[a]=1; });
    c.sites.forEach(s=>{ sites[s]=1; });
  });
  const appList=Object.keys(apps), siteList=Object.keys(sites);
  if(!appList.length && !siteList.length) return;   // nothing to block: do not create an empty rule

  const limite = ONB.methodEffective==='limite';
  const p = {
    name: programName(),
    type: limite ? 'limite' : 'ora',
    icon: limite ? '⏳' : '🕑',
    from: ONB.allDay ? '00:00' : ONB.from,
    to:   ONB.allDay ? '23:59' : ONB.to,
    allDay: !!ONB.allDay,
    days: ONB.days.slice(),
    qh: null,
    qd: limite ? ONB.quotaDay : null,
    apps: appList, sites: siteList, keywords: [], allow: [],
    on: true,
    fromOnboarding: true          // so a second pass replaces it instead of piling up copies
  };
  let i=-1;
  for(let k=0;k<PROGRAMS.length;k++){ if(PROGRAMS[k] && PROGRAMS[k].fromOnboarding){ i=k; break; } }
  if(i>=0) PROGRAMS[i]=p; else PROGRAMS.push(p);
  saveProgramsLocal();
  if(typeof pushRules === 'function') pushRules();
  if(typeof renderPrograms === 'function') renderPrograms();
}

/* ============================================================================
 * LEGAL DOCUMENTS — one viewer, one source of truth
 *
 * The two documents are real files in www/legal/. They are also the files that get uploaded to
 * the public address declared on Play, so they have to BE the original: an in-app copy of the
 * same text written inline in JavaScript is a second source of truth, and the day one of them
 * is corrected the other starts lying. There was exactly such a copy — screen 's-legal' in
 * profile.js — and it is gone; openLegal() over there funnels into ueOpenLegal() below, so
 * Profilo, the paywall, s0, s1, s2 and the accessibility disclosure all show the same file.
 *
 * The anchors keep a real href, so they still work if scripting fails; the click handler shows
 * the file inside the app instead, because navigating index.html away would drop someone in
 * the middle of the onboarding back at screen zero.
 * ========================================================================== */
let legalFrom = 's0';

/* Callers say 'terms', 'termini' or 'privacy' depending on which lane wrote them; the document
   is picked here so no caller has to know the file name. */
const LEGAL_DOCS = {
  termini: { file: 'legal/termini.html', title: 'Condizioni d' + String.fromCharCode(39) + 'uso' },
  privacy: { file: 'legal/privacy.html', title: 'Informativa sulla privacy' }
};
function ueLegalKind(kind){
  const k = String(kind == null ? '' : kind).toLowerCase();
  return (k === 'termini' || k === 'terms' || k === 'condizioni' || k === 'uso') ? 'termini' : 'privacy';
}

const LEGAL_HTML = `
  <div class="topbar">
    <button class="iconbtn" onclick="ueCloseLegal()">&lsaquo;</button>
    <b id="ue-legal-title" style="font:700 14px var(--font-display);color:var(--navy)"></b>
    <div class="spacer"></div>
    <a id="ue-legal-online" class="ue-legal-online" target="_blank" rel="noopener noreferrer" hidden>Apri online ↗</a>
  </div>
  <iframe id="ue-legal-frame" class="ue-legal-frame" title="Documento legale"></iframe>`;

function ueOpenLegal(kind){
  const k = ueLegalKind(kind);
  const doc = LEGAL_DOCS[k];
  const fr=document.getElementById('ue-legal-frame');
  const ti=document.getElementById('ue-legal-title');
  if(!fr){ location.href=doc.file; return false; }  // screen missing: the plain link still works
  if(order[cur]!=='s-ue-legal') legalFrom=order[cur];
  if(ti) ti.textContent = doc.title;
  if(fr.getAttribute('src')!==doc.file) fr.setAttribute('src',doc.file);
  ueLegalOnlineLink(k);
  goId('s-ue-legal');
  return false;                                  // cancels the anchor's own navigation
}
function ueCloseLegal(){ goId(legalFrom || 's0'); }

/* The published copy of the same document, offered only once it has actually answered.
   profile.js owns the addresses and the reachability probe (LEGAL_URLS); all that happens here
   is the link, and it stays hidden whenever there is nothing behind it. The document on screen
   is always the local file, so an address that is wrong, not published yet or simply offline
   costs the user nothing — worst case the extra link is absent. */
function ueLegalOnlineLink(kind){
  const a = document.getElementById('ue-legal-online');
  if(!a) return;
  const url = (typeof legalPublicUrl === 'function') ? legalPublicUrl(kind) : '';
  if(url){ a.setAttribute('href', url); a.hidden = false; }
  else { a.removeAttribute('href'); a.hidden = true; }
  // Probes at most once per launch, and only if the addresses were switched on. Its answer
  // decides the NEXT open, so nothing here ever waits on the network.
  if(typeof legalProbePublic === 'function') legalProbePublic();
}

(function(){
  // Every legal anchor in the app, wherever its screen lives. Matching on the text is right
  // here: the two documents are told apart by what the link says, and the same two strings
  // appear on s0, s1 and the paywall.
  document.querySelectorAll('.legal a').forEach(a=>{
    if(a.getAttribute('href')) return;
    const txt=(a.textContent||'').toLowerCase();
    const kind = (txt.indexOf('condizioni')>=0 || txt.indexOf('uso')>=0) ? 'termini' : 'privacy';
    a.setAttribute('href', LEGAL_DOCS[kind].file);
    a.addEventListener('click', e=>{ e.preventDefault(); ueOpenLegal(kind); });
  });
  // s2's "Policy sui dati ›" looked like a button and did nothing at all.
  const tag=document.querySelector('#s2 .tag');
  if(tag) tag.addEventListener('click',()=>ueOpenLegal('privacy'));
})();

/* ============================================================================
 * CONFETTI
 * ========================================================================== */
function startConfetti(){
  const c=document.getElementById("confetti");
  if(!c)return;
  c.innerHTML='';                       // idempotent: s16 can be reached more than once
  const colors=["#0075E3","#E63946","#3F9FF4","#F6CCE4","#001E44"];
  for(let k=0;k<40;k++){
    const i=document.createElement("i");
    i.style.left=Math.random()*100+"%";
    i.style.background=colors[k%colors.length];
    i.style.animationDelay=(Math.random()*1.2)+"s";
    i.style.transform="rotate("+Math.random()*360+"deg)";
    c.appendChild(i);
  }
}

/* ============================================================================
 * WIRING — react to a screen becoming visible
 *
 * nav.js owns go()/goId() and is frozen, so instead of wrapping them this watches the class
 * that marks the visible screen. Same information, no other module patched.
 * ========================================================================== */
function onScreenShown(id){
  if(id==='s4')  paintChoices('s4', PROBLEM_KEYS, ONB.problems);
  if(id==='s5')  paintChoices('s5', TRIGGER_KEYS, ONB.triggers);
  if(id==='s13'){ initS13(); syncS13(); }
  if(id==='s14'){
    paintChoices('s14', CATEGORY_KEYS, ONB.categories);
    // Getting here means s12 and s13 were walked through: from now on there is a real answer to
    // describe, and s16 is allowed to describe it.
    ONB.configured=true; onbSave();
  }
  if(id==='s16'){ buildSummary(); startConfetti(); }
}
(function(){
  const phone=document.getElementById('phone');
  if(!phone) return;
  let last=null;
  new MutationObserver(muts=>{
    for(let i=0;i<muts.length;i++){
      const el=muts[i].target;
      if(el.classList && el.classList.contains('screen') && el.classList.contains('active')){
        if(el.id!==last){ last=el.id; onScreenShown(el.id); }
      }
    }
  }).observe(phone,{subtree:true,attributes:true,attributeFilter:['class']});
})();

/* ---------- style, scoped with the lane prefix so it cannot collide ---------- */
(function(){
  const s=document.createElement('style');
  s.id='ue-onboarding-style';
  s.textContent=`
  .ue-tm{font:800 20px var(--font-display);color:var(--navy);text-align:center;
    background:var(--bg);border:1px solid var(--line);border-radius:var(--r-sm);padding:8px 10px;
    width:120px;-webkit-appearance:none;appearance:none}
  .ue-tm:disabled{opacity:.45}
  .ue-quotarow{display:flex;align-items:center;gap:10px;margin-top:12px}
  .ue-qbtn{width:44px;height:44px;border-radius:12px;border:1px solid var(--line);background:#fff;
    color:var(--blue);font:800 20px var(--font-body);cursor:pointer;flex:none}
  .ue-qin{text-align:center;font:800 18px var(--font-display)}
  .ue-sel{border-color:var(--blue) !important;box-shadow:0 0 0 2px rgba(0,117,227,.18)}
  .ue-sumdays{font:600 12px var(--font-body);color:#BBD9FA;margin-top:4px}
  .ue-legal-frame{flex:1;width:100%;border:0;border-radius:var(--r-md);background:#fff;min-height:60vh}
  .ue-legal-online{flex:none;font:700 11px var(--font-body);color:var(--blue);text-decoration:none;
    border:1px solid var(--line);background:#fff;border-radius:999px;padding:5px 10px;white-space:nowrap}
  .ue-legal-online[hidden]{display:none}
  `;
  document.head.appendChild(s);
})();

/* ---------- mount ---------- */
registerScreen('s-ue-legal', LEGAL_HTML, {back: () => legalFrom || 's0'});

/* Restore the answers into the markup, then run the slider once so its label and fill match the
   stored estimate instead of the hardcoded 3. */
paintChoices('s4', PROBLEM_KEYS, ONB.problems);
paintChoices('s5', TRIGGER_KEYS, ONB.triggers);
paintChoices('s14', CATEGORY_KEYS, ONB.categories);
(function(){
  const h=document.getElementById('hours');
  if(!h) return;
  if(ONB.estimate) h.value=ONB.estimate;
  hoursChange(h);
})();
if(ONB.method) document.querySelectorAll('#s12 .mcard').forEach((c,i)=>
  c.classList.toggle('ue-sel', METHOD_KEYS[i]===ONB.method));

/* s13 is built one tick later, not here: syncS13() prints times with fmtMin(), which lives in
   nav.js — and nav.js is deliberately the LAST script on the page. Calling it now would throw
   before the app has finished loading. DOMContentLoaded fires after every script has run. */
document.addEventListener('DOMContentLoaded', function(){ initS13(); syncS13(); });

/* ===========================================================================================
   L'APERTURA E LE DUE DOMANDE — quello che ho imparato guardando le app che funzionano.

   Le regole, viste di persona dentro BlueStacks (vedi docs/onboarding-pattern-dalle-app.md):

     1. UNA FRASE INTERA per schermata. L'accento si da' con il colore, mai spezzando la frase.
        Il tentativo precedente mostrava «Non ti chiamo», poi «per bloccarti»: due mezze frasi
        che non vogliono dire niente. Detox mostra la frase intera e colora le parole che
        contano.
     2. AVANZA IL DITO, non il cronometro. «tocca per continuare» sta sempre a schermo, e
        finche' non si tocca non succede niente.
     3. LE FRASI SI ACCUMULANO: quella di prima resta, spenta, e il discorso cresce.
     4. IL PERSONAGGIO E' A SCHERMO mentre fa le domande (il genio di Akinator non se ne va
        mai), cosi' si vede chi sta parlando.
     5. IL PULSANTE E' LA BATTUTA DI CHI LEGGE, quando c'e' qualcosa da dire.
   =========================================================================================== */

/* Le tre battute dell'apertura. `oro` e' la parte che si accende: dentro la frase, non al
   posto di un pezzo di frase. */
const OB_FRASI = [
  { t: 'Immagina una giornata in cui il telefono non decide al posto tuo.', oro: 'non decide al posto tuo' },
  { t: 'DreamMap blocca quello che ti distrae, sul telefono e sul PC.', oro: 'quello che ti distrae' },
  { t: 'E il Genio ti dice dove stai andando, se non cambi niente.', oro: 'dove stai andando' }
];
let OB_I = 0;

function obFraseHtml(f){
  const i = f.t.indexOf(f.oro);
  if (i < 0) return esc(f.t);
  return esc(f.t.slice(0, i)) + '<b>' + esc(f.oro) + '</b>' + esc(f.t.slice(i + f.oro.length));
}
function obApri(){
  const box = document.getElementById('obFrasi');
  if (!box) return;
  /* 0.9.258, Andrea: la musica solo al primo avvio vero, mai nella Home */
  try{ if (typeof muSigla === 'function' && !localStorage.getItem('fl_onboarding') && !localStorage.getItem('fl_first_run')) muSigla(); }catch(_){ }
  OB_I = 0; box.innerHTML = '';
  const tap = document.getElementById('obTap'); if (tap) tap.hidden = false;
  const fine = document.getElementById('obFine'); if (fine) fine.hidden = true;
  obAvanti();
}
function obAvanti(){
  const box = document.getElementById('obFrasi');
  if (!box || OB_I >= OB_FRASI.length) return;
  box.querySelectorAll('p').forEach(function(p){ p.classList.add('via'); });
  const p = document.createElement('p');
  p.innerHTML = obFraseHtml(OB_FRASI[OB_I]);
  box.appendChild(p);
  OB_I++;
  if (OB_I >= OB_FRASI.length){
    const tap = document.getElementById('obTap'); if (tap) tap.hidden = true;
    const fine = document.getElementById('obFine');
    if (fine) setTimeout(function(){ fine.hidden = false; }, 450);
  }
}

/* --------------------------------------------------------------------------------------- */

/* Le due domande di riconoscimento. Non configurano niente: servono perche' chi legge si
   riconosca, e perche' l'app possa ripetergli indietro le sue parole. */
const OB_DOMANDE = [
  { k: 'stato', q: 'Quale frase descrive meglio come stai adesso?', multi: false,
    opz: ['Mi sento bloccato', 'Ci provo, ma non sono costante', 'Sto facendo progressi', 'Vado bene, ma voglio di più'] },
  { k: 'conti', q: 'Con che cosa stai facendo i conti, in questo periodo?', multi: true,
    sub: 'Puoi sceglierne più di una.',
    opz: ['Poca motivazione', 'Penso troppo', 'Dormo male', 'Rimando tutto', 'Poca fiducia in me', 'Nessuna direzione chiara'] }
];
let OB_D = 0;

function obQPaint(){
  const d = OB_DOMANDE[OB_D];
  const q = document.getElementById('obQ'), o = document.getElementById('obOpts'), cta = document.getElementById('obQCta');
  if (!d || !q || !o) return;
  q.innerHTML = '<h1>' + esc(d.q) + '</h1>' + (d.sub ? '<p class="sub">' + esc(d.sub) + '</p>' : '');
  const scelte = d.multi ? (ONB[d.k] || []) : [ONB[d.k]];
  o.innerHTML = d.opz.map(function(t, i){
    const on = scelte.indexOf(t) >= 0;
    return '<button type="button" class="ob-opt' + (on ? ' on' : '') + '" onclick="obQScegli(' + i + ')">' + esc(t) + '</button>';
  }).join('');
  if (cta) cta.hidden = !d.multi;
}
function obQScegli(i){
  const d = OB_DOMANDE[OB_D];
  const t = d.opz[i];
  if (d.multi){
    const l = (ONB[d.k] || []).slice();
    const j = l.indexOf(t);
    if (j >= 0) l.splice(j, 1); else l.push(t);
    ONB[d.k] = l; onbSave(); obQPaint();
    return;
  }
  ONB[d.k] = t; onbSave(); obQPaint();
  /* una risposta sola: si avanza al tocco, come nel genio */
  setTimeout(obQAvanti, 260);
}
function obQAvanti(){
  OB_D++;
  if (OB_D >= OB_DOMANDE.length){ OB_D = 0; go(3); return; }
  obQPaint();
}

/* Il telaio delle due schermate, scritto qui perche' index.html e' condiviso. */
(function obStile(){
  const st = document.createElement('style');
  st.textContent = [
    '#s0{padding:0;overflow:hidden}',
    '.ob-hero{position:absolute;inset:0;display:flex;flex-direction:column;padding:0 24px calc(24px + env(safe-area-inset-bottom))}',
    '.ob-bg{position:absolute;inset:0;background:url("img/bg/take-flight.jpg") center 40%/cover no-repeat}',
    /* 0.9.292, Andrea: "per un attimo l'aeroplano compare prima del Genio nella prima schermata". s0 e' la schermata
       accesa nell'HTML e l'avvio passa poi al Genio: finche' non e' sicuro che resti s0, l'aereo e le frasi non si vedono. */
    '#s0{background:#00132B}#s0:not(.ob-pronta) .ob-bg,#s0:not(.ob-pronta) .ob-frasi,#s0:not(.ob-pronta) .ob-tap,#s0:not(.ob-pronta) .ob-fine{opacity:0}#s0 .ob-bg,#s0 .ob-frasi,#s0 .ob-tap{transition:opacity .35s ease}',
    '.ob-veil{position:absolute;inset:0;background:linear-gradient(180deg,rgba(4,10,28,.72),rgba(4,10,28,.5) 45%,rgba(4,10,28,.9))}',
    '.ob-frasi{position:relative;z-index:2;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;text-align:center}',
    '.ob-frasi p{margin:0;max-width:16em;font:700 23px/1.42 var(--font-display);color:#fff;text-shadow:0 2px 16px rgba(0,0,0,.6);animation:obIn .45s ease-out both}',
    '.ob-frasi p b{font-weight:700;color:#8CC6FF}',
    '.ob-frasi p.via{opacity:.3;font-size:19px}',
    '@keyframes obIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}',
    '.ob-tap{position:relative;z-index:2;text-align:center;padding:18px 0 26px;font:700 11.5px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.62);animation:obTap 1.8s ease-in-out infinite}',
    '@keyframes obTap{0%,100%{opacity:.45}50%{opacity:1}}',
    '.ob-fine{position:relative;z-index:2;animation:obIn .5s ease-out both}',
    '.ob-fine .ghost{color:rgba(255,255,255,.72)}',
    '.ob-fine .legal{color:rgba(255,255,255,.45)}',
    '.ob-fine .legal a{color:rgba(255,255,255,.7)}',
    /* la sfera del Genio sopra le due domande */
    '.ob-ball{position:relative;width:104px;height:104px;margin:6px auto 2px;display:flex;align-items:center;justify-content:center;border-radius:50%}',
    '.ob-ball::before{content:"";position:absolute;inset:-10px;border-radius:50%;background:conic-gradient(from var(--angle,0deg),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(14px);opacity:.7;animation:spin 4s linear infinite}',
    '.ob-ball span{position:relative;font-size:70px;line-height:1}',
    '.ob-q h1{font-size:23px;margin:10px 0 6px}',
    '.ob-opts{display:flex;flex-direction:column;gap:9px;margin-top:16px}',
    '.ob-opt{width:100%;border:1.5px solid var(--line);background:var(--card,#fff);color:var(--navy);border-radius:15px;padding:15px 16px;font:600 14.5px var(--font-body);text-align:left;cursor:pointer;transition:border-color .15s,transform .12s}',
    'body.dark .ob-opt{background:#141C2C;color:#E8F1FF;border-color:#25314A}',
    '.ob-opt.on{border-color:var(--blue);background:#EAF3FF;color:#0E2350}',
    'body.dark .ob-opt.on{background:#12305F;color:#fff;border-color:#4FA8FF}',
    '.ob-opt:active{transform:scale(.99)}'
  ].join('\n');
  document.head.appendChild(st);
})();

document.addEventListener('DOMContentLoaded', function(){
  const hero = document.getElementById('obHero');
  if (hero) hero.addEventListener('click', function(e){
    if (e.target.closest('.ob-fine')) return;
    obAvanti();
  });
  obApri();
  obQPaint();
});
function obPronta(){ const s0 = document.getElementById('s0'); if (s0) s0.classList.add('ob-pronta'); }
/* all'avvio: se dopo il giro di partenza s0 e' ancora la schermata accesa, e' davvero lei */
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(function(){ const s0 = document.getElementById('s0'); if (s0 && s0.classList.contains('active')) obPronta(); }, 1400);
});
/* Rientrando su s0 (da «Rivedi il primo avvio») il racconto riparte dalla prima frase. */
document.addEventListener('fl:screen', function(e){
  if (e.detail === 's0'){ obPronta(); obApri(); }
  if (e.detail === 's2'){ OB_D = 0; obQPaint(); }
});

/* Lo specchio della fine: le sue parole, ripetute. Una risposta che non torna mai indietro e'
   un modulo da riempire; una che torna e' una conversazione. */
function obSpecchio(){
  const el = document.getElementById('obSpecchio');
  if (!el) return;
  const st = ONB.stato, co = (ONB.conti || []);
  if (!st && !co.length){ el.hidden = true; return; }
  const chiusa = st === 'Mi sento bloccato' ? 'Da oggi non sei più da solo a spingere.'
    : st === 'Ci provo, ma non sono costante' ? 'La costanza non è forza di volontà: è un sistema che tiene il punto anche nei giorni storti.'
    : st === 'Sto facendo progressi' ? 'Bene. Questo serve a non perderli nei giorni storti.'
    : 'Allora alziamo l’asticella.';
  el.hidden = false;
  el.innerHTML = '<b>Hai detto: «' + esc(st || co[0]) + '».</b>'
    + (co.length ? '<span>' + esc(co.slice(0, 3).join(' · ').toLowerCase()) + '</span>' : '')
    + '<p>' + chiusa + '</p>';
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's16') obSpecchio(); });
(function(){
  const st = document.createElement('style');
  st.textContent = '#s16.s16-solo{justify-content:center;text-align:center}#s16.s16-solo .kicker,#s16.s16-solo .sumrow,#s16.s16-solo .sumcard,#s16.s16-solo .ob-specchio{display:none!important}'
    + '#s16.s16-solo h1{font-size:34px!important;margin-top:28vh}'
    + '#s16 .s16-riga{margin:14px auto 0;max-width:30ch;font:500 17px/1.5 var(--font-body);color:var(--muted);text-align:center}';
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.ob-specchio{margin-top:14px;border-radius:16px;padding:14px 16px;background:var(--blue-soft,#EAF3FF);text-align:left}',
    'body.dark .ob-specchio{background:#12305F}',
    '.ob-specchio b{display:block;font:700 13.5px/1.45 var(--font-body);color:#0E2350}',
    'body.dark .ob-specchio b{color:#fff}',
    '.ob-specchio span{display:block;margin-top:4px;font:600 11.5px var(--font-body);color:#4A6punto}'.replace('4A6punto','4A6A8C'),
    'body.dark .ob-specchio span{color:#9FC2F0}',
    '.ob-specchio p{margin:8px 0 0;font:500 12.5px/1.5 var(--font-body);color:#33455F}',
    'body.dark .ob-specchio p{color:#C9DAF2}'
  ].join(String.fromCharCode(10));
  document.head.appendChild(st);
})();
