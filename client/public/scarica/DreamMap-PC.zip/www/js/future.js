/* future.js - il racconto della traiettoria, uno schermo alla volta.

   I numeri erano tutti dentro a un pannello solo: anni, percentuali, giorni, equivalenze e
   probabilità nella stessa schermata. Chi la apriva non sapeva dove guardare e non leggeva
   niente. Qui vale la regola OEOF del Brain (concepts/oeof-veicolare-attenzione): un solo
   elemento cattura l'attenzione, tutto il resto lo serve; lo spazio vuoto non è sprecato, è
   quello che dichiara il valore di ciò che sta al centro; e si rivela uno per volta, con una
   pausa prima della cifra, perché la pausa è ciò che la fa pesare.

   Un passo = una cifra grande, una riga sotto, un pulsante. Niente altro a schermo. */

const FU = { steps: [], i: 0 };

function fuOpen(steps){
  if (!steps || !steps.length) return;
  FU.steps = steps;
  FU.i = 0;
  const el = document.getElementById('fuWrap');
  if (!el) return;
  el.hidden = false;
  document.body.classList.add('fu-on');
  fuPaint();
}
function fuClose(){
  try{ localStorage.setItem('fl_fu_visto', String(Date.now())); }catch(_){ }
  const el = document.getElementById('fuWrap');
  if (el) el.hidden = true;
  document.body.classList.remove('fu-on');
}
function fuNext(){
  const s = FU.steps[FU.i];
  if (s && s.birth){
    const v = (document.getElementById('fuBirthIn') || {}).value || '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)){ toast('Scegli la tua data di nascita'); return; }
    if (typeof s.onSave === 'function') s.onSave(v);
    return;   // onSave ricostruisce i passi e riparte
  }
  if (FU.i >= FU.steps.length - 1){ fuClose(); return; }
  FU.i++;
  fuPaint();
}
function fuBack(){
  if (FU.i <= 0){ fuClose(); return; }
  FU.i--;
  fuPaint();
}

function fuPaint(){
  const s = FU.steps[FU.i];
  const el = document.getElementById('fuWrap');
  if (!s || !el) return;
  const last = FU.i === FU.steps.length - 1;

  let body;
  if (s.birth){
    body = '<div class="fu-body"><b class="fu-kick">' + esc(s.kicker || 'Una cosa sola, una volta sola') + '</b>'
      + '<p class="fu-line" style="margin-top:0">' + s.line + '</p>'
      + '<input class="fu-date" id="fuBirthIn" type="date" max="' + new Date().toISOString().slice(0, 10) + '">'
      + '</div>';
  } else if (s.img){
    body = '<figure class="fu-img" style="background-image:url(\'' + s.img + '\')">'
      + '<div class="fu-img-in"><p>' + esc(s.quote || '') + '</p><small>' + esc(s.by || '') + '</small></div></figure>';
  } else if (s.list){
    body = '<div class="fu-body"><b class="fu-kick">' + esc(s.kicker || '') + '</b>'
      + '<ul class="fu-list">' + s.list.map(x => '<li><i>' + esc(x[1]) + '</i>' + esc(x[0]) + '</li>').join('') + '</ul></div>';
  } else {
    body = '<div class="fu-body">'
      + (s.kicker ? '<b class="fu-kick">' + esc(s.kicker) + '</b>' : '')
      + '<div class="fu-big' + (s.tone ? ' ' + s.tone : '') + '">' + esc(s.big) + (s.unit ? '<span>' + esc(s.unit) + '</span>' : '') + '</div>'
      + (s.line ? '<p class="fu-line">' + s.line + '</p>' : '')
      + '</div>';
  }

  el.innerHTML = '<div class="fu-sheet' + (s.img ? ' wide' : '') + '">'
    + '<div class="fu-top">'
    +   '<button type="button" class="fu-x" onclick="fuBack()" aria-label="Indietro">' + (FU.i === 0 ? '✕' : '←') + '</button>'
    +   '<div class="fu-dots">' + FU.steps.map((_, k) => '<i' + (k === FU.i ? ' class="on"' : '') + '></i>').join('') + '</div>'
    + '</div>'
    + body
    + '<button type="button" class="fu-go" onclick="fuNext()">' + (last ? 'Ho capito' : 'Continua') + '</button>'
    + '</div>';

  // La pausa prima della cifra: il numero entra dopo il resto, non insieme. È la stessa
  // ragione per cui in un video il colpo arriva dopo il silenzio.
  const big = el.querySelector('.fu-big, .fu-list, .fu-img-in');
  if (big){ big.classList.add('fu-hold'); setTimeout(() => big.classList.remove('fu-hold'), 40); }
}

registerOverlay('fuWrap', '');
(function(){ const el = document.getElementById('fuWrap'); if (el) el.hidden = true; })();

(function(){
  const css = [
    '#fuWrap[hidden]{display:none}',
    '#fuWrap{position:absolute;inset:0;z-index:70;background:#FBFCFE;display:flex;align-items:stretch}',
    'body.dark #fuWrap{background:#050C1C}',
    '.fu-sheet{flex:1;display:flex;flex-direction:column;padding:18px 26px 26px}',
    '.fu-top{display:flex;align-items:center;gap:14px;height:44px;flex:none}',
    '.fu-x{border:0;background:transparent;color:var(--muted);font:600 22px/1 var(--font-body);cursor:pointer;padding:6px 6px 6px 0}',
    '.fu-dots{display:flex;gap:6px;flex:1;justify-content:center;padding-right:28px}',
    '.fu-dots i{width:6px;height:6px;border-radius:50%;background:var(--line)}',
    '.fu-dots i.on{background:var(--navy);width:20px;border-radius:99px}',
    'body.dark .fu-dots i.on{background:#9EC1FF}',
    /* il vuoto attorno: è lui che fa pesare la cifra */
    '.fu-body{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 4px}',
    '.fu-kick{display:block;font:700 11px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:var(--muted);margin-bottom:26px}',
    '.fu-big{font:800 86px/1 var(--font-display);font-style:italic;color:var(--navy);transition:opacity .7s ease,transform .7s ease}',
    'body.dark .fu-big{color:#fff}',
    '.fu-big span{font-size:26px;margin-left:6px;font-style:normal;font-weight:700}',
    '.fu-big.warn{color:#E5515F}',
    '.fu-big.good{color:#0E9E6E}',
    '.fu-line{margin:30px 0 0;max-width:19em;font:500 17px/1.65 var(--font-body);color:var(--muted)}',
    '.fu-line strong{color:var(--navy);font-weight:800}',
    'body.dark .fu-line strong{color:#fff}',
    '.fu-list{list-style:none;margin:0;padding:0;text-align:left;max-width:20em;transition:opacity .7s ease,transform .7s ease}',
    '.fu-list li{display:flex;gap:14px;align-items:baseline;padding:12px 0;border-bottom:1px solid var(--line);font:500 15px/1.45 var(--font-body);color:var(--navy)}',
    'body.dark .fu-list li{color:#fff;border-color:#22345A}',
    '.fu-list i{font-style:normal;font-weight:800;min-width:46px;color:#0E9E6E}',
    /* Il ritratto è largo e lo schermo è alto: a tutta altezza `cover` tagliava via la
       faccia. Il riquadro tiene il rapporto dell'immagine e si centra nel vuoto. */
    '.fu-img{flex:0 1 auto;margin:auto 0;aspect-ratio:3/2;max-height:62vh;border-radius:20px;overflow:hidden;position:relative;background-size:cover;background-position:center}',
    '.fu-img-in{position:absolute;inset:0;width:58%;display:flex;flex-direction:column;justify-content:center;padding:22px 10px 22px 22px;transition:opacity .7s ease,transform .7s ease}',
    '.fu-img-in::before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(238,243,240,.86),rgba(238,243,240,.7) 70%,rgba(238,243,240,0));z-index:0}',
    '.fu-img-in p,.fu-img-in small{position:relative;z-index:1}',
    '.fu-img-in p{margin:0;font:700 15px/1.5 var(--font-display);color:#0F2B33}',
    '.fu-img-in small{display:block;margin-top:12px;font:800 12px var(--font-body);color:#1C4652}',
    '.fu-hold{opacity:0;transform:translateY(14px)}',
    '.fu-date{margin-top:26px;width:100%;max-width:280px;border:2px solid var(--line);border-radius:14px;padding:14px 16px;font:700 18px var(--font-body);color:var(--navy);background:#fff}',
    'body.dark .fu-date{background:#0E1E3A;color:#fff;border-color:#22345A}',
    '.fu-go{flex:none;margin-top:26px;border:0;border-radius:99px;background:var(--blue,#006FCF);color:#fff;padding:17px;font:800 16px var(--font-body);cursor:pointer}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
