/* ===========================================================================================
   IL BIANCO E NERO, MA SOLO DOVE SERVE

   È il bianco e nero DI SISTEMA — quello di «Modalità e routine» di Samsung, quello di
   Impostazioni → Accessibilità: il telefono diventa davvero monocromatico. Non un filtro
   disegnato sopra: quello copre, non scolora.

   LA PAGINA, IN TRE COSE E BASTA.
   Un interruttore. Due cartelle quadrate — «Sempre» e «Programmi» — e niente altro. Prima qui
   dentro c'erano schede, file di pillole, elenchi aperti e campi: sette decisioni in una
   schermata, per una funzione che ne ha due. Le cartelle sono le stesse della pagina Categorie:
   si riconoscono a colpo d'occhio, e quello che contengono si apre quando serve.

     🌑 Sempre      → app, siti, indirizzi con le loro sottocartelle, parole che compaiono
                      sulla pagina: valgono sempre, senza condizioni.
     🗓️ Programmi   → le stesse cose ma solo in certi momenti: orari, giorni, rete Wi-Fi,
                      luogo. Stessa condizione dei programmi della scheda Blocco — ma qui NON
                      bloccano niente: tolgono il colore.
   =========================================================================================== */

let GR = { granted: false, permission: false, why: '', on: false, apps: [], sites: [], programs: [], pkg: 'com.dreambrothers.focuslock', service: true,
  /* LA TERZA CARTELLA, al contrario delle altre due: le UNICHE cose che restano a colori. Con
     `modo` = 'eccezioni' tutto quello che non sta qui dentro e' in bianco e nero. */
  modo: 'lista', colori: { apps: [], sites: [] } };
let GR_APPS = null;
let GR_LOADING = false;
const GR_PROGS_KEY = 'fl_grey_programs';

/* Le tre frasi, scritte per QUESTA pagina: riusare quelle della Lista di blocco voleva dire
   leggere «blocca» dove qui non si blocca niente. */
const GR_HINTS = {
  domain: 'Tutto il sito perde il colore, sottodomini compresi: «instagram.com» prende anche «m.instagram.com», non «notinstagram.com».',
  url: 'Solo gli indirizzi che contengono quello che scrivi: «youtube.com/shorts» spegne gli Shorts e lascia a colori il resto di YouTube, sottocartelle comprese.',
  content: 'Quando quella parola compare sulla pagina. Serve perché Chrome nella barra mostra solo il dominio: è l\'unica che arriva dentro alle pagine.'
};

registerScreen('s-grey', `
  <div class="topbar"><button class="iconbtn" onclick="grBack()">‹</button><b class="blk-title">Bianco e nero</b></div>
  <div id="grBody"></div>
  <div class="spacer"></div>
`, { back: 's-settings' });

registerScreen('s-greyalways', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">Sempre in bianco e nero</b></div>
  <div id="grAlwaysBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greyprogs', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">Programmi</b></div>
  <div id="grProgsBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greycolor', `
  <div class="topbar"><button class="iconbtn" onclick="grOpen()">‹</button><b class="blk-title">A colori</b></div>
  <div id="grColorBody"></div>
  <div class="spacer"></div>
`, { back: 's-grey' });

registerScreen('s-greycolorapps', `
  <div class="topbar"><button class="iconbtn" onclick="grColorOpen()">‹</button><b class="blk-title">App a colori</b></div>
  <div class="fl-search">\ud83d\udd0e<input id="grQc" placeholder="Cerca un'app…" oninput="grColorFilter()" autocomplete="off"></div>
  <div class="gr-list" id="grListColor"></div>
  <div class="spacer"></div>
`, { back: 's-greycolor' });

registerScreen('s-greyapps', `
  <div class="topbar"><button class="iconbtn" onclick="grAlwaysOpen()">‹</button><b class="blk-title">App in bianco e nero</b></div>
  <div class="fl-search">🔎<input id="grQ" placeholder="Cerca un'app…" oninput="grFilter()" autocomplete="off"></div>
  <div class="gr-list" id="grList"></div>
  <div class="spacer"></div>
`, { back: 's-greyalways' });

/* ---------------------------------------------------------------------------------------
   Aprire e chiudere
   --------------------------------------------------------------------------------------- */

function grBack(){
  goId('s-settings');
  /* La riga «Bianco e nero selettivo» della pagina di prima deve dire lo stato NUOVO: senza
     questa chiamata restava ferma a quello che c'era quando la pagina è stata disegnata. */
  try{ if (typeof settingsPaintExits === 'function') settingsPaintExits(); }catch(_){ }
}

function grProgramsLoad(){
  try{ GR.programs = JSON.parse(localStorage.getItem(GR_PROGS_KEY) || '[]') || []; }catch(_){ GR.programs = []; }
}

/* 0.9.264, Andrea: con l'aggiornamento le app e i siti del bianco e nero erano spariti, e la pagina ci metteva
   troppo ad aprirsi (prima "collega il computer", poi gli elenchi). Le cause:
   - la pagina partiva dai valori VUOTI mentre aspettava il telefono: un tocco in quel momento (anche il nuovo
     interruttore della schermata di blocco) salvava gli elenchi vuoti sopra a quelli veri;
   - lo stato si chiedeva DOPO l'elenco delle app installate, e le chiamate al telefono passano in fila: si
     aspettava che arrivassero tutte le app con le icone.
   Adesso: l'ultimo stato letto si tiene sul telefono (fl_grey_cache) e la pagina si apre gia' giusta; lo
   stato vero si chiede per primo; e finche' non e' arrivato non si salva niente. */
const GR_CACHE = 'fl_grey_cache';
function grDaStato(r){
  GR.granted = !!r.granted;
  GR.permission = !!r.permission;
  GR.why = r.why || '';
  GR.on = !!r.on;
  GR.apps = r.apps || [];
  GR.sites = (r.sites || []).map(grKw);
  GR.modo = r.mode === 'eccezioni' ? 'eccezioni' : 'lista';
  GR.colori = { apps: r.colorApps || [], sites: (r.colorSites || []).map(function(v){ return grKw(v).t; }) };
  GR.lockColor = !!r.lockColor;
  if (r.package) GR.pkg = r.package;
  if (typeof r.service === 'boolean') GR.service = r.service;
}
function grInCache(){
  try{ localStorage.setItem(GR_CACHE, JSON.stringify({ granted: GR.granted, permission: GR.permission, on: GR.on, apps: GR.apps, sites: GR.sites, mode: GR.modo, colorApps: GR.colori.apps, colorSites: GR.colori.sites, lockColor: !!GR.lockColor, package: GR.pkg, service: GR.service })); }catch(_){ }
}
async function grOpen(){
  goId('s-grey');
  grProgramsLoad();
  try{ const c = JSON.parse(localStorage.getItem(GR_CACHE) || 'null'); if (c){ grDaStato(c); GR.caricato = true; } }catch(_){ }
  grPaint();
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.greyState){
    try{
      const r = await NATIVE.greyState();
      if (r){
        grDaStato(r);
        GR.caricato = true;
        grInCache();
      }
    }catch(_){ }
  }
  grPaint();
  /* le app installate DOPO lo stato: servono solo quando si tocca "Scegli le app" */
  grLoadApps();
}

/* 0.9.286, Andrea: "sul computer cerco Foto o Esplora risorse e non le trovo". Due cause: l'elenco si leggeva una volta
   sola e restava quello per giorni (sul computer la pagina non si chiude mai: Foto, vista dopo, non c'era); ed Esplora
   risorse il computer non lo offre mai, perche' un blocco messo li' lascerebbe il computer senza scrivania. Per il bianco
   e nero non c'e' rischio: qui si aggiunge, insieme a Foto, e l'elenco si rilegge se ha piu' di un minuto. */
let GR_APPS_AT = 0;
/* 0.9.287: il nome di Windows e quello inglese si trovano tutti e due (alias); il computer manda anche l'icona */
const GR_PC_EXTRA = [{ packageName: 'win:explorer', label: 'Esplora file', alias: 'Esplora risorse File Explorer' }, { packageName: 'win:Photos', label: 'Foto', alias: 'Photos Immagini' }];
async function grLoadApps(forza){
  if (GR_LOADING) return GR_APPS;
  if (GR_APPS && !(forza && Date.now() - GR_APPS_AT > 60000)) return GR_APPS;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalledApps){ GR_APPS = []; return GR_APPS; }
  GR_LOADING = true;
  try{
    const r = await NATIVE.getInstalledApps({ uso: 'colori' });
    GR_APPS = (r && r.apps) || [];
    const pc = typeof pcQui === 'function' && pcQui() === 'desktop';
    if (pc) GR_PC_EXTRA.forEach(function(x){ if (!GR_APPS.some(function(a){ return String(a.packageName || '').toLowerCase() === x.packageName.toLowerCase(); })) GR_APPS.push(Object.assign({ system: false }, x)); });
    GR_APPS.sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); });
    GR_APPS_AT = Date.now();
  }catch(_){ GR_APPS = GR_APPS || []; }
  GR_LOADING = false;
  try{ grPaintApps(); }catch(_){ }
  try{ grPaint(); }catch(_){ }
  return GR_APPS;
}

/* Ogni voce nella forma {t, m} che il motore capisce — le stesse tre modalità della Lista di
   blocco. Una stringa nuda con una barra dentro è un indirizzo, senza è un dominio. */
function grKw(v){
  if (typeof ubKw === 'function' && v && typeof v === 'object') return ubKw(v);
  const t = String((v && typeof v === 'object') ? (v.t || v.term || '') : (v || '')).trim().toLowerCase();
  const m = (v && typeof v === 'object' && (v.m || v.mode)) ? String(v.m || v.mode) : (t.indexOf('/') >= 0 ? 'url' : 'domain');
  return { t: t, m: m };
}

async function grSave(){
  try{ localStorage.setItem(GR_PROGS_KEY, JSON.stringify(GR.programs)); }catch(_){ }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setGrey) return;
  /* mai scrivere sopra agli elenchi veri prima di averli letti */
  if (!GR.caricato){ try{ toast('Un attimo: sto leggendo le tue impostazioni'); }catch(_){ } return; }
  grInCache();
  const programs = GR.programs.map(function(p){
    return (typeof programToSchedule === 'function') ? programToSchedule(p) : p;
  });
  try{ await NATIVE.setGrey({ on: GR.on, apps: GR.apps, sites: GR.sites, programs: programs,
                              mode: GR.modo, colorApps: GR.colori.apps, colorSites: GR.colori.sites, lockColor: !!GR.lockColor }); }catch(_){ }
  /* la riserva di dopamina legge il bianco e nero: che sappia subito del cambio */
  try{ if (typeof DP !== 'undefined' && DP) DP.grigio = null; }catch(_){ }
}

function grToggleOn(){
  GR.on = !GR.on;
  grSave(); grPaint();
  if (GR.on && !GR.granted) toast('Manca l\'attivazione dal computer: è scritta qui sopra');
  else if (GR.on && !grCount()) toast('Adesso scegli su cosa: le due cartelle qui sotto');
}

function grCount(){ return GR.apps.length + GR.sites.length + GR.programs.length + (GR.modo === 'eccezioni' ? 1 : 0); }

/* ---------------------------------------------------------------------------------------
   LA PAGINA: un interruttore e due cartelle
   --------------------------------------------------------------------------------------- */

function grPaint(){
  const box = document.getElementById('grBody');
  if (!box) return;

  /* DUE CASI DIVERSI, NON UNO SOLO.
     Se il sistema dice che il permesso NON c'è, va concesso, e si spiega come.
     Se dice che c'è ma la scrittura fallisce lo stesso, il problema è un altro: si mostra
     l'errore vero invece di ripetere istruzioni già eseguite. È esattamente la trappola in cui
     è finito Andrea — riquadro rosso acceso dopo un'attivazione riuscita, e nessun modo di
     capire da che parte stesse il guasto. */
  const permesso = GR.granted ? '' : (GR.permission
    ? '<div class="gr-warn">'
      + '<b>⚠️ Il permesso c\'è, ma la scrittura non passa</b>'
      + '<p>Android dice che DreamMap ha il permesso, eppure il telefono rifiuta di cambiare il bianco e nero di sistema. Non è un passaggio che hai saltato tu.</p>'
      + (GR.why ? '<div class="gr-why">' + esc(GR.why) + '</div>' : '')
      + '<p style="margin:12px 0 0">Prova a riavviare il telefono: il permesso resta, e quasi sempre è quello a sbloccarlo.</p>'
      + '<button type="button" class="ghostmini" style="width:100%;margin-top:12px" onclick="grOpen()">Ricontrolla</button>'
      + '</div>'
    : '<div class="gr-warn">'
      + '<b>🔑 Un\'attivazione, una volta sola, senza cavo</b>'
      + '<p>Il bianco e nero di sistema è protetto da un permesso che Android non concede da solo a nessuna app. Si dà una volta, dal computer, sulla stessa rete Wi-Fi.</p>'
      + '<div class="gr-steps">'
      +   '<div><i>1</i><span><b>Sul telefono</b><br>Impostazioni → Opzioni sviluppatore → Debug wireless → «Accoppia dispositivo con codice».</span></div>'
      +   '<div><i>2</i><span><b>Sul computer</b><br>DreamMap → Impostazioni → «Attiva il bianco e nero sul telefono»: ci scrivi codice e indirizzo.</span></div>'
      +   '<div><i>3</i><span><b>Riapri l\'app</b><br>Alla fine il computer la chiude da solo: riaprendola il permesso è attivo e questo riquadro sparisce.</span></div>'
      + '</div>'
      + '<button type="button" class="ghostmini" style="width:100%;margin-top:14px" onclick="grOpen()">Ho già fatto: ricontrolla</button>'
      + '</div>');
  const testa = '<div class="ps-block">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>🌑 Bianco e nero selettivo</b>'
    + '<small>Il telefono diventa monocromatico solo mentre hai davanti quello che scegli tu. Tutto il resto resta a colori.</small></div>'
    + '<button class="switch' + (GR.on ? ' on' : '') + '" onclick="grToggleOn()"></button></div>'
    + (GR.service === false
        ? '<p class="hintline" style="padding:10px 2px 0;color:#E5515F">Il servizio di blocco è spento: senza di lui nessuno sa cosa hai davanti. Accendilo dal profilo.</p>'
        : '')
    + '</div>';

  box.innerHTML = permesso + testa
    + '<div class="sect" style="margin-top:26px"><b>Cosa diventa bianco e nero</b></div>'
    + '<div class="hintline" style="padding:0 2px 12px">' + (GR.modo === 'eccezioni'
        ? 'Tutto, tranne quello che sta nella cartella <b>A colori</b>. Le altre due cartelle non servono finch\u00e9 questa \u00e8 accesa.'
        : 'Tre cartelle: quello che vale sempre, quello che vale solo in certi momenti, e \u2014 al contrario \u2014 le uniche cose che restano a colori.') + '</div>'
    + '<div class="grp-row">' + grCardSempre() + grCardColori() + grCardProgrammi() + '</div>';

  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}

function grMiniChips(voci, extra){
  const q = voci.slice(0, 3);
  while (q.length < 3) q.push('<span class="grp-chip grp-chip-void"></span>');
  q.push('<span class="grp-chip grp-chip-more">' + extra + '</span>');
  return '<span class="grp-grid">' + q.join('') + '</span>';
}

function grCardSempre(){
  const n = GR.apps.length + GR.sites.length;
  const voci = [];
  GR.apps.slice(0, 3).forEach(function(p){
    voci.push('<span class="grp-chip"><span class="ub-appico ub-appico-fb">' + esc(grAppLabel(p).charAt(0).toUpperCase())
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(p) + '" alt=""></span></span>');
  });
  GR.sites.slice(0, Math.max(0, 3 - voci.length)).forEach(function(k){
    const m = grKw(k).m;
    voci.push('<span class="grp-chip">' + (m === 'content' ? '🔤' : (m === 'url' ? '📄' : '🌐')) + '</span>');
  });
  return '<button type="button" class="grp-card" onclick="grAlwaysOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '🌑')
    + '<b class="grp-name">Sempre</b>'
    + '<small class="grp-count">' + (n ? n + (n === 1 ? ' voce' : ' voci') : 'vuoto') + '</small>'
    + '</button>';
}

function grCardProgrammi(){
  const n = GR.programs.length;
  const attivi = GR.programs.filter(function(p){ return p.on !== false; }).length;
  const voci = GR.programs.slice(0, 3).map(function(p){
    return '<span class="grp-chip">' + (p.icon || '🕑') + '</span>';
  });
  return '<button type="button" class="grp-card" onclick="grProgsOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '🗓️')
    + '<b class="grp-name">Programmi</b>'
    + '<small class="grp-count">' + (n ? attivi + ' su ' + n + ' attivi' : 'nessuno') + '</small>'
    + '</button>';
}

function grCardColori(){
  const n = GR.colori.apps.length + GR.colori.sites.length;
  const on = GR.modo === 'eccezioni';
  const voci = [];
  GR.colori.apps.slice(0, 3).forEach(function(p){
    voci.push('<span class="grp-chip"><span class="ub-appico ub-appico-fb">' + esc(grAppLabel(p).charAt(0).toUpperCase())
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(p) + '" alt=""></span></span>');
  });
  GR.colori.sites.slice(0, Math.max(0, 3 - voci.length)).forEach(function(){ voci.push('<span class="grp-chip">\ud83c\udf10</span>'); });
  return '<button type="button" class="grp-card' + (on ? ' grp-on' : '') + '" onclick="grColorOpen()">'
    + grMiniChips(voci, n > 3 ? '+' + (n - 3) : '\ud83c\udfa8')
    + '<b class="grp-name">A colori</b>'
    + '<small class="grp-count">' + (on ? (n ? n + (n === 1 ? ' voce' : ' voci') + ' \u00b7 il resto grigio' : 'acceso, vuoto') : (n ? n + (n === 1 ? ' voce' : ' voci') + ' \u00b7 spento' : 'spento')) + '</small>'
    + '</button>';
}

/* ---------------------------------------------------------------------------------------
   A COLORI: le uniche eccezioni. Tutto il resto in bianco e nero.
   --------------------------------------------------------------------------------------- */
function grColorOpen(){
  goId('s-greycolor');
  grPaintColor();
  grLoadApps();
}
function grPaintColor(){
  const box = document.getElementById('grColorBody');
  if (!box) return;
  const on = GR.modo === 'eccezioni';
  const testa = '<div class="ps-block">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83c\udfa8 Tutto il resto in bianco e nero</b>'
    + '<small>Solo le app e i siti scelti qui restano a colori. Ogni altra schermata perde il colore, e con lui buona parte dello stimolo: la riserva di dopamina lo sente.</small></div>'
    + '<button class="switch' + (on ? ' on' : '') + '" onclick="grColorToggle()"></button></div>'
    + '</div>';
  const app = '<div class="sect" style="margin-top:26px"><b>\ud83d\udcf1 App a colori</b></div>'
    + '<div class="setrow" onclick="grColorOpenApps()"><span>\ud83d\udcf1</span><b>Scegli le app</b><small>'
    + (GR.colori.apps.length ? GR.colori.apps.length + (GR.colori.apps.length === 1 ? ' scelta' : ' scelte') : (GR_APPS ? 'nessuna' : 'leggo le app\u2026')) + '</small><span class="chev"></span></div>'
    + (GR.colori.apps.length
        ? '<div class="gr-chips">' + GR.colori.apps.map(function(p){
            return '<span class="gr-chip">' + esc(grAppLabel(p)) + '<button type="button" onclick="grColorRemoveApp(\'' + esc(p) + '\')" aria-label="Togli">\u2715</button></span>';
          }).join('') + '</div>'
        : '');
  const siti = '<div class="sect" style="margin-top:26px"><b>\ud83c\udf10 Siti a colori</b></div>'
    + '<div class="gr-addrow">'
    +   '<input id="grColorSiteIn" placeholder="notion.so \u00b7 docs.google.com" autocomplete="off"'
    +   ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();grColorSiteAdd();}">'
    + '</div>'
    + '<button type="button" class="ghostmini ff-addsite" onclick="grColorSiteAdd()">Inserisci</button>'
    + (GR.colori.sites.length
        ? '<div class="gr-list" style="margin-top:12px">' + GR.colori.sites.map(function(t, i){
            return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">\ud83c\udf10</span>'
              + '<span class="ff-pickname">' + esc(t) + '</span>'
              + '<button type="button" class="ff-rm" onclick="grColorSiteDel(' + i + ')" aria-label="Togli">\u2715</button></div>';
          }).join('') + '</div>'
        : '<p class="ff-empty">Il sito su cui lavori mettilo qui: \u00e8 quello che devi vedere a colori.</p>');
  /* 0.9.263, Andrea: la schermata di blocco del telefono (e la frase del giorno sopra) si puo' vedere a colori */
  const blocco = '<div class="ps-block" style="margin-top:26px">'
    + '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udd12 Schermata di blocco a colori</b>'
    + '<small>Quando il telefono è bloccato, la schermata di blocco e la frase del giorno restano a colori. Appena sblocchi, il bianco e nero torna dove l’avevi scelto.</small></div>'
    + '<button class="switch' + (GR.lockColor ? ' on' : '') + '" onclick="grLockColorToggle()"></button></div>'
    + '</div>';
  box.innerHTML = testa + blocco + app + siti;
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}
function grLockColorToggle(){
  GR.lockColor = !GR.lockColor;
  grSave(); grPaintColor();
  try{ toast(GR.lockColor ? 'La schermata di blocco resta a colori' : 'La schermata di blocco segue il bianco e nero'); }catch(_){ }
}
function grColorToggle(){
  GR.modo = GR.modo === 'eccezioni' ? 'lista' : 'eccezioni';
  if (GR.modo === 'eccezioni') GR.on = true;
  grSave(); grPaintColor();
  if (GR.modo === 'eccezioni' && !GR.granted) toast('Manca l\'attivazione dal computer: \u00e8 scritta nella pagina Bianco e nero');
  else if (GR.modo === 'eccezioni') toast('Tutto in bianco e nero, tranne quello che scegli qui');
}
async function grColorOpenApps(){
  goId('s-greycolorapps');
  grPaintColorApps();
  await grLoadApps(true);
  grPaintColorApps();
}
function grPaintColorApps(){
  const box = document.getElementById('grListColor');
  if (!box) return;
  if (!GR_APPS){ box.innerHTML = '<p class="ff-empty">Leggo le app del telefono\u2026</p>'; return; }
  if (!GR_APPS.length){ box.innerHTML = '<p class="ff-empty">Nessuna app da elencare.</p>'; return; }
  box.innerHTML = GR_APPS.map(function(a){
    const on = GR.colori.apps.indexOf(a.packageName) >= 0;
    const letter = esc((a.label || '?').charAt(0).toUpperCase());
    return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
      + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>' + (a.alias ? '<span class="ff-alias" hidden>' + esc(a.alias) + '</span>' : '')
      + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '')
      + ' onchange="grColorToggleApp(this)"></label>';
  }).join('');
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
  grColorFilter();
}
function grColorFilter(){
  const q = ((document.getElementById('grQc') || {}).value || '').trim().toLowerCase();
  document.querySelectorAll('#grListColor .ff-pickrow').forEach(function(r){
    r.style.display = (!q || r.textContent.toLowerCase().indexOf(q) >= 0) ? '' : 'none';
  });
}
function grColorToggleApp(cb){
  const i = GR.colori.apps.indexOf(cb.value);
  if (cb.checked && i < 0) GR.colori.apps.push(cb.value);
  if (!cb.checked && i >= 0) GR.colori.apps.splice(i, 1);
  grSave();
}
function grColorRemoveApp(pkg){
  GR.colori.apps = GR.colori.apps.filter(function(x){ return x !== pkg; });
  grSave(); grPaintColor();
}
function grColorSiteAdd(){
  const inp = document.getElementById('grColorSiteIn');
  const t = grKw((inp && inp.value) || '').t;
  if (!t){ toast('Scrivi un sito'); return; }
  if (GR.colori.sites.indexOf(t) < 0) GR.colori.sites.push(t);
  if (inp) inp.value = '';
  grSave(); grPaintColor();
}
function grColorSiteDel(i){
  GR.colori.sites.splice(i, 1);
  grSave(); grPaintColor();
}

/* ---------------------------------------------------------------------------------------
   SEMPRE: app, siti, indirizzi, parole
   --------------------------------------------------------------------------------------- */

function grAlwaysOpen(){
  goId('s-greyalways');
  grPaintAlways();
}

function grPaintAlways(){
  const box = document.getElementById('grAlwaysBody');
  if (!box) return;

  const app = '<div class="sect"><b>📱 App</b></div>'
    + '<div class="setrow" onclick="grOpenApps()"><span>📱</span><b>Scegli le app</b><small>'
    + (GR.apps.length ? GR.apps.length + (GR.apps.length === 1 ? ' scelta' : ' scelte') : (GR_APPS ? 'nessuna' : 'leggo le app…')) + '</small><span class="chev"></span></div>'
    + (GR.apps.length
        ? '<div class="gr-chips">' + GR.apps.map(function(p){
            return '<span class="gr-chip">' + esc(grAppLabel(p)) + '<button type="button" onclick="grRemoveApp(\'' + esc(p) + '\')" aria-label="Togli">✕</button></span>';
          }).join('') + '</div>'
        : '');

  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const siti = '<div class="sect" style="margin-top:26px"><b>🌐 Siti, pagine e parole</b></div>'
    + '<div class="gr-addrow">'
    +   '<input id="grSiteIn" placeholder="instagram.com · youtube.com/shorts · reels" autocomplete="off"'
    +   ' oninput="grOnInput()" onkeydown="if(event.key===\'Enter\'){event.preventDefault();grSiteAdd();}">'
    +   '<button type="button" class="gr-modebtn" onclick="grOpenMode()"><span id="grModeLbl">' + esc(grModeLabel(m)) + '</span><i class="ub-caret"></i></button>'
    + '</div>'
    + '<p class="hintline" id="grModeHint" style="padding:8px 2px 0"></p>'
    + '<button type="button" class="ghostmini ff-addsite" onclick="grSiteAdd()">Inserisci</button>'
    + (GR.sites.length
        ? '<div class="gr-list" style="margin-top:12px">' + GR.sites.map(function(k, i){
            const mm = grKw(k);
            return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">'
              + (mm.m === 'content' ? '🔤' : (mm.m === 'url' ? '📄' : '🌐')) + '</span>'
              + '<span class="ff-pickname">' + esc(mm.t) + '</span>'
              + '<button type="button" class="ub-modetag ub-m-' + mm.m + '" onclick="grOpenMode(' + i + ')">' + esc(grModeLabel(mm.m)) + '<i class="ub-caret"></i></button>'
              + '<button type="button" class="ff-rm" onclick="grSiteDel(' + i + ')" aria-label="Togli">✕</button></div>';
          }).join('') + '</div>'
        : '<p class="ff-empty">Il sito su cui lavori lascialo fuori: è quello che devi vedere a colori.</p>');

  box.innerHTML = app + siti;
  grPaintModeBtn();
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
}

/* ---- le app ---- */

async function grOpenApps(){
  goId('s-greyapps');
  grPaintApps();
  await grLoadApps(true);
  grPaintApps();
}

function grPaintApps(){
  const box = document.getElementById('grList');
  if (!box) return;
  if (!GR_APPS){ box.innerHTML = '<p class="ff-empty">Leggo le app del telefono…</p>'; return; }
  if (!GR_APPS.length){ box.innerHTML = '<p class="ff-empty">Nessuna app da elencare.</p>'; return; }
  box.innerHTML = GR_APPS.map(function(a){
    const on = GR.apps.indexOf(a.packageName) >= 0;
    const letter = esc((a.label || '?').charAt(0).toUpperCase());
    return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
      + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
      + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>' + (a.alias ? '<span class="ff-alias" hidden>' + esc(a.alias) + '</span>' : '')
      + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '')
      + ' onchange="grToggleApp(this)"></label>';
  }).join('');
  if (typeof ubFillIcons === 'function') ubFillIcons(box);
  grFilter();
}

function grToggleApp(cb){
  const i = GR.apps.indexOf(cb.value);
  if (cb.checked && i < 0) GR.apps.push(cb.value);
  if (!cb.checked && i >= 0) GR.apps.splice(i, 1);
  grSave();
}

function grRemoveApp(pkg){
  GR.apps = GR.apps.filter(function(x){ return x !== pkg; });
  grSave(); grPaintAlways();
}

function grFilter(){
  const inp = document.getElementById('grQ');
  const q = ((inp && inp.value) || '').toLowerCase();
  document.querySelectorAll('#grList .ff-pickrow').forEach(function(r){
    r.style.display = r.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
  });
}

function grAppLabel(pkg){
  const a = (GR_APPS || []).filter(function(x){ return x.packageName === pkg; })[0];
  return a ? (a.label || pkg) : String(pkg || '').split('.').pop();
}

/* ---- siti, indirizzi, parole ---- */

function grModeSrc(){
  return {
    list: function(){ return GR.sites; },
    normalize: function(){ GR.sites = GR.sites.map(grKw); },
    hints: GR_HINTS,
    after: function(){ grSave(); grPaintAlways(); }
  };
}

function grOpenMode(i){
  if (typeof ubOpenModeForList !== 'function'){ toast('Non disponibile in questa versione'); return; }
  ubOpenModeForList(typeof i === 'number' ? i : null, grModeSrc());
}

function grOnInput(){
  const v = ((document.getElementById('grSiteIn') || {}).value || '').trim().toLowerCase();
  if (typeof UB_MODE_TOUCHED !== 'undefined' && !UB_MODE_TOUCHED){
    UB_NEW_MODE = v.indexOf('/') >= 0 ? 'url'
      : ((typeof ubLooksLikeDomain === 'function' && ubLooksLikeDomain(v)) ? 'domain' : (v ? 'content' : 'domain'));
  }
  grPaintModeBtn();
}

function grPaintModeBtn(){
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const b = document.getElementById('grModeLbl');
  if (b) b.textContent = grModeLabel(m);
  const h = document.getElementById('grModeHint');
  if (h) h.textContent = GR_HINTS[m] || '';
}

function grModeLabel(m){
  if (typeof UB_MODES !== 'undefined' && UB_MODES[m]) return UB_MODES[m].label;
  return m === 'content' ? 'Nel contenuto della pagina' : (m === 'url' ? 'Ovunque nell\'URL' : 'Nel dominio');
}

function grSiteAdd(){
  const inp = document.getElementById('grSiteIn');
  let v = String(inp ? inp.value : '').trim().toLowerCase();
  if (!v){ toast('Scrivi un sito, un indirizzo o una parola'); return; }
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : (v.indexOf('/') >= 0 ? 'url' : 'domain');
  if (m === 'domain'){
    v = (typeof ubSiteNorm === 'function') ? ubSiteNorm(v) : v.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').split('/')[0];
    if (!v || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(v)){ toast('Per «nel dominio» serve un indirizzo, per esempio instagram.com'); return; }
  } else {
    v = v.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').replace(/\/+$/, '');
  }
  if (GR.sites.some(function(x){ return x.t === v && x.m === m; })){ toast('«' + v + '» è già in elenco'); return; }
  GR.sites.push({ t: v, m: m });
  if (inp) inp.value = '';
  if (typeof UB_MODE_TOUCHED !== 'undefined') UB_MODE_TOUCHED = false;
  grSave(); grPaintAlways();
}

function grSiteDel(i){
  GR.sites.splice(i, 1);
  grSave(); grPaintAlways();
}

/* ---------------------------------------------------------------------------------------
   PROGRAMMI: gli stessi della scheda Blocco, in un elenco che non blocca niente
   --------------------------------------------------------------------------------------- */

function grProgsOpen(){
  goId('s-greyprogs');
  grProgramsLoad();
  grPaintProgs();
}

function grPaintProgs(){
  const box = document.getElementById('grProgsBody');
  if (!box) return;
  box.innerHTML =
      '<p class="hintline" style="padding:0 2px 14px">Come «Modalità e routine»: a certe ore, in certi giorni, su una rete Wi-Fi o in un luogo, le app e i siti del programma diventano bianco e nero. Non vengono bloccati: perdono solo il colore.</p>'
    + (GR.programs.length
        ? GR.programs.map(function(p, i){
            const paused = p.on === false;
            return '<div class="gr-prog' + (paused ? ' off' : '') + '" onclick="grEditProgram(' + i + ')" role="button">'
              + '<span class="gr-prog-ico">' + (p.icon || '🌑') + '</span>'
              + '<div class="gr-prog-txt"><b>' + esc(p.name || 'Programma') + '</b>'
              + '<small>' + esc(typeof describeProgram === 'function' ? describeProgram(p) : '') + '</small></div>'
              + '<span class="gr-prog-pill">' + (paused ? 'IN PAUSA' : 'ATTIVO') + '</span>'
              + '<div class="gr-prog-btns">'
              +   '<button type="button" onclick="event.stopPropagation();grProgramToggle(' + i + ')">' + (paused ? '▶ Riprendi' : '⏸ Pausa') + '</button>'
              +   '<button type="button" class="del" onclick="event.stopPropagation();grProgramDelete(' + i + ')">Elimina</button>'
              + '</div></div>';
          }).join('')
        : '<p class="ff-empty">Nessun programma. Il primo può essere «dalle 21 alle 7, tutti i giorni»: la sera il telefono si spegne di colore da solo.</p>')
    + '<button type="button" class="cta" style="margin-top:16px" onclick="grNewProgram()">＋ Nuovo programma</button>';
}

function grNewProgram(){
  if (typeof newBlock !== 'function'){ toast('Non disponibile in questa versione'); return; }
  /* IL PARAMETRO NON È UN DETTAGLIO: `newBlock()` senza argomento azzera il contrassegno
     «questo è grigio», e il programma finiva fra i blocchi — bloccando davvero l'app invece di
     scolorirla. È successo, ed è il difetto peggiore che questa pagina potesse avere. */
  newBlock(true);
}

function grEditProgram(i){
  const p = GR.programs[i];
  if (!p || typeof openEditor !== 'function') return;
  window.BLK_GREY = true;
  DRAFT = JSON.parse(JSON.stringify(p));
  DRAFT.grey = true;
  DRAFT.idx = i;
  if (!Array.isArray(DRAFT.days) || DRAFT.days.length !== 7) DRAFT.days = [true, true, true, true, true, true, true];
  openEditor();
}

/* Chiamata da saveBlock() quando la bozza è grigia: il programma finisce qui, non fra i
   blocchi, e il motore di blocco non lo vede mai. */
function grSaveProgram(clean, idx){
  grProgramsLoad();
  if (idx >= 0 && GR.programs[idx]) GR.programs[idx] = clean; else GR.programs.push(clean);
  grSave();
}

function grAfterProgramSave(){
  grProgramsLoad();
  grProgsOpen();
}

async function grProgramToggle(i){
  const p = GR.programs[i]; if (!p) return;
  p.on = p.on === false;
  await grSave(); grPaintProgs();
}

async function grProgramDelete(i){
  const p = GR.programs[i]; if (!p) return;
  if (!(await blkEliminaChiedi())) return;
  const at = GR.programs.indexOf(p); if (at < 0) return;
  GR.programs.splice(at, 1);
  await grSave(); grPaintProgs();
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */

(function grStyle(){
  const css = [
    /* L'elenco riempie lo schermo: il .ff-picklist del timer si ferma a 42vh, e qui tagliava
       le app a quattro righe lasciando mezzo schermo vuoto sotto. */
    '.gr-list{margin-top:10px}',
    '.gr-warn{border:1px solid #E5515F;border-radius:20px;padding:16px;margin-bottom:14px;background:rgba(229,81,95,.05)}',
    '.gr-warn>b{display:block;font:800 15px var(--font-body);color:var(--navy);margin-bottom:6px}',
    'body.dark .gr-warn>b{color:#fff}',
    '.gr-warn>p{margin:0 0 12px;font:500 13px/1.55 var(--font-body);color:var(--muted)}',
    '.gr-steps{display:flex;flex-direction:column;gap:12px}',
    '.gr-steps>div{display:flex;gap:10px;align-items:flex-start;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.gr-steps i{flex:0 0 24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:700 12px/24px var(--font-body);text-align:center;font-style:normal}',
    '.gr-steps b{color:var(--navy)}',
    '.gr-why{font:600 11px/1.5 ui-monospace,Menlo,Consolas,monospace;background:rgba(14,35,80,.06);'
      + 'border-radius:10px;padding:10px 12px;color:#6B7A99;word-break:break-word}',
    'body.dark .gr-steps b{color:#fff}',
    '.gr-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}',
    '.gr-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 8px 6px 12px;border-radius:99px;background:rgba(0,117,227,.10);color:var(--navy);font:600 12.5px/1 var(--font-body)}',
    'body.dark .gr-chip{background:rgba(255,255,255,.08);color:#fff}',
    '.gr-chip button{border:0;background:transparent;color:var(--muted);font:700 12px/1 var(--font-body);cursor:pointer;padding:2px 4px}',
    '.gr-addrow{display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:6px 6px 6px 14px}',
    'body.dark .gr-addrow{background:#12203A;border-color:#22345A}',
    '.gr-addrow input{flex:1;min-width:0;border:0;outline:0;background:transparent;font:500 14px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .gr-addrow input{color:#fff}',
    '.gr-modebtn{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;border:0;border-radius:10px;padding:9px 11px;background:rgba(14,35,80,.06);color:var(--navy);font:700 12px/1 var(--font-body);cursor:pointer;white-space:nowrap}',
    'body.dark .gr-modebtn{background:rgba(255,255,255,.10);color:#fff}',
    '.gr-prog{display:grid;grid-template-columns:auto 1fr auto;gap:10px 12px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:20px;padding:14px;margin-bottom:10px;cursor:pointer}',
    'body.dark .gr-prog{background:#12203A;border-color:#22345A}',
    '.gr-prog.off{opacity:.62}',
    '.gr-prog-ico{font-size:22px}',
    '.gr-prog-txt b{display:block;font:700 15px var(--font-body);color:var(--navy)}',
    'body.dark .gr-prog-txt b{color:#fff}',
    '.gr-prog-txt small{display:block;margin-top:2px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.gr-prog-pill{font:800 10px/1 var(--font-body);letter-spacing:.06em;color:#0075E3;background:rgba(0,117,227,.12);padding:6px 9px;border-radius:99px}',
    '.gr-prog.off .gr-prog-pill{color:var(--muted);background:rgba(14,35,80,.07)}',
    '.gr-prog-btns{grid-column:1/-1;display:flex;gap:8px}',
    '.gr-prog-btns button{flex:1;border:0;border-radius:12px;padding:9px 0;background:rgba(14,35,80,.06);color:var(--navy);font:700 12px/1 var(--font-body);cursor:pointer}',
    'body.dark .gr-prog-btns button{background:rgba(255,255,255,.08);color:#fff}',
    '.gr-prog-btns button.del{color:#E5515F}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* L'interruttore del mantra a colori: vive nelle impostazioni del motore, perche' e' il
   servizio a doverlo leggere nel momento in cui disegna la card — la pagina web li' non c'e'. */
async function grToggleMantraColori(){
  const ora = (typeof SETTINGS !== 'undefined') && SETTINGS.mantraColori;
  if (typeof settingsSave === 'function') await settingsSave({ mantraColori: !ora });
  grPaint();
  if (typeof toast === 'function'){
    toast(!ora ? 'Il mantra arrivera\' a colori' : 'Il mantra resta in bianco e nero');
  }
}

/* La cartella accesa si vede: bordo blu, come una scelta fatta. Le tre cartelle scorrono in
   orizzontale come nella pagina Categorie, che e' lo stesso disegno. */
(function grStyleColori(){
  const st = document.createElement('style');
  /* LA TERZA CARTELLA SI DEVE INTRAVEDERE. Con tre cartelle da 158px la terza stava tutta
     fuori dallo schermo, e una riga che scorre di lato senza che se ne veda il bordo e' una
     riga che non scorre. Qui le cartelle sono larghe due e mezzo per riga: la terza sbuca. */
  st.textContent = '.grp-card.grp-on{border-color:var(--blue);box-shadow:0 0 0 2px rgba(0,117,227,.18)}\n'
    + '#grBody .grp-card{width:calc((100% - 34px) / 2.4)}';
  document.head.appendChild(st);
})();
