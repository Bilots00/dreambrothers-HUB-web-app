/* ===========================================================================================
   IL COLLO DI BOTTIGLIA E IL PONTE (0.9.335)

   Andrea: "prima di controllare la rotta, il Genio deve trovare il collo di bottiglia che blocca il
   progresso verso il sogno: la cosa che, se risolta, sblocca tutto o rende tutto il resto piu' facile,
   inutile o superfluo". La richiesta parte dalla slide "Com'e' andata oggi" o dalla pill dell'agente;
   il tuo agente comincia la risposta con una riga "COLLO DI BOTTIGLIA: ..." e da quella riga l'app
   tiene l'ultimo trovato e lo mostra in Dream, prima del tuo ritmo.

   Il ponte (al posto del grafico "Stai rallentando"): dalla paura e dal dubbio, a sinistra, alla fede
   e alla velocita', a destra. Dove sei sul ponte lo dice il tuo momentum: quante decisioni prendi oggi
   (tappe fatte, sessioni partite, righe del foglio chiuse, scelte del Genio) e quanto ci metti dalla
   sveglia alla prima mossa. Prefisso clo-.
   =========================================================================================== */
const CLO_K = 'fl_collo';
const CLO_RICHIESTA = 'Trova il mio collo di bottiglia: l’unica cosa che, se la sblocco, rende tutto il resto più facile.';
/* il formato della risposta lo chiede il brief (agBrief, agente.js), non il messaggio: a schermo resta una frase sola */
const CLO_FORMATO = 'SE TI CHIEDE IL COLLO DI BOTTIGLIA o di controllare la rotta: prima di tutto trova l’unica cosa che, se sbloccata, rende il resto più facile o inutile. Comincia la risposta con una riga "COLLO DI BOTTIGLIA: ..." (al massimo 12 parole), poi una riga "PRIMA MOSSA: ...", poi il perché in due o tre frasi.';
function cloEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function cloLeggi(){ try{ const o = JSON.parse(localStorage.getItem(CLO_K) || 'null'); return o && o.t ? o : null; }catch(_){ return null; } }

/* dalla risposta del tuo agente: la riga del collo, la prima mossa, il perche' */
function cloDaTesto(testo, at){
  const t = String(testo || '').replace(/\*\*/g, '');
  const m = /COLLO DI BOTTIGLIA\s*:\s*([^\n]+)/i.exec(t); if (!m) return null;
  const mo = /PRIMA MOSSA\s*:\s*([^\n]+)/i.exec(t);
  const resto = t.split('\n').filter(function(r){ return r.trim() && !/COLLO DI BOTTIGLIA\s*:|PRIMA MOSSA\s*:/i.test(r); }).join(' ').replace(/\s+/g, ' ').trim();
  const pulisci = function(s){ return String(s || '').replace(/^[\s"*_]+|[\s"*_]+$/g, '').trim(); };
  return { t: pulisci(m[1]).slice(0, 140), mossa: mo ? pulisci(mo[1]).slice(0, 160) : '', perche: resto.slice(0, 260), at: at || Date.now() };
}
function cloSalvaDa(m){
  try{
    if (!m || m.direzione === 'in' || !m.testo) return;
    const at = m.at || Date.parse(m.creato || m.createdAt || '') || Date.now();
    const c = cloDaTesto(m.testo, at); if (!c) return;
    const prima = cloLeggi(); if (prima && prima.at >= c.at && prima.t === c.t) return;
    if (prima && prima.at > c.at) return;
    localStorage.setItem(CLO_K, JSON.stringify(c));
    setTimeout(function(){ try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ } }, 50);
  }catch(_){ }
}
function cloChiedi(diretto){
  try{ localStorage.setItem('fl_ctl_giorno', new Date().toDateString()); }catch(_){ }
  if (typeof agApri !== 'function') return;
  if (diretto && typeof agNuovaConversazione === 'function'){ agNuovaConversazione(CLO_RICHIESTA, { titolo: 'Il mio collo di bottiglia' }); return; }
  agApri();
  /* la richiesta si scrive nel campo: parte solo con invio */
  setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza(CLO_RICHIESTA); }catch(_){ } }, 300);
}
function cloSblocca(){
  const c = cloLeggi(); if (!c) return;
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  try{ if (typeof ffPref === 'function'){ ffPref().intent = (c.mossa || c.t).slice(0, 120); if (typeof ffSavePref === 'function') ffSavePref(); } }catch(_){ }
  try{ goId('s-fullfocus'); if (typeof ffPaint === 'function') ffPaint(); }catch(_){ }
}
const CLO_BOTTIGLIA = '<svg class="clo-bt" viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="cloV" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8CC6FF"/><stop offset="1" stop-color="#0075E3"/></linearGradient></defs>'
  + '<path d="M48 22h24v16c0 6 18 12 18 30v34a10 10 0 0 1-10 10H40a10 10 0 0 1-10-10V68c0-18 18-24 18-30z" fill="url(#cloV)" opacity=".9"/>'
  + '<path d="M38 70h44v30a6 6 0 0 1-6 6H44a6 6 0 0 1-6-6z" fill="#fff" opacity=".18"/>'
  + '<circle cx="50" cy="88" r="5" fill="#fff"/><circle cx="64" cy="94" r="5" fill="#fff" opacity=".85"/><circle cx="70" cy="80" r="5" fill="#fff" opacity=".7"/><circle cx="56" cy="76" r="5" fill="#fff" opacity=".8"/>'
  + '<circle cx="60" cy="40" r="5" fill="#fff"/><circle cx="60" cy="50" r="4" fill="#fff" opacity=".7"/>'
  + '<rect x="45" y="8" width="30" height="16" rx="4" fill="#E63946"/><rect x="45" y="8" width="30" height="5" rx="2.5" fill="#fff" opacity=".35"/></svg>';
/* il pannello in Dream, prima del tuo ritmo: c'e' solo dopo che il tuo agente l'ha trovato */
function cloPannelloHtml(){
  const c = cloLeggi(); if (!c) return '';
  const quando = (function(){ const d = Math.floor((Date.now() - c.at) / 86400000); return d <= 0 ? 'Trovato oggi' : (d === 1 ? 'Trovato ieri' : 'Trovato ' + d + ' giorni fa'); })();
  return '<section class="clo-p"><p class="nvp-rit-k">Il tuo collo di bottiglia</p>'
    + '<div class="clo-card">' + CLO_BOTTIGLIA
    + '<b class="clo-t">' + cloEsc(c.t) + '</b>'
    + (c.perche ? '<p class="clo-s">' + cloEsc(c.perche.length > 180 ? c.perche.slice(0, 177).replace(/\s\S*$/, '') + '…' : c.perche) + '</p>' : '')
    + (c.mossa ? '<div class="clo-m"><small>La prima mossa</small><b>' + cloEsc(c.mossa) + '</b></div>' : '')
    + '<button type="button" class="clo-cta" onclick="cloSblocca()">Sbloccalo adesso</button>'
    + '<button type="button" class="clo-link" onclick="cloChiedi(false)">' + cloEsc(quando) + ' · Cerca di nuovo</button></div></section>';
}

/* ---------------------------------------------------------------- il momentum e il ponte */
function cloGiorno(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
function cloDecisioniOggi(){
  const d0 = cloGiorno(Date.now()); let n = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x && x.at >= d0) n++; }); }catch(_){ }
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; const k = new Date(); const kk = k.getFullYear() + '-' + String(k.getMonth() + 1).padStart(2, '0') + '-' + String(k.getDate()).padStart(2, '0'); n += +g[kk] || 0; }catch(_){ }
  try{ (decLog().votes || []).forEach(function(v){ if (v.at >= d0) n++; }); }catch(_){ }
  try{ const l = JSON.parse(localStorage.getItem('fl_fs_scelte') || '[]') || []; l.forEach(function(x){ if (x && x.at >= d0) n++; }); }catch(_){ }
  try{ if (typeof stLines === 'function') n += stLines('today').filter(function(r){ return /^☑/.test(String(r)); }).length; }catch(_){ }
  return n;
}
/* dalla sveglia alla prima mossa (la prima sessione di Full Focus di oggi), in minuti; null se non si sa */
function cloPartenzaMin(){
  try{
    const d0 = cloGiorno(Date.now());
    const m = (typeof SN_MEM !== 'undefined') ? SN_MEM[String(d0)] : null, n = m && m.n;
    if (typeof snNotteDi === 'function' && !m) snNotteDi(d0).catch(function(){ });
    const sveglia = n && n.ok && n.sveglia ? n.sveglia : 0; if (!sveglia) return null;
    const prime = (typeof ffHist === 'function' ? ffHist() : []).filter(function(x){ return x && x.at >= sveglia; }).map(function(x){ return (x.at || 0) - (x.min || x.minutes || 0) * 60000; }).sort(function(a, b){ return a - b; });
    const p = prime[0] || 0;
    if (!p) return Math.round((Date.now() - sveglia) / 60000) > 0 ? -Math.round((Date.now() - sveglia) / 60000) : null;
    return Math.max(0, Math.round((p - sveglia) / 60000));
  }catch(_){ return null; }
}
function cloOre(min){ min = Math.abs(Math.round(min)); if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti'; const h = Math.floor(min / 60), r = min % 60; return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + ' minuti' : ''); }
function cloMomentum(){
  const dec = cloDecisioniOggi(), part = cloPartenzaMin();
  let pos = 0.5 * Math.min(1, dec / 5);
  if (part === null) pos += 0.5 * Math.min(1, dec / 5);
  else if (part < 0) pos += 0.5 * Math.max(0, 1 - (-part - 30) / 210) * 0.5;
  else pos += 0.5 * Math.max(0, Math.min(1, 1 - (part - 30) / 210));
  return { dec: dec, part: part, pos: Math.max(0.04, Math.min(0.96, pos)) };
}
function cloPonteSvg(pos){
  const P0 = [34, 112], P1 = [160, 44], P2 = [286, 112];
  const B = function(t){ const u = 1 - t; return [u * u * P0[0] + 2 * u * t * P1[0] + t * t * P2[0], u * u * P0[1] + 2 * u * t * P1[1] + t * t * P2[1]]; };
  const p = B(pos);
  let pali = ''; for (let i = 1; i < 10; i++){ const q = B(i / 10); pali += '<path d="M' + q[0].toFixed(1) + ' ' + (q[1] - 1).toFixed(1) + 'v-15" stroke="' + (i < 5 ? '#4A6496' : '#BCE0FF') + '" stroke-width="2.4" stroke-linecap="round"/>'; }
  const av = '<g transform="translate(' + p[0].toFixed(1) + ' ' + (p[1] - 26).toFixed(1) + ')"><circle r="12" fill="#fff"/><circle r="9" fill="#E63946"/><path d="M-4 -1a4 4 0 0 1 8 0" fill="none" stroke="#fff" stroke-width="2"/><circle cy="-4" r="2.6" fill="#fff"/><path d="M0 12v8" stroke="#fff" stroke-width="2"/></g>';
  return '<svg class="clo-ponte" viewBox="0 0 320 168" aria-hidden="true"><defs>'
    + '<linearGradient id="cloPa" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3B4F7A"/><stop offset=".5" stop-color="#3F7FD0"/><stop offset="1" stop-color="#8CC6FF"/></linearGradient>'
    + '<linearGradient id="cloAc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A6BC4" stop-opacity=".55"/><stop offset="1" stop-color="#0B2550" stop-opacity=".2"/></linearGradient>'
    + '<radialGradient id="cloLu" cx="0.85" cy="0.6" r="0.5"><stop offset="0" stop-color="#8CC6FF" stop-opacity=".45"/><stop offset="1" stop-color="#8CC6FF" stop-opacity="0"/></radialGradient></defs>'
    + '<rect width="320" height="168" fill="url(#cloLu)"/>'
    + '<path d="M0 126c40-6 80 6 120 0s80-8 120-2 60 4 80 0V168H0z" fill="url(#cloAc)"/>'
    + '<path d="M0 134c30 4 60-4 90 0M120 140c30 4 60-4 90 0M220 132c30 4 60-4 100 0" stroke="#8CC6FF" stroke-opacity=".35" stroke-width="1.5" fill="none"/>'
    + '<path d="M0 108h40l8 20H0z" fill="#22355E"/><path d="M8 128l6-14 6 14M26 128l4-10 5 10" stroke="#4A6496" stroke-width="1.5" fill="none"/>'
    + '<path d="M280 108h40v20h-48z" fill="#2A6BC4"/><path d="M292 108V84" stroke="#fff" stroke-width="2"/><path d="M292 84h14l-4 5 4 5h-14z" fill="#fff"/>'
    + '<path d="M' + P0.join(' ') + 'Q' + P1.join(' ') + ' ' + P2.join(' ') + '" fill="none" stroke="url(#cloPa)" stroke-width="9" stroke-linecap="round"/>'
    + '<path d="M60 112Q160 74 260 112" fill="none" stroke="url(#cloPa)" stroke-opacity=".5" stroke-width="3"/>'
    + pali + av + '</svg>';
}
function cloPonteSlideHtml(){
  const m = cloMomentum();
  const dove = m.pos < 0.35 ? 'Sei dalla parte della paura' : (m.pos < 0.7 ? 'Sei a metà del ponte' : 'Sei quasi dall’altra parte');
  const riga = (m.dec === 1 ? 'Oggi hai preso 1 decisione' : 'Oggi hai preso ' + m.dec + ' decisioni')
    + (m.part === null ? '.' : (m.part < 0 ? ', e dalla sveglia non hai ancora fatto la prima mossa: ' + cloOre(m.part) + '.' : '. Dalla sveglia alla prima mossa: ' + cloOre(m.part) + '.'));
  return '<div class="nvp-rs clo-rs"><b class="nvp-rit-t">' + cloEsc(dove) + '<button type="button" class="nvp-i" onclick="cloPonteInfo()" aria-label="Come si attraversa il ponte"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v6M12 7h.01"/></svg></button></b>'
    + '<div class="clo-pw">' + cloPonteSvg(m.pos) + '<span class="clo-sx">Paura<br>Dubbio<br>Rimando</span><span class="clo-dx">Fede<br>Velocità<br>Successo</span></div>'
    + '<p class="nvp-rit-s">' + cloEsc(riga) + '</p></div>';
}
function cloPonteInfo(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="clo-info"><b>Il ponte si attraversa decidendo</b>'
    + '<p>A sinistra c’è la scarsità: paura, dubbio, rimando. A destra l’abbondanza: fede, velocità, successo.</p>'
    + '<p>Ti sposta in avanti <b>ogni decisione presa</b>: una tappa fatta, una sessione partita, una riga del foglio chiusa.</p>'
    + '<p>E conta <b>quanto ci metti</b>: dalla sveglia alla prima mossa. Più è breve, più vai avanti.</p></div>');
}
/* la risposta dell'agente passa di qui (dream-storia.js avvolge agMsgHtml): se c'e' il collo, si tiene */
(function(){
  const prova = function(){
    if (typeof agMsgHtml !== 'function'){ setTimeout(prova, 800); return; }
    const orig = window.agMsgHtml;
    window.agMsgHtml = function(m){ try{ cloSalvaDa(m); }catch(_){ } return orig.apply(this, arguments); };
  };
  setTimeout(prova, 1500);
  const st = document.createElement('style');
  st.textContent = ''
    + '.clo-p{margin:28px 0 4px;text-align:center}.clo-card{margin-top:14px;padding:20px 18px 16px;border-radius:22px;background:linear-gradient(170deg,rgba(140,198,255,.16),rgba(255,255,255,.05));border:1px solid rgba(140,198,255,.28)}'
    + '.clo-bt{display:block;width:84px;height:84px;margin:0 auto 10px;filter:drop-shadow(0 8px 18px rgba(0,117,227,.45))}'
    + '.clo-t{display:block;font:800 21px/1.25 var(--font-display);color:#fff}.clo-s{margin:10px 0 0;font:500 14px/1.5 var(--font-body);color:#BFD3EC}'
    + '.clo-m{margin:16px 0 0;padding:12px 14px;border-radius:16px;background:rgba(0,0,0,.18);text-align:left}.clo-m small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.clo-m b{display:block;margin-top:4px;font:700 15px/1.4 var(--font-body);color:#fff}'
    + '.clo-cta{display:block;width:100%;margin-top:16px;padding:14px;border:0;border-radius:16px;background:#fff;color:#001E44;font:800 15.5px var(--font-body);cursor:pointer}'
    + '.clo-link{margin-top:10px;padding:6px;border:0;background:none;color:#8CC6FF;font:700 13px var(--font-body);cursor:pointer}'
    + '.clo-rs .nvp-rit-t{display:flex!important;align-items:center;justify-content:center;gap:8px}.clo-pw{position:relative;margin:6px -4px 2px}.clo-ponte{display:block;width:100%;height:auto}'
    + '.clo-sx,.clo-dx{position:absolute;top:4px;font:800 10.5px/1.3 var(--font-body);letter-spacing:.06em;text-transform:uppercase}.clo-sx{left:4px;text-align:left;color:#8FA3C8}.clo-dx{right:4px;text-align:right;color:#BCE0FF}'
    + '.nvs-ctl .nvs-ctl-h{margin:0 0 6px;font:800 23px/1.2 var(--font-display);color:var(--navy);text-align:center}'
    + '.nvp-rit-link{display:block;margin:12px auto 0;padding:6px 10px;border:0;background:none;color:#8CC6FF;font:700 13px var(--font-body);cursor:pointer}'
    /* il foglio dei sette giorni come linea del tempo */
    + '.prc-tl{position:relative;display:flex;flex-direction:column;gap:18px;padding-left:26px}.prc-tl::before{content:"";position:absolute;left:8px;top:14px;bottom:14px;width:2px;border-radius:2px;background:linear-gradient(180deg,#BCE0FF,#0075E3)}'
    + '.prc-tl .prc-r{position:relative;display:grid!important;grid-template-columns:28px 1fr;column-gap:10px;align-items:start;padding:14px 16px!important;margin:0!important}.prc-tl .prc-r[hidden]{display:none!important}'
    + '.prc-tl .prc-r::before{content:"";position:absolute;left:-23px;top:20px;width:12px;height:12px;border-radius:50%;background:#fff;border:3px solid #0075E3;box-sizing:border-box}'
    + '.prc-tl .prc-r > i{grid-column:2;justify-self:start;margin-top:8px}.prc-tl .prc-r p{margin:0;line-height:1.45}'
    + '.clo-info{padding:6px 4px 10px;text-align:center}.clo-info b:first-child{display:block;margin-bottom:14px;font:800 19px var(--font-display);color:var(--navy)}.clo-info p{margin:0 0 12px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}.clo-info p b{color:var(--navy)}';
  document.head.appendChild(st);
})();
