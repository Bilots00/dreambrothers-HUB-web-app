/* ===========================================================================================
   IL COLLO DI BOTTIGLIA E IL PONTE (0.9.335)

   Andrea: "prima di controllare la rotta, il Genio deve trovare il collo di bottiglia che blocca il
   progresso verso il sogno: la cosa che, se risolta, sblocca tutto o rende tutto il resto piu' facile,
   inutile o superfluo". La richiesta parte dalla slide "Com'e' andata oggi" o dalla pill dell'agente;
   il tuo agente comincia la risposta con una riga "COLLO DI BOTTIGLIA: ..." e da quella riga l'app
   tiene l'ultimo trovato e lo mostra in Dream, prima del tuo ritmo.

   Il ponte (al posto del grafico "Stai rallentando"): dalla paura e dal dubbio, a sinistra, alla fede
   e alla velocita', a destra. Dove sei sul ponte lo dice il tuo momentum: quante decisioni prendi oggi
   (tappe fatte, sessioni partite, righe del foglio chiuse, scelte del Genio) e quanto ci metti dalla
   sveglia alla prima mossa. Prefisso clo-.
   =========================================================================================== */
const CLO_K = 'fl_collo';
const CLO_RICHIESTA = 'Aiutami a trovare il mio collo di bottiglia: l’unica cosa che, se la sblocco, rende tutto il resto più facile. Prima fammi le domande che ti servono.';
/* il formato della risposta lo chiede il brief (agBrief, agente.js), non il messaggio: a schermo resta una frase sola */
/* 0.9.340, Andrea: "il Genio trova il collo di bottiglia sbagliato: deduce tutto da solo, senza fare nessuna domanda e senza nessuna
   indagine". Adesso indaga: una domanda per messaggio, partendo da quello che vede nei dati e chiedendo se e' vero; solo dopo
   le risposte scrive il collo. */
const CLO_FORMATO = [
  'SE TI CHIEDE IL COLLO DI BOTTIGLIA o di controllare la rotta: NON dedurlo da solo dai dati.',
  'Prima fai un’indagine, come un medico: una sola domanda per messaggio, al massimo tre messaggi.',
  'Ogni domanda è breve, con 2-4 risposte possibili in un elenco numerato, e parte da quello che vedi nei dati chiedendo se è vero e perché succede.',
  'Non scrivere il collo finché non hai le risposte.',
  'Quando le hai, scrivi una riga "COLLO DI BOTTIGLIA: ..." (al massimo 10 parole), una riga "PRIMA MOSSA: ..." (al massimo 14 parole) e il perché in due frasi.',
  'Chiudi lì. NON scrivere una roadmap e NON mettere il blocco json del piano quando ti chiede il collo.',
  'In fondo chiedi in una riga se vuole che tu ricalcoli la roadmap partendo da quel collo.',
  /* 0.9.343, Andrea: "per chi ha l'agente, che sia l'agente a fare la radiografia di dove e' andata la sua attenzione". L'app la disegna
     come palline dentro alla bottiglia */
  'Poi una riga "ATTENZIONE: ..." con 3-6 voci di dove è andato davvero il suo tempo nelle ultime 24 ore.',
  'Cose concrete, non categorie, nel formato "emoji nome=minuti" separate da punto e virgola.',
  'Un punto esclamativo davanti alla sua priorità (il lavoro sul sogno).',
  'Una tilde davanti alle voci neutre (sonno, pasti, lavoro necessario).'
].join(' ');
function cloEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function cloLeggi(){ try{ const o = JSON.parse(localStorage.getItem(CLO_K) || 'null'); return o && o.t ? o : null; }catch(_){ return null; } }

/* dalla risposta del tuo agente: la riga del collo, la prima mossa, il perche' */
function cloDaTesto(testo, at){
  const t = String(testo || '').replace(/\*\*/g, '');
  const m = /COLLO DI BOTTIGLIA\s*:\s*([^\n]+)/i.exec(t); if (!m) return null;
  const mo = /PRIMA MOSSA\s*:\s*([^\n]+)/i.exec(t);
  const resto = t.split('\n').filter(function(r){ return r.trim() && !/COLLO DI BOTTIGLIA\s*:|PRIMA MOSSA\s*:|ATTENZIONE\s*:/i.test(r); }).join(' ').replace(/\s+/g, ' ').trim();
  const pulisci = function(s){ return String(s || '').replace(/^[\s"*_]+|[\s"*_]+$/g, '').trim(); };
  return { t: pulisci(m[1]).slice(0, 140), mossa: mo ? pulisci(mo[1]).slice(0, 160) : '', perche: resto.slice(0, 260), att: cloAttDaTesto(t), at: at || Date.now() };
}
function cloSalvaDa(m){
  try{
    if (!m || m.direzione === 'in' || !m.testo) return;
    const at = m.at || Date.parse(m.creato || m.createdAt || '') || Date.now();
    const c = cloDaTesto(m.testo, at); if (!c) return;
    const prima = cloLeggi(); if (prima && prima.at >= c.at && prima.t === c.t) return;
    if (prima && prima.at > c.at) return;
    localStorage.setItem(CLO_K, JSON.stringify(c));
    setTimeout(function(){ try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ } try{ if (typeof nvpRiempi === 'function' && typeof nvpRitmoHtml === 'function') nvpRiempi('nvpRitmo', nvpRitmoHtml()); }catch(_){ } }, 50);
  }catch(_){ }
}
function cloChiedi(diretto){
  try{ localStorage.setItem('fl_ctl_giorno', new Date().toDateString()); }catch(_){ }
  if (typeof agApri !== 'function') return;
  if (diretto && typeof agNuovaConversazione === 'function'){ agNuovaConversazione(CLO_RICHIESTA, { titolo: 'Il mio collo di bottiglia' }); return; }
  agApri();
  /* la richiesta si scrive nel campo: parte solo con invio */
  setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza(CLO_RICHIESTA); }catch(_){ } }, 300);
}
function cloSblocca(){
  const c = cloLeggi(); if (!c) return;
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  try{ if (typeof ffPref === 'function'){ ffPref().intent = (c.mossa || c.t).slice(0, 120); if (typeof ffSavePref === 'function') ffSavePref(); } }catch(_){ }
  try{ goId('s-fullfocus'); if (typeof ffPaint === 'function') ffPaint(); }catch(_){ }
}
const CLO_BOTTIGLIA = '<svg class="clo-bt" viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="cloV" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8CC6FF"/><stop offset="1" stop-color="#0075E3"/></linearGradient></defs>'
  + '<path d="M48 22h24v16c0 6 18 12 18 30v34a10 10 0 0 1-10 10H40a10 10 0 0 1-10-10V68c0-18 18-24 18-30z" fill="url(#cloV)" opacity=".9"/>'
  + '<path d="M38 70h44v30a6 6 0 0 1-6 6H44a6 6 0 0 1-6-6z" fill="#fff" opacity=".18"/>'
  + '<circle cx="50" cy="88" r="5" fill="#fff"/><circle cx="64" cy="94" r="5" fill="#fff" opacity=".85"/><circle cx="70" cy="80" r="5" fill="#fff" opacity=".7"/><circle cx="56" cy="76" r="5" fill="#fff" opacity=".8"/>'
  + '<circle cx="60" cy="40" r="5" fill="#fff"/><circle cx="60" cy="50" r="4" fill="#fff" opacity=".7"/>'
  + '<rect x="45" y="8" width="30" height="16" rx="4" fill="#E63946"/><rect x="45" y="8" width="30" height="5" rx="2.5" fill="#fff" opacity=".35"/></svg>';
/* 0.9.340, Andrea: "il collo di bottiglia sta sopra al tuo ritmo invece di essere una slide del carosello, e ha troppo testo":
   ora e' la prima slide del ritmo, con il collo, la prima mossa e un pulsante. Il perche' resta nella chat. */
/* 0.9.343, Andrea: "non voglio tutto quel testo, e a volte al centro e a volte a sinistra. Voglio un'immagine chiara della bottiglia,
   messa in orizzontale, che mostri dove sta andando la sua attenzione e dove dovrebbe andare: le app dentro la bottiglia, e nel collo
   la priorita'". Dentro la bottiglia le app di oggi (piu' tempo, pallina piu' grande; rosse quelle che distraggono), nel collo passa
   il sogno. Con Premium e l'agente, le palline sono la radiografia che ha fatto l'agente (riga ATTENZIONE). Tutto centrato; il collo
   trovato, la prima mossa e il perche' stanno nella (i). */
function cloSlideHtml(){
  const c = cloLeggi();
  const conDati = !!(CLO_USO.apps || (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps));
  if (!c && !conDati) return '';
  try{ cloUsoCarica(); }catch(_){ }
  const pt = cloBottParti();
  const quando = c ? (function(){ const d = Math.floor((Date.now() - c.at) / 86400000); return d <= 0 ? 'Trovato oggi' : (d === 1 ? 'Trovato ieri' : 'Trovato ' + d + ' giorni fa'); })() : '';
  return '<div class="nvp-rs clo-sl clo-sl2"><p class="nvp-rit-k nvp-rs-k clo-sl-k"><span>' + CLO_BOTTIGLIA + '</span> Il tuo collo di bottiglia'
    /* 0.9.353, Andrea: "due (i) nella stessa slide, e quella del titolo e' brutta: massimo una (i) per slide". Resta una sola (i), quella
       bella, accanto al titolo; il problema trovato si apre toccandolo (o toccando la pallina rossa) */
    + '<button type="button" class="clo-i2 clo-i2-t" onclick="cloInfoApri()" aria-label="Come si legge la bottiglia">i</button></p>'
    + '<div class="clo-bott' + (pt.libera ? ' libera' : '') + '" data-clo="1">' + cloBottSvg() + '<div class="clo-sg">' + pt.sg + '</div><div class="clo-pp">' + pt.pp + '</div></div>'
    + '<div class="clo-leg" data-clo-leg="1">' + pt.leg + '</div>'
    + (c ? '<button type="button" class="clo-cta" data-clo-cta="1" onclick="cloCta()">' + cloCtaTesto(pt) + '</button><button type="button" class="clo-link" onclick="cloChiedi(false)">' + cloEsc(quando) + '. Cercalo di nuovo</button>'
         : '<button type="button" class="clo-cta" onclick="cloChiedi(false)">Trova il mio collo di bottiglia</button>')
    + '</div>';
}
/* il pannello di prima (non piu' usato in Dream) */
function cloPannelloHtml(){
  const c = cloLeggi(); if (!c) return '';
  const quando = (function(){ const d = Math.floor((Date.now() - c.at) / 86400000); return d <= 0 ? 'Trovato oggi' : (d === 1 ? 'Trovato ieri' : 'Trovato ' + d + ' giorni fa'); })();
  return '<section class="clo-p"><p class="nvp-rit-k">Il tuo collo di bottiglia</p>'
    + '<div class="clo-card">' + CLO_BOTTIGLIA
    + '<b class="clo-t">' + cloEsc(c.t) + '</b>'
    + (c.perche ? '<p class="clo-s">' + cloEsc(c.perche.length > 180 ? c.perche.slice(0, 177).replace(/\s\S*$/, '') + '…' : c.perche) + '</p>' : '')
    + (c.mossa ? '<div class="clo-m"><small>La prima mossa</small><b>' + cloEsc(c.mossa) + '</b></div>' : '')
    + '<button type="button" class="clo-cta" onclick="cloSblocca()">Sbloccalo adesso</button>'
    + '<button type="button" class="clo-link" onclick="cloChiedi(false)">' + cloEsc(quando) + ' · Cerca di nuovo</button></div></section>';
}

/* ---------------------------------------------------------------- il momentum e il ponte */
function cloGiorno(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
function cloDecisioniOggi(){
  const d0 = cloGiorno(Date.now()); let n = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x && x.at >= d0) n++; }); }catch(_){ }
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; const k = new Date(); const kk = k.getFullYear() + '-' + String(k.getMonth() + 1).padStart(2, '0') + '-' + String(k.getDate()).padStart(2, '0'); n += +g[kk] || 0; }catch(_){ }
  try{ (decLog().votes || []).forEach(function(v){ if (v.at >= d0) n++; }); }catch(_){ }
  try{ const l = JSON.parse(localStorage.getItem('fl_fs_scelte') || '[]') || []; l.forEach(function(x){ if (x && x.at >= d0) n++; }); }catch(_){ }
  try{ if (typeof stLines === 'function') n += stLines('today').filter(function(r){ return /^☑/.test(String(r)); }).length; }catch(_){ }
  try{ n += cloMessaggi().filter(function(t){ return t >= d0; }).length; }catch(_){ }
  cloDecSegna(n);
  return n;
}
/* 0.9.348, Andrea: "le decisioni sono tutto: il Genio e l'agente devono tenerne conto piu' di ogni altra cosa, anche come slancio (i giorni
   di fila con decisioni), nella revisione, nel diario di viaggio, e anche quanto ci metti a mandare un messaggio alla tua AI: se cerchi il
   prompt perfetto sei lento. E la data d'arrivo deve accorgersene". Qui: lo storico per giorno, la serie, il tempo medio per scrivere */
const CLO_DEC_K = 'fl_decisioni_giorni', CLO_AI_K = 'fl_ai_tempi';
function cloDecKey(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function cloDecStoria(){ try{ return JSON.parse(localStorage.getItem(CLO_DEC_K) || '{}') || {}; }catch(_){ return {}; } }
function cloDecSegna(n){
  try{ const s = cloDecStoria(), k = cloDecKey(Date.now()); if (s[k] === n) return; if (!(n < (s[k] || 0))) s[k] = n; const l = Object.keys(s).sort(); while (l.length > 120) delete s[l.shift()]; localStorage.setItem(CLO_DEC_K, JSON.stringify(s)); }catch(_){ }
}
function cloDecSerie(){
  const s = cloDecStoria(); let n = 0;
  for (let i = s[cloDecKey(Date.now())] > 0 ? 0 : 1; i < 400; i++){ if ((s[cloDecKey(Date.now() - i * 86400000)] || 0) > 0) n++; else break; }
  return n;
}
document.addEventListener('input', function(e){ const t = e.target; if (t && t.id === 'agTesto'){ if (!t.value.trim()) window.__cloScriviDa = 0; else if (!window.__cloScriviDa) window.__cloScriviDa = Date.now(); } }, true);
function cloAiTempi(){ try{ return JSON.parse(localStorage.getItem(CLO_AI_K) || '[]') || []; }catch(_){ return []; } }
function cloAiMedia(){ const l = cloAiTempi().slice(-20).map(function(x){ return x.s; }).sort(function(a, b){ return a - b; }); return l.length ? l[Math.floor(l.length / 2)] : null; }
function cloDecDati(){
  const m = cloMomentum(), media = cloAiMedia();
  let lista = []; try{ lista = cloDecisioniLista().map(function(x){ return (x.at ? cloOraHM(x.at) + ' ' : '') + x.t; }).slice(0, 14); }catch(_){ }
  const s = cloDecStoria(), sett = []; for (let i = 6; i >= 0; i--) sett.push(s[cloDecKey(Date.now() - i * 86400000)] || 0);
  return { oggi: m.dec, serie: cloDecSerie(), settimana: sett, partenzaMin: m.part, lista: lista, secondiPerScrivereAllAI: media };
}
function cloDecisioniPerAgente(){
  try{
    const d = cloDecDati();
    return 'LE DECISIONI (il parametro piu\' importante, guardalo per primo): oggi ' + d.oggi + ' decisioni' + (d.lista.length ? ' (' + d.lista.join('; ') + ')' : '')
      + '. Giorni di fila con almeno una decisione: ' + d.serie + '. Ultimi 7 giorni: ' + d.settimana.join(', ') + '.'
      + (d.partenzaMin === null ? '' : (d.partenzaMin < 0 ? ' Dalla sveglia sono passati ' + cloOre(d.partenzaMin) + ' senza la prima mossa.' : ' Dalla sveglia alla prima mossa: ' + cloOre(d.partenzaMin) + '.'))
      + (d.secondiPerScrivereAllAI ? ' Tempo medio per scrivere e mandare un messaggio alla sua AI: ' + Math.round(d.secondiPerScrivereAllAI) + ' secondi.' : '');
  }catch(_){ return ''; }
}
/* 0.9.341, Andrea: "anche mandare un messaggio alla propria intelligenza artificiale e' una decisione: deve contare nella
   velocita' con cui prendi le decisioni". Ogni messaggio mandato al tuo agente o al Genio lascia l'orario qui: conta come
   decisione e, se e' la prima cosa fatta dopo la sveglia, come prima mossa. */
const CLO_MSG_K = 'fl_decisioni_msg';
/* gli orari (numeri); dal 0.9.347 accanto c'e' fl_decisioni_msg_t con due parole di cosa diceva il messaggio */
function cloMessaggi(){ try{ return (JSON.parse(localStorage.getItem(CLO_MSG_K) || '[]') || []).map(function(x){ return typeof x === 'number' ? x : (x && x.at) || 0; }).filter(Boolean); }catch(_){ return []; } }
function cloMessaggiTesti(){ try{ return JSON.parse(localStorage.getItem(CLO_MSG_K + '_t') || '{}') || {}; }catch(_){ return {}; } }
function cloMessaggioMandato(testo){
  try{
    const ora = Date.now(), d0 = cloGiorno(ora - 86400000);
    const l = cloMessaggi().filter(function(t){ return t >= d0; }); l.push(ora); localStorage.setItem(CLO_MSG_K, JSON.stringify(l.slice(-200)));
    /* quanto ci ha messo a scrivere il messaggio (dal primo tasto all'invio) */
    try{ if (window.__cloScriviDa){ const sec = (ora - window.__cloScriviDa) / 1000; window.__cloScriviDa = 0; if (sec > 1 && sec < 3600){ const t = cloAiTempi(); t.push({ at: ora, s: Math.round(sec) }); localStorage.setItem(CLO_AI_K, JSON.stringify(t.slice(-60))); } } }catch(_){ }
    if (typeof testo === 'string' && testo.trim()){
      const m = cloMessaggiTesti(); m[ora] = testo.replace(/\s+/g, ' ').trim().slice(0, 70);
      Object.keys(m).forEach(function(k){ if (+k < d0) delete m[k]; });
      localStorage.setItem(CLO_MSG_K + '_t', JSON.stringify(m));
    }
  }catch(_){ }
}
(function(){
  const avvolgi = function(nome){
    const o = window[nome]; if (typeof o !== 'function' || o.__clo) return false;
    const n = function(){ try{ cloMessaggioMandato(arguments[0]); }catch(_){ } return o.apply(this, arguments); };
    n.__clo = true; window[nome] = n; return true;
  };
  const prova = function(k){ const a = avvolgi('agInvia'), b = avvolgi('cvInvia'); if ((!a || !b) && k < 20) setTimeout(function(){ prova(k + 1); }, 1000); };
  setTimeout(function(){ prova(0); }, 1200);
})()
/* 0.9.347, Andrea: "dice 'oggi hai preso 4 decisioni', ma se voglio sapere quali e a che ora non posso. Decisioni vuol dire tutto e
   niente". L'elenco delle stesse decisioni che conta cloDecisioniOggi, con l'ora quando c'e', in un foglio riassuntivo */
function cloOraHM(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function cloDecisioniLista(giorno){
  const d0 = cloGiorno(giorno || Date.now()), d1 = d0 + 86400000, oggi = d0 === cloGiorno(Date.now()), out = [];
  const kk0 = cloDecKey(d0);
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x && x.at >= d0 && x.at < d1){ const min = Math.round(+(x.min || x.minutes || 0)); out.push({ at: x.start || x.at, ico: x.meditazione ? '🧘' : '🎯', t: (x.meditazione ? 'Hai meditato ' : 'Hai fatto ' + min + ' minuti di Full Focus') + (x.meditazione ? min + ' minuti' : '') + (x.intent ? ': ' + String(x.intent).slice(0, 60) : (x.tag ? ' (' + x.tag + ')' : '')) }); } }); }catch(_){ }
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; const n = +g[kk0] || 0; if (n > 0) out.push({ at: 0, ico: '🗺️', t: n === 1 ? 'Hai fatto 1 tappa della mappa' : 'Hai fatto ' + n + ' tappe della mappa', n: n }); }catch(_){ }
  try{ (decLog().votes || []).forEach(function(v){ if (v.at >= d0 && v.at < d1){
    const t = v.kind === 'strict' ? (v.yes ? 'Hai spento la modalità severa' : 'Hai tenuto accesa la modalità severa') : v.kind === 'rate' ? 'Hai dato il tuo voto all’app' : (v.yes ? 'Hai scelto di sbloccare un’app' : 'Hai resistito alla voglia di sbloccare un’app');
    out.push({ at: v.at, ico: v.yes && v.kind !== 'rate' ? '🔓' : '🛡️', t: t }); } }); }catch(_){ }
  try{ const l = JSON.parse(localStorage.getItem('fl_fs_scelte') || '[]') || []; l.forEach(function(x){ if (x && x.at >= d0 && x.at < d1) out.push({ at: x.at, ico: '🔀', t: x.t ? 'Hai scelto: ' + String(x.t).slice(0, 60) : 'Hai fatto una scelta fra due strade' }); }); }catch(_){ }
  try{ if (oggi && typeof stLines === 'function') stLines('today').filter(function(r){ return /^☑/.test(String(r)); }).forEach(function(r){ out.push({ at: 0, ico: '✅', t: 'Hai spuntato: ' + String(r).replace(/^☑\s*/, '').slice(0, 70) }); }); }catch(_){ }
  try{ const tx = cloMessaggiTesti(); cloMessaggi().filter(function(t){ return t >= d0 && t < d1; }).forEach(function(t){ out.push({ at: t, ico: '💬', t: tx[t] ? 'Hai scritto al tuo agente: "' + tx[t] + '"' : 'Hai scritto al tuo agente' }); }); }catch(_){ }
  return out.sort(function(a, b){ return (a.at || 9e15) - (b.at || 9e15); });
}
function cloDecisioniApri(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const l = cloDecisioniLista(), m = cloMomentum();
  const part = m.part === null ? '' : (m.part < 0 ? 'Dalla sveglia sono passati ' + cloOre(m.part) + ' e la prima mossa non c’è ancora.' : 'Dalla sveglia alla prima mossa sono passati ' + cloOre(m.part) + '.');
  const righe = l.length ? l.map(function(x){ return '<div class="clo-dec-r"><span class="clo-dec-o">' + (x.at ? cloOraHM(x.at) : 'oggi') + '</span><span class="clo-dec-i" aria-hidden="true">' + x.ico + '</span><p>' + cloEsc(x.t) + '</p></div>'; }).join('')
    : '<p class="clo-dec-vuoto">Oggi nessuna decisione ancora. Una sessione di Full Focus o una tappa della mappa sono la prima.</p>';
  inSheet('<div class="en-foglio clo-dec"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<h3>Le decisioni di oggi</h3><b class="clo-dec-n">' + m.dec + '</b>' + (part ? '<p class="clo-dec-p">' + cloEsc(part) + '</p>' : '')
    + '<div class="clo-dec-l">' + righe + '</div>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button>'
    /* 0.9.350, Andrea: "le decisioni anche nella Timeline, con una scheda loro": gli altri giorni stanno li' */
    + '<button type="button" class="clo-dec-tl" onclick="inSheetChiudi();if(typeof tlOpen===\'function\')tlOpen(0,\'insights\',\'decisioni\')">Vedi le decisioni degli altri giorni</button></div>');
}
(function(){ const st = document.createElement('style'); st.textContent = '.clo-dec{text-align:center}.clo-dec h3{margin:0 0 4px}.clo-dec-n{display:block;font:900 40px/1.1 var(--font-display);color:#0075E3;margin:0 0 6px}.clo-dec-p{margin:0 0 18px;font:500 14px/1.5 var(--font-body);color:var(--muted)}'
  + '.clo-dec-l{display:flex;flex-direction:column;gap:8px;margin:0 0 22px;text-align:left;max-height:46vh;overflow:auto}.clo-dec-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--bg,#F0FBFF);border:1px solid var(--line)}body.dark .clo-dec-r{background:#12203A;border-color:#22345A}'
  + '.clo-dec-o{flex:none;min-width:46px;padding:4px 8px;border-radius:99px;background:#0075E3;color:#fff;font:800 12px var(--font-body);text-align:center}.clo-dec-i{flex:none;font-size:20px}.clo-dec-r p{margin:0;font:600 14px/1.4 var(--font-body);color:var(--navy)}body.dark .clo-dec-r p{color:#fff}.clo-dec-vuoto{font:500 14px/1.5 var(--font-body);color:var(--muted)}'
  + '.clo-dec-tl{display:block;margin:14px auto 0;border:0;background:none;color:#0075E3;font:800 14px var(--font-body);cursor:pointer}body.dark .clo-dec-tl{color:#8CC6FF}'
  + '.clo-dec-link{display:inline-block;margin:10px auto 0;padding:6px 12px;border:0;background:none;color:#8CC6FF;font:800 13.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}'; document.head.appendChild(st); })();
/* dalla sveglia alla prima mossa (la prima sessione di Full Focus di oggi), in minuti; null se non si sa */
function cloPartenzaMin(){
  try{
    const d0 = cloGiorno(Date.now());
    const m = (typeof SN_MEM !== 'undefined') ? SN_MEM[String(d0)] : null, n = m && m.n;
    if (typeof snNotteDi === 'function' && !m) snNotteDi(d0).catch(function(){ });
    const sveglia = n && n.ok && n.sveglia ? n.sveglia : 0; if (!sveglia) return null;
    const prime = (typeof ffHist === 'function' ? ffHist() : []).filter(function(x){ return x && x.at >= sveglia; }).map(function(x){ return (x.at || 0) - (x.min || x.minutes || 0) * 60000; })
      .concat(cloMessaggi().filter(function(t){ return t >= sveglia; })).sort(function(a, b){ return a - b; });
    const p = prime[0] || 0;
    if (!p) return Math.round((Date.now() - sveglia) / 60000) > 0 ? -Math.round((Date.now() - sveglia) / 60000) : null;
    return Math.max(0, Math.round((p - sveglia) / 60000));
  }catch(_){ return null; }
}
function cloOre(min){ min = Math.abs(Math.round(min)); if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti'; const h = Math.floor(min / 60), r = min % 60; return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + ' minuti' : ''); }
function cloMomentum(){
  const dec = cloDecisioniOggi(), part = cloPartenzaMin();
  /* 0.9.348: lo slancio conta anche i giorni di fila con decisioni (fino a una spinta in piu' del 15% dopo una settimana) */
  let pos = 0.5 * Math.min(1, dec / 5) + Math.min(0.15, (cloDecSerie() || 0) * 0.02);
  if (part === null) pos += 0.5 * Math.min(1, dec / 5);
  else if (part < 0) pos += 0.5 * Math.max(0, 1 - (-part - 30) / 210) * 0.5;
  else pos += 0.5 * Math.max(0, Math.min(1, 1 - (part - 30) / 210));
  return { dec: dec, part: part, pos: Math.max(0.04, Math.min(0.96, pos)) };
}
function cloPonteSvg(pos){
  const P0 = [34, 112], P1 = [160, 44], P2 = [286, 112];
  const B = function(t){ const u = 1 - t; return [u * u * P0[0] + 2 * u * t * P1[0] + t * t * P2[0], u * u * P0[1] + 2 * u * t * P1[1] + t * t * P2[1]]; };
  const p = B(pos);
  let pali = ''; for (let i = 1; i < 10; i++){ const q = B(i / 10); pali += '<path d="M' + q[0].toFixed(1) + ' ' + (q[1] - 1).toFixed(1) + 'v-15" stroke="' + (i < 5 ? '#4A6496' : '#BCE0FF') + '" stroke-width="2.4" stroke-linecap="round"/>'; }
  /* 0.9.342, Andrea: "il puntino rosso sul ponte sembra un cartello stradale, non si capisce che sei tu". Il segnaposto delle
     mappe con la persona dentro, l'alone che pulsa sul ponte, e la scritta TU */
  const av = '<g transform="translate(' + p[0].toFixed(1) + ' ' + (p[1] - 4).toFixed(1) + ')">'
    + '<ellipse class="clo-alone" cx="0" cy="2" rx="14" ry="5" fill="#8CC6FF"/>'
    + '<path d="M0 0C-5-9-15-15-15-26a15 15 0 1 1 30 0C15-15 5-9 0 0z" fill="#E63946" stroke="#fff" stroke-width="2.5"/>'
    + '<circle cy="-30" r="4.6" fill="#fff"/><path d="M-7.5-17.5a7.5 6.5 0 0 1 15 0z" fill="#fff"/>'
    + '<rect x="-17" y="-62" width="34" height="19" rx="9.5" fill="#fff"/><text x="0" y="-48.5" text-anchor="middle" font-size="12.5" font-weight="800" font-family="Poppins,Arial,sans-serif" fill="#001E44">TU</text></g>';
  return '<svg class="clo-ponte" viewBox="0 0 320 168" aria-hidden="true"><defs>'
    + '<linearGradient id="cloPa" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3B4F7A"/><stop offset=".5" stop-color="#3F7FD0"/><stop offset="1" stop-color="#8CC6FF"/></linearGradient>'
    + '<linearGradient id="cloAc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A6BC4" stop-opacity=".55"/><stop offset="1" stop-color="#0B2550" stop-opacity=".2"/></linearGradient>'
    + '<radialGradient id="cloLu" cx="0.85" cy="0.6" r="0.5"><stop offset="0" stop-color="#8CC6FF" stop-opacity=".45"/><stop offset="1" stop-color="#8CC6FF" stop-opacity="0"/></radialGradient></defs>'
    + '<rect width="320" height="168" fill="url(#cloLu)"/>'
    + '<path d="M0 126c40-6 80 6 120 0s80-8 120-2 60 4 80 0V168H0z" fill="url(#cloAc)"/>'
    + '<path d="M0 134c30 4 60-4 90 0M120 140c30 4 60-4 90 0M220 132c30 4 60-4 100 0" stroke="#8CC6FF" stroke-opacity=".35" stroke-width="1.5" fill="none"/>'
    + '<path d="M0 108h40l8 20H0z" fill="#22355E"/><path d="M8 128l6-14 6 14M26 128l4-10 5 10" stroke="#4A6496" stroke-width="1.5" fill="none"/>'
    + '<path d="M280 108h40v20h-48z" fill="#2A6BC4"/><path d="M292 108V84" stroke="#fff" stroke-width="2"/><path d="M292 84h14l-4 5 4 5h-14z" fill="#fff"/>'
    + '<path d="M' + P0.join(' ') + 'Q' + P1.join(' ') + ' ' + P2.join(' ') + '" fill="none" stroke="url(#cloPa)" stroke-width="9" stroke-linecap="round"/>'
    + '<path d="M60 112Q160 74 260 112" fill="none" stroke="url(#cloPa)" stroke-opacity=".5" stroke-width="3"/>'
    + pali + av + '</svg>';
}
function cloPonteSlideHtml(){
  const m = cloMomentum();
  const dove = m.pos < 0.35 ? 'Sei dalla parte della paura' : (m.pos < 0.7 ? 'Sei a metà del ponte' : 'Sei quasi dall’altra parte');
  /* 0.9.340, Andrea: "dopo i due punti si va a capo" */
  const riga = (m.dec === 1 ? 'Oggi hai preso 1 decisione' : 'Oggi hai preso ' + m.dec + ' decisioni')
    + (m.part === null ? '.' : (m.part < 0 ? '. Sono passati ' + cloOre(m.part) + ' dalla sveglia e non hai ancora fatto la prima mossa.' : '. Dalla sveglia alla prima mossa sono passati ' + cloOre(m.part) + '.'))
    + (function(){ const s = cloDecSerie(); return s >= 2 ? ' Prendi decisioni da ' + s + ' giorni di fila: stai prendendo slancio.' : ''; })();
  /* 0.9.350, Andrea: "la (i) va sul titolo Il tuo ritmo, non sulla frase; e manca un'emoji che dica quanto vai veloce" */
  return '<div class="nvp-rs clo-rs"><p class="nvp-rit-k nvp-rs-k clo-sl-k"><span aria-hidden="true">🏃</span> Il tuo ritmo<button type="button" class="nvp-i" onclick="cloPonteInfo()" aria-label="Come si attraversa il ponte"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v6M12 7h.01"/></svg></button></p><b class="nvp-rit-t">' + cloEsc(dove) + '</b>'
    + '<div class="clo-pw">' + cloPonteSvg(m.pos) + '<span class="clo-sx">Paura<br>Dubbio<br>Rimando</span><span class="clo-dx">Fede<br>Velocità<br>Successo</span></div>'
    + '<p class="nvp-rit-s">' + cloEsc(riga) + '</p>'
    + (m.dec > 0 ? '<button type="button" class="clo-dec-link" onclick="cloDecisioniApri()">Vedi quali e a che ora</button>' : '') + '</div>';
}
/* IL CIRCOLO, IN HTML (0.9.359). Andrea: "le slide del piu' pensi, piu' dubiti, meno fai non devono essere immagini, perche' le
   immagini non si traducono: ricreale con elementi HTML e CSS". Le quattro voci sono testo vero, posizionate sul cerchio; le
   frecce sono un disegno senza parole. Il rosso e' la mente che si blocca, il blu l'azione (gli schemi che ha mandato Andrea). */
function flCircoloHtml(tit, voci){
  const pos = [[50, 15.3], [81.9, 50], [50, 84.7], [18.1, 50]];
  return '<div class="fl-circ"><svg class="fl-circ-fr" viewBox="0 0 320 300" aria-hidden="true"><defs><marker id="flCircFr" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M1 1L9 5L1 9" fill="none" stroke="#8A9BB3" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
    + '<g fill="none" stroke="#8A9BB3" stroke-width="2.6" stroke-linecap="round" marker-end="url(#flCircFr)"><path d="M210 52 Q258 66 268 112"/><path d="M262 192 Q252 240 214 250"/><path d="M108 250 Q66 240 56 192"/><path d="M54 110 Q64 64 108 50"/></g></svg>'
    + voci.map(function(v, i){ return '<span class="fl-circ-p ' + (v[1] ? 'r' : 'b') + '" style="left:' + pos[i][0] + '%;top:' + pos[i][1] + '%">' + cloEsc(v[0]) + '</span>'; }).join('')
    + '</div><p class="fl-circ-t">' + cloEsc(tit) + '</p>';
}
const FL_CIRCOLO_FRENA = ['Il circolo che ti frena', [['+ PENSI', 1], ['+ DUBITI', 1], ['− FAI', 0], ['− FIDUCIA', 0]]];
const FL_CIRCOLO_SPINGE = ['Il circolo che ti spinge', [['+ AGISCI', 0], ['− DUBITI', 1], ['+ FAI', 0], ['+ FIDUCIA', 0]]];
function cloInfoScorri(c){
  const d = c && c.parentNode && c.parentNode.querySelector('.clo-ic-d'); if (!d) return;
  const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth));
  Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
}
function cloInfoVai(btn, i){ const c = btn && btn.parentNode && btn.parentNode.parentNode.querySelector('.clo-ic'); if (c) try{ c.scrollTo({ left: i * c.clientWidth, behavior: 'smooth' }); }catch(_){ c.scrollLeft = i * c.clientWidth; } }
function cloPonteInfo(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  if (typeof inSheet !== 'function') return;
  /* 0.9.340, Andrea: "zero emoji, niente immagine, spaziatura che fa schifo, e i due punti a capo da soli sembrano un bug".
     Il ponte disegnato in cima, le due sponde affiancate, poi le due regole: un titolo e una riga sotto, mai i due punti a inizio riga.
     0.9.359, Andrea: "nel popover della (i) di Il tuo ritmo, come prima slide quello che c'e' adesso, e poi la slide del piu' pensi
     piu' dubiti meno fai meno fiducia, e come invertire quel loop se si vuole decidere piu' in fretta, quindi aumentare il ritmo".
     Tre slide, una cosa alla volta: il ponte, il circolo che frena, il circolo girato al contrario. */
  const s1 = '<section class="clo-ic-s"><div class="clo-info-img">' + cloPonteSvg(0.5) + '</div>'
    + '<h3>Il ponte si attraversa decidendo</h3>'
    + '<div class="clo-info-sponde"><div class="sx"><span>\ud83d\ude1f</span><b>Scarsità</b><small>Paura, dubbio, rimando</small></div><div class="dx"><span>\ud83d\ude80</span><b>Abbondanza</b><small>Fede, velocità, successo</small></div></div>'
    + '<div class="clo-info-r"><span>\u2705</span><div><b>Ogni decisione presa ti sposta in avanti</b><p>Conta una tappa fatta, una sessione partita o una riga del foglio chiusa.</p></div></div>'
    + '<div class="clo-info-r"><span>\u23f1\ufe0f</span><div><b>Conta anche quanto ci metti</b><p>Il tempo si misura dalla sveglia alla prima mossa. Più è breve, più vai avanti.</p></div></div></section>';
  const s2 = '<section class="clo-ic-s"><h3>Più pensi, meno fai</h3>'
    + flCircoloHtml(FL_CIRCOLO_FRENA[0], FL_CIRCOLO_FRENA[1])
    + '<p class="clo-ic-p">Più pensi, più dubiti. Più dubiti, meno fai. Meno fai, meno ti fidi di te. E meno ti fidi, più pensi.</p></section>';
  const s3 = '<section class="clo-ic-s"><h3>Per decidere più in fretta, giralo al contrario</h3>'
    + flCircoloHtml(FL_CIRCOLO_SPINGE[0], FL_CIRCOLO_SPINGE[1])
    + '<div class="clo-info-r"><span>\u26a1</span><div><b>Fai un passo di due minuti</b><p>Ogni cosa fatta toglie un dubbio, e la decisione dopo arriva prima.</p></div></div>'
    + '<button type="button" class="clo-ic-link" onclick="inSheetChiudi();if(typeof acApriLezione===\'function\')setTimeout(function(){acApriLezione(\'procrastinazione\',\'Il circolo dell’autosabotaggio\')},250)">Leggi la lezione nell’Academy</button></section>';
  inSheet('<div class="clo-info clo-info3"><div class="clo-ic" onscroll="cloInfoScorri(this)">' + s1 + s2 + s3 + '</div>'
    + '<div class="clo-ic-d">' + [0, 1, 2].map(function(i){ return '<button type="button" class="' + (i ? '' : 'on') + '" onclick="cloInfoVai(this,' + i + ')" aria-label="Pagina ' + (i + 1) + ' di 3"><i></i></button>'; }).join('') + '</div></div>');
}
(function(){
  const st = document.createElement('style');
  st.textContent = ''
    + '.clo-ic{display:flex;align-items:flex-start;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;margin:0 -2px}.clo-ic::-webkit-scrollbar{display:none}'
    + '.clo-ic-s{flex:0 0 100%;min-width:0;box-sizing:border-box;padding:0 2px;scroll-snap-align:center;scroll-snap-stop:always}'
    + '.clo-ic-s h3{margin:6px 40px 22px;text-align:center}'
    + '.clo-ic-p{margin:20px 4px 0;text-align:center;font:600 15px/1.55 var(--font-body);color:var(--navy)}body.dark .clo-ic-p{color:#fff}'
    + '.clo-ic-link{display:block;margin:22px auto 4px;border:0;background:none;color:#0075E3;font:800 14.5px var(--font-body);cursor:pointer;padding:8px 12px}body.dark .clo-ic-link{color:#8CC6FF}'
    + '.clo-ic-d{display:flex;justify-content:center;gap:2px;margin-top:22px}'
    + '.clo-ic-d button{flex:none;width:22px;height:22px;border:0;background:none;padding:0;display:flex;align-items:center;justify-content:center;cursor:pointer}'
    + '.clo-ic-d i{flex:none;width:7px;height:7px;border-radius:50%;background:rgba(0,30,68,.2);transition:background .2s ease,transform .2s ease}.clo-ic-d button.on i{background:#0075E3;transform:scale(1.25)}'
    + 'body.dark .clo-ic-d i{background:rgba(255,255,255,.25)}body.dark .clo-ic-d button.on i{background:#8CC6FF}'
    + '.fl-circ{position:relative;width:100%;max-width:320px;aspect-ratio:320/300;margin:0 auto}'
    + '.fl-circ-fr{position:absolute;inset:0;width:100%;height:100%}'
    + '.fl-circ-p{position:absolute;transform:translate(-50%,-50%);padding:9px 14px;border-radius:12px;font:800 14px/1 var(--font-body);letter-spacing:.03em;color:#fff;white-space:nowrap;box-shadow:0 6px 14px rgba(0,30,68,.16)}'
    + '.fl-circ-p.r{background:#E63946}.fl-circ-p.b{background:#0075E3}'
    + '.fl-circ-t{margin:6px 0 0;text-align:center;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}'
    + '.clo-ic-s .fl-circ-t + .clo-info-r{margin-top:28px}';
  document.head.appendChild(st);
})();
/* la risposta dell'agente passa di qui (dream-storia.js avvolge agMsgHtml): se c'e' il collo, si tiene */
(function(){
  const prova = function(){
    if (typeof agMsgHtml !== 'function'){ setTimeout(prova, 800); return; }
    const orig = window.agMsgHtml;
    window.agMsgHtml = function(m){ try{ cloSalvaDa(m); }catch(_){ } return orig.apply(this, arguments); };
  };
  setTimeout(prova, 1500);
  const st = document.createElement('style');
  st.textContent = ''
    + '.clo-p{margin:28px 0 4px;text-align:center}.clo-card{margin-top:14px;padding:20px 18px 16px;border-radius:22px;background:linear-gradient(170deg,rgba(140,198,255,.16),rgba(255,255,255,.05));border:1px solid rgba(140,198,255,.28)}'
    + '.clo-bt{display:block;width:84px;height:84px;margin:0 auto 10px;filter:drop-shadow(0 8px 18px rgba(0,117,227,.45))}'
    + '.clo-t{display:block;font:800 21px/1.25 var(--font-display);color:#fff}.clo-s{margin:10px 0 0;font:500 14px/1.5 var(--font-body);color:#BFD3EC}'
    + '.clo-m{margin:16px 0 0;padding:12px 14px;border-radius:16px;background:rgba(0,0,0,.18);text-align:left}.clo-m small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.clo-m b{display:block;margin-top:4px;font:700 15px/1.4 var(--font-body);color:#fff}'
    + '.clo-cta{display:block;width:100%;margin-top:16px;padding:14px;border:0;border-radius:16px;background:#fff;color:#001E44;font:800 15.5px var(--font-body);cursor:pointer}'
    + '.clo-link{margin-top:10px;padding:6px;border:0;background:none;color:#8CC6FF;font:700 13px var(--font-body);cursor:pointer}'
    + '.clo-rs .nvp-rit-t{display:flex!important;align-items:center;justify-content:center;gap:8px}.clo-pw{position:relative;margin:6px -4px 2px}.clo-ponte{display:block;width:100%;height:auto}'
    + '.clo-sx,.clo-dx{position:absolute;top:4px;font:800 10.5px/1.3 var(--font-body);letter-spacing:.06em;text-transform:uppercase}.clo-sx{left:4px;text-align:left;color:#8FA3C8}.clo-dx{right:4px;text-align:right;color:#BCE0FF}'
    + '.nvs-ctl .nvs-ctl-h{margin:0 0 6px;font:800 23px/1.2 var(--font-display);color:var(--navy);text-align:center}'
    + '.nvp-rit-link{display:block;margin:12px auto 0;padding:6px 10px;border:0;background:none;color:#8CC6FF;font:700 13px var(--font-body);cursor:pointer}'
    /* il foglio dei sette giorni come linea del tempo */
    + '.prc-tl{position:relative;display:flex;flex-direction:column;gap:18px;padding-left:26px}.prc-tl::before{content:"";position:absolute;left:8px;top:14px;bottom:14px;width:2px;border-radius:2px;background:linear-gradient(180deg,#BCE0FF,#0075E3)}'
    + '.prc-tl .prc-r{position:relative;display:grid!important;grid-template-columns:28px 1fr;column-gap:10px;align-items:start;padding:14px 16px!important;margin:0!important}.prc-tl .prc-r[hidden]{display:none!important}'
    + '.prc-tl .prc-r::before{content:"";position:absolute;left:-23px;top:20px;width:12px;height:12px;border-radius:50%;background:#fff;border:3px solid #0075E3;box-sizing:border-box}'
    + '.prc-tl .prc-r > i{grid-column:2;justify-self:start;margin-top:8px}.prc-tl .prc-r p{margin:0;line-height:1.45}'
    + '.clo-info{padding:40px 2px 12px;text-align:center}.clo-info-img{margin:0 -6px 6px;border-radius:20px;overflow:hidden;background:linear-gradient(180deg,#0B2A5C,#001E44)}.clo-info-img svg{display:block;width:100%;height:auto}'
    + '.clo-info h3{margin:18px 0 18px;font:800 21px/1.25 var(--font-display);color:var(--navy)}'
    + '.clo-alone{transform-box:fill-box;transform-origin:center;animation:cloAlone 1.8s ease-out infinite}@keyframes cloAlone{0%{opacity:.85;transform:scale(.6)}100%{opacity:0;transform:scale(1.8)}}'
    + '.clo-info-sponde{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:22px}.clo-info-sponde > div{display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 8px;border-radius:16px;background:var(--bg,#F4F9FF);border:1px solid var(--line)}'
    + '.clo-info-sponde span{font-size:26px;line-height:1;margin-bottom:4px}.clo-info-sponde b{font:800 15px var(--font-body);color:var(--navy)}.clo-info-sponde small{font:500 12.5px/1.35 var(--font-body);color:var(--muted)}.clo-info-sponde .dx{border-color:#8CC6FF;background:rgba(0,117,227,.07)}'
    + 'body.dark .clo-info-sponde > div{background:#12203A;border-color:#22345A}body.dark .clo-info-sponde .dx{border-color:#3F9FF4}'
    + '.clo-info-r{display:flex;align-items:flex-start;gap:14px;margin:0 0 18px;text-align:left}.clo-info-r > span{flex:none;width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;background:var(--bg,#F4F9FF)}body.dark .clo-info-r > span{background:#12203A}'
    + '.clo-info-r b{display:block;font:800 15.5px/1.35 var(--font-body);color:var(--navy)}.clo-info-r p{margin:5px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}'
    /* la slide del collo nel carosello del ritmo */
    + '.clo-sl{padding:20px 16px 14px!important}.clo-sl-t{display:block;margin:12px 0 0;font:800 18px/1.3 var(--font-display);color:#fff}.clo-sl .clo-m{margin-top:14px}.clo-sl .clo-cta{margin-top:14px}.clo-sl .clo-bt{display:inline-block;width:22px;height:22px;margin:0;vertical-align:-5px;filter:none}';
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------- 0.9.343: la bottiglia */
const CLO_USO = { at: 0, apps: null, p: null };
/* 0.9.346, Andrea: "prima il collo era WhatsApp, dopo due minuti era vuoto: avevo scelto i dati del computer nella revisione. Il collo deve
   tenere conto sia del telefono sia del computer". Prima chiedeva "le app piu' usate" al Report, che risponde per la sorgente scelta
   (telefono, computer o insieme). Adesso legge SEMPRE tutti e due: i granelli del telefono e quelli del computer (o, se il computer
   ha mandato solo i totali, il suo elenco del giorno). Una distrazione entra nel collo da 3 minuti in su: un minuto di WhatsApp no. */
const CLO_MIN_MS = 3 * 60000;
function cloSommaGrani(grani, d0, ora, fonte){
  const per = {};
  (grani || []).forEach(function(x){
    const f = x.fonte || x.dev || fonte; if (f !== fonte) return;
    const s = Math.max(x.s, d0), e = Math.min(x.s + x.ms, ora); if (!(e > s)) return;
    const k = String(x.p || x.l || '?');
    if (!per[k]) per[k] = { packageName: x.p || k, label: x.l || x.p || k, ms: 0, fonte: fonte };
    per[k].ms += e - s;
  });
  return Object.keys(per).map(function(k){ return per[k]; });
}
function cloUsoCarica(){
  if (CLO_USO.p || (CLO_USO.apps && Date.now() - CLO_USO.at < 90000)) return CLO_USO.p;
  const d0 = cloGiorno(Date.now()), ora = Date.now();
  const tel = (async function(){
    try{ if (typeof mwGraniTelefono === 'function'){ const l = cloSommaGrani(await mwGraniTelefono(d0), d0, ora, 'telefono'); if (l.length) return l; } }catch(_){ }
    try{ if ((typeof mwFonte !== 'function' || mwFonte() === 'telefono') && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps){ const r = await NATIVE.getTopApps({ from: d0, to: ora, limit: 24, by: 'ms', icons: 10 }); return ((r && r.apps) || []).filter(function(a){ return a && !a.self; }).map(function(a){ return { packageName: a.packageName, label: a.label, ms: a.ms || 0, icon: a.icon, fonte: 'telefono' }; }); } }catch(_){ }
    return [];
  })();
  const pc = (async function(){
    try{ if (typeof pcSync === 'function') await Promise.race([pcSync(false), new Promise(function(ok){ setTimeout(ok, 3000); })]); }catch(_){ }
    let l = [];
    try{ if (typeof mwGraniComputer === 'function') l = cloSommaGrani(await mwGraniComputer(d0), d0, ora, 'computer'); }catch(_){ l = []; }
    try{ const d = (typeof pcGiorno === 'function') ? pcGiorno(0) : null; if (d && (!l.length || l.reduce(function(t, x){ return t + x.ms; }, 0) < (d.m || 0) * 60000 * 0.6)) l = (d.top || []).map(function(t){ return { packageName: String(t.k || ''), label: String(t.k || ''), ms: Math.round((t.m || 0) * 60000), fonte: 'computer', cat: t.c || '' }; }); }catch(_){ }
    return l;
  })();
  CLO_USO.p = Promise.all([tel, pc]).then(function(r){
    CLO_USO.apps = r[0].concat(r[1]).filter(function(a){ return a && (a.ms || 0) >= CLO_MIN_MS && !(typeof dmNonConta === 'function' && dmNonConta(a.packageName)); }).sort(function(a, b){ return b.ms - a.ms; });
    CLO_USO.at = Date.now(); CLO_USO.p = null; cloBottRiempi();
  }).catch(function(){ CLO_USO.p = null; });
  return CLO_USO.p;
}
/* "📱 Instagram=95; !✍️ Scrivere il libro=25; ~😴 Dormire=420" */
function cloAttDaTesto(t){
  const m = /ATTENZIONE\s*:\s*([^\n]+)/i.exec(String(t || '')); if (!m) return null;
  const l = m[1].split(/[;|]/).map(function(x){
    const v = /^\s*([!~]?)\s*(.+?)\s*[=:]\s*(\d+)\s*(?:min[a-z]*)?\s*$/i.exec(x); if (!v) return null;
    const nome = v[2].replace(/^[\s"*_]+|[\s"*_]+$/g, '');
    let e = ''; try{ const k = nome.match(/^(\p{Extended_Pictographic}\uFE0F?)/u); if (k) e = k[1]; }catch(_){ }
    return { k: v[1] === '!' ? 'prio' : (v[1] === '~' ? 'neutro' : 'distr'), e: e, n: nome.replace(/^\p{Extended_Pictographic}\uFE0F?\s*/u, '').slice(0, 40), min: Math.min(1440, +v[3] || 0) };
  }).filter(function(x){ return x && x.n && x.min > 0; });
  return l.length >= 2 ? l.slice(0, 8) : null;
}
function cloPremium(){ try{ return typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium(); }catch(_){ return false; } }
function cloSognoMin(){
  const d0 = cloGiorno(Date.now()); let m = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x && x.at >= d0 && !x.meditazione) m += +(x.min || x.minutes || 0) || 0; }); }catch(_){ }
  return Math.round(m);
}
function cloSognoEmoji(){ try{ if (typeof cstIcona === 'function'){ const e = cstIcona(); if (e) return e; } }catch(_){ } try{ if (typeof accSognoEmoji === 'function'){ const e = accSognoEmoji(); if (e) return e; } }catch(_){ } return '✨'; }
/* le voci da disegnare: dall'agente (Premium) o dalle app di oggi */
function cloVoci(){
  const c = cloLeggi();
  if (cloPremium() && c && c.att && c.att.length){
    const l = c.att.map(function(x){ return { n: x.n, e: x.e, ms: x.min * 60000, k: x.k }; });
    if (!l.some(function(x){ return x.k === 'prio'; })) l.push({ n: 'Il tuo sogno', e: cloSognoEmoji(), ms: cloSognoMin() * 60000, k: 'prio' });
    return { fonte: 'agente', l: l };
  }
  if (!CLO_USO.apps) return null;
  let cats = {}, ex = []; try{ cats = insCats(); ex = insExcl(); }catch(_){ }
  const l = CLO_USO.apps.slice(0, 12).map(function(a){
    let p = .22, ico = a.icon || '';
    if (a.fonte === 'computer'){
      /* sul computer la categoria la decide il suo programma; chi non ne ha una si pesa per nome (youtube, instagram...) */
      if (a.cat === 'Distracting') p = 1; else if (a.cat === 'Productive') p = .05;
      else { try{ const q = (typeof dpPattern === 'function') ? dpPattern(a.label) : null; p = q === null ? .22 : q; }catch(_){ } }
      try{ if (!ico && typeof mwIcoPerNome === 'function' && typeof mwIcoTenute === 'function') ico = mwIcoPerNome(mwIcoTenute(), a.label) || ''; }catch(_){ }
    } else {
      try{ if (typeof dpPeso === 'function') p = dpPeso(a.packageName, cats, ex, a.label); }catch(_){ }
      if (!ico){ try{ ico = (typeof insIconaSubito === 'function') ? insIconaSubito(a.packageName) : ''; }catch(_){ } }
    }
    return { n: a.label || a.packageName, pkg: a.packageName, ico: ico, ms: a.ms, k: p >= .6 ? 'distr' : (p <= .1 ? 'prod' : 'neutro') };
  });
  l.push({ n: 'Il tuo sogno', e: cloSognoEmoji(), ms: cloSognoMin() * 60000, k: 'prio' });
  return { fonte: 'app', l: l };
}
/* 0.9.344, Andrea (con l'analisi che ha portato): "la grafica era al contrario: le distrazioni giravano libere nella pancia e il sogno
   stava nel collo, bloccato dal tappo. Cosi' sembrava che fosse il sogno a tappare le distrazioni". Ribaltata: nella pancia c'e' IL SOGNO,
   che spinge per uscire; nel collo, il punto piu' stretto, sono incastrate le distrazioni di oggi, e sono loro a tappare l'uscita. Senza
   tappo: se il collo e' libero, il sogno passa. "Sbloccalo adesso" vuol dire togliere le distrazioni dal collo. */
function cloBottSvg(){
  return '<svg class="clo-bott-svg" viewBox="0 0 300 150" aria-hidden="true"><defs>'
    + '<linearGradient id="cloVetro" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8CC6FF" stop-opacity=".2"/><stop offset="1" stop-color="#8CC6FF" stop-opacity=".05"/></linearGradient>'
    + '<linearGradient id="cloAcqua" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3F9FF4" stop-opacity=".75"/><stop offset="1" stop-color="#0075E3" stop-opacity=".45"/></linearGradient>'
    + '<clipPath id="cloDentro"><path d="M26 12H176C206 12 212 54 238 54H296V96H238C212 96 206 138 176 138H26A20 20 0 0 1 6 118V32A20 20 0 0 1 26 12Z"/></clipPath></defs>'
    + '<g clip-path="url(#cloDentro)"><path class="clo-onda" d="M-20 46C10 38 40 54 70 46S130 38 160 46 220 54 250 46 310 38 340 46V150H-20Z" fill="url(#cloAcqua)"/></g>'
    + '<path d="M296 54H238C212 54 206 12 176 12H26A20 20 0 0 0 6 32V118A20 20 0 0 0 26 138H176C206 138 212 96 238 96H296" fill="url(#cloVetro)" stroke="#BCE0FF" stroke-opacity=".8" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>'
    + '<path d="M22 28V104" stroke="#fff" stroke-opacity=".18" stroke-width="5" stroke-linecap="round"/>'
    + '<g class="clo-spinta" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M138 66l9 9-9 9"/><path d="M152 66l9 9-9 9"/></g></svg>';
}
/* quanto e' alta la bottiglia, dentro, a una certa x: larga nella pancia, a imbuto nella spalla, stretta nel collo */
function cloMeta(x){ if (x <= 176) return 58; if (x >= 236) return 18; const t = 1 - (x - 176) / 60; return 18 + 40 * t * t; }
/* le distrazioni incastrate: la piu' grande in bocca al collo, le altre dietro, a tappare */
function cloImpacca(voci){
  const fuori = voci.filter(function(v){ return v.k === 'distr' && v.ms > 0; }).sort(function(a, b){ return b.ms - a.ms; }).slice(0, 7);
  const max = Math.max.apply(null, fuori.map(function(v){ return v.ms; }).concat([1]));
  const posti = [];
  fuori.forEach(function(v){
    const r = 10 + 7 * Math.sqrt(v.ms / max);
    let ok = null;
    for (let x = 292 - r; x >= 168 && !ok; x -= 2){
      const libero = Math.min(cloMeta(x - r * 0.8), cloMeta(x), cloMeta(x + r * 0.8)) - r - 1;
      if (libero < 0) continue;
      for (let d = 0; d <= libero && !ok; d += 3){
        [75 - d, 75 + d].forEach(function(y){
          if (ok) return;
          if (posti.every(function(p){ const dx = p.x - x, dy = p.y - y; return Math.sqrt(dx * dx + dy * dy) >= p.r + r + 2; })) ok = { x: x, y: y };
        });
      }
    }
    if (ok) posti.push({ x: ok.x, y: ok.y, r: r, v: v });
  });
  return posti;
}
function cloDurata(ms){ const m = Math.round((ms || 0) / 60000); if (m < 60) return m + ' min'; const h = Math.floor(m / 60), r = m % 60; return h + ' h' + (r ? ' ' + r + ' min' : ''); }
/* 0.9.347, Andrea: "nel collo ci sono I, W, Y: che cazzo vogliono dire? Devono avere un'immagine e si devono poter toccare". Le voci scritte
   dall'agente arrivano spesso senza emoji: l'icona si cerca per nome fra quelle delle app (telefono e computer), poi in un elenco di
   emoji per le app e le attivita' piu' comuni, e solo in fondo un'emoji generica. Mai piu' una lettera. Ogni pallina apre la sua scheda. */
const CLO_EMOJI = [[/instagram/i, '📸'], [/whatsapp|telegram|messag|signal/i, '💬'], [/youtube|twitch|netflix|prime video|disney|film|serie/i, '📺'], [/tiktok|reels|shorts/i, '🎵'],
  [/facebook|threads|twitter|\bx\b|reddit|linkedin|snapchat|pinterest/i, '👥'], [/chrome|safari|firefox|browser|google|sito|web/i, '🌐'], [/gioc|game|clash|fortnite|steam|play/i, '🎮'],
  [/mail|gmail|posta/i, '✉️'], [/telefon|chiamat/i, '📞'], [/notizi|news/i, '📰'], [/shop|amazon|acquist|zalando|vinted/i, '🛍️'], [/spotify|musica|podcast/i, '🎧'],
  [/dorm|sonno|letto/i, '😴'], [/mangi|cibo|pranzo|cena/i, '🍝'], [/claude|chatgpt|gemini|ai\b|lavor|shopify|codice|scriv/i, '💻']];
function cloEmojiPer(n){ const t = String(n || ''); for (let i = 0; i < CLO_EMOJI.length; i++) if (CLO_EMOJI[i][0].test(t)) return CLO_EMOJI[i][1]; return '📱'; }
/* 0.9.348, Andrea: "per Instagram e YouTube deve esserci l'icona dell'app, non un'emoji: le emoji per le categorie (piu' app di video)".
   Un nome che e' un'app nota si cerca fra le icone delle app installate; un nome che e' un'attivita' (sonno, lavoro) resta un'emoji */
const CLO_PKG = [[/instagram/i, 'com.instagram.android'], [/youtube/i, 'com.google.android.youtube'], [/whatsapp/i, 'com.whatsapp'], [/tiktok/i, 'com.zhiliaoapp.musically'],
  [/facebook/i, 'com.facebook.katana'], [/chrome/i, 'com.android.chrome'], [/telegram/i, 'org.telegram.messenger'], [/netflix/i, 'com.netflix.mediaclient'], [/twitter|^x$/i, 'com.twitter.android'],
  [/reddit/i, 'com.reddit.frontpage'], [/snapchat/i, 'com.snapchat.android'], [/spotify/i, 'com.spotify.music'], [/gmail/i, 'com.google.android.gm'], [/threads/i, 'com.instagram.barcelona'],
  [/twitch/i, 'tv.twitch.android.app'], [/pinterest/i, 'com.pinterest'], [/linkedin/i, 'com.linkedin.android'], [/capcut/i, 'com.lemon.lvoverseas'], [/fotocamera|camera/i, 'com.sec.android.app.camera']];
function cloIcoPer(v){
  if (v.ico) return v.ico;
  try{ if (typeof insIconaSubito === 'function'){ for (let i = 0; i < CLO_PKG.length; i++){ if (CLO_PKG[i][0].test(String(v.n || '').trim())){ const ic = insIconaSubito(CLO_PKG[i][1]); if (ic) return ic; break; } } } }catch(_){ }
  try{ if (typeof mwIcoPerNome === 'function' && typeof mwIcoTenute === 'function'){ const i = mwIcoPerNome(mwIcoTenute(), v.n); if (i) return i; } }catch(_){ }
  return '';
}
const CLO_UI = [];
function cloPallina(x, y, r, v, cls){
  const ico = /sogno/.test(cls || '') ? '' : cloIcoPer(v);
  const dentro = ico ? '<img src="' + ico + '" alt="" onerror="this.outerHTML=\'<em>' + cloEsc(v.e || cloEmojiPer(v.n)) + '</em>\'">' : '<em>' + cloEsc(v.e || cloEmojiPer(v.n)) + '</em>';
  const i = CLO_UI.length; CLO_UI.push({ v: v, ico: ico });
  return '<button type="button" class="clo-b k-' + v.k + (cls ? ' ' + cls : '') + '" onclick="cloVoceApri(' + i + ')" aria-label="' + cloEsc(v.n + ', ' + cloDurata(v.ms)) + '" style="left:' + ((x - r) / 3).toFixed(2) + '%;top:' + ((y - r) / 1.5).toFixed(2) + '%;width:' + (2 * r / 3).toFixed(2) + '%;--d:' + ((x * 7 + y) % 23 / 10).toFixed(1) + 's">' + dentro + '</button>';
}
/* la scheda di una pallina: cos'e', quanto tempo oggi, e perche' sta li' */
function cloCollApri(){
  const c = cloLeggi(); if (!c) return;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  inSheet('<div class="en-foglio clo-voce"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="clo-voce-fig k-distr"><span>' + cloEsc((cloEmojiPer(c.t) === '📱' ? '🚧' : cloEmojiPer(c.t))) + '</span></div>'
    + '<small class="clo-voce-k">Il collo che ha trovato il tuo agente</small><h3>' + cloEsc(c.t) + '</h3>'
    + (c.mossa ? '<div class="clo-voce-m"><small>La prima mossa</small><b>' + cloEsc(c.mossa) + '</b></div>' : '')
    + (c.perche ? '<p>' + cloEsc(c.perche) + '</p>' : '')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi();cloSblocca()">Lavoraci adesso</button>'
    + '<button type="button" class="clo-voce-ok" onclick="cloRisolto()">L’ho sbloccato</button></div>');
}
/* sbloccato: la festa, e la domanda sul prossimo (c'e' sempre un collo: tolto uno, il prossimo sta altrove) */
function cloRisolto(){
  const c = cloLeggi(); if (!c) return;
  c.risolto = Date.now();
  try{ localStorage.setItem(CLO_K, JSON.stringify(c)); }catch(_){ }
  try{ const st = JSON.parse(localStorage.getItem('fl_colli_sbloccati') || '[]') || []; st.push({ t: c.t, da: c.at, a: c.risolto }); localStorage.setItem('fl_colli_sbloccati', JSON.stringify(st.slice(-30))); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra([20, 50, 20, 50, 40]); }catch(_){ }
  const n = (function(){ try{ return (JSON.parse(localStorage.getItem('fl_colli_sbloccati') || '[]') || []).length; }catch(_){ return 1; } })();
  inSheet('<div class="en-foglio clo-voce clo-fatto"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="clo-fatto-ico" aria-hidden="true">🍾</div><h3>Ottimo lavoro: hai sbloccato il tuo collo di bottiglia</h3>'
    + '<p>' + (n > 1 ? 'È il collo numero ' + n + ' che togli. ' : '') + 'Il sogno adesso passa. Tolto un collo, il prossimo sta da un’altra parte: troviamolo.</p>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi();cloChiedi(false)">Trova il prossimo collo</button>'
    + '<button type="button" class="clo-voce-ok" onclick="inSheetChiudi()">Più tardi</button></div>');
  try{ cloBottRiempi(); }catch(_){ }
  try{ if (typeof nvpRiempi === 'function' && typeof nvpRitmoHtml === 'function') nvpRiempi('nvpRitmo', nvpRitmoHtml()); }catch(_){ }
}
function cloVoceApri(i){
  const u = CLO_UI[i]; if (!u) return;
  const v = u.v;
  if (v.k === 'collo'){ cloCollApri(); return; }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const sogno = v.k === 'prio';
  const fig = u.ico ? '<img src="' + u.ico + '" alt="">' : '<span>' + cloEsc(v.e || (sogno ? cloSognoEmoji() : cloEmojiPer(v.n))) + '</span>';
  const perche = sogno ? 'È il tempo che oggi hai dato al tuo sogno, con le sessioni di Full Focus. Spinge per uscire dalla bottiglia.'
    : (v.k === 'distr' ? 'Oggi ti ha preso ' + cloDurata(v.ms) + '. È nel collo: insieme alle altre distrazioni tappa l’uscita del tuo sogno.'
    : 'Oggi ci hai passato ' + cloDurata(v.ms) + '. Non ti allontana dal sogno, quindi non tappa il collo.');
  inSheet('<div class="en-foglio clo-voce"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="clo-voce-fig k-' + v.k + '">' + fig + '</div><h3>' + cloEsc(sogno ? (v.n === 'Il tuo sogno' ? 'Il tuo sogno' : v.n) : v.n) + '</h3>'
    + '<b class="clo-voce-min">' + cloDurata(v.ms) + ' oggi</b><p>' + perche + '</p>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/* le parti della bottiglia: le palline, la legenda, e se il collo e' libero. Le usa la slide appena nasce (cosi' non cambia altezza
   un attimo dopo) e l'aggiornamento quando arrivano i dati */
function cloBottParti(){
  const vv = cloVoci();
  const sogno0 = { n: 'Il tuo sogno', e: cloSognoEmoji(), ms: cloSognoMin() * 60000, k: 'prio' };
  CLO_UI.length = 0;
  if (!vv && !cloLeggi()) return { sg: cloPallina(84, 78, 30, sogno0, 'sogno'), pp: '', leg: '<p class="clo-attesa">Le distrazioni di oggi compaiono nel collo appena arrivano i dati.</p>', libera: false, pronta: false };
  const prio0 = (vv ? vv.l.filter(function(v){ return v.k === 'prio'; })[0] : null) || sogno0;
  /* 0.9.348, Andrea: "ho trovato il collo di bottiglia e nella slide non compare niente: sembra che non ci sia. Deve esserci una pallina
     con quello che e' stato trovato, e il testo deve stare li', non nel foglio della (i). Le app sono solo il ripiego finche' il collo
     non e' stato trovato: 4 minuti di WhatsApp non sono un collo di bottiglia. E quando l'ho risolto, voglio vederlo". */
  const cc = cloLeggi();
  if (cc && !cc.risolto){
    const e = cloEmojiPer(cc.t);
    const vc = { n: cc.t, e: e === '📱' ? '🚧' : e, ms: 0, k: 'collo' };
    const prioC = { n: prio0.n, e: cloSognoEmoji(), ms: prio0.ms, k: 'prio' };
    return {
      sg: cloPallina(84, 78, 30, prioC, 'sogno'),
      pp: cloPallina(262, 75, 17, vc, 'tappo collo'),
      /* 0.9.349, Andrea: "non 'Nel collo' che va a capo e il testo attaccato: cosa ti sta bloccando, due punti, la (i) accanto, e il
         problema in grassetto a capo. Niente 'Tocca la pallina rossa': la pallina si tocca da sola, e se serve c'e' la (i)" */
      leg: '<div class="clo-leg2"><p class="clo-leg2-k"><i class="k-distr"></i>Cosa ti sta bloccando:</p>'
        + '<b role="button" tabindex="0" class="clo-leg2-v" onclick="event.stopPropagation();cloCollApri()">' + cloEsc(cc.t.length > 90 ? cc.t.slice(0, 87).replace(/\s\S*$/, '') + '…' : cc.t) + '</b></div>',
      libera: false, pronta: true, collo: true
    };
  }
  if (cc && cc.risolto){
    const prioR = { n: prio0.n, e: cloSognoEmoji(), ms: prio0.ms, k: 'prio' };
    return { sg: cloPallina(84, 78, 30, prioR, 'sogno libero'), pp: '',
      leg: '<div class="clo-leg2"><p class="clo-leg2-k"><i class="k-prio"></i>Collo sbloccato:</p><b>' + cloEsc(cc.t.length > 90 ? cc.t.slice(0, 87).replace(/\s\S*$/, '') + '…' : cc.t) + '</b></div>',
      libera: true, pronta: true, risolto: true };
  }
  /* 0.9.347: la bolla del sogno ha SEMPRE l'emoji del sogno (prima prendeva l'iniziale della priorita' scritta dall'agente: "I") */
  const prio = { n: prio0.n, e: cloSognoEmoji(), ms: prio0.ms, k: 'prio' };
  const tappo = cloImpacca(vv.l);
  const distr = vv.l.filter(function(v){ return v.k === 'distr'; }).reduce(function(t, v){ return t + v.ms; }, 0);
  return {
    sg: cloPallina(84, 78, 30, prio, 'sogno' + (tappo.length ? '' : ' libero')),
    pp: tappo.map(function(p){ return cloPallina(p.x, p.y, p.r, p.v, 'tappo'); }).join(''),
    leg: (tappo.length ? '<span><i class="k-distr"></i>Nel collo, a tappare <b>' + cloDurata(distr) + '</b></span>' : '<span><i class="k-prio"></i>Oggi il collo è libero</span>')
      + '<span><i class="k-prio"></i>' + cloEsc(prio.n) + ' <b>' + cloDurata(prio.ms) + '</b></span>'
      + (vv.fonte === 'agente' ? '<small class="clo-fonte">La radiografia del tuo agente</small>' : ''),
    libera: !tappo.length, pronta: true
  };
}
/* 0.9.346, Andrea: "dice Sbloccalo adesso anche se il collo e' libero". Con il collo libero il pulsante invita a far passare il sogno */
function cloCtaTesto(pt){ return pt.risolto ? 'Trova il prossimo collo' : (pt.pronta && pt.libera ? 'Fai passare il sogno' : 'Sbloccalo adesso'); }
function cloCta(){
  const c = cloLeggi(); if (c && c.risolto){ cloChiedi(false); return; }
  if (c){ cloSblocca(); return; }
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  try{ goId('s-fullfocus'); if (typeof ffPaint === 'function') ffPaint(); }catch(_){ }
}
function cloBottRiempi(){
  const hs = document.querySelectorAll('.clo-bott[data-clo]'); if (!hs.length) return;
  const pt = cloBottParti();
  hs.forEach(function(h){
    const pp = h.querySelector('.clo-pp'), slide = h.parentElement, leg = slide && slide.querySelector('.clo-leg');
    if (pp && pp._h !== pt.pp){ pp.innerHTML = pt.pp; pp._h = pt.pp; }
    /* 0.9.347, Andrea: "a volte la bolla del sogno sparisce". La bolla ora sta in un posto suo e si tocca solo se e' cambiata; se per
       qualunque motivo manca, si rimette */
    const sg = h.querySelector('.clo-sg');
    if (sg && (!sg.querySelector('.clo-b.sogno') || sg._h !== pt.sg)){ sg.innerHTML = pt.sg; sg._h = pt.sg; }
    if (leg && leg.innerHTML !== pt.leg) leg.innerHTML = pt.leg;
    h.classList.toggle('libera', pt.libera);
    const b = slide && slide.querySelector('.clo-cta[data-clo-cta]'); if (b && b.textContent !== cloCtaTesto(pt)) b.textContent = cloCtaTesto(pt);
  });
}
function cloInfoApri(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const c = cloLeggi();
  /* 0.9.348: il collo trovato non sta piu' qui ma nella sua pallina (cloCollApri) */
  const trovato = '';
  inSheet('<div class="en-foglio clo-info2"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il tuo collo di bottiglia</h3>' + trovato
    + flInfoRighe([
        ['🎯', 'Nella bottiglia c’è il tuo sogno', 'Spinge per uscire e diventare vero.'],
        ['🔴', 'Nel collo ci sono le distrazioni di oggi', 'Più tempo ci hai passato, più sono grandi. Sono loro a tappare l’uscita.'],
        ['🔓', 'Sbloccare vuol dire liberare il collo', 'Meno tempo sulle distrazioni, e il sogno passa.']
      ].concat(cloPremium() ? [] : [['🤖', 'Con Premium la fa il tuo agente', 'Non solo le app: tutto quello che hai fatto nella giornata.']]))
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.clo-sl2{text-align:center}.clo-sl-k{display:flex!important;align-items:center;justify-content:center;gap:6px;white-space:nowrap;letter-spacing:.08em!important;font-size:11.5px!important}.clo-sl-k > span{font-size:18px;line-height:1;letter-spacing:0}.clo-sl-k .clo-i,.clo-sl-k .nvp-i{margin-left:4px}',
    '.clo-bott{position:relative;width:100%;aspect-ratio:2/1;margin:14px 0 4px}.clo-bott-svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}.clo-pp,.clo-sg{position:absolute;inset:0;pointer-events:none}.clo-pp .clo-b,.clo-sg .clo-b{pointer-events:auto;padding:0;cursor:pointer;-webkit-tap-highlight-color:transparent}.clo-sg{z-index:2}.clo-pp{z-index:3}.clo-b.sogno{z-index:2;will-change:transform}.clo-b em{font-size:17px}.clo-b.tappo em{font-size:15px}',
    '.clo-voce{text-align:center}.clo-voce-fig{width:84px;height:84px;margin:6px auto 14px;border-radius:50%;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#F0FBFF;border:3px solid #3F9FF4;font-size:42px}.clo-voce-fig.k-distr{border-color:#E63946}.clo-voce-fig img{width:100%;height:100%;object-fit:cover}body.dark .clo-voce-fig{background:#12203A}',
    '.clo-voce-k{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#E63946;margin:0 0 6px}.clo-voce-m{margin:0 0 14px;padding:12px 14px;border-radius:16px;background:#F0FBFF;border:1px solid #C8EFFD}.clo-voce-m small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}.clo-voce-m b{display:block;margin-top:4px;font:700 15px/1.4 var(--font-body);color:var(--navy)}body.dark .clo-voce-m{background:#12203A;border-color:#22345A}body.dark .clo-voce-m b{color:#fff}',
    '.clo-voce-ok{display:block;margin:12px auto 0;border:0;background:none;color:#0075E3;font:800 14.5px var(--font-body);cursor:pointer}.clo-fatto-ico{font-size:58px;line-height:1;margin:8px 0 12px}.clo-b.collo{animation:cloCollo 1.8s ease-in-out infinite!important}',
    '.clo-voce h3{margin:0 0 6px}.clo-voce-min{display:block;font:800 22px var(--font-display);color:#0075E3;margin:0 0 12px}.clo-voce p{margin:0 0 22px;font:500 15px/1.5 var(--font-body);color:var(--muted)}',
    '.clo-b{position:absolute;aspect-ratio:1/1;border-radius:50%;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#fff;box-sizing:border-box;border:2.5px solid #3F9FF4;box-shadow:0 4px 10px rgba(0,0,0,.28);animation:cloGalla 3.2s ease-in-out var(--d,0s) infinite alternate}',
    '.clo-b img{width:100%;height:100%;object-fit:cover;border-radius:50%}.clo-b em{font:800 15px/1 var(--font-body);font-style:normal;color:#001E44}',
    '.clo-b.k-distr{border-color:#E63946;box-shadow:0 0 0 2px rgba(230,57,70,.25),0 4px 10px rgba(0,0,0,.3)}.clo-b.k-prod{border-color:#0075E3}.clo-b.k-neutro{border-color:#8CC6FF}',
    '.clo-b.sogno{border:3px solid #fff;background:radial-gradient(circle at 35% 30%,#fff 0%,#E3F1FF 60%,#C8EFFD 100%);box-shadow:0 0 0 5px rgba(140,198,255,.3),0 0 26px rgba(140,198,255,.75);animation:cloSpinge 2.2s ease-in-out infinite}.clo-b.sogno em{font-size:30px}',
    '.clo-b.sogno.libero{animation:cloEsce 2.6s ease-in-out infinite}.clo-b.tappo{border-color:#E63946;box-shadow:0 0 0 2px rgba(230,57,70,.3),0 4px 10px rgba(0,0,0,.35);animation:cloTrema 2.4s ease-in-out var(--d,0s) infinite}',
    '@keyframes cloSpinge{0%,100%{transform:translateX(0)}50%{transform:translateX(7px)}}@keyframes cloEsce{0%,100%{transform:translateX(0)}50%{transform:translateX(60%)}}@keyframes cloTrema{0%,100%{transform:translate(0,0)}50%{transform:translate(-1.5px,1px)}}',
    '.clo-onda{animation:cloOnda 5s ease-in-out infinite alternate}@keyframes cloOnda{to{transform:translateX(-18px)}}.clo-spinta{animation:cloSpintaF 1.4s ease-in-out infinite}@keyframes cloSpintaF{0%,100%{opacity:.25;transform:translateX(0)}50%{opacity:.9;transform:translateX(5px)}}.clo-bott.libera .clo-spinta{opacity:1}',
    '@media (prefers-reduced-motion:reduce){.clo-b,.clo-onda,.clo-spinta{animation:none!important}}',
    '@keyframes cloGalla{from{transform:translate(0,0)}to{transform:translate(2px,-2px)}}@keyframes cloCollo{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}',
    '.clo-leg{display:flex;flex-wrap:wrap;justify-content:center;gap:8px 16px;margin:8px 0 2px;font:600 13px var(--font-body);color:#BFD3EC}.clo-leg span{display:inline-flex;align-items:center;gap:6px}.clo-leg b{color:#fff}.clo-leg i{width:10px;height:10px;border-radius:50%}.clo-leg i.k-distr{background:#E63946}.clo-leg i.k-prio{background:#22C55E}',
    '.clo-leg i{flex:none}.clo-leg2{flex-basis:100%;display:flex;flex-direction:column;align-items:center;gap:10px;margin-top:4px}.clo-leg2-k{display:inline-flex;align-items:center;gap:8px;margin:0;white-space:nowrap;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.clo-leg2-k i{width:10px!important;height:10px!important;border-radius:50%}',
    '.clo-leg2 > b{display:block;max-width:30ch;font:800 16px/1.4 var(--font-display);color:#fff}.clo-i2{flex:none;box-sizing:border-box;width:22px;height:22px;min-width:22px;margin-left:2px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid rgba(188,224,255,.7);border-radius:50%;background:none;color:#BCE0FF;font:800 12px/1 Georgia,serif;font-style:italic;cursor:pointer}',
    '.clo-fonte{flex-basis:100%;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.clo-attesa{margin:0;font:500 13px/1.4 var(--font-body);color:#BFD3EC}',
    '.clo-sl2 .clo-cta{margin-top:16px}',
    '.clo-if{margin:0 0 22px;padding:16px;border-radius:18px;background:var(--bg,#F4F9FF);border:1px solid var(--line);text-align:center}.clo-if small{display:block;margin-top:10px;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.clo-if small:first-child{margin-top:0}.clo-if b{display:block;margin-top:4px;font:800 16px/1.35 var(--font-display);color:var(--navy)}.clo-if p{margin:12px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}body.dark .clo-if{background:#12203A;border-color:#22345A}body.dark .clo-if small{color:#8CC6FF}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* 0.9.344, Andrea: "il segnaposto TU finisce sotto alla scritta Paura, Dubbio, Rimando". Le due scritte stanno in una riga sopra al ponte,
   non piu' sopra al disegno: il segnaposto ha tutto il suo spazio */
(function(){ const st = document.createElement('style'); st.textContent = '.clo-pw{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-end;margin-top:14px!important}.clo-pw .clo-sx,.clo-pw .clo-dx{position:static!important;order:1;margin:0 4px 0}.clo-pw .clo-ponte{order:2;flex:0 0 100%;margin-top:-10px}.clo-leg{min-height:52px;align-content:center}'; document.head.appendChild(st); })();
