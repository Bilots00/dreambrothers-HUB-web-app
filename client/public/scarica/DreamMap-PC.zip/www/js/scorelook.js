/* ===========================================================================================
   L'ASPETTO DEL TABELLONE IN OVERLAY

   La bolla del punteggio compare sopra a qualsiasi app, e questo è esattamente il suo problema:
   non sa dove sta atterrando. Bianca su Instagram in modalità scura si legge benissimo; bianca
   sopra a una pagina bianca sparisce. E un tabellone che sparisce non è discreto — è rotto,
   perché l'unica cosa che deve fare è farsi leggere in mezzo secondo mentre guardi altro.

   TRE MODI, in ordine di quanto sanno:

     · COME SUL COMPUTER — sempre il navy della pillola desktop. Nessuna sorpresa, i due
       schermi si somigliano, e se guardi telefono e computer insieme vedi lo stesso oggetto.
     · SEGUE IL TEMA — chiaro quando il telefono è chiaro, scuro quando è scuro. Va d'accordo
       con il sistema, e sbaglia ogni volta che l'app sotto non la pensa come il sistema.
     · SEMPRE IN CONTRASTO — guarda davvero che colore c'è dietro, e si mette all'opposto.
       Sfondo scuro, pillola bianca; sfondo chiaro, il blu del computer. È l'unico dei tre che
       non indovina: legge la striscia di schermo dove sta per comparire e poi decide.

   GLI STEMMI. 🕳️ e 🚀 sono le due squadre della scheda START, ma sono una scelta nostra, non
   una legge: qui si cambiano, si possono mettere più emoji insieme (🚀✨) o una foto. Il
   tabellone è la cosa che l'utente guarda cento volte al giorno — che assomigli a lui conta.
   =========================================================================================== */

const SL_MODI = [
  { k: 'contrasto', ico: '🪄', n: 'Sempre in contrasto',
    d: 'Guarda il colore dietro e si mette all\'opposto: su scuro diventa bianca, su chiaro blu. Si legge sempre.' },
  { k: 'desktop',   ico: '🖥️', n: 'Come sul computer',
    d: 'Sempre il blu scuro della pillola del desktop. I due schermi mostrano lo stesso oggetto.' },
  { k: 'tema',      ico: '🌗', n: 'Segue la modalità scura',
    d: 'Chiara quando il telefono è chiaro, scura quando è scuro.' }
];

const SL_OLD_DEF = '🕳️';
const SL_NEO_DEF = '🚀';

function slSkin(){ return (typeof SETTINGS !== 'undefined' && SETTINGS.scoreSkin) || 'contrasto'; }
function slEmoji(lato){
  const v = (typeof SETTINGS !== 'undefined' && SETTINGS['scoreEmoji' + lato]) || '';
  return v || (lato === 'Old' ? SL_OLD_DEF : SL_NEO_DEF);
}
function slImg(lato){ return (typeof SETTINGS !== 'undefined' && SETTINGS['scoreImg' + lato]) || ''; }

/* ---------------------------------------------------------------------------------------
   IL COLORE DEL TUO PUNTEGGIO

   Il verde e l'azzurro non dicono la stessa cosa a chi guarda quel numero tutti i giorni: il
   verde e' la spunta, il «va bene cosi'»; l'azzurro e' il colore del marchio, e sta piu' vicino
   a «continua». Quale delle due spinge di piu' su una persona specifica non si decide a tavolino
   — si prova per qualche settimana e si guarda il tabellone a fine mese. Quindi e' un
   interruttore, non una scelta nostra definitiva.
   --------------------------------------------------------------------------------------- */
const SL_TINTE = {
  blu:   { n: 'Azzurro',  ico: '\ud83d\udd35', d: 'Il colore del marchio. Spinge in avanti.',
           forte: '#0075E3', tenue: '#4FB8FF', glow: 'rgba(79,184,255,.9)' },
  verde: { n: 'Verde',    ico: '\ud83d\udfe2', d: 'Il colore della spunta. Rassicura.',
           forte: '#1B9E6A', tenue: '#8CF0C8', glow: 'rgba(140,240,200,.9)' }
};

function slTint(){
  const k = (typeof SETTINGS !== 'undefined' && SETTINGS.scoreTint) || 'blu';
  return SL_TINTE[k] ? k : 'blu';
}
function slNeo(chiara){ const t = SL_TINTE[slTint()]; return chiara ? t.forte : t.tenue; }

/* Le variabili CSS: un posto solo da cui prendono il colore la scheda START, il referto e
   l'anteprima qui dentro. Cambiare l'impostazione le riscrive, e tutto si adegua insieme. */
function slTintApply(){
  try{
    const t = SL_TINTE[slTint()];
    const r = document.documentElement.style;
    r.setProperty('--neo', t.forte);
    r.setProperty('--neo-soft', t.tenue);
    r.setProperty('--neo-glow', t.glow);
  }catch(_){ }
}
setTimeout(slTintApply, 1500);

/* ---------------------------------------------------------------------------------------
   Lo stemma, dovunque compaia

   TONDO, non quadrato: uno stemma di una squadra e' tondo da sempre, e una foto quadrata in
   mezzo a due numeri sembra una miniatura di un file, non l'emblema di chi sta giocando.
   --------------------------------------------------------------------------------------- */
function slCrestTag(lato, px){
  const img = slImg(lato);
  if (img) return '<img class="sl-crest" style="width:' + px + 'px;height:' + px + 'px" src="'
    + img.replace(/"/g, '') + '" alt="">';
  return esc(slEmoji(lato));
}

registerScreen('s-scorelook',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-settings\')">‹</button><b class="blk-title">Aspetto del tabellone</b></div>' +
  '<p class="hintline" style="padding:0 2px 14px">La bolla del punteggio che compare sopra alle altre app. Qui decidi come si veste e chi sono le due squadre.</p>' +
  '<div id="slPrev"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Come si veste</b></div>' +
  '<div id="slModi"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Il colore del tuo punteggio</b></div>' +
  '<p class="hintline" style="padding:0 2px 12px">Vale dappertutto: scheda START, referto, bolla e pillola del computer.</p>' +
  '<div class="sl-tint" id="slTint"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Le due squadre</b></div>' +
  '<p class="hintline" style="padding:0 2px 12px">Una emoji, più di una (<b>🚀✨</b>) o una foto tua. Lascia vuoto per tornare a quelle di serie.</p>' +
  '<div id="slTeams"></div>' +
  '<div class="spacer"></div>', { back: 's-settings' });

(function slStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* L'anteprima sta sopra a due strisce, una chiara e una scura: è l'unico modo di far
       vedere in un colpo solo cosa vuol dire «in contrasto» senza doverlo spiegare.

       Una sopra all'altra, non affiancate: due mezzi schermi da 160px tagliavano la pillola
       proprio sul minuto, ed e' l'ultima cosa che si puo' permettere di perdere un'anteprima
       che esiste solo per far vedere come si legge. */
    '.sl-stage{border-radius:20px;overflow:hidden;display:flex;flex-direction:column;border:1.5px solid var(--line)}',
    '.sl-half{padding:18px 12px;display:flex;align-items:center;justify-content:center}',
    '.sl-half.light{background:#F2F4F8}',
    '.sl-half.dark{background:#10141C}',
    '.sl-pill{display:inline-flex;align-items:center;border-radius:99px;padding:9px 14px;',
      'box-shadow:0 6px 16px rgba(0,0,0,.18);white-space:nowrap}',
    '.sl-pill.chiara{background:#fff;border:1px solid rgba(0,30,68,.13)}',
    '.sl-pill.scura{background:#0E2350;border:1px solid rgba(255,255,255,.2)}',
    '.sl-pill b{font:800 20px var(--font-display)}',
    '.sl-pill .sep{font-size:15px;padding:0 2px}',
    '.sl-pill.chiara .sep{color:rgba(0,30,68,.33)}',
    '.sl-pill.scura .sep{color:rgba(255,255,255,.4)}',
    '.sl-pill .cr{font-size:15px;line-height:1}',
    '.sl-pill .cr.l{padding-right:7px}',
    '.sl-pill .cr.r{padding-left:7px}',
    '.sl-crest{border-radius:50%;object-fit:cover;vertical-align:middle;display:inline-block}',
    '.sl-pill .min{font:700 12px var(--font-body);padding-left:8px}',
    '.sl-pill.chiara .min{color:#0075E3}',
    '.sl-pill.scura .min{color:#7FB6FF}',
    '.sl-cap{text-align:center;font:600 11px var(--font-body);color:var(--muted);padding:10px 2px 0}',
    /* La riga della squadra: emoji a sinistra, casella al centro, pulsante foto a destra. */
    '.sl-team{display:flex;align-items:center;gap:10px;border:1.5px solid var(--line);border-radius:16px;',
      'padding:12px 12px;margin-bottom:10px;background:#fff}',
    'body.dark .sl-team{background:#12203A;border-color:#22345A}',
    '.sl-team .who{font:700 11.5px var(--font-body);color:var(--muted);width:78px;flex:0 0 78px}',
    '.sl-team input{flex:1;min-width:0;border:0;background:transparent;font:700 19px var(--font-body);',
      'color:var(--navy);text-align:center;outline:none}',
    'body.dark .sl-team input{color:#fff}',
    '.sl-team .pic{width:40px;height:40px;border-radius:50%;object-fit:cover}',
    '.sl-tint{display:flex;gap:10px}',
    '.sl-tint button{flex:1;border:1.5px solid var(--line);border-radius:16px;background:#fff;'
      + 'padding:14px 10px;cursor:pointer;font:700 13px var(--font-body);color:var(--navy)}',
    'body.dark .sl-tint button{background:#12203A;border-color:#22345A;color:#fff}',
    '.sl-tint button.on{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4}',
    '.sl-tint .pal{display:block;width:100%;height:8px;border-radius:99px;margin-bottom:10px}',
    '.sl-tint small{display:block;font:500 11px/1.35 var(--font-body);color:var(--muted);margin-top:4px}',
    '.sl-team button{flex:0 0 auto;border:0;background:rgba(0,117,227,.1);color:#0075E3;border-radius:10px;',
      'padding:9px 11px;font:700 12px var(--font-body);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();

function slOpen(){ goId('s-scorelook'); slPaint(); }

/* ---------------------------------------------------------------------------------------
   L'anteprima

   Due strisce, una chiara e una scura, con la pillola sopra a tutte e due come si vestirebbe
   lì: quello che una spiegazione scritta non riesce a dire in tre righe, due pillole una
   sopra all'altra lo dicono in mezzo secondo.
   --------------------------------------------------------------------------------------- */
function slPillHtml(chiara){
  const cOld = chiara ? '#E5515F' : '#FF8A9B';
  const cNeo = slNeo(chiara);
  return '<span class="sl-pill ' + (chiara ? 'chiara' : 'scura') + '">'
    + slCrestHtml('Old', 'l')
    + '<b style="color:' + cOld + '">2</b><span class="sep">–</span><b style="color:' + cNeo + '">3</b>'
    + slCrestHtml('Neo', 'r')
    + '<span class="min">45\'</span></span>';
}

function slCrestHtml(lato, dove){
  return '<span class="cr ' + dove + '">' + slCrestTag(lato, 24) + '</span>';
}

function slPaint(){
  const prev = document.getElementById('slPrev');
  if (!prev) return;
  const skin = slSkin();

  /* Con «come sul computer» la pillola è scura da tutte e due le parti, con «segue il tema»
     dipende dal tema di adesso: l'anteprima deve mostrare quello che succederà davvero, non
     una vetrina che vale per un'impostazione sola. */
  const dark = document.body.classList.contains('dark');
  const suChiaro = skin === 'desktop' ? false : (skin === 'tema' ? !dark : false);
  const suScuro  = skin === 'desktop' ? false : (skin === 'tema' ? !dark : true);

  prev.innerHTML = '<div class="sl-stage">'
    + '<div class="sl-half light">' + slPillHtml(suChiaro) + '</div>'
    + '<div class="sl-half dark">' + slPillHtml(suScuro) + '</div>'
    + '</div>'
    + '<p class="sl-cap">Come si vede sopra a una app chiara, e sopra a una scura</p>';

  const modi = document.getElementById('slModi');
  if (modi) modi.innerHTML = SL_MODI.map(function(m){
    const on = m.k === skin;
    return '<button type="button" class="lp-row' + (on ? ' on' : '') + '" onclick="slPick(\'' + m.k + '\')">'
      + '<span class="lp-ic">' + m.ico + '</span>'
      + '<div class="lp-txt"><b>' + m.n + '</b><small>' + m.d + '</small></div>'
      + '<i class="lp-sw' + (on ? ' on' : '') + '"></i></button>';
  }).join('');

  const tint = document.getElementById('slTint');
  if (tint) tint.innerHTML = Object.keys(SL_TINTE).map(function(k){
    const t = SL_TINTE[k];
    return '<button type="button" class="' + (k === slTint() ? 'on' : '') + '" onclick="slPickTint(\'' + k + '\')">'
      + '<i class="pal" style="background:linear-gradient(90deg,' + t.forte + ',' + t.tenue + ')"></i>'
      + t.ico + ' ' + t.n + '<small>' + t.d + '</small></button>';
  }).join('');

  const teams = document.getElementById('slTeams');
  if (teams) teams.innerHTML = slTeamHtml('Old', 'Il vecchio te') + slTeamHtml('Neo', 'Il nuovo te');
}

function slTeamHtml(lato, nome){
  const img = slImg(lato);
  return '<div class="sl-team">'
    + '<span class="who">' + nome + '</span>'
    + (img
        ? '<img class="pic" src="' + img.replace(/"/g, '') + '" alt="">'
        : '<input type="text" maxlength="8" value="' + esc(slEmoji(lato)) + '" '
          + 'onchange="slSetEmoji(\'' + lato + '\', this.value)" aria-label="Emoji di ' + nome + '">')
    + (img
        ? '<button type="button" onclick="slClearImg(\'' + lato + '\')">Togli foto</button>'
        : '<button type="button" onclick="slPickImg(\'' + lato + '\')">🖼️ Foto</button>')
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   Le scelte
   --------------------------------------------------------------------------------------- */

async function slPick(k){
  if (typeof settingsSave === 'function') await settingsSave({ scoreSkin: k });
  else SETTINGS.scoreSkin = k;
  slPaint();
  slApply();
  const m = SL_MODI.filter(function(x){ return x.k === k; })[0];
  if (typeof toast === 'function' && m) toast('Tabellone: ' + m.n.toLowerCase());
}

async function slPickTint(k){
  if (typeof settingsSave === 'function') await settingsSave({ scoreTint: k });
  else SETTINGS.scoreTint = k;
  slTintApply();
  slPaint();
  slApply();
  /* La scheda START ha gia' i numeri disegnati: senza ridisegnarla il colore nuovo arriverebbe
     solo la prossima volta che qualcuno segna. */
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  if (typeof toast === 'function') toast('Il tuo punteggio adesso e\' ' + SL_TINTE[k].n.toLowerCase());
}

async function slSetEmoji(lato, v){
  const val = (v || '').trim().slice(0, 8);
  const patch = {};
  patch['scoreEmoji' + lato] = val;
  if (typeof settingsSave === 'function') await settingsSave(patch);
  else SETTINGS['scoreEmoji' + lato] = val;
  slPaint();
  slApply();
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
}

/* La foto dello stemma è larga 21 pixel sullo schermo: portarsela dietro a 320px sarebbe
   cinquanta volte la roba che serve, e ogni salvataggio delle impostazioni se la rifarebbe
   tutto il viaggio fino al motore. Novantasei pixel bastano anche sugli schermi più fitti. */
function slPickImg(lato){
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    const fr = new FileReader();
    fr.onload = function(){
      const img = new Image();
      img.onload = async function(){
        try{
          const S = 96, cv = document.createElement('canvas');
          cv.width = S; cv.height = S;
          const ctx = cv.getContext('2d');
          const side = Math.min(img.width, img.height);
          ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
          const out = cv.toDataURL('image/png');
          const patch = {};
          patch['scoreImg' + lato] = out;
          if (typeof settingsSave === 'function') await settingsSave(patch);
          else SETTINGS['scoreImg' + lato] = out;
          slPaint();
          slApply();
          try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
        }catch(e){
          if (typeof toast === 'function') toast('Non riesco a usare questa immagine');
        }
      };
      img.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questa immagine'); };
      img.src = fr.result;
    };
    fr.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questo file'); };
    fr.readAsDataURL(f);
  });
  document.body.appendChild(inp);
  inp.click();
}

async function slClearImg(lato){
  const patch = {};
  patch['scoreImg' + lato] = '';
  if (typeof settingsSave === 'function') await settingsSave(patch);
  else SETTINGS['scoreImg' + lato] = '';
  slPaint();
  slApply();
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
}

/* Il cambiamento deve arrivare alla bolla ADESSO. Il punteggio non è cambiato, quindi
   l'invio normale si fermerebbe da solo («è già quello di prima»): qui si azzera la memoria
   dell'ultimo invio, così il prossimo parte e porta con sé il vestito nuovo. */
function slApply(){
  slTintApply();
  try{
    if (typeof MT_SENT !== 'undefined') MT_SENT = null;
    if (typeof mtBroadcast === 'function' && typeof mtRoll === 'function') mtBroadcast(mtRoll());
  }catch(_){ }
}
