/* ===========================================================================================
   I DATI DEL COMPUTER, SUL TELEFONO

   IL BUCO CHE CHIUDE. Il Genio prevedeva il futuro leggendo il telefono. Ma chi lavora davanti
   a un computer passa lì la maggior parte delle sue ore sveglie, e una previsione costruita
   sulle sole app del telefono non descrive il lavoro: descrive le pause. «Ieri hai aperto
   Instagram quarantuno volte» è una frase esattissima su una fetta piccola, e muta sulla fetta
   grande — e presa da sola può dire il contrario del vero: quarantuno aperture in una giornata
   di nove ore di codice sono una persona che lavora e si distrae; le stesse quarantuno in una
   giornata vuota sono una persona che non ha fatto niente.

   DA DOVE ARRIVANO. FocusLock desktop scrive ogni dieci minuti una riga nello stesso archivio
   dove vivono i backup — un magazzino di documenti con una chiave, per account — esattamente
   come fa già il tabellone della partita. Qui quella riga si legge, non si scrive mai: il
   telefono non ha niente da dire al computer su come è andata la giornata al computer.

   COSA C'È DENTRO: per ogni giorno degli ultimi trenta, i minuti totali, la divisione in
   produttivo / distraente / neutro, e le otto cose su cui è finito più tempo. Non la cronologia
   al granello, che resta sul PC: sono centinaia di migliaia di righe contro un tetto di mezzo
   megabyte, e al telefono serve la forma della giornata, non ogni secondo.

   QUANDO NON C'È. Senza account, senza rete, o se il computer non è mai stato acceso, qui non
   c'è niente — e va detto invece di far finta che la giornata sia stata vuota. Un computer
   spento e un computer non collegato producono lo stesso zero, e confonderli sarebbe il modo
   più veloce di dare un giudizio falso a chi ha lavorato tutto il giorno.
   =========================================================================================== */

const PC_SLOT = 'fl:pc-usage';
const PC_SLOT_MOB = 'fl:mobile-usage';   // la riga che scrive il telefono, e che legge il computer
const PC_KEY = 'fl_pc_usage';
const PC = { doc: null, rigaAt: '', quando: 0, inCorso: null };

/* Ogni quanto vale la pena richiedere. Il desktop scrive ogni dieci minuti: chiedere più
   spesso paga una richiesta per avere due volte la stessa risposta. */
const PC_FRESCO_MS = 8 * 60000;

function pcPuo(){
  try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; }
}

function pcLeggiCache(){
  try{ return JSON.parse(localStorage.getItem(PC_KEY) || 'null'); }catch(_){ return null; }
}
function pcScriviCache(doc, rigaAt){
  try{ localStorage.setItem(PC_KEY, JSON.stringify({ doc: doc, rigaAt: rigaAt, at: Date.now() })); }catch(_){ }
}

/**
 * Prende i dati del computer, se ci sono.
 *
 * <p>Una chiamata sola quando la riga non è cambiata: le colonne di riepilogo viaggiano
 * nell'ELENCO delle righe, quindi i minuti di oggi si leggono senza scaricare il documento.
 * Il documento intero si scarica solo quando `updatedAt` si muove.</p>
 */
async function pcSync(forza){
  const cache = pcLeggiCache();
  if (cache && cache.doc && !forza && (Date.now() - (cache.at || 0)) < PC_FRESCO_MS){
    PC.doc = cache.doc; PC.rigaAt = cache.rigaAt || '';
    return PC.doc;
  }
  if (cache && cache.doc){ PC.doc = cache.doc; PC.rigaAt = cache.rigaAt || ''; }
  if (!pcPuo()) return PC.doc;

  /* Una richiesta alla volta: la pagina Timeline, il Genio e la scheda Profilo possono
     chiederli nello stesso istante, e tre richieste identiche in volo sono tre risposte
     uguali pagate tre volte. */
  if (PC.inCorso) return PC.inCorso;

  PC.inCorso = (async function(){
    try{
      const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
      const righe = (lista && lista.backups) || [];
      const riga = righe.filter(function(x){ return x && x.deviceId === PC_SLOT; })[0] || null;
      if (!riga) return PC.doc;

      const quando = String(riga.updatedAt || '');
      if (PC.doc && quando === PC.rigaAt){
        pcScriviCache(PC.doc, quando);      // solo per rinfrescare il timbro
        return PC.doc;
      }
      const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
      const doc = (pieno && pieno.payload) || null;
      if (doc && doc.kind === 'focuslock-pcusage'){
        PC.doc = doc; PC.rigaAt = quando;
        pcScriviCache(doc, quando);
      }
      return PC.doc;
    }catch(_){
      return PC.doc;                        // rete assente: si tiene quello che si sapeva
    }finally{
      PC.inCorso = null;
    }
  })();
  return PC.inCorso;
}

function pcChiave(off){
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** Un giorno di computer, o null se quel giorno non ne sappiamo niente. */
function pcGiorno(off){
  const g = (PC.doc && PC.doc.giorni) || null;
  if (!g) return null;
  return g[pcChiave(off)] || null;
}

/** Quanti dei giorni chiesti il computer li ha visti davvero. Serve a non dividere per zero. */
function pcGiorniNoti(n){
  const g = (PC.doc && PC.doc.giorni) || null;
  if (!g) return 0;
  let c = 0;
  for (let i = 0; i < n; i++) if (g[pcChiave(i)]) c++;
  return c;
}

/**
 * La media di una finestra, contata solo sui giorni che il computer ha visto.
 *
 * <p>Dividere per i giorni del calendario darebbe «due ore al giorno» a chi in tre giorni di
 * lavoro ne ha fatte sei ma ha spento il computer negli altri quattro: sarebbe una media su
 * giornate che non sono mai esistite.</p>
 */
function pcMedia(n){
  const g = (PC.doc && PC.doc.giorni) || null;
  if (!g) return null;
  let m = 0, prod = 0, distr = 0, visti = 0;
  for (let i = 0; i < n; i++){
    const d = g[pcChiave(i)];
    if (!d) continue;
    visti++;
    m += d.m || 0; prod += d.prod || 0; distr += d.distr || 0;
  }
  if (!visti) return null;
  return { min: m / visti, prod: prod / visti, distr: distr / visti, giorni: visti };
}

/** Le cose su cui è andato più tempo al computer nella finestra, sommate. */
function pcTop(n, quante){
  const g = (PC.doc && PC.doc.giorni) || null;
  if (!g) return [];
  const somma = {};
  for (let i = 0; i < n; i++){
    const d = g[pcChiave(i)];
    if (!d) continue;
    (d.top || []).forEach(function(t){
      const k = t.k || '';
      if (!somma[k]) somma[k] = { k: k, m: 0, c: t.c || 'Neutral' };
      somma[k].m += t.m || 0;
    });
  }
  return Object.keys(somma).map(function(k){ return somma[k]; })
    .sort(function(a, b){ return b.m - a.m; }).slice(0, quante || 5);
}

/**
 * Il riassunto per chi deve giudicare: il Genio e il motore di previsione.
 *
 * <p>Torna {@code null} quando il computer non ha mai raccontato niente — e chi lo riceve deve
 * comportarsi di conseguenza, cioè dire «del tuo computer non so niente» invece di dedurre
 * dallo zero che quel giorno non hai lavorato.</p>
 */
function pcRiassunto(){
  if (!PC.doc || !PC.doc.giorni) return null;
  const oggi = pcGiorno(0);
  const ieri = pcGiorno(1);
  const m30 = pcMedia(30);
  const m7 = pcMedia(7);
  if (!m30) return null;
  return {
    host: PC.doc.host || '',
    aggiornato: PC.doc.at || 0,
    oggi: oggi, ieri: ieri,
    media30: m30, media7: m7,
    giorniNoti30: pcGiorniNoti(30),
    top: pcTop(7, 5),
    /* La quota distraente è il numero che conta davvero: sei ore di computer non dicono niente
       finché non si sa quante erano lavoro. */
    quotaDistr: m7 && m7.min > 0 ? m7.distr / m7.min : 0
  };
}

function pcMinuti(m){
  m = Math.max(0, Math.round(m || 0));
  if (m < 60) return m + 'min';
  const h = Math.floor(m / 60);
  return (m % 60) ? h + 'h ' + (m % 60) + 'min' : h + 'h';
}

/** Le frasi che il computer può dire al Genio. Solo quelle che i numeri sostengono. */
function pcFrasi(){
  const r = pcRiassunto();
  if (!r) return [];
  const out = [];
  if (r.ieri && r.ieri.m > 0){
    out.push('Ieri al computer hai passato <strong>' + pcMinuti(r.ieri.m) + '</strong>, di cui '
      + pcMinuti(r.ieri.prod || 0) + ' su cose che hai marcato come lavoro.');
  }
  if (r.media7 && r.media7.min > 0 && r.quotaDistr >= 0.3){
    out.push('Al computer, in media, <strong>' + Math.round(r.quotaDistr * 100) + '%</strong> del '
      + 'tuo tempo finisce su cose che hai marcato come distrazioni.');
  }
  const capo = (r.top || [])[0];
  if (capo && capo.m > 60){
    out.push('La cosa su cui passi più tempo al computer è <strong>' + esc(capo.k) + '</strong>: '
      + pcMinuti(capo.m) + ' in sette giorni.');
  }
  return out;
}


/* ===========================================================================================
   LO SPECCHIO: il telefono scrive la sua riga, e ognuno dei due legge quella dell'altro

   Fin qui questo file faceva una cosa sola: leggere sul telefono la riga del computer. Ma il
   computer ha lo stesso buco, rovesciato — sa tutto delle nove ore di lavoro e niente delle
   due in divano. Da qui in giu' il file e' simmetrico: c'e' un LATO (chi sono) e un ALTRO
   (chi leggo), e nessuno dei due e' privilegiato.
   =========================================================================================== */

/** Su quale dei due schermi sto girando. Il computer si dichiara nel ponte che inietta lui. */
function pcQui(){
  try{
    if (window.Capacitor && typeof window.Capacitor.getPlatform === 'function'
        && window.Capacitor.getPlatform() === 'desktop') return 'desktop';
  }catch(_){ }
  return 'mobile';
}
/** La riga da leggere: quella dell'ALTRO, mai la propria. */
function pcSlotAltro(){ return pcQui() === 'desktop' ? PC_SLOT_MOB : PC_SLOT; }
function pcNomeAltro(){ return pcQui() === 'desktop' ? 'telefono' : 'computer'; }

const PC_ALTRO = { doc: null, at: 0, inCorso: null };
const PC_ALTRO_KEY = 'fl_altro_usage';

function pcAltroCache(){
  try{ return JSON.parse(localStorage.getItem(PC_ALTRO_KEY) || 'null'); }catch(_){ return null; }
}

/** Il riassunto dell'altro dispositivo, o null se quel dispositivo non ha mai parlato. */
async function pcAltroSync(forza){
  const cache = pcAltroCache();
  if (cache && cache.doc && cache.slot === pcSlotAltro()){
    PC_ALTRO.doc = cache.doc;
    if (!forza && (Date.now() - (cache.at || 0)) < PC_FRESCO_MS) return PC_ALTRO.doc;
  }
  if (!pcPuo()) return PC_ALTRO.doc;
  if (PC_ALTRO.inCorso) return PC_ALTRO.inCorso;

  PC_ALTRO.inCorso = (async function(){
    try{
      const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
      const slot = pcSlotAltro();
      const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === slot; })[0];
      if (!riga) return PC_ALTRO.doc;
      const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
      const doc = (pieno && pieno.payload) || null;
      if (doc && doc.giorni){
        PC_ALTRO.doc = doc;
        try{ localStorage.setItem(PC_ALTRO_KEY, JSON.stringify({ doc: doc, slot: slot, at: Date.now() })); }catch(_){ }
      }
      return PC_ALTRO.doc;
    }catch(_){
      return PC_ALTRO.doc;              // rete assente: si tiene quello che si sapeva
    }finally{
      PC_ALTRO.inCorso = null;
    }
  })();
  return PC_ALTRO.inCorso;
}

/* ---------------------------------------------------------------------------------------
   IL TELEFONO SCRIVE LA SUA RIGA

   DUE GIORNI ALLA VOLTA, non trenta. Il riassunto di ieri non cambia mai piu': riscriverlo
   ogni giorno sarebbe pagare trenta letture dell'archivio di sistema per riottenere trenta
   numeri gia' noti. Si aggiornano oggi (che si muove) e ieri (che si e' appena chiuso), e la
   storia si accumula da sola, un giorno per volta, esattamente come fa il computer.
   --------------------------------------------------------------------------------------- */

const PC_MIO_QUANDO = 'fl_mio_usage_at';

function pcMioChiave(off){
  const d = new Date(); d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** Un giorno di telefono nella stessa forma che usa il computer: minuti, diviso, e le top. */
async function pcMioGiorno(off){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange || !NATIVE.getTopApps) return null;
  const d = new Date(); d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  const da = d.getTime();
  const a = Math.min(Date.now(), da + 86400000);
  if (a <= da) return null;
  let range, top;
  try{
    range = await NATIVE.getScreenTimeRange({ from: da, to: a, bucket: 'none' });
    top = await NATIVE.getTopApps({ from: da, to: a, limit: 30, icons: 0 });
  }catch(_){ return null; }
  if (!range || !range.granted) return null;

  const cats = (typeof insCats === 'function') ? insCats() : {};
  const ex = (typeof insExcl === 'function') ? insExcl() : [];
  let prod = 0, distr = 0;
  const lista = ((top && top.apps) || []).filter(function(x){
    return x && !x.self && ex.indexOf(x.packageName) < 0;
  });
  lista.forEach(function(x){
    const c = cats[x.packageName];
    if (c === 'prod') prod += x.ms || 0;
    else if (c === 'distr') distr += x.ms || 0;
  });
  const min = function(ms){ return Math.round((ms || 0) / 60000); };
  return {
    m: min(range.ms),
    prod: min(prod),
    distr: min(distr),
    /* IL NOME DELL'APP, non il pacchetto: dall'altra parte dello specchio non c'e' nessuno
       che sappia tradurre com.zhiliaoapp.musically in «TikTok». */
    top: lista.slice(0, 8).map(function(x){
      return { k: x.label || x.packageName, m: min(x.ms),
               c: cats[x.packageName] === 'prod' ? 'Productive'
                  : cats[x.packageName] === 'distr' ? 'Distracting' : 'Neutral' };
    })
  };
}

/**
 * Scrive la riga del telefono, al massimo una volta ogni sei ore.
 *
 * <p>Non fa niente sul computer (che la sua riga la scrive da se') e non fa niente senza
 * account: senza cassetta non c'e' dove mettere il foglio.</p>
 */
async function pcMandaMio(forza){
  if (pcQui() !== 'mobile' || !pcPuo()) return false;
  let ultimo = 0;
  try{ ultimo = +localStorage.getItem(PC_MIO_QUANDO) || 0; }catch(_){ }
  if (!forza && Date.now() - ultimo < 6 * 3600000) return false;

  const oggi = await pcMioGiorno(0);
  if (!oggi) return false;                       // senza permesso d'uso non c'e' niente da dire
  const ieri = await pcMioGiorno(1);

  let doc = { kind: 'focuslock-mobileusage', giorni: {} };
  let id = '';
  try{
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === PC_SLOT_MOB; })[0];
    if (riga){
      id = riga.id;
      const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
      const vecchio = (pieno && pieno.payload) || null;
      if (vecchio && vecchio.giorni) doc.giorni = vecchio.giorni;
    }
  }catch(_){ /* prima volta, o rete assente: si riparte da un documento vuoto */ }

  doc.giorni[pcMioChiave(0)] = oggi;
  if (ieri) doc.giorni[pcMioChiave(1)] = ieri;
  doc.at = Date.now();
  doc.host = 'telefono';

  /* Sessanta giorni e non di piu': la cassetta ha un tetto di mezzo megabyte, e una storia
     che cresce all'infinito prima o poi smette di poter essere scritta — senza dirlo. */
  const chiavi = Object.keys(doc.giorni).sort();
  while (chiavi.length > 60) delete doc.giorni[chiavi.shift()];

  try{
    await NATIVE.accountApi({
      method: 'PUT', path: '/api/focuslock/backups',
      body: JSON.stringify({ deviceId: PC_SLOT_MOB, deviceName: 'Uso del telefono',
                             appVersion: 'mobileusage', backup: doc })
    });
    try{ localStorage.setItem(PC_MIO_QUANDO, String(Date.now())); }catch(_){ }
    return true;
  }catch(_){ return false; }
}

/* ---------------------------------------------------------------------------------------
   LA SEZIONE NEL REPORT
   --------------------------------------------------------------------------------------- */

const PC_SEZ_APERTA = 'fl_altro_aperta';

function pcSezAperta(){ try{ return localStorage.getItem(PC_SEZ_APERTA) === '1'; }catch(_){ return false; } }
function pcSezToggle(){
  try{ localStorage.setItem(PC_SEZ_APERTA, pcSezAperta() ? '0' : '1'); }catch(_){ }
  pcDipingiSezione();
}

function pcSezMedia(doc, n){
  const g = (doc && doc.giorni) || null;
  if (!g) return null;
  let m = 0, prod = 0, distr = 0, visti = 0;
  for (let i = 0; i < n; i++){
    const d = g[pcMioChiave(i)];
    if (!d) continue;
    visti++; m += d.m || 0; prod += d.prod || 0; distr += d.distr || 0;
  }
  return visti ? { min: m / visti, prod: prod / visti, distr: distr / visti, giorni: visti } : null;
}

function pcSezTop(doc, n, quante){
  const g = (doc && doc.giorni) || null;
  if (!g) return [];
  const somma = {};
  for (let i = 0; i < n; i++){
    const d = g[pcMioChiave(i)];
    if (!d) continue;
    (d.top || []).forEach(function(t){
      const k = t.k || '';
      if (!somma[k]) somma[k] = { k: k, m: 0, c: t.c || 'Neutral' };
      somma[k].m += t.m || 0;
    });
  }
  return Object.keys(somma).map(function(k){ return somma[k]; })
    .sort(function(a, b){ return b.m - a.m; }).slice(0, quante || 5);
}

/** Il contenitore. Va nell'HTML del Report anche quando e' vuoto: si riempie dopo. */
function pcSezSlot(){ return '<div id="pcSez"></div>'; }

async function pcDipingiSezione(){
  const box = document.getElementById('pcSez');
  if (!box) return;
  await pcAltroSync(false);
  const doc = PC_ALTRO.doc;
  const oggi = doc && doc.giorni ? doc.giorni[pcMioChiave(0)] : null;
  const m7 = pcSezMedia(doc, 7);
  /* CHI NON HA L'ALTRO DISPOSITIVO NON VEDE NIENTE. Una sezione vuota con dentro un invito a
     collegare qualcosa e' pubblicita' travestita da funzione, e occupa lo spazio di un dato
     vero. Compare il giorno in cui c'e' qualcosa da mostrare. */
  if (!doc || !m7){ box.innerHTML = ''; return; }

  const chi = pcNomeAltro();
  const titolo = chi === 'telefono' ? '\u{1F4F1} Il tuo telefono' : '\u{1F4BB} Il tuo computer';
  const aperta = pcSezAperta();
  const quota = m7.min > 0 ? Math.round((m7.distr / m7.min) * 100) : 0;

  let dentro = '';
  if (aperta){
    /* LA SETTIMANA A BARRE, ieri a destra e sei giorni fa a sinistra: i giorni che il
       dispositivo non ha visto restano vuoti, non a zero — un computer spento e uno non
       collegato fanno lo stesso zero, e non sono la stessa cosa. */
    const giorni = [];
    let massimo = 1;
    for (let i = 6; i >= 0; i--){
      const d = doc.giorni ? doc.giorni[pcMioChiave(i)] : null;
      const dt = new Date(); dt.setHours(0, 0, 0, 0); dt.setDate(dt.getDate() - i);
      giorni.push({ m: d ? (d.m || 0) : null, l: ['D', 'L', 'M', 'M', 'G', 'V', 'S'][dt.getDay()], oggi: i === 0 });
      if (d && d.m > massimo) massimo = d.m;
    }
    const barre = giorni.map(function(g){
      return '<div class="pcz-b' + (g.oggi ? ' oggi' : '') + '">'
        + (g.m === null ? '<i class="vuoto"></i>' : '<i style="height:' + Math.max(4, Math.round(g.m / massimo * 100)) + '%"></i>')
        + '<span>' + g.l + '</span></div>';
    }).join('');
    dentro = '<div class="pcz-in">'
      + '<div class="pcz-graf">' + barre + '</div>'
      + '<div class="pcz-num">'
      +   '<div><b>' + pcMinuti(oggi ? oggi.m : 0) + '</b><small>oggi</small></div>'
      +   '<div><b>' + pcMinuti(m7.min) + '</b><small>al giorno, su 7</small></div>'
      +   '<div><b>' + quota + '%</b><small>distrazioni</small></div>'
      + '</div>'
      + (oggi ? '' : '<p class="pcz-nota">Oggi il ' + chi + ' non ha ancora raccontato niente. '
          + 'Un ' + chi + ' spento e un ' + chi + ' non collegato fanno lo stesso zero, e non sono la stessa cosa.</p>')
      + pcSezTop(doc, 7, 5).map(function(t){
          const cl = /^Prod/i.test(t.c) ? 'prod' : /^Distr/i.test(t.c) ? 'distr' : 'neutro';
          return '<div class="pcz-r"><i class="' + cl + '"></i><b>' + esc(t.k) + '</b>'
            + '<small>' + pcMinuti(t.m) + '</small></div>';
        }).join('')
      + '<p class="pcz-nota">Ultime 24 ore e sette giorni, cos\u00ec come li ha visti il '
      +   chi + '.</p>'
      + '</div>';
  }

  box.innerHTML = '<div class="pcz' + (aperta ? ' on' : '') + '">'
    + '<button type="button" class="pcz-cap" onclick="pcSezToggle()">'
    +   '<b>' + titolo + '</b>'
    +   '<small>' + pcMinuti(m7.min) + ' al giorno</small>'
    +   '<span class="pcz-chev"></span></button>'
    + dentro + '</div>';
}

(function pczStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.pcz{border:1px solid var(--line);border-radius:18px;overflow:hidden;margin:18px 0}',
    '.pcz-cap{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;',
      'padding:15px 16px;cursor:pointer;text-align:left}',
    '.pcz-cap b{font:800 14px var(--font-display);color:var(--navy)}',
    'body.dark .pcz-cap b{color:#fff}',
    '.pcz-cap small{margin-left:auto;font:700 12px var(--font-body);color:var(--muted)}',
    /* La freccia gira invece di cambiare glifo: due caratteri diversi saltellano di mezzo
       pixel, una rotazione no. */
    '.pcz-chev{width:9px;height:9px;flex:none;border-right:2px solid var(--muted);',
      'border-bottom:2px solid var(--muted);transform:rotate(45deg) translate(-2px,-2px);',
      'transition:transform .2s}',
    '.pcz.on .pcz-chev{transform:rotate(225deg) translate(-1px,-1px)}',
    '.pcz-in{padding:0 16px 16px;border-top:1px solid var(--line)}',
    '.pcz-graf{display:flex;align-items:flex-end;gap:8px;height:96px;margin:16px 0 4px;padding:0 2px}',
    '.pcz-b{flex:1;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:5px}',
    '.pcz-b i{display:block;width:100%;border-radius:6px 6px 3px 3px;background:linear-gradient(180deg,var(--sky),var(--blue))}',
    '.pcz-b.oggi i{background:linear-gradient(180deg,#8CF0C8,#1B9E6A)}',
    '.pcz-b i.vuoto{height:4px;background:rgba(120,140,170,.25)}',
    '.pcz-b span{font:700 9.5px var(--font-body);color:var(--muted)}',
    '.pcz-num{display:flex;gap:10px;margin:12px 0 6px}',
    '.pcz-num div{flex:1;text-align:center}',
    /* Una riga sola: «5h 44min» spezzato a meta' fa saltare la colonna di mezzo di dodici
       pixel piu' in basso delle altre due, e tre numeri allineati diventano tre numeri
       messi a caso. */
    '.pcz-num b{display:block;font:800 17px/1.2 var(--font-display);color:var(--navy);white-space:nowrap}',
    'body.dark .pcz-num b{color:#fff}',
    '.pcz-num small{display:block;margin-top:3px;font:600 10.5px/1.35 var(--font-body);color:var(--muted)}',
    '.pcz-r{display:flex;align-items:center;gap:10px;padding:9px 0;border-top:1px solid var(--line)}',
    '.pcz-r i{width:9px;height:9px;border-radius:50%;flex:none;background:var(--muted)}',
    '.pcz-r i.prod{background:#0075E3}.pcz-r i.distr{background:#E63946}.pcz-r i.neutro{background:#8CC6FF}',
    '.pcz-r b{font:600 13px var(--font-body);color:var(--navy);overflow:hidden;',
      'text-overflow:ellipsis;white-space:nowrap}',
    'body.dark .pcz-r b{color:#fff}',
    '.pcz-r small{margin-left:auto;font:700 12px var(--font-body);color:var(--muted)}',
    '.pcz-nota{margin:12px 0 0;font:500 11.5px/1.6 var(--font-body);color:var(--muted)}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* La riga del telefono si scrive quando si apre il Report: e' il momento in cui i numeri di
   oggi sono appena stati letti, quindi non costa una seconda lettura dell'archivio. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'insights') return;
  setTimeout(function(){ try{ pcMandaMio(false); }catch(_){ } }, 3000);
});
