/* =========================================================================================
   FULL FOCUS A CICLI, E IL FULL FOCUS CHE PARTE DA SOLO.

   Due richieste, una sola idea: togliere la decisione. Alle 9 non si sceglie se cominciare,
   si e' gia' cominciato; finita una sessione non si sceglie se farne un'altra, parte da sola
   dopo la pausa. E' il Pomodoro di AppBlock (durata, pausa, numero di sessioni, ripetizione
   automatica) piu' i programmi a orario, che armano il Full Focus anche ad app chiusa.

   Chi fa cosa:
   · questa pagina scrive due impostazioni del motore — ffAuto (i programmi, le app consentite,
     la priorita' di oggi) e ffCiclo (la catena in corso) — e disegna la pausa;
   · il telefono (FocusAuto.java) ha la sveglia: avvia i programmi, fa partire la pausa quando
     una sessione del ciclo finisce e la sessione dopo quando la pausa finisce;
   · una sessione partita da sola, quando l'app si apre, viene ADOTTATA: diventa FF.run come
     se l'avessi fatta partire tu, con la sua pianta e il suo verdetto.
   ========================================================================================= */
const FFC = { prossimo: null, tick: 0 };
const FFC_KEY = 'fl_ff_auto';
const FFC_GIORNI = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];

function ffcCicli(){
  const p = ffPref();
  p.cicli = Object.assign({ on: false, pausa: 5, sessioni: 4, auto: true }, p.cicli || {});
  return p.cicli;
}
function ffcStato(){
  try{
    const raw = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS.ffCiclo : '';
    const s = raw ? JSON.parse(raw) : null;
    return (s && s.tot) ? s : null;
  }catch(_){ return null; }
}
function ffcNative(patch){
  try{ if (typeof SETTINGS !== 'undefined') Object.assign(SETTINGS, patch); }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) return NATIVE.setSettings(patch); }catch(_){ }
  return Promise.resolve();
}
function ffcMin(m){ return m >= 60 && m % 60 === 0 ? (m / 60) + 'h' : m + ' min'; }
function ffcOra(min){ return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }

/* ---------------------------------------------------------------- la pagina delle impostazioni
   Rifatta nella 0.9.201 dopo la bocciatura di Andrea («spazio inesistente, ordine, poca
   chiarezza»). Si apre dall'ingranaggio del foglio del Timer. Regole: UNA cosa in evidenza (i
   cicli, l'unica con l'emoji), sotto ogni voce una riga che dice cosa cambia per te, le scelte
   dei cicli raggruppate in una card sola, le altre due voci sono righe con la freccia. */
const FFC_SVG_BACK = '<svg viewBox="0 0 8 12" width="9" height="13" aria-hidden="true"><path fill="none" d="M7 1L2 6L7 11" stroke="currentColor" stroke-width="1.6"/></svg>';
function ffcTesta(titolo, indietro){
  return '<div class="ff-sh-head"><button type="button" class="ff-back" onclick="' + indietro + '" aria-label="Indietro">' + FFC_SVG_BACK + '</button><div class="ff-sh-title">' + titolo + '</div><span></span></div>';
}
function ffcRigaSw(tit, sub, on, fn){
  return '<div class="ffi-r"><div><b>' + tit + '</b><small>' + sub + '</small></div><button type="button" class="switch' + (on ? ' on' : '') + '" onclick="' + fn + '"></button></div>';
}
/* 0.9.335, Andrea: "non voglio le pill, i minuti escono dal bordo: metti un menu a tendina". Le pillole restano
   solo dove le scelte sono parole in colonna (la bolla); i numeri si scelgono da una tendina. */
function ffcRigaChips(tit, sub, vals, cur, fn, fmt, cls){
  if (cls !== 'col') return '<div class="ffi-r col"><div><b>' + tit + '</b><small>' + sub + '</small></div><label class="ffi-sel"><select onchange="' + fn + '(+this.value)">'
    + vals.map(function(v){ return '<option value="' + v + '"' + (v === cur ? ' selected' : '') + '>' + (fmt ? fmt(v) : v) + '</option>'; }).join('')
    + '</select><svg viewBox="0 0 12 8" width="12" height="8" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></label></div>';
  return '<div class="ffi-r col"><div><b>' + tit + '</b><small>' + sub + '</small></div><div class="ffi-chips' + (cls ? ' ' + cls : '') + '">'
    + vals.map(function(v){ return '<button type="button" class="' + (v === cur ? 'on' : '') + '" onclick="' + fn + '(' + v + ')">' + (fmt ? fmt(v) : v) + '</button>'; }).join('') + '</div></div>';
}
function ffcRigaVai(tit, sub, val, fn){
  return '<button type="button" class="ffi-r vai" onclick="' + fn + '"><div><b>' + tit + '</b><small>' + sub + '</small></div><span>' + val + '</span><svg class="chev" viewBox="0 0 8 12" width="8" height="12" aria-hidden="true"><path fill="none" d="M1 1l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>';
}
/* 0.9.326, Andrea: "troppe sezioni in un popover, e' confusionario: dividile in sottopagine come le impostazioni del Report, che ha quattro voci e tutto il resto vuoto" */
const FF_IMP = { k: '' };
const FFI_BOLLA_FMT = function(v){ return v.indexOf('su') >= 0 ? 'Il tempo passato' : (v.indexOf('giu') >= 0 ? 'Il tempo che manca' : 'Nessuna bolla'); };
const FF_IMP_T = { suono: 'Il suono', pausa: 'La pausa', cicli: 'I cicli', bolla: 'La bolla del tempo', schede: 'Le schede aperte' };
function ffImpostazioniApri(){
  /* 0.9.331, Andrea: "tornando indietro il popover e' chiuso invece di restare aperto": si ricorda da dove si e' venuti */
  const sh = document.getElementById('ffSheetWrap'), sub0 = document.getElementById('s-ff-imp'), sub1 = document.getElementById('s-ff-imp2');
  if (!(sub0 && sub0.classList.contains('active')) && !(sub1 && sub1.classList.contains('active'))) FF_IMP.daFoglio = !!(sh && sh.classList.contains('open'));
  try{ ffSheetClose(); }catch(_){ }
  const sub = document.getElementById('s-ff-imp2');
  if (sub && sub.classList.contains('active') && FF_IMP.k){ ffImpSezPaint(); return; }
  goId('s-ff-imp'); ffImpPaint();
}
function ffImpEsci(){
  goId('s-fullfocus'); try{ ffPaint(); }catch(_){ }
  if (FF_IMP.daFoglio){ FF_IMP.daFoglio = false; setTimeout(function(){ try{ ffTimerOpen(); }catch(_){ } }, 60); }
}
function ffSchermoToggle(){ const p = ffPref(); p.schermoNo = !p.schermoNo; ffSavePref(); try{ ffSchermoApplica(); }catch(_){ } ffImpPaint(); }
function ffImpPaint(){
  const box = document.getElementById('ffImpBody'); if (!box) return;
  const p = ffPref(), c = ffcCicli(), n = ffcProgrammi().filter(function(x){ return x.on; }).length;
  const riga = function(ico, t, val, fn){ return '<div class="setrow" onclick="' + fn + '"><span>' + ico + '</span><b>' + t + '</b><small>' + esc(val || '') + '</small><span class="chev"></span></div>'; };
  box.innerHTML = riga('🔊', 'Il suono', p.suonoAuto ? 'Parte da solo' : 'Silenzio', "ffImpSez('suono')")
    + riga('⏸️', 'La pausa', ffPausaPermessa() ? ffPausaMin() + ' min' : 'Spenta', "ffImpSez('pausa')")
    + riga('🍅', 'I cicli', c.on ? c.sessioni + ' sessioni' : 'Spenti', "ffImpSez('cicli')")
    + riga('🫧', 'La bolla del tempo', '', "ffImpSez('bolla')")
    + riga('⏰', 'Quando parte', n ? n + ' attiv' + (n === 1 ? 'o' : 'i') : 'Spento', 'ffcProgrammiApri()')
    + riga('🔓', 'Le schede aperte', '', "ffImpSez('schede')")
    /* 0.9.331, Andrea: di serie acceso, come su Forest */
    + '<div class="setrow"><span>☀️</span><b>Mantieni lo schermo acceso</b><small></small><button type="button" class="switch' + (p.schermoNo ? '' : ' on') + '" onclick="ffSchermoToggle()" aria-label="Mantieni lo schermo acceso"></button></div>'
    + '<div class="spacer"></div>';
}
function ffImpSez(k){ FF_IMP.k = k; goId('s-ff-imp2'); ffImpSezPaint(); }
function ffImpSezPaint(){
  const box = document.getElementById('ffImp2Body'), t = document.getElementById('ffImp2T'); if (!box) return;
  if (t) t.textContent = FF_IMP_T[FF_IMP.k] || '';
  const p = ffPref(), c = ffcCicli();
  let h = '';
  if (FF_IMP.k === 'suono'){
    h = '<div class="ffi-card">' + ffcRigaSw('Il suono parte da solo', p.suonoAuto ? 'Appena inizia la sessione parte l’ultimo suono che hai scelto.' : 'La sessione parte in silenzio: il suono lo accendi tu, toccando l’icona in alto.', !!p.suonoAuto, 'ffSuonoAutoToggle()') + '</div>'
      + '<p class="ffs-nota ffi-fuori">Un programma creato nella pagina dei suoni parte sempre da solo.</p>';
  } else if (FF_IMP.k === 'pausa'){
    const fuori = p.fuori !== 'continua';
    h = '<div class="ffi-card">' + ffcRigaSw('Puoi mettere in pausa', ffPausaPermessa() ? 'Durante la sessione vedi il pulsante della pausa.' : 'Durante la sessione il pulsante della pausa non c’è.', ffPausaPermessa(), 'ffPausaPrefToggle()')
      + (ffPausaPermessa() ? ffcRigaChips('Quanto dura', 'Alla fine la sessione riparte da sola.', [3, 5, 10], ffPausaMin(), 'ffPausaMinSet', function(v){ return v + ' min'; }) : '') + '</div>'
      + '<div class="ffi-sez">🚪 Quando esci dall’app</div>'
      + '<div class="ffi-card">' + ffcRigaSw('Il tempo si ferma', fuori ? 'Se vai su un’altra app il conto si ferma, e riprende quando torni.' : 'Il conto continua a scendere anche mentre sei su un’altra app.', fuori, 'ffFuoriToggle()')
      + (fuori ? ffcRigaChips('Si ferma al massimo per', 'Le app che hai consentito per la sessione non fermano il tempo.', [3, 5, 10, 15], ffFuoriMin(), 'ffFuoriMinSet', function(v){ return v + ' min'; }) : '') + '</div>';
  } else if (FF_IMP.k === 'cicli'){
    h = '<div class="ffi-card">' + ffcRigaSw('🍅 Cicli con pausa', c.on ? c.sessioni + ' sessioni da ' + p.minutes + ' min, con ' + c.pausa + ' min di pausa.' : 'Più sessioni di fila, con una pausa in mezzo.', c.on, 'ffcToggle()')
      + (c.on ? ffcRigaChips('Quante sessioni', 'Finite tutte, il ciclo è chiuso.', [2, 3, 4, 5, 6], c.sessioni, 'ffcSessioni', function(v){ return v + ' sessioni'; })
          + ffcRigaChips('Pausa fra una sessione e l’altra', 'Il telefono è libero per questi minuti.', [5, 10, 15, 20], c.pausa, 'ffcPausa', function(v){ return v + ' min'; })
          + ffcRigaSw('Riparte da sola', 'Finita la pausa, la sessione dopo parte senza toccare niente.', c.auto, 'ffcAuto()') : '') + '</div>';
  } else if (FF_IMP.k === 'bolla'){
    /* 0.9.335, Andrea: "ogni 5 minuti per qualche secondo... COSA succede? Manca il verbo, e l'utente deve vederla" */
    const mb = (typeof ffBollaModo === 'function') ? ffBollaModo() : 'su';
    h = '<div class="ffi-bolla-prev"><div class="ffi-bp-schermo"><i></i><i></i><i></i>'
      + (mb === 'off' ? '<span class="ffi-bp-off">Nessuna bolla</span>' : '<span class="ffi-bp-pill"><i class="ffi-bp-anello"></i><b>' + (mb === 'giu' ? '18:24' : '6:36') + '</b> ' + (mb === 'giu' ? 'alla fine della sessione' : 'di concentrazione') + '</span>')
      + '</div></div>'
      + '<p class="ffi-bolla-t">Durante una sessione, ogni 5 minuti compare per qualche secondo questa bolla con il tempo.</p>'
      + '<p class="ffi-bolla-s">La vedi sul telefono e sul computer, anche quando sei dentro a un’altra app.</p>'
      + '<div class="ffi-card">' + ffcRigaChips('Cosa mostra la bolla', 'Tocca una scelta per vederla qui sopra.', ["'su'", "'giu'", "'off'"], "'" + mb + "'", 'ffBollaModoSet', FFI_BOLLA_FMT, 'col') + '</div>';
  } else if (FF_IMP.k === 'schede'){
    h = (typeof ffsImpostazioniHtml === 'function') ? ffsImpostazioniHtml().replace(/<div class="ffi-sez">[\s\S]*?<\/div>/, '') : '';
  }
  box.innerHTML = h;
}
registerScreen('s-ff-imp', '<div class="topbar"><button class="iconbtn" onclick="ffImpEsci()" aria-label="Indietro">' + FFC_SVG_BACK + '</button><b class="blk-title">Impostazioni del Full Focus</b></div><div id="ffImpBody"></div>', { back: function(){ setTimeout(function(){ if (FF_IMP.daFoglio){ FF_IMP.daFoglio = false; try{ ffTimerOpen(); }catch(_){ } } }, 60); return 's-fullfocus'; } });
registerScreen('s-ff-imp2', '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-ff-imp\');ffImpPaint()" aria-label="Indietro">' + FFC_SVG_BACK + '</button><b class="blk-title" id="ffImp2T"></b></div><div id="ffImp2Body"></div>', { back: function(){ try{ ffImpPaint(); }catch(_){ } return 's-ff-imp'; } });
function ffcToggle(){ const c = ffcCicli(); c.on = !c.on; ffSavePref(); ffImpostazioniApri(); }
function ffcPausa(v){ ffcCicli().pausa = v; ffSavePref(); ffImpostazioniApri(); }
function ffcSessioni(v){ ffcCicli().sessioni = v; ffSavePref(); ffImpostazioniApri(); }
function ffcAuto(){ const c = ffcCicli(); c.auto = !c.auto; ffSavePref(); ffImpostazioniApri(); }

/* ---------------------------------------------------------------- la sessione che parte */
/** Il pezzo di catena della sessione che sta per partire, o null se e' una sessione sola. */
function ffcRunCiclo(p){
  if (FFC.prossimo){ const x = FFC.prossimo; FFC.prossimo = null; return x; }
  const c = ffcCicli();
  return c.on ? { n: 1, tot: c.sessioni, pausa: c.pausa, auto: c.auto } : null;
}
function ffcCompito(){
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    if (one && one.task) return String(one.task.text || one.task.t || one.task || '').slice(0, 120);
  }catch(_){ }
  return '';
}
function ffcListe(){
  const p = ffPref();
  const apps = (p.allow || []).slice(); if (apps.indexOf('com.dreambrothers.focuslock') < 0) apps.push('com.dreambrothers.focuslock');
  return { allowApps: apps, allow: (p.allowSites || []).slice(), allowWords: (p.allowWords || []).slice() };
}
/** Quello che il motore deve sapere della catena, scritto insieme all'orario di fine. */
function ffcEngineCiclo(run){
  if (!run || !run.ciclo) return '';
  return JSON.stringify(Object.assign({ n: run.ciclo.n, tot: run.ciclo.tot, pausa: run.ciclo.pausa, auto: run.ciclo.auto,
    minuti: run.minutes, task: ffcCompito(), inizio: run.startAt, pausaFino: 0 }, ffcListe()));
}
/** Rinuncia o «basta cosi'»: la catena si ferma, nessuna sessione dopo. */
async function ffcStop(){
  FFC.prossimo = null;
  try{ await ffcNative({ ffCiclo: '' }); }catch(_){ }
  try{ ffPaint(); }catch(_){ }
}
/** Dopo il verdetto di una sessione del ciclo: il motore ha gia' fatto partire la pausa. */
function ffcDopo(){
  setTimeout(async function(){
    try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
    /* se il telefono ha gia' aperto la sessione dopo (app chiusa durante la pausa), la si prende */
    if (!FF.run && typeof SETTINGS !== 'undefined' && +(SETTINGS && SETTINGS.ffUntil) > Date.now()){ ffcAdottaDaMotore(); return; }
    ffcTickAvvia();
    try{ ffPaint(); }catch(_){ }
  }, 1500);
}

/* ---------------------------------------------------------------- la pausa */
function ffcTickAvvia(){
  clearInterval(FFC.tick);
  FFC.tick = setInterval(function(){
    const s = ffcStato();
    if (!s || !s.pausaFino || FF.run){ clearInterval(FFC.tick); FFC.tick = 0; return; }
    /* la pausa e' finita e la sessione dopo parte da sola: la fa partire il telefono, qui la si adotta */
    if (s.auto && Date.now() > s.pausaFino + 2500){
      clearInterval(FFC.tick); FFC.tick = 0;
      ffcAdottaDaMotore();
      return;
    }
    const scr = document.getElementById('s-fullfocus');
    if (scr && scr.classList.contains('active')) ffPaint();
  }, 1000);
}
/** Disegno della pausa sulla schermata del timer. La chiama ffPaint quando non c'e' sessione. */
function ffcPaint(){
  const s = ffcStato();
  const st = document.getElementById('ffStatus'), cta = document.getElementById('ffCta');
  if (!s || !s.pausaFino || FF.run) return;
  const left = s.pausaFino - Date.now();
  const dopo = (s.n + 1) + ' di ' + s.tot;
  if (st){
    st.hidden = false;
    st.innerHTML = (left > 0
        ? '☕ <b>Pausa · ' + ffFmt(left) + '</b><br>' + (s.auto ? 'Poi la sessione ' + dopo + ' parte da sola' : 'Poi tocca a te: sessione ' + dopo)
        : (s.auto ? '▶️ <b>Sta ripartendo…</b>' : '☕ <b>Pausa finita</b>'))
      + '<br><button type="button" class="ff-link ffc-basta" onclick="ffcStop()">Basta così</button>';
  }
  if (cta){ cta.hidden = false; cta.textContent = (left > 0 ? 'Inizia subito la sessione ' : 'Inizia la sessione ') + dopo; }
  if (!FFC.tick && left > 0) ffcTickAvvia();
}
/** Il pulsante durante la pausa: la sessione dopo, adesso. */
function ffcProssimaOra(){
  const s = ffcStato();
  if (!s) return false;
  FFC.prossimo = { n: s.n + 1, tot: s.tot, pausa: s.pausa, auto: s.auto };
  const p = ffPref(); if (s.minuti) p.minutes = s.minuti;
  ffStart();
  return true;
}
function ffcInPausa(){ const s = ffcStato(); return !!(s && s.pausaFino && !FF.run); }

/* ---------------------------------------------------------------- le sessioni partite da sole */
/** Una sessione armata dal telefono senza che questa pagina la vedesse partire: diventa FF.run. */
async function ffcAdottaDaMotore(){
  try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
  ffcImporta();
  /* 0.9.309: ff-cicli.js si carica prima di settings.js; chiamata troppo presto, SETTINGS non esiste ancora */
  if (FF.run || typeof SETTINGS === 'undefined') return;
  const until = +(SETTINGS && SETTINGS.ffUntil) || 0;
  if (until <= Date.now()) { try{ ffPaint(); }catch(_){ } return; }
  const s = ffcStato() || {};
  const p = ffPref();
  let prev = null; try{ prev = SETTINGS.ffPrev ? JSON.parse(SETTINGS.ffPrev) : null; }catch(_){ }
  const from = +(SETTINGS.ffFrom) || s.inizio || Date.now();
  const run = { startAt: from, endAt: until, graceUntil: 0, minutes: s.minuti || Math.round((until - from) / 60000),
    tag: p.tag, intent: s.task || p.intent || '', intensive: true, meditazione: false, mode: 'allow', sound: p.sound, prev: prev,
    ciclo: s.tot ? { n: s.n, tot: s.tot, pausa: s.pausa, auto: s.auto } : null, daMotore: true };
  FF.run = run;
  ffWrite('fl_ff_session', run);
  clearInterval(FF.tick); FF.tick = setInterval(ffTickFn, 1000);
  if (ffPref().suonoAuto && run.sound && run.sound !== 'none'){ run.suonoOn = true; ffSoundStart(run.sound); }
  ffPaint();
}
/** Le sessioni finite ad app chiusa entrano nella storia (e nelle monete) una volta sola. */
function ffcImporta(){
  let log = [];
  try{ log = JSON.parse((SETTINGS && SETTINGS.ffAutoLog) || '[]') || []; }catch(_){ log = []; }
  if (!log.length) return;
  const hist = ffHist();
  let nuove = 0, monete = 0;
  log.forEach(function(r){
    if (!r || !r.s || !r.e) return;
    if (hist.some(function(h){ return h && Math.abs((h.start || 0) - r.s) < 60000; })) return;
    const min = +r.m || Math.round((r.e - r.s) / 60000);
    const coins = Math.round(min * 1.25);
    hist.push({ at: r.e, start: r.s, spentMs: Math.max(0, r.e - r.s), stage: 4, min: min, tag: ffPref().tag, ok: true, coins: coins,
      intent: r.t || '', intensive: true, meditazione: false, auto: true });
    nuove++; monete += coins;
  });
  if (!nuove) return;
  hist.sort(function(a, b){ return (a.at || 0) - (b.at || 0); });
  ffWrite('fl_ff_hist', hist.slice(-500));
  ffAddCoins(monete);
  try{ if (typeof dpCalcola === 'function') dpCalcola(true); }catch(_){ }
}

/* ---------------------------------------------------------------- i programmi */
function ffcProgrammi(){ try{ return JSON.parse(localStorage.getItem(FFC_KEY) || '[]') || []; }catch(_){ return []; } }
function ffcSalvaProgrammi(l){ try{ localStorage.setItem(FFC_KEY, JSON.stringify(l)); }catch(_){ } ffcPush(); }
/** Il motore riceve i programmi, le app consentite e la priorita' di oggi (per la notifica). */
function ffcPush(){
  const l = ffcProgrammi();
  const payload = Object.assign({ programmi: l, task: ffcCompito() }, ffcListe());
  ffcNative({ ffAuto: l.length ? JSON.stringify(payload) : '' });
}
function ffcGiorniTxt(g){
  const on = (g || []).map(function(x, i){ return x ? i : -1; }).filter(function(i){ return i >= 0; });
  if (on.length === 7) return 'Ogni giorno';
  if (on.length === 5 && on.join() === '0,1,2,3,4') return 'Lun–Ven';
  if (on.length === 2 && on.join() === '5,6') return 'Weekend';
  return on.map(function(i){ return ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'][i]; }).join(' ') || 'Nessun giorno';
}
function ffcProgrammiApri(){
  const l = ffcProgrammi();
  /* 0.9.335, Andrea: "quel popover fa cagare". Una cosa per volta: senza programmi un invito con il disegno,
     con i programmi l'ora grande e i giorni sotto, come una sveglia. */
  if (!l.length){
    ffSheetOpen(ffcTesta('Quando parte', 'ffImpostazioniApri()')
      + '<div class="ffc-v2"><span class="ffc-v2-ico">⏰</span><b>Fai partire il Full Focus da solo</b>'
      + '<p>Scegli un’ora e i giorni. A quell’ora la sessione inizia anche se l’app è chiusa.</p></div>'
      + '<button type="button" class="cta ff-go" onclick="ffcProgEdit(\'\')">Scegli l’ora</button>');
    return;
  }
  ffSheetOpen(ffcTesta('Quando parte', 'ffImpostazioniApri()')
    + l.map(function(x){
        return '<div class="ffc-prog ffc-prog2' + (x.on ? '' : ' spento') + '"><button type="button" class="ffc-prog-t" onclick="ffcProgEdit(\'' + x.id + '\')"><b>' + ffcOra(x.ora) + '</b>'
          + '<small>' + esc(ffcGiorniTxt(x.giorni)) + ' · ' + (x.sessioni > 1 ? x.sessioni + ' sessioni da ' : '') + ffcMin(x.minuti) + '</small></button>'
          + '<button type="button" class="switch' + (x.on ? ' on' : '') + '" onclick="ffcProgOn(\'' + x.id + '\')" aria-label="Acceso"></button></div>';
      }).join('')
    + '<p class="ffc-sotto">Lavora sulla priorità di oggi.</p>'
    + '<button type="button" class="ff-link ffc-add" onclick="ffcProgEdit(\'\')">＋ Aggiungi un altro orario</button>');
}
function ffcProgOn(id){
  const l = ffcProgrammi();
  const x = l.filter(function(y){ return y.id === id; })[0]; if (!x) return;
  x.on = !x.on; ffcSalvaProgrammi(l); ffcProgrammiApri();
  if (x.on && typeof toast === 'function') toast('⏰ Alle ' + ffcOra(x.ora) + ' parte da solo');
}
let FFC_ED = null;
function ffcProgEdit(id){
  const c = ffcCicli();
  const x = ffcProgrammi().filter(function(y){ return y.id === id; })[0];
  FFC_ED = x ? JSON.parse(JSON.stringify(x))
    : { id: 'p' + Date.now().toString(36), on: true, ora: 9 * 60, giorni: [true, true, true, true, true, false, false], minuti: ffPref().minutes || 50, sessioni: c.sessioni || 2, pausa: c.pausa || 10, auto: true };
  ffcEdPaint(!!x);
}
function ffcEdPaint(esiste){
  const e = FFC_ED; if (!e) return;
  ffSheetOpen(ffcTesta(esiste ? 'Modifica il programma' : 'Nuovo programma', 'ffcProgrammiApri()')
    + '<div class="ffi-sez">Quando</div>'
    + '<div class="ffi-card">'
    +   '<div class="ffi-r"><div><b>Ora</b><small>A quest’ora il Full Focus parte da solo.</small></div><input type="time" class="fin ffc-ora" value="' + ffcOra(e.ora) + '" onchange="ffcEdOra(this.value)"></div>'
    +   '<div class="ffi-r col"><div><b>Giorni</b><small>Solo nei giorni accesi.</small></div><div class="ffi-chips giorni">' + FFC_GIORNI.map(function(g, i){ return '<button type="button" class="' + (e.giorni[i] ? 'on' : '') + '" onclick="ffcEdGiorno(' + i + ')">' + g + '</button>'; }).join('') + '</div></div>'
    + '</div>'
    + '<div class="ffi-sez">Quanto</div>'
    + '<div class="ffi-card">'
    +   ffcRigaChips('Durata di una sessione', 'Minuti di concentrazione, senza interruzioni.', [15, 20, 25, 30, 45, 50, 60, 75, 90, 120].concat([15, 20, 25, 30, 45, 50, 60, 75, 90, 120].indexOf(e.minuti) < 0 ? [e.minuti] : []).sort(function(a, b){ return a - b; }), e.minuti, 'ffcEdMin', ffcMin)
    +   ffcRigaChips('Quante sessioni', 'Una sola, o un ciclo con le pause.', [1, 2, 3, 4, 5, 6], e.sessioni, 'ffcEdSes', function(v){ return v === 1 ? '1 sessione' : v + ' sessioni'; })
    +   (e.sessioni > 1
          ? ffcRigaChips('Pausa fra una sessione e l’altra', 'Il telefono è libero per questi minuti.', [5, 10, 15, 20], e.pausa, 'ffcEdPausa', function(v){ return v + ' min'; })
          + ffcRigaSw('Riparte da sola', 'Finita la pausa, la sessione dopo parte senza toccare niente.', e.auto, 'ffcEdAuto()')
          : '')
    + '</div>'
    + '<button type="button" class="cta ff-go" onclick="ffcEdSalva()">Salva</button>'
    + (esiste ? '<button type="button" class="ff-link ffc-del" onclick="ffcEdElimina()">Elimina il programma</button>' : ''));
}
function ffcEsiste(){ return FFC_ED && ffcProgrammi().some(function(y){ return y.id === FFC_ED.id; }); }
function ffcEdOra(v){ const m = /^(\d{1,2}):(\d{2})/.exec(v || ''); if (m && FFC_ED) FFC_ED.ora = Math.min(1439, (+m[1]) * 60 + (+m[2])); }
function ffcEdGiorno(i){ FFC_ED.giorni[i] = !FFC_ED.giorni[i]; ffcEdPaint(ffcEsiste()); }
function ffcEdMin(v){ FFC_ED.minuti = v; ffcEdPaint(ffcEsiste()); }
function ffcEdSes(v){ FFC_ED.sessioni = v; ffcEdPaint(ffcEsiste()); }
function ffcEdPausa(v){ FFC_ED.pausa = v; ffcEdPaint(ffcEsiste()); }
function ffcEdAuto(){ FFC_ED.auto = !FFC_ED.auto; ffcEdPaint(ffcEsiste()); }
function ffcEdSalva(){
  const e = FFC_ED; if (!e) return;
  if (!e.giorni.some(Boolean)){ toast('Scegli almeno un giorno'); return; }
  const max = typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 90;
  if (e.minuti > max){ toast('Al tuo livello arrivi a ' + max + ' minuti'); return; }
  const l = ffcProgrammi().filter(function(y){ return y.id !== e.id; });
  l.push(e); l.sort(function(a, b){ return a.ora - b.ora; });
  ffcSalvaProgrammi(l);
  FFC_ED = null;
  toast('⏰ Alle ' + ffcOra(e.ora) + ' parte da solo');
  ffcProgrammiApri();
}
async function ffcEdElimina(){
  const e = FFC_ED; if (!e) return;
  if (!(await blkEliminaChiedi())) return;
  ffcSalvaProgrammi(ffcProgrammi().filter(function(y){ return y.id !== e.id; }));
  FFC_ED = null;
  ffcProgrammiApri();
}

/* ---------------------------------------------------------------- l'avvio dell'app */
setTimeout(function(){
  (async function(){
    try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
    ffcImporta();
    /* la priorita' di oggi cambia: la notifica del programma deve dire quella giusta */
    if (ffcProgrammi().length) ffcPush();
    if (!FF.run && !(ffRead('fl_ff_session', null))) ffcAdottaDaMotore();
    if (ffcInPausa()) ffcTickAvvia();
  })();
}, 2500);
document.addEventListener('visibilitychange', function(){
  if (document.hidden) return;
  setTimeout(function(){ if (!FF.run) ffcAdottaDaMotore(); }, 600);
});

(function(){
  const css = [
    /* la pagina delle impostazioni (0.9.201): tre livelli di contrasto, una riga per voce, una card per gruppo */
    '.ffi-sez{margin:30px 2px 12px;font:800 19px var(--font-display);color:var(--navy)}',
    'body.dark .ffi-sez{color:#fff}',
    '.ffi-card{border:1px solid var(--line);border-radius:18px;padding:0 16px;background:var(--card,#fff)}',
    '.ffi-card.primo{margin-top:4px;background:#F3F5F8;border:0;padding:4px 18px}',
    '.ffi-r{display:flex;align-items:center;gap:14px;width:100%;padding:16px 0;border-top:1px solid var(--line);text-align:left}',
    '.ffi-r:first-child{border-top:0}.ffi-r > div:first-child{flex:1;min-width:0}',
    '.ffi-r b{display:block;font:800 15.5px/1.25 var(--font-body);color:var(--navy)}',
    '.ffi-r small{display:block;margin-top:4px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.ffi-r.col{flex-direction:column;align-items:stretch;gap:0}',
    '.ffi-r.vai{background:transparent;border-left:0;border-right:0;border-bottom:0;cursor:pointer;font:inherit;color:inherit}',
    '.ffi-r.vai > span{font:700 13.5px var(--font-body);color:var(--muted);white-space:nowrap}',
    '.ffi-r.vai .chev{flex:none;color:var(--muted)}',
    '.ffi-chips{display:flex;gap:8px;margin-top:12px}',
    /* 0.9.315: pillole con un margine vero intorno al testo; quelle con le parole lunghe vanno una per riga */
    '.ffi-chips button{flex:1;min-width:0;min-height:48px;border-radius:99px;border:1.5px solid var(--line);background:var(--card,#fff);font:800 14.5px/1.2 var(--font-body);color:var(--navy);cursor:pointer;padding:10px 8px}',
    '.ffi-chips.col{flex-direction:column}.ffi-chips.col button{flex:none;width:100%;padding:13px 20px}',
    '.ffi-chips button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.ffi-chips.giorni{gap:6px}.ffi-chips.giorni button{font-size:13px;padding:10px 0}',
    'body.dark .ffi-card{background:#12203A;border-color:#22345A}body.dark .ffi-card.primo{background:#0E1B33}',
    'body.dark .ffi-r{border-top-color:#22345A}body.dark .ffi-r b{color:#fff}',
    'body.dark .ffi-chips button{background:#16233A;border-color:#22345A;color:#fff}body.dark .ffi-chips button.on{background:#0075E3;border-color:#0075E3}',
    '#ffSheet .ffi-sez{text-align:center;margin:30px 0 12px}',
    '#ffSheet .ffi-card{margin-bottom:6px}',
    '#ffSheet .ffc-r.ffc-col > b,#ffSheet .ffc-r.ffc-col > small{text-align:center}',
    /* OEOF e colore selettivo: acceso solo quello scelto, il resto spento */
    '#ffSheet .ff-pre:not(.on){filter:grayscale(1);opacity:.62}',
    '.ffc-box{display:flex;flex-direction:column;gap:12px;margin:4px 0 12px;padding:12px 16px;border:1px solid var(--line);border-radius:16px}',
    '.ffc-r{display:flex;align-items:center;justify-content:space-between;gap:12px}',
    '.ffc-r.ffc-col{flex-direction:column;align-items:stretch;gap:8px}',
    '.ffc-r > b{font:800 14px var(--font-body);color:var(--navy);white-space:nowrap}',
    '.ffc-chips{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}',
    '.ffc-chips .ff-pre{padding:8px 14px}',
    '.ffc-giorni{flex-wrap:nowrap;gap:6px}',
    '.ffc-g{flex:1 1 0;min-width:0;max-width:40px;padding:8px 0 !important;text-align:center}',
    '.ffc-ora{max-width:120px;text-align:center}',
    '.ffc-prog-link{display:block;width:100%;margin:4px 0 16px;text-align:center}',
    '.ffc-sotto{margin:0 0 16px;font:500 13.5px/1.45 var(--font-body);color:var(--muted);text-align:center}',
    '.ffc-vuoto{margin:16px 0 24px;text-align:center;color:var(--muted)}',
    '.ffc-prog{display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;border:1px solid var(--line);border-radius:16px}',
    '.ffc-prog-t{flex:1;display:flex;flex-direction:column;align-items:flex-start;gap:4px;background:none;border:0;padding:0;text-align:left;cursor:pointer}',
    '.ffc-prog-t b{font:800 15px var(--font-body);color:var(--navy)}',
    '.ffc-prog-t small{font:500 12.5px var(--font-body);color:var(--muted)}',
    '.ffc-del{display:block;margin:12px auto 0;color:#E63946}',
    '.ffc-basta{margin-top:8px;color:#fff !important;opacity:.9;font-weight:700}',
    'body.dark .ffc-r > b, body.dark .ffc-prog-t b{color:#fff}',
    'body.dark .ffc-box, body.dark .ffc-prog{border-color:#22345A}'
  ].join('\n');
  const st = document.createElement('style'); st.id = 'ffc-css'; st.textContent = css;
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = ''
    + '.ffi-sel{position:relative;display:block;margin-top:10px}.ffi-sel select{width:100%;box-sizing:border-box;-webkit-appearance:none;appearance:none;border:1.5px solid #BCE0FF;border-radius:14px;padding:13px 40px 13px 14px;background:var(--card,#fff);color:var(--navy);font:700 15px var(--font-body);cursor:pointer}'
    + '.ffi-sel svg{position:absolute;right:15px;top:50%;margin-top:-4px;color:#0075E3;pointer-events:none}body.dark .ffi-sel select{background:#0B2550;border-color:#2C4A80;color:#fff}body.dark .ffi-sel svg{color:#8CC6FF}'
    + '.ffi-bolla-prev{display:flex;justify-content:center;margin:6px 0 18px}.ffi-bp-schermo{position:relative;width:230px;height:150px;border-radius:22px;background:linear-gradient(180deg,#DCEBFF,#F0FBFF);border:1.5px solid #BCE0FF;overflow:hidden;display:flex;flex-direction:column;gap:9px;padding:52px 18px 0;box-sizing:border-box}'
    + '.ffi-bp-schermo > i{display:block;height:9px;border-radius:5px;background:rgba(0,30,68,.1)}.ffi-bp-schermo > i:nth-child(2){width:78%}.ffi-bp-schermo > i:nth-child(3){width:58%}'
    + '.ffi-bp-pill{position:absolute;left:10px;top:12px;display:flex;align-items:center;gap:6px;padding:7px 12px 7px 9px;border-radius:99px;background:linear-gradient(90deg,#F6CCCC,#DFD2F8,#B8E5FF);color:#001E44;font:700 11.5px var(--font-body);white-space:nowrap;box-shadow:0 4px 12px rgba(0,30,68,.18);animation:ffiBp 2.4s ease-in-out infinite}'
    + '.ffi-bp-pill b{font:800 13px var(--font-body)}.ffi-bp-anello{width:11px;height:11px;border-radius:50%;border:2.5px solid #0075E3;box-sizing:border-box}'
    + '.ffi-bp-off{position:absolute;left:0;right:0;top:16px;text-align:center;font:700 12px var(--font-body);color:var(--muted)}'
    + '@keyframes ffiBp{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}'
    + '.ffi-bolla-t{margin:0 8px 6px;text-align:center;font:800 17px/1.35 var(--font-display);color:var(--navy)}.ffi-bolla-s{margin:0 8px 18px;text-align:center;font:500 14px/1.45 var(--font-body);color:var(--muted)}'
    + 'body.dark .ffi-bp-schermo{background:linear-gradient(180deg,#14305E,#0B2550);border-color:#2C4A80}body.dark .ffi-bp-schermo > i{background:rgba(255,255,255,.12)}'
    + '.ffc-v2{text-align:center;padding:10px 6px 22px}.ffc-v2-ico{display:inline-flex;align-items:center;justify-content:center;width:76px;height:76px;border-radius:50%;background:#F0FBFF;font-size:38px;line-height:1}'
    + '.ffc-v2 b{display:block;margin:16px 0 8px;font:800 19px var(--font-display);color:var(--navy)}.ffc-v2 p{margin:0 auto;max-width:290px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}body.dark .ffc-v2-ico{background:#14305E}'
    + '.ffc-prog2 .ffc-prog-t b{font:800 30px/1 var(--font-display);letter-spacing:-.01em}.ffc-prog2 .ffc-prog-t small{margin-top:6px}.ffc-prog2.spento .ffc-prog-t{opacity:.5}'
    + '.ffc-add{display:block;margin:6px auto 4px}';
  document.head.appendChild(st);
})();
