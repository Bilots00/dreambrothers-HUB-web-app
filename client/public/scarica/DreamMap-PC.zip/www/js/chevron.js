/* ===========================================================================================
   LE FRECCE SONO ICONE, NON CARATTERI (0.9.219)

   Andrea: «continui a usare il carattere › al posto dell'icona chevron». In giro per l'app ce ne
   sono decine, scritte a mano in ogni modulo («Apri il diario ›», «Visualizza altro ▾»). Invece di
   inseguirle una per una, qui si guarda il DOM: quando un testo comincia o finisce con una
   freccia-carattere (› ‹ ▸ ▾ ▴), la freccia diventa un'icona SVG a tratto, come quelle del tema
   Shopify, dello stesso colore del testo. Le frecce IN MEZZO a una frase («Impostazioni › App ›
   Batteria», un percorso da seguire) restano testo: li' sono separatori, non pulsanti.
   =========================================================================================== */
const FL_CHEV_PATH = { '›': 'M9 6l6 6-6 6', '‹': 'M15 6l-6 6 6 6', '▸': 'M9 6l6 6-6 6', '▾': 'M6 9l6 6 6-6', '▴': 'M6 15l6-6 6 6', '⌄': 'M6 9l6 6 6-6' };
function flChevSvg(ch){
  return '<svg class="fl-chev" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + FL_CHEV_PATH[ch] + '"/></svg>';
}
const FL_CHEV_RX = /^(\s*)([›‹▸▾▴⌄])(\s*)([\s\S]*?)(\s*)([›‹▸▾▴⌄]?)(\s*)$/;
function flChevTesto(n){
  const p = n.parentElement;
  if (!p || p.closest('svg, textarea, input, [contenteditable="true"], script, style, .no-chev')) return;
  const t = n.nodeValue;
  if (!t || !/[›‹▸▾▴⌄]/.test(t)) return;
  const testa = /^\s*[›‹▸▾▴⌄]/.test(t), coda = /[›‹▸▾▴⌄]\s*$/.test(t);
  if (!testa && !coda) return;
  /* una freccia in mezzo a un percorso («A › B ›») resta testo */
  const interne = t.replace(/^\s*[›‹▸▾▴⌄]/, '').replace(/[›‹▸▾▴⌄]\s*$/, '');
  if (/[›‹▸▾▴⌄]/.test(interne)) return;
  const frag = document.createDocumentFragment();
  const tmp = document.createElement('span');
  let resto = t;
  if (testa){ const ch = resto.trim().charAt(0); tmp.innerHTML = flChevSvg(ch); frag.appendChild(tmp.firstChild); resto = resto.replace(/^\s*[›‹▸▾▴⌄]/, ''); }
  let fine = null;
  if (coda){ const ch = resto.trim().slice(-1); if (FL_CHEV_PATH[ch]){ tmp.innerHTML = flChevSvg(ch); fine = tmp.firstChild; resto = resto.replace(/[›‹▸▾▴⌄]\s*$/, ''); } }
  if (resto) frag.appendChild(document.createTextNode(resto));
  if (fine) frag.appendChild(fine);
  p.replaceChild(frag, n);
}
function flChevScansiona(radice){
  if (!radice) return;
  if (radice.nodeType === 3){ flChevTesto(radice); return; }
  if (radice.nodeType !== 1 || radice.closest && radice.closest('svg')) return;
  const w = document.createTreeWalker(radice, NodeFilter.SHOW_TEXT, null);
  const lista = []; let n;
  while ((n = w.nextNode())) if (/[›‹▸▾▴⌄]/.test(n.nodeValue)) lista.push(n);
  lista.forEach(flChevTesto);
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.fl-chev{display:inline-block;vertical-align:-0.15em;flex:none}';
  document.head.appendChild(st);
  const parti = function(){
    flChevScansiona(document.body);
    new MutationObserver(function(ms){
      ms.forEach(function(m){
        if (m.type === 'characterData') flChevTesto(m.target);
        else m.addedNodes.forEach(function(n){ if (n.nodeType === 1) flChevScansiona(n); else if (n.nodeType === 3) flChevTesto(n); });
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  };
  if (document.body) parti(); else document.addEventListener('DOMContentLoaded', parti);
})();
