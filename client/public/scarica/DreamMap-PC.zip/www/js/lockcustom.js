/* =========================================================================================
   LA SCHERMATA DI BLOCCO PERSONALIZZATA, COPIATA DA APPBLOCK (0.9.283-284)

   0.9.284, Andrea: "hai messo icona, colore, testi e preferenze tutti nella stessa pagina, sotto
   al radio button, con un'anteprima quadrata: horror vacui. Devi scomporre in pagine separate,
   come AppBlock". Ritratto dal vero degli screenshot di AppBlock:
   - la pagina del programma ("Schermata di blocco"): Predefinita (con il collegamento a
     Personalizza) oppure Personalizzata (porta alla sua pagina);
   - "Personalizzate": X, titolo, Salva; l'anteprima grande come il telefono; in basso quattro
     pulsanti: Icona, Colore, Testo, Preferenze;
   - ogni pulsante apre la sua pagina con X e Salva: "Modifica testo" con Titolo, Sottotitolo e
     Pulsante di uscita (icona a sinistra, X per cancellare, "48 (massimo 60)"); "Preferenze" con
     Motivo del blocco (solo nei programmi), Scadenza schermata di blocco (meno, i secondi scritti
     da tastiera, piu', come nel foglio di START), Apri contatore, e nei programmi la pagina da
     aprire dopo il blocco.
   Dove vive: SETTINGS.lockCustom (Personalizza, stile "Personalizzata") e
   SETTINGS.schermateProgrammi[id] (modo "propria"); le legge BlockOverlay.buildCustom.
   ========================================================================================= */
const LC_DEF = { ico: 'app', emoji: '🛡️', colore: '#2F8FF0', titolo: '', sotto: '', bottone: 'Chiudi', scadenza: 0, contatore: false, motivo: true, url: '' };
const LC_COLORI = [['#2F8FF0', 'Blu'], ['#0075E3', 'Blu intenso'], ['#0E2350', 'Notte'], ['#5BC0F8', 'Azzurro'], ['#E5484D', 'Rosso'], ['#FF6FA8', 'Rosa'], ['grad', 'Rosa e azzurro']];
const LC_EMOJI = ['🛡️', '🚀', '🎯', '🔥', '🏆', '💎', '🧠', '⭐', '🌱', '⛔', '⏳', '🦁', '🗻', '📚', '💪'];
const LC = { ctx: 'globale', cfg: null, salvato: '', sub: '', tmp: null };
function lcEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function lcParse(v){ if (v && typeof v === 'object') return v; try{ return JSON.parse(v || '{}') || {}; }catch(_){ return {}; } }
function lcCfgGlobale(){ return Object.assign({}, LC_DEF, lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.lockCustom : '')); }
function lcProgDi(id){ const m = lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.schermateProgrammi : ''); return Object.assign({ modo: 'globale' }, LC_DEF, (id && m[id]) || {}); }
function lcSfondo(c){ return c === 'grad' ? 'linear-gradient(160deg,#FF8AC2,#5BC0F8)' : (c || '#2F8FF0'); }

/* le icone, a linea come quelle di AppBlock */
const LC_ICO = {
  x: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  icona: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M8.2 14.2c1 1.5 2.3 2.2 3.8 2.2s2.8-.7 3.8-2.2"/><circle cx="9" cy="9.8" r=".9" fill="currentColor"/><circle cx="15" cy="9.8" r=".9" fill="currentColor"/></svg>',
  colore: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h4v15a2 2 0 0 1-4 0z"/><path d="M9 7.5l3.2-3.2 2.8 2.8-6 6"/><path d="M13 21H7.5"/><path d="M13.5 15H21v6h-8z"/></svg>',
  testo: '<svg viewBox="0 0 24 24" width="32" height="32" fill="currentColor"><text x="1" y="18.5" font-size="15" font-family="Georgia,serif">Aa</text></svg>',
  pref: '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="8.5" cy="8.5" r="2.4"/><path d="M8.5 2.8v1.6M8.5 12.6v1.6M2.8 8.5h1.6M12.6 8.5h1.6M4.5 4.5l1.1 1.1M11.4 11.4l1.1 1.1M4.5 12.5l1.1-1.1M11.4 5.6l1.1-1.1"/><circle cx="16.5" cy="16.5" r="2.2"/><path d="M16.5 11.8v1.5M16.5 19.7v1.5M11.8 16.5h1.5M19.7 16.5h1.5M13.2 13.2l1 1M18.8 18.8l1 1M13.2 19.8l1-1M18.8 14.2l1-1"/></svg>',
  scudo: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>',
  timer: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 1.5M9.5 2.5h5"/></svg>',
  barre: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M8 16v-4M12 16V8M16 16v-6"/></svg>',
  link: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1"/><path d="M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/></svg>',
  tt: '<b class="lc-tt">Tt</b>',
  righe: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg>',
  pulsante: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="6" width="18" height="12" rx="2.5"/><path d="M8 12h8"/></svg>',
  freccia: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>'
};

/* ---------- l'anteprima: la schermata vera, in piccolo ---------- */
function lcIconaHtml(c, classe){
  if (c.ico === 'nessuna') return '';
  if (c.ico === 'emoji') return '<div class="' + classe + ' emo">' + lcEsc(c.emoji || '🛡️') + '</div>';
  if (c.ico === 'img'){
    const img = (typeof SETTINGS !== 'undefined' && SETTINGS.blockImage) ? String(SETTINGS.blockImage).replace(/"/g, '') : '';
    return '<div class="' + classe + ' img"' + (img ? ' style="background-image:url(' + img + ')"' : '') + '></div>';
  }
  /* l'icona dell'app bloccata, con il segno di DreamMap sopra (come lo scudo di AppBlock) */
  return '<div class="' + classe + ' app"><span>📷</span><i>' + LC_ICO.scudo + '</i></div>';
}
function lcSchermataHtml(c, conMotivo){
  const tit = (c.titolo || '').trim() || 'Instagram è bloccata';
  return lcIconaHtml(c, 'lc-s-ico')
    + '<h4 class="lc-s-tit">' + lcEsc(tit.replace('{app}', 'Instagram')) + '</h4>'
    + ((c.sotto || '').trim() ? '<p class="lc-s-sotto">' + lcEsc(c.sotto.replace('{app}', 'Instagram')) + '</p>' : '')
    + (!conMotivo || c.motivo !== false ? '<p class="lc-s-mot">Bloccata dal programma Social.</p>' : '')
    + (c.contatore ? '<p class="lc-s-cont"><b>Hai provato ad aprirla</b><br>3× quest’ora  |  41× in totale</p>' : '')
    + '<span class="lc-s-btn">' + lcEsc((c.bottone || '').trim() || 'Chiudi') + (c.scadenza ? ' · ' + c.scadenza + 's' : '') + '</span>';
}
/* per il carosello e per "Vedi a schermo intero" di Personalizza: la stessa schermata, nel loro riquadro */
function lcAnteprimaHtml(c, conMotivo){
  return '<div class="prev lc-prev-ls" style="background:' + lcSfondo(c.colore) + '">' + lcSchermataHtml(c, conMotivo) + '</div>';
}

/* ---------- la pagina "Personalizzate" ---------- */
function lcEdApri(ctx){
  LC.ctx = ctx === 'programma' ? 'programma' : 'globale';
  if (LC.ctx === 'programma'){
    const d = (typeof DRAFT !== 'undefined' && DRAFT) ? DRAFT : {};
    LC.cfg = Object.assign({}, LC_DEF, d.schermata || lcProgDi(d.id), { modo: 'propria' });
    if (!LC.cfg.url && d.redirectUrl) LC.cfg.url = d.redirectUrl;
  } else LC.cfg = lcCfgGlobale();
  LC.salvato = JSON.stringify(LC.cfg);
  goId('s-lc-ed');
  lcEdPaint();
}
function lcEdPaint(){
  const h = document.getElementById('lcEdBody'); if (!h || !LC.cfg) return;
  const conMotivo = LC.ctx === 'programma';
  h.innerHTML = '<div class="lc-top"><button type="button" class="lc-top-x" onclick="lcEdChiudi()" aria-label="Chiudi">' + LC_ICO.x + '</button><b>Personalizzate</b><button type="button" class="lc-top-ok" onclick="lcEdSalva()">Salva</button></div>'
    + '<div class="lc-ed-w"><div class="lc-ed-prev" style="background:' + lcSfondo(LC.cfg.colore) + '">' + lcSchermataHtml(LC.cfg, conMotivo) + '</div></div>'
    + '<div class="lc-tabs">'
    + [['icona', 'Icona'], ['colore', 'Colore'], ['testo', 'Testo'], ['pref', 'Preferenze']].map(function(t){ return '<button type="button" onclick="lcSubApri(\'' + t[0] + '\')">' + LC_ICO[t[0]] + '<span>' + t[1] + '</span></button>'; }).join('')
    + '</div>';
}
function lcSporco(){ return LC.cfg && JSON.stringify(LC.cfg) !== LC.salvato; }
function lcEdSalva(){
  const c = Object.assign({}, LC.cfg);
  if (LC.ctx === 'programma'){
    c.modo = 'propria';
    if (typeof DRAFT !== 'undefined' && DRAFT){
      DRAFT.schermata = c;
      DRAFT.redirectUrl = String(c.url || '').trim();
      const r = document.getElementById('edRedirect'); if (r) r.value = DRAFT.redirectUrl;
      /* un programma che esiste gia' la usa da subito; uno nuovo la salva insieme al programma */
      if (DRAFT.id && DRAFT.idx >= 0) lcSalvaProgramma(DRAFT.id, c);
    }
  } else {
    const v = JSON.stringify(c);
    if (typeof SETTINGS !== 'undefined'){ SETTINGS.lockCustom = v; SETTINGS.lockStyle = 'custom'; }
    try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ lockCustom: v, lockStyle: 'custom' }); }catch(_){ }
  }
  LC.salvato = JSON.stringify(LC.cfg);
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Schermata di blocco salvata');
  plkRigaPaint();
  lcIndietro();
}
/* si torna alla pagina di prima dalla storia (non da flIndietro: il tasto indietro di queste pagine chiama proprio
   lcEdChiudi e lcSubChiudi, e passare di nuovo da li' girerebbe all'infinito) */
function lcTorna(fallback){ const qui = order[cur]; if (!(typeof navTornaDietro === 'function' && navTornaDietro(qui))) goId(fallback); }
function lcIndietro(){ lcTorna(LC.ctx === 'programma' ? 's-prog-lock' : 's-lockscreen'); setTimeout(function(){ try{ plkPaint(); if (typeof lockScreenPaint === 'function' && order[cur] === 's-lockscreen') lockScreenPaint(); }catch(_){ } }, 60); }
function lcEdChiudi(){
  if (!lcSporco()){ lcIndietro(); return; }
  lcChiedi('Vuoi salvare le modifiche alla schermata di blocco?', 'Salva', function(){ lcEdSalva(); }, 'Esci senza salvare', function(){ LC.salvato = JSON.stringify(LC.cfg); lcIndietro(); });
}
/* la domanda prima di perdere delle modifiche: due pulsanti, ognuno col suo esito scritto */
function lcChiedi(testo, si, fSi, no, fNo){
  const w = document.createElement('div'); w.className = 'lc-chiedi';
  w.innerHTML = '<div class="lc-chiedi-in"><p>' + lcEsc(testo) + '</p><button type="button" class="cta">' + lcEsc(si) + '</button><button type="button" class="lc-chiedi-no">' + lcEsc(no) + '</button></div>';
  const via = function(){ w.remove(); };
  w.querySelector('.cta').onclick = function(){ via(); fSi(); };
  w.querySelector('.lc-chiedi-no').onclick = function(){ via(); fNo(); };
  w.addEventListener('click', function(e){ if (e.target === w) via(); });
  (document.getElementById('phone') || document.body).appendChild(w);
}

/* ---------- le sottopagine: Icona, Colore, Testo, Preferenze ---------- */
function lcSubApri(k){ LC.sub = k; LC.tmp = Object.assign({}, LC.cfg); goId('s-lc-sub'); lcSubPaint(); }
function lcSubSalva(){ LC.cfg = Object.assign({}, LC.tmp); try{ flVibra(10); }catch(_){ } lcTorna('s-lc-ed'); setTimeout(lcEdPaint, 30); }
function lcSubChiudi(){ LC.tmp = null; lcTorna('s-lc-ed'); setTimeout(lcEdPaint, 30); }
function lcSubPaint(){
  const h = document.getElementById('lcSubBody'); if (!h || !LC.tmp) return;
  const c = LC.tmp, k = LC.sub;
  const titolo = { icona: 'Icona', colore: 'Colore', testo: 'Modifica testo', pref: 'Preferenze' }[k] || '';
  let corpo = '';
  if (k === 'icona'){
    const voce = function(v, t){ return '<button type="button" class="lc-opt' + (c.ico === v ? ' on' : '') + '" onclick="lcTmp(\'ico\',\'' + v + '\')"><span>' + t + '</span><i></i></button>'; };
    corpo = voce('app', 'L’icona dell’app bloccata') + voce('emoji', 'Un’emoji') + voce('img', 'La tua immagine') + voce('nessuna', 'Nessuna icona');
    if (c.ico === 'emoji') corpo += '<div class="lc-emo">' + LC_EMOJI.map(function(e){ return '<button type="button" class="' + (c.emoji === e ? 'on' : '') + '" onclick="lcTmp(\'emoji\',\'' + e + '\')">' + e + '</button>'; }).join('') + '</div>';
    if (c.ico === 'img') corpo += '<button type="button" class="lc-img-btn" onclick="lcImmagine()">' + ((typeof SETTINGS !== 'undefined' && SETTINGS.blockImage) ? 'Cambia l’immagine' : 'Scegli l’immagine') + '</button>';
  } else if (k === 'colore'){
    corpo = '<div class="lc-col">' + LC_COLORI.map(function(x){ return '<button type="button" class="' + (c.colore === x[0] ? 'on' : '') + '" onclick="lcTmp(\'colore\',\'' + x[0] + '\')" aria-label="' + x[1] + '"><i style="background:' + lcSfondo(x[0]) + '"></i><span>' + x[1] + '</span></button>'; }).join('') + '</div>';
  } else if (k === 'testo'){
    const campo = function(chiave, lab, ico, max, ph){
      const v = c[chiave] || '';
      return '<p class="lc-lab">' + lab + '</p><div class="lc-campo"><span class="lc-campo-ico">' + ico + '</span><textarea rows="1" maxlength="' + max + '" placeholder="' + lcEsc(ph) + '" oninput="lcTesto(\'' + chiave + '\',this)">' + lcEsc(v) + '</textarea>'
        + '<button type="button" class="lc-campo-x" onclick="lcTestoVia(\'' + chiave + '\')" aria-label="Cancella">' + LC_ICO.x + '</button></div><small class="lc-conta" id="lcN_' + chiave + '">' + v.length + ' (massimo ' + max + ')</small>';
    };
    corpo = campo('titolo', 'Titolo', LC_ICO.tt, 60, 'Instagram è bloccata') + campo('sotto', 'Sottotitolo', LC_ICO.righe, 100, 'Ogni volta che lo vedo, ricordo perché ho iniziato.') + campo('bottone', 'Pulsante di uscita', LC_ICO.pulsante, 20, 'Chiudi');
  } else if (k === 'pref'){
    const riga = function(ico, t, destra, desc, clic){ return '<div class="lc-pref"' + (clic ? ' onclick="' + clic + '" role="button"' : '') + '><span class="lc-pref-ico">' + ico + '</span><b>' + t + '</b>' + destra + '</div><p class="lc-pref-d">' + desc + '</p>'; };
    const sw = function(on){ return '<span class="lc-sw' + (on ? ' on' : '') + '"><i></i></span>'; };
    if (LC.ctx === 'programma') corpo += riga(LC_ICO.scudo, 'Motivo del blocco', sw(c.motivo !== false), 'Mostra cosa ha causato il blocco (per esempio un Programma o Blocco rapido specifico)', 'lcTmp(\'motivo\',' + (c.motivo === false ? 'true' : 'false') + ')');
    corpo += riga(LC_ICO.timer, 'Scadenza schermata di blocco',
      '<div class="stt-qty lc-qty" onclick="event.stopPropagation()"><button type="button" onclick="lcScad(-5)" aria-label="Meno">−</button><input id="lcScadIn" type="number" inputmode="numeric" min="0" max="120" value="' + (c.scadenza || 0) + '" oninput="lcScadScritto(this.value)" onfocus="this.select()"><span>s</span><button type="button" onclick="lcScad(5)" aria-label="Più">+</button></div>',
      'Imposta una scadenza prima di poter chiudere la schermata di blocco.');
    corpo += riga(LC_ICO.barre, 'Apri contatore', sw(!!c.contatore), 'Mostra quante volte hai provato ad aprire l’app.', 'lcTmp(\'contatore\',' + (c.contatore ? 'false' : 'true') + ')');
    if (LC.ctx === 'programma') corpo += '<div class="lc-pref lc-pref-url"><span class="lc-pref-ico">' + LC_ICO.link + '</span><div><b>Pagina dopo il blocco</b><input class="fin" inputmode="url" autocomplete="off" placeholder="Vuota: quella di Personalizza" value="' + lcEsc(c.url || '') + '" oninput="LC.tmp.url=this.value.trim()"></div></div><p class="lc-pref-d">Si apre quando chiudi la schermata di blocco di questo programma.</p>';
  }
  h.innerHTML = '<div class="lc-top"><button type="button" class="lc-top-x" onclick="lcSubChiudi()" aria-label="Chiudi">' + LC_ICO.x + '</button><b>' + titolo + '</b><button type="button" class="lc-top-ok" onclick="lcSubSalva()">Salva</button></div><div class="lc-sub">' + corpo + '</div>';
  h.querySelectorAll('.lc-campo textarea').forEach(lcCresci);
}
function lcTmp(k, v){ if (!LC.tmp) return; LC.tmp[k] = v; try{ flVibra(8); }catch(_){ } lcSubPaint(); }
function lcCresci(t){ t.style.height = 'auto'; t.style.height = Math.min(140, t.scrollHeight) + 'px'; }
function lcTesto(k, el){ LC.tmp[k] = el.value; lcCresci(el); const n = document.getElementById('lcN_' + k); if (n) n.textContent = el.value.length + ' (massimo ' + el.maxLength + ')'; }
function lcTestoVia(k){ LC.tmp[k] = ''; lcSubPaint(); const t = document.querySelector('#lcSubBody textarea[oninput*="' + k + '"]'); if (t) t.focus(); }
function lcScad(d){ LC.tmp.scadenza = Math.max(0, Math.min(120, (+LC.tmp.scadenza || 0) + d)); const i = document.getElementById('lcScadIn'); if (i) i.value = LC.tmp.scadenza; try{ flVibra(8); }catch(_){ } }
function lcScadScritto(v){ const n = Math.round(+v); LC.tmp.scadenza = isFinite(n) ? Math.max(0, Math.min(120, n)) : 0; }
async function lcImmagine(){ if (typeof lockPick === 'function'){ await lockPick(); } lcSubPaint(); }

/* ---------- Personalizza: lo stile "Personalizzata" porta alla sua pagina ---------- */
function lsCustomPaint(){
  const box = document.getElementById('lsCustomBox'); if (!box) return;
  const on = (typeof SETTINGS !== 'undefined' && SETTINGS.lockStyle) === 'custom';
  box.hidden = !on;
  box.innerHTML = on ? '<button type="button" class="lc-vai" onclick="lcEdApri(\'globale\')"><span class="lc-vai-ico">' + LC_ICO.testo + '</span><span><b>Personalizza la schermata</b><small>Icona, colore, testi e preferenze</small></span>' + LC_ICO.freccia + '</button>' : '';
}

/* ---------- il programma: Predefinita o Personalizzata ---------- */
function plkTesto(){ const c = (typeof DRAFT !== 'undefined' && DRAFT && DRAFT.schermata) || null; return c && c.modo === 'propria' ? 'Personalizzata' : 'Predefinita'; }
function plkRigaPaint(){ const t = document.getElementById('edLockTxt'); if (t) t.textContent = plkTesto(); }
async function plkApri(){
  try{ if (typeof settingsLoad === 'function') await settingsLoad(); }catch(_){ }
  if (!DRAFT.schermata) DRAFT.schermata = lcProgDi(DRAFT.id);
  goId('s-prog-lock'); plkPaint();
}
function plkPaint(){
  const h = document.getElementById('plkBody'); if (!h || typeof DRAFT === 'undefined' || !DRAFT) return;
  const c = DRAFT.schermata || lcProgDi(DRAFT.id), propria = c.modo === 'propria';
  h.innerHTML = '<div class="pd-ops">'
    + '<div class="pd-op' + (propria ? '' : ' on') + '" role="button" onclick="plkModo(\'globale\')"><i></i><span><b>Predefinita</b><small>La schermata impostata in Personalizza, uguale per tutti i blocchi.</small>'
    +   (propria ? '' : '<button type="button" class="plk-vai" onclick="event.stopPropagation();goId(\'s-lockscreen\');if(typeof lockScreenPaint===\'function\')lockScreenPaint()">Modifica la schermata predefinita' + LC_ICO.freccia + '</button>') + '</span></div>'
    + '<div class="pd-op' + (propria ? ' on' : '') + '" role="button" onclick="plkModo(\'propria\')"><i></i><span><b>Personalizzata</b><small>Solo per questo programma: icona, colore, testi e preferenze.</small>'
    +   (propria ? '<button type="button" class="plk-vai" onclick="event.stopPropagation();lcEdApri(\'programma\')">Personalizza la schermata' + LC_ICO.freccia + '</button>' : '') + '</span></div>'
    + '</div>';
}
function plkModo(m){
  const prima = (DRAFT.schermata || lcProgDi(DRAFT.id)).modo;
  DRAFT.schermata = Object.assign({}, DRAFT.schermata || lcProgDi(DRAFT.id), { modo: m === 'propria' ? 'propria' : 'globale' });
  try{ flVibra(8); }catch(_){ }
  if (DRAFT.id && DRAFT.idx >= 0) lcSalvaProgramma(DRAFT.id, DRAFT.schermata);
  plkPaint(); plkRigaPaint();
  /* scegliere "Personalizzata" porta subito alla sua pagina */
  if (m === 'propria' && prima !== 'propria') lcEdApri('programma');
}
function plkIndietro(){ plkRigaPaint(); if (typeof flIndietro === 'function') flIndietro(); else goId('s-editor'); }
/** Al salvataggio del programma: la sua schermata va nel motore (solo se e' "propria"). */
function lcSalvaProgramma(id, cfg){
  if (!id) return;
  const m = lcParse(typeof SETTINGS !== 'undefined' ? SETTINGS.schermateProgrammi : '');
  if (cfg && cfg.modo === 'propria'){ const c = Object.assign({}, cfg); m[id] = c; } else delete m[id];
  const v = JSON.stringify(m); if (typeof SETTINGS !== 'undefined') SETTINGS.schermateProgrammi = v;
  try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ schermateProgrammi: v }); }catch(_){ }
}

const LC_INDIETRO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>';
registerScreen('s-prog-lock',
  '<div class="topbar"><button class="iconbtn" onclick="plkIndietro()" aria-label="Indietro">' + LC_INDIETRO + '</button><b class="blk-title">Schermata di blocco</b></div>'
  + '<div id="plkBody"></div><div class="spacer"></div>', { back: 's-editor' });
registerScreen('s-lc-ed', '<div id="lcEdBody" class="lc-ed"></div>', { back: function(){ lcEdChiudi(); return null; } });
registerScreen('s-lc-sub', '<div id="lcSubBody" class="lc-subw"></div>', { back: function(){ lcSubChiudi(); return null; } });
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* le pagine: niente imbottitura dello schermo, ci pensano loro */
    '#s-lc-ed,#s-lc-sub{padding:0;background:var(--bg)}',
    '.lc-ed{position:absolute;inset:0;display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}',
    '.lc-subw{position:absolute;inset:0;overflow-y:auto;padding-top:env(safe-area-inset-top,0px)}',
    '.lc-top{display:flex;align-items:center;gap:10px;padding:14px 16px 10px;flex:none}',
    '.lc-top b{flex:1;font:800 22px var(--font-body);color:var(--navy);text-align:left;margin-left:6px}',
    '.lc-top-x,.lc-top-ok{border:0;background:none;color:#2F8FF0;cursor:pointer;padding:6px;display:flex;align-items:center}',
    '.lc-top-ok{font:800 18px var(--font-body)}',
    /* l'anteprima grande come il telefono, al centro */
    '.lc-ed-w{flex:1;min-height:0;display:flex;align-items:center;justify-content:center;padding:6px 0 10px}',
    '.lc-ed-prev{height:100%;max-height:640px;aspect-ratio:.565;max-width:84vw;border-radius:30px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px 22px;box-sizing:border-box;color:#fff;box-shadow:0 18px 40px rgba(0,30,68,.22);overflow:hidden}',
    '.lc-s-ico{position:relative;width:96px;height:96px;border-radius:50%;margin-bottom:26px;flex:none}',
    '.lc-s-ico.app{background:radial-gradient(circle at 30% 107%,#fdf497 0%,#fd5949 45%,#d6249f 60%,#285AEB 90%);display:flex;align-items:center;justify-content:center;font-size:44px}',
    '.lc-s-ico.app i{position:absolute;left:-14px;top:-12px;width:42px;height:42px;border-radius:50%;background:#2F8FF0;color:#fff;display:flex;align-items:center;justify-content:center;border:3px solid rgba(255,255,255,.95)}',
    '.lc-s-ico.app i svg{width:22px;height:22px}',
    '.lc-s-ico.emo{background:none;font-size:72px;line-height:96px;width:auto}',
    '.lc-s-ico.img{border-radius:22px;background:rgba(255,255,255,.3) center/cover}',
    '.lc-s-tit{margin:0;font:800 28px/1.18 var(--font-body);color:#fff;overflow-wrap:anywhere}',
    '.lc-s-sotto{margin:16px 0 0;font:500 16px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.lc-s-mot{margin:16px 0 0;font:500 15px/1.45 var(--font-body);color:rgba(255,255,255,.72)}',
    '.lc-s-cont{margin:14px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.78)}.lc-s-cont b{color:#fff}',
    '.lc-s-btn{margin-top:26px;min-width:45%;padding:15px 28px;border-radius:99px;background:rgba(255,255,255,.28);font:800 17px var(--font-body);color:#fff;box-sizing:border-box}',
    /* i quattro pulsanti in basso */
    '.lc-tabs{flex:none;display:grid;grid-template-columns:repeat(4,1fr);padding:8px 8px calc(env(safe-area-inset-bottom,0px) + 14px);border-top:1px solid var(--line)}',
    '.lc-tabs button{border:0;background:none;color:var(--navy);display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px 0;cursor:pointer;font:600 15px var(--font-body)}',
    /* le sottopagine */
    '.lc-sub{padding:8px 18px 40px}',
    '.lc-lab{margin:22px 4px 10px;font:800 18px var(--font-body);color:var(--navy)}.lc-lab:first-child{margin-top:8px}',
    '.lc-campo{display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:26px;background:var(--card);border:1px solid var(--line)}',
    '.lc-campo:focus-within{border-color:#2F8FF0;box-shadow:0 0 0 2px #2F8FF0 inset}',
    '.lc-campo-ico{flex:none;width:30px;display:flex;justify-content:center;color:#2F8FF0}.lc-tt{font:700 22px var(--font-body);color:#2F8FF0}',
    '.lc-campo textarea{flex:1;border:0;background:none;resize:none;font:500 17px/1.35 var(--font-body);color:var(--navy);outline:none;padding:0;min-height:24px;overflow:hidden}',
    '.lc-campo-x{flex:none;border:0;background:none;color:var(--muted);cursor:pointer;padding:2px;display:flex}.lc-campo-x svg{width:20px;height:20px}',
    '.lc-conta{display:block;text-align:right;margin:8px 4px 0;font:500 14px var(--font-body);color:var(--muted)}',
    '.lc-pref{display:flex;align-items:center;gap:14px;padding:18px 18px;border-radius:26px;background:var(--card);border:1px solid var(--line);margin-top:14px;cursor:pointer}',
    '.lc-pref-ico{flex:none;color:#2F8FF0;display:flex}.lc-pref > b{flex:1;font:600 18px/1.3 var(--font-body);color:var(--navy)}',
    '.lc-pref-d{margin:10px 6px 0;font:500 14.5px/1.45 var(--font-body);color:var(--muted)}',
    '.lc-pref-url{cursor:default;align-items:flex-start}.lc-pref-url > div{flex:1}.lc-pref-url b{display:block;font:600 18px var(--font-body);color:var(--navy);margin-bottom:10px}.lc-pref-url .fin{width:100%;box-sizing:border-box}',
    '.lc-sw{flex:none;width:52px;height:32px;border-radius:99px;background:#C9D6E6;position:relative;transition:background .2s}',
    '.lc-sw i{position:absolute;top:4px;left:4px;width:24px;height:24px;border-radius:50%;background:#fff;transition:transform .2s}',
    '.lc-sw.on{background:#2F8FF0}.lc-sw.on i{transform:translateX(20px)}body.dark .lc-sw{background:#33415C}body.dark .lc-sw.on{background:#2F8FF0}',
    '.lc-qty{flex:none}.lc-qty button{width:40px!important}.lc-qty input{width:46px!important}',
    '.lc-opt{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:12px;padding:18px;border-radius:26px;background:var(--card);border:1px solid var(--line);font:600 17px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    '.lc-opt i{width:22px;height:22px;border-radius:50%;border:2px solid #9DB8D6;flex:none;box-sizing:border-box}.lc-opt.on{border-color:#2F8FF0}.lc-opt.on i{border:7px solid #2F8FF0}',
    '.lc-emo{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:16px}',
    '.lc-emo button{aspect-ratio:1;border-radius:18px;border:1.5px solid var(--line);background:var(--card);font-size:30px;cursor:pointer}.lc-emo button.on{border-color:#2F8FF0;box-shadow:0 0 0 2px #2F8FF0 inset}',
    '.lc-img-btn{margin-top:16px;width:100%;padding:16px;border-radius:99px;border:0;background:#2F8FF0;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.lc-col{display:grid;grid-template-columns:repeat(3,1fr);gap:18px 10px;margin-top:10px}',
    '.lc-col button{border:0;background:none;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;font:600 13.5px var(--font-body);color:var(--navy)}',
    '.lc-col button i{width:66px;height:66px;border-radius:50%;box-shadow:0 0 0 1px var(--line)}.lc-col button.on i{box-shadow:0 0 0 4px var(--bg),0 0 0 7px #2F8FF0}',
    /* il collegamento in Personalizza e nel programma */
    '.lc-vai{display:flex;align-items:center;gap:14px;width:100%;margin-top:14px;padding:16px 18px;border-radius:20px;border:1.5px solid var(--line);background:var(--card);color:var(--navy);cursor:pointer;text-align:left}',
    '.lc-vai > span:nth-child(2){flex:1}.lc-vai b{display:block;font:800 16px var(--font-body)}.lc-vai small{display:block;font:500 13.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.lc-vai-ico{color:#2F8FF0;display:flex}.lc-vai > svg{color:var(--muted)}',
    '.plk-vai{display:flex;align-items:center;gap:4px;margin-top:12px;padding:0;border:0;background:none;color:#2F8FF0;font:800 14.5px var(--font-body);cursor:pointer}',
    'body.dark .plk-vai,body.dark .lc-top-x,body.dark .lc-top-ok{color:#7FC0FF}',
    /* il carosello e lo schermo intero di Personalizza */
    '.ls-card .prev.lc-prev-ls{padding:18px 14px}.ls-card .lc-prev-ls .lc-s-ico{width:52px;height:52px;margin-bottom:12px;font-size:24px}.ls-card .lc-prev-ls .lc-s-ico.emo{font-size:40px;line-height:52px}.ls-card .lc-prev-ls .lc-s-ico.app i{width:24px;height:24px;left:-8px;top:-6px;border-width:2px}.ls-card .lc-prev-ls .lc-s-ico.app i svg{width:12px;height:12px}',
    '.ls-card .lc-prev-ls .lc-s-tit{font-size:17px}.ls-card .lc-prev-ls .lc-s-sotto,.ls-card .lc-prev-ls .lc-s-mot,.ls-card .lc-prev-ls .lc-s-cont{font-size:11px;margin-top:8px}.ls-card .lc-prev-ls .lc-s-btn{margin-top:14px;padding:8px 16px;font-size:11px;min-width:0}',
    '.ls-card .prev.lc-prev-ls p{margin-top:8px}',
    '.ls-full .prev.lc-prev-ls{height:100%;min-height:100%;border-radius:0;padding:40px 28px}',
    '.ls-full .prev.lc-prev-ls .lc-s-ico{width:96px;height:96px;margin-bottom:28px;font-size:44px}.ls-full .prev.lc-prev-ls .lc-s-ico.emo{font-size:76px;line-height:96px}',
    '.ls-full .prev.lc-prev-ls h4.lc-s-tit{font-size:30px;line-height:1.2;margin:0}',
    '.ls-full .prev.lc-prev-ls p.lc-s-sotto{margin-top:16px;font-size:17px;color:rgba(255,255,255,.85)}',
    '.ls-full .prev.lc-prev-ls p.lc-s-mot{margin-top:18px;font-size:15px;color:rgba(255,255,255,.75)}',
    '.ls-full .prev.lc-prev-ls p.lc-s-cont{margin-top:16px;font-size:15px}',
    '.ls-full .prev.lc-prev-ls .lc-s-btn{margin-top:34px;padding:16px 34px;font-size:17px}',
    /* la domanda prima di perdere le modifiche */
    '.lc-chiedi{position:fixed;inset:0;z-index:9900;background:rgba(6,16,43,.5);display:flex;align-items:flex-end;justify-content:center}',
    '.lc-chiedi-in{width:100%;max-width:520px;background:var(--card);border-radius:24px 24px 0 0;padding:24px 20px calc(env(safe-area-inset-bottom,0px) + 22px);display:flex;flex-direction:column;gap:10px}',
    '.lc-chiedi-in p{margin:0 0 8px;font:700 17px/1.4 var(--font-body);color:var(--navy);text-align:center}',
    '.lc-chiedi-no{border:0;background:none;padding:12px;font:700 15px var(--font-body);color:var(--muted);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();
