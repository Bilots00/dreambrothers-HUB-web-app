/* ===========================================================================================
   I TUOI FRENI (0.9.206) — il questionario che prende il posto di «Leggi me»

   Otto freni (content/blocchi.json), un modulo ripetuto: per ognuno un voto di impatto a
   quattro livelli e, se non e' «per niente», quattro sintomi a quattro livelli di frequenza.
   Alla fine una domanda di auto-identificazione, e il risultato CALCOLATO (non dichiarato):
     P = impatto × (1 + media dei sintomi), portato a 0-100
   freno principale = il massimo; secondari = quelli entro il 15% dal massimo.
   Il risultato (fl_blocchi) entra nel contesto dell'agente: la rotta ne tiene conto.
   =========================================================================================== */
const BQ = { c: null, i: 0, fase: 'intro', imp: {}, sin: {}, scelto: '', ordine: [], slide: 0, ris: null };
const BQ_KEY = 'fl_blocchi';
function bqEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function bqMd(s){ return bqEsc(s).replace(/\*([^*]+)\*/g, '<b>$1</b>'); }
async function bqCarica(){
  if (BQ.c) return BQ.c;
  const r = await fetch('content/blocchi.json', { cache: 'no-cache' }); BQ.c = await r.json(); return BQ.c;
}
function bqLeggi(){ try{ return JSON.parse(localStorage.getItem(BQ_KEY) || 'null'); }catch(_){ return null; } }

registerScreen('s-blocchi',
  '<div class="topbar"><button class="iconbtn" onclick="bqIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Il sabotatore invisibile</b></div>'
  + '<div class="bq-bar"><i id="bqBar"></i></div><div id="bqBody"></div><div class="spacer"></div>', { back: 's-home' });

async function blocchiApri(boss, ck){
  await bqCarica();
  BQ.boss = !!boss;
  /* LA RADIOGRAFIA DI CONTROLLO (0.9.212): nei capitoli dopo, lo stesso questionario rifatto
     da capo, per vedere se il paradigma si sta spostando */
  BQ.ck = ck || '';
  const v = bqLeggi();
  /* 0.9.279, Andrea: "se l'utente clicca su quel livello deve poterlo rifare, se lo vuole lui. Non glielo
     proponiamo noi alla fine". Gia' fatto: si sceglie fra rivedere il risultato e rifarlo da capo. */
  BQ.fase = (v && !ck) ? 'scelta' : 'intro'; BQ.i = 0; BQ.imp = {}; BQ.sin = {}; BQ.scelto = ''; BQ.ordine = []; BQ.slide = 0; BQ.ris = v;
  goId('s-blocchi'); bqPaint();
}
function bqIndietro(){
  if (BQ.fase === 'risultato' && BQ.slide > 0){ BQ.slide--; bqPaint(); return; }
  if (BQ.fase === 'blocco' && BQ.i > 0){ BQ.i--; bqPaint(); return; }
  if (BQ.fase === 'finale'){ BQ.fase = 'causa'; bqPaint(); return; }
  if (BQ.fase === 'causa'){ BQ.fase = 'blocco'; BQ.i = BQ.c.blocchi.length - 1; bqPaint(); return; }
  goId('s-home');
}
function bqRicomincia(){ BQ.fase = 'intro'; BQ.i = 0; BQ.imp = {}; BQ.sin = {}; BQ.scelto = ''; BQ.ordine = []; BQ.slide = 0; bqPaint(); }
/* L'ORDINE (0.9.278, Andrea): "non quale pensi sia il piu' grande, ma metterli in ordine, primo, secondo, terzo, quarto,
   quinto posto: e' l'esercizio molto piu' potente, perche' li confronti fra loro invece di tirare a indovinare". */
function bqDaOrdinare(){
  const C = BQ.c;
  let l = C.blocchi.filter(function(b){ return (BQ.imp[b.k] || 0) > 0; });
  if (l.length < 2) l = C.blocchi.slice();
  return l.sort(function(a, b){ return (BQ.imp[b.k] || 0) - (BQ.imp[a.k] || 0); });
}
function bqPosti(){ return Math.min(5, bqDaOrdinare().length); }
/* gli altri blocchi, quelli che non sono la causa principale: quelli che pesano, o tutti se pesano meno di due */
function bqAltri(){
  const C = BQ.c;
  let l = C.blocchi.filter(function(b){ return b.k !== BQ.scelto && (BQ.imp[b.k] || 0) > 0; });
  if (l.length < 2) l = C.blocchi.filter(function(b){ return b.k !== BQ.scelto; });
  return l.sort(function(a, b){ return (BQ.imp[b.k] || 0) - (BQ.imp[a.k] || 0); });
}
function bqOrdineLetto(){ return Array.prototype.map.call(document.querySelectorAll('#bqOrdine .bq-riga'), function(r){ return r.dataset.k; }); }
/* 0.9.295, Andrea: "al posto dei sei puntini le frecce per spostare su e giu'; e tenendo premuto, la stessa animazione delle
   schede del pannello di pianificazione". Tenendo premuta una riga si stacca una copia che segue il dito, il suo posto resta
   sbiadito e le altre scivolano per farle spazio; al rilascio la riga va al posto nuovo. Le frecce spostano di un posto. */
function bqNumeri(){ const box = document.getElementById('bqOrdine'); if (!box) return; box.querySelectorAll('.bq-riga').forEach(function(r, j){ const e = r.querySelector('.bq-posto'); if (e) e.textContent = (j + 2) + '°'; }); }
function bqSposta(k, d){
  const box = document.getElementById('bqOrdine'); if (!box) return;
  const righe = Array.prototype.slice.call(box.querySelectorAll('.bq-riga'));
  const i = righe.findIndex(function(x){ return x.dataset.k === k; }), j = i + d;
  if (i < 0 || j < 0 || j >= righe.length) return;
  const prima = righe.map(function(x){ return x.getBoundingClientRect().top; });
  if (d < 0) box.insertBefore(righe[i], righe[j]); else box.insertBefore(righe[j], righe[i]);
  const dopo = Array.prototype.slice.call(box.querySelectorAll('.bq-riga'));
  dopo.forEach(function(x){ const k0 = righe.indexOf(x), dy = prima[k0] - x.getBoundingClientRect().top; if (!dy) return; x.style.transition = 'none'; x.style.transform = 'translateY(' + dy + 'px)'; requestAnimationFrame(function(){ x.style.transition = 'transform .22s ease'; x.style.transform = ''; }); });
  bqNumeri(); BQ.ordine = bqOrdineLetto();
  try{ flVibra(8); }catch(_){ }
}
function bqTrascinaAttiva(){
  const box = document.getElementById('bqOrdine'); if (!box || box._tt) return; box._tt = true;
  box.addEventListener('pointerdown', function(e){
    const riga = e.target.closest('.bq-riga'); if (!riga || e.target.closest('.bq-frecce') || e.button > 0) return;
    const rr0 = Array.prototype.slice.call(box.querySelectorAll('.bq-riga'));
    const i = rr0.indexOf(riga), y0 = e.clientY, x0 = e.clientX;
    let attivo = false, a = i, fant = null, rr = [], passo = 0, dy = 0;
    const timer = setTimeout(function(){
      attivo = true;
      rr = rr0.map(function(x){ return x.getBoundingClientRect(); });
      const r = rr[i]; passo = (rr[1] ? rr[1].top - rr[0].top : r.height + 10); dy = y0 - r.top;
      fant = riga.cloneNode(true); fant.classList.add('bq-fant');
      Object.assign(fant.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
      document.body.appendChild(fant); riga.classList.add('bq-presa');
      rr0.forEach(function(x){ x.style.transition = 'transform .18s ease'; });
      try{ flVibra(15); }catch(_){ }
    }, e.pointerType === 'mouse' ? 120 : 260);
    const disponi = function(){
      rr0.forEach(function(x, j){
        let t = 0;
        if (a > i && j > i && j <= a) t = -passo;
        if (a < i && j >= a && j < i) t = passo;
        if (j !== i) x.style.transform = t ? 'translateY(' + t + 'px)' : '';
      });
      riga.style.transform = a !== i ? 'translateY(' + ((a - i) * passo) + 'px)' : '';
    };
    const muovi = function(ev){
      if (!attivo){ if (Math.hypot(ev.clientX - x0, ev.clientY - y0) > 8) fine(); return; }
      if (ev.cancelable) ev.preventDefault();
      fant.style.top = (ev.clientY - dy) + 'px';
      let n = i;
      for (let j = 0; j < rr.length; j++){ if (j === i) continue; const c = rr[j].top + rr[j].height / 2; if (j > i && ev.clientY > c) n = j; if (j < i && ev.clientY < c && n === i) n = j; }
      if (n !== a){ a = n; disponi(); try{ flVibra(6); }catch(_){ } }
    };
    const ferma = function(ev){ if (attivo && ev.cancelable) ev.preventDefault(); };
    const fine = function(){
      clearTimeout(timer);
      window.removeEventListener('pointermove', muovi); window.removeEventListener('pointerup', su); window.removeEventListener('pointercancel', su);
      window.removeEventListener('touchmove', ferma);
    };
    const su = function(){
      fine(); if (!attivo) return;
      if (fant) fant.remove();
      rr0.forEach(function(x){ x.style.transition = 'none'; x.style.transform = ''; });
      riga.classList.remove('bq-presa');
      if (a !== i){ const resto = rr0.filter(function(x){ return x !== riga; }); if (a >= resto.length) box.appendChild(riga); else box.insertBefore(riga, resto[a]); }
      bqNumeri(); BQ.ordine = bqOrdineLetto(); try{ flVibra(10); }catch(_){ }
    };
    window.addEventListener('pointermove', muovi, { passive: false }); window.addEventListener('pointerup', su); window.addEventListener('pointercancel', su);
    window.addEventListener('touchmove', ferma, { passive: false });
  });
}
function bqOrdina(k){
  const i = BQ.ordine.indexOf(k);
  if (i >= 0) BQ.ordine.splice(i, 1);
  else if (BQ.ordine.length < bqPosti()) BQ.ordine.push(k);
  BQ.scelto = BQ.ordine[0] || '';
  try{ flVibra(8); }catch(_){ }
  bqPaint();
}
function bqPaint(){
  const h = document.getElementById('bqBody'); if (!h || !BQ.c) return;
  const C = BQ.c, n = C.blocchi.length;
  const bar = document.getElementById('bqBar');
  if (bar) bar.style.width = (BQ.fase === 'intro' ? 0 : BQ.fase === 'risultato' ? 100 : BQ.fase === 'finale' ? 92 : Math.round(8 + BQ.i / n * 84)) + '%';
  const barra = document.querySelector('#s-blocchi .bq-bar');
  /* una sola barra per volta: nel questionario quella dell'avanzamento, nel risultato le lineette delle schermate */
  if (barra) barra.style.display = (BQ.fase === 'risultato' || BQ.fase === 'scelta' || BQ.fase === 'intro') ? 'none' : '';
  /* 0.9.281, Andrea (come il quiz di VMR Consulting): prima la causa principale, scelta da lui; poi gli altri in ordine */
  if (BQ.fase === 'causa'){
    const cc = C.causa || { domanda: 'Quale pensi sia *la causa principale*?', sotto: '' };
    h.innerHTML = '<p class="bq-eti">La causa principale</p><p class="bq-q">' + bqMd(cc.domanda) + '</p>' + (cc.sotto ? '<p class="bq-sotto">' + bqEsc(cc.sotto) + '</p>' : '')
      /* 0.9.295, Andrea: "nella causa principale compaiono anche quelli a cui ho risposto Per niente": solo quelli che pesano
         almeno un po' (tutti, se ne pesa uno solo o nessuno) */
      + '<div class="bq-lista">' + (function(){ const pes = C.blocchi.filter(function(b){ return (BQ.imp[b.k] || 0) > 0; }); return pes.length >= 2 ? pes : C.blocchi.slice(); })().sort(function(a, b){ return (BQ.imp[b.k] || 0) - (BQ.imp[a.k] || 0); }).map(function(b){
          return '<button type="button" class="' + (BQ.scelto === b.k ? 'on' : '') + '" onclick="BQ.scelto=\'' + b.k + '\';BQ.ordine=[];try{flVibra(8)}catch(_){};bqPaint()"><span>' + b.emoji + '</span>' + bqEsc(b.nome) + '</button>';
        }).join('') + '</div>'
      + '<button type="button" class="cta bq-avanti"' + (BQ.scelto ? '' : ' disabled') + ' onclick="BQ.fase=\'finale\';bqPaint();const s=document.getElementById(\'s-blocchi\');if(s)s.scrollTop=0">Avanti</button>';
    return;
  }
  if (BQ.fase === 'scelta'){
    const d = BQ.ris && BQ.ris.at ? new Date(BQ.ris.at).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }) : '';
    h.innerHTML = '<div class="bq-intro bq-scelta"><span class="bq-ico">🕵️</span><h2>L\u2019hai già smascherato</h2>'
      + '<p>' + (d ? 'L\u2019ultima volta, il ' + d + '. ' : '') + 'Puoi rivedere cosa era venuto fuori, o rifarlo da capo per vedere se qualcosa è cambiato.</p>'
      + '<button type="button" class="cta" onclick="BQ.fase=\'risultato\';BQ.slide=0;bqPaint()">Rivedi il risultato</button>'
      + '<button type="button" class="bq-rifai" onclick="bqRicomincia()">Rifallo da capo</button></div>';
    return;
  }
  if (BQ.fase === 'intro'){
    h.innerHTML = '<div class="bq-intro">' + (BQ.boss ? '<p class="bq-eti">Il boss del capitolo</p>' : '') + '<span class="bq-ico">' + (BQ.boss ? '🐉' : '🧞') + '</span><h2>' + bqEsc(C.intro.titolo) + '</h2><p>' + bqEsc(C.intro.sotto) + '</p><small>' + bqEsc(C.intro.durata) + '</small>'
      + '<button type="button" class="cta" onclick="BQ.fase=\'blocco\';BQ.i=0;bqPaint()">Comincia</button></div>';
    return;
  }
  if (BQ.fase === 'blocco'){
    const b = C.blocchi[BQ.i]; const imp = BQ.imp[b.k]; const sin = BQ.sin[b.k] || {};
    let html = '<p class="bq-eti">Blocco ' + (BQ.i + 1) + ' di ' + n + '</p><div class="bq-testa"><span>' + b.emoji + '</span><h2>' + bqEsc(b.nome) + '</h2></div>'
      + '<p class="bq-q">' + bqMd(b.impatto) + '</p>'
      + '<div class="bq-scala">' + C.scala_impatto.map(function(t, i){ return '<button type="button" class="' + (imp === i ? 'on' : '') + '" onclick="bqImpatto(' + i + ')">' + bqEsc(t) + '</button>'; }).join('') + '</div>';
    if (imp > 0){
      html += '<p class="bq-sotto">Quanto spesso ti capita?</p><div class="bq-sintomi">' + b.sintomi.map(function(s, j){
        return '<div class="bq-sin"><p>' + bqEsc(s) + '</p><div class="bq-chips">' + C.scala_sintomi.map(function(t, v){ return '<button type="button" class="' + (sin[j] === v ? 'on' : '') + '" onclick="bqSintomo(' + j + ',' + v + ')">' + bqEsc(t) + '</button>'; }).join('') + '</div></div>';
      }).join('') + '</div>';
    }
    const pronto = imp === 0 || (imp > 0 && b.sintomi.every(function(_, j){ return sin[j] != null; }));
    html += '<button type="button" class="cta bq-avanti"' + (pronto ? '' : ' disabled') + ' onclick="bqAvanti()">' + (BQ.i === n - 1 ? 'Ultima domanda' : 'Avanti') + '</button>';
    h.innerHTML = html;
    return;
  }
  if (BQ.fase === 'finale'){
    const altri = bqAltri();
    if (!BQ.ordine.length) BQ.ordine = altri.map(function(b){ return b.k; });
    const by = {}; C.blocchi.forEach(function(b){ by[b.k] = b; });
    const primo = by[BQ.scelto];
    h.innerHTML = '<p class="bq-eti">L’ultima</p><p class="bq-q">' + bqMd(C.finale.domanda) + '</p><p class="bq-sotto">' + bqEsc(C.finale.sotto) + '</p>'
      + (primo ? '<div class="bq-primo"><em class="bq-posto">1°</em><span>' + primo.emoji + '</span><b>' + bqEsc(primo.nome) + '</b><small>la causa principale</small></div>' : '')
      + '<div class="bq-lista bq-ordine bq-trascina" id="bqOrdine">' + BQ.ordine.map(function(k, j){ const b = by[k]; if (!b) return '';
          return '<div class="bq-riga" data-k="' + k + '"><em class="bq-posto">' + (j + 2) + '°</em><span>' + b.emoji + '</span><b>' + bqEsc(b.nome) + '</b>'
            + '<span class="bq-frecce"><button type="button" aria-label="Sposta su" onclick="bqSposta(\'' + k + '\',-1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg></button>'
            + '<button type="button" aria-label="Sposta giù" onclick="bqSposta(\'' + k + '\',1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button></span></div>'; }).join('') + '</div>'
      + '<button type="button" class="cta bq-avanti" onclick="BQ.ordine=[BQ.scelto].concat(bqOrdineLetto());bqCalcola()">Scopri il risultato</button>';
    bqTrascinaAttiva();
    return;
  }
  /* il risultato */
  const r = BQ.ris; if (!r){ BQ.fase = 'intro'; bqPaint(); return; }
  const by = {}; C.blocchi.forEach(function(b){ by[b.k] = b; });
  const p = by[r.primario]; if (!p){ BQ.fase = 'intro'; bqPaint(); return; }
  const conf = r.scelto === r.primario ? C.confronto.uguale : C.confronto.diverso.replace('{scelto}', (by[r.scelto] || {}).nome || '').replace('{calcolato}', p.nome);
  const sec = (r.secondari || []).map(function(k){ return by[k]; }).filter(Boolean);
  /* il confronto con la radiografia prima: il paradigma si sposta, resta, o riprende terreno */
  let confronto = '';
  if (r.prec && r.prec.P){
    const tot = function(P){ return Object.keys(P).reduce(function(a, k){ return a + (P[k] || 0); }, 0); };
    const d = tot(r.P) - tot(r.prec.P);
    const righe = C.blocchi.map(function(b){ const a = Math.round(r.prec.P[b.k] || 0), z = Math.round(r.P[b.k] || 0); return { b: b, a: a, z: z, d: z - a }; }).filter(function(x){ return Math.abs(x.d) >= 5; }).sort(function(x, y){ return x.d - y.d; }).slice(0, 4);
    confronto = '<div class="bq-card bq-confronto"><h4>Rispetto alla radiografia del ' + new Date(r.prec.at).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }) + '</h4>'
      + '<p><b>' + (d <= -20 ? 'Il vecchio paradigma sta perdendo terreno.' : (d >= 20 ? 'Il vecchio paradigma ha ripreso terreno.' : 'Il paradigma è quasi lo stesso.')) + '</b> '
      + (d <= -20 ? 'Le abitudini nuove stanno riscrivendo quello che credi di te: la rotta lo sente, giorno dopo giorno.' : (d >= 20 ? 'Non è una sconfitta: è un dato. Il Genio rimette in cima il blocco che è cresciuto.' : 'Si cambia per ripetizione: la goccia scava la roccia non per la forza, ma perché cade sempre.')) + '</p>'
      + righe.map(function(x){ return '<div class="bq-delta"><span>' + x.b.emoji + '</span><em>' + bqEsc(x.b.esito.titolo) + '</em><b class="' + (x.d < 0 ? 'giu' : 'su') + '">' + x.a + ' → ' + x.z + '</b></div>'; }).join('') + '</div>';
  }
  /* 0.9.278, Andrea: "tutto insieme: grafico, bottiglia, muro di testo, rifai il questionario. One element, one focus,
     come nel report settimanale: una schermata alla volta". Il questionario si rifa' fra tre mesi (la mappa lo
     ripropone da sola), non da qui. */
  /* 0.9.279, Andrea: "due muri di testo insieme; deve essere una specie di video, non avanti avanti come un
     compitino". Ogni schermata ha UNA frase: alcune si scrivono a macchina, altre salgono un pezzo alla volta. */
  const SL = [];
  SL.push({ anim: 'su', html: '<small>Il tuo sabotatore invisibile</small><span class="bq-ico bq-pop">' + p.emoji + '</span><h2>' + bqEsc(p.esito.titolo) + '</h2>'
    + '<div class="bq-punti">' + C.blocchi.slice().sort(function(a, b){ return ((r.P && r.P[b.k]) || 0) - ((r.P && r.P[a.k]) || 0); }).slice(0, 5).map(function(b){ const v = Math.round((r.P && r.P[b.k]) || 0); return '<div class="bq-punto' + (b.k === r.primario ? ' top' : '') + '"><span>' + b.emoji + '</span><i><b style="--w:' + v + '%"></b></i><em>' + v + '</em></div>'; }).join('') + '</div>' });
  SL.push({ anim: 'scrivi', html: bqBottiglia(C, r, p) });
  SL.push({ anim: 'su', html: '<small>Come si vede</small><p class="bq-grande">' + bqEsc(p.esito.testo) + '</p>'
    + (Array.isArray(p.esito.esempi) ? '<ul class="bq-esempi">' + p.esito.esempi.map(function(x){ return '<li>' + bqEsc(x) + '</li>'; }).join('') + '</ul>' : '') });
  SL.push({ anim: 'scrivi', html: '<small>Perché succede</small><p class="bq-grande bq-tw">' + bqEsc(p.esito.perche) + '</p>' });
  /* 0.9.361, Andrea: "le slide del piu' pensi, piu' dubiti, meno fai: mostrale se l'utente risulta che ha il blocco del focus o di
     overthinking, dalle domande del sabotatore invisibile". Il focus e' la dispersione; l'overthinking sta nel dover imparare
     ancora prima di agire e nella paura di non farcela. Due slide, una cosa alla volta: il circolo in cui sei, e come girarlo. */
  if (typeof flCircoloHtml === 'function' && typeof FL_CIRCOLO_FRENA !== 'undefined' && [r.primario].concat(r.secondari || []).some(function(x){ return BQ_CIRCOLO.indexOf(x) >= 0; })){
    SL.push({ anim: 'su', html: '<small>Il circolo in cui sei</small><div class="bq-circ">' + flCircoloHtml(FL_CIRCOLO_FRENA[0], FL_CIRCOLO_FRENA[1]) + '</div>'
      + '<p class="bq-medio">Più pensi, più dubiti. Più dubiti, meno fai. E meno fai, meno ti fidi di te.</p>' });
    SL.push({ anim: 'su', html: '<small>Come si gira al contrario</small><div class="bq-circ">' + flCircoloHtml(FL_CIRCOLO_SPINGE[0], FL_CIRCOLO_SPINGE[1]) + '</div>'
      + '<p class="bq-medio">Fai un passo di due minuti. Ogni cosa fatta toglie un dubbio, e la decisione dopo arriva prima.</p>' });
  }
  SL.push({ anim: 'su', html: '<span class="bq-ico">⚖️</span><small>Quello che pensavi tu</small><p class="bq-grande">' + bqEsc(conf) + '</p>' + confronto });
  SL.push({ anim: 'scrivi', html: '<span class="bq-ico">🧭</span><small>Cosa cambia da domani</small><p class="bq-grande bq-tw">' + bqEsc(p.esito.passo) + '</p>'
    + (r.esercizio ? '' : '<p class="bq-medio bq-dopo-tw">Sulla tua mappa trovi gi\u00e0 il primo esercizio per smontare questo blocco. Ti servono solo dieci minuti.</p>') });
  const k = Math.max(0, Math.min(SL.length - 1, BQ.slide || 0)), ultima = k === SL.length - 1;
  h.innerHTML = '<div class="bq-ris bq-slide"><div class="bq-pallini">' + SL.map(function(_, j){ return '<i class="' + (j <= k ? 'on' : '') + '"></i>'; }).join('') + '</div>'
    + '<div class="bq-slide-in bq-anim-' + SL[k].anim + '" id="bqSlideIn">' + SL[k].html + '</div>'
    + '<div class="bq-slide-cta" id="bqSlideCta">'
    + (ultima ? '<button type="button" class="cta" onclick="goId(\'s-home\');switchTab(\'mappa\')">Vai alla mappa</button>'
              : '<button type="button" class="cta" onclick="BQ.slide=' + (k + 1) + ';bqPaint();const s=document.getElementById(\'s-blocchi\');if(s)s.scrollTop=0">Avanti</button>')
    + '</div></div>';
  bqAnima(SL[k].anim);
}
/* LE ANIMAZIONI DEL RISULTATO: "scrivi" batte a macchina la frase grande (poi compare il resto), "su" fa
   salire gli elementi uno dopo l'altro e riempie le barre. Il pulsante arriva per ultimo. Un tocco salta. */
/* i blocchi che fanno girare il circolo del piu' pensi, meno fai (0.9.361) */
const BQ_CIRCOLO = ['dispersione', 'imparare', 'paura'];
let BQ_TW = 0;
function bqAnima(tipo){
  const box = document.getElementById('bqSlideIn'), cta = document.getElementById('bqSlideCta');
  if (!box || !cta) return;
  const giro = ++BQ_TW;
  cta.classList.add('attesa');
  const fine = function(){ if (giro !== BQ_TW) return; box.classList.add('fatto'); cta.classList.remove('attesa'); };
  box.onclick = function(){ BQ_TW++; box.querySelectorAll('[data-tw]').forEach(function(el){ el.textContent = el.dataset.tw; }); box.classList.add('fatto'); cta.classList.remove('attesa'); };
  let rid = false; try{ rid = matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  if (rid){ fine(); return; }
  if (tipo === 'scrivi'){
    const tw = box.querySelectorAll('.bq-tw, .orc-tw');
    if (!tw.length){ setTimeout(fine, 900); return; }
    let i = 0;
    const prossimo = function(){
      if (giro !== BQ_TW) return;
      const el = tw[i++]; if (!el){ setTimeout(fine, 250); return; }
      const t = el.textContent; el.dataset.tw = t; el.textContent = ''; el.classList.add('scrive');
      let n = 0;
      const passo = function(){
        if (giro !== BQ_TW) return;
        n = Math.min(t.length, n + 1);
        el.textContent = t.slice(0, n);
        /* 0.9.281, Andrea: andava troppo veloce. Il passo della frase del giorno: 55 ms a lettera, pausa sulla punteggiatura */
        if (n < t.length) setTimeout(passo, /[.,:!?]/.test(t[n - 1]) ? 320 : 55);
        else { el.classList.remove('scrive'); setTimeout(prossimo, 350); }
      };
      passo();
    };
    setTimeout(prossimo, 450);
    return;
  }
  setTimeout(fine, 1500);
}
function bqImpatto(i){ const b = BQ.c.blocchi[BQ.i]; BQ.imp[b.k] = i; try{ flVibra(10); }catch(_){ } bqPaint(); if (i > 0) setTimeout(function(){ const s = document.querySelector('.bq-sintomi'); if (s) s.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60); }
function bqSintomo(j, v){ const b = BQ.c.blocchi[BQ.i]; BQ.sin[b.k] = BQ.sin[b.k] || {}; BQ.sin[b.k][j] = v; try{ flVibra(8); }catch(_){ } bqPaint(); }
function bqAvanti(){ if (BQ.i < BQ.c.blocchi.length - 1){ BQ.i++; } else { BQ.fase = 'causa'; } bqPaint(); const s = document.getElementById('s-blocchi'); if (s) s.scrollTop = 0; }
/** Il calcolo: impatto × (1 + media sintomi), su 100. Principale il massimo, secondari entro il 15%. */
function bqPunteggi(imp, sin, blocchi){
  const P = {};
  blocchi.forEach(function(b){
    const I = imp[b.k] || 0; const s = sin[b.k] || {};
    const vals = b.sintomi.map(function(_, j){ return s[j] || 0; });
    const S = vals.length ? vals.reduce(function(a, x){ return a + x; }, 0) / vals.length : 0;
    P[b.k] = Math.round(I * (1 + S) / 12 * 100);
  });
  return P;
}
function bqCalcola(){
  const C = BQ.c; const P = bqPunteggi(BQ.imp, BQ.sin, C.blocchi);
  let max = -1, primario = ''; Object.keys(P).forEach(function(k){ if (P[k] > max){ max = P[k]; primario = k; } });
  if (max <= 0) primario = BQ.scelto;
  const secondari = Object.keys(P).filter(function(k){ return k !== primario && P[k] > 0 && P[k] >= max * 0.85; });
  const prima = bqLeggi();
  BQ.slide = 0;
  /* 0.9.281, Andrea: con il blocco del focus il pannello di pianificazione mostra un passo alla volta, da solo */
  try{ if (primario === 'dispersione') localStorage.setItem('fl_rm_oggi', JSON.stringify('uno')); }catch(_){ }
  BQ.ris = { at: Date.now(), P: P, primario: primario, secondari: secondari, scelto: BQ.scelto, ordine: BQ.ordine.slice(), esercizio: (prima && prima.esercizio) || '',
             prec: prima && prima.P ? { at: prima.at, P: prima.P, primario: prima.primario } : null };
  try{ localStorage.setItem(BQ_KEY, JSON.stringify(BQ.ris)); }catch(_){ }
  try{
    const st = JSON.parse(localStorage.getItem('fl_bq_storia') || '[]') || [];
    st.push({ at: BQ.ris.at, P: P, primario: primario }); localStorage.setItem('fl_bq_storia', JSON.stringify(st.slice(-30)));
    if (BQ.ck){ const c = JSON.parse(localStorage.getItem('fl_bq_ck') || '{}') || {}; c[BQ.ck] = BQ.ris.at; localStorage.setItem('fl_bq_ck', JSON.stringify(c)); BQ.ck = ''; }
  }catch(_){ }
  BQ.fase = 'risultato';
  try{ flVibra([20, 30, 60]); }catch(_){ }
  bqPaint(); const s = document.getElementById('s-blocchi'); if (s) s.scrollTop = 0;
}
/* ---- L'ESERCIZIO DEL FRENO (0.9.207): una tappa a parte, con le cose che hai GIA' scritto ---- */
registerScreen('s-bq-eser',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\');switchTab(\'mappa\')">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">L’esercizio del blocco</b></div>'
  + '<div id="bqEserBody"></div><div class="spacer"></div>', { back: function(){ try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
async function bqEsercizioApri(){
  await bqCarica();
  const r = bqLeggi(); if (!r || !r.primario){ toast('Prima la sfida "Indovina il mio sabotatore", nella scheda Sogno'); return; }
  goId('s-bq-eser');
  const p = BQ.c.blocchi.filter(function(b){ return b.k === r.primario; })[0]; if (!p) return;
  let righe = []; try{ righe = (typeof orcRighe === 'function') ? orcRighe() : []; }catch(_){ }
  const h = document.getElementById('bqEserBody'); if (!h) return;
  h.innerHTML = '<div class="bq-testa"><span>' + p.emoji + '</span><h2>' + bqEsc(p.esito.titolo) + '</h2></div><p class="bq-q">' + bqEsc(p.esito.esercizio) + '</p>'
    + (righe.length ? '<p class="bq-sotto">Dalle cose che hai già scritto nel foglio: toccane una.</p><div class="bq-lista" id="bqEserLista">' + righe.map(function(t, i){ return '<button type="button" class="' + (r.esercizio === t ? 'on' : '') + '" onclick="bqEsercizioScegli(this)">' + bqEsc(t) + '</button>'; }).join('') + '</div>' : '')
    + '<p class="bq-sotto">' + (righe.length ? 'Oppure una riga, scritta adesso:' : 'Una riga sola, scritta adesso:') + '</p><input class="fin" id="bqEserIn" placeholder="es. finire la prima pagina" maxlength="120" value="' + bqEsc(righe.indexOf(r.esercizio || '') < 0 ? (r.esercizio || '') : '') + '">'
    + '<button type="button" class="cta bq-avanti" onclick="bqEsercizioFine()">Fatto</button>';
}
function bqEsercizioScegli(btn){ document.querySelectorAll('#bqEserLista button').forEach(function(b){ b.classList.toggle('on', b === btn); }); const i = document.getElementById('bqEserIn'); if (i) i.value = ''; }
function bqEsercizioFine(){
  const sel = document.querySelector('#bqEserLista button.on'); const i = document.getElementById('bqEserIn');
  const v = (sel ? sel.textContent : (i ? i.value : '')).trim();
  if (!v){ toast('Scegli una riga, o scrivila'); return; }
  bqEsercizioSalva(v);
  try{ flVibra([20, 30, 60]); }catch(_){ }
  try{ if (typeof sdAggiorna === 'function') sdAggiorna(true); }catch(_){ }
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
  toast('L’esercizio del blocco è fatto');
}
function bqEsercizioSalva(v){ const r = bqLeggi(); if (!r) return; r.esercizio = String(v || '').slice(0, 1200); try{ localStorage.setItem(BQ_KEY, JSON.stringify(r)); }catch(_){ } BQ.ris = r; }
/** Una riga per l'agente: «freno principale: …; secondari: …». */
function bqPerAgente(){
  const r = bqLeggi(); if (!r || !r.primario) return '';
  const nomi = { valore: 'non sentirsi all’altezza', passato: 'il peso dei fallimenti passati', dispersione: 'la dispersione fra troppe cose', tempo: 'il tempo che scappa', paura: 'la paura di non farcela', sguardi: 'il giudizio degli altri', denaro: 'il rapporto con i soldi', imparare: 'il dover imparare ancora prima di partire' };
  return 'Blocco inconscio principale: ' + (nomi[r.primario] || r.primario) + (r.secondari && r.secondari.length ? '; secondari: ' + r.secondari.map(function(k){ return nomi[k] || k; }).join(', ') : '') + '.';
}

(function(){
  const css = [
    '.bq-bar{height:6px;margin:0 18px;border-radius:99px;background:rgba(0,117,227,.14);overflow:hidden}.bq-bar i{display:block;height:100%;width:0;background:#0075E3;border-radius:99px;transition:width .3s}',
    '#bqBody{padding:0 18px}.bq-ico{display:block;font-size:56px;line-height:1;margin:26px 0 10px;text-align:center}',
    '.bq-intro{text-align:center;padding-top:10px}.bq-intro h2{margin:0;font:800 26px var(--font-display);color:var(--navy)}body.dark .bq-intro h2{color:#fff}.bq-intro p{margin:14px auto 0;max-width:34ch;font:500 15px/1.55 var(--font-body);color:var(--muted)}.bq-intro small{display:block;margin:12px 0 26px;font:700 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.bq-intro .cta{width:100%}',
    '.bq-eti{margin:22px 0 8px;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.bq-testa{display:flex;align-items:center;gap:12px}.bq-testa span{font-size:34px}.bq-testa h2{margin:0;font:800 22px var(--font-display);color:var(--navy)}body.dark .bq-testa h2{color:#fff}',
    '.bq-q{margin:18px 0 14px;font:600 17px/1.45 var(--font-body);color:var(--navy)}body.dark .bq-q{color:#fff}.bq-q b{color:#0075E3}.bq-sotto{margin:26px 0 12px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.bq-scala{display:grid;grid-template-columns:1fr 1fr;gap:10px}.bq-scala button,.bq-lista button{border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);padding:14px 10px;font:700 14px var(--font-body);color:var(--navy);cursor:pointer;text-align:center}body.dark .bq-scala button,body.dark .bq-lista button{background:#12203A;border-color:#22345A;color:#fff}.bq-scala button.on,.bq-lista button.on{border-color:#0075E3;background:rgba(0,117,227,.12);color:#0075E3}'
    /* 0.9.298, Andrea: "in modalità scura, scegliendo Per niente, Un po', Molto, non sembra selezionato come Mai, A volte".
       La regola del tema scuro (body.dark .bq-scala button) pesava di piu' di .on e copriva bordo e colore. */
    + 'body.dark .bq-scala button.on,body.dark .bq-lista button.on{border-color:#3F9FF4;background:rgba(63,159,244,.16);color:#8CC6FF;box-shadow:0 0 0 1px #3F9FF4 inset}',
    '.bq-sintomi{display:flex;flex-direction:column;gap:14px}.bq-sin{padding:14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff)}body.dark .bq-sin{background:#12203A;border-color:#22345A}.bq-sin p{margin:0 0 10px;font:600 14px/1.45 var(--font-body);color:var(--navy)}body.dark .bq-sin p{color:#fff}',
    '.bq-chips{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.bq-chips button{border:1.5px solid var(--line);border-radius:10px;background:transparent;padding:9px 2px;font:700 11.5px var(--font-body);color:var(--muted);cursor:pointer}.bq-chips button.on{border-color:#0075E3;background:rgba(0,117,227,.12);color:#0075E3}',
    '.bq-avanti{width:100%;margin-top:26px}.bq-lista{display:flex;flex-direction:column;gap:8px}.bq-lista button{display:flex;align-items:center;gap:12px;text-align:left}.bq-lista button span{font-size:22px}',
    '.bq-ris{text-align:center;padding-bottom:20px}.bq-ris small{display:block;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.bq-ris h2{margin:6px 0 18px;font:800 26px var(--font-display);color:var(--navy)}body.dark .bq-ris h2{color:#fff}',
    '.bq-punti{display:flex;flex-direction:column;gap:6px;text-align:left}.bq-punto{display:flex;align-items:center;gap:10px}.bq-punto span{width:28px;text-align:center}.bq-punto i{flex:1;height:10px;border-radius:99px;background:rgba(0,117,227,.12);overflow:hidden;display:block}.bq-punto b{display:block;height:100%;background:#9DB7D6;border-radius:99px}.bq-punto.top b{background:#0075E3}.bq-punto em{width:30px;font:800 12px var(--font-body);font-style:normal;color:var(--muted);text-align:right}',
    '.bq-conf{margin:18px 0 0;font:700 15px/1.5 var(--font-body);color:#0075E3}.bq-card{margin-top:18px;padding:16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line);text-align:left}body.dark .bq-card{background:#12203A;border-color:#22345A}.bq-card p{margin:0;font:500 14.5px/1.55 var(--font-body);color:var(--navy)}body.dark .bq-card p{color:#fff}.bq-card h4{margin:14px 0 6px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.bq-card.passo{background:rgba(0,117,227,.08);border-color:transparent}.bq-card.passo h4{margin-top:0}',
    '.bq-h{margin:26px 0 8px;text-align:left;font:800 16px var(--font-display);color:var(--navy)}body.dark .bq-h{color:#fff}.bq-sec{display:flex;flex-wrap:wrap;gap:8px}.bq-sec span{padding:8px 12px;border-radius:99px;background:var(--card,#fff);border:1px solid var(--line);font:700 12.5px var(--font-body);color:var(--navy)}body.dark .bq-sec span{background:#12203A;border-color:#22345A;color:#fff}',
    '.bq-confronto h4{margin-top:0 !important}.bq-confronto > p{margin-bottom:10px !important}.bq-delta{display:flex;align-items:center;gap:10px;padding:8px 0;border-top:1px solid var(--line)}.bq-delta em{flex:1;font:600 13.5px var(--font-body);font-style:normal;color:var(--navy)}body.dark .bq-delta em{color:#fff}.bq-delta b{font:800 14px var(--font-body)}.bq-delta b.giu{color:#0075E3}.bq-delta b.su{color:#E63946}',
    /* 0.9.278: il risultato a schermate, e la classifica con il posto */
    '.bq-circ{margin:22px auto 0;width:100%;max-width:340px}.bq-circ .fl-circ-t{margin-top:10px}',
    '.bq-slide{display:flex;flex-direction:column;min-height:calc(100vh - 150px);padding-top:8px}.bq-slide-in{flex:1;display:flex;flex-direction:column;justify-content:center;padding:12px 0 28px}',
    '.bq-pallini{display:flex;justify-content:center;gap:8px;margin:10px 0 8px}.bq-pallini i{width:28px;height:5px;border-radius:9px;background:rgba(0,117,227,.18)}.bq-pallini i.on{background:#0075E3}',
    '.bq-slide-in .bq-ico{margin:0 0 18px}.bq-slide-in small{margin-bottom:12px}.bq-slide-in h2{margin:0 0 32px}.bq-punti{gap:14px}',
    '.bq-grande{margin:6px 0 0;font:700 19px/1.5 var(--font-body);color:var(--navy)}body.dark .bq-grande{color:#fff}.bq-medio{margin:24px 0 0;font:500 16px/1.6 var(--font-body);color:var(--muted)}',
    '.bq-slide-in .bq-confronto{margin-top:32px}.bq-slide .cta{margin-top:0}',
    '.bq-ordine{gap:12px}.bq-ordine button{padding:16px 14px}.bq-posto{flex:none;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font:900 14px var(--font-body);font-style:normal;background:rgba(0,117,227,.1);color:#0075E3}.bq-ordine button.on .bq-posto{background:#0075E3;color:#fff}',
    /* 0.9.279: il risultato animato */
    '.bq-slide-cta{transition:opacity .35s,transform .35s}.bq-slide-cta.attesa{opacity:0;transform:translateY(12px);pointer-events:none}',
    '.bq-anim-su > *{opacity:0;animation:bqSu .55s cubic-bezier(.2,.8,.3,1) forwards}',
    '.bq-anim-su > *:nth-child(1){animation-delay:.05s}.bq-anim-su > *:nth-child(2){animation-delay:.3s}.bq-anim-su > *:nth-child(3){animation-delay:.6s}.bq-anim-su > *:nth-child(4){animation-delay:.9s}.bq-anim-su > *:nth-child(5){animation-delay:1.1s}',
    '@keyframes bqSu{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}',
    '.bq-pop{animation:bqPop .6s .2s cubic-bezier(.2,1.5,.4,1) both !important}@keyframes bqPop{from{opacity:0;transform:scale(.3)}to{opacity:1;transform:scale(1)}}',
    '.bq-punto b{width:0;animation:bqRiempi .9s 1s cubic-bezier(.2,.8,.3,1) forwards}.bq-punto:nth-child(2) b{animation-delay:1.15s}.bq-punto:nth-child(3) b{animation-delay:1.3s}.bq-punto:nth-child(4) b{animation-delay:1.45s}.bq-punto:nth-child(5) b{animation-delay:1.6s}',
    '@keyframes bqRiempi{to{width:var(--w)}}',
    '.bq-tw.scrive::after{content:"";display:inline-block;width:2px;height:1em;margin-left:2px;vertical-align:-2px;background:#0075E3;animation:bqCur .7s steps(1) infinite}@keyframes bqCur{50%{opacity:0}}',
    '.bq-dopo-tw{opacity:0;transition:opacity .5s}.fatto .bq-dopo-tw{opacity:1}',
    '.bq-anim-scrivi .orc-bott{animation:bqSu .6s cubic-bezier(.2,.8,.3,1) both}',
    '.bq-scelta p{margin-bottom:32px!important}.bq-scelta h2{margin-top:8px}',
    '.bq-esempi{list-style:none;margin:22px 0 0;padding:0;display:flex;flex-direction:column;gap:12px;text-align:left}',
    '.bq-esempi li{position:relative;padding:12px 14px 12px 40px;border-radius:14px;background:rgba(0,117,227,.07);font:600 15px/1.45 var(--font-body);color:var(--navy)}body.dark .bq-esempi li{background:rgba(255,255,255,.07);color:#fff}',
    '.bq-esempi li::before{content:"";position:absolute;left:16px;top:19px;width:8px;height:8px;border-radius:50%;background:#0075E3}',
    '.bq-anim-su .bq-esempi li{opacity:0;animation:bqSu .55s cubic-bezier(.2,.8,.3,1) forwards}.bq-esempi li:nth-child(1){animation-delay:.9s}.bq-esempi li:nth-child(2){animation-delay:1.5s}.bq-esempi li:nth-child(3){animation-delay:2.1s}.bq-esempi li:nth-child(4){animation-delay:2.7s}.bq-esempi li:nth-child(5){animation-delay:3.3s}',
    '.bq-primo{display:flex;align-items:center;gap:12px;padding:14px;border-radius:14px;background:#0075E3;color:#fff;margin-bottom:12px}.bq-primo .bq-posto{background:#fff;color:#0075E3}.bq-primo b{flex:1;font:700 15px var(--font-body)}.bq-primo small{font:600 11.5px var(--font-body);opacity:.85}',
    '.bq-trascina{gap:10px}.bq-riga{display:flex;align-items:center;gap:12px;padding:14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);touch-action:none;user-select:none;-webkit-user-select:none;transition:box-shadow .15s,transform .15s}',
    'body.dark .bq-riga{background:#12203A;border-color:#22345A}.bq-riga b{flex:1;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .bq-riga b{color:#fff}',
    '.bq-riga span{font-size:22px}.bq-maniglia{font-style:normal;font-size:20px;color:var(--muted);padding:4px 6px;touch-action:none;cursor:grab}',
    '.bq-frecce{margin-left:auto;display:flex;flex-direction:column;gap:2px}.bq-frecce button{width:34px;height:26px;border:0;border-radius:8px;background:rgba(0,117,227,.1);color:#0075E3;display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .bq-frecce button{background:rgba(63,159,244,.18);color:#BCE0FF}',
    '.bq-riga.bq-presa{opacity:.3}.bq-fant{position:fixed;z-index:9001;pointer-events:none;margin:0;box-shadow:0 16px 40px rgba(0,30,68,.3);transform:scale(1.03);border-color:#0075E3!important}',
    '.bq-riga.presa{transform:scale(1.03);box-shadow:0 12px 28px rgba(0,30,68,.22);border-color:#0075E3;position:relative;z-index:2}',
    '.bq-rifai{display:block;width:100%;margin-top:14px;padding:14px;border:0;background:transparent;font:700 15px var(--font-body);color:#0075E3;cursor:pointer}',
    '.bq-ris .bq-sotto{text-align:left;margin-top:8px}.bq-eser{width:100%;margin:0 0 6px}.bq-ris .cta{width:100%;margin-top:20px}.bq-dopo{margin-top:10px !important;font-weight:700 !important}#bqEserBody{padding:0 18px}#bqEserBody .fin{margin:0}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* LA BOTTIGLIA DEL PARADIGMA (0.9.214): nel collo il paradigma principale, nel corpo gli altri
   blocchi del quiz. Finche' il collo resta stretto, tutto il resto non passa. */
const BQ_CORTO = { valore: 'Il valore', passato: 'Il passato', dispersione: 'Il focus', tempo: 'Il tempo', paura: 'La paura', sguardi: 'Il giudizio', denaro: 'I soldi', imparare: 'Imparare' };
/* 0.9.299, Andrea: "Finché i soldi resta così stretto, il tuo sogno non passa: ti sembra una frase corretta? Non
   può essere usata per tutti i blocchi". Una frase per blocco, che dice qual è il nodo e cosa blocca. */
const BQ_FINCHE = {
  valore: 'Finché non credi di valere abbastanza, il tuo sogno resta fermo qui.',
  passato: 'Finché lasci decidere al passato, il tuo sogno resta fermo qui.',
  dispersione: 'Finché inizi tutto e non finisci niente, il tuo sogno resta fermo qui.',
  tempo: 'Finché al sogno dai solo il tempo che avanza, il tuo sogno resta fermo qui.',
  paura: 'Finché è la paura a scegliere per te, il tuo sogno resta fermo qui.',
  sguardi: 'Finché il giudizio degli altri pesa più del tuo, il tuo sogno resta fermo qui.',
  denaro: 'Finché il tuo rapporto con i soldi resta questo, il tuo sogno resta fermo qui.',
  imparare: 'Finché continui a studiare invece di fare, il tuo sogno resta fermo qui.'
};
/* 0.9.279, Andrea: "gli altri blocchi aspettano non ha senso, che cazzo aspettano? La bottiglia serve a far
   vedere il problema che blocca il TUO obiettivo". Nel collo il sabotatore; sotto, quello che non passa: il sogno. */
function bqSognoRighe(){
  let a = null; try{ a = (typeof mpArrivo === 'function') ? mpArrivo() : null; }catch(_){ }
  const nome = String((a && a.nome) || 'Il tuo sogno');
  const parole = nome.split(/\s+/), righe = []; let r = '';
  /* 0.9.299, Andrea: "non mi piace che vada a capo, Chi cresce nel / lavoro". Il corpo della bottiglia tiene 24 lettere */
  parole.forEach(function(w){ if ((r + ' ' + w).trim().length > 24 && r){ righe.push(r); r = w; } else r = (r + ' ' + w).trim(); });
  if (r) righe.push(r);
  return { ico: (a && a.ico) || '✨', righe: righe.slice(0, 4) };
}
function bqBottiglia(C, r, p){
  if (typeof orcBottiglia !== 'function') return '';
  const sg = bqSognoRighe();
  const svg = orcBottiglia([sg.ico].concat(sg.righe), BQ_CORTO[p.k] || p.nome).replace('TUTTO IL RESTO ASPETTA', 'IL TUO SOGNO, BLOCCATO QUI');
  return svg + '<p class="bq-grande bq-tw" style="margin-top:20px">' + (BQ_FINCHE[p.k] || 'Finché non sciogli questo nodo, il tuo sogno resta fermo qui.') + '</p>';
}

/* 0.9.344, Andrea: "nel sabotatore invisibile le freccette sono minuscole e una sotto l'altra: le voglio affiancate, con lo stesso
   chevron di 'Metti in ordine le tue risposte'". Due pulsanti da 44 pixel, uno accanto all'altro */
(function(){ const st = document.createElement('style'); st.textContent = '.bq-frecce{flex:none!important;flex-direction:row!important;gap:6px!important}.bq-frecce button{flex:none;width:44px!important;height:44px!important;border-radius:14px!important;border:1.5px solid var(--line)!important;background:#F1F7FE!important;color:#0075E3!important}.bq-frecce svg{width:22px!important;height:22px!important;flex:none}body.dark .bq-frecce button{background:#1C2E5A!important;border-color:#2C4474!important;color:#8CC6FF!important}'; document.head.appendChild(st); })();
