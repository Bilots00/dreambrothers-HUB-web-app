/* ===========================================================================================
   I MODELLI DI PARTITA — le regole del tabellone si scelgono, non si subiscono (0.9.173)

   Le regole con cui Andrea gioca la sua partita non sono quelle di chi vuole passare un esame
   o rimettersi in forma. Prima erano una sola, uguale per tutti, scritta nel codice. Adesso ci
   sono cinque modelli; il Genio ne consiglia uno in base a quello che sa, ma la scelta e' di
   chi gioca, e ogni regola si regola: quanti punti, entro che ora.

   OGNI REGOLA LA CONTA L'APP. Non c'e' niente da segnare a mano: le regole qui dentro sono
   solo quelle che il motore sa gia' vedere (la mossa del giorno chiusa in Full Focus, una
   sessione portata a termine o mollata, un blocco interrotto, la mezzanotte). Una regola che
   l'app non puo' contare non e' una regola, e' un'intenzione: quelle stanno nel foglio.

   I nomi non parlano di calcio: chi il calcio non lo segue non deve tradurre.
   =========================================================================================== */

const MD_KEY = 'fl_partita_modello';

/* LE REGOLE CONTABILI. ev: l'evento del motore; lato: chi prende il punto; pt: quanti;
   ora: entro che ora vale (o dopo che ora scatta), modificabile; chi: chi la conta, a parole. */
const MD_REGOLE = {
  mossa:        { t: 'La mossa del giorno chiusa in Full Focus', chi: 'lo conta il Full Focus', lato: 'neo', ev: 'mossa' },
  mossaPresto:  { t: 'La mossa del giorno chiusa prima delle {ora}', chi: 'lo conta il Full Focus', lato: 'neo', ev: 'mossa', entro: true, ora: 12 },
  sessione:     { t: 'Ogni sessione di Full Focus portata a termine', chi: 'lo conta il Full Focus', lato: 'neo', ev: 'sessione' },
  giornoPulito: { t: 'Una giornata intera senza blocchi interrotti', chi: 'lo conta lo Scudo, a mezzanotte', lato: 'neo', ev: 'giornoPulito' },
  ceduto:       { t: 'Un blocco interrotto, o il blocco rapido fermato', chi: 'lo vede lo Scudo', lato: 'old', ev: 'ceduto' },
  cedutoPresto: { t: 'Un blocco interrotto prima delle {ora}', chi: 'lo vede lo Scudo', lato: 'old', ev: 'ceduto', entro: true, ora: 12 },
  mollata:      { t: 'Una sessione mollata a metà', chi: 'lo conta il Full Focus', lato: 'old', ev: 'mollata' },
  senzaMossa:   { t: 'Mezzanotte senza la mossa del giorno', chi: 'lo conta il foglio, a mezzanotte', lato: 'old', ev: 'senzaMossa' }
};

const MD_MODELLI = [
  { k: 'partenza', n: 'Partenza forte', s: 'Vince chi parte bene.', per: 'Per chi comincia tardi.', diff: 2, ico: '🌅',
    regole: [['mossaPresto', 2], ['mossa', 1], ['cedutoPresto', 2], ['ceduto', 1]] },
  { k: 'scudo', n: 'Scudo alto', s: 'Si vince in difesa.', per: 'Per chi si distrae.', diff: 2, ico: '🛡️',
    regole: [['giornoPulito', 2], ['mossa', 1], ['ceduto', 2]] },
  { k: 'una', n: 'Una cosa sola', s: 'Una mossa al giorno, quella giusta.', per: 'Per chi ha poco tempo.', diff: 3, ico: '🎯',
    regole: [['mossa', 3], ['senzaMossa', 3], ['ceduto', 1]] },
  { k: 'passo', n: 'Passo dopo passo', s: 'Tanti piccoli punti.', per: 'Per chi ha bisogno di vedere i progressi.', diff: 1, ico: '🪜',
    regole: [['sessione', 1], ['mossa', 1], ['mollata', 1], ['ceduto', 1]] },
  { k: 'mie', n: 'Regole mie', s: 'Le scegli tu, una per una.', per: 'Per chi sa già come gioca.', diff: 0, ico: '✍️',
    regole: [['mossa', 1], ['ceduto', 1]], libero: true }
];

/* 0.9.290, Andrea: "se la Modalita' severa e' attiva e l'utente ha scelto di non poter cambiare le regole (un'opzione
   che non c'era), niente 'si cambia quando vuoi'". L'opzione sta nella Modalita' severa (severe.js, 'regole'). */
function mdRegoleBloccate(){
  try{ return localStorage.getItem('fl_sev_regole') === '1' && typeof cstSeveraAccesa === 'function' && cstSeveraAccesa(); }catch(_){ return false; }
}
function mdBloccoAvviso(){ try{ toast('Le regole della partita sono bloccate finché la Modalità severa è accesa'); flVibra([20, 40, 20]); }catch(_){ } }
function mdLeggi(){
  let m = null; try{ m = JSON.parse(localStorage.getItem(MD_KEY) || 'null'); }catch(_){ }
  return m && m.k ? m : null;
}
function mdSalva(m){ try{ localStorage.setItem(MD_KEY, JSON.stringify(m)); }catch(_){ } }
function mdModello(k){ return MD_MODELLI.filter(function(x){ return x.k === k; })[0] || null; }
/** Le regole in vigore, gia' pronte: {id, t, chi, lato, pt, ora, ev, on}. */
function mdRegole(){
  const m = mdLeggi(); if (!m) return [];
  return (m.regole || []).map(function(r){
    const d = MD_REGOLE[r.id]; if (!d) return null;
    const ora = r.ora != null ? r.ora : d.ora;
    return { id: r.id, t: d.t.replace('{ora}', String(ora)), chi: d.chi, lato: d.lato, ev: d.ev, entro: !!d.entro, ora: ora, pt: Math.max(1, Math.min(3, +r.pt || 1)), on: r.on !== false };
  }).filter(Boolean);
}
/* Il consiglio del Genio: dalle risposte del primo avvio e degli episodi. */
function mdConsiglio(){
  let d = {}; try{ d = gnDati(); }catch(_){ }
  const conti = (d.conti || []).join(' ');
  let ep = {}; try{ ep = dqStato().risposte; }catch(_){ }
  const v = function(id){ return ep[id] ? ep[id].v : ''; };
  if (/distraggo/.test(conti) || v('e2q3') === 'Il telefono' || v('e2q4') === 'Sì') return { k: 'scudo', perche: 'Hai detto che ti distrai con niente. Qui ogni blocco tenuto conta.' };
  if (v('e5q1') === 'Meno di 30 minuti' || v('e3q1') === 'Lo faccio dopo, con più calma') return { k: 'una', perche: 'Hai poco tempo, o rimandi. Una mossa sola al giorno, e vale tre.' };
  if (v('e6q2') === 'Vedere i progressi' || /Rimando/.test(conti)) return { k: 'passo', perche: 'Hai detto che ti muove vedere i progressi. Qui ogni sessione conta.' };
  if (v('e2q1') === 'Sera tardi' || v('e3q5') === 'Recupero di notte' || /Dormo male/.test(conti)) return { k: 'partenza', perche: 'Le tue giornate partono tardi. Qui vince chi parte presto.' };
  return { k: 'passo', perche: 'È il modello che regge meglio i primi giorni: tanti punti piccoli.' };
}

/* ---------------------------------------------------------------------------------------
   L'ARBITRO CONSULTA IL MODELLO. Restituisce quanti punti vale un evento, e una nota.
   Senza modello scelto: un punto, come sempre.
   --------------------------------------------------------------------------------------- */
function mdMolt(chi, ev, extra){
  /* 0.9.322, Andrea: "non ho mai messo la regola che da' un punto al vecchio te se interrompo una sessione". LA CAUSA era qui:
     un evento senza regola valeva comunque un punto. Adesso, con un modello scelto, conta solo quello che c'e' nel modello; e la
     sessione mollata non segna nemmeno senza modello: e' una regola da scegliere. */
  const R = mdRegole(); if (!R.length) return { n: ev === 'mollata' ? 0 : 1, nota: '' };
  const h = new Date().getHours() + new Date().getMinutes() / 60;
  let best = null;
  R.forEach(function(r){
    if (!r.on || r.lato !== chi || r.ev !== ev) return;
    if (r.entro && h >= r.ora) return;
    if (!best || r.pt > best.pt) best = r;
  });
  if (!best) return { n: 0, nota: '' };
  return { n: best.pt, nota: best.pt > 1 ? ' (×' + best.pt + ', ' + best.t.toLowerCase() + ')' : '' };
}
/** L'evento a cui appartiene un motivo del registro: e' cosi' che l'arbitro capisce la regola. */
function mdEvento(chi, motivo){
  const m = String(motivo || '').toLowerCase();
  if (chi === 'neo'){
    if (m.indexOf('unica cosa') === 0) return 'mossa';
    if (m.indexOf('sessione portata') === 0) return 'sessione';
    return '';
  }
  if (m.indexOf('blocco') === 0) return 'ceduto';
  if (m.indexOf('sessione mollata') === 0) return 'mollata';
  return '';
}
/* A MEZZANOTTE: la giornata pulita e la mezzanotte senza mossa. Si chiama dal fischio finale. */
function mdMezzanotte(giorno, eventi){
  const R = mdRegole(); if (!R.length) return [];
  const out = [];
  const ev = eventi || [];
  const ceduti = ev.some(function(e){ return e && e.chi === 'old' && /^blocco/i.test(e.motivo || ''); });
  const mossa = ev.some(function(e){ return e && e.chi === 'neo' && /^unica cosa/i.test(e.motivo || ''); });
  R.forEach(function(r){
    if (!r.on) return;
    if (r.ev === 'giornoPulito' && !ceduti) out.push({ chi: 'neo', n: r.pt, motivo: 'giornata senza blocchi interrotti (' + giorno + ')' });
    if (r.ev === 'senzaMossa' && !mossa) out.push({ chi: 'old', n: r.pt, motivo: 'mezzanotte senza la mossa del giorno (' + giorno + ')' });
  });
  return out;
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA: cinque carte, poi le regole del modello scelto, regolabili
   --------------------------------------------------------------------------------------- */
registerScreen('s-modelli',
  '<div class="topbar"><button class="iconbtn" onclick="mdIndietro()">‹</button><b class="blk-title" id="mdTitolo">La partita</b></div>'
  + '<div class="md-prog" id="mdProg"></div>'
  + '<div id="mdBody"></div><div class="spacer"></div>', { back: function(){ return mdIndietro(); } });

/* LA SEQUENZA. Prima si vede la partita (un'amichevole che si gioca da sola), poi si sceglie
   il modello, poi UNA regola per schermata con il suo interruttore, poi il riepilogo. Tutto
   insieme era un muro; qui ogni schermata ha una cosa sola da capire. */
const MD_W = { passo: 0, regola: 0, sim: 0 };
function mdApri(){ MD_W.passo = mdLeggi() ? 3 : 0; MD_W.regola = 0; goId('s-modelli'); mdPaint(); }
/* indietro: una schermata alla volta; dalla prima si torna alla partita. Restituisce la
   destinazione per il tasto indietro del telefono (null = resto qui, ridisegnato). */
function mdIndietro(){
  if (MD_W.passo === 0 || (MD_W.passo === 3 && mdLeggi())){ goId('s-partita'); if (typeof paPaint === 'function') paPaint(); return 's-partita'; }
  if (MD_W.passo === 4 && MD_W.regola > 0){ MD_W.regola--; mdPaint(); return null; }
  MD_W.passo = Math.max(0, MD_W.passo - 1); MD_W.regola = 0; mdPaint(); return null;
}
function mdVai(n){ MD_W.passo = n; MD_W.regola = 0; mdPaint(); }

/* l'amichevole: tre momenti di una giornata, i punti si segnano da soli */
const MD_SIM = [
  { ora: '09:12', ico: '🔮', t: 'Full Focus di 25 minuti finito', chi: 'neo', chi_t: 'lo conta il Full Focus' },
  { ora: '14:30', ico: '📱', t: 'Instagram aperta durante un blocco', chi: 'old', chi_t: 'lo vede lo Scudo' },
  { ora: '21:05', ico: '✅', t: 'La mossa del giorno chiusa', chi: 'neo', chi_t: 'lo conta il foglio' }
];
function mdSimAvvia(){
  MD_W.sim = 0;
  const tick = function(){
    if (MD_W.passo !== 1) return;
    MD_W.sim++;
    const old = MD_SIM.slice(0, MD_W.sim).filter(function(e){ return e.chi === 'old'; }).length;
    const neo = MD_SIM.slice(0, MD_W.sim).filter(function(e){ return e.chi === 'neo'; }).length;
    const o = document.getElementById('mdSimOld'), n = document.getElementById('mdSimNeo');
    if (o) o.textContent = old; if (n) n.textContent = neo;
    const li = document.querySelectorAll('.md-sim li')[MD_W.sim - 1]; if (li) li.classList.add('on');
    try{ if (typeof gnVibra === 'function') gnVibra(12); }catch(_){ }
    if (MD_W.sim < MD_SIM.length) setTimeout(tick, 1400);
    else { const b = document.getElementById('mdSimBtn'); if (b) b.hidden = false; }
  };
  setTimeout(tick, 900);
}

function mdPaint(){
  const host = document.getElementById('mdBody'); if (!host) return;
  const tit = document.getElementById('mdTitolo'), prog = document.getElementById('mdProg');
  const cur = mdLeggi(); const c = mdConsiglio();
  const R = mdRegole();
  const tot = 4 + Math.max(1, R.length);
  const pos = MD_W.passo < 4 ? MD_W.passo : (MD_W.passo === 4 ? 3 + MD_W.regola + 1 : tot);
  if (prog) prog.innerHTML = '<i style="width:' + Math.round(Math.min(1, (pos + 1) / (tot + 1)) * 100) + '%"></i>';

  if (MD_W.passo === 0){
    if (tit) tit.textContent = 'La partita';
    host.innerHTML = '<div class="md-slide"><div class="md-tab"><div><small>Vecchio te</small><b>0</b></div><i>:</i><div><small>Nuovo te</small><b>0</b></div></div>'
      + '<h2>Ogni giorno giochi una partita contro il vecchio te.</h2>'
      + '<p>Vince chi a mezzanotte ha più punti. Non devi segnare niente: <b>i punti li conta l\'app</b>, come un arbitro. Tu vivi la giornata, il tabellone si muove da solo.</p>'
      + '<button type="button" class="am-cta" onclick="mdVai(1)">Fammi vedere</button></div>';
    return;
  }
  if (MD_W.passo === 1){
    if (tit) tit.textContent = 'Un\'amichevole';
    host.innerHTML = '<div class="md-slide"><div class="md-tab"><div><small>Vecchio te</small><b id="mdSimOld">0</b></div><i>:</i><div><small>Nuovo te</small><b id="mdSimNeo">0</b></div></div>'
      + '<h2>Una giornata qualsiasi.</h2>'
      + '<ul class="md-sim">' + MD_SIM.map(function(e){ return '<li><span class="md-sim-ora">' + e.ora + '</span><span class="md-sim-ico">' + e.ico + '</span><div><b>' + esc(e.t) + '</b><small>' + esc(e.chi_t) + '</small></div><em class="' + e.chi + '">' + (e.chi === 'neo' ? '+1 Nuovo te' : '+1 Vecchio te') + '</em></li>'; }).join('') + '</ul>'
      + '<p>Nessun tocco tuo: l\'arbitro ha visto tutto da solo.</p>'
      + '<button type="button" class="am-cta" id="mdSimBtn" hidden onclick="mdVai(2)">Ho capito il gioco</button></div>';
    mdSimAvvia();
    return;
  }
  if (MD_W.passo === 2){
    if (tit) tit.textContent = 'Le regole';
    host.innerHTML = '<div class="md-slide"><div class="md-ico-big">🏆</div>'
      + '<h2>Le regole le scegli tu.</h2>'
      + '<p>Chi studia per un esame non gioca la stessa partita di chi apre un negozio. Ci sono cinque modi di giocare: <b>il Genio te ne consiglia uno</b>, poi ogni regola la accendi, la spegni o la cambi.</p>'
      + '<button type="button" class="am-cta" onclick="mdVai(3)">Scegli come giocare</button></div>';
    return;
  }
  if (MD_W.passo === 3){
    if (tit) tit.textContent = 'Come vuoi giocare?';
    host.innerHTML = '<p class="hintline" style="padding:0 2px 10px;text-align:center">' + mdSuggerimento() + '</p><div class="md-scroll">' + mdCarteHtml(false) + '</div>'
      + (cur ? '<button type="button" class="am-cta" onclick="MD_W.regola=0;mdVai(4)">Vedi le regole di "' + esc(mdModello(cur.k).n) + '"</button>' : '');
    const sel = host.querySelector('.md-card.sel'); if (sel && sel.scrollIntoView) try{ sel.scrollIntoView({ block: 'nearest', inline: 'center' }); }catch(_){ }
    return;
  }
  if (MD_W.passo === 4){
    if (!cur){ mdVai(3); return; }
    const m = mdModello(cur.k);
    if (MD_W.regola >= R.length){ mdVai(5); return; }
    const r = R[MD_W.regola], i = MD_W.regola;
    if (tit) tit.textContent = 'Regola ' + (i + 1) + ' di ' + R.length;
    host.innerHTML = '<div class="md-slide md-regola' + (r.on ? '' : ' off') + '">'
      + '<small class="md-eti">' + esc(m.ico + ' ' + m.n) + '</small>'
      + '<h2>' + esc(r.t) + '</h2>'
      + '<div class="md-pt-big ' + r.lato + '">+' + r.pt + '<small>' + (r.lato === 'neo' ? 'al Nuovo te' : 'al Vecchio te') + '</small></div>'
      + '<p class="md-chi">' + esc(r.chi.charAt(0).toUpperCase() + r.chi.slice(1)) + '. Tu non segni niente.</p>'
      + '<div class="md-ctl">'
      +   '<div class="md-row"><span>Regola attiva</span><button class="switch' + (r.on ? ' on' : '') + '" onclick="mdOnOff(' + i + ')" aria-label="Attiva o spegni"></button></div>'
      +   '<div class="md-row"><span>Quanti punti</span><div class="md-step"><button type="button" onclick="mdPt(' + i + ',-1)" aria-label="Meno">−</button><b>' + r.pt + '</b><button type="button" onclick="mdPt(' + i + ',1)" aria-label="Più">+</button></div></div>'
      +   (r.entro ? '<div class="md-row"><span>Entro le</span><div class="md-step"><button type="button" onclick="mdOra(' + i + ',' + (r.ora - 1) + ')" aria-label="Prima">−</button><b>' + r.ora + ':00</b><button type="button" onclick="mdOra(' + i + ',' + (r.ora + 1) + ')" aria-label="Dopo">+</button></div></div>' : '')
      + '</div>'
      + '<button type="button" class="am-cta" onclick="MD_W.regola++;mdPaint()">' + (i + 1 < R.length ? 'Regola successiva' : 'Vedi il riepilogo') + '</button>'
      + '</div>';
    return;
  }
  /* 5: il riepilogo, con le regole da aggiungere */
  if (!cur){ mdVai(3); return; }
  const m = mdModello(cur.k);
  if (tit) tit.textContent = 'Gioco così';
  const daAggiungere = Object.keys(MD_REGOLE).filter(function(id){ return !R.some(function(r){ return r.id === id; }); });
  host.innerHTML = '<div class="md-slide"><small class="md-eti">' + esc(m.ico + ' ' + m.n) + '</small><h2>' + esc(m.s) + '</h2>'
    + '<div class="md-rie">' + R.map(function(r, i){
        return '<div class="md-rie-r' + (r.on ? '' : ' off') + '" onclick="mdRegolaApri(' + i + ')"><span class="md-pt ' + r.lato + '">+' + r.pt + '</span><div><b>' + esc(r.t) + '</b><small>' + esc(r.lato === 'neo' ? 'Nuovo te' : 'Vecchio te') + ' · ' + esc(r.chi) + (r.on ? '' : ' · spenta') + '</small></div><span class="chev"></span></div>';
      }).join('') + '</div>'
    + (daAggiungere.length ? '<details class="md-add-box"><summary>Aggiungi una regola<span class="animated-plus"></span></summary><div class="md-add">' + daAggiungere.map(function(id){
        const d = MD_REGOLE[id];
        return '<button type="button" onclick="mdAggiungi(\'' + id + '\')"><b>' + esc(d.t.replace('{ora}', String(d.ora || ''))) + '</b><small>' + (d.lato === 'neo' ? 'punto al Nuovo te' : 'punto al Vecchio te') + ' · ' + esc(d.chi) + '</small></button>';
      }).join('') + '</div></details>' : '')
    /* 0.9.290, Andrea: "nelle Regole mie, come ultima opzione, Chiedi una regola al tuo agente personale: crea qualsiasi regola" */
    + (m.libero ? '<button type="button" class="md-chiedi" onclick="if(typeof rgmChiediAgente===\'function\')rgmChiediAgente()"><span>💬</span><div><b>Chiedi una regola al tuo agente personale</b><small>Qualsiasi regola: lui la scrive, l’app conta i punti.</small></div></button>' : '')
    + '<button type="button" class="am-cta" onclick="goId(\'s-partita\');if(typeof paPaint===\'function\')paPaint();toast(\'Si gioca così. Il tabellone fa il resto.\')">Si gioca</button>'
    + '<button type="button" class="am-link" onclick="mdVai(3)">Cambia modello</button></div>';
}
function mdSuggerimento(){ return mdRegoleBloccate() ? 'Scorri le carte. Con la Modalità severa accesa le regole restano queste.' : 'Scorri le carte. La scelta è tua, e si cambia quando vuoi.'; }
/** Le carte dei modi di giocare: nella pagina "Come vuoi giocare?" e, da sole, in cima alla pagina della partita. */
function mdCarteHtml(fuori){
  const cur = mdLeggi(), c = mdConsiglio();
  return MD_MODELLI.map(function(m){
    const sel = cur && cur.k === m.k, cons = c.k === m.k;
    return '<div class="md-card' + (sel ? ' sel' : '') + '" onclick="' + (fuori ? 'mdApriModello' : 'mdScegli') + '(\'' + m.k + '\')">'
      + (cons ? '<span class="md-cons">Consigliato per te</span>' : '')
      + '<span class="md-ico">' + m.ico + '</span><b>' + esc(m.n) + '</b><em>' + esc(m.s) + '</em><small>' + esc(m.per) + '</small>'
      + (cons ? '<p class="md-perche">' + esc(c.perche) + '</p>' : '')
      + '<div class="md-diff">' + (m.diff ? '<span></span>'.repeat(m.diff) + '<i></i>'.repeat(3 - m.diff) : '<small>tua</small>') + '</div>'
      + '<span class="md-chk">' + (sel ? '✓ Scelto' : 'Scegli') + '</span></div>';
  }).join('');
}
/* 0.9.290, Andrea: "nella pagina La partita, al posto del pannello Regole su misura, la pagina Come vuoi giocare, con le
   card". Le carte stanno in cima alla pagina; toccandone una si aprono le sue regole. */
function mdInlineHtml(){
  return '<div class="md-inline"><div class="md-inline-h"><b>Come vuoi giocare?</b><small>' + esc(mdSuggerimento()) + '</small></div><div class="md-scroll">' + mdCarteHtml(true) + '</div></div>';
}
function mdApriModello(k){
  goId('s-modelli');
  const cur = mdLeggi();
  if (cur && cur.k === k){ MD_W.passo = 5; MD_W.regola = 0; mdPaint(); return; }
  mdScegli(k);
}
function mdRegolaApri(i){ MD_W.passo = 4; MD_W.regola = i; mdPaint(); }
function mdScegli(k){
  const m = mdModello(k); if (!m) return;
  const prima = mdLeggi();
  if (mdRegoleBloccate() && (!prima || prima.k !== k)){ mdBloccoAvviso(); if (!(document.querySelector('.screen.active') || {}).id || document.querySelector('.screen.active').id !== 's-modelli') return; MD_W.passo = 3; mdPaint(); return; }
  if (!prima || prima.k !== k) mdSalva({ k: k, at: Date.now(), regole: m.regole.map(function(r){ return { id: r[0], pt: r[1], ora: MD_REGOLE[r[0]].ora, on: true }; }) });
  try{ if (typeof gnVibra === 'function') gnVibra(18); }catch(_){ }
  MD_W.passo = 4; MD_W.regola = 0; mdPaint();
}
function mdPt(i, d){ if (mdRegoleBloccate()){ mdBloccoAvviso(); return; } const m = mdLeggi(); if (!m || !m.regole[i]) return; m.regole[i].pt = Math.max(1, Math.min(3, (+m.regole[i].pt || 1) + d)); mdSalva(m); mdPaint(); }
function mdOra(i, v){ if (mdRegoleBloccate()){ mdBloccoAvviso(); return; } const m = mdLeggi(); if (!m || !m.regole[i]) return; m.regole[i].ora = Math.max(5, Math.min(23, +v || 12)); mdSalva(m); mdPaint(); }
function mdOnOff(i){ if (mdRegoleBloccate()){ mdBloccoAvviso(); return; } const m = mdLeggi(); if (!m || !m.regole[i]) return; m.regole[i].on = m.regole[i].on === false; mdSalva(m); mdPaint(); }
function mdAggiungi(id){ if (mdRegoleBloccate()){ mdBloccoAvviso(); return; } const m = mdLeggi(); if (!m || !MD_REGOLE[id]) return; m.regole.push({ id: id, pt: 1, ora: MD_REGOLE[id].ora, on: true }); mdSalva(m); mdRegolaApri(m.regole.length - 1); }

/** Il riquadro nella pagina della partita: al posto di «Come fai punti». */
function mdRiquadroHtml(){
  const cur = mdLeggi();
  if (!cur){
    const c = mdConsiglio(); const m = mdModello(c.k);
    return '<div class="pa-regole md-box"><b>Come vuoi giocare?</b><p class="md-p">Le regole della partita si scelgono. Il Genio ti consiglia <b>' + esc(m.n) + '</b>: ' + esc(c.perche.charAt(0).toLowerCase() + c.perche.slice(1)) + '</p>'
      + '<button type="button" class="am-cta" onclick="mdApri()">Scegli il modello</button></div>';
  }
  const m = mdModello(cur.k); const R = mdRegole().filter(function(r){ return r.on; });
  return '<div class="pa-regole md-box"><b>' + esc(m.ico + ' ' + m.n) + '</b><p class="md-p">' + esc(m.s) + '</p>'
    + R.map(function(r){ return '<div><span>' + esc(r.t) + '<small>' + esc(r.chi) + '</small></span><b class="' + (r.lato === 'old' ? 'rosso' : '') + '">' + (r.lato === 'neo' ? '+' : '+') + r.pt + ' ' + (r.lato === 'neo' ? 'Nuovo te' : 'Vecchio te') + '</b></div>'; }).join('')
    + '<p>Vince chi a mezzanotte ha più punti. Il punteggio lo tiene l\'app.</p>'
    + '<button type="button" class="am-link" onclick="mdApri()">Cambia modello o regole</button></div>';
}

(function(){
  const css = [
    '.md-scroll{display:flex;gap:12px;overflow-x:auto;padding:4px 2px 14px;margin:0 -2px;scrollbar-width:none;scroll-snap-type:x mandatory}',
    '.md-inline{margin:0 0 28px}.md-inline-h{text-align:center;margin:4px 0 16px}.md-inline-h b{display:block;font:800 20px var(--font-display,var(--font-body));color:var(--navy)}body.dark .md-inline-h b{color:#fff}.md-inline-h small{display:block;margin-top:8px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.md-inline .md-scroll{padding-top:14px}',
    '.md-chiedi{display:flex;align-items:center;gap:14px;width:100%;margin:24px 0 0;padding:16px;border:1.5px solid #0075E3;border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer;font:inherit}body.dark .md-chiedi{background:#12203A;border-color:#3F9FF4}.md-chiedi > span{font-size:26px}.md-chiedi b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .md-chiedi b{color:#fff}.md-chiedi small{display:block;margin-top:4px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.md-scroll::-webkit-scrollbar{display:none}',
    '.md-card{position:relative;flex:0 0 78%;scroll-snap-align:center;border:2px solid var(--line);border-radius:22px;background:var(--card,#fff);padding:22px 16px 16px;text-align:center;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px}',
    'body.dark .md-card{background:#12203A;border-color:#22345A}',
    '.md-card.sel{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.22)}',
    '.md-cons{position:absolute;top:-11px;left:50%;transform:translateX(-50%);white-space:nowrap;background:#0075E3;color:#fff;border-radius:99px;padding:4px 12px;font:700 11px var(--font-body)}',
    '.md-ico{font-size:34px;line-height:1;margin-top:6px}',
    '.md-card b{font:800 20px var(--font-display);color:var(--navy)}body.dark .md-card b{color:#fff}',
    '.md-card em{font:700 13px var(--font-body);font-style:normal;color:#0075E3}',
    '.md-card small{font:500 12px var(--font-body);color:var(--muted)}',
    '.md-perche{margin:8px 0 0;font:500 12.5px/1.45 var(--font-body);color:var(--navy);background:var(--blue-soft,#E3F1FF);border-radius:12px;padding:8px 10px}body.dark .md-perche{background:rgba(63,159,244,.15);color:#fff}',
    '.md-diff{display:flex;gap:4px;margin-top:10px;align-items:center}.md-diff span,.md-diff i{width:18px;height:5px;border-radius:3px;background:#0075E3}.md-diff i{background:var(--line)}.md-diff small{font:700 11px var(--font-body);color:var(--muted)}',
    '.md-chk{margin-top:10px;border-radius:99px;padding:9px 18px;font:700 13px var(--font-body);background:var(--bg,#F4F9FF);color:var(--navy)}.md-card.sel .md-chk{background:#0075E3;color:#fff}',
    '.md-reg{display:flex;flex-direction:column;gap:8px;background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:12px 14px;margin-bottom:8px}body.dark .md-reg{background:#12203A;border-color:#22345A}',
    '.md-reg.off{opacity:.5}',
    '.md-reg-t b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .md-reg-t b{color:#fff}.md-reg-t small{display:block;margin-top:2px;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.md-reg-ctl{display:flex;align-items:center;gap:6px}',
    '.md-pt{font:800 15px var(--font-display);min-width:34px}.md-pt.neo{color:#0075E3}.md-pt.old{color:#E63946}',
    '.md-reg-ctl > button{width:32px;height:32px;border-radius:16px;border:1px solid var(--line);background:transparent;color:var(--navy);font:700 16px var(--font-body);cursor:pointer}body.dark .md-reg-ctl > button{color:#fff}',
    '.md-reg-ctl input{width:54px;border:1px solid var(--line);border-radius:10px;padding:6px;font:700 13px var(--font-body);text-align:center;color:var(--navy);background:var(--card,#fff)}',
    '.md-reg-ctl .md-on{margin-left:auto;width:auto;padding:0 12px;font-size:12px;border-radius:99px}',
    '.md-add{display:flex;flex-direction:column;gap:8px}.md-add button{text-align:left;border:1.5px dashed var(--line);background:transparent;border-radius:14px;padding:10px 12px;cursor:pointer}',
    '.md-add b{display:block;font:700 13px var(--font-body);color:var(--navy)}body.dark .md-add b{color:#fff}.md-add small{display:block;font:500 11px var(--font-body);color:var(--muted)}',
    '.md-box .md-p{margin:0 0 4px;font:500 13.5px/1.5 var(--font-body);color:var(--muted);text-align:center;border:0;padding:0}',
    '.md-box > div span small{display:block;font:500 11px var(--font-body);color:var(--muted)}',
    '.md-box .am-cta,.md-box .am-link{margin-top:6px}',
    '.md-prog{height:6px;border-radius:3px;background:var(--blue-soft,#E3F1FF);overflow:hidden;margin:0 0 14px}.md-prog i{display:block;height:100%;border-radius:3px;background:linear-gradient(90deg,#3F9FF4,#0075E3);transition:width .4s}',
    '.md-slide{display:flex;flex-direction:column;align-items:center;text-align:center;gap:14px;padding:8px 0}',
    '.md-slide h2{margin:4px 0 0;font:800 24px/1.25 var(--font-display);color:var(--navy);text-wrap:pretty}body.dark .md-slide h2{color:#fff}',
    '.md-slide > p{margin:0;max-width:32ch;font:500 14.5px/1.6 var(--font-body);color:var(--muted)}.md-slide > p b{color:var(--navy)}body.dark .md-slide > p b{color:#fff}',
    '.md-slide .am-cta{margin-top:10px;width:100%}',
    '.md-tab{display:flex;align-items:center;justify-content:center;gap:18px;background:#001E44;color:#fff;border-radius:22px;padding:16px 26px;min-width:240px}',
    '.md-tab div{text-align:center}.md-tab small{display:block;font:700 10px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.md-tab b{display:block;font:900 40px/1.1 var(--font-display);font-style:italic}.md-tab i{font:800 30px var(--font-display);color:rgba(255,255,255,.4);font-style:normal}',
    '.md-ico-big{font-size:56px;line-height:1;margin-top:10px}',
    '.md-sim{list-style:none;margin:0;padding:0;width:100%;display:flex;flex-direction:column;gap:8px}',
    '.md-sim li{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);text-align:left;opacity:.25;transform:translateY(6px);transition:opacity .4s,transform .4s}body.dark .md-sim li{background:#12203A;border-color:#22345A}',
    '.md-sim li.on{opacity:1;transform:none}',
    '.md-sim-ora{font:700 12px var(--font-body);color:var(--muted);flex:none;width:40px}.md-sim-ico{font-size:20px;flex:none}',
    '.md-sim li div{flex:1;min-width:0}.md-sim li b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}body.dark .md-sim li b{color:#fff}.md-sim li small{display:block;font:500 11px var(--font-body);color:var(--muted)}',
    '.md-sim li em{flex:none;font:800 12px var(--font-body);font-style:normal;border-radius:99px;padding:5px 10px}.md-sim li em.neo{background:#E3F1FF;color:#0075E3}.md-sim li em.old{background:#FDE8EA;color:#E63946}',
    '.md-eti{font:700 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}',
    '.md-pt-big{font:900 56px/1 var(--font-display);color:#0075E3;display:flex;flex-direction:column;align-items:center;gap:6px}.md-pt-big.old{color:#E63946}.md-pt-big small{font:600 13px var(--font-body);color:var(--muted);letter-spacing:0}',
    '.md-chi{margin:0;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.md-regola.off h2,.md-regola.off .md-pt-big{opacity:.4}',
    '.md-ctl{width:100%;display:flex;flex-direction:column;gap:8px;margin-top:6px}',
    '.md-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .md-row{background:#12203A;border-color:#22345A}',
    '.md-row > span{font:700 14px var(--font-body);color:var(--navy)}body.dark .md-row > span{color:#fff}',
    '.md-step{display:flex;align-items:center;gap:10px}.md-step b{min-width:52px;text-align:center;font:800 16px var(--font-display);color:var(--navy)}body.dark .md-step b{color:#fff}',
    '.md-step button{width:34px;height:34px;border-radius:17px;border:1px solid var(--line);background:transparent;color:var(--navy);font:700 18px var(--font-body);cursor:pointer}body.dark .md-step button{color:#fff}',
    '.md-rie{width:100%;display:flex;flex-direction:column;gap:8px;text-align:left}',
    '.md-rie-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);cursor:pointer}body.dark .md-rie-r{background:#12203A;border-color:#22345A}',
    '.md-rie-r.off{opacity:.5}.md-rie-r div{flex:1;min-width:0}.md-rie-r b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}body.dark .md-rie-r b{color:#fff}.md-rie-r small{display:block;font:500 11px var(--font-body);color:var(--muted)}',
    '.md-add-box{width:100%;text-align:left}.md-add-box summary{list-style:none;display:flex;align-items:center;justify-content:space-between;padding:12px 4px;font:700 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .md-add-box summary{color:#fff}.md-add-box summary::-webkit-details-marker{display:none}',
    '.md-add-box[open] summary .animated-plus::before,.md-add-box[open] summary .animated-plus::after{transform:translate(-50%,-50%) rotate(0deg)}.md-add-box[open] summary .animated-plus::after{opacity:0}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
