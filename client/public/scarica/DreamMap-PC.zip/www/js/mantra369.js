/* ===========================================================================================
   IL METODO 3·6·9 — la lista dei mantra, il Genio che sceglie, e i tre momenti del giorno

   COSA C'È DI VERO. Il «3·6·9» attribuito a Tesla è un'invenzione del self-help: Tesla non ha
   mai scritto affermazioni tre volte al mattino. Quello che resta in piedi, e per cui questa
   pagina esiste, è la ripetizione distanziata: la stessa frase, tre volte al giorno, nei tre
   momenti in cui il cervello è più disponibile — appena sveglio, a metà giornata, prima di
   dormire. Il sistema di attivazione reticolare si sintonizza su ciò che gli si mette davanti
   spesso; è la stessa ragione per cui, comprata un'auto, la si vede ovunque.

   COSA FA L'APP. Tre cose, e nessuna chiede all'utente di ricordarsi qualcosa:
     1. tiene una LISTA di mantra, ognuno con un traguardo a cui serve (settimana, mese,
        trimestre) e, se si vuole, un audio o un video registrato dall'utente;
     2. il GENIO sceglie il mantra del periodo fra quelli allineati al traguardo scritto negli
        Orizzonti — non a caso: conta le parole che il mantra e il traguardo hanno in comune —
        e lo passa al motore come mantra corrente, con il suo audio o video;
     3. il MOTORE (FocusLockService) fa comparire la card da sola nelle tre fasce del giorno,
        con «3×», «6×», «9×» davanti alla frase: quante volte ripeterla, come vuole il metodo.

   La rotazione è mensile: a ogni mese nuovo il Genio ripassa la lista e cambia mantra, così
   la frase non diventa arredamento. Chi vuole la stessa per un trimestre le dà il traguardo
   del trimestre, che cambia ogni tre mesi.
   =========================================================================================== */

const M369_KEY = 'fl_m369';
const M369_TAG = [
  ['settimana', 'Settimana', 'settimana'],
  ['mese', 'Mese', 'mese'],
  ['trimestre', 'Trimestre', 'anno'],
  ['sempre', 'Sempre', '']
];

function m369Leggi(){
  let v = null;
  try{ v = JSON.parse(localStorage.getItem(M369_KEY) || 'null'); }catch(_){ v = null; }
  v = v || {};
  return {
    on: !!v.on,
    lista: Array.isArray(v.lista) ? v.lista : [],
    bande: Array.isArray(v.bande) && v.bande.length === 3 ? v.bande : [480, 840, 1260],
    scelto: v.scelto || '',
    periodo: v.periodo || '',
    perche: v.perche || ''
  };
}
function m369Salva(v){
  try{ localStorage.setItem(M369_KEY, JSON.stringify(v)); }catch(_){ }
}

function m369Etichetta(){
  const v = m369Leggi();
  if (!v.on) return v.lista.length ? v.lista.length + (v.lista.length === 1 ? ' mantra' : ' mantra') + ' · spento' : 'spento';
  return v.bande.map(m369Ora).join(' · ');
}
function m369Ora(min){ return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }
function m369Min(v){ const m = /^(\d{1,2}):(\d{2})$/.exec(String(v || '')); return m ? Math.max(0, Math.min(1439, (+m[1]) * 60 + (+m[2]))) : -1; }

/* ---------------------------------------------------------------------------------------
   LA SCELTA DEL GENIO
   --------------------------------------------------------------------------------------- */

/** Il periodo corrente: un mese. Cambia mese, cambia mantra. */
function m369Periodo(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}
function m369Parole(t){
  return String(t || '').toLowerCase().replace(/[^a-z\u00e0\u00e8\u00e9\u00ec\u00f2\u00f9 0-9\s]/g, ' ').split(/\s+/)
    .filter(function(w){ return w.length >= 4 && M369_VUOTE.indexOf(w) < 0; });
}
const M369_VUOTE = ['della', 'delle', 'dello', 'degli', 'nella', 'nelle', 'sono', 'essere', 'fare', 'ogni', 'come', 'anche', 'mio', 'mia', 'tuo', 'tua', 'quello', 'questa', 'questo', 'sempre', 'giorno', 'volta'];

/* GLI ORIZZONTI, letti dagli Orizzonti: settimana, mese, anno (che qui fa da trimestre).
   E' il Genio a decidere a quale traguardo serve un mantra — non chi lo scrive. */
const M369_ORIZZONTI = [['settimana', 'Settimana'], ['mese', 'Mese'], ['anno', 'Trimestre']];
function m369Traguardo(k){
  try{ return (typeof ozTesto === 'function') ? (ozTesto(k) || '') : ''; }catch(_){ return ''; }
}

/**
 * Quanto un mantra parla di un traguardo: le parole piene che hanno in comune.
 *
 * @return {p: punti, k: l'orizzonte più vicino, nome: il suo nome}
 */
function m369Punteggio(m){
  const parole = m369Parole(m.t);
  let best = { p: 0, k: '', nome: '' };
  M369_ORIZZONTI.forEach(function(o){
    const pt = m369Parole(m369Traguardo(o[0]));
    if (!pt.length) return;
    let p = 0;
    parole.forEach(function(w){ if (pt.indexOf(w) >= 0) p += 2; });
    if (p > best.p) best = { p: p, k: o[0], nome: o[1] };
  });
  /* ANCHE LA LETTURA DEL GENIO conta: la persona che si vuole diventare («chi costruisce
     qualcosa di suo») e' un traguardo quanto gli Orizzonti, e un mantra che ne parla e'
     allineato anche se negli Orizzonti non c'e' una parola in comune. */
  try{
    const r = (typeof orLast === 'function') ? orLast() : null;
    const pg = m369Parole([r && r.target, r && r.why].filter(Boolean).join(' '));
    let p = 0;
    parole.forEach(function(w){ if (pg.indexOf(w) >= 0) p += 2; });
    if (p > best.p) best = { p: p, k: 'genio', nome: 'chi vuoi diventare' };
  }catch(_){ }
  return best;
}

/**
 * Quando nessun mantra scritto parla dei traguardi, il Genio ne compone uno dal traguardo
 * più vicino nel tempo e dalla lettura del futuro: chi ha una lettura bassa ha bisogno di
 * sentirsi dire che NON è più quello di prima; chi ce l'ha alta, che lo è già.
 */
function m369Inventa(){
  const ord = ['settimana', 'mese', 'anno'];
  let k = '', t = '';
  for (let i = 0; i < ord.length && !t; i++){ t = m369Traguardo(ord[i]); k = ord[i]; }
  if (!t) return null;
  let pct = null;
  try{ const r = (typeof orLast === 'function') ? orLast() : null; if (r && typeof r.pct === 'number') pct = r.pct; }catch(_){ }
  let meta = t.trim().replace(/[.!]+$/, '').replace(/^./, function(c){ return c.toLowerCase(); });
  /* CORTO: la card lo mostra in otto righe al massimo, e un mantra che non si legge intero
     non si ripete. Il traguardo si taglia a una parola intera. */
  if (meta.length > 60){ meta = meta.slice(0, 60).replace(/\s+\S*$/, '') + '\u2026'; }
  const frase = (pct !== null && pct < 50)
    ? 'Ogni giorno un passo verso: ' + meta + '. Non rimando pi\u00f9.'
    : 'Sono chi porta a termine: ' + meta + '.';
  const nome = (M369_ORIZZONTI.filter(function(o){ return o[0] === k; })[0] || ['', 'traguardo'])[1];
  return { id: 'genio-' + k, t: frase, media: null, inventato: true, k: k, nome: nome };
}

/** Il mantra di questo periodo: il più allineato, a rotazione fra i pari merito; se nessuno
 *  è allineato, quello che il Genio compone dal traguardo. */
function m369Scegli(v){
  const punteggi = v.lista.filter(function(m){ return m.t && m.t.trim(); })
    .map(function(m){ const b = m369Punteggio(m); return { m: m, p: b.p, k: b.k, nome: b.nome }; });
  /* I TUOI VINCONO SEMPRE, se ci sono. Il Genio ne compone uno solo quando la lista e' vuota:
     inventare al posto di chi ha gia' scritto i suoi era presuntuoso, e Andrea l'ha detto.
     Fra i tuoi, vince il piu' allineato ai traguardi; a parita' (anche a zero) si ruota. */
  if (!punteggi.length){
    const inv = m369Inventa();
    return inv ? { m: inv, p: 0, k: inv.k, nome: inv.nome, fra: 1, inventato: true } : null;
  }
  const top = Math.max.apply(null, punteggi.map(function(x){ return x.p; }));
  const pari = punteggi.filter(function(x){ return x.p === top; });
  const d = new Date();
  const sc = pari[(d.getFullYear() * 12 + d.getMonth()) % pari.length];
  return { m: sc.m, p: sc.p, k: sc.k, nome: sc.nome || '', fra: pari.length, inventato: false, allineato: top > 0 };
}

/**
 * Applica la scelta al motore: il mantra corrente diventa questo, con il suo audio o video.
 *
 * <p>Silenzioso: passa dal ponte diretto e non da settingsSave, perché una scelta del Genio a
 * inizio mese non è un tocco dell'utente e non deve far comparire «Impostazioni salvate».</p>
 */
async function m369Applica(forza){
  const v = m369Leggi();
  if (!v.on) return false;
  const periodo = m369Periodo();
  const sc = m369Scegli(v);
  if (!sc) return false;
  if (!forza && v.periodo === periodo && v.scelto === sc.m.id) return false;
  v.periodo = periodo; v.scelto = sc.m.id;
  v.perche = sc.inventato ? 'composto dal Genio: non hai ancora scritto un mantra'
    : sc.allineato ? 'parla del traguardo: ' + sc.nome.toLowerCase()
    : 'nessuno parla dei traguardi scritti: a rotazione fra i tuoi';
  v.inventato = sc.inventato ? sc.m.t : '';
  m369Salva(v);
  try{ localStorage.setItem('fl_why_mantra_369', sc.m.t); }catch(_){ }
  const patch = { mantraText: sc.m.t, m369On: true, m369A: v.bande[0], m369B: v.bande[1], m369C: v.bande[2] };
  /* L'AUDIO NON SI TOCCA. Solo un mantra con un file suo cambia l'azione della card: scrivere
     «none» per gli altri cancellava l'audio del «perche'», e il play non suonava più. */
  if (sc.m.media && sc.m.media.kind && sc.m.media.uri){
    patch.mantraAction = sc.m.media.kind;
    patch.mantraValue = sc.m.media.uri;
  }
  try{ if (typeof SETTINGS !== 'undefined' && SETTINGS) Object.assign(SETTINGS, patch); }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) await NATIVE.setSettings(patch); }catch(_){ }
  return true;
}

/* Le fasce e l'interruttore vanno al motore anche senza una scelta nuova. */
async function m369Motore(){
  const v = m369Leggi();
  const patch = { m369On: v.on, m369A: v.bande[0], m369B: v.bande[1], m369C: v.bande[2] };
  try{ if (typeof SETTINGS !== 'undefined' && SETTINGS) Object.assign(SETTINGS, patch); }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) await NATIVE.setSettings(patch); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA
   --------------------------------------------------------------------------------------- */

function m369Apri(){ goId('s-m369'); m369Paint(); }
function m369Indietro(){
  const host = document.getElementById('psMantra');
  const sc = host ? host.closest('.screen') : null;
  return sc && sc.id ? sc.id : 's-home';
}

function m369Paint(){
  const box = document.getElementById('m369Body');
  if (!box) return;
  const v = m369Leggi();
  const sc = v.on ? m369Scegli(v) : null;
  const orz = m369Traguardo;

  /* 0.9.295, Andrea: "rifai la pagina del mantra". Una cosa alla volta: in cima il mantra di questo mese, grande; sotto
     l'interruttore del metodo con gli orari dentro un pannello che si apre; poi i tuoi mantra, puliti. Le virgolette
     sono quelle normali. */
  const fit = function(m){ const b = m369Punteggio(m); return b.p > 0 ? 'Serve il traguardo: ' + esc(b.nome.toLowerCase()) : 'Entra a rotazione'; };
  const CESTINO = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>';
  box.innerHTML =
      '<div class="m3-hero">'
    + (sc
        ? '<small>Il tuo mantra di questo mese</small><b>"' + esc(sc.m.t) + '"</b>'
          + '<p>' + (sc.inventato ? 'L’ha composto il Genio: scrivi i tuoi e userà quelli' : sc.allineato ? 'Serve il traguardo: ' + esc(sc.nome.toLowerCase()) : 'A rotazione fra i tuoi') + '</p>'
        : '<small>Il tuo mantra</small><b>' + (v.on ? 'Scrivi il primo qui sotto' : 'Una frase, ripetuta al momento giusto') + '</b>'
          + '<p>' + (v.on ? 'Il Genio sceglie ogni mese quello più vicino ai tuoi traguardi.' : 'Accendi il metodo e la frase compare da sola tre volte al giorno.') + '</p>')
    + '</div>'
    + '<details class="m3-pan"' + (v.on ? '' : ' open') + '><summary><span><b>Metodo 3·6·9</b><small>' + (v.on ? 'Acceso: mattina, pomeriggio, sera' : 'Spento') + '</small></span>'
    +   '<button type="button" class="switch' + (v.on ? ' on' : '') + '" onclick="event.preventDefault();event.stopPropagation();m369Toggle()" aria-label="Accendi il metodo"></button></summary>'
    +   '<p class="m3-sotto">3 ripetizioni al mattino, 6 nel pomeriggio, 9 la sera: la card compare da sola a questi orari.</p>'
    +   '<div class="m369-bande">'
    +     [['☀️ 3× mattina', 0], ['⛅ 6× pomeriggio', 1], ['🌙 9× sera', 2]].map(function(b){
            return '<label><span>' + b[0] + '</span><input class="fin" type="time" value="' + m369Ora(v.bande[b[1]]) + '" onchange="m369Banda(' + b[1] + ', this.value)"></label>';
          }).join('')
    +   '</div></details>'
    + '<h3 class="m3-h">I tuoi mantra</h3>'
    + (v.lista.length ? v.lista.map(function(m){
        return '<div class="m3-m' + (sc && sc.m.id === m.id ? ' on' : '') + '">'
          + '<textarea class="fin" rows="2" placeholder="Il mantra" onchange="m369Testo(\'' + m.id + '\', this.value)">' + esc(m.t) + '</textarea>'
          + '<div class="m3-piede"><small>' + fit(m) + '</small>'
          +   '<button type="button" class="m3-ico" onclick="m369Media(\'' + m.id + '\',\'sound\')" aria-label="Registrazione audio">' + (m.media && m.media.kind === 'sound' ? '🎧' : '🎙️') + '</button>'
          +   '<button type="button" class="m3-ico" onclick="m369Media(\'' + m.id + '\',\'video\')" aria-label="Video">🎬</button>'
          +   (m.media ? '<button type="button" class="m3-ico" onclick="m369MediaVia(\'' + m.id + '\')" aria-label="Togli il file">✕</button>' : '')
          +   '<button type="button" class="m3-ico rosso" onclick="m369Togli(\'' + m.id + '\')" aria-label="Elimina">' + CESTINO + '</button></div>'
          + '</div>';
      }).join('') : '')
    + '<button type="button" class="m3-agg" onclick="m369Aggiungi()">+ Aggiungi un mantra</button>'
    + (sc ? '<button type="button" class="m3-link" onclick="m369Applica(true).then(function(){ toast(\'Mantra aggiornato\'); m369Paint(); })">Aggiorna il mantra del mese</button>' : '')
    + '<div class="spacer"></div>';
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.m3-hero{margin:6px 0 18px;padding:26px 20px;border-radius:24px;text-align:center;color:#fff;background:linear-gradient(150deg,#0E2350,#0B3E86)}'
    + '.m3-hero small{display:block;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#9FD8FF}'
    + '.m3-hero b{display:block;margin-top:12px;font:800 22px/1.35 var(--font-display);color:#fff}.m3-hero p{margin:12px 0 0;font:500 13.5px/1.45 var(--font-body);color:rgba(255,255,255,.75)}'
    + '.m3-pan{border-radius:20px;background:var(--card);border:1px solid var(--line);padding:0 16px;margin:0 0 22px}'
    + '.m3-pan summary{list-style:none;display:flex;align-items:center;gap:12px;padding:15px 0;cursor:pointer}.m3-pan summary::-webkit-details-marker{display:none}'
    + '.m3-pan summary>span{flex:1;min-width:0}.m3-pan summary b{display:block;font:800 16px var(--font-display);color:var(--navy)}.m3-pan summary small{display:block;margin-top:2px;font:600 12.5px var(--font-body);color:var(--muted)}'
    + '.m3-sotto{margin:0 0 10px;font:500 13px/1.45 var(--font-body);color:var(--muted)}.m3-pan .m369-bande{padding-bottom:14px}'
    + '.m3-h{margin:0 2px 10px;font:800 18px var(--font-display);color:var(--navy)}'
    + '.m3-m{margin:0 0 12px;padding:14px;border-radius:18px;background:var(--card);border:1px solid var(--line)}.m3-m.on{border-color:#0075E3;box-shadow:0 0 0 1.5px #0075E3 inset}'
    + '.m3-m textarea{width:100%;box-sizing:border-box;border:0;background:transparent;font:700 16px/1.4 var(--font-display);color:var(--navy);resize:none}'
    + '.m3-piede{display:flex;align-items:center;gap:6px;margin-top:6px}.m3-piede small{flex:1;min-width:0;font:600 12px var(--font-body);color:var(--muted)}'
    + '.m3-ico{flex:none;width:36px;height:36px;border:0;border-radius:50%;background:var(--blue-soft,#E6F2FF);color:var(--navy);display:flex;align-items:center;justify-content:center;font-size:16px;cursor:pointer}.m3-ico.rosso{color:#E5515F;background:rgba(229,81,95,.1)}'
    + '.m3-agg{display:block;width:100%;margin-top:4px;padding:14px;border:1.5px dashed var(--line);border-radius:16px;background:transparent;color:#0075E3;font:800 14.5px var(--font-body);cursor:pointer}'
    + '.m3-link{display:block;margin:14px auto 0;border:0;background:none;color:var(--muted);font:700 13px var(--font-body);text-decoration:underline;cursor:pointer}';
  document.head.appendChild(st);
})();

function m369Toggle(){
  const v = m369Leggi(); v.on = !v.on; m369Salva(v);
  m369Motore().then(function(){ if (v.on) m369Applica(true); });
  m369Paint();
  if (typeof personalizePaintMantra === 'function') try{ personalizePaintMantra(); }catch(_){ }
}
function m369Banda(i, val){
  const n = m369Min(val); if (n < 0) return;
  const v = m369Leggi(); v.bande[i] = n; m369Salva(v); m369Motore(); m369Paint();
}
function m369Aggiungi(){
  const v = m369Leggi();
  v.lista.push({ id: 'm' + Date.now().toString(36), t: '', media: null });
  m369Salva(v); m369Paint();
}
function m369Testo(id, t){
  const v = m369Leggi(); const m = v.lista.filter(function(x){ return x.id === id; })[0];
  if (!m) return; m.t = String(t || '').trim(); m369Salva(v); m369Applica(true); m369Paint();
}
function m369Tag(id, tag){
  const v = m369Leggi(); const m = v.lista.filter(function(x){ return x.id === id; })[0];
  if (!m) return; m.tag = tag; m369Salva(v); m369Applica(true); m369Paint();
}
function m369Togli(id){
  const v = m369Leggi(); v.lista = v.lista.filter(function(x){ return x.id !== id; });
  m369Salva(v); m369Applica(true); m369Paint();
}
async function m369Media(id, kind){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickMedia){ toast('Disponibile solo sul telefono'); return; }
  try{
    const r = await NATIVE.pickMedia({ kind: kind === 'sound' ? 'audio' : 'video' });
    const uri = r && (r.uri || r.value);
    if (!uri) return;
    const v = m369Leggi(); const m = v.lista.filter(function(x){ return x.id === id; })[0];
    if (!m) return;
    m.media = { kind: kind, uri: uri, name: String((r && r.name) || kind).replace(/^.*[\/:]/, '').slice(0, 24) };
    m369Salva(v); m369Applica(true); m369Paint();
  }catch(_){ }
}
function m369MediaVia(id){
  const v = m369Leggi(); const m = v.lista.filter(function(x){ return x.id === id; })[0];
  if (!m) return; m.media = null; m369Salva(v); m369Applica(true); m369Paint();
}

registerScreen('s-m369',
  '<div class="topbar"><button class="iconbtn" onclick="goId(m369Indietro())">‹</button>'
  + '<b class="blk-title">Metodo 3·6·9</b></div>'
  + '<div id="m369Body"></div>',
  { back: function(){ return m369Indietro(); } });

/* A ogni cambio di giorno e a ogni apertura: se il mese e' cambiato, il Genio risceglie. */
document.addEventListener('fl:giorno', function(){ m369Applica(false); });
setTimeout(function(){ m369Applica(false); }, 7000);

(function m369Stile(){
  const st = document.createElement('style');
  st.textContent = [
    '.m369-bande{display:flex;flex-direction:column;gap:8px;margin-top:12px}',
    '.m369-bande label{display:flex;align-items:center;gap:10px;font:600 13px var(--font-body);color:var(--navy)}',
    'body.dark .m369-bande label{color:#fff}',
    '.m369-bande label span{flex:1}',
    '.m369-bande .fin{width:auto;padding:8px 10px}',
    '.m369-scelto{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:6px}',
    '.m369-scelto b{display:block;font:800 16px/1.35 var(--font-display);color:var(--navy)}',
    'body.dark .m369-scelto b{color:#fff}',
    '.m369-scelto small{display:block;margin:6px 0 10px;font:500 12px var(--font-body);color:var(--muted)}',
    '.m369-m{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:12px;margin-bottom:10px}',
    '.m369-m.on{border-color:var(--blue);box-shadow:0 0 0 1px var(--blue)}',
    '.m369-m textarea{margin-bottom:8px;min-height:0;resize:none}',
    '.m369-fit{margin:0 0 8px;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.m369-m .ps-row{flex-wrap:wrap;gap:6px}',
    '.m369-m .ghostmini{margin-left:0}'
  ].join('\n');
  document.head.appendChild(st);
})();
