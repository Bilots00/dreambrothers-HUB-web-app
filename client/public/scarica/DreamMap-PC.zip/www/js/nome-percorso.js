/* ===========================================================================================
   ROADMAP O PERCORSO, SECONDO CHI LEGGE (0.9.364)

   Andrea: "per gli utenti giovani voglio che si chiami sempre roadmap: si capisce, come Black
   Friday. Per gli utenti piu' adulti, i boomer, va bene percorso. In base all'eta', che si deduce
   dalla data di nascita". Nel codice il nome e' uno solo ("il percorso", 0.9.361): qui, per chi ha
   meno di 55 anni (o non ha detto l'eta'), le scritte a schermo diventano "la roadmap", con articoli
   e accordi giusti. Le frasi lunghe vengono prima delle corte, cosi' "il tuo percorso e' pronto"
   diventa "la tua roadmap e' pronta" e non "la tua roadmap e' pronto".
   =========================================================================================== */
const NP_FRASI = [
  ['Il tuo percorso è pronto', 'La tua roadmap è pronta'],
  ['Il percorso è aggiornato', 'La roadmap è aggiornata'],
  ['Il percorso è cambiato', 'La roadmap è cambiata'],
  ['Il percorso è questo, eccolo', 'La roadmap è questa, eccola'],
  ['Il percorso non è ancora pronto', 'La roadmap non è ancora pronta'],
  ['Il percorso nuovo arriva', 'La roadmap nuova arriva'],
  ['il percorso intero', 'la roadmap intera'],
  ['Il percorso, aggiornato dalla tua AI', 'La roadmap, aggiornata dalla tua AI'],
  ['Il percorso lo fa la tua AI', 'La roadmap la fa la tua AI'],
  ['Aggiorna il percorso da solo', 'Aggiorna la roadmap da sola'],
  ['il percorso compare qui da solo', 'la roadmap compare qui da sola'],
  ['lo costruisce dal tuo sogno', 'la costruisce dal tuo sogno'],
  ['Il percorso ha i livelli già pronti', 'La roadmap ha i livelli già pronti'],
  ['Un percorso solo tuo', 'Una roadmap solo tua'],
  ['Percorso applicato', 'Roadmap applicata'],
  ['Percorso modificato', 'Roadmap modificata'],
  ['VAI AL PERCORSO', 'VAI ALLA ROADMAP'],
  ['il tuo percorso', 'la tua roadmap'], ['Il tuo percorso', 'La tua roadmap'],
  ['del tuo percorso', 'della tua roadmap'], ['dal tuo percorso', 'dalla tua roadmap'], ['Dal tuo percorso', 'Dalla tua roadmap'],
  ['sul tuo percorso', 'sulla tua roadmap'], ['nel tuo percorso', 'nella tua roadmap'], ['al tuo percorso', 'alla tua roadmap'],
  ['il mio percorso', 'la mia roadmap'], ['del mio percorso', 'della mia roadmap'], ['nel mio percorso', 'nella mia roadmap'],
  ['del percorso', 'della roadmap'], ['dal percorso', 'dalla roadmap'], ['Dal percorso', 'Dalla roadmap'],
  ['nel percorso', 'nella roadmap'], ['sul percorso', 'sulla roadmap'], ['al percorso', 'alla roadmap'],
  ['il percorso', 'la roadmap'], ['Il percorso', 'La roadmap'], ['un percorso', 'una roadmap'],
  ['Percorso', 'Roadmap'], ['percorso', 'roadmap']
];
function npEta(){
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null') || {};
    let b = u.birth || ''; if (!b && typeof scFuture === 'function') b = (scFuture() || {}).birth || '';
    const t = Date.parse(b); if (!t) return null;
    return Math.floor((Date.now() - t) / (365.25 * 86400000));
  }catch(_){ return null; }
}
/* "roadmap" per chi ha meno di 55 anni o non l'ha detto; "percorso" da 55 in su */
function npRoadmap(){ const e = npEta(); return !(e !== null && e >= 55); }
function npTesto(t){
  if (!t || t.indexOf('ercors') < 0 && t.indexOf('ERCORSO') < 0) return t;
  for (let i = 0; i < NP_FRASI.length; i++) if (t.indexOf(NP_FRASI[i][0]) >= 0) t = t.split(NP_FRASI[i][0]).join(NP_FRASI[i][1]);
  return t;
}
function npNodo(n){
  if (n.nodeType === 3){ const v = n.nodeValue; if (v && v.indexOf('ercors') >= 0 || v && v.indexOf('ERCORSO') >= 0){ const w = npTesto(v); if (w !== v) n.nodeValue = w; } return; }
  if (n.nodeType !== 1) return;
  const tag = n.tagName; if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA') return;
  ['placeholder', 'aria-label', 'title'].forEach(function(a){ const v = n.getAttribute && n.getAttribute(a); if (v && v.indexOf('ercors') >= 0){ const w = npTesto(v); if (w !== v) n.setAttribute(a, w); } });
  const it = document.createTreeWalker(n, NodeFilter.SHOW_TEXT, null); let x;
  while ((x = it.nextNode())){ const v = x.nodeValue; if (v && (v.indexOf('ercors') >= 0 || v.indexOf('ERCORSO') >= 0)){ const w = npTesto(v); if (w !== v) x.nodeValue = w; } }
}
(function(){
  if (typeof document === 'undefined') return;
  let coda = [], attesa = 0;
  const lavora = function(){ attesa = 0; if (!npRoadmap()){ coda = []; return; } const l = coda; coda = []; l.forEach(function(n){ try{ if (n.isConnected) npNodo(n); }catch(_){ } }); };
  const metti = function(n){ coda.push(n); if (!attesa) attesa = requestAnimationFrame(lavora); };
  const parti = function(){
    try{ metti(document.body); }catch(_){ }
    try{ new MutationObserver(function(ms){ ms.forEach(function(m){ if (m.type === 'characterData') metti(m.target); else m.addedNodes.forEach(metti); }); }).observe(document.body, { childList: true, subtree: true, characterData: true }); }catch(_){ }
  };
  if (document.body) parti(); else document.addEventListener('DOMContentLoaded', parti);
})();
