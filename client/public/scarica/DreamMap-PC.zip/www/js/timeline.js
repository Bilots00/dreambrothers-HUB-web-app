/* ===========================================================================================
   LA TIMELINE: LA RADIOGRAFIA DELLA GIORNATA (0.9.303)

   Tutte le altre schermate rispondono con delle somme: "ieri quattro ore, di cui due su
   TikTok". Qui c'e' la fila, e da questa versione anche COSA si faceva dentro le app: su Chrome
   il sito o la ricerca, nell'app Google la ricerca, negli assistenti la domanda, su YouTube il
   titolo del video o gli Shorts, su Instagram reel, storie, messaggi o feed. Andrea: "cosa mi
   significa 08:34 Instagram 7 secondi? Cosa stavo facendo?".

   DA DOVE ARRIVANO I DATI
     - QUANDO e PER QUANTO: la cronologia d'uso di Android (NATIVE.getTimeline), circa una
       settimana, senza permessi nuovi. Il launcher (One UI Home e ogni altro) non conta mai:
       ci si torna per forza quando si esce da un'app, non e' una cosa che si fa.
     - COSA: la radiografia (Radiografia.java, letta con NATIVE.getRadiografia). Il servizio di
       accessibilita' annota una riga quando lo schermo cambia cosa mostra. Resta sul telefono,
       quattordici giorni, mai le password, mai il testo delle chat. Non fa scattare blocchi.
       Si spegne dai tre puntini: "Registra cosa fai dentro le app".
     - Le scelte: Full Focus (fl_ff_hist), il piano, le spunte, i blocchi interrotti, i punti.
     - Il carburante: oggi le voci vere del motore della dopamina (dpCalcola), i giorni
       passati solo il carburante guadagnato (fl_dopa_checkin). Mai numeri stimati.

   LA FUNZIONE PER GLI ALTRI FILE
     tlRadiografia(giornoISO, daMs, aMs) -> Promise<Array<{t, durMs, pkg, app, cosa, tipo, url}>>
       giornoISO  'YYYY-MM-DD' (vuoto = oggi)
       daMs, aMs  istanti assoluti in ms; se piu' piccoli di due giorni valgono come
                  millisecondi dalla mezzanotte di quel giorno; vuoti = tutto il giorno
       tipo       'ricerca' | 'sito' | 'video' | 'ai' | 'reel' | 'storie' | 'messaggi' | 'feed' | 'app'
       cosa       la frase letta dallo schermo ("voli per lisbona", "Storie di marco", il
                  titolo del video), '' quando si sa solo l'app
       Ordinati per tempo, senza il launcher. Un evento e' un pezzo di un'apertura: se dentro
       Instagram si passa dal feed ai reel, sono due eventi. Fuori dall'app installata: [].
       La usa il Rientra in rotta per capire da solo cosa ha portato fuori rotta.

   LA PAGINA, dall'alto (0.9.304, Andrea: "troppo confusionaria, non hai usato OEOF"):
     - il report, nello stile delle statistiche della partita (partita-stats.js: pannello scuro,
       schede che scorrono di lato). Schede: Riepilogo (il Genio, al massimo tre cose notate),
       Ore del giorno, App, Ricerche, Carburante, le schede fatte dalla persona e "+" (0.9.353, come nelle
       statistiche della partita: si scrive cosa tenere d'occhio e nasce una scheda). I filtri stanno
       dietro ai tre puntini del pannello (tlFiltriApri): prima si sceglie la voce, poi il suo
       controllo; il filtro acceso resta come pillola sotto al titolo e si toglie con la X.
     - i momenti della giornata, cinque per pagina, con l'immagine e il pulsante per condividerli;
     - ora per ora, con ogni apertura e cosa c'era dentro.
   Tolti nella 0.9.304: Jordan e l'itinerario che propone, "Dentro DreamMap" (il Report ha gia'
   l'interruttore), la riga del motore delle previsioni.
   =========================================================================================== */

const TL = { off: 0, min: 0, dati: null, radio: null, ev: [], carb: null, carbOff: -1, token: 0, da: 'insights',
             pag: 0, fascia: 'tutto', fDa: '08:00', fA: '12:00', cat: 'tutto', app: '', tab: 'riepilogo',
             bozza: '', esito: '', mod: '' };
const TL_MIN_KEY = 'fl_tl_min';
const TL_PER_PAGINA = 5;

/* Le tre finezze del dettaglio, dai tre puntini. */
const TL_SOGLIE = [
  [0, 'Tutto', 'Anche i passaggi da un secondo: sono quelli che raccontano l\'abitudine.'],
  [10000, 'Da 10 secondi in su', 'Toglie i rimbalzi involontari e le schermate di passaggio.'],
  [60000, 'Da un minuto in su', 'Solo le volte in cui ci sei rimasto davvero.']
];

function tlMin(){
  try{ const v = parseInt(localStorage.getItem(TL_MIN_KEY) || '0', 10); return isNaN(v) ? 0 : v; }
  catch(_){ return 0; }
}
function tlSetMin(v){
  try{ localStorage.setItem(TL_MIN_KEY, String(v)); }catch(_){ }
  TL.min = v;
  tlMenuClose();
  tlCarica();
}

/* ---------------------------------------------------------------------------------------
   TEMPO IN PAROLE (al secondo: un'apertura da otto secondi e' il granello che si viene a vedere)
   --------------------------------------------------------------------------------------- */
function tlDur(ms){
  ms = Math.max(0, Math.round(ms || 0));
  const s = Math.round(ms / 1000);
  if (s < 60) return s + 's';
  const m = Math.floor(s / 60);
  if (m < 60) return (s % 60 >= 30 ? m + 1 : m) + 'min';
  const h = Math.floor(m / 60);
  return (m % 60) ? h + 'h ' + (m % 60) + 'min' : h + 'h';
}
function tlOra(t){
  const d = new Date(t);
  return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
}
function tlOraSec(t){
  const d = new Date(t);
  return tlOra(t) + ':' + ('0' + d.getSeconds()).slice(-2);
}
function tlNum(v){
  const r = Math.round(Math.abs(v) * 10) / 10;
  return String(r).replace('.', ',');
}

/* Un colore stabile per ogni app, preso solo dai colori del brand. */
const TL_TINTE = ['#0075E3', '#3F9FF4', '#E63946', '#005BB0', '#8CC6FF', '#C42B38', '#14234A', '#E71D4F', '#0E2350'];
function tlTinta(pkg){
  let h = 0;
  const s = String(pkg || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 9973;
  return TL_TINTE[h % TL_TINTE.length];
}

function tlGiorno(off){
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  return d.getTime();
}
function tlNomeGiorno(off){
  if (off === 0) return 'Oggi';
  if (off === 1) return 'Ieri';
  const d = new Date(tlGiorno(off));
  return d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' });
}
/** "Oggi alle 14:50", "Ieri alle 09:12", "Lunedì 26 alle 21:04". */
function tlQuando(t){
  const off = Math.round((tlGiorno(0) - new Date(new Date(t).setHours(0, 0, 0, 0)).getTime()) / 86400000);
  let g;
  if (off === 0) g = 'Oggi';
  else if (off === 1) g = 'Ieri';
  else { const s = new Date(t).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric' }); g = s.charAt(0).toUpperCase() + s.slice(1); }
  return g + ' alle ' + tlOra(t);
}

/* ---------------------------------------------------------------------------------------
   IL LAUNCHER NON CONTA MAI (Andrea, 28/10)
   Si torna alla schermata Home ogni volta che si esce da un'app: contarla diceva "hai aperto
   One UI Home 141 volte", che e' vero e non vuol dire niente.
   --------------------------------------------------------------------------------------- */
const TL_HOME_KEY = 'fl_tl_home';
function tlHome(){ try{ return localStorage.getItem(TL_HOME_KEY) || ''; }catch(_){ return ''; } }
function tlLauncher(pkg){
  const p = String(pkg || '').toLowerCase();
  if (!p) return false;
  const h = tlHome();
  if (h && p === h.toLowerCase()) return true;
  return /launcher|nexuslauncher|^com\.miui\.home$|\.home$|^com\.android\.systemui$|^android$/.test(p);
}
function tlSenzaLauncher(grani){
  return (grani || []).filter(function(x){ return x && !tlLauncher(x.p); });
}

/* ---------------------------------------------------------------------------------------
   LE ICONE (si chiedono una volta e restano)
   --------------------------------------------------------------------------------------- */
const TL_ICONE = {};
async function tlIcona(pkg){
  if (!pkg) return '';
  if (TL_ICONE[pkg] !== undefined) return TL_ICONE[pkg];
  TL_ICONE[pkg] = '';
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getAppIcon){
      const r = await NATIVE.getAppIcon({ packageName: pkg });
      TL_ICONE[pkg] = (r && (r.icon || r.dataUri || r.png)) || '';
    }
  }catch(_){ }
  return TL_ICONE[pkg];
}
function tlIniziale(nome){ const s = String(nome || '?').trim(); return esc((s.charAt(0) || '?').toUpperCase()); }
function tlIconaTag(pkg, px, tinta, nome){
  const d = TL_ICONE[pkg];
  if (d) return '<img class="tl-ico" style="width:' + px + 'px;height:' + px + 'px" src="'
    + d.replace(/"/g, '') + '" alt="">';
  return '<span class="tl-ico tl-ico-vuota" style="width:' + px + 'px;height:' + px + 'px;background:'
    + (tinta || tlTinta(pkg)) + ';font-size:' + Math.round(px * 0.45) + 'px">' + tlIniziale(nome || pkg) + '</span>';
}

/* ---------------------------------------------------------------------------------------
   LA RADIOGRAFIA: le aperture di Android, spezzate in quello che c'era dentro
   --------------------------------------------------------------------------------------- */
async function tlRadioLeggi(from, to){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getRadiografia) return null;
    const r = await NATIVE.getRadiografia({ from: from, to: to });
    if (r && r.home){ try{ localStorage.setItem(TL_HOME_KEY, String(r.home)); }catch(_){ } }
    return r || null;
  }catch(_){ return null; }
}

/**
 * Le aperture (grani) incrociate con le osservazioni: ogni apertura diventa uno o piu' eventi
 * {t, durMs, pkg, app, cosa, tipo, url, g}. g e' l'indice dell'apertura, per contare "quante
 * volte". Le osservazioni fuori da ogni apertura (la cronologia di Android non le ha viste)
 * restano come eventi da zero secondi.
 */
function tlEventiDa(grani, oss){
  const out = [];
  const perPkg = {};
  (oss || []).forEach(function(o){ if (o && o.p) (perPkg[o.p] = perPkg[o.p] || []).push(o); });
  Object.keys(perPkg).forEach(function(k){ perPkg[k].sort(function(a, b){ return a.t - b.t; }); });
  const usate = new Set();
  (grani || []).forEach(function(g, gi){
    const fine = g.s + (g.ms || 0);
    const app = g.l || g.p;
    const dentro = (perPkg[g.p] || []).filter(function(o){ return o.t >= g.s - 3000 && o.t < fine; });
    dentro.forEach(function(o){ usate.add(o); });
    const pezzi = [];
    dentro.forEach(function(o){
      const k = (o.tipo || '') + '|' + (o.cosa || '') + '|' + (o.url || '');
      if (pezzi.length && pezzi[pezzi.length - 1].k === k) return;
      pezzi.push({ o: o, k: k });
    });
    if (!pezzi.length){
      out.push({ t: g.s, durMs: g.ms || 0, pkg: g.p, app: app, cosa: '', tipo: 'app', url: '', g: gi });
      return;
    }
    const primo = Math.max(g.s, pezzi[0].o.t);
    if (primo - g.s >= 3000) out.push({ t: g.s, durMs: primo - g.s, pkg: g.p, app: app, cosa: '', tipo: 'app', url: '', g: gi });
    pezzi.forEach(function(p, i){
      const s = Math.max(g.s, p.o.t);
      const e = i + 1 < pezzi.length ? Math.max(s, Math.min(fine, pezzi[i + 1].o.t)) : fine;
      out.push({ t: s, durMs: e - s, pkg: g.p, app: app, cosa: String(p.o.cosa || ''), tipo: String(p.o.tipo || 'app'), url: String(p.o.url || ''), g: gi });
    });
  });
  (oss || []).forEach(function(o){
    if (!o || usate.has(o) || tlLauncher(o.p)) return;
    out.push({ t: o.t, durMs: 0, pkg: o.p, app: tlNomeApp(o.p), cosa: String(o.cosa || ''), tipo: String(o.tipo || 'app'), url: String(o.url || ''), g: -1 });
  });
  out.sort(function(a, b){ return a.t - b.t; });
  return out;
}
const TL_NOMI = {};
function tlNomeApp(pkg){
  if (TL_NOMI[pkg]) return TL_NOMI[pkg];
  try{ const n = JSON.parse(localStorage.getItem('fl_app_nomi') || '{}') || {}; if (n[pkg]) return n[pkg]; }catch(_){ }
  const noti = { 'com.android.chrome': 'Chrome', 'com.google.android.googlequicksearchbox': 'Google', 'com.google.android.youtube': 'YouTube',
    'com.instagram.android': 'Instagram', 'com.whatsapp': 'WhatsApp', 'com.google.android.apps.bard': 'Gemini', 'com.openai.chatgpt': 'ChatGPT' };
  return noti[pkg] || String(pkg || '').split('.').pop();
}

/** Il giorno ISO in millisecondi (mezzanotte locale). */
function tlIsoMs(iso){
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ''));
  if (!m) return tlGiorno(0);
  return new Date(+m[1], +m[2] - 1, +m[3]).getTime();
}

/**
 * Cosa ha fatto l'utente in una finestra di tempo (vedi la testa del file).
 * @return {Promise<Array<{t:number,durMs:number,pkg:string,app:string,cosa:string,tipo:string,url:string}>>}
 */
async function tlRadiografia(giornoISO, daMs, aMs){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return [];
    const g0 = tlIsoMs(giornoISO);
    const DUE = 2 * 86400000;
    const da = (daMs == null || daMs === '') ? g0 : (+daMs < DUE ? g0 + +daMs : +daMs);
    const a = (aMs == null || aMs === '') ? g0 + 86400000 : (+aMs < DUE ? g0 + +aMs : +aMs);
    const fine = Math.max(g0 + 86400000, a);
    const res = await Promise.all([
      NATIVE.getTimeline({ from: g0, to: fine, minMs: 0, limit: 6000 }).catch(function(){ return null; }),
      tlRadioLeggi(g0, fine)
    ]);
    const t = res[0], r = res[1];
    const grani = (t && t.granted) ? tlSenzaLauncher(t.grani) : [];
    const ev = tlEventiDa(grani, (r && r.eventi) || []);
    return ev.filter(function(e){ return e.durMs > 0 ? (e.t < a && e.t + e.durMs > da) : (e.t >= da && e.t < a); })
      .map(function(e){ return { t: e.t, durMs: e.durMs, pkg: e.pkg, app: e.app, cosa: e.cosa, tipo: e.tipo, url: e.url }; });
  }catch(_){ return []; }
}

/* ---------------------------------------------------------------------------------------
   IL RIASSUNTO (lo stesso numero che legge il Genio: vive qui perche' la frase e la previsione
   devono usare gli stessi fatti). LAMPO = un'apertura sotto ai trenta secondi.
   --------------------------------------------------------------------------------------- */
const TL_LAMPO = 30000;

function tlRiassunto(d){
  const g = tlSenzaLauncher((d && d.grani) || []);
  const r = { tot: 0, riprese: g.length, lampi: 0, piuLunga: null, notte: 0, perApp: [], primo: 0, ultimo: 0, fuoco: 0, oraRotta: -1 };
  if (!g.length) return r;

  const mappa = {};
  const perOra = new Array(24).fill(0);
  g.forEach(function(x){
    const ms = x.ms || 0;
    r.tot += ms;
    if (ms < TL_LAMPO) r.lampi++;
    if (!r.piuLunga || ms > r.piuLunga.ms) r.piuLunga = x;
    const h = new Date(x.s).getHours();
    perOra[h]++;
    if (h < 5) r.notte += ms;
    const k = x.p || x.l;
    if (!mappa[k]) mappa[k] = { p: x.p, l: x.l, ms: 0, n: 0, lampi: 0, piu: 0 };
    mappa[k].ms += ms;
    mappa[k].n++;
    if (ms < TL_LAMPO) mappa[k].lampi++;
    if (ms > mappa[k].piu) mappa[k].piu = ms;
  });

  r.primo = g[0].s;
  r.ultimo = g[g.length - 1].s + (g[g.length - 1].ms || 0);

  /* il buco piu' lungo, solo di giorno: di notte e' il sonno */
  for (let i = 1; i < g.length; i++){
    const fine = g[i - 1].s + (g[i - 1].ms || 0);
    const h = new Date(fine).getHours();
    if (h < 7 || h >= 23) continue;
    const buco = g[i].s - fine;
    if (buco > r.fuoco) r.fuoco = buco;
  }

  /* l'ora in cui la giornata si e' rotta: quella con piu' riprese, non con piu' minuti */
  let picco = 0;
  for (let h = 0; h < 24; h++) if (perOra[h] > picco){ picco = perOra[h]; r.oraRotta = h; }
  if (picco < 6) r.oraRotta = -1;

  r.perApp = Object.keys(mappa).map(function(k){ return mappa[k]; })
    .sort(function(a, b){ return b.ms - a.ms; });
  return r;
}

/* 0.9.322, Andrea: "'hai aperto Chrome 30 volte: e' un riflesso' non vuol dire un cazzo. Deve scovare come Sherlock Holmes
   quello che da solo non vedresti, e dipende dal sogno: il tempo al telefono conta solo se il sogno e' usarlo di meno".
   Ogni indizio e' un incrocio di dati veri dell'app (blocchi, sessioni, tappe, carburante, umore) e compare solo se i numeri lo
   reggono. Vale l'ordine: prima quello che e' successo in quel giorno, poi le abitudini degli ultimi trenta. */
function tlSognoSulTelefono(){
  try{ return /telefono|schermo|social|scroll|distrazion|dipendenz|smartphone/i.test(String(nvSogno() || '')); }catch(_){ return false; }
}
function tlLs(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function tlK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function tlNum(v){ return String(Math.round(v * 10) / 10).replace('.', ','); }
/* i blocchi di un giorno, dal motore: si leggono una volta e la scheda si ridisegna */
function tlBlocchi(off){
  TL.blk = TL.blk || {};
  if (off in TL.blk) return TL.blk[off];
  TL.blk[off] = null;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getRegistroBlocchi){
      NATIVE.getRegistroBlocchi({ days: off + 2 }).then(function(res){
        const da = tlGiorno(off), a = da + 86400000;
        TL.blk[off] = ((res && res.items) || []).filter(function(x){ return x && +x.t >= da && +x.t < a; });
        if (TL.pag === 0 && TL.off === off){ try{ tlPaint(); }catch(_){ } }
      }).catch(function(){ });
    }
  }catch(_){ }
  return null;
}
function tlIndizioBlocchi(off, grani){
  const it = tlBlocchi(off); if (!it || !it.length) return [];
  const out = [], quando = off === 0 ? 'Oggi' : 'Quel giorno';
  const perNome = {}, perOra = {};
  it.forEach(function(x){ const n = x.n || x.c || 'un’app'; perNome[n] = (perNome[n] || 0) + 1; const h = new Date(+x.t).getHours(); perOra[h] = (perOra[h] || 0) + 1; });
  const top = Object.keys(perNome).sort(function(a, b){ return perNome[b] - perNome[a]; })[0];
  const oraTop = +Object.keys(perOra).sort(function(a, b){ return perOra[b] - perOra[a]; })[0];
  let t = quando + ' i blocchi ti hanno fermato <strong>' + (it.length === 1 ? 'una volta' : it.length + ' volte') + '</strong>';
  if (it.length > 1 && perNome[top] > 1) t += ', ' + perNome[top] + ' su <strong>' + esc(top) + '</strong>';
  /* 0.9.353: dopo i due punti si va a capo (regola di Andrea): qui un punto */
  if (it.length >= 3 && perOra[oraTop] * 2 >= it.length) t += '. La tentazione arriva fra le ' + oraTop + ' e le ' + ((oraTop + 1) % 24);
  out.push({ ico: '🛡️', html: t + '.' });
  /* il grilletto: dove eri subito prima di cercare quell'app */
  const prima = {};
  it.filter(function(x){ return (x.n || x.c) === top; }).forEach(function(x){
    let g = null; (grani || []).forEach(function(v){ if (v.s < +x.t && v.l && v.l !== top && !tlLauncher(v.p) && v.p !== TL_DM) g = v; });
    if (g && +x.t - g.s - (g.ms || 0) < 5 * 60000) prima[g.l] = (prima[g.l] || 0) + 1;
  });
  const pr = Object.keys(prima).sort(function(a, b){ return prima[b] - prima[a]; })[0];
  if (pr && prima[pr] >= 2) out.push({ ico: '🔎', html: 'Prima di cercare ' + esc(top) + ', <strong>' + (prima[pr] === 2 ? 'due volte' : prima[pr] + ' volte') + '</strong> eri su ' + esc(pr) + '. Il grilletto sta lì.' });
  return out;
}
function tlIndizioMomento(){
  const da = Date.now() - 30 * 86400000, h = tlLs('fl_ff_hist', []).filter(function(x){ return x && x.at >= da && !x.meditazione; });
  const F = [['la mattina', 5, 12], ['il pomeriggio', 12, 18], ['la sera', 18, 24]].map(function(b){
    const l = h.filter(function(x){ const o = new Date(x.start || x.at).getHours(); return o >= b[1] && o < b[2]; });
    return { n: b[0], tot: l.length, ok: l.filter(function(x){ return x.ok; }).length };
  }).filter(function(b){ return b.tot >= 3; }).sort(function(a, b){ return b.ok / b.tot - a.ok / a.tot; });
  if (F.length < 2) return null;
  const su = F[0], giu = F[F.length - 1];
  if (su.ok / su.tot - giu.ok / giu.tot < 0.3) return null;
  return { tipo: 'fascia', ico: '🎯', html: 'Le sessioni iniziate ' + su.n + ' le finisci <strong>' + su.ok + ' volte su ' + su.tot + '</strong>, quelle ' + (giu.n === 'la sera' ? 'di sera' : giu.n === 'il pomeriggio' ? 'del pomeriggio' : 'di mattina') + ' ' + giu.ok + ' su ' + giu.tot + '. Il tuo momento è ' + su.n + '.' };
}
function tlSessioniPerGiorno(){
  const m = {}; tlLs('fl_ff_hist', []).forEach(function(x){ if (x && x.ok && !x.meditazione){ const k = tlK(x.at); m[k] = (m[k] || 0) + 1; } });
  return m;
}
function tlIndizioCarburante(){
  const g = tlLs('fl_dopa_giorni_v2', {}), s = tlSessioniPerGiorno(), alti = [], bassi = [];
  Object.keys(g).forEach(function(k){ const f = g[k] && g[k].fine; if (typeof f !== 'number') return; (f >= 60 ? alti : f < 40 ? bassi : []).push(s[k] || 0); });
  if (alti.length < 3 || bassi.length < 3) return null;
  const m = function(l){ return l.reduce(function(a, b){ return a + b; }, 0) / l.length; }, a = m(alti), b = m(bassi);
  if (Math.abs(a - b) < 0.5) return null;
  return { ico: '⛽', html: 'Quando il carburante finisce la giornata sopra 60 fai in media <strong>' + tlNum(a) + ' sessioni</strong>. Sotto 40, ' + tlNum(b) + '.' };
}
function tlIndizioUmore(){
  if (typeof umLeggi !== 'function') return null;
  const s = tlSessioniPerGiorno(), con = [], senza = [], oggi = new Date(); oggi.setHours(12, 0, 0, 0);
  for (let i = 1; i <= 30; i++){
    const k = tlK(oggi.getTime() - i * 86400000); let u = null;
    try{ u = umLeggi(k); }catch(_){ }
    if (u && u.sodd) (s[k] ? con : senza).push(u.sodd);
  }
  if (con.length < 3 || senza.length < 3) return null;
  const m = function(l){ return l.reduce(function(a, b){ return a + b; }, 0) / l.length; }, a = m(con), b = m(senza);
  if (a - b < 0.5) return null;
  return { ico: '😊', html: 'Nei giorni con una sessione finita il tuo umore è <strong>' + tlNum(a) + ' su 5</strong>. Negli altri ' + tlNum(b) + '. Si vede.' };
}
function tlIndizioMollate(off){
  const da = tlGiorno(off), a = da + 86400000, l = tlLs('fl_ff_hist', []).filter(function(x){ return x && x.at >= da && x.at < a && !x.ok && !x.meditazione; });
  if (!l.length) return null;
  const x = l[l.length - 1], min = Math.round((x.spentMs || 0) / 60000);
  return { ico: '⏱️', html: 'Hai interrotto la sessione delle <strong>' + tlOra(x.start || x.at) + '</strong> dopo ' + (min === 1 ? 'un minuto' : min + ' minuti') + (l.length > 1 ? ', e non è stata l’unica' : '') + '.' };
}
const TL_GIORNI_N = ['la domenica', 'il lunedì', 'il martedì', 'il mercoledì', 'il giovedì', 'il venerdì', 'il sabato'];
/** Il giorno della settimana in cui si saltano piu' tappe, nelle ultime sei settimane: { d, no, tot } o null. */
function tlTappeConto(){
  let g = {}; try{ if (typeof sdGiorniFatti === 'function') g = sdGiorniFatti(); }catch(_){ return null; }
  const tot = [0, 0, 0, 0, 0, 0, 0], no = [0, 0, 0, 0, 0, 0, 0];
  if (!Object.keys(g).some(function(k){ return g[k] > 0; })) return null;
  const oggi = new Date(); oggi.setHours(12, 0, 0, 0);
  for (let i = 1; i <= 42; i++){ const t = oggi.getTime() - i * 86400000, d = new Date(t).getDay(); tot[d]++; if (!(g[tlK(t)] > 0)) no[d]++; }
  let peggio = 0; for (let d = 1; d < 7; d++) if (no[d] > no[peggio]) peggio = d;
  if (no[peggio] < 4 || no[peggio] === tot[peggio] && no.every(function(v, i){ return v === tot[i]; })) return null;
  return { d: peggio, no: no[peggio], tot: tot[peggio] };
}
function tlIndizioTappe(){
  const x = tlTappeConto(); if (!x) return null;
  const N = TL_GIORNI_N[x.d];
  return { tipo: 'tappe', ico: '🗓️', html: '<strong>' + N.charAt(0).toUpperCase() + N.slice(1) + '</strong> è il giorno in cui salti più tappe, ' + x.no + ' volte su ' + x.tot + '.' };
}
/** Gli indizi che il Genio puo' dare, al massimo tre: solo quelli che i numeri sostengono. */
function tlFrasi(r, off){
  let out = [];
  const add = function(x){ if (x) out.push(x); };
  try{ out = out.concat(tlIndizioBlocchi(off || 0, (TL.dati && tlSenzaLauncher(TL.dati.grani || [])) || [])); }catch(_){ }
  if (r && r.oraRotta >= 0){
    add({ ico: '⏰', html: 'L\'ora più difficile è stata quella delle <strong>' + ('0' + r.oraRotta).slice(-2) + ':00</strong>: lì hai preso il telefono più spesso.' });
  }
  [tlIndizioMollate.bind(null, off || 0), tlIndizioMomento, tlIndizioCarburante, tlIndizioUmore, tlIndizioTappe].forEach(function(f){ try{ add(f()); }catch(_){ } });
  if (r && r.notte >= 20 * 60000){
    add({ ico: '🌙', html: 'Fra mezzanotte e le cinque hai passato <strong>' + tlDur(r.notte) + '</strong> sullo schermo. Quel tempo lo paghi la mattina dopo.' });
  }
  /* il tempo al telefono vale come indizio solo se il sogno passa da li' */
  if (r && tlSognoSulTelefono()){
    if (r.fuoco >= 45 * 60000) add({ ico: '🌿', html: 'Il tratto più lungo senza telefono è durato <strong>' + tlDur(r.fuoco) + '</strong>. Sai già farlo, si tratta di rifarlo.' });
    if (r.piuLunga && !tlLauncher(r.piuLunga.p)) add({ ico: '⏳', html: 'La volta più lunga sei rimasto <strong>' + tlDur(r.piuLunga.ms) + '</strong> su ' + esc(r.piuLunga.l) + ', dalle ' + tlOra(r.piuLunga.s) + '.' });
  }
  return out.slice(0, 3);
}

/* ---------------------------------------------------------------------------------------
   I PATTERN DI CHI HA PREMIUM (0.9.353)
   Andrea: "le cose notate sono deboli: 'i blocchi ti hanno fermato 2 volte', 'l'ora piu' difficile e' stata quella delle 13'.
   Per chi ha Premium cerca da solo i pattern utili con i dati che l'app ha gia': la prima app dopo la sveglia e quanto ci metti
   a cominciare, la fascia in cui rendi di piu', il giorno in cui salti piu' tappe, quanto durano le sessioni rispetto al previsto".
   Ogni pattern ha un peso e compare solo se i numeri lo reggono: restano i tre piu' pesanti; con meno di due si completano
   con quelli di tutti (tlFrasi), senza doppioni dello stesso tipo.
   --------------------------------------------------------------------------------------- */
function tlMinTxt(m){
  m = Math.max(0, Math.round(m || 0));
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + (r === 1 ? '1 minuto' : r + ' minuti') : '');
}
/** L'ora della sveglia di un giorno (g0 = mezzanotte): la notte gia' contata da sonno.js, altrimenti 0. */
function tlSvegliaDi(g0){
  try{ const m = (typeof SN_MEM !== 'undefined') ? SN_MEM[String(g0)] : null; if (m && m.n && m.n.ok && m.n.sveglia) return +m.n.sveglia; }catch(_){ }
  const v = tlLs('fl_sonno_' + tlK(g0), null);
  return (v && v.n && v.n.ok && v.n.sveglia) ? +v.n.sveglia : 0;
}
/** La prima sessione di Full Focus dopo la sveglia (o il primo messaggio al tuo agente), nello stesso giorno. */
function tlPrimaMossa(g0, sv, soloFF){
  const fine = g0 + 86400000; let p = null;
  tlLs('fl_ff_hist', []).forEach(function(x){
    if (!x || x.meditazione) return;
    const t = +(x.start || (x.at - (x.spentMs || 0))) || 0;
    if (t >= sv && t < fine && (!p || t < p.t)) p = { t: t, ff: true };
  });
  if (!soloFF){ try{ if (typeof cloMessaggi === 'function') cloMessaggi().forEach(function(t){ if (t >= sv && t < fine && (!p || t < p.t)) p = { t: t, ff: false }; }); }catch(_){ } }
  return p;
}
function tlPatSveglia(off){
  const g0 = tlGiorno(off);
  const g = tlSenzaLauncher((TL.dati && TL.dati.grani) || []).filter(function(x){ return x.p !== TL_DM && !/clock|alarm/i.test(x.p); });
  let sv = tlSvegliaDi(g0);
  /* senza la notte contata: la prima apertura dopo le quattro, arrivata dopo almeno tre ore di telefono fermo */
  if (!sv) for (let i = 0; i < g.length; i++){
    if (g[i].s < g0 + 4 * 3600000) continue;
    const prima = i ? g[i - 1].s + (g[i - 1].ms || 0) : 0;
    if (!prima || g[i].s - prima >= 3 * 3600000){ sv = g[i].s; break; }
  }
  if (!sv) return null;
  const app = g.filter(function(x){ return x.s >= sv - 120000 && x.s < sv + 3 * 3600000; })[0];
  if (!app) return null;
  const p = tlPrimaMossa(g0, sv, false);
  /* "di solito": le altre mattine delle ultime due settimane con la notte contata e una sessione di Full Focus */
  const l = [];
  for (let d = 1; d <= 14; d++){
    const g1 = tlGiorno(off + d), s1 = tlSvegliaDi(g1); if (!s1) continue;
    const p1 = tlPrimaMossa(g1, s1, true); if (p1 && p1.t - s1 < 14 * 3600000) l.push(p1.t - s1);
  }
  l.sort(function(a, b){ return a - b; });
  const solito = l.length >= 3 ? l[Math.floor(l.length / 2)] : 0;
  let t = 'La prima app che hai aperto dopo la sveglia è stata <strong>' + esc(app.l || tlNomeApp(app.p)) + '</strong>.', peso = 90;
  if (p){
    t += ' ' + (p.ff ? 'Hai cominciato la prima sessione di Full Focus' : 'Hai scritto il primo messaggio al tuo agente personale')
      + (p.t - sv < 60000 ? ' subito dopo.' : ' <strong>' + tlMinTxt((p.t - sv) / 60000) + '</strong> dopo.');
    if (p.ff && solito) t += ' Di solito ci metti ' + tlMinTxt(solito / 60000) + '.';
  } else if (off === 0) t += ' La sveglia era alle ' + tlOra(sv) + ' e non hai ancora cominciato una sessione di Full Focus.';
  else { t += ' Quel giorno non hai fatto sessioni di Full Focus.'; peso = 40; }
  return { tipo: 'sveglia', ico: '🌅', peso: peso, html: t };
}
/* l'app che ne apre un'altra: due aperture una dopo l'altra, a meno di un minuto, almeno tre volte */
function tlPatCatena(off){
  const g = tlSenzaLauncher((TL.dati && TL.dati.grani) || []).filter(function(x){ return x.p !== TL_DM; });
  const n = {}, nomi = {};
  for (let i = 1; i < g.length; i++){
    const a = g[i - 1], b = g[i];
    if (a.p === b.p || b.s - (a.s + (a.ms || 0)) > 60000) continue;
    const k = a.p + '>' + b.p; n[k] = (n[k] || 0) + 1;
    nomi[a.p] = a.l || tlNomeApp(a.p); nomi[b.p] = b.l || tlNomeApp(b.p);
  }
  const k = Object.keys(n).sort(function(x, y){ return n[y] - n[x]; })[0];
  if (!k || n[k] < 3) return null;
  const pz = k.split('>'), da = esc(nomi[pz[0]]), a = esc(nomi[pz[1]]);
  return { tipo: 'catena', ico: '🔗', peso: 70 + n[k] * 3,
           html: (off === 0 ? 'Oggi' : 'Quel giorno') + ' hai aperto <strong>' + a + '</strong> subito dopo ' + da + ' per <strong>' + n[k] + ' volte</strong>. È ' + da + ' che ti porta su ' + a + '.' };
}
/* la fascia in cui le sessioni di Full Focus arrivano fino in fondo, negli ultimi trenta giorni */
function tlPatFascia(){
  const da = Date.now() - 30 * 86400000;
  const h = tlLs('fl_ff_hist', []).filter(function(x){ return x && x.at >= da && !x.meditazione; });
  const F = [[6, 9], [9, 12], [12, 15], [15, 18], [18, 21], [21, 24]].map(function(b){
    const l = h.filter(function(x){ const o = new Date(x.start || x.at).getHours(); return o >= b[0] && o < b[1]; });
    return { a: b[0], b: b[1], tot: l.length, ok: l.filter(function(x){ return x.ok; }).length };
  }).filter(function(b){ return b.tot >= 3; });
  if (!F.length) return null;
  F.sort(function(x, y){ return (y.ok / y.tot - x.ok / x.tot) || (y.tot - x.tot); });
  const su = F[0], giu = F[F.length - 1], d = F.length > 1 ? su.ok / su.tot - giu.ok / giu.tot : 0;
  const nome = function(b){ return 'fra le ' + b.a + ' e ' + (b.b === 24 ? 'mezzanotte' : 'le ' + b.b); };
  const sess = function(b){ return (b.ok === 1 ? '1 sessione' : b.ok + ' sessioni') + ' di Full Focus su ' + b.tot; };
  if (d >= 0.25) return { tipo: 'fascia', ico: '🎯', peso: 60 + Math.round(d * 40),
    html: 'Lavori meglio ' + nome(su) + '. Lì finisci <strong>' + sess(su) + '</strong>. ' + nome(giu).charAt(0).toUpperCase() + nome(giu).slice(1) + ' ne finisci ' + giu.ok + ' su ' + giu.tot + '.' };
  if (su.tot >= 4 && su.ok / su.tot >= 0.8) return { tipo: 'fascia', ico: '🎯', peso: 45, html: 'Lavori meglio ' + nome(su) + '. Lì finisci <strong>' + sess(su) + '</strong>.' };
  return null;
}
/* quanto restano le sessioni di Full Focus rispetto ai minuti scelti, negli ultimi trenta giorni */
function tlPatDurata(){
  const da = Date.now() - 30 * 86400000;
  const l = tlLs('fl_ff_hist', []).filter(function(x){ return x && x.at >= da && !x.meditazione && (x.minPrevisti || x.min) >= 5; });
  if (l.length < 4) return null;
  let fatti = 0, previsti = 0;
  l.forEach(function(x){ fatti += (x.spentMs || 0) / 60000; previsti += +(x.minPrevisti || x.min); });
  const mf = Math.round(fatti / l.length), mp = Math.round(previsti / l.length), q = fatti / Math.max(1, previsti);
  const moll = l.filter(function(x){ return !x.ok && !x.prima; });
  const mm = moll.length >= 2 ? Math.round(moll.reduce(function(s, x){ return s + (x.spentMs || 0); }, 0) / moll.length / 60000) : 0;
  if (q >= 0.92) return { tipo: 'durata', ico: '⏱️', peso: 35, html: 'Le tue sessioni di Full Focus durano quanto le avevi previste, in media <strong>' + tlMinTxt(mf) + '</strong>.' };
  return { tipo: 'durata', ico: '⏱️', peso: 55 + Math.round((1 - q) * 50),
    html: 'Le tue sessioni di Full Focus durano in media <strong>' + tlMinTxt(mf) + '</strong>, invece dei ' + mp + ' minuti che avevi previsto.'
      + (mm ? ' Quando ti fermi prima, succede dopo <strong>' + tlMinTxt(mm) + '</strong>.' : '') };
}
function tlPatTappe(){
  const x = tlTappeConto(); if (!x) return null;
  const N = TL_GIORNI_N[x.d], plur = { 0: 'domeniche', 6: 'sabati' }[x.d] || N.replace(/^(la|il) /, '');
  return { tipo: 'tappe', ico: '🗓️', peso: 50 + Math.round(x.no / x.tot * 20),
    html: N.charAt(0).toUpperCase() + N.slice(1) + ' è il giorno in cui salti più tappe della mappa. Nelle ultime sei settimane, in <strong>' + x.no + ' ' + plur + ' su ' + x.tot + '</strong> non hai fatto nessuna tappa.' };
}
function tlFrasiPremium(r, off){
  const l = [];
  [tlPatSveglia, tlPatCatena, tlPatFascia, tlPatDurata, tlPatTappe].forEach(function(f){ try{ const x = f(off || 0, r); if (x) l.push(x); }catch(_){ } });
  l.sort(function(a, b){ return b.peso - a.peso; });
  const out = l.slice(0, 3);
  if (out.length < 2){
    const gia = {}; out.forEach(function(x){ gia[x.tipo] = 1; });
    tlFrasi(r, off).forEach(function(x){ if (out.length < 3 && !(x.tipo && gia[x.tipo])) out.push(x); });
  }
  return out;
}

/** Il riassunto di un giorno, per chi non vuole disegnare niente (l'oracolo). */
async function tlRiassuntoDi(off){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return null;
    const from = tlGiorno(off);
    const d = await NATIVE.getTimeline({ from: from, to: from + 86400000, minMs: 0, limit: 1800 });
    if (!d || !d.granted || !(d.grani || []).length) return null;
    const r = tlRiassunto(d);
    try{ if (typeof taDelGiorno === 'function'){ const t = taDelGiorno(off); r.dentro = { tot: t.tot, perArea: t.perArea.slice(0, 6), cat: t.cat }; } }catch(_){ }
    return r;
  }catch(_){ return null; }
}

/* ---------------------------------------------------------------------------------------
   LA VITA: quello che hai DECISO, non quello che hai aperto
     🌳 le sessioni di Full Focus (fl_ff_hist)   📝 il piano (fl_notes_log)   ✅ le spunte
     🚨 i blocchi interrotti (fl_interrupts_log)  ⚽ i punti della partita (fl_match_hist)
   --------------------------------------------------------------------------------------- */
function tlLeggi(chiave, def){
  try{ return JSON.parse(localStorage.getItem(chiave) || def) || JSON.parse(def); }
  catch(_){ return JSON.parse(def); }
}

function tlVita(from, to){
  const out = [];
  const dentro = function(t){ return t >= from && t < to; };
  (tlLeggi('fl_ff_hist', '[]') || []).forEach(function(h){
    const inizio = h.start || h.at;
    const fine = h.start && h.spentMs ? h.start + h.spentMs : h.at;
    if (!dentro(fine)) return;
    out.push({ at: fine, k: 'albero', ok: !!h.ok, inizio: inizio, fine: fine,
               spentMs: h.spentMs || 0, stage: typeof h.stage === 'number' ? h.stage : (h.ok ? 4 : 0),
               min: h.min || 0, tag: h.tag || '', intent: h.intent || '' });
  });
  (tlLeggi('fl_notes_log', '[]') || []).forEach(function(r){
    if (!dentro(r.at)) return;
    out.push({ at: r.at, k: r.k === 'tolta' ? 'tolta' : 'scritta', t: r.t || '' });
  });
  (tlLeggi('fl_notes_done', '[]') || []).forEach(function(r){
    if (!dentro(r.at)) return;
    out.push({ at: r.at, k: 'spunta', t: r.text || '', verificata: !!r.verified });
  });
  (tlLeggi('fl_interrupts_log', '[]') || []).forEach(function(r){
    if (!dentro(r.at)) return;
    out.push({ at: r.at, k: 'ceduto', id: r.id || '' });
  });
  (tlLeggi('fl_match_hist', '[]') || []).forEach(function(g){
    (g.eventi || []).forEach(function(e){
      if (!dentro(e.at)) return;
      out.push({ at: e.at, k: 'punto', chi: e.chi, motivo: e.motivo || '' });
    });
  });
  out.sort(function(a, b){ return a.at - b.at; });
  return out;
}

/** La pianta, presa in prestito da Full Focus: e' la stessa che hai visto crescere. */
function tlPianta(v){
  try{
    if (v.ok && typeof ffPlantSvg === 'function') return ffPlantSvg(4, false);
    if (!v.ok && typeof ffPlantWithered === 'function') return ffPlantWithered();
  }catch(_){ }
  return '<span class="tl-pianta-fallback">' + (v.ok ? '🌳' : '🥀') + '</span>';
}

const TL_VITA_ICO = { albero: '🌳', scritta: '📝', tolta: '🗑️', spunta: '✅', ceduto: '🚨', punto: '⚽' };

function tlVitaFrase(v){
  if (v.k === 'albero'){
    const fatti = Math.round((v.spentMs || 0) / 60000);
    return v.ok ? 'Hai portato a termine <b>' + fatti + ' min</b> di Full Focus' + (v.intent || v.tag ? ' su ' + esc(v.intent || v.tag) : '')
                : 'Hai mollato il Full Focus dopo <b>' + fatti + ' min</b>';
  }
  if (v.k === 'scritta') return 'Hai scritto nel piano: <b>' + esc(v.t || '') + '</b>';
  if (v.k === 'tolta') return 'Hai tolto dal piano: ' + esc(v.t || '');
  if (v.k === 'spunta') return 'Hai fatto <b>' + esc(v.t || '') + '</b>' + (v.verificata ? ' <i>(visto in Full Focus)</i>' : '');
  if (v.k === 'ceduto') return v.id === 'quick' ? 'Hai fermato il blocco rapido' : 'Hai interrotto un blocco';
  if (v.k === 'punto') return (v.chi === 'old' ? 'Hai dato un punto al Vecchio te' : 'Hai dato un punto al Nuovo te') + (v.motivo ? ': ' + esc(v.motivo) : '');
  return '';
}

/* ---------------------------------------------------------------------------------------
   IL CARBURANTE: oggi le voci vere del motore; i giorni passati solo quello guadagnato
   --------------------------------------------------------------------------------------- */
function tlCarburante(from, to){
  if (TL.carb && TL.carbOff === TL.off){
    return TL.carb.filter(function(v){ return v.t >= from && v.t < to && Math.abs(v.delta) >= 0.05; });
  }
  return (tlLeggi('fl_dopa_checkin', '[]') || []).filter(function(c){
    return c && typeof c.delta === 'number' && c.t >= from && c.t < to;
  }).map(function(c){ return { t: c.t, delta: c.delta, l: c.l || 'Carburante guadagnato', nota: c.nota || '' }; });
}
function tlCarbConto(lista){
  let su = 0, giu = 0;
  (lista || []).forEach(function(v){ if (v.delta > 0) su += v.delta; else giu -= v.delta; });
  return { su: su, giu: giu };
}

/* ---------------------------------------------------------------------------------------
   I FILTRI DEL REPORT
   --------------------------------------------------------------------------------------- */
const TL_FASCE = [
  ['tutto', 'Tutto il giorno', 0, 24],
  ['mattina', 'Mattina', 6, 12],
  ['pomeriggio', 'Pomeriggio', 12, 18],
  ['sera', 'Sera', 18, 24],
  ['notte', 'Notte', 0, 6],
  ['mia', 'Scegli tu', -1, -1]
];
const TL_CAT = [
  ['tutto', 'Tutto', '🧭'],
  ['social', 'Social', '💬'],
  ['video', 'Video', '▶️'],
  ['ricerche', 'Ricerche', '🔎'],
  ['siti', 'Siti', '🌐'],
  ['ai', 'Intelligenza artificiale', '✨'],
  ['messaggi', 'Messaggi', '✉️'],
  ['giochi', 'Giochi', '🎮'],
  ['dreammap', 'DreamMap', '🗺️'],
  ['altre', 'Altre app', '📱']
];
const TL_DM = 'com.dreambrothers.focuslock';

function tlMinuti(hhmm){ const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '')); return m ? (+m[1]) * 60 + (+m[2]) : 0; }
function tlFinestra(){
  const g0 = tlGiorno(TL.off);
  const f = TL_FASCE.filter(function(x){ return x[0] === TL.fascia; })[0] || TL_FASCE[0];
  if (f[0] === 'mia'){
    const a = tlMinuti(TL.fDa), b = tlMinuti(TL.fA);
    return { da: g0 + a * 60000, a: g0 + Math.max(a + 1, b) * 60000 };
  }
  return { da: g0 + f[2] * 3600000, a: g0 + f[3] * 3600000 };
}
function tlFasciaNome(){
  const f = TL_FASCE.filter(function(x){ return x[0] === TL.fascia; })[0] || TL_FASCE[0];
  if (f[0] === 'tutto') return 'in tutta la giornata';
  if (f[0] === 'mia') return 'dalle ' + TL.fDa + ' alle ' + TL.fA;
  return 'di ' + f[1].toLowerCase() + ', dalle ' + f[2] + ' alle ' + f[3];
}

function tlCatDi(e){
  const pkg = e.pkg;
  if (pkg === TL_DM) return 'dreammap';
  if (e.tipo === 'ricerca') return 'ricerche';
  if (e.tipo === 'ai') return 'ai';
  if (e.tipo === 'sito') return 'siti';
  if (e.tipo === 'messaggi') return 'messaggi';
  if (e.tipo === 'video') return 'video';
  if (e.tipo === 'reel' || e.tipo === 'storie' || e.tipo === 'feed') return pkg === 'com.google.android.youtube' ? 'video' : 'social';
  let c = '';
  try{ if (typeof rpCatDi === 'function') c = rpCatDi(pkg); }catch(_){ }
  if (c === 'social') return 'social';
  if (c === 'video') return 'video';
  if (c === 'msg') return 'messaggi';
  if (c === 'games') return 'giochi';
  if (/bard|chatgpt|anthropic|copilot|perplexity|deepseek|grok/.test(pkg)) return 'ai';
  return 'altre';
}

/** Gli eventi del giorno che passano i filtri, tagliati alla fascia oraria. */
/* 0.9.335, Andrea: i link aperti da Gmail (google.com/url?q=...) e la barra con "La connessione non è sicura" finivano fra le ricerche.
   Il telefono ora li riconosce; qui si ripuliscono anche quelli gia' registrati. */
function tlRicercaVera(e){
  if (!e || e.tipo !== 'ricerca' || !e.cosa) return e;
  const c = String(e.cosa).trim();
  let m = c.match(/^(?:https?:\/\/)?(?:www\.)?google\.[a-z.]+\/(?:url|imgres)\?(?:.*&)?(?:q|url)=([^&\s]+)/i), dest = '';
  if (m){ try{ dest = decodeURIComponent(m[1]); }catch(_){ dest = m[1]; } }
  else if (/^(https?:\/\/)?[a-z0-9-]+(\.[a-z0-9-]+)+(\/\S*)?$/i.test(c)) dest = c;
  else if ((m = c.match(/^(\S+\.[a-z]{2,}\S*?)\.?\s+(la connessione|connessione|connection|not secure)/i))) dest = m[1];
  if (!dest) return e;
  const host = dest.replace(/^[a-z]+:\/\//i, '').split(/[\/?#:]/)[0].replace(/^www\./, '');
  return Object.assign({}, e, { tipo: 'sito', cosa: host });
}
function tlFiltrati(ev, conCat){
  const w = tlFinestra();
  return (ev || TL.ev || []).filter(function(e){
    const fine = e.t + (e.durMs || 0);
    if (e.durMs > 0 ? (fine <= w.da || e.t >= w.a) : (e.t < w.da || e.t >= w.a)) return false;
    if (TL.app && e.pkg !== TL.app) return false;
    if (conCat !== false && TL.cat !== 'tutto' && tlCatDi(e) !== TL.cat) return false;
    return true;
  }).map(function(e){
    const s = Math.max(e.t, w.da), f = Math.min(e.t + (e.durMs || 0), w.a);
    return Object.assign({}, tlRicercaVera(e), { tIn: s, msIn: Math.max(0, f - s) });
  });
}
function tlSetFascia(k){ TL.fascia = k; TL.pag = 0; tlPaint(); }
function tlSetCat(k){ TL.cat = k; TL.pag = 0; tlPaint(); }
function tlSetApp(p){ TL.app = p || ''; TL.pag = 0; tlPaint(); }
function tlSetOre(quale, v){ if (/^\d{1,2}:\d{2}$/.test(v)){ TL[quale] = v; TL.pag = 0; tlPaint(); } }

/* ---------------------------------------------------------------------------------------
   LA PAGINA
   --------------------------------------------------------------------------------------- */
function tlOpen(off, da, scheda){
  TL.tab = scheda || (TL.tab === 'ricalcoli' ? 'riepilogo' : TL.tab);
  TL.off = Math.max(0, off || 0);
  TL.da = da || 'insights';
  TL.min = tlMin();
  TL.pag = 0; TL.app = ''; TL.cat = 'tutto'; TL.fascia = 'tutto';
  goId('s-timeline');
  tlCarica();
}

function tlIndietro(){
  try{ if (typeof switchTab === 'function') switchTab(TL.da || 'insights'); }catch(_){ }
  return 's-home';
}
function tlTornaIndietro(){
  if (typeof flIndietro === 'function') flIndietro();
  else goId(tlIndietro());
}
function tlSposta(n){
  const v = TL.off + n;
  if (v < 0 || v > 29) return;
  TL.off = v;
  TL.pag = 0; TL.app = '';
  tlCarica();
}

async function tlCarica(){
  const box = document.getElementById('tlBody');
  if (!box) return;
  const token = ++TL.token;

  box.innerHTML = tlTesta() + '<div class="tl-attesa">Sto rileggendo la giornata…</div>';

  const from = tlGiorno(TL.off);
  let d = null, r = null;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTimeline){
      const res = await Promise.all([
        NATIVE.getTimeline({ from: from, to: from + 86400000, minMs: TL.min, limit: 1800 }).catch(function(){ return null; }),
        tlRadioLeggi(from, from + 86400000)
      ]);
      d = res[0]; r = res[1];
    }
  }catch(_){ d = null; }
  if (token !== TL.token) return;

  if (d && d.grani) d.grani = tlSenzaLauncher(d.grani);
  TL.dati = d;
  TL.radio = r;
  TL.ev = (d && d.granted) ? tlEventiDa(d.grani || [], (r && r.eventi) || []) : [];
  if (TL.carbOff !== TL.off) TL.carb = null;
  if (d && (d.grani || []).length){
    const viste = {};
    for (const x of d.grani){
      if (viste[x.p]) continue;
      viste[x.p] = 1;
      if (Object.keys(viste).length > 24) break;
      await tlIcona(x.p);
    }
    if (token !== TL.token) return;
  }
  tlPaint();

  /* il carburante di oggi lo calcola il motore della dopamina: si aspetta lui, poi si ridisegna */
  if (TL.off === 0 && typeof dpCalcola === 'function'){
    try{
      const dd = await dpCalcola();
      if (token !== TL.token) return;
      if (dd && dd.ris && Array.isArray(dd.ris.voci)){
        TL.carb = dd.ris.voci.map(function(v){ return { t: v.t, delta: v.delta, l: v.l || '', nota: v.nota || '' }; });
        TL.carbOff = 0;
        tlPaint();
      }
    }catch(_){ }
  }
}

function tlTesta(){
  const puoAvanti = TL.off > 0;
  const puoIndietro = TL.off < 29;
  return '<div class="tlx-nav">'
    + '<button type="button" class="tlx-frec" ' + (puoIndietro ? '' : 'disabled ')
    +   'onclick="tlSposta(1)" aria-label="Giorno prima">' + tlSvg('sx', 18) + '</button>'
    + '<b>' + esc(tlNomeGiorno(TL.off)) + '</b>'
    + '<button type="button" class="tlx-frec" ' + (puoAvanti ? '' : 'disabled ')
    +   'onclick="tlSposta(-1)" aria-label="Giorno dopo">' + tlSvg('dx', 18) + '</button>'
    + '</div>';
}

const TL_SVG = {
  sx: '<path d="M15 5l-7 7 7 7"/>',
  dx: '<path d="M9 5l7 7-7 7"/>',
  indietro: '<path d="M15 5l-7 7 7 7"/>',
  dots: '<circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.6" fill="currentColor" stroke="none"/>',
  share: '<path d="M12 15V4"/><path d="M7.5 8.5L12 4l4.5 4.5"/><path d="M5 13v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  lucchetto: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  carb: '<path d="M5 20V6a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v14"/><path d="M4 20h12"/><path d="M8 8h4"/><path d="M15 9l3 2v6a1.5 1.5 0 0 0 3 0V9l-3-3"/>'
};
function tlSvg(k, px){
  return '<svg viewBox="0 0 24 24" width="' + (px || 20) + '" height="' + (px || 20) + '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (TL_SVG[k] || '') + '</svg>';
}

/* ---------------------------------------------------------------------------------------
   IL REPORT (0.9.304): lo stesso pannello delle statistiche della partita (partita-stats.js,
   classi pst, pst-kick, pst-tabs, pst-tab, pst-corpo), una cosa per scheda. I filtri non si
   vedono finche' non servono: stanno dietro ai tre puntini del pannello.
   --------------------------------------------------------------------------------------- */
/* 0.9.353, Andrea: "via la scheda Chiedi al tuo agente personale: alla fine della fila un + come nelle statistiche della partita,
   dove l'utente crea una scheda sua". Ogni scheda ha la sua emoji: si vede solo su quella attiva, nel pallino bianco. */
const TL_SCHEDE = [
  ['riepilogo', 'Riepilogo', '📋'],
  ['decisioni', 'Decisioni', '⚡'],
  ['ricalcoli', 'Ricalcoli', '🧭'],
  ['ai', 'Le tue AI', '🤖'],
  ['ore', 'Ore del giorno', '⏰'],
  ['app', 'App', '📱'],
  ['ricerche', 'Ricerche', '🔎'],
  ['carb', 'Carburante', '⛽']
];
const TL_PIU_SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
/** Tutte le schede della fila: quelle di serie, quelle fatte dalla persona, poi "+". */
function tlSchedeTutte(){
  const l = TL_SCHEDE.map(function(s){ return { id: s[0], t: s[1], em: s[2] }; });
  tlMie().forEach(function(c){ l.push({ id: c.id, t: c.titolo, em: c.em || '⭐', mia: true }); });
  l.push({ id: 'piu', t: 'Una scheda tutta tua', piu: true });
  return l;
}
const TL_ICO = {
  app: '<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',
  ora: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  cosa: '<path d="M4 6h16M7 12h10M10 18h4"/>',
  giorno: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  lente: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
  nodi: '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="8" r="2.5"/><circle cx="9" cy="18" r="2.5"/><path d="M8.3 7.2l7.4 0.6M16.6 10.1l-6.2 5.8M6.6 8.4l1.8 7.2"/>',
  cursori: '<path d="M5 7h9M18 7h1M5 17h3M12 17h7"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  chat: '<path d="M5 18l-1.5 3 4-1.6A8.5 8.5 0 1 0 5 18z"/>',
  spunta: '<path d="M5 12.5l4.5 4.5L19 7.5"/>'
};
function tlIco(k, px){
  return '<svg viewBox="0 0 24 24" width="' + (px || 18) + '" height="' + (px || 18) + '" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (TL_ICO[k] || TL_SVG[k] || '') + '</svg>';
}
function tlTab(k){
  if (k !== 'piu'){ TL.esito = ''; if (TL.mod){ TL.mod = ''; TL.bozza = ''; } }
  TL.tab = k; tlPaint();
  if (k === 'ai' && typeof pntSync === 'function') pntSync(true).then(function(){ if (TL.tab === 'ai') tlPaint(); });
}

/** I nomi dei filtri accesi, per le pillole sotto al titolo e per la richiesta all'agente. */
function tlFasciaBreve(){
  const f = TL_FASCE.filter(function(x){ return x[0] === TL.fascia; })[0] || TL_FASCE[0];
  if (f[0] === 'mia') return 'Dalle ' + TL.fDa + ' alle ' + TL.fA;
  return f[1] + ', dalle ' + f[2] + ' alle ' + f[3];
}
function tlCatNome(){ return (TL_CAT.filter(function(c){ return c[0] === TL.cat; })[0] || TL_CAT[0])[1]; }
function tlFiltriAccesi(){ return (TL.app ? 1 : 0) + (TL.fascia !== 'tutto' ? 1 : 0) + (TL.cat !== 'tutto' ? 1 : 0); }
function tlPilloleHtml(){
  const p = [];
  const pill = function(testo, via, nome){
    return '<button type="button" class="tls-pill" onclick="' + via + '" aria-label="Togli il filtro ' + esc(nome) + '"><span>' + esc(testo) + '</span>' + tlSvg('x', 13) + '</button>';
  };
  if (TL.app) p.push(pill(tlNomeApp(TL.app), 'tlSetApp(\'\')', tlNomeApp(TL.app)));
  if (TL.fascia !== 'tutto') p.push(pill(tlFasciaBreve(), 'tlSetFascia(\'tutto\')', 'delle ore'));
  if (TL.cat !== 'tutto') p.push(pill(tlCatNome(), 'tlSetCat(\'tutto\')', tlCatNome()));
  return p.length ? '<div class="tls-pills">' + p.join('') + '</div>' : '';
}

/** Le app della fascia scelta, dalla piu' usata. */
function tlAppDellaFascia(){
  const app = {};
  tlFiltrati(TL.ev, false).forEach(function(e){ if (!app[e.pkg]) app[e.pkg] = { p: e.pkg, l: e.app, ms: 0 }; app[e.pkg].ms += e.msIn; });
  return Object.keys(app).map(function(k){ return app[k]; }).sort(function(a, b){ return b.ms - a.ms; });
}

/* DECISIONI (0.9.350), Andrea: "decisioni vuol dire tutto e niente: devo poter vedere quali ho preso e a che ora, in una pagina con un
   bel design riassuntivo, una scheda nella Timeline". Il numero del giorno, la serie, i sette giorni in barre, poi la linea delle decisioni */
function tlSchedaDecisioni(){
  if (typeof cloDecisioniLista !== 'function') return '<p class="pst-nota">Le decisioni non si leggono adesso.</p>';
  const g0 = tlGiorno(TL.off), l = cloDecisioniLista(g0), oggi = TL.off === 0;
  const st = (typeof cloDecStoria === 'function') ? cloDecStoria() : {};
  const k = function(t){ return (typeof cloDecKey === 'function') ? cloDecKey(t) : ''; };
  const n = oggi && typeof cloDecisioniOggi === 'function' ? cloDecisioniOggi() : Math.max(l.length, +st[k(g0)] || 0);
  const serie = (typeof cloDecSerie === 'function') ? cloDecSerie() : 0;
  const G = ['D', 'L', 'M', 'M', 'G', 'V', 'S'];
  const sett = []; for (let i = 6; i >= 0; i--){ const t = g0 - i * 86400000; sett.push({ n: +st[k(t)] || 0, g: G[new Date(t).getDay()], qui: i === 0 }); }
  const max = Math.max(1, Math.max.apply(null, sett.map(function(x){ return x.n; })));
  const ora = function(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  return '<div class="tld-testa"><b>' + n + '</b><span>' + (n === 1 ? 'decisione' : 'decisioni') + (oggi ? ' oggi' : ' in questo giorno') + '</span>'
      + (serie ? '<em>⚡ ' + serie + (serie === 1 ? ' giorno di fila con decisioni' : ' giorni di fila con decisioni') + '</em>' : '') + '</div>'
    + '<div class="tld-sett">' + sett.map(function(x){ return '<div class="' + (x.qui ? 'qui' : '') + '"><i style="height:' + Math.max(6, Math.round(x.n / max * 64)) + 'px"></i><small>' + x.n + '</small><span>' + x.g + '</span></div>'; }).join('') + '</div>'
    /* 0.9.351, Andrea: "non dice quanto ci metto a scrivere alla mia AI, ne' il tempo medio per ogni decisione" */
    + (function(){ const ai = (typeof cloAiMedia === 'function') ? cloAiMedia() : null; const tt = l.map(function(x){ return x.at; }).filter(Boolean).sort(function(a, b){ return a - b; }); const tra = tt.length > 1 ? (tt[tt.length - 1] - tt[0]) / (tt.length - 1) / 1000 : null;
        const d = (typeof dcsDurata === 'function') ? dcsDurata : function(x){ return Math.round(x) + ' s'; };
        return '<div class="tld-ins"><div><span>💬</span><b>' + (ai ? d(ai) : 'Non ancora misurato') + '</b><small>per scrivere alla tua AI</small></div><div><span>⏱️</span><b>' + (tra !== null ? d(tra) : 'Servono due decisioni') + '</b><small>fra una decisione e l’altra</small></div></div>'; })()
    + '<button type="button" class="pst-link" onclick="if(typeof dcsApri===\'function\')dcsApri(' + TL.off + ')">Apri la pagina delle decisioni</button>'
    + (l.length ? '<div class="tld-l">' + l.map(function(x){ return '<div class="tld-r"><span class="tld-o">' + (x.at ? ora(x.at) : 'in giornata') + '</span><span class="tld-i" aria-hidden="true">' + x.ico + '</span><p>' + esc(x.t) + '</p></div>'; }).join('') + '</div>'
      : '<p class="pst-nota">' + (oggi ? 'Oggi nessuna decisione ancora: una sessione di Full Focus o una tappa della mappa sono la prima.' : 'In questo giorno non risultano decisioni.') + '</p>');
}
(function(){ const s = document.createElement('style'); s.textContent = '.tld-testa{display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center}.tld-testa b{font:900 48px/1 var(--font-display);color:#fff}.tld-testa span{font:700 14px var(--font-body);color:#C8EFFD}.tld-testa em{margin-top:10px;padding:6px 12px;border-radius:99px;background:rgba(230,57,70,.2);color:#FFB3BA;font:800 12.5px var(--font-body);font-style:normal}'
  + '.tld-sett{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;align-items:end;height:112px;padding:0 4px}.tld-sett > div{display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;height:100%}.tld-sett i{display:block;width:16px;border-radius:6px;background:rgba(140,198,255,.35)}.tld-sett .qui i{background:linear-gradient(180deg,#3F9FF4,#0075E3)}.tld-sett small{font:800 11px var(--font-body);color:#fff}.tld-sett span{font:700 11px var(--font-body);color:rgba(255,255,255,.55)}'
  + '.tld-ins{display:grid;grid-template-columns:1fr 1fr;gap:10px}.tld-ins > div{display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 10px;border-radius:16px;background:rgba(255,255,255,.07);text-align:center}.tld-ins span{font-size:22px}.tld-ins b{font:800 15px var(--font-display);color:#fff}.tld-ins small{font:600 12px/1.35 var(--font-body);color:#C8EFFD}'
  + '.tld-l{position:relative;display:flex;flex-direction:column;gap:12px;padding-left:4px}.tld-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.07)}.tld-o{flex:none;min-width:52px;padding:4px 8px;border-radius:99px;background:#0075E3;color:#fff;font:800 12px var(--font-body);text-align:center}.tld-i{flex:none;font-size:20px}.tld-r p{margin:0;font:600 14px/1.4 var(--font-body);color:#fff}';
  document.head.appendChild(s); })();
/* RIEPILOGO: il Genio, tre cose al massimo, ognuna con la sua emoji.
   0.9.353, Andrea: "Il Genio ha notato e' troppo grande e attaccato al titolo: e' un occhiello. La priorita' va alle cose notate".
   Occhiello piccolo e smorzato con il Genio in piccolo, poi le frasi grandi. In fondo un pulsante solo: chi e' gratis legge il Genio
   ("Il tuo sogno"), chi ha Premium sceglie cosa chiedere al suo agente personale (tlAlGenio). */
function tlSchedaRiepilogo(){
  const prem = tlPremium(), r = tlRiassunto(TL.dati);
  const frasi = prem ? tlFrasiPremium(r, TL.off) : tlFrasi(r, TL.off);
  const testa = '<div class="tls-genio"><img src="img/genio/genio-pensa.png" alt=""><span>Il Genio ha notato</span></div>';
  const cta = '<button type="button" class="pst-link tls-cta" onclick="tlAlGenio()">' + tlIco('chat', 16) + '<span>' + (prem ? 'Chiedi al tuo agente personale' : 'Chiedi al Genio cosa fare') + '</span></button>';
  if (!frasi.length){
    return testa + '<p class="pst-nota tls-nulla">Su questa giornata il Genio non ha ancora abbastanza da dirti. Torna quando avrai usato il telefono un po\' di più.</p>' + (prem ? cta : '');
  }
  return testa
    + '<ul class="tls-punti">' + frasi.map(function(f){ return '<li><span class="tls-em">' + f.ico + '</span><span>' + f.html + '</span></li>'; }).join('') + '</ul>'
    + cta;
}

/* ORE DEL GIORNO: quanto, e in quali ore. opz (0.9.353, per le schede tue): w = la finestra da mostrare, senzaBig = solo le barre */
function tlSchedaOre(ev, opz){
  opz = opz || {};
  const tot = ev.reduce(function(s, e){ return s + e.msIn; }, 0);
  const ap = {};
  ev.forEach(function(e){ if (e.g >= 0) ap[e.g] = 1; });
  const nAp = Object.keys(ap).length;
  const big = '<div class="tls-big"><b>' + (tot ? tlDur(tot) : '0 minuti') + '</b>'
    + '<small>' + (nAp ? 'sul telefono in ' + nAp + (nAp === 1 ? ' apertura' : ' aperture') + ', ' + esc(tlFasciaNome()) : 'In questa scelta non hai aperto nessuna app.') + '</small></div>';
  if (!tot) return opz.senzaBig ? '' : big;
  /* ogni pezzo di tempo diviso fra le ore in cui e' caduto davvero */
  const perOra = new Array(24).fill(0);
  ev.forEach(function(e){
    let t = e.tIn; const fine = e.tIn + e.msIn;
    while (t < fine){
      const d = new Date(t); const h = d.getHours();
      const prossima = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h + 1).getTime();
      const pezzo = Math.min(fine, prossima) - t;
      perOra[h] += pezzo; t += pezzo;
    }
  });
  const fasce = [[0, 6], [6, 9], [9, 12], [12, 15], [15, 18], [18, 21], [21, 24]].map(function(f){
    let ms = 0; for (let h = f[0]; h < f[1]; h++) ms += perOra[h];
    return { a: f[0], b: f[1], ms: ms };
  });
  const w = opz.w || tlFinestra(), g0 = tlGiorno(TL.off);
  const viste = fasce.filter(function(f){ return g0 + f.b * 3600000 > w.da && g0 + f.a * 3600000 < w.a; });
  const max = Math.max.apply(null, viste.map(function(f){ return f.ms; }).concat([1]));
  return (opz.senzaBig ? '' : big) + '<div class="tls-ore">' + viste.map(function(f){
    const pct = f.ms ? Math.max(3, Math.round(f.ms / max * 100)) : 0;
    return '<div class="tls-or' + (f.ms === max && f.ms ? ' top' : '') + (f.ms ? '' : ' muta') + '"><span>' + f.a + '-' + f.b + '</span>'
      + '<i class="tls-bar"><i style="width:' + pct + '%"></i></i><b>' + (f.ms ? tlDur(f.ms) : '-') + '</b></div>';
  }).join('') + '</div>'
    + '<p class="pst-nota">Le ore sono quelle del giorno. La fascia più lunga è in rosso.</p>';
}

/* APP: dove e' andato il tempo */
function tlSchedaApp(ev){
  const per = {};
  ev.forEach(function(e){ if (!per[e.pkg]) per[e.pkg] = { p: e.pkg, l: e.app, ms: 0, n: {} }; per[e.pkg].ms += e.msIn; if (e.g >= 0) per[e.pkg].n[e.g] = 1; });
  const top = Object.keys(per).map(function(k){ return per[k]; }).sort(function(a, b){ return b.ms - a.ms; }).slice(0, 6);
  if (!top.length) return '<p class="pst-nota">In questa scelta non hai aperto nessuna app.</p>';
  return '<div class="tls-lista">' + top.map(function(a){
    const pct = Math.max(3, Math.round(a.ms / Math.max(1, top[0].ms) * 100));
    const n = Object.keys(a.n).length;
    return '<div class="tls-app">' + tlIconaTag(a.p, 36, null, a.l)
      + '<div class="tls-app-t"><b>' + esc(a.l || a.p) + '</b><small>' + (n ? 'Aperta ' + n + (n === 1 ? ' volta' : ' volte') : 'Vista di passaggio') + '</small>'
      + '<i class="tls-bar"><i style="width:' + pct + '%"></i></i></div>'
      + '<b class="tls-val">' + tlDur(a.ms) + '</b></div>';
  }).join('') + '</div>';
}

/* RICERCHE: le cose scritte, non solo le app */
function tlCercate(ev){
  const visti = {}, cercate = [];
  ev.slice().reverse().forEach(function(e){
    if (!e.cosa || (e.tipo !== 'ricerca' && e.tipo !== 'ai')) return;
    const k = e.cosa.toLowerCase(); if (visti[k]) return; visti[k] = 1; cercate.push(e);
  });
  return cercate;
}
function tlCercateHtml(cercate, max){
  return '<div class="tls-lista">' + cercate.slice(0, max).map(function(e){
    return '<div class="tls-cosa"><span class="tls-em">' + (e.tipo === 'ai' ? '✨' : '🔎') + '</span>'
      + '<div><b>"' + esc(e.cosa) + '"</b><small>' + (e.tipo === 'ai' ? 'Chiesto a ' : 'Cercato su ') + esc(e.app) + ' alle ' + tlOra(e.t) + '</small></div></div>';
  }).join('') + '</div>';
}
function tlSchedaRicerche(ev){
  const cercate = tlCercate(ev);
  if (!cercate.length){
    const spenta = TL.radio && (TL.radio.on === false || TL.radio.accessibilita === false);
    return '<p class="pst-nota">' + (spenta ? 'Le ricerche si vedono quando è acceso "Registra cosa fai dentro le app".' : 'In questa scelta non hai cercato niente e non hai fatto domande.') + '</p>';
  }
  /* 0.9.353, Andrea: "in fondo c'e' solo un riassunto delle ultime: voglio vederle tutte, ora per ora" (tlRicercheApri) */
  return '<p class="tls-tit">Le cose che hai cercato o chiesto</p>' + tlCercateHtml(cercate, 6)
    + '<button type="button" class="tls-tutte" onclick="tlRicercheApri()">Vedi tutte le ricerche</button>';
}

/* ---------------------------------------------------------------------------------------
   TUTTE LE RICERCHE DEL GIORNO (0.9.353): una pagina, ora per ora, con la grafica dei momenti della
   giornata (la linea a sinistra con i punti blu, l'ora, la frase e la scheda). Tutto il giorno, senza i
   filtri del report: e' la pagina "tutte". Indietro torna alla Timeline (flIndietro).
   --------------------------------------------------------------------------------------- */
function tlRicercheDelGiorno(){
  const out = [];
  (TL.ev || []).forEach(function(e0){
    const e = tlRicercaVera(e0);
    if (!e || !e.cosa || (e.tipo !== 'ricerca' && e.tipo !== 'ai')) return;
    const u = out[out.length - 1];
    /* la stessa ricerca ripresa nella stessa app un attimo dopo e' una ricerca sola */
    if (u && u.pkg === e.pkg && u.cosa.toLowerCase() === e.cosa.toLowerCase() && e.t - (u.t + (u.durMs || 0)) < 120000){ u.durMs = (e.t + (e.durMs || 0)) - u.t; return; }
    out.push(Object.assign({}, e));
  });
  return out.sort(function(a, b){ return a.t - b.t; });
}
function tlRicercheApri(){
  goId('s-tl-ricerche');
  tlRicerchePaint();
  try{ const s = document.getElementById('s-tl-ricerche'); if (s) s.scrollTop = 0; }catch(_){ }
}
function tlRicerchePaint(){
  const box = document.getElementById('tlqBody'); if (!box) return;
  const l = tlRicercheDelGiorno();
  const g = tlNomeGiorno(TL.off), giorno = g.charAt(0).toUpperCase() + g.slice(1);
  if (!l.length){
    box.innerHTML = tlVuoto('🔎', giorno + ' non hai cercato niente', 'Le ricerche su Google e le domande alle intelligenze artificiali compaiono qui, ora per ora.');
    return;
  }
  const nR = l.filter(function(e){ return e.tipo === 'ricerca'; }).length, nA = l.length - nR;
  const conto = [];
  if (nR) conto.push('hai cercato ' + (nR === 1 ? 'una cosa' : nR + ' cose'));
  if (nA) conto.push('hai fatto ' + (nA === 1 ? 'una domanda' : nA + ' domande') + ' alle intelligenze artificiali');
  const ore = {};
  l.forEach(function(e){ const h = new Date(e.t).getHours(); (ore[h] = ore[h] || []).push(e); });
  box.innerHTML = '<p class="tlq-sotto">' + esc(giorno + ' ' + conto.join(' e ')) + '.</p>'
    + Object.keys(ore).map(Number).sort(function(a, b){ return a - b; }).map(function(h){
        return '<section class="tlq-ora"><h4 class="tlq-h">Dalle ' + h + ' alle ' + (h + 1) + '</h4><div class="tlm-lista">'
          + ore[h].map(function(e){
              return '<div class="tlm"><i class="tlm-punto"></i>'
                + '<p class="tlm-ora">' + tlOra(e.t) + '</p>'
                + '<p class="tlm-frase">' + (e.tipo === 'ai' ? 'Hai chiesto a ' : 'Hai cercato su ') + esc(e.app) + '</p>'
                + '<div class="tlm-card"><span class="tlm-img tlm-app">' + tlIconaTag(e.pkg, 52, null, e.app) + '</span>'
                +   '<div class="tlm-t"><b>"' + esc(e.cosa) + '"</b></div>'
                +   (e.durMs >= 10000 ? '<b class="tlm-val">' + tlDur(e.durMs) + '</b>' : '')
                + '</div></div>';
            }).join('') + '</div></section>';
      }).join('');
}
registerScreen('s-tl-ricerche',
  '<div class="topbar">'
  + '<button class="iconbtn" onclick="tlTornaIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/></svg></button>'
  + '<b class="blk-title">Le tue ricerche</b>'
  + '</div>'
  + '<div id="tlqBody"></div><div class="spacer"></div>', { back: 's-timeline' });

/* CARBURANTE: quanto ne hai guadagnato e perso, e il Full Focus che l'ha mosso */
function tlSchedaCarb(){
  const w = tlFinestra();
  const voci = tlCarburante(w.da, w.a);
  const c = tlCarbConto(voci);
  const ff = tlVita(w.da, w.a).filter(function(v){ return v.k === 'albero'; });
  const ffOk = ff.filter(function(v){ return v.ok; }).length;
  const ffMin = ff.reduce(function(s, v){ return s + Math.round((v.spentMs || 0) / 60000); }, 0);
  let html = '<div class="tls-due">'
    + '<div class="su"><b>+' + tlNum(c.su) + '</b><small>carburante guadagnato</small></div>'
    + '<div class="giu"><b>' + (c.giu >= 0.05 ? '−' : '') + tlNum(c.giu) + '</b><small>carburante perso</small></div></div>';
  const forti = voci.slice().sort(function(a, b){ return Math.abs(b.delta) - Math.abs(a.delta); }).filter(function(v){ return Math.abs(v.delta) >= 0.5; }).slice(0, 4);
  if (forti.length){
    html += '<div class="tls-lista">' + forti.map(function(v){
      return '<div class="tls-voce"><div><b>' + esc(v.l || 'Carburante') + '</b><small>Alle ' + tlOra(v.t) + '</small></div>'
        + '<b class="tls-val ' + (v.delta > 0 ? 'su' : 'giu') + '">' + (v.delta > 0 ? '+' : '−') + tlNum(v.delta) + '</b></div>';
    }).join('') + '</div>';
  } else if (c.su < 0.05 && c.giu < 0.05){
    html += '<p class="pst-nota">In questa scelta il carburante non si è mosso.</p>';
  }
  if (ff.length){
    const fatte = ff.length + (ff.length === 1 ? ' sessione' : ' sessioni') + ' di Full Focus';
    const finite = ffOk === 0 ? 'non ne hai completata nessuna' : (ffOk === 1 ? 'ne hai completata una' : 'ne hai completate ' + ffOk);
    html += '<div class="tls-ff"><span class="tls-em">🌳</span><span>' + (ffOk === ff.length
      ? 'Hai completato ' + fatte + ', ' + ffMin + ' minuti in tutto.'
      : 'Hai fatto ' + fatte + ' e ' + finite + ': ' + ffMin + ' minuti in tutto.') + '</span></div>';
  }
  return html;
}

/* ---------------------------------------------------------------------------------------
   LE SCHEDE TUE E "+" (0.9.353): lo stesso meccanismo delle statistiche della partita (partita-stats.js, scheda
   "+": "Una statistica tutta tua"). La persona scrive cosa vuole tenere d'occhio ("Instagram dopo le 22", "le
   ricerche della mattina"); la frase diventa un filtro fisso (app, attivita', ore) che si legge qui, senza modello.
   fl_tl_schede = [{ id, titolo, em, app, appNome, cat, dalle, alle, richiesta, at }]
   --------------------------------------------------------------------------------------- */
const TL_MIE_K = 'fl_tl_schede';
function tlMie(){ const l = tlLs(TL_MIE_K, []); return Array.isArray(l) ? l.filter(function(c){ return c && c.id && c.titolo; }) : []; }
function tlScriviMie(l){ try{ localStorage.setItem(TL_MIE_K, JSON.stringify(l.slice(-8))); return true; }catch(_){ return false; } }
function tlOrari(t){
  let m;
  if ((m = t.match(/dall[ea']?\s*(\d{1,2})(?:[:.]\d{2})?\s+all[ea']?\s*(\d{1,2})/))) return { dalle: +m[1], alle: +m[2] };
  if ((m = t.match(/(?:tra|fra)\s+le\s+(\d{1,2})\s+e\s+le\s+(\d{1,2})/))) return { dalle: +m[1], alle: +m[2] };
  if ((m = t.match(/dopo\s+(?:le\s+|l'\s*|la\s+)?(\d{1,2})/))) return { dalle: +m[1], alle: 24 };
  if ((m = t.match(/prima\s+(?:delle\s+|dell'\s*|di\s+)?(\d{1,2})/))) return { dalle: 0, alle: +m[1] };
  if (/di notte|la notte|notturn|a letto/.test(t)) return { dalle: 23, alle: 6 };
  if (/la sera|di sera|serale|stasera/.test(t)) return { dalle: 18, alle: 24 };
  if (/mattin/.test(t)) return { dalle: 6, alle: 12 };
  if (/pomerigg/.test(t)) return { dalle: 12, alle: 18 };
  return {};
}
function tlOrariTxt(c){
  if (c.dalle == null && c.alle == null) return '';
  const a = c.dalle == null ? 0 : c.dalle, b = c.alle == null ? 24 : c.alle;
  if (a > 0 && b >= 24) return 'dopo le ' + a;
  if (a === 0 && b < 24) return 'prima delle ' + b;
  return 'dalle ' + a + ' alle ' + b;
}
const TL_MIE_CAT = [['ricerche', /ricerc|\bcerc|cosa cerco/], ['ai', /\bai\b|\bia\b|intelligenz|domand|chatgpt|gemini|claude/], ['social', /social|reel|storie|\bfeed/],
  ['video', /video|film|serie tv/], ['siti', /\bsit[oi]\b|pagine web|internet/], ['messaggi', /messagg|\bchat\b/], ['giochi', /\bgioc|\bgame/], ['dreammap', /dreammap/]];
const TL_MIE_APP = [['instagram', 'Instagram', 'social'], ['tiktok', 'TikTok', 'social'], ['tik tok', 'TikTok', 'social'], ['youtube', 'YouTube', 'video'], ['facebook', 'Facebook', 'social'],
  ['whatsapp', 'WhatsApp', 'messaggi'], ['telegram', 'Telegram', 'messaggi'], ['reddit', 'Reddit', 'social'], ['twitter', 'X', 'social'], ['netflix', 'Netflix', 'video'],
  ['twitch', 'Twitch', 'video'], ['snapchat', 'Snapchat', 'social'], ['pinterest', 'Pinterest', 'social'], ['threads', 'Threads', 'social'], ['linkedin', 'LinkedIn', 'social'],
  ['spotify', 'Spotify', ''], ['amazon', 'Amazon', ''], ['discord', 'Discord', 'messaggi'], ['gmail', 'Gmail', 'messaggi'], ['chrome', 'Chrome', 'siti'],
  ['chatgpt', 'ChatGPT', 'ai'], ['gemini', 'Gemini', 'ai'], ['google', 'Google', 'ricerche']];
/** La frase della persona come filtro: app, attivita', ore. null se non c'e' niente che la Timeline sappia leggere. */
function tlMiaCapisci(testo){
  let t = ' ' + String(testo || '').toLowerCase().replace(/[’]/g, '\'') + ' ';
  /* l'app: prima quelle viste in questo giorno (con il nome vero), poi quelle che si riconoscono per nome */
  const viste = {}; (TL.ev || []).forEach(function(e){ if (e.pkg && e.app && e.pkg !== TL_DM) viste[String(e.app).toLowerCase()] = { p: e.pkg, n: e.app }; });
  let app = null;
  Object.keys(viste).sort(function(a, b){ return b.length - a.length; }).some(function(n){ if (n.length >= 3 && t.indexOf(n) >= 0){ app = viste[n]; return true; } return false; });
  if (!app) TL_MIE_APP.some(function(a){ if (t.indexOf(a[0]) >= 0){ app = { p: '', n: a[1], c: a[2] }; return true; } return false; });
  if (app && !app.c){ const n0 = String(app.n).toLowerCase(); TL_MIE_APP.some(function(a){ if (a[0] === n0){ app.c = a[2]; return true; } return false; }); }
  if (app) t = t.split(app.n.toLowerCase()).join(' ');
  let cat = 'tutto';
  TL_MIE_CAT.some(function(c){ if (c[1].test(t)){ cat = c[0]; return true; } return false; });
  const or = tlOrari(t);
  if (!app && cat === 'tutto' && or.dalle == null) return null;
  const c = { app: app ? app.p : '', appNome: app ? app.n : '', cat: cat };
  if (or.dalle != null){ c.dalle = Math.max(0, Math.min(24, or.dalle)); c.alle = Math.max(0, Math.min(24, or.alle)); }
  const catNome = (TL_CAT.filter(function(x){ return x[0] === cat; })[0] || TL_CAT[0])[1];
  const ore = tlOrariTxt(c);
  let titolo = app ? app.n + (cat !== 'tutto' ? ', ' + catNome.toLowerCase() : '') : (cat !== 'tutto' ? catNome : 'Il telefono');
  if (ore) titolo += ' ' + ore;
  const s = String(testo || '').trim();
  c.titolo = (s.length <= 28 ? s.charAt(0).toUpperCase() + s.slice(1) : titolo).replace(/[«»“”]/g, '"').slice(0, 28);
  const catApp = app ? (app.c || (app.p ? tlCatDi({ pkg: app.p, tipo: 'app' }) : '')) : '';
  c.em = (TL_CAT.filter(function(x){ return x[0] === (cat !== 'tutto' ? cat : catApp); })[0] || [0, 0, '⭐'])[2];
  if (c.em === '🧭' || c.em === '📱') c.em = '⭐';
  return c;
}
/** Gli eventi del giorno che rientrano in una scheda tua, tagliati alle sue ore (anche a cavallo della mezzanotte). */
function tlMiaEventi(c){
  const g0 = tlGiorno(TL.off), H = 3600000;
  const a = c.dalle == null ? 0 : c.dalle, b = c.alle == null ? 24 : c.alle;
  const pezzi = b > a ? [[g0 + a * H, g0 + b * H]] : [[g0, g0 + b * H], [g0 + a * H, g0 + 24 * H]];
  const nome = String(c.appNome || '').toLowerCase();
  const out = [];
  (TL.ev || []).forEach(function(e0){
    const e = tlRicercaVera(e0);
    if (c.app ? e.pkg !== c.app : (nome && String(e.app || '').toLowerCase().indexOf(nome) < 0 && String(e.pkg || '').toLowerCase().indexOf(nome.replace(/\s+/g, '')) < 0)) return;
    if (c.cat && c.cat !== 'tutto' && tlCatDi(e) !== c.cat) return;
    pezzi.forEach(function(w){
      const fine = e.t + (e.durMs || 0);
      if (e.durMs > 0 ? (fine <= w[0] || e.t >= w[1]) : (e.t < w[0] || e.t >= w[1])) return;
      const s = Math.max(e.t, w[0]), f = Math.min(fine, w[1]);
      out.push(Object.assign({}, e, { tIn: s, msIn: Math.max(0, f - s) }));
    });
  });
  return out.sort(function(x, y){ return x.tIn - y.tIn; });
}
function tlSchedaMia(c){
  const ev = tlMiaEventi(c);
  const tot = ev.reduce(function(s, e){ return s + e.msIn; }, 0);
  const ap = {}; ev.forEach(function(e){ if (e.g >= 0) ap[e.g] = 1; });
  const nAp = Object.keys(ap).length;
  const ore = tlOrariTxt(c), dove = c.appNome ? 'su ' + c.appNome : 'sul telefono';
  const cerca = c.cat === 'ricerche' || c.cat === 'ai';
  const cercate = cerca ? tlCercate(ev) : [];
  let h;
  if (cerca){
    h = '<div class="tls-big"><b>' + cercate.length + '</b><small>' + (cercate.length === 1 ? (c.cat === 'ai' ? 'domanda' : 'ricerca') : (c.cat === 'ai' ? 'domande' : 'ricerche')) + (ore ? ' ' + esc(ore) : '') + '</small></div>'
      + (cercate.length ? tlCercateHtml(cercate, 6) : '');
  } else {
    h = '<div class="tls-big"><b>' + (tot ? tlDur(tot) : '0 minuti') + '</b>'
      + '<small>' + (nAp ? esc(dove) + ' in ' + nAp + (nAp === 1 ? ' apertura' : ' aperture') + (ore ? ', ' + esc(ore) : '') : 'In questo giorno non c’è niente che rientra in questa scheda.') + '</small></div>';
    /* con un'app: le sue ore (solo le fasce della scheda); senza: le app che ci rientrano */
    const g0 = tlGiorno(TL.off), a = c.dalle == null ? 0 : c.dalle, b = c.alle == null ? 24 : c.alle;
    const w = b > a ? { da: g0 + a * 3600000, a: g0 + b * 3600000 } : { da: g0, a: g0 + 86400000 };
    if (tot) h += c.appNome ? tlSchedaOre(ev, { w: w, senzaBig: true }) : tlSchedaApp(ev);
  }
  return h + '<p class="pst-nota">Hai chiesto "' + esc(c.richiesta || c.titolo) + '".</p>'
    + '<div class="pst-azioni"><button type="button" onclick="tlMiaCambia(\'' + c.id + '\')">Cambia</button><button type="button" class="via" onclick="tlMiaElimina(\'' + c.id + '\')">Elimina</button></div>';
}
/* "+": la persona scrive cosa vuole tenere d'occhio e nasce la scheda */
function tlPiuHtml(){
  const esempi = ['YouTube dopo le 22', 'Le ricerche della mattina'];
  return '<div class="pst-piu tl-piu">'
    + '<h3>' + (TL.mod ? 'Cambia la scheda' : 'Una scheda tutta tua') + '</h3>'
    + '<p>Scrivi quale app, quali ore o quale attività vuoi tenere d’occhio.</p>'
    + '<textarea id="tlCampo" rows="2" maxlength="120" placeholder="Instagram dopo le 22" oninput="TL.bozza=this.value">' + esc(TL.bozza || '') + '</textarea>'
    + '<button type="button" class="pst-cta" onclick="tlMiaCrea()">' + (TL.mod ? 'Aggiorna la scheda' : 'Crea la scheda') + '</button>'
    + (TL.esito ? '<div class="pst-esito"><p>' + esc(TL.esito) + '</p></div>'
                : '<div class="pst-esempi">' + esempi.map(function(t){ return '<button type="button" onclick="tlMiaEsempio(\'' + t + '\')">' + esc(t) + '</button>'; }).join('') + '</div>')
    /* chi ha Premium puo' chiederlo anche al suo agente personale, con i dati del giorno (il messaggio resta nel campo) */
    + (tlPremium() ? '<button type="button" class="pst-link" onclick="tlAgente(\'filtro\')">' + tlIco('chat', 16) + '<span>Chiedilo al tuo agente personale</span></button>' : '')
    + (TL.mod ? '<button type="button" class="pst-link muto" onclick="tlMiaAnnulla()">Lascia la scheda com’era</button>' : '')
    + '</div>';
}
function tlMiaEsempio(t){ TL.bozza = t; TL.esito = ''; tlPaint(); const c = document.getElementById('tlCampo'); if (c) c.focus(); }
function tlMiaCrea(){
  const f = document.getElementById('tlCampo');
  const t = String((f && f.value) || TL.bozza || '').trim();
  if (t.length < 3){ if (typeof toast === 'function') toast('Scrivi cosa vuoi tenere d’occhio'); if (f) f.focus(); return; }
  TL.bozza = t;
  const c = tlMiaCapisci(t);
  if (!c){ TL.esito = 'La Timeline non vede questa cosa. Prova con un’app, delle ore o un’attività, come "YouTube dopo le 22".'; tlPaint(); return; }
  c.richiesta = t.slice(0, 120); c.at = Date.now();
  const l = tlMie(), era = !!TL.mod;
  const i = era ? l.findIndex(function(x){ return x.id === TL.mod; }) : -1;
  if (i >= 0){ c.id = l[i].id; l[i] = c; }
  else { c.id = 'm' + Date.now().toString(36); l.push(c); }
  if (!tlScriviMie(l)){ if (typeof toast === 'function') toast('La memoria del telefono è piena e la scheda non si salva'); return; }
  TL.tab = c.id; TL.bozza = ''; TL.esito = ''; TL.mod = '';
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  tlPaint();
  if (typeof toast === 'function') toast(era ? 'Hai aggiornato la scheda' : 'Hai creato la scheda "' + c.titolo + '"');
}
function tlMiaCambia(id){
  const c = tlMie().filter(function(x){ return x.id === id; })[0]; if (!c) return;
  TL.mod = id; TL.bozza = c.richiesta || c.titolo; TL.esito = ''; TL.tab = 'piu'; tlPaint();
  const f = document.getElementById('tlCampo'); if (f) f.focus();
}
function tlMiaAnnulla(){ const id = TL.mod; TL.mod = ''; TL.bozza = ''; TL.esito = ''; TL.tab = id || 'riepilogo'; tlPaint(); }
async function tlMiaElimina(id){
  const c = tlMie().filter(function(x){ return x.id === id; })[0]; if (!c) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare la scheda "' + c.titolo + '"?', 'La tua giornata resta com’è. Sparisce solo la scheda.', 'Elimina', true); }catch(_){ }
  if (!ok) return;
  tlScriviMie(tlMie().filter(function(x){ return x.id !== id; }));
  TL.tab = 'riepilogo'; tlPaint();
  if (typeof toast === 'function') toast('Scheda eliminata');
}

function tlSchedeHtml(){
  return '<div class="pst-tabs" role="tablist">' + tlSchedeTutte().map(function(s){
    const on = s.id === TL.tab;
    return '<button type="button" role="tab" aria-selected="' + on + '" class="pst-tab tl-tab' + (on ? ' on' : '') + (s.piu ? ' piu' : '') + (s.mia ? ' mia' : '') + '"'
      + (s.piu ? ' aria-label="' + esc(s.t) + '"' : '') + ' onclick="tlTab(\'' + s.id + '\')">'
      + (s.piu ? TL_PIU_SVG : '<i class="tl-tem" aria-hidden="true">' + esc(s.em) + '</i><span>' + esc(s.t) + '</span>') + '</button>';
  }).join('') + '</div>';
}
/* I RICALCOLI (0.9.326): ogni volta che l'arrivo si e' spostato, cosa e' successo. Sono le stesse voci del foglio "Perche' la data si e' spostata" (perche.js) */
function tlRicalcoliHtml(){
  let log = []; try{ log = (typeof etaLog === 'function') ? etaLog() : []; }catch(_){ log = []; }
  const voci = log.filter(function(v){ return v && typeof v.delta === 'number' && Math.abs(v.delta) >= 60000; }).sort(function(a, b){ return b.at - a.at; }).slice(0, 150);
  let testa = '';
  try{ const s = (typeof ETA !== 'undefined' && ETA.stato) ? ETA.stato : null; if (s && isFinite(s.p50)) testa = '<p class="tlr-arr"><small>Arrivo previsto</small><b>' + esc(etaDataTxt(s.p50)) + '</b></p>'; }catch(_){ }
  if (!voci.length) return testa + '<p class="pst-nota">Ancora nessun ricalcolo: compare qui ogni volta che il tuo arrivo si sposta.</p>';
  const oggi = etaKey(Date.now()), ieri = etaKey(Date.now() - 86400000);
  let h = testa, gruppo = '';
  voci.forEach(function(v){
    const k = etaKey(v.at);
    if (k !== gruppo){
      if (gruppo) h += '</div>';
      gruppo = k;
      h += '<h4 class="tlr-g">' + esc(k === oggi ? 'Oggi' : (k === ieri ? 'Ieri' : etaDataTxt(v.at))) + '</h4><div class="prc-lista">';
    }
    const f = (typeof prcFrase === 'function') ? prcFrase(v) : { ico: '•', t: String(etaCausaTxt(v) || '') };
    const t = (k === oggi) ? f.t : String(f.t).replace(/^Ieri avevi/, 'Avevi').replace(/^Oggi hai/, 'Hai');
    const su = v.delta > 0;
    h += '<div class="prc-r"><span>' + f.ico + '</span><p>' + esc(t) + '<small>' + tlOra(v.at) + '</small></p><i class="' + (su ? 'su' : 'giu') + '">' + (su ? '+' : '−') + esc((typeof prcTempo === 'function') ? prcTempo(v.delta) : '') + '</i></div>';
  });
  return h + '</div>';
}
function tlReportHtml(){
  const ev = tlFiltrati(TL.ev, true);
  if (!tlSchedeTutte().some(function(s){ return s.id === TL.tab; })) TL.tab = 'riepilogo';
  const mia = tlMie().filter(function(c){ return c.id === TL.tab; })[0];
  let corpo = '';
  try{
    if (TL.tab === 'ore') corpo = tlSchedaOre(ev);
    else if (TL.tab === 'app') corpo = tlSchedaApp(ev);
    else if (TL.tab === 'ricerche') corpo = tlSchedaRicerche(ev);
    else if (TL.tab === 'carb') corpo = tlSchedaCarb();
    else if (TL.tab === 'decisioni') corpo = tlSchedaDecisioni();
    else if (TL.tab === 'ai') corpo = (typeof pntSchedaHtml === 'function') ? pntSchedaHtml(TL.off) : '';
    else if (TL.tab === 'piu') corpo = tlPiuHtml();
    else if (mia) corpo = tlSchedaMia(mia);
    else corpo = tlSchedaRiepilogo();
  }catch(_){ corpo = '<p class="pst-nota">Questa scheda non si apre adesso. Riprova fra poco.</p>'; }
  const tabs = tlSchedeHtml();
  const n = tlFiltriAccesi();
  /* le schede tue sono gia' un filtro: sotto di loro le pillole dei filtri del report non valgono */
  return '<section class="pst tlr" id="tlReport">'
    + '<p class="pst-kick">Il tuo report</p>'
    + '<button type="button" class="tls-dots' + (n ? ' acceso' : '') + '" onclick="tlFiltriApri(\'menu\')" aria-label="Filtra il report">' + tlSvg('dots', 20) + '</button>'
    + (mia || TL.tab === 'piu' ? '' : tlPilloleHtml())
    + tabs
    + '<div class="pst-corpo tls-corpo">' + corpo + '</div>'
    + '</section>';
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO DEI FILTRI (tre puntini del report): prima la voce, poi il suo controllo.
   Velo scuro, X, si chiude toccando fuori; il tasto indietro del telefono lo chiude (nav.js).
   --------------------------------------------------------------------------------------- */
function tlFiltriChiudi(){ const v = document.getElementById('tlfVelo'); if (v) v.remove(); }
function tlFiltriApri(vista){
  tlMenuClose();
  let v = document.getElementById('tlfVelo');
  if (!v){
    v = document.createElement('div');
    v.id = 'tlfVelo';
    v.className = 'tlf-velo';
    v.innerHTML = '<div class="tlf-scrim" onclick="tlFiltriChiudi()"></div>'
      + '<div class="tlf-f" role="dialog" aria-modal="true" aria-label="Filtra il report">'
      + '<button type="button" class="tlf-x" onclick="tlFiltriChiudi()" aria-label="Chiudi">' + tlSvg('x', 18) + '</button>'
      + '<div class="tlf-in"></div></div>';
    (document.getElementById('phone') || document.body).appendChild(v);
  }
  const c = v.querySelector('.tlf-in');
  c.innerHTML = tlFiltriCorpo(vista || 'menu');
  c.scrollTop = 0;
  try{ v.querySelector('.tlf-f').setAttribute('aria-label', vista === 'chiedi' ? 'Chiedi al tuo agente personale' : 'Filtra il report'); }catch(_){ }
}
function tlFiltriTesta(titolo){
  return '<div class="tlf-testa"><button type="button" class="tlf-back" onclick="tlFiltriApri(\'menu\')" aria-label="Torna ai filtri">' + tlSvg('sx', 18) + '</button>'
    + '<h3>' + titolo + '</h3></div>';
}
function tlFiltriRiga(onclick, icona, titolo, sotto, scelta){
  return '<button type="button" class="tlf-r' + (scelta ? ' on' : '') + '" onclick="' + onclick + '">' + icona
    + '<span class="tlf-rt"><b>' + titolo + '</b>' + (sotto ? '<small>' + sotto + '</small>' : '') + '</span>'
    + '<span class="tlf-rf">' + (scelta ? tlIco('spunta', 18) : tlSvg('dx', 16)) + '</span></button>';
}
function tlFiltriCorpo(vista){
  const q = function(k){ return '<span class="tlf-q">' + tlIco(k, 18) + '</span>'; };
  /* 0.9.353, Andrea: "Analizza dove va il mio tempo e Trova i pattern della giornata vanno nel Riepilogo". Chi ha Premium tocca
     "Chiedi al tuo agente personale" e sceglie qui; la domanda parte con i dati di questa giornata (tlAgente) */
  if (vista === 'chiedi'){
    return '<div class="tlf-chiedi"><h3 class="tlf-h">Cosa chiedi al tuo agente personale?</h3>'
      + '<p class="tlf-p">Il tuo agente personale legge questa giornata e ti risponde in chat.</p>'
      + '<div class="tlf-lista">'
      + tlFiltriRiga('tlFiltriChiudi();tlAgente(\'analisi\')', q('lente'), 'Analizza dove va il mio tempo', 'Scopri dove finiscono tempo ed energia', false)
      + tlFiltriRiga('tlFiltriChiudi();tlAgente(\'pattern\')', q('nodi'), 'Trova i pattern della giornata', 'Scopri cosa ti porta fuori rotta', false)
      + '</div></div>';
  }
  if (vista === 'app'){
    const l = tlAppDellaFascia();
    return tlFiltriTesta('Scegli un\'app')
      + '<div class="tlf-lista">'
      + tlFiltriRiga('tlFiltroApp(\'\')', q('app'), 'Tutte le app', '', !TL.app)
      + l.map(function(a){ return tlFiltriRiga('tlFiltroApp(\'' + esc(a.p) + '\')', '<span class="tlf-q tlf-qi">' + tlIconaTag(a.p, 30, null, a.l) + '</span>', esc(a.l || a.p), tlDur(a.ms) + ' ' + esc(tlFasciaNome()), TL.app === a.p); }).join('')
      + '</div>' + (l.length ? '' : '<p class="tlf-nota">In queste ore non hai aperto nessuna app.</p>');
  }
  if (vista === 'ora'){
    return tlFiltriTesta('Scegli le ore')
      + '<div class="tlf-lista">' + TL_FASCE.filter(function(f){ return f[0] !== 'mia'; }).map(function(f){
          return tlFiltriRiga('tlFiltroOre(\'' + f[0] + '\')', q('ora'), f[1], f[0] === 'tutto' ? 'Tutte le 24 ore' : 'Dalle ' + f[2] + ' alle ' + f[3], TL.fascia === f[0]);
        }).join('') + '</div>'
      + '<p class="tlf-sez">Oppure scegli tu le ore</p>'
      + '<div class="tlf-ore"><label><span>Dalle</span><input type="time" id="tlfDa" value="' + esc(TL.fDa) + '"></label>'
      + '<label><span>Alle</span><input type="time" id="tlfA" value="' + esc(TL.fA) + '"></label></div>'
      + '<button type="button" class="tlf-cta" onclick="tlFiltroMie()">Mostra queste ore</button>';
  }
  if (vista === 'cosa'){
    const conta = {};
    tlFiltrati(TL.ev, false).forEach(function(e){ if (!TL.app || e.pkg === TL.app){ const c = tlCatDi(e); conta[c] = (conta[c] || 0) + e.msIn; } });
    const cats = TL_CAT.filter(function(c){ return c[0] === 'tutto' || conta[c[0]] || TL.cat === c[0]; });
    return tlFiltriTesta('Scegli cosa guardare')
      + '<div class="tlf-lista">' + cats.map(function(c){
          return tlFiltriRiga('tlFiltroCat(\'' + c[0] + '\')', '<span class="tlf-q tlf-qe">' + c[2] + '</span>', c[0] === 'tutto' ? 'Tutto quello che hai fatto' : c[1],
            c[0] === 'tutto' ? '' : tlDur(conta[c[0]] || 0), TL.cat === c[0]);
        }).join('') + '</div>';
  }
  if (vista === 'giorno'){
    const righe = [];
    for (let i = 0; i < 7; i++){
      const nome = tlNomeGiorno(i);
      righe.push(tlFiltriRiga('tlFiltroGiorno(' + i + ')', q('giorno'), esc(nome.charAt(0).toUpperCase() + nome.slice(1)), '', TL.off === i));
    }
    return tlFiltriTesta('Scegli il giorno')
      + '<div class="tlf-lista">' + righe.join('') + '</div>'
      + '<p class="tlf-nota">Android tiene la cronologia per circa una settimana.</p>';
  }
  /* il menu: le quattro voci, con la scelta di adesso scritta sotto */
  const giorno = tlNomeGiorno(TL.off);
  return '<h3 class="tlf-h">Filtra il report</h3>'
    + '<p class="tlf-p">Il report, i momenti e le ore seguono il filtro che scegli.</p>'
    + '<div class="tlf-lista">'
    + tlFiltriRiga('tlFiltriApri(\'app\')', q('app'), 'Filtra per app', TL.app ? esc(tlNomeApp(TL.app)) : 'Tutte le app', false)
    + tlFiltriRiga('tlFiltriApri(\'ora\')', q('ora'), 'Filtra per ora', TL.fascia === 'tutto' ? 'Tutto il giorno' : esc(tlFasciaBreve()), false)
    + tlFiltriRiga('tlFiltriApri(\'cosa\')', q('cosa'), 'Filtra per attività', TL.cat === 'tutto' ? 'Social, video, ricerche, siti e altro' : esc(tlCatNome()), false)
    + tlFiltriRiga('tlFiltriApri(\'giorno\')', q('giorno'), 'Filtra per giorno', esc(giorno.charAt(0).toUpperCase() + giorno.slice(1)), false)
    + '</div>'
    + (tlFiltriAccesi() ? '<button type="button" class="tlf-via" onclick="tlFiltriVia()">Togli tutti i filtri</button>' : '');
}
function tlFiltroApp(p){ tlFiltriChiudi(); tlSetApp(p); }
function tlFiltroOre(k){ tlFiltriChiudi(); tlSetFascia(k); }
function tlFiltroCat(k){ tlFiltriChiudi(); tlSetCat(k); }
function tlFiltroGiorno(i){ tlFiltriChiudi(); if (i === TL.off) return; TL.off = i; TL.pag = 0; TL.app = ''; tlCarica(); }
function tlFiltroMie(){
  const a = (document.getElementById('tlfDa') || {}).value || '', b = (document.getElementById('tlfA') || {}).value || '';
  if (!/^\d{1,2}:\d{2}$/.test(a) || !/^\d{1,2}:\d{2}$/.test(b)) return;
  if (tlMinuti(b) <= tlMinuti(a)){ if (typeof toast === 'function') toast('L\'ora di fine viene dopo quella di inizio'); return; }
  TL.fDa = a; TL.fA = b;
  tlFiltriChiudi();
  tlSetFascia('mia');
}
function tlFiltriVia(){ tlFiltriChiudi(); TL.app = ''; TL.cat = 'tutto'; TL.fascia = 'tutto'; TL.pag = 0; tlPaint(); }

function tlPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }

/** La richiesta pronta per l'agente, con i dati della scelta. Si scrive nel campo, parte solo con invio. */
function tlAgente(tipo){
  if (!tlPremium()){
    try{ flVibra(12); }catch(_){ }
    if (typeof pwUpsellApri === 'function') pwUpsellApri();
    else if (typeof toast === 'function') toast('È una funzione di Premium');
    return;
  }
  const ev = tlFiltrati(TL.ev, true);
  const giorno = tlNomeGiorno(TL.off).toLowerCase();
  const cat = (TL_CAT.filter(function(c){ return c[0] === TL.cat; })[0] || TL_CAT[0])[1];
  const scelta = 'Giorno: ' + giorno + '. Ore: ' + tlFasciaNome() + '. Cosa: ' + cat.toLowerCase() + (TL.app ? '. App: ' + tlNomeApp(TL.app) : '') + '.';
  const w = tlFinestra();
  const carb = tlCarbConto(tlCarburante(w.da, w.a));
  const righe = ev.filter(function(e){ return e.msIn >= 3000 || e.cosa; }).slice(-120).map(function(e){
    return tlOra(e.tIn) + ' ' + e.app + (e.cosa ? ' (' + tlTipoNome(e.tipo) + ': ' + e.cosa + ')' : '') + ' ' + tlDur(e.msIn);
  });
  const dati = scelta + '\nCarburante: +' + tlNum(carb.su) + ' guadagnato, ' + tlNum(carb.giu) + ' perso.\nQuello che ho fatto, riga per riga:\n' + (righe.join('\n') || '(niente)');
  const testa = {
    analisi: 'Fammi un\'analisi approfondita di dove stanno andando il mio tempo e la mia energia in questa parte della giornata, e dimmi qual è la prima cosa che cambieresti.',
    pattern: 'Trova i pattern che si ripetono qui dentro: a che ora cedo, quale app mi porta a quale altra, quali ricerche mi portano fuori rotta. Dimmi quali sono i miei grilletti.',
    filtro: 'Crea un filtro nuovo sulla mia giornata e mostrami solo quello che ci rientra. Il filtro che voglio: ' + String(TL.bozza || '').trim()
  }[tipo] || '';
  const testo = tipo === 'filtro' ? dati + '\n\n' + testa : testa + '\n\n' + dati;
  const titolo = 'Timeline di ' + giorno;
  /* 0.9.353, Andrea: "chi ha Premium deve parlare con il suo agente personale". Analizza e Trova i pattern sono pulsanti che dicono gia'
     cosa fanno: la domanda parte subito (agNuovaConversazione con invia). Il filtro lo scrive la persona: resta nel campo (agPopover). */
  let s = null; try{ s = (typeof agStato === 'function') ? agStato() : null; }catch(_){ s = null; }
  if (tipo !== 'filtro' && s && s.impostato && typeof agNuovaConversazione === 'function'){
    agNuovaConversazione(testo, { invia: true, titolo: titolo });
  } else if (typeof agPopover === 'function'){
    agPopover(testo, { titolo: titolo });
  } else if (typeof agApri === 'function'){
    Promise.resolve(agApri()).then(function(){ try{ AG.vista = 'chat'; agPaint(); }catch(_){ } });
    setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900);
  } else if (typeof toast === 'function') toast('L\'agente si apre dalla scheda Profilo.');
}

function tlTipoNome(t){
  return { ricerca: 'ricerca', sito: 'sito', video: 'video', ai: 'domanda', reel: 'reel', storie: 'storie', messaggi: 'messaggi', feed: 'feed', app: 'app' }[t] || t;
}

/* ---------------------------------------------------------------------------------------
   I MOMENTI DELLA GIORNATA (ritratto dal vero: la linea a sinistra con i punti distanziati,
   l'ora e una frase, la scheda con l'immagine a sinistra, il testo al centro e il valore a
   destra, e il pulsante per condividere). Cinque per pagina, dal piu' recente.
   --------------------------------------------------------------------------------------- */
function tlFraseEvento(e){
  const a = esc(e.app);
  switch (e.tipo){
    case 'ricerca': return 'Hai cercato su ' + a;
    case 'ai': return 'Hai chiesto a ' + a;
    case 'video': return 'Hai guardato un video su ' + a;
    case 'reel': return 'Hai guardato i reel su ' + a;
    case 'storie': return 'Hai guardato le storie su ' + a;
    case 'messaggi': return 'Hai aperto i messaggi su ' + a;
    case 'feed': return 'Hai scorso ' + a;
    case 'sito': return 'Hai letto ' + esc(tlHost(e.url) || 'un sito') + ' su ' + a;
    default: return 'Hai usato ' + a;
  }
}
function tlHost(url){
  return String(url || '').replace(/^[a-z]+:\/\//i, '').replace(/^www\./, '').replace(/^m\./, '').split(/[\/?#:]/)[0];
}

/** I momenti, dagli eventi filtrati: i pezzi uguali vicini diventano uno solo, e restano quelli che contano. */
function tlMomenti(){
  const w = tlFinestra();
  const ev = tlFiltrati(TL.ev, true).filter(function(e){ return e.pkg !== TL_DM; });
  const uniti = [];
  ev.forEach(function(e){
    const u = uniti[uniti.length - 1];
    const fineU = u ? u.t + u.ms : 0;
    if (u && u.pkg === e.pkg && u.tipo === e.tipo && (e.tipo === 'reel' || e.tipo === 'storie' || e.tipo === 'feed' || e.tipo === 'app' || u.cosa === e.cosa) && e.tIn - fineU < 120000){
      u.ms += e.msIn; u.n++; if (!u.cosa && e.cosa) u.cosa = e.cosa;
      return;
    }
    uniti.push({ t: e.tIn, ms: e.msIn, pkg: e.pkg, app: e.app, tipo: e.tipo, cosa: e.cosa, url: e.url, n: 1 });
  });
  const out = [];
  uniti.forEach(function(u){
    const soglia = { ricerca: 0, ai: 0, video: 30000, sito: 30000, messaggi: 60000, reel: 60000, storie: 60000, feed: 120000, app: 300000 }[u.tipo];
    if (u.ms < (soglia == null ? 300000 : soglia)) return;
    const cosa = u.cosa ? (u.tipo === 'ricerca' || u.tipo === 'ai' || u.tipo === 'video' ? '"' + u.cosa + '"' : u.cosa) : (u.n > 1 ? u.n + ' aperture di fila' : 'Un\'apertura sola');
    out.push({ t: u.t, k: 'app', pkg: u.pkg, nome: u.app, frase: tlFraseEvento(u), titolo: cosa,
               sotto: tlOra(u.t) + (u.ms >= 60000 ? ' - ' + tlOra(u.t + u.ms) : ''), valore: u.ms ? tlDur(u.ms) : '', cls: '' });
  });
  if (TL.cat === 'tutto' && !TL.app){
    tlVita(w.da, w.a).forEach(function(v){
      if (v.k === 'albero'){
        const fatti = Math.round((v.spentMs || 0) / 60000);
        out.push({ t: v.at, k: 'albero', ok: v.ok, v: v, frase: v.ok ? 'Hai completato una sessione di Full Focus' : 'Hai interrotto una sessione di Full Focus',
                   titolo: v.intent || v.tag ? esc(v.intent || v.tag) : (v.ok ? 'L\'albero è cresciuto' : 'L\'albero si è seccato'),
                   sotto: tlOra(v.inizio) + ' - ' + tlOra(v.fine), valore: fatti + ' min', cls: v.ok ? 'su' : 'giu' });
      } else if (v.k === 'spunta'){
        out.push({ t: v.at, k: 'spunta', frase: 'Hai completato una cosa del piano', titolo: esc(v.t || ''), sotto: v.verificata ? 'Vista in Full Focus' : '', valore: '✓', cls: 'su' });
      } else if (v.k === 'ceduto'){
        out.push({ t: v.at, k: 'ceduto', frase: v.id === 'quick' ? 'Hai fermato il blocco rapido' : 'Hai interrotto un blocco', titolo: 'Il blocco era acceso e l\'hai tolto', sotto: '', valore: '', cls: 'giu' });
      }
    });
    tlCarburante(w.da, w.a).filter(function(v){ return Math.abs(v.delta) >= 1; }).forEach(function(v){
      out.push({ t: v.t, k: 'carb', su: v.delta > 0, frase: v.delta > 0 ? 'Il tuo carburante è salito' : 'Hai perso carburante',
                 titolo: esc(v.l || ''), sotto: esc(v.nota || ''), valore: (v.delta > 0 ? '+' : '−') + tlNum(v.delta), cls: v.delta > 0 ? 'su' : 'giu' });
    });
  }
  out.sort(function(a, b){ return b.t - a.t; });
  return out;
}

function tlImmagine(m){
  if (m.k === 'albero') return '<span class="tlm-img tlm-pianta' + (m.ok ? ' ok' : ' ko') + '">' + tlPianta(m.v) + '</span>';
  if (m.k === 'carb') return '<span class="tlm-img tlm-carb' + (m.su ? ' su' : ' giu') + '">' + tlSvg('carb', 30) + '</span>';
  if (m.k === 'spunta') return '<span class="tlm-img tlm-em"><i>✅</i></span>';
  if (m.k === 'ceduto') return '<span class="tlm-img tlm-em giu"><i>🚨</i></span>';
  return '<span class="tlm-img tlm-app">' + tlIconaTag(m.pkg, 52, null, m.nome) + '</span>';
}

function tlMomentiHtml(){
  const tutti = tlMomenti();
  TL.momenti = tutti;
  if (!tutti.length) return '';
  const pagine = Math.ceil(tutti.length / TL_PER_PAGINA);
  if (TL.pag >= pagine) TL.pag = pagine - 1;
  const da = TL.pag * TL_PER_PAGINA;
  const qui = tutti.slice(da, da + TL_PER_PAGINA);
  /* 0.9.305, Andrea: "nessuno condivide la propria ricerca su Chrome": il pulsante Condividi sotto ogni momento non c'e' piu' */
  const html = qui.map(function(m){
    return '<div class="tlm">'
      + '<i class="tlm-punto' + (m.cls ? ' ' + m.cls : '') + '"></i>'
      + '<p class="tlm-ora">' + esc(tlQuando(m.t)) + '</p>'
      + '<p class="tlm-frase">' + m.frase + '</p>'
      + '<div class="tlm-card">' + tlImmagine(m)
      +   '<div class="tlm-t"><b>' + m.titolo + '</b>' + (m.sotto ? '<small>' + m.sotto + '</small>' : '') + '</div>'
      +   (m.valore ? '<b class="tlm-val' + (m.cls ? ' ' + m.cls : '') + '">' + m.valore + '</b>' : '')
      + '</div>'
      + '</div>';
  }).join('');
  const nav = pagine > 1
    ? '<div class="tlm-pag"><button type="button" class="tlx-frec" ' + (TL.pag > 0 ? '' : 'disabled ') + 'onclick="tlPagina(-1)" aria-label="Pagina prima">' + tlSvg('sx', 18) + '</button>'
      + '<span>Pagina ' + (TL.pag + 1) + ' di ' + pagine + '</span>'
      + '<button type="button" class="tlx-frec" ' + (TL.pag < pagine - 1 ? '' : 'disabled ') + 'onclick="tlPagina(1)" aria-label="Pagina dopo">' + tlSvg('dx', 18) + '</button></div>'
    : '';
  return '<h3 class="tlx-h">I momenti della giornata</h3><div class="tlm-lista" id="tlMomenti">' + html + '</div>' + nav;
}
function tlPagina(n){
  TL.pag = Math.max(0, TL.pag + n);
  tlPaint();
  setTimeout(function(){ const el = document.getElementById('tlMomenti'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 30);
}

function tlTestoPiano(h){ const d = document.createElement('div'); d.innerHTML = h || ''; return (d.textContent || '').trim(); }

/** Il momento come immagine: la scheda dipinta su un canvas, condivisa con il foglio di sempre. */
function tlCondividi(i){
  const m = (TL.momenti || [])[i];
  if (!m) return;
  const frase = tlTestoPiano(m.frase), titolo = tlTestoPiano(m.titolo);
  const testo = tlQuando(m.t) + '. ' + frase + ': ' + titolo + (m.valore ? ' (' + tlTestoPiano(m.valore) + ')' : '') + '.';
  const tela = async function(){
    const W = 1080, H = 1080, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const x = cv.getContext('2d');
    const g = x.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#f6cce4'); g.addColorStop(0.45, '#d0d7fd'); g.addColorStop(0.75, '#bce0ff'); g.addColorStop(1, '#ddfefc');
    x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = '#ffffff';
    const r = 48, X = 80, Y = 210, w = W - 160, h = 620;
    x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); x.fill();
    x.textAlign = 'center';
    x.fillStyle = '#001E44'; x.font = '800 54px sans-serif'; x.fillText('DreamMap', W / 2, 140);
    x.fillStyle = '#0075E3'; x.font = '700 40px sans-serif'; x.fillText(tlQuando(m.t), W / 2, Y + 100);
    const capo = function(t, y, font, col, max){
      x.font = font; x.fillStyle = col;
      const passo = parseInt(font.split(' ')[1], 10) * 1.3;
      const righe = [];
      let riga = '';
      String(t).split(' ').forEach(function(p){
        const prova = riga ? riga + ' ' + p : p;
        if (x.measureText(prova).width > w - 120 && riga){ righe.push(riga); riga = p; }
        else riga = prova;
      });
      if (riga) righe.push(riga);
      if (righe.length > max){ righe.length = max; righe[max - 1] = righe[max - 1].replace(/\s+\S*$/, '') + '…'; }
      righe.forEach(function(r, k){ x.fillText(r, W / 2, y + k * passo); });
      return y + (righe.length - 1) * passo;
    };
    let y = capo(frase, Y + 200, '800 52px sans-serif', '#001E44', 2);
    y = capo(titolo, y + 90, '600 44px sans-serif', '#14234A', 3);
    if (m.valore){ x.font = '900 96px sans-serif'; x.fillStyle = m.cls === 'giu' ? '#E63946' : '#0075E3'; x.fillText(tlTestoPiano(m.valore), W / 2, Math.min(Y + h - 60, y + 150)); }
    return cv;
  };
  if (typeof flCondividiApri === 'function'){ flCondividiApri(tela, testo, 'Condividi il momento'); return; }
  try{ if (navigator.share){ navigator.share({ text: testo }); return; } }catch(_){ }
  if (typeof toast === 'function') toast('Su questo dispositivo non si può condividere');
}

/* ---------------------------------------------------------------------------------------
   DREAMMAP NELLE ORE (tempo-app.js): un'apertura di DreamMap divisa per attivita'
   --------------------------------------------------------------------------------------- */
function tlDmPezzi(x){
  if (!x || x.p !== TL_DM || typeof taPezzi !== 'function') return null;
  const fine = x.s + (x.ms || 0);
  const pezzi = taPezzi(x.s - 5000, fine + 5000).map(function(p){
    const s = Math.max(p.s, x.s), e = Math.min(p.e, fine);
    return { s: s, e: e, a: p.a };
  }).filter(function(p){ return p.e - p.s >= 1000; });
  if (!pezzi.length) return null;
  const out = pezzi.map(function(p){
    const ar = taArea(p.a);
    return { s: p.s, ms: p.e - p.s, l: ar.l, col: taCat(ar.c).col };
  });
  const coperto = out.reduce(function(a, p){ return a + p.ms; }, 0);
  if ((x.ms || 0) - coperto >= 60000){
    out.push({ s: pezzi[pezzi.length - 1].e, ms: (x.ms || 0) - coperto, l: 'aperta senza toccarla', col: '#C8D3E3' });
  }
  return out;
}

/* ---------------------------------------------------------------------------------------
   ORA PER ORA: ogni ora e' un cassetto; aperto mostra ogni apertura e cosa c'era dentro
   --------------------------------------------------------------------------------------- */
const TL_APERTE = {};
function tlOraToggle(h){
  TL_APERTE[h] = !TL_APERTE[h];
  const g = document.getElementById('tlxOra' + h);
  if (!g) return;
  g.classList.toggle('on', !!TL_APERTE[h]);
  const b = g.querySelector('.tlx-oh'); if (b) b.setAttribute('aria-expanded', TL_APERTE[h] ? 'true' : 'false');
}

const TL_TIPO_ICO = { ricerca: '🔎', ai: '✨', video: '▶️', reel: '🎞️', storie: '⭕', messaggi: '✉️', feed: '📰', sito: '🌐' };

/** Le viste del menu: tutto, solo le app, solo le scelte. */
const TL_VISTE = [
  ['tutto', 'Tutto insieme'],
  ['app', 'Solo le app'],
  ['vita', 'Solo le mie scelte']
];
function tlVista(){
  try{ return localStorage.getItem('fl_tl_vista') || 'tutto'; }catch(_){ return 'tutto'; }
}
function tlSetVista(v){
  try{ localStorage.setItem('fl_tl_vista', v); }catch(_){ }
  tlMenuClose();
  tlPaint();
}

function tlOre(d){
  const vista = tlVista();
  const w = tlFinestra();
  const ev = (vista === 'vita') ? [] : tlFiltrati(TL.ev, true);
  const vita = (vista === 'app' || TL.cat !== 'tutto' || TL.app) ? [] : tlVita(w.da, w.a);
  if (!ev.length && !vita.length) return '';
  const g = tlSenzaLauncher(d.grani || []);
  const spenti = (d.schermo || []).filter(function(m){ return !m.on; }).map(function(m){ return m.t; });
  const carb = tlCarburante(w.da, w.a);

  const ore = {};
  const ora = function(t){ const h = new Date(t).getHours(); if (!ore[h]) ore[h] = { h: h, ap: {}, lampi: {}, ms: 0, vita: [], righe: [], carb: 0 }; return ore[h]; };

  /* i buchi senza telefono, solo senza filtri di cosa o di app: con un filtro il buco non vuol dire niente */
  if (TL.cat === 'tutto' && !TL.app && vista !== 'vita'){
    for (let i = 1; i < g.length; i++){
      const prima = g[i - 1].s + (g[i - 1].ms || 0);
      const buco = g[i].s - prima;
      if (buco >= 5 * 60000 && prima >= w.da && prima < w.a){
        const spento = spenti.some(function(t){ return t >= prima - 2000 && t <= g[i].s; });
        ora(prima).righe.push({ at: prima + 1, html: '<div class="tlx-buco">' + (spento ? '🌙 ' : '') + tlDur(buco) + ' senza telefono</div>' });
      }
    }
  }

  const gr = (d.grani || []);
  ev.forEach(function(e){
    const o = ora(e.tIn);
    o.ms += e.msIn;
    if (e.g >= 0){ o.ap[e.g] = 1; if ((gr[e.g] && gr[e.g].ms || 0) < TL_LAMPO) o.lampi[e.g] = 1; }
    const lampo = e.g >= 0 && (gr[e.g] && gr[e.g].ms || 0) < TL_LAMPO;
    const dentro = e.pkg === TL_DM && e.g >= 0 ? tlDmPezzi(gr[e.g]) : null;
    if (dentro){
      dentro.forEach(function(p){
        o.righe.push({ at: p.s, html: '<div class="tlx-r dm"><span class="tlx-t">' + tlOra(p.s) + '</span>'
          + tlIconaTag(e.pkg, 26, null, e.app)
          + '<span class="tlx-nome"><small>DreamMap</small><i class="tlx-dmc" style="background:' + p.col + '"></i>' + esc(p.l) + '</span>'
          + '<span class="tlx-dur">' + tlDur(p.ms) + '</span></div>' });
      });
      return;
    }
    const cosa = e.cosa ? '<small class="tlx-cosa">' + (TL_TIPO_ICO[e.tipo] ? TL_TIPO_ICO[e.tipo] + ' ' : '') + esc(e.tipo === 'ricerca' || e.tipo === 'ai' ? '"' + e.cosa + '"' : e.cosa) + '</small>'
      : (e.tipo !== 'app' ? '<small class="tlx-cosa">' + (TL_TIPO_ICO[e.tipo] || '') + ' ' + esc(tlTipoNome(e.tipo)) + '</small>' : '');
    o.righe.push({ at: e.tIn, html: '<div class="tlx-r' + (cosa ? ' due' : '') + '"><span class="tlx-t">' + tlOra(e.tIn) + '</span>'
      + tlIconaTag(e.pkg, 26, null, e.app)
      + '<span class="tlx-nome">' + esc(e.app || e.pkg) + cosa + '</span>'
      + '<span class="tlx-dur' + (lampo ? ' lampo' : '') + '">' + (e.durMs ? tlDur(e.msIn) : 'un attimo') + '</span></div>' });
  });
  vita.forEach(function(v){
    const o = ora(v.at);
    o.vita.push(v.k);
    const rosso = v.k === 'ceduto' || (v.k === 'albero' && !v.ok) || (v.k === 'punto' && v.chi === 'old');
    o.righe.push({ at: v.at, html: '<div class="tlx-r vita' + (rosso ? ' rosso' : '') + '"><span class="tlx-t">' + tlOra(v.at) + '</span>'
      + '<span class="tlx-vico">' + (v.k === 'albero' && !v.ok ? '🥀' : (TL_VITA_ICO[v.k] || '•')) + '</span>'
      + '<span class="tlx-frase">' + tlVitaFrase(v) + '</span></div>' });
  });
  carb.forEach(function(v){ if (ore[new Date(v.t).getHours()]) ora(v.t).carb += v.delta; });

  const lista = Object.keys(ore).map(function(k){ return ore[k]; }).sort(function(a, b){ return a.h - b.h; });
  const max = Math.max.apply(null, lista.map(function(o){ return o.ms; }).concat([1]));
  return lista.map(function(o){
    o.righe.sort(function(a, b){ return a.at - b.at; });
    const hh = ('0' + o.h).slice(-2);
    const aperta = !!TL_APERTE[o.h];
    const n = Object.keys(o.ap).length, lampi = Object.keys(o.lampi).length;
    const icone = {};
    o.vita.forEach(function(k){ icone[k] = (icone[k] || 0) + 1; });
    const vitaTxt = Object.keys(icone).map(function(k){ return (TL_VITA_ICO[k] || '•') + (icone[k] > 1 ? icone[k] : ''); }).join(' ');
    const sotto = n
      ? n + (n === 1 ? ' volta' : ' volte') + ' · ' + tlDur(o.ms) + (lampi ? ' · <em>' + lampi + (lampi === 1 ? ' lampo' : ' lampi') + '</em>' : '')
      : (o.ms ? tlDur(o.ms) : 'Nessuna app aperta');
    const carbTxt = Math.abs(o.carb) >= 0.05 ? '<span class="tlx-carb ' + (o.carb > 0 ? 'su' : 'giu') + '">' + (o.carb > 0 ? '+' : '−') + tlNum(o.carb) + ' ⛽</span>' : '';
    return '<div class="tlx-ora' + (aperta ? ' on' : '') + '" id="tlxOra' + o.h + '">'
      + '<button type="button" class="tlx-oh" aria-expanded="' + (aperta ? 'true' : 'false') + '" onclick="tlOraToggle(' + o.h + ')">'
      +   '<b class="tlx-hh">' + hh + ':00</b>'
      +   '<span class="tlx-ohm"><small>' + sotto + '</small>'
      +     '<span class="tlx-obar"><i style="width:' + Math.round(o.ms / max * 100) + '%"></i></span></span>'
      +   carbTxt
      +   (vitaTxt ? '<span class="tlx-ovita">' + vitaTxt + '</span>' : '')
      +   '<span class="animated-plus"></span></button>'
      + '<div class="tlx-oin">' + o.righe.map(function(r){ return r.html; }).join('') + '</div>'
      + '</div>';
  }).join('');
}

/* ---------------------------------------------------------------------------------------
   IL DISEGNO
   --------------------------------------------------------------------------------------- */
function tlRadioAvviso(){
  const r = TL.radio;
  if (!r) return '';
  if (r.accessibilita === false){
    return '<div class="tl-avviso"><p>Per sapere cosa facevi dentro le app serve l\'accessibilità di DreamMap.</p>'
      + '<button type="button" onclick="goId(\'s-perm\')">Dai il permesso</button></div>';
  }
  if (r.on === false){
    return '<div class="tl-avviso"><p>Per vedere il sito, la ricerca o il video di ogni apertura, accendi "Registra cosa fai dentro le app".</p>'
      + '<button type="button" onclick="tlRadioImposta(true)">Accendi</button></div>';
  }
  return '';
}

function tlPaint(){
  const box = document.getElementById('tlBody');
  if (!box) return;
  const d = TL.dati;
  if (TL.tab === 'ricalcoli' || TL.tab === 'ai'){
    const sx0 = (box.querySelector('.tlr .pst-tabs') || {}).scrollLeft || 0;
    box.innerHTML = '<section class="pst tlr" id="tlReport"><p class="pst-kick">Il tuo report</p>' + tlSchedeHtml() + '<div class="pst-corpo tls-corpo">' + (TL.tab === 'ai' ? ((TL.off ? tlTesta() : '') + pntSchedaHtml(TL.off)) : tlRicalcoliHtml()) + '</div></section>';
    /* 0.9.353: anche qui la scheda scelta si vede intera (Le tue AI restava tagliata a destra) */
    tlRigaTab(box, sx0);
    return;
  }

  if (!d){
    box.innerHTML = tlTesta() + tlVuoto('📵', 'La cronologia si vede solo nell\'app',
      'La cronologia la ricostruisce il telefono, con DreamMap installata. In una finestra del browser non c\'è.');
    return;
  }
  if (!d.granted){
    box.innerHTML = tlTesta() + tlVuoto('🔒', 'Manca l\'accesso alle statistiche d\'uso',
      'È lo stesso permesso della scheda Report. Senza, Android non dice a nessuna app cosa hai aperto.')
      + '<button class="btn primary" style="margin:14px auto 0;display:block" onclick="goId(\'s-perm\')">Dai il permesso</button>';
    return;
  }

  const g = d.grani || [];
  if (!g.length){
    box.innerHTML = tlTesta() + tlVuoto('🗓️', 'Di questo giorno non c\'è cronologia',
      TL.off >= 7
        ? 'Android tiene gli eventi d\'uso per circa una settimana, poi li cancella. Più indietro di così non li ha nessuna app.'
        : 'Nessuna app in primo piano registrata. Se il telefono era spento, è tutto normale.');
    return;
  }

  let html = tlTesta();
  html += tlRadioAvviso();
  html += tlReportHtml();
  html += tlMomentiHtml();

  html += '<h3 class="tlx-h">Ora per ora</h3>'
    + '<p class="tlx-nota fuori">Tocca un\'ora per vedere cosa hai aperto, cosa c\'era dentro e per quanto.</p>';
  if (d.nascosti){
    html += '<p class="tlx-nota fuori">Altre <b>' + d.nascosti + '</b> aperture (' + tlDur(d.nascostiMs)
      + ' in tutto) sono più corte del filtro scelto: lo cambi dai tre puntini.</p>';
  }
  const ore = tlOre(d);
  html += ore ? '<div class="tlx-ore">' + ore + '</div>' : '<p class="tlx-nota fuori">In questa scelta non c\'è niente.</p>';
  html += '<div class="spacer"></div>';

  const y = box.closest('.screen') ? box.closest('.screen').scrollTop : 0;
  const sx = (box.querySelector('.tlr .pst-tabs') || {}).scrollLeft || 0;
  box.innerHTML = html;
  try{ if (box.closest('.screen')) box.closest('.screen').scrollTop = y; }catch(_){ }
  tlRigaTab(box, sx);
}
/** La scheda scelta si vede sempre intera, anche quando sta in fondo alla riga che scorre. */
function tlRigaTab(box, sx){
  const row = box.querySelector('.tlr .pst-tabs'), on = row && row.querySelector('.pst-tab.on');
  if (!row) return;
  /* la riga scorre "smooth": rimessa a posto senza animazione, e con la misura calcolata qui
     (letto subito dopo, scrollLeft vale ancora zero e la scheda scelta restava fuori vista) */
  row.style.scrollBehavior = 'auto';
  let x = sx;
  if (on && (on.offsetLeft < x || on.offsetLeft + on.offsetWidth > x + row.clientWidth)) x = Math.max(0, on.offsetLeft - 24);
  row.scrollLeft = x;
  row.style.scrollBehavior = '';
}

function tlVuoto(ico, tit, testo){
  return '<div class="tl-vuoto"><div class="tl-v-ico">' + ico + '</div><b>' + esc(tit) + '</b><p>' + testo + '</p></div>';
}

/** Porta il Genio dentro alla giornata che si sta guardando.
    0.9.353, Andrea: "la lettura Il tuo sogno del Genio va bene per chi e' gratis; chi ha Premium deve parlare con il suo agente
    personale". Chi ha Premium sceglie fra Analizza dove va il mio tempo e Trova i pattern della giornata (tlFiltriCorpo 'chiedi'). */
function tlAlGenio(){
  if (tlPremium()){ tlFiltriApri('chiedi'); return; }
  if (typeof orOpen === 'function') orOpen();
  else if (typeof toast === 'function') toast('Il Genio si apre dalla scheda Nuovo te.');
}

/* ---------------------------------------------------------------------------------------
   L'INTERRUTTORE DELLA RADIOGRAFIA
   --------------------------------------------------------------------------------------- */
async function tlRadioImposta(on){
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setRadiografia){
      const r = await NATIVE.setRadiografia({ on: !!on });
      if (TL.radio) TL.radio.on = !!(r && r.on);
    }
  }catch(_){ }
  tlMenuClose();
  if (on && TL.radio && TL.radio.accessibilita === false){ goId('s-perm'); return; }
  if (typeof toast === 'function') toast(on ? 'Da adesso la Timeline segna cosa fai dentro le app' : 'La Timeline non segna più cosa fai dentro le app');
  tlPaint();
}

/* ---------------------------------------------------------------------------------------
   IL MENU DEI TRE PUNTINI (velo scuro, X, si chiude toccando fuori)
   --------------------------------------------------------------------------------------- */
function tlMenuClose(){
  const m = document.getElementById('tlMenu');
  if (m) m.remove();
  const v = document.getElementById('tlVeil');
  if (v) v.remove();
}
function tlMenuOpen(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('tlMenu')){ tlMenuClose(); return; }
  const box = document.getElementById('s-timeline');
  if (!box) return;

  const veil = document.createElement('div');
  veil.id = 'tlVeil';
  veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); tlMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(veil);

  const r = TL.radio;
  const radioOn = !!(r && r.on !== false && r.accessibilita !== false);
  const m = document.createElement('div');
  m.id = 'tlMenu';
  m.className = 'arb-menu tl-menu';
  m.innerHTML = '<button type="button" class="tl-menu-x" aria-label="Chiudi" onclick="tlMenuClose()">' + tlSvg('x', 16) + '</button>'
    + '<p class="arb-mtit">Cosa fai dentro le app</p>'
    + '<button type="button" class="tl-sw-r" role="switch" aria-checked="' + (radioOn ? 'true' : 'false') + '" onclick="tlRadioImposta(' + (radioOn ? 'false' : 'true') + ')">'
    +   '<span><b>Registra cosa fai dentro le app</b><small>Il sito, la ricerca, il video: resta solo su questo telefono, mai le password.</small></span>'
    +   '<i class="tl-sw' + (radioOn ? ' on' : '') + '"></i></button>'
    + '<p class="arb-mtit">Cosa mostrare</p>'
    + TL_VISTE.map(function(v){
        return '<button type="button" class="' + (v[0] === tlVista() ? 'on' : '') + '" '
          + 'onclick="tlSetVista(\'' + v[0] + '\')">' + v[1] + '</button>';
      }).join('')
    + '<p class="arb-mtit">Quanto in dettaglio</p>'
    + TL_SOGLIE.map(function(s){
        return '<button type="button" class="' + (s[0] === TL.min ? 'on' : '') + '" '
          + 'onclick="tlSetMin(' + s[0] + ')">' + s[1] + '</button>';
      }).join('')
    + '<p class="arb-mtit">Vai a</p>'
    + '<button type="button" onclick="tlMenuClose();TL.off=0;TL.pag=0;tlCarica()">Oggi</button>'
    + '<button type="button" onclick="tlMenuClose();TL.off=1;TL.pag=0;tlCarica()">Ieri</button>';
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.tl-dots'));
}

registerScreen('s-timeline',
  '<div class="topbar">'
  /* 0.9.322, Andrea: "la stessa icona dei giorni qui sotto: sono due pulsanti uguali". In alto la freccia, sotto i chevron */
  + '<button class="iconbtn" onclick="tlTornaIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/></svg></button>'
  + '<b class="blk-title">Timeline</b>'
  + '<button type="button" class="iconbtn tl-dots" onclick="tlMenuOpen(event)" aria-label="Opzioni">' + tlSvg('dots', 20) + '</button>'
  + '</div>'
  + '<div id="tlBody"></div>', { back: function(){ return tlIndietro(); } });

(function tlStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* IL TITOLO AL CENTRO (Andrea, 28/10): i tre puntini erano appesi in assoluto a 2px dal bordo,
       fuori dalla riga del titolo. Adesso sono un pulsante della stessa riga, largo quanto quello
       per tornare indietro: il titolo sta in mezzo ai due, cioe' al centro dello schermo. */
    '#s-timeline > .topbar .tl-dots{position:static;flex:none}',
    'body.dark #s-timeline > .topbar .iconbtn{background:rgba(255,255,255,.1);color:#fff}',

    '.tl-ico{border-radius:22%;object-fit:cover;flex:0 0 auto;display:block}',
    '.tl-ico-vuota{display:inline-flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-family:var(--font-body)}',
    '.tl-pianta-fallback{font-size:38px;line-height:1}',

    '.tl-attesa{padding:34px 0;text-align:center;font:600 13px var(--font-body);color:var(--muted,#7A8AA3)}',
    '.tl-vuoto{text-align:center;padding:34px 16px;border:1.5px dashed var(--line);border-radius:20px}',
    '.tl-v-ico{font-size:38px;line-height:1}',
    '.tl-vuoto b{display:block;margin-top:12px;font:800 16px var(--font-body);color:var(--navy)}body.dark .tl-vuoto b{color:#fff}',
    '.tl-vuoto p{margin:8px 0 0;font:500 13px/1.6 var(--font-body);color:var(--muted,#7A8AA3)}',

    '.tl-avviso{margin:0 0 14px;padding:14px 16px;border-radius:18px;background:#E3F1FF;text-align:center}',
    '.tl-avviso p{margin:0;font:600 13px/1.5 var(--font-body);color:#001E44}',
    '.tl-avviso button{margin-top:10px;padding:9px 18px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13px var(--font-body);cursor:pointer}',
    'body.dark .tl-avviso{background:#14234A}body.dark .tl-avviso p{color:#E3F1FF}',

    /* il menu: X in alto, interruttore della radiografia */
    '.tl-menu{min-width:260px;max-width:300px}',
    '.tl-menu .tl-menu-x{position:absolute;top:6px;right:6px;width:30px;height:30px;padding:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#EEF2F8;color:#001E44;border:0}',
    '.tl-menu .tl-menu-x + .arb-mtit{padding-right:44px}',
    '.tl-menu .tl-sw-r{display:flex;align-items:center;gap:12px;border-top:0}',
    '.tl-sw-r span{flex:1;min-width:0}',
    '.tl-sw-r b{display:block;font:800 13px var(--font-body);color:#001E44}',
    '.tl-sw-r small{display:block;margin-top:3px;font:500 11.5px/1.4 var(--font-body);color:#5B6B82;white-space:normal}',
    '.tl-sw{flex:none;position:relative;width:42px;height:24px;border-radius:99px;background:#C8D3E3;transition:background .2s}',
    '.tl-sw::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:left .2s}',
    '.tl-sw.on{background:#0075E3}.tl-sw.on::after{left:21px}',
    'body.dark .tl-sw-r b{color:#fff}body.dark .tl-sw-r small{color:#B8C6DC}body.dark .tl-sw{background:#3A4A66}body.dark .tl-sw.on{background:#0075E3}',
    'body.dark .tl-menu .tl-menu-x{background:rgba(255,255,255,.12);color:#fff}',

    /* ---- il giorno ---- */
    '.tlx-nav{display:flex;align-items:center;justify-content:center;gap:18px;margin:0 0 16px}',
    '.tlx-nav b{min-width:150px;text-align:center;font:800 13px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--navy)}',
    'body.dark .tlx-nav b{color:#fff}',
    '.tlx-frec{width:38px;height:38px;flex:none;border-radius:50%;border:1px solid var(--line);background:var(--card,#fff);color:var(--navy);',
      'display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.tlx-frec[disabled]{opacity:.3}',
    'body.dark .tlx-frec{background:rgba(255,255,255,.06);color:#fff;border-color:#22345A}',

    /* ---- il report: il pannello delle statistiche della partita (classi pst di partita-stats.js) ----
       Qui solo le aggiunte: i tre puntini, le pillole dei filtri, il contenuto delle schede.
       Le regole hanno due classi (.pst.tlr, .tlr .x) perche' partita-stats.js si carica dopo. */
    /* 0.9.353, Andrea: "piu' scuro il fondo del pannello". Con le percentuali, su una scheda lunga il gradiente si stirava e restava un blu
       medio piatto: con gli stop in px arriva al blu scuro entro i primi 520px, e da li' il fondo resta scuro fino in fondo */
    '.pst.tlr{position:relative;padding:20px 0 24px;gap:16px;background:linear-gradient(172deg,#0B3470 0px,#001E44 260px,#00132B 520px,#00132B 100%)}',
    '.tlr .pst-kick{padding:0 56px}',
    /* le schede: l'emoji nel pallino bianco solo su quella attiva (regola di Andrea, come .oz-tem in orizzonti.js) */
    '.tlr .tl-tab:not(.piu){display:inline-flex;align-items:center;gap:7px}',
    '.tlr .tl-tab:not(.on) .tl-tem{display:none}',
    '.tl-tem{flex:none;width:22px;height:22px;border-radius:11px;background:#fff;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:13px;line-height:1;letter-spacing:0}',
    '.tls-dots{position:absolute;top:10px;right:10px;width:38px;height:38px;padding:0;border:0;border-radius:50%;display:flex;align-items:center;justify-content:center;',
      'background:rgba(255,255,255,.1);color:#fff;cursor:pointer}',
    '.tls-dots.acceso{background:#0075E3}',
    '.tls-pills{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;padding:0 16px;margin-top:-6px}',
    '.tls-pill{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:6px 8px 6px 12px;border-radius:99px;border:1px solid rgba(140,198,255,.5);',
      'background:rgba(63,159,244,.2);color:#fff;font:700 12.5px var(--font-body);cursor:pointer}',
    '.tls-pill span{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.tls-pill svg{flex:none;width:18px;height:18px;padding:3px;box-sizing:border-box;border-radius:50%;background:rgba(255,255,255,.18)}',
    '.tlr .tls-corpo{gap:18px}',
    '.tls-em{flex:none;display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:50%;background:#fff;font-size:17px;line-height:1}',
    /* riepilogo: il Genio.
       0.9.353, Andrea: "Il Genio ha notato e' un sottotitolo: occhiello piccolo, il Genio piccolo, la priorita' alle cose notate".
       Occhiello smorzato (12px, azzurro) -> frasi grandi e bianche; occhiello -> prima frase 24px, ultima frase -> pulsante 32px */
    '.tls-genio{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 6px;text-align:center}',
    '.tls-genio img{width:36px;height:36px;object-fit:contain;flex:none}',
    '.tls-genio span{font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.tls-punti{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}',
    '.tls-punti li{display:flex;align-items:flex-start;gap:14px;padding:16px 0;border-top:1px solid rgba(255,255,255,.1);font:500 16px/1.55 var(--font-body);color:#fff;text-align:left}',
    '.tls-punti li:first-child{border-top:0;padding-top:0}',
    '.tls-punti li:last-child{padding-bottom:0}',
    '.tls-punti li strong{color:#fff;font-weight:800}',
    '.tls-punti .tls-em{margin-top:-2px}',
    '.tlr .pst-link{margin-top:0}',
    '.tlr .tls-cta{margin-top:14px}',
    '.tlr .tls-nulla{font-size:14px;color:rgba(255,255,255,.75)}',
    /* ricerche: il pulsante per la pagina con tutte */
    '.tls-tutte{width:100%;min-height:48px;margin-top:14px;padding:0 16px;border:1px solid rgba(140,198,255,.5);border-radius:24px;background:rgba(63,159,244,.14);color:#fff;font:800 14.5px var(--font-body);cursor:pointer}',
    /* "+": la grafica delle statistiche della partita (.pst-piu); il link in chat qui vuole il suo spazio */
    '.tlr .tl-piu .pst-link{margin-top:20px}.tlr .tl-piu .pst-link.muto{margin-top:4px}.tlr .tl-piu textarea{margin-bottom:32px}',
    '.tlr .pst-azioni{margin-top:-4px}',
    /* ore del giorno */
    '.tls-big{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center}',
    '.tls-big b{font:900 42px/1 var(--font-display);letter-spacing:-.02em;color:#fff}',
    '.tls-big small{font:600 13px/1.45 var(--font-body);color:rgba(255,255,255,.7)}',
    '.tls-ore{display:flex;flex-direction:column;gap:12px}',
    '.tls-or{display:grid;grid-template-columns:42px 1fr 66px;align-items:center;gap:10px}',
    '.tls-or span{font:700 12.5px var(--font-body);color:rgba(255,255,255,.7);font-variant-numeric:tabular-nums}',
    '.tls-or > b{text-align:right;font:800 13px var(--font-body);color:#fff;white-space:nowrap}',
    '.tls-or.muta span,.tls-or.muta > b{color:rgba(255,255,255,.35)}',
    '.tls-bar{display:block;height:10px;border-radius:5px;background:rgba(255,255,255,.08);overflow:hidden}',
    '.tls-bar i{display:block;height:100%;border-radius:5px;background:#3F9FF4}',
    '.tls-or.top .tls-bar i{background:#E63946}',
    /* app, ricerche, carburante: le righe */
    '.tls-lista{display:flex;flex-direction:column}',
    '.tls-app,.tls-cosa,.tls-voce{display:flex;align-items:center;gap:12px;padding:11px 0;border-top:1px solid rgba(255,255,255,.08);text-align:left}',
    '.tls-app:first-child,.tls-cosa:first-child,.tls-voce:first-child{border-top:0}',
    '.tls-app-t{flex:1;min-width:0}',
    '.tls-app-t b,.tls-voce b{display:block;font:700 14px var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.tls-app-t small,.tls-cosa small,.tls-voce small{display:block;margin-top:2px;font:600 11.5px var(--font-body);color:rgba(255,255,255,.6)}',
    '.tls-app-t .tls-bar{height:6px;margin-top:7px}',
    '.tls-val{flex:none;min-width:58px;text-align:right;font:800 14px var(--font-body);color:#fff;white-space:nowrap}',
    '.tls-val.su{color:#4CC98F}.tls-val.giu{color:#FF8A94}',
    '.tls-cosa > div{flex:1;min-width:0}',
    '.tls-cosa b{display:block;font:700 14px/1.4 var(--font-body);color:#fff;word-break:break-word}',
    '.tls-voce > div{flex:1;min-width:0}',
    '.tls-tit{margin:0 0 -6px;text-align:center;font:800 15px var(--font-display);color:#fff}',
    '.tls-due{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.tls-due > div{display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 8px;border-radius:18px;background:rgba(255,255,255,.06);text-align:center}',
    '.tls-due b{font:900 32px/1 var(--font-display);font-variant-numeric:tabular-nums}',
    '.tls-due .su b{color:#4CC98F}.tls-due .giu b{color:#FF8A94}',
    '.tls-due small{font:600 12px/1.35 var(--font-body);color:rgba(255,255,255,.7)}',
    '.tls-ff{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.06);font:600 13.5px/1.45 var(--font-body);color:#fff;text-align:left}',
    /* la pagina con tutte le ricerche: la grafica dei momenti (.tlm-*), divisa per ora */
    'body.dark #s-tl-ricerche > .topbar .iconbtn{background:rgba(255,255,255,.1);color:#fff}',
    '#tlqBody{padding:0 16px}',
    '.tlq-sotto{margin:10px 0 30px;text-align:center;font:600 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.tlq-ora + .tlq-ora{margin-top:30px}',
    '.tlq-h{margin:0 0 16px;font:800 16px var(--font-display);color:var(--navy);text-align:center}body.dark .tlq-h{color:#fff}',
    '.tlq-ora .tlm-ora{font-variant-numeric:tabular-nums}',
    /* il foglio "Cosa chiedi al tuo agente personale?": titolo -> sottotitolo 10px, sottotitolo -> scelte 26px */
    '.tlf-chiedi .tlf-h{margin-bottom:10px}.tlf-chiedi .tlf-p{margin-bottom:26px}',

    /* ---- il foglio dei filtri: velo scuro, X, si chiude toccando fuori ---- */
    '.tlf-velo{position:fixed;inset:0;z-index:9500;display:flex;align-items:flex-end;justify-content:center}',
    '.tlf-scrim{position:absolute;inset:0;background:rgba(0,30,68,.55)}',
    'body.dark .tlf-scrim{background:rgba(0,8,22,.72)}',
    '.tlf-f{position:relative;width:100%;max-width:520px;max-height:88vh;border-radius:26px 26px 0 0;background:#fff;color:#001E44;box-shadow:0 -10px 40px rgba(0,30,68,.28);display:flex;flex-direction:column;overflow:hidden}',
    'body.dark .tlf-f{background:#1C2E5A;color:#fff;border-top:1px solid rgba(188,224,255,.35);box-shadow:0 -10px 40px rgba(0,0,0,.5)}',
    '.tlf-in{overflow:auto;padding:22px 18px calc(22px + env(safe-area-inset-bottom))}',
    '.tlf-x{position:absolute;top:22px;right:18px;z-index:2;width:36px;height:36px;padding:0;border:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#EEF2F8;color:#001E44;cursor:pointer}',
    'body.dark .tlf-x{background:rgba(255,255,255,.14);color:#fff}',
    '.tlf-h{margin:4px 44px 6px;text-align:center;font:800 20px var(--font-display);color:inherit}',
    '.tlf-p{margin:0 0 16px;text-align:center;font:500 13.5px/1.5 var(--font-body);color:#5B6B82}body.dark .tlf-p{color:#C9D7EC}',
    '.tlf-testa{display:flex;align-items:center;justify-content:center;position:relative;margin:2px 44px 14px;min-height:36px}',
    '.tlf-testa h3{margin:0;text-align:center;font:800 18px var(--font-display);color:inherit}',
    '.tlf-back{position:absolute;left:-44px;top:0;width:36px;height:36px;padding:0;border:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#EEF2F8;color:#001E44;cursor:pointer}',
    'body.dark .tlf-back{background:rgba(255,255,255,.14);color:#fff}',
    '.tlf-lista{display:flex;flex-direction:column;gap:8px}',
    '.tlf-r{display:flex;align-items:center;gap:12px;width:100%;min-height:56px;padding:8px 12px 8px 8px;border-radius:16px;border:1px solid #E1E8F2;background:#fff;color:#001E44;text-align:left;cursor:pointer}',
    'body.dark .tlf-r{background:rgba(255,255,255,.07);border-color:rgba(188,224,255,.18);color:#fff}',
    '.tlf-r.on{border-color:#0075E3;box-shadow:inset 0 0 0 1px #0075E3}body.dark .tlf-r.on{border-color:#8CC6FF;box-shadow:inset 0 0 0 1px #8CC6FF}',
    '.tlf-q{flex:none;width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:#E3F1FF;color:#0075E3}',
    'body.dark .tlf-q{background:rgba(140,198,255,.18);color:#BCE0FF}',
    '.tlf-qi{background:transparent}body.dark .tlf-qi{background:transparent}',
    '.tlf-qe{background:#fff;border:1px solid #E1E8F2;font-size:19px;line-height:1}body.dark .tlf-qe{background:#fff;border-color:#fff}',
    '.tlf-rt{flex:1;min-width:0}',
    '.tlf-rt b{display:block;font:700 15px var(--font-body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.tlf-rt small{display:block;margin-top:2px;font:600 12px var(--font-body);color:#5B6B82;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .tlf-rt small{color:#C9D7EC}',
    '.tlf-rf{flex:none;display:flex;color:#8A9AB2}.tlf-r.on .tlf-rf{color:#0075E3}body.dark .tlf-r.on .tlf-rf{color:#8CC6FF}',
    '.tlf-sez{margin:20px 0 10px;text-align:center;font:800 14px var(--font-body);color:inherit}',
    '.tlf-ore{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.tlf-ore label{display:flex;flex-direction:column;align-items:stretch;gap:5px;min-width:0;font:700 12.5px var(--font-body);color:#5B6B82;text-align:center}',
    'body.dark .tlf-ore label{color:#C9D7EC}',
    '.tlf-ore input{width:100%;min-width:0;box-sizing:border-box;padding:10px;border-radius:14px;border:1.5px solid #E1E8F2;background:#fff;color:#001E44;font:700 16px var(--font-body);text-align:center}',
    'body.dark .tlf-ore input{background:#0E2350;border-color:rgba(188,224,255,.3);color:#fff;color-scheme:dark}',
    '.tlf-cta{display:block;width:100%;min-height:50px;margin-top:14px;border:0;border-radius:25px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.tlf-via{display:block;margin:16px auto 0;padding:8px 14px;border:0;background:none;color:#E63946;font:800 14px var(--font-body);cursor:pointer}',
    'body.dark .tlf-via{color:#FF8A94}',
    '.tlf-nota{margin:12px 0 0;text-align:center;font:500 12.5px/1.5 var(--font-body);color:#5B6B82}body.dark .tlf-nota{color:#C9D7EC}',
    /* i valori dei momenti e delle ore: verde se migliora, rosso se peggiora */
    '.tlm-val.su,.tlx-carb.su{color:#1B9E6A}.tlm-val.giu,.tlx-carb.giu{color:#E63946}',

    /* ---- i momenti: la linea a sinistra, i punti distanziati, la scheda con l'immagine ---- */
    '.tlx-h{margin:30px 2px 14px;font:800 20px var(--font-display);color:var(--navy);text-align:center}body.dark .tlx-h{color:#fff}',
    '.tlm-lista{position:relative;padding-left:26px}',
    '.tlm-lista::before{content:"";position:absolute;left:8px;top:8px;bottom:8px;width:2px;border-radius:2px;background:var(--line)}',
    'body.dark .tlm-lista::before{background:#22345A}',
    '.tlm{position:relative;padding-bottom:30px}',
    '.tlm:last-child{padding-bottom:6px}',
    '.tlm-punto{position:absolute;left:-24px;top:3px;width:14px;height:14px;border-radius:50%;background:#0075E3;box-shadow:0 0 0 4px var(--bg,#F4F9FF)}',
    '.tlm-punto.su{background:#1B9E6A}.tlm-punto.giu{background:#E63946}',
    'body.dark .tlm-punto{box-shadow:0 0 0 4px #0B1220}',
    '.tlm-ora{margin:0;font:700 12.5px var(--font-body);color:var(--muted)}',
    '.tlm-frase{margin:4px 0 10px;font:700 15.5px/1.4 var(--font-body);color:var(--navy)}body.dark .tlm-frase{color:#fff}',
    '.tlm-card{display:flex;align-items:center;gap:14px;padding:14px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 6px 18px rgba(0,30,68,.06)}',
    'body.dark .tlm-card{background:#12203A;border-color:#22345A;box-shadow:none}',
    '.tlm-img{flex:none;width:64px;height:64px;border-radius:18px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#E3F1FF}',
    'body.dark .tlm-img{background:#0E2350}',
    '.tlm-app{background:transparent}body.dark .tlm-app{background:transparent}',
    '.tlm-pianta svg{width:58px;height:58px}.tlm-pianta.ok{background:rgba(27,158,106,.12)}.tlm-pianta.ko{background:rgba(230,57,70,.10)}',
    '.tlm-carb.su{background:#E3F1FF;color:#0075E3}.tlm-carb.giu{background:rgba(230,57,70,.12);color:#E63946}',
    '.tlm-em i{display:flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:50%;background:#fff;font-style:normal;font-size:24px}',
    '.tlm-em.giu{background:rgba(230,57,70,.12)}',
    '.tlm-t{flex:1;min-width:0;text-align:left}',
    '.tlm-t b{display:block;font:700 14px/1.4 var(--font-body);color:var(--navy);word-break:break-word;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}',
    'body.dark .tlm-t b{color:#fff}',
    '.tlm-t small{display:block;margin-top:4px;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.tlm-val{flex:none;font:900 16px var(--font-display);color:var(--navy);white-space:nowrap}body.dark .tlm-val{color:#fff}',
    'body.dark .tlm-val.su{color:#4CC98F}body.dark .tlm-val.giu{color:#FF7A85}',
    '.tlm-cond{display:flex;align-items:center;justify-content:center;gap:7px;margin:10px auto 0;padding:8px 16px;border-radius:99px;border:1.5px solid var(--line);',
      'background:var(--card,#fff);color:#0075E3;font:800 12.5px var(--font-body);cursor:pointer}',
    'body.dark .tlm-cond{background:rgba(255,255,255,.06);border-color:#2A3E66;color:#8CC6FF}',
    '.tlm-pag{display:flex;align-items:center;justify-content:center;gap:16px;margin:8px 0 0}',
    '.tlm-pag span{font:700 13px var(--font-body);color:var(--navy)}body.dark .tlm-pag span{color:#fff}',

    '.tlx-card{margin-top:14px;background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:16px}',
    'body.dark .tlx-card{background:#12203A;border-color:#22345A}',
    '.tlx-nota{margin:10px 0 0;font:500 12px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.tlx-nota.fuori{margin:-4px 2px 12px}',

    /* ---- ora per ora ---- */
    '.tlx-ore{display:flex;flex-direction:column;gap:8px}',
    '.tlx-ora{background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;overflow:hidden}',
    'body.dark .tlx-ora{background:#12203A;border-color:#22345A}',
    '.tlx-oh{display:flex;align-items:center;gap:10px;width:100%;padding:13px 16px;border:0;background:transparent;cursor:pointer;text-align:left;color:var(--navy)}',
    'body.dark .tlx-oh{color:#fff}',
    '.tlx-hh{flex:none;width:54px;font:800 16px var(--font-display);font-variant-numeric:tabular-nums}',
    '.tlx-ohm{flex:1;min-width:0;display:flex;flex-direction:column;gap:6px}',
    '.tlx-ohm small{font:600 12px var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.tlx-ohm small em{font-style:normal;color:#E63946}',
    '.tlx-obar{display:block;height:5px;border-radius:99px;background:var(--bg,#EEF2F8);overflow:hidden}',
    'body.dark .tlx-obar{background:rgba(255,255,255,.08)}',
    '.tlx-obar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#3F9FF4,#0075E3)}',
    '.tlx-carb{flex:none;font:800 12px var(--font-body);white-space:nowrap}body.dark .tlx-carb.su{color:#4CC98F}body.dark .tlx-carb.giu{color:#FF7A85}',
    '.tlx-ovita{flex:none;font-size:13px}',
    '.tlx-oin{display:none;padding:2px 16px 12px;border-top:1px solid var(--line)}body.dark .tlx-oin{border-color:#22345A}',
    '.tlx-ora.on .tlx-oin{display:block}',
    '.tlx-r{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)}body.dark .tlx-r{border-color:#22345A}',
    '.tlx-r:last-child{border-bottom:0}',
    '.tlx-t{flex:none;width:44px;font:700 12.5px var(--font-body);color:var(--muted);font-variant-numeric:tabular-nums}',
    '.tlx-nome{flex:1;min-width:0;font:600 14px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .tlx-nome{color:#fff}',
    '.tlx-r.due .tlx-nome{white-space:normal}',
    '.tlx-cosa{display:block;margin-top:2px;font:600 12px/1.35 var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.tlx-dur{flex:none;padding:3px 9px;border-radius:99px;background:var(--bg,#EEF2F8);font:700 12px var(--font-body);color:var(--navy)}',
    'body.dark .tlx-dur{background:rgba(255,255,255,.08);color:#fff}',
    '.tlx-dur.lampo{background:rgba(230,57,70,.10);color:#C42B38}',
    'body.dark .tlx-dur.lampo{background:rgba(230,57,70,.2);color:#FF8A94}',
    '.tlx-r.vita .tlx-t{color:var(--navy)}body.dark .tlx-r.vita .tlx-t{color:#fff}',
    '.tlx-vico{flex:none;width:26px;text-align:center;font-size:17px}',
    '.tlx-frase{flex:1;min-width:0;font:500 13.5px/1.45 var(--font-body);color:var(--navy)}body.dark .tlx-frase{color:#fff}',
    '.tlx-frase i{font-style:normal;color:#1B9E6A}',
    '.tlx-r.vita.rosso .tlx-frase{color:#E63946}',
    '.tlx-buco{margin:6px 0;padding:6px 12px;border-radius:99px;background:var(--bg,#EEF2F8);text-align:center;font:600 11.5px var(--font-body);color:var(--muted)}',
    'body.dark .tlx-buco{background:rgba(255,255,255,.06)}',
    '.tlx-r.dm .tlx-nome{white-space:normal;line-height:1.3}',
    '.tlx-r.dm .tlx-nome small{display:block;font:600 11px var(--font-body);color:var(--muted,#7A8AA3)}',
    '.tlx-dmc{display:inline-block;width:8px;height:8px;margin:0 6px 1px 0;border-radius:50%;vertical-align:middle}'
  ].join('');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   LA PORTA NEL REPORT: cosa trovi dentro, in una riga, e la giornata in piccolo
   --------------------------------------------------------------------------------------- */
function tlCardEntrata(off){
  off = Math.max(0, off || 0);
  /* 0.9.305, Andrea: "a sinistra c'e' un'immagine che sembra un codice a barre, la odio". Al suo posto un orologio con la
     freccia che torna indietro (la giornata riavvolta) e una lente sopra (si guarda da vicino), nel riquadro azzurro. */
  const ico = '<svg viewBox="0 0 40 40" width="38" height="38" aria-hidden="true" focusable="false">'
    + '<path d="M6 17A11 11 0 1 1 9.22 24.78" fill="none" stroke="#0075E3" stroke-width="2.8" stroke-linecap="round"/>'
    + '<path d="M2.6 13.9L6 17.5l3.4-3.6" fill="none" stroke="#0075E3" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>'
    + '<path d="M17 10.5V17l4.2 2.6" fill="none" stroke="#0075E3" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>'
    + '<circle cx="27.2" cy="27.2" r="6.4" fill="#fff" stroke="#E63946" stroke-width="2.8"/>'
    + '<path d="M31.8 31.8L36.4 36.4" stroke="#E63946" stroke-width="3.4" stroke-linecap="round"/>'
    + '</svg>';
  return '<button type="button" class="tl-entry" onclick="tlOpen(' + off + ')">'
    + '<span class="tl-e-art">' + ico + '</span>'
    + '<span class="tl-e-t"><b>Timeline</b>'
    +   '<small>Cosa hai fatto sul telefono, ora per ora: le app, i siti, le ricerche.</small></span>'
    + '<span class="chev"></span></button>';
}

(function tlEntryStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.tl-entry{display:flex;align-items:center;gap:14px;width:100%;margin-top:16px;padding:16px;text-align:left;',
      'background:var(--card,#fff);border:1px solid var(--line);border-radius:var(--r-md,18px);cursor:pointer;color:var(--navy)}',
    '.tl-e-art{display:flex;align-items:center;justify-content:center;width:56px;height:56px;flex:none;border-radius:16px;',
      'background:#E3F1FF}',
    '.tl-e-art svg{display:block}',
    '.tl-e-t{flex:1;min-width:0;display:block}',
    '.tl-e-t b{display:block;font:800 15px var(--font-display);color:var(--navy)}',
    '.tl-e-t small{display:block;margin-top:3px;font:500 12px/1.45 var(--font-body);color:var(--muted,#7A8AA3)}',
    'body.dark .tl-entry{background:#12203A;border-color:#22345A}',
    'body.dark .tl-e-t b{color:#fff}',
    'body.dark .tl-e-art{background:#E3F1FF}'
  ].join('');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '.tlr-arr{margin:4px 0 8px;text-align:center}.tlr-arr small{display:block;font:700 12px var(--font-body);color:var(--muted)}.tlr-arr b{display:block;margin-top:2px;font:800 22px var(--font-display);color:var(--navy)}body.dark .tlr-arr b{color:#fff}.tlr-g{margin:18px 0 8px;font:800 15px var(--font-display);color:var(--navy)}body.dark .tlr-g{color:#fff}/* 0.9.335: dentro al report scuro il bianco da subito: prima nasceva blu notte e la guardia del contrasto lo girava dopo, il lampo nero */.tlr .tlr-arr small{color:#BFD3EC}.tlr .tlr-arr b,.tlr .tlr-g{color:#fff}';
  /* 0.9.353, Andrea: "nel 0.9.351 hai reso scure le righe dei Ricalcoli (+17 ore, +5 ore): io volevo piu' scuro il FONDO del pannello".
     La regola .tlr .prc-r non c'e' piu': le righe tornano quelle di perche.js (chiare con il testo navy; in body.dark le sue).
     Il fondo scuro sta nel gradiente di .pst.tlr, con gli stop in px. */
  document.head.appendChild(st);
})();
