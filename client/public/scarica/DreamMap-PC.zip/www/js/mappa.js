/* ===========================================================================================
   LA MAPPA DEL VIAGGIO — da dove sei a dove hai detto di voler arrivare

   Il Genio ti dice due cose: chi sei diventando oggi (il profilo) e chi volevi diventare (il
   traguardo che hai scelto tu davanti alla sfera). Fra quelle due cose c'è una distanza, e
   finora quella distanza era un numero — «hai il 30% di probabilità» — cioè la cosa meno utile
   che si possa dire a qualcuno che vuole muoversi.

   Un numero non si percorre. Una mappa sì.

   PERCHÉ STILIZZATA E NON IL MONDO VERO. Una mappa del mondo con l'America in fondo sarebbe
   bellissima per una settimana e poi sbagliata per sempre: il viaggio di cui parla questa app
   non è geografico, e chi vuole «rimettersi in forma» non sta andando in nessun posto sulla
   carta. Un sentiero disegnato invece funziona per qualsiasi traguardo — è la mappa di un gioco
   in cui le tappe sono le tue, e la bandierina in cima ha il nome che hai scelto tu.

   LE TAPPE NON LE INVENTA LA MAPPA. Sono le stesse che il Genio calcola nel piano
   (orBuildPlan): quello che è già acceso è tappa superata, quello che manca è strada. Se la
   mappa e il piano dicessero due cose diverse, la mappa sarebbe un disegno.
   =========================================================================================== */

let MP_TAPPE = null;

/* ---------------------------------------------------------------------------------------
   L'ORIZZONTE CHE SI STA GUARDANDO

   La mappa di serie mostra le tre mosse che il Genio consiglia adesso: giuste, ma sempre le
   stesse tre, e tutte a distanza di una settimana. Quando invece si vuole vedere la strada per
   il mese, per l'anno o per i cinque anni, le tappe sono i passi che hai scritto tu in quel
   livello — gli orizzonti di Keller — e la mappa diventa quella di quel pezzo di viaggio.

   «Il Genio» resta l'impostazione di partenza: è l'unica che ha qualcosa da dire il primo
   giorno, quando nessun orizzonte è ancora stato scritto.
   --------------------------------------------------------------------------------------- */

const MP_ORIZZONTI = [
  ['genio', 'Le mosse del Genio'],
  ['settimana', 'Questa settimana'],
  ['mese', 'Questo mese'],
  ['anno', 'Quest\'anno'],
  ['cinque', 'Fra cinque anni'],
  ['ungiorno', 'Un giorno']
];

/* ---------------------------------------------------------------------------------------
   LE DUE VISTE DELLA STESSA MAPPA
   Prima c'erano due mappe una sotto l'altra: la cartina del mondo con l'aereo e il sentiero
   disegnato con le tappe. Sono la stessa domanda — dove sono, quanto manca — vista da due
   altezze. Adesso e' una sezione sola: il sentiero di serie, e un pulsante con il satellite
   che passa alla cartina, con le stesse tappe distribuite sull'oceano e il tempo che resta.
   --------------------------------------------------------------------------------------- */
function mpVista(){
  try{ return localStorage.getItem('fl_mp_vista') === 'globo' ? 'globo' : 'disegno'; }catch(_){ return 'disegno'; }
}
function mpToggleVista(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const nuova = mpVista() === 'globo' ? 'disegno' : 'globo';
  if (nuova === 'globo' && (typeof rtStato !== 'function' || !rtStato().a)){
    if (typeof toast === 'function') toast('Prima scegli una destinazione');
    if (typeof rtApriCerca === 'function') rtApriCerca('a');
    return;
  }
  try{ localStorage.setItem('fl_mp_vista', nuova); }catch(_){ }
  mpPaint();
  /* la pagina grande si ridisegna AL SUO POSTO: chiuderla e riaprirla la riportava in cima e
     aggiungeva ogni volta un passo alla cronologia del tasto indietro */
  mpFullRidisegna();
}
function mpVistaBtn(cls){
  const globo = mpVista() === 'globo';
  const sat = (typeof rtStato === 'function') && rtStato().strato === 'satellite';
  return '<button type="button" class="mp-vista ' + (cls || '') + '" onclick="mpToggleVista(event)" '
    + 'aria-label="' + (globo ? 'Vedi il sentiero' : 'Vedi la mappa del mondo') + '">' + (globo ? '\ud83d\uddfa\ufe0f' : '\ud83d\udef0\ufe0f') + '</button>'
    /* nella vista globo, un secondo pulsante: satellite o mappa a due colori */
    + (globo ? '<button type="button" class="mp-vista mp-strato ' + (cls || '') + '" onclick="mpToggleStrato(event)" '
        + 'aria-label="' + RT_STRATI[rtStratoDopo(rtStato().strato)].nome + '">' + RT_STRATI[rtStratoDopo(rtStato().strato)].ico + '</button>' : '');
}
function mpToggleStrato(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (typeof rtToggleStrato === 'function') rtToggleStrato(ev);
  mpPaint();
  mpFullRidisegna();
  mpSlideRidisegna();
}
/* UN PULSANTE SOLO NELLA PAGINA GRANDE (0.9.228): prima ce n'erano due, il satellite e la
   cartina del sentiero, e sembravano la stessa cosa. Adesso uno: passa dalla mappa al satellite
   e ritorno, e l'icona mostra dove porta. Se la pagina mostra ancora il sentiero disegnato, lo
   stesso pulsante apre la cartina. */
function mpFullStrato(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (mpVista() !== 'globo'){ mpToggleVista(); return; }
  mpToggleStrato();
}
function mpStratoBtn(){
  const globo = mpVista() === 'globo';
  const dopo = (typeof rtStato === 'function' && typeof rtStratoDopo === 'function') ? rtStratoDopo(rtStato().strato) : 'satellite';
  const ico = !globo ? '🛰️' : RT_STRATI[dopo].ico;
  const lab = !globo ? 'Vedi la cartina' : 'Passa a: ' + RT_STRATI[dopo].nome;
  return '<button type="button" class="mpf-btn mpf-strato" onclick="mpFullStrato(event)" aria-label="' + lab + '" title="' + lab + '">' + ico + '</button>';
}
/* La cartina della Mappa (blkhero.js) non si ridisegna se la sua «firma» non cambia, e lo strato
   non fa parte della firma: si cancella, cosi' anche li' si vede il satellite o la mappa scelti. */
function mpSlideRidisegna(){
  const g = document.getElementById('sevGlobo');
  if (!g || typeof sevGloboPaint !== 'function') return;
  try{ delete g.dataset.firma; sevGloboPaint(); }catch(_){ }
}
/** Il corpo della vista globo: la cartina, le tappe sull'arco, e quanto manca. */
function mpGloboHtml(grande){
  const s = (typeof rtStato === 'function') ? rtStato() : null;
  if (!s || !s.da || !s.a) return '<p class="life-sub" style="color:#cfe0ff">Se il tuo sogno ha un luogo nel mondo, sceglilo: qui vedrai la rotta.</p>';
  const km = (typeof rtKm === 'function') ? rtKm(s.da, s.a) : 0;
  const f = (typeof rtProgresso === 'function') ? rtProgresso() : 0;
  return '<div class="mp-globo' + (grande ? ' big' : '') + '" id="' + (grande ? 'mpGloboFull' : 'mpGlobo') + '"></div>'
    + '<div class="mp-globo-hud">'
    /* i nomi nell'ordine della mappa: a sinistra chi ha la longitudine minore, come i punti */
    +   (function(){ const sx = (+s.da.lon <= +s.a.lon) ? s.da : s.a, dx = sx === s.da ? s.a : s.da;
          return '<span>' + esc(String(sx.nome).split(',')[0]) + '</span><i>' + km.toLocaleString('it-IT') + ' km</i><span>' + esc(String(dx.nome).split(',')[0]) + '</span>'; })()
    + '</div>'
    + '<p class="mp-globo-t">' + mpPercHtml() + '</p>';
}
/* LA PERCENTUALE SCRITTA E' QUELLA VERA (0.9.189), la stessa della slide dell'arrivo in Dream.
   rtProgresso() la tiene almeno al 2% perche' l'aereo non stia sopra al punto di partenza: e'
   una misura per il disegno. Scritta sotto la cartina diceva «2%» mentre Dream diceva «0,0%». */
function mpPctVera(){ return (typeof flPercorso === 'function') ? flPercorso() : 0; }
/* UNA PERCENTUALE SOLA (0.9.203): quella dell'intestazione (tappe + strada), anche qui sotto
   la cartina. Prima qui c'era solo la strada e in alto il totale: «18%» contro «0,0%». */
function mpPercHtml(f){
  let v = f;
  try{ if (typeof hdPercorso === 'function') v = hdPercorso().pct; }catch(_){ }
  if (v == null) v = mpPctVera();
  return '<b>' + mpPercTxt(v) + '%</b> del percorso';
}
/** La percentuale del percorso: intera (2%) o con un decimale (2,6%), come nelle opzioni. */
function mpPercTxt(f){
  let dec = false;
  try{ dec = (typeof serOpzioni === 'function') && serOpzioni().pctDec === true; }catch(_){ }
  const v = f * 100;
  return dec ? v.toFixed(1).replace('.', ',') : String(Math.round(v));
}
/* SI DIPINGONO TUTTE E DUE. La card e la mappa grande avevano lo stesso id, e
   getElementById trova sempre la prima: la grande restava vuota, con i nomi in fila. */
function mpPaintGlobo(){
  if (typeof rtMappaHtml !== 'function') return;
  const s = rtStato();
  if (!s.da || !s.a) return;
  ['mpGlobo', 'mpGloboFull'].forEach(function(id){
    const box = document.getElementById(id);
    if (!box) return;
    const L = Math.max(200, Math.round(box.clientWidth || 340));
    const H = Math.max(160, Math.round(box.clientHeight || 220));
    box.innerHTML = rtMappaHtml(s.da, s.a, s.strato, L, H, MP_TAPPE || []);
  });
}

/**
 * IL PANNELLO DELL'ARRIVO, come in MyFutureSelf: una riga sopra, la data grande sotto, tutto
 * centrato, e basta. Prima la data stava in grassetto dentro a una frase, in mezzo ad altre
 * tre: aveva lo stesso peso di tutto il resto, cioe' nessuno.
 */
function mpArrivoPannello(){
  /* il pannello e' del navigatore (eta.js): data, conto alla rovescia, bollino «rispetto a ieri» */
  if (typeof etaCardHtml === 'function'){ try{ return etaCardHtml(); }catch(_){ return ''; } }
  return '';
}
/* Il conto alla rovescia scende da solo, ogni minuto, su ogni pannello a schermo; la
   posizione dell'aereo si ridisegna ogni mezz'ora (in un minuto non si sposta di un pixel). */
let MP_CONTO_T = 0, MP_AEREO_T = 0;
function mpContoVivo(){
  if (MP_CONTO_T) return;
  MP_CONTO_T = setInterval(function(){
    const el = document.querySelectorAll('.mp-arrivo-cd');
    const grande = document.querySelectorAll('.mpf-conto');
    if (!el.length && !grande.length){ clearInterval(MP_CONTO_T); MP_CONTO_T = 0; return; }
    el.forEach(function(e){ const at = +e.dataset.at; if (at && typeof serContoRovescia === 'function') e.textContent = serContoRovescia(at, e.dataset.modo || undefined); });
    grande.forEach(function(e){ const at = +e.dataset.at; if (at) e.textContent = mpContoTxt(at, e.dataset.modo || undefined); });
  }, 60000);
  if (!MP_AEREO_T) MP_AEREO_T = setInterval(function(){ if (!document.hidden) mpPaintGlobo(); }, 30 * 60000);
}
/** La spiegazione, in un foglio: cosa vuol dire la data, e perche' l'aereo si muove col tempo. */
function mpSpiega(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const w = document.getElementById('mpSheet');
  if (!w) return;
  const T = function(k, d){ const x = (typeof etaT === 'function') ? etaT(k) : ''; return x || d; };
  w.innerHTML = '<div class="mp-sheet-in">'
    + '<div class="mp-sico">✈️</div>'
    + '<h3>' + T('spiega.titolo', 'Come si legge l’arrivo') + '</h3>'
    + '<p>' + T('spiega.p1', 'La data è una stima: dove arrivi se il passo resta quello dei tuoi giorni veri.') + '</p>'
    + '<p>' + T('spiega.p2', 'Si ricalcola a ogni cosa che chiudi. Il bollino sotto dice di quanto si è mossa rispetto a ieri.') + '</p>'
    + '<p>' + T('spiega.p3', 'L’aereo segna quanto manca. Tocca la data per l’intervallo, il bollino per la Timeline.') + '</p>'
    + '<button type="button" class="cta mp-sec" onclick="mpApriTimeline()">' + T('intervallo.timeline', 'Apri la Timeline del viaggio') + '</button>'
    + '<button type="button" class="cta mp-sec" onclick="mpOpzioniApri()">' + flIngranaggio(18) + ' ' + String(T('spiega.opzioni', 'Opzioni di viaggio')).replace(/^\u2699\ufe0f?\s*/, '') + '</button>'
    + '<button type="button" class="cta" onclick="mpSheetClose()">' + T('intervallo.ok', 'Ho capito') + '</button>'
    + '</div>';
  w.hidden = false;
}
function mpApriTimeline(){ mpSheetClose(); if (typeof etaTimelineApri === 'function') etaTimelineApri(); }
/** Le opzioni di viaggio: pedaggi, budget, capitale. Restano sul dispositivo. */
/* ---------------------------------------------------------------------------------------
   LE OPZIONI DI VIAGGIO — una PAGINA.

   Erano un foglio che si alzava dal basso. Un foglio va bene per una domanda sola; qui ce ne
   sono cinque, due aprono un'altra schermata (partenza e destinazione) e da quella si deve
   poter tornare indietro. Un foglio non ha un indietro: quando si tornava dalla ricerca, il
   foglio non c'era piu' e ci si ritrovava sulla Roadmap senza aver chiesto niente.
   --------------------------------------------------------------------------------------- */
registerScreen('s-viaggio-opz', '<div class="topbar"><button class="iconbtn" onclick="mpOpzIndietro()">\u2039</button>'
  + '<b class="blk-title">Opzioni di viaggio</b></div>'
  + '<div class="mp-opz mp-opz-pg" id="mpOpzBody"></div>'
  + '<div class="spacer"></div>', { back: function(){ mpOpzioniSalva(true); return 's-home'; } });

function mpOpzioniApri(){
  mpMenuClose();
  mpSheetClose();
  if (document.getElementById('mpFull')) mpClose();
  goId('s-viaggio-opz');
  mpOpzPaint();
}
function mpOpzIndietro(){
  mpOpzioniSalva(true);
  goId('s-home');
  if (typeof switchTab === 'function') switchTab('mappa');
}

function mpOpzPaint(){
  const w = document.getElementById('mpOpzBody');
  if (!w || typeof serOpzioni !== 'function') return;
  const o = serOpzioni();
  const prec = (typeof etaPrecisione === 'function') ? etaPrecisione() : (o.precisione === 'semplice' ? 'semplice' : 'precisa');
  const rt = mpRottaDaA();
  const sim = (typeof flSimbolo === 'function') ? flSimbolo() : '\u20ac';
  w.innerHTML =
    /* 0.9.323, Andrea: "troppe sezioni attaccate". Quattro blocchi con il titolo: il viaggio, il tempo, come vedi l'arrivo, le scorciatoie */
      '<h3 class="mpz-t"><span aria-hidden="true">🗺️</span>Il tuo viaggio</h3><div class="mpz-c">'
    + '<div class="mp-opz-r"><div><b>Partenza</b><small>' + esc(rt.da || 'Non impostata') + '</small></div>'
    +   '<button type="button" class="ghostmini" onclick="mpOpzioniRotta(\'da\')">Cambia</button></div>'
    + '<div class="mp-opz-r"><div><b>Destinazione</b><small>' + esc(rt.a || 'Non impostata') + '</small></div>'
    +   '<button type="button" class="ghostmini" onclick="mpOpzioniRotta(\'a\')">Cambia</button></div>'
    + '</div>'
    /* le ore a settimana, i giorni di lavoro e l'imprevisto: del navigatore */
    + '<h3 class="mpz-t"><span aria-hidden="true">⏳</span>Il tuo tempo</h3><div class="mpz-c">' + ((typeof etaOpzHtml === 'function') ? etaOpzHtml(o) : '') + '</div>'
    /* la precisione dell'arrivo, PRIMA dei pedaggi: tre gradi, e cambiarli non tocca la stima */
    /* 0.9.342: la percentuale della bolla 🧭 in alto, con la stessa emoji (era nella pagina della partenza) */
    + (typeof mpOpzPercHtml === 'function' ? '<h3 class="mpz-t"><span aria-hidden="true">🧭</span>La percentuale del viaggio</h3><div class="mpz-c">' + mpOpzPercHtml() + '</div>' : '')
    + '<h3 class="mpz-t"><span aria-hidden="true">🎯</span>Come vedi l’arrivo</h3><div class="mpz-c">'
    + '<div class="mp-opz-r"><div><b>' + mpOpzT('opz.arrivo', 'Precisione') + '</b><small id="mpOpzPrecTxt">' + mpOpzPrecDesc(prec) + '</small></div></div>'
    + '<div class="mp-seg mp-seg3" id="mpOpzPrec">' + ['semplice', 'precisa', 'dettagliata'].map(function(v){ return '<button type="button" class="' + (prec === v ? 'on' : '') + '" data-v="' + v + '" onclick="mpOpzPrecisione(this)">' + mpOpzT('opz.prec.' + v, v) + '</button>'; }).join('') + '</div>'
    /* la percentuale del percorso: intera o con un decimale */
    + '<div class="mp-opz-r"><div><b>Percentuale</b><small>' + (o.pctDec ? 'Con un decimale: 2,6%.' : 'Arrotondata: 3%.') + '</small></div>'
    +   '<div class="mp-seg" id="mpOpzPct"><button type="button" class="' + (o.pctDec ? '' : 'on') + '" data-v="intera" onclick="mpOpzPct(this)">3%</button><button type="button" class="' + (o.pctDec ? 'on' : '') + '" data-v="dec" onclick="mpOpzPct(this)">2,6%</button></div></div>'
    + '</div>'
    /* i pedaggi: la spiegazione sta qui, non nel cartello dell'arrivo */
    + '<h3 class="mpz-t"><span aria-hidden="true">⚡</span>Le scorciatoie</h3><div class="mpz-c">'
    + '<label class="mp-opz-r"><div><b>Compra tempo</b><small>Il Genio ti propone software, strumenti o persone che avvicinano l’arrivo.</small></div>'
    +   '<button type="button" class="switch' + (o.pedaggi ? ' on' : '') + '" onclick="this.classList.toggle(\'on\');mpOpzPedaggiMostra()" id="mpOpzPed"></button></label>'
    /* budget, capitale e nota compaiono solo con i pedaggi accesi */
    + '<div id="mpOpzPedBox"' + (o.pedaggi ? '' : ' hidden') + '>'
    + '<label class="mp-opz-r"><div><b>Budget massimo</b><small>Quanto sei disposto a spendere per andare pi\u00f9 in fretta.</small></div>'
    +   '<input type="number" inputmode="numeric" id="mpOpzBudget" value="' + (o.budget || '') + '" placeholder="' + esc(sim) + '"></label>'
    + '<label class="mp-opz-r"><div><b>Capitale attuale</b><small>Quello che hai adesso, in tutto.</small></div>'
    +   '<input type="number" inputmode="numeric" id="mpOpzCap" value="' + (o.capitale || '') + '" placeholder="' + esc(sim) + '"></label>'
    + '<p class="mp-opz-nota">Restano su questo dispositivo. Servono al Genio per proporti la via pi\u00f9 veloce che ti puoi permettere.</p>'
    + '</div></div>'
    + '<button type="button" class="cta mpz-salva" onclick="mpOpzioniSalva()">Salva</button>';
}
/* Il pulsante dei pedaggi mostra o nasconde budget, capitale e nota, subito, senza salvare. */
function mpOpzPedaggiMostra(){
  const sw = document.getElementById('mpOpzPed'), box = document.getElementById('mpOpzPedBox');
  if (sw && box) box.hidden = !sw.classList.contains('on');
}
function mpOpzPct(btn){
  const seg = btn.parentNode;
  Array.prototype.forEach.call(seg.children, function(b){ b.classList.toggle('on', b === btn); });
  const small = seg.parentNode.querySelector('small');
  if (small) small.textContent = btn.dataset.v === 'dec' ? 'Con un decimale: 2,6%.' : 'Arrotondata: 3%.';
}
function mpOpzT(k, d){ const x = (typeof etaT === 'function') ? etaT(k) : ''; return x || d; }
function mpOpzPrecDesc(v){
  const d = { semplice: 'Mese e anno. Il conto in anni e mesi.', precisa: 'Il giorno. Il conto in anni, mesi e giorni.', dettagliata: 'Il giorno, e il conto fino al minuto.' };
  return mpOpzT('opz.prec.desc' + String(v).charAt(0).toUpperCase() + String(v).slice(1), d[v] || '');
}
function mpOpzPrecisione(btn){
  const seg = btn.parentNode;
  Array.prototype.forEach.call(seg.children, function(b){ b.classList.toggle('on', b === btn); });
  const small = document.getElementById('mpOpzPrecTxt');
  if (small) small.textContent = mpOpzPrecDesc(btn.dataset.v);
}
/* La partenza e la destinazione della rotta, come le tiene il navigatore. */
function mpRottaDaA(){
  let da = '', a = '';
  const nome = x => x ? (typeof x === 'string' ? x : (x.nome || x.n || x.name || x.city || '')) : '';
  try{ const s = (typeof rtStato === 'function') ? rtStato() : null; if (s){ da = nome(s.da); a = nome(s.a); } }catch(_){ }
  if (!da || !a){ try{ const r = JSON.parse(localStorage.getItem('fl_rotta') || 'null'); if (r){ da = da || nome(r.da); a = a || nome(r.a); } }catch(_){ } }
  return { da: da, a: a };
}
/* Cambiare partenza o destinazione: si salva quello che c'e' e si apre la ricerca del
   navigatore, LASCIANDOLE DETTO DA DOVE SI ARRIVA: e' quello che riporta qui, sia con il
   pulsante indietro sia dopo aver scelto una citta'. */
function mpOpzioniRotta(quale){
  mpOpzioniSalva(true);
  if (typeof rtRitorno === 'function') rtRitorno('s-viaggio-opz');
  if (typeof rtApriCerca === 'function') rtApriCerca(quale);
}
function mpOpzioniSalva(silenzioso){
  const ped = !!(document.getElementById('mpOpzPed') && document.getElementById('mpOpzPed').classList.contains('on'));
  const b = parseFloat((document.getElementById('mpOpzBudget') || {}).value) || 0;
  const c = parseFloat((document.getElementById('mpOpzCap') || {}).value) || 0;
  const precBtn = document.querySelector('#mpOpzPrec .on');
  const prec = (precBtn && precBtn.dataset.v) || 'precisa';
  /* Il foglio non c'e' piu': se la pagina non e' a schermo non c'e' niente da leggere e
     soprattutto niente da sovrascrivere con degli zeri. */
  const pctBtn = document.querySelector('#mpOpzPct .on');
  if (document.getElementById('mpOpzPrec') && typeof serOpzioniSalva === 'function'){
    serOpzioniSalva({ pedaggi: ped, budget: b, capitale: c, precisione: prec, pctDec: !!(pctBtn && pctBtn.dataset.v === 'dec') });
    /* le ore e i giorni del piano: se cambiano, il navigatore ricalcola e lo scrive nel registro */
    if (typeof etaOpzSalva === 'function') try{ etaOpzSalva(); }catch(_){ }
  }
  if (silenzioso === true) return;
  goId('s-home');
  if (typeof switchTab === 'function') switchTab('mappa');
  mpPaint();
  if (typeof sevGloboPaint === 'function') try{ sevGloboPaint(); }catch(_){ }
  if (typeof toast === 'function') toast(ped ? 'Pedaggi attivi: si arriva prima' : 'Opzioni salvate');
}

function mpOrizzonte(){
  try{ const v = localStorage.getItem('fl_mp_oz'); return v || 'genio'; }catch(_){ return 'genio'; }
}

async function mpSetOrizzonte(v){
  try{ localStorage.setItem('fl_mp_oz', v); }catch(_){ }
  mpMenuClose();

  /* L'ORDINE QUI E' TUTTO.
     mpPaint e' asincrona perche' le tappe di un orizzonte vanno lette (e per «Le mosse del
     Genio» addirittura ricalcolate). Senza questo `await` il codice proseguiva subito e
     ridisegnava la mappa grande leggendo MP_TAPPE ANCORA VECCHIO: si vedevano le bandierine
     dell'orizzonte precedente, e un istante dopo MP_TAPPE cambiava sotto ai piedi — quelle
     bandierine restavano a schermo puntando a un elenco che non le conteneva piu', e toccarle
     non apriva niente. Erano due difetti diversi con la stessa riga come colpevole. */
  await mpPaint();
  /* MP_TAPPE e' gia' quello nuovo: la pagina grande si ridisegna al suo posto */
  if (!document.getElementById('scMap')) MP_TAPPE = await mpTappeDi();
  mpFullRidisegna();
}

function mpOrizzonteNome(){
  const v = mpOrizzonte();
  return (MP_ORIZZONTI.filter(function(x){ return x[0] === v; })[0] || MP_ORIZZONTI[0])[1];
}

/** Le tappe da disegnare: quelle del Genio, oppure i passi non fatti dell'orizzonte scelto. */
async function mpTappeDi(){
  const v = mpOrizzonte();
  if (v === 'genio'){
    return (typeof orBuildPlan === 'function') ? await orBuildPlan() : [];
  }
  if (typeof ozAnello !== 'function') return [];
  const a = ozAnello(v);
  return (a.passi || []).filter(function(x){ return !x.fatto; }).slice(0, 6).map(function(x){
    return { ico: '\ud83d\udccd', t: x.t, s: 'Un passo verso "' + (ozTesto(v) || mpOrizzonteNome()) + '".', go: 'ozOpen()' };
  });
}

function mpMenuClose(){
  const m = document.getElementById('mpMenu');
  if (m) m.remove();
  const v = document.getElementById('mpVeil');
  if (v) v.remove();
}

function mpMenuOpen(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('mpMenu')){ mpMenuClose(); return; }
  const box = document.getElementById('mpFull') || document.getElementById('scMap');
  if (!box) return;
  const veil = document.createElement('div');
  veil.id = 'mpVeil';
  veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); mpMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(veil);
  const m = document.createElement('div');
  m.className = 'arb-menu';
  m.id = 'mpMenu';
  m.innerHTML = '<p class="arb-mtit">Quali passi vedere sulla mappa</p>'
    + MP_ORIZZONTI.map(function(o){
        return '<button type="button" class="' + (o[0] === mpOrizzonte() ? 'on' : '') + '" '
          + 'onclick="mpSetOrizzonte(\'' + o[0] + '\')">' + o[1] + '</button>';
      }).join('')
    + '<p class="arb-mtit">Il viaggio</p>'
    + '<button type="button" onclick="mpOpzioniApri()">\u2699\ufe0f Opzioni di viaggio</button>'
    + '<p class="arb-mtit">Il piano</p>'
    /* mpClose() e non solo mpMenuClose(): la mappa a tutto schermo e' un pannello fisso sopra a
       tutto, e cambiare schermata mentre resta li' non si vede — sembra che l'app si sia
       piantata. Chi va altrove chiude quello che stava guardando. */
    + '<button type="button" onclick="mpClose();ozOpen()">Apri gli orizzonti \u203a</button>';
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.mp-dots-full, .mp-dots'));
}

/** Il punto di partenza: chi il Genio dice che stai diventando oggi. */
function mpPartenza(){
  const last = (typeof orLast === 'function') ? orLast() : null;
  if (!last) return null;
  const p = (typeof orProfile === 'function') ? orProfile(last.profile) : null;
  return { ico: (p && p.ico) || '🧭', nome: (p && p.name) || 'Dove sei oggi', pct: last.pct || 0 };
}

/** L'arrivo: il traguardo scelto davanti alla sfera. */
function mpArrivo(){
  const last = (typeof orLast === 'function') ? orLast() : null;
  if (!last) return null;
  const t = (typeof OR_TARGETS !== 'undefined')
    ? OR_TARGETS.filter(function(x){ return x.id === last.target; })[0] : null;
  /* 0.9.337, Andrea: "il sogno non e' Chi costruisce qualcosa di suo, quella era l'identita': e' quello che ho detto al Genio nell'intro" */
  let sogno = String(last.sogno || '').trim();
  try{ if (!sogno && typeof gnDati === 'function') sogno = String(gnDati().sogno || '').trim(); }catch(_){ }
  if (sogno) sogno = sogno.charAt(0).toUpperCase() + sogno.slice(1);
  return { ico: (t && t.ico) || '🏁', nome: sogno || (t && t.name) || 'Dove vuoi arrivare' };
}

/* ---------------------------------------------------------------------------------------
   Il sentiero

   Una linea che sale a zig-zag, come il percorso di un livello: le tappe stanno sui suoi
   gomiti, alternate a sinistra e a destra, e la parte già fatta è continua mentre quella che
   manca è tratteggiata. È tutta la grammatica che serve — dove sono, quanto manca.
   --------------------------------------------------------------------------------------- */

function mpNodi(n){
  /* n tappe fra partenza e arrivo: in tutto n+2 punti, dal basso verso l'alto. */
  const tot = n + 2;
  const out = [];
  for (let i = 0; i < tot; i++){
    const t = i / (tot - 1);
    out.push({
      x: 50 + Math.sin(i * 1.15) * 27,        // il serpente: ampio abbastanza da vedersi
      y: 92 - t * 84                          // dal basso (92) alla cima (8)
    });
  }
  return out;
}

function mpNodiOrizz(n){
  const tot = n + 2, out = [];
  for (let i = 0; i < tot; i++){
    const t = i / (tot - 1);
    out.push({ x: 9 + t * 82, y: 50 + Math.sin(i * 1.15 + .4) * 11 });
  }
  return out;
}
function mpPath(nodi, da, a){
  let d = '';
  for (let i = da; i <= a && i < nodi.length; i++){
    const p = nodi[i];
    if (i === da) d += 'M' + p.x.toFixed(1) + ' ' + p.y.toFixed(1);
    else {
      const q = nodi[i - 1];
      const mx = (p.x + q.x) / 2;
      d += ' C' + mx.toFixed(1) + ' ' + q.y.toFixed(1) + ' ' + mx.toFixed(1) + ' ' + p.y.toFixed(1)
         + ' ' + p.x.toFixed(1) + ' ' + p.y.toFixed(1);
    }
  }
  return d;
}

function mpSvg(tappe, grande, orizzontale){
  const part = mpPartenza(), arr = mpArrivo();
  /* 0.9.292, Andrea: "le mosse in orizzontale, cosi' non finiscono sopra al testo": nel riquadro basso il sentiero va
     da sinistra a destra, lontano dall'etichetta in alto e da "Tocca per aprire" in basso */
  const nodi = orizzontale ? mpNodiOrizz(tappe.length) : mpNodi(tappe.length);
  /* Fatto = le tappe che il piano non propone più, perché quella cosa è già attiva. Il piano
     restituisce solo quello che manca, quindi il punto in cui sei è sempre il primo nodo. */
  const fatte = 0;

  const scia = '<path d="' + mpPath(nodi, 0, fatte) + '" class="mp-line done"/>'
    + '<path d="' + mpPath(nodi, fatte, nodi.length - 1) + '" class="mp-line todo"/>';

  const punti = nodi.map(function(p, i){
    if (i === 0){
      return '<g class="mp-node start" transform="translate(' + p.x + ' ' + p.y + ')">'
        + '<circle r="7.2"/><circle class="mp-halo" r="5.2"/><text y="0.4">' + ((part && part.ico) || '🧭') + '</text></g>';
    }
    if (i === nodi.length - 1){
      return '<g class="mp-node end" transform="translate(' + p.x + ' ' + p.y + ')">'
        + '<circle r="8"/><circle class="mp-halo" r="5.8"/><text y="0.4">' + ((arr && arr.ico) || '🏁') + '</text></g>';
    }
    const t = tappe[i - 1] || {};
    /* `event` passato a mano: la scheda intorno alla mappa ha un suo onclick che apre la mappa
       grande, e senza fermare la risalita il tocco su una bandierina faceva DUE cose — apriva il
       foglietto e subito dopo la mappa a tutto schermo. */
    /* IL NUMERO. Il sentiero sale dal basso, ma una pagina si legge dall'alto: senza un
       numero la prima tappa sembra l'ultima. Piccolo, in alto a destra del nodo. */
    return '<g class="mp-node step' + (t.sbiadita ? ' sbiadita' : '') + (t.prossima ? ' prossima' : '') + '" transform="translate(' + p.x + ' ' + p.y + ')" '
      + 'onclick="mpTappa(' + (i - 1) + ',event)" role="button">'
      + '<circle r="6.4"/><text y="0.4">' + (t.ico || '•') + '</text>'
      + '<g class="mp-num" transform="translate(5.4 -5.4)"><circle r="3.4"/><text y="1.3">' + i + '</text></g></g>';
  }).join('');

  return '<svg class="mp-svg' + (grande ? ' big' : '') + '" viewBox="' + (orizzontale ? '0 22 100 56' : '0 0 100 100') + '" preserveAspectRatio="xMidYMid meet">'
    + '<defs><pattern id="mpGrid" width="10" height="10" patternUnits="userSpaceOnUse">'
    +   '<path d="M10 0H0V10" fill="none" stroke="rgba(255,255,255,.055)" stroke-width=".6"/></pattern></defs>'
    + '<rect width="100" height="100" fill="url(#mpGrid)"/>'
    + scia + punti + '</svg>';
}

/* ---------------------------------------------------------------------------------------
   Il pannello
   --------------------------------------------------------------------------------------- */

/* Quale ridisegno e' l'ultimo chiesto.
   mpPaint viene invocata da piu' parti (l'evento fl:tab con 300ms di ritardo, il cambio di
   orizzonte, il ritorno dal Genio) e in mezzo ha un await che per «Le mosse del Genio» arriva
   fino al motore nativo. Due ridisegni sovrapposti possono finire in ordine inverso e lasciare
   a schermo la mappa piu' vecchia — con MP_TAPPE della piu' nuova, che e' esattamente la
   condizione in cui toccare una bandierina non apre niente. */
let MP_TICK = 0;

async function mpPaint(){
  const el = document.getElementById('scMap');
  if (!el) return;
  const mio = ++MP_TICK;

  const part = mpPartenza(), arr = mpArrivo();
  if (!part || !arr){
    /* SENZA LA LETTURA DEL GENIO NON C'E' NE' PARTENZA NE' ARRIVO.
       All'inizio qui non compariva niente, e nascondere una sezione non e' la stessa cosa che
       spiegarla: dal punto di vista di chi scorre la pagina, una sezione che non c'e' e' una
       sezione che non e' stata fatta. Adesso c'e' la mappa piegata, con scritto cosa la apre. */
    el.innerHTML = '<div class="sev-intro mp-intro"><div class="sev-intro-ic">🗺️</div>'
      + '<h2>La tua mappa</h2></div>'
      + '<p class="life-sub">Il sentiero da dove sei oggi a dove vuoi arrivare, con le tappe '
      + 'segnate dal Genio.</p>'
      + '<div class="mp-card mp-vuota" onclick="mpChiediLettura()">'
      +   '<div class="mp-piegata">🗺️</div>'
      +   '<p>La mappa si disegna da sola quando il Genio sa due cose: <b>chi stai diventando</b> '
      +     'e <b>dove vuoi arrivare</b>. Gliele dici rispondendo alle sue domande, qui sopra.</p>'
      +   '<div class="mp-open">Fai la lettura ›</div>'
      + '</div>';
    return;
  }

  const tappe = await mpTappeDi();
  if (mio !== MP_TICK) return;      // un altro ridisegno e' partito dopo: comanda lui
  MP_TAPPE = tappe;
  const oz = mpOrizzonte();
  const eta = (typeof ozStimaTxt === 'function') ? ozStimaTxt(oz) : '';

  el.innerHTML = '<div class="sev-intro mp-intro"><div class="sev-intro-ic">🗺️</div>'
    + '<h2>La tua mappa</h2></div>'
    + '<p class="life-sub">Da dove sei oggi a dove hai detto di voler arrivare. Tocca una '
    + 'bandierina per vedere la tappa; i tre puntini cambiano il pezzo di strada.</p>'
    + '<div class="mp-card" onclick="mpOpen()">'
    +   '<button type="button" class="pb-dots mp-dots" onclick="mpMenuOpen(event)" aria-label="Che pezzo di strada">⋯</button>'
    +   mpVistaBtn('mp-vista-card')
    +   '<div class="mp-head"><span>' + part.ico + '</span>'
    +     '<div><small>Oggi sei</small><b>' + esc(part.nome) + '</b></div></div>'
    +   '<p class="mp-oz">' + esc(mpOrizzonteNome()) + '</p>'
    +   (mpVista() === 'globo' ? mpGloboHtml(false) : mpSvg(MP_TAPPE, false))
    +   '<div class="mp-foot"><span>' + arr.ico + '</span>'
    +     '<div><small>Vuoi diventare</small><b>' + esc(arr.nome) + '</b></div></div>'
    +   mpArrivoPannello()
    +   '<div class="mp-open">Apri la mappa ›</div>'
    + '</div>';
  if (mpVista() === 'globo') setTimeout(mpPaintGlobo, 20);
}

/** Manda dal Genio: senza la sua lettura questa sezione non ha niente da disegnare. */
function mpChiediLettura(){
  if (typeof orOpen === 'function') orOpen();
}

/** La tappa toccata: cosa dice il Genio, e il pulsante che ci porta. */
function mpTappa(i, ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const t = (MP_TAPPE || [])[i];
  const w = document.getElementById('mpSheet');
  if (!w) return;
  /* SE LA TAPPA NON C'E' PIU', DIRLO.
     Prima qui c'era un `return` muto, ed e' il modo piu' rapido di far credere che un pulsante
     sia rotto: si tocca, non succede niente, e non c'e' nessun indizio su cosa fare. Capita
     davvero quando la mappa e' rimasta a schermo mentre l'orizzonte cambiava sotto. */
  if (!t){
    w.innerHTML = '<div class="mp-sheet-in"><div class="mp-sico">🧭</div>'
      + '<h3>Questa tappa non c\'è più</h3>'
      + '<p>Hai cambiato pezzo di strada mentre la mappa era aperta. Riaprila per vedere le '
      + 'tappe di adesso.</p>'
      + '<button type="button" class="cta" onclick="mpSheetClose();mpClose();mpPaint()">Ricarica la mappa</button>'
      + '</div>';
    w.hidden = false;
    return;
  }
  w.innerHTML = '<div class="mp-sheet-in">'
    + '<div class="mp-sico">' + (t.ico || '📍') + '</div>'
    + '<h3>' + t.t + '</h3>'
    + '<p>' + t.s + '</p>'
    /* mpClose() anche qui: «Vai» porta altrove, e la mappa a tutto schermo e' un pannello opaco
       che resterebbe davanti alla schermata di destinazione. E' lo stesso difetto della voce
       «Apri gli orizzonti», nello stesso file, a due schermate di distanza — quando un errore
       ricompare uguale vuol dire che la regola non era scritta: chi porta altrove chiude. */
    + '<button type="button" class="cta" onclick="mpSheetClose();mpClose();' + (t.go || '') + '">Vai</button>'
    + '<button type="button" class="life-edit" onclick="mpSheetClose()">Più tardi</button>'
    + '</div>';
  w.hidden = false;
}

function mpSheetClose(){
  const w = document.getElementById('mpSheet');
  if (w){ w.hidden = true; w.innerHTML = ''; }
}

/* La mappa a schermo intero: la stessa, grande, dove le tappe si leggono tutte insieme. */
function mpOpen(){
  if (document.getElementById('mpFull')) return;
  const part = mpPartenza(), arr = mpArrivo();
  if (!part || !arr) return;
  const box = document.createElement('div');
  box.id = 'mpFull';
  box.className = 'mp-full';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'La mappa del viaggio');
  box.innerHTML = mpFullHtml();
  /* DENTRO AL TELEFONO. Appesa al documento, sul computer la mappa grande usciva dalla scocca
     e si spalmava su 1900 pixel: ventiquattro tessere da scaricare invece di quattro, e per
     minuti la meta' destra restava vuota. Dentro alla scocca e' larga quanto la scocca. */
  (typeof flVeloCasa === 'function' ? (document.getElementById('phone') || document.body) : document.body).appendChild(box);
  if (mpVista() === 'globo') setTimeout(mpPaintGlobo, 20);
  /* aperta da un posto dove la sezione della mappa non si e' mai disegnata: le tappe si leggono qui */
  if (!MP_TAPPE) mpTappeDi().then(function(t){ if (MP_TAPPE) return; MP_TAPPE = t; mpFullRidisegna(); }).catch(function(){ });
  mpContoVivo();
  try{ window.addEventListener('popstate', mpClose, { once: true }); history.pushState({ mp: 1 }, ''); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA DELLA MAPPA (0.9.228)

   Prima era una colonna fissa: la mappa in mezzo si stringeva e il pannello dell'arrivo restava
   inchiodato in basso, sopra alla cartina, tagliandola. E sotto c'erano due arrivi (quello del
   sogno e quello dei passi) scritti con la stessa voce, fra puntini e sigle.

   Adesso e' una pagina che scorre, in quest'ordine: il sogno, la mappa intera senza niente
   sopra, UNA scheda con l'arrivo del sogno, e in fondo un riquadro piccolo con il resto (chi sei
   oggi e la fine dei passi che si vedono sulla mappa). Ogni riga dice di cosa parla.
   --------------------------------------------------------------------------------------- */

/* come si chiamano i passi di ogni pezzo di strada, nella frase */
const MP_PASSI_DI = {
  settimana: 'I passi di questa settimana',
  mese: 'I passi di questo mese',
  anno: 'I passi di quest’anno',
  cinque: 'I passi dei prossimi cinque anni',
  ungiorno: 'I passi verso il tuo grande obiettivo'
};

function mpFullHtml(){
  const part = mpPartenza(), arr = mpArrivo();
  if (!part || !arr) return '';
  const globo = mpVista() === 'globo';
  const oz = mpOrizzonte();
  const sotto = oz === 'genio'
    ? 'Sulla mappa vedi le mosse che ti consiglia il Genio.'
    : 'Sulla mappa vedi ' + (MP_PASSI_DI[oz] || 'i tuoi passi').toLowerCase() + '.';
  return '<div class="mpf-bar">'
    +   mpStratoBtn()
    +   '<button type="button" class="mpf-btn mp-dots-full" onclick="mpMenuOpen(event)" aria-label="Quali passi vedere sulla mappa">⋯</button>'
    +   '<button type="button" class="mpf-btn" onclick="mpClose()" aria-label="Chiudi la mappa">✕</button>'
    + '</div>'
    + '<header class="mpf-head"><small>Il tuo sogno</small>'
    +   '<h2><span>' + arr.ico + '</span>' + esc(arr.nome) + '</h2>'
    +   '<p>' + sotto + '</p></header>'
    + '<div class="mpf-map' + (globo ? ' globo' : '') + '">' + (globo ? mpFullGlobo() : mpSvg(MP_TAPPE || [], true)) + '</div>'
    + mpArrivoCard();
}
/** La pagina grande si ridisegna al suo posto, alla stessa altezza di scorrimento. */
function mpFullRidisegna(){
  const b = document.getElementById('mpFull');
  if (!b) return;
  const y = b.scrollTop;
  mpMenuClose();
  b.innerHTML = mpFullHtml();
  b.scrollTop = y;
  if (mpVista() === 'globo') setTimeout(mpPaintGlobo, 20);
}
/** La cartina grande, e sotto la rotta e quanta strada e' gia' fatta. */
function mpFullGlobo(){
  const s = (typeof rtStato === 'function') ? rtStato() : null;
  if (!s || !s.da || !s.a) return '<p class="mpf-vuoto">Se il tuo sogno ha un luogo nel mondo, una città dove vuoi arrivare, sceglila: qui vedrai la rotta.</p>';
  const km = (typeof rtKm === 'function') ? rtKm(s.da, s.a) : 0;
  const nome = function(x){ return esc(String(x.nome || '').split(',')[0]); };
  return '<div class="mp-globo big" id="mpGloboFull"></div>'
    + '<div class="mpf-rotta"><span>Da <b>' + nome(s.da) + '</b> a <b>' + nome(s.a) + '</b></span>'
    +   (km ? '<span>' + String(Math.round(km)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' km</span>' : '') + '</div>'
    + '<div class="mpf-perc" id="mpfPerc">' + mpFullPercInner() + '</div>';
}
function mpFullPercInner(){
  let v = null;
  try{ if (typeof hdPercorso === 'function') v = hdPercorso().pct; }catch(_){ }
  if (v == null || !isFinite(v)) v = mpPctVera();
  const w = Math.max(0, Math.min(100, v * 100));
  return '<div class="mpf-perc-r"><span>Strada già fatta</span><b>' + mpPercTxt(v) + '%</b></div>'
    + '<div class="mpf-perc-bar"><i style="width:' + w.toFixed(1) + '%"></i></div>';
}

/** La scheda dell'arrivo del sogno: la data grande, quanto manca in una riga, il confronto con ieri. */
function mpArrivoCard(){
  let s = null, a = null;
  try{ if (typeof etaArrivo === 'function'){ a = etaArrivo(); s = (typeof ETA !== 'undefined') ? ETA.stato : null; } }catch(_){ }
  if (!s || !a) return '';
  const T = function(k, d){ const x = (typeof etaT === 'function') ? etaT(k) : ''; return (typeof x === 'string' && x) || d; };
  let data, testo = false;
  /* 0.9.267, Andrea: il primo giorno diceva "Oltre 40 anni di questo passo": una previsione fatta senza dati.
     Finche' la data e' velata, qui si dice solo perche' */
  if (typeof evVelata === 'function' && evVelata()){ data = (typeof evBreve === "function" ? evBreve() : evMotivo()); testo = true; }
  else if (s.senzaPiano){ data = T('card.senzaPiano', 'Metti almeno un giorno di lavoro nelle Opzioni di viaggio'); testo = true; }
  /* 0.9.304: a.oltre (eta.js, etaArrivo) e' acceso solo quando una data non c'e'. s.oltre di uno stato vecchio voleva
     dire anche "oltre la scadenza scelta": qui diceva "Oltre 40 anni" mentre la slideshow mostrava il 18 luglio 2028 */
  else if (a.oltre){ data = T('card.oltre', 'Oltre 40 anni a questo passo: serve una leva'); testo = true; }
  else data = a.semplice ? a.txtSemplice : a.txt;
  const conto = (!testo && isFinite(s.p50)) ? mpContoTxt(s.p50, a.modo) : '';
  const note = [];
  if (s.pausa){
    let motivi = null;
    try{ motivi = (typeof etaT === 'function') ? etaT('tl.imprevisto.motivi') : null; }catch(_){ }
    const mot = ((motivi && typeof motivi === 'object') ? motivi[s.pausa.motivo] : '') || s.pausa.motivo || '';
    note.push('Il viaggio è in pausa' + (mot ? ' (' + esc(String(mot).toLowerCase()) + ')' : '') + '.');
  } else if (s.calibrazione){
    const tot = (typeof ETA_CFG !== 'undefined' && ETA_CFG.calibrazione && ETA_CFG.calibrazione.giorni) || 14;
    const n = Math.min(tot, (+s.giorniDati || 0) + 1);
    note.push('Sto ancora imparando il tuo ritmo: giorno ' + n + ' di ' + tot + '.');
  }
  if (s.pedaggi) note.push('La data conta anche i pedaggi.');
  return '<section class="mpf-card" id="mpfArrivo" onclick="mpSpiega(event)">'
    + '<p class="mpf-eyebrow">Arrivo previsto</p>'
    + '<b class="mpf-data' + (testo ? ' testo' : '') + '"' + (testo ? '' : ' onclick="etaIntervalloApri(event)"') + '>' + esc(data) + '</b>'
    + (conto ? '<p class="mpf-conto" data-at="' + s.p50 + '" data-modo="' + esc(a.modo || '') + '">' + esc(conto) + '</p>' : '')
    + mpDeltaPill()
    + (note.length ? '<p class="mpf-nota">' + note.join(' ') + '</p>' : '')
    + '<span class="mpf-link">Come si calcola la data</span>'
    + '</section>';
}
/** Quanto manca, in una riga che si legge ad alta voce: «Mancano 3 anni, 10 mesi e 11 ore». */
function mpContoTxt(at, modo){
  if (modo === undefined || modo === null || modo === ''){
    try{ modo = (typeof etaPrecisione === 'function') ? etaPrecisione() : 'precisa'; }catch(_){ modo = 'precisa'; }
  }
  let ms = Math.max(0, at - Date.now());
  const anni = Math.floor(ms / (365.25 * 86400000)); ms -= anni * 365.25 * 86400000;
  const mesi = Math.floor(ms / (30.4375 * 86400000)); ms -= mesi * 30.4375 * 86400000;
  const giorni = Math.floor(ms / 86400000); ms -= giorni * 86400000;
  const ore = Math.floor(ms / 3600000); ms -= ore * 3600000;
  const min = Math.floor(ms / 60000);
  const p = [];
  const metti = function(n, uno, tanti){ if (n > 0) p.push(n + ' ' + (n === 1 ? uno : tanti)); };
  metti(anni, 'anno', 'anni');
  metti(mesi, 'mese', 'mesi');
  if (modo !== 'semplice' || !p.length) metti(giorni, 'giorno', 'giorni');
  if (modo === 'dettagliata'){ metti(ore, 'ora', 'ore'); metti(min, 'minuto', 'minuti'); }
  if (!p.length) return 'Ci sei quasi';
  /* UNA RIGA SOLA: le tre misure piu' grandi bastano. I minuti tornano quando mancano giorni. */
  p.length = Math.min(p.length, 3);
  const frase = p.length === 1 ? p[0] : p.slice(0, -1).join(', ') + ' e ' + p[p.length - 1];
  return (p.length === 1 && /^1 /.test(p[0]) ? 'Manca ' : 'Mancano ') + frase;
}
/** Un periodo detto per intero: «94 giorni», «5 ore». */
function mpDurataTxt(ms){
  const g = Math.round(ms / 86400000);
  if (g >= 1) return g + (g === 1 ? ' giorno' : ' giorni');
  const h = Math.max(1, Math.round(ms / 3600000));
  return h + (h === 1 ? ' ora' : ' ore');
}
/** Il confronto con ieri, in una pillola sola: la data si e' avvicinata o allontanata. */
function mpDeltaPill(){
  let b = null;
  try{ b = (typeof etaBollino === 'function') ? etaBollino() : null; }catch(_){ }
  if (!b) return '';
  let txt, cls = 'piatta';
  if (b.pausa) txt = 'In pausa, la data resta ferma';
  else if (b.nuova) txt = 'Strada nuova: il confronto parte da domani';
  else if (b.primo) txt = 'Da domani vedi come cambia la data';
  else if (!b.delta) txt = 'La data è la stessa di ieri';
  else {
    const m = /(\d+) giorni fa/.exec(b.txt || '');
    const quando = m ? m[1] + ' giorni fa' : 'ieri';
    const q = mpDurataTxt(Math.abs(b.delta));
    txt = b.delta < 0 ? 'Arrivi ' + q + ' prima rispetto a ' + quando : 'Arrivi ' + q + ' dopo rispetto a ' + quando;
    cls = b.delta < 0 ? 'meglio' : 'peggio';
  }
  return '<div><span class="mpf-pill ' + cls + '" onclick="etaTimelineApri(event)">' + esc(txt) + '</span></div>';
}
/** «il 18 ottobre», «l'8 novembre 2027»: la data intera, come si dice. */
function mpIlData(ts){
  const d = new Date(ts);
  const mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  const g = d.getDate();
  return ([1, 8, 11].indexOf(g) >= 0 ? 'l’' : 'il ') + g + ' ' + mesi[d.getMonth()]
    + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : '');
}
function mpRiga(ico, titolo, grande, righe, azione){
  return '<div class="mpf-riga"><span class="mpf-ico">' + ico + '</span><div>'
    + '<small>' + titolo + '</small>'
    + (grande ? '<b>' + grande + '</b>' : '')
    + (righe || []).map(function(r){ return '<p' + (r.warn ? ' class="warn"' : '') + '>' + r.t + '</p>'; }).join('')
    + (azione || '') + '</div></div>';
}
/** La fine dei passi che si vedono sulla mappa: piccola, sotto all'arrivo del sogno. */
function mpPassiHtml(){
  if (typeof ozAnello !== 'function' || typeof ozStima !== 'function') return '';
  const scrivi = function(t){ return '<button type="button" class="mpf-azione" onclick="mpClose();ozOpen()">' + t + '</button>'; };
  let k = mpOrizzonte();
  if (k === 'genio'){
    k = (typeof ozProssimoOrizzonte === 'function') ? ozProssimoOrizzonte() : '';
    if (!k) return mpRiga('🧭', 'I tuoi passi', '', [{ t: 'Le mosse del Genio non hanno una data. Scrivi i tuoi passi e ti dico quando li finisci.' }], scrivi('Scrivi i passi'));
  }
  const tit = MP_PASSI_DI[k] || 'I tuoi passi';
  const passi = ozAnello(k).passi || [];
  if (!passi.length) return mpRiga('📅', tit, '', [{ t: 'Non hai ancora scritto nessun passo.' }], scrivi('Scrivi i passi'));
  const rimasti = passi.filter(function(p){ return !p.fatto; }).length;
  const nPassi = function(n){ return n + (n === 1 ? ' passo' : ' passi'); };
  if (!rimasti) return mpRiga('🏁', tit, 'Li hai spuntati tutti', [], '');
  let s = null;
  try{ s = ozStima(k); }catch(_){ }
  if (!s) return mpRiga('📅', tit, '', [{ t: 'Ti mancano ' + nPassi(rimasti) + '. Dai una scadenza a questi passi e ti dico quando li finisci.' }], scrivi('Apri il piano'));
  const ritmo = function(x){ return (typeof ozRitmoTxt === 'function') ? ozRitmoTxt(x) : ''; };
  /* 0.9.267, Andrea: "per finire entro il 15 ottobre" con il 15 ottobre = oggi non dice niente */
  if (s.fonte === 'richiesto' && (typeof ozGiorniAllaScadenza !== 'function' || ozGiorniAllaScadenza(k) <= 1)){
    return mpRiga('📅', k === 'oggi' ? 'I passi di oggi' : tit, nPassi(rimasti) + ' da fare', [{ t: 'Spuntane uno e comincio a misurare il tuo ritmo.' }], '');
  }
  if (s.fonte === 'richiesto'){
    return mpRiga('📅', tit, 'Per finire entro ' + mpIlData(s.scadenza), [
      { t: 'Ti serve ' + ritmo(s.richiesto) + '. Ti mancano ' + nPassi(s.rimasti) + '.' },
      { t: 'Spunta un passo e misuro il tuo ritmo vero.' }
    ], '');
  }
  const righe = [];
  if (s.scadenza){
    if (s.margine > 0) righe.push({ t: mpDurataTxt(s.margine * 86400000) + ' prima della scadenza.' });
    else if (s.margine === 0) righe.push({ t: 'Giusto in tempo per la scadenza.' });
    else righe.push({ t: mpDurataTxt(-s.margine * 86400000) + ' dopo la scadenza, che è ' + mpIlData(s.scadenza) + '.', warn: true });
  }
  righe.push({ t: 'Ti mancano ' + nPassi(s.rimasti) + '. '
    + (s.fonte === 'misto'
        ? 'Per ora la stima è provvisoria: hai spuntato ' + nPassi(s.prove) + ' finora.'
        : 'Il tuo ritmo è ' + ritmo(s.alGiorno) + '.') });
  /* il confronto con ieri, e il traffico della settimana: solo se c'e' qualcosa da dire */
  let prima = 0;
  try{ prima = (typeof ozRicorda === 'function') ? ozRicorda(k, s) : 0; }catch(_){ }
  const gg = prima ? Math.round((s.quando - prima) / 86400000) : 0;
  if (gg < 0) righe.push({ t: 'Rispetto a ieri finisci ' + mpDurataTxt(-gg * 86400000) + ' prima.' });
  else if (gg > 0) righe.push({ t: 'Rispetto a ieri finisci ' + mpDurataTxt(gg * 86400000) + ' dopo.', warn: true });
  else if (s.traffico === 'lento') righe.push({ t: 'Questa settimana vai più piano del solito.', warn: true });
  else if (s.traffico === 'veloce') righe.push({ t: 'Questa settimana vai più veloce del solito.' });
  return mpRiga('📅', tit, 'Li finisci ' + mpIlData(s.quando), righe, '');
}
/* Il navigatore (eta.js) ridisegna i suoi pannelli quando la stima cambia: anche questa scheda. */
function mpArrivoRidipingi(){
  const el = document.getElementById('mpfArrivo');
  if (el){ const h = mpArrivoCard(); if (h) el.outerHTML = h; else el.remove(); }
  const p = document.getElementById('mpfPerc');
  if (p) p.innerHTML = mpFullPercInner();
}

/** La mappa della settimana, per la scheda START: le tappe di «Questa settimana», e basta. */
function mpTappeSettimana(){
  if (typeof ozAnello !== 'function') return [];
  try{
    const a = ozAnello('settimana');
    return (a.passi || []).filter(function(x){ return !x.fatto; }).slice(0, 6).map(function(x){
      return { ico: '\ud83d\udccd', t: x.t, s: 'Un passo di questa settimana.', go: 'ozOpen()' };
    });
  }catch(_){ return []; }
}
async function mpApriSettimana(){
  try{ localStorage.setItem('fl_mp_oz', 'settimana'); }catch(_){ }
  await mpPaint();
  mpOpen();
}

function mpClose(){
  mpMenuClose();
  const b = document.getElementById('mpFull');
  if (b) b.remove();
}

(function mpStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.mp-card{position:relative;background:linear-gradient(170deg,#0B2A55,#001E44 60%,#00132B);',
      'border-radius:22px;padding:18px 16px 14px;color:#fff;cursor:pointer;overflow:hidden}',
    '.mp-head,.mp-foot{display:flex;align-items:center;gap:12px}',
    '.mp-head span,.mp-foot span{font-size:26px;line-height:1;flex:none}',
    '.mp-head small,.mp-foot small{display:block;font:700 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:rgba(200,218,242,.62)}',
    '.mp-head b,.mp-foot b{display:block;font:800 15px var(--font-display);color:#fff;margin-top:2px}',
    '.mp-svg{display:block;width:100%;height:230px;margin:8px 0}',
    '.mp-svg.big{height:min(62vh,520px)}',
    '.mp-line{fill:none;stroke-width:1.6;stroke-linecap:round}',
    '.mp-line.done{stroke:var(--neo-soft,#4FB8FF)}',
    '.mp-line.todo{stroke:rgba(200,218,242,.42);stroke-dasharray:3 3.4}',
    '.mp-node circle{fill:#0E2350;stroke:rgba(200,218,242,.5);stroke-width:.8}',
    /* 0.9.301, Andrea: "il pallino deve essere il blu del mio brand, non azzurro; e l'emoji sul rosso si mimetizza
       (la valigetta marrone sul rosso quasi non si vede)". Partenza blu del brand, arrivo rosso del brand, e dietro
       all'emoji un disco bianco sfumato che la stacca sempre dal colore. */
    '.mp-node.start circle{fill:#0075E3;stroke:none}',
    '.mp-node.end circle{fill:#E63946;stroke:none}',
    '.mp-node.start circle.mp-halo,.mp-node.end circle.mp-halo{fill:#FFFFFF;stroke:rgba(255,255,255,.55);stroke-width:1.1}',
    '.mp-node.step{cursor:pointer}',
    '.mp-node text{font-size:7px;text-anchor:middle;dominant-baseline:central}',
    '.mp-open{text-align:center;margin-top:10px;font:700 12px var(--font-body);color:var(--neo-soft,#4FB8FF)}',
    '.mp-dots{top:14px;right:14px}',
    /* il pulsante della vista: satellite quando sei sul sentiero, cartina quando sei sul globo */
    '.mp-vista{position:absolute;width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.14);',
      'color:#fff;font-size:17px;cursor:pointer;display:grid;place-items:center;z-index:4}',
    '.mp-vista-card{top:14px;right:52px}',
    '.mp-globo{position:relative;height:220px;border-radius:14px;overflow:hidden;background:#0B1524;margin:8px 0 10px}',
    '.mp-globo.big{height:min(52vh,420px)}',
    '.mp-globo .rt-tiles,.mp-globo .rt-linea{position:absolute;inset:0}',
    '.mp-globo .rt-tile{position:absolute;width:256px;height:256px}',
    '.mp-globo .rt-linea{width:100%;height:100%}',
    '.mp-globo .rt-aereo{position:absolute;font-size:22px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5))}',
    '.mp-globo-hud{display:flex;align-items:center;justify-content:space-between;gap:8px;font:800 13px var(--font-body);color:#fff}',
    '.mp-globo-hud i{font:600 11px var(--font-body);color:rgba(255,255,255,.7)}',
    '.mp-globo-t{margin:10px 0 4px;font:500 12.5px/1.5 var(--font-body);color:rgba(255,255,255,.8);text-align:center}',
    '.mp-globo-t b{font:800 14px var(--font-display);color:#fff}',
    /* la mappa piccola nella scheda START */
    '.st-mappa .mp-card{cursor:pointer}',
    '.st-mappa .mp-svg{width:100%;height:auto;max-height:240px}',
    /* le tappe sull'arco si toccano anche se la linea sotto no */
    '.rt-linea .rt-tappa{pointer-events:auto}',
    /* la seconda diapositiva del cielo: altezza sua, come promette il commento in blkhero */
    '.sev-globo{padding:12px 14px 6px}',
    '.sev-globo-in .mp-globo{height:210px;margin:6px 0 8px}',
    '.sev-globo-vuoto{padding:40px 18px;text-align:center;color:#fff}',
    '.sev-globo-vuoto b{display:block;font:800 18px var(--font-display);font-style:italic;margin-bottom:6px}',
    '.sev-globo-vuoto p{margin:0;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.8)}',
    '.mp-oz{margin:12px 0 0;text-align:center;font:800 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:rgba(200,218,242,.62)}',
    '.mp-card .oz-eta{color:rgba(200,218,242,.86);text-align:center;margin-top:12px}',
    '.oz-eta-di{margin:12px 0 -6px;font:600 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase;',
      'color:rgba(200,218,242,.6);text-align:center}',
    '.oz-eta-di b{color:#fff}',
    '.mp-num circle{fill:#fff;stroke:#0E2350;stroke-width:.8}',
    '.mp-num text{font:800 3.6px var(--font-body);fill:#0E2350;text-anchor:middle}',
    '.mp-card .oz-eta b{color:#fff}',
    '.mp-vuota{text-align:center;padding:26px 20px 18px}',
    '.mp-piegata{font-size:52px;line-height:1;opacity:.55;margin-bottom:14px}',
    '.mp-vuota p{margin:0;font:500 13px/1.7 var(--font-body);color:rgba(200,218,242,.86)}',
    '.mp-vuota p b{color:#fff;font-weight:800}',

    /* LA PAGINA DELLA MAPPA (0.9.228): scorre tutta, niente di fisso sopra alla cartina */
    '.mp-opz-pg{padding:0 16px 24px}.mpz-t{display:flex;align-items:center;justify-content:center;gap:8px;margin:34px 0 14px;font:800 19px var(--font-display);color:var(--navy);text-align:center}.mpz-t:first-child{margin-top:12px}body.dark .mpz-t{color:#fff}.mpz-t span{font-size:22px}',
    '.mpz-c{display:flex;flex-direction:column;gap:18px;padding:18px 16px;border:1px solid var(--line);border-radius:22px;background:var(--card,#fff)}body.dark .mpz-c{background:#12203A;border-color:#22345A}.mpz-c .mp-opz-r{margin:0;padding:0;border:0;background:none}.mpz-c .mp-seg{margin:0}.mpz-salva{margin-top:32px}',
    '.mp-full{position:fixed;inset:0;z-index:9990;background:#0F2041;color:#fff;overflow-x:hidden;overflow-y:auto;',
      '-webkit-overflow-scrolling:touch;overscroll-behavior:none;box-sizing:border-box;',
      'padding:calc(env(safe-area-inset-top,0px) + 12px) 16px calc(env(safe-area-inset-bottom,0px) + 36px)}',
    '.mp-full{scrollbar-width:none}.mp-full::-webkit-scrollbar{display:none}',
    '.mpf-bar{display:flex;justify-content:flex-end;gap:10px}',
    '.mpf-btn{width:44px;height:44px;flex:none;border:0;border-radius:50%;background:#14234A;color:#fff;cursor:pointer;',
      'display:grid;place-items:center;font:700 20px/1 var(--font-body);box-shadow:inset 0 0 0 1px rgba(255,255,255,.14)}',
    '.mpf-btn:active{background:#0075E3}',
    '.mpf-head{margin:10px 2px 18px;text-align:center}',
    '.mpf-head small{display:block;font:700 14px var(--font-body);color:#8CC6FF}',
    /* 0.9.317, Andrea: "il titolo non e' al centro perche' c'e' l'emoji a sinistra". L'emoji sta dentro alla riga, non accanto al blocco */
    '.mpf-head h2{display:block;text-align:center;margin:6px 0 0;font:800 26px/1.2 var(--font-display);color:#fff}',
    '.mpf-head h2 span{display:inline;font-size:26px;line-height:1;margin-right:8px}',
    '.mpf-head p{margin:8px 0 0;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.8)}',
    '.mpf-map{border-radius:20px;overflow:hidden;background:#14234A;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}',
    '.mpf-map .mp-globo.big{height:min(56vh,440px);margin:0;border-radius:0}',
    '.mpf-map .mp-svg.big{height:min(56vh,440px);margin:0;padding:10px 0}',
    '.mpf-rotta{display:flex;justify-content:space-between;align-items:baseline;gap:12px;padding:14px 16px 4px;',
      'font:500 15px/1.4 var(--font-body);color:rgba(255,255,255,.8)}',
    '.mpf-rotta b{color:#fff;font-weight:800}',
    '.mpf-rotta span:last-child{flex:none;font-weight:700;color:rgba(255,255,255,.7)}',
    '.mpf-perc{padding:8px 16px 16px}',
    '.mpf-perc-r{display:flex;justify-content:space-between;align-items:baseline;font:600 14px var(--font-body);color:rgba(255,255,255,.8)}',
    '.mpf-perc-r b{font:800 17px var(--font-display);color:#fff}',
    '.mpf-perc-bar{height:8px;margin-top:8px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}',
    '.mpf-perc-bar i{display:block;height:100%;min-width:8px;border-radius:99px;background:#BCE0FF}',
    '.mpf-vuoto{margin:0;padding:48px 20px;text-align:center;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.82)}',
    '.mpf-card{margin-top:16px;padding:22px 18px 20px;border-radius:20px;background:#14234A;text-align:center;cursor:pointer;',
      'box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)}',
    '.mpf-eyebrow{margin:0;font:700 14px var(--font-body);color:#8CC6FF}',
    '.mpf-data{display:block;margin-top:8px;font:800 34px/1.15 var(--font-display);color:#fff}',
    '.mpf-data.testo{font-size:19px;line-height:1.35}',
    '.mpf-conto{margin:10px 0 0;font:600 16px/1.45 var(--font-body);color:rgba(255,255,255,.88)}',
    '.mpf-pill{display:inline-block;margin-top:14px;padding:7px 14px;border-radius:999px;font:700 14px/1.3 var(--font-body)}',
    '.mpf-pill.meglio{background:#0075E3;color:#fff}',
    '.mpf-pill.peggio{background:#E63946;color:#FFFFFF}',
    '.mpf-pill.piatta{background:rgba(255,255,255,.1);color:rgba(255,255,255,.88)}',
    '.mpf-nota{margin:14px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.72)}',
    '.mpf-link{display:inline-block;margin-top:14px;font:700 14px var(--font-body);color:#fff;',
      'text-decoration:underline;text-decoration-color:rgba(255,255,255,.4);text-underline-offset:4px}',
    '.mpf-altro{margin-top:14px;padding:4px 18px;border-radius:20px;background:#14234A;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}',
    '.mpf-riga{display:flex;align-items:flex-start;gap:14px;padding:16px 0}',
    '.mpf-riga + .mpf-riga{border-top:1px solid rgba(255,255,255,.1)}',
    '.mpf-ico{flex:none;width:32px;text-align:center;font-size:26px;line-height:1.1}',
    '.mpf-riga > div{flex:1;min-width:0}',
    '.mpf-riga small{display:block;font:700 13px var(--font-body);color:rgba(255,255,255,.66)}',
    '.mpf-riga b{display:block;margin-top:3px;font:800 17px/1.3 var(--font-display);color:#fff}',
    '.mpf-riga p{margin:5px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.78)}',
    '.mpf-riga p.warn{color:#FF8A93}',
    '.mpf-azione{margin-top:10px;border:0;border-radius:999px;background:#0075E3;color:#fff;font:700 14px var(--font-body);padding:10px 16px;cursor:pointer}',
    /* il pannello dell'arrivo: una riga, la data grande, centrato */
    '.mp-arrivo{margin:14px 0 8px;padding:16px 14px;border-radius:16px;background:#0B1524;border:1px solid rgba(255,255,255,.1);text-align:center}',
    '.mp-arrivo p{margin:0 0 6px;font:600 12.5px var(--font-body);color:rgba(255,255,255,.78)}',
    '.mp-arrivo p b{color:#fff}',
    '.mp-arrivo > b{display:block;font:800 26px/1.1 var(--font-display);font-style:italic;color:#fff}',
    '.mp-arrivo small{display:block;margin-top:6px;font:600 12px var(--font-body);color:rgba(255,255,255,.78)}',
    '.mp-arrivo{cursor:pointer}',
    '.mp-arrivo-data{text-decoration:underline;text-decoration-color:rgba(255,255,255,.35);text-underline-offset:4px}',
    '.mp-arrivo em{display:block;margin-top:8px;font:700 11px var(--font-body);font-style:normal;color:#6FC0FF}',
    /* il segmento a tre della precisione sta su una riga sua: tre parole non entrano accanto al titolo */
    '.mp-seg3{width:100%;margin:-2px 0 12px}.mp-seg3 button{flex:1}',
    '.mp-strato.mp-vista-card{right:90px}',
    /* la sezione della mappa respira: prima l\'emoji stava incollata al pannello del Genio */
    '#scMap .mp-intro{margin-top:32px}',
    '.sev-globo{padding-bottom:72px}',
    '.mp-opz-r{display:flex;align-items:center;gap:12px;text-align:left;padding:10px 0;border-top:1px solid rgba(0,0,0,.06)}',
    '.mp-opz-r > div{flex:1}.mp-opz-r b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    '.mp-opz-r small{display:block;font:500 11.5px/1.4 var(--font-body);color:var(--muted)}',
    '.mp-opz-r input{width:96px;border:1px solid var(--line);border-radius:10px;padding:8px 10px;font:700 14px var(--font-body);text-align:right}',
    /* La nota sulla riservatezza e' una riga di servizio, non un avviso legale: piccola,
       grigia, senza riquadro. Un pannello scuro attorno la farebbe leggere due volte. */
    '.mp-opz-nota{margin:10px 2px 14px;font:500 10.5px/1.45 var(--font-body);color:var(--muted);background:none}',
    '.mp-opz-pg{padding:8px 16px 20px}',
    '.mp-opz-pg .mp-opz-r:first-child{border-top:none}',
    '.mp-sheet-in .cta.mp-sec{background:#EAF2FB;color:var(--navy);margin-bottom:10px}body.dark .mp-sheet-in .cta.mp-sec{background:#1B2B48;color:#fff}',
    '.mp-seg{display:flex;border:1px solid var(--line);border-radius:10px;overflow:hidden;flex:none}.mp-seg button{border:none;background:#fff;padding:8px 10px;font:700 12px var(--font-body);color:var(--muted)}.mp-seg button.on{background:var(--blue);color:#fff}',
    'body.dark .mp-seg button{background:#12203A;color:#9FB3D1}body.dark .mp-seg button.on{background:var(--blue);color:#fff}',
    '.mp-opz .ghostmini{flex:none}',
    /* la mappa nella scheda START non sta incollata alle linguette */
    '.st-mappa .mp-card{margin-top:16px}',

    '.mp-sheet{position:fixed;inset:0;z-index:9992;background:rgba(0,10,26,.72);display:flex;',
      'align-items:flex-end;justify-content:center}',
    '.mp-sheet-in{width:100%;max-width:460px;background:var(--card,#fff);border-radius:24px 24px 0 0;',
      'padding:26px 22px calc(26px + env(safe-area-inset-bottom,0px));text-align:center}',
    '.mp-sico{font-size:40px;margin-bottom:10px}',
    '.mp-sheet-in h3{font:800 18px/1.3 var(--font-display);color:var(--navy);margin:0 0 8px}',
    '.mp-sheet-in p{font:500 13px/1.6 var(--font-body);color:var(--muted);margin:0 0 18px}',
    '.mp-sheet-in .cta{margin:0 0 6px}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* Il posto: fra «Prevedi il tuo futuro» e la Modalità severa. È l'ordine del racconto — chi
   stai diventando, la strada, e poi il lucchetto che ti tiene sulla strada. */
(function mpGraft(){
  /* Il sentiero delle tappe segue il navigatore dentro alla scheda «Viaggio»: sono la stessa
     domanda vista da due altezze — la rotta sul mondo e le tappe da qui a domani. Tenerle in
     due schede diverse costringeva a ricordarsi l'una mentre si guardava l'altra. */
  /* 0.9.267: la scheda «Blocco» (tab-severa) non esiste piu', e con lei era sparita la mappa disegnata delle mosse
     del Genio. Ora e' il quarto tipo di mappa della scheda Mappa (rotta.js, strato "mosse") e si apre a tutto
     schermo con un tocco (mpOpen). Il foglio della tappa serve comunque. */
  if (document.getElementById('mpSheet')) return;
  const sheet = document.createElement('div');
  sheet.id = 'mpSheet';
  sheet.className = 'mp-sheet';
  sheet.hidden = true;
  sheet.addEventListener('click', function(e){ if (e.target === sheet) mpSheetClose(); });
  document.body.appendChild(sheet);
})();

/* Il disegno parte SUBITO — con le tappe gia' in memoria non c'e' niente da aspettare — e si
   ripete a 300 ms per il caso in cui il motore debba ancora rispondere. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'severa') return;
  try{ mpPaint(); }catch(_){ }
  setTimeout(mpPaint, 300);
});
setTimeout(mpPaint, 3000);

/* ENTRATA DAL BASSO, come la prima diapositiva della Roadmap: la mappa, poi la percentuale,
   poi l'arrivo. Quando l'arrivo e' al suo posto il bordo si accende con l'alone azzurro del
   Blocco rapido e dei programmi: lo stesso segno, lo stesso significato — «questo e' attivo». */
(function mpStileEntrata(){
  const dove = ['.sev-globo-in', '#scMap'];
  const css = [];
  dove.forEach(function(w){
    css.push(w + ' .mp-globo,' + w + ' .mp-globo-hud{animation:sevRise .6s ease-out both;animation-delay:.1s}');
    css.push(w + ' .mp-globo-t{animation:sevRise .6s ease-out both;animation-delay:.3s}');
    css.push(w + ' .mp-arrivo{animation:sevRise .6s ease-out .45s both,mpArrivoAccende .9s ease-out 1.15s both}');
  });
  css.push('@keyframes mpArrivoAccende{from{border-color:rgba(255,255,255,.1);box-shadow:none}'
    + 'to{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.28),0 22px 44px rgba(11,132,255,.16)}}');
  css.push('@keyframes sevRise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}');
  const st = document.createElement('style'); st.textContent = css.join('\n'); document.head.appendChild(st);
})();
