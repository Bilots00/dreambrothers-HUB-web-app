/* ===========================================================================================
   IL RISCALDAMENTO — la guida a passi dopo il primo avvio (0.9.173)

   Come la guida di configurazione di un negozio appena aperto: nove passi in tre gruppi, un
   gruppo aperto alla volta, e ogni passo porta nel posto dell'app dove si fa la cosa. Qui
   finisce la personalizzazione: la pagina del sogno, il mantra, il volto del Nuovo te, le
   etichette alle app. Nel primo avvio non c'e' piu' niente da configurare: prima si racconta,
   poi si prepara il campo, poi si gioca.

   L'ORDINE E' SU MISURA. Chi ha detto «mi distraggo con niente» vede prima lo Scudo; chi ha
   detto «nessuna direzione chiara» vede prima il foglio; chi dorme male trova un passo in piu',
   la sveglia. Al massimo due passi portano «Per te», con il motivo in una riga.

   Ogni passo si dice fatto da solo, leggendo quello che l'app sa gia': non c'e' niente da
   spuntare a mano. Vive nella scheda Mappa, sotto alla slideshow, e sparisce quando e' finito.
   =========================================================================================== */

const RSC_KEY_APERTO = 'fl_rs_aperto';
const RSC_KEY_SALTATI = 'fl_rs_saltati';
const RSC_KEY_LOCK = 'fl_rs_lock_visto';
/* LA SPUNTA SI PUO' TOGLIERE. Un passo che l'app crede fatto (tre etichette messe, un blocco
   acceso) puo' non esserlo davvero per chi lo guarda: toccando la spunta il passo torna da
   fare, con il suo pulsante; toccandola ancora torna fatto. Il pulsante «vai» azzera il
   ripensamento: chi ci torna sopra e completa, lo vede spuntato di nuovo da solo. */
const RSC_KEY_RIAPERTI = 'fl_rs_riaperti';
function rscRiaperti(){ try{ return JSON.parse(localStorage.getItem(RSC_KEY_RIAPERTI) || '[]') || []; }catch(_){ return []; } }
function rscRiapriToggle(id){
  const l = rscRiaperti(); const j = l.indexOf(id);
  if (j >= 0) l.splice(j, 1); else l.push(id);
  try{ localStorage.setItem(RSC_KEY_RIAPERTI, JSON.stringify(l)); }catch(_){ }
  rscPaint();
}
function rscFattoVisto(x){ try{ return x.fatto() && rscRiaperti().indexOf(x.id) < 0; }catch(_){ return false; } }

function rscHa(k){ try{ return !!localStorage.getItem(k); }catch(_){ return false; } }
function rscSaltati(){ try{ return JSON.parse(localStorage.getItem(RSC_KEY_SALTATI) || '[]') || []; }catch(_){ return []; } }
function rscSalta(id){ const l = rscSaltati(); if (l.indexOf(id) < 0) l.push(id); try{ localStorage.setItem(RSC_KEY_SALTATI, JSON.stringify(l)); }catch(_){ } rscPaint(); }

/* I PASSI. fatto(): l'app lo sa da sola. vai(): dove porta. */
const RSC_PASSI = [
  { id: 'app', g: 'campo', t: 'Dai un\'etichetta alle tue app', s: 'Produttiva, neutra, distrattiva o da escludere: così i numeri parlano di te.', btn: 'Ordina le app', ico: '🏷️',
    fatto: function(){ try{ return Object.keys(insCats()).length >= 3; }catch(_){ return false; } },
    /* dritto alla pagina delle carte, senza passare dal Report: e indietro si torna qui, in START */
    vai: function(){ goId('s-home'); switchTab('sveglia'); setTimeout(function(){ try{ insSortApps('sveglia'); }catch(_){ } }, 120); } },
  { id: 'scudo', g: 'campo', t: 'Accendi lo Scudo sul tuo ladro numero uno', s: 'Un programma o il blocco rapido: l\'app che ti prende più tempo, protetta.', btn: 'Proteggila', ico: '🛡️',
    fatto: function(){ try{ return (typeof PROGRAMS !== 'undefined' && PROGRAMS.some(function(p){ return p && p.on !== false; })) || (typeof QUICK !== 'undefined' && !!QUICK.enabled); }catch(_){ return false; } },
    vai: function(){ if (typeof blPaginaApri === 'function') blPaginaApri(); } },
  { id: 'lock', g: 'campo', t: 'Scegli cosa vedi quando un blocco scatta', s: 'Lo scudo, una frase tua, la tua foto o il prezzo in giorni sul tuo arrivo.', btn: 'Scegli la schermata', ico: '🔒',
    fatto: function(){ return rscHa(RSC_KEY_LOCK); },
    vai: function(){ try{ localStorage.setItem(RSC_KEY_LOCK, '1'); }catch(_){ } goId('s-lockscreen'); if (typeof lockScreenPaint === 'function') lockScreenPaint(); } },
  /* I DUE PROMEMORIA CHE NON CHIEDONO NIENTE (1/10): il widget sulla home, come fa Duolingo
     («faro' il tifo per te dalla tua schermata iniziale»), e la frase del giorno sul blocco
     schermo. Si vedono ogni volta che si prende in mano il telefono. */
  { id: 'widget', g: 'campo', t: 'Metti il Genio sulla tua schermata iniziale', s: 'Un widget piccolo, due icone di spazio: conta i tuoi giorni di Full Focus di fila.', btn: 'Aggiungi il widget', ico: '📲',
    fatto: function(){ return rscHa('fl_widget_on'); },
    vai: function(){ if (typeof wgApri === 'function') wgApri(); } },
  { id: 'citazione', g: 'campo', t: 'Metti la frase del giorno sul blocco schermo', s: 'Ogni giorno una frase nuova, ogni volta che accendi lo schermo.', btn: 'Accendila', ico: '❝',
    fatto: function(){ return rscHa('fl_lockquote_on'); },
    vai: function(){ if (typeof scOpenInspire === 'function') scOpenInspire(); } },
  { id: 'mappa', g: 'mappa', t: 'Costruisci la tua pagina del sogno', s: 'Copertina, icona, colore e il nome del sogno, su una riga.', btn: 'Costruisci la mappa', ico: '🗺️',
    fatto: function(){ return rscHa('fl_mappa_cfg'); },
    vai: function(){ if (typeof cstApri === 'function') cstApri(null, true); } },
  { id: 'mantra', g: 'mappa', t: 'Scrivi il tuo mantra', s: 'La frase che leggi quando il vecchio te bussa.', btn: 'Scrivilo', ico: '✍️',
    fatto: function(){ try{ return !!(typeof whyMantra === 'function' && whyMantra()); }catch(_){ return false; } },
    vai: function(){ if (typeof whyOpen === 'function') whyOpen(); } },
  { id: 'volto', g: 'mappa', t: 'Scegli il volto del Nuovo te', s: 'La foto che vedi sul tabellone e nel profilo.', btn: 'Scegli la foto', ico: '🪞',
    fatto: function(){ return rscHa('fl_avatar_img'); },
    vai: function(){ goId('s-home'); switchTab('profilo'); setTimeout(function(){ try{ if (typeof profiloModificaApri === 'function') profiloModificaApri(); else goId('s-profilo-modifica'); }catch(_){ } }, 300); } },
  { id: 'sveglia', g: 'mappa', t: 'Imposta la sveglia del Nuovo te', s: 'La mattina comincia dove decidi tu, non dove finisce lo schermo.', btn: 'Imposta la sveglia', ico: '⏰', solo: 'sonno',
    fatto: function(){ try{ const a = JSON.parse(localStorage.getItem('fl_alarms') || '[]'); return Array.isArray(a) && a.some(function(x){ return x && x.on !== false; }); }catch(_){ return false; } },
    vai: function(){ if (typeof alPageOpen === 'function') alPageOpen(); else goId('s-alarms'); } },
  { id: 'focus', g: 'gioco', t: 'Prova un Full Focus da 10 minuti', s: 'La sfera si accende mentre lavori. Dieci minuti bastano per capire.', btn: 'Provalo adesso', ico: '🔮',
    fatto: function(){ try{ return (ffHist() || []).some(function(h){ return h && h.ok; }); }catch(_){ return false; } },
    vai: function(){ try{ const p = ffPref(); p.minutes = 10; ffSavePref(); }catch(_){ } if (typeof ffOpen === 'function') ffOpen(); } },
  { id: 'foglio', g: 'gioco', t: 'Scrivi la prima riga del foglio di domani', s: 'Una cosa sola. Domani la troverai lì.', btn: 'Apri il foglio', ico: '📝',
    fatto: function(){ try{ return !!(stNotes('today') || '').trim() || !!(stNotes('tomorrow') || '').trim(); }catch(_){ return false; } },
    vai: function(){ goId('s-home'); switchTab('sveglia'); setTimeout(function(){ try{ stTabSet('domani'); }catch(_){ } }, 300); } },
  { id: 'modello', g: 'gioco', t: 'Scegli il tuo modello di partita', s: 'Cinque modi di giocare. Il Genio te ne consiglia uno, la scelta è tua.', btn: 'Scegli come giocare', ico: '🏆',
    fatto: function(){ return rscHa('fl_partita_modello'); },
    vai: function(){ if (typeof mdApri === 'function') mdApri(); } }
];
const RSC_GRUPPI = { campo: 'Prepara il campo', mappa: 'Fai tua la mappa', gioco: 'Impara a giocare' };

/* l'ordine dei gruppi e le etichette «Per te» vengono dal primo avvio */
function rscProfilo(){
  let d = {}; try{ d = gnDati(); }catch(_){ }
  const conti = (d.conti || []).join(' ');
  const out = { ordine: ['campo', 'mappa', 'gioco'], perte: {}, sonno: /Dormo male/.test(conti) };
  if (/distraggo/.test(conti)){ out.ordine = ['campo', 'gioco', 'mappa']; out.perte.scudo = 'Hai detto che ti distrai con niente'; }
  else if (/direzione chiara/.test(conti)){ out.ordine = ['gioco', 'campo', 'mappa']; out.perte.foglio = 'Hai detto che ti manca una direzione'; }
  else if (/Rimando/.test(conti)){ out.ordine = ['gioco', 'campo', 'mappa']; out.perte.focus = 'Hai detto che rimandi tutto: dieci minuti, adesso'; }
  if (out.sonno) out.perte.sveglia = 'Hai detto che dormi male';
  return out;
}
function rscPassi(){
  const p = rscProfilo();
  return RSC_PASSI.filter(function(x){ return !x.solo || (x.solo === 'sonno' && p.sonno); });
}
function rscStato(){
  const passi = rscPassi(), saltati = rscSaltati();
  let fatti = 0;
  passi.forEach(function(x){ if (rscFattoVisto(x) || saltati.indexOf(x.id) >= 0) fatti++; });
  return { n: passi.length, fatti: fatti, finito: fatti >= passi.length };
}
/* il + apre, il − chiude: lo stesso gruppo toccato due volte si richiude */
function rscApertoSet(g){
  let cur = ''; try{ cur = localStorage.getItem(RSC_KEY_APERTO) || ''; }catch(_){ }
  try{ localStorage.setItem(RSC_KEY_APERTO, cur === g ? 'nessuno' : g); }catch(_){ }
  rscPaint();
}
function rscVai(id){
  const x = RSC_PASSI.filter(function(p){ return p.id === id; })[0]; if (!x) return;
  /* chi ci torna sopra con il pulsante ha finito di ripensarci */
  try{ const l = rscRiaperti().filter(function(k){ return k !== id; }); localStorage.setItem(RSC_KEY_RIAPERTI, JSON.stringify(l)); }catch(_){ }
  try{ x.vai(); }catch(_){ }
}

function rscHtml(){
  const st = rscStato();
  if (st.finito) return '';
  const p = rscProfilo(), saltati = rscSaltati(), passi = rscPassi();
  let aperto = ''; try{ aperto = localStorage.getItem(RSC_KEY_APERTO) || ''; }catch(_){ }
  /* di serie e' aperto il primo gruppo che ha ancora qualcosa da fare */
  if (aperto !== 'nessuno' && (!aperto || !p.ordine.some(function(g){ return g === aperto; }))){
    aperto = p.ordine.filter(function(g){ return passi.some(function(x){ return x.g === g && !rscFattoVisto(x) && saltati.indexOf(x.id) < 0; }); })[0] || p.ordine[0];
    /* si ricorda: cosi' il primo tocco sullo stesso + lo richiude, invece di «aprirlo» di nuovo */
    try{ localStorage.setItem(RSC_KEY_APERTO, aperto); }catch(_){ }
  }
  let perTe = 0;
  const gruppi = p.ordine.map(function(g, gi){
    const mie = passi.filter(function(x){ return x.g === g; });
    const fatti = mie.filter(function(x){ return rscFattoVisto(x) || saltati.indexOf(x.id) >= 0; }).length;
    const on = g === aperto;
    return '<div class="rs-g' + (on ? ' on' : '') + '"><button type="button" class="rs-gh" aria-expanded="' + (on ? 'true' : 'false') + '" onclick="rscApertoSet(\'' + g + '\')"><span class="rs-gn">' + (gi + 1) + '</span><b>' + RSC_GRUPPI[g] + '</b><small>' + fatti + ' di ' + mie.length + '</small><span class="animated-plus"></span></button>'
      + '<div class="rs-gin">' + mie.map(function(x){
          const ok = rscFattoVisto(x), sk = saltati.indexOf(x.id) >= 0;
          /* la spunta e' un pulsante: fatto ↔ da rifare (solo per i passi che l'app da' per fatti) */
          const spunta = (ok || (x.fatto() && !sk))
            ? '<button type="button" class="rs-ico rs-check' + (ok ? ' on' : '') + '" onclick="rscRiapriToggle(\'' + x.id + '\')" aria-pressed="' + (ok ? 'true' : 'false') + '" aria-label="' + (ok ? 'Segna come da fare' : 'Segna come fatto') + '">' + (ok ? '✓' : '') + '</button>'
            : '<span class="rs-ico">' + x.ico + '</span>';
          const pt = (!ok && !sk && p.perte[x.id] && perTe < 2) ? (perTe++, '<span class="rs-perte">Per te · ' + esc(p.perte[x.id]) + '</span>') : '';
          return '<div class="rs-p' + (ok ? ' ok' : (sk ? ' sk' : '')) + '">' + spunta + '<div>' + pt + '<b>' + esc(x.t) + '</b>' + (ok ? '' : '<small>' + esc(x.s) + '</small>')
            + (ok || sk ? '' : '<div class="rs-btns"><button type="button" class="rs-go" onclick="rscVai(\'' + x.id + '\')">' + esc(x.btn) + '</button><button type="button" class="rs-skip" onclick="rscSalta(\'' + x.id + '\')">Salta</button></div>') + '</div></div>';
        }).join('') + '</div></div>';
  }).join('');
  return '<div class="rs"><div class="rs-top"><div><small>Riscaldamento</small><b>' + st.fatti + ' di ' + st.n + ' fatti</b></div><div class="rs-bar"><i style="width:' + Math.round(st.fatti / st.n * 100) + '%"></i></div></div>' + gruppi + '</div>';
}
/* VIVE IN START (0.9.177): e' la guida ai primi passi, e START e' dove si comincia la giornata. */
function rscPaint(){
  /* 0.9.293: anche nella pagina della partita (paRisc), oltre a START */
  const html = rscHtml();
  ['stRisc', 'mppRisc', 'paRisc'].forEach(function(id){ const h = document.getElementById(id); if (h && h.innerHTML !== html) h.innerHTML = html; });
}
(function(){
  /* 0.9.293, Andrea: "il riscaldamento in START ha zero margine sopra e sotto, e' attaccato alle altre sezioni" */
  const st = document.createElement('style');
  st.textContent = '#stRisc:not(:empty),#mppRisc:not(:empty){margin:26px 0}#paRisc:not(:empty){margin:0}';
  document.head.appendChild(st);
})();
document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia'){ rscPaint(); try{ wgStato(); }catch(_){ } } });

/* ---------- IL WIDGET della serie di Full Focus (FocusWidget.java) ----------
   Due battute del Genio, poi la richiesta al launcher. Il numero si aggiorna a ogni apertura
   dell'app e a ogni sessione finita. */
function wgSerie(){ try{ return (typeof sdSerieMappa === 'function') ? sdSerieMappa() : 0; }catch(_){ return 0; } }
/* 0.9.304, Andrea: "come Duolingo: Buongiorno Andrea, Buon pomeriggio, Buonasera; piu' avanti, se la tappa manca,
   La mappa ti aspetta; con la tappa fatta, A domani". La frase la sceglie il widget con l'ora del telefono
   (FocusWidget.saluto), cosi' cambia da sola anche ad app chiusa: da qui partono il nome e il giorno della tappa. */
function wgNome(){
  let n = '';
  try{ if (typeof dvPrimoNome === 'function') n = dvPrimoNome() || ''; }catch(_){ }
  try{ if (!n && typeof nvNome === 'function') n = nvNome() || ''; }catch(_){ }
  n = String(n).trim();
  return n ? n.charAt(0).toUpperCase() + n.slice(1) : '';
}
function wgAggiorna(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.widgetSet) return;
    const n = wgSerie();
    const dati = { serie: n, nome: wgNome() };
    try{ if (typeof sdTappeOggi === 'function' && typeof sdK === 'function') dati.tappa = sdTappeOggi() > 0 ? sdK(Date.now()) : ''; }catch(_){ }
    NATIVE.widgetSet(dati)
      .then(function(r){ if (r && r.pinned > 0){ try{ localStorage.setItem('fl_widget_on', '1'); }catch(_){ } } }).catch(function(){ });
  }catch(_){ }
}
async function wgStato(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.widgetState) return;
    const r = await NATIVE.widgetState();
    const era = rscHa('fl_widget_on');
    if (r && r.pinned > 0){ localStorage.setItem('fl_widget_on', '1'); if (!era) rscPaint(); }
  }catch(_){ }
}
function wgApri(){
  let w = document.getElementById('wgSheet');
  if (!w){ w = document.createElement('div'); w.id = 'wgSheet'; w.className = 'wg-sheet'; w.addEventListener('click', function(e){ if (e.target === w) w.remove(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="wg-in"><img src="img/genio/genio-saluta.png" alt=""><h3>Farò il tifo per te dalla tua schermata iniziale</h3>'
    + '<p>Ti ricorderò di tornare, così diventa un\u2019abitudine. Il widget occupa due icone e conta i giorni di fila in cui completi almeno una tappa della mappa.</p>'
    + '<div class="wg-prova"><span>🔥</span><b>' + wgSerie() + '</b><small>giorni di fila</small></div>'
    /* 0.9.260: i widget vinti nelle mystery box, da scegliere */
    + ((typeof wgSkinSbloccate === 'function' && wgSkinSbloccate().length) ? '<div class="wg-skin-row"><button type="button" class="giorno' + (wgSkinAttiva() ? '' : ' on') + '" onclick="wgSkinUsa(\'\');wgApri()">Uno al giorno</button>' + wgSkinSbloccate().map(function(id){ return '<button type="button" class="' + (wgSkinAttiva() === id ? 'on' : '') + '" style="background-image:url(img/widget/skin-' + id + '.jpg)" aria-label="' + wgSkinNome(id) + '" onclick="wgSkinUsa(\'' + id + '\');wgApri()"></button>'; }).join('') + '</div>' : '')
    + '<button type="button" class="cta" onclick="wgMetti()">Aggiungi il widget</button>'
    + '<button type="button" class="wg-link" onclick="document.getElementById(\'wgSheet\').remove()">Non ora</button></div>';
}
async function wgMetti(){
  const w = document.getElementById('wgSheet'); if (w) w.remove();
  wgAggiorna();
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.widgetPin){ toast('Disponibile nell\'app installata'); return; }
  try{
    const r = await NATIVE.widgetPin();
    if (r && !r.asked) toast('Tieni premuto sulla schermata iniziale, poi Widget, poi DreamMap');
  }catch(_){ toast('Tieni premuto sulla schermata iniziale, poi Widget, poi DreamMap'); }
  /* al rientro dal launcher si guarda se c'e' davvero */
  setTimeout(wgStato, 2500); setTimeout(wgStato, 8000);
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden){ wgAggiorna(); setTimeout(wgStato, 600); } });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(wgAggiorna, 5000); });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(rscPaint, 700); });

(function(){
  const css = [
    '.rs{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:16px;display:flex;flex-direction:column;gap:8px}body.dark .rs{background:#12203A;border-color:#22345A}',
    /* la testata al centro, con aria fra l'etichetta e il conto */
    '.rs-top{display:flex;flex-direction:column;align-items:center;gap:10px;margin:2px 0 8px;text-align:center}.rs-top small{display:block;margin-bottom:6px;font:700 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}.rs-top b{display:block;font:800 18px var(--font-display);color:var(--navy)}body.dark .rs-top b{color:#fff}.rs-top > div:not(.rs-bar){display:flex;flex-direction:column;align-items:center}.rs-bar{width:100%;display:block}.rs-bar i{margin:0}',
    '.rs-bar{height:8px;border-radius:4px;background:var(--blue-soft,#E3F1FF);overflow:hidden}.rs-bar i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#3F9FF4,#0075E3);transition:width .5s}body.dark .rs-bar{background:rgba(255,255,255,.1)}',
    '.rs-g{border:1px solid var(--line);border-radius:16px;overflow:hidden}body.dark .rs-g{border-color:#22345A}',
    '.rs-gh{display:flex;align-items:center;gap:10px;width:100%;padding:12px 14px;border:0;background:transparent;cursor:pointer;text-align:left;color:var(--navy)}body.dark .rs-gh{color:#fff}',
    '.rs-gn{width:26px;height:26px;flex:none;border-radius:13px;background:var(--blue-soft,#E3F1FF);color:#0075E3;display:flex;align-items:center;justify-content:center;font:800 12px var(--font-display)}',
    '.rs-gh b{flex:1;font:700 14.5px var(--font-body)}.rs-gh small{font:600 12px var(--font-body);color:var(--muted)}',
    '.rs-gin{display:none;padding:0 12px 12px;border-top:1px solid var(--line)}.rs-g.on .rs-gin{display:block}',
    '.rs-p{display:flex;gap:10px;padding:12px 2px;border-bottom:1px solid var(--line)}.rs-p:last-child{border-bottom:0}',
    '.rs-p.ok{opacity:.7}.rs-p.sk{opacity:.4}.rs-p.ok b{text-decoration:line-through;text-decoration-thickness:2px;color:var(--muted)}',
    /* la spunta vuota e' vuota: bordo grigio; piena e' verde */
    '.rs-check{border:2px solid var(--line);background:transparent;cursor:pointer;padding:0;color:transparent;transition:background .2s,border-color .2s}body.dark .rs-check{border-color:#3A4A66}.rs-check.on,body.dark .rs-check.on{background:#1B9E6A;border-color:#1B9E6A;color:#fff}',
    '.rs-ico{width:34px;height:34px;flex:none;border-radius:12px;background:var(--bg,#F4F9FF);display:flex;align-items:center;justify-content:center;font-size:18px}.rs-p.ok .rs-ico{background:#1B9E6A;color:#fff;font:800 16px var(--font-body)}body.dark .rs-ico{background:rgba(255,255,255,.06)}',
    '.rs-p > div{flex:1;min-width:0}.rs-p b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .rs-p b{color:#fff}.rs-p small{display:block;margin-top:2px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.rs-perte{display:inline-block;margin-bottom:4px;padding:3px 8px;border-radius:99px;background:#FFF1D6;color:#A86A00;font:700 10.5px var(--font-body)}',
    '.rs-btns{display:flex;align-items:center;gap:12px;margin-top:8px}',
    '.rs-go{border:0;border-radius:99px;background:#0075E3;color:#fff;padding:9px 16px;font:700 13px var(--font-body);cursor:pointer}',
    '.rs-skip{border:0;background:none;color:var(--muted);font:600 12px var(--font-body);cursor:pointer;padding:6px 0}',
    '.wg-sheet{position:fixed;inset:0;z-index:9994;background:rgba(0,8,20,.7);display:flex;align-items:flex-end;justify-content:center}',
    '.wg-in{width:100%;max-width:460px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:22px 20px calc(24px + env(safe-area-inset-bottom));text-align:center}body.dark .wg-in{background:#141C2C}',
    '.wg-in img{height:120px;width:auto}.wg-in h3{margin:10px 0 8px;font:800 21px/1.25 var(--font-display);color:var(--navy)}body.dark .wg-in h3{color:#fff}.wg-in p{margin:0 0 16px;font:500 14px/1.55 var(--font-body);color:var(--muted)}',
    '.wg-prova{display:flex;align-items:center;gap:10px;width:210px;margin:0 auto 18px;padding:12px 16px;border-radius:22px;background:linear-gradient(180deg,#3F9FF4,#0075E3);color:#fff;text-align:left}.wg-prova span{font-size:24px}.wg-prova b{font:800 26px var(--font-display)}.wg-prova small{font:600 11.5px/1.3 var(--font-body)}',
    '.wg-link{display:block;width:100%;margin-top:8px;border:0;background:transparent;color:var(--muted);font:600 13px var(--font-body);cursor:pointer;padding:10px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
