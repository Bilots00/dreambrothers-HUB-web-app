/* ===========================================================================================
   IL CONFRONTO NEL REPORT (0.9.325, Andrea: "come Sweatcoin: eri al 99% del tuo ritmo abituale, ti sei mosso come il 30% degli
   utenti; e come Suitcase il podio con le schede della classifica, che porta alla Lega").

   Due pezzi, in cima e in fondo alla pagina Report:
   - il tuo ritmo abituale: il tempo sul telefono di adesso contro la tua media (numeri tuoi, dal telefono);
   - come stai rispetto agli altri: la curva degli utenti con la tua bolla sopra, su Full Focus, tappe, serie e modalità severa.
     I numeri sono quelli del server (/social/confronto). Con meno di cinque persone il confronto non si mostra: un 100% su tre
     persone non vuol dire niente. Solo l'amministratore vede un'anteprima simulata, con la scritta che lo dice.
   Prefisso rcf-.
   =========================================================================================== */
const RCF = { met: 'ff', dati: {}, at: {}, cl: 'serie' };
const RCF_MET = [['ff', 'Full Focus'], ['tappe', 'Tappe'], ['serie', 'Serie'], ['severa', 'Modalità severa']];
function rcfEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function rcfOre(ms){ const m = Math.round((ms || 0) / 60000); if (m < 60) return m + ' min'; return Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm'; }
function rcfVal(met, v){ if (met === 'ff') return rcfOre((v || 0) * 60000); if (met === 'tappe') return v === 1 ? '1 tappa' : v + ' tappe'; return v === 1 ? '1 giorno' : v + ' giorni'; }
function rcfSimulato(met){
  const b = [], tot = 240; for (let i = 0; i < 24; i++) b.push(Math.max(1, Math.round(38 * Math.exp(-i / 5))));
  const nomi = [['Sara', 'x1'], ['Luca', 'x2'], ['Marta', 'x3']];
  const v = { ff: [640, 510, 420], tappe: [34, 28, 21], serie: [58, 41, 23], severa: [44, 30, 19] }[met] || [10, 8, 6];
  return { n: tot, mio: { ff: 95, tappe: 6, serie: 3, severa: 2 }[met] || 1, rank: 148, sotto: 38, max: v[0], buckets: b, top: nomi.map(function(x, i){ return { nome: x[0], device: x[1], v: v[i] }; }), simulato: true };
}
async function rcfCarica(met){
  if (RCF.dati[met] && Date.now() - (RCF.at[met] || 0) < 300000) return RCF.dati[met];
  let r = null;
  try{ if (typeof frApi === 'function') r = await frApi('GET', '/api/focuslock/social/confronto?device=' + encodeURIComponent(frDevice()) + '&met=' + met); }catch(_){ r = null; }
  if ((!r || !(r.n >= 5)) && typeof flAdmin === 'function' && flAdmin()) r = rcfSimulato(met);
  RCF.dati[met] = r; RCF.at[met] = Date.now();
  return r;
}

/* ---------------------------------------------------------------- il tuo ritmo abituale */
async function rcfSomma(da, a){
  try{
    const t = await NATIVE.getTopApps({ from: da, to: a, limit: 60, by: 'ms', icons: 0 });
    return ((t && t.apps) || []).reduce(function(s, x){ return s + (x && !x.self ? (x.ms || 0) : 0); }, 0);
  }catch(_){ return 0; }
}
async function rcfRitmoHtml(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return '';
  const G = 86400000, ora = Date.now(), zero = new Date(); zero.setHours(0, 0, 0, 0);
  const vista = (typeof INS !== 'undefined' && INS.view) || 'giorno';
  let etOra = 'Oggi', etMedia = 'Media di due settimane', ms = 0, media = 0;
  if (vista === 'giorno'){
    ms = await rcfSomma(zero.getTime(), ora);
    /* fino a quest'ora: la mattina non si confronta con giornate intere */
    media = (await rcfSomma(zero.getTime() - 14 * G, zero.getTime())) / 14 * Math.max(.1, (ora - zero.getTime()) / G);
    etMedia = 'Di solito, a quest’ora';
  } else if (vista === 'settimana'){
    ms = (await rcfSomma(ora - 7 * G, ora)) / 7; media = (await rcfSomma(ora - 35 * G, ora - 7 * G)) / 28;
    etOra = 'Questa settimana, al giorno'; etMedia = 'Il mese prima, al giorno';
  } else {
    ms = (await rcfSomma(ora - 30 * G, ora)) / 30; media = (await rcfSomma(ora - 120 * G, ora - 30 * G)) / 90;
    etOra = 'Ultimo mese, al giorno'; etMedia = 'I tre mesi prima, al giorno';
  }
  if (!(media > 60000)) return '';
  const pct = Math.round(ms / media * 100), giu = pct <= 100;
  return '<section class="rcf"><span class="rcf-fr ' + (giu ? 'giu' : 'su') + '" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="' + (giu ? 'M12 5v14M6 13l6 6 6-6' : 'M12 19V5M6 11l6-6 6 6') + '"/></svg></span>'
    + '<h3>Sei al ' + pct + '% del tuo tempo abituale</h3><i class="rcf-l"></i>'
    + '<div class="rcf-g"><div><small class="on">' + etOra + '</small><b>' + rcfOre(ms) + '</b></div><div><small>' + etMedia + '</small><b>' + rcfOre(media) + '</b></div></div></section>';
}

/* ---------------------------------------------------------------- tu rispetto agli altri */
function rcfCurvaSvg(d){
  const b = d.buckets || [], max = Math.max.apply(null, b.concat([1])), W = 320, H = 96, st = W / Math.max(1, b.length - 1);
  const pt = b.map(function(v, i){ return [i * st, H - v / max * (H - 6)]; });
  const linea = pt.map(function(p, i){ return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' ');
  const f = d.max > 0 ? Math.min(1, (d.mio || 0) / d.max) : 0, x = f * W;
  return '<div class="rcf-c"><span class="rcf-av" style="left:' + (f * 100).toFixed(1) + '%">' + ((typeof flAvMio === 'function' && flAvMio()) || '<span class="am-av me">Tu</span>') + '<b>' + rcfEsc(rcfVal(RCF.met, d.mio || 0)) + '</b></span>'
    + '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" preserveAspectRatio="none" aria-hidden="true"><path d="' + linea + ' L' + W + ' ' + H + ' L0 ' + H + 'Z" fill="rgba(140,198,255,.2)"/><path d="' + linea + '" fill="none" stroke="#8CC6FF" stroke-width="1.500"/><path d="M' + x.toFixed(1) + ' 0V' + H + '" stroke="#8CC6FF" stroke-width="1.500"/></svg>'
    + '<div class="rcf-assi"><span>0</span><span>' + rcfEsc(rcfVal(RCF.met, d.max || 0)) + '</span></div></div>';
}
function rcfAltriHtml(d){
  const pills = '<div class="rcf-pills">' + RCF_MET.map(function(m){ return '<button type="button" class="' + (RCF.met === m[0] ? 'on' : '') + '" onclick="rcfScegli(\'' + m[0] + '\')">' + m[1] + '</button>'; }).join('') + '</div>';
  if (!d) return '<section class="rcf">' + pills + '<p class="rcf-p">Il confronto con gli altri compare appena ci sono abbastanza persone.</p></section>';
  return '<section class="rcf">' + pills + (d.simulato ? '<small class="rcf-sim">Anteprima con numeri simulati: solo tu la vedi</small>' : '')
    /* 0.9.326, Andrea: "c'e' troppo testo, e la bolla e' attaccata al testo": la scheda dice gia' di cosa si parla */
    + '<h3>Meglio del <em>' + d.sotto + '%</em> degli utenti</h3>' + rcfCurvaSvg(d) + '</section>';
}
function rcfScegli(m){ RCF.met = m; try{ flVibra(8); }catch(_){ } rcfAltriPaint(); }
async function rcfAltriPaint(){
  const h = document.getElementById('rcfAltri'); if (!h) return;
  const d = await rcfCarica(RCF.met);
  if (document.getElementById('rcfAltri') === h) h.innerHTML = rcfAltriHtml(d);
}
/* 0.9.326, Andrea: "non sono i blocchi principali: in fondo alla pagina, e i blocchi scuri alternati ai chiari, cosi' si rompe il pattern".
   Scuro, l'ultimo blocco chiaro del Report, scuro; poi il pannello delle statistiche globali. Stando in fondo, quando arrivano non spostano niente. */
async function rcfMetti(){
  const body = document.getElementById('insBody'); if (!body) return;
  const ab = document.getElementById('rpAbitudini') || body.querySelector(':scope > .rp-blk:last-of-type'); if (!ab) return;
  /* 0.9.332, Andrea: "sotto al tempo in cui sei sveglio, nel paragrafo delle abitudini, dopo la fascia oraria: li' e' contestualizzato". Il confronto con gli altri va nella Lega */
  let r = document.getElementById('rcfRitmo');
  if (!r){ r = document.createElement('div'); r.id = 'rcfRitmo'; }
  const picco = ab.querySelector('.ins-picco');
  const dopo = picco ? picco.nextSibling : null, casa = picco ? picco.parentElement : ab;
  if (r.parentElement !== casa || (picco && r.previousElementSibling !== picco)) casa.insertBefore(r, dopo);
  const vista = (typeof INS !== 'undefined' && INS.view) || '';
  if (r.dataset.v !== vista){ r.dataset.v = vista; r.innerHTML = await rcfRitmoHtml(); }
}
/* LA LEGA (0.9.332): il podio sopra alla classifica quando si ordina per serie o per modalita' severa, senza il pulsante (la classifica e' li' sotto); il grafico dopo la classifica */
const RCF_DA_ORD = { ff: 'ff', tappe: 'tappe', serie: 'serie', severa: 'severa' };
async function rcfLegaPaint(ord){
  if (RCF_DA_ORD[ord]) RCF.met = RCF_DA_ORD[ord];
  rcfAltriPaint();
  const h = document.getElementById('frPodio');
  if (h && (ord === 'serie' || ord === 'severa')){
    const d = await rcfCarica(ord);
    const q = document.getElementById('frPodio');
    if (q) q.innerHTML = rcfPodioCorpo(d, ord, false);
  }
}

/* ---------------------------------------------------------------- la classifica, seconda slide del pannello globale */
/* 0.9.332, come Suitcase: chi e' in cima sta in mezzo alla fiamma, il podio ha i numeri, e sotto una riga dice quanto manca a te */
const RCF_FIAMMA = '<svg class="rcf-fi" viewBox="0 0 100 130" aria-hidden="true"><path d="M50 2c6 22 32 34 38 66 4 26-14 58-38 60C26 126 8 96 12 68c3-20 15-28 20-44 5 10 9 14 13 16 2-14 2-26 5-38z" fill="url(#rcfFG)"/><path d="M50 52c3 12 18 20 20 38 2 16-8 32-20 32S30 106 32 90c1-11 8-16 11-24 2 4 4 6 5 7 1-7 1-14 2-21z" fill="#FFD9B0" opacity=".75"/><defs><linearGradient id="rcfFG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E63946"/><stop offset="1" stop-color="#FF9A3D"/></linearGradient></defs></svg>';
function rcfPodioCorpo(d, cl, conPulsante){
  if (!d || !d.top || !d.top.length) return '<p class="rcf-p">La classifica compare appena ci sono abbastanza persone.</p>';
  const t = d.top, ord = [t[1], t[0], t[2]].filter(Boolean), alt = t.length >= 3 ? [2, 1, 3] : [1, 2];
  const col = function(x, i){ const pos = alt[i]; return '<div class="rcf-col p' + pos + '"><span class="rcf-col-av">' + (cl === 'serie' ? RCF_FIAMMA : '') + ((typeof frAv === 'function') ? frAv(x.nome, x.device, pos === 1 ? 'lg' : '') : '') + '</span><b>' + rcfEsc(x.nome) + '</b><small>' + (cl === 'serie' ? '🔥' : '🔒') + ' ' + x.v + '</small><i>' + pos + '</i></div>'; };
  /* la riga per te: quanto manca al primo che ti sta davanti */
  const davanti = t.filter(function(x){ return x.v > (d.mio || 0); }).pop();
  const nome = cl === 'serie' ? 'serie' : 'modalità severa';
  const tuo = !(d.mio > 0)
    ? '<div class="rcf-tuo"><div><b>' + (cl === 'serie' ? 'La tua serie è spenta' : 'Oggi niente modalità severa') + '</b><small>' + (davanti ? (davanti.v - (d.mio || 0) + 1) + ' giorni di fila e superi ' + rcfEsc(davanti.nome) + '.' : 'Un giorno oggi e sei in classifica.') + '</small></div><button type="button" onclick="' + (cl === 'serie' ? "goId('s-home');switchTab('mappa')" : "goId('s-home');switchTab('sveglia')") + '">Comincia</button></div>'
    : (davanti ? '<div class="rcf-tuo"><div><b>Sei a ' + d.mio + ' giorni di ' + nome + '</b><small>Altri ' + (davanti.v - d.mio + 1) + ' e superi ' + rcfEsc(davanti.nome) + '.</small></div></div>' : '');
  return '<div class="rcf-pod">' + ord.map(col).join('') + '</div><p class="rcf-rank"><b>#' + d.rank + '</b> nel mondo' + (d.simulato ? ' · anteprima' : '') + '</p>' + tuo
    + (conPulsante ? '<button type="button" class="rcf-cta" onclick="rcfVediClassifica()">Vedi la classifica</button>' : '');
}
function rcfPodioHtml(d){
  const sch = '<div class="rcf-sch"><button type="button" class="' + (RCF.cl === 'serie' ? 'on' : '') + '" onclick="rcfClasse(\'serie\')">🔥 Serie</button><button type="button" class="' + (RCF.cl === 'severa' ? 'on' : '') + '" onclick="rcfClasse(\'severa\')">🔒 Modalità severa</button></div>';
  return sch + rcfPodioCorpo(d, RCF.cl, true);
}
/* 0.9.326, Andrea: "se scelgo la classifica della modalita' severa, la Lega deve essere gia' ordinata cosi'" */
function rcfVediClassifica(){
  try{ if (typeof FR !== 'undefined') FR.legaOrd = RCF.cl; }catch(_){ }
  if (typeof frOpen === 'function') frOpen('lega');
}
function rcfClasse(k){ RCF.cl = k; try{ flVibra(8); }catch(_){ } rcfPodioPaint(); }
async function rcfPodioPaint(){
  const h = document.getElementById('rcfPodio'); if (!h) return;
  const d = await rcfCarica(RCF.cl);
  const q = document.getElementById('rcfPodio'); if (q) q.innerHTML = rcfPodioHtml(d);
}
function rcfCarDot(c){ const d = c.nextElementSibling, i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)); if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); }

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.sg-car > .sg-pan{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:24px 18px;border:1px solid var(--line);border-radius:22px;background:var(--card);color:var(--ink);text-align:center;font:inherit;cursor:pointer}.sg-car > .sg-pan .sg-pan-i{width:58px;height:58px;border-radius:50%}.sg-car > .sg-pan .sg-pan-t{flex:none}.sg-car > .sg-pan .sg-pan-t b{font:800 19px/1.25 var(--font-display);color:var(--navy)}body.dark .sg-car > .sg-pan .sg-pan-t b{color:#fff}.sg-car > .sg-pan .sg-pan-t small{margin-top:6px;font-size:14px}.sg-car > .sg-pan .sg-pan-c{display:none}',
    '.rcf-podio-lega .rcf-pod,#rcfPodio .rcf-pod{margin-top:34px}.rcf-podio-lega{padding:16px;margin:0 0 14px;border-radius:22px;background:linear-gradient(170deg,#0B2A63,#001E44);color:#fff;text-align:center}.rcf-altri-lega{margin-top:18px}.rcf-col-av{position:relative;display:flex;align-items:center;justify-content:center;min-height:64px}.rcf-col-av .am-av{position:relative;z-index:1}.rcf-fi{position:absolute;left:50%;bottom:-6px;width:74px;margin-left:-37px}.rcf-col.p1 .rcf-fi{width:104px;margin-left:-52px}.rcf-tuo{display:flex;align-items:center;gap:12px;margin:12px 0 0;padding:14px;border-radius:16px;border:1px solid rgba(188,224,255,.3);background:rgba(188,224,255,.1);text-align:left}.rcf-tuo > div{flex:1;min-width:0}.rcf-tuo b{display:block;font:800 15px var(--font-display);color:#fff}.rcf-tuo small{display:block;margin-top:3px;font:500 13px/1.35 var(--font-body);color:#BFD3EC}.rcf-tuo button{flex:none;padding:11px 14px;border:0;border-radius:12px;background:#E63946;color:#fff;font:800 13.5px var(--font-body);cursor:pointer}',
    '#rcfRitmo{margin:14px 0}#rcfAltri{margin:18px 0}.rcf{position:relative;margin:0;padding:20px 18px;border-radius:22px;background:linear-gradient(170deg,#0B2A63,#001E44);color:#fff;text-align:left}',
    '.rcf h3{margin:0;padding-right:50px;font:800 25px/1.2 var(--font-display);color:#fff}.rcf h3 em{font-style:normal;color:#8CC6FF}.rcf-p{margin:8px 0 0;font:500 13.5px/1.4 var(--font-body);color:#BFD3EC}',
    '.rcf-fr{position:absolute;right:16px;top:18px;width:42px;height:42px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:#fff}.rcf-fr.giu{color:#1B9E6A}.rcf-fr.su{color:#E63946}',
    '.rcf-l{display:block;height:1px;margin:16px 0;background:rgba(255,255,255,.16)}.rcf-g{display:grid;grid-template-columns:1fr 1fr;gap:16px 14px}.rcf-g small{display:block;font:600 12.5px/1.3 var(--font-body);color:#BFD3EC}.rcf-g small.on{color:#8CC6FF}.rcf-g b{display:block;margin-top:3px;font:800 20px var(--font-display);color:#fff}',
    '.rcf-pills{display:flex;gap:6px;margin:0 -18px 16px;padding:0 18px;overflow-x:auto;scrollbar-width:none}.rcf-pills::-webkit-scrollbar{display:none}.rcf-pills button{flex:none;padding:8px 14px;border:1px solid rgba(255,255,255,.25);border-radius:99px;background:none;color:#D6E8FF;font:700 13px var(--font-body);cursor:pointer}.rcf-pills button.on{background:#fff;border-color:#fff;color:#001E44}',
    '.rcf-sim{display:block;margin-bottom:8px;font:600 11.5px var(--font-body);color:#8CC6FF}',
    '.rcf-c{position:relative;margin-top:92px}.rcf-av{position:absolute;bottom:100%;transform:translateX(-50%);margin-bottom:-2px;display:flex;flex-direction:column;align-items:center;gap:2px;white-space:nowrap}.rcf-av .am-av{width:34px;height:34px;font-size:13px;box-shadow:0 0 0 2px #8CC6FF}.rcf-av b{font:800 12.5px var(--font-body);color:#8CC6FF}.rcf-c svg{display:block;height:96px}.rcf-assi{display:flex;justify-content:space-between;margin-top:6px;font:600 12px var(--font-body);color:#BFD3EC}',
    '.sg-car-w{margin:0 0 12px}.sg-car{display:flex;gap:10px;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.sg-car::-webkit-scrollbar{display:none}.sg-car > *{flex:0 0 100%;box-sizing:border-box;scroll-snap-align:center;min-width:0}.sg-car .sg-pan{margin:0}.sg-car-d{display:flex;justify-content:center;gap:7px;margin-top:10px}.sg-car-d i{width:7px;height:7px;border-radius:50%;background:#C9D9EE}.sg-car-d i.on{background:#0075E3}body.dark .sg-car-d i{background:#2C4170}body.dark .sg-car-d i.on{background:#8CC6FF}',
    '#rcfPodio{padding:16px;border-radius:22px;background:linear-gradient(170deg,#0B2A63,#001E44);color:#fff;text-align:center}.rcf-sch{display:flex;gap:6px;justify-content:center;margin-bottom:14px}.rcf-sch button{padding:8px 12px;border:0;border-bottom:2.5px solid transparent;background:none;color:#BFD3EC;font:700 13.5px var(--font-body);cursor:pointer}.rcf-sch button.on{color:#fff;border-bottom-color:#FF8A3D}',
    '.rcf-pod{display:flex;align-items:flex-end;justify-content:center;gap:8px}.rcf-col{flex:1;max-width:100px;display:flex;flex-direction:column;align-items:center;gap:3px;min-width:0}.rcf-col b{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:700 13px var(--font-body);color:#fff}.rcf-col small{font:700 12.5px var(--font-body);color:#8CC6FF}.rcf-col i{display:flex;align-items:center;justify-content:center;width:100%;margin-top:6px;border-radius:12px 12px 0 0;background:rgba(255,255,255,.1);font:900 22px var(--font-display);font-style:normal;color:#FF8A3D}.rcf-col.p1 i{height:74px}.rcf-col.p2 i{height:52px}.rcf-col.p3 i{height:38px}',
    '.rcf-rank{margin:14px 0 10px;font:600 14px var(--font-body);color:#D6E8FF}.rcf-rank b{font:900 20px var(--font-display);color:#fff}.rcf-cta{display:block;width:100%;padding:12px;border:0;border-radius:14px;background:#8CC6FF;color:#001E44;font:800 14.5px var(--font-body);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();
