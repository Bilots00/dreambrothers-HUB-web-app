/* ===========================================================================================
   LA CRONOLOGIA DEI BLOCCHI (0.9.300, Andrea)

   "Nel Report, da Personalizza pagina, un blocco facoltativo (solo se l'utente lo sceglie) che
   porta a una pagina nuova: lo storico dei blocchi e dei programmi scattati. Quale app, sito o
   funzione, quando, e quale regola o programma l'ha fatto scattare."

   I dati sono del motore (RegistroBlocchi.java): ogni blocco vero, con l'ora, la cosa fermata
   (per un sito solo il dominio) e la regola, per 30 giorni, solo sul telefono. Qui si leggono
   (NATIVE.getRegistroBlocchi) e si mostrano. Niente e' inventato: senza motore la pagina lo dice.

   Il blocco del Report si chiama rpCrono ed e' registrato in Personalizza (SCS_BLOCCHI_REPORT) come
   facoltativo: entra spento. Si mette nella pagina prima che report-blocchi.js la ordini, e se e'
   spento non legge niente. Prefisso crb-.
   =========================================================================================== */

const CRB = { items: null, filtro: 'tutti', da: 's-home', cancella: 0 };
const CRB_FILTRI = [['tutti', 'Tutti'], ['app', 'App'], ['sito', 'Siti'], ['funzione', 'Funzioni'], ['altro', 'Altro']];
const CRB_ICO = {
  indietro: '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  chev: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>',
  scudo: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.2-7.5 9.5-4.3-1.3-7.5-4.9-7.5-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/></svg>',
  orologio: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 2"/></svg>',
  globo: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="8.6"/><path d="M3.4 12h17.2M12 3.4c2.4 2.4 3.6 5.3 3.6 8.6s-1.2 6.2-3.6 8.6c-2.4-2.4-3.6-5.3-3.6-8.6S9.6 5.8 12 3.4z"/></svg>',
  ingranaggio: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.6M12 18.6v2.6M4.2 7.4l2.2 1.3M17.6 15.3l2.2 1.3M4.2 16.6l2.2-1.3M17.6 8.7l2.2-1.3"/></svg>'
};
const CRB_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

registerScreen('s-cronoblocchi',
  '<div class="topbar"><button class="iconbtn" aria-label="Indietro" onclick="crbIndietro()">' + CRB_ICO.indietro + '</button><b class="blk-title">Cronologia dei blocchi</b></div>'
  + '<div class="crb-page" id="crbBody"><p class="crb-vuoto">Leggo la cronologia…</p></div>'
  + '<div class="spacer"></div>', { back: function(){ return CRB.da || 's-home'; } });

function crbIndietro(){
  if (typeof flIndietro === 'function') { flIndietro(); return; }
  goId(CRB.da || 's-home');
}

/** Apre la pagina. {@code da} e' la schermata a cui torna l'indietro di riserva. */
async function crbApri(da){
  CRB.da = da || 's-home';
  CRB.filtro = 'tutti';
  goId('s-cronoblocchi');
  await crbCarica(true);
  crbDipingi();
}

async function crbCarica(forza){
  if (CRB.items && !forza) return CRB.items;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getRegistroBlocchi){ CRB.items = null; return null; }
  try{ const r = await NATIVE.getRegistroBlocchi({ days: 30 }); CRB.items = (r && r.items) || []; }
  catch(_){ CRB.items = []; }
  return CRB.items;
}

function crbGruppo(x){
  const k = x.k || 'app';
  if (k === 'app' || k === 'sito' || k === 'funzione') return k;
  return 'altro';
}
function crbOra(t){ const d = new Date(t || 0); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function crbGiornoKey(t){ const d = new Date(t || 0); d.setHours(0, 0, 0, 0); return d.getTime(); }
function crbGiornoNome(k){
  const oggi = crbGiornoKey(Date.now());
  if (k === oggi) return 'Oggi';
  const ieri = new Date(oggi); ieri.setDate(ieri.getDate() - 1);
  if (k === ieri.getTime()) return 'Ieri';
  const d = new Date(k);
  return d.getDate() + ' ' + CRB_MESI[d.getMonth()];
}
function crbMaiuscola(s){ s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }

/* ---------------------------------------------------------------------------------------
   IL MOTIVO INTERO (0.9.302, Andrea)
   "Per WhatsApp dice Blocco funzionalita' ma non dice quale funzionalita' ha bloccato; e non dice mai la parola
   chiave o il sito che ha fatto scattare il blocco, dice solo il programma. Deve essere specifico: tutta la
   condizione e la parola chiave che hanno fatto scattare quel blocco."
   Il motore scrive (RegistroBlocchi.motivo): rt = tipo di regola, pn = programma, w = parola chiave, s = sito della
   regola, q = quando e' in vigore o il limite finito, ql = limite finito, g = dove (ricerca, indirizzo, pagina,
   schermo, titolo, riaperta, app, limite), fk = la funzione. I blocchi scritti prima della 0.9.302 hanno solo
   r ("Programma X (limite finito)", "Blocco funzionalita' (limite di 30 min finito)"): da li' si ricava quello che c'e'.
   --------------------------------------------------------------------------------------- */

/** Il motivo, anche per le righe vecchie: {rt, pn, w, s, q, ql, g}. */
function crbMotivo(x){
  const r = String(x.r || '');
  const m = { rt: x.rt || '', pn: x.pn || '', w: x.w || '', s: x.s || '', q: x.q || '', ql: !!x.ql, g: x.g || '' };
  if (!m.rt){
    let mm;
    if (/^Programma /.test(r)){ m.rt = 'programma'; m.pn = r.replace(/^Programma /, '').replace(/ \(limite finito\)$/, ''); m.ql = / \(limite finito\)$/.test(r); }
    else if ((mm = /^Blocco funzionalit. \(limite di (\d+) min finito\)/.exec(r))){ m.rt = 'funzione'; m.q = mm[1] + ' minuti al giorno'; m.ql = true; }
    else if (/^Blocco funzionalit/.test(r)) m.rt = 'funzione';
    else if (r === 'Blocco rapido') m.rt = 'rapido';
    else if (r === 'Parola chiave') m.rt = 'lista';
    else if (r === 'Filtro per adulti') m.rt = 'adulti';
    else if (/^Modalit. severa/.test(r)) m.rt = 'severa';
    else if (r === 'Sessione di concentrazione') m.rt = 'fullfocus';
    else m.rt = 'dreammap';
    /* nelle righe vecchie in c c'era quello che si leggeva: la parola della regola o un pezzo di testo */
    if (x.k === 'parola' && x.c && !m.w){ if (/\s/.test(x.c.trim()) || x.c.length > 24) m.letto = x.c; else m.w = x.c; }
  }
  return m;
}

/** L'articolo della funzione ("gli" Stati di WhatsApp), per dirla in una frase. */
function crbArticolo(nome){
  const p = String(nome || '').toLowerCase().split(' ')[0];
  const A = { stati: 'gli', shorts: 'gli', reels: 'i', commenti: 'i', canali: 'i', storie: 'le', feed: 'il', marketplace: 'il', picture: 'il', scheda: 'la', esplora: 'la' };
  return A[p] || '';
}
/** "su" + articolo: sugli, sui, sulle, sul, sulla. */
function crbSu(art){ return { gli: 'sugli', i: 'sui', le: 'sulle', il: 'sul', la: 'sulla' }[art] || 'su'; }
/** "per" + articolo: "per gli Stati di WhatsApp". */
function crbConArticolo(nome){ const a = crbArticolo(nome); return (a ? a + ' ' : '') + nome; }

/** Il nome intero della funzione, anche per le righe vecchie ("stati" + WhatsApp = "Stati di WhatsApp"). */
function crbNomeFunzione(x){
  const c = String(x.c || '').trim(), n = String(x.n || '').trim();
  if (!c) return n || 'Una funzione';
  if (x.fk || / di | in /.test(c) || !n || c.toLowerCase().indexOf(n.toLowerCase()) >= 0) return crbMaiuscola(c);
  return crbMaiuscola(c) + ' di ' + n;
}

/** Il nome della regola, la riga piccola colorata sotto il titolo. */
function crbRegolaNome(x, m){
  switch (m.rt){
    case 'programma': return 'Programma "' + m.pn + '"';
    case 'rapido': return 'Blocco rapido';
    case 'lista': return x.k === 'app' ? 'Le tue app bloccate' : (m.s && !m.w ? 'I tuoi siti bloccati' : 'Le tue parole chiave');
    case 'adulti': return 'Filtro per contenuti per adulti';
    case 'consentite': return 'Solo app e siti consentiti';
    case 'fullfocus': return 'Full Focus';
    case 'funzione': return 'Blocco funzionalità';
    case 'severa': return 'Modalità severa';
    case 'browser': return 'Browser che DreamMap non riesce a leggere';
    default: return x.r && x.r !== 'Regola di DreamMap' ? x.r : 'Una regola di DreamMap';
  }
}

/** Cosa l'ha fatto scattare, con la parola o il sito, in una frase. Vuota se non c'e' una parola o un sito. */
function crbScatto(x, m){
  const w = m.w ? '"' + m.w + '"' : '';
  const adulti = m.rt === 'adulti' || x.k === 'adulti';
  const pc = adulti ? 'la parola per adulti ' + w : 'la parola chiave ' + w;
  if (w){
    switch (m.g){
      case 'ricerca': return 'La ricerca conteneva ' + pc + '.';
      case 'indirizzo': return 'L\'indirizzo della pagina conteneva ' + pc + '.';
      case 'pagina': return 'La pagina conteneva ' + pc + '.';
      case 'titolo': return 'Un titolo sullo schermo conteneva ' + pc + '.';
      case 'riaperta': return 'Hai riaperto una pagina con ' + pc + '.';
      default: return 'Sullo schermo c\'era ' + pc + '.';
    }
  }
  if (m.s){
    if (m.g === 'ricerca' || m.g === 'schermo' || m.g === 'titolo') return 'Sullo schermo c\'era il sito ' + m.s + '.';
    return (m.g === 'riaperta' ? 'Hai riaperto il sito ' : 'Hai aperto il sito ') + m.s + '.';
  }
  if (x.k === 'sito' && x.c) return (m.g === 'riaperta' ? 'Hai riaperto ' : 'Hai aperto ') + x.c + '.';
  if (m.letto) return 'Sullo schermo c\'era "' + m.letto + '".';
  if (adulti) return m.g === 'ricerca' ? 'La ricerca conteneva parole per adulti.' : 'La pagina mostrava parole per adulti.';
  if (m.g === 'riaperta') return 'Hai riaperto una pagina fermata poco prima.';
  return '';
}

/** Perche' la regola era in vigore: il programma con il suo orario o il limite finito, il Blocco rapido, ... */
function crbVigore(x, m){
  const app = x.n || 'l\'app';
  switch (m.rt){
    /* il nome del programma e' gia' nella riga colorata subito sopra: qui non si ripete */
    case 'programma':
      if (m.ql) return m.q ? 'Hai finito i ' + m.q + ' che questo programma ti concede.' : 'Hai finito il tempo che questo programma ti concede.';
      if (m.q === 'sempre') return 'Il programma è sempre attivo.';
      if (m.q) return 'Il programma è attivo ' + m.q + '.';
      return 'Il programma era attivo a quell\'ora.';
    case 'rapido': return 'Il Blocco rapido era acceso.';
    case 'lista':
      if (x.k === 'app') return crbMaiuscola(app) + ' è fra le app che blocchi sempre.';
      if (m.w) return 'È una delle parole chiave che blocchi sempre.';
      if (m.letto) return 'Conteneva una delle parole chiave che blocchi sempre.';
      if (m.s) return 'È uno dei siti che blocchi sempre.';
      return 'È fra le cose che blocchi sempre.';
    case 'adulti': return 'Il filtro per contenuti per adulti è acceso.';
    case 'consentite':
      return m.s ? 'Il sito ' + m.s + ' non è fra i siti consentiti.' : crbMaiuscola(app) + ' non è fra le app consentite.';
    case 'fullfocus': return 'Durante il Full Focus si aprono solo le app consentite.';
    case 'funzione': {
      const f = crbConArticolo(crbNomeFunzione(x));
      if (m.ql) return m.q ? 'Hai finito i ' + m.q + ' che ti concedi per ' + f + '.' : 'Hai finito il tempo che ti concedi per ' + f + '.';
      return 'Hai scelto di bloccare ' + (m.q === 'sempre' ? 'sempre ' : '') + f + '.';
    }
    case 'severa':
      return x.n === 'Impostazioni del telefono' ? 'La modalità severa tiene chiuse le Impostazioni del telefono.' : 'La modalità severa è accesa e tiene chiusa questa pagina.';
    case 'browser': return 'Hai scelto di bloccare i browser di cui DreamMap non riesce a leggere le pagine.';
    default: return '';
  }
}

/** Cosa e' stato fermato (il titolo), la regola (riga colorata) e il perche' intero (la frase sotto). */
function crbTesti(x){
  const k = x.k || 'app', nome = x.n || '', cosa = x.c || '';
  const m = crbMotivo(x);
  const su = nome ? ' su ' + nome : '';
  let t;
  if (k === 'sito') t = (cosa || 'Un sito') + su;
  else if (k === 'funzione') t = crbNomeFunzione(x);
  else if (k === 'parola') t = m.g === 'ricerca' ? 'Una ricerca' + su : ((m.g === 'schermo' || m.g === 'titolo' || !m.g) ? 'Un contenuto' + su : 'Una pagina' + su);
  else if (k === 'adulti') t = (m.g === 'ricerca' ? 'Una ricerca per adulti' : 'Una pagina per adulti') + su;
  else t = nome || 'Un\'app';
  const frase = [crbScatto(x, m), crbVigore(x, m)].filter(Boolean).join(' ');
  return { t: t, l: crbRegolaNome(x, m), s: frase };
}

/** La voce di "Chi li ha fatti scattare": la regola con la sua parola, il suo sito o la sua condizione. */
function crbChi(x){
  const m = crbMotivo(x);
  const per = m.w ? ' per la parola chiave "' + m.w + '"' : (m.s ? ' per il sito ' + m.s : '');
  switch (m.rt){
    case 'programma': {
      const base = 'Programma "' + m.pn + '"';
      if (per) return base + per;
      if (m.ql) return base + (m.q ? ' per il limite di ' + m.q : ' per il limite finito');
      if (m.q === 'sempre') return base + ' sempre attivo';
      if (m.q) return base + ' attivo ' + m.q;
      return base;
    }
    case 'funzione': {
      const f = crbNomeFunzione(x);
      return 'Blocco funzionalità ' + crbSu(crbArticolo(f)) + ' ' + f + (m.ql && m.q ? ' (limite di ' + m.q + ')' : '');
    }
    case 'rapido': return 'Blocco rapido' + per;
    case 'lista':
      if (m.w) return 'La tua parola chiave "' + m.w + '"';
      if (m.s) return 'Il tuo sito bloccato ' + m.s;
      return x.k === 'app' && x.n ? crbMaiuscola(x.n) + ' fra le app bloccate' : 'Le tue app bloccate';
    case 'adulti': return 'Filtro per contenuti per adulti' + (m.w ? ' per la parola "' + m.w + '"' : '');
    default: return crbRegolaNome(x, m);
  }
}
function crbIcona(x){
  if (x.p && x.k !== 'sito' && x.k !== 'impostazioni'){
    if (typeof socE === 'function' && socE(x.p) && typeof socIcona === 'function') return socIcona(x.p, 'soc-ico crb-ico');
    return '<img class="ub-appico crb-ico" data-pkg="' + esc(x.p) + '" alt="">';
  }
  return '<span class="crb-ico crb-ico-s">' + (x.k === 'sito' ? CRB_ICO.globo : (x.k === 'impostazioni' ? CRB_ICO.ingranaggio : CRB_ICO.scudo)) + '</span>';
}

function crbFiltra(k){ CRB.filtro = k; crbDipingi(); }

function crbDipingi(){
  const box = document.getElementById('crbBody'); if (!box) return;
  if (CRB.items === null){
    box.innerHTML = '<p class="crb-vuoto">La cronologia dei blocchi si legge nell\'app installata sul telefono.</p>';
    return;
  }
  const tutti = CRB.items || [];
  const oggi = crbGiornoKey(Date.now());
  const nOggi = tutti.filter(function(x){ return crbGiornoKey(x.t) === oggi; }).length;

  /* in alto: quanti oggi, quanti in 30 giorni (una cosa principale, poi il dettaglio) */
  let html = '<div class="crb-testa"><span class="crb-testa-i">' + CRB_ICO.scudo + '</span><div>'
    + '<b>' + nOggi + (nOggi === 1 ? ' blocco oggi' : ' blocchi oggi') + '</b>'
    + '<small>' + tutti.length + (tutti.length === 1 ? ' blocco' : ' blocchi') + ' negli ultimi 30 giorni</small></div></div>';

  /* le regole e i programmi che sono scattati, dal piu' frequente */
  const per = {};
  tutti.forEach(function(x){ const r = crbChi(x); per[r] = (per[r] || 0) + 1; });
  const regole = Object.keys(per).sort(function(a, b){ return per[b] - per[a]; }).slice(0, 5);
  if (regole.length){
    html += '<p class="crb-sez">Chi li ha fatti scattare</p><div class="crb-regole">'
      + regole.map(function(r){
          return '<div><span>' + esc(r) + '</span><b>' + per[r] + (per[r] === 1 ? ' volta' : ' volte') + '</b></div>';
        }).join('') + '</div>';
  }

  html += '<p class="crb-sez">Ogni blocco</p>';
  html += '<div class="crb-chips riga-scorre" id="crbChips">' + CRB_FILTRI.map(function(f){
    return '<button type="button" class="' + (CRB.filtro === f[0] ? 'on' : '') + '" onclick="crbFiltra(\'' + f[0] + '\')">' + f[1] + '</button>';
  }).join('') + '</div>';

  const lista = tutti.filter(function(x){ return CRB.filtro === 'tutti' || crbGruppo(x) === CRB.filtro; });
  if (!lista.length){
    html += '<p class="crb-vuoto">' + (tutti.length ? 'Nessun blocco di questo tipo negli ultimi 30 giorni.' : 'Ancora nessun blocco. Qui compare ogni app, sito o funzione che DreamMap ferma.') + '</p>';
  } else {
    let giorno = -1;
    lista.slice(0, 400).forEach(function(x){
      const g = crbGiornoKey(x.t);
      if (g !== giorno){
        if (giorno !== -1) html += '</div>';
        giorno = g;
        const n = lista.filter(function(y){ return crbGiornoKey(y.t) === g; }).length;
        html += '<div class="crb-giorno"><b>' + crbGiornoNome(g) + '</b><small>' + n + (n === 1 ? ' blocco' : ' blocchi') + '</small></div><div class="crb-lista">';
      }
      const tx = crbTesti(x);
      html += '<div class="crb-r">' + crbIcona(x)
        + '<div class="crb-r-t"><b>' + esc(tx.t) + '</b><em class="crb-r-l">' + esc(tx.l) + '</em>' + (tx.s ? '<small>' + esc(tx.s) + '</small>' : '') + '</div>'
        + '<span class="crb-r-h">' + crbOra(x.t) + '</span></div>';
    });
    if (giorno !== -1) html += '</div>';
  }
  if (tutti.length){
    html += '<button type="button" class="crb-canc" id="crbCanc" onclick="crbCancella()">'
      + (CRB.cancella && Date.now() - CRB.cancella < 4000 ? 'Tocca di nuovo per cancellare tutto' : 'Cancella la cronologia') + '</button>';
  }
  html += '<p class="crb-nota">La cronologia resta solo su questo telefono, per 30 giorni. Dei siti si tiene il dominio, non l\'indirizzo intero.</p>';
  /* la riga dei filtri resta dove l'avevi portata: ridisegnando ripartiva dall'inizio */
  const vecchia = document.getElementById('crbChips'), sx = vecchia ? vecchia.scrollLeft : 0;
  box.innerHTML = html;
  const nuova = document.getElementById('crbChips');
  if (nuova){
    if (typeof scorreAllinea === 'function') try{ scorreAllinea(nuova); }catch(_){ }
    nuova.scrollLeft = sx;
    const on = nuova.querySelector('button.on');
    if (on && on.offsetLeft + on.offsetWidth > nuova.scrollLeft + nuova.clientWidth) on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  if (typeof ubFillIcons === 'function') try{ ubFillIcons(box); }catch(_){ }
  if (typeof socIconeRiempi === 'function') try{ socIconeRiempi(box); }catch(_){ }
}

/* Due tocchi, non una finestra: il primo chiede conferma sul pulsante stesso, il secondo cancella. */
async function crbCancella(){
  if (!(CRB.cancella && Date.now() - CRB.cancella < 4000)){
    CRB.cancella = Date.now();
    crbDipingi();
    setTimeout(function(){ if (CRB.cancella && Date.now() - CRB.cancella >= 4000){ CRB.cancella = 0; crbDipingi(); } }, 4100);
    return;
  }
  CRB.cancella = 0;
  try{ if (NATIVE && NATIVE.clearRegistroBlocchi) await NATIVE.clearRegistroBlocchi(); }catch(_){ }
  CRB.items = [];
  crbDipingi();
  if (typeof toast === 'function') toast('Cronologia cancellata');
}

/* ---------------------------------------------------------------------------------------
   IL BLOCCO NEL REPORT (facoltativo: lo si aggiunge da Personalizza la pagina Report)
   --------------------------------------------------------------------------------------- */
function crbCardHtml(){
  return '<div class="ins-card crb-link" role="button" onclick="crbApri(\'s-home\')">'
    + '<span class="crb-link-i">' + CRB_ICO.orologio + '</span>'
    + '<div><b>Cronologia dei blocchi</b><small id="crbCardTxt">Ogni app, sito e funzione fermata, con la regola</small></div>'
    + '<span class="crb-link-c">' + CRB_ICO.chev + '</span></div>';
}
function crbCardMetti(){
  const body = document.getElementById('insBody'); if (!body) return;
  if (!body.querySelector(':scope > .rp-blk, :scope > .rp-mk')) return;
  let b = document.getElementById('rpCrono');
  if (!b){
    b = document.createElement('div'); b.id = 'rpCrono'; b.className = 'rp-blk';
    b.innerHTML = crbCardHtml();
    const dopo = body.querySelector(':scope > #sgPannello') || body.querySelector(':scope > .hd-piede') || body.querySelector(':scope > #insShareText');
    body.insertBefore(b, dopo || null);
  }
}
async function crbCardRiempi(){
  const b = document.getElementById('rpCrono');
  if (!b || b.classList.contains('scs-off')) return;
  const it = await crbCarica(true);
  const el = document.getElementById('crbCardTxt'); if (!el || !it) return;
  const oggi = crbGiornoKey(Date.now());
  const di = it.filter(function(x){ return crbGiornoKey(x.t) === oggi; });
  el.textContent = di.length
    ? (di.length + (di.length === 1 ? ' blocco oggi' : ' blocchi oggi') + ', l\'ultimo alle ' + crbOra(di[0].t))
    : 'Oggi DreamMap non ha ancora fermato niente';
}
(function(){
  /* il blocco nell'elenco di Personalizza la pagina Report: facoltativo, entra spento */
  try{
    if (typeof SCS_BLOCCHI_REPORT !== 'undefined' && !SCS_BLOCCHI_REPORT.some(function(x){ return x.id === 'rpCrono'; })){
      SCS_BLOCCHI_REPORT.push({ id: 'rpCrono', ico: '🕘', n: 'La cronologia dei blocchi', s: 'Ogni blocco, quando e con quale regola', facoltativo: true });
    }
  }catch(_){ }
  /* prima che report-blocchi.js ordini la pagina, il blocco c'e' gia' */
  const aggancia = function(){
    if (typeof rpbApplica !== 'function' || rpbApplica.__crb) return;
    const vero = rpbApplica;
    const g = function(){ try{ crbCardMetti(); }catch(_){ } const r = vero.apply(this, arguments); try{ crbCardRiempi(); }catch(_){ } return r; };
    g.__crb = true; window.rpbApplica = g; try{ rpbApplica = g; }catch(_){ }
  };
  aggancia(); setTimeout(aggancia, 500);

  const st = document.createElement('style');
  st.textContent = [
    '.crb-page{padding:4px 2px 0}',
    '.crb-testa{display:flex;align-items:center;gap:14px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:16px;margin:4px 0 6px}',
    '.crb-testa-i{flex:none;width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:rgba(0,117,227,.1);color:#0075E3}',
    '.crb-testa b{display:block;font:800 20px var(--font-display,var(--font-body));color:var(--navy)}',
    '.crb-testa small{display:block;font:500 13px var(--font-body);color:var(--muted);margin-top:2px}',
    '.crb-sez{margin:22px 0 10px;font:700 17px var(--font-display,var(--font-body));color:#0075E3}',
    '.crb-regole{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:2px 14px}',
    '.crb-regole > div{display:flex;justify-content:space-between;gap:12px;padding:11px 0;border-bottom:1px solid var(--line);font:600 13.5px var(--font-body);color:var(--navy)}',
    '.crb-regole > div:last-child{border-bottom:0}',
    '.crb-regole b{flex:none;color:var(--muted);font-weight:700}',
    '.crb-chips{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px;margin-bottom:6px}',
    /* 0.9.302: la riga arriva al bordo dello schermo (classe riga-scorre in app.css), le pill non si tagliano piu' a meta' pagina */
    '.crb-chips button{flex:none;border:1.5px solid var(--line);background:var(--card);color:var(--navy);border-radius:99px;padding:7px 14px;font:700 13px var(--font-body);cursor:pointer}',
    '.crb-chips button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.crb-giorno{display:flex;align-items:baseline;justify-content:space-between;margin:16px 2px 8px}',
    '.crb-giorno b{font:700 15px var(--font-body);color:var(--navy)}',
    '.crb-giorno small{font:600 12px var(--font-body);color:var(--muted)}',
    '.crb-lista{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:2px 14px}',
    '.crb-r{display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-bottom:1px solid var(--line)}',
    '.crb-r > .crb-ico{margin-top:2px}',
    '.crb-r:last-child{border-bottom:0}',
    '.crb-ico{width:34px;height:34px;border-radius:9px;flex:none}',
    '.crb-ico-s{display:grid;place-items:center;background:rgba(0,117,227,.1);color:#0075E3}',
    '.crb-r-t{flex:1;min-width:0}',
    '.crb-r-t b{display:block;font:700 14px/1.35 var(--font-body);color:var(--navy);overflow-wrap:anywhere}',
    '.crb-r-t small{display:block;font:500 12.5px/1.45 var(--font-body);color:var(--muted);margin-top:3px}',
    '.crb-r-t .crb-r-l{display:block;font:700 12px/1.35 var(--font-body);font-style:normal;color:#0075E3;margin-top:3px;overflow-wrap:anywhere}',
    '.crb-r-h{flex:none;font:700 13px var(--font-body);color:var(--muted);margin-top:1px}',
    '.crb-vuoto{margin:14px 2px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.crb-canc{display:block;width:100%;margin:24px 0 8px;padding:13px;border-radius:14px;border:1.5px solid rgba(230,57,70,.4);background:none;color:#E63946;font:700 14px var(--font-body);cursor:pointer}',
    '.crb-nota{margin:6px 2px 0;font:500 12px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '#insBody > #rpCrono{margin-top:18px}',
    '.crb-link{display:flex;align-items:center;gap:12px;cursor:pointer}',
    '.crb-link > div{flex:1;min-width:0}',
    '.crb-link b{display:block;font:700 15px var(--font-body);color:var(--navy)}',
    '.crb-link small{display:block;font:500 12.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.crb-link-i{flex:none;width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:rgba(0,117,227,.1);color:#0075E3}',
    '.crb-link-c{flex:none;color:var(--muted);display:grid;place-items:center}',
    'body.dark .crb-testa,body.dark .crb-regole,body.dark .crb-lista,body.dark .crb-chips button{background:#12203A;border-color:#22345A}',
    'body.dark .crb-regole > div,body.dark .crb-r{border-color:#22345A}',
    'body.dark .crb-testa b,body.dark .crb-regole > div,body.dark .crb-giorno b,body.dark .crb-r-t b,body.dark .crb-chips button,body.dark .crb-link b{color:#fff}',
    'body.dark .crb-chips button.on{background:#0075E3;border-color:#0075E3}',
    'body.dark .crb-sez{color:#8CC6FF}',
    'body.dark .crb-r-t .crb-r-l{color:#6DB6FF}',
    'body.dark .crb-testa-i,body.dark .crb-ico-s,body.dark .crb-link-i{background:#0E1E3A;color:#6DB6FF}',
    'body.dark .crb-canc{color:#FF8A93;border-color:rgba(255,138,147,.45)}'
  ].join('\n');
  document.head.appendChild(st);
})();
