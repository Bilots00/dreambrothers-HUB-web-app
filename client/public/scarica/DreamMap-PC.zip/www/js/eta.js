/* ===========================================================================================
   IL NAVIGATORE — l'interfaccia e i fatti

   Questo file mette insieme i fatti dell'app (le task del foglio, i passi degli orizzonti, le
   sessioni di concentrazione, il lavoro al computer, le opzioni di viaggio) e li da' al motore
   (eta-motore.js). Poi disegna: il pannello dell'arrivo con il bollino «rispetto a ieri», il
   foglio dell'intervallo, la Timeline del viaggio con i ricalcoli spiegati, le leve, il te
   disciplinato, l'affidabilita', il controllo veicolo, l'imprevisto.

   IL BOLLINO NON E' UN CONTATORE DI RITARDO. Prima sotto alla data c'era «in ritardo · fermo
   da 60 giorni»: un numero cumulativo dalla prima previsione, che cresceva e basta (e a 60 si
   fermava, perche' il ciclo che lo contava si fermava a 60). Faceva venire l'ansia e non diceva
   niente su OGGI. Adesso il bollino e' come quello del tempo di schermo: la data di oggi contro
   quella con cui hai chiuso ieri. Verde se l'hai avvicinata, rosso se l'hai allontanata, grigio
   se e' ferma. Il perche' sta nella Timeline, ricalcolo per ricalcolo, con i numeri.

   CHI CALCOLA. Il telefono: e' dove ci sono le task, le sessioni e le opzioni. Il computer
   riceve tutto dallo specchio (specchio-web.js) e mostra; se calcola, calcola per mostrare, non
   scrive niente, altrimenti due registri si sovrascriverebbero a vicenda.

   LE CHIAVI su disco cominciano tutte con fl_eta_. Nessuna chiamata di rete: i testi stanno in
   content/eta.json dentro all'app.
   =========================================================================================== */

const ETA = { stato: null, testi: null, tab: 'ricalcoli', periodo: '7', ultimoDelta: null, pcOggi: null, t: 0, extra: null };
const ETA_K = {
  seme: 'fl_eta_seme', stato: 'fl_eta_stato', snap: 'fl_eta_snap', log: 'fl_eta_log', prima: 'fl_eta_prima',
  crediti: 'fl_eta_crediti', eventi: 'fl_eta_eventi', pausa: 'fl_eta_pausa', tappe: 'fl_eta_tappe',
  veicolo: 'fl_eta_veicolo', varianza: 'fl_eta_var', giorni: 'fl_eta_giorni', vita: 'fl_eta_vita_ok',
  testi: 'fl_eta_testi', prec: 'fl_eta_prec_migrata', pcmem: 'fl_eta_pc', dev: 'fl_eta_dev'
};
const ETA_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

/* ---------------------------------------------------------------------------------------
   Gli attrezzi
   --------------------------------------------------------------------------------------- */
function etaLeggi(k, def){ try{ const v = JSON.parse(localStorage.getItem(ETA_K[k] || k) || 'null'); return v === null ? def : v; }catch(_){ return def; } }
function etaScrivi(k, v){
  if (etaAutorita() !== 'telefono' && k !== 'testi' && k !== 'prec' && k !== 'vita') return;
  try{ localStorage.setItem(ETA_K[k] || k, JSON.stringify(v)); }catch(_){ }
}
function etaAutorita(){ try{ return (typeof pcQui === 'function' && pcQui() === 'desktop') ? 'specchio' : 'telefono'; }catch(_){ return 'telefono'; } }
function etaKey(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function etaMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function etaOggiK(){ return etaKey(Date.now()); }
function etaDaKey(k){ return new Date(k + 'T00:00:00').getTime(); }
function etaNorm(s){ return String(s || '').trim().toLowerCase().replace(/\s+/g, ' '); }
function etaEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function etaNum(x, dec){ return (Math.round(x * Math.pow(10, dec === undefined ? 1 : dec)) / Math.pow(10, dec === undefined ? 1 : dec)).toFixed(dec === undefined ? 1 : dec).replace('.', ','); }
function etaOreTxt(h){ return etaNum(h, 1) + ' h'; }
function etaDataTxt(ts, semplice){
  if (!isFinite(ts)) return '';
  const d = new Date(ts);
  return semplice ? (ETA_MESI[d.getMonth()] + ' ' + d.getFullYear()) : (d.getDate() + ' ' + ETA_MESI[d.getMonth()] + ' ' + d.getFullYear());
}
function etaOra(t){ const x = new Date(t); return String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); }

/* ---- i testi: content/eta.json, con una copia su disco per il primo disegno ---- */
function etaT(path, vars){
  let cur = ETA.testi;
  const parti = String(path).split('.');
  for (let i = 0; cur && i < parti.length; i++) cur = cur[parti[i]];
  if (cur === undefined || cur === null) return '';
  if (typeof cur !== 'string') return cur;
  return cur.replace(/\{(\w+)\}/g, function(m, k){ return (vars && vars[k] !== undefined) ? String(vars[k]) : m; });
}
async function etaTestiCarica(){
  if (!ETA.testi){ const c = etaLeggi('testi', null); if (c && c.card) ETA.testi = c; }
  try{
    const t = await (await fetch('content/eta.json')).json();
    if (t && t.card){
      const cambiati = JSON.stringify(t) !== JSON.stringify(ETA.testi || {});
      ETA.testi = t;
      try{ localStorage.setItem(ETA_K.testi, JSON.stringify(t)); }catch(_){ }
      if (cambiati) etaRidipingi(false);
    }
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   I FATTI
   --------------------------------------------------------------------------------------- */
/** Il viaggio: da quando, quanto e' lunga la strada, il seme. Null senza una lettura. */
function etaViaggio(){
  let L = null, d = null, o = null;
  try{ d = (typeof gnDati === 'function') ? gnDati() : null; }catch(_){ }
  try{ o = (typeof orLast === 'function') ? orLast() : null; }catch(_){ }
  const letto = !!((d && d.at) || (o && o.at));
  if (!letto) return null;
  try{ L = (typeof gnLettura === 'function') ? gnLettura() : null; }catch(_){ }
  const mesi = (L && L.mesi) || 12;
  let inizio = 0;
  try{ inizio = (typeof serInizioViaggio === 'function') ? serInizioViaggio() : 0; }catch(_){ }
  if (!inizio) inizio = (d && d.at) || (o && o.at) || Date.now();
  let seme = etaLeggi('seme', 0);
  if (!seme){ seme = ((inizio / 1000) | 0) ^ 0x5bd1e995; etaScrivi('seme', seme); }
  const target = (d && d.target) || (o && o.target) || '';
  const sc = d ? (+d.scadenza || 0) : 0;
  const cfg = ETA_CFG;
  return {
    inizio: inizio, mesi: mesi, seme: seme, target: target,
    /* 0.9.238: la strada gia' fatta ("Da dove parti?") accorcia il viaggio stimato dal Genio */
    W: mesi * cfg.oreSettimanaRiferimento * (365.25 / 12 / 7) * (1 - ((typeof ptzPct === 'function') ? ptzPct() : 0)),
    targetAt: sc ? inizio + sc * 30.4375 * 86400000 : 0,
    pedaggi: (function(){ try{ return !!serOpzioni().pedaggi; }catch(_){ return false; } })()
  };
}
/** Il piano: ore a settimana e giorni di lavoro, dalle opzioni di viaggio o dalla modalita'. */
function etaPiano(){
  let o = {};
  try{ o = (typeof serOpzioni === 'function') ? serOpzioni() : {}; }catch(_){ }
  let modalita = 'normale';
  try{ modalita = (typeof fsModalita === 'function') ? fsModalita() : (localStorage.getItem('fl_modalita') || 'normale'); }catch(_){ }
  const cfg = ETA_CFG;
  const ore = (+o.capacita > 0) ? +o.capacita : (cfg.capacita[modalita] || cfg.capacita.normale);
  const giorni = (Array.isArray(o.giorniLavoro) && o.giorniLavoro.length === 7) ? o.giorniLavoro.map(function(x){ return x ? 1 : 0; }) : cfg.giorniDiSerie.slice();
  const tot = giorni.reduce(function(a, b){ return a + b; }, 0);
  const alGiorno = giorni.map(function(g){ return tot ? ore * g / tot : 0; });
  return { oreSettimana: ore, giorni: giorni, alGiorno: alGiorno, nGiorni: tot, modalita: modalita, daOpzioni: +o.capacita > 0 };
}
/* ---- la pausa (imprevisto) ---- */
function etaPause(){ return etaLeggi('pausa', []) || []; }
function etaPausaAttiva(){ const p = etaPause(); const u = p[p.length - 1]; return (u && !u.a) ? u : null; }
function etaInPausa(k){ return etaPause().some(function(p){ return p && k >= p.da && (!p.a || k < p.a); }); }

/* ---- la stima di una task ---- */
function etaStimaDi(testo, day, tipo, livello){
  const cfg = ETA_CFG.stimaProvvisoria;
  let m = null;
  try{ if (typeof stMeta === 'function' && tipo !== 'oz') m = stMeta(testo, day); }catch(_){ }
  if (m && m.stima > 0) return { stimaMin: +m.stima, provvisoria: false };
  const x = String(testo || '').match(/(\d{1,3})\s*min/i);
  if (x) return { stimaMin: +x[1], provvisoria: false };
  if (tipo === 'oz') return { stimaMin: cfg.orizzonte[livello] || cfg.orizzonte.settimana, provvisoria: true };
  return { stimaMin: tipo === 'priorita' ? cfg.priorita : cfg.riga, provvisoria: true };
}
/** Le task aperte: le righe di oggi, la priorita', i passi degli orizzonti. */
function etaTaskAperte(){
  const out = [], visti = {};
  const oggi = etaOggiK();
  const metti = function(t){ const n = etaNorm(t.testo); if (!n || visti[n]) return; visti[n] = 1; out.push(t); };
  try{
    if (typeof stRigheDi === 'function'){
      stRigheDi(oggi).forEach(function(r){
        const fatta = (typeof stIsDone === 'function') && stIsDone(r, oggi);
        if (!fatta) metti(Object.assign({ tipo: 'riga', testo: r, day: oggi }, etaStimaDi(r, oggi, 'riga')));
      });
    }
  }catch(_){ }
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    const t = one && !one.done && one.task && (one.task.text || one.task);
    if (t) metti(Object.assign({ tipo: 'priorita', testo: String(t), day: oggi }, etaStimaDi(String(t), oggi, 'priorita')));
  }catch(_){ }
  try{
    const s = (typeof ozLeggi === 'function') ? ozLeggi() : {};
    Object.keys(s).forEach(function(k){
      if (k.indexOf('__') === 0 || k === 'adesso') return;
      (s[k].passi || []).forEach(function(p){ if (p && !p.fatto && p.t) metti(Object.assign({ tipo: 'oz', testo: p.t, livello: k }, etaStimaDi(p.t, '', 'oz', k))); });
    });
  }catch(_){ }
  return out;
}
/* ---- il registro dei crediti delle task chiuse ---- */
function etaCrediti(){ return etaLeggi('crediti', {}) || {}; }
function etaCreditoKey(tipo, testo, day){ return (tipo === 'oz' ? 'oz' : (day || etaOggiK())) + '|' + etaNorm(testo); }
/** Le sessioni collegate a una task: stessa intenzione, negli ultimi 14 giorni, non gia' usate. */
function etaSessioniDi(testo, usate){
  const n = etaNorm(testo);
  if (!n) return [];
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const da = Date.now() - 14 * 86400000;
  return h.filter(function(x){ return x && x.ok && !x.meditazione && x.at >= da && etaNorm(x.intent) === n && !(usate && usate[x.at]); });
}
/**
 * Accredita una task chiusa: la sua stima corretta dal fattore, oltre a quello che le sessioni
 * su di lei hanno gia' dato. Torna la voce, o null se era gia' accreditata.
 */
function etaAccredita(tipo, testo, day, livello){
  if (!etaNorm(testo)) return null;
  const reg = etaCrediti();
  const k = etaCreditoKey(tipo, testo, day);
  if (reg[k]) return null;
  const usate = {};
  Object.keys(reg).forEach(function(x){ (reg[x].sess || []).forEach(function(at){ usate[at] = 1; }); });
  const sess = etaSessioniDi(testo, usate);
  const legateMin = sess.reduce(function(a, x){ return a + (x.spentMs || 0) / 60000; }, 0);
  const st = etaStimaDi(testo, day, tipo === 'priorita' ? 'priorita' : (tipo === 'oz' ? 'oz' : 'riga'), livello);
  const f = (ETA.stato && ETA.stato.f) || ETA_CFG.fattoreStima.default;
  const extraOre = Math.max(0, st.stimaMin / 60 * f - legateMin / 60);
  const voce = { at: Date.now(), tipo: tipo, testo: String(testo).slice(0, 120), stimaMin: st.stimaMin, provvisoria: st.provvisoria,
                 legateMin: Math.round(legateMin), extraOre: Math.round(extraOre * 1000) / 1000, f: f, sess: sess.map(function(x){ return x.at; }) };
  reg[k] = voce;
  const keys = Object.keys(reg);
  if (keys.length > 800) keys.sort(function(a, b){ return reg[a].at - reg[b].at; }).slice(0, keys.length - 800).forEach(function(x){ delete reg[x]; });
  etaScrivi('crediti', reg);
  return voce;
}
/** Il credito torna nella strada (spunta ritirata, storno dell'arbitro). */
function etaScredita(tipo, testo, day){
  const reg = etaCrediti();
  const k = etaCreditoKey(tipo, testo, day);
  const v = reg[k];
  if (!v) return null;
  delete reg[k];
  etaScrivi('crediti', reg);
  return v;
}
/** Le misure del fattore di stima: task chiuse con del tempo collegato e una stima vera. */
function etaMisureStima(){
  const reg = etaCrediti();
  return Object.keys(reg).map(function(k){ return reg[k]; })
    .filter(function(v){ return v && !v.provvisoria && v.legateMin > 0 && v.stimaMin > 0; })
    .sort(function(a, b){ return a.at - b.at; })
    .map(function(v){ return { reale: v.legateMin / 60, stimato: v.stimaMin / 60 }; });
}
function etaVoti(){
  const out = [];
  try{ const all = (typeof stMetaAll === 'function') ? stMetaAll() : {}; Object.keys(all).forEach(function(k){ if (all[k] && all[k].voto) out.push(all[k].voto); }); }catch(_){ }
  return out;
}
/** Le ore pianificate scritte per settimana (per la scoperta): le stime delle righe dei giorni. */
function etaOreSettimane(){
  const cfg = ETA_CFG.scoperta;
  const sett = {};
  const oggi = etaMezzanotte();
  const lun = new Date(oggi); lun.setDate(lun.getDate() - (lun.getDay() + 6) % 7);   // lunedi' di questa settimana
  for (let i = 1; i <= cfg.settimane * 7; i++){
    const d = new Date(lun); d.setDate(d.getDate() - i);
    const t = d.getTime(), k = etaKey(t);
    let righe = [];
    try{ righe = (typeof stRigheDi === 'function') ? stRigheDi(k) : []; }catch(_){ }
    if (!righe.length) continue;
    const w = Math.floor((i - 1) / 7);
    sett[w] = (sett[w] || 0) + righe.reduce(function(a, r){ return a + etaStimaDi(r, k, 'riga').stimaMin / 60; }, 0);
  }
  const out = [];
  for (let w = cfg.settimane - 1; w >= 0; w--) if (sett[w] !== undefined) out.push(sett[w]);
  return out;
}
/* ---- i crediti per giorno: sessioni, computer, task ---- */
function etaPcConta(viaggio){
  const c = ETA_CFG.pcLavoro;
  return c.conta && viaggio && c.target.indexOf(viaggio.target) >= 0;
}
function etaCreditiPerGiorno(viaggio, piano){
  const g = {};
  const metti = function(k, campo, ore){ if (!(ore > 0)) return; g[k] = g[k] || { sess: 0, pc: 0, task: 0 }; g[k][campo] += ore; };
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  h.forEach(function(x){ if (x && x.ok && !x.meditazione && x.at >= viaggio.inizio) metti(etaKey(x.at), 'sess', (x.spentMs || 0) / 3600000); });
  if (etaPcConta(viaggio)){
    /* il computer manda solo gli ultimi 30 giorni, e all'avvio puo' non esserci ancora: le ore
       viste restano scritte qui, e un giorno gia' accreditato non torna mai a zero */
    const mem = etaLeggi('pcmem', {}) || {};
    let nuovo = false;
    if (typeof pcGiorno === 'function' && typeof pcChiave === 'function'){
      for (let off = 0; off < 30; off++){
        const d = pcGiorno(off);
        if (d && d.prod > 0){ const k = pcChiave(off), h = d.prod / 60; if (!(mem[k] >= h)){ mem[k] = h; nuovo = true; } }
      }
    }
    if (nuovo) etaScrivi('pcmem', mem);
    const nascita = etaMezzanotte(viaggio.inizio);
    Object.keys(mem).forEach(function(k){ if (etaDaKey(k) >= nascita) metti(k, 'pc', mem[k]); });
  }
  const reg = etaCrediti();
  Object.keys(reg).forEach(function(k){ const v = reg[k]; if (v && v.at >= viaggio.inizio) metti(etaKey(v.at), 'task', v.extraOre || 0); });
  /* 0.9.348, Andrea: "se l'utente aumenta il numero di decisioni prese, la data di arrivo deve adattarsi: i soldi amano la velocita'".
     Ogni decisione del giorno (collo.js, fl_decisioni_giorni) vale 3 minuti di strada, fino a mezz'ora; il tetto del giorno resta */
  try{ const dec = JSON.parse(localStorage.getItem('fl_decisioni_giorni') || '{}') || {}; const nascita = etaMezzanotte(viaggio.inizio); Object.keys(dec).forEach(function(k){ if (etaDaKey(k) >= nascita) metti(k, 'task', Math.min(10, +dec[k] || 0) * 0.05); }); }catch(_){ }
  /* il tetto giornaliero */
  const mediaPian = piano.oreSettimana / 7;
  Object.keys(g).forEach(function(k){
    const dow = new Date(etaDaKey(k)).getDay();
    const pian = piano.alGiorno[dow] > 0 ? piano.alGiorno[dow] : mediaPian;
    const tetto = ETA_CFG.creditoMaxAlGiorno * Math.max(0.5, pian);
    const tot = g[k].sess + g[k].pc + g[k].task;
    g[k].tot = Math.min(tot, tetto);
  });
  return g;
}
/** I giorni chiusi, dal piu' recente: pianificate, credito, pausa. */
function etaGiorniSerie(viaggio, piano, crediti){
  const out = [];
  const oggi = etaMezzanotte();
  const nascita = etaMezzanotte(viaggio.inizio);
  for (let eta = 1; eta <= ETA_CFG.rate.giorniStoria; eta++){
    const t = oggi - eta * 86400000;
    if (t < nascita) break;
    const k = etaKey(t);
    out.push({ eta: eta, k: k, pian: piano.alGiorno[new Date(t).getDay()], credito: (crediti[k] && crediti[k].tot) || 0, pausa: etaInPausa(k) });
  }
  return out;
}
/* ---- i segnali della qualita' ---- */
function etaSegnaliQ(){
  const seg = { sessioneMedia: null, quotaFinestra: null, cambiOra: null, passivo: null, veicolo: etaVeicoloEffetto() };
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const da = Date.now() - 14 * 86400000;
  const rec = h.filter(function(x){ return x && x.ok && !x.meditazione && x.at >= da; });
  if (rec.length >= 3) seg.sessioneMedia = rec.reduce(function(a, x){ return a + (x.spentMs || 0) / 60000; }, 0) / rec.length;
  try{
    if (typeof dpFinestre === 'function' && typeof dpGiorni === 'function'){
      const f = dpFinestre(dpGiorni());
      if (f && f.pronto && f.fasce && f.fasce.length && rec.length >= 3){
        const dentro = rec.filter(function(x){ const hh = new Date(x.start || x.at).getHours(); return f.fasce.some(function(b){ return hh >= b.da && hh < b.a; }); }).length;
        seg.quotaFinestra = dentro / rec.length;
        seg.finestre = f.fasce;
      }
    }
  }catch(_){ }
  try{
    const st = (typeof dpGiorni === 'function') ? dpGiorni() : {};
    const ks = Object.keys(st).sort().slice(-7);
    const v = ks.map(function(k){ return Array.isArray(st[k].fasce) ? st[k].fasce.reduce(function(a, b){ return a + b; }, 0) / 16 : null; }).filter(function(x){ return x !== null; });
    if (v.length >= 3) seg.cambiOra = v.reduce(function(a, b){ return a + b; }, 0) / v.length;
  }catch(_){ }
  return seg;
}
/* ---- gli indicatori anticipatori: i giorni sigillati con riserva e cambi ---- */
function etaSigilla(serie){
  if (etaAutorita() !== 'telefono') return;
  const g = etaLeggi('giorni', {}) || {};
  let st = {};
  try{ st = (typeof dpGiorni === 'function') ? dpGiorni() : {}; }catch(_){ }
  let cambiato = false;
  serie.forEach(function(d){
    if (g[d.k] && g[d.k].pian === d.pian && g[d.k].credito === d.credito) return;
    const r = st[d.k];
    g[d.k] = { pian: d.pian, credito: d.credito, pausa: d.pausa ? 1 : 0,
               riserva: r && typeof r.fine === 'number' ? r.fine : null,
               cambi: r && Array.isArray(r.fasce) ? r.fasce.reduce(function(a, b){ return a + b; }, 0) : null };
    cambiato = true;
  });
  const keys = Object.keys(g).sort();
  if (keys.length > 400){ keys.slice(0, keys.length - 400).forEach(function(k){ delete g[k]; }); cambiato = true; }
  if (cambiato) etaScrivi('giorni', g);
}
function etaIndicatori(){
  const g = etaLeggi('giorni', {}) || {};
  const ks = Object.keys(g).sort();
  const giorni = ks.map(function(k){ const d = g[k]; return (d && d.pian > 0 && !d.pausa) ? { rate: Math.min(2, d.credito / d.pian), riserva: d.riserva, cambi: d.cambi } : null; }).filter(Boolean);
  const ieri = g[etaKey(Date.now() - 86400000)] || null;
  return { giorni: giorni, ultimo: ieri && typeof ieri.riserva === 'number' ? { riserva: ieri.riserva, cambi: ieri.cambi || 0 } : null };
}
/* ---- i rinvii e i colli di bottiglia ---- */
function etaRimandi(testo){
  const n = etaNorm(testo);
  if (!n) return 0;
  const da = Date.now() - 30 * 86400000;
  let c = (etaLeggi('eventi', []) || []).filter(function(e){ return e && e.tipo === 'rimandata' && e.at >= da && etaNorm(e.testo) === n; }).length;
  const oggi = etaMezzanotte();
  for (let i = 1; i <= 30; i++){
    const k = etaKey(oggi - i * 86400000);
    let righe = [];
    try{ righe = (typeof stRigheDi === 'function') ? stRigheDi(k) : []; }catch(_){ }
    if (righe.some(function(r){ return etaNorm(r) === n; }) && !(typeof stIsDone === 'function' && stIsDone(testo, k))) c++;
  }
  return c;
}
function etaColli(task){
  let critica = '';
  try{ critica = etaNorm((typeof stTask === 'function') ? stTask() : ''); }catch(_){ }
  return task.filter(function(t){ return !t.fatta; }).map(function(t){ return { testo: t.testo, n: etaRimandi(t.testo), critico: etaNorm(t.testo) === critica }; })
    .filter(function(x){ return x.n >= ETA_CFG.collo.rimandi; });
}

/* ---------------------------------------------------------------------------------------
   IL CALCOLO
   --------------------------------------------------------------------------------------- */
function etaCalcola(){
  const cfg = ETA_CFG;
  const viaggio = etaViaggio();
  if (!viaggio) return null;
  const piano = etaPiano();
  const crediti = etaCreditiPerGiorno(viaggio, piano);
  const task = etaTaskAperte();
  const fs = etaFattoreStima(etaMisureStima(), etaVoti(), cfg);
  const sc = etaScoperta(etaOreSettimane(), cfg);
  const totCrediti = Object.keys(crediti).reduce(function(a, k){ return a + crediti[k].tot; }, 0);
  const lavoro = etaLavoro({ cfg: cfg, task: task, W: viaggio.W, crediti: totCrediti, f: fs.f, s: sc.s });
  const serie = etaGiorniSerie(viaggio, piano, crediti);
  etaSigilla(serie);
  const tassi = etaTassi(serie, cfg);
  const colli = etaColli(task);
  let varianza = +etaLeggi('varianza', cfg.varianza.default) || cfg.varianza.default;
  if (colli.some(function(c){ return c.critico; })) varianza = etaClamp(varianza * (1 + cfg.varianza.collo), cfg.varianza.min, cfg.varianza.max);
  /* IL FRENO CON UN NOME (0.9.210): chi ha fatto la sfida del sabotatore ha detto al Genio
     dove si inceppa. Quello che si sa non si indovina: l'intervallo si stringe del 15%. La
     data al centro non si muove: la spostano solo le cose che fai. */
  let freniNoti = false;
  try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : null; freniNoti = !!(b && b.primario); }catch(_){ }
  if (freniNoti) varianza = etaClamp(varianza * (1 - ((cfg.varianza && cfg.varianza.freni) || 0.15)), cfg.varianza.min, cfg.varianza.max);
  /* LA RADIOGRAFIA DEL PARADIGMA (0.9.212). Finche' i giorni veri sono pochi (la calibrazione,
     14 giorni) il passo di partenza non e' piu' uguale per tutti: lo decide la radiografia della
     sfida «Indovina il mio sabotatore». Un paradigma che frena forte fa partire piu' piano; uno
     leggero piu' svelto. Poi contano solo le abitudini misurate: se il paradigma e le abitudini
     restano gli stessi, la data resta (o peggiora); se cambiano, la data migliora. */
  const pool = etaPool(tassi.tassi, etaCfgParadigma(cfg), varianza);
  const seg = etaSegnaliQ();
  const q = etaQ(seg, cfg);
  const ind = etaIndicatori();
  const tilt = etaTilt(ind.giorni, ind.ultimo, cfg);
  const oggi = etaMezzanotte();
  const oggiK = etaOggiK();
  const pausa = etaPausaAttiva();
  const oreOggi = pausa ? 0 : Math.max(0, piano.alGiorno[new Date(oggi).getDay()] - ((crediti[oggiK] && crediti[oggiK].tot) || 0));
  const giorniMs = [];
  for (let i = 0; i < 400; i++){ const d = new Date(oggi); d.setDate(d.getDate() + i); giorniMs.push(d.getTime()); }
  /* IL FRENO: un giorno sposta la strada al massimo di un giorno di strada, e il passo al massimo
     del 3%. Quello che resta entra nei giorni seguenti. Non frena le scelte esplicite: una nuova
     lettura del Genio (W) o un nuovo piano (ore) ripartono da capo. */
  const ist = etaIstantaneaPrima();
  const esplicito = !ist || ist.W !== lavoro.W || ist.ore !== piano.oreSettimana;
  const nG = ist ? Math.max(1, ist.giorniFa) : 1;
  let R = lavoro.R, Qeff = q.Q, frenoR = 0;
  if (!esplicito && isFinite(ist.R) && isFinite(ist.crediti)){
    const tetto = Math.max(0, ist.R - (lavoro.crediti - ist.crediti)) + cfg.freno.stradaGiorni * (piano.oreSettimana / 7) * nG;
    if (R > tetto){ frenoR = R - tetto; R = tetto; }
  }
  const kMis = pool.media * q.Q;
  let k = kMis;
  if (!esplicito && ist.k > 0 && kMis > 0){
    const e = Math.min(0.9, cfg.freno.passoMax * nG);
    k = etaClamp(kMis, ist.k * (1 - e), ist.k * (1 + e));
    Qeff = q.Q * k / kMis;
  }
  lavoro.R = R; lavoro.pct = (lavoro.crediti + R) > 0 ? lavoro.crediti / (lavoro.crediti + R) : 0;
  const inp = { cfg: cfg, R: lavoro.R, oggi: oggi, adesso: Date.now(), oreOggi: oreOggi, piano: piano, pool: pool, Q: Qeff,
                tilt: { giorni: tilt.giorni, fattore: tilt.fattore }, seme: viaggio.seme, target: viaggio.targetAt, giorniMs: giorniMs };
  const sim = etaSimula(inp);
  /* LA MATEMATICA DEL NAVIGATORE (0.9.236, Andrea: "+43, -95 giorni da un giorno all'altro").
     Il freno di prima limitava il passo al 3% al giorno: su un viaggio di quattro anni sono 44
     giorni. Adesso la data d'arrivo parte dall'ancora di ieri e si sposta solo per quello che e'
     successo: ogni giornata chiusa la sposta di (1 - fatto / previsto) giorni.
       - fatto tutto il previsto: la data resta;  - niente: un giorno piu' in la';
       - il doppio: un giorno prima (al massimo due giorni prima in una giornata).
     E' la proporzione che ha chiesto Andrea: 0,5 / 1 / 2 / 3 tappe al giorno -> 2T / T / T÷2 / T÷3.
     Le pause e i giorni di riposo previsti non spostano niente. Oggi conta solo se hai gia' fatto piu'
     del previsto (la data si avvicina mentre lavori); il resto di oggi si conta a giornata chiusa.
     Una lettura nuova del Genio o un piano nuovo (ore) ripartono dalla simulazione: sono scelte. */
  const GIORNO = 86400000;
  const pianOggi = pausa ? 0 : (piano.alGiorno[new Date(oggi).getDay()] || 0);
  const fattoOggi = (crediti[oggiK] && crediti[oggiK].tot) || 0;
  const mediaLav = piano.nGiorni > 0 ? piano.oreSettimana / piano.nGiorni : 0;
  let oggiD = 0;
  if (pianOggi > 0 && fattoOggi > pianOggi) oggiD = -Math.min(2, (fattoOggi - pianOggi) / pianOggi);
  else if (!(pianOggi > 0) && fattoOggi > 0 && mediaLav > 0) oggiD = -Math.min(1, fattoOggi / mediaLav);
  let base = sim.p50, chiuse = 0;
  if (!esplicito && ist && isFinite(isFinite(ist.base) ? ist.base : ist.p50) && isFinite(sim.p50)){
    const base0 = isFinite(ist.base) ? ist.base : ist.p50;
    serie.forEach(function(d){
      if (!(d.eta >= 1 && d.eta <= nG) || d.pausa || !(d.pian > 0)) return;
      chiuse += etaClamp(1 - d.credito / d.pian, -2, 1);
    });
    base = base0 + chiuse * GIORNO;
  } else oggiD = 0;
  let p50 = isFinite(base) ? base + oggiD * GIORNO : sim.p50;
  /* LE DEVIAZIONI DI OGGI (0.9.285): le idee fuori rotta tenute e gli imprevisti spostano la data subito, come il
     navigatore quando esci dalla strada. Contano solo per la strada che ti portano via: le ore pianificate di
     oggi non ancora fatte e, per un imprevisto, i suoi giorni a venire. A giornata chiusa decide la giornata vera. */
  const dev = etaDevOggi(piano, pianOggi, fattoOggi);
  if (isFinite(p50) && dev.giorni > 0) p50 += dev.giorni * GIORNO;
  if (isFinite(p50) && p50 < Date.now()) p50 = Date.now();
  if (isFinite(p50) && isFinite(sim.p50)){
    const giu = Math.max(0, sim.p50 - sim.p10), su = Math.max(0, sim.p90 - sim.p50);
    sim.p10 = p50 - giu; sim.p90 = p50 + su; sim.p50 = p50;
    /* 0.9.304, LA CAUSA DELLE DUE DATE: qui "oltre" veniva riscritto con "la data supera la scadenza che hai scelto".
       Ma per tutte le viste "oltre" vuol dire "nessuna data: oltre 40 anni" (eta-motore.js: oltre = !isFinite(p50)).
       Con una scadenza di 6 mesi e un arrivo al 18 luglio 2028 la slideshow mostrava la data, la pagina della cartina
       "Oltre 40 anni di questo passo". Adesso sono due cose diverse: oltre (nessuna data) e oltreScadenza. */
    sim.oltre = false;
    sim.oltreScadenza = !!(viaggio.targetAt && p50 > viaggio.targetAt);
  }
  const stato = {
    at: Date.now(), giorno: oggiK, inizio: viaggio.inizio, pedaggi: viaggio.pedaggi, target: viaggio.targetAt,
    p10: sim.p10, p50: sim.p50, p90: sim.p90, oltre: !!sim.oltre, oltreScadenza: !!sim.oltreScadenza, senzaPiano: !!sim.senzaPiano, pTarget: sim.pTarget,
    R: lavoro.R, Rt: lavoro.Rt, Wp: lavoro.Wp, W: lavoro.W, crediti: lavoro.crediti, pct: lavoro.pct,
    aperteN: lavoro.aperteN, provvisorie: lavoro.provvisorie,
    f: fs.f, fN: fs.n, fFonte: fs.fonte, s: sc.s, sN: sc.n, Q: q.Q, qVoci: q.voci,
    rate: pool.media, rateSd: pool.sd, giorniDati: pool.n, calibrazione: pool.calibrazione, giorniMancanti: pool.giorniMancanti,
    piano: { oreSettimana: piano.oreSettimana, giorni: piano.giorni, nGiorni: piano.nGiorni },
    oreOggi: oreOggi, creditoOggi: (crediti[oggiK] && crediti[oggiK].tot) || 0, pcOggi: (crediti[oggiK] && crediti[oggiK].pc) || 0,
    pausa: pausa ? { da: pausa.da, motivo: pausa.motivo } : null, colli: colli, tilt: tilt.fattore, tiltN: tilt.n, varianza: varianza, freni: freniNoti, k: k, kMis: kMis, frenoR: frenoR,
    base: base, giorniChiusi: chiuse, giornoOggi: oggiD,
    dev: { giorni: dev.giorni, gIdee: dev.gIdee, gImpr: dev.gImpr, gRotta: dev.gRotta || 0, idee: dev.idee, impr: dev.impr,
           voci: dev.voci.slice(-6).map(function(v){ return { tipo: v.tipo, testo: String(v.testo || '').slice(0, 80), ore: v.ore }; }) }
  };
  ETA.inp = inp; ETA.serie = serie; ETA.tassi = tassi.tassi; ETA.seg = seg; ETA.task = task;
  return stato;
}
/** Una sintesi di uno stato, per il registro (prima → dopo). */
function etaSintesi(s){
  if (!s) return null;
  return { R: s.R, f: s.f, rate: s.rate, Q: s.Q, piano: s.piano && s.piano.oreSettimana, p50: s.p50, p10: s.p10, p90: s.p90, crediti: s.crediti, pct: s.pct };
}

/* ---------------------------------------------------------------------------------------
   IL RICALCOLO E IL REGISTRO
   --------------------------------------------------------------------------------------- */
function etaLog(){ return etaLeggi('log', []) || []; }
/**
 * Ricalcola e, se c'e' una causa, scrive la voce nel registro con lo scarto esatto.
 * Le voci con la stessa `chiave` nello stesso giorno si fondono (il lavoro al computer).
 */
function etaRicalcola(causa){
  const prima = ETA.stato || etaLeggi('stato', null);
  const dopo = etaCalcola();
  if (!dopo) return null;
  ETA.stato = dopo;
  etaScrivi('stato', dopo);
  if (!etaLeggi('prima', null)){
    etaScrivi('prima', { at: dopo.at, p10: dopo.p10, p50: dopo.p50, p90: dopo.p90, R: dopo.R });
  } else if (prima && causa){
    const finiti = isFinite(prima.p50) && isFinite(dopo.p50);
    const delta = finiti ? dopo.p50 - prima.p50 : null;
    const zeroOk = ['giornata', 'giornate', 'riposo', 'pausaGiorno', 'mollata', 'rimandata', 'imprevisto', 'ripresa', 'prima', 'genio', 'veicolo', 'deviazione', 'deviazioneTolta', 'imprevistoAgente'].indexOf(causa.tipo) >= 0;
    if (zeroOk || delta === null || Math.abs(delta) >= 60000){
      const log = etaLog();
      const oggiK = etaOggiK();
      const voce = { at: Date.now(), tipo: causa.tipo, testo: causa.testo || '', vars: causa.vars || {}, chiave: causa.chiave || '',
                     delta: delta, prima: etaSintesi(prima), dopo: etaSintesi(dopo) };
      const ultima = log[log.length - 1];
      if (causa.chiave && ultima && ultima.chiave === causa.chiave && etaKey(ultima.at) === oggiK && ultima.delta !== null && delta !== null){
        ultima.delta += delta; ultima.dopo = voce.dopo; ultima.at = voce.at; ultima.vars = voce.vars;
      } else log.push(voce);
      etaScrivi('log', log.slice(-ETA_CFG.registro.max));
    }
  }
  /* l'istantanea del giorno: l'ultimo valore calcolato oggi */
  const snap = etaLeggi('snap', {}) || {};
  /* 0.9.221: l'istantanea ricorda di quale sogno era. Un sogno nuovo (l'onboarding rifatto, un
     altro nome, un'altra meta) non si confronta con la data del sogno di prima: il bollino diceva
     «+655 giorni rispetto a ieri» a chi aveva solo cambiato sogno. */
  let sogno = ''; try{ const vg = etaViaggio(); sogno = vg ? etaNorm(vg.target) : ''; }catch(_){ }
  snap[dopo.giorno] = { p50: dopo.p50, p10: dopo.p10, p90: dopo.p90, R: dopo.R, at: dopo.at, crediti: dopo.crediti, k: dopo.k, W: dopo.W, ore: dopo.piano.oreSettimana, sogno: sogno, base: dopo.base };
  const ks = Object.keys(snap).sort();
  if (ks.length > 400) ks.slice(0, ks.length - 400).forEach(function(k){ delete snap[k]; });
  etaScrivi('snap', snap);
  etaTappeAggiorna();
  etaRidipingi(true);
  return dopo;
}
/** I numeri di un credito, per la frase «come l'ho calcolato». */
function etaVarsCredito(v){ return { stimaMin: v.stimaMin, legate: v.legateMin, ore: etaNum(v.extraOre, 1), f: etaNum(v.f, 2) }; }
function etaEvento(tipo, vars, testo, chiave){ return etaRicalcola({ tipo: tipo, vars: vars || {}, testo: testo || '', chiave: chiave || '' }); }

/** L'istantanea con cui confrontare oggi: quella di ieri, o l'ultima prima di oggi. */
/** Il prior della calibrazione scalato dalla radiografia del paradigma: da x1,15 (paradigma
    leggero) a x0,75 (paradigma che frena forte). Senza radiografia, quello di sempre. */
function etaCfgParadigma(cfg){
  let r = null; try{ r = (typeof bqLeggi === 'function') ? bqLeggi() : null; }catch(_){ r = null; }
  if (!r || !r.P) return cfg;
  const v = Object.keys(r.P).map(function(k){ return +r.P[k] || 0; }).sort(function(a, b){ return b - a; }).slice(0, 3);
  if (!v.length) return cfg;
  const intensita = Math.max(0, Math.min(1, v.reduce(function(a, x){ return a + x; }, 0) / v.length / 100));
  const f = 1.15 - 0.4 * intensita;
  const c = Object.assign({}, cfg); c.calibrazione = Object.assign({}, cfg.calibrazione, { priorValori: cfg.calibrazione.priorValori.map(function(x){ return x * f; }), priorMedia: cfg.calibrazione.priorMedia * f });
  return c;
}
function etaIstantaneaPrima(){
  const snap = etaLeggi('snap', {}) || {};
  const oggiK = etaOggiK();
  let sg = ''; try{ const vg = etaViaggio(); sg = vg ? etaNorm(vg.target) : ''; }catch(_){ }
  const ks = Object.keys(snap).filter(function(k){ return k < oggiK && !(sg && snap[k].sogno && snap[k].sogno !== sg); }).sort();
  if (!ks.length) return null;
  const k = ks[ks.length - 1];
  const giorniFa = Math.round((etaMezzanotte() - etaDaKey(k)) / 86400000);
  return { k: k, giorniFa: giorniFa, p50: snap[k].p50, p10: snap[k].p10, p90: snap[k].p90, R: snap[k].R, crediti: snap[k].crediti, k: snap[k].k, W: snap[k].W, ore: snap[k].ore, base: snap[k].base };
}
/**
 * 0.9.308, LO SPOSTAMENTO DELL'ARRIVO RISPETTO A IERI: UNO SOLO PER TUTTA L'APP.
 * Andrea (708.jpg): il foglio diceva "dal 17 luglio 2028 al 17 luglio 2028: 0 giorni più in là" e il bollino era
 * rosso. La causa: il bollino e il foglio confrontavano i millisecondi (p50 di oggi meno p50 di ieri). Nove ore in
 * piu' facevano il bollino rosso ("Come ieri" in rosso) e il foglio "0 giorni" (9 ore arrotondate al giorno), mentre
 * a schermo la data, scritta al giorno, era la stessa. Adesso lo spostamento e' quello che si vede: i giorni di
 * calendario fra la data di ieri e quella di oggi. Lo usano il bollino di Dream (nvBadge), la card della Mappa, il
 * foglio "Perche' la data si e' spostata" (perche.js) e la schermata nativa fuori rotta (porte.js lo manda in lockRotta).
 * { stato: 'ok'|'primo'|'nuova'|'pausa', giorni, ms, prima, dopo, giorniFa }
 */
function etaSpostamento(){
  const s = ETA.stato;
  if (!s) return null;
  if (s.pausa) return { stato: 'pausa', giorni: 0, ms: 0, giorniFa: 1 };
  const ist = etaIstantaneaPrima();
  if (!ist || !isFinite(s.p50) || !isFinite(ist.p50)) return { stato: 'primo', giorni: 0, ms: 0, giorniFa: 1 };
  /* 0.9.222: una lettura nuova del Genio (un sogno nuovo, l'onboarding rifatto) cambia la strada
     intera (W): confrontare la data con quella della strada di prima dava «+655 giorni rispetto a
     ieri». Con una strada nuova il confronto riparte da domani. */
  const daIst = etaMezzanotte() - (Math.max(1, ist.giorniFa) - 1) * 86400000;
  const riletta = etaLog().some(function(v){ return v && v.tipo === 'genio' && v.at >= daIst; });
  if (riletta || (isFinite(ist.W) && isFinite(s.W) && Math.abs(ist.W - s.W) > 0.5)) return { stato: 'nuova', giorni: 0, ms: 0, prima: ist.p50, dopo: s.p50, giorniFa: ist.giorniFa };
  /* Math.round: il giorno del cambio d'ora ha 23 o 25 ore */
  const giorni = Math.round((etaMezzanotte(s.p50) - etaMezzanotte(ist.p50)) / 86400000);
  return { stato: 'ok', giorni: giorni, ms: s.p50 - ist.p50, prima: ist.p50, dopo: s.p50, giorniFa: Math.max(1, ist.giorniFa) };
}
/** Il testo del bollino, lo stesso in Dream, nella Mappa e sulla schermata nativa: "+1 giorno rispetto a ieri ↗". */
function etaSpostamentoTxt(sp){
  if (!sp) return '';
  if (sp.stato === 'pausa') return '⏸ ' + (etaT('badge.pausa') || 'In pausa: nessun confronto');
  if (sp.stato === 'nuova') return 'Rotta nuova: da domani il confronto';
  if (sp.stato === 'primo') return etaT('badge.primo') || 'Prima previsione: da domani il confronto';
  const fa = sp.giorniFa > 1 ? sp.giorniFa + ' giorni fa' : 'ieri';
  if (!sp.giorni) return 'Come ' + fa;
  const g = Math.abs(sp.giorni);
  return (sp.giorni < 0 ? '−' : '+') + g + (g === 1 ? ' giorno' : ' giorni') + ' rispetto a ' + fa + (sp.giorni < 0 ? ' ↘' : ' ↗');
}
/** Il bollino di oggi: classe, testo, scarto. delta = giorni di calendario in millisecondi (ms = lo scarto esatto). */
function etaBollino(){
  const sp = etaSpostamento();
  if (!sp) return null;
  const txt = etaSpostamentoTxt(sp);
  if (sp.stato === 'pausa') return { cls: 'flat', txt: txt, delta: 0, giorni: 0, ms: 0, pausa: true };
  if (sp.stato === 'primo') return { cls: 'flat', txt: txt, delta: 0, giorni: 0, ms: 0, primo: true };
  if (sp.stato === 'nuova') return { cls: 'flat', txt: txt, delta: 0, giorni: 0, ms: 0, primo: true, nuova: true };
  return { cls: sp.giorni > 0 ? 'up' : (sp.giorni < 0 ? 'down' : 'flat'), txt: txt, delta: sp.giorni * 86400000, giorni: sp.giorni, ms: sp.ms, giorniFa: sp.giorniFa };
}
/** La giornata (o le giornate) chiuse da ieri a oggi: la voce del registro. */
function etaChiudiGiornate(prima){
  const s = ETA.stato || prima;
  if (!s) return;
  /* la serie di OGGI, non quella dell'ultimo calcolo: i giorni chiusi stanno li' */
  etaCalcola();
  const serie = ETA.serie || [];
  const n = Math.max(1, Math.min(60, Math.round((etaMezzanotte() - etaDaKey(prima.giorno)) / 86400000)));
  const giorni = serie.filter(function(d){ return d.eta <= n; });
  const pausa = giorni.length && giorni.every(function(d){ return d.pausa; });
  const riposo = giorni.length && giorni.every(function(d){ return !(d.pian > 0); });
  const fatte = giorni.reduce(function(a, d){ return a + d.credito; }, 0), pian = giorni.reduce(function(a, d){ return a + d.pian; }, 0);
  const vars = { fatte: etaNum(fatte, 1), pian: etaNum(pian, 1), n: n, fatteOre: fatte, pianOre: pian };
  return etaRicalcola({ tipo: pausa ? 'pausaGiorno' : (riposo ? 'riposo' : (n > 1 ? 'giornate' : 'giornata')), vars: vars });
}
/** All'apertura e a ogni cambio di data: se il giorno dello stato e' passato, si chiude. */
function etaControllaGiorno(){
  const prima = ETA.stato || etaLeggi('stato', null);
  if (!prima){ etaRicalcola(null); return; }
  if (prima.giorno < etaOggiK()){ ETA.stato = prima; etaChiudiGiornate(prima); }
}

/* ---------------------------------------------------------------------------------------
   LE TAPPE (affidabilita'): un orizzonte con passi aperti riceve una previsione; quando si
   chiude, si guarda se la data vera e' caduta nell'intervallo.
   --------------------------------------------------------------------------------------- */
function etaTappeAggiorna(){
  if (!ETA.inp || typeof ozLeggi !== 'function') return;
  const t = etaLeggi('tappe', {}) || {};
  let s = {};
  try{ s = ozLeggi(); }catch(_){ }
  let cambiato = false;
  Object.keys(s).forEach(function(k){
    if (k.indexOf('__') === 0 || k === 'adesso' || k === 'ungiorno') return;
    const passi = (s[k].passi || []).filter(function(p){ return p && p.t; });
    if (!passi.length) return;
    const aperti = passi.filter(function(p){ return !p.fatto; });
    const id = k + ':' + passi.length;
    if (aperti.length){
      if (!t[id]){
        const R = aperti.reduce(function(a, p){ return a + etaStimaDi(p.t, '', 'oz', k).stimaMin / 60; }, 0) * (ETA.stato ? ETA.stato.f : 1);
        const sim = etaSimula(Object.assign({}, ETA.inp, { R: R }));
        t[id] = { k: k, at: Date.now(), p10: sim.p10, p50: sim.p50, p90: sim.p90 };
        cambiato = true;
      }
    } else if (t[id] && !t[id].chiusaIl){
      const ultimo = passi.map(function(p){ return p.il ? etaDaKey(p.il) + 12 * 3600000 : 0; }).sort().pop() || Date.now();
      t[id].chiusaIl = ultimo;
      cambiato = true;
      const a = etaAffidabilita(Object.keys(t).map(function(x){ return t[x]; }), +etaLeggi('varianza', ETA_CFG.varianza.default) || 1, ETA_CFG);
      etaScrivi('varianza', a.varianza);
    }
  });
  if (cambiato) etaScrivi('tappe', t);
}
function etaAffidabilitaOra(){
  const t = etaLeggi('tappe', {}) || {};
  return etaAffidabilita(Object.keys(t).map(function(x){ return t[x]; }), +etaLeggi('varianza', ETA_CFG.varianza.default) || 1, ETA_CFG);
}

/* ---------------------------------------------------------------------------------------
   IL VEICOLO: nessun controllo continuo, solo quando lo chiedi
   --------------------------------------------------------------------------------------- */
function etaVeicoloProve(){ return etaLeggi('veicolo', []) || []; }
function etaVeicoloProva(){
  let c = null;
  try{ c = navigator.connection || navigator.mozConnection || navigator.webkitConnection || null; }catch(_){ }
  const prova = { at: Date.now(), rtt: c && typeof c.rtt === 'number' ? c.rtt : null, downlink: c && typeof c.downlink === 'number' ? c.downlink : null, tipo: (c && c.effectiveType) || '' };
  const p = etaVeicoloProve(); p.push(prova);
  etaScrivi('veicolo', p.slice(-12));
  etaEvento('veicolo', {});
  etaTlPaint();
}
/** L'effetto sulla qualita': mai oltre il 3 per cento, e solo se lento piu' volte E con dispersione alta. */
function etaVeicoloEffetto(){
  const c = ETA_CFG.veicolo;
  const p = etaVeicoloProve().slice(-c.ultimeProve);
  const lenti = p.filter(function(x){ return (x.rtt !== null && x.rtt >= c.rttLento) || c.tipiLenti.indexOf(x.tipo) >= 0; }).length;
  if (lenti < c.minRipetizioni) return 0;
  let disperso = false;
  try{
    const st = (typeof dpGiorni === 'function') ? dpGiorni() : {};
    const v = Object.keys(st).sort().slice(-14).map(function(k){ return Array.isArray(st[k].fasce) ? st[k].fasce.reduce(function(a, b){ return a + b; }, 0) : null; }).filter(function(x){ return x !== null; });
    if (v.length >= 4){ const med = etaMediana(v); disperso = v.slice(-3).reduce(function(a, b){ return a + b; }, 0) / 3 > med; }
  }catch(_){ }
  return disperso ? -c.malus : 0;
}

/* ---------------------------------------------------------------------------------------
   L'IMPREVISTO: la rotta in pausa, senza penalita' e senza perdere la serie
   --------------------------------------------------------------------------------------- */
function etaImprevistoInizia(motivo){
  const p = etaPause();
  if (etaPausaAttiva()) return;
  p.push({ da: etaOggiK(), a: '', motivo: motivo || 'altro', at: Date.now() });
  etaScrivi('pausa', p);
  etaEvento('imprevisto', { motivo: etaT('tl.imprevisto.motivi.' + (motivo || 'altro')) || motivo });
  if (typeof toast === 'function') toast(etaT('tl.imprevisto.messaggio'));
  etaTlPaint(); etaOpzRidipingi();
}
function etaImprevistoFine(){
  const p = etaPause();
  const u = p[p.length - 1];
  if (!u || u.a) return;
  u.a = etaOggiK();
  etaScrivi('pausa', p);
  etaEvento('ripresa', {});
  etaTlPaint(); etaOpzRidipingi();
}
function etaImprevistoHtml(){
  const p = etaPausaAttiva();
  const m = etaT('tl.imprevisto.motivi') || {};
  return '<div class="eta-box" id="etaImprevisto"><b>' + etaT('tl.imprevisto.titolo') + '</b><small>' + etaT('tl.imprevisto.sotto') + '</small>'
    + (p ? '<p class="eta-pausa">' + etaT('tl.imprevisto.inPausa', { da: etaDataTxt(etaDaKey(p.da)), motivo: m[p.motivo] || p.motivo }) + '</p>'
           + '<button type="button" class="btn primary" onclick="etaImprevistoFine()">' + etaT('tl.imprevisto.riprendi') + '</button>'
         : '<div class="eta-motivi" hidden id="etaMotivi"><p>' + etaT('tl.imprevisto.scegli') + '</p>'
           + Object.keys(m).map(function(k){ return '<button type="button" onclick="etaImprevistoInizia(\'' + k + '\')">' + etaEsc(m[k]) + '</button>'; }).join('')
           + '<button type="button" class="eta-annulla" onclick="document.getElementById(\'etaMotivi\').hidden=true">' + etaT('tl.imprevisto.annulla') + '</button></div>'
           + '<button type="button" class="ghostmini" onclick="document.getElementById(\'etaMotivi\').hidden=false">' + etaT('tl.imprevisto.bottone') + '</button>')
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   LE DEVIAZIONI E GLI IMPREVISTI (0.9.285, Andrea): "il tempo di arrivo previsto si ricalcola ogni volta che
   aggiungo un'idea fuori dalla roadmap o comunico un imprevisto all'agente". Come il navigatore quando esci di
   strada: l'idea fuori rotta che tieni oggi si prende il suo tempo dalla strada di oggi, e la data si sposta
   subito. Se la metti nel caveau o la tagli, il tempo torna. Un imprevisto si prende il tempo che dice lui
   ("due giorni in meno") sui suoi giorni. Contano solo le ore pianificate che portano via davvero: chi fa
   comunque tutto il previsto non perde niente. A giornata chiusa decide la giornata vera (etaChiudiGiornate).
   fl_eta_dev = [{ id, at, tipo: 'idea'|'imprevisto', testo, ore, giorni, fonte, via }]
   Le richieste fuori rotta dell'arbitro sul computer stanno gia' in fl_deviazioni (arbitro-claude.js), con i
   minuti misurati: si leggono da li', e quelle annullate al VAR ne escono da sole.
   --------------------------------------------------------------------------------------- */
/* la configurazione delle deviazioni: con un eta-config.js vecchio in cache (aggiornamento a meta') valgono questi numeri */
function etaDevCfg(){ return (typeof ETA_CFG !== 'undefined' && ETA_CFG.deviazione) || { minutiDefault: 30, maxGiorniIdee: 1, maxGiorniImprevisto: 60 }; }
function etaDev(){ return etaLeggi('dev', []) || []; }
function etaDevId(){ return 'dv' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
function etaDevVoci(){
  const oggi0 = etaMezzanotte();
  const voci = [];
  let reg = []; try{ reg = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || []; }catch(_){ }
  reg.forEach(function(e){
    if (!e || !(+e.at >= oggi0)) return;
    voci.push({ id: 'ac:' + e.id, tipo: 'idea', testo: String(e.motivo || 'aggiunta non prevista'), ore: Math.max(5, +e.minuti > 0 ? +e.minuti : etaDevCfg().minutiDefault) / 60, at: +e.at, fonte: 'arbitro' });
  });
  etaDev().forEach(function(x){
    if (!x || x.via) return;
    /* 0.9.305: un'app aperta comunque dalla schermata fuori rotta: il prezzo detto li', in giorni di calendario */
    /* 0.9.308: fuori dalle ore del piano il prezzo va sulla prossima giornata di lavoro (x.giorno, scelto dal telefono) */
    if (x.tipo === 'rotta'){ if ((x.giorno || etaKey(+x.at)) === etaOggiK()) voci.push({ id: x.id, tipo: 'rotta', testo: x.testo, ore: Math.max(0, +x.ore || 0), giorni: Math.max(0, +x.giorni || 0), at: +x.at, fonte: x.fonte }); return; }
    if (x.tipo === 'idea'){ if (+x.at >= oggi0) voci.push({ id: x.id, tipo: 'idea', testo: x.testo, ore: Math.max(0, +x.ore || 0), at: +x.at, fonte: x.fonte }); return; }
    if (x.tipo !== 'imprevisto') return;
    const g = Math.max(1, Math.min(etaDevCfg().maxGiorniImprevisto, Math.round(+x.giorni || 1)));
    const passati = Math.round((oggi0 - etaMezzanotte(+x.at)) / 86400000);
    if (passati < 0 || passati >= g) return;
    voci.push({ id: x.id, tipo: 'imprevisto', testo: x.testo, oreTot: Math.max(0, +x.ore || 0), g: g, restanti: g - passati, ore: Math.max(0, +x.ore || 0) * (g - passati) / g, at: +x.at, fonte: x.fonte });
  });
  return voci;
}
/** Quanti giorni di strada portano via oggi le deviazioni: solo le ore pianificate che restano da fare. */
function etaDevOggi(piano, pianOggi, fattoOggi){
  const voci = etaDevVoci();
  const hG = piano && piano.nGiorni > 0 ? piano.oreSettimana / piano.nGiorni : 0;
  let idee = 0, impr = 0, rotta = 0;
  voci.forEach(function(v){ if (v.tipo === 'idea') idee += v.ore; else if (v.tipo === 'rotta') rotta += v.giorni; else impr += v.ore; });
  /* 0.9.305: le app aperte comunque pagano il prezzo detto sulla schermata fuori rotta, tale e quale (al massimo un giorno) */
  const out = { voci: voci, idee: idee, impr: impr, giorni: Math.min(1, rotta), gIdee: 0, gImpr: 0, gRotta: Math.min(1, rotta) };
  if (!(hG > 0)) return out;
  let libero = Math.max(0, (+pianOggi || 0) - (+fattoOggi || 0));
  const ideeOggi = Math.min(idee, libero);
  libero -= ideeOggi;
  out.gIdee = Math.min(etaDevCfg().maxGiorniIdee, ideeOggi / hG);
  voci.forEach(function(v){
    if (v.tipo !== 'imprevisto') return;
    const alGiorno = v.oreTot / v.g;
    const oggiQ = Math.min(alGiorno, libero); libero -= oggiQ;
    const futuri = Math.max(0, v.restanti - 1) * Math.min(alGiorno, hG);
    out.gImpr += (oggiQ + futuri) / hG;
  });
  out.giorni = out.gIdee + out.gImpr + out.gRotta;
  return out;
}
function etaDevSalva(l){ etaScrivi('dev', (l || []).slice(-300)); }
/** Un tempo detto per intero ("10 ore", "1 giorno e 6 ore"): niente sigle a schermo. */
function etaTempoParole(ms){
  const m = Math.round(Math.abs(ms) / 60000);
  if (m < 60) return m + (m === 1 ? ' minuto' : ' minuti');
  const h = Math.round(m / 60);
  if (h < 24) return h + (h === 1 ? ' ora' : ' ore');
  const g = Math.floor(h / 24), r = h % 24;
  return g + (g === 1 ? ' giorno' : ' giorni') + (r ? ' e ' + r + (r === 1 ? ' ora' : ' ore') : '');
}
function etaDevToast(stato, prima, cosa){
  try{
    if (typeof toast !== 'function' || !stato || !prima || !isFinite(stato.p50) || !isFinite(prima.p50)) return;
    const d = stato.p50 - prima.p50;
    if (Math.abs(d) < 30 * 60000) { toast(etaT('dev.fermo', { cosa: cosa })); return; }
    const txt = etaTempoParole(d);
    toast(etaT(d > 0 ? 'dev.piu' : 'dev.meno', { delta: txt, cosa: cosa }));
  }catch(_){ }
}
/** Un'idea fuori rotta tenuta oggi (dal foglio o dall'agente): l'arrivo si ricalcola subito. */
function etaDeviazione(testo, minuti, fonte){
  const l = etaDev();
  const x = { id: etaDevId(), at: Date.now(), tipo: 'idea', testo: String(testo || 'un\u2019idea fuori rotta').slice(0, 160), ore: Math.max(5, +minuti || etaDevCfg().minutiDefault) / 60, fonte: fonte || 'app', via: 0 };
  l.push(x); etaDevSalva(l);
  const prima = ETA.stato;
  const dopo = etaEvento('deviazione', { ore: etaNum(x.ore, 1) + ' h' }, x.testo, 'dev:' + etaOggiK());
  etaDevToast(dopo, prima, etaT('dev.idea'));
  return x.id;
}
/** 0.9.305: "Apri comunque" dalla schermata fuori rotta, confermato con l'effetto farfalla. Il prezzo e' quello detto
    sulla schermata (minuti di lavoro persi diviso i minuti di lavoro di un giorno), tale e quale: va sull'arrivo di oggi.
    A giornata chiusa decide la giornata vera, come per le altre deviazioni. */
function etaRottaPagata(nome, spostaMs, minuti, giorno){
  const l = etaDev();
  const g = /^\d{4}-\d{2}-\d{2}$/.test(String(giorno || '')) && String(giorno) >= etaOggiK() ? String(giorno) : etaOggiK();
  const x = { id: etaDevId(), at: Date.now(), tipo: 'rotta', testo: ('Hai aperto ' + (nome || 'un’app') + ' comunque').slice(0, 160),
              ore: Math.max(0, +minuti || 0) / 60, giorni: Math.max(0, +spostaMs || 0) / 86400000, fonte: 'blocco', via: 0, giorno: g };
  l.push(x); etaDevSalva(l);
  return etaEvento('deviazione', { ore: etaNum(x.ore, 1) + ' h' }, x.testo, 'rotta:' + x.id);
}
/** 0.9.308: i giorni gia' presi dalle app aperte comunque, per giorno ({ '2026-10-30': 0.16 }): la schermata nativa
    toglie questi dal tetto di un giorno (una giornata non sposta l'arrivo piu' di un giorno, eta.js etaDevOggi). */
function etaRottaGiorni(){
  const oggi = etaOggiK(), out = {};
  etaDev().forEach(function(x){
    if (!x || x.via || x.tipo !== 'rotta') return;
    const g = x.giorno || etaKey(+x.at);
    if (g < oggi) return;
    out[g] = Math.round(((out[g] || 0) + Math.max(0, +x.giorni || 0)) * 10000) / 10000;
  });
  return out;
}
/** Toglie una deviazione (messa nel caveau, tagliata, o annullata): il suo tempo torna alla strada. */
function etaDevTogli(id, perche){
  const l = etaDev(); const x = l.filter(function(v){ return v.id === id; })[0];
  if (!x || x.via) return false;
  x.via = Date.now(); x.perche = perche || ''; etaDevSalva(l);
  const prima = ETA.stato;
  const dopo = etaEvento('deviazioneTolta', {}, x.testo);
  etaDevToast(dopo, prima, etaT(x.tipo === 'imprevisto' ? 'dev.imprevistoTolto' : 'dev.ideaTolta'));
  return true;
}
/* ---- quanto tempo porta via un imprevisto, dalle sue parole ("due giorni in meno", "tre ore", "mezza giornata") ---- */
const ETA_NUMERI = { un: 1, uno: 1, una: 1, mezzo: 0.5, mezza: 0.5, due: 2, tre: 3, quattro: 4, cinque: 5, sei: 6, sette: 7, otto: 8, nove: 9, dieci: 10, quindici: 15, venti: 20, trenta: 30 };
function etaDurataDaTesto(t){
  const piano = etaPiano();
  const hG = piano.nGiorni > 0 ? piano.oreSettimana / piano.nGiorni : piano.oreSettimana / 7;
  const s = ' ' + String(t || '').toLowerCase().replace(/un['\u2019]/g, 'un ').replace(/\s+/g, ' ') + ' ';
  let ore = 0, giorni = 0, trovato = false;
  if (/tutt[ao] (il giorno|la giornata)|giornata persa|oggi (niente|nulla)/.test(s)){ ore += hG; giorni = Math.max(giorni, 1); trovato = true; }
  const re = /(\d+(?:[.,]\d+)?|un|uno|una|mezz[ao]|due|tre|quattro|cinque|sei|sette|otto|nove|dieci|quindici|venti|trenta)\s+(e mezz[ao]\s+)?(minut[oi]|or[ae]|giornat[ae]|giorn[oi]|settiman[ae]|mes[ei])\b/g;
  let m;
  while ((m = re.exec(s))){
    let n = /^\d/.test(m[1]) ? parseFloat(m[1].replace(',', '.')) : ETA_NUMERI[m[1]];
    if (!(n > 0)) continue;
    if (m[2]) n += 0.5;
    const u = m[3];
    trovato = true;
    if (/^minut/.test(u)) ore += n / 60;
    else if (/^or/.test(u)) ore += n;
    else if (/^giorn/.test(u)){ ore += n * hG; giorni += n; }
    else if (/^settiman/.test(u)){ ore += n * piano.oreSettimana; giorni += n * 7; }
    else if (/^mes/.test(u)){ ore += n * piano.oreSettimana * 4.35; giorni += n * 30; }
  }
  return { trovato: trovato, ore: ore, giorni: Math.max(1, Math.min(etaDevCfg().maxGiorniImprevisto, Math.ceil(giorni || 1))) };
}
/** Un imprevisto comunicato all'agente (o dalla revisione della giornata): l'arrivo si ricalcola subito.
    Senza una durata nelle parole il tempo lo stima l'agente nella risposta (azioni.imprevisto). */
function etaImprevistoSegnalato(testo, fonte){
  const d = etaDurataDaTesto(testo);
  const l = etaDev();
  const x = { id: etaDevId(), at: Date.now(), tipo: 'imprevisto', testo: String(testo || '').slice(0, 160), ore: d.ore, giorni: d.giorni, fonte: fonte || 'agente', via: 0, stimaAgente: !d.trovato };
  l.push(x); etaDevSalva(l);
  const prima = ETA.stato;
  const dopo = etaEvento('imprevistoAgente', { ore: etaNum(d.ore, 1) + ' h', giorni: d.giorni }, x.testo);
  if (d.trovato) etaDevToast(dopo, prima, etaT('dev.imprevisto'));
  else if (typeof toast === 'function') toast(etaT('dev.attesaStima'));
  return x.id;
}
/** La stima dell'agente (azioni.imprevisto nella risposta): aggiorna l'ultimo imprevisto senza durata, o ne apre uno. */
function etaImprevistoDaAgente(a){
  if (!a) return false;
  const piano = etaPiano();
  const hG = piano.nGiorni > 0 ? piano.oreSettimana / piano.nGiorni : piano.oreSettimana / 7;
  const giorni = Math.max(1, Math.min(etaDevCfg().maxGiorniImprevisto, Math.round(+a.giorni || 1)));
  const ore = +a.ore > 0 ? +a.ore : (+a.giorni > 0 ? +a.giorni * hG : 0);
  const l = etaDev();
  /* l'imprevisto appena segnalato (dalla chat o dalla revisione) prende la stima dell'agente: niente doppioni */
  let x = l.slice().reverse().filter(function(v){ return v.tipo === 'imprevisto' && !v.via && (v.stimaAgente || v.fonte === 'agente' || v.fonte === 'revisione') && Date.now() - v.at < (v.stimaAgente ? 3 * 86400000 : 6 * 3600000); })[0];
  if (!x){ x = { id: etaDevId(), at: Date.now(), tipo: 'imprevisto', testo: String(a.motivo || 'Imprevisto').slice(0, 160), fonte: 'agente', via: 0 }; l.push(x); }
  x.ore = ore; x.giorni = giorni; x.stimaAgente = false; if (a.motivo) x.testo = String(a.motivo).slice(0, 160);
  etaDevSalva(l);
  const prima = ETA.stato;
  const dopo = etaEvento('imprevistoAgente', { ore: etaNum(ore, 1) + ' h', giorni: giorni }, x.testo);
  etaDevToast(dopo, prima, etaT('dev.imprevisto'));
  return x.id;
}
/** La riga sotto alla data: quanto costano oggi le deviazioni, e come riprenderti il tempo. */
function etaDevHtml(s){
  const d = s && s.dev;
  if (!d || !(d.giorni > 0.004)) return '';
  const ore = function(g){ return etaTempoParole(g * 86400000); };
  const righe = [];
  if (d.gIdee > 0.004) righe.push(etaT('card.devIdee', { tempo: ore(d.gIdee) }));
  if (d.gImpr > 0.004) righe.push(etaT('card.devImpr', { tempo: ore(d.gImpr) }));
  /* 0.9.305: "Apri comunque" dalla schermata fuori rotta */
  if (d.gRotta > 0.0005) righe.push('Le app aperte comunque oggi spostano l’arrivo di ' + (typeof frDurata === 'function' ? frDurata(d.gRotta * 1440) : ore(d.gRotta)) + '.');
  return '<small class="mp-dev" onclick="etaTimelineApri(event)">' + righe.map(etaEsc).join('<br>') + '</small>';
}

/* ---------------------------------------------------------------------------------------
   IL PANNELLO DELL'ARRIVO
   --------------------------------------------------------------------------------------- */
function etaPrecisione(){
  let p = 'precisa';
  try{ p = serOpzioni().precisione || 'precisa'; }catch(_){ }
  if (p === 'minuti') p = 'dettagliata';
  return ['semplice', 'precisa', 'dettagliata'].indexOf(p) >= 0 ? p : 'precisa';
}
/** L'arrivo nella forma che il resto dell'app conosce (serArrivo). */
function etaArrivo(){
  if (!ETA.stato){ ETA.stato = etaLeggi('stato', null); if (!ETA.stato) ETA.stato = etaCalcola(); }
  const s = ETA.stato;
  if (!s) return null;
  const modo = etaPrecisione();
  /* 0.9.304: "oltre" = nessuna data finita, sempre. Uno stato salvato prima (o arrivato dal computer) poteva avere oltre
     acceso con una data vera: era "oltre la scadenza scelta" */
  const senzaData = !isFinite(s.p50);
  return { at: s.p50, p10: s.p10, p90: s.p90, inizio: s.inizio, oltre: !!s.oltre && senzaData, oltreScadenza: s.oltreScadenza != null ? !!s.oltreScadenza : (!!s.oltre && !senzaData), senzaPiano: s.senzaPiano,
           txt: etaDataTxt(s.p50, false), txtSemplice: etaDataTxt(s.p50, true), modo: modo, semplice: modo === 'semplice',
           pedaggi: !!s.pedaggi, pct: s.pct, pTarget: s.pTarget, calibrazione: s.calibrazione, pausa: s.pausa };
}
function etaBollinoHtml(){
  const b = etaBollino();
  if (!b) return '';
  return '<span class="rep-badge ' + b.cls + ' mp-delta" data-delta="' + (b.delta || 0) + '" onclick="etaTimelineApri(event)">' + etaEsc(b.txt) + '</span>';
}
function etaCardInner(){
  const s = ETA.stato;
  const a = etaArrivo();
  if (!s || !a) return '';
  const modo = a.modo;
  let data;
  if (s.senzaPiano) data = etaT('card.senzaPiano');
  else if (a.oltre) data = etaT('card.oltre');
  else data = modo === 'semplice' ? a.txtSemplice : a.txt;
  const conto = (isFinite(s.p50) && !s.senzaPiano && typeof serContoRovescia === 'function') ? serContoRovescia(s.p50, modo) : '';
  return '<p>' + etaT('card.arrivo') + (s.pedaggi ? ' ' + etaT('card.pedaggi') : '') + ' <i class="mp-stima">' + etaT('card.stima') + '</i></p>'
    + '<b class="mp-arrivo-data" onclick="etaIntervalloApri(event)">' + etaEsc(data) + '</b>'
    + (conto ? '<small class="mp-arrivo-cd" data-at="' + s.p50 + '" data-modo="' + modo + '">' + etaEsc(conto) + '</small>' : '')
    + '<div class="mp-delta-wrap">' + etaBollinoHtml() + '</div>'
    + etaDevHtml(s)
    + (s.pausa ? '<small class="mp-calibro">' + etaT('card.pausa', { motivo: (etaT('tl.imprevisto.motivi') || {})[s.pausa.motivo] || s.pausa.motivo }) + '</small>' : '')
    + (!s.pausa && s.calibrazione ? '<small class="mp-calibro">' + etaT('card.calibro', { n: Math.min(ETA_CFG.calibrazione.giorni, s.giorniDati + 1), tot: ETA_CFG.calibrazione.giorni }) + '</small>' : '');
}
function etaCardHtml(){
  if (!ETA.stato){ ETA.stato = etaLeggi('stato', null); if (!ETA.stato) ETA.stato = etaCalcola(); }
  if (!ETA.stato) return '';
  return '<div class="mp-arrivo" onclick="mpSpiega(event)">' + etaCardInner() + '</div>';
}
/** Ridisegna i pannelli a schermo senza rifare la mappa; il bollino conta fino al nuovo numero. */
function etaRidipingi(anima){
  if (typeof document === 'undefined') return;
  const s = ETA.stato;
  if (!s) return;
  const prima = ETA.ultimoDelta;
  const b = etaBollino();
  document.querySelectorAll('.mp-arrivo').forEach(function(el){
    el.innerHTML = etaCardInner();
    if (anima && b && prima !== null && prima !== b.delta && !b.primo && !b.pausa){
      const badge = el.querySelector('.mp-delta');
      if (badge) etaAnimaBollino(badge, prima, b.delta, b);
      const cd = el.querySelector('.mp-arrivo-cd');
      if (cd){ cd.classList.add('mp-salto'); setTimeout(function(){ cd.classList.remove('mp-salto'); }, 700); }
    }
  });
  ETA.ultimoDelta = b ? b.delta : null;
  /* la pagina grande della mappa ha la sua scheda dell'arrivo (mappa.js, 0.9.228) */
  try{ if (typeof mpArrivoRidipingi === 'function') mpArrivoRidipingi(); }catch(_){ }
  document.querySelectorAll('.mp-globo-t').forEach(function(el){ if (typeof mpPercTxt === 'function') el.innerHTML = (typeof mpPercHtml === 'function') ? mpPercHtml() : (mpPercTxt(s.pct) + '% del percorso'); });
  try{ if (typeof sevGloboPaint === 'function' && document.getElementById('sevGlobo')) sevGloboPaint(); }catch(_){ }
  if (document.getElementById('etaBody') && document.getElementById('s-eta') && document.getElementById('s-eta').classList.contains('active')) etaTlPaint();
}
function etaAnimaBollino(el, da, a, fine){
  const t0 = performance.now(), dur = 650;
  /* 0.9.308: si conta a giorni interi, come il bollino (etaSpostamentoTxt) */
  const passo = function(now){
    const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    const g = Math.round((da + (a - da) * e) / 86400000);
    el.className = 'rep-badge ' + (g > 0 ? 'up' : (g < 0 ? 'down' : 'flat')) + ' mp-delta';
    el.textContent = etaSpostamentoTxt({ stato: 'ok', giorni: g, giorniFa: fine.giorniFa || 1 });
    if (k < 1) requestAnimationFrame(passo);
    else { el.className = 'rep-badge ' + fine.cls + ' mp-delta'; el.textContent = fine.txt; }
  };
  requestAnimationFrame(passo);
}
/* ---- il foglio dell'intervallo ---- */
function etaIntervalloApri(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const s = ETA.stato;
  const w = document.getElementById('mpSheet');
  if (!s || !w) return;
  const aff = etaAffidabilitaOra();
  w.innerHTML = '<div class="mp-sheet-in">'
    + '<div class="mp-sico">🧭</div>'
    + '<h3>' + etaT('intervallo.titolo') + '</h3>'
    + (isFinite(s.p10) && isFinite(s.p90) ? '<p>' + etaT('intervallo.testo', { da: etaDataTxt(s.p10), a: etaDataTxt(s.p90) }) + '</p>' : '')
    + '<p>' + etaT('intervallo.centro') + '</p>'
    + (s.target && isFinite(s.p50) ? '<p>' + etaT('intervallo.target', { data: etaDataTxt(s.target, true), pct: Math.round(s.pTarget * 100) }) + '</p>' : '')
    + (s.calibrazione ? '<p>' + etaT('intervallo.calibro') + '</p>' : '')
    + (s.freni ? '<p>Il Genio ha la radiografia del tuo paradigma, dalla sfida «Indovina il mio sabotatore»: il ritmo di partenza è il tuo, non quello medio, e l’intervallo è più stretto.</p>' : '<p>Fai la sfida «Indovina il mio sabotatore», nella scheda Sogno: con la radiografia del tuo paradigma la prima previsione parte dal tuo passo, e l’intervallo si stringe.</p>')
    + (aff.n ? '<p>' + etaT('intervallo.affid', { dentro: aff.dentro, n: aff.n }) + '</p>' : '')
    + '<button type="button" class="cta mp-sec" onclick="mpSheetClose();etaTimelineApri()">' + etaT('intervallo.timeline') + '</button>'
    + '<button type="button" class="cta mp-sec" onclick="mpSheetClose();etaInfoApri()">' + etaT('intervallo.come') + '</button>'
    + '<button type="button" class="cta" onclick="mpSheetClose()">' + etaT('intervallo.ok') + '</button>'
    + '</div>';
  w.hidden = false;
}

/* ---------------------------------------------------------------------------------------
   LE OPZIONI DI VIAGGIO: la precisione, le ore, i giorni, l'imprevisto
   --------------------------------------------------------------------------------------- */
function etaOpzHtml(o){
  const p = etaPiano();
  const nomi = etaT('opz.giorniNomi') || ['D', 'L', 'M', 'M', 'G', 'V', 'S'];
  const ws = (typeof flWeekStart === 'function') ? flWeekStart() : 1;
  const ordine = []; for (let i = 0; i < 7; i++) ordine.push((ws + i) % 7);
  return '<label class="mp-opz-r"><div><b>' + etaT('opz.capacita') + '</b><small>' + etaT('opz.capacitaSotto') + '</small></div>'
    +   '<input type="number" inputmode="decimal" min="0.5" max="80" step="0.5" id="etaOpzOre" value="' + p.oreSettimana + '"></label>'
    + '<div class="mp-opz-r"><div><b>' + etaT('opz.giorni') + '</b><small>' + etaT('opz.giorniSotto') + '</small></div></div>'
    + '<div class="eta-giorni" id="etaOpzGiorni">' + ordine.map(function(d){ return '<button type="button" class="' + (p.giorni[d] ? 'on' : '') + '" data-d="' + d + '" onclick="this.classList.toggle(\'on\')">' + nomi[d] + '</button>'; }).join('') + '</div>'
    + etaImprevistoHtml();
}
/** Legge il piano dalla pagina delle opzioni e, se e' cambiato, ricalcola con la causa. */
function etaOpzSalva(){
  const ore = parseFloat((document.getElementById('etaOpzOre') || {}).value);
  const box = document.getElementById('etaOpzGiorni');
  if (!box || typeof serOpzioniSalva !== 'function') return;
  const giorni = [0, 0, 0, 0, 0, 0, 0];
  Array.prototype.forEach.call(box.querySelectorAll('button'), function(b){ giorni[+b.dataset.d] = b.classList.contains('on') ? 1 : 0; });
  const prima = etaPiano();
  serOpzioniSalva({ capacita: ore > 0 ? ore : prima.oreSettimana, giorniLavoro: giorni });
  const dopo = etaPiano();
  if (dopo.oreSettimana !== prima.oreSettimana || dopo.giorni.join('') !== prima.giorni.join('')){
    etaEvento('piano', { ore: etaNum(dopo.oreSettimana, 1), giorni: dopo.nGiorni, prima: etaNum(prima.oreSettimana, 1), dopo: etaNum(dopo.oreSettimana, 1) });
  }
}
function etaOpzRidipingi(){ if (typeof document === 'undefined') return; const b = document.getElementById('etaImprevisto'); if (b) b.outerHTML = etaImprevistoHtml(); }
/** La migrazione della precisione: chi vedeva ore e minuti passa a «dettagliata»; i nuovi a «precisa». */
function etaMigraPrecisione(){
  if (etaLeggi('prec', 0)) return;
  try{
    const o = serOpzioni();
    let salvato = null;
    try{ salvato = JSON.parse(localStorage.getItem('fl_viaggio_opz') || 'null'); }catch(_){ }
    const p = salvato && salvato.precisione;
    let nuova = 'precisa';
    if (p === 'semplice') nuova = 'semplice';
    else if (p === 'minuti' || (etaViaggio() && !p)) nuova = 'dettagliata';
    else if (p === 'precisa' || p === 'dettagliata') nuova = p;
    if (o.precisione !== nuova) serOpzioniSalva({ precisione: nuova });
  }catch(_){ }
  try{ localStorage.setItem(ETA_K.prec, '1'); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LA TIMELINE DEL VIAGGIO
   --------------------------------------------------------------------------------------- */
if (typeof registerScreen === 'function'){
  registerScreen('s-eta',
    '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title" id="etaTitolo">Timeline del viaggio</b>'
    + '<button type="button" class="dp-i dp-i-top" onclick="etaInfoApri()" aria-label="Come funziona">i</button></div>'
    + '<div id="etaBody" class="dp-page eta-page"></div>', { back: 's-home' });
  registerScreen('s-eta-info',
    '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title" id="etaInfoTitolo">Come funziona il navigatore</b></div>'
    + '<div id="etaInfoBody" class="dp-page dp-info eta-info"></div>', { back: 's-eta' });
}
function etaTimelineApri(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (typeof mpSheetClose === 'function') try{ mpSheetClose(); }catch(_){ }
  if (document.getElementById('mpFull') && typeof mpClose === 'function') try{ mpClose(); }catch(_){ }
  /* 0.9.326, Andrea: "la Timeline del viaggio fa cagare: molto meglio la pagina Timeline del Report, con una sezione ricalcoli dedicata" */
  if (typeof tlOpen === 'function'){ tlOpen(0, 'rotta', 'ricalcoli'); return; }
  goId('s-eta');
  etaTlPaint();
}
function etaInfoApri(){
  goId('s-eta-info');
  const t = document.getElementById('etaInfoTitolo'); if (t) t.textContent = etaT('info.titolo');
  const b = document.getElementById('etaInfoBody');
  if (b) b.innerHTML = (etaT('info.p') || []).map(function(p){ return '<p>' + String(p).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>') + '</p>'; }).join('');
}
function etaTlTab(t){ ETA.tab = t; etaTlPaint(); }
function etaTlPeriodo(p){ ETA.periodo = p; etaTlPaint(); }
function etaTlVoci(){
  const log = etaLog();
  const oggi = etaMezzanotte();
  let da = 0;
  if (ETA.periodo === 'oggi') da = oggi;
  else if (ETA.periodo === '7') da = oggi - 6 * 86400000;
  else if (ETA.periodo === '30') da = oggi - 29 * 86400000;
  return log.filter(function(v){ return v && v.at >= da; });
}
function etaCausaTxt(v){
  const vars = Object.assign({}, v.vars || {}, { t: v.testo });
  return etaT('cause.' + v.tipo, vars) || v.tipo;
}
function etaFormulaTxt(v){
  const p = v.prima || {}, d = v.dopo || {};
  const delta = v.delta === null ? '—' : (etaDeltaTxt(v.delta, ETA_CFG) || '= 0');
  const pian = (d.piano || 0) / 7;
  const vars = Object.assign({}, v.vars || {}, { delta: delta, Rprima: etaNum(p.R || 0, 0), Rdopo: etaNum(d.R || 0, 0), rate: etaNum(d.rate || 0, 2), Q: etaNum(d.Q || 1, 2),
    pian: etaNum(pian, 1), f: etaNum(d.f || 1, 2), ore: etaNum(Math.abs((p.R || 0) - (d.R || 0)), 1), prima: etaNum(p.piano || 0, 1), dopo: etaNum(d.piano || 0, 1) });
  const k = { riga: 'credito', priorita: 'credito', passo: 'credito', completata: 'credito', sessione: 'credito', pc: 'credito',
              giornata: (vars.fatteOre >= vars.pianOre) ? 'giornataBene' : 'giornata', giornate: (vars.fatteOre >= vars.pianOre) ? 'giornataBene' : 'giornata',
              riposo: 'riposo', pausaGiorno: 'pausa', piano: 'piano', rimandata: 'rimandata', storno: 'storno', ritirata: 'ritirata', passoTolto: 'ritirata', stima: 'stima', deviazione: 'deviazione', deviazioneTolta: 'deviazioneTolta', imprevistoAgente: 'imprevistoAgente' }[v.tipo] || 'generico';
  let come = '';
  /* una voce senza i numeri del credito (o scritta prima che li avesse) usa la frase generica */
  if (k === 'credito' && !(vars.stimaMin > 0) && !(vars.min > 0)) return etaT('formula.generico', vars);
  if (k === 'credito'){
    if (v.tipo === 'sessione') come = etaT('formula.creditoSessione', vars);
    else if (v.tipo === 'pc') come = vars.ore ? etaT('formula.creditoSessione', { min: Math.round((v.vars && v.vars.min) || 0) }) : '';
    else if (v.vars && v.vars.legate > 0) come = etaT('formula.creditoExtra', vars);
    else come = etaT('formula.creditoStima', vars);
    return etaT('formula.credito', Object.assign({}, vars, { come: come })) + ' ' + etaT('formula.passo', vars);
  }
  return etaT('formula.' + k, vars) || etaT('formula.generico', vars);
}
function etaVoceHtml(v, i){
  const delta = v.delta === null ? '—' : (etaDeltaTxt(v.delta, ETA_CFG) || '=');
  const buono = v.delta !== null && v.delta < 0;
  const p = v.prima || {}, d = v.dopo || {};
  const righe = [['R', etaNum(p.R || 0, 0) + ' → ' + etaNum(d.R || 0, 0) + ' h'], ['f', etaNum(p.f || 0, 2) + ' → ' + etaNum(d.f || 0, 2)],
                 ['rate', etaNum(p.rate || 0, 2) + ' → ' + etaNum(d.rate || 0, 2)], ['Q', etaNum(p.Q || 0, 2) + ' → ' + etaNum(d.Q || 0, 2)],
                 ['piano', etaNum(p.piano || 0, 1) + ' → ' + etaNum(d.piano || 0, 1) + ' h'], ['p50', etaDataTxt(p.p50) + ' → ' + etaDataTxt(d.p50)]];
  return '<div class="dp-evr eta-voce' + (buono ? ' buono' : '') + (v.delta === 0 ? ' zero' : '') + '">'
    + '<b class="dp-evn">' + etaEsc(delta) + '</b>'
    + '<div><b>' + etaEsc(etaCausaTxt(v)) + '</b><small>' + etaOra(v.at) + (ETA.periodo !== 'oggi' ? ' · ' + etaDataTxt(v.at) : '') + '</small>'
    +   '<button type="button" class="eta-come" onclick="var b=this.nextElementSibling;b.hidden=!b.hidden">' + etaT('tl.come') + ' ›</button>'
    +   '<div class="eta-come-box" hidden><p>' + etaFormulaTxt(v) + '</p><ul>'
    +     righe.map(function(r){ return '<li><span>' + etaT('tl.voci.' + r[0]) + '</span><b>' + etaEsc(r[1]) + '</b></li>'; }).join('')
    +   '</ul></div>'
    + '</div></div>';
}
function etaPassoHtml(s){
  const fF = etaT('tl.passo.fFonte.' + s.fFonte, { n: s.fN });
  const riga = function(k, val, spiega){ return '<div class="eta-passo-r"><div><b>' + etaT('tl.passo.' + k) + '</b><small>' + (spiega || etaT('tl.passo.' + k + 'Spiega')) + '</small></div><i>' + val + '</i></div>'; };
  return '<div class="eta-box"><b>' + etaT('tl.passo.titolo') + '</b>'
    + '<p class="eta-calibro ' + (s.calibrazione ? 'in' : 'ok') + '">' + (s.calibrazione ? etaT('tl.passo.calibro', { n: Math.min(ETA_CFG.calibrazione.giorni, s.giorniDati + 1), tot: ETA_CFG.calibrazione.giorni }) : etaT('tl.passo.pronto')) + '</p>'
    + riga('rate', etaNum(s.rate, 2))
    + riga('Q', etaNum(s.Q, 2))
    + riga('f', etaNum(s.f, 2), etaT('tl.passo.fSpiega') + ' ' + fF)
    + riga('s', '+' + Math.round(s.s * 100) + '%')
    + riga('piano', etaT('tl.passo.pianoVal', { ore: etaNum(s.piano.oreSettimana, 1), giorni: s.piano.nGiorni }), '')
    + riga('R', etaT('tl.passo.RVal', { ore: etaNum(s.R, 0), pct: (typeof mpPercTxt === 'function') ? mpPercTxt(s.pct) : Math.round(s.pct * 100) }), '')
    + riga('dati', String(s.giorniDati), '')
    + (s.provvisorie ? '<p class="eta-nota">' + etaT('tl.passo.provvisorie', { n: s.provvisorie }) + '</p>' : '')
    + (s.colli && s.colli.length ? s.colli.map(function(c){ return '<p class="eta-nota eta-collo">' + etaT('cause.collo', { t: c.testo, n: c.n }) + (c.critico ? ' ' + etaT('cause.criticoNota') : '') + '</p>'; }).join('') : '')
    + '</div>';
}
/** Le leve: le tre mosse che spostano di piu', ognuna una simulazione controfattuale. */
function etaLeve(){
  const s = ETA.stato, inp = ETA.inp;
  if (!s || !inp || !isFinite(s.p50)) return [];
  const out = [];
  const g = function(ms){ return etaDeltaTxt(ms, ETA_CFG); };
  /* +1 sessione da 45 min al giorno pianificato */
  const piu = Object.assign({}, inp.piano, { oreSettimana: inp.piano.oreSettimana + 0.75 * (inp.piano.nGiorni || 7) });
  const c1 = etaControfattuale(inp, { piano: piu, oreOggi: inp.oreOggi + 0.75 });
  if (isFinite(c1.delta) && c1.delta < 0) out.push({ k: 'sessione', txt: etaT('tl.leve.sessione'), esito: etaT('tl.leve.arrivo', { delta: g(c1.delta) }), peso: -c1.delta });
  /* chiudi il collo di bottiglia, o la task aperta piu' grossa */
  const aperte = (ETA.task || []).filter(function(t){ return !t.fatta; });
  let mira = null;
  if (s.colli && s.colli.length) mira = aperte.filter(function(t){ return etaNorm(t.testo) === etaNorm(s.colli[0].testo); })[0] || null;
  if (!mira && aperte.length) mira = aperte.slice().sort(function(a, b){ return b.stimaMin - a.stimaMin; })[0];
  if (mira){
    const credito = mira.stimaMin / 60 * s.f;
    const c2 = etaControfattuale(inp, { R: Math.max(0, inp.R - credito) });
    if (isFinite(c2.delta) && c2.delta < 0) out.push({ k: 'collo', txt: etaT('tl.leve.collo', { t: mira.testo }), esito: etaT('tl.leve.arrivo', { delta: g(c2.delta) }), peso: -c2.delta });
  }
  /* la finestra migliore */
  const seg = ETA.seg || {};
  if (seg.finestre && seg.finestre.length && (seg.quotaFinestra === null || seg.quotaFinestra < ETA_CFG.Q.finestreQuota)){
    const q2 = etaQ(Object.assign({}, seg, { quotaFinestra: 1 }), ETA_CFG).Q;
    const c3 = etaControfattuale(inp, { Q: q2 });
    const f0 = seg.finestre[0];
    if (isFinite(c3.delta) && c3.delta < 0) out.push({ k: 'finestra', txt: etaT('tl.leve.finestra', { da: String(f0.da).padStart(2, '0'), a: String(f0.a % 24).padStart(2, '0') }), esito: etaT('tl.leve.arrivo', { delta: g(c3.delta) }), peso: -c3.delta });
  }
  /* la costanza: stesso passo, intervallo piu' stretto */
  if (s.giorniDati >= 5 && s.rateSd > 0.15){
    const pool2 = etaPool((ETA.tassi || []).map(function(t){ return { eta: t.eta, rate: s.rate }; }), ETA_CFG, 1);
    const c4 = etaControfattuale(inp, { pool: pool2 });
    const largh = (c4.delta90 || 0) - (c4.delta10 || 0);
    if (isFinite(largh) && largh < -3600000) out.push({ k: 'costanza', txt: etaT('tl.leve.costanza'), esito: etaT('tl.leve.intervallo', { delta: g(largh) }), peso: -largh / 4 });
  }
  if (s.provvisorie) out.push({ k: 'stime', txt: etaT('tl.leve.stime', { n: s.provvisorie }), esito: etaT('tl.leve.precisione'), peso: 0 });
  return out.sort(function(a, b){ return b.peso - a.peso; }).slice(0, 3);
}
function etaLeveHtml(){
  const l = etaLeve();
  return '<div class="eta-box"><b>' + etaT('tl.leve.titolo') + '</b><small>' + etaT('tl.leve.sotto') + '</small>'
    + (l.length ? l.map(function(x){ return '<div class="eta-leva"><b>' + etaEsc(x.txt) + '</b><i>' + etaEsc(x.esito) + '</i></div>'; }).join('') : '<p class="eta-nota">' + etaT('tl.leve.vuoto') + '</p>')
    + '</div>';
}
/** Le abitudini che tornano, proiettate su trenta giorni. */
function etaAbitudini(){
  const s = ETA.stato, inp = ETA.inp, c = ETA_CFG.abitudini;
  if (!s || !inp || !isFinite(s.p50)) return [];
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const da = Date.now() - c.giorni * 86400000;
  const rec = h.filter(function(x){ return x && !x.meditazione && x.at >= da; });
  const out = [];
  const proietta = function(k, costoOreAlGiorno, Qalt){
    const piano = Object.assign({}, inp.piano, { oreSettimana: Math.max(0.5, inp.piano.oreSettimana - costoOreAlGiorno * 7) });
    const r = etaControfattuale(inp, Object.assign({ tilt: { giorni: 30, fattore: 1 } }, Qalt ? { Q: Qalt } : { piano: piano }));
    if (!isFinite(r.delta) || r.delta <= 0) return;
    const n = Math.round(r.delta / 86400000), a = Math.round(Math.min(r.delta10, r.delta90) / 86400000), b = Math.round(Math.max(r.delta10, r.delta90) / 86400000);
    if (n < 1) return;
    out.push({ k: k, txt: etaT('tl.abit.' + k), frase: etaT('tl.abit.frase', { n: n, a: Math.min(a, n), b: Math.max(b, n) }) });
  };
  /* sessioni interrotte */
  const giorniAttivi = {}; rec.forEach(function(x){ giorniAttivi[etaKey(x.at)] = 1; });
  const nAttivi = Object.keys(giorniAttivi).length;
  if (nAttivi >= c.minGiorni){
    const molla = rec.filter(function(x){ return !x.ok; });
    const giorniMolla = {}; molla.forEach(function(x){ giorniMolla[etaKey(x.at)] = 1; });
    if (Object.keys(giorniMolla).length >= c.minRicorrenze){
      const perse = molla.reduce(function(a, x){ return a + Math.max(0, (x.min || 25) * 60000 - (x.spentMs || 0)); }, 0) / 3600000;
      proietta('interrotte', perse / nAttivi);
    }
    /* lavoro fuori finestra */
    const seg = ETA.seg || {};
    if (seg.finestre && typeof seg.quotaFinestra === 'number' && seg.quotaFinestra < 0.5) proietta('fuoriFinestra', 0, etaQ(Object.assign({}, seg, { quotaFinestra: 0 }), ETA_CFG).Q);
  }
  /* giorni pianificati senza un'ora */
  const serie = (ETA.serie || []).filter(function(d){ return d.pian > 0 && !d.pausa; }).slice(0, c.finestra);
  const vuoti = serie.filter(function(d){ return d.credito < 0.25; }).length;
  if (serie.length >= c.minGiorni && vuoti >= c.minRicorrenze) proietta('vuoti', inp.piano.oreSettimana / 7 * (vuoti / serie.length));
  return out;
}
function etaAbitudiniHtml(){
  const a = etaAbitudini();
  return '<div class="eta-box"><b>' + etaT('tl.abit.titolo') + '</b><small>' + etaT('tl.abit.sotto') + '</small>'
    + (a.length ? a.map(function(x){ return '<div class="eta-leva"><b>' + etaEsc(x.txt) + '</b><i>' + x.frase + '</i></div>'; }).join('') : '<p class="eta-nota">' + etaT('tl.abit.vuoto') + '</p>')
    + '</div>';
}
function etaFantasmaHtml(){
  const s = ETA.stato, inp = ETA.inp;
  if (!s || !inp) return '';
  const g = etaFantasma(ETA.tassi || [], inp, ETA_CFG);
  let corpo;
  if (!g || !isFinite(g.p50) || !isFinite(s.p50)) corpo = '<p class="eta-nota">' + etaT('tl.fantasma.vuoto') + '</p>';
  else {
    const sett = Math.round((s.p50 - g.p50) / (7 * 86400000));
    corpo = '<p>' + (sett >= 1 ? etaT('tl.fantasma.frase', { n: sett }) : etaT('tl.fantasma.vicino')) + '</p>';
  }
  let partita = '';
  try{ if (typeof mtState === 'function'){ const m = mtState(); partita = '<small class="eta-partita" onclick="mgOpen()">' + etaT('tl.fantasma.partita', { neo: m.neo || 0, old: m.old || 0 }) + '</small>'; } }catch(_){ }
  return '<div class="eta-box"><b>' + etaT('tl.fantasma.titolo') + '</b>' + corpo + partita + '</div>';
}
function etaAffidHtml(){
  const a = etaAffidabilitaOra();
  return '<div class="eta-box"><b>' + etaT('tl.affid.titolo') + '</b>'
    + '<p>' + (a.n ? etaT('tl.affid.frase', { dentro: a.dentro, n: a.n }) : etaT('tl.affid.vuoto')) + '</p>'
    + '<small>' + etaT('tl.affid.varianza', { v: etaNum(a.varianza, 2) }) + '</small></div>';
}
function etaVeicoloHtml(){
  const p = etaVeicoloProve();
  const u = p[p.length - 1];
  const eff = etaVeicoloEffetto();
  let esito = etaT('tl.veicolo.mai');
  if (u){
    esito = (u.rtt === null && !u.tipo) ? etaT('tl.veicolo.nd') : etaT('tl.veicolo.esito', { tipo: u.tipo || '—', rtt: u.rtt === null ? '—' : u.rtt });
    esito += ' ' + (eff < 0 ? etaT('tl.veicolo.lento', { pct: Math.round(-eff * 100) }) : etaT('tl.veicolo.ok'));
  }
  return '<div class="eta-box"><b>' + etaT('tl.veicolo.titolo') + '</b><small>' + etaT('tl.veicolo.sotto') + '</small><p>' + esito + '</p>'
    + '<button type="button" class="ghostmini" onclick="etaVeicoloProva()">' + etaT('tl.veicolo.bottone') + '</button></div>';
}
/* ---- la scheda «inizio vs oggi» ---- */
function etaInizioHtml(){
  const s = ETA.stato, prima = etaLeggi('prima', null);
  if (!s || !prima) return '<p class="hintline">' + etaT('tl.inizio.vuoto') + '</p>';
  const d = (isFinite(s.p50) && isFinite(prima.p50)) ? s.p50 - prima.p50 : null;
  const div = d === null ? '—' : (Math.abs(d) < 60000 ? etaT('tl.inizio.uguale') : (d < 0 ? etaT('tl.inizio.avanti', { delta: etaDeltaTxt(d, ETA_CFG, true) }) : etaT('tl.inizio.indietro', { delta: etaDeltaTxt(d, ETA_CFG, true) })));
  const snap = etaLeggi('snap', {}) || {};
  const ks = Object.keys(snap).sort();
  let grafico = '';
  if (ks.length >= 2){
    const W = 320, H = 120, pad = 6;
    const xs = ks.map(function(k){ return etaDaKey(k); });
    const x0 = xs[0], x1 = xs[xs.length - 1] || x0 + 1;
    const ys = ks.map(function(k){ return snap[k]; });
    const tutti = [];
    ys.forEach(function(y){ [y.p10, y.p50, y.p90].forEach(function(v){ if (isFinite(v)) tutti.push(v); }); });
    const y0 = Math.min.apply(null, tutti), y1 = Math.max.apply(null, tutti) || y0 + 1;
    const X = function(t){ return pad + (x1 > x0 ? (t - x0) / (x1 - x0) : 0) * (W - 2 * pad); };
    const Y = function(v){ return H - pad - (y1 > y0 ? (v - y0) / (y1 - y0) : 0.5) * (H - 2 * pad); };
    const linea = ks.map(function(k, i){ return (i ? 'L' : 'M') + X(xs[i]).toFixed(1) + ' ' + Y(ys[i].p50).toFixed(1); }).join(' ');
    const banda = ks.map(function(k, i){ return (i ? 'L' : 'M') + X(xs[i]).toFixed(1) + ' ' + Y(ys[i].p10).toFixed(1); }).join(' ')
      + ' ' + ks.slice().reverse().map(function(k, j){ const i = ks.length - 1 - j; return 'L' + X(xs[i]).toFixed(1) + ' ' + Y(ys[i].p90).toFixed(1); }).join(' ') + ' Z';
    grafico = '<p class="dp-sotto">' + etaT('tl.inizio.grafico') + '</p><svg class="eta-graf" viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '">'
      + '<path d="' + banda + '" fill="rgba(0,117,227,.16)"/><path d="' + linea + '" fill="none" stroke="#0075E3" stroke-width="2.5" stroke-linejoin="round"/></svg>'
      + '<div class="eta-graf-x"><span>' + etaDataTxt(x0, true) + '</span><span>' + etaDataTxt(x1, true) + '</span></div>';
  } else grafico = '<p class="hintline">' + etaT('tl.inizio.vuoto') + '</p>';
  return '<div class="eta-box eta-inizio">'
    + '<div class="eta-due"><div><small>' + etaT('tl.inizio.prima') + '</small><b>' + etaEsc(etaDataTxt(prima.p50)) + '</b></div>'
    + '<div><small>' + etaT('tl.inizio.oggi') + '</small><b>' + etaEsc(etaDataTxt(s.p50)) + '</b></div></div>'
    + '<p class="eta-divario"><span>' + etaT('tl.inizio.divario') + '</span> <b>' + etaEsc(div) + '</b></p>'
    + grafico + '</div>';
}
/* ---- la scheda «calendario della vita» ---- */
function etaVitaOk(){ try{ return localStorage.getItem(ETA_K.vita) === '1'; }catch(_){ return false; } }
function etaVitaAccetta(si){ try{ localStorage.setItem(ETA_K.vita, si ? '1' : '0'); }catch(_){ } if (!si) ETA.tab = 'ricalcoli'; etaTlPaint(); }
function etaVitaHtml(){
  if (!etaVitaOk()) return '<div class="eta-box eta-vita-intro"><b>' + etaT('tl.vita.titolo') + '</b><p>' + etaT('tl.vita.intro') + '</p>'
    + '<button type="button" class="cta" onclick="etaVitaAccetta(true)">' + etaT('tl.vita.si') + '</button>'
    + '<button type="button" class="ghostmini" onclick="etaVitaAccetta(false)">' + etaT('tl.vita.no') + '</button></div>';
  const c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c) return '<div class="eta-box"><b>' + etaT('tl.vita.titolo') + '</b><p>' + etaT('tl.vita.nascita') + '</p>'
    + '<button type="button" class="cta" onclick="mmOpen(\'s-eta\')">' + etaT('tl.vita.apri') + '</button></div>';
  const s = ETA.stato, prima = etaLeggi('prima', null);
  const nato = (typeof mmNascita === 'function') ? etaDaKey(mmNascita()) : 0;
  const sett = function(ts){ return (nato && isFinite(ts)) ? Math.floor((ts - nato) / (7 * 86400000)) : -1; };
  const wA = sett(s && s.p50), wP = sett(prima && prima.p50);
  const anni = (typeof mmAnni === 'function') ? mmAnni() : 80;
  setTimeout(function(){ if (typeof mmDisegna === 'function') mmDisegna(c, anni, { canvas: document.getElementById('etaVitaCanvas'), segni: [{ settimana: wP, tipo: 'inizio' }, { settimana: wA, tipo: 'attuale' }] }); }, 30);
  return '<div class="eta-box"><b>' + etaT('tl.vita.titolo') + '</b>'
    + (wA >= 0 ? '<p>' + etaT('tl.vita.settimana', { n: wA + 1, anni: Math.floor(wA / 52) }) + '</p>' : '')
    + '<div class="mm-griglia eta-vita"><canvas id="etaVitaCanvas"></canvas></div>'
    + '<div class="eta-legenda"><span><i class="inizio"></i>' + etaT('tl.vita.legenda.inizio') + '</span><span><i class="attuale"></i>' + etaT('tl.vita.legenda.attuale') + '</span></div>'
    + '</div>';
}
function etaTlPaint(){
  if (typeof document === 'undefined') return;
  const host = document.getElementById('etaBody');
  if (!host) return;
  const t = document.getElementById('etaTitolo'); if (t) t.textContent = etaT('tl.titolo');
  if (!ETA.stato){ ETA.stato = etaLeggi('stato', null) || etaCalcola(); }
  const s = ETA.stato;
  if (!s){ host.innerHTML = '<p class="hintline">' + etaT('card.nessuno') + '</p>'; return; }
  if (!ETA.inp) etaCalcola();
  const tabs = ['ricalcoli', 'inizio', 'vita'];
  let html = '<div class="ins-tabs">' + tabs.map(function(k){ return '<button type="button" class="' + (ETA.tab === k ? 'on' : '') + '" onclick="etaTlTab(\'' + k + '\')">' + etaT('tl.tab.' + k) + '</button>'; }).join('') + '</div>';
  if (ETA.tab === 'ricalcoli'){
    const periodi = ['oggi', '7', '30', 'tutto'];
    html += '<div class="dp-chip eta-chip">' + periodi.map(function(p){ return '<button type="button" class="' + (ETA.periodo === p ? 'on' : '') + '" onclick="etaTlPeriodo(\'' + p + '\')">' + etaT('tl.periodo.' + p) + '</button>'; }).join('') + '</div>';
    html += etaPassoHtml(s);
    const voci = etaTlVoci();
    const conDelta = voci.filter(function(v){ return v.delta !== null; });
    const netto = conDelta.reduce(function(a, v){ return a + v.delta; }, 0);
    const su = conDelta.filter(function(v){ return v.delta < 0; }).sort(function(a, b){ return a.delta - b.delta; }).slice(0, 3);
    const giu = conDelta.filter(function(v){ return v.delta > 0; }).sort(function(a, b){ return b.delta - a.delta; }).slice(0, 3);
    const lista = function(arr, titolo){ return '<div class="dp-cl"><b class="dp-cl-t">' + titolo + '</b>' + (arr.length ? arr.map(function(v){ return '<p><span>' + etaEsc(etaCausaTxt(v)) + '</span><b class="' + (v.delta < 0 ? 'su' : 'giu') + '">' + etaEsc(etaDeltaTxt(v.delta, ETA_CFG)) + '</b></p>'; }).join('') : '<p class="dp-cl-0">—</p>') + '</div>'; };
    html += '<div class="dp-conto eta-netto">' + (Math.abs(netto) >= 60000 ? etaT('tl.netto', { delta: '<b class="' + (netto < 0 ? 'su' : 'giu') + '">' + etaDeltaTxt(netto, ETA_CFG) + '</b>' }) : etaT('tl.nettoZero')) + '</div>'
      + '<div class="dp-cls">' + lista(su, etaT('tl.su')) + lista(giu, etaT('tl.giu')) + '</div>'
      + '<div class="sect"><b>🕒 ' + etaT('tl.tab.ricalcoli') + '</b></div>'
      + (voci.length ? '<div class="dp-ev">' + voci.slice().reverse().map(etaVoceHtml).join('') + '</div>' : '<p class="hintline">' + etaT('tl.vuoto') + '</p>')
      + etaLeveHtml() + etaAbitudiniHtml() + etaFantasmaHtml() + etaAffidHtml() + etaVeicoloHtml() + etaImprevistoHtml()
      + '<p class="dp-sotto dp-portariga"><span class="dp-link" onclick="etaInfoApri()">' + etaT('tl.info') + ' ›</span></p>';
  } else if (ETA.tab === 'inizio') html += etaInizioHtml();
  else html += etaVitaHtml();
  host.innerHTML = html;
}

/* ---------------------------------------------------------------------------------------
   GLI EVENTI: ogni cosa significativa ricalcola, con la sua causa
   --------------------------------------------------------------------------------------- */
function etaRimandoSegna(testo){
  const ev = etaLeggi('eventi', []) || [];
  ev.push({ at: Date.now(), tipo: 'rimandata', testo: String(testo || '').slice(0, 120) });
  etaScrivi('eventi', ev.slice(-300));
  return etaRimandi(testo);
}
async function etaControllaPC(){
  if (etaAutorita() !== 'telefono' || typeof pcSync !== 'function' || !ETA.stato) return;
  try{ await pcSync(false); }catch(_){ return; }
  const viaggio = etaViaggio();
  if (!viaggio || !etaPcConta(viaggio)) return;
  const d = (typeof pcGiorno === 'function') ? pcGiorno(0) : null;
  const min = d ? (d.prod || 0) : 0;
  if (ETA.pcOggi === null){ ETA.pcOggi = Math.round(ETA.stato.pcOggi * 60); }
  if (Math.abs(min - ETA.pcOggi) >= ETA_CFG.pcLavoro.sogliaVoceMin){
    ETA.pcOggi = min;
    etaEvento('pc', { ore: etaDeltaTxt(min * 60000, ETA_CFG, true), min: min }, '', 'pc:' + etaOggiK());
  }
}
function etaAgganci(){
  document.addEventListener('fl:spunta', function(e){
    const d = e && e.detail;
    if (!d || !d.line) return;
    if (d.azione === 'ritirata'){ if (etaScredita('riga', d.line, d.day)) etaEvento('ritirata', {}, d.line); return; }
    const v = etaAccredita('riga', d.line, d.day);
    if (v) etaEvento('riga', etaVarsCredito(v), d.line);
  });
  document.addEventListener('fl:piano', function(){ etaEvento('roadmap', {}); });
  /* 0.9.285: una richiesta fuori rotta registrata dall'arbitro sul computer: l'arrivo si ricalcola subito */
  document.addEventListener('fl:deviazione', function(){
    let reg = []; try{ reg = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || []; }catch(_){ }
    const oggi0 = etaMezzanotte();
    const nuove = reg.filter(function(e){ return e && +e.at >= oggi0; });
    if (!nuove.length) return;
    const ultima = nuove[nuove.length - 1];
    const prima = ETA.stato;
    const visti = etaLeggi('devVisti', []) || [];
    const dopo = etaEvento('deviazione', { ore: etaNum(Math.max(5, +ultima.minuti || etaDevCfg().minutiDefault) / 60, 1) + ' h' }, String(ultima.motivo || ''), 'dev:' + etaOggiK());
    if (visti.indexOf(ultima.id) < 0){ visti.push(ultima.id); etaScrivi('devVisti', visti.slice(-200)); etaDevToast(dopo, prima, etaT('dev.idea')); }
  });
  /* le righe nuove tenute nel foglio con la priorita' ancora aperta (ulisse.js): sono idee fuori rotta tenute */
  if (typeof ulFuoriTengo === 'function'){
    const origFT = ulFuoriTengo;
    ulFuoriTengo = function(){ const r = origFT.apply(this, arguments); try{ etaDeviazione(etaT('dev.righe'), ETA_CFG.stimaProvvisoria.riga, 'foglio'); }catch(_){ } return r; };
    try{ window.ulFuoriTengo = ulFuoriTengo; }catch(_){ }
  }
  document.addEventListener('fl:giorno', function(){ etaControllaGiorno(); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden){ etaControllaGiorno(); etaControllaPC(); } });
  setInterval(function(){ etaControllaGiorno(); etaControllaPC(); }, 5 * 60000);
  /* la priorita' archiviata (dal foglio o dalla sessione) */
  if (typeof stOneComplete === 'function'){
    const orig = stOneComplete;
    stOneComplete = function(prova){
      const one = (typeof stOne === 'function') ? stOne() : null;
      const n0 = (typeof stOneHist === 'function') ? stOneHist().length : 0;
      const r = orig.apply(this, arguments);
      const n1 = (typeof stOneHist === 'function') ? stOneHist().length : 0;
      if (n1 > n0 && one){ const t = String((one.task && (one.task.text || one.task)) || ''); const v = etaAccredita('priorita', t, etaOggiK()); if (v) etaEvento('priorita', etaVarsCredito(v), t); }
      return r;
    };
  }
  /* la task chiusa in sessione */
  if (typeof ffRispondi === 'function'){
    const orig = ffRispondi;
    ffRispondi = function(si){
      const box = document.getElementById('ffAsk');
      const task = box ? (box.dataset.task || '') : '';
      const r = orig.apply(this, arguments);
      if (si && task){ const v = etaAccredita('completata', task, etaOggiK()); if (v) etaEvento('completata', etaVarsCredito(v), task); }
      return r;
    };
  }
  /* la sessione finita: le sue ore sono gia' nel registro */
  if (typeof ffDoneOpen === 'function'){
    const orig = ffDoneOpen;
    ffDoneOpen = function(ok, run, coins){
      const r = orig.apply(this, arguments);
      try{
        /* i minuti veri stanno nell'ultima riga del registro delle sessioni, appena scritta */
        let h = []; try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
        const x = h[h.length - 1];
        const min = (x && Math.abs((x.at || 0) - Date.now()) < 60000) ? Math.round((x.spentMs || 0) / 60000) : ((run && run.minutes) || 0);
        if (ok) etaEvento(run && run.intent ? 'sessione' : 'sessioneSenza', { min: min }, (run && run.intent) || '');
        else etaEvento('mollata', { min: min }, (run && run.intent) || '');
      }catch(_){ }
      return r;
    };
  }
  if (typeof ffRipianifica === 'function'){
    const orig = ffRipianifica;
    ffRipianifica = function(){
      const box = document.getElementById('ffAsk');
      const task = box ? (box.dataset.task || '') : '';
      const r = orig.apply(this, arguments);
      if (task){ const n = etaRimandoSegna(task); etaEvento('rimandata', { n: n }, task); }
      return r;
    };
  }
  if (typeof ffStorna === 'function'){
    const orig = ffStorna;
    ffStorna = function(at, motivo){
      const r = orig.apply(this, arguments);
      if (r){
        let h = [];
        try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
        const x = h.filter(function(e){ return e && Math.abs((e.at || 0) - at) < 60000; })[0];
        const t = x ? (x.task || x.intent || '') : '';
        const v = etaScredita('completata', t, etaKey(at)) || etaScredita('priorita', t, etaKey(at)) || etaScredita('riga', t, etaKey(at));
        etaEvento('storno', { ore: v ? etaNum(v.extraOre, 1) : '0' }, t);
      }
      return r;
    };
  }
  if (typeof ozSpunta === 'function'){
    const orig = ozSpunta;
    ozSpunta = function(k, j){
      const r = orig.apply(this, arguments);
      try{
        const p = ozAnello(k).passi[j];
        if (p){
          if (p.fatto){ const v = etaAccredita('oz', p.t, '', k); if (v) etaEvento('passo', etaVarsCredito(v), p.t); }
          else if (etaScredita('oz', p.t, '')) etaEvento('passoTolto', {}, p.t);
        }
      }catch(_){ }
      return r;
    };
  }
  ['ozAggiungi', 'ozPulisci', 'ozScriviTesto'].forEach(function(nome){
    if (typeof window[nome] !== 'function') return;
    const orig = window[nome];
    window[nome] = function(){ const r = orig.apply(this, arguments); setTimeout(function(){ etaEvento('roadmap', {}); }, 50); return r; };
  });
  if (typeof stRigaStima === 'function'){
    const orig = stRigaStima;
    stRigaStima = function(n){
      const r = orig.apply(this, arguments);
      try{ etaEvento('stima', { min: n }, (typeof STR !== 'undefined' && STR && STR.line) || ''); }catch(_){ }
      return r;
    };
  }
  /* la lettura del Genio cambia la strada */
  if (typeof gnApplica === 'function'){
    const orig = gnApplica;
    gnApplica = function(){ const r = orig.apply(this, arguments); setTimeout(function(){ etaEvento('genio', {}); }, 100); return r; };
  }
}

/* ---------------------------------------------------------------------------------------
   L'AVVIO
   --------------------------------------------------------------------------------------- */
function etaAvvia(){
  etaMigraPrecisione();
  etaTestiCarica();
  etaAgganci();
  try{ if (typeof PC !== 'undefined' && !PC.doc && typeof pcLeggiCache === 'function'){ const c = pcLeggiCache(); if (c && c.doc) PC.doc = c.doc; } }catch(_){ }
  const salvato = etaLeggi('stato', null);
  if (salvato) ETA.stato = salvato;
  etaControllaGiorno();
  if (!ETA.stato) etaRicalcola(null);
  else if (ETA.stato.giorno === etaOggiK() && etaAutorita() === 'telefono'){
    /* stesso giorno: un ricalcolo muto, per i dati arrivati mentre l'app era chiusa */
    const p = ETA.stato;
    const dopo = etaCalcola();
    if (dopo && isFinite(p.p50) && isFinite(dopo.p50) && Math.abs(dopo.p50 - p.p50) >= 60000){
      /* 0.9.321, Andrea: "-2 giorni, lavoro al computer: 0 minuti". Qualunque ricalcolo all'apertura finiva sotto "Lavoro al computer",
         anche con zero minuti di computer. Il computer si nomina solo se ha contato davvero. */
      if (dopo.pcOggi > p.pcOggi) etaRicalcola({ tipo: 'pc', vars: { ore: etaDeltaTxt(dopo.pcOggi * 3600000, ETA_CFG, true) }, chiave: 'pc:' + etaOggiK() });
      else etaRicalcola({ tipo: 'aggiornamento', vars: {}, chiave: 'agg:' + etaOggiK() });
    } else etaRicalcola(null);           // scrive stato, prima previsione e istantanea, senza voce
  }
  ETA.ultimoDelta = (etaBollino() || {}).delta;
  ETA.pcOggi = ETA.stato ? Math.round(ETA.stato.pcOggi * 60) : null;
  setTimeout(etaControllaPC, 4000);
}
if (typeof document !== 'undefined'){
  document.addEventListener('DOMContentLoaded', function(){ setTimeout(etaAvvia, 0); });
  document.addEventListener('fl:tema', function(){ if (document.getElementById('etaVitaCanvas')) etaTlPaint(); });
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */
if (typeof document !== 'undefined') (function etaStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.mp-stima{display:inline-block;margin-left:6px;padding:2px 7px;border-radius:99px;font:800 9.5px var(--font-body);font-style:normal;letter-spacing:.1em;text-transform:uppercase;color:#cfe0ff;background:rgba(255,255,255,.12)}',
    '.mp-delta-wrap{margin-top:10px}',
    '.mp-delta{cursor:pointer}',
    '.mp-calibro{display:block;margin-top:8px;font:600 11px var(--font-body);color:rgba(255,255,255,.62)}',
    '.mp-arrivo small.mp-arrivo-cd.mp-salto{animation:etaSalto .7s ease-out}',
    '@keyframes etaSalto{0%{color:#6FC0FF;transform:scale(1.06)}100%{color:rgba(255,255,255,.78);transform:none}}',
    '.eta-page .ins-tabs{margin-top:6px}',
    '.eta-chip{margin:10px 0 14px}',
    '.eta-box{margin:0 0 14px;padding:14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff);text-align:left}',
    'body.dark .eta-box{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.eta-box > b{display:block;font:800 15px var(--font-display);color:var(--navy)}',
    'body.dark .eta-box > b{color:#fff}',
    '.eta-box > small{display:block;margin:4px 0 10px;font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.eta-box > p{margin:8px 0;font:500 13px/1.55 var(--font-body);color:var(--navy)}',
    'body.dark .eta-box > p{color:#fff}',
    '.eta-box .cta,.eta-box .btn{margin-top:10px}',
    '.eta-passo-r{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;border-top:1px solid var(--line)}',
    '.eta-passo-r div b{display:block;font:700 13px var(--font-body);color:var(--navy)}',
    'body.dark .eta-passo-r div b{color:#fff}',
    '.eta-passo-r div small{display:block;margin-top:2px;font:500 11px/1.45 var(--font-body);color:var(--muted)}',
    '.eta-passo-r > div{flex:1;min-width:0}',
    '.eta-passo-r > i{flex:none;max-width:50%;text-align:right;font:800 15px/1.25 var(--font-display);font-style:italic;color:var(--blue,#0075E3)}',
    '.eta-calibro{margin:2px 0 8px;font:700 12px var(--font-body)}',
    '.eta-calibro.in{color:#B8860B}.eta-calibro.ok{color:#1B9E6A}',
    '.eta-nota{margin:8px 0 0;font:600 12px/1.5 var(--font-body);color:var(--muted)}',
    '.eta-collo{color:#B8860B}',
    '.eta-netto{margin:6px 0 10px}',
    '.eta-netto b.su{color:#1B9E6A}.eta-netto b.giu{color:#E63946}',
    '.eta-voce > div{flex:1;min-width:0}',
    '.eta-voce.zero .dp-evn{color:var(--muted)}',
    '.eta-come{display:inline-block;margin-top:6px;border:0;background:none;padding:0;font:700 11.5px var(--font-body);color:var(--blue,#0075E3);cursor:pointer}',
    '.eta-come-box{margin-top:8px;padding:10px 12px;border-radius:12px;background:rgba(0,117,227,.07)}',
    'body.dark .eta-come-box{background:rgba(0,117,227,.18)}',
    '.eta-come-box p{margin:0 0 8px;font:500 12px/1.55 var(--font-body);color:var(--navy)}',
    'body.dark .eta-come-box p{color:#fff}',
    '.eta-come-box ul{list-style:none;margin:0;padding:0}',
    '.eta-come-box li{display:flex;justify-content:space-between;gap:10px;font:500 11.5px var(--font-body);color:var(--muted);padding:3px 0}',
    '.eta-come-box li b{color:var(--navy);font-weight:700;text-align:right}',
    'body.dark .eta-come-box li b{color:#fff}',
    '.eta-leva{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;border-top:1px solid var(--line)}',
    '.eta-leva b{font:700 13px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .eta-leva b{color:#fff}',
    '.eta-leva i{flex:none;font:800 12px var(--font-body);font-style:normal;color:#1B9E6A;text-align:right;max-width:46%}',
    '.eta-partita{display:block;margin-top:6px;font:600 11.5px var(--font-body);color:var(--blue,#0075E3);cursor:pointer}',
    '.eta-pausa{font:700 13px var(--font-body);color:#B8860B}',
    '.eta-motivi{margin:8px 0 10px;display:flex;flex-wrap:wrap;gap:8px}',
    '.eta-motivi p{width:100%;margin:0 0 2px;font:600 12.5px var(--font-body);color:var(--muted)}',
    '.eta-motivi button{border:1px solid var(--line);background:none;border-radius:99px;padding:7px 12px;font:700 12px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .eta-motivi button{color:#fff;border-color:rgba(255,255,255,.25)}',
    '.eta-motivi button.eta-annulla{color:var(--muted)}',
    '.eta-giorni{display:flex;gap:6px;margin:-4px 0 14px}',
    '.eta-giorni button{flex:1;height:36px;border:1px solid var(--line);background:none;border-radius:10px;font:800 12px var(--font-body);color:var(--muted);cursor:pointer}',
    '.eta-giorni button.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .eta-giorni button.on{background:#0075E3;border-color:#0075E3}',
    '.eta-due{display:flex;gap:12px;text-align:center}',
    '.eta-due > div{flex:1}',
    '.eta-due small{display:block;font:600 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.eta-due b{display:block;margin-top:4px;font:800 16px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .eta-due b{color:#fff}',
    '.eta-divario{margin:12px 0 4px;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.eta-divario b{color:var(--navy)}body.dark .eta-divario b{color:#fff}',
    '.eta-graf{display:block;margin-top:6px}',
    '.eta-graf-x{display:flex;justify-content:space-between;font:600 10.5px var(--font-body);color:var(--faint)}',
    '.eta-vita{margin-top:10px}',
    '.eta-legenda{display:flex;gap:16px;justify-content:center;margin-top:10px}',
    '.eta-legenda span{display:flex;align-items:center;gap:6px;font:600 11px var(--font-body);color:var(--muted)}',
    '.eta-legenda i{width:12px;height:12px;border-radius:2px}',
    '.eta-legenda i.inizio{border:2px dashed #0075E3}.eta-legenda i.attuale{background:#0075E3}',
    '.eta-vita-intro .ghostmini{margin-top:8px}',
    '.eta-info p{font:500 13.5px/1.65 var(--font-body);color:var(--navy);margin:0 0 14px}',
    'body.dark .eta-info p{color:#fff}'
  ].join('');
  document.head.appendChild(st);
})();

if (typeof module !== 'undefined' && module.exports){
  module.exports = { ETA: ETA, etaT: etaT, etaBollino: etaBollino, etaIstantaneaPrima: etaIstantaneaPrima, etaRicalcola: etaRicalcola, etaCalcola: etaCalcola,
    etaAccredita: etaAccredita, etaScredita: etaScredita, etaControllaGiorno: etaControllaGiorno, etaChiudiGiornate: etaChiudiGiornate,
    etaPiano: etaPiano, etaViaggio: etaViaggio, etaLog: etaLog, etaLeggi: etaLeggi, etaScrivi: etaScrivi, etaTlVoci: etaTlVoci,
    etaImprevistoInizia: etaImprevistoInizia, etaImprevistoFine: etaImprevistoFine, etaInPausa: etaInPausa, etaRimandi: etaRimandi, etaRimandoSegna: etaRimandoSegna,
    etaMigraPrecisione: etaMigraPrecisione, etaPrecisione: etaPrecisione, etaArrivo: etaArrivo, etaLeve: etaLeve, etaTaskAperte: etaTaskAperte, etaEvento: etaEvento, etaColli: etaColli };
}

/* ===========================================================================================
   L'ARRIVO VELATO (0.9.255, Andrea). Nella prima settimana la data d'arrivo non si vede: e' una
   previsione fatta senza dati, e una data sbagliata il primo giorno pesa piu' di nessuna data.
   Si svela quando il Genio ha letto il paradigma (il boss «I tuoi freni», blocchi.js) E sono
   passati almeno sette giorni dal primo avvio (fl_first_run). Fino ad allora chi disegna la
   data chiede qui, e mostra il velo con il motivo.
   =========================================================================================== */
const EV_GIORNI = 7;
/* 0.9.288, Andrea: "il badge dice sempre: la data arriva fra 7 giorni". Sui telefoni da tempo fl_first_run e' un numero
   ("1726000000000"): new Date() su quella stringa non e' una data, e il conto ripartiva da adesso a ogni apertura.
   flPrimoAvvioSegna (registry.js) legge tutti e due i formati, e se manca lo segna una volta sola. */
function evPrimoAvvio(){ try{ const t = (typeof flPrimoAvvioSegna === 'function') ? flPrimoAvvioSegna() : 0; return t > 0 ? t : Date.now(); }catch(_){ return Date.now(); } }
function evLetto(){ try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : null; return !!(b && b.primario); }catch(_){ return false; } }
function evGiorniMancanti(){ return Math.max(0, EV_GIORNI - Math.floor((Date.now() - evPrimoAvvio()) / 86400000)); }
/* 0.9.300: la data la svela l'episodio 7 della serie del Genio ("La sfera parla"): da li' in poi si vede sempre */
function evVelata(){ try{ if (typeof epiDataSvelata === 'function' && epiDataSvelata()) return false; }catch(_){ } return evGiorniMancanti() > 0 || !evLetto(); }
/** Il motivo, in una riga, per chi lo chiede. */
/* 0.9.265, Andrea: "Si svela fra 7 giorni" in giallo sopra la data, e sotto un badge verde "Prima previsione: da domani
   il confronto": due frasi che si contraddicono. Adesso la spiegazione e' UNA, nel badge: per calcolare la traiettoria il
   Genio deve prima conoscere le tue abitudini (sette giorni), e anche dopo "Leggi me" servono quei giorni. */
function evMotivo(){
  const g = evGiorniMancanti();
  if (g > 0) return 'Il Genio sta imparando le tue abitudini per calcolare la tua traiettoria: la data arriva fra ' + g + (g === 1 ? ' giorno' : ' giorni');
  return 'Per calcolare la tua traiettoria il Genio deve leggere i tuoi blocchi inconsci: fai "Leggi me" sulla Mappa';
}
/* 0.9.276, Andrea: "non su un pannello verde (il verde e' solo per i miglioramenti), centrato, piu' corto, e la
   spiegazione solo se la tocchi". Una riga breve; il resto in un foglio. */
function evBreve(){
  const g = evGiorniMancanti();
  if (g > 0) return 'La data arriva fra ' + g + (g === 1 ? ' giorno' : ' giorni');
  return 'Fai "Leggi me" per vedere la data';
}
function evSpiega(){
  if (typeof stgFoglio !== 'function') return;
  const g = evGiorniMancanti();
  stgFoglio('<small class="stg-eti">Arrivo previsto</small><h2 class="stg-h">Perché la data non c\'è ancora</h2>'
    + '<div class="sc-come">'
    + (g > 0 ? '<div><span>🔍</span><p><b>Il Genio ti sta conoscendo</b>Guarda come usi le tue giornate per ' + EV_GIORNI + ' giorni.</p></div>' : '')
    + '<div><span>🧭</span><p><b>Poi calcola la traiettoria</b>Dalle tue abitudini vere, non da una stima.</p></div>'
    + (!evLetto() ? '<div><span>🐉</span><p><b>Serve anche "Leggi me"</b>È il livello dei tuoi blocchi inconsci, sulla Mappa.</p></div>' : '')
    + '</div><button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho capito</button>');
}
if (typeof document !== 'undefined') (function(){
  const st = document.createElement('style');
  st.textContent = [
    /* censurata davvero: le cifre non si leggono, si intuisce solo che una data c'e' */
    '.ev-velo{position:relative;user-select:none;pointer-events:none}.ev-velo > b,.ev-velo > span{filter:blur(15px);opacity:.85}',
    '.nv-pill.velo{display:inline-flex;align-items:center;justify-content:center;gap:8px;max-width:300px;white-space:normal;text-align:center;line-height:1.35;padding:9px 16px;border-radius:999px;background:rgba(255,255,255,.16)!important;color:#fff;cursor:pointer;border:0;font:600 13.5px var(--font-body)}',
    '.nv-pill.velo svg{flex:none}',
    '.ev-velo-riga{font:600 13px var(--font-body);color:var(--muted,#5B6B86)}'
  ].join('');
  document.head.appendChild(st);
})();
