/* ---------------------------------------------------------------------------------------
   DOPAMINA — TUTTI I PARAMETRI DEL MODELLO, IN UN POSTO SOLO (dopamineConfig)

   Il motore (dopamina-motore.js) non contiene numeri: li legge tutti da qui. Per tarare il
   modello si cambia questo file e basta. Accanto a ogni numero c'e' cosa fa e, dove c'e',
   l'esempio che lo misura (i test in tools/test-dopamina.js).

   DUE GRANDEZZE CHE NON SI MESCOLANO MAI
     · RISERVA (tonica) → il tachimetro. 50 e' la base, 100 il serbatoio pieno. Sale SOLO con
       azioni sane (sforzo portato a termine, sonno, movimento, pause, costanza). Lo stimolo
       rapido non la alza mai: la abbassa, con il debito che lascia.
     · STIMOLAZIONE (fasica) → la curva sotto al tachimetro. Picchi e crolli: un picco alto qui
       NON e' una buona notizia, e' stimolazione a basso sforzo.

   E' un modello CONCETTUALE e motivazionale, non una misura medica.
   --------------------------------------------------------------------------------------- */
const DM_CFG = {
  /* ---- la scala ---- */
  base: 50,                    // il basale: il punto a cui si torna
  min: 0, max: 100,            // la riserva resta sempre qui dentro
  weatherModifier: 0,          // gancio per il meteo: si somma al basale. Non implementato (0).
  sunlightHook: 0,             // gancio per la luce solare: non implementato (0).

  /* ---- il ritorno verso la base, da svegli e senza stimoli ----
     Da SOTTO sale del 10% della distanza all'ora: da 11, 20 minuti -> 12,3; da 30, un'ora -> 32.
     Da SOPRA scende piano, del 4% all'ora: i guadagni sani durano ma vanno mantenuti.
     (Il prompt proponeva il 3%: da 80, dopo 3 ore, 77,4 — fuori dalla forchetta 76-77 del suo
     stesso test. Col 4% sono 76,5.) Durante il sonno niente decadimento. */
  ritornoOra: 0.9,
  sopraOra: 0.96,

  /* ---- il sonno: al risveglio recupera una parte della distanza SOTTO la base ----
     [ore minime, quota recuperata]. Sopra la base il sonno consolida: non toglie niente.
     Sotto le 4 ore: niente recupero e una penalita'. */
  sonno: [[7, 0.60], [6, 0.45], [5, 0.30], [4, 0.15]],
  sonnoCorto: -2.0,
  sonnoMinOre: 3,              // un buco piu' corto non e' una notte
  sonnoPassiMax: 400,          // piu' passi di cosi' dentro al «sonno»: non era sonno

  /* ---- picchi e debito ----
     Una sessione ad alta intensita' di almeno 10 minuti. Il PICCO (da +2 a +6) va SOLO sulla
     curva Stimolazione; alla riserva arriva SOLO il DEBITO (da 3 a 8), minuto per minuto
     mentre la sessione dura, riassorbito del 15% all'ora. */
  altoMinMin: 10,
  altoBuco: 2 * 60000,         // due pezzi della stessa sessione possono avere un buco cosi'
  picco: [2, 6],               // da 10 minuti a un'ora
  piccoMinPer: [10, 60],       // la durata che va da un capo all'altro di picco e debito
  piccoSaleMin: 5,             // costante di salita del picco (minuti)
  piccoScendeMin: 15,          // costante di discesa: dopo 45 minuti ne resta il 5%
  debito: [3, 8],
  debitoOra: 0.15,
  /* la combo negativa (0.9.298): un picco entro tre ore dal precedente moltiplica il suo debito */
  comboDebito: [1, 1.25, 1.5, 1.75, 2],
  comboFinestraMin: 180,

  /* ---- l'uso leggero: messaggi, navigazione, app non categorizzate ----
     Costo al minuto per un'app a indice 1. Dieci minuti di web.telegram.org: -0,2.
     Un'apertura sotto al minuto: niente. */
  costoMedioMin: 0.06,
  aperturaMaxMs: 60000,

  /* ---- la dispersione: cambi fra app vere in dieci minuti, ogni dispositivo per conto suo (0.9.317) ---- */
  dispFinestraMin: 10,
  dispMinMs: 3000,             // una visita piu' corta non e' un cambio: e' un passaggio
  dispSoglie: [[10, -0.6], [5, -0.3]],

  /* ---- la mattina ---- */
  mattinaScrollMin: 15, mattinaScroll: -1.0,
  mattinaPulitaMin: 30, mattinaPulita: +0.5,

  /* ---- le notifiche: rispondere in automatico ---- */
  latFasciaOre: 2,
  latSogliaMs: 30000,
  latMinCampioni: 3,
  latMaxMs: 10 * 60000,
  latPenalita: -0.5,

  /* ---- FULL FOCUS: bonus di concentrazione, con rendimenti decrescenti ----
     [minuti effettivi, bonus]: fra un punto e l'altro si interpola. Sotto i 10 minuti niente,
     da 90 in su il tetto. Una sessione mollata vale per i minuti fatti, se sono almeno 10. */
  ffBonus: [[10, 0], [15, 0.4], [25, 0.8], [45, 1.5], [60, 2.0], [90, 2.8]],
  ffCompletata: +1.5,          // «Si', completata»: in piu' al bonus di concentrazione
  /* la meditazione: preset di FullFocus senza app consentite */
  meditazione: [[20, 1.2], [10, 0.8]],
  /* concentrazione misurata fuori da FullFocus (tanto tempo su una cosa produttiva sola) */
  focus: [[50, +1.2], [25, +0.5]],
  focusBuco: 2 * 60000,

  /* ---- il lavoro sugli obiettivi ---- */
  spunta: +0.5,                // ogni attivita' del piano portata a termine
  spunteMaxGiorno: 3.0,
  novitaSana: +0.8,            // una cosa del piano mai fatta prima (prima volta), al posto del +0,5
  novitaMaxGiorno: 1.6,
  novitaFuori: -0.5,           // un'app nuova installata dentro a una fascia pianificata
  gusto: +0.3,                 // dopo una cosa fatta, 5 minuti senza app che spremono
  gustoMin: 5,
  gustoMaxGiorno: 0.9,
  ioFuturo: +0.3,              // la prima lettura del giorno del messaggio dal tuo Io Futuro (sostituisce i «progressi guardati»)
  serieGiorno: 0.2,            // per ogni giorno di fila con il piano
  serieMax: 2.0,

  /* ---- la noia sana: telefono giu', niente focus, niente allenamento ---- */
  noiaMin: 20,
  noia: +0.3,
  noiaMaxGiorno: 3,            // blocchi al giorno

  /* ---- i check-in autodichiarati: pesano poco e hanno un tetto ---- */
  doccia: +0.5,                // doccia fredda, una al giorno
  autoMaxGiorno: 1.0,          // tetto di tutti i check-in autodichiarati insieme

  /* ---- il bianco e nero ---- */
  grigio: 0.6,                 // uno stimolo in bianco e nero vale il 60%

  /* ---- il movimento ---- */
  cammMinPassiMin: 60,         // da sessanta passi al minuto e' camminare
  cammBucoMin: 1,
  camm: [[30, +2.5], [10, +1.0]],
  cammMinPassi: 1000,
  cammDebitoX: 1.5,            // camminando il debito si riassorbe una volta e mezza piu' in fretta
  allenamento: [[45, +2.5], [20, +1.5]],   // corsa, ballo, pesi… da Health Connect
  passiObiettivo: 8000,
  passiObiettivoBonus: +1.0,
  movimentoMaxGiorno: 6.0,     // tanti passi possono essere lavoro (Andrea fa il corriere)

  /* ---- la notte ---- */
  notteDa: 0, notteA: 5,
  notteX: 2,                   // ogni penalita' (e il debito) pesa il doppio
  noiaDa: 7, noiaA: 23,        // la noia sana si conta solo di giorno

  /* ---- i tetti ---- */
  eventoMax: 5.0,              // nessun evento vale piu' di ±5 (il sonno ha la sua formula)
  caloOraMax: 8.0,             // in un'ora non si perdono piu' di 8 punti di penalita'

  /* ---- le tre parole sotto al numero ---- */
  bandaAlta: 56,
  bandaBase: 44,

  /* ---- le finestre produttive ---- */
  finestreGiorniMin: 14,       // prima non si dice niente: «sto imparando i tuoi ritmi»
  finestreOre: 2,

  /* ---- gli insight ---- */
  usoBucoMin: 15,              // due usi leggeri a meno di un quarto d'ora sono una voce sola
  voceMin: 0.05,               // le voci piu' piccole finiscono in «Variazioni minori»
  dedupeMs: 5000,
  curvaPassoMin: 10           // un punto ogni dieci minuti: un picco di mezz'ora deve vedersi
};

if (typeof module !== 'undefined' && module.exports) module.exports = { DM_CFG: DM_CFG };
