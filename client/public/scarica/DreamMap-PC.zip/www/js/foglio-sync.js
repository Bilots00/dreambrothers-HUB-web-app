/* ===========================================================================================
   IL FOGLIO OVUNQUE — lo stesso foglio della scheda START sul telefono, sul computer, su
   Notion e nelle note del telefono

   Il foglio è una stringa per giorno (`fl_notes_<giorno>`), riscritta intera a ogni modifica.
   Qui non si cambia la sua forma: si aggiunge, accanto a ogni giorno, l'ORA dell'ultima
   scrittura (`fl_notes_at_<giorno>`), che è l'unica cosa che serve per far vincere la versione
   più recente quando due posti hanno scritto lo stesso foglio.

   Tre canali, tre regole diverse, dette come stanno:

   · COMPUTER ↔ TELEFONO. La stessa riga dell'archivio dell'account che già porta in giro il
     tabellone (`match-score`): una riga di sistema, `fl:foglio`, che gli elenchi dei backup
     nascondono. Ogni venti secondi con l'app davanti; scrive solo se ha qualcosa di nuovo.
     Non serve nessun server nuovo e non costa niente.

   · NOTION. Ha un'API pubblica e gratuita: l'utente crea un'integrazione interna, incolla il
     token e l'indirizzo della pagina. La pagina diventa il foglio di OGGI: ogni riga è una
     casella (to_do). Le righe nuove viaggiano nei due sensi, la spunta pure, la riga tolta
     sparisce di là. Il telefono chiama Notion da solo (ponte nativo `httpJson`: il WebView
     non può, per CORS).

   · NOTE DEL TELEFONO (Samsung Notes). NON ha un'API: nessuna app può leggere o scrivere le
     note di un'altra. Quello che esiste davvero è il menu Condividi, nei due sensi: il foglio
     si manda alle Note con un tocco, e una nota condivisa verso Focus2Dream entra nel foglio
     riga per riga. È il massimo che il sistema concede, e si dice così.
   =========================================================================================== */

/* ---------------------------------------------------------------------------------------
   1 · COMPUTER ↔ TELEFONO
   --------------------------------------------------------------------------------------- */
const FS_SLOT = 'fl:foglio';
const FS_EVERY = 20000;
let FS_ROW_AT = '', FS_BUSY = false, FS_T = 0, FS_LAST = { at: 0, ok: false, why: '' }, FS_PUSH = false;

function fsCan(){ try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; } }
function fsKey(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
/* I giorni che viaggiano: ieri, oggi, domani, dopodomani. Il resto è archivio, e resta dov'è. */
function fsGiorni(){ const out = []; for (let i = -1; i <= 2; i++) out.push(fsKey(Date.now() + i * 86400000)); return out; }
function fsAt(k){ try{ return +localStorage.getItem('fl_notes_at_' + k) || 0; }catch(_){ return 0; } }
function fsTesto(k){ try{ return localStorage.getItem('fl_notes_' + k) || ''; }catch(_){ return ''; } }

/* Chiamato da stNotesSave: segna l'ora e programma la spedizione. */
function fsToccato(k){
  try{ localStorage.setItem('fl_notes_at_' + k, String(Date.now())); }catch(_){ }
  FS_PUSH = true;
  clearTimeout(FS_T); FS_T = setTimeout(function(){ fsSync(); }, 1500);
  try{ ntToccato(); }catch(_){ }
}

function fsMio(){
  const days = {};
  fsGiorni().forEach(function(k){
    const t = fsTesto(k), at = fsAt(k);
    let n = '', ap = [];
    try{ n = localStorage.getItem('fl_note_html_' + k) || ''; ap = JSON.parse(localStorage.getItem('fl_appunti_' + k) || '[]') || []; }catch(_){ }
    if (t || at || n || ap.length) days[k] = { t: t, at: at, n: n, ap: ap };
  });
  let done = [];
  try{ done = (typeof stDone === 'function') ? stDone().slice(-200) : []; }catch(_){ }
  return { kind: 'focuslock-foglio', v: 1, days: days, done: done };
}

/* Il documento del server entra qui: per ogni giorno vince chi ha scritto per ultimo. Le
   spunte si uniscono (una riga fatta di là è fatta anche di qua). Torna vero se ha cambiato
   qualcosa a schermo. */
function fsApplica(doc){
  if (!doc || !doc.days) return false;
  let cambiato = false;
  for (const k in doc.days){
    if (!Object.prototype.hasOwnProperty.call(doc.days, k)) continue;
    const r = doc.days[k] || {};
    if ((+r.at || 0) > fsAt(k) && typeof r.t === 'string'){
      try{
        localStorage.setItem('fl_notes_' + k, r.t); localStorage.setItem('fl_notes_at_' + k, String(+r.at));
        if (typeof r.n === 'string') localStorage.setItem('fl_note_html_' + k, r.n);
        if (Array.isArray(r.ap)) localStorage.setItem('fl_appunti_' + k, JSON.stringify(r.ap));
      }catch(_){ }
      cambiato = true;
    }
  }
  try{
    const mie = (typeof stDone === 'function') ? stDone() : [];
    const loro = Array.isArray(doc.done) ? doc.done : [];
    let nuove = 0;
    const oggi = (typeof stDayKey === 'function') ? stDayKey('today') : '';
    loro.forEach(function(d){
      if (!d || !d.day || !d.text) return;
      /* di oggi entra solo quello che oggi esiste: l'altro dispositivo puo' avere la stessa
         lista sporca, e non deve rispedircela dentro */
      if (d.day === oggi && !fsRigaDiOggi(d.text)) return;
      if (!mie.some(function(m){ return m.day === d.day && m.text === d.text; })){ mie.push(d); nuove++; }
    });
    if (nuove){ localStorage.setItem('fl_notes_done', JSON.stringify(mie.slice(-400))); cambiato = true; }
  }catch(_){ }
  if (cambiato){
    try{ if (typeof stListPaint === 'function') stListPaint(); if (typeof stNoteFoot === 'function') stNoteFoot(); }catch(_){ }
    try{ if (typeof stSyncToFF === 'function') stSyncToFF(); }catch(_){ }
  }
  return cambiato;
}

/** La riga sta nel foglio di oggi? Solo quelle possono diventare «fatte oggi». */
function fsRigaDiOggi(n){
  try{
    if (typeof stLines !== 'function' || typeof ntNorm !== 'function') return true;
    return stLines().some(function(r){ return ntNorm(r) === n; });
  }catch(_){ return true; }
}

/**
 * LA PULIZIA DELLE SPUNTE DI OGGI.
 *
 * <p>La versione precedente girava al caricamento di questo file, quando `stLines` non
 * esisteva ancora: `fsRigaDiOggi` rispondeva sempre «sì» e non toglieva niente — ed e' per
 * questo che le settanta spunte sono rimaste li' un altro giorno. Adesso gira a documento
 * pronto, e ogni volta che lo specchio riversa la lista dall'altro dispositivo.</p>
 *
 * <p>Con `tutto` toglie OGNI spunta di oggi: e' il fischio di inizio di oggi, una volta sola
 * (le uniche spunte di oggi erano prove fatte per vedere il difetto).</p>
 */
function fsPulisciOggi(tutto){
  try{
    const oggi = (typeof stDayKey === 'function') ? stDayKey('today') : '';
    if (!oggi) return false;
    const d = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
    const visti = {};
    const out = d.filter(function(x){
      if (!x || !x.day || !x.text) return false;
      const k = x.day + '\u0000' + x.text;
      if (visti[k]) return false;                         // doppione: mai due volte la stessa riga
      visti[k] = 1;
      if (x.day !== oggi) return true;
      if (tutto) return false;
      return fsRigaDiOggi(x.text);                        // di oggi solo quello che oggi esiste
    });
    if (out.length !== d.length){
      localStorage.setItem('fl_notes_done', JSON.stringify(out));
      try{ document.dispatchEvent(new CustomEvent('fl:spunta')); }catch(_){ }
      try{ if (typeof stListPaint === 'function') stListPaint(); }catch(_){ }
      return true;
    }
  }catch(_){ }
  return false;
}
/**
 * LA PULIZIA DI QUELLO CHE L'IMPORT HA GIA' COMBINATO (una volta sola, alla prima apertura).
 * Le spunte di oggi arrivate da Notion se ne vanno: oggi non e' stata spuntata nessuna a
 * mano. Le righe del foglio di oggi si tengono una volta ciascuna; e quelle che l'import
 * aveva riportato da ieri — cioe' righe di ieri con una spunta importata — tornano a ieri.
 */
function fsRipuliscoImportati(){
  try{
    const oggi = (typeof stDayKey === 'function') ? stDayKey('today') : fsKey(Date.now());
    const ieri = fsKey(Date.now() - 86400000);
    const done = (typeof stDone === 'function') ? stDone() : [];
    const importate = {};
    done.forEach(function(x){ if (x && x.day === oggi && x.da === 'notion') importate[ntNorm(x.text)] = 1; });
    const resto = done.filter(function(x){ return !(x && x.day === oggi && x.da === 'notion'); });
    if (resto.length !== done.length) localStorage.setItem('fl_notes_done', JSON.stringify(resto));
    const righeIeri = {};
    (typeof stRigheDi === 'function' ? stRigheDi(ieri) : []).forEach(function(r){ righeIeri[ntNorm(r)] = 1; });
    const visti = {}; const out = []; let tolte = 0;
    (typeof stRigheDi === 'function' ? stRigheDi(oggi) : []).forEach(function(r){
      const n = ntNorm(r);
      if (visti[n]){ tolte++; return; }
      visti[n] = 1;
      if (importate[n] && righeIeri[n]){ tolte++; return; }
      out.push(r);
    });
    if (tolte) localStorage.setItem('fl_notes_' + oggi, out.join('\n'));
    try{ document.dispatchEvent(new CustomEvent('fl:spunta')); }catch(_){ }
    try{ if (typeof stListPaint === 'function') stListPaint(); }catch(_){ }
  }catch(_){ }
}
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(function(){
    try{
      const K3 = 'fl_notes_done_reset_v3';
      if (!localStorage.getItem(K3)){ localStorage.setItem(K3, '1'); fsRipuliscoImportati(); }
    }catch(_){ }
    const K = 'fl_notes_done_reset_v2';
    let prima = false;
    try{ prima = !localStorage.getItem(K); if (prima) localStorage.setItem(K, '1'); }catch(_){ }
    fsPulisciOggi(prima);
  }, 300);
});

function fsUnisci(doc, mio){
  const out = (doc && doc.days) ? JSON.parse(JSON.stringify(doc)) : { kind: 'focuslock-foglio', v: 1, days: {}, done: [] };
  out.days = out.days || {}; out.done = Array.isArray(out.done) ? out.done : [];
  for (const k in mio.days){
    if (!Object.prototype.hasOwnProperty.call(mio.days, k)) continue;
    const l = out.days[k];
    if (!l || (+l.at || 0) < (+mio.days[k].at || 0)) out.days[k] = mio.days[k];
  }
  mio.done.forEach(function(d){
    if (!out.done.some(function(m){ return m.day === d.day && m.text === d.text; })) out.done.push(d);
  });
  out.done = out.done.slice(-300);
  /* i giorni vecchi non servono più a nessuno */
  const vivi = fsGiorni();
  for (const k in out.days) if (Object.prototype.hasOwnProperty.call(out.days, k) && vivi.indexOf(k) < 0) delete out.days[k];
  return out;
}

async function fsSync(){
  if (FS_BUSY || !fsCan()) return false;
  FS_BUSY = true;
  try{
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const righe = (lista && lista.backups) || [];
    const riga = righe.filter(function(x){ return x && x.deviceId === FS_SLOT; })[0] || null;
    let doc = null;
    if (riga && String(riga.updatedAt || '') !== FS_ROW_AT){
      const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
      doc = (pieno && pieno.payload) || null;
      FS_ROW_AT = String(riga.updatedAt || '');
      fsApplica(doc);
    }
    if (FS_PUSH || !riga){
      const unito = fsUnisci(doc, fsMio());
      const r = await NATIVE.accountApi({ method: 'PUT', path: '/api/focuslock/backups', body: JSON.stringify({
        deviceId: FS_SLOT, deviceName: 'Il foglio della scheda START', appVersion: 'foglio',
        summary: { programs: 0, apps: 0, sites: 0, keywords: 0 }, backup: unito }) });
      FS_ROW_AT = String((r && r.backup && r.backup.updatedAt) || '');
      FS_PUSH = false;
    }
    FS_LAST = { at: Date.now(), ok: true, why: '' };
    return true;
  }catch(e){
    FS_LAST = { at: Date.now(), ok: false, why: (e && e.message) || 'non riuscito' };
    try{ console.warn('[foglio] sync', FS_LAST.why); }catch(_){ }
    return false;
  }finally{ FS_BUSY = false; try{ fsPaintFoglio(); }catch(_){ } }
}
function fsDesktop(){ try{ return !!(window.chrome && window.chrome.webview); }catch(_){ return false; } }
function fsTick(){ if (document.visibilityState !== 'visible' && !fsDesktop()) return; fsSync(); }
setInterval(fsTick, FS_EVERY);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') fsTick(); });
setTimeout(fsTick, 5000);
async function fsAggiorna(){
  FS_ROW_AT = ''; FS_PUSH = true;
  const ok = await fsSync();
  fsPaintSettings(); fsPaintFoglio();
  if (typeof toast === 'function') toast(ok ? 'Foglio aggiornato con il computer' : 'Non riuscito: ' + FS_LAST.why);
}
/* La riga sotto al foglio: quello che non si vede non si può controllare. */
/* 0.9.217: niente piu' riga «Sincronizzato con il computer, un istante fa» sotto al foglio. Ad
   Andrea non interessa sapere quando si sincronizza, e nella scheda START (dove non si scrive)
   occupava spazio. La sincronizzazione continua uguale, in silenzio. */
function fsPaintFoglio(){
  const el = document.getElementById('stSyncTxt'); if (el) el.textContent = '';
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia'){ fsSync().then(fsPaintFoglio); ntSync(); } });
setInterval(fsPaintFoglio, 10000);
/* l'errore tecnico detto in parole (0.9.209): «Unable to resolve host…» non dice niente a nessuno */
function fsPerche(w){ w = String(w || ''); if (/resolve host|UnknownHost|Unable to resolve|timeout|timed out|connect|network/i.test(w)) return 'il telefono non raggiunge il server. Riprovo da solo appena torna la rete.'; if (/401|403|auth/i.test(w)) return 'serve di nuovo l’accesso con Google.'; return 'riprovo fra poco.'; }
function fsStato(){
  if (!fsCan()) return 'Disponibile nell’app installata, con l’account Google collegato.';
  if (!FS_LAST.at) return 'Collegamento al tuo account in corso…';
  if (!FS_LAST.ok) return 'Non sincronizzato col computer: ' + fsPerche(FS_LAST.why);
  const min = Math.round((Date.now() - FS_LAST.at) / 60000);
  return 'Sincronizzato con il computer' + (min < 1 ? ', un istante fa.' : ', ' + min + ' min fa.');
}

/* ---------------------------------------------------------------------------------------
   2 · NOTION
   --------------------------------------------------------------------------------------- */
const NT_KEY = 'fl_notion';
const NT_EVERY = 60000;
/* SPENTA (0.9.225). Questa sincronizzazione ha riempito il toggle «IMPORTANTE» della «To do list» di
   Andrea con 50.000 caselle (59 testi diversi): leggeva solo le prime 100 caselle di ogni cassetto
   (page_size=100, nessuna pagina dopo), e oltre le 100 le righe di oggi sembravano mancare e venivano
   riaggiunte a ogni giro, ogni minuto, dal telefono e dal computer. Adesso legge tutte le pagine;
   ma resta spenta finche' Andrea non la riaccende sapendolo: il piano di DreamMap ha preso il posto
   della pagina di Notion. */
const NT_SPENTA = true;
const NT_MAX_PAGINE = 20;
let NT_BUSY = false, NT_T = 0, NT_LAST = { at: 0, ok: false, why: '' };

function ntCfg(){ try{ return Object.assign({ on: false, token: '', page: '', map: {} }, JSON.parse(localStorage.getItem(NT_KEY) || '{}') || {}); }catch(_){ return { on: false, token: '', page: '', map: {} }; } }
function ntSave(p){ const c = Object.assign(ntCfg(), p || {}); try{ localStorage.setItem(NT_KEY, JSON.stringify(c)); }catch(_){ } return c; }
function ntCan(){ try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.httpJson); }catch(_){ return false; } }
/* L'id della pagina sta in fondo all'indirizzo: 32 caratteri esadecimali, con o senza trattini. */
function ntPageId(u){
  const m = String(u || '').replace(/-/g, '').match(/([0-9a-f]{32})(?:[^0-9a-f]|$)/i);
  return m ? m[1] : '';
}
async function ntCall(method, path, body){
  const c = ntCfg();
  const r = await NATIVE.httpJson({ method: method, url: 'https://api.notion.com/v1' + path, body: body ? JSON.stringify(body) : '',
    headers: { 'Authorization': 'Bearer ' + c.token, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' } });
  let j = null; try{ j = JSON.parse(r && r.body || 'null'); }catch(_){ }
  if (!r || r.status >= 400) throw new Error((j && j.message) || ('Notion ha risposto ' + (r ? r.status : '?')));
  return j;
}
function ntToccato(){ if (NT_SPENTA || !ntCfg().on) return; clearTimeout(NT_T); NT_T = setTimeout(function(){ ntSync(); }, 2500); }
function ntNorm(t){ return String(t || '').trim().toLowerCase(); }

/* ---------- LE SEZIONI DELLA SUA PAGINA ----------
   La pagina «To do list» di Andrea ha cinque cassetti (toggle), gli stessi del foglio: la
   priorita' assoluta, l'importante, le scadenze, il non urgente, le completate. Si
   riconoscono dal titolo. Se la pagina li ha, ogni riga va nel cassetto che le spetta — e se
   una riga viene spostata di la', si sposta anche di qua. Se la pagina non ha cassetti, il
   foglio resta piatto, com'era. */
const NT_SEZ = [
  ['one',   /PRIORIT/i],
  ['imp',   /^\s*IMPORTANTE/i],
  ['scad',  /SCADENZ|APPUNTAMENT/i],
  ['idee',  /NON URGENTE|IDEAS/i],
  ['fatte', /COMPLETAT|FATT|SMALL WINS/i]
];
function ntTesto(b){
  const rt = (b && b.type && b[b.type] && b[b.type].rich_text) || [];
  return rt.map(function(x){ return x.plain_text || ''; }).join('').trim();
}
async function ntFigli(id){
  /* TUTTE le pagine di figli, non solo le prime 100 (era la causa dei doppioni). Oltre il tetto si
     ferma con un errore: meglio non scrivere niente che scrivere di nuovo righe gia' presenti. */
  let out = [], cur = '', n = 0;
  do {
    const j = await ntCall('GET', '/blocks/' + id + '/children?page_size=100' + (cur ? '&start_cursor=' + encodeURIComponent(cur) : ''));
    out = out.concat((j && j.results) || []);
    cur = (j && j.has_more && j.next_cursor) || '';
    n++;
  } while (cur && n < NT_MAX_PAGINE);
  if (cur) throw new Error('la pagina di Notion ha troppe caselle in un cassetto (oltre ' + (NT_MAX_PAGINE * 100) + '): sincronizzazione fermata');
  return out;
}
function ntEUnCassetto(b){
  if (!b || !b.type) return false;
  if (b.type === 'toggle') return true;
  return /^heading_/.test(b.type) && !!(b[b.type] && b[b.type].is_toggleable);
}
async function ntCassetti(pid){
  const out = {};
  const guarda = function(b){
    if (!ntEUnCassetto(b)) return;
    const t = ntTesto(b);
    NT_SEZ.forEach(function(sz){ if (!out[sz[0]] && sz[1].test(t)) out[sz[0]] = b.id; });
  };
  const liv1 = await ntFigli(pid);
  const contenitori = [];
  liv1.forEach(function(b){
    if (ntEUnCassetto(b)) guarda(b);
    else if (b.has_children && /^(column_list|column|callout|synced_block)$/.test(b.type)) contenitori.push(b.id);
  });
  for (let i = 0; i < contenitori.length && i < 6; i++){
    const f = await ntFigli(contenitori[i]);
    for (let k = 0; k < f.length; k++){
      const b = f[k];
      if (b.type === 'column' && b.has_children){ (await ntFigli(b.id)).forEach(guarda); }
      else guarda(b);
    }
  }
  return out;
}

/* Una passata: la pagina è il foglio di oggi. */
async function ntSync(){
  const c = ntCfg();
  if (NT_SPENTA){ NT_LAST = { at: Date.now(), ok: false, why: 'spenta' }; return false; }
  if (NT_BUSY || !c.on || !c.token || !ntCan()) return false;
  const pid = ntPageId(c.page);
  if (!pid){ NT_LAST = { at: Date.now(), ok: false, why: 'indirizzo della pagina non valido' }; return false; }
  NT_BUSY = true;
  try{
    const oggi = fsKey(Date.now());
    const cassetti = await ntCassetti(pid);
    const ok = (Object.keys(cassetti).length >= 3)
      ? await ntSyncSezioni(c, pid, oggi, cassetti)
      : await ntSyncPiatta(c, pid, oggi);
    NT_LAST = { at: Date.now(), ok: true, why: '' };
    return ok;
  }catch(e){
    NT_LAST = { at: Date.now(), ok: false, why: (e && e.message) || 'non riuscito' };
    return false;
  }finally{ NT_BUSY = false; fsPaintSettings(); }
}

/* Con i cassetti: ogni riga sotto al suo. */
async function ntSyncSezioni(c, pid, oggi, cassetti){
  const righe = (typeof stRigheDi === 'function') ? stRigheDi(oggi) : ((typeof stLines === 'function') ? stLines('today') : []);
  const fatte = (typeof stDone === 'function') ? stDone() : [];
  const map = (c.mapDay === oggi) ? (c.map || {}) : {};
  /* LE DICIASSETTE SPUNTE DELL'UNA DI NOTTE. La pagina di Notion e' una sola per tutti i
     giorni. A mezzanotte «oggi» cambia, la mappa delle righe riparte vuota, e le caselle di
     ieri — ancora spuntate — non stanno nel foglio nuovo: venivano lette come righe NUOVE,
     messe nel foglio di oggi e, siccome spuntate, segnate fatte oggi. Tutte, con l'ora del
     sync. Da qui: la mappa di ieri si tiene per riconoscere le righe nostre, e una casella
     gia' spuntata non e' mai un compito nuovo. */
  const mapVecchia = c.map || {};
  const nuovoGiorno = c.mapDay !== oggi;
  /* UNA CASELLA SPUNTATA IERI NON E' UNA COSA FATTA OGGI. Notion dice quando ogni blocco e'
     stato toccato l'ultima volta: una spunta piu' vecchia della mezzanotte di oggi e' rimasta
     li' da un altro giorno, e va rimessa a posto, non importata. */
  const oggiMs = new Date(oggi + 'T00:00:00').getTime();
  const spuntaVecchia = function(b){ return nuovoGiorno || !(b.edited >= oggiMs); };
  let cambiato = false;

  /* 1 · cosa c'e' di la', cassetto per cassetto */
  const remoti = [];
  for (const sez in cassetti){
    if (!Object.prototype.hasOwnProperty.call(cassetti, sez)) continue;
    const f = await ntFigli(cassetti[sez]);
    f.forEach(function(b){
      if (b.type !== 'to_do') return;
      const t = ntTesto(b); if (!t) return;
      remoti.push({ id: b.id, t: t, n: ntNorm(t), checked: !!(b.to_do && b.to_do.checked), sez: sez,
                    edited: Date.parse(b.last_edited_time || '') || 0 });
    });
  }

  /* 2 · di la' e non di qua: le mie (tolte qui) spariscono di la'; le altre entrano nel foglio */
  const nuoveQui = [];
  for (const b of remoti){
    if (righe.some(function(r){ return ntNorm(r) === b.n; })) continue;
    const mia = Object.keys(mapVecchia).some(function(k){ return mapVecchia[k] && mapVecchia[k].id === b.id; });
    if (mia){ try{ await ntCall('DELETE', '/blocks/' + b.id); }catch(_){ } delete map[b.n]; continue; }
    /* spuntata, o nel cassetto delle fatte: e' un lavoro finito, non un compito da importare */
    if (b.checked || b.sez === 'fatte') continue;
    /* LA STESSA RIGA SEI VOLTE. La pagina teneva lo stesso blocco piu' volte (spedito una
       volta al giorno senza che quello vecchio venisse tolto) e ogni copia entrava nel foglio:
       diciassette compiti diventavano centotredici righe «completate». Una volta basta. */
    if (nuoveQui.some(function(x){ return x.n === b.n; })) continue;
    nuoveQui.push(b);
  }
  if (nuoveQui.length){
    nuoveQui.forEach(function(b){
      righe.push(b.t);
      map[b.n] = { id: b.id, sez: b.sez };
      if (b.sez === 'fatte' || b.checked){
        if (!fatte.some(function(d){ return d.day === oggi && d.text === b.n; })) fatte.push({ day: oggi, text: b.n, at: Date.now(), verified: false, da: 'notion' });
      } else if (b.sez !== 'imp' && typeof stMetaSave === 'function'){
        stMetaSave(b.t, oggi, { sez: b.sez });
      }
    });
    try{ localStorage.setItem('fl_notes_' + oggi, righe.join('\n')); localStorage.setItem('fl_notes_at_' + oggi, String(Date.now())); }catch(_){ }
    FS_PUSH = true; cambiato = true;
  }

  /* 3 · di qua: ognuna sotto al cassetto che le spetta */
  for (const r of righe){
    const n = ntNorm(r);
    const sez = (typeof stSezione === 'function') ? stSezione(r, oggi, righe) : 'imp';
    const parent = cassetti[sez] || cassetti.imp || cassetti.idee;
    if (!parent) continue;
    const fattaQui = sez === 'fatte';
    const rem = remoti.filter(function(b){ return b.n === n; })[0];

    if (rem && rem.sez !== sez){
      /* spostata a mano di la'? allora si sposta anche qui, e basta */
      const prima = map[n] && map[n].sez;
      if (prima && prima !== rem.sez){
        if (rem.sez === 'fatte'){
          if (!fattaQui){ fatte.push({ day: oggi, text: n, at: Date.now(), verified: false, da: 'notion' }); cambiato = true; }
        } else if (typeof stMetaSave === 'function') stMetaSave(r, oggi, { sez: rem.sez });
        map[n] = { id: rem.id, sez: rem.sez };
        continue;
      }
    }
    if (rem && rem.sez === sez){
      map[n] = { id: rem.id, sez: sez };
      if (fattaQui && !rem.checked){ try{ await ntCall('PATCH', '/blocks/' + rem.id, { to_do: { checked: true } }); }catch(_){ } }
      else if (!fattaQui && rem.checked){
        /* SOLO SE E' UNA RIGA DI OGGI. La pagina di Notion tiene le caselle spuntate dei giorni
           passati; contarle tutte come «fatte oggi» dava ottantadue spunte per una vera. */
        /* E MAI AL PRIMO GIRO DI UN GIORNO NUOVO: la casella e' rimasta spuntata da ieri.
           Il foglio di oggi comanda, e la casella si rimette a posto di la'. */
        if (spuntaVecchia(rem)){ try{ await ntCall('PATCH', '/blocks/' + rem.id, { to_do: { checked: false } }); }catch(_){ } }
        else if (fsRigaDiOggi(n) && !fatte.some(function(d){ return d.day === oggi && d.text === n; })){ fatte.push({ day: oggi, text: n, at: Date.now(), verified: false, da: 'notion' }); cambiato = true; }
      }
      continue;
    }
    /* non c'e', o sta nel cassetto sbagliato per una scelta fatta qui: si rimette al suo posto */
    if (rem){ try{ await ntCall('DELETE', '/blocks/' + rem.id); }catch(_){ } }
    try{
      const res = await ntCall('PATCH', '/blocks/' + parent + '/children', { children: [
        { object: 'block', type: 'to_do', to_do: { rich_text: [{ type: 'text', text: { content: r.slice(0, 1900) } }], checked: fattaQui } }
      ] });
      const b = res && res.results && res.results[0];
      if (b && b.id) map[n] = { id: b.id, sez: sez };
    }catch(_){ }
  }

  if (cambiato){
    try{ localStorage.setItem('fl_notes_done', JSON.stringify(fatte.slice(-400))); }catch(_){ }
    try{ if (typeof stListPaint === 'function') stListPaint(); if (typeof stNoteFoot === 'function') stNoteFoot(); if (typeof stfPaint === 'function' && document.getElementById('stfBody')) stfPaint(); }catch(_){ }
  }
  ntSave({ map: map, mapDay: oggi, sezioni: true });
  return true;
}

/* Senza cassetti: la pagina e' il foglio, piatto. */
async function ntSyncPiatta(c, pid, oggi){
  const j = await ntCall('GET', '/blocks/' + pid + '/children?page_size=100');
  const blocchi = ((j && j.results) || []).filter(function(b){ return b && b.type === 'to_do'; }).map(function(b){
    return { id: b.id, t: ntTesto(b), checked: !!(b.to_do && b.to_do.checked), edited: Date.parse(b.last_edited_time || '') || 0 };
  }).filter(function(b){ return b.t; });
  const righe = (typeof stLines === 'function') ? stLines('today') : [];
  const fatte = (typeof stDone === 'function') ? stDone() : [];
  const map = (c.mapDay === oggi) ? (c.map || {}) : {};
  /* LE DICIASSETTE SPUNTE DELL'UNA DI NOTTE. La pagina di Notion e' una sola per tutti i
     giorni. A mezzanotte «oggi» cambia, la mappa delle righe riparte vuota, e le caselle di
     ieri — ancora spuntate — non stanno nel foglio nuovo: venivano lette come righe NUOVE,
     messe nel foglio di oggi e, siccome spuntate, segnate fatte oggi. Tutte, con l'ora del
     sync. Da qui: la mappa di ieri si tiene per riconoscere le righe nostre, e una casella
     gia' spuntata non e' mai un compito nuovo. */
  const mapVecchia = c.map || {};
  const nuovoGiorno = c.mapDay !== oggi;
  /* UNA CASELLA SPUNTATA IERI NON E' UNA COSA FATTA OGGI. Notion dice quando ogni blocco e'
     stato toccato l'ultima volta: una spunta piu' vecchia della mezzanotte di oggi e' rimasta
     li' da un altro giorno, e va rimessa a posto, non importata. */
  const oggiMs = new Date(oggi + 'T00:00:00').getTime();
  const spuntaVecchia = function(b){ return nuovoGiorno || !(b.edited >= oggiMs); };
  let cambiato = false;
  const nuoveQui = [];
  for (const b of blocchi){
    const n = ntNorm(b.t);
    if (righe.some(function(r){ return ntNorm(r) === n; })) continue;
    const eraMia = Object.keys(mapVecchia).some(function(k){ return mapVecchia[k] && (mapVecchia[k].id || mapVecchia[k]) === b.id; });
    if (eraMia){ try{ await ntCall('DELETE', '/blocks/' + b.id); }catch(_){ } delete map[n]; continue; }
    if (b.checked) continue;   // finita, non nuova
    if (nuoveQui.some(function(x){ return ntNorm(x) === n; })) continue;   // la stessa riga una volta sola
    nuoveQui.push(b.t);
  }
  if (nuoveQui.length){
    try{ localStorage.setItem('fl_notes_' + oggi, righe.concat(nuoveQui).join('\n')); localStorage.setItem('fl_notes_at_' + oggi, String(Date.now())); }catch(_){ }
    FS_PUSH = true; cambiato = true;
  }
  const daMandare = righe.filter(function(r){ const n = ntNorm(r); return !blocchi.some(function(b){ return ntNorm(b.t) === n; }); });
  if (daMandare.length){
    const res = await ntCall('PATCH', '/blocks/' + pid + '/children', { children: daMandare.map(function(t){
      return { object: 'block', type: 'to_do', to_do: { rich_text: [{ type: 'text', text: { content: t.slice(0, 1900) } }], checked: fatte.some(function(d){ return d.day === oggi && d.text === ntNorm(t); }) } };
    }) });
    ((res && res.results) || []).forEach(function(b, i){ if (b && b.id && daMandare[i]) map[ntNorm(daMandare[i])] = { id: b.id }; });
  }
  for (const b of blocchi){
    const n = ntNorm(b.t);
    if (!map[n]) map[n] = { id: b.id };
    const fattaQui = fatte.some(function(d){ return d.day === oggi && d.text === n; });
    if (b.checked && !fattaQui && spuntaVecchia(b)){
      try{ await ntCall('PATCH', '/blocks/' + b.id, { to_do: { checked: false } }); }catch(_){ }
    } else if (b.checked && !fattaQui && fsRigaDiOggi(n)){
      fatte.push({ day: oggi, text: n, at: Date.now(), verified: false, da: 'notion' });
      try{ localStorage.setItem('fl_notes_done', JSON.stringify(fatte.slice(-400))); }catch(_){ }
      cambiato = true;
    } else if (!b.checked && fattaQui){
      try{ await ntCall('PATCH', '/blocks/' + b.id, { to_do: { checked: true } }); }catch(_){ }
    }
  }
  ntSave({ map: map, mapDay: oggi, sezioni: false });
  if (cambiato){ try{ if (typeof stListPaint === 'function') stListPaint(); if (typeof stNoteFoot === 'function') stNoteFoot(); }catch(_){ } }
  return true;
}
setInterval(function(){ if (document.visibilityState === 'visible' || fsDesktop()) ntSync(); }, NT_EVERY);
setTimeout(ntSync, 8000);
/* Rinominata: `ntStato` esiste anche in notifiche.js (asincrona, per le notifiche) e vinceva
   l'ultima caricata — la riga dello stato di Notion e quella delle notifiche si rompevano a
   turno con «ntStato(...).then is not a function». */
function ntStatoTesto(){
  const c = ntCfg();
  if (NT_SPENTA) return 'In pausa: creava caselle doppie nella pagina di Notion. Il tuo piano adesso vive in DreamMap.';
  if (!c.on) return 'Spenta.';
  if (!ntCan()) return 'Disponibile nell’app installata sul telefono.';
  if (!c.token || !ntPageId(c.page)) return 'Manca il token o l’indirizzo della pagina.';
  if (!NT_LAST.at) return 'Primo collegamento in corso…';
  if (!NT_LAST.ok) return 'Non sincronizzato col computer: ' + fsPerche(NT_LAST.why);
  const min = Math.round((Date.now() - NT_LAST.at) / 60000);
  return (c.sezioni ? 'Ogni riga sta nel suo cassetto della pagina' : 'La pagina è il foglio di oggi') + (min < 1 ? ', aggiornata un istante fa.' : ', aggiornata ' + min + ' min fa.');
}

/* ---------------------------------------------------------------------------------------
   3 · LE NOTE DEL TELEFONO — il menu Condividi, nei due sensi
   --------------------------------------------------------------------------------------- */
function noteCfg(){ try{ return localStorage.getItem('fl_note_share') === '1'; }catch(_){ return false; } }
function noteSet(on){ try{ localStorage.setItem('fl_note_share', on ? '1' : '0'); }catch(_){ } }
/* Il foglio del giorno scelto va alle Note (o a qualunque app che accetta testo). */
async function noteManda(){
  const righe = (typeof stLines === 'function') ? stLines() : [];
  if (!righe.length){ toast('Il foglio è vuoto'); return; }
  const giorno = (typeof STN !== 'undefined' && STN.day === 'tomorrow') ? 'Domani' : 'Oggi';
  const testo = 'DreamMap · ' + giorno + '\n' + righe.map(function(r){ return '☐ ' + r; }).join('\n');
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'Il foglio' }); return; }
    if (navigator.share){ await navigator.share({ text: testo }); return; }
    await navigator.clipboard.writeText(testo); toast('Copiato: incollalo nelle Note');
  }catch(_){ }
}
/* Una nota condivisa verso Focus2Dream: ogni riga diventa una riga del foglio di oggi. */
async function noteRicevi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.consumeSharedText) return;
    const r = await NATIVE.consumeSharedText();
    const t = (r && r.text) || '';
    if (!t.trim()) return;
    const righe = t.split('\n').map(function(x){ return x.replace(/^[\s☐☑☒•\-\*\[\]x ]+/i, '').trim(); }).filter(function(x){ return x && !/^(focus2dream|dreammap)/i.test(x); });
    if (!righe.length) return;
    const oggi = fsKey(Date.now());
    const cur = (typeof stLines === 'function') ? stLines('today') : [];
    let n = 0;
    righe.forEach(function(x){ if (cur.indexOf(x) < 0){ cur.push(x); n++; } });
    if (!n){ toast('Righe già nel foglio'); return; }
    try{ localStorage.setItem('fl_notes_' + oggi, cur.join('\n')); }catch(_){ }
    fsToccato(oggi);
    try{ if (typeof stListPaint === 'function') stListPaint(); if (typeof stNoteFoot === 'function') stNoteFoot(); }catch(_){ }
    toast(n === 1 ? 'Una riga aggiunta al foglio di oggi' : n + ' righe aggiunte al foglio di oggi');
    try{ if (typeof switchTab === 'function') switchTab('sveglia'); }catch(_){ }
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) noteRicevi(); });
setTimeout(noteRicevi, 1800);

/* ---------------------------------------------------------------------------------------
   Le impostazioni: Personalizza → Il foglio della scheda START → Il foglio ovunque
   --------------------------------------------------------------------------------------- */
/* I passi delle istruzioni: numero in un cerchietto, una riga per passo, niente frecce.
   Una riga con dentro tre frecce e' un diagramma di flusso scritto in prosa: si legge due
   volte e si capisce alla terza. */
(function fsStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.fs-titolo{margin:16px 0 8px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--faint)}',
    '.fs-steps{margin:8px 0 0;padding:0;list-style:none;counter-reset:fs}',
    '.fs-steps li{position:relative;counter-increment:fs;padding:0 0 12px 34px;',
      'font:500 13px/1.6 var(--font-body);color:var(--muted)}',
    '.fs-steps li::before{content:counter(fs);position:absolute;left:0;top:0;width:22px;height:22px;',
      'border-radius:50%;background:var(--blue,#0075E3);color:#fff;font:800 12px var(--font-body);',
      'display:flex;align-items:center;justify-content:center}',
    '.fs-steps li b{color:var(--navy);font-weight:800}',
    'body.dark .fs-steps li b{color:#fff}'
  ].join('');
  document.head.appendChild(st);
})();

function fsModalita(){ try{ return localStorage.getItem('fl_modalita') || 'normale'; }catch(_){ return 'normale'; } }
async function fsSetModalita(m){
  try{ if (typeof mgLocked === 'function' && await mgLocked()){ toast('Modalità severa accesa: la modalità della partita non si tocca'); return; } }catch(_){ }
  try{ localStorage.setItem('fl_modalita', m); }catch(_){ }
  fsPaintSettings();
}
function fsPaintModalita(){
  const host = document.getElementById('psModalita'); if (!host) return;
  const cur = fsModalita();
  host.innerHTML = [['facile', 'Facile \u00b7 1 passo'], ['normale', 'Normale \u00b7 3 passi'], ['difficile', 'Difficile \u00b7 5 passi']].map(function(m){
    return '<button type="button" class="' + (m[0] === cur ? 'on' : '') + '" onclick="fsSetModalita(\'' + m[0] + '\')">' + m[1] + '</button>';
  }).join('');
  const t = document.getElementById('psModalitaTxt');
  if (t) t.textContent = { facile: 'Un passo sulla rotta al giorno: per chi ha tempo davanti.', normale: 'Tre passi al giorno: il ritmo di chi vuole arrivare.', difficile: 'Cinque passi al giorno: per chi ha una data vicina e vuole dominare la partita.' }[cur] || '';
}
function fsPaintSettings(){
  fsPaintModalita();
  const pc = document.getElementById('psFoglioPc'); if (pc) pc.textContent = fsStato();
  const c = ntCfg();
  const b = document.getElementById('psNotion'); if (b) b.classList.toggle('on', !!c.on);
  const box = document.getElementById('psNotionBox'); if (box) box.hidden = !c.on;
  const tok = document.getElementById('psNotionTok'); if (tok && document.activeElement !== tok) tok.value = c.token || '';
  const pg = document.getElementById('psNotionPage'); if (pg && document.activeElement !== pg) pg.value = c.page || '';
  const st = document.getElementById('psNotionTxt'); if (st) st.textContent = ntStatoTesto();
  const n = document.getElementById('psNote'); if (n) n.classList.toggle('on', noteCfg());
  try{ const t = document.getElementById('psNoteTutte'); if (t && typeof mnMostraTutte === 'function') t.classList.toggle('on', mnMostraTutte()); }catch(_){ }
  const nb = document.getElementById('psNoteBox'); if (nb) nb.hidden = !noteCfg();
}
function settingsToggleNotion(){
  const c = ntCfg();
  ntSave({ on: !c.on });
  fsPaintSettings();
  if (!c.on) setTimeout(ntSync, 300);
}
function notionSalva(){
  const tok = document.getElementById('psNotionTok'), pg = document.getElementById('psNotionPage');
  ntSave({ token: tok ? tok.value.trim() : '', page: pg ? pg.value.trim() : '', map: {} });
  NT_LAST = { at: 0, ok: false, why: '' };
  fsPaintSettings();
  ntSync().then(function(ok){ toast(ok ? 'Notion collegato: la pagina è il foglio di oggi' : 'Notion: ' + NT_LAST.why); });
}
function settingsToggleNote(){ noteSet(!noteCfg()); fsPaintSettings(); }
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-settings') setTimeout(fsPaintSettings, 50); });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(fsPaintSettings, 800); });
