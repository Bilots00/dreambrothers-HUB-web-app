/* =========================================================================================
   L'INTERVISTA PER IL PIANO SU MISURA (0.9.280)

   Andrea, 17/10: "mi ha fatto una domanda in croce e mi ha dato una roadmap a caso, da network
   marketing, con stime da 6.000 minuti. Io devo solo rispondere a delle domande e ricevere un piano
   su misura: un questionario, non una chat da cui posso deviare. Con il Genio sullo sfondo della
   foresta e il riquadro per rispondere, senza le pill. Le domande non scriptate: le fa il Genio con
   l'AI, dinamiche, per costruire una roadmap precisa. Finite le domande, si va nella chat con il piano".

   Come funziona: una conversazione nuova dell'agente ("Il tuo piano su misura"), con i messaggi che
   cominciano per [intervista]. Il server li manda al modello del piano (Opus) con le regole
   dell'intervista: da 5 a 7 domande, una per volta, scelte sulle risposte, mai il piano prima. Ogni
   domanda torna con {"intervista": {n, di, esempi}}; l'ultima risposta torna con il blocco del piano.
   Qui si mostra la domanda sulla scena del Genio; quando arriva il piano si apre la chat su quella
   conversazione, dove c'e' "Applica la roadmap".
   ========================================================================================= */
const IV_PREF = '[intervista] ';
const IV = { sid: '', inviato: 0, poll: 0, da: 0, ultima: null, esempi: [] };

function ivPuo(){
  try{ return typeof agStato === 'function' && agStato().impostato && typeof agPuo === 'function' && agPuo(); }catch(_){ return false; }
}
/* 0.9.282, Andrea: "Preparo le domande" ci metteva troppo, e sulla scena del Genio sembrava il Genio scriptato. Il piano
   su misura e' una fase cruciale: si fa nella chat con il tuo agente personale, cosi' si capisce che e' un'intelligenza artificiale.
   La conversazione e' segnata come intervista: ogni risposta parte con [intervista] finche' non arriva il piano. */
async function ivApri(){
  const sogno = (typeof nvSogno === 'function' && nvSogno()) || 'il mio sogno';
  if (!ivPuo()){ if (typeof agNuovaConversazione === 'function') agNuovaConversazione('Costruisci la mia roadmap su misura. Prima fammi le tue domande, una alla volta.'); return; }
  if (typeof agAbilitato === 'function' && !(await agAbilitato())){ if (typeof guidaApri === 'function') guidaApri(); return; }
  /* 0.9.289, Andrea: prima la scelta "importa la memoria da un'altra AI" o "rispondo alle domande" (memoria-ai.js), poi la
     chat con il messaggio GIA' SCRITTO nella casella: parte solo quando lo manda lui. */
  if (typeof imemApri === 'function'){ imemApri(function(m){ ivApriChat(sogno, m || {}); }); return; }
  ivApriChat(sogno, {});
}
function ivMessaggio(sogno, m){
  const righe = ['Costruisci la mia roadmap su misura verso "' + sogno + '".'];
  if (typeof mdPerAgente === 'function') righe.push(mdPerAgente() + ' Il numero di passi al giorno deve rispettare questa strada.');
  /* 0.9.293, Andrea: "se ha scelto realizzare il mio progetto, il Genio deve scavare: di che progetto si tratta, cosa
     intendi davvero". Se il sogno e' ancora l'etichetta generica di una carta, la prima domanda e' quella. */
  if (/^(realizzare il mio progetto|vivere della mia passione|creare il mio progetto|eccellere nello studio)/i.test(String(sogno).replace(/^[^\p{L}]+/u, '').trim()))
    righe.push('Il mio sogno l\u2019ho scelto da una lista ed è ancora generico: la prima domanda è di cosa si tratta davvero e che cosa intendo, poi il resto.');
  /* 0.9.305: la data del sogno e gli orizzonti che ci stanno dentro, cosi' il piano non ha "fra cinque anni" per un sogno
     a sei mesi (ozSognoFine, ozVisibili in orizzonti.js) */
  try{
    if (typeof ozSognoFine === 'function' && typeof ozVisibili === 'function'){
      const nomi = { cinque: 'fra cinque anni', anno: 'quest’anno', mese: 'questo mese', settimana: 'questa settimana', oggi: 'oggi' };
      const l = ozVisibili().map(function(k){ return nomi[k]; });
      const dur = (typeof sdDurata === 'function' && typeof sdDurataTxt === 'function') ? ' (' + sdDurataTxt(sdDurata().mesi) + ')' : '';
      righe.push('Voglio arrivarci entro ' + ozIlData(ozSognoFine()) + dur + '. Nel piano metti solo gli orizzonti che finiscono prima di quella data: '
        + (l.length > 1 ? l.slice(0, -1).join(', ') + ' e ' + l[l.length - 1] : l[0]) + '.');
    }
  }catch(_){ }
  if (m && m.importata) righe.push('Ho importato la mia memoria da ' + (m.da || 'un’altra AI') + ': la trovi fra i miei documenti. Usala, e chiedimi solo quello che non c’è.');
  righe.push('Fammi le domande che ti servono davvero, una alla volta. Quando sai abbastanza, proponimi il piano partendo dal collo di bottiglia vero, con passi che stanno nelle mie ore.');
  return righe.join('\n');
}
function ivApriChat(sogno, m){
  goId('s-agente');
  const sid = agSessNuova('Il tuo piano su misura');
  const st = agStato(); const x = st.sess.filter(function(q){ return q.id === sid; })[0]; if (x){ x.intervista = true; agSalva(); }
  AG.vista = 'chat'; try{ agTitoloPaint(); agPaint(); }catch(_){ }
  IV.sid = sid;
  /* il messaggio e' scritto nella casella, non inviato: lo manda lui (con il prefisso [intervista], agente.js) */
  try{ agBozza(ivMessaggio(sogno, m), 'agTesto'); }catch(_){ }
  try{ agPollAvvia(true); }catch(_){ }
}
/** La conversazione aperta e' un'intervista ancora senza piano? Allora la risposta parte con [intervista]. */
function ivInCorso(){
  try{
    const s = agStato(); const x = s.sess.filter(function(q){ return q.id === s.corrente; })[0];
    if (!x || !x.intervista) return false;
    return !agSessMsgs(x.id).some(function(m){ return m.direzione === 'out' && m.azioni && m.azioni.piano; });
  }catch(_){ return false; }
}
function ivBarra(n, di){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(Math.max(0.04, Math.min(1, (n || 0) / (di || 6))) * 100) + '%';
  if (txt) txt.textContent = 'Il tuo piano su misura';
}
async function ivManda(testo){
  IV.attesa = true; GN.step = ''; gnVai('iv');
  const prima = agSessMsgs(IV.sid).length;
  await agInvia(IV_PREF + testo, IV.sid);
  const l = agSessMsgs(IV.sid);
  if (l.length <= prima){ IV.attesa = false; IV.errore = true; GN.step = ''; gnVai('iv'); return; }
  const mio = l.filter(function(m){ return m.direzione === 'in'; }).pop();
  IV.inviato = (mio && mio.id) || 0; IV.da = Date.now();
  ivAttendi();
}
function ivAttendi(){
  clearTimeout(IV.poll);
  const giro = async function(){
    if (GN.modo !== 'iv' && !IV.fuori) return;
    try{ await agSync(true); }catch(_){ }
    const r = agSessMsgs(IV.sid).filter(function(m){ return m.direzione === 'out' && m.id > IV.inviato; }).pop();
    /* 0.9.351: chi e' uscito ad aspettare fuori trova la pillola "pronto" e rientra toccandola */
    if (r && IV.fuori){ IV.attesa = false; IV.ultima = r; if (typeof flAttesaFine === 'function') flAttesaFine('iv', (r.azioni && r.azioni.piano) ? 'La tua roadmap è pronta' : 'La prossima domanda è pronta', ivRientra); return; }
    if (r){ IV.attesa = false; IV.ultima = r; ivRisposta(r); return; }
    if (Date.now() - IV.da > 4 * 60000){ IV.attesa = false; IV.errore = true; if (IV.fuori){ if (typeof flAttesaFine === 'function') flAttesaFine('iv', 'Il tuo agente non ha risposto: tocca per riprovare', ivRientra); return; } GN.step = ''; gnVai('iv'); return; }
    IV.poll = setTimeout(giro, 3000);
  };
  IV.poll = setTimeout(giro, 2500);
}
function ivRisposta(m){
  const az = m.azioni || {};
  if (az.piano){ ivFine(); return; }
  const q = az.intervista || {};
  IV.esempi = Array.isArray(q.esempi) ? q.esempi.slice(0, 4) : [];
  IV.n = +q.n || ((IV.n || 0) + 1); IV.di = +q.di || Math.max(IV.n, 6);
  ivBarra(IV.n, IV.di);
  GN.step = ''; gnVai('iv');
}
/* la domanda: il markdown dell'agente diventa quello della scena (*evidenziato*) */
function ivTesto(t){
  return String(t || '').replace(/^#+\s*/gm, '').replace(/\*\*(.+?)\*\*/g, '*$1*').replace(/\n{2,}/g, '\n').trim();
}
function ivEntra(){
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte'); sc.classList.remove('apertura', 'volo', 'carte'); }
  if (IV.errore){
    IV.errore = false;
    gnDomanda('triste', 'Il tuo agente personale non mi ha risposto. *Riproviamo?*',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();ivRiprova()">Riprova</button><button type="button" class="gn-link" onclick="event.stopPropagation();ivChiudi()">Più tardi</button></div>');
    return;
  }
  if (IV.attesa || !IV.ultima){
    gnPosa('pensa');
    gnScrivi(IV.ultima ? 'Ci penso un attimo…' : 'Preparo le domande per te…', null);
    /* 0.9.351, Andrea: "durante un'attesa la schermata si chiude e resta il cartello con la percentuale e il tempo che manca" */
    const r = document.getElementById('gnRisp'); if (r) r.innerHTML = '<div class="iv-attesa"><i></i><i></i><i></i></div><button type="button" class="gn-link iv-fuori" onclick="event.stopPropagation();ivFuori()">Aspetta fuori, ti avviso io</button>';
    return;
  }
  const chips = IV.esempi.length ? '<div class="iv-esempi">' + IV.esempi.map(function(e, i){ return '<button type="button" onclick="event.stopPropagation();ivEsempio(' + i + ')">' + gnEsc(e) + '</button>'; }).join('') + '</div>' : '';
  gnDomanda('pensa', ivTesto(IV.ultima.testo),
    '<div class="iv-box"><small class="iv-n">Domanda ' + IV.n + ' di ' + IV.di + '</small>' + chips
    + '<textarea class="gn-area" id="ivTesto" rows="3" placeholder="Scrivi la tua risposta, anche lunga…" onclick="event.stopPropagation()" oninput="ivCampo(this)"></textarea>'
    + '<div class="or-grid one"><button type="button" class="or-a main" id="ivVia" disabled onclick="event.stopPropagation();ivRispondi()">Rispondi</button></div></div>');
}
function ivCampo(t){ const b = document.getElementById('ivVia'); if (b) b.disabled = !String(t.value || '').trim(); }
function ivEsempio(i){ const t = document.getElementById('ivTesto'); if (!t) return; t.value = IV.esempi[i] || ''; ivCampo(t); t.focus(); }
function ivRispondi(){
  const t = document.getElementById('ivTesto'); const v = t ? t.value.trim() : '';
  if (!v) return;
  try{ gnAu.scelta(1); flVibra(12); }catch(_){ }
  ivManda(v);
}
function ivFuori(){
  IV.fuori = true;
  const piano = (IV.n || 0) >= (IV.di || 99);
  if (typeof flAttesaAvvia === 'function') flAttesaAvvia('iv', { titolo: piano ? 'Il tuo agente costruisce la roadmap' : 'Il tuo agente prepara la domanda', durataMs: piano ? 120000 : 45000, riapri: ivRientra });
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
}
function ivRientra(){
  IV.fuori = false;
  if (typeof flAttesaVia === 'function') flAttesaVia('iv');
  if (IV.ultima && IV.ultima.azioni && IV.ultima.azioni.piano){ ivFine(); return; }
  try{ GN.on = true; GN.modo = 'iv'; goId('s-genio'); }catch(_){ }
  if (IV.ultima && !IV.attesa){ ivRisposta(IV.ultima); return; }
  GN.step = ''; gnVai('iv'); if (IV.attesa) ivAttendi();
}
function ivRiprova(){ const ult = agSessMsgs(IV.sid).filter(function(m){ return m.direzione === 'in'; }).pop(); IV.attesa = true; IV.inviato = ult ? ult.id : 0; IV.da = Date.now(); GN.step = ''; gnVai('iv'); ivAttendi(); }
function ivChiudi(){
  clearTimeout(IV.poll);
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
}
/* il piano e' arrivato: la chat su questa conversazione, con "Applica la roadmap" */
function ivFine(){
  clearTimeout(IV.poll);
  try{ gnAu.musicaOff(); gnAu.punto(); flVibra([20, 40, 60]); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-agente');
  try{ agTitoloPaint(); agSessApri(IV.sid); agPollAvvia(); }catch(_){ }
}
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.iv = { entra: ivEntra };
  if (typeof gnChiudiTop === 'function'){ const v = gnChiudiTop; gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'iv'){ ivChiudi(); return; } return v.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v2 = gnIndietro; gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'iv'){ ivChiudi(); return true; } return v2.apply(this, arguments); }; }
  const st = document.createElement('style');
  st.textContent = [
    '.iv-box{display:flex;flex-direction:column;gap:12px}',
    '.iv-n{display:block;text-align:center;font:700 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#BCE0FF}',
    '.iv-esempi{display:flex;flex-wrap:wrap;gap:8px;justify-content:center}',
    '.iv-esempi button{border:0;border-radius:999px;padding:9px 14px;background:rgba(255,255,255,.14);color:#fff;font:600 13.5px var(--font-body);cursor:pointer;text-align:left}',
    '.iv-fuori{display:block;margin:18px auto 0}',
    '.iv-attesa{display:flex;justify-content:center;gap:8px;padding:18px 0}.iv-attesa i{width:10px;height:10px;border-radius:50%;background:#BCE0FF;animation:ivPunto 1.2s ease-in-out infinite}',
    '.iv-attesa i:nth-child(2){animation-delay:.2s}.iv-attesa i:nth-child(3){animation-delay:.4s}',
    '@keyframes ivPunto{0%,100%{opacity:.3;transform:translateY(0)}50%{opacity:1;transform:translateY(-6px)}}'
  ].join('\n');
  document.head.appendChild(st);
})();
