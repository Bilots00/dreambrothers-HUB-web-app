/* ===========================================================================================
   IL CONTRATTO DI ABITUDINE (0.9.302, Andrea)

   "Schermata di blocco / contratto di abitudine: regola di tempo di attesa che aumenta in modo
   esponenziale per disincentivare la modifica delle regole; penitenza 2: schermata in bianco e
   nero che si applica su tutto; penitenza 3: soldi persi / donati ad un amico o in beneficenza
   se si sgarra."

   Un contratto con se stessi: cosa ci si impegna a non fare, su quali app, quanto tempo al giorno
   ci si concede, e le penitenze se si sgarra.
   - Penitenza 1, sempre: per allentare una regola di blocco si aspetta 1, 2, 4, 8... minuti (tetto
     24 ore, il conto torna a un minuto dopo 7 giorni senza richieste); finita l'attesa le regole
     restano aperte 15 minuti. Lo fa rispettare il telefono (Contratto.java + il plugin), non questa
     pagina: chiudere l'app non accorcia niente.
   - Penitenza 2: uno sgarro mette in bianco e nero TUTTO il telefono per le ore scelte (Greyscale).
   - Penitenza 3: i soldi passano dal patto (patto.js, focuslockPatti.ts) con la verifica
     "contratto": un giorno con uno sgarro e' un giorno mancato. A un amico che fa da garante o a un
     ente. I pagamenti veri restano spenti finche' non c'e' la chiave di Stripe: si scrive l'impegno.
   - Cosa conta come sgarro: il terzo tentativo del giorno di aprire un'app del contratto bloccata,
     il tempo di oggi oltre il limite, una regola spenta nella finestra (o lo sblocco di emergenza
     della modalita' severa). Uno per tipo e per app al giorno.

   Nel browser (e sul computer) il motore e' CTR_LOCALE, con le stesse regole, su localStorage:
   li' non blocca niente, serve all'anteprima e alle prove.
   =========================================================================================== */
const CTR = { s: null, w: null, passo: 0, tick: 0, appTutte: null, cerca: '', patto: null };
const CTR_ICO = '📜';
const CTR_I = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
const CTR_X = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const CTR_CHEV = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
const CTR_REGOLE = { tettoMin: 1440, finestraMin: 15, azzeraGiorni: 7, tentativi: 3 };

function ctrEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function ctrNativo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.contrattoStato === 'function'; }

/* ---------------------------------------------------------------------------------------
   IL MOTORE NEL BROWSER: le stesse regole di Contratto.java
   --------------------------------------------------------------------------------------- */
const CTR_LOCALE = (function(){
  const K = 'fl_contratto_web', MIN = 60000, ORA = 3600000, GIORNO = 86400000;
  const leggi = function(){ try{ return JSON.parse(localStorage.getItem(K) || '{}') || {}; }catch(_){ return {}; } };
  const scrivi = function(d){ try{ localStorage.setItem(K, JSON.stringify(d)); }catch(_){ } };
  const giorno = function(ms){ const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const attesaMinuti = function(n){ n = Math.max(0, n | 0); return n >= 11 ? CTR_REGOLE.tettoMin : Math.min(CTR_REGOLE.tettoMin, Math.pow(2, n)); };
  const nValido = function(d, ora){ return (!d.ultimaRichiesta || ora - d.ultimaRichiesta >= CTR_REGOLE.azzeraGiorni * GIORNO) ? 0 : (d.n || 0); };
  const firmato = function(d){ const k = d.c || {}; return !!k.attivo && Date.now() < (k.fineAt || Infinity); };
  /* 0.9.340: con un amico come garante il contratto vale da quando l'amico firma */
  const vigore = function(d){ const k = d.c || {}, s = k.soldi || {}; return s.tipo !== 'amico' || +k.garanteAt > 0; };
  const attivo = function(d){ return firmato(d) && vigore(d); };
  const finestra = function(d, ora){ return d.attesaFino > 0 && ora >= d.attesaFino && ora < d.attesaFino + CTR_REGOLE.finestraMin * MIN; };
  const apps = function(k){ return ((k && k.apps) || []).map(function(a){ return String(a.p || a).toLowerCase(); }); };
  const euro = function(k){ const s = (k && k.soldi) || {}; return s.tipo && s.tipo !== 'nessuno' ? (+s.euro || 0) : 0; };
  const indebolisce = function(a, b){
    const dopo = apps(b);
    if (apps(a).some(function(p){ return dopo.indexOf(p) < 0; })) return true;
    if ((+b.limiteMin || 0) > (+a.limiteMin || 0)) return true;
    if ((+b.grigioOre || 0) < (+a.grigioOre || 0)) return true;
    if (euro(b) < euro(a)) return true;
    return (b.fineAt || 0) < (a.fineAt || 0);
  };
  const messaggio = function(d){
    const ora = Date.now();
    if (d.attesaFino > ora) return 'Il tuo contratto di abitudine protegge questa regola: mancano ' + Math.max(1, Math.ceil((d.attesaFino - ora) / MIN)) + ' minuti alla fine dell’attesa.';
    return 'Il tuo contratto di abitudine protegge questa regola. Per cambiarla chiedi la modifica e aspetta ' + ctrDurata(attesaMinuti(nValido(d, ora))) + '.';
  };
  const stato = function(){
    const d = leggi(), ora = Date.now(), n = nValido(d, ora);
    return { contratto: d.c || {}, attivo: attivo(d), inAttesaGarante: firmato(d) && !vigore(d), adesso: ora, n: n, prossimaAttesaMin: attesaMinuti(n), attesaFino: d.attesaFino || 0, attesaMin: d.attesaMin || 0,
      finestraFino: d.attesaFino ? d.attesaFino + CTR_REGOLE.finestraMin * MIN : 0, ultimaRichiesta: d.ultimaRichiesta || 0, grigioFino: d.grigioFino || 0,
      sgarri: d.sgarri || [], tentativi: (d.t && d.t.g === giorno(ora)) ? d.t.c : {}, regole: CTR_REGOLE, permessoGrigio: true, locale: true };
  };
  const rifiuta = function(msg){ const e = new Error(msg); e.code = 'contract-wait'; return Promise.reject(e); };
  const api = {
    attesaMinuti: attesaMinuti,
    contrattoStato: function(){ return Promise.resolve(stato()); },
    contrattoFirma: function(o){
      const d = leggi(), ora = Date.now(), nuovo = JSON.parse(JSON.stringify((o && o.contratto) || {}));
      const giorni = Math.max(1, Math.min(365, +nuovo.giorni || 30));
      nuovo.attivo = true;
      if (attivo(d)){
        nuovo.firmatoAt = d.c.firmatoAt; nuovo.fineAt = nuovo.fineAt || d.c.fineAt;
        if (!finestra(d, ora) && indebolisce(d.c, nuovo)) return rifiuta(messaggio(d));
      } else { nuovo.firmatoAt = ora; nuovo.fineAt = ora + giorni * GIORNO; d.attesaFino = 0; }
      d.c = nuovo; scrivi(d); return Promise.resolve(stato());
    },
    contrattoChiedi: function(){
      const d = leggi(), ora = Date.now();
      if (attivo(d) && !(d.attesaFino > ora) && !finestra(d, ora)){
        const n = nValido(d, ora), m = attesaMinuti(n);
        d.n = n + 1; d.ultimaRichiesta = ora; d.attesaFino = ora + m * MIN; d.attesaMin = m; scrivi(d);
      }
      return Promise.resolve(stato());
    },
    contrattoRitira: function(){ const d = leggi(); if (firmato(d) && !vigore(d)){ d.c.attivo = false; d.c.ritiratoAt = Date.now(); d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoAnnulla: function(){ const d = leggi(); if (d.attesaFino > Date.now()){ d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoChiudi: function(){ const d = leggi(); if (finestra(d, Date.now())){ d.attesaFino = 0; scrivi(d); } return Promise.resolve(stato()); },
    contrattoStrappa: function(){
      const d = leggi(); if (!attivo(d)) return Promise.resolve(stato());
      if (!finestra(d, Date.now())) return rifiuta(messaggio(d));
      d.c.attivo = false; d.c.strappatoAt = Date.now(); scrivi(d); return Promise.resolve(stato());
    },
    /* nel browser nessuno vede le app: le prove chiamano queste due al posto del servizio */
    sgarro: function(tipo, pkg, nome, cosa){
      const d = leggi(); if (!attivo(d)) return false;
      const ora = Date.now(), g = giorno(ora), chiave = g + ':' + tipo + ':' + (pkg || '');
      d.fatti = (d.fatti && d.fatti.g === g) ? d.fatti : { g: g, l: [] };
      if (d.fatti.l.indexOf(chiave) >= 0) return false;
      d.fatti.l.push(chiave);
      const k = d.c, ore = +k.grigioOre || 0, s = { t: ora, g: g, k: tipo, n: nome || pkg || '', c: cosa || '', grigioOre: ore };
      if (pkg) s.p = pkg;
      if (k.soldi && k.soldi.tipo && k.soldi.tipo !== 'nessuno'){ s.euro = +k.soldi.euro || 0; s.a = k.soldi.a || ''; s.dest = k.soldi.tipo; }
      d.sgarri = [s].concat(d.sgarri || []).slice(0, 300);
      if (ore > 0) d.grigioFino = Math.max(d.grigioFino || 0, ora + ore * ORA);
      scrivi(d); return true;
    },
    tentativo: function(pkg, nome){
      const d = leggi(); if (!attivo(d) || apps(d.c).indexOf(String(pkg).toLowerCase()) < 0) return;
      const g = giorno(Date.now());
      d.t = (d.t && d.t.g === g) ? d.t : { g: g, c: {} };
      d.t.c[pkg] = (d.t.c[pkg] || 0) + 1; scrivi(d);
      if (d.t.c[pkg] >= CTR_REGOLE.tentativi) api.sgarro('tentativo', pkg, nome, d.t.c[pkg] + ' tentativi di aprirla oggi');
    },
    modificaConcessa: function(){ const d = leggi(); return !attivo(d) || finestra(d, Date.now()); },
    messaggio: function(){ return messaggio(leggi()); }
  };
  return api;
})();
window.CTR_LOCALE = CTR_LOCALE;
function ctrMotore(){ return ctrNativo() ? NATIVE : CTR_LOCALE; }

/* ---------------------------------------------------------------------------------------
   LE PAROLE
   --------------------------------------------------------------------------------------- */
function ctrDurata(min){
  min = Math.round(min);
  if (min < 60) return min === 1 ? 'un minuto' : min + ' minuti';
  const h = Math.floor(min / 60), m = min % 60;
  const s = h === 1 ? 'un’ora' : h + ' ore';
  return m ? s + ' e ' + m + ' minuti' : s;
}
function ctrConto(ms){
  const t = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(s).padStart(2, '0');
}
function ctrData(ms){ return new Date(ms).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' }); }
function ctrOra(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function ctrQuando(ms){
  const d = new Date(ms), oggi = new Date(); const ieri = new Date(Date.now() - 86400000);
  const st = function(a, b){ return a.toDateString() === b.toDateString(); };
  return (st(d, oggi) ? 'Oggi' : st(d, ieri) ? 'Ieri' : d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' }).replace(/^./, function(x){ return x.toUpperCase(); })) + ' alle ' + ctrOra(ms);
}
function ctrNomiApp(k){ const a = ((k && k.apps) || []).map(function(x){ return x.n || x.p; }); return a.length <= 2 ? a.join(' e ') : a.slice(0, -1).join(', ') + ' e ' + a[a.length - 1]; }
function ctrLimiteTxt(k){
  const l = +k.limiteMin || 0;
  return l ? 'Al massimo ' + ctrDurata(l) + ' al giorno su ' + ctrNomiApp(k) : 'Su ' + ctrNomiApp(k) + ' neanche un minuto';
}
function ctrSoldiTxt(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return '';
  return s.euro + ' € ' + (s.tipo === 'beneficenza' ? 'in beneficenza a ' : 'a ') + (s.a || (s.tipo === 'beneficenza' ? 'un ente' : 'un amico'));
}
function ctrSgarroTit(x){
  if (x.k === 'tentativo') return 'Hai provato ad aprire ' + (x.n || 'un’app del contratto');
  if (x.k === 'limite') return 'Hai superato il limite su ' + (x.n || 'un’app del contratto');
  return /emergenza/i.test(x.c || '') ? 'Hai usato lo sblocco di emergenza' : 'Hai spento una regola';
}

/* ---------------------------------------------------------------------------------------
   LO STATO
   --------------------------------------------------------------------------------------- */
async function ctrCarica(){
  try{ CTR.s = await ctrMotore().contrattoStato(); }catch(_){ CTR.s = CTR.s || null; }
  if (CTR.s && CTR.s.regole) Object.assign(CTR_REGOLE, CTR.s.regole);
  ctrGrigioWeb();
  return CTR.s;
}
function ctrAttivo(){ return !!(CTR.s && CTR.s.attivo); }
/* Nel browser e sul computer il bianco e nero di sistema non c'e': la penitenza scolora la pagina. */
function ctrGrigioWeb(){
  try{ const on = !!(CTR.s && CTR.s.locale && CTR.s.grigioFino > Date.now()); document.documentElement.classList.toggle('ctr-grigio', on); }catch(_){ }
}
/** Il verdetto di un giorno per il patto con la verifica "contratto": false con uno sgarro, true a giorno finito, null prima. */
async function ctrVerdetto(giorno){
  const s = await ctrCarica(); if (!s) return null;
  if ((s.sgarri || []).some(function(x){ return x.g === giorno; })) return false;
  const fine = new Date(giorno + 'T00:00:00').getTime() + 86400000;
  /* un giorno finito prima della firma non dice niente */
  const firmato = +((s.contratto || {}).firmatoAt) || 0;
  if (!firmato || firmato >= fine) return null;
  return Date.now() >= fine ? true : null;
}

/* ---------------------------------------------------------------------------------------
   LE SCHERMATE
   --------------------------------------------------------------------------------------- */
registerScreen('s-contratto', '<div class="topbar ctr-top"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + CTR_I + '</button><b class="blk-title">Contratto di abitudine</b><button type="button" class="iconbtn ctr-i" onclick="ctrSgarriInfo()" aria-label="Cosa conta come sgarro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg></button></div><div id="ctrBody"></div><div class="spacer"></div>');
registerScreen('s-contratto-nuovo', '<div class="topbar ctr-top"><button class="iconbtn" onclick="ctrIndietroW()" aria-label="Indietro">' + CTR_I + '</button><b class="blk-title" id="ctrWTit">Il tuo contratto</b><span class="iconbtn ctr-vuota" aria-hidden="true"></span></div><div class="md-prog" id="ctrProg"></div><div id="ctrW"></div><div class="spacer"></div>', { back: function(){ ctrIndietroW(); return null; } });
registerScreen('s-contratto-attesa', '<div id="ctrA"></div>', { back: function(){ ctrAttesaStop(); return 's-contratto'; } });

async function ctrApri(){
  goId('s-contratto');
  if (!CTR.s) ctrPaint();
  await ctrCarica(); ctrPaint();
  ctrPattoCarica();
}

function ctrPaint(){
  const host = document.getElementById('ctrBody'); if (!host) return;
  const s = CTR.s;
  if (!s){ host.innerHTML = '<p class="ctr-carica">Leggo il tuo contratto…</p>'; return; }
  if (!s.attivo && !s.inAttesaGarante){ host.innerHTML = ctrVuotoHtml(s); return; }
  const k = s.contratto || {}, ora = Date.now();
  /* 0.9.340: finche' il garante non firma, il contratto e' una proposta: lo si vede, ma non protegge niente */
  if (s.inAttesaGarante){
    const chi = ((k.soldi || {}).a) || 'il tuo garante';
    host.innerHTML = '<div class="ctr-attesa-g"><span class="ctr-emo">\u270d\ufe0f</span><b>Il contratto entra in vigore quando ' + ctrEsc(chi) + ' lo firma</b>'
      + '<p>Fino a quel momento le tue regole restano libere e gli sgarri non contano.</p>'
      + (CTR.patto && CTR.patto.stato === 'attesa' ? '<button type="button" class="am-cta" onclick="patManda(' + CTR.patto.id + ')">Manda il contratto a ' + ctrEsc(chi) + '</button>' : '') + '</div>'
      + '<section class="ctr-foglio">'
      +   '<small class="ctr-eti">Il tuo contratto</small>'
      +   '<p class="ctr-impegno">' + ctrEsc(k.frase || ctrFrase(k.impegno)) + '</p>'
      +   '<p class="ctr-lim">' + ctrEsc(ctrLimiteTxt(k)) + '</p>'
      + '</section>'
      + '<button type="button" class="ctr-stampa" onclick="ctrStampa()">' + CTR_STAMPA_ICO + 'Stampa il contratto</button>';
    return;
  }
  const grigio = s.grigioFino > ora;
  const inCorso = s.attesaFino > 0 && s.finestraFino > ora;
  host.innerHTML = (inCorso ? ctrStatoHtml(s) : '')
    + '<section class="ctr-foglio">'
    +   '<small class="ctr-eti">Il tuo contratto · fino al ' + ctrEsc(ctrData(k.fineAt)) + '</small>'
    +   '<p class="ctr-impegno">' + ctrEsc(k.frase || ctrFrase(k.impegno)) + '</p>'
    +   '<p class="ctr-lim">' + ctrEsc(ctrLimiteTxt(k)) + '</p>'
    + '</section>'
    + '<h3 class="ctr-sez">Se sgarri</h3>'
    + '<div class="ctr-pen">'
    +   ctrPenRiga('1', 'Le regole si cambiano dopo un’attesa', 'La prossima attesa è di ' + ctrDurata(s.prossimaAttesaMin) + ', poi raddoppia')
    +   ctrPenRiga('2', (+k.grigioOre ? 'Bianco e nero per ' + ctrDurata(k.grigioOre * 60) : 'Niente bianco e nero'), grigio ? 'In corso fino alle ' + ctrOra(s.grigioFino) + (new Date(s.grigioFino).toDateString() !== new Date().toDateString() ? ' di ' + ctrData(s.grigioFino) : '') : (+k.grigioOre ? 'Su tutto il telefono, dopo ogni sgarro' : 'L’hai scelto tu alla firma'), grigio)
    +   ctrPenRiga('3', ctrSoldiTxt(k) ? ctrSoldiTxt(k) + ' per ogni giorno con uno sgarro' : 'Niente soldi', ctrSoldiNota(k))
    + '</div>'
    + ctrPattoHtml(k)
    + ctrStoricoHtml(s.sgarri || [])
    + (inCorso ? '' : ctrStatoHtml(s))
    /* 0.9.340, Andrea: "una volta creato il contratto non si deve poter stracciare: si puo' stampare, che e' diverso" */
    + '<button type="button" class="ctr-stampa" onclick="ctrStampa()">' + CTR_STAMPA_ICO + 'Stampa il contratto</button>';
}
const CTR_STAMPA_ICO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/></svg>';
/* STAMPA: il contratto su un foglio, come immagine da salvare o mandare (lo stesso foglio di condivisione del profilo) */
function ctrStampa(){
  if (typeof flCondividiApri !== 'function'){ toast('La stampa funziona nell’app sul telefono'); return; }
  flCondividiApri(ctrStampaCanvas, '', 'Il tuo contratto');
}
async function ctrStampaCanvas(){
  const k = (CTR.s && CTR.s.contratto) || {};
  const W = 1000, H = 1400, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const x = cv.getContext('2d');
  x.fillStyle = '#FBF8F1'; x.fillRect(0, 0, W, H);
  x.strokeStyle = '#001E44'; x.lineWidth = 3; x.strokeRect(40, 40, W - 80, H - 80);
  x.lineWidth = 1; x.strokeRect(54, 54, W - 108, H - 108);
  x.textAlign = 'center'; x.fillStyle = '#0075E3'; x.font = '700 30px sans-serif'; x.fillText('DREAMMAP', W / 2, 140);
  x.fillStyle = '#001E44'; x.font = '800 58px serif'; x.fillText('Contratto di abitudine', W / 2, 220);
  const righe = function(t, y, font, max, passo){
    x.font = font; const parole = String(t || '').split(/\s+/); let r = '';
    parole.forEach(function(p){ const prova = r ? r + ' ' + p : p; if (x.measureText(prova).width > max && r){ x.fillText(r, W / 2, y); y += passo; r = p; } else r = prova; });
    if (r){ x.fillText(r, W / 2, y); y += passo; }
    return y;
  };
  let y = 330;
  x.fillStyle = '#001E44'; y = righe(k.frase || ctrFrase(k.impegno), y, '600 40px serif', W - 220, 54);
  y += 26; x.fillStyle = '#4A5B74'; y = righe(ctrLimiteTxt(k), y, '500 30px sans-serif', W - 240, 42);
  y += 40;
  const pen = [];
  if (+k.grigioOre) pen.push('Se sgarro, il telefono va in bianco e nero per ' + ctrDurata(k.grigioOre * 60) + '.');
  if (ctrSoldiTxt(k)) pen.push('Se sgarro, ' + ctrMinuscola(ctrSoldiTxt(k)) + ' per ogni giorno con uno sgarro.');
  pen.push('Le regole si cambiano solo dopo un’attesa che raddoppia ogni volta.');
  x.fillStyle = '#001E44'; pen.forEach(function(p){ y = righe(p, y, '500 28px sans-serif', W - 260, 40) + 14; });
  if (k.firmatoAt){ y += 20; x.fillStyle = '#4A5B74'; x.font = '500 26px sans-serif'; x.fillText('Firmato il ' + ctrData(k.firmatoAt) + (k.fineAt ? ', valido fino al ' + ctrData(k.fineAt) : ''), W / 2, y); }
  /* le due firme */
  const fy = H - 230;
  x.strokeStyle = '#001E44'; x.lineWidth = 2;
  x.beginPath(); x.moveTo(120, fy); x.lineTo(450, fy); x.moveTo(550, fy); x.lineTo(880, fy); x.stroke();
  x.fillStyle = '#4A5B74'; x.font = '500 22px sans-serif'; x.fillText('firma di chi promette', 285, fy + 36); x.fillText('firma del garante', 715, fy + 36);
  let firma = ''; try{ firma = localStorage.getItem('fl_firma_mia') || ''; }catch(_){ firma = ''; }
  if (firma){ try{ const im = await new Promise(function(ok, ko){ const i = new Image(); i.onload = function(){ ok(i); }; i.onerror = ko; i.src = firma; }); const s = Math.min(320 / im.width, 110 / im.height); x.drawImage(im, 285 - im.width * s / 2, fy - 8 - im.height * s, im.width * s, im.height * s); }catch(_){ } }
  else { x.fillStyle = '#001E44'; x.font = 'italic 44px serif'; x.fillText((typeof patMioNome === 'function') ? patMioNome() : '', 285, fy - 20); }
  const g = (k.soldi || {}).a || '';
  if (g && +k.garanteAt){ x.fillStyle = '#001E44'; x.font = 'italic 44px serif'; x.fillText(g, 715, fy - 20); }
  return cv;
}
/* 0.9.340: il contratto entra in vigore quando il garante firma il patto sul server. Si controlla aprendo la pagina e all'avvio. */
async function ctrVigoreControlla(){
  try{
    const s = CTR.s || await ctrCarica();
    if (!s || !s.inAttesaGarante) return;
    const k = s.contratto || {}, id = (k.soldi || {}).pattoId;
    if (!id || typeof patCarica !== 'function' || typeof PAT === 'undefined') return;
    await patCarica();
    const p = (Array.isArray(PAT.lista) ? PAT.lista : []).filter(function(x){ return x.id === id; })[0];
    CTR.patto = p || CTR.patto || null;
    if (!p || p.stato !== 'attivo') return;
    const nuovo = JSON.parse(JSON.stringify(k)); nuovo.garanteAt = Date.now();
    CTR.s = await ctrMotore().contrattoFirma({ contratto: nuovo });
    try{ toast((((k.soldi || {}).a) || 'Il tuo garante') + ' ha firmato: il contratto è in vigore'); }catch(_){ }
    if (document.getElementById('ctrBody')) ctrPaint();
  }catch(_){ }
}
/* 0.9.340, Andrea: "chiudimi il contratto che si e' creato: non l'ha firmato il mio garante e mi blocca il programma di
   WhatsApp". Una volta sola, per l'amministratore: la proposta non firmata si ritira e il patto in attesa si scioglie. */
async function ctrRitiroUnaTantum(){
  try{
    if (localStorage.getItem('fl_ctr_ritiro_340')) return;
    if (!(typeof flAdmin === 'function' && flAdmin())) return;
    const s = await ctrCarica(); if (!s) return;
    if (!s.inAttesaGarante){ localStorage.setItem('fl_ctr_ritiro_340', '1'); return; }
    const id = ((s.contratto || {}).soldi || {}).pattoId;
    const m = ctrMotore();
    if (typeof m.contrattoRitira === 'function') CTR.s = await m.contrattoRitira();
    if (id && typeof patApi === 'function'){ try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: id }); }catch(_){ } }
    localStorage.setItem('fl_ctr_ritiro_340', '1');
  }catch(_){ }
}
setTimeout(function(){ ctrRitiroUnaTantum().then(ctrVigoreControlla); }, 6000);
function ctrPenRiga(n, t, sub, acceso){
  return '<div class="ctr-pr' + (acceso ? ' on' : '') + '"><i>' + n + '</i><div><b>' + ctrEsc(t) + '</b><small>' + ctrEsc(sub || '') + '</small></div></div>';
}
function ctrSoldiNota(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return 'L’hai scelto tu alla firma';
  return 'Per ora è un impegno scritto: nessun addebito finché i pagamenti non sono collegati';
}
function ctrVuotoHtml(s){
  const fatti = (s.sgarri || []).length;
  return '<div class="ctr-vuoto">'
    + '<span class="ctr-emo">' + CTR_ICO + '</span>'
    + '<h2>Firma un contratto con te stesso</h2>'
    + '<p>Scrivi cosa non vuoi più fare. Se sgarri, paghi una penitenza che hai scelto tu.</p>'
    + '<div class="ctr-pen">'
    +   ctrPenRiga('1', 'Le regole si cambiano solo dopo un’attesa', 'Un minuto, poi due, poi quattro: raddoppia ogni volta')
    +   ctrPenRiga('2', 'Il telefono va in bianco e nero', 'Tutto, anche le app a colori, per le ore che scegli')
    +   ctrPenRiga('3', 'Paghi qualcosa', 'A un amico che fa da garante, o in beneficenza')
    + '</div>'
    + '<button type="button" class="am-cta ctr-cta" onclick="ctrNuovo()">Scrivi il tuo contratto</button>'
    + '</div>'
    + (fatti ? ctrStoricoHtml(s.sgarri) : '');
}
function ctrStatoHtml(s){
  const ora = Date.now();
  if (s.attesaFino > ora){
    return '<button type="button" class="ctr-stato attesa" onclick="ctrAttesaApri()"><small>Stai aspettando di cambiare le regole</small><b id="ctrStatoConto">' + ctrConto(s.attesaFino - ora) + '</b><span>Tocca per vedere l’attesa</span></button>';
  }
  if (s.finestraFino > ora && s.attesaFino > 0){
    return '<button type="button" class="ctr-stato aperta" onclick="ctrAttesaApri()"><small>Le regole sono aperte</small><b id="ctrStatoConto">' + ctrConto(s.finestraFino - ora) + '</b><span>Poi si richiudono da sole</span></button>';
  }
  return '<div class="ctr-stato ctr-stato-giu"><small>Vuoi cambiare una regola protetta?</small><button type="button" class="ctr-chiedi" onclick="ctrChiedi()">Chiedi di cambiare le regole</button><span>Adesso l’attesa è di ' + ctrDurata(s.prossimaAttesaMin) + '</span></div>';
}
function ctrStoricoHtml(l){
  const righe = (l || []).slice(0, 40);
  let h = '<h3 class="ctr-sez">I tuoi sgarri</h3>';
  if (!righe.length) return h + '<p class="ctr-nessuno">Nessuno sgarro finora.</p>';
  const giorniPagati = {};
  h += '<div class="ctr-storico">' + righe.slice().reverse().map(function(x){
    const pen = [];
    if (+x.grigioOre) pen.push('bianco e nero per ' + ctrDurata(x.grigioOre * 60));
    if (+x.euro && !giorniPagati[x.g]){ giorniPagati[x.g] = 1; pen.push(x.euro + ' € ' + (x.dest === 'beneficenza' ? 'in beneficenza' : 'a ' + (x.a || 'il tuo garante')) + ' per quel giorno'); }
    return '<div class="ctr-sg"><b>' + ctrEsc(ctrSgarroTit(x)) + '</b><small>' + ctrEsc(ctrQuando(x.t)) + (x.c && !/emergenza/i.test(x.c) ? ' · ' + ctrEsc(x.c) : '') + '</small>' + (pen.length ? '<small class="ctr-sg-pen">Penitenza: ' + ctrEsc(pen.join(', ')) + '</small>' : '') + '</div>';
  }).reverse().join('') + '</div>';
  return h;
}

/* il foglio della (i): cosa conta come sgarro, detto una volta e bene */
function ctrSgarriInfo(){
  const t = CTR_REGOLE.tentativi;
  ctrFoglio('<span class="ctr-emo">' + CTR_ICO + '</span><h3>Cosa conta come sgarro</h3>'
    + '<div class="ctr-def"><b>Insisti su un’app bloccata</b><p>Dal ' + t + '° tentativo nello stesso giorno di aprire un’app del contratto mentre è bloccata.</p></div>'
    + '<div class="ctr-def"><b>Superi il tuo limite</b><p>Il tempo di oggi su un’app del contratto va oltre quello che ti sei concesso. Se il limite è zero, basta un minuto.</p></div>'
    + '<div class="ctr-def"><b>Spegni una regola</b><p>Spegni la protezione, un programma o il Blocco rapido, oppure usi lo sblocco di emergenza della modalità severa.</p></div>'
    + '<p class="ctr-foglio-nota">Conta uno sgarro per tipo e per app al giorno. Lo vede il telefono da solo.</p>');
}
function ctrFoglio(html){
  let f = document.getElementById('ctrFoglio');
  if (!f){
    f = document.createElement('div'); f.id = 'ctrFoglio'; f.className = 'ctr-velo';
    f.addEventListener('click', function(e){ if (e.target === f) ctrFoglioChiudi(); });
    (document.getElementById('phone') || document.body).appendChild(f);
  }
  f.innerHTML = '<div class="ctr-sheet" role="dialog"><button type="button" class="ctr-x" onclick="ctrFoglioChiudi()" aria-label="Chiudi">' + CTR_X + '</button>' + html + '</div>';
  requestAnimationFrame(function(){ f.classList.add('open'); });
}
function ctrFoglioChiudi(){ const f = document.getElementById('ctrFoglio'); if (f) f.classList.remove('open'); }

/* ---------------------------------------------------------------------------------------
   LA RICHIESTA DI MODIFICA E LA SCHERMATA DI ATTESA
   --------------------------------------------------------------------------------------- */
async function ctrChiedi(){
  await ctrCarica();
  const s = CTR.s; if (!s || !s.attivo) return;
  if (!(s.attesaFino > Date.now()) && !(s.finestraFino > Date.now() && s.attesaFino > 0)){
    const m = s.prossimaAttesaMin, dopo = CTR_LOCALE.attesaMinuti((s.n || 0) + 1);
    let ok = true;
    try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Aspetti ' + ctrDurata(m) + '?', 'Dopo hai ' + CTR_REGOLE.finestraMin + ' minuti per cambiare le regole. La prossima volta l’attesa sarà di ' + ctrDurata(dopo) + '.', 'Comincia l’attesa'); }catch(_){ }
    if (!ok) return;
    try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(e){ toast(String((e && e.message) || 'Non sono riuscito a farlo')); return; }
    try{ flVibra(12); }catch(_){ }
  }
  ctrAttesaApri();
}
/** Il plugin ha rifiutato una modifica (codice "contract-wait"): lo si dice e si offre l'attesa. */
async function ctrRifiuto(e){
  await ctrCarica();
  const s = CTR.s;
  if (s && s.attesaFino > Date.now()){ toast(String((e && e.message) || 'Il contratto protegge questa regola')); ctrAttesaApri(); return; }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Il contratto protegge questa regola', 'Per cambiarla aspetti ' + ctrDurata((s && s.prossimaAttesaMin) || 1) + '. Poi hai ' + CTR_REGOLE.finestraMin + ' minuti per farlo.', 'Chiedi di cambiarla'); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(_){ }
  ctrAttesaApri();
}
function ctrAttesaApri(){ goId('s-contratto-attesa'); ctrAttesaPaint(true); ctrAttesaStop(); CTR.tick = setInterval(function(){ ctrAttesaPaint(false); }, 1000); }
function ctrAttesaStop(){ if (CTR.tick){ clearInterval(CTR.tick); CTR.tick = 0; } }
function ctrAttesaPaint(tutto){
  const host = document.getElementById('ctrA'); if (!host) return;
  const scr = document.getElementById('s-contratto-attesa');
  if (!tutto && scr && !scr.classList.contains('active')){ ctrAttesaStop(); return; }
  const s = CTR.s || {}, ora = Date.now();
  const attesa = s.attesaFino > ora, aperta = !attesa && s.attesaFino > 0 && s.finestraFino > ora;
  const fase = attesa ? 'attesa' : aperta ? 'aperta' : 'chiusa';
  const tot = attesa ? (s.attesaMin || 1) * 60000 : CTR_REGOLE.finestraMin * 60000;
  const resta = attesa ? s.attesaFino - ora : aperta ? s.finestraFino - ora : 0;
  const p = Math.max(0, Math.min(1, resta / tot));
  if (!tutto && host.dataset.fase === fase){
    const t = document.getElementById('ctrATempo'); if (t) t.textContent = ctrConto(resta);
    const a = document.getElementById('ctrAArco'); if (a) a.setAttribute('stroke-dashoffset', String(603 * (1 - p)));
    return;
  }
  host.dataset.fase = fase;
  const anello = '<div class="ef-anello"><svg viewBox="0 0 210 210" width="210" height="210" aria-hidden="true"><circle cx="105" cy="105" r="96" fill="none" stroke="rgba(255,255,255,.1)" stroke-width="10"/><circle id="ctrAArco" cx="105" cy="105" r="96" fill="none" stroke="' + (aperta ? '#7CC4FF' : '#2F9BFF') + '" stroke-width="10" stroke-linecap="round" stroke-dasharray="603" stroke-dashoffset="' + (603 * (1 - p)) + '" transform="rotate(-90 105 105)"/></svg><span><span class="ctr-a-dentro"><b id="ctrATempo" class="ef-tempo">' + ctrConto(resta) + '</b><small>' + (attesa ? 'e le regole si aprono' : 'e si richiudono') + '</small></span></span></div>';
  let h;
  if (attesa){
    const dopo = CTR_LOCALE.attesaMinuti(s.n || 0);
    h = '<div class="ef-centro ef-alto">' + anello
      + '<h1>Aspetta ancora un po’</h1>'
      + '<p>Il contratto che hai firmato ti chiede di aspettare ' + ctrDurata(s.attesaMin || 1) + ' prima di cambiare le regole.</p>'
      + '<p class="ctr-a-pross">La prossima volta l’attesa sarà di ' + ctrDurata(dopo) + '.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-grigio" onclick="ctrIndietroAttesa()">Torna al contratto</button><button type="button" class="ef-link" onclick="ctrAnnulla()">Annulla la richiesta</button></div>';
  } else if (aperta){
    h = '<div class="ef-centro ef-alto">' + anello
      + '<h1>Le regole sono aperte</h1>'
      + '<p>Puoi cambiare le regole protette per ' + CTR_REGOLE.finestraMin + ' minuti. Spegnerne una conta come sgarro.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="ctrVaiProtezione()">Vai alla Protezione</button><button type="button" class="ef-link" onclick="ctrChiudiFinestra()">Ho cambiato idea, richiudi</button></div>';
  } else {
    h = '<div class="ef-centro ef-alto"><span class="ctr-emo ctr-emo-scuro">' + CTR_ICO + '</span><h1>Le regole sono di nuovo protette</h1><p>Per cambiarle serve un’altra attesa.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-grigio" onclick="ctrIndietroAttesa()">Torna al contratto</button></div>';
  }
  host.innerHTML = '<div class="ef ctr-a"><button type="button" class="ef-x" onclick="ctrIndietroAttesa()" aria-label="Chiudi">' + CTR_X + '</button>' + h + '</div>';
}
function ctrIndietroAttesa(){ ctrAttesaStop(); goId('s-contratto'); ctrPaint(); ctrCarica().then(ctrPaint); }
async function ctrAnnulla(){
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Annullare la richiesta?', 'Le regole restano protette. La richiesta resta contata: la prossima attesa non si accorcia.', 'Annulla la richiesta'); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoAnnulla(); }catch(_){ }
  ctrIndietroAttesa();
}
async function ctrChiudiFinestra(){ try{ CTR.s = await ctrMotore().contrattoChiudi(); }catch(_){ } ctrIndietroAttesa(); }
function ctrVaiProtezione(){ ctrAttesaStop(); try{ if (typeof blPaginaApri === 'function') blPaginaApri(); else goId('s-home'); }catch(_){ goId('s-home'); } }

async function ctrStrappa(){
  await ctrCarica();
  const s = CTR.s; if (!s || !s.attivo) return;
  const aperta = s.attesaFino > 0 && s.attesaFino <= Date.now() && s.finestraFino > Date.now();
  if (!aperta){
    let ok = true;
    try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Vuoi strappare il contratto?', 'Anche per questo serve l’attesa: ' + ctrDurata(s.attesaFino > Date.now() ? s.attesaMin : s.prossimaAttesaMin) + '. Poi hai ' + CTR_REGOLE.finestraMin + ' minuti per farlo.', s.attesaFino > Date.now() ? 'Vedi l’attesa' : 'Comincia l’attesa', true); }catch(_){ }
    if (!ok) return;
    if (!(s.attesaFino > Date.now())){ try{ CTR.s = await ctrMotore().contrattoChiedi(); }catch(_){ } }
    ctrAttesaApri(); return;
  }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Strappare il contratto?', 'Le regole tornano libere e i prossimi sgarri non costano più niente. Quelli già fatti restano scritti.', 'Strappa il contratto', true); }catch(_){ }
  if (!ok) return;
  try{ CTR.s = await ctrMotore().contrattoStrappa(); }catch(e){ toast(String((e && e.message) || 'Non sono riuscito a farlo')); return; }
  /* il patto verso un ente (o non ancora firmato dall'amico) lo scioglie chi si impegna; quello firmato lo scioglie l'amico */
  let resta = '';
  try{
    const k = (CTR.s && CTR.s.contratto) || {};
    if (k.soldi && k.soldi.pattoId && typeof patApi === 'function'){
      try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: k.soldi.pattoId }); }
      catch(_){ if (k.soldi.tipo === 'amico') resta = k.soldi.a || 'il tuo garante'; }
    }
  }catch(_){ }
  toast(resta ? 'Contratto strappato. Il patto con ' + resta + ' resta: può scioglierlo solo lui' : 'Contratto strappato');
  await ctrCarica(); ctrPaint();
}

/* ---------------------------------------------------------------------------------------
   IL PATTO DEI SOLDI (patto.js): verifica "contratto", verso un amico o un ente
   --------------------------------------------------------------------------------------- */
async function ctrPattoCarica(){
  const k = (CTR.s && CTR.s.contratto) || {};
  if (!k.soldi || !k.soldi.pattoId || typeof patCarica !== 'function' || typeof PAT === 'undefined') return;
  try{ await patCarica(); CTR.patto = Array.isArray(PAT.lista) ? PAT.lista.filter(function(p){ return p.id === k.soldi.pattoId; })[0] || null : null; }catch(_){ }
  if (CTR.s && CTR.s.inAttesaGarante){ await ctrVigoreControlla(); }
  if (document.getElementById('ctrBody')) ctrPaint();
}
function ctrPattoHtml(k){
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return '';
  if (!s.pattoId) return '<div class="ctr-patto"><p>Il patto con i soldi non è partito' + (s.errore ? ': ' + ctrEsc(s.errore) : '') + '.</p><button type="button" class="am-link" onclick="ctrPattoCrea()">Riprova</button></div>';
  const p = CTR.patto;
  if (s.tipo === 'amico' && p && p.stato === 'attesa') return '<div class="ctr-patto"><p>' + ctrEsc(s.a || 'Il tuo garante') + ' non ha ancora firmato il patto.</p><button type="button" class="am-cta" onclick="patManda(' + p.id + ')">Manda il patto a ' + ctrEsc(s.a || 'il tuo garante') + '</button></div>';
  return '';
}
/** Crea il patto sul server. Torna l'id, o scrive l'errore nel contratto (che resta firmato lo stesso). */
async function ctrPattoCrea(k){
  k = k || (CTR.s && CTR.s.contratto) || {};
  const s = k.soldi || {};
  if (!s.tipo || s.tipo === 'nessuno') return 0;
  let id = 0, errore = '';
  try{
    if (typeof patApi !== 'function') throw new Error('Il patto funziona nell’app sul telefono');
    const giorni = Math.max(7, Math.round(((k.fineAt || Date.now()) - Date.now()) / 86400000) || (k.giorni || 30));
    const ab = { cosa: ctrFrase(k.impegno).replace(/^Mi impegno a non /, 'Non '), verifica: { tipo: 'contratto' }, giorni: [true, true, true, true, true, true, true], entro: '23:59' };
    /* 0.9.335, Andrea: "hai creato 2 contratti". Un "Riprova" dopo una risposta persa ne creava un secondo sul server: se il patto
       di questo contratto c'e' gia' (stessa frase, non sciolto), si riprende quello */
    try{
      if (typeof patCarica === 'function'){ await patCarica(); }
      const gia = (Array.isArray(PAT.lista) ? PAT.lista : []).filter(function(p){ const a = p && p.abitudine; return a && a.verifica && a.verifica.tipo === 'contratto' && a.cosa === ab.cosa && p.stato !== 'sciolto' && p.stato !== 'finito'; }).sort(function(x, y){ return (y.id || 0) - (x.id || 0); })[0];
      if (gia && gia.id) id = gia.id;
    }catch(_){ }
    if (s.tipo === 'beneficenza') ab.destinazione = { tipo: 'beneficenza', ente: s.a };
    if (!id){
      const r = await patApi('POST', '/api/focuslock/patti', { abitudine: ab, posta: s.euro, tetto: s.tetto || Math.max(s.euro, s.euro * 10), durataGiorni: giorni, garanteNome: s.tipo === 'amico' ? s.a : '', nome: (typeof nvNome === 'function' && nvNome()) || '' });
    id = (r && r.patto && r.patto.id) || 0;
    }
  }catch(e){ errore = String((e && e.message) || e).slice(0, 120); }
  const nuovo = JSON.parse(JSON.stringify(k));
  nuovo.soldi = Object.assign({}, s, { pattoId: id || 0, errore: id ? '' : errore });
  try{ CTR.s = await ctrMotore().contrattoFirma({ contratto: nuovo }); }catch(_){ }
  if (id && s.tipo === 'amico') setTimeout(function(){ try{ patManda(id); }catch(_){ } }, 700);
  if (document.getElementById('ctrBody')){ ctrPaint(); ctrPattoCarica(); }
  return id;
}

/* ---------------------------------------------------------------------------------------
   IL CONTRATTO NUOVO: una domanda per schermata
   --------------------------------------------------------------------------------------- */
const CTR_PASSI = ['impegno', 'app', 'limite', 'attesa', 'grigio', 'soldi', 'firma'];
const CTR_ESEMPI = ['Aprire Instagram appena sveglio', 'Scorrere TikTok a letto', 'Guardare YouTube mentre lavoro', 'Controllare il telefono ogni cinque minuti'];
function ctrNuovo(){
  CTR.w = { impegno: '', apps: [], limiteMin: 15, limiteMio: false, grigioOre: 6, grigioMio: false, soldi: { tipo: 'amico', a: '', euro: 5, mio: false }, giorni: 30 };
  CTR.passo = 0; CTR.cerca = '';
  goId('s-contratto-nuovo'); ctrWPaint();
  ctrAppCarica();
}
function ctrIndietroW(){ ctrLeggiCampi(); if (CTR.passo > 0){ CTR.passo--; ctrWPaint(); return; } goId('s-contratto'); ctrPaint(); }
function ctrAvanti(){ ctrLeggiCampi(); const e = ctrControlla(); if (e){ toast(e); return; } CTR.passo = Math.min(CTR_PASSI.length - 1, CTR.passo + 1); ctrWPaint(); try{ document.getElementById('s-contratto-nuovo').scrollTop = 0; }catch(_){ } }
function ctrLeggiCampi(){
  const w = CTR.w; if (!w) return;
  const v = function(id){ const e = document.getElementById(id); return e ? e.value.trim() : null; };
  if (v('ctrImpegno') !== null) w.impegno = v('ctrImpegno');
  if (v('ctrLimMio') !== null && w.limiteMio){ const n = parseInt(v('ctrLimMio'), 10); if (!isNaN(n)) w.limiteMin = Math.max(0, Math.min(1440, n)); }
  if (v('ctrGrigioMio') !== null && w.grigioMio){ const n = parseInt(v('ctrGrigioMio'), 10); if (!isNaN(n)) w.grigioOre = Math.max(0, Math.min(72, n)); }
  if (v('ctrSoldiA') !== null) w.soldi.a = v('ctrSoldiA');
  if (v('ctrEuroMio') !== null && w.soldi.mio){ const n = parseInt(v('ctrEuroMio'), 10); if (!isNaN(n)) w.soldi.euro = Math.max(0, Math.min(100, n)); }
}
function ctrControlla(){
  const w = CTR.w, p = CTR_PASSI[CTR.passo];
  if (p === 'impegno' && !w.impegno) return 'Scrivi cosa non vuoi più fare';
  if (p === 'app' && !w.apps.length) return 'Scegli almeno un’app';
  if (p === 'soldi' && !w.soldi.a) return 'Scrivi il nome del tuo garante';
  if (p === 'firma' && !w.firma) return 'Firma il contratto';
  return '';
}
function ctrOpz(on, js, txt){ return '<button type="button" class="ctr-opz' + (on ? ' on' : '') + '" onclick="ctrLeggiCampi();' + js + ';ctrWPaint()">' + txt + '</button>'; }
function ctrWPaint(){
  const host = document.getElementById('ctrW'); if (!host || !CTR.w) return;
  const w = CTR.w, p = CTR_PASSI[CTR.passo];
  const prog = document.getElementById('ctrProg'); if (prog) prog.innerHTML = '<i style="width:' + Math.round((CTR.passo + 1) / CTR_PASSI.length * 100) + '%"></i>';
  const tit = document.getElementById('ctrWTit'); if (tit) tit.textContent = 'Il tuo contratto · ' + (CTR.passo + 1) + ' di ' + CTR_PASSI.length;
  const avanti = function(t){ return '<button type="button" class="am-cta ctr-avanti" onclick="ctrAvanti()">' + (t || 'Avanti') + '</button>'; };
  let h = '';
  if (p === 'impegno'){
    h = '<h2 class="ctr-q">Cosa non vuoi più fare?</h2><p class="ctr-qs">Una cosa sola, detta come la diresti a un amico.</p>'
      + '<textarea id="ctrImpegno" class="fin ctr-campo" rows="3" placeholder="Per esempio: aprire Instagram appena sveglio">' + ctrEsc(w.impegno) + '</textarea>'
      + '<div class="ctr-esempi">' + CTR_ESEMPI.map(function(e){ return '<button type="button" onclick="document.getElementById(\'ctrImpegno\').value=this.textContent">' + ctrEsc(e) + '</button>'; }).join('') + '</div>' + avanti();
  } else if (p === 'app'){
    h = '<h2 class="ctr-q">Su quali app vale il contratto?</h2><p class="ctr-qs">Il telefono conta il tempo e i tentativi solo su queste.</p>'
      + (w.apps.length ? '<div class="ctr-scelte">' + w.apps.map(function(a){ return '<button type="button" onclick="ctrAppTogli(\'' + ctrEsc(a.p) + '\')">' + ctrEsc(a.n) + ' <span aria-hidden="true">×</span></button>'; }).join('') + '</div>' : '')
      + '<input id="ctrCerca" class="fin" placeholder="Cerca un’app" value="' + ctrEsc(CTR.cerca) + '" oninput="CTR.cerca=this.value;ctrAppLista()">'
      + '<div id="ctrAppL" class="ctr-appl"></div>' + avanti();
  } else if (p === 'limite'){
    const v = [[0, 'Neanche un minuto'], [15, '15 minuti'], [30, '30 minuti'], [60, 'Un’ora']];
    h = '<h2 class="ctr-q">Quanto tempo al giorno ti concedi su ' + ctrEsc(ctrNomiApp(w)) + '?</h2><p class="ctr-qs">Oltre questo tempo è uno sgarro.</p>'
      + '<div class="ctr-opzl">' + v.map(function(x){ return ctrOpz(!w.limiteMio && w.limiteMin === x[0], 'CTR.w.limiteMio=false;CTR.w.limiteMin=' + x[0], x[1]); }).join('')
      + ctrOpz(w.limiteMio, 'CTR.w.limiteMio=true', 'Lo scrivo io') + '</div>'
      + (w.limiteMio ? '<label class="ctr-l" for="ctrLimMio">Minuti al giorno</label><input id="ctrLimMio" class="fin" type="number" inputmode="numeric" min="0" value="' + w.limiteMin + '">' : '')
      + avanti();
  } else if (p === 'attesa'){
    const scala = [1, 2, 4, 8, 16, 32];
    h = '<span class="ctr-emo">⏳</span><h2 class="ctr-q">Le regole si cambiano solo dopo un’attesa</h2>'
      + '<p class="ctr-qs">Ogni volta che vorrai allentare un blocco, aspetterai. E ogni volta l’attesa raddoppia.</p>'
      + '<div class="ctr-scala">' + scala.map(function(m, i){ return '<div><b>' + (m < 60 ? m : m / 60) + '</b><small>' + (m === 1 ? 'minuto' : 'minuti') + '</small><i>' + (i + 1) + 'ª volta</i></div>'; }).join('') + '<div class="ctr-scala-fine"><b>24</b><small>ore al massimo</small></div></div>'
      + '<p class="ctr-qs">Finita l’attesa hai ' + CTR_REGOLE.finestraMin + ' minuti per cambiare le regole. Dopo ' + CTR_REGOLE.azzeraGiorni + ' giorni senza richieste si riparte da un minuto.</p>'
      + avanti('Ho capito');
  } else if (p === 'grigio'){
    const v = [[2, '2 ore'], [6, '6 ore'], [12, '12 ore'], [24, 'Un giorno intero'], [0, 'Niente bianco e nero']];
    const perm = !CTR.s || CTR.s.permessoGrigio !== false;
    h = '<h2 class="ctr-q">Se sgarri, per quanto tempo il telefono va in bianco e nero?</h2><p class="ctr-qs">Tutto il telefono, anche le app che di solito restano a colori.</p>'
      + '<div class="ctr-opzl">' + v.map(function(x){ return ctrOpz(!w.grigioMio && w.grigioOre === x[0], 'CTR.w.grigioMio=false;CTR.w.grigioOre=' + x[0], x[1]); }).join('')
      + ctrOpz(w.grigioMio, 'CTR.w.grigioMio=true', 'Lo scrivo io') + '</div>'
      + (w.grigioMio ? '<label class="ctr-l" for="ctrGrigioMio">Ore di bianco e nero</label><input id="ctrGrigioMio" class="fin" type="number" inputmode="numeric" min="0" value="' + w.grigioOre + '">' : '')
      + (!perm && w.grigioOre ? '<div class="ctr-avviso"><p>Per il bianco e nero il telefono deve dare un permesso, una volta sola, dal computer.</p><button type="button" class="am-link" onclick="if(typeof grOpen===\'function\')grOpen()">Come si dà il permesso</button></div>' : '')
      + avanti();
  } else if (p === 'soldi'){
    /* 0.9.337, Andrea: "il contratto di abitudine e il patto con il Dreambrother sono la stessa cosa: un contratto non lo fai da solo,
       lo fai con un garante". Il garante c'e' sempre; i soldi sono la sua parte, e possono anche essere niente. */
    const s = w.soldi; s.tipo = 'amico';
    h = '<h2 class="ctr-q">Chi è il tuo garante?</h2><p class="ctr-qs">Un amico, un fratello, tua madre: firma il contratto con te dalla sua app.</p>'
      + '<input id="ctrSoldiA" class="fin" placeholder="Il suo nome" value="' + ctrEsc(s.a) + '">'
      + '<label class="ctr-l">Se sgarri, quanto gli dai per ogni giorno con uno sgarro?</label>'
      + '<div class="ctr-euro">' + [[0, 'Niente, basta la parola'], [2, '2 €'], [5, '5 €'], [10, '10 €'], [20, '20 €']].map(function(e){ return ctrOpz(!s.mio && s.euro === e[0], 'CTR.w.soldi.mio=false;CTR.w.soldi.euro=' + e[0], e[1]); }).join('') + ctrOpz(s.mio, 'CTR.w.soldi.mio=true', 'Lo scrivo io') + '</div>'
      + (s.mio ? '<input id="ctrEuroMio" class="fin" type="number" inputmode="numeric" min="0" placeholder="Euro" value="' + s.euro + '">' : '')
      + avanti();
  } else if (p === 'soldi_vecchio'){
    const s = w.soldi;
    h = '<h2 class="ctr-q">Se sgarri, a chi vanno i tuoi soldi?</h2><p class="ctr-qs">Conta un giorno alla volta: più sgarri nello stesso giorno costano una volta sola.</p>'
      + '<div class="ctr-opzl">' + ctrOpz(s.tipo === 'amico', 'CTR.w.soldi.tipo=\'amico\'', 'A un amico che fa da garante') + ctrOpz(s.tipo === 'beneficenza', 'CTR.w.soldi.tipo=\'beneficenza\'', 'In beneficenza') + ctrOpz(s.tipo === 'nessuno', 'CTR.w.soldi.tipo=\'nessuno\'', 'Niente soldi') + '</div>';
    if (s.tipo !== 'nessuno'){
      h += '<label class="ctr-l" for="ctrSoldiA">' + (s.tipo === 'amico' ? 'Come si chiama il tuo amico?' : 'A chi vuoi donare?') + '</label>'
        + '<input id="ctrSoldiA" class="fin" placeholder="' + (s.tipo === 'amico' ? 'Il suo nome' : 'Per esempio: la Croce Rossa della tua città') + '" value="' + ctrEsc(s.a) + '">'
        + '<label class="ctr-l">Quanto per ogni giorno con uno sgarro?</label>'
        + '<div class="ctr-euro">' + [2, 5, 10, 20].map(function(e){ return ctrOpz(!s.mio && s.euro === e, 'CTR.w.soldi.mio=false;CTR.w.soldi.euro=' + e, e + ' €'); }).join('') + ctrOpz(s.mio, 'CTR.w.soldi.mio=true', 'Lo scrivo io') + '</div>'
        + (s.mio ? '<input id="ctrEuroMio" class="fin" type="number" inputmode="numeric" min="1" placeholder="Euro" value="' + s.euro + '">' : '')
        + '<p class="ctr-onesto">I pagamenti non sono ancora collegati: ogni sgarro resta scritto con la sua cifra, senza nessun addebito.' + (s.tipo === 'amico' ? ' Il tuo amico firma il patto dalla sua app.' : '') + '</p>';
    }
    h += avanti();
  } else {
    const nome = (typeof nvNome === 'function' && nvNome()) || '';
    const s = w.soldi;
    const pen = [];
    pen.push('aspetterò prima di cambiare le regole, e ogni volta l’attesa raddoppierà');
    if (w.grigioOre) pen.push('il mio telefono andrà in bianco e nero per ' + ctrDurata(w.grigioOre * 60));
    if (s.tipo !== 'nessuno' && s.euro > 0) pen.push((s.tipo === 'amico' ? s.a + ' riceverà ' : 'donerò ') + s.euro + ' €' + (s.tipo === 'beneficenza' ? ' a ' + s.a : '') + ' per ogni giorno con uno sgarro');
    if (s.tipo === 'amico' && !(s.euro > 0)) pen.push(s.a + ' lo saprà, perché è il mio garante');
    h = '<h2 class="ctr-q">Il tuo contratto</h2>'
      + '<div class="ctr-carta"><p>Io' + (nome ? ', ' + ctrEsc(nome) + ',' : '') + ' ' + ctrEsc(ctrMinuscola(ctrFrase(w.impegno))) + '.</p>'
      + '<p>' + ctrEsc(ctrLimiteTxt(w)) + '.</p>'
      + '<p>Se sgarro, ' + ctrEsc(pen.join('; ')) + '.</p></div>'
      + '<div class="md-row ctr-durata"><span>Quanto dura</span><div class="md-step"><button type="button" onclick="CTR.w.giorni=Math.max(7,CTR.w.giorni-(CTR.w.giorni>30?30:7));ctrWPaint()" aria-label="Meno">−</button><b>' + w.giorni + ' giorni</b><button type="button" onclick="CTR.w.giorni=Math.min(365,CTR.w.giorni+(CTR.w.giorni>=30?30:7));ctrWPaint()" aria-label="Più">+</button></div></div>'
      /* 0.9.337, Andrea: "l'utente deve poterlo firmare: disegnare la firma, o farla firmare all'app, come nei contratti digitali" */
      + '<div class="ctr-firme"><div class="ctr-firma-box"><canvas id="ctrFirmaC" width="600" height="200" aria-label="Firma qui con il dito"></canvas>'
      +   (w.firma ? '' : '<span class="ctr-firma-ph">Firma qui con il dito</span>') + '<i class="ctr-firma-riga"></i><small>' + ctrEsc(nome || 'La tua firma') + '</small></div>'
      +   '<div class="ctr-firma-az"><button type="button" class="am-link" onclick="ctrFirmaAuto()">Firma con il mio nome</button><button type="button" class="am-link" onclick="ctrFirmaCancella()">Cancella</button></div>'
      +   '<div class="ctr-firma-gar"><i>' + ctrEsc(s.a || 'Il tuo garante') + '</i><small>firma del garante, dalla sua app</small></div></div>'
      + '<button type="button" class="am-cta ctr-avanti" id="ctrFirmaBtn"' + (w.firma ? '' : ' disabled') + ' onclick="ctrFirma()">Firma il contratto</button>';
  }
  host.innerHTML = '<div class="ctr-w">' + h + '</div>';
  if (p === 'app') ctrAppLista();
  if (p === 'firma') ctrFirmaPad();
  ctrGenioScena(host);
}
/* LA FIRMA: si disegna con il dito, o la scrive l'app con il nome in corsivo. Resta nel contratto come immagine. */
function ctrFirmaPad(){
  const c = document.getElementById('ctrFirmaC'); if (!c || !CTR.w) return;
  const g = c.getContext('2d');
  if (CTR.w.firma){ const im = new Image(); im.onload = function(){ g.clearRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0); }; im.src = CTR.w.firma; }
  g.lineWidth = 5; g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = '#001E44';
  let giu = false, ultimo = null;
  const pt = function(e){ const r = c.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * c.width, (e.clientY - r.top) / r.height * c.height]; };
  c.addEventListener('pointerdown', function(e){ e.preventDefault(); giu = true; ultimo = pt(e); try{ c.setPointerCapture(e.pointerId); }catch(_){ } const ph = c.parentNode.querySelector('.ctr-firma-ph'); if (ph) ph.remove(); });
  c.addEventListener('pointermove', function(e){ if (!giu) return; const p = pt(e); g.beginPath(); g.moveTo(ultimo[0], ultimo[1]); g.lineTo(p[0], p[1]); g.stroke(); ultimo = p; });
  const fine = function(){ if (!giu) return; giu = false; CTR.w.firma = c.toDataURL('image/png'); const b = document.getElementById('ctrFirmaBtn'); if (b) b.disabled = false; };
  c.addEventListener('pointerup', fine); c.addEventListener('pointercancel', fine);
  c.style.touchAction = 'none';
}
function ctrFirmaAuto(){
  const c = document.getElementById('ctrFirmaC'); if (!c || !CTR.w) return;
  const nome = ((typeof nvNome === 'function' && nvNome()) || 'Io').trim();
  const g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height);
  g.fillStyle = '#001E44'; g.font = 'italic 84px "Caveat","DM Caveat","Segoe Print",cursive'; g.textBaseline = 'middle';
  const w = g.measureText(nome).width; g.fillText(nome, Math.max(20, (c.width - w) / 2), c.height / 2);
  const ph = c.parentNode.querySelector('.ctr-firma-ph'); if (ph) ph.remove();
  CTR.w.firma = c.toDataURL('image/png');
  const b = document.getElementById('ctrFirmaBtn'); if (b) b.disabled = false;
  try{ flVibra(10); }catch(_){ }
}
function ctrFirmaCancella(){ if (!CTR.w) return; CTR.w.firma = ''; ctrWPaint(); }
/* IL GENIO CHE PARLA (0.9.337, Andrea: "i passi del contratto fanno cagare: ci vuole il Genio che parla sul cielo notturno della
   foresta, con le risposte su due colonne e le emoji"). La domanda diventa la sua nuvoletta; le scelte vanno in griglia. */
const CTR_EMO = { 'Neanche un minuto': '🚫', '15 minuti': '⏱️', '30 minuti': '🕧', 'Un’ora': '🕐', 'Lo scrivo io': '✍️', '2 ore': '🌗', '6 ore': '🌘', '12 ore': '🌑', 'Un giorno intero': '📅', 'Niente bianco e nero': '🎨', 'Niente, basta la parola': '🤝', '2 €': '💶', '5 €': '💶', '10 €': '💶', '20 €': '💶' };
function ctrGenioScena(host){
  const q = host.querySelector('.ctr-q'); if (!q || host.querySelector('.ctr-genio')) return;
  const s = host.querySelector('.ctr-qs');
  const box = document.createElement('div'); box.className = 'ctr-genio';
  box.innerHTML = '<img src="img/genio/genio-' + (CTR_PASSI[CTR.passo] === 'firma' ? 'rivela' : 'pensa') + '.png" alt=""><div class="ctr-fum"></div>';
  q.parentNode.insertBefore(box, q);
  const f = box.querySelector('.ctr-fum'); f.appendChild(q); if (s) f.appendChild(s);
  host.querySelectorAll('.ctr-opzl .ctr-opz, .ctr-euro .ctr-opz').forEach(function(b){ const t = b.textContent.trim(); if (CTR_EMO[t] && !b.querySelector('.ctr-e')) b.insertAdjacentHTML('afterbegin', '<span class="ctr-e">' + CTR_EMO[t] + '</span>'); });
}
function ctrMinuscola(t){ t = String(t || ''); return t.charAt(0).toLowerCase() + t.slice(1); }
/** "Aprire Instagram appena sveglio" -> "Mi impegno a non aprire Instagram appena sveglio" (anche se chi scrive comincia con "non" o "smettere di"). */
function ctrFrase(impegno){
  let t = ctrMinuscola(String(impegno || '').trim()).replace(/[.!]+$/, '');
  t = t.replace(/^(non\s+|smettere\s+di\s+|smetto\s+di\s+|basta\s+)/i, '').replace(/^più\s+/i, '');
  return 'Mi impegno a non ' + t;
}

/* le app: prima quelle che blocchi gia', poi tutte */
async function ctrAppCarica(){
  let tutte = [], bloccate = [];
  try{ const r = typeof flApps === 'function' ? await flApps() : null; tutte = ((r && r.apps) || []).filter(function(a){ return a && a.packageName && !a.system && !/^com\.dreambrothers\./.test(a.packageName) && !/focus\s*lock|dream\s*map/i.test(String(a.label || '')); }); }catch(_){ }
  /* 0.9.343, Andrea: "appare FocusLock al posto di DreamMap": il contratto non vale sulla stessa app che lo fa rispettare */
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getRulesFull){ const r = await NATIVE.getRulesFull(); bloccate = (r && r.apps) || []; } }catch(_){ }
  const b = {}; bloccate.forEach(function(p){ b[String(p).toLowerCase()] = 1; });
  tutte.sort(function(x, y){ return (b[y.packageName] || 0) - (b[x.packageName] || 0) || String(x.label).localeCompare(String(y.label)); });
  CTR.appTutte = tutte.map(function(a){ return { p: a.packageName, n: a.label || a.packageName, b: !!b[a.packageName] }; });
  if (CTR_PASSI[CTR.passo] === 'app') ctrAppLista();
}
function ctrAppLista(){
  const host = document.getElementById('ctrAppL'); if (!host || !CTR.w) return;
  if (!CTR.appTutte){ host.innerHTML = '<p class="ctr-carica">Un attimo…</p>'; return; }
  const q = String(CTR.cerca || '').trim().toLowerCase();
  const scelte = {}; CTR.w.apps.forEach(function(a){ scelte[a.p] = 1; });
  const l = CTR.appTutte.filter(function(a){ return !q || a.n.toLowerCase().indexOf(q) >= 0; }).slice(0, 60);
  if (!l.length){ host.innerHTML = '<p class="ctr-carica">' + (CTR.appTutte.length ? 'Nessuna app con questo nome.' : 'Sul telefono qui compaiono le tue app.') + '</p>'; return; }
  /* 0.9.343, Andrea: "le app appaiono senza immagine": l'icona vera, come nell'elenco del blocco */
  host.innerHTML = l.map(function(a){ return '<button type="button" class="ctr-app' + (scelte[a.p] ? ' on' : '') + '" onclick="ctrAppScegli(\'' + ctrEsc(a.p) + '\')"><em class="ub-appico ub-appico-fb ctr-ico">' + ctrEsc((a.n || '?').trim().charAt(0).toUpperCase()) + '<img class="ub-appico ub-appico-img" data-pkg="' + ctrEsc(a.p) + '" alt=""></em><span><b>' + ctrEsc(a.n) + '</b>' + (a.b ? '<small>La blocchi già</small>' : '') + '</span><i aria-hidden="true"></i></button>'; }).join('');
  try{ if (typeof ubFillIcons === 'function') ubFillIcons(host); }catch(_){ }
}
function ctrAppScegli(pkg){
  const w = CTR.w; const i = w.apps.findIndex(function(a){ return a.p === pkg; });
  if (i >= 0) w.apps.splice(i, 1);
  else { const a = (CTR.appTutte || []).filter(function(x){ return x.p === pkg; })[0]; if (a) w.apps.push({ p: a.p, n: a.n }); }
  const y = (document.getElementById('s-contratto-nuovo') || {}).scrollTop || 0;
  ctrWPaint();
  try{ document.getElementById('s-contratto-nuovo').scrollTop = y; const c = document.getElementById('ctrCerca'); if (c && CTR.cerca) c.focus(); }catch(_){ }
}
function ctrAppTogli(pkg){ ctrAppScegli(pkg); }

async function ctrFirma(){
  const w = CTR.w; if (!w) return;
  try{ if (w.firma) localStorage.setItem('fl_firma_mia', w.firma); }catch(_){ }
  const k = { impegno: w.impegno, frase: ctrFrase(w.impegno), apps: w.apps, limiteMin: w.limiteMin, grigioOre: w.grigioOre, giorni: w.giorni,
    soldi: { tipo: 'amico', a: w.soldi.a, euro: w.soldi.euro, tetto: Math.min(500, Math.max(w.soldi.euro, w.soldi.euro * 10)) } };
  try{ CTR.s = await ctrMotore().contrattoFirma({ contratto: k }); }
  catch(e){ toast(String((e && e.message) || 'Il contratto non si è salvato: riprova')); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  CTR.w = null; CTR.passo = 0;
  goId('s-contratto'); ctrPaint();
  toast('Contratto firmato');
  if (k.soldi.tipo !== 'nessuno') await ctrPattoCrea(CTR.s && CTR.s.contratto);
}

/* ---------------------------------------------------------------------------------------
   DOVE SI TROVA: la Protezione (dopo la modalita' severa), la pagina della modalita' severa,
   la schermata di blocco (pulsante "Rileggi il contratto" -> apri "contratto")
   --------------------------------------------------------------------------------------- */
function ctrPortaHtml(){
  const s = CTR.s, on = !!(s && s.attivo);
  const oggi = on ? (s.sgarri || []).filter(function(x){ return x.g === new Date().toISOString().slice(0, 10) || new Date(x.t).toDateString() === new Date().toDateString(); }).length : 0;
  const sub = !on ? 'Scrivi cosa non vuoi più fare e scegli le penitenze se sgarri'
    : (s.grigioFino > Date.now() ? 'Bianco e nero fino alle ' + ctrOra(s.grigioFino) : (oggi ? (oggi === 1 ? 'Oggi hai sgarrato una volta' : 'Oggi hai sgarrato ' + oggi + ' volte') : 'Attivo fino al ' + ctrData((s.contratto || {}).fineAt)));
  return '<button type="button" class="ctr-porta' + (on ? ' on' : '') + '" onclick="ctrApri()"><span class="ctr-emo">' + CTR_ICO + '</span><b>Contratto di abitudine</b><small>' + ctrEsc(sub) + '</small></button>';
}
function ctrPortePaint(){
  ['ctrBlHost', 'ctrSevHost'].forEach(function(id){ const h = document.getElementById(id); if (h) h.innerHTML = ctrPortaHtml(); });
}
function ctrPorteMetti(schermo){
  try{
    /* 0.9.335, Andrea: "il contratto d'abitudine non deve comparire nella sezione della modalita' severa, ma nella sua pagina" */
    if (schermo === 's-blocco'){ const vecchio = document.getElementById('ctrBlHost'); if (vecchio) vecchio.remove(); }
    if (schermo === 's-severa-pagina'){
      const box = document.getElementById('sevTabBox');
      let h = document.getElementById('ctrSevHost');
      if (!h && box && box.parentNode){ h = document.createElement('div'); h.id = 'ctrSevHost'; h.className = 'ctr-porta-host'; box.parentNode.insertBefore(h, box.nextSibling); }
    }
    ctrPortePaint();
  }catch(_){ }
}
document.addEventListener('fl:screen', function(e){
  const id = e && e.detail;
  if (id === 's-blocco' || id === 's-severa-pagina'){ setTimeout(function(){ ctrPorteMetti(id); ctrCarica().then(ctrPortePaint); }, 60); }
  if (id === 's-contratto' && CTR.s) ctrPaint();
});
setTimeout(function(){ ctrCarica().catch(function(){ }); }, 3000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) ctrCarica().then(function(){ if (document.getElementById('s-contratto') && document.getElementById('s-contratto').classList.contains('active')) ctrPaint(); }).catch(function(){ }); });
/* il conto alla rovescia sulla pagina del contratto */
setInterval(function(){
  const el = document.getElementById('ctrStatoConto'), s = CTR.s; if (!el || !s) return;
  const ora = Date.now();
  if (s.attesaFino > ora) el.textContent = ctrConto(s.attesaFino - ora);
  else if (s.finestraFino > ora && s.attesaFino > 0) el.textContent = ctrConto(s.finestraFino - ora);
  else if (el.dataset.f !== '1'){ el.dataset.f = '1'; ctrPaint(); }
  ctrGrigioWeb();
}, 1000);

(function(){
  const css = [
    '#s-contratto .ctr-top,#s-contratto-nuovo .ctr-top{justify-content:space-between}#s-contratto .ctr-top .blk-title,#s-contratto-nuovo .ctr-top .blk-title{flex:1;text-align:center}',
    '.ctr-i{color:var(--muted)}',
    '.ctr-vuota{visibility:hidden}',
    'html.ctr-grigio{filter:grayscale(1)}',
    '.ctr-carica{text-align:center;font:600 13px var(--font-body);color:var(--muted);margin:16px 0}',
    '.ctr-emo{display:inline-grid;place-items:center;width:64px;height:64px;border-radius:50%;background:#fff;box-shadow:0 6px 20px rgba(0,30,68,.12);font-size:32px;line-height:1}',
    '.ctr-emo-scuro{margin-bottom:26px}',
    '.ctr-vuoto{display:flex;flex-direction:column;align-items:center;text-align:center;padding:12px 4px 8px}',
    '.ctr-vuoto h2{margin:20px 0 10px;font:800 24px/1.25 var(--font-display);color:var(--navy);text-wrap:balance}body.dark .ctr-vuoto h2{color:#fff}',
    '.ctr-vuoto > p{margin:0 0 24px;max-width:32ch;font:500 15px/1.5 var(--font-body);color:var(--muted)}',
    '.ctr-cta{width:100%;margin-top:28px}',
    '.ctr-pen{display:flex;flex-direction:column;gap:10px;width:100%}',
    '.ctr-pr{display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line);text-align:left}body.dark .ctr-pr{background:#12203A;border-color:#22345A}',
    '.ctr-pr > i{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;font:800 14px var(--font-body);font-style:normal;color:#0075E3;background:rgba(0,117,227,.1)}body.dark .ctr-pr > i{color:#7CC4FF;background:rgba(124,196,255,.14)}',
    '.ctr-pr b{display:block;font:700 15px/1.35 var(--font-body);color:var(--navy)}body.dark .ctr-pr b{color:#fff}',
    '.ctr-pr small{display:block;margin-top:3px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.ctr-pr.on{border-color:#E63946}.ctr-pr.on > i{color:#fff;background:#E63946}',
    '.ctr-stato{display:flex;flex-direction:column;align-items:center;gap:10px;width:100%;margin:4px 0 22px;padding:22px 18px;border-radius:24px;border:1px solid var(--line);background:var(--card,#fff);text-align:center;cursor:default}body.dark .ctr-stato{background:#12203A;border-color:#22345A}',
    '.ctr-stato small{font:700 13px var(--font-body);color:var(--muted)}.ctr-stato span{font:500 12.5px var(--font-body);color:var(--muted)}.ctr-stato .am-cta{width:100%;margin:4px 0 0}',
    '.ctr-stato.attesa,.ctr-stato.aperta{cursor:pointer;background:linear-gradient(180deg,#0B2A5C,#001E44);border-color:transparent}.ctr-stato.attesa small,.ctr-stato.aperta small,.ctr-stato.attesa span,.ctr-stato.aperta span{color:rgba(220,234,255,.82)}',
    '.ctr-stato b{font:800 40px/1 var(--font-body);color:#2F9BFF;font-variant-numeric:tabular-nums}.ctr-stato.aperta b{color:#7CC4FF}',
    '.ctr-foglio{padding:20px 18px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .ctr-foglio{background:#12203A;border-color:#22345A}',
    '.ctr-eti{display:block;font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}body.dark .ctr-eti{color:#7CC4FF}',
    '.ctr-impegno{margin:12px 0 0;font:800 20px/1.3 var(--font-display);color:var(--navy)}body.dark .ctr-impegno{color:#fff}',
    '.ctr-lim{margin:10px 0 0;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    '.ctr-sez{margin:28px 0 12px;font:800 17px var(--font-display);color:var(--navy);text-align:center}body.dark .ctr-sez{color:#fff}',
    '.ctr-patto{margin-top:12px;padding:14px 16px;border-radius:18px;border:1px dashed var(--line);text-align:center}.ctr-patto p{margin:0 0 8px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.ctr-patto .am-cta{width:100%}',
    '.ctr-nessuno{margin:0;text-align:center;font:500 14px var(--font-body);color:var(--muted)}',
    '.ctr-storico{display:flex;flex-direction:column;gap:8px}',
    '.ctr-sg{padding:14px 16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);border-left:4px solid #E63946;text-align:left}body.dark .ctr-sg{background:#12203A;border-color:#22345A;border-left-color:#E63946}',
    '.ctr-sg b{display:block;font:700 14.5px/1.35 var(--font-body);color:var(--navy)}body.dark .ctr-sg b{color:#fff}',
    '.ctr-sg small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}.ctr-sg .ctr-sg-pen{color:#E63946;font-weight:600}',
    '.ctr-strappa{display:block;margin:32px auto 0;border:0;background:transparent;font:600 14px var(--font-body);color:var(--muted);text-decoration:underline;text-underline-offset:3px;cursor:pointer;padding:10px}',
    '.ctr-velo{position:fixed;inset:0;z-index:9000;background:rgba(0,12,30,.55);display:flex;align-items:flex-end;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s}.ctr-velo.open{opacity:1;pointer-events:auto}body.dark .ctr-velo{background:rgba(0,0,0,.72)}',
    '.ctr-sheet{position:relative;width:100%;max-width:520px;box-sizing:border-box;padding:28px 22px calc(26px + env(safe-area-inset-bottom,0px));border-radius:26px 26px 0 0;background:var(--card,#fff);text-align:center;transform:translateY(30px);transition:transform .25s}.ctr-velo.open .ctr-sheet{transform:none}body.dark .ctr-sheet{background:#12203A}',
    '.ctr-sheet h3{margin:16px 0 18px;font:800 21px var(--font-display);color:var(--navy)}body.dark .ctr-sheet h3{color:#fff}',
    '.ctr-x{position:absolute;top:12px;right:12px;width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}',
    '.ctr-def{margin:0 0 16px}.ctr-def b{display:block;font:700 15px var(--font-body);color:var(--navy)}body.dark .ctr-def b{color:#fff}.ctr-def p{margin:4px auto 0;max-width:34ch;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}',
    '.ctr-foglio-nota{margin:6px 0 0;font:600 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.ctr-w{display:flex;flex-direction:column;gap:16px;align-items:stretch;text-align:center}.ctr-w > .ctr-emo{align-self:center}',
    '.ctr-q{margin:6px 0 0;font:800 24px/1.25 var(--font-display);color:var(--navy);text-align:center;text-wrap:balance}body.dark .ctr-q{color:#fff}',
    /* 0.9.337: il contratto si scrive con il Genio, sul cielo notturno della foresta (come le sue domande), risposte su due colonne */
    '#s-contratto-nuovo{background:linear-gradient(180deg,rgba(6,23,58,.55),rgba(0,19,43,.92) 70%),url(img/dream-night.jpg) center top/cover no-repeat,#001E44!important}',
    '#s-contratto-nuovo .ctr-top .blk-title{color:#fff}#s-contratto-nuovo .ctr-top .iconbtn{background:rgba(255,255,255,.14);color:#fff}#s-contratto-nuovo .ctr-prog{background:rgba(255,255,255,.15)}',
    '.ctr-genio{display:flex;align-items:flex-end;gap:10px;margin:4px 0 18px}.ctr-genio img{flex:none;width:86px;height:auto;filter:drop-shadow(0 8px 18px rgba(140,198,255,.4));animation:ctrGenio 4s ease-in-out infinite}@keyframes ctrGenio{50%{transform:translateY(-6px)}}',
    '.ctr-fum{position:relative;flex:1;min-width:0;padding:14px 16px;border-radius:20px 20px 20px 6px;background:#fff;box-shadow:0 10px 28px rgba(0,0,0,.3)}.ctr-fum .ctr-q{margin:0;font-size:19px;text-align:left;color:#001E44!important}.ctr-fum .ctr-qs{margin:6px 0 0;text-align:left;font-size:13.5px;color:#4A5A75!important}',
    '#s-contratto-nuovo .ctr-opzl{display:grid;grid-template-columns:1fr 1fr;gap:10px}#s-contratto-nuovo .ctr-euro{grid-template-columns:1fr 1fr}#s-contratto-nuovo .ctr-euro .ctr-opz:last-child{grid-column:auto}',
    '#s-contratto-nuovo .ctr-opz{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:84px;padding:12px 8px;border:1.5px solid rgba(188,224,255,.35);background:rgba(255,255,255,.08);color:#fff}#s-contratto-nuovo .ctr-opz.on{background:#F0FBFF;border-color:#0075E3;color:#001E44}',
    '.ctr-e{font-size:26px;line-height:1}#s-contratto-nuovo .ctr-l{color:#BFD3EC}#s-contratto-nuovo .ctr-scala div{background:rgba(255,255,255,.08);color:#fff}#s-contratto-nuovo .ctr-emo{display:none}',
    '#s-contratto-nuovo .ctr-esempi button{background:rgba(255,255,255,.08);color:#fff;border-color:rgba(188,224,255,.35)}',
    /* la firma */
    '.ctr-firme{margin:18px 0 6px;padding:16px;border-radius:20px;background:#FBF8F0;color:#3b2d20}.ctr-firma-box{position:relative;height:120px}.ctr-firma-box canvas{position:absolute;inset:0;width:100%;height:100%;cursor:crosshair}',
    '.ctr-firma-ph{position:absolute;left:0;right:0;top:36px;text-align:center;font:600 14px var(--font-body);color:#8a6a4a;pointer-events:none}.ctr-firma-riga{position:absolute;left:8px;right:8px;bottom:22px;height:1.5px;background:#8a6a4a}',
    '.ctr-firma-box small,.ctr-firma-gar small{position:absolute;left:0;right:0;bottom:0;text-align:center;font:700 11px var(--font-body);letter-spacing:.06em;color:#8a6a4a}.ctr-firma-az{display:flex;justify-content:center;gap:16px;margin:6px 0 10px}',
    '.ctr-firma-gar{position:relative;height:56px;border-top:1px dashed rgba(138,106,74,.4);padding-top:8px;text-align:center}.ctr-firma-gar i{font:500 24px "Caveat","DM Caveat","Segoe Print",cursive;color:#8a6a4a;opacity:.7}',
    '#ctrFirmaBtn[disabled]{opacity:.45}.pat-firma-img{display:block;height:46px;margin:0 auto -4px;object-fit:contain}',
    '.ctr-qs{margin:0;font:500 14.5px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.ctr-campo{min-height:90px;resize:none;margin:0;width:100%;box-sizing:border-box}',
    '.ctr-esempi{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.ctr-esempi button{border:1px dashed var(--line);background:transparent;border-radius:99px;padding:9px 13px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .ctr-esempi button{color:#fff;border-color:#22345A}',
    '.ctr-avanti{margin-top:12px}',
    '.ctr-scelte{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.ctr-scelte button{border:0;border-radius:99px;padding:8px 14px;background:#0075E3;color:#fff;font:700 13px var(--font-body);cursor:pointer}',
    '.ctr-appl{display:flex;flex-direction:column;gap:8px;max-height:46vh;overflow:auto;padding:2px}',
    '.ctr-app{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:13px 14px;border-radius:14px;border:1.5px solid var(--line);background:var(--card,#fff);cursor:pointer}body.dark .ctr-app{background:#12203A;border-color:#22345A}',
    '.ctr-app .ctr-ico{flex:none;width:40px;height:40px;border-radius:10px;font-style:normal;overflow:hidden}',
    '.ctr-app span{flex:1}.ctr-app b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .ctr-app b{color:#fff}.ctr-app small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.ctr-app i{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--line)}.ctr-app.on{border-color:#0075E3}.ctr-app.on i{border-color:#0075E3;background:#0075E3 url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27%3E%3Cpath d=%27M6 12l4 4 8-8%27 fill=%27none%27 stroke=%27white%27 stroke-width=%273%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27/%3E%3C/svg%3E") center/16px no-repeat}',
    '.ctr-opzl{display:flex;flex-direction:column;gap:10px}.ctr-euro{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.ctr-euro .ctr-opz{padding:12px 4px;font-size:14px}.ctr-euro .ctr-opz:last-child{grid-column:1/-1}',
    '.ctr-opz{width:100%;padding:15px 16px;border-radius:16px;border:1.5px solid var(--line);background:var(--card,#fff);font:700 15px var(--font-body);color:var(--navy);cursor:pointer;text-align:center}body.dark .ctr-opz{background:#12203A;border-color:#22345A;color:#fff}',
    '.ctr-opz.on{border-color:#0075E3;background:rgba(0,117,227,.1);color:#0075E3}body.dark .ctr-opz.on{color:#7CC4FF;border-color:#3F9FF4;background:rgba(63,159,244,.16)}',
    '.ctr-l{display:block;margin:6px 0 -6px;font:700 13.5px var(--font-body);color:var(--navy);text-align:center}body.dark .ctr-l{color:#fff}',
    '.ctr-w input.fin{margin:0;width:100%;box-sizing:border-box;text-align:center}',
    '.ctr-avviso{padding:14px 16px;border-radius:16px;background:rgba(230,57,70,.08);border:1px solid rgba(230,57,70,.35)}.ctr-avviso p{margin:0 0 6px;font:600 13.5px/1.45 var(--font-body);color:var(--navy)}body.dark .ctr-avviso p{color:#fff}',
    '.ctr-onesto{margin:4px 0 0;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);font:500 12.5px/1.45 var(--font-body);color:var(--muted)}body.dark .ctr-onesto{background:#0F1B33}',
    '.ctr-scala{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.ctr-scala > div{padding:12px 4px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .ctr-scala > div{background:#12203A;border-color:#22345A}',
    '.ctr-scala b{display:block;font:800 22px var(--font-body);color:#0075E3}body.dark .ctr-scala b{color:#7CC4FF}.ctr-scala small{display:block;font:600 11.5px var(--font-body);color:var(--muted)}.ctr-scala i{display:block;margin-top:4px;font:600 10.5px var(--font-body);font-style:normal;color:var(--muted)}',
    '.ctr-scala .ctr-scala-fine{grid-column:span 2;border-color:#E63946}.ctr-scala .ctr-scala-fine b{color:#E63946}',
    '.ctr-carta{padding:22px 20px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .ctr-carta{background:#12203A;border-color:#22345A}.ctr-carta p{margin:0 0 12px;font:500 15px/1.6 var(--font-body);color:var(--navy)}body.dark .ctr-carta p{color:#fff}.ctr-carta p:first-child{font:700 17px/1.5 var(--font-body)}.ctr-carta p:last-child{margin:0}',
    '.ctr-durata{margin:0}',
    '.ctr-firma{margin-top:16px}',
    '.ctr-porta-host{margin:18px 0 6px}#ctrBlHost{margin:-8px 18px 24px}',
    '.ctr-porta{display:flex;flex-direction:column;align-items:center;gap:6px;width:100%;padding:20px 18px;border-radius:22px;border:1px solid var(--line);background:var(--card,#fff);text-align:center;cursor:pointer}body.dark .ctr-porta{background:#12203A;border-color:#22345A}',
    '.ctr-porta .ctr-emo{width:52px;height:52px;font-size:26px;margin-bottom:6px}.ctr-porta b{font:800 17px var(--font-display);color:var(--navy)}body.dark .ctr-porta b{color:#fff}.ctr-porta small{font:500 13px/1.4 var(--font-body);color:var(--muted);max-width:30ch}',
    '.ctr-porta.on{border-color:#0075E3}',
    '#ctrA{min-height:100%;display:flex}#ctrA > .ef{flex:1}',
    '.ctr-stato-giu{margin:28px 0 0}.ctr-chiedi{width:100%;min-height:52px;border:1.5px solid #0075E3;border-radius:26px;background:transparent;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}body.dark .ctr-chiedi{color:#7CC4FF;border-color:#3F9FF4}',
    '#s-contratto-attesa{padding:0!important;background:linear-gradient(180deg,#0B2A5C 0%,#001E44 38%,#00132D 100%)}',
    '.ctr-a .ef-anello > span{display:flex;align-items:center;justify-content:center}.ctr-a-dentro{display:flex;flex-direction:column;align-items:center}.ctr-a-dentro .ef-tempo{margin:0}.ctr-a-dentro small{margin-top:8px;font:600 13px var(--font-body);color:rgba(220,234,255,.75)}',
    '.ctr-a .ctr-a-pross{margin-top:16px;font-size:14px;color:rgba(220,234,255,.6)}',
    '.ctr-stampa{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:52px;margin:24px 0 8px;border:1.5px solid #0075E3;border-radius:26px;background:transparent;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}body.dark .ctr-stampa{color:#7CC4FF;border-color:#3F9FF4}',
    '.ctr-attesa-g{display:flex;flex-direction:column;align-items:center;gap:10px;margin:8px 0 22px;padding:24px 20px;border-radius:22px;background:linear-gradient(180deg,#0B2A5C,#001E44);color:#fff;text-align:center}',
    '.ctr-attesa-g .ctr-emo{width:56px;height:56px;font-size:28px;margin-bottom:4px}.ctr-attesa-g b{font:800 18px/1.35 var(--font-display);color:#fff}.ctr-attesa-g p{margin:0 0 6px;font:500 14px/1.5 var(--font-body);color:#BCE0FF}.ctr-attesa-g .am-cta{margin-top:6px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
