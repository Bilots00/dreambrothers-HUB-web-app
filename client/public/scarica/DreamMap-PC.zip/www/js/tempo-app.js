/* ===========================================================================================
   IL TEMPO DENTRO DREAMMAP

   Il Report sa dire "40 minuti in DreamMap", e la Timeline mette DreamMap in fila come
   un'app qualunque. Ma quaranta minuti di Full Focus e quaranta minuti di giochi col Genio
   sono due giornate opposte, e da fuori sembrano la stessa. Qui si registra dove va il tempo
   DENTRO l'app: quale scheda, quale pagina, quale attivita', con l'ora d'inizio e di fine.
   Cosi' l'utente non si racconta storie ("sono stato un'ora su DreamMap, ho lavorato") e il
   Genio e l'agente sanno esattamente dove va il tempo.

   COME SI CONTA
     · solo con l'app davanti e lo schermo visibile (visibilitychange);
     · l'area si legge dal sistema delle schermate: fl:screen, fl:tab, la schermata corrente
       (order[cur]), i veli che non sono schermate (la chat dell'agente, il diario) e, nella
       scena del Genio, GN.modo (giochi, episodi, revisione, rientro, respiro);
     · dopo 2 minuti senza tocchi, scorrimenti o tasti si smette di contare, a meno che sia
       acceso il Full Focus (li' stare fermi e' proprio il lavoro);
     · una schermata che non conosciamo non si perde: finisce in "Altro nell'app" col suo id.

   DOVE STA: localStorage 'fl_tempo_app', per giorno, segmenti [inizio, fine, area] in secondi
   dalla mezzanotte. 35 giorni, poi si buttano. Niente rete.
   =========================================================================================== */

const TA_KEY = 'fl_tempo_app';
const TA_GIORNI = 35;
const TA_IDLE = 120000;            // due minuti senza toccare niente = non stai usando l'app
const TA_UNISCI = 10;              // secondi: due pezzi della stessa area cosi' vicini sono uno
const TA_MIN = 3;                  // secondi: sotto, era un passaggio, non un uso
const TA_MAX_PEZZI = 900;          // per giorno

/* Le otto categorie: sono le linguette del Report e i colori della Timeline. */
const TA_CAT = {
  lavoro:      { id: 'lavoro',      l: 'Lavoro sul sogno', ic: '🎯', col: '#0075E3' },
  pianificare: { id: 'pianificare', l: 'Pianificare',      ic: '🗺️', col: '#3F9FF4' },
  giochi:      { id: 'giochi',      l: 'Giochi',           ic: '🎮', col: '#FFD66B' },
  imparare:    { id: 'imparare',    l: 'Imparare',         ic: '🎓', col: '#8CC6FF' },
  riflettere:  { id: 'riflettere',  l: 'Riflettere',       ic: '🪞', col: '#5B9BE8' },
  sistemare:   { id: 'sistemare',   l: 'Sistemare l\'app', ic: '🛠️', col: '#9AB8DE' },
  social:      { id: 'social',      l: 'Social',           ic: '💬', col: '#B9DBFF' },
  altro:       { id: 'altro',       l: 'Altro',            ic: '📱', col: '#C8D3E3' }
};

/* Le aree. l = come si chiama nella Timeline; c = categoria; nel = "30 minuti ___";
   cosa = "Niente ___ prima delle 18" (solo per quello che si puo' tagliare: il lavoro no). */
const TA_AREE = {
  fullfocus:    { l: 'Full Focus', c: 'lavoro', nel: 'in Full Focus' },
  roadmap:      { l: 'Roadmap', c: 'lavoro', nel: 'sulla Roadmap' },
  note:         { l: 'Note', c: 'lavoro', nel: 'nelle note' },
  notion:       { l: 'Piano in Notion', c: 'lavoro', nel: 'nel piano in Notion' },
  dream:        { l: 'Scheda Sogno', c: 'pianificare', nel: 'nella scheda Sogno' },
  mappa:        { l: 'La Mappa', c: 'pianificare', nel: 'sulla Mappa' },
  esercizi:     { l: 'Esercizi della Mappa', c: 'pianificare', nel: 'negli esercizi della Mappa' },
  start:        { l: 'START, il piano del giorno', c: 'pianificare', nel: 'su START' },
  foglio:       { l: 'Il foglio del giorno', c: 'pianificare', nel: 'sul foglio del giorno' },
  agente:       { l: 'Chat con l\'agente', c: 'pianificare', nel: 'a parlare con l\'agente' },
  giochi:       { l: 'Giochi col Genio', c: 'giochi', nel: 'nei giochi col Genio', cosa: 'giochi col Genio' },
  academy:      { l: 'Academy', c: 'imparare', nel: 'nelle lezioni dell\'Academy' },
  aiuto:        { l: 'Guida e aiuto', c: 'imparare', nel: 'nella guida' },
  episodi:      { l: 'Episodi del Genio', c: 'riflettere', nel: 'negli episodi del Genio' },
  revisione:    { l: 'Revisione col Genio', c: 'riflettere', nel: 'nella revisione col Genio' },
  rientro:      { l: 'Rientro col Genio', c: 'riflettere', nel: 'nel rientro col Genio' },
  genio:        { l: 'Il Genio', c: 'riflettere', nel: 'col Genio' },
  oracolo:      { l: 'L\'Oracolo', c: 'riflettere', nel: 'con l\'Oracolo' },
  iofuturo:     { l: 'Io futuro', c: 'riflettere', nel: 'con l\'Io futuro' },
  diario:       { l: 'Diario di viaggio', c: 'riflettere', nel: 'nel diario di viaggio' },
  umore:        { l: 'Umore', c: 'riflettere', nel: 'nella pagina dell\'umore' },
  respiro:      { l: 'Respiro', c: 'riflettere', nel: 'negli esercizi di respiro' },
  partita:      { l: 'La partita', c: 'riflettere', nel: 'nella partita' },
  report:       { l: 'Report e Timeline', c: 'riflettere', nel: 'a guardare Report e Timeline', cosa: 'giri nel Report' },
  musica:       { l: 'Scelta della musica', c: 'sistemare', nel: 'a scegliere la musica', cosa: 'giri fra le musiche' },
  personalizza: { l: 'Personalizzare le schede', c: 'sistemare', nel: 'a personalizzare le schede', cosa: 'ritocchi alle schede' },
  impostazioni: { l: 'Impostazioni', c: 'sistemare', nel: 'nelle impostazioni', cosa: 'giri nelle impostazioni' },
  blocchi:      { l: 'Blocchi e limiti', c: 'sistemare', nel: 'a sistemare i blocchi' },
  social:       { l: 'Amici, sfide e lega', c: 'social', nel: 'fra amici, sfide e lega', cosa: 'giri fra amici, sfide e lega' },
  profilo:      { l: 'Profilo', c: 'altro', nel: 'nel profilo', cosa: 'giri nel profilo' },
  primoavvio:   { l: 'Primo avvio', c: 'altro', nel: 'nel primo avvio' }
};

/* Le schede della barra in basso (fl:tab) */
const TA_SCHEDE = { rotta: 'dream', mappa: 'mappa', severa: 'roadmap', sveglia: 'start', insights: 'report', profilo: 'profilo', blocco: 'blocchi' };

/* Le schermate conosciute. Quello che non c'e' qui passa dalle regole per prefisso, poi da "Altro". */
const TA_SCHERMI = {
  's-fullfocus': 'fullfocus', 's-ff-done': 'fullfocus', 's-ff-forest': 'fullfocus',
  's-severa-pagina': 'roadmap', 's-romguide': 'roadmap', 's-levels': 'roadmap',
  's-note': 'note', 's-caveau': 'note', 's-caveau-pag': 'note',
  's-notion': 'notion',
  's-esercizio': 'esercizi', 's-viaggio-opz': 'mappa', 's-orizzonti': 'mappa', 's-catena': 'mappa',
  's-notes': 'foglio', 's-riga': 'foglio', 's-foglio-imp': 'impostazioni',
  's-agente': 'agente', 's-agente-canali': 'impostazioni', 's-agente-consumi': 'impostazioni',
  's-oracolo': 'oracolo', 's-rimpianto': 'genio', 's-why': 'genio', 's-identita': 'genio',
  's-visualization': 'genio', 's-memento': 'genio', 's-inspire': 'genio', 's-film': 'genio', 's-consenso-genio': 'genio',
  's-academy': 'academy', 's-academy-mod': 'academy', 's-lesson': 'academy', 's-dopamina-scopri': 'academy',
  's-dopamina-info': 'academy', 's-eta-info': 'academy',
  's-guida': 'aiuto', 's-aiuto': 'aiuto', 's-aiuto-video': 'aiuto', 's-help': 'aiuto', 's-trouble': 'aiuto', 's-feedback': 'aiuto',
  's-dv-nota': 'diario',
  's-umore-chat': 'umore', 's-umore-info': 'umore', 's-umore-imp': 'impostazioni',
  's-respiro': 'respiro',
  's-match': 'partita', 's-partita': 'partita', 's-punti': 'partita', 's-score': 'partita', 's-scorelook': 'partita',
  's-dopamina': 'genio', 's-eta': 'roadmap', 's-ricomincia': 'genio', 's-rientro': 'rientro', 's-passi': 'mappa',
  's-timeline': 'report', 's-ins-app': 'report', 's-ins-cat': 'report', 's-repstat': 'report',
  's-suoni': 'musica', 's-alarm-audio': 'musica', 's-m369': 'genio',
  's-personalize': 'personalizza', 's-costruisci': 'personalizza', 's-start-cst': 'personalizza', 's-slideimg': 'personalizza',
  's-modelli': 'personalizza', 's-fbimp': 'personalizza',
  's-friends': 'social', 's-group': 'social', 's-partner': 'social', 's-sfide-dream': 'social', 's-profilo-pubblico': 'social',
  's-blocco': 'blocchi', 's-blocchi': 'blocchi', 's-quick': 'blocchi', 's-blocklist': 'blocchi', 's-editor': 'blocchi',
  's-newtype': 'blocchi', 's-qlist': 'blocchi', 's-lockpacks': 'blocchi', 's-restricted': 'blocchi', 's-emergency': 'blocchi',
  's-bq-eser': 'blocchi', 's-silenzio': 'blocchi', 's-nd': 'blocchi', 's-assenze': 'blocchi', 's-onething': 'blocchi', 's-waiting': 'blocchi',
  's-profilo-modifica': 'profilo'
};

/* Nella scena del Genio la pagina e' una sola: a dire cosa si sta facendo e' GN.modo. */
const TA_GENIO = { ak: 'giochi', dq: 'episodi', rv: 'revisione', rn: 'rientro', rs: 'respiro' };

function taPerPrefisso(id){
  if (/^s\d+$/.test(id) || id === 's-partenza') return 'primoavvio';
  if (id.indexOf('sev-') === 0) return 'roadmap';
  if (id.indexOf('s-sd-') === 0) return 'mappa';
  if (id.indexOf('s-amici') === 0) return 'social';
  if (id.indexOf('s-iofuturo') === 0) return 'iofuturo';
  if (id.indexOf('s-grey') === 0 || id.indexOf('s-rep') === 0 || id.indexOf('s-prof-') === 0 || id.indexOf('s-alarm') === 0) return 'impostazioni';
  if (/^s-(settings|inapp|notifs|account|backup|blockprefs|cats|lockscreen|a11y-disclosure|ue-legal|about|alarms|bell|reset|qr)$/.test(id)) return 'impostazioni';
  return '';
}

/** Le informazioni di un'area. Quelle sconosciute ("x:s-qualcosa") restano visibili col loro id. */
function taArea(id){
  if (TA_AREE[id]) return Object.assign({ id: id }, TA_AREE[id]);
  if (String(id).indexOf('x:') === 0) return { id: id, l: 'Altro nell\'app (' + String(id).slice(2) + ')', c: 'altro', nel: 'in altre pagine dell\'app' };
  return { id: id, l: 'Altro nell\'app', c: 'altro', nel: 'in altre pagine dell\'app' };
}
function taCat(id){ return TA_CAT[id] || TA_CAT.altro; }

/* ---------------------------------------------------------------------------------------
   DOVE SEI ADESSO
   --------------------------------------------------------------------------------------- */
function taFFAcceso(){
  try{ return typeof FF !== 'undefined' && FF && !!FF.run; }catch(_){ return false; }
}
function taSchermo(){
  try{ return (typeof order !== 'undefined' && typeof cur !== 'undefined') ? (order[cur] || '') : ''; }catch(_){ return ''; }
}
function taAreaOra(){
  if (taFFAcceso()) return 'fullfocus';
  /* i veli che non sono schermate */
  if (document.getElementById('agPop')) return 'agente';
  if (document.getElementById('dvBook')) return 'diario';
  const id = taSchermo();
  if (!id) return '';
  if (id === 's-home'){
    let t = TA.tab;
    if (!t){ try{ t = localStorage.getItem('fl_tab') || ''; }catch(_){ t = ''; } }
    return TA_SCHEDE[t] || ('x:tab-' + (t || '?'));
  }
  if (id === 's-genio'){
    let m = '';
    try{ m = (typeof GN !== 'undefined' && GN) ? (GN.modo || '') : ''; }catch(_){ }
    return TA_GENIO[m] || 'genio';
  }
  if (TA_SCHERMI[id]) return TA_SCHERMI[id];
  return taPerPrefisso(id) || ('x:' + id);
}

/* ---------------------------------------------------------------------------------------
   IL REGISTRO
   --------------------------------------------------------------------------------------- */
const TA = { seg: null, slot: null, ultimoTocco: Date.now(), tab: '', db: null, tick: null, potato: '' };

function taK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function taMezzanotte(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }

function taDb(){
  if (TA.db) return TA.db;
  let db = null;
  try{ db = JSON.parse(localStorage.getItem(TA_KEY) || 'null'); }catch(_){ db = null; }
  if (!db || typeof db !== 'object' || !db.d) db = { v: 1, d: {} };
  TA.db = db;
  taPota();
  return db;
}
function taScrivi(){
  try{ localStorage.setItem(TA_KEY, JSON.stringify(TA.db)); }catch(_){ }
}
/** Via i giorni oltre i 35: una volta al giorno basta. */
function taPota(){
  const oggi = taK(Date.now());
  if (TA.potato === oggi || !TA.db) return;
  TA.potato = oggi;
  const limite = taK(Date.now() - TA_GIORNI * 86400000);
  Object.keys(TA.db.d).forEach(function(k){ if (k < limite) delete TA.db.d[k]; });
}

/** Scrive (o aggiorna) il pezzo aperto. Un pezzo che scavalca la mezzanotte si spezza. */
function taRegistra(fine){
  const s = TA.seg; if (!s) return;
  const db = taDb();
  const mezz = taMezzanotte(s.s);
  if (fine > mezz + 86400000){
    /* la mezzanotte: si chiude il giorno vecchio e il resto riparte da zero */
    taRegistra(mezz + 86400000 - 1);
    TA.seg = { a: s.a, s: mezz + 86400000 };
    TA.slot = null;
    taRegistra(fine);
    return;
  }
  const k = taK(s.s);
  const a = Math.floor((s.s - mezz) / 1000), b = Math.floor((fine - mezz) / 1000);
  if (b - a < TA_MIN && !TA.slot) return;
  const giorno = db.d[k] || (db.d[k] = []);
  if (TA.slot && TA.slot.k === k && giorno[TA.slot.i] && giorno[TA.slot.i][2] === s.a){
    giorno[TA.slot.i][1] = Math.max(giorno[TA.slot.i][1], b);
  } else {
    const ult = giorno[giorno.length - 1];
    if (ult && ult[2] === s.a && a - ult[1] <= TA_UNISCI){
      ult[1] = Math.max(ult[1], b);
      TA.slot = { k: k, i: giorno.length - 1 };
    } else {
      if (giorno.length >= TA_MAX_PEZZI) return;
      giorno.push([a, b, s.a]);
      TA.slot = { k: k, i: giorno.length - 1 };
    }
  }
  taScrivi();
}

function taChiudi(fine){
  if (!TA.seg) return;
  taRegistra(Math.max(TA.seg.s, fine || Date.now()));
  TA.seg = null; TA.slot = null;
}

/** Il cuore: guarda dove sei e se stai usando l'app, e tiene il registro allineato. */
function taValuta(){
  const ora = Date.now();
  const visibile = !document.hidden;
  const ff = taFFAcceso();
  const fermo = !ff && (ora - TA.ultimoTocco) > TA_IDLE;
  if (!visibile || fermo){
    if (TA.seg) taChiudi(fermo ? Math.min(ora, TA.ultimoTocco + TA_IDLE) : ora);
    return;
  }
  const area = taAreaOra();
  if (!area){ if (TA.seg) taChiudi(ora); return; }
  if (TA.seg && TA.seg.a === area){ taRegistra(ora); return; }
  if (TA.seg) taChiudi(ora);
  TA.seg = { a: area, s: ora };
  TA.slot = null;
}

function taTocco(){
  const eraFermo = (Date.now() - TA.ultimoTocco) > TA_IDLE;
  TA.ultimoTocco = Date.now();
  if (eraFermo || !TA.seg) taValuta();
}

/* ---------------------------------------------------------------------------------------
   LA LETTURA (Timeline, Report, Genio, agente, Taglia)
   --------------------------------------------------------------------------------------- */
/** I pezzi fra due istanti, in millisecondi veri: [{ s, e, a }]. */
function taPezzi(from, to){
  try{ if (TA.seg && !document.hidden) taRegistra(Date.now()); }catch(_){ }
  const db = taDb(), out = [];
  let t = taMezzanotte(from);
  while (t < to){
    const giorno = db.d[taK(t)] || [];
    giorno.forEach(function(p){
      const s = t + p[0] * 1000, e = t + p[1] * 1000;
      if (e <= from || s >= to) return;
      out.push({ s: Math.max(s, from), e: Math.min(e, to), a: p[2] });
    });
    t = taMezzanotte(t + 36 * 3600000);
  }
  out.sort(function(x, y){ return x.s - y.s; });
  return out;
}
/** Quanto per area e per categoria, ordinato per tempo. */
function taRiassunto(from, to){
  const pezzi = taPezzi(from, to);
  const mappa = {}, cat = {};
  let tot = 0;
  pezzi.forEach(function(p){
    const ms = p.e - p.s; if (ms <= 0) return;
    const ar = taArea(p.a);
    if (!mappa[p.a]) mappa[p.a] = { id: p.a, l: ar.l, c: ar.c, ms: 0, n: 0, ore: [] };
    mappa[p.a].ms += ms; mappa[p.a].n++; mappa[p.a].ore.push(new Date(p.s).getHours());
    cat[ar.c] = (cat[ar.c] || 0) + ms;
    tot += ms;
  });
  const perArea = Object.keys(mappa).map(function(k){ return mappa[k]; }).sort(function(a, b){ return b.ms - a.ms; });
  const perCat = Object.keys(cat).map(function(k){ return { id: k, l: taCat(k).l, ms: cat[k] }; }).sort(function(a, b){ return b.ms - a.ms; });
  return { tot: tot, pezzi: pezzi, perArea: perArea, perCat: perCat, cat: cat };
}
function taGiornoDa(off){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (off || 0)); return d.getTime(); }
function taDelGiorno(off){ const f = taGiornoDa(off); return taRiassunto(f, f + 86400000); }

function taMin(ms){
  const m = Math.round((ms || 0) / 60000);
  if (m < 1) return 'meno di un minuto';
  if (m < 60) return m + ' min';
  const h = Math.floor(m / 60), r = m % 60;
  return h + (h === 1 ? ' ora' : ' ore') + (r ? ' e ' + r + ' min' : '');
}

/** Per il Genio e per l'agente: dove e' andato il tempo dentro l'app, oggi (o ieri, se oggi e' vuoto). */
function taPerAgente(){
  let r = taDelGiorno(0), quando = 'Oggi';
  if (r.tot < 60000){ r = taDelGiorno(1); quando = 'Ieri'; }
  if (r.tot < 60000) return '';
  const top = r.perArea.filter(function(a){ return a.ms >= 60000; }).slice(0, 5)
    .map(function(a){ return a.l + ' ' + Math.round(a.ms / 60000) + ' min'; });
  const lavoro = Math.round((r.cat.lavoro || 0) / 60000);
  return quando + ' dentro DreamMap ' + Math.round(r.tot / 60000) + ' min: ' + top.join(', ')
    + '. Di questi, lavoro vero sul sogno ' + lavoro + ' min.';
}

/* ---------------------------------------------------------------------------------------
   GLI AGGANCI
   --------------------------------------------------------------------------------------- */
if (typeof document !== 'undefined'){
  ['pointerdown', 'touchstart', 'keydown', 'wheel'].forEach(function(ev){
    document.addEventListener(ev, taTocco, { capture: true, passive: true });
  });
  document.addEventListener('scroll', taTocco, { capture: true, passive: true });
  /* un tocco puo' aprire un velo (la chat dell'agente, il diario) o cambiare GN.modo: si
     riguarda poco dopo, quando la pagina ha finito di cambiare */
  document.addEventListener('click', function(){ setTimeout(taValuta, 120); }, true);
  document.addEventListener('fl:screen', function(){ setTimeout(taValuta, 0); });
  document.addEventListener('fl:tab', function(e){ TA.tab = (e && e.detail) || TA.tab; setTimeout(taValuta, 0); });
  document.addEventListener('visibilitychange', function(){
    if (!document.hidden) TA.ultimoTocco = Date.now();
    taValuta();
  });
  window.addEventListener('pagehide', function(){ taChiudi(Date.now()); });
  TA.tick = setInterval(taValuta, 15000);
  setTimeout(taValuta, 1500);

  /* Al tuo agente personale e al Genio: la stessa riga, accodata alle uscite di rotta come fanno gli altri. */
  setTimeout(function(){
    try{
      if (typeof rnPerAgente === 'function' && !rnPerAgente.__ta){
        const v = rnPerAgente;
        const w = function(){ return [v.apply(this, arguments), taPerAgente()].filter(Boolean).join(' '); };
        w.__ta = true; Object.keys(v).forEach(function(k){ if (k !== '__ta') w[k] = v[k]; });
        window.rnPerAgente = w;
      }
    }catch(_){ }
  }, 0);
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { TA_AREE: TA_AREE, TA_CAT: TA_CAT, taArea: taArea, taCat: taCat, taPerPrefisso: taPerPrefisso };
}
