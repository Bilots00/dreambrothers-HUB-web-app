/* ===========================================================================================
   IL TUO PERCHÉ — la pagina dietro la bolla della Modalità severa.

   L'immagine di chi si vuole diventare (con le immagini scelte in passato, per tornarci in un
   tocco), un mantra di una riga, e sotto delle sezioni separate, con aria intorno, dove
   scrivere chi si vuole essere e cosa si farà per arrivarci: righe di testo, elenchi puntati
   e caselle da spuntare, come nelle note del telefono.

   Tutto quello che si tocca qui è una BOZZA finché non si preme Salva: uscire con la freccia
   lascia le cose come erano. Tutto resta in localStorage; niente lascia il telefono.
   =========================================================================================== */

const WHY_KEY = 'fl_why_notes';
const WHY_IMGS_KEY = 'fl_why_imgs';       // the pictures chosen so far, newest first, at most 6
const WHY_DEFAULT = {
  mantra: '',
  sections: [
    { id: 'who', title: 'Chi voglio diventare', items: [{ t: 'p', text: '', done: false }] },
    // Prima di quello che si farà viene quello a cui si rinuncia: è la parte che costa, ed è
    // la parte che decide. I suggerimenti sotto arrivano da dove il tempo se ne va davvero.
    { id: 'give', title: 'A cosa rinuncio per arrivarci', items: [{ t: 'c', text: '', done: false }] },
    { id: 'how', title: 'Cosa farò per arrivarci', items: [{ t: 'c', text: '', done: false }] },
    { id: 'memo', title: 'Promemoria', items: [{ t: 'b', text: '', done: false }] }
  ]
};
let WHY = null;          // what is saved
let WHY_D = null;        // the draft being edited
let WHY_IMG = null;      // the draft picture: null = untouched, '' = removed, 'data:…' = chosen

function whyLoad(){
  if (WHY) return WHY;
  try{ WHY = JSON.parse(localStorage.getItem(WHY_KEY) || 'null'); }catch(_){ WHY = null; }
  if (!WHY || !Array.isArray(WHY.sections)) WHY = JSON.parse(JSON.stringify(WHY_DEFAULT));
  // chi aveva già scritto le sue sezioni prima di questa versione se la trova al posto giusto,
  // vuota, senza perdere niente di quello che aveva scritto
  if (!WHY.sections.some(x => x.id === 'give')){
    const at = WHY.sections.findIndex(x => x.id === 'how');
    WHY.sections.splice(at < 0 ? Math.min(1, WHY.sections.length) : at, 0,
      { id: 'give', title: 'A cosa rinuncio per arrivarci', items: [{ t: 'c', text: '', done: false }] });
  }
  return WHY;
}
function whyMantra(){ const w = whyLoad(); return (w.mantra || '').trim(); }
function whyImgs(){ try{ const v = JSON.parse(localStorage.getItem(WHY_IMGS_KEY) || '[]'); return Array.isArray(v) ? v : []; }catch(_){ return []; } }
function whyImgsRemember(src){
  if (!src) return;
  const list = whyImgs().filter(x => x !== src);
  list.unshift(src);
  while (list.length > 6) list.pop();
  try{ localStorage.setItem(WHY_IMGS_KEY, JSON.stringify(list)); }
  catch(_){ try{ localStorage.setItem(WHY_IMGS_KEY, JSON.stringify(list.slice(0, 3))); }catch(__){ } }
}
function whyCurrentImg(){
  if (WHY_IMG !== null) return WHY_IMG;
  return typeof sevFaceGet === 'function' ? sevFaceGet() : '';
}
function whyDirty(){
  return WHY_IMG !== null || JSON.stringify(WHY_D) !== JSON.stringify(whyLoad());
}

registerScreen('s-why', `
  <div class="topbar"><button class="iconbtn" onclick="whyBack()">‹</button><b class="blk-title">Il tuo perché</b></div>
  <div class="why-top">
    <button type="button" class="sev-face why-face" id="whyFace" onclick="whyPick()" aria-label="Immagine"></button>
    <button type="button" class="ghostmini why-facebtn" id="whyFaceBtn" onclick="whyPick()">Scegli immagine</button>
    <button type="button" class="acc-av-x" id="whyFaceX" onclick="whyClear()">Togli l'immagine</button>
    <div class="why-gallery" id="whyGallery"></div>
  </div>
  <div class="why-card">
    <label class="why-lbl">Il mantra della versione futura di te</label>
    <input class="fin why-mantra" id="whyMantra" maxlength="140" placeholder="es. Sono una persona che finisce quello che inizia" autocomplete="off" oninput="whyMantraSet(this.value)">
    <small class="why-hint">Una riga: compare sotto la bolla in Modalità severa e, se vuoi, ogni tanto sullo schermo (Personalizza).</small>
  </div>
  <div class="why-card why-mod">
    <b class="why-mod-h">Scrivi chi diventi</b>
    <p class="why-mod-p">Scegli un modello: si apre come una pagina di Notion, e la riempi tu.</p>
    <button type="button" class="why-mod-r" onclick="whyModello('dreamlife')"><span class="why-mod-e">✨</span><span class="why-mod-t"><b>Dream Life · Vision Board</b><small>Una giornata della tua vita dei sogni, con le immagini</small></span><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>
    <button type="button" class="why-mod-r" onclick="whyModello('futurose')"><span class="why-mod-e">🪞</span><span class="why-mod-t"><b>Il mio io futuro</b><small>Le abitudini e le convinzioni di chi diventi</small></span><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>
  </div>
  <div class="why-card why-sugg" id="whySugg" hidden></div>
  <div id="whySections"></div>
  <div class="spacer"></div>
  <button class="cta" onclick="whySaveAll()">Salva</button>
`, { back: function(){ return whyBack() ? 's-home' : 's-why'; } });

function whyOpen(){
  WHY_D = JSON.parse(JSON.stringify(whyLoad()));
  WHY_IMG = null;
  goId('s-why');
  whyPaintFace();
  const m = document.getElementById('whyMantra'); if (m) m.value = WHY_D.mantra || '';
  whyPaint();
}
function whyBack(){
  if (WHY_D && whyDirty() && !confirm('Uscire senza salvare? Le modifiche di questa pagina andranno perse.')) return false;
  WHY_D = null; WHY_IMG = null;
  if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); switchTab('severa'); }
  return true;
}
function whySaveAll(){
  const m = document.getElementById('whyMantra');
  if (m) WHY_D.mantra = String(m.value || '').trim().slice(0, 140);
  WHY = JSON.parse(JSON.stringify(WHY_D));
  try{ localStorage.setItem(WHY_KEY, JSON.stringify(WHY)); }catch(_){ }
  if (WHY_IMG !== null){
    try{
      if (WHY_IMG){ localStorage.setItem(SEV_FACE_KEY, WHY_IMG); whyImgsRemember(WHY_IMG); }
      else localStorage.removeItem(SEV_FACE_KEY);
    }catch(_){ toast('Immagine troppo grande per questo telefono'); }
  }
  // the service shows the mantra on screen (Personalizza > Mantra sullo schermo)
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings){ try{ NATIVE.setSettings({ mantraText: whyMantra() }); }catch(_){ } }
  WHY_D = null; WHY_IMG = null;
  toast('Salvato');
  goId('s-home'); switchTab('severa');
  if (typeof sevSyncTab === 'function') sevSyncTab();
  if (typeof lvBump === 'function') lvBump();
}

/* ---- the picture and its history ---- */
function whyPaintFace(){
  const f = document.getElementById('whyFace'), x = document.getElementById('whyFaceX'), b = document.getElementById('whyFaceBtn');
  const src = whyCurrentImg();
  if (f){ f.style.backgroundImage = src ? 'url(' + src + ')' : ''; f.classList.toggle('has', !!src); f.innerHTML = src ? '' : '<span class="ic">✛</span>'; }
  if (x) x.hidden = !src;
  if (b) b.textContent = src ? 'Cambia immagine' : 'Scegli immagine';
  const g = document.getElementById('whyGallery');
  if (g){
    const list = whyImgs().filter(s => s !== src);
    g.innerHTML = list.length ? '<small>Scelte in passato</small><div class="why-thumbs">' + list.map((s, i) =>
      '<button type="button" class="why-thumb" style="background-image:url(' + s + ')" onclick="whyUse(' + i + ')" aria-label="Usa questa immagine"></button>').join('') + '</div>' : '';
  }
}
function whyPick(){
  if (typeof flImgPick !== 'function') return;
  flImgPick('fl_why_img_tmp', function(out){
    WHY_IMG = out || '';
    try{ localStorage.removeItem('fl_why_img_tmp'); }catch(_){ }
    whyPaintFace();
  }, true);
}
function whyUse(i){
  const src = whyCurrentImg();
  const list = whyImgs().filter(s => s !== src);
  if (list[i]){ WHY_IMG = list[i]; whyPaintFace(); }
}
function whyClear(){ WHY_IMG = ''; whyPaintFace(); }
function whyMantraSet(v){ if (WHY_D) WHY_D.mantra = String(v || '').slice(0, 140); }

/* ---- the sections and their rows (all on the draft) ---- */
/* 0.9.296, Andrea: "togli i blocchi personalizzati, voglio un pannello che porta alla replica di Notion coi modelli".
   Le sezioni scritte fino a qui non si perdono: se c'e' del testo resta leggibile in fondo, chiuso. */
function whyModello(k){
  const f = document.getElementById('ntFrame');
  if (!f || typeof NT === 'undefined') return;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  NT.schermo = 's-why';
  const w = f.contentWindow;
  if (NT.pronto && /notion\/index\.html/.test(f.getAttribute('src') || '') && w && typeof w.flNotionModello === 'function'){
    NT.aperto = true; goId('s-notion'); try{ w.flNotionModello(k); }catch(_){ }
    return;
  }
  f.setAttribute('src', 'notion/index.html?v=' + Date.now() + '#modello=' + k);
  NT.pronto = true; NT.aperto = true;
  goId('s-notion');
}
function whyRinuncia(i){
  const x = WHY_SUGG && WHY_SUGG[i];
  if (!x || !WHY_D) return;
  const l = Array.isArray(WHY_D.rinunce) ? WHY_D.rinunce : (WHY_D.rinunce = []);
  const at = l.indexOf(x.name);
  if (at >= 0) l.splice(at, 1); else l.push(x.name);
  whySuggPaint(WHY_SUGG);
}
function whyPaint(){
  const host = document.getElementById('whySections'); if (!host || !WHY_D) return;
  const scritte = WHY_D.sections.map(s => ({ t: s.title, r: s.items.filter(it => (it.text || '').trim()) })).filter(s => s.r.length);
  host.innerHTML = scritte.length
    ? '<details class="why-card why-vecchie"><summary>Quello che avevi scritto qui</summary>'
      + scritte.map(s => '<b>' + esc(s.t || 'Senza titolo') + '</b><ul>' + s.r.map(it => '<li>' + esc(it.text) + '</li>').join('') + '</ul>').join('')
      + '</details>'
    : '';
  whySuggest();
}
function whyPaintVecchia(){
  const host = document.getElementById('whySections'); if (!host || !WHY_D) return;
  host.innerHTML = WHY_D.sections.map((s, si) =>
    '<div class="why-card why-sec" data-si="' + si + '">'
    + '<div class="why-sechead"><input class="why-title" value="' + esc(s.title) + '" maxlength="40" placeholder="Titolo della sezione" oninput="whyTitle(' + si + ', this.value)">'
    + '<button type="button" class="why-del" onclick="whyDelSection(' + si + ')" aria-label="Elimina la sezione">×</button></div>'
    + '<div class="why-rows">' + s.items.map((it, ii) => whyRowHtml(si, ii, it)).join('') + '</div>'
    /* 0.9.295, Andrea: "rifai la pagina Il tuo perche'". Sotto ogni sezione un solo "Aggiungi": i tre tipi di riga
       compaiono quando servono, non tre pulsanti per sezione sempre accesi. */
    + '<div class="why-adds"><button type="button" class="why-piu" onclick="this.parentElement.classList.toggle(\'aperto\')">＋ Aggiungi</button><span class="why-tipi"><button type="button" onclick="whyAdd(' + si + ',\'p\')">Testo</button><button type="button" onclick="whyAdd(' + si + ',\'b\')">Elenco</button><button type="button" onclick="whyAdd(' + si + ',\'c\')">Casella</button></span></div>'
    + (s.id === 'give' ? '<div class="why-sugg" id="whySugg" data-si="' + si + '"><small>Dove se ne va il tuo tempo</small><div class="why-chips">Leggo…</div></div>' : '')
    + '</div>').join('');
  whySuggest();
}

/* ---- i suggerimenti: le app e i siti che ti stanno mangiando le ore ----------------------

   L'ordine non è il mio, è il tuo: prima quello che hai segnato come distrazione nel Report,
   poi il resto, e dentro ogni gruppo chi ti ha preso più tempo negli ultimi sette giorni.
   Toccare un suggerimento scrive una riga nella sezione, che resta modificabile come le altre. */
let WHY_SUGG = null;
async function whySuggest(){
  const host = document.getElementById('whySugg');
  if (!host) return;
  if (WHY_SUGG){ whySuggPaint(WHY_SUGG); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps){ host.hidden = true; return; }
  const to = Date.now(), from = to - 7 * 86400000;
  const out = [];
  try{
    const cats = (typeof insCats === 'function') ? insCats() : {};
    const top = await NATIVE.getTopApps({ from: from, to: to, limit: 14, icons: 12 });
    (top.apps || []).forEach(a => {
      if (a.self || a.launcher) return;   // noi stessi e la schermata Home non sono una rinuncia
      out.push({ name: a.label || a.packageName, ms: a.ms || 0, distr: cats[a.packageName] === 'distr', icon: a.icon || '' });
    });
  }catch(_){ }
  try{
    if (NATIVE.getWebTime){
      const w = await NATIVE.getWebTime({ from: from, to: to, bucket: 'none', limit: 6 });
      (w.sites || []).forEach(x => out.push({ name: x.host, ms: x.ms || 0, distr: false, site: true }));
    }
  }catch(_){ }
  out.sort((a, b) => (b.distr ? 1 : 0) - (a.distr ? 1 : 0) || b.ms - a.ms);
  WHY_SUGG = out.slice(0, 10);
  whySuggPaint(WHY_SUGG);
}
function whySuggPaint(list){
  const host = document.getElementById('whySugg');
  if (!host) return;
  if (!list.length){ host.hidden = true; return; }
  host.hidden = false;
  const fmt = ms => (typeof scFmtShort === 'function') ? scFmtShort(ms) : Math.round(ms / 60000) + 'min';
  const via = (WHY_D && Array.isArray(WHY_D.rinunce)) ? WHY_D.rinunce : [];
  const GLOBO = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>';
  host.innerHTML = '<b class="why-mod-h">Dove se ne va il tuo tempo</b><p class="why-mod-p">Negli ultimi 7 giorni. Tocca quello a cui rinunci per arrivarci.</p><div class="why-chips">'
    + list.map((x, i) => '<button type="button" class="why-sug' + (x.distr ? ' distr' : '') + (via.indexOf(x.name) >= 0 ? ' via' : '') + '" onclick="whyRinuncia(' + i + ')">'
        + (x.icon ? '<img class="why-sug-ico" src="' + x.icon + '" alt="">' : '<span class="why-sug-ico">' + (x.site ? GLOBO : esc((x.name || '?').charAt(0))) + '</span>')
        + '<span class="why-sug-n">' + esc(x.name) + '</span><i>' + fmt(x.ms) + '</i></button>').join('')
    + '</div>';
}
function whySuggAdd(i){
  const x = WHY_SUGG && WHY_SUGG[i];
  if (!x || !WHY_D) return;
  const si = WHY_D.sections.findIndex(sec => sec.id === 'give');
  if (si < 0) return;
  const sec = WHY_D.sections[si];
  const text = 'Rinuncio a ' + x.name;
  if (sec.items.some(it => it.text === text)){ toast('C\'è già'); return; }
  const empty = sec.items.findIndex(it => !it.text.trim());
  if (empty >= 0){ sec.items[empty] = { t: 'c', text: text, done: false }; }
  else sec.items.push({ t: 'c', text: text, done: false });
  whyPaint();
}
function whyRowHtml(si, ii, it){
  const lead = it.t === 'c'
    ? '<input type="checkbox" class="why-chk"' + (it.done ? ' checked' : '') + ' onchange="whyDone(' + si + ',' + ii + ', this.checked)">'
    : (it.t === 'b' ? '<span class="why-bullet"></span>' : '<span class="why-nolead"></span>');
  return '<div class="why-row t-' + it.t + (it.done ? ' done' : '') + '">' + lead
    + '<input class="why-in" value="' + esc(it.text) + '" placeholder="' + (it.t === 'c' ? 'Cosa devi fare' : (it.t === 'b' ? 'Un punto' : 'Scrivi…')) + '"'
    + ' oninput="whyText(' + si + ',' + ii + ', this.value)" onkeydown="return whyKey(event,' + si + ',' + ii + ')">'
    + '<button type="button" class="why-type" onclick="whyCycle(' + si + ',' + ii + ')" aria-label="Cambia tipo">' + (it.t === 'c' ? '☐' : (it.t === 'b' ? '•' : '¶')) + '</button>'
    + '</div>';
}
function whyTitle(si, v){ WHY_D.sections[si].title = v; }
function whyText(si, ii, v){ WHY_D.sections[si].items[ii].text = v; }
function whyDone(si, ii, on){ WHY_D.sections[si].items[ii].done = !!on; const row = document.querySelector('.why-sec[data-si="' + si + '"] .why-row:nth-child(' + (ii + 1) + ')'); if (row) row.classList.toggle('done', !!on); }
function whyAdd(si, t, at){
  const s = WHY_D.sections[si];
  const idx = typeof at === 'number' ? at : s.items.length;
  s.items.splice(idx, 0, { t: t, text: '', done: false });
  whyPaint(); whyFocus(si, idx);
}
function whyCycle(si, ii){ const it = WHY_D.sections[si].items[ii]; it.t = it.t === 'p' ? 'b' : (it.t === 'b' ? 'c' : 'p'); whyPaint(); whyFocus(si, ii); }
function whyFocus(si, ii){ const row = document.querySelector('.why-sec[data-si="' + si + '"] .why-row:nth-child(' + (ii + 1) + ') .why-in'); if (row){ row.focus(); try{ row.setSelectionRange(row.value.length, row.value.length); }catch(_){ } } }
/* Enter adds a row of the same kind under this one; Backspace on an empty row removes it,
   like the phone's notes do. */
function whyKey(ev, si, ii){
  const s = WHY_D.sections[si], it = s.items[ii];
  if (ev.key === 'Enter'){ ev.preventDefault(); if (!it.text.trim() && it.t !== 'p'){ it.t = 'p'; whyPaint(); whyFocus(si, ii); return false; } whyAdd(si, it.t, ii + 1); return false; }
  if (ev.key === 'Backspace' && !ev.target.value && s.items.length > 1){ ev.preventDefault(); s.items.splice(ii, 1); whyPaint(); whyFocus(si, Math.max(0, ii - 1)); return false; }
  return true;
}
function whyAddSection(){ WHY_D.sections.push({ id: 's' + Date.now(), title: '', items: [{ t: 'p', text: '', done: false }] }); whyPaint(); const t = document.querySelectorAll('.why-title'); if (t.length) t[t.length - 1].focus(); }
function whyDelSection(si){ const s = WHY_D.sections; if (s.length <= 1){ toast('Almeno una sezione resta'); return; } if (!confirm('Eliminare questa sezione e le sue righe?')) return; s.splice(si, 1); whyPaint(); }

(function whyStyle(){
  const css = [
    '.why-top{text-align:center;padding:6px 0 18px}',
    '.why-face{background-color:var(--blue)}',
    '.why-facebtn{display:block;margin:14px auto 0}',
    '.why-gallery{margin-top:14px}',
    '.why-gallery small{display:block;font:700 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:8px}',
    '.why-thumbs{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}',
    '.why-thumb{width:52px;height:52px;border-radius:50%;border:2px solid var(--line);background:#0A1A2F center/cover no-repeat;cursor:pointer;padding:0}',
    '.why-card{background:#fff;border:1px solid var(--line);border-radius:20px;padding:22px 20px;margin:0 0 22px}',
    '.why-lbl{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin-bottom:10px}',
    '.why-mantra{width:100%;margin:0;font:600 15px var(--font-body)}',
    '.why-hint{display:block;margin-top:8px;font:500 11.5px var(--font-body);color:var(--faint)}',
    '.why-sechead{display:flex;align-items:center;gap:8px;margin-bottom:12px}',
    '.why-title{flex:1;min-width:0;border:0;background:none;font:800 16.5px var(--font-display);color:var(--navy);outline:none;padding:0;text-overflow:ellipsis}',
    '.why-del{width:30px;height:30px;border-radius:50%;border:1px solid var(--line);background:#fff;color:var(--faint);font:600 16px/1 var(--font-body);cursor:pointer}',
    '.why-rows{display:flex;flex-direction:column;gap:6px}',
    '.why-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:12px}',
    '.why-row:focus-within{background:#F3F6FB}',
    '.why-in{flex:1;border:0;background:none;font:500 15px var(--font-body);color:var(--navy);outline:none;padding:4px 0;min-width:0}',
    '.why-row.done .why-in{text-decoration:line-through;color:var(--faint)}',
    '.why-chk{width:20px;height:20px;margin:0;accent-color:var(--blue);flex:none}',
    '.why-bullet{width:7px;height:7px;border-radius:50%;background:var(--navy);flex:none;margin:0 6px}',
    '.why-nolead{width:8px;flex:none}',
    '.why-type{border:0;background:none;color:var(--faint);font:600 15px/1 var(--font-body);cursor:pointer;width:28px;flex:none}',
    '.why-adds{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}',
    '.why-adds button{border:1px solid var(--line);background:#fff;border-radius:99px;padding:8px 13px;font:700 12px var(--font-body);color:var(--blue);cursor:pointer}',
    '.why-addsec{width:100%;margin:0}',
    '.why-sugg{margin-top:18px;padding-top:16px;border-top:1px dashed var(--line)}',
    '.why-sugg[hidden]{display:none}',
    '.why-sugg > small{display:block;font:700 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:10px}',
    '.why-chips{display:flex;flex-wrap:wrap;gap:8px}',
    '.why-sug{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--line);background:#fff;border-radius:99px;',
    '  padding:9px 13px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}',
    '.why-sug i{font-style:normal;font-weight:700;color:var(--muted);font-size:11px}',
    '.why-sug.distr{border-color:var(--red);color:var(--red)}.why-sug.distr i{color:var(--red);opacity:.75}',
    'body.dark .why-sug{background:#12203A;border-color:#22345A;color:#fff}',
    'body.dark .why-card,body.dark .why-del,body.dark .why-adds button{background:#12203A;border-color:#22345A}',
    'body.dark .why-title,body.dark .why-in{color:#fff}body.dark .why-row:focus-within{background:#0E1B33}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function(){
  /* 0.9.295: Il tuo perche' rifatto. L'immagine grande in cima, il mantra in evidenza, le sezioni come fogli puliti: il
     titolo grande a tutta riga, le righe senza cornici, un "Aggiungi" solo. */
  const st = document.createElement('style');
  st.textContent = '#s-why .why-top{display:flex;flex-direction:column;align-items:center;gap:10px;margin:4px 0 18px}'
    + '#s-why .why-face{width:132px;height:132px;border-radius:32px;background-size:cover;background-position:center;box-shadow:0 14px 34px rgba(0,30,68,.2)}'
    + '#s-why .why-card{border-radius:22px;padding:18px 16px;margin:0 0 14px}'
    + '#s-why .why-lbl{display:block;text-align:center;margin-bottom:10px}'
    + '#s-why .why-mantra{text-align:center;font:700 16px var(--font-display)}'
    + '#s-why .why-hint{display:block;text-align:center;margin-top:8px}'
    + '#s-why .why-sechead{display:flex;align-items:center;gap:8px;margin-bottom:8px}'
    + '#s-why .why-title{flex:1;min-width:0;border:0;background:transparent;font:800 18px/1.3 var(--font-display);color:var(--navy);padding:4px 0;text-overflow:ellipsis}'
    + '#s-why .why-del{flex:none;width:32px;height:32px;border:0;border-radius:50%;background:transparent;color:var(--faint);font-size:20px;cursor:pointer}'
    + '#s-why .why-adds{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:10px}'
    + '#s-why .why-piu{border:0;background:none;color:#0075E3;font:800 14px var(--font-body);padding:6px 0;cursor:pointer}'
    + '#s-why .why-tipi{display:none;gap:8px}#s-why .why-adds.aperto .why-tipi{display:inline-flex}'
    + '#s-why .why-tipi button{border:1.5px solid var(--line);border-radius:99px;background:var(--card);color:var(--navy);font:700 13px var(--font-body);padding:7px 12px;cursor:pointer}'
    + '#s-why .why-addsec{display:block;margin:4px auto 0;border:1.5px dashed var(--line);border-radius:16px;background:transparent;color:#0075E3;font:800 14px var(--font-body);padding:13px;width:100%}';
  document.head.appendChild(st);
})();

(function(){
  /* 0.9.296, Andrea: "l'immagine torna rotonda, non quadrata". Il pannello dei modelli e' l'elemento primario
     della pagina; il tempo e le cose scritte prima restano sotto, piu' piccoli. */
  const st = document.createElement('style');
  st.textContent = '#s-why .why-face{border-radius:50%!important}'
    + '#s-why .why-mod{padding:18px 16px 8px}'
    + '#s-why .why-mod-h{display:block;font:800 18px var(--font-display);color:var(--navy)}'
    + '#s-why .why-mod-p{margin:4px 0 12px;font:500 13.5px/1.4 var(--font-body);color:var(--muted)}'
    + '#s-why .why-mod-r{display:flex;align-items:center;gap:12px;width:100%;padding:14px 4px;border:0;border-top:1px solid var(--line);background:none;color:var(--faint);text-align:left;cursor:pointer}'
    + '#s-why .why-mod-e{flex:none;width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;background:var(--blue-soft,#E6F2FF)}'
    + '#s-why .why-mod-t{flex:1;min-width:0}#s-why .why-mod-t b{display:block;font:800 15.5px var(--font-display);color:var(--navy)}#s-why .why-mod-t small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted)}'
    + '#s-why .why-sugg{margin-top:0;border-top:1px solid var(--line)}'
    + '#s-why .why-sug{gap:7px;padding:6px 12px 6px 6px}'
    + '#s-why .why-sug-ico{flex:none;width:22px;height:22px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;background:var(--blue-soft,#E6F2FF);color:var(--navy);font:800 11px var(--font-body);object-fit:cover}'
    + '#s-why .why-sug.via{border-color:#E5515F;background:rgba(229,81,95,.08)}#s-why .why-sug.via .why-sug-n{text-decoration:line-through;color:#E5515F}'
    + '#s-why .why-vecchie{padding:14px 16px}#s-why .why-vecchie summary{font:700 14px var(--font-body);color:var(--muted);cursor:pointer}'
    + '#s-why .why-vecchie b{display:block;margin:12px 0 4px;font:800 14px var(--font-display);color:var(--navy)}#s-why .why-vecchie ul{margin:0;padding-left:18px;font:500 14px/1.45 var(--font-body);color:var(--navy)}'
    + 'body.dark #s-why .why-mod-e,body.dark #s-why .why-sug-ico{background:#1B2C4D;color:#fff}body.dark #s-why .why-sug.via{background:rgba(229,81,95,.16)}';
  document.head.appendChild(st);
})();
