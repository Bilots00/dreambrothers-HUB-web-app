/* ===========================================================================================
   IL TABELLONE DEI PIANI — giorni con il piano contro giorni senza

   Il tabellone della prima diapositiva dice chi sta vincendo la partita. Questo dice DA COSA
   dipende quel punteggio: quante volte hai chiuso la giornata avendo deciso l'unica cosa del
   giorno dopo, e quante volte no.

   Perché sono due tabelloni e non uno. Il primo è il risultato — e un risultato si subisce.
   Questo è la causa, ed è l'unica riga di tutta l'app su cui si può fare qualcosa stasera,
   in trenta secondi, scrivendo una frase. Metterli nella stessa diapositiva voleva dire
   chiedere di leggere quattro numeri in una schermata che si guarda per due secondi.

   LA SERIE STA QUI, NON LÌ. «7 giorni di fila con il piano» era una didascalia sotto al
   punteggio della partita, dove non c'entrava niente: la serie è dei piani, e appartiene al
   tabellone dei piani. E accanto ai giorni di fila c'è il record della serie NERA — i giorni
   di fila senza piano — perché anche quella è una serie, e sapere qual è stata la più lunga
   è l'unico modo di accorgersi quando ci si sta rientrando.
   =========================================================================================== */

const PB_TFS = [[7, 'Ultimi 7 giorni'], [30, 'Ultimi 30 giorni'], [90, 'Ultimi 3 mesi'],
                [365, 'Quest\'anno'], [0, 'Da sempre']];

function pbTf(){
  try{ const v = +localStorage.getItem('fl_pb_tf'); return PB_TFS.some(x => x[0] === v) ? v : 30; }
  catch(_){ return 30; }
}
function pbSetTf(v){
  try{ localStorage.setItem('fl_pb_tf', String(v)); }catch(_){ }
  pbMenuClose();
  pbPaint();
}
function pbTfLabel(){
  const v = pbTf();
  return (PB_TFS.filter(function(x){ return x[0] === v; })[0] || PB_TFS[1])[1];
}

/* ---------------------------------------------------------------------------------------
   I conti

   Il registro dei piani è una mappa «giorno → 1». I giorni SENZA piano non ci sono scritti —
   e non potrebbero esserci, perché un giorno senza piano non produce nessun gesto da salvare.
   Si contano quindi camminando all'indietro sul calendario, dal primo giorno in cui l'app
   esiste: ogni casella vuota è un giorno perso davvero, non un buco nei dati.
   --------------------------------------------------------------------------------------- */

function pbGiorno(d){
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function pbPrimoGiorno(){
  const t = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0;
  /* Il ripiego a trenta giorni non e' innocuo: fa contare come «persi» trenta giorni in cui
     l'app non c'era. Si usa solo se la data del primo avvio non si sa proprio. */
  return new Date(t || (Date.now() - 30 * 86400000));
}

/* LA STESSA DOMANDA CHE FA L'ARBITRO, con la stessa risposta: mtPlanned() sa leggere sia i
   segni nuovi sia quelli scritti prima della correzione del registro. Leggere la mappa a mano
   qui voleva dire raccontare una settimana diversa da quella del tabellone accanto. */
function pbPianificato(giorno){
  if (typeof mtPlanned === 'function') return mtPlanned(giorno);
  try{ return !!mtRead(MT_PLAN, {})[giorno]; }catch(_){ return false; }
}

/* ---------------------------------------------------------------------------------------
   UN GIORNO IN ROTTA

   Questa diapositiva contava i giorni in cui il piano del giorno dopo era stato scritto la
   sera prima. Ma scrivere un piano non e' averlo fatto: la sera si puo' scrivere qualunque
   cosa, e il giorno dopo restare fermi. Quello che tiene in piedi la rotta e' un'altra cosa,
   piu' dura da barare: aver portato a termine ALMENO UNA cosa della giornata DENTRO a una
   sessione di concentrazione. Un giorno cosi' e' un giorno in rotta; tutti gli altri no.
   --------------------------------------------------------------------------------------- */

/** Le sessioni di concentrazione riuscite di un giorno, come intervalli. */
function pbSessioni(giorno){
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const a = new Date(giorno + 'T00:00:00').getTime();
  if (isNaN(a)) return [];
  const b = a + 86400000;
  return h.filter(function(x){ return x && x.ok && x.at >= a && x.at < b; })
          .map(function(x){ const fine = x.at; return { s: x.start || (fine - (x.min || 25) * 60000), e: fine }; });
}

/** Le cose spuntate in un giorno, con l'ora in cui sono state spuntate. */
function pbSpunte(giorno){
  try{
    const d = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
    return d.filter(function(x){ return x && x.day === giorno && x.at; });
  }catch(_){ return []; }
}

/** Almeno una cosa portata a termine dentro a una sessione di concentrazione. */
function pbInRotta(giorno){
  const ss = pbSessioni(giorno);
  if (!ss.length) return false;
  const sp = pbSpunte(giorno);
  if (!sp.length) return false;
  /* mezz'ora di tolleranza dopo la fine: si spunta quando ci si alza, non al secondo esatto */
  return sp.some(function(x){
    return ss.some(function(f){ return x.at >= f.s && x.at <= f.e + 30 * 60000; });
  });
}

function pbConti(){
  const tf = pbTf();
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const primo = pbPrimoGiorno(); primo.setHours(0, 0, 0, 0);

  /* Il periodo non può cominciare prima del primo giorno dell'app: contare come «persi» i
     giorni in cui l'app non c'era ancora sarebbe una bugia, e una bugia che demoralizza. */
  let da = new Date(oggi);
  if (tf > 0) da.setDate(da.getDate() - (tf - 1));
  else da = new Date(primo);
  if (da < primo) da = new Date(primo);

  let con = 0, senza = 0;
  /* Oggi non si conta mai fra i persi: la giornata non è finita. */
  for (let d = new Date(da); d < oggi; d.setDate(d.getDate() + 1)){
    if (pbInRotta(pbGiorno(d))) con++; else senza++;
  }
  if (pbInRotta(pbGiorno(oggi))) con++;

  /* Le due serie, camminando all'indietro da ieri: quella viva e la più lunga mai fatta. */
  let serieCon = 0, serieSenza = 0, recCon = 0, recSenza = 0, curCon = 0, curSenza = 0;
  const ieri = new Date(oggi); ieri.setDate(ieri.getDate() - 1);
  for (let d = new Date(primo); d <= ieri; d.setDate(d.getDate() + 1)){
    if (pbInRotta(pbGiorno(d))){ curCon++; curSenza = 0; }
    else { curSenza++; curCon = 0; }
    if (curCon > recCon) recCon = curCon;
    if (curSenza > recSenza) recSenza = curSenza;
  }
  serieCon = curCon; serieSenza = curSenza;
  if (pbInRotta(pbGiorno(oggi))){ serieCon++; serieSenza = 0; if (serieCon > recCon) recCon = serieCon; }

  return { con: con, senza: senza, serieCon: serieCon, serieSenza: serieSenza,
           recCon: recCon, recSenza: recSenza };
}

/* ---------------------------------------------------------------------------------------
   La diapositiva
   --------------------------------------------------------------------------------------- */

function pbMenuClose(){
  const m = document.getElementById('pbMenu');
  if (m) m.remove();
  const v = document.getElementById('pbVeil');
  if (v) v.remove();
}

function pbMenuOpen(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('pbMenu')){ pbMenuClose(); return; }
  const box = document.getElementById('stPlanBox');
  if (!box) return;
  const v = document.createElement('div');
  v.id = 'pbVeil';
  v.className = 'arb-veil';
  v.addEventListener('click', function(e){ e.stopPropagation(); pbMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(v);
  const m = document.createElement('div');
  m.className = 'arb-menu';
  m.id = 'pbMenu';
  m.innerHTML = '<p class="arb-mtit">Periodo</p>' + PB_TFS.map(function(t){
    return '<button type="button" class="' + (t[0] === pbTf() ? 'on' : '') + '" onclick="pbSetTf(' + t[0] + ')">'
      + t[1] + '</button>';
  }).join('');
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.pb-per, .pb-dots'));
}

function pbPaint(){
  const box = document.getElementById('stPlanBox');
  if (!box) return;
  const c = pbConti();

  const t1 = 'I giorni chiusi senza portare a termine niente dentro a una sessione di concentrazione.\n\n'
    + 'Serie nera in corso: ' + c.serieSenza + (c.serieSenza === 1 ? ' giorno' : ' giorni') + '.\n'
    + 'La più lunga mai fatta: ' + c.recSenza + (c.recSenza === 1 ? ' giorno' : ' giorni') + '.';
  const t2 = 'I giorni in cui hai chiuso almeno una cosa dentro a una sessione di concentrazione.\n\n'
    + 'Serie in corso: ' + c.serieCon + (c.serieCon === 1 ? ' giorno' : ' giorni') + '.\n'
    + 'Il tuo record: ' + c.recCon + (c.recCon === 1 ? ' giorno' : ' giorni') + '.';

  box.innerHTML =
      '<p class="mt-eyebrow sev-rise" style="--d:.1s">Da cosa dipende</p>'
    + '<h2 class="mt-title sev-rise" style="--d:.22s">La tua rotta</h2>'
    + '<div class="pf-opal mt-board">'
    +   '<div class="pf-stat sev-rise" style="--d:.5s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t1)) + ')">'
    +     '<span class="ico glow-red">🌑</span><b class="num red">' + c.senza + '</b><small>FERMO<i class="q">i</i></small></div>'
    +   '<div class="mt-dash sev-rise" style="--d:.62s">–</div>'
    +   '<div class="pf-stat sev-rise" style="--d:.74s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t2)) + ')">'
    +     '<span class="ico glow-neo">🚀</span><b class="num neo">' + c.con + '</b><small>IN ROTTA<i class="q">i</i></small></div>'
    + '</div>'
    + '<p class="mt-line sev-rise" style="--d:.9s">'
    +   (c.serieCon
        ? '<b>' + c.serieCon + (c.serieCon === 1 ? ' giorno' : ' giorni') + '</b> di fila in rotta'
        : (c.serieSenza
            ? '<b>' + c.serieSenza + (c.serieSenza === 1 ? ' giorno' : ' giorni') + '</b> di fila fermo. Basta una sessione.'
            : 'La serie comincia con la prima sessione.'))
    /* IL PERIODO SI TOCCA QUI. Era un pulsante a tre puntini in cima alla diapositiva, cioe'
       lontano dall'unica cosa che cambiava; adesso e' la parola stessa che dice qual e'. */
    +   ' · <button type="button" class="pb-per" onclick="pbMenuOpen(event)">'
    +   esc(pbTfLabel().toLowerCase()) + ' ▾</button></p>';
}

/* ---------------------------------------------------------------------------------------
   LE NOTTI CON IL PIANO SCRITTO — la diapositiva che era sparita

   Chi ha il Premium il piano non lo scrive: glielo fa l'agente, e la sua unica cosa e'
   eseguirlo. Chi non ce l'ha se lo scrive la sera prima, e quella e' la sua abitudine da
   tenere: la si conta qui, notte per notte. Chi sviluppa la vede sempre, per controllarla.
   --------------------------------------------------------------------------------------- */
function stPianoVisibile(){
  try{
    if (typeof FL_DEBUG_PREMIUM !== 'undefined' && FL_DEBUG_PREMIUM) return true;
    if (typeof Premium !== 'undefined' && Premium && typeof Premium.isPremium === 'function') return !Premium.isPremium();
  }catch(_){ }
  return true;
}
function stPianoConti(){
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const primo = pbPrimoGiorno(); primo.setHours(0, 0, 0, 0);
  /* la sera di X si scrive il piano di X+1: il giorno «pianificato» e' quello con il piano */
  let serie = 0, rec = 0, cur = 0, tot = 0;
  for (let d = new Date(primo); d <= oggi; d.setDate(d.getDate() + 1)){
    if (pbPianificato(pbGiorno(d))){ cur++; tot++; if (cur > rec) rec = cur; }
    else if (d < oggi){ cur = 0; }
    /* oggi senza piano non rompe la serie: la sera non e' ancora arrivata */
  }
  serie = cur;
  return { serie: serie, rec: rec, tot: tot, oggi: pbPianificato(pbGiorno(oggi)) };
}
function stPianoPaint(){
  const box = document.getElementById('stPianoBox');
  if (!box) return;
  const c = stPianoConti();
  box.innerHTML =
      '<p class="mt-eyebrow sev-rise" style="--d:.1s">La sera prima</p>'
    + '<h2 class="mt-title sev-rise" style="--d:.22s">Il piano scritto</h2>'
    + '<div class="pf-opal mt-board">'
    +   '<div class="pf-stat sev-rise" style="--d:.5s"><span class="ico glow-neo">\ud83d\udcdd</span><b class="num neo">' + c.serie + '</b><small>NOTTI DI FILA</small></div>'
    +   '<div class="mt-dash sev-rise" style="--d:.62s">\u00b7</div>'
    +   '<div class="pf-stat pb-primato sev-rise" data-cg-no style="--d:.74s"><span class="ico">\ud83c\udfc5</span><b class="num">' + c.rec + '</b><small>RECORD</small></div>'
    + '</div>'
    + '<p class="mt-line sev-rise" style="--d:.9s">'
    +   (c.oggi ? 'Il piano di domani e\u2019 gi\u00e0 scritto.' : 'Stasera, prima di dormire: l\u2019unica cosa di domani.')
    +   ' <b>' + c.tot + (c.tot === 1 ? ' giorno' : ' giorni') + '</b> con il piano, da quando l\u2019app c\u2019\u00e8.</p>';
}

(function pbStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* .pb-dots NON si tocca: e' nata qui ma adesso la usano la mappa e la Timeline, che i
       tre puntini ce li hanno ancora — e li' sono al loro posto, in cima a una pagina. */
    '.pb-dots{position:absolute;top:0;right:0;width:34px;height:34px;border:0;border-radius:50%;',
      'background:rgba(255,255,255,.16);color:#fff;font:800 16px var(--font-body);cursor:pointer;',
      'line-height:1;z-index:4}',
    /* 0.9.304: il numero del record non aveva un colore suo e prendeva quello che trovava: a volte
       il bianco della slide, a volte il blu notte che la guardia del contrasto gli scriveva sopra
       quando misurava la slide fuori schermo. Ora e' il rosso del brand, fisso, e la guardia lo lascia stare. */
    '.pf-stat.pb-primato .num,.pf-stat.pb-primato small{color:#E63946!important;-webkit-text-stroke:.6px rgba(255,255,255,.9);text-shadow:0 0 2px #fff,0 0 6px rgba(255,255,255,.85),0 0 14px rgba(255,255,255,.45)}',
    '.pb-per{border:0;background:rgba(255,255,255,.16);border-radius:99px;padding:4px 11px;',
      'color:#fff;font:700 12px var(--font-body);cursor:pointer}',
    '#stPlanBox{position:relative}',
    /* Sopra alle nuvole: il cielo ritaglia quello che sborda, e l'ultima voce del menu
       finiva esattamente sul bordo. */
    '#stPlanBox .arb-menu{left:50%;right:auto;transform:translateX(-50%);bottom:70px;top:auto}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ===========================================================================================
   LA DIAPOSITIVA IN MEZZO — il video, la frase, e chi decide come girano

   Due immagini che si alternano da sole sono un respiro; due immagini che si alternano mentre
   stai leggendo sono un fastidio. Non esiste una velocità giusta per tutti, quindi la si
   sceglie — e si può anche fermare del tutto.
   =========================================================================================== */

const MID_SEC = [3, 4, 5];
const MID_KEY = 'fl_mid';          // { auto: bool, sec: n, testo: string }

function midCfg(){
  try{
    const v = JSON.parse(localStorage.getItem(MID_KEY) || 'null') || {};
    /* Tre, quattro o cinque secondi: oltre, una diapositiva che gira smette di essere un
       respiro fra due sezioni e diventa una pagina ferma. Un valore vecchio piu' alto viene
       riportato dentro, invece di restare li' a contraddire il menu. */
    return { auto: v.auto !== false, sec: MID_SEC.indexOf(+v.sec) >= 0 ? +v.sec : 4, testo: v.testo || '', autore: v.autore || '', testoV: v.testoV || '', autoreV: v.autoreV || '', media: v.media || {} };
  }catch(_){ return { auto: true, sec: 4, testo: '' }; }
}

function midSave(p){
  const c = Object.assign(midCfg(), p || {});
  try{ localStorage.setItem(MID_KEY, JSON.stringify(c)); }catch(_){ }
  midApply();
  midMenuClose();
  return c;
}

/** Riporta la rotazione a quello che dicono le impostazioni, senza ridisegnare le diapositive. */
function midApply(){
  const c = midCfg();
  const h = (typeof FL_HEROES !== 'undefined') ? FL_HEROES.startmid : null;
  if (!h) return;
  h.cycle = c.sec * 1000;
  h.auto = c.auto;
  clearInterval(h.timer);
  const host = document.getElementById(h.hostId);
  if (host) host.classList.toggle('bh--manual', !c.auto);
  /* la frase e lo sfondo scelti per la slide del video e per quella della frase */
  try{
    if (host) Array.prototype.forEach.call(host.querySelectorAll('.bh-slide'), function(s){
      const k = s.querySelector('#stVid') ? 'v' : 'i', m = c.media && c.media[k];
      let el = s.querySelector('.mid-media');
      if (el) el.remove();
      if (m && m.src){
        const src = String(m.src).replace(/"/g, '');
        s.insertAdjacentHTML('afterbegin', m.tipo === 'video' ? '<video class="vz-media mid-media" src="' + src + '" autoplay muted loop playsinline></video>' : '<img class="vz-media mid-media" src="' + src + '" alt="">');
      }
      const vw = s.querySelector('.st-vidwrap'); if (vw) vw.hidden = !!(m && m.src);
      if (k === 'v'){
        const tx = s.querySelector('.bh-text');
        if (tx){
          if (tx.dataset.serie === undefined) tx.dataset.serie = tx.innerHTML;
          tx.innerHTML = c.testoV ? '<h2 class="bh-title">' + esc(c.testoV) + '</h2>' + (c.autoreV ? '<small class="st-cit-a">\u2053 ' + esc(c.autoreV) + '</small>' : '') : tx.dataset.serie;
        }
      }
    });
  }catch(_){ }
  if (c.auto && typeof flHeroAuto === 'function') flHeroAuto('startmid');
  /* La frase sopra alla seconda: vuota di serie, perché l'immagine parla già da sola. */
  const t = document.getElementById('midTesto');
  if (t){
    /* 0.9.280: di serie la frase di Hormozi, scritta (non piu' dentro all'immagine), con l'autore dopo il segno */
    t.innerHTML = c.testo ? '<h2 class="bh-title">' + esc(c.testo) + '</h2>' + (c.autore ? '<small class="st-cit-a">\u2053 ' + esc(c.autore) + '</small>' : '')
      : '<h2 class="bh-title">Come restare povero:<br>inizia domani\u2026</h2><small class="st-cit-a">\u2053 Alex Hormozi</small>';
    t.hidden = false;
  }
}

function midMenuClose(){
  const m = document.getElementById('midMenu');
  if (m) m.remove();
  const v = document.getElementById('midVeil');
  if (v) v.remove();
}

/**
 * Il menu della diapositiva di mezzo.
 *
 * <p>Viveva dentro al cielo (`#stMidHero`), e i cieli di quest'app hanno `overflow:hidden`
 * perche' l'immagine deve restare dentro ai propri bordi: un menu piu' alto del cielo veniva
 * tagliato, e le ultime voci non esistevano proprio. Adesso sta attaccato al telefono e si
 * posiziona sotto al pulsante che lo ha aperto — come fa il fumetto degli «i», per lo stesso
 * motivo e con lo stesso trucco.</p>
 */
function midMenuOpen(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('midMenu')){ midMenuClose(); return; }
  const host = document.getElementById('phone') || document.body;
  const bottone = document.getElementById('midDots');
  if (!host) return;
  const c = midCfg();
  const v = document.createElement('div');
  v.id = 'midVeil';
  v.className = 'arb-veil';
  v.addEventListener('click', function(e){ e.stopPropagation(); midMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(v);
  const m = document.createElement('div');
  m.className = 'arb-menu mid-menu';
  m.id = 'midMenu';
  /* 0.9.332, Andrea: "troppe opzioni: voglio solo modifica ed elimina, come il menu della card di Per te". Il resto sta nel foglio a schede (midEditApri) */
  m.innerHTML = '<p class="arb-mtit">Questa slide</p>'
    + '<button type="button" onclick="midMenuClose();midEditApri()">Modifica questa slide</button>'
    + '<button type="button" class="pr-menu-via" onclick="midTogli()">Togli questo blocco</button>';
  host.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.mid-dots, .pb-dots'));
  /* Sotto al pulsante che l'ha aperto, e dentro al telefono: si misura, non si indovina. */
  if (bottone){
    const pr = host.getBoundingClientRect(), br = bottone.getBoundingClientRect();
    m.style.top = Math.round(br.bottom - pr.top + 8) + 'px';
    m.style.right = Math.round(pr.right - br.right) + 'px';
    m.style.maxHeight = Math.round(pr.bottom - br.bottom - 90) + 'px';
  }
}

/* IL FOGLIO DELLA SLIDE (0.9.332): tre schede, come "Modifica la card". La frase, l'immagine o il video, la rotazione.
   Le due slide si scambiano di posto ogni giorno: si riconoscono dal contenuto ('v' quella col video, 'i' quella con la frase), non dalla posizione. */
const MID_E = { tab: 'frase', k: 'i' };
function midSlideK(){
  try{ const h = FL_HEROES.startmid, host = document.getElementById(h.hostId), s = host && host.querySelector('.bh-slide[data-i="' + h.slide + '"]'); return s && s.querySelector('#stVid') ? 'v' : 'i'; }catch(_){ return 'i'; }
}
function midEditApri(){
  MID_E.tab = 'frase'; MID_E.k = midSlideK();
  const c = midCfg(), mia = MID_E.k === 'v' ? c.testoV : c.testo;
  MID_E.testo = mia || ''; MID_E.autore = MID_E.k === 'v' ? (c.autoreV || '') : (c.autore || '');
  midEditPaint();
}
function midEditLeggi(){
  const t = document.getElementById('midTxt'), a = document.getElementById('midAut');
  if (t) MID_E.testo = t.value; if (a) MID_E.autore = a.value;
}
function midEditTab(k){ midEditLeggi(); MID_E.tab = k; midEditPaint(); }
function midEditHtml(){
  const c = midCfg();
  let corpo = '';
  if (MID_E.tab === 'frase'){
    const mia = MID_E.k === 'v' ? c.testoV : c.testo;
    corpo = '<textarea class="mid-area" id="midTxt" rows="4" maxlength="160" placeholder="Scrivi la tua frase">' + esc(MID_E.testo) + '</textarea>'
      + '<input class="mid-aut" id="midAut" maxlength="60" placeholder="Di chi è la frase? (facoltativo)" value="' + esc(MID_E.autore) + '">'
      + '<button type="button" class="stg-cta" onclick="midEditFrase()">Salva la frase</button>'
      + (mia ? '<button type="button" class="mid-serie" onclick="midEditSerie()">Rimetti la frase di serie</button>' : '');
  } else if (MID_E.tab === 'sfondo'){
    const m = midMedia(MID_E.k);
    corpo = '<div class="mid-prev">' + (m ? (m.tipo === 'video' ? '<video src="' + esc(m.src) + '" autoplay muted loop playsinline></video>' : '<img src="' + esc(m.src) + '" alt="">') : '<span>Lo sfondo di serie</span>') + '</div>'
      + '<button type="button" class="vz-pag-r" onclick="midScegliFoto()"><span>🖼️</span><div><b>Un’immagine</b><small>Dalla galleria del telefono</small></div></button>'
      + '<button type="button" class="vz-pag-r" onclick="midScegliVideo()"><span>🎬</span><div><b>Un video</b><small>Parte da solo, senza audio, e ricomincia</small></div></button>'
      + (m ? '<button type="button" class="mid-serie" onclick="midMediaSalva(null)">Rimetti lo sfondo di serie</button>' : '');
  } else {
    corpo = '<div class="blk-swrow mid-rot"><div><b>Rotazione automatica</b><small>' + (c.auto ? 'Le slide cambiano da sole.' : 'Le slide le cambi tu, con un dito.') + '</small></div><button type="button" class="switch' + (c.auto ? ' on' : '') + '" onclick="midEditAuto()" aria-label="Rotazione automatica"></button></div>'
      + (c.auto ? '<p class="mid-eti">Ogni quanti secondi</p><div class="mid-sec">' + MID_SEC.map(function(n){ return '<button type="button" class="' + (c.sec === n ? 'on' : '') + '" onclick="midSave({sec:' + n + '});midEditPaint()">' + n + ' secondi</button>'; }).join('') + '</div>' : '');
  }
  return '<h2 class="stg-h mid-h">Modifica la slide</h2><div class="pr-ce-tabs">' + [['frase', 'Frase'], ['sfondo', 'Sfondo'], ['rotazione', 'Rotazione']].map(function(t){ return '<button type="button" class="' + (MID_E.tab === t[0] ? 'on' : '') + '" onclick="midEditTab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('') + '</div><div class="mid-corpo">' + corpo + '</div>';
}
function midEditPaint(){
  if (document.getElementById('stgVelo') && typeof stgFoglioCorpo === 'function') stgFoglioCorpo(midEditHtml());
  else stgFoglio(midEditHtml());
}
function midEditFrase(){
  midEditLeggi();
  const t = String(MID_E.testo || '').trim().slice(0, 160), a = String(MID_E.autore || '').trim().slice(0, 60);
  midSave(MID_E.k === 'v' ? { testoV: t, autoreV: a } : { testo: t, autore: a });
  stgFoglioChiudi();
  try{ toast('Frase salvata'); }catch(_){ }
}
function midEditSerie(){
  midSave(MID_E.k === 'v' ? { testoV: '', autoreV: '' } : { testo: '', autore: '' });
  MID_E.testo = ''; MID_E.autore = '';
  midEditPaint();
}
function midEditAuto(){ midSave({ auto: !midCfg().auto }); midEditPaint(); }
function midMedia(k){ const c = midCfg(); const m = c.media && c.media[k]; return m && m.src ? m : null; }
function midMediaSalva(m){
  const c = midCfg(), media = Object.assign({}, c.media || {}); media[MID_E.k] = m;
  midSave({ media: media });
  midEditPaint();
}
function midScegliFoto(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.onchange = function(){
    const file = inp.files && inp.files[0]; inp.remove(); if (!file) return;
    const r = new FileReader();
    r.onload = function(){
      const img = new Image();
      img.onload = function(){
        const q = Math.min(1, 1080 / Math.max(img.width, img.height)), cv = document.createElement('canvas');
        cv.width = Math.round(img.width * q); cv.height = Math.round(img.height * q);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        midMediaSalva({ tipo: 'immagine', src: cv.toDataURL('image/jpeg', .82) });
      };
      img.src = r.result;
    };
    r.readAsDataURL(file);
  };
  document.body.appendChild(inp); inp.click();
}
async function midScegliVideo(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickMedia){ toast('Disponibile nell\'app installata'); return; }
    const r = await NATIVE.pickMedia({ kind: 'video' });
    const uri = r && (r.uri || r.dataUri || r.path);
    if (uri) midMediaSalva({ tipo: 'video', src: uri });
  }catch(_){ }
}
/* togliere il blocco: lo stesso interruttore di Personalizza, dove si rimette */
function midTogli(){
  midMenuClose();
  try{
    const c = scsCfg('start'), b = c.blocchi.filter(function(x){ return x.id === 'stMid'; })[0];
    if (b){ b.on = false; localStorage.setItem(scsPag('start').key, JSON.stringify(c)); }
    if (typeof scsOrdinaBlocchi === 'function') scsOrdinaBlocchi('start');
    toast('Blocco tolto: lo rimetti da Personalizza la pagina');
  }catch(_){ }
}
/* 0.9.282, Andrea: il riquadro di sistema (Cancel, OK) "fa cagare" e ogni volta faceva riscrivere la frase da capo.
   Un foglio dal basso con un campo grande, la frase di adesso gia' dentro, e l'autore. */
function midChiediTesto(){
  const c = midCfg();
  midMenuClose();
  const testo = c.testo || 'Come restare povero: inizia domani\u2026';
  const autore = c.testo ? (c.autore || '') : 'Alex Hormozi';
  if (typeof stgFoglio !== 'function'){ const v = prompt('La frase che vuoi leggere qui:', testo); if (v !== null) midSave({ testo: String(v).trim().slice(0, 160) }); return; }
  stgFoglio('<small class="stg-eti">La frase della slide</small><h2 class="stg-h">Cosa vuoi leggere qui?</h2>'
    + '<textarea class="mid-area" id="midTxt" rows="4" maxlength="160" placeholder="Scrivi la tua frase">' + esc(testo) + '</textarea>'
    + '<input class="mid-aut" id="midAut" maxlength="60" placeholder="Di chi è la frase? (facoltativo)" value="' + esc(autore) + '">'
    + '<button type="button" class="stg-cta" onclick="midTestoSalva()">Salva la frase</button>'
    + (c.testo ? '<button type="button" class="mid-serie" onclick="midSave({ testo: \'\', autore: \'\' });stgFoglioChiudi()">Rimetti la frase di serie</button>' : ''));
  setTimeout(function(){ const t = document.getElementById('midTxt'); if (t){ t.focus(); t.setSelectionRange(t.value.length, t.value.length); } }, 250);
}
function midTestoSalva(){
  const t = document.getElementById('midTxt'), a = document.getElementById('midAut');
  const v = t ? t.value.trim().slice(0, 160) : '';
  midSave({ testo: v, autore: a ? a.value.trim().slice(0, 60) : '' });
  try{ stgFoglioChiudi(); }catch(_){ }
}

(function midStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '#stMidHero{position:relative}',
    '.mid-area{display:block;width:100%;box-sizing:border-box;margin:6px 0 12px;padding:14px;border:1.5px solid var(--line);border-radius:16px;font:600 17px/1.45 var(--font-body);color:var(--navy);background:var(--card,#fff);resize:vertical;min-height:120px}',
    '.mid-aut{display:block;width:100%;box-sizing:border-box;margin:0 0 20px;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px;font:500 15px var(--font-body);color:var(--navy);background:var(--card,#fff)}',
    'body.dark .mid-area,body.dark .mid-aut{background:#14234A;color:#fff;border-color:rgba(255,255,255,.16)}',
    '.mid-serie{display:block;width:100%;margin-top:10px;padding:12px;border:0;background:none;font:700 14px var(--font-body);color:#0075E3;cursor:pointer}',
    '.mid-dots{position:absolute;top:12px;right:12px;width:34px;height:34px;border:0;border-radius:50%;',
      'background:rgba(0,0,0,.35);color:#fff;font:800 16px var(--font-body);cursor:pointer;line-height:1;z-index:5}',
    /* Il menu non sta piu' dentro al cielo: sta nel telefono, e si posiziona da se'. */
    '.mid-menu{position:absolute;z-index:120;overflow-y:auto;min-height:120px}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* I due tabelloni si rifanno quando la scheda torna davanti. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'sveglia') return;
  pbPaint();
  midApply();
});
setTimeout(function(){ pbPaint(); midApply(); }, 2800);
(function(){
  const st = document.createElement('style');
  st.textContent = '.mid-h{text-align:center}.mid-corpo{margin-top:20px;display:flex;flex-direction:column;gap:12px}.mid-corpo .mid-area,.mid-corpo .mid-aut{margin:0}.mid-prev{height:150px;border-radius:18px;overflow:hidden;display:flex;align-items:center;justify-content:center;background:linear-gradient(168deg,#123A70,#001E44);color:#BFD3EC;font:600 14px var(--font-body)}.mid-prev img,.mid-prev video{width:100%;height:100%;object-fit:cover}.mid-rot{margin:0!important}.mid-eti{margin:8px 0 0;font:800 15px var(--font-display);color:var(--navy);text-align:center}body.dark .mid-eti{color:#fff}.mid-sec{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.mid-sec button{padding:13px 4px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy);font:700 13.5px var(--font-body);cursor:pointer}body.dark .mid-sec button{color:#fff}.mid-sec button.on{background:#0075E3;border-color:#0075E3;color:#fff}';
  document.head.appendChild(st);
})();
