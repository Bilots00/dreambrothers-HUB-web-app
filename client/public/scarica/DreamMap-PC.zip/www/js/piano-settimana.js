/* ===========================================================================================
   LA SETTIMANA (0.9.242): l'esercizio della domenica sera, o del lunedi' mattina

   Dal sistema di Davie Fogarty: una volta a settimana si scrivono le cose importanti, si stima
   quanto tempo serve a ognuna e si guarda il totale accanto alle ore che ci sono davvero. Chi
   lo fa scopre subito se la settimana ci sta, prima che sia lei a deciderlo. Poi, se vuole,
   ogni cosa va nel calendario a un giorno e a un'ora.

   Compare come card nella Mappa (vista Roadmap, sopra al piano del percorso) la domenica dalle
   17 e il lunedi' fino alle 13, finche' la settimana non e' pianificata. Si apre anche dalla
   scheda Calendario del piano del percorso (psApri).

   fl_settimana_piano = { "<lunedi' AAAA-MM-GG>": { voci: [{ t, ore, giorno, ora, evId }],
   disponibili, at } }. Il report della settimana (settimana.js) e' un'altra cosa.
   =========================================================================================== */
const PS_KEY = 'fl_settimana_piano';
const PS_ORE = [[0.5, 'Mezz’ora'], [1, '1 ora'], [2, '2 ore'], [3, '3 ore'], [4, '4 ore'], [6, '6 ore'], [8, '8 ore'], [12, '12 ore']];
const PS_GIORNI = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
const PS = { lun: '', voci: [], disponibili: 20, passo: 'lista' };

function psLeggi(){ try{ const o = JSON.parse(localStorage.getItem(PS_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; }catch(_){ return {}; } }
function psScrivi(o){ try{ localStorage.setItem(PS_KEY, JSON.stringify(o)); }catch(_){ } }
function psEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function psIso(d){ d = new Date(d); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
/** Il lunedi' della settimana da pianificare: la domenica e' gia' quella dopo. */
function psLunedi(adesso){
  const d = new Date(adesso || Date.now()); d.setHours(0, 0, 0, 0);
  if (d.getDay() === 0) d.setDate(d.getDate() + 1);
  else d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d;
}
function psData(d){ const m = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']; d = new Date(d); return d.getDate() + ' ' + m[d.getMonth()]; }
function psOreTxt(h){ h = Math.round(h * 10) / 10; if (h === 0.5) return 'mezz’ora'; return (String(h).replace('.', ',')) + (h === 1 ? ' ora' : ' ore'); }
function psFatta(adesso){ return !!psLeggi()[psIso(psLunedi(adesso))]; }
/** E' il momento di proporla? Domenica dalle 17, lunedi' fino alle 13, se non e' gia' fatta. */
function psMomento(adesso){
  const d = new Date(adesso || Date.now()), g = d.getDay(), h = d.getHours();
  return ((g === 0 && h >= 17) || (g === 1 && h < 13)) && !psFatta(adesso);
}

function psProposte(){
  const l = [];
  try{
    if (typeof ozAnello === 'function') ['settimana', 'mese'].forEach(function(k){
      (ozAnello(k).passi || []).forEach(function(p){ if (p && p.t && !p.fatto && l.length < 5 && !l.some(function(x){ return x.t === p.t; })) l.push({ t: p.t, ore: 1 }); });
    });
  }catch(_){ }
  return l;
}
function psApri(){
  const lun = psLunedi(); PS.lun = psIso(lun); PS.passo = 'lista';
  const gia = psLeggi()[PS.lun];
  PS.voci = gia ? JSON.parse(JSON.stringify(gia.voci || [])) : psProposte();
  if (!PS.voci.length) PS.voci.push({ t: '', ore: 1 });
  PS.disponibili = gia ? (+gia.disponibili || 20) : 20;
  if (typeof stgFoglio === 'function') stgFoglio(psHtml());
}
function psTotale(){ return PS.voci.filter(function(v){ return String(v.t || '').trim(); }).reduce(function(a, v){ return a + (+v.ore || 0); }, 0); }
function psConto(){
  const tot = psTotale(), dis = PS.disponibili, resto = Math.round((dis - tot) * 10) / 10;
  const pct = dis ? Math.min(100, Math.round(tot / dis * 100)) : 100;
  return '<div class="ps-conto' + (resto < 0 ? ' troppo' : '') + '"><div class="ps-conto-r"><span>Ti servono</span><b>' + psOreTxt(tot) + '</b></div>'
    + '<div class="ps-conto-r"><span>Ne hai</span><b>' + psOreTxt(dis) + '</b></div>'
    + '<div class="stg-barra"><i style="width:' + pct + '%"></i></div>'
    + '<p>' + (resto >= 0 ? 'La settimana ci sta' + (resto > 0 ? ', con ' + psOreTxt(resto) + ' di margine.' : ', senza margine.') : 'Mancano ' + psOreTxt(-resto) + ': togli una cosa o spostala alla settimana dopo.') + '</p></div>';
}
function psHtml(){
  const lun = new Date(PS.lun + 'T12:00:00'), dom = new Date(lun.getTime() + 6 * 86400000);
  if (PS.passo === 'cal') return psCalHtml();
  const righe = PS.voci.map(function(v, i){
    return '<div class="ps-riga"><input class="stg-in" data-ps="' + i + '" value="' + psEsc(v.t) + '" placeholder="Una cosa importante" oninput="psTesto(' + i + ',this.value)">'
      + '<div class="ps-riga-b"><select class="ps-sel" onchange="psOre(' + i + ',this.value)" aria-label="Quanto tempo serve">' + PS_ORE.map(function(o){ return '<option value="' + o[0] + '"' + (+v.ore === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'
      + '<button type="button" class="ps-togli" onclick="psTogli(' + i + ')" aria-label="Togli questa riga"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div></div>';
  }).join('');
  return '<small class="stg-eti">La settimana</small><h2 class="stg-h">Le cose importanti dal ' + psData(lun) + ' al ' + psData(dom) + '</h2>'
    + '<p class="stg-p">Scrivi le cose che contano davvero e quanto tempo serve a ognuna. Poi guardiamo se ci stanno nelle ore che hai.</p>'
    + '<div class="ps-righe">' + righe + '</div>'
    + '<button type="button" class="stg-link ps-piu" onclick="psAggiungi()">Aggiungi una cosa</button>'
    + '<label class="stg-q">Quante ore hai per lavorarci questa settimana?</label>'
    + '<div class="ps-stepper"><button type="button" onclick="psDisp(-1)" aria-label="Un’ora in meno">−</button><b id="psDisp">' + psOreTxt(PS.disponibili) + '</b><button type="button" onclick="psDisp(1)" aria-label="Un’ora in più">+</button></div>'
    + '<div id="psConto">' + psConto() + '</div>'
    + '<button type="button" class="stg-cta" onclick="psSalva()">Salvo la settimana</button>'
    + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>';
}
function psTesto(i, t){ if (PS.voci[i]) PS.voci[i].t = t; const c = document.getElementById('psConto'); if (c) c.innerHTML = psConto(); }
function psOre(i, v){ if (PS.voci[i]) PS.voci[i].ore = +v; const c = document.getElementById('psConto'); if (c) c.innerHTML = psConto(); }
function psRidisegna(){ if (typeof stgFoglioCorpo === 'function') stgFoglioCorpo(psHtml()); }
function psAggiungi(){ PS.voci.push({ t: '', ore: 1 }); psRidisegna(); setTimeout(function(){ const l = document.querySelectorAll('#stgVelo [data-ps]'); if (l.length) l[l.length - 1].focus(); }, 50); }
function psTogli(i){ PS.voci.splice(i, 1); if (!PS.voci.length) PS.voci.push({ t: '', ore: 1 }); psRidisegna(); }
function psDisp(d){
  PS.disponibili = Math.max(1, Math.min(100, PS.disponibili + d));
  const b = document.getElementById('psDisp'); if (b) b.textContent = psOreTxt(PS.disponibili);
  const c = document.getElementById('psConto'); if (c) c.innerHTML = psConto();
}
function psSalva(){
  PS.voci = PS.voci.map(function(v){ return Object.assign({}, v, { t: String(v.t || '').replace(/\s+/g, ' ').trim() }); }).filter(function(v){ return v.t; });
  if (!PS.voci.length){ if (typeof toast === 'function') toast('Scrivi almeno una cosa importante.'); PS.voci.push({ t: '', ore: 1 }); return; }
  const o = psLeggi(); o[PS.lun] = { voci: PS.voci, disponibili: PS.disponibili, at: Date.now() };
  /* si tengono le ultime dodici settimane */
  Object.keys(o).sort().slice(0, -12).forEach(function(k){ delete o[k]; });
  psScrivi(o);
  try{ flVibra([20, 40]); }catch(_){ }
  PS.passo = 'cal'; psRidisegna(); psPaint();
}
/* il secondo passo, facoltativo: ogni cosa a un giorno e a un'ora */
function psCalHtml(){
  const lun = new Date(PS.lun + 'T12:00:00');
  /* i giorni gia' passati non si propongono: si parte da oggi (o da lunedi', se e' domenica) */
  const primo = Math.max(0, Math.min(6, Math.round((new Date().setHours(12, 0, 0, 0) - lun.getTime()) / 86400000)));
  const righe = PS.voci.map(function(v, i){
    const g = v.giorno != null ? +v.giorno : Math.min(6, primo + i);
    return '<div class="ps-cal"><b>' + psEsc(v.t) + ' <small>' + psOreTxt(+v.ore || 1) + '</small></b>' + (v.evId ? '<small class="ps-in">Già in calendario</small>' : '')
      + '<div class="ps-riga-b"><select class="ps-sel" id="psG' + i + '" aria-label="Il giorno">' + PS_GIORNI.map(function(n, k){ const d = new Date(lun.getTime() + k * 86400000); return '<option value="' + k + '"' + (g === k ? ' selected' : '') + '>' + n + ' ' + d.getDate() + '</option>'; }).join('') + '</select>'
      + '<input type="time" class="stg-in pkp-time" id="psO' + i + '" value="' + psEsc(v.ora || '09:00') + '" aria-label="L’ora"></div></div>';
  }).join('');
  return '<small class="stg-eti">La settimana è scritta</small><h2 class="stg-h">Vuoi metterle in calendario?</h2>'
    + '<p class="stg-p">Scegli il giorno e l’ora di ogni cosa. Un appuntamento con un’ora precisa si rimanda molto meno.</p>'
    + '<div class="ps-righe">' + righe + '</div>'
    + '<button type="button" class="stg-cta" onclick="psCalendario()">Metti tutto in calendario</button>'
    + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Va bene così</button>';
}
function psCalendario(){
  const lun = new Date(PS.lun + 'T00:00:00');
  let n = 0;
  PS.voci.forEach(function(v, i){
    const g = +((document.getElementById('psG' + i) || {}).value || 0);
    const hm = String((document.getElementById('psO' + i) || {}).value || '09:00').split(':');
    const d = new Date(lun.getTime()); d.setDate(d.getDate() + g); d.setHours(+hm[0] || 9, +hm[1] || 0, 0, 0);
    v.giorno = g; v.ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    try{
      if (typeof calSalvaEvento === 'function'){
        const ev = calSalvaEvento({ id: v.evId || undefined, titolo: v.t, inizio: d.getTime(), fine: d.getTime() + Math.max(0.5, +v.ore || 1) * 3600000, colore: '#0075E3', descr: 'La settimana in DreamMap' });
        if (ev){ v.evId = ev.id; n++; }
      }
    }catch(_){ }
  });
  const o = psLeggi(); if (o[PS.lun]){ o[PS.lun].voci = PS.voci; psScrivi(o); }
  if (typeof stgFoglioCorpo === 'function') stgFoglioCorpo('<small class="stg-eti">La settimana</small><h2 class="stg-h">' + (n === 1 ? 'Una cosa in calendario' : n + ' cose in calendario') + '</h2><p class="stg-p">Le trovi nel calendario di DreamMap' + ((typeof calCollegato === 'function' && calCollegato()) ? ' e in quello del telefono' : '') + '. Buona settimana.</p><button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Chiudi</button>');
}

/* la card nella Mappa.
   0.9.286, Andrea: "il pannello blu La settimana non deve comparire sopra al piano del percorso" (e il suo foglio con
   "Ti servono 0 ore, ne hai 20"). Nella Roadmap la settimana l'ha gia' pianificata il Genio; nella Mappa c'e' il
   pulsante "Pianifica la settimana" nel calendario, che apre la chat del tuo agente personale (calendario.js). */
function psCardHtml(){ return ''; }
function psPaint(){
  if (typeof document === 'undefined') return;
  const rif = document.getElementById('mppPianoRm'); if (!rif || !rif.parentNode) return;
  let h = document.getElementById('mppSettimana');
  if (!h){ h = document.createElement('div'); h.id = 'mppSettimana'; h.className = 'mpp-slot'; }
  if (h.nextElementSibling !== rif) rif.parentNode.insertBefore(h, rif);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  h.classList.toggle('mpp-via', v !== 'rotta');
  const html = psCardHtml();
  if (h.dataset.html !== html){ h.dataset.html = html; h.innerHTML = html; }
}
/** Per il tuo agente personale: il piano della settimana. */
function psPerAgente(){
  const p = psLeggi()[psIso(psLunedi())]; if (!p) return '';
  const tot = (p.voci || []).reduce(function(a, v){ return a + (+v.ore || 0); }, 0);
  return 'La settimana pianificata: ' + (p.voci || []).map(function(v){ return '"' + v.t + '" (' + psOreTxt(+v.ore || 0) + ')'; }).join(', ') + '; totale ' + psOreTxt(tot) + ' su ' + psOreTxt(+p.disponibili || 0) + ' disponibili.';
}

if (typeof document !== 'undefined'){
  (function(){
    if (typeof rmpPaint === 'function' && !rmpPaint.__ps){ const v = rmpPaint; const w = function(){ const r = v.apply(this, arguments); try{ psPaint(); }catch(_){ } return r; }; w.__ps = true; w.__stg = v.__stg; window.rmpPaint = w; }
    if (typeof rnPerAgente === 'function' && !rnPerAgente.__ps){ const v2 = rnPerAgente; const w2 = function(){ return [v2.apply(this, arguments), psPerAgente()].filter(Boolean).join(' '); }; w2.__ps = true; window.rnPerAgente = w2; }
  })();
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(psPaint, 140); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(psPaint, 700); });
  setTimeout(psPaint, 1600);
  setInterval(psPaint, 60000);
  (function(){
    const st = document.createElement('style');
    st.textContent = [
      '#mppSettimana{padding:0 16px;margin:10px 0 12px}#mppSettimana:empty{display:none}',
      '.ps-righe{display:grid;gap:10px;margin:4px 0 6px}.ps-riga{display:grid;gap:8px;padding:12px;border-radius:14px;background:rgba(255,255,255,.06)}',
      '.ps-riga-b{display:flex;gap:8px;align-items:center}.ps-sel{flex:1;padding:12px;border-radius:12px;border:1.5px solid rgba(255,255,255,.2);background:#14234A;color:#FFFFFF;font:600 15px var(--font-body)}',
      '.ps-togli{flex:none;width:44px;height:44px;border-radius:12px;border:0;background:rgba(255,255,255,.1);color:#FFFFFF;display:grid;place-items:center}',
      '.ps-piu{text-align:left;padding-left:0}',
      '.ps-stepper{display:flex;align-items:center;gap:12px}.ps-stepper button{width:48px;height:48px;border-radius:14px;border:0;background:#0075E3;color:#FFFFFF;font:800 24px var(--font-body)}.ps-stepper b{min-width:110px;text-align:center;font:800 20px var(--font-body);color:#FFFFFF}',
      '.ps-conto{margin:14px 0 4px;padding:14px;border-radius:16px;background:rgba(0,117,227,.18)}.ps-conto.troppo{background:rgba(140,198,255,.16)}',
      '.ps-conto-r{display:flex;justify-content:space-between;font:600 15.5px var(--font-body);color:rgba(255,255,255,.85);margin-bottom:4px}.ps-conto-r b{color:#FFFFFF}',
      '.ps-conto p{margin:10px 0 0;font:700 15.5px/1.45 var(--font-body);color:#FFFFFF}.ps-conto.troppo p{color:#FF8A93}',
      '.ps-cal{display:grid;gap:8px;padding:12px;border-radius:14px;background:rgba(255,255,255,.06)}.ps-cal > b{font:700 15.5px/1.4 var(--font-body);color:#FFFFFF}.ps-cal > b small{font:600 13px var(--font-body);color:#8CC6FF}',
      '.ps-in{font:600 12.5px var(--font-body);color:#8CC6FF}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { psLunedi: psLunedi, psMomento: psMomento, psIso: psIso };
}
