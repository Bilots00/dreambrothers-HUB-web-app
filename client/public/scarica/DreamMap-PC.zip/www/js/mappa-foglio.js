/* ===========================================================================================
   IL FOGLIO DELLA MAPPA: Note | Oggi | Domani | Calendario (0.9.216)

   Andrea: il caveau delle idee in una scheda sua, Note, prima di Oggi; dopo Domani il
   Calendario; le schede scorrono di lato e i tre puntini stanno sulla loro riga. Dai tre
   puntini si sceglie se Oggi mostra UNA cosa sola (la priorita') o una lista vera, dove si
   scrive sotto alla prima riga come in una to-do list. Una task si sposta fra Oggi e Domani
   tenendola premuta e trascinandola sulla scheda, oppure dai tre puntini che compaiono sulla
   riga in cui sta il cursore.

   I dati restano quelli di sempre: le righe di `fl_notes_<giorno>`, le spunte di stSpunta, il
   caveau di ulisse.js. START, Full Focus e il piano in Notion vedono le stesse cose.
   =========================================================================================== */
const MF = { mese: null, giorno: '', drag: null };
const MF_TABS = [['note', 'Note'], ['oggi', 'Oggi'], ['domani', 'Domani'], ['cal', 'Calendario']];
const MF_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

/** Una lista di cose da fare (true) o una cosa sola, la priorita' (false, come prima). */
function mfLista(){ try{ return localStorage.getItem('fl_foglio_lista') === '1'; }catch(_){ return false; } }
function mfListaSet(on){ try{ localStorage.setItem('fl_foglio_lista', on ? '1' : '0'); }catch(_){ } try{ stPaint(); }catch(_){ } try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ } }
function mfIso(off){ return mtKey(Date.now() + off * 86400000); }
function mfDomande(t){
  return t === 'note' ? '“Quale idea ti sta distraendo adesso?”'
    : t === 'domani' ? '“Qual è il tuo piano per domani?”'
    : t === 'cal' ? '“Cosa vuoi fare, e in quale giorno?”'
    : '“Qual è il tuo piano per la prossima ora?”';
}

/* ---------- le schede si rinominano e si tolgono (0.9.231, come quelle della To do list) ----------
   Un tocco sulla scheda gia' aperta apre il menu: Rinomina, Elimina. Eliminare la nasconde (quello che
   c'e' dentro resta), e dal menu si rimettono le schede nascoste. In localStorage `fl_foglio_schede`:
   { nomi: { chiave: nome }, via: [chiavi] }. */
function mfSchedeCfg(){ try{ const c = JSON.parse(localStorage.getItem('fl_foglio_schede') || '{}'); return { nomi: (c && c.nomi) || {}, via: (c && Array.isArray(c.via)) ? c.via : [], ordine: (c && Array.isArray(c.ordine)) ? c.ordine : [] }; }catch(_){ return { nomi: {}, via: [], ordine: [] }; } }
function mfSchedeSalva(c){ try{ localStorage.setItem('fl_foglio_schede', JSON.stringify(c)); }catch(_){ } }
function mfSchede(){
  const c = mfSchedeCfg();
  /* 0.9.232: le schede si riordinano trascinandole (c.ordine); quelle nuove o mai spostate restano in coda */
  const pos = function(k){ const i = c.ordine.indexOf(k); return i < 0 ? 100 + MF_TABS.findIndex(function(x){ return x[0] === k; }) : i; };
  const l = MF_TABS.slice().sort(function(a, b){ return pos(a[0]) - pos(b[0]); }).filter(function(x){ return c.via.indexOf(x[0]) < 0; }).map(function(x){ return [x[0], String(c.nomi[x[0]] || x[1])]; });
  return l.length ? l : [[MF_TABS[0][0], String(c.nomi[MF_TABS[0][0]] || MF_TABS[0][1])]];
}
function mfTabTocca(k, el){
  if (MF_TT.tirata) return;
  if (STN.tab !== k){ mfTab(k); return; }
  mfTabMenu(k, el);
}
function mfTabMenuVia(){ const m = document.getElementById('mfTabMenu'); if (m) m.remove(); }
function mfTabMenu(k, el){
  mfTabMenuVia();
  const r = el.getBoundingClientRect(), c = mfSchedeCfg(), nascoste = c.via.length;
  const ico = function(p){ return '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
  const m = document.createElement('div'); m.id = 'mfTabMenu'; m.className = 'mf-tmenu-velo';
  m.innerHTML = '<div class="mf-tmenu" style="left:' + Math.max(8, Math.min(r.left, window.innerWidth - 228)) + 'px;top:' + (r.bottom + 6) + 'px">'
    + '<button type="button" onclick="mfTabRinomina(\'' + k + '\')">' + ico('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>') + 'Rinomina</button>'
    + (mfSchede().length > 1 ? '<button type="button" class="mf-tmenu-via" onclick="mfTabElimina(\'' + k + '\')">' + ico('<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>') + 'Elimina</button>' : '')
    + (nascoste ? '<button type="button" onclick="mfTabRimetti()">' + ico('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>') + 'Rimetti le schede tolte (' + nascoste + ')</button>' : '')
    + '</div>';
  m.addEventListener('click', function(e){ if (e.target === m) mfTabMenuVia(); });
  document.body.appendChild(m);
}
function mfTabRinomina(k){
  mfTabMenuVia();
  const b = document.querySelector('#mfTabs [data-k="' + k + '"]'); if (!b) return;
  const i = document.createElement('input'); i.className = 'st-daytab on mf-tab-in'; i.value = b.textContent; i.setAttribute('aria-label', 'Nuovo nome della scheda'); i.setAttribute('data-no-dettatura', '');
  i.style.width = Math.max(70, b.offsetWidth + 24) + 'px';
  b.replaceWith(i); i.focus(); i.select();
  let fatto = false;
  const salva = function(){ if (fatto) return; fatto = true; const v = i.value.trim().slice(0, 24); const c = mfSchedeCfg(); if (v) c.nomi[k] = v; mfSchedeSalva(c); stPaint(); };
  i.addEventListener('keydown', function(e){ if (e.key === 'Enter'){ e.preventDefault(); i.blur(); } if (e.key === 'Escape'){ fatto = true; stPaint(); } });
  i.addEventListener('blur', salva);
}
function mfTabElimina(k){
  mfTabMenuVia();
  const c = mfSchedeCfg(); if (c.via.indexOf(k) < 0) c.via.push(k); mfSchedeSalva(c);
  const resta = mfSchede()[0][0];
  toast('Scheda tolta. La rimetti dai tre puntini, alla voce Le schede');
  mfTab(resta);
}
function mfTabRimetti(){ mfTabMenuVia(); const c = mfSchedeCfg(); c.via = []; mfSchedeSalva(c); stPaint(); }
/** Le schede come erano all'inizio: tutte, coi nomi e l'ordine di partenza (dalle impostazioni). */
function mfSchedeRipristina(){ mfSchedeSalva({ nomi: {}, via: [], ordine: [] }); try{ stPaint(); }catch(_){ } try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ } toast('Schede ripristinate'); }
function mfSchedaMostra(k, on){ const c = mfSchedeCfg(); c.via = c.via.filter(function(x){ return x !== k; }); if (!on) c.via.push(k); if (MF_TABS.length - c.via.length < 1){ toast('Almeno una scheda resta'); return; } mfSchedeSalva(c); try{ stPaint(); }catch(_){ } try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ } }

/* ---------- trascinare le schede (0.9.232, come nel piano) ----------
   Col dito: si tiene premuto un attimo, la scheda si stacca e segue il dito, il suo posto resta
   sbiadito e le altre scivolano per farle spazio. Al rilascio l'ordine nuovo si salva. */
const MF_TT = { tirata: false };
function mfTabsTrascina(){
  const box = document.getElementById('mfTabs'); if (!box || box._tt) return; box._tt = true;
  box.addEventListener('pointerdown', function(e){
    const btn = e.target && e.target.closest ? e.target.closest('.st-daytab[data-k]') : null;
    if (!btn || e.button > 0) return;
    const bt = Array.from(box.querySelectorAll('.st-daytab[data-k]')); if (bt.length < 2) return;
    const i = bt.indexOf(btn), x0 = e.clientX, y0 = e.clientY, tocco = e.pointerType !== 'mouse';
    let attivo = false, a = i, fant = null, rr = [], passo = 0, dx = 0, lp = 0;
    const parti = function(){
      attivo = true; MF_TT.tirata = true;
      rr = bt.map(function(x){ return x.getBoundingClientRect(); });
      const r = rr[i]; const gap = bt[i + 1] ? rr[i + 1].left - r.right : (i > 0 ? r.left - rr[i - 1].right : 6);
      passo = r.width + gap; dx = x0 - r.left;
      fant = btn.cloneNode(true); fant.classList.add('mf-tab-fant');
      Object.assign(fant.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
      document.body.appendChild(fant); btn.classList.add('mf-tab-presa');
      bt.forEach(function(x){ x.style.transition = 'transform .18s ease'; });
      try{ flVibra(12); }catch(_){ }
    };
    const disponi = function(){
      let vuoto = 0;
      bt.forEach(function(x, j){
        let t = 0;
        if (a > i && j > i && j <= a){ t = -passo; vuoto += rr[j].width + (passo - rr[i].width); }
        if (a < i && j >= a && j < i){ t = passo; vuoto -= rr[j].width + (passo - rr[i].width); }
        if (j !== i) x.style.transform = t ? 'translateX(' + t + 'px)' : '';
      });
      btn.style.transform = vuoto ? 'translateX(' + vuoto + 'px)' : '';
    };
    const mossa = function(ev){
      if (!attivo){
        if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < 7) return;
        if (tocco){ fine(); return; }
        parti();
      }
      fant.style.left = (ev.clientX - dx) + 'px';
      fant.style.top = (rr[i].top + Math.max(-16, Math.min(16, ev.clientY - y0))) + 'px';
      let n = i;
      for (let j = 0; j < rr.length; j++){ if (j === i) continue; const c = rr[j].left + rr[j].width / 2; if (j > i && ev.clientX > c) n = j; if (j < i && ev.clientX < c && n === i) n = j; }
      if (n !== a){ a = n; disponi(); }
      const b = box.getBoundingClientRect(); if (ev.clientX > b.right - 24) box.scrollLeft += 8; else if (ev.clientX < b.left + 24) box.scrollLeft -= 8;
    };
    const ferma = function(ev){ if (attivo && ev.cancelable) ev.preventDefault(); };
    const fine = function(){
      clearTimeout(lp);
      window.removeEventListener('pointermove', mossa); window.removeEventListener('pointerup', su); window.removeEventListener('pointercancel', annulla);
      window.removeEventListener('touchmove', ferma);
    };
    const pulisci = function(){ bt.forEach(function(x){ x.style.transition = 'none'; x.style.transform = ''; x.classList.remove('mf-tab-presa'); }); setTimeout(function(){ MF_TT.tirata = false; }, 80); };
    const annulla = function(){ fine(); if (!attivo) return; if (fant) fant.remove(); pulisci(); };
    const su = function(){
      fine(); if (!attivo) return;
      const dest = btn.getBoundingClientRect();
      fant.style.transition = 'left .14s ease, top .14s ease, transform .14s ease';
      fant.style.left = dest.left + 'px'; fant.style.top = dest.top + 'px'; fant.style.transform = 'none';
      setTimeout(function(){
        fant.remove();
        if (a !== i){
          const k = bt.map(function(x){ return x.getAttribute('data-k'); }); const [m] = k.splice(i, 1); k.splice(a, 0, m);
          const c = mfSchedeCfg(); c.ordine = k.concat(c.ordine.filter(function(x){ return k.indexOf(x) < 0; })); mfSchedeSalva(c);
          /* le schede si rimettono in ordine nel DOM, senza ridisegnare il foglio */
          const piu = box.querySelector('.st-daytab:not([data-k])');
          k.forEach(function(kk){ const el = box.querySelector('.st-daytab[data-k="' + kk + '"]'); if (el) box.insertBefore(el, piu || null); });
        }
        pulisci();
      }, 150);
    };
    if (tocco) lp = setTimeout(parti, 320);
    window.addEventListener('pointermove', mossa); window.addEventListener('pointerup', su); window.addEventListener('pointercancel', annulla);
    window.addEventListener('touchmove', ferma, { passive: false });
  });
  box.addEventListener('contextmenu', function(e){ e.preventDefault(); });
}

/* ---------- il pannello ---------- */
function mfHtml(titolo){
  const sch = mfSchede();
  if (!sch.some(function(x){ return x[0] === STN.tab; })) STN.tab = sch[0][0];
  const t = STN.tab;
  const tabs = sch.map(function(x){ return '<button type="button" class="st-daytab' + (t === x[0] ? ' on' : '') + '" data-k="' + x[0] + '" onclick="mfTabTocca(\'' + x[0] + '\',this)">' + esc(x[1]) + '</button>'; }).join('');
  return '<section class="st-sec mf">'
    + '<div class="sev-intro st-intro">' + titolo + '<p class="st-domanda">' + mfDomande(t) + '</p></div>'
    + '<div class="st-note st-tutto mf-note">'
    +   '<div class="mf-head"><div class="mf-tabs" id="mfTabs">' + tabs + '</div>'
    +     '<button type="button" class="mf-dots" onclick="if(typeof ulImpApri===\'function\')ulImpApri()" aria-label="Impostazioni del piano">⋯</button></div>'
    +   '<div class="mf-corpo" id="mfCorpo">' + mfCorpo(t) + '</div>'
    +   '<div class="st-dict st-solo"><button type="button" class="st-expand" onclick="stFullOpen()" aria-label="A tutto schermo"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H3v6M15 3h6v6M9 21H3v-6M15 21h6v-6"/></svg></button></div>'
    + '</div></section>';
}
function mfTab(k){ STN.tab = k; STN.day = 'today'; try{ flVibra(6); }catch(_){ } stPaint(); setTimeout(function(){ const b = document.querySelector('#mfTabs [data-k="' + k + '"]'); if (b && b.scrollIntoView) b.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' }); }, 30); }
function mfCorpo(t){
  /* 0.9.232: sopra al caveau le note veloci, scrivibili riga per riga come nella sezione Le tue note */
  if (t === 'note') return (typeof mnVelociHtml === 'function' ? '<div class="mf-veloci">' + mnVelociHtml('foglio') + '</div>' : '') + (typeof cvBoxHtml === 'function' ? cvBoxHtml() : '') + mfNotionNote();
  if (t === 'cal') return typeof calCorpo === 'function' ? calCorpo() : mfCalHtml(); /* calendario.js: Mese (questo) | Settimana | Giorno */
  if (t === 'domani'){
    if (typeof pnDomaniAperto === 'function' && !pnDomaniAperto()) return pnLucchettoHtml();
    return mfLista() ? mfListaHtml(mfIso(1), 'Da fare domani') : pnDomaniHtml();
  }
  /* oggi */
  return mfLista() ? mfListaHtml(mfIso(0), 'Da fare oggi') : '<div class="st-list st-oggi" id="stList"></div>';
}
/** Dopo il disegno: la lista di oggi «a una cosa sola» la disegna start.js come prima. */
function mfDopo(){
  if (STN.tab === 'oggi' && !mfLista()) try{ stListPaint(); }catch(_){ }
  mfDragAggancia();
  mfTabsTrascina();
  if (STN.tab === 'cal' && typeof calDopo === 'function') try{ calDopo(); }catch(_){ }
  try{ if (typeof mnRigheAggancia === 'function') mnRigheAggancia(); }catch(_){ }
  /* dopo «invio» sulla riga nuova il cursore resta li', per scrivere la prossima */
  if (MF.fuocoTesto){
    const f = MF.fuocoTesto; MF.fuocoTesto = null;
    const el = Array.from(document.querySelectorAll('#mfCorpo .mf-t[data-v]')).filter(function(x){ return x.getAttribute('data-v') === f.t; })[0];
    if (el) mfCursore(el, f.at);
  }
  if (MF.fuoco){
    MF.fuoco = false; const nr = document.querySelector('#mfCorpo .mf-nuova');
    if (nr && MF.nuovaDopo){ const r = Array.from(document.querySelectorAll('#mfCorpo .mf-riga[data-t]')).filter(function(x){ return x.getAttribute('data-t') === MF.nuovaDopo; })[0]; if (r){ r.after(nr); nr.setAttribute('data-dopo', MF.nuovaDopo); nr.classList.remove('piena'); } }
    MF.nuovaDopo = '';
    const n = nr && nr.querySelector('.mf-t'); if (n) n.focus();
  }
  mfTappaPaint();
}

/* ---------- la lista vera: una riga per cosa, si scrive sotto ---------- */
function mfListaHtml(iso, titolo){
  const righe = stRigheDi(iso);
  let prio = ''; try{ prio = stPriorita(iso, righe) || ''; }catch(_){ }
  const aperte = righe.filter(function(r){ return !stIsDone(r, iso); });
  const fatte = righe.filter(function(r){ return stIsDone(r, iso); });
  const oggi = iso === mfIso(0);
  return '<p class="st-onelbl">' + titolo + '</p>'
    + '<div class="mf-lista" data-iso="' + iso + '">'
    + aperte.map(function(r){ return mfRigaHtml(iso, r, r === prio, false, oggi); }).join('')
    + '<div class="mf-riga mf-nuova' + (aperte.length ? ' piena' : '') + '"><span class="mf-box vuota"></span><div class="mf-t" contenteditable="true"' + (aperte.length ? '' : ' data-ph="Scrivi una cosa, e invio"') + ' onkeydown="mfTasto(event,this)" onblur="mfNuovaBlur(this)"></div></div>'
    + '</div>'
    + (fatte.length ? '<details class="st-fatte"><summary><b>Completate</b><small>' + fatte.length + '</small></summary>'
        + fatte.map(function(r){ return mfRigaHtml(iso, r, false, true, oggi); }).join('') + '</details>' : '');
}
function mfRigaHtml(iso, r, prio, fatta, oggi){
  const q = JSON.stringify(r).replace(/"/g, '&quot;');
  return '<div class="mf-riga' + (fatta ? ' fatta' : '') + (prio ? ' prio' : '') + '" data-t="' + esc(r) + '">'
    + '<button type="button" class="mf-box' + (fatta ? ' on' : '') + '" onclick="mfSpunta(\'' + iso + '\',' + q + ')" aria-label="' + (fatta ? 'Togli la spunta' : 'Segna come fatta') + '">' + (fatta ? '✓' : '') + '</button>'
    + (prio ? '<i class="mf-stella" title="La priorità">★</i>' : '')
    + '<div class="mf-t"' + (fatta ? '' : ' contenteditable="true" onkeydown="mfTasto(event,this)" onblur="mfRinomina(this)"') + ' data-v="' + esc(r) + '">' + esc(r) + '</div>'
    + (fatta ? '' : '<button type="button" class="mf-piu" onmousedown="event.preventDefault()" onclick="mfMenu(event,\'' + iso + '\',' + q + ')" aria-label="Altro">⋯</button>')
    + '</div>';
}
function mfRidisegna(soloQui){
  const c = document.getElementById('mfCorpo'); if (c){ c.innerHTML = mfCorpo(STN.tab); mfDopo(); }
  /* 0.9.286: il calendario della Roadmap usa lo stesso mese (MF.mese, MF.giorno): si ridisegna anche lui */
  if (!soloQui && typeof RMP !== 'undefined' && RMP.tab === 'cal' && typeof rmpPaint === 'function') try{ rmpPaint(); }catch(_){ }
}
function mfSpunta(iso, t){ try{ stSpunta(t, iso, mfRidisegna); }catch(_){ } }
function mfAggiungi(iso, t){
  t = String(t || '').replace(/\s+/g, ' ').trim(); if (!t) return false;
  return window.flPiano ? window.flPiano.aggiungi(iso, t) : false;
}
/* 0.9.227, COME UNA TO-DO LIST VERA (Notion):
   - invio a meta' riga: il testo dopo il cursore va su una casella nuova, subito sotto;
   - invio a fine riga: la riga nuova si apre subito sotto (non in fondo al foglio);
   - Backspace all'inizio di una riga: la riga si unisce a quella sopra (vuota, sparisce). */
function mfCaret(el){
  const s = window.getSelection(); if (!s || !s.rangeCount || !el.contains(s.anchorNode)) return el.textContent.length;
  const r = s.getRangeAt(0).cloneRange(); r.selectNodeContents(el); r.setEnd(s.getRangeAt(0).endContainer, s.getRangeAt(0).endOffset); return r.toString().length;
}
function mfCursore(el, at){
  el.focus();
  try{
    let resto = at; const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n = w.nextNode();
    while (n){ if (resto <= n.textContent.length){ const r = document.createRange(); r.setStart(n, resto); r.collapse(true); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); return; } resto -= n.textContent.length; n = w.nextNode(); }
    const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
  }catch(_){ }
}
/* la cosa `testo` va subito dopo `dopoDi`, nell'ordine del giorno */
function mfMettiDopo(iso, testo, dopoDi){
  const tutte = stRigheDi(iso).filter(function(r){ return r !== testo; });
  const i = tutte.indexOf(dopoDi);
  tutte.splice(i < 0 ? tutte.length : i + 1, 0, testo);
  try{ localStorage.setItem('fl_notes_' + iso, tutte.join('\n')); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
}
function mfTasto(e, el){
  const riga = el.closest('.mf-riga'); const lista = el.closest('.mf-lista'); if (!riga || !lista) return;
  const iso = lista.getAttribute('data-iso');
  const nuova = !!el.closest('.mf-nuova');
  const testo = el.textContent || '';
  const sel = window.getSelection(); const unico = !sel || sel.isCollapsed;
  if (e.key === 'Backspace' && unico && mfCaret(el) === 0){
    let su = riga.previousElementSibling;
    while (su && !su.querySelector('.mf-t[contenteditable]')) su = su.previousElementSibling;
    if (!su) return;
    e.preventDefault();
    const st = su.querySelector('.mf-t'); const prima = st.getAttribute('data-v') || st.textContent || '';
    const pulito = testo.replace(/\s+/g, ' ').trim();
    if (!nuova && el.getAttribute('data-v') && window.flPiano) window.flPiano.togli(iso, el.getAttribute('data-v'));
    if (nuova) el.textContent = '';
    const unito = pulito ? (prima + (prima && !/\s$/.test(prima) ? ' ' : '') + pulito).replace(/\s+/g, ' ').trim() : prima;
    if (unito !== prima && window.flPiano) window.flPiano.rinomina(iso, prima, unito);
    MF.fuocoTesto = { t: unito, at: prima.length };
    mfRidisegna();
    return;
  }
  if (e.key !== 'Enter' || e.shiftKey) return;
  e.preventDefault();
  if (nuova){
    const t = testo.replace(/\s+/g, ' ').trim();
    const dopoDi = riga.getAttribute('data-dopo');
    if (t && mfAggiungi(iso, t)){
      if (dopoDi) mfMettiDopo(iso, t, dopoDi);
      el.textContent = ''; MF.nuovaDopo = dopoDi ? t : ''; MF.fuoco = true; mfRidisegna();
    }
    return;
  }
  const v = el.getAttribute('data-v') || '';
  const o = mfCaret(el);
  const prima = testo.slice(0, o).replace(/\s+/g, ' ').trim(), dopo = testo.slice(o).replace(/\s+/g, ' ').trim();
  if (dopo && prima){
    /* a meta' riga: la riga si spezza in due caselle */
    if (prima !== v && window.flPiano) window.flPiano.rinomina(iso, v, prima);
    if (mfAggiungi(iso, dopo)) mfMettiDopo(iso, dopo, prima);
    MF.fuocoTesto = { t: dopo, at: 0 };
    mfRidisegna();
    return;
  }
  if (dopo && !prima){
    /* all'inizio: la riga scende di uno e sopra si apre una casella vuota */
    const nr = lista.querySelector('.mf-nuova'); if (!nr) return;
    riga.before(nr);
    let sopra = nr.previousElementSibling; while (sopra && !sopra.getAttribute('data-t')) sopra = sopra.previousElementSibling;
    if (sopra) nr.setAttribute('data-dopo', sopra.getAttribute('data-t')); else nr.removeAttribute('data-dopo');
    nr.classList.remove('piena'); nr.querySelector('.mf-t').focus();
    return;
  }
  /* a fine riga: la riga nuova si apre subito sotto */
  el.blur();
  const nr = lista.querySelector('.mf-nuova'); if (!nr) return;
  riga.after(nr); nr.setAttribute('data-dopo', v); nr.classList.remove('piena');
  setTimeout(function(){ const n = nr.querySelector('.mf-t'); if (n) n.focus(); }, 30);
}
function mfNuovaBlur(el){ const iso = el.closest('.mf-lista').getAttribute('data-iso'); if (el.textContent.trim() && mfAggiungi(iso, el.textContent)){ el.textContent = ''; mfRidisegna(); } }
function mfRinomina(el){
  const iso = el.closest('.mf-lista') ? el.closest('.mf-lista').getAttribute('data-iso') : mfIso(0);
  const prima = el.getAttribute('data-v'), ora = el.textContent.replace(/\s+/g, ' ').trim();
  if (!ora){ el.textContent = prima; return; }
  if (ora !== prima && window.flPiano && window.flPiano.rinomina(iso, prima, ora)) el.setAttribute('data-v', ora);
}

/* ---------- i tre puntini della riga ---------- */
function mfMenu(ev, iso, t){
  ev.stopPropagation();
  let m = document.getElementById('mfMenu'); if (m) m.remove();
  const oggi = iso === mfIso(0), domani = iso === mfIso(1);
  m = document.createElement('div'); m.id = 'mfMenu'; m.className = 'mf-menu';
  const q = JSON.stringify(t).replace(/"/g, '&quot;');
  m.innerHTML = (oggi ? '<button type="button" onclick="mfSposta(\'' + iso + '\',' + q + ',1)">➡️ Sposta a domani</button>' : '')
    + (domani ? '<button type="button" onclick="mfSposta(\'' + iso + '\',' + q + ',0)">⬅️ Sposta a oggi</button>' : '')
    + (!oggi && !domani ? '<button type="button" onclick="mfSposta(\'' + iso + '\',' + q + ',0)">⬅️ Sposta a oggi</button>' : '')
    + (oggi ? '<button type="button" onclick="mfMenuVia();try{STN.day=\'today\';stStimaSheet(stLines(\'today\').indexOf(' + q + '))}catch(_){}">▶ Inizia in Full Focus</button>' : '')
    + '<button type="button" onclick="mfMenuVia();try{stRigaOpen(' + q + ',\'' + iso + '\',\'s-home\')}catch(_){}">ⓘ Dettagli: passi e tempo</button>'
    + '<button type="button" class="via" onclick="mfTogli(\'' + iso + '\',' + q + ')">✕ Togli</button>';
  document.body.appendChild(m);
  const r = ev.currentTarget.getBoundingClientRect();
  m.style.top = Math.min(window.innerHeight - 220, r.bottom + 4) + 'px';
  m.style.right = Math.max(8, window.innerWidth - r.right) + 'px';
  setTimeout(function(){ document.addEventListener('click', function via(e){ if (e.target.closest && e.target.closest('#mfMenu')) return; mfMenuVia(); document.removeEventListener('click', via, true); }, true); }, 0);
}
function mfMenuVia(){ const m = document.getElementById('mfMenu'); if (m) m.remove(); }
function mfTogli(iso, t){ mfMenuVia(); if (window.flPiano) window.flPiano.togli(iso, t); mfRidisegna(); }
/** Sposta una riga nel giorno `off` (0 oggi, 1 domani): la sezione scelta e la stima la seguono. */
function mfSposta(iso, t, off){
  mfMenuVia();
  const dest = mfIso(off);
  if (dest === iso) return;
  if (!window.flPiano) return;
  let meta = {}; try{ meta = stMeta(t, iso) || {}; }catch(_){ }
  window.flPiano.aggiungi(dest, t);
  try{ if (Object.keys(meta).length) stMetaSave(t, dest, meta); }catch(_){ }
  window.flPiano.togli(iso, t);
  try{ flVibra([10, 40, 18]); }catch(_){ }
  toast(off === 1 ? 'Spostata a domani' : 'Spostata a oggi');
  mfRidisegna();
}

/* ---------- tieni premuto e trascina sulla scheda ---------- */
function mfDragAggancia(){
  const box = document.getElementById('mfCorpo'); if (!box || box._drag) return;
  box._drag = true;
  /* mentre si trascina la pagina non deve scorrere: senza questo il telefono si prendeva il
     gesto per scorrere, annullava il trascinamento (pointercancel) e la riga restava li' */
  box.addEventListener('touchmove', function(e){ if (MF.drag) e.preventDefault(); }, { passive: false });
  /* 0.9.219: si prende la riga tenendo premuto OVUNQUE, anche sulla casella. Il trascinamento
     parte a 350 ms, prima che il telefono cominci a selezionare il testo (che arriva verso i
     500 ms); la selezione e il menu del testo restano bloccati mentre il dito e' giu', e il tocco
     che chiude il trascinamento non spunta la casella. */
  box.addEventListener('pointerdown', function(e){
    const riga = e.target.closest && e.target.closest('.mf-riga:not(.mf-nuova):not(.fatta)');
    if (!riga || e.target.closest('.mf-piu')) return;
    const x0 = e.clientX, y0 = e.clientY;
    MF.premuto = true;
    const t = setTimeout(function(){ MF.premuto = false; mfDragInizia(riga, x0, y0, e.pointerId); }, 350);
    const annulla = function(ev){ if (ev.type !== 'pointermove' || Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) > 10){ clearTimeout(t); MF.premuto = false; box.removeEventListener('pointermove', annulla); window.removeEventListener('pointerup', annulla); window.removeEventListener('pointercancel', annulla); } };
    box.addEventListener('pointermove', annulla); window.addEventListener('pointerup', annulla); window.addEventListener('pointercancel', annulla);
  });
  const blocca = function(e){ if (MF.drag || MF.premuto) e.preventDefault(); };
  box.addEventListener('selectstart', blocca);
  box.addEventListener('contextmenu', blocca);
  /* il tocco che lascia la riga dopo il trascinamento non e' un tocco sulla casella */
  box.addEventListener('click', function(e){ if (MF.trascinata && Date.now() - MF.trascinata < 500){ e.preventDefault(); e.stopPropagation(); } }, true);
}
function mfDragInizia(riga, x, y){
  const iso = riga.closest('.mf-lista') ? riga.closest('.mf-lista').getAttribute('data-iso') : '';
  const t = riga.getAttribute('data-t'); if (!iso || !t) return;
  try{ document.activeElement && document.activeElement.blur && document.activeElement.blur(); }catch(_){ }
  try{ window.getSelection().removeAllRanges(); }catch(_){ }
  document.body.classList.add('mf-trascino');
  try{ flVibra(25); }catch(_){ }
  const g = riga.cloneNode(true); g.className += ' mf-fantasma';
  const r = riga.getBoundingClientRect();
  g.style.width = r.width + 'px'; g.style.left = r.left + 'px'; g.style.top = r.top + 'px';
  document.body.appendChild(g); riga.classList.add('mf-presa');
  document.querySelectorAll('#mfTabs [data-k]').forEach(function(b){ const k = b.getAttribute('data-k'); if ((k === 'oggi' && iso !== mfIso(0)) || (k === 'domani' && iso !== mfIso(1)) || k === 'note') b.classList.add('mf-meta'); });
  MF.drag = { iso: iso, t: t, g: g, dx: x - r.left, dy: y - r.top, su: null };
  const muovi = function(e){
    e.preventDefault();
    g.style.left = (e.clientX - MF.drag.dx) + 'px'; g.style.top = (e.clientY - MF.drag.dy) + 'px';
    g.style.visibility = 'hidden'; const sotto = document.elementFromPoint(e.clientX, e.clientY); g.style.visibility = '';
    const tab = sotto && sotto.closest ? sotto.closest('#mfTabs .mf-meta') : null;
    document.querySelectorAll('#mfTabs .mf-sopra').forEach(function(b){ if (b !== tab) b.classList.remove('mf-sopra'); });
    if (tab && !tab.classList.contains('mf-sopra')){ tab.classList.add('mf-sopra'); try{ flVibra(8); }catch(_){ } }
    MF.drag.su = tab ? tab.getAttribute('data-k') : null;
    /* nella lista: la riga sbiadita va nel punto dove sta il dito, come il blocco di Notion */
    const lista = riga.parentElement;
    if (!tab && lista){
      const altre = Array.from(lista.querySelectorAll('.mf-riga:not(.mf-nuova):not(.mf-presa)'));
      let prima = null;
      for (let i = 0; i < altre.length; i++){ const rr = altre[i].getBoundingClientRect(); if (e.clientY < rr.top + rr.height / 2){ prima = altre[i]; break; } }
      const nuova = lista.querySelector('.mf-nuova');
      const dove = prima || nuova;
      if (dove && riga.nextElementSibling !== dove){ lista.insertBefore(riga, dove); MF.drag.mosso = true; try{ flVibra(5); }catch(_){ } }
    }
  };
  const fine = function(){
    window.removeEventListener('pointermove', muovi); window.removeEventListener('pointerup', fine); window.removeEventListener('pointercancel', fine);
    const d = MF.drag; MF.drag = null; if (!d) return;
    MF.trascinata = Date.now();
    d.g.remove(); riga.classList.remove('mf-presa'); document.body.classList.remove('mf-trascino');
    document.querySelectorAll('#mfTabs .mf-meta').forEach(function(b){ b.classList.remove('mf-meta', 'mf-sopra'); });
    if (!d.su && d.mosso) mfRiordina(d.iso, riga.parentElement);
    else if (d.su === 'oggi') mfSposta(d.iso, d.t, 0);
    else if (d.su === 'domani') mfSposta(d.iso, d.t, 1);
    else if (d.su === 'note'){ if (typeof cvAggiungi === 'function' && cvAggiungi(d.t, false)){ window.flPiano && window.flPiano.togli(d.iso, d.t); toast('Nel caveau delle idee: la rileggi ' + cvQuandoTxt()); mfRidisegna(); } }
  };
  window.addEventListener('pointermove', muovi, { passive: false }); window.addEventListener('pointerup', fine); window.addEventListener('pointercancel', fine);
}

/** Il nuovo ordine della lista, preso dalle righe come stanno adesso: le fatte restano in fondo. */
function mfRiordina(iso, lista){
  if (!lista) return;
  const nuove = Array.from(lista.querySelectorAll('.mf-riga:not(.mf-nuova)')).map(function(r){ return r.getAttribute('data-t'); }).filter(Boolean);
  const tutte = stRigheDi(iso);
  const resto = tutte.filter(function(r){ return nuove.indexOf(r) < 0; });
  try{ localStorage.setItem('fl_notes_' + iso, nuove.concat(resto).join('\n')); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
  try{ flVibra([8, 30, 14]); }catch(_){ }
  mfRidisegna();
}

/* ---------- sotto al foglio: la prossima tappa (gratis) o il tuo agente personale (Premium) ----------
   Andrea: sotto al pannello torna «L'oracolo del giorno · La prossima tappa». Con Premium al
   suo posto c'e' il tuo agente personale: se nel giorno c'e' gia' qualcosa lo RIVEDE, se e' vuoto ti
   scrive un piano per rompere l'inerzia. Il giorno e' quello della scheda aperta. */
/* il chevron e' un'icona SVG, non il carattere «›» (regola del 10/10/2026) */
const MF_CHEV = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
function mfPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function mfTappaHtml(){
  if (!mfPremium()){
    return '<div class="mf-tappa" onclick="if(typeof orcApri===\'function\')orcApri(\'mappa\')"><img src="img/genio/genio-pensa.png" alt=""><div><small>L’oracolo del giorno</small><b>La prossima tappa</b><p>Tre domande, e il Genio ti dice l’unica cosa da fare.</p></div><span class="mf-tappa-v">' + MF_CHEV + '</span></div>';
  }
  const domani = STN.tab === 'domani';
  const iso = mfIso(domani ? 1 : 0);
  const n = stRigheDi(iso).filter(function(r){ return !stIsDone(r, iso); }).length;
  const quando = domani ? 'domani' : 'oggi';
  const titolo = n ? 'Il tuo agente personale rivede il piano di ' + quando : 'Il tuo agente personale ti scrive il piano di ' + quando;
  const testo = n ? 'Hai scritto ' + n + (n === 1 ? ' cosa' : ' cose') + '. Ti dice cosa togliere, cosa spostare e da dove partire.' : 'Non sai da dove partire? Ti scrive tre cose al massimo, la prima piccola, per rompere l’inerzia.';
  /* scuro, come «Il tuo agente personale» nella Roadmap: su una pagina tutta bianca deve staccare */
  return '<div class="mf-tappa ag scuro" onclick="mfAgentePiano()"><span class="mf-tappa-ag">🧞</span><div><small>Il tuo agente personale</small><b>' + titolo + '</b><p>' + testo + '</p></div><span class="mf-tappa-v">' + MF_CHEV + '</span></div>';
}
function mfAgentePiano(){
  const domani = STN.tab === 'domani';
  const iso = mfIso(domani ? 1 : 0), quando = domani ? 'domani' : 'oggi';
  const righe = stRigheDi(iso).filter(function(r){ return !stIsDone(r, iso); });
  const testo = righe.length
    ? 'Rivedi il mio piano di ' + quando + ':\n' + righe.map(function(r){ return '• ' + r; }).join('\n') + '\nDimmi cosa togliere, cosa spostare e in che ordine farle, partendo dalla mia rotta.'
    : 'Scrivimi il piano di ' + quando + ' partendo dalla mia rotta: tre cose al massimo, la prima piccola, per rompere l’inerzia.';
  /* la chat si apre SOPRA la Mappa (come Notion AI): niente avanti e indietro fra le pagine */
  if (typeof agPopover === 'function'){ agPopover(testo, { titolo: domani ? 'Il piano di domani' : 'Il piano di oggi' }); return; }
  if (typeof agNuovaConversazione === 'function'){ agNuovaConversazione(testo); return; }
  if (typeof agApri === 'function'){ agApri(); setTimeout(function(){ const a = document.getElementById('agTesto'); if (a){ a.value = testo; a.focus(); } }, 450); }
}
function mfTappaPaint(){ const tp = document.getElementById('mppTappa'); if (!tp) return; tp.innerHTML = mfTappaHtml(); tp.hidden = false; }

/* ---------- il calendario ---------- */
function mfCalHtml(){
  const oggi = new Date(); const m = MF.mese || new Date(oggi.getFullYear(), oggi.getMonth(), 1);
  MF.mese = m;
  const conta = mfConteggi(m.getFullYear(), m.getMonth());
  const primo = (m.getDay() + 6) % 7, giorni = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
  const isoOggi = mfIso(0);
  let celle = '';
  for (let i = 0; i < primo; i++) celle += '<i></i>';
  for (let d = 1; d <= giorni; d++){
    const iso = m.getFullYear() + '-' + String(m.getMonth() + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
    const c = conta[iso];
    celle += '<button type="button" class="mf-g' + (iso === isoOggi ? ' oggi' : '') + (iso === MF.giorno ? ' sel' : '') + '" onclick="mfCalGiorno(\'' + iso + '\')"><b>' + d + '</b>' + (c ? '<em class="' + (c.f >= c.t ? 'tutte' : '') + '"></em>' : '') + '</button>';
  }
  const sel = MF.giorno || isoOggi;
  const selD = new Date(sel + 'T12:00:00');
  const off = Math.round((selD - new Date(isoOggi + 'T12:00:00')) / 86400000);
  const chiuso = off === 1 && typeof pnDomaniAperto === 'function' && !pnDomaniAperto();
  const nome = off === 0 ? 'Oggi' : off === 1 ? 'Domani' : off === -1 ? 'Ieri' : selD.getDate() + ' ' + MF_MESI[selD.getMonth()];
  return '<div class="mf-cal">'
    + '<div class="mf-cal-h"><b>' + MF_MESI[m.getMonth()] + ' ' + m.getFullYear() + '</b><span><button type="button" onclick="mfCalMese(-1)" aria-label="Mese prima">‹</button><button type="button" class="mf-oggi" onclick="mfCalMese(0)">Oggi</button><button type="button" onclick="mfCalMese(1)" aria-label="Mese dopo">›</button></span></div>'
    + '<div class="mf-cal-gs">' + ['lun', 'mar', 'mer', 'gio', 'ven', 'sab', 'dom'].map(function(g){ return '<span>' + g + '</span>'; }).join('') + '</div>'
    + '<div class="mf-cal-grid">' + celle + '</div></div>'
    + (chiuso ? pnLucchettoHtml() : mfListaHtml(sel, nome.charAt(0).toUpperCase() + nome.slice(1)));
}
function mfConteggi(anno, mese){
  const out = {}, pre = 'fl_notes_' + anno + '-' + String(mese + 1).padStart(2, '0') + '-';
  for (let i = 0; i < localStorage.length; i++){
    const k = localStorage.key(i) || ''; if (k.indexOf(pre) !== 0 || !/^fl_notes_\d{4}-\d{2}-\d{2}$/.test(k)) continue;
    const iso = k.slice(9), r = stRigheDi(iso); if (!r.length) continue;
    out[iso] = { t: r.length, f: r.filter(function(x){ return stIsDone(x, iso); }).length };
  }
  return out;
}
function mfCalMese(d){ const o = new Date(); MF.mese = d === 0 ? new Date(o.getFullYear(), o.getMonth(), 1) : new Date(MF.mese.getFullYear(), MF.mese.getMonth() + d, 1); if (d === 0) MF.giorno = mfIso(0); mfRidisegna(); }
function mfCalGiorno(iso){ MF.giorno = iso; try{ flVibra(6); }catch(_){ } mfRidisegna(); }

/* ---------- la pagina Notion collegata alla scheda Note ---------- */
function mfNotionNote(){
  try{
    const ws = JSON.parse(localStorage.getItem('fl_notion_ws') || 'null'); if (!ws || !ws.pages) return '';
    const p = ws.pages.filter(function(x){ return x && x.collega === 'note'; })[0]; if (!p) return '';
    /* anche quello che sta dentro agli elenchi espandibili (children), in ordine */
    const piatti = []; (function giu(l){ (l || []).forEach(function(b){ piatti.push(b); giu(b.children); }); })(p.blocks);
    const righe = piatti.map(function(b){ return String(b.text || '').trim(); }).filter(Boolean).slice(0, 12);
    return '<div class="mf-nt"><div class="mf-nt-h"><span>' + esc(p.emoji || '📄') + '</span><b>' + esc(p.title || 'Senza titolo') + '</b><button type="button" onclick="stFullOpen()">Apri ›</button></div>'
      + (righe.length ? righe.map(function(r){ return '<p>• ' + esc(r) + '</p>'; }).join('') : '<p class="mf-vuoto">La pagina è vuota.</p>') + '</div>';
  }catch(_){ return ''; }
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* 0.9.308: le linguette restano DENTRO il pannello (Calendario usciva a sinistra, vedi righe-scorrevoli.js anello) */
    '.mf-note{overflow-x:clip}.mf-head{display:flex;align-items:center;gap:4px;margin:0 -4px 8px}',
    '.mf-tabs{flex:1;min-width:0;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px 2px 4px}.mf-tabs::-webkit-scrollbar{display:none}',
    '.mf-tabs .st-daytab{flex:none;white-space:nowrap;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}',
    '.mf-tabs .st-daytab.mf-tab-presa{opacity:.3}',
    '.mf-tab-fant{position:fixed!important;z-index:9999;pointer-events:none;margin:0!important;transform:scale(1.06);opacity:.94;box-shadow:0 0 0 1.5px #0075E3,0 10px 24px rgba(15,32,65,.25)!important;display:inline-flex;align-items:center;justify-content:center;white-space:nowrap}',
    '.mf-veloci{margin:2px 0 12px}.mf-veloci .mn-veloci{margin:0}',
    '.mf-tab-in{flex:none;border:0;outline:2px solid #0075E3;font:inherit}',
    '.mf-tmenu-velo{position:fixed;inset:0;z-index:9400}.mf-tmenu{position:absolute;width:220px;background:var(--card,#fff);border-radius:14px;box-shadow:0 0 0 1px var(--line,#E5ECF6),0 14px 34px rgba(15,32,65,.22);padding:6px}',
    '.mf-tmenu button{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;border-radius:10px;padding:11px 10px;font:600 14.5px var(--font-body);color:var(--navy,#14234A);text-align:left;cursor:pointer}.mf-tmenu button:active{background:#EEF3FB}.mf-tmenu .mf-tmenu-via{color:#D93A3A}',
    '.mf-tabs .st-daytab.mf-meta{outline:2px dashed #0075E3;outline-offset:2px}.mf-tabs .st-daytab.mf-sopra{background:#0075E3 !important;color:#fff !important;transform:scale(1.08)}',
    '.mf-dots{flex:none;width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--navy);font:900 20px var(--font-body);cursor:pointer;line-height:1}body.dark .mf-dots{color:#fff}',
    '#mppFoglio .mf-note > .st-dots{display:none}',
    '.mf-lista{display:flex;flex-direction:column}',
    '.mf-riga{display:flex;align-items:flex-start;gap:10px;padding:7px 2px;border-bottom:1px solid var(--line);position:relative;touch-action:pan-y}',
    '.mf-box{flex:none;width:22px;height:22px;margin-top:1px;border-radius:6px;border:2px solid #9AA8BD;background:transparent;color:#fff;font:900 13px var(--font-body);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.mf-box.on{background:#0075E3;border-color:#0075E3}.mf-box.vuota{border-style:dashed;opacity:.5}',
    '.mf-t{flex:1;min-width:0;outline:none;font:600 15px/1.45 var(--font-body);color:var(--navy);word-break:break-word;min-height:22px}body.dark .mf-t{color:#fff}',
    '.mf-t:empty::before{content:attr(data-ph);color:var(--muted);font-weight:500}',
    /* 0.9.234: sotto alla riga tratteggiata niente linea: c'e' gia' quella che separa le Completate */
    '.mf-lista>.mf-riga:last-child{border-bottom:0}',
    '.mf-nuova.piena .mf-box{opacity:.35}.mf-nuova.piena:not(:focus-within) .mf-t{min-height:22px}',
    '.mf-riga.fatta .mf-t{text-decoration:line-through;color:var(--muted)}',
    '.mf-stella{font-style:normal;color:#E63946;margin-top:1px}',
    /* i tre puntini si vedono solo sulla riga dove sta il cursore */
    '.mf-piu{flex:none;visibility:hidden;width:30px;height:26px;border:0;border-radius:8px;background:#E6F2FF;color:#0075E3;font:900 15px var(--font-body);cursor:pointer;padding:0}',
    '.mf-riga:focus-within .mf-piu{visibility:visible}',
    '.mf-menu{position:fixed;z-index:9000;min-width:220px;background:var(--card,#fff);border-radius:16px;box-shadow:0 14px 40px rgba(0,30,68,.22);padding:6px;display:flex;flex-direction:column}body.dark .mf-menu{background:#12203A}',
    '.mf-menu button{border:0;background:transparent;text-align:left;padding:11px 12px;border-radius:10px;font:600 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .mf-menu button{color:#fff}.mf-menu button:active{background:#E6F2FF}.mf-menu .via{color:#E63946}',
    '.mf-presa{opacity:.3;background:#E6F2FF;border-radius:10px}.mf-fantasma{position:fixed;z-index:9001;pointer-events:none;opacity:.6;background:var(--card,#fff);border-radius:12px;box-shadow:0 16px 40px rgba(0,30,68,.3);padding:8px 10px}',
    'body.mf-trascino,body.mf-trascino *{-webkit-user-select:none !important;user-select:none !important}.mf-t{-webkit-touch-callout:none}',
    '.mf-tappa{display:flex;align-items:center;gap:12px;margin:14px 0 0;padding:14px 16px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 8px 22px rgba(0,30,68,.08);cursor:pointer}body.dark .mf-tappa{background:#12203A;border-color:#22345A}',
    '.mf-tappa img{width:64px;height:64px;object-fit:contain;flex:none}.mf-tappa-ag{width:56px;height:56px;flex:none;border-radius:18px;background:linear-gradient(160deg,#3F9FF4,#005BB0);display:flex;align-items:center;justify-content:center;font-size:30px}',
    '.mf-tappa small{display:block;font:800 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.mf-tappa b{display:block;margin-top:2px;font:800 16px/1.25 var(--font-display);color:var(--navy)}body.dark .mf-tappa b{color:#fff}',
    '.mf-tappa p{margin:4px 0 0;font:500 13px/1.4 var(--font-body);color:var(--muted)}.mf-tappa > div{flex:1;min-width:0}.mf-tappa-v{display:flex;color:var(--muted)}',
    '.mf-tappa.scuro{background:linear-gradient(160deg,#0E1B3D,#16245A);border-color:#22345A;box-shadow:0 12px 28px rgba(0,20,60,.28)}.mf-tappa.scuro small{color:#8CC6FF}.mf-tappa.scuro b{color:#fff}.mf-tappa.scuro p{color:#B9C7E2}.mf-tappa.scuro .mf-tappa-v{color:#8CC6FF}',
    '.mf-cal{margin-bottom:10px}.mf-cal-h{display:flex;align-items:center;justify-content:space-between;margin:2px 0 8px}.mf-cal-h b{font:800 16px var(--font-body);color:var(--navy);text-transform:capitalize}body.dark .mf-cal-h b{color:#fff}',
    '.mf-cal-h span{display:flex;align-items:center;gap:2px}.mf-cal-h button{border:0;background:transparent;font:700 18px var(--font-body);color:var(--navy);padding:4px 8px;cursor:pointer}.mf-cal-h .mf-oggi{font-size:13.5px}body.dark .mf-cal-h button{color:#fff}',
    '.mf-cal-gs,.mf-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);text-align:center}.mf-cal-gs span{font:600 11.5px var(--font-body);color:var(--muted);padding:4px 0;border-bottom:1px solid var(--line)}',
    '.mf-g{border:0;background:transparent;height:44px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;cursor:pointer;padding:0}',
    '.mf-g b{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:600 14px var(--font-body);color:var(--navy)}body.dark .mf-g b{color:#fff}',
    '.mf-g.oggi b{background:#E63946;color:#fff}.mf-g.sel:not(.oggi) b{box-shadow:inset 0 0 0 2px #0075E3}',
    '.mf-g em{width:5px;height:5px;border-radius:50%;background:#9AA8BD}.mf-g em.tutte{background:#0075E3}',
    '.mf-nt{margin-top:12px;border:1px solid var(--line);border-radius:16px;padding:12px 14px}.mf-nt-h{display:flex;align-items:center;gap:8px}.mf-nt-h b{flex:1;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .mf-nt-h b{color:#fff}',
    '.mf-nt-h button{border:0;background:transparent;color:#0075E3;font:700 13px var(--font-body);cursor:pointer}.mf-nt p{margin:6px 0 0;font:500 14px/1.45 var(--font-body);color:var(--ink)}.mf-vuoto{color:var(--muted) !important}'
  ].join('');
  document.head.appendChild(st);
})();
