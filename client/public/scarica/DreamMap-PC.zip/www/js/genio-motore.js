/* ===========================================================================================
   IL MOTORE DEL GENIO (0.9.190) — come Limule, il motore di Akinator.

   COME FUNZIONA AKINATOR, E QUINDI QUESTO:
   · Un catalogo di «entita'» (personaggi, libri, film, tipi di persona) e un elenco di domande.
     Per ogni coppia entita'/domanda il motore sa con che probabilita' un giocatore che pensa
     a quella entita' risponde Si', Probabilmente si', Non lo so, Probabilmente no, No.
   · Ogni risposta MOLTIPLICA la probabilita' di ogni entita' per quella probabilita' (regola
     di Bayes). Nessuna entita' viene eliminata per una risposta sbagliata: scende e basta, e
     se le risposte dopo la riportano su, torna in gara. E' quello che rende Akinator capace di
     indovinare anche quando il giocatore sbaglia una o due risposte.
   · La domanda successiva e' quella che, in media, lascia MENO incertezza (massimo guadagno
     di informazione sull'entropia delle entita' ancora in gioco). Un po' di caso fra le
     domande quasi migliori: due partite sullo stesso personaggio non sono mai identiche.
   · C'e' un'entita' in piu', «una cosa che non conosco», che risponde come la media di tutte.
     Quando vince lei, il Genio sa di non sapere: e' il momento di chiedere aiuto al cervello
     grande (il server) o di farsi insegnare la risposta.
   · IMPARA. A fine partita, se la risposta giusta e' nota, le risposte date si sommano alle
     statistiche di quella entita' (prima sul telefono, poi sul server per tutti): partita dopo
     partita il catalogo smette di essere quello che ha scritto chi l'ha compilato e diventa
     quello che rispondono le persone vere. E' il cuore di Limule.

   Questo file non tocca il DOM: gira anche in node (tools/test-genio.js lo collauda con migliaia
   di partite simulate).
   =========================================================================================== */

/* le cinque risposte, nell'ordine dei calcoli (i pulsanti a schermo hanno il loro ordine) */
const GM_RISP = ['si', 'ps', 'ns', 'pn', 'no'];
const GM_ETICHETTE = { si: 'Sì', ps: 'Probabilmente sì', ns: 'Non lo so', pn: 'Probabilmente no', no: 'No' };
/* I CINQUE LIVELLI DEL CATALOGO e come rispondono i giocatori a ciascuno. Code larghe di
   proposito: un «No» detto a un'entita' da «Si'» la abbassa di tredici volte, non di cento.
   E' la tolleranza all'errore. Tarate con le partite simulate (tools/test-genio.js). */
const GM_LIV = 'Yy?nN';
const GM_DIST = [
  /* Y */ [0.62, 0.20, 0.07, 0.06, 0.05],
  /* y */ [0.32, 0.30, 0.12, 0.14, 0.12],
  /* ? */ [0.20, 0.20, 0.20, 0.20, 0.20],
  /* n */ [0.12, 0.14, 0.12, 0.30, 0.32],
  /* N */ [0.05, 0.06, 0.07, 0.20, 0.62]
];
const GM_PESO_PRIOR = 4;      /* quante «partite finte» vale l'annotazione, contro le partite vere */
const GM_POP = [0.25, 0.4, 0.7, 1, 1.6, 2.6];
const GM_IGNOTO = 0.12;       /* la probabilita' iniziale di «una cosa che non conosco» */
const GM_LIMITI = [22, 32, 42];   /* a queste domande il Genio prova comunque a indovinare */
const GM_MAX_DOMANDE = 50;

function gmIdx(r){ const i = GM_RISP.indexOf(r); return i < 0 ? 2 : i; }

/* ---------- il catalogo ---------- */
/** Prepara il catalogo per i calcoli: livelli in array, indici delle domande, la colonna
 *  dell'ignoto. `appresi` = {entita: {domanda: [5 conteggi]}} dalle partite vere. */
function gmPrepara(kb, appresi){
  const Q = kb.domande.length, E = kb.entita.length;
  const qi = {}; kb.domande.forEach(function(q, i){ qi[q.id] = i; });
  const liv = new Uint8Array(E * Q);
  kb.entita.forEach(function(e, k){
    /* il profilo puo' arrivare come stringa (un carattere per domanda, nell'ordine) o come
       oggetto {domanda: livello}: le domande non scritte valgono «?» */
    if (e.r && typeof e.r === 'object'){
      kb.domande.forEach(function(q, j){ const l = GM_LIV.indexOf(e.r[q.id] || '?'); liv[k * Q + j] = l < 0 ? 2 : l; });
      return;
    }
    const a = String(e.a || '');
    for (let j = 0; j < Q; j++){ const c = a.charAt(j); const l = GM_LIV.indexOf(c); liv[k * Q + j] = l < 0 ? 2 : l; }
  });
  const ei = {}; kb.entita.forEach(function(e, k){ ei[e.id] = k; });
  const prior = new Float64Array(E);
  kb.entita.forEach(function(e, k){ prior[k] = GM_POP[Math.max(0, Math.min(5, e.pop | 0))] * (1 + Math.log(1 + (e.vinte || 0)) * 0.3); });
  const kbp = { kb: kb, Q: Q, E: E, qi: qi, ei: ei, liv: liv, prior: prior, appresi: appresi || {}, ignoto: null };
  /* l'ignoto risponde come la media del catalogo, domanda per domanda */
  const ign = new Float64Array(Q * 5);
  for (let j = 0; j < Q; j++){
    for (let k = 0; k < E; k++){ const d = gmDist(kbp, k, j); for (let r = 0; r < 5; r++) ign[j * 5 + r] += d[r]; }
    for (let r = 0; r < 5; r++) ign[j * 5 + r] = E ? ign[j * 5 + r] / E : 0.2;
  }
  kbp.ignoto = ign;
  return kbp;
}
/** P(risposta | entita', domanda): l'annotazione come prior, le partite vere sopra. */
function gmDist(kbp, k, j){
  const base = GM_DIST[kbp.liv[k * kbp.Q + j]];
  const e = kbp.kb.entita[k];
  const ap = kbp.appresi[e.id];
  const c = ap && ap[kbp.kb.domande[j].id];
  if (!c) return base;
  let n = 0; for (let r = 0; r < 5; r++) n += c[r] || 0;
  if (!n) return base;
  const out = new Array(5);
  for (let r = 0; r < 5; r++) out[r] = (base[r] * GM_PESO_PRIOR + (c[r] || 0)) / (GM_PESO_PRIOR + n);
  return out;
}

/* ---------- la partita ---------- */
function gmNuova(kbp, opz){
  opz = opz || {};
  const E = kbp.E;
  const lp = new Float64Array(E + 1);
  let tot = 0; for (let k = 0; k < E; k++) tot += kbp.prior[k];
  for (let k = 0; k < E; k++) lp[k] = Math.log(kbp.prior[k] / tot * (1 - GM_IGNOTO));
  lp[E] = Math.log(opz.ignoto != null ? opz.ignoto : GM_IGNOTO);
  return { kbp: kbp, lp: lp, chieste: [], risposte: {}, rifiutate: [], storia: [], tentativi: 0, n: 0,
           seme: opz.seme != null ? opz.seme : Math.floor(Math.random() * 1e9), vietate: opz.vietate || null };
}
/* un generatore di numeri a seme: le partite simulate si ripetono uguali */
function gmCaso(P){ P.seme = (P.seme * 1103515245 + 12345) % 2147483648; return P.seme / 2147483648; }

/** Le probabilita' normalizzate delle entita' piu' vive (le altre valgono zero nei calcoli). */
function gmVive(P, K){
  const E = P.kbp.E, lp = P.lp;
  let max = -Infinity; for (let k = 0; k <= E; k++) if (lp[k] > max) max = lp[k];
  const idx = [];
  for (let k = 0; k < E; k++) if (lp[k] > max - 14) idx.push(k);
  if (idx.length > K){ idx.sort(function(a, b){ return lp[b] - lp[a]; }); idx.length = K; }
  let z = Math.exp(lp[E] - max);
  const p = idx.map(function(k){ const v = Math.exp(lp[k] - max); z += v; return v; });
  return { idx: idx, p: p.map(function(v){ return v / z; }), pIgnoto: Math.exp(lp[E] - max) / z };
}
function gmEntropia(arr, extra){
  let h = 0, s = 0;
  for (let i = 0; i < arr.length; i++){ const x = arr[i]; s += x; if (x > 0) h -= x * Math.log(x); }
  if (extra > 0){ s += extra; h -= extra * Math.log(extra); }
  if (s <= 0) return 0;
  /* entropia della distribuzione normalizzata: H(p/s) = (H(p) + s ln s) / s */
  return h / s + Math.log(s);
}
/** La prossima domanda: massimo guadagno di informazione, con un po' di caso fra le migliori. */
function gmProssima(P){
  if (P.n >= GM_MAX_DOMANDE) return null;
  const kbp = P.kbp, Q = kbp.Q, E = kbp.E;
  const v = gmVive(P, 220);
  const h0 = gmEntropia(v.p, v.pIgnoto);
  const cand = [];
  const pe = new Float64Array(v.idx.length);
  for (let j = 0; j < Q; j++){
    const id = kbp.kb.domande[j].id;
    if (P.risposte[id] !== undefined) continue;
    if (P.vietate && P.vietate[id]) continue;
    let atteso = 0;
    for (let r = 0; r < 5; r++){
      let pa = 0;
      for (let i = 0; i < v.idx.length; i++){ const d = gmDist(kbp, v.idx[i], j); pe[i] = v.p[i] * d[r]; pa += pe[i]; }
      const pu = v.pIgnoto * kbp.ignoto[j * 5 + r]; pa += pu;
      if (pa <= 0) continue;
      atteso += pa * gmEntropia(pe, pu);
    }
    cand.push({ j: j, g: h0 - atteso });
  }
  if (!cand.length) return null;
  cand.sort(function(a, b){ return b.g - a.g; });
  const best = cand[0].g;
  /* all'inizio piu' varieta' (le prime tre domande cambiano da una partita all'altra), poi
     quasi sempre la migliore */
  const soglia = P.n < 3 ? 0.82 : 0.93;
  const vicine = cand.filter(function(c){ return c.g >= best * soglia; }).slice(0, P.n < 3 ? 5 : 3);
  const scelta = vicine[Math.floor(gmCaso(P) * vicine.length)] || cand[0];
  return kbp.kb.domande[scelta.j];
}
/** Una risposta: si moltiplica, non si elimina. `peso` < 1 per le risposte dedotte dai dati. */
function gmRispondi(P, qid, r, peso){
  const kbp = P.kbp, j = kbp.qi[qid];
  if (j === undefined) return;
  P.storia.push({ lp: P.lp.slice(), chieste: P.chieste.slice(), risposte: Object.assign({}, P.risposte), n: P.n });
  if (P.storia.length > 30) P.storia.shift();
  const ri = gmIdx(r), w = peso == null ? 1 : peso;
  for (let k = 0; k < kbp.E; k++){ if (P.lp[k] === -Infinity) continue; P.lp[k] += w * Math.log(gmDist(kbp, k, j)[ri]); }
  P.lp[kbp.E] += w * Math.log(kbp.ignoto[j * 5 + ri]);
  P.chieste.push(qid); P.risposte[qid] = r; P.n++;
  gmRiscala(P);
}
function gmRiscala(P){
  let max = -Infinity; for (let k = 0; k < P.lp.length; k++) if (P.lp[k] > max) max = P.lp[k];
  if (isFinite(max)) for (let k = 0; k < P.lp.length; k++) if (P.lp[k] !== -Infinity) P.lp[k] -= max;
}
function gmAnnulla(P){
  const s = P.storia.pop(); if (!s) return false;
  P.lp = s.lp; P.chieste = s.chieste; P.risposte = s.risposte; P.n = s.n;
  return true;
}
/** Le entita' in testa, con la loro probabilita'. */
function gmCandidati(P, K){
  const v = gmVive(P, Math.max(K || 5, 5));
  const out = v.idx.map(function(k, i){ return { e: P.kbp.kb.entita[k], k: k, p: v.p[i] }; });
  out.sort(function(a, b){ return b.p - a.p; });
  return { lista: out.slice(0, K || 5), ignoto: v.pIgnoto };
}
/** E' il momento di provare a indovinare? {tipo:'ipotesi', e, p} | {tipo:'ignoto'} | null */
function gmIpotesi(P){
  const c = gmCandidati(P, 3);
  const t = c.lista[0], s = c.lista[1];
  const n = P.n;
  const limite = GM_LIMITI[Math.min(P.tentativi, GM_LIMITI.length - 1)];
  if (!t) return n >= 6 ? { tipo: 'ignoto' } : null;
  const p1 = t.p, p2 = s ? s.p : 0;
  if (p1 >= 0.90 && n >= 6) return { tipo: 'ipotesi', e: t.e, p: p1 };
  if (p1 >= 0.78 && n >= 10 && p1 >= 6 * p2) return { tipo: 'ipotesi', e: t.e, p: p1 };
  /* al limite si prova comunque, come Akinator: anche quando il catalogo sembra non saperlo */
  if (n >= limite) return { tipo: 'ipotesi', e: t.e, p: p1, forzata: true };
  if (c.ignoto >= 0.62 && n >= 14 && p1 < 0.3) return { tipo: 'ignoto', p: c.ignoto, migliore: t };
  return null;
}
function gmRifiuta(P, eid){
  const k = P.kbp.ei[eid]; if (k === undefined) return;
  P.lp[k] = -Infinity; P.rifiutate.push(eid); P.tentativi++;
  gmRiscala(P);
}
/** La partita e' persa? Tre ipotesi sbagliate, o troppe domande. */
function gmFinita(P){ return P.tentativi >= GM_LIMITI.length || P.n >= GM_MAX_DOMANDE; }

/* ---------- imparare ---------- */
/** Le risposte di una partita finita si sommano alla entita' giusta: {appresi} aggiornato. */
function gmImpara(appresi, eid, risposte){
  appresi = appresi || {};
  const a = appresi[eid] = appresi[eid] || {};
  Object.keys(risposte || {}).forEach(function(q){
    const r = gmIdx(risposte[q]);
    const c = a[q] = a[q] || [0, 0, 0, 0, 0];
    c[r] = (c[r] || 0) + 1;
  });
  return appresi;
}
/** Un'entita' nuova, insegnata da chi ha giocato: le risposte diventano il suo profilo. */
function gmEntitaDaRisposte(kb, nome, risposte, extra){
  let a = '';
  kb.domande.forEach(function(q){
    const r = risposte[q.id];
    a += r === 'si' ? 'Y' : r === 'ps' ? 'y' : r === 'pn' ? 'n' : r === 'no' ? 'N' : '?';
  });
  const id = 'u_' + String(nome).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40);
  return Object.assign({ id: id, n: String(nome).trim().slice(0, 60), d: '', pop: 2, a: a, insegnata: true }, extra || {});
}
/** Trova un'entita' dal nome scritto (senza accenti, maiuscole, articoli). */
function gmNorm(s){ return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/^(il|lo|la|i|gli|le|l'|un|una|uno|the)\s+/, '').replace(/[^a-z0-9]+/g, ' ').trim(); }
function gmCerca(kb, testo, max){
  const t = gmNorm(testo); if (!t) return [];
  const out = [];
  kb.entita.forEach(function(e){
    const n = gmNorm(e.n);
    let s = 0;
    if (n === t) s = 100;
    else if (n.indexOf(t) === 0) s = 80;
    else if (n.indexOf(' ' + t) >= 0) s = 60;
    else if (n.indexOf(t) >= 0) s = 40;
    else if (e.alias && e.alias.some(function(x){ return gmNorm(x).indexOf(t) >= 0; })) s = 50;
    if (s) out.push({ e: e, s: s + (e.pop || 0) });
  });
  out.sort(function(a, b){ return b.s - a.s; });
  return out.slice(0, max || 6).map(function(x){ return x.e; });
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { GM_RISP, GM_ETICHETTE, GM_DIST, GM_LIMITI, GM_MAX_DOMANDE, gmPrepara, gmDist, gmNuova, gmProssima, gmRispondi, gmAnnulla,
    gmCandidati, gmIpotesi, gmRifiuta, gmFinita, gmImpara, gmEntitaDaRisposte, gmCerca, gmNorm, gmVive };
}
