/* academy.js — Academy, Esplora e Aiuto: le tre sezioni che AppBlock tiene fuori dal blocco.

   L'Academy è un corso in cinque moduli, ognuno con le sue lezioni. A differenza di AppBlock
   le lezioni si leggono dentro l'app: un elenco di titoli che rimandano a un blog non ancora
   scritto sarebbe una fila di link morti. Quando gli articoli esisteranno, ACADEMY[..].url
   porterà là e il testo qui resterà come anteprima. */

/* ---------------------------------------------------------------------------------------
   Link esterni. Quelli vuoti sono canali che ancora non esistono: la card lo dice invece di
   aprire il nulla. Riempire qui e basta.
   --------------------------------------------------------------------------------------- */
const EXPLORE_LINKS = {
  desktop:  'https://dream-brothers.com/pages/focuslock-pc',
  whatsapp: '',      // canale WhatsApp DreamBrothers — da creare
  telegram: ''       // gruppo Telegram DreamBrothers — da creare
};

const ACADEMY = [
  { id:'contabile', icon:'🧮', name:'Il contabile interno',
    intro:'La motivazione non è una batteria che si scarica: è un contabile che decide se uno sforzo vale la pena. Capire come fa i conti cambia a che ora, e come, fai le cose che contano.',
    lessons:[
      { t:'La dopamina non è carburante, è un contabile',
        b:'Pensiamo alla motivazione come a un serbatoio: la mattina pieno, la sera vuoto. Non funziona così.\n\n## Come fa i conti\n\n**La dopamina non misura il carburante che resta: decide se uno sforzo vale il premio.**\n\n- La sera, dopo ore di lavoro, rileggere una pagina di appunti sembra impossibile.\n- Se qualcuno ti offrisse mille euro per farlo, lo faresti subito.\n\nL’energia c’era. **Il contabile aveva solo deciso che quella pagina costava troppo per quello che dava.**\n\n## La domanda giusta\n\nLa domanda non è «ho energia?», ma **«quanto mi costa questo sforzo adesso, e cosa mi dà?»**.' },
      { t:'Perché la sera tutto costa di più',
        b:'Durante il giorno nel cervello si accumula l’adenosina, che la sera rende ogni sforzo più pesante. Più ore passi sveglio, più ne hai in circolo. Succede a tutti.\n\nPer questo la stessa cosa, alle nove di sera, pesa il doppio che alle nove di mattina.\n\n## La mattina costa meno\n\nIl cortisolo, l’ormone che ti sveglia e ti rende pronto, è più alto nelle prime ore dopo il risveglio. **La mattina il contabile fa prezzi bassi.**\n\n## La regola pratica\n\n**Metti la cosa più importante della giornata al mattino, quando ti costa meno.** Non la sera.' },
      { t:'La caffeina non aggiunge, copre',
        b:'La caffeina non ti dà energia: nasconde al cervello il segnale della stanchezza, che poi arriva tutto insieme.\n\n## Come funziona\n\n- Prende il posto dell’adenosina nel cervello: la stanchezza non si sente, e per qualche ora ogni sforzo sembra più leggero di quello che è.\n- Il conto però arriva dopo: l’adenosina si è accumulata lo stesso, e quando l’effetto del caffè finisce **la senti tutta insieme.**\n\n## Come usarla\n\nBevi il caffè **la mattina, per lavorare bene nelle prime ore.** Alle undici di sera non ti regala tempo: te lo toglie dal sonno.' },
      { t:'La motivazione viene dopo l’azione',
        b:'La voglia di lavorare arriva dopo aver cominciato, non prima: dieci minuti bastano a farla partire.\n\n**Appena inizi**, anche per pochi minuti, il cervello rilascia dopamina, e continuare diventa più facile.\n\nPiù resti fermo sul divano, **più ti senti svogliato.** Il primo passo, anche piccolo, ti sblocca.\n\n## La regola dei dieci minuti\n\n- Non serve aspettare l’ispirazione.\n- Basta dirti: lavoro dieci minuti, poi vedo.\n- Nove volte su dieci, passati quelli, non ti fermi.\n\nPer questo, quando nell’app scegli quanto tempo dare a un compito, la prima scelta è «10 min».' },
      { t:'La stanchezza dopo una giornata intera sull’obiettivo',
        b:'Capita a chi passa ore su un lavoro difficile, come cercare un errore nel codice. La sera arrivano il mal di testa e la stanchezza, e la voglia sparisce, anche se hai lavorato tutto il giorno per la cosa giusta.\n\n## Non è pigrizia\n\nLa dopamina non arriva solo quando raggiungi il traguardo: **arriva quando il cervello vede un segno di progresso.** Quando risolvi tanti problemi piccoli e veloci, ogni piccolo successo ti dà una spinta.\n\n**Ore su un problema solo, senza un segno di progresso, sono tanto sforzo e zero premio: la dopamina cala.** Per il contabile il conto non torna, e smette di pagare.\n\nC’è anche la fatica vera.\n\n- Il cervello consuma circa un quinto dell’energia del corpo.\n- Ore di concentrazione senza pause stancano la corteccia prefrontale, la parte del cervello che decide e che resiste alle tentazioni.\n- Il mal di testa di fine giornata è spesso tensione: lo sguardo fisso sullo schermo sbatte meno le palpebre e stanca gli occhi, e il collo e le spalle restano contratti per ore.\n\n## Tre rimedi\n\n1. **Spezza il lavoro in passi ridicolmente piccoli**, così ogni passo spuntato è un segno di progresso.\n2. **Lavora a blocchi di 25 minuti** con 5 minuti di pausa vera, lontano dagli schermi.\n3. **Conta anche il lavoro che non si vede:** anche se l’errore è ancora lì, oggi hai scoperto dove non sta. Quello è progresso, anche se il cervello fatica a vederlo.' },
      { t:'Ricaricare il contabile',
        b:'Quando la testa è vuota, guardare un video o leggere un manuale non la riposa: continua a farla lavorare. **Serve un riposo vero**, in cui la testa può vagare senza un compito.\n\n## Come ricaricarti\n\n- **Il riposo profondo da svegli** (si cerca come NSDR, o Yoga Nidra): dieci o venti minuti a occhi chiusi, con una guida audio. Recupera più di quanto sembri, senza addormentarsi.\n- **Mezz’ora senza schermi dopo il lavoro.** Chiudere il computer per aprire il telefono non è una pausa. Guarda fuori dalla finestra, fai una doccia calda, ascolta la musica a occhi chiusi.\n- **La regola 20-20-20 contro il mal di testa.** Ogni 20 minuti guarda per 20 secondi un punto lontano almeno 6 metri: gli occhi si rilassano.\n- **La luce del sole al mattino:** dieci minuti all’aperto appena sveglio regolano l’orologio interno, e l’energia della giornata e il sonno della notte dopo ne guadagnano.\n- **Un tabellone di carta:** scrivi i passi piccoli su un foglio e tirali via con una riga di pennarello quando li finisci. Il gesto di depennare è un segno di progresso che il cervello sente più di un clic.\n- **Un premio deciso prima:** dopo 45 minuti sulla parte più difficile, un caffè buono o un capitolo del romanzo. Se il lavoro non ti premia, il premio te lo dai tu.' }
    ] },
  { id:'tempo', icon:'⏳', name:'Gestire il tempo',
    intro:'Gestire bene il tempo vuol dire fare di più in meno ore, con meno stress. Non è una questione di app: è una questione di dove finiscono le tue giornate.',
    lessons:[
      { t:'Dove va davvero il tuo tempo',
        b:'Prima di cambiare qualcosa, guarda quanto tempo passi davvero al telefono.\n\n## Leggi il Report\n\nApri il Report dell’app: ti dice **quante ore hai passato al telefono ieri, e su quali app.**\n\n**Quasi tutti sbagliano di due o tre ore la stima del tempo passato al telefono, sempre per difetto.** Non è colpa tua: il tempo passato a scorrere non lascia ricordi, quindi la memoria non lo conta.\n\n## Il punto di partenza\n\nScrivi su un foglio quante ore hai passato al telefono oggi. È il tuo punto di partenza: **fra un mese, rileggendolo, vedrai quanto tempo ti sei ripreso.**' },
      { t:'La regola dei blocchi di tempo',
        b:'Il cervello non fa due cose insieme: passa dall’una all’altra, e ogni cambio costa qualche minuto. Per questo una giornata piena di interruzioni finisce con poco di fatto.\n\n## Come dividere la giornata\n\n1. Dividi la giornata in **blocchi da 60 o 90 minuti**, uno per volta.\n2. Dentro ciascun blocco metti una cosa sola.\n3. Fra un blocco e l\'altro, pausa vera: alzati, guarda fuori.\n\n## Lascia decidere al programma\n\nIn DreamMap crea un programma con gli stessi orari del blocco: **in quelle ore le app che ti distraggono restano chiuse**, e non devi resistere ogni volta.' },
      { t:'Le due liste',
        b:'Tieni due liste separate.\n\n- **La prima:** le tre cose che, se le fai oggi, la giornata è riuscita.\n- **La seconda:** tutto il resto.\n\n## Quando scriverla\n\n**Le tre cose che rendono riuscita la giornata si scrivono la sera prima, non la mattina.** La mattina la testa fresca ti serve per fare, non per decidere cosa fare.\n\n## Tagliare\n\nSe ti escono sette cose importanti, non sono priorità: è un elenco di desideri. **Scegliere cosa togliere è la parte difficile, ed è quella che conta.**' },
      { t:'La legge di Parkinson',
        b:'Un lavoro si allunga fino a riempire tutto il tempo che gli dai. Se ti dai due ore per scrivere una mail, ci metterai due ore.\n\n## Scadenze strette\n\nDai a ogni cosa **una scadenza stretta e visibile.** Un timer sul tavolo cambia il ritmo più di qualsiasi motivazione.\n\n## Vale anche al contrario\n\nSe metti a Instagram un limite di trenta minuti al giorno, non perdi niente: **quei trenta minuti li passi a guardare le cose che ti interessano davvero.**' },
      { t:'Scrivere un obiettivo a mano',
        b:'Si sente dire che un obiettivo scritto ha dieci volte più probabilità di realizzarsi. Il «dieci volte» è esagerato, **ma l’effetto c’è.**\n\nIn uno studio della Dominican University (Gail Matthews) chi scriveva i propri obiettivi e ogni settimana raccontava a un amico a che punto era ne realizzava molti più di chi li teneva solo in testa.\n\n## Perché funziona\n\n**Scrivere un obiettivo a mano costringe a deciderlo, e un obiettivo deciso diventa un filtro per le occasioni giuste.**\n\n- Scrivere a mano costringe il cervello a scegliere le parole, e quello che scegli si ricorda meglio.\n- Un obiettivo scritto fa da filtro: da quel giorno noti le occasioni che lo riguardano e che prima ignoravi.\n- Un pensiero vago non si può scrivere: per scriverlo devi deciderlo.\n- La testa è bravissima ad avere idee e pessima a conservarle: il foglio fa da memoria, e la testa si libera.\n\n## Dalla testa alla pagina\n\nMatthew McConaughey, nel suo libro Greenlights, la mette così: scrivere un obiettivo lo tira fuori dalla testa e lo mette su una pagina, dove lo puoi guardare. **Finché sta in testa è un monologo; sulla pagina diventa un dialogo con te stesso.**\n\nDavanti agli occhi tieni due cose sole: **l’obiettivo, e la cosa più importante da fare oggi.** Le idee nuove no: quelle vanno nel caveau delle idee dell’app.' }
    ] },
  { id:'focus', icon:'🎯', name:'Concentrazione',
    intro:'Concentrarsi non è sforzarsi di più. È togliere le cose che ti interrompono, prima che ti interrompano.',
    lessons:[
      { t:'Il costo di una notifica',
        b:'Dopo una notifica servono diversi minuti per tornare con la testa al lavoro di prima. Non è pigrizia: è il modo in cui funziona l\'attenzione.\n\n## Il conto della mattina\n\nCon venti notifiche in una mattina non perdi venti secondi: **passi tutta la mattina con la testa a metà fra il lavoro e il telefono.**\n\n## Lascia acceso il blocco\n\nQuando crei un programma in DreamMap, il blocco delle notifiche è già acceso: **lascialo così.** Le app bloccate non ti suonano, e non ti tirano fuori dal lavoro.' },
      { t:'Il telefono in un\'altra stanza',
        b:'Un telefono spento sul tavolo ruba comunque attenzione, perché una parte di te sa che è lì.\n\n## Cosa dicono gli studi\n\nIn uno studio del 2017 (Ward e colleghi) chi aveva il telefono sul tavolo, anche spento, **faceva peggio nei test di memoria** di chi l’aveva in un’altra stanza.\n\n## La soluzione\n\nLa Focus Box, la scatola col timer per il telefono, esiste per questo. Va bene anche un cassetto. **Conta la distanza, non la volontà.**' },
      { t:'Iniziare è la parte difficile',
        b:'Non aspettare la voglia: arriva dopo, non prima.\n\n## La regola dei due minuti\n\n**Per cominciare un compito basta la sua versione minuscola: aprire il file e scrivere una riga.**\n\n- Non "scrivo il capitolo".\n- Ma "apro il file e scrivo una riga".\n\nNove volte su dieci, dopo la riga continui.\n\n## Chiudi le vie di fuga\n\nCrea in DreamMap un programma che parte **all’ora in cui di solito rimandi.** Se Instagram e YouTube sono bloccati, cominciare il lavoro costa meno fatica che cercare un’altra distrazione.' },
      { t:'Il rientro morbido',
        b:'Alla fine di un blocco di lavoro conviene scrivere dove sei arrivato e quale sarà il passo successivo. Basta una riga.\n\nIl giorno dopo non riparti da zero: **sai già qual è la prima cosa da fare.** Costa trenta secondi, ed è uno dei modi più semplici per non rimandare.\n\n## Anche la sera\n\nSe prima di chiudere la giornata scrivi cosa farai domani, **a letto non ci ripensi di continuo** mentre provi a dormire.' }
    ] },
  { id:'motivazione', icon:'🔥', name:'Motivazione',
    intro:'Le regole le scrive la persona lucida di oggi. A romperle è quella stanca delle undici di sera. Capire come funziona la tua motivazione è come mettere una distanza fra le due.',
    lessons:[
      { t:'I due tipi di motivazione',
        b:'Ci sono due tipi di motivazione.\n\n- **Da fuori:** un voto, un premio, l’approvazione degli altri.\n- **Da dentro:** il fatto che la cosa in sé ti interessa.\n\n**La motivazione che viene da un premio esterno finisce presto; quella che nasce dall’interesse per la cosa regge per anni.** La prima è comoda, la seconda è lenta a partire.\n\n## La domanda da farti\n\nQuando scegli un obiettivo, chiediti **per chi lo stai facendo.** Se lo fai per i tuoi genitori, per il capo o per farti vedere, fra sei mesi probabilmente avrai mollato.' },
      { t:'L\'elefante e il cavaliere',
        b:'Lo psicologo Jonathan Haidt descrive la mente come un cavaliere su un elefante.\n\n- **Il cavaliere** è la ragione.\n- **L\'elefante** è tutto il resto: abitudini, umore, impulsi.\n\n**La ragione è un cavaliere su un elefante: se l’elefante non vuole andare, nessuna discussione lo convince.** Il cavaliere può solo indicare la direzione.\n\n## Cambia la strada\n\nQuindi non litigare con te stesso: cambia la strada. **Se alle nove di sera Instagram è bloccato, l’elefante non va convinto: la strada comoda non c’è più.**' },
      { t:'La lista delle abitudini',
        b:'Un’abitudine è una decisione presa una volta sola, che poi non costa più energia.\n\nOgni cosa che decidi ogni giorno ti costa energia; **ogni cosa che è diventata automatica non ti costa nulla.**\n\n## Come costruirne una\n\n1. Scegline **una sola per volta**, la più piccola che riesci a immaginare.\n2. Legala a qualcosa che già fai: dopo il caffè, dopo la doccia.\n3. Fai una crocetta sul calendario ogni giorno che la fai.\n\nDopo una settimana di crocette **non vorrai rompere la catena**: funziona meglio di qualsiasi proposito.' },
      { t:'La forza di volontà si esaurisce',
        b:'La volontà somiglia più a un muscolo che a un tratto del carattere.\n\n**La forza di volontà si stanca come un muscolo, e la sera cedi su cose che la mattina avresti rifiutato.** Una giornata di decisioni la svuota.\n\n## Decidi da lucido\n\nLe regole **decidile quando sei lucido, e fai in modo che la sera non si possano cambiare.** A questo serve la Modalità severa: una volta attiva, non la spegni con un tocco.\n\n## Come ricaricarla\n\nDormire bene, mangiare bene e muoverti la ricaricano più di qualsiasi video motivazionale.' }
    ] },
  { id:'relazioni', icon:'🏡', name:'Tempo con chi ami',
    intro:'Il telefono non ruba solo ore di lavoro. Ruba le sere, le cene, e quel poco che resta di attenzione per le persone accanto.',
    lessons:[
      { t:'Il phubbing',
        b:'Guardare il telefono mentre qualcuno ti parla si chiama phubbing, e chi lo subisce lo vive come un piccolo rifiuto. Lo sente così anche quando non dice niente.\n\nSe succede ogni sera, **alla lunga pesa sul rapporto più di una litigata.**\n\n## Una regola che decide per te\n\nUn programma che blocca i social dalle 20 alle 22 ti toglie una scelta: **non devi decidere venti volte a sera se prendere in mano il telefono.**' },
      { t:'La zona senza telefono',
        b:'Scegli un posto della casa e un momento della giornata in cui il telefono non entra.\n\n**La tavola è il posto naturale in cui il telefono non entra, per tutta la famiglia, adulti compresi.** La regola funziona meglio se vale per tutti: i figli imparano quello che vedono, non quello che sentono.\n\n## L’ora come segnale\n\nCon DreamMap puoi creare un programma che blocca le app che scegli all’ora di cena, per esempio dalle 20 alle 21: **si accende da solo ogni sera.** Non devi ricordartelo tu.' },
      { t:'Attenzione intera, per poco',
        b:'Venti minuti di attenzione vera valgono più di tre ore nella stessa stanza, ognuno davanti al proprio schermo.\n\n## Come si fa\n\n- Metti via il telefono.\n- Guarda in faccia chi ti parla.\n- Chiedi qualcosa di vero, come «cosa ti ha fatto ridere oggi?».\n\n## Se ti sembra difficile\n\nÈ normale: **eri abituato a stare insieme col telefono in mano.** Dopo qualche sera viene da sé.' },
      { t:'Dare l\'esempio, non le regole',
        b:'Se a cena chiedi a tuo figlio di posare il telefono mentre tu scorri i video sul tuo, tuo figlio impara quello che ti vede fare. **Non impara quello che gli dici.**\n\n## Mettiti in gioco\n\nMetti via il telefono tu per primo. Poi digli la verità: «anch’io la sera passo troppo tempo sul telefono, sto provando a lasciarlo in cucina». E proponigli di provarci insieme. **Un genitore che ammette la sua fatica si ascolta più di uno che dà ordini.**\n\n## In due è più facile\n\nNell’app c’è anche il Focus Partner: **ci si prova in due**, che sia tuo figlio, tuo fratello o un amico.' }
    ] },
  { id:'sonno', icon:'🌙', name:'Dormire meglio',
    intro:'Il sonno decide l\'umore, la fame, la lucidità e la volontà del giorno dopo. È la leva più corta che hai su tutto il resto.',
    lessons:[
      { t:'L\'ultima ora',
        b:'L’ora prima di andare a dormire conta più dell’ora in cui vai a letto.\n\n## Cosa ti tiene sveglio\n\n- La luce forte dello schermo.\n- Le notifiche.\n- Video e discussioni che ti agitano.\n\nQueste cose dicono al corpo che non è ancora ora di dormire. **E finisci a rigirarti nel letto per mezz’ora.**\n\n## Togli la scelta\n\nUn programma di DreamMap che parte alle 22:30 e finisce alle 7 **decide al posto tuo proprio quando sei troppo stanco per decidere bene.**' },
      { t:'Il letto è per dormire',
        b:'Se guardi video a letto, il cervello impara che il letto è un posto in cui si sta svegli.\n\nPer fargli cambiare idea servono qualche settimana e una regola noiosa: **nel letto si dorme, e basta.**\n\n## Se non dormi\n\n1. Se dopo venti minuti sei ancora sveglio, alzati.\n2. Vai in un\'altra stanza con luce bassa.\n3. Torna a letto solo quando arriva il sonno.' },
      { t:'La sveglia, non l\'ora di andare a letto',
        b:'Il ritmo del sonno si tiene con l’ora della sveglia, uguale tutti i giorni, weekend compreso. L\'ora in cui ti addormenti si sistema da sola nel giro di qualche giorno.\n\n## Il jet lag del sabato\n\nSpostare la sveglia di due ore il sabato equivale a **un piccolo jet lag ogni settimana.**\n\n## La luce del mattino\n\nSe puoi, esci alla luce naturale entro mezz\'ora dal risveglio: **è il segnale più forte che il tuo orologio interno riceve.**' },
      { t:'La sveglia fuori dalla stanza',
        b:'Usare il telefono come sveglia te lo mette in mano appena sveglio, nel momento della giornata in cui resisti di meno.\n\n## Una sveglia vera\n\n**Basta una sveglia da pochi euro.** Il telefono dorme in un’altra stanza, e la prima mezz’ora è tua.\n\nÈ l’idea dell’uscita «caricabatterie» della Modalità severa: la spegni solo attaccando il telefono al caricatore, che magari sta in cucina. **La distanza batte i buoni propositi.**' }
    ] },
  { id:'procrastinazione', icon:'🐢', name:'Smettere di rimandare',
    intro:'Rimandare non è un difetto di carattere. È un modo di scappare da una sensazione. Qui impari a riconoscerlo, e a chiudergli le uscite.',
    lessons:[
      { t:'Rimandare non è pigrizia',
        b:'Si rimanda per non sentire il disagio che la cosa ci dà, non perché si è pigri.\n\n## Da cosa scappi\n\nChi rimanda non scappa dalla cosa da fare: **scappa dalla sensazione che la cosa gli dà.**\n\n- La noia.\n- La paura di sbagliare.\n- La confusione di non sapere da dove partire.\n\nLe ricerche sulla procrastinazione la descrivono proprio così: **un modo di stare meglio adesso, pagato dal te di domani.** Per questo non si vince con i sensi di colpa, che aggiungono una sensazione brutta in più e fanno rimandare di nuovo.\n\n## La domanda utile\n\nNon chiederti «perché sono così?», ma **«cosa mi fa sentire questa cosa, adesso?»**.\n\n- Se la risposta è confusione, spezza la cosa in passi.\n- Se è paura, rendi il primo passo così piccolo che sbagliarlo non costi niente.' },
      { t:'La regola dei cinque minuti',
        b:'Quando la motivazione è a zero e aprire il lavoro ti dà fastidio, fai un patto con te stesso.\n\n**«Ci lavoro cinque minuti. Se dopo cinque minuti voglio smettere, smetto senza sensi di colpa».**\n\n## Perché funziona\n\nQuasi sempre lo sforzo più grande è cominciare. Una volta partito, il cervello entra nel problema e la voglia arriva da sola.\n\n**Se lavori cinque minuti con il permesso di smettere dopo, quasi sempre continui: la voglia segue l’azione.**\n\nE se dopo cinque minuti smetti davvero, **sono comunque cinque minuti di lavoro che prima non c’erano.**' },
      { t:'Fare tante cose per non fare la cosa',
        b:'C’è un modo di rimandare che sembra lavoro.\n\n- Rispondere alle mail.\n- Riordinare.\n- Studiare un altro po’.\n- Cominciare un progetto nuovo.\n\nCi si sente occupati, e **la sera la cosa che conta è ancora lì.**\n\n## Come riconoscerlo\n\nFatti una domanda: «se oggi facessi solo questa cosa, la giornata sarebbe riuscita?». Se la risposta è no, stai facendo tante cose per non fare la cosa.\n\n**Fare subito le cose facili per non fare quella difficile si chiama precrastinazione.**\n\n## Le idee nuove\n\nLe idee nuove sono la forma più pericolosa, **perché sono belle davvero.** Non buttarle: mettile nel caveau delle idee, e tornaci quando la cosa che conta è fatta.' },
      { t:'Il prezzo di domani',
        b:'Ogni volta che rimandi la cosa che conta, il tuo obiettivo si allontana, e le volte si sommano. Un giorno perso sembra poco. Ma se rimandi tre volte a settimana, in un anno sono cinque mesi.' + '\n\n## L’arrivo previsto' + '\n\nPer questo nella scheda Sogno vedi la data in cui arriverai al tuo obiettivo, e l’app la ricalcola: **se rimandi, la vedi spostarsi in avanti.** Un giorno perso smette di essere invisibile.' + '\n\n## Visione e azione' + '\n\nUn proverbio giapponese lo dice così: la visione senza azione è un sogno ad occhi aperti, l’azione senza visione è un incubo. **Servono tutte e due, ogni giorno.**' },
      { t:'Ulisse e le sirene',
        b:'Ulisse sapeva che, sentendo le sirene, avrebbe girato la nave verso gli scogli.\n\n**Ulisse non si fidò della volontà: si fece legare all’albero maestro prima di sentire le sirene.**\n\n## L’impegno preso in anticipo\n\nQuesto si chiama impegno preso in anticipo.\n\n1. Decidi a mente fredda, quando sei lucido.\n2. Togli a te stesso la possibilità di cambiare idea quando sarai tentato.\n\nIn DreamMap lo fanno la **Modalità severa**, che non ti lascia sbloccare le app quando sei tentato, e l’**ADHD Mode**, che mette da parte le idee nuove.\n\nSapere dove cedi vuol dire conoscerti. **Ulisse si fece legare, e tornò a casa.**' }
  ,
      /* 0.9.343, Andrea: il circolo dell'autosabotaggio e come si gira al contrario. In fondo al modulo: le lezioni fatte sono
         salvate per posizione, una lezione in mezzo sposterebbe le spunte di tutti */
      { t:'Il circolo dell’autosabotaggio',
        b:'Più pensi, più dubiti. Più dubiti, meno fai. Meno fai, meno ti fidi di te. E meno ti fidi, più pensi.'
          + '\n\n[[fig:sabotaggio]]'
          + '\n\n## Un circolo che si alimenta da solo'
          + '\n\nOgni giro rende più forte quello dopo. **Il dubbio non si spegne pensandoci sopra. Cresce.**'
          + '\n\nPer questo chi aspetta di sentirsi pronto aspetta per sempre.'
          + '\n\n## Si gira al contrario da un punto solo'
          + '\n\nQuel punto è l’azione. **Agisci di più, anche in piccolo, e i dubbi calano.**'
          + '\n\n[[fig:fiducia]]'
          + '\n\n1. Agisci, anche con un passo di due minuti.\n2. Ogni cosa fatta toglie un dubbio.\n3. Meno dubiti, più fai.\n4. Più fai, più ti fidi di te. E la fiducia ti fa agire ancora.'
          + '\n\n## La catena da ricordare'
          + '\n\n**Meno pensi, più fai. Più fai, più impari e ottieni risultati. Più risultati ottieni, più cresce la fiducia in te stesso.**'
          + '\n\nVale il doppio se il Sabotatore invisibile ti ha detto che il tuo freno è l’autostima, o il perfezionismo.' },
      /* 0.9.347, Andrea: la cecita' temporale, dal reel di @lifeology.it con lo psichiatra Valerio Rosso (02/11/2026). Le strategie in fondo
         sono quelle classiche della letteratura sull'ADHD (Barkley), legate agli strumenti dell'app: non sono attribuite a lui */
      { t:'La cecità temporale',
        b:'Arrivi in ritardo, fai le cose all’ultimo minuto, perdi un pomeriggio intero ad aspettare un appuntamento. **Spesso dietro c’è la stessa cosa: la cecità temporale.**'
          + '\n\n## Due tempi soli: adesso e non adesso'
          + '\n\nChi ce l’ha vive il tempo in due pezzi: **quello che succede adesso, e tutto il resto.** Una scadenza fra un mese resta astratta finché non diventa urgente.'
          + '\n\nE quando l’unica spinta a cominciare è l’urgenza, si arriva sempre di corsa.'
          + '\n\n## La pigrizia non c’entra'
          + '\n\nIl senso del tempo dipende da circuiti del cervello legati alla dopamina. **Con l’ADHD la stima del tempo sbaglia in modo sistematico.** Il carattere non c’entra, e non tutti quelli con l’ADHD ce l’hanno.'
          + '\n\n## Come si porta il futuro nell’adesso'
          + '\n\n1. **Rendi il tempo visibile.** Un timer che scende davanti agli occhi, come quello del Full Focus.'
          + '\n2. **Spezza la scadenza lontana in tappe vicine.** Una tappa di oggi è un “adesso”, una scadenza fra tre mesi no.'
          + '\n3. **Stima, poi controlla.** Scrivi quanto pensi che ci vorrà, e a fine giornata guarda quanto ci è voluto davvero.'
          + '\n4. **Metti il limite prima di entrare.** Lo scroll fa sparire il tempo: il blocco va acceso prima di aprire l’app, non dopo.'
          + '\n\nVale il doppio se ti riconosci nel blocco del tempo del Sabotatore invisibile.' }
    ] },
  /* 0.9.282, Andrea: la lezione sull'habit stacking (James Clear, Atomic Habits; S.J. Scott). */
  { id:'abitudini', icon:'🔗', name:'Abitudini a catena',
    intro:'Una nuova abitudine resta più facilmente se la agganci a una cosa che fai già ogni giorno. Qui impari la formula, tre esempi pronti e le regole per non strafare.',
    lessons:[
      { t:'La formula',
        b:'Con un’abitudine nuova, la parte più difficile è ricordarsi di farla. Per questo conviene agganciarla a una cosa che fai già senza pensarci.\n\n## La frase da scrivere\n\n**"Dopo aver fatto [abitudine attuale], farò [nuova abitudine]."**\n\nSi chiama habit stacking, cioè abitudini a catena. L’ha resa famosa James Clear nel libro Atomic Habits, partendo da un’idea di S.J. Scott.\n\n## Cosa cambia\n\nLa cosa che fai già diventa il tuo promemoria. **Appena la finisci, sai che tocca alla nuova.**' },
      { t:'Perché il cervello la segue',
        b:'I gesti che ripeti ogni giorno, come lavarti i denti o fare il caffè, nel cervello hanno già una strada tracciata e partono da soli.\n\n## Il vagone sul treno\n\nAgganciare un gesto nuovo a uno vecchio è come attaccare un vagone a un treno che corre già. **Il gesto vecchio fa da segnale e quello nuovo parte subito dopo.**\n\n## Decidere quando e dove\n\nGli psicologi la chiamano intenzione di attuazione: decidi in anticipo **quando** e **dove** farai una cosa. Chi scrive il suo piano in questo modo lo porta a termine molto più spesso di chi si limita a volerlo.' },
      { t:'Tre catene da copiare',
        b:'Tre esempi pronti, uno per ogni momento della giornata.\n\n## La mattina\n\n**"Dopo aver versato il caffè, scrivo le 3 cose più importanti della giornata."**\n\n## A fine lavoro\n\n**"Dopo aver spento il computer, faccio 5 minuti di stretching."**\n\n## La sera\n\n**"Dopo essermi messo a letto, penso a una cosa per cui sono grato oggi."**\n\nScegli quella che ti somiglia di più e **provala domani.**' },
      { t:'Le tre regole',
        b:'La formula funziona se rispetti tre regole.\n\n## 1. Un aggancio solido\n\nScegli una cosa che fai **ogni giorno, più o meno alla stessa ora**: il caffè, la doccia, il viaggio in macchina. Se l’aggancio salta un giorno su due, salta anche l’abitudine nuova.\n\n## 2. Comincia in piccolo\n\nLa nuova abitudine deve durare **meno di due minuti**. Prima dieci flessioni, poi cento. Prima una riga di diario, poi una pagina.\n\n## 3. Una catena alla volta\n\nAggiungi un anello nuovo solo quando il primo ti viene da solo. **Tre abitudini nuove nello stesso momento fanno saltare tutta la catena.**' },
      { t:'Il cambio al posto dell’app',
        b:'La stessa formula ti aiuta quando ti viene voglia di aprire un’app che ti porta fuori strada.\n\n## La frase\n\n**"Quando mi viene voglia di aprire Instagram, faccio 20 flessioni."** Al posto del gesto vecchio metti una cosa che ti piace e ti fa bene: un quadratino di cioccolato fondente, un frullato, due minuti d’aria fuori.\n\n## Dove la trovi\n\nIn **Rientra in rotta** il Genio ti chiede cosa ti fa stare bene e lo usa come cambio. Quando quell’app è bloccata, la schermata di blocco **ti ricorda la promessa che hai fatto tu.**' }
    ] },
  { id:'adhd', icon:'⚡', name:'La testa a 3000 giri',
    intro:'Per chi ha l’ADHD e per chiunque abbia la testa che non si ferma mai. Cosa succede nel cervello, e un sistema per non finire fuori strada. Non sostituisce il parere di un medico.',
    lessons:[
      { t:'Non è mancanza di volontà',
        b:'Nell’ADHD la dopamina viene rilasciata e riassorbita in modo irregolare, e la routine non basta a tenere l’attenzione.\n\n## Cosa succede nel cervello\n\nPiù che produrne meno, il cervello gestisce la dopamina in modo diverso: **nella corteccia prefrontale**, la parte che pianifica e trattiene l’attenzione, **ne resta disponibile di meno.**\n\nIl risultato pratico: le attività di routine non danno abbastanza segnale per tenere la concentrazione. Servono stimoli più forti, più immediati o più carichi di emozione.\n\n- Una novità.\n- Un’urgenza.\n- Una scadenza vicina.\n- Una passione.\n\nCon lo stimolo giusto arriva perfino **l’iperfocus**, una concentrazione totale.\n\n## Cosa puoi fare tu\n\nI farmaci per l’ADHD agiscono proprio qui, e **li valuta solo un medico.** Quello che puoi fare tu ogni giorno è organizzarti le giornate in modo da non dover contare solo sulla forza di volontà.' },
      { t:'Perché l’idea nuova vince sempre',
        b:'Un’idea nuova accende la testa più di un compito noioso che non mostra progressi.\n\nUn compito noioso e difficile non dà segni di progresso, e per una testa che cerca stimoli è fatica senza premio. **L’idea nuova invece è una novità**, ed è proprio lo stimolo che la testa cercava.\n\n## L’alibi perfetto\n\nLa testa trova l’alibi: «questa idea è geniale, se la faccio adesso il progetto vale di più». Magari è vero. Ma intanto **la cosa che ti avvicina davvero all’obiettivo resta ferma**, e l’arrivo si sposta in avanti di settimane.\n\n## Il vero problema\n\nIl problema non sono le idee. **È che restano visibili:** ogni volta che le rileggi, ti chiamano.' },
      { t:'Il caveau delle idee',
        b:'Il caveau è un posto in cui le idee si scrivono ma non si rileggono. Scrivi l’idea, la metti al sicuro, e sparisce dalla vista fino alla fine del timer che hai scelto.\n\n'
          + '## Perché la testa si calma\n\n'
          + '**Nel caveau un’idea si scrive ma non si rilegge finché il timer non finisce: non si perde e non ti porta fuori strada.**\n\n'
          + 'Con l’ADHD si corre a realizzare un’idea anche per paura di dimenticarla: **nel caveau quella paura non serve.**\n\n'
          + '## Quando si riapre\n\n'
          + 'Quando il timer finisce, il caveau si riapre e resta aperto finché non lo richiudi. Nel Taglia l’app ti mostra le idee una alla volta, con poco tempo per decidere. **O la tagli, o la tieni per domani.**\n\n'
          + 'Un’idea urgente può saltare la coda solo a due condizioni.\n\n'
          + '1. Sono passate 48 ore da quando l’hai scritta.\n2. Rileggendola, rispondi sì alla domanda «senza questa, il mio obiettivo non si può raggiungere?».' },
      { t:'L’obiettivo davanti, le sirene dietro',
        b:'Due regole, e bastano.\n\n- **L’obiettivo**, cioè il tuo sogno e la cosa più importante da fare oggi, deve essere sempre visibile: è l’ancora.\n- **Le idee nuove** devono essere invisibili: sono le sirene.\n\n**L’obiettivo resta sempre visibile; le idee nuove restano invisibili fino al Taglia.**\n\n## Un modo nuovo di pensare\n\nUna frase attribuita a Einstein dice che non si risolve un problema con lo stesso modo di pensare che l’ha creato. Pianificare ogni giorno con la stessa testa che ti ha portato fuori strada **rischia di riportarti al punto di partenza.**\n\nBuckminster Fuller diceva che le cose non si cambiano combattendo la realtà che c’è, ma costruendo un modello nuovo che renda vecchio quello di prima. L’ADHD Mode fa questo: **invece di litigare con la tua testa, cambia quello che le metti davanti.**' },
      { t:'Scaricare la RAM',
        b:'Quando la testa gira a vuoto, scrivi a mano per cinque o dieci minuti tutto quello che hai dentro: idee, problemi, emozioni.\n\nPer esempio: «non so come dirlo a mia madre», «ho paura di non finire in tempo».\n\n## Perché funziona\n\nI pensieri che tieni a mente occupano la memoria di lavoro, la RAM del cervello. Scritti sul foglio, smettono di girare.\n\n**Scrivere a mano tutto quello che hai in testa libera la memoria di lavoro e ti fa sentire più leggero.** Succede quasi subito.\n\nLa sera, prima di dormire, è il momento migliore: **scrivi tutto, metti le idee nel caveau, poi spegni la luce.**' }
    ] },
  { id:'scrittura', icon:'✍️', name:'Scrivere per liberare la testa',
    intro:'Scrivere non serve solo a ricordare. Cambia quello che succede nella testa: la svuota, abbassa l’allarme, mette in ordine. Ma non tutti i modi di scrivere fanno lo stesso effetto.',
    lessons:[
      { t:'Scaricare la testa',
        b:'Un compito lasciato a metà continua a girare in testa: è l’effetto Zeigarnik, e consuma attenzione anche quando stai facendo altro.\n\n## Cosa dicono gli esperimenti\n\nGli esperimenti di Masicampo e Baumeister lo hanno misurato. **Scrivere il prossimo passo di un compito lasciato a metà basta perché smetta di girarti in testa.** Non serve fare la cosa: basta un piano concreto. La testa si fida del foglio e **molla la presa.**\n\n## Al sicuro\n\nPer questo appuntare un pensiero dà sollievo subito: non perché la cosa sia fatta, ma **perché è al sicuro.** È il principio del caveau delle idee.' },
      { t:'Dare un nome all’emozione',
        b:'Scrivere «sono in ansia per la consegna di domani» fa più di quello che sembra.\n\n## Cosa succede nel cervello\n\nGli studi di Matthew Lieberman con la risonanza magnetica lo mostrano. **Dare un nome a un’emozione abbassa l’attività dell’amigdala, il centro dell’allarme.** E accende la parte del cervello che tiene a bada le emozioni.\n\nSi chiama etichettare l’emozione. Non serve risolvere niente: **serve la parola giusta.**\n\n## Come si fa\n\nQuando la testa è in tempesta, scrivi una riga che cominci con **«mi sento…»**. È il primo passo per calmarla.' },
      { t:'Il diario che fa bene',
        b:'James Pennebaker ha chiesto a migliaia di persone di scrivere per quindici-venti minuti, tre o quattro giorni di fila, dei pensieri e delle emozioni più profonde su un momento difficile.\n\n**Scrivere per quindici minuti al giorno delle emozioni profonde, per pochi giorni, migliora lo stress e l’umore nei mesi dopo.** Chi aveva scritto, nei mesi seguenti aveva:\n\n- meno stress;\n- meno visite dal medico;\n- umore più stabile.\n\n## Come scrivere\n\nNon conta scrivere bene: **conta scrivere quello che senti davvero, e perché.** Il diario di viaggio dell’app comincia proprio così: prima come ti senti e perché, e solo in fondo i minuti di lavoro.' },
      { t:'Carta o telefono?',
        b:'Le note del telefono sono velocissime e sempre in tasca: perfette per catturare un’idea prima che scappi. Ma per aprirle sblocchi il telefono, e **dal telefono sbloccato alle notifiche il passo è corto.**\n\n## La mano e il cervello\n\nScrivere a mano è un’altra cosa. Uno studio norvegese del 2024 (van der Meer e van der Weel) ha registrato l’attività del cervello: **scrivendo a mano le aree che lavorano insieme sono molte di più** che battendo sulla tastiera, comprese quelle della memoria.\n\n## La regola pratica\n\n**Il telefono serve a catturare un’idea; la carta a pensarla e a ricordarla.**' },
      { t:'Note che calmano, note che agitano',
        b:'Lo stesso foglio può calmare o agitare.\n\n**Un foglio che finisce con il prossimo passo mette la testa a riposo; una lista frenetica di scadenze la tiene in allerta.** Se la lista è scritta a mezzanotte, il sonno se ne accorge.\n\n## Tre regole\n\n1. **Un posto solo per le idee**, che non rileggi fino al giorno che hai deciso: il caveau.\n2. **Ogni cosa da fare scritta come prossima azione**, con un verbo («scrivere la prima riga», non «libro»).\n3. **La sera chiudi con una riga sola:** la prima cosa di domani.\n\nCosì scrivere smette di essere un’altra fonte d’ansia e **diventa il posto dove l’ansia si posa.**' }
    ] },
  { id:'respiro', icon:'🌬️', name:'Il respiro che calma',
    intro:'Il respiro è l’unico interruttore del sistema nervoso che puoi toccare con le mani. Qui impari quale respiro usare, e quando.',
    lessons:[
      { t:'Il nervo che frena',
        b:'Il nervo vago è il freno del corpo: collega il cervello al cuore, ai polmoni e allo stomaco, e quando lavora il battito rallenta.\n\n## Come azionarlo\n\n**Respirare piano, intorno a sei respiri al minuto, aziona il nervo vago e rallenta il battito.** È il modo più diretto che hai.\n\n**Le espirazioni lunghe contano più delle inspirazioni:** è mentre butti fuori l’aria che il cuore rallenta.\n\n## Provalo\n\nNon serve crederci. Respira per due minuti con quattro secondi dentro e sei fuori: alla fine il battito è più lento di quando hai cominciato.' },
      { t:'Allarme o riposo',
        b:'Il corpo ha due modalità.\n\n- **Allarme**, il sistema simpatico: prepara a scappare o a combattere. Battito veloce, respiro corto, pensieri che corrono.\n- **Riposo**, il sistema parasimpatico: serve a digerire, a recuperare e a pensare con calma.\n\n## Il respiro sceglie\n\n**Il respiro rapido e di petto tiene acceso l’allarme del corpo; il respiro lento e di pancia accende il riposo.**\n\nÈ per questo che l’ansia si combatte male con i ragionamenti e bene con il respiro: **con il respiro parli al corpo nella lingua del corpo.**' },
      { t:'Lo stress che si accumula',
        b:'Ogni giornata passata in allarme lascia in circolo più cortisolo, l’ormone dello stress.\n\n- Dormi peggio.\n- Mangi peggio.\n- Ti concentri peggio.\n\n## Spegnere l’allarme\n\n**Una pratica di respiro lento ogni giorno abbassa il battito, la pressione e, con il tempo, il cortisolo.**\n\nLavorare sul sintomo vuol dire bere un altro caffè per reggere la giornata. **Lavorare sulla radice vuol dire spegnere l’allarme che ti stanca.**' },
      { t:'Quale respiro, e quando',
        b:"Ogni stato d’animo ha il suo respiro." + "\n\n## Quale scegliere" + "\n" + "\n- **Ansia, agitazione prima di una cosa difficile:** il sospiro ciclico, due inspirazioni dal naso e una lunga fuori dalla bocca." + "\n- **Una mente che salta da un pensiero all’altro:** il respiro quadrato, quattro secondi per ogni fase." + "\n- **La sera, quando non riesci a staccare:** il 4-7-8, quattro secondi dentro, sette col fiato trattenuto, otto fuori. Quattro cicli." + "\n- **Stanchezza e testa vuota, di giorno e da seduto:** il respiro che sveglia, oppure la carica breve se hai solo due minuti." + "\n\n## Dove trovarli" + "\n\nNella scheda Sogno, il pulsante **«Respiro guidato»**: **dici al Genio cosa vuoi ottenere, quanto tempo hai e dove sei, e lui ti propone il respiro giusto.**" },
      { t:'Il sospiro fisiologico',
        b:'Il sospiro fisiologico serve ad abbassare l’agitazione.\n\n## Come si fa\n\n**Due inspirazioni dal naso, la seconda più corta, poi un’espirazione lunga dalla bocca: è il modo più rapido di calmarsi.** La seconda inspirazione riempie del tutto i polmoni; l’espirazione va fatta lenta.\n\nRipetilo **da cinque a dieci volte.** Bastano un minuto e nessuna preparazione: si fa alla scrivania, in macchina da fermo, prima di una telefonata difficile.' },
      { t:'Il respiro che sveglia',
        b:'C’è un respiro che fa il contrario degli altri: invece di calmare, attiva.\n\n## Come si fa\n\nÈ quello reso famoso da Wim Hof.\n\n1. Trenta respiri profondi.\n2. Si butta fuori l’aria e si resta senza respirare finché è comodo.\n3. Un respiro pieno, trattenuto per quindici secondi.\n\nLe ricerche su questo metodo mostrano un picco di adrenalina: **il corpo si sveglia, la testa si schiarisce.** Serve quando sei scarico e apatico, a metà giornata. La sera no: ti toglie il sonno.\n\n## Sicurezza prima di tutto\n\n**Il respiro alla Wim Hof attiva il corpo con un picco di adrenalina: mai in acqua, mai alla guida, mai la sera.**\n\n- Mai in piedi.\n- Non se sei in gravidanza o hai problemi al cuore o epilessia.\n- Se ti gira la testa, fermati e respira normalmente.' },
      { t:'Cinque minuti per una testa che corre',
        b:'Non serve meditare un’ora. Chiudi gli occhi e segui l’aria che entra e che esce dal naso.\n\n## L’esercizio è il ritorno\n\nLa mente tornerà al lavoro, alle idee, al problema di prima: succederà di continuo. Ogni volta te ne accorgi, senza giudicarti, e ricominci.\n\n**Nella meditazione sul respiro l’esercizio è riportare l’attenzione sul respiro ogni volta che scappa.** Quel ritorno allena la testa a staccarsi dal problema invece di girarci intorno.\n\n## Con l’ADHD\n\nLa meditazione seduta e silenziosa può innervosire. Comincia con un respiro guidato dell’app, o con tre minuti: **anche tre minuti contano.**' }
    ] },
  { id:'respiro-performance', icon:'🫁', name:'Il respiro per la performance',
    intro:"Come usare il respiro per accendere la testa di giorno e spegnerla la sera, senza farti male. Il protocollo del mattino, quello di mezzogiorno e quello prima di dormire.",
    lessons:[
      { t:"Perché in piedi si sviene",
        b:"Il respiro che sveglia, trenta respiri profondi e veloci, è sicuro solo se sei seduto o sdraiato.\n\n## Cosa succede nel corpo\n\n1. Respirando forte e veloce butti fuori molta anidride carbonica.\n2. Con meno anidride carbonica nel sangue, **i vasi che portano il sangue al cervello si stringono.** Al cervello arriva meno sangue: per questo senti la testa leggera e i formicolii alle mani.\n3. In piedi la gravità tira il sangue verso le gambe e la pressione cala ancora. **Il cervello resta qualche secondo senza abbastanza sangue, e svieni.**\n\n## Il pericolo vero è l’apnea\n\nDopo i trenta respiri l’anidride carbonica è così bassa che **non senti il bisogno di respirare anche quando l’ossigeno sta finendo.** Puoi perdere i sensi senza nessun segnale prima. In acqua vuol dire annegare, alla guida un incidente, in piedi una caduta con la testa a terra.\n\n**La regola: solo da seduto o sdraiato, mai in acqua, sotto la doccia o alla guida.** Nell’app, prima di ogni respiro della categoria Performance, te lo ricorda un avviso da confermare.",
        es:"Dopo trenta respiri profondi e veloci, in piedi, al cervello arriva meno sangue e si può svenire." },
      { t:"Il crollo del pomeriggio",
        b:"Il respiro che sveglia funziona perché fa salire l’adrenalina. In uno studio olandese del 2014 (Kox e colleghi, Radboud University) chi lo praticava aveva nel sangue molta più adrenalina di chi non lo faceva.\n\n## L’adrenalina usa le tue riserve\n\nL’adrenalina dice al fegato di liberare lo zucchero che tiene da parte. **Energia subito, presa dalle riserve.** Se poi quelle riserve non le ricarichi mangiando, qualche ora dopo il conto arriva.\n\n## Il conto delle cinque\n\nMolti raccontano lo stesso schema: mattina a mille, poi verso le cinque del pomeriggio la testa si spegne, gli occhi pesano e viene voglia di dolci. A quell’ora si sommano tre cose:\n\n- il calo naturale del pomeriggio, che arriva per tutti;\n- l’adrenalina del mattino, che è finita;\n- le riserve di zucchero vuote, se hai saltato i pasti.\n\n**Le ricerche dirette su questo crollo sono ancora poche, ma il rimedio è semplice: non fare il respiro che sveglia a digiuno da troppe ore, e mangia prima che arrivi la fame.**",
        es:"L’adrenalina del respiro che sveglia fa liberare al fegato lo zucchero che tiene da parte." },
      { t:"Il protocollo di mezzogiorno",
        b:"Se il respiro che sveglia lo fai a metà giornata, conta l’ordine.\n\n1. **Alle dodici, uno spuntino leggero:** una manciata di frutta secca, uno yogurt o un frutto. Ricarica un po’ le riserve senza riempire lo stomaco.\n2. **Alle dodici e mezza, il respiro da seduto:** tre giri del respiro che sveglia. Con lo stomaco quasi vuoto i trenta respiri profondi non danno fastidio.\n3. **Alle due, il pranzo vero.** Arriva quando l’adrenalina sta calando, e rimette a posto le riserve prima del pomeriggio.\n\n## Perché in questo ordine\n\nLo spuntino evita di usare l’adrenalina a serbatoio vuoto. Il pranzo dopo evita il crollo delle cinque. **In mezzo hai un’ora e mezza di testa accesa: mettici il lavoro più difficile della giornata.**",
        es:"Uno spuntino alle dodici, il respiro che sveglia alle dodici e mezza, il pranzo vero alle due." },
      { t:"Il mattino in cinque mosse",
        b:"Il protocollo del mattino si fa a stomaco vuoto, in quest’ordine.\n\n1. **Un bicchiere d’acqua con un pizzico di sale.** Dopo una notte senza bere il corpo è un po’ disidratato, e il sale aiuta a trattenere l’acqua. Se hai la pressione alta, chiedi prima al medico.\n2. **Dieci o quindici minuti di luce del sole, all’aperto.** La luce del mattino negli occhi regola l’orologio interno, e la sera il sonno arriva prima. Dietro un vetro funziona molto meno. Non guardare mai il sole direttamente.\n3. **Il respiro, da seduto.** Il respiro che sveglia se vuoi energia, il respiro quadrato se vuoi calma.\n4. **La doccia fredda, da uno a tre minuti.** In uno studio di Praga del 2000 (Šrámek e colleghi) un’ora immersi nell’acqua a 14 gradi ha alzato la dopamina nel sangue di due volte e mezzo. La doccia dura molto meno e l’effetto è più piccolo, ma la sveglia si sente. Con problemi al cuore, chiedi prima al medico.\n5. **Il caffè dopo un’ora e mezza o due dal risveglio.** Lo consiglia Andrew Huberman, neuroscienziato di Stanford: secondo lui così eviti il crollo del primo pomeriggio. Le prove sono ancora poche: provalo per una settimana e guarda come ti senti.",
        es:"Al mattino il caffè arriva per ultimo, dopo l’acqua, la luce del sole, il respiro e la doccia fredda." },
      { t:"Il respiro dei Navy SEAL",
        b:"Il respiro quadrato, in inglese box breathing, ha quattro fasi da quattro secondi.\n\n1. Inspira dal naso per quattro secondi.\n2. Trattieni il fiato per quattro secondi.\n3. Butta fuori l’aria per quattro secondi.\n4. Resta a polmoni vuoti per quattro secondi.\n\n## A cosa serve\n\nLo ha reso famoso Mark Divine, ex comandante dei Navy SEAL americani, che lo insegnava per restare lucidi sotto pressione. **Ferma la testa senza addormentarla e senza agitarla.** È il respiro giusto prima di una telefonata difficile, di un esame o di una trattativa.\n\n## Quanto\n\n**Da cinque a dieci minuti, da seduto.** Va bene anche la sera, perché non fa salire l’adrenalina.",
        es:"Il respiro quadrato ha quattro fasi da quattro secondi: dentro, fermo, fuori, fermo." },
      { t:"Lo stress che allena e quello che consuma",
        b:"Ci sono due tipi di stress, e fanno cose opposte.\n\n- **Lo stress acuto dura poco:** una doccia fredda, un allenamento duro, il respiro che sveglia. Il corpo reagisce, poi recupera, e ogni volta diventa un po’ più forte. Si chiama ormesi: una piccola dose di stress che allena.\n- **Lo stress cronico non si spegne mai:** scadenze, notifiche, notti corte. Il cortisolo, l’ormone dello stress, resta alto tutto il giorno.\n\n## Cortisolo e testosterone\n\nQuando il cortisolo resta alto per settimane, il corpo produce meno testosterone, l’ormone che in uomini e donne sostiene energia, voglia di fare e muscoli. **Lo stress che allena è breve e arriva di giorno; quello che consuma è lungo e ti segue fino a sera.**\n\n## La regola della sera\n\n**Niente respiri che svegliano dopo le sei di sera.** L’adrenalina resta in circolo per ore e ti ruba il sonno, e il sonno è il momento in cui il corpo recupera dallo stress.",
        es:"Quando il cortisolo resta alto per settimane, il corpo produce meno testosterone." },
      { t:"La sera, per spegnere il motore",
        b:"La sera servono i respiri che rallentano.\n\n## Il 4-7-8 di Andrew Weil\n\n1. Inspira dal naso per quattro secondi.\n2. Trattieni il fiato per sette secondi.\n3. Butta fuori l’aria dalla bocca per otto secondi, con un soffio che si sente.\n\n**Esattamente quattro cicli, non di più:** Weil, il medico americano che l’ha reso famoso, consiglia di non superarli finché non ci hai preso la mano. L’espirazione lunga rallenta il battito.\n\n## Il sospiro ciclico di Huberman\n\nDue inspirazioni dal naso, la seconda più corta per riempire del tutto i polmoni, poi un’espirazione lunga e lenta dalla bocca. **Da tre a cinque minuti.**\n\nIn uno studio di Stanford del 2023 (Balban, Huberman e colleghi) quattro gruppi di persone hanno fatto cinque minuti di respiro al giorno per un mese. **Il sospiro ciclico ha migliorato l’umore più degli altri respiri e più della meditazione.**",
        es:"Il 4-7-8 si fa per esattamente quattro cicli, con l’aria buttata fuori dalla bocca in un soffio." },
      { t:"Le regole d’oro",
        b:"Le sette regole da ricordare." + "\n" + "\n1. **Il respiro che sveglia solo da seduto o sdraiato.** Mai in piedi, in acqua, sotto la doccia o alla guida." + "\n2. **Di giorno si accende, la sera si spegne.** I respiri che svegliano solo prima delle sei di sera." + "\n3. **Mai a serbatoio vuoto.** Uno spuntino prima del respiro che sveglia, un pasto vero dopo." + "\n4. **Il mattino ha un ordine:** acqua e sale, luce del sole, respiro, doccia fredda, e il caffè per ultimo." + "\n5. **Sotto pressione, il respiro quadrato:** cinque minuti fermano la testa senza addormentarla." + "\n6. **Prima di dormire, quattro cicli di 4-7-8 o cinque minuti di sospiro ciclico.**" + "\n7. **Se ti gira la testa, ti fermi.** L’apnea a polmoni vuoti si allunga da sola con la pratica, mai forzandola." + "\n\n## Dove trovarli" + "\n\nNella scheda Sogno: il pulsante **«Respiro guidato»** in alto, oppure la card **«Quale respiro ti serve adesso?»** nelle Sfide. **Dici al Genio cosa vuoi ottenere, quanto tempo hai e dove sei, e lui sceglie il respiro giusto.**",
        es:"Il respiro che sveglia si fa solo da seduto o sdraiato, mai in acqua, sotto la doccia o alla guida." }
    ] }
];

/* LE FRASI DELL'ESAME (0.9.210). L'esame prendeva la prima frase di ogni lezione, tagliata a
   140 lettere: venivano fuori pezzi senza soggetto («Aspettiamo la voglia per cominciare»),
   frasi tronche e frasi sbagliate («mentre scorri a cena»). Ogni lezione ha adesso una frase
   intera, scritta per stare in piedi da sola: chi la legge capisce di cosa parla. */
const AC_FRASI = {
  'La dopamina non è carburante, è un contabile': 'La dopamina non misura il carburante che resta: decide se uno sforzo vale il premio.',
  'Perché la sera tutto costa di più': 'Durante il giorno nel cervello si accumula l’adenosina, che la sera rende ogni sforzo più pesante.',
  'La caffeina non aggiunge, copre': 'La caffeina non ti dà energia: nasconde al cervello il segnale della stanchezza, che poi arriva tutto insieme.',
  'La motivazione viene dopo l’azione': 'La voglia di lavorare arriva dopo aver cominciato, non prima: dieci minuti bastano a farla partire.',
  'Dove va davvero il tuo tempo': 'Quasi tutti sbagliano di due o tre ore la stima del tempo passato al telefono, sempre per difetto.',
  'La regola dei blocchi di tempo': 'Il cervello non fa due cose insieme: passa dall’una all’altra, e ogni cambio costa qualche minuto.',
  'Le due liste': 'Le tre cose che rendono riuscita la giornata si scrivono la sera prima, non la mattina.',
  'La legge di Parkinson': 'Un lavoro si allunga fino a riempire tutto il tempo che gli dai.',
  'Il costo di una notifica': 'Dopo una notifica servono diversi minuti per tornare con la testa al lavoro di prima.',
  'Il telefono in un\'altra stanza': 'Un telefono spento sul tavolo ruba comunque attenzione, perché una parte di te sa che è lì.',
  'Iniziare è la parte difficile': 'Per cominciare un compito basta la sua versione minuscola: aprire il file e scrivere una riga.',
  'Il rientro morbido': 'Alla fine di un blocco di lavoro conviene scrivere dove sei arrivato e quale sarà il passo successivo.',
  'I due tipi di motivazione': 'La motivazione che viene da un premio esterno finisce presto; quella che nasce dall’interesse per la cosa regge per anni.',
  'L\'elefante e il cavaliere': 'La ragione è un cavaliere su un elefante: se l’elefante non vuole andare, nessuna discussione lo convince.',
  'La lista delle abitudini': 'Un’abitudine è una decisione presa una volta sola, che poi non costa più energia.',
  'La forza di volontà si esaurisce': 'La forza di volontà si stanca come un muscolo, e la sera cedi su cose che la mattina avresti rifiutato.',
  'Il phubbing': 'Guardare il telefono mentre qualcuno ti parla si chiama phubbing, e chi lo subisce lo vive come un piccolo rifiuto.',
  'La zona senza telefono': 'La tavola è il posto naturale in cui il telefono non entra, per tutta la famiglia, adulti compresi.',
  'Attenzione intera, per poco': 'Venti minuti di attenzione vera valgono più di tre ore nella stessa stanza, ognuno davanti al proprio schermo.',
  'Dare l\'esempio, non le regole': 'Se a cena chiedi a tuo figlio di posare il telefono mentre tu scorri i video sul tuo, tuo figlio impara quello che ti vede fare.',
  'L\'ultima ora': 'L’ora prima di andare a dormire conta più dell’ora in cui vai a letto.',
  'Il letto è per dormire': 'Se guardi video a letto, il cervello impara che il letto è un posto in cui si sta svegli.',
  'La sveglia, non l\'ora di andare a letto': 'Il ritmo del sonno si tiene con l’ora della sveglia, uguale tutti i giorni, weekend compreso.',
  'La sveglia fuori dalla stanza': 'Usare il telefono come sveglia te lo mette in mano appena sveglio, nel momento della giornata in cui resisti di meno.',
  'La stanchezza dopo una giornata intera sull’obiettivo': 'Ore su un problema solo, senza un segno di progresso, sono tanto sforzo e zero premio: la dopamina cala.',
  'Ricaricare il contabile': 'Ogni 20 minuti guarda per 20 secondi un punto lontano almeno 6 metri: gli occhi si rilassano.',
  'Scrivere un obiettivo a mano': 'Scrivere un obiettivo a mano costringe a deciderlo, e un obiettivo deciso diventa un filtro per le occasioni giuste.',
  'Rimandare non è pigrizia': 'Si rimanda per non sentire il disagio che la cosa ci dà, non perché si è pigri.',
  'La regola dei cinque minuti': 'Se lavori cinque minuti con il permesso di smettere dopo, quasi sempre continui: la voglia segue l’azione.',
  'Fare tante cose per non fare la cosa': 'Fare subito le cose facili per non fare quella difficile si chiama precrastinazione.',
  'Il prezzo di domani': 'Ogni volta che rimandi la cosa che conta, il tuo obiettivo si allontana, e le volte si sommano.',
  'Ulisse e le sirene': 'Ulisse non si fidò della volontà: si fece legare all’albero maestro prima di sentire le sirene.',
  'Non è mancanza di volontà': 'Nell’ADHD la dopamina viene rilasciata e riassorbita in modo irregolare, e la routine non basta a tenere l’attenzione.',
  'Perché l’idea nuova vince sempre': 'Un’idea nuova accende la testa più di un compito noioso che non mostra progressi.',
  'Il caveau delle idee': 'Nel caveau un’idea si scrive ma non si rilegge finché il timer non finisce: non si perde e non ti porta fuori strada.',
  'L’obiettivo davanti, le sirene dietro': 'L’obiettivo resta sempre visibile; le idee nuove restano invisibili fino al Taglia.',
  'Scaricare la RAM': 'Scrivere a mano tutto quello che hai in testa libera la memoria di lavoro e ti fa sentire più leggero.',
  'Il sospiro fisiologico': 'Due inspirazioni dal naso, la seconda più corta, poi un’espirazione lunga dalla bocca: è il modo più rapido di calmarsi.',
  'Il respiro che sveglia': 'Il respiro alla Wim Hof attiva il corpo con un picco di adrenalina: mai in acqua, mai alla guida, mai la sera.',
  'Cinque minuti per una testa che corre': 'Nella meditazione sul respiro l’esercizio è riportare l’attenzione sul respiro ogni volta che scappa.',
  'Scaricare la testa': 'Scrivere il prossimo passo di un compito lasciato a metà basta perché smetta di girarti in testa.',
  'Dare un nome all’emozione': 'Dare un nome a un’emozione abbassa l’attività dell’amigdala, il centro dell’allarme.',
  'Il diario che fa bene': 'Scrivere per quindici minuti al giorno delle emozioni profonde, per pochi giorni, migliora lo stress e l’umore nei mesi dopo.',
  'Carta o telefono?': 'Il telefono serve a catturare un’idea; la carta a pensarla e a ricordarla.',
  'Note che calmano, note che agitano': 'Un foglio che finisce con il prossimo passo mette la testa a riposo; una lista frenetica di scadenze la tiene in allerta.',
  'Il nervo che frena': 'Respirare piano, intorno a sei respiri al minuto, aziona il nervo vago e rallenta il battito.',
  'Allarme o riposo': 'Il respiro rapido e di petto tiene acceso l’allarme del corpo; il respiro lento e di pancia accende il riposo.',
  'Lo stress che si accumula': 'Una pratica di respiro lento ogni giorno abbassa il battito, la pressione e, con il tempo, il cortisolo.',
  'Quale respiro, e quando': 'Prima di dormire il respiro giusto è il 4-7-8: quattro secondi dentro, sette col fiato trattenuto, otto fuori.'
};
ACADEMY.forEach(function(m){ m.lessons.forEach(function(l){ if (AC_FRASI[l.t]) l.es = AC_FRASI[l.t]; }); });

/* ---------------------------------------------------------------------------------------
   Progresso: quali lezioni hai letto. Locale, senza account: è un promemoria, non un voto.
   --------------------------------------------------------------------------------------- */
/* Il modulo gira anche prima di nav.js, che è l'ultimo script: acEsc() lì non esiste ancora, e
   una ReferenceError a metà di ufPaintExploreSocial lasciava "Seguici" come titolo vuoto. Qui
   la scorciatoia se la porta dietro. */
function acEsc(v){
  return String(v == null ? '' : v).replace(/[&<>"]/g, function(m){
    return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[m];
  });
}

function acDone(){
  try{ return JSON.parse(localStorage.getItem('fl_academy') || '{}') || {}; }catch(_){ return {}; }
}
function acMark(modId, i){
  const d = acDone();
  d[modId + ':' + i] = 1;
  try{ localStorage.setItem('fl_academy', JSON.stringify(d)); }catch(_){ }
}
/* 0.9.306: le lezioni che un episodio della tua storia ha consegnato ("Nuova nell'Academy"): fl_academy_nuove,
   { 'modulo:i': quando }. Restano Nuove finche' non le leggi davvero (acMark). */
function acNuove(){ try{ return JSON.parse(localStorage.getItem('fl_academy_nuove') || '{}') || {}; }catch(_){ return {}; } }
function acNuovaSegna(modId, i){ const n = acNuove(); const k = modId + ':' + i; if (n[k]) return; n[k] = Date.now(); try{ localStorage.setItem('fl_academy_nuove', JSON.stringify(n)); }catch(_){ } }
function acNuova(modId, i){ return !!acNuove()[modId + ':' + i] && !acDone()[modId + ':' + i]; }
function acNuoveN(){ const n = acNuove(), d = acDone(); return Object.keys(n).filter(function(k){ return !d[k]; }).length; }
function acModuleDone(mod){
  const d = acDone();
  return mod.lessons.filter(function(_, i){ return d[mod.id + ':' + i]; }).length;
}
function acModule(id){ return ACADEMY.filter(function(m){ return m.id === id; })[0]; }

(function acStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.ac-mod{display:flex;gap:12px;align-items:flex-start;background:#fff;border:1px solid var(--line);border-radius:18px;padding:15px;margin-bottom:10px;cursor:pointer}',
    '.ac-mod .ico{width:42px;height:42px;border-radius:50%;background:var(--blue-soft);display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}',
    '.ac-mod .txt{flex:1;min-width:0}',
    '.ac-mod b{display:block;font:800 15px var(--font-display);color:var(--navy)}',
    '.ac-mod p{font:500 12px/1.55 var(--font-body);color:var(--muted);margin:4px 0 0}',
    '.ac-mod .prog{font:700 11px var(--font-body);color:var(--blue);margin-top:6px;display:block}',
    '.ac-les{display:flex;gap:12px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:14px;padding:13px 14px;margin-bottom:8px;cursor:pointer}',
    '.ac-les .n{width:30px;height:30px;border-radius:50%;border:2px solid var(--line);display:flex;align-items:center;justify-content:center;',
    '  font:800 13px var(--font-body);color:var(--muted);flex:none}',
    '.ac-les.done .n{background:#22B14C;border-color:#22B14C;color:#fff}',
    '.ac-les b{font:700 13.5px var(--font-body);color:var(--navy)}',
    '.ac-les.first{background:var(--blue);border-color:var(--blue)}',
    '.ac-les.first b,.ac-les.first .n{color:#fff}',
    '.ac-les.first .n{border-color:rgba(255,255,255,.6)}',
    '.ac-body{font:500 14.5px/1.75 var(--font-body);color:var(--ink);white-space:pre-wrap;margin:14px 0 20px}',
    '.ex-scroll{display:flex;gap:12px;overflow-x:auto;padding:2px 2px 8px;margin:0 -2px;-webkit-overflow-scrolling:touch;scrollbar-width:none}',
    '.ex-scroll::-webkit-scrollbar{display:none}',
    '.ex-card{flex:0 0 128px;background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px;cursor:pointer;min-height:112px;',
    '  display:flex;flex-direction:column;justify-content:space-between}',
    '.ex-card .ic{font-size:24px}',
    '.ex-card b{font:700 12.5px/1.3 var(--font-body);color:var(--navy);display:block;margin-top:10px}',
    '.ex-card small{display:block;font:600 10px var(--font-body);color:var(--faint);margin-top:3px}',
    '.soc-scroll{display:flex;gap:10px;overflow-x:auto;padding:2px 2px 8px;margin:0 -2px;scrollbar-width:none}',
    '.soc-scroll::-webkit-scrollbar{display:none}',
    '.soc-btn{flex:0 0 auto;width:52px;height:52px;border-radius:16px;background:#fff;border:1px solid var(--line);',
    '  display:flex;align-items:center;justify-content:center;font-size:22px;cursor:pointer;-webkit-tap-highlight-color:transparent;color:var(--navy)}',
    '.soc-btn svg{width:22px;height:22px;display:block}',
    'body.dark .soc-btn{color:#fff}',
    '#faqList{margin-top:22px}.faq-sez + .faq-sez{margin-top:30px}',
    '.faq-cat{margin:0 0 6px;padding:18px 22px;border-radius:15px;background:#C8EFFD;border:1.8px solid #3F9FF4;font:800 15px/1.25 var(--font-display,var(--font-body));letter-spacing:.06em;text-transform:uppercase;color:#001E44}',
    'body.dark .faq-cat{background:#12305A;color:#fff}',
    '.faq-q{background:transparent;border:0;border-radius:0;margin:0;overflow:visible}.faq-q + .faq-q{border-top:1px solid rgba(0,30,68,.15)}body.dark .faq-q + .faq-q{border-top-color:rgba(255,255,255,.14)}',
    '.faq-t{position:relative;z-index:0;width:100%;display:flex;align-items:center;justify-content:space-between;gap:22px;padding:18px 6px;border:0;background:transparent;text-align:left;font:700 15.5px/1.4 var(--font-body);color:var(--navy);cursor:pointer}',
    '.faq-t svg{flex:none;color:var(--navy);transition:transform .2s ease-in-out}.faq-q.open .faq-t svg{transform:rotate(180deg)}',
    '.faq-q.open .faq-t::before{content:"";position:absolute;inset:0 -6px;border-radius:15px;background:#F0FBFF;z-index:-1}body.dark .faq-q.open .faq-t::before{background:rgba(63,159,244,.14)}',
    '.faq-a{display:none;padding:6px 40px 24px 6px;font:500 14.5px/1.65 var(--font-body);color:var(--muted);white-space:pre-wrap}',
    '.faq-q.open .faq-a{display:block}',
    'body.dark .ac-mod,body.dark .ac-les,body.dark .ex-card,body.dark .soc-btn{background:#12203A;border-color:#22345A}',
    'body.dark .ac-mod b,body.dark .ac-les b,body.dark .ex-card b,body.dark .faq-t,body.dark .faq-t svg{color:#fff}',
    'body.dark .ac-les.first{background:var(--blue)}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   Schermate
   --------------------------------------------------------------------------------------- */
registerScreen('s-academy',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">Academy</b><button class="iconbtn ac-menu" onclick="acCuriositaPagina()" aria-label="Altre lezioni da scoprire">⋮</button></div>' +
  '<div id="acList"></div><div class="spacer"></div>', { back: 's-home' });
/* 0.9.349, Andrea: "le domande con Mi interessa non le metterei in quella pagina: in una pagina dedicata, dai tre puntini in alto" */
registerScreen('s-academy-cur',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-academy\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">Ti sei mai chiesto…</b></div>' +
  '<div id="acCurBody"></div><div class="spacer"></div>', { back: 's-academy' });

registerScreen('s-academy-mod',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-academy\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title" id="acModTitle">Modulo</b></div>' +
  '<div id="acModBody"></div><div class="spacer"></div>', { back: 's-academy' });

registerScreen('s-lesson',
  '<div class="topbar"><button class="iconbtn" onclick="acBackToModule()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title" id="acLesTitle">Lezione</b></div>' +
  '<div id="acLesBody"></div>', { back: 's-academy-mod' });

let AC_MOD = null, AC_LES = 0;
/* la domanda di curiosita' arriva alla fine di un episodio (una volta al giorno al massimo) */
(function(){
  const prova = function(k){
    const o = window.epiFine; if (typeof o !== 'function'){ if (k < 20) setTimeout(function(){ prova(k + 1); }, 1500); return; }
    if (o.__ac) return;
    const n = function(){ const r = o.apply(this, arguments); setTimeout(function(){ try{ if (!(typeof GN !== 'undefined' && GN.on)) acCuriositaProponi(); }catch(_){ } }, 2500); return r; };
    n.__ac = true; window.epiFine = n;
  };
  setTimeout(function(){ prova(0); }, 2000);
})();

function academyOpen(){ acRenderList(); goId('s-academy'); }
/* 0.9.348, Andrea: "le lezioni non le farei sbloccare a caso: il primo principio dell'apprendimento e' la curiosita'. Il Genio chiede
   'ti interessa questo?' con una domanda che fa venire voglia di scoprire, e solo se l'utente dice si' la lezione si sblocca. Altrimenti e'
   come la scuola, e vedere tutti quei moduli e' troppo". Un modulo e' aperto se ci sei gia' dentro (una lezione fatta) o se hai detto
   "mi interessa"; gli altri restano chiusi, ognuno con la sua domanda che accende la curiosita'. */
const AC_GANCI = {
  /* 0.9.351, Andrea: "cosa sente chi parla mentre guardi il telefono? Nessuno parla cosi'". Domande come le farebbe una persona */
  contabile: 'Perché la sera cedi a cose che la mattina non avresti mai fatto?',
  tempo: 'Perché certe giornate piene finiscono senza aver fatto la cosa più importante?',
  focus: 'Dopo una notifica, quanto ci metti a tornare concentrato?',
  motivazione: 'Può un premio farti passare la voglia di fare una cosa che ti piaceva?',
  relazioni: 'Cosa prova chi ti parla mentre tu guardi il telefono?',
  sonno: 'Perché conta più l’ora in cui ti svegli di quella in cui vai a letto?',
  procrastinazione: 'Quando rimandi, da cosa stai scappando davvero?',
  abitudini: 'Come fa un’abitudine a restare senza che tu debba ricordartela?',
  adhd: 'Perché per alcune persone esistono solo due tempi, adesso e non adesso?',
  scrittura: 'Perché scrivere quello che hai in testa ti libera più che pensarci?',
  respiro: 'Qual è il respiro che calma il cuore in meno di un minuto?'
};
function acSbloccati(){ try{ return JSON.parse(localStorage.getItem('fl_ac_sbloccati') || '[]') || []; }catch(_){ return []; } }
function acAperto(m){ return acModuleDone(m) > 0 || acSbloccati().indexOf(m.id) >= 0 || acEsamePassato(m.id); }
function acCuriositaPagina(){ acCurPaint(); goId('s-academy-cur'); try{ const sc = document.getElementById('s-academy-cur'); if (sc) sc.scrollTop = 0; }catch(_){ } }
function acCurPaint(){
  const h = document.getElementById('acCurBody'); if (!h) return;
  const chiusi = ACADEMY.filter(function(m){ return !acAperto(m); });
  h.innerHTML = '<p class="ac-cur-intro">Le lezioni si aprono quando ti incuriosiscono. Tocca la domanda di cui vuoi sapere la risposta.</p>'
    + (chiusi.length ? chiusi.map(function(m){
        return '<button type="button" class="ac-gancio" onclick="acSblocca(\'' + m.id + '\', true)"><span aria-hidden="true">' + m.icon + '</span><b>' + acEsc(AC_GANCI[m.id] || m.name) + '</b><i>Mi interessa</i></button>';
      }).join('') : '<p class="ac-vuoto">Hai aperto tutte le lezioni dell’Academy.</p>');
}
function acSblocca(id, apri){
  const l = acSbloccati(); if (l.indexOf(id) < 0){ l.push(id); try{ localStorage.setItem('fl_ac_sbloccati', JSON.stringify(l)); }catch(_){ } }
  try{ if (typeof flVibra === 'function') flVibra([12, 30, 12]); }catch(_){ }
  if (apri){ goId('s-academy'); acRenderList(); setTimeout(function(){ acOpenModule(id); }, 150); } else acRenderList();
}
/** Il Genio accende una curiosita': la domanda di un modulo ancora chiuso, al massimo una volta al giorno (fine episodio, fine tappa). */
function acCuriositaProponi(){
  try{
    const oggi = new Date().toDateString();
    if (localStorage.getItem('fl_ac_curiosita') === oggi) return false;
    const chiusi = ACADEMY.filter(function(m){ return !acAperto(m) && AC_GANCI[m.id]; });
    if (!chiusi.length || typeof inSheet !== 'function') return false;
    const m = chiusi[Math.floor(Math.random() * chiusi.length)];
    localStorage.setItem('fl_ac_curiosita', oggi);
    inSheet('<div class="en-foglio ac-cur"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
      + '<img class="ac-cur-genio" src="img/genio/genio-pensa.png" alt=""><small class="ac-cur-k">Una domanda del Genio</small>'
      + '<h3>' + acEsc(AC_GANCI[m.id]) + '</h3><p>La risposta è nell’Academy, nel modulo "' + acEsc(m.name) + '".</p>'
      + '<div class="or-grid"><button type="button" class="or-a main" onclick="inSheetChiudi();acSblocca(\'' + m.id + '\', true)">Sì, voglio saperlo</button>'
      + '<button type="button" class="or-a" onclick="inSheetChiudi()">Non mi interessa</button></div></div>');
    return true;
  }catch(_){ return false; }
}
function acRenderList(){
  const host = document.getElementById('acList');
  if(!host) return;
  /* 0.9.340, Andrea: "l'Academy di prima era meglio: i pannelli erano grandi, mancava solo il contrasto. Ora ci sono troppi
     pannelli piccolissimi e non si vedono le lezioni fatte". Torna la card grande di prima (icona, nome, descrizione), con il
     contrasto: titolo pieno, stato in blu, e una barra a tacche, una tacca per lezione, piena per ogni lezione completata. */
  const d = acDone();
  const aperti = ACADEMY.filter(acAperto), chiusi = ACADEMY.filter(function(m){ return !acAperto(m); });
  host.innerHTML = (aperti.length ? '' : '<div class="ac-vuoto2"><span aria-hidden="true">🧠</span><b>Le lezioni si aprono quando ti incuriosiscono</b><p>Scegli una domanda: la risposta diventa il tuo primo modulo.</p><button type="button" class="cta" onclick="acCuriositaPagina()">Scegli cosa scoprire</button></div>')
  + aperti.map(function(m){
    const done = acModuleDone(m), tot = m.lessons.length, fin = done >= tot, esame = fin && acEsamePassato(m.id);
    const nuova = m.lessons.some(function(_, i){ return acNuova(m.id, i); });
    const stato = esame ? '🎓 Esame superato' : (fin ? 'Lezioni finite, manca l’esame' : (done ? done + ' di ' + tot + ' lezioni completate' : tot + ' lezioni da scoprire'));
    const tacche = m.lessons.map(function(_, i){ return '<i class="' + (d[m.id + ':' + i] ? 'on' : '') + '"></i>'; }).join('');
    return '<div class="ac-mod2' + (esame ? ' fin' : (done ? ' corso' : '')) + '" role="button" onclick="acOpenModule(\'' + m.id + '\')">'
      + '<div class="ac-mod2-top"><span class="ac-mod2-ico">' + m.icon + '</span><div class="ac-mod2-t"><b>' + acEsc(m.name) + (nuova ? ' <i class="ac-nuova">Nuova</i>' : '') + '</b><small>' + stato + '</small></div>'
      + '<svg class="ac-mod2-c" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></div>'
      + '<p>' + acEsc(m.intro) + '</p>'
      + '<div class="ac-tacche">' + tacche + '</div></div>';
  }).join('')
  + (chiusi.length && aperti.length ? '<button type="button" class="ac-altre" onclick="acCuriositaPagina()">Scopri di cosa parlano le altre lezioni<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>' : '')
  /* 0.9.348, Andrea: "i duelli sono teoria: in fondo all'Academy, dove ci si confronta su quello che si e' imparato" */
  + (typeof dsoDuelliHtml === 'function' ? '<div class="ac-duelli"><p class="ac-chiusi-t">Sfida un amico</p>' + dsoDuelliHtml().replace(/^<div class="am-sect"><b>Duelli<\/b>(<span>[^<]*<\/span>)?<\/div>/, '') + '</div>' : '');
}
(function(){
  const css = [
    '#acList{display:flex;flex-direction:column;gap:12px;padding-top:8px}',
    /* 0.9.348: le domande chiuse, la domanda del Genio, la prova di fine lezione su fondo scuro, i duelli in fondo */
    '.ac-vuoto{margin:6px 4px 4px;font:600 15px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.ac-chiusi{margin-top:18px}.ac-chiusi-t{margin:0 4px 10px;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3;text-align:center}body.dark .ac-chiusi-t{color:#8CC6FF}',
    '.ac-gancio{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin:0 0 10px;padding:14px;border-radius:18px;border:1.5px dashed #8CC6FF;background:#F0FBFF;text-align:left;cursor:pointer;font-family:var(--font-body)}',
    '.ac-gancio span{flex:none;font-size:24px;filter:grayscale(.3)}.ac-gancio b{flex:1;font:700 14.5px/1.4 var(--font-body);color:var(--navy)}.ac-gancio i{flex:none;font:800 12px var(--font-body);font-style:normal;color:#fff;background:#0075E3;padding:7px 11px;border-radius:99px}',
    'body.dark .ac-gancio{background:#12203A;border-color:#2C4170}body.dark .ac-gancio b{color:#fff}',
    '.ac-duelli{margin-top:26px}',
    '.ac-cur{text-align:center}.ac-cur-genio{width:96px;height:96px;object-fit:contain;margin:4px auto 6px;display:block}.ac-cur-k{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.ac-cur h3{margin:8px 0 8px;font:800 20px/1.3 var(--font-display)}.ac-cur p{margin:0 0 18px;color:var(--muted);font:500 14.5px/1.5 var(--font-body)}',
    '.ac-menu{margin-left:auto;font-size:22px;line-height:1}.ac-altre{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:6px 0 0;padding:14px;border-radius:18px;border:1.5px dashed #8CC6FF;background:none;color:#0075E3;font:800 14.5px var(--font-body);cursor:pointer}.ac-altre span{font-size:20px;line-height:1}body.dark .ac-altre{color:#8CC6FF;border-color:#2C4170}',
    '.ac-vuoto2{text-align:center;padding:26px 18px 22px;border-radius:24px;background:linear-gradient(180deg,#C8EFFD,#F0FBFF);border:1px solid #BCE0FF}.ac-vuoto2 span{display:block;font-size:44px;line-height:1}.ac-vuoto2 b{display:block;margin:14px 0 0;font:800 19px/1.3 var(--font-display);color:#001E44}.ac-vuoto2 p{margin:12px auto 26px;max-width:30ch;font:500 14.5px/1.5 var(--font-body);color:#33476A}.ac-vuoto2 .cta{width:100%}',
    'body.dark .ac-vuoto2{background:linear-gradient(180deg,#1A3C6E,#12264C);border-color:#2C4170}body.dark .ac-vuoto2 b{color:#fff}body.dark .ac-vuoto2 p{color:#D6E8FF}',
    '#acCurBody{padding:4px 22px 0}.ac-cur-intro{margin:6px 4px 22px;text-align:center;font:500 15px/1.5 var(--font-body);color:var(--muted)}#acCurBody .ac-gancio{margin-bottom:12px;display:grid;grid-template-columns:36px 1fr;column-gap:12px;row-gap:12px;align-items:center;padding:18px 16px}#acCurBody .ac-gancio span{font-size:28px;text-align:center}#acCurBody .ac-gancio b{font-size:15.5px}#acCurBody .ac-gancio i{grid-column:2;justify-self:start}',
    /* la lezione a sezioni */
    '.ac-prog{position:sticky;top:0;z-index:6;height:5px;margin:0 -22px;background:rgba(0,117,227,.12);overflow:hidden}.ac-prog i{display:block;height:100%;background:linear-gradient(90deg,#3F9FF4,#0075E3);transform-origin:left center;transform:scaleX(0)}',
    '.ac-storia{margin-top:26px}.acs{margin:0 0 40px}.acs-h{margin:0 0 16px;font:800 22px/1.3 var(--font-display);color:var(--navy);opacity:0;transform:translateY(26px);transition:opacity .6s ease,transform .6s ease}.acs-h.in{opacity:1;transform:none}body.dark .acs-h{color:#fff}',
    '.acs-p{margin:0 0 20px;font:500 17px/1.75 var(--font-body);color:var(--ink)}.acw{opacity:.16;transition:opacity .28s ease}.acw.on{opacity:1}.ac-storia b{font-weight:800;color:var(--navy)}body.dark .ac-storia b{color:#fff}',
    '.acs-l{margin:0 0 20px;padding-left:22px}.acs-li{margin:0 0 14px;font:500 16.5px/1.6 var(--font-body);color:var(--ink);opacity:0;transform:translateX(-18px);transition:opacity .5s ease,transform .5s ease}.acs-li.in{opacity:1;transform:none}.acs-li::marker{color:#0075E3;font-weight:800}',
    '.acs-fig{opacity:0;transform:scale(.92);transition:opacity .6s ease,transform .6s ease}.acs-fig.in{opacity:1;transform:none}',
    '.acs-chk{margin:4px 0 44px;padding:26px 20px 24px;border-radius:24px;background:linear-gradient(160deg,#0075E3,#001E44);color:#fff;text-align:center;opacity:0;transform:translateY(26px);transition:opacity .6s ease,transform .6s ease}.acs-chk.in{opacity:1;transform:none}',
    '.acs-chk small{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#C8EFFD}.acs-chk > b{display:block;margin-top:10px;font:800 21px var(--font-display);color:#fff!important}.acs-chk > p{margin:14px auto 22px;max-width:30ch;font:600 16px/1.5 var(--font-body);color:#fff}',
    '.acs-chk-b{display:grid;grid-template-columns:1fr 1fr;gap:12px}.acs-chk-b button{min-height:52px;border-radius:16px;border:2px solid rgba(255,255,255,.4);background:rgba(255,255,255,.1);color:#fff;font:800 16px var(--font-body);cursor:pointer}.acs-chk-b button.ok{background:#fff;color:#0075E3;border-color:#fff}.acs-chk-b button.no{background:#E63946;border-color:#E63946}.acs-chk-b button[disabled]:not(.ok):not(.no){opacity:.5}',
    '.acs-chk-e{margin:18px 0 0!important;font:600 14.5px/1.5 var(--font-body)!important;color:#C8EFFD!important}',
    '.ac-les-cta{display:block;width:100%;margin-top:8px;opacity:0;transform:translateY(16px);transition:opacity .5s ease,transform .5s ease}.ac-les-cta.in{opacity:1;transform:none}.ac-fondo{height:34vh}',
    /* la prova e l'esame */
    '.ac-prova-in{padding:calc(14px + env(safe-area-inset-top)) 24px 40px!important;max-width:480px;margin:0 auto;display:flex;flex-direction:column;align-items:stretch;text-align:center;min-height:100%;box-sizing:border-box}',
    '.acq-top{display:flex;align-items:center;gap:12px;margin-bottom:34px}.acq-x{flex:none;width:40px;height:40px;border-radius:20px;border:0;background:rgba(255,255,255,.12);color:#fff;font:700 16px var(--font-body);cursor:pointer}.acq-bar{flex:1;height:10px;border-radius:5px;background:rgba(255,255,255,.14);overflow:hidden}.acq-bar i{display:block;height:100%;border-radius:5px;background:linear-gradient(90deg,#3F9FF4,#8CC6FF);transition:width .4s}.acq-n{flex:none;font:800 13px var(--font-body);color:#8CC6FF}',
    '.acq-tit{margin:0 0 6px;font:600 13px/1.4 var(--font-body);color:rgba(200,239,253,.7)}.ac-prova .acq-d{margin:12px 0 34px}.acq-k{display:block;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.acq-d{margin:12px 0 34px;font:800 23px/1.35 var(--font-display);color:#fff}',
    '.acq-buco{display:inline-block;min-width:96px;margin:0 4px;padding:0 8px;border-bottom:3px solid #8CC6FF;color:#8CC6FF;line-height:1.2}.acq-buco.pieno{border-bottom-color:#22C55E;color:#fff}',
    '.acq-l{display:flex;flex-direction:column;gap:14px}.acq-o{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;padding:16px 16px;border-radius:18px;border:2px solid #2C4170;background:#0B2550;color:#fff;font:600 16px/1.4 var(--font-body);text-align:left;cursor:pointer;transition:transform .15s}.acq-o:active{transform:scale(.98)}',
    '.acq-lt{flex:none;width:34px;height:34px;border-radius:17px;display:flex;align-items:center;justify-content:center;background:rgba(140,198,255,.16);color:#8CC6FF;font:900 15px var(--font-display)}.acq-t{flex:1;min-width:0}',
    '.acq-l.parole{display:grid;grid-template-columns:1fr;gap:12px}',
    '.acq-vf{display:grid;grid-template-columns:1fr 1fr;gap:14px}.acq-vf .acq-o{flex-direction:column;justify-content:center;gap:8px;min-height:120px;font-size:30px;text-align:center}.acq-vf .acq-o b{font:800 18px var(--font-body);color:#fff}',
    '.acq-o.ok{border-color:#22C55E;background:rgba(34,197,94,.18)}.acq-o.ok .acq-lt{background:#22C55E;color:#fff}.acq-o.no{border-color:#E63946;background:rgba(230,57,70,.2)}.acq-o.no .acq-lt{background:#E63946;color:#fff}.acq-o[disabled]:not(.ok):not(.no){opacity:.45}',
    '.acq-es{margin-top:26px}.acq-fb{padding:16px 18px;border-radius:18px;background:rgba(255,255,255,.07);text-align:left}.acq-fb b{display:block;font:800 16px var(--font-body);color:#fff}.acq-fb p{margin:8px 0 0;font:500 15px/1.5 var(--font-body);color:#C8EFFD}.acq-fb.ok{background:rgba(34,197,94,.14)}.acq-cta{width:100%;margin-top:22px}',
    '.ac-prova{position:fixed;inset:0;z-index:10040;background:linear-gradient(180deg,#001E44,#00132B);color:#fff;opacity:0;transition:opacity .25s;overflow:auto}.ac-prova.in{opacity:1}',
    '.ac-prova-in{max-width:520px;margin:0 auto;padding:calc(48px + env(safe-area-inset-top)) 22px 40px}.ac-prova-k{display:block;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF;text-align:center}',
    '.ac-prova h2{margin:12px 0 24px;font:800 22px/1.3 var(--font-display);text-align:center;color:#fff}',
    '.ac-prova-o{display:block;width:100%;box-sizing:border-box;margin:0 0 12px;padding:16px;border-radius:18px;border:1.5px solid #2C4170;background:#0B2550;color:#fff;font:600 15px/1.45 var(--font-body);text-align:left;cursor:pointer}',
    '.ac-prova-o.ok{border-color:#22C55E;background:rgba(34,197,94,.18)}.ac-prova-o.no{border-color:#E63946;background:rgba(230,57,70,.18)}',
    '.ac-prova-r{margin:18px 0 18px;font:700 15.5px/1.5 var(--font-body);text-align:center;color:#C8EFFD}.ac-prova-cta{width:100%}',
    '#acList{gap:16px}.ac-mod2{padding:20px 18px 18px;border-radius:24px;background:var(--card,#fff);border:1.5px solid #CFE3FA;box-shadow:0 8px 22px rgba(0,30,68,.07);cursor:pointer}',
    '.ac-mod2-top{display:flex;align-items:center;gap:14px}.ac-mod2-ico{flex:none;width:56px;height:56px;border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:28px;background:#E3F1FF}',
    '.ac-mod2-t{flex:1;min-width:0}.ac-mod2-t b{display:block;font:800 17.5px/1.25 var(--font-display);color:var(--navy)}.ac-mod2-t small{display:block;margin-top:4px;font:700 13px var(--font-body);color:#0075E3}.ac-mod2-c{flex:none;color:var(--navy);opacity:.45}',
    '.ac-mod2 p{margin:14px 0 0;font:500 14px/1.55 var(--font-body);color:#3E5575}',
    '.ac-tacche{display:flex;gap:6px;margin-top:16px}.ac-tacche i{flex:1;height:8px;border-radius:99px;background:rgba(0,117,227,.14)}.ac-tacche i.on{background:#0075E3}',
    '.ac-mod2.fin{border-color:#0075E3;background:linear-gradient(180deg,#F2F8FF,#fff)}',
    'body.dark .ac-mod2{background:#12203A;border-color:#22345A}body.dark .ac-mod2-t b,body.dark .ac-mod2-c{color:#fff}body.dark .ac-mod2-t small{color:#8CC6FF}body.dark .ac-mod2 p{color:#BFD3EC}body.dark .ac-mod2-ico{background:#1B2C4F}body.dark .ac-tacche i{background:rgba(140,198,255,.18)}body.dark .ac-tacche i.on{background:#3F9FF4}body.dark .ac-mod2.fin{border-color:#3F9FF4;background:#12203A}',
    '.ac-m{display:flex;align-items:center;gap:14px;width:100%;min-height:84px;box-sizing:border-box;padding:14px 16px;border:2px solid var(--line);border-radius:22px;background:var(--card,#fff);color:var(--navy);text-align:left;cursor:pointer;font:inherit}',
    '.ac-m-ico{flex:none;width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:26px;background:#E3F1FF}',
    '.ac-m-t{flex:1;min-width:0}.ac-m-t b{display:block;font:800 16px/1.25 var(--font-display)}.ac-m-t small{display:block;margin-top:3px;font:600 13px var(--font-body);color:var(--muted)}.ac-m-t .ac-bar{display:block;margin:8px 0 0}.ac-m-c{flex:none;opacity:.5}',
    '.ac-m.ora{border-color:#0075E3;box-shadow:0 8px 22px rgba(0,117,227,.2)}.ac-m.ora .ac-m-ico{background:#0075E3}',
    '.ac-m.fin{border-color:#0075E3;background:#0075E3;color:#fff}.ac-m.fin .ac-m-ico{background:rgba(255,255,255,.2);color:#fff}.ac-m.fin small{color:#D6E8FF}.ac-m.fin .ac-m-c{opacity:.8}',
    '.ac-m.poi{border-color:#DCE6F3}.ac-m.poi .ac-m-ico{filter:grayscale(1);opacity:.55;background:var(--line)}.ac-m.poi b{color:var(--muted)}.ac-m.poi small{opacity:.7}',
    'body.dark .ac-m{background:#12203A;border-color:#22345A;color:#fff}body.dark .ac-m.ora{border-color:#3F9FF4}body.dark .ac-m.fin{background:#0075E3;border-color:#0075E3}body.dark .ac-m.poi{border-color:#1E2E4F}body.dark .ac-m-ico{background:#1B2C4F}',
    '#acLesBody,#acModBody{padding-left:22px !important;padding-right:22px !important}.ac-body{padding:0 4px}',
    /* il titolo della lezione staccato dall'intestazione: era attaccato alla barra in alto */
    '.ac-les-n{font:700 11px var(--font-body);color:var(--blue);letter-spacing:.08em;text-transform:uppercase;margin-top:22px}',
    '.ac-les-t{font:800 23px/1.25 var(--font-display);font-style:italic;color:var(--navy);margin:8px 0 6px}',
    '#acLesTesto{margin-top:18px;min-height:40vh}#acLesTesto .ac-cur{color:var(--blue)}',
    '.ac-les-cta[hidden]{display:none}.ac-cta-in{animation:acCtaIn .45s ease-out both}@keyframes acCtaIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}',
    /* la forma della lezione: sottotitoli, paragrafi, elenchi, grassetto in blu scuro */
    '#acLesTesto{white-space:normal !important}#acLesTesto .ac-attesa{display:none}',
    '#acLesTesto .ac-h{margin:22px 0 8px;font:800 18px/1.3 var(--font-display);color:var(--navy)}#acLesTesto .ac-h:first-child{margin-top:4px}body.dark #acLesTesto .ac-h{color:#fff}',
    '#acLesTesto .ac-p{margin:0 0 12px;font:500 15px/1.7 var(--font-body);color:var(--ink)}',
    '#acLesTesto .ac-l{margin:0 0 14px;padding-left:22px}#acLesTesto .ac-l li{margin:0 0 8px;font:500 15px/1.6 var(--font-body);color:var(--ink)}#acLesTesto .ac-l li::marker{color:#0075E3;font-weight:800}',
    '#acLesTesto b{font-weight:800;color:var(--navy)}body.dark #acLesTesto b{color:#fff}',
    '.ac-nuova{display:inline-block;margin-left:6px;padding:2px 8px;border-radius:99px;background:#E63946;color:#fff;font:800 10px var(--font-body);letter-spacing:.06em;text-transform:uppercase;font-style:normal;vertical-align:middle;flex:none}',
    '.ac-bar{height:8px;border-radius:99px;background:rgba(0,117,227,.14);margin:8px 0 6px;overflow:hidden}.ac-bar i{display:block;height:100%;background:#0075E3;border-radius:99px;transition:width .4s}',
    '.ac-esame{margin:22px 0 10px;padding:18px 16px;border:2px dashed var(--line);border-radius:18px;text-align:center;background:var(--card,#fff)}body.dark .ac-esame{background:#12203A;border-color:#22345A}.ac-esame.pronto{border-style:solid;border-color:#0075E3}.ac-esame.fatto{border-color:#1B9E6A}.ac-esame-lucchetto{display:block;font-size:40px;line-height:1}.ac-esame b{display:block;margin-top:8px;font:800 18px var(--font-display);color:var(--navy)}body.dark .ac-esame b{color:#fff}.ac-esame p{margin:6px 0 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}.ac-esame small{display:block;margin-top:10px;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.ac-esame-btn{width:100%;margin-top:14px}',
    '.ac-es{padding-top:18px}.ac-es small{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin:10px 0 8px}.ac-es h2{margin:0 0 14px;font:800 20px/1.35 var(--font-display);color:var(--navy)}body.dark .ac-es h2{color:#fff}.ac-es-opz{display:flex;align-items:center;gap:12px;width:100%;text-align:left;margin-bottom:12px;padding:14px 14px;border:1.5px solid var(--line);border-bottom-width:4px;border-radius:16px;background:var(--card,#fff);font:600 14.5px/1.45 var(--font-body);color:var(--navy);cursor:pointer;box-shadow:0 2px 8px rgba(0,30,68,.06)}.ac-es-opz:active{transform:translateY(2px);border-bottom-width:2px}.ac-es-l{flex:none;width:28px;height:28px;border-radius:8px;background:rgba(0,117,227,.1);color:#5B8FD0;display:flex;align-items:center;justify-content:center;font:800 13px var(--font-body)}.ac-es-t{flex:1}body.dark .ac-es-opz{background:#12203A;border-color:#22345A;color:#fff}.ac-es-opz.ok{border-color:#1B9E6A;background:rgba(27,158,106,.12)}.ac-es-opz.ko{border-color:#E63946;background:rgba(230,57,70,.1)}',
    '.ac-es-fine{text-align:center;padding:30px 10px}.ac-es-fine span{font-size:64px}.ac-es-fine h2{margin:10px 0 6px;font:800 24px var(--font-display);color:var(--navy)}body.dark .ac-es-fine h2{color:#fff}.ac-es-fine p{margin:0 0 18px;font:500 14px/1.5 var(--font-body);color:var(--muted)}.ac-es-fine .cta{width:100%}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
function acOpenModule(id){
  const m = acModule(id);
  if(!m) return;
  AC_MOD = id;
  const t = document.getElementById('acModTitle'); if(t) t.textContent = m.name;
  const host = document.getElementById('acModBody');
  const d = acDone();
  const firstUndone = m.lessons.findIndex(function(_, i){ return !d[m.id + ':' + i]; });
  if(host) host.innerHTML = '<div style="text-align:center;padding:8px 0 14px"><div style="font-size:44px">' + m.icon + '</div>'
    + '<h2 style="font:800 20px var(--font-display);font-style:italic;color:var(--navy);margin:8px 0 6px">' + acEsc(m.name) + '</h2>'
    + '<p class="hintline" style="padding:0 8px">' + acEsc(m.intro) + '</p></div>'
    + '<div class="sect"><b>Lezioni</b><span style="font:700 12px var(--font-body);color:var(--muted)">' + acModuleDone(m) + ' / ' + m.lessons.length + '</span></div>'
    + m.lessons.map(function(l, i){
        const isDone = !!d[m.id + ':' + i];
        return '<div class="ac-les' + (isDone ? ' done' : '') + (i === firstUndone ? ' first' : '') + '" onclick="acOpenLesson(' + i + ')">'
          + '<span class="n">' + (isDone ? '✓' : (i + 1)) + '</span><b>' + acEsc(l.t) + '</b>' + (!isDone && acNuova(m.id, i) ? '<span class="ac-nuova">Nuova</span>' : '') + '<span class="chev"></span></div>';
      }).join('')
    + acEsameCardHtml(m);
  goId('s-academy-mod');
}
/* ---- L'ESAME FINALE (0.9.208), come la scuola di Clash: si sblocca a lezioni finite ---- */
function acEsamePassato(id){ try{ return !!(JSON.parse(localStorage.getItem('fl_academy_esami') || '{}') || {})[id]; }catch(_){ return false; } }
function acEsameCardHtml(m){
  const done = acModuleDone(m), tot = m.lessons.length, pronto = done >= tot, passato = acEsamePassato(m.id);
  return '<div class="ac-esame' + (pronto ? ' pronto' : '') + (passato ? ' fatto' : '') + '"><span class="ac-esame-lucchetto">' + (passato ? '🎓' : (pronto ? '📝' : '🔒')) + '</span><b>Esame finale</b>'
    + '<p>' + (passato ? 'Superato. Puoi rifarlo quando vuoi.' : (pronto ? 'Tre domande sulle lezioni. Superalo: +40 XP e il modulo è tuo.' : 'Completa tutte le lezioni per sbloccarlo!')) + '</p>'
    + (!pronto ? '<small>' + done + ' / ' + tot + ' lezioni completate</small><div class="ac-bar"><i style="width:' + Math.round(done / tot * 100) + '%"></i></div>' : '')
    + (pronto ? '<button type="button" class="cta ac-esame-btn" onclick="acEsameVia(\'' + m.id + '\')">' + (passato ? 'Rifai l’esame' : 'Fai l’esame') + '</button>' : '') + '</div>';
}
const AC_ES = { id: '', d: [], i: 0, giuste: 0 };
function acEsameDomande(m){
  const altre = ACADEMY.filter(function(x){ return x.id !== m.id; }).reduce(function(a, x){ return a.concat(x.lessons); }, []);
  const frase = function(l){ return l.es || String(l.b).split(/\n+/)[0].split(/(?<=[.!?])\s/)[0]; };
  const picks = m.lessons.slice().sort(function(){ return Math.random() - 0.5; }).slice(0, 3);
  return picks.map(function(l){
    const giusta = frase(l);
    const distr = altre.slice().sort(function(){ return Math.random() - 0.5; }).slice(0, 2).map(frase);
    const opz = [giusta].concat(distr).sort(function(){ return Math.random() - 0.5; });
    return { q: 'Quale di queste tre frasi si trova nella lezione «' + l.t + '»?', opz: opz, ok: giusta };
  });
}
function acEsameVia(id){
  const m = acModule(id); if (!m) return;
  AC_ES.id = id; AC_ES.i = 0; AC_ES.giuste = 0; AC_ES.t0 = Date.now();
  acDomCarica().then(function(){
    /* tre lezioni a caso, una domanda per lezione, e i tipi che si alternano */
    const tipi = ['vf', 'abc', 'completa'].sort(function(){ return Math.random() - 0.5; });
    const idx = m.lessons.map(function(_, i){ return i; }).sort(function(){ return Math.random() - 0.5; }).slice(0, 3);
    let d = idx.map(function(li, k){ const l = acDomDi(m.id, li); return l.filter(function(q){ return q.tipo === tipi[k]; })[0] || l[0]; }).filter(Boolean);
    if (d.length < 3) d = acEsameDomande(m).map(function(x){ return { tipo: 'abc', d: x.q, o: [x.ok].concat(x.opz.filter(function(o){ return o !== x.ok; })), e: '' }; });
    AC_ES.d = d;
    acQuizApri('Esame finale: ' + m.name, d, function(g, n){ AC_ES.giuste = g; AC_ES.i = n; acEsamePaint(); }, 'Vedi il risultato');
  });
}
function acEsamePaint(){
  const host = document.getElementById('acModBody'); if (!host) return;
  const d = AC_ES.d[AC_ES.i];
  if (!d){
    const ok = AC_ES.giuste >= 2;
    let xp = 0;
    if (ok){ try{ const e = JSON.parse(localStorage.getItem('fl_academy_esami') || '{}') || {}; if (!e[AC_ES.id]){ e[AC_ES.id] = Date.now(); localStorage.setItem('fl_academy_esami', JSON.stringify(e)); const s = sdStato(); s.xp += 40; sdSalva(s); xp = 40; if (typeof sdXpOggiAdd === 'function') sdXpOggiAdd(40); } }catch(_){ } try{ flVibra([30, 40, 90]); }catch(_){ } }
    /* 0.9.343, Andrea: "la schermata di esame superato su schermo bianco fa cagare: molto meglio quella di fine livello della
       roadmap, in stile Duolingo". La stessa (sdFineDisegna), con la medaglia del modulo al posto del Genio */
    if (ok && typeof sdFineDisegna === 'function' && document.getElementById('sdFine')){ acEsameFine(xp); return; }
    host.innerHTML = '<div class="ac-es-fine"><span>' + (ok ? '🎓' : '📚') + '</span><h2>' + (ok ? 'Esame superato' : 'Quasi') + '</h2><p>' + AC_ES.giuste + ' su ' + AC_ES.d.length + '. ' + (ok ? 'Il modulo è tuo: +40 XP.' : 'Rileggi le lezioni: le frasi giuste sono lì.') + '</p><button type="button" class="cta" onclick="acOpenModule(\'' + AC_ES.id + '\');acRenderList()">Torna al modulo</button></div>';
    return;
  }
  host.innerHTML = '<div class="ac-es"><small>Domanda ' + (AC_ES.i + 1) + ' di ' + AC_ES.d.length + '</small><h2>' + acEsc(d.q) + '</h2>'
    + d.opz.map(function(o, i){ return '<button type="button" class="ac-es-opz" onclick="acEsameRisp(' + i + ')"><span class="ac-es-l">' + 'ABCD'.charAt(i) + '</span><span class="ac-es-t">' + acEsc(o) + '</span><span class="chev"></span></button>'; }).join('') + '</div>';
}
function acEsameRisp(i){
  const d = AC_ES.d[AC_ES.i]; const giusta = d.opz[i] === d.ok;
  const b = document.querySelectorAll('.ac-es-opz')[i]; if (b) b.classList.add(giusta ? 'ok' : 'ko');
  try{ flVibra(giusta ? 18 : [40, 30, 40]); }catch(_){ }
  if (giusta) AC_ES.giuste++;
  setTimeout(function(){ AC_ES.i++; acEsamePaint(); }, 600);
}
function acOpenLesson(i){
  const m = acModule(AC_MOD);
  if(!m || !m.lessons[i]) return;
  AC_LES = i;
  const l = m.lessons[i];
  const t = document.getElementById('acLesTitle'); if(t) t.textContent = m.name;
  const host = document.getElementById('acLesBody');
  const last = i >= m.lessons.length - 1;
  /* 0.9.349, Andrea: "tieni premuto e il testo scorre e' una cazzata, e va troppo veloce. Le lezioni con testo che scorre, a sezioni
     come quelle GSAP, cosi' l'apprendimento e' interattivo". La lezione e' una storia a sezioni: scorrendo i titoli salgono, le parole
     si accendono una alla volta (scrub, legate allo scorrimento come ScrollTrigger), a meta' c'e' un vero o falso da toccare, e in alto
     una barra dice quanto manca. La macchina da scrivere non c'e' piu'. */
  const scrivi = function(){
    const check = acDomDi(m.id, i).filter(function(q){ return q.tipo === 'vf'; })[0];
    if(host) host.innerHTML = '<div class="ac-prog"><i id="acProg"></i></div>'
      + '<div class="ac-les-n">Lezione ' + (i + 1) + ' di ' + m.lessons.length + '</div>'
      + '<h2 class="ac-les-t">' + acEsc(l.t) + '</h2>'
      + '<div class="ac-storia" id="acLesTesto">' + acStoriaHtml(String(l.b || ''), check ? acCheckHtml(check) : '') + '</div>'
      + '<button class="cta ac-les-cta" id="acLesCta" onclick="acProvaApri()">Mettiti alla prova</button>'
      + '<div class="ac-fondo"></div>';
    goId('s-lesson');
    const sc = document.getElementById('s-lesson');
    try{ if (sc) sc.scrollTop = 0; }catch(_){ }
    acScrubMonta(sc);
    setTimeout(function(){ acScrubGiro(sc); }, 60); setTimeout(function(){ acScrubGiro(sc); }, 400);
  };
  let fatto = false; const una = function(){ if (fatto) return; fatto = true; scrivi(); };
  acDomCarica().then(una); setTimeout(una, 700);
}
/* le domande scritte per ogni lezione (content/academy-domande.json): vero o falso, a scelta, completa la frase */
let AC_DOM = null, AC_DOM_P = null;
function acDomCarica(){
  if (AC_DOM) return Promise.resolve(AC_DOM);
  if (AC_DOM_P) return AC_DOM_P;
  AC_DOM_P = fetch('content/academy-domande.json', { cache: 'no-cache' }).then(function(r){ return r.json(); }).then(function(j){ AC_DOM = j || {}; return AC_DOM; }).catch(function(){ AC_DOM_P = null; return {}; });
  return AC_DOM_P;
}
setTimeout(function(){ try{ acDomCarica(); }catch(_){ } }, 5000);
function acDomDi(modId, i){
  try{
    const l = AC_DOM && AC_DOM[modId] && AC_DOM[modId][i];
    return Array.isArray(l) ? l.filter(function(q){ return q && q.d && (q.tipo === 'vf' ? typeof q.v === 'boolean' : (Array.isArray(q.o) && q.o.length >= 2)); }) : [];
  }catch(_){ return []; }
}
/** Il testo della lezione in sezioni: ogni "## titolo" apre una sezione; le parole dei paragrafi diventano pezzi che si accendono. */
function acStoriaHtml(testo, check){
  const sez = []; let s0 = null;
  acBlocchi(testo).forEach(function(b){ if (b.tipo === 'h' || !s0){ s0 = { h: null, corpo: [] }; sez.push(s0); } if (b.tipo === 'h') s0.h = b; else s0.corpo.push(b); });
  const inl = function(r, parole){
    return r.map(function(x){
      const t = acEsc(x.t);
      const w = parole ? t.split(/(\s+)/).map(function(p){ return (!p || /^\s+$/.test(p)) ? p : '<span class="acw">' + p + '</span>'; }).join('') : t;
      return x.b ? '<b>' + w + '</b>' : w;
    }).join('');
  };
  const dove = sez.length >= 3 ? 1 : 0;
  let out = '';
  sez.forEach(function(x, k){
    out += '<section class="acs">' + (x.h ? '<h3 class="acs-h">' + inl(x.h.righe[0], false) + '</h3>' : '');
    x.corpo.forEach(function(b){
      if (b.tipo === 'fig') out += '<div class="ac-fig acs-fig">' + (typeof acFigura === 'function' ? acFigura(b.k) : '') + '</div>';
      else if (b.tipo === 'p') out += '<p class="acs-p">' + inl(b.righe[0], true) + '</p>';
      else out += '<' + b.tipo + ' class="acs-l">' + b.righe.map(function(r){ return '<li class="acs-li">' + inl(r, false) + '</li>'; }).join('') + '</' + b.tipo + '>';
    });
    out += '</section>';
    if (check && k === dove && sez.length > 1) out += check;
  });
  if (check && sez.length <= 1) out += check;
  return out;
}
function acCheckHtml(q){
  return '<div class="acs-chk" data-v="' + (q.v ? 1 : 0) + '"><small>Fermati un attimo</small><b>Vero o falso?</b><p>' + acEsc(q.d) + '</p>'
    + '<div class="acs-chk-b"><button type="button" onclick="acCheckRisp(this,1)">Vero</button><button type="button" onclick="acCheckRisp(this,0)">Falso</button></div>'
    + '<p class="acs-chk-e" hidden>' + acEsc(q.e || '') + '</p></div>';
}
function acCheckRisp(b, v){
  const c = b.closest('.acs-chk'); if (!c || c.classList.contains('fatto')) return;
  c.classList.add('fatto');
  const giusto = (+c.getAttribute('data-v')) === v;
  const bb = c.querySelectorAll('.acs-chk-b button');
  bb.forEach(function(x){ x.disabled = true; });
  bb[c.getAttribute('data-v') === '1' ? 0 : 1].classList.add('ok');
  if (!giusto) b.classList.add('no');
  const e = c.querySelector('.acs-chk-e'); if (e){ e.textContent = (giusto ? '🎉 Esatto. ' : '💡 Non proprio. ') + e.textContent; e.hidden = false; }
  try{ if (typeof flVibra === 'function') flVibra(giusto ? [12, 40, 12] : 30); }catch(_){ }
}
/* lo scrub: ogni giro del dito ricalcola, al massimo una volta per fotogramma */
function acScrubMonta(sc){
  if (!sc || sc.__acs) return;
  sc.__acs = 1;
  let raf = 0;
  sc.addEventListener('scroll', function(){ if (!raf) raf = requestAnimationFrame(function(){ raf = 0; acScrubGiro(sc); }); }, { passive: true });
  window.addEventListener('resize', function(){ acScrubGiro(sc); });
}
function acScrubGiro(sc){
  const body = document.getElementById('acLesBody'); if (!sc || !body) return;
  const vh = sc.clientHeight || window.innerHeight, top0 = sc.getBoundingClientRect().top;
  const max = sc.scrollHeight - vh, inFondo = max <= 4 || sc.scrollTop >= max - 6;
  let fermo = false; try{ fermo = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  const pr = document.getElementById('acProg'); if (pr) pr.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, Math.max(0, sc.scrollTop / max)) : 1) + ')';
  body.querySelectorAll('.acs-p').forEach(function(p){
    const ws = p.__w || (p.__w = p.querySelectorAll('.acw')); const n = ws.length; if (!n) return;
    const r = p.getBoundingClientRect(), t = r.top - top0;
    const pg = (fermo || inFondo) ? 1 : Math.max(0, Math.min(1, (vh * 0.9 - t) / (r.height + vh * 0.32)));
    const k = Math.min(n, Math.round(pg * n * 1.25));
    if (p.__k === k) return; p.__k = k;
    for (let i = 0; i < n; i++) ws[i].classList.toggle('on', i < k);
  });
  body.querySelectorAll('.acs-h,.acs-li,.acs-fig,.acs-chk,.ac-les-cta').forEach(function(el){
    if (el.classList.contains('in')) return;
    if (fermo || inFondo || el.getBoundingClientRect().top - top0 < vh * 0.9) el.classList.add('in');
  });
}
/* LA LEZIONE SI SCRIVE DA SOLA, LETTERA PER LETTERA (0.9.217), con la macchina da scrivere della
   frase del giorno: una lettera ogni 55 ms (CIT_MS), il cursore davanti all'ultima. Nella 0.9.216
   compariva una parola alla volta: Andrea voleva la STESSA animazione, e la frase del giorno
   scrive lettere, non parole.

   E LA LEZIONE HA UNA FORMA, come le risposte di Google AI Mode: un sottotitolo per sezione
   («## »), elenchi puntati («- ») e numerati («1. »), il grassetto sulla frase che conta
   («**…**»). Le lezioni sono scritte cosi' in ACADEMY; qui diventano titoli, elenchi e
   paragrafi, e la macchina da scrivere li riempie uno dopo l'altro.

   Il pulsante per andare avanti NON c'e' finche' la lezione non e' scritta tutta: spento ma in
   vista rubava l'attenzione. Compare alla fine. Una lezione gia' letta si mostra subito intera. */
const AC_LETTERA_MS = (typeof CIT_MS === 'number') ? CIT_MS : 55;
const ACB = { t: 0, fine: null };
/** Il testo della lezione in blocchi: { tipo: 'h'|'p'|'ul'|'ol', righe: [[{t, b}]] } */
function acBlocchi(testo){
  const out = [];
  const inline = function(riga){
    const pezzi = []; const re = /\*\*([^*]+)\*\*/g; let k = 0, m;
    while ((m = re.exec(riga))){ if (m.index > k) pezzi.push({ t: riga.slice(k, m.index), b: false }); pezzi.push({ t: m[1], b: true }); k = m.index + m[0].length; }
    if (k < riga.length) pezzi.push({ t: riga.slice(k), b: false });
    return pezzi;
  };
  String(testo || '').split(/\n\s*\n/).forEach(function(par){
    const righe = par.split('\n').map(function(r){ return r.trim(); }).filter(Boolean);
    if (!righe.length) return;
    /* 0.9.343: un disegno al posto di un paragrafo, scritto [[fig:nome]] (AC_FIG) */
    const fg = /^\[\[fig:([a-z]+)\]\]$/.exec(righe[0]); if (fg && righe.length === 1){ out.push({ tipo: 'fig', k: fg[1] }); return; }
    if (/^##\s+/.test(righe[0])){ out.push({ tipo: 'h', righe: [inline(righe[0].replace(/^##\s+/, ''))] }); righe.shift(); if (!righe.length) return; }
    if (righe.every(function(r){ return /^[-•]\s+/.test(r); })) out.push({ tipo: 'ul', righe: righe.map(function(r){ return inline(r.replace(/^[-•]\s+/, '')); }) });
    else if (righe.every(function(r){ return /^\d+\.\s+/.test(r); })) out.push({ tipo: 'ol', righe: righe.map(function(r){ return inline(r.replace(/^\d+\.\s+/, '')); }) });
    else out.push({ tipo: 'p', righe: [inline(righe.join(' '))] });
  });
  return out;
}
function acBatti(el, testo){
  if (ACB.t){ clearTimeout(ACB.t); ACB.t = 0; }
  if (!el) return;
  el.innerHTML = '';
  const cta = document.getElementById('acLesCta');
  if (cta) cta.hidden = true;
  const cur = document.createElement('span');
  cur.className = 'typewriter-cursor ac-cur'; cur.textContent = '|';
  /* la coda: per ogni pezzo di testo, il contenitore dove scriverlo */
  const coda = [];
  acBlocchi(testo).forEach(function(bl){
    let box;
    if (bl.tipo === 'fig'){ box = document.createElement('div'); box.className = 'ac-fig'; box.innerHTML = (typeof acFigura === 'function') ? acFigura(bl.k) : ''; el.appendChild(box); coda.push({ dove: box, t: '\u200b', b: false }); return; }
    if (bl.tipo === 'h'){ box = document.createElement('h3'); box.className = 'ac-h'; el.appendChild(box); bl.righe.forEach(function(r){ r.forEach(function(x){ coda.push({ dove: box, t: x.t, b: x.b }); }); }); return; }
    if (bl.tipo === 'p'){ box = document.createElement('p'); box.className = 'ac-p'; el.appendChild(box); bl.righe.forEach(function(r){ r.forEach(function(x){ coda.push({ dove: box, t: x.t, b: x.b }); }); }); return; }
    const lista = document.createElement(bl.tipo); lista.className = 'ac-l'; el.appendChild(lista);
    bl.righe.forEach(function(r){ const li = document.createElement('li'); lista.appendChild(li); r.forEach(function(x){ coda.push({ dove: li, t: x.t, b: x.b }); }); });
  });
  /* i blocchi vuoti restano nascosti finche' la macchina non ci arriva */
  Array.from(el.children).forEach(function(c){ c.classList.add('ac-attesa'); });
  let q = 0, k = 0, span = null;
  const mostra = function(n){ let x = n; while (x && x !== el){ x.classList && x.classList.remove('ac-attesa'); x = x.parentElement; } };
  const finito = function(){
    ACB.t = 0; ACB.fine = null;
    Array.from(el.querySelectorAll('.ac-attesa')).forEach(function(c){ c.classList.remove('ac-attesa'); });
    if (cta){ cta.disabled = false; cta.hidden = false; cta.classList.add('ac-cta-in'); }
    try{ const hint = document.getElementById('acLesHint'); if (hint) hint.remove(); }catch(_){ }
    setTimeout(function(){ try{ cur.remove(); }catch(_){ } }, 1600);
  };
  const nuovoSpan = function(p){ span = document.createElement(p.b ? 'b' : 'span'); p.dove.appendChild(span); p.dove.appendChild(cur); mostra(p.dove); };
  ACB.fine = function(){
    if (ACB.t){ clearTimeout(ACB.t); ACB.t = 0; }
    while (q < coda.length){ const p = coda[q]; if (k === 0 || !span) nuovoSpan(p); span.textContent += p.t.slice(k); q++; k = 0; span = null; }
    finito();
  };
  const passo = function(){
    if (!document.body.contains(el)){ ACB.t = 0; ACB.fine = null; return; }
    if (q >= coda.length){ finito(); return; }
    const p = coda[q];
    if (k === 0) nuovoSpan(p);
    /* 0.9.344, Andrea: "tenendo premuto il testo deve andare piu' veloce o comparire tutto, cosi' non sono obbligato ad aspettare".
       Con il dito giu' si scrivono sei lettere alla volta senza pause; dopo quasi un secondo di pressione compare tutto */
    let giri = ACB.veloce ? 6 : 1;
    while (giri-- > 0 && k < p.t.length){ span.textContent += p.t[k++]; }
    let attesa = ACB.veloce ? 8 : AC_LETTERA_MS;
    if (k >= p.t.length){
      q++; k = 0; span = null;
      /* fine di un blocco (titolo, voce, paragrafo): una pausa, come chi legge e va a capo */
      if (q < coda.length && coda[q].dove !== p.dove) attesa = ACB.veloce ? 30 : 420;
    }
    ACB.t = setTimeout(passo, attesa);
  };
  ACB.t = setTimeout(passo, 400);
  ACB.veloce = false;
  const zona = el.parentElement || el;
  if (!zona.__acHold){
    zona.__acHold = 1;
    const giu = function(e){ if (e.target && e.target.closest && e.target.closest('button, a')) return; ACB.veloce = true; clearTimeout(ACB.giuT); ACB.giuT = setTimeout(function(){ if (ACB.veloce && ACB.fine) ACB.fine(); }, 900); };
    const su = function(){ ACB.veloce = false; clearTimeout(ACB.giuT); };
    zona.addEventListener('pointerdown', giu);
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function(k){ zona.addEventListener(k, su); });
    zona.addEventListener('contextmenu', function(e){ if (ACB.fine) e.preventDefault(); });
  }
}

/** La domanda di fine lezione, su una schermata scura (lo stacco dal bianco della lettura): l'idea chiave fra tre. */
/* l'idea chiave: la frase in grassetto piu' completa della lezione (una frase intera, con il verbo), non il primo grassetto */
function acIdea(l){
  const b = String(l.b || ''), re = /\*\*([^*]{12,200})\*\*/g; let m, best = '';
  while ((m = re.exec(b))){ const t = m[1].replace(/[«»]/g, '"').trim(); if (/[a-zà-ù]{3,}\s+[a-zà-ù]/i.test(t) && t.split(' ').length >= 6 && t.length > best.length) best = t; }
  return best || (l.es || b.split(/\n+/)[0].split(/(?<=[.!?])\s/)[0]);
}
/* 0.9.349, Andrea: "fa sempre la stessa domanda, qual e' l'idea piu' importante della lezione: anche vero o falso, A B C, altri tipi.
   E la schermata fa cagare: margini, opzioni senza A B C, attaccate alla domanda. E se premo indietro si chiude l'app". Un motore solo
   (acQuiz) per la prova di fine lezione e per l'esame: vero o falso, a scelta con le lettere, completa la frase; la X in alto e il tasto
   indietro di Android (acProvaBack, nav.js) tornano alla lezione. */
const AQ = { d: [], i: 0, giuste: 0, fine: null, titolo: '', ultimo: 'Fine', fatta: false };
function acDomandaRiserva(m, l){
  const giusta = acIdea(l);
  const altre = ACADEMY.filter(function(x){ return x.id !== m.id; }).reduce(function(a, x){ return a.concat(x.lessons); }, []).map(acIdea).filter(function(t){ return t && t !== giusta; });
  return { tipo: 'abc', d: 'Quale di queste frasi riassume la lezione?', o: [giusta].concat(altre.sort(function(){ return Math.random() - 0.5; }).slice(0, 2)), e: '' };
}
function acQuizApri(titolo, domande, fine, ultimo){
  AQ.d = domande; AQ.i = 0; AQ.giuste = 0; AQ.fine = fine; AQ.titolo = titolo; AQ.ultimo = ultimo || 'Fine';
  let w = document.getElementById('acProva');
  if (!w){ w = document.createElement('div'); w.id = 'acProva'; w.className = 'ac-prova'; (document.getElementById('phone') || document.body).appendChild(w); requestAnimationFrame(function(){ w.classList.add('in'); }); }
  acQuizPaint();
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
}
function acQuizPaint(){
  const w = document.getElementById('acProva'); if (!w) return;
  const q = AQ.d[AQ.i]; if (!q) return;
  AQ.fatta = false;
  const top = '<div class="acq-top"><button type="button" class="acq-x" aria-label="Chiudi" onclick="acQuizChiudi()">✕</button>'
    + '<div class="acq-bar"><i style="width:' + Math.round(AQ.i / AQ.d.length * 100) + '%"></i></div><span class="acq-n">' + (AQ.i + 1) + ' di ' + AQ.d.length + '</span></div>';
  let corpo = '';
  if (q.tipo === 'vf'){
    corpo = '<small class="acq-k">Vero o falso?</small><h2 class="acq-d">' + acEsc(q.d) + '</h2>'
      + '<div class="acq-vf"><button type="button" class="acq-o" data-i="1" onclick="acQuizRisp(this)">👍<b>Vero</b></button><button type="button" class="acq-o" data-i="0" onclick="acQuizRisp(this)">👎<b>Falso</b></button></div>';
  } else {
    q._opz = q.o.map(function(t, i){ return { t: t, ok: i === 0 }; }).sort(function(){ return Math.random() - 0.5; });
    const dom = q.tipo === 'completa' ? acEsc(q.d).replace('___', '<span class="acq-buco">&nbsp;</span>') : acEsc(q.d);
    corpo = '<small class="acq-k">' + (q.tipo === 'completa' ? 'Completa la frase' : 'Scegli la risposta giusta') + '</small><h2 class="acq-d">' + dom + '</h2>'
      + '<div class="acq-l' + (q.tipo === 'completa' ? ' parole' : '') + '">' + q._opz.map(function(o, i){ return '<button type="button" class="acq-o" data-i="' + i + '" onclick="acQuizRisp(this)"><span class="acq-lt">' + 'ABCD'.charAt(i) + '</span><span class="acq-t">' + acEsc(o.t) + '</span></button>'; }).join('') + '</div>';
  }
  w.innerHTML = '<div class="ac-prova-in">' + top + '<p class="acq-tit">' + acEsc(AQ.titolo) + '</p>' + corpo + '<div id="acProvaEsito" class="acq-es"></div></div>';
  w.scrollTop = 0;
}
function acQuizRisp(b){
  if (AQ.fatta) return; AQ.fatta = true;
  const q = AQ.d[AQ.i]; let giusta = false;
  const bb = document.querySelectorAll('#acProva .acq-o');
  if (q.tipo === 'vf'){
    giusta = (b.getAttribute('data-i') === '1') === !!q.v;
    bb.forEach(function(x){ x.disabled = true; if ((x.getAttribute('data-i') === '1') === !!q.v) x.classList.add('ok'); });
  } else {
    giusta = !!(q._opz[+b.getAttribute('data-i')] || {}).ok;
    bb.forEach(function(x, i){ x.disabled = true; if (q._opz[i] && q._opz[i].ok) x.classList.add('ok'); });
    if (q.tipo === 'completa'){ const bu = document.querySelector('#acProva .acq-buco'), g = q._opz.filter(function(x){ return x.ok; })[0]; if (bu && g){ bu.textContent = g.t; bu.classList.add('pieno'); } }
  }
  if (giusta) AQ.giuste++; else b.classList.add('no');
  try{ if (typeof flVibra === 'function') flVibra(giusta ? [12, 40, 12] : 30); }catch(_){ }
  const e = document.getElementById('acProvaEsito');
  const ultima = AQ.i >= AQ.d.length - 1;
  if (e) e.innerHTML = '<div class="acq-fb ' + (giusta ? 'ok' : 'no') + '"><b>' + (giusta ? '🎉 Esatto' : '💡 La risposta giusta è quella evidenziata') + '</b>' + (q.e ? '<p>' + acEsc(q.e) + '</p>' : '') + '</div>'
    + '<button type="button" class="cta acq-cta" onclick="acQuizAvanti()">' + (ultima ? AQ.ultimo : 'Continua') + '</button>';
  setTimeout(function(){ try{ e.scrollIntoView({ behavior: 'smooth', block: 'end' }); }catch(_){ } }, 80);
}
function acQuizAvanti(){
  AQ.i++;
  if (AQ.i < AQ.d.length){ acQuizPaint(); return; }
  const f = AQ.fine, g = AQ.giuste, n = AQ.d.length;
  acQuizChiudi();
  if (typeof f === 'function') f(g, n);
}
function acQuizChiudi(){ const w = document.getElementById('acProva'); if (!w) return; w.removeAttribute('id'); w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 260); }
/** Il tasto indietro di Android con la prova aperta: si torna alla lezione (o al modulo, per l'esame), non si esce dall'app. */
function acProvaBack(){ if (!document.getElementById('acProva')) return false; acQuizChiudi(); return true; }
function acProvaApri(){
  const m = acModule(AC_MOD); if (!m) return;
  const l = m.lessons[AC_LES]; if (!l) return;
  acDomCarica().then(function(){
    let qs = acDomDi(m.id, AC_LES).filter(function(q){ return q.tipo !== 'vf'; });
    if (!qs.length) qs = [acDomandaRiserva(m, l)];
    acQuizApri('Lezione ' + (AC_LES + 1) + ': ' + l.t, qs.slice(0, 2), function(){ acProvaFine(); }, 'Lezione fatta');
  });
}
function acProvaFine(){
  const w = document.getElementById('acProva'); if (w){ w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 260); }
  const m = acModule(AC_MOD); if (!m) return;
  acMark(m.id, AC_LES);
  /* una lezione per volta: si torna al modulo, la prossima la sceglie lui quando vuole */
  acOpenModule(m.id); acRenderList();
  toast(acModuleDone(m) >= m.lessons.length ? 'Modulo completato 🎓' : 'Lezione fatta. La prossima ti aspetta qui.');
}
function acFinishLesson(){
  const m = acModule(AC_MOD);
  if(!m) return;
  acMark(m.id, AC_LES);
  if(AC_LES < m.lessons.length - 1){ acOpenLesson(AC_LES + 1); return; }
  acOpenModule(m.id);
  acRenderList();
  toast('Modulo completato 🎓');
}
function acBackToModule(){ if(AC_MOD) acOpenModule(AC_MOD); else goId('s-academy'); }

/* ---------------------------------------------------------------------------------------
   Esplora: le card orizzontali del profilo
   --------------------------------------------------------------------------------------- */
function exploreCardsHtml(){
  const cards = [
    { ic:'📦', b:'Focus Box', s:'il blocco fisico', fn:'ufOpenUrl(\'https://dream-brothers.com/products/timed-phone-locking-box-for-self-control\')' },
    { ic:'🖥️', b:'DreamMap per PC/Mac', s:'in arrivo', fn:'exploreOpen(\'desktop\')' },
    { ic:'🎓', b:'Academy', s:(acNuoveN() ? (acNuoveN() === 1 ? '1 lezione nuova' : acNuoveN() + ' lezioni nuove') : '5 moduli'), fn:'academyOpen()' },
    { ic:'💬', b:'Canale WhatsApp', s:EXPLORE_LINKS.whatsapp ? 'unisciti' : 'in arrivo', fn:'exploreOpen(\'whatsapp\')' },
    { ic:'✈️', b:'Gruppo Telegram', s:EXPLORE_LINKS.telegram ? 'unisciti' : 'in arrivo', fn:'exploreOpen(\'telegram\')' }
  ];
  return '<div class="ex-scroll">' + cards.map(function(c){
    return '<div class="ex-card" onclick="' + c.fn + '"><span class="ic">' + c.ic + '</span>'
      + '<div><b>' + c.b + '</b><small>' + c.s + '</small></div></div>';
  }).join('') + '</div>';
}
function exploreOpen(which){
  const url = EXPLORE_LINKS[which];
  if(!url){
    toast(which === 'whatsapp' ? 'Il canale WhatsApp non è ancora aperto' : 'Il gruppo Telegram non è ancora aperto');
    return;
  }
  ufOpenUrl(url);
}

/* ---------------------------------------------------------------------------------------
   Seguici: le icone scorrevoli
   --------------------------------------------------------------------------------------- */
/* The same marks the site's footer uses (snippets/icon.liquid of the theme), not emoji: an
   emoji camera is not Instagram and a thumb is not Facebook. Paths are the theme's, verbatim;
   the colour comes from the button so dark mode needs nothing special. */
const SOCIALS = [
  { ic:'<svg viewBox="0 0 16 16"> <path fill-rule="evenodd" clip-rule="evenodd" d="M8 0C5.827 0 5.555.01 4.702.048 3.85.087 3.269.222 2.76.42a3.921 3.921 0 00-1.417.923c-.445.444-.719.89-.923 1.417-.198.509-.333 1.09-.372 1.942C.01 5.555 0 5.827 0 8s.01 2.445.048 3.298c.039.852.174 1.433.372 1.942.204.526.478.973.923 1.417.444.445.89.719 1.417.923.509.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.445-.01 3.298-.048c.852-.039 1.433-.174 1.942-.372a3.922 3.922 0 001.417-.923c.445-.444.719-.89.923-1.417.198-.509.333-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.298c-.039-.852-.174-1.433-.372-1.942a3.922 3.922 0 00-.923-1.417A3.921 3.921 0 0013.24.42c-.509-.198-1.09-.333-1.942-.372C10.445.01 10.173 0 8 0zm0 1.441c2.136 0 2.39.009 3.233.047.78.036 1.203.166 1.485.276.374.145.64.318.92.598.28.28.453.546.598.92.11.282.24.705.276 1.485.038.844.047 1.097.047 3.233s-.009 2.39-.047 3.233c-.036.78-.166 1.203-.276 1.485-.145.374-.318.64-.598.92-.28.28-.546.453-.92.598-.282.11-.705.24-1.485.276-.844.038-1.097.047-3.233.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.479 2.479 0 01-.92-.598 2.478 2.478 0 01-.598-.92c-.11-.282-.24-.705-.276-1.485-.038-.844-.047-1.097-.047-3.233s.009-2.39.047-3.233c.036-.78.166-1.203.276-1.485.145-.374.318-.64.598-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.844-.038 1.097-.047 3.233-.047zm0 9.226a2.667 2.667 0 110-5.334 2.667 2.667 0 010 5.334zm0-6.775a4.108 4.108 0 100 8.216 4.108 4.108 0 000-8.216zm5.23-.162a.96.96 0 11-1.92 0 .96.96 0 011.92 0z" fill="currentColor"></path> </svg>', url:'https://www.instagram.com/dream.brothers_/', name:'Instagram' },
  { ic:'<svg viewBox="0 0 9 17"> <path fill-rule="evenodd" clip-rule="evenodd" d="M2.486 16.2084L2.486 8.81845H0L0 5.93845L2.486 5.93845L2.486 3.81845C2.38483 2.79982 2.73793 1.78841 3.45107 1.05407C4.16421 0.319722 5.16485 -0.0628415 6.186 0.00844868C6.9284 0.00408689 7.67039 0.0441585 8.408 0.128449V2.69845L6.883 2.69845C6.4898 2.61523 6.08104 2.73438 5.79414 3.01585C5.50724 3.29732 5.3803 3.70373 5.456 4.09845L5.456 5.93845H8.308L7.936 8.81845H5.46L5.46 16.2084H2.486Z" fill="currentColor"></path> </svg>', url:'https://www.facebook.com/profile.php?id=61552834966030', name:'Facebook' },
  { ic:'<svg viewBox="0 0 12 16"> <path fill-rule="evenodd" clip-rule="evenodd" d="M5.8042 0.00123531C8.79537 -0.0442356 10.6685 1.16769 11.5498 3.29299C11.8407 3.99433 12.1516 5.28439 11.9181 6.35474C11.825 6.78208 11.7985 7.22812 11.6726 7.63086C11.4163 8.4496 11.0829 9.17441 10.6413 9.79945C10.0418 10.6486 9.13196 11.2212 7.98951 11.5091C6.97899 11.7637 6.04959 11.3826 5.50954 10.9732C5.33747 10.843 5.10674 10.6728 5.04304 10.4377C5.03488 10.4377 5.0267 10.4377 5.01853 10.4377C4.97972 10.8669 4.81532 11.3224 4.69924 11.7135C4.53858 12.2545 4.50733 12.8146 4.3064 13.3208C4.08349 13.8828 3.81274 14.3978 3.52072 14.8776C3.36739 15.1292 2.94427 15.9904 2.63675 16C2.60311 15.9354 2.58964 15.9105 2.58761 15.796C2.48858 15.6383 2.55757 15.3724 2.51393 15.1578C2.44604 14.8236 2.39317 14.2217 2.46491 13.8824C2.46491 13.7038 2.46491 13.5248 2.46491 13.3465C2.54397 12.9786 2.54085 12.6015 2.63675 12.2494C2.84537 11.4824 2.96145 10.6699 3.17692 9.87611C3.38398 9.11352 3.57396 8.27939 3.74172 7.50321C3.77957 7.32789 3.56652 6.82389 3.52072 6.63572C3.37628 6.04186 3.48624 5.21874 3.66805 4.77269C3.89698 4.21111 4.56717 3.3535 5.43589 3.57359C6.13407 3.75039 6.57846 4.50528 6.34437 5.46192C6.09862 6.46589 5.7798 7.3653 5.5587 8.37035C5.50173 8.62933 5.59968 8.90442 5.65687 9.05958C5.86357 9.61934 6.49037 10.163 7.32652 9.95278C8.59396 9.63365 9.15431 8.48627 9.53645 7.24791C9.63981 6.91302 9.62743 6.59647 9.70831 6.22709C9.87894 5.44763 9.80648 4.28411 9.56098 3.67556C9.16753 2.70023 8.43329 2.07518 7.42471 1.73624C7.1465 1.68526 6.86819 1.63427 6.58988 1.58329C6.12397 1.47655 5.23532 1.63685 4.92023 1.73624C3.51171 2.18156 2.63952 2.92544 2.09658 4.26247C1.91177 4.71767 1.81046 5.17911 1.77741 5.81884C1.76913 5.8955 1.76094 5.97217 1.75278 6.04883C1.86153 6.62068 1.87259 6.99959 2.09658 7.42657C2.20715 7.63711 2.46971 7.8029 2.51393 8.06444C2.54001 8.2185 2.42705 8.45105 2.39125 8.57467C2.33705 8.76137 2.35676 8.97522 2.26844 9.13625C2.10873 9.42678 1.67383 9.20852 1.48275 9.08491C0.489307 8.44373 -0.329526 6.5895 0.132284 4.79837C0.20342 4.5218 0.206915 4.28118 0.304126 4.03285C0.906661 2.49554 1.80565 1.55101 3.10325 0.741098C3.58947 0.437749 4.24511 0.287354 4.84657 0.128885C5.16574 0.0863481 5.48503 0.0437917 5.8042 0.00123531Z" fill="currentColor"></path> </svg>', url:'https://it.pinterest.com/DreamBrothersGallery', name:'Pinterest' },
  { ic:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="9.2"/><path d="M2.8 12h18.4M12 2.8c2.6 2.7 3.9 5.8 3.9 9.2s-1.3 6.5-3.9 9.2c-2.6-2.7-3.9-5.8-3.9-9.2S9.4 5.5 12 2.8z"/></svg>', url:'https://dream-brothers.com/', name:'Sito' }
];
function socialsHtml(){
  return '<div class="soc-scroll">' + SOCIALS.map(function(s){
    return '<button type="button" class="soc-btn" title="' + acEsc(s.name) + '" aria-label="' + acEsc(s.name) + '" onclick="ufOpenUrl(\'' + s.url + '\')">' + s.ic + '</button>';
  }).join('') + '</div>';
}

/* ---------------------------------------------------------------------------------------
   Aiuto: domande frequenti e risoluzione dei problemi
   --------------------------------------------------------------------------------------- */
/* 0.9.291, Andrea: "nella pagina Assistenza ci sono ancora le V al posto delle chevron, il titolo e' attaccato alla
   prima domanda e le domande non sono divise per categorie come le FAQ del mio sito". Lo stile e' quello della sezione
   FAQ del tema Shopify: categoria su fondo azzurro con il bordo blu, domande divise da una riga, la domanda aperta su
   un fondo azzurrino, e la chevron che si gira. */
const FAQ_CAT = { blocchi: 'Blocchi e programmi', severa: 'Modalità severa', dati: 'Privacy e dati', account: 'Account e backup' };
const FAQ = [
  { cat:'blocchi', q:'Il blocco non scatta. Perché?',
    a:'Nove volte su dieci il servizio di accessibilità è stato spento dal sistema: succede su Xiaomi, Samsung e Huawei quando la batteria viene ottimizzata.\n\nApri Risoluzione dei problemi e controlla che il servizio di blocco sia attivo, poi togli DreamMap dall\'ottimizzazione batteria.' },
  { cat:'blocchi', q:'Posso bloccare i siti in qualsiasi browser?',
    a:'DreamMap legge l\'indirizzo nei browser più diffusi. In quelli che non espongono la barra degli indirizzi non può leggerlo: in quel caso l\'opzione «Blocca browser non supportati» blocca direttamente il browser, che è l\'unica risposta onesta.' },
  { cat:'blocchi', q:'Che differenza c\'è fra Blocco rapido e programma?',
    a:'Il Blocco rapido è un interruttore: si accende adesso e vale finché non lo spegni. Un programma è una regola che si accende da sola alla condizione che scegli: un orario, un limite di minuti, una rete Wi-Fi, un luogo, o una combinazione.' },
  { cat:'dati', q:'Che cosa legge davvero il servizio?',
    a:'Quale app è in primo piano e, nei browser, l\'indirizzo della pagina. Serve a decidere se bloccare. Non salva la cronologia, non la manda a nessuno e non legge quello che scrivi fuori dalla barra degli indirizzi. L\'informativa completa è in Risoluzione dei problemi › Dati letti dal servizio.' },
  { cat:'severa', q:'Come esco dalla Modalità severa?',
    a:'Con il metodo che hai scelto quando l\'hai attivata: la scadenza del timer, l\'attesa, il PIN, il caricabatterie o la persona di fiducia. Non c\'è una via d\'uscita nascosta, ed è il motivo per cui funziona.' },
  { cat:'dati', q:'I miei dati escono dal telefono?',
    a:'Blocchi, statistiche e programmi restano sul dispositivo. Escono solo se attivi tu il backup sull\'account Google, o il Focus Partner: in quel caso i partner vedono il tuo nome e i numeri del giorno, mai la tua email.' },
  { cat:'account', q:'Ho cambiato telefono. Ritrovo i miei blocchi?',
    a:'Sì, se avevi fatto il backup: accedi con lo stesso account Google e vai in Account › Backup e ripristino. Il backup non include la Modalità severa né il PIN, apposta.' },
  { cat:'blocchi', q:'Il limite di utilizzo conta anche a schermo spento?',
    a:'No. I minuti li misura Android, che sa quando lo schermo si è spento: il telefono posato dentro un\'app non consuma il tuo limite. Serve il permesso ai dati di utilizzo.' },
  { cat:'severa', q:'Ho un\'emergenza vera. Come disattivo la Modalità severa?',
    a:'Dal menu laterale apri Aiuto e feedback e scegli Sblocco di emergenza: c\'è solo con la Modalità severa accesa.\n\nCon il pass si spegne subito. Senza, aspetti: un minuto la prima volta del mese, poi l\'attesa raddoppia.' }
];
const FAQ_CHEV = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';

registerScreen('s-help',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">Assistenza e domande frequenti</b></div>' +
  '<div id="faqList"></div>' +
  '<div class="sect" style="margin-top:34px"><b>Non hai trovato la risposta?</b></div>' +
  '<div class="setrow" onclick="drawerGo(\'s-feedback\')"><span>💬</span><b>Scrivi all\'assistenza</b><small>la risposta arriva via email</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="ufOpenUrl(\'mailto:info@dreambrothers.it\')"><span>✉️</span><b>info@dreambrothers.it</b><span class="chev"></span></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

function helpOpen(){
  const host = document.getElementById('faqList');
  if(host) host.innerHTML = Object.keys(FAQ_CAT).map(function(c){
    const voci = FAQ.map(function(f, i){ return { f: f, i: i }; }).filter(function(x){ return x.f.cat === c; });
    if (!voci.length) return '';
    return '<section class="faq-sez"><h2 class="faq-cat">' + acEsc(FAQ_CAT[c]) + '</h2>'
      + voci.map(function(x){
          return '<div class="faq-q" id="faq' + x.i + '"><button type="button" class="faq-t" aria-expanded="false" onclick="faqToggle(' + x.i + ')"><span>' + acEsc(x.f.q) + '</span>' + FAQ_CHEV + '</button>'
            + '<div class="faq-a">' + acEsc(x.f.a) + '</div></div>';
        }).join('') + '</section>';
  }).join('');
  goId('s-help');
}
function faqToggle(i){
  const el = document.getElementById('faq' + i);
  if(!el) return;
  const on = el.classList.toggle('open');
  const t = el.querySelector('.faq-t'); if (t) t.setAttribute('aria-expanded', on ? 'true' : 'false');
}

registerScreen('s-trouble',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">Risoluzione dei problemi</b></div>' +
  '<p class="hintline" style="padding:0 2px 12px">Se un blocco non è scattato, la causa è quasi sempre qui: un permesso che il sistema ha tolto. Un segno di spunta verde su tutte le voci significa che il motore ha tutto quello che gli serve.</p>' +
  '<div id="troubleRows"></div><div class="spacer"></div>', { back: 's-home' });

function troubleOpen(){
  const host = document.getElementById('troubleRows');
  // The profile fills this when it redraws; if it redrew before this module registered the
  // screen, the rows are still parked and this is where they land.
  if(host && !host.children.length && typeof ufFillTroubleScreen === 'function') ufFillTroubleScreen([]);
  goId('s-trouble');
  if(typeof refreshPerms === 'function') refreshPerms();
  if(typeof ufRefreshExtraPerms === 'function') ufRefreshExtraPerms();
}

/* This module defines what the profile's Esplora and Seguici sections draw, and loads after
   it: tell it to fill them now that the functions exist. */
if (typeof ufPaintExploreSocial === 'function') ufPaintExploreSocial();
document.addEventListener('DOMContentLoaded', function(){
  if (typeof ufPaintExploreSocial === 'function') ufPaintExploreSocial();
});

/* ---------------------------------------------------------------------------------------
   0.9.343: LA FINE DELL'ESAME come la fine della tappa (sentiero-mappa.js, s-sd-fine): la medaglia del modulo, il titolo,
   i tre riquadri che entrano uno alla volta, Continua.
   --------------------------------------------------------------------------------------- */
function acEsameFine(xp){
  const m = acModule(AC_ES.id); if (!m) return;
  const sec = Math.max(1, Math.round((Date.now() - (AC_ES.t0 || Date.now())) / 1000));
  goId('s-sd-fine');
  const h = document.getElementById('sdFine'); if (!h) return;
  const voto = (typeof sdFineVoto === 'function') ? sdFineVoto(sec) : '';
  sdFineDisegna(h, {
    cls: 'ac-fs', tit: 'Esame superato!', sotto: 'Il modulo ' + acEsc(m.name) + ' è tuo.',
    box: '<div class="sd-box gialla"><small>' + (xp ? 'Totale XP' : 'XP già presi') + '</small><b>⚡ ' + (xp || 40) + '</b></div>'
      + '<div class="sd-box verde giro"><small>Risposte giuste</small><b>🎯 ' + AC_ES.giuste + '/' + AC_ES.d.length + '</b></div>'
      + '<div class="sd-box blu"><small>' + acEsc(voto || 'Tempo') + '</small><b>⏱ ' + ((typeof sdMmSs === 'function') ? sdMmSs(sec) : sec + 's') + '</b></div>',
    cta: '<button type="button" class="cta sd-fine-cta" onclick="acEsameFineVia()">Continua</button>'
  });
  const im = h.querySelector('.sd-fine-in > img');
  if (im) im.outerHTML = '<div class="ac-medaglia" aria-hidden="true"><span>' + m.icon + '</span><i>🎓</i></div>';
}
function acEsameFineVia(){
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  goId('s-academy-mod'); acOpenModule(AC_ES.id); acRenderList();
}
/* i disegni delle lezioni: il circolo dell'autosabotaggio e quello della fiducia, come gli schemi che Andrea ha mandato
   (il rosso per la mente che si blocca, il blu per l'azione) */
function acFigura(k){
  const giro = function(tit, voci){
    const pos = [[160, 46], [262, 150], [160, 254], [58, 150]];
    const pill = function(v, i){ const p = pos[i], w = Math.max(80, v[0].length * 10.5 + 26); return '<g><rect x="' + (p[0] - w / 2) + '" y="' + (p[1] - 19) + '" width="' + w + '" height="38" rx="11" fill="' + (v[1] ? '#E63946' : '#0075E3') + '"/><text x="' + p[0] + '" y="' + (p[1] + 6) + '" text-anchor="middle" font-size="16" font-weight="800" fill="#fff" font-family="Poppins,system-ui,sans-serif">' + v[0] + '</text></g>'; };
    const freccia = '<path d="M210 52 Q258 66 268 112" /><path d="M262 192 Q252 240 214 250" /><path d="M108 250 Q66 240 56 192" /><path d="M54 110 Q64 64 108 50" />';
    return '<svg viewBox="0 0 320 300" role="img" aria-label="' + tit + '"><defs><marker id="acFr" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M1 1L9 5L1 9" fill="none" stroke="#8A9BB3" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>'
      + '<g fill="none" stroke="#8A9BB3" stroke-width="2.6" stroke-linecap="round" marker-end="url(#acFr)">' + freccia + '</g>'
      + voci.map(pill).join('') + '</svg><p class="ac-fig-t">' + tit + '</p>';
  };
  if (k === 'sabotaggio') return giro('Il circolo che ti frena', [['+ PENSI', 1], ['+ DUBITI', 1], ['− FAI', 0], ['− FIDUCIA', 0]]);
  if (k === 'fiducia') return giro('Il circolo che ti spinge', [['+ AGISCI', 0], ['− DUBITI', 1], ['+ FAI', 0], ['+ FIDUCIA', 0]]);
  return '';
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.ac-fig{margin:18px -4px 22px;padding:10px 6px;border-radius:22px;background:var(--card,#fff);border:1.5px solid #CFE3FA}.ac-fig svg{display:block;width:100%;height:auto;max-width:360px;margin:0 auto}body.dark .ac-fig{background:#12203A;border-color:#22345A}body.dark .ac-fig text[fill="#5B6F8C"]{fill:#BFD3EC}.ac-fig-t{margin:2px 0 4px;text-align:center;font:700 13.5px var(--font-body);color:#5B6F8C}body.dark .ac-fig-t{color:#BFD3EC}',
    '.ac-medaglia{position:relative;width:148px;height:148px;margin:0 auto 6px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 35% 30%,#5BB6FF 0%,#0075E3 55%,#00459A 100%);box-shadow:0 0 0 8px rgba(140,198,255,.28),0 0 0 16px rgba(140,198,255,.12),0 20px 44px rgba(0,117,227,.45);animation:acMed .8s cubic-bezier(.2,1.4,.4,1) both}',
    '.ac-medaglia span{font-size:70px;line-height:1;filter:drop-shadow(0 4px 8px rgba(0,0,0,.25))}.ac-medaglia i{position:absolute;right:-6px;bottom:4px;font-size:46px;font-style:normal;line-height:1;transform:rotate(-12deg);filter:drop-shadow(0 4px 6px rgba(0,0,0,.3))}',
    '@keyframes acMed{0%{transform:scale(.3) rotate(-25deg);opacity:0}100%{transform:none;opacity:1}}',
    /* 0.9.343, Andrea: "i moduli completati hanno troppo poco contrasto con gli altri: si illumina solo il bordo. Voglio il glow dei
       programmi attivi di Proteggi i tuoi sogni, blu scuro, testo bianco". Tre stati a colpo d'occhio: da fare (bianco, tacche vuote),
       in corso (bordo blu, tacche blu), finito (blu notte con il bagliore, testo bianco, tacche azzurre) */
    '.ac-mod2.corso{border-color:#8CC6FF}',
    '.ac-mod2.fin{position:relative;border-color:#0B84FF!important;background:linear-gradient(160deg,#0B3A7A 0%,#001E44 100%)!important;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.32),0 22px 44px rgba(11,132,255,.2)!important}',
    '.ac-mod2.fin::before{content:"";position:absolute;inset:3px;border:2px solid rgba(255,255,255,.14);border-radius:21px;pointer-events:none}',
    '.ac-mod2.fin .ac-mod2-t b,.ac-mod2.fin .ac-mod2-c{color:#fff!important}.ac-mod2.fin .ac-mod2-c{opacity:.8}.ac-mod2.fin .ac-mod2-t small{color:#8CC6FF!important}.ac-mod2.fin p{color:#C9DBF2!important}.ac-mod2.fin .ac-mod2-ico{background:rgba(255,255,255,.14)!important}.ac-mod2.fin .ac-tacche i{background:#8CC6FF!important;box-shadow:0 0 8px rgba(140,198,255,.6)}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* 0.9.343: la lezione sul circolo dell'autosabotaggio compare come Nuova, una volta */
setTimeout(function(){
  try{
    if (localStorage.getItem('fl_ac_nuova_343')) return; localStorage.setItem('fl_ac_nuova_343', '1');
    const m = acModule('procrastinazione'); if (m && typeof acNuovaSegna === 'function') acNuovaSegna('procrastinazione', m.lessons.length - 1);
  }catch(_){ }
}, 4000);

(function(){ const st = document.createElement('style'); st.textContent = '.ac-les-hint{margin:-4px 0 14px;font:600 12.5px/1.4 var(--font-body);color:var(--muted);text-align:left}#acLesBody{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}'; document.head.appendChild(st); })();
