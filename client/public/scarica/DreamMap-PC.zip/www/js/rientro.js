/* ===========================================================================================
   RIENTRA IN ROTTA: LA DIAGNOSI (0.9.212)

   PRIMA. Il pannello «Ti riporto in rotta» proponeva trenta minuti di Full Focus e basta: la
   cura del sintomo. Il giorno dopo la stessa cosa ti fermava di nuovo, perche' nessuno aveva
   chiesto COSA ti aveva fermato.

   ADESSO. «Rientra in rotta» apre una diagnosi. Il Genio chiede cosa e' successo (un'app che ti
   ha preso, la stanchezza, le idee nuove, non sapere da dove partire, la paura, un imprevisto
   vero), stringe sul dettaglio (quale app, a che ora) e trova il collo di bottiglia. Poi cambia
   il SISTEMA, non la giornata: un programma che blocca quell'app in quella fascia, l'unica cosa
   spostata al mattino, l'ADHD Mode per le idee, i passi per la confusione, i cinque minuti per
   la paura. La data d'arrivo non si aggiusta da sola: torna indietro quando le cose si fanno.

   PREMIUM E GRATIS («vendi il cosa e il perche', non il come»). Senza Premium la diagnosi e' a
   domande fisse, come il Genio di Akinator, e il primo rimedio si applica davvero: si assaggia.
   Con Premium il tuo agente personale riceve la diagnosi, fa le sue domande nella chat, ricorda ogni
   uscita di rotta (fl_rientri va nel suo brief) e propone il blocco su misura. Lo schema che
   emerge dalle uscite passate (l'ora, l'app, la causa che torna) si vede solo con Premium: e'
   un dato vero calcolato qui, coperto, non un testo inventato.
   =========================================================================================== */
const RN_KEY = 'fl_rientri';
const RN = { v: null, i: 0, r: {}, app: [], rimedio: null };
const RN_CAUSE = [
  { k: 'app', ico: '📱', t: 'Un’app mi ha preso' },
  { k: 'stanco', ico: '🪫', t: 'Troppa stanchezza' },
  { k: 'idee', ico: '💡', t: 'Ho fatto altre cose, idee nuove' },
  { k: 'confuso', ico: '🧱', t: 'Non sapevo da dove partire' },
  { k: 'paura', ico: '😰', t: 'Mi metteva ansia, o paura di sbagliare' },
  { k: 'imprevisto', ico: '🗓️', t: 'Un imprevisto vero' }
];
const RN_ORE = [['mattina', '🌅', 'La mattina', '07:00', '12:00'], ['pomeriggio', '☀️', 'Il pomeriggio', '12:00', '18:00'], ['sera', '🌆', 'La sera', '18:00', '22:30'], ['notte', '🌙', 'La notte', '22:30', '02:00']];
function rnEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function rnPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function rnAgente(){ try{ return typeof agAbilitatoOra === 'function' && agAbilitatoOra() && typeof agPuo === 'function' && agPuo(); }catch(_){ return false; } }
function rnLista(){ try{ return JSON.parse(localStorage.getItem(RN_KEY) || '[]') || []; }catch(_){ return []; } }
function rnTask(){
  try{ const day = stDayKey('today'); const p = stPriorita(day, stRigheDi(day)); if (p) return String(p).replace(/^[☐☑•\-]\s*/, ''); }catch(_){ }
  try{ const one = stOne(); if (one && one.task) return String(one.task.text || one.task); }catch(_){ }
  return '';
}
/** Per il tuo agente personale: le ultime uscite di rotta, con causa e rimedio. */
function rnPerAgente(){
  const l = rnLista().slice(-8); if (!l.length) return '';
  return 'Uscite di rotta recenti: ' + l.map(function(x){ return new Date(x.at).toLocaleDateString('it-IT') + ' ' + (RN_CAUSE.filter(function(c){ return c.k === x.causa; })[0] || {}).t + (x.app ? ' (' + x.appNome + ', ' + x.ora + ')' : (x.ora ? ' (' + x.ora + ')' : '')) + ' → ' + (x.rimedio || 'nessun rimedio'); }).join('; ') + '.';
}

registerScreen('s-rientro',
  '<div class="topbar"><button class="iconbtn" onclick="rnIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Rientra in rotta</b></div>'
  + '<div id="rnBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });

function rnApri(v){
  RN.v = v || null; RN.i = 0; RN.r = {}; RN.rimedio = null; RN.app = [];
  goId('s-rientro'); rnPaint();
  rnAppDistraenti();
}
function rnIndietro(){ if (RN.i > 0 && !RN.rimedio){ RN.i--; rnPaint(); return; } if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } } }
/* le app che ti distraggono di piu' fra ieri e oggi: quelle segnate «Distrattivo», in ordine di minuti */
async function rnAppDistraenti(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return;
    const da = new Date(); da.setHours(0, 0, 0, 0);
    const r = await NATIVE.getTopApps({ from: da.getTime() - 86400000, to: Date.now(), limit: 40, icons: 0 });
    const cats = (typeof insCats === 'function') ? insCats(null) : {};
    const l = ((r && r.apps) || []).filter(function(a){ return cats[a.packageName] === 'distr'; }).slice(0, 5);
    const altre = ((r && r.apps) || []).filter(function(a){ return cats[a.packageName] !== 'distr' && cats[a.packageName] !== 'prod' && a.packageName !== 'com.dreambrothers.focuslock'; }).slice(0, 5 - l.length);
    RN.app = l.concat(altre).map(function(a){ return { pkg: a.packageName, nome: a.label || a.appName || a.packageName, min: Math.round((a.ms || 0) / 60000) }; });
    if (RN.i === 1 && RN.r.causa === 'app') rnPaint();
  }catch(_){ }
}
function rnDomande(){
  const c = RN.r.causa;
  const d = [{ k: 'causa', q: 'Quando dovevi fare «' + rnEsc(rnTask() || 'l’unica cosa di oggi') + '», <b>cosa ti ha fermato</b>?', o: RN_CAUSE.map(function(x){ return [x.k, x.ico, x.t]; }) }];
  if (c === 'app') d.push({ k: 'app', q: '<b>Quale app</b> ti ha preso?', o: (RN.app.length ? RN.app.map(function(a){ return [a.pkg, '📱', a.nome + (a.min ? ' · ' + a.min + ' min' : '')]; }) : []).concat([['altro', '❔', 'Un’altra app, o il browser']]) });
  if (c && c !== 'imprevisto') d.push({ k: 'ora', q: 'Di solito, <b>in che momento della giornata</b> ti succede?', o: RN_ORE.map(function(o){ return [o[0], o[1], o[2]]; }) });
  return d;
}
function rnRisp(j){
  const d = rnDomande()[RN.i]; RN.r[d.k] = d.o[j][0];
  if (d.k === 'app'){ const a = RN.app.filter(function(x){ return x.pkg === d.o[j][0]; })[0]; RN.r.appNome = a ? a.nome : ''; }
  try{ flVibra(10); }catch(_){ }
  RN.i++;
  if (RN.i >= rnDomande().length) rnDiagnosi();
  rnPaint();
}
function rnOra(k){ return RN_ORE.filter(function(o){ return o[0] === k; })[0] || RN_ORE[2]; }
/** Il collo di bottiglia e il rimedio che cambia il sistema, non la giornata. */
function rnDiagnosi(){
  const c = RN.r.causa, o = rnOra(RN.r.ora);
  const task = rnTask() || 'l’unica cosa di oggi';
  let x;
  if (c === 'app' && RN.r.app && RN.r.app !== 'altro') x = { collo: RN.r.appNome + ' ' + o[2].toLowerCase(), perche: 'Finché ' + RN.r.appNome + ' si apre ' + o[2].toLowerCase() + ', la volontà deve vincere ogni volta. Basta che perda una volta, e la giornata se ne va.', rimedio: 'Un programma che blocca ' + RN.r.appNome + ' dalle ' + o[3] + ' alle ' + o[4] + ', tutti i giorni', btn: 'Crea il programma', fa: 'rnFaProgramma()' };
  else if (c === 'app') x = { collo: 'un’app che ti prende ' + o[2].toLowerCase(), perche: 'La distrazione arriva sempre alla stessa ora: è un’abitudine, non un incidente.', rimedio: 'Un blocco di tutte le app che distraggono dalle ' + o[3] + ' alle ' + o[4], btn: 'Apri il Blocco', fa: 'rnFaBlocco()' };
  else if (c === 'stanco') x = { collo: 'la stanchezza ' + o[2].toLowerCase(), perche: 'Hai messo la cosa difficile nell’ora in cui il contabile interno fa i prezzi più alti. Non è pigrizia: è l’orario sbagliato.', rimedio: 'L’unica cosa spostata a domattina, come prima riga del foglio di domani', btn: 'Spostala a domattina', fa: 'rnFaMattina()' };
  else if (c === 'idee') x = { collo: 'le idee nuove', perche: 'L’idea nuova vince sempre sulla cosa noiosa, perché accende la testa. Finché resta visibile, ti chiama.', rimedio: 'L’ADHD Mode: le idee nuove nel caveau fino alla data che scegli', btn: 'Accendi l’ADHD Mode', fa: 'rnFaUlisse()' };
  else if (c === 'confuso') x = { collo: 'non sapere da dove partire', perche: 'Una cosa troppo grande non si comincia: la testa vede la montagna, non il primo passo.', rimedio: '«' + task + '» spezzata in passi da pochi minuti', btn: 'Scomponi in passi', fa: 'rnFaPassi()' };
  else if (c === 'paura') x = { collo: 'la paura di sbagliare', perche: 'Si rimanda per non sentire il disagio. Più la cosa pesa, più il primo passo deve essere piccolo.', rimedio: 'Cinque minuti di Full Focus, con il permesso di smettere dopo', btn: 'Parti con cinque minuti', fa: 'rnFaCinque()' };
  else x = { collo: 'un imprevisto vero', perche: 'Gli imprevisti capitano a tutti, e non dicono niente di te. Conta che domani la rotta riparta.', rimedio: 'Nessun blocco: domani l’unica cosa torna in cima', btn: 'Va bene, domani riparto', fa: 'rnFaImprevisto()', imprevisto: true };
  RN.rimedio = x;
  const l = rnLista();
  l.push({ at: Date.now(), causa: c, app: RN.r.app || '', appNome: RN.r.appNome || '', ora: RN.r.ora || '', collo: x.collo, rimedio: x.rimedio, task: task, delta: RN.v && RN.v.delta || 0 });
  try{ localStorage.setItem(RN_KEY, JSON.stringify(l.slice(-60))); }catch(_){ }
}
/** Lo schema delle uscite passate: un dato vero, calcolato qui. */
function rnSchema(){
  const l = rnLista(); if (l.length < 2) return '';
  const conta = function(k){ const m = {}; l.forEach(function(x){ if (x[k]) m[x[k]] = (m[x[k]] || 0) + 1; }); let best = '', n = 0; Object.keys(m).forEach(function(y){ if (m[y] > n){ n = m[y]; best = y; } }); return { v: best, n: n }; };
  const ora = conta('ora'), causa = conta('causa'), app = conta('appNome');
  const parti = [];
  if (ora.n >= 2) parti.push(ora.n + ' uscite su ' + l.length + ' arrivano ' + rnOra(ora.v)[2].toLowerCase());
  if (app.n >= 2) parti.push(app.v + ' torna ' + app.n + ' volte');
  if (causa.n >= 2) parti.push('la causa che si ripete è «' + ((RN_CAUSE.filter(function(c){ return c.k === causa.v; })[0] || {}).t || '').toLowerCase() + '»');
  return parti.join('; ');
}
function rnPaint(){
  const h = document.getElementById('rnBody'); if (!h) return;
  const d = rnDomande();
  if (!RN.rimedio && RN.i < d.length){
    const q = d[RN.i];
    h.innerHTML = '<div class="orc-dots">' + d.map(function(_, i){ return '<i class="' + (i <= RN.i ? 'on' : '') + '"></i>'; }).join('') + '</div>'
      + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div>'
      + (RN.i === 0 && RN.v && RN.v.delta > 0 ? '<p class="rn-delta">L’arrivo si è spostato di ' + rnEsc(typeof nvGiorni === 'function' ? nvGiorni(RN.v.delta) : '') + '. Prima di rientrare, capiamo cosa è successo: così non ricapita.</p>' : '')
      + '<p class="orc-q">' + q.q + '</p>'
      + '<div class="orc-lista rst-opz">' + q.o.map(function(o, j){ return '<button type="button" onclick="rnRisp(' + j + ')"><span>' + o[1] + '</span>' + rnEsc(o[2]) + '</button>'; }).join('') + '</div>';
    return;
  }
  const x = RN.rimedio, prem = rnPremium() || rnAgente();
  const schema = rnSchema();
  h.innerHTML = '<div class="orc-genio"><img src="img/genio/genio-rivela.png" alt=""></div><p class="orc-eti">Il collo di bottiglia</p><h2 class="orc-h">' + rnEsc(x.collo.charAt(0).toUpperCase() + x.collo.slice(1)) + '</h2>'
    + '<p class="rn-perche">' + rnEsc(x.perche) + '</p>'
    + '<div class="rn-rimedio"><small>' + (x.imprevisto ? 'La rotta' : 'Il rimedio che cambia il sistema') + '</small><b>' + rnEsc(x.rimedio) + '</b><button type="button" class="cta rn-fa" onclick="rnScelto();' + x.fa + '">' + rnEsc(x.btn) + '</button></div>'
    + '<p class="rn-nota">La data d’arrivo non si aggiusta da sola: torna indietro quando l’unica cosa è fatta.</p>'
    + (prem
        ? '<div class="rn-agente"><span>🧞</span><div><b>Il tuo agente personale ricorda questa uscita</b><p>' + (schema ? 'Lo schema che vede: ' + rnEsc(schema) + '.' : 'Dalla seconda uscita di rotta comincia a vedere lo schema.') + '</p><button type="button" class="ghostmini" onclick="rnAgenteChiedi()">Raccontalo al tuo agente personale</button></div></div>'
        : '<div class="rn-agente chiuso"><span>🔒</span><div><b>Il tuo agente personale avrebbe chiesto di più</b><p>Con Premium il tuo agente personale fa le sue domande, ricorda ogni uscita di rotta e trova lo schema che si ripete' + (schema ? ':' : '.') + '</p>' + (schema ? '<p class="rn-coperto">' + rnEsc(schema) + '</p>' : '') + '<button type="button" class="cta rn-prem" onclick="if(typeof pwUpsellApri===\'function\')pwUpsellApri();else go(11)">Sblocca la diagnosi del tuo agente personale</button></div></div>');
}
/* ---- i rimedi ---- */
/* la causa e' trovata e il rimedio scelto: il pannello «Ti riporto in rotta» puo' andare via */
function rnScelto(){ try{ if (typeof nvRientroSegna === 'function') nvRientroSegna(); }catch(_){ } }
function rnFatto(msg){ try{ if (typeof nvRientroSegna === 'function') nvRientroSegna(); }catch(_){ } toast(msg); const l = rnLista(); if (l.length){ l[l.length - 1].fatto = Date.now(); try{ localStorage.setItem(RN_KEY, JSON.stringify(l)); }catch(_){ } } try{ if (typeof nvVisto === 'function') nvVisto(RN.v); }catch(_){ } goId('s-home'); try{ switchTab('rotta'); }catch(_){ } }
function rnFaProgramma(){
  const o = rnOra(RN.r.ora);
  if (typeof frProgrammaDaAgente === 'function') frProgrammaDaAgente({ nome: 'Rientro in rotta: ' + RN.r.appNome, app: [RN.r.app], dalle: o[3], alle: o[4] }, false);
  rnFatto('Programma creato: ' + RN.r.appNome + ' bloccata dalle ' + o[3] + ' alle ' + o[4]);
}
function rnFaBlocco(){ goId('s-home'); try{ switchTab('severa'); }catch(_){ } toast('Crea un programma per la fascia ' + rnOra(RN.r.ora)[2].toLowerCase()); }
function rnFaMattina(){
  const t = rnTask(); const dom = (typeof mtKey === 'function') ? mtKey(Date.now() + 86400000) : '';
  if (t && dom){ try{ const r = (typeof stRigheDi === 'function') ? stRigheDi(dom).filter(function(x){ return x !== t; }) : []; localStorage.setItem('fl_notes_' + dom, [t].concat(r).join('\n')); if (typeof fsToccato === 'function') fsToccato(dom); }catch(_){ } }
  rnFatto('Domattina, prima di tutto: «' + (t || 'l’unica cosa') + '»');
}
function rnFaUlisse(){ goId('s-home'); if (typeof ulImpApri === 'function') ulImpApri(); }
/* i passi li scrive il tuo agente personale SUBITO, in una conversazione nuova: niente «arrivano fra poco» */
function rnFaPassi(){
  const t = rnTask() || 'l’unica cosa di oggi';
  try{ if (typeof nvRientroSegna === 'function') nvRientroSegna(); }catch(_){ }
  if (typeof agNuovaConversazione === 'function'){ agNuovaConversazione('Scomponi in passi da pochi minuti questa task, così so da dove partire: «' + t + '»'); return; }
  if (typeof agApri === 'function') agApri();
}
function rnFaCinque(){ goId('s-home'); try{ switchTab('sveglia'); }catch(_){ } setTimeout(function(){ try{ const p = ffPref(); p.minutes = 5; ffSavePref(); if (typeof stGoFocus === 'function') stGoFocus(); }catch(_){ } }, 350); }
function rnFaImprevisto(){ rnFatto('Domani si riparte: l’unica cosa resta in cima'); }
function rnAgenteChiedi(){
  const l = rnLista(), x = l[l.length - 1] || {};
  const testo = 'Ho perso la rotta. Collo di bottiglia: ' + (x.collo || '') + '. Rimedio scelto: ' + (x.rimedio || '') + '. Fammi le domande che servono per capire perché succede, e proponimi un blocco o un programma su misura perché non ricapiti.';
  if (typeof agApri === 'function'){ Promise.resolve(agApri()).then(function(){ AG.vista = 'chat'; agPaint(); }); setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900); }
}

(function(){
  const css = [
    '#rnBody{padding:0 18px}.rn-delta{margin:0 0 12px;padding:12px 14px;border-radius:14px;background:rgba(230,57,70,.08);font:600 13.5px/1.5 var(--font-body);color:#B91C2C;text-align:center}',
    '.rn-perche{margin:0 0 16px;text-align:center;font:500 14.5px/1.55 var(--font-body);color:var(--muted)}',
    '.rn-rimedio{padding:18px 16px;border-radius:20px;border:1.5px solid #0075E3;background:rgba(0,117,227,.06)}.rn-rimedio small{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.rn-rimedio b{display:block;margin:6px 0 14px;font:800 17px/1.35 var(--font-body);color:var(--navy)}body.dark .rn-rimedio b{color:#fff}.rn-fa{width:100%;margin:0 !important;background:#E63946 !important;color:#fff !important}',
    '.rn-nota{margin:12px 0 0;text-align:center;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.rn-agente{display:flex;gap:12px;margin-top:20px;padding:16px 14px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .rn-agente{background:#12203A;border-color:#22345A}.rn-agente > span{font-size:28px}.rn-agente > div{flex:1}.rn-agente b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .rn-agente b{color:#fff}.rn-agente p{margin:4px 0 10px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.rn-agente.chiuso{background:linear-gradient(160deg,#14234A,#0B1530);border-color:transparent}.rn-agente.chiuso b{color:#fff}.rn-agente.chiuso p{color:rgba(255,255,255,.75)}.rn-coperto{filter:blur(5px);user-select:none;color:#fff !important;font-weight:700 !important}.rn-prem{width:100%;margin:6px 0 0 !important;background:#fff !important;color:#001E44 !important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
