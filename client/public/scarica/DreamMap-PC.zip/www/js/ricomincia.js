/* ===========================================================================================
   RICOMINCIA DA CAPO (0.9.238)

   Andrea: "Rivedi il primo avvio" deve poter anche RIPARTIRE da zero, come un ripristino del
   telefono, ma scegliendo cosa tenere (come quando il telefono chiede se salvare foto e musica).
   - "Rivedi soltanto": il film del primo avvio, senza cambiare niente (genio-intro.js lo protegge).
   - "Ricomincia da capo": si sceglie cosa tenere; la lettura del Genio, la data d'arrivo e il suo
     storico ripartono sempre da zero (e' il motivo per cui si ricomincia).
   Restano SEMPRE: le regole di blocco e i programmi (prima se ne fa una copia nell'account Google),
   la Modalita' severa se e' accesa (altrimenti ricominciare sarebbe un modo per scappare dai blocchi),
   l'account, Premium, le preferenze del telefono.
   =========================================================================================== */
const RC_SEMPRE = [/^fl_(user|premium|premium_since|premium_until|trial_used|offer_until|device_id|dark|lang|a11y_consent|privacy_extra|loc_disclosed|backup_at|undo_at|piano_chiave|fonte|grants_extra|rated|widget_on|lega_nick|fr_me|ref|restore_asked|toast_wanted)$/,
  /^fl_(programs|groups|blocco_cfg|regole_cache|rules_pub|rules_pub_v2|cats_edit|grey_programs|sound_programs|ins_excl|ins_excl_riam|ins_cat|ins_fasce|strict|strict_asked|strict_cfg|focusbox|box_ultimo|silenzio|nd|assenze|alarms|alarm_slots|alarm_info|lockquote_on|bgs)$/,
  /^fl_sev_/,
  /* 0.9.302, Andrea: "se telefono e computer erano collegati non si devono scollegare". Il segno dei due dispositivi
     (i tre puntini "Da dove") e la sorgente scelta restano: prima il reset li cancellava e il pannello tornava al
     solo telefono, senza la voce per scegliere il computer finche' l'app non lo ritrovava. */
  /^fl_(due_dispositivi|rep_fonte)$/,
  /* 0.9.301: i sogni realizzati e le Roadmap dei viaggi conclusi restano SEMPRE (dal livello finale si riparte da qui) */
  /^fl_(sogni_realizzati|sd_viaggi)$/,
  /* 0.9.259, Andrea: le personalizzazioni restano SEMPRE: immagine del profilo, dell'Io futuro, della mappa, l'agente e i suoi documenti */
  /^fl_(avatar_img|if_img|mappa_cover_img|agente|rif_agente|rif_iofuturo|agente_modello|agente_modello_chat|dt_pos|musica_muto)$/,
  /* 0.9.260, Andrea: dopo il reset il Vecchio te si e' trovato 10 punti in piu'. Cancellando questi registri l'arbitro
     ricontava come nuove tutte le richieste fuori rotta di oggi gia' segnate. Sono il ricordo di cosa e' gia' stato
     contato: restano sempre. */
  /^fl_arbitro_/,
  /* il Report disegnato l'ultima volta: si mostra subito e si aggiorna da solo */
  /^fl_(ins_cache_|pfr_cache|grey_cache)/,
  /* 0.9.261, Andrea: le personalizzazioni di pagine e schede restano SEMPRE, da sole: chi ha passato ore a
     sistemare blocchi, sezioni, schede e immagini non deve rifare tutto. (Le immagini grandi stanno in
     IndexedDB, che Ricomincia non tocca.) */
  /^fl_(dream_chips|foglio_schede|foglio_lista|pagina_off|sev_sezioni|sev_glow|mappa_cfg|mappa_mia_blocchi|mappa_rotta_blocchi|start_cfg|cst_blocco|why_img|why_imgs|slide_img|slide_off|pr_nascosti|pr_ordine|rm_schede|mantra_avatar|um_off|widget_skin|widget_skins|sfide_cfg|match_cfg|tema|tema_)/];
const RC_GRUPPI = [
  { k: 'diario', n: 'Il diario di viaggio', s: 'Le pagine che hai scritto, le note e le foto', on: true, re: [/^fl_(diario_|dv_|if_diario)/] },
  { k: 'piano', n: 'Il piano', s: 'I fogli di Oggi e Domani, il calendario, le pagine in stile Notion', on: true, re: [/^fl_(notes|notes_|notion|notion_ws|foglio_|cal_|plan_|prio_fatta_|domani_|fine_lavoro|one|one_hist)/] },
  { k: 'note', n: 'Le note e il caveau', s: 'Le tue note, le note veloci, le idee nel caveau', on: true, re: [/^fl_(note_|caveau|ulisse|appunti_)/] },
  { k: 'sogno', n: 'Il tuo sogno e la roadmap', s: 'Gli orizzonti, la rotta, i passi della roadmap, il tuo perché', on: false, re: [/^fl_(orizzonti|rotta|roadmap_agente|why|why_|mappa_|mp_|sogno_pubblico|sogni_realizzati|viaggio_opz|mm_)/] },
  { k: 'mappa', n: 'I livelli della mappa', s: 'Le tappe del sentiero già fatte, la serie di giorni', on: true, re: [/^fl_(sd|sd_|sentiero|serie_|streak|streak_broken|perc_ancora|lv_|esercizi|scrigni|sfide|sfide_|coins|dream_points|trees|combo|records)/] },
  { k: 'partita', n: 'La partita: Nuovo te contro Vecchio te', s: 'Tieni il punteggio di adesso. Spento (come parte): la partita ricomincia da 0 a 0', on: false, re: [/^fl_(deviazioni|prenota)/] },
  { k: 'storia', n: 'La storia del telefono', s: 'Report, tempo sullo schermo, sonno, umore, respiro, sessioni di Full Focus', on: true, re: [/^fl_(dayrep_|pc_usage|report|week_|ff_hist|sonno_|umore|respiro|interrupts|interrupts_log|mio_usage_at|screen|dopa_|altro_usage|app_nomi)/] }
];
const RC = { scelte: {} };

function rivediOnboarding(){
  if (typeof inSheet !== 'function'){ if (typeof gnRivedi === 'function') gnRivedi(); return; }
  inSheet('<div class="rc-sh"><b>Il primo avvio</b>'
    + '<button type="button" class="rc-op" onclick="inSheetChiudi();rcRivedi()"><span class="rc-ico">' + rcIco('play') + '</span><div><b>Rivedi soltanto</b><small>Il racconto del Genio dall’inizio. Non cambia niente: la tua lettura e la tua data restano.</small></div></button>'
    + '<button type="button" class="rc-op" onclick="inSheetChiudi();rcApri()"><span class="rc-ico">' + rcIco('giro') + '</span><div><b>Ricomincia da capo</b><small>La lettura del Genio e la data d’arrivo ripartono da zero. Scegli tu cosa tenere.</small></div></button></div>');
}
function rcRivedi(){
  try{ document.documentElement.classList.remove('fl-home'); }catch(_){ }
  if (typeof gnRivedi === 'function') gnRivedi(); else if (typeof go === 'function') go(0);
}
function rcIco(k){
  const p = { play: '<path d="M8 5v14l11-7z"/>', giro: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>', scudo: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>' }[k] || '';
  return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
}
function rcSeveraAccesa(){
  try{ if (typeof sevActive === 'function') return !!sevActive(); }catch(_){ }
  try{ const s = JSON.parse(localStorage.getItem('fl_strict') || 'null'); return !!(s && (s.on || s.active || (s.until && s.until > Date.now()))); }catch(_){ return false; }
}
registerScreen('s-ricomincia',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\');try{switchTab(\'profilo\')}catch(_){}" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Ricomincia da capo</b></div>'
  + '<div id="rcBody"></div><div class="spacer"></div>', { back: 's-home' });
function rcApri(){
  RC.scelte = {}; RC_GRUPPI.forEach(function(g){ RC.scelte[g.k] = g.on; });
  goId('s-ricomincia'); rcPaint();
}
function rcPaint(){
  const h = document.getElementById('rcBody'); if (!h) return;
  const sev = rcSeveraAccesa();
  h.innerHTML = '<p class="rc-p">La lettura del Genio e la data d’arrivo ripartono da zero, come la prima volta. Prima scegli cosa tenere: quello che lasci acceso resta com’è.</p>'
    + '<div class="rc-card"><b class="rc-tit">Restano sempre</b>'
    +   '<div class="rc-fisso"><span class="rc-ico">' + rcIco('scudo') + '</span><div><b>Le regole di blocco e i programmi</b><small>Prima ne faccio una copia nel tuo account Google.</small></div></div>'
    +   '<div class="rc-fisso"><span class="rc-ico">' + rcIco('scudo') + '</span><div><b>Come hai sistemato l’app</b><small>Blocchi, sezioni, schede, immagini e widget restano come li hai messi.</small></div></div>'
    +   (sev ? '<div class="rc-fisso"><span class="rc-ico">' + rcIco('scudo') + '</span><div><b>La Modalità severa</b><small>È accesa: resta accesa fino alla sua scadenza.</small></div></div>' : '')
    + '</div>'
    + '<div class="rc-card"><b class="rc-tit">Cosa vuoi tenere</b>'
    +   RC_GRUPPI.map(function(g){ return '<div class="blk-swrow"><div><b>' + g.n + '</b><small>' + g.s + '</small></div><button type="button" class="switch' + (RC.scelte[g.k] ? ' on' : '') + '" aria-label="Tieni: ' + g.n + '" onclick="RC.scelte[\'' + g.k + '\']=!RC.scelte[\'' + g.k + '\'];rcPaint()"></button></div>'; }).join('')
    + '</div>'
    + '<button type="button" class="cta rc-via" onclick="rcConferma()">Ricomincia da capo</button>';
}
async function rcConferma(){
  const ok = (typeof blkConfirm === 'function')
    ? await blkConfirm('Ricominci da capo?', 'La lettura del Genio e la data d’arrivo ripartono da zero. Quello che hai tenuto acceso resta. Non si torna indietro.', 'Ricomincia', true)
    : window.confirm('Ricominci da capo?');
  if (!ok) return;
  /* la copia delle regole nell'account, prima di toccare qualunque cosa */
  try{ if (typeof ufBackupSave === 'function' && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.backupSave) await ufBackupSave(true); }catch(_){ }
  /* la partita: se non la tieni, si fischia una partita nuova (livescore.js lsRiparti), cosi'
     anche gli altri dispositivi e il cloud ripartono da 0 a 0; le sue chiavi restano, azzerate */
  if (!RC.scelte.partita){
    try{ if (typeof lsRiparti === 'function') lsRiparti(); }catch(_){ }
    /* 0.9.264: prima si scrive sul server la partita nuova (0 a 0), poi si ricarica. Prima la scrittura
       partiva un secondo e mezzo dopo, ma la pagina si ricaricava prima: il server restava con la
       partita vecchia, e al primo giro il telefono se la riprendeva. */
    try{ if (typeof lsSync === 'function') await Promise.race([lsSync(true), new Promise(function(r){ setTimeout(r, 6000); })]); }catch(_){ }
    try{ ['fl_dc_js', 'fl_match_hist'].forEach(function(k){ localStorage.removeItem(k); }); }catch(_){ }
  }
  const tieni = [].concat(RC_SEMPRE, [/^fl_match/]);
  RC_GRUPPI.forEach(function(g){ if (RC.scelte[g.k]) [].push.apply(tieni, g.re); });
  const via = [];
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (!k || k.indexOf('fl_') !== 0) continue;
      if (tieni.some(function(re){ return re.test(k); })) continue;
      via.push(k);
    }
  }catch(_){ }
  via.forEach(function(k){ try{ localStorage.removeItem(k); }catch(_){ } });
  /* 0.9.262: anche il livello riparte dall'inizio (levels.js lo azzera al prossimo calcolo) */
  try{ localStorage.setItem('fl_lv_azzera', '1'); ['fl_lv_base', 'fl_lv_seen', 'fl_lv_festa'].forEach(function(k){ localStorage.removeItem(k); }); }catch(_){ }
  try{ localStorage.setItem('fl_reset_ultimo', String(Date.now())); }catch(_){ }
  toast('Si riparte da capo');
  setTimeout(function(){ location.reload(); }, RC.scelte.partita ? 700 : 1600);
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.rc-sh{padding:4px 2px 8px}.rc-sh>b{display:block;font:800 18px var(--font-display,var(--font-body));color:var(--navy,#14234A);margin-bottom:12px}',
    '.rc-op{display:flex;align-items:flex-start;gap:12px;width:100%;text-align:left;border:0;border-radius:16px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:14px;margin-bottom:10px;cursor:pointer;font:inherit;color:var(--navy,#14234A)}',
    '.rc-op b{display:block;font:800 15px var(--font-body)}.rc-op small,.rc-fisso small{display:block;margin-top:3px;font:500 13px/1.45 var(--font-body);color:var(--muted,#5B6B86)}',
    '.rc-ico{flex:none;width:40px;height:40px;border-radius:12px;background:#EAF3FE;color:#0075E3;display:grid;place-items:center}',
    '#rcBody{padding:6px 16px 0}.rc-p{font:500 14px/1.5 var(--font-body);color:var(--muted,#5B6B86);margin:4px 2px 14px}',
    '.rc-card{border-radius:18px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:14px;margin-bottom:12px}.rc-tit{display:block;font:800 15px var(--font-display,var(--font-body));color:var(--navy,#14234A);margin-bottom:8px}',
    '.rc-fisso{display:flex;gap:12px;align-items:flex-start;padding:8px 0}.rc-fisso b{display:block;font:700 14.5px var(--font-body);color:var(--navy,#14234A)}',
    '.rc-via{margin:6px 0 10px}'
  ].join('');
  document.head.appendChild(st);
})();
