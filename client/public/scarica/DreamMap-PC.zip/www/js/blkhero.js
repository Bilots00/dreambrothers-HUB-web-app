/* blkhero.js - the slideshow sections at the top of Blocco, Modalità severa and Report.

   A port of the theme's own Slideshow section (sections/slideshow.liquid) to the app: the
   same anatomy - image with a Ken Burns zoom, a base overlay, an eyebrow above a heading
   whose lines rise one after the other, and progress bars that fill for the length of the
   autoplay cycle - and the same timings (the heading starts once the image transition is
   done, the lines are staggered, the bar is the cycle). The clouds at the foot are the
   theme's own divider, and they are what separates the night from the white page under it.

   Three sections share this machinery, because they are the same section with different
   content:
     Blocco   two slides, autoplay: the promise, then the Focus Box with its own image and a
              button that opens the product page in the browser.
     Severa   one slide: the streak panel floating in the sky, and under it the two figures
              (hours of focus, days in a row).
     Report   one slide: the day's score, with a ring around each figure.
   A one-slide section has no dots and no timer: there is nothing to move to. */

const FL_HEROES = {};                 // key -> { slide, timer, held, n, cycle, auto, tabId, hostId }
const BH_SWEEP_MS = 700;               // durata dello sweep (solo caroselli con opts.sweep)
const BH_TITLE_DELAY = 560;           // _db_title_delay_ms for the "sweep" transition
const BH_LINE_STEP = 110;
const BH_CYCLE = 7000;

/* The product the second slide points at. The link is the clean product URL: the _pos/_psq/
   shpxid parameters of a copied address belong to one browsing session, not to a build. */
const BH_FOCUSBOX_URL = 'https://dream-brothers.com/products/timed-phone-locking-box-for-self-control';

/* ---------- pieces ---------- */

/* One line of a heading. `i` is its place in the stagger, counting the eyebrow as 0. */
function flHeroLine(t, i){
  return '<span class="ln" style="--i:' + i + '"><i>' + esc(t) + '</i></span>';
}

/* The theme's "Clouds Border (Mobile)" divider, in the colour of the page below it. */
function flHeroClouds(){
  return '<div class="prof-clouds" aria-hidden="true"><svg viewBox="0 0 1079 222" preserveAspectRatio="none">'
    + '<path fill="currentColor" d="M1892 85.955V222H-812V101.045C-807.936 99.2828 -803.785 97.9292 -799.442 96.9236C-767.887 89.6201 -739.625 97.8605 -725.622 118.451L-722.365 123.24L-720.18 111.329C-711.532 64.2599 -669.839 21.6916 -612.442 1.32756C-560.803 -16.994 -500.245 -14.7645 -454.1 7.1579C-427.701 19.6973 -406.341 38.8233 -394.304 60.7072L-387.784 72.5618L-383.052 64.1362C-371.016 42.7166 -342.658 20.6163 -312.438 9.10685C-253.434 -13.3629 -183.179 -2.84902 -143.746 34.3515C-121.792 55.0648 -110.995 81.5502 -114.083 107.122C-114.948 114.318 -115.388 120.514 -115.051 120.89C-114.714 121.265 -111.816 119.287 -108.618 116.495C-99.8454 108.828 -82.8208 100.457 -68.9061 96.9635C-54.2727 93.2865 -24.6977 92.467 -11.8026 95.3794C11.4716 100.637 35.3839 116.329 44.2814 132.181C47.6922 138.267 50.7876 140.542 50.7216 136.922C50.6629 133.526 64.13 114.744 74.8686 103.258C86.2306 91.1033 107.964 74.9154 124.432 66.3469C147.302 54.4419 172.19 47.3937 206.394 43.1341C254.086 37.1933 311.175 50.769 346.714 76.5023C371.301 94.3036 390.13 118.921 395.844 140.736L397.274 146.22L402.834 135.393C417.482 106.859 451.143 88.9582 491.662 88.1524C511.533 87.7587 523.217 90.1367 541.724 98.3427C564.763 108.554 580.959 124.924 584.817 141.885L586.24 148.166L591.8 137.128C603.837 113.227 631.637 92.4166 664.307 82.8634C677.203 79.0934 684.384 78.2321 705.809 77.8943C734.482 77.4415 749.079 79.8084 772.786 88.7538C795.495 97.3224 824.344 118.382 836.447 135.222L839.366 139.281L847.42 132.893C858.569 124.053 871.002 120.075 888.298 119.805C906.731 119.52 919.245 123.614 939.761 136.644L945.072 140.017L943.715 131.846C939.981 109.392 951.263 79.4647 971.053 59.3248C1032.66 -3.35963 1152.65 -5.07344 1228.87 55.6419C1251.27 73.4767 1268.77 99.5913 1276.93 127.367L1280.29 138.788L1285.3 131.59C1295.14 117.474 1321.27 108.532 1342.52 112.002C1369.84 116.463 1391.47 134.742 1397.24 158.24L1399.78 168.601L1402.91 161.716C1407.58 151.435 1425.24 130.001 1436.78 120.586C1466.59 96.2649 1504.7 83.319 1549.19 82.3959C1594.07 81.4645 1629.71 92.1071 1662.34 116.18C1674.05 124.823 1692.02 145.838 1698.27 158.225C1702.45 166.493 1705.98 169.223 1705.89 164.121C1705.81 159.461 1718.12 135.955 1725.43 126.834C1749.99 96.1609 1791.04 77.9736 1837.82 77.0454C1857.53 76.6535 1875.5 79.5921 1892 85.955Z"/>'
    + '</svg></div>';
}

/*
 * How far a full-bleed section has to stick out to touch the glass.
 *
 * It was written as -40px (the tab's 18 plus the screen's 22) and that is a guess about two
 * stylesheets that can change: on the phone it left the page a couple of dozen pixels wider
 * than the screen. Measured instead, it is exact anywhere, and it is one number shared by
 * every full-width section.
 */
let FL_BLEED = -1;
function flSetBleed(){
  const phone = document.getElementById('phone');
  // The tab that is ON SCREEN. A hidden tab has display:none and therefore clientWidth 0, and
  // measuring that one gave a bleed of 208px: the profile's sky came out twice the width of
  // the phone and the page could be dragged sideways.
  const tab = document.querySelector('.tabpage.on') || document.querySelector('.tabpage');
  if (!phone || !tab || !tab.clientWidth) return;
  const inner = tab.clientWidth - (parseFloat(getComputedStyle(tab).paddingLeft) || 0)
                                - (parseFloat(getComputedStyle(tab).paddingRight) || 0);
  if (inner <= 0) return;
  const bleed = Math.max(0, Math.round((phone.clientWidth - inner) / 2));
  /* 0.9.264: una variabile sulla radice ricalcola lo stile di TUTTA la pagina: si riscrive solo se cambia */
  if (bleed === FL_BLEED) return;
  FL_BLEED = bleed;
  document.documentElement.style.setProperty('--bleed', bleed + 'px');
}
addEventListener('resize', flSetBleed);
document.addEventListener('fl:tab', flSetBleed);

/* The header over the sky: transparent at the top of a tab that opens with a sky, solid after
   48px of scroll or on any other tab. The sky itself is pulled up under the header (the tab's
   negative margin) and padded inside by the header's height, so nothing is hidden by it. */
/* 0.9.263, Andrea: tutta l'app scattava scorrendo. Questa funzione girava a OGNI evento di scroll e a ogni giro
   riscriveva --hdr-h su tutta la Home (stile ricalcolato per l'intera pagina), poi leggeva offsetHeight (layout
   forzato subito dopo la scrittura) e ripassava tutte le schede. Adesso il lavoro pesante si fa solo quando
   cambia scheda o misura (flHeaderSync); allo scroll si guarda soltanto se il vetro dell'intestazione va
   acceso o spento, una volta per fotogramma, e si tocca la classe solo se cambia davvero. */
const FL_HDR = { h: -1, top: false, glass: null, raf: 0 };
function flHeaderSync(){
  const home = document.getElementById('s-home');
  const head = home ? home.querySelector('.home-head') : null;
  const tab = document.querySelector('.tabpage.on');
  if (!home || !head || !tab) return;
  const h = head.offsetHeight;
  if (h !== FL_HDR.h){ FL_HDR.h = h; home.style.setProperty('--hdr-h', h + 'px'); }
  const hero = tab.querySelector(':scope > .bh, :scope > .prof-sky');
  let top = false;
  if (hero && hero.offsetHeight > 0){
    let first = null;
    for (let i = 0; i < tab.children.length; i++){
      const c = tab.children[i];
      if (!c.hidden && c.offsetHeight > 0){ first = c; break; }
    }
    top = first === hero;
  }
  FL_HDR.top = top;
  document.querySelectorAll('.tabpage').forEach(t => { const v = t === tab && top; if (t.classList.contains('hero-top') !== v) t.classList.toggle('hero-top', v); });
  flHeaderVetro(tab, head);
}
/* 0.9.265 (lag): l'intestazione "di vetro" in cima alla scheda. Prima un gestore dello scroll leggeva scrollTop a ogni
   fotogramma, e la lettura obbligava a ricalcolare la pagina (360 ms su 5 secondi di scroll in START). Adesso un
   segnaposto alto zero in cima a ogni scheda e un IntersectionObserver: dice da solo quando si e' sotto i 48 px. */
function flHeaderVetro(tab, head){
  head = head || document.querySelector('#s-home .home-head');
  tab = tab || document.querySelector('.tabpage.on');
  if (!head || !tab) return;
  const g = FL_HDR.top && tab._inCima !== false;
  if (g !== FL_HDR.glass){ FL_HDR.glass = g; head.classList.toggle('glass', g); }
}
function flHeaderSegno(t){
  let m = t.querySelector(':scope > .fl-segno-cima');
  if (!m){ m = document.createElement('i'); m.className = 'fl-segno-cima'; m.setAttribute('aria-hidden', 'true'); m.style.cssText = 'display:block;height:0;margin:0;padding:0;pointer-events:none'; }
  if (t.firstElementChild !== m) t.insertBefore(m, t.firstElementChild);
  if (!t._segIo && 'IntersectionObserver' in window){
    t._segIo = new IntersectionObserver(function(v){
      t._inCima = v[v.length - 1].isIntersecting;
      if (t.classList.contains('on')) flHeaderVetro(t);
    }, { root: t, rootMargin: '48px 0px 0px 0px', threshold: 0 });
    t._segIo.observe(m);
  }
}
document.querySelectorAll('.tabpage').forEach(flHeaderSegno);
document.addEventListener('fl:tab', function(){ document.querySelectorAll('.tabpage').forEach(flHeaderSegno); });
/* una volta al cambio scheda (al fotogramma dopo, a pagina disegnata) e una di controllo quando le immagini sono arrivate */
document.addEventListener('fl:tab', function(){ requestAnimationFrame(flHeaderSync); setTimeout(flHeaderSync, 700); });
addEventListener('resize', flHeaderSync);
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(flHeaderSync, 300); });
else setTimeout(flHeaderSync, 300);
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', flSetBleed);
else flSetBleed();

/* ---------- the generic section ---------- */

/*
 * Builds the section once, as the first thing in its tab.
 *   key      the name it is driven by ('blocco', 'severa', 'insights')
 *   tabId    the tab it belongs to
 *   hostId   the id of the <section>
 *   slides   an array of slide html
 *   opts     { auto: true to rotate, tall: true to let it grow with its content }
 */
/* LE SLIDE SI TOLGONO E SI RIMETTONO (0.9.187). fl_slide_off = { <key>: [data-i, ...] }: le
   slide spente non entrano nel carosello. data-i resta quello scritto nel codice, cosi' chi
   cerca la sua slide per numero la trova ancora (o non la trova, se e' spenta). Ne resta
   sempre almeno una, e quelle in FL_SLIDE_FISSE (dove sta una matita) non si spengono. */
const FL_SLIDE_KEY = 'fl_slide_off';
const FL_SLIDE_DEF = {
  rotta: [{ i: 9, n: 'Le date importanti del mese (compare da sola)' }, { i: 0, n: 'Arrivo previsto' }, { i: 1, n: 'Liberati dai ladri di sogni' }, { i: 2, n: 'Mettimi alla prova' }, { i: 3, n: 'La frase del giorno' }],
  start: [{ i: 0, n: 'La partita (qui c\u2019è la matita)', fissa: true }, { i: 1, n: 'Ricordati perché hai iniziato' }, { i: 2, n: 'Da cosa dipende la rotta' }, { i: 3, n: 'La sera prima' }],
  blocco: [{ i: 0, n: 'Liberati dai ladri di sogni' }, { i: 1, n: 'Riprendi il controllo · Focus Box' }, { i: 2, n: 'La Focus Box · le tue notti' }]
};
/* I BLOCCHI DELLE PAGINE che si tolgono dalla stessa matita (0.9.188): per ora la Focus Box
   nella pagina «Proteggi i tuoi sogni». fl_pagina_off = { <key>: [id, ...] } */
const FL_PAGINA_BLOCCHI = { blocco: [{ id: 'fbBoard', n: 'La Focus Box (pannello)' }] };
function flPaginaOff(key){ try{ const o = JSON.parse(localStorage.getItem('fl_pagina_off') || '{}') || {}; return Array.isArray(o[key]) ? o[key] : []; }catch(_){ return []; } }
function flPaginaApplica(key){
  const off = flPaginaOff(key);
  (FL_PAGINA_BLOCCHI[key] || []).forEach(function(b){ const el = document.getElementById(b.id); if (el) el.classList.toggle('pg-off', off.indexOf(b.id) >= 0); });
}
function flPaginaSet(key, id, on){
  let o = {}; try{ o = JSON.parse(localStorage.getItem('fl_pagina_off') || '{}') || {}; }catch(_){ }
  const l = (Array.isArray(o[key]) ? o[key] : []).filter(function(x){ return x !== id; });
  if (!on) l.push(id);
  o[key] = l; try{ localStorage.setItem('fl_pagina_off', JSON.stringify(o)); }catch(_){ }
  flPaginaApplica(key);
  return true;
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'blocco') setTimeout(function(){ flPaginaApplica('blocco'); }, 300); });
function flSlideOff(key){ try{ const o = JSON.parse(localStorage.getItem(FL_SLIDE_KEY) || '{}') || {}; return Array.isArray(o[key]) ? o[key] : []; }catch(_){ return []; } }
function flSlideFiltra(key, slides){
  const off = flSlideOff(key);
  const fisse = (FL_SLIDE_DEF[key] || []).filter(function(d){ return d.fissa; }).map(function(d){ return d.i; });
  /* 0.9.242: una slide spenta dalla Modalità severa o dalla stagione di spinta (blocchi-sezioni.js) non entra */
  const chiusa = function(i){ try{ return typeof bsSlideBloccata === 'function' && bsSlideBloccata(key, i); }catch(_){ return false; } };
  let tenute = slides.filter(function(h){ const m = String(h).match(/data-i="(\d+)"/); const i = m ? +m[1] : -1; return !chiusa(i) && (fisse.indexOf(i) >= 0 || off.indexOf(i) < 0); });
  if (!tenute.length) tenute = slides.slice(0, 1);
  /* la prima rimasta e' quella accesa */
  return tenute.map(function(h, k){ h = String(h).replace(/class="bh-slide on( |")/, function(_, c){ return 'class="bh-slide' + (c === '"' ? '"' : ' '); }); return k === 0 ? h.replace('class="bh-slide', 'class="bh-slide on') : h; });
}
function flSlideSet(key, i, on){
  try{ if (on && typeof bsSlideBloccata === 'function' && bsSlideBloccata(key, i)){ if (typeof bsAvvisa === 'function') bsAvvisa('genio-giochi'); return false; } }catch(_){ }
  let o = {}; try{ o = JSON.parse(localStorage.getItem(FL_SLIDE_KEY) || '{}') || {}; }catch(_){ }
  const l = (Array.isArray(o[key]) ? o[key] : []).filter(function(x){ return x !== i; });
  if (!on) l.push(i);
  const tutte = (FL_SLIDE_DEF[key] || []).map(function(d){ return d.i; });
  if (tutte.length && tutte.every(function(x){ return l.indexOf(x) >= 0; })){ toast('Ne serve almeno una'); return false; }
  o[key] = l; try{ localStorage.setItem(FL_SLIDE_KEY, JSON.stringify(o)); }catch(_){ }
  flHeroRifai(key);
  return true;
}
/* il carosello si rifa' con le slide nuove, e chi lo riempie lo riempie di nuovo */
function flHeroRifai(key){
  const h = FL_HEROES[key];
  const host = h ? document.getElementById(h.hostId) : null;
  const dove = host ? host.nextSibling : null, padre = host ? host.parentElement : null;
  if (host){ try{ clearInterval(h.timer); }catch(_){ } host.remove(); delete FL_HEROES[key]; }
  try{
    if (key === 'blocco' && typeof blkHeroEnsure === 'function') blkHeroEnsure();
    if (key === 'start' && typeof stHeroEnsure === 'function'){ stHeroEnsure(); if (typeof sevHeroPaint === 'function') sevHeroPaint(); }
    if (key === 'rotta' && typeof nvPaint === 'function') nvPaint();
  }catch(_){ }
  const nuovo = FL_HEROES[key] && document.getElementById(FL_HEROES[key].hostId);
  if (nuovo && padre && nuovo.parentElement !== padre) padre.insertBefore(nuovo, dove && dove.parentElement === padre ? dove : null);
  try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ }
  try{ if (key === 'start' && typeof scsApplica === 'function') scsApplica(); }catch(_){ }
  try{ if (key === 'rotta' && typeof cstApplica === 'function') cstApplica(); }catch(_){ }
  try{ flHeaderSync(); }catch(_){ }
}
/* il foglio con gli interruttori, uguale per tutte le schede */
function flSlideFoglio(key, titolo){
  let w = document.getElementById('flSlideSheet');
  if (!w){ w = document.createElement('div'); w.id = 'flSlideSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) w.remove(); }); document.body.appendChild(w); }
  const off = flSlideOff(key);
  w.innerHTML = '<div class="sd-sheet-in fl-sl-sheet"><i class="pr-grab"></i><h3>' + (titolo || 'Le slide') + '</h3><h4 class="fl-sl-h">Le slide</h4><p>Spegni le slide che non vuoi vedere. Le riaccendi da qui quando vuoi.</p>'
    + (FL_SLIDE_DEF[key] || []).map(function(d){
        const on = d.fissa || off.indexOf(d.i) < 0;
        const chiusa = (typeof bsSlideBloccata === 'function') && bsSlideBloccata(key, d.i);
        if (chiusa) return '<div class="fl-sl-row"><b>' + d.n + '</b><small class="bs-lock">' + (typeof bsChi === 'function' && bsChi('genio-giochi') === 'stagione' ? 'Spenta durante la stagione di spinta' : 'Spenta finché dura la Modalità severa') + '</small><button type="button" class="switch" disabled aria-disabled="true" aria-label="' + d.n + '"></button></div>';
        return '<div class="fl-sl-row"><b>' + d.n + '</b>' + (d.fissa ? '<small>Resta sempre</small>' : '<button type="button" class="switch' + (on ? ' on' : '') + '" onclick="if(flSlideSet(\'' + key + '\',' + d.i + ',!this.classList.contains(\'on\')))this.classList.toggle(\'on\')" aria-label="' + d.n + '"></button>') + '</div>';
      }).join('')
    + ((FL_PAGINA_BLOCCHI[key] || []).length ? '<h4 class="fl-sl-h">I blocchi della pagina</h4>' + FL_PAGINA_BLOCCHI[key].map(function(b){
        const on = flPaginaOff(key).indexOf(b.id) < 0;
        return '<div class="fl-sl-row"><b>' + b.n + '</b><button type="button" class="switch' + (on ? ' on' : '') + '" onclick="if(flPaginaSet(\'' + key + '\',\'' + b.id + '\',!this.classList.contains(\'on\')))this.classList.toggle(\'on\')" aria-label="' + b.n + '"></button></div>';
      }).join('') : '')
    + '<button type="button" class="sd-btn-link" onclick="document.getElementById(\'flSlideSheet\').remove()">Chiudi</button></div>';
  w.hidden = false;
}
function flHeroEnsure(key, tabId, hostId, slides, opts){
  const tab = document.getElementById(tabId);
  if (!tab) return null;
  let host = document.getElementById(hostId);
  if (host) return host;
  opts = opts || {};
  if (FL_SLIDE_DEF[key]) slides = flSlideFiltra(key, slides);
  host = document.createElement('section');
  host.id = hostId;
  host.className = 'bh' + (opts.tall ? ' bh--tall' : '') + (opts.auto ? '' : ' bh--manual');
  if (opts.h) host.style.setProperty('--bh-h', opts.h + 'px');
  host.innerHTML = '<div class="bh-track">' + slides.join('') + '</div>'
    + (slides.length > 1 ? flHeroDots(key, slides.length) : '')
    + (opts.clouds === false ? '' : flHeroClouds());
  /* opts.into: un cielo in mezzo alla pagina invece che in cima. Serve all'intermezzo fra
     due sezioni, che e' una diapositiva a tutti gli effetti ma non apre niente. */
  const into = opts.into ? document.getElementById(opts.into) : null;
  if (into) into.appendChild(host);
  else tab.insertBefore(host, tab.firstChild);
  /* Un carosello rifatto non deve lasciare dietro il battito del precedente. */
  try{ if (FL_HEROES[key] && FL_HEROES[key].timer) clearInterval(FL_HEROES[key].timer); }catch(_){ }
  FL_HEROES[key] = { slide: 0, timer: 0, held: 0, last: Date.now(), n: slides.length, cycle: BH_CYCLE, auto: !!opts.auto, tabId: tabId, hostId: hostId, sweep: !!opts.sweep };
  if (opts.sweep) host.classList.add('bh--sweep');
  flSetBleed();
  if (slides.length > 1){
    const track = host.querySelector('.bh-track');
    let x0 = 0;
    /* IL DITO CHE PASSA NON E' UN DITO CHE SCEGLIE.
       `held` sospende la rotazione per qualche secondo dopo che sei stato TU a cambiare
       diapositiva. Veniva messo su `touchstart`, cioe' su qualunque dito appoggiato sopra —
       e l'intermezzo sta in mezzo alla pagina, quindi bastava scorrere la scheda per
       congelarlo. Con «ogni 3 secondi» impostato si vedeva una diapositiva ferma per un
       quarto di minuto: «a volte va, a volte no». Adesso lo mette solo una scorsa vera. */
    /* 0.9.256, Andrea: scorrendo di lato la pagina scendeva anche in basso (il dito non e' mai perfettamente
       orizzontale). Appena il gesto si capisce laterale, il verticale si blocca; se e' verticale, lo
       slideshow lascia scorrere la scheda e non cambia diapositiva. */
    let y0 = 0, lato = null;
    track.addEventListener('touchstart', function(e){ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; lato = null; }, { passive: true });
    track.addEventListener('touchmove', function(e){
      const dx = e.touches[0].clientX - x0, dy = e.touches[0].clientY - y0;
      if (lato == null && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) lato = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'x' : 'y';
      if (lato === 'x' && e.cancelable) e.preventDefault();
    }, { passive: false });
    track.addEventListener('touchend', function(e){
      const dx = e.changedTouches[0].clientX - x0;
      const fu = lato; lato = null;
      if (fu !== 'y' && Math.abs(dx) > 45) flHeroGo(key, (FL_HEROES[key].slide + (dx < 0 ? 1 : -1) + slides.length) % slides.length);
    }, { passive: true });
  }
  if (opts.auto) flHeroAuto(key);
  return host;
}

function flHeroDots(key, n){
  let out = '<div class="bh-dots">';
  for (let i = 0; i < n; i++) out += '<button class="bh-dot' + (i === 0 ? ' on' : '') + '" onclick="flHeroGo(\'' + key + '\',' + i + ')"><i></i></button>';
  return out + '</div>';
}

/**
 * Va alla diapositiva `i`. `auto` e' vero quando a chiedere il cambio e' il timer.
 *
 * <p>PERCHE' QUESTO TERZO ARGOMENTO. `held` e' l'ora dell'ultimo tocco: serve a non far
 * scivolare via una diapositiva mentre qualcuno la sta guardando dopo averla aperta lui
 * (quattordici secondi di tregua). Ma veniva aggiornato ANCHE dai cambi automatici, e cosi'
 * ogni cambio si rimandava da solo di quattordici secondi: con «ogni 4 secondi» impostato, le
 * diapositive giravano ogni sedici. Il timer non tocca piu' `held`, e l'impostazione torna a
 * voler dire quello che dice.</p>
 */
function flHeroGo(key, i, auto){
  const h = FL_HEROES[key];
  const host = h && document.getElementById(h.hostId);
  if (!host) return;
  const track = host.querySelector('.bh-track');
  if (!track) return;
  if (!auto) h.held = Date.now();
  h.last = Date.now();
  /* LO SWEEP (solo dove e' chiesto, opts.sweep: lo slideshow di Dream). Come l'opzione
     «Sweep» del tema Shopify: la nuova diapositiva entra SOPRA alla vecchia dal lato verso
     cui si va, con un taglio (clip-path) che scorre dal bordo e la foto che si sposta appena.
     La vecchia resta accesa sotto finche' non e' coperta, cosi' non sparisce di colpo. */
  if (h.swFin) h.swFin();
  const prev = h.slide, kids = track.children;
  const sweep = h.sweep && prev !== i && kids[prev] && kids[i] && h.n > 1;
  const dir = sweep ? (((i - prev + h.n) % h.n) <= h.n / 2 ? 'r' : 'l') : '';
  /* 0.9.261: l'altezza si misura PRIMA di accendere la nuova diapositiva. Misurata dopo, le due erano gia'
     impilate e si bloccava il doppio (604 -> 1208 px): le nuvole scendevano di una schermata e sparivano. */
  const altezzaPrima = sweep ? track.offsetHeight : 0;
  h.slide = i;
  Array.prototype.forEach.call(track.children, function(s, k){
    if (sweep && k === prev) return;
    s.classList.toggle('on', k === i);
    // The animations are declared on .on, so removing and re-adding the class replays them
    // exactly as the theme does when a slide comes back round.
    if (k === i){ void s.offsetWidth; }
  });
  if (sweep){
    const vec = kids[prev], nuova = kids[i];
    /* 0.9.259, Andrea: con due diapositive accese insieme la pista cambiava altezza per un attimo e la
       pagina sotto saltava («si viene portati giu'»). L'altezza resta bloccata finche' lo sweep finisce. */
    try{ track.style.transition = 'none'; track.style.height = altezzaPrima + 'px'; }catch(_){ }
    vec.classList.add('bh-out', 'bh-sw-' + dir);
    nuova.classList.add('bh-in', 'bh-sw-' + dir);
    /* 0.9.292, Andrea: "cambiando slide si taglia per un attimo il testo (6% del percorso, il paragrafo della sfida del
       Genio)". L'altezza bloccata era quella della diapositiva che esce: quando quella che entra e' piu' alta, il suo
       fondo restava sotto alle nuvole finche' lo sweep non finiva. Si blocca la piu' alta delle due. */
    try{ const hNuova = nuova.offsetHeight; if (hNuova > altezzaPrima) track.style.height = hNuova + 'px'; }catch(_){ }
    const fin = function(){
      clearTimeout(t);
      if (h.swFin !== fin) return;
      h.swFin = null;
      vec.classList.remove('bh-out', 'bh-sw-r', 'bh-sw-l');
      if (h.slide !== prev) vec.classList.remove('on');
      nuova.classList.remove('bh-in', 'bh-sw-r', 'bh-sw-l');
      try{ track.style.height = ''; setTimeout(function(){ track.style.transition = ''; }, 50); }catch(_){ }
    };
    const t = setTimeout(fin, BH_SWEEP_MS + 40);
    h.swFin = fin;
  }
  const dots = host.querySelector('.bh-dots');
  if (dots) Array.prototype.forEach.call(dots.children, function(d, k){ d.classList.toggle('on', k === i); });
  // whoever needs to know which slide is up (the phrase typing itself, the header's pill)
  try{ document.dispatchEvent(new CustomEvent('fl:slide', { detail: { key: key, i: i } })); }catch(_){ }
}

/**
 * La rotazione automatica, guidata dall'OROLOGIO e non dal periodo del timer.
 *
 * <p>Prima era un {@code setInterval(fn, cycle)} in cui ogni battito poteva saltare: scheda
 * chiusa, pagina nascosta, tregua dopo un tocco. Un battito saltato pero' non e' un ritardo
 * piccolo — e' un ciclo intero buttato: con tre secondi impostati, tornare sulla scheda un
 * istante dopo un battito voleva dire aspettarne altri tre, e due tregue di fila facevano
 * stare ferma la stessa diapositiva mezzo minuto. In piu' la WebView rallenta i timer lunghi
 * quando l'app va dietro, e al ritorno il periodo non torna sempre quello di prima.</p>
 *
 * <p>Adesso il battito e' fisso a un quarto di secondo e non decide niente: guarda
 * l'orologio. Se sono passati {@code cycle} millisecondi dall'ultimo cambio, cambia. Se il
 * carosello e' fermo (scheda chiusa, pagina nascosta, tregua), il conto riparte da adesso, e
 * quindi chi torna sulla scheda ha la diapositiva per intero. L'impostazione «ogni 3 secondi»
 * vuol dire tre secondi, sempre.</p>
 */
const BH_TICK = 250;
/* La tregua dopo una scorsa fatta col dito: nove secondi. Quattordici erano tarati su un
   cielo in cima alla pagina che si tocca di rado; su un intermezzo che si sfoglia sono
   un'eternita'. */
const BH_HOLD = 9000;
function flHeroAuto(key){
  const h = FL_HEROES[key];
  if (!h) return;
  clearInterval(h.timer);
  h.last = Date.now();
  h.timer = setInterval(function(){
    /* SI SPEGNE DA SOLO. Se il carosello e' stato rifatto, FL_HEROES[key] e' un altro
       oggetto e questo battito appartiene a un fantasma: continuerebbe a spingere una
       diapositiva vecchia contro quella nuova, che e' il modo piu' elegante di restare
       bloccati su una slide per sempre. */
    if (FL_HEROES[key] !== h){ clearInterval(h.timer); return; }
    const host = document.getElementById(h.hostId);
    if (!host){ clearInterval(h.timer); h.timer = 0; return; }
    const tab = document.getElementById(h.tabId);
    const home = document.getElementById('s-home');
    const fermo = !tab || !tab.classList.contains('on')
      || !home || !home.classList.contains('active')
      || document.hidden
      || (Date.now() - h.held) < BH_HOLD;
    if (fermo){ h.last = Date.now(); return; }
    if (Date.now() - h.last < h.cycle) return;
    /* 0.9.265 (lag): mentre si scorre la diapositiva non cambia: cambiarla vuol dire ricalcolare e ridisegnare il
       carosello, ed e' lavoro che fatto durante lo scroll si sente come uno scatto. Cambia appena ti fermi. */
    if (typeof flInScroll === 'function' && flInScroll()) return;
    flHeroGo(key, (h.slide + 1) % h.n, true);
  }, BH_TICK);
}

/* Coming back to the tab replays the current slide, like reloading the page does on the site. */
function flHeroReplay(key){
  const h = FL_HEROES[key];
  if (h) flHeroGo(key, h.slide, true);
}

/* Every link out of here is the shop, which is a website: it opens in the system browser,
   not inside the app's own WebView (which has no chrome, no back and no address bar). */
function flHeroOpen(url){
  if (typeof ufOpenUrl === 'function') ufOpenUrl(url);
  else window.open(url, '_blank');
}

/* ---------- BLOCCO: the promise, then the Focus Box ---------- */

function blkHeroSlides(){
  return [
    /* 1. The drawing: the climb up the stairs with the phone, the bed, the TV and the clock
       chained to the ankles, the flag at the top reading DREAMS. */
    '<article class="bh-slide on" data-i="0" style="--bh-img:url(\'img/dream-thieves.jpg\');--bh-pos:center 38%">'
    +   '<div class="bh-img"></div><span class="bh-ov dark"></span>'
    +   '<div class="bh-text">'
    +     '<p class="bh-eyebrow">' + flHeroLine('Liberati', 0) + '</p>'
    +     '<h2 class="bh-title">' + flHeroLine('Dai ladri di sogni', 1) + '</h2>'
    +   '</div>'
    + '</article>',
    /* 2. The Focus Box, text in the middle of the slide, the button lit like the site's and
       arriving only once the title has finished its sweep. */
    '<article class="bh-slide" data-i="1" style="--bh-img:url(\'img/focus-box.jpg\')">'
    +   '<div class="bh-img"></div><span class="bh-ov veil-mid"></span>'
    +   '<div class="bh-text">'
    +     '<p class="bh-eyebrow">' + flHeroLine('Riprendi il controllo', 0) + '</p>'
    +     '<h2 class="bh-title">' + flHeroLine('Del tuo tempo', 1) + '</h2>'
    +     '<button class="bh-cta bh-cta--glow bh-cta--late" onclick="flHeroOpen(\'' + BH_FOCUSBOX_URL + '\')">Discover</button>'
    +   '</div>'
    + '</article>',
    /* 3. (0.9.188) LA FOCUS BOX come slide: le notti con il telefono nella scatola, la serie.
       La disegna focusbox.js (fbSlidePaint), con gli stessi numeri del pannello. */
    '<article class="bh-slide" data-i="2" style="--bh-img:url(\'img/focus-box.jpg\')">'
    +   '<div class="bh-img"></div><span class="bh-ov dark"></span>'
    +   '<div class="bh-text" id="fbSlideBox"></div>'
    + '</article>'
    /* La frase del giorno e' traslocata: e' una diapositiva della scheda Sogno (rotta-tab.js). */
  ];
}
/* Niente rotazione automatica: la slide la cambia chi guarda, con un dito o con le lineette.
   Con la terza slide che parte a macchina da scrivere e col suo suono, una rotazione che
   arriva da sola mentre fai altro e' un rumore che nessuno ha chiesto. */
function blkHeroEnsure(){
  const host = flHeroEnsure('blocco', 'tab-blocco', 'blkHero', blkHeroSlides(), { auto: false, h: 340 });
  /* la matita (0.9.187): quali slide vedere in questa pagina */
  if (host && !host.querySelector('.bh-edit')) host.insertAdjacentHTML('beforeend', '<button type="button" class="bh-edit" onclick="flSlideFoglio(\'blocco\',\'Proteggi i tuoi sogni\')" aria-label="Personalizza la pagina">✎</button>');
  return host;
}

/* The screen time report sits between the slideshow and the quick block, so the first thing
   under the sky is the number the whole tab is about. */
function blkReportEnsure(){
  const tab = document.getElementById('tab-blocco');
  if (!tab) return null;
  let el = document.getElementById('blkReport');
  if (el) return el;
  el = document.createElement('div');
  el.id = 'blkReport';
  const qb = tab.querySelector('.qb');
  if (qb) tab.insertBefore(el, qb); else tab.appendChild(el);
  return el;
}
function blkHeroReplay(){ blkHeroEnsure(); flHeroReplay('blocco'); }
/* kept for any older call site: the dots now go through flHeroGo */
function blkHeroGo(i){ flHeroGo('blocco', i); }

/* ---------- MODALITÀ SEVERA: the streak in the sky, the two figures under it ---------- */

function sevHeroEnsure(){
  /* UNA DIAPOSITIVA SOLA, e cosi' deve restare.
     Per un giorno qui davanti c'e' stata anche la rotta; poi la rotta ha avuto la sua scheda
     («Viaggio») e quella copia e' rimasta indietro. Un carosello alto prende l'altezza dal
     contenuto, quindi con due diapositive il testo della prima finiva sotto alle nuvole — e la
     stessa mappa compariva in due punti dell'app. Se un giorno servira' una seconda
     diapositiva qui, va aggiunta insieme alla sua altezza, non da sola. */
  /* DUE DIAPOSITIVE, e la seconda ha la sua altezza fissa (vedi .sev-globo): il cielo con la
     serie e le ore di concentrazione, poi la cartina del mondo con l'aereo, le tappe
     sull'oceano e quanto manca ad arrivare. */
  /* 27/09/2026: le due diapositive hanno traslocato. La prima (la bolla, il mantra) e' la
     seconda della slideshow di START (start.js), la seconda (la cartina) apre la slideshow
     della Mappa (mappa-tab.js). Qui si assicura solo che esista la casa della prima. */
  if (typeof stHeroEnsure === 'function') return stHeroEnsure();
  return null;
}
/** La cartina nella seconda diapositiva: la stessa della sezione mappa, con le sue tappe. */
function sevGloboPaint(){
  const box = document.getElementById('sevGlobo');
  if (!box) return;
  const st0 = (typeof rtStato === 'function') ? rtStato() : {};
  const senzaCartina = st0.strato === 'mosse' || st0.strato === 'memento';
  const bottone = (typeof RT_STRATI !== 'undefined' && typeof rtStratoDopo === 'function') ? '<button type="button" class="mpf-btn mpf-strato" style="position:absolute;top:12px;right:12px;z-index:3" onclick="event.stopPropagation();rtSalva({strato:rtStratoDopo(rtStato().strato),stratoScelto:true});mpSlideRidisegna();try{toast(RT_STRATI[rtStato().strato].nome)}catch(_){}" aria-label="Cambia tipo di mappa">' + RT_STRATI[rtStratoDopo(st0.strato)].ico + '</button>' : '';
  if (typeof mpGloboHtml !== 'function' || typeof rtStato !== 'function'){
    /* 0.9.267: anche senza destinazione si passa alle mosse del Genio e al memento mori (il pulsante a destra) */
    box.innerHTML = '<div class="sev-globo-vuoto" style="position:relative"><b>La rotta</b><p>Se il tuo sogno ha un luogo nel mondo, sceglilo: qui vedrai la rotta.</p>' + bottone + '</div>';
    return;
  }
  /* 0.9.293, Andrea: "se il sogno non ha un luogo nel mondo, 'scegli una destinazione dal Genio' non ha senso: la slide
     deve mostrare i passi della mappa". Senza destinazione la slide mostra le mosse del Genio (o il memento, se scelto). */
  if (!st0.a){
    const stratoV = st0.strato === 'memento' ? 'memento' : 'mosse';
    /* le mosse del Genio / il memento mori senza cartina: il riquadro e il pulsante per cambiare tipo */
    const h0 = '<div class="sev-globo-in" style="position:relative"><div id="sevGloboMappa" class="mp-globo"></div>' + bottone + '</div>';
    if (box.dataset.firma !== h0){ box.dataset.firma = h0; box.innerHTML = h0; }
    setTimeout(function(){
      const m = document.getElementById('sevGloboMappa'); if (!m || typeof rtMappaHtml !== 'function') return;
      const L = Math.max(200, Math.round(m.clientWidth || 340)), H = Math.max(160, Math.round(m.clientHeight || 220));
      m.innerHTML = rtMappaHtml(null, null, stratoV, L, H, (typeof MP_TAPPE !== 'undefined' && MP_TAPPE) || []);
    }, 30);
    return;
  }
  /* IL PANNELLO DELL'ARRIVO NON STA PIU' QUI (0.9.189): e' la prima slide di Dream e il
     pannello sotto all'interruttore. Due volte la stessa data a due schede di distanza era
     un doppione; sotto la cartina resta la percentuale. */
  const html = '<div class="sev-globo-in">' + mpGloboHtml(false).replace('id="mpGlobo"', 'id="sevGloboMappa"') + '</div>';
  /* LA STESSA CARTINA NON SI RIDISEGNA. Ridisegnarla rimette in moto la salita e il bagliore:
     se la rotta e il pannello sono quelli di prima, resta com'e'. */
  if (box.dataset.firma === html && box.querySelector('#sevGloboMappa svg')) return;
  box.dataset.firma = html;
  box.innerHTML = html;
  /* 0.9.292, Andrea: "scelto il satellite nella pagina della mappa, uscendo nella slide compaiono le mosse del Genio".
     La slide disegna sempre la cartina (mappa-pagina.js le passa lo strato geografico), ma il disegno vero arrivava
     30 ms dopo e rileggeva lo stato quando lo strato vero (le mosse) era gia' tornato: si tiene quello di adesso. */
  const sOra = rtStato();
  setTimeout(function(){
    const m = document.getElementById('sevGloboMappa');
    if (!m || typeof rtMappaHtml !== 'function') return;
    const s = sOra;
    const L = Math.max(200, Math.round(m.clientWidth || 340)), H = Math.max(160, Math.round(m.clientHeight || 220));
    m.innerHTML = rtMappaHtml(s.da, s.a, s.strato, L, H, (typeof MP_TAPPE !== 'undefined' && MP_TAPPE) || []);
    /* la misura a cui e' stata disegnata: mppGloboStorto (mappa-tab.js) ridisegna solo se e' sbagliata */
    if (m.clientWidth) box.dataset.lw = String(L);
  }, 30);
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(sevGloboPaint, 400); if (e.detail === 'sveglia') setTimeout(sevVistaProgressi, 600); });
document.addEventListener('fl:slide', function(e){ if (e && e.detail && e.detail.key === 'start' && e.detail.i === 1) setTimeout(sevVistaProgressi, 200); });
/* PERCHE' RIPARTIVA OGNI SETTE SECONDI. `fl:slide` lo manda OGNI carosello quando cambia
   diapositiva — anche quello del Mind Movie, sulla stessa scheda, che gira da solo ogni
   sette secondi. Qui si ascoltava senza guardare chi parlava, e a ogni giro la cartina si
   ridisegnava da capo con la sua animazione. Adesso conta solo il carosello della Roadmap,
   quando arriva sulla seconda diapositiva. */
document.addEventListener('fl:slide', function(e){
  const d = e && e.detail;
  if (!d || d.key !== 'mappa' || d.i !== 0) return;
  setTimeout(sevGloboPaint, 60);
});


/*
 * What the sky shows.
 *
 * `n` is the streak in days, and it is passed in rather than read here: sevStreakDays(false)
 * DELETES the stored streak, so only the one place that knows whether a strict session is
 * running may ask for it. Zero means no session, and then the panel says so instead of
 * congratulating someone who has not started.
 */
function sevHeroPaint(n){
  sevHeroEnsure();
  const box = document.getElementById('sevHeroBox');
  if (!box) return;
  /* LA PRIMA DIAPOSITIVA, finche' non hai scelto dove vuoi arrivare: un'alba sopra le nuvole
     e «Let your dreams take flight». La mappa senza una destinazione e' una mappa di niente;
     questa e' la domanda fatta con un'immagine. Scelta la meta, torna il cielo di sempre. */
  const slide = box.closest('.bh-slide');
  const senzaMeta = (typeof rtStato === 'function') && !(rtStato().a);
  if (senzaMeta){
    /* UNA COSA ALLA VOLTA. Prima le due righe che salgono dal basso come nelle altre
       diapositive — «Let your dreams» piccolo, «BE YOUR WINGS» grande — sull'aereo nel
       tramonto che ha scelto Andrea. Poi, finita la salita, il testo se ne va e resta una
       cosa sola: dove comincia il viaggio, e il pulsante. Mai tutte e due insieme. */
    if (slide){
      slide.style.setProperty('--bh-img', 'url("img/bg/take-flight.jpg")');
      slide.style.setProperty('--bh-pos', 'center 42%');
      slide.classList.add('volo');
    }
    if (box.dataset.volo === '2') return;                 // gia' al secondo tempo: non si riparte
    if (box.dataset.volo === '1') return;                 // sta ancora salendo
    /* LA SALITA PARTE QUANDO LA SI PUO' VEDERE. La scheda viene dipinta all'avvio, sotto allo
       splash e dietro alle altre schede: se il cronometro partisse li', chi apre Roadmap
       troverebbe il secondo tempo e non vedrebbe mai le due righe salire. Finche' la scheda
       non e' davanti, il testo resta fermo in attesa (volo = 0) e riparte da capo all'apertura. */
    const tab = document.getElementById('tab-severa');
    const boot = document.getElementById('boot');
    const bootVia = !boot || boot.hidden || !boot.isConnected || boot.classList.contains('gone')
      || getComputedStyle(boot).display === 'none' || +getComputedStyle(boot).opacity === 0;
    const davanti = !!(tab && tab.classList.contains('on')) && bootVia;
    box.dataset.volo = davanti ? '1' : '0';
    box.innerHTML = '<div class="bh-text sev-volo-t' + (davanti ? '' : ' fermo') + '">'
      + '<p class="bh-eyebrow">' + flHeroLine('Lascia che i tuoi sogni', 0) + '</p>'
      + '<h2 class="bh-title">' + flHeroLine('Siano le tue ali', 1) + '</h2>'
      + '</div>';
    if (!davanti){ sevVoloAttendi(); return; }
    const attesa = BH_TITLE_DELAY + BH_LINE_STEP + 850 + 1700;
    setTimeout(function(){
      if (box.dataset.volo !== '1') return;
      if (typeof rtStato === 'function' && rtStato().a){ box.dataset.volo = ''; sevHeroPaint(0); return; }
      box.dataset.volo = '2';
      /* SOLO LA FRASE. Il pulsante «Scegli la destinazione» ripeteva parola per parola il campo
         del pannello sottostante: due richieste identiche a dieci pixel di distanza. La
         destinazione si sceglie una volta sola, nell'intro, e si cambia accanto alla mappa. */
      box.innerHTML = '<div class="sev-volo">'
        + '<small>Il tuo viaggio comincia qui</small>'
        + '</div>';
    }, attesa);
    return;
  }
  if (slide){ slide.style.removeProperty('--bh-img'); slide.style.removeProperty('--bh-pos'); slide.classList.remove('volo'); }
  box.dataset.volo = '';
  box.innerHTML = sevFaceHtml() + '<div class="pf-opal" id="sevHeroStats"></div>';
  sevHeroStats();
}

/* ---------- the picture of why you started ----------

   A circle in the sky, the shape of the portrait in the profile. What goes in it is the
   user's business: the person they mean to become, someone they look up to, or simply the
   thing they are doing all this for. That is why the caption asks the question instead of
   naming an answer.

   The picture is resized to 320px and kept in localStorage on this phone. It is never sent
   anywhere: there is no account behind it and no reason for one. */
const SEV_FACE_KEY = 'fl_why_img';

function sevFaceGet(){
  try{ return localStorage.getItem(SEV_FACE_KEY) || ''; }catch(_){ return ''; }
}
function sevFaceHtml(){
  const src = sevFaceGet();
  return '<div class="sev-why">'
    + '<button type="button" class="sev-face' + (src ? ' has' : '') + '" onclick="if(typeof whyOpen===\'function\')whyOpen();else sevFacePick()"'
    +   (src ? ' style="background-image:url(\'' + src + '\')"' : '')
    +   ' aria-label="Cambia l\'immagine del tuo perché">'
    +   (src ? '' : '<span class="ic">✛</span>')
    + '</button>'
    + '<p class="sev-why-cap sev-rise" style="--d:.15s">Ricordati perché hai iniziato</p>'
    + ((typeof whyMantra === 'function' && whyMantra()) ? '<p class="sev-why-mantra sev-rise" style="--d:.32s">«' + esc(whyMantra()) + '»</p>' : '')
    + (src ? '' : '<p class="sev-why-hint sev-rise" style="--d:.45s">Tocca per mettere un\'immagine e il tuo mantra</p>')
    + '</div>';
}
/* ---------- picking and storing a picture (shared with the profile portrait) ----------

   The file input is created, clicked and thrown away. It has to be clicked from inside a real
   tap: a programmatic .click() with no user gesture behind it opens nothing, which is exactly
   how this looks broken when tested from a console instead of a finger. */
function flImgPick(key, after, quiet){
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    if (f) flImgStore(f, key, after, quiet);
    try{ inp.remove(); }catch(_){ }
  });
  document.body.appendChild(inp);
  inp.click();
}
/* Squared off and scaled down before it is stored: a phone photo is several megabytes and
   localStorage holds a few, so keeping the original would fill the quota with one picture. */
function flImgStore(file, key, after, quiet){
  const fr = new FileReader();
  fr.onload = function(){
    const img = new Image();
    img.onload = function(){
      try{
        const S = 320, cv = document.createElement('canvas');
        cv.width = S; cv.height = S;
        const ctx = cv.getContext('2d');
        const side = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
        let out = cv.toDataURL('image/jpeg', 0.82);
        if (out.length > 400000) out = cv.toDataURL('image/jpeg', 0.6);
        localStorage.setItem(key, out);
        if (typeof after === 'function') after(out);
        if (!quiet && typeof toast === 'function') toast('Immagine salvata su questo telefono');
      }catch(e){
        if (typeof toast === 'function') toast('Immagine troppo grande, provane un\'altra');
      }
    };
    img.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questa immagine'); };
    img.src = fr.result;
  };
  fr.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questo file'); };
  fr.readAsDataURL(file);
}
function flImgGet(key){
  try{ return localStorage.getItem(key) || ''; }catch(_){ return ''; }
}

/* Quando la scheda arriva davanti (o lo splash se ne va) con il testo ancora fermo, si
   ridipinge da zero: le righe rientrano nel DOM e la loro animazione riparte dall'inizio. */
let SEV_VOLO_OBS = null;
function sevVoloRiparti(){
  const box = document.getElementById('sevHeroBox');
  if (!box || box.dataset.volo !== '0') return;
  box.dataset.volo = '';
  sevHeroPaint(0);
}
function sevVoloAttendi(){
  if (SEV_VOLO_OBS) return;
  SEV_VOLO_OBS = new MutationObserver(function(){ setTimeout(sevVoloRiparti, 60); });
  const boot = document.getElementById('boot');
  if (boot) SEV_VOLO_OBS.observe(boot, { attributes: true });
  SEV_VOLO_OBS.observe(document.body, { childList: true });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(sevVoloRiparti, 120); });
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia') setTimeout(sevVoloRiparti, 80); });

function sevFacePick(){ flImgPick(SEV_FACE_KEY, function(){ sevHeroPaint(0); }); }
function sevFaceClear(){
  try{ localStorage.removeItem(SEV_FACE_KEY); }catch(_){ }
  sevHeroPaint(0);
}

/*
 * The streak panel, at the foot of the tab: the last thing read, after everything the strict
 * mode has to say. `n` comes from sevSyncTab for the same reason it always did - asking
 * sevStreakDays(false) here would erase a run of days.
 */
/**
 * Il bagliore sul bordo: fermo finche' la Modalita' severa e' accesa, e una pulsazione sola
 * la prima volta che il pannello si fa vedere dopo l'avvio.
 *
 * <p>La pulsazione si lega alla DATA DI INIZIO della serie, non a un orologio: cosi' una
 * serie nuova la fa una volta e poi mai piu', mentre un'animazione legata al tempo
 * ripartirebbe a ogni visita nei primi minuti e mancherebbe del tutto se il pannello lo si
 * apre mezz'ora dopo — cioe' quasi sempre.</p>
 */
function sevGlowClasse(n){
  if (!(n > 0)) return '';
  let start = '';
  try{ start = (JSON.parse(localStorage.getItem('fl_sev_streak') || 'null') || {}).start || ''; }catch(_){ }
  let visto = '';
  try{ visto = localStorage.getItem('fl_sev_glow') || ''; }catch(_){ }
  if (start && start !== visto){
    try{ localStorage.setItem('fl_sev_glow', start); }catch(_){ }
    return ' accesa nuova';
  }
  return ' accesa';
}

function sevStreakFoot(n){
  // Il posto è fisso nell'HTML, subito sotto al pannello della Modalità severa: spostarlo da
  // qui faceva a pugni con il pannello del futuro, che voleva lo stesso posto in fondo.
  const el = document.getElementById('sevStreakFoot');
  if (!el) return;
  const c = (n > 0 && typeof blkStreakCopy === 'function') ? blkStreakCopy(n) : null;
  /* i traguardi della serie portano il premio dell'Io Futuro (iofuturo.js) */
  try{ if (typeof ifSerieTraguardo === 'function') ifSerieTraguardo(n); }catch(_){ }
  /* La coda fissa «Il te del futuro ti sta gia' ringraziando» e' sparita: era la stessa riga
     sotto a ogni frase, e una frase nuova ogni giorno con la stessa coda tutti i giorni si
     legge come la coda, non come la frase. Adesso quella riga compare quando serve — il primo
     giorno — ed e' dentro al testo del giorno. */
  el.innerHTML = c
    ? '<div class="blk-streak' + sevGlowClasse(n) + ((typeof blkMedagliaClasse === 'function') ? blkMedagliaClasse(n, c) : '') + '"><div class="txt"><b>' + esc(c.t) + '</b><p>'
      + esc(c.p) + ((typeof blkForte === 'function') ? blkForte(c) : '') + '</p></div>'
      + '<div class="flame">🔥<span>' + n + '</span></div></div>'
    : '<div class="blk-streak"><div class="txt"><b>Il primo passo</b>'
      + '<p>La Modalità severa è spenta. Da quando la accendi, i giorni cominciano a contare '
      + 'e i blocchi smettono di essere negoziabili.</p></div>'
      + '<div class="flame">🔒</div></div>';
}

/* The two figures, the same ones the profile slideshow shows. */
async function sevHeroStats(){
  const el = document.getElementById('sevHeroStats');
  if (!el || typeof scReport !== 'function') return;
  if (typeof scMantraLoad === 'function') await scMantraLoad();
  if (typeof scMantraLoad === 'function') await scMantraLoad();
  if (typeof scHaGiornata === 'function' ? !scHaGiornata() : (!NATIVE || !NATIVE.getDayReport)){ el.innerHTML = ''; return; }
  const r = await scReport(0);
  if (!r || !r.granted){
    el.innerHTML = '<button class="bh-cta" onclick="openPerm(\'usage\')">Abilita i dati di utilizzo</button>';
    return;
  }
  const sc = scCompute(r), st = scStreak();
  // I record personali non sono più una riga nel cielo: stanno dentro ai due tooltip
  // (scFocusHtml), dove chi li vuole va a cercarli.
  el.innerHTML = scFocusHtml(sc, st) + sevCuriositaHtml();
  sevVistaProgressi();
}

/* LA RIGA CHE FA VENIRE VOGLIA DI TORNARE A GUARDARE: questa settimana contro la scorsa, nello
   stesso numero di giorni, e una domanda su dove arriverai. Niente voti: un confronto e basta. */
function sevCuriositaHtml(){
  try{
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    const ws = (typeof flWeekStart === 'function') ? flWeekStart() : 1;
    const inizio = oggi.getTime() - ((oggi.getDay() - ws + 7) % 7) * 86400000;
    const ora = Date.now(), prima = inizio - 7 * 86400000, primaFine = prima + (ora - inizio);
    const conta = function(a, b){ return h.filter(function(x){ return x && x.ok && x.at >= a && x.at < b; }).length; };
    const adesso = conta(inizio, ora), scorsa = conta(prima, primaFine);
    if (!adesso && !scorsa) return '';
    const diff = adesso - scorsa;
    const conf = diff > 0 ? ', ' + diff + ' in più della scorsa' : (diff < 0 ? ', ' + (-diff) + ' in meno della scorsa' : ', come la scorsa');
    return '<p class="sev-curioso">Questa settimana ' + adesso + (adesso === 1 ? ' sessione' : ' sessioni') + conf + '. Dove arrivi domenica?</p>';
  }catch(_){ return ''; }
}
/** I progressi guardati davvero: scheda davanti, prima diapositiva accesa, pagina visibile. */
function sevVistaProgressi(){
  try{
    const el = document.getElementById('sevHeroStats');
    const tab = document.getElementById('tab-severa');
    const slide = el && el.closest('.bh-slide');
    if (!el || !el.innerHTML || !tab || !tab.classList.contains('on') || !slide || !slide.classList.contains('on') || document.hidden) return;
    /* il bonus della riserva adesso lo da' il messaggio dell'Io Futuro (iofuturo.js): i due non si sommano */
  }catch(_){ }
}

/* The day's score used to be a section of its own at the top of Report. It now lives in the
   sky of the Profile, under the name, so insHeroEnsure() is gone with it. */

(function bhStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* full bleed: the tab pads by 18 and the screen by 22 */
    '.bh{position:relative;margin:0 calc(-1 * var(--bleed, 40px)) 14px;overflow:hidden;background:#020926}',
    '.bh-track{position:relative;height:var(--bh-h, 230px);transition:height .4s cubic-bezier(.2,.8,.2,1)}',
    /* senza rotazione le lineette non sono un timer: quella accesa e' piena e basta */
    '.bh--manual .bh-dot.on i{animation:none;transform:none}',
    '.bh-slide{position:absolute;inset:0;opacity:0;visibility:hidden;transition:opacity .45s ease}',
    '.bh-slide.on{opacity:1;visibility:visible}',
    /* a section with one slide grows with what is inside it */
    '.bh--tall .bh-track{height:auto}',
    /* Alto = prende l'altezza dal contenuto, quindi le diapositive stanno nel flusso e con
       due si accatastavano una sotto l'altra: quella spenta esce dal flusso. */
    '.bh--tall .bh-slide{position:relative;inset:auto}',
    '.bh--tall .bh-slide:not(.on){display:none}',
    '.bh--tall .bh-text{position:relative;inset:auto}',
    '.bh-img{position:absolute;inset:0;background-image:var(--bh-img, url("img/dream-night.jpg"));background-position:var(--bh-pos, center);background-size:cover;background-repeat:no-repeat;transform:scale(1.06)}',
    '.bh-slide.on .bh-img{animation:bhKen ' + (BH_CYCLE / 1000) + 's cubic-bezier(.22,.61,.36,1) both}',
    /* L'alba deve restare un'alba: il velo di serie (fatto per la notte) la spegneva. */
    '.sev-curioso{margin:10px auto 0;max-width:300px;text-align:center;font:600 13px/1.45 var(--font-body);color:rgba(255,255,255,.86)}',
    '.bh-slide.volo .bh-ov{background:linear-gradient(180deg,rgba(2,9,38,.08),rgba(2,9,38,.58))}',
    '.sev-volo-t{position:absolute;inset:0 0 58px 0;padding:18px 26px}',
    '.sev-volo-t .bh-title{font-size:30px}',
    '.sev-volo-t .bh-eyebrow{font-size:12px}',
    '.sev-volo-t.fermo .ln > i{animation:none}',
    '.sev-volo{position:absolute;inset:0 0 58px 0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 18px;color:#fff;animation:bhCtaIn .6s ease-out both}',
    '.sev-volo small{display:block;font:800 14px var(--font-display);font-style:italic;letter-spacing:.12em;text-transform:uppercase;color:#fff;text-shadow:0 2px 14px rgba(0,0,0,.5);margin-bottom:4px}',
    '@keyframes bhKen{from{transform:scale(1.06)}to{transform:scale(1)}}',
    /* SWEEP: la vecchia resta ferma sotto (assoluta, stessa altezza), la nuova entra sopra
       con il taglio che parte dal bordo. `translate` e non `transform`, per non litigare con
       lo zoom lento (bhKen) che la foto ha gia'. */
    '.bh--sweep .bh-slide.bh-out{position:absolute !important;top:0;left:0;right:0;z-index:1;opacity:1;visibility:visible;transition:none}',
    '.bh--sweep .bh-slide.bh-in{position:relative;z-index:2;opacity:1;visibility:visible;transition:none;will-change:clip-path}',
    '.bh--sweep:not(.bh--tall) .bh-slide.bh-in{position:absolute}',
    '.bh--sweep .bh-slide.bh-in.bh-sw-r{animation:bhSwR ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1) both}',
    '.bh--sweep .bh-slide.bh-in.bh-sw-l{animation:bhSwL ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1) both}',
    '.bh--sweep .bh-slide.bh-in.bh-sw-r .bh-img{translate:0 0;animation:bhKen ' + (BH_CYCLE / 1000) + 's cubic-bezier(.22,.61,.36,1) both,bhSwImgR ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1) both}',
    '.bh--sweep .bh-slide.bh-in.bh-sw-l .bh-img{translate:0 0;animation:bhKen ' + (BH_CYCLE / 1000) + 's cubic-bezier(.22,.61,.36,1) both,bhSwImgL ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1) both}',
    '.bh--sweep .bh-slide.bh-out.bh-sw-r .bh-img{translate:-4% 0;transition:translate ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1)}',
    '.bh--sweep .bh-slide.bh-out.bh-sw-l .bh-img{translate:4% 0;transition:translate ' + (BH_SWEEP_MS / 1000) + 's cubic-bezier(.22,.61,.36,1)}',
    '@keyframes bhSwR{from{clip-path:inset(0 0 0 100%)}to{clip-path:inset(0 0 0 0)}}',
    '@keyframes bhSwL{from{clip-path:inset(0 100% 0 0)}to{clip-path:inset(0 0 0 0)}}',
    '@keyframes bhSwImgR{from{translate:10% 0}to{translate:0 0}}',
    '@keyframes bhSwImgL{from{translate:-10% 0}to{translate:0 0}}',
    /* piu' leggero: le foto delle diapositive del Blocco erano quasi spente sotto al velo */
    '.bh-ov{position:absolute;inset:0;background:linear-gradient(180deg,rgba(2,9,38,.36),rgba(2,9,38,.63))}',
    '.bh-ov.dark{background:linear-gradient(180deg,rgba(2,9,38,.56),rgba(2,9,38,.75))}',
    '.bh-edit{position:absolute;top:14px;right:14px;z-index:4;cursor:pointer}',
    '.fb-s-sub{margin:8px 0 0;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.88)}.fb-s-sub b{color:#fff}',
    '.pg-off{display:none !important}.fl-sl-h{margin:16px 0 4px;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3;text-align:left}',
    '.fl-sl-sheet p{margin:0 0 10px;font:500 13px/1.5 var(--font-body);color:var(--muted)}.fl-sl-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 2px;border-bottom:1px solid var(--line);text-align:left}',
    '.fl-sl-row b{font:600 14px var(--font-body);color:var(--navy)}body.dark .fl-sl-row b{color:#fff}.fl-sl-row small{font:600 12px var(--font-body);color:var(--muted)}',
    /* The Focus Box photo has a bright sky: white type sat on it and disappeared. This veil is
       heavy where the words are and lets the product through in the middle. */
    '.bh-ov.veil{background:linear-gradient(180deg,rgba(2,9,38,.9) 0%,rgba(2,9,38,.78) 34%,rgba(2,9,38,.42) 58%,rgba(2,9,38,.72) 100%)}',
    /* the same veil for text in the middle of the slide: heavy where the words are */
    '.bh-ov.veil-mid{background:linear-gradient(180deg,rgba(2,9,38,.55) 0%,rgba(2,9,38,.82) 40%,rgba(2,9,38,.82) 62%,rgba(2,9,38,.5) 100%)}',
    '.bh-text{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:18px 26px 34px;color:#fff}',
    '.bh-text--top{justify-content:flex-start;padding-top:20px}',
    /* the phrase of the day, with the side margins of a meditation app's quote card */
    /* the bottom padding clears the progress bars: the pill was sitting on top of them */
    '.bh-quote{padding:18px 40px 100px}',
    /* Poppins in grassetto a 19.5px con interlinea 1.714: la frase del giorno della pagina
       Wishlist del sito, riga per riga. Il .long che la rimpiccioliva non c'e' piu'. */
    '.bh-q-text{margin:0;font:700 19.5px/1.714 var(--font-body);text-shadow:0 2px 14px rgba(0,0,0,.5)}',
    '.bh-q-more{border:0;background:none;padding:0;color:#03A9F4;font:700 16.5px var(--font-body);text-decoration:underline;text-underline-offset:2px;text-shadow:0 0 1.5px #fff;cursor:pointer}',
    '.bh-q-author{margin:12px 0 0;font:500 13px var(--font-body);font-style:italic;color:rgba(255,255,255,.85)}',
    '.bh-q-btn{margin-top:18px}',
    '.bh-q-btn[hidden]{display:none}',
    '.bh-eyebrow{font:700 10.5px var(--font-body);letter-spacing:.18em;text-transform:uppercase;opacity:.92;margin:0 0 10px}',
    /* Uppercase like every heading on the site (the theme sets text-transform on .dbr-mc__h).
       Capitals are wider, so the size comes down a notch to keep "FROM DREAM THIEVES" on one
       line at 375px, and the letter-spacing opens slightly the way the theme's headings do. */
    '.bh-title{font:800 22px/1.16 var(--font-display);font-style:italic;text-transform:uppercase;letter-spacing:.005em;margin:0;text-shadow:0 2px 14px rgba(0,0,0,.45)}',
    '.ln{display:block;overflow:hidden}',
    '.ln > i{display:block;font-style:inherit;transform:translateY(110%);opacity:0}',
    '.bh-slide.on .ln > i{animation:bhLine .85s cubic-bezier(.22,.61,.36,1) forwards;animation-delay:calc(' + (BH_TITLE_DELAY / 1000) + 's + var(--i) * ' + (BH_LINE_STEP / 1000) + 's)}',
    '@keyframes bhLine{from{transform:translateY(110%);opacity:0}to{transform:translateY(0);opacity:1}}',
    /* the button of the second slide, in the shape of the theme's pill buttons */
    '.bh-cta{margin-top:16px;border:0;border-radius:99px;background:#fff;color:#001E44;',
    '  font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;padding:12px 26px;cursor:pointer;',
    '  box-shadow:0 8px 22px rgba(0,0,0,.3)}',
    '.bh-cta:active{transform:translateY(1px)}',
    /* the white glow of the site's slideshow buttons (slideshow-custom.liquid, glow_pulse) */
    '.bh-cta--glow{animation:bhGlow 1.6s ease-in-out infinite}',
    '@keyframes bhGlow{0%,100%{box-shadow:0 0 .7rem rgba(255,255,255,.45),0 0 1.4rem rgba(255,255,255,.25)}50%{box-shadow:0 0 1.05rem rgba(255,255,255,.75),0 0 2.2rem rgba(255,255,255,.5)}}',
    /* the button arrives after the eyebrow and the title have finished their sweep */
    '.bh-cta--late{opacity:0}',
    '.bh-slide.on .bh-cta--late{animation:bhGlow 1.6s ease-in-out infinite,bhCtaIn .5s ease forwards;animation-delay:0s,calc(' + (BH_TITLE_DELAY / 1000) + 's + 2 * ' + (BH_LINE_STEP / 1000) + 's + .85s)}',
    '@keyframes bhCtaIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '.bh-dots{position:absolute;left:0;right:0;bottom:64px;display:flex;gap:6px;justify-content:center;z-index:3}',
    '.bh-dot{width:34px;height:3px;border:none;padding:0;border-radius:99px;background:rgba(255,255,255,.28);cursor:pointer;overflow:hidden}',
    /* 0.9.262: la barretta si riempie con transform (la muove la scheda grafica), non con la larghezza:
       la larghezza ricalcolava il layout e ridisegnava a ogni fotogramma (lo scroll scattava) */
    '.bh-dot i{display:block;height:100%;width:100%;background:#fff;border-radius:99px;transform:scaleX(0);transform-origin:left center}',
    '.bh-dot.on i{animation:bhBar ' + (BH_CYCLE / 1000) + 's linear forwards}',
    '@keyframes bhBar{from{transform:scaleX(0)}to{transform:scaleX(1)}}',
    '.bh .prof-clouds{position:absolute;left:0;right:0;bottom:-1px;z-index:2;line-height:0;color:var(--bg);pointer-events:none}',
    '.bh .prof-clouds svg{display:block;width:100%;height:56px}',
    /* Modalità severa: the panels stacked over the sky */
    '.bh-stack{position:relative;z-index:1;padding:22px 18px 84px}',
    /* Air between the picture and the two figures: they are the point of the page, and a
       counter pressed against the thing above it reads as its label instead of as a result. */
    '.bh-stack .pf-opal{display:flex;justify-content:space-around;align-items:flex-start;padding-top:54px}',
    '.bh-stack .bh-cta{display:block;margin:22px auto 0}',
    /* the picture of why you started: the portrait of the profile, in the sky */
    '.sev-why{position:relative;text-align:center}',
    '.sev-face{width:92px;height:92px;border-radius:50%;border:0;padding:0;cursor:pointer;',
    '  background:var(--blue) center/cover no-repeat;color:#fff;display:inline-flex;align-items:center;justify-content:center;',
    '  box-shadow:0 0 0 4px rgba(255,255,255,.16),0 12px 30px rgba(0,0,0,.45)}',
    '.sev-face .ic{font:300 34px/1 var(--font-body);opacity:.92}',
    '.sev-face.has{background-color:#0A1A2F}',
    '.sev-face-x{position:absolute;top:-2px;left:50%;margin-left:30px;width:26px;height:26px;border-radius:50%;border:0;cursor:pointer;',
    '  background:rgba(2,9,38,.78);color:#fff;font:700 16px/1 var(--font-body);backdrop-filter:blur(4px)}',
    '.sev-why-cap{margin:12px 0 0;font:700 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.9)}',
    '.sev-why-hint{margin:5px 0 0;font:500 11.5px var(--font-body);color:rgba(255,255,255,.6)}',
    '.sev-why-mantra{margin:8px 24px 0;font:600 14px/1.45 var(--font-body);font-style:italic;color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.4)}',
    /* the entrance of the wishlist page's cards (wishlist.css, sortFadeIn): up from ten pixels below */
    '.sev-rise{animation:sevRise .6s ease-out both;animation-delay:var(--d,0s)}',
    '@keyframes sevRise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}',
    '.bh-stack .pf-opal{flex-wrap:wrap}',
    '#sevStreakFoot{margin:44px 0 40px}',
    /* Il lucchetto e il titolo della Modalità severa, con aria sopra: sotto c'è il pannello
       del futuro, e due sezioni attaccate si leggono come una sola. */
    '.sev-intro{text-align:center;padding:52px 0 6px}',
    '.sev-intro-ic{font-size:64px;line-height:1.15;margin-bottom:14px}',
    '.sev-intro h2{font:800 22px var(--font-display);font-style:italic;color:var(--navy);margin-top:0}',
    '.sev-intro p{font:500 13px/1.6 var(--font-body);color:var(--muted);margin:12px 18px 0}',
    'body.dark .sev-intro h2{color:#fff}',
    /* the score, laid out the way a score board is: the total above, the three under it */
    '.bh-scorebox{padding-bottom:70px}',
    '.bh-sc-total{cursor:pointer}',
    '.bh-sc-total small{display:block;font:600 11px var(--font-body);letter-spacing:.06em;color:rgba(255,255,255,.75)}',
    '.bh-sc-total b{display:block;font:800 40px/1 var(--font-display);color:#8CF0C8}',
    '.bh-sc-total .caret{font-size:14px;color:#8CF0C8;margin-left:4px;vertical-align:middle}',
    '.bh-bracket{position:relative;height:14px;width:74%;margin:6px auto 2px}',
    '.bh-bracket::before{content:"";position:absolute;left:12%;right:12%;top:7px;border-top:1px solid rgba(255,255,255,.3)}',
    '.bh-bracket::after{content:"";position:absolute;left:50%;top:0;height:7px;border-left:1px solid rgba(255,255,255,.3)}',
    '.bh-bracket i{position:absolute;top:7px;height:7px;border-left:1px solid rgba(255,255,255,.3)}',
    '.bh-bracket i:nth-child(1){left:12%}.bh-bracket i:nth-child(2){left:50%}.bh-bracket i:nth-child(3){right:12%}',
    '.bh-row{display:flex;gap:10px;justify-content:center;width:100%;margin-top:6px}',
    '.bs-pill{flex:1;max-width:108px;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer}',
    '.bs-pill .cap{position:relative;display:flex;align-items:center;justify-content:center;gap:6px;width:100%;height:42px;border-radius:21px;',
    '  background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);font:800 17px var(--font-display);color:#fff}',
    '.bs-pill .cap .ic{font-size:14px}',
    '.bs-pill .arc{position:absolute;left:0;top:0;width:100%;height:100%;overflow:visible;pointer-events:none}',
    '.bs-pill .arc path{fill:none;stroke:#8CF0C8;stroke-width:2.5;stroke-linecap:round}',
    '.bs-pill small{font:600 11px var(--font-body);color:rgba(255,255,255,.78)}'
  ].join('\n');
  document.head.appendChild(st);
})();
