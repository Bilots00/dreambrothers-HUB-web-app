/* ===========================================================================================
   L'ARBITRO ESTERNO — il punto che arriva dal computer

   Chi lavora tutto il giorno con un assistente al computer aggiunge cose senza accorgersene:
   una sezione, una pagina, «e se mettessimo anche…». Ogni aggiunta fuori rotta e' un passo
   di lato, e un passo di lato non si vede finche' il tabellone non si muove. Qui il tabellone
   si muove: un agente sul computer riconosce la richiesta fuori rotta e deposita un punto in
   una riga dell'account (`fl:arbitro`). L'app la legge e segna il punto al vecchio te, con il
   motivo, una volta sola per evento.

   Non decide niente da sola: applica un registro. Chi ha segnato, e perche', e' scritto
   nell'evento e finisce nel registro della partita come tutti gli altri punti.
   =========================================================================================== */

const AC_SLOT = 'fl:arbitro';
const AC_KEY = 'fl_arbitro_visti';       // gli id gia' applicati
const AC_OGNI_MS = 5 * 60000;
let AC_T = 0, AC_ULTIMO = 0;

function acPuo(){ try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; } }
function acVisti(){ try{ return JSON.parse(localStorage.getItem(AC_KEY) || '[]') || []; }catch(_){ return []; } }
const AC_APPLICATI = 'fl_arbitro_applicati';    // gli id che QUESTO dispositivo ha segnato davvero
function acApplicati(){ try{ return JSON.parse(localStorage.getItem(AC_APPLICATI) || '[]') || []; }catch(_){ return []; } }
function acIoApplico(){
  try{
    if (typeof pcQui === 'function' && pcQui() === 'desktop') return true;
    const dev = (typeof LS_DOC !== 'undefined' && LS_DOC && LS_DOC.devices) || {};
    for (const k in dev){
      if (!Object.prototype.hasOwnProperty.call(dev, k)) continue;
      if (dev[k] && dev[k].name === 'Computer' && Date.now() - (+dev[k].at || 0) < 12 * 3600000) return false;
    }
  }catch(_){ }
  return true;
}
function acSalva(v){ try{ localStorage.setItem(AC_KEY, JSON.stringify(v.slice(-200))); }catch(_){ } }

/* IL REGISTRO DELLE DEVIAZIONI (fl_deviazioni): ogni punto fuori rotta, con i minuti che l'hook
   di Claude ha misurato fra il messaggio e la fine della risposta. Lo legge la prima slide della
   Roadmap (rotta-oggi.js). Una durata appartiene a un evento della stessa sessione, iniziata
   al massimo cinque minuti prima che l'evento arrivasse (il giudizio sul VPS impiega un minuto). */
function acDeviazioni(eventi, durate){
  let reg = [];
  try{ reg = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || []; }catch(_){ }
  let cambiato = false;
  eventi.forEach(function(e){
    if (!e || !e.id) return;
    let x = reg.filter(function(r){ return r.id === e.id; })[0];
    if (!x){ x = { id: e.id, at: e.at, motivo: String(e.motivo || ''), sessione: e.sessione || '', minuti: 0 }; reg.push(x); cambiato = true; }
    if (!x.minuti && x.sessione){
      const d = durate.filter(function(q){ return q && q.sessione === x.sessione && q.inizio <= x.at && x.at - q.inizio <= 5 * 60000; })
        .sort(function(a, b){ return b.inizio - a.inizio; })[0];
      if (d && d.minuti > 0){ x.minuti = Math.round(d.minuti); cambiato = true; }
    }
  });
  if (cambiato){
    try{ localStorage.setItem('fl_deviazioni', JSON.stringify(reg.slice(-500))); }catch(_){ }
    try{ document.dispatchEvent(new CustomEvent('fl:deviazione')); }catch(_){ }
  }
}

/* I PUNTI ANNULLATI: un punto finito sulla riga per sbaglio (un falso allarme dell'arbitro, una
   prova) viene tolto dal server e messo in `annullati`. Se questo dispositivo l'aveva gia'
   applicato, il punto al vecchio te si storna qui, una volta sola, con il motivo nel registro. */
function acAnnulla(ids, eventi, annullatiInfo){
  if (!ids.length) return;
  /* il motivo di ogni punto annullato: dalla riga del server (gli annullati tengono una copia) */
  const mappa = {};
  (eventi || []).concat(annullatiInfo || []).forEach(function(e){ if (e && e.id) mappa[e.id] = e; });
  let fatti = [];
  try{ fatti = JSON.parse(localStorage.getItem('fl_arbitro_annullati') || '[]') || []; }catch(_){ }
  const visti = acVisti();
  let cambiato = false;
  ids.forEach(function(id){
    if (fatti.indexOf(id) >= 0) return;
    fatti.push(id); cambiato = true;
    try{
      const reg = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || [];
      localStorage.setItem('fl_deviazioni', JSON.stringify(reg.filter(function(x){ return x.id !== id; })));
    }catch(_){ }
    if (visti.indexOf(id) < 0) visti.push(id);
    const app = acApplicati();
    /* i punti segnati prima del registro `applicati` si riconoscono dal registro della partita:
       una riga NATA QUI (non importata) con lo stesso motivo */
    const motivo = 'fuori rotta: ' + String((mappa[id] && mappa[id].motivo) || '');
    const nelRegistro = !!(mappa[id] && (typeof mgHist === 'function' ? mgHist() : []).some(function(g){
      return (g.eventi || []).some(function(e){ return e && e.chi === 'old' && !e.da && !e.stornato && e.motivo === motivo; });
    }));
    if (app.indexOf(id) < 0 && !nelRegistro) return;           // mai segnato qui: niente da stornare
    try{ localStorage.setItem(AC_APPLICATI, JSON.stringify(app.filter(function(x){ return x !== id; }))); }catch(_){ }
    try{
      const s = mtRoll();
      s.old = Math.max(0, (s.old || 0) - 1);
      mtWrite(MT_KEY, s);
      if (typeof mgLog === 'function') mgLog('annullo', 'Punto fuori rotta annullato al VAR: ' + String((mappa[id] && (mappa[id].var || mappa[id].motivo)) || 'era in rotta'));
      if (typeof lsMine === 'function' && typeof lsWrite === 'function'){
        const m = lsMine();
        m.old = Math.max(0, (m.old || 0) - 1);
        if (m.seen) m.seen.old = Math.max(0, (m.seen.old || 0) - 1);
        lsWrite(m);
        if (typeof lsPushSoon === 'function') lsPushSoon();
      }
      if (typeof mtPaint === 'function') mtPaint();
    }catch(_){ }
  });
  acSalva(visti);
  if (cambiato){
    try{ localStorage.setItem('fl_arbitro_annullati', JSON.stringify(fatti.slice(-100))); }catch(_){ }
    try{ document.dispatchEvent(new CustomEvent('fl:deviazione')); }catch(_){ }
  }
}

async function acLeggi(forza){
  if (!acPuo()) return;
  if (!forza && Date.now() - AC_ULTIMO < AC_OGNI_MS) return;
  AC_ULTIMO = Date.now();
  let eventi = [];
  try{
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === AC_SLOT; })[0];
    if (!riga) return;
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const v = (pieno && pieno.payload) || null;
    if (!v || v.kind !== 'focuslock-arbitro' || !Array.isArray(v.eventi)) return;
    eventi = v.eventi;
    acDeviazioni(v.eventi, v.durate || []);
    /* gli annullamenti del VAR stanno SOLO in annullatiInfo: le versioni precedenti leggono
       `annullati` con la regola vecchia (stornavano anche i punti mai segnati qui) */
    const info = v.annullatiInfo || [];
    acAnnulla((v.annullati || []).concat(info.map(function(x){ return x && x.id; }).filter(Boolean)), v.eventi, info);
  }catch(_){ return; }
  /* UN PUNTO, UN DISPOSITIVO. Lo leggevano telefono e computer, e ognuno lo segnava nella sua
     parte del tabellone: sulla partita condivisa ogni «fuori rotta» valeva DUE. Adesso lo
     applica il computer (e' acceso mentre si lavora, ed e' li' che nascono le richieste); il
     telefono lo applica solo se il computer non si fa vivo da dodici ore. */
  if (!acIoApplico()) return;
  const visti = acVisti();
  const applicati = acApplicati();
  /* GIA' APPLICATI ALTROVE (0.9.207): ogni dispositivo scrive nel tabellone condiviso gli id che
     ha segnato; chi legge dopo li salta. Prima bastava che il computer fosse spento da 12 ore
     perche' il telefono segnasse, e al ritorno il computer segnava di nuovo. */
  /* 0.9.286, Andrea: "Fuori rotta: Richiede di replicare Focusmate" alle 8:00 e lo stesso punto alle 11:15 "(dal
     computer)", il tabellone da 4 a 5 e poi a 6. Il telefono l'aveva segnato alle 8 (il computer era spento) e
     l'aveva scritto nel tabellone condiviso; il computer, riacceso, leggeva i punti con il tabellone che aveva in
     memoria da prima, senza la riga del telefono, e lo segnava di nuovo. Adesso il tabellone si rilegge dal
     server PRIMA di segnare: se non si riesce a leggerlo, il punto aspetta il giro dopo (meglio in ritardo che due). */
  const fresco = await acAltroveFresco();
  if (!fresco.ok) return;
  const altrove = fresco.ids.concat(acApplicatiAltrove());
  let nuovi = 0;
  eventi.forEach(function(e){
    if (!e || !e.id || visti.indexOf(e.id) >= 0) return;
    visti.push(e.id);
    if (altrove.indexOf(e.id) >= 0) return;
    /* solo gli eventi di oggi: un punto di tre giorni fa applicato adesso sarebbe un punto
       di oggi con la data sbagliata */
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    if (!(e.at >= oggi.getTime())) return;
    try{ if (typeof mgOldPoint === 'function') mgOldPoint('fuori rotta: ' + String(e.motivo || 'aggiunta non prevista')); }catch(_){ }
    applicati.push(e.id);
    nuovi++;
  });
  acSalva(visti);
  try{ localStorage.setItem(AC_APPLICATI, JSON.stringify(applicati.slice(-200))); }catch(_){ }
  if (nuovi && typeof toast === 'function') toast(nuovi === 1 ? 'Punto al vecchio te: richiesta fuori rotta' : nuovi + ' punti al vecchio te: richieste fuori rotta');
  if (nuovi){ try{ if (typeof lsPushSoon === 'function') lsPushSoon(); }catch(_){ } }
}
/** Gli id che gli ALTRI dispositivi hanno gia' segnato, letti adesso dal tabellone sul server. */
async function acAltroveFresco(){
  try{
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === 'match-score'; })[0];
    if (!riga) return { ok: true, ids: [] };
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const doc = (pieno && pieno.payload) || null;
    if (!doc || typeof doc !== 'object') return { ok: false, ids: [] };
    const me = (typeof lsDevId === 'function') ? lsDevId() : '';
    const dev = doc.devices || {}, ids = [];
    for (const k in dev){
      if (!Object.prototype.hasOwnProperty.call(dev, k) || k === me) continue;
      ((dev[k] && dev[k].arb) || []).forEach(function(id){ if (ids.indexOf(id) < 0) ids.push(id); });
    }
    return { ok: true, ids: ids };
  }catch(_){ return { ok: false, ids: [] }; }
}
function acApplicatiAltrove(){
  const out = [];
  try{ const dev = (typeof LS_DOC !== 'undefined' && LS_DOC && LS_DOC.devices) || {}; const me = (typeof lsDevId === 'function') ? lsDevId() : ''; for (const k in dev){ if (!Object.prototype.hasOwnProperty.call(dev, k) || k === me) continue; (dev[k] && dev[k].arb || []).forEach(function(id){ if (out.indexOf(id) < 0) out.push(id); }); } }catch(_){ }
  return out;
}

/* I DOPPIONI GIA' CONTATI. Prima di questa regola telefono e computer segnavano lo stesso punto:
   una volta sola, il telefono toglie i suoi «fuori rotta» degli ultimi sette giorni che il
   computer ha segnato anche lui (il registro del computer arriva col tabellone condiviso). */
function acTogliDoppioni(){
  try{
    if (typeof pcQui === 'function' && pcQui() === 'desktop') return;
    const dev = (typeof LS_DOC !== 'undefined' && LS_DOC && LS_DOC.devices) || null;
    if (!dev) return;                                          // il tabellone non e' ancora arrivato
    const suoi = [], arbPc = [];
    for (const k in dev){
      if (!Object.prototype.hasOwnProperty.call(dev, k) || !dev[k] || dev[k].name !== 'Computer') continue;
      (dev[k].log || []).forEach(function(e){ if (e && e.chi === 'old' && /^fuori rotta:/.test(String(e.motivo || ''))) suoi.push({ m: String(e.motivo), at: +e.at || 0 }); });
      (dev[k].arb || []).forEach(function(id){ if (arbPc.indexOf(id) < 0) arbPc.push(id); });
    }
    const da = Date.now() - 7 * 86400000;
    let tolti = 0;
    const storia = (typeof mgHist === 'function' ? mgHist() : []);
    const giorno = function(t){ const d = new Date(t); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); };
    /* 0.9.286: il confronto si fa sui primi 150 caratteri. Il tabellone taglia il motivo a 160 (lsMerge), qui il
       motivo era intero: per un motivo lungo ("Richiede di replicare Focusmate, feature estranea...") i due testi
       non erano mai uguali e il doppione restava. */
    const uguale = function(a, b){ return String(a).slice(0, 150) === String(b).slice(0, 150); };
    const storna = function(pred){
      let fatto = false;
      storia.forEach(function(g){
        (g.eventi || []).forEach(function(e){
          if (fatto || !e || e.chi !== 'old' || e.da || e.stornato || !(e.at >= da)) return;
          const m = String(e.motivo || '');
          if (!/^fuori rotta:/.test(m) || /\(dal /.test(m) || !pred(m, e)) return;
          e.stornato = true; fatto = true; tolti++;
        });
      });
      return fatto;
    };
    /* PRIMA PER ID: lo stesso evento dell'arbitro segnato qui e sul computer. Il motivo dell'evento sta nel registro
       delle deviazioni (fl_deviazioni), che ha id e motivo. */
    let reg = []; try{ reg = JSON.parse(localStorage.getItem('fl_deviazioni') || '[]') || []; }catch(_){ }
    let mie = acApplicati(); const tolteId = [];
    mie.filter(function(id){ return arbPc.indexOf(id) >= 0; }).forEach(function(id){
      const r = reg.filter(function(x){ return x && x.id === id; })[0];
      const mot = r ? 'fuori rotta: ' + String(r.motivo || '') : '';
      if (!mot) return;
      if (storna(function(m){ return uguale(m, mot); })){
        tolteId.push(id);
        const i = suoi.findIndex(function(x){ return uguale(x.m, mot); }); if (i >= 0) suoi.splice(i, 1);
      }
    });
    if (tolteId.length){ mie = mie.filter(function(id){ return tolteId.indexOf(id) < 0; }); try{ localStorage.setItem(AC_APPLICATI, JSON.stringify(mie)); }catch(_){ } }
    /* POI PER MOTIVO, per i punti segnati prima che ogni dispositivo scrivesse i suoi id: stesso motivo, stesso giorno */
    suoi.forEach(function(x){ storna(function(m, e){ return uguale(m, x.m) && (!x.at || giorno(x.at) === giorno(e.at)); }); });
    if (tolti){ try{ localStorage.setItem('fl_match_hist', JSON.stringify(storia)); }catch(_){ } }
    for (let i = 0; i < tolti; i++){
      const s = mtRoll(); s.old = Math.max(0, (s.old || 0) - 1); mtWrite(MT_KEY, s);
      if (typeof mgLog === 'function') mgLog('annullo', 'Punto fuori rotta contato due volte (telefono e computer): tolto il doppione');
      if (typeof lsMine === 'function' && typeof lsWrite === 'function'){
        const mm = lsMine(); mm.old = Math.max(0, (mm.old || 0) - 1); if (mm.seen) mm.seen.old = Math.max(0, (mm.seen.old || 0) - 1); lsWrite(mm);
      }
    }
    if (tolti){ if (typeof lsPushSoon === 'function') lsPushSoon(); if (typeof mtPaint === 'function') mtPaint(); if (typeof toast === 'function') toast(tolti === 1 ? 'Tolto un punto contato due volte' : 'Tolti ' + tolti + ' punti contati due volte'); }
  }catch(_){ }
}
setTimeout(acTogliDoppioni, 30000);
setTimeout(acTogliDoppioni, 90000);
setInterval(acTogliDoppioni, 5 * 60000);

document.addEventListener('fl:tab', function(){ acLeggi(false); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) acLeggi(false); });
setTimeout(function(){ acLeggi(true); }, 12000);
setInterval(function(){ if (!document.hidden) acLeggi(false); }, AC_OGNI_MS);
