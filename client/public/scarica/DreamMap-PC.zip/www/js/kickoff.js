/* ===========================================================================================
   LA PARTITA A TEMPO — fischio d'inizio, minuto, fischio finale

   Campionato e «ogni giorno» hanno un difetto in comune: non finiscono mai davvero. Il
   campionato non finisce per definizione; la partita del giorno finisce a mezzanotte, quando
   dormi, e nessuno la guarda finire. Una partita vera invece ha un inizio che decidi tu, un
   orologio che corre mentre giochi e un fischio finale che arriva mentre sei ancora sveglio a
   vedere com'è andata.

   DUE MODI DI COMINCIARE, e sono due persone diverse:

     · A MANO — apri START e dai il calcio d'inizio quando sei pronto. Novanta minuti (o
       quanti ne vuoi) in cui quello che fai conta doppio, perché stai guardando il tabellone.
     · DA SOLA — le fasce orarie che scrivi qui: «tutti i giorni 9:00, 90 minuti». Alle nove
       l'arbitro fischia da solo, e alle 10:30 sai com'è finita senza aver deciso niente.

   COSA SUCCEDE AL FISCHIO FINALE: il risultato va nel referto, il tabellone riparte da 0-0 e
   il minuto sparisce dalla bolla. I punti segnati restano nella storia: una partita finita non
   si cancella, si archivia.

   PERCHÉ IL MINUTO CONTA. Un punteggio senza tempo non dice se stai vincendo: dice solo dove
   sei. «2-0 al 12°» e «2-0 all'88°» sono due partite completamente diverse, e la seconda ti
   fa alzare dalla sedia. È la stessa ragione per cui un tabellone allo stadio ha l'orologio
   grande quanto i numeri.
   =========================================================================================== */

const KO_KEY = 'fl_match_kick';     // la partita in corso: { at, min }
const KO_PLAN = 'fl_match_plan';    // le fasce orarie: [{ id, h, m, min, days[7], on }]

/* ---------------------------------------------------------------------------------------
   La partita in corso
   --------------------------------------------------------------------------------------- */

function koLive(){
  try{
    const v = JSON.parse(localStorage.getItem(KO_KEY) || 'null');
    if (!v || !v.at || !v.min) return null;
    return v;
  }catch(_){ return null; }
}

function koWrite(v){
  try{
    if (v) localStorage.setItem(KO_KEY, JSON.stringify(v));
    else localStorage.removeItem(KO_KEY);
  }catch(_){ }
}

/** Minuti giocati, da 1 in su — come su un tabellone: al primo minuto si legge 1', non 0'. */
function koMinute(){
  const k = koLive();
  if (!k) return 0;
  return Math.min(k.min, Math.floor((Date.now() - k.at) / 60000) + 1);
}

/** Quello che va scritto nella bolla e nel tabellone: «45'» oppure vuoto. */
function koLabel(){
  const k = koLive();
  if (!k) return '';
  return koMinute() + "'";
}

function koRunning(){ return !!koLive(); }

/** Quanto manca, in minuti. */
function koLeft(){
  const k = koLive();
  if (!k) return 0;
  return Math.max(0, k.min - Math.floor((Date.now() - k.at) / 60000));
}

/* ---------------------------------------------------------------------------------------
   Fischio d'inizio e fischio finale
   --------------------------------------------------------------------------------------- */

function koStart(minuti, zitto){
  const m = Math.max(1, Math.round(+minuti || koDurata()));
  koWrite({ at: Date.now(), min: m });
  /* Una partita comincia da 0-0: altrimenti non e' una partita, e' la continuazione di
     quella di prima con un orologio sopra. */
  if (typeof mtState === 'function' && typeof mtWrite === 'function'){
    const s = mtState();
    s.old = 0; s.neo = 0;
    mtWrite(MT_KEY, s);
    /* La partita nuova e' un'epoca nuova anche per la sincronizzazione: senza, il giro dopo
       il cloud rimetterebbe dentro il punteggio della partita precedente. */
    try{ if (typeof lsResetEpoch === 'function') lsResetEpoch(); else if (typeof lsSeen === 'function') lsSeen(s); }catch(_){ }
  }
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  if (!zitto && typeof toast === 'function') toast('Si comincia: ' + m + ' minuti');
  koTick();
}

/** Il fischio finale: il risultato va in archivio e il tabellone riparte pulito. */
function koEnd(zitto){
  const k = koLive();
  if (!k) return;
  const s = (typeof mtState === 'function') ? mtState() : { old: 0, neo: 0 };
  koWrite(null);

  /* Il referto: la stessa forma delle partite del giorno, cosi' compaiono nello stesso
     elenco «Ultimi risultati» senza inventare una seconda storia. */
  try{
    if (typeof mgHist === 'function' && typeof MG_HIST !== 'undefined'){
      const h = mgHist();
      h.push({ day: (typeof mgDayKey === 'function' ? mgDayKey() : ''), old: s.old, neo: s.neo,
               min: k.min, eventi: [] });
      localStorage.setItem(MG_HIST, JSON.stringify(h.slice(-120)));
    }
  }catch(_){ }

  if (typeof mtWrite === 'function'){
    s.old = 0; s.neo = 0;
    mtWrite(MT_KEY, s);
    try{ if (typeof lsResetEpoch === 'function') lsResetEpoch(); else if (typeof lsSeen === 'function') lsSeen(s); }catch(_){ }
  }
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  if (!zitto && typeof toast === 'function') toast('Fine partita: ' + s.old + ' – ' + s.neo);
}

function koDurata(){
  const c = (typeof mgCfg === 'function') ? mgCfg() : {};
  return Math.max(1, +c.matchMin || 90);
}

/* ---------------------------------------------------------------------------------------
   Le fasce orarie che fanno partire una partita da sole
   --------------------------------------------------------------------------------------- */

function koPlan(){
  try{ return JSON.parse(localStorage.getItem(KO_PLAN) || '[]') || []; }catch(_){ return []; }
}

function koPlanWrite(v){
  try{ localStorage.setItem(KO_PLAN, JSON.stringify(v || [])); }catch(_){ }
}

function koPlanAdd(h, m, min){
  const p = koPlan();
  p.push({ id: 'k' + Date.now().toString(36), h: h, m: m, min: min || koDurata(),
           days: [true, true, true, true, true, true, true], on: true });
  koPlanWrite(p);
  return p;
}

function koPlanDel(id){
  koPlanWrite(koPlan().filter(function(x){ return x.id !== id; }));
}

function koPlanToggle(id){
  const p = koPlan();
  p.forEach(function(x){ if (x.id === id) x.on = x.on === false; });
  koPlanWrite(p);
}

/* Il controllo: ogni minuto guarda se una fascia deve far partire la partita adesso.

   Una fascia scatta una volta sola per giorno: il segno di «gia' fatta» e' la data, cosi'
   riaprire l'app dieci volte nella stessa ora non fa ricominciare dieci partite. */
function koCheckPlan(){
  if (koRunning()) return;
  const now = new Date();
  const oggi = (typeof mgDayKey === 'function') ? mgDayKey() : String(now.toDateString());
  const giorno = (now.getDay() + 6) % 7;          // 0 = lunedi', come nei programmi
  const p = koPlan();
  let cambiato = false;

  p.forEach(function(f){
    if (f.on === false) return;
    if (Array.isArray(f.days) && f.days.length === 7 && !f.days[giorno]) return;
    if (f.last === oggi) return;
    /* La finestra e' di due minuti: se il telefono era spento all'ora esatta, la partita
       parte appena si riaccende — ma non si recupera una fascia di tre ore fa. */
    const scatto = f.h * 60 + f.m;
    const adesso = now.getHours() * 60 + now.getMinutes();
    if (adesso < scatto || adesso > scatto + 2) return;
    f.last = oggi;
    cambiato = true;
    koStart(f.min, true);
    if (typeof toast === 'function') toast('Calcio d\'inizio: ' + f.min + ' minuti');
  });

  if (cambiato) koPlanWrite(p);
}

/* ---------------------------------------------------------------------------------------
   L'orologio

   Gira una volta al minuto: e' la risoluzione di un tabellone, e piu' spesso vorrebbe dire
   svegliare la pagina per riscrivere lo stesso numero.
   --------------------------------------------------------------------------------------- */

function koTick(){
  try{
    const c = (typeof mgCfg === 'function') ? mgCfg() : {};
    if (c.season === 'tempo') koCheckPlan();

    if (koRunning() && koLeft() <= 0){ koEnd(); return; }

    /* Il minuto viaggia con il punteggio: la bolla sopra le altre app e la pillola sul
       computer lo mostrano accanto ai numeri, come il punteggio in diretta di una partita. */
    if (typeof mtRoll === 'function' && typeof mtBroadcast === 'function'){
      MT_SENT = null;                       // il minuto e' cambiato: il prossimo invio parte
      mtBroadcast(mtRoll());
    }
    if (typeof mtPaint === 'function' && document.getElementById('stMatchBox')) mtPaint();
  }catch(_){ }
}

setInterval(koTick, 60000);
setTimeout(koTick, 2500);
