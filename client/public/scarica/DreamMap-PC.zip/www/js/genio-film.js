/* =========================================================================================
   PARLARE DI UN FILM CON IL GENIO, E I GIOCHI CHE SERVONO A QUALCOSA (0.9.317)

   Andrea: "la prova non puo' essere una domanda in un box con 24 ore per rispondere: e' un'interrogazione, fa schifo. Voglio
   una conversazione col Genio o con il tuo agente, che tiri fuori curiosita' interessanti sul film e che servano a
   ispirarsi davvero. E i giochi del Genio escono dalla slide di Dream e vanno nella pagina della storia, dopo aver visto un episodio:
   cosi' il Genio impara i gusti e propone film sempre piu' in linea. Se l'utente spunta la casella, le sue partite
   addestrano il Genio di tutti".

   La scena e' quella unica del Genio (s-genio), una domanda alla volta, sempre con "Lo scrivo io". Le risposte finiscono in fl_genio_gusti:
   le legge epiIspOpera (episodi.js) per scegliere la prossima sorpresa, e il brief dell'Io Futuro (iofuturo-chiamata.js) per
   parlare con le parole di chi lo ascolta. Il backup della vecchia slide e' sul branch backup/sfida-genio-slide-0.9.316.
   ========================================================================================= */
const GF = { s: 0, op: null, cfg: null, risp: [], i: 0, scrivi: false };
const GF_GUSTI = 'fl_genio_gusti';
const GF_CONSENSO = 'fl_genio_insegna';
function gfEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
async function gfCarica(){
  if (GF.cfg) return GF.cfg;
  try{ GF.cfg = await (await fetch('content/film-genio.json')).json(); }catch(_){ GF.cfg = { temi: {}, opere: {} }; }
  return GF.cfg;
}
function gfGusti(){ let g = null; try{ g = JSON.parse(localStorage.getItem(GF_GUSTI) || 'null'); }catch(_){ } return (g && typeof g === 'object') ? Object.assign({ temi: {}, opere: [] }, g) : { temi: {}, opere: [] }; }
function gfGustiSalva(g){ try{ localStorage.setItem(GF_GUSTI, JSON.stringify(g)); }catch(_){ } }
function gfConsenso(){ try{ return localStorage.getItem(GF_CONSENSO) === '1'; }catch(_){ return false; } }
function gfConsensoCambia(on){ try{ localStorage.setItem(GF_CONSENSO, on ? '1' : '0'); }catch(_){ } try{ if (on && typeof akSvuotaCoda === 'function') akSvuotaCoda(); }catch(_){ } }

/* la scelta della prossima sorpresa: fra le opere del sogno e quelle di tutti, prima quelle dei temi che gli sono piaciuti */
function gfPreferita(lista){
  const g = gfGusti(), cfg = GF.cfg;
  if (!cfg || !Object.keys(g.temi).length || !Array.isArray(lista) || !lista.length) return null;
  const visti = g.opere.map(function(x){ return x.t; });
  let meglio = null, punti = -1;
  lista.forEach(function(op){
    if (visti.indexOf(op.t) >= 0) return;
    const info = cfg.opere[op.t] || op.info; const p = info ? (g.temi[info.tema] || 0) : 0;
    if (p > punti){ punti = p; meglio = op; }
  });
  return punti > 0 ? meglio : null;
}
gfCarica();

/* la conversazione: tre domande e la curiosita', mai un voto */
function gfApri(s){
  const st = (typeof epiIspStato === 'function') ? epiIspStato()[s] : null;
  if (!st || !st.opera || typeof GN === 'undefined') return;
  GF.s = s; GF.op = st.opera; GF.i = 0; GF.risp = []; GF.scrivi = false;
  gfCarica().then(function(){
    GN.on = true; GN.modo = 'ak';
    goId('s-genio');
    try{ akBarra(false); }catch(_){ }
    gnVai('gfParla');
  });
}
/* 0.9.354: un titolo scelto dal tuo agente non e' nel catalogo: chi, tema e curiosita' arrivano con lui (opera.info) */
function gfInfo(){ return (GF.cfg && GF.cfg.opere[GF.op.t]) || GF.op.info || { chi: '', tema: '', curiosita: '' }; }
function gfLibro(){ return GF.op && GF.op.tipo === 'libro'; }
function gfSogno(){ try{ const n = (typeof nvSogno === 'function') ? nvSogno() : ''; return n ? 'il tuo sogno, "' + n + '"' : 'il tuo sogno'; }catch(_){ return 'il tuo sogno'; } }
function gfDomande(){
  const t = GF.op.t, info = gfInfo(), chi = info.chi || 'il protagonista';
  const temi = (GF.cfg && GF.cfg.temi) || {};
  return [
    { k: 'momento', q: 'Di "' + t + '", quale momento ti è rimasto addosso?', ph: 'Il momento che mi è rimasto è…',
      o: [['😮', 'Quando sembrava tutto perso'], ['🔥', 'Quando ha deciso di non mollare'], ['🥲', 'Un momento che mi ha toccato'], ['💬', 'Una frase che non dimentico']] },
    { k: 'tema', q: 'Di "' + t + '" ti ha preso soprattutto…', ph: 'Mi ha preso…',
      o: Object.keys(temi).slice(0, 4).sort(function(a, b){ return a === info.tema ? -1 : b === info.tema ? 1 : 0; }).map(function(k){ return [GF_EMO[k] || '✨', temi[k], k]; }) },
    { k: 'mossa', q: 'Se ' + chi + ' avesse ' + gfSogno() + ', cosa farebbe per prima cosa domani?', ph: 'Domani farebbe…',
      o: [['📞', 'Chiamerebbe una persona che può aiutarlo'], ['🧗', 'Comincerebbe dalla parte più difficile'], ['✂️', 'Toglierebbe quello che lo distrae'], ['🚶', 'Farebbe il primo passo, anche piccolo']] }
  ];
}
const GF_EMO = { rinascita: '🌱', talento: '🎯', ribellione: '✊', amore: '❤️', ingegno: '💡', spirito: '🕊️', liberta: '🧭' };
function gfRisposta(testo, tema){
  GF.risp.push({ q: gfDomande()[GF.i].k, a: String(testo || '') });
  if (tema){ const g = gfGusti(); g.temi[tema] = (g.temi[tema] || 0) + 2; gfGustiSalva(g); }
  GF.i++; GF.scrivi = false;
  try{ if (typeof gnAu !== 'undefined') gnAu.scelta(GF.i + 1); if (typeof flVibra === 'function') flVibra(14); }catch(_){ }
  gnVai(GF.i < gfDomande().length ? 'gfDomanda' : 'gfFine');
}
function gfOpz(i, j){ const o = gfDomande()[i].o[j]; gfRisposta(o[1], o[2]); }
function gfScriviApri(){ GF.scrivi = true; gnVai('gfDomanda'); setTimeout(function(){ const a = document.getElementById('gfArea'); if (a) a.focus(); }, 200); }
function gfScriviOk(){
  const a = document.getElementById('gfArea'), t = String(a ? a.value : '').trim();
  if (!t){ if (a) a.focus(); return; }
  gfRisposta(t);
}
/* la fine: una cosa da fare scelta da lui, che resta nella pagina e nel brief dell'agente. Niente scadenze. */
function gfFineOk(){
  const a = document.getElementById('gfArea'), t = String(a ? a.value : '').trim();
  if (!t){ if (a) a.focus(); return; }
  gfSalva(t);
}
function gfSalva(azione){
  const o = epiIspStato(), st = o[GF.s];
  if (st){ st.azione = { t: azione, at: Date.now() }; st.conversazione = GF.risp.slice(); epiIspSalva(o); }
  const g = gfGusti();
  g.opere = g.opere.filter(function(x){ return x.t !== GF.op.t; }).concat([{ t: GF.op.t, tipo: GF.op.tipo, risp: GF.risp.slice(), azione: azione, at: Date.now() }]).slice(-20);
  gfGustiSalva(g);
  try{ if (typeof ffAddCoins === 'function') ffAddCoins(30); }catch(_){ }
  gnVai('gfSaluto');
}
/* 0.9.321, Andrea: "nel quiz sui film il tasto indietro del telefono non torna alla domanda prima" */
function gfIndietro(){
  if (GN.typing && GN.completa){ GN.completa(); return true; }
  if (GN.step === 'gfDomanda' && GF.scrivi){ GF.scrivi = false; gnVai('gfDomanda'); return true; }
  if (GN.step === 'gfParla'){ gfEsci(); return true; }
  if (GN.step === 'gfDomanda' && GF.i === 0){ gnVai('gfParla'); return true; }
  if (GN.step === 'gfDomanda' || GN.step === 'gfFine'){
    GF.i = Math.max(0, GF.i - 1); GF.risp.pop(); GF.scrivi = false;
    gnVai('gfDomanda'); return true;
  }
  if (GN.step === 'gfSaluto'){ gfEsci(); return true; }
  return false;
}
function gfEsci(){
  GN.on = false; GN.modo = '';
  try{ const t = document.getElementById('gnTop'); if (t){ t.hidden = true; t.classList.remove('ak-top'); } }catch(_){ }
  goId('s-serie');
  try{ if (typeof epiSeriePaint === 'function') epiSeriePaint(); }catch(_){ }
}
function gfVaiAgente(){
  /* la bozza nel campo: parte solo con l'invio */
  const op = GF.op || {}, ultima = GF.risp[GF.risp.length - 1];
  gfEsci();
  if (typeof agApri === 'function'){ agApri(); if (typeof agBozza === 'function') agBozza('Ho appena finito "' + (op.t || '') + '". Fammi qualche domanda per capire cosa posso usarne per il mio sogno.' + (ultima ? ' Il Genio mi ha chiesto cosa farebbe il protagonista e ho risposto: ' + ultima.a + '.' : '')); }
}
function gfVaiGioco(){ GN.on = false; try{ if (typeof akApri === 'function') akApri(); }catch(_){ } }
(function(){
  if (typeof GN_PASSI === 'undefined') return;
  GN_PASSI.gfParla = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('rivela');
    const info = gfInfo();
    /* senza una curiosita' sicura il Genio non ne promette una */
    gnScrivi((gfLibro() ? 'Hai letto "' : 'Hai visto "') + GF.op.t + '". ' + (info.curiosita ? 'Ti dico una cosa che in pochi sanno. ' + info.curiosita + ' ' : '') + 'Parliamone?', function(){
      akRisp('<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'gfDomanda\')">Parliamone</button></div>');
    });
  } };
  GN_PASSI.gfDomanda = { entra: function(){
    akScena(['domanda']); akBarra(false);
    gnPosa('pensa');
    const q = gfDomande()[GF.i];
    gnScrivi(q.q, function(){
      if (GF.scrivi){
        akRisp('<div class="gn-carta">' + (typeof micArea === 'function' ? micArea('gfArea', 4, q.ph) : '<textarea class="gn-area" id="gfArea" rows="4" placeholder="' + gfEsc(q.ph) + '"></textarea>')
          + '<button type="button" class="or-a main gf-ok" onclick="event.stopPropagation();gfScriviOk()">Confermo</button></div>');
        return;
      }
      /* 0.9.319, Andrea: le stesse due colonne di tutti i quiz del Genio, non una pila */
      akRisp('<div class="or-grid quattro gf-griglia">' + q.o.map(function(o, j){ return '<button type="button" class="or-a" onclick="event.stopPropagation();gfOpz(' + GF.i + ',' + j + ')"><span>' + o[0] + '</span>' + gfEsc(o[1]) + '</button>'; }).join('')
        + '<button type="button" class="or-a gf-tutta" onclick="event.stopPropagation();gfScriviApri()">✍️ Lo scrivo io</button></div>');
    });
  } };
  GN_PASSI.gfFine = { entra: function(){
    akScena(['domanda']); akBarra(false);
    gnPosa('rivela');
    gnScrivi('E tu? Qual è la cosa che fai adesso, per il tuo sogno, ispirato da "' + GF.op.t + '"?', function(){
      akRisp('<div class="gn-carta">' + (typeof micArea === 'function' ? micArea('gfArea', 4, 'La cosa che faccio è…') : '<textarea class="gn-area" id="gfArea" rows="4"></textarea>')
        + '<button type="button" class="or-a main gf-ok" onclick="event.stopPropagation();gfFineOk()">Me lo segno</button></div>');
    });
  } };
  GN_PASSI.gfSaluto = { entra: function(){
    akScena([]); akBarra(false);
    gnPosa('saluta');
    const prem = (typeof akPremium === 'function') && akPremium();
    gnScrivi('Segnato. Adesso so qualcosa in più di te: la prossima sorpresa la scelgo con questo in testa. Hai guadagnato 30 monete.', function(){
      akRisp('<div class="or-grid one">'
        + (prem ? '<button type="button" class="or-a main" onclick="event.stopPropagation();gfVaiAgente()">Continua con il tuo agente personale</button>' : '')
        + '<button type="button" class="or-a' + (prem ? '' : ' main') + '" onclick="event.stopPropagation();gfVaiGioco()">Mettimi alla prova con un gioco</button>'
        + '<button type="button" class="or-a" onclick="event.stopPropagation();gfEsci()">Torna alla tua storia</button></div>');
    });
  } };
})();

/* il pannello dei giochi, nella pagina della storia: si apre dopo il primo episodio visto */
function gfEpisodiVisti(){
  try{ const v = epiStato().visti || {}; return Object.keys(v).length; }catch(_){ return 0; }
}
function gfGiochiHtml(){
  const aperti = gfEpisodiVisti() > 0;
  const g = gfGusti();
  let pensati = 0; try{ pensati = (JSON.parse(localStorage.getItem('fl_genio_pensati') || '[]') || []).length; }catch(_){ }
  const sotto = aperti ? 'Pensa a un personaggio, a un libro o a un film: lo indovino con qualche domanda. Così capisco cosa ti piace, e le prossime sorprese le scelgo per te.' : 'Si apre dopo il tuo primo episodio.';
  return '<section class="gf-box' + (aperti ? '' : ' chiuso') + '" data-cg-no>'
    + '<img src="img/genio/genio-rivela.png" alt="">'
    + '<h2>Mettimi alla prova</h2><p>' + sotto + '</p>'
    + (aperti ? '<button type="button" class="gf-play" onclick="if(typeof akApri===\'function\')akApri()">Gioca con il Genio</button>'
        + (pensati || Object.keys(g.temi).length ? '<small class="gf-num">Finora ho imparato da ' + (pensati + g.opere.length) + ' tue ' + (pensati + g.opere.length === 1 ? 'risposta' : 'risposte') + '.</small>' : '')
        + '<label class="gf-cons"><input type="checkbox"' + (gfConsenso() ? ' checked' : '') + ' onchange="gfConsensoCambia(this.checked)"><span>Le mie partite possono aiutare il Genio a indovinare meglio per tutti. Parte solo il gioco: il titolo pensato e le risposte, senza il mio nome.</span></label>' : '')
    + '</section>';
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.gf-box{margin:30px 0 8px;padding:22px 20px;border-radius:24px;background:linear-gradient(168deg,#123A70,#001E44 62%);color:#fff;text-align:center}',
    '.gf-box img{display:block;width:92px;height:auto;margin:0 auto 6px}.gf-box h2{margin:0;font:800 23px var(--font-display);color:#fff}.gf-box p{margin:8px auto 0;max-width:34ch;font:500 14.5px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.gf-box.chiuso img{filter:grayscale(.5) brightness(.8)}',
    '.gf-play{width:100%;min-height:52px;margin-top:18px;border:0;border-radius:26px;background:#fff;color:#0E2350;font:800 16px var(--font-body);cursor:pointer}',
    '.gf-num{display:block;margin-top:12px;font:600 13px var(--font-body);color:#BCE0FF}',
    '.gf-cons{display:flex;align-items:flex-start;gap:10px;margin-top:16px;padding-top:14px;border-top:1px solid rgba(255,255,255,.14);text-align:left;font:500 12.5px/1.45 var(--font-body);color:rgba(255,255,255,.8);cursor:pointer}.gf-cons input{flex:none;width:20px;height:20px;margin:0;accent-color:#0075E3}',
    '.gf-opz{display:flex;flex-direction:column;gap:8px}.gf-o{display:flex;align-items:center;gap:12px;width:100%;min-height:54px;padding:10px 14px;box-sizing:border-box;border:2px solid #BCE0FF;border-radius:16px;background:#fff;color:#0E2350;text-align:left;cursor:pointer}',
    '.gf-o span{flex:none;font-size:22px;line-height:1}.gf-o b{font:700 15px/1.3 var(--font-body)}.gf-o.scrivi{border-style:dashed}',
    '.gf-griglia .or-a{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:14px 8px;font-size:14.5px;line-height:1.25}.gf-griglia .or-a > span{font-size:24px;line-height:1}.gn-risp .or-grid.quattro.gf-griglia .gf-tutta{grid-column:1/-1;flex-direction:row}',
    '.gf-ok{margin-top:12px;width:100%}'
  ].join('');
  document.head.appendChild(st);
})();
