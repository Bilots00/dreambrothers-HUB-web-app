/* ===========================================================================================
   IL TABELLONE DAL VIVO, OVUNQUE

   COS'ERA PRIMA E PERCHE' NON BASTAVA.
   Il punteggio passava dal telefono al computer sulla rete di casa: l'app chiamava un
   indirizzo tipo 192.168.1.5 e il computer rispondeva. Funziona, ma solo dentro quelle quattro
   mura. Basta uscire — un treno, l'ufficio, una camera d'albergo, la connessione dati — e i
   due tabelloni si dividono senza dire niente. E nessuno a cui scarichi l'app sa cos'e' un
   indirizzo IP, ne' deve saperlo: il punteggio di una partita si aggiorna perche' c'e'
   internet, punto.

   COME FUNZIONA ADESSO.
   Il punteggio vive sull'account. E' lo stesso account Google e lo stesso server dei backup:
   li' dentro ogni dispositivo ha una sua riga, e una riga in piu' — chiamata `match-score` —
   e' il tabellone. Nessun indirizzo, nessuna configurazione, nessun server nuovo da costruire.
   Chi ha fatto l'accesso ha il tabellone ovunque; chi non l'ha fatto gioca lo stesso, in
   locale, e il giorno che accede si ritrova tutto.

   PERCHE' UN PUNTO NON SI PERDE E NON SI CONTA DUE VOLTE.
   Il documento non tiene «il punteggio»: tiene QUANTI PUNTI HA SEGNATO CIASCUN DISPOSITIVO, e
   il totale e' la somma. Se il telefono segna due gol mentre il computer e' spento e il
   computer ne segna uno per conto suo, alla riaccensione sono tre. Tenere un numero solo e
   sovrascriverlo avrebbe perso il gol di chi scriveva per secondo — ed e' proprio il caso
   normale: due dispositivi, una persona sola, la stessa giornata.

   I GIORNI PERSI SONO UN CASO A PARTE. Il punto che il vecchio te segna quando una giornata
   finisce senza piano lo calcolano ENTRAMBI i dispositivi, ognuno per conto suo, sulla stessa
   data: sommandoli, quel giorno varrebbe due punti. Per questo i giorni non stanno nel conto
   di un dispositivo ma in un elenco di date — `days` — dove la stessa data scritta due volte
   resta una. Il totale del vecchio te e' «i suoi punti d'azione, piu' quante date ci sono».

   IL TOTALE MOSTRATO E' SEMPRE «gli altri, piu' me», mai il numero che il server aveva un
   istante fa. E' la differenza fra un tabellone che sale e uno che sfarfalla: appena segni, il
   punto e' gia' tuo e nessuna risposta in arrivo puo' toglierlo prima che sia stato spedito.

   COSA RESTA DELLA RETE DI CASA. Niente di obbligatorio. Se l'indirizzo e' gia' salvato il
   punteggio continua a partire anche di li' — istantaneo invece che entro venti secondi — ma
   non viene piu' chiesto a nessuno.
   =========================================================================================== */

const LS_KEY  = 'fl_match_sync';        // il mio contributo + cosa ho gia' visto
const LS_DEV  = 'dbdev_id';             // chi sono io, per il tabellone
const LS_SLOT = 'match-score';          // la riga del tabellone fra quelle dei backup
const LS_EVERY = 20000;                 // ogni venti secondi: dal vivo, per un tabellone

/* ---------------------------------------------------------------------------------------
   CHI SONO IO

   Volutamente FUORI dal prefisso fl_, che e' quello che finisce nel backup. Se l'identita' di
   questo dispositivo viaggiasse dentro a un backup, ripristinarlo su un secondo telefono
   creerebbe due dispositivi con lo stesso nome: i loro punti finirebbero nella stessa casella
   e uno dei due sparirebbe a ogni scrittura.
   --------------------------------------------------------------------------------------- */
function lsDevId(){
  let v = '';
  try{ v = localStorage.getItem(LS_DEV) || ''; }catch(_){ }
  if (!v){
    v = 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    try{ localStorage.setItem(LS_DEV, v); }catch(_){ }
  }
  return v;
}

function lsDevName(){
  /* Non «esiste getWebTime?»: quella gliela innesta motore-web.js anche al computer. */
  try{ return (typeof pcQui === 'function' && pcQui() === 'desktop') ? 'Computer' : 'Telefono'; }
  catch(_){ return 'Dispositivo'; }
}

/* ---------------------------------------------------------------------------------------
   IL MIO CONTRIBUTO
   --------------------------------------------------------------------------------------- */

function lsWrite(s){ try{ localStorage.setItem(LS_KEY, JSON.stringify(s)); }catch(_){ } }

function lsMine(){
  let s = null;
  try{ s = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); }catch(_){ }
  if (!s || typeof s !== 'object'){
    /* PRIMA VOLTA: quello che questo dispositivo ha gia' sul tabellone e' suo.
       L'alternativa — partire da zero — cancellerebbe la partita in corso davanti agli occhi
       di chi la sta giocando, che e' il modo piu' veloce di far disinstallare un'app. */
    const t = (typeof mtState === 'function') ? mtState() : { old: 0, neo: 0 };
    s = { neo: t.neo || 0, old: t.old || 0, days: {},
          seen: { old: t.old || 0, neo: t.neo || 0 }, epoch: lsEpochNow() };
    lsWrite(s);
  }
  s.days = s.days || {};
  s.plans = s.plans || {};
  s.seenDays = s.seenDays || {};
  s.seen = s.seen || { old: 0, neo: 0 };
  if (!s.epoch) s.epoch = lsEpochNow();
  /* IL CONTO HA UN PADRONE (6/10/2026). Se questo conto e' stato scritto da un altro
     dispositivo (arrivato con un backup ripristinato), i suoi punti li ha gia' dichiarati lui:
     qui si riparte da zero, senza toccare il tabellone che si vede. */
  if (s.dev && s.dev !== lsDevId()){
    const t = (typeof mtState === 'function') ? mtState() : { old: 0, neo: 0 };
    s.neo = 0; s.old = 0; s.seen = { old: t.old || 0, neo: t.neo || 0 }; s.dev = lsDevId();
    lsWrite(s);
  }
  /* I PIANI SCRITTI QUI vanno nel documento condiviso, sempre: cosi' un giorno addebitato da
     un altro dispositivo che non aveva il piano viene scontato da tutti. Si rilegge il registro
     locale ogni volta, che e' la fonte, e costa niente. */
  try{
    const m = JSON.parse(localStorage.getItem('fl_plan_days') || '{}') || {};
    for (const k in m) if (Object.prototype.hasOwnProperty.call(m, k) && m[k] && /^\d{4}-\d{2}-\d{2}$/.test(k)) s.plans[k] = 1;
  }catch(_){ }
  return s;
}

/* Quel giorno risulta pianificato, qui o su un altro dispositivo? */
function lsPlanned(day){
  const s = lsMine();
  if (s.plans[day]) return true;
  return !!(LS_DOC && LS_DOC.plans && LS_DOC.plans[day]);
}
function lsPlanMark(day){
  const s = lsMine();
  s.plans[day] = 1;
  lsWrite(s);
  lsPushSoon();
}

/* L'epoca della partita: per il campionato e' una sola e non finisce mai; per chi gioca una
   partita al giorno e' la data di oggi. Serve a far ripartire i tabelloni INSIEME a mezzanotte
   invece che uno per volta. */
/* L'epoca del campionato non e' piu' una costante: si puo' fischiare l'inizio di una partita
   nuova, e tutti i dispositivi la adottano azzerando (lsAdopt). Serviva per uscire dal
   tabellone gonfiato dalla somma, e serve ogni volta che si vuole ricominciare davvero. */
const LS_EPOCA = 'fl_match_epoch';
/* 0.9.264, Andrea (quarta volta): dopo "Ricomincia da capo" la chiamata diceva "Sei sotto 3 a 10".
   Sul server il tabellone era nell'epoca "k1789491974194" (una partita a tempo di settembre) con
   dentro Computer 7-0 e un vecchio Computer 3-3. Il reset scriveva un'epoca "c..." e le epoche si
   confrontavano COME TESTO: "c" viene prima di "k", quindi la partita nuova risultava piu' vecchia di
   quella di settembre, il telefono adottava quella e risommava 7+3 = 10. Adesso si confrontano per
   l'ora che portano dentro; e il reset scrive "r" + millisecondi, che vince anche sul codice vecchio
   ancora acceso su un altro dispositivo ("r" viene dopo "c" e "k"). */
function lsEpocaT(e){
  e = String(e || '');
  let m = /^[rk](\d{12,})$/.exec(e);
  if (m) return +m[1];
  if (e !== 'campionato' && (m = /^c([0-9a-z]{6,})$/.exec(e))){ const t = parseInt(m[1], 36); return isFinite(t) ? t : 0; }
  if (/^\d{4}-\d{2}-\d{2}$/.test(e)) return new Date(e + 'T00:00:00').getTime();
  return 0;   /* "campionato" o niente: la partita di sempre, la piu' vecchia di tutte */
}
/** l'epoca a e' piu' recente dell'epoca b? */
function lsEpocaDopo(a, b){
  const ta = lsEpocaT(a), tb = lsEpocaT(b);
  if (ta !== tb) return ta > tb;
  return String(a || '') > String(b || '');
}
function lsEpocaCampionato(){
  try{ return localStorage.getItem(LS_EPOCA) || 'campionato'; }catch(_){ return 'campionato'; }
}
/** Azzera qui e dichiara una partita nuova: gli altri dispositivi la vedranno piu' recente. */
function lsRiparti(){
  const nuova = 'r' + Date.now();
  try{ localStorage.setItem(LS_EPOCA, nuova); }catch(_){ }
  const s = lsMine();
  s.epoch = nuova; s.neo = 0; s.old = 0; s.days = {}; s.plans = {}; s.seenDays = {};
  s.seen = { old: 0, neo: 0 };
  lsWrite(s);
  try{
    if (typeof mtState === 'function' && typeof mtWrite === 'function'){
      const cur = mtState(); cur.old = 0; cur.neo = 0; mtWrite(MT_KEY, cur);
    }
  }catch(_){ }
  try{ localStorage.setItem('fl_match_hist', '[]'); }catch(_){ }
  try{ if (typeof lsPushSoon === 'function') lsPushSoon(); }catch(_){ }
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:match')); }catch(_){ }
  return nuova;
}

function lsEpochNow(){
  try{
    const st = (typeof mgCfg === 'function') ? mgCfg().season : 'campionato';
    if (st === 'giorno') return (typeof mgDayKey === 'function') ? mgDayKey() : 'campionato';
    /* UNA PARTITA A TEMPO E' UN'EPOCA SUA. Senza questo, il calcio d'inizio azzerava il
       tabellone qui e il giro di sincronizzazione dopo glielo rimetteva com'era: il punteggio
       della partita precedente tornava dentro a quella nuova, dal cloud. L'ora del fischio
       d'inizio e' l'unica cosa che distingue una partita dalla successiva, quindi e' lei. */
    if (st === 'tempo' && typeof koLive === 'function'){
      const k = koLive();
      if (k && k.at) return 'k' + k.at;
    }
  }catch(_){ }
  return lsEpocaCampionato();
}

/* ---------------------------------------------------------------------------------------
   IL FISCHIO D'INIZIO DI OGGI, una volta sola.
   Il tabellone era gonfio per la somma descritta sopra: un numero che non corrisponde a
   niente non si corregge a mano, si ricomincia. Chi installa adesso parte gia' da zero e non
   se ne accorge.
   --------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------
   LA PARTITA CHE IL RESET NON AVEVA CHIUSO (0.9.264, Andrea).
   Chi ha fatto "Ricomincia da capo" con il confronto vecchio e' rimasto dentro la partita di
   prima (un'epoca piu' vecchia del reset, sul server), e si e' ritrovato i punti degli altri
   dispositivi: 10 a 3. Nessuno deve sapere cos'e' un server per uscirne: se la partita in corso
   e' nata PRIMA dell'ultimo reset, l'app la chiude da sola e ne apre una nuova. Restano solo i
   punti segnati qui dopo il reset; gli altri dispositivi la adottano perche' e' piu' recente.
   Le partite «del giorno» (epoca = data) non si toccano: ripartono comunque a mezzanotte.
   --------------------------------------------------------------------------------------- */
function lsRiparaDopoReset(){
  try{
    const r = +localStorage.getItem('fl_reset_ultimo') || 0;
    if (!r) return false;
    const s = lsMine();
    const ep = String(s.epoch || '');
    if (!/^(k|c|campionato$)/.test(ep) && ep !== '') return false;
    if (lsEpocaT(ep) >= r - 60000) return false;          // la partita e' nata dopo il reset: e' giusta
    const nuova = 'r' + Date.now();
    try{ localStorage.setItem(LS_EPOCA, nuova); }catch(_){ }
    s.epoch = nuova; s.days = {}; s.plans = {}; s.seenDays = {};
    s.neo = s.neo || 0; s.old = s.old || 0;
    s.seen = { old: s.old, neo: s.neo };
    lsWrite(s);
    if (typeof mtState === 'function' && typeof mtWrite === 'function'){
      const cur = mtState(); cur.old = s.old; cur.neo = s.neo; mtWrite(MT_KEY, cur);
    }
    /* i punti arrivati dagli altri dispositivi appartenevano alla partita chiusa: via dal registro */
    try{
      const h = (typeof mgHist === 'function') ? mgHist() : [];
      h.forEach(function(g){ g.eventi = (g.eventi || []).filter(function(e){ return !(e && e.da); }); });
      localStorage.setItem('fl_match_hist', JSON.stringify(h));
    }catch(_){ }
    LS_DOC = null; LS_ROW_AT = '';
    try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
    lsPushSoon();
    return true;
  }catch(_){ return false; }
}
setTimeout(function(){ try{ lsRiparaDopoReset(); }catch(_){ } }, 1500);

(function lsRipartiUnaVolta(){
  const K = 'fl_match_reset_somma';
  try{
    if (localStorage.getItem(K)) return;
    localStorage.setItem(K, String(Date.now()));
    setTimeout(function(){ try{ lsRiparti(); }catch(_){ } }, 1200);
  }catch(_){ }
})();

/* ---------------------------------------------------------------------------------------
   I TRE GANCI CHE IL RESTO DELL'APP CHIAMA
   --------------------------------------------------------------------------------------- */

/* Ogni volta che il tabellone locale cambia. La differenza rispetto all'ultima volta e' roba
   segnata QUI, quindi va nel mio conto. Solo in salita: quando il totale scende e' perche' e'
   arrivata una somma dal server, e quella non e' roba mia da rivendicare. */
function lsSeen(t){
  if (!t) return;
  const s = lsMine();
  const dOld = (t.old || 0) - s.seen.old;
  const dNeo = (t.neo || 0) - s.seen.neo;
  if (dOld > 0) s.old += dOld;
  if (dNeo > 0) s.neo += dNeo;
  s.seen = { old: t.old || 0, neo: t.neo || 0 };
  lsWrite(s);
  if (dOld > 0 || dNeo > 0) lsPushSoon();
}

/* Una giornata chiusa senza piano. Non e' un punto «mio»: e' un fatto del calendario, che
   qualsiasi dispositivo acceso quel giorno calcolerebbe uguale. Va nell'elenco delle date, e
   il conto locale che l'ha appena aggiunta viene dichiarato gia' visto — altrimenti finirebbe
   due volte, una come data e una come punto d'azione. */
function lsChargeDay(k){
  if (!k) return;
  return;                    // vedi lsGiorniValidi: il giorno senza piano non si addebita piu'
  // eslint-disable-next-line no-unreachable
  if (lsPlanned(k)) return;   // qualcuno il piano lo aveva scritto: niente da addebitare
  const s = lsMine();
  if (!s.days[k]) s.days[k] = 1;
  s.seen.old += 1;
  lsWrite(s);
  lsPushSoon();
}

/* Mezzanotte, per chi gioca una partita al giorno: si riparte da zero, e non solo qui. */
function lsResetEpoch(){
  const s = lsMine();
  s.neo = 0; s.old = 0; s.days = {}; s.plans = {}; s.seenDays = {};
  s.seen = { old: 0, neo: 0 };
  s.epoch = lsEpochNow();
  lsWrite(s);
  LS_DOC = null; LS_ROW_AT = '';
  lsPushSoon();
}

/* ---------------------------------------------------------------------------------------
   LA RETE
   --------------------------------------------------------------------------------------- */

let LS_DOC = null;        // l'ultimo documento letto dal server
let LS_ROW_AT = '';       // quando e' stato scritto: se non cambia, non si riscarica
let LS_BUSY = false;
let LS_PUSH_T = 0;
let LS_LAST = { at: 0, ok: false, why: '' };

function lsCan(){
  try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; }
}

async function lsCall(method, path, body){
  const r = await NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
  return r || {};
}

function lsEmptyDoc(){
  return { kind: 'focuslock-score', v: 1, epoch: lsEpochNow(), devices: {}, days: {}, plans: {} };
}

/* I giorni addebitati che valgono davvero: quelli senza un piano in NESSUNA delle due liste. */
function lsGiorniValidi(giorni, piani){
  /* IL PIANO NON LO SCRIVE PIU' LUI. Dal 23/09/2026 il piano del giorno lo fa il Genio (o
     Jordan): Andrea lo esegue. Un giorno «senza piano scritto» non e' piu' una scelta sua, e
     un punto per una cosa che non dipende da te non e' un punto, e' una tassa. Le date che i
     dispositivi hanno gia' scritto restano nel documento ma non contano piu'. */
  return 0;
}

/* ---------------------------------------------------------------------------------------
   I CLONI (6/10/2026). Il 6/10 Andrea ha installato DreamMap su un secondo computer: il
   ripristino del backup dell'account gli ha copiato il conto del telefono (fl_match_sync), e
   il computer nuovo l'ha dichiarato come suo. Risultato: 6-3 diventato 9-6, con «segnato su un
   altro dispositivo» come motivo. Lo stesso guaio del 22/09 (8-8 → 16-16), che allora era
   stato chiuso solo per lo specchio e non per il backup.
   La firma di una copia: i punti che dichiara portano gli STESSI istanti, al millesimo, di
   quelli di un dispositivo piu' vecchio (l'id porta l'ora in cui e' nato). Due dispositivi
   veri non segnano mai nello stesso millesimo. Una copia non si conta finche' non si e'
   corretta da sola con il codice nuovo (v2).
   --------------------------------------------------------------------------------------- */
function lsIdTempo(id){
  const m = /^d([0-9a-z]+)[0-9a-z]{6}$/.exec(String(id || ''));
  if (!m) return 0;
  const t = parseInt(m[1], 36);
  return isFinite(t) && t > 1.5e12 ? t : 0;
}
function lsIstanti(log){ const o = {}; (log || []).forEach(function(e){ if (e && e.at) o[e.chi + ':' + e.at] = 1; }); return o; }
/** id del dispositivo copia → nome dell'originale */
function lsCloni(doc){
  const out = {}, d = (doc && doc.devices) || {}, ids = Object.keys(d);
  ids.forEach(function(b){
    const B = d[b]; if (!B || B.v2) return;
    const tb = lsIdTempo(b); if (!tb) return;
    const kb = Object.keys(lsIstanti(B.log)); if (!kb.length) return;
    for (let i = 0; i < ids.length; i++){
      const a = ids[i]; if (a === b) continue;
      const ta = lsIdTempo(a); if (!ta || ta >= tb) continue;
      const ia = lsIstanti(d[a] && d[a].log);
      if (kb.some(function(k){ return ia[k]; })){ out[b] = (d[a] && d[a].name) || 'altro dispositivo'; break; }
    }
  });
  return out;
}
/* Sono io la copia? Una volta sola per dispositivo: se si', il mio conto torna a zero e le
   righe copiate nel registro diventano «arrivate dall'originale», cosi' non si rispediscono. */
function lsControllaCopia(doc){
  const s = lsMine();
  if (s.dev) return;
  const io = lsDevId(), tio = lsIdTempo(io);
  const mieri = {};
  try{ (typeof mgHist === 'function' ? mgHist() : []).forEach(function(g){ (g.eventi || []).forEach(function(e){ if (e && e.at && !e.da) mieri[e.chi + ':' + e.at] = 1; }); }); }catch(_){ }
  let originale = '';
  const d = (doc && doc.devices) || {};
  if (tio && Object.keys(mieri).length){
    for (const a in d){
      if (!Object.prototype.hasOwnProperty.call(d, a) || a === io) continue;
      const ta = lsIdTempo(a); if (!ta || ta >= tio) continue;
      const ia = lsIstanti(d[a] && d[a].log);
      if (Object.keys(mieri).some(function(k){ return ia[k]; })){ originale = (d[a] && d[a].name) || 'altro dispositivo'; break; }
    }
  }
  if (originale){
    s.neo = 0; s.old = 0;
    try{
      const h = mgHist();
      h.forEach(function(g){ (g.eventi || []).forEach(function(e){ if (e && e.at && !e.da) e.da = originale; }); });
      localStorage.setItem('fl_match_hist', JSON.stringify(h));
    }catch(_){ }
  }
  s.dev = io;
  lsWrite(s);
}

/* Quello che hanno segnato GLI ALTRI. Il mio conto non si legge mai dal server: e' qui, ed e'
   piu' aggiornato per definizione. */
function lsOthers(doc){
  const io = lsDevId();
  const out = { old: 0, neo: 0, days: {} };
  const d = (doc && doc.devices) || {};
  const cloni = lsCloni(doc);
  for (const k in d){
    if (!Object.prototype.hasOwnProperty.call(d, k) || k === io || cloni[k]) continue;
    out.old += (+d[k].old || 0);
    out.neo += (+d[k].neo || 0);
  }
  const g = (doc && doc.days) || {};
  for (const k in g) if (Object.prototype.hasOwnProperty.call(g, k)) out.days[k] = 1;
  out.plans = Object.assign({}, (doc && doc.plans) || {});
  return out;
}

/* La somma di TUTTO quello che c'e' in un documento, me compreso: serve quando il documento
   e' gia' stato unito e va riassunto per il server. */
function lsSum(doc){
  let old = 0, neo = 0, n = 0;
  const d = (doc && doc.devices) || {};
  const cloni = lsCloni(doc);
  for (const k in d){
    if (!Object.prototype.hasOwnProperty.call(d, k) || cloni[k]) continue;
    old += (+d[k].old || 0);
    neo += (+d[k].neo || 0);
  }
  n = lsGiorniValidi((doc && doc.days) || {}, (doc && doc.plans) || {});
  return { old: old + n, neo: neo };
}

function lsTotals(doc, s){
  /* 0.9.261, Andrea: dopo "Ricomincia da capo" compariva 10-3 "segnato su un altro dispositivo". La partita
     nuova (epoca piu' recente) sommava ancora i punti che il documento sul server teneva per la partita
     VECCHIA. Un documento di un'epoca precedente non conta: la partita nuova parte da 0 a 0. */
  if (doc && s && s.epoch && lsEpocaDopo(s.epoch, doc.epoch || '')) doc = null;
  const a = lsOthers(doc);
  const giorni = Object.assign({}, a.days, s.days || {});
  const piani = Object.assign({}, a.plans || {}, s.plans || {});
  const n = lsGiorniValidi(giorni, piani);
  return { old: a.old + (s.old || 0) + n, neo: a.neo + (s.neo || 0) };
}

/* Il documento con dentro la mia parte. Le parti degli altri non si toccano MAI: e' l'unica
   regola che tiene in piedi tutto il resto. */
function lsMerge(doc, s){
  const out = (doc && typeof doc === 'object' && doc.devices) ? JSON.parse(JSON.stringify(doc)) : lsEmptyDoc();
  out.devices = out.devices || {};
  out.days = out.days || {};
  out.plans = out.plans || {};
  out.kind = 'focuslock-score';
  out.v = 1;

  /* Epoche diverse = partite diverse. Vince la piu' recente: chi arriva dalla precedente
     lascia li' i punti vecchi invece di sommarli a una partita nuova. */
  if (lsEpocaDopo(s.epoch, out.epoch || '')){
    out.epoch = s.epoch;
    out.devices = {};
    out.days = {};
    out.plans = {};
  }

  /* IL MOTIVO VIAGGIA CON IL PUNTO. Il registro locale (mgHist) porta chi e perche'; le ultime
     quaranta righe entrano nel documento, cosi' l'altro dispositivo puo' scrivere la regola
     invece di «segnato su un altro dispositivo». */
  let log = [];
  try{
    (typeof mgHist === 'function' ? mgHist() : []).slice(-7).forEach(function(g){
      (g.eventi || []).forEach(function(e){
        if (!e || !e.at || e.da) return;                                   // importata: non si rispedisce
        if (/\(dal (computer|telefono|altro dispositivo)\)/i.test(String(e.motivo || ''))) return;   // le vecchie, senza segno
        log.push({ chi: e.chi, motivo: String(e.motivo || '').slice(0, 160), at: e.at });
      });
    });
    log = log.slice(-40);
  }catch(_){ log = []; }
  let arb = []; try{ arb = (typeof acApplicati === 'function') ? acApplicati().slice(-60) : []; }catch(_){ }
  out.devices[lsDevId()] = { neo: s.neo || 0, old: s.old || 0, name: lsDevName(), at: Date.now(), log: log, arb: arb, v2: 1 };
  for (const k in s.days) if (Object.prototype.hasOwnProperty.call(s.days, k)) out.days[k] = 1;
  for (const k in s.plans) if (Object.prototype.hasOwnProperty.call(s.plans, k)) out.plans[k] = 1;
  return out;
}

/* Se il server e' passato a una partita piu' recente della mia, la adotto e riparto da zero. */
function lsAdopt(doc){
  const s = lsMine();
  if (!doc || !doc.epoch || !lsEpocaDopo(doc.epoch, s.epoch)) return false;
  s.epoch = String(doc.epoch);
  s.neo = 0; s.old = 0; s.days = {}; s.plans = {}; s.seenDays = {};
  s.seen = { old: 0, neo: 0 };
  lsWrite(s);
  return true;
}

/* Il totale diventa il tabellone di questo dispositivo. Se e' salito e' un gol: si vede e si
   sente come un gol segnato qui, perche' la partita e' una sola — era esattamente questo che
   mancava, il punteggio che restava fermo sul computer mentre il telefono segnava. */
function lsApply(tot, doc){
  if (typeof mtState !== 'function' || typeof mtWrite !== 'function') return false;
  const cur = mtState();
  if ((cur.old || 0) === tot.old && (cur.neo || 0) === tot.neo) return false;

  const prevOld = cur.old || 0, prevNeo = cur.neo || 0;
  const suNeo = tot.neo > prevNeo;
  const suOld = tot.old > prevOld;
  /* IL TOTALE SCENDE quando un punto contato per sbaglio viene tolto (una copia riconosciuta):
     con lui se ne vanno le righe «segnato su un altro dispositivo» che aveva lasciato nel
     registro, dalle piu' recenti. */
  if (tot.old < prevOld || tot.neo < prevNeo){
    try{
      const giu = { old: Math.max(0, prevOld - tot.old), neo: Math.max(0, prevNeo - tot.neo) };
      const h = (typeof mgHist === 'function') ? mgHist() : [];
      for (let gi = h.length - 1; gi >= 0 && (giu.old || giu.neo); gi--){
        const ev = h[gi].eventi || [];
        for (let ei = ev.length - 1; ei >= 0; ei--){
          const e = ev[ei];
          if (e && e.da === 'altro' && e.motivo === 'segnato su un altro dispositivo' && giu[e.chi] > 0){ ev.splice(ei, 1); giu[e.chi]--; }
        }
      }
      localStorage.setItem('fl_match_hist', JSON.stringify(h));
    }catch(_){ }
  }
  cur.old = tot.old;
  cur.neo = tot.neo;
  mtWrite(MT_KEY, cur);

  /* Prima si dichiara visto, poi si ridisegna: al contrario il ridisegno leggerebbe una
     differenza e me la rivenderebbe come roba segnata qui, gonfiando il punteggio a ogni
     sincronizzazione. */
  const s = lsMine();
  s.seen = { old: tot.old, neo: tot.neo };

  /* IL MOTIVO, ANCHE QUANDO ARRIVA DA FUORI. Un punto che arriva dal server era un numero
     nudo: il cartello non diceva perche' e il registro non ne teneva traccia (il 6-3 del
     20/09 con quattro righe sole). Qui si ricostruisce: un giorno nuovo nell'elenco e' un
     «giorno senza piano scritto», il resto e' un punto segnato su un altro dispositivo. */
  if (suOld || suNeo){
    const giorniDoc = (doc && doc.days) || {};
    const piani = Object.assign({}, (doc && doc.plans) || {}, s.plans || {});
    const nuovi = [];
    for (const k in giorniDoc){
      if (!Object.prototype.hasOwnProperty.call(giorniDoc, k)) continue;
      if (s.seenDays[k] || s.days[k] || piani[k]) continue;
      nuovi.push(k);
    }
    nuovi.forEach(function(k){ s.seenDays[k] = 1; });
    try{
      if (typeof mgLog === 'function'){
        /* I motivi veri, dai registri degli altri dispositivi: le righe che non ho ancora
           visto, dalla piu' vecchia. Quello che manca resta «segnato altrove», ma e' l'eccezione. */
        const io_ = lsDevId();
        const vistoAt = s.seenLogAt || 0;
        const altrui = [];
        const dev = (doc && doc.devices) || {};
        for (const id in dev){
          if (!Object.prototype.hasOwnProperty.call(dev, id) || id === io_) continue;
          const nome = (dev[id] && dev[id].name) || 'altro dispositivo';
          ((dev[id] && dev[id].log) || []).forEach(function(e){ if (e && e.at > vistoAt) altrui.push({ chi: e.chi, motivo: e.motivo, at: e.at, nome: nome }); });
        }
        altrui.sort(function(a, b){ return a.at - b.at; });
        const prendi = function(chi){ const i = altrui.findIndex(function(e){ return e.chi === chi; }); if (i < 0) return null; return altrui.splice(i, 1)[0]; };
        const dOld = Math.max(0, tot.old - prevOld);
        for (let i = 0; i < dOld; i++){
          const e = prendi('old');
          /* niente piu' «giorno senza piano scritto»: dal 23/09 il piano lo fa l'agente e quel
             punto non esiste (lsGiorniValidi = 0); usarlo come etichetta era un'etichetta falsa */
          if (e) mgLog('old', e.motivo + ' (dal ' + e.nome.toLowerCase() + ')', { da: e.nome });
          else mgLog('old', 'segnato su un altro dispositivo', { da: 'altro' });
        }
        const dNeo = Math.max(0, tot.neo - prevNeo);
        for (let i = 0; i < dNeo; i++){
          const e = prendi('neo');
          mgLog('neo', e ? e.motivo + ' (dal ' + e.nome.toLowerCase() + ')' : 'segnato su un altro dispositivo', { da: e ? e.nome : 'altro' });
        }
        s.seenLogAt = Date.now();
      }
    }catch(_){ }
  }
  lsWrite(s);

  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  try{
    /* durante il primo avvio (il film del Genio, l'onboarding) i punti che arrivano da fuori non si mostrano */
    const avvio = !!document.querySelector('#s-genio.active, .screen.active[id^="s1"], .screen.active[id^="s2"], .screen.active[id^="s3"], .screen.active[id^="s4"], .screen.active[id^="s5"], .screen.active[id^="s6"]');
    if (!avvio && typeof mtGoal === 'function' && document.visibilityState === 'visible' && (suNeo || suOld))
      mtGoal(suNeo ? 'neo' : 'old');
  }catch(_){ }
  return true;
}

function lsPushSoon(){
  clearTimeout(LS_PUSH_T);
  LS_PUSH_T = setTimeout(function(){ lsSync(true); }, 1500);
}

/** Quello che il server non ha ancora di mio. */
function lsDaScrivere(s){
  const mio = (LS_DOC && LS_DOC.devices && LS_DOC.devices[lsDevId()]) || null;
  if (!mio) return true;
  if ((+mio.neo || 0) !== (s.neo || 0) || (+mio.old || 0) !== (s.old || 0)) return true;
  const g = (LS_DOC && LS_DOC.days) || {};
  for (const k in s.days) if (Object.prototype.hasOwnProperty.call(s.days, k) && !g[k]) return true;
  const pp = (LS_DOC && LS_DOC.plans) || {};
  for (const k in s.plans) if (Object.prototype.hasOwnProperty.call(s.plans, k) && !pp[k]) return true;
  return String((LS_DOC && LS_DOC.epoch) || '') !== String(s.epoch);
}

/**
 * Una passata: guarda se e' cambiato qualcosa, scarica solo se serve, scrivi solo se hai
 * qualcosa di tuo da aggiungere, e applica il totale.
 *
 * L'elenco dei backup porta gia' la data dell'ultima scrittura: finche' non cambia, non c'e'
 * niente da scaricare. Un tabellone che riscarica tutto ogni venti secondi e' traffico su una
 * riga che nessuno ha toccato.
 */
async function lsSync(scrivi){
  if (LS_BUSY || !lsCan()) return false;
  LS_BUSY = true;
  try{
    const lista = await lsCall('GET', '/api/focuslock/backups');
    const righe = (lista && lista.backups) || [];
    const riga = righe.filter(function(x){ return x && x.deviceId === LS_SLOT; })[0] || null;

    if (riga && String(riga.updatedAt || '') !== LS_ROW_AT){
      const pieno = await lsCall('GET', '/api/focuslock/backups/' + riga.id);
      LS_DOC = (pieno && pieno.payload) || null;
      LS_ROW_AT = String(riga.updatedAt || '');
      lsAdopt(LS_DOC);
    }
    if (!riga){ LS_DOC = null; LS_ROW_AT = ''; }
    lsControllaCopia(LS_DOC);

    let s = lsMine();
    if (scrivi || lsDaScrivere(s)){
      const unito = lsMerge(LS_DOC, s);
      const tot = lsSum(unito);   // il documento e' gia' unito: qui dentro ci sono anche i miei
      const r = await lsCall('PUT', '/api/focuslock/backups', {
        deviceId: LS_SLOT,
        deviceName: 'Tabellone della partita',
        appVersion: 'score',
        /* I due numeri viaggiano anche qui, dove il server li tiene in colonne sue: cosi' chi
           deve solo MOSTRARE il punteggio — la pillola sempre in vista sul computer — lo legge
           con una richiesta sola, senza scaricare il documento. */
        summary: { programs: tot.old, apps: tot.neo, sites: 0, keywords: 0 },
        backup: unito
      });
      LS_DOC = unito;
      LS_ROW_AT = String((r && r.backup && r.backup.updatedAt) || '');
    }

    s = lsMine();
    LS_LAST = { at: Date.now(), ok: true, why: '' };
    lsApply(lsTotals(LS_DOC, s), LS_DOC);
    return true;
  }catch(e){
    LS_LAST = { at: Date.now(), ok: false, why: (e && e.message) || 'non riuscito' };
    return false;
  }finally{
    LS_BUSY = false;
  }
}

/* ---------------------------------------------------------------------------------------
   IL BATTITO

   Solo con l'app davanti: interrogare il server mentre il telefono e' in tasca consuma
   batteria per aggiornare uno schermo spento.
   --------------------------------------------------------------------------------------- */
/* Sul computer la vista telefono sta spesso DIETRO ad altre finestre, e per il browser una
   pagina coperta e' "nascosta": con il cancello sulla visibilita' il tabellone si aggiornava
   solo quando la persona lo guardava — cioe' mai nel momento in cui serviva, e per farlo
   muovere toccava premere un pulsante. Un computer non ha una batteria da proteggere. */
function lsDesktop(){ try{ return !!(window.chrome && window.chrome.webview); }catch(_){ return false; } }
function lsTick(){
  if (document.visibilityState !== 'visible' && !lsDesktop()) return;
  lsSync(false);
}

setInterval(lsTick, LS_EVERY);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') lsTick(); });
setTimeout(lsTick, 4000);

/* ---------------------------------------------------------------------------------------
   COSA DIRE ALL'UTENTE: una riga sola, e onesta.
   --------------------------------------------------------------------------------------- */
function lsStatus(){
  if (!lsCan()) return { on: false, testo: 'Disponibile nell\'app installata.' };
  if (!LS_LAST.at) return { on: true, testo: 'Collegamento al tuo account in corso…' };
  if (!LS_LAST.ok)
    return { on: false, testo: 'Non sincronizzato: ' + LS_LAST.why };
  const min = Math.round((Date.now() - LS_LAST.at) / 60000);
  return { on: true, testo: 'Sincronizzato con il tuo account Google' + (min < 1 ? ', un istante fa.' : ', ' + min + ' min fa.') };
}

async function lsSyncNow(){
  if (!lsCan()){ if (typeof toast === 'function') toast('Disponibile nell\'app installata'); return; }
  const ok = await lsSync(true);
  if (typeof toast === 'function')
    toast(ok ? 'Tabellone aggiornato su tutti i tuoi dispositivi' : 'Account non raggiungibile: ' + LS_LAST.why);
  try{ if (typeof mgPaint === 'function' && document.getElementById('mgBody')) mgPaint(); }catch(_){ }
}
