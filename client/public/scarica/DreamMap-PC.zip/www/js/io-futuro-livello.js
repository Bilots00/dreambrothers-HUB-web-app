/* ===========================================================================================
   IL TUO IO FUTURO TI STA CHIAMANDO (0.9.298) — il livello subito dopo il Sabotatore invisibile.

   Andrea: "tutto dipende da questa parte iniziale: se il dove vuole arrivare, il sogno e la nuova identita'
   non sono chiari e precisi, il risultato sara' mediocre in tutto quello che viene dopo". E: "al posto della
   chiamata subito, un livello in cui l'utente conferma l'identita' del suo Io Futuro che l'app ha creato per
   lui, con la possibilita' di cambiare le risposte, esattamente come fa MyFutureSelf".

   Il principio (Atomic Habits, Psicocibernetica): le abitudini durano solo se sono coerenti con l'identita';
   ogni azione e' un voto per la persona che stai diventando. Non si spiega: lo racconta l'Io Futuro.

   I passi, in 2-3 minuti:
     1. la chiamata in arrivo: prima di parlarti vuole conoscerti;
     2. al massimo tre domande (quelle che non si possono dedurre), una per schermata, come MyFutureSelf. 0.9.307:
        chi vedi (si salta se il genere e' gia' noto), come si sente, cosa fa con facilita'. Le altre (fra un anno,
        quanto conosci, cosa vorresti) arrivano una per episodio (episodi.js, passo "nf"). Con tre scelte o piu'
        si mettono in ordine: la prima e' quella che conta di piu', e l'agente lo sa;
     3. LA TUA STORIA: tutte le risposte, anche quelle dedotte (dal Sabotatore, dal sogno, dal segno zodiacale
        se c'e' la data di nascita), ognuna si tocca e si cambia;
     4. la rivelazione: l'Io Futuro racconta chi e' diventato. "Sono io" o "Ritocca" (tre alternative pronte,
        mai un campo vuoto);
     5. il volto (selfie o foto) e la voce (le registrazioni per la chiamata, Premium);
     6. le regole della partita, vecchio te contro nuovo te, e i tre voti di ogni giorno nel foglio di START.
   L'identita' finisce in localStorage 'fl_iofuturo' (ifNuovoMe()): la leggono la roadmap su misura, la
   schermata fuori rotta ("Il nuovo te: ..."), la pagina "Chi saro'" e il modello Notion "Il mio futuro se'".

   GRATIS: il motore a modelli (categoria del sogno x blocco del Sabotatore, almeno tre varianti). PREMIUM:
   l'agente personale scrive lo stesso JSON (server: /api/focuslock/agent/identita); se non risponde in
   tempo o il JSON non e' valido, si usano i modelli. Nessun testo dice "devi": parla sempre l'Io Futuro.
   =========================================================================================== */
const NF_KEY = 'fl_iofuturo';
const NF = { c: null, fase: 'intro', i: 0, r: {}, ded: {}, id: null, alt: [], edit: '', ritorno: '', qs: [], ord: {}, solo: null };

function ifNuovoMe(){ try{ return JSON.parse(localStorage.getItem(NF_KEY) || 'null') || {}; }catch(_){ return {}; } }
function nfSalva(o){ try{ localStorage.setItem(NF_KEY, JSON.stringify(o)); return true; }catch(_){ return false; } }
/* 0.9.301: "Io Futuro" non si spezza mai a fine riga (a schermo); il testo scritto dall'utente resta com'e' (crudo) */
function nfEsc(s, crudo){ const e = (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); return crudo ? e : e.replace(/Io Futuro/g, 'Io\u00a0Futuro'); }
async function nfCarica(){
  if (NF.c) return NF.c;
  try{ const r = await fetch('content/io-futuro.json', { cache: 'no-cache' }); NF.c = await r.json(); }catch(_){ NF.c = null; }
  return NF.c;
}
function nfT(s, v){ return String(s || '').replace(/\{(\w+)\}/g, function(_, k){ return v && v[k] != null ? v[k] : ''; }); }

/* ---------------------------------------------------------------- quello che l'app sa gia' */
function nfSogno(){
  try{ if (typeof nvSogno === 'function'){ const s = nvSogno(); if (s) return s; } }catch(_){ }
  try{ const g = gnDati(); if (g && g.sogno) return String(g.sogno); }catch(_){ }
  return '';
}
function nfCategoria(sogno){
  const C = NF.c.categorie, t = ' ' + String(sogno || '').toLowerCase() + ' ';
  let best = 'generale', bestN = 0;
  Object.keys(C).forEach(function(k){
    const n = (C[k].parole || []).filter(function(p){ return t.indexOf(p) >= 0; }).length;
    if (n > bestN){ best = k; bestN = n; }
  });
  return best;
}
function nfBlocco(){
  try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : null; if (b && b.primario) return b; }catch(_){ }
  return null;
}
function nfNascita(){
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); if (u && /^\d{4}-\d{2}-\d{2}$/.test(u.birth || '')) return u.birth; }catch(_){ }
  try{ if (typeof scFuture === 'function'){ const f = scFuture(); if (f && /^\d{4}-\d{2}-\d{2}$/.test(f.birth || '')) return f.birth; } }catch(_){ }
  return '';
}
function nfSegno(iso){
  if (!iso) return '';
  const d = new Date(iso + 'T12:00:00'), m = d.getMonth() + 1, g = d.getDate();
  /* [mese, giorno in cui comincia il segno, segno]. 0.9.300: la tabella era sfasata di un segno (il 14 marzo dava Acquario). */
  const T = [[1, 20, 'Acquario'], [2, 19, 'Pesci'], [3, 21, 'Ariete'], [4, 20, 'Toro'], [5, 21, 'Gemelli'], [6, 21, 'Cancro'], [7, 23, 'Leone'], [8, 23, 'Vergine'], [9, 23, 'Bilancia'], [10, 23, 'Scorpione'], [11, 22, 'Sagittario'], [12, 22, 'Capricorno']];
  for (let i = 0; i < T.length; i++){ if (m === T[i][0]) return g < T[i][1] ? (i ? T[i - 1][2] : 'Capricorno') : T[i][2]; }
  return '';
}
/** Le risposte che il Genio ricava da solo, con la fonte. Chi le ha gia' cambiate tiene le sue. */
function nfDeduci(){
  const r = {}, f = {};
  const b = nfBlocco(), P = (b && b.P) || {};
  const forti = Object.keys(P).filter(function(k){ return P[k] >= 50; });
  if (b && b.primario && forti.indexOf(b.primario) < 0) forti.unshift(b.primario);
  /* le fatiche dal Sabotatore */
  const daBlocco = { dispersione: 'distratto', tempo: 'rimando', paura: 'fiducia', valore: 'fiducia', passato: 'rimugino', sguardi: 'fiducia', denaro: 'soldi', imparare: 'rimando' };
  const fat = []; forti.forEach(function(k){ const v = daBlocco[k]; if (v && fat.indexOf(v) < 0) fat.push(v); });
  if (fat.length){ r.fatiche = fat.slice(0, 3); f.fatiche = 'genio'; }
  /* cosa aiuta, dal blocco principale */
  const aiuta = { dispersione: 'passi', tempo: 'promemoria', paura: 'incoraggiamento', valore: 'progressi', passato: 'progressi', sguardi: 'conto', denaro: 'passi', imparare: 'passi' };
  if (b && aiuta[b.primario]){ r.aiuta = aiuta[b.primario]; f.aiuta = 'genio'; }
  /* dove ti senti indietro, dal sogno */
  const cat = nfCategoria(nfSogno());
  r.indietro = (NF.c.categorie[cat] || {}).indietro || 'abitudini'; f.indietro = 'genio';
  /* com'e' la tua vita adesso, dalla serie della partita */
  let serie = 0; try{ serie = (typeof mtState === 'function') ? (mtState().streak || 0) : 0; }catch(_){ }
  r.oggi = serie >= 5 ? 'progressi' : (b && (P.passato >= 60 || P.paura >= 60)) ? 'bloccato' : 'incostante'; f.oggi = 'genio';
  r.quanto = 'ogni_giorno'; f.quanto = 'genio';
  /* come si sente e cosa fa con facilita' l'Io Futuro: dal segno, se c'e' la data di nascita */
  const segno = nfSegno(nfNascita());
  if (segno){
    const Z = NF.c.zodiaco;
    Object.keys(Z).forEach(function(el){ if (Z[el].segni.indexOf(segno) >= 0){ r.sente = Z[el].sente; r.facile = Z[el].facile; f.sente = f.facile = 'segno:' + segno; } });
  }
  return { r: r, f: f };
}

/* ---------------------------------------------------------------- il motore: obiettivo -> identita' */
function nfScegli(l, seme){ return l[Math.abs(seme) % l.length]; }
function nfSeme(s){ let h = 0; String(s).split('').forEach(function(c){ h = (h * 31 + c.charCodeAt(0)) | 0; }); return h; }
/* 0.9.300, Andrea: "l'utente deve poter scegliere piu' opzioni E scrivere la sua risposta insieme" e "quando un utente
   scrive deve poter scrivere quanto vuole". Ogni risposta ora e' una lista: le chiavi delle opzioni scelte, piu' (in
   fondo) il testo scritto dall'utente, intero. I dati salvati prima (una stringa: una chiave o un testo; oppure la
   lista delle domande multiple) si leggono con le stesse funzioni, senza migrazione: niente si perde. */
function nfLista(v){
  if (Array.isArray(v)) return v.filter(function(x){ return x != null && String(x).trim() !== ''; }).map(String);
  return (v == null || String(v).trim() === '') ? [] : [String(v)];
}
function nfIsOp(d, x){ return !!d && d.op.some(function(o){ return o[0] === x; }); }
function nfScelteDi(r, k){ const d = nfDomanda(k); return nfLista(r[k]).filter(function(x){ return nfIsOp(d, x); }); }
function nfTestoDi(r, k){ const d = nfDomanda(k); return nfLista(r[k]).filter(function(x){ return !nfIsOp(d, x); }).join('\n'); }
function nfScelte(k){ return nfScelteDi(NF.r, k); }
function nfTesto(k){ return nfTestoDi(NF.r, k); }
/** La prima opzione scelta (per il motore a modelli, che parte da una chiave sola). */
function nfPrimaScelta(r, k){ return nfScelteDi(r, k)[0] || ''; }
/** Il testo di un'opzione, al femminile quando il genere scelto e' "f" e la domanda ha la sua forma. */
function nfEtichetta(d, key){
  const o = d && d.op.filter(function(x){ return x[0] === key; })[0];
  if (!o) return key || '';
  return (d.opF && d.opF[key] && nfGenere() === 'f') ? d.opF[key] : o[1];
}
function nfOpz(k, v){ return nfEtichetta(nfDomanda(k), v); }
/** Le scelte in una riga sola: "Nelle abitudini, nella salute". */
function nfScelteTxt(k, r){
  const d = nfDomanda(k);
  return nfScelteDi(r || NF.r, k).map(function(x, i){ const s = nfEtichetta(d, x); return i ? s.charAt(0).toLowerCase() + s.slice(1) : s; }).join(', ');
}
/** Le risposte in parole, per chi le legge da fuori (l'agente personale): scelte e testo, interi.
 *  0.9.307: le scelte messe in ordine dall'utente arrivano numerate, con la nota che la prima conta di piu'. */
function nfRisposteTesto(r, ord){
  const out = {}, D = (NF.c && NF.c.domanda) || {};
  Object.keys(r || {}).forEach(function(k){
    const d = nfDomanda(k); if (!d) return;
    const l = nfScelteDi(r, k), t = nfTestoDi(r, k);
    let sc = nfScelteTxt(k, r);
    if (ord && ord[k] && l.length >= 2) sc = l.map(function(x, i){ return (i + 1) + ') ' + nfEtichetta(d, x); }).join('; ') + ' (' + (D.ordine_agente || 'in ordine di importanza, la prima conta di più') + ')';
    out[k] = [sc, t].filter(Boolean).join('. ');
  });
  return out;
}
/** Il riassunto per l'agente (agente.js, agBrief): domanda e risposta, intere. Si scrive a ogni salvataggio, cosi'
 *  agBrief lo legge subito senza aspettare io-futuro.json. */
function nfPerAgenteTesto(){
  if (!NF.c) return '';
  const tx = nfRisposteTesto(NF.r, NF.ord), righe = [];
  Object.keys(tx).forEach(function(k){ const d = nfDomanda(k); if (d && tx[k]) righe.push('- ' + d.q + ' ' + tx[k] + (NF.ded[k] ? ' [dedotta dal Genio]' : '')); });
  return righe.length ? 'Io Futuro (risposte del livello "Il tuo Io Futuro ti sta chiamando"; quando le scelte sono numerate, la prima e\' quella che conta di piu\': e\' il collo di bottiglia da sbloccare per primo):\n' + righe.join('\n') : '';
}
function nfPerAgente(){ try{ return String(ifNuovoMe().perAgente || '').slice(0, 3000); }catch(_){ return ''; } }
/** La domanda (anche una spostata negli episodi) ha gia' una risposta salvata. */
function nfHaRisposto(k){ try{ return nfLista((ifNuovoMe().risposte || {})[k]).length > 0; }catch(_){ return false; } }
/** L'identita' a modelli: categoria del sogno x blocco del Sabotatore. variante 0..2 cambia il nucleo. */
function nfIdentitaModello(r, variante){
  const sogno = nfSogno(), cat = nfCategoria(sogno), C = NF.c.categorie[cat] || NF.c.categorie.generale;
  const b = nfBlocco(), B = (b && NF.c.blocchi[b.primario]) || NF.c.blocchi.dispersione;
  const v = variante || 0, seme = nfSeme(sogno + (b ? b.primario : ''));
  const core = C.core[(seme + v) % C.core.length];
  const antidoto = B.antidoto[(seme + v) % B.antidoto.length];
  const identity = 'Sono una persona che ' + core + ' e ' + antidoto + '.';
  const sente = NF.c.sente[nfPrimaScelta(r, 'sente')] || '';
  const traits = [C.tratti[(seme + v) % C.tratti.length], B.tratto, sente || C.tratti[(seme + v + 1) % C.tratti.length]];
  const facile = NF.c.facile[nfPrimaScelta(r, 'facile')];
  const azioni = [C.azioni[(seme + v) % C.azioni.length], B.azione, C.azioni[(seme + v + 1) % C.azioni.length]];
  const credenze = [B.credenza].concat(C.credenze);
  const nonPiu = [B.nonPiu];
  const daFatica = { distratto: 'Non apro più il telefono appena mi siedo a lavorare', rimando: 'Non rimando più la cosa che conta a domani', rimugino: 'Non giro più intorno alle cose: decido e provo', soldi: 'Non lascio più che l’ansia per i soldi decida per me', motivazione: 'Non aspetto più la voglia per cominciare', fiducia: 'Non parlo più male di me', sonno: 'Non tengo più il telefono a letto', solo: 'Non mi chiudo più quando sono giù' };
  nfScelteDi(r, 'fatiche').forEach(function(x){ if (daFatica[x] && nonPiu.indexOf(daFatica[x]) < 0) nonPiu.push(daFatica[x]); });
  const vals = { core: core, sogno: sogno || 'il mio sogno', tratto1: traits[0], tratto2: traits[1], tratto3: traits[2], credenza1: credenze[0], credenza2: credenze[1] || credenze[0], credenza3: credenze[2] || credenze[0], prima: B.prima, ora: B.ora, nonPiu: nonPiu[0] };
  const affirmations = NF.c.affermazioni.filter(function(a){ return sogno || a.indexOf('{sogno}') < 0; }).map(function(a){ return nfT(a, vals).replace(/\.\.$/, '.'); });
  return {
    identity_statement: identity,
    traits: traits,
    old_self_line: 'Prima dicevo: "' + B.prima + '"',
    new_self_line: 'Ora dico: "' + B.ora + '"',
    vote_actions: azioni,
    affirmations: affirmations,
    credenze: credenze,
    nonPiu: nonPiu,
    facile: facile || '',
    fonte: 'modello', variante: v, categoria: cat, blocco: b ? b.primario : ''
  };
}
/** Il JSON dell'agente e' valido solo se ha tutto, al presente, senza imperativi. */
function nfValida(j){
  if (!j || typeof j !== 'object') return false;
  if (typeof j.identity_statement !== 'string' || !/^Sono una persona che/i.test(j.identity_statement)) return false;
  const liste = ['traits', 'vote_actions', 'affirmations'];
  if (liste.some(function(k){ return !Array.isArray(j[k]) || !j[k].length; })) return false;
  const tutto = JSON.stringify(j).toLowerCase();
  if (/\bdevi\b|\bdovresti\b|\bbisogna\b|è necessario|\bai\b/.test(tutto)) return false;
  return true;
}
/** PREMIUM: l'agente personale scrive l'identita'. Otto secondi, poi i modelli. */
async function nfIdentitaAgente(r){
  let premium = false; try{ premium = typeof sdPremium === 'function' && sdPremium(); }catch(_){ }
  if (!premium || typeof agApi !== 'function') return null;
  try{
    const b = nfBlocco();
    const j = await Promise.race([
      agApi('POST', '/api/focuslock/agent/identita', { sogno: nfSogno(), categoria: nfCategoria(nfSogno()), blocco: b ? b.primario : '', risposte: r, risposte_testo: nfRisposteTesto(r, NF.ord), ordinate: NF.ord }),
      new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, 8000); })
    ]);
    const x = j && (j.identita || j);
    if (nfValida(x)){ x.fonte = 'agente'; x.credenze = x.credenze || []; x.nonPiu = x.nonPiu || []; return x; }
  }catch(_){ }
  return null;
}

/* ---------------------------------------------------------------- la pagina */
registerScreen('s-nuovome', '<div class="nf-top"><button class="iconbtn" onclick="nfIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg></button><div class="nf-bar"><i id="nfBar"></i></div></div><div id="nfBody" class="nf-body"></div>', { back: function(){ setTimeout(nfIndietro, 0); return null; } });

async function nfApri(ritorno){
  if (!(await nfCarica())){ if (typeof toast === 'function') toast('Non riesco ad aprire il livello: riprova'); return; }
  const prima = ifNuovoMe();
  const d = nfDeduci();
  NF.r = Object.assign({}, d.r, prima.risposte || {});
  NF.ded = Object.assign({}, d.f);
  Object.keys(prima.risposte || {}).forEach(function(k){ if (prima.dedotte && !prima.dedotte[k]) delete NF.ded[k]; });
  NF.id = prima.identita || null; NF.alt = [];
  NF.ord = Object.assign({}, prima.ordinate || {}); NF.solo = null;
  /* il genere scelto in "Chi saro'" vale come risposta: la domanda "chi vedi" non si ripete */
  if (!nfLista(NF.r.genere).length && nfGenere()) NF.r.genere = [nfGenere()];
  NF.qs = NF.c.domande.filter(function(d){ return !(d.k === 'genere' && nfLista(NF.r.genere).length); });
  NF.ritorno = ritorno || '';
  NF.fase = prima.confermata && !ritorno ? 'storia' : 'intro'; NF.i = 0; NF.edit = '';
  goId('s-nuovome'); nfPaint();
}
/** 0.9.307: UNA domanda spostata in un episodio, con lo stesso aspetto (e "Lo scrivo io"). fatto(true) quando ha
 *  risposto, fatto(false) se torna indietro. Le altre risposte restano come sono. */
async function nfDomandaEpisodio(k, fatto){
  if (!(await nfCarica()) || !nfDomanda(k)){ fatto(false); return; }
  const prima = ifNuovoMe();
  NF.r = Object.assign({}, prima.risposte || {}); NF.ded = Object.assign({}, prima.dedotte || {});
  NF.ord = Object.assign({}, prima.ordinate || {}); NF.id = prima.identita || null; NF.alt = [];
  NF.solo = { k: k, fatto: fatto }; NF.edit = ''; NF.ritorno = ''; NF.fase = 'domanda'; NF.i = 0;
  NF.qs = NF.c.domande.slice();
  goId('s-nuovome'); nfPaint();
  try{ window.scrollTo(0, 0); const sc = document.getElementById('s-nuovome'); if (sc) sc.scrollTop = 0; }catch(_){ }
}
/** La domanda sullo schermo: quella che si sta cambiando, quella dell'episodio, o quella della chiamata. */
function nfDomCorrente(){ return NF.edit ? nfDomanda(NF.edit) : (NF.solo ? nfDomanda(NF.solo.k) : NF.qs[NF.i]); }
function nfIndietro(){
  if (NF.fase === 'ordina'){ NF.fase = NF.edit ? 'storia' : 'domanda'; nfPaint(); return; }
  if (NF.edit){ NF.edit = ''; NF.fase = 'storia'; nfPaint(); return; }
  if (NF.solo){ const so = NF.solo; NF.solo = null; NF.fase = 'intro'; nfSalvaBozza(); so.fatto(false); return; }
  if (NF.fase === 'domanda' && NF.i > 0){ NF.i--; nfPaint(); return; }
  if (NF.fase === 'ritratto'){ NF.fase = 'volto'; nfPaint(); return; }
  const ordine = ['intro', 'domanda', 'storia', 'rivela', 'volto', 'voce', 'regole', 'fine'];
  const k = ordine.indexOf(NF.fase);
  if (k > 1){ NF.fase = ordine[k - 1]; if (NF.fase === 'domanda') NF.i = NF.qs.length - 1; nfPaint(); return; }
  if (NF.ritorno === 's-identita' && typeof ifIdentitaApri === 'function'){ ifIdentitaApri(); return; }
  goId('s-home');
}
function nfBarra(){
  const b = document.getElementById('nfBar'); if (!b) return;
  /* la domanda di un episodio: meta' barra, piena quando si mettono in ordine le risposte */
  if (NF.solo){ b.style.width = (NF.fase === 'ordina' ? 100 : 50) + '%'; return; }
  const q = NF.qs.length, tot = q + 6;
  const pos = { intro: 0, domanda: 1 + NF.i, ordina: 1 + NF.i, storia: q + 1, rivela: q + 2, volto: q + 3, ritratto: q + 3, voce: q + 4, regole: q + 5, fine: tot }[NF.fase] || 0;
  b.style.width = Math.round(pos / tot * 100) + '%';
}
function nfDomanda(k){ return NF.c.domande.concat(NF.c.dedotte, NF.c.domande_episodi || []).filter(function(x){ return x.k === k; })[0]; }
/** Una domanda che arriva in un episodio (non nella chiamata). */
function nfDaEpisodio(k){ return (NF.c.domande_episodi || []).some(function(x){ return x.k === k; }); }

function nfPaint(){
  const h = document.getElementById('nfBody'); if (!h || !NF.c) return;
  nfBarra();
  const C = NF.c;
  if (NF.fase === 'intro'){
    h.innerHTML = '<div class="nf-intro">' + nfSagoma('') + '<small class="nf-kick">' + nfEsc(C.intro.kick) + '</small>'
      + '<h1>' + nfEsc(C.intro.titolo) + '</h1><p>' + nfEsc(nfT(C.intro.sotto, { n: (C.intro.numeri || [])[NF.qs.length - 1] || String(NF.qs.length) })) + '</p><small class="nf-dur">' + nfEsc(C.intro.durata) + '</small>'
      + '<button type="button" class="nf-cta" onclick="NF.fase=\'domanda\';NF.i=0;nfPaint()">' + nfEsc(C.intro.cta) + '</button></div>';
    return;
  }
  if (NF.fase === 'ordina'){ h.innerHTML = nfOrdinaHtml(); nfOrdAggancia(); return; }
  if (NF.fase === 'domanda' || NF.edit){
    /* 0.9.300: piu' scelte e il testo insieme; niente "Scegli una risposta"; la nota (a cosa serve) in fondo, piccola */
    const d = nfDomCorrente();
    const D = C.domanda || {};
    const sc = nfScelte(d.k), testo = nfTesto(d.k);
    const fonte = NF.ded[d.k] ? (String(NF.ded[d.k]).indexOf('segno:') === 0 ? C.storia.dal_segno + ' (' + NF.ded[d.k].slice(6) + ')' : C.storia.dal_genio) : '';
    h.innerHTML = '<div class="nf-q">'
      + '<h2>' + nfEsc(d.q) + '</h2>'
      + (fonte ? '<p class="nf-fonte"><span class="nf-tag">' + nfEsc(fonte) + '</span></p>' : '')
      + '<div class="nf-ops">' + d.op.map(function(o){
          const on = sc.indexOf(o[0]) >= 0;
          return '<button type="button" class="nf-op' + (on ? ' on' : '') + '" data-k="' + nfEsc(o[0]) + '" aria-pressed="' + on + '" onclick="nfScelta(\'' + d.k + '\',\'' + o[0] + '\')">'
            + (o[2] ? '<span class="nf-emo" aria-hidden="true">' + o[2] + '</span>' : (d.sagome ? '<span class="nf-emo nf-emo-sag" aria-hidden="true">' + nfSagMini(o[0]) + '</span>' : ''))
            + '<span class="nf-op-t">' + nfEsc(nfEtichetta(d, o[0])) + '</span><i class="nf-spunta" aria-hidden="true">' + NF_SPUNTA_OP + '</i></button>';
        }).join('') + '</div>'
      + '<div class="nf-mio"><label class="nf-mio-t" for="nfLibero">' + nfEsc(D.scrivo || 'Lo scrivo io') + '</label>'
      +   '<textarea class="nf-libero" id="nfLibero" rows="3" placeholder="' + nfEsc(D.segnaposto || 'Scrivi la tua risposta') + '" oninput="nfLibero(\'' + d.k + '\')" onblur="nfLibero(\'' + d.k + '\')">' + nfEsc(testo, true) + '</textarea></div>'
      + '<button type="button" class="nf-cta" onclick="nfLibero(\'' + d.k + '\');nfAvanti()">' + nfEsc(NF.edit && !(nfScelte(d.k).length >= 3 && !d.unica) ? (D.salva || 'Salva') : (D.avanti || 'Avanti')) + '</button>'
      + (d.nota ? '<p class="nf-nota">' + nfEsc(d.nota) + '</p>' : '')
      + '</div>';
    nfAltezza(document.getElementById('nfLibero'));
    return;
  }
  if (NF.fase === 'storia'){
    /* 0.9.300: titoli di sezione veri (blu, grandi, con la loro emoji); risposte intere, a tre righe con i puntini,
       che si aprono al tocco; con piu' scelte si vedono tutte, e il testo scritto sotto. */
    const S = C.storia;
    h.innerHTML = '<div class="nf-storia"><h2 class="nf-h">' + nfEsc(S.titolo) + '</h2><p class="nf-sub">' + nfEsc(S.sotto) + '</p>'
      + S.gruppi.map(function(g){
          return '<section class="nf-sez"><h3 class="nf-sez-t">' + (g[2] ? '<span aria-hidden="true">' + g[2] + '</span>' : '') + nfEsc(g[0]) + '</h3>' + g[1].map(function(k){
            const d = nfDomanda(k); if (!d) return '';
            if (nfDaEpisodio(k) && !nfLista(NF.r[k]).length) return '';
            const scTxt = nfScelteTxt(k), t = nfTesto(k);
            const ded = NF.ded[k] ? '<span class="nf-tag">' + nfEsc(String(NF.ded[k]).indexOf('segno:') === 0 ? S.dal_segno : S.dal_genio) + '</span>' : '';
            return '<div class="nf-riga" role="button" tabindex="0" onclick="nfModifica(\'' + k + '\')"><span class="nf-riga-c"><small>' + nfEsc(d.q) + '</small>'
              + (scTxt ? '<b class="nf-ris" onclick="nfEspandi(event,this)">' + nfEsc(scTxt) + '</b>' : '')
              + (t ? '<b class="nf-ris nf-ris-mio" onclick="nfEspandi(event,this)">' + nfEsc(t) + '</b>' : '')
              + (!scTxt && !t ? '<b class="nf-ris vuota">' + nfEsc(S.vuota || 'Tocca per rispondere') + '</b>' : '')
              + '<button type="button" class="nf-leggi" hidden onclick="nfEspandi(event,this)">' + nfEsc(S.leggi_tutto || 'Leggi tutto') + '</button>'
              + ded + '</span><i class="nf-chev" aria-hidden="true">' + NF_CHEV + '</i></div>';
          }).join('') + '</section>';
        }).join('')
      + '<button type="button" class="nf-cta" onclick="nfVaiRivela()">' + nfEsc(S.cta) + '</button></div>';
    nfSegnaTronche();
    return;
  }
  if (NF.fase === 'rivela'){
    const R = C.rivela, id = NF.id; if (!id){ h.innerHTML = '<div class="nf-attesa">' + nfSagoma('pieno') + '<p>Il tuo Io Futuro sta ricordando chi è diventato…</p></div>'; return; }
    h.innerHTML = nfDiarioFuturoHtml(R, id);
    nfDiarioFuturoSuono();
    return;
  }
  if (NF.fase === 'ritocca'){
    const R = C.rivela;
    h.innerHTML = '<div class="nf-q"><h2>' + nfEsc(R.ritocca_t) + '</h2><p class="nf-sub">' + nfEsc(R.ritocca_sotto) + '</p><div class="nf-ops">'
      + NF.alt.map(function(a, i){ return '<button type="button" class="nf-op alta' + (NF.id && a.identity_statement === NF.id.identity_statement ? ' on' : '') + '" onclick="nfAltScegli(' + i + ')">' + nfEsc(a.identity_statement) + '</button>'; }).join('')
      + '</div></div>';
    return;
  }
  if (NF.fase === 'volto'){
    const S = C.selfie, im = nfImmagine(), RT = C.ritratto || {};
    /* l'esito vero dell'ultimo tentativo: niente frasi inventate, solo quello che e' successo */
    const avviso = NF.rtAvviso === 'finiti' ? RT.finiti : (NF.rtAvviso === 'non_ora' ? RT.non_ora : '');
    h.innerHTML = '<div class="nf-intro">' + (im ? nfVolto('grande') : nfSagoma('')) + '<h1>' + nfEsc(S.titolo) + '</h1><p>' + nfEsc(S.sotto) + '</p>'
      + (avviso ? '<p class="nf-rt-avviso">' + nfEsc(avviso) + '</p>' : '')
      + '<button type="button" class="nf-cta" onclick="nfSelfie(true)">' + nfEsc(S.scatta) + '</button>'
      + '<button type="button" class="nf-sec" onclick="nfSelfie(false)">' + nfEsc(S.scegli) + '</button>'
      + '<button type="button" class="nf-sec" onclick="NF.fase=\'voce\';nfPaint()">' + nfEsc(im ? 'Avanti' : S.senza) + '</button></div>';
    return;
  }
  if (NF.fase === 'ritratto'){ nfRitrattoPaint(); return; }
  if (NF.fase === 'voce'){
    const V = C.voce;
    h.innerHTML = '<div class="nf-intro">' + nfVolto('grande') + '<h1>' + nfEsc(V.titolo) + '</h1><p>' + nfEsc(V.sotto) + '</p>'
      + '<button type="button" class="nf-cta" onclick="nfVoce()">🎙️ ' + nfEsc(V.registra) + '</button>'
      + '<button type="button" class="nf-sec" onclick="NF.fase=\'regole\';nfPaint()">' + nfEsc(V.dopo) + '</button></div>';
    return;
  }
  if (NF.fase === 'regole'){ h.innerHTML = nfRegoleHtml(); return; }
  if (NF.fase === 'fine'){
    const F = C.fine, N = C.notion;
    h.innerHTML = '<div class="nf-intro">' + nfVolto('grande') + '<h1>' + nfEsc(F.titolo) + '</h1><p>' + nfEsc(F.sotto) + '</p>'
      + '<button type="button" class="nf-notion" onclick="nfNotion()"><span>🪞</span><div><b>' + nfEsc(N.titolo) + '</b><small>' + nfEsc(N.sotto) + '</small></div><i class="nf-chev" aria-hidden="true">' + NF_CHEV + '</i></button>'
      + '<button type="button" class="nf-cta" onclick="nfVaiPartita()">' + nfEsc(F.cta) + '</button></div>';
  }
}
const NF_CHEV = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>';
const NF_SPUNTA = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#3F9FF4" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg> ';
const NF_SPUNTA_OP = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
/** La casella del testo cresce con quello che si scrive: niente barra di scorrimento dentro, niente limite. */
function nfAltezza(a){
  if (!a) return;
  try{ a.style.height = 'auto'; a.style.height = Math.max(a.scrollHeight + 2, 86) + 'px'; }catch(_){ }
}
/** Nel riepilogo: dove la risposta supera le tre righe compare "Leggi tutto". */
function nfSegnaTronche(){
  const fai = function(){
    document.querySelectorAll('#nfBody .nf-riga').forEach(function(r){
      const tronca = [].some.call(r.querySelectorAll('.nf-ris'), function(b){ return b.scrollHeight > b.clientHeight + 2; });
      r.classList.toggle('tronca', tronca);
      const l = r.querySelector('.nf-leggi'); if (l) l.hidden = !tronca;
    });
  };
  fai();
  try{ if (document.fonts && document.fonts.ready) document.fonts.ready.then(fai); }catch(_){ }
}
/** Tocco sulla risposta tagliata (o su "Leggi tutto"): si apre intera. Su quella gia' intera: si cambia. */
function nfEspandi(e, el){
  const r = el && el.closest('.nf-riga'); if (!r) return;
  const bottone = el.classList.contains('nf-leggi');
  if (!bottone && (!r.classList.contains('tronca') || r.classList.contains('aperta'))) return; /* passa alla riga: si cambia */
  if (e) e.stopPropagation();
  const aperta = !r.classList.contains('aperta');
  r.classList.toggle('aperta', aperta);
  const l = r.querySelector('.nf-leggi'); if (l) l.textContent = aperta ? 'Riduci' : ((NF.c.storia || {}).leggi_tutto || 'Leggi tutto');
}
/* 0.9.307, Andrea: "sembra Slenderman". La sagoma ora e' copiata dal vero da quella di My Future Self: proporzioni
   umane (testa circa un ottavo dell'altezza, collo corto, trapezio, braccia staccate dal busto con le mani e il pollice,
   ginocchia, polpacci e piedi), il blu che scende da chiaro in alto a scuro in basso, un ovale di luce a terra.
   Cambia col genere: uomo (spalle larghe, vita dritta), donna (spalle piu' strette, vita segnata, fianchi, capelli
   lunghi), neutra se il genere non c'e'. I tracciati si generano qui: meta' destra punto per punto, la sinistra a specchio.
   cls '' = piena; 'carica' = chiara, si riempie di blu dal basso (il ritratto in arrivo). */
/* La sagoma dell'Io Futuro (0.9.307): meta' destra punto per punto, la sinistra a specchio, curve morbide
   (Catmull-Rom -> Bezier). 'c' = spigolo (ascella, cavallo, punta delle dita). viewBox 0 0 140 310, centro x=70. */
const NF_SAG_PUNTI = {
  /* uomo: spalle larghe, vita dritta */
  m: [[0,3.6],[5.6,4],[10.4,6.4],[13.6,10.8],[15.3,16.8],[15.9,23.5],[15.4,29.5],[13.8,34.4],[11.6,38.4],[10.6,41.8],[10.7,46],[13.6,49.6],[19.4,52.4],[26.4,54.8],[33.2,57.6],[37.8,60.8],[40.6,65.6],[42,72],[42.8,80],[43.8,88],[45,96],[46.6,104],[48,112],[49,121],[49.4,130],[49.4,139],[49.6,147],[50.2,154],[50.4,161],[49.8,167.5],[48.2,173.4],[45.6,177.8],[42.4,178.8,'c'],[40,176.4],[39.4,172],[39.2,168.4,'c'],[37.2,169.6],[35.6,168],[35.4,164],[36.6,159.4],[38.2,154.6],[38.8,148],[38,139],[36.6,130],[35,121],[33.4,112],[31.8,104],[30.2,97.5,'c'],[27.6,102],[27.4,110],[27.6,120],[28.2,130],[29,139],[30,148],[31.2,156],[31.8,164],[31.6,173],[31.2,182],[30.6,193],[29.8,205],[30,217],[31.2,229],[31.6,240],[30.6,250],[28.8,259],[27.2,268],[26.6,277],[26.6,285],[28,291],[31.4,295.6],[34.8,299.2],[34.6,303.4,'c'],[26,304.4],[21.4,303.6],[19.8,299.6],[16.4,295.4],[15.4,290],[15.2,282],[15.8,272],[14.6,262],[12.4,252],[11.2,243],[10.4,232],[9.6,220],[7.4,208],[5.2,196],[3.4,186],[1.6,177.5],[0,170.5,'c']],
  /* donna: spalle piu' strette, vita segnata, fianchi larghi, capelli lunghi sulle spalle */
  f: [[0,3],[7.2,3.6],[12.4,6.6],[15.6,11.6],[17.2,18.5],[17.6,26],[17.6,34],[17.8,42],[18.4,50],[19.4,57],[20.6,62.4,'c'],[25.4,62.6],[30.4,64],[34,66.8],[36,71.5],[37.2,78],[38,86],[38.8,94],[40,102],[41.4,110],[42.8,119],[43.8,128],[44.4,137],[44.8,145],[45.4,152],[45.6,158.6],[45,164.2],[43.6,169],[41.4,172.4],[38.8,173.2,'c'],[37,171],[36.6,167.4],[36.6,164.4,'c'],[35,165],[33.8,163.2],[34,159.4],[35.4,155],[36,149],[35,141],[33.4,132],[31.6,123],[29.8,114],[28.2,105],[26.8,97.5,'c'],[25.4,101],[25.6,107],[24.8,113],[23.2,120],[22.8,127],[24,135],[27,143],[30.4,151],[32.4,159],[33,166],[32.6,175],[31.6,186],[30.2,197],[28.6,208],[27.6,219],[28,229],[28.4,239],[27.2,250],[25.2,260],[23.4,270],[22.6,279],[22.6,287],[23.8,292.4],[26.4,296.8],[29,300.6],[28.4,303.8,'c'],[21.4,304.5],[18.4,303.4],[17.2,299.4],[14.6,295],[13.8,290],[13.6,282],[13.8,272],[12.6,262],[10.6,252],[9.6,243],[8.8,232],[7.8,220],[6,208],[4.2,196],[2.6,186],[1.3,178],[0,171.5,'c']],
  /* neutra: fra le due, senza capelli lunghi */
  n: [[0,3.6],[5.6,4],[10.2,6.4],[13.4,10.8],[15,16.8],[15.6,23.5],[15.1,29.5],[13.6,34.4],[11.4,38.4],[10.2,41.8],[10.1,46],[12.8,49.6],[18.2,52.6],[24.8,55.2],[31,58],[35.2,61.2],[37.8,66],[39.2,72.4],[40,80],[41,88],[42.2,96],[43.6,104],[45,112],[46,121],[46.4,130],[46.4,139],[46.6,147],[47.2,154],[47.4,161],[46.8,167.4],[45.2,173],[42.8,177],[39.8,177.8,'c'],[37.6,175.6],[37,171.6],[36.8,168,'c'],[35,169],[33.6,167.4],[33.6,163.6],[34.8,159],[36.4,154.4],[37,148],[36.2,139.5],[34.8,131],[33.2,122],[31.6,113],[30.2,105],[28.6,97.8,'c'],[26.6,102],[26.4,110],[25.8,118],[25.4,126],[26,134],[27.6,142],[29.4,150],[31,158],[31.6,165],[31.4,174],[30.8,184],[30,195],[29,206],[28.8,217],[29.8,228],[30.2,239],[29.2,250],[27.4,259.5],[25.8,268.5],[25,277.5],[25,285.6],[26.4,291.2],[29.6,296],[32.6,299.6],[32.2,303.6,'c'],[24.4,304.4],[20.4,303.6],[19,299.4],[15.8,295.2],[14.8,290],[14.6,282],[15,272],[13.8,262],[11.8,252],[10.6,243],[9.8,232],[9,220],[7,208],[4.9,196],[3.2,186],[1.5,177.8],[0,171,'c']]
};
function nfSagPath(gen){
  const R = NF_SAG_PUNTI[gen] || NF_SAG_PUNTI.n, cx = 70;
  /* il giro completo: la meta' destra dall'alto al cavallo, poi la sinistra a specchio risalendo */
  const P = R.map(function(p){ return { x: cx + p[0], y: p[1], c: !!p[2] }; });
  for (let i = R.length - 2; i >= 1; i--) P.push({ x: cx - R[i][0], y: R[i][1], c: !!R[i][2] });
  const n = P.length, f = function(v){ return Math.round(v * 100) / 100; };
  const tg = function(i){
    const p = P[i]; if (p.c) return { x: 0, y: 0 };
    const a = P[(i - 1 + n) % n], b = P[(i + 1) % n];
    return { x: (b.x - a.x) / 6, y: (b.y - a.y) / 6 };
  };
  let d = 'M' + f(P[0].x) + ' ' + f(P[0].y);
  for (let i = 0; i < n; i++){
    const a = P[i], b = P[(i + 1) % n], ta = tg(i), tb = tg((i + 1) % n);
    d += 'C' + f(a.x + ta.x) + ' ' + f(a.y + ta.y) + ' ' + f(b.x - tb.x) + ' ' + f(b.y - tb.y) + ' ' + f(b.x) + ' ' + f(b.y);
  }
  return d + 'Z';
}
const NF_SAG_D = {};
function nfSagD(g){ g = (g === 'm' || g === 'f') ? g : 'n'; return NF_SAG_D[g] || (NF_SAG_D[g] = nfSagPath(g)); }
let NF_SAG_N = 0;
function nfSagoma(cls){
  const n = ++NF_SAG_N, carica = cls === 'carica', d = nfSagD(nfGenere());
  return '<div class="nf-sagoma ' + (cls || '') + '"' + (carica ? ' id="nfSag"' : '') + '>'
    + '<svg viewBox="0 0 140 310" aria-hidden="true"><defs>'
    +   '<linearGradient id="nfSgP' + n + '" x1="0" y1="0" x2="0" y2="1"><stop class="nf-sg-0" offset="0"/><stop class="nf-sg-1" offset=".2"/><stop class="nf-sg-2" offset=".58"/><stop class="nf-sg-3" offset="1"/></linearGradient>'
    +   '<radialGradient id="nfSgO' + n + '" cx=".5" cy=".5" r=".5"><stop class="nf-sg-t0" offset="0"/><stop class="nf-sg-t1" offset="1"/></radialGradient>'
    +   '<radialGradient id="nfSgL' + n + '" cx=".5" cy=".3" r=".42"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>'
    +   '<clipPath id="nfSgC' + n + '"><path d="' + d + '"/></clipPath></defs>'
    +   '<ellipse class="nf-sag-terra" cx="70" cy="302" rx="64" ry="11" fill="url(#nfSgO' + n + ')"/>'
    +   '<ellipse class="nf-sag-anello" cx="70" cy="301" rx="50" ry="7.5"/>'
    +   '<path class="nf-sag-base" d="' + d + '"' + (carica ? '' : ' fill="url(#nfSgP' + n + ')"') + '/>'
    +   '<g clip-path="url(#nfSgC' + n + ')">'
    +     (carica ? '<rect class="nf-sag-pieno" x="0" y="306" width="140" height="310" fill="url(#nfSgP' + n + ')"/>'
    +       '<g class="nf-sag-scan" transform="translate(0 306)"><rect y="-5" width="140" height="1.6"/><rect y="-1.6" width="140" height="2.4"/><rect y="2.4" width="140" height="1"/></g>' : '')
    +     '<rect class="nf-sag-luce" x="0" y="0" width="140" height="310" fill="url(#nfSgL' + n + ')"/>'
    +   '</g></svg><div class="nf-sag-foto" aria-hidden="true"></div></div>';
}
/** La sagoma piccola, per le risposte "Un uomo" / "Una donna". */
function nfSagMini(g){ return '<svg viewBox="0 0 140 310" width="20" height="44"><path d="' + nfSagD(g) + '" fill="currentColor"/></svg>'; }
function nfImmagine(){ try{ return localStorage.getItem('fl_if_img') || localStorage.getItem('fl_avatar_img') || ''; }catch(_){ return ''; } }
function nfVolto(cls){
  const im = nfImmagine();
  return im ? '<div class="nf-volto ' + cls + '" style="background-image:url(\'' + String(im).replace(/'/g, '') + '\')"></div>' : '<div class="nf-volto vuoto ' + cls + '">🌅</div>';
}
function nfGenere(){
  try{ const g = (typeof ifIdentita === 'function' ? ifIdentita().genere : '') || ''; if (g) return g; }catch(_){ }
  /* la risposta a "chi vedi" nella chiamata (anche prima di salvarla) */
  try{ const l = nfLista((NF.r && NF.r.genere) || (ifNuovoMe().risposte || {}).genere); if (l.indexOf('f') >= 0) return 'f'; if (l.indexOf('m') >= 0) return 'm'; }catch(_){ }
  return '';
}
function nfDataArrivo(){
  try{ const a = (typeof etaArrivo === 'function') ? etaArrivo() : null; if (a && a.at && isFinite(a.at)){ const d = new Date(a.at); return d.getDate() + ' ' + ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()] + ' ' + d.getFullYear(); } }catch(_){ }
  return '';
}

/* ---------------------------------------------------------------- la pagina dal futuro (0.9.308)
   Andrea (707.jpg): il testo attaccato alla foto, un muro di frasi, "Ecco chi sono diventato" in un
   pannello blu. Adesso la rivelazione e' UNA PAGINA DI DIARIO scritta a mano dal giorno d'arrivo: lo
   stesso oggetto del diario di viaggio del profilo (diario.js, il taccuino di Nathan Drake), carta
   ingiallita con le righe e i bordi consumati, la foto con la graffetta, la data in alto, frasi corte
   che vanno a capo come in una lettera, la firma "Tu, dal ...". La pagina si apre girando sul bordo
   sinistro e le righe compaiono come inchiostro; un tocco sulla pagina mostra subito tutto.
   Compare SOLO qui: non si salva da nessuna parte e non entra nel diario sfogliabile.
   Il font a mano (Caveat, SIL OFL 1.1) sta dentro l'app: www/fonts/caveat (licenza in OFL.txt). */
const NF_DF_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
function nfDataArrivoMs(){ try{ const a = (typeof etaArrivo === 'function') ? etaArrivo() : null; if (a && a.at && isFinite(a.at)) return a.at; }catch(_){ } return 0; }
/** La frase fra virgolette di "Prima dicevo: ..." / "Ora dico: ...", senza le virgolette. */
function nfDfCitazione(s){ return String(s || '').replace(/^(Prima dicevo|Ora dico)\s*:\s*/i, '').replace(/^["“«]\s*|\s*["”»]\s*\.?$/g, '').trim(); }
/** Il tratto come lo direbbe un'altra persona: senza il punto finale (le virgolette lo chiudono). */
function nfDfTratto(s){ return String(s || '').trim().replace(/[.;]+$/, ''); }
const NF_DF_GRAFFETTA = '<svg class="nf-df-clip" viewBox="0 0 26 66" aria-hidden="true"><path d="M9 22v28a5.5 5.5 0 0 0 11 0V13a8.5 8.5 0 0 0-17 0v35" fill="none" stroke="#7d8793" stroke-width="3" stroke-linecap="round"/><path d="M9 22v28a5.5 5.5 0 0 0 11 0V13a8.5 8.5 0 0 0-17 0v35" fill="none" stroke="#dfe4ea" stroke-width="1.1" stroke-linecap="round" transform="translate(-.6 -.6)"/></svg>';
function nfDiarioFuturoHtml(R, id){
  const ms = nfDataArrivoMs(), data = nfDataArrivo();
  const giorno = ms ? NF_DF_GIORNI[new Date(ms).getDay()] : '';
  const im = nfImmagine(), sogno = nfSogno();
  const prima = nfDfCitazione(id.old_self_line), ora = nfDfCitazione(id.new_self_line);
  const tratti = (id.traits || []).map(nfDfTratto).filter(Boolean).slice(0, 3);
  let n = 0;
  const riga = function(html, cls){ n++; return '<p class="nf-df-r' + (cls ? ' ' + cls : '') + '" style="--i:' + n + '">' + html + '</p>'; };
  let pag = '';
  if (im) pag += '<figure class="nf-df-foto">' + NF_DF_GRAFFETTA + '<span class="nf-df-img" style="background-image:url(\'' + String(im).replace(/'/g, '') + '\')"></span></figure>';
  if (data) pag += '<p class="nf-df-data">' + nfEsc((giorno ? giorno + ' ' : '') + data) + '</p>';
  pag += riga(nfEsc(R.ehi), 'nf-df-ehi');
  if (sogno) pag += riga(nfEsc(nfT(R.fatto, { sogno: sogno })));
  pag += riga(nfEsc(R.svolta) + '<br>' + nfEsc(R.svolta_2));
  /* la frase vecchia barrata a penna, quella nuova ripassata: si capisce senza leggere tutto */
  if (prima && ora){
    pag += riga(nfEsc(R.smesso), 'nf-df-attacco') + riga('<s class="nf-df-vecchia">"' + nfEsc(prima) + '"</s>', 'nf-df-stretto');
    pag += riga(nfEsc(R.cominciato), 'nf-df-attacco') + riga('<b class="nf-df-nuova">"' + nfEsc(ora) + '"</b>', 'nf-df-stretto');
    pag += riga(nfEsc(R.da_li));
  }
  pag += riga(nfEsc(R.guardami), 'nf-df-calda');
  pag += riga(nfEsc(id.identity_statement), 'nf-df-id');
  if (tratti.length){
    n++;
    pag += '<div class="nf-df-r nf-df-strappo" style="--i:' + n + '"><i class="nf-df-scotch" aria-hidden="true"></i><small>' + nfEsc(R.dicono) + '</small>'
      + tratti.map(function(t){ return '<p>"' + nfEsc(t) + '"</p>'; }).join('') + '</div>';
  }
  pag += riga(nfEsc(data ? nfT(R.firma, { data: data }) : R.firma_senza_data), 'nf-df-firma');
  return '<div class="nf-df">'
    + '<div class="nf-df-scena"><article class="nf-df-pag" aria-label="' + nfEsc(R.pagina || '') + '" onclick="nfDfSubito(this)">' + pag + '</article></div>'
    + '<div class="nf-df-btn" style="--i:' + (n + 1) + '"><button type="button" class="nf-cta" onclick="nfConferma()">' + nfEsc(R.si) + '</button><button type="button" class="nf-sec" onclick="nfRitocca()">' + nfEsc(R.ritocca) + '</button></div>'
    + '</div>';
}
/** I bordi consumati della pagina: un poligono che morde i quattro lati di 0-3 px, sempre uguale
 *  (seme fisso), con gli angoli appena smussati. */
function nfDfBordo(){
  let s = 7;
  const r = function(){ s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const p = [];
  const passi = 22;
  for (let i = 0; i <= passi; i++) p.push((i * 100 / passi).toFixed(2) + '% ' + (r() * 3).toFixed(1) + 'px');
  for (let i = 1; i <= passi; i++) p.push('calc(100% - ' + (r() * 3).toFixed(1) + 'px) ' + (i * 100 / passi).toFixed(2) + '%');
  for (let i = passi - 1; i >= 0; i--) p.push((i * 100 / passi).toFixed(2) + '% calc(100% - ' + (r() * 3).toFixed(1) + 'px)');
  for (let i = passi - 1; i >= 1; i--) p.push((r() * 2.5).toFixed(1) + 'px ' + (i * 100 / passi).toFixed(2) + '%');
  return 'polygon(' + p.join(',') + ')';
}
/** Un tocco sulla pagina: niente attesa, si legge tutto subito. */
function nfDfSubito(el){ const d = el && el.closest('.nf-df'); if (d) d.classList.add('subito'); }
/** Il fruscio della carta quando la pagina si apre. Il 30/10 l'app non ha ancora un suono di carta
 *  (www/audio/sfx ha click, whoosh, reward...): qui va collegato quello, quando c'e'. Fino ad allora: silenzio. */
function nfDiarioFuturoSuono(){ }

/* ---------------------------------------------------------------- le risposte */
/** 0.9.300: le scelte e il testo stanno insieme. Ogni tocco aggiunge o toglie un'opzione (nelle scale, "unica",
 *  la nuova prende il posto della vecchia); il testo scritto resta. Si aggiornano solo i pulsanti: la casella del
 *  testo, il cursore e lo scorrimento non si muovono. */
function nfImposta(k, scelte, testo){
  const l = scelte.slice(); const t = String(testo == null ? '' : testo).trim();
  if (t) l.push(t);
  if (JSON.stringify(nfLista(NF.r[k])) === JSON.stringify(l)) return false;
  NF.r[k] = l; delete NF.ded[k];
  if (k === 'genere'){
    try{ if (typeof ifIdentita === 'function' && typeof ifScrivi === 'function' && typeof IF_KEYS !== 'undefined'){ const id = ifIdentita(); id.genere = scelte.indexOf('f') >= 0 ? 'f' : (scelte.indexOf('m') >= 0 ? 'm' : ''); ifScrivi(IF_KEYS.ident, id); } }catch(_){ }
  }
  const f = document.querySelector('#nfBody .nf-fonte'); if (f) f.remove();
  nfSalvaPresto();
  return true;
}
function nfScelta(k, v){
  const d = nfDomanda(k);
  let sc = nfScelte(k);
  const i = sc.indexOf(v);
  if (i >= 0) sc.splice(i, 1); else { if (d.unica) sc = []; sc.push(v); }
  delete NF.ord[k]; /* scelte cambiate: l'ordine si conferma di nuovo */
  nfImposta(k, sc, nfTesto(k));
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  document.querySelectorAll('#nfBody .nf-op[data-k]').forEach(function(b){ const on = sc.indexOf(b.getAttribute('data-k')) >= 0; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
}
/** Il testo dell'utente, intero: nessun limite di lunghezza. Si salva mentre scrive (anche la dettatura passa da qui). */
function nfLibero(k){
  const a = document.getElementById('nfLibero'); if (!a) return;
  nfAltezza(a);
  nfImposta(k, nfScelte(k), a.value);
}
let NF_SALVA_T = 0;
function nfSalvaPresto(){ clearTimeout(NF_SALVA_T); NF_SALVA_T = setTimeout(nfSalvaBozza, 400); }
function nfSu(){ try{ window.scrollTo(0, 0); const sc = document.getElementById('s-nuovome'); if (sc) sc.scrollTop = 0; }catch(_){ } }
function nfAvanti(){
  if (NF.fase !== 'domanda' && !NF.edit) return;
  const d = nfDomCorrente(); if (!d) return;
  if (!NF.edit && !nfLista(NF.r[d.k]).length){ if (typeof toast === 'function') toast((NF.c.domanda || {}).vuota || 'Scegli almeno una risposta, o scrivi la tua'); return; }
  /* Avanti su una risposta proposta dal Genio la conferma: non e' piu' "dedotta" */
  if (!NF.edit) delete NF.ded[d.k];
  /* 0.9.307, Andrea: "se tutto e' scelto niente e' importante". Con tre scelte o piu' si mettono in ordine. */
  if (!d.unica && nfScelte(d.k).length >= 3){ NF.fase = 'ordina'; nfSalvaBozza(); nfPaint(); nfSu(); return; }
  nfProsegui();
}
/** Dopo la domanda (e il suo ordine): la domanda dopo, il riepilogo, o l'episodio da cui si era arrivati. */
function nfProsegui(){
  if (NF.edit){ NF.edit = ''; NF.fase = 'storia'; NF.id = null; nfSalvaBozza(); nfPaint(); nfSu(); return; }
  nfSalvaBozza();
  nfSu();
  if (NF.solo){ const so = NF.solo; NF.solo = null; NF.fase = 'intro'; so.fatto(true); return; }
  NF.fase = 'domanda';
  if (NF.i < NF.qs.length - 1){ NF.i++; nfPaint(); return; }
  NF.fase = 'storia'; nfPaint();
}

/* ---------------------------------------------------------------- mettile in ordine (0.9.307)
   Le scelte in lista: la prima conta di piu'. Frecce su e giu' (pulsanti grandi) e trascinamento: col dito si tiene
   premuta la riga un attimo e si sposta, col mouse si trascina subito. L'ordine e' l'ordine della lista salvata. */
const NF_SU = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg>';
const NF_GIU = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
function nfOrdinaHtml(){
  const d = nfDomCorrente(), D = NF.c.domanda || {};
  return '<div class="nf-q nf-ord"><small class="nf-ord-q">' + nfEsc(d.q) + '</small>'
    + '<h2>' + nfEsc(D.ordina_t || 'Metti in ordine le tue risposte') + '</h2>'
    + '<p class="nf-ord-sotto">' + nfEsc(D.ordina_sotto || 'La prima è quella che conta di più.') + '</p>'
    + '<ol class="nf-ord-l" id="nfOrdL">' + nfOrdRighe(d) + '</ol>'
    + '<p class="nf-ord-come">' + nfEsc(D.ordina_come || '') + '</p>'
    + '<button type="button" class="nf-cta" onclick="nfOrdinaOk()">' + nfEsc(NF.edit ? (D.salva || 'Salva') : (D.avanti || 'Avanti')) + '</button></div>';
}
function nfOrdRighe(d){
  const sc = nfScelte(d.k), D = NF.c.domanda || {};
  return sc.map(function(x, i){
    const o = d.op.filter(function(y){ return y[0] === x; })[0] || [x, x, ''];
    return '<li class="nf-ord-r' + (i === 0 ? ' prima' : '') + '" data-k="' + nfEsc(x) + '"><b class="nf-ord-n">' + (i + 1) + '</b>'
      + (o[2] ? '<span class="nf-emo" aria-hidden="true">' + o[2] + '</span>' : '')
      + '<span class="nf-op-t">' + nfEsc(nfEtichetta(d, x)) + '</span>'
      + '<span class="nf-ord-fr"><button type="button" class="nf-ord-b" aria-label="' + nfEsc(D.ordina_su || 'Sposta più in alto') + '"' + (i === 0 ? ' disabled' : '') + ' onclick="nfOrdSposta(' + i + ',-1)">' + NF_SU + '</button>'
      + '<button type="button" class="nf-ord-b" aria-label="' + nfEsc(D.ordina_giu || 'Sposta più in basso') + '"' + (i === sc.length - 1 ? ' disabled' : '') + ' onclick="nfOrdSposta(' + i + ',1)">' + NF_GIU + '</button></span></li>';
  }).join('');
}
function nfOrdApplica(sc, mossa){
  const d = nfDomCorrente(); if (!d) return;
  nfImposta(d.k, sc, nfTesto(d.k));
  const l = document.getElementById('nfOrdL'); if (!l) return;
  l.innerHTML = nfOrdRighe(d);
  if (mossa){ const r = l.querySelector('.nf-ord-r[data-k="' + mossa + '"]'); if (r){ r.classList.add('mossa'); setTimeout(function(){ r.classList.remove('mossa'); }, 450); } }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
}
function nfOrdSposta(i, dir){
  const d = nfDomCorrente(); if (!d) return;
  const sc = nfScelte(d.k), j = i + dir;
  if (j < 0 || j >= sc.length) return;
  const t = sc[i]; sc[i] = sc[j]; sc[j] = t;
  nfOrdApplica(sc, t);
}
function nfOrdinaOk(){
  const d = nfDomCorrente(); if (!d) return;
  NF.ord[d.k] = Date.now();
  nfProsegui();
}
let NF_DRAG = null;
function nfOrdAggancia(){
  const l = document.getElementById('nfOrdL'); if (!l) return;
  l.addEventListener('pointerdown', nfOrdGiu);
  l.addEventListener('touchmove', function(e){ if (NF_DRAG && NF_DRAG.attivo && e.cancelable) e.preventDefault(); }, { passive: false });
  l.addEventListener('contextmenu', function(e){ e.preventDefault(); });
}
function nfOrdNumeri(){
  document.querySelectorAll('#nfOrdL .nf-ord-r').forEach(function(r, i, tutte){
    r.classList.toggle('prima', i === 0);
    const n = r.querySelector('.nf-ord-n'); if (n) n.textContent = String(i + 1);
    const b = r.querySelectorAll('.nf-ord-b'); if (b[0]) b[0].disabled = i === 0; if (b[1]) b[1].disabled = i === tutte.length - 1;
  });
}
function nfOrdGiu(e){
  const r = e.target.closest('.nf-ord-r'); if (!r || e.target.closest('button') || NF_DRAG) return;
  const D = NF_DRAG = { r: r, y: e.clientY, y0: e.clientY, id: e.pointerId, attivo: false, mouse: e.pointerType === 'mouse', t: 0 };
  D.attiva = function(){
    if (NF_DRAG !== D) return;
    D.attivo = true; r.classList.add('presa');
    try{ r.setPointerCapture(D.id); }catch(_){ }
    try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  };
  if (!D.mouse) D.t = setTimeout(D.attiva, 220);
  document.addEventListener('pointermove', nfOrdMuovi, { passive: false });
  document.addEventListener('pointerup', nfOrdSu);
  document.addEventListener('pointercancel', nfOrdSu);
}
function nfOrdMuovi(e){
  const D = NF_DRAG; if (!D || e.pointerId !== D.id) return;
  if (!D.attivo){
    if (Math.abs(e.clientY - D.y0) < 6) return;
    if (D.mouse) D.attiva(); else { nfOrdSu(e); return; } /* il dito si e' mosso subito: sta scorrendo la pagina */
  }
  if (e.cancelable) e.preventDefault();
  const r = D.r, dy = e.clientY - D.y, prima = r.offsetTop;
  const prev = r.previousElementSibling, next = r.nextElementSibling;
  if (next && dy > next.offsetHeight / 2 + 4) r.parentNode.insertBefore(next, r);
  else if (prev && dy < -(prev.offsetHeight / 2 + 4)) r.parentNode.insertBefore(r, prev);
  const sposta = r.offsetTop - prima;
  if (sposta){ D.y += sposta; nfOrdNumeri(); try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ } }
  r.style.transform = 'translateY(' + (e.clientY - D.y) + 'px)';
}
function nfOrdSu(){
  const D = NF_DRAG; if (!D) return;
  clearTimeout(D.t); NF_DRAG = null;
  document.removeEventListener('pointermove', nfOrdMuovi, { passive: false });
  document.removeEventListener('pointerup', nfOrdSu);
  document.removeEventListener('pointercancel', nfOrdSu);
  if (!D.attivo) return;
  D.r.classList.remove('presa'); D.r.style.transform = '';
  const l = document.getElementById('nfOrdL'); if (!l) return;
  nfOrdApplica([].map.call(l.querySelectorAll('.nf-ord-r'), function(x){ return x.getAttribute('data-k'); }), D.r.getAttribute('data-k'));
}
function nfModifica(k){ NF.edit = k; nfPaint(); try{ window.scrollTo(0, 0); const sc = document.getElementById('s-nuovome'); if (sc) sc.scrollTop = 0; }catch(_){ } }
function nfSalvaBozza(){
  const o = ifNuovoMe();
  o.v = 1; o.sogno = nfSogno(); o.categoria = nfCategoria(o.sogno);
  o.risposte = Object.assign({}, NF.r); o.dedotte = Object.assign({}, NF.ded); o.ordinate = Object.assign({}, NF.ord);
  o.perAgente = nfPerAgenteTesto();
  nfSalva(o);
}

/* ---------------------------------------------------------------- la rivelazione */
async function nfVaiRivela(){
  nfSalvaBozza();
  NF.fase = 'rivela'; NF.id = null; nfPaint();
  const t0 = Date.now();
  const ag = await nfIdentitaAgente(NF.r);
  NF.id = ag || nfIdentitaModello(NF.r, 0);
  /* la pausa del ricordo: almeno un secondo e mezzo, come chi ci pensa */
  setTimeout(function(){ if (NF.fase === 'rivela') nfPaint(); }, Math.max(0, 1500 - (Date.now() - t0)));
}
function nfRitocca(){
  NF.alt = [0, 1, 2].map(function(v){ return nfIdentitaModello(NF.r, v); });
  if (NF.id && NF.id.fonte === 'agente') NF.alt.unshift(NF.id);
  NF.fase = 'ritocca'; nfPaint();
}
function nfAltScegli(i){ NF.id = NF.alt[i]; NF.fase = 'rivela'; nfPaint(); }
function nfConferma(){
  const o = ifNuovoMe();
  o.v = 1; o.sogno = nfSogno(); o.categoria = nfCategoria(o.sogno);
  o.risposte = Object.assign({}, NF.r); o.dedotte = Object.assign({}, NF.ded);
  o.ordinate = Object.assign({}, NF.ord); o.perAgente = nfPerAgenteTesto();
  o.identita = NF.id; o.confermata = o.confermata || Date.now(); o.modificata = Date.now();
  nfSalva(o);
  /* "Chi saro'" (iofuturo.js) parte da qui, se era vuoto */
  try{ if (typeof ifIdentita === 'function' && typeof ifScrivi === 'function' && typeof IF_KEYS !== 'undefined'){ const id = ifIdentita(); if (!id.chiSaro){ id.chiSaro = String(NF.id.identity_statement).replace(/^Sono una persona che /i, '').replace(/\.$/, ''); ifScrivi(IF_KEYS.ident, id); } } }catch(_){ }
  /* la schermata fuori rotta mostra chi stai diventando */
  try{ if (typeof ptPedaggiSync === 'function') ptPedaggiSync(true); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra([12, 40, 12]); }catch(_){ }
  if (NF.ritorno === 's-identita'){ if (typeof toast === 'function') toast('Salvato: è la tua identità'); ifIdentitaApri(); return; }
  NF.fase = 'volto'; nfPaint();
}

/* ---------------------------------------------------------------- il volto e la voce */
function nfSelfie(camera){
  /* la fotocamera frontale: un input con capture, come fa il telefono con "scatta un selfie"; senza capture, la galleria */
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  if (camera) inp.setAttribute('capture', 'user');
  inp.onchange = function(){ const f = inp.files && inp.files[0]; if (f) nfFotoDaFile(f); try{ inp.remove(); }catch(_){ } };
  document.body.appendChild(inp);
  inp.click();
}
/** Il selfie rimpicciolito (640 px sul lato lungo): resta solo sul telefono, e parte verso il ritratto. */
function nfFotoDaFile(f){
  const r = new FileReader();
  r.onload = function(){
    const img = new Image();
    img.onload = function(){
      const lato = 640, k = Math.min(1, lato / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      nfRitrattoAvvia(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questa foto, provane un\'altra'); };
    img.src = r.result;
  };
  r.readAsDataURL(f);
}

/* ---------------------------------------------------------------- il ritratto dell'Io Futuro (0.9.301)
   Andrea: dal selfie, il suo Io Futuro poco piu' grande d'eta' (quanto manca al sogno secondo la stima di DreamMap),
   nel pieno della forma, con lo sguardo di chi ce l'ha fatta. Mentre arriva, la sagoma si riempie di blu dal basso
   (come il caricamento di My Future Self) e il Genio racconta il viaggio nel tempo: mai "generato", mai "creato".
   Server: POST /api/focuslock/agent/ritratto (Premium, Gemini). Il selfie non resta sul server. Il ritratto si salva
   qui: fl_if_img (lo leggono la chiamata, i messaggi, la Roadmap) e una copia intera in IndexedDB, mai persa.
   Se la funzione e' spenta o il server non risponde: resta la sagoma e si dice solo quello che e' successo. */
const NF_RT_GIORNO = 3; /* come DREAMMAP_RITRATTO_MAX_GIORNO sul server */
const NF_RT = { id: 0, t0: 0, raf: 0, frase: 0, timer: 0, p: 0, fine: false, img: '', restano: null, continua: false };
function nfDb(){
  return new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_iofuturo', 1);
      r.onupgradeneeded = function(){ r.result.createObjectStore('img'); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ko(r.error); };
    }catch(e){ ko(e); }
  });
}
async function nfIdbPut(k, v){
  try{ const db = await nfDb(); await new Promise(function(ok, ko){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').put(v, k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ko(tx.error); }; }); return true; }catch(_){ return false; }
}
async function nfIdbGet(k){
  try{ const db = await nfDb(); return await new Promise(function(ok){ const tx = db.transaction('img', 'readonly'); const q = tx.objectStore('img').get(k); q.onsuccess = function(){ ok(q.result || null); }; q.onerror = function(){ ok(null); }; }); }catch(_){ return null; }
}
/** Se localStorage ha perso il ritratto (memoria ripulita), torna dalla copia in IndexedDB. */
async function nfRitrattoRipristina(){
  try{ if (localStorage.getItem('fl_if_img')) return; }catch(_){ return; }
  const r = await nfIdbGet('ritratto');
  if (r && r.piccolo){ try{ localStorage.setItem('fl_if_img', r.piccolo); }catch(_){ } }
}
setTimeout(nfRitrattoRipristina, 4000);
/** Quanti anni mancano al sogno secondo la stima di DreamMap (null se la stima non c'e'). */
function nfAnniAlSogno(){
  try{ const a = (typeof etaArrivo === 'function') ? etaArrivo() : null; if (a && a.at && isFinite(a.at) && !a.senzaPiano){ const y = (a.at - Date.now()) / (365.25 * 864e5); if (y > 0) return Math.min(15, y); } }catch(_){ }
  return null;
}
/** "fra due anni", "fra otto mesi": il tempo in parole, per la voce del Genio. */
function nfTempoTxt(anni){
  const N = ['', 'un', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove', 'dieci', 'undici'];
  if (anni < 1){ const m = Math.max(1, Math.round(anni * 12)); return m >= 12 ? 'fra un anno' : (m === 1 ? 'fra un mese' : 'fra ' + N[m] + ' mesi'); }
  const y = Math.round(anni);
  return y <= 1 ? 'fra un anno' : 'fra ' + (N[y] || y) + ' anni';
}
function nfRtFrasi(){
  const RT = NF.c.ritratto || {}, anni = nfAnniAlSogno();
  return (RT.frasi || []).map(function(f){ return f.indexOf('{tempo}') >= 0 ? (anni ? nfT(f, { tempo: nfTempoTxt(anni) }) : (RT.frase_senza_tempo || '')) : f; }).filter(Boolean);
}
function nfRtConta(){
  try{ const c = JSON.parse(localStorage.getItem('fl_if_ritratti') || 'null'); const g = new Date().toDateString(); return c && c.g === g ? c.n : 0; }catch(_){ return 0; }
}
function nfRtSegna(){ try{ localStorage.setItem('fl_if_ritratti', JSON.stringify({ g: new Date().toDateString(), n: nfRtConta() + 1 })); }catch(_){ } }
/** Il ritratto in formato telefono (600x800, JPEG): sta in localStorage e lo leggono tutte le pagine dell'Io Futuro. */
function nfRtRimpicciolisci(src){
  return new Promise(function(ok){
    const img = new Image();
    img.onload = function(){
      try{
        const W = 600, H = 800, c = document.createElement('canvas'); c.width = W; c.height = H;
        const k = Math.max(W / img.width, H / img.height), w = img.width * k, h = img.height * k;
        c.getContext('2d').drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
        ok(c.toDataURL('image/jpeg', 0.86));
      }catch(_){ ok(''); }
    };
    img.onerror = function(){ ok(''); };
    img.src = src;
  });
}
async function nfRitrattoAvvia(selfie){
  if (!(await nfCarica())) return;
  NF.rtAvviso = '';
  /* il selfie resta sul telefono: serve a chiedere un altro ritratto senza rifare la foto */
  if (selfie){ NF.rtSelfie = selfie; nfIdbPut('selfie', selfie); }
  selfie = selfie || NF.rtSelfie || await nfIdbGet('selfie');
  if (!selfie){ NF.fase = 'volto'; nfPaint(); return; }
  let premium = false; try{ premium = typeof sdPremium === 'function' && sdPremium(); }catch(_){ }
  if (!premium || typeof agApi !== 'function'){
    /* senza Premium il volto dell'Io Futuro resta il selfie, come prima */
    try{ localStorage.setItem('fl_if_img', selfie); }catch(_){ if (typeof toast === 'function') toast('La memoria del telefono è piena'); }
    try{ if (typeof ifCardPaint === 'function') ifCardPaint(); }catch(_){ }
    NF.fase = 'volto'; nfPaint(); return;
  }
  if (nfRtConta() >= NF_RT_GIORNO){ NF.rtAvviso = 'finiti'; NF.fase = 'volto'; nfPaint(); return; }
  const id = ++NF_RT.id;
  Object.assign(NF_RT, { t0: Date.now(), frase: 0, p: 0, fine: false, img: '', continua: false });
  NF.fase = 'ritratto'; nfPaint();
  let r = null, errore = '';
  try{
    const anni = nfAnniAlSogno();
    r = await agApi('POST', '/api/focuslock/agent/ritratto', { selfie: selfie, anni: anni == null ? 2 : Math.round(anni * 10) / 10, genere: nfGenere() });
  }catch(e){ errore = String((e && e.message) || e || ''); }
  if (id !== NF_RT.id) return;
  if (!r || !r.immagine){
    nfRtFerma();
    NF.rtAvviso = /429|finiti/.test(errore) ? 'finiti' : 'non_ora';
    if (NF.fase === 'ritratto'){ NF.fase = 'volto'; nfPaint(); }
    return;
  }
  /* salvato prima di tutto: anche se nel frattempo si e' andati avanti, il ritratto non si perde */
  const piccolo = await nfRtRimpicciolisci(r.immagine);
  const quando = Date.now();
  await nfIdbPut('ritratto', { intero: r.immagine, piccolo: piccolo, t: quando });
  nfIdbPut('ritratto-' + quando, { intero: r.immagine, t: quando });
  try{ localStorage.setItem('fl_if_img', piccolo || r.immagine); }catch(_){ }
  nfRtSegna();
  NF_RT.restano = typeof r.restano === 'number' ? r.restano : Math.max(0, NF_RT_GIORNO - nfRtConta());
  try{ if (typeof ifCardPaint === 'function') ifCardPaint(); }catch(_){ }
  NF_RT.img = piccolo || r.immagine;
  NF_RT.fine = true;
  if (NF.fase === 'ritratto') nfRtArrivo();
  else if (document.getElementById('nfBody') && NF.fase === 'voce') nfPaint();
}
function nfRtFerma(){ cancelAnimationFrame(NF_RT.raf); clearInterval(NF_RT.timer); NF_RT.raf = 0; NF_RT.timer = 0; }
function nfRitrattoPaint(){
  const h = document.getElementById('nfBody'), RT = NF.c.ritratto || {}, frasi = nfRtFrasi();
  if (NF_RT.fine && NF_RT.img){ nfRtFinePaint(false); return; }
  h.innerHTML = '<div class="nf-intro nf-rt">' + nfSagoma('carica')
    + '<h1 class="nf-h2">' + nfEsc(RT.titolo) + '</h1>'
    + '<div class="nf-rt-punti" aria-hidden="true">' + frasi.map(function(_, i){ return '<i' + (i === 0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div>'
    + '<p class="nf-rt-frase" id="nfRtFrase" aria-live="polite">' + nfEsc(frasi[0] || '') + '</p>'
    + '<button type="button" class="nf-cta" onclick="nfRtContinua()">' + nfEsc(RT.continua) + '</button>'
    + '<p class="nf-nota">' + nfEsc(RT.continua_nota) + '</p></div>';
  nfRtFerma();
  /* il riempimento: veloce all'inizio, poi rallenta; non arriva in cima finche' il ritratto non c'e' davvero */
  const passo = function(){
    const t = Date.now() - NF_RT.t0;
    NF_RT.p = 0.93 * (1 - Math.exp(-t / 9000));
    nfRtLivello(NF_RT.p);
    NF_RT.raf = requestAnimationFrame(passo);
  };
  NF_RT.raf = requestAnimationFrame(passo);
  NF_RT.frase = 0;
  NF_RT.timer = setInterval(function(){
    const el = document.getElementById('nfRtFrase'); if (!el || NF.fase !== 'ritratto'){ nfRtFerma(); return; }
    /* la prima frase apre il viaggio una volta sola; poi si alternano le altre */
    NF_RT.frase = NF_RT.frase + 1 < frasi.length ? NF_RT.frase + 1 : Math.min(1, frasi.length - 1);
    el.classList.add('via');
    setTimeout(function(){ el.textContent = frasi[NF_RT.frase] || ''; el.classList.remove('via'); }, 280);
    document.querySelectorAll('#nfBody .nf-rt-punti i').forEach(function(d, i){ d.classList.toggle('on', i === NF_RT.frase); });
  }, 4200);
}
/** p da 0 a 1: il blu sale dal basso, con le righe chiare sul bordo come una scansione. */
function nfRtLivello(p){
  const sag = document.getElementById('nfSag'); if (!sag) return;
  const y = 306 * (1 - Math.max(0, Math.min(1, p)));
  const r = sag.querySelector('.nf-sag-pieno'); if (r) r.setAttribute('y', y.toFixed(1));
  const sc = sag.querySelector('.nf-sag-scan'); if (sc){ sc.setAttribute('transform', 'translate(0 ' + y.toFixed(1) + ')'); sc.style.opacity = p >= 0.995 ? '0' : '1'; }
}
/** Il ritratto e' arrivato: il blu finisce di salire, poi la sagoma lascia il posto al volto. */
function nfRtArrivo(){
  nfRtFerma();
  const da = NF_RT.p || 0, t0 = Date.now();
  const sale = function(){
    const k = Math.min(1, (Date.now() - t0) / 700);
    nfRtLivello(da + (1 - da) * (1 - Math.pow(1 - k, 3)));
    if (k < 1){ NF_RT.raf = requestAnimationFrame(sale); return; }
    nfRtFinePaint(true);
  };
  NF_RT.raf = requestAnimationFrame(sale);
}
function nfRtFinePaint(dissolvi){
  const h = document.getElementById('nfBody');
  if (!h || !NF.c) return;
  const RT = NF.c.ritratto || {};
  const restano = NF_RT.restano == null ? Math.max(0, NF_RT_GIORNO - nfRtConta()) : NF_RT.restano;
  const sag = document.getElementById('nfSag');
  const testo = '<h1 class="nf-h2 nf-rt-in">' + nfEsc(RT.arrivo) + '</h1><p class="nf-rt-in">' + nfEsc(RT.arrivo_sotto) + '</p>'
    + '<button type="button" class="nf-cta nf-rt-in" onclick="NF.fase=\'voce\';nfPaint()">' + nfEsc(RT.avanti) + '</button>'
    + (restano > 0 ? '<button type="button" class="nf-sec nf-rt-in" onclick="nfRitrattoAvvia()">' + nfEsc(RT.altro) + '</button><p class="nf-nota nf-rt-in">' + nfEsc(nfT(restano === 1 ? RT.altro_uno : RT.altro_nota, { n: restano })) + '</p>' : '');
  if (dissolvi && sag){
    /* la dissolvenza: il volto compare sopra la sagoma, che intanto svanisce */
    const foto = sag.querySelector('.nf-sag-foto');
    if (foto) foto.style.backgroundImage = "url('" + String(NF_RT.img).replace(/'/g, '') + "')";
    sag.classList.add('arrivato');
    const wrap = sag.parentElement;
    [].slice.call(wrap.children).forEach(function(el){ if (el !== sag) el.remove(); });
    wrap.insertAdjacentHTML('beforeend', testo);
    try{ if (typeof flVibra === 'function') flVibra([12, 40, 12]); }catch(_){ }
    return;
  }
  h.innerHTML = '<div class="nf-intro nf-rt"><div class="nf-sagoma arrivato fermo"><div class="nf-sag-foto" style="background-image:url(\'' + String(NF_RT.img).replace(/'/g, '') + '\')"></div></div>' + testo + '</div>';
}
/** "Continua" durante l'attesa: si va avanti, e il ritratto si salva lo stesso appena arriva. */
function nfRtContinua(){ NF_RT.continua = true; nfRtFerma(); NF.fase = 'voce'; nfPaint(); }
function nfVoce(){
  let premium = false; try{ premium = typeof sdPremium === 'function' && sdPremium(); }catch(_){ }
  if (!premium){ if (typeof toast === 'function') toast(NF.c.voce.premium); NF.fase = 'regole'; nfPaint(); return; }
  NF.fase = 'regole';
  if (typeof icVoceApri === 'function') icVoceApri(); else nfPaint();
}

/* ---------------------------------------------------------------- le regole della partita */
function nfRegoleHtml(){
  const R = NF.c.regole, id = NF.id || ifNuovoMe().identita || { vote_actions: [] };
  let cons = null, mod = null;
  try{ cons = (typeof mdConsiglio === 'function') ? mdConsiglio() : null; mod = cons && typeof mdModello === 'function' ? mdModello(cons.k) : null; }catch(_){ }
  try{ const cur = (typeof mdLeggi === 'function') ? mdLeggi() : null; if (cur && typeof mdModello === 'function') mod = mdModello(cur.k); }catch(_){ }
  const regole = mod ? mod.regole.map(function(x){ const r = (typeof MD_REGOLE !== 'undefined') ? MD_REGOLE[x[0]] : null; return r ? { t: String(r.t).replace('{ora}', (r.ora || 12) + ':00'), chi: r.chi, lato: r.lato, pt: x[1] } : null; }).filter(Boolean) : [];
  const riga = function(r){ return '<div class="nf-reg"><span>' + nfEsc(r.t) + '<small>' + nfEsc(r.chi) + '</small></span><b class="' + (r.lato === 'old' ? 'rosso' : '') + '">+' + r.pt + '</b></div>'; };
  return '<div class="nf-regole">'
    + '<h2 class="nf-h">' + nfEsc(R.titolo) + '</h2><p class="nf-sub">' + nfEsc(R.sotto) + '</p>'
    + '<div class="nf-tab"><div><small>Vecchio te</small><b class="rosso">' + nfPunti('old') + '</b></div><i class="nf-vs">vs</i><div><small>Nuovo te</small><b>' + nfPunti('neo') + '</b></div></div>'
    + (mod ? '<div class="nf-card"><small class="nf-gr">' + nfEsc(R.modello) + '</small><b class="nf-mod">' + nfEsc(mod.ico + ' ' + mod.n) + '</b><p class="nf-p">' + nfEsc(mod.s + ' ' + (mod.per || '')) + '</p>'
      + '<small class="nf-gr">' + nfEsc(R.punti_neo) + '</small>' + regole.filter(function(r){ return r.lato === 'neo'; }).map(riga).join('')
      + '<small class="nf-gr">' + nfEsc(R.punti_old) + '</small>' + regole.filter(function(r){ return r.lato === 'old'; }).map(riga).join('')
      + '<button type="button" class="nf-link" onclick="nfModelloCambia()">' + nfEsc(R.cambia) + '</button></div>' : '')
    + '<div class="nf-card"><small class="nf-gr">' + nfEsc(R.come) + '</small>' + R.vince.map(function(v){ return '<div class="nf-vince"><span>' + v[0] + '</span><p><b>' + nfEsc(v[1]) + '</b> ' + nfEsc(v[2]) + '</p></div>'; }).join('') + '</div>'
    + '<div class="nf-card"><small class="nf-gr">' + nfEsc(R.voti_t) + '</small><p class="nf-p">' + nfEsc(R.voti_sotto) + '</p>'
    +   (id.vote_actions || []).map(function(t){ return '<p class="nf-voto">🗳️ ' + nfEsc(t) + '</p>'; }).join('')
    +   '<label class="nf-check"><input type="checkbox" id="nfVotiOggi" checked><span>' + nfEsc(R.voti_metti) + '</span></label></div>'
    + '<button type="button" class="nf-cta" onclick="nfIniziaPartita()">' + nfEsc(R.cta) + '</button></div>';
}
function nfPunti(lato){ try{ const s = (typeof mtState === 'function') ? mtState() : null; return s ? (s[lato] || 0) : 0; }catch(_){ return 0; } }
function nfModelloCambia(){ if (typeof mdApri === 'function'){ NF.tornaRegole = true; mdApri(); } }
function nfIniziaPartita(){
  /* il modello consigliato diventa quello in vigore, se non ne era stato scelto uno */
  try{ if (typeof mdLeggi === 'function' && !mdLeggi() && typeof mdConsiglio === 'function' && typeof mdModello === 'function' && typeof mdSalva === 'function'){ const m = mdModello(mdConsiglio().k); if (m) mdSalva({ k: m.k, regole: m.regole.map(function(x){ return { id: x[0], pt: x[1], ora: (MD_REGOLE[x[0]] || {}).ora, on: true }; }) }); } }catch(_){ }
  /* i tre voti nel foglio di oggi, una riga ciascuno */
  const cb = document.getElementById('nfVotiOggi');
  if (cb && cb.checked){
    const id = NF.id || ifNuovoMe().identita || {};
    try{ const day = (typeof stDayKey === 'function') ? stDayKey('today') : ''; if (day && typeof ulAggiungiRiga === 'function') (id.vote_actions || []).forEach(function(t){ ulAggiungiRiga(day, t); }); }catch(_){ }
  }
  const o = ifNuovoMe(); o.partita = Date.now(); nfSalva(o);
  try{ if (typeof ffAddCoins === 'function') ffAddCoins(20); }catch(_){ }
  NF.fase = 'fine'; nfPaint();
}
/** La pagina "Il mio futuro se'" della replica di Notion, gia' scritta con l'identita' (come whyModello in why.js). */
function nfNotion(da){
  const f = document.getElementById('ntFrame');
  if (!f || typeof NT === 'undefined'){ if (typeof toast === 'function') toast('Apri il piano: la pagina è nei modelli'); return; }
  NT.schermo = da || 's-nuovome';
  const w = f.contentWindow;
  if (NT.pronto && /notion\/index\.html/.test(f.getAttribute('src') || '') && w && typeof w.flNotionModello === 'function'){
    NT.aperto = true; goId('s-notion'); try{ w.flNotionModello('futurose'); }catch(_){ }
    return;
  }
  f.setAttribute('src', 'notion/index.html?v=' + Date.now() + '#modello=futurose');
  NT.pronto = true; NT.aperto = true; goId('s-notion');
}
function nfVaiPartita(){
  goId('s-home');
  try{ switchTab('sveglia'); }catch(_){ }
  try{ if (typeof sdAggiorna === 'function') sdAggiorna(true); }catch(_){ }
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#s-nuovome{background:var(--bg)}',
    '.nf-top{display:flex;align-items:center;gap:10px;padding:10px 14px 4px}.nf-bar{flex:1;height:8px;border-radius:99px;background:rgba(0,117,227,.14);overflow:hidden}.nf-bar i{display:block;height:100%;width:0;border-radius:99px;background:#0075E3;transition:width .4s}',
    '.nf-body{padding:8px 20px 40px;max-width:560px;margin:0 auto}',
    '.nf-intro{display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:10px}',
    '.nf-intro h1{margin:18px 0 8px;font:900 28px/1.15 var(--font-display);color:var(--navy);text-wrap:balance}.nf-intro .nf-h2{font-size:21px}',
    '.nf-intro p{margin:0 0 6px;font:500 15px/1.5 var(--font-body);color:var(--muted);text-wrap:pretty}',
    '.nf-kick{font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3;margin-top:10px}',
    '.nf-dur{font:700 12px var(--font-body);color:var(--muted);margin-top:4px}',
    '.nf-sagoma{position:relative;width:260px;height:318px;display:grid;place-items:center;flex:none}',
    '.nf-sagoma::before{content:"";position:absolute;left:50%;top:44%;width:230px;height:300px;margin:-150px 0 0 -115px;border-radius:50%;background:radial-gradient(closest-side,rgba(63,159,244,.20),rgba(63,159,244,.10) 40%,rgba(63,159,244,.04) 70%,rgba(63,159,244,0));animation:nfAura 3.2s ease-in-out infinite}',
    '.nf-sagoma svg{position:relative;width:138px;height:305px;overflow:visible}',
    '.nf-sg-0{stop-color:#8CC6FF}.nf-sg-1{stop-color:#4FA6F5}.nf-sg-2{stop-color:#1C7FE6}.nf-sg-3{stop-color:#0B4A9E}',
    'body.dark .nf-sg-0{stop-color:#BCE0FF}body.dark .nf-sg-1{stop-color:#6DB7F8}body.dark .nf-sg-2{stop-color:#2F8DEE}body.dark .nf-sg-3{stop-color:#1660C4}',
    '.nf-sg-t0{stop-color:#8CC6FF;stop-opacity:.75}.nf-sg-t1{stop-color:#8CC6FF;stop-opacity:0}body.dark .nf-sg-t0{stop-color:#3F9FF4;stop-opacity:.55}',
    '.nf-sag-anello{fill:none;stroke:#8CC6FF;stroke-opacity:.55;stroke-width:.8}body.dark .nf-sag-anello{stroke:#3F9FF4;stroke-opacity:.45}',
    '.nf-sagoma.carica .nf-sag-terra,.nf-sagoma.carica .nf-sag-anello{opacity:.6}',
    '.nf-emo-sag{display:grid;place-items:center;color:#0075E3}body.dark .nf-emo-sag{color:#8CC6FF}',
    '.nf-sagoma.carica .nf-sag-base{fill:#C2D7F4}body.dark .nf-sagoma.carica .nf-sag-base{fill:#2A4470}.nf-sagoma.carica .nf-sag-luce{opacity:.35}',
    '.nf-sag-scan rect{fill:#EAF4FF;opacity:.85}.nf-sag-scan rect:nth-child(2){opacity:.55}.nf-sag-scan{transition:opacity .3s}',
    'body.dark .nf-sagoma::before{background:radial-gradient(closest-side,rgba(63,159,244,.24),rgba(63,159,244,.12) 40%,rgba(63,159,244,.05) 70%,rgba(63,159,244,0))}',
    '.nf-sag-foto{position:absolute;left:50%;top:50%;width:210px;height:280px;margin:-140px 0 0 -105px;border-radius:28px;background-size:cover;background-position:center 30%;opacity:0;transform:scale(.94);transition:opacity 1.1s ease,transform 1.1s ease;box-shadow:0 0 0 4px #fff,0 0 0 7px #3F9FF4,0 18px 50px rgba(0,88,176,.35)}',
    'body.dark .nf-sag-foto{box-shadow:0 0 0 4px #0B1220,0 0 0 7px #3F9FF4,0 18px 50px rgba(0,0,0,.5)}',
    '.nf-sagoma.arrivato svg{opacity:0;transition:opacity .9s ease}.nf-sagoma.arrivato .nf-sag-foto{opacity:1;transform:none}.nf-sagoma.fermo .nf-sag-foto{transition:none}',
    '@keyframes nfAura{50%{transform:scale(1.07);opacity:.75}}',
    '.nf-rt-punti{display:flex;justify-content:center;gap:6px;margin:2px 0 14px}.nf-rt-punti i{width:7px;height:7px;border-radius:99px;background:rgba(0,117,227,.28);transition:width .3s,background .3s}.nf-rt-punti i.on{width:24px;background:#0075E3}body.dark .nf-rt-punti i{background:rgba(140,198,255,.3)}body.dark .nf-rt-punti i.on{background:#3F9FF4}',
    '.nf-rt-frase{min-height:72px;margin:0 6px;font:500 16px/1.5 var(--font-body);color:var(--muted);transition:opacity .28s ease}.nf-rt-frase.via{opacity:0}',
    '.nf-rt .nf-cta{margin-top:14px}.nf-rt .nf-nota{margin-top:14px}',
    '.nf-rt-in{opacity:0;animation:nfEntra .6s ease forwards;animation-delay:.7s}.nf-rt-in + .nf-rt-in{animation-delay:.9s}',
    '.nf-rt-avviso{margin:4px 6px 0;padding:12px 14px;border-radius:16px;background:rgba(0,117,227,.08);color:var(--navy);font:600 14px/1.45 var(--font-body)}body.dark .nf-rt-avviso{background:rgba(63,159,244,.14);color:#fff}',
    '.nf-punti{display:flex;gap:6px;margin:4px 0 12px}.nf-punti i{width:8px;height:8px;border-radius:50%;background:#0075E3;animation:nfPunto 1s infinite}.nf-punti i:nth-child(2){animation-delay:.2s}.nf-punti i:nth-child(3){animation-delay:.4s}@keyframes nfPunto{50%{opacity:.25}}',
    '.nf-cta{display:block;width:100%;margin-top:18px;padding:16px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 4px 0 #0B4F9C}',
    '.nf-sec{display:block;width:100%;margin-top:10px;padding:14px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy);font:700 15px var(--font-body);cursor:pointer}',
    'body.dark .nf-sec{background:#12203A;border-color:#22345A;color:#fff}',
    '.nf-q h2,.nf-h{margin:6px 0 6px;font:900 27px/1.18 var(--font-display);color:var(--navy)}',
    '.nf-q h2{margin:6px 0 22px;text-align:center;text-wrap:balance}.nf-fonte{margin:-12px 0 18px;text-align:center}.nf-fonte .nf-tag{display:inline-block}',
    '.nf-ord-q{display:block;margin:4px 6px 4px;text-align:center;font:700 13.5px/1.4 var(--font-body);color:#0075E3}body.dark .nf-ord-q{color:#8CC6FF}',
    '.nf-ord h2{margin:2px 0 6px}.nf-ord-sotto{margin:0 0 20px;text-align:center;font:800 16px/1.4 var(--font-body);color:#E63946}body.dark .nf-ord-sotto{color:#FF7A84}',
    '.nf-ord-l{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:10px}',
    '.nf-ord-r{position:relative;display:flex;align-items:center;gap:12px;padding:9px 9px 9px 14px;border:1.5px solid var(--line);border-radius:20px;background:var(--card,#fff);color:var(--navy);font:700 16px/1.35 var(--font-body);box-shadow:0 3px 0 rgba(15,32,65,.12);-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;cursor:grab;transition:box-shadow .15s,border-color .15s}',
    '.nf-ord-r.presa{z-index:3;cursor:grabbing;border-color:#0075E3;box-shadow:0 16px 34px rgba(0,60,140,.28);transition:none}',
    '.nf-ord-r.mossa{animation:nfMossa .45s ease}@keyframes nfMossa{0%{background:#DCEBFC}100%{background:var(--card,#fff)}}',
    '.nf-ord-n{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:#0075E3;color:#fff;font:900 14px var(--font-display)}.nf-ord-r.prima .nf-ord-n{background:#E63946}',
    '.nf-ord-fr{flex:none;display:flex;gap:6px}',
    '.nf-ord-b{width:44px;height:44px;padding:0;border-radius:14px;border:1.5px solid var(--line);background:#F1F7FE;color:#0075E3;display:grid;place-items:center;cursor:pointer}.nf-ord-b:disabled{opacity:.3;cursor:default}',
    'body.dark .nf-ord-r{background:#12203A;border-color:#22345A;color:#fff;box-shadow:0 3px 0 rgba(0,0,0,.35)}body.dark .nf-ord-r.presa{border-color:#3F9FF4;box-shadow:0 16px 34px rgba(0,0,0,.55)}',
    'body.dark .nf-ord-r.mossa{animation:nfMossaS .45s ease}@keyframes nfMossaS{0%{background:#22376B}100%{background:#12203A}}',
    'body.dark .nf-ord-b{background:#1C2E5A;border-color:#2C4474;color:#8CC6FF}body.dark .nf-ord-r.prima .nf-ord-n{background:#E63946}',
    '.nf-ord-come{margin:16px 8px 0;text-align:center;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.nf-sub{margin:0 0 14px;font:500 14.5px/1.45 var(--font-body);color:var(--muted)}.nf-ded{color:#0075E3;font-weight:700}',
    '.nf-nota{margin:26px 12px 0;text-align:center;font:500 12.5px/1.5 var(--font-body);color:var(--muted);opacity:.85}',
    '.nf-ops{display:flex;flex-direction:column;gap:10px}',
    '.nf-op{width:100%;text-align:left;padding:16px 16px;border:1.5px solid var(--line);border-radius:20px;background:var(--card,#fff);color:var(--navy);font:700 16.5px/1.35 var(--font-body);cursor:pointer;box-shadow:0 3px 0 rgba(15,32,65,.12);display:flex;align-items:center;gap:14px}',
    '.nf-emo{flex:none;width:28px;text-align:center;font-size:22px;line-height:1}.nf-op-t{flex:1;min-width:0}',
    '.nf-spunta{flex:none;width:24px;height:24px;border-radius:50%;border:2px solid var(--line);display:grid;place-items:center;color:transparent;box-sizing:border-box;transition:background .15s,border-color .15s}',
    '.nf-op.on .nf-spunta{background:#0075E3;border-color:#0075E3;color:#fff}body.dark .nf-spunta{border-color:#3A5480}body.dark .nf-op.on .nf-spunta{background:#3F9FF4;border-color:#3F9FF4;color:#fff}',
    '.nf-op.alta{display:block}',
    '.nf-op.alta{font:600 15.5px/1.45 var(--font-body)}',
    '.nf-op.on{border-color:#0075E3;background:#E6F1FD;box-shadow:0 0 0 1px #0075E3 inset,0 3px 0 rgba(0,117,227,.25)}',
    'body.dark .nf-op{background:#12203A;border-color:#22345A;color:#fff;box-shadow:0 3px 0 rgba(0,0,0,.35)}',
    'body.dark .nf-op.on{border-color:#3F9FF4;background:rgba(63,159,244,.18);color:#fff;box-shadow:0 0 0 1px #3F9FF4 inset}',
    '.nf-mio{margin-top:28px}.nf-mio-t{display:block;margin:0 4px 10px;text-align:center;font:800 14px var(--font-body);color:var(--muted)}',
    '.nf-libero{width:100%;box-sizing:border-box;min-height:86px;padding:16px 56px 16px 18px;border:1.5px solid var(--line);border-radius:20px;background:var(--card,#fff);color:var(--navy);font:500 16px/1.5 var(--font-body);resize:none;overflow:hidden}',
    '.nf-q .nf-cta{margin-top:28px}',
    'body.dark .nf-libero{background:#12203A;border-color:#22345A;color:#fff}',
    '.nf-gr{display:block;margin:18px 2px 8px;font:800 11.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}',
    '.nf-riga{display:flex;align-items:center;gap:10px;width:100%;text-align:left;margin-bottom:10px;padding:16px 18px;border:1.5px solid var(--line);border-radius:20px;background:var(--card,#fff);cursor:pointer;box-shadow:0 3px 0 rgba(15,32,65,.1)}',
    'body.dark .nf-riga{background:#12203A;border-color:#22345A}',
    '.nf-riga-c{flex:1;min-width:0;display:flex;flex-direction:column;gap:6px}.nf-riga small{font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.nf-ris{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;font:700 16px/1.4 var(--font-body);color:var(--navy);overflow-wrap:anywhere;white-space:pre-line}body.dark .nf-ris{color:#fff}.nf-ris.vuota,body.dark .nf-ris.vuota{color:var(--muted)}.nf-ris-mio{font-weight:600}',
    '.nf-riga.aperta .nf-ris{display:block;-webkit-line-clamp:unset;overflow:visible}',
    '.nf-leggi{align-self:flex-start;margin:0;padding:2px 0;border:0;background:none;color:#0075E3;font:800 13.5px var(--font-body);cursor:pointer}body.dark .nf-leggi{color:#5BB2FF}',
    '.nf-sez{margin-top:30px}.nf-sez-t{display:flex;align-items:center;gap:10px;margin:0 2px 14px;font:900 21px/1.25 var(--font-display);color:#0075E3}.nf-sez-t span{font-size:22px}body.dark .nf-sez-t{color:#5BB2FF}',
    '.nf-tag{align-self:flex-start;margin-top:4px;padding:2px 9px;border-radius:99px;background:rgba(0,117,227,.1);color:#0075E3;font:700 11px var(--font-body)}',
    '.nf-chev{color:var(--muted);display:flex}',
    'body.dark .nf-tag{background:rgba(91,178,255,.16);color:#8CC6FF}',
    '@keyframes nfEntra{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    /* la pagina dal futuro (0.9.308): carta che resta carta anche al buio, inchiostri fissi */
    '@font-face{font-family:"DM Caveat";font-style:normal;font-weight:400 700;font-display:swap;src:url("fonts/caveat/Caveat-latin.woff2") format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}',
    '@font-face{font-family:"DM Caveat";font-style:normal;font-weight:400 700;font-display:swap;src:url("fonts/caveat/Caveat-latin-ext.woff2") format("woff2");unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C4,U+2113,U+2C60-2C7F,U+A720-A7FF}',
    '.nf-df{padding:16px 0 8px}',
    '.nf-df-scena{perspective:1500px;padding:0 2px;filter:drop-shadow(0 18px 22px rgba(15,32,65,.26)) drop-shadow(0 2px 2px rgba(60,40,20,.22))}body.dark .nf-df-scena{filter:drop-shadow(0 18px 26px rgba(0,0,0,.6)) drop-shadow(0 2px 2px rgba(0,0,0,.4))}',
    '.nf-df-pag{position:relative;max-width:440px;margin:0 auto;padding:30px 26px 34px;box-sizing:border-box;text-align:center;color:#3b2d20;background-color:#eee0bf;'
      + 'background-image:linear-gradient(90deg,rgba(110,72,32,.20),rgba(110,72,32,0) 26px),radial-gradient(ellipse at 22% 6%,rgba(255,255,255,.5),rgba(255,255,255,0) 55%),'
      + 'radial-gradient(circle at 84% 30%,rgba(150,100,40,.13) 0 22px,rgba(150,100,40,.05) 34px,rgba(150,100,40,0) 46px),radial-gradient(circle at 14% 64%,rgba(150,100,40,.08) 0 14px,rgba(150,100,40,0) 30px),'
      + 'radial-gradient(ellipse at 8% 96%,rgba(120,80,30,.26),rgba(120,80,30,0) 42%),radial-gradient(ellipse at 98% 100%,rgba(120,80,30,.3),rgba(120,80,30,0) 38%),radial-gradient(ellipse at 100% 0%,rgba(120,80,30,.18),rgba(120,80,30,0) 30%),'
      + 'repeating-linear-gradient(0deg,rgba(90,70,50,0) 0 31px,rgba(90,70,50,.11) 31px 32px);'
      + 'box-shadow:inset 0 0 46px rgba(120,80,30,.26);clip-path:' + nfDfBordo() + ';transform-origin:left center;animation:nfDfApri 1s cubic-bezier(.2,.75,.25,1) both;cursor:default}',
    '.nf-df-pag::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,rgba(60,40,20,.38),rgba(60,40,20,0) 70%);opacity:0;animation:nfDfOmbra 1s ease both}',
    '@keyframes nfDfApri{0%{transform:rotateY(-96deg);opacity:0}18%{opacity:1}100%{transform:none;opacity:1}}',
    '@keyframes nfDfOmbra{0%{opacity:1}100%{opacity:0}}',
    '.nf-df-foto{position:relative;width:128px;margin:2px auto 22px;padding:8px 8px 24px;background:#fbf8f0;box-shadow:0 6px 14px rgba(60,40,20,.28);transform:rotate(-3deg)}',
    '.nf-df-img{display:block;width:100%;aspect-ratio:1;background:#d9cfbd center 30%/cover no-repeat;filter:sepia(.28) saturate(.9) contrast(1.03)}',
    '.nf-df-clip{position:absolute;top:-22px;left:16px;width:22px;height:56px;transform:rotate(7deg);filter:drop-shadow(1px 2px 1px rgba(0,0,0,.25))}',
    '.nf-df-data{position:relative;display:inline-block;margin:0 0 20px;padding:0 6px 5px;font:700 24px/1.1 "DM Caveat","Caveat","Segoe Print",cursive;color:#7a5634}',
    '.nf-df-data::after{content:"";position:absolute;left:0;right:0;bottom:0;height:3px;border-radius:2px;background:#C42B38;opacity:.6;transform:rotate(-1deg)}',
    '.nf-df-r.nf-df-attacco{margin-bottom:2px}.nf-df-r.nf-df-stretto{margin-bottom:14px}',
    '.nf-df-vecchia{text-decoration:line-through;text-decoration-color:rgba(196,43,56,.75);text-decoration-thickness:2px;color:#806a55}',
    '.nf-df-nuova{font-weight:700;color:#2b1f14;padding:0 4px;border-radius:4px;background:rgba(140,198,255,.45);-webkit-box-decoration-break:clone;box-decoration-break:clone}',
    'body.dark .nf-df-vecchia{color:#806a55 !important}body.dark .nf-df-nuova{color:#2b1f14 !important}',
    '.nf-df-r{margin:0 0 18px;font:500 23px/1.3 "DM Caveat","Caveat","Segoe Print",cursive;color:#3b2d20;text-wrap:balance;opacity:0;animation:nfDfInchiostro .75s ease-out both;animation-delay:calc(.75s + var(--i,0) * .28s)}',
    '@keyframes nfDfInchiostro{0%{opacity:0;clip-path:inset(-24px 100% -24px -24px);filter:blur(1.5px)}35%{opacity:1}100%{opacity:1;clip-path:inset(-24px -24px -24px -24px);filter:none}}',
    '.nf-df-r.nf-df-ehi{margin-bottom:12px;font-size:40px;font-weight:700;line-height:1.05;color:#2b1f14}',
    '.nf-df-r.nf-df-calda{margin:26px 0 4px;font-size:24px;font-weight:600;color:#5a4030}',
    '.nf-df-r.nf-df-id{margin-bottom:24px;font-size:27px;font-weight:700;line-height:1.18;color:#0B4F9C}',
    '.nf-df-id::after{content:"";display:block;width:56%;height:3px;margin:10px auto 0;border-radius:2px;background:#C42B38;opacity:.75;transform:rotate(-1.5deg)}',
    '.nf-df-strappo{position:relative;margin:0 4px 26px;padding:18px 14px 12px;background:#fbf6e6;background-image:repeating-linear-gradient(0deg,rgba(90,110,150,0) 0 25px,rgba(90,110,150,.14) 25px 26px);box-shadow:0 4px 10px rgba(60,40,20,.2);transform:rotate(1.2deg)}',
    '.nf-df-strappo small{display:block;margin-bottom:6px;font:600 20px/1.2 "DM Caveat","Caveat","Segoe Print",cursive;color:#7a5634}',
    '.nf-df-strappo p{margin:0 0 6px;font:500 20.5px/1.25 "DM Caveat","Caveat","Segoe Print",cursive;color:#3b2d20}',
    '.nf-df-scotch{position:absolute;left:50%;top:-10px;width:70px;height:20px;margin-left:-35px;background:rgba(235,214,150,.78);transform:rotate(-3deg);box-shadow:0 1px 2px rgba(0,0,0,.15)}',
    '.nf-df-r.nf-df-firma{margin:6px 0 0;font-size:26px;font-weight:700;color:#2b1f14;transform:rotate(-2deg)}',
    'body.dark .nf-df-pag,body.dark .nf-df-r,body.dark .nf-df-strappo p{color:#3b2d20 !important}body.dark .nf-df-r.nf-df-ehi,body.dark .nf-df-r.nf-df-firma{color:#2b1f14 !important}body.dark .nf-df-r.nf-df-id{color:#0B4F9C !important}body.dark .nf-df-r.nf-df-calda{color:#5a4030 !important}body.dark .nf-df-data,body.dark .nf-df-strappo small{color:#7a5634 !important}',
    '.nf-df-btn{margin-top:26px;opacity:0;animation:nfEntra .5s ease both;animation-delay:calc(.75s + var(--i,0) * .28s)}.nf-df-btn .nf-cta{margin-top:0}',
    '.nf-df.subito .nf-df-pag,.nf-df.subito .nf-df-pag::after,.nf-df.subito .nf-df-r,.nf-df.subito .nf-df-btn{animation:none !important;opacity:1}.nf-df.subito .nf-df-pag::after{opacity:0}.nf-df.subito .nf-df-r{clip-path:none;filter:none}',
    '@media (prefers-reduced-motion:reduce){.nf-df-pag,.nf-df-pag::after,.nf-df-r,.nf-df-btn{animation:none !important;opacity:1}.nf-df-pag::after{opacity:0}}',
    '.nf-volto{width:120px;height:120px;border-radius:50%;background-size:cover;background-position:center 30%;box-shadow:0 0 0 4px #fff,0 0 0 7px #3F9FF4,0 0 40px rgba(63,159,244,.55)}.nf-volto.grande{width:170px;height:170px;margin:10px 0}.nf-volto.piccolo{width:92px;height:92px}',
    '.nf-volto.vuoto{display:grid;place-items:center;font-size:48px;background:linear-gradient(160deg,#5BB2FF,#0B4F9C)}',
    '.nf-regole .nf-tab{display:flex;align-items:center;justify-content:center;gap:22px;margin:4px 0 6px;padding:14px;border-radius:22px;background:linear-gradient(160deg,#0E2350,#0B3E86);color:#fff}',
    '.nf-tab div{text-align:center}.nf-tab small{display:block;font:800 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.nf-tab b{font:900 36px var(--font-display);color:#5BB2FF}.nf-tab b.rosso{color:#FF6B76}.nf-tab i{font-style:normal;font:800 13px var(--font-body);color:rgba(255,255,255,.5)}',
    '.nf-card{margin-top:12px;padding:6px 16px 14px;border-radius:22px;border:1.5px solid var(--line);background:var(--card,#fff)}body.dark .nf-card{background:#12203A;border-color:#22345A}',
    '.nf-mod{display:block;font:900 19px var(--font-display);color:var(--navy)}body.dark .nf-mod{color:#fff}',
    '.nf-p{margin:6px 0 4px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.nf-reg{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-top:1px solid var(--line);font:600 14px/1.4 var(--font-body);color:var(--navy)}body.dark .nf-reg{color:#fff;border-color:#22345A}.nf-reg small{display:block;font:500 12px var(--font-body);color:var(--muted)}.nf-reg b{color:#0075E3;white-space:nowrap}.nf-reg b.rosso{color:#E63946}',
    '.nf-vince{display:flex;gap:10px;align-items:flex-start;margin:8px 0}.nf-vince span{font-size:20px}.nf-vince p{margin:0;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .nf-vince p{color:#fff}',
    '.nf-voto{margin:8px 0 0;font:700 15px/1.45 var(--font-body);color:var(--navy)}body.dark .nf-voto{color:#fff}',
    '.nf-check{display:flex;align-items:center;gap:10px;margin-top:14px;font:700 14px var(--font-body);color:var(--navy)}body.dark .nf-check{color:#fff}.nf-check input{width:20px;height:20px;accent-color:#0075E3}',
    '.nf-link{display:block;margin:10px auto 0;border:0;background:none;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}',
    '.nf-notion{display:flex;align-items:center;gap:12px;width:100%;margin-top:18px;padding:16px;border:1.5px solid var(--line);border-radius:20px;background:var(--card,#fff);text-align:left;cursor:pointer}body.dark .nf-notion{background:#12203A;border-color:#22345A}',
    '.nf-notion > span{font-size:28px}.nf-notion div{flex:1}.nf-notion b{display:block;font:800 15.5px var(--font-body);color:var(--navy)}body.dark .nf-notion b{color:#fff}.nf-notion small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.nf-attesa{display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:30px}.nf-attesa p{font:600 16px var(--font-body);color:var(--muted)}'
  ].join('');
  document.head.appendChild(st);
  /* il font a mano della pagina dal futuro si carica subito: quando la pagina si apre e' gia' pronto */
  try{ if (document.fonts && document.fonts.load) document.fonts.load('500 23px "DM Caveat"'); }catch(_){ }
})();
