/* blocco.js - corsia U-A · BLOCCO E PROGRAMMI.
 *
 * Everything that decides what gets blocked and when: the engine status banner, the Quick
 * Block (its own screen, its own lists, its own on/off), the programs with real schedules
 * (hours, weekdays, "all day", usage quotas), the nine ready-made templates, the
 * blocklist/allowlist selector and the four "Opzioni extra" flags.
 *
 * WHY THIS FILE OWNS SO MUCH STATE
 * The old version kept programs in localStorage and sent the engine the flat UNION of every
 * program's apps and keywords. That made an 08:00-16:00 program and a permanent one produce
 * exactly the same rules: the schedule existed only on screen. The engine now has Schedule,
 * so a program is sent whole - hours, days, quotas - and the union is gone. localStorage is
 * still written, but only as a mirror for the browser preview: the engine is the truth.
 *
 * SCREENS ARE REGISTERED HERE, NOT IN index.html: six lanes edit that file at once, so each
 * area adds its own markup at load time through registry.js.
 *
 * LOAD ORDER: this file runs before nav.js, so nothing here may call toast()/goId()/esc() at
 * load time - only inside handlers, which run later. That is why blkEsc() exists.
 */

/* ================= 0 · HELPERS THAT MUST WORK AT LOAD TIME ================= */

/* nav.js (which owns esc) is loaded last on purpose. The markup below is built while this
   file loads, so it needs an escaper of its own. */
/* ---------------------------------------------------------------------------------------
   La favicon di un sito, chiesta AL SITO STESSO.

   Nessun servizio di terze parti (Google, DuckDuckGo): quelli vedrebbero l'elenco dei siti
   che una persona sta bloccando, che è esattamente la cosa che questa app non fa uscire dal
   telefono. Si chiede https://dominio/favicon.ico e basta; se non c'è, resta l'iniziale.
   --------------------------------------------------------------------------------------- */
function flFavHost(v){
  const h = String(v == null ? '' : v).trim().toLowerCase()
    .replace(/^https?:\/\//, '').split(/[\/?#]/)[0];
  return (h && h.indexOf('.') > 0 && !/\s/.test(h)) ? h : '';
}
function flFavHtml(v, cls){
  const host = flFavHost(v);
  const letter = (String(v == null ? '?' : v).replace(/^www\./, '').charAt(0) || '?').toUpperCase();
  const base = '<span class="fav' + (cls ? ' ' + cls : '') + '">' + blkEsc(letter);
  if (!host) return base + '</span>';
  // Due tentativi: il dominio, e poi lo stesso con "www." davanti — instagram.com non
  // risponde, www.instagram.com sì, ed è la differenza fra un'icona e un'iniziale.
  const alt = host.indexOf('www.') === 0 ? '' : 'https://www.' + host + '/favicon.ico';
  const onerr = alt
    ? 'if(this.dataset.t){this.remove()}else{this.dataset.t=1;this.src=&quot;' + blkEsc(alt) + '&quot;}'
    : 'this.remove()';
  return base + '<img alt="" loading="lazy" src="https://' + blkEsc(host) + '/favicon.ico"'
    + ' onload="this.classList.add(\'on\')" onerror="' + onerr + '"></span>';
}
(function favStyle(){
  const st = document.createElement('style');
  st.textContent = '.fav{position:relative;display:inline-flex;align-items:center;justify-content:center;'
    + 'width:22px;height:22px;flex:none;border-radius:6px;background:var(--blue-soft);color:var(--blue);'
    + 'font:800 11px var(--font-body);overflow:hidden}'
    + '.fav img{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:contain;background:#fff;opacity:0;transition:opacity .2s}'
    + '.fav img.on{opacity:1}'
    + '.fav.big{width:34px;height:34px;border-radius:9px;font-size:15px}'
    + '.blk-chip .fav{width:15px;height:15px;border-radius:4px;font-size:8px;margin-right:5px}'
    + 'body.dark .fav{background:#12203A;color:#9EC1FF}';
  document.head.appendChild(st);
})();

function blkEsc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}

/* Every call to the plugin goes through here. Two failure modes have to stay distinct:
   NATIVE missing (browser preview - the feature degrades, no error is shown) and a method
   that rejects (Modalita severa refusing a change, bad arguments - the user must read the
   engine's own message, which is already in Italian, not a generic "non riuscito"). */
async function blkNative(method, args, silent){
  if(!NATIVE || typeof NATIVE[method] !== 'function') return null;
  try{
    return await NATIVE[method](args || {});
  }catch(e){
    const msg = (e && (e.message || e.errorMessage)) || 'Operazione non riuscita';
    /* 0.9.302: il contratto di abitudine protegge la regola: si offre l'attesa invece di un messaggio e basta */
    if(e && e.code === 'contract-wait' && !silent && typeof ctrRifiuto === 'function'){ ctrRifiuto(e); return null; }
    if(!silent && typeof toast === 'function') toast(msg);
    console.warn('[blocco] ' + method + ' rifiutato', e && e.code, msg);
    return null;
  }
}
function blkHasNative(method){ return !!(NATIVE && typeof NATIVE[method] === 'function'); }

/* ================= 1 · STILE (prefisso blk-, niente collisioni) ================= */
(function blkStyle(){
  const css = `
  .blk-title{font:800 17px var(--font-display);font-style:italic;color:var(--navy)}
  #s-newtype .topbar{position:relative}#s-newtype .nt-snd-tit{position:absolute;left:52px;right:52px;margin:0 !important;text-align:center}#s-newtype.snd-mode > h2{display:none}body.dark .nt-snd-tit{color:#fff}
  .blk-right{margin-left:auto}
  .blk-gear{margin-left:10px;border:0;background:none;font-size:17px;cursor:pointer;color:var(--muted);line-height:1}
  .blk-quicklink{width:100%;margin:0 0 10px;border:1px dashed var(--line);background:#fff;border-radius:12px;
    padding:11px;font:700 12px var(--font-body);color:var(--blue);cursor:pointer;text-align:left}
  .blk-quicklink .chev{float:right;color:var(--faint)}

  .blk-moderow{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:14px;margin-bottom:10px;cursor:pointer}
  .blk-modetxt b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}
  .blk-modetxt small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:2px}
  .blk-chevbtn{margin-left:auto;flex:none;width:30px;height:30px;border-radius:50%;background:var(--blue-soft);
    color:var(--blue);display:grid;place-items:center;font:800 13px var(--font-body)}

  .blk-chips{display:flex;flex-wrap:wrap;gap:6px;margin:-4px 0 10px;padding:0 2px}
  /* IL COLORE DEL TEMA, QUI, non in un correttivo a parte: #fff fisso con il testo in
     --navy era bianco su bianco di notte, e lo e' rimasto cinque volte perche' il rimedio
     stava in un altro foglio. La carta e' --card, il bordo --line: seguono il tema da soli. */
  .blk-chip{display:inline-flex;align-items:center;gap:5px;font:600 10.5px var(--font-body);color:var(--navy);
    background:var(--card,#fff);border:1px solid var(--line);border-radius:99px;padding:4px 10px;max-width:100%}
  body.dark .blk-chip{background:#141C2C;color:#E8F1FF;border-color:#25314A}
  .blk-chip i{font-style:normal;color:var(--blue)}
  .blk-chip.more{color:var(--muted);background:var(--line)}
  body.dark .blk-chip.more{background:#1B2540;color:#9FB6CF}

  .blk-opt{display:flex;align-items:flex-start;gap:11px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:13px;margin-bottom:8px}
  .blk-opt .oi{width:30px;height:30px;flex:none;border-radius:9px;background:var(--blue-soft);color:var(--blue);
    display:grid;place-items:center;font:800 11px var(--font-body)}
  .blk-opt .ot{flex:1}
  .blk-opt b{display:block;font:700 13px var(--font-body);color:var(--navy)}
  .blk-opt small{display:block;font:500 11px/1.5 var(--font-body);color:var(--muted);margin-top:3px}
  .blk-opt .switch{margin-top:3px}

  .blk-daysbox{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px;margin-top:10px}
  .blk-days{display:flex;gap:6px;justify-content:space-between}
  .blk-day{flex:1;height:36px;border-radius:10px;border:1.5px solid var(--line);background:#fff;
    font:700 12px var(--font-body);color:var(--muted);cursor:pointer;transition:all .15s}
  .blk-day.on{background:var(--blue);border-color:var(--blue);color:#fff}
  .blk-presets{display:flex;gap:6px;margin-top:10px}
  .blk-preset{flex:1;border:1px solid var(--line);background:var(--bg);border-radius:99px;padding:6px 4px;
    font:700 10.5px var(--font-body);color:var(--navy);cursor:pointer}
  .blk-swrow{display:flex;align-items:center;gap:10px;margin-top:12px;font:700 13px var(--font-body);color:var(--navy)}
  .blk-swrow small{display:block;font:500 11px var(--font-body);color:var(--muted);margin-top:2px}
  .blk-swrow .switch{margin-left:auto}

  /* One long line, ellipsised: a schedule plus two counters wraps and pushes the pill out of
     the row on a 360px screen. */
  .blk-prog small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .blk-prog>div{min-width:0}
  .blk-soon{opacity:.55}
  .blk-soon small{color:var(--faint);font:800 9.5px var(--font-body);letter-spacing:.5px}

  .blk-tplhead{display:flex;align-items:center;gap:10px;margin:30px 0 8px;cursor:pointer}
  .blk-tplhead b{font:800 20px var(--font-display);color:var(--navy)}
  .blk-tplhead small{display:block;font:500 11px/1.5 var(--font-body);color:var(--muted);margin-top:2px}
  .blk-tplchev{margin-left:auto;color:var(--muted);transition:transform .2s}
  .blk-tplchev.closed{transform:rotate(180deg)}
  .blk-quote{}
  .blk-tplwrap{margin-bottom:6px}
  .blk-tplwrap[hidden]{display:none}
  .blk-inhead{cursor:default;margin-top:34px}
  /* Tutto al centro, come l'intestazione che ha sopra: un pannello in cui il badge sta a
     sinistra e il titolo pure e' una colonna di roba allineata a caso. */
  .blk-doom{background:linear-gradient(160deg,#12203A,#1E3A6B);border-radius:20px;padding:22px 18px;margin:0 0 4px;color:#fff;cursor:pointer;text-align:center}
  .blk-doom-badge{display:inline-block;background:rgba(255,255,255,.16);color:#fff;font:800 9.5px var(--font-body);letter-spacing:.8px;padding:6px 11px;border-radius:8px}
  .blk-doom b{display:block;font:800 18px/1.2 var(--font-display);margin:16px 0 8px;color:#fff}
  .blk-doom p{font:500 12.5px/1.55 var(--font-body);color:#C8DAF2;margin:0 auto 20px;max-width:24em}
  .blk-doom .cta{width:100%;background:#0075E3;display:inline-flex;align-items:center;justify-content:center;gap:9px}
  .blk-inintro{padding:44px 0 14px}
  .blk-inintro h2{text-transform:none}
  /* Same stack as a program card: icon on top, everything centred. A template is a
     program the user has not made yet, and it should look like one. */
  .blk-tpl{position:relative;background:#fff;border:1px solid var(--line);border-radius:18px;
    padding:22px 18px 18px;margin-top:10px;text-align:center;box-shadow:0 2px 10px rgba(0,30,68,.05)}
  .blk-trend{position:relative;background:linear-gradient(160deg,#001E44,#0E2350 60%,#005BB0);border-radius:22px;padding:16px 16px 14px;margin-bottom:8px;color:#fff}
  .blk-trend-badge{display:inline-block;background:#E63946;color:#fff;font:800 10px var(--font-body);letter-spacing:.6px;padding:5px 10px;border-radius:8px}
  .blk-trend > b{display:block;font:800 19px/1.2 var(--font-display);margin:10px 0 4px;color:#fff}
  .blk-trend > p{font:500 12.5px/1.5 var(--font-body);color:#BCE0FF;margin:0 0 12px}
  .blk-trend-x{position:absolute;top:12px;right:12px;background:none;border:0;color:#fff;font-size:18px;cursor:pointer;padding:4px 8px}
  .blk-trend .blk-tpl{margin-bottom:0;background:#0F2041;border-color:#14234A;color:#fff}
  .blk-trend .blk-tpl b{color:#fff}
  .blk-trend .blk-tpl small{color:#BCE0FF}
  .blk-tpl .tem{display:block;font-size:34px;line-height:1;margin-bottom:10px}
  .blk-tpl b{display:block;font:800 16px var(--font-display);color:var(--navy)}
  .blk-tpl small{display:block;font:500 12px/1.6 var(--font-body);color:var(--muted);margin-top:4px}
  .blk-trg{display:inline-flex;align-items:center;gap:4px;font:700 9px var(--font-body);letter-spacing:.4px;
    text-transform:uppercase;border-radius:99px;padding:3px 8px;margin-bottom:14px}
  .blk-trg.clock{background:var(--blue-soft);color:var(--blue)}
  .blk-trg.hour{background:#FFF3E0;color:#B26A00}
  .blk-trg.geo{background:#EDF1F6;color:var(--faint)}
  .blk-add{position:absolute;top:12px;right:12px;width:28px;height:28px;border-radius:50%;border:0;
    background:var(--blue);color:#fff;font:800 17px var(--font-body);line-height:1;cursor:pointer}
  .blk-add.off{background:var(--bg);color:var(--faint);border:1px solid var(--line);font-size:10px;width:auto;
    padding:0 9px;border-radius:99px;font-weight:800;height:22px}
  .blk-quote{font:italic 500 11.5px/1.55 var(--font-body);color:var(--muted);margin:6px 4px 0;text-align:center}

  .blk-sw{position:absolute;inset:0;z-index:95;pointer-events:none}
  .blk-base{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px;margin:12px 0}
  .blk-base-h{display:flex;align-items:baseline;gap:8px}
  .blk-base-h b{font:700 14px var(--font-display);color:var(--navy)}
  .blk-base-h span{margin-left:auto;font:600 11.5px var(--font-body);color:var(--blue)}
  .blk-base p{font:500 11.5px/1.6 var(--font-body);color:var(--muted);margin:6px 0 10px}
  .blk-sw .blk-scrim{position:absolute;inset:0;background:rgba(0,19,43,.5);opacity:0;transition:opacity .3s}
  .blk-sw .blk-sheet{position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:24px 24px 0 0;
    padding:16px 18px calc(20px + env(safe-area-inset-bottom));transform:translateY(102%);transition:transform .32s;
    max-height:82%;overflow-y:auto}
  .blk-sw.open{pointer-events:auto}
  .blk-sw.open .blk-scrim{opacity:1}
  .blk-sw.open .blk-sheet{transform:none}
  .blk-sw .grab{width:44px;height:5px;border-radius:99px;background:#DCE8F5;margin:0 auto 14px}
  .blk-sw h3{font:800 17px var(--font-display);font-style:italic;color:var(--navy);text-align:center}
  .blk-ssub{font:500 12px/1.6 var(--font-body);color:var(--muted);text-align:center;margin:6px 10px 16px}
  .blk-trow{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:13px;margin-bottom:9px}
  .blk-trow .blk-tico{font-size:18px;width:26px;text-align:center;flex:none}
  .blk-trow b{font:700 13.5px var(--font-body);color:var(--navy)}
  .blk-trow small{display:block;font:500 11px var(--font-body);color:var(--muted)}
  .blk-trow .switch{margin-left:auto}

  .blk-modecard{display:flex;gap:12px;align-items:flex-start;background:#fff;border:2px solid var(--line);
    border-radius:16px;padding:14px;margin-bottom:10px;cursor:pointer}
  .blk-modecard.sel{border-color:var(--blue);background:var(--blue-soft)}
  .blk-modecard .mi{font-size:22px;flex:none}
  .blk-modecard b{display:block;font:800 14px var(--font-display);color:var(--navy)}
  .blk-modecard small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:3px}

  .blk-qlmode{display:flex;align-items:center;gap:8px;width:100%;margin:8px 0 0;padding:12px;background:#fff;
    border:1px solid var(--line);border-radius:12px;font:600 12px var(--font-body);color:var(--muted);cursor:pointer}
  .blk-qlmode b{margin-left:auto;font:700 12px var(--font-body);color:var(--blue)}
  .blk-modepick{display:flex;gap:14px;margin:8px 2px 0;font:600 12px var(--font-body);color:var(--navy)}
  .blk-modepick label{display:flex;align-items:center;gap:6px}
  .blk-modepick input{accent-color:var(--blue)}
  `;
  const tag = document.createElement('style');
  tag.id = 'blk-style';
  tag.textContent = css;
  document.head.appendChild(tag);
})();

/* ================= 2 · STATO ================= */

/* Programs are still mirrored in localStorage so the browser preview has something to draw,
   but the engine's schedules are the authority: loadFromEngine() overwrites this list on a
   real device. */
let PROGRAMS = JSON.parse(localStorage.getItem('fl_programs') || '[]');
let DRAFT = null;                                   // program being created/edited
let QUICK = { enabled:false, apps:[], sites:[], keywords:[] };

/* The flags that live in Rules and apply to the whole engine, not to one program:
   list mode, the four "Opzioni extra" and the Lancia/Notifiche pair. */
let EXTRA = {
  enabled:true, listMode:'blocklist', allowApps:[],
  blockNewlyInstalled:false, blockUnsupportedBrowsers:false, blockAdult:false, blockReinstalled:false,
  blockPurchases:false, searchTyping:false,
  blockLaunch:true, blockNotifications:true
};

let QL_TAB = 'app';            // which tab of the quick-block list screen is open
let QL_APPS = [];              // installed apps, read once per visit
let SET_TARGET = 'quick';      // whose Lancia/Notifiche the bottom sheet is editing
let MODE_TARGET = 'quick';
let TPL_OPEN = localStorage.getItem('fl_tpl_open') !== '0';

const DAY_SHORT = ['L','M','M','G','V','S','D'];
const DAY_LONG  = ['lunedì','martedì','mercoledì','giovedì','venerdì','sabato','domenica'];

function saveProgramsLocal(){ localStorage.setItem('fl_programs', JSON.stringify(PROGRAMS)); }

/* The engine is the source of truth for programmes; localStorage is only its cache.

   Until now they were two independent copies. Anything that changed the engine without
   going through this screen - a restore from Drive, a restore from a file, Android putting
   the app back on a new phone - left the engine full and the dashboard empty, and the user
   staring at "no programmes" while the blocks fired. Reading the engine on every start and
   every return to the foreground is what makes a backup restore actually appear. The only
   thing the cache still owns is the icon, which the engine has no field for. */
function scheduleToProgram(sc, iconOf){
  return {
    id: sc.id, name: sc.name || 'Programma', type: sc.type || 'sempre',
    icon: iconOf[sc.id] || (BLK_TYPE_ICON[sc.type] || '🚫'),
    from: sc.from || '00:00', to: sc.to || '00:00',
    days: (Array.isArray(sc.days) && sc.days.length === 7) ? sc.days : [true,true,true,true,true,true,true],
    allDay: !!sc.allDay,
    qh: sc.quotaHourMin || null, qd: sc.quotaDayMin || null,
    /* 0.9.291, Andrea: "il programma duplicato si cambia nei due minuti ma non si elimina". Rileggendo i programmi dal
       motore la tolleranza si perdeva, e la copia risultava gia' chiusa a chiave: ora torna indietro con lui. */
    grazia: +sc.grazia || 0,
    rimastoMs: typeof sc.rimastoMs === 'number' ? sc.rimastoMs : null, rimastoAl: +sc.rimastoAl || 0,
    apps: sc.apps || [], sites: sc.sites || [], keywords: sc.keywords || [], allow: sc.allow || [],
    redirectUrl: sc.redirectUrl || '',
    wifi: Array.isArray(sc.wifi) ? sc.wifi : [],
    places: Array.isArray(sc.places) ? sc.places : [],
    useTime: sc.useTime !== false, useWifi: !!sc.useWifi, usePlace: !!sc.usePlace, useLimit: !!sc.useLimit,
    activeNow: !!sc.activeNow,
    blockLaunch: sc.blockLaunch !== false, blockNotifications: sc.blockNotifications !== false,
    on: sc.enabled !== false
  };
}
const BLK_TYPES = [
  { k:'ora',       ico:'🕑', name:'Ora',                        desc:'Attivo solo nei giorni e nella fascia oraria che scegli qui sotto.' },
  { k:'limite',    ico:'⏳', name:'Limite di utilizzo',          desc:'Concede un tot di minuti, poi blocca.' },
  { k:'sempre',    ico:'🚫', name:'Permanente',                  desc:'Sempre attivo, senza orari.' },
  { k:'wifi',      ico:'📶', name:'Wi-Fi',                       desc:'Attivo quando il telefono è connesso a una delle reti Wi-Fi scelte.' },
  { k:'posizione', ico:'📍', name:'Posizione',                   desc:'Attivo quando il telefono si trova in uno dei luoghi scelti.' },
  { k:'combo',     ico:'🧩', name:'Combinazione personalizzata', desc:'Attivo solo quando tutte le condizioni accese qui sotto sono vere insieme.' }
];
const BLK_TYPE_ICON = {}, BLK_TYPE_NAME = {}, BLK_TYPE_DESC = {};
BLK_TYPES.forEach(function(t){ BLK_TYPE_ICON[t.k] = t.ico; BLK_TYPE_NAME[t.k] = t.name; BLK_TYPE_DESC[t.k] = t.desc; });
/* SOLO PER I PROGRAMMI DEI SUONI (0.9.181): il suono parte mentre usi un'app o un sito. Il
   «permanente» e il «limite di utilizzo» li' non hanno senso, e nel foglio non compaiono. */
const BLK_TYPE_APP = { k:'app', ico:'📲', name:'Mentre usi un\u2019app o un sito', desc:'Il suono parte quando apri una delle app o dei siti scelti, e si ferma quando li lasci.' };
BLK_TYPE_ICON.app = BLK_TYPE_APP.ico; BLK_TYPE_NAME.app = BLK_TYPE_APP.name; BLK_TYPE_DESC.app = BLK_TYPE_APP.desc;
function blkTipiDisponibili(){
  if (DRAFT && DRAFT.sound) return BLK_TYPES.filter(function(t){ return t.k !== 'sempre' && t.k !== 'limite'; }).concat([BLK_TYPE_APP]);
  return BLK_TYPES;
}

async function hydrateProgramsFromEngine(){
  if(!blkHasNative('getSchedules')) return false;
  const r = await blkNative('getSchedules', {}, true);
  if(!r || !Array.isArray(r.schedules)) return false;
  const iconOf = {};
  PROGRAMS.forEach(function(p){ if(p && p.id && p.icon) iconOf[p.id] = p.icon; });
  const fresh = r.schedules.map(function(sc){ return scheduleToProgram(sc, iconOf); });
  PROGRAMS.length = 0;
  fresh.forEach(function(p){ PROGRAMS.push(p); });
  saveProgramsLocal();
  return true;
}

// On start and on every return from the background: a restore may have happened meanwhile.
(async function blkHydrateBoot(){
  try{ if(await hydrateProgramsFromEngine() && typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  try{ await blkLoadInstalled(); }catch(_){ }
})();
// The blue ring means "blocking right now", and "now" moves: re-read once a minute while the
// home is on screen, so a programme that started at 20:00 lights up at 20:00.
setInterval(async function(){
  const home = document.getElementById('s-home');
  const tab = document.getElementById('tab-blocco');
  if(!home || !home.classList.contains('active') || !tab || !tab.classList.contains('on')) return;
  try{ if(await hydrateProgramsFromEngine()) renderPrograms(); }catch(_){ }
}, 60000);
document.addEventListener('visibilitychange', async function(){
  if(document.hidden) return;
  try{ if(await hydrateProgramsFromEngine()) renderPrograms(); }catch(_){ }
});

/* A program without an id cannot be matched to the engine's schedule on the next save: the
   engine would grow a duplicate on every push. Old programs get one here, once. */
function blkEnsureIds(){
  let dirty = false;
  PROGRAMS.forEach(function(p){
    if(!p.id){ p.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); dirty = true; }
    if(!Array.isArray(p.days) || p.days.length !== 7){ p.days = [true,true,true,true,true,true,true]; dirty = true; }
  });
  if(dirty) saveProgramsLocal();
}
blkEnsureIds();

/* ================= 3 · SCHERMATE E OVERLAY ================= */

registerScreen('s-quick', `
  <div class="topbar">
    <button class="iconbtn" onclick="closeQuick()">✕</button>
    <b class="blk-title">Blocco rapido</b>
    <button class="iconbtn blk-right" onclick="openBlockSettings('quick')">⚙</button>
  </div>

  <div class="blk-moderow" onclick="openModeSheet('quick')">
    <div class="blk-modetxt">
      <b id="qkModeName">Lista di blocco</b>
      <small id="qkModeDesc">Seleziona app, siti web e parole chiave che desideri bloccare.</small>
    </div>
    <span class="blk-chevbtn">⌄</span>
  </div>

  <div class="setrow" onclick="openQuickList('app')"><span>📱</span><b>Applicazioni</b><small id="qkNApps">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipApps"></div>
  <div class="setrow" onclick="openQuickList('web')"><span>🌐</span><b>Siti web</b><small id="qkNSites">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipSites"></div>
  <div class="setrow" onclick="openQuickList('kw')"><span>🔤</span><b>Parole chiave</b><small id="qkNKw">0</small><span class="chev"></span></div>
  <div class="blk-chips" id="qkChipKw"></div>

  <div class="sect"><b>Opzioni extra</b></div>
  <div class="hintline">Valgono per tutti i tuoi blocchi, non solo per questo.</div>
  <div id="qkExtra"></div>

  <div class="spacer"></div>
  <button class="cta" onclick="saveQuick()">Salva</button>
`, { back:'s-home' });

registerScreen('s-qlist', `
  <div class="topbar"><button class="iconbtn" onclick="goId('s-quick')">‹</button><b class="blk-title" id="qlTitle">Lista di blocco</b></div>
  <div class="bltabs">
    <button class="bltab on" data-ql="app" onclick="qlTab('app')">App</button>
    <button class="bltab" data-ql="web" onclick="qlTab('web')">Web</button>
    <button class="bltab" data-ql="kw" onclick="qlTab('kw')">Parole chiave</button>
  </div>

  <div id="ql-app">
    <input class="fin" id="qlSearch" placeholder="Cerca un'app…" oninput="renderQlApps()" autocomplete="off">
    <div id="qlAppList" class="picklist"></div>
  </div>
  <div id="ql-web" hidden>
    <div class="addrow"><input class="fin" id="qlWebIn" placeholder="es. instagram.com" autocomplete="off"><button class="addbtn" onclick="qlAdd('web')">+</button></div>
    <div id="qlWebList" class="picklist"></div>
  </div>
  <div id="ql-kw" hidden>
    <div class="addrow"><input class="fin" id="qlKwIn" placeholder="es. porn" autocomplete="off"><button class="addbtn" onclick="qlAdd('kw')">+</button></div>
    <div class="blk-opt" style="margin-top:10px"><span class="oi">🔎</span>
      <div class="ot"><b>Blocca ricerche e contenuti in tutte le app</b><small>Se scrivi una di queste parole nella barra di ricerca di qualsiasi app, o se compare in un risultato, in un profilo o in un titolo, l'app viene chiusa. Vale per tutti i programmi e per il Blocco rapido.</small></div>
      <button class="switch" id="qlSearchSw" onclick="toggleExtra('searchTyping')"></button></div>
    <!-- Same control as the program editor: three match types, and every row can change its
         own afterwards. Two radio buttons here meant the Quick Block could not reach "nel
         contenuto della pagina" and could never correct a word once added. -->
    <button type="button" class="ub-modebtn blk-qlmode" onclick="qlOpenMode(null)">
      <span>Tipo di corrispondenza</span><b id="qlKwModeLbl">Nel dominio</b><i class="ub-caret"></i></button>
    <div class="hintline" id="qlKwModeHint"></div>
    <div id="qlKwList" class="picklist"></div>
  </div>

  <div class="spacer"></div>
  <button class="cta" onclick="goId('s-quick')">Salva</button>
`, { back:'s-quick' });

/* Bottom sheet "Impostazioni" (G03) - what is blocked for the selected apps. */
(function(){
  const el = registerOverlay('blkSetSheet', `
    <div class="blk-scrim" onclick="closeBlockSettings()"></div>
    <div class="blk-sheet">
      <div class="grab"></div>
      <h3>Impostazioni</h3>
      <p class="blk-ssub">Scegli cosa è bloccato per le tue app selezionate. Devi selezionare almeno un'opzione.</p>
      <div class="blk-trow"><span class="blk-tico">🚷</span><div><b>Avvio</b><small>L'app non si apre.</small></div>
        <button class="switch on" id="swLaunch" onclick="toggleBlockSetting('launch')"></button></div>
      <div class="blk-trow"><span class="blk-tico">🔕</span><div><b>Notifiche</b><small>Le sue notifiche non arrivano.</small></div>
        <button class="switch on" id="swNotif" onclick="toggleBlockSetting('notif')"></button></div>
      <button class="cta" style="margin-top:12px" onclick="closeBlockSettings()">Fatto</button>
    </div>
  `);
  if(el) el.className = 'blk-sw';
})();

/* Bottom sheet "Modalità Blocco" (G21/G01) - blocklist vs allowlist, AppBlock's own wording. */
(function(){
  const el = registerOverlay('blkModeSheet', `
    <div class="blk-scrim" onclick="closeModeSheet()"></div>
    <div class="blk-sheet">
      <div class="grab"></div>
      <h3>Modalità Blocco</h3>
      <p class="blk-ssub">Scegli la variante che meglio si adatta alle tue preferenze.</p>
      <div class="blk-modecard" id="mcBlock" onclick="pickListMode('blocklist')">
        <span class="mi">🚫</span>
        <div><b>Lista di blocco</b><small>Seleziona app, siti web e parole chiave che desideri bloccare.</small></div>
      </div>
      <div class="blk-modecard" id="mcAllow" onclick="pickListMode('allowlist')">
        <span class="mi">⭐</span>
        <div><b>Elenco consentiti <span class="tag prem">PRO</span></b><small>Seleziona app che desideri autorizzare. Tutte le altre saranno bloccate.</small></div>
      </div>
      <div class="hintline" style="text-align:center">La modalità vale per tutto il motore, non per un singolo blocco.</div>
      <button class="cta" onclick="closeModeSheet()">Continua</button>
    </div>
  `);
  if(el) el.className = 'blk-sw';
})();

/* ================= 4 · INNESTI NEL MARKUP CONGELATO =================
 * index.html belongs to no lane any more, so the pieces that must live inside screens
 * already written there (the Blocco tab, the program editor) are grafted in from here at
 * load time. Every insertion is guarded: if the host markup ever changes, the graft is
 * skipped instead of throwing and taking the whole module down with it. */
(function blkGraft(){

  /* ---- 4.1 Blocco tab: gear + "scegli cosa bloccare" on the Quick Block card ---- */
  const qb = document.querySelector('#tab-blocco .qb');
  if(qb){
    const head = qb.querySelector('.qbhead');
    if(head) head.insertAdjacentHTML('beforeend',
      '<button class="blk-gear" title="Impostazioni" onclick="event.stopPropagation();openBlockSettings(\'quick\')">⚙</button>');
    const btn = qb.querySelector('.startbtn');
    if(btn) btn.insertAdjacentHTML('beforebegin',
      '<button class="blk-quicklink" onclick="openQuick()">Scegli cosa bloccare<span class="chev"></span></button>');
  }

  /* La freccia del pulsante rosso "vesti la tua visione" nello slideshow del sito
   (snippets/icon.liquid, arrow-right-short). Un pulsante che porta da qualche parte lo dice
   con una freccia; scriverlo e basta lo fa sembrare un interruttore. */
const BLK_ARROW = '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" aria-hidden="true">'
  + '<path d="M4 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
  + '<path d="M12 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

/* ---- 4.2 Blocco tab: the nine templates replace the three hardcoded cards ---- */
  const tab = document.getElementById('tab-blocco');
  if(tab){
    let sect = null;
    tab.querySelectorAll('.sect').forEach(function(s){
      if(s.textContent.indexOf('Modelli') >= 0) sect = s;
    });
    const olds = tab.querySelectorAll('.prog[onclick^="useTemplate"]');
    const anchor = sect || (olds.length ? olds[0] : null);
    if(anchor){
      anchor.insertAdjacentHTML('beforebegin', `
        <div class="blk-tplhead" onclick="toggleTemplates()">
          <div><b>Modelli</b><small>Hai bisogno di idee? Dai un'occhiata a cosa piace agli utenti.</small></div>
          <span class="blk-tplchev" id="tplChev"></span>
        </div>
        <div class="blk-tplwrap" id="tplWrap"></div>
        <div class="sev-intro blk-inintro">
          <div class="sev-intro-ic">💀</div>
          <h2>Doom-scrolling apps</h2>
          <p>L'ora che perdi sta tutta nei Reels e negli Shorts. Il resto dell'app puoi tenerlo.</p>
        </div>
        <div class="blk-doom" onclick="inappOpen()">
          <span class="blk-doom-badge">🛡️ BLOCCO IN-APP</span>
          <b>Spegni la parte, non l'app</b>
          <p>Chiudi Reels, Shorts e le storie. Il resto dell'app resta com'era.</p>
          <button class="cta" type="button" onclick="event.stopPropagation();inappOpen()">Configura${BLK_ARROW}</button>
        </div>`);
      if(sect) sect.remove();
      olds.forEach(function(n){ n.remove(); });
    }
  }

  /* ---- 4.3 Program editor: days, "Tutto il giorno", openings, mode, extra options ---- */
  const quota = document.getElementById('edQuotaBox');
  if(quota) quota.insertAdjacentHTML('afterend', `
    <div class="blk-daysbox" id="edDaysBox">
      <div class="blk-days" id="edDays"></div>
      <div class="blk-presets">
        <button class="blk-preset" onclick="edDaysPreset('ogni')">Ogni giorno</button>
        <button class="blk-preset" onclick="edDaysPreset('feriali')">Giorni feriali</button>
        <button class="blk-preset" onclick="edDaysPreset('weekend')">Fine settimana</button>
      </div>
      <div class="blk-swrow" id="edAllDayRow">
        <div><b>Tutto il giorno</b><small>Attivo per l'intera giornata, senza fascia oraria.</small></div>
        <button class="switch" id="edAllDay" onclick="edToggleAllDay()"></button>
      </div>
    </div>
    <div id="edOpensBox" hidden>
      <div class="setrow blk-soon"><span>🔢</span><b>Numero aperture</b><small>PROSSIMAMENTE</small></div>
      <div class="hintline">Il motore misura i minuti di utilizzo, non ancora quante volte apri l'app: attivarlo adesso
        sarebbe un blocco che non scatta mai. Usa "Minuti al giorno" finché il conteggio delle aperture non è pronto.</div>
    </div>`);

  const ed = document.getElementById('s-editor');
  const spacer = ed ? ed.querySelector('.spacer') : null;
  if(spacer) spacer.insertAdjacentHTML('beforebegin', `
    <div class="blk-moderow" style="margin-top:12px" onclick="openModeSheet('draft')">
      <div class="blk-modetxt"><b id="edModeName">Lista di blocco</b><small id="edModeDesc">Seleziona app, siti web e parole chiave che desideri bloccare.</small></div>
      <span class="blk-chevbtn">⌄</span>
    </div>
    <div class="setrow" onclick="openBlockSettings('draft')"><span>⚙️</span><b>Cosa viene bloccato</b><small id="edWhatLbl">Avvio · Notifiche</small><span class="chev"></span></div>
    <div class="sect"><b>Opzioni extra</b></div>
    <div class="hintline">Valgono per tutti i tuoi blocchi, non solo per questo.</div>
    <div id="edExtra"></div>`);

  /* The chips under the editor's three list rows (G04) are grafted by blocklist.js, which owns
     that screen's lists: adding a second strip here would draw every item twice. Chips in the
     Quick Block screen below are ours because that screen is ours. */
})();

/* ================= 5 · I NOVE MODELLI (G09) =================
 * Names, schedules and quoted lines come from AppBlock's own screens (gap analysis §1.1.5).
 * "Ritorno a scuola" is the one card whose line was never captured, so its line is ours and
 * is marked as such in the handover rather than passed off as AppBlock's.
 * "A casa" is a location trigger: geofencing is deferred to 1.1, so the card says so instead
 * of creating a program that would never fire. */
const DISTRACTIONS = ['instagram.com','tiktok.com','facebook.com','x.com','youtube.com','reddit.com','snapchat.com'];

const TEMPLATES = {
  scuola:   {name:'Ritorno a scuola', em:'🎒', trig:'clock', when:'Giorni feriali, 08:00 – 16:00',
             quote:'Torna in classe con la testa sgombra.', mine:true,
             type:'ora', from:'08:00', to:'16:00', days:'feriali', feat:true},
  focus:    {name:'Focus', em:'🎯', trig:'clock', when:'Giorni feriali, 08:00 – 17:00',
             quote:'Rendi più efficaci le tue sessioni di studio o lavoro.',
             type:'ora', from:'08:00', to:'17:00', days:'feriali'},
  limite:   {name:'Limite app', em:'⏳', trig:'hour', when:'Ogni giorno, 30m',
             quote:'Liberati dallo scrolling infinito.',
             type:'limite', qd:30, days:'ogni'},
  tempo:    {name:'Tempo per me', em:'🫖', trig:'clock', when:'Giorni feriali, 17:00 – 18:00',
             quote:'Trai il massimo dai tuoi momenti preziosi.',
             type:'ora', from:'17:00', to:'18:00', days:'feriali'},
  casa:     {name:'A casa', em:'🏠', trig:'geo', when:'Ogni giorno, Posizione',
             quote:'Blocca le distrazioni in luoghi specifici.', soon:true},
  studio:   {name:'Ora dello studio', em:'📖', trig:'clock', when:'Giorni feriali, 16:00 – 21:00',
             quote:'Studia in tutta tranquillità.',
             type:'ora', from:'16:00', to:'21:00', days:'feriali'},
  detox:    {name:'Detox digitale', em:'🌿', trig:'clock', when:'Domenica, Tutto il giorno',
             quote:'Regalati un giorno senza telefono.',
             type:'ora', allDay:true, days:'domenica'},
  serata:   {name:'Serata', em:'🌙', trig:'clock', when:'Ogni giorno, 20:00 – 23:59',
             quote:'Per avere più facilmente dei sogni d\'oro.',
             type:'ora', from:'20:00', to:'23:59', days:'ogni'},
  mattinata:{name:'Mattinata mindful', em:'🌅', trig:'clock', when:'Giorni feriali, 06:00 – 09:00',
             quote:'Goditi la tua routine mattutina senza interruzioni.',
             type:'ora', from:'06:00', to:'09:00', days:'feriali'}
};
const TPL_ORDER = ['scuola','focus','limite','tempo','casa','studio','detox','serata','mattinata'];
const TRIG_LABEL = { clock:'🕐 Orario', hour:'⏳ Limite di utilizzo', geo:'📍 Posizione' };

function renderTemplates(){
  const wrap = document.getElementById('tplWrap');
  const chev = document.getElementById('tplChev');
  if(!wrap) return;
  wrap.hidden = !TPL_OPEN;
  if(chev) chev.className = 'blk-tplchev' + (TPL_OPEN ? ' closed' : '');
  let trendClosed = false; try{ trendClosed = localStorage.getItem('fl_trend_closed') === '1'; }catch(_){ }
  wrap.innerHTML = TPL_ORDER.map(function(k){
    const t = TEMPLATES[k];
    const btn = t.soon
      ? '<button class="blk-add off" onclick="templateSoon()">PRESTO</button>'
      : '<button class="blk-add" onclick="useTemplate(\'' + k + '\')">+</button>';
    const card = '<div class="blk-tpl">' + btn +
             '<span class="blk-trg ' + t.trig + '">' + TRIG_LABEL[t.trig] + '</span>' +
             '<span class="tem">' + t.em + '</span>' +
             '<b>' + blkEsc(t.name) + '</b><small>' + blkEsc(t.when) + '</small>' +
           '</div>';
    // AppBlock's "TENDENZA" panel around the template of the moment: a navy card with its
    // own headline, dismissable. A blue ring here meant "active", which a template never is.
    if(t.feat && !trendClosed){
      return '<div class="blk-trend">' +
        '<button class="blk-trend-x" onclick="blkTrendClose()" aria-label="Chiudi">✕</button>' +
        '<span class="blk-trend-badge">📈 TENDENZA</span>' +
        '<b>' + blkEsc(t.trendTitle || 'Modalità Studio: attivata') + '</b>' +
        '<p>' + blkEsc(t.trendSub || 'Inizia l\'anno scolastico senza distrazioni. Blocca tutte le app che ti distraggono.') + '</p>' +
        card + '</div>' +
        '<div class="blk-quote">«' + blkEsc(t.quote) + '»</div>';
    }
    return card + '<div class="blk-quote">«' + blkEsc(t.quote) + '»</div>';
  }).join('');
}
function blkTrendClose(){
  try{ localStorage.setItem('fl_trend_closed', '1'); }catch(_){ }
  renderTemplates();
}
function toggleTemplates(){
  TPL_OPEN = !TPL_OPEN;
  localStorage.setItem('fl_tpl_open', TPL_OPEN ? '1' : '0');
  renderTemplates();
}
function templateSoon(){
  toast('Trigger Posizione: arriva nella 1.1');
}

/* A template opens the editor already filled in - it is a starting point, not a program
   created behind the user's back. */
function useTemplate(kind){
  const t = TEMPLATES[kind];
  if(!t || t.soon){ templateSoon(); return; }
  DRAFT = {
    id:null, name:t.name, type:t.type, icon:t.em,
    from:t.from || '22:00', to:t.to || '08:00',
    qh:null, qd:t.qd || null,
    days:daysFromPreset(t.days), allDay:!!t.allDay,
    apps:[], sites:DISTRACTIONS.slice(), keywords:[], allow:[],
    blockLaunch:true, blockNotifications:true, on:true, idx:-1
  };
  openEditor();
}

/* ================= 6 · GIORNI, ORARI, DESCRIZIONI ================= */

function daysFromPreset(p){
  if(p === 'feriali')  return [true,true,true,true,true,false,false];
  if(p === 'weekend')  return [false,false,false,false,false,true,true];
  if(p === 'domenica') return [false,false,false,false,false,false,true];
  return [true,true,true,true,true,true,true];
}
function daysLabel(days){
  if(!Array.isArray(days) || days.length !== 7) return 'Ogni giorno';
  const on = days.filter(Boolean).length;
  if(on === 0) return 'Nessun giorno';
  if(on === 7) return 'Ogni giorno';
  const week = days[0] && days[1] && days[2] && days[3] && days[4] && !days[5] && !days[6];
  if(week) return 'Giorni feriali';
  if(!days[0] && !days[1] && !days[2] && !days[3] && !days[4] && days[5] && days[6]) return 'Fine settimana';
  if(on === 1) return DAY_LONG[days.indexOf(true)].charAt(0).toUpperCase() + DAY_LONG[days.indexOf(true)].slice(1);
  return days.map(function(d,i){ return d ? DAY_SHORT[i] : null; }).filter(Boolean).join(' ');
}
function renderEdDays(){
  const box = document.getElementById('edDays');
  if(!box || !DRAFT) return;
  box.innerHTML = DAY_SHORT.map(function(l,i){
    return '<button class="blk-day' + (DRAFT.days[i] ? ' on' : '') + '" onclick="edDay(' + i + ')">' + l + '</button>';
  }).join('');
}
/* This used to be a bare classList.toggle: the button lit up and nothing was ever stored
   (G13). It now writes into the DRAFT, which is what reaches the engine. */
function edDay(i){
  if(!DRAFT) return;
  DRAFT.days[i] = !DRAFT.days[i];
  if(!DRAFT.days.some(Boolean)){
    // Zero days would mean "never blocks" while looking armed - the worst possible failure.
    DRAFT.days[i] = true;
    toast('Serve almeno un giorno');
  }
  renderEdDays();
}
function edDaysPreset(p){
  if(!DRAFT) return;
  DRAFT.days = daysFromPreset(p);
  renderEdDays();
}
function edToggleAllDay(){
  if(!DRAFT) return;
  DRAFT.allDay = !DRAFT.allDay;
  paintEditorSchedule();
}
function paintEditorSchedule(){
  if(!DRAFT) return;
  const t = DRAFT.type, combo = t === 'combo';
  const timeOn = t === 'ora' || (combo && DRAFT.useTime);
  const wifiOn = t === 'wifi' || (combo && DRAFT.useWifi);
  const placeOn = t === 'posizione' || (combo && DRAFT.usePlace);
  const limitOn = t === 'limite' || (combo && DRAFT.useLimit);
  const sw = document.getElementById('edAllDay');
  if(sw) sw.className = 'switch' + (DRAFT.allDay ? ' on' : '');
  const time = document.getElementById('edTimeBox');
  if(time) time.hidden = !timeOn || DRAFT.allDay;
  const daysBox = document.getElementById('edDaysBox');
  if(daysBox) daysBox.hidden = (t === 'sempre' || t === 'app');
  const allRow = document.getElementById('edAllDayRow');
  if(allRow) allRow.hidden = !timeOn;
  const opens = document.getElementById('edOpensBox');
  if(opens) opens.hidden = !limitOn;
  const quota = document.getElementById('edQuotaBox');
  if(quota) quota.hidden = !limitOn;
  const cb = document.getElementById('edComboBox');
  if(cb){
    cb.hidden = !combo;
    [['edUseTime','useTime'],['edUseLimit','useLimit'],['edUsePlace','usePlace'],['edUseWifi','useWifi']].forEach(function(pair){
      const el = document.getElementById(pair[0]); if(el) el.className = 'switch' + (DRAFT[pair[1]] ? ' on' : '');
    });
    const warn = document.getElementById('edComboWarn');
    if(warn) warn.hidden = edComboCount() >= 2;
  }
  const wb = document.getElementById('edWifiBox'); if(wb) wb.hidden = !wifiOn;
  const pb = document.getElementById('edPlaceBox'); if(pb) pb.hidden = !placeOn;
  if(wifiOn) edPaintWifi();
  if(placeOn) edPaintPlaces();
  renderEdDays();
}

/* ---- Wi-Fi / posizione / combinazione: the conditions AppBlock offers beyond the clock ---- */
/* AppBlock asks for at least two: a "combination" of one condition is just that condition,
   and the four types above already cover each on its own. */
function edComboCount(){
  if(!DRAFT) return 0;
  return ['useTime','useLimit','useWifi','usePlace'].filter(function(k){ return !!DRAFT[k]; }).length;
}
function edComboToggle(key){
  if(!DRAFT || DRAFT.type !== 'combo') return;
  DRAFT[key] = !DRAFT[key];
  paintEditorSchedule();
  if(DRAFT[key] && (key === 'useWifi' || key === 'usePlace')) edEnsureLocation(key === 'usePlace');
}

/* The SSID is location data on Android: without the permission the phone reports
   "<unknown ssid>" and a Wi-Fi program would never fire. Asked here, once, when it matters. */
const ED_LOC_DISCLOSED = 'fl_loc_disclosed';
async function edEnsureLocation(wantBackground){
  if(!NATIVE || !NATIVE.requestLocationPermission) return { granted:true, background:true, preview:true };
  let p = null;
  try{ p = await NATIVE.getLocationPermission(); }catch(e){ p = null; }
  if(!(p && p.granted)){
    // Google Play's "prominent disclosure": said in our own words, before the system dialog,
    // and only once. The dialog itself never explains why an app wants the location.
    if(localStorage.getItem(ED_LOC_DISCLOSED) !== '1'){
      const ok = await blkConfirm('DreamMap usa la posizione',
        'Serve per i programmi Wi-Fi e Posizione: Android rivela il nome della rete e il luogo solo a chi ha questo permesso. '
        + 'La posizione viene letta anche quando l\'app è chiusa o non in uso, così il blocco scatta quando arrivi sul posto. '
        + 'Resta sul telefono: non viene mai inviata a nessuno.', 'Continua');
      if(!ok) return { granted:false, declined:true };
      localStorage.setItem(ED_LOC_DISCLOSED, '1');
    }
    try{ p = await NATIVE.requestLocationPermission(); }catch(e){ p = null; }
  }
  edPaintLocationHint(p, wantBackground);
  return p || { granted:false };
}
function edPaintLocationHint(p, wantBackground){
  const ids = ['edWifiPerm','edPlacePerm'];
  ids.forEach(function(id){
    const el = document.getElementById(id); if(!el) return;
    if(!p){ el.hidden = true; return; }
    if(!p.granted){
      el.hidden = false;
      el.innerHTML = '⚠️ Senza il permesso di posizione Android non rivela né la rete né il luogo: il programma non potrebbe mai scattare. '
        + '<a href="#" onclick="event.preventDefault();edEnsureLocation(true)">Concedi il permesso</a>';
    }else if(wantBackground && !p.background){
      el.hidden = false;
      el.innerHTML = 'ℹ️ Per funzionare anche a schermo spento imposta la posizione su <b>Consenti sempre</b>. '
        + '<a href="#" onclick="event.preventDefault();NATIVE&&NATIVE.openLocationSettings&&NATIVE.openLocationSettings()">Apri le impostazioni</a>';
    }else if(p.locationOn === false){
      el.hidden = false;
      el.textContent = '⚠️ La posizione del telefono è spenta: accendila dalle impostazioni rapide.';
    }else{
      el.hidden = true;
    }
  });
}

function edPaintWifi(){
  const box = document.getElementById('edWifiList'); if(!box || !DRAFT) return;
  const list = DRAFT.wifi || [];
  box.innerHTML = list.length
    ? list.map(function(ssid, i){ return '<span class="blk-chip"><i>📶</i>' + blkEsc(ssid) + ' <b style="cursor:pointer;padding-left:4px" onclick="edWifiRemove(' + i + ')">✕</b></span>'; }).join('')
    : '<span class="hintline" style="padding:0">Nessuna rete ancora. Aggiungi quella attuale o scrivi il nome.</span>';
}
function edWifiAddName(name){
  if(!DRAFT) return;
  const v = String(name || '').trim();
  if(!v){ toast('Scrivi il nome della rete'); return; }
  DRAFT.wifi = DRAFT.wifi || [];
  if(DRAFT.wifi.indexOf(v) < 0) DRAFT.wifi.push(v);
  edPaintWifi();
}
function edWifiAdd(){
  const el = document.getElementById('edWifiIn');
  edWifiAddName(el ? el.value : '');
  if(el) el.value = '';
}
function edWifiRemove(i){ if(!DRAFT || !DRAFT.wifi) return; DRAFT.wifi.splice(i, 1); edPaintWifi(); }
async function edWifiCurrent(){
  if(!NATIVE || !NATIVE.getWifiInfo){ toast('Anteprima nel browser: sul telefono qui compare la rete a cui sei connesso'); return; }
  const p = await edEnsureLocation(false);
  if(p && p.granted === false) return;
  let info = null;
  try{ info = await NATIVE.getWifiInfo(); }catch(e){ info = null; }
  if(!info || !info.current){
    toast(info && info.wifiEnabled === false ? 'Il Wi-Fi è spento' : 'Non sei connesso a nessuna rete Wi-Fi');
    return;
  }
  edWifiAddName(info.current);
  toast('Aggiunta: ' + info.current);
}
async function edWifiScan(){
  const near = document.getElementById('edWifiNear');
  if(!NATIVE || !NATIVE.getWifiInfo){ toast('Anteprima nel browser: sul telefono qui compaiono le reti vicine'); return; }
  const p = await edEnsureLocation(false);
  if(p && p.granted === false) return;
  let info = null;
  try{ info = await NATIVE.getWifiInfo(); }catch(e){ info = null; }
  const nets = (info && Array.isArray(info.networks)) ? info.networks : [];
  if(!near) return;
  if(!nets.length){ near.innerHTML = '<span class="hintline" style="padding:0">Nessuna rete visibile adesso' + (info && info.wifiEnabled === false ? ': il Wi-Fi è spento' : '') + '.</span>'; return; }
  near.innerHTML = nets.map(function(n){
    return '<button type="button" class="blk-chip" style="cursor:pointer;border:1px solid var(--line);background:#fff" onclick="edWifiAddName(' + JSON.stringify(n).replace(/"/g,'&quot;') + ')">＋ ' + blkEsc(n) + '</button>';
  }).join('');
}

const ED_RADII = [{m:100,l:'100 m'},{m:250,l:'250 m'},{m:500,l:'500 m'},{m:1000,l:'1 km'}];
let edRadiusM = 150;
function edPaintPlaces(){
  const box = document.getElementById('edPlaceList'); if(!box || !DRAFT) return;
  const list = DRAFT.places || [];
  box.innerHTML = list.length
    ? list.map(function(p, i){
        return '<div class="setrow" style="cursor:default"><span>📍</span><b>' + blkEsc(p.name || 'Luogo') + '</b>'
          + '<small>raggio ' + (p.radius >= 1000 ? (p.radius/1000) + ' km' : p.radius + ' m') + '</small>'
          + '<button type="button" class="ghostmini" style="margin-left:auto" onclick="edPlaceRemove(' + i + ')">✕</button></div>';
      }).join('')
    : '<div class="hintline" style="padding:0 0 8px">Nessun luogo ancora. Vai sul posto e tocca "Aggiungi la posizione attuale".</div>';
  const r = document.getElementById('edRadius');
  if(r) r.innerHTML = '<span class="hintline" style="padding:0;width:100%">Raggio intorno al punto</span>' + ED_RADII.map(function(o){
    return '<button type="button" class="sev-chip' + (edRadiusM === o.m ? ' on' : '') + '" onclick="edRadiusPick(' + o.m + ')">' + o.l + '</button>';
  }).join('');
}
function edRadiusPick(m){ edRadiusM = m; edPaintPlaces(); }
function edPlaceRemove(i){ if(!DRAFT || !DRAFT.places) return; DRAFT.places.splice(i, 1); edPaintPlaces(); }
async function edPlaceAddCurrent(){
  if(!DRAFT) return;
  const nameEl = document.getElementById('edPlaceName');
  const name = (nameEl ? nameEl.value : '').trim() || ('Luogo ' + ((DRAFT.places || []).length + 1));
  if(!NATIVE || !NATIVE.getCurrentLocation){
    DRAFT.places = DRAFT.places || [];
    DRAFT.places.push({ name: name, lat: 45.4642, lng: 9.19, radius: edRadiusM });
    if(nameEl) nameEl.value = '';
    edPaintPlaces(); toast('Anteprima: sul telefono qui viene letta la posizione reale');
    return;
  }
  const p = await edEnsureLocation(true);
  if(p && p.granted === false) return;
  toast('Leggo la posizione…');
  let loc = null;
  try{ loc = await NATIVE.getCurrentLocation(); }
  catch(e){ toast((e && e.message) || 'Posizione non disponibile'); return; }
  if(!loc || typeof loc.lat !== 'number'){ toast('Posizione non disponibile'); return; }
  DRAFT.places = DRAFT.places || [];
  DRAFT.places.push({ name: name, lat: loc.lat, lng: loc.lng, radius: edRadiusM });
  if(nameEl) nameEl.value = '';
  edPaintPlaces();
  toast('Aggiunto: ' + name + (loc.accuracy > 0 ? ' (±' + Math.round(loc.accuracy) + ' m)' : ''));
}

function describeProgram(p){
  const bits = [];
  if(p.type === 'ora' || (p.type === 'combo' && p.useTime !== false)){
    bits.push(daysLabel(p.days));
    bits.push(p.allDay ? 'Tutto il giorno' : ((p.from || '') + ' – ' + (p.to || '')));
  }
  if(p.type === 'wifi' || (p.type === 'combo' && p.useWifi)){
    const w = p.wifi || []; bits.push(w.length === 1 ? 'Wi-Fi ' + w[0] : w.length + ' reti Wi-Fi');
  }
  if(p.type === 'posizione' || (p.type === 'combo' && p.usePlace)){
    const pl = p.places || []; bits.push(pl.length === 1 ? '📍 ' + (pl[0].name || 'luogo') : pl.length + ' luoghi');
  }
  if(p.type === 'limite' || (p.type === 'combo' && p.useLimit)){
    if(p.qh) bits.push(p.qh + 'm/ora');
    if(p.qd) bits.push(p.qd + 'm/giorno');
    if(!p.qh && !p.qd) bits.push('nessun limite impostato');
  }
  if(p.type === 'sempre') bits.push('Sempre attivo');
  if(p.type === 'limite') bits.push(daysLabel(p.days));
  const n = (p.apps || []).length, s = (p.sites || []).length + (p.keywords || []).length;
  bits.push(n + ' app · ' + s + ' siti/parole');
  return bits.join(' · ');
}

/* ================= 7 · PUSH VERSO IL MOTORE =================
 * One program = one Schedule. No more flattened union: that is what made an hourly program
 * and a permanent one indistinguishable to the engine (G12). */
function programToSchedule(p){
  return {
    id: p.id,
    name: p.name || 'Programma',
    type: p.type || 'sempre',
    from: p.from || '00:00',
    to: p.to || '00:00',
    days: (Array.isArray(p.days) && p.days.length === 7) ? p.days : [true,true,true,true,true,true,true],
    allDay: !!p.allDay,
    quotaHourMin: p.qh || 0,
    quotaDayMin: p.qd || 0,
    apps: p.apps || [],
    sites: p.sites || [],
    keywords: p.keywords || [],
    redirectUrl: p.redirectUrl || '',
    wifi: p.wifi || [],
    places: p.places || [],
    useTime: p.useTime !== false, useWifi: !!p.useWifi, usePlace: !!p.usePlace, useLimit: !!p.useLimit,
    allow: p.allow || [],
    blockLaunch: p.blockLaunch !== false,
    blockNotifications: p.blockNotifications !== false,
    enabled: p.on !== false,
    grazia: blkInGrazia(p) ? p.grazia : 0
  };
}

async function pushRules(){
  saveProgramsLocal();
  if(!NATIVE) return;
  blkEnsureIds();

  if(blkHasNative('saveSchedules')){
    const res = await blkNative('saveSchedules', { schedules: PROGRAMS.map(programToSchedule) });
    if(res === null){
      /* 0.9.287: rifiutato dal motore (Modalita' severa): la pagina torna a quello che il motore applica davvero,
         invece di mostrare un programma modificato che non vale */
      try{ if(await hydrateProgramsFromEngine()){ saveProgramsLocal(); if(typeof renderPrograms === 'function') renderPrograms(); } }catch(_){ }
      return;
    }
    await blkClearLegacyUnion();
    /* Whether a programme is blocking RIGHT NOW is the engine's answer, not ours: resuming a
       paused one left `activeNow` at what it was while paused (false), so the card said
       PROGRAMMATO with no ring until the once-a-minute refresh came round. Re-reading here
       costs one call and makes every save tell the truth immediately. */
    try{ if(await hydrateProgramsFromEngine() && typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
    return;
  }

  /* Older engine build without Schedule: the union is all it understands. Degrading to it is
     better than saving nothing, but the user is told the schedule is not being honoured. */
  const apps = new Set(), kws = new Set(), allow = new Set();
  PROGRAMS.filter(function(p){ return p.on !== false; }).forEach(function(p){
    (p.apps || []).forEach(function(a){ apps.add(a); });
    // Keywords are {t, m} objects since the match-type work; the legacy setRules only
    // understands flat strings, so the term is what goes across on this path.
    (p.keywords || []).forEach(function(k){ kws.add((k && k.t) ? k.t : k); });
    (p.sites || []).forEach(function(s){ kws.add(s); });
    (p.allow || []).forEach(function(a){ allow.add(a); });
  });
  const cur = await blkNative('getRules', {}, true);
  await blkNative('setRules', {
    apps:[...apps], keywords:[...kws], allow:[...allow],
    strict: cur ? cur.strict : 0, enabled: cur ? cur.enabled : true
  });
  if(typeof toast === 'function') toast('Motore datato: gli orari non vengono applicati');
}

/* Versions before schedules wrote the union into the GLOBAL apps/keywords, which block
   around the clock. Leaving them there would keep every program permanent forever, so they
   are cleared once - and only once the schedules have actually been accepted. A refusal from
   Modalita severa is not an error here: it is retried on the next save. */
async function blkClearLegacyUnion(){
  if(localStorage.getItem('fl_union_cleared') === '1') return;
  const cur = await blkNative('getRulesFull', {}, true);
  if(!cur) return;
  const dirty = (cur.apps && cur.apps.length) || (cur.keywords && cur.keywords.length) || (cur.sites && cur.sites.length);
  if(!dirty){ localStorage.setItem('fl_union_cleared','1'); return; }
  const ok = await blkNative('setRulesFull', { apps:[], keywords:[], sites:[] }, true);
  if(ok) localStorage.setItem('fl_union_cleared','1');
}

/* ================= 8 · LISTA DEI PROGRAMMI ================= */

let BLK_STRICT = null;   // last known severe-mode state; null until the engine has answered

/* Whether the engine will refuse any change to the programs right now.
   "Blocca i blocchi nelle app" is the one guard that is always on in severe mode, so this is
   also the answer to "may the user delete a program". */
function blkEditLocked(){
  return !!(BLK_STRICT && BLK_STRICT.inAppEditLocked);
}
/* 0.9.290, Andrea (come AppBlock): "duplicandolo uno deve poterlo modificare: se si blocca subito per la modalita' severa
   non si possono cambiare le regole. Diamo due minuti, poi diventa attivo da solo". Un programma creato o duplicato con
   la Modalita' severa accesa ha `grazia` (l'ora in cui finiscono i due minuti): fino ad allora si cambia, si mette in
   pausa e si elimina come se la modalita' fosse spenta; il motore (FocusLockPlugin.refuseIfWeakening) fa lo stesso. */
const BLK_GRAZIA_MS = 2 * 60 * 1000;
function blkInGrazia(p){ return !!(p && p.grazia && p.grazia > Date.now()); }
function blkBloccato(p){ return blkEditLocked() && !blkInGrazia(p); }

async function blkRefreshStrict(){
  if(!blkHasNative('getStrictState')) return;
  const st = await blkNative('getStrictState', {}, true);
  if(st) BLK_STRICT = st;
}

/* Which packages are on the phone right now. A programme whose every app has been
   uninstalled is not blocking anything, and the card has to say so instead of "ATTIVO". */
let BLK_INSTALLED = null;
async function blkLoadInstalled(){
  if(!blkHasNative('getInstalledApps')) return;
  const r = await flApps().catch(function(){ return null; });
  if(r && Array.isArray(r.apps)){
    BLK_INSTALLED = new Set(r.apps.map(function(a){ return a.packageName; }));
    renderPrograms();
  }
}
/* "Sta bloccando qualcosa?" — false when the programme has nothing left to act on. */
function blkHasTargets(p){
  if((p.sites || []).length || (p.keywords || []).length) return true;
  const apps = p.apps || [];
  if(!apps.length) return false;
  if(!BLK_INSTALLED) return true;              // not known yet: do not accuse
  return apps.some(function(a){ return BLK_INSTALLED.has(a); });
}
/* The four states a card can be in, and what they look like. */
/* "9m 53s rimasti", come AppBlock; a zero l'app e' chiusa fino alla prossima ora (o a domani) */
function blkRimasto(ms){
  if (!(ms > 0)) return 'Tempo finito';
  const t = Math.ceil(ms / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
  return (h ? h + 'h ' + m + 'm' : m + 'm ' + sec + 's') + ' rimasti';
}
/* fermo mentre guardi DreamMap: il tempo scende solo quando usi quell'app, e si rilegge dal motore */
function blkCardState(p, locked){
  if(p.on === false) return { cls:'off', pill:'IN PAUSA', pillCls:'paused' };
  if(!blkHasTargets(p)) return { cls:'off', pill:'NON BLOCCA NIENTE', pillCls:'paused' };
  /* 0.9.292, Andrea: "PROTETTO non dice che sta bloccando adesso: la parola giusta e' ATTIVO" */
  if(locked) return { cls: p.activeNow ? 'on' : '', pill: p.activeNow ? '🔒 ATTIVO' : '🔒 PROGRAMMATO', pillCls: p.activeNow ? '' : 'idle' };
  if(p.activeNow) return { cls:'on', pill:'ATTIVO', pillCls:'' };
  return { cls:'', pill:'PROGRAMMATO', pillCls:'idle' };
}

/* IL PROGRAMMA NUOVO IN EVIDENZA (0.9.282, Andrea): dal "Mostra il programma" del Genio si arriva qui, la pagina scorre
   fino al programma creato, tutto il resto si scurisce e il suo bordo lampeggia. Toccandolo (o toccando fuori) si torna normali. */
function blkEvidenzia(pid){
  let n = 0;
  const giro = function(){
    const c = document.querySelector('.blk-card[data-pid="' + (window.CSS && CSS.escape ? CSS.escape(pid) : pid) + '"]');
    if (!c){ if (++n < 20) setTimeout(giro, 200); return; }
    c.scrollIntoView({ block: 'center', behavior: 'smooth' });
    let v = document.getElementById('blkEvVelo');
    if (!v){ v = document.createElement('div'); v.id = 'blkEvVelo'; v.className = 'blk-ev-velo'; v.onclick = blkEvidenzaVia; (c.closest('.screen') || document.getElementById('phone') || document.body).appendChild(v); }
    c.classList.add('blk-ev');
  };
  setTimeout(giro, 350);
}
function blkEvidenzaVia(){
  const v = document.getElementById('blkEvVelo'); if (v) v.remove();
  document.querySelectorAll('.blk-card.blk-ev').forEach(function(c){ c.classList.remove('blk-ev'); });
}
function renderPrograms(){
  const box = document.getElementById('progList');
  if(!box) return;
  if(!PROGRAMS.length){
    box.innerHTML = '<div class="hintline" style="text-align:center;padding:18px 0">Nessun programma. Tocca “+ Inserisci” per crearne uno.</div>';
    setTimeout(blkPaintStreak, 0);
    return;
  }
  const locked = blkEditLocked();
  setTimeout(blkPaintStreak, 0);
  box.innerHTML = PROGRAMS.map(function(p,i){
    const paused = p.on === false;
    const st = blkCardState(p, locked);
    const dead = st.pill === 'NON BLOCCA NIENTE';
    return '<div class="blk-card' + (locked ? ' blk-card-locked' : '') + (st.cls ? ' ' + st.cls : '') + '" data-pid="' + blkEsc(p.id || '') + '" onclick="blkEvidenzaVia();editProgram(' + i + ')" role="button">' +
      '<button class="blk-card-more" onclick="event.stopPropagation(); blkProgMenu(' + i + ')" aria-label="Opzioni">⋯</button>' +
      '<div class="blk-card-ico">' + (p.icon || '🕑') + '</div>' +
      '<b class="blk-card-name">' + blkEsc(p.name) + '</b>' +
      '<small class="blk-card-desc">' + blkEsc(describeProgram(p)) + '</small>' +
      (typeof p.rimastoMs === 'number' && p.on !== false ? '<small class="blk-card-rim" data-ms="' + p.rimastoMs + '" data-al="' + (p.rimastoAl || Date.now()) + '">' + blkRimasto(p.rimastoMs) + '</small>' : '') +
      '<span class="blk-card-pill' + (st.pillCls ? ' ' + st.pillCls : '') + '">' + st.pill + '</span>' +
      (dead ? '<small class="blk-card-dead">Le app di questo programma non sono più sul telefono. Quando le reinstalli tornano bloccate da sole; intanto tocca la card per aggiungerne altre.</small>' : '') +
      // A paused programme is one tap from being on again, right where it is: the ⋯ menu
      // hid the only action anybody wants on it.
      (paused && !locked ? '<button class="blk-card-resume" onclick="event.stopPropagation();toggleProgram(' + i + ')">▶ Riprendi</button>' : '') +
    '</div>';
  }).join('');
}

/* The three-dot menu, in place of a bare ✕.

   A program is work: naming it, choosing its hours, picking its apps. Putting a delete cross
   as the only affordance on the card made destruction the easiest thing to reach, and it went
   through the browser's own confirm() — a dialog that does not belong to this app and cannot
   be styled, which is why it looked like a web page error. */
function blkProgMenu(i){
  const p = PROGRAMS[i];
  if(!p) return;
  const locked = blkBloccato(p);
  const paused = p.on === false;

  const sheet = document.getElementById('blkProgSheet');
  const body = document.getElementById('blkProgSheetBody');
  if(!sheet || !body) return;

  const row = function(icon, label, handler, danger, disabled){
    const b = document.createElement('button');
    b.className = 'blk-sheet-row' + (danger ? ' danger' : '') + (disabled ? ' disabled' : '');
    b.innerHTML = '<span class="ic">' + icon + '</span><span>' + blkEsc(label) + '</span>';
    if(disabled) b.disabled = true;
    else b.addEventListener('click', function(){ blkCloseProgMenu(); handler(); });
    return b;
  };

  body.innerHTML = '';
  const title = document.createElement('div');
  title.className = 'blk-sheet-title';
  title.textContent = p.name;
  body.appendChild(title);

  if(locked){
    const note = document.createElement('p');
    note.className = 'blk-sheet-note';
    note.textContent = "Modalità severa attiva: puoi ancora AGGIUNGERE app, siti e parole "
                     + "a questo blocco, ma non toglierne, né metterlo in pausa o eliminarlo. "
                     + "Stringere sì, allentare no.";
    body.appendChild(note);
  }

  // Editing stays open while the strict mode runs, and this is not an oversight.
  //
  // The lock exists to stop the block being loosened, and adding a keyword to a programme is
  // the opposite of loosening. Greying this row out took a tightening away from the user for
  // no gain: it was the one thing they were allowed to do and the app said no. Removals are
  // still refused, by the engine, on save - which is where a guard belongs, because that is
  // the only place it cannot be walked around.
  body.appendChild(row('✏️', locked ? 'Aggiungi altri blocchi' : 'Modifica',
                       function(){ editProgram(i); }, false, false));
  /* "Metti in pausa" e' un eufemismo: descrive il gesto, non quello che succede. Interrompere
     un blocco e' interromperlo, e la parola giusta e' gia' meta' dell'attrito. */
  body.appendChild(row(paused ? '▶️' : '⏸', paused ? 'Riprendi' : 'Interrompi',
                       function(){ blkCloseProgMenu();
                                   if (paused || typeof itProgramAsk !== 'function') toggleProgram(i);
                                   else setTimeout(function(){ itProgramAsk(i); }, 220); },
                       false, locked));
  /* 0.9.287, Andrea: un programma come modello per un altro. Si apre l'editor con una copia nuova:
     creare un blocco in piu' stringe, quindi si puo' anche con la Modalita' severa accesa. */
  body.appendChild(row('📄', 'Duplica', function(){ blkDuplicaProgramma(i); }, false, false));
  body.appendChild(row('🗑', 'Elimina', function(){ deleteProgram(i); }, true, locked));

  sheet.classList.add('open');
}
async function blkDuplicaProgramma(i){
  const p = PROGRAMS[i];
  if(!p) return;
  window.BLK_GREY = false;
  /* 0.9.290: la copia nasce subito (come "Duplica" in AppBlock). Con la Modalita' severa accesa ha due minuti per
     essere cambiata; il foglio lo dice, e l'editor della copia si apre da solo. */
  const copia = JSON.parse(JSON.stringify(p));
  copia.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
  delete copia.idx;
  copia.on = true;
  copia.name = (p.name || 'Programma') + ' (copia)';
  if(!Array.isArray(copia.days) || copia.days.length !== 7) copia.days = [true,true,true,true,true,true,true];
  const severa = blkEditLocked();
  if (severa) copia.grazia = Date.now() + BLK_GRAZIA_MS;
  PROGRAMS.push(copia);
  saveProgramsLocal();
  await pushRules();
  try{ if (typeof lcProgDi === 'function' && typeof lcSalvaProgramma === 'function'){ const sc = lcProgDi(p.id); if (sc) lcSalvaProgramma(copia.id, JSON.parse(JSON.stringify(sc))); } }catch(_){ }
  renderPrograms();
  const idx = PROGRAMS.findIndex(function(x){ return x.id === copia.id; });
  const apri = function(){ if (idx >= 0) editProgram(idx); };
  if (severa && !blkGraziaNonMostrare()) blkGraziaFoglio(apri); else { apri(); toast('Copia di “' + (p.name || 'Programma') + '”: cambia quello che vuoi'); }
}
function blkGraziaNonMostrare(){ try{ return localStorage.getItem('fl_sev_grazia_no') === '1'; }catch(_){ return false; } }
/* Il foglio come quello di AppBlock, nel modo dei fogli dell'app: la X, il velo scuro, un tocco fuori lo chiude. */
function blkGraziaFoglio(poi){
  let w = document.getElementById('blkGrazia'); if (w) w.remove();
  w = document.createElement('div'); w.id = 'blkGrazia'; w.className = 'blk-grazia';
  w.innerHTML = '<div class="blk-grazia-f" role="dialog" aria-modal="true">'
    + '<button type="button" class="blk-grazia-x" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="blk-grazia-ico"><svg viewBox="0 0 24 24" width="30" height="30" fill="#fff" aria-hidden="true"><path d="M13.5 2 4.8 13.4h6.1L9.9 22l8.9-12h-6.2z"/></svg></div>'
    + '<b>Modalità severa attiva</b>'
    + '<p>Il programma duplicato si blocca da solo fra due minuti. Fino ad allora puoi cambiarne le regole.</p>'
    + '<label class="blk-grazia-cb"><input type="checkbox" id="blkGraziaNo"><span>Non mostrare di nuovo</span></label>'
    + '<button type="button" class="cta blk-grazia-ok">Cambio le regole</button></div>';
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  const chiudi = function(){
    try{ if (document.getElementById('blkGraziaNo').checked) localStorage.setItem('fl_sev_grazia_no', '1'); }catch(_){ }
    w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 220);
    if (typeof poi === 'function') poi();
  };
  w.addEventListener('click', function(e){ if (e.target === w) chiudi(); });
  w.querySelector('.blk-grazia-x').onclick = chiudi;
  w.querySelector('.blk-grazia-ok').onclick = chiudi;
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.blk-grazia{position:fixed;inset:0;z-index:99970;background:rgba(0,8,20,.62);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .2s}.blk-grazia.in{opacity:1}',
    '.blk-grazia-f{position:relative;width:100%;max-width:520px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:32px 22px calc(24px + env(safe-area-inset-bottom));text-align:center;transform:translateY(24px);transition:transform .25s cubic-bezier(.2,.9,.3,1)}.blk-grazia.in .blk-grazia-f{transform:none}body.dark .blk-grazia-f{background:#12203A}',
    '.blk-grazia-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .blk-grazia-x{background:rgba(255,255,255,.1);color:#fff}',
    '.blk-grazia-ico{width:64px;height:64px;margin:0 auto 18px;border-radius:20px;background:linear-gradient(160deg,#E63946,#B3202C);display:flex;align-items:center;justify-content:center;font-size:32px}',
    '.blk-grazia-f > b{display:block;font:800 21px/1.3 var(--font-display,var(--font-body));color:var(--navy)}body.dark .blk-grazia-f > b{color:#fff}',
    '.blk-grazia-f p{margin:12px auto 24px;max-width:30ch;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.blk-grazia-cb{display:inline-flex;align-items:center;gap:10px;margin:0 0 28px;font:600 14.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .blk-grazia-cb{color:#fff}.blk-grazia-cb input{width:20px;height:20px;accent-color:#0075E3}',
    '.blk-grazia-f .cta{width:100%}'
  ].join('');
  document.head.appendChild(st);
})();
function blkCloseProgMenu(){
  const sheet = document.getElementById('blkProgSheet');
  if(sheet) sheet.classList.remove('open');
}

/* An in-app confirmation. window.confirm() shows the WebView's own dialog, which carries the
   page origin and none of the app's design: to the user it reads as a browser error, not as a
   decision the app is asking for. Returns a promise so callers stay linear. */
function blkConfirm(title, text, okLabel, danger){
  return new Promise(function(resolve){
    const box = document.getElementById('blkConfirm');
    if(!box) return resolve(window.confirm(title));
    document.getElementById('blkConfirmTitle').textContent = title;
    document.getElementById('blkConfirmText').textContent = text || '';
    const ok = document.getElementById('blkConfirmOk');
    const no = document.getElementById('blkConfirmNo');
    ok.textContent = okLabel || 'Conferma';
    ok.className = 'cta' + (danger ? ' danger' : '');
    const done = function(v){
      box.classList.remove('open');
      ok.onclick = null; no.onclick = null;
      resolve(v);
    };
    ok.onclick = function(){ done(true); };
    no.onclick = function(){ done(false); };
    box.classList.add('open');
  });
}

/* 0.9.311, ELIMINA PROGRAMMA. Un popup al centro, uno solo per tutti i programmi dell'app (blocchi, bianco e nero,
   suoni, cicli del Full Focus, quelli creati dall'agente personale): prima alcuni cancellavano al primo tocco.
   MANTIENI e' la scelta che non fa danni: ci finiscono anche il tocco fuori e il tasto indietro di Android
   (navChiudiVelo tocca il velo: per questo lo z-index sta sopra a 100 e il velo copre tutta la cornice).
   Le card dei modelli usano lo stesso popup con le loro parole (o.titolo, o.testo, o.si). */
function blkEliminaChiedi(o){
  o = o || {};
  return new Promise(function(resolve){
    const vecchio = document.getElementById('blkElimina'); if (vecchio) vecchio.remove();
    const w = document.createElement('div');
    w.id = 'blkElimina'; w.className = 'blk-el';
    w.innerHTML = '<div class="blk-el-f" role="alertdialog" aria-modal="true" aria-labelledby="blkElT" aria-describedby="blkElP">'
      + '<b id="blkElT"></b><p id="blkElP"></p>'
      + '<div class="blk-el-az"><button type="button" class="blk-el-no"></button><button type="button" class="blk-el-si"></button></div></div>';
    w.querySelector('#blkElT').textContent = o.titolo || 'Elimina programma';
    w.querySelector('#blkElP').textContent = o.testo || 'Vuoi davvero eliminare il programma? L\u2019operazione non può essere annullata.';
    w.querySelector('.blk-el-no').textContent = o.no || 'MANTIENI';
    w.querySelector('.blk-el-si').textContent = o.si || 'ELIMINA';
    document.body.appendChild(w);
    requestAnimationFrame(function(){ w.classList.add('in'); });
    let finito = false;
    const fine = function(v){
      if (finito) return; finito = true;
      w.remove();
      resolve(v);
    };
    w.addEventListener('click', function(e){ if (e.target === w) fine(false); });
    w.querySelector('.blk-el-no').onclick = function(){ fine(false); };
    w.querySelector('.blk-el-si').onclick = function(){ fine(true); };
  });
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.blk-el{position:fixed;inset:0;z-index:99975;background:rgba(0,8,20,.62);display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;transition:opacity .16s}.blk-el.in{opacity:1}',
    '.blk-el-f{width:100%;max-width:372px;background:var(--card,#fff);border-radius:28px;padding:30px 26px 18px;text-align:center;box-shadow:0 18px 50px rgba(0,19,43,.32)}',
    '.blk-el-f b{display:block;font:800 20px/1.3 var(--font-display,var(--font-body));color:var(--navy)}',
    '.blk-el-f p{margin:14px 0 22px;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.blk-el-az{display:flex;justify-content:center;gap:14px}',
    '.blk-el-az button{min-height:46px;padding:0 16px;border:0;background:none;border-radius:50px;font:800 15px var(--font-body);letter-spacing:.3px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.blk-el-az button:active{background:rgba(0,117,227,.1)}',
    '.blk-el-no{color:#0075E3}',
    '.blk-el-si{color:#E63946}',
    /* di notte il foglio stacca dal velo, e il rosso pieno su blu notte non si leggerebbe: si schiarisce */
    'body.dark .blk-el{background:rgba(0,6,16,.74)}',
    'body.dark .blk-el-f{background:#1C2E5A;border:1px solid rgba(188,224,255,.24)}',
    'body.dark .blk-el-f b{color:#fff}',
    'body.dark .blk-el-f p{color:#BCE0FF}',
    'body.dark .blk-el-no{color:#8CC6FF}',
    'body.dark .blk-el-si{color:#FF8791}'
  ].join('');
  document.head.appendChild(st);
})();

async function toggleProgram(i){
  if(blkBloccato(PROGRAMS[i])){
    toast('Modalità severa attiva: i blocchi non si possono mettere in pausa');
    return;
  }
  PROGRAMS[i].on = PROGRAMS[i].on === false;
  if (PROGRAMS[i].on !== false && typeof itRipresa === 'function') itRipresa('p' + (PROGRAMS[i].id || i));
  saveProgramsLocal(); renderPrograms();
  // A programme switched off is the plan interrupted: the streak starts over.
  if(PROGRAMS[i].on === false && typeof sevStreakBreak === 'function') sevStreakBreak('program');
  await pushRules();                      // re-reads the engine and repaints with the truth
  syncNative();
}

async function deleteProgram(i){
  const p = PROGRAMS[i];
  if(!p) return;
  if(blkBloccato(p)){
    toast('Modalità severa attiva: i blocchi non si possono eliminare');
    return;
  }
  const ok = await blkEliminaChiedi();
  if(!ok) return;
  /* mentre il popup era aperto il motore puo' aver riscritto l'elenco: si cerca lo stesso programma */
  const at = PROGRAMS.indexOf(p) >= 0 ? PROGRAMS.indexOf(p) : PROGRAMS.findIndex(function(x){ return x.id === p.id; });
  if(at < 0) return;
  PROGRAMS.splice(at,1); saveProgramsLocal(); renderPrograms(); await pushRules(); syncNative();
}

/* ================= 9 · CREAZIONE E MODIFICA ================= */

/* UN EDITOR SOLO, DUE ELENCHI.
   Un programma in bianco e nero ha le stesse condizioni di un blocco — ora, giorni, Wi-Fi,
   posizione, combinazione — quindi usa questo stesso editor. Cambia solo dove finisce: fra i
   blocchi, o nell'elenco della pagina Bianco e nero, dove il motore di blocco non lo vede
   mai. `grey` viaggia nella bozza; il limite di utilizzo non ha senso per il grigio e la
   card sparisce. */
/* TERZO ELENCO (1/10): i programmi dei SUONI (sounds.js). Stesse condizioni, stesso editor;
   al posto della lista di blocco c'e' il suono da far partire. newBlock('sound'). */
function newBlock(grey){
  window.BLK_SOUND = grey === 'sound';
  if (window.BLK_SOUND) grey = false;
  window.BLK_GREY = !!grey;
  DRAFT = null;
  const h = document.querySelector('#s-newtype h2');
  if (h) h.textContent = window.BLK_SOUND ? 'Programma di suoni' : (grey ? 'Programma in bianco e nero' : 'Crea nuovo blocco');
  if (window.BLK_SOUND) grey = true;   /* come per il grigio, il limite di utilizzo qui non ha senso */
  const cards = document.querySelectorAll('#s-newtype .typecard');
  if (cards[1]) cards[1].hidden = !!grey;
  blkTipiSuoni(!!window.BLK_SOUND);
  goId('s-newtype');
  if(typeof adsMaybeInterstitial === 'function') adsMaybeInterstitial('new-program');
}

/* La pagina dei tipi, in versione suoni: il titolo sta sulla riga della freccia, al centro; il
   permanente sparisce; compare «mentre usi un'app o un sito»; le descrizioni parlano di suoni. */
const BLK_DESC_SUONI = { ora: 'Il suono parte nei giorni e nelle ore che scegli. Es: pioggia dalle 9 alle 12 nei giorni feriali.', wifi: 'Il suono parte quando sei connesso a una rete. Es: la rete dell\u2019ufficio.', posizione: 'Il suono parte quando sei in un luogo. Es: in biblioteca.', combo: 'Orario, Wi-Fi e posizione insieme: il suono parte solo quando valgono tutte.' };
function blkTipiSuoni(on){
  const sec = document.getElementById('s-newtype'); if (!sec) return;
  sec.classList.toggle('snd-mode', on);
  const bar = sec.querySelector('.topbar');
  let tit = document.getElementById('ntSndTit');
  if (!tit && bar){ tit = document.createElement('b'); tit.id = 'ntSndTit'; tit.className = 'blk-title nt-snd-tit'; tit.textContent = 'Programma di suoni'; bar.appendChild(tit); }
  if (tit) tit.hidden = !on;
  sec.querySelectorAll('.typecard').forEach(function(c){
    const m = String(c.getAttribute('onclick') || '').match(/pickType\('(\w+)'\)/); const k = m ? m[1] : '';
    const p = c.querySelector('p'); if (!p) return;
    if (!c.dataset.desc) c.dataset.desc = p.textContent;
    p.textContent = (on && BLK_DESC_SUONI[k]) ? BLK_DESC_SUONI[k] : c.dataset.desc;
    c.querySelectorAll('.ttag').forEach(function(tg){ tg.hidden = on; });
    if (k === 'sempre') c.hidden = on;
  });
  let app = document.getElementById('ntSndApp');
  if (!app){
    app = document.createElement('div'); app.id = 'ntSndApp'; app.className = 'typecard';
    app.setAttribute('onclick', "pickType('app')");
    app.innerHTML = '<div><b>Mentre usi un\u2019app o un sito</b><p>Il suono parte quando apri le app o i siti che scegli, e si ferma quando li lasci. Es: Notion, Google Docs.</p></div><span class="tico">📲</span>';
    const prima = sec.querySelectorAll('.typecard')[1]; if (prima) sec.insertBefore(app, prima); else sec.appendChild(app);
  }
  app.hidden = !on;
  let den = document.getElementById('ntSndDentro');
  if (!den){
    den = document.createElement('div'); den.id = 'ntSndDentro'; den.className = 'typecard';
    den.setAttribute('onclick', "if(typeof sndDentroApri==='function')sndDentroApri()");
    den.innerHTML = '<div><b>Dentro DreamMap</b><p>Il suono parte quando avvii una sessione di Full Focus o apri una sezione di DreamMap. Es: il diario di viaggio.</p></div><span class="tico">🚀</span>';
    app.parentNode.insertBefore(den, app.nextSibling);
  }
  den.hidden = !on;
}
function pickType(type){
  DRAFT = {
    id:null, name:'', type:type, icon:BLK_TYPE_ICON[type] || '🚫',
    from:'22:00', to:'08:00', qh:null, qd:null,
    days:[true,true,true,true,true,true,true], allDay:false,
    apps:[], sites:[], keywords:[], allow:[],
    wifi:[], places:[], useTime: type === 'combo', useWifi:false, usePlace:false, useLimit:false,
    blockLaunch:true, blockNotifications:true, on:true, idx:-1
  };
  if (window.BLK_GREY){ DRAFT.grey = true; DRAFT.icon = '🌑'; }
  if (window.BLK_SOUND){ DRAFT.sound = true; DRAFT.suono = 'rain'; DRAFT.volume = 0.5; DRAFT.icon = type === 'app' ? '📲' : '🎵'; DRAFT.from = '09:00'; DRAFT.to = '12:00'; DRAFT.shuffle = false; if (type === 'app'){ DRAFT.useTime = false; DRAFT.allDay = true; } }
  openEditor();
  if(type === 'wifi' || type === 'posizione') edEnsureLocation(type === 'posizione');
}
/* Indietro dall'editor: alla scheda Blocco, o alla pagina Bianco e nero se la bozza e' grigia. */
function edBack(){
  const grey = !!(window.BLK_GREY || (DRAFT && DRAFT.grey));
  const suono = !!(window.BLK_SOUND || (DRAFT && DRAFT.sound));
  window.BLK_GREY = false; window.BLK_SOUND = false;
  if (suono && typeof suoProgApri === 'function'){ suoProgApri(); return; }
  /* 0.9.291, Andrea: "dopo Cambio le regole, tornando indietro finisco in Dream invece che in Proteggi i tuoi sogni".
     Indietro torna dove eri (nav.js), non alla casa. */
  if (grey && typeof grOpen === 'function') grOpen(); else if (typeof flIndietro === 'function') flIndietro(); else goId('s-home');
}
function editProgram(i){
  window.BLK_GREY = false;
  DRAFT = JSON.parse(JSON.stringify(PROGRAMS[i]));
  DRAFT.idx = i;
  if(!Array.isArray(DRAFT.days) || DRAFT.days.length !== 7) DRAFT.days = [true,true,true,true,true,true,true];
  openEditor();
}
function openEditor(){
  document.getElementById('edIcon').textContent = DRAFT.icon || '🕑';
  document.getElementById('edName').value = DRAFT.name || '';
  const edR = document.getElementById('edRedirect'); if (edR) edR.value = DRAFT.redirectUrl || '';
  const edS = document.getElementById('edStopNote'); if (edS) edS.value = DRAFT.stopNote || '';
  /* 0.9.283: la schermata di blocco del programma si carica quando si apre la sua pagina (lockcustom.js) */
  DRAFT.schermata = null;
  try{ if (typeof settingsLoad === 'function') settingsLoad().then(function(){ if (typeof plkRigaPaint === 'function' && DRAFT && !DRAFT.schermata){ DRAFT.schermata = (typeof lcProgDi === 'function') ? lcProgDi(DRAFT.id) : null; plkRigaPaint(); } }); }catch(_){ }
  edPaintCondition();
  document.getElementById('edFrom').value = DRAFT.from || '22:00';
  document.getElementById('edTo').value = DRAFT.to || '08:00';
  blkPaintTimeLabels();
  document.getElementById('edQh').value = DRAFT.qh || '';
  document.getElementById('edQd').value = DRAFT.qd || '';

  paintModeRow('draft');
  paintWhatLabel();
  renderExtraOptions('edExtra');
  refreshEditorCounts();
  try{ if (typeof sndEditorMode === 'function') sndEditorMode(!!DRAFT.sound); }catch(_){ }
  /* 0.9.313, Andrea: "Crea" su un programma che esiste gia' non ha senso */
  const edSalva = document.getElementById('edSalva');
  if (edSalva) edSalva.textContent = (DRAFT.idx >= 0) ? 'Salva' : 'Crea';
  goId('s-editor');
}

/* Everything the chosen condition decides on this screen, in one place, so changing the
   condition later repaints exactly what creating it painted. */
function edPaintCondition(){
  if(!DRAFT) return;
  if(!Array.isArray(DRAFT.wifi)) DRAFT.wifi = [];
  if(!Array.isArray(DRAFT.places)) DRAFT.places = [];
  const t = DRAFT.type;
  const ico = document.getElementById('edIcon'); if(ico) ico.textContent = DRAFT.icon || BLK_TYPE_ICON[t] || '🕑';
  const ci = document.getElementById('edCondIco'); if(ci) ci.textContent = BLK_TYPE_ICON[t] || '🕑';
  const nm = document.getElementById('edName');
  if(nm) nm.placeholder =
    {limite:'Es. Social a piccole dosi', sempre:'Es. Mai più', wifi:'Es. In ufficio',
     posizione:'Es. In palestra', combo:'Es. Studio in biblioteca'}[t] || 'Es. Notte pulita';
  const lbl = document.getElementById('edCondLbl'); if(lbl) lbl.textContent = BLK_TYPE_NAME[t] || 'Ora';
  const body = document.getElementById('edCondBody'); if(body) body.textContent = BLK_TYPE_DESC[t] || '';
  paintEditorSchedule();
}

/* The condition picker, reachable from the editor at any time. Nothing else in the draft is
   touched: the name, the lists and the schedule survive the change, which is the whole point
   of being able to change it at all. */
function edOpenTypeSheet(){
  if(!DRAFT) return;
  const body = document.getElementById('blkTypeSheetBody');
  const sheet = document.getElementById('blkTypeSheet');
  if(!body || !sheet) return;
  body.innerHTML = '<div class="blk-sheet-title">Condizione del programma</div>'
    + blkTipiDisponibili().map(function(t){
        return '<button type="button" class="blk-typerow' + (t.k === DRAFT.type ? ' sel' : '') + '"'
          + ' onclick="edPickType(\'' + t.k + '\')"><span class="ti">' + t.ico + '</span>'
          + '<span class="tt"><b>' + blkEsc(t.name) + '</b><small>' + blkEsc(t.desc) + '</small></span>'
          + '<span class="tk">' + (t.k === DRAFT.type ? '✓' : '') + '</span></button>';
      }).join('');
  sheet.classList.add('open');
}
function edCloseTypeSheet(){
  const sheet = document.getElementById('blkTypeSheet');
  if(sheet) sheet.classList.remove('open');
}
async function edPickType(k){
  edCloseTypeSheet();
  if(!DRAFT || !BLK_TYPE_NAME[k] || k === DRAFT.type) return;
  const old = DRAFT.type;
  // A hand-picked emoji is the user's; the default one belongs to the condition and follows it.
  if(!DRAFT.icon || DRAFT.icon === BLK_TYPE_ICON[old]) DRAFT.icon = BLK_TYPE_ICON[k];
  DRAFT.type = k;
  if(k === 'combo' && !DRAFT.useTime && !DRAFT.useWifi && !DRAFT.usePlace) DRAFT.useTime = true;
  edPaintCondition();
  try{ if (DRAFT.sound && typeof sndEditorMode === 'function') sndEditorMode(true); }catch(_){ }
  toast('Condizione: ' + BLK_TYPE_NAME[k]);
  if(k === 'wifi' || k === 'posizione') edEnsureLocation(k === 'posizione');
}

/* =========================== IL PANNELLO DELLA COSTANZA ===========================
 * Il "First step taken" di Opal, con la striscia di giorni.
 *
 * Compare solo quando qualcosa sta davvero bloccando: almeno un programma acceso con delle
 * regole vive, oppure il Blocco rapido avviato con almeno una voce in elenco. Se l'utente
 * cancella o mette in pausa tutto — cioè se smonta la protezione per aggirarla — il pannello
 * sparisce e la striscia riparte da zero. È l'unica cosa che gli dà valore: non è una
 * decorazione, è la prova che oggi le regole hanno tenuto.
 */
let BLK_QUICK_KNOWN = false;   // il Blocco rapido è stato letto dal motore almeno una volta
function blkProtectionUp(){
  const anyProgram = (PROGRAMS || []).some(function(p){ return p.on !== false && blkHasTargets(p); });
  return anyProgram || (!!EXTRA.enabled && quickHasTargets());
}
function blkToday(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}
function blkDaysBetween(a, b){
  const pa = a.split('-').map(Number), pb = b.split('-').map(Number);
  const da = Date.UTC(pa[0], pa[1]-1, pa[2]), db = Date.UTC(pb[0], pb[1]-1, pb[2]);
  return Math.round((db - da) / 86400000);
}
/* Legge, aggiorna e riscrive la striscia. Un giorno saltato la spezza: non si può sommare
   ieri con la settimana scorsa e chiamarla costanza. */
function blkStreak(up){
  let st = { days:0, last:'' };
  try{ st = JSON.parse(localStorage.getItem('fl_streak') || 'null') || st; }catch(_){ }
  const today = blkToday();
  if(!up){
    if(st.days !== 0){ st = { days:0, last:'' }; try{ localStorage.setItem('fl_streak', JSON.stringify(st)); }catch(_){ } }
    return 0;
  }
  if(st.last === today) return st.days || 1;
  const gap = st.last ? blkDaysBetween(st.last, today) : 999;
  st.days = (gap === 1 ? (st.days || 0) + 1 : 1);
  st.last = today;
  try{ localStorage.setItem('fl_streak', JSON.stringify(st)); }catch(_){ }
  return st.days;
}
/* LE FRASI DELLA SERIE. Corte come quelle dell'app di riferimento: un titolo di due o tre
   parole, poi una o due frasi brevi che si leggono in tre secondi. Si dice sempre «Modalità
   severa» per esteso: «la severa» da sola non vuol dire niente per chi legge. Un complimento
   chiaro, mai una frase che si puo' scambiare per una critica. La chiusa in grassetto (f) c'e'
   solo in pochi giorni, dove una riga deve restare addosso. L'elevazione («stai diventando
   un'altra persona») compare una volta ogni tanto e sempre DOPO un fatto, mai nella forma
   «non è X, è Y» (Brain, regole anti-AI). */
const BLK_PIETRE = {
  1:   { t: 'Primo passo fatto',    p: 'Hai acceso la Modalità severa. La parte difficile era questa.', f: 'Il tuo io futuro ti sta già ringraziando.' },
  2:   { t: 'Secondo giorno',       p: 'Ieri poteva essere un caso. Oggi no.' },
  3:   { t: 'Sta prendendo ritmo',  p: 'Tre giorni di Modalità severa. Da qui comincia il cambiamento.' },
  5:   { t: 'Cinque giorni',        p: 'Una settimana di lavoro intera con le regole accese. Tienile così.' },
  7:   { t: 'Una settimana intera', p: 'Sette giorni di Modalità severa. Un’abitudine sta nascendo.' },
  10:  { t: 'Doppia cifra',         p: 'Dieci giorni. Non stai più provando: stai diventando un’altra persona.' },
  14:  { t: 'In pieno ritmo',       p: 'Due settimane piene di costanza. La disciplina comincia a venirti naturale.' },
  21:  { t: 'Tre settimane',        p: 'Ventun giorni. Il tempo che serve a un’abitudine per non chiedere più permesso.' },
  /* 0.9.292, Andrea: "dopo un mese, come Opal: A new normal. One month of focus. The dedication you show is amazing." */
  30:  { t: 'Un nuovo normale',     p: 'Un mese di concentrazione. La dedizione che dimostri è straordinaria.' },
  50:  { t: 'Cinquanta giorni',     p: 'Sette settimane di fila. Chi ti sta vicino se n’è accorto.' },
  60:  { t: 'Due mesi',             p: 'Sessanta giorni. Le cose che rimandavi hanno una data.' },
  90:  { t: 'Tre mesi',             p: 'Un trimestre intero di Modalità severa. Questa è disciplina vera.' },
  100: { t: 'Cento giorni',         p: 'Tre cifre. Pochissimi arrivano fin qui.', f: 'Tu sì.' },
  180: { t: 'Sei mesi',             p: 'Mezzo anno con le regole accese. Rileggi cosa scrivevi il primo giorno.' },
  200: { t: 'Duecento giorni',      p: 'Duecento. La mattina il telefono non decide più niente per te.' },
  270: { t: 'Nove mesi',            p: 'Nove mesi. Il tempo che serve per far nascere qualcosa.' },
  365: { t: 'Un anno intero',       p: 'Trecentosessantacinque giorni di Modalità severa.', f: 'Sei un’altra persona.' }
};

/* Le altre giornate: [frase, chiusa in grassetto o '']. Una frase sola, breve. La sceglie il
   numero del giorno, quindi due giorni vicini non leggono mai la stessa cosa, e riaprendo
   l'app oggi si ritrova quella di stamattina. 0.9.263, Andrea: piu' spinta, mai il numero. */
const BLK_FRASI = {
  corta: [
    ['Le regole hanno tenuto anche oggi. Tu pure.', ''],
    ['Oggi il telefono ha chiesto. Hai detto di no.', ''],
    ['Un altro giorno vinto contro il vecchio te.', ''],
    ['Il primo impulso è arrivato e l’hai lasciato passare.', ''],
    ['Ancora qui. È esattamente quello che conta.', ''],
    ['Ogni giorno così rende il prossimo un po’ più facile.', '']
  ],
  media: [
    ['Stai costruendo un ritmo. Non regalarlo a una sera storta.', ''],
    ['Quello che all’inizio costava fatica adesso ti viene da solo.', ''],
    ['Le giornate così non fanno rumore. Si sommano, e un giorno si vedono.', ''],
    ['La serie ha un peso, adesso.', 'Proteggila.'],
    ['Il tuo io futuro sta prendendo forma, un giorno alla volta.', ''],
    ['Le scuse ci sono ancora. Tu non le ascolti più.', '']
  ],
  lunga: [
    ['La persona che eri avrebbe già mollato.', 'Tu sei ancora qui.'],
    ['Le tue giornate le decidi tu, non la prossima notifica.', ''],
    ['Nessuna scorciatoia ti avrebbe portato fin qui. Solo i giorni.', ''],
    ['Ogni sera con le regole accese è un voto per chi stai diventando.', ''],
    ['Quello che per gli altri è forza di volontà, per te ormai è un’abitudine.', ''],
    ['Hai smesso di trattare con te stesso. Si vede.', '']
  ]
};

/* I TITOLI DELLA SERIE (0.9.265, Andrea). Call of Duty era solo lo spunto: ogni 5 giorni un TITOLO di una parola
   sola che dice il traguardo raggiunto (niente "Nucleare" o "Spietato": parole che parlano di costanza e di
   concentrazione). Negli altri giorni il titolo cambia ogni giorno: un incoraggiamento o un complimento sul
   percorso ("Primo passo fatto"), e alle tappe settimanali e mensili una frase come quelle di Opal ("Due settimane
   piene di costanza: la disciplina comincia a venirti naturale"). Sotto, una riga breve che spinge. */
const BLK_RANGHI = {
  5:   ['Costante',      'Cinque giorni senza cedere. La costanza è cominciata qui.'],
  10:  ['Determinato',   'Dieci giorni e le regole non si sono piegate una volta. Neanche tu.'],
  15:  ['Concentrato',   'Sei pericoloso quando sei concentrato. E da quindici giorni lo sei.'],
  20:  ['Disciplinato',  'Venti giorni: quello che prima ti costava fatica adesso lo fai e basta.'],
  25:  ['Tenace',        'Le tentazioni bussano ancora. Tu non apri più.'],
  30:  ['Inarrestabile', 'Un mese intero. A questo punto fermarti costerebbe più fatica che continuare.'],
  35:  ['Lucido',        'Le tue giornate le decide la tua testa, non la prossima notifica.'],
  40:  ['Instancabile',  'Quaranta giorni. Chi ti sta vicino se n’è accorto, anche se non te l’ha detto.'],
  45:  ['Saldo',         'Le giornate storte arrivano anche a te. Non ti spostano più.'],
  50:  ['Incrollabile',  'Cinquanta giorni di fila. Pochissimi arrivano fin qui.'],
  60:  ['Padrone',       'Due mesi: il tuo tempo adesso lo comandi tu.'],
  75:  ['Esemplare',     'La versione di te che mollava non abita più qui.'],
  90:  ['Inscalfibile',  'Tre mesi. Questa ormai non è forza di volontà: è chi sei.'],
  100: ['Leggendario',   'Cento giorni. Tre cifre di costanza.'],
  150: ['Fuoriclasse',   'La concentrazione per te è diventata normale. Per gli altri è un superpotere.'],
  200: ['Visionario',    'Duecento giorni dietro al tuo sogno. Il futuro che vedevi adesso si vede.'],
  365: ['Leggenda',      'Un anno intero con le regole accese. Rileggi chi eri il primo giorno.']
};
/* il titolo di ogni giorno che non e' un traguardo: un incoraggiamento, un complimento */
const BLK_TITOLI_GIORNO = ['Giorno vinto', 'Ancora in piedi', 'Ritmo tenuto', 'Un altro sì a te', 'Nessuna scusa',
  'Testa sul sogno', 'Passo dopo passo', 'Mente lucida', 'Più forte di ieri', 'Sulla tua rotta'];
function blkRango(n){
  let r = null;
  Object.keys(BLK_RANGHI).forEach(function(k){ if (n >= +k) r = { da: +k, t: BLK_RANGHI[k][0], p: BLK_RANGHI[k][1] }; });
  return r;
}
/* compatibilita': chi chiedeva la medaglia trova il rango */
function blkMedaglia(n){ const r = blkRango(n); return r ? { da: r.da, nome: r.t, p: r.p, f: '' } : { da: 1, nome: 'Primo passo fatto', p: '', f: '' }; }

/** La chiusa in grassetto, gia' pronta per finire in un <p>. */
function blkForte(c){
  return (c && c.f) ? ' <strong>' + blkEsc(c.f) + '</strong>' : '';
}

function blkStreakCopy(n){
  n = Math.max(1, n || 0);
  /* ogni 5 giorni: il titolo di una parola, il giorno in cui si sblocca scoppia */
  if (n % 5 === 0){
    const r = BLK_RANGHI[n] ? { t: BLK_RANGHI[n][0], p: BLK_RANGHI[n][1], nuovo: true } : null;
    if (r) return { t: r.t, p: r.p, f: '', nuova: true };
    const g0 = n < 30 ? BLK_FRASI.media : BLK_FRASI.lunga;
    const v0 = g0[(n / 5) % g0.length];
    const rr = blkRango(n);
    return { t: rr ? rr.t : 'Costante', p: v0[0], f: v0[1] };
  }
  /* le tappe (primo giorno, una settimana, due settimane...): la loro frase */
  if (BLK_PIETRE[n]) return { t: BLK_PIETRE[n].t, p: BLK_PIETRE[n].p, f: BLK_PIETRE[n].f || '' };
  /* gli altri giorni: un titolo nuovo ogni giorno e una riga che spinge */
  const gruppo = n < 7 ? BLK_FRASI.corta : (n < 30 ? BLK_FRASI.media : BLK_FRASI.lunga);
  const v = gruppo[n % gruppo.length];
  return { t: BLK_TITOLI_GIORNO[n % BLK_TITOLI_GIORNO.length], p: v[0], f: v[1] };
}
/** Il giorno della medaglia nuova il titolo scoppia una volta sola (poi resta fermo). */
function blkMedagliaClasse(n, c){
  if (!c || !c.nuova) return '';
  let vista = 0; try{ vista = +localStorage.getItem('fl_sev_medaglia_vista') || 0; }catch(_){ }
  if (vista >= n) return '';
  try{ localStorage.setItem('fl_sev_medaglia_vista', String(n)); }catch(_){ }
  return ' medaglia-nuova';
}
function blkStreakHtml(n){
  const c = blkStreakCopy(n);
  return '<div class="blk-streak' + blkMedagliaClasse(n, c) + '" id="blkStreak">'
    + '<div class="txt"><b>' + blkEsc(c.t) + '</b><p>' + blkEsc(c.p) + blkForte(c) + '</p></div>'
    + '<div class="flame">🔥<span>' + n + '</span></div>'
    + '</div>';
}
/* Va sotto la prima card dei programmi; se programmi non ce ne sono, sotto il Blocco rapido. */
function blkPaintStreak(){
  const tab = document.getElementById('tab-blocco');
  if(!tab) return;
  const old = document.getElementById('blkStreak');
  if(old) old.remove();
  const up = blkProtectionUp();
  // Finché non sappiamo che cosa contiene il Blocco rapido, "niente sta bloccando" è solo
  // ignoranza, non un fatto: azzerare la striscia qui la cancellerebbe a ogni avvio a chi usa
  // soltanto il Blocco rapido.
  if(!up && !BLK_QUICK_KNOWN) return;
  // The streak is still kept up to date from here; the panel itself now lives in the
  // Profile (with the phrase of the day) and in Modalità severa (with the fire).
  blkStreak(up);
}

/* Counters and chips: a number alone never told the user WHAT was in the list (G04). */
function refreshEditorCounts(){
  if(!DRAFT) return;
  const a = document.getElementById('edAppCount'), w = document.getElementById('edWebCount'), k = document.getElementById('edKwCount');
  if(a) a.textContent = (DRAFT.apps || []).length;
  if(w) w.textContent = (DRAFT.sites || []).length;
  if(k) k.textContent = (DRAFT.keywords || []).length;
}
function paintChips(id, arr){
  const box = document.getElementById(id);
  if(!box) return;
  const max = 6;
  box.innerHTML = arr.slice(0,max).map(function(v){
    const label = (v && v.t) ? v.t : v;
    // a domain gets its own favicon; an app or a keyword keeps the dot
    const lead = flFavHost(label) ? flFavHtml(label) : '<i>•</i>';
    return '<span class="blk-chip">' + lead + blkEsc(shortLabel(label)) + '</span>';
  }).join('') + (arr.length > max ? '<span class="blk-chip more">+' + (arr.length - max) + '</span>' : '');
}
/* A package name is unreadable at chip size — but its LAST segment names the wrong thing:
   com.instagram.android is not "android". The app's real label wins whenever the installed
   list has been read; otherwise the most telling segment does, skipping the generic tails
   every vendor appends. Domains and keywords fall through untouched. */
const SHORT_GENERIC = { android:1, app:1, apps:1, mobile:1, client:1, main:1, ui:1,
                        free:1, lite:1, pro:1, beta:1, plus:1 };
function shortLabel(v){
  const s = String(v == null ? '' : v);
  if(!s || s.indexOf(' ') >= 0) return s;
  // ubAppLabel only answers for a string that IS an installed package, so a domain is safe here.
  if(typeof ubAppLabel === 'function'){
    const l = ubAppLabel(s);
    if(l && l !== s) return l;
  }
  if(s.indexOf('com.') === 0 && s.split('.').length > 2){
    const parts = s.split('.').slice(1).filter(Boolean);
    for(let i = parts.length - 1; i >= 0; i--){
      if(!SHORT_GENERIC[parts[i].toLowerCase()]) return parts[i];
    }
  }
  return s;
}

async function saveBlock(){
  if(!DRAFT) return;
  DRAFT.name = document.getElementById('edName').value.trim() || 'Programma senza nome';
  const edR2 = document.getElementById('edRedirect'); DRAFT.redirectUrl = edR2 ? edR2.value.trim() : '';
  const edS2 = document.getElementById('edStopNote'); DRAFT.stopNote = edS2 ? edS2.value.trim() : '';
  DRAFT.from = document.getElementById('edFrom').value;
  DRAFT.to   = document.getElementById('edTo').value;
  DRAFT.qh   = parseInt(document.getElementById('edQh').value,10) || null;
  DRAFT.qd   = parseInt(document.getElementById('edQd').value,10) || null;

  if(DRAFT.sound && DRAFT.type === 'app' && !DRAFT.apps.length && !DRAFT.sites.length){
    toast('Scegli almeno un\'app o un sito');
    return;
  }
  if(!DRAFT.sound && !DRAFT.apps.length && !DRAFT.sites.length && !DRAFT.keywords.length){
    const funz = (!DRAFT.grey && typeof ubFunzScelte === 'function') ? ubFunzScelte() : [];
    toast(funz.length ? 'Le funzioni che hai spuntato sono già bloccate. Per salvare il programma aggiungi un\'app, un sito o una parola'
                      : 'Aggiungi almeno un\'app, un sito o una parola');
    return;
  }
  const needLimit = DRAFT.type === 'limite' || (DRAFT.type === 'combo' && DRAFT.useLimit);
  if(needLimit && !DRAFT.qh && !DRAFT.qd){
    toast('Imposta un limite in minuti');
    return;
  }
  const needWifi = DRAFT.type === 'wifi' || (DRAFT.type === 'combo' && DRAFT.useWifi);
  const needPlace = DRAFT.type === 'posizione' || (DRAFT.type === 'combo' && DRAFT.usePlace);
  if(needWifi && !(DRAFT.wifi || []).length){ toast('Aggiungi almeno una rete Wi-Fi'); return; }
  if(needPlace && !(DRAFT.places || []).length){ toast('Aggiungi almeno un luogo'); return; }
  if(DRAFT.type === 'combo' && edComboCount() < 2){
    toast('Imposta almeno due condizioni'); return;
  }
  if(!DRAFT.id) DRAFT.id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);

  const idx = DRAFT.idx;
  const clean = Object.assign({}, DRAFT);
  delete clean.idx;
  if (clean.sound && typeof sndSaveProgram === 'function'){
    sndSaveProgram(clean, idx);
    window.BLK_SOUND = false;
    toast(idx >= 0 ? 'Programma aggiornato' : 'Programma di suoni creato');
    if (typeof suoProgApri === 'function') suoProgApri(); else sndPaginaApri();
    return;
  }
  if (clean.grey && typeof grSaveProgram === 'function'){
    grSaveProgram(clean, idx);
    window.BLK_GREY = false;
    toast(idx >= 0 ? 'Programma aggiornato' : 'Programma in bianco e nero creato');
    grAfterProgramSave();
    return;
  }
  if (idx < 0 && blkEditLocked()) clean.grazia = Date.now() + BLK_GRAZIA_MS;
  if(idx >= 0) PROGRAMS[idx] = clean; else PROGRAMS.push(clean);
  saveProgramsLocal();
  await pushRules();
  try{ if (clean.schermata && typeof lcSalvaProgramma === 'function') lcSalvaProgramma(clean.id, clean.schermata); }catch(_){ }
  renderPrograms();
  toast(idx >= 0 ? 'Programma aggiornato' : 'Programma creato');
  goId('s-home'); switchTab('blocco');
  // The natural transition the owner chose for advertising: work is done, nothing is
  // interrupted. The ads module decides on its own whether this one earns an ad.
  if(typeof adsMaybeInterstitial === 'function') adsMaybeInterstitial('program-saved');
}

/* ================= 10 · BLOCCO RAPIDO (G02) =================
 * "Inizia" with no list blocked nothing at all while the counter cheerfully read
 * "0 app · 0 siti": the most visible button in the app did nothing. The Quick Block now owns
 * its own lists in the engine (Rules.QuickBlock) and refuses to start empty. */

async function loadQuick(){
  if(!blkHasNative('getQuickBlock')) return;
  const q = await blkNative('getQuickBlock', {}, true);
  if(!q) return;
  QUICK = {
    enabled: !!q.enabled,
    apps: q.apps || [],
    sites: q.sites || [],
    keywords: q.keywords || []
  };
}
async function loadExtra(){
  if(!blkHasNative('getRulesFull')) return;
  const r = await blkNative('getRulesFull', {}, true);
  if(!r) return;
  EXTRA = {
    enabled: r.enabled !== false,
    listMode: r.listMode || 'blocklist',
    allowApps: r.allowApps || [],
    blockNewlyInstalled: !!r.blockNewlyInstalled,
    blockUnsupportedBrowsers: !!r.blockUnsupportedBrowsers,
    blockAdult: !!r.blockAdult,
    blockReinstalled: !!r.blockReinstalled,
    blockPurchases: !!r.blockPurchases,
    searchTyping: !!r.searchTyping,
    blockLaunch: r.blockLaunch !== false,
    blockNotifications: !!r.blockNotifications,
    // The engine-wide lists. They are what the first-install seed lands in, and until now no
    // screen read them: the base protection was real and had no window.
    sites: r.sites || [],
    keywords: r.keywords || []
  };
}

async function openQuick(){
  await loadQuick();
  await loadExtra();
  paintQuick();
  goId('s-quick');
}
function closeQuick(){ goId('s-home'); switchTab('blocco'); }

function paintQuick(){
  const allow = EXTRA.listMode === 'allowlist';
  const apps = allow ? EXTRA.allowApps : QUICK.apps;
  const set = function(id, v){ const e = document.getElementById(id); if(e) e.textContent = v; };
  set('qkNApps', apps.length);
  set('qkNSites', QUICK.sites.length);
  set('qkNKw', QUICK.keywords.length);
  paintChips('qkChipApps', (!allow && typeof ubFunzScelte === 'function') ? apps.concat(ubFunzScelte()) : apps);
  paintChips('qkChipSites', QUICK.sites);
  paintChips('qkChipKw', QUICK.keywords);
  paintModeRow('quick');
  renderExtraOptions('qkExtra');
}

async function saveQuick(){
  if(!NATIVE){ toast('Anteprima nel browser: nulla viene salvato nel motore'); goId('s-home'); return; }
  const apps = EXTRA.listMode === 'allowlist' ? EXTRA.allowApps : QUICK.apps;
  if(!apps.length && !QUICK.sites.length && !QUICK.keywords.length){
    toast('Scegli almeno un\'app, un sito o una parola');
    return;
  }
  /* The saved list has to inherit the master switch. Saving it as inert while the banner says
     "Protezione attiva" is exactly the lie this screen exists to remove: the engine only reads
     the quick lists when QuickBlock.enabled is true. */
  /* Only the master switch is re-read here. Calling loadExtra() would overwrite EXTRA with
     the engine's copy and throw away the very edits (allowApps, the extra flags) this save
     is about. */
  const cur = await blkNative('getRules', {}, true);
  QUICK.enabled = cur ? cur.enabled !== false : EXTRA.enabled;
  EXTRA.enabled = QUICK.enabled;

  const res = await blkNative('setQuickBlock', {
    enabled: QUICK.enabled, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords
  });
  if(res === null) return;

  /* In allowlist mode the app list is not the quick block's: the engine reads Rules.allowApps
     for it. Saving only the quick block here would let the screen show a list of authorised
     apps that the engine has never heard of. */
  if(EXTRA.listMode === 'allowlist'){
    const ok = await blkNative('setRulesFull', { allowApps: EXTRA.allowApps });
    if(ok === null) return;
  }
  toast('Blocco rapido salvato');
  closeQuick();
  syncNative();
}

/* Start / pause. The engine flag `enabled` is the master switch; the quick block has its own
   `enabled` inside QuickBlock, and both have to move together or the button lies. */
async function quickBlockToggle(force){
  if(!NATIVE){ toast('Disponibile solo nell\'app installata'); return; }

  /* Fermare il blocco rapido passa dal pannello della decisione. Accenderlo no: mettersi una
     regola addosso non ha bisogno di attrito, toglierla si'. */
  /* 0.9.287: con la Modalita' severa accesa il Blocco rapido non si ferma (prima il pannello faceva fermare lo stesso) */
  if(QUICK.enabled && blkEditLocked()){ toast('Modalità severa attiva: il Blocco rapido resta acceso finché non la spegni'); try{ flVibra(30); }catch(_){ } return; }
  if(QUICK.enabled && force !== true && typeof itQuickAsk === 'function'){ itQuickAsk(); return; }

  const svc = await blkNative('isServiceEnabled', {}, true);
  if(svc && !svc.enabled){
    toast('Prima attiva il servizio di blocco');
    if(typeof openPerm === 'function') openPerm('accessibility'); else goEngine();
    return;
  }

  await loadQuick();
  await loadExtra();
  const hasQuick = QUICK.apps.length || QUICK.sites.length || QUICK.keywords.length;
  const hasPrograms = PROGRAMS.some(function(p){ return p.on !== false; });
  const allowMode = EXTRA.listMode === 'allowlist';
  // An extra option IS something to block. With the adult classifier on, "choose what to
  // block first" was refusing to start a blocker that had plenty to do - the very toggle the
  // user had just switched on was being ignored by the button below it.
  const hasExtras = EXTRA.blockAdult || EXTRA.blockUnsupportedBrowsers
                 || EXTRA.blockNewlyInstalled || EXTRA.blockReinstalled || EXTRA.blockPurchases
                 || (EXTRA.sites || []).length || (EXTRA.keywords || []).length;

  if(!hasQuick && !hasPrograms && !allowMode && !hasExtras){
    // Starting here would switch on a blocker with nothing to block. Send them to the list.
    toast('Scegli prima cosa bloccare');
    await openQuick();
    return;
  }

  /* This button is the QUICK BLOCK's, and only its. It used to flip the engine's master
     switch as well, so pausing the quick block silently paused every programme: "blocco
     rapido in pausa" read, in the engine, as "nothing blocks anything". Now the quick block
     has its own on/off, and the master switch is only ever put back ON here. */
  const next = !QUICK.enabled;
  if(next && EXTRA.enabled === false){
    const okRules = await blkNative('setEnabled', { enabled: true });
    if(okRules === null) return;
    EXTRA.enabled = true;
  }
  if(blkHasNative('setQuickBlock')){
    const ok = await blkNative('setQuickBlock', {
      enabled: next, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords
    }, true);
    if(ok === null){ if(!next) toast('Modalità severa attiva: il Blocco rapido resta acceso'); return; }
    QUICK.enabled = next;
  }
  if(!next && typeof sevStreakBreak === 'function') sevStreakBreak('quick');
  if(next && typeof itRipresa === 'function') itRipresa('quick');
  paintQuickBlock(next);
  toast(next ? 'Blocco rapido attivo' : 'Blocco rapido in pausa: i programmi restano attivi');
  syncNative();
}
/* Quante regole ha il Blocco rapido: senza nessuna, avviato o no, non sta bloccando niente. */
function quickHasTargets(){
  if(EXTRA.listMode === 'allowlist') return (EXTRA.allowApps || []).length > 0;
  return (QUICK.apps || []).length > 0 || (QUICK.sites || []).length > 0 || (QUICK.keywords || []).length > 0;
}
function paintQuickBlock(on){
  BLK_QUICK_KNOWN = true;
  const card = document.querySelector('#tab-blocco .qb');
  const has = quickHasTargets();
  if(card){
    // Stesso codice colore delle card dei programmi: anello blu mentre blocca, rosso quando
    // ha delle regole ma è in pausa, niente anello quando non c'è ancora nulla da bloccare.
    card.classList.toggle('on', !!on && has);
    card.classList.toggle('off', !on && has);
  }
  const btn = document.getElementById('qbBtn');
  if(!btn) return;
  /* L'icona di stop e' un SVG, come nell'app di riferimento: un quadrato dentro un cerchio.
     Le emoji cambiano faccia da un telefono all'altro; un tracciato no. */
  btn.innerHTML = on
    ? '<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true"><circle cx="10" cy="10" r="8.6" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="6.6" y="6.6" width="6.8" height="6.8" rx="1.2" fill="currentColor"/></svg>STOP'
    : '▶ Inizia';
  btn.style.background = '';
  // AppBlock: "Inizia" is the blue call to action, "Stop" is grey and faded once the block
  // is running. The rings on the card keep saying whether anything is blocked.
  btn.classList.remove('paused');
  btn.classList.toggle('stop', !!on);
  blkPaintStreak();
}

/* ---- the quick block's own list screen ---- */
function openQuickList(which){
  QL_TAB = which;
  goId('s-qlist');
  qlTab(which);
}
function qlTab(which){
  QL_TAB = which;
  document.querySelectorAll('#s-qlist .bltab').forEach(function(b){ b.classList.toggle('on', b.dataset.ql === which); });
  ['app','web','kw'].forEach(function(k){
    const e = document.getElementById('ql-' + k);
    if(e) e.hidden = (k !== which);
  });
  const title = document.getElementById('qlTitle');
  if(title) title.textContent = EXTRA.listMode === 'allowlist' ? 'Elenco consentiti' : 'Lista di blocco';
  if(which === 'app') loadQlApps(); else renderQlSimple(which);
}
async function loadQlApps(){
  const box = document.getElementById('qlAppList');
  if(!box) return;
  if(!NATIVE){ box.innerHTML = '<div class="hintline" style="padding:14px">Elenco disponibile solo nell\'app installata.</div>'; return; }
  if(!QL_APPS.length){
    if(!(typeof FLA !== 'undefined' && FLA.list && FLA.list.length)) box.innerHTML = '<div class="hintline" style="padding:14px">Leggo le app installate…</div>';
    const r = await flApps().catch(function(){ return null; });
    QL_APPS = (r && r.apps) || [];
  }
  renderQlApps();
  if(typeof ubFunzRileggi === 'function') ubFunzRileggi(renderQlApps);
}
function qlAppTarget(){ return EXTRA.listMode === 'allowlist' ? EXTRA.allowApps : QUICK.apps; }
function renderQlApps(){
  const box = document.getElementById('qlAppList');
  if(!box) return;
  const q = ((document.getElementById('qlSearch') || {}).value || '').toLowerCase();
  /* Nell'elenco dei consentiti non si blocca niente: le funzioni non c'entrano */
  const conFunz = EXTRA.listMode !== 'allowlist';
  const list = QL_APPS.filter(function(a){ return ubAppCercata(a, q, conFunz); });
  const target = qlAppTarget();
  if(!list.length){ box.innerHTML = '<div class="hintline" style="padding:14px">Nessuna app trovata.</div>'; return; }
  box.innerHTML = ubPrimaLeScelte(list, target).map(function(a){ return ubRigaAppHtml(a, target.indexOf(a.packageName) >= 0, conFunz); }).join('');
  if (typeof ubLoadIcons === 'function') ubLoadIcons(box);
  box.querySelectorAll('input:not([data-funz])').forEach(function(i){
    i.addEventListener('change', function(){
      const arr = qlAppTarget();
      const at = arr.indexOf(i.value);
      if(i.checked){ if(at < 0) arr.push(i.value); }
      else if(at >= 0) arr.splice(at,1);
      ubFunzSegui(box, i.value, i.checked);
      paintQuick();
    });
  });
  ubFunzCollega(box, paintQuick);
}
function qlList(which){ return which === 'web' ? QUICK.sites : QUICK.keywords; }
/* The Quick Block's keyword list borrows the program editor's picker (blocklist.js) instead of
   owning a second, poorer copy of it: same three match types, same sheet, same wording. */
function qlModeSrc(){
  return {
    list: function(){ return QUICK.keywords; },
    normalize: function(){
      if(typeof ubNormalizeKeywordList === 'function') QUICK.keywords = ubNormalizeKeywordList(QUICK.keywords);
    },
    after: function(){ renderQlSimple('kw'); paintQuick(); }
  };
}
function qlOpenMode(i){
  if(typeof ubOpenModeForList !== 'function'){ toast('Non disponibile in questa versione'); return; }
  ubOpenModeForList(i, qlModeSrc());
}
function qlModeLabel(m){
  if(typeof UB_MODES !== 'undefined' && UB_MODES[m]) return UB_MODES[m].label;
  return m === 'domain' ? 'Nel dominio' : m === 'content' ? 'Nel contenuto della pagina' : 'Ovunque nell\'URL';
}
function qlPaintKwMode(){
  const m = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
  const lbl = document.getElementById('qlKwModeLbl');
  if(lbl) lbl.textContent = qlModeLabel(m);
  const hint = document.getElementById('qlKwModeHint');
  if(hint && typeof UB_MODES !== 'undefined' && UB_MODES[m]) hint.textContent = UB_MODES[m].hint;
}
function renderQlSimple(which){
  const box = document.getElementById(which === 'web' ? 'qlWebList' : 'qlKwList');
  if(!box) return;
  if(which === 'kw') qlPaintKwMode();
  const arr = qlList(which);
  if(!arr.length){ box.innerHTML = '<div class="hintline" style="padding:14px">Ancora niente in elenco.</div>'; return; }
  box.innerHTML = arr.map(function(v,i){
    const term = (v && v.t) ? v.t : v;
    if(which === 'web'){
      return '<div class="pickrow">' + flFavHtml(term, 'big') + '<span class="pl">' + blkEsc(term) + '</span>' +
        '<button class="del" onclick="qlRemove(\'web\',' + i + ')">✕</button></div>';
    }
    const m = (v && v.m) ? v.m : 'url';
    return '<div class="pickrow ub-kwrow"><span class="pl">' + blkEsc(term) + '</span>' +
      '<button class="ub-modetag ub-m-' + m + '" onclick="qlOpenMode(' + i + ')">' + blkEsc(qlModeLabel(m)) + '<i class="ub-caret"></i></button>' +
      '<button class="del" onclick="qlRemove(\'kw\',' + i + ')">✕</button></div>';
  }).join('');
}
function qlAdd(which){
  const input = document.getElementById(which === 'web' ? 'qlWebIn' : 'qlKwIn');
  if(!input) return;
  const v = input.value.trim().toLowerCase();
  if(!v) return;
  const arr = qlList(which);
  if(which === 'web'){
    if(arr.indexOf(v) < 0) arr.push(v);
  }else{
    const mode = (typeof UB_NEW_MODE !== 'undefined') ? UB_NEW_MODE : 'domain';
    if(arr.some(function(k){ return (k.t || k) === v && (k.m || 'url') === mode; })){
      toast('“' + v + '” è già in elenco come “' + qlModeLabel(mode) + '”');
    }else{
      arr.push({ t:v, m:mode });
    }
  }
  input.value = '';
  renderQlSimple(which);
  paintQuick();
}
function qlRemove(which, i){
  qlList(which).splice(i,1);
  renderQlSimple(which);
  paintQuick();
}

/* ================= 11 · BOTTOM SHEET "IMPOSTAZIONI" (G03) ================= */

function openBlockSettings(target){
  SET_TARGET = target || 'quick';
  const from = SET_TARGET === 'draft' && DRAFT
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications };
  if(SET_TARGET !== 'draft' && NATIVE) loadExtra().then(paintBlockSettings);
  paintSwitches(from);
  const el = document.getElementById('blkSetSheet');
  if(el) el.classList.add('open');
}
function paintSwitches(v){
  const l = document.getElementById('swLaunch'), n = document.getElementById('swNotif');
  if(l) l.className = 'switch' + (v.launch ? ' on' : '');
  if(n) n.className = 'switch' + (v.notif ? ' on' : '');
}
function paintBlockSettings(){
  paintSwitches(SET_TARGET === 'draft' && DRAFT
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications });
}
async function toggleBlockSetting(which){
  const draft = SET_TARGET === 'draft' && DRAFT;
  const cur = draft
    ? { launch: DRAFT.blockLaunch !== false, notif: DRAFT.blockNotifications !== false }
    : { launch: EXTRA.blockLaunch !== false, notif: !!EXTRA.blockNotifications };
  const next = Object.assign({}, cur);
  next[which] = !cur[which];

  // AppBlock's own rule, and the engine's: with both off a program is armed and inert.
  if(!next.launch && !next.notif){ toast('Devi selezionare almeno un\'opzione.'); return; }

  if(draft){
    DRAFT.blockLaunch = next.launch;
    DRAFT.blockNotifications = next.notif;
    paintSwitches(next);
    paintWhatLabel();
    return;
  }
  EXTRA.blockLaunch = next.launch;
  EXTRA.blockNotifications = next.notif;
  paintSwitches(next);
  if(!NATIVE){ toast('Anteprima nel browser: l\'impostazione non viene salvata'); return; }
  const ok = await blkNative('setRulesFull', { blockLaunch: next.launch, blockNotifications: next.notif });
  if(ok === null){ await loadExtra(); paintBlockSettings(); }
}
function closeBlockSettings(){
  const el = document.getElementById('blkSetSheet');
  if(el) el.classList.remove('open');
}
function paintWhatLabel(){
  const e = document.getElementById('edWhatLbl');
  if(!e || !DRAFT) return;
  const bits = [];
  if(DRAFT.blockLaunch !== false) bits.push('Avvio');
  if(DRAFT.blockNotifications !== false) bits.push('Notifiche');
  e.textContent = bits.join(' · ') || '—';
}

/* ================= 12 · LISTA DI BLOCCO / ELENCO CONSENTITI (G01/G21) ================= */

function openModeSheet(target){
  MODE_TARGET = target || 'quick';
  paintModeSheet();
  const el = document.getElementById('blkModeSheet');
  if(el) el.classList.add('open');
}
function closeModeSheet(){
  const el = document.getElementById('blkModeSheet');
  if(el) el.classList.remove('open');
}
function paintModeSheet(){
  const b = document.getElementById('mcBlock'), a = document.getElementById('mcAllow');
  if(b) b.className = 'blk-modecard' + (EXTRA.listMode === 'blocklist' ? ' sel' : '');
  if(a) a.className = 'blk-modecard' + (EXTRA.listMode === 'allowlist' ? ' sel' : '');
}
async function pickListMode(mode){
  const prev = EXTRA.listMode;
  EXTRA.listMode = mode;
  paintModeSheet(); paintModeRow('quick'); paintModeRow('draft');
  if(NATIVE){
    const ok = await blkNative('setRulesFull', { listMode: mode });
    if(ok === null){ EXTRA.listMode = prev; paintModeSheet(); paintModeRow('quick'); paintModeRow('draft'); return; }
  }
  if(mode === 'allowlist' && !EXTRA.allowApps.length){
    toast('Scegli le app da autorizzare: tutte le altre saranno bloccate');
  }
  paintQuick();
}
function paintModeRow(where){
  const n = document.getElementById(where === 'draft' ? 'edModeName' : 'qkModeName');
  const d = document.getElementById(where === 'draft' ? 'edModeDesc' : 'qkModeDesc');
  const allow = EXTRA.listMode === 'allowlist';
  if(n) n.textContent = allow ? 'Elenco consentiti' : 'Lista di blocco';
  if(d) d.textContent = allow
    ? 'Seleziona app che desideri autorizzare. Tutte le altre saranno bloccate.'
    : 'Seleziona app, siti web e parole chiave che desideri bloccare.';
}

/* ================= 13 · OPZIONI EXTRA (G05-G08) =================
 * All four are already implemented in the engine (Rules.blockNewlyInstalled,
 * blockUnsupportedBrowsers, blockAdult, blockReinstalled). They were simply never exposed.
 * Each toggle saves immediately through setRulesFull: a screen that stores a promise until
 * some later "Salva" is a screen where a crash silently loses protection. */
const EXTRA_OPTS = [
  { k:'blockNewlyInstalled', i:'✨', t:'Aggiungi app appena installate',
    d:'Se attivato, le app installate da poco verranno automaticamente bloccate.' },
  { k:'blockUnsupportedBrowsers', i:'🧭', t:'Blocca browser non supportati',
    d:'Se i siti web non possono essere bloccati in un browser, viene invece bloccato il browser.' },
  { k:'blockAdult', i:'18+', t:'Blocco dei siti porno',
    d:'I siti porno vengono rilevati e bloccati automaticamente in tutti i tuoi browser.' },
  { k:'blockReinstalled', i:'♻️', t:'Blocca applicazioni reinstallate',
    d:'Conserveremo le applicazioni non installate tra i tuoi blocchi. Non potrai evitare il blocco durante la reinstallazione.' },
  { k:'blockPurchases', i:'💳', t:'Blocca acquisti in-app',
    d:'La finestra di pagamento di Google Play viene chiusa appena si apre, in qualsiasi app. Gli acquisti dentro DreamMap restano possibili.' }
];

function renderExtraOptions(containerId){
  // the search switch lives in the keyword tabs, not in the extra list
  document.querySelectorAll('#qlSearchSw,#kwSearchSw').forEach(function(sw){ sw.className = 'switch' + (EXTRA.searchTyping ? ' on' : ''); });
  const box = document.getElementById(containerId);
  if(!box) return;
  box.innerHTML = EXTRA_OPTS.map(function(o){
    return '<div class="blk-opt"><span class="oi">' + o.i + '</span>' +
      '<div class="ot"><b>' + blkEsc(o.t) + '</b><small>' + blkEsc(o.d) + '</small></div>' +
      '<button class="switch' + (EXTRA[o.k] ? ' on' : '') + '" onclick="toggleExtra(\'' + o.k + '\')"></button></div>';
  }).join('') + dnsRigaHtml();
  dnsAggiorna();
}

/* 0.9.275, Andrea: "il blocco dei siti porno dovrebbe essere piu' rigoroso, non solo i siti piu'
   noti, anche tramite impostazioni per bloccare a livello di DNS, e forzare la safe search su
   Google come fa Family Link". Il DNS privato di Android vale per tutto il telefono: ogni
   browser, ogni app, anche i siti che nessuna lista conosce. Due filtri gratuiti di CleanBrowsing:
   - porno + SafeSearch forzata su Google e Bing;
   - lo stesso, piu' YouTube in modalita' protetta e niente proxy o VPN per aggirarlo.
   Se il telefono ha il permesso di sistema (lo stesso del bianco e nero) DreamMap lo scrive da
   sola e lo rimette se qualcuno lo toglie dalle Impostazioni; se no apre la schermata con
   l'indirizzo gia' copiato. */
const DNS_SCELTE = [
  { h:'', t:'Spenta' },
  { h:'adult-filter-dns.cleanbrowsing.org', t:'Attiva' },
  { h:'family-filter-dns.cleanbrowsing.org', t:'Attiva, anche su YouTube' }
];
let DNS_STATO = null;
function dnsRigaHtml(){
  const v = DNS_STATO ? (DNS_STATO.voluto || '') : '';
  const att = DNS_STATO ? (DNS_STATO.attuale || '') : '';
  let nota = 'Filtra i siti per adulti in ogni app e tiene attiva la Ricerca sicura di Google.';
  if (DNS_STATO && v && att.toLowerCase() !== v.toLowerCase()) {
    nota = DNS_STATO.puoScrivere ? 'Lo sto rimettendo: era stato cambiato nelle Impostazioni.'
      : 'Non ancora attivo. In "DNS privato" scegli "Nome host" e incolla l\'indirizzo: \u00e8 gi\u00e0 copiato.';
  } else if (DNS_STATO && v) {
    nota = 'Attivo su tutto il telefono. Si spegne solo da qui.';
  }
  return '<div class="blk-opt blk-dns"><span class="oi">\uD83D\uDEE1\uFE0F</span>' +
    '<div class="ot"><b>Protezione in tutto il telefono</b><small class="dns-nota">' + blkEsc(nota) + '</small>' +
    '<div class="dns-scelte">' + DNS_SCELTE.map(function(o){
      return '<button class="dns-sc' + (o.h === v ? ' on' : '') + '" onclick="dnsScegli(\'' + o.h + '\')">' + blkEsc(o.t) + '</button>';
    }).join('') + '</div></div></div>';
}
async function dnsAggiorna(){
  if(!NATIVE || !NATIVE.dnsStato) return;
  try {
    const st = await NATIVE.dnsStato();
    const cambiato = JSON.stringify(st) !== JSON.stringify(DNS_STATO);
    DNS_STATO = st;
    if (cambiato) document.querySelectorAll('.blk-dns').forEach(function(el){ el.outerHTML = dnsRigaHtml(); });
  } catch(e){}
}
async function dnsScegli(h){
  if(!NATIVE || !NATIVE.dnsImposta){ toast('Disponibile sul telefono'); return; }
  /* spegnerlo con la modalita' severa accesa non si puo': e' proprio il momento in cui serve */
  if(!h && DNS_STATO && DNS_STATO.voluto){
    try { const st = await NATIVE.getStrictState(); if (st && st.level >= 1){ toast('Con la modalit\u00e0 severa accesa la protezione resta attiva'); return; } } catch(e){}
  }
  try {
    const r = await NATIVE.dnsImposta({ host: h });
    if (h && !r.scritto) toast('Indirizzo copiato: incollalo in "DNS privato", "Nome host"');
    else toast(h ? 'Protezione attiva in tutto il telefono' : 'Protezione spenta');
  } catch(e){ toast('Non sono riuscito a cambiarlo'); }
  DNS_STATO = null;
  dnsAggiorna();
}
document.addEventListener('visibilitychange', function(){ if(!document.hidden && document.querySelector('.blk-dns')) dnsAggiorna(); });
async function toggleExtra(key){
  const prev = !!EXTRA[key];
  EXTRA[key] = !prev;
  renderExtraOptions('qkExtra'); renderExtraOptions('edExtra'); renderExtraOptions('bpExtra');
  if(!NATIVE){
    toast('Anteprima nel browser: l\'opzione non viene salvata');
    return;
  }
  const payload = {}; payload[key] = EXTRA[key];
  const ok = await blkNative('setRulesFull', payload);
  if(ok === null){
    EXTRA[key] = prev;                       // the engine refused: the switch must go back
    renderExtraOptions('qkExtra'); renderExtraOptions('edExtra'); renderExtraOptions('bpExtra');
  }
}

/* ================= 14 · BANNER DI STATO =================
 * The single place that answers "is anything actually being blocked". isServiceRunning()
 * now separates "granted" from "alive": on MIUI and One UI the system kills accessibility
 * services, and until this banner said so the user believed they were protected.
 *
 * heartbeatAge === -1 means the service has never written a heartbeat at all. On a build
 * where FocusLockService does not write one yet that is every device, so it is reported as
 * "unverified" rather than "dead": crying wolf on every launch would teach the user to
 * ignore the banner on the one day it is right. */
/* How many rules the engine actually has to work with, across the quick block and every
   enabled program. The banner used to report "Protezione attiva" while this was zero: the
   service was granted, the master switch was on, and there was nothing whatsoever to match.
   Saying "protected" over an empty rule set is the worst lie this app can tell, because the
   user stops checking. */
/* The banner was always sending the user to the accessibility settings, whatever it said.
   When the problem is an empty rule set, that is the wrong room entirely. */
function svcBannerTap(){
  const b = document.getElementById('svcbanner');
  const state = b ? (b.dataset.state || 'perm') : 'perm';
  if(state === 'norules'){ openQuick(); return; }
  openPerm('accessibility');
}

function blkRuleCount(engine){
  let n = 0;
  try{
    if(engine){
      /* The engine's own snapshot. The local mirror lied here once already - the banner said
         "no rules" over a program the engine was happily enforcing in Chrome - so when a
         snapshot is available it is the only voice that counts. */
      n += (engine.apps||[]).length + (engine.sites||[]).length + (engine.keywords||[]).length;
      const q = engine.quick || {};
      n += (q.apps||[]).length + (q.sites||[]).length + (q.keywords||[]).length;
      (engine.schedules||[]).forEach(function(sc){
        if(sc && sc.enabled !== false){
          n += (sc.apps||[]).length + (sc.sites||[]).length + (sc.keywords||[]).length;
        }
      });
      if(engine.listMode === 'allowlist') n += 1;   // "block everything except" IS a rule
      if(engine.blockAdult) n += 1;                 // so is the adult classifier
      return n;
    }
    n += (QUICK.apps||[]).length + (QUICK.sites||[]).length + (QUICK.keywords||[]).length;
    (PROGRAMS||[]).forEach(function(p){
      if(p && p.on !== false){
        n += (p.apps||[]).length + (p.sites||[]).length + (p.keywords||[]).length;
      }
    });
  }catch(_){ }
  return n;
}

/* The protection nobody asked for, made visible.

   On a first install the engine seeds itself: ten adult domains into the GLOBAL site list and
   the adult classifier switched on. Both are real and both block - but the dashboard renders
   the quick block and the programmes, which are different containers, so it truthfully showed
   "0 app · 0 siti/parole" while sites were being blocked. From the outside that reads as an
   app possessed by rules the user never wrote, and the obvious wrong conclusion is the one
   that got reported: "it restored them from my Google account". There is no account and no
   backup; there was only a container with no window onto it. This is the window. */
/* The sheet behind "Vedi e modifica": the engine-wide sites, one by one, with the adult
   classifier toggle. Built with DOM calls so no handler string has to survive quoting.
   Removing a site goes through setRulesFull, where the strict-mode guard already refuses it
   while a session runs - the sheet does not need a lock of its own. */
function openBaseProtection(){
  let sw = document.getElementById('blkBaseSheet');
  if(!sw){
    sw = registerOverlay('blkBaseSheet', '<div class="blk-scrim"></div><div class="blk-sheet"><div class="grab"></div><h3>Protezione di base</h3><p class="blk-ssub">Siti bloccati per tutti, da subito. Puoi toglierne, aggiungerne, o spegnere il rilevamento.</p><div id="blkBaseAdult"></div><div class="addrow"><input class="fin" id="blkBaseIn" placeholder="aggiungi un dominio, es. sito.com" autocomplete="off" enterkeyhint="done"></div><div id="blkBaseList" class="picklist"></div><button class="cta" style="margin-top:12px" id="blkBaseClose">Fatto</button></div>');
    sw.className = 'blk-sw';
    sw.querySelector('.blk-scrim').addEventListener('click', closeBaseProtection);
    sw.querySelector('#blkBaseClose').addEventListener('click', closeBaseProtection);
    const input = sw.querySelector('#blkBaseIn');
    input.addEventListener('keydown', function(ev){
      if(ev.key !== 'Enter') return;
      ev.preventDefault();
      addBaseSite(input.value);
      input.value = '';
    });
  }
  paintBaseProtection();
  sw.classList.add('open');
}
function closeBaseProtection(){
  const sw = document.getElementById('blkBaseSheet');
  if(sw) sw.classList.remove('open');
}

function paintBaseProtection(){
  const adult = document.getElementById('blkBaseAdult');
  if(adult){
    adult.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'blk-opt';
    const ico = document.createElement('span'); ico.className = 'oi'; ico.textContent = '18+';
    const txt = document.createElement('div'); txt.className = 'ot';
    const b = document.createElement('b'); b.textContent = 'Rilevamento automatico dei siti porno';
    const sm = document.createElement('small'); sm.textContent = 'Riconosce i siti per adulti anche se non sono in questa lista.';
    txt.appendChild(b); txt.appendChild(sm);
    const sw = document.createElement('button');
    sw.className = 'switch' + (EXTRA.blockAdult ? ' on' : '');
    sw.addEventListener('click', async function(){
      await toggleExtra('blockAdult');
      await loadExtra();
      paintBaseProtection();
      renderBaseProtection();
    });
    row.appendChild(ico); row.appendChild(txt); row.appendChild(sw);
    adult.appendChild(row);
  }

  const list = document.getElementById('blkBaseList');
  if(!list) return;
  list.innerHTML = '';
  const sites = EXTRA.sites || [];
  if(!sites.length){
    const e = document.createElement('div');
    e.className = 'hintline';
    e.style.padding = '14px';
    e.textContent = 'Nessun sito nella protezione di base.';
    list.appendChild(e);
    return;
  }
  sites.forEach(function(site){
    const r = document.createElement('div');
    r.className = 'pickrow ub-kwrow';
    const name = document.createElement('span');
    name.className = 'pl';
    name.textContent = site;
    const del = document.createElement('button');
    del.className = 'del';
    del.setAttribute('aria-label', 'Togli ' + site);
    del.textContent = '\u2715';
    del.addEventListener('click', function(){ removeBaseSite(site); });
    r.appendChild(name); r.appendChild(del);
    list.appendChild(r);
  });
}

async function addBaseSite(raw){
  const site = String(raw || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if(!site || site.indexOf('.') < 0){ toast('Scrivi un dominio, es. sito.com'); return; }
  const next = (EXTRA.sites || []).slice();
  if(next.indexOf(site) >= 0){ toast('Gia\u0300 presente'); return; }
  next.push(site);
  const ok = await blkNative('setRulesFull', { sites: next });
  if(ok === null) return;                      // the engine already said why
  await loadExtra();
  paintBaseProtection();
  renderBaseProtection();
  refreshServiceBanner();
}

async function removeBaseSite(site){
  const next = (EXTRA.sites || []).filter(function(x){ return x !== site; });
  const ok = await blkNative('setRulesFull', { sites: next });
  if(ok === null) return;                      // strict mode refuses removals; message shown
  await loadExtra();
  paintBaseProtection();
  renderBaseProtection();
  refreshServiceBanner();
}

/* Retired. The card explained a seed the engine no longer plants, and it was being appended
   once per call - the home tab showed it twice. Any copy still in the DOM is removed here so
   an upgraded install does not keep a ghost of it. */
async function renderBaseProtection(){
  document.querySelectorAll('#blkBaseProt, .blk-base').forEach(function(el){ el.remove(); });
  return;
  const host = document.getElementById('tab-blocco');
  if(!host) return;

  let row = document.getElementById('blkBaseProt');
  const engine = NATIVE ? await blkNative('getRulesFull', {}, true) : null;
  const sites = engine && engine.sites ? engine.sites.length : 0;
  const kws = engine && engine.keywords ? engine.keywords.length : 0;
  const adult = !!(engine && engine.blockAdult);

  if(!sites && !kws && !adult){
    if(row) row.hidden = true;
    return;
  }

  if(!row){
    row = document.createElement('div');
    row.id = 'blkBaseProt';
    row.className = 'blk-base';
    // The quick-block card carries no id in the frozen markup, so it is found by class.
    const anchorEl = host.querySelector('.qb') || host.firstElementChild;
    if(anchorEl && anchorEl.parentNode) anchorEl.parentNode.insertBefore(row, anchorEl.nextSibling);
    else host.appendChild(row);
  }

  const bits = [];
  if(sites) bits.push(sites + (sites === 1 ? ' sito' : ' siti'));
  if(kws) bits.push(kws + (kws === 1 ? ' parola' : ' parole'));
  if(adult) bits.push('rilevamento automatico');

  row.hidden = false;
  row.innerHTML =
    '<div class="blk-base-h"><b>Protezione di base</b><span>' + blkEsc(bits.join(' · ')) + '</span></div>'
    + '<p>Attiva dalla prima installazione, indipendente dai programmi e dal Blocco rapido. '
    + 'È il motivo per cui alcuni siti risultano bloccati anche senza un programma tuo.</p>'
    + '<button class="blk-quicklink" id="blkBaseOpen">Vedi e modifica<span class="chev"></span></button>';

  const btn = document.getElementById('blkBaseOpen');
  if(btn) btn.addEventListener('click', openBaseProtection);
}

async function refreshServiceBanner(){
  const b = document.getElementById('svcbanner');
  if(!b) return;
  const ic = document.getElementById('svcbanner-ic');
  const tx = document.getElementById('svcbanner-txt');
  const bt = document.getElementById('svcbanner-btn');
  const qc = document.getElementById('qbCount');
  const say = function(cls, icon, text, btn, state){
    b.hidden = false;
    b.dataset.state = state || 'perm';
    b.className = 'svcbar' + (cls ? ' ' + cls : '');
    if(ic) ic.textContent = icon;
    if(tx) tx.textContent = text;
    if(bt){ bt.textContent = btn || 'Abilita'; bt.hidden = !btn; }
  };

  if(!NATIVE){
    b.hidden = true;        // the preview strip was one more banner above the quick block
    if(qc) qc.textContent = '0 app · 0 siti/parole';
    return;
  }

  await loadQuick();
  await loadExtra();

  const allow = EXTRA.listMode === 'allowlist';
  const nApps = allow ? EXTRA.allowApps.length : QUICK.apps.length;
  const nWeb  = QUICK.sites.length + QUICK.keywords.length;
  if(qc) qc.textContent = nApps + (allow ? ' app permesse' : ' app') + ' · ' + nWeb + ' siti/parole';

  let svc = await blkNative('isServiceRunning', {}, true);
  if(!svc) svc = await blkNative('isServiceEnabled', {}, true);
  const enabled = !!(svc && svc.enabled);
  const known = svc && typeof svc.heartbeatAge === 'number' && svc.heartbeatAge >= 0;
  const dead = enabled && known && svc.stale;
  // The card is about the quick block: its own switch, under the engine's master switch.
  // A master switch left OFF by an older build (which paused everything from this button)
  // is put back on now, so the programmes it silenced come back to life.
  if(EXTRA.enabled === false && blkHasNative('setEnabled')){
    const okRules = await blkNative('setEnabled', { enabled: true }, true);
    if(okRules !== null) EXTRA.enabled = true;
  }
  const on = QUICK.enabled;

  paintQuickBlock(on);

  await blkRefreshStrict();   // the cards need to know whether they are locked
  const engineRules = await blkNative('getRulesFull', {}, true);
  const nRules = blkRuleCount(engineRules);
  renderBaseProtection();

  if(!enabled){
    say('', '!', 'Il blocco non può funzionare — servizio non attivo', 'Abilita');
  }else if(dead){
    say('', '!', 'Il sistema ha fermato il servizio: non stai bloccando nulla', 'Riattiva');
  }else{
    // Working, or paused by the user's own switch: nothing to shout about. The quick-block
    // card already shows the switch state; a green "verified" strip on top of it was noise.
    b.hidden = true;
  }
}

/* ================= 15 · AVVIO ================= */
renderTemplates();
renderPrograms();

/* Sheet and dialog, registered by this module so index.html stays untouched. */
(function blkRegisterChrome(){
  if(typeof registerOverlay !== 'function') return;
  registerOverlay('blkProgSheet',
    '<div class="blk-sheet-scrim" onclick="blkCloseProgMenu()"></div>' +
    '<div class="blk-sheet"><div class="blk-grab"></div><div id="blkProgSheetBody"></div>' +
    '<button class="ghost blk-sheet-cancel" onclick="blkCloseProgMenu()">Annulla</button></div>');
  /* The thin Premium band AppBlock keeps above the tab bar ("7 giorni di Premium gratuiti").
     Sticky at the bottom of the Blocco tab, gone the moment the user is Premium. While no
     trial has ever been taken it offers the week; afterwards it simply sells. */
  /* Appesa a #phone, non alla pagina che scorre: dentro .tabpage un position:sticky non può
     superare il fondo del suo contenuto, e infatti la banda restava a mezz'aria sopra il menu
     invece di appoggiarcisi. Qui è ancorata all'altezza reale della barra, misurata. */
  const phone = document.getElementById('phone');
  if(phone && !document.getElementById('blkPremBand')){
    const band = document.createElement('div');
    band.className = 'blk-premband';
    band.id = 'blkPremBand';
    band.setAttribute('onclick', 'go(11)');
    phone.appendChild(band);
  }
  registerOverlay('blkTypeSheet',
    '<div class="blk-sheet-scrim" onclick="edCloseTypeSheet()"></div>' +
    '<div class="blk-sheet"><div class="blk-grab"></div><div id="blkTypeSheetBody"></div>' +
    '<button class="ghost blk-sheet-cancel" onclick="edCloseTypeSheet()">Annulla</button></div>');
  registerOverlay('blkConfirm',
    '<div class="blk-sheet-scrim"></div>' +
    '<div class="blk-dialog"><b id="blkConfirmTitle"></b><p id="blkConfirmText"></p>' +
    '<button class="cta" id="blkConfirmOk"></button>' +
    '<button class="ghost" id="blkConfirmNo">Annulla</button></div>');

  const css = [
    /* Card: generous padding and everything centred, the way AppBlock stacks a program. */
    '.blk-card{position:relative;background:#fff;border:1px solid var(--line);border-radius:18px;cursor:pointer;-webkit-tap-highlight-color:transparent;',
    '  padding:22px 18px 18px;margin-bottom:12px;text-align:center;box-shadow:0 2px 10px rgba(0,30,68,.05)}',
    '.blk-card-locked{border-color:#F5C2C7;background:#FFFBFB}',
    /* The active ring is the selected-swatch of dream-brothers.com: blue border, a 1.5px halo,
       two layers of blue glow, and a thin white inner frame. */
    '.blk-card.on{border-color:#0B84FF;background:#F7FBFF;box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.28),0 22px 44px rgba(11,132,255,.16)}',
    /* Solo una cornice: niente sfondo, niente z-index, cosi' non copre nulla e soprattutto
       non costringe i figli a position:relative — che e' quello che aveva spostato i tre
       puntini dall'angolo al centro della card. */
    '.blk-card.on::before{content:"";position:absolute;inset:3px;border:3px solid #fff;border-radius:15px;pointer-events:none}',
    '.blk-card.off{border-color:#E63946;box-shadow:0 0 0 1.5px #F08A92,0 8px 18px rgba(230,57,70,.18)}',
    '.blk-card-pill.idle{background:#DCE8F5;color:#4A5A72}',
    /* Il Dream gradient del brand (brand-kit): rosa tenue -> lavanda -> blu -> ciano. */
    '.blk-streak{display:flex;align-items:center;gap:14px;border-radius:22px;padding:18px;margin:0 0 12px;',
    '  background:linear-gradient(135deg,rgba(246,204,204,1),rgba(246,204,228,1) 23%,rgba(236,207,239,1) 31%,rgba(223,210,248,1) 41%,rgba(208,215,253,1) 50%,rgba(193,219,255,1) 57%,rgba(188,224,255,1) 67%,rgba(184,229,255,1) 80%,rgba(182,233,254,1) 88%,rgba(190,239,253,1) 94%,rgba(199,244,252,1) 97%,rgba(210,249,251,1) 99%,rgba(221,254,252,1) 100%)}',
    /* IL BORDO CHE SI ACCENDE quando la Modalita' severa e' avviata. Fermo finche' e'
       accesa; pulsa una volta sola, la prima volta che il pannello si fa vedere dopo
       l'attivazione — un'animazione che riparte a ogni visita e' un tic, non una festa. */
    /* L'ALONE E' QUELLO DEL LUCCHETTO, non l'azzurro dei blocchi.
       L'azzurro circonda gia' il Blocco rapido e i programmi: usarlo anche qui voleva dire
       dire «qualcosa e' acceso» invece di «Modalita' severa avviata». Questo e' lo stesso
       gradiente conico che gira intorno alla bolla del lucchetto (app.css) — ed e' anche
       quello della frase del giorno sul sito. Un segno, un significato.
       Il doppio strato serve: un figlio con z-index negativo si disegna SOPRA allo sfondo del
       genitore, quindi il gradiente del pannello va ridipinto sopra all'alone. */
    '.blk-streak.accesa{position:relative;isolation:isolate}',
    /* NON SI RUOTA LA SCATOLA, si ruota la luce.
       `transform:rotate()` su un rettangolo largo fa spazzare agli angoli un'area molto piu'
       grande della card, e il bagliore esce a macchie da tutte le parti. Su un cerchio quel
       trucco funziona — un disco ruotato e' identico a se stesso — e infatti l'avevo copiato
       dalla bolla del lucchetto senza accorgermi che qui la forma e' un'altra.
       `--flang` e' registrata come angolo in app.css: e' l'unico modo perche' il browser sappia
       interpolare l'inclinazione di un conic-gradient. */
    '.blk-streak.accesa::before{content:"";position:absolute;inset:-7px;border-radius:29px;',
      'z-index:-2;pointer-events:none;filter:blur(12px);',
      'background:conic-gradient(from var(--flang),#3F9FF4,#0075E3,#E63946,#3F9FF4);',
      'animation:flGlowAng 3s linear infinite}',
    '.blk-streak.accesa::after{content:"";position:absolute;inset:0;border-radius:inherit;',
      'background:inherit;z-index:-1;pointer-events:none}',
    /* Appena avviata l'alone respira una volta, poi si posa. */
    '@keyframes blkNato{0%{transform:scale(.88);opacity:.2}60%{transform:scale(1.06);opacity:1}100%{transform:scale(1);opacity:1}}',
    '.blk-streak.accesa.nuova::before{animation:flGlowAng 3s linear infinite,blkNato 1.2s ease-out}',
    '.blk-streak .txt{flex:1;min-width:0}',
    /* la medaglia nuova: il titolo scoppia e una luce lo attraversa, una volta */
    '.blk-streak.medaglia-nuova b{display:inline-block;transform-origin:left center;animation:blkMedaglia 1.1s cubic-bezier(.2,1.6,.4,1) both,blkLuce 1.8s ease-out .6s both}',
    '@keyframes blkMedaglia{0%{transform:scale(.6);opacity:0}60%{transform:scale(1.14);opacity:1}100%{transform:scale(1)}}',
    '@keyframes blkLuce{0%{text-shadow:0 0 0 rgba(255,255,255,0)}35%{text-shadow:0 0 16px rgba(255,255,255,.95),0 0 4px rgba(255,255,255,.9)}100%{text-shadow:0 0 0 rgba(255,255,255,0)}}',
    '.blk-streak b{display:block;font:800 17px var(--font-display);color:#001E44;margin-bottom:5px}',
    '.blk-streak p{font:500 12.5px/1.55 var(--font-body);color:#31456B;margin:0}',
    '.blk-streak strong{font-weight:800;color:#001E44}',
    '.blk-streak .flame{position:relative;font-size:54px;line-height:1;flex:none;filter:drop-shadow(0 6px 10px rgba(230,120,0,.35))}',
    /* IL NUMERO DENTRO AL FUOCO. Era a 17px in Montserrat sopra a un'emoji arancione: troppo
       piccolo e troppo sottile per un fondo che gli cambia colore sotto. Piu' grande, in
       Poppins nero (che ha le aste molto piu' spesse del display), e con un contorno chiaro
       sotto — senza, un numero scuro su arancione resta un'ombra. */
    '.blk-streak .flame span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;',
    '  padding-top:13px;font:900 24px var(--font-body);color:#5A2A00;',
    '  text-shadow:0 1px 0 rgba(255,225,170,.85),0 -1px 0 rgba(255,225,170,.6),',
    '  1px 0 0 rgba(255,225,170,.6),-1px 0 0 rgba(255,225,170,.6)}',
    '.blk-card-dead{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--red-deep);margin-top:10px}',
    'body.dark .blk-card.on{background:#0E1E3A}',
    'body.dark .blk-card.on::before{border-color:#1B2E52}',
    '.blk-card-ico{font-size:34px;line-height:1;margin-bottom:10px}',
    '.blk-card-name{display:block;font:800 16px var(--font-display);color:var(--navy)}',
    '.blk-card-desc{display:block;font:500 12px/1.6 var(--font-body);color:var(--muted);margin:5px 12px 14px}',
    '.blk-card-rim{display:block;margin:-8px 12px 14px;font:700 13px/1.4 var(--font-body);color:#0075E3}body.dark .blk-card-rim{color:#4FB8FF}',
    '.blk-card-pill{display:inline-block;font:800 10px var(--font-body);letter-spacing:.4px;',
    '  color:#fff;background:var(--blue);border-radius:99px;padding:6px 14px}',
    '.blk-card-pill.paused{background:#8FA6C2}',
    '.blk-card-resume{display:block;margin:12px auto 0;border:0;border-radius:99px;background:var(--blue);color:#fff;',
    '  font:800 13px var(--font-body);padding:11px 26px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.blk-card-more{position:absolute;top:10px;right:8px;background:none;border:0;font-size:22px;',
    '  line-height:1;color:var(--faint);padding:6px 10px;cursor:pointer}',
    /* Sheet */
    /* con la tastiera aperta sparisce come la barra delle schede: era l'altra meta' del
       menu che saliva sopra ai tasti */
    'body.kbd .blk-premband{display:none !important}',
    '.blk-premband{position:absolute;left:14px;right:14px;z-index:39;display:flex;align-items:center;gap:9px;padding:12px 16px;',
    '  background:linear-gradient(90deg,#0B2A55,#0075E3);color:#fff;font:700 13px var(--font-body);border-radius:16px;cursor:pointer;',
    '  box-shadow:0 10px 24px rgba(0,30,68,.28)}',
    '.blk-premband .arr{margin-left:auto;color:#fff}',
    '.blk-premband[hidden]{display:none}',
    '#blkProgSheet,#blkConfirm,#blkTypeSheet{position:fixed;inset:0;z-index:70;display:none}',
    '#blkProgSheet.open,#blkConfirm.open,#blkTypeSheet.open{display:block}',
    '#blkTypeSheet .blk-sheet{max-height:82%;overflow:auto}',
    '.blk-typerow{display:flex;align-items:flex-start;gap:12px;width:100%;text-align:left;background:#fff;',
    '  border:1px solid var(--line);border-radius:14px;padding:12px;margin-bottom:8px;cursor:pointer}',
    '.blk-typerow.sel{border-color:var(--blue);background:var(--blue-soft)}',
    '.blk-typerow .ti{font-size:22px;flex:none;line-height:1.2}',
    '.blk-typerow .tt{flex:1;min-width:0}',
    '.blk-typerow .tt b{display:block;font:800 14px var(--font-display);color:var(--navy)}',
    '.blk-typerow .tt small{display:block;font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin-top:2px}',
    '.blk-typerow .tk{color:var(--blue);font-weight:800;flex:none}',
    '.blk-sheet-scrim{position:absolute;inset:0;background:rgba(0,19,43,.45)}',
    '.blk-sheet{position:absolute;left:0;right:0;bottom:0;background:#fff;border-radius:22px 22px 0 0;',
    '  padding:10px 16px calc(18px + env(safe-area-inset-bottom))}',
    '.blk-grab{width:38px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 12px}',
    '.blk-sheet-title{font:800 16px var(--font-display);color:var(--navy);text-align:center;margin-bottom:6px}',
    '.blk-sheet-note{font:500 11.5px/1.6 var(--font-body);color:var(--red-deep);background:var(--red-soft);',
    '  border-radius:12px;padding:11px 12px;margin:8px 0 12px}',
    '.blk-sheet-row{display:flex;align-items:center;gap:13px;width:100%;background:none;border:0;',
    '  padding:15px 6px;font:600 14.5px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    '.blk-sheet-row .ic{width:24px;text-align:center}',
    '.blk-sheet-row.danger{color:var(--red)}',
    '.blk-sheet-row.disabled{opacity:.38;cursor:not-allowed}',
    '.blk-sheet-cancel{width:100%;margin-top:6px}',
    /* Dialog */
    '.blk-dialog{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(320px,88%);',
    '  background:#fff;border-radius:20px;padding:24px 20px 18px;text-align:center}',
    '.blk-dialog b{display:block;font:800 17px var(--font-display);color:var(--navy)}',
    '.blk-dialog p{font:500 12.5px/1.65 var(--font-body);color:var(--muted);margin:10px 0 18px}',
    '.blk-dialog .cta{width:100%}',
    '.blk-dialog .cta.danger{background:var(--red)}',
    '.blk-dialog .ghost{width:100%;margin-top:4px}'
  ].join(' ');
  const st = document.createElement('style');
  st.id = 'blk-card-style';
  st.textContent = css;
  document.head.appendChild(st);
})();

/* ================= SELETTORE ORARIO A DUE COLONNE =================
 * The native <input type="time"> hands over to the system clock, and on One UI that is an
 * analog dial: to set 22:00 you drag a hand twice and switch AM/PM. Two vertical wheels -
 * hours, minutes - are one flick each, and they are what AppBlock shows. */

let BLK_TIME_TARGET = null;

function blkTimeParts(v){
  const m = /^(\d{1,2}):(\d{2})$/.exec(v || '');
  return m ? { h: Math.min(23, +m[1]), mi: Math.min(59, +m[2]) } : { h: 22, mi: 0 };
}
function blkPad(n){ return (n < 10 ? '0' : '') + n; }

/* Opens the wheel for any hidden time input, not just the editor's two: the onboarding has
   its own pair, and two implementations of the same control is how they drift apart. */
function blkOpenTime(target, opts){
  opts = opts || {};
  const inputId = target === 'from' ? 'edFrom' : (target === 'to' ? 'edTo' : target);
  const input = document.getElementById(inputId);
  if(!input) return;
  BLK_TIME_TARGET = {
    inputId: inputId,
    labelId: opts.labelId || (inputId + 'Lbl'),
    onDone: opts.onDone || null
  };
  const cur = blkTimeParts(input.value);
  const wrap = document.getElementById('blkTime');
  if(!wrap) return;
  document.getElementById('blkTimeTitle').textContent =
    opts.title || (target === 'to' ? 'Fino a che ora?' : 'Dalle che ora?');

  const fill = function(id, count, step, sel){
    const col = document.getElementById(id);
    col.innerHTML = '';
    for(let v = 0; v < count; v += step){
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'blk-time-item' + (v === sel ? ' on' : '');
      b.textContent = blkPad(v);
      b.dataset.v = v;
      b.addEventListener('click', function(){
        col.querySelectorAll('.blk-time-item').forEach(function(x){ x.classList.remove('on'); });
        b.classList.add('on');
        b.scrollIntoView({ block: 'center', behavior: 'smooth' });
      });
      col.appendChild(b);
    }
    // Centre the current value without animating on open.
    const on = col.querySelector('.blk-time-item.on');
    if(on) col.scrollTop = on.offsetTop - col.clientHeight / 2 + on.clientHeight / 2;
  };
  fill('blkTimeH', 24, 1, cur.h);
  fill('blkTimeM', 60, 5, Math.round(cur.mi / 5) * 5 % 60);

  wrap.classList.add('open');
}

function blkCloseTime(){
  const w = document.getElementById('blkTime');
  if(w) w.classList.remove('open');
}

function blkConfirmTime(){
  const h = document.querySelector('#blkTimeH .blk-time-item.on');
  const m = document.querySelector('#blkTimeM .blk-time-item.on');
  if(!h || !m || !BLK_TIME_TARGET){ blkCloseTime(); return; }
  const value = blkPad(+h.dataset.v) + ':' + blkPad(+m.dataset.v);
  const input = document.getElementById(BLK_TIME_TARGET.inputId);
  if(input){
    input.value = value;
    // Fired so whoever owns the field reacts exactly as it did with the native picker.
    try{ input.dispatchEvent(new Event('input', { bubbles: true })); }catch(_){ }
  }
  const lbl = document.getElementById(BLK_TIME_TARGET.labelId);
  if(lbl) lbl.textContent = value;
  if(BLK_TIME_TARGET.onDone) BLK_TIME_TARGET.onDone(value);
  blkCloseTime();
}

/* Keeps the visible labels in step with the hidden inputs whenever the editor is filled in. */
function blkPaintTimeLabels(){
  ['edFrom','edTo'].forEach(function(id){
    const el = document.getElementById(id), lbl = document.getElementById(id + 'Lbl');
    if(el && lbl) lbl.textContent = el.value || '--:--';
  });
}

(function blkRegisterTimePicker(){
  if(typeof registerOverlay !== 'function') return;
  registerOverlay('blkTime',
    '<div class="blk-sheet-scrim" onclick="blkCloseTime()"></div>' +
    '<div class="blk-sheet">' +
      '<div class="blk-grab"></div>' +
      '<div class="blk-sheet-title" id="blkTimeTitle"></div>' +
      '<div class="blk-time-cols">' +
        '<div class="blk-time-col" id="blkTimeH"></div>' +
        '<div class="blk-time-sep">:</div>' +
        '<div class="blk-time-col" id="blkTimeM"></div>' +
      '</div>' +
      '<button class="cta" onclick="blkConfirmTime()">Conferma</button>' +
      '<button class="ghost blk-sheet-cancel" onclick="blkCloseTime()">Annulla</button>' +
    '</div>');

  const css = [
    /* Without this the sheet has no display rule at all: it sat visible and empty over the
       home screen from the moment the app opened, and blkCloseTime() - which only removes
       .open - could not put away something that was never hidden to begin with. */
    '#blkTime{position:fixed;inset:0;z-index:70;display:none}',
    '#blkTime.open{display:block}',
    '.blk-timerow{gap:10px}',
    '.blk-timefield{width:100%;background:#fff;border:1px solid var(--line);border-radius:14px;',
    '  padding:12px 14px;text-align:left;cursor:pointer}',
    '.blk-timefield .flbl{display:block;margin-bottom:2px}',
    '.blk-timefield b{font:800 20px var(--font-display);color:var(--navy)}',
    '.blk-time-cols{display:flex;align-items:center;justify-content:center;gap:6px;margin:10px 0 16px}',
    '.blk-time-col{height:190px;overflow-y:auto;scroll-snap-type:y mandatory;width:96px;',
    '  -webkit-overflow-scrolling:touch}',
    '.blk-time-col::-webkit-scrollbar{display:none}',
    '.blk-time-item{display:block;width:100%;background:none;border:0;padding:11px 0;',
    '  font:600 21px var(--font-display);color:var(--faint);cursor:pointer;scroll-snap-align:center}',
    '.blk-time-item.on{color:var(--navy);font-weight:800;background:var(--blue-soft);border-radius:12px}',
    '.blk-time-sep{font:800 22px var(--font-display);color:var(--navy)}'
  ].join(' ');
  const st = document.createElement('style');
  st.id = 'blk-time-style';
  st.textContent = css;
  document.head.appendChild(st);
})();

/* ---- Emoji picker for the editor: the big icon, or an emoji dropped into the name ---- */
const BLK_EMOJI = ['🕑','⏳','🚫','🎯','📚','💼','🧠','🌙','☀️','🏃','🧘','💤','📵','🔕','🔒','🛡️','🎓','✍️','🧪','💻',
  '🍎','🏋️','🚴','🎨','🎸','📖','🧹','🍽️','👨‍👩‍👧','❤️','🔥','⚡','🌱','🌊','🏔️','🚀','🎧','📝','⏰','🛏️',
  '📵','🙈','🐢','🦁','🐝','🍀','🌸','🎁','🏆','💎','🗝️','🧭','📌','✅','🧩','🎲','🕹️','📺','🎬','☕'];
function blkEmojiPicker(target){
  let sh = document.getElementById('blkEmoji');
  if(!sh){
    sh = document.createElement('div');
    sh.id = 'blkEmoji';
    sh.className = 'blk-sw';
    sh.innerHTML = '<div class="blk-scrim"></div>' +
      '<div class="blk-sheet"><div class="grab"></div><h3 id="blkEmojiTitle" style="margin:0 0 4px">Scegli un\'emoji</h3>' +
      '<div class="emo-grid" id="blkEmojiGrid"></div>' +
      '<div class="emo-own"><input id="blkEmojiOwn" placeholder="…o scrivine una dalla tastiera" maxlength="4"><button class="cta" style="padding:10px 14px;width:auto" id="blkEmojiUse">Usa</button></div>' +
      '<button class="ghost cancel" id="blkEmojiClose" style="margin-top:8px">Annulla</button></div>';
    const phone = document.getElementById('phone'); (phone || document.body).appendChild(sh);
    sh.querySelector('.blk-scrim').addEventListener('click', function(){ sh.classList.remove('open'); });
    sh.querySelector('#blkEmojiClose').addEventListener('click', function(){ sh.classList.remove('open'); });
    const grid = sh.querySelector('#blkEmojiGrid');
    BLK_EMOJI.filter(function(e,i,a){ return a.indexOf(e) === i; }).forEach(function(e){
      const b = document.createElement('button'); b.type = 'button'; b.textContent = e;
      b.addEventListener('click', function(){ blkEmojiApply(e); });
      grid.appendChild(b);
    });
    sh.querySelector('#blkEmojiUse').addEventListener('click', function(){
      const v = (sh.querySelector('#blkEmojiOwn').value || '').trim();
      if(v) blkEmojiApply(v);
    });
  }
  sh._target = target;
  sh.querySelector('#blkEmojiTitle').textContent = 'Icona del programma';
  sh.querySelector('#blkEmojiOwn').value = '';
  sh.classList.add('open');
}
function blkEmojiApply(e){
  const sh = document.getElementById('blkEmoji');
  if(!sh) return;
  if(sh._target === 'name'){
    const inp = document.getElementById('edName');
    const start = inp.selectionStart != null ? inp.selectionStart : inp.value.length;
    const end = inp.selectionEnd != null ? inp.selectionEnd : start;
    inp.value = inp.value.slice(0, start) + e + ' ' + inp.value.slice(end);
    try{ inp.focus(); inp.setSelectionRange(start + e.length + 1, start + e.length + 1); }catch(_){ }
  } else {
    if(typeof DRAFT === 'object' && DRAFT) DRAFT.icon = e;
    const ico = document.getElementById('edIcon'); if(ico) ico.textContent = e;
  }
  sh.classList.remove('open');
}

/* ---- the Premium band: text and visibility follow the entitlement ---- */
function blkPaintPremBand(){
  const band = document.getElementById('blkPremBand');
  if(!band) return;
  const premium = (typeof Premium !== 'undefined') && Premium.isPremium();
  const tab = document.getElementById('tab-blocco');
  const home = document.getElementById('s-home');
  const onBlocco = !!(tab && tab.classList.contains('on') && home && home.classList.contains('active'));
  band.hidden = premium || !onBlocco;
  if(band.hidden){
    if(tab) tab.style.paddingBottom = '';
    return;
  }
  // Sopra la barra di navigazione, alla sua altezza vera (cambia con la safe area).
  const nav = document.querySelector('.bottomnav');
  const navH = nav ? nav.offsetHeight : 64;
  band.style.bottom = (navH + 10) + 'px';
  if(tab) tab.style.paddingBottom = (96 + band.offsetHeight) + 'px';
  if(premium) return;
  let trialUsed = false; try{ trialUsed = localStorage.getItem('fl_trial_used') === '1'; }catch(_){ }
  band.innerHTML = trialUsed
    ? '💎 <span>Passa a Premium — blocco illimitato, zero pubblicità</span><span class="arr">›</span>'
    : '🎁 <span>7 giorni di Premium gratuiti</span><span class="arr">›</span>';
}
blkPaintPremBand();
if(typeof Premium !== 'undefined' && Premium.onChange) Premium.onChange(blkPaintPremBand);
document.addEventListener('fl:screen', function(){ setTimeout(blkPaintPremBand, 0); });
document.addEventListener('fl:tab', function(){ setTimeout(blkPaintPremBand, 0); });
window.addEventListener('resize', blkPaintPremBand);

(function blkEvStile(){
  const st = document.createElement('style');
  st.textContent = '.blk-ev-velo{position:fixed;inset:0;z-index:60;background:rgba(0,10,26,.62)}'
    + '.blk-card.blk-ev{position:relative;z-index:61;animation:blkEvLampo 1s ease-in-out infinite}'
    + '@keyframes blkEvLampo{0%,100%{box-shadow:0 0 0 3px #4FB8FF,0 0 24px 6px rgba(79,184,255,.75)}50%{box-shadow:0 0 0 3px rgba(79,184,255,.15),0 0 0 0 rgba(79,184,255,0)}}';
  document.head.appendChild(st);
})();
