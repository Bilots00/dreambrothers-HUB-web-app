/* ===========================================================================================
   IL NAVIGATORE — la configurazione

   Tutti i numeri del motore di arrivo stanno qui, e solo qui. Il motore (eta-motore.js) e'
   puro: riceve questa tabella e i fatti, e restituisce le date. Cambiare un numero qui non
   richiede di capire il motore; cambiare il motore non richiede di cercare i numeri.

   Le unita': le ore sono ore, i minuti sono minuti, i giorni sono giorni. Dove un numero e' un
   moltiplicatore lo dice il nome.
   =========================================================================================== */
const ETA_CFG = {
  /* ---- la strada ----
     I mesi del Genio sono una lunghezza di strada, non una data: valgono a QUESTO ritmo di
     ore a settimana. Dieci ore sono il passo «normale» dell'app (tre sessioni da mezz'ora al
     giorno, tutti i giorni). Chi pianifica di piu' arriva prima, chi pianifica di meno dopo. */
  oreSettimanaRiferimento: 10,
  /* il fattore di stima (planning fallacy): ore reali / ore stimate sulle ultime task chiuse
     con del tempo di concentrazione collegato. Finche' le task misurate sono poche vale il
     voto dato dopo la spunta («troppo pochi / giusti / troppi»), e prima ancora il default. */
  fattoreStima: { default: 1.5, min: 0.8, max: 3.0, minTask: 5, finestraTask: 20,
                  voti: { 'troppo pochi': 1.5, 'giusti': 1.0, 'troppi': 0.7 } },
  /* la scoperta: la strada cresce man mano che la si scrive. Misurata sulla crescita
     settimanale delle ore pianificate (8 settimane); prima, il dieci per cento. */
  scoperta: { default: 0.10, min: 0, max: 0.3, settimane: 8, settimaneMin: 4 },
  /* la stima provvisoria di una task senza stima, in minuti, per tipo */
  stimaProvvisoria: { riga: 30, priorita: 60,
                      orizzonte: { adesso: 30, oggi: 60, settimana: 120, mese: 240, anno: 480, cinque: 960, ungiorno: 960 } },
  /* il credito di una giornata non supera N volte le ore pianificate: una fila di spunte
     senza tempo dietro non e' una giornata di lavoro */
  creditoMaxAlGiorno: 3,
  /* LE DEVIAZIONI (0.9.285): un'idea fuori rotta che tieni oggi vale questi minuti se nessuno li ha misurati
     (l'arbitro sul computer misura la risposta di Claude); le idee di un giorno spostano l'arrivo al massimo di
     un giorno di strada, perche' piu' di una giornata non te la possono togliere. */
  deviazione: { minutiDefault: 30, maxGiorniIdee: 1, maxGiorniImprevisto: 60 },
  freno: { stradaGiorni: 1, passoMax: 0.03 },

  /* ---- il piano ----
     Le ore a settimana di serie per modalita' (modificabili nelle Opzioni di viaggio), e i
     giorni di lavoro di serie: tutti. Un giorno a zero e' un giorno di riposo pianificato. */
  capacita: { facile: 5, normale: 10, difficile: 17.5 },
  giorniDiSerie: [1, 1, 1, 1, 1, 1, 1],          // domenica … sabato
  /* la finestra in cui il lavoro cade dentro a un giorno: serve a interpolare l'arrivo
     dentro al giorno finale, mai a mostrare un orario */
  finestraGiorno: { da: 8, a: 22 },
  /* il lavoro al computer conta come strada solo se il sogno e' di quel tipo */
  pcLavoro: { conta: true, target: ['lavoro', 'carriera', 'studio', 'arte'], sogliaVoceMin: 15 },

  /* ---- il passo ----
     Il tasso di esecuzione di un giorno = credito / ore pianificate, fra 0 e 2. Si campiona
     dagli ultimi 120 giorni veri, pesati sul recente (dimezzamento a 60 giorni).
     PERCHE' NON 56 E 21: con quella memoria un solo giorno vuoto pesava un quindicesimo del
     campione e spostava un arrivo a un anno di 24 giorni — un contatore d'ansia con un altro
     nome. Il passo di una persona si impara in mesi, non in due settimane; il giorno vuoto
     sposta comunque la data (la strada non si e' accorciata), ma di quello che vale. */
  rate: { min: 0, max: 3, giorniStoria: 120, mezzaVita: 60 },
  /* la calibrazione: sotto i 14 giorni di dati il campione e' un prior a media 0,6 e larga
     varianza, che pesa come dieci giorni e si spegne man mano che i giorni veri arrivano */
  calibrazione: { giorni: 14, priorMedia: 0.6, priorPeso: 10,
                  priorValori: [0.1, 0.25, 0.4, 0.5, 0.55, 0.6, 0.65, 0.7, 0.85, 1.0, 1.15, 0.45] },
  /* la qualita' Q: da 0,7 a 1,1, a piccoli passi spiegabili */
  Q: { min: 0.7, max: 1.1,
       sessioneLunga: 45, sessioneCorta: 20, bonusLunga: 0.05, malusCorta: 0.05,
       finestreQuota: 0.6, finestreBonus: 0.05,
       cambiOra: [15, 30], cambiMalus: [0.05, 0.12],
       passivoQuota: 0.5, passivoMalus: 0.05,
       veicoloMax: 0.03 },
  /* la varianza del campione: si allarga se le tappe cadono fuori dall'intervallo, si stringe
     se ci cadono quasi tutte. Un collo di bottiglia sulla via critica la allarga. */
  varianza: { default: 1, min: 0.6, max: 1.8, passo: 0.15, sogliaLarga: 0.7, sogliaStretta: 0.9, minTappe: 5, collo: 0.15 },
  /* gli indicatori anticipatori (riserva di dopamina, cambi d'app): pesi per persona, da una
     regressione dopo 30 giorni; prima pesano zero. Inclinano solo i prossimi 7 giorni. */
  indicatori: { giorniMin: 30, giorniPrevisti: 7, tiltMin: 0.8, tiltMax: 1.2, lambda: 2.0 },
  /* il collo di bottiglia: una task rimandata tre volte */
  collo: { rimandi: 3 },

  /* ---- la simulazione ----
     Duemila cammini, un seme per viaggio, gli stessi numeri casuali a ogni ricalcolo. Dopo
     730 giorni simulati ogni cammino finisce con il proprio passo medio (la coda analitica):
     sette anni di strada sono duemilacinquecento giorni, e un telefono non deve fermarsi. */
  simulazione: { runs: 2000, codaGiorni: 730, maxGiorni: 365 * 40, tabella: 2048 },

  /* ---- la carta ---- */
  precisione: { default: 'precisa' },            // 'semplice' | 'precisa' | 'dettagliata'
  /* le abitudini: un pattern conta se torna in almeno 5 degli ultimi 10 giorni attivi */
  abitudini: { giorni: 30, finestra: 10, minRicorrenze: 5, minGiorni: 6 },
  fantasma: { percentile: 0.8, minGiorni: 5 },
  veicolo: { rttLento: 400, tipiLenti: ['slow-2g', '2g'], minRipetizioni: 2, ultimeProve: 4, malus: 0.02 },
  registro: { max: 600 },
  snapshotOra: 3,                                 // l'ora di riserva per chiudere la giornata
  formato: { ore: 'h', minuti: 'min', giorni: 'g' }
};

if (typeof module !== 'undefined' && module.exports) module.exports = { ETA_CFG: ETA_CFG };
