/* ===========================================================================================
   NIENTE STRETCH, IN NESSUNA PAGINA (0.9.358)

   Andrea, 14/11: "le schede di La tua dopamina di oggi, se l'utente tiene premuto e va su e giu' con il dito, si
   allungano in verticale e il testo Cause viene tagliato; lo stesso nella pagina del bivio. Non voglio piu' vedere in
   nessuna parte del sito lo stretch, l'allungamento e la distorsione del testo e del contenuto".

   LA CAUSA. Dalla versione 145 la WebView di Android stira OGNI pannello che scorre, non piu' solo la pagina:
   il movimento che il pannello non riesce a usare diventa l'effetto elastico (Chromium, cc/input/input_handler.cc,
   OverscrollEffectOnNonRootScrollers). Lo spegne solo overscroll-behavior:none su quell'asse ("contain" lo lascia).
   Nella fila delle schede il dito parte di lato, la fila prende il gesto e poi, andando su e giu', tutto il movimento
   verticale diventa elastico: le scritte si allungano.

   PERCHE' NON UNA REGOLA CSS FISSA. Con overscroll-behavior non auto un pannello trattiene il gesto anche sull'asse in
   cui non scorre (stesso file, FindNodeToLatch): una fila che scorre di lato con none in verticale ferma lo scorrimento
   della pagina quando il dito parte da li'. E' quello che nel 0.9.351 aveva fermato i caroselli (*{overscroll-behavior-x:
   none}). Quindi la regola si mette DURANTE il gesto: quando il dito si e' gia' mosso di 16 px la WebView ha gia' scelto
   chi lo riceve, e da li' in poi ogni pannello che scorre sotto al dito ha overscroll-behavior:none. Si toglie quando
   lo scorrimento (anche la spinta dopo che il dito si alza) si ferma, e comunque al tocco successivo.
   Nessuna regola globale: solo uno stile in linea, sui pannelli toccati, per il tempo del gesto. Vale anche dentro i
   riquadri delle note e del piano (note/, notion/): si installa in ogni iframe appena si carica, e le loro pagine
   caricano questo file anche quando si aprono da sole (le note nella loro attivita', ?app=sola).
   Un file a parte (non dentro scorre.js) proprio per questo: scorre.js cambia i timer, e nelle note non serve.
   =========================================================================================== */
window.FL_NIENTE_STRETCH = 1;
function flNienteStretchIn(doc){
  if (!doc || doc.__flNienteStretch) return;
  doc.__flNienteStretch = 1;
  let bersaglio = null, deciso = false, x0 = 0, y0 = 0, messi = [], timer = 0, ultimo = 0;
  const segna = function(){ ultimo = Date.now(); };
  const radice = doc.documentElement;
  /* i pannelli che scorrono davvero (overflow auto o scroll, con qualcosa da scorrere), dal dito in su */
  function pannelli(el){
    const out = [];
    const vista = doc.defaultView || window;
    for (let n = el; n && n.nodeType === 1 && n !== radice; n = n.parentElement){
      const lx = n.scrollWidth > n.clientWidth + 1, ly = n.scrollHeight > n.clientHeight + 1;
      if (!lx && !ly) continue;
      const cs = vista.getComputedStyle(n);
      const sx = lx && (cs.overflowX === 'auto' || cs.overflowX === 'scroll');
      const sy = ly && (cs.overflowY === 'auto' || cs.overflowY === 'scroll');
      if (sx || sy) out.push(n);
    }
    return out;
  }
  function togli(){
    clearTimeout(timer); timer = 0;
    for (let i = 0; i < messi.length; i++){
      const m = messi[i];
      m[0].removeEventListener('scroll', segna);
      m[0].style.overscrollBehavior = m[1];
    }
    messi = [];
  }
  function metti(){
    const lista = pannelli(bersaglio);
    for (let i = 0; i < lista.length; i++){
      const n = lista[i];
      messi.push([n, n.style.overscrollBehavior]);
      n.style.overscrollBehavior = 'none';
      n.addEventListener('scroll', segna, { passive: true });
    }
  }
  /* i timer sotto i 150 ms non passano dalla coda di questo file: la regola si toglie appena lo scorrimento si ferma */
  function controlla(){
    if (Date.now() - ultimo > 240){ togli(); return; }
    timer = setTimeout(controlla, 120);
  }
  doc.addEventListener('touchstart', function(e){
    togli();
    deciso = false;
    bersaglio = (e.touches && e.touches.length === 1) ? e.target : null;
    if (bersaglio){ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }
  }, { capture: true, passive: true });
  doc.addEventListener('touchmove', function(e){
    if (!bersaglio || deciso || !e.touches || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - x0, dy = e.touches[0].clientY - y0;
    if (dx * dx + dy * dy < 256) return;
    deciso = true;
    metti();
    segna();
  }, { capture: true, passive: true });
  const fine = function(){
    bersaglio = null;
    if (!messi.length) return;
    segna();
    clearTimeout(timer);
    timer = setTimeout(controlla, 120);
  };
  doc.addEventListener('touchend', fine, { capture: true, passive: true });
  doc.addEventListener('touchcancel', fine, { capture: true, passive: true });
}
flNienteStretchIn(document);
/* le note e il piano vivono in un iframe: anche li' dentro, appena il riquadro si carica */
document.addEventListener('load', function(e){
  const f = e.target;
  if (!f || f.tagName !== 'IFRAME') return;
  try{ flNienteStretchIn(f.contentDocument); }catch(_){ }
}, true);
