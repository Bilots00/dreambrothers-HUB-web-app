/* ===========================================================================================
   L'ANTEPRIMA SOCIALE (solo admin): tutta la parte di comunita' dell'app, provata con amici
   simulati, per farla toccare ad Andrea e mostrarla a un investitore.

   CHI LA VEDE. Solo chi ha flAdmin() (admin.js, fl_admin='1'). Per tutti gli altri nessuna
   funzione cambia comportamento: ogni involucro qui sotto chiama l'originale e basta.

   GLI AMICI SIMULATI. Nomi, avatar (img/avatar/a1-a6.svg) e numeri nascono sul telefono, da un
   seme che dipende dal giorno: oggi sono sempre gli stessi, domani si muovono. Hanno il device
   che comincia con "bot-": e' quello che li tiene lontani dal server (reazioni, segui, Focus
   insieme, diario passano da qui e non escono dal telefono). Sono marcati dal cartellino giallo
   "Anteprima".

   COSA C'E', sul modello di Duolingo:
   1. Missione di gruppo di 3 giorni con un amico (splash d'inizio, card con barra e contributi).
   2. Incoraggia: quattro reazioni, un pulsante grande, e la voce nel feed.
   3. Regalo: la Pozione della concentrazione. Quella che ricevi accende DAVVERO gli XP doppi per
      15 minuti (sdBoostDai di sentiero-mappa.js, la stessa sfera di fine episodio) e, nella lega
      dell'anteprima, raddoppia i punti dei minuti di Full Focus fatti in quella finestra.
   4. Feed degli amici con Mi piace e risposte rapide.
   5. Full Focus in coppia: la ricerca alla Clash Royale, il compagno trovato, il suo stato dal
      vivo durante la sessione e il risultato condiviso. Il Full Focus e' quello vero (ffOpen e
      ffStart, come fa insieme.js): qui si aggiunge solo il compagno.
   6. La Lega con persone dello stesso sogno: trenta posti, zone di promozione e retrocessione.
   =========================================================================================== */
const AS = { tick: 0, match: null, matchT: 0, matchGiro: 0, incSel: 'muscolo', regSel: 'pozione' };
const AS_DONNE = { giulia: 1, sara: 1, chiara: 1, elena: 1, francesca: 1, martina: 1, valentina: 1, alice: 1, beatrice: 1, noemi: 1, irene: 1, aurora: 1, camilla: 1, sofia: 1, greta: 1 };
const AS_NOMI = ['Giulia', 'Marco', 'Sara', 'Luca', 'Chiara', 'Davide', 'Elena', 'Matteo', 'Francesca', 'Alessandro', 'Martina', 'Simone', 'Valentina', 'Federico', 'Alice', 'Riccardo', 'Beatrice', 'Tommaso', 'Noemi', 'Gabriele', 'Irene', 'Lorenzo', 'Aurora', 'Pietro', 'Camilla', 'Edoardo', 'Sofia', 'Nicola', 'Greta'];
const AS_N_AMICI = 5;
const AS_INC = [
  { k: 'muscolo', e: '💪', t: 'Finiamo in bellezza!' },
  { k: 'gatto', e: '😾', t: 'Non farmi rimanere male!' },
  { k: 'cinque', e: '🙌', t: 'Batti il cinque!' },
  { k: 'genio', img: 'img/genio/genio-saluta.png', t: 'Ce la fai!' }
];
const AS_REGALI = [
  { k: 'pozione', e: '🧪', n: 'Pozione della concentrazione', s: 'Raddoppia i punti per 15 minuti.' },
  { k: 'scudo', e: '🛡️', n: 'Scudo della serie', s: 'Protegge la serie per un giorno.' }
];
const AS_RISPOSTE = ['Grande!', 'Continua così!', 'Fiero di te', 'Ce la fai!', 'Ci vediamo in vetta'];

/* ---------------------------------------------------------------- basi */
function asOn(){ try{ return typeof flAdmin === 'function' && flAdmin(); }catch(_){ return false; } }
function asE(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function asJs(v){ return JSON.stringify(String(v == null ? '' : v)).replace(/"/g, '&quot;'); }
function asHash(s){ let h = 2166136261; s = String(s); for (let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h; }
function asRnd(seed){
  let a = asHash(seed) || 1;
  return function(){ a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function asG0(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function asGiorno(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function asNumGiorno(t){ const d = new Date(t || Date.now()); return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000); }
function asLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function asScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function asVibra(p){ try{ if (typeof flVibra === 'function') flVibra(p); }catch(_){ } }
function asToast(m){ try{ if (typeof toast === 'function') toast(m); }catch(_){ } }
function asBadge(){ return '<span class="as-badge">Anteprima</span>'; }
function asLunedi(){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); }
function asCat(){ try{ return (typeof frCategoriaSuggerita === 'function') ? frCategoriaSuggerita() : 'lavoratori'; }catch(_){ return 'lavoratori'; } }
function asCatNome(){ const k = asCat(); try{ const n = (typeof frCatNome === 'function') ? frCatNome(k) : ''; if (n && n !== k) return n; }catch(_){ } return { studenti: 'Studenti', imprenditori: 'Imprenditori', lavoratori: 'Lavoratori', creator: 'Creator', sportivi: 'Sportivi' }[k] || 'Lavoratori'; }
function asOre(min){ return (typeof frOre === 'function') ? frOre(min) : Math.round(min) + ' minuti'; }
function asQuando(at){
  const m = Math.max(0, Math.round((Date.now() - at) / 60000));
  if (m < 2) return 'adesso';
  if (m < 60) return m + ' minuti fa';
  const h = Math.round(m / 60); if (h < 24) return h === 1 ? 'un\'ora fa' : h + ' ore fa';
  const g = Math.round(h / 24); return g === 1 ? 'ieri' : g + ' giorni fa';
}

/* ---------------------------------------------------------------- gli amici simulati */
function asBot(i){
  const nome = AS_NOMI[i % AS_NOMI.length];
  const k = nome.toLowerCase();
  const av = i < 6 ? 'img/avatar/a' + (i + 1) + '.svg' : (i % 3 === 0 ? 'img/avatar/a' + ((i % 6) + 1) + '.svg' : '');
  return { device: 'bot-' + k, nome: nome, av: av, i: i, f: !!AS_DONNE[k] };
}
function asBotDa(device){
  if (!device || String(device).indexOf('bot-') !== 0) return null;
  for (let i = 0; i < AS_NOMI.length; i++){ const b = asBot(i); if (b.device === device) return b; }
  return null;
}
function asO(b){ return b && b.f ? 'a' : 'o'; }
/** Un amico simulato con i numeri di oggi: la serie sale di uno al giorno, le ore crescono con la settimana. */
function asAmicoBot(b){
  const rs = asRnd(b.device), r = asRnd(b.device + asGiorno());
  const giorni = Math.max(0, asNumGiorno() - asNumGiorno(new Date(2026, 9, 1).getTime()));
  const streak = 4 + Math.floor(rs() * 30) + giorni;
  const wk = Math.max(0.1, Math.min(1, (Date.now() - asLunedi()) / (7 * 86400000)));
  const ffMin7 = Math.round((180 + rs() * 520) * wk + r() * 25);
  const prev = Math.round((180 + rs() * 520) * 2 * (0.7 + r() * 0.5));
  const reaz = (asLeggi('fl_as_reaz', {})[asGiorno()] || {})[b.device] || [];
  return {
    device: b.device, nome: b.nome, bot: true, av: b.av, f: b.f,
    streak: streak, ffMin7: ffMin7, score7: ffMin7 * 2 + streak * 5, prevScore7: prev,
    neo: 9 + Math.floor(rs() * 18) + (giorni % 7), old: 2 + Math.floor(r() * 6), level: 2 + Math.floor(rs() * 6),
    online: r() < 0.55, attivita: r() < 0.6 ? 'ff' : 'app',
    visto: new Date(Date.now() - Math.floor(r() * 5 * 3600000)).toISOString(),
    tier: ['oro', 'argento', 'argento', 'bronzo', 'oro'][b.i % 5],
    capitolo: 2 + Math.floor(rs() * 4) + Math.floor(giorni / 6),
    reazioniOggi: reaz.slice(),
    metriche: asMetricheBot(b.device, streak)
  };
}
/** 0.9.300: i numeri del confronto (Oggi / Settimana / Mese / Serie) di un amico simulato, nella stessa
    forma che il telefono pubblica (frMetriche in friends.js). Il mese contiene la settimana, la settimana oggi. */
function asMetricheBot(device, serie){
  const rs = asRnd(device + 'met'), r = asRnd(device + 'met' + asGiorno());
  const ora = Date.now(), d = new Date();
  const gSett = ((d.getDay() + 6) % 7) + 1, gMese = d.getDate();
  const gPrima = Math.max(0, Math.min(gMese, gSett) - 1);     /* giorni di questa settimana prima di oggi, nel mese */
  const quota = Math.max(0.15, Math.min(1, (ora - asG0()) / 86400000 * 1.4));
  const tre = function(oggi, perGiorno){ return { g: oggi, s: oggi + Math.round(perGiorno * (gSett - 1)), m: oggi + Math.round(perGiorno * (gMese - 1)) }; };
  const tappeDi = 0.5 + rs() * 2;
  const sevOn = rs() < 0.55;
  const sch = 90 + Math.round(rs() * 240);
  const k = (typeof frK === 'function') ? frK : function(t){ return asGiorno(t); };
  return {
    v: 1, giorno: k(ora), lunedi: k(asLunedi()), mese: d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'),
    tappe: tre(Math.floor(r() * 3), tappeDi),
    severa: sevOn ? { g: 1, s: gSett, m: Math.min(gMese, gPrima + 1 + Math.floor(rs() * Math.max(0, gMese - gSett))) } : { g: 0, s: Math.floor(rs() * gSett), m: Math.floor(rs() * gMese) },
    ff: tre(Math.round(r() * 60), 30 + rs() * 70),
    schermo: rs() < 0.8 ? tre(Math.round(sch * quota), sch) : null,
    serie: serie || 0
  };
}
function asAmiciBot(){ const l = []; for (let i = 0; i < AS_N_AMICI; i++) l.push(asAmicoBot(asBot(i))); return l; }
function asAmicoDa(device){ return asAmiciBot().filter(function(a){ return a.device === device; })[0] || null; }
function asAvHtml(b, cls){
  if (b && b.av) return '<span class="am-av as-av' + (cls ? ' ' + cls : '') + '"><img src="' + b.av + '" alt=""></span>';
  if (typeof frAv === 'function') return frAv(b ? b.nome : '?', b ? b.device : '', cls);
  return '<span class="am-av">' + asE((b && b.nome || '?').charAt(0)) + '</span>';
}
function asTuHtml(cls){ try{ const pic = (typeof flImgGet === 'function' && typeof UF_AVATAR_KEY !== 'undefined') ? flImgGet(UF_AVATAR_KEY) : ''; if (pic && typeof flAvMio === 'function') return flAvMio('as-tu' + (cls ? ' ' + cls : '')); }catch(_){ } let n = ''; try{ n = (typeof frName === 'function' ? frName() : '').charAt(0).toUpperCase(); }catch(_){ } return '<span class="am-av me as-tu' + (cls ? ' ' + cls : '') + '">' + asE(n || 'Tu') + '</span>'; }

/* ---------------------------------------------------------------- i punti doppi */
function asBoostResta(){
  let a = 0; try{ if (typeof sdBoostResta === 'function') a = sdBoostResta(); }catch(_){ }
  return Math.max(a, (+asLeggi('fl_as_boost', 0) || 0) - Date.now());
}
function asBoostTxt(){ const s = Math.ceil(asBoostResta() / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function asBoostAccendi(){
  const fino = Date.now() + 15 * 60000;
  try{ if (typeof sdBoostDai === 'function') sdBoostDai(15, 2); }catch(_){ }
  asScrivi('fl_as_boost', fino);
  const fin = asLeggi('fl_as_boost_win', []); fin.push({ da: Date.now(), a: fino }); asScrivi('fl_as_boost_win', fin.slice(-40));
}
function asBoostPill(){ return asBoostResta() > 0 ? '<div class="as-boost"><span>⚡</span><b>Punti doppi</b><small>ancora <i class="as-boost-t">' + asBoostTxt() + '</i></small></div>' : ''; }
/** I punti in piu' della lega: i minuti di Full Focus fatti mentre la pozione era accesa contano due volte. */
function asBoostBonusLega(){
  const fin = asLeggi('fl_as_boost_win', []), lun = asLunedi();
  let extra = 0;
  try{
    (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){
      const s = h.start || h.at; if (!h.ok || h.meditazione || s < lun) return;
      const e = s + (h.spentMs || (h.min || 0) * 60000);
      fin.forEach(function(w){ const o = Math.min(e, w.a) - Math.max(s, w.da); if (o > 0) extra += o / 60000; });
    });
  }catch(_){ }
  return Math.round(extra);
}

/* ---------------------------------------------------------------- la missione di gruppo */
function asMissione(){
  const g = asNumGiorno(), w = Math.floor(g / 3);
  const inizio = asG0() - (g % 3) * 86400000, fine = inizio + 3 * 86400000;
  const amici = asAmiciBot();
  const p = amici[w % amici.length];
  const tipo = w % 2 ? 'minuti' : 'sessioni';
  const goal = tipo === 'sessioni' ? 10 : 150;
  let mio = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){ const t = h.start || h.at; if (h.ok && !h.meditazione && t >= inizio && t < fine) mio += tipo === 'sessioni' ? 1 : Math.round((h.spentMs || (h.min || 0) * 60000) / 60000); }); }catch(_){ }
  const r = asRnd('mis' + w);
  const fr = Math.min(1, (Date.now() - inizio) / (fine - inizio));
  const lui = Math.round(goal * (0.3 + r() * 0.2) * Math.min(1, 0.15 + fr * 1.3));
  const tot = Math.min(goal, mio + lui);
  const st = asLeggi('fl_as_mis', {});
  if (tot >= goal && st.vinta !== w){ st.vinta = w; st.fila = (st.fila || 0) + 1; asScrivi('fl_as_mis', st); }
  return { w: w, inizio: inizio, fine: fine, p: p, tipo: tipo, goal: goal, mio: mio, lui: lui, tot: tot, fatta: tot >= goal, fila: st.fila || 0,
    titolo: tipo === 'sessioni' ? 'Completa ' + goal + ' sessioni di Full Focus' : 'Fai ' + goal + ' minuti di Full Focus' };
}
function asMissioneHtml(){
  const m = asMissione();
  const restaG = Math.max(1, Math.ceil((m.fine - Date.now()) / 86400000));
  const pMio = Math.min(100, m.mio / m.goal * 100), pLui = Math.min(100 - pMio, m.lui / m.goal * 100);
  const unita = m.tipo === 'sessioni' ? function(n){ return n === 1 ? '1 sessione' : n + ' sessioni'; } : function(n){ return n + ' minuti'; };
  return '<div class="am-sect first"><b>Missione di gruppo</b><span>' + asBadge() + '</span></div>'
    + '<div class="as-card as-mis">'
    /* 0.9.321, come Duolingo: le due persone sopra al compito */
    +   '<div class="as-mis-art">' + asTuHtml('grande') + asAvHtml(m.p, 'grande') + '</div>'
    +   '<div class="as-mis-top"><span class="as-mis-tag">3 giorni</span><small>' + (restaG === 1 ? 'Ultimo giorno' : 'Mancano ' + restaG + ' giorni') + '</small></div>'
    +   '<b class="as-mis-t">' + asE(m.titolo) + '</b>'
    +   '<div class="as-mis-bar"><i class="io" style="width:' + pMio + '%"></i><i class="lui" style="width:' + pLui + '%"></i><span>' + m.tot + ' / ' + m.goal + '</span></div>'
    +   (m.fatta ? '<p class="as-mis-ok">🎉 Missione completata: bravi tutti e due!</p>' : '')
    +   '<div class="as-mis-righe">'
    +     '<div class="as-mis-r">' + asTuHtml() + '<b>Tu</b><span>' + unita(m.mio) + '</span></div>'
    +     '<div class="as-mis-r">' + asAvHtml(m.p) + '<b>' + asE(m.p.nome) + '</b><span>' + unita(m.lui) + '</span></div>'
    +   '</div>'
    +   '<div class="as-mis-btn dso-mis-btn"><button type="button" onclick="asIncoraggiaApri(' + asJs(m.p.device) + ')">👏 Incoraggia</button><button type="button" onclick="asRegaloApri(' + asJs(m.p.device) + ')">🎁 Regalo</button></div>'
    + '</div>';
}
function asSplashForse(){
  if (!asOn()) return;
  const m = asMissione(), st = asLeggi('fl_as_mis', {});
  if (st.splash === m.w || document.getElementById('asSplash')) return;
  st.splash = m.w; asScrivi('fl_as_mis', st);
  const w = document.createElement('div'); w.id = 'asSplash'; w.className = 'as-full';
  w.innerHTML = '<div class="as-full-in">' + asBadge()
    + '<h2>È iniziata una nuova Missione di gruppo!</h2>'
    + '<div class="as-duo">' + '<div>' + asTuHtml('xl') + '<b>Tu</b></div><span class="as-duo-piu">+</span><div>' + asAvHtml(m.p, 'xl') + '<b>' + asE(m.p.nome) + '</b></div></div>'
    + '<p class="as-fila">🔥 ' + (m.fila === 1 ? '1 missione di fila' : m.fila + ' missioni di fila') + '</p>'
    + '<p class="as-full-p">' + asE(m.titolo) + ' in 3 giorni. Quello che fa uno vale per tutti e due.</p>'
    + '<button type="button" class="as-cta-y" onclick="asSplashChiudi()">Iniziamo</button></div>';
  (document.getElementById('phone') || document.body).appendChild(w);
  asVibra([20, 40, 60]);
  setTimeout(function(){ w.classList.add('in'); }, 20);
}
function asSplashChiudi(){ const w = document.getElementById('asSplash'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 250); }

/* ---------------------------------------------------------------- incoraggia */
function asIncoraggiaApri(device){
  const a = asAmicoDa(device) || asBotDa(device); if (!a || typeof inSheet !== 'function') return;
  AS.incSel = AS.incSel || 'muscolo';
  inSheet('<div class="am-sheet center as-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="as-sh-av">' + asAvHtml(a, 'lg') + '</div>'
    + '<b class="am-sh-title">Incoraggia ' + asE(a.nome) + '</b><p class="am-sh-p">Scegli cosa mandar' + (a.f ? 'le' : 'gli') + '.</p>'
    + '<div class="as-inc">' + AS_INC.map(function(x){ return '<button type="button" class="as-inc-b' + (x.k === AS.incSel ? ' on' : '') + '" onclick="asIncScegli(\'' + x.k + '\',this)">' + (x.img ? '<img src="' + x.img + '" alt="">' : '<span>' + x.e + '</span>') + '<small>' + asE(x.t) + '</small></button>'; }).join('') + '</div>'
    + '<button type="button" class="am-cta" onclick="asIncoraggiaManda(' + asJs(a.device) + ')">Incoraggia ' + asE(a.nome) + '!</button>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">No, grazie</button></div>');
}
function asIncScegli(k, btn){ AS.incSel = k; document.querySelectorAll('.as-inc-b').forEach(function(b){ b.classList.toggle('on', b === btn); }); asVibra(8); }
function asIncoraggiaManda(device){
  const a = asBotDa(device); if (!a) return;
  const x = AS_INC.filter(function(z){ return z.k === AS.incSel; })[0] || AS_INC[0];
  if (typeof inSheetChiudi === 'function') inSheetChiudi();
  asMiaVoce(x.e || '✨', 'Hai incoraggiato ' + a.nome + ': <b>"' + asE(x.t) + '"</b>');
  asVibra([14, 30, 14]);
  asToast((x.e ? x.e + ' ' : '') + 'Hai incoraggiato ' + a.nome);
  asRidisegna();
  /* dopo qualche secondo risponde: e' quello che fa sembrare vivo il gruppo */
  setTimeout(function(){
    const ris = AS_INC[(asHash(device + Date.now()) % 3)];
    asVoceDi(a, ris.e, 'Ti ha risposto: <b>"' + asE(ris.t) + '"</b>');
    asToast(ris.e + ' ' + a.nome + ' ti ha risposto: "' + ris.t + '"');
    asRidisegna();
  }, 4500);
}

/* ---------------------------------------------------------------- regalo */
function asRegaloApri(device){
  const a = asAmicoDa(device) || asBotDa(device); if (!a || typeof inSheet !== 'function') return;
  const fatti = asLeggi('fl_as_doni', {})[asGiorno()] || {};
  if (fatti[device]){ asToast('Oggi hai già mandato un regalo a ' + a.nome); return; }
  inSheet('<div class="am-sheet center as-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="as-sh-av">' + asAvHtml(a, 'lg') + '</div>'
    + '<b class="am-sh-title">Un regalo per ' + asE(a.nome) + '</b><p class="am-sh-p">Uno al giorno. Arriva subito.</p>'
    + '<div class="as-reg">' + AS_REGALI.map(function(x){ return '<button type="button" class="as-reg-b' + (x.k === AS.regSel ? ' on' : '') + '" onclick="asRegScegli(\'' + x.k + '\',this)"><span>' + x.e + '</span><div><b>' + asE(x.n) + '</b><small>' + asE(x.s) + '</small></div></button>'; }).join('') + '</div>'
    + '<button type="button" class="am-cta" onclick="asRegaloManda(' + asJs(a.device) + ')">Manda il regalo</button>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">No, grazie</button></div>');
}
function asRegScegli(k, btn){ AS.regSel = k; document.querySelectorAll('.as-reg-b').forEach(function(b){ b.classList.toggle('on', b === btn); }); asVibra(8); }
function asRegaloManda(device){
  const a = asBotDa(device); if (!a) return;
  const x = AS_REGALI.filter(function(z){ return z.k === AS.regSel; })[0] || AS_REGALI[0];
  const d = asLeggi('fl_as_doni', {}); const g = asGiorno(); const oggi = d[g] || {}; oggi[device] = x.k;
  asScrivi('fl_as_doni', { [g]: oggi });
  if (typeof inSheetChiudi === 'function') inSheetChiudi();
  asMiaVoce(x.e, 'Hai regalato a ' + a.nome + ': <b>' + asE(x.n) + '</b>');
  asVibra([20, 30, 60]);
  asToast(x.e + ' Regalo mandato a ' + a.nome);
  asRidisegna();
}
/** Il regalo di un amico: accende davvero i punti doppi per 15 minuti. */
function asRegaloRicevi(id){
  const p = asLeggi('fl_as_presi', {}); if (p[id]) return;
  p[id] = Date.now(); asScrivi('fl_as_presi', p);
  asBoostAccendi();
  asVibra([30, 40, 90]);
  asToast('⚡ Punti doppi per 15 minuti: fai una sessione adesso');
  asRidisegna();
}

/* ---------------------------------------------------------------- il feed */
function asMiaVoce(e, t){ const l = asLeggi('fl_as_mie', []); l.push({ id: 'io-' + Date.now(), e: e, t: t, at: Date.now() }); asScrivi('fl_as_mie', l.slice(-30)); }
function asVoceDi(a, e, t){ const l = asLeggi('fl_as_loro', []); l.push({ id: 'lo-' + Date.now(), d: a.device, e: e, t: t, at: Date.now() }); asScrivi('fl_as_loro', l.slice(-30)); }
function asFeed(){
  const g = asGiorno(), r = asRnd('feed' + g), ora = Date.now();
  const finestra = Math.max(40 * 60000, Math.min(14 * 3600000, ora - asG0() + 6 * 3600000));
  const quando = function(){ return ora - 4 * 60000 - Math.floor(r() * finestra); };
  const voci = [];
  asAmiciBot().forEach(function(a){
    const b = asBotDa(a.device);
    const tpl = [
      { e: '🔥', t: 'Ha completato <b>' + a.streak + ' giorni di serie</b>' },
      { e: '🗺️', t: 'Ha passato il <b>capitolo ' + a.capitolo + '</b> della mappa' },
      { e: '⏳', t: 'Ha fatto <b>' + asE(asOre(a.ffMin7)) + ' di Full Focus</b> questa settimana' },
      { e: '🏆', t: 'È salit' + asO(b) + ' in <b>Lega ' + (a.tier === 'oro' ? 'Oro' : (a.tier === 'argento' ? 'Argento' : 'Bronzo')) + '</b>' },
      { e: '🚀', t: 'Sta vincendo la partita contro il vecchio sé: <b>' + a.neo + ' a ' + a.old + '</b>' }
    ];
    const i1 = Math.floor(r() * tpl.length); let i2 = Math.floor(r() * tpl.length); if (i2 === i1) i2 = (i1 + 2) % tpl.length;
    voci.push(Object.assign({ id: g + a.device + i1, a: a, at: quando() }, tpl[i1]));
    if (r() < 0.6) voci.push(Object.assign({ id: g + a.device + i2, a: a, at: quando() }, tpl[i2]));
  });
  const amici = asAmiciBot();
  const dono = amici[asNumGiorno() % amici.length];
  voci.push({ id: 'regalo' + g, a: dono, e: '🧪', t: 'Ti ha mandato un regalo: <b>Pozione della concentrazione</b>', regalo: true, at: ora - 25 * 60000 - Math.floor(r() * 90 * 60000) });
  const m = asMissione();
  voci.push({ id: 'inc' + g, a: m.p, e: '🙌', t: 'Ti ha incoraggiato: <b>"Batti il cinque!"</b>', at: ora - 50 * 60000 - Math.floor(r() * 60 * 60000) });
  asLeggi('fl_as_loro', []).forEach(function(x){ if (ora - x.at < 3 * 86400000){ const a = asAmicoDa(x.d); if (a) voci.push({ id: x.id, a: a, e: x.e, t: x.t, at: x.at }); } });
  asLeggi('fl_as_mie', []).forEach(function(x){ if (ora - x.at < 3 * 86400000) voci.push({ id: x.id, io: true, e: x.e, t: x.t, at: x.at }); });
  voci.forEach(function(v){ if (v.at > ora) v.at = ora; });
  voci.sort(function(x, y){ return y.at - x.at; });
  return voci.slice(0, 16);
}
function asFeedHtml(){
  const st = asLeggi('fl_as_feed', {}), presi = asLeggi('fl_as_presi', {});
  return '<div class="am-sect"><b>Feed</b><span>' + asBadge() + '</span></div>'
    + ((typeof dsoRegaliHtml === 'function') ? dsoRegaliHtml() : '')
    + '<div class="as-feed">' + asFeed().map(function(v){
      const s = st[v.id] || {};
      const base = v.io ? 0 : (asHash(v.id) % 6) + 1;
      const nLike = base + (s.l ? 1 : 0);
      const regalo = v.regalo ? (presi[v.id]
        ? '<span class="as-preso">✓ Regalo ricevuto</span>'
        : '<button type="button" class="as-ricevi" onclick="asRegaloRicevi(' + asJs(v.id) + ')">🎁 Ricevi regalo</button>') : '';
      return '<div class="as-card as-fv">'
        + '<div class="as-fv-top">' + (v.io ? asTuHtml() : asAvHtml(v.a)) + '<div><b>' + (v.io ? 'Tu' : asE(v.a.nome)) + '</b><small>' + asQuando(v.at) + '</small></div><span class="as-fv-e">' + v.e + '</span></div>'
        + '<p>' + v.t + '</p>' + regalo
        + ((s.c || []).length ? '<div class="as-fv-com">' + s.c.map(function(c){ return '<small><b>Tu</b> ' + asE(c) + '</small>'; }).join('') + '</div>' : '')
        + '<div class="as-fv-az"><button type="button" class="' + (s.l ? 'on' : '') + '" onclick="asLike(' + asJs(v.id) + ')">' + (s.l ? '❤️' : '🤍') + ' ' + nLike + '</button>'
        + '<button type="button" onclick="asCommentaApri(' + asJs(v.id) + ')">💬 Commenta</button></div>'
        + '</div>';
    }).join('') + '</div>';
}
function asLike(id){ const st = asLeggi('fl_as_feed', {}); st[id] = st[id] || {}; st[id].l = !st[id].l; asScrivi('fl_as_feed', st); asVibra(10); asRidisegna(); }
function asCommentaApri(id){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="am-sheet center as-sheet"><b class="am-sh-title">Rispondi</b><p class="am-sh-p">Una risposta veloce, niente chat.</p>'
    + '<div class="as-rr">' + AS_RISPOSTE.map(function(t){ return '<button type="button" onclick="asCommenta(' + asJs(id) + ',' + asJs(t) + ')">' + asE(t) + '</button>'; }).join('') + '</div>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">No, grazie</button></div>');
}
function asCommenta(id, t){
  const st = asLeggi('fl_as_feed', {}); st[id] = st[id] || {}; st[id].c = (st[id].c || []).concat([t]).slice(-3); asScrivi('fl_as_feed', st);
  if (typeof inSheetChiudi === 'function') inSheetChiudi();
  asToast('Risposta inviata'); asRidisegna();
}

/* ---------------------------------------------------------------- la lega dello stesso sogno */
function asLegaFinta(){
  const cat = asCat(), sett = (typeof frSettimanaKey === 'function') ? frSettimanaKey() : String(asLunedi());
  const lun = asLunedi(), fine = lun + 7 * 86400000;
  const wk = Math.max(0.04, Math.min(1, (Date.now() - lun) / (7 * 86400000)));
  const membri = [];
  for (let i = 0; i < 29; i++){
    const b = asBot(i);
    const r = asRnd(b.device + sett + cat);
    const target = 180 + Math.floor(r() * 1900);
    const curva = Math.pow(wk, 0.85 + r() * 0.4);
    membri.push({ device: b.device, nome: b.nome, punti: Math.round(target * curva + asRnd(b.device + asGiorno())() * 20), metriche: asMetricheBot(b.device, 3 + Math.floor(r() * 40)) });
  }
  let mie = 0; try{ mie = (typeof frPuntiLega === 'function') ? frPuntiLega() : 0; }catch(_){ }
  membri.push({ device: 'me', nome: 'Tu', me: true, punti: mie + asBoostBonusLega() });
  membri.sort(function(a, b){ return b.punti - a.punti || (a.me ? -1 : 1); });
  const pos = membri.findIndex(function(m){ return m.me; }) + 1;
  return { optIn: true, stato: 'attiva', tier: 'argento', goal: cat, nome: 'Lega ' + asCatNome(), membri: membri, mio: { posizione: pos, punti: membri[pos - 1].punti }, fine: fine, anteprima: true };
}

/* ---------------------------------------------------------------- Full Focus in coppia */
function asStartCardHtml(){
  return '<div class="as-card as-start"><div class="as-start-top"><span class="as-start-ico">⚔️</span>' + asBadge() + '</div>'
    + '<b>Full Focus in coppia</b><small>Un compagno con il tuo stesso sogno, una sessione insieme. Vedi se resta concentrato, lui vede te.</small>'
    + '<button type="button" class="am-cta" onclick="asMatchApri()">Cerca un compagno</button></div>';
}
function asMatchApri(device){
  if (!asOn()) return;
  let w = document.getElementById('asMatch');
  if (w) w.remove();
  w = document.createElement('div'); w.id = 'asMatch'; w.className = 'as-full as-match';
  (document.getElementById('phone') || document.body).appendChild(w);
  let partner = device ? asBotDa(device) : null;
  if (!partner){ const i = AS_N_AMICI + Math.floor(Math.random() * (AS_NOMI.length - AS_N_AMICI)); partner = asBot(i); if (!partner.av) partner.av = 'img/avatar/a' + ((i % 6) + 1) + '.svg'; }
  AS.match = partner;
  w.innerHTML = '<div class="as-full-in">' + asBadge()
    + '<p class="as-m-k">Full Focus in coppia</p>'
    + '<h2 id="asMTit">Cerco un compagno con il tuo stesso sogno…</h2>'
    + '<div class="as-vs"><div>' + asTuHtml('xl') + '<b>Tu</b></div><span class="as-vs-x">VS</span><div><span class="am-av as-av xl as-giro" id="asGiro"><img src="img/avatar/a2.svg" alt=""></span><b id="asGiroN">…</b></div></div>'
    + '<div id="asMSotto"><p class="as-full-p">🎯 ' + asE(asCatNome()) + ' come te</p><div class="as-dots"><i></i><i></i><i></i></div></div>'
    + '<button type="button" class="am-link as-m-x" onclick="asMatchChiudi()">Annulla</button></div>';
  setTimeout(function(){ w.classList.add('in'); }, 20);
  clearInterval(AS.matchGiro);
  let k = 0;
  AS.matchGiro = setInterval(function(){
    const im = document.querySelector('#asGiro img'), nm = document.getElementById('asGiroN');
    if (!im){ clearInterval(AS.matchGiro); return; }
    k++; im.src = 'img/avatar/a' + ((k % 6) + 1) + '.svg';
    if (nm) nm.textContent = AS_NOMI[(k * 7) % AS_NOMI.length];
  }, 130);
  clearTimeout(AS.matchT);
  AS.matchT = setTimeout(asMatchTrovato, device ? 2200 : 3000 + Math.floor(Math.random() * 1800));
}
function asMatchTrovato(){
  clearInterval(AS.matchGiro);
  const b = AS.match; if (!b || !document.getElementById('asMatch')) return;
  const a = asAmicoBot(b);
  const im = document.querySelector('#asGiro img'), nm = document.getElementById('asGiroN'), giro = document.getElementById('asGiro');
  if (im) im.src = b.av; if (nm) nm.textContent = b.nome; if (giro) giro.classList.add('preso');
  const t = document.getElementById('asMTit'); if (t) t.textContent = 'Trovato!';
  asVibra([30, 50, 30]);
  let min = 25; try{ min = (typeof ffPref === 'function' && ffPref().minutes) || 25; }catch(_){ }
  const durate = [25, 45, 60];
  if (durate.indexOf(min) < 0) min = 25;
  AS.matchMin = min;
  const s = document.getElementById('asMSotto');
  if (s) s.innerHTML = '<div class="as-pc"><small>Il tuo compagno di oggi</small><div class="as-pc-ch"><span>🎯 ' + asE(asCatNome()) + '</span><span>🔥 ' + a.streak + ' giorni di serie</span><span>⏳ ' + asE(asOre(a.ffMin7)) + ' questa settimana</span></div></div>'
    + '<p class="as-m-lbl">Quanto restate concentrati?</p>'
    + '<div class="as-dur">' + durate.map(function(d){ return '<button type="button" class="' + (d === min ? 'on' : '') + '" onclick="asMatchDur(' + d + ',this)">' + d + '<small>minuti</small></button>'; }).join('') + '</div>'
    + '<button type="button" class="as-cta-y" onclick="asMatchInizia()">Inizia insieme</button>';
}
function asMatchDur(d, btn){ AS.matchMin = d; document.querySelectorAll('.as-dur button').forEach(function(b){ b.classList.toggle('on', b === btn); }); asVibra(8); }
function asMatchChiudi(){ clearInterval(AS.matchGiro); clearTimeout(AS.matchT); const w = document.getElementById('asMatch'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 250); }
function asMatchInizia(){
  const b = AS.match; if (!b) return;
  const min = AS.matchMin || 25;
  asMatchChiudi();
  try{ const p = ffPref(); p.minutes = Math.max(5, Math.min(typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 180, min)); ffSavePref(); }catch(_){ }
  if (typeof ffOpen !== 'function') return;
  ffOpen();
  setTimeout(async function(){
    try{ await ffStart(); }catch(_){ }
    if (typeof FF !== 'undefined' && FF.run){
      FF.run.asCompagno = { device: b.device, nome: b.nome, av: b.av, f: b.f };
      try{ ffWrite('fl_ff_session', FF.run); }catch(_){ }
      asCompTick();
    }
  }, 250);
}
/** Lo stato del compagno, deciso da un seme della sessione: concentrato, una pausa a meta', poi di nuovo dentro. */
function asCompStato(run){
  const c = run.asCompagno, tot = Math.max(60000, run.endAt - run.startAt);
  const r = asRnd(c.device + run.startAt);
  const el = Math.max(0, (run.pausedAt || Date.now()) - run.startAt);
  const pIn = tot * (0.3 + r() * 0.3), pLen = 60000 + r() * 90000;
  const min = Math.floor(Math.min(el, tot) / 60000);
  if (el >= pIn && el < pIn + pLen) return { k: 'pausa', t: 'Ha fatto una pausa', min: min };
  if (el >= pIn + pLen && el < pIn + pLen + 45000) return { k: 'su', t: 'È tornat' + (c.f ? 'a' : 'o') + ' in concentrazione', min: min };
  return { k: 'ok', t: 'In concentrazione da ' + (min === 1 ? '1 minuto' : min + ' minuti'), min: min };
}
function asCompTick(){
  const run = (typeof FF !== 'undefined' && FF) ? FF.run : null;
  let el = document.getElementById('asComp');
  if (!run || !run.asCompagno){ if (el) el.remove(); return; }
  const scr = document.getElementById('s-fullfocus'); if (!scr) return;
  if (!el){
    el = document.createElement('div'); el.id = 'asComp'; el.className = 'as-comp';
    const dopo = scr.querySelector('.ff-intent');
    if (dopo && dopo.parentNode) dopo.parentNode.insertBefore(el, dopo.nextSibling); else scr.appendChild(el);
  }
  const s = asCompStato(run), c = run.asCompagno;
  const html = asAvHtml(c, 'sm') + '<div><b>' + asE(c.nome) + '</b><small>' + asE(s.t) + '</small></div><i class="as-dot ' + s.k + '"></i>';
  if (el.dataset.h !== html){ el.innerHTML = html; el.dataset.h = html; }
}
function asCompEsito(run, ok, c){
  const spent = Math.max(0, (run.endAt - run.startAt) - Math.max(0, run.endAt - Date.now()));
  const mio = Math.round(spent / 60000);
  const r = asRnd(c.device + run.startAt + 'fine');
  const suoOk = ok ? r() < 0.88 : r() < 0.6;
  const suo = suoOk ? Math.max(mio, ok ? run.minutes : mio) : Math.max(1, Math.round((ok ? run.minutes : mio) * (0.5 + r() * 0.35)));
  asMiaVoce('⚔️', 'Full Focus in coppia con ' + asE(c.nome) + ': <b>' + (mio + suo) + ' minuti insieme</b>');
  const host = document.getElementById('ffDone'); if (!host) return;
  const riga = function(av, nome, min, fatto){ return '<div class="as-es-r">' + av + '<b>' + asE(nome) + '</b><span class="' + (fatto ? 'ok' : 'no') + '">' + (fatto ? '✓ ' : '') + min + ' minuti</span></div>'; };
  const card = document.createElement('div'); card.className = 'as-esito';
  card.innerHTML = '<div class="as-es-top"><b>In coppia con ' + asE(c.nome) + '</b>' + asBadge() + '</div>'
    + riga(asTuHtml('sm'), 'Tu', mio, ok) + riga(asAvHtml(c, 'sm'), c.nome, suo, suoOk)
    + '<p>' + (ok && suoOk ? 'Avete chiuso tutti e due: ' + (mio + suo) + ' minuti di concentrazione insieme.' : (suoOk ? c.nome + ' ha chiuso la sessione: la prossima la chiudete insieme.' : 'Insieme avete fatto ' + (mio + suo) + ' minuti. La prossima volta di più.')) + '</p>';
  const go = host.querySelector('.ffd-go');
  if (go) host.insertBefore(card, go); else host.appendChild(card);
}

/* ---------------------------------------------------------------- ridisegnare */
function asRidisegna(){
  try{ const b = document.getElementById('frBody'); if (b && b.offsetParent && typeof frPaint === 'function') frPaint(); }catch(_){ }
}
/* 0.9.265 (lag): ogni secondo, ma lavora solo se c'e' qualcosa da aggiornare */
const AS_BT = document.getElementsByClassName('as-boost-t'), AS_B = document.getElementsByClassName('as-boost');
function asTicker(){
  if (AS_BT.length){ const t0 = asBoostTxt(); for (let i = 0; i < AS_BT.length; i++){ if (AS_BT[i].textContent !== t0) AS_BT[i].textContent = t0; } }
  if (AS_B.length && !(asBoostResta() > 0)) Array.from(AS_B).forEach(function(x){ x.remove(); });
  if ((typeof FF !== 'undefined' && FF && FF.run) || document.getElementById('asComp')){ try{ asCompTick(); }catch(_){ } }
}
setInterval(asTicker, 1000);

/* ---------------------------------------------------------------- gli involucri (solo admin) */
function asAvvolgi(nome, fn){
  const orig = window[nome];
  if (typeof orig !== 'function') return;
  window[nome] = function(){ return fn.call(this, orig, Array.prototype.slice.call(arguments)); };
}
function asAmiciMescola(){
  if (typeof FR === 'undefined') return null;
  if (!asOn()){ if (FR.amici && FR.amici.amici) FR.amici.amici = FR.amici.amici.filter(function(a){ return !a.bot; }); return FR.amici; }
  if (!FR.amici) FR.amici = { amici: [], reazioni: { totali: [], ultime: [] } };
  FR.amici.amici = (FR.amici.amici || []).filter(function(a){ return !a.bot; }).concat(asAmiciBot());
  return FR.amici;
}
(function(){
  asAvvolgi('frAmiciCarica', async function(orig, a){
    let r = null; try{ r = await orig.apply(this, a); }catch(_){ }
    return asOn() ? asAmiciMescola() : r;
  });
  asAvvolgi('frLegaCarica', async function(orig, a){
    let r = null; try{ r = await orig.apply(this, a); }catch(_){ }
    if (!asOn()) return r;
    FR.lega = asLegaFinta();
    return FR.lega;
  });
  asAvvolgi('frAv', function(orig, a){
    const b = asOn() ? asBotDa(a[1]) : null;
    if (b && b.av) return '<span class="am-av as-av' + (a[2] ? ' ' + a[2] : '') + '"><img src="' + b.av + '" alt=""></span>';
    return orig.apply(this, a);
  });
  asAvvolgi('frReagisci', function(orig, a){
    const b = asBotDa(a[0]);
    if (!b) return orig.apply(this, a);
    const tipo = a[2], btn = a[3];
    /* 0.9.300, la causa vera dei "coriandoli che non compaiono": per gli amici dell'anteprima questo
       involucro rispondeva da solo e non passava mai da frReagisci, che e' dove partono i coriandoli
       (flCoriandoli, levels.js). Con amici veri partivano; Andrea vede gli amici simulati. */
    try{ if (typeof flCoriandoli === 'function') flCoriandoli(); }catch(_){ }
    const r0 = (typeof FR_REAZIONI !== 'undefined' ? FR_REAZIONI : []).filter(function(z){ return z.k === tipo; })[0] || { e: '❤️' };
    const tutte = asLeggi('fl_as_reaz', {}), g = asGiorno(), oggi = tutte[g] || {};
    const l = oggi[b.device] || []; if (l.indexOf(tipo) < 0) l.push(tipo); oggi[b.device] = l;
    asScrivi('fl_as_reaz', { [g]: oggi });
    if (btn) btn.classList.add('on');
    const testo = (typeof amT === 'function') ? amT('amici.reazioni.' + tipo) : tipo;
    /* prima la festa, poi il messaggio, come per gli amici veri */
    setTimeout(function(){
      const n = document.getElementById('amNote'); if (n){ n.textContent = 'Reazione inviata a ' + b.nome + ' ✓'; n.classList.add('ok'); }
      asToast(r0.e + ' "' + testo + '" inviata a ' + b.nome);
    }, 1100);
    try{ if (typeof FR !== 'undefined' && FR.amici) (FR.amici.amici || []).forEach(function(x){ if (x.device === b.device){ x.reazioniOggi = l.slice(); } }); }catch(_){ }
    return Promise.resolve();
  });
  asAvvolgi('frSegui', function(orig, a){
    const b = asBotDa(a[0]); if (!b) return orig.apply(this, a);
    const btn = a[1]; if (btn){ btn.disabled = true; btn.textContent = 'Segui già'; btn.classList.add('on'); }
    asVibra(14); asToast('Ora segui ' + b.nome);
    return Promise.resolve();
  });
  asAvvolgi('inScegli', function(orig, a){ if (asOn() && asBotDa(a[0])) return asMatchApri(a[0]); return orig.apply(this, a); });
  asAvvolgi('dvApriDi', function(orig, a){ const b = asBotDa(a[0]); if (b){ asToast('Il diario di ' + b.nome + ' è privato'); return Promise.resolve(); } return orig.apply(this, a); });
  asAvvolgi('frLegaIscrivi', function(orig, a){ if (asOn()){ asToast('Nell\'anteprima la lega resta aperta'); return Promise.resolve(); } return orig.apply(this, a); });
  asAvvolgi('frAmiciHtml', function(orig, a){
    if (!asOn()) return orig.apply(this, a);
    asAmiciMescola();
    let h = orig.apply(this, a);
    const feed = asFeedHtml();
    const i = h.indexOf('<div class="am-codici">');
    h = i >= 0 ? h.slice(0, i) + feed + h.slice(i) : h + feed;
    /* 0.9.300, Andrea: la missione di gruppo sta nella scheda Sfide (sfMissioniHtml qui sotto), non in Amici */
    return h;
  });
  asAvvolgi('sfMissioniHtml', function(orig, a){
    const h = orig.apply(this, a);
    if (!asOn()) return h;
    const i = h.indexOf('<div class="am-sect"><b>Missioni giornaliere');
    return asMissioneHtml() + (i >= 0 ? h.slice(i) : h);
  });
  asAvvolgi('frLegaHtml', function(orig, a){
    if (asOn() && (!FR.lega || !FR.lega.anteprima)) FR.lega = asLegaFinta();
    return orig.apply(this, a);
  });
  asAvvolgi('frPaint', function(orig, a){
    const r = orig.apply(this, a);
    if (!asOn()) return r;
    const b = document.getElementById('frBody');
    /* 0.9.309: il motto non c'e' piu': l'avviso va in cima, prima delle schede */
    const m = b && (b.querySelector('.am-offline') || b.querySelector('.fr-tabs'));
    if (m && !b.querySelector('.as-top')){
      const d = document.createElement('div'); d.className = 'as-top';
      d.innerHTML = asBadge() + '<span>Amici simulati: solo tu vedi questa anteprima.</span>';
      m.parentNode.insertBefore(d, m);
      if (asBoostResta() > 0){ const p = document.createElement('div'); p.innerHTML = asBoostPill(); d.parentNode.insertBefore(p.firstChild, d.nextSibling); }
    }
    /* la presentazione della missione di gruppo compare dove sta la missione: nella scheda Sfide */
    if (typeof FR !== 'undefined' && FR.tab === 'sfide') setTimeout(asSplashForse, 350);
    return r;
  });
  asAvvolgi('stGruppoHtml', function(orig, a){
    const h = orig.apply(this, a);
    if (!asOn()) return h;
    const i = h.indexOf('<div class="st-gr">');
    return i >= 0 ? h.slice(0, i) + asStartCardHtml() + h.slice(i) : asStartCardHtml() + h;
  });
  asAvvolgi('ffFinish', async function(orig, a){
    const run = (typeof FF !== 'undefined' && FF) ? FF.run : null;
    const c = run && run.asCompagno;
    const r = await orig.apply(this, a);
    if (c){ try{ asCompEsito(run, !!a[0], c); }catch(_){ } }
    return r;
  });
  /* all'avvio, se il server ha appena detto «admin», gli amici simulati compaiono anche nel feed della serie */
  document.addEventListener('fl:admin', function(){ try{ asAmiciMescola(); }catch(_){ } });
})();

/* ---------------------------------------------------------------- lo stile */
(function(){
  if (document.getElementById('asCss')) return;
  const s = document.createElement('style'); s.id = 'asCss';
  s.textContent = [
    '.as-badge{display:inline-flex;align-items:center;padding:3px 9px;border-radius:99px;background:#BCE0FF;color:#0F2041;font:800 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;vertical-align:middle}',
    /* 0.9.332, Andrea: "le schede sono troppo distaccate dall'intestazione": era questa riga di servizio, vuota alla vista */
    '.as-top{display:none}',
    'body.dark .as-top{color:#9EB0CC}',
    '.as-boost{display:flex;align-items:center;gap:10px;margin:0 0 12px;padding:10px 14px;border-radius:14px;background:#BCE0FF;color:#0F2041}.as-boost span{font-size:20px}.as-boost b{font:900 14px var(--font-body)}.as-boost small{margin-left:auto;font:700 12.5px var(--font-body)}.as-boost i{font-style:normal;font-variant-numeric:tabular-nums}',
    '.as-card{background:#FFFFFF;color:#0F2041;border-radius:20px;padding:16px;box-shadow:0 6px 20px rgba(15,32,65,.08);border:1px solid rgba(15,32,65,.06)}',
    'body.dark .as-card{background:#14234A;color:#FFFFFF;border-color:rgba(255,255,255,.08)}',
    '.as-av{background:#E6F2FF;overflow:hidden;padding:0}.as-av img{width:100%;height:100%;display:block}',
    '.as-tu{background:#0075E3;color:#FFFFFF;font:800 14px var(--font-body)}',
    '.am-av.xl{width:84px;height:84px;font-size:26px}.am-av.sm{width:34px;height:34px;font-size:12px}',
    '.as-mis-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.as-mis-tag{padding:4px 10px;border-radius:99px;background:#0F2041;color:#8CC6FF;font:800 11.5px var(--font-body)}.as-mis-top small{font:700 12px var(--font-body);opacity:.7}',
    'body.dark .as-mis-tag{background:#0075E3;color:#FFFFFF}',
    '.as-mis-t{display:block;font:800 18px var(--font-display);line-height:1.25;margin-bottom:12px}',
    '.as-mis-bar{position:relative;display:flex;height:22px;border-radius:99px;background:#E6ECF5;overflow:hidden}.as-mis-bar i{display:block;height:100%}.as-mis-bar i.io{background:#0075E3}.as-mis-bar i.lui{background:#BCE0FF}',
    '.as-mis-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:800 12px var(--font-body);color:#0F2041}',
    'body.dark .as-mis-bar{background:#0F2041}body.dark .as-mis-bar span{color:#FFFFFF}',
    '.as-mis-ok{margin:10px 0 0;font:700 13.5px var(--font-body)}',
    '.as-mis-righe{margin-top:12px;display:grid;gap:8px}.as-mis-r{display:flex;align-items:center;gap:10px}.as-mis-r .am-av{width:34px;height:34px;font-size:12px}.as-mis-r b{flex:1;font:700 14.5px var(--font-body)}.as-mis-r>span:last-child{font:800 13.5px var(--font-body);color:#0075E3}',
    'body.dark .as-mis-r>span:last-child{color:#9EC1FF}',
    '.as-mis-btn{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.as-mis-btn button{border:none;cursor:pointer;border-radius:14px;padding:13px 10px;font:800 14px var(--font-body);background:#E6F2FF;color:#0075E3}.as-mis-btn button+button{background:#BCE0FF;color:#0F2041}',
    'body.dark .as-mis-btn button{background:#0F2041;color:#9EC1FF}body.dark .as-mis-btn button+button{background:#BCE0FF;color:#0F2041}',
    '.as-feed{display:grid;gap:10px}.as-fv{padding:14px}.as-fv-top{display:flex;align-items:center;gap:10px}.as-fv-top .am-av{width:40px;height:40px;font-size:13px}.as-fv-top div{flex:1;min-width:0}.as-fv-top b{display:block;font:800 14.5px var(--font-body)}.as-fv-top small{font:600 12px var(--font-body);opacity:.6}.as-fv-e{font-size:24px}',
    '.as-fv p{margin:10px 0 0;font:500 14.5px/1.4 var(--font-body)}.as-fv p b{font-weight:800}',
    '.as-fv-az{display:flex;gap:8px;margin-top:12px}.as-fv-az button{border:1px solid rgba(15,32,65,.12);background:transparent;color:inherit;cursor:pointer;border-radius:99px;padding:7px 14px;font:700 13px var(--font-body)}.as-fv-az button.on{border-color:#E63946;color:#E63946}',
    'body.dark .as-fv-az button{border-color:rgba(255,255,255,.18)}',
    '.as-fv-com{margin-top:10px;display:grid;gap:4px}.as-fv-com small{font:500 13px var(--font-body);padding:7px 10px;border-radius:12px;background:rgba(0,117,227,.08)}',
    '.as-ricevi{display:block;width:100%;margin-top:12px;border:none;cursor:pointer;border-radius:14px;padding:13px;font:800 14.5px var(--font-body);background:#BCE0FF;color:#0F2041;box-shadow:0 6px 16px rgba(140,198,255,.45)}',
    '.as-preso{display:inline-block;margin-top:10px;font:800 13px var(--font-body);color:#0075E3}body.dark .as-preso{color:#9EC1FF}',
    '.as-start{margin:0 0 14px}.as-start-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}.as-start-ico{font-size:28px}.as-start>b{display:block;font:800 19px var(--font-display)}.as-start>small{display:block;margin-top:4px;font:500 13.5px/1.4 var(--font-body);opacity:.75}.as-start .am-cta{margin-top:14px}',
    '.as-full{position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;padding:24px 20px;background:linear-gradient(180deg,#14234A 0%,#0F2041 100%);color:#FFFFFF;opacity:0;transition:opacity .25s}.as-full.in{opacity:1}',
    '.as-full-in{width:100%;max-width:380px;text-align:center}.as-full h2{margin:16px 0 22px;font:900 25px/1.2 var(--font-display);color:#FFFFFF}',
    '.as-duo,.as-vs{display:flex;align-items:center;justify-content:center;gap:18px}.as-duo>div,.as-vs>div{display:flex;flex-direction:column;align-items:center;gap:8px;min-width:96px}.as-duo b,.as-vs b{font:800 15px var(--font-body);color:#FFFFFF}',
    '.as-duo-piu{font:900 28px var(--font-display);color:#8CC6FF}.as-vs-x{font:900 22px var(--font-display);color:#8CC6FF;letter-spacing:.05em}',
    '.as-full .am-av.xl{box-shadow:0 0 0 4px rgba(255,255,255,.12)}.as-giro.preso{box-shadow:0 0 0 4px #8CC6FF;animation:asPop .35s ease-out}',
    '@keyframes asPop{0%{transform:scale(.8)}70%{transform:scale(1.1)}100%{transform:scale(1)}}',
    '.as-fila{margin:22px 0 6px;font:800 15px var(--font-body);color:#8CC6FF}.as-full-p{margin:6px 0 0;font:500 14.5px/1.45 var(--font-body);color:#C9D6EE}',
    '.as-cta-y{display:block;width:100%;margin-top:22px;border:none;cursor:pointer;border-radius:99px;padding:17px;font:900 16px var(--font-body);background:#BCE0FF;color:#0F2041;box-shadow:0 10px 24px rgba(140,198,255,.3)}',
    '.as-m-k{margin:14px 0 0;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#9EC1FF}.as-m-x{color:#9EB0CC !important;margin-top:8px}',
    '.as-dots{display:flex;justify-content:center;gap:6px;margin-top:18px}.as-dots i{width:8px;height:8px;border-radius:50%;background:#0075E3;animation:asDot 1s infinite ease-in-out}.as-dots i:nth-child(2){animation-delay:.15s}.as-dots i:nth-child(3){animation-delay:.3s}',
    '@keyframes asDot{0%,100%{opacity:.3;transform:translateY(0)}50%{opacity:1;transform:translateY(-4px)}}',
    '.as-pc{margin-top:18px;padding:14px;border-radius:18px;background:rgba(255,255,255,.07)}.as-pc>small{font:800 11.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#9EC1FF}.as-pc-ch{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;margin-top:10px}.as-pc-ch span{padding:5px 10px;border-radius:99px;background:rgba(0,117,227,.25);font:700 12px var(--font-body);color:#FFFFFF}',
    '.as-m-lbl{margin:18px 0 8px;font:700 13px var(--font-body);color:#C9D6EE}',
    '.as-dur{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.as-dur button{border:2px solid rgba(255,255,255,.15);background:transparent;color:#FFFFFF;cursor:pointer;border-radius:16px;padding:10px 0;font:900 20px var(--font-display)}.as-dur button small{display:block;font:600 11px var(--font-body);opacity:.75}.as-dur button.on{border-color:#8CC6FF;background:rgba(140,198,255,.12)}',
    '.as-sheet .as-sh-av{display:flex;justify-content:center;margin:6px 0 8px}.as-sheet .am-av.lg{width:64px;height:64px}',
    '.as-inc{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.as-inc-b{display:flex;flex-direction:column;align-items:center;gap:6px;border:2px solid rgba(15,32,65,.1);background:transparent;color:inherit;cursor:pointer;border-radius:18px;padding:14px 8px}.as-inc-b span{font-size:36px;line-height:1}.as-inc-b img{width:48px;height:48px;object-fit:contain}.as-inc-b small{font:700 12.5px/1.25 var(--font-body)}.as-inc-b.on{border-color:#0075E3;background:rgba(0,117,227,.08)}',
    'body.dark .as-inc-b{border-color:rgba(255,255,255,.14)}',
    '.as-reg{display:grid;gap:10px;margin-top:14px;text-align:left}.as-reg-b{display:flex;align-items:center;gap:12px;border:2px solid rgba(15,32,65,.1);background:transparent;color:inherit;cursor:pointer;border-radius:18px;padding:12px 14px;text-align:left}.as-reg-b span{font-size:32px}.as-reg-b b{display:block;font:800 14.5px var(--font-body)}.as-reg-b small{font:500 12.5px var(--font-body);opacity:.75}.as-reg-b.on{border-color:#8CC6FF;background:rgba(140,198,255,.16)}',
    'body.dark .as-reg-b{border-color:rgba(255,255,255,.14)}',
    '.as-rr{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:14px}.as-rr button{border:none;cursor:pointer;border-radius:99px;padding:10px 16px;font:700 14px var(--font-body);background:#E6F2FF;color:#0075E3}',
    'body.dark .as-rr button{background:#0F2041;color:#9EC1FF}',
    '.as-comp{display:flex;align-items:center;gap:10px;margin:8px auto 0;max-width:300px;padding:8px 14px 8px 8px;border-radius:99px;background:rgba(15,32,65,.08);text-align:left}.as-comp div{flex:1;min-width:0}.as-comp b{display:block;font:800 13.5px var(--font-body)}.as-comp small{display:block;font:600 12px var(--font-body);opacity:.75}',
    'body.dark .as-comp{background:rgba(255,255,255,.08)}',
    '.as-dot{width:10px;height:10px;border-radius:50%;flex:none;background:#0075E3;box-shadow:0 0 0 4px rgba(0,117,227,.2)}.as-dot.pausa{background:#BCE0FF;box-shadow:0 0 0 4px rgba(140,198,255,.25)}',
    '.as-esito{width:100%;max-width:340px;margin:16px auto 0;padding:14px 16px;border-radius:18px;background:#E6F2FF;color:#0F2041;text-align:left}',
    'body.dark .as-esito{background:#14234A;color:#FFFFFF}',
    '.as-es-top{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}.as-es-top b{font:800 15px var(--font-body)}',
    '.as-es-r{display:flex;align-items:center;gap:10px;margin-top:8px}.as-es-r b{flex:1;font:700 14px var(--font-body)}.as-es-r>span:last-child{font:800 13.5px var(--font-body)}.as-es-r>span.ok{color:#0075E3}',
    'body.dark .as-es-r>span.ok{color:#9EC1FF}',
    '.as-esito p{margin:10px 0 0;font:500 13.5px/1.4 var(--font-body)}'
  ].join('\n');
  document.head.appendChild(s);
})();
