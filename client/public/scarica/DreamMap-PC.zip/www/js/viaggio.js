/* ===========================================================================================
   IL VIAGGIO DENTRO A «OBIETTIVO»

   La rotta (rotta.js) e il sentiero delle tappe (mappa.js) vivevano in una scheda loro. Sono
   la risposta a «dove stai andando», che e' la stessa domanda del Genio: quindi stanno sotto a
   «Prevedi il tuo futuro», e compaiono SOLO dopo la lettura. Prima della lettura una mappa
   non ha niente da disegnare — la traiettoria la intuisce lui.

   Questo modulo non disegna niente: prende i pezzi che gli altri due innestano nella scheda e
   li mette nell'ordine giusto, dentro a un contenitore che si apre e si chiude da solo.
   =========================================================================================== */

function vgPronto(){
  try{ return typeof orLast === 'function' && !!orLast(); }catch(_){ return false; }
}

function vgContenitore(){
  const tab = document.getElementById('tab-severa');
  if (!tab) return null;
  let box = document.getElementById('scViaggio');
  if (!box){
    box = document.createElement('section');
    box.id = 'scViaggio';
    const vita = document.getElementById('scLife');
    if (vita && vita.parentElement === tab) vita.insertAdjacentElement('afterend', box);
    else tab.appendChild(box);
  }
  return box;
}

/**
 * Mette ogni pezzo al suo posto.
 *
 * LA CARD partenza/destinazione sta SOTTO AL CIELO, e ci sporge sopra: e' la domanda «dove
 * vuoi arrivare» fatta subito dopo il titolo, com'era nella vecchia scheda Viaggio. LA MAPPA
 * (la rotta sul mondo e le tappe) sta sotto al Genio, e compare solo dopo la lettura: senza
 * lettura la traiettoria non c'e'.
 */
function vgSistema(){
  const tab = document.getElementById('tab-severa');
  const box = vgContenitore();
  if (!tab || !box) return;
  /* IL PANNELLO DELLA ROTTA STA ACCANTO ALLA MAPPA, non sotto al cielo. Sotto al cielo
     finiva appeso alla diapositiva del mantra e delle ore di focus, dove non c'entra niente:
     la destinazione si sceglie una volta sola nell'intro, e si cambia qui, dove la si vede
     disegnata. */
  /* L'ORDINE E' LA COSA CHE CONTA. Il pannello della rotta sporge di 70px su cio' che ha
     sopra: se viene innestato PRIMA del cielo della mappa (perche' rtHero non esiste ancora
     nel momento in cui passa questo giro) finisce appeso alla card del Genio, sopra al
     pannello «Prevedi il tuo futuro». E' il bug che Andrea ha visto il 19/09. Quindi: si
     rimettono i tre pezzi nell'ordine giusto OGNI volta, e il pannello entra solo se il cielo
     c'e' gia'. */
  const rtHero = document.getElementById('rtHero'), scRotta = document.getElementById('scRotta'), scMap = document.getElementById('scMap');
  if (rtHero && rtHero.parentElement !== box) box.appendChild(rtHero);
  if (scRotta){
    if (rtHero){ if (scRotta.previousElementSibling !== rtHero || scRotta.parentElement !== box) rtHero.insertAdjacentElement('afterend', scRotta); }
    else scRotta.hidden = true;
  }
  if (scMap && (scMap.parentElement !== box || scMap.previousElementSibling !== (scRotta || rtHero))) box.appendChild(scMap);
  if (scRotta && rtHero) scRotta.hidden = false;
  box.hidden = !vgPronto();
}

/* L'ORDINE SI SISTEMA PRIMA CHE LA SCHEDA SI VEDA.
   `fl:tab` parte dentro a switchTab, prima che il browser disegni: sistemare qui vuol dire
   che la scheda compare gia' giusta. Prima questa funzione girava solo a 420 e 900 ms, e la
   mappa — innestata in fondo alla scheda da mappa.js — veniva spostata dentro al contenitore
   del viaggio MEZZO SECONDO DOPO il tocco, sotto gli occhi di chi guardava. E' il salto che
   Andrea vede ogni volta che apre la Roadmap. I due ritardi restano come rete: se nel
   frattempo un altro modulo ha innestato il suo pezzo, l'ordine si richiude da solo. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'severa') return;
  vgSistema();
  setTimeout(vgSistema, 420);
  setTimeout(vgSistema, 900);
});
document.addEventListener('DOMContentLoaded', function(){ vgSistema(); setTimeout(vgSistema, 300); });
