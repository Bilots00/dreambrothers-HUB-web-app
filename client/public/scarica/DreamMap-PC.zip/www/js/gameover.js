/* ===========================================================================================
   GAME OVER — arrendersi, e ricominciare con un'altra destinazione

   Chi rifiuta la chiamata dicendo «mi arrendo, cambio strada» non sta saltando un giorno: sta
   dicendo che quella destinazione non è più la sua. Fingere che sia un giorno storto sarebbe
   una bugia comoda. Quindi si fa quello che fa un videogioco: schermo nero, la scritta, il
   punteggio, e un solo pulsante. La partita ricomincia da zero — tabellone, serie, foresta,
   monete, rotta — e il Genio rifà la sua lettura dall'inizio, per scegliere un sogno nuovo.

   COSA RESTA. Le impostazioni, le regole di blocco, i permessi già concessi, l'account, gli
   appunti scritti a mano. Sono cose della persona, non della partita: un videogioco che alla
   nuova partita ti richiedesse di riconfigurare il joystick non sarebbe un videogioco, sarebbe
   una punizione.
   =========================================================================================== */

const GO_RIPARTI = 'fl_gn_riparti';

/* Le chiavi della PARTITA. Tutto quello che non è qui, resta. */
const GO_CHIAVI = [
  'fl_match', 'fl_match_hist', 'fl_plan_days', 'fl_sp_toll', 'fl_plan_fix_v1',
  'fl_ff_hist', 'fl_coins', 'fl_ff_session', 'fl_records',
  'fl_oracle', 'fl_rotta', 'fl_orizzonti', 'fl_chiamata', 'fl_dopa_fine',
  'fl_scomponi', 'fl_revisione', 'fl_serie_aperta'
];

function goPunteggio(){
  try{ const s = JSON.parse(localStorage.getItem('fl_match') || 'null'); return s ? { old: s.old || 0, neo: s.neo || 0, best: s.best || 0 } : { old: 0, neo: 0, best: 0 }; }
  catch(_){ return { old: 0, neo: 0, best: 0 }; }
}

function goApri(){
  let el = document.getElementById('goWrap');
  if (!el){
    el = document.createElement('div');
    el.id = 'goWrap';
    (document.getElementById('phone') || document.body).appendChild(el);
  }
  const p = goPunteggio();
  el.innerHTML = '<div class="go-box">'
    + '<div class="go-title">GAME<br>OVER</div>'
    + '<div class="go-score"><span class="old">' + p.old + '</span><i>–</i><span class="neo">' + p.neo + '</span></div>'
    + '<p class="go-p">Hai cambiato strada. Succede, ed è meglio dirlo che trascinarsi.</p>'
    + '<p class="go-p small">La partita ricomincia da zero: tabellone, serie, cielo e rotta. Le impostazioni e i permessi restano.</p>'
    + '<button type="button" class="go-btn" onclick="goRicomincia()">Ricomincia con un nuovo sogno</button>'
    + '<button type="button" class="go-link" onclick="goChiudi()">Ho cambiato idea, resto</button>'
    + '</div>';
  el.hidden = false;
  requestAnimationFrame(function(){ el.classList.add('in'); });
  try{ if (typeof flVibra === 'function') flVibra([40, 60, 40]); }catch(_){ }
}
function goChiudi(){
  const el = document.getElementById('goWrap');
  if (!el) return;
  el.classList.remove('in');
  setTimeout(function(){ el.hidden = true; el.innerHTML = ''; }, 300);
}
function goRicomincia(){
  GO_CHIAVI.forEach(function(k){ try{ localStorage.removeItem(k); }catch(_){ } });
  /* le frasi del giorno sbloccate appartengono alla partita finita */
  try{
    Object.keys(localStorage).forEach(function(k){ if (k.indexOf('fl_cit_') === 0 || k.indexOf('fl_dayrep_') === 0) localStorage.removeItem(k); });
  }catch(_){ }
  /* Il Genio ricomincia dalla prima battuta e, alla fine, torna a casa: niente permessi da
     richiedere, sono già concessi. */
  try{ localStorage.setItem(GO_RIPARTI, '1'); }catch(_){ }
  goChiudi();
  setTimeout(function(){
    if (typeof gnRivedi === 'function') gnRivedi();
    else if (typeof rivediOnboarding === 'function') rivediOnboarding();
  }, 320);
}

(function goStile(){
  const st = document.createElement('style');
  st.textContent = [
    '#goWrap{position:absolute;inset:0;z-index:95;display:flex;align-items:center;justify-content:center;',
      'background:#05070D;opacity:0;transition:opacity .35s ease}',
    '#goWrap[hidden]{display:none}',
    '#goWrap.in{opacity:1}',
    '.go-box{text-align:center;padding:32px 26px;max-width:340px}',
    '.go-title{font:900 64px/0.95 var(--font-display);font-style:italic;letter-spacing:.04em;color:#fff;',
      'text-shadow:0 0 24px rgba(230,57,70,.55),0 0 60px rgba(230,57,70,.35);animation:goPulse 1.6s ease-in-out infinite}',
    '@keyframes goPulse{0%,100%{opacity:1}50%{opacity:.78}}',
    '.go-score{margin:26px 0 22px;font:800 40px/1 var(--font-display);font-style:italic;display:flex;gap:14px;justify-content:center;align-items:center}',
    '.go-score .old{color:#FF7A8A}.go-score .neo{color:#7FE0C4}.go-score i{color:rgba(255,255,255,.35);font-style:normal;font-size:28px}',
    '.go-p{margin:0 0 12px;font:600 15px/1.5 var(--font-body);color:#fff}',
    '.go-p.small{font:500 12.5px/1.6 var(--font-body);color:rgba(255,255,255,.62);margin-bottom:26px}',
    '.go-btn{width:100%;border:0;border-radius:99px;background:#fff;color:#05070D;padding:16px;',
      'font:800 15px var(--font-body);cursor:pointer}',
    '.go-link{display:block;width:100%;margin-top:14px;border:0;background:none;color:rgba(255,255,255,.55);',
      'font:600 13px var(--font-body);cursor:pointer;text-decoration:underline}',
    '@media (prefers-reduced-motion:reduce){.go-title{animation:none}}'
  ].join('');
  document.head.appendChild(st);
})();
