/* ===========================================================================================
   IL REPORT SETTIMANALE — e il flusso che ne esce

   Una tabella non ha mai cambiato le abitudini di nessuno. Il report che c'era — tempo di
   schermo, avvii, notifiche — è esatto e non serve a niente da solo, perché finisce dove
   comincia il problema: adesso che lo so, cosa faccio?

   Questo è il pezzo che mancava. Alla fine di ogni settimana l'app si apre con un cartello, e
   da lì parte una sequenza di schermate — una sola informazione per volta, a schermo intero,
   come «Prevedi il tuo futuro» — dove ogni numero scomodo si porta dietro la sua freccia: un
   programma già scritto, che un tocco crea davvero.

   L'ORDINE NON È CASUALE. Prima quanto (la media), poi la direzione (la tendenza), poi il
   totale, e solo dopo i colpevoli — l'app, la fascia oraria, la sessione infinita. Chi legge
   «WhatsApp: 6h 28m» al primo schermo si difende; chi ci arriva dopo aver visto la propria
   curva salire, no.

   QUANDO COMPARE. Una volta a settimana, il lunedì (o la domenica sera), alla prima apertura.
   Mai due volte per la stessa settimana, mai durante il resto dei giorni: un cartello che torna
   quando gli pare diventa una cosa da chiudere, e una cosa da chiudere non la legge nessuno.
   =========================================================================================== */

const WK_KEY = 'fl_week_report';        // l'ultima settimana già mostrata: "2026-W37"

function wkWeekKey(d){
  const t = new Date(d || Date.now());
  t.setHours(0, 0, 0, 0);
  /* Settimana ISO: il giovedì decide l'anno, che è l'unico modo di non litigare a capodanno. */
  const gio = new Date(t);
  gio.setDate(t.getDate() - ((t.getDay() + 6) % 7) + 3);
  const primo = new Date(gio.getFullYear(), 0, 4);
  const n = 1 + Math.round(((gio - primo) / 86400000 - 3 + ((primo.getDay() + 6) % 7)) / 7);
  return gio.getFullYear() + '-W' + String(n).padStart(2, '0');
}

function wkVista(){ try{ return localStorage.getItem(WK_KEY) || ''; }catch(_){ return ''; } }
function wkSegna(){ try{ localStorage.setItem(WK_KEY, wkWeekKey(wkDomenica())); }catch(_){ } }
/* 0.9.321, Andrea: "un badge Nuovo se non l'ha ancora visto, magari perche' ha chiuso il pop-up". Aperto non vuol dire visto: conta
   chi e' andato avanti di due schermate. */
const WK_LETTO = 'fl_week_report_letto';
function wkDaVedere(){ try{ return localStorage.getItem(WK_LETTO) !== wkWeekKey(wkDomenica()); }catch(_){ return false; } }
function wkSegnaLetto(){ try{ localStorage.setItem(WK_LETTO, wkWeekKey(wkDomenica())); }catch(_){ } try{ if (typeof pfrNuovoAgg === 'function') pfrNuovoAgg(); }catch(_){ } }

/** La domenica appena passata: è la settimana di cui si parla. */
function wkDomenica(){
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7) - 1);   // lunedì di questa settimana, meno uno
  return d;
}

/** Vero quando è il momento: lunedì, o domenica dopo le 20, e non l'abbiamo già mostrato. */
function wkTocca(){
  const now = new Date();
  const g = now.getDay();                 // 0 = domenica
  const momento = (g === 1) || (g === 0 && now.getHours() >= 20);
  if (!momento) return false;
  return wkVista() !== wkWeekKey(wkDomenica());
}

/* ---------------------------------------------------------------------------------------
   I numeri della settimana

   "- 43h 45m AL GIORNO" NON ESISTE: un giorno ha ventiquattro ore. La media della settimana
   prima leggeva i giorni da 8 a 14 fa, e li' Android non ha piu' gli eventi di utilizzo
   dettagliati: il motore vede un'app aperta e mai chiusa, e le conta giornate da 40 ore.
   Il pannello del Profilo lo aveva gia' capito (pfrPaint, profcaro.js): un giorno sopra le
   18 ore e' un errore di misura, e si scarta. Qui la stessa regola, per tutte e due le
   settimane, e un confronto si fa solo se la settimana prima ha almeno tre giorni veri.
   --------------------------------------------------------------------------------------- */

let WK_DATI = null;
const WK_TETTO = 18 * 3600000;
const WK_GIORNO = 86400000;

/** Il tempo di schermo di un giorno, o 0 se il giorno non c'e' o la misura e' impossibile. */
function wkMsValido(r){
  const ms = (r && r.granted && r.screenMs) || 0;
  return (ms > 0 && ms <= WK_TETTO) ? ms : 0;
}

/** La finestra del report: i sette giorni interi prima di oggi (ieri compreso). */
/* 0.9.267, Andrea: i giorni partivano da giovedi' e finivano mercoledi' (gli ultimi sette giorni). La settimana e'
   quella del calendario: l'ultima completa, da lunedi' a domenica (o dal giorno con cui comincia la settimana nella
   lingua del telefono: negli Stati Uniti la domenica). Aperto di lunedi' e' la settimana appena finita. */
function wkPrimoGiorno(){
  try{ const L = new Intl.Locale(navigator.language || 'it'); const w = (L.getWeekInfo ? L.getWeekInfo() : L.weekInfo); if (w && w.firstDay >= 1 && w.firstDay <= 7) return w.firstDay % 7; }catch(_){ }
  return 1;   /* 1 = lunedi' (0 = domenica) */
}
function wkFinestra(){
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const primo = wkPrimoGiorno();
  const a = new Date(oggi); a.setDate(a.getDate() - ((oggi.getDay() - primo + 7) % 7));   /* l'inizio della settimana in corso */
  const da = new Date(a); da.setDate(da.getDate() - 7);                                   /* ... e quella prima, intera */
  const ieri = new Date(a); ieri.setDate(ieri.getDate() - 1);
  return { da: da, a: a, ieri: ieri, oggi: oggi };
}

/* 0.9.262, Andrea: la pagina Report si apre subito, la seconda slide del report settimanale restava nera.
   I dati della settimana si rileggevano da capo a ogni apertura (sedici giornate dal telefono) e si buttavano
   alla chiusura. Adesso restano: in memoria fra un'apertura e l'altra, e salvati sul telefono (fl_wk_cache)
   per la settimana a cui si riferiscono. Si mostrano subito e si aggiornano dietro. */
const WK_CACHE = 'fl_wk_cache';
let WK_IN_CORSO = null, WK_DATI_K = '';
function wkChiaveSett(){ const a = wkFinestra().a; return a.getFullYear() + '-' + (a.getMonth() + 1) + '-' + a.getDate(); }   /* i sette giorni finiscono ieri: cambiano ogni giorno */
function wkDaCache(){
  try{
    const c = JSON.parse(localStorage.getItem(WK_CACHE) || 'null');
    if (!c || c.k !== wkChiaveSett() || !c.d) return null;
    const d = c.d;
    /* 0.9.300, Andrea: "dal telefono aziendale il report diceva che non poteva misurare il tempo, ma il permesso
       l'avevo dato". La settimana veniva letta 2,5 secondi dopo l'avvio, prima del permesso, e quella lettura
       vuota restava in cache per tutta la settimana. Una settimana vuota non si rilegge dalla cache. */
    if (!d.totale) return null;
    (d.giorni || []).forEach(function(g){ g.data = new Date(g.data); });
    return d;
  }catch(_){ return null; }
}
function wkInCache(d){
  if (!d || !d.totale) return;
  try{
    const copia = JSON.parse(JSON.stringify(d));
    (copia.giorni || []).forEach(function(g){ g.top = (g.top || []).slice(0, 25).map(function(a){ return { packageName: a.packageName, label: a.label, ms: a.ms, launcher: a.launcher }; }); });
    localStorage.setItem(WK_CACHE, JSON.stringify({ k: wkChiaveSett(), at: Date.now(), d: copia }));
  }catch(_){ }
}
async function wkRaccogli(){
  const k = wkChiaveSett();
  /* una settimana vuota in memoria si rilegge: il permesso puo' essere arrivato dopo */
  if (WK_DATI && WK_DATI_K === k && (WK_DATI.totale || Date.now() - (WK_DATI.letto || 0) < 20000)) return WK_DATI;
  if (WK_DATI && !WK_DATI.totale) WK_DATI = null;
  if (!WK_DATI){
    const c = wkDaCache();
    if (c){
      WK_DATI = c; WK_DATI_K = k;
      /* i numeri freschi arrivano dietro, senza far aspettare nessuno */
      if (!WK_IN_CORSO) WK_IN_CORSO = wkLeggi().then(function(d){ WK_DATI = d; WK_DATI_K = k; wkInCache(d); return d; }).finally(function(){ WK_IN_CORSO = null; });
      return WK_DATI;
    }
  }
  if (!WK_IN_CORSO) WK_IN_CORSO = wkLeggi().then(function(d){ WK_DATI = d; WK_DATI_K = k; wkInCache(d); return d; }).finally(function(){ WK_IN_CORSO = null; });
  return WK_IN_CORSO;
}
async function wkLeggi(){
  const fin = wkFinestra();
  const giorni = [];
  /* 0.9.257, Andrea: quattordici letture UNA DOPO L'ALTRA tenevano a schermo «Sto mettendo in fila i
     tuoi sette giorni» per troppo tempo. Ora partono tutte insieme, e una lettura che fallisce non
     ferma le altre. */
  const leggi = function(i){ try{ return (typeof scReport === 'function') ? Promise.resolve(scReport(i)).catch(function(){ return null; }) : Promise.resolve(null); }catch(_){ return Promise.resolve(null); } };
  /* i giorni da leggere: quanti giorni fa, rispetto a oggi, cade ogni giorno della settimana scelta */
  const giorniFa = function(d){ return Math.round((fin.oggi - d) / WK_GIORNO); };
  const idx7 = [], idx14 = [];
  for (let k = 0; k < 7; k++){ const d = new Date(fin.da); d.setDate(d.getDate() + k); idx7.push(giorniFa(d)); idx14.push(giorniFa(d) + 7); }
  const tutti = await Promise.all(idx7.concat(idx14).map(leggi).concat([wkOre().catch(function(){ return []; }), wkSessioneLunga().catch(function(){ return null; })]));
  const rep7 = tutti.slice(0, 7), rep14 = tutti.slice(7, 14), ore = tutti[14], lunga = tutti[15];
  for (let k = 0; k < 7; k++){
    const i = idx7[k];
    const r = rep7[k];
    const ms = wkMsValido(r);
    const top = ms ? ((r && r.top) || []) : [];
    const dis = top.reduce(function(s, a){ return s + ((a && !a.launcher && typeof scIsDistracting === 'function' && scIsDistracting(wkPacchetto(a.packageName, a.label))) ? (a.ms || 0) : 0); }, 0);
    const data = new Date(fin.oggi); data.setDate(data.getDate() - i);
    const sonno = (r && r.sleepMs) || 0;
    giorni.push({ off: i, data: data, ms: ms, top: top, dis: Math.min(dis, ms), blocchi: (r && r.blocks) || 0,
                  sonno: (sonno >= 3 * 3600000 && sonno <= 14 * 3600000) ? sonno : 0 });
  }
  let prima = 0, nPrima = 0;
  rep14.forEach(function(r){ const ms = wkMsValido(r); if (ms){ prima += ms; nPrima++; } });

  const conDati = giorni.filter(function(x){ return x.ms > 0; });
  const totale = conDati.reduce(function(s, x){ return s + x.ms; }, 0);
  const media = conDati.length ? totale / conDati.length : 0;
  /* con meno di tre giorni veri la settimana prima non e' una settimana: niente confronto */
  const mediaPrima = (nPrima >= 3 && conDati.length) ? prima / nPrima : 0;

  /* LE ORE DI VEGLIA: per ogni giorno, le 24 ore meno la notte misurata; dove la notte non
     c'e', sedici ore. Mai meno del tempo passato sullo schermo. */
  const veglia = Math.max(totale, giorni.reduce(function(s, x){ return s + (x.sonno ? WK_GIORNO - x.sonno : 16 * 3600000); }, 0));

  /* Le app: si sommano i sette giorni, si tolgono il launcher e le nostre, e si tiene solo
     quello che l'app stessa considera una distrazione. */
  const mappa = {};
  giorni.forEach(function(d){
    (d.top || []).forEach(function(a){
      if (!a || a.launcher) return;
      /* 0.9.310: sul computer le giornate passate del telefono hanno il nome dell'app al posto del pacchetto
         ("Instagram"): la categoria e l'icona si cercano sul pacchetto vero */
      const k = (typeof wkPacchetto === 'function') ? (wkPacchetto(a.packageName, a.label) || a.packageName) : a.packageName;
      if (typeof scIsDistracting === 'function' && !scIsDistracting(k) && !scIsDistracting(a.packageName)) return;
      mappa[k] = mappa[k] || { pkg: k, label: a.label || k, ms: 0 };
      mappa[k].ms += a.ms || 0;
    });
  });
  const apps = Object.keys(mappa).map(function(k){ return mappa[k]; })
    .sort(function(a, b){ return b.ms - a.ms; }).slice(0, 6);

  /* il permesso si legge dai rapporti stessi: se il telefono ha risposto "concesso" il problema non e' il permesso */
  const permesso = rep7.concat(rep14).some(function(r){ return !!(r && r.granted); });
  return { giorni: giorni, totale: totale, media: media, mediaPrima: mediaPrima, veglia: veglia,
           apps: apps, ore: ore || [], lunga: lunga || null, permesso: permesso, letto: Date.now() };
}

/**
 * Le ventiquattro ore della settimana, sommate: quale fascia se ne prende di piu'.
 *
 * <p>LEGGEVA UN CAMPO CHE NON C'E'. Il motore chiama l'inizio di ogni ora `start`; qui si
 * leggeva `from` o `at`, si trovava zero, e zero e' il primo gennaio 1970 all'una di notte:
 * tutta la settimana finiva nella barra delle 01:00, e l'ora difficile era sempre quella.</p>
 */
async function wkOre(){
  const ore = new Array(24).fill(0);
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return ore;
    const f = wkFinestra();
    const r = await NATIVE.getScreenTimeRange({ from: f.da.getTime(), to: f.a.getTime(), bucket: 'hour' });
    (r && r.buckets || []).forEach(function(b){
      const t = b.start || b.from || b.at;
      if (!t) return;
      const ms = b.ms != null ? b.ms : (b.minutes || 0) * 60000;
      ore[new Date(t).getHours()] += Math.max(0, Math.min(3600000, ms || 0));   // un'ora ne contiene al massimo una
    });
  }catch(_){ }
  return ore;
}

function wkOraPeggiore(ore){
  let best = 0;
  for (let i = 1; i < 24; i++) if (ore[i] > ore[best]) best = i;
  return best;
}

/**
 * La sessione piu' lunga della settimana: quanto tempo di fila su una sola app.
 *
 * <p>LA SCHERMATA "TUTTO D'UN FIATO" MOSTRAVA LA PAUSA PIU' LUNGA. Leggeva `longestGapMs`, che
 * il motore calcola come il tratto piu' lungo SENZA telefono, e lo chiamava "la tua sessione
 * piu' lunga". Adesso si legge la fila vera (getTimeline: ogni pezzo d'uso con l'app, l'inizio
 * e la durata), si uniscono i pezzi della stessa app separati da meno di due minuti, e si
 * tiene il tratto piu' lungo su un'app che distrae. Senza la fila, la schermata non c'e'.</p>
 */
async function wkSessioneLunga(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return null;
  const f = wkFinestra();
  let best = null;
  for (let i = 0; i < 7; i++){
    const da = new Date(f.da); da.setDate(da.getDate() + i);
    let d = null;
    try{ d = await NATIVE.getTimeline({ from: da.getTime(), to: da.getTime() + WK_GIORNO, minMs: 0, limit: 1800 }); }catch(_){ d = null; }
    const g = ((d && d.grani) || []).slice().sort(function(a, b){ return a.s - b.s; });
    let cur = null;
    const chiudi = function(){
      if (!cur) return;
      const ok = cur.ms <= 10 * 3600000 && (typeof scIsDistracting !== 'function' || scIsDistracting(cur.pkg));
      if (ok && (!best || cur.ms > best.ms)) best = cur;
      cur = null;
    };
    g.forEach(function(x){
      if (!x || !x.p || !(x.ms > 0)) return;
      if (cur && cur.pkg === x.p && x.s - cur.fine <= 120000){ cur.fine = Math.max(cur.fine, x.s + x.ms); cur.ms = cur.fine - cur.at; return; }
      chiudi();
      cur = { pkg: x.p, label: x.l || x.p, at: x.s, fine: x.s + x.ms, ms: x.ms };
    });
    chiudi();
  }
  return (best && best.ms >= 10 * 60000) ? best : null;     // sotto i dieci minuti non e' una storia
}

/* ---------------------------------------------------------------------------------------
   LE FACCE DELLE APP

   «WhatsApp» scritto non è la stessa cosa dell'icona di WhatsApp. In una schermata che dice
   «queste sono le tue distrazioni», l'icona è metà del messaggio: la riconosci prima di
   leggerla, ed è la stessa che tocchi cinquanta volte al giorno.

   Il motore le tiene già (getAppIcon, una PNG in base64). Si chiedono una volta e si tengono
   da parte: in un funnel di sette schermate la stessa app compare in tre.
   --------------------------------------------------------------------------------------- */
const WK_ICONE = {};
const WK_ICO_ATTESE = {};

/* 0.9.310, Andrea (foto del PC, 729.png): "I ladri di tempo" sul computer senza l'icona di Instagram, sul telefono
   c'e'. LA CAUSA: l'icona si chiedeva SOLO al motore (NATIVE.getAppIcon). Sul telefono il motore e' Android e la da';
   sul computer il motore e' il ponte di Windows, che conosce le icone dei programmi del PC e non quelle delle app del
   telefono: rispondeva vuoto, e la slide restava senza (Instagram) o con il riquadro grigio (WhatsApp). In piu' sul
   computer le giornate passate del telefono arrivano con il NOME dell'app ("Instagram"), non con il pacchetto.
   ADESSO l'icona si cerca, in ordine: la cache delle icone dell'app (memoria + IndexedDB dm-icone, insights.js), la
   mappa di icone che il telefono pubblica per il computer (fl:dopamina, mwAltroPub), il motore di qui, e per le app
   note il disegno di img/social. Il nome si traduce nel pacchetto (wkPacchetto) prima di cercare. */
function wkEPacchetto(p){ return /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i.test(String(p || '')); }
/** Il pacchetto Android di un'app, anche quando arriva solo il nome ("Instagram" -> com.instagram.android). */
function wkPacchetto(pkg, label){
  if (wkEPacchetto(pkg)) return pkg;
  const nome = String(label || pkg || '').trim().toLowerCase();
  if (!nome) return pkg || '';
  try{
    if (typeof SOC_APPS !== 'undefined' && SOC_APPS){
      for (const k in SOC_APPS){ if (String(SOC_APPS[k].nome || '').toLowerCase() === nome) return k; }
    }
    if (typeof FL_APP_NAMES !== 'undefined' && FL_APP_NAMES){
      for (const k in FL_APP_NAMES){ if (String(FL_APP_NAMES[k]).toLowerCase() === nome) return k; }
    }
  }catch(_){ }
  return pkg || '';
}
/** Il disegno dell'app nota (img/social), finche' non c'e' l'icona vera. */
function wkIconaNota(pkg){
  try{
    if (typeof SOC_APPS === 'undefined' || !SOC_APPS) return '';
    if (SOC_APPS[pkg] && SOC_APPS[pkg].img) return SOC_APPS[pkg].img;
    for (const k in SOC_APPS){ if ((SOC_APPS[k].altri || []).indexOf(pkg) >= 0) return SOC_APPS[k].img || ''; }
  }catch(_){ }
  return '';
}
function wkIcoValida(u){ return !!u && (String(u).indexOf('data:image') === 0 || /^img\//.test(String(u))); }
async function wkIcona(pkg, label){
  if (!pkg) return '';
  if (WK_ICONE[pkg]) return WK_ICONE[pkg];
  if (WK_ICO_ATTESE[pkg]) return WK_ICO_ATTESE[pkg];
  WK_ICO_ATTESE[pkg] = (async function(){
    const vero = wkPacchetto(pkg, label);
    const chiavi = vero && vero !== pkg ? [vero, pkg] : [pkg];
    let ic = '';
    /* 1. la cache delle icone dell'app (telefono e computer: si apre all'avvio) */
    try{ if (typeof insIcoPronte === 'function') await Promise.race([insIcoPronte(), new Promise(function(r){ setTimeout(r, 400); })]); }catch(_){ }
    for (const k of chiavi){ if (!ic && typeof INS_ICONE !== 'undefined' && wkIcoValida(INS_ICONE[k])) ic = INS_ICONE[k]; }
    /* 2. le icone che il telefono ha pubblicato per il computer */
    if (!ic){
      try{
        const a = (typeof mwQuiComputer === 'function' && mwQuiComputer() && typeof mwAltroPub === 'function') ? mwAltroPub() : null;
        for (const k of chiavi.concat([label || ''])){ if (!ic && a && a.ico && wkIcoValida(a.ico[k])) ic = a.ico[k]; }
      }catch(_){ }
    }
    /* 3. il motore di qui: Android per le app del telefono, il ponte di Windows per i programmi del PC */
    if (!ic){
      try{
        if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getAppIcon){
          const r = await NATIVE.getAppIcon({ packageName: vero || pkg });
          const u = (r && (r.icon || r.dataUri || r.png)) || '';
          if (wkIcoValida(u)){ ic = u; try{ if (typeof insIcoSalva === 'function' && wkEPacchetto(vero)) insIcoSalva(vero, u); }catch(_){ } }
        }
      }catch(_){ }
    }
    /* 4. l'app nota: il suo disegno */
    if (!ic) ic = wkIconaNota(vero) || wkIconaNota(pkg);
    if (ic) WK_ICONE[pkg] = ic;
    delete WK_ICO_ATTESE[pkg];
    return ic;
  })();
  return WK_ICO_ATTESE[pkg];
}

/** Carica le icone delle app che serviranno, prima di disegnare: tutte insieme, non una dopo l'altra. */
async function wkIconePronte(apps){
  await Promise.all((apps || []).map(function(a){ return wkIcona(a.pkg, a.label).catch(function(){ return ''; }); }));
}

function wkIconaTag(pkg, px){
  const d = WK_ICONE[pkg];
  if (!d) return '';
  return '<img class="wk-ico" style="width:' + px + 'px;height:' + px + 'px" src="' + d.replace(/"/g, '') + '" alt="">';
}

function wkH(ms){
  const h = Math.floor(ms / 3600000), m = Math.round((ms % 3600000) / 60000);
  if (m === 60) return (h + 1) + 'h 00m';
  return h ? h + 'h ' + String(m).padStart(2, '0') + 'm' : m + 'm';
}

/** Una durata scritta per esteso, come la direbbe una persona: "1 ora e 20 minuti", "1 giorno e 11 ore". */
function wkLungo(ms){
  const min = Math.round((ms || 0) / 60000);
  if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti';
  if (min >= 24 * 60){
    const H = Math.round(min / 60), g = Math.floor(H / 24), h = H % 24;
    return g + (g === 1 ? ' giorno' : ' giorni') + (h ? ' e ' + h + (h === 1 ? ' ora' : ' ore') : '');
  }
  const h = Math.floor(min / 60), m = min % 60;
  return h + (h === 1 ? ' ora' : ' ore') + (m ? ' e ' + m + (m === 1 ? ' minuto' : ' minuti') : '');
}

/** La stessa durata, corta, per le etichette: "1g 11h" sopra le 24 ore, "6h 28m" sotto. */
function wkCorto(ms){
  if ((ms || 0) < WK_GIORNO) return wkH(ms || 0);
  const H = Math.round(ms / 3600000), g = Math.floor(H / 24), h = H % 24;
  return g + 'g' + (h ? ' ' + h + 'h' : '');
}

/* ---------------------------------------------------------------------------------------
   LE ICONE: sempre SVG, mai caratteri (Andrea: niente › ↗ ✓ ✕ scritti come testo).
   --------------------------------------------------------------------------------------- */
function wkSvg(d, cls, sw){
  return '<svg class="' + (cls || 'wk-svg') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || 2.2)
    + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
}
const WK_IC = {
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  ok: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  su: '<path d="M7 17L17 7"/><path d="M9 7h8v8"/>',
  giu: '<path d="M7 7l10 10"/><path d="M17 9v8H9"/>',
  piu: '<path d="M12 5v14M5 12h14"/>',
  tel: '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
  sole: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6L6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4L6 18M18 6l1.4-1.4"/>',
  sveglia: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.5 2"/><path d="M5 3.5L2.5 6M19 3.5L21.5 6"/>',
  clessidra: '<path d="M6 2.5h12M6 21.5h12"/><path d="M7.5 2.5h9L12 12l4.5 9.5h-9L12 12z"/>',
  lucchetto: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/>',
  chat: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H9l-4.2 3.4V16A2.5 2.5 0 0 1 4 13.5z"/><path d="M8 8h8M8 11.5h5"/>'
};
/* LA CONDIVISIONE: la stessa icona della frase del giorno (scores.js, pagina Ispirazione
   quotidiana), copiata tale e quale. Prima qui c'era il carattere della freccia obliqua. */
const WK_SHARE = '<svg class="wk-share-i" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'
  + '<g transform="translate(-1,0)"><circle cx="17.2" cy="5" r="2.8"></circle><circle cx="6" cy="12" r="2.8"></circle>'
  + '<circle cx="17.2" cy="19" r="2.8"></circle><line x1="9" y1="13" x2="14.7" y2="17"></line>'
  + '<line x1="14.7" y1="7" x2="9" y2="10"></line></g></svg>';

/* ---------------------------------------------------------------------------------------
   Le schermate
   --------------------------------------------------------------------------------------- */

let WK_I = 0;
/* LE SCHERMATE, in ordine. Quelle senza un numero vero da mostrare non ci sono: niente
   confronto senza la settimana prima, niente ora difficile senza le ore, niente sessione
   piu' lunga senza la fila delle app. In fondo, dopo la condivisione, la chiusura con le due
   strade (il report completo, l'agente). */
let WK_NUOVA = false;
function wkElenco(){
  const d = WK_DATI;
  const l = ['cover', 'media'];
  if (!d || d.mediaPrima > 0) l.push('tendenza');
  l.push('totale', 'distrazioni');
  if (!d || d.ore.some(function(v){ return v > 0; })) l.push('ora');
  if (!d || d.lunga) l.push('continuo');
  return l.concat(['pause', 'condividi', 'fine']);
}
function wkN(){ return wkElenco().length; }
const WK_GG = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
const WK_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
const WK_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
/* il giorno della settimana VERO di quella data: aperto di giovedi', sette giorni fa era giovedi' */
function wkGG(data){ return WK_GG[(data.getDay() + 6) % 7]; }
function wkNome(){ try{ return String((JSON.parse(localStorage.getItem('fl_user') || 'null') || {}).name || '').split(' ')[0]; }catch(_){ return ''; } }
function wkGenio(posa, cls){ return '<img class="wk-genio' + (cls ? ' ' + cls : '') + '" src="img/genio/genio-' + (posa || 'saluta') + '.png" alt="">'; }
function wkPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
/* la chevron del tema (snippets/icon.liquid), la stessa di .chev */
const WK_CHEV = '<svg class="wk-chev" viewBox="0 0 8 12" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" d="M1.5 1 6.5 6 1.5 11"/></svg>';

/* "dal 6 al 12 ottobre", "dall'8 all'11 ottobre", "dal 29 settembre al 5 ottobre" */
function wkRangeTesto(){
  const f = wkFinestra(), da = f.da, a = f.ieri;
  const art = function(n, base){ return (n === 1 || n === 8 || n === 11) ? base + 'l\'' + n : base + 'l ' + n; };
  const stesso = da.getMonth() === a.getMonth();
  return art(da.getDate(), 'da') + (stesso ? '' : ' ' + WK_MESI[da.getMonth()]) + ' ' + art(a.getDate(), 'a') + ' ' + WK_MESI[a.getMonth()];
}

/* ---- le pause della settimana: dal registro delle interruzioni (interrupt.js) e da quello
   delle riprese. La durata si conta solo dove la ripresa e' registrata: un numero inventato
   sarebbe peggio di nessun numero. ---- */
function wkPause(){
  /* la stessa finestra dei numeri del report: i sette giorni prima di oggi */
  const f = wkFinestra(), a = f.a, da = f.da;
  let reg = [], rip = [];
  try{ reg = JSON.parse(localStorage.getItem('fl_interrupts_log') || '[]') || []; }catch(_){ }
  try{ rip = JSON.parse(localStorage.getItem('fl_riprese_log') || '[]') || []; }catch(_){ }
  let n = 0, ms = 0, noto = false;
  reg.forEach(function(r){
    if (!r || r.at < da.getTime() || r.at >= a.getTime()) return;
    n++;
    const fine = rip.filter(function(x){ return x && x.id === r.id && x.at > r.at; }).sort(function(x, y){ return x.at - y.at; })[0];
    if (fine){ ms += Math.min(fine.at, a.getTime()) - r.at; noto = true; }
  });
  return { n: n, ms: ms, noto: noto };
}

/** Vero quando l'app e' gia' dentro a un programma: il suo riquadro nasce gia' spuntato. */
function wkGiaInRegola(pkg){
  try{ return typeof PROGRAMS !== 'undefined' && PROGRAMS.some(function(p){ return p && Array.isArray(p.apps) && p.apps.indexOf(pkg) >= 0; }); }catch(_){ return false; }
}

async function wkSlide(i){
  const k0 = wkElenco()[i];
  /* 0.9.259: la copertina non aspetta i numeri */
  const d = k0 === 'cover' ? (WK_DATI || null) : await wkRaccogli();
  const k = wkElenco()[i];
  const nome = wkNome();

  if (k === 'cover'){
    return '<div class="wk-cover">'
      + wkGenio('saluta')
      + '<h2>La tua<br>settimana</h2>'
      + '<p>' + (nome ? esc(nome) + ', un\'altra' : 'Un\'altra') + ' settimana di viaggio è finita. Vediamo insieme dove ti ha portato.</p>'
      + '<b class="wk-range">' + esc(wkRangeTesto().replace(/^d/, 'D')) + '</b></div>';
  }

  if (k === 'media'){
    /* 0.9.260, Andrea, come AppBlock: ogni barra divisa in produttivo (in basso), neutrale e distrattivo (in cima),
       con la linea tratteggiata della media. Le categorie sono quelle del Report (insCats); il tempo senza app
       riconosciuta va nel neutrale. */
    const max = Math.max.apply(null, d.giorni.map(function(x){ return x.ms; }).concat([1]));
    const H = 170;
    const C = (typeof INS_CAT !== 'undefined') ? INS_CAT : { distr: { color: '#E63946' }, neutro: { color: '#2F55D4' }, prod: { color: '#22C55E' } };
    const barre = d.giorni.map(function(x){
      const h = x.ms ? Math.max(6, Math.round(x.ms / max * H)) : 4;
      let sp = { distr: 0, neutro: x.ms, prod: 0 };
      try{ if (x.ms && typeof insSplit === 'function'){ const q = insSplit((x.top || []).filter(function(a){ return a && !a.launcher; }), x.ms); sp = { distr: q.distr, neutro: q.neutro + q.none, prod: q.prod }; } }catch(_){ }
      const tot = Math.max(1, sp.distr + sp.neutro + sp.prod);
      const pezzo = function(k){ const v = sp[k] / tot; return v > 0 ? '<b style="flex:' + v.toFixed(4) + ' 0 0;background:' + C[k].color + '"></b>' : ''; };
      return '<div class="wk-bar"><i class="wk-pila" style="height:' + h + 'px">' + (x.ms ? pezzo('distr') + pezzo('neutro') + pezzo('prod') : '') + '</i><small>' + wkGG(x.data) + '</small>'
        + '<u>' + (x.ms ? wkH(x.ms) : '') + '</u></div>';
    }).join('');
    const yMedia = d.media ? Math.round(d.media / max * H) : 0;
    const legenda = '<div class="wk-legenda">' + ['distr', 'neutro', 'prod'].map(function(k){ return '<span><i style="background:' + C[k].color + '"></i>' + ({ distr: 'Distrattivo', neutro: 'Neutrale', prod: 'Produttivo' })[k] + '</span>'; }).join('') + '</div>';
    const delta = d.mediaPrima ? Math.round((d.media - d.mediaPrima) / d.mediaPrima * 100) : 0;
    const leggero = d.giorni.reduce(function(a, b){ return (b.ms && (!a.o || b.ms < a.ms)) ? { ms: b.ms, o: WK_GIORNI[b.data.getDay()] } : a; }, { ms: 0, o: '' });
    return wkHead('Tempo al telefono', 'Ogni giorno, in media, lo schermo ti ha preso')
      + '<b class="wk-big">' + wkH(d.media) + '</b>'
      + (d.mediaPrima && delta ? '<p class="wk-delta ' + (delta > 0 ? 'su' : 'giu') + '">'
          + wkSvg(delta > 0 ? WK_IC.su : WK_IC.giu, 'wk-tr', 2.6) + Math.min(99, Math.abs(delta)) + '% ' + (delta > 0 ? 'in più' : 'in meno') + ' della settimana prima</p>' : '')
      + '<div class="wk-bars wk-bars-pila" style="--media:' + yMedia + 'px">' + barre + (yMedia ? '<i class="wk-media-linea" aria-label="La media"></i>' : '') + '</div>'
      + legenda
      + (leggero.o ? '<p class="wk-line">Il giorno più leggero è stato <b>' + leggero.o + '</b>, con ' + wkLungo(leggero.ms) + ' di telefono. Ne voglio vedere altri così.</p>' : '');
  }

  /* LA DIREZIONE: la media di ogni giorno di questa settimana contro la media di ogni giorno
     della settimana prima. Due medie al giorno, quindi una differenza AL GIORNO: non puo'
     superare le 18 ore, e con i giorni impossibili scartati sta dove deve stare. */
  if (k === 'tendenza'){
    const diff = d.media - d.mediaPrima;
    const pari = Math.round(Math.abs(diff) / 60000) < 5;
    const su = diff > 0;
    const pct = d.mediaPrima >= 15 * 60000 ? Math.min(99, Math.round(Math.abs(diff) / d.mediaPrima * 100)) : 0;
    const titolo = pari ? 'Questa settimana il telefono ti ha preso lo stesso tempo della settimana prima'
      : (su ? 'Questa settimana ogni giorno hai dato ' + wkLungo(Math.abs(diff)) + ' in più al telefono'
            : 'Questa settimana ogni giorno hai tolto ' + wkLungo(Math.abs(diff)) + ' al telefono');
    const max = Math.max(d.media, d.mediaPrima, 1);
    const riga = function(et, ms, cls){
      return '<div class="wk-cmp-r ' + cls + '"><small>' + et + '</small><span><i style="width:' + Math.max(4, Math.round(ms / max * 100)) + '%"></i></span>'
        + '<b>' + wkH(ms) + ' <em>al giorno</em></b></div>';
    };
    const frase = pari
      ? 'Circa ' + wkLungo(d.media) + ' al giorno, come sette giorni fa. Togli 15 minuti al giorno e la prossima settimana la direzione cambia.'
      : (su ? (pct ? 'Il tempo al telefono è cresciuto del <b>' + pct + '%</b> rispetto alla settimana prima. ' : '') + 'Da oggi lo riprendiamo, un giorno alla volta.'
            : (pct ? 'Il tempo al telefono è sceso del <b>' + pct + '%</b> rispetto alla settimana prima. ' : '') + 'Quel tempo adesso è tuo: continua così.');
    return wkHead('La direzione', titolo)
      + wkGenio(su && !pari ? 'pensa' : 'rivela', 'wk-genio-s')
      + '<div class="wk-cmp wk-uno-dentro">' + riga('La settimana prima', d.mediaPrima, 'prima') + riga('Questa settimana', d.media, 'ora ' + (pari ? '' : (su ? 'su' : 'giu'))) + '</div>'
      + '<p class="wk-line">' + frase + '</p>';
  }

  /* IL CONTO, COME QUELLO DI APPBLOCK: un anello con due parti e due etichette. Il sole sono
     le ore di veglia della settimana, il telefono la parte che e' andata allo schermo. I
     totali sopra le 24 ore si leggono in giorni: "35h 45m" non lo misura nessuno a occhio. */
  if (k === 'totale'){
    if (!d.totale){
      if (d.permesso) return wkHead('Il conto della settimana', 'Il telefono non ha ancora giorni misurati per questa settimana')
        + '<p class="wk-line">Il conto arriva con la prossima settimana intera.</p>';
      return wkHead('Il conto della settimana', 'Questa settimana non ho potuto misurare il tempo sullo schermo')
        + '<p class="wk-line">Serve il permesso di leggere l\'utilizzo delle app. Lo trovi nelle impostazioni del telefono, alla voce Accesso ai dati di utilizzo.</p>';
    }
    const pct = d.veglia ? Math.min(100, Math.round(d.totale / d.veglia * 100)) : 0;
    /* 0.9.256, Andrea: come AppBlock. Il tempo in blu nel titolo, l'anello con il resto grigio e il sole
       dalla parte opposta, niente riquadri sotto; la frase sta in fondo, staccata dall'anello. */
    return '<p class="wk-eyebrow">Il conto della settimana</p><h3 class="wk-h">In una settimana hai passato <span class="wk-blu">' + esc(wkLungo(d.totale)) + '</span> davanti allo schermo</h3>'
      + wkAnello(pct, wkCorto(d.totale), wkCorto(d.veglia))
      + '<p class="wk-line wk-line-giu">Il tuo tempo sullo schermo è circa il <span class="wk-blu">' + pct + '%</span> del tempo in cui eri sveglio.</p>';
  }

  if (k === 'distrazioni'){
    if (!d.apps.length){
      if (d.permesso && d.totale) return wkHead('I ladri di tempo', 'Nessun ladro di tempo questa settimana')
        + '<p class="wk-line">Le app che ti distraggono sono rimaste chiuse. Hai tenuto benissimo.</p>';
      if (d.permesso) return wkHead('I ladri di tempo', 'Il telefono non ha ancora giorni misurati per questa settimana')
        + '<p class="wk-line">I ladri di tempo compaiono con la prossima settimana intera.</p>';
      return wkHead('I ladri di tempo', 'Non posso ancora vedere i ladri di tempo')
        + '<p class="wk-line">Serve il permesso di leggere l\'utilizzo delle app, alla voce Accesso ai dati di utilizzo.</p>';
    }
    await wkIconePronte(d.apps);
    const primo = d.apps[0];
    const altre = d.apps.slice(1).map(function(a){
      const fatto = wkGiaInRegola(a.pkg);
      return '<button type="button" class="wk-app' + (fatto ? ' fatto' : '') + '" aria-label="Aggiungi ' + esc(a.label) + ' al blocco"'
        + ' onclick="wkBlocca(\'' + a.pkg + '\', ' + esc(JSON.stringify(a.label)) + ', this)">'
        + '<span class="wk-piu">' + wkSvg(fatto ? WK_IC.ok : WK_IC.piu, 'wk-svg', 3) + '</span>'
        + (wkIconaTag(a.pkg, 34) || '<span class="wk-ico-v"></span>')
        + '<small>' + esc(a.label) + '</small><u>' + wkH(a.ms) + '</u></button>';
    }).join('');
    return wkHead('I ladri di tempo', 'L\'app su cui hai passato più tempo questa settimana')
      + (wkIconaTag(primo.pkg, 60) || '')
      + '<b class="wk-app1">' + esc(primo.label) + '</b>'
      + '<p class="wk-line wk-line-s">Tempo su ' + esc(primo.label) + ' in sette giorni: <b>' + wkH(primo.ms) + '</b></p>'
      + '<button type="button" class="wk-do" onclick="wkBlocca(\'' + primo.pkg + '\', ' + esc(JSON.stringify(primo.label)) + ', this)">'
      +   wkSvg(WK_IC.lucchetto, 'wk-do-i', 2.2) + 'Blocca o limita ' + esc(primo.label) + '</button>'
      + '<div class="wk-esito" id="wkEsito"></div>'
      + (altre ? '<p class="wk-sub">Altre app che ti distraggono</p><div class="wk-apps">' + altre + '</div>'
                 + '<p class="wk-hint">Tocca un\'app per aggiungerla al blocco</p>' : '');
  }

  /* L'ORA DIFFICILE: tutte le ventiquattro ore, in azzurro tenue; quella che pesa di piu' in
     rosso pieno. Le etichette 0, 6, 12, 18 stanno sotto alle loro barre, non sparse. */
  if (k === 'ora'){
    const h = wkOraPeggiore(d.ore);
    const max = Math.max.apply(null, d.ore.concat([1]));
    const barre = d.ore.map(function(v, j){
      return '<i class="' + (j === h ? 'on' : '') + '" style="height:' + Math.max(3, Math.round(v / max * 120)) + 'px"></i>';
    }).join('');
    const assi = [0, 6, 12, 18].map(function(o){ return '<span style="left:' + ((o + 0.5) / 24 * 100).toFixed(2) + '%">' + o + '</span>'; }).join('');
    return wkHead('L\'ora difficile', 'In questa fascia il telefono ti chiama più forte')
      + '<b class="wk-big"><small>dalle</small> ' + h + ' <small>alle</small> ' + ((h + 1) % 24) + '</b>'
      + '<p class="wk-cap2">In sette giorni, in quest\'ora, il telefono ti ha preso ' + wkLungo(d.ore[h]) + '</p>'
      + '<div class="wk-hours">' + barre + '</div>'
      + '<div class="wk-axis">' + assi + '</div>'
      + '<button type="button" class="wk-do" onclick="wkProgramma(' + h + ')">' + wkSvg(WK_IC.sveglia, 'wk-do-i', 2.2) + 'Proteggi questa fascia</button>'
      + '<div class="wk-esito" id="wkEsito"></div>';
  }

  if (k === 'continuo'){
    const s = d.lunga;
    await wkIcona(s.pkg, s.label);
    const quando = new Date(s.at);
    return wkHead('Tutto d\'un fiato', 'La tua sessione più lunga della settimana')
      + (wkIconaTag(s.pkg, 56) || '')
      + '<b class="wk-big">' + wkH(s.ms) + ' <small>di fila</small></b>'
      + '<p class="wk-line">Su <b>' + esc(s.label) + '</b>, ' + WK_GIORNI[quando.getDay()] + ' alle '
      +   String(quando.getHours()).padStart(2, '0') + ':' + String(quando.getMinutes()).padStart(2, '0')
      +   ': ' + wkLungo(s.ms) + ' senza mai staccare.</p>'
      + '<button type="button" class="wk-do" onclick="wkLimite(\'' + s.pkg + '\', ' + esc(JSON.stringify(s.label)) + ')">'
      +   wkSvg(WK_IC.clessidra, 'wk-do-i', 2.2) + 'Metti un limite a ' + esc(s.label) + '</button>'
      + '<div class="wk-esito" id="wkEsito"></div>';
  }

  if (k === 'pause'){
    const p = wkPause();
    if (!p.n){
      return wkHead('Le regole', 'Sette giorni senza fermare un blocco')
        + wkGenio('rivela')
        + '<b class="wk-big giu">0 <small>volte</small></b>'
        + '<p class="wk-line">Le regole che hai scelto hanno retto tutta la settimana. È così che si arriva.</p>';
    }
    return wkHead('Le regole piegate', p.n === 1 ? 'Una volta hai fermato un blocco a metà' : p.n + ' volte hai fermato un blocco a metà')
      + '<span class="wk-tag">Occhio</span>'
      + '<b class="wk-big">' + p.n + ' <small>' + (p.n === 1 ? 'volta' : 'volte') + '</small></b>'
      + (p.noto ? '<p class="wk-cap2">In pausa in tutto: ' + wkH(p.ms) + '</p>' : '')
      /* 0.9.321, Andrea: "non voglio che si senta sopraffatto". Il perche' si legge solo se lo si chiede */
      + '<button type="button" class="wk-perche" onclick="wkPercheApri(this)">Perché conta' + WK_CHEV + '</button>'
      + '<p class="wk-perche-t" hidden>La voglia di fermarlo arriva sempre nel momento sbagliato. Togli la scelta a quel momento.</p>'
      + '<button type="button" class="wk-do" onclick="wkSevera()">' + wkSvg(WK_IC.lucchetto, 'wk-do-i', 2.2) + 'Apri la Modalità severa</button>'
      + '<button type="button" class="wk-vedi" onclick="wkNiente()">Togli le pause dalle impostazioni' + WK_CHEV + '</button>';
  }

  if (k === 'condividi'){
    return wkHead('Racconta la tua settimana', 'Mandala a chi tifa per te')
      + '<div class="wk-card" id="wkCard">' + wkCardHtml(d) + '</div>'
      + '<button type="button" class="wk-do wk-share" onclick="wkCondividi()">' + WK_SHARE + 'Condividi</button>';
  }

  /* LA CHIUSURA: una settimana nuova, e le due strade. Il report completo per chi vuole i
     numeri esatti; l'agente per chi vuole sapere cosa farne (con Premium; senza, la stessa
     porta con il bollino, che apre la pagina di Premium). */
  /* 0.9.260, Andrea: la chiusura e' UNA frase, scritta a macchina, sola sullo schermo. Il Genio e le due
     strade arrivano DOPO, quando la frase e' finita (il loro posto e' gia' tenuto: niente salti). */
  /* 0.9.286, Andrea: "La mia vita in settimane" (vita-settimane.js) come passaggio dell'ultima slide: la casella della
     settimana appena chiusa la annerisci tu, poi "La frase della settimana:" con il suo autore, poi il Genio. */
  const vita = typeof vsAvvento === 'function' && typeof mmConti === 'function' && !!mmConti();
  try{ await wkFrasiCarica(); }catch(_){ }
  const fr = wkFraseSettimana();
  return '<div class="wk-fine">'
    + (vita ? '<div class="wk-vita" id="wkVita"></div>' : '')
    + '<div class="wk-frase-w' + (vita ? ' dopo' : '') + '" id="wkFraseW">'
    +   '<p class="wk-frase-kick">La frase della settimana</p>'
    +   '<h3 class="wk-h wk-h-fine" id="wkFineFrase" aria-label="' + esc(fr.t + (fr.a ? ' ' + fr.a : '')) + '"></h3>'
    /* 0.9.287, Andrea: l'autore con il ⁓ davanti, in corsivo */
    +   '<p class="wk-frase-aut" id="wkFineAut">' + (fr.a ? '⁓ ' + esc(fr.a) : '') + '</p>'
    + '</div>'
    + '<div class="wk-fine-dopo" id="wkFineDopo">' + wkGenio('rivela', 'wk-genio-s wk-genio-fermo')
    + '<div class="wk-scelte wk-scelte-giu">'
    /* 0.9.300, Andrea: "se uno non ha un agente personale non deve apparire". L'agente c'e' solo con Premium e
       l'account collegato: il pulsante nasce nascosto e compare quando wkHaAgente() lo conferma. */
    +   '<button type="button" class="wk-ag" id="wkAgBtn" hidden onclick="wkChiediAgente()"><i class="wk-emo" aria-hidden="true">\uD83D\uDCAC</i>'
    +     '<span>Chiedi al tuo agente personale come migliorare la settimana</span></button>'
    +   '<button type="button" class="wk-next wk-tutto" onclick="wkGo(1)">Vedi il report completo</button>'
    + '</div></div></div>';
}
/* LA FRASE DELLA SETTIMANA (0.9.310).
   Andrea (foto del PC, 728.webp): "e' sempre la stessa", Ieri e' storia... di Kung Fu Panda. LA CAUSA VERA: la frase si
   sceglieva contando le settimane da un punto fisso (settimana del 19/10 = posizione 28 della lista) e andando avanti di
   una. Ma la posizione era scritta a mano: quando la 0.9.302 ha aggiunto due frasi (Liguori, Gandhi) PRIMA di quella di
   Oogway, Oogway e' scivolata dalla 28 alla 30, e due settimane dopo il conto ci e' ricaduto sopra (settimana del 2/11).
   La stessa frase il 19/10 e il 2/11. E ogni frase aggiunta o tolta piu' in alto avrebbe rimescolato tutto di nuovo.
   ADESSO: 53 frasi in www/content/frasi-settimana.json, una per ogni settimana ISO dell'anno (la settimana N mostra la
   frase N, la 53 c'e' solo negli anni che ce l'hanno, come il 2026). Nessun punto fisso, nessun conto: in un anno non
   se ne ripete nessuna, e cambiare una frase non sposta le altre. Il file si carica all'avvio e prima dell'ultima slide. */
const WK_FINE_SEMPRE = 'La settimana scorsa è già scritta.\nQuesta è una pagina bianca, e la penna ce l’hai tu.';
let WK_FRASI = null, WK_FRASI_P = null;
function wkFrasiCarica(){
  if (WK_FRASI) return Promise.resolve(WK_FRASI);
  if (!WK_FRASI_P){
    WK_FRASI_P = fetch('content/frasi-settimana.json', { cache: 'no-cache' })
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(j){
        const l = (j && Array.isArray(j.frasi)) ? j.frasi.filter(function(f){ return f && f.t; }) : [];
        if (l.length) WK_FRASI = l;
        return WK_FRASI;
      })
      .catch(function(){ return null; })
      .then(function(v){ if (!v) WK_FRASI_P = null; return v; });   /* andato male: si riprova la prossima volta */
  }
  return WK_FRASI_P;
}
/** Il numero della settimana ISO (1-53) del giorno d: la stessa regola di wkWeekKey. */
function wkSettimanaIso(d){ return +String(wkWeekKey(d || new Date())).split('-W')[1] || 1; }
function wkFraseSettimana(d){
  const l = WK_FRASI;
  /* il file non c'e' (mai successo nell'app installata): la frase di sempre della chiusura, senza autore */
  if (!l || !l.length) return { t: WK_FINE_SEMPRE.replace(/\n/g, ' '), a: '' };
  const f = l[(wkSettimanaIso(d) - 1) % l.length];
  return { t: String(f.t).replace(/^"|"$/g, ''), a: String(f.a || '').trim() };
}
/* il testo della frase della settimana, con l'autore (per chi la vuole in una riga sola) */
function wkFineFrase(){ const f = wkFraseSettimana(); return '"' + f.t + '"' + (f.a ? ', ' + f.a : ''); }
let WK_TW = 0;
/* l'ultima slide: prima la vita in settimane (se c'e' la data di nascita), poi la frase */
function wkFineAvvia(){
  const v = document.getElementById('wkVita');
  if (v && typeof vsAvvento === 'function'){
    const ok = vsAvvento(v, { dopo: function(){
      const box = document.getElementById('wkVita'), fw = document.getElementById('wkFraseW');
      if (box) box.classList.add('via');
      setTimeout(function(){ if (box) box.remove(); if (fw){ fw.classList.remove('dopo'); fw.classList.add('su'); } const b = document.getElementById('wkBody'); if (b) b.scrollTop = 0; wkFineScrivi(); }, 380);
    } });
    if (ok) return;
  }
  const fw = document.getElementById('wkFraseW'); if (fw) fw.classList.remove('dopo');
  wkFineScrivi();
}
function wkPassoLettera(el){
  const base = (typeof CIT_MS === 'number') ? CIT_MS : 55;
  let fs = 26; try{ fs = parseFloat(getComputedStyle(el).fontSize) || 26; }catch(_){ }
  return Math.round(base * Math.max(1, fs / 19.5));
}
function wkFineScrivi(){
  const h = document.getElementById('wkFineFrase'), dopo = document.getElementById('wkFineDopo'), aut = document.getElementById('wkFineAut');
  if (!h) return;
  wkMostraAgente();
  const tok = ++WK_TW, fr = wkFraseSettimana(), t = '"' + fr.t + '"';
  let i = 0;
  if (aut) aut.classList.remove('su');
  /* 0.9.291, Andrea: "le righe sopra continuano a cambiare larghezza mentre la frase si scrive, nella frase del giorno no".
     Il titolo ha text-wrap:balance: a ogni lettera nuova il browser ribilanciava TUTTE le righe sul testo scritto fin li'.
     Come nella frase del giorno (una lettera alla volta, mai il testo riscritto) e in piu' la frase intera e' gia' al suo
     posto, trasparente: le righe si decidono una volta sola, sul testo finito, e le lettere si accendono dentro. Il
     cursore e' disegnato sopra all'ultima lettera accesa, fuori dal flusso: non sposta niente. */
  const chars = Array.from(t);
  h.innerHTML = chars.map(function(c){ return '<span class="wk-c">' + (c === '<' ? '&lt;' : c === '&' ? '&amp;' : c) + '</span>'; }).join('');
  const spans = h.querySelectorAll('.wk-c');
  /* 0.9.292, Andrea: "nell'ultima slide non si sente la macchina da scrivere, che invece si sente con Scopri di piu'
     della frase del giorno". Lo stesso suono (interrupt.js, itTypeSound), acceso mentre le lettere arrivano. */
  try{ if (typeof itTypeSound === 'function') itTypeSound(true); }catch(_){ }
  const zitto = function(){ try{ if (typeof itTypeSound === 'function') itTypeSound(false); }catch(_){ } };
  (function passo(){
    if (tok !== WK_TW || !document.getElementById('wkFineFrase')){ zitto(); return; }
    if (i > 0) spans[i - 1].classList.remove('cur');
    spans[i].classList.add('on', 'cur');
    i++;
    /* 0.9.263, Andrea: la stessa velocita' della frase del giorno (55 ms a lettera).
       0.9.290: "va piu' veloce di quella di Dream". Il tempo per lettera era lo stesso, ma qui le lettere sono grandi 26 px
       contro i 19,5 della frase del giorno: il cursore percorreva lo schermo un terzo piu' in fretta. Il passo si allunga
       con la grandezza del carattere, cosi' la riga cresce alla stessa velocita' che si vede in Dream. */
    if (i < chars.length){ setTimeout(passo, wkPassoLettera(h)); return; }
    zitto();
    setTimeout(function(){
      if (tok !== WK_TW) return;
      const cur = h.querySelector('.wk-c.cur'); if (cur) cur.classList.remove('cur');
      if (aut && fr.a) aut.classList.add('su');
      setTimeout(function(){ if (tok === WK_TW && dopo) dopo.classList.add('su'); }, fr.a ? 650 : 0);
    }, 600);
  })();
}

/* ---- l'agente: una conversazione NUOVA, con i numeri della settimana gia' scritti ---- */
function wkTestoAgente(d){
  const L = [];
  const pct = d.veglia ? Math.min(100, Math.round(d.totale / d.veglia * 100)) : 0;
  L.push('Questi sono i numeri della mia settimana, ' + wkRangeTesto() + ':');
  L.push('- tempo al telefono: in media ' + wkLungo(d.media) + ' al giorno' + (d.mediaPrima ? ' (la settimana prima erano ' + wkLungo(d.mediaPrima) + ' al giorno)' : ''));
  if (d.totale) L.push('- in tutta la settimana ' + wkLungo(d.totale) + ' davanti allo schermo, il ' + pct + '% delle mie ore di veglia');
  if (d.apps.length) L.push('- le app che mi hanno preso più tempo: ' + d.apps.slice(0, 3).map(function(a){ return a.label + ' (' + wkLungo(a.ms) + ' in sette giorni)'; }).join(', '));
  if (d.ore.some(function(v){ return v > 0; })){ const h = wkOraPeggiore(d.ore); L.push('- l\'ora più difficile: dalle ' + h + ' alle ' + ((h + 1) % 24) + ', con ' + wkLungo(d.ore[h]) + ' di telefono in sette giorni'); }
  if (d.lunga) L.push('- la sessione più lunga: ' + wkLungo(d.lunga.ms) + ' di fila su ' + d.lunga.label);
  const p = wkPause();
  L.push('- blocchi fermati a metà: ' + (p.n === 1 ? 'una volta' : p.n + ' volte'));
  L.push('');
  L.push('Dammi consigli concreti per la settimana che comincia, per non ripetere gli stessi errori: cosa cambiare, in quali ore, e quali regole mettere nell\'app.');
  return L.join('\n');
}
async function wkHaAgente(){
  if (!wkPremium() || typeof agNuovaConversazione !== 'function') return false;
  try{ const a = (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.googleAccount) ? await NATIVE.googleAccount() : null; return !!(a && a.signedIn); }catch(_){ return false; }
}
function wkMostraAgente(){
  wkHaAgente().then(function(si){ const b = document.getElementById('wkAgBtn'); if (b) b.hidden = !si; });
}
async function wkChiediAgente(){
  if (!wkPremium()){ wkUpsell(); return; }
  if (typeof agNuovaConversazione !== 'function'){ if (typeof toast === 'function') toast('Il tuo agente personale arriva con l\'app aggiornata'); return; }
  const testo = wkTestoAgente(await wkRaccogli());
  wkClose();
  try{ await agNuovaConversazione(testo, { titolo: 'La mia settimana' }); }catch(_){ }
}
/* Senza Premium: la pagina di Premium sopra al report, e chiusa quella si torna qui. */
let WK_RIDIPINGI = false;
function wkUpsell(){
  if (typeof pwUpsellApri !== 'function'){ if (typeof go === 'function') go(11); return; }
  wkNascondi();
  WK_RIDIPINGI = true;
  pwUpsellApri(function(){
    setTimeout(function(){
      const a = document.querySelector('.screen.active');
      if (WK_TORNA && (!a || a.id === WK_DA)) wkMostra();
    }, 150);
  });
}

/* ---- la card da condividere: la stessa in pagina e nell'immagine ---- */
function wkRange(){
  const t = wkRangeTesto();
  return t.charAt(0).toUpperCase() + t.slice(1) + ' ' + wkFinestra().ieri.getFullYear();
}
function wkCardDati(d){
  const delta = d.mediaPrima ? Math.round((d.media - d.mediaPrima) / d.mediaPrima * 100) : null;
  const blocchi = d.giorni.reduce(function(a, g){ return a + (g.blocchi || 0); }, 0);
  const ieri = d.giorni[d.giorni.length - 1], prima = d.giorni[d.giorni.length - 2];
  return { delta: delta === null ? null : Math.max(-99, Math.min(999, delta)), blocchi: blocchi, cambio: (ieri && prima) ? ieri.ms - prima.ms : 0 };
}
function wkCardHtml(d){
  const c = wkCardDati(d);
  const max = Math.max.apply(null, d.giorni.map(function(x){ return x.ms; }).concat([1]));
  const barre = d.giorni.map(function(x){
    const h = Math.max(4, Math.round(x.ms / max * 90)), dis = x.ms ? Math.round(Math.min(1, (x.dis || 0) / x.ms) * h) : 0;
    return '<div class="wkc-b"><span style="height:' + h + 'px"><i style="height:' + dis + 'px"></i></span><small>' + wkGG(x.data) + '</small><u>' + (x.ms ? wkH(x.ms) : '') + '</u></div>';
  }).join('');
  return '<p class="wkc-top"><b>🧭 The Dream Map</b><span>' + esc(wkRange()) + '</span></p>'
    + '<b class="wkc-big">' + wkH(d.media) + '</b><p class="wkc-sub">al giorno sullo schermo</p>'
    + (c.delta ? '<p class="wkc-d ' + (c.delta > 0 ? 'su' : 'giu') + '">' + wkSvg(c.delta > 0 ? WK_IC.su : WK_IC.giu, 'wk-tr', 2.6) + Math.abs(c.delta) + '% ' + (c.delta > 0 ? 'in più' : 'in meno') + ' della settimana prima</p>' : '')
    + '<div class="wkc-bars">' + barre + '</div>'
    + '<p class="wkc-leg"><i class="dis"></i>Distrazioni <i></i>Il resto</p>'
    + '<div class="wkc-foot"><div><b>🛡️ ' + c.blocchi + '×</b><small>Distrazioni fermate</small></div><div><b>' + (c.cambio > 0 ? '+' : '−') + wkH(Math.abs(c.cambio)) + '</b><small>Ieri rispetto al giorno prima</small></div></div>';
}
async function wkCondividi(){
  const d = await wkRaccogli();
  const c = wkCardDati(d);
  const W = 1080, H = 1350;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const x = cv.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0B2A6B'); g.addColorStop(1, '#040B1F');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.textAlign = 'left'; x.fillStyle = '#8CC6FF'; x.font = '800 40px Montserrat, sans-serif'; x.fillText('The Dream Map', 90, 130);
  x.fillStyle = 'rgba(255,255,255,.7)'; x.font = '500 30px Poppins, sans-serif'; x.fillText(wkRange(), 90, 180);
  x.textAlign = 'center'; x.fillStyle = '#fff'; x.font = '900 150px Montserrat, sans-serif'; x.fillText(wkH(d.media), W / 2, 380);
  x.fillStyle = 'rgba(255,255,255,.8)'; x.font = '500 36px Poppins, sans-serif'; x.fillText('al giorno sullo schermo', W / 2, 440);
  if (c.delta){ x.fillStyle = c.delta > 0 ? '#FF8A9B' : '#8CF0C8'; x.font = '700 34px Poppins, sans-serif'; x.fillText(Math.abs(c.delta) + '% ' + (c.delta > 0 ? 'in più' : 'in meno') + ' della settimana prima', W / 2, 500); }
  const max = Math.max.apply(null, d.giorni.map(function(q){ return q.ms; }).concat([1]));
  const bw = 90, gap = 42, x0 = (W - (7 * bw + 6 * gap)) / 2, base = 960;
  d.giorni.forEach(function(q, j){
    const h = Math.max(8, Math.round(q.ms / max * 340)), dis = q.ms ? Math.round(Math.min(1, (q.dis || 0) / q.ms) * h) : 0;
    const bx = x0 + j * (bw + gap);
    x.fillStyle = '#3F9FF4'; x.fillRect(bx, base - h, bw, h);
    x.fillStyle = '#E63946'; x.fillRect(bx, base - h, bw, dis);
    x.fillStyle = 'rgba(255,255,255,.75)'; x.font = '600 28px Poppins, sans-serif'; x.fillText(wkGG(q.data), bx + bw / 2, base + 44);
    x.fillStyle = 'rgba(255,255,255,.5)'; x.font = '500 22px Poppins, sans-serif'; x.fillText(q.ms ? wkH(q.ms) : '', bx + bw / 2, base + 78);
  });
  x.fillStyle = '#fff'; x.font = '800 52px Montserrat, sans-serif';
  x.fillText('🛡️ ' + c.blocchi + '×', W / 4 + 30, 1170); x.fillText((c.cambio > 0 ? '+' : '−') + wkH(Math.abs(c.cambio)), W * 3 / 4 - 30, 1170);
  x.fillStyle = 'rgba(255,255,255,.7)'; x.font = '500 28px Poppins, sans-serif';
  x.fillText('Distrazioni fermate', W / 4 + 30, 1218); x.fillText('Ieri rispetto al giorno prima', W * 3 / 4 - 30, 1218);
  x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '500 26px Poppins, sans-serif'; x.fillText('dream-brothers.com', W / 2, 1300);
  let data; try{ data = cv.toDataURL('image/png'); }catch(_){ toast('Non riesco a comporre l\'immagine'); return; }
  const testo = 'La mia settimana su The Dream Map: ' + wkH(d.media) + ' al giorno sullo schermo' + (c.delta ? ', ' + Math.abs(c.delta) + '% ' + (c.delta > 0 ? 'in più' : 'in meno') + ' della settimana prima' : '') + '.';
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareImage){ await NATIVE.shareImage({ base64: data, title: 'La mia settimana', text: testo }); return; }
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'La mia settimana' }); return; }
    await navigator.clipboard.writeText(testo); toast('Copiato');
  }catch(_){ }
}
function wkNiente(){
  wkNascondi();
  if (typeof goId === 'function') goId('s-settings');
  setTimeout(function(){ const r = document.getElementById('stNoPause'); if (r) r.scrollIntoView({ block: 'center' }); }, 350);
}
function wkSevera(){
  wkNascondi();
  if (typeof svpApri === 'function') svpApri(); else if (typeof switchTab === 'function') switchTab('severa');
}

function wkPercheApri(b){ const t = b.nextElementSibling; if (t) t.hidden = !t.hidden; b.classList.toggle('on', !!(t && !t.hidden)); }
function wkHead(occhiello, titolo){
  return '<p class="wk-eyebrow">' + esc(occhiello) + '</p><h3 class="wk-h">' + esc(titolo) + '</h3>';
}

/* L'anello: la traccia gialla sono le ore di veglia, l'arco azzurro la parte andata allo schermo. */
function wkAnello(pct, tel, sveglio){
  /* 0.9.257: come AppBlock. Anello grande, arco azzurro dalle 12 in senso orario, il resto grigio;
     DENTRO al cerchio le due voci: il telefono in alto a destra (azzurro), il sole in basso a
     sinistra (grigio). Niente percentuale al centro: sta nella frase sotto. */
  const r = 86, c = 2 * Math.PI * r;
  return '<div class="wk-anello"><svg viewBox="0 0 200 200" aria-hidden="true">'
    + '<circle cx="100" cy="100" r="' + r + '" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="22"/>'
    + '<circle cx="100" cy="100" r="' + r + '" fill="none" stroke="#4FB8FF" stroke-width="22"'
    +   ' stroke-linecap="butt" stroke-dasharray="' + (c * pct / 100).toFixed(1) + ' ' + c.toFixed(1) + '"'
    +   ' transform="rotate(-90 100 100)"/>'
    + '</svg>'
    + '<div class="wk-anello-in">'
    +   '<span class="wk-an-tel">' + wkSvg(WK_IC.tel, 'wk-an-i', 2.2) + esc(tel || '') + '</span>'
    +   '<span class="wk-an-sole">' + wkSvg(WK_IC.sole, 'wk-an-i', 2.2) + esc(sveglio || '') + '</span>'
    + '</div></div>';
}

/* ---------------------------------------------------------------------------------------
   Le frecce: quello che il report non faceva
   --------------------------------------------------------------------------------------- */

/**
 * La conferma, e la porta per andarci.
 *
 * <p>Un messaggio a scomparsa non basta qui: chi preme quel pulsante chiede una REGOLA, e
 * vuole vederla. La conferma prende il posto del pulsante — che ha gia' fatto il suo lavoro e
 * ripremerlo creerebbe un doppione — e porta con se' la strada per aprire quella regola.</p>
 */
function wkConferma(testo, da){
  wkPronteVia();                                 /* una regola nuova: le slide preparate prima non la conoscono */
  const box = document.getElementById('wkEsito');
  /* il riquadro di un'app piccola si spunta e basta: il pulsante grande resta per la prima */
  if (da && da.classList && da.classList.contains('wk-app')){
    da.classList.add('fatto');
    const b = da.querySelector('.wk-piu'); if (b) b.innerHTML = wkSvg(WK_IC.ok, 'wk-svg', 3);
  }
  if (!box){ if (typeof toast === 'function') toast(testo); return; }
  const btn = (da && da.classList && da.classList.contains('wk-do')) ? da : box.previousElementSibling;
  if (btn && btn.classList && btn.classList.contains('wk-do') && !(da && da.classList && da.classList.contains('wk-app'))) btn.hidden = true;
  box.innerHTML = '<p class="wk-ok">' + wkSvg(WK_IC.ok, 'wk-ok-i', 2.8) + esc(testo) + '</p>'
    + '<button type="button" class="wk-vedi" onclick="wkVaiAllaRegola()">Aprila nella pagina Blocco' + WK_CHEV + '</button>';
}

/**
 * Apre PROPRIO quella regola, e poi si torna qui.
 *
 * <p>Prima chiudeva il report e portava alla scheda Blocco: chi tornava indietro era fuori
 * dal percorso della settimana, e la regola andava cercata a mano. Adesso si apre solo
 * l'editor di quel programma (quello appena creato, o quello che conteneva gia' l'app) e il
 * report resta in attesa, nascosto: appena si esce dall'editor, con la freccia o con il tasto
 * indietro del telefono, ricompare sulla stessa schermata.</p>
 */
let WK_REGOLA = -1, WK_TORNA = false;
function wkVaiAllaRegola(){
  const i = WK_REGOLA >= 0 ? WK_REGOLA : ((typeof PROGRAMS !== 'undefined' && PROGRAMS) ? PROGRAMS.length - 1 : -1);
  if (i < 0 || typeof editProgram !== 'function'){ wkClose(); if (typeof blPaginaApri === 'function') blPaginaApri(); return; }
  wkNascondi();
  try{ editProgram(i); }catch(_){ wkMostra(); }
}
/* il report torna quando si rientra nella schermata da cui era stato aperto (di solito la home):
   le pagine aperte da li' (editor, impostazioni e le loro sottopagine) non lo richiamano */
let WK_DA = 's-home';
function wkNascondi(){
  const b = document.getElementById('wkWrap');
  const a = document.querySelector('.screen.active');
  WK_DA = (a && a.id) || 's-home';
  if (b){ b.hidden = true; WK_TORNA = true; }
}
function wkMostra(){
  const b = document.getElementById('wkWrap'); if (b){ b.hidden = false; } WK_TORNA = false;
  /* tornando dalla pagina di Premium il bollino potrebbe non servire piu' */
  if (WK_RIDIPINGI){ WK_RIDIPINGI = false; wkPronteVia(); wkPaint(); }
}
/* si esce dall'editor (o dalla pagina aperta dal report): il report torna davanti */
document.addEventListener('fl:screen', function(e){
  if (!WK_TORNA) return;
  const id = e && e.detail;
  if (id !== WK_DA) return;
  setTimeout(wkMostra, 60);
});
/* il tasto indietro del telefono, dentro al report: una schermata indietro, alla prima si chiude */
function wkBack(){
  const b = document.getElementById('wkWrap');
  if (!b || b.hidden) return false;
  if (WK_I > 0) wkGo(-1); else wkClose();
  return true;
}

/**
 * Blocca l'app, davvero.
 *
 * <p>Prima passava dal Blocco rapido chiamando <c>saveQuick()</c>, che è la funzione di
 * SALVATAGGIO DI UNA SCHERMATA: si aspetta la pagina del Blocco rapido aperta davanti,
 * legge i suoi campi, e se non trova niente da salvare esce in silenzio. Chiamata da dentro
 * a un funnel a schermo intero non aveva niente da leggere, e infatti non succedeva niente —
 * il pulsante era vivo, la strada dietro non c'era.</p>
 *
 * <p>Adesso crea un programma, che è la stessa strada già usata dalle altre due frecce di
 * questo funnel e funziona senza nessuna schermata aperta. Un limite di quindici minuti al
 * giorno invece del blocco totale: è la cosa che si accetta di tenere, e una regola che non
 * si toglie dopo due giorni vale più di una che si toglie subito.</p>
 */
async function wkBlocca(pkg, label, da){
  try{
    if (typeof PROGRAMS === 'undefined' || typeof pushRules !== 'function'){
      toast('Disponibile nell\'app installata');
      return;
    }
    /* Se un limite per questa app c'è già, non se ne fa un secondo: due regole sulla stessa
       app sono il modo più rapido di non capire più perché una cosa è bloccata. */
    const gia = PROGRAMS.findIndex(function(p){
      return p && Array.isArray(p.apps) && p.apps.indexOf(pkg) >= 0;
    });
    if (gia >= 0){ WK_REGOLA = gia; wkConferma(label + ' è già dentro a un programma.', da); return; }
    WK_REGOLA = -1;

    PROGRAMS.push({
      id: 'p' + Date.now().toString(36),
      name: label,
      type: 'limit', icon: '⏳',
      from: '00:00', to: '23:59',
      days: [true, true, true, true, true, true, true],
      allDay: true,
      qd: 15,
      apps: [pkg], sites: [], keywords: [], allow: [],
      blockLaunch: true, blockNotifications: false, on: true
    });
    WK_REGOLA = PROGRAMS.length - 1;
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    await pushRules();
    if (typeof syncNative === 'function') syncNative();
    wkConferma(label + ': 15 minuti al giorno, da adesso.', da);
  }catch(_){ toast('Non sono riuscito a creare il blocco'); }
}

/** Crea il programma per la fascia oraria peggiore, già scritto e già acceso. */
async function wkProgramma(h){
  try{
    if (typeof PROGRAMS === 'undefined' || typeof pushRules !== 'function'){
      toast('Disponibile nell\'app installata');
      return;
    }
    const da = String(h).padStart(2, '0') + ':00';
    /* la stessa fascia della schermata: un'ora. Prima ne proteggeva due e ne mostrava una. */
    const a = String((h + 1) % 24).padStart(2, '0') + ':00';
    const d = await wkRaccogli();
    PROGRAMS.push({
      id: 'p' + Date.now().toString(36),
      name: 'La mia ora difficile · ' + da,
      type: 'schedule', icon: '⏰',
      from: da, to: a,
      days: [true, true, true, true, true, true, true],
      allDay: false,
      apps: d.apps.slice(0, 3).map(function(x){ return x.pkg; }),
      sites: (typeof DISTRACTIONS !== 'undefined' ? DISTRACTIONS.slice() : []),
      keywords: [], allow: [],
      blockLaunch: true, blockNotifications: true, on: true
    });
    WK_REGOLA = PROGRAMS.length - 1;
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    await pushRules();
    if (typeof syncNative === 'function') syncNative();
    wkConferma('Programma creato: dalle ' + da + ' alle ' + a + ', tutti i giorni.');
  }catch(_){ toast('Non sono riuscito a creare il programma'); }
}

/** Il limite giornaliero sull'app che ti tiene più a lungo. */
async function wkLimite(pkg, label){
  try{
    if (typeof PROGRAMS === 'undefined' || typeof pushRules !== 'function'){
      toast('Disponibile nell\'app installata');
      return;
    }
    PROGRAMS.push({
      id: 'p' + Date.now().toString(36),
      name: 'Limite · ' + label,
      type: 'limit', icon: '⏳',
      from: '00:00', to: '23:59',
      days: [true, true, true, true, true, true, true],
      allDay: true,
      qd: 15,
      apps: [pkg], sites: [], keywords: [], allow: [],
      blockLaunch: true, blockNotifications: false, on: true
    });
    WK_REGOLA = PROGRAMS.length - 1;
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    await pushRules();
    if (typeof syncNative === 'function') syncNative();
    wkConferma('Limite creato: ' + label + ', 15 minuti al giorno.');
  }catch(_){ toast('Non sono riuscito a creare il limite'); }
}

/* ---------------------------------------------------------------------------------------
   Il contenitore
   --------------------------------------------------------------------------------------- */

function wkOpen(i, daCartello){
  WK_I = i || 0;
  WK_NUOVA = !!daCartello;
  WK_TORNA = false; WK_REGOLA = -1;
  wkPronteVia();                                 /* ogni apertura riparte dalle regole di adesso */
  try{ wkFrasiCarica(); }catch(_){ }
  let box = document.getElementById('wkWrap');
  if (!box){
    box = document.createElement('div');
    box.id = 'wkWrap';
    box.className = 'wk';
    wkTocchi(box);
    document.body.appendChild(box);
  }
  wkSegna();
  wkPaint();
}

function wkClose(){
  const b = document.getElementById('wkWrap');
  if (b) b.remove();
  WK_TORNA = false;   /* i dati restano: alla prossima apertura il report e' gia' pronto */
}

/* daGesto: arriva da un tocco o da uno scorrimento. Alla fine non si esce con un tocco
   distratto: dall'ultima schermata si esce solo scegliendo una delle due strade. */
function wkGo(d, daGesto){
  const n = WK_I + d;
  if (n < 0) return;
  if (n >= 2) wkSegnaLetto();
  if (n >= wkN()){
    if (daGesto) return;
    wkClose();
    /* Alla fine si atterra sul report vero: chi vuole i numeri esatti li trova, dopo aver
       visto cosa ne esce. */
    if (typeof switchTab === 'function') switchTab('insights');
    return;
  }
  WK_I = n;
  wkPaint();
}

/**
 * Come le storie di Instagram (e il report di AppBlock).
 *
 * <p>Un tocco sul terzo sinistro torna indietro, sui due terzi a destra va avanti; uno
 * scorrimento orizzontale fa lo stesso (verso sinistra avanti, verso destra indietro). I
 * pulsanti dentro alle schermate restano pulsanti: un tocco li' non sfoglia niente. Il
 * pulsante Avanti in fondo resta, per chi non sa dei tocchi.</p>
 */
function wkTocchi(box){
  let p0 = null;
  const suPulsante = function(t){ return !!(t && t.closest && t.closest('button, a, input, textarea, select, label, [onclick], .wk-top, .wk-vita')); };
  box.addEventListener('pointerdown', function(e){
    p0 = suPulsante(e.target) ? null : { x: e.clientX, y: e.clientY, t: Date.now() };
  });
  box.addEventListener('pointercancel', function(){ p0 = null; });
  box.addEventListener('pointerup', function(e){
    if (!p0) return;
    const s = p0; p0 = null;
    if (suPulsante(e.target)) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.3){ wkGo(dx < 0 ? 1 : -1, true); return; }
    if (Math.abs(dx) < 12 && Math.abs(dy) < 12 && Date.now() - s.t < 700){
      const r = box.getBoundingClientRect();
      wkGo((e.clientX - r.left) < r.width / 3 ? -1 : 1, true);
    }
  });
}

let WK_TOK = 0;
/* 0.9.310, Andrea: "ogni slide mostra gli elementi uno alla volta troppo lentamente, e fra una slide e l'altra resta
   lo schermo nero troppo a lungo". LE CAUSE VERE (misurate, wk310misura.mjs):
   1. ogni pezzo della slide entrava 0,6 s dopo quello prima, e ci metteva 0,55 s: una slide di 6 pezzi era composta
      dopo 3,4 s, quella delle app che distraggono (10 pezzi) dopo 6 s. Il titolo e il numero grande, cioe' quello che
      si legge, arrivavano dopo un secondo e piu' di schermo blu notte con il solo occhiello grigio: il "nero";
   2. la slide si costruiva solo DOPO il tocco: dati, e per "I ladri di tempo" e "Tutto d'un fiato" le icone chieste al
      motore UNA DOPO L'ALTRA (sei viaggi al ponte nativo), e intanto restava la slide di prima;
   3. quando i numeri arrivavano a copertina aperta, la copertina si ridisegnava da capo (e ripartiva l'entrata).
   ADESSO: le slide si preparano in anticipo (WK_PRONTE: la successiva e la precedente dopo ogni disegno, tutte appena
   ci sono i numeri) e al tocco si disegnano subito, senza attese; i pezzi entrano con una dissolvenza di 0,32 s
   sfalsata di 60-110 ms, cosi' la slide e' composta in 0,6-0,8 s qualunque sia il numero dei pezzi. */
const WK_PRONTE = {};                 // indice -> { k: tipo, d: i numeri con cui e' fatta, html }
let WK_PREP_GIRO = 0;
function wkPronteVia(){ for (const k in WK_PRONTE) delete WK_PRONTE[k]; WK_PREP_GIRO++; }
function wkPronta(i){
  const p = WK_PRONTE[i], k = wkElenco()[i];
  return (p && p.k === k && p.d === WK_DATI) ? p.html : null;
}
async function wkPrepara(i){
  if (i < 0 || i >= wkN() || wkPronta(i) !== null) return;
  const giro = WK_PREP_GIRO, d = WK_DATI, k = wkElenco()[i];
  if (!d && k !== 'cover') return;
  let html = null;
  try{ html = await wkSlide(i); }catch(_){ html = null; }
  /* scartata se intanto sono cambiati i numeri, l'elenco o una regola (un'app appena bloccata) */
  if (html === null || giro !== WK_PREP_GIRO || d !== WK_DATI || wkElenco()[i] !== k) return;
  WK_PRONTE[i] = { k: k, d: d, html: html };
}
/** Prepara le slide vicine a quella aperta, poi tutte le altre, una alla volta e dietro le quinte. */
async function wkPreparaVicine(){
  const da = WK_I;
  await wkPrepara(da + 1);
  await wkPrepara(da - 1);
  for (let i = 0; i < wkN(); i++){ if (!document.getElementById('wkWrap')) return; await wkPrepara(i); }
}
function wkProgHtml(n){
  return Array.from({ length: n }, function(_, k){ return '<i class="' + (k <= WK_I ? 'on' : '') + '"></i>'; }).join('');
}
async function wkPaint(){
  const box = document.getElementById('wkWrap');
  if (!box) return;
  const tok = ++WK_TOK;
  const x = '<button type="button" class="wk-x" onclick="wkClose()" aria-label="Chiudi">' + wkSvg(WK_IC.x, 'wk-x-i', 2.4) + '</button>';
  /* 0.9.257, Andrea: niente attesa a schermo. La copertina non ha bisogno dei numeri: si disegna
     subito, e i sette giorni si mettono in fila dietro (di solito sono gia' pronti: wkMementoApri
     e il cartello li chiedono prima). */
  if (!WK_DATI && WK_I > 0){
    box.innerHTML = '<div class="wk-top">' + x + '<div class="wk-prog"></div></div><div class="wk-body"><div class="wk-in"></div></div>';
    await wkRaccogli();
    if (tok !== WK_TOK || !document.getElementById('wkWrap')) return;
  }
  /* i numeri arrivano a copertina aperta: la copertina non li usa, si aggiorna solo la barra in alto (prima si
     ridisegnava tutta, e l'entrata ripartiva da capo) e si preparano le slide */
  if (!WK_DATI) wkRaccogli().then(function(){
    if (tok !== WK_TOK) return;
    const pr = document.querySelector('#wkWrap .wk-prog'); if (pr) pr.innerHTML = wkProgHtml(wkN());
    wkPreparaVicine();
  });
  const n = wkN();
  if (WK_I >= n) WK_I = n - 1;
  /* la slide gia' pronta si disegna SUBITO, nello stesso giro del tocco; se non c'e', si fa adesso */
  let html = wkPronta(WK_I);
  if (html === null){
    html = await wkSlide(WK_I);
    if (tok !== WK_TOK || !document.getElementById('wkWrap')) return;
  }
  const fine = wkElenco()[WK_I] === 'fine';
  /* UN SOLO CONTENITORE CENTRATO. Il centraggio con i margini automatici sul primo e
     sull'ultimo figlio si rompeva quando l'ultimo era il riquadro della conferma ancora
     vuoto (display:none: il suo margine non conta), e la schermata cadeva in fondo, sopra
     al pulsante Avanti ("Tutto d'un fiato"). Adesso tutto sta in .wk-in, che si centra da
     solo fra la barra in alto e il pulsante in basso. */
  box.innerHTML = '<div class="wk-top">' + x
    + '<div class="wk-prog">' + wkProgHtml(n) + '</div></div>'
    /* 0.9.256, Andrea: Avanti non galleggia sopra al testo: sta in fondo alla schermata, dopo tutto, staccato */
    + '<div class="wk-body" id="wkBody"><div class="wk-in">' + html + '</div>' + (fine ? '' : '<button type="button" class="wk-tap" onclick="wkGo(1)">Tocca per continuare</button>') + '</div>';
  /* 0.9.259, Andrea: un elemento alla volta, come le bolle della missione: ogni pezzo della schermata entra
     dopo quello prima (One Element One Focus), non tutto insieme. */
  /* 0.9.262, Andrea: anche dentro a un riquadro (il confronto fra le due settimane) un pezzo alla volta: prima la
     settimana prima, poi questa, poi la frase. */
  /* 0.9.310: sempre un pezzo alla volta, ma veloce. Il passo si adatta al numero dei pezzi visibili (i riquadri vuoti,
     come la conferma che non c'e' ancora, non contano): fra 60 e 110 ms, e l'ultimo pezzo e' a posto entro 0,8 s. */
  try{
    const pezzi = [];
    Array.prototype.forEach.call(box.querySelectorAll('.wk-in > *'), function(el){
      if (el.classList.contains('wk-uno-dentro')){ Array.prototype.forEach.call(el.children, function(f){ pezzi.push(f); }); return; }
      if (el.classList.contains('wk-esito') && !el.innerHTML) return;
      pezzi.push(el);
    });
    const passo = pezzi.length > 1 ? Math.max(0.06, Math.min(0.11, (0.78 - 0.32) / (pezzi.length - 1))) : 0;
    box.style.setProperty('--wk-passo', passo.toFixed(3) + 's');
    pezzi.forEach(function(el, k){ el.style.setProperty('--i', String(k)); el.classList.add('wk-uno'); });
  }catch(_){ }
  if (fine) wkFineAvvia();
  /* la prossima (e la precedente) si preparano adesso, mentre questa entra */
  if (WK_DATI) setTimeout(function(){ if (tok === WK_TOK) wkPreparaVicine(); }, 60);
}

(function wkStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.wk{position:fixed;inset:0;z-index:9998;background:linear-gradient(180deg,#00132B,#000)',
      ';color:#fff;display:flex;flex-direction:column;padding:calc(env(safe-area-inset-top,0px) + 14px) 22px',
      ' calc(env(safe-area-inset-bottom,0px) + 18px);overflow:hidden;animation:wkIn .25s ease-out;',
      'touch-action:pan-y;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}',
    '@keyframes wkIn{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:none}}',
    '.wk-top{display:flex;align-items:center;gap:14px;flex:0 0 auto}',
    '.wk-x{width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.14);',
      'color:#fff;cursor:pointer;flex:none;display:flex;align-items:center;justify-content:center;padding:0}',
    '.wk-x-i{width:18px;height:18px}',
    '.wk-prog{flex:1;display:flex;gap:4px}',
    '.wk-prog i{flex:1;height:4px;border-radius:99px;background:rgba(255,255,255,.18)}',
    '.wk-prog i.on{background:#fff}',
    /* IL TESTO IN ALTO VENIVA TAGLIATO. Un contenitore che scorre e centra con justify-content
       taglia la parte che sborda in alto, e quella parte non si raggiunge scorrendo: su una
       schermata alta (le distrazioni) l'occhiello e mezzo titolo sparivano. I margini automatici
       centrano uguale quando c'e' spazio, e quando non c'e' partono dall'alto. */
    '.wk-body{flex:1;min-height:0;display:flex;flex-direction:column;overflow-y:auto;padding:14px 0 10px;scrollbar-width:none}',
    '.wk-body::-webkit-scrollbar{display:none}',
    '.wk-in{margin:auto 0;width:100%;display:flex;flex-direction:column;align-items:center;text-align:center;padding-bottom:10px}',
    '.wk-svg{width:100%;height:100%;display:block}',
    '.wk-tr{width:15px;height:15px;vertical-align:-2px;margin-right:4px}',
    '.wk-do-i{width:18px;height:18px;flex:none}',
    '.wk-share-i{flex:none}',
    /* la direzione: due righe, la settimana prima e questa, ognuna con la sua barra */
    '.wk-cmp{width:100%;max-width:330px;display:flex;flex-direction:column;gap:14px;margin-top:4px}',
    '.wk-cmp-r{display:grid;grid-template-columns:1fr auto;grid-template-areas:"et val" "bar bar";gap:6px 10px;text-align:left}',
    '.wk-cmp-r small{grid-area:et;font:600 12.5px var(--font-body);color:rgba(200,218,242,.75)}',
    '.wk-cmp-r b{grid-area:val;font:800 15px var(--font-display);color:#fff}.wk-cmp-r b em{font:500 11.5px var(--font-body);font-style:normal;color:rgba(200,218,242,.7)}',
    '.wk-cmp-r span{grid-area:bar;display:block;height:12px;border-radius:99px;background:rgba(255,255,255,.1);overflow:hidden}',
    '.wk-cmp-r span i{display:block;height:100%;border-radius:99px;background:rgba(200,218,242,.45);transform-origin:left center}',
    '.wk-cmp-r.wk-uno span i{animation:wkBarra .5s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i, 0) * var(--wk-passo, .1s) + .15s)}',
    '@keyframes wkBarra{from{transform:scaleX(0)}to{transform:scaleX(1)}}',
    '.wk-cmp-r.ora span i{background:#4FB8FF}.wk-cmp-r.ora.su span i{background:#E63946}.wk-cmp-r.ora.giu span i{background:#8CF0C8}',
    /* il conto: l'anello con le due parti, e sotto le due etichette */
    '.wk-anello{position:relative;width:272px;height:272px;margin:34px auto 0}',
    '.wk-anello-in{position:absolute;inset:0}.wk-an-tel,.wk-an-sole{position:absolute;display:inline-flex;align-items:center;gap:7px;font:800 17px var(--font-body);white-space:nowrap}',
    '.wk-an-tel{right:58px;top:100px;color:#4FB8FF}.wk-an-sole{left:58px;bottom:92px;color:rgba(200,218,242,.7)}.wk-an-tel,.wk-an-sole{font-size:15.5px}.wk-anello .wk-an-i{width:18px!important;height:18px!important;flex:none}',
    '.wk-anello > svg{width:100%;height:100%;display:block}',
    '.wk-anello-c{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}',
    '.wk-anello-c b{font:800 38px/1 var(--font-display);color:#fff}',
    '.wk-anello-c small{margin-top:6px;font:600 11.5px/1.3 var(--font-body);color:rgba(200,218,242,.75)}',
    '.wk-blu{color:#4FB8FF}.wk-line-giu{margin-top:44px}',
    /* 0.9.321, Andrea: "tutte le slide con la dissolvenza, come il report di AppBlock": solo opacita', una cosa alla volta, niente salti */
    '.wk-uno{animation:wkUno .7s ease-out both;animation-delay:calc(var(--i, 0) * var(--wk-passo, .28s))}@keyframes wkUno{from{opacity:0}to{opacity:1}}',
    '.wk-perche{display:inline-flex;align-items:center;gap:6px;margin:18px auto 0;padding:6px 10px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);cursor:pointer}.wk-perche svg{width:14px;height:14px;transition:transform .2s ease}.wk-perche.on svg{transform:rotate(90deg)}',
    '.wk-perche-t.wk-uno,.wk-perche-t{animation:none !important;opacity:1 !important}.wk-perche-t{margin:6px auto 0;max-width:30ch;font:500 14.5px/1.45 var(--font-body);color:rgba(200,218,242,.85);text-align:center}',
    '.wk-h-fine{margin-top:0;min-height:5.6em;font-size:26px;line-height:1.3;text-align:center}.wk-scelte-giu{margin-top:30px}',
    '.wk-h-fine{text-wrap:balance}.wk-tw-a{display:inline-block;font-size:.78em;color:rgba(200,218,242,.72);margin-bottom:10px}.wk-tw-b{display:block;text-wrap:balance}',
    '.wk-tw-cur{font-style:normal;font-weight:400;margin-left:2px;animation:wkCur .9s steps(1) infinite}@keyframes wkCur{50%{opacity:0}}',
    '.wk-c{opacity:0;position:relative}.wk-c.on{opacity:1}.wk-c.cur::after{content:"|";position:absolute;left:100%;top:0;margin-left:2px;font-weight:400;opacity:1;animation:wkCur .9s steps(1) infinite}',
    '.wk-fine-dopo{width:100%;display:flex;flex-direction:column;align-items:center;margin-top:26px;opacity:0;transform:translateY(14px);pointer-events:none;transition:opacity .6s ease,transform .6s cubic-bezier(.2,.8,.2,1)}.wk-fine-dopo.su{opacity:1;transform:none;pointer-events:auto}',
    '.wk-fine-dopo .wk-scelte{transition:opacity .5s ease .45s;opacity:0}.wk-fine-dopo.su .wk-scelte{opacity:1}',
    '.wk-genio.wk-genio-fermo{animation:none}',
    '.wk-tap{flex:0 0 auto;margin-top:auto;padding:46px 0 22px;border:0;background:none;text-align:center;font:700 11.5px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:rgba(200,218,242,.8);animation:obTap 1.6s ease-in-out infinite;cursor:pointer}',
    '@keyframes obTap{0%,100%{opacity:.45}50%{opacity:1}}',
    '.wk-anello-eti{display:flex;justify-content:center;gap:16px;margin-top:10px;font:700 12.5px var(--font-body);color:rgba(200,218,242,.8)}.wk-anello-eti .blu{color:#4FB8FF}',
    '.wk-next-in{width:100%;max-width:330px;margin:30px auto 8px}',
    '.wk-leg{display:flex;gap:12px;width:100%;max-width:330px;margin-top:18px}',
    '.wk-leg > div{flex:1;display:flex;flex-direction:column;align-items:center;background:rgba(255,255,255,.07);border-radius:16px;padding:12px 8px}',
    '.wk-leg-i{width:34px;height:34px;border-radius:50%;padding:7px;box-sizing:border-box;margin-bottom:6px}',
    '.wk-leg-i.tel{background:#4FB8FF;color:#0F2041}.wk-leg-i.sole{background:#FFD66B;color:#0F2041}',
    '.wk-leg b{font:800 20px var(--font-display);color:#fff}',
    '.wk-leg small{margin-top:2px;font:600 11.5px var(--font-body);color:rgba(200,218,242,.75)}',
    /* la chiusura: le due strade */
    '.wk-fine{width:100%;display:flex;flex-direction:column;align-items:center}',
    '.wk-vita{width:100%;transition:opacity .35s ease,transform .35s ease}.wk-vita.via{opacity:0;transform:translateY(-12px)}',
    '.wk-frase-w{width:100%;display:flex;flex-direction:column;align-items:center}.wk-frase-w.dopo{display:none}',
    '.wk-frase-w.su{animation:wkFraseSu .5s ease-out}@keyframes wkFraseSu{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}',
    '.wk-frase-kick{margin:0 0 14px;font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#7DBEFF}',
    '.wk-frase-aut{margin:-6px 0 0;font:italic 700 15px var(--font-body);color:rgba(200,218,242,.85);opacity:0;transform:translateY(6px);transition:opacity .5s,transform .5s}.wk-frase-aut.su{opacity:1;transform:none}',
    '.wk-scelte{width:100%;display:flex;flex-direction:column;gap:10px;margin-top:24px}',
    '.wk-ag{display:flex;align-items:center;gap:10px;width:100%;border:0;border-radius:18px;background:#0075E3;color:#fff;',
      'padding:14px 16px;font:800 14px/1.35 var(--font-body);text-align:left;cursor:pointer}',
    /* 0.9.267, Andrea: l'icona stava tutta a sinistra, lontana dal testo su due righe. Testo in linea, icona attaccata alla prima parola. */
    /* 0.9.276, Andrea: l'icona stava piu' in alto del testo. L'emoji della chat, a meta' altezza del testo (anche su due righe). */
    '.wk-ag{display:flex;align-items:center;justify-content:center;gap:10px;text-align:center}.wk-ag .wk-emo{flex:none;font-size:22px;line-height:1;font-style:normal}.wk-ag span{display:block;text-align:center;flex:0 1 auto;max-width:215px;text-wrap:balance}',
    '.wk-pill{flex:none;font:800 10.5px var(--font-body);font-style:normal;letter-spacing:.06em;text-transform:uppercase;',
      'background:#BCE0FF;color:#0F2041;border-radius:99px;padding:4px 9px}',
    '.wk-tutto{margin-top:0;width:100%}',
    '.wk[hidden]{display:none}',
    '.wk-genio{height:150px;width:auto;margin:0 auto 14px;display:block;animation:wkFloat 4s ease-in-out infinite}',
    '.wk-genio.wk-genio-s{height:110px}',
    '@keyframes wkFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}',
    '.wk-line-s{margin-top:10px}',
    '.wk-chev{width:8px;height:12px;margin-left:8px;vertical-align:-1px}',
    '.wk-vedi{display:inline-flex;align-items:center}',
    '.wk-tag{display:inline-block;margin:0 0 18px;padding:4px 10px;border:1.5px solid rgba(255,255,255,.55);border-radius:6px;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#fff}',
    '.wk-cap{margin:10px 0 0;font:800 18px var(--font-display);color:#fff}',
    '.wk-cap2{margin:4px 0 0;font:500 14px var(--font-body);color:rgba(200,218,242,.7)}',
    '.wk-big + .wk-cap2{margin-top:10px}',
    '.wk-nuova .wk-genio{height:180px}',
    '.wk-card{width:100%;max-width:330px;border-radius:26px;padding:20px 18px;background:linear-gradient(180deg,#0B2A6B,#040B1F);border:1px solid rgba(255,255,255,.1);text-align:center}',
    '.wkc-top{display:flex;flex-direction:column;align-items:flex-start;gap:2px;margin:0 0 12px;font:500 10.5px var(--font-body);color:rgba(255,255,255,.65);text-align:left}.wkc-top b{font:800 13px var(--font-display);color:#8CC6FF;white-space:nowrap}',
    '.wkc-big{display:block;font:900 40px/1 var(--font-display);color:#fff}.wkc-sub{margin:6px 0 0;font:500 12px var(--font-body);color:rgba(255,255,255,.75)}',
    '.wkc-d{margin:6px 0 0;font:700 11.5px var(--font-body)}.wkc-d.su{color:#FF8A9B}.wkc-d.giu{color:#8CF0C8}',
    '.wkc-bars{display:flex;align-items:flex-end;justify-content:center;gap:6px;margin-top:14px}',
    '.wkc-b{flex:1;display:flex;flex-direction:column;align-items:center}.wkc-b span{display:flex;flex-direction:column;width:100%;max-width:26px;border-radius:5px;background:#3F9FF4;overflow:hidden}.wkc-b span i{display:block;background:#E63946}',
    '.wkc-b small{margin-top:5px;font:700 9px var(--font-body);color:rgba(255,255,255,.7)}.wkc-b u{text-decoration:none;font:500 7.5px var(--font-body);color:rgba(255,255,255,.45)}',
    '.wkc-leg{margin:10px 0 0;font:500 9.5px var(--font-body);color:rgba(255,255,255,.6)}.wkc-leg i{display:inline-block;width:8px;height:8px;border-radius:2px;background:#3F9FF4;margin:0 4px 0 8px}.wkc-leg i.dis{background:#E63946;margin-left:0}',
    '.wkc-foot{display:flex;margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,.12)}.wkc-foot div{flex:1}.wkc-foot b{display:block;font:800 17px var(--font-display);color:#fff}.wkc-foot small{font:500 10px var(--font-body);color:rgba(255,255,255,.65)}',
    '.wk-share{margin-top:18px}',
    '.wk-eyebrow{font:700 11px var(--font-body);letter-spacing:.22em;text-transform:uppercase;',
      'color:rgba(200,218,242,.6);margin:0 0 14px}',
    '.wk-h{font:800 25px/1.3 var(--font-display);margin:0 0 22px;color:#fff;max-width:14em}',
    '.wk-big{display:block;font:800 44px/1 var(--font-display);color:var(--neo-soft,#4FB8FF)}',
    '.wk-big small{font-size:19px;color:rgba(200,218,242,.7)}',
    '.wk-big.su{color:#FF8A9B}.wk-big.giu{color:#8CF0C8}',
    '.wk-delta{font:700 13px var(--font-body);margin:12px 0 0}',
    '.wk-delta.su{color:#FF8A9B}.wk-delta.giu{color:#8CF0C8}',
    '.wk-line{font:500 14px/1.6 var(--font-body);color:rgba(200,218,242,.86);margin:18px 0 0;max-width:22em}',
    '.wk-line b{color:#fff;font-weight:800;white-space:nowrap}',
    '.wk-sub{font:700 13px var(--font-body);margin:26px 0 12px;color:#fff}',
    '.wk-hint{font:500 12px var(--font-body);color:rgba(200,218,242,.55);margin-top:16px}',
    '.wk-emoji{font-size:46px;margin:0 0 10px}',
    '.wk-cover{text-align:center}',
    '.wk-cover .wk-mark{font-size:40px;display:block;margin-bottom:18px}',
    '.wk-cover h2{font:800 40px/1.06 var(--font-display);margin:0 0 20px}',
    '.wk-cover p{font:500 14px/1.6 var(--font-body);color:rgba(200,218,242,.86);max-width:20em;margin:0 auto}',
    '.wk-range{display:block;margin-top:22px;font:800 15px var(--font-body);color:var(--neo-soft,#4FB8FF)}',
    '.wk-bars{display:flex;align-items:flex-end;justify-content:center;gap:7px;margin-top:40px;width:100%}',
    '.wk-bars + .wk-line{margin-top:40px}',
    '.wk-bars-pila{position:relative}',
    '.wk-bar i.wk-pila{display:flex;flex-direction:column;overflow:hidden;border-radius:8px 8px 4px 4px;background:rgba(200,218,242,.18)}',
    '.wk-pila b{display:block;min-height:0}',
    '.wk-media-linea{position:absolute;left:0;right:0;bottom:calc(var(--media) + 34px);border-top:2px dashed rgba(200,218,242,.55);pointer-events:none}',
    '.wk-legenda{display:flex;justify-content:center;gap:16px;margin-top:18px;font:600 12px var(--font-body);color:rgba(200,218,242,.85)}',
    '.wk-legenda span{display:inline-flex;align-items:center;gap:6px}.wk-legenda i{width:10px;height:10px;border-radius:50%;display:inline-block}',
    '.wk-legenda + .wk-line{margin-top:26px}',
    '.wk-bar{flex:1;max-width:38px;display:flex;flex-direction:column;align-items:center}',
    '.wk-bar i{display:block;width:100%;border-radius:6px 6px 2px 2px;background:var(--neo-soft,#4FB8FF)}',
    '.wk-bar small{margin-top:7px;font:700 10px var(--font-body);color:rgba(200,218,242,.7)}',
    '.wk-bar u{text-decoration:none;font:600 8.5px var(--font-body);color:rgba(200,218,242,.45)}',
    '.wk-hours{display:flex;align-items:flex-end;gap:2px;margin-top:22px;width:100%;height:124px}',
    /* tutte le ore in azzurro tenue, l'ora difficile in rosso pieno */
    '.wk-hours i{flex:1;border-radius:3px 3px 1px 1px;background:#4FB8FF;opacity:.4}',
    '.wk-hours i.on{background:#E63946;opacity:1}',
    '.wk-axis{position:relative;width:100%;height:16px;margin-top:6px;font:700 11px var(--font-body);color:rgba(200,218,242,.7)}',
    '.wk-axis span{position:absolute;top:0;transform:translateX(-50%)}',
    '.wk-app1{display:block;font:800 30px/1.2 var(--font-display);margin-top:12px}',
    '.wk-ico{display:block;margin:0 auto;border-radius:22%;object-fit:contain}',
    '.wk-ico + .wk-big{margin-top:14px}',
    '.wk-app .wk-ico{margin:0 auto 6px}',
    '.wk-ico-v{display:block;width:34px;height:34px;margin:0 auto 6px;border-radius:22%;background:rgba(255,255,255,.14)}',
    '.wk-do{margin-top:22px;border:0;border-radius:99px;background:#0075E3;color:#fff;display:inline-flex;align-items:center;gap:9px;white-space:nowrap;',
      'padding:14px 24px;font:800 14px var(--font-body);cursor:pointer}',
    '.wk-do[hidden]{display:none}',
    '.wk-esito:empty{display:none}',
    '.wk-esito{margin-top:20px;background:rgba(140,240,200,.12);border:1px solid rgba(140,240,200,.45);',
      'border-radius:18px;padding:16px}',
    '.wk-ok{margin:0;display:flex;align-items:flex-start;justify-content:center;gap:8px;font:700 13.5px/1.55 var(--font-body);color:#8CF0C8}',
    '.wk-ok-i{width:18px;height:18px;flex:none;margin-top:2px}',
    '.wk-vedi{margin-top:12px;border:0;border-radius:99px;background:#fff;color:#0E1B33;',
      'padding:11px 20px;font:800 12.5px var(--font-body);cursor:pointer}',
    '.wk-apps{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}',
    '.wk-app{position:relative;border:0;background:rgba(255,255,255,.08);border-radius:16px;padding:12px 10px;',
      'min-width:84px;cursor:pointer;color:#fff}',
    /* il "+" dice cosa fa il tocco: aggiungere l'app al blocco. Fatto, diventa una spunta. */
    '.wk-piu{position:absolute;top:-7px;right:-7px;width:24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;',
      'padding:5px;box-sizing:border-box;box-shadow:0 0 0 2px #0A1C3A}',
    '.wk-app.fatto .wk-piu{background:#8CF0C8;color:#0F2041}',
    '.wk-app b{display:block;font:800 17px var(--font-body);color:var(--neo-soft,#4FB8FF)}',
    '.wk-app small{display:block;margin-top:5px;font:600 10.5px var(--font-body);color:#fff}',
    '.wk-app u{display:block;text-decoration:none;font:500 10px var(--font-body);color:rgba(200,218,242,.6)}',
    '.wk-next{flex:0 0 auto;margin-top:12px;border:0;border-radius:99px;background:#fff;color:#0E1B33;',
      'padding:15px 20px;font:800 14.5px var(--font-body);cursor:pointer}',

    /* Il cartello che apre tutto: piccolo, con una porta sola. */
    '.wkp{position:fixed;inset:0;z-index:9997;background:rgba(0,10,26,.72);display:flex;',
      'align-items:center;justify-content:center;padding:26px}',
    '.wkp-card{background:#12203A;border-radius:24px;padding:26px 22px 22px;max-width:340px;',
      'text-align:center;color:#fff;position:relative}',
    '.wkp-card .art{font-size:40px;display:block;margin-bottom:14px}',
    '.wkp-genio{height:110px;display:block;margin:0 auto 12px}',
    '.wkp-card h3{font:800 20px var(--font-display);margin:0 0 10px}',
    '.wkp-card p{font:500 13px/1.6 var(--font-body);color:rgba(200,218,242,.86);margin:0 0 20px}',
    '.wkp-card .cta{margin:0}',
    '.wkp-x{position:absolute;top:12px;right:12px;width:32px;height:32px;border:0;border-radius:50%;',
      'background:rgba(255,255,255,.12);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0}',
    '.wkp-x .wk-x-i{width:15px;height:15px}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   Il cartello di fine settimana
   --------------------------------------------------------------------------------------- */

function wkPromptShow(){
  if (document.getElementById('wkPrompt')) return;
  try{ if (!WK_DATI) wkRaccogli(); }catch(_){ }
  const el = document.createElement('div');
  el.className = 'wkp';
  el.id = 'wkPrompt';
  el.innerHTML = '<div class="wkp-card">'
    + '<button type="button" class="wkp-x" onclick="wkPromptClose()" aria-label="Chiudi">' + wkSvg(WK_IC.x, 'wk-x-i', 2.4) + '</button>'
    + '<img class="wkp-genio" src="img/genio/genio-saluta.png" alt="">'
    + '<h3>La tua settimana</h3>'
    + '<p>Ho messo in fila i tuoi ultimi sette giorni: dove è andato il tuo tempo e cosa puoi cambiare da oggi.</p>'
    + '<button type="button" class="cta" onclick="wkPromptClose();wkOpen(0, true)">Guardala ora</button>'
    + '</div>';
  document.body.appendChild(el);
}

function wkPromptClose(){
  const e = document.getElementById('wkPrompt');
  if (e) e.remove();
  /* Chiuderlo conta come averlo visto: tornare a chiedere la stessa settimana e' il modo
     piu' rapido di trasformare una buona idea in una seccatura. */
  wkSegna();
}

/* All'avvio, una volta sola: dopo che l'app ha finito di caricarsi e prima che l'utente si
   sia messo a fare altro. */
/* 0.9.286: il calendario della vita non si apre piu' da solo all'avvio: sta nell'ultima slide del report (vita-settimane.js) */
setTimeout(function(){ try{ if (wkTocca()) wkPromptShow(); }catch(_){ } }, 4200);

/* ===========================================================================================
   LA SETTIMANA VISSUTA, PRIMA DEL REPORT (0.9.257, Andrea). Alla fine di una settimana la prima
   cosa che si vede aprendo l'app NON e' il cartello del report: e' il calendario della vita in
   settimane, bianco con i quadrati scuri (come la pagina Memento mori), dove la settimana
   appena finita si riempie sotto gli occhi. Poi "Continua" e arriva il cartello del report.
   Mentre il calendario e' a schermo, i sette giorni si mettono in fila in sottofondo: il report
   si apre gia' pronto.
   =========================================================================================== */
function wkMementoApri(dopo){
  const c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c){ if (dopo) dopo(); return; }
  if (document.getElementById('wkMm')) return;
  const w = document.createElement('div'); w.id = 'wkMm'; w.className = 'wkmm';
  const anni = (typeof mmAnni === 'function') ? mmAnni() : 80;
  w.innerHTML = '<div class="wkmm-in">'
    + '<p class="wkmm-kick">Memento mori</p>'
    + '<h2>La tua vita in settimane</h2>'
    + '<p class="wkmm-sotto">La numero <b>' + c.vissute.toLocaleString('it-IT') + '</b> della tua vita si riempie adesso.</p>'
    + '<div class="wkmm-griglia"><canvas id="wkMmCv"></canvas></div>'
    + '<p class="wkmm-resta"><b>' + c.restano.toLocaleString('it-IT') + '</b> settimane davanti, se arrivi a ' + anni + ' anni. Che ci fai con la prossima?</p>'
    + '<button type="button" class="wkmm-via" onclick="wkMementoChiudi()">Continua</button></div>';
  document.body.appendChild(w);
  w._dopo = dopo;
  try{ wkRaccogli(); }catch(_){ }
  const prima = Object.assign({}, c, { vissute: Math.max(0, c.vissute - 1) });
  const cv = document.getElementById('wkMmCv');
  requestAnimationFrame(function(){ mmDisegna(prima, anni, { canvas: cv, chiaro: true }); });
  setTimeout(function(){
    const cv2 = document.getElementById('wkMmCv'); if (!cv2) return;
    mmDisegna(c, anni, { canvas: cv2, chiaro: true });
    cv2.parentNode.classList.add('pop');
    try{ flVibra([10, 40, 20]); }catch(_){ }
    try{ if (typeof muJingle === 'function') muJingle('moneta'); }catch(_){ }
  }, 1100);
}
function wkMementoChiudi(){
  const w = document.getElementById('wkMm'); if (!w) return;
  const dopo = w._dopo; w.remove();
  if (dopo) setTimeout(dopo, 150);
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.wkmm{position:fixed;inset:0;z-index:9996;background:#FBF7F2;color:#2A1F1D;overflow:auto;display:flex;align-items:flex-start;justify-content:center;animation:wkmmIn .4s ease-out}',
    '@keyframes wkmmIn{from{opacity:0}to{opacity:1}}',
    '.wkmm-in{width:100%;max-width:440px;padding:calc(28px + env(safe-area-inset-top)) 18px calc(26px + env(safe-area-inset-bottom));text-align:center}',
    '.wkmm-kick{margin:0 0 8px;font:800 11px var(--font-body);letter-spacing:.24em;text-transform:uppercase;color:#E63946}',
    '.wkmm-in h2{margin:0;font:800 26px/1.2 var(--font-display,var(--font-body));color:#2A1F1D}',
    'body.dark .wkmm-in h2,body.dark .wkmm-in p,body.dark .wkmm-in b{color:#2A1F1D}body.dark .wkmm-sotto b,body.dark .wkmm-kick{color:#E63946}',
    '.wkmm-sotto{margin:10px 0 18px;font:500 15px/1.5 var(--font-body);color:#5B4F4A}.wkmm-sotto b{color:#E63946}',
    '.wkmm-griglia{padding:12px 10px;border-radius:18px;background:#fff;box-shadow:0 0 0 1.5px #EADFD6}.wkmm-griglia.pop{animation:wkmmPop .5s cubic-bezier(.2,1.5,.4,1)}',
    '@keyframes wkmmPop{0%{transform:scale(1)}40%{transform:scale(1.02)}100%{transform:scale(1)}}',
    '.wkmm-resta{margin:22px 0 0;font:500 14.5px/1.5 var(--font-body);color:#5B4F4A}.wkmm-resta b{color:#2A1F1D}',
    '.wkmm-via{margin-top:26px;width:100%;max-width:330px;padding:15px 20px;border:0;border-radius:99px;background:#14234A;color:#fff;font:800 15px var(--font-body);cursor:pointer}'
  ].join('');
  document.head.appendChild(st);
})();

/* 0.9.258, Andrea: il report non deve mai aprirsi su una schermata nera. I sette giorni si mettono in
   fila da soli poco dopo l'avvio e quando si apre la scheda Profilo/Report, cosi' sono gia' pronti. */
setTimeout(function(){ try{ wkRaccogli().catch(function(){ }); }catch(_){ } try{ wkFrasiCarica(); }catch(_){ } }, 2500);
document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights' || e.detail === 'profilo'){ try{ if (!WK_DATI) wkRaccogli().catch(function(){ }); }catch(_){ } } });
