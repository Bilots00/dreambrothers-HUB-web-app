/* ===========================================================================================
   IL TOUR SULLA CASA VERA — il Genio ti porta in giro per l'app, come la Valchiria di Clash

   Il tutorial di prima era una scena a parte: un tabellone disegnato dentro al film e un
   pulsante da tenere premuto che «segnava un punto». Due bugie in una: la scheda START non si
   vedeva mai (si parlava di una cosa che l'utente non aveva davanti), e il punto lo regalava
   un gesto che non c'entra niente con la partita — nessuna azione, nessun passo verso il sogno.

   Qui non c'è nessuna scena. Il Genio, piccolo, sta sopra alla CASA VERA con il menu in basso
   visibile; il resto è in ombra, l'elemento che conta è nella luce con la freccia sopra, e
   l'utente tocca la cosa vera. Il Genio aspetta il tocco: non avanza da solo. Le fermate sono
   azioni, non spiegazioni:

     1. tocca Mappa          → la mappa alla Duolingo: una tappa al giorno, la serie, la rotta
     2. tocca START          → il foglio di domani, con la prima riga già scritta (dalla rotta)
     3. premi invio          → IL PUNTO È PRENOTATO (mtPlanMark): è la stessa mossa che farà
                               ogni sera, e vale solo se domani la fa dentro una sessione Focus
     4. il tabellone         → il vecchio te ha già segnato con le ore VERE di ieri
     5. tocca Blocco         → dove chiude le app mentre fa la sua riga
     6. i permessi

   Niente punto regalato: il tabellone lo tocca solo l'arbitro, dopo.
   =========================================================================================== */

const GT = { on: false, i: 0, stop: null, timer: 0, tick: 0, ev: null };

/* I TESTI DEL GIRO: li scrive il Copywriter (ruolo nel company brain). {segnaposto} fra graffe. */
/* Il Copywriter li ha scritti per «domani»; il foglio che il giro apre e' quello di OGGI (la
   scheda Domani si apre a sera): stesse parole, cambiato solo il giorno. */
const GT_TESTI = {
  /* 0.9.264, Andrea: il Genio ripeteva qui il sogno intero scritto a mano. Il foglio si spiega per quello che e'. */
  tour_start: 'Qui c\u2019è *START*: il foglio di oggi. Ci scrivi *una riga sola*, la cosa che oggi ti avvicina al sogno. Falla dentro Full Focus, e vale un punto.',
  tour_scrivi: 'La prima riga te la scrivo io: *«{riga}»*. Cambiala se vuoi, poi mettila sul foglio.',
  tour_scrivi_btn: 'La metto sul foglio',
  tour_fatto: 'È sul foglio. Il punto arriva solo se la fai dentro *Full Focus*: lì i minuti li conta il telefono. Te lo mostro.'
};
function gtT(k, v){
  let s = GT_TESTI[k] || '';
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  return s;
}

function gtEl(){
  let el = document.getElementById('gnTour');
  if (el) return el;
  el = document.createElement('div');
  el.id = 'gnTour';
  el.innerHTML =
      '<div class="gt-scrim" id="gtScrim"></div>'
    + '<div class="gt-spot" id="gtSpot" hidden></div>'
    + '<div class="gt-arrow" id="gtArrow" hidden>👇</div>'
    + '<div class="gt-genio" id="gtGenioBox">'
    +   '<img id="gtGenio" src="img/genio/genio-saluta.png" alt="">'
    +   '<div class="gt-bolla"><p id="gtTesto"></p><div class="gt-risp" id="gtRisp"></div></div>'
    + '</div>';
  (document.getElementById('phone') || document.body).appendChild(el);
  document.getElementById('gtScrim').addEventListener('click', gtToccoScrim);
  try{ document.querySelector('#gnTour .gt-bolla').addEventListener('click', function(e){ if (GT.timer && typeof GT.completa === 'function' && !e.target.closest('button')){ GT.completa(); } }); }catch(_){ }
  return el;
}

/* ---------- utilità ---------- */
function gtSogno(){
  try{ return (typeof gnLettura === 'function') ? gnLettura() : null; }catch(_){ return null; }
}
function gtNomi(){
  try{ return (typeof gnNomi === 'function') ? gnNomi() : { vecchio: 'il vecchio te', nuovo: 'il nuovo te' }; }
  catch(_){ return { vecchio: 'il vecchio te', nuovo: 'il nuovo te' }; }
}
function gtPosa(p){
  const img = document.getElementById('gtGenio');
  if (img) img.src = 'img/genio/genio-' + (p || 'saluta') + '.png';
}
/* Il typewriter del Genio, nella bolla del tour: stesse regole del film (26 ms a lettera, la
   parte fra *asterischi* si accende). */
/* 0.9.292, Andrea: "dopo l'onboarding il Genio scrive nettamente piu' lento". Il tempo per lettera era lo stesso (55 ms),
   ma nella bolla le lettere sono da 15 px contro i 19,5 della frase del giorno: la riga cresceva un quarto piu' piano.
   Il passo segue la grandezza del carattere, come nella frase della settimana (settimana.js, wkPassoLettera). */
function gtPasso(el){
  const base = (typeof CIT_MS === 'number') ? CIT_MS : 55;
  let fs = 19.5; try{ fs = parseFloat(getComputedStyle(el).fontSize) || 19.5; }catch(_){ }
  return Math.max(24, Math.round(base * Math.min(1, fs / 19.5)));
}
function gtScrivi(testo, dopo){
  const el = document.getElementById('gtTesto'); if (!el) return;
  clearInterval(GT.timer);
  const parti = (typeof gnParti === 'function') ? gnParti(testo) : { html: testo, n: testo.length };
  let i = 0;
  el.innerHTML = '';
  const fine = function(){ clearInterval(GT.timer); GT.timer = 0; el.innerHTML = parti.html; if (dopo) dopo(); };
  GT.timer = setInterval(function(){
    i++;
    try{ if (i % 2 === 0 && typeof gnAu !== 'undefined') gnAu.tick(); }catch(_){ }
    el.innerHTML = (typeof gnParti === 'function') ? gnParti(testo, i).html : testo.slice(0, i);
    if (i >= parti.n) fine();
  }, gtPasso(el));
  GT.completa = fine;
}

/* LA PROSSIMA TAPPA DELLA ROTTA. Il primo passo non fatto dell'orizzonte più vicino; se non
   c'è ancora niente scritto, il primo passo lo propone il Genio dal sogno scelto — e lo scrive
   anche nella rotta (orizzonte «oggi»), così la riga del foglio è SULLA rotta per costruzione. */
const GT_PRIMI_PASSI = {
  viaggiare: 'Cercare il prezzo del volo e segnarlo (10 min)',
  lavoro:    'Scrivere a una persona che fa già il lavoro che voglio (10 min)',
  amore:     'Scrivere a una persona che mi piace (10 min)',
  legami:    'Chiamare una persona a cui tengo, senza motivo (10 min)',
  imparare:  'Dieci minuti di pratica sulla cosa che sto imparando',
  liberta:   'Scrivere le tre cose che mi tengono fermo, e la prima da togliere (10 min)',
  soldi:     'Guardare le uscite dell’ultimo mese e tagliarne una (10 min)',
  meglio:    'Dieci minuti sulla cosa che rimando da più tempo',
  progetto:  'Scrivere a una persona che potrebbe diventare il mio primo cliente (10 min)',
  sessione:  'Dieci minuti sul capitolo che rimando',
  passione:  'Dieci minuti sulla cosa che amo',
  famiglia:  'Scrivere a una persona a cui tengo, senza motivo (10 min)',
  controllo: 'Dieci minuti sulla cosa che rimando da più tempo',
  corpo:     'Dieci minuti di allenamento, adesso',
  capolavoro: 'Dieci minuti sul mio capolavoro',
  voce:      'Registrare un minuto di video, senza rifarlo (10 min)',
  fede:      'Dieci minuti di preghiera, telefono in un\'altra stanza',
  coscienza: 'Dieci minuti di meditazione, telefono in un\'altra stanza',
  scrivo:    'Costruire la mia roadmap con il Genio (10 min)'
};
/* 0.9.293: il giro di prima scriveva da solo uno di questi passi nella rotta di oggi ("Scrivere a una persona che potrebbe
   diventare il mio primo cliente"), e ricompariva come Prossima mossa. Lo tolgo, una volta, se non e' stato fatto. */
function gtPuliziaPassi293(){
  try{
    if (localStorage.getItem('fl_gt_pulizia293') === '1' || typeof ozAnello !== 'function' || typeof ozSalvaAnello !== 'function') return;
    const vecchi = Object.keys(GT_PRIMI_PASSI).map(function(k){ return GT_PRIMI_PASSI[k]; });
    const a = ozAnello('oggi');
    const via = (a.passi || []).filter(function(p){ return !(p && !p.fatto && vecchi.indexOf(p.t) >= 0); });
    if (via.length !== (a.passi || []).length){
      a.passi = via;
      if (!via.length && /^Il primo passo/.test(a.testo || '')) a.testo = '';
      ozSalvaAnello('oggi', a);
    }
    localStorage.setItem('fl_gt_pulizia293', '1');
  }catch(_){ }
}
window.addEventListener('load', function(){ setTimeout(gtPuliziaPassi293, 800); });
function gtMissione(){
  try{ if (typeof stMissione === 'function'){ const m = stMissione(); if (m && m.t) return m.t; } }catch(_){ }
  let k = 'meglio';
  try{ k = (typeof gnDati === 'function' && gnDati().sognoK) || 'meglio'; }catch(_){ }
  const t = GT_PRIMI_PASSI[k] || GT_PRIMI_PASSI.meglio;
  /* nella rotta, una volta sola */
  try{
    if (typeof ozAnello === 'function' && typeof ozSalvaAnello === 'function'){
      const a = ozAnello('oggi');
      if (!(a.passi || []).some(function(p){ return p && p.t === t; })){
        a.passi = (a.passi || []).concat([{ t: t, fatto: false, il: '' }]);
        if (!a.testo){ const L = gtSogno(); a.testo = (L && L.sogno && L.sogno !== 'quel sogno') ? 'Il primo passo verso ' + L.sogno : 'Il primo passo'; }
        ozSalvaAnello('oggi', a);
      }
    }
  }catch(_){ }
  return t;
}
function gtModalita(){
  let m = 'normale';
  try{ m = localStorage.getItem('fl_modalita') || 'normale'; }catch(_){ }
  return { k: m, n: { facile: 1, normale: 3, difficile: 5 }[m] || 3 };
}

/* ---------- le fermate ----------
   Ogni fermata è un'azione vera. Il primo punto NON è regalato: è la prima scelta della
   partita (il pannello della decisione, quello vero), e il tabellone si muove in diretta con
   il cartello del gol. Prima, però, l'utente vede tutte e due le regole: come si segna e
   come segna l'altro. */
function gtStops(){
  /* 0.9.293, Andrea: "il tour e' da rifare sulla roadmap nuova: niente riga che scrivo io (non e' network marketing),
     la manina che indica un riquadro bianco, la scelta 'chi vuoi essere' troppo presto, e 'fare la tua riga' non e'
     italiano". Quattro fermate sulle schede vere (Dream, Mappa, START), il primo passo e' la prima tappa della roadmap,
     nessun compito inventato e nessuna scelta da firmare: il pannello delle scelte arriva quando c'e' qualcosa da
     scegliere (la Modalita' severa, il rinnovo). */
  const tappa = gtPrimaTappa();
  const casa = function(tab){ return function(){ try{ goId('s-home'); if (tab) switchTab(tab); }catch(_){ } }; };
  /* 0.9.337, Andrea: "il tour parte dalla scheda Sogno, ma deve partire dalla Mappa, dove si svolge tutto; poi START, e Sogno per
     ultima. Spiega una cosa per fermata, senza mischiare la storia con il rientro, e spiega cosa si fa in START". */
  return [
    { posa: 'saluta', target: '#mppSentiero', modo: 'btn', attesa: 900,
      pre: function(){ casa('mappa')(); try{ if (typeof mppVista === 'function' && !(typeof faStrada === 'function' && faStrada())) mppVista('rotta'); const t = document.getElementById('tab-mappa'); if (t) t.scrollTo({ top: 0 }); const n = document.getElementById('mppSentiero'); if (n) n.scrollIntoView({ block: 'start' }); }catch(_){ } },
      testo: 'Questa è la *Mappa*: qui fai il viaggio verso il tuo sogno, una tappa al giorno, come i livelli di un gioco.',
      btn: 'Ho capito' },
    { posa: 'rivela', target: '#mppSentiero .sd-nodo.corrente, #mppSentiero', modo: 'btn', attesa: 700,
      pre: function(){ try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n) n.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: tappa
        ? 'La prima tappa è *' + tappa + '*. Lì scegli come arrivarci: seguire la strada del Genio, o pianificare tu.'
        : 'La prima tappa è il tuo *piano su misura*. Lì scegli come arrivarci: seguire la strada del Genio, o pianificare tu.',
      btn: 'Ho capito' },
    { posa: 'pensa', target: '#nav-sveglia', modo: 'tap',
      testo: 'Poi c\u2019è *START*: è da qui che lavori al sogno. Tocca START.' },
    { posa: 'rivela', target: '#stMatchBox, #stHero', modo: 'btn', attesa: 700,
      pre: function(){ try{ const b = document.getElementById('stMatchBox') || document.getElementById('stHero'); if (b) b.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: 'Da qui parte il *Full Focus*: il telefono resta bloccato finché la sessione non finisce. Puoi farla da solo, *in coppia* con un amico, con i *suoni* per concentrarti.',
      btn: 'Ho capito' },
    { posa: 'saluta', target: '#nav-rotta', modo: 'tap',
      testo: 'Per ultima la scheda *Sogno*. Tocca Sogno.' },
    { posa: 'rivela', target: '#nvPannello', modo: 'btn', attesa: 700, pre: function(){ try{ if (typeof nvpVai === 'function') nvpVai('sogno'); const n = document.getElementById('nvPannello'); if (n) n.scrollIntoView({ block: 'start' }); }catch(_){ } },
      testo: 'Qui vedi *la data in cui arrivi* al tuo sogno. Si sposta ogni giorno, con quello che fai.',
      btn: 'Ho capito' },
    { posa: 'pensa', target: '#nvsPan', modo: 'btn', attesa: 400, pre: function(){ try{ const n = document.getElementById('nvsPan'); if (n) n.scrollIntoView({ block: 'center' }); }catch(_){ } },
      testo: 'E qui c\u2019è *la tua storia*: un episodio al giorno, in cui il Genio impara chi sei. La sera trovi qui anche *la revisione* della giornata.',
      btn: 'Ho capito' },
    { posa: 'saluta', target: null, modo: 'btn', attesa: 400, pre: casa('mappa'),
      testo: function(){
        return GT.permessiOk
          ? 'Fatto. Adesso la prima tappa: scegli come arrivare al tuo sogno.'
          : 'Hai visto tutto. Ora l\u2019app ha bisogno di *due permessi* per bloccare le distrazioni.';
      },
      btn: function(){ return GT.permessiOk ? 'Scelgo adesso' : 'Andiamo'; }, btnFn: function(){ const ok = GT.permessiOk; gtFine(); if (ok) gtBivioDopo(); } }
  ];
}
/* 0.9.337, Andrea: "l'utente non viene mai fatto scegliere se seguire il Genio o pianificare lui": finito il tour si sceglie subito */
function gtBivioDopo(){
  setTimeout(function(){
    try{
      if (typeof faStrada === 'function' && faStrada()) return;
      if (typeof faApriStrada === 'function') faApriStrada(function(k){ if (k === 'rotta' && typeof sdPianoApri === 'function') sdPianoApri(); });
    }catch(_){ }
  }, 600);
}
/* il titolo della tappa di oggi nella roadmap (quella che il sentiero segna come corrente) */
function gtPrimaTappa(){
  try{
    const n = document.querySelector('#mppSentiero .sd-nodo.corrente');
    const t = n && n.getAttribute('aria-label');
    if (t && String(t).trim()) return String(t).trim();
  }catch(_){ }
  return '';
}

/* ---------- il motore ---------- */
function gtStart(){
  /* i permessi si guardano subito, cosi' l'ultima fermata sa gia' se chiederli */
  GT.permessiOk = false;
  try{ if (typeof gnPermessiDati === 'function') gnPermessiDati().then(function(ok){ GT.permessiOk = !!ok; }); }catch(_){ }
  try{ if (typeof GN !== 'undefined' && GN.permessiOk) GT.permessiOk = true; }catch(_){ }
  if (GT.rivedi) GT.permessiOk = true;
  gtEl();
  GT.on = true; GT.i = 0;
  document.body.classList.add('gt-on');
  gtVai(0);
}
function gtFine(){
  GT.on = false;
  gtStacca();
  clearInterval(GT.timer);
  document.body.classList.remove('gt-on');
  const el = document.getElementById('gnTour'); if (el) el.remove();
  if (GT.rivedi){ GT.rivedi = false; return; }
  try{ const d = gnDati(); d.tourFatto = Date.now(); gnSalva(); }catch(_){ }
  try{ if (typeof gnPermessi === 'function') gnPermessi(); }catch(_){ }
}
function gtStacca(){
  clearInterval(GT.tick); GT.tick = 0;
  if (GT.ev){ document.removeEventListener(GT.ev.n, GT.ev.f); GT.ev = null; }
}
function gtVai(i){
  const stops = gtStops();
  if (i >= stops.length){ gtFine(); return; }
  gtStacca();
  GT.i = i; GT.stop = stops[i];
  const s = GT.stop;
  const risp = document.getElementById('gtRisp'); if (risp) risp.innerHTML = '';
  gtPosa(s.posa);
  try{ if (s.pre) s.pre(); }catch(_){ }
  setTimeout(function(){
    if (!GT.on || GT.stop !== s) return;
    /* il bersaglio deve stare nella luce: se e' sotto la piega, la scheda scorre fin li' */
    try{ const el = gtTarget(); if (el && !el.closest('.bottomnav, nav')) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
    gtMira(s.target);
    gtScrivi(typeof s.testo === 'function' ? s.testo() : s.testo, function(){
      if (s.modo === 'btn' || s.btn){
        const r = document.getElementById('gtRisp');
        if (r) r.innerHTML = '<button type="button" class="gt-btn" onclick="gtBtn()">' + ((typeof s.btn === 'function' ? s.btn() : s.btn) || 'Avanti') + '</button>';
      }
    });
    if (s.modo === 'evento' && s.evento){
      const f = function(){ gtDopoAzione(); };
      GT.ev = { n: s.evento, f: f };
      document.addEventListener(s.evento, f);
    }
  }, s.attesa || 120);
}
function gtBtn(){
  const s = GT.stop; if (!s) return;
  if (s.btnFn){
    s.btnFn();
    /* chi aspetta un evento (la decisione, il piano) avanza quando l'evento arriva */
    if (s.modo === 'evento') return;
  }
  gtDopoAzione();
}
function gtDopoAzione(){
  if (!GT.on) return;
  try{ if (typeof gnAu !== 'undefined') gnAu.scelta(1); }catch(_){ }
  gtVai(GT.i + 1);
}

/* IL BERSAGLIO. Il riflettore segue l'elemento vero (che può muoversi: una scheda che scorre,
   una tastiera che sale), quindi si rimisura quattro volte al secondo finché la fermata dura. */
function gtTarget(){
  const s = GT.stop; if (!s || !s.target) return null;
  const sels = s.target.split(',');
  for (let i = 0; i < sels.length; i++){
    const el = document.querySelector(sels[i].trim());
    if (el && el.offsetParent !== null) return el;
  }
  return null;
}
function gtMira(){
  clearInterval(GT.tick);
  gtMisura();
  GT.tick = setInterval(gtMisura, 250);
}
function gtMisura(){
  const spot = document.getElementById('gtSpot'), arrow = document.getElementById('gtArrow'), box = document.getElementById('gtGenioBox');
  const phone = document.getElementById('phone') || document.body;
  const el = gtTarget();
  if (!spot || !arrow || !box) return;
  const pr = phone.getBoundingClientRect();
  if (!el){ spot.hidden = true; arrow.hidden = true; box.classList.remove('su'); return; }
  const r = el.getBoundingClientRect();
  const pad = 6;
  spot.hidden = false;
  spot.style.left = (r.left - pr.left - pad) + 'px';
  spot.style.top = (r.top - pr.top - pad) + 'px';
  spot.style.width = (r.width + pad * 2) + 'px';
  spot.style.height = (r.height + pad * 2) + 'px';
  arrow.hidden = false;
  arrow.style.left = (r.left - pr.left + r.width / 2) + 'px';
  arrow.style.top = (r.top - pr.top - 44) + 'px';
  /* la bolla sta dalla parte opposta del bersaglio */
  box.classList.toggle('su', (r.top - pr.top) > pr.height * 0.55);
}
/* Un tocco sull'ombra: se cade dentro alla luce, arriva all'elemento vero. Fuori, niente. */
function gtToccoScrim(e){
  /* 0.9.292, Andrea: "toccando lo schermo il Genio continua a scrivere lettera per lettera invece di mostrare tutto" */
  if (GT.timer && typeof GT.completa === 'function'){ GT.completa(); return; }
  const s = GT.stop; if (!s) return;
  const el = gtTarget(); if (!el) return;
  const r = el.getBoundingClientRect();
  const x = e.clientX, y = e.clientY;
  if (x < r.left - 6 || x > r.right + 6 || y < r.top - 6 || y > r.bottom + 6){
    const a = document.getElementById('gtArrow'); if (a){ a.classList.remove('nudge'); void a.offsetWidth; a.classList.add('nudge'); }
    return;
  }
  const tour = document.getElementById('gnTour');
  tour.style.pointerEvents = 'none';
  const sotto = document.elementFromPoint(x, y) || el;
  tour.style.pointerEvents = '';
  try{
    if (sotto.tagName === 'TEXTAREA' || sotto.tagName === 'INPUT'){ sotto.focus(); return; }
    const b = sotto.closest('button, a, label, [onclick]') || el;
    b.click();
  }catch(_){ }
  if (s.modo === 'tap') setTimeout(gtDopoAzione, 80);
}

/* ---------- lo stile ---------- */
(function(){
  const css = [
    '#gnTour{position:absolute;inset:0;z-index:60;pointer-events:none}',
    '#gnTour .gt-scrim{position:absolute;inset:0;pointer-events:auto}',
    '.gt-spot{position:absolute;border-radius:14px;box-shadow:0 0 0 9999px rgba(4,10,28,.66);transition:left .3s,top .3s,width .3s,height .3s;pointer-events:none}',
    '.gt-arrow{position:absolute;transform:translateX(-50%);font-size:34px;line-height:1;animation:gtBounce 1s ease-in-out infinite;pointer-events:none;filter:drop-shadow(0 4px 8px rgba(0,0,0,.4))}',
    '.gt-arrow.nudge{animation:gtNudge .35s ease}',
    '@keyframes gtBounce{0%,100%{transform:translate(-50%,0)}50%{transform:translate(-50%,-8px)}}',
    '@keyframes gtNudge{0%,100%{transform:translate(-50%,0)}25%{transform:translate(-62%,0)}75%{transform:translate(-38%,0)}}',
    '.gt-genio{position:absolute;left:12px;right:12px;bottom:calc(84px + env(safe-area-inset-bottom));display:flex;align-items:flex-end;gap:8px;pointer-events:none}',
    '.gt-genio.su{bottom:auto;top:calc(56px + env(safe-area-inset-top))}',
    '.gt-genio img{width:96px;height:auto;flex:none;filter:drop-shadow(0 8px 16px rgba(0,0,0,.45))}',
    '.gt-bolla{flex:1;min-width:0;background:#fff;color:#0E2350;border:2px solid #0E2350;border-radius:18px 18px 18px 4px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.35);pointer-events:auto}',
    '.gt-bolla p{margin:0;font:600 15px/1.4 var(--font-body);color:#0E2350}',
    '.gt-bolla p b{color:#0075E3;font-weight:800}',
    '.gt-risp{margin-top:10px}.gt-risp:empty{display:none}',
    '.gt-btn{width:100%;border:0;border-radius:14px;padding:12px;background:#FFC53D;color:#0E2350;font:800 15px var(--font-body);cursor:pointer}',
    'body.gt-on .gn-tap{display:none}',
    'body.dec-on #gnTour{display:none}'
  ].join('');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
