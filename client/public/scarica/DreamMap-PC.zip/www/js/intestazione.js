/* ===========================================================================================
   L'INTESTAZIONE: le tre bolle e i loro pannelli (0.9.202, su richiesta di Andrea)

   🧭 la percentuale del percorso fatto (tappe della mappa + strada percorsa): tocco → pannello
      che scende dall'alto, come il punteggio del corso su Duolingo, con la data d'arrivo e i
      numeri che la spiegano;
   🔥 la serie (giorni di fila con almeno una tappa): tocco → la pagina della serie, con il
      calendario, i gettoni, e la scheda «Con gli amici» con i traguardi degli amici e il 👏;
   ⛽ il carburante: la riserva di dopamina di oggi (il tachimetro): tocco → la sua pagina.
   Il menu ☰ resta solo nella scheda Profilo.
   =========================================================================================== */
const HD = { pan: false, serieTab: 'personale', mese: 0, feed: null };
function hdEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }

/* ---------- la percentuale del percorso ---------- */
/* IL PERCORSO, UNA MISURA SOLA (0.9.209). Prima c'erano quattro numeri (intestazione, pannello,
   strada percorsa, cartina) e non tornavano mai. Adesso:
     · le MACRO TAPPE sono i passi degli orizzonti (mese, anno, cinque anni, un giorno): l'aereo
       sta sulla tappa macro a cui sei arrivato;
     · i LIVELLI della Roadmap lo fanno avanzare dentro al tratto verso la prossima tappa macro.
   Senza orizzonti scritti, contano solo i livelli. Lo stesso numero va ovunque, aereo compreso. */
const HD_MACRO = ['mese', 'anno', 'cinque', 'ungiorno'];
function hdMacro(){
  let tot = 0, fatti = 0;
  try{ const oz = (typeof ozLeggi === 'function') ? ozLeggi() : {}; HD_MACRO.forEach(function(k){ ((oz[k] && oz[k].passi) || []).forEach(function(p){ if (p && p.t){ tot++; if (p.fatto) fatti++; } }); }); }catch(_){ }
  return { tot: tot, fatti: fatti };
}
let HD_RESTA = null;
function hdPercorso(){
  let fatti = 0, tot = 0, capitolo = null;
  try{
    const caps = sdCapitoliBase(), s = sdStato();
    caps.forEach(function(c){ c.nodi.forEach(function(nd){ tot++; if (sdNodoFatto(nd, s)) fatti++; }); });
    const cur = sdCorrente(); if (cur.nodo && cur.nodo.cap) capitolo = cur.nodo.cap;
    /* 0.9.301: la Roadmap arriva fino al sogno (fasi 3 e 4 comprese). Contare solo i primi 14 capitoli dava il 99%
       dopo due settimane: il totale sono le tappe fatte piu' tutte quelle che mancano al sogno. */
    if (typeof sdTappeAlSogno === 'function'){
      if (!HD_RESTA || Date.now() - HD_RESTA.at > 5000) HD_RESTA = { at: Date.now(), n: sdTappeAlSogno() };
      if (HD_RESTA.n > 0) tot = Math.max(tot, fatti + HD_RESTA.n);
    }
  }catch(_){ }
  const lv = tot ? fatti / tot : 0;
  const m = hdMacro();
  let pct = lv;
  if (m.tot > 0){
    /* l'ancora: quanti livelli avevi quando hai chiuso l'ultima tappa macro */
    let anc = {}; try{ anc = JSON.parse(localStorage.getItem('fl_perc_ancora') || '{}') || {}; }catch(_){ }
    /* 0.9.237, Andrea: "0,0% del percorso, sembra resettato". Senza tappe macro chiuse l'ancora e' zero
       livelli: tutti i livelli fatti contano. Prima un'ancora riscritta (dopo un ripristino) ripartiva dai
       livelli di adesso e il percorso tornava a 0 */
    if (m.fatti === 0) anc = { m: 0, l: 0 };
    else if (anc.m !== m.fatti){ anc = { m: m.fatti, l: fatti }; }
    try{ localStorage.setItem('fl_perc_ancora', JSON.stringify(anc)); }catch(_){ }
    const tratto = 1 / (m.tot + 1);
    const perTratto = Math.max(1, tot / (m.tot + 1));
    const dentro = Math.min(0.9, Math.max(0, (fatti - (anc.l || 0)) / perTratto));
    pct = m.fatti * tratto + dentro * tratto;
  }
  /* 0.9.238: la strada gia' fatta prima dell'app ("Da dove parti?", partenza.js) */
  let par = 0; try{ par = (typeof ptzPct === 'function') ? ptzPct() : 0; }catch(_){ par = 0; }
  /* 0.9.281: si puo' contare solo la strada fatta con DreamMap (scelta nella pagina della rotta) */
  if (hdPercModo() === 'app') par = 0;
  pct = par + (1 - par) * pct;
  pct = Math.max(0, Math.min(0.99, pct));
  return { pct: pct, partenza: par, fatti: fatti, tot: tot, capitolo: capitolo, macro: m, tappe: lv };
}
function hdPercModo(){ try{ return localStorage.getItem('fl_perc_modo') === 'app' ? 'app' : 'sogno'; }catch(_){ return 'sogno'; } }
function hdPercModoSet(v){ try{ localStorage.setItem('fl_perc_modo', v === 'app' ? 'app' : 'sogno'); }catch(_){ } try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ } try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ } }
function flPercorso(){ try{ return hdPercorso().pct; }catch(_){ return 0; } }
function hdPctTxt(f){ if (typeof mpPercTxt === 'function') return mpPercTxt(f); const v = f * 100; return String(Math.round(v)); }
/** La tappa di oggi e' fatta? (la serie di oggi e' al sicuro) */
function hdOggiFatto(){ try{ const g = sdGiorniFatti(); return g[hdK(Date.now())] > 0; }catch(_){ return false; } }
/** Le ore che restano alla fine della giornata, arrotondate in su. */
function hdOreAllaFine(){ const m = new Date(); m.setHours(24, 0, 0, 0); return Math.max(1, Math.ceil((m.getTime() - Date.now()) / 3600000)); }
function hdSerie(){ try{ if (typeof sdSerieMappa === 'function') return sdSerieMappa(); }catch(_){ } try{ return (typeof serStreak === 'function') ? serStreak() : 0; }catch(_){ return 0; } }
function hdCarburante(){
  try{
    /* 0.9.306: all'avvio DP.L e' l'ultimo numero di oggi (dopamina.js, fl_dopa_ultimo): si mostra subito, e il calcolo vero parte lo stesso */
    if (typeof DP !== 'undefined' && DP && typeof DP.L === 'number'){
      if (!DP.dett && !DP.inCorso && typeof dpCalcola === 'function') dpCalcola(false).then(function(){ try{ hdrMatchApply(); }catch(_){ } }).catch(function(){ });
      return Math.round(DP.L);
    }
    if (typeof dpCalcola === 'function'){ dpCalcola(false).then(function(){ try{ hdrMatchApply(); }catch(_){ } }).catch(function(){ }); }
  }catch(_){ }
  return null;
}

/* ---------- il pannello del percorso, dall'alto ---------- */
function hdPercorsoApri(){
  if (HD.pan){ hdPercorsoChiudi(); return; }
  try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  const p = hdPercorso();
  let arrivo = null; try{ arrivo = (typeof etaArrivo === 'function') ? etaArrivo() : null; }catch(_){ }
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  const giorni = arrivo && isFinite(arrivo.at) ? Math.max(0, Math.round((arrivo.at - Date.now()) / 86400000)) : null;
  const serie = hdSerie();
  const righe = [];
  if (arrivo && arrivo.txt && typeof evVelata === 'function' && evVelata()) righe.push(['📅', 'Arrivo previsto', 'Ancora velato', evMotivo()]);
  else if (arrivo && arrivo.txt) righe.push(['📅', 'Arrivo previsto', arrivo.txt, giorni != null ? 'fra ' + giorni + (giorni === 1 ? ' giorno' : ' giorni') : '']);
  righe.push(['🗺️', 'Tappe della mappa', p.fatti + ' su ' + p.tot, p.capitolo ? 'capitolo ' + p.capitolo.cap + ': ' + p.capitolo.titolo : '']);
  if (p.macro && p.macro.tot) righe.push(['🏁', 'Tappe macro dei tuoi orizzonti', p.macro.fatti + ' su ' + p.macro.tot, 'l’aereo sta sull’ultima che hai chiuso']);
  righe.push(['🔥', 'Giorni di fila', String(serie), serie ? 'la serie cresce ogni giorno con una tappa' : 'una tappa oggi la fa partire']);
  let w = document.getElementById('hdPan');
  if (!w){
    w = document.createElement('div'); w.id = 'hdPan'; w.className = 'hd-pan';
    w.addEventListener('click', function(e){ if (e.target === w) hdPercorsoChiudi(); });
    (document.getElementById('phone') || document.body).appendChild(w);
  }
  /* 0.9.291: anche questo popover ha la sua X (regola dei popover: X, velo, tocco fuori, e il tasto indietro) */
  w.innerHTML = '<div class="hd-pan-in"><button type="button" class="hd-pan-x" aria-label="Chiudi" onclick="hdPercorsoChiudi()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="hd-pan-top"><div class="hd-pan-pct"><b>' + hdPctTxt(p.pct) + '%</b><small>del percorso</small></div>'
    + '<div class="hd-pan-bar"><i style="width:' + Math.round(p.pct * 100) + '%"></i></div>'
    + (sogno ? '<p class="hd-pan-sogno">' + hdEsc(sogno) + '</p>' : '') + '</div>'
    + '<div class="hd-pan-righe">' + righe.map(function(r){ return '<div class="hd-pan-r"><span>' + r[0] + '</span><div><small>' + hdEsc(r[1]) + '</small><b>' + hdEsc(r[2]) + '</b>' + (r[3] ? '<em>' + hdEsc(r[3]) + '</em>' : '') + '</div></div>'; }).join('') + '</div>'
    + '<div class="hd-pan-bot"><button type="button" class="hd-pan-link" onclick="hdPercorsoChiudi();if(typeof orPlanOpen===\'function\')orPlanOpen()">Ricalcola il percorso</button>'
    + '<button type="button" class="hd-pan-link" onclick="hdPercorsoChiudi();switchTab(\'mappa\')">Vai alla mappa</button></div>'
    + '</div>';
  w.hidden = false; HD.pan = true;
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function hdPercorsoChiudi(){ const w = document.getElementById('hdPan'); if (!w) return; w.classList.remove('in'); HD.pan = false; setTimeout(function(){ if (!HD.pan) w.hidden = true; }, 220); }

/* ---------- la serie: un pannello che scende dall'alto (0.9.203), come su Duolingo ---------- */
function hdSerieApri(tab){
  if (tab) HD.serieTab = tab;
  HD.mese = 0;
  let w = document.getElementById('hdSer');
  if (!w){
    w = document.createElement('div'); w.id = 'hdSer'; w.className = 'hd-pan hd-ser';
    w.addEventListener('click', function(e){ if (e.target === w) hdSerieChiudi(); });
    (document.getElementById('phone') || document.body).appendChild(w);
  }
  w.hidden = false; HD.ser = true;
  hdSeriePaint();
  requestAnimationFrame(function(){ w.classList.add('in'); });
  if (HD.serieTab === 'amici') hdFeedCarica();
  hdSerieAlterna();
  /* quanti non hanno ancora allungato la serie oggi: dal server, una volta per apertura */
  if (HD.primaPct == null && typeof frApi === 'function'){ HD.primaPct = 0; frApi('GET', '/api/focuslock/social/serie-prima?device=' + encodeURIComponent(frDevice())).then(function(r){ HD.primaPct = (r && r.pct) || 0; if (HD.ser && HD.serieTab === 'personale') hdSeriePaint(); }).catch(function(){ }); }
}
function hdSerieChiudi(){ clearInterval(HD.alt); const w = document.getElementById('hdSer'); if (!w) return; w.classList.remove('in'); HD.ser = false; setTimeout(function(){ if (!HD.ser) w.hidden = true; }, 220); }
/** Alla tappa che tocca adesso nella Mappa (la card della serie, «Inizia la tappa»). */
function hdTappaVia(){
  let c = null; try{ c = sdCorrente(); }catch(_){ }
  try{ switchTab('mappa'); }catch(_){ }
  if (c && c.nodo){ setTimeout(function(){ try{ if (typeof mppVista === 'function') mppVista('rotta'); sdTapVia(c.nodo.id); }catch(_){ } }, 350); }
}
/* ---------- CONDIVIDI LA SERIE (0.9.205): la card arancione come su Duolingo, a schermo intero ---------- */
async function hdSerieCard(){
  const n = hdSerie();
  let nome = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = (u && u.name) ? String(u.name) : ''; }catch(_){ }
  const W = 900, H = 1600, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#FF8A3D'); g.addColorStop(1, '#FFB347');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillStyle = 'rgba(0,19,43,.85)'; x.font = '800 54px sans-serif'; x.fillText('DreamMap', W / 2, 130);
  x.font = '400 420px sans-serif'; x.fillText('🔥', W / 2, 560);
  x.fillStyle = '#fff'; x.shadowColor = 'rgba(0,0,0,.18)'; x.shadowOffsetY = 8;
  x.font = '900 300px sans-serif'; x.fillText(String(n), W / 2, 950);
  x.shadowColor = 'transparent';
  x.font = '800 72px sans-serif'; x.fillText(n === 1 ? 'giorno di fila' : 'giorni di fila', W / 2, 1150);
  x.font = '600 44px sans-serif'; x.fillStyle = 'rgba(255,255,255,.92)'; x.textAlign = 'left';
  if (nome) x.fillText('@' + nome.replace(/\s+/g, ''), 70, 1510);
  x.textAlign = 'right';
  const d = new Date(); x.fillText(d.getDate() + ' ' + ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'][d.getMonth()] + ' ' + d.getFullYear(), W - 70, 1510);
  return cv;
}
async function hdSerieCondividi(){
  let w = document.getElementById('hdShare');
  if (!w){ w = document.createElement('div'); w.id = 'hdShare'; w.className = 'hd-share'; (document.getElementById('phone') || document.body).appendChild(w); }
  const cv = await hdSerieCard(); HD.shareUrl = cv.toDataURL('image/png');
  w.innerHTML = '<div class="hd-share-top"><button type="button" class="hd-x" onclick="hdShareChiudi()" aria-label="Chiudi">✕</button><b>Condividi la serie</b><span></span></div>'
    + '<div class="hd-share-stage"><img class="hd-share-img" src="' + HD.shareUrl + '" alt="La tua serie"></div>'
    + '<div class="hd-share-btn"><button type="button" class="hd-share-b" onclick="hdShareSalva()"><span>⬇</span>Salva</button><button type="button" class="hd-share-b main" onclick="hdShareVia()"><span>↗</span>Condividi</button></div>';
  w.hidden = false; requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ flVibra(10); }catch(_){ }
}
function hdShareChiudi(){ const w = document.getElementById('hdShare'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 220); }
async function hdShareVia(){
  const n = hdSerie();
  const txt = '🔥 ' + n + (n === 1 ? ' giorno' : ' giorni') + ' di fila su DreamMap, verso il mio sogno. ' + ((typeof FR_URL !== 'undefined') ? FR_URL : '');
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareImage){ try{ await NATIVE.shareImage({ base64: HD.shareUrl, text: txt, title: 'La mia serie' }); return; }catch(_){ } }
  try{
    const blob = await (await fetch(HD.shareUrl)).blob(); const f = new File([blob], 'serie.png', { type: 'image/png' });
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [f] })){ await navigator.share({ files: [f], text: txt }); return; }
  }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: 'La mia serie' }); return; }catch(_){ } }
  try{ await navigator.clipboard.writeText(txt); toast('Copiato'); }catch(_){ }
}
async function hdShareSalva(){
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.saveImage){ try{ await NATIVE.saveImage({ dataUrl: HD.shareUrl, name: 'dreammap-serie.png' }); toast('Salvata nella galleria'); return; }catch(_){ } }
  const a = document.createElement('a'); a.href = HD.shareUrl; a.download = 'dreammap-serie.png'; document.body.appendChild(a); a.click(); a.remove();
}
async function hdSerieCondividiTesto(){
  const n = hdSerie();
  const txt = '🔥 ' + n + (n === 1 ? ' giorno' : ' giorni') + ' di fila su DreamMap, verso il mio sogno. Fai strada con me: ' + ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock');
  try{ flVibra(12); }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: 'La mia serie' }); return; }catch(_){ } }
  if (navigator.share){ try{ await navigator.share({ text: txt }); return; }catch(_){ } }
  try{ await navigator.clipboard.writeText(txt); toast('Copiato'); }catch(_){ }
}
/* 0.9.350, Andrea: "Serie di tappe fa pensare a tappe di fila, non a giorni di fila: un titolo che non si possa fraintendere, e la (i)" */
function hdSerieInfo(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Giorni di fila</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe([
        ['🗺️', 'Basta una tappa al giorno', 'Ogni giorno in cui fai almeno una tappa della mappa, la serie cresce di uno.'],
        ['🧊', 'Un giorno saltato si congela', 'Un congelamento della serie salva il giorno in cui non fai tappe.'],
        ['⏱️', 'Il Full Focus ha la sua serie', 'I giorni di fila in Full Focus stanno nella scheda START.']
      ]) : '')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
(function(){ const st = document.createElement('style'); st.textContent = '.hd-ser-tit{display:inline-flex;align-items:center;justify-content:center;gap:8px;flex:1}.hd-ser-i{flex:none;box-sizing:border-box;width:22px;height:22px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid currentColor;border-radius:50%;background:none;color:inherit;opacity:.7;font:800 12px/1 Georgia,serif;font-style:italic;cursor:pointer}'
  + '.hd-ser-pietra{background:linear-gradient(135deg,#0075E3 0%,#001E44 100%)!important;border:0!important;box-shadow:0 8px 20px rgba(0,30,68,.25)!important}.hd-ser-pietra .txt b,.hd-ser-pietra .txt p{color:#fff!important}.hd-ser-pietra .txt p{opacity:.88}'; document.head.appendChild(st); })();
function hdSerieTab(t){ HD.serieTab = t; hdSeriePaint(); if (t === 'amici') hdFeedCarica(); }
function hdGeloOggi(){ try{ const k = localStorage.getItem('fl_gelo_oggi'); return !!k && k === (typeof snOggi === 'function' ? snOggi() : ''); }catch(_){ return false; } }
function hdSeriePaint(){
  const w = document.getElementById('hdSer'); if (!w) return;
  w.innerHTML = '<div class="hd-pan-in hd-ser-in"><div class="hd-ser-top"><button type="button" class="hd-x" onclick="hdSerieChiudi()" aria-label="Chiudi">✕</button><b class="hd-ser-tit">Giorni di fila<button type="button" class="hd-ser-i" onclick="event.stopPropagation();hdSerieInfo()" aria-label="Cosa conta questa serie">i</button></b><button type="button" class="hd-x" onclick="hdSerieCondividi()" aria-label="Condividi la serie"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5"/></svg></button></div>'
    + '<div class="hd-tabs"><button type="button"' + (HD.serieTab === 'personale' ? ' class="on"' : '') + ' onclick="hdSerieTab(\'personale\')">Personale</button>'
    + '<button type="button"' + (HD.serieTab === 'amici' ? ' class="on"' : '') + ' onclick="hdSerieTab(\'amici\')">Con gli amici</button></div>'
    + '<div class="hd-ser-corpo">' + (HD.serieTab === 'personale' ? hdPersonaleHtml() : hdAmiciHtml()) + '</div></div>';
}
/* il ghiacciolo dei giorni coperti dal gettone: disegnato, non un emoji */
const HD_GHIACCIO = '<svg class="hd-ghiaccio" viewBox="0 0 24 30" aria-hidden="true"><path d="M5 3.5A2.5 2.5 0 0 1 7.5 1h9A2.5 2.5 0 0 1 19 3.5V18a7 7 0 0 1-14 0z" fill="#7FD3FF" stroke="#2EA8F0" stroke-width="1.6"/><path d="M8 6v10M11.5 4.5V9" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><path d="M12 25v4" stroke="#B9842F" stroke-width="2.4" stroke-linecap="round"/></svg>';
/* la frase del giorno sotto al numero: cambia ogni giorno, come il pannello della Modalita' severa */
const HD_FRASI = [
  '{n} giorni di fila: il te di {n} giorni fa non ci avrebbe scommesso.',
  'Ogni giorno in più è un mattone che nessuno ti toglie.',
  'La serie non è il numero: è la persona che diventi tenendola.',
  'Chi torna ogni giorno arriva. Non è poesia, è aritmetica.',
  'Il sogno si avvicina alla velocità delle tue tappe.',
  'Oggi conta più di ieri, perché ieri lo hai già vinto.',
  'Una tappa al giorno batte una maratona al mese.',
  'Tenere la serie è dire di sì al te di domani.'
];
function hdFraseGiorno(n){
  const d = new Date(); const g = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 86400000);
  const f = n <= 1 ? HD_FRASI[1] : HD_FRASI[g % HD_FRASI.length];
  return f.replace(/\{n\}/g, n);
}
function hdSerieAlterna(){
  clearInterval(HD.alt); HD.altI = 0;
  HD.alt = setInterval(function(){
    const p = document.querySelector('#hdSer .hd-ser-card[data-alt] p'); if (!p){ clearInterval(HD.alt); return; }
    const frasi = JSON.parse(p.parentElement.dataset.alt); HD.altI = (HD.altI + 1) % frasi.length;
    p.classList.add('via'); setTimeout(function(){ p.textContent = frasi[HD.altI]; p.classList.remove('via'); }, 260);
  }, 6000);
}
function hdK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
/* I complimenti della serie delle tappe, nel pannello col gradiente della Modalita' severa (.blk-streak) */
const HD_PIETRE = {
  1:   ['Prima tappa fatta', 'La serie della mappa è partita. Domani la fai crescere.'],
  2:   ['Secondo giorno', 'Ieri poteva essere un caso. Oggi no.'],
  3:   ['Sta prendendo ritmo', 'Tre giorni di tappe di fila. Da qui comincia il cambiamento.'],
  5:   ['Cinque giorni', 'Cinque tappe in cinque giorni. Il sogno ha smesso di essere un’idea.'],
  7:   ['Una settimana intera', 'Sette giorni di tappe. Un’abitudine sta nascendo.'],
  10:  ['Doppia cifra', 'Dieci giorni di fila sulla tua mappa. Non stai più provando.'],
  14:  ['In pieno ritmo', 'Due settimane di tappe. La costanza comincia a venirti naturale.'],
  21:  ['Tre settimane', 'Ventun giorni. Il tempo che serve a un’abitudine per non chiedere più permesso.'],
  30:  ['Un nuovo normale', 'Un mese di concentrazione. La dedizione che dimostri è straordinaria.'],
  60:  ['Due mesi', 'Sessanta giorni di tappe. Le cose che rimandavi hanno una data.'],
  90:  ['Tre mesi', 'Un trimestre intero verso il tuo sogno. Questa è disciplina vera.'],
  100: ['Cento giorni', 'Tre cifre. Pochissimi arrivano fin qui.'],
  365: ['Un anno intero', 'Trecentosessantacinque giorni sulla tua mappa. Sei un’altra persona.']
};
const HD_FRASI_TAPPA = [
  'Tappa di oggi fatta. Il tuo sogno è un passo più vicino.',
  'Un altro giorno vinto contro il vecchio te.',
  'Le giornate così non fanno rumore. Si sommano, e un giorno si vedono.',
  'Ogni tappa fatta rende la prossima un po’ più facile.',
  'Il tuo io futuro sta prendendo forma, una tappa alla volta.'
];
function hdPietraHtml(n){
  let t, p;
  if (HD_PIETRE[n]){ t = HD_PIETRE[n][0]; p = HD_PIETRE[n][1]; }
  else if (n > 30){ t = n < 60 ? 'Un nuovo normale' : (n + ' giorni di fila'); p = n < 60 ? 'Più di un mese di concentrazione. La dedizione che dimostri è straordinaria.' : HD_FRASI_TAPPA[n % HD_FRASI_TAPPA.length]; }
  else { t = n + ' giorni di fila'; p = HD_FRASI_TAPPA[n % HD_FRASI_TAPPA.length]; }
  /* 0.9.350, Andrea: "quel gradiente non c'entra niente con l'arancione: blu, per il contrasto. E niente fuoco col numero, il numero c'e' gia'
     sopra" (il fuoco con il numero resta nel pannello della pagina Modalita' severa) */
  return '<div class="blk-streak hd-ser-pietra"><div class="txt"><b>' + hdEsc(t) + '</b><p>' + hdEsc(p) + '</p></div></div>';
}
function hdPersonaleHtml(){
  const n = hdSerie();
  let g = {}; try{ g = sdGiorniFatti(); }catch(_){ }
  let gettoni = 0; try{ gettoni = snStato().serie.gettoni || 0; }catch(_){ }
  const oggiK = hdK(Date.now());
  const oggiFatto = g[oggiK] > 0;
  /* il calendario del mese: lunedi' per primo, i giorni con una tappa in azzurro, oggi in arancio */
  const base = new Date(); base.setDate(1); base.setMonth(base.getMonth() + HD.mese);
  const anno = base.getFullYear(), mese = base.getMonth();
  const primo = (new Date(anno, mese, 1).getDay() + 6) % 7;
  const nGiorni = new Date(anno, mese + 1, 0).getDate();
  const MESI = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
  let celle = '';
  for (let i = 0; i < primo; i++) celle += '<i></i>';
  for (let d = 1; d <= nGiorni; d++){
    const k = hdK(new Date(anno, mese, d).getTime());
    const st = k === oggiK ? (oggiFatto ? 'oggi fatto' : 'oggi') : (g[k] > 0 ? 'fatto' : (g[k] === -1 ? 'coperto' : ''));
    celle += '<i class="' + st + '">' + (st === 'coperto' ? '🧊' : d) + '</i>';
  }
  const ore = hdOreAllaFine();
  const oreTxt = ore <= 1 ? 'meno di un’ora' : ore + ' ore';
  return '<div class="hd-ser-testa' + (oggiFatto ? '' : ' spenta') + '"><div class="hd-ser-num"><b>' + n + '</b><small>' + (n === 1 ? 'giorno di fila!' : 'giorni di fila!') + '</small></div><span class="hd-ser-fiamma">🔥</span>'
    + (oggiFatto
        /* 0.9.292, Andrea: "a nessuno frega niente di Tappa di oggi al sicuro: voglio il pannello col gradiente della pagina
           Modalita' severa, con i complimenti legati alle tappe della roadmap, e dopo un mese il testo di Opal" */
        ? (hdGeloOggi() ? '<div class="hd-ser-card dso-prot"><span aria-hidden="true">🧊</span><div><p>Hai guadagnato un <b>congelamento della serie</b> per aver fatto la tappa anche oggi!</p></div></div>' : hdPietraHtml(n))
        /* 0.9.278, come Duolingo: quante ore restano per salvare la serie */
        /* 0.9.280, Andrea: "solo 24 ore" non mette fretta a nessuno. L'urgenza arriva da meta' giornata in giu' */
        /* 0.9.322, Andrea: prima di tutto il tempo che resta; poi, se le protezioni sono finite, quelle; se no la tappa di oggi */
        : (ore > 12 && gettoni === 0 && typeof dsoProtezioneHtml === 'function') ? dsoProtezioneHtml()
        : '<div class="hd-ser-card' + (ore <= 12 ? ' urgente' : '') + '"><span>' + (ore <= 12 ? '⏱️' : '🔥') + '</span><div><p>' + (ore > 12
            ? (n >= 1 ? 'Fai la tappa di oggi e la tua serie sale a <b>' + (n + 1) + ' giorni</b>.' : 'Fai la tappa di oggi e la tua serie comincia.')
            : (n >= 1 ? 'Ti rimangono solo <b>' + oreTxt + '</b> per salvare la tua serie!' : 'Ti rimangono <b>' + oreTxt + '</b> per iniziare la tua serie.')) + '</p><button type="button" class="hd-ser-cta" onclick="hdSerieChiudi();hdTappaVia()">Inizia la tappa</button></div></div>')
    + '</div>'
    + '<h3 class="hd-ser-h">Calendario della serie</h3>'
    + '<div class="hd-cal"><div class="hd-cal-top"><button type="button" onclick="HD.mese--;hdSeriePaint()" aria-label="Mese prima">‹</button><b>' + MESI[mese] + ' ' + anno + '</b><button type="button" onclick="HD.mese++;hdSeriePaint()" aria-label="Mese dopo">›</button></div>'
    + '<div class="hd-cal-g">' + ['L', 'M', 'M', 'G', 'V', 'S', 'D'].map(function(x){ return '<span>' + x + '</span>'; }).join('') + '</div>'
    + '<div class="hd-cal-d">' + celle + '</div></div>'
    + hdObiettivoHtml(n) + hdCompagniaHtml(n);
}
/* ---- L'OBIETTIVO DELLA SERIE (0.9.207, come Duolingo dal 0.9.210) ----
   Mentre il periodo e' in corso si vede SOLO la barra con le tappe (7, 14, 30...) e «4 / 50
   giorni»: nessun pulsante spento, nessuna frase che spiega le regole. Solo a periodo finito (o
   a obiettivo raggiunto) compaiono le scelte, in una riga che scorre di lato, fino a un anno,
   con l'ultima per scrivere i giorni a mano. */
const HD_OBIETTIVI = [7, 14, 30, 50, 100, 180, 365];
function hdObiettivo(){ let v = 0; try{ v = +localStorage.getItem('fl_serie_obiettivo') || 0; }catch(_){ } return (v >= 3 && v <= 1000) ? Math.round(v) : 0; }
function hdObiettivoAt(){ try{ return +localStorage.getItem('fl_serie_obiettivo_at') || 0; }catch(_){ return 0; } }
/** Si puo' cambiare solo quando il periodo scelto e' finito (o l'obiettivo e' raggiunto). */
function hdObiettivoLibero(n){ const ob = hdObiettivo(); if (!ob) return true; if (n >= ob) return true; return Date.now() - hdObiettivoAt() >= ob * 86400000; }
function hdObiettivoSet(v){
  let n = 0; try{ n = hdSerie(); }catch(_){ }
  if (!hdObiettivoLibero(n)){ try{ flVibra([30, 30, 30]); }catch(_){ } return; }
  v = Math.round(+v || 0); if (v < 3 || v > 1000) return;
  try{ localStorage.setItem('fl_serie_obiettivo', String(v)); localStorage.setItem('fl_serie_obiettivo_at', String(Date.now())); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  if (HD.ser) hdSeriePaint();
  try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ }
}
function hdObiettivoMio(){
  const v = prompt('Quanti giorni di fila vuoi fare? (da 3 a 1000)', '21');
  if (v === null) return;
  const n = Math.round(+String(v).replace(/[^0-9]/g, '') || 0);
  if (n < 3 || n > 1000){ toast('Scegli un numero di giorni fra 3 e 1000'); return; }
  hdObiettivoSet(n);
}
function hdCal(num, fatto){ return '<span class="hd-mc' + (fatto ? ' fatto' : '') + '"><i></i><b>' + (fatto ? '✓' : num) + '</b></span>'; }
function hdObiettivoHtml(n){
  const ob = hdObiettivo(); const libero = hdObiettivoLibero(n);
  let html = '<h3 class="hd-ser-h">Obiettivo della serie</h3><div class="hd-ob">';
  if (ob){
    /* le tappe sulla barra: le pietre miliari fino all'obiettivo, al massimo tre, l'ultima e' l'obiettivo */
    const pietre = HD_OBIETTIVI.filter(function(g){ return g < ob; }).slice(-3).concat([ob]);
    const nodi = [0].concat(pietre);
    let barra = '<div class="hd-ob-linea">' + hdCal('', true);
    for (let i = 1; i < nodi.length; i++){
      const da = nodi[i - 1], a = nodi[i];
      const f = Math.max(0, Math.min(1, (n - da) / Math.max(1, a - da)));
      barra += '<div class="hd-ob-tratto"><i style="width:' + Math.round(f * 100) + '%"></i></div>' + hdCal(a, n >= a);
    }
    html += barra + '</div><small>' + Math.min(n, ob) + ' / ' + ob + ' giorni</small>';
  }
  if (libero){
    html += (ob ? '<p class="hd-ob-scegli">' + (n >= ob ? 'Obiettivo raggiunto: scegli il prossimo.' : 'Il periodo è finito: scegli il prossimo obiettivo.') + '</p>' : '<p class="hd-ob-scegli">Quanti giorni di fila vuoi fare?</p>')
      + '<div class="hd-ob-scorri">' + HD_OBIETTIVI.filter(function(g){ return g > Math.min(n, ob || 0) || !ob; }).map(function(g){ return '<button type="button" class="' + (g === ob ? 'on' : '') + '" onclick="hdObiettivoSet(' + g + ')">' + hdCal(g, false) + '<b>' + g + ' giorni</b></button>'; }).join('')
      + '<button type="button" onclick="hdObiettivoMio()"><span class="hd-mc mio"><i></i><b>✎</b></span><b>A modo tuo</b></button></div>';
  }
  return html + '</div>';
}
/* ---- LA COMPAGNIA DELLA SERIE: il club di chi arriva a sette giorni ---- */
function hdCompagniaHtml(n){
  const dentro = n >= 7;
  return '<h3 class="hd-ser-h">Compagnia della serie</h3><div class="hd-comp' + (dentro ? ' dentro' : '') + '"><span>' + (dentro ? '🛡️' : '🔒') + '</span><p>' + (dentro
    ? 'Sei nella Compagnia: lo scudo accanto al tuo nome fra gli amici, e una protezione in più ogni sette giorni di fila.'
    : 'Raggiungi una serie di 7 giorni per entrare nella Compagnia della serie e ricevere premi esclusivi.') + '</p></div>';
}
/* ---------- con gli amici: il feed dei traguardi, con il cuore e le altre reazioni ---------- */
async function hdFeedCarica(){
  try{ if (typeof frAmiciCarica === 'function') await frAmiciCarica(false); }catch(_){ }
  if (HD.ser && HD.serieTab === 'amici') hdSeriePaint();
}
function hdFeedVoci(){
  const A = (typeof FR !== 'undefined' && FR && FR.amici) ? FR.amici : null;
  const lista = (A && A.amici) || [];
  const voci = [];
  lista.forEach(function(a){
    const at = a.visto ? Date.parse(a.visto) : 0;
    if (a.streak >= 1) voci.push({ a: a, t: 'è a <b>' + a.streak + (a.streak === 1 ? ' giorno' : ' giorni') + ' di fila</b>!', e: '🔥', at: at, k: 'serie' });
    if (a.ffMin7 >= 25) voci.push({ a: a, t: 'ha fatto <b>' + (typeof frOre === 'function' ? frOre(a.ffMin7) : a.ffMin7 + ' min') + ' di Full Focus</b> questa settimana', e: '⏳', at: at - 1, k: 'focus' });
    if (a.neo > a.old) voci.push({ a: a, t: 'sta vincendo la partita: <b>' + a.neo + ' a ' + a.old + '</b> per il nuovo sé', e: '🚀', at: at - 2, k: 'partita' });
    if (a.level >= 2) voci.push({ a: a, t: 'è al <b>livello ' + a.level + '</b>', e: '⭐', at: at - 3, k: 'livello' });
    /* 0.9.300: la lega in cui gioca (dal server, tier), come "Mirko ha raggiunto la Lega Diamante" su Duolingo */
    if (HD_CG_LEGHE[a.tier]) voci.push({ a: a, t: 'gioca in <b>Lega ' + HD_CG_LEGHE[a.tier].n + '</b>', e: HD_CG_LEGHE[a.tier].e, at: at - 0.5, k: 'lega' });
  });
  voci.sort(function(x, y){ return y.at - x.at; });
  return voci.slice(0, 30);
}
function hdQuando(at){
  if (!at) return '';
  const m = Math.round((Date.now() - at) / 60000);
  if (m < 60) return m <= 1 ? 'adesso' : m + ' min fa';
  const h = Math.round(m / 60); if (h < 24) return h + (h === 1 ? ' ora fa' : ' ore fa');
  const g = Math.round(h / 24); return g + (g === 1 ? ' giorno fa' : ' giorni fa');
}
const HD_REAZ = [{ k: 'cuore', e: '❤️', t: 'Mi piace' }, { k: 'grande', e: '👏', t: 'Grande!' }, { k: 'continua', e: '🔥', t: 'Continua così' }, { k: 'nonmollare', e: '💪', t: 'Non mollare' }, { k: 'centrato', e: '🎯', t: 'Centrato' }];
/* 0.9.321, Andrea: la scheda Con gli amici e' la serie di gruppo (dream-social.js); il feed sta nella scheda Social */
function hdAmiciHtml(){ return (typeof dsoGruppoHtml === 'function') ? dsoGruppoHtml() : ''; }
function hdFeedHtml(){
  const A = (typeof FR !== 'undefined' && FR && FR.amici) ? FR.amici : null;
  const lista = (A && A.amici) || [];
  if (!lista.length) return '';
  const voci = hdFeedVoci();
  if (!voci.length) return '';
  return '<div class="hd-feed">' + voci.map(function(v, i){
    const mandate = v.a.reazioniOggi || [];
    const fatta = HD_REAZ.filter(function(r){ return mandate.indexOf(r.k) >= 0; })[0];
    return '<div class="hd-feed-r"><div class="hd-feed-top">' + (typeof frAv === 'function' ? frAv(v.a.nome, v.a.device) : '') + '<div><b>' + hdEsc(v.a.nome) + '</b><small>' + hdQuando(v.at) + '</small></div><span class="hd-feed-e">' + v.e + '</span></div>'
      + '<p>' + v.t + '</p>'
      /* il cuore e' il tocco; tenendo premuto escono le altre reazioni, come su Facebook */
      + '<div class="hd-reaz-w"><button type="button" class="hd-like' + (fatta ? ' on' : '') + '" data-dev="' + hdEsc(v.a.device) + '" data-nome="' + hdEsc(v.a.nome) + '" onclick="hdReazione(this,\'cuore\')" onpointerdown="hdPremi(this)" onpointerup="hdLascia()" onpointerleave="hdLascia()" oncontextmenu="return false">' + (fatta ? fatta.e + ' ' + fatta.t : '❤️ Mi piace') + '</button>'
      + '<div class="hd-reaz-bar">' + HD_REAZ.map(function(r){ return '<button type="button" onclick="event.stopPropagation();hdReazione(this.parentElement.previousElementSibling,\'' + r.k + '\')" aria-label="' + r.t + '">' + r.e + '</button>'; }).join('') + '</div></div>'
      + '</div>';
  }).join('') + '</div>';
}
function hdPremi(btn){
  clearTimeout(HD.premuto);
  HD.premuto = setTimeout(function(){
    document.querySelectorAll('.hd-reaz-bar.in').forEach(function(x){ x.classList.remove('in'); });
    const bar = btn.nextElementSibling; if (bar) bar.classList.add('in');
    btn.dataset.lungo = '1';
    try{ flVibra(16); }catch(_){ }
  }, 420);
}
function hdLascia(){ clearTimeout(HD.premuto); }
document.addEventListener('click', function(e){ if (!e.target.closest('.hd-reaz-w')) document.querySelectorAll('.hd-reaz-bar.in').forEach(function(x){ x.classList.remove('in'); }); });
async function hdReazione(btn, tipo){
  if (!btn) return;
  if (btn.dataset.lungo === '1' && tipo === 'cuore' && btn.nextElementSibling && btn.nextElementSibling.classList.contains('in')){ btn.dataset.lungo = ''; return; }
  btn.dataset.lungo = '';
  const r = HD_REAZ.filter(function(x){ return x.k === tipo; })[0] || HD_REAZ[0];
  btn.classList.add('on'); btn.textContent = r.e + ' ' + r.t;
  const bar = btn.nextElementSibling; if (bar) bar.classList.remove('in');
  try{ flVibra(14); }catch(_){ }
  try{ if (typeof frReagisci === 'function') await frReagisci(btn.dataset.dev, btn.dataset.nome, tipo, null); }catch(_){ }
}

/* ---------- CONGRATULATI (0.9.278), come su Duolingo ("Nico ha completato 5200 esercizi... CONGRATULATI") ----------
   Quando apri l'app, se un amico ha raggiunto un traguardo che conta (una serie tonda, tante ore di Full Focus, la
   partita vinta), compare a tutto schermo con un pulsante solo. "Congratulati" manda la reazione nel feed: la riceve
   lui, e la sana competizione cresce. Una volta per traguardo, e al massimo una ogni quattro ore. */
const HD_CONGRAT_KEY = 'fl_congrat_visti';
/* le leghe che si festeggiano (Bronzo e' quella di partenza: non e' un traguardo) */
const HD_CG_LEGHE = { argento: { n: 'Argento', e: '🥈' }, oro: { n: 'Oro', e: '🥇' }, zaffiro: { n: 'Zaffiro', e: '🔷' }, rubino: { n: 'Rubino', e: '♦️' }, smeraldo: { n: 'Smeraldo', e: '💚' }, turchese: { n: 'Turchese', e: '💠' }, perla: { n: 'Perla', e: '🤍' }, ossidiana: { n: 'Ossidiana', e: '🖤' }, diamante: { n: 'Diamante', e: '💎' } };
/* IL PULSANTE CAMBIA CON IL TRAGUARDO (0.9.300), come su Duolingo ("Mirko ha appena raggiunto la Lega
   Diamante" con "Batti il 5"): ogni traguardo ha il suo titolo, il suo pulsante e la reazione che manda. */
const HD_CG_PULSANTE = {
  lega: { b: 'Batti il 5', r: 'grande', fatto: '🙌 Inviato' },
  serie: { b: 'Fai il tifo', r: 'continua', fatto: '🔥 Inviato' },
  livello: { b: 'Applaudi', r: 'grande', fatto: '👏 Inviato' },
  focus: { b: 'Fai i complimenti', r: 'centrato', fatto: '🎯 Inviato' },
  partita: { b: 'Incoraggia', r: 'nonmollare', fatto: '💪 Inviato' }
};
function hdCongratVisti(){ try{ return JSON.parse(localStorage.getItem(HD_CONGRAT_KEY) || '{}') || {}; }catch(_){ return {}; } }
function hdCongratTraguardo(v){
  const a = v.a || {};
  if (v.k === 'lega'){ const L = HD_CG_LEGHE[a.tier]; if (L) return { id: a.device + ':lega:' + a.tier, k: 'lega', e: L.e, t: hdEsc(a.nome) + ' ha raggiunto la Lega ' + L.n + '!' }; return null; }
  if (v.k === 'serie'){ const n = +a.streak || 0; if (n >= 3 && ([3, 5, 7, 10, 14, 21, 30, 50, 75, 100, 150, 200, 365].indexOf(n) >= 0 || n % 50 === 0)) return { id: a.device + ':serie:' + n, k: 'serie', e: '🔥', t: hdEsc(a.nome) + ' è a ' + n + ' giorni di fila!' }; return null; }
  if (v.k === 'livello'){ const n = +a.level || 0; if (n >= 2) return { id: a.device + ':livello:' + n, k: 'livello', e: '⭐', t: hdEsc(a.nome) + ' ha raggiunto il livello ' + n + '!' }; return null; }
  if (v.k === 'focus'){ const m = +a.ffMin7 || 0; if (m >= 120){ const ore = Math.floor(m / 60); return { id: a.device + ':focus:' + ore + ':' + hdK(Date.now()).slice(0, 7), k: 'focus', e: '⏳', t: hdEsc(a.nome) + ' ha fatto ' + ore + ' ore di Full Focus questa settimana!' }; } return null; }
  if (v.k === 'partita'){ if ((+a.neo || 0) >= (+a.old || 0) + 3) return { id: a.device + ':partita:' + a.neo, k: 'partita', e: '🚀', t: hdEsc(a.nome) + ' sta vincendo la partita ' + a.neo + ' a ' + a.old + ' per il nuovo sé!' }; return null; }
  return null;
}
async function hdCongratControlla(){
  try{
    if (document.hidden) return;
    const home = document.getElementById('s-home'); if (!home || !home.classList.contains('active')) return;
    if ((typeof DEC !== 'undefined' && DEC.open) || document.getElementById('hdCongrat')) return;
    let ultimo = 0; try{ ultimo = +localStorage.getItem('fl_congrat_at') || 0; }catch(_){ }
    if (Date.now() - ultimo < 4 * 3600000) return;
    if (typeof frAmiciCarica === 'function') await frAmiciCarica(false);
    const visti = hdCongratVisti();
    const voce = hdFeedVoci().map(function(v){ const g = hdCongratTraguardo(v); return g ? { v: v, g: g } : null; }).filter(function(x){ return x && !visti[x.g.id]; })[0];
    if (!voce) return;
    visti[voce.g.id] = Date.now();
    try{ localStorage.setItem(HD_CONGRAT_KEY, JSON.stringify(visti)); localStorage.setItem('fl_congrat_at', String(Date.now())); }catch(_){ }
    hdCongratMostra(voce.v, voce.g);
  }catch(_){ }
}
function hdCongratMostra(v, g){
  const w = document.createElement('div'); w.id = 'hdCongrat'; w.className = 'hd-cg';
  const P = HD_CG_PULSANTE[g.k || v.k] || { b: 'Congratulati', r: 'grande', fatto: '👏 Inviato' };
  w.innerHTML = '<div class="hd-cg-in"><i class="hd-cg-grab"></i>'
    + '<div class="hd-cg-av">' + (typeof frAv === 'function' ? frAv(v.a.nome, v.a.device) : '') + '<span class="hd-cg-e">' + (g.e || v.e) + '</span></div>'
    + '<h2>' + g.t + '</h2>'
    + '<button type="button" class="hd-cg-si" data-dev="' + hdEsc(v.a.device) + '" data-nome="' + hdEsc(v.a.nome) + '" data-r="' + P.r + '" data-fatto="' + hdEsc(P.fatto) + '" onclick="hdCongratInvia(this)">' + hdEsc(P.b) + '</button>'
    + '<button type="button" class="hd-cg-no" onclick="hdCongratChiudi()">Chiudi</button></div>';
  w.addEventListener('click', function(e){ if (e.target === w) hdCongratChiudi(); });
  (document.getElementById('phone') || document.body).appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ flVibra(12); }catch(_){ }
}
function hdCongratChiudi(){ const w = document.getElementById('hdCongrat'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 250); }
async function hdCongratInvia(btn){
  btn.disabled = true; btn.textContent = btn.dataset.fatto || '👏 Inviato';
  try{ flVibra([10, 30, 10]); }catch(_){ }
  /* i coriandoli partono dentro frReagisci (anche per gli amici dell'anteprima, dal 0.9.300); il foglio
     resta aperto finche' la festa non ha fatto il suo giro, poi si chiude */
  const t0 = Date.now();
  try{ if (typeof frReagisci === 'function') await frReagisci(btn.dataset.dev, btn.dataset.nome, btn.dataset.r || 'grande', null); }catch(_){ }
  setTimeout(hdCongratChiudi, Math.max(700, 1600 - (Date.now() - t0)));
}
setTimeout(hdCongratControlla, 6000);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(hdCongratControlla, 2500); });
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.hd-cg{position:fixed;inset:0;z-index:9400;display:flex;align-items:flex-end;background:rgba(0,20,45,.55);opacity:0;transition:opacity .25s}.hd-cg.in{opacity:1}',
    '.hd-cg-in{width:100%;box-sizing:border-box;border-radius:26px 26px 0 0;background:#0F1E33;color:#fff;text-align:center;padding:14px 26px calc(28px + env(safe-area-inset-bottom));transform:translateY(40px);transition:transform .3s cubic-bezier(.2,1,.3,1)}.hd-cg.in .hd-cg-in{transform:none}',
    '.hd-cg-grab{display:block;width:44px;height:5px;margin:0 auto 40px;border-radius:9px;background:rgba(255,255,255,.25)}',
    '.hd-cg-av{position:relative;width:120px;height:120px;margin:0 auto 32px}.hd-cg-av > *:first-child{width:120px!important;height:120px!important;font:900 46px var(--font-display)!important;border-radius:50%;display:grid!important;place-items:center;color:#fff}',
    '.hd-cg-e{position:absolute;right:-12px;top:-6px;width:46px;height:46px;border-radius:50%;background:#fff;display:grid;place-items:center;font-size:24px;box-shadow:0 6px 16px rgba(0,0,0,.3)}',
    '.hd-cg-in h2{margin:0 0 40px;font:800 24px/1.35 var(--font-display,var(--font-body))}',
    '.hd-cg-si{display:block;width:100%;border:0;border-radius:18px;padding:17px;background:#3F9FF4;color:#001E44;font:900 17px var(--font-body);letter-spacing:.06em;text-transform:uppercase;box-shadow:0 5px 0 #0075E3;cursor:pointer}',
    '.hd-cg-no{display:block;width:100%;margin-top:16px;border:0;background:none;color:#8CC6FF;font:800 15px var(--font-body);letter-spacing:.06em;text-transform:uppercase;padding:12px;cursor:pointer}'
  ].join('');
  document.head.appendChild(st);
})();

/* ---------- IL PIEDE «PERSONALIZZA» (0.9.203): in fondo a ogni scheda, come su Mediolanum ----------
   Il bordo tratteggiato dice «questa pagina la decidi tu». Sparisce se la Modalita' severa
   tiene ferma la pagina (scelta dell'utente nelle opzioni della severa). */
const HD_PIEDI = {
  'tab-rotta': { n: 'la scheda Sogno', f: "if(typeof cstApri==='function')cstApri()", dentro: '.nv-page' },
  'tab-mappa': { n: 'Mappa', f: "if(typeof scsApri==='function')scsApri((typeof mppVistaCur==='function'&&mppVistaCur()==='rotta')?'mappa-rotta':'mappa-mia')", nome: function(){ return (typeof mppVistaCur === 'function' && mppVistaCur() === 'rotta') ? 'Roadmap' : 'Mappa'; } },
  'tab-sveglia': { n: 'la scheda START', f: "if(typeof scsApri==='function')scsApri('start')" },
  's-blocco': { n: 'la pagina', f: "if(typeof scsApri==='function')scsApri('blocco')", dentro: '#blHost' }
};
const HD_PIU = '<svg class="hd-piede-piu" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 7.5v9M7.5 12h9"/></svg>';
const HD_TRATTO = '<svg class="hd-piede-b" aria-hidden="true"><rect/></svg>';
function hdPiedeInnesta(id){
  const casa = document.getElementById(id); const def = HD_PIEDI[id]; if (!casa || !def) return;
  const dove = def.dentro ? (casa.querySelector(def.dentro) || casa) : casa;
  let p = dove.querySelector(':scope > .hd-piede');
  let chiuso = false; try{ chiuso = cstBloccoSevera() && cstSeveraAccesa(); }catch(_){ }
  if (chiuso){ if (p) p.remove(); return; }
  if (!p){
    p = document.createElement('button'); p.type = 'button'; p.className = 'hd-piede'; dove.appendChild(p);
    p.innerHTML = HD_TRATTO + HD_PIU + '<span>Personalizza ' + def.n + '</span>';
    p.setAttribute('onclick', def.f);
  }
  if (def.nome){ const sp = p.querySelector('span'); if (sp) sp.textContent = 'Personalizza ' + def.nome(); }
  if (dove.lastElementChild !== p) dove.appendChild(p);
}
function hdPiediTutti(){ Object.keys(HD_PIEDI).forEach(hdPiedeInnesta); }
document.addEventListener('fl:tab', function(){ setTimeout(hdPiediTutti, 400); setTimeout(hdPiediTutti, 1400); });
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-blocco') setTimeout(function(){ hdPiedeInnesta('s-blocco'); }, 500); });
setTimeout(hdPiediTutti, 3000);

(function(){
  const css = [
    '.hd-pan{position:absolute;inset:0;z-index:9990;background:rgba(0,8,20,.62)}.hd-pan[hidden]{display:none}',
    '.hd-pan-in{background:var(--card,#fff);border-radius:0 0 26px 26px;padding:18px 20px 16px;transform:translateY(-100%);transition:transform .24s cubic-bezier(.2,.8,.3,1);box-shadow:0 18px 40px rgba(0,0,0,.25)}.hd-pan.in .hd-pan-in{transform:none}',
    'body.dark .hd-pan-in{background:#12203A}',
    '.hd-pan-in{position:relative}.hd-pan-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;z-index:2}body.dark .hd-pan-x{background:rgba(255,255,255,.1);color:#fff}',
    '.hd-pan-top{text-align:center}.hd-pan-pct b{font:900 44px/1 var(--font-display);color:var(--navy)}.hd-pan-pct small{display:block;margin-top:4px;font:700 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}',
    'body.dark .hd-pan-pct b{color:#fff}',
    '.hd-pan-bar{height:10px;border-radius:99px;background:rgba(0,117,227,.14);margin:14px 0 0;overflow:hidden}.hd-pan-bar i{display:block;height:100%;background:#0075E3;border-radius:99px}',
    '.hd-pan-sogno{margin:12px 0 0;font:600 14px var(--font-body);color:var(--navy)}body.dark .hd-pan-sogno{color:#fff}',
    '.hd-pan-righe{margin-top:16px;border-top:1px solid var(--line)}body.dark .hd-pan-righe{border-color:#22345A}',
    '.hd-pan-r{display:flex;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid var(--line)}body.dark .hd-pan-r{border-color:#22345A}.hd-pan-r > span{font-size:20px;width:28px;text-align:center}',
    '.hd-pan-r small{display:block;font:600 11.5px var(--font-body);color:var(--muted)}.hd-pan-r b{display:block;font:800 16px var(--font-body);color:var(--navy)}body.dark .hd-pan-r b{color:#fff}.hd-pan-r em{display:block;font:500 12px var(--font-body);font-style:normal;color:var(--muted)}',
    '.hd-pan-bot{display:flex;gap:8px;margin-top:12px}.hd-pan-link{flex:1;border:0;border-radius:12px;background:rgba(0,117,227,.1);color:var(--blue,#0075E3);font:700 13px var(--font-body);padding:11px 8px;cursor:pointer}',
    '.hd-ser .hd-pan-in{padding:0;height:100%;max-height:none;border-radius:0;display:flex;flex-direction:column}.hd-ser-top{display:grid;grid-template-columns:40px 1fr 40px;align-items:center;padding:calc(env(safe-area-inset-top,0px) + 12px) 12px 6px}.hd-ser-top b{text-align:center;font:800 19px var(--font-display);color:var(--navy)}body.dark .hd-ser-top b{color:#fff}.hd-ser-top .hd-x{color:var(--navy)}body.dark .hd-ser-top .hd-x{color:#fff}',
    '.hd-x{width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--muted);font-size:18px;cursor:pointer}.hd-ser-corpo{flex:1;overflow-y:auto;padding-bottom:40px}',
    '.hd-reaz-w{position:relative;display:inline-block}.hd-reaz-bar{position:absolute;left:0;bottom:calc(100% + 8px);display:none;gap:4px;padding:6px 8px;border-radius:99px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 10px 26px rgba(0,0,0,.18);z-index:3}.hd-reaz-bar.in{display:flex;animation:hdPop .18s cubic-bezier(.2,.9,.3,1.3) both}body.dark .hd-reaz-bar{background:#16233A;border-color:#22345A}',
    '.hd-reaz-bar button{width:40px;height:40px;border:0;border-radius:50%;background:transparent;font-size:24px;cursor:pointer}.hd-reaz-bar button:active{transform:scale(1.25)}@keyframes hdPop{from{opacity:0;transform:translateY(6px) scale(.9)}to{opacity:1;transform:none}}',
    '.hd-piede{position:relative;display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin:6px 0 10px;padding:20px 16px;border:0;border-radius:18px;background:transparent;color:var(--navy);font:700 15px var(--font-body);cursor:pointer}body.dark .hd-piede{color:#fff}',
    '.hd-piede-b{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;overflow:visible}.hd-piede-b rect{x:1.5px;y:1.5px;width:calc(100% - 3px);height:calc(100% - 3px);rx:18px;ry:18px;fill:none;stroke:#8FA4C2;stroke-width:2;stroke-dasharray:10 9}body.dark .hd-piede-b rect{stroke:#4A638F}',
    '.hd-piede-piu{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}',
    '#tab-rotta .nv-page > .hd-piede{grid-column:1/-1;margin:0}#tab-mappa > .hd-piede{width:calc(100% - 36px);margin:42px 18px 28px}#blHost > .hd-piede{width:calc(100% - 36px);margin:42px 18px 28px}#tab-sveglia > .hd-piede{margin:42px 0 24px}',
    '.hd-tabs{display:flex;border-bottom:2px solid var(--line)}.hd-tabs button{flex:1;border:0;background:transparent;padding:12px 0 10px;font:800 13px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);border-bottom:3px solid transparent;margin-bottom:-2px;cursor:pointer}.hd-tabs button.on{color:#0075E3;border-color:#0075E3}',
    /* serie di oggi non ancora fatta: la testata e la fiamma sono spente, come su Duolingo */
    '.hd-ser-testa.spenta{background:linear-gradient(135deg,#2A3B55,#1B2A42)!important}.hd-ser-testa.spenta .hd-ser-fiamma{filter:grayscale(1) brightness(.75);opacity:.55}.hd-ser-testa.spenta .hd-ser-num b,.hd-ser-testa.spenta .hd-ser-num small{color:#8FA3BF;text-shadow:none}',
    '.hd-fuoco.spento span{filter:grayscale(1);opacity:.55}.hd-fuoco.spento b{opacity:.65}',
    /* la bolla col punto esclamativo, come su Duolingo: la serie e' a rischio */
    '.hd-fuoco{position:relative}.hd-rischio{position:absolute;left:18px;bottom:0;width:15px;height:15px;border-radius:50%;background:#E63946;color:#fff;font:900 11px/15px var(--font-body);font-style:normal;text-align:center;box-shadow:0 0 0 1.5px #fff;animation:hdRischio 1.8s ease-in-out infinite}@keyframes hdRischio{50%{transform:scale(1.14)}}',
    '.hd-ser-card.urgente b{color:#E63946}',
    '.hd-ser-testa{display:grid;grid-template-columns:1fr auto;align-items:center;padding:26px 22px 20px;background:linear-gradient(135deg,#FF8A3D,#FFB347);color:#fff}.hd-ser-num b{display:block;font:900 60px/1 var(--font-display);text-shadow:0 3px 0 rgba(0,0,0,.18)}.hd-ser-num small{display:block;margin-top:8px;font:800 18px var(--font-body)}.hd-ser-fiamma{font-size:84px;line-height:1;filter:drop-shadow(0 8px 16px rgba(0,0,0,.25))}',
    '.hd-ser-pietra{grid-column:1/-1;margin:20px 0 0!important;color:#14234A}.hd-ser-pietra .txt b{display:block;font:800 17px var(--font-display,var(--font-body));color:#14234A}.hd-ser-pietra .txt p{margin:4px 0 0;font:500 14px/1.45 var(--font-body);color:#2A3B55}.hd-ser-pietra .txt{flex:1}.hd-ser-pietra .flame{position:relative;font-size:46px;line-height:1}.hd-ser-pietra .flame span{position:absolute;left:0;right:0;top:56%;transform:translateY(-50%);text-align:center;font:900 16px var(--font-body);color:#3A1A00}',
    '.hd-ser-card{grid-column:1/-1;display:flex;align-items:center;gap:14px;margin:20px 0 0;padding:14px 16px;border-radius:16px;background:rgba(0,19,43,.62);border:0}.hd-ser-card span{font-size:30px}.hd-ser-card p{margin:0;font:500 14px/1.5 var(--font-body);color:#fff}.hd-ser-card p b{color:#7FD3FF}',
    '.hd-ser-h{margin:26px 18px 10px;font:800 19px var(--font-display);color:var(--navy)}body.dark .hd-ser-h{color:#fff}',
    '.hd-cal{margin:0 18px;padding:12px 10px 14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .hd-cal{background:#12203A;border-color:#22345A}',
    '.hd-cal-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.hd-cal-top b{font:800 15px var(--font-body);color:var(--navy)}body.dark .hd-cal-top b{color:#fff}.hd-cal-top button{width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--navy);font-size:22px;cursor:pointer}body.dark .hd-cal-top button{color:#fff}',
    '.hd-cal-g,.hd-cal-d{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}.hd-cal-g span{text-align:center;font:800 11px var(--font-body);color:var(--muted)}',
    '.hd-cal-d i{height:38px;display:flex;align-items:center;justify-content:center;border-radius:50%;font:700 13.5px var(--font-body);font-style:normal;color:var(--muted)}',
    '.hd-cal-d i.fatto{background:#FFE3E6;color:#B91C2C;border:2px solid #E63946;font-weight:800}.hd-cal-d i.oggi{background:#E63946;color:#fff;font-weight:800;border:2px solid #E63946}.hd-cal-d i.coperto{padding:0;background:transparent}body.dark .hd-cal-d i.fatto{background:rgba(230,57,70,.22);color:#FFB3BA}',
    '.hd-ser-nota{display:flex;align-items:center;gap:10px;margin:14px 18px 0;font:500 13px/1.5 var(--font-body);color:var(--muted)}.hd-ser-nota > span{font-size:24px;flex:none}.hd-cal-d i.coperto{font-size:22px}',
    '.hd-ob-linea{display:flex;align-items:center;gap:0;margin:2px 0 12px}.hd-ob-tratto{flex:1;height:12px;margin:0 -2px;background:rgba(0,117,227,.14);overflow:hidden}.hd-ob-tratto i{display:block;height:100%;background:#0075E3}body.dark .hd-ob-tratto{background:#22345A}',
    '.hd-mc{position:relative;z-index:1;flex:none;display:inline-flex;flex-direction:column;width:38px;height:38px;border-radius:9px;background:#fff;border:2px solid #0075E3;overflow:hidden;box-shadow:0 2px 0 rgba(0,30,68,.12)}.hd-mc i{display:block;height:9px;background:#E63946}.hd-mc b{flex:1;display:flex;align-items:center;justify-content:center;font:900 14px var(--font-display);color:#001E44}.hd-mc.fatto{background:#0075E3}.hd-mc.fatto b{color:#fff}.hd-mc.mio{border-color:#9DB7D6}.hd-mc.mio i{background:#9DB7D6}',
    '.hd-ob-scegli{margin:14px 0 10px;font:700 13.5px var(--font-body);color:var(--navy)}body.dark .hd-ob-scegli{color:#fff}.hd-ob-scorri{display:flex;gap:10px;overflow-x:auto;scroll-snap-type:x mandatory;padding:4px 2px 8px;margin:0 -4px;scrollbar-width:none}.hd-ob-scorri::-webkit-scrollbar{display:none}.hd-ob-scorri button{flex:0 0 auto;scroll-snap-align:start;display:flex;flex-direction:column;align-items:center;gap:8px;min-width:86px;padding:12px 10px;border:1.5px solid var(--line);border-radius:16px;background:var(--card,#fff);cursor:pointer}.hd-ob-scorri button b{font:800 12.5px var(--font-body);color:var(--navy)}body.dark .hd-ob-scorri button{background:#12203A;border-color:#22345A}body.dark .hd-ob-scorri button b{color:#fff}.hd-ob-scorri button.on{border-color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.2)}',
    '.hd-ob{margin:0 18px;padding:16px 14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .hd-ob{background:#12203A;border-color:#22345A}.hd-ob-tappe{display:flex;justify-content:space-between;gap:6px}.hd-ob-tappe button{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;border:1.5px solid var(--line);border-radius:14px;background:transparent;padding:10px 4px;font:800 14px var(--font-body);color:var(--muted);cursor:pointer}.hd-ob-tappe button i{font-style:normal;font-size:22px}.hd-ob-tappe button.on{border-color:#0075E3;color:#0075E3;background:rgba(0,117,227,.1);box-shadow:0 0 0 4px rgba(0,117,227,.22),0 0 18px rgba(0,117,227,.45)}.hd-ob-tappe button.fatto{color:#0075E3}.hd-ob.chiuso .hd-ob-tappe button:not(.on){opacity:.45}body.dark .hd-ob-tappe button{border-color:#22345A}',
    '.hd-ob-bar{height:12px;border-radius:99px;background:rgba(0,117,227,.14);margin:14px 0 8px;overflow:hidden}.hd-ob-bar i{display:block;height:100%;background:#0075E3;border-radius:99px}.hd-ob small{display:block;font:700 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}',
    '.hd-comp{display:flex;align-items:center;gap:14px;margin:0 18px;padding:16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .hd-comp{background:#12203A;border-color:#22345A}.hd-comp > span{font-size:40px;line-height:1}.hd-comp p{margin:0;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .hd-comp p{color:#fff}.hd-comp.dentro{border-color:#0075E3}',
    '.hd-ser-card p{transition:opacity .25s}.hd-ser-card p.via{opacity:0}',
    '.hd-ser-card > div{flex:1}.hd-ser-cta{display:inline-block;margin-top:10px;border:0;border-radius:12px;background:#fff;color:#C2410C;font:800 13px var(--font-body);letter-spacing:.06em;text-transform:uppercase;padding:10px 16px;cursor:pointer}',
    '.hd-share{position:absolute;inset:0;z-index:9995;display:flex;flex-direction:column;background:#0B1424;color:#fff;opacity:0;transition:opacity .2s}.hd-share.in{opacity:1}.hd-share[hidden]{display:none}',
    '.hd-share-top{display:grid;grid-template-columns:40px 1fr 40px;align-items:center;padding:calc(env(safe-area-inset-top,0px) + 12px) 12px 6px}.hd-share-top b{text-align:center;font:800 19px var(--font-display)}.hd-share-top .hd-x{color:#fff}',
    '.hd-share-stage{flex:1;display:flex;align-items:center;justify-content:center;padding:18px 40px}.hd-share-img{max-height:100%;max-width:100%;border-radius:24px;box-shadow:0 24px 60px rgba(0,0,0,.5)}',
    '.hd-share-btn{display:flex;gap:14px;justify-content:center;padding:10px 24px calc(env(safe-area-inset-bottom,0px) + 34px)}.hd-share-b{display:flex;flex-direction:column;align-items:center;gap:8px;border:0;background:transparent;color:#fff;font:600 13px var(--font-body);cursor:pointer}.hd-share-b span{width:64px;height:64px;border-radius:50%;background:rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;font-size:26px}.hd-share-b.main span{background:#0075E3}',
    '.hd-slancio{padding:22px 20px 0}.hd-slancio .am-vuoto{padding:30px 20px 24px}.hd-slancio .am-vuoto h2.hd-sl-t{margin:16px auto 4px;max-width:18em;font:800 21px/1.35 var(--font-display);font-style:normal;color:#001E44}.hd-slancio .am-vuoto h2.hd-sl-t b{color:#E63946;font-weight:800}',
    '.hd-sl-cta{display:flex;align-items:center;justify-content:center;gap:10px;border-radius:50px}.hd-sl-cta svg{flex:none}',
    '.hd-vuoto{text-align:center;padding:40px 24px 0}.hd-vuoto span{font-size:54px}.hd-vuoto h3{margin:12px 0 6px;font:800 20px var(--font-display);color:var(--navy)}body.dark .hd-vuoto h3{color:#fff}.hd-vuoto p{margin:0 auto 18px;max-width:30ch;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.hd-feed{padding:6px 18px 0}.hd-feed-r{padding:16px 0;border-bottom:1px solid var(--line)}body.dark .hd-feed-r{border-color:#22345A}',
    '.hd-feed-top{display:flex;align-items:center;gap:10px}.hd-feed-top > div{flex:1}.hd-feed-top b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .hd-feed-top b{color:#fff}.hd-feed-top small{font:500 12px var(--font-body);color:var(--muted)}.hd-feed-e{font-size:30px}',
    '.hd-feed-r p{margin:10px 0 12px;font:500 15px/1.45 var(--font-body);color:var(--navy)}body.dark .hd-feed-r p{color:#fff}.hd-feed-r p b{font-weight:800}',
    '.hd-like{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:manipulation;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);padding:8px 14px;font:800 13px var(--font-body);color:var(--navy);cursor:pointer}.hd-like.on{background:rgba(0,117,227,.12);border-color:#0075E3;color:#0075E3}body.dark .hd-like{background:#16233A;border-color:#22345A;color:#fff}body.dark .hd-like.on{background:rgba(79,184,255,.18);border-color:#4FB8FF;color:#4FB8FF}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
