/* ===========================================================================================
   L'IMMAGINE DI UNA DIAPOSITIVA — due, una per tema

   PERCHÉ DUE. Una fotografia che sta bene sopra a una pagina chiara quasi mai sta bene sopra
   a una pagina scura, e viceversa: l'occhio giudica il contrasto fra l'immagine e quello che
   la circonda, non l'immagine da sola. Chiedere una sola immagine per tutti e due i temi vuol
   dire chiedere un compromesso, e un compromesso in grafica è una cosa che non piace a
   nessuno dei due. Quindi due, e chi ne mette una sola la vede in tutti e due i casi.

   PERCHÉ ESISTE QUESTA PAGINA. La frase di Alex Hormozi sopra alla scheda START non era testo:
   era dentro all'immagine. Scrivendoci sopra la propria frase si finiva con due testi
   sovrapposti, e non c'era modo di accorgersene prima di provarci. Il problema non era la
   frase — era che l'immagine non si poteva toccare. Adesso si può: cambiarla, toglierla (e
   allora resta il fondo scuro, con sopra solo il proprio testo), o rimettere quella di serie.

   DOVE VIVONO. Nel telefono, ridotte a 900 pixel di lato lungo e in JPEG: una fotografia da
   fotocamera, messa dentro così com'è, riempirebbe da sola la memoria del browser — ed è la
   stessa regola che vale per l'avatar, per la faccia della Modalità severa e per le scene del
   Mind Movie.
   =========================================================================================== */

const SI_KEY = 'fl_slide_img';

function siTutte(){
  try{ return JSON.parse(localStorage.getItem(SI_KEY) || '{}') || {}; }catch(_){ return {}; }
}
function siSalvaTutte(v){
  try{ localStorage.setItem(SI_KEY, JSON.stringify(v || {})); }catch(_){
    if (typeof toast === 'function') toast('Memoria piena: prova un\'immagine più piccola');
  }
}
function siId(key, i){ return String(key) + ':' + (i || 0); }

function siVoce(key, i){
  const v = siTutte()[siId(key, i)] || {};
  return { chiaro: v.chiaro || '', scuro: v.scuro || '', via: !!v.via };
}
function siSalvaVoce(key, i, patch){
  const tutte = siTutte();
  tutte[siId(key, i)] = Object.assign(siVoce(key, i), patch || {});
  siSalvaTutte(tutte);
}

function siScuro(){
  try{ return document.body.classList.contains('dark'); }catch(_){ return false; }
}

/** L'immagine da mostrare adesso: quella del tema in corso, o l'altra se c'è una sola. */
function siScelta(key, i){
  const v = siVoce(key, i);
  if (v.via) return 'none';
  const mia = siScuro() ? (v.scuro || v.chiaro) : (v.chiaro || v.scuro);
  return mia || '';
}

/* ---------------------------------------------------------------------------------------
   Applicare

   L'immagine di serie è scritta nell'attributo `style` della diapositiva, quindi toglierla
   cancellerebbe anche quella: prima di sostituirla la si mette da parte, una volta sola.
   --------------------------------------------------------------------------------------- */
function siSlide(key, i){
  const h = (typeof FL_HEROES !== 'undefined') ? FL_HEROES[key] : null;
  const host = h && document.getElementById(h.hostId);
  return host ? host.querySelector('.bh-slide[data-i="' + (i || 0) + '"]') : null;
}

function siApplica(key, i){
  const sl = siSlide(key, i);
  if (!sl) return;
  if (sl.dataset.siOrig === undefined){
    sl.dataset.siOrig = sl.style.getPropertyValue('--bh-img') || '';
  }
  const mia = siScelta(key, i);
  if (mia === 'none') sl.style.setProperty('--bh-img', 'none');
  else if (mia) sl.style.setProperty('--bh-img', 'url("' + mia.replace(/"/g, '') + '")');
  else if (sl.dataset.siOrig) sl.style.setProperty('--bh-img', sl.dataset.siOrig);
  else sl.style.removeProperty('--bh-img');
}

/** Rimette a posto tutte le diapositive che qualcuno ha personalizzato. */
function siApplicaTutte(){
  const tutte = siTutte();
  Object.keys(tutte).forEach(function(id){
    const p = id.split(':');
    siApplica(p[0], +p[1] || 0);
  });
}

/* Al cambio di tema le immagini cambiano con lui: è tutto il senso di averne due. */
document.addEventListener('fl:tema', siApplicaTutte);
document.addEventListener('fl:tab', function(){ setTimeout(siApplicaTutte, 400); });
setTimeout(siApplicaTutte, 3000);

/* ---------------------------------------------------------------------------------------
   La pagina
   --------------------------------------------------------------------------------------- */

let SI_KEY_CUR = '', SI_I_CUR = 0;

function slImgOpen(key, i){
  SI_KEY_CUR = key; SI_I_CUR = i || 0;
  goId('s-slideimg');
  siPaint();
}

function siPaint(){
  const box = document.getElementById('siBody');
  if (!box) return;
  const v = siVoce(SI_KEY_CUR, SI_I_CUR);
  const riq = function(quale, titolo, sotto){
    const u = v[quale];
    return '<div class="si-blocco">'
      + '<div class="si-t"><b>' + titolo + '</b><small>' + sotto + '</small></div>'
      + '<button type="button" class="si-prev ' + quale + '" onclick="siScegli(\'' + quale + '\')"'
      +   (u ? ' style="background-image:url(' + u.replace(/[()"]/g, '') + ')"' : '') + '>'
      +   (u ? '' : '<span>+</span>') + '</button>'
      + (u ? '<button type="button" class="si-togli" onclick="siPulisci(\'' + quale + '\')">Togli questa</button>' : '')
      + '</div>';
  };
  box.innerHTML =
      '<p class="hintline" style="padding:0 2px 16px">Due immagini, una per tema. Se ne metti '
    + 'una sola, vale per tutti e due.</p>'
    + riq('chiaro', '☀️ Tema chiaro', 'Quando l\'app è in modalità normale')
    + riq('scuro', '🌙 Tema scuro', 'Quando l\'app è in modalità scura')
    + '<div class="si-azioni">'
    +   '<button type="button" class="si-az' + (v.via ? ' on' : '') + '" onclick="siNessuna()">'
    +     (v.via ? '✓ Nessuna immagine' : 'Nessuna immagine') + '</button>'
    +   '<button type="button" class="si-az" onclick="siDiSerie()">Rimetti quella di serie</button>'
    + '</div>'
    + '<p class="hintline" style="padding:14px 2px 0">Senza immagine resta il fondo scuro, e '
    + 'sopra si legge solo la tua frase.</p>';
}

function siScegli(quale){
  siFoto(function(dati){
    siSalvaVoce(SI_KEY_CUR, SI_I_CUR, { via: false });
    const p = {}; p[quale] = dati;
    siSalvaVoce(SI_KEY_CUR, SI_I_CUR, p);
    siApplica(SI_KEY_CUR, SI_I_CUR);
    siPaint();
    if (typeof toast === 'function') toast('Immagine salvata su questo telefono');
  });
}

function siPulisci(quale){
  const p = {}; p[quale] = '';
  siSalvaVoce(SI_KEY_CUR, SI_I_CUR, p);
  siApplica(SI_KEY_CUR, SI_I_CUR);
  siPaint();
}

function siNessuna(){
  const v = siVoce(SI_KEY_CUR, SI_I_CUR);
  siSalvaVoce(SI_KEY_CUR, SI_I_CUR, { via: !v.via });
  siApplica(SI_KEY_CUR, SI_I_CUR);
  siPaint();
}

function siDiSerie(){
  const tutte = siTutte();
  delete tutte[siId(SI_KEY_CUR, SI_I_CUR)];
  siSalvaTutte(tutte);
  siApplica(SI_KEY_CUR, SI_I_CUR);
  siPaint();
  if (typeof toast === 'function') toast('Rimessa quella di serie');
}

/* La fotografia: ridotta prima di essere tenuta, e SENZA ritagliarla quadrata — una
   diapositiva è larga, e un ritaglio quadrato le taglierebbe via i lati. */
function siFoto(dopo){
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    const fr = new FileReader();
    fr.onload = function(){
      const img = new Image();
      img.onload = function(){
        try{
          const L = 900;
          const scala = Math.min(1, L / Math.max(img.width, img.height));
          const cv = document.createElement('canvas');
          cv.width = Math.round(img.width * scala);
          cv.height = Math.round(img.height * scala);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          let out = cv.toDataURL('image/jpeg', 0.8);
          if (out.length > 500000) out = cv.toDataURL('image/jpeg', 0.62);
          dopo(out);
        }catch(e){ if (typeof toast === 'function') toast('Immagine troppo grande'); }
      };
      img.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questa immagine'); };
      img.src = fr.result;
    };
    fr.readAsDataURL(f);
  });
  document.body.appendChild(inp);
  inp.click();
}

registerScreen('s-slideimg',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button>'
  + '<b class="blk-title">L\'immagine della diapositiva</b></div>'
  + '<div id="siBody"></div><div class="spacer"></div>', { back: 's-home' });

(function siStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.si-blocco{background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;',
      'padding:14px;margin-bottom:12px}',
    '.si-t b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}',
    'body.dark .si-t b{color:#fff}',
    '.si-t small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.si-prev{display:block;width:100%;height:140px;margin-top:12px;border:1.5px dashed var(--line);',
      'border-radius:14px;background-size:cover;background-position:center;cursor:pointer;',
      'display:flex;align-items:center;justify-content:center}',
    '.si-prev.chiaro{background-color:#EEF3FA}',
    '.si-prev.scuro{background-color:#0E1B33}',
    '.si-prev span{font:300 38px/1 var(--font-body);color:var(--blue)}',
    '.si-togli{display:block;margin:10px auto 0;border:0;background:transparent;color:#E5515F;',
      'font:700 12.5px var(--font-body);cursor:pointer}',
    '.si-azioni{display:flex;gap:10px;flex-wrap:wrap;margin-top:6px}',
    '.si-az{flex:1;min-width:140px;border:1px solid var(--line);background:var(--card,#fff);',
      'border-radius:99px;padding:12px;font:700 12.5px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .si-az{color:#fff}',
    '.si-az.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .si-az.on{background:#fff;color:#0E1B33}'
  ].join('\n');
  document.head.appendChild(st);
})();
