/* ===========================================================================================
   LE CITAZIONI CHE CAMBIANO OGNI GIORNO

   Due frasi stavano ferme da sempre sotto ai titoli della scheda START: quella dei due conigli
   sotto «Prima: quale cosa», quella di Parkinson sotto «Una cosa alla volta». Una frase che non
   cambia mai smette di essere letta dopo tre giorni — diventa parte della cornice, come il
   bordo di un quadro. Qui ce ne sono due mazzi, e ogni giorno esce quella dopo.

   COME SI SCEGLIE, e perché non a caso. L'indice è il numero di giorni dal 1970 diviso per la
   lunghezza del mazzo: la frase è LA STESSA per tutta la giornata (riaprire l'app dieci volte
   non la cambia, e una frase che salta a ogni ritorno è rumore), cambia da sola a mezzanotte,
   e il giro completo non ripete mai due volte la stessa prima di aver finito il mazzo. I due
   mazzi hanno lunghezze diverse: le coppie che si incontrano cambiano quasi ogni giorno.

   L'ANIMAZIONE. Compare quando entra davvero nello schermo, non al disegno della pagina: una
   frase che si anima mentre nessuno la guarda è un'animazione sprecata. Sale di quattordici
   pixel, si mette a fuoco (il blur che si dissolve è quello che la fa sembrare "stampata"
   addosso), e l'autore arriva un sesto di secondo dopo — l'occhio legge prima la frase.
   =========================================================================================== */

/* ------------------------------------------------------------------ 1 · QUALE COSA
   Sotto «Prima: quale cosa»: scegliere l'unica cosa, e il prezzo del non sceglierla. */
const CIT_UNA = [
  /* 0.9.337, Andrea */
  ['Ricorda che non ottenere ciò che vuoi a volte è un meraviglioso colpo di fortuna.', 'Dalai Lama'],
  ['Ogni progresso avviene fuori dalla zona di comfort.', 'Michael John Bobak'],
  ['Chi insegue due conigli non ne prende nessuno.', 'Gary Keller, The One Thing'],
  ['Il task switching è come spegnere e riaccendere continuamente il motore della tua mente. Consumi più carburante e ci metti più tempo ad arrivare a destinazione.', 'Moya Sarner'],
  ['Non esiste il multitasking. Esiste solo il task switching veloce, e ha un prezzo biologico molto alto in termini di stanchezza mentale.', 'Daniel Levitin'],
  ['Pensiamo di essere efficienti perché ci muoviamo velocemente tra le cose, ma stiamo solo confondendo il movimento con il progresso.', 'Francis Picabia'],
  ['Il segreto per produrre di più non è lavorare più ore, ma eliminare le falle invisibili causate dal context switching e massimizzare la densità di ogni singolo minuto.', 'Cal Newport'],
  ['La semplicità batte la frammentazione. Quando riduci all’osso il numero di progetti attivi, la velocità di rilascio sul mercato raddoppia.', 'Cal Newport'],
  ['Dire sì a un compito secondario significa dire automaticamente no all’unico progetto straordinario che avrebbe spostato l’ago della bilancia.', 'Cal Newport'],
  ['Chiudere deliberatamente la giornata lavorativa e staccare del tutto la mente non è pigrizia: è il prerequisito biologico per avere intensità cognitiva il giorno successivo.', 'Cal Newport'],
  ['Fai meno cose. Fanne di più importanti. Falle con uno standard di qualità che nessun altro può replicare.', 'Cal Newport'],
  ['La chiarezza su ciò che conta davvero fornisce immediata chiarezza su tutto ciò che deve essere spietatamente ignorato.', 'Cal Newport'],
  ['Il segreto delle persone di successo è la capacità di dirigere la propria attenzione su un unico punto fermo finché non è completato.', 'Og Mandino'],
  ['Ogni volta che passi da un compito all’altro, lasci un residuo di attenzione sul compito precedente. La tua mente non si sposta in modo pulito.', 'Cal Newport'],
  ['Il multitasking è semplicemente l’opportunità di rovinare più di una cosa alla volta.', 'Steve Uzzel'],
  ['Il multitasking è un mito. In realtà è switch-tasking, e ha un costo enorme.', 'Dave Crenshaw'],
  ['Concentra tutti i tuoi pensieri sul lavoro che hai per le mani. I raggi del sole non bruciano finché non vengono messi a fuoco.', 'Alexander Graham Bell'],
  ['Aggiungere un secondo progetto al tuo flusso di lavoro ti costa il 20% del tuo tempo in context switching. Aggiungerne un terzo te ne costa il 50%.', 'Gerald Weinberg'],
  ['Il modo più breve per fare molte cose è farne solo una alla volta.', 'Wolfgang Amadeus Mozart'],
  ['Le cose che contano di più non devono mai essere in balia delle cose che contano di meno.', 'Johann Wolfgang von Goethe'],
  ['Sii come un francobollo: attaccati a una cosa fino ad arrivare a destinazione.', 'Josh Billings'],
  ['Il multitasking nasce dalla distrazione stessa.', 'Marilyn vos Savant'],
  ['La nostra capacità di attenzione è limitata, e ogni volta che cambiamo compito paghiamo una pesante penalità cognitiva.', 'Gloria Mark'],
  ['Quando provi a fare tutto, finisci per non fare nulla.', 'Aristotele'],
  ['Sono coloro che si concentrano su una sola cosa alla volta che avanzano in questo mondo.', 'Og Mandino'],
  ['Il successo richiede singolarità di intenti.', 'Vince Lombardi'],
  ['La mancanza di direzione, non la mancanza di tempo, è il problema. Tutti abbiamo giornate di ventiquattro ore.', 'Zig Ziglar'],
  ['Il multitasking divide la tua attenzione e moltiplica vertiginosamente le tue probabilità di commettere un errore.', 'Anonimo'],
  ['Il passaggio da un’attività all’altra impone un pedaggio sulla produttività. Ci vuole tempo per tornare esattamente al punto in cui eri.', 'Devora Zack'],
  ['La maggior parte delle volte il multitasking è pura illusione. Pensi di essere produttivo, ma stai solo sprecando tempo ed energie nella transizione.', 'Bosco Tjan'],
  ['La concentrazione è una questione di decidere quali cose NON farai.', 'John Carmack'],
  ['Il segreto non è dare priorità a ciò che è in programma, ma programmare le tue priorità.', 'Stephen Covey'],
  ['In un’era di continue distrazioni, niente può sembrare più lussuoso e potente del prestare attenzione totale.', 'Pico Iyer'],
  ['L’efficienza è fare le cose nel modo giusto; l’efficacia è fare solo la cosa giusta.', 'Peter Drucker'],
  ['Il context switching è la tassa silenziosa e spietata che paghiamo sull’ambizione senza disciplina. Riduci l’orizzonte, colpisci un solo bersaglio alla volta.', 'Anonimo'],
  ['Fino a quando la mia Unica Cosa non è completata, tutto il resto è una distrazione.', 'Gary Keller'],
  ['Non è che abbiamo troppo poco tempo per fare tutte le cose che dobbiamo fare: è che sentiamo il bisogno di fare troppe cose nel tempo che abbiamo.', 'Gary Keller'],
  ['Quando tutto sembra urgente e importante, tutto sembra uguale. Diventiamo attivi e indaffarati, ma questo non ci avvicina minimamente al successo.', 'Gary Keller'],
  ['Se tutti hanno lo stesso numero di ore nel giorno, perché alcuni ottengono molto di più? Perché vanno dritti al cuore delle cose.', 'Gary Keller'],
  ['La produttività non è lavorare come un mulo, essere sempre impegnati o fare gli straordinari: riguarda priorità, pianificazione e strenua difesa del proprio tempo.', 'Gary Keller'],
  ['Ottenere risultati straordinari significa creare un effetto domino nella tua vita.', 'Gary Keller'],
  ['Puoi avere successo con meno disciplina di quanto pensi, per un semplice motivo: il successo riguarda il fare la cosa giusta, non il fare tutto nel modo giusto.', 'Gary Keller'],
  ['Il successo si costruisce in modo sequenziale. È una cosa alla volta.', 'Gary Keller'],
  ['Qual è l’Unica Cosa che posso fare, facendo la quale tutto il resto diventerà più semplice o non necessario?', 'Gary Keller'],
  ['Ciò che temiamo di più fare è di solito ciò che abbiamo più bisogno di fare.', 'Tim Ferriss'],
  ['L’informazione è inutile se non viene applicata a qualcosa di importante, o se la dimenticherai prima di avere la possibilità di applicarla.', 'Tim Ferriss'],
  ['È del tutto possibile fare un sacco di cose e non concludere ancora nulla.', 'Tim Ferriss'],
  ['Lavorando solo quando sei più efficace, la vita è sia più produttiva che più piacevole.', 'Tim Ferriss'],
  ['La Legge di Parkinson stabilisce che un compito si gonfierà di importanza e complessità percepite in relazione al tempo assegnato per il suo completamento.', 'Tim Ferriss'],
  ['Chiediti sempre: se questo fosse l’unico compito che portassi a termine oggi, sarei soddisfatto della mia giornata?', 'Tim Ferriss'],
  ['La mancanza di tempo è in realtà una mancanza di priorità.', 'Tim Ferriss'],
  ['L’azione non è solo l’effetto della motivazione: ne è anche la causa.', 'Tim Ferriss'],
  ['Inizia con la fine in mente.', 'Stephen Covey'],
  ['Devi decidere quali sono le tue priorità assolute e avere il coraggio, sorridendo e senza scusarti, di dire no ad altre cose.', 'Stephen Covey'],
  ['Non sono un prodotto delle mie circostanze. Sono un prodotto delle mie decisioni.', 'Stephen Covey'],
  ['L’abitudine è l’intersezione tra conoscenza (cosa fare), abilità (come fare) e desiderio (voler fare).', 'Stephen Covey'],
  ['Non puoi risolvere un problema con lo stesso tipo di pensiero che hai usato per crearlo.', 'Albert Einstein']
];

/* ------------------------------------------------------------------ 2 · UNA COSA ALLA VOLTA
   Sotto «Una cosa alla volta»: il tempo che si gonfia, e il lavoro profondo. */
const CIT_TEMPO = [
  ['Il lavoro si espande fino a occupare tutto il tempo disponibile per il suo completamento.', 'Cyril N. Parkinson'],
  ['La concentrazione è la radice di tutte le capacità umane.', 'Bruce Lee'],
  ['Senza una barriera temporale definita, il lavoro si espande fino a occupare ogni singolo spazio mentale disponibile, divorando il riposo necessario alla performance.', 'Cal Newport'],
  ['Non puoi produrre risultati da fuoriclasse se il tuo flusso cognitivo viene spezzato ogni dieci minuti da micro-comunicazioni asincrone.', 'Cal Newport'],
  ['Il passaggio continuo da un task all’altro non è solo inefficiente: frammenta e usura irreparabilmente i tuoi circuiti neurali.', 'Cal Newport'],
  ['Tratta i tuoi blocchi di concentrazione profonda con la stessa inviolabile sacralità con cui tratteresti un incontro con il cliente più importante della tua vita.', 'Cal Newport'],
  ['Se vuoi che il tuo lavoro sia preso sul serio, devi prendere sul serio la protezione del tuo focus.', 'Cal Newport'],
  ['Per vincere con il lavoro profondo devi eliminare la forza di volontà dall’equazione, attraverso rituali, orari fissi e ambienti blindati.', 'Cal Newport'],
  ['La capacità di concentrarsi intensamente è un muscolo che va allenato sistematicamente, non un interruttore che puoi accendere a piacimento solo quando sei ispirato.', 'Cal Newport'],
  ['Se organizzi la tua vita per evitare a tutti i costi la noia, stai implicitamente addestrando il tuo cervello a perdere la capacità di concentrarsi.', 'Cal Newport'],
  ['Se non pianifichi e controlli tu la tua giornata, il mondo esterno userà il tuo tempo per raggiungere i propri scopi.', 'Cal Newport'],
  ['L’attenzione costante e ininterrotta è il nuovo quoziente intellettivo dell’era digitale.', 'Cal Newport'],
  ['Quando passi da un compito A a un compito B la tua attenzione non si sposta all’istante: un residuo resta ancorato al compito precedente, sabotando la tua lucidità.', 'Cal Newport'],
  ['Anche una rapida occhiata alle notifiche, di cinque secondi, innesca un residuo di attenzione che degrada le prestazioni cognitive per i venti minuti successivi.', 'Cal Newport'],
  ['Il lavoro profondo è la capacità di concentrarsi senza distrazioni su un compito cognitivamente impegnativo.', 'Cal Newport'],
  ['La capacità di svolgere lavoro profondo sta diventando sempre più rara esattamente nel momento in cui diventa sempre più preziosa. Chi la padroneggia dominerà il mercato.', 'Cal Newport'],
  ['Nell’era della distrazione, fare una cosa alla volta è un superpotere.', 'Greg McKeown'],
  ['In un mondo pieno di distrazioni, la concentrazione è il superpotere più grande.', 'Anonimo']
];

/* I nomi con cui i due mazzi vengono chiesti: `scelta` è quello sotto «Prima: quale cosa»,
   `profondo` quello sotto «Una cosa alla volta». Gli altri due nomi restano validi perché
   dicono la stessa cosa, e un richiamo rimasto in giro non deve lasciare un buco. */
/* I nomi con cui i due mazzi vengono chiesti: `scelta` è quello della prima sezione,
   `profondo` quello della seconda. Gli altri due nomi restano validi perché dicono la stessa
   cosa, e un richiamo rimasto in giro non deve lasciare un buco. */
/* I nomi con cui i due mazzi vengono chiesti: `scelta` è quello della prima sezione,
   `profondo` quello della seconda. Gli altri due nomi restano validi perché dicono la stessa
   cosa, e un richiamo rimasto in giro non deve lasciare un buco. */
const CIT_MAZZI = { scelta: CIT_UNA, una: CIT_UNA, profondo: CIT_TEMPO, tempo: CIT_TEMPO };

/* ===========================================================================================
   I TITOLI DELLE DUE SEZIONI, uno al giorno, con una parola cerchiata a mano

   Stesso effetto della sezione «Image with text» del sito: il titolo sale, e sei decimi dopo
   una matita gira intorno alla parola che regge la frase. Cambiano ogni giorno come le
   citazioni, e la parola cerchiata cambia con loro — il cerchio si nota perché è raro, e
   sarebbe sprecato sempre sulla stessa parola.

   Il secondo mazzo ha una voce che NON è in rotazione: «You're closer than you think» esce
   solo quando l'utente sta tirando una serie di sessioni. Una frase che dice «ci sei quasi»
   detta a chi non ha fatto niente è una bugia; detta dopo tre sessioni in tre giorni è la
   cosa giusta al momento giusto. */
const CIT_TITOLI = {
  /* 1 · la scelta: una cosa sola */
  focus: [
    ['Una cosa alla volta', 'Una'],
    ['La concentrazione profonda porta risultati rari', 'profonda'],
    ['La concentrazione decide il successo', 'decide'],
    ['La concentrazione crea lo slancio', 'slancio'],
    ['La concentrazione rende chiaro lo scopo', 'chiaro'],
    ['Non ti serve più tempo, ti serve più concentrazione', 'concentrazione']
  ],
  /* 2 · la spinta: entra e fallo adesso */
  spinta: [
    ['Se non ora, quando?', 'ora'],
    ['La magia che cerchi è nel lavoro che stai evitando', 'magia'],
    ['La comodità uccide la crescita', 'uccide'],
    ['I sogni non funzionano se non lavori tu', 'lavori'],
    ['La meta ama chi non molla', 'meta'],
    ['Il tuo prossimo capitolo comincia qui', 'qui'],
    ['Meglio fatto che perfetto', 'fatto'],
    ['Ottieni ciò per cui lavori, non ciò che desideri', 'lavori'],
    ['Volo verso la vita dei miei sogni', 'Volo'],
    ['L’avventura ti chiama', 'avventura'],
    ['La comodità uccide più sogni del fallimento', 'uccide'],
    ['Mi fido del prossimo capitolo perché conosco l’autore', 'autore'],
    ['Lo sto facendo succedere', 'succedere'],
    ['Carpe diem', 'Carpe']
  ],
  /* fuori rotazione: si guadagna */
  vicino: [['Sei più vicino di quanto pensi', 'vicino']]
};
const CIT_COL = { focus: '#0075E3', spinta: '#E63946', vicino: '#1B9E6A' };

/** I giorni dal 1970, in ora locale: è il numero che fa girare tutto, e cambia a mezzanotte. */
function citGiorno(){
  const d = new Date();
  return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000);
}

/* ------------------------------------------------------------------ lo scoccare della mezzanotte
   La frase, il titolo con la parola cerchiata e l'oblo' si calcolano quando una sezione si
   disegna: con l'app lasciata aperta sul telefono, a mezzanotte nessuno la ridisegnava e la
   frase di ieri restava li' (Andrea, 14/10/2026). Un orologio controlla il numero del giorno:
   al cambio manda `fl:giorno`, e le sezioni che hanno una frase del giorno si ridisegnano.
   Il timer della WebView in sottofondo puo' dormire: per questo si controlla anche al ritorno
   in primo piano e ogni minuto, non solo allo scadere del conto alla rovescia. */
let CIT_GIORNO_VISTO = citGiorno();
let CIT_GIORNO_T = 0;
function citControllaGiorno(){
  const g = citGiorno();
  if (g !== CIT_GIORNO_VISTO){
    CIT_GIORNO_VISTO = g;
    try{ document.dispatchEvent(new CustomEvent('fl:giorno', { detail: g })); }catch(_){ }
  }
  clearTimeout(CIT_GIORNO_T);
  const d = new Date(); const mezzanotte = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, 0, 0, 1).getTime();
  CIT_GIORNO_T = setTimeout(citControllaGiorno, Math.max(1000, Math.min(mezzanotte - Date.now(), 60000)));
}
setTimeout(citControllaGiorno, 1500);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') citControllaGiorno(); });

function citDelGiorno(quale){
  const m = CIT_MAZZI[quale] || CIT_UNA;
  /* uno sfasamento per mazzo, così i due non si muovono all'unisono */
  const off = (quale === 'tempo' || quale === 'profondo') ? 5 : 0;
  return m[((citGiorno() + off) % m.length + m.length) % m.length];
}
function citEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x == null ? '' : x); }

/** Quante sessioni di concentrazione portate a termine negli ultimi `g` giorni. */
function citSessioni(g){
  try{
    const da = Date.now() - (g || 1) * 86400000;
    return (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [])
      .filter(function(x){ return x && x.ok && x.at >= da; }).length;
  }catch(_){ return 0; }
}
/** In serie: tre sessioni in tre giorni. È la condizione che sblocca «You're closer…». */
function citInSerie(){ return citSessioni(3) >= 3; }

/* ===========================================================================================
   IL TITOLO CON LA PAROLA CERCHIATA
   =========================================================================================== */
const FL_CIRCLE_PATH = 'M180,25 C130,5 30,5 15,40 C5,75 60,90 140,85 C190,82 200,50 180,35';

/** Il titolo, con `parola` cerchiata. La parola deve comparire nel testo, o non si cerchia niente. */
function flTitolo(testo, parola, colore){
  const t = citEsc(testo);
  const p = citEsc(parola || '');
  const dentro = p && t.indexOf(p) >= 0;
  const corpo = dentro
    ? t.replace(p, '<span class="fl-hl">' + p
        + '<svg class="fl-hl-svg" viewBox="0 0 200 90" preserveAspectRatio="none" aria-hidden="true">'
        + '<path d="' + FL_CIRCLE_PATH + '" vector-effect="non-scaling-stroke" stroke="' + (colore || '#0075E3') + '"/></svg></span>')
    : t;
  return '<h2 class="fl-titolo fl-anim">' + corpo + '</h2>';
}
/** Il titolo di oggi per una sezione: `focus` o `spinta`. */
function flTitoloDelGiorno(quale){
  if (quale === 'spinta' && citInSerie()){
    const v = CIT_TITOLI.vicino[0];
    return flTitolo(v[0], v[1], CIT_COL.vicino);
  }
  const m = CIT_TITOLI[quale] || CIT_TITOLI.focus;
  const off = quale === 'spinta' ? 3 : 0;
  const t = m[((citGiorno() + off) % m.length + m.length) % m.length];
  return flTitolo(t[0], t[1], CIT_COL[quale] || '#0075E3');
}

/* ===========================================================================================
   LA MACCHINA DA SCRIVERE

   Alla stessa velocità della frase del giorno della scheda Blocco: 55 millisecondi per
   lettera, con il cursore che lampeggia davanti all'ultima. Ventidue era una raffica: si
   leggeva la fine prima di aver cominciato l'inizio, e allora tanto valeva scriverla tutta.
   =========================================================================================== */
const CIT_MS = 55;
function citBatti(el, testo, dopo){
  const box = el.querySelector('.cit-t');
  if (!box) return;
  if (el._t){ clearTimeout(el._t); el._t = 0; }
  box.innerHTML = '';
  const chars = Array.from('\u00ab' + testo + '\u00bb');
  const cur = document.createElement('span');
  cur.className = 'typewriter-cursor cit-cur'; cur.textContent = '|';
  box.appendChild(cur);
  let i = 0;
  const passo = function(){
    if (!document.body.contains(el)){ el._t = 0; return; }
    if (i < chars.length){
      const sp = document.createElement('span');
      sp.className = 'typewriter-char visible'; sp.textContent = chars[i++];
      box.insertBefore(sp, cur);
      el._t = setTimeout(passo, CIT_MS);
      return;
    }
    el._t = 0;
    setTimeout(function(){ try{ cur.remove(); }catch(_){ } }, 1600);
    const a = el.querySelector('.cit-a');
    if (a){ a.textContent = '~ ' + (el.dataset.autore || ''); a.classList.add('in'); }
    if (dopo) dopo();
  };
  el._t = setTimeout(passo, 40);
}

/* ===========================================================================================
   LA CITAZIONE È UNA DIAPOSITIVA, E SI GUADAGNA

   Sotto al titolo rubava l'occhio a quello che c'è da fare. Adesso è la SECONDA diapositiva
   del carosello, di fianco al pannello che conta: chi la vuole ci arriva con un dito, e chi
   sta lavorando non se la trova davanti. Chiusa finché la giornata non ha prodotto qualcosa —
   il mazzo della scelta si apre scrivendo la priorità, quello del lavoro profondo facendola
   dentro a una sessione.
   =========================================================================================== */
function citChiave(quale){
  const d = new Date();
  return 'fl_cit_' + quale + '_' + d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
/** `scelta`: basta aver scritto la priorità di oggi. `profondo`: averla fatta in sessione. */
function citGuadagnata(quale){
  const k = citChiave(quale);
  try{ if (localStorage.getItem(k) === '1') return true; }catch(_){ }
  let ok = false;
  try{
    const day = stDayKey();
    if (quale === 'scelta'){
      ok = !!stPriorita(day);
    } else {
      const serve = (typeof refRules === 'function') ? refRules().needSession !== false : true;
      ok = stRigheDi(day).some(function(r){
        if (!stIsDone(r, day)) return false;
        if (typeof stEtichetta === 'function' && !stEtichetta(r).importante) return false;
        return !serve || ((typeof refSessionFor === 'function') && !!refSessionFor(r, day));
      });
    }
  }catch(_){ }
  if (ok){ try{ localStorage.setItem(k, '1'); }catch(_){ } }
  return ok;
}
const CIT_PERCHE = {
  scelta:   ['Scrivi la priorità di oggi', 'La frase di oggi si apre quando hai deciso qual è la tua unica cosa.'],
  profondo: ['Falla dentro a una sessione', 'La frase di oggi si apre quando porti a termine la tua priorità in FullFocus.']
};
/** Il pannello-diapositiva della citazione. */
function citSlide(quale){
  const c = citDelGiorno(quale);
  const ok = citGuadagnata(quale);
  const p = CIT_PERCHE[quale] || CIT_PERCHE.scelta;
  return '<div class="cit-slide" id="citSlide-' + quale + '" data-cit="' + quale + '">'
    + (ok
        ? '<p class="cit-occhiello">La frase di oggi</p>'
          + '<p class="cit-grande" data-autore="' + citEsc(c[1]) + '" data-testo="' + citEsc(c[0]) + '">'
          +   '<span class="cit-t"></span><i class="cit-a"></i></p>'
        : '<div class="cit-chiusa"><span>\ud83d\udd12</span><div><b>' + p[0] + '</b><small>' + p[1] + '</small></div></div>')
    + '</div>';
}
/** Scrive la citazione di una diapositiva, se è aperta e non l'ha già fatto. */
function citBattiSlide(quale){
  const box = document.getElementById('citSlide-' + quale);
  if (!box) return;
  const p = box.querySelector('.cit-grande');
  if (!p || p.dataset.fatta) return;
  p.dataset.fatta = '1';
  citBatti(p, p.dataset.testo || '');
}
/** Quando la giornata cambia stato (priorità scritta, priorità fatta) le diapositive si rifanno. */
function citAggiornaPremio(){
  ['scelta', 'profondo'].forEach(function(q){
    const box = document.getElementById('citSlide-' + q);
    if (!box || box.querySelector('.cit-grande') || !citGuadagnata(q)) return;
    box.outerHTML = citSlide(q);
  });
}

/* ===========================================================================================
   L'OBLÒ: la stessa ora che c'è fuori

   Sei foto dal finestrino, una per momento della giornata. Chi apre l'app alle sette vede
   l'alba, chi la apre a mezzanotte vede la luna: è la stessa cosa che vedrebbe guardando
   fuori, ed è il modo più economico di far sentire un'app viva.
   =========================================================================================== */
function obloDelMomento(){
  const h = new Date().getHours();
  if (h < 5)  return 'notte';
  if (h < 8)  return 'alba';
  if (h < 16) return 'giorno';
  if (h < 18) return 'tramonto';
  if (h < 20) return 'sera';
  if (h < 22) return 'crepuscolo';
  return 'notte';
}
function obloSrc(){ return 'img/oblo/' + obloDelMomento() + '.jpg'; }

/* ------------------------------------------------------------------ i titoli delle altre sezioni
   Gli stessi titoli con la matita, anche fuori dalla scheda START. Si trasformano quando
   compaiono nel DOM, qualunque file li abbia scritti: cosi' nessuna sezione deve sapere che
   esiste la matita, e una sezione nuova la eredita da sola. La parola cerchiata e' scelta qui;
   un titolo che non e' in lista si anima lo stesso, senza cerchio. */
const CIT_CERCHI = {
  'Mind Movie': ['Movie', '#0075E3'],
  'La tua mappa': ['mappa', '#0075E3'],
  'Doom-scrolling apps': ['Doom', '#E63946']
};
function citTitoliAuto(){
  document.querySelectorAll('.sev-intro > h2:not(.fl-titolo)').forEach(function(h){
    const t = (h.textContent || '').trim();
    const c = CIT_CERCHI[t];
    const wrap = document.createElement('div');
    wrap.innerHTML = flTitolo(t, c ? c[0] : '', c ? c[1] : '#0075E3');
    const nuovo = wrap.firstChild;
    if (!nuovo) return;
    h.parentNode.replaceChild(nuovo, h);
  });
}
/* Le sezioni si ridisegnano quando vogliono: chi appare dopo l'evento della scheda deve
   trovare la matita lo stesso. Un osservatore sulle mutazioni, con un respiro di 120 ms. */
let CIT_MUT_T = 0;
(function citOsservaMutazioni(){
  const radice = document.getElementById('phone') || document.body;
  if (!radice || !('MutationObserver' in window)) return;
  /* 0.9.263: solo quando entrano elementi; un testo che si aggiorna (i contatori ogni secondo) non conta */
  new MutationObserver(function(m){
    for (let i = 0; i < m.length; i++){
      const a = m[i].addedNodes;
      for (let j = 0; j < a.length; j++){ if (a[j].nodeType === 1){ clearTimeout(CIT_MUT_T); CIT_MUT_T = setTimeout(citOsserva, 120); return; } }
    }
  }).observe(radice, { childList: true, subtree: true });
})();

/* ------------------------------------------------------------------ chi entra, si anima */
let CIT_OSS = null;
function citOsserva(){
  try{ citTitoliAuto(); }catch(_){ }
  if (!('IntersectionObserver' in window)){
    document.querySelectorAll('.fl-anim').forEach(function(el){ el.classList.add('in'); });
    return;
  }
  if (!CIT_OSS){
    CIT_OSS = new IntersectionObserver(function(voci){
      voci.forEach(function(v){
        if (!v.isIntersecting) return;
        const el = v.target;
        CIT_OSS.unobserve(el);          // una volta sola, come fa il sito
        setTimeout(function(){ el.classList.add('in'); }, 120);
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });
  }
  document.querySelectorAll('.fl-anim').forEach(function(el){
    if (el.dataset.citOn) return;
    el.dataset.citOn = '1';
    CIT_OSS.observe(el);
  });
}
document.addEventListener('fl:tab', function(){ setTimeout(citOsserva, 120); });
document.addEventListener('fl:screen', function(){ setTimeout(citOsserva, 120); });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(citOsserva, 600); });

(function citStile(){
  const st = document.createElement('style');
  st.textContent = [
    /* il titolo, e la matita */
    '.fl-titolo{margin:14px 10px 0;font:800 22px/1.3 var(--font-display);font-style:italic;',
      'color:var(--navy);text-align:center}',
    /* dentro all'intestazione vince la regola di la', che incollava il titolo all'emoji con
       otto pixel: il razzo e il testo sembravano una cosa sola. Ventiquattro, piu' il respiro
       che serve al cerchio disegnato per non toccare le lettere sopra. */
    /* e sotto lo stesso respiro: il titolo staccato dall'emoji sopra e incollato al pannello
       sotto era peggio di prima — il cerchio disegnato toccava il bordo della carta */
    '.sev-intro .fl-titolo{margin:24px 10px 22px}',
    'body.dark .fl-titolo{color:#fff}',
    '.fl-hl{position:relative;display:inline-block;z-index:0;padding:0 .05em;white-space:nowrap}',
    '.fl-hl-svg{position:absolute;width:118%;height:145%;top:50%;left:50%;',
      'transform:translate(-50%,-50%) rotate(-1deg);pointer-events:none;overflow:visible}',
    '.fl-hl-svg path{fill:none;stroke-width:.11em;stroke-linecap:round;stroke-linejoin:round;',
      'stroke-dasharray:1200;stroke-dashoffset:1200}',
    '.fl-anim{opacity:0;transform:translateY(30px)}',
    '.fl-anim.in{opacity:1;transform:none;',
      'transition:opacity .6s cubic-bezier(.5,.06,.01,.99),transform .6s cubic-bezier(.5,.06,.01,.99)}',
    '.fl-anim.in .fl-hl-svg path{animation:flDrawCircle 1.2s .6s ease-out forwards}',
    '@keyframes flDrawCircle{0%{stroke-dashoffset:1200}100%{stroke-dashoffset:0}}',
    /* la diapositiva della citazione */
    '.cit-slide{min-height:180px;display:flex;flex-direction:column;justify-content:center;',
      'padding:22px 18px;border:1.5px solid var(--line);border-radius:20px;text-align:center}',
    '.cit-occhiello{margin:0 0 12px;font:800 11px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:var(--faint)}',
    '.cit-grande{margin:0;font:italic 600 15px/1.7 var(--font-body);color:var(--navy);min-height:3em}',
    'body.dark .cit-grande{color:#EEF4FF}',
    '.cit-grande .cit-a{display:block;margin-top:10px;font:600 12px var(--font-body);',
      'font-style:normal;color:var(--faint);opacity:0;transform:translateY(6px)}',
    '.cit-grande .cit-a.in{opacity:1;transform:none;transition:opacity .4s ease,transform .4s ease}',
    '.cit-cur{color:var(--blue,#0075E3)!important}',
    '.cit-chiusa{display:flex;align-items:center;gap:12px;text-align:left}',
    '.cit-chiusa span{font-size:26px;line-height:1;flex:none;opacity:.6}',
    '.cit-chiusa b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .cit-chiusa b{color:#fff}',
    '.cit-chiusa small{display:block;margin-top:4px;font:500 12px/1.6 var(--font-body);color:var(--muted)}',
    '@media (prefers-reduced-motion:reduce){.fl-anim{opacity:1!important;transform:none!important;',
      'transition:none!important}.fl-anim.in .fl-hl-svg path{animation:none;stroke-dashoffset:0}}'
  ].join('');
  document.head.appendChild(st);
})();
