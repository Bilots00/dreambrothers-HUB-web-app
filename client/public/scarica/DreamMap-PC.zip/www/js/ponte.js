/* ===========================================================================================
   IL PONTE CON LE ALTRE AI (0.9.333)

   Andrea: "se usa un'AI agentica che puo' comunicare con DreamMap, quello su cui lavora deve arrivare al Genio: se l'utente ha
   lavorato e il Genio non lo sa, e' un problema". Si accende solo dal pulsante nel foglio dell'albero maestro, e da li' c'e' una
   chiave sua. La sua AI scrive un riassunto (mai la conversazione intera) con il server MCP o con una chiamata HTTP; chi usa
   un'AI che non puo' chiamare niente incolla il resoconto nella Timeline. Il Genio lo legge nel brief e nella revisione della sera.
   Spegnendolo, la chiave e tutto quello che era stato scritto spariscono dal server e dal telefono. Prefisso pnt-.
   =========================================================================================== */
const PNT_K = 'fl_ponte_chiave', PNT_LOG = 'fl_ponte_log';
const PNT = { at: 0 };
function pntBase(){ return (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app'; }
function pntChiave(){ try{ return localStorage.getItem(PNT_K) || ''; }catch(_){ return ''; } }
function pntOn(){ return !!pntChiave(); }
function pntMcpUrl(){ return pntBase() + '/api/focuslock/ponte/mcp/' + pntChiave(); }
function pntHttpUrl(){ return pntBase() + '/api/focuslock/ponte/registra'; }
function pntVoci(){ try{ return JSON.parse(localStorage.getItem(PNT_LOG) || '[]') || []; }catch(_){ return []; } }
async function pntCollega(){
  const r = await frApi('POST', '/api/focuslock/ponte/collega', { device: frDevice() });
  if (!r || !r.chiave) throw new Error('nessuna chiave');
  try{ localStorage.setItem(PNT_K, r.chiave); }catch(_){ }
  pntPianoManda();
  return r.chiave;
}
async function pntScollega(){
  const c = pntChiave();
  try{ localStorage.removeItem(PNT_K); localStorage.removeItem(PNT_LOG); }catch(_){ }
  if (c){ try{ await frApi('POST', '/api/focuslock/ponte/scollega', { chiave: c }); }catch(_){ } }
}
/* il piano di oggi, per lo strumento leggi_piano */
function pntPianoManda(){
  if (!pntOn() || typeof amAlbero !== 'function') return;
  try{
    const a = amAlbero();
    const testo = 'Il sogno: ' + (a.SOGNO || 'da scrivere') + '\nQuest\'anno: ' + (a.ANNO || 'da scrivere') + '\nQuesto mese: ' + (a.MESE || 'da scrivere') + '\nQuesta settimana: ' + (a.SETTIMANA || 'da scrivere') + '\nOggi, una cosa sola: ' + (a.OGGI || 'da scrivere');
    frApi('POST', '/api/focuslock/ponte/piano', { chiave: pntChiave(), piano: testo }).catch(function(){ });
  }catch(_){ }
}
async function pntSync(forza){
  if (!pntOn() || (!forza && Date.now() - PNT.at < 120000)) return pntVoci();
  PNT.at = Date.now();
  try{
    const r = await frApi('GET', '/api/focuslock/ponte/log?chiave=' + encodeURIComponent(pntChiave()) + '&giorni=30');
    if (r && Array.isArray(r.voci)) localStorage.setItem(PNT_LOG, JSON.stringify(r.voci));
  }catch(_){ }
  return pntVoci();
}
function pntDelGiorno(off){
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const da = d0.getTime() - (off || 0) * 86400000, a = da + 86400000;
  return pntVoci().filter(function(v){ return v && v.at >= da && v.at < a; });
}
function pntMinTxt(m){ m = Math.round(m || 0); if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti'; const h = Math.floor(m / 60), r = m % 60; return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + ' minuti' : ''); }
/* per il tuo agente personale: quello che le altre AI hanno scritto, oggi e ieri */
function pntBriefTesto(){
  if (!pntOn()) return '';
  const riga = function(v){ return '- [' + v.fonte + (v.minuti ? ', ' + v.minuti + ' min' : '') + (v.inRotta === false ? ', fuori rotta' : (v.inRotta === true ? ', in rotta' : '')) + '] ' + v.testo; };
  const oggi = pntDelGiorno(0), ieri = pntDelGiorno(1);
  if (!oggi.length && !ieri.length) return '';
  let t = 'SU COSA HA LAVORATO CON LE ALTRE AI (lo scrivono loro con il ponte, e conta come lavoro vero: usalo per capire quante ore ha dato al sogno e se erano in rotta):';
  if (oggi.length) t += '\nOggi:\n' + oggi.slice(0, 20).map(riga).join('\n');
  if (ieri.length) t += '\nIeri:\n' + ieri.slice(0, 10).map(riga).join('\n');
  return t;
}
/* le righe della revisione della sera: [emoji, frase] */
function pntRigheSera(){
  const l = pntDelGiorno(0); if (!l.length) return [];
  const min = l.reduce(function(a, v){ return a + (v.minuti || 0); }, 0), fuori = l.filter(function(v){ return v.inRotta === false; }).length;
  const f = (l.length === 1 ? 'Con le tue AI oggi hai fatto 1 lavoro' : 'Con le tue AI oggi hai fatto ' + l.length + ' lavori') + (min ? ', per ' + pntMinTxt(min) : '') + (fuori ? ': ' + (fuori === 1 ? '1 era fuori rotta' : fuori + ' erano fuori rotta') : '') + '.';
  return [['🤖', f]];
}
/* LA SCHEDA NELLA TIMELINE */
function pntSchedaHtml(off){
  const e = (typeof esc === 'function') ? esc : function(s){ return String(s == null ? '' : s); };
  if (!pntOn()) return '<div class="pnt-vuoto"><span aria-hidden="true">🤖</span><b>Le tue AI non sono ancora collegate</b><p>Collegale e qui vedi su cosa hai lavorato con loro. Lo legge anche il Genio.</p><button type="button" class="cta" onclick="amApri()">Collega le tue AI</button></div>';
  const l = pntDelGiorno(off);
  const min = l.reduce(function(a, v){ return a + (v.minuti || 0); }, 0);
  const lista = l.length ? '<div class="prc-lista">' + l.map(function(v){
      return '<div class="prc-r"><span>🤖</span><p>' + e(v.testo) + '<small>' + e(v.fonte) + ' · ' + new Date(v.at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) + (v.minuti ? ' · ' + pntMinTxt(v.minuti) : '') + '</small></p>'
        + (v.inRotta === false ? '<i class="su">Fuori rotta</i>' : (v.inRotta === true ? '<i class="giu">In rotta</i>' : '')) + '</div>';
    }).join('') + '</div>' : '<p class="pst-nota">Le tue AI non hanno ancora scritto niente per questo giorno.</p>';
  return (min ? '<p class="tlr-arr"><small>Lavoro segnato dalle tue AI</small><b>' + e(pntMinTxt(min)) + '</b></p>' : '') + lista
    + '<div class="pnt-man"><b>La tua AI non si collega?</b><small>Chiedile un resoconto di due righe e incollalo qui.</small><textarea class="fin" id="pntTesto" rows="3" maxlength="2000" data-no-mic placeholder="Incolla il resoconto"></textarea><button type="button" class="ghostmini" onclick="pntIncolla()">Salva il resoconto</button></div>';
}
async function pntIncolla(){
  const t = document.getElementById('pntTesto'), v = t ? t.value.trim() : '';
  if (!v){ if (t) t.focus(); return; }
  try{
    await frApi('POST', '/api/focuslock/ponte/registra', { chiave: pntChiave(), riassunto: v, fonte: 'Incollato da te' });
    await pntSync(true);
    if (typeof tlPaint === 'function') tlPaint();
    toast('Resoconto salvato');
  }catch(_){ toast('Non sono riuscito a salvarlo: riprova con la connessione'); }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden){ try{ pntSync(false); pntPianoManda(); }catch(_){ } } });
setTimeout(function(){ try{ pntSync(false); pntPianoManda(); }catch(_){ } }, 6000);
(function(){
  const st = document.createElement('style');
  st.textContent = '.pnt-vuoto{text-align:center;padding:14px 6px}.pnt-vuoto span{display:block;font-size:44px;line-height:1}.pnt-vuoto b{display:block;margin:12px 0 6px;font:800 18px var(--font-display);color:#fff}.pnt-vuoto p{margin:0 0 18px;font:500 14px/1.45 var(--font-body);color:#BFD3EC}'
    + '.pnt-man{margin-top:18px;padding:14px;border-radius:16px;background:rgba(188,224,255,.1);text-align:center}.pnt-man b{display:block;font:800 15px var(--font-display);color:#fff}.pnt-man small{display:block;margin:3px 0 10px;font:500 13px var(--font-body);color:#BFD3EC}.pnt-man textarea{width:100%;box-sizing:border-box;margin-bottom:10px}';
  document.head.appendChild(st);
})();
