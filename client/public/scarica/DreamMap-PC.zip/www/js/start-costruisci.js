/* ===========================================================================================
   PERSONALIZZA START — come «Costruisci la tua mappa», per la scheda START (0.9.186)

   Si apre dalla matita in alto a destra nel cielo di START (al posto dei tre puntini, che
   aprivano le regole della partita: quelle restano nel link «Regole della partita ›»).

   COSA SI TOCCA
     · I BLOCCHI della scheda: l'ordine (frecce), toglierli (✕), rimetterli. Tutti, anche lo
       slideshow in alto e l'intermezzo.
     · LE SLIDE dei due slideshow: l'immagine di ogni slide del cielo in alto, l'immagine e il
       video dell'intermezzo. Fra le nostre, oppure dalla galleria del telefono.

   DOVE STA COSA
     · fl_start_cfg = { blocchi: [{id, on}], media: { '<slot>': { k } } }
       k = un'immagine o un video nostri ('img/…', 'video/…'), una sfumatura ('grad:a,b'), oppure
       'idb:<slot>' = il file scelto dalla galleria, salvato in IndexedDB (database fl_media):
       una foto intera o un video non entrano nel localStorage. La foto si riduce a 1080 px.
   =========================================================================================== */

const SCS_KEY = 'fl_start_cfg';
const SCS_BLOCCHI = [
  /* fisso: nella sua prima slide c'e' la matita che apre questa pagina */
  { id: 'stHero', ico: '🎞️', n: 'Lo slideshow in alto', s: 'La partita, il perché, il piano', fisso: true },
  /* 0.9.299: la partita delle idee non e' piu' un blocco di START, Mappa, Roadmap e Report: vive solo nelle statistiche della partita (partita-stats.js) */
  { id: 'stRisc', ico: '🔥', n: 'Il riscaldamento', s: 'I primi passi nell’app' },
  { id: 'stFocus', ico: '🎯', n: 'La priorità di oggi', s: 'L’unica cosa, e la porta del Full Focus', adotta: true },
  { id: 'stMid', ico: '🎬', n: 'L’intermezzo', s: 'Il video e la frase' },
  { id: 'stPark', ico: '🚀', n: 'Le sessioni di oggi', s: 'Quanto hai fatto, sessione per sessione' },
  /* 0.9.285: le sessioni in coppia (coppia.js) e il patto con il Dreambrother (patto.js) */
  { id: 'cplHost', ico: '🤝', n: 'Lavora in compagnia', s: 'Le sessioni in coppia e il patto' },
  { id: 'spHost', ico: '🧊', n: 'La serie', s: 'Il calendario e la protezione della serie' },
  { id: 'sndHost', ico: '🎵', n: 'Suoni per concentrarsi', s: 'Pioggia, mare, camino' },
  { id: 'spSez-start', ico: '🫧', n: 'Le persone concentrate adesso', s: 'Le bolle e il numero dal vivo', solo: function(){ return typeof flAdmin === 'function' && flAdmin(); } },
  { id: 'prHost', ico: '📚', n: 'Per te', s: 'Le sessioni già pronte' }
];
/* le slide che si possono vestire: dove stanno, e cosa accettano */
const SCS_SLIDE = [
  { k: 'hero0', n: 'La partita', tipo: 'img', sel: '#stHero .bh-slide[data-i="0"]', def: 'img/dream-night.jpg' },
  { k: 'hero1', n: 'Ricordati perché hai iniziato', tipo: 'img', sel: '#stHero .bh-slide[data-i="1"]', def: 'img/dream-night.jpg' },
  { k: 'hero2', n: 'Da cosa dipende la rotta', tipo: 'img', sel: '#stHero .bh-slide[data-i="2"]', def: 'img/dream-night.jpg' },
  { k: 'hero3', n: 'La sera prima', tipo: 'img', sel: '#stHero .bh-slide[data-i="3"]', def: 'img/dream-night.jpg' },
  { k: 'midVideo', n: 'Il video dell’intermezzo', tipo: 'video', def: 'video/energy.mp4' },
  { k: 'midImg', n: 'L’immagine dell’intermezzo', tipo: 'img', def: '' }
];
const SCS_IMMAGINI = [
  'img/dream-night.jpg', 'img/bg/montagne.jpg', 'img/bg/aurora.jpg', 'img/bg/mare.jpg', 'img/bg/take-flight.jpg', 'img/bg/luna.jpg',
  'img/bg/alba.jpg', 'img/bg/dune.jpg', 'img/bg/foresta.jpg', 'img/bg/nebbia.jpg', 'img/hormozi-tomorrow.jpg', 'img/dream-thieves.jpg',
  'img/oblo/tramonto.jpg', 'grad:#0B3F7A,#001E44', 'grad:#1B2A6B,#C42B38', 'grad:#0A4D68,#05BFDB', 'grad:#2C1810,#C2410C'
];
const SCS_VIDEO = [
  { k: 'video/energy.mp4', n: 'Energy flows', poster: 'video/energy-poster.jpg' },
  { k: 'video/nightmare.mp4', n: 'Nightmare', poster: 'video/nightmare-poster.jpg' },
  { k: 'video/now-choose.mp4', n: 'Now choose', poster: '' }
];
/* I BLOCCHI E LE SLIDE DELLA PAGINA BLOCCO («Proteggi i tuoi sogni»), 0.9.204 */
const SCS_BLOCCHI_BLOCCO = [
  { id: 'blkHero', ico: '🎞️', n: 'Lo slideshow in alto', s: 'Liberati dai ladri di sogni, la Focus Box', fisso: true },
  { id: 'blkReport', ico: '⏱️', n: 'Dove va la tua attenzione?', s: 'Il tempo di schermo e le prime cinque app' },
  { id: 'fbBoard', ico: '📦', n: 'La Focus Box', s: 'Il pannello del blocco fisico' },
  { id: 'blQb', ico: '⚡', n: 'Blocco rapido', s: 'App e siti da chiudere subito' },
  { id: 'blProg', ids: ['blProgSect', 'progList'], ico: '🕒', n: 'Programmi', s: 'I blocchi a orario' },
  { id: 'blTpl', ids: ['blTplHead', 'tplWrap'], ico: '📋', n: 'Modelli', s: 'Idee pronte da usare' },
  { id: 'blIntro', ico: '🔒', n: 'Il blocco che non si può spegnere', s: 'La Modalità severa, spiegata' },
  { id: 'blDoom', ico: '📱', n: 'Le app del doom-scrolling', s: 'Quelle che la Modalità severa chiude' }
];
const SCS_SLIDE_BLOCCO = [
  { k: 'bl0', n: 'Liberati dai ladri di sogni', tipo: 'img', sel: '#blkHero .bh-slide[data-i="0"]', def: 'img/dream-thieves.jpg', tieni: true },
  { k: 'bl1', n: 'Riprendi il controllo · Focus Box', tipo: 'img', sel: '#blkHero .bh-slide[data-i="1"]', def: 'img/focus-box.jpg', tieni: true },
  { k: 'bl2', n: 'La Focus Box · le tue notti', tipo: 'img', sel: '#blkHero .bh-slide[data-i="2"]', def: 'img/focus-box.jpg', tieni: true }
];
/* le pagine che si personalizzano da qui: START e Blocco. Stessa pagina, stessi fogli. */
/* LA SCHEDA MAPPA (0.9.206): i blocchi delle due viste, da spostare e togliere. Il cielo resta. */
const SCS_BLOCCHI_MAPPA = [
  { id: 'mppFoglio', ico: '📝', n: 'Il foglio del piano', s: 'La mia mappa · la priorità e le righe di oggi' },
  { id: 'mppRoadmap', ico: '🛤️', n: 'La tua roadmap', s: 'La mia mappa · i passi da oggi a fra cinque anni' },
  { id: 'mppTappa', ico: '🔮', n: 'La prossima tappa', s: 'La mia mappa · sotto al foglio: l’Oracolo, o il tuo agente personale con Premium' },
  /* 0.9.306, Andrea: il blocco "La tua mappa e la rotta di oggi" (mppBody) non c'e' piu': scsCfg lo toglie anche dalle liste salvate */
  { id: 'mppNote', ico: '🗒️', n: 'Le tue note', s: 'La mia mappa · note veloci, caveau e cestino' },
  { id: 'mppPagine', ico: '📄', n: 'Le tue pagine', s: 'La mia mappa · appunti e pagine' },
  { id: 'spSez-mappa', ico: '🫧', n: 'Le persone in cammino adesso', s: 'La mia mappa · le bolle e il numero dal vivo', solo: function(){ return typeof flAdmin === 'function' && flAdmin(); } },
  /* 0.9.273, Andrea: in "Personalizza Roadmap" c'erano solo il sentiero e l'agente. Ora ci sono tutte le sezioni della
     Roadmap: lo slideshow (con il suo divisore) e' una sezione sola, poi il sentiero, il piano, la stagione di spinta. */
  { id: 'mppHero', ico: '🎞️', n: 'Lo slideshow', s: 'Roadmap · la rotta sulla mappa, in alto' },
  { id: 'mppSentiero', ids: ['mppRevPer', 'mppRevisione', 'mppSentiero'], ico: '🛣️', n: 'Il sentiero', s: 'Roadmap · le tappe del Genio', fisso: true },
  { id: 'mppPianoRm', ids: ['mppSettimana', 'mppPianoRm'], ico: '🗓️', n: 'Il piano della roadmap', s: 'Roadmap · la settimana e il piano' },
  { id: 'mppStagione', ico: '🔥', n: 'La stagione di spinta', s: 'Roadmap · 90 giorni senza distrazioni' },
  { id: 'mppMossa', ico: '♟️', n: 'La prossima mossa', s: 'Roadmap · cosa tocca adesso' },
  { id: 'mppAgente', ico: '🧞', n: 'Il tuo agente personale', s: 'Roadmap · la guida' }
];
/* LA PAGINA REPORT (0.9.285, Andrea: "i blocchi del Report si personalizzano, con il blocco tratteggiato
   Personalizza in fondo, solo per me"). I blocchi stanno dentro #insBody, che si ridisegna a ogni cambio di vista:
   report-blocchi.js li avvolge dopo ogni disegno, e qui si sceglie l'ordine e cosa si vede. */
const SCS_BLOCCHI_REPORT = [
  { id: 'rpRiepilogo', ico: '⏱️', n: 'Il tempo sullo schermo', s: 'Il numero grande, il grafico e le categorie', fisso: true },
  { id: 'rpApp', ico: '📱', n: 'Le app più usate', s: 'L’elenco, dalla più usata' },
  { id: 'rpEvitate', ico: '🛡️', n: 'Le distrazioni evitate', s: 'Quante volte il blocco ti ha fermato' },
  { id: 'rpAbitudini', ico: '📈', n: 'Le abitudini', s: 'Bilancia, fascia oraria, concentrazione, distrazioni' },
  { id: 'rpUtilizzo', ico: '🧮', n: 'L’utilizzo per categoria', s: 'Distrattivo, neutrale, produttivo' },
  { id: 'rpTimeline', ico: '🕒', n: 'La Timeline', s: 'La giornata ora per ora' },
  { id: 'rpUmore', ico: '🙂', n: 'Il controllo dell’umore', s: 'Come stai oggi' }
];
const SCS_PAGINE = {
  report: { key: 'fl_report_blocchi', tab: 'insBody', titolo: 'Personalizza la pagina Report', blocchi: SCS_BLOCCHI_REPORT, slide: [], slideKey: '', slideTitolo: '', torna: function(){ try{ switchTab('insights'); }catch(_){ } } },
  'mappa-mia': { key: 'fl_mappa_mia_blocchi', tab: 'tab-mappa', titolo: 'Personalizza Mappa', blocchi: SCS_BLOCCHI_MAPPA.filter(function(b){ return ['mppFoglio', 'mppRoadmap', 'mppTappa', 'mppNote', 'mppPagine', 'spSez-mappa'].indexOf(b.id) >= 0; }), slide: [], slideKey: '', slideTitolo: '', torna: function(){ try{ switchTab('mappa'); }catch(_){ } } },
  'mappa-rotta': { key: 'fl_mappa_rotta_blocchi', tab: 'tab-mappa', titolo: 'Personalizza Roadmap', blocchi: SCS_BLOCCHI_MAPPA.filter(function(b){ return ['mppHero', 'mppSentiero', 'mppPianoRm', 'mppStagione', 'mppAgente'].indexOf(b.id) >= 0; }), slide: [], slideKey: '', slideTitolo: '', torna: function(){ try{ switchTab('mappa'); }catch(_){ } } },
  start: { key: SCS_KEY, tab: 'tab-sveglia', titolo: 'Personalizza START', blocchi: SCS_BLOCCHI, slide: SCS_SLIDE, slideKey: 'start', slideTitolo: 'Le slide di START', torna: function(){ try{ switchTab('sveglia'); }catch(_){ } } },
  blocco: { key: 'fl_blocco_cfg', tab: 'tab-blocco', titolo: 'Personalizza la pagina', blocchi: SCS_BLOCCHI_BLOCCO, slide: SCS_SLIDE_BLOCCO, slideKey: 'blocco', slideTitolo: 'Proteggi i tuoi sogni', torna: function(){ try{ blPaginaApri(); }catch(_){ } } }
};
const SCS = { slot: '', url: {}, pag: 'start' };
function scsPag(p){ return SCS_PAGINE[p || SCS.pag] || SCS_PAGINE.start; }

function scsCfg(p){
  const P = scsPag(p); const B = P.blocchi;
  let c = {}; try{ c = JSON.parse(localStorage.getItem(P.key) || '{}') || {}; }catch(_){ }
  if (!Array.isArray(c.blocchi)) c.blocchi = [];
  const nPrima = c.blocchi.length;
  c.blocchi = c.blocchi.filter(function(b){ return B.some(function(x){ return x.id === b.id; }); });
  /* 0.9.306: un blocco tolto dall'app (mppBody) esce anche dalla lista salvata, non solo da quella in memoria */
  if (c.blocchi.length !== nPrima){ try{ const salvata = JSON.parse(localStorage.getItem(P.key) || '{}') || {}; salvata.blocchi = c.blocchi; localStorage.setItem(P.key, JSON.stringify(salvata)); }catch(_){ } }
  B.forEach(function(b, i){
    if (c.blocchi.some(function(x){ return x.id === b.id; })) return;
    /* 0.9.234: un blocco nuovo entra subito dopo quello che lo precede nell'elenco, non in fondo */
    const prima = i > 0 ? c.blocchi.findIndex(function(x){ return x.id === B[i - 1].id; }) : -1;
    /* 0.9.300: un blocco facoltativo (la Cronologia dei blocchi) entra spento: lo accende chi lo sceglie da qui */
    const acceso = !b.facoltativo;
    if (prima >= 0) c.blocchi.splice(prima + 1, 0, { id: b.id, on: acceso }); else if (i === 0) c.blocchi.unshift({ id: b.id, on: acceso }); else c.blocchi.push({ id: b.id, on: acceso });
  });
  /* il blocco con la matita torna sempre (chi l'aveva tolto non poteva piu' rientrare qui) */
  c.blocchi.forEach(function(b){ if (B.some(function(x){ return x.id === b.id && x.fisso; })) b.on = true; });
  c.media = c.media || {};
  return c;
}
function scsSalva(c, p){ const P = scsPag(p); try{ localStorage.setItem(P.key, JSON.stringify(c)); }catch(_){ } scsApplica(p || SCS.pag); }

/* ---------------------------------------------------------------- IndexedDB: i file della galleria */
function scsDb(){
  return new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_media', 1);
      r.onupgradeneeded = function(){ r.result.createObjectStore('m'); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ko(r.error); };
    }catch(e){ ko(e); }
  });
}
async function scsPut(k, blob){
  const db = await scsDb();
  return new Promise(function(ok, ko){ const tx = db.transaction('m', 'readwrite'); tx.objectStore('m').put(blob, k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ko(tx.error); }; });
}
async function scsGet(k){
  const db = await scsDb();
  return new Promise(function(ok){ const tx = db.transaction('m', 'readonly'); const rq = tx.objectStore('m').get(k); rq.onsuccess = function(){ ok(rq.result || null); }; rq.onerror = function(){ ok(null); }; });
}
/** L'indirizzo da mettere nella pagina per un valore k (un file nostro, o uno della galleria). */
async function scsUrl(k){
  if (!k) return '';
  if (k.indexOf('idb:') !== 0) return k;
  if (SCS.url[k]) return SCS.url[k];
  try{ const b = await scsGet(k.slice(4)); if (b){ SCS.url[k] = URL.createObjectURL(b); return SCS.url[k]; } }catch(_){ }
  return '';
}
function scsCssDi(k, url){
  if (k && k.indexOf('grad:') === 0){ const p = k.slice(5).split(','); return 'linear-gradient(160deg,' + p[0] + ',' + p[1] + ')'; }
  return url ? "url('" + url + "')" : '';
}

/* ---------------------------------------------------------------- dove si vede */
function scsOrdinaBlocchi(p){
  const P = scsPag(p);
  const tab = document.getElementById(P.tab); if (!tab) return;
  let rientrato = false;
  const ordine = [];
  scsCfg(p).blocchi.forEach(function(b){
    const d = P.blocchi.filter(function(x){ return x.id === b.id; })[0];
    (d && d.ids ? d.ids : [b.id]).forEach(function(id){
      const el = document.getElementById(id); if (!el) return;
      /* il foglio di START puo' stare nella Mappa: quando START si riapre, torna a casa */
      if (el.parentElement !== tab){
        if (!(d && d.adotta)) return;
        /* 0.9.227: START si riprende il foglio solo se e' lui la scheda a schermo. All'avvio START
           si disegnava DOPO la Mappa e le portava via il foglio: nella Mappa restava il buco
           finche' non si cambiava scheda */
        if (tab.offsetParent === null) return;
        if (id === 'stFocus') rientrato = true;
      }
      /* una classe, non `hidden`: alcuni blocchi (il riscaldamento) si nascondono da soli */
      if (el.classList.contains('scs-off') !== !b.on) el.classList.toggle('scs-off', !b.on);
      if (ordine.indexOf(el) < 0) ordine.push(el);
    });
  });
  /* il piede «Personalizza» resta in fondo; si sposta solo se l'ordine e' cambiato (0.9.265, flOrdina) */
  const piede = tab.querySelector(':scope > .hd-piede'); if (piede) ordine.push(piede);
  if (typeof flOrdina === 'function') flOrdina(tab, ordine); else ordine.forEach(function(e){ tab.appendChild(e); });
  /* 0.9.210: il foglio tornato dalla Mappa si ridisegna da START, con l'interruttore
     Da solo | In gruppo (prima restava il disegno della Mappa, senza interruttore) */
  if (rientrato){ try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ } }
  try{ if (typeof flHeaderSync === 'function') flHeaderSync(); }catch(_){ }
}
async function scsApplicaMedia(p){
  const P = scsPag(p); const c = scsCfg(p);
  for (let i = 0; i < P.slide.length; i++){
    const s = P.slide[i], m = c.media[s.k];
    if (s.tipo === 'img'){
      const el = s.k === 'midImg' ? (document.getElementById('midTesto') || {}).parentElement : document.querySelector(s.sel);
      if (!el || !el.style) continue;
      /* 0.9.280: l'intermezzo di serie non ha immagine (la frase di Hormozi e' testo vero): 'none' */
      if (!m || !m.k){ if (s.k !== 'midImg' && !s.tieni) el.style.removeProperty('--bh-img'); else el.style.setProperty('--bh-img', s.def ? "url('" + s.def + "')" : 'none'); continue; }
      const css = scsCssDi(m.k, await scsUrl(m.k));
      if (css) el.style.setProperty('--bh-img', css);
    } else {
      const v = document.getElementById('stVid'); if (!v) continue;
      const want = (m && m.k) ? await scsUrl(m.k) : s.def;
      if (!want) continue;
      if (v.dataset.src === want) continue;
      v.dataset.src = want;
      v.removeAttribute('poster');
      if (!m || !m.k) v.setAttribute('poster', 'video/energy-poster.jpg');
      else { const nostro = SCS_VIDEO.filter(function(x){ return x.k === m.k; })[0]; if (nostro && nostro.poster) v.setAttribute('poster', nostro.poster); }
      while (v.firstChild) v.removeChild(v.firstChild);
      v.src = want; try{ v.load(); }catch(_){ }
      try{ if (typeof stVideoSync === 'function') stVideoSync(); }catch(_){ }
    }
  }
}
function scsApplica(p){ p = p || 'start'; scsOrdinaBlocchi(p); scsApplicaMedia(p); }
document.addEventListener('fl:tab', function(e){
  if (e.detail === 'sveglia'){ setTimeout(function(){ scsApplica('start'); }, 120); setTimeout(function(){ scsApplica('start'); }, 900); }
  if (e.detail === 'blocco'){ setTimeout(function(){ scsApplica('blocco'); }, 150); setTimeout(function(){ scsApplica('blocco'); }, 900); }
});
document.addEventListener('DOMContentLoaded', function(){ setTimeout(function(){ scsApplica('start'); }, 2000); });

/* ---------------------------------------------------------------- la pagina */
registerScreen('s-start-cst',
  '<div class="topbar"><button class="iconbtn" onclick="scsChiudi()">‹</button><b class="blk-title cst-tit" id="scsTitolo">Personalizza START</b></div>'
  + '<div id="scsBody"></div>'
  + '<button type="button" class="cta cst-salva" onclick="scsChiudi(true)">Salva</button><div class="spacer"></div>'
  + '<input type="file" id="scsFileImg" accept="image/*" hidden onchange="scsCarica(this,\'img\')">'
  + '<input type="file" id="scsFileVid" accept="video/*" hidden onchange="scsCarica(this,\'video\')">',
  { back: function(){ scsPag().torna(); return 's-home'; } });
function scsApri(p){
  SCS.pag = (p && SCS_PAGINE[p]) ? p : 'start';
  try{ if (SCS.pag === 'start' && typeof FF !== 'undefined' && FF && FF.run){ toast('Sei in una sessione di Full Focus. START aspetta.'); return; } }catch(_){ }
  goId('s-start-cst');
  const t = document.getElementById('scsTitolo'); if (t) t.textContent = scsPag().titolo;
  scsPaint();
}
function scsChiudi(salva){ goId('s-home'); scsPag().torna(); if (salva) toast('Salvato'); }
async function scsPaint(){
  const box = document.getElementById('scsBody'); if (!box) return;
  const P = scsPag(); const c = scsCfg();
  const righe = [];
  for (let i = 0; i < P.slide.length; i++){
    const s = P.slide[i];
    if (s.k === 'hero3' && !document.querySelector(s.sel)) continue;     /* la quarta c'e' solo per chi il piano lo scrive da sé */
    const m = c.media[s.k], k = (m && m.k) || s.def;
    let anteprima = '';
    if (s.tipo === 'video'){
      const nostro = SCS_VIDEO.filter(function(x){ return x.k === k; })[0];
      anteprima = (nostro && nostro.poster) ? "url('" + nostro.poster + "')" : 'linear-gradient(160deg,#0B3F7A,#001E44)';
    } else anteprima = scsCssDi(k, await scsUrl(k)) || 'linear-gradient(160deg,#0B3F7A,#001E44)';
    righe.push('<div class="scs-sl"><span class="scs-thumb" style="background:' + anteprima + ' center/cover">' + (s.tipo === 'video' ? '▶' : '') + '</span>'
      + '<div><b>' + esc(s.n) + '</b><small>' + (m && m.k ? (m.k.indexOf('idb:') === 0 ? 'Dalla tua galleria' : 'Scelta da te') : 'Quella di serie') + '</small></div>'
      + '<button type="button" class="cst-rimetti" onclick="scsScegli(\'' + s.k + '\')">Cambia</button></div>');
  }
  const blocchi = c.blocchi.map(function(b, i){
    const d = P.blocchi.filter(function(x){ return x.id === b.id; })[0]; if (!d || (d.solo && !d.solo())) return '';
    return '<div class="cst-bl' + (b.on ? '' : ' off') + '">'
      + '<span class="cst-bl-ico">' + d.ico + '</span>'
      + '<div><b>' + esc(d.n) + '</b><small>' + esc(b.on ? (d.fisso ? 'Qui c\u2019è la matita: resta sempre' : d.s) : (d.facoltativo ? d.s : 'Tolto dalla pagina')) + '</small></div>'
      + (b.on
          ? '<button type="button" class="cst-mini" aria-label="Su" onclick="scsSposta(' + i + ',-1)"' + (i === 0 ? ' disabled' : '') + '><span class="chev su"></span></button>'
            + '<button type="button" class="cst-mini" aria-label="Giù" onclick="scsSposta(' + i + ',1)"' + (i === c.blocchi.length - 1 ? ' disabled' : '') + '><span class="chev giu"></span></button>'
            + (d.fisso ? '<span class="cst-mini lucchetto" aria-label="Resta sempre">🔒</span>' : '<button type="button" class="cst-mini x" aria-label="Togli" onclick="scsTogli(' + i + ')">✕</button>')
          : '<button type="button" class="cst-rimetti" onclick="scsRimetti(' + i + ')">' + (d.facoltativo ? 'Aggiungi' : 'Rimetti') + '</button>')
      + '</div>';
  }).join('');
  box.innerHTML = (P.slide.length ? '<h3 class="cst-h">Le slide</h3><p class="cst-p">Tocca «Cambia» per scegliere un’immagine o un video, nostri o della tua galleria.</p>'
    + '<div class="cst-bls">' + righe.join('') + '</div>'
    + '<button type="button" class="cst-galleria" onclick="flSlideFoglio(\'' + P.slideKey + '\',\'' + esc(P.slideTitolo) + '\')">🎞️ Scegli quali slide vedere</button>' : '')
    + '<h3 class="cst-h">I blocchi della scheda</h3><p class="cst-p">Le frecce spostano, la ✕ toglie, «Rimetti» lo riporta nella scheda.</p>'
    + '<div class="cst-bls">' + blocchi + '</div>';
}
function scsSposta(i, d){ const c = scsCfg(); const j = i + d; if (j < 0 || j >= c.blocchi.length) return; const t = c.blocchi[i]; c.blocchi[i] = c.blocchi[j]; c.blocchi[j] = t; scsSalva(c); scsPaint(); }
function scsTogli(i){ const c = scsCfg(); const d = c.blocchi[i] && scsPag().blocchi.filter(function(x){ return x.id === c.blocchi[i].id; })[0]; if (d && d.fisso) return; if (c.blocchi[i]) c.blocchi[i].on = false; scsSalva(c); scsPaint(); }
function scsRimetti(i){ const c = scsCfg(); if (c.blocchi[i]) c.blocchi[i].on = true; scsSalva(c); scsPaint(); }

/* ---------------------------------------------------------------- il foglio per scegliere */
function scsScegli(slot){
  SCS.slot = slot;
  const s = scsPag().slide.filter(function(x){ return x.k === slot; })[0]; if (!s) return;
  const c = scsCfg(), cur = (c.media[slot] && c.media[slot].k) || s.def;
  let w = document.getElementById('scsSheet');
  if (!w){ w = document.createElement('div'); w.id = 'scsSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) scsSheetChiudi(); }); document.body.appendChild(w); }
  const griglia = s.tipo === 'video'
    ? SCS_VIDEO.map(function(v){ return '<button type="button" class="scs-op v' + (cur === v.k ? ' on' : '') + '" style="background:' + (v.poster ? "url('" + v.poster + "')" : 'linear-gradient(160deg,#0B3F7A,#001E44)') + ' center/cover" onclick="scsMetti(\'' + v.k + '\')"><span>' + esc(v.n) + '</span></button>'; }).join('')
    : SCS_IMMAGINI.map(function(k){ return '<button type="button" class="scs-op' + (cur === k ? ' on' : '') + '" style="background:' + scsCssDi(k, k) + ' center/cover" onclick="scsMetti(\'' + k + '\')" aria-label="Immagine"></button>'; }).join('');
  w.innerHTML = '<div class="sd-sheet-in"><i class="pr-grab"></i><h3>' + esc(s.n) + '</h3>'
    + '<div class="scs-ops">' + griglia + '</div>'
    + '<button type="button" class="cst-galleria" onclick="document.getElementById(\'' + (s.tipo === 'video' ? 'scsFileVid' : 'scsFileImg') + '\').click()">📷 ' + (s.tipo === 'video' ? 'Un video dalla galleria' : 'Una foto dalla galleria') + '</button>'
    + '<button type="button" class="sd-btn-link" onclick="scsMetti(\'\')">Torna a quella di serie</button></div>';
  w.hidden = false;
}
function scsSheetChiudi(){ const w = document.getElementById('scsSheet'); if (w) w.remove(); }
function scsMetti(k){
  const c = scsCfg();
  if (k) c.media[SCS.slot] = { k: k }; else delete c.media[SCS.slot];
  scsSalva(c); scsSheetChiudi(); scsPaint();
}
/* LA GALLERIA: la foto ridotta a 1080 px (JPEG), il video com'e' fino a 80 MB. In IndexedDB. */
async function scsCarica(inp, tipo){
  const f = inp && inp.files && inp.files[0]; inp.value = '';
  if (!f) return;
  const slot = SCS.slot; if (!slot) return;
  try{
    if (tipo === 'video'){
      if (f.size > 80 * 1024 * 1024){ toast('Il video è troppo grande: massimo 80 MB'); return; }
      await scsPut(SCS.pag === 'start' ? slot : SCS.pag + ':' + slot, f);
    } else {
      const blob = await new Promise(function(ok){
        const r = new FileReader();
        r.onload = function(){
          const img = new Image();
          img.onload = function(){
            const M = 1080, sc = Math.min(1, M / Math.max(img.width, img.height));
            const cv = document.createElement('canvas'); cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
            cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
            cv.toBlob(function(b){ ok(b); }, 'image/jpeg', .84);
          };
          img.onerror = function(){ ok(null); };
          img.src = r.result;
        };
        r.readAsDataURL(f);
      });
      if (!blob){ toast('Non riesco a leggere questa foto'); return; }
      await scsPut(SCS.pag === 'start' ? slot : SCS.pag + ':' + slot, blob);
    }
    const k = 'idb:' + (SCS.pag === 'start' ? slot : SCS.pag + ':' + slot);
    if (SCS.url[k]){ try{ URL.revokeObjectURL(SCS.url[k]); }catch(_){ } delete SCS.url[k]; }
    const c = scsCfg(); c.media[slot] = { k: k }; scsSalva(c);
    scsSheetChiudi(); scsPaint();
    toast(SCS.pag === 'start' ? 'Fatto: la trovi nella scheda START' : 'Fatto: la trovi nella pagina');
  }catch(_){ toast('Non sono riuscito a salvarlo sul telefono'); }
}

(function(){
  const css = [
    '.scs-off{display:none !important}',
    '.scs-sl{display:flex;align-items:center;gap:12px;background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:10px 12px}',
    'body.dark .scs-sl{background:#12203A;border-color:#22345A}',
    '.scs-thumb{flex:none;width:52px;height:52px;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;text-shadow:0 2px 6px rgba(0,0,0,.5)}',
    '.scs-sl > div{flex:1;min-width:0}.scs-sl b{display:block;font:600 14px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .scs-sl b{color:#fff}',
    '.scs-sl small{display:block;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.scs-ops{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;padding:10px 6px;margin:4px 0 6px}',
    '.scs-op{aspect-ratio:1;border:0;border-radius:14px;cursor:pointer;position:relative;transition:transform .25s cubic-bezier(.3,1.6,.5,1),box-shadow .2s}',
    '.scs-op.on{transform:scale(1.04);box-shadow:0 0 0 3px var(--card,#fff),0 0 0 6px var(--blue,#0075E3)}body.dark .scs-op.on{box-shadow:0 0 0 3px #141C2C,0 0 0 6px #3F9FF4}',
    '.scs-op.v{aspect-ratio:3/4}.scs-op.v span{position:absolute;left:6px;right:6px;bottom:6px;font:700 11px var(--font-body);color:#fff;text-shadow:0 2px 6px rgba(0,0,0,.6)}',
    /* la matita al posto dei tre puntini, nel cielo di START */
    /* UNA MATITA SOLA in tutta l\'app (0.9.188): la stessa della card dell\'arrivo (.nv-edit) */
    '.mt-edit,.bh-edit{width:36px !important;height:36px !important;border-radius:18px !important;border:0;background:rgba(255,255,255,.16) !important;color:#fff !important;font:400 16px/1 var(--font-body) !important;display:flex !important;align-items:center;justify-content:center;padding:0 !important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
