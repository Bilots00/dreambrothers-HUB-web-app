/* ===========================================================================================
   IO FUTURO — il messaggio del giorno, la card nella Roadmap, il diario, «Chi sarò»

   DOVE SI AGGANCIA
     · FullFocus: ffDoneClose / ffRispondi / ffChiudiDomanda chiamano ifDopoFocus() quando la
       fila dei pop-up di fine sessione e' finita (piantina → scrigno → «Hai completato la
       task?» → Io Futuro);
     · le righe spuntate: l'evento «fl:spunta» (start.js) e la spunta a mano della priorita';
     · il Genio: i tag di identita' sui nodi (oracle.js) e una domanda d'identita' al giorno;
     · la riserva di dopamina: la prima lettura del giorno del messaggio vale +0,3
       (fl_if_viste, al posto dei «progressi guardati»);
     · la Roadmap: la card sotto al pannello della modalita' severa (#ifCardHost) e, dopo la
       lettura del Genio, il pannello «Ottieni una guida 1-1» (#guidaHost).

   NESSUNA CHIAMATA DI RETE: i testi arrivano da content/iofuturo.json dentro all'app, tutto il
   resto sta nel localStorage del telefono.
   =========================================================================================== */

const IF_KEYS = {
  diario: 'fl_if_diario',          // [{ id, tema, testo, t, giorno, fonte }]
  viste: 'fl_if_viste',            // [t] prime letture del giorno (per la riserva di dopamina)
  impost: 'fl_if_impost',          // { popup, immagine: 'profilo' | 'roadmap' }
  ident: 'fl_if_ident',            // { chiSaro, perche, genere, manuale: { attr: valore } }
  risposte: 'fl_if_risposte',      // [{ attr, k, w, t }] risposte alle domande d'identita'
  domanda: 'fl_if_domanda_giorno', // il giorno dell'ultima domanda d'identita'
  global: 'fl_if_global',          // { consenso, coda } — spento
  spunte: 'fl_if_spunte_viste'     // quante righe fatte oggi erano gia' state viste
};
const IF = { contenuti: null, lingua: 'it', inCorso: false };

function ifLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function ifScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function ifKey(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function ifMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function ifEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x); }

/** I testi, nella lingua di chi legge. Un file dentro all'app: nessuna rete. */
async function ifContenuti(){
  if (IF.contenuti) return IF.contenuti;
  try{
    const tutti = await (await fetch('content/iofuturo.json')).json();
    IF.lingua = (typeof flLingua === 'function' && tutti[flLingua()]) ? flLingua() : 'it';
    IF.contenuti = tutti[IF.lingua] || tutti.it;
  }catch(_){ IF.contenuti = null; }
  return IF.contenuti;
}
function ifUi(k, sub){ const c = IF.contenuti; const v = c && c.ui && c.ui[k]; return (v && sub) ? v[sub] : (v || ''); }

/* ---------------------------------------------------------------------------------------
   IL GIORNO COMINCIA AL RISVEGLIO, non a mezzanotte: chi e' ancora sveglio all'una sta
   vivendo la giornata di ieri.
   --------------------------------------------------------------------------------------- */
async function ifGiorno(){
  const ora = Date.now(), mezz = ifMezzanotte(ora);
  let sveglia = 0;
  try{
    if (typeof scReport === 'function' && typeof scCompute === 'function'){
      const r = await scReport(0);
      const c = r && r.granted ? scCompute(r) : null;
      if (c && c.wake >= mezz && c.wake <= ora) sveglia = c.wake;
    }
  }catch(_){ }
  if (sveglia) return { key: ifKey(ora), inizio: sveglia };
  if (new Date(ora).getHours() < 5) return { key: ifKey(ora - 86400000), inizio: mezz - 86400000 };
  return { key: ifKey(ora), inizio: mezz };
}

/* ---------------------------------------------------------------------------------------
   I FATTI VERI DEL GIORNO
   --------------------------------------------------------------------------------------- */
function ifSevera(){
  try{ if (typeof sevState !== 'undefined' && sevState && typeof sevState.level === 'number') return sevState.level > 0; }catch(_){ }
  return !!ifLeggi('fl_sev_streak', null);
}
function ifStreak(){
  const st = ifLeggi('fl_sev_streak', null);
  if (!st || !st.start) return 0;
  try{ return Math.max(1, (typeof blkDaysBetween === 'function' ? blkDaysBetween(st.start, blkToday()) : 0) + 1); }catch(_){ return 1; }
}
function ifFF(){ return (ifLeggi('fl_ff_hist', []) || []).filter(function(x){ return x && !x.meditazione && x.tag !== 'meditazione'; }); }
function ifGiorniAttivi(){
  const g = {};
  ifFF().forEach(function(x){ if ((x.spentMs || 0) >= IF_CFG.focusMinMin * 60000) g[ifKey(x.at)] = 1; });
  (ifLeggi('fl_notes_done', []) || []).forEach(function(x){ if (x && x.at) g[ifKey(x.at)] = 1; });
  (ifLeggi('fl_one_hist', []) || []).forEach(function(x){ if (x && x.doneAt) g[ifKey(x.doneAt)] = 1; });
  return g;
}
function ifDati(giorno, passo){
  const ui = function(k){ return ifUi(k); };
  const da = giorno.inizio, ora = Date.now();
  const ff = ifFF();
  const oggi = ff.filter(function(x){ return x.at >= da && x.at <= ora; });
  const minutiFocus = Math.round(oggi.reduce(function(a, x){ return a + (x.spentMs || 0); }, 0) / 60000);
  const maxOggi = Math.max.apply(null, [0].concat(oggi.map(function(x){ return x.spentMs || 0; })));
  const prima = ff.filter(function(x){ return x.at < da && x.at >= da - 30 * 86400000; });
  const maxPrima = Math.max.apply(null, [0].concat(prima.map(function(x){ return x.spentMs || 0; })));
  const fatte = (ifLeggi('fl_notes_done', []) || []).filter(function(x){ return x && x.at >= da && x.at <= ora; }).length;
  const priorita = (ifLeggi('fl_one_hist', []) || []).filter(function(x){ return x && x.doneAt >= da && x.doneAt <= ora; });
  const att = ifGiorniAttivi();
  const k0 = ifKey(ora), k1 = ifKey(ora - 86400000), k2 = ifKey(ora - 2 * 86400000);
  let primoPasso = '';
  if (passo && passo.tipo === 'focus') primoPasso = ui('primo_passo_focus').replace('{min}', String(passo.min));
  else if (passo && passo.tipo === 'task' && passo.testo){
    const tx = String(passo.testo).trim();
    primoPasso = ui('primo_passo_task').replace('{testo}', tx.length > 40 ? tx.slice(0, 39) + '…' : tx);
  }
  let prossimo = '';
  try{
    const one = (typeof stOne === 'function') ? stOne() : null;
    const tx = one && !one.done && one.task && (one.task.text || one.task);
    prossimo = tx ? '«' + String(tx).trim() + '»' : ui('prossimo_default');
  }catch(_){ prossimo = ui('prossimo_default'); }
  return {
    streak: ifStreak(), minutiFocus: minutiFocus, task: fatte + priorita.length, priorita: priorita.length > 0,
    record: prima.length > 0 && maxOggi > maxPrima && maxOggi >= 15 * 60000, recordMin: Math.round(maxOggi / 60000),
    ritorno: !!att[k0] && !att[k1] && !!att[k2],
    primoPasso: primoPasso, prossimoPasso: prossimo
  };
}

/* ---------------------------------------------------------------------------------------
   IL PROFILO IDENTITA' — le fonti (IdentityProfileSource)
   Oggi: il Genio (i tag dei nodi e le domande d'identita'). Domani anche l'agente personale.
   --------------------------------------------------------------------------------------- */
const IF_SORGENTE_GENIO = {
  nome: 'genio',
  contributi: function(){
    const out = [];
    const add = function(tag, mult){
      Object.keys(tag || {}).forEach(function(attr){ Object.keys(tag[attr]).forEach(function(k){ out.push({ attr: attr, k: k, w: tag[attr][k] * (mult || 1) }); }); });
    };
    const r = (typeof orLast === 'function') ? orLast() : null;
    if (r){
      if (typeof OR_TAG_TARGET !== 'undefined' && r.target) add(OR_TAG_TARGET[r.target], 1);
      if (typeof OR_TAG_TRIGGER !== 'undefined') (r.trigger || []).forEach(function(tr){ add(OR_TAG_TRIGGER[tr], 1); });
      if (typeof OR_TAG_Q !== 'undefined') Object.keys(r.answers || {}).forEach(function(q){ const a = r.answers[q]; if (a >= .75) add(OR_TAG_Q[q], a); });
    }
    (ifLeggi(IF_KEYS.risposte, []) || []).forEach(function(x){ if (x && x.attr && x.k) out.push({ attr: x.attr, k: x.k, w: x.w || 2 }); });
    return out;
  }
};
const IF_SORGENTI = [IF_SORGENTE_GENIO];
function ifIdentita(){ return ifLeggi(IF_KEYS.ident, { chiSaro: '', perche: '', genere: '', manuale: {} }) || {}; }
function ifProfiloOra(){ return ifProfilo(IF_SORGENTI, ifIdentita().manuale || {}); }

/** La domanda d'identita' di oggi, se il profilo ha un attributo poco chiaro (una al giorno). */
function ifDomandaDelGiorno(){
  const oggi = ifKey(Date.now());
  if (localStorage.getItem(IF_KEYS.domanda) === oggi) return null;
  const attr = ifAttributoIncerto(ifProfiloOra());
  if (!attr || typeof OR_IDQ === 'undefined' || !OR_IDQ[attr]) return null;
  try{ localStorage.setItem(IF_KEYS.domanda, oggi); }catch(_){ }
  return Object.assign({ attr: attr }, OR_IDQ[attr]);
}
function ifRispostaIdentita(attr, k){
  const l = ifLeggi(IF_KEYS.risposte, []) || [];
  l.push({ attr: attr, k: k, w: 2, t: Date.now() });
  ifScrivi(IF_KEYS.risposte, l.slice(-60));
}

/* ---------------------------------------------------------------------------------------
   IL CONTESTO per il generatore: solo quello che serve, niente di piu'
   --------------------------------------------------------------------------------------- */
function ifObiettivo(){
  try{
    if (typeof ozAnello === 'function'){
      const a = ozAnello('ungiorno').testo || ozAnello('cinque').testo || '';
      if (a.trim()) return a.trim();
    }
  }catch(_){ }
  return '';
}
function ifContesto(giorno, passo){
  const id = ifIdentita();
  const u = ifLeggi('fl_user', null);
  return {
    nome: (u && u.name) ? String(u.name).trim().split(/\s+/)[0] : '',
    profilo: ifProfiloOra(),
    obiettivo: ifObiettivo(),
    perche: (id.perche || '').trim(),
    chiSaro: (id.chiSaro || '').trim(),
    genere: id.genere || '',
    dati: ifDati(giorno, passo),
    recenti: (ifLeggi(IF_KEYS.diario, []) || []).slice(-40).map(function(m){ return { id: m.id, tema: m.tema, t: m.t }; }),
    adesso: Date.now()
  };
}

/* ---------------------------------------------------------------------------------------
   IL PRIMO PASSO: qui arrivano FullFocus e le spunte
   --------------------------------------------------------------------------------------- */
function ifInConfigurazione(){
  try{
    if (typeof FF !== 'undefined' && FF && FF.run) return true;
    const w = document.getElementById('ffSheetWrap');
    if (w && w.classList.contains('open')) return true;
  }catch(_){ }
  return false;
}
/** Dopo la fila dei pop-up di FullFocus: vale se la sessione ha avuto almeno 10 minuti veri. */
function ifDopoFocus(){
  const ultima = ifFF().slice(-1)[0];
  if (!ultima || Date.now() - ultima.at > 30 * 60000) return;
  const min = Math.round((ultima.spentMs || 0) / 60000);
  /* la lettera della sessione la si chiede all'INIZIO (ifPrimaSessione) e arriva nello scrigno
     o alla prossima apertura: qui non c'e' piu' niente da fare */
  return;
}

/* ---------------------------------------------------------------------------------------
   UN PREMIO, NON UNA CARD FISSA
   Il messaggio dell'Io Futuro stava sempre li', nella Roadmap: una cosa sempre visibile non
   vale niente. Adesso arriva come premio, e non tutte le volte: dopo una sessione di Full
   Focus o una cosa fatta, una volta su due, qualche minuto dopo (mai sopra al verdetto della
   sessione); e sempre ai traguardi della serie in severa. Una volta al giorno al massimo, mai
   durante una chiamata e mai nelle fasce di «Quando tacere».
   --------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------
   LA LETTERA LA SCRIVE IL SUO AGENTE, NELLA SUA VOCE.
   Niente template: il messaggio lo genera l'agente personale come «io futuro», imitando il modo
   di scrivere dell'utente (i suoi messaggi in chat) e incrociandolo con quello che il Genio sa
   di lui. Per questo arriva SOLO quando l'agente lo conosce abbastanza: agente creato e almeno
   tre messaggi suoi. Prima di allora, niente lettera: un «io futuro» che non ti somiglia stona.

   QUANDO ARRIVA. Mai a caso, mai minuti dopo senza motivo. Tre porte:
   · nello scrigno, dopo una sessione di Full Focus (la lettera si chiede all'INIZIO della
     sessione, cosi' e' pronta quando lo scrigno si apre; se la sessione viene mollata, si butta);
   · subito dopo il gesto, se l'utente e' nell'app (una cosa spuntata, un traguardo della serie);
   · altrimenti alla prossima apertura dell'app: e' lui ad averla aperta, quindi c'e'.
   Una al giorno al massimo, mai in chiamata, mai nelle fasce di «Quando tacere».
   --------------------------------------------------------------------------------------- */
const IF_LET = 'fl_if_lettera';      // { testo, bottone, passo, at, giorno, consegnata }
const IF_ATTESA = 'fl_if_attesa';    // { msgId, passo, at, giorno }
function ifAgentePronto(){
  try{
    if (typeof agAbilitatoOra !== 'function' || !agAbilitatoOra()) return false;
    if (typeof agPuo !== 'function' || !agPuo()) return false;
    const s = agStato();
    if (!s || !s.impostato) return false;
    const miei = (s.msgs || []).filter(function(m){ return m.direzione === 'in' && !/^\[/.test(String(m.testo || '')); }).length;
    return miei >= 3;
  }catch(_){ return false; }
}
function ifPassoTesto(passo){
  const serie = ifSevera() ? ifStreak() : 0;
  let t = '';
  if (passo.tipo === 'focus') t = 'sta facendo una sessione di Full Focus di ' + passo.min + ' minuti' + (passo.task ? ' su «' + passo.task + '»' : '') + ' e la portera’ a termine';
  else if (passo.tipo === 'task') t = 'ha appena spuntato «' + (passo.testo || 'una cosa del piano') + '»';
  else if (passo.tipo === 'serie') t = 'è arrivato a ' + passo.n + ' giorni di fila con la Modalità severa accesa';
  else t = 'ha fatto un passo vero verso la sua destinazione';
  return t + (serie ? ' (serie in Modalità severa: ' + serie + ' giorni)' : '');
}
async function ifRichiedi(passo){
  if (!ifAgentePronto() || !ifSevera()) return false;
  const oggi = ifKey(Date.now());
  const l = ifLeggi(IF_LET, null);
  if (l && l.giorno === oggi) return false;
  const a = ifLeggi(IF_ATTESA, null);
  if (a && a.giorno === oggi) return false;
  try{
    const r = await agApi('POST', '/api/focuslock/agent/chat', { testo: '[iofuturo] ' + ifPassoTesto(passo), brief: agBrief() });
    if (!r || !r.id) return false;
    ifScrivi(IF_ATTESA, { msgId: r.id, passo: passo, at: Date.now(), giorno: oggi });
    ifAttendi();
    return true;
  }catch(_){ return false; }
}
function ifAttendi(){
  const giro = async function(){
    const a = ifLeggi(IF_ATTESA, null);
    if (!a || !a.msgId) return;
    if (Date.now() - a.at > 10 * 60000){ try{ localStorage.removeItem(IF_ATTESA); }catch(_){ } return; }
    try{
      const r = await agApi('GET', '/api/focuslock/agent/chat?after=' + (a.msgId - 1));
      const risp = ((r && r.messaggi) || []).filter(function(m){ return m.direzione === 'out' && (m.inReplyTo === a.msgId || (m.id > a.msgId && m.azioni && m.azioni.iofuturo)); })[0];
      if (risp){
        try{ localStorage.removeItem(IF_ATTESA); }catch(_){ }
        const io = (risp.azioni && risp.azioni.iofuturo) || null;
        const testo = String((io && io.testo) || '').trim();
        if (!testo) return;
        const lettera = { testo: testo, bottone: String((io && io.bottone) || '').trim().slice(0, 24), passo: a.passo, at: Date.now(), giorno: a.giorno, consegnata: false };
        ifScrivi(IF_LET, lettera);
        const diario = ifLeggi(IF_KEYS.diario, []) || [];
        diario.push({ id: 'l' + Date.now().toString(36), tema: 'lettera', testo: testo, t: Date.now(), giorno: a.giorno, fonte: 'agent' });
        ifScrivi(IF_KEYS.diario, diario.slice(-400));
        /* subito, se e' stato un gesto fatto adesso; la sessione aspetta lo scrigno o l'apertura */
        if (a.passo && a.passo.tipo !== 'focus') ifConsegna('gesto');
        return;
      }
    }catch(_){ }
    setTimeout(giro, 6000);
  };
  setTimeout(giro, 5000);
}
/** La lettera pronta: si consegna adesso se il momento e' giusto. Torna true se e' stata aperta. */
async function ifConsegna(via){
  const l = ifLeggi(IF_LET, null);
  if (!l || l.consegnata || !l.testo) return false;
  if (document.hidden || document.getElementById('ifPop')) return false;
  if (via !== 'scrigno'){
    if (ifInConfigurazione()) return false;
    const occupato = ['s-ff-done', 's-fullfocus'].some(function(id){ const e = document.getElementById(id); return e && e.classList.contains('active'); });
    if (occupato) return false;
  }
  try{ if (typeof silOra === 'function' && await silOra()) return false; }catch(_){ }
  l.consegnata = true; l.consegnataAt = Date.now(); l.via = via;
  ifScrivi(IF_LET, l);
  ifPopup({ id: 'l' + l.at, testo: l.testo, bottone: l.bottone, tema: 'lettera' });
  return true;
}
/** Una lettera pronta e non ancora letta (per lo scrigno). */
function ifLetteraPronta(){ const l = ifLeggi(IF_LET, null); return (l && !l.consegnata && l.testo) ? l : null; }
/** La sessione parte: si chiede la lettera adesso, cosi' e' pronta quando si apre lo scrigno. */
function ifPrimaSessione(run){
  try{
    if (!run || !run.intensive || run.meditazione || (run.minutes || 0) < IF_CFG.focusMinMin) return;
    let task = ''; try{ const one = (typeof stOne === 'function') ? stOne() : null; task = one && one.task ? String(one.task.text || one.task.t || one.task || '').slice(0, 120) : ''; }catch(_){ }
    ifRichiedi({ tipo: 'focus', min: run.minutes, task: task || run.intent || '' });
  }catch(_){ }
}
/** La sessione e' stata mollata: la lettera che parlava di una sessione finita si butta. */
function ifSessioneMollata(){
  const l = ifLeggi(IF_LET, null);
  if (l && !l.consegnata && l.passo && l.passo.tipo === 'focus'){ l.consegnata = true; l.via = 'scartata'; ifScrivi(IF_LET, l); }
  const a = ifLeggi(IF_ATTESA, null);
  if (a && a.passo && a.passo.tipo === 'focus'){ a.scarta = true; ifScrivi(IF_ATTESA, a); }
}
/** I traguardi della serie in severa (gli stessi del pannello con la fiamma). */
function ifSerieTraguardo(n){
  if (!(n > 0) || typeof BLK_PIETRE === 'undefined' || !BLK_PIETRE[n]) return;
  const k = 'fl_if_serie_premiata';
  if (+ifLeggi(k, 0) >= n) return;
  ifScrivi(k, n);
  ifRichiedi({ tipo: 'serie', n: n });
}
/* all'apertura dell'app: se c'e' una lettera pronta, e' il momento */
setTimeout(function(){ ifConsegna('apertura'); if (ifLeggi(IF_ATTESA, null)) ifAttendi(); }, 3500);
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(function(){ ifConsegna('apertura'); }, 1800); });
async function ifDopoPasso(passo){
  if (IF.inCorso) return;
  IF.inCorso = true;
  try{
    const c = await ifContenuti();
    if (!c) return;
    const giorno = await ifGiorno();
    const diario = ifLeggi(IF_KEYS.diario, []) || [];
    const giaOggi = diario.some(function(m){ return m.giorno === giorno.key; });
    const ok = ifPuoMostrare({ severa: ifSevera(), passoReale: !!passo, giaOggi: giaOggi, inSessione: ifInConfigurazione(), inConfigurazione: false });
    if (!ok) return;
    const ctx = ifContesto(giorno, passo);
    const msg = ifGenera(ctx, c, IF_CFG);
    diario.push({ id: msg.id, tema: msg.tema, testo: msg.testo, t: Date.now(), giorno: giorno.key, fonte: msg.fonte });
    ifScrivi(IF_KEYS.diario, diario.slice(-400));
    const imp = ifImpost();
    if (imp.popup) ifPopup(msg);
    ifCardPaint();
  } finally { IF.inCorso = false; }
}
/** La prima lettura del giorno: e' questa che la riserva di dopamina premia, una volta. */
function ifSegnaVista(giornoKey){
  const l = ifLeggi(IF_KEYS.viste, []) || [];
  if (l.some(function(t){ return ifKey(t) === giornoKey || t >= ifMezzanotte(); })) return;
  l.push(Date.now());
  ifScrivi(IF_KEYS.viste, l.slice(-60));
  try{ if (typeof dpCalcola === 'function') dpCalcola(true).then(function(){ if (typeof dpRidipingi === 'function') dpRidipingi(); }); }catch(_){ }
}
function ifImpost(){ return Object.assign({ popup: true, immagine: 'profilo' }, ifLeggi(IF_KEYS.impost, {}) || {}); }

/* ---------------------------------------------------------------------------------------
   IL POP-UP
   --------------------------------------------------------------------------------------- */
const IF_IMG_KEY = 'fl_if_img';       // l'immagine scelta apposta da «Chi saro'»: vince su tutto
function ifImmagini(){
  let foto = '', roadmap = '', propria = '';
  try{ foto = localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
  try{ roadmap = localStorage.getItem('fl_why_img') || ''; }catch(_){ }
  try{ propria = localStorage.getItem(IF_IMG_KEY) || ''; }catch(_){ }
  const imp = ifImpost();
  let cerchio = propria || (imp.immagine === 'roadmap' ? (roadmap || foto) : (foto || roadmap));
  return { cerchio: cerchio, sfondo: roadmap || propria, senzaFoto: !foto && !propria, propria: propria };
}
/** Scegliere o togliere l'immagine dell'Io Futuro dalla pagina «Chi saro'». */
function ifImgScegli(){
  if (typeof flImgPick !== 'function'){ if (typeof toast === 'function') toast('Non riesco ad aprire le immagini qui'); return; }
  flImgPick(IF_IMG_KEY, function(){ ifIdentitaPaint(); ifCardPaint(); }, true);
}
function ifImgTogli(){
  try{ localStorage.removeItem(IF_IMG_KEY); }catch(_){ }
  ifIdentitaPaint(); ifCardPaint();
}
function ifAvatarHtml(im, cls){
  return im.cerchio
    ? '<div class="if-av ' + (cls || '') + '" style="background-image:url(\'' + im.cerchio + '\')"></div>'
    : '<div class="if-av vuoto ' + (cls || '') + '">🌅</div>';
}
function ifPopup(msg){
  const vecchio = document.getElementById('ifPop'); if (vecchio) vecchio.remove();
  const im = ifImmagini();
  const bottoni = ifUi('bottoni') || ['OK'];
  const n = (ifLeggi(IF_KEYS.diario, []) || []).length;
  const box = document.createElement('div');
  box.id = 'ifPop'; box.className = 'if-pop';
  box.innerHTML = (im.sfondo ? '<div class="if-bg" style="background-image:url(\'' + im.sfondo + '\')"></div>' : '<div class="if-bg vuoto"></div>')
    + '<div class="if-card">'
    +   ifAvatarHtml(im, 'grande')
    +   '<small class="if-kick">' + ifEsc(ifUi('titolo')) + '</small>'
    +   '<p class="if-testo">' + ifEsc(msg.testo) + '</p>'
    +   (im.senzaFoto ? '<p class="if-invito">' + ifEsc(ifUi('foto_invito')) + '</p>' : '')
    +   '<button type="button" class="cta if-ok" onclick="ifChiudiPopup()">' + ifEsc(msg.bottone || bottoni[n % bottoni.length]) + '</button>'
    +   '<button type="button" class="if-rilink" onclick="ifChiudiPopup();ifDiarioApri()">Apri il mio diario di viaggio ›</button>'
    + '</div>';
  (document.getElementById('phone') || document.body).appendChild(box);
  requestAnimationFrame(function(){ box.classList.add('in'); });
  ifGiorno().then(function(g){ ifSegnaVista(g.key); });
}
function ifChiudiPopup(){
  const b = document.getElementById('ifPop');
  if (!b) return;
  b.classList.remove('in');
  setTimeout(function(){ b.remove(); }, 260);
}

/* ---------------------------------------------------------------------------------------
   LA CARD NELLA ROADMAP e il diario
   --------------------------------------------------------------------------------------- */
async function ifCardPaint(){
  const host = document.getElementById('ifCardHost');
  if (!host) return;
  /* niente card fissa nella Roadmap: il messaggio arriva solo come lettera-premio (ifRichiedi) */
  host.innerHTML = ''; host.hidden = true;
  return;
  if (!(await ifContenuti())){ host.innerHTML = ''; return; }
  const g = await ifGiorno();
  const diario = ifLeggi(IF_KEYS.diario, []) || [];
  const oggi = diario.filter(function(m){ return m.giorno === g.key; }).slice(-1)[0];
  const ultimo = diario.slice(-1)[0];
  const im = ifImmagini();
  const severa = ifSevera();
  const serie = severa ? ifStreak() : 0;
  let testo;
  if (!severa) testo = ifUi('card_spenta');
  else if (oggi) testo = oggi.testo;
  else testo = ifUi('card_attesa');
  host.innerHTML = '<button type="button" class="if-rcard' + (oggi ? '' : ' attesa') + '" onclick="ifDiarioApri()">'
    + '<div class="if-rtesta">' + ifAvatarHtml(im, 'medio')
    +   '<div><b>' + ifEsc(ifUi('titolo')) + '</b>' + (serie ? '<small>🔥 ' + ifEsc(ifUi('card_serie').replace('{n}', serie)) + '</small>' : '') + '</div></div>'
    + '<p class="if-rtesto">' + ifEsc(testo) + '</p>'
    + (ultimo ? '<small class="if-rgo">' + ifEsc(ifUi('card_rileggi')) + ' ›</small>' : '')
    + '</button>';
  /* chi ha spento il pop-up legge il messaggio qui: la prima lettura vale lo stesso */
  const tab = document.getElementById('tab-severa');
  if (oggi && !ifImpost().popup && tab && tab.classList.contains('on') && !document.hidden) ifSegnaVista(g.key);
}

registerScreen('s-iofuturo',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title" id="ifDiarioT">Il diario dei progressi</b></div>'
  + '<div id="ifDiario" class="dp-page"></div>', { back: 's-home' });
async function ifDiarioApri(){ goId('s-iofuturo'); await ifDiarioPaint(); }
async function ifDiarioPaint(){
  const host = document.getElementById('ifDiario');
  if (!host || !(await ifContenuti())) return;
  const t = document.getElementById('ifDiarioT'); if (t) t.textContent = ifUi('diario_titolo');
  const imp = ifImpost();
  const lista = (ifLeggi(IF_KEYS.diario, []) || []).slice().reverse();
  const loc = (typeof flLocale === 'function') ? flLocale() : 'it-IT';
  const scelta = function(v, l){ return '<button type="button" class="' + (imp.immagine === v ? 'on' : '') + '" onclick="ifImpostSet(\'immagine\',\'' + v + '\')">' + ifEsc(l) + '</button>'; };
  host.innerHTML =
      (lista.length ? '<div class="if-diario">' + lista.map(function(m){
        return '<div class="if-dvoce"><small>' + new Date(m.t).toLocaleDateString(loc, { weekday: 'long', day: 'numeric', month: 'long' }) + '</small><p>' + ifEsc(m.testo) + '</p></div>';
      }).join('') + '</div>' : '<p class="hintline">' + ifEsc(ifUi('diario_vuoto')) + '</p>')
    + '<div class="sect"><b>' + flIngranaggio(18) + ' ' + ifEsc(ifUi('imp_titolo')) + '</b></div>'
    + '<label class="if-riga"><span>' + ifEsc(ifUi('imp_popup')) + '</span><input type="checkbox" ' + (imp.popup ? 'checked' : '') + ' onchange="ifImpostSet(\'popup\', this.checked)"></label>'
    + '<div class="if-riga col"><span>' + ifEsc(ifUi('imp_immagine')) + '</span><div class="dp-chip">' + scelta('profilo', ifUi('imp_foto')) + scelta('roadmap', ifUi('imp_roadmap')) + '</div></div>'
    + '<button type="button" class="if-link" onclick="ifIdentitaApri()">🪞 ' + ifEsc(ifUi('id_titolo')) + ' ›</button>';
}
function ifImpostSet(k, v){
  const imp = ifImpost(); imp[k] = v; ifScrivi(IF_KEYS.impost, imp);
  ifDiarioPaint(); ifCardPaint();
}

/* ---------------------------------------------------------------------------------------
   «CHI SARO'» — i due campi liberi, il genere, il profilo identita' da vedere e correggere
   --------------------------------------------------------------------------------------- */
registerScreen('s-identita',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title" id="ifIdT">Chi sarò</b></div>'
  + '<div id="ifId" class="dp-page"></div>', { back: 's-home' });
async function ifIdentitaApri(){ goId('s-identita'); await ifIdentitaPaint(); }
async function ifIdentitaPaint(){
  const host = document.getElementById('ifId');
  if (!host || !(await ifContenuti())) return;
  const t = document.getElementById('ifIdT'); if (t) t.textContent = ifUi('id_titolo');
  const id = ifIdentita();
  const p = ifProfiloOra();
  const gen = function(v, k){ return '<button type="button" class="' + ((id.genere || '') === v ? 'on' : '') + '" onclick="ifGenereSet(\'' + v + '\')">' + ifEsc(ifUi(k)) + '</button>'; };
  const im = ifImmagini();
  host.innerHTML =
      '<div class="if-img"><div class="if-img-t"><b>' + ifEsc(ifUi('id_img')) + '</b><small>' + ifEsc(ifUi('id_img_sub')) + '</small></div>'
    +   '<div class="if-img-r">' + ifAvatarHtml(im, 'medio')
    +     '<button type="button" class="btn primary" onclick="ifImgScegli()">' + ifEsc(im.propria ? ifUi('id_img_cambia') : ifUi('id_img_scegli')) + '</button>'
    +     (im.propria ? '<button type="button" class="ff-ask-no if-img-x" onclick="ifImgTogli()">' + ifEsc(ifUi('id_img_togli')) + '</button>' : '')
    +   '</div></div>'
    + '<label class="if-campo"><b>' + ifEsc(ifUi('id_chi')) + '</b><input class="fin" id="ifChi" placeholder="' + ifEsc(ifUi('id_chi_ph')) + '" value="' + ifEsc(id.chiSaro || '') + '"></label>'
    + '<label class="if-campo"><b>' + ifEsc(ifUi('id_perche')) + '</b><textarea class="fin" id="ifPerche" rows="2" placeholder="' + ifEsc(ifUi('id_perche_ph')) + '">' + ifEsc(id.perche || '') + '</textarea></label>'
    + '<button type="button" class="cta" onclick="ifIdentitaSalva()">' + ifEsc(ifUi('id_salva')) + '</button>'
    /* 0.9.298, Andrea: "la pagina Chi saro' collegata al modello Notion, gia' compilata, e la storia modificabile come in
       MyFutureSelf" (io-futuro-livello.js) */
    + ifNuovoMeHtml()
    /* 0.9.253, Andrea: l'identita' dell'Io futuro per esteso, da un file .md o da immagini (riferimenti.js) */
    + ((typeof rfSezioneHtml === 'function') ? rfSezioneHtml('iofuturo', 'Chi sarò, per esteso', 'Un file .md con l’identità del tuo Io futuro (come parla, cosa ha fatto, cosa pensa di te oggi), o delle immagini di riferimento. Nelle chiamate parla da lì.') : '')
    + '<div class="if-riga col"><span>' + ifEsc(ifUi('id_genere')) + '</span><div class="dp-chip">' + gen('m', 'id_genere_m') + gen('f', 'id_genere_f') + gen('', 'id_genere_n') + '</div></div>'
    + '<div class="sect"><b>🧭 ' + ifEsc(ifUi('id_profilo')) + '</b></div>'
    + '<p class="hintline">' + ifEsc(ifUi('id_profilo_sub')) + '</p>'
    + Object.keys(IF_CFG.attributi).map(function(attr){
        const x = p[attr] || {};
        const nota = x.fonte === 'utente' ? ifUi('id_scelto') : (x.valore ? ifUi('id_dal_genio') + ' · ' + Math.round((x.conf || 0) * 100) + '%' : '—');
        return '<div class="if-attr"><div class="if-attr-t"><b>' + ifEsc(ifUi('attr', attr)) + '</b><small>' + ifEsc(nota) + '</small></div>'
          + '<div class="dp-chip">' + IF_CFG.attributi[attr].map(function(k){
              return '<button type="button" class="' + (x.valore === k ? 'on' : '') + '" onclick="ifAttrSet(\'' + attr + '\',\'' + k + '\')">' + ifEsc((ifUi('valori', attr) || {})[k] || k) + '</button>';
            }).join('') + '</div></div>';
      }).join('')
    + '<button type="button" class="if-link" onclick="ifConsensoApri()">🔐 ' + ifEsc(ifUi('consenso_titolo')) + ' · ' + ifEsc(ifUi('consenso_spento')) + '</button>';
}
function ifNuovoMeHtml(){
  const o = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : {};
  const id = o.identita;
  const ch = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  return '<div class="sect" style="margin-top:22px"><b>🪞 Il tuo nuovo te</b></div>'
    + (id ? '<div class="if-nm"><b>' + ifEsc(id.identity_statement) + '</b>' + (id.vote_actions || []).map(function(t){ return '<small>🗳️ ' + ifEsc(t) + '</small>'; }).join('') + '</div>'
          : '<p class="hintline">Lo costruisci nel livello "Il tuo Io Futuro ti sta chiamando", subito dopo il Sabotatore.</p>')
    + '<div class="setrow" onclick="nfApri(\'s-identita\')"><span>📖</span><b>La tua storia</b><small>' + (id ? 'Cambia le risposte' : 'Comincia') + '</small><span class="if-ch">' + ch + '</span></div>'
    + '<div class="setrow" onclick="nfNotion(\'s-identita\')"><span>📝</span><b>Il mio io futuro</b><small>La pagina nel piano</small><span class="if-ch">' + ch + '</span></div>';
}
function ifIdentitaSalva(){
  const id = ifIdentita();
  const chi = document.getElementById('ifChi'), pe = document.getElementById('ifPerche');
  id.chiSaro = chi ? chi.value.trim() : id.chiSaro;
  id.perche = pe ? pe.value.trim() : id.perche;
  ifScrivi(IF_KEYS.ident, id);
  if (typeof toast === 'function') toast(ifUi('id_salvato'));
}
function ifGenereSet(v){ const id = ifIdentita(); id.genere = v; ifScrivi(IF_KEYS.ident, id); ifIdentitaPaint(); }
function ifAttrSet(attr, k){
  const id = ifIdentita(); id.manuale = id.manuale || {};
  if (id.manuale[attr] === k) delete id.manuale[attr]; else id.manuale[attr] = k;
  ifScrivi(IF_KEYS.ident, id); ifIdentitaPaint();
}

/* ---------------------------------------------------------------------------------------
   L'APPRENDIMENTO GLOBALE — la schermata del consenso, in bozza. Spento: niente parte.
   --------------------------------------------------------------------------------------- */
const IF_GLOBAL = GlobalInsights({ leggi: function(){ return ifLeggi(IF_KEYS.global, null); }, scrivi: function(v){ ifScrivi(IF_KEYS.global, v); } }, IF_CFG);
registerScreen('s-consenso-genio',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title">🔐</b></div>'
  + '<div id="ifConsenso" class="dp-page dp-info"></div>', { back: 's-identita' });
async function ifConsensoApri(){
  goId('s-consenso-genio');
  const host = document.getElementById('ifConsenso');
  if (!host || !(await ifContenuti())) return;
  host.innerHTML = '<h2>' + ifEsc(ifUi('consenso_titolo')) + '</h2>'
    + (ifUi('consenso_testo') || []).map(function(x){ return '<p>' + ifEsc(x) + '</p>'; }).join('')
    /* mai preselezionato, e finche' la funzione non c'e' non si puo' accendere */
    + '<label class="if-riga"><span>' + ifEsc(ifUi('consenso_titolo')) + '</span><input type="checkbox" disabled></label>'
    + '<p class="dp-fine">' + ifEsc(ifUi('consenso_spento')) + '</p>';
}

/* ---------------------------------------------------------------------------------------
   I GANCI
   --------------------------------------------------------------------------------------- */
/* una riga spuntata adesso, dall'utente, su questo dispositivo */
document.addEventListener('fl:spunta', function(){
  try{
    const oggi = ifKey(Date.now());
    const fatte = (ifLeggi('fl_notes_done', []) || []).filter(function(x){ return x && x.day === oggi; });
    const viste = ifLeggi(IF_KEYS.spunte, { giorno: '', n: 0 }) || {};
    const prima = viste.giorno === oggi ? viste.n : 0;
    ifScrivi(IF_KEYS.spunte, { giorno: oggi, n: fatte.length });
    if (fatte.length <= prima || document.hidden) return;
    const ultima = fatte.slice().sort(function(a, b){ return (a.at || 0) - (b.at || 0); }).slice(-1)[0];
    if (!ultima || ultima.da === 'telefono' || !(Date.now() - (ultima.at || 0) < 60000)) return;
    ifRichiedi({ tipo: 'task', testo: ultima.text });
  }catch(_){ }
});
/* la priorita' del giorno spuntata a mano */
(function(){
  if (typeof stOneTick !== 'function') return;
  const orig = stOneTick;
  stOneTick = function(){
    const one = (typeof stOne === 'function') ? stOne() : null;
    const r = orig.apply(this, arguments);
    const tx = one && one.task && (one.task.text || one.task);
    if (one && !((typeof stOne === 'function') && stOne())) ifRichiedi({ tipo: 'task', testo: String(tx || '') });
    return r;
  };
})();
document.addEventListener('fl:tab', function(e){ if (e.detail === 'severa'){ ifCardPaint(); guidaPaint(); } });

/* ---------------------------------------------------------------------------------------
   «OTTIENI UNA GUIDA 1-1» — dopo la lettura del Genio
   --------------------------------------------------------------------------------------- */
function guidaPronta(){ try{ const r = (typeof orLast === 'function') ? orLast() : null; return !!(r && r.profile); }catch(_){ return false; } }
function guidaPaint(){
  const host = document.getElementById('guidaHost');
  if (!host) return;
  if (!guidaPronta()){ host.innerHTML = ''; return; }
  host.innerHTML = '<h3 class="gd-h">Ottieni una guida 1-1</h3>'
    + '<button type="button" class="gd-card" onclick="guidaApri()">'
    +   '<span class="gd-ico">🧞</span>'
    +   '<div><b>Il tuo agente personale</b><small>Parte dalla tua lettura del Genio e ti prepara piano e percorso su misura, uno a uno.</small></div>'
    +   '<span class="gd-go"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></span>'
    + '</button>';
}
registerScreen('s-guida',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title">Guida 1-1</b></div>'
  + '<div id="guidaPag" class="dp-page dp-info"></div>', { back: 's-home' });
function guidaApri(){
  goId('s-guida');
  const host = document.getElementById('guidaPag');
  if (!host) return;
  /* 0.9.293, Andrea: "dice ancora Arriva con Premium e Avvisami quando arriva, ma l'agente personale c'e' gia'. Le emoji
     attaccate al testo, e mezza pagina a sinistra e mezza al centro". Tutto a sinistra, le emoji in una bolla, e il
     pulsante che crea l'agente adesso. */
  const voce = function(ico, t, d){ return '<div class="gd-voce"><span class="gd-bolla">' + ico + '</span><div><b>' + t + '</b><small>' + d + '</small></div></div>'; };
  host.className = 'gd-pag';
  host.innerHTML = '<span class="gd-bolla gd-bolla-xl">🧞</span>'
    + '<h2>Il tuo agente personale</h2>'
    + '<p class="gd-sub">Parte dalla tua lettura del Genio e dalle tue giornate vere.</p>'
    + '<div class="gd-voci">'
    +   voce('🗺️', 'Un percorso solo tuo', 'Il piano lo scrive con te, passo per passo.')
    +   voce('💬', 'Uno a uno', 'Quando sei bloccato gli chiedi cosa fare, e ti risponde su di te.')
    +   voce('🔮', 'Un Genio più preciso', 'Quello che sa di te rende le previsioni più giuste.')
    + '</div>'
    + '<button type="button" class="cta gd-cta" onclick="guidaCrea()">Crea il mio agente</button>';
}
async function guidaCrea(){
  if (typeof agAbilitato !== 'function' || typeof agApri !== 'function'){ if (typeof toast === 'function') toast('Disponibile nell\u2019app installata'); return; }
  if (await agAbilitato(true)){ agApri(); return; }
  if (typeof toast === 'function') toast('L\u2019agente si crea con il tuo account: accedi con Google dal Profilo, poi riprova.');
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.gd-pag{padding:6px 4px 28px;text-align:left}'
    + '.gd-bolla{flex:none;width:44px;height:44px;border-radius:50%;background:var(--blue-soft,#E6F2FF);display:flex;align-items:center;justify-content:center;font-size:22px}'
    + 'body.dark .gd-bolla{background:rgba(63,159,244,.18)}'
    + '.gd-bolla-xl{width:72px;height:72px;font-size:38px;margin:4px 0 14px}'
    + '.gd-pag h2{margin:0;font:800 24px/1.2 var(--font-display);color:var(--navy)}'
    + '.gd-sub{margin:8px 0 20px;font:500 15px/1.5 var(--font-body);color:var(--muted)}'
    + '.gd-voci{display:flex;flex-direction:column;gap:16px;padding:18px 16px;border-radius:20px;background:var(--card);border:1px solid var(--line)}'
    + '.gd-voce{display:flex;gap:14px;align-items:center}'
    + '.gd-voce b{display:block;font:700 15.5px/1.3 var(--font-display);color:var(--navy)}'
    + '.gd-voce small{display:block;margin-top:3px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}'
    + '.gd-cta{margin-top:24px}';
  document.head.appendChild(st);
})();

(function ifStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.if-pop{position:fixed;inset:0;z-index:9100;display:flex;align-items:center;justify-content:center;padding:24px;opacity:0;transition:opacity .3s ease}',
    '.if-pop.in{opacity:1}',
    '.if-bg{position:absolute;inset:0;background-size:cover;background-position:center;filter:blur(14px) brightness(.35);transform:scale(1.1)}',
    '.if-bg.vuoto{background:radial-gradient(120% 80% at 50% 0%,#12305F,#040B1C)}',
    '.if-card{position:relative;width:100%;max-width:340px;text-align:center;color:#fff;transform:translateY(14px);transition:transform .45s cubic-bezier(.2,.8,.2,1)}',
    '.if-pop.in .if-card{transform:none}',
    '.if-av{border-radius:50%;background-size:cover;background-position:center;margin:0 auto;display:flex;align-items:center;justify-content:center}',
    '.if-av.grande{width:112px;height:112px;box-shadow:0 0 0 3px rgba(255,255,255,.85),0 0 34px 8px rgba(11,132,255,.55)}',
    '.if-av.medio{width:52px;height:52px;flex:none;box-shadow:0 0 0 2px #fff,0 0 16px 3px rgba(11,132,255,.4)}',
    '.if-av.vuoto{background:rgba(255,255,255,.12);font-size:40px}',
    '.if-av.medio.vuoto{font-size:24px}',
    '.if-kick{display:block;margin:22px 0 10px;font:800 11px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.72)}',
    '.if-testo{margin:0 0 18px;font:600 17px/1.5 var(--font-display);color:#fff}',
    '.if-invito{margin:0 0 14px;font:500 12.5px/1.45 var(--font-body);color:rgba(255,255,255,.7)}',
    '.if-ok{width:100%}',
    '.if-rilink{display:block;margin:12px auto 0;border:0;background:transparent;color:rgba(255,255,255,.8);font:700 13px var(--font-body);cursor:pointer}',
    '.if-rcard{display:block;width:100%;text-align:left;margin:16px 0;padding:16px;border:0;border-radius:18px;cursor:pointer;color:#fff;background:linear-gradient(135deg,#0E2350,#0B3E86);box-shadow:0 10px 26px rgba(0,30,68,.28)}',
    '.if-rcard.attesa{background:linear-gradient(135deg,#132038,#1B2E52)}',
    '.if-rtesta{display:flex;align-items:center;gap:12px}',
    '.if-rtesta b{display:block;font:800 15px var(--font-display);color:#fff}',
    '.if-rtesta small{display:block;margin-top:2px;font:600 12px var(--font-body);color:rgba(255,255,255,.75)}',
    '.if-rtesto{margin:12px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.92)}',
    '.if-rgo{display:block;margin-top:10px;font:700 12px var(--font-body);color:#7FB8FF}',
    '.if-diario{display:flex;flex-direction:column;gap:10px}',
    '.if-dvoce{padding:14px;border:1px solid var(--line);border-radius:14px;background:#fff}',
    'body.dark .if-dvoce{background:#12203A;border-color:#22345A}',
    '.if-dvoce small{display:block;font:700 11px var(--font-body);color:var(--muted);text-transform:capitalize}',
    '.if-dvoce p{margin:6px 0 0;font:500 14px/1.5 var(--font-body);color:var(--navy)}',
    'body.dark .if-dvoce p{color:#fff}',
    '.if-riga{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid var(--line);font:600 14px var(--font-body);color:var(--navy)}',
    'body.dark .if-riga{color:#fff}',
    '.if-riga.col{flex-direction:column;align-items:flex-start}',
    '.if-riga input[type=checkbox]{width:20px;height:20px;flex:none}',
    '.if-link{display:block;width:100%;margin-top:18px;padding:12px;border:1px dashed var(--line);border-radius:14px;background:none;font:700 13.5px var(--font-body);color:var(--blue,#0075E3);cursor:pointer;text-align:left}',
    '.if-img{margin:0 0 18px;padding:14px;border:1px solid var(--line);border-radius:16px;background:#fff}',
    'body.dark .if-img{background:#12203A;border-color:#22345A}',
    '.if-nm{margin:0 0 10px;padding:14px 16px;border-radius:18px;background:linear-gradient(160deg,#0E2350,#0B3E86);color:#fff}.if-nm b{display:block;font:800 16px/1.4 var(--font-display);margin-bottom:6px}.if-nm small{display:block;margin-top:4px;font:600 13px/1.4 var(--font-body);color:#C8EFFD}',
    '.if-ch{margin-left:auto;display:flex;color:var(--muted)}',
    '.if-img-t b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .if-img-t b{color:#fff}',
    '.if-img-t small{display:block;margin-top:4px;font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.if-img-r{display:flex;align-items:center;gap:12px;margin-top:12px}',
    '.if-img-r .btn{flex:none;width:auto;margin:0;padding:9px 16px;font-size:13px}',
    '.if-img-x{width:auto;margin:0;padding:9px 6px}',
    '.if-campo{display:block;margin:0 0 14px}',
    '.if-campo b{display:block;margin-bottom:6px;font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .if-campo b{color:#fff}',
    '.if-campo .fin{width:100%;box-sizing:border-box}',
    '.if-attr{margin:0 0 14px}',
    '.if-attr-t{display:flex;justify-content:space-between;align-items:baseline;gap:8px}',
    '.if-attr-t b{font:800 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .if-attr-t b{color:#fff}',
    '.if-attr-t small{font:600 11.5px var(--font-body);color:var(--muted)}',
    '.if-attr .dp-chip{justify-content:flex-start;margin-top:8px}',
    /* la guida 1-1, come le card scure delle app di benessere */
    '.gd-h{margin:22px 0 10px;font:800 21px var(--font-display);color:var(--navy)}',
    'body.dark .gd-h{color:#fff}',
    '.gd-card{display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:18px 16px;border-radius:20px;border:1px solid rgba(255,255,255,.14);background:linear-gradient(135deg,#0A1024,#141B3A);color:#fff;cursor:pointer}',
    '.gd-ico{flex:none;width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:34px;background:radial-gradient(circle,#3F9FF4 0%,#0E2350 70%);box-shadow:0 0 24px rgba(63,159,244,.55)}',
    '.gd-card b{display:block;font:800 17px var(--font-display);color:#fff}',
    '.gd-card small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:rgba(255,255,255,.72)}',
    '.gd-go{flex:none;font:700 24px var(--font-body);color:rgba(255,255,255,.6)}'
  ].join('');
  document.head.appendChild(st);
})();

/* all'avvio: la card e il pannello, se la scheda e' gia' li' */
setTimeout(function(){ try{ ifCardPaint(); guidaPaint(); }catch(_){ } }, 1500);
