/* ===========================================================================================
   IO FUTURO — IL MOTORE (puro: niente pagina, niente telefono, niente rete)

   La versione di te che ha gia' raggiunto l'obiettivo ti scrive una volta al giorno, dopo il
   primo passo reale, riconoscendo fatti misurati. Basi: la continuita' con il se' futuro
   (Hershfield) e l'elogio del processo, non del talento (Dweck).

   Qui dentro ci sono le regole, tutte provabili con node tools/test-iofuturo.js:
     · quando puo' comparire (ifPuoMostrare);
     · il generatore di oggi, a template (TemplateMessageProvider), e il posto gia' pronto per
       l'agente personale premium (AgentMessageProvider, spento), con la STESSA validazione;
     · il profilo identita' (IdentityProfileSource): oggi lo alimenta il Genio, domani anche
       l'agente. Tutto in locale;
     · il modulo per l'apprendimento globale (GlobalInsights): solo la struttura, spenta.
   =========================================================================================== */

const IF_CFG = {
  maxCaratteri: 280,
  giorniNoRipetizione: 14,
  traguardi: [7, 14, 21, 30, 60, 100],
  bonusRiserva: 0.3,                 // la prima lettura del giorno, nella riserva di dopamina
  focusMinMin: 10,                   // una sessione vale come primo passo da 10 minuti effettivi
  premium_agent_enabled: false,      // l'agente personale: non ancora
  global_learning_enabled: false,    // l'apprendimento globale anonimo: non ancora
  /* l'ordine dei temi quando piu' di uno e' possibile: il fatto piu' raro vince */
  pesoTema: { traguardo_streak: 50, ritorno_dopo_pausa: 40, record_focus: 30, task_difficile: 20, streak: 10, primo_passo: 0 },
  attributi: {
    tipo: ['diventare', 'raggiungere'],
    dominio: ['business', 'creativita', 'fitness', 'viaggi', 'studio', 'carriera', 'relazioni'],
    valore: ['liberta', 'riconoscimento', 'famiglia', 'indipendenza', 'padronanza'],
    ostacolo: ['dispersione', 'procrastinazione', 'stanchezza', 'perfezionismo']
  },
  confidenzaBassa: 0.5
};

/* ---------------------------------------------------------------------------------------
   QUANDO COMPARE
   stato = { severa, passoReale, giaOggi, inSessione, inConfigurazione, apertura, notifica }
   --------------------------------------------------------------------------------------- */
function ifPuoMostrare(s){
  if (!s || !s.severa) return false;            // 1. solo con la modalita' severa accesa
  if (!s.passoReale) return false;               // 2. solo dopo un passo reale
  if (s.giaOggi) return false;                   // 3. una volta al giorno
  if (s.inSessione || s.inConfigurazione) return false;
  if (s.apertura || s.notifica) return false;    // mai all'apertura, mai da una notifica
  return true;
}

/* ---------------------------------------------------------------------------------------
   I TEMI POSSIBILI OGGI, dai dati reali
   dati = { streak, record, priorita, ritorno, minutiFocus, task, primoPasso }
   --------------------------------------------------------------------------------------- */
function ifTemi(d, cfg){
  cfg = cfg || IF_CFG;
  const t = ['primo_passo'];
  if (d.streak >= 2) t.push('streak');
  if (cfg.traguardi.indexOf(d.streak) >= 0) t.push('traguardo_streak');
  if (d.record) t.push('record_focus');
  if (d.priorita) t.push('task_difficile');
  if (d.ritorno) t.push('ritorno_dopo_pausa');
  return t;
}
function ifIdoneo(tpl, d, cfg){
  const r = tpl.richiede || {};
  if (ifTemi(d, cfg).indexOf(tpl.tema) < 0) return false;
  if (r.streakMin && !(d.streak >= r.streakMin)) return false;
  if (r.traguardo && (cfg || IF_CFG).traguardi.indexOf(d.streak) < 0) return false;
  if (r.record && !d.record) return false;
  if (r.ritorno && !d.ritorno) return false;
  if (r.priorita && !d.priorita) return false;
  return true;
}

/* ---------------------------------------------------------------------------------------
   IL PROFILO IDENTITA'
   Ogni fonte da' dei contributi { attr, k, w }; il profilo e' la somma pesata, con una
   confidenza per attributo: quanto il primo valore stacca gli altri, e quante prove ci sono.
   Una scelta fatta a mano dall'utente vale sempre, con confidenza piena.
   --------------------------------------------------------------------------------------- */
function ifProfilo(sorgenti, manuale){
  const somme = {};
  (sorgenti || []).forEach(function(src){
    let c = [];
    try{ c = src.contributi() || []; }catch(_){ c = []; }
    c.forEach(function(x){
      if (!x || !x.attr || !x.k || !(x.w > 0)) return;
      const a = somme[x.attr] = somme[x.attr] || {};
      a[x.k] = (a[x.k] || 0) + x.w;
    });
  });
  const out = {};
  Object.keys(IF_CFG.attributi).forEach(function(attr){
    if (manuale && manuale[attr]){ out[attr] = { valore: manuale[attr], conf: 1, fonte: 'utente', pesi: somme[attr] || {} }; return; }
    const a = somme[attr] || {};
    const k = Object.keys(a).sort(function(x, y){ return a[y] - a[x]; });
    if (!k.length){ out[attr] = { valore: null, conf: 0, fonte: 'nessuna', pesi: {} }; return; }
    const tot = k.reduce(function(s, x){ return s + a[x]; }, 0);
    const conf = (a[k[0]] / tot) * Math.min(1, tot / 3);
    out[attr] = { valore: k[0], conf: Math.round(conf * 100) / 100, fonte: 'genio', pesi: a };
  });
  return out;
}
/** L'attributo meno chiaro: e' quello che il Genio prova a chiarire con una domanda. */
function ifAttributoIncerto(profilo, cfg){
  cfg = cfg || IF_CFG;
  const l = Object.keys(cfg.attributi).map(function(a){ return { a: a, c: (profilo[a] && profilo[a].conf) || 0 }; })
    .filter(function(x){ return x.c < cfg.confidenzaBassa; })
    .sort(function(x, y){ return x.c - y.c; });
  return l.length ? l[0].a : null;
}

/* ---------------------------------------------------------------------------------------
   IL TESTO: riempire, accordare, controllare
   --------------------------------------------------------------------------------------- */
/** {g:maschile|femminile}: con il genere noto si sceglie; senza, «ripartito/a». */
function ifGenere(testo, genere){
  return testo.replace(/\{g:([^|}]+)\|([^}]+)\}/g, function(_, m, f){
    if (genere === 'm') return m;
    if (genere === 'f') return f;
    return m + '/' + f.slice(-1);
  });
}
function ifCompila(tpl, vars, genere){
  let t = ifGenere(tpl.testo, genere);
  return t.replace(/\{([a-z_]+)\}/g, function(tutto, k){
    const v = vars[k];
    return (v === undefined || v === null || String(v).trim() === '') ? tutto : String(v);
  });
}
/** Il controllo, identico per ogni generatore presente e futuro. */
function ifValida(testo, vietate, cfg){
  cfg = cfg || IF_CFG;
  const errori = [];
  if (!testo || !String(testo).trim()) errori.push('vuoto');
  if (/\{[^}]*\}/.test(testo || '')) errori.push('variabile');
  if (String(testo || '').length > cfg.maxCaratteri) errori.push('lunghezza');
  /* dall'inizio di una parola, non dentro: «giornata perfetta» non contiene «nata per» */
  const basso = String(testo || '').toLowerCase();
  const lettera = function(ch){ return !!ch && ch.toLowerCase() !== ch.toUpperCase(); };
  (vietate || []).forEach(function(w){
    if (!w) return;
    const x = String(w).toLowerCase();
    let i = basso.indexOf(x);
    while (i >= 0){
      if (!lettera(basso.charAt(i - 1))){ errori.push('vietata:' + w); return; }
      i = basso.indexOf(x, i + 1);
    }
  });
  return { ok: !errori.length, errori: errori };
}

/** Quanto un template somiglia alla persona: tipo di obiettivo, campo, valori. */
function ifAffinita(tpl, profilo){
  let s = 0;
  const tipo = profilo && profilo.tipo && profilo.tipo.valore;
  if (tpl.tipo === 'entrambi') s += 2;
  else if (tipo && tpl.tipo === tipo) s += 5 * (profilo.tipo.conf || 0.5);
  else if (tipo && tpl.tipo !== tipo) s -= 3;
  ['dominio', 'valore', 'ostacolo'].forEach(function(attr){
    const p = profilo && profilo[attr];
    const lista = (tpl.tag && tpl.tag[attr]) || [];
    if (p && p.valore && lista.indexOf(p.valore) >= 0) s += 3 * (p.conf || 0.5);
  });
  return s;
}

/* ---------------------------------------------------------------------------------------
   I GENERATORI
   Stessa interfaccia: generate(context) → { id, tema, testo, fonte }. Il context contiene
   solo: nome, profilo identita', obiettivo, perche', chi sarai, genere, dati reali del giorno
   e della settimana, id e temi degli ultimi messaggi. Niente altro.
   --------------------------------------------------------------------------------------- */
function TemplateMessageProvider(contenuti, cfg, caso){
  cfg = cfg || IF_CFG;
  caso = caso || Math.random;
  return {
    nome: 'template',
    generate: function(ctx){
      const d = ctx.dati || {};
      const recenti = {};
      (ctx.recenti || []).forEach(function(r){ if (r && r.t >= (ctx.adesso || 0) - cfg.giorniNoRipetizione * 86400000) recenti[r.id] = 1; });
      const vars = ifVariabili(ctx);
      const cand = (contenuti.template || [])
        .filter(function(t){ return !recenti[t.id] && ifIdoneo(t, d, cfg); })
        .map(function(t){ return { t: t, s: (cfg.pesoTema[t.tema] || 0) + ifAffinita(t, ctx.profilo) }; })
        .sort(function(a, b){ return b.s - a.s; });
      /* un po' di varieta': fra i primi tre dello stesso livello di tema */
      const scarti = [];
      while (cand.length){
        const alto = cand[0].s;
        const primi = cand.filter(function(c){ return c.s >= alto - 6; }).slice(0, 3);
        const scelta = primi[Math.floor(caso() * primi.length) % primi.length];
        cand.splice(cand.indexOf(scelta), 1);
        const testo = ifCompila(scelta.t, vars, ctx.genere);
        const v = ifValida(testo, contenuti.vietate, cfg);
        if (v.ok) return { id: scelta.t.id, tema: scelta.t.tema, testo: testo, fonte: 'template', scartati: scarti };
        scarti.push({ id: scelta.t.id, errori: v.errori });
      }
      /* la rete di sicurezza: sempre valida, sempre vera */
      const sic = contenuti.sicurezza;
      return { id: sic.id, tema: sic.tema, testo: ifCompila(sic, vars, ctx.genere), fonte: 'template', sicurezza: true, scartati: scarti };
    }
  };
}
/** L'agente personale premium: il posto e' pronto, l'implementazione no. */
function AgentMessageProvider(){
  return {
    nome: 'agent',
    generate: function(){ throw new Error('agente non disponibile'); }
  };
}
/**
 * Chi genera il messaggio di oggi. Con l'agente acceso si prova lui; se sbaglia, non risponde
 * o scrive qualcosa che non passa la validazione, si torna ai template. Sempre.
 */
function ifGenera(ctx, contenuti, cfg, fornitori){
  cfg = cfg || IF_CFG;
  const tpl = (fornitori && fornitori.template) || TemplateMessageProvider(contenuti, cfg);
  if (cfg.premium_agent_enabled){
    const ag = (fornitori && fornitori.agent) || AgentMessageProvider();
    try{
      const m = ag.generate(ctx);
      if (m && ifValida(m.testo, contenuti.vietate, cfg).ok) return Object.assign({ fonte: 'agent' }, m);
    }catch(_){ }
  }
  return tpl.generate(ctx);
}
function ifVariabili(ctx){
  const d = ctx.dati || {};
  return {
    nome: ctx.nome || '',
    obiettivo: ctx.obiettivo || '',
    perche: ctx.perche || '',
    chi_saro: ctx.chiSaro || '',
    streak_giorni: d.streak > 0 ? String(d.streak) : '',
    minuti_focus: d.minutiFocus > 0 ? String(d.minutiFocus) : '',
    task_completate: d.task > 0 ? String(d.task) : '',
    record: d.recordMin > 0 ? String(d.recordMin) : '',
    primo_passo: d.primoPasso || '',
    prossimo_passo: d.prossimoPasso || ''
  };
}

/* ---------------------------------------------------------------------------------------
   L'APPRENDIMENTO GLOBALE — solo la struttura, spenta.
   Quando sara' acceso (con consenso esplicito, separato e revocabile) mandera' SOLO conteggi
   aggregati dei percorsi dell'albero (domanda → risposta → esito): mai log grezzi, mai nomi
   di app, mai testi liberi, mai foto, mai dati di salute, nessun identificativo persistente.
   Qui non c'e' nessun invio e nessun server.
   --------------------------------------------------------------------------------------- */
function GlobalInsights(archivio, cfg){
  cfg = cfg || IF_CFG;
  const leggi = function(){ try{ return archivio.leggi() || { consenso: false, coda: {} }; }catch(_){ return { consenso: false, coda: {} }; } };
  return {
    attivo: function(){ return !!cfg.global_learning_enabled && !!leggi().consenso; },
    /** Un percorso dell'albero, come conteggio: solo se acceso e consentito. */
    registra: function(percorso){
      if (!this.attivo() || !percorso || !percorso.q || percorso.a === undefined || !percorso.esito) return false;
      const s = leggi();
      const k = String(percorso.q) + '|' + String(percorso.a) + '|' + String(percorso.esito);
      s.coda[k] = (s.coda[k] || 0) + 1;
      archivio.scrivi(s);
      return true;
    },
    consenti: function(){ const s = leggi(); s.consenso = true; archivio.scrivi(s); },
    /** La revoca cancella anche quello che non e' ancora partito. */
    revoca: function(){ archivio.scrivi({ consenso: false, coda: {} }); },
    pacchetto: function(){ const s = leggi(); return this.attivo() ? { conteggi: Object.assign({}, s.coda) } : null; }
  };
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { IF_CFG: IF_CFG, ifPuoMostrare: ifPuoMostrare, ifTemi: ifTemi, ifIdoneo: ifIdoneo, ifProfilo: ifProfilo,
                     ifAttributoIncerto: ifAttributoIncerto, ifGenere: ifGenere, ifCompila: ifCompila, ifValida: ifValida,
                     ifAffinita: ifAffinita, TemplateMessageProvider: TemplateMessageProvider, AgentMessageProvider: AgentMessageProvider,
                     ifGenera: ifGenera, GlobalInsights: GlobalInsights };
}
