/* ===========================================================================================
   GLI ESERCIZI A TEMPO — cinque tappe della Mappa con un tempo che non si tratta (0.9.180)

   Il Full Focus ha la durata che sceglie l'utente. Qui no: il tempo e' fissato, e' corto, e'
   sempre sullo schermo, non si mette in pausa. Meno tempo c'e', meno se ne spreca.

   LE REGOLE COMUNI
     · conto alla rovescia sempre visibile, legato all'orologio (non a un contatore): non si
       ferma con niente;
     · chi esce dall'app mentre il tempo corre perde l'esercizio;
     · finito in tempo = monete (le stesse del Full Focus: ffCoins / ffAddCoins);
     · a tempo scaduto si possono comprare 30 secondi, solo con le monete, una volta sola;
     · il gettone salva-serie (sentiero.js) si compra con le monete;
     · NESSUN testo qui dentro: stanno tutti in content/esercizi.json;
     · ogni risposta si salva con data e ora in `fl_esercizi` (esStoria la rilegge per il Genio
       e per l'agente Premium);
     · se un dato dell'utente manca, lo scenario usa la sua versione generica.

   I CINQUE
     taglia           60 s  si tagliano le cose una alla volta finche' ne resta una (oggi, la
                            settimana, il mese, l'anno). NIENTE DA SCRIVERE (Andrea, 1/10: scrivere
                            e tagliare sono due esercizi, non uno): le cose sono quelle che l'utente
                            ha gia' scritto nel suo piano, a mente fredda; se non ce ne sono abbastanza
                            e' un quiz con una risposta giusta. Quella di oggi, se e' sua, diventa
                            il compito della prossima sessione di Full Focus
     riordina         60 s  cinque cose in ordine di importanza: il punteggio misura quanto
                            l'ordine scelto e' vicino a quello giusto
     interrogatorio   90 s  10 domande si'/no, 3 secondi l'una, girano ogni giorno
     ripasso         120 s  5 domande a scelta: la risposta giusta e' CALCOLATA dai dati veri
                            degli ultimi 7 giorni
     bivio            90 s  6 situazioni da 15 secondi, riempite con i dati dell'utente
     pitch            60 s  il sogno spiegato in un minuto, una volta a settimana

   Nessun modello linguistico, nessuna chiamata in rete: logica e dati del telefono.
   La parte alta del file e' logica pura (la provano i test: node tools/test-esercizi.js).
   =========================================================================================== */

const ES_KEY = 'fl_esercizi';
const ES_GIORNO = 86400000;
const ES = { cfg: null, caricando: null, run: null, aprendo: false, tok: 0 };

/* ---------------------------------------------------------------------------------------
   LA LOGICA PURA
   --------------------------------------------------------------------------------------- */
function esSeme(s){ let h = 2166136261; s = String(s); for (let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function esRng(seme){ let a = seme >>> 0; return function(){ a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function esMescola(a, rnd){ const b = a.slice(); for (let i = b.length - 1; i > 0; i--){ const j = Math.floor(rnd() * (i + 1)); const x = b[i]; b[i] = b[j]; b[j] = x; } return b; }
function esGiornoK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function esMezzanotte(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
function esRiempi(s, v){ s = String(s == null ? '' : s); if (v) Object.keys(v).forEach(function(k){ s = s.split('{' + k + '}').join(String(v[k])); }); return s; }
function esParole(t){ return String(t || '').trim().split(/\s+/).filter(Boolean).length; }
function esTempoTxt(ms){ const s = Math.max(0, Math.ceil(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function esDurata(min){ min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60; return h ? (h + ' h' + (m ? ' ' + m + ' min' : '')) : (m + ' min'); }
const ES_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
function esGiornoNome(t){ const d = new Date(t); return ES_GIORNI[d.getDay()] + ' ' + d.getDate(); }
function esDataBreve(t){ const d = new Date(t); return d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear(); }

/** Le domande dell'Interrogatorio di oggi: mai quelle dell'ultima volta, finche' il pool basta. */
function esInterScegli(pool, ultimi, n, seme){
  const rnd = esRng(seme);
  const prima = {}; (ultimi || []).forEach(function(id){ prima[id] = 1; });
  const nuove = esMescola(pool.filter(function(q){ return !prima[q.id]; }), rnd);
  const vecchie = esMescola(pool.filter(function(q){ return prima[q.id]; }), rnd);
  return nuove.concat(vecchie).slice(0, n);
}

/** Quattro numeri in fila, a `passo` l'uno dall'altro, mai sotto zero: uno e' quello vero. */
function esOpzioniNumero(giusto, passo, rnd, max){
  passo = Math.max(1, passo);
  /* in che posto puo' stare quello vero: non cosi' avanti da mandare sotto zero i primi, e
     (se c'e' un tetto) non cosi' indietro da mandare oltre il tetto gli ultimi. Se le due cose
     non stanno insieme vince lo zero: un numero negativo non e' una risposta. */
  const pMax = Math.min(3, Math.floor(giusto / passo));
  const pMin = (max != null) ? Math.max(0, 3 - Math.floor((max - giusto) / passo)) : 0;
  const p = (pMin <= pMax) ? pMin + Math.floor(rnd() * (pMax - pMin + 1)) : pMax;
  const v = []; for (let i = 0; i < 4; i++) v.push(giusto + (i - p) * passo);
  return { valori: v, giusta: p };
}

function esFFok(d){ return (d.ff || []).filter(function(x){ return x && x.ok && !x.meditazione; }); }
function esInFascia(ora, f){ return f.da <= f.a ? (ora >= f.da && ora < f.a) : (ora >= f.da || ora < f.a); }

/** Le domande del Ripasso: prima quelle che confrontano il detto col fatto, poi le altre.
    Ogni risposta giusta esce dai dati (`d`), mai da una frase scritta a mano. */
function esRipassoDomande(d, cfg, rnd){
  const R = cfg.ripasso, T = R.testi, M = R.modelli, out = [];
  const ok = esFFok(d);
  const nSess = function(n){ return n === 0 ? T.nessuna : n === 1 ? T.sessioni_una : esRiempi(T.sessioni, { n: n }); };
  const nGiorni = function(n){ return n === 0 ? T.nessuno : n === 1 ? T.giorni_uno : esRiempi(T.giorni, { n: n }); };
  const nMin = function(n){ return esRiempi(T.minuti, { n: n }); };
  const numerica = function(id, testo, giusto, passo, fmt, max){
    const o = esOpzioniNumero(giusto, passo, rnd, max);
    out.push({ id: id, t: testo, opzioni: o.valori.map(fmt), giusta: o.giusta, vero: fmt(giusto) });
  };
  const dich = d.dich || {};

  /* 1. la fascia in cui ha detto di rendere meglio, contro le sessioni fatte in quella fascia */
  const fascia = dich.lucida && R.fasce[dich.lucida];
  if (fascia){
    const n = ok.filter(function(x){ return esInFascia(new Date(x.start || x.at).getHours(), fascia); }).length;
    numerica('lucida_sessioni', esRiempi(M.lucida_sessioni, { fascia: fascia.txt }), n, 1, nSess);
  }
  /* 2. le ore di telefono dichiarate all'inizio, contro la media vera */
  if (+dich.oreN > 0 && (d.giorni || []).length >= 3){
    const media = d.giorni.reduce(function(a, g){ return a + g.ms; }, 0) / d.giorni.length / 60000;
    const m10 = Math.round(media / 10) * 10;
    numerica('ore_dichiarate', esRiempi(M.ore_dichiarate, { ore: (+dich.oreN === 1 ? '1 ora' : dich.oreN + ' ore') }), m10, 50, esDurata);
  }
  /* 3. il tempo che ha detto di poter dare al sogno, contro i minuti di Full Focus al giorno */
  const tempo = dich.tempoSogno && R.tempoSogno[dich.tempoSogno];
  if (tempo){
    const media = Math.round(ok.reduce(function(a, x){ return a + (x.min || 0); }, 0) / 7);
    numerica('tempo_sogno', esRiempi(M.tempo_sogno, { tempo: tempo }), media, media < 20 ? 5 : media < 60 ? 15 : 30, nMin);
  }
  /* 4. l'app piu' usata */
  if ((d.apps || []).length >= 3){
    const prime = d.apps.slice(0, 4);
    const ordine = esMescola(prime, rnd);
    out.push({ id: 'app_top', t: M.app_top, opzioni: ordine.map(function(a){ return a.label; }), giusta: ordine.indexOf(prime[0]), vero: prime[0].label + ' · ' + esDurata(prime[0].ms / 60000) });
  }
  /* 5. il giorno con meno telefono */
  if ((d.giorni || []).length >= 4){
    const meno = d.giorni.slice().sort(function(a, b){ return a.ms - b.ms; })[0];
    const altri = esMescola(d.giorni.filter(function(g){ return g !== meno; }), rnd).slice(0, 3);
    const scelti = altri.concat([meno]).sort(function(a, b){ return a.t - b.t; });
    out.push({ id: 'giorno_meno', t: M.giorno_meno, opzioni: scelti.map(function(g){ return esGiornoNome(g.t); }), giusta: scelti.indexOf(meno), vero: esGiornoNome(meno.t) + ' · ' + esDurata(meno.ms / 60000) });
  }
  /* le domande che non hanno bisogno di niente oltre allo storico delle sessioni */
  const giorniAttivi = {}; ok.forEach(function(x){ giorniAttivi[esGiornoK(x.at)] = 1; });
  numerica('giorni_attivi', M.giorni_attivi, Object.keys(giorniAttivi).length, 1, nGiorni, 7);
  numerica('sessioni_tot', M.sessioni_tot, ok.length, ok.length > 8 ? 2 : 1, nSess);
  const minTot = ok.reduce(function(a, x){ return a + (x.min || 0); }, 0);
  numerica('minuti_tot', M.minuti_tot, minTot, minTot < 40 ? 10 : minTot < 150 ? 25 : 60, nMin);
  const mollate = (d.ff || []).filter(function(x){ return x && !x.ok && !x.meditazione; }).length;
  numerica('mollate', M.mollate, mollate, 1, nSess);
  const lunga = ok.reduce(function(a, x){ return Math.max(a, x.min || 0); }, 0);
  numerica('sessione_lunga', M.sessione_lunga, lunga, lunga < 30 ? 5 : 15, nMin);
  return out.slice(0, R.domande);
}

/** Le variabili che riempiono gli scenari del Bivio. Quello che manca resta fuori. */
function esBivioVariabili(d, cfg){
  const v = {}, dich = d.dich || {};
  const ore = d.oreDelGiorno;
  if (ore && ore.some(function(x){ return x > 0; })){
    let picco = 0; for (let h = 1; h < 24; h++) if (ore[h] > ore[picco]) picco = h;
    v.ora = String(picco).padStart(2, '0') + ':00';
  }
  const apps = d.apps || [];
  const distr = apps.filter(function(a){ return a.cat === 'distr'; })[0] || apps.filter(function(a){ return a.cat !== 'prod'; })[0];
  if (distr && distr.label) v.app = distr.label;
  if (dich.scusa) v.scusa = dich.scusa;
  const motivo = String(dich.motivo || '').replace(/^\s*lo voglio perch[eé]\s*/i, '').replace(/[.…\s]+$/, '').trim();
  if (motivo && motivo.length <= 90) v.motivo = motivo;
  const vecchio = String(dich.vecchio || '').trim();
  if (vecchio && vecchio.length <= 30) v.vecchio = vecchio;
  if (dich.lucida && cfg.bivio.fasce[dich.lucida]) v.fascia = cfg.bivio.fasce[dich.lucida];
  return v;
}
/** Sei scenari: prima quelli che si possono scrivere con i dati dell'utente, poi gli altri. */
function esBivioScenari(d, cfg, rnd){
  const v = esBivioVariabili(d, cfg);
  const tutti = cfg.bivio.modelli.map(function(m){
    const pieno = (m.serve || []).length > 0 && m.serve.every(function(k){ return v[k]; });
    return { id: m.id, personale: pieno, t: pieno ? esRiempi(m.t, v) : m.generico, opzioni: esMescola(m.opzioni.map(function(o){ return { t: o.t, nuovo: !!o.nuovo }; }), rnd) };
  });
  const scelti = esMescola(tutti.filter(function(s){ return s.personale; }), rnd).concat(esMescola(tutti.filter(function(s){ return !s.personale; }), rnd)).slice(0, cfg.bivio.scenari);
  return esMescola(scelti, rnd);
}
/** Un punto solo per esercizio: al nuovo te se quattro scelte su sei sono sue, al vecchio se prevale lui. */
function esBivioPunto(nuovo, vecchio){ return (nuovo >= 4 && nuovo > vecchio) ? 'nuovo' : (vecchio > nuovo ? 'vecchio' : ''); }

/** Le cose da tagliare. Le sue, se ne ha scritte abbastanza per quell'arco di tempo; se no un
    quiz dal file dei testi, con una cosa sola che conta davvero (la prima della lista). */
function esTagliaVoci(arco, mie, cfg, rnd, dati){
  const T = cfg.taglia;
  const sue = (mie || []).map(function(x){ return String(x || '').trim().slice(0, 90); }).filter(Boolean)
    .filter(function(x, i, a){ return a.indexOf(x) === i; }).slice(0, T.maxMie);
  if (sue.length >= T.minMie) return { modo: 'mie', voci: sue.map(function(x){ return { t: x, ess: false }; }), essenziale: '', perche: '' };
  /* Nel piano di oggi non ha scritto niente di suo: prima del quiz, i ladri di tempo veri */
  if (!sue.length && (arco === 'oggi' || arco === 'abitudini') && dati && dati.length >= T.minMie){
    return { modo: 'dati', voci: dati.slice(0, T.maxMie).map(function(x){ return { t: x.t, taglio: x.taglio, ess: false }; }), essenziale: '', perche: '' };
  }
  const set = (T.quiz[arco] && T.quiz[arco].length) ? T.quiz[arco] : T.quiz.oggi;
  const q = set[Math.floor(rnd() * set.length)];
  return { modo: 'quiz', voci: esMescola(q.voci.map(function(x, i){ return { t: x, ess: i === 0 }; }), rnd), essenziale: q.voci[0], perche: q.perche || '' };
}
/** Le cose da tagliare prese dai dati veri, ognuna con la sua regola concreta. Entrano:
    il tempo dentro DreamMap che non e' lavoro (giochi col Genio, impostazioni, musica...),
    le app che distraggono di piu' e le abitudini evidenti (la stessa app aperta tante volte).
    inp = { dentro: [{ nel, cosa, ms, ora }], apps: [{ label, ms }], abitudini: [{ label, n }] },
    con ms al giorno e ora = l'ora tipica (0-23). */
function esTagliaDaDati(inp, cfg){
  const X = (cfg.taglia && cfg.taglia.testi) || {};
  const out = [], viste = {};
  const minuti = function(ms){ return Math.round((ms || 0) / 60000); };
  const regolaOra = function(ora, prima, dopo, v){
    const h = (typeof ora === 'number' && ora >= 0) ? ora : 12;
    return h < 18 ? esRiempi(prima, Object.assign({ ora: 18 }, v)) : esRiempi(dopo, Object.assign({ ora: Math.max(21, h) }, v));
  };
  ((inp && inp.dentro) || []).forEach(function(a){
    if (!a || !a.cosa || minuti(a.ms) < 5) return;
    out.push({ t: esRiempi(X.dati_voce_dentro, { tempo: esDurata(minuti(a.ms)), nel: a.nel }),
               taglio: regolaOra(a.ora, X.dati_regola_prima, X.dati_regola_dopo, { cosa: a.cosa }) });
  });
  ((inp && inp.abitudini) || []).forEach(function(a){
    if (!a || !a.label || (a.n || 0) < 15 || viste[a.label]) return;
    viste[a.label] = 1;
    out.push({ t: esRiempi(X.dati_voce_aperture, { app: a.label, n: a.n }),
               taglio: esRiempi(X.dati_regola_aperture, { app: a.label, n: Math.max(3, Math.round(a.n / 4)) }) });
  });
  ((inp && inp.apps) || []).forEach(function(a){
    if (!a || !a.label || minuti(a.ms) < 15 || viste[a.label]) return;
    viste[a.label] = 1;
    out.push({ t: esRiempi(X.dati_voce_app, { tempo: esDurata(minuti(a.ms)), app: a.label }),
               taglio: regolaOra(a.ora, X.dati_regola_app, X.dati_regola_app_dopo, { app: a.label }) });
  });
  return out.slice(0, (cfg.taglia && cfg.taglia.maxMie) || 8);
}

/** Quanto l'ordine scelto e' vicino a quello giusto, da 0 a 100: la distanza di ogni voce dal
    suo posto, sommata, contro la distanza piu' grande possibile. */
function esRiordinaPunteggio(scelto, giusto){
  const n = giusto.length; if (!n) return 0;
  let d = 0, max = 0;
  giusto.forEach(function(v, i){ const j = scelto.indexOf(v); d += Math.abs((j < 0 ? n - 1 : j) - i); max += Math.abs((n - 1 - i) - i); });
  return max ? Math.round(100 * (1 - d / max)) : 100;
}
/** Lo scenario di oggi: lo stesso tutto il giorno, mai quello dell'ultima volta. */
function esRiordinaScegli(scenari, ultimo, seme){
  const rnd = esRng(seme);
  const ok = scenari.filter(function(s){ return s.id !== ultimo; });
  const l = ok.length ? ok : scenari;
  return l[Math.floor(rnd() * l.length)];
}

/** Quanti giorni mancano al prossimo pitch (0 = si puo' scrivere). */
function esPitchMancano(versioni, ora, giorni){
  const ultimo = (versioni || []).reduce(function(a, x){ return Math.max(a, x.at || 0); }, 0);
  if (!ultimo) return 0;
  const resta = ultimo + giorni * ES_GIORNO - ora;
  return resta <= 0 ? 0 : Math.ceil(resta / ES_GIORNO);
}
/** Quanti giorni di dati mancano al Ripasso (0 = si apre). */
function esRipassoMancano(primoAvvio, ora, minimi){
  if (!primoAvvio) return minimi;
  return Math.max(0, minimi - Math.floor((ora - primoAvvio) / ES_GIORNO));
}
/** Si possono comprare i secondi in piu'? Una volta sola, e solo con le monete che ci sono. */
function esExtraStato(giaUsato, monete, costo){ return giaUsato ? 'usato' : (monete >= costo ? 'ok' : 'poche'); }
/** Si puo' comprare il gettone? */
function esGettoneStato(gettoni, monete, costo, max){ return gettoni >= max ? 'pieno' : (monete >= costo ? 'ok' : 'poche'); }

/* ---------------------------------------------------------------------------------------
   LO STATO (fl_esercizi) — quello che il Genio e l'agente Premium rileggono
     storia : [{ id, tipo, at, quando (ISO), esito, durataMs, extra, monete, risposte[], sintesi }]
     taglia : { task, at }            l'ultima cosa rimasta
     inter  : { giorno, ids, prima }  la rotazione delle domande
     pitch  : [{ at, quando, testo, parole }]   tutte le versioni
   --------------------------------------------------------------------------------------- */
function esStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(ES_KEY) || 'null'); }catch(_){ }
  if (!s) s = {};
  s.storia = s.storia || []; s.pitch = s.pitch || []; s.inter = s.inter || { giorno: '', ids: [], prima: [] };
  return s;
}
function esSalva(s){ try{ s.storia = s.storia.slice(-400); localStorage.setItem(ES_KEY, JSON.stringify(s)); }catch(_){ } }
/** Tutto quello che l'utente ha risposto, dal piu' vecchio al piu' recente. `tipo` filtra. */
function esStoria(tipo){ return esStato().storia.filter(function(x){ return !tipo || x.tipo === tipo; }); }
function esPitchVersioni(){ return esStato().pitch; }
function esUltimaTaglia(){ return esStato().taglia || null; }

/* ---------------------------------------------------------------------------------------
   IL FILE DEI TESTI
   --------------------------------------------------------------------------------------- */
async function esCarica(){
  if (ES.cfg) return ES.cfg;
  if (!ES.caricando) ES.caricando = (async function(){
    try{ const r = await fetch('content/esercizi.json', { cache: 'no-cache' }); if (r.ok) ES.cfg = await r.json(); }catch(_){ ES.cfg = null; }
    ES.caricando = null;
    try{ if (ES.cfg && typeof sdPaint === 'function') sdPaint(); }catch(_){ }
    return ES.cfg;
  })();
  return ES.caricando;
}
function esT(sez, k, v){
  const c = ES.cfg; if (!c || !c[sez]) return '';
  const t = (c[sez].testi || c[sez])[k];
  return esRiempi(t, v);
}
function esH(x){ return (typeof esc === 'function') ? esc(x) : String(x == null ? '' : x); }
function esNome(tipo){ return (ES.cfg && ES.cfg[tipo] && ES.cfg[tipo].nome) || ''; }
function esNomeNodo(nd){ try{ if (nd && nd.arco && ES.cfg.taglia.nodi[nd.arco] && nd.es === 'taglia') return ES.cfg.taglia.nodi[nd.arco]; }catch(_){ } return esNome(nd && nd.es); }
function esIco(tipo){ return (ES.cfg && ES.cfg[tipo] && ES.cfg[tipo].ico) || ''; }
function esMonete(){ try{ return (typeof ffCoins === 'function') ? ffCoins() : 0; }catch(_){ return 0; } }
function esMoneteAggiungi(n){
  try{ if (typeof ffAddCoins === 'function') ffAddCoins(n); }catch(_){ }
  try{ if (typeof hdrContatoriApply === 'function') hdrContatoriApply(); }catch(_){ }
  const el = document.getElementById('esMon'); if (el) el.textContent = esMonete();
}

/* ---------------------------------------------------------------------------------------
   I DATI DELL'UTENTE: quello che ha detto e quello che ha fatto negli ultimi 7 giorni
   --------------------------------------------------------------------------------------- */
function esDichiarato(){
  const o = {};
  const val = function(id){ try{ return (typeof dqVal === 'function') ? dqVal(id) : ''; }catch(_){ return ''; } };
  try{ const g = (typeof gnDati === 'function') ? gnDati() : {}; o.oreN = +g.oreN || 0; o.sogno = String(g.targetTesto || g.sogno || '').replace(/^[^A-Za-zÀ-ÿ0-9]+/, '').trim(); }catch(_){ }
  o.lucida = val('e2q1'); o.tempoSogno = val('e5q1'); o.motivo = val('e1q6'); o.vecchio = val('e3q6'); o.scusa = val('e3q1');
  return o;
}
function esConScadenza(fn, ms){
  return new Promise(function(fatto){
    const t = setTimeout(function(){ fatto(null); }, ms);
    Promise.resolve().then(fn).then(function(r){ clearTimeout(t); fatto(r); }, function(){ clearTimeout(t); fatto(null); });
  });
}
async function esDati(){
  const a = esMezzanotte(Date.now()), da = a - 7 * ES_GIORNO;
  const d = { da: da, a: a, giorni: [], oreDelGiorno: null, apps: [], ff: [], dich: esDichiarato() };
  try{ d.ff = (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).filter(function(x){ return x && x.at >= da && x.at < a; }); }catch(_){ }
  const N = (typeof NATIVE !== 'undefined') ? NATIVE : null;
  if (N && N.getScreenTimeRange){
    const r = await Promise.all([
      esConScadenza(function(){ return N.getScreenTimeRange({ from: da, to: a, bucket: 'day' }); }, 2500),
      esConScadenza(function(){ return N.getScreenTimeRange({ from: da, to: a, bucket: 'hour' }); }, 2500)
    ]);
    /* un giorno oltre le 18 ore non e' un giorno: e' il registro di Android che si e' accorciato */
    if (r[0] && r[0].buckets) d.giorni = r[0].buckets.filter(function(b){ return b && b.ms > 60000 && b.ms <= 18 * 3600000; }).map(function(b){ return { t: b.start, ms: b.ms }; });
    if (r[1] && r[1].buckets){ const ore = new Array(24).fill(0); r[1].buckets.forEach(function(b){ if (b && b.ms > 0) ore[new Date(b.start).getHours()] += b.ms; }); d.oreDelGiorno = ore; }
  }
  if (N && N.getTopApps){
    const r = await esConScadenza(function(){ return N.getTopApps({ from: da, to: a, limit: 12 }); }, 2500);
    let cat = {}; try{ cat = (typeof insCats === 'function') ? insCats() : {}; }catch(_){ }
    if (r && r.apps) d.apps = r.apps.filter(function(x){ return x && !x.launcher && x.ms > 0 && x.label && x.packageName !== 'com.dreambrothers.focuslock'; })
      .sort(function(x, y){ return y.ms - x.ms; }).map(function(x){ return { label: x.label, ms: x.ms, cat: cat[x.packageName] || '' }; });
  }
  return d;
}
/* Le cose che l'utente ha scritto lui, a mente fredda: le righe non spuntate del foglio di
   oggi (START), o i passi non fatti dell'orizzonte (orizzonti.js) per settimana, mese, anno. */
/** I dati per Taglia quando il piano di oggi e' vuoto: ultimi 7 giorni, mai piu' di 2,5 secondi di attesa. */
async function esTagliaRaccogli(cfg){
  const ora = Date.now(), a = esMezzanotte(ora), da = a - 7 * ES_GIORNO;
  const inp = { dentro: [], apps: [], abitudini: [] };
  const mediana = function(v){ if (!v || !v.length) return -1; const b = v.slice().sort(function(x, y){ return x - y; }); return b[Math.floor(b.length / 2)]; };
  /* dentro DreamMap (tempo-app.js): diviso per i giorni in cui c'e' davvero un registro */
  try{
    if (typeof taRiassunto === 'function' && typeof taArea === 'function'){
      const r = taRiassunto(da, ora);
      const giorni = {}; r.pezzi.forEach(function(p){ giorni[esGiornoK(p.s)] = 1; });
      const n = Math.max(1, Object.keys(giorni).length);
      r.perArea.forEach(function(x){
        const ar = taArea(x.id);
        if (ar.cosa) inp.dentro.push({ nel: ar.nel, cosa: ar.cosa, ms: x.ms / n, ora: mediana(x.ore) });
      });
    }
  }catch(_){ }
  const N = (typeof NATIVE !== 'undefined') ? NATIVE : null;
  const fuori = function(pk, lb){ return /launcher|\.home$|systemui|inputmethod|keyboard|honeyboard|packageinstaller|permissioncontroller|com\.dreambrothers\.focuslock/i.test(String(pk || '')) || /launcher|\bhome$|one ui/i.test(String(lb || '')); };
  /* le app che distraggono: quelle giudicate distraenti nel Report, o nelle categorie che lo sono quasi sempre */
  if (N && N.getTopApps){
    const r = await esConScadenza(function(){ return N.getTopApps({ from: da, to: a, limit: 15 }); }, 2500);
    let cat = {}; try{ cat = (typeof insCats === 'function') ? insCats() : {}; }catch(_){ }
    const distr = ['social', 'video', 'games', 'news', 'shop', 'bet', 'dating', 'adult'];
    if (r && r.apps) inp.apps = r.apps.filter(function(x){
      if (!x || x.launcher || x.self || !x.label || !(x.ms > 0) || fuori(x.packageName, x.label)) return false;
      if (cat[x.packageName]) return cat[x.packageName] === 'distr';
      let g = ''; try{ g = (typeof rpCatDi === 'function') ? rpCatDi(x.packageName) : ''; }catch(_){ }
      return distr.indexOf(g) >= 0;
    }).sort(function(x, y){ return y.ms - x.ms; }).slice(0, 3).map(function(x){ return { label: x.label, ms: x.ms / 7, ora: -1 }; });
  }
  /* le abitudini: ieri, la stessa app presa in mano tante volte */
  try{
    if (typeof tlRiassuntoDi === 'function'){
      const t = await esConScadenza(function(){ return tlRiassuntoDi(1); }, 2500);
      if (t && t.perApp){
        inp.abitudini = t.perApp.filter(function(x){ return x && x.n >= 15 && !fuori(x.p, x.l); })
          .sort(function(x, y){ return y.n - x.n; }).slice(0, 2).map(function(x){ return { label: x.l || x.p, n: x.n }; });
      }
    }
  }catch(_){ }
  return esTagliaDaDati(inp, cfg);
}

/* 0.9.311, Andrea: la fonte del Taglia e' la nota "💡 Idee e note" (mappa-note.js), dove finiscono le note veloci: qui si tagliano
   le idee superflue. Taglia le abitudini resta sui dati del telefono; settimana, mese e anno restano sui passi che
   l'utente ha scritto per quel periodo, e passano alla nota se non ne ha scritti abbastanza. */
function esIdeeNota(arco, mie, cfg){
  if (arco === 'abitudini' || typeof mnIdeePerTaglia !== 'function') return null;
  const T = cfg.taglia;
  if (arco !== 'oggi' && (mie || []).filter(function(x){ return String(x || '').trim(); }).length >= T.minMie) return null;
  const idee = mnIdeePerTaglia(T.maxMie);
  return idee.length >= T.minMie ? idee : null;
}
function esCoseMie(arco){
  if (arco === 'abitudini') return [];
  try{
    if (arco === 'oggi'){
      const day = (typeof stDayKey === 'function') ? stDayKey('today') : esGiornoK(Date.now());
      const righe = (typeof stRigheDi === 'function') ? stRigheDi(day) : [];
      return righe.filter(function(r){ try{ return !(typeof stIsDone === 'function' && stIsDone(r, day)); }catch(_){ return true; } })
        .filter(function(r){ return r.indexOf('☑') !== 0; })
        .map(function(r){ return r.replace(/^[☐☑•\-]\s*/, '').replace(/^\d+[.)]\s+/, '').trim(); }).filter(Boolean);
    }
    if (typeof ozAnello === 'function') return (ozAnello(arco).passi || []).filter(function(x){ return x && !x.fatto && x.t; }).map(function(x){ return x.t; });
  }catch(_){ }
  return [];
}
function esPrimoAvvio(){
  let t = 0;
  try{ t = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0; }catch(_){ }
  try{ const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; if (h.length && h[0].at && (!t || h[0].at < t)) t = h[0].at; }catch(_){ }
  return t;
}
/** Quanti giorni mancano prima che l'esercizio si apra (0 = aperto). */
function esMancano(tipo){
  if (!ES.cfg) return 0;
  if (tipo === 'ripasso') return esRipassoMancano(esPrimoAvvio(), Date.now(), ES.cfg.ripasso.giorniMinimi);
  if (tipo === 'pitch') return esPitchMancano(esPitchVersioni(), Date.now(), ES.cfg.pitch.giorni);
  return 0;
}
function esChiusoTxt(tipo){
  const n = esMancano(tipo); if (!n) return '';
  return n === 1 ? esT(tipo, 'chiuso_uno') : esT(tipo, 'chiuso', { n: n });
}

/* ---------------------------------------------------------------------------------------
   IL MOTORE: apri, parti, scade, compra tempo, perso, riuscito
   --------------------------------------------------------------------------------------- */
async function esApri(nd){
  if (ES.aprendo) return; ES.aprendo = true;
  try{
    const cfg = await esCarica();
    if (!cfg) return;
    if (!cfg[nd.es]){ toast(esT('comune', 'non_pronto')); return; }
    const chiuso = esChiusoTxt(nd.es);
    if (chiuso){ toast(chiuso); return; }
    const c = cfg[nd.es];
    const r = { nd: nd, tipo: nd.es, tok: ++ES.tok, fase: 'intro', sec: c.secondi, extra: false, risposte: [], salvato: false, voci: [] };
    if (nd.es === 'taglia'){
      r.arco = nd.arco || 'oggi';
      const mie = esCoseMie(r.arco);
      let dati = null;
      /* 0.9.253: «Taglia le abitudini» parte sempre dai dati veri del telefono (app, aperture, tempo dentro all'app) */
      if (r.arco === 'abitudini'){ try{ dati = await esTagliaRaccogli(cfg); }catch(_){ dati = null; } }
      else if (r.arco === 'oggi' && !(mie || []).filter(function(x){ return String(x || '').trim(); }).length){
        try{ dati = await esTagliaRaccogli(cfg); }catch(_){ dati = null; }
      }
      const idee = esIdeeNota(r.arco, mie, cfg);
      if (idee){ r.modo = 'idee'; r.voci = idee.map(function(t){ return { t: t.slice(0, 90), intera: t, ess: false }; }); r.essenziale = ''; r.perche = ''; }
      else {
        const v = esTagliaVoci(r.arco, mie, cfg, esRng(esSeme(nd.id + ':' + Date.now())), dati);
        r.modo = v.modo; r.voci = v.voci; r.essenziale = v.essenziale; r.perche = v.perche;
      }
    }
    if (nd.es === 'riordina') r.scenario = esRiordinaOggi();
    if (nd.es === 'ripasso' || nd.es === 'bivio'){
      const d = await esDati();
      const rnd = esRng(esSeme(nd.id + ':' + Date.now()));
      r.lista = nd.es === 'ripasso' ? esRipassoDomande(d, cfg, rnd) : esBivioScenari(d, cfg, rnd);
    }
    if (nd.es === 'interrogatorio') r.lista = esInterOggi();
    ES.run = r;
    goId('s-esercizio');
    esGuscio();
    esIntro();
  } finally { ES.aprendo = false; }
}
/* lo scenario di Riordina: lo stesso tutto il giorno, il giorno dopo un altro */
function esRiordinaOggi(){
  const c = ES.cfg.riordina, s = esStato(), oggi = esGiornoK(Date.now());
  s.rio = s.rio || { giorno: '', id: '', prima: '' };
  if (s.rio.giorno !== oggi || !c.scenari.some(function(x){ return x.id === s.rio.id; })){
    const sc = esRiordinaScegli(c.scenari, s.rio.id, esSeme('rio:' + oggi));
    s.rio = { giorno: oggi, id: sc.id, prima: s.rio.id }; esSalva(s);
  }
  const sc = c.scenari.filter(function(x){ return x.id === s.rio.id; })[0];
  return { id: sc.id, t: sc.t, ordine: sc.ordine.slice(), perche: sc.perche, mostra: esMescola(sc.ordine, esRng(esSeme('rio-ordine:' + oggi))) };
}
/* le domande di oggi: lo stesso giorno restano quelle, il giorno dopo cambiano */
function esInterOggi(){
  const c = ES.cfg.interrogatorio, s = esStato(), oggi = esGiornoK(Date.now());
  if (s.inter.giorno !== oggi || !(s.inter.ids || []).length){
    const prima = s.inter.ids || [];
    const scelte = esInterScegli(c.pool, prima, c.domande, esSeme('inter:' + oggi));
    s.inter = { giorno: oggi, ids: scelte.map(function(q){ return q.id; }), prima: prima };
    esSalva(s);
  }
  return s.inter.ids.map(function(id){ return c.pool.filter(function(q){ return q.id === id; })[0]; }).filter(Boolean);
}

function esGuscio(){
  const r = ES.run, h = document.getElementById('esBox'); if (!h || !r) return;
  esFermo(false);
  h.innerHTML = '<div class="es-top"><button type="button" class="es-x" onclick="esX()" aria-label="' + esH(esT('comune', 'lascia_esco')) + '">✕</button>'
    + '<div class="es-barra"><i id="esBar" style="width:100%"></i></div><b class="es-tempo" id="esTempo">' + esTempoTxt(r.sec * 1000) + '</b></div>'
    + '<div class="es-sotto"><span class="es-nome">' + esIco(r.tipo) + ' ' + esH(esNome(r.tipo)) + '</span><span class="es-monete">🪙 <b id="esMon">' + esMonete() + '</b></span></div>'
    + '<div class="es-corpo" id="esCorpo"></div><div class="es-velo" id="esVelo" hidden></div>';
}
function esFermo(si){ const b = document.getElementById('esBox'); if (b) b.classList.toggle('finito', !!si); }
/* 0.9.347: un paragrafo lungo diventa una frase per riga */
function esFrasi(html){ const p = String(html || '').split(/(?<=[.!?])\s+(?=[A-ZÀ-Ý"“])/); return p.map(function(x, i){ return '<p class="es-p' + (i === p.length - 1 ? ' ultimo' : '') + '">' + x + '</p>'; }).join(''); }
function esCorpo(html){ const c = document.getElementById('esCorpo'); if (c){ c.innerHTML = html; c.scrollTop = 0; } }
function esVelo(html){ const v = document.getElementById('esVelo'); if (!v) return; if (html == null){ v.hidden = true; v.innerHTML = ''; } else { v.innerHTML = '<div class="es-velo-in">' + html + '</div>'; v.hidden = false; } }
function esOrologio(rem){
  const r = ES.run; if (!r) return;
  const b = document.getElementById('esBar'), t = document.getElementById('esTempo');
  const tot = (r.totMs || r.sec * 1000);
  if (b){ b.style.width = Math.max(0, Math.min(100, rem / tot * 100)) + '%'; b.classList.toggle('poco', rem <= 10000); }
  if (t){ t.textContent = esTempoTxt(rem); t.classList.toggle('poco', rem <= 10000); }
}
function esVibra(p){ try{ flVibra(p); }catch(_){ } }

/* ---------- prima del via ---------- */
function esIntro(){
  const r = ES.run, c = ES.cfg[r.tipo], T = function(k, v){ return esH(esT(r.tipo, k, v)); };
  const premio = ES.cfg.comune.premi[r.tipo] || 0;
  const coda = '<p class="es-regola">' + esH(esT('comune', 'regola')) + '</p><p class="es-premio">🪙 ' + esH(esT('comune', 'premio', { n: premio })) + '</p>';
  const sogno = esDichiarato().sogno;
  if (r.tipo === 'taglia'){
    const A = c.archi[r.arco] || c.archi.oggi;
    esCorpo('<div class="es-ico-grande">' + esIco('taglia') + '</div><h2 class="es-h">' + esH(r.modo === 'dati' ? esT('taglia', 'dati_titolo') : r.modo === 'idee' ? esT('taglia', 'idee_titolo') : A.titolo) + '</h2>' + (sogno ? '<p class="es-sogno">' + T('intro_sogno', { sogno: sogno }) + '</p>' : '')
      + esFrasi((r.modo === 'idee' ? T('intro_idee', { n: r.voci.length, sec: c.secondi }) : r.modo === 'mie' ? T('intro_mie', { fonte: A.fonte, n: r.voci.length, sec: c.secondi }) : r.modo === 'dati' ? T('intro_dati', { n: r.voci.length, sec: c.secondi }) : T('intro_quiz', { n: r.voci.length, sec: c.secondi }))) + coda
      + '<button type="button" class="cta es-cta" onclick="esParti()">' + esH(esT('comune', 'inizia', { n: c.secondi })) + '</button>');
    return;
  }
  if (r.tipo === 'riordina'){
    esCorpo('<div class="es-ico-grande">' + esIco('riordina') + '</div><h2 class="es-h">' + T('intro_titolo') + '</h2>'
      + '<p class="es-p">' + T('intro_testo', { sec: c.secondi }) + '</p>' + coda
      + '<button type="button" class="cta es-cta" onclick="esParti()">' + esH(esT('comune', 'inizia', { n: c.secondi })) + '</button>');
    return;
  }
  const n = r.lista ? r.lista.length : 0;
  const per = c.secondiPerDomanda || c.secondiPerScenario || c.secondi;
  esCorpo('<div class="es-ico-grande">' + esIco(r.tipo) + '</div><h2 class="es-h">' + T('intro_titolo', { n: n, sec: per }) + '</h2>'
    + (r.tipo === 'pitch' && sogno ? '<p class="es-sogno">' + T('intro_sogno', { sogno: sogno }) + '</p>' : '')
    + '<p class="es-p">' + T('intro_testo', { n: n, sec: per }) + '</p>' + coda
    + '<button type="button" class="cta es-cta" onclick="esParti()">' + esH(esT('comune', 'inizia', { n: c.secondi })) + '</button>');
}

/* ---------- il via ---------- */
function esParti(){
  const r = ES.run; if (!r || r.fase !== 'intro') return;
  const c = ES.cfg[r.tipo];
  r.fase = 'corsa'; r.t0 = Date.now(); r.fineAt = r.t0 + r.sec * 1000; r.totMs = r.sec * 1000; r.i = 0;
  esVibra(20);
  if (r.tipo === 'taglia'){ r.risposte.push({ at: Date.now(), azione: 'opzioni', modo: r.modo, arco: r.arco, voci: r.voci.map(function(v){ return v.t; }) }); esTagliaCorsa(); }
  else if (r.tipo === 'riordina'){ r.scelto = []; esRioMostra(); }
  else if (r.tipo === 'interrogatorio') esInterMostra();
  else if (r.tipo === 'ripasso') esRipMostra();
  else if (r.tipo === 'bivio') esBivMostra();
  else if (r.tipo === 'pitch') esPitchCorsa();
  esOrologio(r.fineAt - Date.now());
  esAvviaTick();
}
function esAvviaTick(){ const r = ES.run; if (!r) return; clearInterval(r.tick); r.tick = setInterval(esTick, 100); }
function esTick(){
  const r = ES.run; if (!r || r.fase !== 'corsa') return;
  const ora = Date.now(), rem = r.fineAt - ora;
  esOrologio(rem);
  if (rem <= 0){ esScaduto(); return; }
  if (r.voce && !r.voce.chiusa && r.voce.fineAt && ora >= r.voce.fineAt) esVoceScaduta();
}
/* una cosa da fare fra un attimo, ma solo se l'esercizio e' ancora quello e sta ancora correndo */
function esDopo(ms, fn){ const tok = ES.run && ES.run.tok; setTimeout(function(){ const r = ES.run; if (r && r.tok === tok && r.fase === 'corsa') fn(); }, ms); }

/* ---------- il tempo e' finito ---------- */
function esScaduto(){
  const r = ES.run; if (!r) return;
  clearInterval(r.tick); r.fase = 'scaduto'; esOrologio(0);
  /* il pitch a tempo scaduto si consegna da solo, se c'e' abbastanza da consegnare */
  if (r.tipo === 'pitch'){ esPitchLeggi(); const ta = document.getElementById('esPitch'); if (ta){ ta.disabled = true; ta.blur(); } if (esParole(r.testo) >= ES.cfg.pitch.minParole){ esRiuscito(); return; } }
  esVibra([40, 60, 40]);
  const X = ES.cfg.comune.extra, stato = esExtraStato(r.extra, esMonete(), X.costo);
  let h = '<h3>' + esH(esT('comune', 'scaduto_titolo')) + '</h3><p>' + esH(r.tipo === 'pitch' ? esT('pitch', 'corto', { min: ES.cfg.pitch.minParole, n: esParole(r.testo) }) : esT('comune', 'scaduto_testo', { n: r.sec })) + '</p>';
  if (stato === 'ok') h += '<button type="button" class="cta es-cta" onclick="esCompraTempo()">🪙 ' + esH(esT('comune', 'extra_btn', { sec: X.secondi, costo: X.costo })) + '</button>';
  else h += '<p class="es-nota">' + esH(stato === 'usato' ? esT('comune', 'extra_usato') : esT('comune', 'extra_poche', { sec: X.secondi, costo: X.costo, hai: esMonete() })) + '</p>';
  h += '<button type="button" class="es-sec" onclick="esRicomincia(\'tempo\')">' + esH(esT('comune', 'ricomincia')) + '</button>'
    + '<button type="button" class="es-link" onclick="esEsci(\'tempo\')">' + esH(esT('comune', 'mappa')) + '</button>';
  esVelo(h);
}
function esCompraTempo(){
  const r = ES.run; if (!r || r.fase !== 'scaduto') return;
  const X = ES.cfg.comune.extra;
  if (esExtraStato(r.extra, esMonete(), X.costo) !== 'ok') return;
  esMoneteAggiungi(-X.costo);
  r.extra = true; r.fase = 'corsa'; r.totMs = X.secondi * 1000; r.fineAt = Date.now() + r.totMs;
  esVelo(null);
  if (r.tipo === 'pitch'){ const ta = document.getElementById('esPitch'); if (ta){ ta.disabled = false; ta.focus(); } }
  if (r.voce){
    if (r.voce.chiusa){ if (r.tipo === 'interrogatorio') esInterAvanti(); else if (r.tipo === 'ripasso') esRipAvanti(); else if (r.tipo === 'bivio') esBivAvanti(); }
    else if (r.voce.fineAt){ r.voce.t0 = Date.now(); r.voce.fineAt = Date.now() + r.voce.per * 1000; const q = document.getElementById('esQBar'); if (q){ q.style.animation = 'none'; void q.offsetWidth; q.style.animation = ''; q.style.animationDuration = r.voce.per + 's'; } }
  }
  esOrologio(r.totMs);
  esAvviaTick();
}

/* ---------- lasciare ---------- */
function esX(){
  const r = ES.run;
  if (!r || r.fase === 'intro' || r.fase === 'esito'){ esTornaMappa(); return; }
  if (r.fase === 'scaduto') return;
  esVelo('<h3>' + esH(esT('comune', 'lascia_titolo')) + '</h3><p>' + esH(esT('comune', 'lascia_testo')) + '</p>'
    + '<button type="button" class="cta es-cta" onclick="esVelo(null)">' + esH(esT('comune', 'lascia_resto')) + '</button>'
    + '<button type="button" class="es-link" onclick="esPerso(\'lasciato\')">' + esH(esT('comune', 'lascia_esco')) + '</button>');
}
function esIndietro(){ const r = ES.run; if (r && (r.fase === 'corsa' || r.fase === 'scaduto')){ esX(); return 's-esercizio'; } ES.run = null; try{ switchTab('mappa'); }catch(_){ } return 's-home'; }
function esTornaMappa(){
  if (ES.run) clearInterval(ES.run.tick); ES.run = null;
  /* 0.9.347: Taglia fatto nella sera riporta al passo di domani, non alla Mappa */
  const dopo = ES.dopo; ES.dopo = null;
  if (typeof dopo === 'function'){ goId('s-home'); setTimeout(function(){ try{ dopo(); }catch(_){ } }, 350); return; }
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
}

/* ---------- quello che si scrive nello storico ---------- */
function esRegistra(esito, monete, sintesi){
  const r = ES.run; if (!r || r.salvato) return;
  r.salvato = true;
  const s = esStato();
  s.storia.push({ id: r.nd.id, tipo: r.tipo, at: r.t0 || Date.now(), quando: new Date(r.t0 || Date.now()).toISOString(), esito: esito, durataMs: r.t0 ? Date.now() - r.t0 : 0, extra: !!r.extra, monete: monete || 0, risposte: r.risposte, sintesi: sintesi || null });
  if (esito === 'riuscito' && r.tipo === 'taglia' && sintesi && r.modo === 'mie' && r.arco === 'oggi') s.taglia = { task: sintesi.rimasta, at: Date.now() };
  if (esito === 'riuscito' && r.tipo === 'taglia' && sintesi && r.modo === 'dati') s.tagliDati = { regole: sintesi.regole, concessa: sintesi.rimasta, at: Date.now() };
  if (esito === 'riuscito' && r.tipo === 'pitch') s.pitch.push({ at: Date.now(), quando: new Date().toISOString(), testo: r.testo, parole: esParole(r.testo) });
  esSalva(s);
}

/* ---------- perso: uscito dall'app, lasciato, tempo finito ---------- */
function esPerso(esito){
  const r = ES.run; if (!r || r.fase === 'esito' || r.fase === 'intro') return;
  clearInterval(r.tick);
  if (r.tipo === 'pitch') esPitchLeggi();
  esRegistra(esito, 0, null);
  r.fase = 'esito';
  esVelo(null); esFermo(true);
  esCorpo('<div class="es-esito ko"><div class="es-esito-ico">✕</div><h2 class="es-h">' + esH(esT('comune', 'uscito_titolo')) + '</h2>'
    + '<p class="es-p">' + esH(esito === 'uscito' ? esT('comune', 'uscito_testo') : esito === 'lasciato' ? esT('comune', 'lasciato_testo') : esT('comune', 'scaduto_testo', { n: r.sec })) + '</p>'
    + '<button type="button" class="cta es-cta" onclick="esRicomincia()">' + esH(esT('comune', 'ricomincia')) + '</button>'
    + '<button type="button" class="es-link" onclick="esTornaMappa()">' + esH(esT('comune', 'mappa')) + '</button></div>');
}
function esRicomincia(esito){ const r = ES.run; if (!r) return; clearInterval(r.tick); if (esito) esRegistra(esito, 0, null); esApri(r.nd); }
function esEsci(esito){ const r = ES.run; if (r && esito){ if (r.tipo === 'pitch') esPitchLeggi(); esRegistra(esito, 0, null); } esTornaMappa(); }

/* ---------- riuscito ---------- */
function esRiuscito(){
  const r = ES.run; if (!r || r.fase === 'esito') return;
  clearInterval(r.tick); r.fase = 'esito'; esVelo(null); esFermo(true);
  const C = ES.cfg;
  let premio = C.comune.premi[r.tipo] || 0;
  let titolo = '', testo = '', mezzo = '', sintesi = null;
  if (r.tipo === 'taglia'){
    const rimasta = r.voci.filter(function(v){ return !v.via; })[0].t;
    r.risposte.push({ at: Date.now(), azione: 'rimasta', voce: rimasta });
    const A = C.taglia.archi[r.arco] || C.taglia.archi.oggi;
    mezzo = '<div class="es-rimasta">"' + esH(rimasta) + '"</div>';
    if (r.modo === 'dati'){
      /* quella rimasta e' quella che si concede; le tagliate diventano regole concrete */
      const regole = r.voci.filter(function(v){ return v.via; }).map(function(v){ return v.taglio || v.t; });
      sintesi = { rimasta: rimasta, modo: 'dati', arco: r.arco, regole: regole, opzioni: r.voci.length };
      titolo = esT('taglia', 'riuscito_dati_titolo', { n: regole.length });
      mezzo = '<div class="es-regole">' + regole.map(function(t){ return '<div>✂️ ' + esH(t) + '</div>'; }).join('') + '</div>';
      testo = esT('taglia', 'riuscito_dati', { t: rimasta });
    } else if (r.modo === 'idee'){
      /* solo a esercizio riuscito: le tagliate escono dalla nota e restano nel cestino delle note, quella rimasta resta nella nota */
      const via = r.voci.filter(function(v){ return v.via; }).map(function(v){ return v.intera || v.t; });
      try{ if (typeof mnIdeeTaglia === 'function') mnIdeeTaglia(via); }catch(_){ }
      sintesi = { rimasta: rimasta, modo: 'idee', arco: r.arco, opzioni: r.voci.length, tagliate: via.length };
      titolo = esT('taglia', 'riuscito_titolo');
      testo = esT('taglia', 'riuscito_idee', { n: via.length });
    } else if (r.modo === 'quiz'){
      const giusta = rimasta === r.essenziale;
      try{ if (typeof muJingle === 'function') muJingle(giusta ? 'giusta' : 'sbagliata'); }catch(_){ }
      if (!giusta) premio = Math.ceil(premio / 2);
      sintesi = { rimasta: rimasta, modo: 'quiz', arco: r.arco, giusta: giusta, essenziale: r.essenziale, opzioni: r.voci.length };
      titolo = esT('taglia', giusta ? 'giusta_titolo' : 'sbagliata_titolo');
      if (!giusta) mezzo += '<p class="es-era">' + esH(esT('taglia', 'era', { t: r.essenziale })) + '</p>';
      testo = r.perche;
    } else {
      sintesi = { rimasta: rimasta, modo: 'mie', arco: r.arco, opzioni: r.voci.length };
      titolo = esT('taglia', 'riuscito_titolo');
      if (r.arco === 'oggi'){
        /* la cosa rimasta e' il compito della prossima sessione: la sessione la fa partire l'utente */
        try{ if (typeof ffPref === 'function'){ ffPref().intent = rimasta.slice(0, 250); ffSavePref(); } }catch(_){ }
        testo = esT('taglia', 'riuscito_ff');
      } else testo = esT('taglia', 'riuscito_mie', { arco: A.eti });
    }
  } else if (r.tipo === 'riordina'){
    const sc = r.scenario, pct = esRiordinaPunteggio(r.scelto, sc.ordine);
    premio = Math.max(3, Math.round(premio * pct / 100));
    sintesi = { scenario: sc.id, pct: pct, scelto: r.scelto.slice(), giusto: sc.ordine.slice() };
    titolo = esT('riordina', 'riuscito_titolo', { pct: pct }); testo = sc.perche;
    mezzo = '<small class="es-conf-t">' + esH(esT('riordina', 'riuscito_testo')) + '</small><div class="es-rio-fine">' + sc.ordine.map(function(v, i){ const j = r.scelto.indexOf(v); return '<div class="' + (j === i ? 'ok' : '') + '"><b>' + (i + 1) + '</b><span>' + esH(v) + '</span><i>' + (j + 1) + '</i></div>'; }).join('') + '</div>';
  } else if (r.tipo === 'interrogatorio'){
    const nulla = esT('comune', 'nessuna_risposta');
    const date = r.risposte.filter(function(x){ return x.risposta !== nulla; }).length;
    sintesi = { risposte: date, domande: r.lista.length };
    titolo = esT('interrogatorio', 'riuscito_titolo', { n: date, tot: r.lista.length }); testo = esT('interrogatorio', 'riuscito_testo');
  } else if (r.tipo === 'ripasso'){
    const giuste = r.risposte.filter(function(x){ return x.corretta; }).length;
    sintesi = { giuste: giuste, domande: r.lista.length };
    titolo = esT('ripasso', 'riuscito_titolo', { n: giuste, tot: r.lista.length }); testo = esT('ripasso', 'riuscito_testo');
  } else if (r.tipo === 'bivio'){
    const nuovo = r.risposte.filter(function(x){ return x.nuovo === true; }).length, vecchio = r.risposte.filter(function(x){ return x.nuovo === false; }).length;
    let punto = esBivioPunto(nuovo, vecchio), dato = false;
    try{
      if (punto === 'nuovo' && typeof mgFocusPoint === 'function') dato = mgFocusPoint(esT('bivio', 'motivo_nuovo', { n: nuovo, tot: r.lista.length }), true);
      if (punto === 'vecchio' && typeof mgOldPoint === 'function') dato = mgOldPoint(esT('bivio', 'motivo_vecchio', { n: vecchio, tot: r.lista.length }));
    }catch(_){ }
    if (!dato) punto = '';
    sintesi = { nuovo: nuovo, vecchio: vecchio, scenari: r.lista.length, punto: punto };
    titolo = esT('bivio', 'riuscito_titolo', { n: nuovo, tot: r.lista.length }); testo = esT('bivio', punto === 'nuovo' ? 'punto_nuovo' : punto === 'vecchio' ? 'punto_vecchio' : 'punto_nessuno');
  } else if (r.tipo === 'pitch'){
    const prima = esPitchVersioni();
    const n = prima.length + 1;
    sintesi = { versione: n, parole: esParole(r.testo) };
    r.risposte.push({ at: Date.now(), testo: r.testo });
    titolo = esT('pitch', 'riuscito_titolo', { n: n }); testo = esT('pitch', 'riuscito_testo');
    if (n >= C.pitch.confrontoDa) mezzo = '<small class="es-conf-t">' + esH(esT('pitch', 'confronto_titolo')) + '</small><div class="es-conf"><div><b>' + esH(esT('pitch', 'confronto_prima', { data: esDataBreve(prima[0].at) })) + '</b><p>' + esH(prima[0].testo) + '</p></div><div><b>' + esH(esT('pitch', 'confronto_oggi', { data: esDataBreve(Date.now()) })) + '</b><p>' + esH(r.testo) + '</p></div></div>';
  }
  esMoneteAggiungi(premio);
  esRegistra('riuscito', premio, sintesi);
  /* il nodo della mappa e' fatto, e la giornata conta per la serie */
  try{ const s = sdStato(); s.fatti[r.nd.id] = Date.now(); sdSalva(s); sdAggiorna(false); }catch(_){ }   /* l'esperienza del nodo sale subito; la festa la apre «Continua» */
  try{ const sn = snStato(); snGiorno(sn).e = Date.now(); snSalva(sn); snTick(); }catch(_){ }
  esVibra([20, 30, 60]);
  try{ if (typeof gnAu !== 'undefined') gnAu.punto(); }catch(_){ }
  esCorpo('<div class="es-esito ok"><div class="es-esito-ico">✓</div><h2 class="es-h">' + esH(titolo) + '</h2>' + mezzo
    + '<p class="es-p">' + esH(testo) + '</p><span class="es-chip">🪙 ' + esH(esT('comune', 'premio_riga', { n: premio })) + '</span>'
    + '<button type="button" class="cta es-cta" onclick="esContinua()">' + esH(esT('comune', 'riuscito_btn')) + '</button></div>');
}
function esContinua(){
  const r = ES.run; ES.run = null;
  try{ switchTab('mappa'); }catch(_){ }
  /* una ripetizione (0.9.202): esperienza ridotta, nodo d'oro */
  try{ if (r && r.nd && typeof SD !== 'undefined' && SD.ripeti && SD.ripeti.id === r.nd.id){ if (sdRipetiFine(r.nd.id, esDettaglio(r.nd.id))){ sdPaint(); return; } } }catch(_){ }
  /* la fine tappa della mappa, con i riquadri dell'esercizio: esperienza, monete, tempo */
  try{ if (r && r.nd){ sdFineApri(r.nd, esDettaglio(r.nd.id)); sdPaint(); return; } }catch(_){ }
  goId('s-home');
}
/** Quello che la schermata di fine tappa della mappa scrive nei suoi riquadri. */
function esDettaglio(id){
  const x = esStato().storia.filter(function(e){ return e.id === id && e.esito === 'riuscito'; }).pop();
  if (!x || !ES.cfg) return null;
  return { es: x.tipo, monete: x.monete, tempo: esTempoTxt(x.durataMs), sec: Math.round((x.durataMs || 0) / 1000), titolo: esT('comune', 'fine_titolo'), sotto: esT(x.tipo, 'fine_sotto'), boxMonete: esT('comune', 'fine_box_monete'), boxTempo: esT('comune', 'fine_box_tempo') };
}

/* ---------------------------------------------------------------------------------------
   1. TAGLIA
   --------------------------------------------------------------------------------------- */
/* 0.9.258, Andrea: MAI piu' di cinque cose davanti. Il 20% del 20% di Gary Keller: si taglia fra
   cinque finche' ne resta una, poi quella entra nel giro dopo con altre quattro, finche' le cose
   finiscono. Alla fine ne resta una sola. */
const ES_TRANCHE = 5;
function esTagliaGioco(r){
  const vive = r.voci.map(function(v, i){ return i; }).filter(function(i){ return !r.voci[i].via; });
  r.visti = r.visti || [];
  const inGioco = r.gioco ? r.gioco.filter(function(i){ return !r.voci[i].via; }) : [];
  if (!r.gioco || inGioco.length <= 1){
    const nuovi = vive.filter(function(i){ return r.visti.indexOf(i) < 0 && inGioco.indexOf(i) < 0; }).slice(0, ES_TRANCHE - inGioco.length);
    if (!nuovi.length) return null;
    r.gioco = inGioco.concat(nuovi);
    nuovi.forEach(function(i){ r.visti.push(i); });
    r.tranche = (r.tranche || 0) + 1;
  }
  return r.gioco.filter(function(i){ return !r.voci[i].via; });
}
function esTagliaCorsa(){
  const r = ES.run;
  const gioco = esTagliaGioco(r);
  if (!gioco){ esRiuscito(); return; }
  const restano = r.voci.filter(function(v){ return !v.via; }).length;
  const fuori = restano - gioco.length;
  esCorpo('<h3 class="es-h3">' + esH(esT('taglia', 'corsa_titolo')) + '</h3><small class="es-conta">' + esH(esT('taglia', 'restano', { n: restano })) + (fuori > 0 ? ' · ' + fuori + (fuori === 1 ? ' altra aspetta il giro dopo' : ' altre aspettano il giro dopo') : '') + '</small>'
    + gioco.map(function(i){ const v = r.voci[i]; return '<button type="button" class="es-voce" onclick="esTagliaVia(' + i + ')"><span>' + esH(v.t) + '</span><i>✂️ ' + esH(esT('taglia', 'taglia_btn')) + '</i></button>'; }).join(''));
}
function esTagliaVia(i){
  const r = ES.run; if (!r || r.fase !== 'corsa' || !r.voci[i] || r.voci[i].via) return;
  if (!r.gioco || r.gioco.indexOf(i) < 0) return;
  if (r.voci.filter(function(v){ return !v.via; }).length <= 1) return;
  const inGioco = r.gioco.filter(function(k){ return !r.voci[k].via; });
  if (inGioco.length <= 1) return;
  r.voci[i].via = Date.now();
  r.risposte.push({ at: Date.now(), azione: 'tagliata', voce: r.voci[i].t });
  esVibra(14);
  if (r.voci.filter(function(v){ return !v.via; }).length === 1){ esRiuscito(); return; }
  esTagliaCorsa();
}

/** La chiama ffOpen(), prima che il foglio di START riscriva il compito: finche' la sessione
    dopo Taglia non e' stata fatta (e finche' e' ancora oggi), il compito gia' scritto in Full
    Focus e' la cosa rimasta. La sessione non parte da sola: la fa partire l'utente. */
function esTagliaPerFF(){
  const s = esStato(), tg = s.taglia; if (!tg || !tg.task || tg.chiusa) return;
  const chiudi = function(){ tg.chiusa = true; esSalva(s); };
  if (esGiornoK(tg.at) !== esGiornoK(Date.now())){ chiudi(); return; }
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  if (h.some(function(x){ return x && (x.start || x.at) >= tg.at; })){ chiudi(); return; }
  /* chi ha appena scelto un altro compito (una card, una missione) ha scelto dopo: vince lui */
  try{ if (typeof ST_FF_SALTA !== 'undefined' && ST_FF_SALTA) return; }catch(_){ }
  const p = ffPref();
  let foglio = ''; try{ foglio = (typeof stTask === 'function') ? stTask() : ''; }catch(_){ }
  /* se nel frattempo l'ha riscritto lui a mano, resta quello che ha scritto lui */
  if (tg.messa && p.intent && p.intent !== tg.task && p.intent !== foglio){ chiudi(); return; }
  p.intent = tg.task; tg.messa = true; esSalva(s); ffSavePref();
  if (typeof stSaltaSync === 'function') stSaltaSync();
}

/* ---------------------------------------------------------------------------------------
   RIORDINA — si toccano le cinque cose in ordine; l'ultima si puo' annullare
   --------------------------------------------------------------------------------------- */
function esRioMostra(){
  const r = ES.run, sc = r.scenario;
  const prossimo = r.scelto.length + 1;
  esCorpo('<h3 class="es-h3">' + esH(sc.t) + '</h3><small class="es-conta">' + esH(esT('riordina', 'conta', { i: Math.min(prossimo, sc.ordine.length) })) + '</small>'
    + '<div class="es-rio">' + sc.mostra.map(function(v, i){ const j = r.scelto.indexOf(v); return '<button type="button" class="' + (j >= 0 ? 'preso' : '') + '" onclick="esRioTocca(' + i + ')"><b>' + (j >= 0 ? (j + 1) : '') + '</b><span>' + esH(v) + '</span></button>'; }).join('') + '</div>'
    + (r.scelto.length ? '<button type="button" class="es-link" onclick="esRioAnnulla()">' + esH(esT('riordina', 'annulla')) + '</button>' : ''));
}
function esRioTocca(i){
  const r = ES.run; if (!r || r.fase !== 'corsa') return;
  const v = r.scenario.mostra[i]; if (r.scelto.indexOf(v) >= 0) return;
  r.scelto.push(v); r.risposte.push({ at: Date.now(), azione: 'posto', voce: v, posto: r.scelto.length });
  esVibra(12);
  if (r.scelto.length === r.scenario.ordine.length){ esRioMostra(); esDopo(350, esRiuscito); return; }
  esRioMostra();
}
function esRioAnnulla(){ const r = ES.run; if (!r || r.fase !== 'corsa' || !r.scelto.length) return; const v = r.scelto.pop(); r.risposte.push({ at: Date.now(), azione: 'annullato', voce: v }); esRioMostra(); }

/* ---------------------------------------------------------------------------------------
   2. INTERROGATORIO
   --------------------------------------------------------------------------------------- */
function esBarraVoce(per){ return '<div class="es-qbar"><i id="esQBar" style="animation-duration:' + per + 's"></i></div>'; }
function esInterMostra(){
  const r = ES.run, c = ES.cfg.interrogatorio, q = r.lista[r.i];
  r.voce = { t0: Date.now(), per: c.secondiPerDomanda, fineAt: Date.now() + c.secondiPerDomanda * 1000, chiusa: false };
  esCorpo('<small class="es-conta">' + esH(esT('interrogatorio', 'conta', { i: r.i + 1, n: r.lista.length })) + '</small>' + esBarraVoce(c.secondiPerDomanda)
    + '<h2 class="es-domanda">' + esH(q.t) + '</h2>'
    + '<div class="es-sino"><button type="button" class="si" onclick="esInterRispondi(\'si\')">' + esH(esT('interrogatorio', 'si')) + '</button><button type="button" class="no" onclick="esInterRispondi(\'no\')">' + esH(esT('interrogatorio', 'no')) + '</button></div>');
}
function esInterRispondi(v){
  const r = ES.run; if (!r || r.fase !== 'corsa' || !r.voce || r.voce.chiusa) return;
  const q = r.lista[r.i];
  r.voce.chiusa = true;
  r.risposte.push({ at: Date.now(), id: q.id, domanda: q.t, risposta: v, ms: Date.now() - r.voce.t0 });
  const b = document.querySelector('.es-sino .' + v); if (b) b.classList.add('scelta');
  esVibra(12);
  esDopo(220, esInterAvanti);
}
function esInterAvanti(){ const r = ES.run; r.i++; if (r.i >= r.lista.length) esRiuscito(); else esInterMostra(); }
/* il tempo della singola domanda (o del singolo scenario) e' finito: resta «nessuna risposta» */
function esVoceScaduta(){
  const r = ES.run; if (!r || !r.voce || r.voce.chiusa) return;
  r.voce.chiusa = true;
  const q = r.lista[r.i], nulla = esT('comune', 'nessuna_risposta');
  if (r.tipo === 'interrogatorio'){ r.risposte.push({ at: Date.now(), id: q.id, domanda: q.t, risposta: nulla, ms: r.voce.per * 1000 }); esInterAvanti(); }
  else if (r.tipo === 'bivio'){ r.risposte.push({ at: Date.now(), id: q.id, scenario: q.t, scelta: nulla, nuovo: null, personale: q.personale }); esBivAvanti(); }
}

/* ---------------------------------------------------------------------------------------
   3. RIPASSO DI STAGIONE
   --------------------------------------------------------------------------------------- */
function esRipMostra(){
  const r = ES.run, q = r.lista[r.i];
  r.voce = { t0: Date.now(), chiusa: false };
  esCorpo('<small class="es-conta">' + esH(esT('ripasso', 'conta', { i: r.i + 1, n: r.lista.length })) + '</small><h3 class="es-h3">' + esH(q.t) + '</h3>'
    + '<div class="es-opz">' + q.opzioni.map(function(o, i){ return '<button type="button" onclick="esRipScegli(' + i + ')">' + esH(o) + '</button>'; }).join('') + '</div><p class="es-vero" id="esVero"></p>');
}
function esRipScegli(i){
  const r = ES.run; if (!r || r.fase !== 'corsa' || !r.voce || r.voce.chiusa) return;
  const q = r.lista[r.i];
  r.voce.chiusa = true;
  const giusta = i === q.giusta;
  r.risposte.push({ at: Date.now(), id: q.id, domanda: q.t, opzioni: q.opzioni, scelta: q.opzioni[i], giusta: q.opzioni[q.giusta], dato: q.vero, corretta: giusta });
  document.querySelectorAll('.es-opz button').forEach(function(b, k){ b.disabled = true; if (k === q.giusta) b.classList.add('giusta'); else if (k === i) b.classList.add('sbagliata'); });
  const v = document.getElementById('esVero'); if (v) v.textContent = esT('ripasso', 'dato_vero', { v: q.vero });
  esVibra(giusta ? 14 : [30, 40, 30]);
  esDopo(1500, esRipAvanti);
}
function esRipAvanti(){ const r = ES.run; r.i++; if (r.i >= r.lista.length) esRiuscito(); else esRipMostra(); }

/* ---------------------------------------------------------------------------------------
   4. IL BIVIO
   --------------------------------------------------------------------------------------- */
function esBivMostra(){
  const r = ES.run, c = ES.cfg.bivio, q = r.lista[r.i];
  r.voce = { t0: Date.now(), per: c.secondiPerScenario, fineAt: Date.now() + c.secondiPerScenario * 1000, chiusa: false };
  esCorpo('<small class="es-conta">' + esH(esT('bivio', 'conta', { i: r.i + 1, n: r.lista.length })) + '</small>' + esBarraVoce(c.secondiPerScenario)
    + '<h3 class="es-h3">' + esH(q.t) + '</h3>'
    + '<div class="es-opz">' + q.opzioni.map(function(o, i){ return '<button type="button" onclick="esBivScegli(' + i + ')">' + esH(o.t) + '</button>'; }).join('') + '</div><p class="es-vero" id="esVero"></p>');
}
function esBivScegli(i){
  const r = ES.run; if (!r || r.fase !== 'corsa' || !r.voce || r.voce.chiusa) return;
  const q = r.lista[r.i], o = q.opzioni[i];
  r.voce.chiusa = true;
  r.risposte.push({ at: Date.now(), id: q.id, scenario: q.t, scelta: o.t, nuovo: !!o.nuovo, personale: q.personale, ms: Date.now() - r.voce.t0 });
  document.querySelectorAll('.es-opz button').forEach(function(b, k){ b.disabled = true; if (k === i) b.classList.add(o.nuovo ? 'giusta' : 'sbagliata'); });
  const qb = document.getElementById('esQBar'); if (qb) qb.style.animationPlayState = 'paused';
  const v = document.getElementById('esVero'); if (v){ v.textContent = esT('bivio', o.nuovo ? 'nuovo' : 'vecchio'); v.classList.toggle('no', !o.nuovo); }
  esVibra(o.nuovo ? 14 : [30, 40, 30]);
  esDopo(900, esBivAvanti);
}
function esBivAvanti(){ const r = ES.run; r.i++; if (r.i >= r.lista.length) esRiuscito(); else esBivMostra(); }

/* ---------------------------------------------------------------------------------------
   5. PITCH DA 60 SECONDI
   --------------------------------------------------------------------------------------- */
function esPitchCorsa(){
  const r = ES.run; r.testo = '';
  esCorpo('<textarea class="es-pitch" id="esPitch" maxlength="1200" placeholder="' + esH(esT('pitch', 'ph')) + '" oninput="esPitchScrive()"></textarea>'
    + '<small class="es-conta" id="esPitchN">' + esH(esT('pitch', 'parole', { n: 0 })) + '</small>'
    + '<button type="button" class="cta es-cta" id="esPitchBtn" onclick="esPitchConsegna()" disabled>' + esH(esT('pitch', 'consegna')) + '</button>');
  const ta = document.getElementById('esPitch'); if (ta) try{ ta.focus(); }catch(_){ }
}
function esPitchLeggi(){ const r = ES.run, ta = document.getElementById('esPitch'); if (r && ta) r.testo = ta.value.trim(); }
function esPitchScrive(){
  const r = ES.run; if (!r) return; esPitchLeggi();
  const n = esParole(r.testo);
  const c = document.getElementById('esPitchN'); if (c) c.textContent = esT('pitch', 'parole', { n: n });
  const b = document.getElementById('esPitchBtn'); if (b) b.disabled = n < ES.cfg.pitch.minParole;
}
function esPitchConsegna(){
  const r = ES.run; if (!r || r.fase !== 'corsa') return; esPitchLeggi();
  const n = esParole(r.testo), min = ES.cfg.pitch.minParole;
  if (n < min){ toast(esT('pitch', 'corto', { min: min, n: n })); return; }
  esRiuscito();
}

/* ---------------------------------------------------------------------------------------
   IL GETTONE SALVA-SERIE, CON LE MONETE
   --------------------------------------------------------------------------------------- */
function esGettoni(){ try{ return snStato().serie.gettoni || 0; }catch(_){ return 0; } }
async function esNegozioApri(){
  const cfg = await esCarica(); if (!cfg){ return; }
  let w = document.getElementById('esNegozio');
  if (!w){ w = document.createElement('div'); w.id = 'esNegozio'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) esNegozioChiudi(); }); document.body.appendChild(w); }
  const G = cfg.comune.gettone, hai = esMonete(), n = esGettoni(), stato = esGettoneStato(n, hai, G.costo, G.max);
  const N = function(k, v){ return esH(esRiempi(cfg.negozio[k], v)); };
  w.innerHTML = '<div class="sd-sheet-in"><i class="pr-grab"></i><div class="es-neg-ico">🛡️</div><h3>' + N('titolo') + '</h3><p>' + N('testo', { max: G.max }) + '</p>'
    + '<p class="es-neg-saldo">🪙 ' + N('saldo', { hai: hai, n: n, max: G.max }) + '</p>'
    + (stato === 'ok' ? '<button type="button" class="cta" onclick="esGettoneCompra()">' + N('compra', { costo: G.costo }) + '</button>'
        : '<p class="es-neg-no">' + (stato === 'pieno' ? N('pieno', { max: G.max }) : N('poche', { costo: G.costo, hai: hai })) + '</p>')
    + '<button type="button" class="sd-btn-link" onclick="esNegozioChiudi()">' + N('chiudi') + '</button></div>';
  w.hidden = false;
}
function esNegozioChiudi(){ const w = document.getElementById('esNegozio'); if (w) w.remove(); }
function esGettoneCompra(){
  const G = ES.cfg.comune.gettone;
  if (esGettoneStato(esGettoni(), esMonete(), G.costo, G.max) !== 'ok') return;
  esMoneteAggiungi(-G.costo);
  try{ const sn = snStato(); sn.serie.gettoni = (sn.serie.gettoni || 0) + 1; snSalva(sn); }catch(_){ }
  toast(esRiempi(ES.cfg.negozio.comprato, { n: esGettoni() }));
  esVibra([20, 30, 60]);
  esNegozioApri();
  try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   GLI AGGANCI E LO STILE (solo dentro all'app: i test caricano il file senza pagina)
   --------------------------------------------------------------------------------------- */
if (typeof document !== 'undefined' && typeof registerScreen === 'function'){
  registerScreen('s-esercizio', '<div class="es" id="esBox"></div>', { back: esIndietro });
  /* chi esce dall'app mentre il tempo corre, perde l'esercizio */
  document.addEventListener('visibilitychange', function(){ const r = ES.run; if (document.hidden && r && (r.fase === 'corsa' || r.fase === 'scaduto')) esPerso('uscito'); });
  document.addEventListener('DOMContentLoaded', function(){ setTimeout(esCarica, 1200); });
  (function(){
    const css = [
      '#s-esercizio{padding:0;background:#001E44}',
      '.es{position:absolute;inset:0;display:flex;flex-direction:column;color:#fff;padding:calc(14px + env(safe-area-inset-top)) 18px calc(18px + env(safe-area-inset-bottom))}',
      '.es-top{display:flex;align-items:center;gap:12px}.es-x{flex:none;width:36px;height:36px;border:0;border-radius:50%;background:#0A2A57;color:#9FB2D0;font-size:16px;cursor:pointer}',
      '.es-barra{flex:1;height:16px;border-radius:99px;background:#0A2A57;overflow:hidden}.es-barra i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#3F9FF4,#BCE0FF);transition:width .1s linear}.es-barra i.poco{background:#E63946}',
      '.es-tempo{flex:none;min-width:54px;text-align:right;font:900 22px var(--font-display);color:#fff;font-variant-numeric:tabular-nums}.es-tempo.poco{color:#E63946;animation:esBatte .5s ease-in-out infinite}',
      '@keyframes esBatte{50%{transform:scale(1.12)}}','.es.finito .es-tempo{animation:none;color:#9FB2D0}.es.finito .es-barra i{background:#1F4A80}',
      '.es-sotto{display:flex;justify-content:space-between;align-items:center;margin:10px 2px 0;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#9FB2D0}.es-monete{color:#FFC800}.es-monete b{font-weight:900}',
      '.es-corpo{flex:1;overflow:auto;padding:22px 2px 8px;display:flex;flex-direction:column}',
      '.es-ico-grande{font-size:64px;line-height:1;text-align:center;margin:18px 0 22px}',
      '.es-h{margin:0 0 16px;font:900 25px/1.2 var(--font-display);color:#fff;text-align:center}.es-h3{margin:0 0 16px;font:800 20px/1.3 var(--font-display);color:#fff}',
      '.es-p{margin:0 0 14px;font:500 15px/1.55 var(--font-body);color:#C8D6EA;text-align:center}.es-p + .es-p{margin-top:-2px}.es-p.ultimo{margin-bottom:26px}.es-sogno{margin:0 0 22px;font:700 14px/1.4 var(--font-body);color:#8CC6FF;text-align:center}',
      '.es-regola{margin:0 0 18px;padding:12px 14px;border-radius:14px;background:#0A2A57;border:1px solid #1F4A80;font:600 13.5px/1.5 var(--font-body);color:#E6EEFA}',
      '.es-premio{margin:0 0 26px;font:700 13.5px var(--font-body);color:#8CC6FF;text-align:center}',
      '.es-cta{margin-top:auto;background:#0075E3;color:#fff;box-shadow:0 5px 0 #005BB0;font-weight:900}.es-cta:disabled{background:#1F4A80;color:#9FB2D0;box-shadow:none;filter:none;opacity:1}',
      '.es-sec{display:block;width:100%;margin-top:10px;border:0;border-radius:99px;background:#0A2A57;color:#fff;padding:14px;font:800 15px var(--font-body);cursor:pointer}',
      '.es-link{display:block;width:100%;margin-top:6px;border:0;background:transparent;color:#9FB2D0;font:700 14px var(--font-body);cursor:pointer;padding:12px}',
      '.es-conta{display:block;margin:0 0 10px;font:800 11.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#9FB2D0}',
      /* taglia */
      '.es-scrivi{display:flex;gap:8px;margin:4px 0 12px}.es-scrivi input{flex:1;min-width:0;border:2px solid #1F4A80;border-radius:14px;background:#0A2A57;color:#fff;padding:13px 14px;font:600 15px var(--font-body);outline:0}.es-scrivi input:focus{border-color:#3F9FF4}.es-scrivi input::placeholder{color:#7F9CC4}',
      '.es-scrivi button{flex:none;border:0;border-radius:14px;background:#3F9FF4;color:#001E44;padding:0 16px;font:900 14px var(--font-body);cursor:pointer}',
      '.es-voce{display:flex;align-items:center;gap:10px;width:100%;margin:0 0 10px;padding:15px 16px;border:2px solid #1F4A80;border-radius:16px;background:#0A2A57;color:#fff;font:700 15.5px/1.35 var(--font-body);text-align:left;cursor:pointer;box-shadow:0 4px 0 #000F26}',
      '.es-voce span{flex:1;min-width:0;overflow-wrap:anywhere}.es-voce i{flex:none;font:800 12px var(--font-body);font-style:normal;color:#F6A5B5}.es-voce:active{transform:translateY(3px);box-shadow:0 1px 0 #000F26}',
      '.es-voce.bozza{cursor:default;padding:11px 14px;box-shadow:none}.es-voce.bozza button{flex:none;width:30px;height:30px;border:0;border-radius:50%;background:#0A2A57;color:#9FB2D0;cursor:pointer}',
      '.es-rimasta{margin:6px 0 12px;padding:18px 16px;border-radius:18px;background:#0A2A57;border:2px solid #3F9FF4;font:800 19px/1.35 var(--font-display);color:#fff;text-align:center;overflow-wrap:anywhere}',
      '.es-regole{display:flex;flex-direction:column;gap:8px;margin:6px 0 12px}',
      '.es-regole div{padding:12px 14px;border-radius:14px;background:#0A2A57;border:1.5px solid #3F9FF4;font:700 15px/1.4 var(--font-body);color:#fff;overflow-wrap:anywhere}',
      '.es-era{margin:0 0 12px;font:700 14px/1.45 var(--font-body);color:#F6A5B5;text-align:center}',
      /* riordina */
      '.es-rio button{display:flex;align-items:center;gap:12px;width:100%;margin:0 0 10px;padding:14px 14px;border:2px solid #1F4A80;border-radius:16px;background:#0A2A57;color:#fff;font:700 15px/1.35 var(--font-body);text-align:left;cursor:pointer;box-shadow:0 4px 0 #000F26}',
      '.es-rio button b{flex:none;width:30px;height:30px;border-radius:50%;border:2px dashed #3F6FA8;display:flex;align-items:center;justify-content:center;font:900 15px var(--font-display);color:#001E44}.es-rio button span{flex:1;min-width:0}',
      '.es-rio button.preso{border-color:#3F9FF4;background:#0D3D73}.es-rio button.preso b{border:0;background:var(--dream)}',
      '.es-rio-fine{margin:0 0 14px;text-align:left}.es-rio-fine div{display:flex;align-items:center;gap:10px;padding:10px 12px;margin-bottom:6px;border-radius:14px;background:#0A2A57;border:1px solid #1F4A80}.es-rio-fine div.ok{border-color:#3F9FF4}',
      '.es-rio-fine b{flex:none;width:26px;height:26px;border-radius:50%;background:var(--dream);color:#001E44;display:flex;align-items:center;justify-content:center;font:900 13px var(--font-display)}.es-rio-fine span{flex:1;font:600 13.5px/1.35 var(--font-body);color:#E6EEFA}.es-rio-fine i{flex:none;font:800 12px var(--font-body);font-style:normal;color:#9FB8DA}.es-rio-fine div.ok i{color:#BCE0FF}',
      /* interrogatorio */
      '.es-qbar{height:8px;border-radius:99px;background:#0A2A57;overflow:hidden;margin:0 0 24px}.es-qbar i{display:block;height:100%;background:#3F9FF4;border-radius:99px;transform-origin:left;animation:esScorre linear both}',
      '@keyframes esScorre{from{transform:scaleX(1)}to{transform:scaleX(0)}}',
      '.es-domanda{margin:8px 0 0;font:900 27px/1.25 var(--font-display);color:#fff;text-align:center;flex:1;display:flex;align-items:center;justify-content:center}',
      '.es-sino{display:flex;gap:12px;margin-top:20px}.es-sino button{flex:1;border:0;border-radius:20px;padding:26px 0;font:900 24px var(--font-display);cursor:pointer}.es-sino .si{background:#0075E3;color:#fff;box-shadow:0 6px 0 #005BB0}.es-sino .no{background:#E63946;color:#fff;box-shadow:0 6px 0 #C42B38}.es-sino button:active,.es-sino button.scelta{transform:translateY(4px);box-shadow:none}',
      /* ripasso e bivio */
      '.es-opz button{display:block;width:100%;margin:0 0 10px;padding:16px;border:2px solid #1F4A80;border-radius:16px;background:#0A2A57;color:#fff;font:700 15.5px/1.35 var(--font-body);text-align:left;cursor:pointer;box-shadow:0 4px 0 #000F26}',
      '.es-opz button:disabled{opacity:1;cursor:default}.es-opz button.giusta{border-color:#0075E3;background:#0D3D73;color:#fff}.es-opz button.sbagliata{border-color:#E63946;background:#4A1220;color:#fff}',
      '.es-vero{min-height:22px;margin:6px 0 0;font:800 14px var(--font-body);color:#BCE0FF;text-align:center}.es-vero.no{color:#F6A5B5}',
      /* pitch */
      '.es-pitch{flex:1;min-height:180px;width:100%;box-sizing:border-box;border:2px solid #1F4A80;border-radius:18px;background:#0A2A57;color:#fff;padding:16px;font:500 16px/1.55 var(--font-body);resize:none;outline:0;margin-bottom:10px}.es-pitch:focus{border-color:#3F9FF4}.es-pitch::placeholder{color:#7F9CC4}.es-pitch:disabled{opacity:.7}',
      '.es-conf-t{display:block;margin:4px 0 8px;font:800 11.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#9FB2D0;text-align:center}',
      '.es-conf{display:flex;gap:8px;margin:0 0 16px;text-align:left}.es-conf > div{flex:1;min-width:0;max-height:210px;overflow:auto;padding:12px;border-radius:14px;background:#0A2A57;border:1px solid #1F4A80}.es-conf b{display:block;margin-bottom:6px;font:800 11.5px var(--font-body);color:#7CC4FF}.es-conf p{margin:0;font:500 13px/1.5 var(--font-body);color:#E6EEFA;overflow-wrap:anywhere}',
      /* esito */
      '.es-esito{flex:1;display:flex;flex-direction:column;text-align:center}.es-esito-ico{width:84px;height:84px;margin:18px auto 16px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:900 42px var(--font-display)}.es-esito.ok .es-esito-ico{background:var(--dream);color:#001E44}.es-esito.ko .es-esito-ico{background:#E63946;color:#fff}',
      '.es-chip{align-self:center;margin:2px 0 18px;padding:9px 16px;border-radius:99px;background:rgba(140,198,255,.12);border:1px solid #8CC6FF;color:#C8EFFD;font:900 14px var(--font-body)}',
      /* il velo: tempo scaduto, lasciare */
      '.es-velo{position:absolute;inset:0;z-index:5;background:rgba(4,8,16,.86);display:flex;align-items:flex-end}.es-velo[hidden]{display:none}',
      '.es-velo-in{width:100%;background:#0A2A57;border-radius:26px 26px 0 0;padding:24px 20px calc(22px + env(safe-area-inset-bottom));text-align:center}.es-velo-in h3{margin:0 0 8px;font:900 23px var(--font-display);color:#fff}.es-velo-in p{margin:0 0 16px;font:500 15px/1.5 var(--font-body);color:#C8D6EA}.es-velo-in .es-nota{font-weight:700;color:#8CC6FF}.es-velo-in .es-cta{margin-top:0}',
      /* il negozio del gettone e la pillola delle monete nella mappa */
      '.es-neg-ico{font-size:48px;line-height:1;margin-top:10px}.es-neg-saldo{font-weight:800!important;color:var(--navy)!important}body.dark .es-neg-saldo{color:#fff!important}.es-neg-no{font-weight:700!important;color:#C24A00!important}body.dark .es-neg-no{color:#FFB37A!important}',
      'button.sd-pill{cursor:pointer;font-family:inherit}'
    ].join('\n');
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { esSeme: esSeme, esRng: esRng, esMescola: esMescola, esInterScegli: esInterScegli, esOpzioniNumero: esOpzioniNumero, esRipassoDomande: esRipassoDomande,
    esBivioVariabili: esBivioVariabili, esBivioScenari: esBivioScenari, esBivioPunto: esBivioPunto, esPitchMancano: esPitchMancano, esRipassoMancano: esRipassoMancano,
    esExtraStato: esExtraStato, esGettoneStato: esGettoneStato, esTagliaVoci: esTagliaVoci, esTagliaDaDati: esTagliaDaDati, esRiordinaPunteggio: esRiordinaPunteggio, esRiordinaScegli: esRiordinaScegli, esParole: esParole, esTempoTxt: esTempoTxt, esDurata: esDurata, esRiempi: esRiempi, esGiornoNome: esGiornoNome };
}
