/* perms.js - Android permissions, corsia U-E.
 *
 * Contains, in order:
 *   1. the prominent disclosure for the accessibility service (R2) and the consent record,
 *   2. the per-ROM guide that tells the user where their manufacturer hid the setting (G77),
 *   3. opening the real Settings pages (openPerm) and reading their state back (refreshPerms),
 *      including the two grants that were missing from the flow entirely: overlay (G74) and
 *      battery optimisation (G76),
 *   4. the restricted-settings flow Android 13+ imposes on sideloaded apps (kept as it was:
 *      it works, and breaking it would cost more than anything added here).
 *
 * Rule that governs every call below: NATIVE may be absent (browser preview) and every plugin
 * method may reject. Neither may leave a promise hanging or a button dead (G88).
 */

/* ============================================================================
 * 1. PROMINENT DISCLOSURE — R2
 *
 * Play does not accept an app that uses the accessibility API without a disclosure that shows
 * up during normal use, names the data read, and takes an AFFIRMATIVE consent. "Affirmative"
 * excludes a Close button and excludes merely walking past the screen, so this screen is a
 * gate in front of openAccessibilitySettings(), not a notice next to it. The consent is stored
 * with its date because the reviewer, and later we, need to be able to say when it was given.
 * ========================================================================== */

const A11Y_CONSENT_KEY = 'fl_a11y_consent';
const A11Y_CONSENT_VERSION = 1;   // bump to re-ask when the wording of what we read changes

function a11yConsentRecord(){
  try{ return JSON.parse(localStorage.getItem(A11Y_CONSENT_KEY) || 'null'); }
  catch(e){ return null; }
}
function hasA11yConsent(){
  const c = a11yConsentRecord();
  return !!(c && c.accepted === true && c.version === A11Y_CONSENT_VERSION);
}
function a11yConsentDateText(){
  const c = a11yConsentRecord();
  if(!c || !c.at) return '';
  const d = new Date(c.at);
  if(isNaN(d.getTime())) return '';
  const p = n => String(n).padStart(2,'0');
  return p(d.getDate())+'/'+p(d.getMonth()+1)+'/'+d.getFullYear()+' alle '+p(d.getHours())+':'+p(d.getMinutes());
}

/* Where the user was when the disclosure interrupted them, so "Non ora" puts them back there
   instead of guessing a screen. */
let a11yFrom = 's15';
/* What they were trying to reach when we stopped them, so accepting resumes that action
   instead of dropping them on a dead screen. */
let a11yPending = 'accessibility';

const A11Y_DISCLOSURE_HTML = `
  <div class="topbar"><button class="iconbtn" onclick="declineA11yDisclosure()">&lsaquo;</button></div>
  <div class="ue-disc-badge">
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M12 3l7 3v5c0 4.6-3 8.4-7 10-4-1.6-7-5.4-7-10V6l7-3z" fill="#fff"/>
      <path d="M9.5 12l2 2 3.5-3.8" stroke="#0075E3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </div>
  <h2 class="ue-disc-title">DreamMap ha bisogno del Servizio di accessibilità</h2>
  <p class="ue-disc-intro">
    Per bloccare davvero un'app o un sito, DreamMap deve sapere che cosa hai davanti in questo
    momento. Android lo consente solo attraverso il Servizio di accessibilità: è il motore di
    tutta l'app.</p>

  <div class="ue-disc-card">
    <b class="ue-disc-h">Mentre il servizio è attivo, DreamMap legge:</b>
    <ul class="ue-disc-list">
      <li><b>Il nome dell'app che hai in primo piano</b> — per riconoscere quando apri un'app che
        hai messo in blocco.</li>
      <li><b>L'indirizzo del sito nella barra del browser</b> — per riconoscere un sito o un
        dominio della tua lista di blocco.</li>
      <li><b>Il testo che digiti in una barra di ricerca</b> — per riconoscere una parola chiave
        bloccata anche quando l'indirizzo non la contiene.</li>
      <li><b>Il testo visibile della pagina</b> — solo se scegli la corrispondenza «Nel contenuto»
        per una tua parola chiave. Senza quella impostazione, non viene esaminato.</li>
    </ul>
  </div>

  <div class="ue-disc-priv">
    <span class="ue-disc-privic">🔒</span>
    <span><b>Tutto questo resta sul telefono.</b> Il confronto avviene qui, sul dispositivo, nel
    momento stesso in cui apri qualcosa: niente viene salvato, niente viene inviato a un server,
    niente viene condiviso con terzi e niente viene usato per la pubblicità. DreamMap non tiene
    la cronologia di ciò che leggi.</span>
  </div>

  <p class="ue-disc-revoke">
    Puoi revocare il permesso quando vuoi da <b>Impostazioni › Accessibilità › DreamMap</b>:
    da quel momento Android smette di consegnarci qualunque evento.</p>

  <p class="ue-disc-given" id="a11yGiven" hidden></p>

  <div class="spacer"></div>
  <button class="cta" onclick="acceptA11yDisclosure()">Accetto e continuo</button>
  <button class="ghost" onclick="declineA11yDisclosure()">Non ora</button>
  <p class="legal">
    Toccando «Accetto e continuo» acconsenti all'uso del Servizio di accessibilità come descritto
    qui sopra. Il dettaglio completo è nell'<a href="legal/privacy.html" onclick="return ueOpenLegal('privacy')">Informativa sulla privacy</a>.
  </p>`;

/* Opens the disclosure. `pending` is the permission the user was reaching for, so accepting
   resumes it. Called from openPerm() and from the Profilo row, which is what keeps the
   disclosure reachable during normal use and not only once, buried in the onboarding. */
function showA11yDisclosure(pending){
  a11yPending = pending || 'accessibility';
  if(order[cur] !== 's-a11y-disclosure' && order[cur] !== 's-romguide') a11yFrom = order[cur];
  const given = document.getElementById('a11yGiven');
  if(given){
    const when = a11yConsentDateText();
    given.hidden = !when;
    given.innerHTML = when
      ? 'Consenso già registrato il ' + when +
        ' · <button class="ue-linkbtn" onclick="revokeA11yDisclosure()">revoca il consenso</button>'
      : '';
  }
  goId('s-a11y-disclosure');
}

/* The affirmative act. Nothing else in the app writes this key. */
function acceptA11yDisclosure(){
  const now = new Date();
  localStorage.setItem(A11Y_CONSENT_KEY, JSON.stringify({
    version: A11Y_CONSENT_VERSION,
    accepted: true,
    at: now.toISOString(),
    ts: now.getTime()
  }));
  // Resume what they asked for. proceedPerm() skips the consent gate: we have just passed it.
  proceedPerm(a11yPending);
}

function declineA11yDisclosure(){
  // No consent recorded, no Settings trip: refusing has to be a real option, or the consent is
  // not a consent. They go back where they were, with the button still reading "Abilita".
  toast('Nessun problema: puoi attivarlo quando vuoi');
  goId(a11yFrom || 's15');
}

/* Revoking is symmetric to giving: the record goes away and the gate closes again. It cannot
   flip the Android switch for them — only Settings can — so it says so. */
function revokeA11yDisclosure(){
  localStorage.removeItem(A11Y_CONSENT_KEY);
  const given = document.getElementById('a11yGiven');
  if(given){ given.hidden = true; given.innerHTML = ''; }
  toast('Consenso revocato. Disattiva il servizio da Impostazioni › Accessibilità');
  refreshPerms();
}

/* ============================================================================
 * 2. ROM GUIDE — G77
 *
 * Samsung, Xiaomi and Oppo each rename and move the accessibility entry, and each adds a
 * second gate (autostart / background activity) without which the service is killed within
 * hours. One generic "Settings > Accessibility" is wrong on the three families that make up
 * most Android phones here, so the steps are per-ROM — detected, and switchable by hand,
 * because user-agent sniffing is a guess and a wrong guess must not trap anyone on the wrong
 * instructions.
 * ========================================================================== */

const ROMS = {
  samsung: {
    label: 'Samsung',
    sub: 'One UI',
    steps: [
      ['Impostazioni › Accessibilità', 'One UI la mostra come voce principale nell\'elenco delle impostazioni.'],
      ['In fondo, «App installate»', 'È la sezione dei servizi non di sistema. Su alcune versioni si chiama «Servizi installati».'],
      ['Tocca DreamMap e attiva l\'interruttore', 'Compare una richiesta di conferma: è la schermata standard di Android per qualunque servizio di accessibilità.'],
      ['Poi: Impostazioni › Batteria › Limiti di utilizzo in background', 'Togli DreamMap dalle app «in sospensione» e da «sospensione profonda», altrimenti One UI lo chiude dopo qualche ora.']
    ]
  },
  xiaomi: {
    label: 'Xiaomi',
    sub: 'MIUI / HyperOS',
    steps: [
      ['Impostazioni › Impostazioni aggiuntive › Accessibilità', 'Su MIUI e HyperOS l\'accessibilità è annidata dentro «Impostazioni aggiuntive», non al primo livello.'],
      ['Scheda «App scaricate»', 'La schermata ha due schede: i servizi di sistema e quelli scaricati. DreamMap è nella seconda.'],
      ['Tocca DreamMap e attiva l\'interruttore', 'MIUI mostra un conto alla rovescia di qualche secondo prima di abilitare il pulsante di conferma: è normale, aspetta.'],
      ['Poi: Impostazioni › App › DreamMap › Risparmio batteria › «Nessuna restrizione»', 'Nella stessa pagina attiva «Avvio automatico». Senza questi due passaggi MIUI chiude il motore e i blocchi smettono di funzionare da soli.']
    ]
  },
  oppo: {
    label: 'Oppo / Realme',
    sub: 'ColorOS',
    steps: [
      ['Impostazioni › Impostazioni aggiuntive › Accessibilità', 'Su ColorOS e Realme UI il percorso passa da «Impostazioni aggiuntive».'],
      ['«Servizi scaricati» / «Servizi installati»', 'Il nome cambia con la versione di ColorOS: è la sezione delle app non di sistema.'],
      ['Tocca DreamMap e attiva l\'interruttore', 'Conferma la richiesta che compare.'],
      ['Poi: Impostazioni › Batteria › Utilizzo batteria in background', 'Metti DreamMap su «Consenti attività in background» e attivalo in «Gestione avvio automatico».']
    ]
  },
  huawei: {
    label: 'Huawei / Honor',
    sub: 'EMUI / MagicOS',
    steps: [
      ['Impostazioni › Accessibilità › Accessibilità', 'La voce è ripetuta due volte: quella interna contiene i servizi.'],
      ['«Servizi scaricati»', 'DreamMap è elencata qui.'],
      ['Attiva l\'interruttore e conferma', ''],
      ['Poi: Impostazioni › Batteria › Avvio app › DreamMap › gestione manuale', 'Attiva «Avvio automatico», «Avvio secondario» ed «Esecuzione in background»: senza, EMUI chiude il servizio.']
    ]
  },
  stock: {
    label: 'Pixel e altri',
    sub: 'Android essenziale',
    steps: [
      ['Impostazioni › Accessibilità', ''],
      ['Sezione «App scaricate»', 'Su Android 13 e successivi la lista è divisa per categorie: DreamMap è in fondo, fra le app scaricate.'],
      ['Tocca DreamMap e attiva «Usa DreamMap»', 'Conferma nella finestra che compare.'],
      ['Poi: Impostazioni › App › DreamMap › Batteria › «Senza restrizioni»', 'Facoltativo ma consigliato: evita che il sistema chiuda il motore quando il telefono resta fermo.']
    ]
  }
};

/* Heuristic on purpose: no plugin method reports the manufacturer, and the Android WebView
   user agent carries the model code, not the brand. The chips let the user correct us in one
   tap, which is cheaper and more honest than pretending to know. */
function detectRom(){
  let ua = navigator.userAgent || '';
  try{
    // userAgentData.brands never carries the OEM, but the model hint sometimes is exposed
    // synchronously; when it is we use it, otherwise the plain UA is enough.
    if(navigator.userAgentData && navigator.userAgentData.model) ua += ' ' + navigator.userAgentData.model;
  }catch(e){}
  if(/samsung|SM-[A-Z0-9]{4}|GT-[A-Z0-9]|SC-\d\d|galaxy|one ?ui/i.test(ua)) return 'samsung';
  if(/xiaomi|redmi|poco|miui|hyperos|\bM2\d{3}\b|\b2\d{5}[A-Z]/i.test(ua))  return 'xiaomi';
  if(/oppo|realme|coloros|oneplus|\bCPH\d{4}\b|\bRMX\d{4}\b/i.test(ua))     return 'oppo';
  if(/huawei|honor|emui|magicos/i.test(ua))                                 return 'huawei';
  return 'stock';
}

let ROM_KEY = null;                 // resolved lazily: detection runs once, then the user owns it
let romGuideFrom = 's15';
let romGuideVia  = '';              // how openAccessibilitySettings() actually landed

const ROM_GUIDE_HTML = `
  <div class="topbar"><button class="iconbtn" onclick="closeRomGuide()">&lsaquo;</button></div>
  <h2 class="ue-rom-title">Dove trovare DreamMap nelle impostazioni</h2>
  <p class="ue-rom-sub" id="romLead">Ogni produttore chiama questa voce in modo diverso.</p>
  <div class="ue-chips" id="romChips"></div>
  <div id="romSteps"></div>
  <div class="ue-rom-note">
    Non trovi la voce? Cerca «accessibilità» nella barra di ricerca delle Impostazioni: porta
    alla stessa schermata su qualunque telefono.
  </div>
  <div class="spacer"></div>
  <button class="cta" onclick="openAccessibilityNow()">Apri le impostazioni di Android</button>
  <button class="ghost" onclick="closeRomGuide()">Ho attivato il servizio</button>`;

function showRomGuide(){
  if(order[cur] !== 's-romguide' && order[cur] !== 's-a11y-disclosure') romGuideFrom = order[cur];
  if(!ROM_KEY) ROM_KEY = detectRom();
  renderRomGuide();
  goId('s-romguide');
}
function closeRomGuide(){ refreshPerms(); goId(romGuideFrom || 's15'); }

function pickRom(key){
  if(!ROMS[key]) return;
  ROM_KEY = key;
  localStorage.setItem('fl_rom', key);   // their correction outlives the session
  renderRomGuide();
}

function renderRomGuide(){
  const chips = document.getElementById('romChips');
  const steps = document.getElementById('romSteps');
  const lead  = document.getElementById('romLead');
  if(!chips || !steps) return;
  const saved = localStorage.getItem('fl_rom');
  if(saved && ROMS[saved]) ROM_KEY = saved;
  const rom = ROMS[ROM_KEY] || ROMS.stock;

  chips.innerHTML = Object.keys(ROMS).map(k =>
    '<button class="ue-chip' + (k===ROM_KEY ? ' on' : '') + '" onclick="pickRom(\'' + k + '\')">'
    + esc(ROMS[k].label) + '</button>'
  ).join('');

  if(lead){
    // Saying which screen actually opened is the difference between a guide and a guess: when
    // the deep link worked, the user is already on the right row and the steps would confuse.
    lead.innerHTML = (romGuideVia === 'oem-oneui' || romGuideVia === 'deeplink')
      ? 'Ti abbiamo portato direttamente alla riga di DreamMap. Se non la vedi evidenziata, '
        + 'segui i passaggi qui sotto per <b>' + esc(rom.label) + '</b>.'
      : 'Ogni produttore chiama questa voce in modo diverso. Questi sono i passaggi per <b>'
        + esc(rom.label) + '</b> (' + esc(rom.sub) + ').';
  }

  steps.innerHTML = '<div class="panelcard ue-steps">' + rom.steps.map((s,i) =>
    '<div class="ue-step"><span class="ue-stepn">' + (i+1) + '</span><div><b>'
    + esc(s[0]) + '</b>' + (s[1] ? '<p>' + esc(s[1]) + '</p>' : '') + '</div></div>'
  ).join('') + '</div>';
}

/* The button on the guide. Separate from openPerm() because consent has already been given by
   the time this screen exists, and asking again would be noise. */
async function openAccessibilityNow(){
  if(!NATIVE || !NATIVE.openAccessibilitySettings){
    toast('Anteprima: sul telefono si aprirebbero le Impostazioni di Android');
    return;
  }
  try{
    const r = await NATIVE.openAccessibilitySettings();
    romGuideVia = (r && r.via) || '';
    renderRomGuide();
    if(r && r.opened === false) toast('Android non ha aperto la pagina: cercala come nei passaggi qui sopra');
  }catch(e){
    toast(permError(e, 'Non riesco ad aprire le impostazioni di accessibilità'));
  }
}

/* ============================================================================
 * 3. PERMISSIONS
 * ========================================================================== */

/* Where the user was when Android turned out to be blocking the grant, so the back arrow
   returns there instead of guessing. */
let restrictedFrom = "s15";
let RESTRICTED = null;

/* Older installed builds have no isRestrictedSettings: an app that cannot ask must not guess
   a "yes", or it would hide the real settings page behind an explanation that may be wrong. */
async function isBlockedByAndroid(){
  if(!NATIVE || !NATIVE.isRestrictedSettings) return false;
  try{ RESTRICTED = await NATIVE.isRestrictedSettings(); return !!RESTRICTED.restricted; }
  catch(e){ return false; }
}
function androidName(sdk){ return sdk >= 34 ? "14+" : (sdk >= 33 ? "13" : String(sdk)); }
function showRestricted(){
  if(order[cur] !== "s-restricted") restrictedFrom = order[cur];
  const st = document.getElementById("restrictedState");
  if(st && RESTRICTED){
    st.textContent = "Android " + androidName(RESTRICTED.sdk) + " · installata da "
                   + (RESTRICTED.installer ? RESTRICTED.installer : "file APK")
                   + ", autorizzazioni bloccate";
  }
  goId("s-restricted");
}
function closeRestricted(){ goId(restrictedFrom); }
async function openAppInfo(){
  if(!NATIVE || !NATIVE.openAppDetailsSettings){ toast("Disponibile solo nell" + String.fromCharCode(39) + "app installata"); return; }
  try{ await NATIVE.openAppDetailsSettings(); }
  catch(e){ toast(permError(e, 'Non riesco ad aprire le informazioni dell' + String.fromCharCode(39) + 'app')); }
}
/* After the user says they lifted it, ask Android again — their word is not the evidence. */
async function retryRestricted(){
  if(!NATIVE){ toast("Disponibile solo nell" + String.fromCharCode(39) + "app installata"); return; }
  try{
    const acc = await NATIVE.isServiceEnabled();
    if(acc.enabled){ toast("Servizio attivo ✓"); refreshPerms(); goId(restrictedFrom); return; }
    if(await isBlockedByAndroid()){
      toast("Android le tiene ancora bloccate — ripeti i 4 passaggi");
      showRestricted();
      return;
    }
    toast("Sbloccato: adesso attiva il servizio");
    showRomGuide();
    await openAccessibilityNow();
  }catch(e){ toast(permError(e, 'Controllo non riuscito, riprova')); }
}

/* A rejected plugin call must say something a person can act on. The plugin attaches a
   machine-readable `code` and an Italian message, so the message wins when it is there. */
function permError(e, fallback){
  if(!e) return fallback;
  if(e.code === 'strict-locked') return 'La Modalità severa è attiva: questa modifica è bloccata.';
  if(e.code === 'no-context')    return 'L' + String.fromCharCode(39) + 'app non è pronta: riprova fra un istante.';
  return e.message || fallback;
}

/* The single entry point every card, banner and settings row calls. */
async function openPerm(kind){
  // R2: the disclosure is a gate in front of the accessibility grant, and it is shown even in
  // the browser preview — that is where it gets reviewed before it gets published.
  if(kind === 'accessibility' && !hasA11yConsent()){ showA11yDisclosure(kind); return; }
  proceedPerm(kind);
}

async function proceedPerm(kind){
  if(!NATIVE){
    // Preview: say what would happen instead of failing silently. The disclosure above still
    // runs, so the whole consent flow is testable without a device.
    if(kind === 'accessibility'){ showRomGuide(); return; }
    toast('Anteprima nel browser: sul telefono si aprirebbero le Impostazioni di Android');
    return;
  }
  try{
    // Accessibility and usage access are the two grants Android 13+ shuts off for sideloaded
    // apps. Sending the user to a page where the switch is grey teaches them the app is broken;
    // ask first, and explain how to open it. The other three are never restricted.
    if(kind === 'accessibility' || kind === 'usage'){
      if(await isBlockedByAndroid()){ showRestricted(); return; }
    }
    // Straight to the Accessibility list, skipping the check above on purpose.
    //
    // It is reached from the restricted-settings guide itself, where sending the user back to
    // that same guide would be a loop. And it has a real job: Android only offers "Allow
    // restricted settings" while a block is actually pending, so tapping the greyed-out entry
    // and being refused is often what makes the option appear in the first place.
    if(kind === 'accessibility-raw'){
      await openAccessibilityNow();
      return;
    }
    if(kind === 'accessibility'){
      // The guide goes on screen BEFORE the Settings trip, so it is what they come back to.
      showRomGuide();
      await openAccessibilityNow();
      return;
    }
    if(kind === 'usage'){
      if(!NATIVE.openUsageAccessSettings){ toast('Non disponibile in questa versione dell' + String.fromCharCode(39) + 'app'); return; }
      await NATIVE.openUsageAccessSettings();
    }
    if(kind === 'notif'){
      if(!NATIVE.openNotificationAccessSettings){ toast('Non disponibile in questa versione dell' + String.fromCharCode(39) + 'app'); return; }
      await NATIVE.openNotificationAccessSettings();
    }
    if(kind === 'overlay'){
      if(!NATIVE.openOverlaySettings){ toast('Non disponibile in questa versione dell' + String.fromCharCode(39) + 'app'); return; }
      const r = await NATIVE.openOverlaySettings();
      if(r && r.via === 'not-needed'){ toast('Su questa versione di Android non serve ✓'); refreshPerms(); }
    }
    if(kind === 'battery'){
      if(!NATIVE.openBatteryOptimizationSettings){ toast('Non disponibile in questa versione dell' + String.fromCharCode(39) + 'app'); return; }
      const r = await NATIVE.openBatteryOptimizationSettings();
      if(r && r.via === 'battery-list') toast('Cerca DreamMap nell' + String.fromCharCode(39) + 'elenco e scegli «Non ottimizzare»');
    }
  }catch(e){
    toast(permError(e, 'Non riesco ad aprire questa impostazione'));
  }
  // The user leaves for a Settings screen; refreshPerms() re-checks when they come back.
}

/* ---------- the two cards missing from s15 (G74, G76) ----------
 * index.html is frozen and six lanes share it, so the markup is injected here, next to the code
 * that drives it. Idempotent: registering twice would give two cards with the same id. */
function mountExtraPermCards(){
  const s15 = document.getElementById('s15');
  if(!s15 || document.getElementById('ue-card-overlay')) return;
  const anchor = s15.querySelector('.spacer');       // sits above the Continua button
  const box = document.createElement('div');
  box.innerHTML = `
    <div class="panelcard ue-permcard" id="ue-card-overlay">
      <b>Mostra sopra le altre app <span class="ue-tagi">consigliata</span></b>
      <p>È la finestra con cui la schermata di blocco compare <b>sopra</b> l'app che stai aprendo.
         Senza, il blocco può solo chiuderla: succede e basta, senza spiegazione.</p>
      <button class="cta ue-permbtn" id="perm-overlay" onclick="openPerm('overlay')">Abilita</button>
    </div>
    <div class="panelcard ue-permcard" id="ue-card-battery">
      <b>Nessuna restrizione della batteria <span class="ue-tagi red">importante</span></b>
      <p>Samsung, Xiaomi e Oppo chiudono le app rimaste in secondo piano per risparmiare batteria:
         è il motivo per cui, su questi telefoni, dopo qualche ora i blocchi smettono di funzionare
         da soli. Con questa esclusione il motore resta vivo.</p>
      <button class="cta ue-permbtn" id="perm-battery" onclick="openPerm('battery')">Abilita</button>
    </div>`;
  while(box.firstElementChild){
    if(anchor) s15.insertBefore(box.firstElementChild, anchor);
    else s15.appendChild(box.firstElementChild);
  }

  // Same two grants, plus the disclosure and the guide, reachable later from Profilo — where a
  // user goes looking when the blocking "stopped working". Play also wants the disclosure to
  // stay reachable during normal use, not only once during setup.
  const prof = document.getElementById('tab-profilo');
  if(prof && !document.getElementById('ue-set-overlay')){
    const rows = document.createElement('div');
    rows.innerHTML = `
      <div class="setrow" id="ue-set-overlay" onclick="openPerm('overlay')"><span>🪟</span><b>Mostra sopra le altre app</b><small id="setOverlay">—</small><span class="chev"></span></div>
      <div class="setrow" id="ue-set-battery" onclick="openPerm('battery')"><span>🔋</span><b>Restrizioni batteria</b><small id="setBattery">—</small><span class="chev"></span></div>
      <div class="setrow" onclick="showA11yDisclosure('accessibility')"><span>📄</span><b>Dati letti dal servizio</b><small>informativa</small><span class="chev"></span></div>
      <div class="setrow" onclick="showRomGuide()"><span>🧭</span><b>Guida per il tuo telefono</b><small id="setRom">—</small><span class="chev"></span></div>`;
    while(rows.firstElementChild) prof.appendChild(rows.firstElementChild);
  }
}

/* Reads every grant back from the system. Nothing here marks itself as done: only Android can
   say yes. Never throws — a failed probe leaves the previous, honest label alone. */
async function refreshPerms(){
  const romLbl = document.getElementById('setRom');
  if(romLbl){
    if(!ROM_KEY) ROM_KEY = localStorage.getItem('fl_rom') || detectRom();
    romLbl.textContent = (ROMS[ROM_KEY] || ROMS.stock).label;
  }

  if(!NATIVE){
    // G88, second half: in the browser preview the service can never report "on", so Continua
    // stayed disabled forever and the onboarding ended in a wall. The preview now says what it
    // is and lets the tester through.
    previewUnlockPerms();
    return;
  }
  try{
    const acc = await NATIVE.isServiceEnabled();
    const usage = await NATIVE.isUsageAccessGranted();
    const notif = await NATIVE.isNotificationAccessGranted();
    mark('perm-acc', acc.enabled);
    // Say it on the card too: a button that reads "Abilita" over a switch Android will not let
    // them touch is the exact lie this screen was told to stop telling.
    if(!acc.enabled && await isBlockedByAndroid()){
      const b = document.getElementById('perm-acc');
      if(b){ b.textContent = 'Bloccata da Android — vedi come sbloccarla'; b.disabled = false; }
    }
    mark('perm-usage', usage.granted);
    mark('perm-notif', notif.granted);
    // Same truth, shown again in Profilo where the user goes looking for it.
    setLbl('setAcc', acc.enabled); setLbl('setUsage', usage.granted); setLbl('setNotif', notif.granted);

    // G74 — overlay. `required:false` is Android below 23, where the window type needs no grant:
    // the card would become a permanent unfixable warning, so it goes away instead.
    if(NATIVE.isOverlayGranted){
      const ov = await NATIVE.isOverlayGranted();
      if(ov.required === false) hidePermCard('ue-card-overlay','ue-set-overlay');
      else { mark('perm-overlay', ov.granted); setLbl('setOverlay', ov.granted); }
    } else hidePermCard('ue-card-overlay','ue-set-overlay');

    // G76 — battery optimisation. Same reasoning for `supported:false`.
    if(NATIVE.isBatteryOptimizationIgnored){
      const bt = await NATIVE.isBatteryOptimizationIgnored();
      if(bt.supported === false) hidePermCard('ue-card-battery','ue-set-battery');
      else {
        mark('perm-battery', bt.ignored);
        const l = document.getElementById('setBattery');
        if(l){
          if(bt.ignored){
            l.textContent = 'nessuna restrizione';
            l.style.color = '#0F7A3D';
          }else if(bt.oemManaged){
            // We read the AOSP allowlist; the OEM keeps a separate switch we cannot see. The
            // user can see it, and claiming the opposite of what their screen says is worse
            // than admitting the limit.
            l.textContent = 'da verificare in Batteria';
            l.style.color = 'var(--muted)';
          }else{
            l.textContent = 'il sistema può chiuderlo';
            l.style.color = 'var(--red)';
          }
        }
      }
    } else hidePermCard('ue-card-battery','ue-set-battery');

    // Continue unlocks only once the essential service is really on.
    const next = document.getElementById('permsNext');
    if(next) next.disabled = !acc.enabled;
    const skip = document.getElementById('ue-perms-skip');
    if(skip) skip.hidden = !!acc.enabled;   // no reason to offer a way out once it works

    if(usage.granted && NATIVE.getScreenTimeToday){
      const st = await NATIVE.getScreenTimeToday();
      const el = document.getElementById('perm-usage-real');
      if(el && st.granted){
        el.style.display='block';
        el.textContent = 'Oggi hai usato il telefono ' + fmtMin(st.minutes) + '. Ci eri andato vicino?';
      }
    }
  }catch(e){}
}

function hidePermCard(cardId, rowId){
  const c = document.getElementById(cardId); if(c) c.hidden = true;
  const r = document.getElementById(rowId);  if(r) r.hidden = true;
}

/* Browser preview: the buttons stay pressable (they explain themselves) and the gate opens. */
function previewUnlockPerms(){
  const next = document.getElementById('permsNext');
  if(next && next.disabled){
    next.disabled = false;
    const note = next.nextElementSibling;
    if(note) note.textContent = 'Anteprima nel browser: qui il servizio di blocco non esiste, '
                              + 'quindi il pulsante è già sbloccato. Sul telefono si sblocca solo a servizio attivo.';
  }
  const skip = document.getElementById('ue-perms-skip');
  if(skip) skip.hidden = true;
}

function setLbl(id, granted){
  const el=document.getElementById(id);
  if(el){ el.textContent = granted ? 'attivo' : 'non attivo';
          el.style.color = granted ? '#0F7A3D' : 'var(--red)'; }
}
function mark(id, granted){
  const btn = document.getElementById(id);
  if(!btn) return;
  btn.textContent = granted ? 'Abilitata ✓' : 'Abilita';
  btn.disabled = granted;
  btn.style.opacity = granted ? '.6' : '1';
  /* 0.9.293, Andrea: "le voci gia' abilitate non devono apparire: Abilitata per un secondo, poi il pannello esce verso
     destra e quello sotto sale al suo posto". Solo nella pagina dei permessi dell'onboarding (s15). */
  const card = btn.closest('#s15 .panelcard');
  if (!card) return;
  const prima = btn.dataset.pm;
  btn.dataset.pm = granted ? '1' : '0';
  if (!granted){ card.classList.remove('pm-via', 'pm-chiuso'); card.style.maxHeight = ''; card.style.display = ''; return; }
  if (prima === '1' || card.classList.contains('pm-chiuso')) return;
  if (prima === undefined){ card.classList.add('pm-via', 'pm-chiuso'); card.style.display = 'none'; return; }
  setTimeout(function(){
    card.style.maxHeight = card.offsetHeight + 'px';
    card.classList.add('pm-via');
    setTimeout(function(){ card.classList.add('pm-chiuso'); setTimeout(function(){ if (card.classList.contains('pm-chiuso')) card.style.display = 'none'; }, 400); }, 420);
  }, 1000);
}

/* ---------- style, scoped with the lane prefix so it cannot collide ---------- */
(function(){
  const s = document.createElement('style');
  s.id = 'ue-perms-style';
  s.textContent = `
  #s15{overflow-x:hidden}
  #s15 .panelcard{transition:transform .42s cubic-bezier(.4,0,.2,1),opacity .42s,max-height .38s ease,margin .38s ease,padding .38s ease}
  #s15 .panelcard.pm-via{transform:translateX(115%);opacity:0}
  #s15 .panelcard.pm-chiuso{max-height:0!important;margin-top:0!important;margin-bottom:0!important;padding-top:0!important;padding-bottom:0!important;border-width:0!important;overflow:hidden}
  .ue-disc-badge{width:84px;height:84px;flex:none;margin:6px auto 0;border-radius:50%;
    background:linear-gradient(135deg,var(--blue),var(--blue-deep));display:grid;place-items:center;
    box-shadow:0 14px 34px rgba(0,117,227,.34)}
  .ue-disc-badge svg{width:40px;height:40px}
  .ue-disc-title{font:800 21px/1.24 var(--font-display);font-style:italic;color:var(--navy);
    text-align:center;margin:14px 0 8px}
  .ue-disc-intro{font:500 12.5px/1.62 var(--font-body);color:var(--muted);text-align:center;margin-bottom:4px}
  .ue-disc-card{background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);
    padding:15px 16px;box-shadow:var(--shadow);margin-top:14px}
  .ue-disc-h{display:block;font:700 13px var(--font-display);color:var(--navy);margin-bottom:8px}
  .ue-disc-list{list-style:none;margin:0;padding:0}
  .ue-disc-list li{position:relative;padding-left:18px;margin-bottom:9px;
    font:500 12px/1.6 var(--font-body);color:var(--muted)}
  .ue-disc-list li:last-child{margin-bottom:0}
  .ue-disc-list li::before{content:"";position:absolute;left:2px;top:7px;width:6px;height:6px;
    border-radius:50%;background:var(--blue)}
  .ue-disc-list b{color:var(--navy);font-weight:700}
  .ue-disc-priv{display:flex;gap:10px;align-items:flex-start;background:#E6F7EC;
    border:1px solid #BFE6CE;border-radius:14px;padding:13px;margin-top:12px;
    font:500 11.5px/1.6 var(--font-body);color:#14603A}
  .ue-disc-priv b{color:#0F4D2E}
  .ue-disc-privic{font-size:15px;line-height:1.2;flex:none}
  .ue-disc-revoke{font:500 11.5px/1.6 var(--font-body);color:var(--muted);margin-top:12px;text-align:center}
  .ue-disc-given{font:600 11.5px var(--font-body);color:var(--blue);text-align:center;margin-top:10px}
  .ue-linkbtn{border:0;background:none;padding:0;color:var(--red);font:700 11.5px var(--font-body);
    text-decoration:underline;cursor:pointer}

  .ue-rom-title{font:800 21px/1.24 var(--font-display);font-style:italic;color:var(--navy);
    text-align:center;margin:8px 0 8px}
  .ue-rom-sub{font:500 12.5px/1.6 var(--font-body);color:var(--muted);text-align:center}
  .ue-chips{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin:14px 0 4px}
  .ue-chip{border:1px solid var(--line);background:#fff;border-radius:99px;padding:7px 13px;
    font:700 11px var(--font-body);color:var(--muted);cursor:pointer}
  .ue-chip.on{background:var(--blue);border-color:var(--blue);color:#fff}
  .ue-steps{padding-block:14px}
  .ue-step{display:flex;gap:11px;align-items:flex-start;margin-bottom:13px}
  .ue-step:last-child{margin-bottom:0}
  .ue-stepn{flex:0 0 24px;height:24px;border-radius:50%;background:var(--blue);color:#fff;
    font:800 12px var(--font-body);display:grid;place-items:center}
  .ue-step b{font:700 13px var(--font-display);color:var(--navy)}
  .ue-step p{font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin:3px 0 0}
  .ue-rom-note{font:500 11.5px/1.6 var(--font-body);color:var(--muted);text-align:center;margin-top:12px}

  .ue-permcard b{font:700 14px var(--font-display);color:var(--navy)}
  .ue-permcard p{font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin:4px 0 10px}
  .ue-permbtn{padding:11px 26px;font-size:13px;width:auto}
  .ue-tagi{font:700 10px var(--font-body);color:var(--blue);background:var(--blue-soft);
    border-radius:99px;padding:2px 8px;margin-left:4px;vertical-align:middle}
  .ue-tagi.red{color:var(--red);background:var(--red-soft)}
  `;
  document.head.appendChild(s);
})();

/* ---------- mount ---------- */
registerScreen('s-a11y-disclosure', A11Y_DISCLOSURE_HTML, {back: () => a11yFrom || 's15'});
registerScreen('s-romguide',        ROM_GUIDE_HTML,        {back: () => romGuideFrom || 's15'});
mountExtraPermCards();

/* An explicit way out of s15 for someone who will not, or cannot, grant the service. The ✕ in
   the corner already did this, but unlabelled: a user who reads "the button unlocks when the
   service is really active" and cannot activate it has, as far as they can tell, hit a wall
   (G88). refreshPerms() hides it again the moment the service reports on. */
(function(){
  const s15 = document.getElementById('s15');
  if(!s15 || document.getElementById('ue-perms-skip')) return;
  const b = document.createElement('button');
  b.className = 'ghost';
  b.id = 'ue-perms-skip';
  b.textContent = 'Lo farò più tardi';
  b.onclick = function(){ toast('Puoi attivarlo quando vuoi dal Profilo'); if (!(typeof inDopoPermessi === 'function' && inDopoPermessi())) go(16); };
  s15.appendChild(b);
})();
