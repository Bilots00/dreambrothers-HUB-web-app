/* ===========================================================================================
   AMBIENTE, AZIONE E IDENTITA' (0.9.354): le prime tre schede del pannello mini "Le statistiche della
   partita", nella scheda Identita' di "Il tuo viaggio" (rotta-tab.js, #pstBoxMini di partita-stats.js).

   Andrea: "Ambiente | Azione | Identita' | Riepilogo | +. Prima l'ambiente, poi le azioni, e l'identita'
   come conseguenza delle due". partita-stats.js disegna le linguette e chiama qui il corpo della scheda.

   AMBIENTE. I luoghi in cui la persona passa il tempo, come le card di "Per te" in START (preset.js): foto
   dalla galleria (lato lungo 720 px, JPEG, come csImmagineDato), nome, tempo indicativo (ore al giorno o al
   mese), persone e inneschi visivi scritti a mano, una nota breve. Si aggiungono e si cambiano in una pagina
   a schermo intero (s-ambiente). Le foto stanno in IndexedDB (fl_ambiente); nei dati resta solo il
   riferimento 'idb:<chiave>' (o 'ls:<chiave>' se IndexedDB non c'e'): localStorage non si riempie.
     fl_ambienti = [{ id, nome, ore, unita: 'giorno'|'mese', persone, inneschi, nota, img, at }]
   La card fissa "Il telefono" non si elimina: apre s-ambiente-tel, dove un'immagine del sogno va sul blocco
   schermo o come sfondo della Home (NATIVE.setWallpaperImage, SfondoFoto.java) e dove sta la stessa levetta
   "Frase del giorno sul blocco schermo" della pagina Ispirazione quotidiana (scores.js, scToggleLockQuote,
   #inspLockSw): qui si legge lo stato e si chiama la stessa funzione, cosi' le due levette dicono la stessa cosa.
     fl_ambiente_tel = { img, fonte: 'galleria'|'sogno', lockAt, homeAt }

   AZIONE. Con Premium: quello che ha notato il tuo agente personale (tlFrasiPremium della Timeline, i
   resoconti del ponte con le altre AI). Con il piano gratis: le app, i siti e le ricerche del periodo
   (getTopApps, getWebTime, la radiografia della Timeline). Ogni voce diventa un'azione scritta chiara, con
   un'emoji o una foto: un'abitudine da cambiare o una nuova azione.
     fl_azioni_id = [{ id, tipo: 'cambia'|'nuova', t, em, img, da: { tipo, nome }, at }]

   IDENTITA'. Tre sotto-schede: "Chi sono oggi" (fl_chi_sono_oggi = { frase, parole: [3], at }, scritta
   dalla persona), "Chi devo diventare" (la card passaporto della pagina "Il mio io futuro", dai dati di
   fl_iofuturo; tocca e si apre la pagina con nfNotion) e "Chi stai diventando": il pannello #scLife di
   scores.js, adottato vivo con data-adotta. Non sta piu' nel carosello della scheda Identita'.
   Prefisso psc-.
   =========================================================================================== */
const PSC_LUOGHI = 'fl_ambienti';
const PSC_TEL = 'fl_ambiente_tel';
const PSC_AZIONI = 'fl_azioni_id';
const PSC_OGGI = 'fl_chi_sono_oggi';
const PSC_SUB = 'fl_partita_io_sub';
const PSC_BOZZA = 'fl_ambiente_bozza';
const PSC = { url: {}, carica: {}, az: {}, azCarica: {}, azAtt: false, azFonti: [], bozza: null, azBozza: null, salva: false };

const PSC_SVG = {
  indietro: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
  info: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v7M12 6.5v.2"/></svg>',
  infoGrande: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.2"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  foto: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="12" cy="12.5" r="3.5"/><path d="M8.5 5l1.5-2h4l1.5 2"/></svg>'
};

function pscPremium(){
  try{ if (typeof ngPremium === 'function') return !!ngPremium(); }catch(_){ }
  try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; }
}
function pscToast(t){ try{ toast(t); }catch(_){ } }
function pscVibra(n){ try{ if (typeof flVibra === 'function') flVibra(n || 8); }catch(_){ } }
function pscInfoBtn(azione, nome){ return '<button type="button" class="psc-i" onclick="' + azione + '" aria-label="' + pstE(nome) + '">' + PSC_SVG.info + '</button>'; }
function pscOre(ms){
  const m = Math.round((ms || 0) / 60000);
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '');
}
function pscData(t){ const d = new Date(t); return d.getDate() + ' ' + ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()]; }
function pscNum(v, max, intero){
  let n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  if (!isFinite(n) || n < 0) n = 0;
  n = Math.min(max, n);
  return intero ? Math.round(n) : Math.round(n * 2) / 2;
}
function pscId(p){ return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
/** Ridisegna quello che si vede: il pannello mini e le pagine aperte. */
function pscRidisegna(){
  try{ if (typeof pstVisibile === 'function' && pstVisibile()) pstPaint(); }catch(_){ }
  try{ const a = document.getElementById('s-ambiente'); if (a && a.classList.contains('active')) pscLuogoPaint(); }catch(_){ }
  try{ const b = document.getElementById('s-ambiente-tel'); if (b && b.classList.contains('active')) pscTelPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LE IMMAGINI: in IndexedDB, mai in localStorage (le foto lo riempirebbero). In pagina si mostrano con un
   indirizzo blob:, corto, cosi' ridisegnare il pannello non si porta dietro centinaia di KB di testo.
   --------------------------------------------------------------------------------------- */
function pscDb(){
  return new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_ambiente', 1);
      r.onupgradeneeded = function(){ r.result.createObjectStore('img'); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ko(r.error); };
    }catch(e){ ko(e); }
  });
}
async function pscIdbPut(k, v){
  try{
    const db = await pscDb();
    await new Promise(function(ok, ko){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').put(v, k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ko(tx.error); }; tx.onabort = function(){ ko(tx.error); }; });
    return true;
  }catch(_){ return false; }
}
async function pscIdbGet(k){
  try{ const db = await pscDb(); return await new Promise(function(ok){ const tx = db.transaction('img', 'readonly'); const q = tx.objectStore('img').get(k); q.onsuccess = function(){ ok(q.result || null); }; q.onerror = function(){ ok(null); }; }); }catch(_){ return null; }
}
async function pscIdbDel(k){
  try{ const db = await pscDb(); await new Promise(function(ok){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').delete(k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ok(); }; }); }catch(_){ }
}
function pscBlob(dato){
  const m = /^data:([^;,]+)(;base64)?,(.*)$/.exec(String(dato || ''));
  if (!m) return null;
  const bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
  const a = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
  return new Blob([a], { type: m[1] });
}
function pscUrlDa(ref, dato){
  try{ const b = pscBlob(dato); PSC.url[ref] = b ? URL.createObjectURL(b) : dato; }catch(_){ PSC.url[ref] = dato; }
  return PSC.url[ref];
}
/** Salva un'immagine (data URL) e restituisce il riferimento da scrivere nei dati; '' se non c'e' posto. */
async function pscSalvaImg(k, dato, piccolo){
  if (!dato) return '';
  if (await pscIdbPut(k, dato)){ pscUrlDa('idb:' + k, dato); return 'idb:' + k; }
  const ls = 'fl_ambiente_img_' + k;
  try{ localStorage.setItem(ls, piccolo || dato); pscUrlDa('ls:' + ls, piccolo || dato); return 'ls:' + ls; }catch(_){ }
  return '';
}
/** L'indirizzo da mettere in pagina per un riferimento. Se e' in IndexedDB lo legge e poi ridisegna. */
function pscImgUrl(ref){
  if (!ref) return '';
  if (PSC.url[ref]) return PSC.url[ref];
  if (ref.indexOf('ls:') === 0){ let d = ''; try{ d = localStorage.getItem(ref.slice(3)) || ''; }catch(_){ } return d ? pscUrlDa(ref, d) : ''; }
  if (ref.indexOf('idb:') === 0){
    if (!PSC.carica[ref]){ PSC.carica[ref] = true; pscIdbGet(ref.slice(4)).then(function(d){ if (d){ pscUrlDa(ref, d); pscRidisegna(); } }); }
    return '';
  }
  return /^(img\/|data:image\/|https?:|blob:)/.test(ref) ? ref : '';
}
/** Il data URL di un riferimento (per il telefono, che vuole i byte). */
async function pscImgDato(ref){
  if (!ref) return '';
  if (ref.indexOf('idb:') === 0) return (await pscIdbGet(ref.slice(4))) || '';
  if (ref.indexOf('ls:') === 0){ try{ return localStorage.getItem(ref.slice(3)) || ''; }catch(_){ return ''; } }
  return '';
}
function pscImgVia(ref){
  if (!ref) return;
  try{ if (PSC.url[ref] && PSC.url[ref].indexOf('blob:') === 0) URL.revokeObjectURL(PSC.url[ref]); }catch(_){ }
  delete PSC.url[ref]; delete PSC.carica[ref];
  if (ref.indexOf('idb:') === 0) pscIdbDel(ref.slice(4));
  else if (ref.indexOf('ls:') === 0){ try{ localStorage.removeItem(ref.slice(3)); }catch(_){ } }
}
/* la galleria: l'input si crea, si tocca e si butta, dentro al tocco vero della persona */
function pscScegliFoto(dopo){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    pscLeggiFile(f).then(dopo).catch(function(){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); });
  });
  document.body.appendChild(inp);
  inp.click();
}
function pscLeggiFile(f){
  return new Promise(function(ok, ko){
    const fr = new FileReader();
    fr.onload = function(){ pscCaricaImg(fr.result).then(ok, ko); };
    fr.onerror = ko;
    fr.readAsDataURL(f);
  });
}
function pscCaricaImg(src){ return new Promise(function(ok, ko){ const img = new Image(); img.onload = function(){ ok(img); }; img.onerror = ko; img.src = src; }); }
function pscRiduci(img, lato, q){
  try{
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height; if (!w0 || !h0) return '';
    const k = Math.min(1, lato / Math.max(w0, h0));
    const c = document.createElement('canvas'); c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', q || .8);
  }catch(_){ return ''; }
}
/** Lato lungo 720 px, JPEG: la misura delle altre immagini dell'app (csImmagineDato, caveau-selezione.js). */
function pscPiccola(img){ return ((typeof csImmagineDato === 'function') ? csImmagineDato(img, 720) : '') || pscRiduci(img, 720, .72); }

/* ---------------------------------------------------------------------------------------
   AMBIENTE
   --------------------------------------------------------------------------------------- */
function pscLuoghi(){ const l = pstJ(PSC_LUOGHI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id; }) : []; }
function pscScriviLuoghi(l){ try{ localStorage.setItem(PSC_LUOGHI, JSON.stringify(l)); return true; }catch(_){ return false; } }
function pscTel(){ const t = pstJ(PSC_TEL, {}); return (t && typeof t === 'object' && !Array.isArray(t)) ? t : {}; }
function pscScriviTel(t){ try{ localStorage.setItem(PSC_TEL, JSON.stringify(t)); return true; }catch(_){ return false; } }
function pscTempoTxt(x){
  const n = +x.ore || 0;
  if (!n) return '';
  return String(n).replace('.', ',') + (n === 1 ? ' ora' : ' ore') + (x.unita === 'mese' ? ' al mese' : ' al giorno');
}
function pscLockAcceso(){ try{ return localStorage.getItem('fl_lockquote_on') === '1'; }catch(_){ return false; } }

/* 0.9.367, Andrea: "come le card della sezione Per te: cambiare l'emoji e lo sfondo della card (di serie la casa), o metterci la
   foto di una stanza". Gli sfondi sono i gradienti del brand */
const PSC_SFONDI = { blu: 'linear-gradient(160deg,#3F9FF4,#0075E3 45%,#001E44)', notte: 'linear-gradient(160deg,#0075E3,#001E44 70%)', rosso: 'linear-gradient(160deg,#E63946,#001E44 75%)', cielo: 'linear-gradient(160deg,#8CC6FF,#3F9FF4 55%,#0075E3)' };
const PSC_CASA_EMOJI = ['🏠', '🏡', '🛋️', '🛏️', '🪴', '🏢', '🧘', '📚'];
function pscCardHtml(o){
  const url = pscImgUrl(o.img);
  /* 0.9.363, Andrea: "con la copertina del sogno l'emoji del telefono sparisce e l'occhio non capisce che e' il telefono".
     Con la foto, l'emoji dell'ambiente resta in un pallino nell'angolo in alto a sinistra */
  const st = url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : (o.sfondo && PSC_SFONDI[o.sfondo] ? ' style="background:' + PSC_SFONDI[o.sfondo] + '"' : '');
  return '<button type="button"' + (o.id ? ' id="' + o.id + '"' : '') + ' class="psc-card' + (url ? ' foto' : '') + '"' + st + ' onclick="' + o.click + '" aria-label="' + pstE(o.nome) + '">'
    + (url ? '<span class="psc-card-ico" aria-hidden="true">' + o.art + '</span>' : '<span class="psc-card-art" aria-hidden="true">' + o.art + '</span>')
    + '<span class="psc-veil" aria-hidden="true"></span>'
    + '<span class="psc-card-txt"><b>' + pstE(o.nome) + '</b>'
    + o.righe.filter(Boolean).map(function(r){ return '<i>' + pstE(r) + '</i>'; }).join('')
    + (o.chips.length ? '<span class="psc-chips">' + o.chips.map(function(c){ return '<em>' + pstE(c) + '</em>'; }).join('') + '</span>' : '')
    + '</span></button>';
}
function pscAmbienteHtml(){
  const tel = pscTel(), l = pscLuoghi();
  /* 0.9.363, Andrea: "il badge Frase del giorno viene tagliato, e il badge Home sulla card del telefono non c'entra:
     la casa e' un'altra card". Il telefono resta pulito; le sue scelte stanno nella sua pagina */
  const telChips = [];
  return '<div class="psc-amb">'
    + '<div class="psc-testa"><p>I posti in cui passi il tempo decidono chi diventi.</p>' + pscInfoBtn('pscAmbInfo()', 'Come funziona l\'ambiente') + '</div>'
    + '<div class="psc-griglia">'
    + pscCardHtml({ click: 'pscTelApri()', img: tel.img, art: '📱', nome: 'Il telefono', righe: ['Ti segue ovunque'], chips: telChips })
    + pscCasaCardHtml()
    + l.map(function(x){
        const ch = [];
        if (x.persone || x.persone === 0) ch.push('👥 ' + x.persone + (x.persone === 1 ? ' persona' : ' persone'));
        if (x.inneschi || x.inneschi === 0) ch.push('✨ ' + x.inneschi + (x.inneschi === 1 ? ' innesco' : ' inneschi'));
        return pscCardHtml({ click: 'pscLuogoApri(' + pstA(x.id) + ')', img: x.img, art: '🏡', nome: x.nome, righe: [pscTempoTxt(x)], chips: ch });
      }).join('')
    + '<button type="button" class="psc-card psc-card-piu" onclick="pscLuogoApri(\'\')"><span class="psc-piu-ic">' + PST_ICO.piu + '</span><b>Aggiungi un luogo</b></button>'
    + '</div></div>';
}
/* ---------------------------------------------------------------------------------------
   CASA (0.9.363). Andrea: "una card Casa come preset, oltre al telefono: la camera da letto, la casa, dove segnare gli
   inneschi di quell'ambiente. Il tempo passato in casa si deduce da solo dal tempo connesso al Wi-Fi di casa".
   Il telefono si segna ogni rete a cui si connette (Conditions.setSsid, NATIVE.getWifiLog); qui si sceglie quale e' la
   rete di casa e si sommano le ore. fl_ambiente_casa = { ssid, inneschi, img }.
   --------------------------------------------------------------------------------------- */
const PSC_CASA = 'fl_ambiente_casa';
const PSC_WIFI = { log: null, current: '', permesso: true, at: 0, p: null };
function pscCasa(){ const c = pstJ(PSC_CASA, {}); return (c && typeof c === 'object' && !Array.isArray(c)) ? c : {}; }
function pscScriviCasa(c){ try{ localStorage.setItem(PSC_CASA, JSON.stringify(c)); return true; }catch(_){ return false; } }
function pscWifiCarica(forza){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getWifiLog) return Promise.resolve(null);
  if (PSC_WIFI.p) return PSC_WIFI.p;
  if (!forza && PSC_WIFI.log && Date.now() - PSC_WIFI.at < 60000) return Promise.resolve(PSC_WIFI);
  PSC_WIFI.p = NATIVE.getWifiLog({}).then(function(r){
    PSC_WIFI.log = (r && Array.isArray(r.log)) ? r.log : []; PSC_WIFI.current = (r && r.current) || ''; PSC_WIFI.permesso = !(r && r.permesso === false);
    PSC_WIFI.at = Date.now(); PSC_WIFI.p = null; pscCasaRinfresca(); return PSC_WIFI;
  }).catch(function(){ PSC_WIFI.p = null; return null; });
  return PSC_WIFI.p;
}
/* i millisecondi sulla rete di casa fra da e a */
function pscCasaMs(ssid, da, a){
  let ms = 0;
  (PSC_WIFI.log || []).forEach(function(x){ if (!x || x.s !== ssid) return; const s0 = Math.max(+x.a || 0, da), e0 = Math.min(+x.b || Date.now(), a); if (e0 > s0) ms += e0 - s0; });
  return ms;
}
function pscOreTxt(ms){ const m = Math.round(ms / 60000); if (m < 60) return m + (m === 1 ? ' minuto' : ' minuti'); const h = Math.floor(m / 60), r = m % 60; return h + (h === 1 ? ' ora' : ' ore') + (r ? ' e ' + r + ' min' : ''); }
function pscOreCorte(ms){ const m = Math.round(ms / 60000); if (m < 60) return m + ' min'; return Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm'; }
function pscCasaTempi(c){
  if (!c.ssid || !PSC_WIFI.log) return null;
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const oggi = pscCasaMs(c.ssid, d0.getTime(), Date.now());
  const da7 = d0.getTime() - 6 * 86400000;
  const tot7 = pscCasaMs(c.ssid, da7, Date.now());
  /* la media si fa sui giorni da quando il telefono la registra, non su sette giorni che non ha visto */
  const primo = (PSC_WIFI.log[0] && +PSC_WIFI.log[0].a) || Date.now();
  const giorni = Math.max(1, Math.min(7, Math.ceil((Date.now() - Math.max(da7, primo)) / 86400000)));
  return { oggi: oggi, media: tot7 / giorni };
}
function pscCasaCardHtml(){
  const c = pscCasa();
  try{ pscWifiCarica(false); }catch(_){ }
  const t = pscCasaTempi(c);
  /* 0.9.364, Andrea: "la card non deve parlare di Wi-Fi subito: solo una volta aperta". Sulla card il tempo, se c'e', o niente */
  const righe = [t && t.media >= 60000 ? pscOreTxt(t.media) + ' al giorno' : 'Dove passi più tempo'];
  const ch = [];
  if (c.persone || c.persone === 0) ch.push('👥 ' + c.persone + (c.persone === 1 ? ' persona' : ' persone'));
  if (c.inneschi || c.inneschi === 0) ch.push('✨ ' + c.inneschi + (c.inneschi === 1 ? ' innesco' : ' inneschi'));
  return pscCardHtml({ id: 'pscCasaCard', click: 'pscCasaApri()', img: c.img, art: c.emoji || '🏠', sfondo: c.sfondo || '', nome: 'Casa', righe: righe, chips: ch });
}
function pscCasaRinfresca(){
  const el = document.getElementById('pscCasaCard'); if (el){ const t = document.createElement('div'); t.innerHTML = pscCasaCardHtml(); if (t.firstElementChild) el.parentNode.replaceChild(t.firstElementChild, el); }
  if (PSC.bozza && PSC.bozza.casa && document.getElementById('pscLuogoBody')) pscLuogoPaint();
}
function pscCasaApri(ridisegna){
  /* 0.9.364, Andrea: "Casa deve essere una card come le altre: l'immagine della stanza in cui passo piu' tempo, le persone, gli
     inneschi. E il Wi-Fi si chiede solo dentro, spiegato bene: il tempo che passi li' si puo' contare da solo". La pagina e' quella
     dei luoghi (s-ambiente), con il blocco del tempo al posto di "Quanto tempo ci passi?" */
  if (ridisegna){ if (PSC.bozza && PSC.bozza.casa) pscLuogoPaint(); return; }
  pscVibra(6);
  const c = pscCasa();
  PSC.bozza = Object.assign({ id: 'casa', casa: true, nome: 'Casa', persone: '', inneschi: '', nota: '', img: '', emoji: '🏠', sfondo: '' }, c, { casa: true, nuova: '' });
  /* 0.9.367, Andrea: "la pagina della casa fa schifo: era meglio il popover, come quello dell'agente con le due frecce per allargarlo" */
  PSC.foglio = true;
  const pag = document.getElementById('pscLuogoBody'); if (pag) pag.innerHTML = '';
  /* 0.9.368, Andrea: "il pulsante per allargare e' piu' in basso della X, e a pagina intera tutto tocca il bordo destro: toglilo" */
  inSheet('<div class="en-foglio psc-casa-fg">'
    + '<button type="button" class="am-x" aria-label="Chiudi" onclick="PSC.foglio=false;inSheetChiudi()">✕</button><div id="pscLuogoSheet"></div></div>');
  pscLuogoPaint();
  pscWifiCarica(true);
}
const PSC_FRECCE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7"/></svg>';
function pscCasaGrande(){
  PSC.foglio = false;
  try{ inSheetChiudi(); }catch(_){ }
  goId('s-ambiente'); pscLuogoPaint();
  try{ const p = document.getElementById('s-ambiente'); if (p) p.scrollTop = 0; }catch(_){ }
}
function pscCasaEmoji(e){ if (!PSC.bozza) return; PSC.bozza.emoji = e; pscVibra(6); pscLuogoPaint(); }
function pscCasaSfondo(k){ if (!PSC.bozza) return; PSC.bozza.sfondo = k; PSC.bozza.nuova = ''; if (PSC.bozza.img){ PSC.bozza.togliImg = true; } pscVibra(6); pscLuogoPaint(); }
/* il blocco del tempo di Casa: spiegato come un servizio, non come un controllo */
function pscCasaTempoHtml(){
  const c = PSC.bozza || {}, nat = typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getWifiLog;
  const t = pscCasaTempi(c);
  let corpo;
  if (!nat) corpo = '<p class="psc-casa-p">Sul telefono il tempo che passi in casa si conta da solo, senza che tu lo debba segnare.</p>';
  else if (!c.ssid) corpo = '<p class="psc-casa-p">Invece di stimarlo tu, il tempo in casa si può contare da solo: quando il telefono è collegato alla rete di casa, sei a casa. Il conto resta sul telefono.</p>'
    + (!PSC_WIFI.permesso ? '<button type="button" class="en-cta psc-casa-go" onclick="pscCasaPermesso()">Conta il tempo da solo</button><small class="psc-casa-n2">Android chiede il permesso della posizione per dire il nome della rete.</small>'
      : PSC_WIFI.current ? '<button type="button" class="en-cta psc-casa-go" onclick="pscCasaRete()">Sono a casa adesso: conta da qui</button><small class="psc-casa-n2">Rete di adesso: ' + pstE(PSC_WIFI.current) + '</small>'
      : '<small class="psc-casa-n2">Quando sei a casa e il telefono è collegato alla tua rete, torna qui e tocca il pulsante.</small>');
  else {
    const primo = pscCasaInizio(c);
    corpo = '<div class="psc-casa-num"><div><b>' + (t ? pscOreCorte(t.oggi) : '—') + '</b><small>oggi</small></div><i></i><div><b>' + (t ? pscOreCorte(t.media) : '—') + '</b><small>al giorno, in media</small></div></div>'
      + (primo && Date.now() - primo < 86400000 ? '<small class="psc-casa-n2">Il conto è partito ' + pscQuando(primo) + ': domani il numero è quello di una giornata intera.</small>' : '')
      /* 0.9.367, Andrea: "Rete di casa: Vodafone attaccato ai numeri, e non si puo' cambiare". Una riga sua, con Cambia */
      + '<div class="psc-rete"><span aria-hidden="true">📶</span><div><small>Rete di casa</small><b>' + pstE(c.ssid) + '</b></div><button type="button" onclick="pscCasaReteCambia()">' + (PSC.reteApri ? 'Chiudi' : 'Cambia') + '</button></div>'
      + (PSC.reteApri ? '<div class="psc-reti">' + ((PSC.reti || []).length ? PSC.reti.map(function(n, i){ return '<button type="button" class="' + (n === c.ssid ? 'on' : '') + '" onclick="pscCasaReteScegli(' + i + ')"><span>' + pstE(n) + '</span>' + (n === PSC_WIFI.current ? '<small>collegato adesso</small>' : '') + '</button>'; }).join('') : '<p>Nessuna rete visibile adesso. Accendi il Wi-Fi e riprova.</p>') + '</div>' : '');
  }
  return '<div class="psc-campo"><label>Il tempo che passi a casa</label>' + corpo + '</div>';
}
/* da quando il telefono conta: la prima volta che ha visto la rete di casa */
function pscCasaInizio(c){ let p = 0; (PSC_WIFI.log || []).forEach(function(x){ if (x && x.s === c.ssid && (!p || +x.a < p)) p = +x.a; }); return p; }
function pscQuando(t){ const d = new Date(t), o = new Date(); const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); return (d.toDateString() === o.toDateString() ? 'oggi alle ' : 'ieri alle ') + hm; }
async function pscCasaSalva(){
  const b = PSC.bozza; if (!b || PSC.salva) return;
  PSC.salva = true;
  const c = pscCasa();
  let img = c.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('amb_casa_' + Date.now().toString(36), b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; }
    else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const vuoto = function(v){ return v === '' || v == null; };
  if (b.togliImg && !b.nuova){ if (img) pscImgVia(img); img = ''; }
  pscScriviCasa(Object.assign({}, c, { emoji: b.emoji || '🏠', sfondo: b.sfondo || '', img: img, ssid: b.ssid || c.ssid || '', persone: vuoto(b.persone) ? null : pscNum(b.persone, 9999, true), inneschi: vuoto(b.inneschi) ? null : pscNum(b.inneschi, 999, true), nota: String(b.nota || '').trim().slice(0, 120), at: Date.now() }));
  PSC.salva = false; PSC.bozza = null;
  pscVibra([10, 30, 10]); pscToast('Casa aggiornata');
  if (PSC.foglio){ PSC.foglio = false; try{ inSheetChiudi(); }catch(_){ } } else flIndietro();
  setTimeout(pscRidisegna, 60);
}
/* 0.9.368, Andrea: "Cambia diceva Sei gia' collegato a questa rete senza farmi scegliere fra quelle che l'app rileva". Cambia apre l'elenco
   dentro al foglio: la rete di adesso, quelle vicine e quelle gia' viste dal telefono */
async function pscCasaReteCambia(){
  PSC.reteApri = !PSC.reteApri;
  if (PSC.reteApri){
    let vicine = [];
    try{ if (typeof edEnsureLocation === 'function') await edEnsureLocation(false); const info = NATIVE && NATIVE.getWifiInfo ? await NATIVE.getWifiInfo() : null; vicine = (info && Array.isArray(info.networks)) ? info.networks.map(function(n){ return String((n && (n.ssid || n.name)) || n || '').trim(); }) : []; }catch(_){ vicine = []; }
    const viste = (PSC_WIFI.log || []).map(function(x){ return x && x.s; });
    const tutte = [PSC_WIFI.current].concat(vicine, viste).filter(function(x, i, l){ return x && x !== '<unknown ssid>' && l.indexOf(x) === i; }).slice(0, 12);
    PSC.reti = tutte;
  }
  pscVibra(6); pscLuogoPaint();
}
function pscCasaReteScegli(i){
  const n = (PSC.reti || [])[i]; if (!n) return;
  const c = pscCasa(); c.ssid = n; c.at = Date.now(); pscScriviCasa(c);
  if (PSC.bozza && PSC.bozza.casa) PSC.bozza.ssid = n;
  PSC.reteApri = false; pscVibra(10); pscToast('Rete di casa: ' + n); pscLuogoPaint();
}
function pscCasaRete(){
  if (!PSC_WIFI.current) return;
  const c = pscCasa(); c.ssid = PSC_WIFI.current; c.at = Date.now(); pscScriviCasa(c);
  if (PSC.bozza && PSC.bozza.casa) PSC.bozza.ssid = c.ssid;
  pscVibra(10); pscCasaRinfresca();
}
function pscCasaInneschi(d){ const c = pscCasa(); c.inneschi = Math.max(0, Math.min(99, (+c.inneschi || 0) + d)); pscScriviCasa(c); pscCasaRinfresca(); }
async function pscCasaPermesso(){
  try{ if (typeof edEnsureLocation === 'function') await edEnsureLocation(false); else if (NATIVE.requestLocationPermission) await NATIVE.requestLocationPermission({ background: false }); }catch(_){ }
  pscWifiCarica(true);
}
function pscAmbInfo(){
  pscVibra(6);
  /* 0.9.368, Andrea: "due emoji (la casa sul titolo e quella della slide) no: uno non vive per forza in una casa. Il titolo senza emoji,
     un'emoji per slide, e il carosello in un pannello scuro". E il link alla lezione sottolineato, che sembri toccabile */
  inSheet('<div class="en-foglio psc-fg psc-fg-amb"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il tuo ambiente</h3>'
    + flInfoRighe([
      ['👥', 'I luoghi ti cambiano', 'Le persone e le cose intorno a te spingono le tue scelte.'],
      ['⏱️', 'Conta il tempo', 'Più ore passi in un luogo, più quel luogo decide per te.'],
      ['✨', 'Gli inneschi visivi', 'Sono le immagini e gli oggetti che ti ricordano il sogno. Più ne vedi, più ci pensi.'],
      ['📱', 'Il telefono ti segue', 'Lo guardi tutto il giorno. Mettici un’immagine del sogno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button>'
    /* 0.9.357: la lezione dell'Academy sul cambiare stanza, il perché scientifico di questa scheda */
    + (typeof acApriLezione === 'function' ? '<button type="button" class="am-link psc-lez" onclick="inSheetChiudi();acApriLezione(\'focus\', \'Cambiare stanza per ricaricare la testa\')">Leggi la lezione sul cambiare stanza</button>' : '')
    + '</div>');
}

/* LA PAGINA DI UN LUOGO: nuovo o da cambiare. La bozza di un luogo nuovo resta salvata (senza la foto) finche' non lo salvi */
registerScreen('s-ambiente',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t" id="pscLuogoT">Il luogo</b><button class="iconbtn" onclick="pscAmbInfo()" aria-label="Come funziona l\'ambiente">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscLuogoBody"></div><div class="spacer"></div>', { back: function(){ return 's-home'; } });

function pscLuogoApri(id){
  const x = id ? pscLuoghi().filter(function(l){ return l.id === id; })[0] : null;
  if (id && !x) return;
  pscVibra(6);
  let bz = null; try{ bz = JSON.parse(localStorage.getItem(PSC_BOZZA) || 'null'); }catch(_){ bz = null; }
  PSC.bozza = x ? Object.assign({}, x) : ((bz && typeof bz === 'object') ? bz : { id: '', nome: '', ore: '', unita: 'giorno', persone: '', inneschi: '', nota: '', img: '' });
  PSC.bozza.nuova = '';
  goId('s-ambiente');
  pscLuogoPaint();
  try{ const p = document.getElementById('s-ambiente'); if (p) p.scrollTop = 0; }catch(_){ }
}
function pscBz(k, v){
  const b = PSC.bozza; if (!b) return;
  b[k] = v;
  if (!b.id){ try{ const c = Object.assign({}, b); delete c.nuova; localStorage.setItem(PSC_BOZZA, JSON.stringify(c)); }catch(_){ } }
}
function pscBzUnita(u){ pscBz('unita', u); pscVibra(6); pscLuogoPaint(); }
function pscCampo(id, lab, input, sotto){
  return '<div class="psc-campo"><label for="' + id + '">' + lab + '</label>' + (sotto ? '<small>' + sotto + '</small>' : '') + input + '</div>';
}
function pscLuogoPaint(){
  const box = document.getElementById(PSC.foglio && document.getElementById('pscLuogoSheet') ? 'pscLuogoSheet' : 'pscLuogoBody'), b = PSC.bozza; if (!box || !b) return;
  const t = document.getElementById('pscLuogoT'); if (t) t.textContent = b.casa ? 'Casa' : (b.id ? 'Il luogo' : 'Un luogo nuovo');
  /* 0.9.364, Andrea: "al centro fra - e + voglio poter toccare il numero e scriverlo, se non ho voglia di toccare 22 volte il +". E i
     colori di - e + come nelle altre sezioni (md-step: bordo sottile, sfondo trasparente) */
  const step = function(id, k, max){ const v = b[k] === '' || b[k] == null ? '' : String(b[k]);
    return '<div class="md-step psc-step"><button type="button" onclick="pscStep(\'' + id + '\',\'' + k + '\',-1,' + max + ')" aria-label="Meno">−</button>'
      + '<input class="psc-step-n" id="' + id + '" type="number" inputmode="numeric" min="0" max="' + max + '" placeholder="0" value="' + pstE(v) + '" oninput="pscBz(\'' + k + '\',this.value)">'
      + '<button type="button" onclick="pscStep(\'' + id + '\',\'' + k + '\',1,' + max + ')" aria-label="Più">+</button></div>'; };
  const url = b.nuova || pscImgUrl(b.img);
  const num = function(id, k, ph, max, passo){ return '<input class="fin psc-fin psc-n" id="' + id + '" type="number" inputmode="decimal" min="0" max="' + max + '" step="' + passo + '" placeholder="' + ph + '" value="' + pstE(b[k] === '' || b[k] == null ? '' : b[k]) + '" oninput="pscBz(\'' + k + '\',this.value)">'; };
  const urlVero = b.togliImg ? b.nuova : url;
  const testa = b.casa
    ? '<div class="psc-casa-testa"><div class="psc-casa-anteprima' + (urlVero ? ' foto' : '') + '" style="' + (urlVero ? 'background-image:url(\'' + String(urlVero).replace(/['()\\]/g, '') + '\')' : 'background:' + (PSC_SFONDI[b.sfondo] || PSC_SFONDI.blu)) + '"><span>' + (b.emoji || '🏠') + '</span><b>Casa</b></div>'
      + '<p class="psc-casa-l">Emoji</p><div class="psc-casa-emo">' + PSC_CASA_EMOJI.map(function(e){ return '<button type="button" class="' + ((b.emoji || '🏠') === e ? 'on' : '') + '" onclick="pscCasaEmoji(\'' + e + '\')">' + e + '</button>'; }).join('') + '</div>'
      + '<p class="psc-casa-l">Sfondo</p><div class="psc-casa-sf">' + Object.keys(PSC_SFONDI).map(function(k){ return '<button type="button" aria-label="Sfondo ' + k + '" class="' + (!urlVero && (b.sfondo || 'blu') === k ? 'on' : '') + '" style="background:' + PSC_SFONDI[k] + '" onclick="pscCasaSfondo(\'' + k + '\')"></button>'; }).join('')
      + '<button type="button" class="psc-casa-foto' + (urlVero ? ' on' : '') + '" onclick="pscLuogoFoto()" aria-label="Una tua foto">' + PSC_SVG.foto + '</button></div></div>'
    : '<button type="button" class="psc-foto' + (url ? ' piena' : '') + '" onclick="pscLuogoFoto()"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>'
      + (url ? '<span class="psc-foto-c">' + PSC_SVG.foto + 'Cambia la foto</span>' : '<span class="psc-foto-v">' + PSC_SVG.foto + '<b>Scegli una foto dalla galleria</b></span>')
    + '</button>';
  box.innerHTML = testa
    + (b.casa ? pscCasaTempoHtml() : pscCampo('pscNome', 'Come si chiama il luogo?', '<input class="fin psc-fin" id="pscNome" maxlength="40" placeholder="Per esempio, la mia camera" value="' + pstE(b.nome || '') + '" oninput="pscBz(\'nome\',this.value)">')
    + pscCampo('pscOre', 'Quanto tempo ci passi?', '<div class="psc-tempo">' + num('pscOre', 'ore', '0', b.unita === 'mese' ? 744 : 24, '0.5') + '<span class="psc-u">ore</span>'
      + '<div class="psc-unita" role="radiogroup" aria-label="Ogni quanto">' + [['giorno', 'al giorno'], ['mese', 'al mese']].map(function(u){ return '<button type="button" role="radio" aria-checked="' + (b.unita === u[0]) + '" class="' + (b.unita === u[0] ? 'on' : '') + '" onclick="pscBzUnita(\'' + u[0] + '\')">' + u[1] + '</button>'; }).join('') + '</div></div>',
      'Scegli "al mese" per un posto in cui vai di rado.'))
    + pscCampo('pscPersone', 'Quante persone ci sono di solito?', step('pscPersone', 'persone', 9999))
    + pscCampo('pscInneschi', 'Quanti inneschi visivi ci sono?', step('pscInneschi', 'inneschi', 999)
      + '<textarea class="fin psc-fin psc-nota-in" id="pscNota" rows="2" maxlength="120" placeholder="Una nota breve, se vuoi. Per esempio, la foto del mare sopra la scrivania" oninput="pscBz(\'nota\',this.value)">' + pstE(b.nota || '') + '</textarea>',
      'Conta le immagini e gli oggetti che ti ricordano il sogno.')
    + '<button type="button" class="en-cta psc-salva" onclick="' + (b.casa ? 'pscCasaSalva()' : 'pscLuogoSalva()') + '">' + (b.id ? 'Salva le modifiche' : 'Salva il luogo') + '</button>'
    + (b.id && !b.casa ? '<button type="button" class="psc-via" onclick="pscLuogoElimina()">Elimina il luogo</button>' : '');
}
function pscStep(id, k, d, max){
  const i = document.getElementById(id); const v = Math.max(0, Math.min(max, (parseInt(i && i.value, 10) || 0) + d));
  if (i) i.value = String(v); pscBz(k, String(v)); pscVibra(6);
}
function pscLuogoFoto(){
  pscScegliFoto(function(img){
    const d = pscPiccola(img);
    if (!d){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
    if (PSC.bozza){ PSC.bozza.nuova = d; PSC.bozza.togliImg = false; pscLuogoPaint(); }
  });
}
async function pscLuogoSalva(){
  const b = PSC.bozza; if (!b || PSC.salva) return;
  const nome = String(b.nome || '').trim().slice(0, 40);
  if (!nome){ pscToast('Scrivi il nome del luogo'); const n = document.getElementById('pscNome'); if (n) n.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('l');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('amb_' + id + '_' + Date.now().toString(36), b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; }
    else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const unita = b.unita === 'mese' ? 'mese' : 'giorno';
  const vuoto = function(v){ return v === '' || v == null; };
  const o = { id: id, nome: nome, ore: pscNum(b.ore, unita === 'mese' ? 744 : 24), unita: unita,
    persone: vuoto(b.persone) ? null : pscNum(b.persone, 9999, true), inneschi: vuoto(b.inneschi) ? null : pscNum(b.inneschi, 999, true),
    nota: String(b.nota || '').trim().slice(0, 120), img: img, at: Date.now() };
  const l = pscLuoghi(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviLuoghi(l)){ pscToast('La memoria del telefono è piena, il luogo non si salva'); return; }
  try{ localStorage.removeItem(PSC_BOZZA); }catch(_){ }
  PSC.bozza = null;
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Luogo aggiornato' : 'Luogo aggiunto al tuo ambiente');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}
async function pscLuogoElimina(){
  const b = PSC.bozza; if (!b || !b.id) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare "' + b.nome + '"?', 'Il luogo sparisce con la sua foto.', 'Elimina', true); }catch(_){ }
  if (!ok) return;
  pscScriviLuoghi(pscLuoghi().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.bozza = null;
  pscToast('Luogo eliminato');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}

/* IL TELEFONO: la card fissa. Un'immagine del sogno sul blocco schermo o sulla Home, e la frase del giorno */
registerScreen('s-ambiente-tel',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t">Il telefono</b><button class="iconbtn" onclick="pscTelInfo()" aria-label="Come funziona il telefono come innesco">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscTelBody"></div><div class="spacer"></div>', { back: function(){ return 's-home'; } });

function pscTelApri(){
  pscVibra(6);
  goId('s-ambiente-tel');
  pscTelPaint();
  pscLockSync().then(function(){ pscTelPaint(); });
}
/** L'immagine del sogno che l'app usa gia': la copertina della pagina del sogno (costruisci.js), foto o immagine scelta. */
function pscImgSogno(){
  try{
    if (typeof cstCfg === 'function'){
      const c = String(cstCfg().cover || '');
      if (c === 'mia'){ const d = localStorage.getItem('fl_mappa_cover_img') || ''; if (d) return d; }
      else if (/^img\//.test(c)) return c;
    }
  }catch(_){ }
  return '';
}
function pscTelPaint(){
  const box = document.getElementById('pscTelBody'); if (!box) return;
  const t = pscTel(), url = pscImgUrl(t.img), sogno = pscImgSogno(), prem = pscPremium(), q = pscLockAcceso();
  const tile = function(k, ico, txt, at){
    return '<button type="button" class="psc-tile' + (url ? '' : ' spento') + '" onclick="pscTelMetti(\'' + k + '\')"><span aria-hidden="true">' + ico + '</span><b>' + txt + '</b>' + (at ? '<small>Messa il ' + pscData(at) + '</small>' : '') + '</button>';
  };
  box.innerHTML = '<div class="psc-tel-prev"><div class="psc-tel-schermo"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : '<span aria-hidden="true">📱</span>') + '</div></div>'
    + '<p class="psc-tel-p">' + (url ? 'Guarda questa immagine ogni volta che prendi il telefono.' : 'Scegli un’immagine che ti ricorda il sogno.') + '</p>'
    + '<div class="psc-fonti"><button type="button" onclick="pscTelGalleria()">🖼️ Scegli dalla galleria</button>'
    + (sogno ? '<button type="button" onclick="pscTelSogno()">🎯 Usa la copertina del sogno</button>' : '') + '</div>'
    + '<section class="psc-blocco"><p class="psc-k">Dove la metti</p><div class="psc-tiles">' + tile('lock', '🔒', 'Metti sul blocco schermo', t.lockAt) + tile('home', '🏠', 'Metti come sfondo della Home', t.homeAt) + '</div>'
    + (q ? '<p class="psc-avviso">💬 La frase del giorno è accesa.<br>Domani coprirà la foto sul blocco schermo.</p>' : '') + '</section>'
    + '<section class="psc-blocco"><div class="psc-riga-sw' + (prem ? '' : ' chiusa') + '"' + (prem ? '' : ' role="button" tabindex="0" onclick="pscLockToggle()"') + '>'
    + '<div><b>Frase del giorno sul blocco schermo</b><small>Ogni giorno una frase nuova sul blocco schermo.</small>' + (prem ? '' : '<span class="psc-prem">⭐ Premium</span>') + '</div>'
    + (prem ? '<button type="button" class="switch' + (q ? ' on' : '') + '" id="pscLockSw" role="switch" aria-checked="' + q + '" aria-label="Frase del giorno sul blocco schermo" onclick="pscLockToggle()"></button>'
      : '<span class="switch psc-sw-chiuso" aria-hidden="true"></span>')
    + '</div></section>';
}
function pscTelInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il telefono come innesco</h3>'
    + flInfoRighe([
      ['👀', 'Lo guardi sempre', 'Prendi il telefono decine di volte al giorno.'],
      ['🎯', 'Mettici il sogno', 'Ogni volta che lo sblocchi, l’immagine ti ricorda dove stai andando.'],
      ['💬', 'Oppure una frase', 'Con Premium il blocco schermo mostra una frase nuova ogni giorno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/** Un'immagine nuova per il telefono: lato lungo 1600 px, per non vederla sgranata sullo schermo intero. */
async function pscTelImposta(dato, fonte){
  if (!dato){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
  const t = pscTel(), prima = t.img;
  const ref = await pscSalvaImg('tel_' + Date.now().toString(36), dato);
  if (!ref){ pscToast('La memoria del telefono è piena, l’immagine non si salva'); return; }
  t.img = ref; t.fonte = fonte; t.lockAt = 0; t.homeAt = 0; t.at = Date.now();
  if (!pscScriviTel(t)){ pscImgVia(ref); pscToast('La memoria del telefono è piena, l’immagine non si salva'); return; }
  if (prima && prima !== ref) pscImgVia(prima);
  pscVibra(8);
  pscTelPaint();
  pscRidisegna();
}
function pscTelGalleria(){ pscScegliFoto(function(img){ pscTelImposta(pscRiduci(img, 1600, .86), 'galleria'); }); }
async function pscTelSogno(){
  const src = pscImgSogno(); if (!src) return;
  try{ const img = await pscCaricaImg(src); await pscTelImposta(pscRiduci(img, 1600, .86), 'sogno'); }
  catch(_){ pscToast('Non riesco a leggere la copertina del sogno'); }
}
function pscErr(e){
  const m = String((e && (e.message || e.errorMessage)) || '');
  if (/not implemented|unimplemented/i.test(m) || (e && e.code === 'UNIMPLEMENTED')) return 'Aggiorna l’app per mettere lo sfondo';
  return m || 'Non riuscito, riprova fra poco';
}
async function pscTelMetti(target){
  const t = pscTel();
  if (!t.img){ pscToast('Scegli prima un’immagine'); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setWallpaperImage){ pscToast('Disponibile nell\'app installata'); return; }
  if (target === 'lock' && await pscLockSync()){ pscTelAvviso(); return; }
  await pscTelApplica(target);
}
/* 0.9.354: la frase del giorno ridisegna il blocco schermo ogni giorno e domani coprirebbe la foto. Si chiede prima */
function pscTelAvviso(){
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">💬</span><h3>La frase del giorno è accesa</h3>'
    + '<p class="psc-fg-p">Domani la frase coprirà la tua foto sul blocco schermo.</p>'
    + '<button type="button" class="en-cta" onclick="pscTelSpegniEMetti()">Spegni la frase e metti la foto</button>'
    + '<button type="button" class="psc-fg-2" onclick="inSheetChiudi();pscTelApplica(\'lock\')">Metti la foto e tieni la frase</button></div>');
}
async function pscTelSpegniEMetti(){
  inSheetChiudi();
  if (await pscLockSync() && typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  await pscTelApplica('lock');
}
async function pscTelApplica(target){
  const t = pscTel();
  const dato = await pscImgDato(t.img);
  if (!dato){ pscToast('Non trovo l’immagine, sceglila di nuovo'); return; }
  try{ await NATIVE.setWallpaperImage({ data: dato, target: target }); }
  catch(e){ pscToast(pscErr(e)); return; }
  const n = pscTel(); n[target === 'lock' ? 'lockAt' : 'homeAt'] = Date.now(); pscScriviTel(n);
  pscVibra([10, 30, 10]);
  pscToast(target === 'lock' ? 'Fatto, guarda il blocco schermo' : 'Fatto, guarda la Home');
  pscTelPaint();
  pscRidisegna();
}
/* LA FRASE DEL GIORNO: lo stato vero lo sa il telefono (getLockQuote). Si copia sulle due levette, poi si usa la stessa funzione */
async function pscLockSync(){
  let on = pscLockAcceso();
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getLockQuote){ const st = await NATIVE.getLockQuote(); on = !!(st && st.on); try{ if (on) localStorage.setItem('fl_lockquote_on', '1'); else localStorage.removeItem('fl_lockquote_on'); }catch(_){ } } }catch(_){ }
  const a = document.getElementById('inspLockSw'); if (a) a.className = 'switch' + (on ? ' on' : '');
  const b = document.getElementById('pscLockSw'); if (b){ b.className = 'switch' + (on ? ' on' : ''); b.setAttribute('aria-checked', String(on)); }
  return on;
}
async function pscLockToggle(){
  if (!pscPremium()){ if (typeof pfApri === 'function') pfApri(); return; }
  await pscLockSync();
  if (typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  pscTelPaint();
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   AZIONE
   --------------------------------------------------------------------------------------- */
function pscAzioni(){ const l = pstJ(PSC_AZIONI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id && x.t; }) : []; }
function pscScriviAzioni(l){ try{ localStorage.setItem(PSC_AZIONI, JSON.stringify(l)); return true; }catch(_){ return false; } }
async function pscAzCarica(per){
  if (PSC.azCarica[per]) return;
  PSC.azCarica[per] = true;
  const F = pstFinestra(per), out = { at: Date.now(), apps: [], siti: [], ricerche: [], frasi: [], browser: false };
  if (typeof NATIVE === 'undefined' || !NATIVE) out.browser = true;
  else {
    try{
      if (NATIVE.getTopApps){
        const r = await NATIVE.getTopApps({ from: F.da, to: F.a, limit: 12, icons: 8 });
        out.apps = ((r && r.apps) || []).filter(function(a){ const p = String(a && a.packageName || ''); return a && (a.ms || 0) >= 60000 && p.indexOf('com.dreambrothers') !== 0 && !(typeof tlLauncher === 'function' && tlLauncher(p)); }).slice(0, 4);
      }
    }catch(_){ }
    try{
      if (NATIVE.getWebTime){ const w = await NATIVE.getWebTime({ from: F.da, to: F.a, bucket: 'none', limit: 4 }); out.siti = ((w && w.sites) || []).filter(function(s){ return s && s.host; }).slice(0, 3); }
    }catch(_){ }
    try{
      if (typeof tlRadioLeggi === 'function'){
        const r = await tlRadioLeggi(F.da, F.a), per0 = {};
        ((r && r.eventi) || []).forEach(function(e0){
          const e = (typeof tlRicercaVera === 'function') ? tlRicercaVera(e0) : e0;
          if (!e || e.tipo !== 'ricerca' || !e.cosa) return;
          const testo = String(e.cosa).trim(), k = testo.toLowerCase();
          if (k.length < 2) return;
          if (!per0[k]) per0[k] = { t: testo.slice(0, 60), n: 0, at: 0 };
          per0[k].n++; if (+e.t > per0[k].at) per0[k].at = +e.t;
        });
        out.ricerche = Object.keys(per0).map(function(k){ return per0[k]; }).sort(function(a, b){ return b.n - a.n || b.at - a.at; }).slice(0, 4);
      }
    }catch(_){ }
  }
  if (pscPremium()){
    try{
      const r = (typeof tlRiassuntoDi === 'function') ? await tlRiassuntoDi(0) : null;
      out.frasi = (typeof tlFrasiPremium === 'function') ? (tlFrasiPremium(r || ((typeof tlRiassunto === 'function') ? tlRiassunto(null) : {}), 0) || []).slice(0, 3) : [];
    }catch(_){ out.frasi = []; }
    try{ if (typeof pntSync === 'function') await pntSync(false); }catch(_){ }
  }
  PSC.az[per] = out; PSC.azCarica[per] = false;
  pscRidisegna();
}
function pscAzioneHtml(){
  const per = PST.per, d = PSC.az[per];
  if (!d || Date.now() - d.at > 60000) pscAzCarica(per);
  const prem = pscPremium();
  return '<div class="psc-az">' + ((prem && !PSC.azAtt) ? pscAgenteHtml(d, per) : pscAttivitaHtml(d, per)) + pscAzioniListaHtml() + '</div>';
}
function pscPerGiro(){ const l = [1, 7, 30]; PST.per = l[(l.indexOf(PST.per) + 1) % 3]; try{ pstSalvaVista(); }catch(_){ } pscVibra(6); pstPaint(); }
function pscQuando(per){ return per === 1 ? 'oggi' : (per === 7 ? 'negli ultimi 7 giorni' : 'negli ultimi 30 giorni'); }
/* PREMIUM: quello che ha notato il tuo agente personale (gli stessi pattern del Riepilogo della Timeline) */
function pscAgenteHtml(d, per){
  const frasi = (d && d.frasi) || [];
  let ponte = '';
  try{
    if (typeof pntOn === 'function' && pntOn() && typeof pntVoci === 'function'){
      const F = pstFinestra(per), v = pntVoci().filter(function(x){ return x && x.at >= F.da && x.testo; });
      if (v.length) ponte = '<div class="psc-ponte"><span aria-hidden="true">🤝</span><p>Le tue AI hanno scritto ' + v.length + (v.length === 1 ? ' resoconto' : ' resoconti') + ' ' + pscQuando(per) + '.<small>' + pstE(String(v[0].testo).slice(0, 110)) + '</small></p></div>';
    }
  }catch(_){ }
  return '<div class="psc-ag"><div class="tls-genio"><img src="img/genio/genio-pensa.png" alt=""><span>Il tuo agente personale ha notato</span></div>'
    + (!d ? '<p class="pst-nota">Il tuo agente personale sta leggendo la giornata.</p>'
      : (frasi.length ? '<ul class="tls-punti">' + frasi.map(function(f){ return '<li><span class="tls-em">' + f.ico + '</span><span>' + f.html + '</span></li>'; }).join('') + '</ul>'
        : '<p class="pst-nota">Il tuo agente personale ha ancora pochi dati. Torna dopo aver usato il telefono un po’ di più.</p>'))
    + ponte
    /* 0.9.369, Andrea: "un po' a sinistra un po' al centro, e Chiedi al tuo agente non sembra un pulsante". Tutto al centro: il pulsante pieno,
       il secondario sottolineato */
    + '<button type="button" class="pst-cta psc-az-cta" onclick="pscAgChat()">' + PST_ICO.chat + '<span>Chiedi al tuo agente personale</span></button>'
    + '<button type="button" class="psc-az-link" onclick="pscAzAttivita(true)">Trasforma le attività in abitudini</button></div>';
}
function pscAzAttivita(on){ PSC.azAtt = !!on; pscVibra(6); pstPaint(); }
async function pscAgChat(){
  let ok = false;
  try{ if (typeof agPopover === 'function') ok = await agPopover('', { titolo: 'Le mie azioni', pill: ['Quale abitudine mi allontana di più dal sogno?', 'Che azione nuova posso fare domani?'] }); }catch(_){ ok = false; }
  if (!ok && typeof agPopover !== 'function') pscToast('Il tuo agente personale non risponde adesso, riprova fra poco');
}
/* GRATIS (e Premium dal link): le app, i siti e le ricerche del periodo. Il + trasforma la voce in un'azione */
function pscAttivitaHtml(d, per){
  PSC.azFonti = [];
  /* 0.9.367: niente schede Oggi / 7 giorni / 30 giorni sopra: il periodo si cambia toccando la parola */
  const testa = '<div class="psc-testa"><p>Ecco cosa hai fatto <button type="button" class="psc-per-btn" onclick="pscPerGiro()">' + pscQuando(per) + ' <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>.</p>' + pscInfoBtn('pscAzInfo()', 'Come funzionano le azioni') + '</div>';
  const torna = pscPremium() ? '<button type="button" class="pst-link muto psc-torna" onclick="pscAzAttivita(false)">Torna al tuo agente personale</button>' : '';
  if (!d) return testa + '<p class="pst-nota">Sto leggendo le attività del telefono.</p>' + torna;
  if (d.browser) return testa + '<p class="pst-nota">Le attività del telefono si vedono nell’app installata.</p>' + torna;
  /* 0.9.371, Andrea: "la scheda Azione e' troppo diversa dal pannello Dove va la tua attenzione; l'interfaccia con il + va bene quando
     l'utente tocca il pulsante". Di serie le righe sono come quelle di Dove va la tua attenzione (icona, nome, barra, tempo); il + accanto
     a ogni riga compare solo dopo "Trasforma in un'azione" */
  const piu = !!PSC.azPiu;
  const riga = function(f, ico, nome, val, quota){
    const i = PSC.azFonti.push(f) - 1;
    if (!piu) return '<div class="psc-att psc-att-r"><span class="psc-att-i" aria-hidden="true">' + ico + '</span><span class="psc-att-n"><b>' + pstE(nome) + '</b><i class="psc-att-tr"><em style="width:' + Math.max(4, Math.round((quota || 0) * 100)) + '%"></em></i></span><b class="psc-att-v">' + pstE(val) + '</b></div>';
    return '<div class="psc-att"><span class="psc-att-i" aria-hidden="true">' + ico + '</span><span class="psc-att-n"><b>' + pstE(nome) + '</b><small>' + pstE(val) + '</small></span>'
      + '<button type="button" class="psc-att-piu" aria-label="Trasforma ' + pstE(nome) + ' in un’azione" onclick="pscAzNuova(' + i + ')">' + PST_ICO.piu + '</button></div>';
  };
  const maxA = Math.max(1, (d.apps || []).reduce(function(m, a){ return Math.max(m, a.ms || 0); }, 0));
  const maxS = Math.max(1, (d.siti || []).reduce(function(m, a){ return Math.max(m, a.ms || 0); }, 0));
  const maxR = Math.max(1, (d.ricerche || []).reduce(function(m, a){ return Math.max(m, a.n || 0); }, 0));
  const gruppo = function(tit, righe){ return righe.length ? '<div class="psc-gr"><p class="psc-gr-t">' + tit + '</p>' + righe.join('') + '</div>' : ''; };
  const app = d.apps.map(function(a){
    const nome = a.label || a.appName || String(a.packageName || '').split('.').pop();
    const ico = (a.icon && String(a.icon).indexOf('data:image') === 0) ? '<img src="' + a.icon + '" alt="">' : '📱';
    return riga({ tipo: 'app', nome: nome, val: pscOre(a.ms), em: '📱' }, ico, nome, pscOre(a.ms), (a.ms || 0) / maxA);
  });
  const siti = d.siti.map(function(s){ const h = String(s.host).replace(/^www\./, ''); return riga({ tipo: 'sito', nome: h, val: pscOre(s.ms), em: '🌐' }, '🌐', h, pscOre(s.ms), (s.ms || 0) / maxS); });
  const ric = d.ricerche.map(function(r){ const v = r.n === 1 ? 'Cercata 1 volta' : 'Cercata ' + r.n + ' volte'; return riga({ tipo: 'ricerca', nome: r.t, val: v, em: '🔎' }, '🔎', r.t, v, (r.n || 0) / maxR); });
  const tutto = gruppo('📱 App', app) + gruppo('🌐 Siti', siti) + gruppo('🔎 Ricerche', ric);
  const trasforma = !tutto ? '' : (piu
    ? '<p class="psc-att-hint">Tocca + accanto a quello che vuoi cambiare.</p><button type="button" class="psc-az-link" onclick="PSC.azPiu=false;pscVibra(6);pstPaint()">Fatto</button>'
    : '<button type="button" class="pst-cta psc-az-cta" onclick="PSC.azPiu=true;pscVibra(6);pstPaint()">' + PST_ICO.piu + '<span>Trasforma in un’azione</span></button>');
  return testa + (tutto || '<p class="pst-nota">Le app aperte le conta il telefono. Serve il permesso di utilizzo.</p>') + trasforma + torna;
}
function pscAzInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Le tue azioni</h3>'
    + flInfoRighe([
      ['📱', 'Il telefono conta', 'Vedi le app, i siti e le ricerche del periodo che scegli.'],
      ['✍️', 'Scrivi l’azione', 'Tocca + accanto a una voce e scrivi l’abitudine in modo chiaro.'],
      ['🔁', 'Cambia o comincia', 'Scegli un’abitudine da cambiare, oppure una nuova azione da fare.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pscAzioniListaHtml(){
  const l = pscAzioni();
  return '<section class="psc-blocco psc-azb"><p class="psc-k">Le tue azioni</p>'
    + (l.length ? '<div class="psc-azl">' + l.map(function(a){
        const url = pscImgUrl(a.img);
        return '<button type="button" class="psc-azr" onclick="pscAzModifica(' + pstA(a.id) + ')"><span class="psc-azr-e"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : pstE(a.em || '🎯')) + '</span>'
          + '<span class="psc-azr-t"><b>' + pstE(a.t) + '</b><small class="' + (a.tipo === 'cambia' ? 'cambia' : 'nuova') + '">' + (a.tipo === 'cambia' ? 'Da cambiare' : 'Nuova azione') + '</small></span></button>';
      }).join('') + '</div>'
      : '<p class="pst-nota psc-azv">Qui trovi le abitudini e le azioni che scrivi.</p>')
    + '<button type="button" class="psc-az-out" onclick="pscAzNuova(-1)">' + PST_ICO.piu + '<span>Scrivi un’azione</span></button></section>';
}
const PSC_EMOJI = ['📱', '📚', '🏃', '💧', '🧘', '✍️', '🌙', '🎯'];
function pscAzNuova(i){
  const f = (i >= 0 && PSC.azFonti[i]) ? PSC.azFonti[i] : null;
  PSC.azBozza = { id: '', tipo: f && f.tipo !== 'ricerca' ? 'cambia' : 'nuova', t: '', em: f ? f.em : '🎯', img: '', nuova: '', da: f ? { tipo: f.tipo, nome: f.nome, val: f.val } : null };
  pscVibra(6);
  pscAzFoglio();
}
function pscAzModifica(id){
  const a = pscAzioni().filter(function(x){ return x.id === id; })[0]; if (!a) return;
  PSC.azBozza = Object.assign({ nuova: '' }, a);
  pscVibra(6);
  pscAzFoglio();
}
function pscAzEsempio(b){
  const n = b.da && b.da.nome ? b.da.nome : '';
  if (b.tipo === 'cambia') return b.da && b.da.tipo === 'app' ? 'Per esempio, apro ' + n + ' a letto' : (b.da && b.da.tipo === 'sito' ? 'Per esempio, apro ' + n + ' appena mi siedo' : 'Per esempio, apro Instagram a letto');
  return 'Per esempio, leggo 10 pagine';
}
function pscAzFoglio(){
  const b = PSC.azBozza; if (!b) return;
  const url = b.nuova || pscImgUrl(b.img);
  inSheet('<div class="en-foglio psc-fg psc-azf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">⚡</span>'
    + '<h3>' + (b.id ? 'La tua azione' : 'Trasforma in un’azione') + '</h3>'
    + (b.da ? '<p class="psc-fg-da">' + pstE(b.da.nome) + ', ' + pstE(String(b.da.val || '').toLowerCase()) + '</p>' : '')
    + '<div class="psc-scelta" role="radiogroup" aria-label="Che tipo di azione">' + [['cambia', 'Un’abitudine da cambiare'], ['nuova', 'Una nuova azione']].map(function(x){
        return '<button type="button" role="radio" aria-checked="' + (b.tipo === x[0]) + '" class="' + (b.tipo === x[0] ? 'on ' : '') + x[0] + '" onclick="pscAzTipo(\'' + x[0] + '\')">' + x[1] + '</button>';
      }).join('') + '</div>'
    + '<label class="psc-lab" for="pscAzT">Scrivila in modo chiaro</label>'
    + '<input class="fin psc-fin" id="pscAzT" maxlength="80" placeholder="' + pstE(pscAzEsempio(b)) + '" value="' + pstE(b.t || '') + '" oninput="PSC.azBozza.t=this.value">'
    + '<label class="psc-lab">Scegli un’emoji o una foto</label>'
    + '<div class="psc-emoji">' + PSC_EMOJI.map(function(e){ return '<button type="button" class="' + (!url && b.em === e ? 'on' : '') + '" onclick="pscAzEmoji(\'' + e + '\')" aria-label="Emoji ' + e + '">' + e + '</button>'; }).join('')
    + '<button type="button" class="psc-emoji-foto' + (url ? ' on' : '') + '" onclick="pscAzFoto()" aria-label="Usa una foto"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : PSC_SVG.foto) + '</button></div>'
    + '<button type="button" class="en-cta psc-salva" onclick="pscAzSalva()">' + (b.id ? 'Salva le modifiche' : 'Salva l’azione') + '</button>'
    + (b.id ? '<button type="button" class="psc-via" onclick="pscAzElimina()">Elimina l’azione</button>' : '')
    + '</div>');
}
function pscAzLeggi(){ const i = document.getElementById('pscAzT'); if (i && PSC.azBozza) PSC.azBozza.t = i.value; }
function pscAzTipo(k){ pscAzLeggi(); PSC.azBozza.tipo = k; pscVibra(6); pscAzFoglio(); }
function pscAzEmoji(e){ pscAzLeggi(); const b = PSC.azBozza; b.em = e; b.nuova = ''; if (b.img){ b.imgVia = b.img; b.img = ''; } pscVibra(6); pscAzFoglio(); }
function pscAzFoto(){
  pscAzLeggi();
  pscScegliFoto(function(img){ const d = pscRiduci(img, 240, .8); if (!d || !PSC.azBozza) return; PSC.azBozza.nuova = d; pscAzFoglio(); });
}
async function pscAzSalva(){
  pscAzLeggi();
  const b = PSC.azBozza; if (!b || PSC.salva) return;
  const t = String(b.t || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  if (t.length < 3){ pscToast('Scrivi l’azione in modo chiaro'); const i = document.getElementById('pscAzT'); if (i) i.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('a');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('az_' + id + '_' + Date.now().toString(36), b.nuova, b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; } else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const o = { id: id, tipo: b.tipo === 'cambia' ? 'cambia' : 'nuova', t: t.charAt(0).toUpperCase() + t.slice(1), em: b.em || '🎯', img: img, da: b.da || null, at: Date.now() };
  const l = pscAzioni(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviAzioni(l)){ pscToast('La memoria del telefono è piena, l’azione non si salva'); return; }
  if (b.imgVia && b.imgVia !== img) pscImgVia(b.imgVia);
  PSC.azBozza = null;
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Azione aggiornata' : 'Azione salvata nelle tue azioni');
  pscRidisegna();
}
async function pscAzElimina(){
  const b = PSC.azBozza; if (!b || !b.id) return;
  inSheetChiudi();
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare questa azione?', '"' + b.t + '" sparisce dalle tue azioni.', 'Elimina', true); }catch(_){ }
  if (!ok){ pscAzFoglio(); return; }
  pscScriviAzioni(pscAzioni().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.azBozza = null;
  pscToast('Azione eliminata');
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   IDENTITA': chi sono oggi, chi devo diventare, chi stai diventando
   --------------------------------------------------------------------------------------- */
/* 0.9.367, Andrea: "Chi sei oggi dovrebbe essere come ti vedi, la tua self image. E due schede bastano: come ti vedi e chi devi
   diventare. Il pannello di chi stai diventando va dentro a come ti vedi, ma prima chiedi come si vede, con delle opzioni e la
   possibilita' di scrivere". "Chi stai diventando" non e' piu' una scheda: sta sotto all'immagine di te */
const PSC_IO = [['oggi', 'Chi stai diventando'], ['devo', 'Chi devi diventare']];
function pscIoSub(){ let v = ''; try{ v = localStorage.getItem(PSC_SUB) || ''; }catch(_){ } return PSC_IO.some(function(x){ return x[0] === v; }) ? v : 'oggi'; }
function pscIoVai(k){
  if (k === pscIoSub()) return;
  try{ localStorage.setItem(PSC_SUB, k); }catch(_){ }
  pscVibra(6);
  pstPaint();
  if (k === 'oggi'){ const el = document.getElementById('scLife'); if (el && !el.innerHTML.trim() && typeof scLifePaint === 'function'){ try{ scLifePaint(); }catch(_){ } } }
}
/* ---------------------------------------------------------------------------------------
   LA PANORAMICA: il triangolo dei tre pilastri (0.9.368). Ogni lato da 0 a 100, dai dati veri:
   - Ambiente: i luoghi descritti e gli inneschi visivi che ci hai messo;
   - Azione: i giorni con una tappa negli ultimi 7 e le azioni che hai scritto;
   - Identita': come ti vedi, il tuo Io Futuro, e quanto stai battendo il vecchio te negli ultimi 7 giorni.
   Il piu' basso e' "il numero sbagliato della combinazione": un tocco porta alla sua scheda.
   --------------------------------------------------------------------------------------- */
function pscTreValori(){
  const amb = (function(){
    const l = pscLuoghi().concat([pscCasa()]);
    let inn = 0, desc = 0;
    l.forEach(function(x){ const n = +x.inneschi || 0; inn += n; if (n > 0 || x.img || (x.persone || x.persone === 0)) desc++; });
    return Math.min(100, desc * 15 + inn * 4);
  })();
  const az = (function(){
    let g = 0;
    try{ const f = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; for (let i = 0; i < 7; i++){ const d = new Date(Date.now() - i * 86400000); const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); if (f[k]) g++; } }catch(_){ }
    return Math.min(100, Math.round(g / 7 * 70) + Math.min(30, pscAzioni().length * 10));
  })();
  const io = (function(){
    let v = pscOggi() ? 25 : 0;
    try{ const n = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : {}; if (n && n.identita && n.identita.identity_statement) v += 30; }catch(_){ }
    try{ if (typeof vtSomma === 'function'){ const p = vtSomma(Date.now() - 7 * 86400000, Date.now()); if (p.neo + p.old) v += Math.round(45 * p.neo / (p.neo + p.old)); } }catch(_){ }
    return Math.min(100, v);
  })();
  return { ambiente: amb, azione: az, io: io };
}
function pscTreHtml(){
  const v = pscTreValori();
  const nomi = { ambiente: 'Ambiente', azione: 'Azione', io: 'Identità' };
  const ord = ['io', 'azione', 'ambiente'].sort(function(a, b){ return v[a] - v[b]; });
  const basso = ord[0];
  /* il triangolo: tre assi a 90, 210 e 330 gradi dal centro (cx 110, cy 112, raggio 82) */
  const P = function(k, val){ const ang = { io: -90, azione: 150, ambiente: 30 }[k] * Math.PI / 180, r = 82 * Math.max(0.06, val / 100); return [110 + r * Math.cos(ang), 112 + r * Math.sin(ang)]; };
  const pt = function(k, val){ const p = P(k, val); return p[0].toFixed(1) + ',' + p[1].toFixed(1); };
  const pieno = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, 100); }).join(' ');
  const meta = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, 50); }).join(' ');
  const tuo = ['io', 'azione', 'ambiente'].map(function(k){ return pt(k, v[k]); }).join(' ');
  const eti = function(k, x, y, anc){ return '<text x="' + x + '" y="' + y + '" text-anchor="' + anc + '" class="psc-tre-l' + (k === basso ? ' basso' : '') + '">' + nomi[k] + ' ' + v[k] + '%</text>'; };
  const svg = '<svg class="psc-tre-svg" viewBox="0 0 220 210" role="img" aria-label="Ambiente ' + v.ambiente + '%, Azione ' + v.azione + '%, Identità ' + v.io + '%">'
    + '<polygon points="' + pieno + '" class="psc-tre-g"/><polygon points="' + meta + '" class="psc-tre-g2"/>'
    + '<polygon points="' + tuo + '" class="psc-tre-tu"/>'
    + ['io', 'azione', 'ambiente'].map(function(k){ const p = P(k, v[k]); return '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="5" class="psc-tre-p' + (k === basso ? ' basso' : '') + '"/>'; }).join('')
    + eti('io', 110, 18, 'middle') + eti('azione', 6, 200, 'start') + eti('ambiente', 214, 200, 'end') + '</svg>';
  const perche = { ambiente: 'I luoghi in cui passi il tempo non ti ricordano il sogno: è lì che il vecchio te ritorna.', azione: 'Sai chi vuoi diventare, ma i giorni passano senza tappe: l’identità si nutre di prove.', io: 'Fai le cose, ma dentro ti vedi ancora come prima: è così che si torna al punto di partenza.' }[basso];
  const vai = { ambiente: 'ambiente', azione: 'azione', io: 'io' }[basso];
  return '<div class="psc-pano">' + svg
    + '<p class="psc-pano-k">Il numero sbagliato della combinazione</p><b class="psc-pano-h">' + nomi[basso] + '</b>'
    + '<p class="psc-pano-p">' + perche + '</p>'
    + '<button type="button" class="pst-cta" onclick="pstVaiAai(\'' + vai + '\')">Lavora su ' + nomi[basso].toLowerCase().replace('identità', 'identità') + '</button></div>';
}
/* 0.9.369, Andrea: "le schede Come ti vedi e Chi devi diventare comparivano anche sopra al campionato; sotto al campionato mancavano le
   statistiche della partita; Come ti vedi e Chi stai diventando sono due cose diverse; il pannello di chi stai diventando era tagliato e
   ballava su e giu'". La scheda Identita' e' un carosello:
   1. il campionato in diretta, e sotto le statistiche della partita;
   2. come ti vedi (la tua carta, o la domanda del Genio);
   3. chi stai diventando adesso e chi devi diventare, con il selettore solo qui.
   Il carosello scorre solo di lato: in altezza segue la slide, niente che balla */
function pscIoHtml(){
  const cur = pscIoSub();
  let par = '';
  try{ if (typeof nvpPartitaSlideHtml === 'function') par = nvpPartitaSlideHtml() + (typeof nvpRiepilogoHtml === 'function' ? nvpRiepilogoHtml() : ''); }catch(_){ par = ''; }
  /* 0.9.371, Andrea: "hai messo la scheda Chi stai diventando quando c'e' gia' il pannello Stai diventando; quel pannello stava in una
     scheda che in realta' era Come ti vedi oggi". Niente piu' selettore dentro al carosello: la seconda slide e' come ti vedi oggi, con
     sotto il pannello Stai diventando; la terza e' chi devi diventare */
  void cur;
  let stai = '', devo = '';
  try{ stai = pscStaiHtml(); }catch(_){ stai = ''; }
  try{ devo = pscDevoHtml(); }catch(_){ devo = ''; }
  /* 0.9.372, Andrea: "il pannello Stai diventando doveva venire prima di Come ti vedi oggi: la seconda cosa dopo il campionato".
     Una slide per cosa: 1. il campionato con le statistiche, 2. stai diventando, 3. come ti vedi oggi, 4. chi devi diventare */
  const sl = [];
  if (par) sl.push('<div class="psc-io-s psc-io-par">' + par + '</div>');
  sl.push('<div class="psc-io-s">' + stai + '</div>');
  sl.push('<div class="psc-io-s"><p class="psc-io-k">Come ti vedi oggi</p>' + pscOggiHtml() + '</div>');
  sl.push('<div class="psc-io-s"><p class="psc-io-k">Chi devi diventare</p>' + devo + '</div>');
  const i0 = Math.max(0, Math.min(sl.length - 1, +PSC.ioSl || 0));
  return '<div class="psc-io"><div class="psc-io-car" data-no-swipe data-i="' + i0 + '"><div class="psc-io-tr" style="transform:translateX(-' + (i0 * 100) + '%)">' + sl.join('') + '</div></div>'
    + '<div class="psc-io-dots">' + sl.map(function(_, i){ return '<i' + (i === i0 ? ' class="on"' : '') + ' onclick="pscIoVaiSl(' + i + ')"></i>'; }).join('') + '</div></div>';
}
/* 0.9.372, Andrea: "nella scheda Identita', scorrendo su e giu', a volte si inceppa dentro al pannello". LA CAUSA: il carosello era una
   striscia che scorre di lato (overflow-x): il browser decideva a ogni gesto chi doveva scorrere, e a volte prendeva il carosello invece
   della pagina. Ora non scorre niente di lato: la striscia si sposta con transform, il dito di lato lo leggiamo noi (touch-action:pan-y),
   e il verticale e' SEMPRE della pagina. L'altezza segue la slide che si vede. */
function pscIoVaiSl(i, subito){
  const c = document.querySelector('.psc-io-car'); if (!c) return;
  const tr = c.querySelector('.psc-io-tr'); if (!tr) return;
  const n = tr.children.length; i = Math.max(0, Math.min(n - 1, i | 0));
  PSC.ioSl = i; c.setAttribute('data-i', i);
  if (subito) tr.style.transition = 'none';
  tr.style.transform = 'translateX(-' + (i * 100) + '%)';
  if (subito){ void tr.offsetWidth; tr.style.transition = ''; }
  const d = c.nextElementSibling; if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
  pscIoAltezza(c);
}
function pscIoAltezza(c){
  if (!c) return;
  const tr = c.querySelector('.psc-io-tr'); if (!tr) return;
  const s = tr.children[+c.getAttribute('data-i') || 0]; if (!s) return;
  const h = s.offsetHeight; if (h > 0 && Math.abs((parseFloat(c.style.height) || 0) - h) > 1) c.style.height = h + 'px';
  if (!c.__ro && typeof ResizeObserver !== 'undefined'){ c.__ro = new ResizeObserver(function(){ pscIoAltezza(c); }); Array.prototype.forEach.call(tr.children, function(x){ c.__ro.observe(x); }); }
}
setInterval(function(){ const c = document.querySelector('.psc-io-car'); if (c && c.offsetParent && !c.__ro) pscIoAltezza(c); }, 700);
(function(){
  let x0 = 0, y0 = 0, t0 = 0, car = null, lato = null;
  document.addEventListener('touchstart', function(e){ car = (e.touches.length === 1 && e.target.closest) ? e.target.closest('.psc-io-car') : null; if (!car) return; if (e.target.closest('.pst-anelli.sfoglia,input,textarea,[contenteditable]')){ car = null; return; } x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now(); lato = null; }, { passive: true });
  document.addEventListener('touchmove', function(e){ if (!car || lato) return; const dx = e.touches[0].clientX - x0, dy = e.touches[0].clientY - y0; if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return; lato = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'x' : 'y'; }, { passive: true });
  document.addEventListener('touchend', function(e){
    if (!car || lato !== 'x'){ car = null; return; }
    const p = (e.changedTouches || [])[0]; const c = car; car = null; if (!p) return;
    const dx = p.clientX - x0, v = Math.abs(dx) / Math.max(1, Date.now() - t0);
    if (Math.abs(dx) < 45 && !(Math.abs(dx) > 22 && v > 0.35)) return;
    pscIoVaiSl((+c.getAttribute('data-i') || 0) + (dx < 0 ? 1 : -1));
  }, { passive: true });
})();
function pscOggi(){ const o = pstJ(PSC_OGGI, null); return (o && typeof o === 'object') ? o : null; }
function pscOggiHtml(){
  const o = pscOggi();
  let av = ''; try{ av = localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
  const volto = '<span class="psc-oggi-v"' + (av ? ' style="background-image:url(\'' + String(av).replace(/['()\\]/g, '') + '\')"' : '') + ' aria-hidden="true">' + (av ? '' : '🙂') + '</span>';
  const parole = o && Array.isArray(o.parole) ? o.parole.filter(Boolean) : [];
  if (o && (o.frase || parole.length)){
    return '<div class="psc-oggi">' + volto + '<p class="psc-oggi-k">Ti vedi così</p>'
      + (o.frase ? '<p class="psc-oggi-f">"' + pstE(o.frase) + '"</p>' : '')
      + (parole.length ? '<div class="psc-parole">' + parole.map(function(p){ return '<em>' + pstE(p) + '</em>'; }).join('') + '</div>' : '')
      + '<button type="button" class="pst-link" onclick="pscOggiApri()">Cambia come ti vedi</button></div>';
  }
  return '<div class="psc-oggi">' + volto + '<b class="psc-oggi-h">Come ti vedi, oggi?</b><p class="psc-oggi-p">Prima di dirti chi stai diventando, il Genio vuole sapere come ti vedi tu.</p>'
    + '<button type="button" class="pst-cta" onclick="pscOggiApri()">Rispondi al Genio</button></div>';
}
/* 0.9.368, Andrea: "la domanda Come ti vedi va fatta dal Genio che parla, come nell'intro dell'onboarding, con le opzioni e le emoji,
   UNA domanda alla volta. Non deve essere il compitino della verifica a scuola". Scena del Genio (s-genio), modo 'vd':
   1. le sei risposte come carte con l'emoji, e "Lo dico io";
   2. solo se "Lo dico io": la casella;
   3. tre parole, facoltative ("Salta");
   4. il Genio ripete come ti vedi, e torna alla scheda Identita'. */
const PSC_VEDI = [['😴', 'Rimando le cose difficili'], ['🔁', 'Comincio e non finisco'], ['🏃', 'Lavoro tanto ma non avanzo'], ['📱', 'Mi distraggo facilmente'], ['🌱', 'Sto cambiando, piano piano'], ['🚀', 'Ce la sto facendo']];
const VD = { passo: 'scegli', frase: '', parole: '' };
function pscOggiApri(){
  if (typeof GN === 'undefined' || typeof gnVai !== 'function' || typeof GN_PASSI === 'undefined'){ pscToast('Il Genio non è pronto, riprova'); return; }
  const o = pscOggi() || {};
  VD.passo = 'scegli'; VD.frase = o.frase || ''; VD.parole = (Array.isArray(o.parole) ? o.parole : []).join(', '); VD.storia = [];
  GN.on = true; GN.modo = 'vd'; GN.audio = true; GN.storia = [];
  goId('s-genio');
  const t = document.getElementById('gnTop'); if (t) t.hidden = false;
  pscVdBarra();
  GN.step = ''; gnVai('vd');
}
function pscVdBarra(){
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = ({ scegli: 25, scrivo: 50, parole: 70, fine: 100 }[VD.passo] || 25) + '%';
  if (txt) txt.textContent = 'Come ti vedi';
}
function pscVdVai(p){ VD.storia.push(VD.passo); VD.passo = p; pscVdBarra(); GN.step = ''; gnVai('vd'); }
function pscVdIndietro(){ if (!VD.storia.length){ pscVdChiudi(); return true; } VD.passo = VD.storia.pop(); pscVdBarra(); GN.step = ''; gnVai('vd'); return true; }
function pscVdChiudi(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
  try{ PST.aaiTab = 'io'; localStorage.setItem(PSC_SUB, 'oggi'); }catch(_){ }
  setTimeout(function(){ try{ PSC.ioSl = 2; pstPaint(); pscIoVaiSl(2, true); }catch(_){ } }, 120);
}
function pscVdEntra(){
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo'); }
  const p = VD.passo;
  if (p === 'scegli'){
    gnDomanda('pensa', 'Dimmi la verità: come ti vedi, oggi?',
      '<div class="gn-carta"><div class="gn-cards">' + PSC_VEDI.map(function(o, i){ return '<button type="button" class="gn-card" onclick="event.stopPropagation();pscVdScegli(' + i + ')"><span>' + o[0] + '</span><b>' + pstE(o[1]) + '</b></button>'; }).join('') + '</div></div>'
      + '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();pscVdVai(\'scrivo\')">✍️ Lo dico io</button>');
    return;
  }
  if (p === 'scrivo'){
    gnDomanda('pensa', 'Dillo con parole tue.',
      '<textarea class="gn-area" id="pscVdF" rows="3" maxlength="140" placeholder="Per esempio, sono una persona che si arrende al primo ostacolo" oninput="VD.frase=this.value;document.getElementById(\'pscVdOk\').disabled=!this.value.trim()" onclick="event.stopPropagation()">' + pstE(PSC_VEDI.some(function(o){ return o[1] === VD.frase; }) ? '' : VD.frase) + '</textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a main" id="pscVdOk" disabled onclick="event.stopPropagation();pscVdVai(\'parole\')">Continua</button></div>');
    return;
  }
  if (p === 'parole'){
    gnDomanda('saluta', 'Ultima cosa: tre parole che ti descrivono?',
      '<input class="gn-area" id="pscVdP" maxlength="70" placeholder="Per esempio: curioso, testardo" value="' + pstE(VD.parole) + '" oninput="VD.parole=this.value" onclick="event.stopPropagation()">'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();pscVdSalva()">Continua</button>'
      + '<button type="button" class="or-a" onclick="event.stopPropagation();VD.parole=\'\';pscVdSalva()">Salta</button></div>');
    return;
  }
  if (p === 'fine'){
    gnDomanda('rivela', 'Ti vedi così: "' + VD.frase + '". Adesso guarda chi stai diventando.',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();pscVdChiudi()">Torna alla tua identità</button></div>');
  }
}
function pscVdScegli(i){ VD.frase = PSC_VEDI[i][1]; try{ gnAu.scelta(i % 4); }catch(_){ } pscVdVai('parole'); }
function pscVdSalva(){
  const frase = String(VD.frase || '').trim().replace(/\s+/g, ' ').slice(0, 140);
  const parole = String(VD.parole || '').split(/[,;\n]+/).map(function(x){ return x.trim().slice(0, 20); }).filter(Boolean).slice(0, 3);
  if (!frase){ VD.passo = 'scegli'; GN.step = ''; gnVai('vd'); return; }
  try{ localStorage.setItem(PSC_OGGI, JSON.stringify({ frase: frase, parole: parole, at: Date.now() })); }catch(_){ pscToast('La memoria del telefono è piena, non si salva'); return; }
  pscVdVai('fine');
}
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.vd = { entra: pscVdEntra };
  if (typeof gnChiudiTop === 'function'){ const v = gnChiudiTop; window.gnChiudiTop = gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'vd'){ pscVdChiudi(); return; } return v.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v2 = gnIndietro; window.gnIndietro = gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'vd') return pscVdIndietro(); return v2.apply(this, arguments); }; }
})();
function pscOggiSalva(){
  const f = document.getElementById('pscOggiF');
  const frase = String((f && f.value) || '').trim().replace(/\s+/g, ' ').slice(0, 140) || PSC.vedi || '';
  const pin = document.getElementById('pscOggiP');
  const parole = String((pin && pin.value) || '').split(/[,;\n]+/).map(function(x){ return x.trim().slice(0, 20); }).filter(Boolean).slice(0, 3);
  if (!frase && !parole.length){ pscToast('Scegli una risposta o scrivi come ti vedi'); return; }
  try{ localStorage.setItem(PSC_OGGI, JSON.stringify({ frase: frase, parole: parole, at: Date.now() })); }
  catch(_){ pscToast('La memoria del telefono è piena, non si salva'); return; }
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast('Salvato come ti vedi');
  pscRidisegna();
}
/* LA CARD PASSAPORTO: il riassunto della pagina "Il mio io futuro" della replica di Notion (nfNotion), dagli stessi dati */
function pscDevoHtml(){
  let o = {}; try{ o = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : (pstJ('fl_iofuturo', {}) || {}); }catch(_){ o = {}; }
  const id = o && o.identita;
  if (!id || !id.identity_statement){
    return '<div class="psc-oggi"><span class="psc-oggi-v" aria-hidden="true">🧭</span><b class="psc-oggi-h">Il tuo Io Futuro non c’è ancora</b><p class="psc-oggi-p">Scopri chi diventi quando arrivi al sogno.</p>'
      + '<button type="button" class="pst-cta" onclick="if(typeof nfApri===\'function\')nfApri(\'s-home\')">Scopri il tuo Io Futuro</button></div>';
  }
  let im = '', nome = '', sogno = '', data = '';
  try{ im = (typeof nfImmagine === 'function') ? nfImmagine() : ''; }catch(_){ }
  try{ const g = (typeof gnDati === 'function') ? gnDati() : null; nome = g && g.nome ? String(g.nome) : ''; }catch(_){ }
  if (!nome){ try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = u && u.name ? String(u.name) : ''; }catch(_){ } }
  try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  try{ data = (typeof nfDataArrivo === 'function') ? nfDataArrivo() : ''; }catch(_){ }
  const tratti = (Array.isArray(id.traits) ? id.traits : []).map(function(t){ return String(t || '').trim().replace(/[.;]+$/, ''); }).filter(Boolean).slice(0, 3);
  const campo = function(k, v){ return v ? '<small>' + k + '</small><b>' + pstE(v) + '</b>' : ''; };
  return '<button type="button" class="psc-pass" onclick="pscDevoApri()" aria-label="Apri la pagina Il mio io futuro">'
    + '<span class="psc-pass-top"><b>Il mio io futuro</b><i aria-hidden="true">✈️</i></span>'
    + '<span class="psc-pass-mid"><span class="psc-pass-foto"' + (im ? ' style="background-image:url(\'' + String(im).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (im ? '' : '<i aria-hidden="true">🧑‍🚀</i>') + '</span>'
    + '<span class="psc-pass-dati">' + campo('Nome', nome.split(' ')[0]) + campo('Destinazione', sogno) + campo('Arrivo previsto', data) + '</span></span>'
    + '<span class="psc-pass-id">' + pstE(String(id.identity_statement).slice(0, 180)) + '</span>'
    + (tratti.length ? '<span class="psc-pass-tr">' + tratti.map(function(t){ return '<em>' + pstE(t) + '</em>'; }).join('') + '</span>' : '')
    + '<span class="psc-pass-apri">Apri la pagina' + PSC_SVG.avanti + '</span>'
    + '</button>';
}
function pscDevoApri(){
  pscVibra(8);
  if (typeof nfNotion === 'function') nfNotion('s-home');
  else if (typeof nfApri === 'function') nfApri('s-home');
}
/* CHI STAI DIVENTANDO: il pannello vivo #scLife (scores.js), adottato qui. Se e' vuoto (nessun giorno misurato) parla la riga sotto */
function pscStaiHtml(){
  return '<div class="psc-life" data-adotta="scLife"></div><p class="psc-life-vuoto">Il Genio ti dice chi stai diventando dopo il primo giorno di misure.</p>';
}

(function(){
  const css = [
    /* --- dentro al pannello scuro (testo bianco fisso, uguale nei due temi) --- */
    '.psc-amb,.psc-az,.psc-io{display:flex;flex-direction:column;padding-top:8px}',
    '.psc-per-btn{border:0;background:rgba(140,198,255,.18);color:#C8EFFD;font:700 14px var(--font-body);padding:3px 10px;border-radius:99px;cursor:pointer;display:inline-flex;align-items:center;gap:4px}',
    '.psc-fg-amb h3{margin:6px 0 22px!important;text-align:center}.psc-fg-amb .fl-info-car{border-radius:22px;background:linear-gradient(160deg,#0075E3 0%,#001E44 78%)}',
    '.psc-fg-amb .fl-info-s{padding:30px 22px 26px}.psc-fg-amb .fl-info-s b{color:#fff!important}.psc-fg-amb .fl-info-s p{color:rgba(255,255,255,.86)!important}',
    '.psc-lez{text-decoration:underline;text-underline-offset:3px;color:#0075E3!important}body.dark .psc-lez{color:#8CC6FF!important}',
    '.psc-stai{margin-top:34px}.psc-oggi-k{margin:14px 0 0;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-vedi .psc-vedi-g{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:22px 0 6px}.psc-vedi-o{min-height:58px;padding:10px 12px;border-radius:16px;border:1.5px solid #C8EFFD;background:#F0FBFF;color:#001E44;font:700 14px/1.3 var(--font-body);cursor:pointer}.psc-vedi-o.on{border-color:#0075E3;background:#0075E3;color:#fff}body.dark .psc-vedi-o{background:#0E1D3D;border-color:#1F3A66;color:#fff}body.dark .psc-vedi-o.on{background:#0075E3;border-color:#0075E3}.psc-vedi .psc-lab{display:block;margin:26px 0 10px}.psc-vedi .psc-salva{margin-top:30px}',
    '.psc-testa{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 26px;text-align:center}.psc-testa p{margin:0;font:600 14px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.psc-i{flex:none;width:24px;height:24px;padding:0;border:0;border-radius:12px;background:rgba(140,198,255,.2);color:#C8EFFD;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-griglia{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-card{position:relative;min-width:0;aspect-ratio:3/4;border:0;padding:0;border-radius:20px;overflow:hidden;cursor:pointer;display:flex;align-items:flex-end;text-align:left;background:linear-gradient(160deg,#3F9FF4,#0075E3 45%,#001E44);background-size:cover;background-position:center;-webkit-tap-highlight-color:transparent}',
    '.psc-card:active{transform:scale(.98)}',
    /* l'emoji sta in alto, nel suo spazio: centrata a meta' card finiva sotto al nome quando il nome va su due righe */
    '.psc-card:not(.psc-card-piu){flex-direction:column;justify-content:space-between;align-items:stretch;aspect-ratio:auto;min-height:232px}.psc-card.foto{justify-content:flex-end}.psc-card-piu{aspect-ratio:auto;min-height:232px}.psc-card-art{position:relative;z-index:1;align-self:center;margin-top:20px;font-size:46px;line-height:1}',
    '.psc-veil{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 34%,rgba(0,30,68,.86))}',
    '.psc-card-txt{position:relative;display:flex;flex-direction:column;gap:3px;padding:12px;width:100%;box-sizing:border-box;min-width:0}',
    '.psc-card-txt b{font:800 16px/1.2 var(--font-display);color:#fff;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:break-word}',
    '.psc-card-txt i{font:600 12px/1.3 var(--font-body);font-style:normal;color:#C8EFFD}',
    '.psc-card-ico{position:absolute;top:10px;left:10px;z-index:2;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;background:rgba(255,255,255,.92);box-shadow:0 3px 10px rgba(0,0,0,.25)}',
    '.psc-casa-p{margin:0 0 22px;text-align:center;font:500 15px/1.5 var(--font-body);color:var(--muted)}.psc-casa-p b{color:var(--navy)}body.dark .psc-casa-p b{color:#fff}',
    '.psc-casa-n{display:flex;align-items:center;gap:16px;margin:4px 0 26px}.psc-casa-n > div{flex:1;text-align:center}.psc-casa-n b{display:block;font:900 22px/1.2 var(--font-display);color:#0075E3}.psc-casa-n small{display:block;margin-top:6px;font:600 12.5px var(--font-body);color:var(--muted)}.psc-casa-n i{width:1px;height:40px;background:var(--line)}body.dark .psc-casa-n b{color:#8CC6FF}',
    '.psc-casa-inn{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 18px;padding:14px 16px;border-radius:16px;background:var(--bg,#F0FBFF);border:1px solid var(--line)}.psc-casa-inn span{font:700 14.5px var(--font-body);color:var(--navy)}.psc-casa-inn div{display:flex;align-items:center;gap:12px}.psc-casa-inn button{width:34px;height:34px;border-radius:50%;border:0;background:#0075E3;color:#fff;font:800 18px/1 var(--font-body);cursor:pointer}.psc-casa-inn b{min-width:22px;text-align:center;font:800 17px var(--font-body);color:var(--navy)}body.dark .psc-casa-inn{background:#12203A;border-color:#22345A}body.dark .psc-casa-inn span,body.dark .psc-casa-inn b{color:#fff}',
    '.psc-step{gap:12px}.psc-step-n{width:76px;height:44px;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);color:var(--navy);text-align:center;font:800 18px var(--font-display);-moz-appearance:textfield}.psc-step-n::-webkit-inner-spin-button,.psc-step-n::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.psc-step button{width:40px;height:40px;border-radius:20px}body.dark .psc-step-n{background:#141C2C;color:#fff;border-color:#25314A}',
    '.psc-casa-go{margin-top:4px}.psc-casa-n2{display:block;margin-top:10px;font:500 13px/1.45 var(--font-body);color:var(--muted);text-align:center}.psc-casa-cambia{border:0;background:none;padding:0;color:#0075E3;font:700 13px var(--font-body);text-decoration:underline;cursor:pointer}',
    '.psc-casa-num{display:flex;align-items:center;gap:16px;margin:8px 0 4px}.psc-casa-num > div{flex:1;text-align:center}.psc-casa-num b{display:block;font:900 22px/1.2 var(--font-display);color:#0075E3}.psc-casa-num small{display:block;margin-top:6px;font:600 12.5px var(--font-body);color:var(--muted)}.psc-casa-num i{width:1px;height:40px;background:var(--line)}body.dark .psc-casa-num b{color:#8CC6FF}',
    '.psc-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}.psc-chips em{font:700 10.5px/1 var(--font-body);font-style:normal;color:#fff;background:rgba(255,255,255,.18);padding:5px 7px;border-radius:99px;white-space:nowrap}',
    '.psc-card-piu{background:rgba(255,255,255,.04);border:1.5px dashed rgba(140,198,255,.55);flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:12px}',
    '.psc-piu-ic{width:44px;height:44px;border-radius:22px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center}.psc-piu-ic svg{width:20px;height:20px}',
    '.psc-card-piu b{font:800 14px/1.3 var(--font-display);color:#fff}',
    /* azione */
    '.psc-gr{display:flex;flex-direction:column;gap:8px}.psc-gr + .psc-gr{margin-top:22px}',
    '.psc-gr-t{margin:0 0 4px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-att{display:flex;align-items:center;gap:12px;min-height:52px;padding:8px 8px 8px 12px;border-radius:16px;background:rgba(255,255,255,.07)}',
    '.psc-att-i{flex:none;width:32px;height:32px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;overflow:hidden}.psc-att-i img{width:32px;height:32px;object-fit:contain}',
    '.psc-att-n{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;text-align:left}.psc-att-n b{font:700 14px/1.3 var(--font-body);color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psc-att-n small{font:600 12px var(--font-body);color:#C8EFFD}',
    '.psc-att-r{background:none!important;padding:6px 4px!important;min-height:44px!important}.psc-att-tr{display:block;height:6px;margin-top:6px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}.psc-att-tr em{display:block;height:100%;border-radius:99px;background:#3F9FF4}.psc-att-v{flex:none;font:800 13.5px var(--font-body);color:#fff}',
    '.psc-att-hint{margin:26px 0 0;text-align:center;font:600 14px var(--font-body);color:#C8EFFD}',
    '.psc-att-piu{flex:none;width:40px;height:40px;border:0;border-radius:20px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-blocco-az,.psc-azb{margin-top:30px}.psc-azb .pst-link{margin-top:14px}',
    '.psc-k{margin:0 0 26px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-azl{display:flex;flex-direction:column;gap:8px}',
    '.psc-ag,.psc-azb{display:flex;flex-direction:column;align-items:center;text-align:center}.psc-ag .tls-genio{justify-content:center}.psc-ag .tls-punti{text-align:left;align-self:stretch}.psc-azl{align-self:stretch}',
    '.psc-az-cta{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:24px;width:auto!important;padding:0 24px!important}.psc-az-cta svg{flex:none}',
    '.psc-az-link{margin-top:14px;border:0;background:none;color:#C8EFFD;font:600 14px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    '.psc-az-out{display:inline-flex;align-items:center;gap:8px;margin-top:20px;min-height:46px;padding:0 22px;border:1.5px solid rgba(255,255,255,.5);border-radius:23px;background:none;color:#fff;font:700 14.5px var(--font-body);cursor:pointer}.psc-az-out svg{width:18px;height:18px}',
    '.psc-azb .psc-k{text-align:center}',
    '.psc-azr{display:flex;align-items:center;gap:12px;width:100%;padding:10px 12px;border:0;border-radius:16px;background:rgba(255,255,255,.07);text-align:left;cursor:pointer}',
    '.psc-azr-e{flex:none;width:40px;height:40px;border-radius:20px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:20px;line-height:1}',
    '.psc-azr-t{flex:1;min-width:0;display:flex;flex-direction:column;align-items:flex-start;gap:5px}.psc-azr-t b{font:700 14.5px/1.35 var(--font-body);color:#fff}',
    '.psc-azr-t small{font:800 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#fff;padding:4px 8px;border-radius:99px;background:#0075E3}.psc-azr-t small.cambia{background:#E63946}',
    '.psc-azv{margin-top:-8px}',
    '.psc-ag .tls-punti{margin-top:20px}.psc-ag .pst-link.muto,.psc-torna{margin-top:4px}',
    '.psc-ponte{display:flex;gap:12px;align-items:flex-start;margin-top:18px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.07);text-align:left}.psc-ponte span{font-size:20px}.psc-ponte p{margin:0;font:600 13.5px/1.45 var(--font-body);color:#fff}.psc-ponte small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:#C8EFFD}',
    /* identita */
    /* 0.9.368, Andrea: "due schede e lo spazio per una terza vuoto, e Chi devi diventare va a capo": tante colonne quanti i pulsanti, una riga */
    '.psc-seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:4px;padding:4px;border-radius:18px;background:rgba(255,255,255,.07)}',
    '.psc-seg button{min-height:44px;border:0;border-radius:14px;background:none;color:rgba(255,255,255,.65);font:700 13.5px/1.2 var(--font-body);padding:6px 8px;cursor:pointer;white-space:nowrap}.psc-seg button.on{background:#fff;color:#001E44}',
    /* 0.9.371, Andrea: "nella scheda Identita' se provo a scorrere su e giu' non scorre, si scorre solo di lato". LA CAUSA:
       overscroll-behavior-y:none sul carosello (0.9.370) fermava il passaggio dello scorrimento verticale alla pagina. Ora si ferma solo
       quello di lato (che altrimenti cambierebbe scheda), e l'altezza segue la slide che si vede (pscIoAltezza) */
    '.psc-io-car{overflow:hidden;margin:0 -12px;touch-action:pan-y;transition:height .25s ease}.psc-io-tr{display:flex;align-items:flex-start;transition:transform .32s cubic-bezier(.2,.8,.2,1);will-change:transform}.psc-io-dots i{cursor:pointer}',
    '.psc-io-k{margin:4px 0 22px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    /* lo spazio intorno alla slide lascia respirare l'alone del pannello (prima tagliato), e il pannello non e' mai piu' largo della slide */
    '.psc-io-s .psc-seg{margin-bottom:24px}.psc-io-s #scLife,.psc-io-s .psc-life{overflow:visible!important;max-height:none!important}.psc-io-s{padding:8px 18px 22px!important}',
    '.psc-io-s #scLife{width:auto!important;max-width:100%!important;box-sizing:border-box!important;margin-left:0!important;margin-right:0!important}',
    '.psc-io-s{flex:0 0 100%;min-width:0;box-sizing:border-box;padding:0 4px}',
    '.psc-io-dots{display:flex;justify-content:center;gap:7px;margin:22px 0 4px}.psc-io-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.28)}.psc-io-dots i.on{background:#fff}',
    '.psc-pano{display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:6px;width:100%}.psc-tre-svg{display:block;width:min(280px,86%);height:auto;margin:0 auto}',
    '.psc-tre-g{fill:rgba(255,255,255,.04);stroke:rgba(255,255,255,.25);stroke-width:1.2}.psc-tre-g2{fill:none;stroke:rgba(255,255,255,.14);stroke-width:1;stroke-dasharray:3 4}',
    '.psc-tre-tu{fill:rgba(63,159,244,.35);stroke:#3F9FF4;stroke-width:2.2;stroke-linejoin:round}.psc-tre-p{fill:#3F9FF4;stroke:#fff;stroke-width:1.5}.psc-tre-p.basso{fill:#E63946}',
    '.psc-tre-l{font:700 11.5px var(--font-body);fill:#C8EFFD}.psc-tre-l.basso{fill:#FF8A92}',
    '.psc-pano-k{margin:26px 0 0;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#FF8A92}',
    '.psc-pano-h{display:block;margin-top:8px;font:800 24px var(--font-display);color:#fff}.psc-pano-p{margin:12px 0 0;max-width:30ch;font:500 14.5px/1.5 var(--font-body);color:rgba(255,255,255,.85)}',
    '.psc-pano .pst-cta{margin-top:30px;width:auto;padding:0 28px;white-space:nowrap}',
    '.psc-io-c{margin-top:26px;display:flex;flex-direction:column}',
    '.psc-oggi{display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.psc-oggi-v{width:72px;height:72px;border-radius:36px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:38px;line-height:1;box-shadow:0 8px 22px rgba(0,0,0,.28)}',
    '.psc-oggi-h{margin-top:14px;font:800 18px var(--font-display);color:#fff}.psc-oggi-p{margin:8px 0 32px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.75)}',
    '.psc-oggi-f{margin:16px 0 0;font:italic 600 17px/1.45 var(--font-body);color:#fff}',
    '.psc-parole{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:18px}.psc-parole em{font:800 13px var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:7px 12px;border-radius:99px}',
    '.psc-oggi .pst-link{margin-top:24px}',
    '.psc-pass{display:flex;flex-direction:column;width:100%;padding:0;border:1px solid rgba(140,198,255,.35);border-radius:20px;overflow:hidden;background:linear-gradient(160deg,#0B3F7A,#001E44);text-align:left;cursor:pointer;box-shadow:0 10px 24px rgba(0,0,0,.25)}',
    '.psc-pass-top{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#0075E3}.psc-pass-top b{font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#fff}.psc-pass-top i{font-style:normal;font-size:18px}',
    '.psc-pass-mid{display:flex;gap:14px;padding:16px}',
    '.psc-pass-foto{flex:none;width:86px;height:110px;border-radius:12px;background:#C8EFFD;background-size:cover;background-position:center 30%;display:flex;align-items:center;justify-content:center;border:3px solid #fff}.psc-pass-foto i{font-style:normal;font-size:40px}',
    '.psc-pass-dati{flex:1;min-width:0;display:flex;flex-direction:column}.psc-pass-dati small{font:800 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.psc-pass-dati small:not(:first-child){margin-top:9px}.psc-pass-dati b{margin-top:2px;font:700 14px/1.3 var(--font-body);color:#fff;overflow-wrap:anywhere}',
    '.psc-pass-id{display:block;margin:0 16px;padding-top:14px;border-top:1px dashed rgba(140,198,255,.4);font:italic 600 14.5px/1.5 var(--font-body);color:#fff}',
    '.psc-pass-tr{display:flex;flex-wrap:wrap;gap:6px;padding:12px 16px 0}.psc-pass-tr em{font:700 12px/1.3 var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:6px 10px;border-radius:99px}',
    '.psc-pass-apri{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;padding:14px;border-top:1px solid rgba(255,255,255,.1);font:800 14px var(--font-body);color:#8CC6FF}',
    '.psc-life{padding:16px 6px}.psc-life #scLife{margin:0!important}.psc-life .life-wrap{margin:0}.psc-life .life{padding:26px 16px 22px!important}.psc-life .life-big{font-size:clamp(21px,6.4vw,27px)!important;line-height:1.15;overflow-wrap:break-word}',
    '.psc-life-vuoto{display:none;margin:0;text-align:center;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.7)}.psc-life:empty + .psc-life-vuoto,.psc-life:has(> #scLife:empty) + .psc-life-vuoto{display:block}.psc-life:has(> #scLife:empty){display:none}',
    /* --- le pagine a schermo intero (colori del tema) --- */
    '.psc-bar{display:flex;align-items:center}.psc-bar-t{flex:1;text-align:center;font:800 17px var(--font-display);color:var(--navy)}',
    '.psc-pag{padding:12px 20px 40px;max-width:560px;margin:0 auto;display:flex;flex-direction:column}',
    '.psc-foto{position:relative;width:100%;aspect-ratio:16/10;border-radius:22px;border:1.5px dashed var(--line);background-color:var(--card);background-size:cover;background-position:center;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;color:var(--navy)}',
    '.psc-foto.piena{border:0;align-items:flex-end;justify-content:flex-end}',
    '.psc-foto-v{display:flex;flex-direction:column;align-items:center;gap:10px;color:#0075E3}.psc-foto-v b{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-foto-c{display:inline-flex;align-items:center;gap:6px;margin:12px;padding:8px 12px;border-radius:99px;background:rgba(0,30,68,.72);color:#fff;font:700 12.5px var(--font-body)}.psc-foto-c svg{width:16px;height:16px}',
    '.psc-campo{display:flex;flex-direction:column;margin-top:30px}.psc-campo > label{font:800 15px var(--font-display);color:var(--navy)}.psc-campo > small{margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-campo > input,.psc-campo > .psc-tempo,.psc-campo > textarea{margin-top:10px}',
    /* 0.9.367, Andrea: "il - e + attaccati alla domanda: usa le regole dello spacing". Domanda -> controllo 16 px, gruppo -> gruppo 32 px */
    '.psc-campo{margin-top:32px!important}.psc-campo > .psc-step,.psc-campo > .md-step{margin-top:16px!important}.psc-campo > small + .psc-step,.psc-campo > small + .md-step{margin-top:16px!important}.psc-campo > .psc-nota-in{margin-top:22px!important}',
    '.psc-casa-fg{padding-top:8px}.psc-fg-alza{position:absolute;left:16px;top:16px;width:40px;height:40px;border:0;border-radius:50%;background:#EAF2FB;color:#001E44;display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .psc-fg-alza{background:#1B2B48;color:#fff}',
    '.psc-casa-testa{display:flex;flex-direction:column;align-items:center;margin-top:12px}',
    '.psc-casa-anteprima{position:relative;width:132px;height:170px;border-radius:20px;background-size:cover!important;background-position:center!important;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:22px 10px 14px;box-sizing:border-box;box-shadow:0 10px 24px rgba(0,30,68,.2)}',
    '.psc-casa-anteprima span{font-size:46px;line-height:1}.psc-casa-anteprima.foto span{position:absolute;left:10px;top:10px;font-size:22px;width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.9);display:flex;align-items:center;justify-content:center}.psc-casa-anteprima b{font:800 16px var(--font-display);color:#fff;text-shadow:0 1px 6px rgba(0,0,0,.3)}',
    '.psc-casa-l{align-self:stretch;margin:26px 0 12px;font:800 14px var(--font-display);color:var(--navy);text-align:left}body.dark .psc-casa-l{color:#fff}',
    '.psc-casa-emo{display:grid;grid-template-columns:repeat(8,1fr);gap:6px;align-self:stretch}.psc-casa-emo button{aspect-ratio:1;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);font-size:20px;cursor:pointer;padding:0}.psc-casa-emo button.on{border-color:#0075E3;box-shadow:0 0 0 2px rgba(0,117,227,.25)}',
    '.psc-casa-sf{display:flex;gap:12px;align-self:stretch}.psc-casa-sf button{flex:1;height:48px;border:0;border-radius:14px;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(0,0,0,.05)}.psc-casa-sf button.on{box-shadow:0 0 0 3px var(--bg,#fff),0 0 0 5px #0075E3}',
    '.psc-casa-foto{display:flex;align-items:center;justify-content:center;background:#F0FBFF!important;border:1.5px dashed #8CC6FF!important;color:#0075E3}body.dark .psc-casa-foto{background:#0E1D3D!important;color:#8CC6FF}',
    '.psc-rete{display:flex;align-items:center;gap:12px;margin-top:20px;padding:14px;border-radius:16px;background:#F0FBFF;border:1px solid #C8EFFD}body.dark .psc-rete{background:#0E1D3D;border-color:#1F3A66}',
    '.psc-rete > span{font-size:20px}.psc-rete > div{flex:1;min-width:0}.psc-rete small{display:block;font:600 12px var(--font-body);color:var(--muted)}.psc-rete b{display:block;margin-top:2px;font:700 14.5px var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}body.dark .psc-rete b{color:#fff}',
    '.psc-rete button{flex:none;min-height:36px;padding:0 14px;border:1.5px solid #0075E3;border-radius:18px;background:none;color:#0075E3;font:700 13px var(--font-body);cursor:pointer}body.dark .psc-rete button{color:#8CC6FF;border-color:#8CC6FF}',
    '.psc-casa-num b{white-space:nowrap}',
    '.psc-reti{display:flex;flex-direction:column;gap:8px;margin-top:12px}.psc-reti button{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:48px;padding:0 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);color:var(--navy);font:700 14px var(--font-body);text-align:left;cursor:pointer}',
    '.psc-reti button span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psc-reti button small{flex:none;font:600 12px var(--font-body);color:var(--muted)}.psc-reti button.on{border-color:#0075E3;box-shadow:0 0 0 2px rgba(0,117,227,.2)}body.dark .psc-reti button{color:#fff}',
    '.psc-reti p{margin:0;font:500 13.5px var(--font-body);color:var(--muted);text-align:center}',
    '.psc-casa-fg{padding-top:44px}.psc-casa-testa{margin-top:0}',
    '.psc-fin{box-sizing:border-box;font-size:16px!important}.psc-n{max-width:120px}.psc-tempo .psc-n{width:84px;flex:none}.psc-nota-in{min-height:64px!important;margin-top:12px!important}',
    '.psc-tempo{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.psc-u{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-unita{display:flex;gap:2px;padding:3px;border-radius:99px;background:rgba(0,117,227,.1)}.psc-unita button{border:0;background:none;color:var(--navy);font:700 13px var(--font-body);padding:9px 14px;border-radius:99px;cursor:pointer}.psc-unita button.on{background:#0075E3;color:#fff}',
    'body.dark .psc-unita{background:rgba(140,198,255,.14)}',
    '.psc-salva{margin-top:32px}',
    '.psc-via{display:block;margin:16px auto 0;border:0;background:none;color:#E63946;font:700 14px var(--font-body);padding:8px;cursor:pointer}',
    '.psc-tel-prev{display:flex;justify-content:center;margin-top:6px}',
    '.psc-tel-schermo{width:150px;aspect-ratio:9/19;border-radius:26px;border:5px solid #001E44;background:linear-gradient(160deg,#3F9FF4,#001E44);background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:44px;box-shadow:0 14px 30px rgba(0,30,68,.25)}',
    'body.dark .psc-tel-schermo{border-color:#3F9FF4}',
    '.psc-tel-p{margin:20px 0 0;text-align:center;font:600 14.5px/1.45 var(--font-body);color:var(--navy)}',
    '.psc-fonti{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:16px}.psc-fonti button{border:1.5px solid #3F9FF4;background:var(--card);color:var(--navy);font:700 13.5px var(--font-body);padding:10px 14px;border-radius:99px;cursor:pointer}',
    '.psc-blocco{margin-top:30px}.psc-pag .psc-k{color:#0075E3}body.dark .psc-pag .psc-k{color:#8CC6FF}',
    '.psc-tiles{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-tile{display:flex;flex-direction:column;align-items:center;gap:12px;padding:18px 12px;border-radius:20px;border:0;background:#0075E3;color:#fff;cursor:pointer;text-align:center}.psc-tile span{font-size:28px;line-height:1}.psc-tile b{font:800 14px/1.3 var(--font-body)}.psc-tile small{font:600 11.5px var(--font-body);color:#C8EFFD}',
    '.psc-tile.spento{opacity:.45}',
    /* 0.9.364, Andrea: "quel contenitore grigio non e' un colore del mio brand: azzurrino" (il rosa tenue sul bianco sembrava grigio) */
    '.psc-avviso{margin:16px 0 0;padding:12px 14px;border-radius:16px;background:#F0FBFF;border:1px solid #C8EFFD;color:#001E44;font:600 13.5px/1.45 var(--font-body)}body.dark .psc-avviso{background:#0E1D3D;border-color:#22345A;color:#D6E8FF}',
    '.psc-riga-sw{display:flex;align-items:center;gap:14px;padding:16px;border-radius:20px;background:var(--card);border:1px solid var(--line)}.psc-riga-sw > div{flex:1;min-width:0}.psc-riga-sw b{display:block;font:800 15px/1.3 var(--font-body);color:var(--navy)}.psc-riga-sw small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-riga-sw.chiusa{cursor:pointer}.psc-prem{display:inline-block;margin-top:8px;padding:4px 9px;border-radius:99px;background:#001E44;color:#fff;font:800 11px var(--font-body);letter-spacing:.04em}body.dark .psc-prem{background:#0075E3}',
    '.psc-sw-chiuso{opacity:.6;pointer-events:none}',
    /* --- i fogli --- */
    '.psc-fg{text-align:center}.psc-fg-e{display:block;font-size:40px;line-height:1;margin-top:8px}.psc-fg h3{margin:14px 26px 26px!important}',
    '.psc-fg-p{margin:-12px 0 32px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.psc-fg-da{margin:-14px 0 24px;font:600 13.5px var(--font-body);color:var(--muted)}',
    '.psc-fg-2{display:block;width:100%;margin-top:12px;min-height:50px;border:1.5px solid var(--line);border-radius:25px;background:none;color:var(--navy);font:700 15px var(--font-body);cursor:pointer}',
    '.psc-lab{display:block;margin:22px 0 10px;text-align:left;font:800 14px var(--font-display);color:var(--navy)}',
    '.psc-scelta{display:grid;grid-template-columns:1fr 1fr;gap:8px}.psc-scelta button{min-height:52px;border:1.5px solid var(--line);border-radius:16px;background:none;color:var(--navy);font:700 13.5px/1.3 var(--font-body);padding:8px;cursor:pointer}',
    '.psc-scelta button.on.cambia{background:#E63946;border-color:#E63946;color:#fff}.psc-scelta button.on.nuova{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.psc-emoji{display:grid;grid-template-columns:repeat(9,1fr);gap:4px}.psc-emoji button{aspect-ratio:1;border:1.5px solid transparent;border-radius:12px;background:rgba(0,117,227,.08);font-size:18px;line-height:1;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#0075E3;background-size:cover;background-position:center}',
    '.psc-emoji button.on{border-color:#0075E3;background-color:rgba(0,117,227,.18)}.psc-emoji-foto svg{width:18px;height:18px}body.dark .psc-emoji button{background-color:rgba(140,198,255,.12);color:#8CC6FF}',
    '.psc-tre{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.psc-tre input{min-width:0;padding:12px 8px!important;text-align:center}',
    '.psc-oggi-in{min-height:72px!important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
