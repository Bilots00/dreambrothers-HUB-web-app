/* ===========================================================================================
   AMBIENTE, AZIONE E IDENTITA' (0.9.354): le prime tre schede del pannello mini "Le statistiche della
   partita", nella scheda Identita' di "Il tuo viaggio" (rotta-tab.js, #pstBoxMini di partita-stats.js).

   Andrea: "Ambiente | Azione | Identita' | Riepilogo | +. Prima l'ambiente, poi le azioni, e l'identita'
   come conseguenza delle due". partita-stats.js disegna le linguette e chiama qui il corpo della scheda.

   AMBIENTE. I luoghi in cui la persona passa il tempo, come le card di "Per te" in START (preset.js): foto
   dalla galleria (lato lungo 720 px, JPEG, come csImmagineDato), nome, tempo indicativo (ore al giorno o al
   mese), persone e inneschi visivi scritti a mano, una nota breve. Si aggiungono e si cambiano in una pagina
   a schermo intero (s-ambiente). Le foto stanno in IndexedDB (fl_ambiente); nei dati resta solo il
   riferimento 'idb:<chiave>' (o 'ls:<chiave>' se IndexedDB non c'e'): localStorage non si riempie.
     fl_ambienti = [{ id, nome, ore, unita: 'giorno'|'mese', persone, inneschi, nota, img, at }]
   La card fissa "Il telefono" non si elimina: apre s-ambiente-tel, dove un'immagine del sogno va sul blocco
   schermo o come sfondo della Home (NATIVE.setWallpaperImage, SfondoFoto.java) e dove sta la stessa levetta
   "Frase del giorno sul blocco schermo" della pagina Ispirazione quotidiana (scores.js, scToggleLockQuote,
   #inspLockSw): qui si legge lo stato e si chiama la stessa funzione, cosi' le due levette dicono la stessa cosa.
     fl_ambiente_tel = { img, fonte: 'galleria'|'sogno', lockAt, homeAt }

   AZIONE. Con Premium: quello che ha notato il tuo agente personale (tlFrasiPremium della Timeline, i
   resoconti del ponte con le altre AI). Con il piano gratis: le app, i siti e le ricerche del periodo
   (getTopApps, getWebTime, la radiografia della Timeline). Ogni voce diventa un'azione scritta chiara, con
   un'emoji o una foto: un'abitudine da cambiare o una nuova azione.
     fl_azioni_id = [{ id, tipo: 'cambia'|'nuova', t, em, img, da: { tipo, nome }, at }]

   IDENTITA'. Tre sotto-schede: "Chi sono oggi" (fl_chi_sono_oggi = { frase, parole: [3], at }, scritta
   dalla persona), "Chi devo diventare" (la card passaporto della pagina "Il mio io futuro", dai dati di
   fl_iofuturo; tocca e si apre la pagina con nfNotion) e "Chi stai diventando": il pannello #scLife di
   scores.js, adottato vivo con data-adotta. Non sta piu' nel carosello della scheda Identita'.
   Prefisso psc-.
   =========================================================================================== */
const PSC_LUOGHI = 'fl_ambienti';
const PSC_TEL = 'fl_ambiente_tel';
const PSC_AZIONI = 'fl_azioni_id';
const PSC_OGGI = 'fl_chi_sono_oggi';
const PSC_SUB = 'fl_partita_io_sub';
const PSC_BOZZA = 'fl_ambiente_bozza';
const PSC = { url: {}, carica: {}, az: {}, azCarica: {}, azAtt: false, azFonti: [], bozza: null, azBozza: null, salva: false };

const PSC_SVG = {
  indietro: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
  info: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v7M12 6.5v.2"/></svg>',
  infoGrande: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.2"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  foto: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="12" cy="12.5" r="3.5"/><path d="M8.5 5l1.5-2h4l1.5 2"/></svg>'
};

function pscPremium(){
  try{ if (typeof ngPremium === 'function') return !!ngPremium(); }catch(_){ }
  try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; }
}
function pscToast(t){ try{ toast(t); }catch(_){ } }
function pscVibra(n){ try{ if (typeof flVibra === 'function') flVibra(n || 8); }catch(_){ } }
function pscInfoBtn(azione, nome){ return '<button type="button" class="psc-i" onclick="' + azione + '" aria-label="' + pstE(nome) + '">' + PSC_SVG.info + '</button>'; }
function pscOre(ms){
  const m = Math.round((ms || 0) / 60000);
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : '');
}
function pscData(t){ const d = new Date(t); return d.getDate() + ' ' + ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()]; }
function pscNum(v, max, intero){
  let n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  if (!isFinite(n) || n < 0) n = 0;
  n = Math.min(max, n);
  return intero ? Math.round(n) : Math.round(n * 2) / 2;
}
function pscId(p){ return p + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
/** Ridisegna quello che si vede: il pannello mini e le pagine aperte. */
function pscRidisegna(){
  try{ if (typeof pstVisibile === 'function' && pstVisibile()) pstPaint(); }catch(_){ }
  try{ const a = document.getElementById('s-ambiente'); if (a && a.classList.contains('active')) pscLuogoPaint(); }catch(_){ }
  try{ const b = document.getElementById('s-ambiente-tel'); if (b && b.classList.contains('active')) pscTelPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   LE IMMAGINI: in IndexedDB, mai in localStorage (le foto lo riempirebbero). In pagina si mostrano con un
   indirizzo blob:, corto, cosi' ridisegnare il pannello non si porta dietro centinaia di KB di testo.
   --------------------------------------------------------------------------------------- */
function pscDb(){
  return new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_ambiente', 1);
      r.onupgradeneeded = function(){ r.result.createObjectStore('img'); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ ko(r.error); };
    }catch(e){ ko(e); }
  });
}
async function pscIdbPut(k, v){
  try{
    const db = await pscDb();
    await new Promise(function(ok, ko){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').put(v, k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ko(tx.error); }; tx.onabort = function(){ ko(tx.error); }; });
    return true;
  }catch(_){ return false; }
}
async function pscIdbGet(k){
  try{ const db = await pscDb(); return await new Promise(function(ok){ const tx = db.transaction('img', 'readonly'); const q = tx.objectStore('img').get(k); q.onsuccess = function(){ ok(q.result || null); }; q.onerror = function(){ ok(null); }; }); }catch(_){ return null; }
}
async function pscIdbDel(k){
  try{ const db = await pscDb(); await new Promise(function(ok){ const tx = db.transaction('img', 'readwrite'); tx.objectStore('img').delete(k); tx.oncomplete = function(){ ok(); }; tx.onerror = function(){ ok(); }; }); }catch(_){ }
}
function pscBlob(dato){
  const m = /^data:([^;,]+)(;base64)?,(.*)$/.exec(String(dato || ''));
  if (!m) return null;
  const bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
  const a = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
  return new Blob([a], { type: m[1] });
}
function pscUrlDa(ref, dato){
  try{ const b = pscBlob(dato); PSC.url[ref] = b ? URL.createObjectURL(b) : dato; }catch(_){ PSC.url[ref] = dato; }
  return PSC.url[ref];
}
/** Salva un'immagine (data URL) e restituisce il riferimento da scrivere nei dati; '' se non c'e' posto. */
async function pscSalvaImg(k, dato, piccolo){
  if (!dato) return '';
  if (await pscIdbPut(k, dato)){ pscUrlDa('idb:' + k, dato); return 'idb:' + k; }
  const ls = 'fl_ambiente_img_' + k;
  try{ localStorage.setItem(ls, piccolo || dato); pscUrlDa('ls:' + ls, piccolo || dato); return 'ls:' + ls; }catch(_){ }
  return '';
}
/** L'indirizzo da mettere in pagina per un riferimento. Se e' in IndexedDB lo legge e poi ridisegna. */
function pscImgUrl(ref){
  if (!ref) return '';
  if (PSC.url[ref]) return PSC.url[ref];
  if (ref.indexOf('ls:') === 0){ let d = ''; try{ d = localStorage.getItem(ref.slice(3)) || ''; }catch(_){ } return d ? pscUrlDa(ref, d) : ''; }
  if (ref.indexOf('idb:') === 0){
    if (!PSC.carica[ref]){ PSC.carica[ref] = true; pscIdbGet(ref.slice(4)).then(function(d){ if (d){ pscUrlDa(ref, d); pscRidisegna(); } }); }
    return '';
  }
  return /^(img\/|data:image\/|https?:|blob:)/.test(ref) ? ref : '';
}
/** Il data URL di un riferimento (per il telefono, che vuole i byte). */
async function pscImgDato(ref){
  if (!ref) return '';
  if (ref.indexOf('idb:') === 0) return (await pscIdbGet(ref.slice(4))) || '';
  if (ref.indexOf('ls:') === 0){ try{ return localStorage.getItem(ref.slice(3)) || ''; }catch(_){ return ''; } }
  return '';
}
function pscImgVia(ref){
  if (!ref) return;
  try{ if (PSC.url[ref] && PSC.url[ref].indexOf('blob:') === 0) URL.revokeObjectURL(PSC.url[ref]); }catch(_){ }
  delete PSC.url[ref]; delete PSC.carica[ref];
  if (ref.indexOf('idb:') === 0) pscIdbDel(ref.slice(4));
  else if (ref.indexOf('ls:') === 0){ try{ localStorage.removeItem(ref.slice(3)); }catch(_){ } }
}
/* la galleria: l'input si crea, si tocca e si butta, dentro al tocco vero della persona */
function pscScegliFoto(dopo){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    pscLeggiFile(f).then(dopo).catch(function(){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); });
  });
  document.body.appendChild(inp);
  inp.click();
}
function pscLeggiFile(f){
  return new Promise(function(ok, ko){
    const fr = new FileReader();
    fr.onload = function(){ pscCaricaImg(fr.result).then(ok, ko); };
    fr.onerror = ko;
    fr.readAsDataURL(f);
  });
}
function pscCaricaImg(src){ return new Promise(function(ok, ko){ const img = new Image(); img.onload = function(){ ok(img); }; img.onerror = ko; img.src = src; }); }
function pscRiduci(img, lato, q){
  try{
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height; if (!w0 || !h0) return '';
    const k = Math.min(1, lato / Math.max(w0, h0));
    const c = document.createElement('canvas'); c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', q || .8);
  }catch(_){ return ''; }
}
/** Lato lungo 720 px, JPEG: la misura delle altre immagini dell'app (csImmagineDato, caveau-selezione.js). */
function pscPiccola(img){ return ((typeof csImmagineDato === 'function') ? csImmagineDato(img, 720) : '') || pscRiduci(img, 720, .72); }

/* ---------------------------------------------------------------------------------------
   AMBIENTE
   --------------------------------------------------------------------------------------- */
function pscLuoghi(){ const l = pstJ(PSC_LUOGHI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id; }) : []; }
function pscScriviLuoghi(l){ try{ localStorage.setItem(PSC_LUOGHI, JSON.stringify(l)); return true; }catch(_){ return false; } }
function pscTel(){ const t = pstJ(PSC_TEL, {}); return (t && typeof t === 'object' && !Array.isArray(t)) ? t : {}; }
function pscScriviTel(t){ try{ localStorage.setItem(PSC_TEL, JSON.stringify(t)); return true; }catch(_){ return false; } }
function pscTempoTxt(x){
  const n = +x.ore || 0;
  if (!n) return '';
  return String(n).replace('.', ',') + (n === 1 ? ' ora' : ' ore') + (x.unita === 'mese' ? ' al mese' : ' al giorno');
}
function pscLockAcceso(){ try{ return localStorage.getItem('fl_lockquote_on') === '1'; }catch(_){ return false; } }

function pscCardHtml(o){
  const url = pscImgUrl(o.img);
  return '<button type="button" class="psc-card' + (url ? ' foto' : '') + '"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + ' onclick="' + o.click + '" aria-label="' + pstE(o.nome) + '">'
    + (url ? '' : '<span class="psc-card-art" aria-hidden="true">' + o.art + '</span>')
    + '<span class="psc-veil" aria-hidden="true"></span>'
    + '<span class="psc-card-txt"><b>' + pstE(o.nome) + '</b>'
    + o.righe.filter(Boolean).map(function(r){ return '<i>' + pstE(r) + '</i>'; }).join('')
    + (o.chips.length ? '<span class="psc-chips">' + o.chips.map(function(c){ return '<em>' + pstE(c) + '</em>'; }).join('') + '</span>' : '')
    + '</span></button>';
}
function pscAmbienteHtml(){
  const tel = pscTel(), l = pscLuoghi();
  const telChips = [];
  if (tel.lockAt) telChips.push('🔒 Blocco schermo');
  if (tel.homeAt) telChips.push('🏠 Home');
  if (pscLockAcceso()) telChips.push('💬 Frase del giorno');
  return '<div class="psc-amb">'
    + '<div class="psc-testa"><p>I posti in cui passi il tempo decidono chi diventi.</p>' + pscInfoBtn('pscAmbInfo()', 'Come funziona l\'ambiente') + '</div>'
    + '<div class="psc-griglia">'
    + pscCardHtml({ click: 'pscTelApri()', img: tel.img, art: '📱', nome: 'Il telefono', righe: ['Ti segue ovunque'], chips: telChips })
    + l.map(function(x){
        const ch = [];
        if (x.persone || x.persone === 0) ch.push('👥 ' + x.persone + (x.persone === 1 ? ' persona' : ' persone'));
        if (x.inneschi || x.inneschi === 0) ch.push('✨ ' + x.inneschi + (x.inneschi === 1 ? ' innesco' : ' inneschi'));
        return pscCardHtml({ click: 'pscLuogoApri(' + pstA(x.id) + ')', img: x.img, art: '🏡', nome: x.nome, righe: [pscTempoTxt(x)], chips: ch });
      }).join('')
    + '<button type="button" class="psc-card psc-card-piu" onclick="pscLuogoApri(\'\')"><span class="psc-piu-ic">' + PST_ICO.piu + '</span><b>Aggiungi un luogo</b></button>'
    + '</div></div>';
}
function pscAmbInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">🏡</span><h3>Il tuo ambiente</h3>'
    + flInfoRighe([
      ['👥', 'I luoghi ti cambiano', 'Le persone e le cose intorno a te spingono le tue scelte.'],
      ['⏱️', 'Conta il tempo', 'Più ore passi in un luogo, più quel luogo decide per te.'],
      ['✨', 'Gli inneschi visivi', 'Sono le immagini e gli oggetti che ti ricordano il sogno. Più ne vedi, più ci pensi.'],
      ['📱', 'Il telefono ti segue', 'Lo guardi tutto il giorno. Mettici un’immagine del sogno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}

/* LA PAGINA DI UN LUOGO: nuovo o da cambiare. La bozza di un luogo nuovo resta salvata (senza la foto) finche' non lo salvi */
registerScreen('s-ambiente',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t" id="pscLuogoT">Il luogo</b><button class="iconbtn" onclick="pscAmbInfo()" aria-label="Come funziona l\'ambiente">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscLuogoBody"></div><div class="spacer"></div>', { back: function(){ return 's-home'; } });

function pscLuogoApri(id){
  const x = id ? pscLuoghi().filter(function(l){ return l.id === id; })[0] : null;
  if (id && !x) return;
  pscVibra(6);
  let bz = null; try{ bz = JSON.parse(localStorage.getItem(PSC_BOZZA) || 'null'); }catch(_){ bz = null; }
  PSC.bozza = x ? Object.assign({}, x) : ((bz && typeof bz === 'object') ? bz : { id: '', nome: '', ore: '', unita: 'giorno', persone: '', inneschi: '', nota: '', img: '' });
  PSC.bozza.nuova = '';
  goId('s-ambiente');
  pscLuogoPaint();
  try{ const p = document.getElementById('s-ambiente'); if (p) p.scrollTop = 0; }catch(_){ }
}
function pscBz(k, v){
  const b = PSC.bozza; if (!b) return;
  b[k] = v;
  if (!b.id){ try{ const c = Object.assign({}, b); delete c.nuova; localStorage.setItem(PSC_BOZZA, JSON.stringify(c)); }catch(_){ } }
}
function pscBzUnita(u){ pscBz('unita', u); pscVibra(6); pscLuogoPaint(); }
function pscCampo(id, lab, input, sotto){
  return '<div class="psc-campo"><label for="' + id + '">' + lab + '</label>' + (sotto ? '<small>' + sotto + '</small>' : '') + input + '</div>';
}
function pscLuogoPaint(){
  const box = document.getElementById('pscLuogoBody'), b = PSC.bozza; if (!box || !b) return;
  const t = document.getElementById('pscLuogoT'); if (t) t.textContent = b.id ? 'Il luogo' : 'Un luogo nuovo';
  const url = b.nuova || pscImgUrl(b.img);
  const num = function(id, k, ph, max, passo){ return '<input class="fin psc-fin psc-n" id="' + id + '" type="number" inputmode="decimal" min="0" max="' + max + '" step="' + passo + '" placeholder="' + ph + '" value="' + pstE(b[k] === '' || b[k] == null ? '' : b[k]) + '" oninput="pscBz(\'' + k + '\',this.value)">'; };
  box.innerHTML = '<button type="button" class="psc-foto' + (url ? ' piena' : '') + '" onclick="pscLuogoFoto()"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>'
      + (url ? '<span class="psc-foto-c">' + PSC_SVG.foto + 'Cambia la foto</span>' : '<span class="psc-foto-v">' + PSC_SVG.foto + '<b>Scegli una foto dalla galleria</b></span>')
    + '</button>'
    + pscCampo('pscNome', 'Come si chiama il luogo?', '<input class="fin psc-fin" id="pscNome" maxlength="40" placeholder="Per esempio, la mia camera" value="' + pstE(b.nome || '') + '" oninput="pscBz(\'nome\',this.value)">')
    + pscCampo('pscOre', 'Quanto tempo ci passi?', '<div class="psc-tempo">' + num('pscOre', 'ore', '0', b.unita === 'mese' ? 744 : 24, '0.5') + '<span class="psc-u">ore</span>'
      + '<div class="psc-unita" role="radiogroup" aria-label="Ogni quanto">' + [['giorno', 'al giorno'], ['mese', 'al mese']].map(function(u){ return '<button type="button" role="radio" aria-checked="' + (b.unita === u[0]) + '" class="' + (b.unita === u[0] ? 'on' : '') + '" onclick="pscBzUnita(\'' + u[0] + '\')">' + u[1] + '</button>'; }).join('') + '</div></div>',
      'Scegli "al mese" per un posto in cui vai di rado.')
    + pscCampo('pscPersone', 'Quante persone ci sono di solito?', num('pscPersone', 'persone', '0', 9999, '1'))
    + pscCampo('pscInneschi', 'Quanti inneschi visivi ci sono?', num('pscInneschi', 'inneschi', '0', 999, '1')
      + '<textarea class="fin psc-fin psc-nota-in" id="pscNota" rows="2" maxlength="120" placeholder="Una nota breve, se vuoi. Per esempio, la foto del mare sopra la scrivania" oninput="pscBz(\'nota\',this.value)">' + pstE(b.nota || '') + '</textarea>',
      'Conta le immagini e gli oggetti che ti ricordano il sogno.')
    + '<button type="button" class="en-cta psc-salva" onclick="pscLuogoSalva()">' + (b.id ? 'Salva le modifiche' : 'Salva il luogo') + '</button>'
    + (b.id ? '<button type="button" class="psc-via" onclick="pscLuogoElimina()">Elimina il luogo</button>' : '');
}
function pscLuogoFoto(){
  pscScegliFoto(function(img){
    const d = pscPiccola(img);
    if (!d){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
    if (PSC.bozza){ PSC.bozza.nuova = d; pscLuogoPaint(); }
  });
}
async function pscLuogoSalva(){
  const b = PSC.bozza; if (!b || PSC.salva) return;
  const nome = String(b.nome || '').trim().slice(0, 40);
  if (!nome){ pscToast('Scrivi il nome del luogo'); const n = document.getElementById('pscNome'); if (n) n.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('l');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('amb_' + id + '_' + Date.now().toString(36), b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; }
    else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const unita = b.unita === 'mese' ? 'mese' : 'giorno';
  const vuoto = function(v){ return v === '' || v == null; };
  const o = { id: id, nome: nome, ore: pscNum(b.ore, unita === 'mese' ? 744 : 24), unita: unita,
    persone: vuoto(b.persone) ? null : pscNum(b.persone, 9999, true), inneschi: vuoto(b.inneschi) ? null : pscNum(b.inneschi, 999, true),
    nota: String(b.nota || '').trim().slice(0, 120), img: img, at: Date.now() };
  const l = pscLuoghi(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviLuoghi(l)){ pscToast('La memoria del telefono è piena, il luogo non si salva'); return; }
  try{ localStorage.removeItem(PSC_BOZZA); }catch(_){ }
  PSC.bozza = null;
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Luogo aggiornato' : 'Luogo aggiunto al tuo ambiente');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}
async function pscLuogoElimina(){
  const b = PSC.bozza; if (!b || !b.id) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare "' + b.nome + '"?', 'Il luogo sparisce con la sua foto.', 'Elimina', true); }catch(_){ }
  if (!ok) return;
  pscScriviLuoghi(pscLuoghi().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.bozza = null;
  pscToast('Luogo eliminato');
  flIndietro();
  setTimeout(pscRidisegna, 60);
}

/* IL TELEFONO: la card fissa. Un'immagine del sogno sul blocco schermo o sulla Home, e la frase del giorno */
registerScreen('s-ambiente-tel',
  '<div class="topbar psc-bar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PSC_SVG.indietro + '</button><b class="psc-bar-t">Il telefono</b><button class="iconbtn" onclick="pscTelInfo()" aria-label="Come funziona il telefono come innesco">' + PSC_SVG.infoGrande + '</button></div>'
  + '<div class="psc-pag" id="pscTelBody"></div><div class="spacer"></div>', { back: function(){ return 's-home'; } });

function pscTelApri(){
  pscVibra(6);
  goId('s-ambiente-tel');
  pscTelPaint();
  pscLockSync().then(function(){ pscTelPaint(); });
}
/** L'immagine del sogno che l'app usa gia': la copertina della pagina del sogno (costruisci.js), foto o immagine scelta. */
function pscImgSogno(){
  try{
    if (typeof cstCfg === 'function'){
      const c = String(cstCfg().cover || '');
      if (c === 'mia'){ const d = localStorage.getItem('fl_mappa_cover_img') || ''; if (d) return d; }
      else if (/^img\//.test(c)) return c;
    }
  }catch(_){ }
  return '';
}
function pscTelPaint(){
  const box = document.getElementById('pscTelBody'); if (!box) return;
  const t = pscTel(), url = pscImgUrl(t.img), sogno = pscImgSogno(), prem = pscPremium(), q = pscLockAcceso();
  const tile = function(k, ico, txt, at){
    return '<button type="button" class="psc-tile' + (url ? '' : ' spento') + '" onclick="pscTelMetti(\'' + k + '\')"><span aria-hidden="true">' + ico + '</span><b>' + txt + '</b>' + (at ? '<small>Messa il ' + pscData(at) + '</small>' : '') + '</button>';
  };
  box.innerHTML = '<div class="psc-tel-prev"><div class="psc-tel-schermo"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : '<span aria-hidden="true">📱</span>') + '</div></div>'
    + '<p class="psc-tel-p">' + (url ? 'Guarda questa immagine ogni volta che prendi il telefono.' : 'Scegli un’immagine che ti ricorda il sogno.') + '</p>'
    + '<div class="psc-fonti"><button type="button" onclick="pscTelGalleria()">🖼️ Scegli dalla galleria</button>'
    + (sogno ? '<button type="button" onclick="pscTelSogno()">🎯 Usa la copertina del sogno</button>' : '') + '</div>'
    + '<section class="psc-blocco"><p class="psc-k">Dove la metti</p><div class="psc-tiles">' + tile('lock', '🔒', 'Metti sul blocco schermo', t.lockAt) + tile('home', '🏠', 'Metti come sfondo della Home', t.homeAt) + '</div>'
    + (q ? '<p class="psc-avviso">💬 La frase del giorno è accesa.<br>Domani coprirà la foto sul blocco schermo.</p>' : '') + '</section>'
    + '<section class="psc-blocco"><div class="psc-riga-sw' + (prem ? '' : ' chiusa') + '"' + (prem ? '' : ' role="button" tabindex="0" onclick="pscLockToggle()"') + '>'
    + '<div><b>Frase del giorno sul blocco schermo</b><small>Ogni giorno una frase nuova sul blocco schermo.</small>' + (prem ? '' : '<span class="psc-prem">⭐ Premium</span>') + '</div>'
    + (prem ? '<button type="button" class="switch' + (q ? ' on' : '') + '" id="pscLockSw" role="switch" aria-checked="' + q + '" aria-label="Frase del giorno sul blocco schermo" onclick="pscLockToggle()"></button>'
      : '<span class="switch psc-sw-chiuso" aria-hidden="true"></span>')
    + '</div></section>';
}
function pscTelInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">📱</span><h3>Il telefono come innesco</h3>'
    + flInfoRighe([
      ['👀', 'Lo guardi sempre', 'Prendi il telefono decine di volte al giorno.'],
      ['🎯', 'Mettici il sogno', 'Ogni volta che lo sblocchi, l’immagine ti ricorda dove stai andando.'],
      ['💬', 'Oppure una frase', 'Con Premium il blocco schermo mostra una frase nuova ogni giorno.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/** Un'immagine nuova per il telefono: lato lungo 1600 px, per non vederla sgranata sullo schermo intero. */
async function pscTelImposta(dato, fonte){
  if (!dato){ pscToast('Non riesco a leggere questa foto, provane un\'altra'); return; }
  const t = pscTel(), prima = t.img;
  const ref = await pscSalvaImg('tel_' + Date.now().toString(36), dato);
  if (!ref){ pscToast('La memoria del telefono è piena, l’immagine non si salva'); return; }
  t.img = ref; t.fonte = fonte; t.lockAt = 0; t.homeAt = 0; t.at = Date.now();
  if (!pscScriviTel(t)){ pscImgVia(ref); pscToast('La memoria del telefono è piena, l’immagine non si salva'); return; }
  if (prima && prima !== ref) pscImgVia(prima);
  pscVibra(8);
  pscTelPaint();
  pscRidisegna();
}
function pscTelGalleria(){ pscScegliFoto(function(img){ pscTelImposta(pscRiduci(img, 1600, .86), 'galleria'); }); }
async function pscTelSogno(){
  const src = pscImgSogno(); if (!src) return;
  try{ const img = await pscCaricaImg(src); await pscTelImposta(pscRiduci(img, 1600, .86), 'sogno'); }
  catch(_){ pscToast('Non riesco a leggere la copertina del sogno'); }
}
function pscErr(e){
  const m = String((e && (e.message || e.errorMessage)) || '');
  if (/not implemented|unimplemented/i.test(m) || (e && e.code === 'UNIMPLEMENTED')) return 'Aggiorna l’app per mettere lo sfondo';
  return m || 'Non riuscito, riprova fra poco';
}
async function pscTelMetti(target){
  const t = pscTel();
  if (!t.img){ pscToast('Scegli prima un’immagine'); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setWallpaperImage){ pscToast('Disponibile nell\'app installata'); return; }
  if (target === 'lock' && await pscLockSync()){ pscTelAvviso(); return; }
  await pscTelApplica(target);
}
/* 0.9.354: la frase del giorno ridisegna il blocco schermo ogni giorno e domani coprirebbe la foto. Si chiede prima */
function pscTelAvviso(){
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">💬</span><h3>La frase del giorno è accesa</h3>'
    + '<p class="psc-fg-p">Domani la frase coprirà la tua foto sul blocco schermo.</p>'
    + '<button type="button" class="en-cta" onclick="pscTelSpegniEMetti()">Spegni la frase e metti la foto</button>'
    + '<button type="button" class="psc-fg-2" onclick="inSheetChiudi();pscTelApplica(\'lock\')">Metti la foto e tieni la frase</button></div>');
}
async function pscTelSpegniEMetti(){
  inSheetChiudi();
  if (await pscLockSync() && typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  await pscTelApplica('lock');
}
async function pscTelApplica(target){
  const t = pscTel();
  const dato = await pscImgDato(t.img);
  if (!dato){ pscToast('Non trovo l’immagine, sceglila di nuovo'); return; }
  try{ await NATIVE.setWallpaperImage({ data: dato, target: target }); }
  catch(e){ pscToast(pscErr(e)); return; }
  const n = pscTel(); n[target === 'lock' ? 'lockAt' : 'homeAt'] = Date.now(); pscScriviTel(n);
  pscVibra([10, 30, 10]);
  pscToast(target === 'lock' ? 'Fatto, guarda il blocco schermo' : 'Fatto, guarda la Home');
  pscTelPaint();
  pscRidisegna();
}
/* LA FRASE DEL GIORNO: lo stato vero lo sa il telefono (getLockQuote). Si copia sulle due levette, poi si usa la stessa funzione */
async function pscLockSync(){
  let on = pscLockAcceso();
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getLockQuote){ const st = await NATIVE.getLockQuote(); on = !!(st && st.on); try{ if (on) localStorage.setItem('fl_lockquote_on', '1'); else localStorage.removeItem('fl_lockquote_on'); }catch(_){ } } }catch(_){ }
  const a = document.getElementById('inspLockSw'); if (a) a.className = 'switch' + (on ? ' on' : '');
  const b = document.getElementById('pscLockSw'); if (b){ b.className = 'switch' + (on ? ' on' : ''); b.setAttribute('aria-checked', String(on)); }
  return on;
}
async function pscLockToggle(){
  if (!pscPremium()){ if (typeof pfApri === 'function') pfApri(); return; }
  await pscLockSync();
  if (typeof scToggleLockQuote === 'function'){ try{ await scToggleLockQuote(); }catch(_){ } }
  pscTelPaint();
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   AZIONE
   --------------------------------------------------------------------------------------- */
function pscAzioni(){ const l = pstJ(PSC_AZIONI, []); return Array.isArray(l) ? l.filter(function(x){ return x && x.id && x.t; }) : []; }
function pscScriviAzioni(l){ try{ localStorage.setItem(PSC_AZIONI, JSON.stringify(l)); return true; }catch(_){ return false; } }
async function pscAzCarica(per){
  if (PSC.azCarica[per]) return;
  PSC.azCarica[per] = true;
  const F = pstFinestra(per), out = { at: Date.now(), apps: [], siti: [], ricerche: [], frasi: [], browser: false };
  if (typeof NATIVE === 'undefined' || !NATIVE) out.browser = true;
  else {
    try{
      if (NATIVE.getTopApps){
        const r = await NATIVE.getTopApps({ from: F.da, to: F.a, limit: 12, icons: 8 });
        out.apps = ((r && r.apps) || []).filter(function(a){ const p = String(a && a.packageName || ''); return a && (a.ms || 0) >= 60000 && p.indexOf('com.dreambrothers') !== 0 && !(typeof tlLauncher === 'function' && tlLauncher(p)); }).slice(0, 4);
      }
    }catch(_){ }
    try{
      if (NATIVE.getWebTime){ const w = await NATIVE.getWebTime({ from: F.da, to: F.a, bucket: 'none', limit: 4 }); out.siti = ((w && w.sites) || []).filter(function(s){ return s && s.host; }).slice(0, 3); }
    }catch(_){ }
    try{
      if (typeof tlRadioLeggi === 'function'){
        const r = await tlRadioLeggi(F.da, F.a), per0 = {};
        ((r && r.eventi) || []).forEach(function(e0){
          const e = (typeof tlRicercaVera === 'function') ? tlRicercaVera(e0) : e0;
          if (!e || e.tipo !== 'ricerca' || !e.cosa) return;
          const testo = String(e.cosa).trim(), k = testo.toLowerCase();
          if (k.length < 2) return;
          if (!per0[k]) per0[k] = { t: testo.slice(0, 60), n: 0, at: 0 };
          per0[k].n++; if (+e.t > per0[k].at) per0[k].at = +e.t;
        });
        out.ricerche = Object.keys(per0).map(function(k){ return per0[k]; }).sort(function(a, b){ return b.n - a.n || b.at - a.at; }).slice(0, 4);
      }
    }catch(_){ }
  }
  if (pscPremium()){
    try{
      const r = (typeof tlRiassuntoDi === 'function') ? await tlRiassuntoDi(0) : null;
      out.frasi = (typeof tlFrasiPremium === 'function') ? (tlFrasiPremium(r || ((typeof tlRiassunto === 'function') ? tlRiassunto(null) : {}), 0) || []).slice(0, 3) : [];
    }catch(_){ out.frasi = []; }
    try{ if (typeof pntSync === 'function') await pntSync(false); }catch(_){ }
  }
  PSC.az[per] = out; PSC.azCarica[per] = false;
  pscRidisegna();
}
function pscAzioneHtml(){
  const per = PST.per, d = PSC.az[per];
  if (!d || Date.now() - d.at > 60000) pscAzCarica(per);
  const prem = pscPremium();
  return '<div class="psc-az">' + ((prem && !PSC.azAtt) ? pscAgenteHtml(d, per) : pscAttivitaHtml(d, per)) + pscAzioniListaHtml() + '</div>';
}
function pscQuando(per){ return per === 1 ? 'oggi' : (per === 7 ? 'negli ultimi 7 giorni' : 'negli ultimi 30 giorni'); }
/* PREMIUM: quello che ha notato il tuo agente personale (gli stessi pattern del Riepilogo della Timeline) */
function pscAgenteHtml(d, per){
  const frasi = (d && d.frasi) || [];
  let ponte = '';
  try{
    if (typeof pntOn === 'function' && pntOn() && typeof pntVoci === 'function'){
      const F = pstFinestra(per), v = pntVoci().filter(function(x){ return x && x.at >= F.da && x.testo; });
      if (v.length) ponte = '<div class="psc-ponte"><span aria-hidden="true">🤝</span><p>Le tue AI hanno scritto ' + v.length + (v.length === 1 ? ' resoconto' : ' resoconti') + ' ' + pscQuando(per) + '.<small>' + pstE(String(v[0].testo).slice(0, 110)) + '</small></p></div>';
    }
  }catch(_){ }
  return '<div class="psc-ag"><div class="tls-genio"><img src="img/genio/genio-pensa.png" alt=""><span>Il tuo agente personale ha notato</span></div>'
    + (!d ? '<p class="pst-nota">Il tuo agente personale sta leggendo la giornata.</p>'
      : (frasi.length ? '<ul class="tls-punti">' + frasi.map(function(f){ return '<li><span class="tls-em">' + f.ico + '</span><span>' + f.html + '</span></li>'; }).join('') + '</ul>'
        : '<p class="pst-nota">Il tuo agente personale ha ancora pochi dati. Torna dopo aver usato il telefono un po’ di più.</p>'))
    + ponte
    + '<button type="button" class="pst-link" onclick="pscAgChat()">' + PST_ICO.chat + '<span>Chiedi al tuo agente personale</span></button>'
    + '<button type="button" class="pst-link muto" onclick="pscAzAttivita(true)">Trasforma le attività in abitudini</button></div>';
}
function pscAzAttivita(on){ PSC.azAtt = !!on; pscVibra(6); pstPaint(); }
async function pscAgChat(){
  let ok = false;
  try{ if (typeof agPopover === 'function') ok = await agPopover('', { titolo: 'Le mie azioni', pill: ['Quale abitudine mi allontana di più dal sogno?', 'Che azione nuova posso fare domani?'] }); }catch(_){ ok = false; }
  if (!ok && typeof agPopover !== 'function') pscToast('Il tuo agente personale non risponde adesso, riprova fra poco');
}
/* GRATIS (e Premium dal link): le app, i siti e le ricerche del periodo. Il + trasforma la voce in un'azione */
function pscAttivitaHtml(d, per){
  PSC.azFonti = [];
  const testa = '<div class="psc-testa"><p>Ecco cosa hai fatto ' + pscQuando(per) + '.</p>' + pscInfoBtn('pscAzInfo()', 'Come funzionano le azioni') + '</div>';
  const torna = pscPremium() ? '<button type="button" class="pst-link muto psc-torna" onclick="pscAzAttivita(false)">Torna al tuo agente personale</button>' : '';
  if (!d) return testa + '<p class="pst-nota">Sto leggendo le attività del telefono.</p>' + torna;
  if (d.browser) return testa + '<p class="pst-nota">Le attività del telefono si vedono nell’app installata.</p>' + torna;
  const riga = function(f, ico, nome, val){
    const i = PSC.azFonti.push(f) - 1;
    return '<div class="psc-att"><span class="psc-att-i" aria-hidden="true">' + ico + '</span><span class="psc-att-n"><b>' + pstE(nome) + '</b><small>' + pstE(val) + '</small></span>'
      + '<button type="button" class="psc-att-piu" aria-label="Trasforma ' + pstE(nome) + ' in un’azione" onclick="pscAzNuova(' + i + ')">' + PST_ICO.piu + '</button></div>';
  };
  const gruppo = function(tit, righe){ return righe.length ? '<div class="psc-gr"><p class="psc-gr-t">' + tit + '</p>' + righe.join('') + '</div>' : ''; };
  const app = d.apps.map(function(a){
    const nome = a.label || a.appName || String(a.packageName || '').split('.').pop();
    const ico = (a.icon && String(a.icon).indexOf('data:image') === 0) ? '<img src="' + a.icon + '" alt="">' : '📱';
    return riga({ tipo: 'app', nome: nome, val: pscOre(a.ms), em: '📱' }, ico, nome, pscOre(a.ms));
  });
  const siti = d.siti.map(function(s){ const h = String(s.host).replace(/^www\./, ''); return riga({ tipo: 'sito', nome: h, val: pscOre(s.ms), em: '🌐' }, '🌐', h, pscOre(s.ms)); });
  const ric = d.ricerche.map(function(r){ const v = r.n === 1 ? 'Cercata 1 volta' : 'Cercata ' + r.n + ' volte'; return riga({ tipo: 'ricerca', nome: r.t, val: v, em: '🔎' }, '🔎', r.t, v); });
  const tutto = gruppo('📱 App', app) + gruppo('🌐 Siti', siti) + gruppo('🔎 Ricerche', ric);
  return testa + (tutto || '<p class="pst-nota">Le app aperte le conta il telefono. Serve il permesso di utilizzo.</p>') + torna;
}
function pscAzInfo(){
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">⚡</span><h3>Le tue azioni</h3>'
    + flInfoRighe([
      ['📱', 'Il telefono conta', 'Vedi le app, i siti e le ricerche del periodo che scegli.'],
      ['✍️', 'Scrivi l’azione', 'Tocca + accanto a una voce e scrivi l’abitudine in modo chiaro.'],
      ['🔁', 'Cambia o comincia', 'Scegli un’abitudine da cambiare, oppure una nuova azione da fare.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pscAzioniListaHtml(){
  const l = pscAzioni();
  return '<section class="psc-blocco psc-azb"><p class="psc-k">Le tue azioni</p>'
    + (l.length ? '<div class="psc-azl">' + l.map(function(a){
        const url = pscImgUrl(a.img);
        return '<button type="button" class="psc-azr" onclick="pscAzModifica(' + pstA(a.id) + ')"><span class="psc-azr-e"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : pstE(a.em || '🎯')) + '</span>'
          + '<span class="psc-azr-t"><b>' + pstE(a.t) + '</b><small class="' + (a.tipo === 'cambia' ? 'cambia' : 'nuova') + '">' + (a.tipo === 'cambia' ? 'Da cambiare' : 'Nuova azione') + '</small></span></button>';
      }).join('') + '</div>'
      : '<p class="pst-nota psc-azv">Qui trovi le abitudini e le azioni che scrivi.</p>')
    + '<button type="button" class="pst-link" onclick="pscAzNuova(-1)">' + PST_ICO.piu + '<span>Scrivi un’azione</span></button></section>';
}
const PSC_EMOJI = ['📱', '📚', '🏃', '💧', '🧘', '✍️', '🌙', '🎯'];
function pscAzNuova(i){
  const f = (i >= 0 && PSC.azFonti[i]) ? PSC.azFonti[i] : null;
  PSC.azBozza = { id: '', tipo: f && f.tipo !== 'ricerca' ? 'cambia' : 'nuova', t: '', em: f ? f.em : '🎯', img: '', nuova: '', da: f ? { tipo: f.tipo, nome: f.nome, val: f.val } : null };
  pscVibra(6);
  pscAzFoglio();
}
function pscAzModifica(id){
  const a = pscAzioni().filter(function(x){ return x.id === id; })[0]; if (!a) return;
  PSC.azBozza = Object.assign({ nuova: '' }, a);
  pscVibra(6);
  pscAzFoglio();
}
function pscAzEsempio(b){
  const n = b.da && b.da.nome ? b.da.nome : '';
  if (b.tipo === 'cambia') return b.da && b.da.tipo === 'app' ? 'Per esempio, apro ' + n + ' a letto' : (b.da && b.da.tipo === 'sito' ? 'Per esempio, apro ' + n + ' appena mi siedo' : 'Per esempio, apro Instagram a letto');
  return 'Per esempio, leggo 10 pagine';
}
function pscAzFoglio(){
  const b = PSC.azBozza; if (!b) return;
  const url = b.nuova || pscImgUrl(b.img);
  inSheet('<div class="en-foglio psc-fg psc-azf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">⚡</span>'
    + '<h3>' + (b.id ? 'La tua azione' : 'Trasforma in un’azione') + '</h3>'
    + (b.da ? '<p class="psc-fg-da">' + pstE(b.da.nome) + ', ' + pstE(String(b.da.val || '').toLowerCase()) + '</p>' : '')
    + '<div class="psc-scelta" role="radiogroup" aria-label="Che tipo di azione">' + [['cambia', 'Un’abitudine da cambiare'], ['nuova', 'Una nuova azione']].map(function(x){
        return '<button type="button" role="radio" aria-checked="' + (b.tipo === x[0]) + '" class="' + (b.tipo === x[0] ? 'on ' : '') + x[0] + '" onclick="pscAzTipo(\'' + x[0] + '\')">' + x[1] + '</button>';
      }).join('') + '</div>'
    + '<label class="psc-lab" for="pscAzT">Scrivila in modo chiaro</label>'
    + '<input class="fin psc-fin" id="pscAzT" maxlength="80" placeholder="' + pstE(pscAzEsempio(b)) + '" value="' + pstE(b.t || '') + '" oninput="PSC.azBozza.t=this.value">'
    + '<label class="psc-lab">Scegli un’emoji o una foto</label>'
    + '<div class="psc-emoji">' + PSC_EMOJI.map(function(e){ return '<button type="button" class="' + (!url && b.em === e ? 'on' : '') + '" onclick="pscAzEmoji(\'' + e + '\')" aria-label="Emoji ' + e + '">' + e + '</button>'; }).join('')
    + '<button type="button" class="psc-emoji-foto' + (url ? ' on' : '') + '" onclick="pscAzFoto()" aria-label="Usa una foto"' + (url ? ' style="background-image:url(\'' + String(url).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (url ? '' : PSC_SVG.foto) + '</button></div>'
    + '<button type="button" class="en-cta psc-salva" onclick="pscAzSalva()">' + (b.id ? 'Salva le modifiche' : 'Salva l’azione') + '</button>'
    + (b.id ? '<button type="button" class="psc-via" onclick="pscAzElimina()">Elimina l’azione</button>' : '')
    + '</div>');
}
function pscAzLeggi(){ const i = document.getElementById('pscAzT'); if (i && PSC.azBozza) PSC.azBozza.t = i.value; }
function pscAzTipo(k){ pscAzLeggi(); PSC.azBozza.tipo = k; pscVibra(6); pscAzFoglio(); }
function pscAzEmoji(e){ pscAzLeggi(); const b = PSC.azBozza; b.em = e; b.nuova = ''; if (b.img){ b.imgVia = b.img; b.img = ''; } pscVibra(6); pscAzFoglio(); }
function pscAzFoto(){
  pscAzLeggi();
  pscScegliFoto(function(img){ const d = pscRiduci(img, 240, .8); if (!d || !PSC.azBozza) return; PSC.azBozza.nuova = d; pscAzFoglio(); });
}
async function pscAzSalva(){
  pscAzLeggi();
  const b = PSC.azBozza; if (!b || PSC.salva) return;
  const t = String(b.t || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  if (t.length < 3){ pscToast('Scrivi l’azione in modo chiaro'); const i = document.getElementById('pscAzT'); if (i) i.focus(); return; }
  PSC.salva = true;
  const id = b.id || pscId('a');
  let img = b.img || '';
  if (b.nuova){
    const ref = await pscSalvaImg('az_' + id + '_' + Date.now().toString(36), b.nuova, b.nuova);
    if (ref){ if (img && img !== ref) pscImgVia(img); img = ref; } else pscToast('La memoria del telefono è piena, la foto non si salva');
  }
  const o = { id: id, tipo: b.tipo === 'cambia' ? 'cambia' : 'nuova', t: t.charAt(0).toUpperCase() + t.slice(1), em: b.em || '🎯', img: img, da: b.da || null, at: Date.now() };
  const l = pscAzioni(), i = l.findIndex(function(x){ return x.id === id; });
  if (i >= 0) l[i] = Object.assign({}, l[i], o); else l.push(o);
  PSC.salva = false;
  if (!pscScriviAzioni(l)){ pscToast('La memoria del telefono è piena, l’azione non si salva'); return; }
  if (b.imgVia && b.imgVia !== img) pscImgVia(b.imgVia);
  PSC.azBozza = null;
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast(i >= 0 ? 'Azione aggiornata' : 'Azione salvata nelle tue azioni');
  pscRidisegna();
}
async function pscAzElimina(){
  const b = PSC.azBozza; if (!b || !b.id) return;
  inSheetChiudi();
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare questa azione?', '"' + b.t + '" sparisce dalle tue azioni.', 'Elimina', true); }catch(_){ }
  if (!ok){ pscAzFoglio(); return; }
  pscScriviAzioni(pscAzioni().filter(function(x){ return x.id !== b.id; }));
  if (b.img) pscImgVia(b.img);
  PSC.azBozza = null;
  pscToast('Azione eliminata');
  pscRidisegna();
}

/* ---------------------------------------------------------------------------------------
   IDENTITA': chi sono oggi, chi devo diventare, chi stai diventando
   --------------------------------------------------------------------------------------- */
const PSC_IO = [['oggi', 'Chi sono oggi'], ['devo', 'Chi devo diventare'], ['stai', 'Chi stai diventando']];
function pscIoSub(){ let v = ''; try{ v = localStorage.getItem(PSC_SUB) || ''; }catch(_){ } return PSC_IO.some(function(x){ return x[0] === v; }) ? v : 'oggi'; }
function pscIoVai(k){
  if (k === pscIoSub()) return;
  try{ localStorage.setItem(PSC_SUB, k); }catch(_){ }
  pscVibra(6);
  pstPaint();
  if (k === 'stai'){ const el = document.getElementById('scLife'); if (el && !el.innerHTML.trim() && typeof scLifePaint === 'function'){ try{ scLifePaint(); }catch(_){ } } }
}
function pscIoHtml(){
  const cur = pscIoSub();
  const seg = '<div class="psc-seg" role="tablist" aria-label="La tua identità">' + PSC_IO.map(function(x){
    return '<button type="button" role="tab" aria-selected="' + (x[0] === cur) + '" class="' + (x[0] === cur ? 'on' : '') + '" onclick="pscIoVai(\'' + x[0] + '\')">' + x[1] + '</button>';
  }).join('') + '</div>';
  let corpo = '';
  try{ corpo = cur === 'oggi' ? pscOggiHtml() : (cur === 'devo' ? pscDevoHtml() : pscStaiHtml()); }catch(_){ corpo = '<p class="pst-nota">Questa scheda non si apre adesso. Riprova fra poco.</p>'; }
  return '<div class="psc-io">' + seg + '<div class="psc-io-c">' + corpo + '</div></div>';
}
function pscOggi(){ const o = pstJ(PSC_OGGI, null); return (o && typeof o === 'object') ? o : null; }
function pscOggiHtml(){
  const o = pscOggi();
  let av = ''; try{ av = localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
  const volto = '<span class="psc-oggi-v"' + (av ? ' style="background-image:url(\'' + String(av).replace(/['()\\]/g, '') + '\')"' : '') + ' aria-hidden="true">' + (av ? '' : '🙂') + '</span>';
  const parole = o && Array.isArray(o.parole) ? o.parole.filter(Boolean) : [];
  if (o && (o.frase || parole.length)){
    return '<div class="psc-oggi">' + volto
      + (o.frase ? '<p class="psc-oggi-f">"' + pstE(o.frase) + '"</p>' : '')
      + (parole.length ? '<div class="psc-parole">' + parole.map(function(p){ return '<em>' + pstE(p) + '</em>'; }).join('') + '</div>' : '')
      + '<button type="button" class="pst-link" onclick="pscOggiApri()">Cambia chi sei oggi</button></div>';
  }
  return '<div class="psc-oggi">' + volto + '<b class="psc-oggi-h">Chi sei oggi?</b><p class="psc-oggi-p">Scrivi una frase e tre parole su di te, adesso.</p>'
    + '<button type="button" class="pst-cta" onclick="pscOggiApri()">Scrivi chi sei oggi</button></div>';
}
function pscOggiApri(){
  const o = pscOggi() || {}, p = Array.isArray(o.parole) ? o.parole : [];
  /* l'esempio viene da quello che l'app sa gia': la frase del vecchio te nella pagina dell'Io Futuro ("Prima dicevo") */
  let es = 'Per esempio, sono una persona che rimanda le cose difficili';
  try{ const id = (typeof ifNuovoMe === 'function' ? ifNuovoMe() : {}).identita; const v = id && id.old_self_line ? String(id.old_self_line).replace(/^Prima dicevo\s*:\s*/i, '').replace(/^["“«]\s*|\s*["”»]\s*\.?$/g, '').trim() : ''; if (v) es = 'Per esempio, ' + v.charAt(0).toLowerCase() + v.slice(1); }catch(_){ }
  pscVibra(6);
  inSheet('<div class="en-foglio psc-fg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="psc-fg-e" aria-hidden="true">🙂</span><h3>Chi sei oggi</h3>'
    + '<label class="psc-lab" for="pscOggiF">Scrivi una frase su di te</label>'
    + '<textarea class="fin psc-fin psc-oggi-in" id="pscOggiF" rows="2" maxlength="140" placeholder="' + pstE(es) + '">' + pstE(o.frase || '') + '</textarea>'
    + '<label class="psc-lab">Scrivi tre parole che ti descrivono</label>'
    + '<div class="psc-tre">' + ['Prima parola', 'Seconda parola', 'Terza parola'].map(function(ph, i){ return '<input class="fin psc-fin" id="pscOggiP' + i + '" maxlength="20" placeholder="' + ph + '" value="' + pstE(p[i] || '') + '">'; }).join('') + '</div>'
    + '<button type="button" class="en-cta psc-salva" onclick="pscOggiSalva()">Salva chi sei oggi</button></div>');
}
function pscOggiSalva(){
  const f = document.getElementById('pscOggiF');
  const frase = String((f && f.value) || '').trim().replace(/\s+/g, ' ').slice(0, 140);
  const parole = [0, 1, 2].map(function(i){ const x = document.getElementById('pscOggiP' + i); return String((x && x.value) || '').trim().slice(0, 20); }).filter(Boolean);
  if (!frase && !parole.length){ pscToast('Scrivi una frase o una parola su di te'); if (f) f.focus(); return; }
  try{ localStorage.setItem(PSC_OGGI, JSON.stringify({ frase: frase, parole: parole, at: Date.now() })); }
  catch(_){ pscToast('La memoria del telefono è piena, non si salva'); return; }
  inSheetChiudi();
  pscVibra([10, 30, 10]);
  pscToast('Salvato chi sei oggi');
  pscRidisegna();
}
/* LA CARD PASSAPORTO: il riassunto della pagina "Il mio io futuro" della replica di Notion (nfNotion), dagli stessi dati */
function pscDevoHtml(){
  let o = {}; try{ o = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : (pstJ('fl_iofuturo', {}) || {}); }catch(_){ o = {}; }
  const id = o && o.identita;
  if (!id || !id.identity_statement){
    return '<div class="psc-oggi"><span class="psc-oggi-v" aria-hidden="true">🧭</span><b class="psc-oggi-h">Il tuo Io Futuro non c’è ancora</b><p class="psc-oggi-p">Scopri chi diventi quando arrivi al sogno.</p>'
      + '<button type="button" class="pst-cta" onclick="if(typeof nfApri===\'function\')nfApri(\'s-home\')">Scopri il tuo Io Futuro</button></div>';
  }
  let im = '', nome = '', sogno = '', data = '';
  try{ im = (typeof nfImmagine === 'function') ? nfImmagine() : ''; }catch(_){ }
  try{ const g = (typeof gnDati === 'function') ? gnDati() : null; nome = g && g.nome ? String(g.nome) : ''; }catch(_){ }
  if (!nome){ try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = u && u.name ? String(u.name) : ''; }catch(_){ } }
  try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  try{ data = (typeof nfDataArrivo === 'function') ? nfDataArrivo() : ''; }catch(_){ }
  const tratti = (Array.isArray(id.traits) ? id.traits : []).map(function(t){ return String(t || '').trim().replace(/[.;]+$/, ''); }).filter(Boolean).slice(0, 3);
  const campo = function(k, v){ return v ? '<small>' + k + '</small><b>' + pstE(v) + '</b>' : ''; };
  return '<button type="button" class="psc-pass" onclick="pscDevoApri()" aria-label="Apri la pagina Il mio io futuro">'
    + '<span class="psc-pass-top"><b>Il mio io futuro</b><i aria-hidden="true">✈️</i></span>'
    + '<span class="psc-pass-mid"><span class="psc-pass-foto"' + (im ? ' style="background-image:url(\'' + String(im).replace(/['()\\]/g, '') + '\')"' : '') + '>' + (im ? '' : '<i aria-hidden="true">🧑‍🚀</i>') + '</span>'
    + '<span class="psc-pass-dati">' + campo('Nome', nome.split(' ')[0]) + campo('Destinazione', sogno) + campo('Arrivo previsto', data) + '</span></span>'
    + '<span class="psc-pass-id">' + pstE(String(id.identity_statement).slice(0, 180)) + '</span>'
    + (tratti.length ? '<span class="psc-pass-tr">' + tratti.map(function(t){ return '<em>' + pstE(t) + '</em>'; }).join('') + '</span>' : '')
    + '<span class="psc-pass-apri">Apri la pagina' + PSC_SVG.avanti + '</span>'
    + '</button>';
}
function pscDevoApri(){
  pscVibra(8);
  if (typeof nfNotion === 'function') nfNotion('s-home');
  else if (typeof nfApri === 'function') nfApri('s-home');
}
/* CHI STAI DIVENTANDO: il pannello vivo #scLife (scores.js), adottato qui. Se e' vuoto (nessun giorno misurato) parla la riga sotto */
function pscStaiHtml(){
  return '<div class="psc-life" data-adotta="scLife"></div><p class="psc-life-vuoto">Il Genio ti dice chi stai diventando dopo il primo giorno di misure.</p>';
}

(function(){
  const css = [
    /* --- dentro al pannello scuro (testo bianco fisso, uguale nei due temi) --- */
    '.psc-amb,.psc-az,.psc-io{display:flex;flex-direction:column;padding-top:8px}',
    '.psc-testa{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 26px;text-align:center}.psc-testa p{margin:0;font:600 14px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.psc-i{flex:none;width:24px;height:24px;padding:0;border:0;border-radius:12px;background:rgba(140,198,255,.2);color:#C8EFFD;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-griglia{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-card{position:relative;min-width:0;aspect-ratio:3/4;border:0;padding:0;border-radius:20px;overflow:hidden;cursor:pointer;display:flex;align-items:flex-end;text-align:left;background:linear-gradient(160deg,#3F9FF4,#0075E3 45%,#001E44);background-size:cover;background-position:center;-webkit-tap-highlight-color:transparent}',
    '.psc-card:active{transform:scale(.98)}',
    /* l'emoji sta in alto, nel suo spazio: centrata a meta' card finiva sotto al nome quando il nome va su due righe */
    '.psc-card:not(.psc-card-piu){flex-direction:column;justify-content:space-between;align-items:stretch;aspect-ratio:auto;min-height:232px}.psc-card.foto{justify-content:flex-end}.psc-card-piu{aspect-ratio:auto;min-height:232px}.psc-card-art{position:relative;z-index:1;align-self:center;margin-top:20px;font-size:46px;line-height:1}',
    '.psc-veil{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 34%,rgba(0,30,68,.86))}',
    '.psc-card-txt{position:relative;display:flex;flex-direction:column;gap:3px;padding:12px;width:100%;box-sizing:border-box;min-width:0}',
    '.psc-card-txt b{font:800 16px/1.2 var(--font-display);color:#fff;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:break-word}',
    '.psc-card-txt i{font:600 12px/1.3 var(--font-body);font-style:normal;color:#C8EFFD}',
    '.psc-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}.psc-chips em{font:700 10.5px/1 var(--font-body);font-style:normal;color:#fff;background:rgba(255,255,255,.18);padding:5px 7px;border-radius:99px;white-space:nowrap}',
    '.psc-card-piu{background:rgba(255,255,255,.04);border:1.5px dashed rgba(140,198,255,.55);flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:12px}',
    '.psc-piu-ic{width:44px;height:44px;border-radius:22px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center}.psc-piu-ic svg{width:20px;height:20px}',
    '.psc-card-piu b{font:800 14px/1.3 var(--font-display);color:#fff}',
    /* azione */
    '.psc-gr{display:flex;flex-direction:column;gap:8px}.psc-gr + .psc-gr{margin-top:22px}',
    '.psc-gr-t{margin:0 0 4px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-att{display:flex;align-items:center;gap:12px;min-height:52px;padding:8px 8px 8px 12px;border-radius:16px;background:rgba(255,255,255,.07)}',
    '.psc-att-i{flex:none;width:32px;height:32px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;overflow:hidden}.psc-att-i img{width:32px;height:32px;object-fit:contain}',
    '.psc-att-n{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;text-align:left}.psc-att-n b{font:700 14px/1.3 var(--font-body);color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psc-att-n small{font:600 12px var(--font-body);color:#C8EFFD}',
    '.psc-att-piu{flex:none;width:40px;height:40px;border:0;border-radius:20px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.psc-blocco-az,.psc-azb{margin-top:30px}.psc-azb .pst-link{margin-top:14px}',
    '.psc-k{margin:0 0 26px;text-align:center;font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.psc-azl{display:flex;flex-direction:column;gap:8px}',
    '.psc-azr{display:flex;align-items:center;gap:12px;width:100%;padding:10px 12px;border:0;border-radius:16px;background:rgba(255,255,255,.07);text-align:left;cursor:pointer}',
    '.psc-azr-e{flex:none;width:40px;height:40px;border-radius:20px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:20px;line-height:1}',
    '.psc-azr-t{flex:1;min-width:0;display:flex;flex-direction:column;align-items:flex-start;gap:5px}.psc-azr-t b{font:700 14.5px/1.35 var(--font-body);color:#fff}',
    '.psc-azr-t small{font:800 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#fff;padding:4px 8px;border-radius:99px;background:#0075E3}.psc-azr-t small.cambia{background:#E63946}',
    '.psc-azv{margin-top:-8px}',
    '.psc-ag .tls-punti{margin-top:20px}.psc-ag .pst-link.muto,.psc-torna{margin-top:4px}',
    '.psc-ponte{display:flex;gap:12px;align-items:flex-start;margin-top:18px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.07);text-align:left}.psc-ponte span{font-size:20px}.psc-ponte p{margin:0;font:600 13.5px/1.45 var(--font-body);color:#fff}.psc-ponte small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:#C8EFFD}',
    /* identita */
    '.psc-seg{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;padding:4px;border-radius:18px;background:rgba(255,255,255,.07)}',
    '.psc-seg button{min-height:44px;border:0;border-radius:14px;background:none;color:rgba(255,255,255,.65);font:700 12px/1.25 var(--font-body);padding:6px 4px;cursor:pointer}.psc-seg button.on{background:#fff;color:#001E44}',
    '.psc-io-c{margin-top:26px;display:flex;flex-direction:column}',
    '.psc-oggi{display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.psc-oggi-v{width:72px;height:72px;border-radius:36px;background:#fff;background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:38px;line-height:1;box-shadow:0 8px 22px rgba(0,0,0,.28)}',
    '.psc-oggi-h{margin-top:14px;font:800 18px var(--font-display);color:#fff}.psc-oggi-p{margin:8px 0 32px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.75)}',
    '.psc-oggi-f{margin:16px 0 0;font:italic 600 17px/1.45 var(--font-body);color:#fff}',
    '.psc-parole{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:18px}.psc-parole em{font:800 13px var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:7px 12px;border-radius:99px}',
    '.psc-oggi .pst-link{margin-top:24px}',
    '.psc-pass{display:flex;flex-direction:column;width:100%;padding:0;border:1px solid rgba(140,198,255,.35);border-radius:20px;overflow:hidden;background:linear-gradient(160deg,#0B3F7A,#001E44);text-align:left;cursor:pointer;box-shadow:0 10px 24px rgba(0,0,0,.25)}',
    '.psc-pass-top{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#0075E3}.psc-pass-top b{font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#fff}.psc-pass-top i{font-style:normal;font-size:18px}',
    '.psc-pass-mid{display:flex;gap:14px;padding:16px}',
    '.psc-pass-foto{flex:none;width:86px;height:110px;border-radius:12px;background:#C8EFFD;background-size:cover;background-position:center 30%;display:flex;align-items:center;justify-content:center;border:3px solid #fff}.psc-pass-foto i{font-style:normal;font-size:40px}',
    '.psc-pass-dati{flex:1;min-width:0;display:flex;flex-direction:column}.psc-pass-dati small{font:800 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.psc-pass-dati small:not(:first-child){margin-top:9px}.psc-pass-dati b{margin-top:2px;font:700 14px/1.3 var(--font-body);color:#fff;overflow-wrap:anywhere}',
    '.psc-pass-id{display:block;margin:0 16px;padding-top:14px;border-top:1px dashed rgba(140,198,255,.4);font:italic 600 14.5px/1.5 var(--font-body);color:#fff}',
    '.psc-pass-tr{display:flex;flex-wrap:wrap;gap:6px;padding:12px 16px 0}.psc-pass-tr em{font:700 12px/1.3 var(--font-body);font-style:normal;color:#001E44;background:#C8EFFD;padding:6px 10px;border-radius:99px}',
    '.psc-pass-apri{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;padding:14px;border-top:1px solid rgba(255,255,255,.1);font:800 14px var(--font-body);color:#8CC6FF}',
    '.psc-life{padding:16px 6px}.psc-life #scLife{margin:0!important}.psc-life .life-wrap{margin:0}.psc-life .life{padding:26px 16px 22px!important}.psc-life .life-big{font-size:clamp(21px,6.4vw,27px)!important;line-height:1.15;overflow-wrap:break-word}',
    '.psc-life-vuoto{display:none;margin:0;text-align:center;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.7)}.psc-life:empty + .psc-life-vuoto,.psc-life:has(> #scLife:empty) + .psc-life-vuoto{display:block}.psc-life:has(> #scLife:empty){display:none}',
    /* --- le pagine a schermo intero (colori del tema) --- */
    '.psc-bar{display:flex;align-items:center}.psc-bar-t{flex:1;text-align:center;font:800 17px var(--font-display);color:var(--navy)}',
    '.psc-pag{padding:12px 20px 40px;max-width:560px;margin:0 auto;display:flex;flex-direction:column}',
    '.psc-foto{position:relative;width:100%;aspect-ratio:16/10;border-radius:22px;border:1.5px dashed var(--line);background-color:var(--card);background-size:cover;background-position:center;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;color:var(--navy)}',
    '.psc-foto.piena{border:0;align-items:flex-end;justify-content:flex-end}',
    '.psc-foto-v{display:flex;flex-direction:column;align-items:center;gap:10px;color:#0075E3}.psc-foto-v b{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-foto-c{display:inline-flex;align-items:center;gap:6px;margin:12px;padding:8px 12px;border-radius:99px;background:rgba(0,30,68,.72);color:#fff;font:700 12.5px var(--font-body)}.psc-foto-c svg{width:16px;height:16px}',
    '.psc-campo{display:flex;flex-direction:column;margin-top:30px}.psc-campo > label{font:800 15px var(--font-display);color:var(--navy)}.psc-campo > small{margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-campo > input,.psc-campo > .psc-tempo,.psc-campo > textarea{margin-top:10px}',
    '.psc-fin{box-sizing:border-box;font-size:16px!important}.psc-n{max-width:120px}.psc-tempo .psc-n{width:84px;flex:none}.psc-nota-in{min-height:64px!important;margin-top:12px!important}',
    '.psc-tempo{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.psc-u{font:700 14px var(--font-body);color:var(--navy)}',
    '.psc-unita{display:flex;gap:2px;padding:3px;border-radius:99px;background:rgba(0,117,227,.1)}.psc-unita button{border:0;background:none;color:var(--navy);font:700 13px var(--font-body);padding:9px 14px;border-radius:99px;cursor:pointer}.psc-unita button.on{background:#0075E3;color:#fff}',
    'body.dark .psc-unita{background:rgba(140,198,255,.14)}',
    '.psc-salva{margin-top:32px}',
    '.psc-via{display:block;margin:16px auto 0;border:0;background:none;color:#E63946;font:700 14px var(--font-body);padding:8px;cursor:pointer}',
    '.psc-tel-prev{display:flex;justify-content:center;margin-top:6px}',
    '.psc-tel-schermo{width:150px;aspect-ratio:9/19;border-radius:26px;border:5px solid #001E44;background:linear-gradient(160deg,#3F9FF4,#001E44);background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;font-size:44px;box-shadow:0 14px 30px rgba(0,30,68,.25)}',
    'body.dark .psc-tel-schermo{border-color:#3F9FF4}',
    '.psc-tel-p{margin:20px 0 0;text-align:center;font:600 14.5px/1.45 var(--font-body);color:var(--navy)}',
    '.psc-fonti{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:16px}.psc-fonti button{border:1.5px solid #3F9FF4;background:var(--card);color:var(--navy);font:700 13.5px var(--font-body);padding:10px 14px;border-radius:99px;cursor:pointer}',
    '.psc-blocco{margin-top:30px}.psc-pag .psc-k{color:#0075E3}body.dark .psc-pag .psc-k{color:#8CC6FF}',
    '.psc-tiles{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.psc-tile{display:flex;flex-direction:column;align-items:center;gap:12px;padding:18px 12px;border-radius:20px;border:0;background:#0075E3;color:#fff;cursor:pointer;text-align:center}.psc-tile span{font-size:28px;line-height:1}.psc-tile b{font:800 14px/1.3 var(--font-body)}.psc-tile small{font:600 11.5px var(--font-body);color:#C8EFFD}',
    '.psc-tile.spento{opacity:.45}',
    '.psc-avviso{margin:16px 0 0;padding:12px 14px;border-radius:16px;background:rgba(230,57,70,.1);color:var(--navy);font:600 13.5px/1.45 var(--font-body)}body.dark .psc-avviso{background:rgba(230,57,70,.18)}',
    '.psc-riga-sw{display:flex;align-items:center;gap:14px;padding:16px;border-radius:20px;background:var(--card);border:1px solid var(--line)}.psc-riga-sw > div{flex:1;min-width:0}.psc-riga-sw b{display:block;font:800 15px/1.3 var(--font-body);color:var(--navy)}.psc-riga-sw small{display:block;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.psc-riga-sw.chiusa{cursor:pointer}.psc-prem{display:inline-block;margin-top:8px;padding:4px 9px;border-radius:99px;background:#001E44;color:#fff;font:800 11px var(--font-body);letter-spacing:.04em}body.dark .psc-prem{background:#0075E3}',
    '.psc-sw-chiuso{opacity:.6;pointer-events:none}',
    /* --- i fogli --- */
    '.psc-fg{text-align:center}.psc-fg-e{display:block;font-size:40px;line-height:1;margin-top:8px}.psc-fg h3{margin:14px 26px 26px!important}',
    '.psc-fg-p{margin:-12px 0 32px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.psc-fg-da{margin:-14px 0 24px;font:600 13.5px var(--font-body);color:var(--muted)}',
    '.psc-fg-2{display:block;width:100%;margin-top:12px;min-height:50px;border:1.5px solid var(--line);border-radius:25px;background:none;color:var(--navy);font:700 15px var(--font-body);cursor:pointer}',
    '.psc-lab{display:block;margin:22px 0 10px;text-align:left;font:800 14px var(--font-display);color:var(--navy)}',
    '.psc-scelta{display:grid;grid-template-columns:1fr 1fr;gap:8px}.psc-scelta button{min-height:52px;border:1.5px solid var(--line);border-radius:16px;background:none;color:var(--navy);font:700 13.5px/1.3 var(--font-body);padding:8px;cursor:pointer}',
    '.psc-scelta button.on.cambia{background:#E63946;border-color:#E63946;color:#fff}.psc-scelta button.on.nuova{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.psc-emoji{display:grid;grid-template-columns:repeat(9,1fr);gap:4px}.psc-emoji button{aspect-ratio:1;border:1.5px solid transparent;border-radius:12px;background:rgba(0,117,227,.08);font-size:18px;line-height:1;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#0075E3;background-size:cover;background-position:center}',
    '.psc-emoji button.on{border-color:#0075E3;background-color:rgba(0,117,227,.18)}.psc-emoji-foto svg{width:18px;height:18px}body.dark .psc-emoji button{background-color:rgba(140,198,255,.12);color:#8CC6FF}',
    '.psc-tre{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.psc-tre input{min-width:0;padding:12px 8px!important;text-align:center}',
    '.psc-oggi-in{min-height:72px!important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
