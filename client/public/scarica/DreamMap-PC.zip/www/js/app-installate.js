/* ===========================================================================================
   LE APP INSTALLATE, LETTE PRIMA (0.9.289, Andrea)

   "Nella lista di blocco le app ci mettono troppo a venire lette: compare 'Leggo le app installate',
   che un utente non dovrebbe mai vedere. Devono essere lette prima, come il Report fa con i dati."
   Ogni pagina (lista di blocco, Blocco rapido, categorie, gruppi, Full Focus, Report) chiedeva al
   telefono l'elenco da capo, ogni volta che si apriva. Adesso l'elenco si legge una volta poco dopo
   l'avvio, si tiene in memoria e in una copia salvata (per l'avvio dopo), e chi lo chiede lo riceve
   subito; dopo dieci minuti si rilegge in sottofondo, senza far aspettare nessuno.
   =========================================================================================== */
const FLA = { list: null, at: 0, p: null };
(function(){
  try{
    const c = JSON.parse(localStorage.getItem('fl_apps_cache') || 'null');
    if (c && Array.isArray(c.apps) && c.apps.length){ FLA.list = c.apps; FLA.at = c.at || 0; }
  }catch(_){ }
})();
function flAppsCarica(){
  if (FLA.p) return FLA.p;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalledApps) return Promise.resolve({ apps: FLA.list || [] });
  FLA.p = NATIVE.getInstalledApps().then(function(r){
    const apps = (r && r.apps) || [];
    FLA.list = apps; FLA.at = Date.now(); FLA.p = null;
    try{
      let j = JSON.stringify({ at: FLA.at, apps: apps });
      if (j.length > 250000) j = JSON.stringify({ at: FLA.at, apps: apps.map(function(a){ return { packageName: a.packageName, label: a.label, system: a.system }; }) });
      localStorage.setItem('fl_apps_cache', j);
    }catch(_){ }
    return r;
  }, function(e){ FLA.p = null; throw e; });
  return FLA.p;
}
/** L'elenco delle app: subito, se c'e' gia'; altrimenti la lettura (una sola, anche se la chiedono in tanti). */
function flApps(){
  if (FLA.list && FLA.list.length){
    if (Date.now() - FLA.at > 10 * 60000) flAppsCarica().catch(function(){ });
    return Promise.resolve({ apps: FLA.list });
  }
  return flAppsCarica();
}
if (typeof document !== 'undefined'){
  setTimeout(function(){ flAppsCarica().catch(function(){ }); }, 2500);
}
