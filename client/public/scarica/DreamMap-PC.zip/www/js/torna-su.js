/* ===========================================================================================
   TORNA IN CIMA (0.9.245), come Duolingo: nella Roadmap, quando sei sceso lungo il sentiero,
   in basso a destra compare un quadrato con la freccia in su che ti riporta in cima.
   =========================================================================================== */
function tsTab(){ return document.getElementById('tab-mappa'); }
/* 0.9.264, Andrea: lag nello scroll. Questa funzione girava a OGNI evento di scroll e leggeva offsetParent e
   scrollTop, che obbligano il telefono a ricalcolare la pagina: 670 ms su 5 secondi di scroll nella Mappa (profilo
   CPU su BlueStacks). Adesso nessuno ascolta lo scroll: un segnaposto di 1 px in cima alla scheda e un
   IntersectionObserver che si accorge da solo quando il segnaposto e' oltre 700 px sopra lo schermo. */
let TS_SOPRA = false, TS_GIU = false;
/* 0.9.321, Andrea (come Duolingo): se stai guardando i capitoli prima dell'ultima tappa raggiunta, la freccia guarda in giu' e
   ti porta li'. Si osserva il nodo, senza ascoltare lo scroll (vedi sopra); se la mappa si ridisegna si riaggancia. */
function tsNodo(){ try{ const cur = (typeof sdCorrente === 'function') ? sdCorrente() : null, id = cur && cur.nodo ? cur.nodo.id : ''; return id ? document.querySelector('#mppSentiero .sd-nodo[data-id="' + id + '"]') : null; }catch(_){ return null; } }
function tsOsservaNodo(tab){
  const n = tsNodo();
  if (!('IntersectionObserver' in window)) return;
  if (!tab._tsNodoIo) tab._tsNodoIo = new IntersectionObserver(function(v){
    const e = v[v.length - 1], fondo = e.rootBounds ? e.rootBounds.bottom : window.innerHeight;
    TS_GIU = !e.isIntersecting && e.boundingClientRect.top >= fondo;
    tsAggiorna();
  }, { root: tab, threshold: 0 });
  if (tab._tsNodo !== n){
    if (tab._tsNodo) tab._tsNodoIo.unobserve(tab._tsNodo);
    tab._tsNodo = n; TS_GIU = false;
    if (n) tab._tsNodoIo.observe(n);
  }
  const s = document.getElementById('mppSentiero');
  if (s && !s._tsOss && 'MutationObserver' in window){ s._tsOss = 1; new MutationObserver(function(){ tsOsservaNodo(tab); }).observe(s, { childList: true }); }
}
function tsAggiorna(){
  const b = document.getElementById('tsSu'), tab = tsTab(); if (!b || !tab) return;
  let rotta = true; try{ rotta = typeof mppVistaCur !== 'function' || mppVistaCur() === 'rotta'; }catch(_){ }
  /* 0.9.278, Andrea: la freccia stava sopra al questionario dei blocchi. Solo quando si vede davvero la Mappa (la
     schermata principale e' quella davanti), mai sopra a un'altra schermata aperta da li'. */
  const casa = document.getElementById('s-home');
  const su = !!(tab.classList.contains('on') && rotta && TS_SOPRA && casa && casa.classList.contains('active'));
  if (b._su !== su){ b._su = su; b.classList.toggle('su', su); }
  b.classList.toggle('giu', TS_GIU);
  b.setAttribute('aria-label', TS_GIU ? 'Vai all\u2019ultima tappa raggiunta' : 'Torna in cima');
  /* 0.9.311, Andrea: sopra alla bolla della modalita' severa ha senso solo quando la bolla c'e'. Altrimenti la freccia
     sta in basso a destra, esattamente dove apparirebbe la bolla. */
  const bolla = document.querySelector('.strict-bubble');
  b.classList.toggle('basso', !(bolla && bolla.classList.contains('on')));
  if (bolla && !bolla._tsOss && 'MutationObserver' in window){ bolla._tsOss = 1; new MutationObserver(tsAggiorna).observe(bolla, { attributes: true, attributeFilter: ['class'] }); }
}
function tsSegnaposto(tab){
  /* lo stesso segnaposto dell'intestazione (blkhero.js flHeaderSegno): uno solo, sempre primo nella scheda */
  if (typeof flHeaderSegno === 'function') flHeaderSegno(tab);
  const m = tab.querySelector(':scope > .fl-segno-cima'); if (!m) return;
  /* 0.9.331, Andrea: "a volte non compare piu'". LE CAUSE: l'osservatore avvisa solo quando il segnaposto entra o esce. Tornando sulla scheda gia' scesi non entra e non esce, e la
     freccia restava com'era quando la scheda si era nascosta, cioe' spenta. E se il segnaposto veniva rifatto, si restava a osservare quello vecchio. Quindi: il conto si rifa' a ogni
     ritorno sulla scheda e a fine scorrimento (una lettura sola, non a ogni evento di scroll), e il segnaposto nuovo si riaggancia. */
  if (tab._tsIo && tab._tsM !== m){ try{ if (tab._tsM) tab._tsIo.unobserve(tab._tsM); tab._tsIo.observe(m); }catch(_){ } }
  tab._tsM = m;
  if (!tab._tsFine){ tab._tsFine = 1; tab.addEventListener('scrollend', tsRicalcola, { passive: true }); }
  if (!tab._tsIo && 'IntersectionObserver' in window){
    tab._tsIo = new IntersectionObserver(function(v){
      const e = v[v.length - 1];
      TS_SOPRA = !e.isIntersecting && e.boundingClientRect.top < (e.rootBounds ? e.rootBounds.top : 0);
      tsAggiorna();
    }, { root: tab, rootMargin: '700px 0px 0px 0px', threshold: 0 });
    tab._tsIo.observe(m);
  }
}
function tsRicalcola(){
  const tab = tsTab(); if (!tab || !tab.classList.contains('on')) return;
  TS_SOPRA = tab.scrollTop > 700;
  const n = tsNodo();
  if (n){ const r = n.getBoundingClientRect(), t = tab.getBoundingClientRect(); TS_GIU = r.width > 0 && r.top >= t.bottom; }
  tsAggiorna();
}
function tsSu(){
  const tab = tsTab(); if (!tab) return;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const n = TS_GIU ? tsNodo() : null;
  if (n){ try{ n.scrollIntoView({ behavior: 'smooth', block: 'center' }); }catch(_){ } return; }
  tab.scrollTo({ top: 0, behavior: 'smooth' });
}
(function(){
  const b = document.createElement('button');
  b.type = 'button'; b.id = 'tsSu'; b.setAttribute('aria-label', 'Torna in cima');
  b.innerHTML = '<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M12 19V5M5.5 11.5L12 5l6.5 6.5" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  b.addEventListener('click', tsSu);
  /* 0.9.309, Andrea (PC): la freccia stava fuori dal telefono, a destra nella finestra. Era aggiunta a document.body e
     "fixed" la ancorava alla finestra; dentro #phone (che sul PC ha transform) "fixed" vale rispetto al telefono.
     Sul telefono vero #phone non ha transform e la finestra e' il telefono: non cambia niente. */
  const metti = function(){ if (!document.getElementById('tsSu')) (document.getElementById('phone') || document.body).appendChild(b); const tab = tsTab(); if (tab){ tsSegnaposto(tab); tsOsservaNodo(tab); } tsAggiorna(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', metti); else setTimeout(metti, 0);
  ['fl:tab', 'fl:screen'].forEach(function(e){ document.addEventListener(e, function(){ setTimeout(metti, 60); setTimeout(tsRicalcola, 250); }); });
  const st = document.createElement('style');
  st.textContent = '#tsSu{position:fixed;right:16px;bottom:calc(172px + env(safe-area-inset-bottom));z-index:60;width:54px;height:54px;border-radius:16px;border:2px solid #C9D9EE;background:#fff;color:#0075E3;display:grid;place-items:center;box-shadow:0 4px 0 #C9D9EE,0 10px 22px rgba(15,32,65,.14);cursor:pointer;opacity:0;transform:translateY(16px) scale(.9);pointer-events:none;transition:opacity .22s ease,transform .22s ease}'
    + '#tsSu.basso{bottom:calc(84px + env(safe-area-inset-bottom))}#tsSu svg{transition:transform .25s ease}#tsSu.giu svg{transform:rotate(180deg)}'
    + '#tsSu.su{opacity:1;transform:none;pointer-events:auto}#tsSu:active{transform:translateY(3px);box-shadow:0 1px 0 #C9D9EE}'
    + 'body.dark #tsSu{background:#14234A;border-color:#2C4170;color:#5AAEFF;box-shadow:0 4px 0 #2C4170,0 10px 22px rgba(0,0,0,.3)}'
    + 'body.sheet-aperto #tsSu{opacity:0!important;pointer-events:none!important}';
  document.head.appendChild(st);
})();
