/* ===========================================================================================
   LE CHIAMATE CHIESTE DALLA TUA AI E IL BIVIO DELL'IDEA (0.9.367)

   Andrea: "voglio dare agli utenti la possibilita' di chiedere al proprio agente di creare trigger su misura per la chiamata dei
   sogni, con uno strumento del server MCP. Per esempio una nuova idea che distrae dal piano: l'AI la riconosce, e prima di dare il
   punto nella partita me lo fa notare con una chiamata in arrivo. Dopo la risposta, al posto del video, il bivio con le due strade e
   la data d'arrivo ricalcolata sotto gli occhi, se decido di farla lo stesso: cosi' vedo il PREZZO di quella scelta".

   Il server (focuslockPonte.ts): crea_condizione_chiamata salva la condizione, fai_squillare mette in coda una chiamata. Qui:
   - pcSync(): legge la coda (al sync del ponte, all'avvio e a ogni ritorno nell'app) e fa squillare la chiamata vera
     (NATIVE.ringDreamCall, la stessa delle altre chiamate dei sogni); senza il telefono, la schermata di chiamata in pagina;
   - dopo la risposta (dreamcall.js, dcAnswerOpen -> pcDopoRisposta): se la chiamata portava un'idea, il bivio dell'idea;
   - il bivio: due strade, la data d'arrivo che scorre fino a quella nuova se segui l'idea, e la scelta decide il punto della
     partita (resti sul piano: punto al nuovo te; segui l'idea: punto al vecchio te);
   - le condizioni si vedono nelle impostazioni della chiamata (pcCondizioniHtml), e si tolgono da li'.
   =========================================================================================== */
const PC_K = 'fl_pc_idea';
const PC_COND = 'fl_pc_cond';
function pcEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function pcOn(){ return typeof pntOn === 'function' && pntOn() && typeof frApi === 'function'; }
let PC_AT = 0;
async function pcSync(){
  if (!pcOn() || Date.now() - PC_AT < 30000) return;
  PC_AT = Date.now();
  let r = null;
  try{ r = await frApi('GET', '/api/focuslock/ponte/chiamate?chiave=' + encodeURIComponent(pntChiave())); }catch(_){ return; }
  if (!r) return;
  /* le chiamate create dal tuo agente nell'app restano (da: 'agente'); quelle della tua AI collegata arrivano dal server */
  try{ const agente = pcCondizioni().filter(function(c){ return c && c.da === 'agente'; }); localStorage.setItem(PC_COND, JSON.stringify((r.condizioni || []).concat(agente))); }catch(_){ }
  const c = (r.chiamate || []).slice().sort(function(a, b){ return a.at - b.at; })[0];
  if (!c) return;
  try{ await frApi('POST', '/api/focuslock/ponte/chiamate/presa', { chiave: pntChiave(), id: c.id }); }catch(_){ }
  pcSquilla(c);
}
async function pcSquilla(c){
  try{ localStorage.setItem(PC_K, JSON.stringify({ at: Date.now(), titolo: c.titolo, testo: c.testo, idea: c.idea || '', ore: +c.ore || 0 })); }catch(_){ }
  try{ if (typeof dcUltimoMotivoSegna === 'function') dcUltimoMotivoSegna('ponte', c.titolo); }catch(_){ }
  let cfg = {}; try{ cfg = (typeof dcCfg === 'function') ? dcCfg() : {}; }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.ringDreamCall){
    try{ const r = await NATIVE.ringDreamCall({ title: cfg.title, sub: cfg.sub, label: cfg.label, line: c.titolo, motivo: 'ponte', titolo: c.titolo }); if (r && r.shown) return; }catch(_){ }
  }
  /* senza la chiamata vera (il PC, il browser): la si apre direttamente */
  pcDopoRisposta(true);
}
/** Dopo la risposta: true se c'era una chiamata della tua AI (e ci pensa lei), false altrimenti. */
function pcDopoRisposta(forza){
  let x = null; try{ x = JSON.parse(localStorage.getItem(PC_K) || 'null'); }catch(_){ }
  if (!x || Date.now() - x.at > 30 * 60000) return false;
  try{ localStorage.removeItem(PC_K); }catch(_){ }
  if (x.idea) { pcBivio(x); return true; }
  if (typeof inSheet === 'function'){
    inSheet('<div class="en-foglio pc-msg"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="pc-msg-e" aria-hidden="true">📞</span><h3>' + pcEsc(x.titolo) + '</h3>'
      + (x.testo && x.testo !== x.titolo ? '<p class="pc-msg-s">' + pcEsc(x.testo) + '</p>' : '') + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
    return true;
  }
  return !!forza;
}

/* ---------------------------------------------------------------- il bivio dell'idea */
function pcRitardoGiorni(ore){
  /* le ore che l'idea ruba si tolgono dal tempo che dai al piano: con le ore al giorno delle opzioni di viaggio, o due di base */
  let alGiorno = 2;
  try{ const o = (typeof serOpzioni === 'function') ? serOpzioni() : null; const h = o ? (+o.ore || +o.oreGiorno || 0) : 0; if (h > 0) alGiorno = h; }catch(_){ }
  return Math.max(1, Math.ceil((ore > 0 ? ore : 6) / alGiorno));
}
function pcData(t){ try{ return new Date(t).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' }); }catch(_){ return ''; } }
function pcBivio(x){
  let arrivo = null; try{ arrivo = (typeof etaArrivo === 'function') ? etaArrivo() : null; }catch(_){ }
  const base = arrivo && isFinite(arrivo.at) ? arrivo.at : null;
  const gg = pcRitardoGiorni(x.ore);
  let w = document.getElementById('pcBivio');
  if (!w){ w = document.createElement('div'); w.id = 'pcBivio'; w.className = 'pc-bv'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.__x = x; w.__gg = gg;
  w.innerHTML = '<div class="pc-bv-in">'
    + '<p class="pc-bv-k">Un bivio</p>'
    + '<h2 class="pc-bv-t">' + pcEsc(x.idea) + '</h2>'
    + (x.testo ? '<p class="pc-bv-s">' + pcEsc(x.testo) + '</p>' : '')
    + '<svg class="pc-bv-strade" viewBox="0 0 300 150" aria-hidden="true"><path d="M150 150 C150 100 150 80 70 20" class="pc-bv-r a"/><path d="M150 150 C150 100 150 80 230 20" class="pc-bv-r b"/><circle cx="150" cy="140" r="7" fill="#fff"/></svg>'
    + '<div class="pc-bv-due">'
    +   '<div class="pc-bv-c a"><small>Resti sul piano</small><b>' + (base ? pcEsc(pcData(base)) : 'In rotta') + '</b></div>'
    +   '<div class="pc-bv-c b"><small>Segui l’idea</small><b id="pcBvData">' + (base ? pcEsc(pcData(base)) : '+' + gg + ' giorni') + '</b><em id="pcBvPiu">+' + gg + (gg === 1 ? ' giorno' : ' giorni') + '</em></div>'
    + '</div>'
    + '<p class="pc-bv-prezzo">Seguirla ti costa circa <b>' + gg + (gg === 1 ? ' giorno' : ' giorni') + '</b> di strada verso il sogno.</p>'
    + '<div class="pc-bv-bot"><button type="button" class="pc-bv-cta" onclick="pcScegli(false)">Resto sul piano</button>'
    + '<button type="button" class="pc-bv-no" onclick="pcScegli(true)">La faccio lo stesso</button>'
    + '<button type="button" class="pc-bv-caveau" onclick="pcCaveau()">Mettila nel caveau delle idee</button></div></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ if (typeof flVibra === 'function') flVibra([20, 40, 20]); }catch(_){ }
  /* la data che scorre: dalla data di oggi a quella nuova, giorno dopo giorno, sotto gli occhi */
  if (base){
    const el = document.getElementById('pcBvData'); let i = 0;
    const passo = function(){
      if (!el.isConnected) return;
      i = Math.min(gg, i + Math.max(1, Math.ceil(gg / 24)));
      el.textContent = pcData(base + i * 86400000);
      if (i < gg) setTimeout(passo, 45); else el.classList.add('fine');
    };
    setTimeout(passo, 900);
  }
}
function pcChiudi(){ const w = document.getElementById('pcBivio'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 200); }
function pcScegli(segue){
  const w = document.getElementById('pcBivio'); const x = w ? w.__x : null;
  const idea = x ? String(x.idea).slice(0, 60) : 'un’idea';
  try{
    if (segue){ if (typeof mgLog === 'function') mgLog('old', 'Idea fuori rotta seguita: ' + idea); if (typeof mtOldPoint === 'function') mtOldPoint(); }
    else { if (typeof mgLog === 'function') mgLog('neo', 'Idea fuori rotta lasciata andare: ' + idea); if (typeof mtFocusPoint === 'function') mtFocusPoint(); }
  }catch(_){ }
  pcChiudi();
  if (typeof toast === 'function') toast(segue ? 'Punto al vecchio te: la strada si allunga' : 'Punto al nuovo te: resti sulla strada');
}
function pcCaveau(){
  const w = document.getElementById('pcBivio'); const x = w ? w.__x : null;
  let ok = false;
  try{ if (x && typeof cvAggiungi === 'function'){ ok = cvAggiungi(x.idea); } }catch(_){ }
  if (!ok){ try{ const l = JSON.parse(localStorage.getItem('fl_caveau_ponte') || '[]') || []; l.push({ t: x ? x.idea : '', at: Date.now() }); localStorage.setItem('fl_caveau_ponte', JSON.stringify(l.slice(-50))); }catch(_){ } }
  pcScegli(false);
}

/* ---------------------------------------------------------------- le condizioni, nelle impostazioni della chiamata */
/* 0.9.380, Andrea: "ho Premium e mi compare Collega la tua AI: con Premium si apre la chat con il tuo agente, che crea la chiamata con i suoi
   strumenti. Su misura dalla tua AI non vuol dire niente, e il pannello deve essere come gli altri, che risalti". Un pannello con il suo
   titolo, le chiamate gia' create, e un pulsante solo: con Premium la chat con il tuo agente, senza la tua AI collegata */
function pcPremiumOk(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function pcCondizioni(){ try{ return JSON.parse(localStorage.getItem(PC_COND) || '[]') || []; }catch(_){ return []; } }
function pcCondizioniHtml(){
  const l = pcCondizioni(), prem = pcPremiumOk();
  const btn = prem
    ? '<button type="button" class="pc-cond-cta" onclick="pcCondChiedi()">Chiedila al tuo agente</button>'
    : (pcOn() ? '<p class="pc-cond-p">Chiedi alla tua AI collegata di creare la chiamata: lei usa gli strumenti di DreamMap.</p>' : '<button type="button" class="pc-cond-cta" onclick="if(typeof pntCollegaApri===\'function\')pntCollegaApri()">Collega la tua AI</button>');
  return '<div class="pc-cond-box"><div class="pc-cond-h"><span aria-hidden="true">📞</span><b>Una chiamata quando succede qualcosa di preciso</b></div>'
    + '<p class="pc-cond-p">Per esempio quando apri un’app dopo le 22, o quando ti viene un’idea che non c’entra con il piano.</p>'
    + (l.length ? l.map(function(c){ return '<div class="pc-cond"><div><b>' + pcEsc(c.titolo) + '</b><small>' + pcEsc(c.testo) + '</small></div><button type="button" aria-label="Togli" onclick="pcCondVia(' + (+c.id) + ')">✕</button></div>'; }).join('') : '')
    + btn + '</div>';
}
async function pcCondVia(id){
  try{ localStorage.setItem(PC_COND, JSON.stringify(pcCondizioni().filter(function(c){ return c.id !== id; }))); }catch(_){ }
  try{ if (typeof dcPaint === 'function') dcPaint(); }catch(_){ }
  try{ await frApi('POST', '/api/focuslock/ponte/chiamate/presa', { chiave: pntChiave(), id: id, via: true }); }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(function(){ pcSync().catch(function(){ }); }, 3500); });
setTimeout(function(){ pcSync().catch(function(){ }); }, 9000);
setInterval(function(){ if (!document.hidden) pcSync().catch(function(){ }); }, 120000);

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.pc-bv{position:fixed;inset:0;z-index:9850;background:radial-gradient(120% 80% at 50% 0%,#0B2A5B,#001E44 60%);color:#fff;opacity:0;transition:opacity .25s;overflow-y:auto}.pc-bv.in{opacity:1}.pc-bv[hidden]{display:none}',
    '.pc-bv-in{min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 40px) 24px calc(env(safe-area-inset-bottom,0px) + 26px)}',
    '.pc-bv-k{margin:0;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.pc-bv-t{margin:14px 0 0;max-width:22ch;font:900 24px/1.25 var(--font-display)}',
    '.pc-bv-s{margin:12px 0 0;max-width:32ch;font:500 15px/1.5 var(--font-body);color:#C8EFFD}',
    '.pc-bv-strade{width:min(300px,80vw);height:auto;margin-top:26px}',
    '.pc-bv-r{fill:none;stroke-width:10;stroke-linecap:round;stroke-dasharray:240;stroke-dashoffset:240;animation:pcStrada .9s ease forwards}.pc-bv-r.a{stroke:#3F9FF4}.pc-bv-r.b{stroke:#E63946;animation-delay:.25s}',
    '@keyframes pcStrada{to{stroke-dashoffset:0}}',
    '.pc-bv-due{display:flex;gap:12px;width:100%;margin-top:-6px}',
    '.pc-bv-c{flex:1;padding:16px 10px;border-radius:18px;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.12)}.pc-bv-c.a{border-color:#3F9FF4}.pc-bv-c.b{border-color:#E63946}',
    '.pc-bv-c small{display:block;font:700 12.5px var(--font-body);color:#C8EFFD}.pc-bv-c b{display:block;margin-top:8px;font:800 16px/1.3 var(--font-display)}.pc-bv-c b.fine{color:#FF8A92}',
    '.pc-bv-c em{display:block;margin-top:6px;font:800 13px var(--font-body);font-style:normal;color:#FF8A92}',
    '.pc-bv-prezzo{margin:26px 0 0;max-width:30ch;font:600 15px/1.5 var(--font-body);color:#fff}',
    '.pc-bv-bot{width:100%;display:flex;flex-direction:column;align-items:center;gap:10px;margin-top:auto;padding-top:32px}',
    '.pc-bv-cta{width:100%;min-height:56px;border:0;border-radius:28px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.pc-bv-no{width:100%;min-height:50px;border:1.5px solid rgba(255,255,255,.35);border-radius:25px;background:none;color:#fff;font:700 15px var(--font-body);cursor:pointer}',
    '.pc-bv-caveau{min-height:44px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);cursor:pointer}',
    '.pc-cond{display:flex;align-items:center;gap:12px;padding:14px;margin-top:10px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}.pc-cond div{flex:1;min-width:0}.pc-cond b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}.pc-cond small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    'body.dark .pc-cond b{color:#fff}',
    '.pc-cond button{flex:none;width:34px;height:34px;border:0;border-radius:50%;background:#EAF2FB;color:#001E44;cursor:pointer}body.dark .pc-cond button{background:#1B2B48;color:#fff}',
    '.pc-cond-link{margin-top:8px;padding:8px 0;border:0;background:none;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}body.dark .pc-cond-link{color:#8CC6FF}',
    '.pc-msg{text-align:center}.pc-msg-e{display:block;font-size:44px;margin:6px 0 14px}.pc-msg-s{margin:10px 0 28px!important;font:500 15px/1.5 var(--font-body);color:var(--muted)}'
  ].join('');
  document.head.appendChild(st);
})();

function pcCondChiedi(){
  const prem = (typeof agPremium === 'function') ? agPremium() : ((typeof pscPremium === 'function') ? pscPremium() : true);
  if (typeof agPopover === 'function'){
    agPopover('', { titolo: 'Una chiamata su misura', pill: ['Chiamami quando apro un’app che mi distrae dopo le 22', 'Chiamami se per due giorni non faccio una tappa', 'Chiamami quando ti racconto un’idea fuori dal piano'] });
    return;
  }
  if (!prem && typeof flPremiumApri === 'function') flPremiumApri();
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.pc-cond-box{margin-top:16px;padding:16px;border-radius:18px;background:linear-gradient(170deg,#0B2E5E,#001E44);color:#fff}.pc-cond-h{display:flex;align-items:center;gap:10px}.pc-cond-h span{font-size:22px}.pc-cond-h b{font:800 16px/1.3 var(--font-display);color:#fff}.pc-cond-p{margin:8px 0 0;font:500 14px/1.45 var(--font-body);color:rgba(232,241,255,.85)}.pc-cond-box .pc-cond{background:rgba(255,255,255,.08);border-color:rgba(140,198,255,.25);color:#fff}.pc-cond-box .pc-cond b{color:#fff}.pc-cond-box .pc-cond small{color:rgba(200,225,255,.75)}.pc-cond-cta{display:block;width:100%;min-height:48px;margin:14px 0 0;border:0;border-radius:24px;background:#fff;color:#001E44;font:800 15px var(--font-body);cursor:pointer}'; document.head.appendChild(st); })();
