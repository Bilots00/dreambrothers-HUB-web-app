/* ===========================================================================================
   LE SCORCIATOIE DI DREAM, TUE (0.9.245)

   Andrea: le scorciatoie scorrevoli di Dream devono essere personalizzabili da "Personalizza
   Dream": spostabili (si trascinano), rinominabili, eliminabili, e se ne aggiungono di nuove
   che aprono una nota del telefono o una pagina del piano (la replica di Notion).
   - fl_dream_chips = { v: 1, chips: [{ id, ico, n, on, link?: { t: 'nota'|'notion', id } }] }
   - quelle dell'app (protezione, umore...) si tolgono e si rimettono; quelle aggiunte si eliminano.
   =========================================================================================== */
const DCH_KEY = 'fl_dream_chips';
const DCH_BASE = [
  { id: 'protezione', ico: '🛡️', n: 'Protezione', az: 'blPaginaApri()' },
  { id: 'umore', ico: '🌤️', n: 'Controllo dell’umore', az: "if(typeof umScorciatoia==='function')umScorciatoia()" },
  { id: 'respiro', ico: '🌬️', n: 'Respiro guidato', az: "if(typeof rsApri==='function')rsApri({da:'dream'})" },
  { id: 'ispirazione', ico: '❝', n: 'Ispirazione quotidiana', az: "if(typeof scOpenInspire==='function')scOpenInspire()" },
  { id: 'appunti', ico: '🪶', n: 'I miei appunti', az: "if(typeof noApri==='function')noApri('')" },
  { id: 'suoni', ico: '🎵', n: 'Suoni per concentrarsi', az: "if(typeof sndPaginaApri==='function')sndPaginaApri()" },
  { id: 'report', ico: '📊', n: 'Report', az: "switchTab('insights')" },
  { id: 'assenze', ico: '📅', n: 'Date d’assenza', az: "if(typeof asApri==='function')asApri('dream')" }
];
const DCH = { drag: null };
function dchEsc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function dchCfg(){
  let c = null; try{ c = JSON.parse(localStorage.getItem(DCH_KEY) || 'null'); }catch(_){ c = null; }
  if (!c || !Array.isArray(c.chips)) c = { v: 1, chips: [] };
  /* quelle dell'app che mancano entrano al loro posto di serie */
  DCH_BASE.forEach(function(b, i){
    if (c.chips.some(function(x){ return x.id === b.id; })) return;
    const prima = i > 0 ? c.chips.findIndex(function(x){ return x.id === DCH_BASE[i - 1].id; }) : -1;
    const v = { id: b.id, ico: b.ico, n: b.n, on: true };
    if (prima >= 0) c.chips.splice(prima + 1, 0, v); else if (i === 0) c.chips.unshift(v); else c.chips.push(v);
  });
  return c;
}
function dchSalva(c){ try{ localStorage.setItem(DCH_KEY, JSON.stringify(c)); }catch(_){ } dchRidisegna(); }
function dchAzione(x){
  if (x.link){ return "dchApriLink('" + x.link.t + "','" + String(x.link.id).replace(/[^A-Za-z0-9_\-]/g, '') + "')"; }
  const b = DCH_BASE.filter(function(y){ return y.id === x.id; })[0];
  return b ? b.az : '';
}
function dchApriLink(t, id){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  if (t === 'nota'){ if (typeof noApri === 'function') noApri(id); return; }
  if (t === 'notion'){
    const f = document.getElementById('ntFrame');
    const w = f && f.contentWindow;
    if (typeof NT !== 'undefined' && NT.pronto && w && typeof w.flNotionApriPagina === 'function'){ if (typeof ntApri === 'function') ntApri(0); try{ w.flNotionApriPagina(id); }catch(_){ } return; }
    if (f){
      try{ if (typeof STF !== 'undefined') STF.ritorno = localStorage.getItem('fl_tab') || 'rotta'; }catch(_){ }
      f.setAttribute('src', 'notion/index.html?v=' + Date.now() + '#pagina=' + encodeURIComponent(id));
      if (typeof NT !== 'undefined'){ NT.pronto = true; NT.aperto = true; }
      goId('s-notion');
    }
  }
}
/* la riga di Dream: sostituisce quella di rotta-tab.js */
function nvChipsHtml(){
  /* 0.9.287: la scorciatoia del respiro sparisce quando la stagione di spinta (o la Modalita' severa) lo spegne */
  const noResp = typeof flSezioneBloccata === 'function' && flSezioneBloccata('respiro');
  const noGiochi = typeof flSezioneBloccata === 'function' && flSezioneBloccata('genio-giochi');
  const eResp = function(x){ return x.id === 'respiro' || /rsApri|rsConsiglio|rstRespira/.test(String(x.az || '')) || /respir/i.test(String(x.n || '')); };
  const eGioco = function(x){ return /akApri|orOpen|gsApri/.test(String(x.az || '')); };
  const vis = dchCfg().chips.filter(function(x){ return x.on !== false && !(noResp && eResp(x)) && !(noGiochi && eGioco(x)); });
  return '<div class="nv-chips-wrap"><div class="nv-chips-row">'
    + vis.map(function(x){ const az = dchAzione(x); if (!az) return ''; return '<button type="button" class="nv-chip" onclick="' + dchEsc(az) + '"><span>' + dchEsc(x.ico || '⭐') + '</span><b>' + dchEsc(x.n) + '</b></button>'; }).join('')
    + '</div></div>';
}
function dchRidisegna(){
  const el = document.getElementById('nvChips');
  if (el){ const w = el.querySelector('.nv-chips-wrap'); if (w) w.outerHTML = nvChipsHtml(); else el.innerHTML = nvChipsHtml(); }
  dchPaintLista();
}

/* ---------- in "Personalizza Dream" ---------- */
function dchListaHtml(){
  const c = dchCfg();
  return c.chips.map(function(x, i){
    const mia = !!x.link;
    return '<div class="dch-riga' + (x.on === false ? ' off' : '') + '" data-i="' + i + '">'
      + '<span class="dch-presa" aria-label="Trascina" data-i="' + i + '"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M5 8h14M5 12h14M5 16h14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg></span>'
      + '<span class="dch-ico">' + dchEsc(x.ico || '⭐') + '</span>'
      + '<input class="dch-nome" value="' + dchEsc(x.n) + '" maxlength="28" aria-label="Nome della scorciatoia" onchange="dchRinomina(' + i + ',this.value)">'
      + (x.on === false
          ? '<button type="button" class="cst-rimetti" onclick="dchOnOff(' + i + ',true)">Rimetti</button>'
          : '<button type="button" class="cst-mini x" aria-label="' + (mia ? 'Elimina' : 'Togli') + '" onclick="' + (mia ? 'dchElimina(' + i + ')' : 'dchOnOff(' + i + ',false)') + '">✕</button>')
      + '</div>';
  }).join('')
    + '<button type="button" class="cst-galleria" onclick="dchAggiungi()">＋ Aggiungi una scorciatoia</button>'
    + '<p class="dch-nota">Tieni il dito sulle tre righe e trascina per cambiare l’ordine. Tocca il nome per cambiarlo.</p>';
}
function dchPaintLista(){
  const h = document.getElementById('dchLista'); if (!h) return;
  h.innerHTML = dchListaHtml(); dchTrascinabili(h);
}
function dchRinomina(i, v){ const c = dchCfg(); const t = String(v || '').trim(); if (!c.chips[i] || !t) return dchPaintLista(); c.chips[i].n = t.slice(0, 28); dchSalva(c); }
function dchOnOff(i, on){ const c = dchCfg(); if (!c.chips[i]) return; c.chips[i].on = !!on; dchSalva(c); }
function dchElimina(i){ const c = dchCfg(); if (!c.chips[i] || !c.chips[i].link) return; c.chips.splice(i, 1); dchSalva(c); try{ toast('Scorciatoia eliminata'); }catch(_){ } }
function dchAggiungi(){
  let note = [], pagine = [];
  try{ note = (typeof mnOrdinate === 'function' ? mnOrdinate() : []).slice(0, 40); }catch(_){ }
  try{ const ws = JSON.parse(localStorage.getItem('fl_notion_ws') || 'null'); pagine = (ws && ws.pages || []).filter(function(p){ return p && !(ws.trash || []).includes(p.id); }).slice(0, 60); }catch(_){ }
  const riga = function(t, id, ico, nome){ return '<button type="button" class="dch-scelta" onclick="dchMetti(\'' + t + '\',\'' + String(id).replace(/[^A-Za-z0-9_\-]/g, '') + '\',\'' + dchEsc(ico).replace(/'/g, '') + '\',this.dataset.n)" data-n="' + dchEsc(nome) + '"><span>' + dchEsc(ico) + '</span>' + dchEsc(nome) + '</button>'; };
  const html = '<div class="dch-sh"><b>Aggiungi una scorciatoia</b>'
    + '<h4>Una pagina del piano</h4>' + (pagine.length ? pagine.map(function(p){ return riga('notion', p.id, p.icon || '📄', p.title || 'Senza titolo'); }).join('') : '<p class="dch-vuoto">Nel piano non ci sono ancora pagine.</p>')
    + '<h4>Una nota del telefono</h4>' + (note.length ? note.map(function(n){ return riga('nota', n.id, '🗒️', n.title || String(n.text || '').split('\n')[0].slice(0, 40) || 'Nota'); }).join('') : '<p class="dch-vuoto">Non hai ancora note.</p>')
    + '</div>';
  if (typeof inSheet === 'function') inSheet(html);
}
function dchMetti(t, id, ico, nome){
  try{ if (typeof inSheetChiudi === 'function') inSheetChiudi(); }catch(_){ }
  const c = dchCfg();
  c.chips.push({ id: 'l' + Date.now().toString(36), ico: ico || (t === 'nota' ? '🗒️' : '📄'), n: String(nome || '').slice(0, 28) || 'Scorciatoia', on: true, link: { t: t, id: id } });
  dchSalva(c);
  try{ toast('Aggiunta alle scorciatoie della scheda Sogno'); }catch(_){ }
}
/* trascinare con il dito: la riga segue il dito e le altre si spostano */
function dchTrascinabili(h){
  h.querySelectorAll('.dch-presa').forEach(function(p){
    p.addEventListener('pointerdown', function(e){
      const riga = p.closest('.dch-riga'); if (!riga) return;
      e.preventDefault();
      DCH.drag = { riga: riga, y0: e.clientY, da: +riga.dataset.i };
      riga.classList.add('su'); try{ p.setPointerCapture(e.pointerId); }catch(_){ }
      try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
    });
    p.addEventListener('pointermove', function(e){
      const d = DCH.drag; if (!d) return;
      d.riga.style.transform = 'translateY(' + (e.clientY - d.y0) + 'px)';
      const righe = Array.prototype.slice.call(h.querySelectorAll('.dch-riga'));
      const sopra = righe.filter(function(r){ if (r === d.riga) return false; const b = r.getBoundingClientRect(); return e.clientY > b.top + b.height / 2; }).length;
      d.a = sopra;
    });
    const fine = function(){
      const d = DCH.drag; if (!d) return; DCH.drag = null;
      d.riga.classList.remove('su'); d.riga.style.transform = '';
      if (d.a == null || d.a === d.da) return;
      const c = dchCfg(); const x = c.chips.splice(d.da, 1)[0]; c.chips.splice(d.a, 0, x); dchSalva(c);
    };
    p.addEventListener('pointerup', fine); p.addEventListener('pointercancel', fine);
  });
}
(function(){
  if (typeof cstPaint === 'function'){
    const v = cstPaint;
    window.cstPaint = cstPaint = function(){
      const r = v.apply(this, arguments);
      const box = document.getElementById('cstBody');
      if (box && !document.getElementById('dchLista')){
        const blocchi = document.getElementById('cst-blocchi');
        const sez = document.createElement('div');
        sez.innerHTML = '<h3 class="cst-h" id="cst-scorciatoie">Le scorciatoie</h3><div id="dchLista" class="dch-lista"></div>';
        if (blocchi) box.insertBefore(sez, blocchi); else box.appendChild(sez);
        dchPaintLista();
      }
      return r;
    };
  }
  const st = document.createElement('style');
  st.textContent = [
    '.dch-lista{display:flex;flex-direction:column;gap:8px}',
    '.dch-riga{display:flex;align-items:center;gap:10px;background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:8px 10px;transition:box-shadow .15s}',
    'body.dark .dch-riga{background:#12203A;border-color:#22345A}.dch-riga.off{opacity:.55}.dch-riga.su{position:relative;z-index:3;box-shadow:0 12px 26px rgba(15,32,65,.22);transition:none}',
    '.dch-presa{flex:none;width:34px;height:34px;display:grid;place-items:center;color:var(--muted,#5B6B86);touch-action:none;cursor:grab}',
    '.dch-ico{flex:none;font-size:20px}.dch-nome{flex:1;min-width:0;border:0;background:transparent;font:700 15px var(--font-body);color:var(--navy,#14234A);padding:8px 4px;border-radius:10px}.dch-nome:focus{outline:2px solid #0075E3;background:rgba(0,117,227,.06)}body.dark .dch-nome{color:#fff}',
    '.dch-nota{margin:8px 2px 0;font:500 12.5px/1.45 var(--font-body);color:var(--muted,#5B6B86);text-align:center}',
    '.dch-sh>b{display:block;font:800 18px var(--font-display,var(--font-body));color:var(--navy,#14234A);margin-bottom:6px}.dch-sh h4{margin:14px 0 6px;font:800 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted,#5B6B86)}',
    '.dch-scelta{display:flex;align-items:center;gap:10px;width:100%;text-align:left;border:0;border-radius:14px;background:#F2F6FC;color:var(--navy,#14234A);font:700 14.5px var(--font-body);padding:12px;margin-bottom:6px;cursor:pointer}.dch-scelta span{font-size:18px}body.dark .dch-scelta{background:#1B2A4A;color:#fff}',
    '.dch-vuoto{font:500 13px var(--font-body);color:var(--muted,#5B6B86)}'
  ].join('');
  document.head.appendChild(st);
})();
/* 0.9.287: quando la stagione o la Modalita' severa cambiano cosa e' spento, le scorciatoie si ridisegnano */
if (typeof document !== 'undefined') document.addEventListener('fl:blocchi', function(){ try{ dchRidisegna(); }catch(_){ } });
