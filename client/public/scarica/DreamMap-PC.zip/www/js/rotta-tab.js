/* ===========================================================================================
   ROTTA — la prima schermata (dal prototipo di Claude Design, «DreamMap Prototipo», 27/09/2026)

   Una card notturna con la data d'arrivo grande, la rotta con l'aereo, il Genio che parla;
   sotto, su fondo chiaro, la prossima mossa e quattro numeri. Elemento unico: la data.
   Azione primaria unica: Inizia.

   L'USCITA DI ROTTA. Quando il registro dell'ETA segna oggi un ritardo (una sessione mollata,
   una mossa rimandata, un imprevisto), la card mostra per un attimo lo scheletro «Ricalcolo…»,
   il bollino diventa rosso e il Genio propone il rientro: una sessione di Full Focus. Un tocco
   e si parte. Il numero non lo inventa nessuno: e' lo stesso motore (eta.js) che lo calcola
   sempre; qui si vede solo cambiare.

   Tutti i dati vengono da moduli che esistono gia': etaArrivo/etaBollino/etaLog (eta.js),
   gnDati (il sogno), stTask (la mossa di oggi), mtState, serStreak, frPuntiLega, ffCoins.
   =========================================================================================== */
const NV = { ricalcolo: false, proposta: null, t: 0 };
const NV_VISTO = 'fl_nv_visto';
const NV_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
/* le schede del pannello unico di Dream (0.9.304), nell'ordine dato da Andrea */
/* 0.9.317, Andrea: via la scheda "Prossima mossa": la prossima tappa sta sotto alla cartina, nella scheda Mappa */
const NVP_SCHEDE = [
  { id: 'sogno', t: 'Sogno', em: '🧭' },
  { id: 'mappa', t: 'Mappa', em: '🗺️' },
  { id: 'identita', t: 'Identità', em: '🪞' }
];
const NVP_KEY = 'fl_nvp_scheda';

function nvSogno(){
  /* 0.9.351, Andrea: "nell'intestazione del sogno due emoji, il razzo e il carrello". Il nome poteva portarsi dietro l'emoji della
     carta scelta all'inizio ("🛒 Aprire il mio negozio online") e l'intestazione ci metteva davanti la sua icona: il nome esce sempre senza */
  const pulito = function(x){ return String(x || '').replace(/^[^\p{L}\p{N}]+/u, '').trim(); };
  const n = nvSognoGrezzo();
  return n ? (pulito(n) || n) : '';
}
function nvSognoGrezzo(){
  /* il nome scelto in «Costruisci la tua mappa» vince su tutto: e' corto e l'ha scritto lui */
  try{ const c = JSON.parse(localStorage.getItem('fl_mappa_cfg') || 'null'); if (c && c.nome) return String(c.nome); }catch(_){ }
  /* 0.9.351: poi il sogno chiaro scritto dal Genio con la roadmap su misura (agApplicaPiano) */
  try{ const k = JSON.parse(localStorage.getItem('fl_sogno_chiaro') || 'null'); if (k && k.nome) return String(k.nome); }catch(_){ }
  try{ const d = (typeof agDati === 'function') ? agDati() : null; if (d && d.sogno && d.sogno !== 'quel sogno') return String(d.sogno); }catch(_){ }
  try{ const g = gnDati(); if (g && g.sogno) return String(g.sogno).replace(/^[^\p{L}\p{N}]+/u, '').trim(); }catch(_){ }
  return '';
}
function nvArrivo(){ try{ return (typeof etaArrivo === 'function') ? etaArrivo() : null; }catch(_){ return null; } }
function nvBollino(){ try{ return (typeof etaBollino === 'function') ? etaBollino() : null; }catch(_){ return null; } }
function nvNome(){ try{ const g = gnDati(); return (g && g.nome) ? String(g.nome).split(' ')[0] : ''; }catch(_){ return ''; } }
/* l'ultima voce del registro di oggi che ha allontanato l'arrivo, non ancora vista */
function nvDeviazione(){
  try{
    const log = (typeof etaLog === 'function') ? etaLog() : [];
    const oggi = etaOggiK();
    const visto = +localStorage.getItem(NV_VISTO) || 0;
    const brutte = ['mollata', 'rimandata', 'imprevisto', 'pedaggio', 'deviazione', 'fuori', 'rinuncia'];
    for (let i = log.length - 1; i >= 0; i--){
      const v = log[i];
      if (!v || etaKey(v.at) !== oggi) break;
      if (v.at > visto && (v.delta || 0) > 0 && brutte.indexOf(v.tipo) >= 0) return v;
    }
  }catch(_){ }
  return null;
}
function nvVisto(v){ try{ localStorage.setItem(NV_VISTO, String(v && v.at ? v.at : Date.now())); }catch(_){ } }
/* 0.9.326, Andrea: "si e' spostato di 0 giorni: ma che cazzo e'?". Sotto il giorno si dice il tempo vero */
function nvGiorni(ms){
  const a = Math.abs(ms), g = Math.round(a / 86400000);
  if (g >= 1) return g + (g === 1 ? ' giorno' : ' giorni');
  const o = Math.round(a / 3600000);
  if (o >= 1) return o === 1 ? '1 ora' : o + ' ore';
  const m = Math.max(1, Math.round(a / 60000));
  return m === 1 ? '1 minuto' : m + ' minuti';
}
/* sotto il quarto d'ora l'arrivo non si e' spostato per nessuno: un pannello lo farebbe sembrare un errore */
const NV_MIN_SPOST = 15 * 60000;
function nvTask(){ try{ return String((typeof stTask === 'function') ? stTask() : '').replace(/^[☐☑•]\s*/, '').trim(); }catch(_){ return ''; } }

/* LA SCHEDA ROTTA, dall'alto: una slideshow a tutta larghezza con le nuvole sotto (come il
   Profilo), poi la proposta o la prossima mossa, le porte, «Prevedi il tuo futuro» e i numeri.
     1. L'arrivo previsto: il sogno, la data, il bollino, la rotta con l'aereo.
     2. La frase del giorno, con «Scopri di piu'» (era la terza diapositiva del Blocco: scores.js
        la riempie dentro #bhQuote ovunque stia).
     3. Prevedi il tuo futuro: il Genio che fluttua con la sua nuvoletta, e la probabilita' di
        arrivare entro la data scelta con la rotta di oggi (etaArrivo().pTarget).
   Le parti adottate (porte, #scLife) non si toccano mai con innerHTML. */
function nvStruttura(){
  const tab = document.getElementById('tab-rotta'); if (!tab) return null;
  if (!document.getElementById('nvTop')){
    /* L'ORDINE (0.9.173): in cima la lettura del Genio con «Prevedi il tuo futuro» subito
       sotto; poi le porte; poi i numeri. La prossima mossa e' andata nella Mappa. */
    /* LE SCORCIATOIE (0.9.177), sotto alle nuvole: una riga di pulsanti che scorre, come in
       Meditopia. Portano dritte alle pagine: Scudo, umore, ispirazione, appunti, suoni, Report. */
    /* 0.9.186: OGNI pezzo della pagina e' un blocco che si sposta e si toglie (costruisci.js):
       l'interruttore con l'arrivo, lo slideshow, la lettura, le scorciatoie, Prevedi, le due
       porte (Io futuro, sveglia) e la barra del Genio. Stanno tutti dentro a .nv-page. */
    tab.innerHTML = '<div class="nv-page"><div id="nvArrBlock"></div><div id="nvTop" class="nv-col"></div><div id="nvChips"></div><div id="nvSfide"></div><div id="nvChiama"></div><div id="nvSveglia"></div></div>';
  }
  if (!document.getElementById('nvHero') && typeof flHeroEnsure === 'function'){
    /* 0.9.285: le date importanti del mese (dream-mese.js) entrano PRIMA di tutte, da sole, quando ci sono */
    flHeroEnsure('rotta', 'tab-rotta', 'nvHero', (typeof dmSlideHtml === 'function' ? [dmSlideHtml()].filter(Boolean) : []).concat([
      /* 0.9.187: la prima e' di nuovo l'ARRIVO PREVISTO (lo stesso del pannello sotto
         all'interruttore), la seconda «Break free from Dream Thieves» come nella pagina Blocca */
      '<article class="bh-slide on nv-arr-s" data-i="0" style="--bh-img:url(\'img/dream-night.jpg\');--bh-pos:center 70%">'
      +   '<div class="bh-img"></div><span class="bh-ov"></span>'
      +   '<div class="bh-stack nv-arr" id="nvArrivoSlide"></div>'
      + '</article>',
      '<article class="bh-slide nv-bf-s" data-i="1" style="--bh-img:url(\'img/dream-thieves.jpg\');--bh-pos:center 38%">'
      +   '<div class="bh-img"></div><span class="bh-ov dark"></span>'
      +   '<div class="bh-text">'
      +     '<p class="bh-eyebrow">' + flHeroLine('Liberati', 0) + '</p>'
      +     '<h2 class="bh-title">' + flHeroLine('Dai ladri di sogni', 1) + '</h2>'
      +   '</div>'
      + '</article>',
      /* LA COPERTINA (0.9.184): la lettura del Genio, con l'episodio di oggi e la lettura da
         rifare; lo sfondo e' quello del quiz del Genio, con l'aura che gira. */
      '<article class="bh-slide nv-cover-s" data-i="2" style="--bh-img:url(\'img/bg/montagne.jpg\');--bh-pos:center bottom">'
      +   '<div class="bh-img"></div><span class="bh-ov"></span>'
      +   '<div class="bh-stack nv-arr nv-cover" id="nvCover"></div>'
      + '</article>',
      '<article class="bh-slide" data-i="3">'
      +   '<div class="bh-img"></div><span class="bh-ov"></span>'
      +   '<div class="bh-text bh-quote">'
      +     '<p class="bh-q-text" id="bhQuote"></p>'
      +     '<p class="bh-q-author" id="bhQuoteAuthor"></p>'
      +     '<button class="bh-cta bh-q-btn" id="bhQuoteBtn" hidden onclick="scOpenInspire()">👁 Vedi dettagli</button>'
      +   '</div>'
      + '</article>'
    ]), { tall: true, auto: false, sweep: true });
    try{ if (typeof dmDopoHero === 'function') dmDopoHero(); }catch(_){ }
    /* la frase del giorno: la stessa di sempre, scritta da scores.js */
    setTimeout(function(){ try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ } }, 300);
  }
  /* L'ARRIVO PREVISTO (0.9.185) non e' piu' una slide: e' un pannello sotto all'interruttore
     Sogno | Mappa, sopra allo slideshow. Il bordo si accende di rosso quando la data si sposta
     (ricalcolo, uscita di rotta), come nel prototipo di Claude Design. */
  const blocco = document.getElementById('nvArrBlock');
  /* 0.9.304, Andrea: UN SOLO PANNELLO A SCHEDE, come "Le statistiche della partita" (partita-stats.js): Prossima
     mossa, La tua storia, Sogno, Mappa, Identita'. Sta nel blocco fisso in cima; l'arrivo previsto e' la scheda Sogno. */
  if (blocco && !document.getElementById('nvPannello')){
    const pn = document.createElement('section');
    pn.id = 'nvPannello'; pn.className = 'pst nvp';
    pn.innerHTML = '<p class="pst-kick">Il tuo viaggio</p><div class="pst-tabs" role="tablist" id="nvpTabs"></div><div class="nvp-corpo">'
      + NVP_SCHEDE.map(function(t){ return '<div class="nvp-pane" id="nvp-' + t.id + '" role="tabpanel" hidden></div>'; }).join('') + '</div>';
    blocco.appendChild(pn);
    nvpSwipe(pn.querySelector('.nvp-corpo'));
    /* 0.9.321: sopra al pannello scuro, il pannello bianco con la storia (dream-storia.js) */
    if (typeof nvsCrea === 'function') nvsCrea(blocco, pn);
  }
  const sogP = document.getElementById('nvp-sogno');
  if (sogP && !document.getElementById('nvArrCard')){
    const card = document.createElement('div');
    card.id = 'nvArrCard'; card.className = 'nv-arr-card';
    card.style.setProperty('--bh-img', "url('img/dream-night.jpg')"); card.style.setProperty('--bh-pos', 'center 70%');
    card.innerHTML = '<div class="bh-img"></div><span class="bh-ov"></span><div class="nv-arr" id="nvArrivo"></div>';
    sogP.appendChild(card);
  }
  if (sogP && !document.getElementById('nvpRitmo')){ const r = document.createElement('div'); r.id = 'nvpRitmo'; sogP.appendChild(r); }
  /* la scheda Identita': chi rischi di diventare (#scLife, scritto da scores.js) e quanto ti conosce il Genio */
  const idP = document.getElementById('nvp-identita');
  if (idP && !document.getElementById('nvpLife')) idP.innerHTML = '<div id="nvpPartita"></div><div id="nvpLife"></div><div id="nvpConosce"></div>';
  const lifeH = document.getElementById('nvpLife'), lifeEl = document.getElementById('scLife');
  const lifeSl = document.querySelector('[data-adotta="scLife"]');
  if (lifeSl && lifeEl && lifeEl.parentElement !== lifeSl) lifeSl.appendChild(lifeEl);
  else if (!lifeSl && lifeH && lifeEl && lifeEl.parentElement !== lifeH) lifeH.appendChild(lifeEl);
  /* LE SFIDE (0.9.210): chi aveva gia' la pagina non ha il posto per il pannello: si aggiunge */
  const pgSf = tab.querySelector('.nv-page');
  if (pgSf && !document.getElementById('nvSfide')){ const sf = document.createElement('div'); sf.id = 'nvSfide'; const ch = document.getElementById('nvChips'); if (ch && ch.parentElement === pgSf) pgSf.insertBefore(sf, ch.nextSibling); else pgSf.appendChild(sf); }
  /* lo slideshow nasce in cima alla scheda (flHeroEnsure): va dentro alla pagina, come blocco */
  const pgS = tab.querySelector('.nv-page'), heroS = document.getElementById('nvHero');
  if (pgS && heroS && heroS.parentElement !== pgS) pgS.insertBefore(heroS, blocco ? blocco.nextSibling : pgS.firstChild);
  /* 0.9.304: il vecchio posto di "Prevedi il tuo futuro" e la prossima mossa sotto alla lettura non ci sono piu' */
  ['nvFuturo', 'nvMossa'].forEach(function(id){ const v = document.getElementById(id); if (v && !v.contains(document.getElementById('scLife'))) v.remove(); });
  return document.getElementById('nvTop');
}
function nvBadge(b){
  if (!b) return '';
  if (b.primo || b.pausa || typeof b.delta !== 'number') return esc(b.txt || '');
  /* 0.9.308: lo stesso testo del foglio e della schermata nativa (eta.js, etaSpostamentoTxt), a giorni di calendario */
  if (typeof b.giorni === 'number') return b.txt || '';
  const g = Math.round(Math.abs(b.delta) / 86400000);
  if (!g) return 'Come ieri';
  return (b.delta < 0 ? '−' : '+') + g + (g === 1 ? ' giorno' : ' giorni') + ' rispetto a ieri ' + (b.delta < 0 ? '↘' : '↗');
}
const NV_AEREO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/></svg>';
function nvPaint(){
  const host = nvStruttura(); if (!host) return;
  /* 0.9.305, Andrea: il blocco "Parla con il Genio" (#nvBottom, la barra per scrivergli) esce da Dream, anche dalle
     pagine gia' costruite. dream-extra.js e socialproof.js senza di lui mettono i loro blocchi in fondo, e poi
     cstOrdinaBlocchi li rimette in ordine */
  const giu = document.getElementById('nvBottom');
  if (giu) giu.remove();
  const arr = document.getElementById('nvArrivo'), prev = document.getElementById('nvPrevedi');
  const a = nvArrivo();
  const nome = nvNome();
  const sogno = nvSogno() || 'Il tuo sogno';
  if (!a || !isFinite(a.at)){
    const vuoto = '<div class="nv-in"><small class="nv-eti">La tua rotta</small><b class="nv-titolo">Prima la lettura del Genio</b>'
      + '<p class="nv-p">Senza una destinazione non c’è una data d’arrivo. Fai la lettura: da lì parte tutto.</p>'
      + '<button type="button" class="am-cta nv-cta" onclick="switchTab(\'mappa\')">Vai dal Genio</button></div>';
    if (arr) arr.innerHTML = vuoto;
    const arrV = document.getElementById('nvArrivoSlide'); if (arrV) arrV.innerHTML = vuoto;
    if (prev) prev.innerHTML = nvPrevediHtml(null, 'Fai la lettura del Genio: poi ti dico quanto è probabile che arrivi.', false);
    const cardV = document.getElementById('nvArrCard'); if (cardV) cardV.classList.remove('fuori', 'ricalcolo');
    host.innerHTML = '';
    nvpPaint(false);
    nvOrdina(); nvCoverPaint();
    return;
  }
  const dev = NV.proposta || nvDeviazione();
  if (dev && !NV.proposta && !NV.ricalcolo){
    /* l'uscita di rotta si vede accadere: scheletro, poi la proposta */
    NV.ricalcolo = true; NV.proposta = null;
    clearTimeout(NV.t);
    NV.t = setTimeout(function(){ NV.ricalcolo = false; NV.proposta = dev; nvPaint(); }, 1900);
  }
  const b = nvBollino();
  /* IL RICALCOLO SI VEDE ACCADERE. Se da ieri l'arrivo si e' allontanato, la prima volta che
     si atterra qui la card non mostra la data gia' peggiorata: mostra lo scheletro
     «Ricalcolo…» per un secondo e nove, poi la data nuova. E' la stessa animazione del
     prototipo quando si salta la mossa; qui parte da sola, una volta per giornata e per
     ritardo, cosi' il peggioramento non passa inosservato. */
  if (b && b.delta > 0 && !NV.ricalcolo && !NV.proposta){
    const firma = etaOggiK() + ':' + Math.round(b.delta / 86400000);
    let vista = ''; try{ vista = localStorage.getItem('fl_nv_ricalcolo') || ''; }catch(_){ }
    if (vista !== firma){
      try{ localStorage.setItem('fl_nv_ricalcolo', firma); }catch(_){ }
      NV.ricalcolo = true; NV.appena = false;
      clearTimeout(NV.t);
      NV.t = setTimeout(function(){ NV.ricalcolo = false; NV.appena = true; nvPaint(); setTimeout(function(){ NV.appena = false; }, 900); }, 1900);
    }
  }
  /* 0.9.308: rosso solo se la data (al giorno) si e' davvero spostata in avanti: una deviazione di poche ore non fa il bordo rosso */
  const fuori = NV.ricalcolo || !!(b && b.delta > 0);
  const cardA = document.getElementById('nvArrCard');
  if (cardA){ cardA.classList.toggle('fuori', fuori); cardA.classList.toggle('ricalcolo', !!NV.ricalcolo); }
  const d = new Date(a.at);
  const inizio = a.inizio || (Date.now() - 86400000);
  /* LA PERCENTUALE DEL PERCORSO, la stessa della cartina dal satellite (eta.js: s.pct, «X%
     del percorso»). L'aereo sta li': prima la sua posizione era il tempo passato fra la
     partenza e la data d'arrivo, che e' un'altra misura, e accanto al badge c'era la
     probabilita' di riuscita, che ha gia' la sua diapositiva (Prevedi il tuo futuro). */
  /* 0.9.236, Andrea: in alto 4,5%, qui 0,4%. Il numero e' UNO in tutta l'app: quello
     dell'intestazione (hdPercorso: tappe della mappa e tappe macro), lo stesso della cartina. */
  let pctF = null;
  try{ if (typeof hdPercorso === 'function'){ const h = hdPercorso(); if (h && isFinite(h.pct)) pctF = h.pct; } }catch(_){ }
  if (pctF == null && a.pct != null && isFinite(a.pct)) pctF = a.pct;
  const perc = pctF != null ? ((typeof mpPercTxt === 'function') ? String(mpPercTxt(pctF)) : String(Math.round(pctF * 100))) : null;
  /* l'aereo sta esattamente sulla percentuale (prima era tenuto fra 4 e 96: con lo 0,4% non si muoveva) */
  const pct = pctF != null ? Math.max(1.5, Math.min(98.5, pctF * 100)) : 2;
  const prob = a.pTarget == null ? null : Math.round(a.pTarget <= 1 ? a.pTarget * 100 : a.pTarget);
  const linea = NV.ricalcolo ? 'Un attimo. Sto ricalcolando la rotta.'
    : (NV.proposta && fuori) ? 'Nessun dramma. Ti dico io come rientrare.'
    : (b && b.delta <= -5 * 86400000) ? 'Così mi piaci. Stai correndo verso di me.'
    : (nome ? nome + ', oggi' : 'Oggi') + ' basta una mossa. Poi sei più vicino.';
  const velata = !NV.ricalcolo && typeof evVelata === 'function' && evVelata();
  const pill = NV.ricalcolo ? '<span class="nv-pill grigia">Ricalcolo…</span>'
    : velata ? '<button type="button" class="nv-pill velo" onclick="event.stopPropagation();evSpiega()"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg><span>' + esc(evBreve()) + '</span></button>'
    : (b ? '<button type="button" class="nv-pill tocca' + (b.delta > 0 ? ' rossa' : (b.delta < 0 ? '' : ' grigia')) + '" onclick="if(typeof prcApri===\'function\')prcApri(event)" aria-label="Perché la data si è spostata">' + esc(nvBadge(b)) + '</button>' : '');
  const arrHtml = '<div class="nv-in' + (fuori ? ' fuori' : '') + '">'
    /* il nome del sogno sta su UNA riga: se e' lungo si tronca, non si mangia la data */
    + '<div class="nv-top"><span class="nv-sogno"><i>' + ((typeof cstIcona === 'function') ? cstIcona() : '🎯') + '</i><em>' + esc(sogno) + '</em></span>'
    +   '<button type="button" class="nv-edit" aria-label="Costruisci la tua mappa" onclick="if(typeof cstApri===\'function\')cstApri();else switchTab(\'mappa\')">✎</button></div>'
    + '<small class="nv-eti">' + (NV.ricalcolo ? 'Ricalcolo…' : 'Arrivo previsto') + '</small>'
    + (NV.ricalcolo ? '<div class="nv-skel"><i style="width:230px"></i><i style="width:130px"></i></div>'
        : (typeof evVelata === 'function' && evVelata())
          ? '<div class="nv-data ev-velo" aria-label="Data d\u2019arrivo non ancora svelata"><b>' + d.getDate() + ' ' + NV_MESI[d.getMonth()] + '</b><span>' + d.getFullYear() + '</span></div>'
          : '<button type="button" class="nv-data' + (NV.appena ? ' nv-pop' : '') + '" onclick="if(typeof etaIntervalloApri===\'function\')etaIntervalloApri(event)"><b>' + d.getDate() + ' ' + NV_MESI[d.getMonth()] + '</b><span>' + d.getFullYear() + '</span></button>')
    + (pill ? '<div class="nv-pills">' + pill + '</div>' : '')
    + '<div class="nv-rotta"><span>Oggi</span><div class="nv-linea"><i style="width:' + pct + '%;background:' + (fuori ? '#E63946' : '#3F9FF4') + '"></i><em style="left:' + pct + '%">' + NV_AEREO + '</em></div><span>Sogno</span></div>'
    + (perc != null ? '<p class="nv-perc-rotta"><b>' + esc(perc) + '%</b> del percorso</p>' : '')
    + '</div>';
  /* 0.9.265: si riscrive solo se cambia (prima ogni disegno ricreava il pannello e la sua slide) */
  if (arr && arr._html !== arrHtml){ arr._html = arrHtml; arr.innerHTML = arrHtml; }
  const arrS = document.getElementById('nvArrivoSlide'); if (arrS && arrS._html !== arrHtml){ arrS._html = arrHtml; arrS.innerHTML = arrHtml; }
  nvAereoAnima(pct);
  if (prev) prev.innerHTML = nvPrevediHtml(prob, linea, fuori, a);
  let h = '', rientro = '';
  if (NV.proposta && (NV.proposta.tipo === 'mollata' || NV.proposta.tipo === 'rimandata' || NV.proposta.delta >= NV_MIN_SPOST)){
    const v = NV.proposta;
    const costo = v.delta >= NV_MIN_SPOST ? nvGiorni(v.delta) : '';
    const testo = (v.tipo === 'mollata' ? 'Hai mollato una sessione' : v.tipo === 'rimandata' ? 'Hai rimandato una mossa' : 'Un imprevisto')
      + (costo ? ' e l’arrivo si è spostato di ' + costo : '') + '. Se vuoi, il Genio ti aiuta a capire cosa ti ha fermato e a rimettere a posto il percorso.';
    rientro = nvRientroCardHtml(testo, 'nvRientra()', 'nvPropostaChiudi()');
  } else if (nvForzato()){
    /* 0.9.235, Andrea: dopo un "Non ora" alla chiamata dei sogni il pannello compare subito, senza
       aspettare che la data peggiori: si spiega al Genio cosa e' successo e si rientra in pista */
    const f = nvForzato();
    rientro = nvRientroCardHtml('Hai detto "Non ora" alla chiamata dei sogni' + (f.titolo ? ' per "' + f.titolo + '"' : '') + '. Se vuoi, spiega al Genio cosa ti ha fermato: ti aiuta a rientrare subito in pista.', 'nvForzatoVia()', 'nvForzatoNo()');
  } else if (b && b.delta >= NV_MIN_SPOST && !NV.ricalcolo && !nvRientroFatto(b)){
    /* LA DATA E' PEGGIORATA DA SOLA (0.9.216). Prima il pannello compariva solo dopo una
       sessione mollata o una mossa rimandata: se l'arrivo si spostava di 26 giorni senza un
       evento preciso, sotto restava la lettura a episodi e nessuno ti diceva come rientrare. Ora
       e' la stessa card del Genio che cambia faccia, finche' non rientri o dici «Non ora». */
    rientro = nvRientroCardHtml('Da ieri la data in cui arrivi al tuo sogno si è spostata in avanti di ' + nvGiorni(b.delta) + '. Se vuoi, il Genio ti aiuta a capire cosa ti ha fermato e a rimettere a posto il percorso.', 'nvRientraRicalcolo()', 'nvRientroNonOra()');
  } else if (typeof rvStato === 'function' && rvStato() === 'da-fare' && (typeof epiVistoOggi === 'function' ? epiVistoOggi() : (typeof dqFattoOggi === 'function' && dqFattoOggi()))){
    /* 0.9.235: episodio di oggi fatto, niente da rientrare: la revisione della sera prende il posto
       della lettura del Genio */
    /* 0.9.337: la revisione e' la prima slide del carosello (dream-storia.js), non piu' una card qui */
  } else if (typeof epiCardHtml !== 'function' && typeof dqCardHtml === 'function'){
    /* la lettura a episodi: la sfera, quanto ti conosce, l'episodio di oggi. (La card del
       sentiero e' andata via in 0.9.177: il sentiero vive nella Mappa, alla Duolingo.) */
    h += dqCardHtml();
  }
  /* 0.9.304: gli episodi (episodi.js) e la prossima mossa vivono nel pannello a schede (nvpPaint), non piu' qui */
  host.innerHTML = h;
  try{ if (typeof nvsPaint === 'function') nvsPaint(rientro); }catch(_){ }
  nvpPaint(fuori);
  try{ if (typeof rvOvunquePaint === 'function') rvOvunquePaint(); }catch(_){ }
  setTimeout(nvHeroPareggia, 450);
  const chips = document.getElementById('nvChips');
  if (chips) chips.innerHTML = nvChipsHtml();
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
  nvOrdina();
  nvCoverPaint();
}
/* L'ORDINE DELLA PAGINA (0.9.184), imposto a ogni disegno perche' costruisci.js riordina i
   blocchi: in cima l'interruttore Sogno | Mappa, poi la lettura del Genio, poi le scorciatoie. */
/* LA SLIDE NUOVA A OGNI APERTURA (0.9.209): una volta per avvio dell'app, mai durante l'uso */
function nvRuotaOn(){ try{ return localStorage.getItem('fl_dream_ruota') === '1'; }catch(_){ return false; } }
function nvRuotaSet(on){ try{ localStorage.setItem('fl_dream_ruota', on ? '1' : '0'); }catch(_){ } }
let NV_RUOTA_I = null;
function nvRuotaApplica(){
  if (!nvRuotaOn() || typeof FL_HEROES === 'undefined' || !FL_HEROES.rotta || typeof flHeroGo !== 'function') return;
  const n = FL_HEROES.rotta.n || 1;
  if (NV_RUOTA_I === null){
    let prima = -1; try{ prima = parseInt(localStorage.getItem('fl_dream_ruota_i') || '-1', 10); }catch(_){ }
    NV_RUOTA_I = (prima + 1) % n;
    try{ localStorage.setItem('fl_dream_ruota_i', String(NV_RUOTA_I)); }catch(_){ }
  }
  if (FL_HEROES.rotta.slide !== NV_RUOTA_I) flHeroGo('rotta', NV_RUOTA_I);
}
function nvOrdina(){
  setTimeout(nvRuotaApplica, 60);
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
  /* 0.9.186: l'ordine lo decide chi personalizza la pagina (costruisci.js) */
  try{ if (typeof cstOrdinaBlocchi === 'function') cstOrdinaBlocchi(); }catch(_){ }
  try{ if (typeof hdrDreamApply === 'function') hdrDreamApply(); }catch(_){ }
  /* lo slideshow appena nato deve passare sotto all'intestazione anche al primo avvio */
  try{ if (typeof flHeaderSync === 'function'){ flHeaderSync(); setTimeout(flHeaderSync, 300); } }catch(_){ }
}
/* LA COPERTINA (0.9.190): «La sfida del Genio · METTIMI ALLA PROVA». Il pulsante bianco con il
   play apre la sfida (genio-sfida.js: il Genio indovina un personaggio, un libro o un film, o
   legge chi gioca); quello grigio rifa' la lettura del futuro. L'episodio di oggi ha gia' il
   suo pulsante nella card «La lettura del Genio», piu' giu' nella pagina. */
const NV_PLAY = '<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path fill="currentColor" d="M7 4.5v15a1 1 0 0 0 1.52.85l12-7.5a1 1 0 0 0 0-1.7l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>';
/* 0.9.317, Andrea: "la sfida del Genio non deve essere il gioco: deve essere la slide della storia, la serie con gli episodi". I giochi
   stanno nella pagina della storia (genio-film.js). La vecchia slide e' sul branch backup/sfida-genio-slide-0.9.316. */
function nvCoverPaint(){
  const c = document.getElementById('nvCover'); if (!c) return;
  let fatta = false; try{ fatta = !!((typeof orLast === 'function') && orLast()); }catch(_){ }
  const html = '<div class="nv-cover-in">'
    + '<div class="nv-cover-aura"><i></i><img src="img/genio/genio-rivela.png" alt=""></div>'
    + '<small class="nv-eti">La tua storia</small>'
    + '<b class="nv-cover-h">Verso il <span class="fl-hl">sogno<svg class="fl-hl-svg" viewBox="0 0 200 90" preserveAspectRatio="none" aria-hidden="true"><path d="' + ((typeof FL_CIRCLE_PATH !== 'undefined') ? FL_CIRCLE_PATH : 'M180,25 C130,5 30,5 15,40 C5,70 60,85 110,80 C165,75 195,55 180,25') + '"/></svg></span></b>'
    + '<p class="nv-p nv-cover-p">Un episodio al giorno: il Genio racconta chi sei e dove stai andando. Alla fine di ogni stagione c’è una sorpresa.</p>'
    + '<button type="button" class="nv-btn-play" onclick="nvCoverEpisodio()">' + NV_PLAY + '<span>' + ((typeof drsSerieIniziata === 'function' && drsSerieIniziata()) ? 'Riprendi' : 'Inizia') + '</span></button>'
    + '<button type="button" class="nv-btn-grigio" onclick="if(typeof orOpen===\'function\')orOpen()">' + (fatta ? 'Rifai la lettura del futuro' : 'Fai la lettura del futuro') + '</button>'
    + '</div>';
  /* LA COPERTINA NON RIPARTE DA SOLA. nvPaint gira spesso (a ogni dato nuovo): riscrivere lo
     stesso HTML rifaceva salire il testo e ridisegnare il cerchio ogni pochi secondi. Si
     riscrive solo se e' cambiato qualcosa (un pulsante, un'etichetta). */
  if (c.dataset.html === html) return;
  c.dataset.html = html;
  c.innerHTML = html;
}
function nvCoverEpisodio(){ try{ goId('s-serie'); }catch(_){ } }
/* la terza diapositiva: la probabilita' di arrivare entro la data scelta, con la rotta di oggi */
function nvPrevediHtml(prob, linea, fuori, a){
  let sotto = 'di arrivare entro la data che hai scelto, con la rotta di oggi';
  try{ if (a && a.oltreScadenza) sotto ='di arrivare entro la data che hai scelto: con questa rotta la superi'; }catch(_){ }
  return '<div class="nv-in nv-prev">'
    + '<small class="nv-eti">Le probabilità di arrivare</small>'
    + (prob != null ? '<b class="nv-perc' + (prob < 40 ? ' bassa' : '') + '">' + prob + '<i>%</i></b><p class="nv-p">' + esc(sotto) + '</p>' : '<b class="nv-perc vuota">—</b>')
    + '<div class="nv-genio"><img src="img/genio/' + (fuori ? 'genio-triste' : 'genio-rivela') + '.png" alt=""><div class="nv-fumetto">' + esc(linea) + '</div></div>'
    + '</div>';
}
/** La prossima mossa: la card di prima, che ora vive nella Mappa (mappa-tab.js). */
/* 0.9.282, Andrea: "dice che il foglio di START e' vuoto, ma non e' vuoto: c'e' la tappa della mappa". Senza una riga
   nel foglio, la prossima mossa e' la tappa in corso della mappa, e Inizia porta li'. */
function nvMossaTappaVai(id){
  try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('rotta'); }catch(_){ }
  setTimeout(function(){
    try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n && n.scrollIntoView) n.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
    setTimeout(function(){ try{ if (id && typeof sdTap === 'function') sdTapVia(id); }catch(_){ } }, 650);
  }, 350);
}
/* 0.9.321, Andrea: "non e' una partita a scacchi, sono le tappe del percorso": il segnaposto della mappa accanto alla parola */
const NV_TAPPA_ICO = '<svg class="nv-tappa-ico" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-6.200-7-11.500a7 7 0 0 1 14 0C19 14.800 12 21 12 21z"/><circle cx="12" cy="9.500" r="2.400"/></svg>';
function nvMossaHtml(){
  /* 0.9.335, Andrea: "la prossima tappa e' SEMPRE quella della roadmap, non la task scritta a mano nel Full Focus":
     prima la tappa della mappa; il foglio di START solo per chi una roadmap non ce l'ha */
  const tp = (typeof stTappaOggi === 'function') ? stTappaOggi() : null;
  const t = tp ? '' : nvTask();
  if (tp) return '<div class="nv-mossa"><small>' + NV_TAPPA_ICO + 'Prossima tappa</small><b>' + esc(tp.nome) + '</b>'
    + '<button type="button" class="am-cta" onclick="nvMossaTappaVai(\'' + tp.id + '\')">▶ Inizia</button></div>';
  return '<div class="nv-mossa"><small>' + NV_TAPPA_ICO + 'Prossima tappa</small><b>' + esc(t || 'Scrivi cosa fai oggi') + '</b><span>' + esc(t ? 'Una sessione di Full Focus, e la data si avvicina.' : 'Il foglio della scheda START è vuoto.') + '</span>'
    + (t ? '<button type="button" class="am-cta" onclick="nvMossaVai()">▶ Inizia</button>' : '<button type="button" class="am-cta" onclick="switchTab(\'sveglia\')">Apri il foglio</button>')
    + '<div class="nv-mossa-btns"><button type="button" onclick="switchTab(\'sveglia\')">Vedi il foglio</button></div></div>';
}

/* ---------------------------------------------------------------------------------------
   IL PANNELLO A SCHEDE (0.9.304)

   Andrea, 28/10: in Dream c'erano cinque pannelli separati (l'interruttore Sogno | Mappa con
   l'arrivo, la serie del Genio, la prossima mossa, "Prevedi il tuo futuro" con chi rischi di
   diventare) e l'occhio non sapeva dove fermarsi. Adesso e' UN pannello scuro con le linguette
   che scorrono di lato, lo stesso stile delle statistiche della partita (partita-stats.js: si
   usano le sue classi .pst, .pst-kick, .pst-tabs, .pst-tab). Una scheda alla volta, una cosa
   principale per scheda; la scheda scelta si ricorda (fl_nvp_scheda).
     Prossima mossa · La tua storia (gli episodi) · Sogno (l'arrivo previsto) · Mappa (la
     cartina e la strada fatta, con il pulsante per la Mappa) · Identita' (chi rischi di
     diventare, e quanto ti conosce il Genio).
   --------------------------------------------------------------------------------------- */
const NVP_PLAY = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M7 4.5v15a1 1 0 0 0 1.52.85l12-7.5a1 1 0 0 0 0-1.7l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>';
function nvpScheda(){
  let v = ''; try{ v = localStorage.getItem(NVP_KEY) || ''; }catch(_){ }
  return NVP_SCHEDE.some(function(t){ return t.id === v; }) ? v : 'sogno';
}
function nvpVai(id){
  if (id === nvpScheda()) return;
  try{ localStorage.setItem(NVP_KEY, id); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  nvpPaint(NV.fuoriP, true);
}
function nvpIco(e){ return '<span class="nvp-ico" aria-hidden="true">' + e + '</span>'; }
/* 0.9.346, Andrea: "la slide del collo a volte viene tagliata e si sposta su e giu'". Ogni minuto il testo del ritmo cambia ("sono passati
   6 ore e 9 minuti") e il pannello si ridisegnava da capo: il carosello tornava alla prima slide e la sua altezza ripartiva da zero.
   Adesso, ridisegnando, il carosello tiene la slide su cui eri e la sua altezza. */
/* 0.9.348: alcune slide non sono html ma pezzi vivi della pagina (l'arrivo previsto #nvArrCard, chi rischi di diventare #scLife), con i
   loro aggiornamenti. Stanno in un segnaposto data-adotta="id": prima di ridisegnare si mettono da parte, dopo si rimettono al loro posto */
function nvpParcheggio(){ let p = document.getElementById('nvpParcheggio'); if (!p){ p = document.createElement('div'); p.id = 'nvpParcheggio'; p.hidden = true; (document.getElementById('nvPannello') || document.body).appendChild(p); } return p; }
function nvpAdotta(el){
  (el || document).querySelectorAll('[data-adotta]').forEach(function(s){
    const x = document.getElementById(s.getAttribute('data-adotta'));
    if (x && x.parentElement !== s){ s.appendChild(x); x.hidden = false; }
  });
}
function nvpRiempi(id, html){
  const el = document.getElementById(id); if (!el) return;
  if (el._html === html){ nvpAdotta(el); return; }
  const c0 = el.querySelector('.nvp-rs-car'); const sx = c0 ? c0.scrollLeft : 0, alt = c0 ? c0.style.height : '', larg = c0 ? c0.clientWidth : 0;
  el.querySelectorAll('[data-adotta]').forEach(function(s){ Array.prototype.slice.call(s.children).forEach(function(x){ nvpParcheggio().appendChild(x); }); });
  el._html = html; el.innerHTML = html;
  nvpAdotta(el);
  const c1 = el.querySelector('.nvp-rs-car');
  if (c1 && c0){
    if (alt){ c1.style.transition = 'none'; c1.style.height = alt; }
    if (sx){ c1.scrollLeft = sx; const d = c1.nextElementSibling, i = Math.round(sx / Math.max(1, larg || c1.clientWidth)); if (d && d.children) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); }
    requestAnimationFrame(function(){ c1.style.transition = ''; });
  }
}
/* 0.9.307, Andrea: le linguette e il cambio di scheda come la sezione "featured collections" del tema Focal di
   dream-brothers.it (tabs-nav: selectButton, _transitionContent, _adjustNavigationPosition; product-list:
   apparitionAnimation). I pulsanti si fanno UNA volta: al cambio si spostano solo la classe "on" e la barretta
   (.nvp-pos), cosi' la barretta scorre invece di rinascere. */
function nvpTabsPaint(cur, fuori, anima){
  const row = document.getElementById('nvpTabs'); if (!row) return;
  const firma = NVP_SCHEDE.map(function(t){ return t.id + (t.id === 'sogno' && fuori ? '!' : ''); }).join('|');
  if (row._firma !== firma){
    const sx = row.scrollLeft;
    row._firma = firma;
    row.innerHTML = '<div class="nvp-tabs-in">' + NVP_SCHEDE.map(function(t){
      return '<button type="button" role="tab" data-nvp="' + t.id + '" aria-controls="nvp-' + t.id + '" aria-selected="false" class="pst-tab nvp-tab" onclick="nvpVai(\'' + t.id + '\')">'
        + (t.em ? '<i class="nvp-em" aria-hidden="true">' + t.em + '</i>' : '') + '<span>' + esc(t.t) + '</span>'
        + (t.id === 'sogno' && fuori ? '<u class="nvp-dot" aria-hidden="true"></u>' : '') + '</button>';
    }).join('') + '<span class="nvp-pos" aria-hidden="true"></span></div>';
    row.scrollLeft = sx;
    anima = false;
    /* la barretta si rimette a posto quando cambiano le misure: la scheda Sogno che si apre, i caratteri che arrivano */
    if (typeof ResizeObserver === 'function'){
      if (!row._ro){ row._ro = new ResizeObserver(function(){ nvpBarra(false); }); row._ro.observe(row); }
      row._ro.observe(row.firstElementChild);
    }
  }
  row.querySelectorAll('.nvp-tab').forEach(function(b){ const on = b.getAttribute('data-nvp') === cur; if (b.classList.contains('on') !== on){ b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); } });
  nvpBarra(anima);
}
/* Focal _adjustNavigationPosition: la riga scorre per mettere al centro la linguetta scelta; la barretta prende la sua
   larghezza (scale = bottone / riga) e la sua posizione (translate = offsetLeft / riga / scale) */
function nvpBarra(anima){
  const row = document.getElementById('nvpTabs'); if (!row) return;
  const inn = row.firstElementChild, pos = inn && inn.querySelector('.nvp-pos'), on = inn && inn.querySelector('.nvp-tab.on');
  if (!pos || !on) return;
  const W = inn.clientWidth; if (!(W > 0) || !(on.clientWidth > 0)) return;
  const s = on.clientWidth / W, t = on.offsetLeft / W / s;
  const rr = row.getBoundingClientRect(), ro = on.getBoundingClientRect();
  const left = Math.max(0, row.scrollLeft + (ro.left - rr.left) - row.clientWidth / 2 + ro.width / 2);
  if (Math.abs(row.scrollLeft - left) > 1){ try{ row.scrollTo({ left: left, behavior: anima ? 'smooth' : 'instant' }); }catch(_){ row.scrollLeft = left; } }
  pos.style.transition = anima ? '' : 'none';
  pos.style.setProperty('--nvp-s', String(s));
  pos.style.setProperty('--nvp-t', (t * 100) + '%');
  void pos.offsetWidth;
  requestAnimationFrame(function(){ pos.classList.add('pronta'); pos.style.transition = ''; });
}
function nvpPocoMoto(){ try{ return matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ return false; } }
/* i pezzi che entrano uno dopo l'altro: si scende finche' c'e' un solo figlio (la card), poi i suoi figli veri
   (niente fondi in position:absolute come la foto della card del sogno) */
function nvpPezzi(el, giro){
  const figli = Array.prototype.filter.call(el.children, function(c){
    if (!(c.offsetWidth > 0 || c.offsetHeight > 0)) return false;
    const p = getComputedStyle(c).position; return p !== 'absolute' && p !== 'fixed';
  });
  if (figli.length === 1 && giro < 6) return nvpPezzi(figli[0], giro + 1);
  return figli.length ? figli : [el];
}
/* Focal product-list.apparitionAnimation: opacita' 0 -> 1 e translateY(35px) -> 0, 600 ms, ease, ritardo 100*i - min(3*i*i, 100*i) */
function nvpEntrata(pane){
  (NV.nvpEnt || []).forEach(function(a){ try{ a.finish(); }catch(_){ } });
  NV.nvpEnt = [];
  if (!pane || typeof pane.animate !== 'function') return;
  const fermo = nvpPocoMoto();
  nvpPezzi(pane, 0).forEach(function(el, i){
    try{
      NV.nvpEnt.push(el.animate({ opacity: [0, 1], transform: ['translateY(' + (fermo ? 0 : 35) + 'px)', 'translateY(0)'] },
        { duration: 600, delay: fermo ? 0 : 100 * i - Math.min(3 * i * i, 100 * i), easing: 'ease', fill: 'backwards' }));
    }catch(_){ }
  });
}
/* Focal _transitionContent: la scheda vecchia sfuma in 250 ms, poi si nasconde e la nuova compare in 250 ms */
function nvpTransizione(cur){
  const corpo = document.querySelector('#nvPannello .nvp-corpo'), nuovo = document.getElementById('nvp-' + cur);
  if (!corpo || !nuovo) return;
  if (NV.nvpAn){ const v = NV.nvpAn; NV.nvpAn = null; try{ v.cancel(); }catch(_){ } }
  (NV.nvpEnt || []).forEach(function(a){ try{ a.finish(); }catch(_){ } });
  const mostra = function(){ NVP_SCHEDE.forEach(function(t){ const p = document.getElementById('nvp-' + t.id); if (p && p.hidden !== (p !== nuovo)) p.hidden = p !== nuovo; }); };
  const vecchio = Array.prototype.filter.call(corpo.children, function(p){ return !p.hidden && p !== nuovo; })[0];
  if (!vecchio || typeof vecchio.animate !== 'function'){ mostra(); nvpEntrata(nuovo); return; }
  const an = vecchio.animate({ opacity: [1, 0] }, { duration: 250, easing: 'ease' });
  NV.nvpAn = an;
  an.onfinish = function(){
    if (NV.nvpAn !== an) return;
    NV.nvpAn = null;
    mostra();
    try{ nuovo.animate({ opacity: [0, 1] }, { duration: 250, easing: 'ease' }); }catch(_){ }
    nvpEntrata(nuovo);
  };
}
/* 0.9.307, Andrea: con il dito di lato sul contenuto del pannello si passa alla scheda dopo (da destra a sinistra) o a
   quella prima (da sinistra a destra). La direzione si decide dopo i primi 10px: se il gesto e' piu' verticale la pagina
   scorre come sempre; una riga che scorre di lato dentro la scheda scorre lei finche' puo'; campi e slider restano loro. */
function nvpSwipe(corpo){
  if (!corpo || corpo._swipe) return;
  corpo._swipe = true;
  let x0 = 0, y0 = 0, t0 = 0, lato = null, riga = null, rigaSx = 0, attivo = false, fatto = 0;
  corpo.addEventListener('touchstart', function(e){
    attivo = false; lato = null; riga = null;
    if (e.touches.length !== 1) return;
    const el = e.target;
    if (el && el.closest && el.closest('input,textarea,select,[contenteditable="true"],[role="slider"],[data-no-swipe]')) return;
    const p = e.touches[0]; x0 = p.clientX; y0 = p.clientY; t0 = Date.now();
    for (let n = el; n && n !== corpo; n = n.parentElement){
      if (n.scrollWidth > n.clientWidth + 1){ const ox = getComputedStyle(n).overflowX; if (ox === 'auto' || ox === 'scroll'){ riga = n; rigaSx = n.scrollLeft; break; } }
    }
    attivo = true;
  }, { passive: true });
  corpo.addEventListener('touchmove', function(e){
    if (!attivo) return;
    if (typeof CST_DRAG !== 'undefined' && CST_DRAG && CST_DRAG.on){ attivo = false; return; }
    const p = e.touches[0], dx = p.clientX - x0, dy = p.clientY - y0;
    if (lato === null){
      if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return;
      if (Math.abs(dx) <= Math.abs(dy)){ attivo = false; return; }
      if (riga){ const max = riga.scrollWidth - riga.clientWidth; if ((dx < 0 && rigaSx < max - 1) || (dx > 0 && rigaSx > 1)){ attivo = false; return; } }
      lato = 'x';
    }
    if (e.cancelable) e.preventDefault();
  }, { passive: false });
  corpo.addEventListener('touchend', function(e){
    if (!attivo || lato !== 'x'){ attivo = false; return; }
    attivo = false;
    const p = (e.changedTouches || [])[0]; if (!p) return;
    const dx = p.clientX - x0, v = Math.abs(dx) / Math.max(1, Date.now() - t0);
    if (Math.abs(dx) < 50 && !(Math.abs(dx) > 24 && v > 0.35)) return;
    const cur = nvpScheda();
    let i = 0; NVP_SCHEDE.forEach(function(t, k){ if (t.id === cur) i = k; });
    const j = i + (dx < 0 ? 1 : -1);
    if (j < 0 || j >= NVP_SCHEDE.length) return;
    fatto = Date.now();
    nvpVai(NVP_SCHEDE[j].id);
  });
  corpo.addEventListener('touchcancel', function(){ attivo = false; });
  /* il dito che ha appena cambiato scheda non preme anche il pulsante su cui era partito */
  corpo.addEventListener('click', function(e){ if (Date.now() - fatto < 400){ e.stopPropagation(); e.preventDefault(); } }, true);
}
function nvpPaint(fuori, anima){
  if (!document.getElementById('nvPannello')) return;
  NV.fuoriP = !!fuori;
  const cur = nvpScheda();
  nvpTabsPaint(cur, !!fuori, !!anima);
  try{ nvpRiempi('nvpRitmo', nvpRitmoHtml()); }catch(_){ }
  try{ nvpRiempi('nvpPartita', nvpPartitaHtml()); }catch(_){ }
  try{ nvpRiempi('nvp-mappa', nvpMappaHtml()); }catch(_){ }
  try{ nvpRiempi('nvpConosce', (typeof epiConosceHtml === 'function') ? epiConosceHtml() : ''); }catch(_){ }
  if (anima) nvpTransizione(cur);
  else if (!NV.nvpAn) NVP_SCHEDE.forEach(function(t){ const p = document.getElementById('nvp-' + t.id); if (p && p.hidden !== (t.id !== cur)) p.hidden = t.id !== cur; });
}
/* la prossima tappa: la stessa di nvMossaHtml (che resta per la Mappa), vestita per il pannello scuro */
function nvpProssimaHtml(){
  /* 0.9.335, Andrea: "la prossima tappa e' SEMPRE quella della roadmap, non la task scritta a mano nel Full Focus":
     prima la tappa della mappa; il foglio di START solo per chi una roadmap non ce l'ha */
  const tp = (typeof stTappaOggi === 'function') ? stTappaOggi() : null;
  const t = tp ? '' : nvTask();
  const eti = '<small class="nvp-eti">' + NV_TAPPA_ICO + 'Prossima tappa</small>';
  if (tp) return eti + '<b class="nvp-h nvp-h0">' + esc(tp.nome) + '</b>'
    + '<button type="button" class="nvp-cta" onclick="nvMossaTappaVai(\'' + tp.id + '\')">' + NVP_PLAY + '<span>Inizia</span></button>';
  if (t) return eti + '<b class="nvp-h nvp-h0">' + esc(t) + '</b><p class="nvp-p">Una sessione di Full Focus, e la data d’arrivo si avvicina.</p>'
    + '<button type="button" class="nvp-cta" onclick="nvMossaVai()">' + NVP_PLAY + '<span>Inizia</span></button>'
    + '<button type="button" class="nvp-link" onclick="switchTab(\'sveglia\')">Vedi il foglio di oggi</button>';
  return eti + '<b class="nvp-h nvp-h0">Scrivi cosa fai oggi</b><p class="nvp-p">Il foglio della scheda START è ancora vuoto.</p>'
    + '<button type="button" class="nvp-cta" onclick="switchTab(\'sveglia\')">Apri il foglio</button>';
}
/* la Mappa: la cartina (tocco = la pagina grande, mpOpen) e sotto la prossima tappa. 0.9.317, Andrea: "via la percentuale e via
   'Apri la Mappa': basta toccare la cartina" */
function nvpMappaHtml(){
  let svg = '';
  try{
    if (typeof mpSvg === 'function' && typeof mpPartenza === 'function' && typeof mpArrivo === 'function' && mpPartenza() && mpArrivo()){
      if (typeof MP_TAPPE !== 'undefined' && MP_TAPPE && MP_TAPPE.length) svg = mpSvg(MP_TAPPE.slice(0, 6), false, true);
      else if (!NV.tappeChieste && typeof mpTappeDi === 'function'){
        NV.tappeChieste = true;
        mpTappeDi().then(function(t){ if (!MP_TAPPE && t && t.length) MP_TAPPE = t; nvpPaint(NV.fuoriP); }).catch(function(){ });
      }
    }
  }catch(_){ svg = ''; }
  return '<div class="nvp-in">'
    + (svg ? '<button type="button" class="nvp-map" onclick="mpOpen()" aria-label="Apri la cartina del viaggio">' + svg + '<span>Tocca per aprire la cartina</span></button>' : nvpIco('🗺️'))
    + nvpProssimaHtml() + '</div>';
}
/* ---------- IL RITMO, sotto alla data d'arrivo (0.9.317) ----------
   Andrea: "sotto alla scheda Sogno voglio due dati in croce che mostrino il ritmo: cosa ha determinato quella data, se nell'ultima
   settimana hai aumentato il passo o hai rallentato, se stai acquisendo slancio". Le settimane sono i punti del gioco (ftPuntiSettimana,
   gli stessi della schermata col cielo a fine tappa); i motivi sono il registro del navigatore (etaLog). Solo dati veri. */
const NVP_RITMO_NO = { prima: 1, genio: 1, veicolo: 1, reset: 1, aggiornamento: 1 };
function nvpSettimane(n){
  const out = [];
  for (let i = 0; i < n; i++){ let v = 0; try{ v = (typeof ftPuntiSettimana === 'function') ? ftPuntiSettimana(i * 7) : 0; }catch(_){ } out.unshift(v); }
  return out;
}
function nvpRitmoFrase(ora, prima){
  if (!(ora > 0) && !(prima > 0)) return { t: 'Il tuo ritmo parte da qui', s: 'Fai una tappa o una sessione: da questa settimana lo misuro.', k: 'pari' };
  if (!(prima > 0)) return { t: 'Hai cominciato a muoverti', s: 'È la prima settimana con dei punti: la prossima ti dico se acceleri.', k: 'su' };
  const r = ora / prima;
  if (r >= 1.15) return { t: 'Stai prendendo slancio', s: 'Questa settimana vai ' + String(Math.round(r * 10) / 10).replace('.', ',') + ' volte più veloce della scorsa.', k: 'su' };
  if (r <= 0.85) return { t: 'Stai rallentando', s: 'Questa settimana vai il ' + Math.round((1 - r) * 100) + '% più piano della scorsa.', k: 'giu' };
  return { t: 'Stai tenendo il ritmo', s: 'Vai alla stessa velocità della settimana scorsa.', k: 'pari' };
}
function nvpRitmoSvg(v){
  const max = Math.max.apply(null, v.concat([1]));
  const W = 280, H = 76, L = W / v.length, B = Math.min(26, L - 10);
  return '<svg class="nvp-rit-svg" viewBox="0 0 ' + W + ' ' + (H + 20) + '" role="img" aria-label="I punti delle ultime ' + v.length + ' settimane">'
    + v.map(function(x, i){
      const h = x > 0 ? Math.max(6, Math.round(x / max * H)) : 3, cx = L * i + L / 2, ultima = i === v.length - 1;
      return '<rect x="' + (cx - B / 2).toFixed(1) + '" y="' + (H - h) + '" width="' + B + '" height="' + h + '" rx="5" fill="' + (ultima ? '#3F9FF4' : 'rgba(188,224,255,.32)') + '"/>'
        + '<text x="' + cx.toFixed(1) + '" y="' + (H + 15) + '" text-anchor="middle" font-size="11" font-weight="' + (ultima ? 800 : 600) + '" fill="' + (ultima ? '#fff' : 'rgba(255,255,255,.62)') + '">' + (ultima ? 'Ora' : '-' + (v.length - 1 - i) + ' sett') + '</text>';
    }).join('') + '</svg>';
}
function nvpGiorniTxt(ms){
  const g = Math.abs(ms) / 86400000;
  if (g >= 1){ const n = Math.round(g); return n + (n === 1 ? ' giorno' : ' giorni'); }
  const h = Math.max(1, Math.round(g * 24));
  return h + (h === 1 ? ' ora' : ' ore');
}
/* quello che ha pesato di piu' sulla data in questi sette giorni: una voce che l'ha avvicinata e una che l'ha allontanata */
function nvpRitmoCause(){
  const da = Date.now() - 7 * 86400000, somma = {};
  let log = []; try{ log = (typeof etaLog === 'function') ? etaLog() : []; }catch(_){ log = []; }
  log.forEach(function(v){
    if (!v || !(v.at >= da) || typeof v.delta !== 'number' || !v.delta || NVP_RITMO_NO[v.tipo]) return;
    /* le voci vecchie con "Lavoro al computer: 0min" non dicono niente: erano ricalcoli all'apertura */
    if (v.tipo === 'pc' && !(v.vars && (v.vars.min > 0 || (v.vars.ore && !/^0\s*min/.test(v.vars.ore))))) return;
    let t = ''; try{ t = (typeof etaCausaTxt === 'function') ? String(etaCausaTxt(v) || '') : ''; }catch(_){ t = ''; }
    const k = v.tipo || t; if (!t) return;
    /* si tiene il testo piu' recente: quello con piu' minuti di computer di oggi, non il primo della settimana */
    if (!somma[k]) somma[k] = { t: t, d: 0 };
    somma[k].t = t;
    somma[k].d += v.delta;
  });
  const l = Object.keys(somma).map(function(k){ return somma[k]; });
  const meglio = l.filter(function(x){ return x.d < 0; }).sort(function(a, b){ return a.d - b.d; })[0];
  const peggio = l.filter(function(x){ return x.d > 0; }).sort(function(a, b){ return b.d - a.d; })[0];
  return { meglio: meglio, peggio: peggio };
}
function nvpRitmoHtml(){
  const v = nvpSettimane(6), ora = v[v.length - 1], prima = v[v.length - 2];
  const f = nvpRitmoFrase(ora, prima), c = nvpRitmoCause();
  /* 0.9.323, Andrea: "tre numeri insieme sono troppi: un carosello, e per ognuno la serie attuale e la piu' lunga". */
  const conta = function(giorni){
    const oggi = new Date(); oggi.setHours(12, 0, 0, 0);
    const k = function(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
    let att = 0; for (let i = giorni[k(oggi.getTime())] ? 0 : 1; i < 800 && giorni[k(oggi.getTime() - i * 86400000)]; i++) att++;
    const l = Object.keys(giorni).sort(); let max = 0, run = 0, prima = 0;
    l.forEach(function(x){ const t = new Date(x + 'T12:00:00').getTime(); run = (prima && Math.round((t - prima) / 86400000) === 1) ? run + 1 : 1; prima = t; if (run > max) max = run; });
    return [att, Math.max(max, att)];
  };
  const record = function(key, v){ let m = 0; try{ m = +localStorage.getItem(key) || 0; if (v > m){ m = v; localStorage.setItem(key, String(v)); } }catch(_){ } return Math.max(m, v); };
  let severa = 0, serieT = [0, 0], ffT = [0, 0];
  try{ severa = (typeof sfSerieSevera === 'function') ? sfSerieSevera() : 0; }catch(_){ }
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}, m = {}; Object.keys(g).forEach(function(x){ if (g[x]) m[x] = 1; }); serieT = conta(m); const uff = (typeof sdSerieMappa === 'function') ? (+sdSerieMappa() || 0) : 0; serieT = [uff, Math.max(serieT[1], uff)]; }catch(_){ }
  try{ const m = {}; (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x.ok && !x.meditazione){ const d = new Date(x.at); m[d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')] = 1; } }); ffT = conta(m); }catch(_){ }
  const slide = function(ico, tit, a, b){ return '<div class="nvp-rs"><p class="nvp-rs-t"><span>' + ico + '</span>' + tit + '</p><div class="nvp-rs-n"><div><b>' + a + '</b><small>Serie attuale</small></div><i></i><div><b>' + b + '</b><small>Serie più lunga</small></div></div></div>'; };
  /* 0.9.326, Andrea: "prima di tutti quei giorni di fila, come prima slide, solamente il grafico: mettere troppe cose insieme e' overwhelming" */
  /* 0.9.335, Andrea: "la prima slide con quel grafico e' una merda: un ponte che fa vedere dove sei e dove devi andare" (collo.js) */
  /* 0.9.341, Andrea: "Il tuo ritmo e' il titolo della slide del ponte, non di tutta la sezione: il collo di bottiglia e' un'altra
     cosa. E i giorni di fila vanno nella scheda Identita', dopo il campionato in diretta". Qui restano il collo e il ponte,
     ognuno con il suo titolo dentro la slide; le serie le scrive nvpSerieSlides per la scheda Identita'. */
  NVP_SERIE_DATI = { tappe: serieT[0], tappeMax: serieT[1], ff: ffT[0], severa: severa };
  NVP_SERIE_HTML = slide('🔥', 'Giorni di fila con una tappa', serieT[0], serieT[1]) + slide('⏱️', 'Giorni di fila in Full Focus', ffT[0], ffT[1]) + slide('🔒', 'Giorni di fila in modalità severa', severa, record('fl_severa_max', severa));
  const collo = (typeof cloSlideHtml === 'function') ? cloSlideHtml() : '';
  /* 0.9.348, Andrea: "l'arrivo previsto deve far parte del carosello, cosi' c'e' meno da guardare: arrivo, poi il collo di bottiglia" */
  /* 0.9.349, Andrea: "prima il collo di bottiglia, poi l'arrivo previsto, poi il ritmo". E "Cosa ha spostato la tua data" sta SOLO nella slide
     dell'arrivo, e solo quando la data si vede ed e' stata ricalcolata: nei primi giorni ("la data arriva fra 1 giorno") non c'e' niente da spiegare */
  let velata = false; try{ velata = typeof evVelata === 'function' && evVelata(); }catch(_){ }
  const link = (!velata && (c.meglio || c.peggio)) ? '<button type="button" class="nvp-rit-link" onclick="nvpRitmoInfo()">Cosa ha spostato la tua data in 7 giorni</button>' : '';
  const arrivo = document.getElementById('nvArrCard') ? '<div class="nvp-rs nvp-rs-arr"><div class="nvp-arr-box" data-adotta="nvArrCard"></div>' + link + '</div>' : '';
  const ritmo = (typeof cloPonteSlideHtml === 'function') ? cloPonteSlideHtml() : '<div class="nvp-rs nvp-rs-g"><p class="nvp-rit-k nvp-rs-k">Il tuo ritmo</p><b class="nvp-rit-t ' + f.k + '">' + esc(f.t) + '</b><p class="nvp-rit-s">' + esc(f.s) + '</p></div>';
  const n = (collo ? 1 : 0) + (arrivo ? 1 : 0) + 1;
  let dots = ''; for (let i = 0; i < n; i++) dots += '<i' + (i ? '' : ' class="on"') + '></i>';
  return '<section class="nvp-rit">'
    /* 0.9.351, Andrea: "l'arrivo previsto e' l'ultima slide del carosello" */
    + '<div class="nvp-rs-car" onscroll="nvpRsDot(this)">' + collo + ritmo + arrivo + '</div>' + (n > 1 ? '<div class="nvp-rs-dots">' + dots + '</div>' : '')
    + '</section>';
}
/* 0.9.318, Andrea: "cosa ha spostato la data" allungava troppo la scheda: sta in un foglio, dalla (i) accanto al titolo */
function nvpRitmoInfoBtn(c){
  return (c.meglio || c.peggio) ? '<button type="button" class="nvp-i" onclick="nvpRitmoInfo()" aria-label="Cosa ha spostato la tua data"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v7M12 6.5v.2"/></svg></button>' : '';
}
/* 0.9.340, Andrea: "le slide dei giorni di fila non ricalcolano l'altezza: fai come il carosello della Lega". L'altezza segue la slide che vedi */
function nvpRsDot(c){ const d = c.nextElementSibling, i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)); if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); nvpRsAltezza(c, i); }
/* 0.9.344, Andrea: "se provo a scorrere verso l'alto il testo della slide viene tagliato, perche' il pannello si muove". Scorrendo la pagina
   il dito spostava un filo anche il carosello, e l'altezza passava a quella dell'altra slide: ora cambia solo a carosello fermo su una slide */
/* 0.9.347, Andrea (quarta volta): "la slide balla se faccio su e giu' con il dito e taglia il titolo IL TUO RITMO". LA CAUSA: il carosello
   ha overflow-x:auto, e per le regole del CSS l'asse verticale diventa auto anche lui. La sua altezza e' quella della slide che guardi,
   ma l'altra slide e' piu' alta: il carosello aveva qualcosa da scorrere in verticale, e il dito che scorre la pagina lo spostava di
   qualche pixel, tagliando la cima. Adesso il verticale e' chiuso (overflow-y:hidden) e se qualcosa lo sposta torna a zero. */
function nvpRsAltezza(c, i){ if (c && c.scrollTop) c.scrollTop = 0; const sl = c && c.children[i]; if (!sl) return; if (Math.abs(c.scrollLeft - i * c.clientWidth) > 3) return; const h = sl.scrollHeight; if (h && c.style.height !== h + 'px') c.style.height = h + 'px'; }
setInterval(function(){ document.querySelectorAll('.nvp-rs-car').forEach(function(c){ if (c.offsetParent) nvpRsAltezza(c, Math.round(c.scrollLeft / Math.max(1, c.clientWidth))); }); }, 500);
document.addEventListener('scroll', function(e){ const c = e.target; if (c && c.classList && c.classList.contains('nvp-rs-car') && c.scrollTop) c.scrollTop = 0; }, true);
/* 0.9.326, Andrea: "dovrebbe esserci lo stesso recap del foglio Perche' la data si e' spostata": le stesse voci, sui sette giorni */
function nvpRitmoInfo(){
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const da = Date.now() - 7 * 86400000;
  let log = []; try{ log = (typeof etaLog === 'function') ? etaLog() : []; }catch(_){ log = []; }
  let pian = 0, fatte = 0, dG = 0, somma = 0, conG = false;
  const altre = [];
  log.forEach(function(v){
    if (!v || !(v.at >= da) || typeof v.delta !== 'number' || NVP_RITMO_NO[v.tipo]) return;
    somma += v.delta;
    if (v.tipo === 'giornata' || v.tipo === 'giornate'){ const x = v.vars || {}; pian += +x.pianOre || 0; fatte += +x.fatteOre || 0; dG += v.delta; conG = true; return; }
    if (Math.abs(v.delta) < NV_MIN_SPOST && ['mollata', 'rimandata', 'imprevisto'].indexOf(v.tipo) < 0) return;
    const f = (typeof prcFrase === 'function') ? prcFrase(v) : { ico: '•', t: String((typeof etaCausaTxt === 'function') ? etaCausaTxt(v) : '') };
    altre.push({ ico: f.ico, t: f.t, delta: v.delta });
  });
  if (conG && pian > 0) altre.push({ ico: '📉', t: 'In questi giorni avevi in programma ' + prcOre(pian) + ' di lavoro sul sogno e ne hai fatte ' + (fatte > 0 ? prcOre(fatte) : 'zero') + '.', delta: dG });
  altre.sort(function(x, y){ return Math.abs(y.delta) - Math.abs(x.delta); });
  const chip = function(ms){ if (Math.abs(ms) < 60000) return ''; return '<i class="' + (ms > 0 ? 'su' : 'giu') + '">' + (ms > 0 ? '+' : '−') + esc((typeof prcTempo === 'function') ? prcTempo(ms) : nvpGiorniTxt(ms)) + '</i>'; };
  const righe = altre.slice(0, 6).map(function(x){ return '<div class="prc-r"><span>' + x.ico + '</span><p>' + esc(x.t) + '</p>' + chip(x.delta) + '</div>'; });
  if (conG && typeof prcPianoRigaHtml === 'function') righe.push(prcPianoRigaHtml());
  if (!righe.length) righe.push('<div class="prc-r"><span>🔎</span><p>In questi sette giorni non è successo niente che abbia spostato il tuo arrivo.</p></div>');
  const testa = Math.abs(somma) < NV_MIN_SPOST ? 'Nel complesso il tuo arrivo è rimasto dov’era.' : 'Nel complesso il tuo arrivo si è spostato di <b>' + esc(nvGiorni(somma)) + '</b>' + (somma > 0 ? ' più in là.' : ' più vicino a te.');
  inSheet('<div class="prc prc-ritmo"><b class="prc-t">Cosa ha spostato la tua data in questi 7 giorni</b><p class="prc-p">' + testa + '</p>'
    /* 0.9.335, Andrea: "troppe cose attaccate: una linea del tempo con i pallini che le collega, distanziate" */
    + '<div class="prc-lista prc-tl">' + righe.join('') + '<div class="prc-r" id="prcAppRiga" hidden></div></div>'
    + (somma >= NV_MIN_SPOST ? '<button type="button" class="cta prc-cta" onclick="inSheetChiudi();if(typeof nvRientraRicalcolo===\'function\')nvRientraRicalcolo()">Il Genio ti aiuta a rientrare</button>' : '')
    + '<button type="button" class="prc-link" onclick="inSheetChiudi();if(typeof etaTimelineApri===\'function\')etaTimelineApri()">Vedi tutti i ricalcoli</button></div>');
  /* 0.9.349, Andrea: "la timeline si anima man mano che scorro, come una sezione GSAP: il primo blocco si vede, gli altri sfumati e si accendono scorrendo" */
  try{ if (typeof flScrubRivela === 'function') flScrubRivela(document.querySelector('#inSheet .prc-tl'), '.prc-r'); }catch(_){ }
  /* il telefono: dove sono finite le ore */
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps) NATIVE.getTopApps({ from: da, to: Date.now(), limit: 40, icons: 0 }).then(function(r){
      let cats = {}; try{ cats = (typeof insCats === 'function') ? insCats(null) : {}; }catch(_){ }
      const l = ((r && r.apps) || []).filter(function(x){ return cats[x.packageName] === 'distr' || (!cats[x.packageName] && PRC_DISTR.indexOf(x.packageName) >= 0); }).sort(function(p, q){ return (q.ms || 0) - (p.ms || 0); });
      const el = document.getElementById('prcAppRiga'); const a0 = l[0];
      if (!el || !a0 || (a0.ms || 0) < 3600000) return;
      el.innerHTML = '<span>📱</span><p>In questi sette giorni hai passato ' + prcOre(a0.ms / 3600000) + ' su ' + esc(a0.label || a0.appName || '') + '.</p>'; el.hidden = false;
    }).catch(function(){ });
  }catch(_){ }
}
/* la scheda Identita': prima il punteggio della partita (i voti per chi vuoi diventare), poi "Se continui cosi'" */
/* 0.9.341, Andrea: "nella scheda Identita' la prima slide del carosello e' il campionato in diretta, poi i giorni di fila
   con una tappa, in Full Focus e in modalita' severa" */
let NVP_SERIE_HTML = '', NVP_SERIE_DATI = null;
function nvpSerieSlides(){ if (!NVP_SERIE_HTML){ try{ nvpRitmoHtml(); }catch(_){ } } return NVP_SERIE_HTML; }
/* 0.9.348, Andrea: "nella scheda Identita': prima il campionato in diretta con sotto il riepilogo delle statistiche della partita e un +
   (le altre schede solo nella pagina della partita), poi 'Se continui cosi' rischi di diventare', poi UNA slide con le serie. Tre serie in
   tre slide sono troppe: si parte dalla serie di tappe, le altre stanno piccole sotto". */
function nvpSerieUna(){
  nvpSerieSlides();
  const d = NVP_SERIE_DATI || {};
  const riga = function(ico, t, v){ return '<div class="nvp-su-r"><span>' + ico + '</span><b>' + t + '</b><em>' + v + '</em></div>'; };
  /* 0.9.349, Andrea: "il numero non e' al centro, il fuoco spinge tutto a destra: il numero sopra, il fuoco sotto al numero" */
  /* 0.9.350, Andrea: "sopra voleva dire sovrapposto: il numero DENTRO al fuoco, come nel pannello della pagina Modalita' severa" */
  return '<div class="nvp-rs nvp-su-w"><div class="nvp-su"><p class="nvp-rit-k nvp-rs-k">Le tue serie</p>'
    + '<div class="nvp-su-top"><span class="nvp-su-fuoco" aria-hidden="true">🔥<b>' + (d.tappe || 0) + '</b></span><small>' + ((d.tappe || 0) === 1 ? 'giorno di fila con una tappa' : 'giorni di fila con una tappa') + '</small></div>'
    + '<small class="nvp-su-mx">Record: ' + (d.tappeMax || 0) + '</small>'
    + '<div class="nvp-su-l">' + riga('⏱️', 'In Full Focus', (d.ff || 0) + (d.ff === 1 ? ' giorno' : ' giorni')) + riga('🔒', 'In modalità severa', (d.severa || 0) + (d.severa === 1 ? ' giorno' : ' giorni')) + '</div></div></div>';
}
/* 0.9.349, Andrea: "il campionato e il riepilogo sono due pannelli separati: sotto al punteggio lo STESSO pannello della pagina della
   partita (Oggi, 7 giorni, 30 giorni), con la scheda Riepilogo e la scheda +". E' un pezzo vivo (#pstBoxMini, partita-stats.js) adottato
   dalla slide come l'arrivo previsto: si ridisegna da solo quando cambi scheda o periodo */
function nvpRiepilogoHtml(){
  if (typeof pstPaint !== 'function') return '';
  if (!document.getElementById('pstBoxMini')){ const b = document.createElement('div'); b.id = 'pstBoxMini'; b.className = 'pst pst-mini'; nvpParcheggio().appendChild(b); try{ pstPaint(); }catch(_){ } }
  return '<div class="nvp-riep-box" data-adotta="pstBoxMini"></div>';
}
/* 0.9.349, Andrea: "nella scheda Identita' la prima slide e' chi stai diventando, il riassunto; la seconda il punteggio della partita" */
function nvpPartitaHtml(){
  const par = nvpPartitaSlideHtml();
  const life = document.getElementById('scLife') ? '<div class="nvp-rs nvp-rs-life" data-adotta="scLife"></div>' : '';
  const serie = nvpSerieUna();
  const n = (par ? 1 : 0) + (life ? 1 : 0) + 1;
  let dots = ''; for (let i = 0; i < n; i++) dots += '<i' + (i ? '' : ' class="on"') + '></i>';
  return '<section class="nvp-rit nvp-id-rit"><div class="nvp-rs-car" onscroll="nvpRsDot(this)">'
    + life + (par ? '<div class="nvp-rs nvp-rs-par"><div class="nvp-par-box">' + par + '</div>' + nvpRiepilogoHtml() + '</div>' : '') + serie + '</div>' + (n > 1 ? '<div class="nvp-rs-dots">' + dots + '</div>' : '') + '</section>';
}
function nvpPartitaSlideHtml(){
  if (typeof paTabelloneDati !== 'function') return '';
  const d = paTabelloneDati();
  return '<button type="button" class="nvp-par" onclick="if(typeof paApri===\'function\')paApri();else goId(\'s-partita\')" aria-label="Apri la partita fra il vecchio te e il nuovo te">'
    + '<small class="nvp-rit-k">' + esc(d.etichetta) + '</small>'
    + '<div class="pa-tab"><div class="pa-lato"><span class="pa-av old">' + paStemma('Old', d.ini) + '</span><small>Vecchio te</small></div><div class="pa-score">' + d.old + '<i>:</i>' + d.neo + '</div><div class="pa-lato"><span class="pa-av neo">' + paStemma('Neo', d.ini) + '</span><small>Nuovo te</small></div></div></button>';
}
/* le scorciatoie, nell'ordine che ha dato Andrea */
/* LA SLIDESHOW NON CAMBIA ALTEZZA. In modalita' «alta» ogni diapositiva prende l'altezza del
   suo contenuto, e quella della frase (una riga troncata) era piu' bassa delle altre: la
   pagina saltava a ogni scorrimento. Si misura la piu' alta vista finora e si impone a tutte. */
/* 0.9.314, Andrea: "non voglio piu' dovertelo ripetere". La misura e' sparita: era il difetto. Le slide nascoste stavano
   in display:none, un'altezza comune si ricavava misurandole una a una in momenti scelti (firma, scroll, immagini) e bastava
   una misura sbagliata per rompere tutto. Adesso stanno tutte nella stessa cella di una griglia, sempre presenti e
   invisibili: la cella e' alta come la piu' alta per costruzione, senza una riga di calcolo (regole #nvHero .bh-track). */
function nvHeroPareggia(){ }
/* (0.9.265: niente piu' misura a ogni cambio di slide: il cambio di slide non cambia le altezze) */
/* l'altezza giusta fin dal primo sguardo: quando la scheda si apre, e quando le immagini arrivano */
document.addEventListener('fl:tab', function(e){ if (e.detail === 'rotta'){ [120, 600, 1500].forEach(function(ms){ setTimeout(nvHeroPareggia, ms); }); } });
addEventListener('load', function(){ setTimeout(nvHeroPareggia, 300); });
function nvChipsHtml(){
  const c = function(ico, t, on){ return '<button type="button" class="nv-chip" onclick="' + on + '"><span>' + ico + '</span><b>' + t + '</b></button>'; };
  return '<div class="nv-chips-wrap"><div class="nv-chips-row">'
    + c('🛡️', 'Protezione', 'blPaginaApri()')
    + c('🌤️', 'Controllo dell\u2019umore', 'if(typeof umScorciatoia===\'function\')umScorciatoia()')
    + nvChipsRespiro(c)
    + c('❝', 'Ispirazione quotidiana', 'if(typeof scOpenInspire===\'function\')scOpenInspire()')
    + c('🪶', 'I miei appunti', 'if(typeof noApri===\'function\')noApri(\'\')')
    + c('🎵', 'Suoni per concentrarsi', 'if(typeof sndPaginaApri===\'function\')sndPaginaApri()')
    + c('📊', 'Report', 'switchTab(\'insights\')')
    + c('📅', 'Date d\u2019assenza', 'if(typeof asApri===\'function\')asApri(\'dream\')')
    + '</div></div>';
}
/* IL RESPIRO GUIDATO (0.9.221): UNA scorciatoia, che porta alla pagina dei respiri. Nella
   0.9.220 c'era una chip per ogni esercizio: Andrea, «non devi mettere una shortcut per ogni
   respiro». La scelta dell'esercizio si fa nella pagina. */
function nvChipsRespiro(c){
  if (typeof flSezioneBloccata === 'function' && flSezioneBloccata('respiro')) return '';
  return c('🌬️', 'Respiro guidato', 'if(typeof rsApri===\'function\')rsApri({da:\'dream\'})');
}
function nvWidgetsHtml(){
  let serie = 0, ff = 0, meta = 3, lega = 0, monete = 0;
  try{ serie = (typeof sfSerieSevera === 'function') ? sfSerieSevera() : 0; }catch(_){ }
  try{ const d0 = new Date(); d0.setHours(0, 0, 0, 0); ff = (typeof ffHist === 'function' ? ffHist() : []).filter(function(x){ return x.ok && !x.meditazione && x.at >= d0.getTime(); }).length; }catch(_){ }
  try{ meta = (typeof serMeta === 'function') ? serMeta() : 3; }catch(_){ }
  try{ lega = (typeof frPuntiLega === 'function') ? frPuntiLega() : 0; }catch(_){ }
  try{ monete = (typeof ffCoins === 'function') ? ffCoins() : 0; }catch(_){ }
  const w = function(ico, l, v, s, on){ return '<button type="button" class="nv-w" onclick="' + on + '"><span>' + ico + '</span><small>' + l + '</small><b>' + v + '</b><em>' + s + '</em></button>'; };
  return '<div class="nv-widgets">'
    + w('🔒', 'Serie in modalità severa', serie + (serie === 1 ? ' giorno' : ' giorni'), 'di fila', 'svpApri()')
    + w('🌱', 'Full Focus oggi', ff + '/' + meta, 'sessioni', 'ffOpen()')
    + w('🏆', 'Lega', lega.toLocaleString('it-IT') + ' pt', 'questa settimana', 'frOpen(\'lega\')')
    + w('🪙', 'Monete', String(monete), 'apri il negozio', 'ngApri()')
    + '</div>';
}
/* RIENTRA IN ROTTA (0.9.212): non piu' trenta minuti di Full Focus e via (la cura del sintomo),
   ma la diagnosi di rientro.js: cosa ti ha fermato, il collo di bottiglia, il rimedio che cambia
   il sistema. La data non si ricalcola al tocco: torna indietro quando le cose si fanno. */
function nvRientra(){
  const v = NV.proposta; nvVisto(v); NV.proposta = null;
  nvPaint();
  if (typeof rnApri === 'function'){ rnApri(v); return; }
  try{ const p = ffPref(); p.minutes = 30; ffSavePref(); }catch(_){ }
  if (typeof stGoFocus === 'function') stGoFocus(); else if (typeof ffOpen === 'function') ffOpen();
}
/* La card del Genio quando sei fuori rotta: la stessa della lettura a episodi (sfera, titolo,
   pulsante), con un altro testo. Da qui parte la diagnosi di rientro.js. */
/* 0.9.218, COME NEL PROTOTIPO DI CLAUDE DESIGN: tutto centrato, l'etichetta blu, il titolo, il
   testo grigio, il pulsante blu alto 52 con la freccia a U (u_turn_left di Material Symbols,
   qui in SVG perche' il font delle icone non c'e' nell'app) e «Non ora» subito sotto, a 8 px. */
const NV_UTURN = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M18 9v12h-2V9c0-2.21-1.79-4-4-4S8 6.79 8 9v4.17l1.59-1.59L11 13l-4 4-4-4 1.41-1.41L6 13.17V9c0-3.31 2.69-6 6-6s6 2.69 6 6z"/></svg>';
/* 0.9.219: la bussola torna (le immagini fanno capire subito di cosa si parla), il bordo e' rosso
   perche' sei fuori rotta, e il testo non sgrida: sei tu che scegli di farti aiutare dal Genio. */
function nvRientroCardHtml(testo, via, nonOra){
  /* 0.9.321, Andrea: chi ha gia' iniziato il rientro lo riprende: il pulsante e' rosso e lo dice */
  const ripresa = (typeof drsRientroPronto === 'function') && drsRientroPronto();
  return '<div class="nv-rientro"><span class="nv-rientro-ico" aria-hidden="true">🧭</span><div class="nv-rot"><b>Hai perso la rotta</b><b class="b2">Ti riporto in rotta</b></div>'
    + '<p>' + esc(testo) + '</p>'
    + '<button type="button" class="nv-rientro-via' + (ripresa ? ' riprendi' : '') + '" onclick="' + via + '">' + NV_UTURN + (ripresa ? 'Riprendi il rientro' : 'Rientra in rotta') + '</button>'
    + '<button type="button" class="nv-rientro-no" onclick="' + nonOra + '">Non ora</button></div>';
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.nv-rientro{background:var(--card,#fff);border:2px solid #F2A3AA;border-radius:22px;padding:24px 20px 14px;text-align:center;box-shadow:0 10px 26px rgba(230,57,70,.10)}body.dark .nv-rientro{background:#12203A;border-color:#B33A46}'
    + '.nv-rientro-ico{display:block;font-size:44px;line-height:1}'
    + '.nv-rientro b{display:block;margin-top:12px;font:800 21px/1.25 var(--font-display);color:var(--navy)}body.dark .nv-rientro b{color:#fff}'
    + '.nv-rientro p{margin:10px 4px 0;font:500 14.5px/1.6 var(--font-body);color:var(--muted)}'
    + '.nv-rientro-via{margin-top:20px;width:100%;height:52px;border:0;border-radius:26px;background:#0075E3;color:#fff;font:600 15px var(--font-body);display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.25)}'
    + '.nv-rientro-via.riprendi{background:#E63946;box-shadow:0 8px 20px rgba(230,57,70,.28)}'
    + '.nv-rientro-no{margin-top:8px;border:0;background:transparent;color:var(--muted);font:600 13.5px var(--font-body);padding:8px 16px;cursor:pointer}';
  document.head.appendChild(st);
})();
function nvRientroFirma(b){ return (typeof etaOggiK === 'function' ? etaOggiK() : new Date().toDateString()) + ':' + Math.round(b.delta / 86400000); }
function nvRientroFatto(b){ if (NV_NONORA && NV_NONORA === nvRientroFirma(b)) return true; try{ return localStorage.getItem('fl_nv_rientro') === nvRientroFirma(b); }catch(_){ return false; } }
function nvRientroSegna(){ const b = nvBollino(); if (b && b.delta > 0) try{ localStorage.setItem('fl_nv_rientro', nvRientroFirma(b)); }catch(_){ } }
/* «Non ora» lo nasconde fino al prossimo avvio dell'app, non per sempre: il pannello del
   ricalcolo resta finche' il Genio non ha trovato la causa e tu non hai scelto il rimedio
   (rientro.js chiama nvRientroSegna). Prima spariva al primo tocco su «Rientra in rotta». */
let NV_NONORA = '';
/* L'AEREO SI MUOVE (0.9.236): parte da dove era l'ultima volta e vola fino alla percentuale nuova.
   Se la percentuale scende (il ricalcolo), torna indietro girato verso "Oggi", poi si rimette in rotta. */
let NV_AEREO_PRIMA = null;
function nvAereoAnima(pct){
  if (NV_AEREO_PRIMA === null){ try{ NV_AEREO_PRIMA = parseFloat(localStorage.getItem('fl_nv_aereo') || ''); }catch(_){ } if (!isFinite(NV_AEREO_PRIMA)) NV_AEREO_PRIMA = pct; }
  const da = NV_AEREO_PRIMA, indietro = pct < da - 0.05;
  document.querySelectorAll('.nv-linea').forEach(function(l){
    const em = l.querySelector('em'), i = l.querySelector('i'); if (!em || !i) return;
    if (Math.abs(pct - da) < 0.05) return;
    em.style.transition = 'none'; i.style.transition = 'none';
    em.style.left = da + '%'; i.style.width = da + '%';
    if (indietro) em.classList.add('indietro');
    void em.offsetWidth;
    setTimeout(function(){
      em.style.transition = ''; i.style.transition = '';
      em.style.left = pct + '%'; i.style.width = pct + '%';
      if (indietro) setTimeout(function(){ em.classList.remove('indietro'); }, 1500);
    }, 40);
  });
  NV_AEREO_PRIMA = pct;
  try{ localStorage.setItem('fl_nv_aereo', String(pct)); }catch(_){ }
}
/* il "Non ora" alla chiamata dei sogni (dreamcall.js scrive fl_rientro_forzato): vale per oggi,
   finche' non lo apri o non dici di nuovo "Non ora" */
function nvForzato(){
  let f = null; try{ f = JSON.parse(localStorage.getItem('fl_rientro_forzato') || 'null'); }catch(_){ f = null; }
  if (!f || !f.at || f.visto) return null;
  if (new Date(f.at).toDateString() !== new Date().toDateString()) return null;
  return f;
}
function nvForzatoSegna(){ const f = nvForzato(); if (!f) return; f.visto = Date.now(); try{ localStorage.setItem('fl_rientro_forzato', JSON.stringify(f)); }catch(_){ } }
function nvForzatoVia(){ const f = nvForzato(); nvForzatoSegna(); nvPaint(); if (typeof rnApri === 'function') rnApri({ tipo: 'chiamata', delta: 0, titolo: (f && f.titolo) || '', condizione: (f && f.condizione) || '' }); }
function nvForzatoNo(){ nvForzatoSegna(); nvPaint(); }
function nvRientroNonOra(){ const b = nvBollino(); NV_NONORA = b ? nvRientroFirma(b) : ''; nvPaint(); }
function nvRientraRicalcolo(){
  const b = nvBollino();
  if (typeof rnApri === 'function') rnApri({ tipo: 'ricalcolo', delta: b ? b.delta : 0, at: Date.now() });
}
function nvPropostaChiudi(){ nvVisto(NV.proposta); NV.proposta = null; nvPaint(); }

document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'rotta') return;
  nvPaint();
  setTimeout(function(){ try{ if (typeof scLifePaint === 'function') scLifePaint(); }catch(_){ } }, 260);
  setTimeout(function(){ try{ if (typeof ptPortePaint === 'function') ptPortePaint(); }catch(_){ } }, 40);
});
document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.querySelector('#tab-rotta.on')) nvPaint(); });
setTimeout(nvPaint, 900);
setInterval(function(){ if (document.querySelector('#tab-rotta.on') && !(typeof flInScroll === 'function' && flInScroll())) nvPaint(); }, 60000);

(function(){
  const css = [
    '.nv-page{display:flex;flex-direction:column;gap:20px;padding:4px 0 120px}',
    /* LA SLIDESHOW NON CAMBIA ALTEZZA, per costruzione: tutte le slide nella stessa cella, le spente invisibili ma presenti */
    '#nvHero .bh-track{display:grid;grid-template-columns:minmax(0,1fr);height:auto}',
    '#nvHero .bh-track > .bh-slide{grid-area:1/1;position:relative !important;inset:auto !important;display:flex !important;flex-direction:column;justify-content:center;min-width:0;min-height:0}',
    '#nvHero .bh-track > .bh-slide:not(.on):not(.bh-out):not(.bh-in){visibility:hidden;opacity:0;pointer-events:none}',
    /* il contenuto di ogni slide sta al centro dell\'altezza comune */
    '#nvHero.bh--tall .bh-slide.on{display:flex;flex-direction:column;justify-content:center}#nvHero.bh--tall .bh-slide.on > .bh-stack,#nvHero.bh--tall .bh-slide.on > .bh-text{flex:none}',
    /* centrata fra l'intestazione (in alto) e le lineette (in basso); se la frase e' lunga la
       diapositiva cresce verso il basso, non sale sotto ai pulsanti dell'intestazione */
    '#nvHero .bh-quote{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;min-height:360px;box-sizing:border-box;padding:104px 30px 110px}',
    '#nvHero .bh-q-text,#nvHero .bh-q-author{text-align:center;width:100%}',
    /* sale dal basso E poi si accende, come «Discover» */
    '#nvHero .bh-q-btn.bh-q-in{animation:bhCtaIn .55s ease both,bhGlow 1.6s ease-in-out .55s infinite}',
    '#nvChips:empty{display:none}.nv-chips-wrap{margin:-6px -18px 0;padding:0 18px;overflow-x:auto;scrollbar-width:none}.nv-chips-wrap::-webkit-scrollbar{display:none}',
    '.nv-chips-row{display:flex;gap:10px;width:max-content;padding-bottom:2px}',
    '.nv-chip{display:flex;align-items:center;gap:9px;border:0;border-radius:16px;background:var(--card,#fff);color:var(--navy);padding:13px 16px;font:700 14px var(--font-body);cursor:pointer;box-shadow:0 6px 18px rgba(0,30,68,.10);white-space:nowrap}',
    'body.dark .nv-chip{background:#1A2338;color:#fff;box-shadow:none}.nv-chip span{font-size:18px;line-height:1}.nv-chip b{font-weight:700}',
    '.nv-card{border-radius:28px;overflow:hidden;color:#fff;background:linear-gradient(180deg,rgba(0,117,227,.25) 0%,rgba(0,117,227,.55) 45%,rgba(0,19,43,.92) 100%),url(img/dream-night.jpg) center 75%/cover no-repeat,#001E44;box-shadow:0 16px 40px rgba(0,30,68,.28);transition:box-shadow .4s}',
    '.nv-card.fuori{box-shadow:0 0 0 2px #E63946,0 16px 40px rgba(230,57,70,.25)}',
    '.nv-in{padding:16px 20px 20px;display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.nv-top{width:100%;display:flex;align-items:center;justify-content:space-between}',
    /* IL CERCHIO ERA UN OVALE: dentro a un flex il tondo si lasciava schiacciare dal testo
       lungo. flex:none per il tondo e per la matita, e il testo e' quello che cede, su una
       riga, con i puntini. */
    '.nv-sogno{display:flex;align-items:center;gap:8px;min-width:0;flex:1;margin-right:10px;font:600 13px var(--font-body)}',
    '.nv-sogno i{flex:none;width:32px;height:32px;border-radius:16px;background:var(--nv-tinta,rgba(255,255,255,.16));display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:16px}',
    '.nv-sogno em{font-style:normal;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}',
    '.nv-edit{flex:none;width:36px;height:36px;border-radius:18px;border:0;background:rgba(255,255,255,.16);color:#fff;font-size:16px;cursor:pointer}',
    '.nv-pop{animation:nvPop .45s cubic-bezier(.3,1.5,.5,1) both}',
    '@keyframes nvPop{0%{opacity:0;transform:scale(.92)}100%{opacity:1;transform:none}}',
    '.nv-eti{display:block;font:600 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#BFE0FF;margin-top:20px}',
    '.nv-titolo{display:block;margin-top:8px;font:800 24px/1.2 var(--font-display);font-style:italic}',
    '.nv-p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.85);max-width:30ch}',
    '.nv-cta{max-width:300px}',
    '.nv-data{background:none;border:0;color:#fff;padding:0;margin-top:6px;cursor:pointer}',
    '.nv-data b{display:block;font:900 54px/0.98 var(--font-display);letter-spacing:-.03em}.nv-data span{display:block;font:300 54px/0.98 var(--font-display);letter-spacing:-.03em;color:#BFE0FF}',
    '.nv-skel{margin-top:10px;display:flex;flex-direction:column;align-items:center;gap:10px;height:98px;justify-content:center}',
    '.nv-skel i{display:block;height:40px;border-radius:12px;background:linear-gradient(90deg,rgba(255,255,255,.12) 0%,rgba(255,255,255,.35) 50%,rgba(255,255,255,.12) 100%) 0 0/240px 100%;animation:nvShimmer 1s linear infinite}',
    '@keyframes nvShimmer{0%{background-position:-240px 0}100%{background-position:240px 0}}',
    '.nv-pills{margin-top:14px;display:flex;gap:8px;align-items:center;justify-content:center;flex-wrap:wrap}',
    '.nv-col{display:flex;flex-direction:column;gap:20px}',
    '#nvHero .nv-arr{padding:calc(var(--hdr-h,64px) + 8px) 22px 84px}',
    /* la copertina: il blu scuro del quiz sotto alla foresta con le stelle, l'aura che gira */
    '#nvHero .nv-cover-s{background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C)}',
    '#nvHero .nv-cover-s .bh-img{opacity:.92}#nvHero .nv-cover-s .bh-ov{background:linear-gradient(180deg,rgba(4,11,28,.2) 0%,rgba(4,11,28,.15) 45%,rgba(4,11,28,.7) 100%)}',
    '#nvHero .nv-cover{padding:26px 22px 78px}',
    /* lo slideshow non sta piu' sotto all'intestazione: niente spazio per lei nelle slide */
    '#nvHero .nv-arr-s .nv-arr{padding:22px 22px 84px}',
    /* GLI ANGOLI DELLA SLIDE (0.9.189). Il sogno in alto a sinistra e la matita in alto a
       destra, staccati dalla data: prima la riga stava incollata sopra «Arrivo previsto» e
       tutto il blocco si centrava insieme. Lo stack riempie la slide, la riga va negli angoli,
       e il centro resta alla data. */
    '#nvHero .bh-slide.on.nv-arr-s > .nv-arr{flex:1 1 auto;display:flex;flex-direction:column;justify-content:center;padding:68px 22px 76px}',
    '#nvHero .nv-arr-s .nv-top{position:absolute;top:16px;left:16px;right:16px;width:auto;z-index:2}',
    '#nvHero .nv-bf-s .bh-text{min-height:360px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:24px 22px 60px}',
    /* LE DUE PORTE AFFIANCATE (0.9.187): la pagina e' una griglia a due colonne; tutti i blocchi
       prendono la riga intera, Chiama e Sveglia mezza, come due widget della schermata Home */
    '#tab-rotta .nv-page{display:grid;grid-template-columns:1fr 1fr;column-gap:12px;row-gap:20px}',
    '#tab-rotta .nv-page > *{grid-column:1 / -1;min-width:0}',
    '#tab-rotta .nv-page > #nvChiama,#tab-rotta .nv-page > #nvSveglia{grid-column:auto}',
    '#nvChiama .pt-mini,#nvSveglia .pt-mini{height:100%;min-height:104px;justify-content:center}',
    /* «futuro» cerchiato a mano in rosso, come nel titolo della sezione Prevedi il tuo futuro */
    '.nv-cover-h .fl-hl-svg path{stroke-width:.09em;animation:flDrawCircle 1.2s .9s ease-out forwards}',
    /* il pannello dell'arrivo previsto, sotto all'interruttore */
    '.nv-arr-card{position:relative;overflow:hidden;border-radius:28px;margin:0 0 16px;border:2px solid rgba(255,255,255,.08);background:#020926;box-shadow:0 14px 34px rgba(0,30,68,.22);transition:border-color .4s,box-shadow .4s}',
    '.nv-arr-card .nv-arr{position:relative;padding:18px 18px 22px}',
    '.nv-arr-card .nv-in{padding:0;color:#fff}',
    '.nv-arr-card .nv-in.fuori .nv-data b,.nv-arr-card .nv-in.fuori .nv-data span{color:#fff}',
    /* 0.9.326, Andrea: "quando c'e' il bordo rosso deve lampeggiare, come il pulsante bianco nello slideshow del mio sito": stessi tempi e stesse misure di quel bagliore, in rosso */
    '@keyframes nvGlowRosso{0%,100%{box-shadow:0 0 11px rgba(230,57,70,.45),0 0 22px rgba(230,57,70,.25),inset 0 0 10px rgba(230,57,70,.2)}50%{box-shadow:0 0 17px rgba(230,57,70,.75),0 0 35px rgba(230,57,70,.5),inset 0 0 18px rgba(230,57,70,.45)}}',
    '.nv-arr-card.fuori{border-color:#E63946;animation:nvGlowRosso 1.6s ease-in-out infinite}',
    '.nv-arr-card.fuori.ricalcolo,.nv-arr-card.ricalcolo{animation:nvArrPulse 1.1s ease-in-out infinite}',
    '@keyframes nvArrPulse{0%,100%{box-shadow:0 0 0 3px rgba(230,57,70,.22),0 0 18px rgba(230,57,70,.4)}50%{box-shadow:0 0 0 4px rgba(230,57,70,.4),0 0 34px rgba(230,57,70,.7)}}',
    '.nv-cover-in{display:flex;flex-direction:column;align-items:center;text-align:center;color:#fff}',
    '.nv-cover-aura{position:relative;width:150px;height:150px;margin:4px auto 2px;display:flex;align-items:center;justify-content:center}',
    '.nv-cover-aura i{position:absolute;inset:-6px;border-radius:50%;background:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(18px);opacity:.8;animation:spin 4s linear infinite}',
    '.nv-cover-aura img{position:relative;height:162px;width:auto;filter:drop-shadow(0 12px 24px rgba(0,0,0,.5));animation:nvFloat 4s ease-in-out infinite}',
    '.nv-cover-h{display:block;margin-top:8px;font:900 32px/1.08 var(--font-display);letter-spacing:.01em;text-transform:uppercase;color:#fff;text-shadow:0 4px 18px rgba(0,0,0,.45)}',
    '.nv-cover-p{margin:12px auto 0;max-width:32ch;text-align:center}',
    /* i pulsanti come quelli della copertina di Netflix: bianco con il play, grigio trasparente */
    '.nv-btn-play{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;max-width:330px;margin:20px auto 0;padding:13px 16px;border:0;border-radius:8px;background:#fff;color:#000;font:700 17px var(--font-body);cursor:pointer}',
    '.nv-btn-play.spento{background:rgba(255,255,255,.75)}.nv-btn-play svg{flex:none}',
    '.nv-btn-grigio{display:flex;align-items:center;justify-content:center;width:100%;max-width:330px;margin:10px auto 0;padding:13px 16px;border:0;border-radius:8px;background:rgba(255,255,255,.2);color:#fff;font:700 17px var(--font-body);cursor:pointer}',
    /* il testo sale dal basso, uno dopo l\'altro, a ogni volta che la copertina torna davanti */
    '#nvHero .bh-slide.on .nv-cover-in > *{animation:nvSale .75s cubic-bezier(.2,.8,.2,1) both}',
    '#nvHero .bh-slide.on .nv-cover-in > :nth-child(2){animation-delay:.12s}#nvHero .bh-slide.on .nv-cover-in > :nth-child(3){animation-delay:.24s}#nvHero .bh-slide.on .nv-cover-in > :nth-child(4){animation-delay:.38s}#nvHero .bh-slide.on .nv-cover-in > :nth-child(5){animation-delay:.52s}#nvHero .bh-slide.on .nv-cover-in > :nth-child(6){animation-delay:.62s}',
    '@keyframes nvSale{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:none}}',
    '#nvHero .nv-in{padding:0;color:#fff}',
    '#nvHero .nv-in.fuori .nv-data b,#nvHero .nv-in.fuori .nv-data span{color:#fff}',
    '.nv-prev{display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.nv-perc{display:block;margin-top:10px;font:900 72px/1 var(--font-display);letter-spacing:-.03em;color:#fff}.nv-perc i{font-style:normal;font-weight:300;font-size:40px;color:#BFE0FF}.nv-perc.bassa{color:#FF8A94}.nv-perc.vuota{color:rgba(255,255,255,.5)}',
    '.nv-prev .nv-genio{margin-top:18px}',
    '#nvPorte:empty,#nvFuturo:empty,#nvChiama:empty,#nvSveglia:empty,#nvArrBlock:empty{display:none}','#nvChiama .pt-porte,#nvSveglia .pt-porte{margin:0}','#nvHero{margin-bottom:0}','#nvFuturo #scLife:empty{display:none}','#nvFuturo:has(> #scLife:empty){display:none}','#nvPorte .pt-porte{margin:0}',
    '.nv-pill{background:#1B9E6A;color:#fff;border-radius:999px;padding:5px 14px;font:600 13px var(--font-body)}.nv-pill.rossa{background:#E63946}.nv-pill.grigia{background:rgba(255,255,255,.2)}',
    '.nv-prob{font:500 13px var(--font-body);color:rgba(255,255,255,.85)}',
    '.nv-perc-rotta{margin:10px 0 0;text-align:center;font:500 12.5px var(--font-body);color:rgba(255,255,255,.8)}.nv-perc-rotta b{font:800 14px var(--font-display);color:#fff}',
    '.nv-rotta{width:100%;display:flex;align-items:center;gap:8px;margin-top:20px;font:500 11px var(--font-body);color:rgba(255,255,255,.7)}',
    '.nv-linea{flex:1;height:2px;background:rgba(255,255,255,.22);position:relative;border-radius:1px}.nv-linea i{position:absolute;left:0;top:0;bottom:0;transition:width .8s}',
    '.nv-linea em{position:absolute;top:50%;width:24px;height:24px;display:block;color:#fff;transform:translate(-50%,-50%) rotate(90deg);transition:left 1.4s cubic-bezier(.45,0,.2,1),transform .3s ease}.nv-linea em.indietro{transform:translate(-50%,-50%) rotate(-90deg)}.nv-linea i{transition:width 1.4s cubic-bezier(.45,0,.2,1)!important}',
    '.nv-linea em svg{display:block;width:24px;height:24px}',
    '.nv-genio{width:100%;display:flex;align-items:flex-end;gap:8px;margin-top:16px}.nv-genio img{height:92px;flex:none;animation:nvFloat 4s ease-in-out infinite}',
    '@keyframes nvFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}',
    '.nv-fumetto{flex:1;background:rgba(255,255,255,.14);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.18);border-radius:16px 16px 16px 4px;padding:12px 14px;font:500 13px/1.45 var(--font-body);text-align:left;margin-bottom:10px}',
    '.nv-prop{background:var(--card,#fff);border:2px solid #0075E3;border-radius:24px;padding:20px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;box-shadow:0 10px 30px rgba(0,117,227,.18);animation:nvUp .45s both}body.dark .nv-prop{background:#12203A}',
    '@keyframes nvUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}',
    '.nv-prop small{font:600 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}.nv-prop b{font:800 20px/1.25 var(--font-display);color:var(--navy)}body.dark .nv-prop b{color:#fff}',
    '.nv-prop p{margin:0;font:500 14px/1.5 var(--font-body);color:var(--muted);max-width:32ch}.nv-prop .am-cta{margin-top:8px}',
    '.nv-mossa{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:20px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:4px}body.dark .nv-mossa{background:#12203A;border-color:#22345A}',
    '.nv-tappa-ico{vertical-align:-3px;margin-right:5px}.nv-mossa small{font:600 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--faint)}.nv-mossa b{margin-top:2px;font:800 20px/1.25 var(--font-display);color:var(--navy)}body.dark .nv-mossa b{color:#fff}',
    '.nv-mossa span{font:500 13px var(--font-body);color:var(--muted)}.nv-mossa .am-cta{margin-top:12px;padding:15px 20px}',
    '.nv-mossa-btns{display:flex;gap:24px;margin-top:4px}.nv-mossa-btns button{background:none;border:0;color:#0075E3;font:600 13px var(--font-body);padding:8px;cursor:pointer}.nv-mossa-btns button.grigio{color:var(--faint)}',
    '.nv-widgets{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.nv-w{background:var(--card,#fff);border:1px solid var(--line);border-radius:20px;padding:16px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:4px;cursor:pointer}body.dark .nv-w{background:#12203A;border-color:#22345A}',
    '.nv-w span{font-size:22px;line-height:1}.nv-w small{font:500 12px var(--font-body);color:var(--muted)}.nv-w b{font:800 18px/1.2 var(--font-display);color:var(--navy)}body.dark .nv-w b{color:#fff}.nv-w em{font:500 11px var(--font-body);font-style:normal;color:var(--faint)}',
    /* IL PANNELLO A SCHEDE (0.9.304): il contenitore, la riga delle linguette e il titolo sono quelli di partita-stats.js
       (.pst, .pst-kick, .pst-tabs, .pst-tab); qui solo cio' che sta dentro. Scuro in tutti e due i temi, testo bianco. */
    '#tab-rotta #dreamSw{display:none}',
    '#nvTop:empty{display:none}',
    '.nvp-tab{display:inline-flex;align-items:center;gap:6px}',
    /* 0.9.307: le linguette come il tema Focal (tabs-nav): quelle non scelte a opacita' .7, la barretta da 2px che scorre
       sotto alla scelta (larghezza in .2 s, posizione in .4 s), al posto della lineetta fissa di .pst-tab.on::after */
    '@property --nvp-s{syntax:"<number>";inherits:false;initial-value:0}',
    '@property --nvp-t{syntax:"<percentage>";inherits:false;initial-value:0%}',
    '.nvp-tabs-in{flex:none;position:relative;display:flex;gap:2px;width:max-content;margin:0 auto}',
    '.nvp .nvp-tab{color:#fff;opacity:.7;transition:opacity .25s ease-in-out}.nvp .nvp-tab.on{opacity:1}.nvp .nvp-tab.on::after{display:none}',
    '.nvp-pos{position:absolute;left:0;bottom:0;width:100%;height:2px;background:#0075E3;transform-origin:left;transform:scaleX(var(--nvp-s)) translateX(var(--nvp-t));opacity:0;pointer-events:none}',
    '.nvp-pos.pronta{opacity:1;transition:--nvp-s .2s ease-in-out,--nvp-t .4s ease-in-out}',
    '@media (prefers-reduced-motion:reduce){.nvp-pos.pronta{transition:none}}',
    /* 0.9.318, regola di Andrea: l'emoji nel pallino bianco solo sulla scheda attiva, le altre solo il testo */
    '.nvp-tab:not(.on) .nvp-em{display:none}',
    '.nvp-em{flex:none;width:22px;height:22px;border-radius:11px;background:#fff;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:13px;line-height:1;letter-spacing:0}',
    '.nvp-dot{flex:none;width:8px;height:8px;border-radius:4px;background:#E63946;box-shadow:0 0 0 2px rgba(230,57,70,.3);align-self:flex-start;margin:-2px 0 0 -2px}',
    '.nvp-corpo{padding:4px 20px 0}',
    '.nvp-pane[hidden]{display:none}',
    '.nvp-in{display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.nvp-ico{flex:none;width:58px;height:58px;border-radius:29px;background:#fff;display:flex;align-items:center;justify-content:center;font-size:28px;line-height:1;box-shadow:0 8px 22px rgba(0,0,0,.28)}',
    '.nvp-h{display:block;margin-top:16px;font:800 23px/1.25 var(--font-display);color:#fff;overflow-wrap:anywhere}',
    '.nvp-p{margin:10px 0 0;max-width:32ch;font:500 14.5px/1.5 var(--font-body);color:rgba(255,255,255,.78)}',
    '.nvp-p b{color:#fff}.nvp-p0{margin-top:4px}',
    '.nvp-cta{margin-top:22px;width:100%;min-height:52px;border:0;border-radius:26px;background:#0075E3;color:#fff;font:800 16px var(--font-body);display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.35);padding:0 20px}',
    '.nvp-cta svg{flex:none}',
    '.nvp-link{margin-top:8px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);padding:8px 12px;cursor:pointer}',
    '.nvp-map{display:block;width:100%;box-sizing:border-box;border:1px solid rgba(140,198,255,.22);border-radius:20px;background:rgba(255,255,255,.05);padding:8px 16px 12px;cursor:pointer;color:#fff;font:inherit}',
    '.nvp-map svg{display:block;width:100%;height:auto}',
    /* 0.9.353, Andrea: "metti Tocca per aprire la cartina con il rosso di Prossima tappa, e Prossima tappa con l'azzurrino di Tocca
       per aprire la cartina": i due colori si scambiano */
    '.nvp-map > span{display:block;font:700 12px var(--font-body);color:#FF8A94}',
    '.nvp-eti{display:block;margin-top:24px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.nvp-h0{margin-top:8px}',
    '.nvp-rs-k{margin:0 0 10px!important}.nvp-rit.nvp-id-rit{margin:4px 0 34px}.nvp-rs-par{padding:16px 10px 6px!important}.nvp-rs-par .nvp-par{margin:0}',
    '.nvp-rit{margin:28px 0 8px;text-align:center}.nvp-rit-k{display:block;margin:0;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.nvp-rit-k2{margin-top:24px}',
    '.nvp-rit-t{display:block;margin-top:10px;font:800 22px/1.25 var(--font-display);color:#fff}.nvp-rit-s{margin:6px auto 0;max-width:32ch;font:500 14.5px/1.45 var(--font-body);color:rgba(255,255,255,.78)}',
    '.nvp-rit-svg{display:block;width:100%;height:auto;margin-top:18px}',
    '.nvp-rs-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;margin-top:18px}.nvp-rs-car::-webkit-scrollbar{display:none}.nvp-rs{flex:0 0 100%;box-sizing:border-box;scroll-snap-align:center;padding:16px 12px;border-radius:18px;background:rgba(255,255,255,.07);text-align:center}.nvp-rs-t{margin:0;font:700 14px var(--font-body);color:#D6E8FF}.nvp-rs-t span{margin-right:6px}.nvp-rs-n{display:flex;align-items:center;justify-content:center;gap:18px;margin-top:12px}.nvp-rs-n > div{flex:1}.nvp-rs-n b{display:block;font:900 32px/1 var(--font-display);color:#fff}.nvp-rs-n small{display:block;margin-top:6px;font:600 12px var(--font-body);color:#BFD3EC}.nvp-rs-n i{width:1px;height:42px;background:rgba(255,255,255,.2)}.nvp-rs-dots{display:flex;justify-content:center;gap:7px;margin-top:12px}.nvp-rs-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.28)}.nvp-rs-dots i.on{background:#fff}',
    '.nvp-rit-ns{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:18px}.nvp-rit-n{display:flex;flex-direction:column;align-items:center;gap:10px;padding:16px 4px 14px;border-radius:16px;background:rgba(255,255,255,.06)}.nvp-rit-n span{font-size:20px;line-height:1}.nvp-rit-n b{font:900 22px/1 var(--font-display);color:#fff}.nvp-rit-n small{font:600 11.5px/1.3 var(--font-body);color:rgba(255,255,255,.72)}',
    '.nvp-rit-c{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}.nvp-rit-c li{display:flex;flex-direction:column;align-items:center;gap:2px;padding:12px;border-radius:16px;background:rgba(255,255,255,.06)}.nvp-rit-c b{font:800 15px var(--font-body)}.nvp-rit-c li.su b{color:#8CC6FF}.nvp-rit-c li.giu b{color:#FF8A92}.nvp-rit-c span{font:500 13.5px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.nvp-i{flex:none;box-sizing:border-box;min-width:22px;display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;margin-left:8px;padding:0;vertical-align:3px;border:1.5px solid rgba(188,224,255,.7);border-radius:50%;background:none;color:#BCE0FF;cursor:pointer}',
    '.nvp-fg h3{margin:10px 42px 18px}.nvp-rit-f{margin:0}.nvp-rit-f li{background:#E9F4FF;gap:6px;padding:16px}.nvp-rit-f b{font-size:19px}.nvp-rit-f li.su b{color:#0075E3}.nvp-rit-f li.giu b{color:#E63946}.nvp-rit-f span{color:#001E44;font-size:14.5px}',
    'body.dark .nvp-rit-f li{background:#14234A}body.dark .nvp-rit-f li.su b{color:#8CC6FF}body.dark .nvp-rit-f li.giu b{color:#FF8A92}body.dark .nvp-rit-f span{color:#fff}',
    /* 0.9.318: lo stemma del nuovo te toccava il bordo del pannello */
    '.nvp-par .pa-tab{gap:6px;margin-top:18px}.nvp-par .pa-score{font-size:44px}.nvp-par .pa-score i{margin:0 5px}.nvp-par .pa-av{width:52px;height:52px;border-radius:26px;font-size:26px}.nvp-par .pa-av.neo{box-shadow:0 0 0 3px rgba(63,159,244,.35)}.nvp-par .pa-av img.sl-crest{width:52px !important;height:52px !important}',
    '#nvpLife .life-t{color:#FF9AA2}',
    '.nvp-par{display:block;width:100%;box-sizing:border-box;margin:4px 0 36px;padding:0;border:0;background:none;color:#fff;font:inherit;text-align:center;cursor:pointer}.nvp-par > p{margin:14px 0 0;font:500 14px var(--font-body);color:rgba(255,255,255,.78)}',
    '.nvp-num{display:block;margin-top:20px;font:900 44px/1 var(--font-display);letter-spacing:-.02em;color:#fff;font-variant-numeric:tabular-nums}.nvp-num i{font-style:normal;font-weight:300;font-size:26px;color:#BCE0FF;margin-left:2px}',
    '.nvp-bar{width:100%;height:8px;margin-top:14px;border-radius:4px;background:rgba(255,255,255,.1);overflow:hidden}.nvp-bar i{display:block;height:100%;min-width:6px;border-radius:4px;background:#3F9FF4}',
    /* Sogno: la card dell'arrivo previsto, con la sua foto, dentro al pannello */
    '.nvp .nv-arr-card{margin:0;border-radius:22px}',
    '.nvp .nv-data b,.nvp .nv-data span{font-size:42px}',
    '.nvp .gc-feed{margin-top:12px}',
    /* La tua storia: la card dell'episodio senza il suo bordo bianco (episodi.js, epiCardHtml({ pannello: true })) */
    '.nvp .epi-card,body.dark .nvp .epi-card{background:none;border:0;box-shadow:none;padding:0;gap:14px}',
    '.nvp .epi-hook,body.dark .nvp .epi-hook{color:#E8F1FF}',
    '.nvp .epi-tutti,body.dark .nvp .epi-tutti{color:#8CC6FF}',
    '.nvp .epi-card .epi-cta{margin-top:4px}',
    /* Identita': chi rischi di diventare (scores.js) senza la sua cornice, e quanto ti conosce il Genio */
    '#nvpLife .life-wrap{margin:0}',
    '#nvpLife .glw,#nvpLife .life-wrap::before{display:none}',
    '#nvpLife .life,body.dark #nvpLife .life{background:transparent !important;padding:2px 0 0}',
    '#nvpLife .life-who{width:84px;height:84px;margin:16px auto 0;border-radius:42px;background:#fff;display:flex;align-items:center;justify-content:center;font-size:50px;filter:none;box-shadow:0 8px 22px rgba(0,0,0,.28)}',
    '#nvpLife:has(> #scLife:empty){display:none}',
    '#nvpConosce{margin-top:22px;padding-top:18px;border-top:1px solid rgba(255,255,255,.1)}',
    /* 0.9.348: le slide adottate e la slide unica delle serie */
    /* 0.9.349, Andrea: "la slide dell'arrivo viene tagliata a destra". LA CAUSA: una slide e' un elemento flex, e un elemento flex non diventa
       mai piu' stretto del suo contenuto (min-width:auto). Dentro la card c'erano righe che non vanno a capo: la slide si allargava oltre il
       carosello e il carosello ne tagliava il bordo destro. Ora ogni slide sta nel carosello (min-width:0) e la card si stringe lei */
    '.nvp-rs{min-width:0}.nvp-rs-arr .nvp-arr-box{min-width:0}.nvp-rs-arr #nvArrCard{width:100%;max-width:100%;box-sizing:border-box;min-width:0}.nvp-rs-arr #nvArrCard *{max-width:100%}.nvp-rs-arr .nv-data b,.nvp-rs-arr .nv-data span{font-size:34px!important}.nvp-rs-arr .nvp-rit-link{margin:16px auto 4px}',
    '.prc-ritmo .prc-t{margin:6px 46px 0;line-height:1.3}.prc-ritmo .prc-p{margin-top:14px}',
    '.nvp-rs-arr{padding:0!important;background:none!important}.nvp-rs-arr > #nvArrCard{margin:0!important}.nvp-rs-life{padding:16px 10px!important}.nvp-rs-life #scLife{margin:0!important}',
    '.nvp-su{padding:22px 16px!important}.nvp-su-top{display:flex;flex-direction:column;align-items:center;gap:6px;margin:14px 0 6px;text-align:center}.nvp-su-top > span{font-size:34px;line-height:1}.nvp-su-top b{display:block;font:900 52px/1 var(--font-display);color:#fff}.nvp-su-top small{display:block;margin-top:4px;font:700 14px var(--font-body);color:#C8EFFD}',
    /* 0.9.349, Andrea: "il glow di Se continui cosi' e' tagliato, e nella slide delle serie si vede il glow della slide prima". Il bagliore ora
       sta tutto dentro la sua slide (spazio intorno piu' largo del bagliore) e la slide non lascia uscire niente verso le vicine */
    /* 0.9.350, Andrea: "il glow si taglia ancora ai lati, e Se continui cosi' e' troppo stretto e troppo lontano dalle schede". Il carosello
       dell'Identita' arriva fino al bordo del pannello e ogni slide ha 20px di spazio vuoto ai lati: il bagliore ci sta dentro, la card resta larga */
    '#nvpPartita .nvp-rs-car{margin-left:-20px;margin-right:-20px}#nvpPartita .nvp-rs-car > .nvp-rs{padding-left:20px!important;padding-right:20px!important;background:none!important;border-radius:0!important}',
    /* 0.9.353, Andrea: "il glow di Stai diventando e' ancora tagliato sopra". La slide aveva 6px sopra la card e il bagliore ne chiede
       circa 20: si taglia sul bordo della slide (overflow:hidden). Adesso la slide ha 24px sopra e il carosello sale di 18px sotto le
       schede (che restano sopra e toccabili): la card sta dove stava, il bagliore ha il suo spazio */
    '#nvpPartita{margin-top:-18px}#nvpTabs{position:relative;z-index:3}',
    '#nvpPartita .nvp-rs-car > .nvp-rs-life{padding-top:24px!important;padding-bottom:24px!important}#nvpPartita .nvp-su{padding:22px 16px;border-radius:18px;background:rgba(255,255,255,.07);text-align:center}',
    '.nvp-su-top > .nvp-su-fuoco,.nvp-su-fuoco{position:relative;display:inline-block;font-size:92px;line-height:1;filter:drop-shadow(0 8px 16px rgba(230,120,0,.35))}.nvp-su-fuoco b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding-top:26px;font:900 38px/1 var(--font-display);color:#5A2A00;text-shadow:0 1px 0 rgba(255,225,170,.85),0 -1px 0 rgba(255,225,170,.6),1px 0 0 rgba(255,225,170,.6),-1px 0 0 rgba(255,225,170,.6)}',
    '.nvp-rs-life{padding:30px 26px!important;overflow:hidden;background:none!important}.nvp-rs-life .life-wrap::before{inset:-5px;filter:blur(9px)}.nvp-rs-life .life{padding:26px 16px 22px!important}.nvp-rs-life .life-big{font-size:clamp(25px,7.6vw,32px)!important;line-height:1.15;overflow-wrap:anywhere}',
    '.nvp-rs-par{background:none!important;padding:0!important}.nvp-par-box{padding:18px 10px 8px;border-radius:18px;background:rgba(255,255,255,.07)}.nvp-par-box .nvp-par{margin:0!important}.nvp-riep-box #pstBoxMini{margin-top:16px}.nvp-rs-par,.nvp-su{overflow:hidden}body.dark .nvp-riep-box .pst-mini{box-shadow:none}',
    '.nvp-su-mx{display:block;margin:0 0 14px;font:600 12.5px var(--font-body);color:rgba(200,239,253,.75)}.nvp-su-l{display:flex;flex-direction:column;gap:8px;text-align:left}.nvp-su-r{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.07)}.nvp-su-r span{font-size:18px}.nvp-su-r b{flex:1;font:700 14px var(--font-body);color:#fff}.nvp-su-r em{font:800 14px var(--font-body);font-style:normal;color:#8CC6FF}',
    '.nvp-riep{margin-top:14px;padding:12px;border-radius:16px;background:rgba(255,255,255,.06);text-align:left}.nvp-riep .pst-corpo{color:#fff}.nvp-riep-piu{display:block;width:100%;margin-top:10px;padding:11px;border-radius:99px;border:1.5px dashed rgba(140,198,255,.6);background:none;color:#8CC6FF;font:800 14px var(--font-body);cursor:pointer}',
    '#nvpLife:has(> #scLife:empty) + #nvpConosce{margin-top:0;padding-top:0;border-top:0}',
    '.nvp .epi-conosce b,body.dark .nvp .epi-conosce b{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* 0.9.259, Andrea: «Inizia» porta alla tappa in corso della Roadmap, per chi ha scelto l'autostrada
   (effetto farfalla: scelta 'rotta', o la vista Roadmap in uso). Per chi pianifica da se', parte la sessione. */
function nvMossaVai(){
  let rotta = false;
  try{ const l = (typeof faLista === 'function') ? faLista() : []; const u = l[l.length - 1]; rotta = u ? u.scelta === 'rotta' : ((typeof mppVistaCur === 'function') && mppVistaCur() === 'rotta'); }catch(_){ }
  if (!rotta){ if (typeof stGoFocus === 'function') stGoFocus(); else ffOpen(); return; }
  try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('rotta'); }catch(_){ }
  setTimeout(function(){
    try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n && n.scrollIntoView) n.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
  }, 450);
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.nvp-rs-car{align-items:flex-start;transition:height .3s ease}.nvp-rs{display:flex;flex-direction:column;justify-content:center}.nvp-rs-g .nvp-rit-t{display:block}.nvp-rs-g .nvp-rit-s{margin-bottom:6px}';
  document.head.appendChild(st);
})();

(function(){ const st = document.createElement('style'); st.textContent = '.nvp-rs{justify-content:flex-start!important}.nvp-rs-car{overscroll-behavior-x:contain;overflow-y:hidden!important;touch-action:pan-x pan-y}'; document.head.appendChild(st); })();
