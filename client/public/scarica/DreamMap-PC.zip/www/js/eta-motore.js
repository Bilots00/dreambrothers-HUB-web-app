/* ===========================================================================================
   IL NAVIGATORE — il motore

   COSA FA. Stima QUANDO arrivi alla destinazione della Roadmap e la ricalcola a ogni cosa che
   fai, come la foto che sbiadisce in Ritorno al futuro. Non e' una profezia: e' aritmetica su
   tre numeri misurati, e ogni spostamento della data si puo' leggere nei numeri che l'hanno
   prodotto.

   I TRE NUMERI.
     · R, la strada che resta, in ore. La strada la misura il Genio in mesi (a un ritmo di
       riferimento); ogni cosa chiusa la accorcia del suo credito. La parte scritta come task
       vale le sue stime, corrette dal fattore di stima (le stime sono quasi sempre corte).
     · il passo: quante ore di strada fai in un giorno, rispetto a quante ne avevi pianificate.
       Non un numero solo — la distribuzione degli ultimi 56 giorni veri, pesata sul recente —
       perche' due persone con la stessa media e regolarita' diverse arrivano in date diverse
       e con incertezze diverse.
     · Q, la qualita' del lavoro: piccole correzioni, mai oltre il dieci per cento, ognuna con
       un nome.

   IL CAMMINO. Duemila copie di te partono da oggi e camminano un giorno alla volta: ogni
   giorno pianificato fanno le ore pianificate per un passo pescato dai tuoi giorni veri.
   Quando la strada finisce, segnano l'ora. Le duemila date ordinate danno il centro (P50: la
   data sulla carta) e l'intervallo (P10–P90: nove volte su dieci).

   LO STESSO DADO. Ogni copia usa numeri casuali che dipendono solo dal seme del viaggio, dal
   numero della copia e dal giorno di calendario: due ricalcoli con gli stessi fatti danno la
   stessa identica data, e un ricalcolo dopo una task chiusa si muove SOLO per la task. Senza
   questo, ogni ricalcolo ballerebbe di qualche ora per puro caso e nessun bollino sarebbe
   credibile.

   IL VENTO. I fattori esterni non sono mai penalita': allargano l'incertezza. Quello che
   sposta la data e' solo quello che controlli.

   Questo file e' puro: nessun localStorage, nessun DOM, nessuna data di sistema. Si prova da
   Node (tools/test-eta.js).
   =========================================================================================== */

const ETA_GIORNO_MS = 86400000;
const ETA_ORA_MS = 3600000;

/* ---------------------------------------------------------------------------------------
   IL DADO — un numero fra 0 e 1 che dipende SOLO da (seme, copia, giorno)
   --------------------------------------------------------------------------------------- */
function etaHash(seme, copia, giorno){
  let h = (seme | 0) ^ Math.imul(copia | 0, 0x9E3779B1) ^ Math.imul(giorno | 0, 0x85EBCA77);
  h = Math.imul(h ^ (h >>> 15), 0x2C1B3C6D);
  h = Math.imul(h ^ (h >>> 12), 0x297A2D39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
}

function etaClamp(x, a, b){ return Math.max(a, Math.min(b, x)); }
function etaMediana(v){
  if (!v.length) return 0;
  const s = v.slice().sort(function(a, b){ return a - b; });
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
/** Il percentile p (0…1) di una lista gia' ordinata. */
function etaPercentile(ordinati, p){
  if (!ordinati.length) return NaN;
  const i = Math.min(ordinati.length - 1, Math.max(0, Math.floor(p * (ordinati.length - 1))));
  return ordinati[i];
}

/* ---------------------------------------------------------------------------------------
   LA STRADA CHE RESTA
   --------------------------------------------------------------------------------------- */
/**
 * Il fattore di stima: ore reali / ore stimate, mediana sulle ultime task chiuse con del
 * tempo collegato. Sotto le cinque task misurate parlano i voti dopo la spunta; senza
 * nemmeno quelli, il default.
 */
function etaFattoreStima(misure, voti, cfg){
  const c = cfg.fattoreStima;
  const m = (misure || []).filter(function(x){ return x && x.reale > 0 && x.stimato > 0; }).slice(-c.finestraTask);
  if (m.length >= c.minTask){
    return { f: etaClamp(etaMediana(m.map(function(x){ return x.reale / x.stimato; })), c.min, c.max), n: m.length, fonte: 'misurato' };
  }
  const v = (voti || []).map(function(x){ return c.voti[x]; }).filter(function(x){ return x > 0; });
  if (v.length) return { f: etaClamp(etaMediana(v), c.min, c.max), n: v.length, fonte: 'voti' };
  return { f: c.default, n: 0, fonte: 'default' };
}

/** La scoperta: crescita media, settimana su settimana, delle ore pianificate scritte. */
function etaScoperta(oreSettimane, cfg){
  const c = cfg.scoperta;
  const w = (oreSettimane || []).slice(-c.settimane);
  const cresc = [];
  for (let i = 1; i < w.length; i++) if (w[i - 1] > 0) cresc.push(w[i] / w[i - 1] - 1);
  if (cresc.length < c.settimaneMin - 1) return { s: c.default, n: cresc.length, fonte: 'default' };
  return { s: etaClamp(etaMediana(cresc), c.min, c.max), n: cresc.length, fonte: 'misurato' };
}

/**
 * R e la percentuale del percorso.
 *   task:    [{ stimaMin, fatta, provvisoria }]  le task scritte (aperte e chiuse)
 *   W:       la strada del Genio in ore (0 se il Genio non ha letto)
 *   crediti: le ore di strada gia' fatte (sessioni, computer, task chiuse)
 * La strada e' la piu' lunga fra quella scritta (task aperte × fattore) e quella del Genio
 * meno il fatto: quello che non hai ancora scritto esiste lo stesso.
 */
function etaLavoro(inp){
  const cfg = inp.cfg;
  const f = inp.f, s = inp.s;
  let aperteOre = 0, aperteN = 0, provvisorie = 0;
  (inp.task || []).forEach(function(t){
    if (!t || t.fatta) return;
    aperteN++;
    if (t.provvisoria) provvisorie++;
    aperteOre += (t.stimaMin || 0) / 60;
  });
  const Rt = aperteOre * f * (1 + s);
  const Wp = (inp.W || 0) * (1 + s);
  const crediti = Math.max(0, inp.crediti || 0);
  const R = Math.max(0, Math.max(Rt, Wp - crediti));
  const pct = (crediti + R) > 0 ? crediti / (crediti + R) : 0;
  return { R: R, Rt: Rt, Wp: Wp, W: inp.W || 0, crediti: crediti, pct: pct, aperteN: aperteN, aperteOre: aperteOre, provvisorie: provvisorie, f: f, s: s, cfg: cfg };
}

/* ---------------------------------------------------------------------------------------
   IL PASSO
   --------------------------------------------------------------------------------------- */
/**
 * I tassi di esecuzione dai giorni chiusi.
 *   giorni: [{ eta (giorni fa, >= 1), pian (ore pianificate), credito (ore), pausa }]
 * I giorni in pausa non esistono; i giorni a zero pianificate con del credito sono un bonus
 * (la strada si accorcia, il passo non ne sa niente).
 */
function etaTassi(giorni, cfg){
  const out = [], bonus = [];
  (giorni || []).forEach(function(g){
    if (!g || g.pausa || !(g.eta >= 1)) return;
    if (!(g.pian > 0)){ if (g.credito > 0) bonus.push(g); return; }
    out.push({ eta: g.eta, rate: etaClamp((g.credito || 0) / g.pian, cfg.rate.min, cfg.rate.max) });
  });
  return { tassi: out, bonus: bonus.length, giorniDati: out.length };
}

/**
 * Il campione da cui pescare: i giorni veri pesati sul recente, piu' il prior della
 * calibrazione che si spegne con i giorni. La varianza allarga o stringe attorno alla media.
 */
function etaPool(tassi, cfg, varianza){
  const c = cfg.calibrazione;
  const valori = [], pesi = [];
  (tassi || []).forEach(function(t){
    valori.push(t.rate);
    pesi.push(Math.pow(0.5, Math.max(0, t.eta - 1) / cfg.rate.mezzaVita));
  });
  const n = valori.length;
  const pesoPrior = c.priorPeso * Math.max(0, 1 - n / c.giorni);
  if (pesoPrior > 0) c.priorValori.forEach(function(v){ valori.push(v); pesi.push(pesoPrior / c.priorValori.length); });
  const tot = pesi.reduce(function(a, b){ return a + b; }, 0) || 1;
  let media = 0;
  for (let i = 0; i < valori.length; i++) media += valori[i] * pesi[i] / tot;
  const v = (varianza === undefined || varianza === null) ? cfg.varianza.default : varianza;
  const finali = valori.map(function(x){ return etaClamp(media + (x - media) * v, cfg.rate.min, cfg.rate.max); });
  let sd = 0;
  for (let i = 0; i < finali.length; i++) sd += pesi[i] / tot * (finali[i] - media) * (finali[i] - media);
  sd = Math.sqrt(sd);
  /* la tabella: N caselle riempite in proporzione ai pesi, cosi' pescare costa un indice */
  const N = cfg.simulazione.tabella;
  const tabella = new Array(N);
  let j = 0, cum = pesi[0] / tot;
  for (let i = 0; i < N; i++){
    const u = (i + 0.5) / N;
    while (u > cum && j < finali.length - 1){ j++; cum += pesi[j] / tot; }
    tabella[i] = j;
  }
  return { valori: finali, pesi: pesi, tabella: tabella, media: media, sd: sd, n: n, calibrazione: n < c.giorni, giorniMancanti: Math.max(0, c.giorni - n) };
}

/** La qualita' Q, a voci: ognuna con il suo nome e il suo segno. */
function etaQ(seg, cfg){
  const c = cfg.Q, voci = [];
  seg = seg || {};
  if (typeof seg.sessioneMedia === 'number' && seg.sessioneMedia > 0){
    if (seg.sessioneMedia >= c.sessioneLunga) voci.push({ k: 'sessioni', delta: c.bonusLunga });
    else if (seg.sessioneMedia < c.sessioneCorta) voci.push({ k: 'sessioni', delta: -c.malusCorta });
  }
  if (typeof seg.quotaFinestra === 'number'){
    if (seg.quotaFinestra >= c.finestreQuota) voci.push({ k: 'finestre', delta: c.finestreBonus });
  }
  if (typeof seg.cambiOra === 'number'){
    if (seg.cambiOra >= c.cambiOra[1]) voci.push({ k: 'cambi', delta: -c.cambiMalus[1] });
    else if (seg.cambiOra >= c.cambiOra[0]) voci.push({ k: 'cambi', delta: -c.cambiMalus[0] });
  }
  if (typeof seg.passivo === 'number' && seg.passivo >= c.passivoQuota) voci.push({ k: 'passivo', delta: -c.passivoMalus });
  if (typeof seg.veicolo === 'number' && seg.veicolo < 0) voci.push({ k: 'veicolo', delta: Math.max(-c.veicoloMax, seg.veicolo) });
  const Q = etaClamp(1 + voci.reduce(function(a, v){ return a + v.delta; }, 0), c.min, c.max);
  return { Q: Q, voci: voci };
}

/**
 * Gli indicatori anticipatori: una regressione ridge di rate ~ riserva + cambi sui giorni
 * chiusi che li hanno. Sotto i 30 giorni i pesi sono zero e l'inclinazione e' 1.
 *   giorni: [{ rate, riserva, cambi }], ultimo: { riserva, cambi } (ieri)
 */
function etaTilt(giorni, ultimo, cfg){
  const c = cfg.indicatori;
  const d = (giorni || []).filter(function(g){ return g && typeof g.rate === 'number' && typeof g.riserva === 'number' && typeof g.cambi === 'number'; });
  if (d.length < c.giorniMin || !ultimo || typeof ultimo.riserva !== 'number') return { fattore: 1, n: d.length, pesi: null, giorni: c.giorniPrevisti };
  const mR = d.reduce(function(a, g){ return a + g.riserva; }, 0) / d.length;
  const mC = d.reduce(function(a, g){ return a + g.cambi; }, 0) / d.length;
  const mY = d.reduce(function(a, g){ return a + g.rate; }, 0) / d.length;
  const sR = Math.sqrt(d.reduce(function(a, g){ return a + (g.riserva - mR) * (g.riserva - mR); }, 0) / d.length) || 1;
  const sC = Math.sqrt(d.reduce(function(a, g){ return a + (g.cambi - mC) * (g.cambi - mC); }, 0) / d.length) || 1;
  /* due variabili standardizzate: la soluzione ridge in forma chiusa (2×2) */
  let a11 = c.lambda, a12 = 0, a22 = c.lambda, b1 = 0, b2 = 0;
  d.forEach(function(g){
    const x1 = (g.riserva - mR) / sR, x2 = (g.cambi - mC) / sC, y = g.rate - mY;
    a11 += x1 * x1; a12 += x1 * x2; a22 += x2 * x2; b1 += x1 * y; b2 += x2 * y;
  });
  const det = a11 * a22 - a12 * a12;
  if (!det) return { fattore: 1, n: d.length, pesi: null, giorni: c.giorniPrevisti };
  const w1 = (b1 * a22 - b2 * a12) / det, w2 = (a11 * b2 - a12 * b1) / det;
  const pred = mY + w1 * ((ultimo.riserva - mR) / sR) + w2 * (((ultimo.cambi || 0) - mC) / sC);
  const fattore = mY > 0 ? etaClamp(pred / mY, c.tiltMin, c.tiltMax) : 1;
  return { fattore: fattore, n: d.length, pesi: { riserva: w1, cambi: w2 }, giorni: c.giorniPrevisti, pred: pred, media: mY };
}

/* ---------------------------------------------------------------------------------------
   IL CAMMINO
   --------------------------------------------------------------------------------------- */
/**
 * La simulazione.
 *   R            ore di strada che restano
 *   oggi         mezzanotte di oggi (ms), adesso (ms)
 *   oreOggi      ore pianificate di oggi non ancora coperte dal credito di oggi
 *   piano        { oreSettimana, giorni: [7 quote, domenica…sabato] }
 *   pool         da etaPool
 *   Q, tilt      { fattore, giorni }
 *   seme         il seme del viaggio
 *   target       una data entro cui vorresti arrivare (0 = nessuna)
 *   giorniMs     [mezzanotte del giorno i] facoltativo (per l'ora legale); altrimenti oggi + i giorni
 */
function etaSimula(inp){
  const cfg = inp.cfg, sim = cfg.simulazione;
  const R = inp.R;
  const runs = inp.runs || sim.runs;
  const adesso = inp.adesso || inp.oggi;
  if (!(R > 0)) return { p10: adesso, p50: adesso, p90: adesso, arrivato: true, oltre: false, pTarget: inp.target ? 1 : 0, runs: 0, arrivati: 0 };
  const quote = inp.piano.giorni || [1, 1, 1, 1, 1, 1, 1];
  const tot = quote.reduce(function(a, b){ return a + (+b || 0); }, 0);
  if (!(inp.piano.oreSettimana > 0) || !tot) return { p10: Infinity, p50: Infinity, p90: Infinity, oltre: true, senzaPiano: true, pTarget: 0, runs: runs, arrivati: 0 };
  const pian = [];
  for (let d = 0; d < 7; d++) pian.push(inp.piano.oreSettimana * (+quote[d] || 0) / tot);
  const pool = inp.pool, tab = pool.tabella, TN = tab.length, val = pool.valori;
  const Q = inp.Q || 1;
  const tiltG = (inp.tilt && inp.tilt.giorni) || 0, tiltF = (inp.tilt && inp.tilt.fattore) || 1;
  const dow0 = new Date(inp.oggi).getDay();
  const idx0 = Math.round(inp.oggi / ETA_GIORNO_MS);
  const fda = cfg.finestraGiorno.da, fa = cfg.finestraGiorno.a;
  const arr = new Float64Array(runs); for (let r = 0; r < runs; r++) arr[r] = NaN;
  const cum = new Float64Array(runs);
  let left = runs, lavorati = 0;
  const bastano = Math.floor(0.9 * (runs - 1)) + 2;       // arrivati questi, il P90 e' deciso
  for (let i = 0; i < sim.maxGiorni && left > 0; i++){
    const h = i === 0 ? Math.max(0, inp.oreOggi || 0) : pian[(dow0 + i) % 7];
    if (!(h > 0)) continue;
    lavorati++;
    const mezzanotte = inp.giorniMs && inp.giorniMs[i] ? inp.giorniMs[i] : inp.oggi + i * ETA_GIORNO_MS;
    const tilt = i < tiltG ? tiltF : 1;
    const giorno = idx0 + i;
    for (let r = 0; r < runs; r++){
      if (arr[r] === arr[r]) continue;                    // gia' arrivato (NaN !== NaN)
      const u = etaHash(inp.seme | 0, r, giorno);
      const w = h * val[tab[(u * TN) | 0]] * Q * tilt;
      if (cum[r] + w >= R){
        const frac = w > 0 ? (R - cum[r]) / w : 1;
        arr[r] = mezzanotte + (fda + frac * (fa - fda)) * ETA_ORA_MS;
        left--;
      } else cum[r] += w;
    }
    if (runs - left >= bastano && i >= 7) break;         // il resto arriva dopo: basta cosi'
    /* la coda analitica: dopo tanti giorni ogni copia prosegue col proprio passo medio */
    if (i >= sim.codaGiorni && left > 0){
      const settimanaLav = pian.filter(function(x){ return x > 0; }).length || 7;
      for (let r = 0; r < runs; r++){
        if (arr[r] === arr[r]) continue;
        const ritmo = cum[r] / lavorati;                   // ore per giorno lavorato
        if (ritmo > 0){
          const giorniLav = (R - cum[r]) / ritmo;
          arr[r] = mezzanotte + giorniLav * (7 / settimanaLav) * ETA_GIORNO_MS;
        } else arr[r] = Infinity;
      }
      left = 0;
    }
  }
  const ordinati = [];
  let arrivati = 0;
  for (let r = 0; r < runs; r++){ const x = arr[r] === arr[r] ? arr[r] : Infinity; if (isFinite(x)) arrivati++; ordinati.push(x); }
  ordinati.sort(function(a, b){ return a - b; });
  const p10 = etaPercentile(ordinati, 0.1), p50 = etaPercentile(ordinati, 0.5), p90 = etaPercentile(ordinati, 0.9);
  let pTarget = 0;
  if (inp.target){ let k = 0; for (let r = 0; r < runs; r++) if (ordinati[r] <= inp.target) k++; pTarget = k / runs; }
  return { p10: p10, p50: p50, p90: p90, oltre: !isFinite(p50), pTarget: pTarget, runs: runs, arrivati: arrivati, giorniSimulati: lavorati };
}

/* ---------------------------------------------------------------------------------------
   LE PAROLE PER I NUMERI
   --------------------------------------------------------------------------------------- */
/** Lo scarto in parole: «3h 26min» sotto le 24 ore, «1g 6h» da 24 ore in su. Zero = ''. */
function etaDeltaTxt(ms, cfg, senzaSegno){
  const f = cfg.formato;
  const segno = ms < 0 ? '−' : '+';
  let min = Math.round(Math.abs(ms) / 60000);
  if (min < 1) return '';
  let txt;
  if (min < 1440){
    const h = Math.floor(min / 60), m = min % 60;
    txt = h ? (h + f.ore + (m ? ' ' + m + f.minuti : '')) : (m + f.minuti);
  } else {
    const g = Math.floor(min / 1440), h = Math.round((min % 1440) / 60);
    txt = h >= 24 ? (g + 1) + f.giorni : (g + f.giorni + (h ? ' ' + h + f.ore : ''));
  }
  return senzaSegno ? txt : segno + txt;
}
/** Il bollino: classe e testo (senza la coda «rispetto a ieri», che decide chi lo scrive). */
function etaBadge(deltaMs, cfg){
  const t = etaDeltaTxt(deltaMs, cfg);
  if (!t) return { cls: 'flat', txt: '', delta: 0 };
  return { cls: deltaMs < 0 ? 'down' : 'up', txt: (deltaMs < 0 ? '↘ ' : '↗ ') + t, delta: deltaMs };
}

/* ---------------------------------------------------------------------------------------
   LE LEVE, IL FANTASMA, L'AFFIDABILITA'
   --------------------------------------------------------------------------------------- */
/** La stessa simulazione con una modifica: ritorna il P50 e lo scarto. */
function etaControfattuale(inp, patch){
  const base = etaSimula(inp);
  const alt = etaSimula(Object.assign({}, inp, patch));
  return { base: base, alt: alt, delta: (isFinite(alt.p50) && isFinite(base.p50)) ? alt.p50 - base.p50 : NaN,
           delta10: (isFinite(alt.p10) && isFinite(base.p10)) ? alt.p10 - base.p10 : NaN,
           delta90: (isFinite(alt.p90) && isFinite(base.p90)) ? alt.p90 - base.p90 : NaN };
}
/** Il te disciplinato: il passo dei tuoi giorni migliori (P80), fisso. */
function etaFantasma(tassi, inp, cfg){
  const r = (tassi || []).map(function(t){ return t.rate; }).sort(function(a, b){ return a - b; });
  if (r.length < cfg.fantasma.minGiorni) return null;
  const p80 = etaPercentile(r, cfg.fantasma.percentile);
  const pool = { valori: [p80], tabella: [0], media: p80, sd: 0, n: r.length };
  const sim = etaSimula(Object.assign({}, inp, { pool: pool, runs: 1, tilt: null }));
  return { rate: p80, p50: sim.p50, oltre: sim.oltre };
}
/** Quante tappe sono cadute nell'intervallo, e come muovere la varianza. */
function etaAffidabilita(tappe, varianza, cfg){
  const c = cfg.varianza;
  const chiuse = (tappe || []).filter(function(t){ return t && t.chiusaIl && isFinite(t.p10) && isFinite(t.p90); });
  const dentro = chiuse.filter(function(t){ return t.chiusaIl >= t.p10 && t.chiusaIl <= t.p90; }).length;
  let nuova = varianza;
  if (chiuse.length >= c.minTappe){
    const q = dentro / chiuse.length;
    if (q < c.sogliaLarga) nuova = etaClamp(varianza * (1 + c.passo), c.min, c.max);
    else if (q > c.sogliaStretta) nuova = etaClamp(varianza * (1 - c.passo), c.min, c.max);
  }
  return { n: chiuse.length, dentro: dentro, quota: chiuse.length ? dentro / chiuse.length : null, varianza: nuova };
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { etaHash: etaHash, etaClamp: etaClamp, etaMediana: etaMediana, etaPercentile: etaPercentile,
    etaFattoreStima: etaFattoreStima, etaScoperta: etaScoperta, etaLavoro: etaLavoro, etaTassi: etaTassi, etaPool: etaPool,
    etaQ: etaQ, etaTilt: etaTilt, etaSimula: etaSimula, etaDeltaTxt: etaDeltaTxt, etaBadge: etaBadge,
    etaControfattuale: etaControfattuale, etaFantasma: etaFantasma, etaAffidabilita: etaAffidabilita };
}
