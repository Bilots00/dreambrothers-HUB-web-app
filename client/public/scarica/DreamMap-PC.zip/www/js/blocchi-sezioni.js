/* ===========================================================================================
   LE SEZIONI CHE DISTRAGGONO (0.9.242): un cancello solo, per la Modalità severa e per la
   stagione di spinta.

   Andrea, dal sistema di Davie Fogarty: durante il lavoro vero non si tollerano distrazioni,
   nemmeno quelle dentro a DreamMap. I giochi del Genio, le lezioni, le sfide sono cose belle,
   e proprio per questo sono il posto perfetto dove rimandare.

   flSezioneBloccata(k) dice se la sezione k e' spenta adesso:
     · Modalita' severa accesa E l'opzione di quella sezione accesa (fl_sev_sezioni), oppure
     · stagione di spinta nei 90 giorni (stagione.js) E la stagione la spegne.
   ECCEZIONE della stagione: il respiro e "Consigliato per te" restano aperti nei giorni in cui
   l'umore di oggi e' basso (soddisfazione o produttivita' a 2 o meno): con ansia o stress il
   respiro serve, e lo concede il tuo agente personale.

   Le chiavi: 'genio-giochi', 'academy', 'respiro', 'consigliati', 'sfide', 'lega'.
   'consigliati' lo applica dream-extra.js (Andrea). Qui si chiudono le porte di tutte le altre:
   le funzioni che aprono le sezioni vengono avvolte, cosi' ogni pulsante che le chiama trova il
   cancello, senza toccare i file che le disegnano.
   =========================================================================================== */
const BS_KEY = 'fl_sev_sezioni';
const BS_SEZIONI = [
  { k: 'genio-giochi', n: 'I giochi del Genio', s: 'La slide "Mettimi alla prova" e, nella scheda Identità, chi rischi di diventare: i giochi in cui il Genio indovina.' },
  { k: 'academy', n: 'Le lezioni dell’Academy', s: 'Le lezioni e gli esami dei moduli.' },
  { k: 'respiro', n: 'Gli esercizi di respiro', s: 'Il respiro guidato e i consigli del Genio sul respiro.' },
  { k: 'consigliati', n: 'Consigliato per te', s: 'La sezione dei consigli nella scheda Sogno.' },
  { k: 'sfide', n: 'Le sfide', s: 'Il carosello delle sfide nella scheda Sogno.' },
  { k: 'lega', n: 'Amici, sfide della settimana e Lega', s: 'Le classifiche e le sfide con gli amici.' }
];
/* le chiavi che la stagione spegne di serie */
const BS_STAGIONE_DEF = ['genio-giochi', 'academy', 'respiro', 'consigliati', 'sfide', 'lega'];

function bsLeggi(){ try{ const o = JSON.parse(localStorage.getItem(BS_KEY) || '{}'); return o && typeof o === 'object' ? o : {}; }catch(_){ return {}; } }
function bsScrivi(o){ try{ localStorage.setItem(BS_KEY, JSON.stringify(o || {})); }catch(_){ } }
function bsNome(k){ const d = BS_SEZIONI.filter(function(x){ return x.k === k; })[0]; return d ? d.n : k; }

/** La Modalità severa e' accesa adesso? (lo stato vero e' quello del motore, letto da severe.js) */
function bsSeveraAccesa(){
  try{ if (typeof sevState !== 'undefined' && sevState) return (sevState.level || 0) > 0; }catch(_){ }
  try{ return (+localStorage.getItem('fl_strict') || 0) > 0; }catch(_){ return false; }
}
/** L'umore di oggi e' basso: soddisfazione o produttivita' a 2 o meno (scala da 1 a 5). */
function bsUmoreBasso(){
  try{
    if (typeof umLeggi !== 'function') return false;
    const d = new Date();
    const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    /* 0.9.287: anche quando nel controllo dell'umore si dice di sentirsi in ansia o sotto pressione */
    try{ if (localStorage.getItem('fl_umore_ansia') === k) return true; }catch(_){ }
    const v = umLeggi(k);
    if (!v) return false;
    const s = +v.sodd || 0, p = +v.prod || 0;
    return (s > 0 && s <= 2) || (p > 0 && p <= 2);
  }catch(_){ return false; }
}
function bsStagione(){ try{ return (typeof flStagioneAttiva === 'function') ? flStagioneAttiva() : null; }catch(_){ return null; } }

/** Chi spegne la sezione k adesso: 'severa', 'stagione' o '' (aperta). */
function bsChi(k){
  if (bsSeveraAccesa() && bsLeggi()[k]) return 'severa';
  const st = bsStagione();
  if (st && st.fase === 'spinta'){
    const bl = st.blocchi || {};
    const spenta = bl[k] !== undefined ? !!bl[k] : BS_STAGIONE_DEF.indexOf(k) >= 0;
    if (spenta){
      if ((k === 'respiro' || k === 'consigliati') && bsUmoreBasso()) return '';
      return 'stagione';
    }
  }
  return '';
}
function flSezioneBloccata(k){ return !!bsChi(k); }
/** La frase che spiega perche' e' chiusa. */
function bsMotivo(k){
  const chi = bsChi(k);
  if (chi === 'severa') return bsNome(k) + ': spenta finché dura la Modalità severa.';
  if (chi === 'stagione'){
    const st = bsStagione();
    return bsNome(k) + ': spenta durante la stagione di spinta' + (st ? ', giorno ' + st.giorno + ' di ' + st.di : '') + '.'
      + ((k === 'respiro' || k === 'consigliati') ? ' Si riapre nei giorni in cui segni un umore basso.' : '');
  }
  return '';
}
function bsAvvisa(k){ try{ if (typeof toast === 'function') toast(bsMotivo(k)); }catch(_){ } try{ flVibra && flVibra(20); }catch(_){ } }

/* ---------------------------------------------------------------------------------------
   LE OPZIONI NELLA MODALITA' SEVERA ("Cosa proteggere"): una riga per sezione, bloccate
   mentre la severa e' accesa (si cambiano solo prima di attivarla).
   --------------------------------------------------------------------------------------- */
function bsSevOpzioniHtml(){
  const o = bsLeggi(), lock = bsSeveraAccesa();
  /* 0.9.293, Andrea: "le sezioni che distraggono dentro un toggle chiuso, con il titolo grande": un pannello che si
     apre, chiuso di serie; resta aperto se lo apri e tocchi un interruttore */
  const spente = BS_SEZIONI.filter(function(d){ return !!o[d.k]; }).length;
  return '<details class="bs-sev-det"' + (BS_SEV_APERTO ? ' open' : '') + ' ontoggle="BS_SEV_APERTO=this.open">'
    + '<summary><div><b>Le sezioni che distraggono</b><small>' + (spente ? spente + (spente === 1 ? ' spenta' : ' spente') : 'Nessuna spenta') + '</small></div>'
    + '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></summary>'
    + '<p class="bs-sev-nota">' + (lock ? 'La Modalità severa è accesa: queste scelte restano così finché non finisce.' : 'Con la Modalità severa accesa, le sezioni spente qui non si aprono.') + '</p>'
    + BS_SEZIONI.map(function(d){
      const on = !!o[d.k];
      return '<div class="sev-optcard' + (lock ? ' fixed' : '') + '"><div class="txt"><b>Spegni: ' + esc(d.n) + '</b><small>' + esc(d.s) + '</small></div>'
        + '<button class="switch' + (on ? ' on' : '') + '"' + (lock ? ' aria-disabled="true"' : '') + ' onclick="bsSevToggle(\'' + d.k + '\')" aria-label="Spegni ' + esc(d.n) + '"></button></div>';
    }).join('') + '</details>';
}
var BS_SEV_APERTO = false;
(function(){
  const st = document.createElement('style');
  st.textContent = '.bs-sev-det{margin:18px 0 0;padding:0 16px 4px;border-radius:20px;background:var(--card);border:1px solid var(--line)}'
    + '.bs-sev-det summary{list-style:none;display:flex;align-items:center;gap:12px;padding:16px 0;cursor:pointer}'
    + '.bs-sev-det summary::-webkit-details-marker{display:none}'
    + '.bs-sev-det summary > div{flex:1;min-width:0}'
    + '.bs-sev-det summary b{display:block;font:800 18px/1.25 var(--font-display);color:var(--navy)}'
    + '.bs-sev-det summary small{display:block;margin-top:3px;font:600 13px var(--font-body);color:var(--muted)}'
    + '.bs-sev-det summary svg{flex:none;color:var(--blue);transition:transform .2s}'
    + '.bs-sev-det[open] summary svg{transform:rotate(180deg)}'
    + '.bs-sev-nota{margin:0 0 10px;font:500 13px/1.45 var(--font-body);color:var(--muted)}'
    + '.bs-sev-det .sev-optcard{margin:0 0 10px}';
  document.head.appendChild(st);
})();
function bsSevToggle(k){
  if (bsSeveraAccesa()){ try{ toast('Si cambia quando la Modalità severa è spenta.'); }catch(_){ } return; }
  const o = bsLeggi(); o[k] = !o[k]; bsScrivi(o);
  try{ if (typeof sevRenderOptions === 'function') sevRenderOptions(); }catch(_){ }
  bsControlla(true);
}

/* ---------------------------------------------------------------------------------------
   LA SLIDE DEL GENIO (Dream, slide 2 "Mettimi alla prova"): spenta, sparisce dal carosello e
   il suo interruttore non si riaccende (blkhero.js chiede a bsSlideBloccata).
   --------------------------------------------------------------------------------------- */
function bsSlideBloccata(key, i){ return key === 'rotta' && i === 2 && flSezioneBloccata('genio-giochi'); }

/* ---------------------------------------------------------------------------------------
   I CANCELLI: le funzioni che aprono le sezioni, avvolte.
   --------------------------------------------------------------------------------------- */
function bsAvvolgi(nome, k, prima){
  try{
    const f = window[nome];
    if (typeof f !== 'function' || f.__bs) return;
    const w = function(){
      if (flSezioneBloccata(k)){
        if (prima) try{ prima.apply(this, arguments); }catch(_){ }
        bsAvvisa(k);
        return;
      }
      return f.apply(this, arguments);
    };
    w.__bs = true;
    window[nome] = w;
  }catch(_){ }
}
function bsInstalla(){
  bsAvvolgi('akApri', 'genio-giochi');
  ['academyOpen', 'acOpenModule', 'acOpenLesson'].forEach(function(n){ bsAvvolgi(n, 'academy'); });
  /* il respiro: chi lo chiama con `dopo` (l'Oracolo della tappa) si sente rispondere "non fatto" */
  bsAvvolgi('rsApri', 'respiro', function(o){ if (o && typeof o.dopo === 'function') setTimeout(function(){ try{ o.dopo(false); }catch(_){ } }, 0); });
  bsAvvolgi('rsConsiglioApri', 'respiro');
  bsAvvolgi('rstRespira', 'respiro');
  bsAvvolgi('sfdTutte', 'sfide');
  bsAvvolgi('rfApri', 'sfide');
  bsAvvolgi('frOpen', 'lega');
  /* il Genio di "Come sta la tua testa?" non propone il respiro quando e' spento */
  try{
    if (typeof rstConsigli === 'function' && !rstConsigli.__bs){
      const v = rstConsigli;
      const w = function(){
        const l = v.apply(this, arguments);
        if (!flSezioneBloccata('respiro')) return l;
        const r = (l || []).filter(function(x){ return String(x.via || '').indexOf('rstRespira') < 0; });
        if (!r.length) r.push({ ico: '⏱️', t: 'La regola dei cinque minuti', s: 'Cinque minuti di Full Focus sull’unica cosa, con il permesso di smettere dopo. La voglia arriva cominciando.', durata: '5 min', via: 'rstCinque()' });
        return r;
      };
      w.__bs = true; window.rstConsigli = w;
    }
  }catch(_){ }
}

/* Quando cambia cosa e' spento, si ridisegna quello che si vede. */
let BS_FIRMA = null;
function bsFirma(){ return BS_SEZIONI.map(function(d){ return d.k + ':' + (flSezioneBloccata(d.k) ? 1 : 0); }).join(','); }
function bsControlla(forza){
  const f = bsFirma();
  if (!forza && f === BS_FIRMA) return;
  const prima = BS_FIRMA; BS_FIRMA = f;
  if (prima === null && !forza && f.indexOf(':1') < 0) return;
  const cambiaGenio = !prima || prima.split(',')[0] !== f.split(',')[0];
  try{ if (cambiaGenio && typeof FL_HEROES !== 'undefined' && FL_HEROES.rotta && typeof flHeroRifai === 'function') flHeroRifai('rotta'); }catch(_){ }
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:blocchi', { detail: { firma: f } })); }catch(_){ }
}

if (typeof document !== 'undefined'){
  bsInstalla();
  document.addEventListener('DOMContentLoaded', function(){ bsInstalla(); });
  [1500, 4000].forEach(function(ms){ setTimeout(function(){ bsInstalla(); bsControlla(); }, ms); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(bsControlla, 900); });
  document.addEventListener('fl:tab', function(){ setTimeout(bsControlla, 200); });
  setInterval(bsControlla, 60000);
  (function(){
    const st = document.createElement('style');
    st.textContent = [
      '.bs-sev-h{margin:18px 4px 8px}.bs-sev-h b{display:block;font:800 15px/1.3 var(--font-body)}.bs-sev-h small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);opacity:.75}',
      '.fl-sl-row .bs-lock{font:600 12px/1.35 var(--font-body);color:#0075E3;max-width:150px;text-align:right}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { flSezioneBloccata: flSezioneBloccata, bsChi: bsChi, bsUmoreBasso: bsUmoreBasso, BS_SEZIONI: BS_SEZIONI };
}
