/* ===========================================================================================
   NEL CAVEAU DAL TESTO SELEZIONATO (0.9.253)

   Andrea: selezionando un testo deve essere possibile spostarlo direttamente nel caveau, e si
   sposta SOLO quella riga. Vale ovunque si scriva: il foglio di START e della Mappa, le note
   (la replica di Samsung Notes, dentro al suo iframe), il piano (la replica di Notion), i
   campi dell'app. Quando c'e' una selezione dentro a un campo o a un editor compare una pillola
   "Nel caveau" sopra al testo: toccandola, la riga intera che contiene la selezione finisce nel
   caveau (cvAggiungi, ulisse.js) e sparisce da dove stava.

   Riga intera, non solo le parole evidenziate: un'idea e' una riga, e tagliarla a meta'
   lascerebbe un moncone nel foglio. Se la selezione copre piu' righe, vanno tutte.
   - Campi di testo (textarea, input): si lavora sul valore, con l'evento input, cosi' chi
     salva da solo (le note sicure, il foglio) se ne accorge.
   - Editor contenteditable: si allarga la selezione ai bordi della riga e si cancella con
     execCommand, che manda gli eventi che gli editor (anche React) ascoltano.
   - Gli iframe della stessa origine (note, piano) si agganciano quando si caricano.
   =========================================================================================== */
const CS = { t: 0, doc: null, sel: null };
function csEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function csBtn(){
  let b = document.getElementById('csBtn');
  if (b) return b;
  b = document.createElement('button'); b.id = 'csBtn'; b.type = 'button'; b.className = 'cs-btn'; b.hidden = true;
  b.innerHTML = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg><span>Sposta nel caveau</span>';
  /* pointerdown senza default: la selezione e il cursore restano dove sono */
  b.addEventListener('pointerdown', function(e){ e.preventDefault(); e.stopPropagation(); });
  b.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); csVia(); });
  document.body.appendChild(b);
  return b;
}
function csNascondi(){ const b = document.getElementById('csBtn'); if (b && !b.hidden) b.hidden = true; CS.sel = null; }
/** La riga (o le righe) che contengono la selezione, con quello che serve per toglierle. */
function csSelezione(doc){
  const el = doc.activeElement;
  if (el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|url|email|tel)?$/.test(el.type || '')))){
    const a = el.selectionStart, b = el.selectionEnd;
    if (b == null || a == null || b <= a) return null;
    const v = el.value;
    const s = v.lastIndexOf('\n', a - 1) + 1;
    let e = v.indexOf('\n', b); if (e < 0) e = v.length;
    const testo = v.slice(s, e);
    if (!testo.trim()) return null;
    return { modo: 'campo', el: el, a: s, b: e, testo: testo, rect: el.getBoundingClientRect() };
  }
  const sel = doc.getSelection ? doc.getSelection() : null;
  if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const r = sel.getRangeAt(0);
  const n = r.commonAncestorContainer;
  const host = n.nodeType === 1 ? n : n.parentElement;
  const ed = host && host.closest && host.closest('[contenteditable=""],[contenteditable="true"],[contenteditable="plaintext-only"]');
  if (!ed) return null;
  const testo = sel.toString();
  if (!testo.trim()) return null;
  return { modo: 'editor', el: ed, sel: sel, testo: testo, rect: r.getBoundingClientRect() };
}
function csOffset(doc){
  if (doc === document) return { x: 0, y: 0 };
  const fr = Array.prototype.filter.call(document.querySelectorAll('iframe'), function(f){ try{ return f.contentDocument === doc; }catch(_){ return false; } })[0];
  if (!fr) return null;
  const q = fr.getBoundingClientRect();
  return { x: q.left, y: q.top };
}
function csControlla(doc){
  /* 0.9.260, Andrea: su Android "Sposta nel caveau" compariva due volte: nel menu del telefono (MenuCaveau.java)
     e in questa pillola in mezzo alla pagina. Sul telefono resta solo quella del menu; la pillola serve al PC. */
  if (/Android/i.test(navigator.userAgent || '')){ csNascondi(); return; }
  /* 0.9.271: il piano (la replica di Notion) ha la sua voce "Caveau" nella barra della selezione: la pillola qui
     sarebbe la seconda, e togliendo l'HTML di un blocco di React la pagina si rompeva */
  if (csProprio(doc)){ if (CS.doc === doc) csNascondi(); return; }
  const s = csSelezione(doc);
  if (!s){ if (CS.doc === doc) csNascondi(); return; }
  const off = csOffset(doc); if (!off) return;
  CS.doc = doc; CS.sel = s;
  const b = csBtn();
  b.hidden = false;
  const r = s.rect;
  let x = off.x + r.left + r.width / 2, y = off.y + r.top - 12;
  if (s.modo === 'campo'){ x = off.x + r.left + r.width / 2; y = off.y + r.top - 10; }
  const w = b.offsetWidth || 120;
  x = Math.max(8 + w / 2, Math.min(window.innerWidth - 8 - w / 2, x));
  if (y < 52) y = off.y + r.bottom + 44;
  b.style.left = Math.round(x) + 'px'; b.style.top = Math.round(y) + 'px';
}
function csVia(){
  const s = CS.sel, doc = CS.doc; if (!s || !doc) return;
  let testo = '';
  try{
    if (s.modo === 'campo'){
      const el = s.el, v = el.value;
      testo = s.testo;
      let a = s.a, b = s.b;
      /* via anche l'a capo che la riga si porta dietro, per non lasciare una riga vuota */
      if (b < v.length && v[b] === '\n') b++; else if (a > 0 && v[a - 1] === '\n') a--;
      el.focus();
      if (typeof el.setRangeText === 'function') el.setRangeText('', a, b, 'start');
      else el.value = v.slice(0, a) + v.slice(b);
      el.dispatchEvent(new (doc.defaultView || window).Event('input', { bubbles: true }));
      el.dispatchEvent(new (doc.defaultView || window).Event('change', { bubbles: true }));
    } else {
      const sel = s.sel;
      /* 0.9.259: la RIGA e' il blocco che contiene la selezione (li, p, div dentro all'editor): si legge il suo
         testo e si svuota con un Range. execCommand('delete') dentro a un iframe non faceva niente. */
      const r = sel.getRangeAt(0);
      let n = r.commonAncestorContainer; if (n.nodeType !== 1) n = n.parentElement;
      let blocco = n;
      while (blocco && blocco !== s.el && !/^(LI|P|DIV|H[1-6]|BLOCKQUOTE)$/.test(blocco.tagName)) blocco = blocco.parentElement;
      if (!blocco || blocco === s.el){ blocco = null; }
      testo = blocco ? (blocco.innerText || blocco.textContent || '') : s.testo;
      const win = doc.defaultView || window;
      const fuori = blocco ? blocco.outerHTML : '';
      if (blocco && blocco.parentNode){
        const lista = blocco.parentNode;
        if (blocco.tagName === 'LI' && lista && /^(UL|OL)$/.test(lista.tagName) && lista.children.length === 1) lista.remove(); else blocco.remove();
      } else {
        r.deleteContents();
      }
      try{ sel.removeAllRanges(); }catch(_){ }
      try{ s.el.dispatchEvent(new win.Event('input', { bubbles: true })); s.el.dispatchEvent(new win.Event('change', { bubbles: true })); }catch(_){ }
      /* 0.9.283: la nota dimentica la riga anche nella sua cronologia, cosi' Ctrl+Z non la riporta */
      try{ if (fuori && typeof win.flCaveauTolto === 'function') win.flCaveauTolto([fuori]); }catch(_){ }
    }
  }catch(_){ testo = testo || s.testo; }
  csNascondi();
  const righe = String(testo || '').split(/\n+/).map(function(x){ return x.replace(/^[☐☑•\-\s]+/, '').trim(); }).filter(Boolean);
  if (!righe.length) return;
  let ok = false;
  try{ ok = (typeof cvAggiungi === 'function') ? cvAggiungi(righe.join('\n'), false) : false; }catch(_){ }
  if (!ok){ try{ const l = JSON.parse(localStorage.getItem('fl_caveau') || '[]') || []; righe.forEach(function(x){ l.push({ id: 'cv' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), t: x.slice(0, 400), at: Date.now(), urg: false, stato: 'chiusa' }); }); localStorage.setItem('fl_caveau', JSON.stringify(l.slice(-500))); ok = true; }catch(_){ } }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  try{ if (typeof cvBoxPaint === 'function') cvBoxPaint(); }catch(_){ }
  try{ if (typeof cvPaginaPaint === 'function') cvPaginaPaint(); }catch(_){ }
  try{ if (typeof toast === 'function') toast(righe.length === 1 ? 'Al sicuro nel caveau: la riga è sparita dal foglio' : righe.length + ' righe al sicuro nel caveau'); }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:caveau', { detail: { n: righe.length } })); }catch(_){ }
}
/* 0.9.256, Andrea: la voce «Nel caveau» sta anche nel menu di Android del testo selezionato
   (Taglia, Copia, Incolla…): MainActivity.onActionModeStarted la aggiunge e chiama questa. Si cerca
   il documento con una selezione vera (la pagina o uno dei suoi iframe) e si fa lo stesso lavoro
   della pillola. */
/* un documento che sposta da se' le sue righe nel caveau (il piano: window.flCaveauSelezione) */
function csProprio(doc){ try{ const w = doc && doc.defaultView; return !!(w && typeof w.flCaveauSelezione === 'function'); }catch(_){ return false; } }
function csDalMenu(){
  const docs = [document].concat(Array.prototype.map.call(document.querySelectorAll('iframe'), function(f){ try{ return f.contentDocument; }catch(_){ return null; } }).filter(Boolean));
  for (let i = 0; i < docs.length; i++){
    if (csProprio(docs[i])){ try{ if (docs[i].defaultView.flCaveauSelezione()) return true; }catch(_){ } continue; }
    const s = csSelezione(docs[i]);
    if (s){ CS.doc = docs[i]; CS.sel = s; csVia(); return true; }
    /* 0.9.283: un'immagine scelta nelle note va nel caveau anche lei */
    try{ const w = docs[i].defaultView; if (w && typeof w.__nimgScelta === 'function' && w.__nimgScelta() && typeof w.__nimgAlCaveau === 'function' && w.__nimgAlCaveau()) return true; }catch(_){ }
  }
  try{ toast('Seleziona prima una riga di testo o un’immagine'); }catch(_){ }
  return false;
}
/* 0.9.283, Andrea: le immagini nel caveau. Si rimpicciolisce (lato lungo 720 px, JPEG) per non riempire la memoria:
   l'idea resta riconoscibile e il caveau non pesa. */
function csImmagineDato(img, lato){
  try{
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height; if (!w0 || !h0) return '';
    const k = Math.min(1, (lato || 720) / Math.max(w0, h0));
    const c = document.createElement('canvas'); c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.72);
  }catch(_){ return ''; }
}
/* 0.9.289: l'immagine del server (Samsung Notes) non si ridisegna: si tiene il suo indirizzo. Con la memoria piena si
   prova una copia piu' piccola (memoria.js intanto butta le cache). */
window.csImmagineAlCaveau = function(img){
  const prova = function(dato){ try{ return !!(dato && typeof cvAggiungiImmagine === 'function' && cvAggiungiImmagine(dato)); }catch(_){ return false; } };
  let ok = prova(csImmagineDato(img)) || prova(csImmagineDato(img, 420));
  if (!ok){ const src = img.currentSrc || img.src || ''; if (/^https?:\/\//.test(src) || (/^data:image\//.test(src) && src.length < 300000)) ok = prova(src); }
  if (!ok){ try{ toast('Memoria piena: l’immagine non è entrata nel caveau'); }catch(_){ } return false; }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  try{ if (typeof cvBoxPaint === 'function') cvBoxPaint(); if (typeof cvPaginaPaint === 'function') cvPaginaPaint(); }catch(_){ }
  try{ toast('Immagine al sicuro nel caveau'); }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:caveau', { detail: { n: 1 } })); }catch(_){ }
  return true;
};
function csAttiva(doc){
  if (!doc || doc._cs) return; doc._cs = 1;
  doc.addEventListener('selectionchange', function(){ clearTimeout(CS.t); CS.t = setTimeout(function(){ try{ csControlla(doc); }catch(_){ } }, 220); });
  doc.addEventListener('pointerdown', function(e){ const t = e.target; if (t && t.closest && t.closest('#csBtn')) return; csNascondi(); }, true);
  doc.addEventListener('scroll', function(){ csNascondi(); }, { capture: true, passive: true });
  doc.addEventListener('keydown', function(){ csNascondi(); }, true);
}
(function(){
  csAttiva(document);
  const aggancia = function(fr){
    const prova = function(){ try{ const d = fr.contentDocument; if (d && d.body) csAttiva(d); }catch(_){ } };
    fr.addEventListener('load', prova); prova();
  };
  document.querySelectorAll('iframe').forEach(aggancia);
  try{
    new MutationObserver(function(m){ m.forEach(function(x){ Array.prototype.forEach.call(x.addedNodes || [], function(n){ if (n && n.nodeType === 1){ if (n.tagName === 'IFRAME') aggancia(n); else if (n.querySelectorAll) n.querySelectorAll('iframe').forEach(aggancia); } }); }); })
      .observe(document.body, { childList: true, subtree: true });
  }catch(_){ }
  addEventListener('resize', csNascondi);
  const st = document.createElement('style');
  st.textContent = [
    '.cs-btn{position:fixed;z-index:9600;transform:translate(-50%,-100%);display:inline-flex;align-items:center;gap:6px;height:34px;padding:0 13px 0 11px;border:0;border-radius:99px;background:#14234A;color:#fff;font:800 13px var(--font-body);box-shadow:0 8px 20px rgba(0,20,60,.3);cursor:pointer;animation:csIn .16s ease-out}',
    '.cs-btn[hidden]{display:none}.cs-btn:active{transform:translate(-50%,-100%) scale(.96)}',
    '.cs-btn::after{content:"";position:absolute;left:50%;bottom:-5px;width:10px;height:10px;background:#14234A;transform:translateX(-50%) rotate(45deg);border-radius:2px}',
    'body.dark .cs-btn,body.dark .cs-btn::after{background:#BCE0FF;color:#14234A}',
    '@keyframes csIn{from{opacity:0;transform:translate(-50%,-90%)}to{opacity:1;transform:translate(-50%,-100%)}}'
  ].join('');
  document.head.appendChild(st);
})();
