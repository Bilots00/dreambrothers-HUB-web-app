/* ===========================================================================================
   GLI EPISODI CHE CAMBIANO FORMATO (0.9.322)

   Andrea: "sfrutta di piu' l'esperienza della sezione Dreamland del mio tema, che replica Atmos", e
   Google AI Mode: alternare i formati, cosi' la serie non annoia. Tre ritmi:
     - Genio che parla nella nuvoletta: tutti gli episodi di serie, gia' cosi'.
     - ATMOS (passo { atmos: [{ e, r: [...] }], fine }): si scorre e si vola fra le nuvole con l'aeroplano di
       carta, i testi galleggiano e passano. Stesse idee di db-dreamland.liquid, senza three.js: qui deve
       girare senza rete e su telefoni modesti, quindi solo trasformazioni CSS guidate dallo scorrimento.
     - FUMETTO (passo { fumetto: [{ art, t, s }], fine }): le vignette compaiono una alla volta scorrendo,
       per le idee che si capiscono meglio con un disegno.
   Prefisso atm-.
   =========================================================================================== */
const ATM = { el: null, raf: 0, nubi: [] };
function atmEsc(s){ return (typeof epiEsc === 'function') ? epiEsc(s) : String(s == null ? '' : s); }
function atmGrassetto(t){ return atmEsc(t).replace(/\*([^*]+)\*/g, '<b>$1</b>'); }
const ATM_AEREO = '<svg viewBox="0 0 120 120" aria-hidden="true"><path d="M8 58 112 10 78 108 56 70z" fill="#fff"/><path d="M56 70 112 10 66 92z" fill="#BCE0FF"/><path d="M56 70 66 92 78 108z" fill="#8CC6FF"/></svg>';

function atmAperto(){ return !!document.getElementById('atmG'); }
function atmChiudi(){ const w = document.getElementById('atmG'); if (w) w.remove(); cancelAnimationFrame(ATM.raf); ATM.el = null; }
function atmIndietro(){ if (!atmAperto()) return false; atmChiudi(); try{ if (typeof epiIndietro === 'function' && epiIndietro()) return true; if (typeof epiChiudi === 'function') epiChiudi(); }catch(_){ } return true; }
function atmAvanti(){ atmChiudi(); try{ if (typeof epiAvanti === 'function') epiAvanti(); }catch(_){ } }
function atmEsci(){ atmChiudi(); try{ if (typeof epiChiudi === 'function') epiChiudi(); }catch(_){ } }
const ATM_X = '<button type="button" class="atm-x" onclick="atmEsci()" aria-label="Chiudi">✕</button>';

/* ---------------------------------------------------------------- il volo */
function atmPasso(p){
  const cap = p.atmos || [], w = document.createElement('div');
  w.id = 'atmG'; w.className = 'atm';
  const nubi = []; for (let i = 0; i < 14; i++) nubi.push('<i class="atm-nu"></i>');
  const due = function(k){ return (k < 10 ? '0' : '') + k; };
  w.innerHTML = '<div class="atm-traccia" style="height:' + ((cap.length + 1) * 110) + '%"><div class="atm-palco">'
    + '<div class="atm-cielo"></div>' + nubi.join('')
    + '<div class="atm-aereo" id="atmAereo">' + ATM_AEREO + '</div>'
    + cap.map(function(c){ return '<div class="atm-cap">' + (c.e ? '<small>' + atmEsc(c.e) + '</small>' : '') + (c.r || []).map(function(r){ return '<p>' + atmGrassetto(r) + '</p>'; }).join('') + '</div>'; }).join('')
    + ATM_X + '<div class="atm-conta" id="atmConta">01 / ' + due(cap.length) + '</div>'
    + '<p class="atm-scorri" id="atmScorri">Scorri per volare</p>'
    + '<div class="atm-fine" id="atmFine"><button type="button" class="or-a main" onclick="atmAvanti()">' + atmEsc(p.fine || 'Continua') + '</button></div>'
    + '<i class="atm-bar"><b id="atmBar"></b></i>'
    + '</div></div>';
  (document.getElementById('phone') || document.body).appendChild(w);
  ATM.el = w;
  const n = cap.length, capi = w.querySelectorAll('.atm-cap'), nuvole = w.querySelectorAll('.atm-nu'), cielo = w.querySelector('.atm-cielo');
  const a = document.getElementById('atmAereo'), sc = document.getElementById('atmScorri'), fi = document.getElementById('atmFine'), b = document.getElementById('atmBar'), conta = document.getElementById('atmConta');
  const disegna = function(){
    const max = Math.max(1, w.scrollHeight - w.clientHeight), t = Math.min(1, w.scrollTop / max);
    /* si sale, e il cielo si fa notte */
    cielo.style.opacity = String(t);
    /* le nuvole nascono all'orizzonte, dietro all'aereo, e passano ai lati e sotto: lo spazio in alto resta ai testi */
    nuvole.forEach(function(el, i){
      const f = (t * 3.4 + i / 14) % 1, s = .12 + f * f * 3.6;
      const lato = i % 2 ? 1 : -1, x = lato * (18 + (i * 37) % 44) * f * f * 1.5, y = (4 + (i * 29) % 40) * f;
      el.style.transform = 'translate(' + x.toFixed(1) + 'vw,' + y.toFixed(1) + 'vh) scale(' + s.toFixed(2) + ')';
      el.style.opacity = String(f < .15 ? f / .15 * .85 : (f > .78 ? (1 - f) / .22 * .85 : .85));
    });
    a.style.transform = 'translate(-50%,-50%) translate(' + (Math.sin(t * 9) * 14).toFixed(1) + 'px,' + (Math.cos(t * 7) * 10).toFixed(1) + 'px) rotate(' + (-45 + Math.sin(t * 9) * 7).toFixed(1) + 'deg)';
    /* ogni testo arriva da lontano, sta fermo e nitido per un tratto lungo (si deve poter leggere), e passa oltre */
    let vicino = 0, meglio = 9;
    capi.forEach(function(el, i){
      const c = (i + .6) / (n + .4), d = (t - c) * (n + .4), v = Math.abs(d), fuori = Math.max(0, v - .24);
      if (v < meglio){ meglio = v; vicino = i; }
      el.style.opacity = String(Math.max(0, 1 - fuori * 3.4));
      el.style.transform = 'translate(-50%,-50%) perspective(600px) translateZ(' + ((d < 0 ? -1 : 1) * fuori * 420).toFixed(0) + 'px)';
      el.style.visibility = fuori > .3 ? 'hidden' : 'visible';
    });
    conta.textContent = due(vicino + 1) + ' / ' + due(n);
    sc.style.opacity = t > .015 ? '0' : '1';
    fi.classList.toggle('su', t > .97);
    b.style.top = (t * 88).toFixed(1) + '%';
  };
  let att = false;
  w.addEventListener('scroll', function(){ if (att) return; att = true; ATM.raf = requestAnimationFrame(function(){ att = false; disegna(); }); }, { passive: true });
  disegna();
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
}

/* ---------------------------------------------------------------- il fumetto */
const ATM_PALLE = [[34, 58], [52, 72], [70, 56], [44, 88], [62, 92], [80, 80], [30, 80], [56, 50], [74, 96], [38, 104], [60, 110], [82, 108]];
const ATM_COL = ['#3F9FF4', '#E63946', '#8CC6FF', '#0075E3', '#FF8A92', '#BCE0FF'];
const ATM_ART = {
  /* la bottiglia piena di cose da fare: la pancia e' piena, dal collo non esce niente di piu' */
  bottiglia: function(){ return '<svg viewBox="0 0 120 130" aria-hidden="true"><path d="M48 6h24v22c0 6 26 14 26 34v48c0 8-6 14-14 14H36c-8 0-14-6-14-14V62c0-20 26-28 26-34z" fill="#E3F1FF" stroke="#001E44" stroke-width="3"/>'
    + ATM_PALLE.map(function(p, i){ return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="7" fill="' + ATM_COL[i % ATM_COL.length] + '"/>'; }).join('') + '</svg>'; },
  /* il collo: una sola cosa nel punto piu' stretto */
  collo: function(){ return '<svg viewBox="0 0 120 130" aria-hidden="true"><path d="M48 6h24v22c0 6 26 14 26 34v48c0 8-6 14-14 14H36c-8 0-14-6-14-14V62c0-20 26-28 26-34z" fill="#E3F1FF" stroke="#001E44" stroke-width="3"/>'
    + ATM_PALLE.map(function(p){ return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="7" fill="#C9D9EE"/>'; }).join('') + '<circle cx="60" cy="24" r="11" fill="#E63946"/><path d="M92 24H76M82 16l-7 8 7 8" fill="none" stroke="#E63946" stroke-width="3.500" stroke-linecap="round" stroke-linejoin="round"/></svg>'; },
  /* e tutto scorre */
  scorre: function(){ return '<svg viewBox="0 0 120 130" aria-hidden="true"><path d="M40 6h40v20c0 8 18 14 18 34v50c0 8-6 14-14 14H36c-8 0-14-6-14-14V60c0-20 18-26 18-34z" fill="#E3F1FF" stroke="#001E44" stroke-width="3"/>'
    + [[60, 12], [50, 28], [70, 34], [60, 48], [44, 62], [76, 66], [60, 80], [40, 96], [80, 98], [60, 110]].map(function(p, i){ return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="7" fill="' + ATM_COL[i % ATM_COL.length] + '"/>'; }).join('') + '</svg>'; }
};
function fumPasso(p){
  const v = p.fumetto || [], w = document.createElement('div');
  w.id = 'atmG'; w.className = 'atm fum';
  w.innerHTML = ATM_X + '<div class="fum-in">' + v.map(function(x, i){
      return '<section class="fum-v' + (i === 0 ? ' in' : '') + '">' + (x.art && ATM_ART[x.art] ? '<div class="fum-art">' + ATM_ART[x.art]() + '</div>' : '')
        + '<h3>' + atmGrassetto(x.t) + '</h3>' + (x.s ? '<p>' + atmGrassetto(x.s) + '</p>' : '') + '</section>';
    }).join('')
    + '<div class="fum-fine"><button type="button" class="or-a main" onclick="atmAvanti()">' + atmEsc(p.fine || 'Continua') + '</button></div></div>';
  (document.getElementById('phone') || document.body).appendChild(w);
  const io = new IntersectionObserver(function(l){ l.forEach(function(e){ if (e.isIntersecting) e.target.classList.add('in'); }); }, { root: w, threshold: .35 });
  w.querySelectorAll('.fum-v').forEach(function(el){ io.observe(el); });
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.atm{position:fixed;inset:0;z-index:9970;overflow-y:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;background:#0075E3;color:#fff}.atm::-webkit-scrollbar{display:none}',
    '.atm-traccia{position:relative}.atm-palco{position:sticky;top:0;height:100vh;height:100dvh;overflow:hidden;background:linear-gradient(180deg,#0B4DA8 0%,#1E7BE0 56%,#9CD0FF 100%)}',
    '.atm-cielo{position:absolute;inset:0;background:linear-gradient(180deg,#000D1F 0%,#00306E 60%,#0059B3 100%);opacity:0}',
    '.atm-nu{position:absolute;left:50%;top:62%;width:190px;height:88px;margin:-44px 0 0 -95px;border-radius:50%;background:radial-gradient(closest-side,#fff 28%,rgba(255,255,255,.62) 58%,rgba(255,255,255,0));will-change:transform,opacity;pointer-events:none}',
    '.atm-aereo{position:absolute;left:50%;top:74%;width:84px;height:84px;filter:drop-shadow(0 14px 18px rgba(0,30,68,.4));pointer-events:none}.atm-aereo svg{width:100%;height:100%}',
    '.atm-cap{position:absolute;left:50%;top:32%;width:calc(100% - 56px);max-width:380px;text-align:center;pointer-events:none;will-change:transform,opacity}',
    '.atm-cap small{display:block;margin-bottom:14px;font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#BCE0FF}',
    '.atm-cap p{margin:0 0 10px;font:800 clamp(24px,6.8vw,30px)/1.24 var(--font-display);color:#fff;text-shadow:0 2px 18px rgba(0,20,60,.65)}.atm-cap p b{color:#FFD9DC;font-weight:800}',
    '.atm-conta{position:absolute;left:0;right:0;top:calc(22px + env(safe-area-inset-top));text-align:center;font:800 12px var(--font-body);letter-spacing:.14em;color:#fff;opacity:.85}',
    '.atm-scorri{position:absolute;left:0;right:0;bottom:calc(30px + env(safe-area-inset-bottom));margin:0;text-align:center;font:700 13px var(--font-body);letter-spacing:.08em;color:#fff;text-shadow:0 1px 8px rgba(0,30,68,.6);transition:opacity .3s ease;animation:atmSu 1.5s ease-in-out infinite}@keyframes atmSu{50%{transform:translateY(-7px)}}',
    '.atm-fine{position:absolute;left:24px;right:24px;bottom:calc(28px + env(safe-area-inset-bottom));opacity:0;pointer-events:none;transition:opacity .35s ease}.atm-fine.su{opacity:1;pointer-events:auto}.atm-fine .or-a{width:100%}',
    '.atm-bar{position:absolute;right:10px;top:24%;bottom:24%;width:2px;border-radius:2px;background:rgba(255,255,255,.28)}.atm-bar b{position:absolute;left:-2px;top:0;width:6px;height:12%;border-radius:6px;background:#fff}',
    '.atm-x{position:absolute;left:14px;top:calc(12px + env(safe-area-inset-top));z-index:3;width:36px;height:36px;padding:0;border:0;border-radius:50%;background:rgba(0,20,60,.4);color:#fff;font-size:15px;cursor:pointer}.fum .atm-x{position:fixed}',
    '.fum{background:#001E44}.fum-in{padding:calc(30px + env(safe-area-inset-top)) 22px calc(30px + env(safe-area-inset-bottom));max-width:440px;margin:0 auto}',
    '.fum-v{min-height:74vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;opacity:0;transform:translateY(26px) scale(.97);transition:opacity .6s ease,transform .6s cubic-bezier(.2,.8,.2,1)}.fum-v.in{opacity:1;transform:none}',
    '.fum-art{width:190px;padding:18px;border-radius:26px;background:#fff;box-shadow:0 18px 40px rgba(0,0,0,.35)}.fum-art svg{display:block;width:100%}',
    '.fum-v h3{margin:26px 0 0;font:800 25px/1.25 var(--font-display);color:#fff}.fum-v h3 b{color:#FF8A92;font-weight:800}.fum-v p{margin:12px 0 0;max-width:30ch;font:500 16px/1.45 var(--font-body);color:#D6E8FF}.fum-v p b{color:#fff;font-weight:800}',
    '.fum-fine{padding:10px 0 20px}.fum-fine .or-a{width:100%}'
  ].join('\n');
  document.head.appendChild(st);
})();
