/* ===========================================================================================
   LA MEMORIA CHE NON SI RIEMPIE (0.9.301; prima: "la memoria piena", 0.9.288)

   LA CAUSA VERA. La memoria locale della pagina (localStorage) ha un tetto fisso: in Chrome e nella
   WebView di Android 10 MB contati in caratteri UTF-16, cioe' circa 5 milioni di caratteri. Le
   personalizzazioni con immagine (diapositive della schermata di blocco, preset, cinema, avatar, le
   foto del perche', l'Io futuro...) finivano li' dentro come testo base64: una foto da 900 pixel in
   JPEG sono ~450.000 caratteri, cioe' ~900 KB del tetto. Dieci immagini e la memoria era piena, e da
   li' OGNI scrittura dell'app falliva, anche un interruttore. La 0.9.288 se ne accorgeva e mostrava
   "La memoria dell'app e' piena: questa modifica non e' stata salvata": vero, ma il dato era perso.

   LA SOLUZIONE. Le cose grandi non stanno piu' in localStorage: stanno in IndexedDB (database
   'fl_memoria', tabella 'v'), che non ha quel tetto (prende una quota dello spazio libero del
   telefono, centinaia di MB). Tutto avviene QUI, sotto localStorage, senza toccare chi salva:
   - setItem di un valore con un'immagine (o enorme): il valore va in una copia in memoria (BIG) e in
     IndexedDB; quando IndexedDB conferma e la rilettura e' identica, in localStorage resta solo un
     segnaposto di pochi caratteri. Se ci sta, il valore viene scritto ANCHE in localStorage subito,
     cosi' e' al sicuro dal primo istante; il segnaposto lo sostituisce solo dopo la verifica.
   - getItem: se la chiave e' in BIG, torna il valore vero. Chi legge non si accorge di niente.
   - qualunque scrittura che non ci sta (anche piccola): prima si buttano le cache, poi il valore va
     in IndexedDB come sopra. Non si lancia piu' l'errore e non compare piu' nessun avviso: il dato
     e' salvato.
   - all'avvio: si caricano in BIG i valori di IndexedDB e si MIGRANO da soli quelli grandi ancora in
     localStorage (copia, rilettura, confronto, e solo allora il segnaposto al loro posto).
   Regola per decidere chi vince fra le due copie, all'avvio: un valore vero in localStorage batte
   IndexedDB (vuol dire che e' stato scritto dopo, o che la migrazione non era finita); un segnaposto
   o una chiave assente lasciano vincere IndexedDB.
   Deve caricarsi per primo (index.html, prima di scorre.js).
   =========================================================================================== */
(function(){
  if (typeof Storage === 'undefined' || !Storage.prototype || Storage.prototype.setItem.__flMem) return;
  const SP = Storage.prototype;
  const oSet = SP.setItem, oGet = SP.getItem, oRem = SP.removeItem, oClear = SP.clear;
  /* solo cache: si rifanno da sole al prossimo calcolo */
  const CACHE = [/^fl_dayrep_/, /^fl_ins_cache_/, /^fl_bgs$/, /^fl_pfr_cache$/, /^fl_sp_cache$/, /^fl_wk_cache$/, /^fl_grey_cache$/, /^fl_quotes$/];
  const SEGNO = '\u2060flidb:';              // il segnaposto (un carattere invisibile davanti: nessun dato vero comincia cosi')
  const IMG = /data:[a-z]+\/[a-z0-9.+-]+;base64,/i;
  const SOGLIA_IMG = 4096;                   // un valore con un'immagine dentro, da 4.000 caratteri in su
  const SOGLIA = 131072;                     // qualunque valore oltre i 128.000 caratteri
  /* Le chiavi lette ANCHE dalle pagine Note e Piano (www/note, www/notion): girano in un iframe con il
     loro localStorage "nudo", senza questo file, e leggerebbero il segnaposto al posto del dato (le note
     sembrerebbero vuote e verrebbero riscritte vuote). Queste restano SEMPRE vere in localStorage. */
  const CONDIVISE = [/^fl_note_/, /^fl_caveau$/, /^fl_ulisse$/, /^fl_piano/, /^fl_notion/, /^fl_iofuturo$/];
  const RIENTRO = new Map();                 // chiave condivisa che non ci stava: si riscrive appena c'e' posto
  const BIG = new Map();                     // chiave -> valore vero, per le chiavi che vivono in IndexedDB
  const TOCCATE = new Set();                 // scritte o tolte in questa sessione prima del caricamento
  const PRESTO = new Set();                  // lette prima che IndexedDB fosse caricato
  const SCARTATE = [];                       // scritture fatte su un dato letto vuoto perche' non ancora caricato
  const CODA = new Map();                    // chiave -> valore da scrivere (null = da togliere)
  let pronto = false, db = null, dbProm = null, timer = 0;
  const stato = { pronto: false, prontoMs: 0, inIdb: 0, migrate: 0, salvateQuandoPiena: 0, errori: 0, presto: [], primaLettura: {} };
  const T0 = Date.now();

  function piena(e){ return e && (e.name === 'QuotaExceededError' || e.code === 22 || e.code === 1014 || /quota/i.test(String(e.message || ''))); }
  let LS0 = null; try{ LS0 = window.localStorage; }catch(_){ }
  function eLocale(st){ return LS0 !== null && st === LS0; }
  function eSegno(v){ return typeof v === 'string' && v.charCodeAt(0) === 0x2060 && v.indexOf(SEGNO) === 0; }
  function grande(v){ return v.length >= SOGLIA || (v.length >= SOGLIA_IMG && IMG.test(v)); }
  function condivisa(k){ return CONDIVISE.some(function(r){ return r.test(k); }); }
  function liberaCache(st, tieni){
    const via = [];
    for (let i = 0; i < st.length; i++){ const k = st.key(i); if (k && k !== tieni && CACHE.some(function(r){ return r.test(k); })) via.push(k); }
    via.forEach(function(k){ try{ oRem.call(st, k); }catch(_){ } });
    return via.length;
  }
  function log(m, e){ try{ console.warn('[memoria] ' + m, e || ''); }catch(_){ } }

  /* ------------------------------------------------------------------ IndexedDB */
  function apri(){
    if (db) return Promise.resolve(db);
    if (dbProm) return dbProm;
    dbProm = new Promise(function(ok){
      try{
        if (typeof indexedDB === 'undefined' || !indexedDB) return ok(null);
        const r = indexedDB.open('fl_memoria', 1);
        r.onupgradeneeded = function(){ if (!r.result.objectStoreNames.contains('v')) r.result.createObjectStore('v'); };
        r.onsuccess = function(){ db = r.result; try{ db.onversionchange = function(){ try{ db.close(); }catch(_){ } db = null; dbProm = null; }; }catch(_){ } ok(db); };
        r.onerror = function(){ ok(null); };
        r.onblocked = function(){ ok(null); };
      }catch(_){ ok(null); }
    }).then(function(d){ if (!d) dbProm = null; return d; });
    return dbProm;
  }
  /* Le scritture si raccolgono per un attimo (chi scrive la stessa chiave a ogni tasto ne fa una sola)
     e partono tutte in una transazione. Dopo la conferma si rilegge e si confronta: solo allora il
     valore in localStorage diventa un segnaposto. */
  function accoda(k, v){ CODA.set(k, v); if (!timer) timer = setTimeout(svuota, 0); }
  function svuota(){
    timer = 0;
    if (!CODA.size) return;
    const lotto = Array.from(CODA.entries()); CODA.clear();
    apri().then(function(d){
      if (!d){ stato.errori++; log('IndexedDB non disponibile: riprovo fra poco'); lotto.forEach(function(x){ if (!CODA.has(x[0])) CODA.set(x[0], x[1]); }); if (!timer) timer = setTimeout(svuota, 3000); return; }
      let tx;
      try{
        tx = d.transaction('v', 'readwrite');
        const s = tx.objectStore('v');
        lotto.forEach(function(x){ if (x[1] === null) s.delete(x[0]); else s.put(x[1], x[0]); });
      }catch(e){ stato.errori++; log('scrittura non partita, riprovo', e); lotto.forEach(function(x){ if (!CODA.has(x[0])) CODA.set(x[0], x[1]); }); if (!timer) timer = setTimeout(svuota, 1000); return; }
      tx.oncomplete = function(){ verifica(d, lotto.filter(function(x){ return x[1] !== null; })); };
      tx.onerror = tx.onabort = function(){ stato.errori++; log('scrittura fallita, riprovo', tx.error); lotto.forEach(function(x){ if (!CODA.has(x[0])) CODA.set(x[0], x[1]); }); if (!timer) timer = setTimeout(svuota, 1000); };
    });
  }
  function verifica(d, scritti){
    if (!scritti.length) return;
    try{
      const tx = d.transaction('v', 'readonly'), s = tx.objectStore('v');
      scritti.forEach(function(x){
        const q = s.get(x[0]);
        q.onsuccess = function(){
          if (q.result !== x[1]){ if (BIG.get(x[0]) === x[1]) accoda(x[0], x[1]); return; }
          /* il valore e' salvato davvero: ora (e solo ora) localStorage si libera */
          if (BIG.get(x[0]) === x[1]) segnaposto(x[0], x[1].length);
        };
      });
    }catch(e){ log('verifica non riuscita', e); }
  }
  function segnaposto(k, n){
    const ls = window.localStorage, s = SEGNO + n;
    try{ if (oGet.call(ls, k) === s) return; }catch(_){ }
    try{ oSet.call(ls, k, s); return; }catch(e){ if (!piena(e)) return; }
    liberaCache(ls, k);
    try{ oSet.call(ls, k, s); return; }catch(_){ }
    /* pienissima: si toglie il vecchio valore (il nuovo e' gia' in IndexedDB, verificato) e si riprova */
    try{ oRem.call(ls, k); oSet.call(ls, k, s); }catch(_){ }
  }

  function riprovaRientro(volta){
    setTimeout(function(){
      const ls = window.localStorage;
      RIENTRO.forEach(function(v, k){
        try{ oSet.call(ls, k, v); RIENTRO.delete(k); if (BIG.get(k) === v) BIG.delete(k); }catch(_){ }
      });
      if (RIENTRO.size && volta < 30) riprovaRientro(volta + 1);
      else if (RIENTRO.size) log('chiavi condivise ancora in attesa di posto: ' + Array.from(RIENTRO.keys()).join(', '));
    }, 1500);
  }

  /* ------------------------------------------------------------------ localStorage, da sotto */
  function salvaGrande(st, k, v, provaPrima){
    BIG.set(k, v);
    if (!pronto) TOCCATE.add(k);
    if (provaPrima){ try{ oSet.call(st, k, v); }catch(_){ } }   // al sicuro subito, se ci sta
    accoda(k, v);
  }
  SP.setItem = function(k, v){
    k = String(k); v = String(v);
    if (!eLocale(this)){
      try{ return oSet.call(this, k, v); }
      catch(e){ if (!piena(e)) throw e; liberaCache(this, k); return oSet.call(this, k, v); }
    }
    /* sotto i 128.000 caratteri si scrive anche subito in localStorage (al sicuro dal primo istante);
       le foto vere vanno dritte in IndexedDB, o riempirebbero la memoria per i pochi millisecondi
       della verifica e le scritture subito dopo non ci starebbero */
    const comune = condivisa(k);
    /* MAI VUOTO SOPRA PIENO. Chi ha letto questa chiave prima che IndexedDB fosse caricato ha avuto
       null al posto del dato vero: quello che scrive adesso e' calcolato su un dato mancante e
       cancellerebbe l'originale. Non si scrive; al caricamento la pagina si ridisegna col dato vero. */
    if (!pronto && PRESTO.has(k) && !BIG.has(k) && eSegno(oGet.call(this, k))){ SCARTATE.push(k); return; }
    if (!comune && grande(v) && !eSegno(v)){ salvaGrande(this, k, v, v.length < SOGLIA); return; }
    /* un valore piccolo: se la chiave viveva in IndexedDB, torna in localStorage */
    try{ oSet.call(this, k, v); }
    catch(e){
      if (!piena(e)) throw e;
      liberaCache(this, k);
      try{ oSet.call(this, k, v); }
      catch(e2){
        if (!piena(e2)) throw e2;
        stato.salvateQuandoPiena++;
        if (comune){
          /* una chiave condivisa resta vera in localStorage: per adesso la tiene la memoria della
             pagina, e si riscrive da sola appena si libera posto (si spostano gli altri valori grandi) */
          BIG.set(k, v); RIENTRO.set(k, v); migra(); riprovaRientro(1);
          return;
        }
        /* non ci sta: va in IndexedDB. Salvato comunque, senza errori e senza avvisi. */
        salvaGrande(this, k, v, false);
        return;
      }
    }
    if (RIENTRO.has(k)) RIENTRO.delete(k);
    if (BIG.has(k)){ BIG.delete(k); if (!comune) accoda(k, null); }
    if (!pronto) TOCCATE.add(k);
  };
  SP.setItem.__flMem = true;
  SP.getItem = function(k){
    const raw = oGet.call(this, k);
    if (!eLocale(this)) return raw;
    k = String(k);
    if (BIG.has(k)){ if (!(k in stato.primaLettura)) stato.primaLettura[k] = Date.now() - T0; return BIG.get(k); }
    if (eSegno(raw)){ if (!pronto){ PRESTO.add(k); stato.presto = Array.from(PRESTO); } return null; }
    return raw;
  };
  SP.removeItem = function(k){
    if (eLocale(this)){
      k = String(k);
      if (!pronto && PRESTO.has(k) && !BIG.has(k) && eSegno(oGet.call(this, k))){ SCARTATE.push(k); return; }
      if (!pronto) TOCCATE.add(k);
      RIENTRO.delete(k);
      if (BIG.has(k) || !pronto || eSegno(oGet.call(this, k))){ BIG.delete(k); accoda(k, null); }
    }
    return oRem.call(this, k);
  };
  SP.clear = function(){
    if (eLocale(this)){
      BIG.clear(); CODA.clear();
      apri().then(function(d){ if (!d) return; try{ d.transaction('v', 'readwrite').objectStore('v').clear(); }catch(_){ } });
    }
    return oClear.call(this);
  };

  /* ------------------------------------------------------------------ all'avvio */
  function carica(){
    /* solo per le prove: un caricamento lento, per vedere cosa succede a chi legge troppo presto */
    const rit = +(window.__flMemoriaRitardo || 0);
    if (rit > 0){ window.__flMemoriaRitardo = 0; setTimeout(carica, rit); return; }
    apri().then(function(d){
      if (!d){ pronto = true; stato.pronto = true; return; }
      let tx;
      try{ tx = d.transaction('v', 'readonly'); }catch(_){ pronto = true; stato.pronto = true; return; }
      const s = tx.objectStore('v'), chiavi = [], valori = [];
      const fine = function(){
        const ls = window.localStorage, vecchie = [];
        for (let i = 0; i < chiavi.length; i++){
          const k = String(chiavi[i]), v = valori[i];
          if (TOCCATE.has(k) || typeof v !== 'string') continue;
          if (condivisa(k)){ vecchie.push(k); continue; }
          const raw = oGet.call(ls, k);
          if (raw === null || eSegno(raw)){
            BIG.set(k, v);
            if (raw === null) segnaposto(k, v.length);   // salvata a memoria pienissima: la chiave torna visibile
          } else vecchie.push(k);                          // un valore vero in localStorage vince
        }
        vecchie.forEach(function(k){ accoda(k, null); });
        pronto = true; stato.pronto = true; stato.inIdb = BIG.size; stato.prontoMs = Date.now() - T0;
        if (PRESTO.size){
          /* qualcuno ha disegnato senza il dato (es. il ritratto del profilo, disegnato da nav.js
             mentre la pagina si carica): si ridisegna adesso, come se si tornasse sulla scheda */
          stato.scartate = SCARTATE.slice();
          log('lette prima del caricamento: ' + Array.from(PRESTO).join(', ') + (SCARTATE.length ? ' (scritture fermate: ' + SCARTATE.join(', ') + ')' : ''));
          try{ window.dispatchEvent(new CustomEvent('flmemoria', { detail: { chiavi: Array.from(PRESTO) } })); }catch(_){ }
          const ridisegna = function(){
            try{ if (typeof renderProfile === 'function') renderProfile(); }catch(_){ }
            try{ const t = oGet.call(window.localStorage, 'fl_tab'); if (t) document.dispatchEvent(new CustomEvent('fl:tab', { detail: t })); }catch(_){ }
          };
          if (window.__flAvviato) ridisegna(); else document.addEventListener('DOMContentLoaded', function(){ setTimeout(ridisegna, 0); });
        }
        setTimeout(migra, 1200);
      };
      try{
        if (s.getAllKeys && s.getAll){
          const a = s.getAllKeys(), b = s.getAll();
          a.onsuccess = function(){ chiavi.push.apply(chiavi, a.result); };
          b.onsuccess = function(){ valori.push.apply(valori, b.result); };
          tx.oncomplete = fine;
        } else {
          const c = s.openCursor();
          c.onsuccess = function(){ const x = c.result; if (x){ chiavi.push(x.key); valori.push(x.value); x.continue(); } };
          tx.oncomplete = fine;
        }
        tx.onerror = tx.onabort = function(){ pronto = true; stato.pronto = true; };
      }catch(_){ pronto = true; stato.pronto = true; }
    });
  }
  /* I dati gia' salvati in localStorage dalle versioni di prima: quelli grandi passano in IndexedDB
     da soli. Si copia, si rilegge, si confronta, e solo dopo localStorage si libera (verifica()). */
  function migra(){
    try{
      const ls = window.localStorage;
      let n = 0;
      for (let i = 0; i < ls.length; i++){
        const k = ls.key(i); if (!k || BIG.has(k) || condivisa(k)) continue;
        const raw = oGet.call(ls, k);
        if (typeof raw !== 'string' || eSegno(raw) || !grande(raw)) continue;
        BIG.set(k, raw); accoda(k, raw); n++;
      }
      stato.migrate += n;
      if (n) try{ console.info('[memoria] ' + n + ' valori grandi spostati in IndexedDB'); }catch(_){ }
    }catch(e){ log('migrazione non riuscita', e); }
  }
  /* uscendo dall'app, quello che e' in coda parte subito */
  try{
    document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden' && CODA.size){ clearTimeout(timer); svuota(); } });
    window.addEventListener('pagehide', function(){ if (CODA.size){ clearTimeout(timer); svuota(); } });
  }catch(_){ }
  window.flMemoriaStato = function(){ stato.inIdb = BIG.size; stato.coda = CODA.size; return JSON.parse(JSON.stringify(stato)); };
  window.flMemoriaPronta = function(){ return new Promise(function(ok){ (function g(){ if (pronto) ok(true); else setTimeout(g, 20); })(); }); };
  window.flMemoriaGrezza = function(k){ try{ return oGet.call(window.localStorage, k); }catch(_){ return null; } };
  carica();
})();

/** Quanto occupa la memoria locale, e quali chiavi pesano di piu' (per la pagina Informazioni e per le prove).
    kb = quello che pesa davvero in localStorage (i segnaposto contano pochi byte); idbKb = quello che sta in IndexedDB. */
function flMemoriaUso(){
  const l = [];
  let tot = 0, idb = 0;
  const grezza = typeof flMemoriaGrezza === 'function' ? flMemoriaGrezza : function(k){ return localStorage.getItem(k); };
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i), raw = grezza(k) || '';
      const n = (k.length + raw.length) * 2; tot += n;
      const vero = localStorage.getItem(k) || '';
      if (vero !== raw) idb += vero.length * 2;
      l.push([k, (k.length + vero.length) * 2]);
    }
  }catch(_){ }
  l.sort(function(a, b){ return b[1] - a[1]; });
  return { kb: Math.round(tot / 1024), idbKb: Math.round(idb / 1024), top: l.slice(0, 12).map(function(x){ return x[0] + ' ' + Math.round(x[1] / 1024) + 'KB'; }) };
}
