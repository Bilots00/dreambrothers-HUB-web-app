/* ===========================================================================================
   LA STAGIONE DI SPINTA (0.9.242): il Monk mode di Davie Fogarty

   Novanta giorni come se la tua vita dipendesse dall'obiettivo, poi due settimane di riposo e
   il bilancio. Si sceglie (opt-in), da una porta chiara: la vista Roadmap della Mappa e la prima
   card delle Sfide di Dream. Mentre dura la spinta le sezioni che distraggono restano spente
   (blocchi-sezioni.js: giochi del Genio, Academy, respiro, Consigliato per te, sfide, Lega);
   il respiro e i consigli si riaprono solo nei giorni con l'umore basso.

   I DATI: fl_stagione = { inizio (mezzanotte del primo giorno), obiettivo, blocchi { k: true },
   bilancio, interrotta } e fl_stagione_storia = [stagioni finite]. Entrano nel backup da soli
   (profile.js prende tutte le chiavi fl_).

   PER DREAM: flStagioneAttiva() restituisce { fase: 'spinta'|'reset', giorno, di, obiettivo,
   inizio, fineSpinta, fineReset, blocchi, bilancio } oppure null. Ci si puo' appoggiare una card.
   (Il "Monk Mode" degli scrigni, trenta giorni e quindici ore a settimana, e' un'altra cosa e
   resta com'e'.)
   =========================================================================================== */
const STG_KEY = 'fl_stagione';
const STG_STORIA_KEY = 'fl_stagione_storia';
const STG_SPINTA = 90;
const STG_RESET = 14;
const STG = { passo: 'intro', bozza: null, bil: null };

function stgLeggiJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function stgScriviJ(k, v){ try{ if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function stgEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function stgMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function stgGiorniDa(inizio, adesso){ return Math.round((stgMezzanotte(adesso) - stgMezzanotte(inizio)) / 86400000) + 1; }
function stgData(ms){ const d = new Date(ms); const m = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']; return d.getDate() + ' ' + m[d.getMonth()]; }

/* 0.9.363, Andrea: "i 90 giorni non devono essere per forza 90: sono il default, ma se l'utente vuole un mese puo' farlo. E una
   modalita' ADHD per chi soffre di cecita' temporale, con scadenze vicine come entro domani" (il reel del dott. Valerio Rosso:
   una scadenza lontana resta astratta finche' non diventa urgente; esistono solo "adesso" e "non adesso"). Quindi in modalita'
   ADHD: scadenze vicine, il conto alla rovescia in ore, una cosa sola da fare adesso. s.di = giorni di spinta, s.adhd. */
const STG_DURATE = [[90, '90 giorni'], [60, '60 giorni'], [30, '30 giorni']];
const STG_DURATE_ADHD = [[2, 'Entro domani'], [3, '3 giorni'], [7, '1 settimana'], [14, '2 settimane']];
function stgDi(s){ const n = s && +s.di; return n > 0 ? Math.min(365, Math.round(n)) : STG_SPINTA; }
function stgRiposo(di){ return di >= 30 ? STG_RESET : Math.max(1, Math.round(di / 4)); }
function stgGiorniTxt(n){ return n === 1 ? '1 giorno' : n + ' giorni'; }
function stgOreTxt(ms){ const h = Math.max(0, Math.floor(ms / 3600000)), m = Math.max(0, Math.floor(ms / 60000) % 60); return h >= 1 ? (h === 1 ? '1 ora' : h + ' ore') + (h < 10 && m ? ' e ' + m + ' min' : '') : m + ' minuti'; }
function stgCorrente(){ const s = stgLeggiJ(STG_KEY, null); return s && s.inizio ? s : null; }

/** Lo stato della stagione adesso, o null se non c'e' (o e' finita: allora passa nella storia). */
function flStagioneAttiva(adesso){
  const s = stgCorrente(); if (!s) return null;
  const g = stgGiorniDa(s.inizio, adesso), DI = stgDi(s), RI = stgRiposo(DI);
  const fineSpinta = stgMezzanotte(s.inizio) + DI * 86400000;
  const fineReset = fineSpinta + RI * 86400000;
  if (g < 1) return null;
  if (g > DI + RI){ stgArchivia(s, false); return null; }
  const spinta = g <= DI;
  return { fase: spinta ? 'spinta' : 'reset', giorno: spinta ? g : g - DI, di: spinta ? DI : RI, adhd: !!s.adhd, spintaDi: DI,
           giornoTot: g, obiettivo: s.obiettivo || '', inizio: s.inizio, fineSpinta: fineSpinta, fineReset: fineReset,
           blocchi: s.blocchi || {}, bilancio: s.bilancio || null };
}
/* 0.9.372: il programma di blocco della spinta (modo "tutto"): le app segnate come distrazioni e i social sul web, tutto il giorno, ogni
   giorno. Porta stagione:true e si toglie da solo quando la stagione si chiude o si interrompe */
async function stgProgrammaCrea(DI){
  try{
    if (typeof PROGRAMS === 'undefined') return;
    let apps = []; try{ const c = (typeof insCats === 'function') ? insCats() : {}; apps = Object.keys(c).filter(function(k){ return c[k] === 'distr'; }); }catch(_){ apps = []; }
    const siti = (typeof DISTRACTIONS !== 'undefined') ? DISTRACTIONS.slice() : ['instagram.com', 'tiktok.com', 'facebook.com', 'youtube.com'];
    for (let i = PROGRAMS.length - 1; i >= 0; i--) if (PROGRAMS[i] && PROGRAMS[i].stagione) PROGRAMS.splice(i, 1);
    PROGRAMS.push({ id: 'p' + Date.now().toString(36), name: 'Stagione di spinta', type: 'ora', icon: '🛡️', from: '00:00', to: '23:59',
      days: [true, true, true, true, true, true, true], allDay: true, apps: apps, sites: siti, keywords: [], allow: [],
      blockLaunch: true, blockNotifications: true, on: true, stagione: true, fino: stgMezzanotte() + DI * 86400000 });
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    if (typeof pushRules === 'function') await pushRules();
    if (!apps.length) try{ toast('Bloccati i social sul web. Per bloccare anche le app, segna quelle che ti distraggono nel Report.'); }catch(_){ }
  }catch(_){ }
}
/* "Tutto, tranne i sempre consentiti": l'elenco consentito del motore per tutta la spinta, con le app e i siti del Full Focus; le regole di
   prima si mettono da parte e tornano alla fine */
async function stgConsentitiArma(DI){
  try{
    if (typeof blkNative !== 'function') return;
    const cur = await blkNative('getRulesFull', {}, true);
    if (!localStorage.getItem('fl_stg_prima')) localStorage.setItem('fl_stg_prima', JSON.stringify({ listMode: (cur && cur.listMode) || 'blocklist', allowApps: (cur && cur.allowApps) || [], allow: (cur && cur.allow) || [], fino: stgMezzanotte() + DI * 86400000 }));
    const p = (typeof ffPref === 'function') ? ffPref() : {};
    const apps = (p.allow || []).slice(); if (apps.indexOf('com.dreambrothers.focuslock') < 0) apps.push('com.dreambrothers.focuslock');
    const ok = await blkNative('setRulesFull', { listMode: 'allowlist', allowApps: apps, allow: (p.allowSites || []).slice() });
    if (ok === null){ localStorage.removeItem('fl_stg_prima'); try{ toast('Il blocco non si e\' acceso: uso una lista di blocco'); }catch(_){ } stgProgrammaCrea(DI); }
  }catch(_){ }
}
async function stgConsentitiTogli(){
  try{
    const pr = JSON.parse(localStorage.getItem('fl_stg_prima') || 'null'); if (!pr) return;
    if (typeof blkNative === 'function'){ const ok = await blkNative('setRulesFull', { listMode: pr.listMode, allowApps: pr.allowApps || [], allow: pr.allow || [] }); if (ok === null) return; }
    localStorage.removeItem('fl_stg_prima');
  }catch(_){ }
}
async function stgProgrammaTogli(){
  stgConsentitiTogli();
  try{
    if (typeof PROGRAMS === 'undefined') return;
    let tolti = 0;
    for (let i = PROGRAMS.length - 1; i >= 0; i--) if (PROGRAMS[i] && PROGRAMS[i].stagione){ PROGRAMS.splice(i, 1); tolti++; }
    if (!tolti) return;
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    if (typeof pushRules === 'function') await pushRules();
  }catch(_){ }
}
/* a ogni avvio: finita la spinta, il programma si toglie anche se la stagione non e' stata chiusa a mano */
setTimeout(function(){ try{ const pr = JSON.parse(localStorage.getItem('fl_stg_prima') || 'null'); if ((pr && pr.fino && Date.now() > pr.fino) || (typeof PROGRAMS !== 'undefined' && PROGRAMS.some(function(p){ return p && p.stagione && p.fino && Date.now() > p.fino; }))) stgProgrammaTogli(); }catch(_){ } }, 6000);
function stgArchivia(s, interrotta){
  stgProgrammaTogli();
  const l = stgLeggiJ(STG_STORIA_KEY, []) || [];
  l.push(Object.assign({}, s, { chiusa: Date.now(), interrotta: !!interrotta }));
  stgScriviJ(STG_STORIA_KEY, l.slice(-20));
  stgScriviJ(STG_KEY, null);
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO (usato anche da prenota.js e piano-settimana.js): un velo con una card blu notte
   --------------------------------------------------------------------------------------- */
function stgFoglio(html, id, intera){
  { const v0 = document.getElementById('stgVelo'); if (v0) v0.remove(); }
  const v = document.createElement('div');
  v.id = 'stgVelo'; v.className = 'stg-velo' + (intera ? ' stg-pagina' : '');
  v.innerHTML = '<div class="stg-scrim" onclick="stgFoglioChiudi()"></div><div class="stg-f" role="dialog" aria-modal="true"' + (id ? ' id="' + id + '"' : '') + '>'
    + '<button type="button" class="stg-x" onclick="stgFoglioChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="stg-fin">' + html + '</div></div>';
  (document.getElementById('phone') || document.body).appendChild(v);
  return v;
}
function stgFoglioCorpo(html){ const c = document.querySelector('#stgVelo .stg-fin'); if (c){ c.innerHTML = html; c.scrollTop = 0; } }
function stgFoglioChiudi(){
  const v = document.getElementById('stgVelo'); if (v) v.remove();
  /* aperto dalla tappa della mappa: chiuso il foglio, la tappa si chiude (accettata o rimandata) */
  if (STG.daMappa){ STG.daMappa = false; setTimeout(function(){ try{ sdAggiorna(true); sdPaint(); }catch(_){ } }, 200); }
}
function stgBack(){ if (document.getElementById('stgVelo')){ if (STG.bozza && STG_PASSI.indexOf(STG.passo) > 0 && document.querySelector('#stgVelo .stg-testa')) stgIndietro(); else stgFoglioChiudi(); return true; } return false; }

const STG_I = {
  monte: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20l6.5-11 4 6.5 2.5-4L21 20z"/><path d="M14.5 6.5l1.5-2.5 1.5 2.5"/></svg>',
  luna: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>',
  spento: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>'
};

/* ---------------------------------------------------------------------------------------
   COMINCIARE: tre schermate (come funziona, l'obiettivo, cosa si spegne)
   --------------------------------------------------------------------------------------- */
function stgObiettivoProposto(){
  /* 0.9.290, Andrea: "viene precompilato con 'L'app e' pubblica e viaggia insieme a ogni quadro venduto': quello non e'
     l'obiettivo che mi sono scritto, viene dalla roadmap". Il trimestre del piano e gli orizzonti li scrive l'agente;
     qui va solo quello che la persona ha scritto con le sue parole: l'obiettivo della stagione di prima, se c'e',
     altrimenti il sogno che ha scelto lui. */
  try{
    const st = JSON.parse(localStorage.getItem('fl_stagione_storia') || '[]') || [];
    const ult = st.length ? st[st.length - 1] : null;
    if (ult && ult.obiettivo && String(ult.obiettivo).trim()) return stgPulito(ult.obiettivo);
  }catch(_){ }
  try{ if (typeof nvSogno === 'function'){ const sg = String(nvSogno() || '').trim(); if (sg) return stgPulito(sg); } }catch(_){ }
  return '';
}
function stgPulito(t){ t = String(t || '').trim(); return typeof flAccenti === 'function' ? flAccenti(t) : t; }
function stgApri(){
  const st = flStagioneAttiva();
  if (st && st.fase === 'reset'){ stgBilancioApri(); return; }
  if (st){ stgStatoApri(); return; }
  STG.passo = 'intro';
  STG.bozza = { obiettivo: stgObiettivoProposto(), blocchi: {}, di: STG_SPINTA, adhd: false };
  (typeof BS_STAGIONE_DEF !== 'undefined' ? BS_STAGIONE_DEF : []).forEach(function(k){ STG.bozza.blocchi[k] = true; });
  /* 0.9.368, Andrea: "si apre a schermo intero invece di un popover, con un'immagine che non c'entra": popover, e la stessa foto della card */
  stgFoglio(stgPassoHtml(), null, false);
}
/* 0.9.373, Andrea: "tutto al centro, mai un po' a sinistra e un po' al centro; la barra 90/14 anche al passo 1, sopra alle durate;
   Accetto la sfida rosso; Cosa blocchi: i sempre consentiti (come il Full Focus) o una lista di blocco (come i programmi); poi la
   modalita' severa, e le distrazioni di DreamMap in un pannello che si apre; e indietro torna al passo prima, mai chiude il foglio".
   I passi: la sfida, 1 quanto dura, 2 cosa blocchi, 3 modalita' severa, 4 l'obiettivo */
const STG_PASSI = ['intro', 'durata', 'blocco', 'severa', 'obiettivo'];
/* 0.9.374, Andrea: "nella barra i giorni di spinta e di riposo centrati fanno schifo: 2 giorni tocca il bordo e spinta va a capo. Era
   meglio prima, uno a sinistra e l'altro a destra: e' una barra, va contestualizzata". La barra resta solo colore; sotto, la spinta a
   sinistra e il riposo a destra, su una riga */
function stgLineaHtml(b){ const DI = stgDi(b), RI = stgRiposo(DI); return '<div class="stg-linea-w"><div class="stg-linea"><div class="stg-l-spinta" style="flex:' + DI + '"></div><div class="stg-l-riposo" style="flex:' + Math.max(RI * 1.6, 14) + '"></div></div>'
  + '<div class="stg-linea-l"><span><b>' + stgGiorniTxt(DI) + '</b> di spinta</span><span><b>' + RI + '</b> di riposo</span></div></div>'; }
function stgTesta(n){ return '<div class="stg-testa"><button type="button" class="stg-back" onclick="stgIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg></button><small class="stg-eti">Passo ' + n + ' di 4</small></div>'; }
function stgPassoHtml(){
  const b = STG.bozza;
  if (STG.passo === 'intro'){
    const DI = stgDi(b), RI = stgRiposo(DI);
    return '<div class="stg-hero"><img src="img/sfide/spinta.jpg" alt=""><div class="stg-hero-t"><small>Una sfida del Genio</small><h2>La stagione di spinta</h2></div></div>'
      /* 0.9.374, Andrea: "il titolo sulla foto e' a sinistra e il testo sotto e' al centro: si rompe la formattazione". Tutto a sinistra
         come il titolo; il testo dei pulsanti resta al centro (sempre) */
      + '<div class="stg-centro stg-sx"><p class="stg-lead">' + stgGiorniTxt(DI) + ' come se la tua vita dipendesse dal tuo obiettivo. Poi ' + RI + ' di riposo.</p>'
      + stgLineaHtml(b)
      + '<button type="button" class="stg-cta rossa" onclick="stgVai(\'durata\')">Accetto la sfida</button>'
      + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button></div>';
  }
  if (STG.passo === 'durata'){
    return '<div class="stg-centro">' + stgTesta(1) + '<h2 class="stg-h">Quanto dura la spinta?</h2>'
      + stgLineaHtml(b)
      + stgDurataHtml(b)
      + '<p class="stg-nota">Finisce il ' + stgData(stgMezzanotte() + (stgDi(b) - 1) * 86400000) + ', poi ' + stgRiposo(stgDi(b)) + ' di riposo.</p>'
      + '<button type="button" class="stg-cta" onclick="stgVai(\'blocco\')">Avanti</button></div>';
  }
  if (STG.passo === 'blocco'){
    const m = b.modo || 'lista';
    const opz = function(k, ico, t, sub){ return '<button type="button" class="stg-modo' + (m === k ? ' on' : '') + '" onclick="STG.bozza.modo=\'' + k + '\';stgVai(\'blocco\')"><i>' + ico + '</i><span><b>' + t + '</b><small>' + sub + '</small></span></button>'; };
    let nAllow = 0; try{ nAllow = (ffPref().allow || []).length; }catch(_){ }
    return '<div class="stg-centro">' + stgTesta(2) + '<h2 class="stg-h">Cosa blocchi?</h2>'
      + opz('consentiti', '⭐', 'Tutto, tranne i sempre consentiti', 'Come nel Full Focus: si aprono solo le app che consenti tu' + (nAllow ? ' (' + nAllow + ')' : '') + '.')
      + opz('lista', '🛡️', 'Una lista di blocco', 'Come nei programmi: le app che ti distraggono e i social sul web, giorno e notte.')
      + (m === 'consentiti' ? '<button type="button" class="stg-link sotto" onclick="stgConsentiti()">Scegli i sempre consentiti</button>' : '')
      + '<button type="button" class="stg-cta" onclick="stgVai(\'severa\')">Avanti</button></div>';
  }
  if (STG.passo === 'severa'){
    const righe = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).map(function(d){
      const spenta = !!b.blocchi[d.k];
      return '<div class="stg-riga' + (spenta ? ' spenta' : '') + '"><div><b>' + stgEsc(d.n) + '</b><small>' + (spenta ? 'Spenta per ' + stgGiorniTxt(stgDi(b)) : 'Resta accesa') + '</small></div><button type="button" class="switch' + (spenta ? '' : ' on') + '" onclick="stgBloccoCambia(\'' + d.k + '\')" aria-label="' + stgEsc(d.n) + (spenta ? ': spenta' : ': accesa') + '"></button></div>';
    }).join('');
    const sev = !!b.severa;
    return '<div class="stg-centro">' + stgTesta(3) + '<h2 class="stg-h">Accendi la modalità severa?</h2>'
      + '<p class="stg-p">Con la modalità severa i blocchi non si possono togliere fino alla fine della spinta.</p>'
      + '<div class="stg-sn"><button type="button" class="' + (sev ? 'on' : '') + '" onclick="STG.bozza.severa=true;stgVai(\'severa\')">Sì, la accendo</button><button type="button" class="' + (sev ? '' : 'on') + '" onclick="STG.bozza.severa=false;stgVai(\'severa\')">No</button></div>'
      + '<details class="stg-dm"' + (STG.dmAperto ? ' open' : '') + ' ontoggle="STG.dmAperto=this.open"><summary>Le distrazioni dentro DreamMap<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></summary><div class="stg-righe">' + righe + '</div></details>'
      + '<button type="button" class="stg-cta" onclick="stgVai(\'obiettivo\')">Avanti</button></div>';
  }
  /* l'obiettivo */
  return '<div class="stg-centro">' + stgTesta(4) + '<h2 class="stg-h">Per cosa spingi ' + (b.adhd ? 'fino alla scadenza' : 'questi ' + stgGiorniTxt(stgDi(b))) + '?</h2>'
    + '<p class="stg-p">Una cosa sola, quella per cui vale la pena dire di no a tutto il resto.</p>'
    + '<textarea class="stg-area" id="stgObiettivo" rows="3" placeholder="Per esempio: lanciare il negozio online e fare le prime 100 vendite">' + stgEsc(b.obiettivo) + '</textarea>'
    + '<button type="button" class="stg-cta" onclick="stgObiettivoOk()">Comincio oggi la stagione</button></div>';
}
/** Il passo prima (la freccia in alto e il tasto indietro del telefono): dalla sfida si chiude */
function stgIndietro(){
  stgObiettivoTieni();
  const i = STG_PASSI.indexOf(STG.passo);
  if (i <= 0){ stgFoglioChiudi(); return; }
  stgVai(STG_PASSI[i - 1]);
}
function stgConsentiti(){ try{ if (typeof ffAllowOpen === 'function') ffAllowOpen(); }catch(_){ } }
/* la durata: tre durate pronte (90 di partenza) o un numero tuo; la modalita' ADHD mostra scadenze vicine */
function stgDurataHtml(b){
  const lista = b.adhd ? STG_DURATE_ADHD : STG_DURATE, di = stgDi(b);
  const libero = !lista.some(function(x){ return x[0] === di; });
  return '<div class="stg-dur"><p class="stg-dur-k">Quanto dura la spinta</p><div class="stg-dur-l">'
    + lista.map(function(x){ return '<button type="button" class="' + (x[0] === di ? 'on' : '') + '" onclick="stgDurata(' + x[0] + ')">' + x[1] + '</button>'; }).join('')
    + (b.adhd ? '' : '<button type="button" class="' + (libero ? 'on' : '') + '" onclick="stgDurataTua()">' + (libero ? stgGiorniTxt(di) : 'Scegli tu') + '</button>')
    + '</div><button type="button" class="stg-adhd' + (b.adhd ? ' on' : '') + '" onclick="stgAdhd()" aria-pressed="' + !!b.adhd + '"><span><b>Modalità ADHD</b><small>Scadenze vicine e conto alla rovescia in ore, per chi fa fatica a sentire il tempo che passa.</small></span><i class="switch' + (b.adhd ? ' on' : '') + '"></i></button></div>';
}
function stgDurata(n){ if (!STG.bozza) return; STG.bozza.di = n; try{ flVibra(6); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgDurataTua(){
  const v = prompt('Quanti giorni dura la tua spinta? (da 7 a 365)', String(stgDi(STG.bozza)));
  const n = Math.round(+String(v || '').replace(/[^0-9]/g, ''));
  if (n >= 7 && n <= 365) stgDurata(n); else if (v != null) try{ toast('Scegli un numero di giorni fra 7 e 365.'); }catch(_){ }
}
function stgAdhd(){ const b = STG.bozza; if (!b) return; b.adhd = !b.adhd; b.di = b.adhd ? 2 : STG_SPINTA; try{ flVibra(8); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgVai(p){ STG.passo = p; try{ flVibra(6); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgObiettivoTieni(){ const a = document.getElementById('stgObiettivo'); if (a && STG.bozza) STG.bozza.obiettivo = a.value; }
function stgObiettivoOk(){
  const a = document.getElementById('stgObiettivo');
  const t = String(a ? a.value : '').replace(/\s+/g, ' ').trim();
  if (t.length < 4){ try{ toast('Scrivi il tuo obiettivo, anche in poche parole.'); }catch(_){ } return; }
  STG.bozza.obiettivo = t; stgComincia();
}
function stgBloccoCambia(k){
  STG.bozza.blocchi[k] = !STG.bozza.blocchi[k];
  const c = document.querySelector('#stgVelo .stg-fin'), y = c ? c.scrollTop : 0;
  stgFoglioCorpo(stgPassoHtml());
  if (c) c.scrollTop = y;
}
function stgComincia(){
  const b = STG.bozza; if (!b || !b.obiettivo) return;
  const DI = stgDi(b);
  stgScriviJ(STG_KEY, { inizio: stgMezzanotte(), at: Date.now(), obiettivo: b.obiettivo, blocchi: b.blocchi, bilancio: null, di: DI, adhd: !!b.adhd, modo: b.modo || 'dreammap' });
  if (b.modo === 'consentiti') stgConsentitiArma(DI); else stgProgrammaCrea(DI);
  /* la modalita' severa si accende dalla sua pagina (il motore chiede la conferma) */
  if (b.severa) setTimeout(function(){ try{ stgFoglioChiudi(); if (typeof sevProntoApri === 'function') sevProntoApri(); else if (typeof sevOpenStatus === 'function') sevOpenStatus(); }catch(_){ } }, 1600);
  /* la stagione e' la prima slide della scheda Sogno: lo slideshow si rifa' */
  try{ const h = document.getElementById('nvHero'); if (h) h.remove(); if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
  try{ flVibra([20, 40, 30]); }catch(_){ }
  stgFoglioCorpo('<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small><h2 class="stg-h">' + (b.adhd ? 'Hai ' + stgOreTxt(stgMezzanotte() + DI * 86400000 - Date.now()) : 'Giorno 1 di ' + DI) + '</h2>'
    + '<p class="stg-p">Da adesso conta una cosa sola, "' + stgEsc(b.obiettivo) + '". Le sezioni che distraggono sono spente fino al ' + stgData(stgMezzanotte() + (DI - 1) * 86400000) + '.</p>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Andiamo</button>');
  stgAggiorna();
}
function stgAggiorna(){
  try{ if (typeof bsControlla === 'function') bsControlla(true); }catch(_){ }
  stgPaint();
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   DURANTE: lo stato, e l'uscita (che costa una conferma scritta)
   --------------------------------------------------------------------------------------- */
function stgSpenteTxt(st){
  const l = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).filter(function(d){ return st.blocchi[d.k]; }).map(function(d){ return d.n; });
  return l.length ? l.join(', ') : 'Nessuna sezione';
}
function stgStatoApri(){
  const st = flStagioneAttiva(); if (!st) return;
  const pct = Math.round(st.giorno / st.di * 100);
  stgFoglio('<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small><h2 class="stg-h">' + (st.adhd ? 'Mancano ' + stgOreTxt(st.fineSpinta - Date.now()) : 'Giorno ' + st.giorno + ' di ' + st.di) + '</h2>'
    + '<div class="stg-barra"><i style="width:' + pct + '%"></i></div>'
    + '<div class="stg-ob"><small>Il tuo obiettivo</small><b>' + stgEsc(st.obiettivo) + '</b></div>'
    + '<p class="stg-p">Restano spenti: ' + stgEsc(stgSpenteTxt(st)) + '. Il riposo comincia il ' + stgData(st.fineSpinta) + '.</p>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Torno a spingere</button>'
    + '<button type="button" class="stg-link" onclick="stgInterrompiChiedi()">Interrompi la stagione</button>', null, true);

}
function stgInterrompiChiedi(){
  stgFoglioCorpo('<small class="stg-eti">Interrompere la stagione</small><h2 class="stg-h">Sei sicuro di fermarti?</h2>'
    + '<p class="stg-p">La stagione finisce adesso, le sezioni si riaprono e i giorni fatti restano nella tua storia. Per confermare scrivi la parola MI FERMO.</p>'
    + '<input class="stg-in" id="stgFermo" autocomplete="off" placeholder="MI FERMO">'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Continuo la stagione</button>'
    + '<button type="button" class="stg-link" onclick="stgInterrompi()">Interrompi adesso</button>');
}
function stgInterrompi(){
  const i = document.getElementById('stgFermo');
  if (!i || String(i.value || '').trim().toUpperCase() !== 'MI FERMO'){ try{ toast('Per interrompere scrivi MI FERMO.'); }catch(_){ } return; }
  const s = stgCorrente(); if (s) stgArchivia(s, true);
  stgFoglioChiudi(); stgAggiorna();
  try{ toast('Stagione interrotta. Le sezioni sono di nuovo aperte.'); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   IL RIPOSO E IL BILANCIO (i 14 giorni dopo la spinta)
   --------------------------------------------------------------------------------------- */
function stgNumeri(st){
  const out = { sessioni: 0, minuti: 0, revisioni: 0 };
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (x && x.ok && !x.meditazione && x.at >= st.inizio && x.at < st.fineSpinta){ out.sessioni++; out.minuti += Math.round((x.spentMs || 0) / 60000); }
    });
  }catch(_){ }
  try{ (JSON.parse(localStorage.getItem('fl_revisioni') || '[]') || []).forEach(function(x){ const t = new Date(x.giorno + 'T12:00:00').getTime(); if (t >= st.inizio && t < st.fineSpinta) out.revisioni++; }); }catch(_){ }
  return out;
}
const STG_VICINO = ['Per niente', 'Poco', 'Abbastanza', 'Molto', 'Ce l’ho fatta'];
function stgBilancioApri(){
  const st = flStagioneAttiva(); if (!st || st.fase !== 'reset') return;
  STG.bil = Object.assign({ ottenuto: '', vicino: 0, tengo: '', cambio: '' }, st.bilancio || {});
  stgFoglio(stgBilancioHtml(st), null, true);
}
function stgBilancioHtml(st){
  const b = STG.bil, n = stgNumeri(st);
  const ore = Math.floor(n.minuti / 60);
  return '<div class="stg-ico">' + STG_I.luna + '</div><small class="stg-eti">Il riposo: giorno ' + st.giorno + ' di ' + st.di + '</small>'
    + '<h2 class="stg-h">Il bilancio della stagione</h2>'
    + '<div class="stg-ob"><small>L’obiettivo dei 90 giorni</small><b>' + stgEsc(st.obiettivo) + '</b></div>'
    + '<div class="stg-num"><div><b>' + n.sessioni + '</b><small>sessioni di Full Focus finite</small></div><div><b>' + ore + '</b><small>' + (ore === 1 ? 'ora di lavoro profondo' : 'ore di lavoro profondo') + '</small></div><div><b>' + n.revisioni + '</b><small>sere con la revisione</small></div></div>'
    + '<label class="stg-q">Cosa hai ottenuto in questi 90 giorni?</label><textarea class="stg-area" id="stgB1" rows="3">' + stgEsc(b.ottenuto) + '</textarea>'
    + '<label class="stg-q">Quanto ti sei avvicinato al tuo obiettivo?</label><div class="stg-chips">' + STG_VICINO.map(function(t, i){ return '<button type="button" class="stg-chip' + (b.vicino === i + 1 ? ' on' : '') + '" onclick="stgVicino(' + (i + 1) + ')">' + t + '</button>'; }).join('') + '</div>'
    + '<label class="stg-q">Cosa tieni per la prossima stagione?</label><textarea class="stg-area" id="stgB2" rows="2">' + stgEsc(b.tengo) + '</textarea>'
    + '<label class="stg-q">Cosa cambi?</label><textarea class="stg-area" id="stgB3" rows="2">' + stgEsc(b.cambio) + '</textarea>'
    + '<button type="button" class="stg-cta" onclick="stgBilancioSalva()">Salvo il bilancio</button>'
    + '<p class="stg-nota">Il riposo finisce il ' + stgData(st.fineReset - 86400000) + '. Poi puoi cominciare una stagione nuova.</p>';
}
function stgBilancioLeggiCampi(){
  const v = function(id){ const e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; };
  STG.bil.ottenuto = v('stgB1'); STG.bil.tengo = v('stgB2'); STG.bil.cambio = v('stgB3');
}
function stgVicino(i){ stgBilancioLeggiCampi(); STG.bil.vicino = i; const st = flStagioneAttiva(); if (st) stgFoglioCorpo(stgBilancioHtml(st)); }
function stgBilancioSalva(){
  stgBilancioLeggiCampi();
  if (!STG.bil.ottenuto){ try{ toast('Scrivi almeno cosa hai ottenuto.'); }catch(_){ } return; }
  const s = stgCorrente(); if (!s) return;
  s.bilancio = Object.assign({}, STG.bil, { at: Date.now() });
  stgScriviJ(STG_KEY, s);
  stgFoglioChiudi(); stgPaint();
  try{ toast('Bilancio salvato. Adesso riposa davvero.'); }catch(_){ }
}
/** Per il tuo agente personale: a che punto e' la stagione. */
function stgPerAgente(){
  const st = flStagioneAttiva(); if (!st) return '';
  return st.fase === 'spinta'
    ? 'Stagione di spinta (Monk mode, 90 giorni): giorno ' + st.giorno + ' di 90, obiettivo "' + st.obiettivo + '". Niente distrazioni.'
    : 'Riposo dopo la stagione di spinta: giorno ' + st.giorno + ' di 14. ' + (st.bilancio ? 'Bilancio: ottenuto "' + st.bilancio.ottenuto + '", cambia "' + (st.bilancio.cambio || '') + '".' : 'Bilancio ancora da fare.');
}

/* ---------------------------------------------------------------------------------------
   LE PORTE: la card nella Mappa (vista Roadmap) e la prima card delle Sfide di Dream
   --------------------------------------------------------------------------------------- */
function stgCardHtml(){
  const st = flStagioneAttiva();
  /* 0.9.275, Andrea: non una sezione della Roadmap ma una sfida, una proposta del gioco. Finche' non e'
     cominciata vive come tappa della mappa (sentiero-mappa.js, nodo "stg") e come card delle Sfide di
     Dream; qui compare solo il contatore, mentre la stagione e' in corso. */
  if (!st) return '';
  if (st.fase === 'spinta'){
    const pct = Math.round(st.giorno / st.di * 100);
    return '<div class="stg-card on" onclick="stgStatoApri()" role="button"><span class="stg-c-ico">' + STG_I.monte + '</span><div><small>La stagione di spinta</small>'
      + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><div class="stg-barra"><i style="width:' + pct + '%"></i></div><i>' + stgEsc(st.obiettivo) + '</i></div>' + STG_I.avanti + '</div>';
  }
  return '<div class="stg-card riposo" onclick="stgBilancioApri()" role="button"><span class="stg-c-ico">' + STG_I.luna + '</span><div><small>Il riposo dopo la stagione</small>'
    + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><i>' + (st.bilancio ? 'Bilancio fatto. Rileggilo quando vuoi.' : 'Fai il bilancio dei 90 giorni.') + '</i></div>' + STG_I.avanti + '</div>';
}
function stgPaint(){
  if (typeof document === 'undefined') return;
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  const rif = document.getElementById('mppPianoRm') || document.getElementById('mppSentiero');
  if (!rif || !rif.parentNode) return;
  let h = document.getElementById('mppStagione');
  if (!h){ h = document.createElement('div'); h.id = 'mppStagione'; h.className = 'mpp-slot'; }
  if (rif.nextElementSibling !== h) rif.parentNode.insertBefore(h, rif.nextSibling);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  /* 0.9.288, Andrea: "dopo averla accettata il pannello della stagione non compare piu' nella Mappa": si nascondeva
     nella vista "Pianifica tu". La stagione vale per tutte e due le strade. */
  h.classList.remove('mpp-via');
  const html = stgCardHtml();
  if (h.dataset.html !== html){ h.dataset.html = html; h.innerHTML = html; }
}
/** La card per il carosello delle Sfide (sfide-dream.js), finche' la stagione non e' cominciata. */
function stgSfidaCard(){
  if (flStagioneAttiva()) return null;
  return { k: 'stagione', ico: '🏔️', img: 'img/sfide/spinta.jpg', t: 'La stagione di spinta',
    s: '90 giorni come se la tua vita dipendesse dal tuo obiettivo: niente distrazioni dentro DreamMap. Poi 14 giorni di riposo e il bilancio.',
    meta: '90 giorni', fatta: false, via: 'stgApri()' };
}

if (typeof document !== 'undefined'){
  (function(){
    if (typeof rmpPaint === 'function' && !rmpPaint.__stg){ const v = rmpPaint; const w = function(){ const r = v.apply(this, arguments); try{ stgPaint(); }catch(_){ } return r; }; w.__stg = true; window.rmpPaint = w; }
    if (typeof rnPerAgente === 'function' && !rnPerAgente.__stg){ const v2 = rnPerAgente; const w2 = function(){ return [v2.apply(this, arguments), stgPerAgente()].filter(Boolean).join(' '); }; w2.__stg = true; window.rnPerAgente = w2; }
  })();
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(stgPaint, 120); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(stgPaint, 600); });
  setTimeout(stgPaint, 1500);
  setInterval(stgPaint, 60000);
  (function(){
    const st = document.createElement('style');
    st.textContent = [
      '#mppStagione{padding:0 16px;margin:10px 0 12px}#mppStagione:empty{display:none}',
      '.stg-card{display:flex;align-items:center;gap:12px;padding:15px 16px;border-radius:20px;background:linear-gradient(135deg,#0075E3,#005BB0);color:#FFFFFF;cursor:pointer;box-shadow:0 10px 24px rgba(0,91,176,.22)}',
      '.stg-card > div{flex:1;min-width:0}.stg-card > svg{flex:none;opacity:.85}.stg-c-ico{flex:none;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:rgba(255,255,255,.16);color:#FFFFFF}',
      '.stg-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#BCE0FF}',
      '.stg-card b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}',
      '.stg-card i{display:block;margin-top:4px;font:600 12.5px/1.4 var(--font-body);font-style:normal;color:#D2ECFF;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.stg-card.riposo{background:linear-gradient(135deg,#3F9FF4,#0075E3)}',
      '.stg-barra{height:8px;border-radius:8px;background:var(--blue-soft,#E3F1FF);overflow:hidden;margin:8px 0 12px}.stg-card .stg-barra{background:rgba(255,255,255,.22);margin:8px 0 0}.stg-barra i{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,#0075E3,#3F9FF4);margin:0}.stg-card .stg-barra i{background:#FFFFFF}',
      '.stg-velo{position:fixed;inset:0;z-index:10040;display:flex;align-items:flex-end;justify-content:center}',
      '.stg-scrim{position:absolute;inset:0;background:rgba(0,30,68,.55)}',
      '.stg-f{position:relative;width:100%;max-width:520px;max-height:92vh;border-radius:26px 26px 0 0;background:var(--card,#FFFFFF);color:var(--ink,#0A1A2F);box-shadow:0 -10px 40px rgba(0,30,68,.28);display:flex;flex-direction:column;overflow:hidden}',
      '.stg-fin{overflow:auto;padding:24px 20px calc(24px + env(safe-area-inset-bottom))}',
      '.stg-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.35);color:#FFFFFF;display:grid;place-items:center;z-index:3;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}',
      '.stg-hero{position:relative;margin:-24px -20px 16px;height:178px;overflow:hidden}.stg-hero img{width:100%;height:100%;object-fit:cover;display:block}',
      '.stg-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 30%,rgba(0,30,68,.78))}',
      '.stg-hero-t{position:absolute;left:20px;right:20px;bottom:14px;z-index:1;color:#FFFFFF}.stg-hero-t small{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#BCE0FF}.stg-hero-t h2{margin:2px 0 0;font:900 26px/1.15 var(--font-display,var(--font-body))}',
      '.stg-lead{margin:0 0 14px;font:700 17px/1.45 var(--font-body);color:var(--navy,#001E44)}',
      '.stg-linea{display:flex;gap:4px;height:46px;border-radius:14px;overflow:hidden;margin:0 0 6px}.stg-linea > div{display:flex;flex-direction:column;justify-content:center;padding:0 12px;color:#FFFFFF}.stg-linea b{font:800 15px/1.1 var(--font-body)}.stg-linea small{font:600 11.5px var(--font-body);opacity:.9}',
      '.stg-l-spinta{flex:90;background:linear-gradient(90deg,#0075E3,#3F9FF4)}.stg-l-riposo{flex:24;background:var(--dream);color:#0E2350!important}.stg-l-riposo b,.stg-l-riposo small{color:#0E2350}',
      '.stg-date{display:flex;justify-content:space-between;margin:0 0 14px;font:600 12px var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-punti{list-style:none;margin:0 0 6px;padding:0;display:grid;gap:10px}.stg-punti li{display:flex;align-items:center;gap:12px;font:500 15px/1.45 var(--font-body);color:var(--ink,#0A1A2F)}.stg-punti b{color:#0075E3}',
      '.stg-punti i{flex:none;width:36px;height:36px;border-radius:12px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;font-style:normal;font-size:17px}',
      '.stg-ico{width:58px;height:58px;border-radius:18px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;margin-bottom:12px}',
      '.stg-eti{display:block;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}',
      '.stg-h{margin:6px 40px 10px 0;font:800 24px/1.25 var(--font-display,var(--font-body));color:var(--navy,#001E44)}',
      '.stg-p{margin:0 0 14px;font:500 16px/1.55 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-nota{margin:12px 0 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-tappe{display:grid;gap:10px;margin:6px 0 14px}.stg-tappe > div{padding:14px;border-radius:16px;background:var(--blue-soft,#E3F1FF)}.stg-tappe b{display:block;font:800 16px var(--font-body);color:#0075E3}.stg-tappe p{margin:4px 0 0;font:500 15px/1.5 var(--font-body);color:var(--ink,#0A1A2F)}',
      '.stg-cta{display:block;width:100%;margin-top:14px;padding:16px;border:0;border-radius:999px;background:#0075E3;color:#FFFFFF;font:800 17px var(--font-body);box-shadow:0 8px 20px rgba(0,117,227,.28)}',
      '.stg-link{display:block;width:100%;margin-top:6px;padding:12px;border:0;background:none;color:var(--muted,#4A5A72);font:700 15px var(--font-body)}',
      '.stg-area,.stg-in{display:block;width:100%;box-sizing:border-box;padding:14px;border-radius:14px;border:1.5px solid var(--line,#DCE8F5);background:var(--bg,#F4F9FF);color:var(--ink,#0A1A2F);font:500 16px/1.5 var(--font-body);resize:vertical}',
      '.stg-area::placeholder,.stg-in::placeholder{color:var(--faint,#8B99AC)}',
      '.stg-righe{display:grid;gap:12px;margin:0 0 28px}.stg-riga{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);border:1.5px solid var(--line,#DCE8F5)}.stg-riga > div{flex:1;min-width:0}',
      '.stg-riga b{display:block;font:700 15px/1.35 var(--font-body);color:var(--ink,#0A1A2F)}.stg-riga small{display:block;margin-top:2px;font:500 13px/1.4 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-ob{padding:16px 18px;border-radius:16px;background:var(--dream);margin:0 0 28px}.stg-ob small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#005BB0}.stg-ob b{display:block;margin-top:4px;font:700 16px/1.4 var(--font-body);color:#0E2350}',
      '.stg-num{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:4px 0 12px}.stg-num > div{padding:12px 8px;border-radius:14px;background:var(--blue-soft,#E3F1FF);text-align:center}.stg-num b{display:block;font:800 24px var(--font-body);color:#0075E3}.stg-num small{display:block;margin-top:2px;font:600 12px/1.3 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-q{display:block;margin:14px 0 6px;font:700 15.5px/1.4 var(--font-body);color:var(--navy,#001E44)}',
      /* 0.9.276, Andrea: "tutto ammassato, nessuna distanza fra un elemento e l'altro: piuttosto una pagina a schermo
         intero". La stagione e' una pagina intera, con lo spazio della skill ui-scansionabile (16/24/32 px). */
      '.stg-pagina{align-items:stretch}.stg-pagina .stg-scrim{display:none}.stg-pagina .stg-f{max-width:none;max-height:none;height:100%;border-radius:0}',
      '.stg-pagina .stg-fin{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:24px 24px calc(28px + env(safe-area-inset-bottom))}',
      /* 0.9.288, Andrea: "la barra 90/14 tagliata, l'intestazione tagliata, Non adesso in bella vista". La colonna era alta
         quanto lo schermo e schiacciava i suoi figli invece di scorrere: adesso nessuno si schiaccia, la foto in cima e'
         grande e i pulsanti si trovano scorrendo. */
      '.stg-pagina .stg-fin > *{flex-shrink:0}',
      '.stg-pagina .stg-hero{height:clamp(300px,50vh,440px)!important}',
      '.stg-pagina .stg-linea{height:auto!important;min-height:58px}.stg-linea > div{padding:8px 12px}',
      '.stg-riga.spenta b{color:var(--muted,#4A5A72)}.stg-riga.spenta small{color:#E5484D;font-weight:700}',
      '.stg-area{min-height:110px}.stg-area:focus{outline:none;border-color:#0075E3}body.dark .stg-area:focus{border-color:#3F9FF4}',
      '.stg-pagina .stg-hero{margin:-24px -24px 28px;height:clamp(200px,32vh,280px)}.stg-pagina .stg-hero-t{left:24px;right:24px;bottom:20px}.stg-pagina .stg-hero-t h2{font-size:30px;margin-top:6px}',
      '.stg-pagina .stg-lead{margin:0 0 28px;font-size:18px;line-height:1.5}',
      '.stg-pagina .stg-linea{height:54px;margin:0 0 10px}.stg-pagina .stg-date{margin:0 0 36px}',
      '.stg-pagina .stg-punti{gap:22px;margin:0 0 40px}.stg-pagina .stg-punti li{gap:16px;font-size:16px}.stg-pagina .stg-punti i{width:44px;height:44px;border-radius:14px}',
      '.stg-pagina .stg-cta{margin-top:auto}.stg-pagina .stg-link{margin-top:12px}',
      '.stg-pagina .stg-h{margin:10px 0 16px;font-size:26px}.stg-pagina .stg-p{margin:0 0 24px}.stg-pagina .stg-eti{margin-top:8px}',
      '.stg-pagina .stg-area,.stg-pagina .stg-righe,.stg-pagina .stg-ob,.stg-pagina .stg-barra{margin-bottom:28px}',
      /* 0.9.277, Andrea: "il margine e' inesistente nel popover". Bordi del foglio 28px, titolo staccato, pulsante con aria. */
      '.stg-fin{padding:32px 28px calc(28px + env(safe-area-inset-bottom))}',
      /* 0.9.372, Andrea: "l'immagine in cima al popover ha un margine ai lati e sopra: deve toccare i bordi" */
      '.stg-velo:not(.stg-pagina) .stg-hero{margin:-32px -28px 24px!important;height:200px}',
      '.stg-dur-k{display:none}.stg-dur{margin-bottom:8px}',
      'body.dark .stg-f .stg-dur-l button.on{background:#E63946!important;border-color:#E63946!important;color:#fff!important}',
      '.stg-modo{display:flex;align-items:center;gap:14px;width:100%;margin:0 0 14px;padding:16px;border-radius:18px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);text-align:left;cursor:pointer}.stg-modo i{flex:none;width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);font-style:normal;font-size:22px}.stg-modo b{display:block;font:800 16px var(--font-body);color:var(--navy,#001E44)}.stg-modo small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#4A5A72)}.stg-modo.on{border-color:#0075E3;box-shadow:inset 0 0 0 1.5px #0075E3}body.dark .stg-modo{background:#12203A;border-color:#22345A}body.dark .stg-modo b{color:#fff}',
      '.stg-h{margin:12px 48px 28px 0}.stg-p{margin:0 0 24px}.stg-cta{margin-top:36px}.stg-q{margin:24px 0 12px}.stg-chips{gap:10px}',
      '.stg-chips{display:flex;flex-wrap:wrap;gap:8px}.stg-chip{padding:10px 14px;border-radius:999px;border:1.5px solid var(--line,#DCE8F5);background:transparent;color:var(--ink,#0A1A2F);font:700 14.5px var(--font-body)}.stg-chip.on{background:#0075E3;border-color:#0075E3;color:#FFFFFF}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { flStagioneAttiva: flStagioneAttiva, stgArchivia: stgArchivia, STG_SPINTA: STG_SPINTA, STG_RESET: STG_RESET };
}

/* 0.9.363, Andrea: "la stagione di spinta, COME SE LA TUA VITA DIPENDESSE DA QUESTO, deve essere la prima slide dello slideshow
   della scheda Sogno: e' un evento importante". Solo durante la spinta. */
/* 0.9.373, Andrea: "con la stagione di spinta la scadenza e' piu' importante di qualunque altra data: e' la prima slide della scheda Sogno" */
function stgHeroSlideHtml(){
  let st = null; try{ st = flStagioneAttiva(); }catch(_){ st = null; }
  if (!st || st.fase !== 'spinta') return '';
  const giorni = Math.max(0, Math.ceil((st.fineSpinta - Date.now()) / 86400000));
  return '<article class="bh-slide stg-hs" data-i="8" style="--bh-img:url(\'img/sfide/spinta.jpg\');--bh-pos:center 40%"><div class="bh-img"></div><span class="bh-ov"></span>'
    + '<div class="bh-stack stg-hs-in"><small>Come se la tua vita dipendesse da questo</small><b>' + stgEsc(st.obiettivo) + '</b>'
    + '<em>' + (st.adhd ? 'Mancano ' + stgOreTxt(st.fineSpinta - Date.now()) : (giorni === 1 ? 'Manca 1 giorno' : 'Mancano ' + giorni + ' giorni')) + '</em><span>Scadenza: ' + stgData(st.fineSpinta - 86400000) + '</span>'
    + '<button type="button" class="stg-cta rossa" onclick="stgStatoApri()">Vai alla stagione</button></div></article>';
}
function stgSlideHtml(){
  let st = null; try{ st = flStagioneAttiva(); }catch(_){ st = null; }
  if (!st || st.fase !== 'spinta') return '';
  const resta = st.fineSpinta - Date.now();
  const conta = st.adhd ? 'Mancano ' + stgOreTxt(resta) : 'Giorno ' + st.giorno + ' di ' + st.di;
  return '<div class="stg-sl"><small class="stg-sl-k">Come se la tua vita dipendesse da questo</small>'
    + '<b class="stg-sl-ob">' + stgEsc(st.obiettivo) + '</b>'
    + '<div class="stg-sl-c"><span>' + conta + '</span><div class="stg-barra"><i style="width:' + Math.round(st.giorno / st.di * 100) + '%"></i></div></div>'
    + '<button type="button" class="stg-cta stg-sl-go" onclick="stgStatoApri()">' + (st.adhd ? 'Fai la cosa di adesso' : 'Vai alla stagione') + '</button></div>';
}
(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    /* 0.9.368, Andrea: "i pulsanti della durata e la riga della modalita' ADHD bianchi su bianco": il foglio e' chiaro, i colori seguono il tema */
    '.stg-f .stg-dur-l button{border-color:#C8EFFD!important;background:#F0FBFF!important;color:#001E44!important}.stg-f .stg-dur-l button.on{background:#E63946!important;border-color:#E63946!important;color:#fff!important}',
    'body.dark .stg-f .stg-dur-l button{background:#0E1D3D!important;border-color:#1F3A66!important;color:#fff!important}',
    '.stg-f .stg-adhd{border-color:#C8EFFD!important;background:#F0FBFF!important;color:#001E44!important}.stg-f .stg-adhd small{color:#3F5A7A!important}.stg-f .stg-dur-k{color:#0075E3!important}',
    'body.dark .stg-f .stg-adhd{background:#0E1D3D!important;border-color:#1F3A66!important;color:#fff!important}body.dark .stg-f .stg-adhd small{color:#BFD3EC!important}body.dark .stg-f .stg-dur-k{color:#8CC6FF!important}',
    '.stg-dur{margin:22px 0 26px;text-align:left}.stg-dur-k{margin:0 0 10px;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF;text-align:center}',
    '.stg-dur-l{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.stg-dur-l button{border:1.5px solid rgba(188,224,255,.35);background:rgba(255,255,255,.06);color:#fff;padding:9px 14px;border-radius:99px;font:700 14px var(--font-body);cursor:pointer}.stg-dur-l button.on{background:#E63946;border-color:#E63946}',
    '.stg-adhd{display:flex;align-items:center;gap:14px;width:100%;margin-top:16px;padding:14px 16px;border-radius:16px;border:1px solid rgba(188,224,255,.25);background:rgba(255,255,255,.05);color:#fff;text-align:left;cursor:pointer}.stg-adhd span{flex:1;min-width:0}.stg-adhd b{display:block;font:800 15px var(--font-body)}.stg-adhd small{display:block;margin-top:4px;font:500 13px/1.4 var(--font-body);color:#BFD3EC}.stg-adhd .switch{flex:none;pointer-events:none}',
    '.stg-centro{display:flex;flex-direction:column;align-items:center;text-align:center}.stg-centro > *{align-self:stretch}.stg-centro .stg-h,.stg-centro .stg-p,.stg-centro .stg-nota,.stg-centro .stg-lead{text-align:center;margin-left:0!important;margin-right:0!important}',
    '.stg-cta.rossa{background:#E63946!important;box-shadow:0 8px 20px rgba(230,57,70,.3)!important}',
    '.stg-testa{position:relative;display:flex;align-items:center;justify-content:center;min-height:40px;margin:0 0 6px}.stg-back{position:absolute;left:0;top:0;width:40px;height:40px;border-radius:50%;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);color:var(--navy,#001E44);display:grid;place-items:center;cursor:pointer}body.dark .stg-back{background:#12203A;border-color:#22345A;color:#fff}',
    '.stg-centro .stg-linea{margin:4px 0 22px}.stg-centro .stg-dur{margin-top:0}',
    '.stg-linea-w{margin:4px 0 24px}.stg-linea-w .stg-linea,.stg-centro .stg-linea-w .stg-linea,.stg-pagina .stg-linea-w .stg-linea{height:16px!important;min-height:0!important;margin:0!important;border-radius:99px}.stg-linea-w .stg-linea > div{padding:0!important}',
    '.stg-linea-l{display:flex;justify-content:space-between;gap:12px;margin-top:10px;font:600 13.5px var(--font-body);color:var(--muted,#4A5A72)}.stg-linea-l span:first-child{text-align:left}.stg-linea-l span:last-child{text-align:right}.stg-linea-l b{font-weight:800;color:var(--navy,#001E44)}body.dark .stg-linea-l b{color:#fff}',
    '.stg-centro.stg-sx,.stg-centro.stg-sx .stg-lead{text-align:left!important}.stg-centro.stg-sx .stg-cta,.stg-centro.stg-sx .stg-link{text-align:center}',
    '.stg-sn{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:4px 0 22px}.stg-sn button{padding:14px;border-radius:16px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);font:800 15px var(--font-body);color:var(--navy,#001E44);cursor:pointer}.stg-sn button.on{border-color:#0075E3;background:#0075E3;color:#fff}body.dark .stg-sn button{background:#12203A;border-color:#22345A;color:#fff}body.dark .stg-sn button.on{background:#0075E3;border-color:#0075E3}',
    '.stg-dm{border:1.5px solid var(--line,#DCE8F5);border-radius:16px;text-align:left}.stg-dm summary{list-style:none;display:flex;align-items:center;justify-content:center;gap:8px;padding:14px;font:800 15px var(--font-body);color:var(--navy,#001E44);cursor:pointer}.stg-dm summary::-webkit-details-marker{display:none}.stg-dm[open] summary svg{transform:rotate(180deg)}.stg-dm .stg-righe{padding:0 12px 12px;margin:0}body.dark .stg-dm{border-color:#22345A}body.dark .stg-dm summary{color:#fff}',
    '.stg-link.sotto{margin-top:-4px;color:#0075E3;text-decoration:underline;text-underline-offset:3px}body.dark .stg-link.sotto{color:#8CC6FF}',
    '.stg-hs-in{display:flex;flex-direction:column;align-items:center;text-align:center;padding:60px 24px 70px;color:#fff}.stg-hs-in small{font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#FF8A9B}.stg-hs-in b{margin:14px 0 18px;font:800 23px/1.3 var(--font-display)}.stg-hs-in em{font:900 34px var(--font-display);font-style:normal}.stg-hs-in span{margin:6px 0 26px;font:700 14px var(--font-body);color:#BCE0FF}.stg-hs-in .stg-cta{width:auto;padding:14px 28px}',
    '.stg-sl{display:flex;flex-direction:column;align-items:center;text-align:center;padding:26px 20px 22px;border-radius:22px;background:linear-gradient(180deg,#001E44 0%,#0B2A5C 100%);color:#fff}',
    '.stg-sl-k{font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#FF8A9B}.stg-sl-ob{display:block;margin:14px 0 22px;font:800 21px/1.3 var(--font-display);color:#fff}',
    '.stg-sl-c{width:100%;margin-bottom:28px}.stg-sl-c span{display:block;margin-bottom:10px;font:800 15px var(--font-body);color:#BCE0FF}.stg-sl-go{margin:0!important;width:100%}'
  ].join('\n');
  document.head.appendChild(st);
})();
