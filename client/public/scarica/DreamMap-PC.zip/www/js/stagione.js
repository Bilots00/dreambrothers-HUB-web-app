/* ===========================================================================================
   LA STAGIONE DI SPINTA (0.9.242): il Monk mode di Davie Fogarty

   Novanta giorni come se la tua vita dipendesse dall'obiettivo, poi due settimane di riposo e
   il bilancio. Si sceglie (opt-in), da una porta chiara: la vista Roadmap della Mappa e la prima
   card delle Sfide di Dream. Mentre dura la spinta le sezioni che distraggono restano spente
   (blocchi-sezioni.js: giochi del Genio, Academy, respiro, Consigliato per te, sfide, Lega);
   il respiro e i consigli si riaprono solo nei giorni con l'umore basso.

   I DATI: fl_stagione = { inizio (mezzanotte del primo giorno), obiettivo, blocchi { k: true },
   bilancio, interrotta } e fl_stagione_storia = [stagioni finite]. Entrano nel backup da soli
   (profile.js prende tutte le chiavi fl_).

   PER DREAM: flStagioneAttiva() restituisce { fase: 'spinta'|'reset', giorno, di, obiettivo,
   inizio, fineSpinta, fineReset, blocchi, bilancio } oppure null. Ci si puo' appoggiare una card.
   (Il "Monk Mode" degli scrigni, trenta giorni e quindici ore a settimana, e' un'altra cosa e
   resta com'e'.)
   =========================================================================================== */
const STG_KEY = 'fl_stagione';
const STG_STORIA_KEY = 'fl_stagione_storia';
const STG_SPINTA = 90;
const STG_RESET = 14;
const STG = { passo: 'intro', bozza: null, bil: null };

function stgLeggiJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function stgScriviJ(k, v){ try{ if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function stgEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function stgMezzanotte(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
function stgGiorniDa(inizio, adesso){ return Math.round((stgMezzanotte(adesso) - stgMezzanotte(inizio)) / 86400000) + 1; }
function stgData(ms){ const d = new Date(ms); const m = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']; return d.getDate() + ' ' + m[d.getMonth()]; }

function stgCorrente(){ const s = stgLeggiJ(STG_KEY, null); return s && s.inizio ? s : null; }

/** Lo stato della stagione adesso, o null se non c'e' (o e' finita: allora passa nella storia). */
function flStagioneAttiva(adesso){
  const s = stgCorrente(); if (!s) return null;
  const g = stgGiorniDa(s.inizio, adesso);
  const fineSpinta = stgMezzanotte(s.inizio) + STG_SPINTA * 86400000;
  const fineReset = fineSpinta + STG_RESET * 86400000;
  if (g < 1) return null;
  if (g > STG_SPINTA + STG_RESET){ stgArchivia(s, false); return null; }
  const spinta = g <= STG_SPINTA;
  return { fase: spinta ? 'spinta' : 'reset', giorno: spinta ? g : g - STG_SPINTA, di: spinta ? STG_SPINTA : STG_RESET,
           giornoTot: g, obiettivo: s.obiettivo || '', inizio: s.inizio, fineSpinta: fineSpinta, fineReset: fineReset,
           blocchi: s.blocchi || {}, bilancio: s.bilancio || null };
}
function stgArchivia(s, interrotta){
  const l = stgLeggiJ(STG_STORIA_KEY, []) || [];
  l.push(Object.assign({}, s, { chiusa: Date.now(), interrotta: !!interrotta }));
  stgScriviJ(STG_STORIA_KEY, l.slice(-20));
  stgScriviJ(STG_KEY, null);
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO (usato anche da prenota.js e piano-settimana.js): un velo con una card blu notte
   --------------------------------------------------------------------------------------- */
function stgFoglio(html, id, intera){
  { const v0 = document.getElementById('stgVelo'); if (v0) v0.remove(); }
  const v = document.createElement('div');
  v.id = 'stgVelo'; v.className = 'stg-velo' + (intera ? ' stg-pagina' : '');
  v.innerHTML = '<div class="stg-scrim" onclick="stgFoglioChiudi()"></div><div class="stg-f" role="dialog" aria-modal="true"' + (id ? ' id="' + id + '"' : '') + '>'
    + '<button type="button" class="stg-x" onclick="stgFoglioChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'
    + '<div class="stg-fin">' + html + '</div></div>';
  (document.getElementById('phone') || document.body).appendChild(v);
  return v;
}
function stgFoglioCorpo(html){ const c = document.querySelector('#stgVelo .stg-fin'); if (c){ c.innerHTML = html; c.scrollTop = 0; } }
function stgFoglioChiudi(){
  const v = document.getElementById('stgVelo'); if (v) v.remove();
  /* aperto dalla tappa della mappa: chiuso il foglio, la tappa si chiude (accettata o rimandata) */
  if (STG.daMappa){ STG.daMappa = false; setTimeout(function(){ try{ sdAggiorna(true); sdPaint(); }catch(_){ } }, 200); }
}
function stgBack(){ if (document.getElementById('stgVelo')){ stgFoglioChiudi(); return true; } return false; }

const STG_I = {
  monte: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20l6.5-11 4 6.5 2.5-4L21 20z"/><path d="M14.5 6.5l1.5-2.5 1.5 2.5"/></svg>',
  luna: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>',
  spento: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  avanti: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>'
};

/* ---------------------------------------------------------------------------------------
   COMINCIARE: tre schermate (come funziona, l'obiettivo, cosa si spegne)
   --------------------------------------------------------------------------------------- */
function stgObiettivoProposto(){
  /* 0.9.290, Andrea: "viene precompilato con 'L'app e' pubblica e viaggia insieme a ogni quadro venduto': quello non e'
     l'obiettivo che mi sono scritto, viene dalla roadmap". Il trimestre del piano e gli orizzonti li scrive l'agente;
     qui va solo quello che la persona ha scritto con le sue parole: l'obiettivo della stagione di prima, se c'e',
     altrimenti il sogno che ha scelto lui. */
  try{
    const st = JSON.parse(localStorage.getItem('fl_stagione_storia') || '[]') || [];
    const ult = st.length ? st[st.length - 1] : null;
    if (ult && ult.obiettivo && String(ult.obiettivo).trim()) return stgPulito(ult.obiettivo);
  }catch(_){ }
  try{ if (typeof nvSogno === 'function'){ const sg = String(nvSogno() || '').trim(); if (sg) return stgPulito(sg); } }catch(_){ }
  return '';
}
function stgPulito(t){ t = String(t || '').trim(); return typeof flAccenti === 'function' ? flAccenti(t) : t; }
function stgApri(){
  const st = flStagioneAttiva();
  if (st && st.fase === 'reset'){ stgBilancioApri(); return; }
  if (st){ stgStatoApri(); return; }
  STG.passo = 'intro';
  STG.bozza = { obiettivo: stgObiettivoProposto(), blocchi: {} };
  (typeof BS_STAGIONE_DEF !== 'undefined' ? BS_STAGIONE_DEF : []).forEach(function(k){ STG.bozza.blocchi[k] = true; });
  stgFoglio(stgPassoHtml(), null, true);
}
function stgPassoHtml(){
  const b = STG.bozza;
  if (STG.passo === 'intro'){
    const fine = stgMezzanotte() + STG_SPINTA * 86400000;
    /* 0.9.275, Andrea: "il popover fa cagare, e basta con quel giallo: i colori del brand sono rosso e blu".
       Un'immagine che si guarda prima di leggere (porta d'ingresso), la stagione disegnata come una linea
       del tempo invece che spiegata, tre righe corte, e i colori del brand. */
    return '<div class="stg-hero"><img src="img/bg/montagne.jpg" alt=""><div class="stg-hero-t"><small>Una sfida del Genio</small><h2>La stagione di spinta</h2></div></div>'
      + '<p class="stg-lead">90 giorni come se la tua vita dipendesse dal tuo obiettivo. Poi 14 di riposo.</p>'
      + '<div class="stg-linea"><div class="stg-l-spinta"><b>90 giorni</b><small>spinta</small></div><div class="stg-l-riposo"><b>14</b><small>riposo</small></div></div>'
      + '<div class="stg-date"><span>Oggi</span><span>' + stgData(fine - 86400000) + '</span></div>'
      + '<ul class="stg-punti">'
      + '<li><i>🎯</i><span>Conta una cosa sola: <b>il tuo obiettivo</b>.</span></li>'
      + '<li><i>' + STG_I.spento + '</i><span>Le parti di DreamMap dove è facile rimandare restano spente.</span></li>'
      + '<li><i>' + STG_I.luna + '</i><span>Alla fine ti fermi davvero e fai il bilancio.</span></li>'
      + '</ul>'
      + '<button type="button" class="stg-cta" onclick="stgVai(\'obiettivo\')">Accetto la sfida</button>'
      + '<button type="button" class="stg-link" onclick="stgFoglioChiudi()">Non adesso</button>';
  }
  if (STG.passo === 'obiettivo'){
    return '<small class="stg-eti">Passo 1 di 2</small><h2 class="stg-h">Per cosa spingi questi 90 giorni?</h2>'
      + '<p class="stg-p">Scrivi l’obiettivo con parole tue. Una cosa sola, quella per cui vale la pena dire di no a tutto il resto.</p>'
      + '<textarea class="stg-area" id="stgObiettivo" rows="3" placeholder="Per esempio: lanciare il negozio online e fare le prime 100 vendite">' + stgEsc(b.obiettivo) + '</textarea>'
      + '<button type="button" class="stg-cta" onclick="stgObiettivoOk()">Avanti</button>'
      + '<button type="button" class="stg-link" onclick="stgObiettivoTieni();stgVai(\'intro\')">Indietro</button>';
  }
  /* cosa si spegne */
  /* 0.9.289, Andrea: "se uno attiva il toggle pensa che sia acceso, invece cosi' sembra il contrario; e il paragrafo
     va in fondo, prima si vogliono solo gli interruttori". Interruttore acceso = la parte resta accesa; spento = spenta
     per 90 giorni. In b.blocchi resta true = spenta (lo legge blocchi-sezioni.js). */
  const righe = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).map(function(d){
    const spenta = !!b.blocchi[d.k];
    return '<div class="stg-riga' + (spenta ? ' spenta' : '') + '"><div><b>' + stgEsc(d.n) + '</b><small>' + (spenta ? 'Spenta per 90 giorni' : 'Resta accesa') + '</small></div><button type="button" class="switch' + (spenta ? '' : ' on') + '" onclick="stgBloccoCambia(\'' + d.k + '\')" aria-label="' + stgEsc(d.n) + (spenta ? ': spenta' : ': accesa') + '"></button></div>';
  }).join('');
  return '<small class="stg-eti">Passo 2 di 2</small><h2 class="stg-h">Cosa spegni per 90 giorni?</h2>'
    + '<p class="stg-p">Spegni le parti che ti distraggono.</p>'
    + '<div class="stg-righe">' + righe + '</div>'
    /* 0.9.290, Andrea: "quel testo lo puoi togliere: meno sa, meglio e'. Less is more". E lo stesso spazio sopra e sotto. */
    + '<div class="stg-ob"><small>Il tuo obiettivo</small><b>' + stgEsc(b.obiettivo) + '</b></div>'
    + '<button type="button" class="stg-cta" onclick="stgComincia()">Comincio oggi la stagione</button>'
    + '<button type="button" class="stg-link" onclick="stgVai(\'obiettivo\')">Indietro</button>';
}
function stgVai(p){ STG.passo = p; try{ flVibra(6); }catch(_){ } stgFoglioCorpo(stgPassoHtml()); }
function stgObiettivoTieni(){ const a = document.getElementById('stgObiettivo'); if (a && STG.bozza) STG.bozza.obiettivo = a.value; }
function stgObiettivoOk(){
  const a = document.getElementById('stgObiettivo');
  const t = String(a ? a.value : '').replace(/\s+/g, ' ').trim();
  if (t.length < 4){ try{ toast('Scrivi il tuo obiettivo, anche in poche parole.'); }catch(_){ } return; }
  STG.bozza.obiettivo = t; stgVai('blocchi');
}
function stgBloccoCambia(k){
  STG.bozza.blocchi[k] = !STG.bozza.blocchi[k];
  const c = document.querySelector('#stgVelo .stg-fin'), y = c ? c.scrollTop : 0;
  stgFoglioCorpo(stgPassoHtml());
  if (c) c.scrollTop = y;
}
function stgComincia(){
  const b = STG.bozza; if (!b || !b.obiettivo) return;
  stgScriviJ(STG_KEY, { inizio: stgMezzanotte(), at: Date.now(), obiettivo: b.obiettivo, blocchi: b.blocchi, bilancio: null });
  try{ flVibra([20, 40, 30]); }catch(_){ }
  stgFoglioCorpo('<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small><h2 class="stg-h">Giorno 1 di 90</h2>'
    + '<p class="stg-p">Da oggi conta una cosa sola: "' + stgEsc(b.obiettivo) + '". Le sezioni che distraggono sono spente fino al ' + stgData(stgMezzanotte() + (STG_SPINTA - 1) * 86400000) + '.</p>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Andiamo</button>');
  stgAggiorna();
}
function stgAggiorna(){
  try{ if (typeof bsControlla === 'function') bsControlla(true); }catch(_){ }
  stgPaint();
  try{ if (typeof sfdPaint === 'function') sfdPaint(); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   DURANTE: lo stato, e l'uscita (che costa una conferma scritta)
   --------------------------------------------------------------------------------------- */
function stgSpenteTxt(st){
  const l = (typeof BS_SEZIONI !== 'undefined' ? BS_SEZIONI : []).filter(function(d){ return st.blocchi[d.k]; }).map(function(d){ return d.n; });
  return l.length ? l.join(', ') : 'Nessuna sezione';
}
function stgStatoApri(){
  const st = flStagioneAttiva(); if (!st) return;
  const pct = Math.round(st.giorno / st.di * 100);
  stgFoglio('<div class="stg-ico">' + STG_I.monte + '</div><small class="stg-eti">La stagione di spinta</small><h2 class="stg-h">Giorno ' + st.giorno + ' di ' + st.di + '</h2>'
    + '<div class="stg-barra"><i style="width:' + pct + '%"></i></div>'
    + '<div class="stg-ob"><small>Il tuo obiettivo</small><b>' + stgEsc(st.obiettivo) + '</b></div>'
    + '<p class="stg-p">Restano spenti: ' + stgEsc(stgSpenteTxt(st)) + '. Il riposo comincia il ' + stgData(st.fineSpinta) + '.</p>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Torno a spingere</button>'
    + '<button type="button" class="stg-link" onclick="stgInterrompiChiedi()">Interrompi la stagione</button>', null, true);

}
function stgInterrompiChiedi(){
  stgFoglioCorpo('<small class="stg-eti">Interrompere la stagione</small><h2 class="stg-h">Sei sicuro di fermarti?</h2>'
    + '<p class="stg-p">La stagione finisce adesso, le sezioni si riaprono e i giorni fatti restano nella tua storia. Per confermare scrivi la parola MI FERMO.</p>'
    + '<input class="stg-in" id="stgFermo" autocomplete="off" placeholder="MI FERMO">'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Continuo la stagione</button>'
    + '<button type="button" class="stg-link" onclick="stgInterrompi()">Interrompi adesso</button>');
}
function stgInterrompi(){
  const i = document.getElementById('stgFermo');
  if (!i || String(i.value || '').trim().toUpperCase() !== 'MI FERMO'){ try{ toast('Per interrompere scrivi MI FERMO.'); }catch(_){ } return; }
  const s = stgCorrente(); if (s) stgArchivia(s, true);
  stgFoglioChiudi(); stgAggiorna();
  try{ toast('Stagione interrotta. Le sezioni sono di nuovo aperte.'); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   IL RIPOSO E IL BILANCIO (i 14 giorni dopo la spinta)
   --------------------------------------------------------------------------------------- */
function stgNumeri(st){
  const out = { sessioni: 0, minuti: 0, revisioni: 0 };
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (x && x.ok && !x.meditazione && x.at >= st.inizio && x.at < st.fineSpinta){ out.sessioni++; out.minuti += Math.round((x.spentMs || 0) / 60000); }
    });
  }catch(_){ }
  try{ (JSON.parse(localStorage.getItem('fl_revisioni') || '[]') || []).forEach(function(x){ const t = new Date(x.giorno + 'T12:00:00').getTime(); if (t >= st.inizio && t < st.fineSpinta) out.revisioni++; }); }catch(_){ }
  return out;
}
const STG_VICINO = ['Per niente', 'Poco', 'Abbastanza', 'Molto', 'Ce l’ho fatta'];
function stgBilancioApri(){
  const st = flStagioneAttiva(); if (!st || st.fase !== 'reset') return;
  STG.bil = Object.assign({ ottenuto: '', vicino: 0, tengo: '', cambio: '' }, st.bilancio || {});
  stgFoglio(stgBilancioHtml(st), null, true);
}
function stgBilancioHtml(st){
  const b = STG.bil, n = stgNumeri(st);
  const ore = Math.floor(n.minuti / 60);
  return '<div class="stg-ico">' + STG_I.luna + '</div><small class="stg-eti">Il riposo: giorno ' + st.giorno + ' di ' + st.di + '</small>'
    + '<h2 class="stg-h">Il bilancio della stagione</h2>'
    + '<div class="stg-ob"><small>L’obiettivo dei 90 giorni</small><b>' + stgEsc(st.obiettivo) + '</b></div>'
    + '<div class="stg-num"><div><b>' + n.sessioni + '</b><small>sessioni di Full Focus finite</small></div><div><b>' + ore + '</b><small>' + (ore === 1 ? 'ora di lavoro profondo' : 'ore di lavoro profondo') + '</small></div><div><b>' + n.revisioni + '</b><small>sere con la revisione</small></div></div>'
    + '<label class="stg-q">Cosa hai ottenuto in questi 90 giorni?</label><textarea class="stg-area" id="stgB1" rows="3">' + stgEsc(b.ottenuto) + '</textarea>'
    + '<label class="stg-q">Quanto ti sei avvicinato al tuo obiettivo?</label><div class="stg-chips">' + STG_VICINO.map(function(t, i){ return '<button type="button" class="stg-chip' + (b.vicino === i + 1 ? ' on' : '') + '" onclick="stgVicino(' + (i + 1) + ')">' + t + '</button>'; }).join('') + '</div>'
    + '<label class="stg-q">Cosa tieni per la prossima stagione?</label><textarea class="stg-area" id="stgB2" rows="2">' + stgEsc(b.tengo) + '</textarea>'
    + '<label class="stg-q">Cosa cambi?</label><textarea class="stg-area" id="stgB3" rows="2">' + stgEsc(b.cambio) + '</textarea>'
    + '<button type="button" class="stg-cta" onclick="stgBilancioSalva()">Salvo il bilancio</button>'
    + '<p class="stg-nota">Il riposo finisce il ' + stgData(st.fineReset - 86400000) + '. Poi puoi cominciare una stagione nuova.</p>';
}
function stgBilancioLeggiCampi(){
  const v = function(id){ const e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; };
  STG.bil.ottenuto = v('stgB1'); STG.bil.tengo = v('stgB2'); STG.bil.cambio = v('stgB3');
}
function stgVicino(i){ stgBilancioLeggiCampi(); STG.bil.vicino = i; const st = flStagioneAttiva(); if (st) stgFoglioCorpo(stgBilancioHtml(st)); }
function stgBilancioSalva(){
  stgBilancioLeggiCampi();
  if (!STG.bil.ottenuto){ try{ toast('Scrivi almeno cosa hai ottenuto.'); }catch(_){ } return; }
  const s = stgCorrente(); if (!s) return;
  s.bilancio = Object.assign({}, STG.bil, { at: Date.now() });
  stgScriviJ(STG_KEY, s);
  stgFoglioChiudi(); stgPaint();
  try{ toast('Bilancio salvato. Adesso riposa davvero.'); }catch(_){ }
}
/** Per il tuo agente personale: a che punto e' la stagione. */
function stgPerAgente(){
  const st = flStagioneAttiva(); if (!st) return '';
  return st.fase === 'spinta'
    ? 'Stagione di spinta (Monk mode, 90 giorni): giorno ' + st.giorno + ' di 90, obiettivo "' + st.obiettivo + '". Niente distrazioni.'
    : 'Riposo dopo la stagione di spinta: giorno ' + st.giorno + ' di 14. ' + (st.bilancio ? 'Bilancio: ottenuto "' + st.bilancio.ottenuto + '", cambia "' + (st.bilancio.cambio || '') + '".' : 'Bilancio ancora da fare.');
}

/* ---------------------------------------------------------------------------------------
   LE PORTE: la card nella Mappa (vista Roadmap) e la prima card delle Sfide di Dream
   --------------------------------------------------------------------------------------- */
function stgCardHtml(){
  const st = flStagioneAttiva();
  /* 0.9.275, Andrea: non una sezione della Roadmap ma una sfida, una proposta del gioco. Finche' non e'
     cominciata vive come tappa della mappa (sentiero-mappa.js, nodo "stg") e come card delle Sfide di
     Dream; qui compare solo il contatore, mentre la stagione e' in corso. */
  if (!st) return '';
  if (st.fase === 'spinta'){
    const pct = Math.round(st.giorno / st.di * 100);
    return '<div class="stg-card on" onclick="stgStatoApri()" role="button"><span class="stg-c-ico">' + STG_I.monte + '</span><div><small>La stagione di spinta</small>'
      + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><div class="stg-barra"><i style="width:' + pct + '%"></i></div><i>' + stgEsc(st.obiettivo) + '</i></div>' + STG_I.avanti + '</div>';
  }
  return '<div class="stg-card riposo" onclick="stgBilancioApri()" role="button"><span class="stg-c-ico">' + STG_I.luna + '</span><div><small>Il riposo dopo la stagione</small>'
    + '<b>Giorno ' + st.giorno + ' di ' + st.di + '</b><i>' + (st.bilancio ? 'Bilancio fatto. Rileggilo quando vuoi.' : 'Fai il bilancio dei 90 giorni.') + '</i></div>' + STG_I.avanti + '</div>';
}
function stgPaint(){
  if (typeof document === 'undefined') return;
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  const rif = document.getElementById('mppPianoRm') || document.getElementById('mppSentiero');
  if (!rif || !rif.parentNode) return;
  let h = document.getElementById('mppStagione');
  if (!h){ h = document.createElement('div'); h.id = 'mppStagione'; h.className = 'mpp-slot'; }
  if (rif.nextElementSibling !== h) rif.parentNode.insertBefore(h, rif.nextSibling);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  /* 0.9.288, Andrea: "dopo averla accettata il pannello della stagione non compare piu' nella Mappa": si nascondeva
     nella vista "Pianifica tu". La stagione vale per tutte e due le strade. */
  h.classList.remove('mpp-via');
  const html = stgCardHtml();
  if (h.dataset.html !== html){ h.dataset.html = html; h.innerHTML = html; }
}
/** La card per il carosello delle Sfide (sfide-dream.js), finche' la stagione non e' cominciata. */
function stgSfidaCard(){
  if (flStagioneAttiva()) return null;
  return { k: 'stagione', ico: '🏔️', img: 'img/sfide/spinta.jpg', t: 'La stagione di spinta',
    s: '90 giorni come se la tua vita dipendesse dal tuo obiettivo: niente distrazioni dentro DreamMap. Poi 14 giorni di riposo e il bilancio.',
    meta: '90 giorni', fatta: false, via: 'stgApri()' };
}

if (typeof document !== 'undefined'){
  (function(){
    if (typeof rmpPaint === 'function' && !rmpPaint.__stg){ const v = rmpPaint; const w = function(){ const r = v.apply(this, arguments); try{ stgPaint(); }catch(_){ } return r; }; w.__stg = true; window.rmpPaint = w; }
    if (typeof rnPerAgente === 'function' && !rnPerAgente.__stg){ const v2 = rnPerAgente; const w2 = function(){ return [v2.apply(this, arguments), stgPerAgente()].filter(Boolean).join(' '); }; w2.__stg = true; window.rnPerAgente = w2; }
  })();
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(stgPaint, 120); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(stgPaint, 600); });
  setTimeout(stgPaint, 1500);
  setInterval(stgPaint, 60000);
  (function(){
    const st = document.createElement('style');
    st.textContent = [
      '#mppStagione{padding:0 16px;margin:10px 0 12px}#mppStagione:empty{display:none}',
      '.stg-card{display:flex;align-items:center;gap:12px;padding:15px 16px;border-radius:20px;background:linear-gradient(135deg,#0075E3,#005BB0);color:#FFFFFF;cursor:pointer;box-shadow:0 10px 24px rgba(0,91,176,.22)}',
      '.stg-card > div{flex:1;min-width:0}.stg-card > svg{flex:none;opacity:.85}.stg-c-ico{flex:none;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:rgba(255,255,255,.16);color:#FFFFFF}',
      '.stg-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#BCE0FF}',
      '.stg-card b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}',
      '.stg-card i{display:block;margin-top:4px;font:600 12.5px/1.4 var(--font-body);font-style:normal;color:#D2ECFF;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.stg-card.riposo{background:linear-gradient(135deg,#3F9FF4,#0075E3)}',
      '.stg-barra{height:8px;border-radius:8px;background:var(--blue-soft,#E3F1FF);overflow:hidden;margin:8px 0 12px}.stg-card .stg-barra{background:rgba(255,255,255,.22);margin:8px 0 0}.stg-barra i{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,#0075E3,#3F9FF4);margin:0}.stg-card .stg-barra i{background:#FFFFFF}',
      '.stg-velo{position:fixed;inset:0;z-index:10040;display:flex;align-items:flex-end;justify-content:center}',
      '.stg-scrim{position:absolute;inset:0;background:rgba(0,30,68,.55)}',
      '.stg-f{position:relative;width:100%;max-width:520px;max-height:92vh;border-radius:26px 26px 0 0;background:var(--card,#FFFFFF);color:var(--ink,#0A1A2F);box-shadow:0 -10px 40px rgba(0,30,68,.28);display:flex;flex-direction:column;overflow:hidden}',
      '.stg-fin{overflow:auto;padding:24px 20px calc(24px + env(safe-area-inset-bottom))}',
      '.stg-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.35);color:#FFFFFF;display:grid;place-items:center;z-index:3;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}',
      '.stg-hero{position:relative;margin:-24px -20px 16px;height:178px;overflow:hidden}.stg-hero img{width:100%;height:100%;object-fit:cover;display:block}',
      '.stg-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,0) 30%,rgba(0,30,68,.78))}',
      '.stg-hero-t{position:absolute;left:20px;right:20px;bottom:14px;z-index:1;color:#FFFFFF}.stg-hero-t small{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#BCE0FF}.stg-hero-t h2{margin:2px 0 0;font:900 26px/1.15 var(--font-display,var(--font-body))}',
      '.stg-lead{margin:0 0 14px;font:700 17px/1.45 var(--font-body);color:var(--navy,#001E44)}',
      '.stg-linea{display:flex;gap:4px;height:46px;border-radius:14px;overflow:hidden;margin:0 0 6px}.stg-linea > div{display:flex;flex-direction:column;justify-content:center;padding:0 12px;color:#FFFFFF}.stg-linea b{font:800 15px/1.1 var(--font-body)}.stg-linea small{font:600 11.5px var(--font-body);opacity:.9}',
      '.stg-l-spinta{flex:90;background:linear-gradient(90deg,#0075E3,#3F9FF4)}.stg-l-riposo{flex:24;background:var(--dream);color:#0E2350!important}.stg-l-riposo b,.stg-l-riposo small{color:#0E2350}',
      '.stg-date{display:flex;justify-content:space-between;margin:0 0 14px;font:600 12px var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-punti{list-style:none;margin:0 0 6px;padding:0;display:grid;gap:10px}.stg-punti li{display:flex;align-items:center;gap:12px;font:500 15px/1.45 var(--font-body);color:var(--ink,#0A1A2F)}.stg-punti b{color:#0075E3}',
      '.stg-punti i{flex:none;width:36px;height:36px;border-radius:12px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;font-style:normal;font-size:17px}',
      '.stg-ico{width:58px;height:58px;border-radius:18px;display:grid;place-items:center;background:var(--blue-soft,#E3F1FF);color:#0075E3;margin-bottom:12px}',
      '.stg-eti{display:block;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}',
      '.stg-h{margin:6px 40px 10px 0;font:800 24px/1.25 var(--font-display,var(--font-body));color:var(--navy,#001E44)}',
      '.stg-p{margin:0 0 14px;font:500 16px/1.55 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-nota{margin:12px 0 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-tappe{display:grid;gap:10px;margin:6px 0 14px}.stg-tappe > div{padding:14px;border-radius:16px;background:var(--blue-soft,#E3F1FF)}.stg-tappe b{display:block;font:800 16px var(--font-body);color:#0075E3}.stg-tappe p{margin:4px 0 0;font:500 15px/1.5 var(--font-body);color:var(--ink,#0A1A2F)}',
      '.stg-cta{display:block;width:100%;margin-top:14px;padding:16px;border:0;border-radius:999px;background:#0075E3;color:#FFFFFF;font:800 17px var(--font-body);box-shadow:0 8px 20px rgba(0,117,227,.28)}',
      '.stg-link{display:block;width:100%;margin-top:6px;padding:12px;border:0;background:none;color:var(--muted,#4A5A72);font:700 15px var(--font-body)}',
      '.stg-area,.stg-in{display:block;width:100%;box-sizing:border-box;padding:14px;border-radius:14px;border:1.5px solid var(--line,#DCE8F5);background:var(--bg,#F4F9FF);color:var(--ink,#0A1A2F);font:500 16px/1.5 var(--font-body);resize:vertical}',
      '.stg-area::placeholder,.stg-in::placeholder{color:var(--faint,#8B99AC)}',
      '.stg-righe{display:grid;gap:12px;margin:0 0 28px}.stg-riga{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);border:1.5px solid var(--line,#DCE8F5)}.stg-riga > div{flex:1;min-width:0}',
      '.stg-riga b{display:block;font:700 15px/1.35 var(--font-body);color:var(--ink,#0A1A2F)}.stg-riga small{display:block;margin-top:2px;font:500 13px/1.4 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-ob{padding:16px 18px;border-radius:16px;background:var(--dream);margin:0 0 28px}.stg-ob small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#005BB0}.stg-ob b{display:block;margin-top:4px;font:700 16px/1.4 var(--font-body);color:#0E2350}',
      '.stg-num{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:4px 0 12px}.stg-num > div{padding:12px 8px;border-radius:14px;background:var(--blue-soft,#E3F1FF);text-align:center}.stg-num b{display:block;font:800 24px var(--font-body);color:#0075E3}.stg-num small{display:block;margin-top:2px;font:600 12px/1.3 var(--font-body);color:var(--muted,#4A5A72)}',
      '.stg-q{display:block;margin:14px 0 6px;font:700 15.5px/1.4 var(--font-body);color:var(--navy,#001E44)}',
      /* 0.9.276, Andrea: "tutto ammassato, nessuna distanza fra un elemento e l'altro: piuttosto una pagina a schermo
         intero". La stagione e' una pagina intera, con lo spazio della skill ui-scansionabile (16/24/32 px). */
      '.stg-pagina{align-items:stretch}.stg-pagina .stg-scrim{display:none}.stg-pagina .stg-f{max-width:none;max-height:none;height:100%;border-radius:0}',
      '.stg-pagina .stg-fin{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:24px 24px calc(28px + env(safe-area-inset-bottom))}',
      /* 0.9.288, Andrea: "la barra 90/14 tagliata, l'intestazione tagliata, Non adesso in bella vista". La colonna era alta
         quanto lo schermo e schiacciava i suoi figli invece di scorrere: adesso nessuno si schiaccia, la foto in cima e'
         grande e i pulsanti si trovano scorrendo. */
      '.stg-pagina .stg-fin > *{flex-shrink:0}',
      '.stg-pagina .stg-hero{height:clamp(300px,50vh,440px)!important}',
      '.stg-pagina .stg-linea{height:auto!important;min-height:58px}.stg-linea > div{padding:8px 12px}',
      '.stg-riga.spenta b{color:var(--muted,#4A5A72)}.stg-riga.spenta small{color:#E5484D;font-weight:700}',
      '.stg-area{min-height:110px}.stg-area:focus{outline:none;border-color:#0075E3}body.dark .stg-area:focus{border-color:#3F9FF4}',
      '.stg-pagina .stg-hero{margin:-24px -24px 28px;height:clamp(200px,32vh,280px)}.stg-pagina .stg-hero-t{left:24px;right:24px;bottom:20px}.stg-pagina .stg-hero-t h2{font-size:30px;margin-top:6px}',
      '.stg-pagina .stg-lead{margin:0 0 28px;font-size:18px;line-height:1.5}',
      '.stg-pagina .stg-linea{height:54px;margin:0 0 10px}.stg-pagina .stg-date{margin:0 0 36px}',
      '.stg-pagina .stg-punti{gap:22px;margin:0 0 40px}.stg-pagina .stg-punti li{gap:16px;font-size:16px}.stg-pagina .stg-punti i{width:44px;height:44px;border-radius:14px}',
      '.stg-pagina .stg-cta{margin-top:auto}.stg-pagina .stg-link{margin-top:12px}',
      '.stg-pagina .stg-h{margin:10px 0 16px;font-size:26px}.stg-pagina .stg-p{margin:0 0 24px}.stg-pagina .stg-eti{margin-top:8px}',
      '.stg-pagina .stg-area,.stg-pagina .stg-righe,.stg-pagina .stg-ob,.stg-pagina .stg-barra{margin-bottom:28px}',
      /* 0.9.277, Andrea: "il margine e' inesistente nel popover". Bordi del foglio 28px, titolo staccato, pulsante con aria. */
      '.stg-fin{padding:32px 28px calc(28px + env(safe-area-inset-bottom))}',
      '.stg-h{margin:12px 48px 28px 0}.stg-p{margin:0 0 24px}.stg-cta{margin-top:36px}.stg-q{margin:24px 0 12px}.stg-chips{gap:10px}',
      '.stg-chips{display:flex;flex-wrap:wrap;gap:8px}.stg-chip{padding:10px 14px;border-radius:999px;border:1.5px solid var(--line,#DCE8F5);background:transparent;color:var(--ink,#0A1A2F);font:700 14.5px var(--font-body)}.stg-chip.on{background:#0075E3;border-color:#0075E3;color:#FFFFFF}'
    ].join('');
    document.head.appendChild(st);
  })();
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { flStagioneAttiva: flStagioneAttiva, stgArchivia: stgArchivia, STG_SPINTA: STG_SPINTA, STG_RESET: STG_RESET };
}
