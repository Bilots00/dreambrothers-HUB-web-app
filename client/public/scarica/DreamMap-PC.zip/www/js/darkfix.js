/* ===========================================================================================
   MODALITÀ SCURA — i pannelli bianchi con il testo bianco

   Non erano venticinque bug diversi: erano due, ripetuti ovunque.

   PRIMO. Decine di pannelli scrivono il proprio sfondo come `background:#fff`, un bianco fisso,
   mentre il testo che ci sta dentro usa le variabili del tema (`--navy`, `--muted`). Al
   passaggio in scuro il testo diventa chiaro — è il suo mestiere — e lo sfondo resta bianco:
   testo bianco su bianco. Il colore fisso è la metà che non si è accorta di niente.

   SECONDO, ed è peggiore. Alcuni pannelli usano `var(--navy)` COME SFONDO (`.life`, la card
   della concentrazione nella scheda START). In chiaro `--navy` è il blu notte e il pannello è
   scuro con il testo bianco: giusto. In scuro `--navy` diventa `#E8F1FF` — perché altrove è
   il colore del TESTO — e quel pannello diventa bianco, con il testo bianco sopra.
   **Una variabile che fa sia da inchiostro sia da carta non può sopravvivere a un cambio di
   tema.** Dove serve un fondo scuro va scritto un fondo scuro, non «il colore del testo».

   Questo foglio si carica per ultimo e vale solo dentro a `body.dark`: in chiaro non tocca
   niente, e ogni riga qui sotto corrisponde a un punto in cui l'app era davvero illeggibile —
   trovato misurando il contrasto vero fra testo e sfondo su tutte le schermate, non a occhio.
   =========================================================================================== */

(function darkFix(){
  const CARTA = 'var(--card)';          // #141C2C in scuro
  const BORDO = 'var(--line)';          // #25314A in scuro
  const NOTTE = '#0E2350';              // il blu notte VERO, quello che non cambia mai

  /* I pannelli, le righe e le caselle che si erano dimenticati di essere in scuro. */
  const carta = [
    '.sheet', '.sheet input', '.acct', '.picklist', '.typecard', '.condcard',
    '.statbox', '.profcard', '.slevel', '.ghostmini',
    '.blk-quicklink', '.blk-moderow', '.blk-chip', '.blk-opt', '.blk-daysbox', '.blk-day',
    '.blk-base', '.blk-trow', '.blk-modecard', '.blk-qlmode', '.blk-typerow', '.blk-dialog',
    '.blk-timefield', '.blk-sw .blk-sheet',
    '.ub-iconbtn', '.ub-modebar', '.ub-appico', '.ub-csv-area',
    '.sev-optcard', '.sev-mcard', '.sev-panel', '.sev-chip', '.sev-pin', '.sev-statecard',
    '.sev-tabbox', '.sev-entry',
    '.ins-menu', '.ins-menu button', '.ins-chip', '.ins-more', '.ins-pick', '.ins-prem',
    '.ins-tabs button.on',   /* .fr-tabs ha i suoi colori del brand in friends.js (0.9.304: qui diventava grigia) */
    '.uf-planrow', '.uf-menu',
    '.ue-qbtn', '.ue-chip', '.ue-legal-frame', '.ue-legal-online',
    '.arb-menu', '.arb-menu button', '.saved', '.mcard', '.choice', '.namefield',
    /* trovati dal cancello statico (tools/controlla-scuro.py), 19/09 */
    '.weekdots .wd'
  ];

  /* I pannelli che restano CHIARI di proposito — una card promozionale, il riquadro rosa
     della serie — e che in scuro si portavano dietro il testo chiaro del tema. Non vanno
     scuriti: va riportato scuro il testo, che e' la meta' che ha sbagliato. */
  /* IL FOGLIO DEL GENIO e' una carta chiara appoggiata su un fondo scuro: e' cosi' di
     proposito, in chiaro e in scuro. Quello che si ribaltava era solo l'inchiostro — le domande
     e i sei traguardi usano `var(--navy)`, che in scuro diventa quasi bianco su carta chiara.
     Qui la carta resta, e l'inchiostro torna scuro. */
  const chiariDiProposito = ['.procard', '.blk-streak', '.or-card', '.or-t', '.or-known li',
    /* LE TRE MOSSE del ricalcolo: stessa carta chiara del foglio, stesso inchiostro che di
       notte spariva. Il numero nel cerchio usava `--navy` come SFONDO: scritto a mano. */
    '.or-step'];

  /* NON metterci `.sc-tipbtn`. E' il pulsante dentro al fumetto degli «i», e quel fumetto ha
     un fondo scuro FISSO in tutti e due i temi: scurire anche il pulsante lo faceva sparire
     (inchiostro #0B1A3A su fondo #141C2C, contrasto 1,1). Un correttivo per la modalita'
     scura non deve toccare cio' che e' gia' scuro di suo. */

  /* PERCHE' `!important`.
     Meta' dei fogli di stile di questa app nascono a runtime, quando il modulo che li usa viene
     toccato la prima volta: si infilano in coda al documento DOPO questo, e per le regole della
     cascata vincono loro. Un correttivo che arriva primo non corregge niente. Queste righe
     vivono solo dentro a `body.dark` e non possono toccare il tema chiaro: qui `!important`
     non e' una scorciatoia, e' l'unico modo di essere l'ultima parola. */
  const css = [
    /* 1. La carta torna carta scura, e il bordo con lei: un pannello scuro con il bordo
          bianco sembra ritagliato male. */
    /* UNA REGOLA PER SELETTORE. In un elenco unico, un solo selettore che un WebView non
       capisce fa scartare TUTTA la regola — e i chip restano bianchi senza che nessun
       errore lo dica. Separate, ognuna cade da sola. */
    carta.map(function(s){ return 'body.dark ' + s + '{background:' + CARTA + ' !important;border-color:' + BORDO + ' !important}'; }).join('\n'),

    /* 1-bis. LA SCELTA FATTA DEVE VEDERSI ANCHE QUI.
          La regola 1 scurisce la carta di `.ins-pick` — e con `!important` scurisce anche
          quella della scelta fatta, che in chiaro ha il fondo azzurro e il bordo blu. In
          scuro i tre riquadri diventavano identici: si poteva scegliere «Distrattivo» e non
          vedere nessuna differenza fra prima e dopo. Il correttivo del tema aveva spento il
          segnale che dice «questo e' quello che hai scelto». */
    'body.dark .ins-pick.on{background:rgba(0,117,227,.22) !important;border-color:var(--blue) !important}',
    'body.dark .ins-pick.on b{color:#fff !important}',

    /* 2. I pannelli che usavano il colore del TESTO come sfondo. Qui il fondo va scritto a
          mano, perché è l'unico modo di dire «scuro» in una lingua che il tema non ribalta. */
    'body.dark .life{background:' + NOTTE + ' !important;color:#fff !important}',
    'body.dark .life-chip.on{background:#fff !important;color:#0E2350 !important}',
    'body.dark .life-go{background:#fff !important;color:#0E2350 !important}',
    'body.dark .life-oddsnum,body.dark .life-big{color:#8CF0C8 !important}',

    /* 2-bis. Chi resta chiaro per scelta si tiene l'inchiostro scuro. */
    chiariDiProposito.map(function(s){ return 'body.dark ' + s + '{color:#0E2350 !important}\nbody.dark ' + s + ' *{color:#0E2350 !important}'; }).join('\n'),

    /* 3. I casi singoli, ognuno con la sua ragione. */
    /* Il riquadro «niente pubblicità»: fondo blu scuro e testo blu scuro, cioè invisibile. */
    'body.dark .uf-noads{color:#9EC1FF !important}',
    'body.dark .or-step i{background:#0E2350 !important;color:#fff !important}',
    'body.dark .or-step small{color:#5B6B85 !important}',
    /* I chip dei siti e delle parole chiave nel Blocco: inline `background:#fff` sul chip
       «aggiungi», e il chip normale che a volte nasce dopo questo foglio. */
    'body.dark .blk-chip,body.dark .blk-chip[style]{background:var(--card) !important;color:#E8F1FF !important;border-color:var(--line) !important}',
    'body.dark .blk-chip.more{background:#1B2540 !important;color:#9FB6CF !important}',
    /* Il pulsante della foresta: testo nero su una velina chiara sopra a uno sfondo scuro. */
    'body.dark .ff-forestbtn{color:#fff !important}',
    /* I link lasciati al colore di serie del browser: blu elettrico su nero. */
    'body.dark a{color:#7FB6FF !important}',
    /* Il pulsante verde della foresta ha il suo testo scuro: va tenuto scuro anche qui,
       perché il suo fondo resta chiaro apposta. */
    'body.dark .ff-cta{background:#fff !important;color:#1F3B32 !important}',

    /* 4. I MENU A TRE PUNTINI — la terza forma dello stesso errore.

       Qui la carta si era ricordata di scurirsi (regola 1) e l'inchiostro no, perché è scritto
       a mano dentro al modulo: `color:#0E1B33`. Misurato sul menu della mappa in scuro: testo
       rgb(14,27,51) su fondo rgb(20,28,44), contrasto 1,03 — cioè una voce di menu che esiste,
       si può premere, e non si vede. Peggio di un pulsante mancante, perché non sembra rotto.

       Insieme all'inchiostro vanno i due dettagli che erano rimasti chiari con lui: la riga di
       separazione (#E7ECF5) e la strisciolina del titolo, che ha uno `background:#fff` suo e
       quindi restava una linguetta bianca in cima a un menu nero. */
    'body.dark .arb-menu button,body.dark .ins-menu button,body.dark .uf-menu button'
      + '{color:#EEF4FF !important}',
    'body.dark .arb-menu button + button,body.dark .ins-menu button + button'
      + '{border-top-color:' + BORDO + ' !important}',
    'body.dark .arb-mtit{background:' + CARTA + ' !important;color:#8FA2BF !important}',
    /* La voce scelta resta azzurra, ma l'azzurro di serie su fondo scuro è troppo cupo. */
    'body.dark .arb-menu button.on,body.dark .ins-menu button.on{color:#6FC0FF !important}',

    /* 5. IL FOGLIO «SCEGLI UN ACCOUNT»: la carta si scurisce (regola 1) ma `.acct b` non ha
       un colore suo e resta nero: nome nero su carta nera. Segnalato da Andrea il 19/09. */
    'body.dark .acct b,body.dark .sheet h3,body.dark .sheet .ssub{color:#EEF4FF !important}',
    'body.dark .acct small{color:#9FB6CF !important}',

    /* 6. I PULSANTI GIALLI DEL GENIO hanno l'inchiostro scuro SEMPRE: il giallo non cambia
       con il tema, quindi nemmeno il testo sopra. Scritto qui perché nessun correttivo
       generico deve poterlo ribaltare. */
    'body.dark .or-a,body.dark .or-a *{color:#0E2350 !important}',
    'body.dark .or-a.main,body.dark .or-a.main *{color:#fff !important}',
    /* 7. LA CARD SCELTA (categorie, momenti): la regola 1 le imponeva il bordo di serie
       anche da selezionata, e il bordo azzurro spariva. Il segno di spunta non basta. */
    'body.dark .choice:has(.choice-in:checked){border-color:#4FA8FF !important;background:#12305F !important}'
  ].join('\n');

  const st = document.createElement('style');
  st.id = 'flDarkFix';
  st.textContent = css;
  document.head.appendChild(st);
})();

/* ===========================================================================================
   IL CANCELLO DEL CONTRASTO — perché «bianco su bianco» non torni una sesta volta.

   Le cinque segnalazioni precedenti hanno tutte la stessa forma: una regola scrive la carta
   con un colore FISSO chiaro e l'inchiostro con una VARIABILE del tema. Di giorno funziona; di
   notte la variabile diventa chiara, la carta no, e il testo sparisce. Ogni volta ho corretto
   la regola che avevo trovato — e l'ultima volta ho corretto perfino la classe sbagliata,
   perché i chip che si vedevano nello screenshot erano `.ub-chip` e non `.blk-chip`.

   Cercare le regole a mano non è un metodo: qui si misura il risultato. In modalità scura si
   guarda quello che è davvero a schermo e, dove l'inchiostro e la carta sono tutti e due
   chiari, si riporta scuro l'inchiostro. La carta chiara a volte è voluta (il foglio del
   Genio); l'inchiostro chiaro sopra una carta chiara non lo è mai.

   Costa una passata sugli elementi visibili della schermata attiva, gira in tutti e due i temi,
   dopo un disegno, con un fermo di 150 ms. Quello che corregge lo lascia scritto in
   `FL_CONTRASTO`, che la pagina Info mostra: così un difetto che passa di qui ha un nome e un
   numero, invece di un altro screenshot.
   =========================================================================================== */
const FL_CONTRASTO = [];
function flLuma(c){
  const m = String(c || '').match(/[\d.]+/g);
  if (!m || m.length < 3) return null;
  if (m.length >= 4 && +m[3] < 0.35) return null;          // trasparente: non è lui la carta
  const v = [+m[0], +m[1], +m[2]].map(function(x){ x /= 255; return x <= .03928 ? x / 12.92 : Math.pow((x + .055) / 1.055, 2.4); });
  return .2126 * v[0] + .7152 * v[1] + .0722 * v[2];
}
/* Un gradiente si giudica dalla media dei suoi colori; una foto (url) non si giudica. Prima
   chi aveva un background-image veniva saltato del tutto, e le card con il gradiente scuro
   (le righe «distrazioni fermate», 20/09) passavano con l'inchiostro scuro sopra. */
function flGradiente(img){
  if (!img || img === 'none') return null;
  if (/url\(/i.test(img)) return 'img';
  const cols = img.match(/rgba?\([^)]*\)/g) || [];
  let tot = 0, n = 0;
  cols.forEach(function(c){ const l = flLuma(c); if (l !== null){ tot += l; n++; } });
  return n ? tot / n : null;
}
function flCarta(el){
  /* la carta vera è il primo antenato che ne ha una: un chip dentro a una card trasparente
     sta sulla card, non sul fondo della pagina */
  let n = el;
  for (let i = 0; i < 8 && n && n !== document.body; i++){
    const cs = getComputedStyle(n);
    const g = flGradiente(cs.backgroundImage);
    if (g === 'img') return null;
    if (g !== null) return g;
    const l = flLuma(cs.backgroundColor);
    if (l !== null) return l;
    n = n.parentElement;
  }
  return null;
}
function flHaTesto(el){
  for (let i = 0; i < el.childNodes.length; i++){
    const n = el.childNodes[i];
    if (n.nodeType === 3 && n.nodeValue && n.nodeValue.trim()) return true;
  }
  return false;
}
let FL_CG_T = null, FL_CG_T2 = null;
/* chi la guardia ha appena toccato: la sua transizione di colore non fa ripartire la guardia */
const FL_CG_TOCCATI = new WeakSet();
/* Gli elementi che il giro precedente ha corretto, con l'inchiostro inline che avevano prima. */
const FL_CG_FATTI = new Map();
/* 0.9.264, Andrea (lag nello scroll): la guardia costa ~150 ms tutta d'un fiato e partiva 400 ms dopo il cambio di
   scheda, cioe' proprio mentre si comincia a scorrere: uno scatto a ogni scheda. Adesso aspetta che lo scroll sia
   fermo da mezzo secondo (lo scroll qui si limita a segnare l'ora: costo zero). */
let FL_CG_SCROLL_AT = 0;
document.addEventListener('scroll', function(){ FL_CG_SCROLL_AT = Date.now(); }, { capture: true, passive: true });
/* flInScroll sta in scorre.js, caricato per primo */
document.addEventListener('touchstart', function(){ FL_CG_SCROLL_AT = Date.now(); }, { capture: true, passive: true });
/* 0.9.265 (lag): la guardia rileggeva TUTTA la schermata e riscriveva i colori gia' giusti ogni volta che un pezzo si
   ridisegnava (i contatori in testata, la revisione, il tabellone: ogni ~2 secondi), ~150 ms di blocco ogni volta.
   Adesso il giro intero si fa solo al cambio di pagina, di scheda o di tema; quando entra un pezzo nuovo si guarda
   solo quel pezzo. E le schede nascoste non si visitano piu'. */
let FL_CG_INTERO = true;
const FL_CG_RADICI = new Set();
function flCgPrendi(root, fuori){
  const out = [];
  if (!root || !root.isConnected) return out;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, { acceptNode: function(n){
    if (n.classList && n.classList.contains('tabpage') && !n.classList.contains('on')) return NodeFilter.FILTER_REJECT;
    if (fuori && fuori(n)) return NodeFilter.FILTER_REJECT;
    return NodeFilter.FILTER_ACCEPT;
  } });
  if (root.nodeType === 1 && !(root.classList.contains('tabpage') && !root.classList.contains('on'))) out.push(root);
  let n; while ((n = w.nextNode())) out.push(n);
  return out;
}
function flContrastoGuardia(){
  if (Date.now() - FL_CG_SCROLL_AT < 500){ clearTimeout(FL_CG_T); FL_CG_T = setTimeout(flContrastoGuardia, 500); return; }
  const viva = document.querySelector('.screen.active') || document.body;
  const intero = FL_CG_INTERO;
  let radici = intero ? [viva] : Array.from(FL_CG_RADICI).filter(function(r){ return r.isConnected && viva.contains(r); });
  FL_CG_INTERO = false; FL_CG_RADICI.clear();
  if (!radici.length) return;
  /* dentro un pezzo gia' contenuto in un altro, si guarda una volta sola (risalendo gli antenati: lineare) */
  if (!intero && radici.length > 1){
    const set = new Set(radici);
    radici = radici.filter(function(r){ for (let p = r.parentElement; p; p = p.parentElement){ if (set.has(p)) return false; } return true; });
  }
  const dentro = function(el){ return intero || radici.some(function(r){ return r.contains(el); }); };
  /* PRIMA SI DISFA, POI SI GIUDICA. La correzione era per sempre (`data-fl-cg`): la testata
     letta a metà transizione — carta chiara per 250 ms mentre cambiava tema — prendeva
     l'inchiostro scuro e lo teneva anche quando la carta tornava scura: il titolo «Report»
     nero sul nero (20/09). Ogni giro riparte dal colore del foglio di stile, e gira in tutti
     e due i temi: lo scuro-su-scuro in modalità chiara è lo stesso difetto. */
  /* 0.9.260, Andrea: le caselle di "Cosa ti ruba piu' tempo ed energia?" lampeggiavano tutte. Era questo giro:
     disfatto il colore, la casella (transition: all) tornava al suo colore IN DIFFERITA, la lettura subito dopo
     vedeva il colore a meta' strada e non correggeva; a transizione finita un altro giro correggeva di nuovo, e
     cosi' ogni 600 ms. Adesso si disfa SENZA transizione (si legge il colore vero), e si rimette la transizione
     solo dopo: se il giudizio e' lo stesso, a schermo non cambia niente. */
  const transiz = [];
  /* 0.9.265: si disfa SOLO dopo un cambio di tema (e' l'unico caso in cui il colore giusto cambia). Negli altri giri
     i pezzi gia' corretti restano come sono: niente lampeggi mentre la guardia lavora a fette. */
  const tema = Date.now() - FL_CG_TEMA_AT < 3000;
  FL_CG_FATTI.forEach(function(prima, el){
    if (!el.isConnected){ FL_CG_FATTI.delete(el); return; }
    if (!tema || !dentro(el)) return;
    FL_CG_FATTI.delete(el);
    transiz.push([el, el.style.getPropertyValue('transition'), el.style.getPropertyPriority('transition')]);
    el.style.setProperty('transition', 'none', 'important');
    if (prima) el.style.setProperty('color', prima.v, prima.p); else el.style.removeProperty('color');
    FL_CG_TOCCATI.add(el);
  });
  const rimetti = function(){ transiz.forEach(function(x){ if (x[1]) x[0].style.setProperty('transition', x[1], x[2]); else x[0].style.removeProperty('transition'); }); };
  /* 0.9.265 (lag): a fette di ~6 ms, prima si LEGGE tutto e poi si SCRIVE tutto. Prima era un giro solo da
     150-300 ms, e leggere e scrivere alternati obbligava a ricalcolare lo stile a ogni elemento. */
  let n = 0, ri = 0, coda = [];
  const da = [];
  /* gli elementi si raccolgono a poco a poco, una radice alla volta, dentro le fette */
  const prossimo = function(){
    while (!coda.length && ri < radici.length) coda = flCgPrendi(radici[ri++]).reverse();
    return coda.length ? coda.pop() : null;
  };
  const passo = function(){
    if (typeof flInScroll === 'function' && flInScroll()){ setTimeout(passo, 300); return; }
    const t0 = performance.now();
    let el = null;
    while (n < 600 && performance.now() - t0 < 6 && (el = prossimo())){
      if (!el.isConnected || FL_CG_FATTI.has(el) || !flHaTesto(el)) continue;
      /* chi disegna la sua carta con un fratello (l'interruttore Sogno | Mappa: la pillola bianca
         scorre sotto l'etichetta) lo dice con data-cg-no: la guardia vedrebbe solo il fondo scuro */
      if (el.closest && el.closest('[data-cg-no]')) continue;
      /* la spunta bianca di una casella vuota e' bianca su bianco APPOSTA: non si vede finche' non la scegli */
      if (el.classList && el.classList.contains('tick')) continue;
      n++;
      const st = getComputedStyle(el);
      if (st.visibility === 'hidden' || st.display === 'none') continue;
      const ink = flLuma(st.color);
      if (ink === null) continue;
      /* 0.9.303: il pulsante col gradiente del brand e' bianco con l'ombra scura APPOSTA (regola del
         brand): la guardia lo vedeva chiaro su chiaro e lo ripassava in blu notte, con l'ombra sotto. */
      if (ink >= .55 && st.textShadow && st.textShadow !== 'none') continue;
      const carta = flCarta(el);
      if (carta === null) continue;
      /* I DUE CASI. Chiaro su chiaro: l'inchiostro torna scuro. Scuro su scuro: l'inchiostro
         torna chiaro. In tutti e due la carta resta com'è: è l'inchiostro la metà che ha
         sbagliato. */
      let nuovo = null;
      if (ink >= .55 && carta >= .55) nuovo = '#0E2350';
      else if (ink < .18 && carta < .18) nuovo = '#EEF4FF';
      if (nuovo) da.push([el, nuovo, st.color, carta]);
    }
    if (n < 600 && (coda.length || ri < radici.length)){ setTimeout(passo, 0); return; }
    da.forEach(function(x){
      const el = x[0];
      const prima = el.style.getPropertyValue('color');
      FL_CG_FATTI.set(el, prima ? { v: prima, p: el.style.getPropertyPriority('color') } : null);
      el.style.setProperty('color', x[1], 'important');
      FL_CG_TOCCATI.add(el);
      if (FL_CONTRASTO.length < 40) FL_CONTRASTO.push((el.className || el.tagName) + '|' + x[2] + ' su ' + Math.round(x[3] * 100));
    });
    void document.body.offsetWidth; rimetti();
  };
  passo();
}

/* Due passate: una subito, una a transizioni finite (le carte cambiano colore in 250 ms). */
function flContrastoDopo(e){
  if (!e || e.type) FL_CG_INTERO = true;
  /* Al cambio di tema servono due passate (la carta cambia colore in 250 ms); al cambio di
     pagina ne basta una, dopo che la pagina si e' fermata: due passate su ogni schermata
     erano lavoro doppio che si sentiva come lentezza all'apertura del foglio. */
  const tema = !!(e && e.type === 'fl:tema');
  clearTimeout(FL_CG_T); FL_CG_T = setTimeout(flContrastoGuardia, tema ? 150 : 400);
  clearTimeout(FL_CG_T2); FL_CG_T2 = tema ? setTimeout(flContrastoGuardia, 700) : null;
}
['fl:screen', 'fl:tab', 'fl:tema'].forEach(function(e){ document.addEventListener(e, flContrastoDopo); });
/* 0.9.263, Andrea: micro-lag ogni pochi secondi. La guardia (centinaia di getComputedStyle) ripartiva a ogni
   fine transizione e a ogni cambio di classe: lo slideshow ne produce di continuo. Le transizioni contano solo
   subito dopo un cambio di tema (le carte cambiano colore in 250 ms), le classi non contano piu': contano le
   pagine che cambiano e i pezzi nuovi che entrano. */
let FL_CG_TEMA_AT = 0;
document.addEventListener('fl:tema', function(){ FL_CG_TEMA_AT = Date.now(); });
document.addEventListener('transitionend', function(e){
  if (Date.now() - FL_CG_TEMA_AT > 1500) return;
  const p = e && e.propertyName;
  if (p === 'color' && e.target && FL_CG_TOCCATI.has(e.target)) return;
  if (p === 'background-color' || p === 'background' || p === 'color' || p === 'opacity') flContrastoDopo();
}, true);
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(flContrastoDopo, 600);
  try{
    /* solo i pezzi che entrano o escono, e non quelli dello slideshow, della chat o dei cartelli che si ridisegnano da soli */
    new MutationObserver(function(m){
      for (let i = 0; i < m.length; i++){
        const t = m[i].target;
        if (t && t.closest && t.closest('.bh, .wk, .glw, .dt-w, #inSheet, .ag-msgs, .sd-fine, .gr-sheet')) continue;
        /* un testo che cambia (i contatori che si aggiornano ogni secondo) non e' un pezzo nuovo */
        const a = m[i].addedNodes;
        for (let j = 0; j < a.length; j++){ if (a[j].nodeType === 1) FL_CG_RADICI.add(a[j]); }
      }
      if (FL_CG_RADICI.size){ clearTimeout(FL_CG_T); FL_CG_T = setTimeout(flContrastoGuardia, 400); }
    }).observe(document.body, { childList: true, subtree: true });
  }catch(_){ }
});
