/* ===========================================================================================
   sonno.js - DOVE IL MOTORE DEL SONNO PRENDE I DATI (0.9.236)

   Il conto e' in sonno-motore.js, uno solo per tutte le schermate. Qui si raccoglie quello
   che serve, sempre dal TELEFONO e mai dalla sorgente scelta nel Report:
   - gli eventi grezzi della notte (NATIVE.getNightEvents); con un motore vecchio, che quella
     funzione non ce l'ha, i granelli della Cronologia (NATIVE.getTimeline), gli stessi che la
     pagina Ora per ora mostra;
   - le sveglie: il registro del telefono (qualunque app) e le sveglie di DreamMap;
   - l'indizio della Focus Box, se l'hai impostata.

   Ogni schermata chiede snNotteDi(mezzanotte): una lettura sola alla volta per notte (chi
   arriva mentre si legge aspetta la stessa risposta), un minuto di memoria per la notte di
   oggi, le notti chiuse salvate su disco. Sul computer qui non si misura niente: la notte la
   manda il telefono dentro al rapporto pubblicato.
   =========================================================================================== */

const SN_V = 1;                 // cambia quando cambia il modo di contare: le notti salvate si rileggono
const SN_MEM = {};
const SN_CORSA = {};

function snQuiComputer(){ try{ return typeof mwQuiComputer === 'function' && mwQuiComputer(); }catch(_){ return false; } }
function snChiave(ds){ const d = new Date(ds); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

/** La finestra della Focus Box per la notte che finisce il giorno ds, solo se l'hai impostata. */
function snIndizio(ds){
  try{
    if (!localStorage.getItem('fl_focusbox') || typeof fbFinestra !== 'function') return null;
    const f = fbFinestra(ds);
    return (f && f.a > f.da) ? { da: f.da, a: f.a } : null;
  }catch(_){ return null; }
}

/** Le sveglie di DreamMap accese, alle loro ore della sera prima e della mattina. */
function snSveglieApp(ds){
  let l = [];
  try{ l = JSON.parse(localStorage.getItem('fl_alarms') || '[]'); }catch(_){ l = []; }
  const out = [];
  (Array.isArray(l) ? l : []).forEach(function(x){
    if (!x || x.on === false || !isFinite(x.hour) || !isFinite(x.minute)) return;
    [-1, 0].forEach(function(g){
      const d = new Date(ds); d.setDate(d.getDate() + g); d.setHours(+x.hour, +x.minute, 0, 0);
      out.push(d.getTime());
    });
  });
  return out;
}

/** Gli ingredienti della notte, dal telefono. null dove non si misura (computer, browser). */
async function snDati(ds){
  if (snQuiComputer() || typeof NATIVE === 'undefined' || !NATIVE) return null;
  const da = ds - SN_CFG.primaMs, a = Math.min(Date.now(), ds + SN_CFG.dopoMs);
  if (!(a > da)) return { eventi: [], registro: [], fonte: 'eventi' };
  if (typeof NATIVE.getNightEvents === 'function'){
    try{
      const r = await NATIVE.getNightEvents({ from: da, to: a });
      if (r && r.granted === false) return { negato: true };
      if (r && Array.isArray(r.eventi)) return { eventi: r.eventi, registro: r.sveglie || [], fonte: 'eventi' };
    }catch(_){ }
  }
  if (typeof NATIVE.getTimeline === 'function'){
    try{
      const d = await NATIVE.getTimeline({ from: da, to: a, minMs: 0, limit: 6000 });
      if (d && d.granted === false) return { negato: true };
      if (d && Array.isArray(d.grani)){
        return { uso: d.grani.map(function(g){ return [+g.s, +g.s + (+g.ms || 0)]; }), registro: [], fonte: 'cronologia' };
      }
    }catch(_){ }
  }
  return null;
}

/**
 * La notte che finisce la mattina del giorno `ds` (mezzanotte locale), gia' contata.
 * null solo dove il telefono non c'e'; altrimenti una notte, con ok=false e il motivo se manca.
 */
async function snNotteDi(ds){
  const k = String(ds);
  const chiusa = Date.now() >= ds + SN_CFG.dopoMs;
  const m = SN_MEM[k];
  if (m && (chiusa || Date.now() - m.t < 60000)) return m.n;
  if (chiusa){
    try{
      const v = JSON.parse(localStorage.getItem('fl_sonno_' + snChiave(ds)) || 'null');
      if (v && v.v === SN_V && v.n){ SN_MEM[k] = { t: Date.now(), n: v.n }; return v.n; }
    }catch(_){ }
  }
  if (SN_CORSA[k]) return SN_CORSA[k];
  SN_CORSA[k] = (async function(){
    try{
      const d = await snDati(ds);
      if (!d) return null;
      let n;
      if (d.negato) n = snSnella({ ok: false, motivo: 'dati' });
      else {
        const adesso = Date.now();
        const da = ds - SN_CFG.primaMs, a = Math.min(adesso, ds + SN_CFG.dopoMs);
        const sveglie = snSveglieSuonate(d.registro, da, a, adesso).concat(snSveglieApp(ds));
        n = snSnella(snNotte({ dayStart: ds, adesso: adesso, eventi: d.eventi, uso: d.uso,
                                sveglie: sveglie, indizio: snIndizio(ds), fonte: d.fonte }));
      }
      SN_MEM[k] = { t: Date.now(), n: n };
      /* una notte chiusa si salva, salvo quando il telefono non l'aveva: domani potrebbe averla */
      if (chiusa && n && n.motivo !== 'dati'){
        try{ localStorage.setItem('fl_sonno_' + snChiave(ds), JSON.stringify({ v: SN_V, n: n })); }catch(_){ }
      }
      return n;
    }catch(_){ return null; }
    finally{ delete SN_CORSA[k]; }
  })();
  return SN_CORSA[k];
}

/** Un rapporto del giorno con dentro la notte del motore (scores.js lo chiama per ogni giorno). */
async function snConNotte(r, ds){
  if (!r || !r.granted) return r;
  let n = null;
  try{ n = await snNotteDi(ds); }catch(_){ n = null; }
  if (!n) return r;
  const o = snNelReport(r, n);
  o.sonnoV = SN_V;
  return o;
}

/** La riga della Focus Box: "Stanotte: a letto alle 00:20 · sveglia alle 07:55." */
function snRigaStanotte(n){
  if (!n) return '';
  if (!n.ok) return snFraseManca(n);
  const hh = function(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  const k = (n.interruzioni || []).length;
  return 'Stanotte: a letto alle ' + hh(n.inizio) + ' · sveglia alle ' + hh(n.sveglia)
    + (k ? ' · interrotto ' + (k === 1 ? '1 volta' : k + ' volte') : '') + '.';
}
