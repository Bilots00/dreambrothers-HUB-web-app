/* ===========================================================================================
   MAPPA — la scheda «La tua mappa» (dal prototipo di Claude Design, 27/09/2026)

   Una cosa sola per ogni tappa: gli orizzonti di Keller che l'utente ha gia' scritto
   (orizzonti.js: un giorno → cinque anni → quest'anno → questo mese → questa settimana → oggi),
   in catena, con la percentuale dei passi spuntati. Sotto, la rotta di oggi (il foglio della
   scheda START, le stesse righe, la stessa spunta) e le pagine: il sogno, il piano, il diario.

   La scheda Roadmap resta com'e' (e' la fase di transizione): qui non si sposta niente, si
   legge e si rimanda alle pagine che esistono.
   =========================================================================================== */
const MPP_ORDINE = ['ungiorno', 'cinque', 'anno', 'mese', 'settimana', 'oggi'];

function mppLivelli(){ try{ return (typeof OZ_LIVELLI !== 'undefined') ? OZ_LIVELLI : []; }catch(_){ return []; } }
function mppAnello(k){ try{ return (typeof ozAnello === 'function') ? ozAnello(k) : { testo: '', passi: [] }; }catch(_){ return { testo: '', passi: [] }; } }
function mppTask(){ try{ return String((typeof stTask === 'function') ? stTask() : '').replace(/^[☐☑•]\s*/, '').trim(); }catch(_){ return ''; } }

function mppCatenaHtml(){
  const liv = mppLivelli();
  /* 0.9.305: solo gli orizzonti che finiscono prima della data del sogno (ozVisibile, orizzonti.js) */
  const items = MPP_ORDINE.map(function(k){ return liv.filter(function(l){ return l.k === k; })[0]; }).filter(Boolean)
    .filter(function(l){ return typeof ozVisibile !== 'function' || ozVisibile(l.k); });
  if (!items.length) return '';
  let h = '<div class="mpp-catena">';
  items.forEach(function(l, i){
    const a = mppAnello(l.k);
    const oggi = l.k === 'oggi', top = i === 0;
    const testo = oggi ? (mppTask() || a.testo || 'La mossa di oggi') : (a.testo || '');
    const passi = a.passi || [];
    const fatti = passi.filter(function(p){ return p && p.fatto; }).length;
    const pct = passi.length ? Math.round(fatti / passi.length * 100) + '%' : '';
    h += '<div class="mpp-riga' + (oggi ? ' oggi' : (top ? ' top' : '')) + '"><div class="mpp-dot"><span></span>' + (i < items.length - 1 ? '<i></i>' : '') + '</div>'
      + '<button type="button" class="mpp-card" onclick="' + (oggi ? 'switchTab(\'sveglia\')' : 'if(typeof ozOpen===\'function\')ozOpen();else switchTab(\'severa\')') + '">'
      + '<div class="mpp-h"><span>' + esc(l.ico + ' ' + l.nome) + '</span><span>' + esc(pct) + '</span></div>'
      + '<b>' + (testo ? esc(testo) : '<em>Ancora da scrivere</em>') + '</b></button></div>';
  });
  return h + '</div>';
}
function mppRottaOggiHtml(){
  let righe = [];
  const day = (typeof stDayKey === 'function') ? stDayKey('today') : '';
  try{ righe = (typeof stLines === 'function') ? stLines('today') : []; }catch(_){ }
  if (!righe.length) return '<div class="mpp-sez"><b>Rotta di oggi</b></div><button type="button" class="mpp-vuoto" onclick="switchTab(\'sveglia\')">Il foglio di oggi è vuoto. Scrivi la prima riga.</button>';
  return '<div class="mpp-sez"><b>Rotta di oggi</b></div><div class="mpp-lista">' + righe.slice(0, 8).map(function(r, i){
    let fatto = false; try{ fatto = (typeof stIsDone === 'function') && stIsDone(r, day); }catch(_){ }
    const t = String(r).replace(/^[☐☑•]\s*/, '');
    return '<button type="button" class="mpp-item' + (fatto ? ' fatto' : '') + '" onclick="mppSpunta(' + i + ')"><span class="mpp-chk">' + (fatto ? '✓' : '') + '</span><span class="mpp-t">' + esc(t) + '</span></button>';
  }).join('') + '</div>';
}
function mppSpunta(i){
  try{ if (typeof stRowTick === 'function'){ stRowTick(i); setTimeout(mppPaint, 150); return; } }catch(_){ }
  switchTab('sveglia');
}
/* 0.9.309, LA CAUSA VERA di "tocco la pagina del sogno e si apre la modalita' severa". La card chiamava
   switchTab('severa'): era il nome della scheda del sogno fino alla 0.9.168, ma dalla 0.9.169 nav.js lo gira alla pagina
   della Modalita' severa (svpApri). La pagina del sogno e' la scheda Sogno, vista Sogno (quella che si personalizza
   con la copertina e l'icona di questa card): ci si va e si torna in cima, anche se si era gia' li' in fondo. */
function mppApriSogno(){
  try{ if (typeof order !== 'undefined' && order[cur] !== 's-home') goId('s-home'); }catch(_){ }
  try{ if (typeof NAV_SCROLL !== 'undefined') NAV_SCROLL.rotta = 0; }catch(_){ }
  switchTab('rotta');
  /* nel pannello "Il tuo viaggio" si apre la scheda Sogno: il sogno con la sua data d'arrivo */
  try{ if (typeof nvpVai === 'function') nvpVai('sogno'); }catch(_){ }
  const t = document.getElementById('tab-rotta');
  /* come aprire una pagina: si arriva gia' in cima, senza il viaggio all'indietro lungo tutta la scheda */
  if (t) t.scrollTop = 0;
}
function mppPagineHtml(){
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  let pagine = 0; try{ pagine = Math.max(0, (typeof dvPagine === 'function' ? dvPagine().length : 2) - 2); }catch(_){ }
  return '<div class="mpp-sez"><b>Le tue pagine</b></div><div class="mpp-pagine">'
    + '<button type="button" class="mpp-pag cover" onclick="mppApriSogno()"><div><span>' + ((typeof cstIcona === 'function') ? cstIcona() : '🎯') + '</span>' + esc(sogno ? 'Pagina del sogno' : 'Il sogno') + '</div></button>'
    + '<button type="button" class="mpp-pag" onclick="if(typeof stFullOpen===\'function\')stFullOpen();else switchTab(\'sveglia\')"><span>🗓️</span>Il piano</button>'
    + '<button type="button" class="mpp-pag" onclick="if(typeof dvApri===\'function\')dvApri()"><span>📔</span>Diario di viaggio<small>' + pagine + (pagine === 1 ? ' pagina' : ' pagine') + '</small></button>'
    + '<button type="button" class="mpp-pag film acc-bloccata" style="margin-top:0" onclick="flInArrivo()"><div><span>🎬</span>Visualizzazione</div><i class="pt-arrivo">In arrivo</i></button>'
    + '<button type="button" class="mpp-pag" onclick="if(typeof ozOpen===\'function\')ozOpen();else switchTab(\'severa\')"><span>⛰️</span>Gli orizzonti</button>'
    + '<button type="button" class="mpp-pag" onclick="switchTab(\'insights\')"><span>📊</span>Report<small>il tempo sullo schermo</small></button>'
    /* 0.9.309, Andrea: anche la pagina dei suoni per concentrarsi (sounds.js), con la sua icona di sempre */
    + '<button type="button" class="mpp-pag" onclick="if(typeof sndPaginaApri===\'function\')sndPaginaApri()"><span>🎵</span>Suoni per concentrarsi</button>'
    /* la scheda col + e' l'ULTIMA, e si chiama come nel prototipo: apre «Costruisci la tua
       mappa» sui blocchi, da cui la pagina si compone */
    + '<button type="button" class="mpp-pag tratt" onclick="if(typeof ntNuovaPagina===\'function\')ntNuovaPagina();else if(typeof cstNuovaPagina===\'function\')cstNuovaPagina()"><span>＋</span>Nuova pagina</button>'
    + '</div>';
}
/* LA SLIDESHOW IN CIMA ALLA MAPPA. La prima diapositiva e' quella che stava seconda nella
   Roadmap: la cartina dal satellite con la percentuale del viaggio e il pannello dell'arrivo
   previsto (blkhero.js: sevGloboPaint, che disegna dentro #sevGlobo ovunque stia). */
function mppHeroEnsure(){
  if (typeof flHeroEnsure !== 'function') return null;
  return flHeroEnsure('mappa', 'tab-mappa', 'mppHero', [
    '<article class="bh-slide on" data-i="0">'
    +   '<div class="bh-img"></div><span class="bh-ov"></span>'
    +   '<div class="bh-stack sev-globo" id="sevGlobo"></div>'
    + '</article>'
  ], { tall: true, auto: false });
}
/* LE DUE VISTE DELLA MAPPA (0.9.205): «Pianifico io» (le mie pagine, la mia mappa, la rotta di
   oggi) e «Rotta su misura» (il sentiero del Genio, la prossima mossa, l'agente). */
/* 0.9.276, Andrea: "quando l'utente sceglie nell'effetto farfalla, l'interruttore in alto deve sparire: chi ha scelto
   la Roadmap vede solo la Roadmap, chi ha scelto Pianifico io solo la sua Mappa". La scelta comanda la vista. */
function mppSceltaFatta(){ try{ const u = (typeof faStrada === 'function') ? faStrada() : null; return u && u.scelta ? u.scelta : ''; }catch(_){ return ''; } }
function mppVistaCur(){
  const sc = mppSceltaFatta(); if (sc) return sc === 'mia' ? 'mia' : 'rotta';
  let v = ''; try{ v = localStorage.getItem('fl_mappa_vista') || ''; }catch(_){ } return v === 'mia' ? 'mia' : 'rotta';
}
function mppVista(v){
  try{ localStorage.setItem('fl_mappa_vista', v === 'mia' ? 'mia' : 'rotta'); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  mppApplicaVista();
  try{ if (typeof hdrDreamApply === 'function') hdrDreamApply(); }catch(_){ }
}
function mppGloboStorto(g){
  const m = g.querySelector('#sevGloboMappa');
  if (!m || !m.querySelector('svg')) return true;
  const lw = parseFloat(g.dataset.lw || '0');
  return !lw || Math.abs(Math.max(200, m.clientWidth) - lw) > 6;
}
function mppApplicaVista(){
  const v = mppVistaCur();
  /* 0.9.211: lo slideshow con la mappa e le nuvole stanno solo nella Roadmap; in «Mappa ·
     pianifica tu» si arriva dritti al foglio */
  /* 0.9.237: "La prossima mossa" e' andata nella scheda Sogno, sotto alla lettura del Genio */
  { const mo = document.getElementById('mppMossa'); if (mo) mo.classList.add('mpp-via'); }
  ['mppHero', 'mppSentiero', 'mppPianoRm', 'mppAgente'].forEach(function(id){ const el = document.getElementById(id); if (el) el.classList.toggle('mpp-via', v !== 'rotta'); });
  ['mppTappa', 'mppFoglio', 'mppRoadmap', 'mppBody', 'mppPagine', 'piCard', 'spSez-mappa'].forEach(function(id){ const el = document.getElementById(id); if (el) el.classList.toggle('mpp-via', v !== 'mia'); });
  try{ if (typeof hdPiedeInnesta === 'function') hdPiedeInnesta('tab-mappa'); }catch(_){ }
  /* 0.9.294, Andrea: "passando da Mappa a Roadmap a volte la slide e' vuota, solo il cielo". La cartina disegnata mentre la
     Roadmap era nascosta misurava zero: tornando visibile si ridisegna sempre, sulla misura vera. */
  /* 0.9.300, Andrea: "la cartina continua a flashare due volte". Il ridisegno forzato a 80 e a 450 ms rimetteva in moto
     l'animazione due volte anche quando la cartina era gia' giusta. Ora si ridisegna solo se e' stata disegnata a una
     misura diversa da quella vera (sevGlobo.dataset.lw, scritto da sevGloboPaint) o non c'e'. */
  if (v === 'rotta') [80, 450].forEach(function(ms){ setTimeout(function(){ try{ const g = document.getElementById('sevGlobo'); if (g && g.offsetWidth && mppGloboStorto(g)){ delete g.dataset.firma; sevGloboPaint(); } }catch(_){ } }, ms); });
  /* il foglio di START viene qui quando si guarda «La mia mappa»; START se lo riprende da solo */
  if (v === 'mia'){
    const fo = document.getElementById('mppFoglio'), st = document.getElementById('stFocus');
    if (fo && st && st.parentElement !== fo){ fo.appendChild(st); st.classList.remove('scs-off'); try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ } }
  }
}
/* 0.9.227: il foglio entra nella Mappa anche se START si e' disegnato dopo (all'avvio, o tornando
   all'app): si controlla qualche volta nei primi secondi e ogni volta che l'app torna davanti */
function mppFoglioAdotta(){
  const tab = document.getElementById('tab-mappa'); if (!tab || tab.offsetParent === null) return;
  if (mppVistaCur() !== 'mia') return;
  const fo = document.getElementById('mppFoglio'), st = document.getElementById('stFocus');
  if (fo && st && st.parentElement !== fo){ fo.appendChild(st); st.classList.remove('scs-off'); try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ } }
}
[300, 900, 2000, 4000].forEach(function(ms){ setTimeout(mppFoglioAdotta, ms); });
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(mppFoglioAdotta, 200); });
function mppPaint(){
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  let host = document.getElementById('mppBody');
  if (!host){ host = document.createElement('div'); host.id = 'mppBody'; tab.appendChild(host); }
  mppHeroEnsure();
  /* L'ORDINE (0.9.173), sotto alle nuvole: il riscaldamento finche' non e' finito, la
     prossima mossa, «La tua mappa», la rotta di oggi, poi IL TUO AGENTE (#guidaHost di
     iofuturo.js/agente.js) e in fondo «Le tue pagine». */
  /* il riscaldamento e' andato in START (0.9.177) */
  const riscVecchio = document.getElementById('mppRisc'); if (riscVecchio) riscVecchio.remove();
  /* IL SENTIERO (sentiero-mappa.js): sezioni, capitoli, nodi, come Duolingo. Primo, sotto al cielo. */
  let sent = document.getElementById('mppSentiero');
  if (!sent){ sent = document.createElement('div'); sent.id = 'mppSentiero'; sent.className = 'mpp-slot'; tab.insertBefore(sent, host); }
  let mossa = document.getElementById('mppMossa');
  if (!mossa){ mossa = document.createElement('div'); mossa.id = 'mppMossa'; mossa.className = 'mpp-slot'; tab.insertBefore(mossa, host); }
  /* 0.9.308: in «Pianifica tu» il sentiero vero sta dentro «La tua roadmap», sotto al foglio (rmlSentieroPosto, roadmap-livelli.js):
     da li' non si riporta qui a ogni disegno */
  if (sent.parentElement === tab && sent.nextElementSibling !== mossa) tab.insertBefore(sent, mossa);
  try{ if (typeof hdrDreamApply === 'function') hdrDreamApply(); }catch(_){ }
  let ag = document.getElementById('mppAgente');
  if (!ag){ ag = document.createElement('div'); ag.id = 'mppAgente'; }
  let pag = document.getElementById('mppPagine');
  if (!pag){ pag = document.createElement('div'); pag.id = 'mppPagine'; pag.className = 'mpp-slot'; }
  /* IL FOGLIO DEL PIANO (0.9.206): nella vista «La mia mappa» c'e' lo stesso foglio di START */
  let fo = document.getElementById('mppFoglio');
  if (!fo){ fo = document.createElement('div'); fo.id = 'mppFoglio'; fo.className = 'mpp-slot mpp-foglio'; }
  /* LA PROSSIMA TAPPA (0.9.208): l'Oracolo del giorno vive qui, nella mia mappa */
  let tp = document.getElementById('mppTappa');
  if (!tp){ tp = document.createElement('div'); tp.id = 'mppTappa'; tp.className = 'mpp-slot'; }
  /* 0.9.217: sotto al foglio torna la prossima tappa (gratis) o il tuo agente personale (Premium), mappa-foglio.js */
  tp.innerHTML = (typeof mfTappaHtml === 'function') ? mfTappaHtml() : ''; tp.hidden = !tp.innerHTML;
  /* l'ordine si impone ogni volta: i nodi adottati non si ricreano, si spostano */
  /* 0.9.265: si spostano solo se l'ordine e' cambiato (flOrdina, scorre.js): prima a ogni disegno */
  if (typeof flOrdina === 'function') flOrdina(tab, [fo, tp, host, ag, pag]); else { tab.appendChild(fo); tab.appendChild(tp); tab.appendChild(host); tab.appendChild(ag); tab.appendChild(pag); }
  /* 0.9.242: la guida 1-1 (il tuo agente personale) e' andata in Dream (#nvGuida, dream-extra.js); qui resta una riga */
  ag.innerHTML = (typeof dxAgenteMiniHtml === 'function') ? dxAgenteMiniHtml() : '';
  try{ if (typeof guidaPaint === 'function') guidaPaint(); }catch(_){ }
  try{ if (typeof sevGloboPaint === 'function') sevGloboPaint(); }catch(_){ }
  { const mh = (typeof nvMossaHtml === 'function') ? nvMossaHtml() : ''; if (mossa.__h !== mh){ mossa.innerHTML = mh; mossa.__h = mh; } }
  try{ if (typeof sdHtml === 'function'){ sdAggiorna(false); if (typeof sdMetti === 'function') sdMetti(sent, sdHtml()); else sent.innerHTML = sdHtml(); } }catch(_){ }
  /* 0.9.306, Andrea: via il blocco "La tua mappa e la rotta di oggi" dalla scheda Mappa (e da Personalizza Mappa).
     #mppBody resta, vuoto e nascosto: e' il segnaposto dietro a cui si mettono il sentiero e la prossima mossa. */
  if (host.__h !== ''){ host.innerHTML = ''; host.__h = ''; }
  host.hidden = true;
  { const ph = '<div class="mpp-page mpp-page-pagine">' + mppPagineHtml() + '</div>'; if (pag.__h !== ph){ pag.innerHTML = ph; pag.__h = ph; } }
  mppApplicaVista();
  /* l'ordine scelto da «Personalizza la scheda», e il piede in fondo */
  try{ if (typeof scsApplica === 'function'){ scsApplica('mappa-mia'); scsApplica('mappa-rotta'); } }catch(_){ }
  try{ if (typeof hdPiedeInnesta === 'function') hdPiedeInnesta('tab-mappa'); }catch(_){ }
  const piede = tab.querySelector(':scope > .hd-piede'); if (piede && tab.lastElementChild !== piede) tab.appendChild(piede);
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa'){ mppPaint(); setTimeout(function(){ try{ const g = document.getElementById('sevGlobo'); if (g && g.offsetWidth && mppGloboStorto(g)){ delete g.dataset.firma; sevGloboPaint(); } }catch(_){ } }, 400); } });
document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.querySelector('#tab-mappa.on')) mppPaint(); });
document.addEventListener('fl:giorno', function(){ try{ mppPaint(); }catch(_){ } });
setTimeout(mppPaint, 1000);

(function(){
  const css = [
    '.mpp-page{display:flex;flex-direction:column;gap:24px;padding:16px 0 120px}',
    '.mpp-testa{text-align:center}.mpp-testa b{display:block;font:800 28px var(--font-display);color:var(--navy)}body.dark .mpp-testa b{color:#fff}.mpp-testa p{margin:4px 0 0;font:500 14px var(--font-body);color:var(--muted)}',
    '.mpp-catena{display:flex;flex-direction:column}',
    '.mpp-riga{display:flex;gap:12px;align-items:stretch}',
    '.mpp-dot{width:24px;flex:none;display:flex;flex-direction:column;align-items:center}.mpp-dot span{width:14px;height:14px;border-radius:7px;margin-top:22px;background:#BFD4EA;flex:none}.mpp-dot i{flex:1;width:2px;background:var(--line)}',
    '.mpp-riga.top .mpp-dot span{background:#001E44}.mpp-riga.oggi .mpp-dot span{background:#0075E3;box-shadow:0 0 0 4px rgba(0,117,227,.2)}',
    '.mpp-card{flex:1;margin-bottom:8px;background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;padding:12px 16px;text-align:left;cursor:pointer}body.dark .mpp-card{background:#12203A;border-color:#22345A}',
    '.mpp-riga.top .mpp-card{background:#001E44;border-color:#001E44}.mpp-riga.oggi .mpp-card{background:#0075E3;border-color:#0075E3}',
    '.mpp-h{display:flex;justify-content:space-between;font:600 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--faint)}.mpp-riga.top .mpp-h,.mpp-riga.oggi .mpp-h{color:rgba(255,255,255,.75)}',
    '.mpp-card b{display:block;margin-top:2px;font:700 15px/1.35 var(--font-display);color:var(--navy)}body.dark .mpp-card b{color:#fff}.mpp-riga.top .mpp-card b,.mpp-riga.oggi .mpp-card b{color:#fff}.mpp-card em{font-style:italic;opacity:.6}',
    '.mpp-sez{text-align:center}.mpp-sez b{font:800 20px var(--font-display);color:var(--navy)}body.dark .mpp-sez b{color:#fff}',
    '.mpp-lista{display:flex;flex-direction:column;gap:12px;margin-top:-8px}',
    '.mpp-item{display:flex;align-items:center;gap:12px;background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:14px 16px;text-align:left;cursor:pointer}body.dark .mpp-item{background:#12203A;border-color:#22345A}',
    '.mpp-chk{width:24px;height:24px;border-radius:12px;border:2px solid #BFD4EA;display:inline-flex;align-items:center;justify-content:center;font:800 13px var(--font-body);color:#fff;flex:none}.mpp-item.fatto .mpp-chk{background:#0075E3;border-color:#0075E3}',
    '.mpp-t{flex:1;font:500 14px var(--font-body);color:var(--navy)}body.dark .mpp-t{color:#fff}.mpp-item.fatto .mpp-t{color:var(--faint);text-decoration:line-through}',
    '.mpp-vuoto{margin-top:-8px;width:100%;border:2px dashed #BFD4EA;background:transparent;border-radius:16px;padding:16px;font:600 13px var(--font-body);color:#0075E3;cursor:pointer}',
    '.mpp-pagine{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:-8px}',
    '.mpp-pag{border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);height:120px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:var(--navy);font:700 14px var(--font-display);cursor:pointer;padding:0}body.dark .mpp-pag{background:#12203A;border-color:#22345A;color:#fff}',
    '.mpp-pag span{font-size:28px;line-height:1}.mpp-pag small{font:500 11px var(--font-body);color:var(--faint)}',
    '.mpp-pag.cover{overflow:hidden;background:#001E44 url(img/dream-night.jpg) center 75%/cover;align-items:flex-end;justify-content:flex-end;border:0}',
    '.mpp-pag.cover div{width:100%;padding:12px;background:linear-gradient(transparent,rgba(0,19,43,.85));color:#fff;text-align:left;font:700 14px var(--font-display);display:flex;align-items:center;gap:6px;box-sizing:border-box}.mpp-pag.cover span{font-size:18px}',
    '.mpp-pag.film{overflow:hidden;background:#001E44 url(img/memento-skull.jpg) center/cover;align-items:flex-end;justify-content:flex-end;border:0}',
    /* 0.9.306: al buio "body.dark .mpp-pag{background:#12203A}" pesava di piu' e cancellava il teschio di Visualization */
    'body.dark .mpp-pag.film{background:#001E44 url(img/memento-skull.jpg) center/cover;border:0}',
    '.mpp-pag.film div{width:100%;padding:12px;background:linear-gradient(transparent,rgba(0,19,43,.9));color:#fff;text-align:left;font:700 14px var(--font-display);display:flex;align-items:center;gap:6px;box-sizing:border-box}.mpp-pag.film span{font-size:18px}',
    '.mpp-page{padding-top:8px}',
    '.mpp-slot{padding:8px 0 0}.mpp-slot:empty{display:none}',
    '#mppPagine .mpp-page{padding-bottom:120px}#mppBody .mpp-page{padding-bottom:0}',
    '#mppAgente{padding-top:16px}',
    '#tab-mappa .hdr-dream button{font-size:14px;padding:8px 2px;line-height:1.15}#tab-mappa .hdr-dream button small{display:block;margin-top:2px;font:600 10px var(--font-body);letter-spacing:0;text-transform:none;opacity:.78}',
    '.mpp-foglio{padding:0}.mpp-foglio #stFocus{padding:0 18px}.mpp-tappa{display:flex;align-items:center;gap:12px;width:calc(100% - 36px);margin:4px 18px 16px;padding:14px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer}body.dark .mpp-tappa{background:#12203A;border-color:#22345A}.mpp-tappa img{width:54px;height:auto}.mpp-tappa > div{flex:1}.mpp-tappa small{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.mpp-tappa b{display:block;font:800 16px var(--font-body);color:var(--navy)}body.dark .mpp-tappa b{color:#fff}.mpp-tappa p{margin:4px 0 0;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.mpp-via{display:none !important}.hdr-prem{display:inline-block;margin-left:6px;padding:2px 7px;border-radius:99px;background:#E71D4F;color:#fff;font:800 9.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;font-style:normal;vertical-align:middle}',
    '#mppAgente{margin:8px 0 12px}#mppAgente:empty{display:none}#mppAgente #guidaHost:empty{display:none}',
    '.mpp-pag.tratt{background:transparent;border:2px dashed #BFD4EA;color:#0075E3;font:600 14px var(--font-body)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
