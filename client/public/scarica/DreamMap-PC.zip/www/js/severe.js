/* severe.js - Modalità severa: the whole AppBlock path (G22-G41).
   Intro wizard -> "Seleziona opzioni" -> "Scegli metodo d'accesso" -> "Ricorda!" -> armed,
   plus the live status screen with the exit gate the chosen method actually requires.

   Why this file was rewritten: the old version armed severity with setRules({strict:2}). The
   engine rejects that with `strict-needs-method` (see corsia N-C §3.4), so on the device the
   Estrema card produced an error and nothing was armed. Levels are now armed through
   setStrictConfig(...) with a level, an unlock method and that method's parameter, and the
   session is left through disableStrict({pin}) - never through setRules({strict:0}).

   Every screen here is registered from this module (registry.js), never from index.html:
   six lanes edit that file at once and shared markup is a guaranteed collision. */

/* ---------- WIRE CONSTANTS ----------
   Same string values as StrictMode.java (TIMER/PROGRAMS/APPROVAL/CHARGER/PAUSE/PIN/NONE):
   they travel through setStrictConfig, so a typo here is a silently wrong lock. */
const SEV_M = { TIMER:'timer', PROGRAMS:'programs', APPROVAL:'approval',
                CHARGER:'charger', PAUSE:'pause', PIN:'pin', NONE:'none' };
const SEV_MIN_PIN = 4;               // MIN_PIN_LENGTH in StrictMode.java
const SEV_INTRO_KEY = 'fl_sev_intro';
const SEV_PREVIEW_KEY = 'fl_sev_preview';
const SEV_DRAFT_KEY = 'fl_sev_draft';     // the chosen method/options, so the tab can show them before arming

const STRICT_LBL = ["disattivata", "Severa", "Estrema"];

/* The draft the wizard is filling in. It is never the source of truth: the engine is. */
let sevDraft = null;
let sevState = null;      // last known getStrictState()
let sevReinstalled = false; // mirror of Rules.blockReinstalled (G28 lives in the rules store)
let sevIntroMode = 'wizard'; // 'wizard' = continue into the options, 'replay' = just reading
let sevTick = null;
let sevTickN = 0;

function sevFreshDraft(level){
  return { level: level,
           opts: { uninstall:false, settings:false, recents:false, split:false, reinstalled:false },
           method: SEV_M.TIMER, timerMin: 0, pauseMinutes: 10, programs: [],
           pin:'', pin2:'', pinCur:'', apin:'', apin2:'', apinCur:'' };
}
/* AppBlock keeps the access method and the options on the tab itself, chosen before the
   session exists. They are stored here; the PINs are not (a PIN in localStorage is a PIN in
   every backup), so a PIN typed in one run is asked again in the next unless the engine
   already holds one. */
function sevSaveDraft(){
  const d = sevDraft; if(!d) return;
  try{ localStorage.setItem(SEV_DRAFT_KEY, JSON.stringify({ level:d.level, opts:d.opts, method:d.method,
    timerMin:d.timerMin, pauseMinutes:d.pauseMinutes, programs:d.programs })); }catch(_){ }
}
function sevLoadDraft(){
  const d = sevFreshDraft(1);
  let saved = null;
  try{ saved = JSON.parse(localStorage.getItem(SEV_DRAFT_KEY) || 'null'); }catch(_){ saved = null; }
  if(saved && typeof saved === 'object'){
    if(saved.opts) Object.keys(d.opts).forEach(k => { if(typeof saved.opts[k] === 'boolean') d.opts[k] = saved.opts[k]; });
    d.method = saved.method || SEV_M.TIMER;
    d.timerMin = +saved.timerMin || 0;
    d.pauseMinutes = +saved.pauseMinutes || 10;
    d.programs = Array.isArray(saved.programs) ? saved.programs.map(String) : [];
  }
  return d;
}
function sevDraftReady(){ if(!sevDraft) sevDraft = sevLoadDraft(); return sevDraft; }
/* The intro is for someone meeting the feature for the first time. A user who signed in with
   an account is not that person (they may have restored a backup with a session already run),
   and AppBlock does not show it to them either. */
function sevNeedsIntro(){
  if(localStorage.getItem(SEV_INTRO_KEY) === '1') return false;
  let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ u = null; }
  return !(u && (u.mail || u.provider));
}
let sevIntroAfter = null;
/* 0.9.309: si torna alla pagina della Modalita' severa da cui si era arrivati (go() lo conta come un passo indietro),
   non alla casa e poi alla pagina: indietro, dopo, porta dove si era prima. */
function sevBackToTab(){
  sevVaiPagina();
  sevBoot();
}

/* ---------- STYLE ----------
   Injected from here, prefixed `sev-`, so it cannot collide with the other five lanes.
   Everything that already exists in app.css (.screen .cta .ghost .panelcard .topbar .iconbtn
   .spacer .switch .warnbox .setrow .fin .picklist ...) is reused instead of redefined. */
(function sevStyle(){
  if(document.getElementById('sev-style')) return;
  const st = document.createElement('style');
  st.id = 'sev-style';
  st.textContent = `
.sev-h{font:800 23px/1.2 var(--font-display);font-style:italic;color:var(--navy);margin:4px 0 6px}
.sev-sub{font:500 13px/1.6 var(--font-body);color:var(--muted);margin:0 0 16px}
.sev-note{font:500 11.5px/1.55 var(--font-body);color:var(--faint);margin-top:10px}
.sev-optcard{display:flex;gap:12px;align-items:flex-start;background:#fff;border:1px solid var(--line);
  border-radius:16px;padding:14px;margin-bottom:10px}
.sev-optcard.fixed{background:#EDF3FA;border-color:#D3E1F0}
.sev-optcard .txt{flex:1;min-width:0}
.sev-optcard b{display:block;font:700 13.5px var(--font-body);color:var(--navy);margin-bottom:3px}
.sev-optcard small{display:block;font:500 11.5px/1.55 var(--font-body);color:var(--muted)}
.sev-optcard .lockw{font:700 10px var(--font-body);color:var(--faint);margin-top:6px;display:block}
.sev-mcard{display:flex;gap:12px;align-items:flex-start;background:#fff;border:2px solid var(--line);
  border-radius:16px;padding:14px;margin-bottom:10px;cursor:pointer;transition:border-color .18s,box-shadow .18s}
.sev-mcard.prem{border-style:dashed}
.sev-mcard.sel{border-color:#0075E3;box-shadow:0 10px 24px rgba(0,117,227,.16)}
.sev-mcard .mico{font-size:24px;width:34px;text-align:center;flex:none}
.sev-mcard b{display:block;font:800 15px var(--font-display);color:var(--navy);margin-bottom:4px}
.sev-mcard p{font:500 12px/1.55 var(--font-body);color:var(--muted);margin:0}
.sev-badge{display:inline-block;font:800 9.5px var(--font-body);letter-spacing:.6px;padding:3px 9px;
  border-radius:99px;text-transform:uppercase;margin-bottom:5px}
.sev-badge.hard{background:#E3F1FF;color:#005BB0}
.sev-badge.med{background:#E1F0FE;color:#0075E3}
.sev-badge.easy{background:#E2F5EA;color:#1B7F4B}
.sev-badge.prem{background:#FFF0E1;color:#B26A00}
.sev-panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px;margin:-4px 0 14px}
.sev-panel .lbl{display:block;font:700 11.5px var(--font-body);color:var(--muted);margin:0 0 6px}
.sev-chips{display:flex;flex-wrap:wrap;gap:7px}
.sev-chip{border:1px solid var(--line);background:#fff;border-radius:99px;padding:8px 13px;
  font:700 12px var(--font-body);color:var(--muted);cursor:pointer}
.sev-chip.on{background:#0075E3;border-color:#0075E3;color:#fff}
.sev-pin{width:100%;border:1px solid var(--line);border-radius:12px;padding:13px;background:#fff;
  font:700 18px var(--font-body);letter-spacing:.35em;text-align:center;color:var(--navy);margin-bottom:9px}
.sev-more{border:0;background:none;width:100%;text-align:center;cursor:pointer;padding:12px 0;
  font:700 13px var(--font-body);color:#0075E3}
.sev-remember{background:#001E44;border:2px solid #E63946;border-radius:18px;padding:16px;margin-bottom:6px}
.sev-remember .rl{display:flex;gap:10px;align-items:flex-start;margin-bottom:12px}
.sev-remember .rl:last-child{margin-bottom:0}
.sev-remember .rl i{font-style:normal;color:#E63946;font-size:15px;line-height:1.35;flex:none}
.sev-remember .rl span{font:500 12.5px/1.55 var(--font-body);color:#E6EFFA}
.sev-statecard{background:#fff;border:1px solid var(--line);border-radius:18px;padding:16px;
  box-shadow:var(--shadow);margin-bottom:12px}
/* «Pronto a bloccare?». La card si chiama sev-sp-card: con «sp-card» vinceva lo stile della scheda
   START (fondo bianco) e il testo bianco spariva (0.9.199). */
.sp-wrap{position:fixed;inset:0;z-index:9995;background:rgba(0,8,20,.72);display:flex;align-items:flex-end;justify-content:center}
.sp-in{width:100%;max-width:460px;background:#141C2C;border-radius:26px 26px 0 0;padding:12px 22px calc(26px + env(safe-area-inset-bottom,0px));
  text-align:center;color:#fff;position:relative;animation:prUp .22s ease-out}
.sp-x{position:absolute;top:16px;right:16px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(255,255,255,.1);color:#fff;font:700 15px var(--font-body);cursor:pointer}
.sp-lock{position:relative;width:118px;height:150px;margin:22px auto 16px}
.sp-lock-b{position:absolute;left:0;right:0;bottom:0;height:96px;border-radius:18px;background:linear-gradient(180deg,#0E2350,#0B1220);box-shadow:0 0 0 2px rgba(79,184,255,.25)}
.sp-lock::before{content:"";position:absolute;left:18px;right:18px;top:0;height:78px;border:12px solid #0E2350;border-bottom:0;border-radius:44px 44px 0 0;box-sizing:border-box}
.sp-lock-t{position:absolute;left:0;right:0;bottom:24px;font-size:42px;line-height:1;color:#4FB8FF}
.sp-in h3{margin:0 0 8px;font:800 27px/1.2 var(--font-display);color:#fff}
.sp-sub{margin:0 0 18px;font:500 13.5px/1.55 var(--font-body);color:rgba(200,218,242,.8)}
.sp-opt{display:flex;align-items:flex-start;gap:10px;margin:14px 0 6px;padding:12px;border-radius:14px;background:rgba(255,255,255,.06);font:500 12.5px/1.5 var(--font-body);color:rgba(200,218,242,.9);cursor:pointer}
.sp-opt input{width:20px;height:20px;margin:1px 0 0;accent-color:#3F9FF4;flex:none}
.sp-track{display:flex;gap:10px;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;margin:0 -22px;padding:0 22px 4px}
.sp-track::-webkit-scrollbar{display:none}
.sev-sp-card{flex:0 0 100%;scroll-snap-align:center;display:flex;gap:14px;align-items:flex-start;text-align:left;
  background:rgba(255,255,255,.07);border-radius:20px;padding:18px 16px;min-height:104px;box-sizing:border-box}
.sev-sp-card i{font-style:normal;font-size:26px;line-height:1;flex:none}
.sev-sp-card b{display:block;font:700 14.5px var(--font-body);color:#fff;margin-bottom:4px}
.sev-sp-card p{margin:0;font:500 13px/1.5 var(--font-body);color:rgba(200,218,242,.82)}
.sp-dots{display:flex;justify-content:center;gap:6px;margin:14px 0 18px}
.sp-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.22)}
.sp-dots i.on{background:#fff}
.sev-count{font:800 36px/1.1 var(--font-display);font-style:italic;color:var(--navy);text-align:center;margin:6px 0 2px}
.sev-count.open{color:#0075E3}
.sev-countlbl{font:600 11px var(--font-body);color:var(--muted);text-align:center;letter-spacing:.05em;
  text-transform:uppercase;margin-bottom:4px}
.sev-plist{list-style:none;margin:8px 0 0;padding:0}
.sev-plist li{display:flex;gap:9px;align-items:flex-start;font:500 12.5px/1.5 var(--font-body);
  color:var(--muted);margin-bottom:7px}
.sev-plist li i{font-style:normal;flex:none}
.sev-tabbox{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px;margin-top:12px;text-align:center}
/* The one entry point of the tab. One card, one sentence, one button: nothing here
   competes with the decision to start. */
.sev-entry{background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px 18px;margin:6px 0 4px}
.sev-entry b{display:block;font:800 17px var(--font-display);font-style:italic;color:var(--navy)}
.sev-entry p{font:500 12.5px/1.65 var(--font-body);color:var(--muted);margin:8px 0 16px}
.sev-entry .cta{width:100%}
.sev-tabbox b{display:block;font:700 13.5px var(--font-body);color:var(--navy);margin-bottom:4px}
.sev-tabbox p{font:500 12px/1.55 var(--font-body);color:var(--muted);margin-bottom:10px}
.sev-body{display:flex;flex-direction:column;flex:1;min-height:0}
.sev-dur{display:flex;gap:8px;align-items:flex-end;margin-top:6px}
.sev-dur label{flex:1;display:flex;flex-direction:column;gap:4px;font:600 10.5px var(--font-body);color:var(--muted);text-align:center;min-width:0}
.sev-dur .fin{text-align:center;padding:10px 4px;margin:0}
.sev-dur .addbtn{flex:none;height:42px}
.sev-row-missing small{color:#E63946 !important}
.sev-il{text-align:center;font-size:62px;margin:6px 0 2px}
.sev-dots{display:flex;gap:6px;justify-content:center;margin-top:12px}
.sev-dots i{width:7px;height:7px;border-radius:50%;background:#CFDDEC}
.sev-dots i.on{background:#0075E3;width:20px;border-radius:99px}
`;
  document.head.appendChild(st);
})();

/* ---------- NATIVE HELPERS ----------
   NATIVE is null in a plain browser: every call below degrades to a local preview state
   instead of leaving a promise hanging or pretending something was locked. */
function sevErr(e, fallback){
  const m = e && (e.message || e.errorMessage || e.code);
  return m ? String(m) : fallback;
}
function sevPreview(){
  let s;
  try{ s = JSON.parse(localStorage.getItem(SEV_PREVIEW_KEY) || 'null'); }catch(_){ s = null; }
  return s || { level:0, storedLevel:0, unlockMethod:SEV_M.NONE, strictUntil:0, pendingDisableAt:0,
                pauseMinutes:10, unlockAvailableAt:0, unlockInMs:0, canDisableNow:true,
                inAppEditLocked:false, uninstallGuard:false, uninstallGuardEffective:false,
                deviceAdminActive:false, settingsGuard:false, recentsGuard:false, splitScreenGuard:false,
                hasPin:false, hasApprovalPin:false, unlockPrograms:[], programsIdle:true, preview:true };
}
function sevSavePreview(s){ try{ localStorage.setItem(SEV_PREVIEW_KEY, JSON.stringify(s)); }catch(_){ } }

async function sevLoadState(){
  if(!NATIVE || typeof NATIVE.getStrictState !== 'function'){ sevState = sevPreview(); return sevState; }
  try{
    sevState = await NATIVE.getStrictState();
  }catch(e){
    // A rejected read must not leave the UI showing a stale lock as if it were live.
    sevState = null;
    toast(sevErr(e, 'Impossibile leggere lo stato della Modalità severa'));
  }
  if(NATIVE && typeof NATIVE.getRulesFull === 'function'){
    try{ const r = await NATIVE.getRulesFull(); sevReinstalled = !!(r && r.blockReinstalled); }catch(_){ }
  }
  return sevState;
}

/* ---------- SCREEN REGISTRATION ---------- */
function sevIntroScreen(id, back, icon, dot, title, body, cta, ctaFn){
  registerScreen(id, `
    <div class="topbar"><button class="iconbtn" onclick="goId('${back}')">‹</button></div>
    <div class="sev-il">${icon}</div>
    <h2 class="sev-h" style="text-align:center">${title}</h2>
    <p class="sev-sub" style="text-align:center">${body}</p>
    <div class="sev-dots">${[0,1,2,3].map(i=>`<i class="${i===dot?'on':''}"></i>`).join('')}</div>
    <div class="spacer"></div>
    <button class="cta" onclick="${ctaFn}">${cta}</button>
    <button class="ghost" onclick="sevIntroSkip()">Salta l'introduzione</button>
  `, { hero:true, back:back });
}

sevIntroScreen('sev-w1','s-home','🔒',0,
  'Che cos’è la Modalità severa',
  'Un lucchetto che si chiude sulle regole che hai già scelto. Finché è attiva, i tuoi blocchi non si possono modificare, mettere in pausa o cancellare dentro DreamMap.',
  'Esplora','sevIntroNext(2)');
sevIntroScreen('sev-w2','sev-w1','\u{1F9E0}',1,
  'Perché esiste',
  'Le regole le scrive la persona lucida di oggi. A romperle è sempre quella stanca delle undici di sera. La Modalità severa mette una distanza fra le due: protegge le tue regole da te stesso nel momento di debolezza.',
  'Continua','sevIntroNext(3)');
sevIntroScreen('sev-w3','sev-w2','\u{1F6E1}️',2,
  'Che cosa comporta',
  'Sceglierai tu che cosa tenere al sicuro: la disinstallazione dell’app, le impostazioni del telefono, le app recenti, lo schermo diviso, le app reinstallate. Nulla è attivo di default, tranne la protezione dei blocchi.',
  'Continua','sevIntroNext(4)');
sevIntroScreen('sev-w4','sev-w3','\u{1F511}',3,
  'Come si esce',
  'Ogni sessione ha sempre una porta: sceglierai tu quale. Un timer, un’attesa, un PIN, il caricabatterie, la persona di fiducia. Nessuna via d’uscita segreta, e nessuna sessione senza uscita.',
  'Ho capito','sevIntroDone()');

registerScreen('sev-options', `
  <div class="topbar"><button class="iconbtn" onclick="sevBackToTab()">‹</button>
    <b style="font:700 14px var(--font-body);color:var(--navy)">Modalità severa</b></div>
  <h2 class="sev-h">Seleziona opzioni</h2>
  <p class="sev-sub">Scegli tutto ciò che vuoi mantenere al sicuro quando la Modalità severa è attiva.</p>
  <div id="sevOptList"></div>
  <div class="sect" style="margin-top:26px"><b>Quando sta per scadere</b></div>
  <div id="sevDecBox"></div>
  <div class="spacer"></div>
  <button class="cta" onclick="sevOptionsContinue()">Fatto</button>
`, { back:'s-home' });

registerScreen('sev-method', `
  <div class="topbar"><button class="iconbtn" onclick="sevBackToTab()">‹</button>
    <b style="font:700 14px var(--font-body);color:var(--navy)">Modalità severa</b></div>
  <h2 class="sev-h">Metodo di sblocco</h2>
  <p class="sev-sub">La Modalità Severa può essere disattivata solo mediante il metodo da te selezionato.</p>
  <div id="sevMethodList"></div>
  <div class="spacer"></div>
  <button class="cta" onclick="sevMethodContinue()">Fatto</button>
`, { back:'s-home' });

registerScreen('sev-remember', `
  <div class="topbar"><button class="iconbtn" onclick="sevBackToTab()">‹</button>
    <b style="font:700 14px var(--font-body);color:var(--navy)">Modalità severa</b></div>
  <h2 class="sev-h">Ricorda!</h2>
  <p class="sev-sub">I seguenti elementi saranno bloccati come da opzioni selezionate</p>
  <div class="sev-remember" id="sevRememberList"></div>
  <p class="sev-note" id="sevRememberExit"></p>
  <div class="spacer"></div>
  <button class="cta" onclick="sevArm()">OK, ho capito</button>
  <button class="ghost" onclick="sevBackToTab()">Torna indietro</button>
`, { back:'s-home' });

/* 0.9.309: la vecchia schermata 'sev-status' ("Modalità severa attiva", con "Manca 57g 2h" e "Blinda il nuovo te")
   non c'e' piu'. Lo stato acceso vive nella pagina della Modalità severa (sevAttivaHtml), come AppBlock. */

/* ---------- LEVEL CARDS (markup lives in index.html, behaviour lives here) ----------
   The three .slevel cards carry onclick="setStrict(n)" in the frozen markup. setStrict is kept
   global and render-only because nav.js calls it once at boot; the cards are rebound to the
   real entry point, which is a wizard and not a one-tap arming. */
function setStrict(lv){ sevRenderLevel(+lv || 0); }

function sevRenderLevel(lv){
  localStorage.setItem('fl_strict', lv);
  document.querySelectorAll('.slevel').forEach(el => el.classList.toggle('sel', +el.dataset.lv === lv));
  const w = document.getElementById('strictwarn'); if(w) w.style.display = lv === 2 ? 'flex' : 'none';
  const l = document.getElementById('strictchipLbl'); if(l) l.textContent = STRICT_LBL[lv] || STRICT_LBL[0];
  const bb = document.getElementById('strictBubble'); if(bb) bb.classList.toggle('on', lv > 0);
}

(function sevBindCards(){
  document.querySelectorAll('.slevel').forEach(el => {
    const lv = +el.dataset.lv;
    el.onclick = function(){ sevPickLevel(lv); };
  });
})();

async function sevPickLevel(lv){
  const s = await sevLoadState();
  const active = s ? (s.level || 0) : 0;
  if(active > 0 && lv === active){ sevOpenStatus(); return; }
  if(lv === 0){
    if(active === 0){ toast('La Modalità severa è già disattivata'); return; }
    sevOpenStatus();   // leaving is a gate, not a tap: the status screen owns the exit
    return;
  }
  if(active > 0){
    // A live session cannot be re-armed from here: the engine refuses anything that loosens it,
    // and a card that pretends otherwise is the bug this file exists to remove.
    toast('C’è già una sessione attiva: esci prima di cambiare livello');
    sevOpenStatus();
    return;
  }
  sevDraftReady().level = lv;
  sevActivate();
}

/* The single way in, now that the three level cards are gone.

   Severity is no longer something you declare up front: it is the sum of what you chose to
   protect and of how you allowed yourself to get out. So the draft starts at the ordinary
   strict level and the wizard decides the rest, instead of asking for a commitment before
   anything has been explained. */
async function sevStart(){ return sevActivate(); }

/* "Attiva Modalità severa": the method and the options were chosen on the tab; here they
   are checked once more (the engine will check them again) and the Ricorda! screen follows. */
async function sevActivate(){
  const st = await sevLoadState();
  if(st && st.level){ sevOpenStatus(); return; }
  if(sevGate(sevActivate)) return;
  const d = sevDraftReady();
  if(!d.method) d.method = SEV_M.TIMER;
  if(d.method === SEV_M.TIMER && !d.timerMin){ svtApri('imposta'); return; }
  if(d.method === SEV_M.PIN && !d.pin && !(sevState && sevState.hasPin)){ toast('Imposta il codice PIN'); sevOpenMethod(); return; }
  if(d.method === SEV_M.APPROVAL && !d.apin && !(sevState && sevState.hasApprovalPin)){ toast('Imposta il PIN della persona di fiducia'); sevOpenMethod(); return; }
  if(!sevMethodValid(d)) { sevOpenMethod(); return; }
  /* 0.9.315, Andrea: la richiesta dell'amministratore dispositivi va fatta SEMPRE prima di attivare, non solo con la levetta
     accesa: a modalita' severa attiva le Impostazioni sono bloccate. Si puo' proseguire senza, ma lo si sceglie. */
  if(await sevAdminAttivo()){ d.opts.uninstall = true; sevSaveDraft(); sevProntoApri(); return; }
  sevAdminApri(sevProntoApri, true);
}

/* ---------- «PRONTO A BLOCCARE?» ----------
   Il cartello di AppBlock al posto della pagina con l'elenco e i triangoli rossi. Una card
   alla volta, che scorre col dito: un elenco di sei righe si legge come un contratto, cioe'
   non si legge; sei card viste una per una si leggono tutte. Sono solo quelle delle opzioni
   scelte — le produce sevRememberLines() dai toggle — perche' un avviso su qualcosa che non si
   e' acceso insegna a saltare anche gli altri. */
function sevProntoApri(){
  const righe = sevRememberLines();
  let w = document.getElementById('sevPronto');
  if(!w){
    w = document.createElement('div');
    w.id = 'sevPronto';
    w.className = 'sp-wrap';
    w.addEventListener('click', function(e){ if(e.target === w) sevProntoChiudi(); });
    document.body.appendChild(w);
  }
  w.innerHTML = '<div class="sp-in">'
    + '<i class="pr-grab"></i>'
    + '<button type="button" class="sp-x" onclick="sevProntoChiudi()" aria-label="Chiudi">✕</button>'
    + '<div class="sp-lock"><span class="sp-lock-b"></span><span class="sp-lock-t">⏱</span></div>'
    + '<h3>Pronto a bloccare?</h3>'
    + '<p class="sp-sub">' + esc(sevExitSentence().replace(/^Uscita: /, 'Uscita: ')) + '</p>'
    + '<div class="sp-track" id="spTrack" onscroll="sevProntoDots()">'
    +   righe.map(function(r){
          return '<div class="sev-sp-card"><i>\u{1F6E1}\uFE0F</i><div><b>Tieni presente che…</b><p>' + esc(r) + '</p></div></div>';
        }).join('')
    + '</div>'
    + '<div class="sp-dots" id="spDots">' + righe.map(function(_, i){ return '<i class="' + (i ? '' : 'on') + '"></i>'; }).join('') + '</div>'
    + '<button type="button" class="cta" onclick="sevProntoVai()">Sì, attivalo</button>'
    + '</div>';
  w.hidden = false;
}
function sevProntoDots(){
  const t = document.getElementById('spTrack'), d = document.getElementById('spDots');
  if(!t || !d || !t.firstElementChild) return;
  const larg = t.firstElementChild.getBoundingClientRect().width + 10;
  const i = Math.round(t.scrollLeft / Math.max(1, larg));
  Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
}
function sevProntoChiudi(){ const w = document.getElementById('sevPronto'); if(w) w.remove(); }
function sevProntoVai(){
  sevProntoChiudi(); sevArm();
}
function sevOpenMethod(){
  if(sevGate(sevOpenMethod)) return;
  sevDraftReady();
  if(sevDraft.method === SEV_M.PROGRAMS) sevLoadPrograms();
  sevRenderMethods();
  goId('sev-method');
}

/* ---------- INTRO WIZARD (G39) ---------- */
function sevIntroNext(n){ goId('sev-w' + n); }
function sevIntroSkip(){ sevIntroDone(); }
function sevIntroDone(){
  localStorage.setItem(SEV_INTRO_KEY, '1');
  const after = sevIntroAfter; sevIntroAfter = null;
  sevIntroMode = 'wizard';
  if(typeof after === 'function'){ after(); return; }
  sevBackToTab();
}
/* Entry point from Aiuto e feedback, so the explanation is never lost after the first run. */
function sevReplayIntro(){ sevIntroMode = 'replay'; sevIntroAfter = null; goId('sev-w1'); }
/* First contact only: the wizard runs once, then hands over to what the user tapped. */
function sevGate(fn){
  if(sevNeedsIntro()){ sevIntroMode = 'wizard'; sevIntroAfter = fn; goId('sev-w1'); return true; }
  return false;
}

/* ---------- "SELEZIONA OPZIONI" (G22-G28) ----------
   Texts are AppBlock's, verbatim, with the app name swapped. The first toggle is always on and
   not modifiable (it is StrictMode.isInAppEditLocked: there is nothing to store). */
const SEV_OPTS = [
  { key:'inapp', fixed:true, title:'Blocca i blocchi nelle app',
    sub:'Non potrai accedere a modifiche, interruzioni o cancellazioni dei tuoi blocchi su DreamMap.' },
  { key:'uninstall', title:'Disattiva disinstallazione DreamMap',
    sub:'Non potrai disinstallare DreamMap.' },
  { key:'settings', title:'Blocca impostazioni dispositivo',
    sub:'Non potrai bypassare i tuoi blocchi tramite le impostazioni del tuo telefono.' },
  { key:'recents', title:'Blocca app recenti',
    sub:'Non potrai accedere alla schermata App recenti e interrompere l’esecuzione di DreamMap da là.' },
  { key:'split', title:'Blocca schermo diviso',
    sub:'Non potrai usare la modalità di schermo diviso.' },
  { key:'reinstalled', title:'Blocca applicazioni reinstallate',
    sub:'Conserveremo le applicazioni non installate tra i tuoi blocchi. Non potrai evitare il blocco durante la reinstallazione.' },
  /* 0.9.200: stava nel riquadro «Pronto a bloccare?»; Andrea la vuole qui, con le altre opzioni.
     Non va nella bozza: vale da subito (costruisci.js, fl_cst_blocco). */
  { key:'sogno', title:'Blocca la pagina del sogno',
    sub:'Copertina, colore e blocchi della pagina del sogno restano come sono finché la Modalità severa è accesa.' },
  /* 0.9.290, Andrea: "l'utente deve poter scegliere di non poter cambiare le regole della partita" */
  { key:'regole', title:'Blocca le regole della partita',
    sub:'Il modo di giocare e le regole del nuovo te contro il vecchio te restano come sono finché la Modalità severa è accesa.' }
];

function sevOpenOptions(){
  setTimeout(sevDecPaint, 30);
  if(sevGate(sevOpenOptions)) return;
  sevDraftReady();
  sevRenderOptions();
  goId('sev-options');
}

function sevRenderOptions(){
  const host = document.getElementById('sevOptList');
  if(!host || !sevDraft) return;
  host.innerHTML = SEV_OPTS.map(o => {
    const on = o.fixed ? true : (o.key === 'sogno' ? (typeof cstBloccoSevera === 'function' && cstBloccoSevera()) : (o.key === 'regole' ? sevRegoleBloccate() : !!sevDraft.opts[o.key]));
    const warn = (o.key === 'uninstall' && on && sevState && !sevState.deviceAdminActive)
      ? '<span class="lockw">In attesa del consenso di sistema: apri la richiesta e concedi l’amministratore dispositivo.</span>' : '';
    return `<div class="sev-optcard${o.fixed?' fixed':''}">
      <div class="txt"><b>${esc(o.title)}</b><small>${esc(o.sub)}</small>${warn}</div>
      <button class="switch${on?' on':''}" ${o.fixed?'disabled aria-disabled="true"':''}
        onclick="${o.fixed?'sevFixedInfo()':`sevToggleOpt('${o.key}')`}"></button>
    </div>`;
  }).join('')
  /* 0.9.242: le sezioni di DreamMap che distraggono (blocchi-sezioni.js), bloccate a severa accesa */
  + (typeof bsSevOpzioniHtml === 'function' ? bsSevOpzioniHtml() : '');
}

function sevRegoleBloccate(){ try{ return localStorage.getItem('fl_sev_regole') === '1'; }catch(_){ return false; } }
function sevFixedInfo(){ toast('Questa protezione è sempre attiva: è il cuore della Modalità severa'); }

async function sevToggleOpt(key){
  if(!sevDraft) return;
  if(key === 'sogno'){
    if(typeof cstBloccoSeveraSet === 'function') cstBloccoSeveraSet(!(typeof cstBloccoSevera === 'function' && cstBloccoSevera()));
    sevRenderOptions();
    return;
  }
  if(key === 'regole'){
    /* si accende quando vuoi; si spegne solo a Modalita' severa spenta, come tutto quello che allenta */
    const ora = sevRegoleBloccate();
    if(ora && typeof cstSeveraAccesa === 'function' && cstSeveraAccesa()){ toast('Si spegne quando la Modalità severa è spenta'); return; }
    try{ localStorage.setItem('fl_sev_regole', ora ? '0' : '1'); }catch(_){ }
    sevRenderOptions();
    return;
  }
  const next = !sevDraft.opts[key];
  if(key === 'uninstall' && next){
    // Device admin is opt-in and only counts when Android says yes (R11): the switch shows the
    // wish, the sub-line below it shows the fact, and they are allowed to disagree.
    /* 0.9.310: se manca, prima la schermata "Autorizzazione mancante" (come AppBlock), che apre la richiesta */
    sevDraft.opts[key] = true;
    sevRenderOptions();
    if(await sevAdminAttivo()){ toast('Protezione dalla disinstallazione già attiva'); sevRenderOptions(); return; }
    sevAdminApri(sevRenderOptions);
    return;
  }
  if(key === 'uninstall' && !next && NATIVE && typeof NATIVE.removeDeviceAdmin === 'function'){
    // Never refused, at any severity (R11): the same switch is two taps away in Settings.
    try{ await NATIVE.removeDeviceAdmin(); }catch(e){ toast(sevErr(e, 'Impossibile revocare l’amministratore')); }
  }
  sevDraft.opts[key] = next;
  sevRenderOptions();
}

function sevOptionsContinue(){
  sevDraftReady();
  sevSaveDraft();
  sevBackToTab();
}

/* ---------- "SCEGLI METODO D'ACCESSO" (G29-G37) ---------- */
const SEV_METHODS = [
  { id:SEV_M.TIMER, icon:'⏱️', name:'Timer', badge:'DIFFICILE', cls:'hard',
    desc:'La Modalità Severa sarà disattivata alla scadenza del tempo impostato.' },
  { id:SEV_M.PROGRAMS, icon:'\u{1F4C5}', name:'Segui programmi', badge:'DIFFICILE', cls:'hard',
    desc:'Potrai disattivare la Modalità Severa quando i programmi selezionati non sono attivi.' },
  { id:SEV_M.APPROVAL, icon:'✅', name:'Approvazione', badge:'DIFFICILE', cls:'hard',
    desc:'La Modalità Severa sarà disattivata da te o dalla tua persona di fiducia.' },
  { id:SEV_M.CHARGER, icon:'\u{1F50C}', name:'Caricabatteria', badge:'MEDIO', cls:'med',
    desc:'La Modalità Severa sarà disattivata collegando il dispositivo ad un caricabatterie.' },
  { id:SEV_M.PAUSE, icon:'⏳', name:'Pausa', badge:'MEDIO', cls:'med',
    desc:'La Modalità Severa sarà disattivata aspettando il periodo di pausa.' },
  { id:SEV_M.PIN, icon:'\u{1F522}', name:'Codice PIN', badge:'FACILE', cls:'easy',
    desc:'Potrai disattivare la funzione mediante il codice PIN impostato.' }
];
/* There is no "no method" option any more. A session you cannot end on purpose is not a
   stricter setting, it is a missing door: whoever wanted one can set a timer, which is the
   same thing said honestly. SEV_M.NONE survives only to read a session armed by an older
   build, never to arm a new one. */
const SEV_METHODS_MORE = [];

/* "1 giorno 3 ore", "45 min": the unit follows the size, as AppBlock prints it. */
function sevFmtDur(min){
  min = Math.max(0, Math.round(min || 0));
  const d = Math.floor(min/1440), h = Math.floor((min%1440)/60), m = min%60;
  const out = [];
  if(d) out.push(d + (d===1 ? ' giorno' : ' giorni'));
  if(h) out.push(h + (h===1 ? ' ora' : ' ore'));
  if(m || !out.length) out.push(m + ' min');
  return out.join(' ');
}
/* 0.9.309: niente piu' SEV_TIMER_MAX_DAYS = 274. Era il tetto del timer (il campo dei giorni e il salvataggio che
   tagliava a 274 giorni): il motore non ne ha mai avuto uno. I rulli arrivano a 3650 giorni (svtApri). */
const SEV_PAUSE_PRESETS = [{m:5,l:'5 min'},{m:10,l:'10 min'},{m:30,l:'30 min'},{m:60,l:'1 ora'},{m:180,l:'3 ore'}];

function sevMethodCard(m){
  const sel = sevDraft && sevDraft.method === m.id;
  return `<div class="sev-mcard${m.prem?' prem':''}${sel?' sel':''}" onclick="sevPickMethod('${m.id}')">
      <div class="mico">${m.icon}</div>
      <div style="flex:1;min-width:0">
        <span class="sev-badge ${m.cls}">${m.prem?'\u{1F48E} ':''}${esc(m.badge)}</span>
        <b>${esc(m.name)}</b><p>${esc(m.desc)}</p>
      </div>
    </div>${sel ? sevMethodPanel(m.id) : ''}`;
}

function sevRenderMethods(){
  const host = document.getElementById('sevMethodList');
  if(!host || !sevDraft) return;
  host.innerHTML = SEV_METHODS.map(sevMethodCard).join('');
}

function sevPickMethod(id){
  if(!sevDraft) return;
  sevDraft.method = id;
  if(id === SEV_M.PROGRAMS) sevLoadPrograms();
  sevRenderMethods();
  if(id === SEV_M.TIMER) setTimeout(svtFoglioApri, 60);
}

function sevMethodPanel(id){
  const d = sevDraft;
  if(id === SEV_M.TIMER){
    return `<div class="sev-panel" style="text-align:center">
      <span class="lbl">Per quanto tempo resta attiva</span>
      <p class="sev-note" style="margin:0 0 12px">${d.timerMin ? esc(sevFmtDur(d.timerMin)) + ', fine prevista il ' + esc(sevWhen(d.timerMin)) + '.' : 'Nessuna durata impostata.'}</p>
      <button class="cta" onclick="svtFoglioApri()">${d.timerMin ? 'Cambia la durata' : 'Imposta il timer'}</button>
    </div>`;
  }
  if(id === SEV_M.PAUSE){
    return `<div class="sev-panel">
      <span class="lbl">Quanto dovrai aspettare dopo aver chiesto di uscire</span>
      <div class="sev-chips">${SEV_PAUSE_PRESETS.map(p=>
        `<button class="sev-chip${d.pauseMinutes===p.m?' on':''}" onclick="sevSetPause(${p.m})">${p.l}</button>`).join('')}</div>
      <p class="sev-note">L’attesa parte quando premi “Voglio uscire”, non prima. Un secondo tocco non la fa ripartire.</p>
    </div>`;
  }
  if(id === SEV_M.PIN){
    const has = sevState && sevState.hasPin;
    return `<div class="sev-panel">
      ${has ? `<span class="lbl">PIN attuale</span>
        <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevPinCur"
          oninput="sevDraft.pinCur=this.value" value="${esc(d.pinCur)}">` : ''}
      <span class="lbl">Nuovo codice PIN (almeno ${SEV_MIN_PIN} cifre)</span>
      <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevPin1"
        oninput="sevDraft.pin=this.value" value="${esc(d.pin)}">
      <span class="lbl">Conferma il codice</span>
      <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevPin2"
        oninput="sevDraft.pin2=this.value" value="${esc(d.pin2)}">
      <p class="sev-note">Il PIN resta sul telefono, salvato solo come impronta: non viaggia e non è recuperabile. Se lo dimentichi, l’unica uscita è la scadenza.</p>
    </div>`;
  }
  if(id === SEV_M.APPROVAL){
    const has = sevState && sevState.hasApprovalPin;
    return `<div class="sev-panel">
      <p class="sev-note" style="margin:0 0 10px">Approvazione in presenza: la tua persona di fiducia imposta qui un secondo PIN che conosce solo lei, e la sessione finisce quando è lei a digitarlo. Niente email, niente account, niente esce dal telefono.</p>
      ${has ? `<span class="lbl">PIN di approvazione attuale</span>
        <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevApinCur"
          oninput="sevDraft.apinCur=this.value" value="${esc(d.apinCur)}">` : ''}
      <span class="lbl">PIN della persona di fiducia (almeno ${SEV_MIN_PIN} cifre)</span>
      <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevApin1"
        oninput="sevDraft.apin=this.value" value="${esc(d.apin)}">
      <span class="lbl">Conferma</span>
      <input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevApin2"
        oninput="sevDraft.apin2=this.value" value="${esc(d.apin2)}">
      <p class="sev-note">Passa il telefono alla persona di fiducia mentre digita: se lo vedi tu, non è più una serratura.</p>
    </div>`;
  }
  if(id === SEV_M.CHARGER){
    return `<div class="sev-panel">
      <p class="sev-note" style="margin:0">La sessione finisce quando colleghi il telefono a un caricabatterie. Funziona bene se il caricabatterie sta in un’altra stanza: l’attesa è la distanza che devi percorrere.</p>
    </div>`;
  }
  if(id === SEV_M.PROGRAMS){
    const list = (sevProgramsCache || []);
    return `<div class="sev-panel">
      <span class="lbl">Potrai uscire quando questi programmi non sono attivi</span>
      ${list.length ? `<div class="picklist">${list.map(p=>
        `<div class="pickrow" onclick="sevToggleProgram('${esc(String(p.id))}')">
          <input type="checkbox" ${d.programs.indexOf(String(p.id))>=0?'checked':''} onclick="event.stopPropagation();sevToggleProgram('${esc(String(p.id))}')">
          <div><div class="pl">${esc(p.name || 'Programma')}</div><div class="ps">${esc(p.type || '')}</div></div>
        </div>`).join('')}</div>`
        : '<p class="sev-note" style="margin:0">Nessun programma da seguire: creane uno nella scheda Blocco.</p>'}
      <p class="sev-note">Se non ne selezioni nessuno, il motore considera tutti i programmi attivi: il cancello resta chiuso finché uno di loro sta lavorando.</p>
    </div>`;
  }
  return '';
}

let sevProgramsCache = null;
async function sevLoadPrograms(){
  if(sevProgramsCache) return;
  if(!NATIVE || typeof NATIVE.getSchedules !== 'function'){ sevProgramsCache = []; sevRenderMethods(); return; }
  try{
    const r = await NATIVE.getSchedules();
    sevProgramsCache = (r && r.schedules) ? r.schedules : [];
  }catch(e){
    sevProgramsCache = [];
    toast(sevErr(e, 'Impossibile leggere i programmi'));
  }
  sevRenderMethods();
}
function sevToggleProgram(id){
  if(!sevDraft) return;
  const i = sevDraft.programs.indexOf(id);
  if(i >= 0) sevDraft.programs.splice(i,1); else sevDraft.programs.push(id);
  sevRenderMethods();
}
function sevSetTimer(min){ if(sevDraft){ sevDraft.timerMin = Math.max(0, Math.round(+min || 0)); sevRenderMethods(); } }
function sevSetPause(min){ if(sevDraft){ sevDraft.pauseMinutes = min; sevRenderMethods(); } }

function sevWhen(min){
  const d = new Date(Date.now() + min*60000);
  const dd = String(d.getDate()).padStart(2,'0'), mm = String(d.getMonth()+1).padStart(2,'0');
  const hh = String(d.getHours()).padStart(2,'0'), mi = String(d.getMinutes()).padStart(2,'0');
  return `${dd}/${mm} alle ${hh}:${mi}`;
}

/* True when the chosen method has everything it needs. A PIN already held by the engine counts:
   the user is not asked to retype it just to leave this screen. */
function sevMethodValid(d){
  if(!d.method){ toast('Scegli come potrai uscire dalla Modalità severa'); return false; }
  if(d.method === SEV_M.TIMER && !d.timerMin){ toast('Imposta la durata del timer'); return false; }
  if(d.method === SEV_M.PIN || d.method === SEV_M.APPROVAL){
    const a = d.method === SEV_M.PIN ? d.pin : d.apin;
    const b = d.method === SEV_M.PIN ? d.pin2 : d.apin2;
    const held = d.method === SEV_M.PIN ? (sevState && sevState.hasPin) : (sevState && sevState.hasApprovalPin);
    if(!a && held) return true;
    if(!a || a.length < SEV_MIN_PIN){ toast(`Il PIN deve avere almeno ${SEV_MIN_PIN} cifre`); return false; }
    if(a !== b){ toast('I due codici non coincidono'); return false; }
  }
  if(d.method === SEV_M.PAUSE && (!d.pauseMinutes || d.pauseMinutes < 1)){ toast('Scegli quanti minuti di attesa'); return false; }
  return true;
}
function sevMethodContinue(){
  const d = sevDraftReady();
  if(!sevMethodValid(d)) return;
  sevSaveDraft();
  sevBackToTab();
}

/* ---------- "RICORDA!" (G38) ----------
   Derived from the toggles actually chosen, not a fixed list: showing a warning about something
   the user did not switch on would train them to stop reading it.
   AppBlock's fifth line ("Le app di pagamento possono essere bloccate") is deliberately absent:
   our overlay excludes payment apps and system consent screens (R12), so printing it would be
   a warning about something this engine never does. */
function sevRememberLines(){
  const o = sevDraft ? sevDraft.opts : {};
  const out = ['Non potrai modificare, mettere in pausa o cancellare i tuoi blocchi in DreamMap.'];
  if(o.uninstall) out.push('Non potrai disinstallare DreamMap.');
  if(o.settings){
    out.push('Le impostazioni del dispositivo saranno bloccate');
    out.push('Anche la concessione di permessi alle app potrebbe essere bloccata');
  }
  if(o.recents) out.push('L’arresto delle app in background nella finestra di dialogo App attive verrà bloccato');
  if(o.split) out.push('Non potrai usare la modalità di schermo diviso.');
  if(o.reinstalled) out.push('Le app che disinstalli restano tra i tuoi blocchi: reinstallarle non le sbloccherà.');
  return out;
}

function sevExitSentence(){
  const d = sevDraft; if(!d) return '';
  switch(d.method){
    case SEV_M.TIMER: return 'Uscita: automatica dopo ' + sevFmtDur(d.timerMin) + ' (' + sevWhen(d.timerMin) + ').';
    case SEV_M.PAUSE: return 'Uscita: chiedi di uscire e aspetta ' + d.pauseMinutes + ' minuti.';
    case SEV_M.PIN: return 'Uscita: il codice PIN che hai appena impostato.';
    case SEV_M.APPROVAL: return 'Uscita: il PIN della tua persona di fiducia.';
    case SEV_M.CHARGER: return 'Uscita: collega il telefono a un caricabatterie.';
    case SEV_M.PROGRAMS: return 'Uscita: quando i programmi selezionati non sono attivi.';
    case SEV_M.NONE: return 'Uscita: solo alla scadenza' + (d.timerMin ? ' (' + sevWhen(d.timerMin) + ').' : ', al massimo fra nove mesi.');
    default: return '';
  }
}

function sevRenderRemember(){
  const host = document.getElementById('sevRememberList');
  if(host) host.innerHTML = sevRememberLines()
    .map(t => `<div class="rl"><i>⚠</i><span>${esc(t)}</span></div>`).join('');
  const ex = document.getElementById('sevRememberExit');
  if(ex) ex.textContent = sevExitSentence();
}

/* ---------- ARMING (the correction: setStrictConfig, never setRules({strict})) ---------- */
async function sevArm(){
  const d = sevDraft;
  if(!d) return;

  if(!NATIVE || typeof NATIVE.setStrictConfig !== 'function'){
    const s = sevPreview();
    s.level = d.level; s.storedLevel = d.level; s.unlockMethod = d.method;
    s.strictUntil = d.timerMin ? Date.now() + d.timerMin*60000 : 0;
    s.unlockAvailableAt = d.method === SEV_M.TIMER ? s.strictUntil : 0;
    s.pauseMinutes = d.pauseMinutes; s.pendingDisableAt = 0;
    s.inAppEditLocked = true; s.canDisableNow = false;
    s.uninstallGuard = !!d.opts.uninstall; s.settingsGuard = !!d.opts.settings;
    s.recentsGuard = !!d.opts.recents; s.splitScreenGuard = !!d.opts.split;
    s.hasPin = !!d.pin || s.hasPin; s.hasApprovalPin = !!d.apin || s.hasApprovalPin;
    s.unlockPrograms = d.programs.slice(); s.programsIdle = true;
    sevSavePreview(s); sevState = s; sevReinstalled = !!d.opts.reinstalled;
    try{ localStorage.setItem(SVH_INIZIO_KEY, JSON.stringify({ start: Date.now(), until: s.strictUntil })); }catch(_){ }
    sevRenderLevel(d.level);
    toast('Anteprima: nel browser non c’è nessun motore da armare');
    sevOpenStatus();
    return;
  }

  // 1) Secrets first. setPin/setApprovalPin are the only calls here that reject, and a session
  //    armed on a PIN that was never stored would be a session with no door.
  try{
    if(d.method === SEV_M.PIN && d.pin){
      const args = { pin:d.pin };
      if(sevState && sevState.hasPin && d.pinCur) args.current = d.pinCur;
      await NATIVE.setPin(args);
    }
    if(d.method === SEV_M.APPROVAL && d.apin){
      const args = { pin:d.apin };
      if(sevState && sevState.hasApprovalPin && d.apinCur) args.current = d.apinCur;
      await NATIVE.setApprovalPin(args);
    }
  }catch(e){
    const c = e && e.code;
    toast(c === 'pin-wrong' ? 'Il PIN attuale non è corretto'
        : c === 'bad-pin' ? `Il PIN deve avere almeno ${SEV_MIN_PIN} cifre`
        : sevErr(e, 'Impossibile salvare il PIN'));
    return;
  }

  // 2) The level, the method and its parameter, in one call. setStrictConfig never rejects:
  //    applied:false means something was refused, and the user deserves to know which switch.
  const cfg = {
    level: d.level,
    unlockMethod: d.method,
    strictUntil: d.timerMin ? Date.now() + d.timerMin*60000 : 0,
    uninstallGuard: !!d.opts.uninstall,
    settingsGuard: !!d.opts.settings,
    recentsGuard: !!d.opts.recents,
    splitScreenGuard: !!d.opts.split
  };
  // Only the parameter the chosen method actually uses: a key the engine cannot honour
  // after arming would otherwise be reported as "not applied" on every session.
  if(d.method === SEV_M.PAUSE) cfg.pauseMinutes = d.pauseMinutes;
  if(d.method === SEV_M.PROGRAMS) cfg.unlockPrograms = d.programs;
  let res;
  try{ res = await NATIVE.setStrictConfig(cfg); }
  catch(e){ toast(sevErr(e, 'Impossibile attivare la Modalità severa')); return; }

  sevState = res || null;
  try{ localStorage.setItem(SVH_INIZIO_KEY, JSON.stringify({ start: Date.now(), until: (res && res.strictUntil) || cfg.strictUntil })); }catch(_){ }
  /* IL GIORNO DELL'ARMAMENTO, scritto una volta: se il segno della serie si perde (backup
     ripristinato, versione vecchia, disco ripulito) la serie si ricostruisce da qui invece
     che ripartire da oggi. */
  try{
    if (sevState && (sevState.level || 0) >= 1 && !localStorage.getItem('fl_sev_armed'))
      localStorage.setItem('fl_sev_armed', (typeof blkToday === 'function') ? blkToday() : new Date().toISOString().slice(0, 10));
  }catch(_){ }

  // 3) "Blocca applicazioni reinstallate" lives in the rules store, not in StrictMode.
  if(typeof NATIVE.setRulesFull === 'function'){
    try{ await NATIVE.setRulesFull({ blockReinstalled: !!d.opts.reinstalled }); sevReinstalled = !!d.opts.reinstalled; }
    catch(e){ toast(sevErr(e, 'Le app reinstallate non sono state salvate')); }
  }

  if(res && res.applied === false){
    toast(sevMismatch(cfg, res) || 'Alcune opzioni non sono state applicate dal motore');
  }else{
    toast(d.level === 2 ? 'Modalità Estrema attiva \u{1F512}' : 'Modalità Severa attiva \u{1F512}');
  }
  sevRenderLevel((sevState && sevState.level) || 0);
  sevSaveDraft();
  sevSyncTab();
  sevOpenStatus();
}

/* Names the first switch the engine did not move, so a refusal has a subject. */
function sevMismatch(want, got){
  if(!got) return '';
  const pairs = [
    ['level','Il livello di severità non è stato cambiato'],
    ['unlockMethod','Il metodo di sblocco non è stato cambiato'],
    ['uninstallGuard','La protezione dalla disinstallazione non è stata applicata'],
    ['settingsGuard','Il blocco delle impostazioni non è stato applicato'],
    ['recentsGuard','Il blocco delle app recenti non è stato applicato'],
    ['splitScreenGuard','Il blocco dello schermo diviso non è stato applicato']
  ];
  for(let i=0;i<pairs.length;i++){
    const k = pairs[i][0];
    if(want[k] !== undefined && got[k] !== undefined && String(want[k]) !== String(got[k])) return pairs[i][1];
  }
  return '';
}

/* ---------- LA PAGINA DELLA MODALITA' SEVERA (0.9.309, ritratto di AppBlock) ----------
   Una pagina sola, accesa o spenta, come AppBlock: il cerchio col lucchetto (chiuso con l'anello del tempo che resta,
   aperto quando e' spenta), lo stato grande, cosa e' bloccato, il metodo di sblocco a due meta', le opzioni avanzate e
   il pulsante grande. La vecchia "Modalita' severa attiva" (sev-status, con "Manca" e "Blinda il nuovo te") non c'e'
   piu': ogni porta (il lucchetto in alto, Impostazioni, la pagina Blocco, lo sblocco di emergenza) arriva qui. */
function sevVaiPagina(){
  const p = document.getElementById('s-severa-pagina');
  if (p && p.classList.contains('active')){ sevSyncTab(); sevPaginaTick(); return; }
  if (typeof svpApri === 'function') svpApri(); else goId('s-home');
}
function sevOpenStatus(){ sevVaiPagina(); }
/* La bolla del lucchetto: lo stato si ricarica prima di mostrarlo, o il conto partirebbe dal numero di quando si e'
   aperta l'app. */
async function sevApriStato(){
  try{ await sevLoadState(); }catch(_){ }
  sevVaiPagina();
}
function sevLeaveStatus(){ svhStop(); flIndietro(); }
async function sevRefreshStatus(){ await sevLoadState(); sevRenderLevel((sevState && sevState.level) || 0); sevSyncTab(); }

/* La firma di uno stato: le cose che, se cambiano, cambiano TUTTA la pagina e non solo il numero. */
function sevFirma(s){
  if (!s) return 'niente';
  return [s.level || 0, s.canDisableNow ? 1 : 0, s.unlockMethod || '', s.pendingDisableAt || 0,
          sevRemain(s) <= 0 ? 'fine' : 'corre'].join('|');
}

/* ---------- le icone ---------- */
function svhLuc(px, aperto){
  return aperto
    ? '<svg viewBox="0 0 24 24" width="' + px + '" height="' + px + '" aria-hidden="true"><path d="M14.6 10.6V7.4a3.9 3.9 0 0 1 7.8 0v1.8" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"/><rect x="2.6" y="10.6" width="14" height="10.4" rx="2.6" fill="currentColor"/></svg>'
    : '<svg viewBox="0 0 24 24" width="' + px + '" height="' + px + '" aria-hidden="true"><path d="M7.6 10.6V7.9a4.4 4.4 0 0 1 8.8 0v2.7" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"/><rect x="5" y="10.6" width="14" height="10.4" rx="2.6" fill="currentColor"/></svg>';
}
const SVH_LUCCHETTO = '<svg viewBox="0 0 24 24" width="46" height="46" aria-hidden="true"><path d="M7.6 10.6V7.9a4.4 4.4 0 0 1 8.8 0v2.7" fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round"/><rect x="5" y="10.6" width="14" height="10.4" rx="2.6" fill="#fff"/></svg>';
const SVH_GIU = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const SVH_TIMER = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.6"/><path d="M12 12 8.6 8.6"/><path d="M12 3.4V5"/></svg>';
const SVH_ICONE = {
  timer: SVH_TIMER,
  programs: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  approval: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.6"/><path d="M2.8 20c.6-3.4 3.2-5.4 6.2-5.4 1.6 0 3 .5 4.1 1.4"/><path d="m15 18 2.2 2.2L21.5 16"/></svg>',
  charger: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3v5M15 3v5M6.5 8h11v3.5a5.5 5.5 0 0 1-11 0z"/><path d="M12 17v4"/></svg>',
  pause: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6.5 3h11M6.5 21h11"/><path d="M7.5 3c0 5 9 5 9 9s-9 4-9 9M16.5 3c0 5-9 5-9 9s9 4 9 9"/></svg>',
  pin: '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><circle cx="6" cy="6" r="1.9"/><circle cx="12" cy="6" r="1.9"/><circle cx="18" cy="6" r="1.9"/><circle cx="6" cy="12" r="1.9"/><circle cx="12" cy="12" r="1.9"/><circle cx="18" cy="12" r="1.9"/><circle cx="12" cy="18" r="1.9"/></svg>'
};
const SVH_INGRANAGGIO = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>';
const SVH_X = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';

/* ---------- i numeri ---------- */
function svhDue(n){ return String(n).padStart(2, '0'); }
/* "2m", "1h 30m", "3g 4h": il metodo di sblocco li scrive cosi', come AppBlock */
function svhBreve(min){
  min = Math.max(0, Math.round(min || 0));
  const g = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60;
  const p = [];
  if (g) p.push(g + 'g');
  if (h) p.push(h + 'h');
  if (m || !p.length) p.push(m + 'm');
  return p.join(' ');
}
/* "fino alle 15:04", "fino a domani alle 9:00", "fino al 26/12 alle 15:58" (e l'anno, se non e' questo) */
function svhFino(at){
  const f = new Date(at), oggi = new Date();
  const ora = svhDue(f.getHours()) + ':' + svhDue(f.getMinutes());
  if (f.toDateString() === oggi.toDateString()) return 'fino alle ' + ora;
  const dom = new Date(oggi.getFullYear(), oggi.getMonth(), oggi.getDate() + 1);
  if (f.toDateString() === dom.toDateString()) return 'fino a domani alle ' + ora;
  return 'fino al ' + svhDue(f.getDate()) + '/' + svhDue(f.getMonth() + 1) + (f.getFullYear() !== oggi.getFullYear() ? '/' + f.getFullYear() : '') + ' alle ' + ora;
}
/* "1m 49s, fino alle 15:04" */
function svhConto(s){
  const ms = sevRemain(s);
  if (s.canDisableNow || ms === 0) return 'Puoi disattivare la Modalità severa adesso';
  if (ms < 0){
    const m = s.unlockMethod;
    return m === SEV_M.PIN ? 'Si disattiva con il tuo codice PIN'
      : m === SEV_M.APPROVAL ? 'Si disattiva con il PIN della tua persona di fiducia'
      : m === SEV_M.CHARGER ? 'Si disattiva dopo aver collegato il caricabatterie'
      : m === SEV_M.PROGRAMS ? 'Si disattiva quando i programmi scelti sono fermi'
      : m === SEV_M.PAUSE ? 'Si disattiva dopo ' + (s.pauseMinutes || 10) + ' minuti di attesa, da quando la chiedi'
      : 'Attiva';
  }
  let t = Math.ceil(ms / 1000);
  const g = Math.floor(t / 86400); t -= g * 86400;
  const h = Math.floor(t / 3600); t -= h * 3600;
  const m = Math.floor(t / 60); const sec = t - m * 60;
  const pezzi = (g ? g + 'g ' : '') + ((g || h) ? h + 'h ' : '') + ((g || h || m) ? m + 'm ' : '') + sec + 's';
  return pezzi + ', ' + svhFino(Date.now() + ms);
}
/* L'inizio della sessione, per l'anello: quanto manca su quanto era. Scritto da sevArm; una proroga allunga la fine e
   tiene l'inizio. Una sessione armata da una versione vecchia parte da quando la si guarda (anello pieno). */
const SVH_INIZIO_KEY = 'fl_sev_inizio';
function svhInizio(s){
  const until = +(s && s.strictUntil) || 0;
  let r = null; try{ r = JSON.parse(localStorage.getItem(SVH_INIZIO_KEY) || 'null'); }catch(_){ r = null; }
  if (r && r.start && r.until === until) return r;
  if (r && r.start && r.start < until && until > (r.until || 0) && (r.until || 0) > 0) r = { start: r.start, until: until };
  else r = { start: Date.now(), until: until };
  try{ localStorage.setItem(SVH_INIZIO_KEY, JSON.stringify(r)); }catch(_){ }
  return r;
}
function svhFrazione(s){
  const ms = sevRemain(s);
  if (ms < 0) return 1;
  if (s.unlockMethod === SEV_M.PAUSE) return Math.max(0, Math.min(1, ms / Math.max(60000, (s.pauseMinutes || 10) * 60000)));
  const r = svhInizio(s);
  return Math.max(0, Math.min(1, ms / Math.max(1, r.until - r.start)));
}
const SVH_C = 2 * Math.PI * 92;

/* ---------- cosa e' bloccato ---------- */
function svhVoci(s){
  const voci = ['Metti in pausa il programma', 'Cambia giorni', 'Cambia intervalli di tempo', 'Elimina blocco', 'Interrompi blocco rapido'];
  const avanzate = [];
  const d = (sevDraft && sevDraft.opts) ? sevDraft.opts : {};
  const acceso = function(k, st){ return (s && s.level) ? !!s[st] : !!d[k]; };
  if (acceso('uninstall', 'uninstallGuard')) avanzate.push('Disattiva disinstallazione DreamMap');
  if (acceso('settings', 'settingsGuard')) avanzate.push('Blocca impostazioni dispositivo');
  if (acceso('recents', 'recentsGuard')) avanzate.push('Blocca app recenti');
  if (acceso('split', 'splitScreenGuard')) avanzate.push('Blocca schermo diviso');
  try{ if (sevRegoleBloccate()) avanzate.push('Cambia le regole della partita'); }catch(_){ }
  return { voci: voci, avanzate: avanzate };
}
/* Le righe col lucchetto scorrono una alla volta, dall'alto in basso, come su AppBlock. */
function svhGiroHtml(lista){
  const righe = lista.concat(lista.length > 1 ? [lista[0]] : []);
  return '<div class="svh-giro" data-n="' + lista.length + '"><div class="svh-giro-in">'
    + righe.map(function(v){ return '<span>' + svhLuc(17) + '<b>' + esc(v) + '</b></span>'; }).join('')
    + '</div></div>';
}
let SVH_GIRO = 0;
function svhGiroAvanti(){
  const g = document.querySelector('#s-severa-pagina .svh-giro'); if (!g) return;
  const n = +g.dataset.n || 0; if (n < 2) return;
  const inn = g.firstElementChild, h = g.offsetHeight || 26;
  SVH_GIRO++;
  inn.style.transition = 'transform .45s ease';
  inn.style.transform = 'translateY(' + (-SVH_GIRO * h) + 'px)';
  if (SVH_GIRO >= n){
    setTimeout(function(){ inn.style.transition = 'none'; inn.style.transform = 'translateY(0)'; SVH_GIRO = 0; }, 500);
  }
}

/* ---------- il metodo di sblocco: due meta', come AppBlock ---------- */
function svhTotaleMin(s){ const r = svhInizio(s); return Math.max(1, Math.round((r.until - r.start) / 60000)); }
function svhSelettoreHtml(s, attiva){
  const d = sevDraftReady();
  const m = attiva ? (s.unlockMethod && s.unlockMethod !== SEV_M.NONE ? s.unlockMethod : SEV_M.TIMER) : (d.method || SEV_M.TIMER);
  let destra = null;
  if (m === SEV_M.TIMER){
    destra = attiva ? { t: svhBreve(svhTotaleMin(s)), f: 'svtApri(\'prolunga\')' }
                    : { t: d.timerMin ? svhBreve(d.timerMin) : 'Imposta', f: 'svtApri(\'imposta\')' };
  } else if (m === SEV_M.PAUSE){
    destra = { t: svhBreve(attiva ? (s.pauseMinutes || 10) : (d.pauseMinutes || 10)), f: attiva ? 'svhMetodoInfo()' : 'sevOpenMethod()' };
  } else if (m === SEV_M.PIN || m === SEV_M.APPROVAL){
    const ha = m === SEV_M.PIN ? (d.pin || (sevState && sevState.hasPin)) : (d.apin || (sevState && sevState.hasApprovalPin));
    destra = { t: ha ? 'Impostato' : 'Da impostare', f: attiva ? 'svhMetodoInfo()' : 'sevOpenMethod()' };
  } else if (m === SEV_M.PROGRAMS){
    const n = attiva ? ((s.unlockPrograms || []).length) : d.programs.length;
    destra = { t: n ? (n === 1 ? '1 scelto' : n + ' scelti') : 'Tutti', f: attiva ? 'svhMetodoInfo()' : 'sevOpenMethod()' };
  }
  return '<small class="svh-lbl">Metodo di sblocco</small>'
    + '<div class="svh-metodo' + (destra ? '' : ' solo') + '">'
    +   '<button type="button" class="svh-m1" onclick="' + (attiva ? 'svhMetodoInfo()' : 'sevOpenMethod()') + '">' + (SVH_ICONE[m] || SVH_TIMER) + '<b>' + esc(sevMethodName(m)) + '</b>' + SVH_GIU + '</button>'
    +   (destra ? '<i></i><button type="button" class="svh-m2" onclick="' + destra.f + '"><b id="svhDurata">' + esc(destra.t) + '</b>' + SVH_GIU + '</button>' : '')
    + '</div>';
}
function svhMetodoInfo(){ if (typeof toast === 'function') toast('Con la Modalità severa attiva il metodo di sblocco non si cambia'); }

/* ---------- il pulsante grande ---------- */
function svhAzioneHtml(s){
  if (s.canDisableNow) return '<button type="button" class="svh-cta rossa" onclick="sevExitNow()">Disattiva la Modalità severa</button>';
  const m = s.unlockMethod;
  if (m === SEV_M.PIN || m === SEV_M.APPROVAL)
    return '<button type="button" class="svh-cta" onclick="svhPinApri()">' + (m === SEV_M.PIN ? 'Disattiva con il PIN' : 'Disattiva con la persona di fiducia') + '</button>';
  if (m === SEV_M.PAUSE)
    return s.pendingDisableAt
      ? '<button type="button" class="svh-cta grigia" onclick="sevCancelPause()">Annulla la richiesta</button>'
      : '<button type="button" class="svh-cta grigia" onclick="sevRequestPause()">Avvia l’attesa per uscire</button>';
  /* MAI UN PULSANTE D'USCITA SPENTO: finche' non si puo' uscire, c'e' la cosa da fare. */
  if (m === SEV_M.CHARGER) return '<p class="svh-nota">Collega il telefono a un caricabatterie: poi potrai disattivare la Modalità severa da qui.</p>';
  if (m === SEV_M.PROGRAMS) return '<p class="svh-nota">Un programma scelto è attivo adesso: potrai disattivare la Modalità severa quando finisce.</p>';
  /* 0.9.311, Andrea: chiaro si mimetizzava con lo sfondo. Rosso, come il vecchio "Blinda il nuovo te". */
  return '<button type="button" class="svh-cta rossa" onclick="svtApri(\'prolunga\')">\ud83d\udd12 Blinda il nuovo te</button>';
}

/* ---------- accesa (724) ---------- */
function sevAttivaHtml(s){
  const v = svhVoci(s);
  const off = (SVH_C * (1 - svhFrazione(s))).toFixed(2);
  return '<div class="svh on">'
    + '<div class="svh-cerchio"><svg class="svh-anello" viewBox="0 0 200 200" aria-hidden="true"><defs><linearGradient id="svhGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#BCE0FF"/><stop offset=".45" stop-color="#3F9FF4"/><stop offset="1" stop-color="#0075E3"/></linearGradient></defs>'
    +   '<circle class="svh-binario" cx="100" cy="100" r="92"/>'
    +   '<circle class="svh-arco" id="svhArco" cx="100" cy="100" r="92" transform="rotate(-90 100 100)" stroke-dasharray="' + SVH_C.toFixed(2) + '" stroke-dashoffset="' + off + '"/></svg>'
    +   '<span class="svh-disco">' + svhLuc(54) + '</span></div>'
    + '<h2 class="svh-tit">Attiva</h2>'
    + '<p class="svh-conto" id="svhConto">' + esc(svhConto(s)) + '</p>'
    + svhGiroHtml(v.avanzate.concat(v.voci))
    + '<i class="svh-molla"></i>'
    + svhSelettoreHtml(s, true)
    + '<button type="button" class="svh-avanzate" onclick="sevOpenOptions()"><i class="svh-av-ic">' + SVH_INGRANAGGIO + '</i><b>Opzioni avanzate</b><svg class="svh-av-ch" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>'
    + svhAzioneHtml(s)
    + '</div>';
}
/* ---------- spenta (727) ---------- */
function sevSpentaHtml(){
  const v = svhVoci(null);
  return '<div class="svh off">'
    + '<div class="svh-cerchio piccolo"><span class="svh-disco">' + svhLuc(40, true) + '</span></div>'
    + '<h2 class="svh-tit spento">I tuoi blocchi sono disattivati</h2>'
    + '<p class="svh-sotto">Cosa è bloccato quando è attiva:</p>'
    + svhGiroHtml(v.voci.slice().reverse().concat(v.avanzate))
    + '<i class="svh-molla"></i>'
    + svhSelettoreHtml(null, false)
    + '<button type="button" class="svh-avanzate" onclick="sevOpenOptions()"><i class="svh-av-ic">' + SVH_INGRANAGGIO + '</i><b>Opzioni avanzate</b><svg class="svh-av-ch" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>'
    + '<button type="button" class="svh-cta" onclick="sevActivate()">Attiva blocco</button>'
    + '</div>';
}

/* ---------- il conto che scorre ----------
   Un giro al secondo finche' la pagina e' davanti: il conto, l'anello e le righe col lucchetto. Ogni dieci secondi si
   ricontrolla il motore, e appena il conto locale arriva a zero si ricontrolla SUBITO: e' l'istante in cui la risposta
   puo' essere cambiata. Se cambia lo stato (scaduta, sbloccata) si ridisegna la pagina intera, e si resta qui. */
let SVH_TICK = 0, SVH_N = 0, SVH_FIRMA = '';
function svhStop(){ if (SVH_TICK){ clearInterval(SVH_TICK); SVH_TICK = 0; } }
function sevAttivaTick(){ sevPaginaTick(); }
function sevStopTick(){ svhStop(); }
function sevPaginaTick(){
  svhStop();
  SVH_N = 0; SVH_GIRO = 0;
  SVH_FIRMA = sevFirma(sevState);
  SVH_TICK = setInterval(async function(){
    const pag = document.getElementById('s-severa-pagina');
    if (!pag || !pag.classList.contains('active')){ svhStop(); return; }
    SVH_N++;
    if (SVH_N % 3 === 0) svhGiroAvanti();
    const s = sevState;
    const viva = !!(s && s.level);
    if (viva){
      const finito = sevRemain(s) === 0 && !s.canDisableNow;
      if (SVH_N % 10 === 0 || finito) await sevLoadState();
    } else if (SVH_N % 15 === 0) await sevLoadState();
    const f = sevFirma(sevState);
    if (f !== SVH_FIRMA){
      const eraViva = SVH_FIRMA.charAt(0) !== '0' && SVH_FIRMA !== 'niente';
      SVH_FIRMA = f;
      try{ sevRenderLevel((sevState && sevState.level) || 0); }catch(_){ }
      sevSyncTab();
      if (eraViva && !(sevState && sevState.level) && typeof toast === 'function') toast('La Modalità severa è finita: i tuoi blocchi si possono di nuovo cambiare');
      return;
    }
    if (sevState && sevState.level){
      const c = document.getElementById('svhConto'); if (c) c.textContent = svhConto(sevState);
      const a = document.getElementById('svhArco'); if (a) a.setAttribute('stroke-dashoffset', (SVH_C * (1 - svhFrazione(sevState))).toFixed(2));
    }
  }, 1000);
}
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-severa-pagina') sevPaginaTick(); });

/* ---------- i fogli: il PIN per uscire ---------- */
function svhFoglio(id, corpo){
  let w = document.getElementById(id); if (w) w.remove();
  w = document.createElement('div'); w.id = id; w.className = 'svt-velo';
  w.innerHTML = '<div class="svt-foglio"><i class="svt-grab"></i><button type="button" class="svt-x" aria-label="Chiudi" onclick="svhFoglioChiudi(\'' + id + '\')">' + SVH_X + '</button>' + corpo + '</div>';
  w.addEventListener('click', function(e){ if (e.target === w) svhFoglioChiudi(id); });
  (document.getElementById('phone') || document.body).appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  return w;
}
function svhFoglioChiudi(id){
  const w = document.getElementById(id); if (!w) return;
  w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 220);
}
function svhChiudiFogli(){ ['svtFoglio', 'svhPin'].forEach(function(id){ const w = document.getElementById(id); if (w) w.remove(); }); }
function svhPinApri(){
  const ap = sevState && sevState.unlockMethod === SEV_M.APPROVAL;
  svhFoglio('svhPin', '<h3>' + (ap ? 'Il PIN della persona di fiducia' : 'Inserisci il codice PIN') + '</h3>'
    + '<p class="svt-sub">' + (ap ? 'Passa il telefono alla tua persona di fiducia: il PIN lo digita lei.' : 'Con il PIN giusto la Modalità severa si disattiva subito.') + '</p>'
    + '<input class="sev-pin" type="password" inputmode="numeric" maxlength="12" id="sevExitPin" autocomplete="off">'
    + '<button type="button" class="svh-cta rossa" onclick="sevExitWithPin()">Disattiva la Modalità severa</button>');
  setTimeout(function(){ const i = document.getElementById('sevExitPin'); if (i) i.focus(); }, 250);
}

/* ---------- IMPOSTA IL TIMER (725 pagina, 726 foglio) ----------
   Tre rulli, giorni | ore | min, che si fermano al centro: la riga scelta e' nella fascia, e ogni scatto e' una tacca
   di vibrazione. NESSUN TETTO: il rullo dei giorni arriva a dieci anni e il salvataggio non taglia niente (prima il
   campo dei giorni si fermava a 274 e il salvataggio tagliava a 274 con "una sessione non può essere per sempre"). */
const SVT_H = 48;
/* 0.9.310, Andrea: "non voglio i giorni infiniti: massimo un anno". */
const SVT_MAX_G = 365;
const SVT = { modo: 'imposta' };
function svtColonna(u, max){
  let r = '';
  for (let i = 0; i <= max; i++) r += '<div class="svt-n">' + i + '</div>';
  return '<div class="svt-col" data-u="' + u + '"><div class="svt-rullo">' + r + '</div><span class="svt-u"></span></div>';
}
function svtRulliHtml(){
  return '<div class="svt-pannello"><i class="svt-banda"></i>' + svtColonna('g', SVT_MAX_G) + svtColonna('h', 23) + svtColonna('m', 59) + '</div>';
}
function svtEtichetta(u, i){ return u === 'g' ? (i === 1 ? 'giorno' : 'giorni') : u === 'h' ? (i === 1 ? 'ora' : 'ore') : 'min'; }
function svtMonta(root, min){
  min = Math.max(0, Math.round(min || 0));
  const v = { g: Math.floor(min / 1440), h: Math.floor((min % 1440) / 60), m: min % 60 };
  root._svt = v;
  root.querySelectorAll('.svt-col').forEach(function(col){
    const u = col.dataset.u, r = col.querySelector('.svt-rullo'), lab = col.querySelector('.svt-u');
    const max = r.children.length - 1;
    const segna = function(i){
      const vecchio = r._v;
      if (vecchio >= 0) for (let k = vecchio - 2; k <= vecchio + 2; k++){ const el = r.children[k]; if (el) el.className = 'svt-n'; }
      for (let k = i - 2; k <= i + 2; k++){ const el = r.children[k]; if (el) el.className = 'svt-n' + (k === i ? ' sel' : (Math.abs(k - i) === 1 ? ' v1' : ' v2')); }
      r._v = i;
      lab.textContent = svtEtichetta(u, i);
      /* 0.9.315: il rullo e' largo quanto le cifre che si vedono: numero e unita' stanno sempre al centro della colonna */
      r.style.width = (String(Math.min(max, i + 2)).length * 18) + 'px';
    };
    r._v = -1;
    if (v[u] > max) v[u] = max;
    segna(v[u]);
    r.scrollTop = v[u] * SVT_H;
    r.addEventListener('scroll', function(){
      const i = Math.max(0, Math.min(max, Math.round(r.scrollTop / SVT_H)));
      if (i === r._v) return;
      segna(i);
      try{ flTacca(); }catch(_){ }
      v[u] = i;
      svtAggiorna(root);
    }, { passive: true });
    /* un tocco su un numero lo porta al centro */
    r.addEventListener('click', function(e){
      const n = e.target && e.target.closest ? e.target.closest('.svt-n') : null; if (!n) return;
      const i = Array.prototype.indexOf.call(r.children, n);
      if (i >= 0) r.scrollTo({ top: i * SVT_H, behavior: 'smooth' });
    });
  });
  svtAggiorna(root);
}
function svtTotale(root){ const v = root._svt || { g: 0, h: 0, m: 0 }; return v.g * 1440 + v.h * 60 + v.m; }
function svtBase(modo){
  if (modo !== 'prolunga') return Date.now();
  const u = +(sevState && sevState.strictUntil) || 0;
  return Math.max(Date.now(), u);
}
/* "Termina il 30/10 alle 15:03." (con l'anno, quando non e' questo) */
function svtTermina(at){
  const f = new Date(at), oggi = new Date();
  return 'Termina il ' + svhDue(f.getDate()) + '/' + svhDue(f.getMonth() + 1) + (f.getFullYear() !== oggi.getFullYear() ? '/' + f.getFullYear() : '')
    + ' alle ' + svhDue(f.getHours()) + ':' + svhDue(f.getMinutes()) + '.';
}
function svtAggiorna(root){
  const tot = svtTotale(root);
  const fine = root.querySelector('[data-svt-fine]');
  if (fine) fine.textContent = svtTermina(svtBase(root.dataset.modo) + tot * 60000);
  const b = root.querySelector('[data-svt-salva]');
  if (b) b.disabled = tot < 1;
}
registerScreen('s-sev-timer',
  '<div class="topbar svt-top"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" id="svtTitolo">Imposta il timer</b><span></span></div>'
  + '<div id="svtCorpo" class="svt-corpo"></div>',
  { back: function(){ return 's-severa-pagina'; } });
function svtApri(modo){
  SVT.modo = modo === 'prolunga' ? 'prolunga' : 'imposta';
  if (SVT.modo === 'prolunga' && !(sevState && sevState.level)){ SVT.modo = 'imposta'; }
  const d = sevDraftReady();
  const t = document.getElementById('svtTitolo');
  if (t) t.textContent = SVT.modo === 'prolunga' ? 'Prolunga il timer' : 'Imposta il timer';
  const c = document.getElementById('svtCorpo'); if (!c) return;
  c.dataset.modo = SVT.modo;
  c.innerHTML = svtRulliHtml()
    + '<p class="svt-fine" data-svt-fine></p>'
    + (SVT.modo === 'prolunga' ? '<p class="svt-sub">Il tempo che scegli si aggiunge a quello che resta. Poi non si torna indietro.</p>' : '')
    + '<div class="spacer"></div>'
    + '<button type="button" class="svh-cta svt-salva" data-svt-salva onclick="svtSalva()" disabled>Salva</button>';
  goId('s-sev-timer');
  requestAnimationFrame(function(){ svtMonta(c, SVT.modo === 'prolunga' ? 0 : (d.method === SEV_M.TIMER || !d.method ? d.timerMin : 0)); });
}
async function svtSalva(){
  const c = document.getElementById('svtCorpo'); if (!c) return;
  const tot = svtTotale(c);
  if (tot < 1) return;
  if (c.dataset.modo === 'prolunga'){
    flIndietro();
    await sevProlungaMin(tot);
    return;
  }
  const d = sevDraftReady();
  d.method = SEV_M.TIMER; d.timerMin = tot;
  sevSaveDraft();
  flIndietro();
  setTimeout(sevSyncTab, 40);
}
/* il foglio, dalla pagina dei metodi (726) */
function svtFoglioApri(){
  const d = sevDraftReady();
  const w = svhFoglio('svtFoglio', '<h3>Imposta il timer</h3>' + svtRulliHtml()
    + '<p class="svt-fine" data-svt-fine></p>'
    + '<button type="button" class="svh-cta svt-salva" data-svt-salva onclick="svtFoglioSalva()" disabled>Salva</button>');
  const f = w.querySelector('.svt-foglio'); f.dataset.modo = 'imposta';
  requestAnimationFrame(function(){ svtMonta(f, d.timerMin || 0); });
}
function svtFoglioSalva(){
  const w = document.getElementById('svtFoglio'); if (!w) return;
  const f = w.querySelector('.svt-foglio');
  const tot = svtTotale(f); if (tot < 1) return;
  const d = sevDraftReady();
  d.method = SEV_M.TIMER; d.timerMin = tot;
  sevSaveDraft();
  svhFoglioChiudi('svtFoglio');
  sevRenderMethods();
  sevSyncTab();
}

/* La pagina della (i): "Cosa è bloccato quando è attiva", come AppBlock */
function svhInfoApri(){
  const v = svhVoci(sevState || {});
  const lista = function(a){ return '<div class="svi-lista">' + a.map(function(x){ return '<div class="svi-r"><span class="svi-ic">' + SVH_LUCCHETTO.replace('width="46" height="46"', 'width="20" height="20"') + '</span><b>' + esc(x) + '</b></div>'; }).join('') + '</div>'; };
  const body = document.getElementById('sviBody');
  if (body) body.innerHTML = '<h1 class="svi-tit">Cosa è bloccato quando è attiva:</h1>' + lista(v.voci)
    + (v.avanzate.length ? '<small class="svi-sez">Opzioni avanzate</small>' + lista(v.avanzate) : '');
  goId('s-sev-info');
}
registerScreen('s-sev-info',
  '<div class="topbar"><button class="iconbtn svi-x" onclick="flIndietro()" aria-label="Chiudi">' + SVH_X + '</button></div><div id="sviBody"></div><div class="spacer"></div>',
  { back: function(){ return 's-severa-pagina'; } });

(function(){
  const st = document.createElement('style');
  st.id = 'svh-style';
  st.textContent = [
    '#svpHost > .sev-intro{display:none!important}',
    '.svh{display:flex;flex-direction:column;align-items:center;text-align:center;padding:6px 0 4px}',
    '#svpHost .svh{min-height:calc(100vh - 118px);min-height:calc(100dvh - 118px);box-sizing:border-box;padding-bottom:18px}',
    '.svh-molla{flex:1 1 0;min-height:4px;display:block}',
    '.svh-cerchio{position:relative;width:200px;height:200px;margin:4px 0 22px;flex:none}',
    '.svh-anello{position:absolute;inset:0;width:100%;height:100%;transform:scaleX(-1);overflow:visible}',
    '.svh-binario{fill:none;stroke:rgba(0,117,227,.13);stroke-width:9}',
    '.svh-arco{fill:none;stroke:url(#svhGrad);stroke-width:9;stroke-linecap:round;transition:stroke-dashoffset .9s linear;filter:drop-shadow(0 0 6px rgba(63,159,244,.55))}',
    '.svh-disco{position:absolute;inset:15px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;background:radial-gradient(circle at 50% 42%,#0E2350 0 52%,#14306A 78%,#1F4F9E 100%);box-shadow:inset 0 0 0 1.5px rgba(140,198,255,.28),0 16px 40px rgba(0,60,140,.28)}',
    '.svh-cerchio.piccolo{width:124px;height:124px;margin:10px 0 30px}',
    '.svh-cerchio.piccolo .svh-disco{inset:0;background:radial-gradient(circle at 50% 40%,#173A75,#0E2350 70%);box-shadow:inset 0 0 0 2.5px rgba(188,224,255,.55),0 14px 32px rgba(0,30,68,.22)}',
    '.svh-tit{margin:0;font:800 36px/1.12 var(--font-display);color:var(--navy);letter-spacing:-.01em}',
    '.svh-tit.spento{font-size:30px;line-height:1.18;color:#6A7A92;max-width:330px}',
    '.svh-conto{margin:10px 0 0;font:600 16px/1.4 var(--font-body);color:var(--muted);font-variant-numeric:tabular-nums}',
    '.svh-sotto{margin:14px 0 0;font:500 15.5px/1.4 var(--font-body);color:var(--muted)}',
    '.svh-giro{height:28px;overflow:hidden;margin:12px 0 0;width:100%;-webkit-mask-image:linear-gradient(transparent,#000 22%,#000 78%,transparent);mask-image:linear-gradient(transparent,#000 22%,#000 78%,transparent)}',
    '.svh-giro-in{will-change:transform}',
    '.svh-giro span{height:28px;display:flex;align-items:center;justify-content:center;gap:7px;color:var(--faint)}',
    '.svh-giro b{font:700 15.5px var(--font-body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.svh.on .svh-giro span{color:#0075E3}',
    '.svh-lbl{display:block;margin:26px 0 10px;font:600 13px var(--font-body);letter-spacing:.07em;text-transform:uppercase;color:var(--muted)}',
    '.svh-metodo{width:100%;display:flex;align-items:stretch;min-height:62px;border-radius:50px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line),0 6px 18px rgba(0,30,68,.06)}',
    '.svh-metodo > i{width:1.5px;margin:12px 0;background:var(--line);flex:none}',
    '.svh-m1,.svh-m2{flex:1;min-width:0;display:flex;align-items:center;gap:10px;padding:0 18px;border:0;background:transparent;cursor:pointer;font:inherit;color:var(--muted)}',
    '.svh-m1{border-radius:50px 0 0 50px}.svh-m2{border-radius:0 50px 50px 0}.svh-metodo.solo .svh-m1{border-radius:50px}',
    '.svh-m1 > svg:first-child{color:#0075E3;flex:none}.svh.on .svh-m1 > svg:first-child{color:var(--muted)}',
    '.svh-m1 b,.svh-m2 b{flex:1;min-width:0;text-align:left;font:700 17px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.svh-m1:active,.svh-m2:active{background:rgba(0,117,227,.06)}',
    /* 0.9.314, Andrea: niente bordo. Una riga bianca come il selettore del metodo sopra: icona in una bolla azzurra, titolo al centro, freccia */
    '.svh-avanzate{width:100%;margin-top:12px;min-height:60px;padding:0 16px 0 10px;border-radius:50px;border:0;background:var(--card,#fff);color:var(--navy);display:grid;grid-template-columns:40px 1fr 40px;align-items:center;cursor:pointer;font:inherit;box-shadow:0 0 0 1.5px var(--line),0 8px 20px rgba(0,30,68,.07)}',
    '.svh-av-ic{width:40px;height:40px;border-radius:50%;background:#E3F1FF;color:#0075E3;display:grid;place-items:center;font-style:normal}.svh-av-ic svg{width:22px;height:22px}',
    '.svh-avanzate b{text-align:center;font:800 16px var(--font-body)}.svh-av-ch{justify-self:end;color:#0075E3}',
    '.svh-avanzate b{font:700 17px var(--font-body)}',
    '.svh-cta{width:100%;margin-top:16px;min-height:62px;border-radius:50px;border:0;background:#0075E3;color:#fff;font:800 18px var(--font-body);cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.28)}',
    '.svh-cta.grigia{background:#E3F1FF;color:#001E44;box-shadow:none}',
    '.svh-cta.rossa{background:#E63946;box-shadow:0 10px 24px rgba(230,57,70,.26)}',
    '.svh-cta:disabled{background:#C9D6E6;color:#fff;box-shadow:none;cursor:default}',
    '.svh-nota{margin:18px 0 0;font:500 14.5px/1.5 var(--font-body);color:var(--muted);max-width:330px}',
    'body.dark .svh-binario{stroke:rgba(140,198,255,.12)}',
    'body.dark .svh-tit.spento{color:rgba(232,241,255,.58)}',
    'body.dark .svh.on .svh-giro span{color:#8CC6FF}',
    'body.dark .svh-metodo{background:#1C2E5A;box-shadow:0 0 0 1.5px rgba(255,255,255,.08)}',
    'body.dark .svh-metodo > i{background:rgba(255,255,255,.14)}',
    'body.dark .svh-m1 > svg:first-child{color:#8CC6FF}body.dark .svh.on .svh-m1 > svg:first-child{color:var(--muted)}',
    'body.dark .svh-avanzate{background:#14234A;color:#fff;box-shadow:0 0 0 1.5px rgba(188,224,255,.16),0 8px 20px rgba(0,0,0,.25)}',
    'body.dark .svh-av-ic{background:#22376B;color:#8CC6FF}body.dark .svh-av-ch{color:#8CC6FF}',
    'body.dark .svh-cta.grigia{background:#22376B;color:#fff}',
    'body.dark .svh-cta:disabled{background:#2A3A5E;color:rgba(255,255,255,.45)}',
    'body.dark .svh-cerchio.piccolo .svh-disco{box-shadow:inset 0 0 0 2.5px rgba(188,224,255,.45),0 14px 32px rgba(0,0,0,.35)}',
    /* la pagina e i fogli del timer */
    '.svt-top{display:grid!important;grid-template-columns:44px 1fr 44px;align-items:center}.svt-top .blk-title{text-align:center;font-style:normal}',
    '#s-sev-timer{display:flex;flex-direction:column}',
    '.svt-corpo{display:flex;flex-direction:column;flex:1;min-height:0}',
    /* 0.9.310: tre colonne uguali, ognuna centrata (numero + unita'), cosi' i minuti non toccano il bordo destro e numero
       e unita' stanno sulla stessa riga della fascia */
    '.svt-pannello{position:relative;display:grid;grid-template-columns:1.15fr 1fr 1fr;grid-template-rows:minmax(0,1fr);height:' + (SVT_H * 5) + 'px;background:var(--card,#fff);border-radius:22px;box-shadow:0 0 0 1.5px var(--line);padding:0 6px;margin:16px 0 14px;overflow:hidden}',
    /* 0.9.340, Andrea: "la barra azzurra non e' a meta' altezza dei numeri": le cifre (senza discendenti) stanno 6px sopra al centro della riga, la banda sale con loro */
    '.svt-banda{position:absolute;left:10px;right:10px;top:' + (SVT_H * 2 - 6) + 'px;height:' + SVT_H + 'px;border-radius:12px;background:#E3F1FF;pointer-events:none}',
    '.svt-col{position:relative;display:flex;align-items:center;justify-content:center;min-width:0;min-height:0;height:100%;overflow:hidden}',
    '.svt-rullo{position:relative;z-index:1;height:100%;width:46px;flex:none;overflow-y:scroll;scroll-snap-type:y mandatory;scrollbar-width:none;overscroll-behavior:contain;padding:' + (SVT_H * 2) + 'px 0;box-sizing:border-box;-webkit-mask-image:linear-gradient(transparent,#000 28%,#000 72%,transparent);mask-image:linear-gradient(transparent,#000 28%,#000 72%,transparent)}',
    '.svt-rullo::-webkit-scrollbar{display:none}',
    '.svt-n{height:' + SVT_H + 'px;line-height:' + SVT_H + 'px;text-align:right;scroll-snap-align:center;font:500 21px var(--font-body);color:var(--faint);opacity:.55;font-variant-numeric:tabular-nums;cursor:pointer}',
    '.svt-n.v2{opacity:.7}.svt-n.v1{opacity:1;color:var(--muted)}',
    '.svt-n.sel{opacity:1;color:var(--navy);font-weight:800;font-size:26px}',
    '.svt-u{position:relative;top:7px;z-index:1;flex:none;white-space:nowrap;margin-left:6px;height:' + SVT_H + 'px;line-height:' + SVT_H + 'px;text-align:left;font:700 15px var(--font-body);color:var(--navy);pointer-events:none}',
    '@media(max-width:340px){.svt-u{font-size:13px;margin-left:4px}.svt-n.sel{font-size:23px}}',
    '.svt-fine{margin:0;text-align:center;font:500 14.5px var(--font-body);color:var(--muted)}',
    '.svt-sub{margin:8px 0 0;text-align:center;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.svt-salva{margin-top:18px}',
    'body.dark .svt-banda{background:#22376B}',
    '.svt-velo{position:fixed;inset:0;z-index:9990;background:rgba(0,12,30,.55);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .2s}',
    '.svt-velo.in{opacity:1}',
    '.svt-foglio{position:relative;width:100%;max-width:460px;background:#fff;border-radius:26px 26px 0 0;padding:12px 20px calc(22px + env(safe-area-inset-bottom,0px));transform:translateY(30px);transition:transform .22s ease-out;text-align:center}',
    '.svt-velo.in .svt-foglio{transform:none}',
    '.svt-grab{display:block;width:44px;height:5px;border-radius:3px;background:rgba(0,30,68,.18);margin:0 auto 6px}',
    '.svt-foglio h3{margin:14px 44px 4px;font:800 21px/1.25 var(--font-display);color:var(--navy)}',
    '.svt-foglio .sev-pin{margin:16px 0 0}',
    '.svt-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,30,68,.07);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .svt-velo{background:rgba(0,0,0,.72)}',
    'body.dark .svt-foglio{background:#1C2E5A;box-shadow:0 -1px 0 rgba(255,255,255,.14)}',
    'body.dark .svt-foglio .svt-pannello{background:#14234A}',
    'body.dark .svt-grab{background:rgba(255,255,255,.3)}',
    'body.dark .svt-x{background:rgba(255,255,255,.14);color:#fff}',
    /* la (i) e il titolo */
    '.svi-x{background:transparent!important;color:#0075E3!important}',
    '.svp-top{display:grid!important;grid-template-columns:44px 1fr 44px;align-items:center}.svp-top .blk-title{text-align:center;font-style:normal}.svp-i{justify-self:end;background:transparent!important;color:var(--navy)!important}',
    '.svi-tit{margin:6px 0 22px;font:800 30px/1.2 var(--font-display);color:var(--navy);text-align:center}',
    '.svi-lista{background:var(--card,#fff);border-radius:22px;padding:4px 20px;box-shadow:0 0 0 1.5px rgba(0,30,68,.06)}body.dark .svi-lista{background:rgba(255,255,255,.06);box-shadow:none}',
    '.svi-r{display:flex;align-items:center;gap:16px;min-height:62px}.svi-r + .svi-r{border-top:1px solid rgba(0,30,68,.08)}body.dark .svi-r + .svi-r{border-color:rgba(255,255,255,.1)}',
    '.svi-ic{width:32px;height:32px;border-radius:10px;background:#0E2350;display:flex;align-items:center;justify-content:center;flex:none}.svi-r b{font:700 16.5px var(--font-body);color:var(--navy)}',
    '.svi-sez{display:block;margin:26px 0 10px;font:600 16px var(--font-body);color:var(--muted);text-align:center}'
  ].join('');
  document.head.appendChild(st);
})();

function sevMethodName(id){
  const all = SEV_METHODS.concat(SEV_METHODS_MORE);
  for(let i=0;i<all.length;i++) if(all[i].id === id) return all[i].name;
  return 'Nessuno';
}

function sevRemain(s){
  if(!s) return -1;
  let at = s.unlockAvailableAt || 0;       // 0 = there is no clock, not "you are free"
  // unlockAvailableAtFor() only reports a clock for timer and pausa. A session armed with an
  // expiry still ends at that instant, so without this fallback "Nessun metodo" would show no
  // countdown at all. Not applied to pin/approval: there the gate is knowledge, and a ticking
  // number next to it would read as a promise that waiting is enough.
  if(!at && s.strictUntil && s.unlockMethod !== SEV_M.PIN && s.unlockMethod !== SEV_M.APPROVAL) at = s.strictUntil;
  if(!at) return -1;
  return Math.max(0, at - Date.now());
}

/* ---------- LA PROROGA ----------
   "Prolunga timer" apre la stessa pagina dei rulli: il tempo scelto si aggiunge alla fine di adesso. Il motore rifiuta
   una scadenza piu' vicina mentre la sessione e' chiusa a chiave, ma una piu' lontana la accetta. Nessun tetto. */
function sevProlungaApri(){ svtApri('prolunga'); }
async function sevProlunga(giorni){ return sevProlungaMin(Math.max(1, +giorni || 7) * 1440); }
async function sevProlungaMin(min){
  min = Math.max(1, Math.round(+min || 0));
  const extra = min * 60000;
  let ok = false;
  if(NATIVE && typeof NATIVE.setStrictConfig === 'function'){
    try{
      const st = await NATIVE.getStrictState();
      const base = Math.max(Date.now(), (st && st.strictUntil) || 0);
      const r = await NATIVE.setStrictConfig({ strictUntil: base + extra });
      ok = !!r && r.applied !== false;
    }catch(_){ ok = false; }
  }else{
    const s = sevPreview();
    s.strictUntil = Math.max(Date.now(), s.strictUntil || 0) + extra;
    s.unlockAvailableAt = s.strictUntil;
    sevSavePreview(s); sevState = s; ok = true;
  }
  await sevRefreshStatus();
  if(!ok){ toast('Il timer non è stato prolungato: riprova'); return; }
  const pts = sevPremiaVoto();
  toast('Timer prolungato di ' + sevFmtDur(min) + (pts ? ' · +' + pts + ' punti' : ''));
}

/* ---------- IL VOTO PER LA NUOVA IDENTITA' ----------
   Blindarsi non e' toccare un'impostazione: e' rifiutare la via d'uscita che si aveva a
   portata di pollice. Vale come voto, e i voti in quest'app hanno un prezzo in tutte e due
   le direzioni (decision.js). Quaranta e non sessanta: il pannello olografico arriva nel
   momento in cui si potrebbe andar via davvero, e quel momento e' piu' difficile di questo.

   UNA VOLTA AL GIORNO. Senza cancello, lo stesso pulsante premuto dieci volte varrebbe
   quattrocento punti: un punteggio che ci si puo' regalare da soli non misura niente. */
const SEV_PROLUNGA_PTS = 40;
const SEV_PREMIO_KEY = 'fl_sev_blinda_premio';

function sevPremioOggi(){
  const d = new Date(); d.setHours(0, 0, 0, 0);
  try{ return (+localStorage.getItem(SEV_PREMIO_KEY) || 0) >= d.getTime(); }catch(_){ return false; }
}
/** La riga sotto al titolo: dice cosa si sta facendo, e se la scelta vale punti adesso. */
function sevPremioRiga(){
  return sevPremioOggi()
    ? 'Si aggiunge alla scadenza di adesso. Non si torna indietro.'
    : 'Un voto per la persona che stai diventando: vale ' + SEV_PROLUNGA_PTS + ' punti.';
}
/** Registra il voto. Torna i punti dati, 0 se oggi il premio era gia' stato preso. */
function sevPremiaVoto(){
  if(sevPremioOggi()) return 0;
  try{ localStorage.setItem(SEV_PREMIO_KEY, String(Date.now())); }catch(_){ }
  if(typeof decVote === 'function') decVote('blinda', true, SEV_PROLUNGA_PTS);
  else if(typeof lvBump === 'function') lvBump();
  return SEV_PROLUNGA_PTS;
}

async function sevRequestPause(){
  if(!NATIVE || typeof NATIVE.requestDisable !== 'function'){
    const s = sevPreview(); s.pendingDisableAt = Date.now() + (s.pauseMinutes||10)*60000;
    s.unlockAvailableAt = s.pendingDisableAt; sevSavePreview(s); sevState = s;
    sevSyncTab(); toast('Anteprima: attesa simulata'); return;
  }
  try{ await NATIVE.requestDisable(); }
  catch(e){ toast(sevErr(e, 'Impossibile avviare l’attesa')); return; }
  await sevRefreshStatus();
  toast('Attesa avviata: torna quando il conto arriva a zero');
}

async function sevCancelPause(){
  if(!NATIVE || typeof NATIVE.cancelDisableRequest !== 'function'){
    const s = sevPreview(); s.pendingDisableAt = 0; s.unlockAvailableAt = 0; sevSavePreview(s); sevState = s;
    sevSyncTab(); return;
  }
  try{ await NATIVE.cancelDisableRequest(); }
  catch(e){ toast(sevErr(e, 'Impossibile annullare la richiesta')); return; }
  await sevRefreshStatus();
  toast('Richiesta annullata');
}

async function sevExitWithPin(){
  const el = document.getElementById('sevExitPin');
  const pin = el ? el.value : '';
  if(!pin || pin.length < SEV_MIN_PIN){ toast(`Il PIN ha almeno ${SEV_MIN_PIN} cifre`); return; }
  await sevDisable(pin);
}
async function sevExitNow(){ await sevDisable(null); }

async function sevDisable(pin){
  if(!NATIVE || typeof NATIVE.disableStrict !== 'function'){
    const s = sevPreview();
    if(!s.canDisableNow && !pin){ toast('Anteprima: il cancello è ancora chiuso'); return; }
    localStorage.removeItem(SEV_PREVIEW_KEY);
    sevState = sevPreview(); sevRenderLevel(0); svhChiudiFogli(); sevSyncTab();
    toast('Anteprima: Modalità severa disattivata'); return;
  }
  let res;
  // disableStrict never rejects: a closed gate comes back as disabled:false with a message.
  try{ res = await NATIVE.disableStrict(pin ? { pin: pin } : {}); }
  catch(e){ toast(sevErr(e, 'Impossibile disattivare la Modalità severa')); return; }
  sevState = res || sevState;
  if(res && res.disabled){
    sevRenderLevel(0);
    svhChiudiFogli();
    sevSyncTab();
    toast('Modalità severa disattivata');
    return;
  }
  const el = document.getElementById('sevExitPin'); if(el) el.value = '';
  sevSyncTab();
  toast((res && res.message) || 'Non è ancora possibile uscire');
}

/* ---------- THE SEVERA TAB (AppBlock layout) ----------
   Above the button, the two decisions the button depends on: the access method (with its
   parameter) and the options. Both rows open their own screen and come back here. With a
   session running, the same box shows the session instead. */
function sevMethodSummary(d){
  if(!d.method) return { icon:'\u{1F511}', name:'Scegli un metodo', sub:'obbligatorio', missing:true };
  const all = SEV_METHODS.concat(SEV_METHODS_MORE);
  let m = null; for(let i=0;i<all.length;i++) if(all[i].id === d.method) m = all[i];
  const icon = m ? m.icon : '\u{1F511}', name = m ? m.name : 'Metodo';
  switch(d.method){
    case SEV_M.TIMER: return d.timerMin ? { icon, name, sub: sevFmtDur(d.timerMin) } : { icon, name, sub:'durata da impostare', missing:true };
    case SEV_M.PAUSE: return { icon, name, sub:'attesa di ' + sevFmtDur(d.pauseMinutes || 10) };
    case SEV_M.PIN: return (d.pin || (sevState && sevState.hasPin)) ? { icon, name, sub:'PIN impostato' } : { icon, name, sub:'PIN da impostare', missing:true };
    case SEV_M.APPROVAL: return (d.apin || (sevState && sevState.hasApprovalPin)) ? { icon, name, sub:'PIN della persona di fiducia impostato' } : { icon, name, sub:'PIN da impostare', missing:true };
    case SEV_M.PROGRAMS: return { icon, name, sub: d.programs.length ? d.programs.length + ' programmi selezionati' : 'tutti i programmi' };
    case SEV_M.CHARGER: return { icon, name, sub:'collega il caricabatterie per uscire' };
    case SEV_M.NONE: return { icon, name:'Nessun metodo', sub:'sessione di una vecchia versione' };
  }
  return { icon, name, sub:'' };
}
function sevOptionsSummary(d){
  let n = ['uninstall','settings','recents','split','reinstalled'].filter(k => d.opts[k]).length;
  try{ if (typeof bsLeggi === 'function'){ const o = bsLeggi(); n += Object.keys(o).filter(k => o[k]).length; } }catch(_){ }
  return n ? 'Blocchi protetti + ' + n + (n===1 ? ' opzione' : ' opzioni') : 'Solo i blocchi';
}

/* "Primo passo fatto": the days in a row the strict session has held. Counted from the day it
   was started, forgotten when it ends. */
/* The plan was interrupted (a pause, a programme switched off, the strict session ended):
   the days of a row are gone, and the count starts again from the next day it holds. */
function sevStreakBreak(why){
  // Da qui parte la finestra in cui vale "il patto rotto": hai tolto il lucchetto, e se
  // adesso vai dritto dove avevi detto di non andare, i sogni chiamano.
  try{ if (NATIVE && NATIVE.markPlanPaused) NATIVE.markPlanPaused(); }catch(_){ }
  /* LA SERIE DELLA MODALITA' SEVERA LA SPEZZA SOLO LA MODALITA' SEVERA.
     Qui ci si arriva anche mettendo in pausa un programma o spegnendo il blocco rapido — due
     cose che con la sessione severa non c'entrano niente. Con la severa accesa (o con lo
     stato ancora ignoto, cioe' nei primi istanti dopo l'avvio) la serie NON si tocca: e' il
     motivo per cui il pannello ripartiva da «un giorno» ogni volta. La striscia dei blocchi
     (fl_streak) invece si spezza davvero: quella misura i blocchi, e un blocco l'hai tolto. */
  const severaViva = !sevState || (sevState.level || 0) >= 1;
  try{
    if (!severaViva) localStorage.removeItem('fl_sev_streak');
    localStorage.removeItem('fl_streak');
    localStorage.setItem('fl_streak_broken', JSON.stringify({ at: Date.now(), why: why || '' }));
  }catch(_){ }
  // Ogni pausa resta scritta: è quello che abbassa la probabilità di riuscirci nel pannello
  // "Prevedi il tuo futuro". Novanta giorni, poi si dimentica.
  try{
    const since = Date.now() - 90 * 86400000;
    const list = (JSON.parse(localStorage.getItem('fl_breaks') || '[]') || []).filter(t => t >= since);
    list.push(Date.now());
    localStorage.setItem('fl_breaks', JSON.stringify(list.slice(-200)));
  }catch(_){ }
  if(typeof sevSyncTab === 'function'){ try{ sevSyncTab(); }catch(_){ } }
  if(typeof blkPaintStreak === 'function'){ try{ blkPaintStreak(); }catch(_){ } }
}
function sevStreakDays(active){
  let st = null;
  try{ st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null'); }catch(_){ st = null; }
  const today = (typeof blkToday === 'function') ? blkToday() : new Date().toISOString().slice(0, 10);
  /* LA SERIE NON SI CANCELLA PER UN ISTANTE DI BUIO. `active` arriva da sevState, che e' null
     finche' il motore non risponde (all'avvio, dopo un aggiornamento dell'app): un giro
     con lo stato ancora vuoto cancellava la serie e la ricreava da oggi — il contatore che
     torna a 1 (20/09). Se lo stato non e' noto, la serie resta com'e'. */
  if(!active){
    if(sevState === null && st && st.start){
      const d0 = (typeof blkDaysBetween === 'function') ? blkDaysBetween(st.start, today) + 1 : 1;
      return Math.max(1, d0);
    }
    if(st){ try{ localStorage.removeItem('fl_sev_streak'); localStorage.removeItem('fl_sev_armed'); }catch(_){ } }
    return 0;
  }
  if(!st || !st.start){
    /* Serie mancante con la severa accesa: si riparte dal giorno in cui e' stata armata, non
       da oggi. Ripartire da oggi e' esattamente il bug che si vedeva. */
    let start = today;
    try{ const a = localStorage.getItem('fl_sev_armed'); if (a && /^\d{4}-\d{2}-\d{2}$/.test(a) && a <= today) start = a; }catch(_){ }
    st = { start: start };
    try{ localStorage.setItem('fl_sev_streak', JSON.stringify(st)); }catch(_){ }
  }
  const days = (typeof blkDaysBetween === 'function') ? blkDaysBetween(st.start, today) + 1 : 1;
  return Math.max(1, days);
}
function sevSyncTab(){
  const s = sevState;
  const active = !!(s && s.level);
  /*
   * The streak panel now floats in the sky at the top of this tab, so it is painted here and
   * not inside the box below.
   *
   * sevStreakDays() is asked EXACTLY ONCE per sync and its answer is passed on: called with
   * active=false it DELETES the stored streak, so a second caller that guessed wrong would
   * quietly wipe a run of days.
   */
  const days = sevStreakDays(active);
  // The sky at the top carries the picture and the two figures; the streak panel is the last
  // thing on the page, so it is what closes the visit.
  if(typeof sevHeroPaint === 'function') sevHeroPaint(days);
  if(typeof sevStreakFoot === 'function') sevStreakFoot(days);
  const box = document.getElementById('sevTabBox');
  if(!box) return;
  /* 0.9.291, Andrea: "al posto del lucchetto e del titolo ripetuto voglio solo Attiva, con il cerchio di AppBlock e il
     flusso di energia azzurro che gira; e sulla pagina il metodo di sblocco, le opzioni avanzate e Prolunga timer,
     come AppBlock, non in una pagina Vedi lo stato". Con la severa accesa l'intestazione col lucchetto si nasconde. */
  document.querySelectorAll('.sev-intro').forEach(function(el){ if (!el.classList.contains('cn-intro')) el.hidden = active; });
  /* 0.9.309: la pagina e' il ritratto di AppBlock, accesa (sevAttivaHtml) o spenta (sevSpentaHtml) */
  box.innerHTML = active ? sevAttivaHtml(s) : sevSpentaHtml();
  /* chi ha appena ridisegnato conosce gia' lo stato: il giro del conto non lo riannuncia ("e' finita" dopo "disattivata") */
  SVH_FIRMA = sevFirma(s);
}

/* ---------- La decisione alla scadenza ----------

   Una sessione che finisce e basta non e' una scelta: e' una scadenza. Questo interruttore
   trasforma la fine in un bivio — si continua o si torna com'era — e lo chiede fuori dall'app,
   con una notifica, perche' chiederlo dentro vorrebbe dire chiederlo a chi e' gia' venuto a
   cercarti. */
function sevDecCfg(){
  try{ return Object.assign({ ask: true, askHours: 24, extendDays: 30 }, JSON.parse(localStorage.getItem('fl_strict_cfg') || '{}')); }
  catch(_){ return { ask: true, askHours: 24, extendDays: 30 }; }
}
function sevDecSave(patch){
  const c = Object.assign(sevDecCfg(), patch || {});
  try{ localStorage.setItem('fl_strict_cfg', JSON.stringify(c)); }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setDecisionConfig){
    try{ NATIVE.setDecisionConfig({ ask: c.ask, askHours: c.askHours }); }catch(_){ }
  }
  sevDecPaint();
}
function sevDecPaint(){
  const el = document.getElementById('sevDecBox');
  if (!el) return;
  const c = sevDecCfg();
  const sw = (on, act) => '<button type="button" class="switch' + (on ? ' on' : '') + '" onclick="' + act + '"></button>';
  el.innerHTML = '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div>'
    + '<b>🛰️ Chiedimi se continuare</b>'
    + '<small>Prima della scadenza arriva una notifica con una domanda sola: rimetterci la firma per altri giorni, o lasciare che i blocchi tornino negoziabili. '
    + 'Rinnovare vale 60 punti, rifiutare ne toglie 30: in tutti e due i casi stai votando per chi vuoi diventare. Si chiede solo per sessioni di almeno due giorni, e la proroga non dura mai più della sessione.</small></div>'
    + sw(c.ask !== false, 'sevDecSave({ask:' + (c.ask === false ? 'true' : 'false') + '})') + '</div>'
    + (c.ask === false ? '' :
        '<div class="ps-sub">Quanto prima</div>'
      + '<div class="sev-chips">' + [[6, 'sei ore prima'], [24, 'il giorno prima'], [48, 'due giorni prima']].map(function(o){
          return '<button type="button" class="sev-chip' + (c.askHours === o[0] ? ' on' : '') + '" onclick="sevDecSave({askHours:' + o[0] + '})">' + o[1] + '</button>'; }).join('')
      + '</div>'
      + '<div class="ps-sub">Se continui, per quanto</div>'
      + '<div class="sev-chips">' + [[7, 'una settimana'], [30, 'un mese'], [90, 'tre mesi'], [365, 'un anno']].map(function(o){
          return '<button type="button" class="sev-chip' + (c.extendDays === o[0] ? ' on' : '') + '" onclick="sevDecSave({extendDays:' + o[0] + '})">' + o[1] + '</button>'; }).join('')
      + '</div>'
      + '<div class="ps-row"><button type="button" class="ghostmini" onclick="sevDecPreview()">Guarda come appare</button></div>')
    + '</div>';
}
function sevDecPreview(){
  if (typeof decOpen !== 'function') return;
  const c = sevDecCfg();
  decOpen('strict', { whenTxt: 'fra ' + (c.askHours || 24) + ' ore', days: 12, extendDays: c.extendDays || 30,
    preview: true, foot: 'Anteprima · nessuna scelta viene registrata' });
}

/* ---------- 0.9.310: «AUTORIZZAZIONE MANCANTE» (Andrea, 740: ritratto della schermata di AppBlock) ----------
   Quando la modalita' severa deve impedire la disinstallazione e Android non ha ancora dato l'amministratore
   dispositivi: l'illustrazione (lo scudo davanti alla griglia delle app), il titolo, la pillola col nome del permesso,
   una riga che spiega e "Vai alle impostazioni", che apre la richiesta di sistema (requestDeviceAdmin). Al ritorno
   dalle Impostazioni si rilegge il permesso: se c'e', la schermata si chiude da sola e si prosegue. Colori del brand,
   uguali in chiaro e in scuro come le altre pagine scure della modalita' severa. */
let SEV_ADM_DOPO = null, SEV_ADM_T = 0;
async function sevAdminAttivo(){
  if(!NATIVE || typeof NATIVE.isDeviceAdminActive !== 'function') return !!(sevState && sevState.deviceAdminActive);
  try{ const r = await NATIVE.isDeviceAdminActive(); return !!(r && r.active); }catch(_){ return false; }
}
function sevAdminIll(){
  let celle = '';
  [34, 88, 142].forEach(function(y){ [36, 88, 140].forEach(function(x){ celle += '<rect x="' + x + '" y="' + y + '" width="44" height="44" rx="11" fill="#22376B"/>'; }); });
  return '<svg viewBox="0 0 220 200" width="200" height="182" aria-hidden="true">'
    + '<defs><linearGradient id="sevAdmG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3F9FF4"/><stop offset="1" stop-color="#0075E3"/></linearGradient>'
    + '<linearGradient id="sevAdmS" x1="0" y1="0" x2="0" y2="1"><stop offset=".45" stop-color="#fff"/><stop offset="1" stop-color="#000"/></linearGradient>'
    + '<mask id="sevAdmM"><rect x="0" y="0" width="220" height="200" fill="url(#sevAdmS)"/></mask></defs>'
    + '<g mask="url(#sevAdmM)"><rect x="22" y="20" width="176" height="180" rx="30" fill="#14234A" stroke="rgba(188,224,255,.18)"/>' + celle + '</g>'
    + '<path d="M110 52 L162 70 V108 C162 140 140 160 110 172 C80 160 58 140 58 108 V70 Z" fill="url(#sevAdmG)" stroke="#BCE0FF" stroke-opacity=".55" stroke-width="1.5"/>'
    + '<path d="M99 112 v-9 a11 11 0 0 1 22 0 v9" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round"/>'
    + '<rect x="92" y="110" width="36" height="28" rx="6" fill="#fff"/><circle cx="110" cy="121" r="4" fill="#0075E3"/><rect x="108" y="122" width="4" height="8" rx="2" fill="#0075E3"/>'
    + '</svg>';
}
function sevAdminSenza(){
  const dopo = SEV_ADM_DOPO;
  if(sevDraft && sevDraft.opts){ sevDraft.opts.uninstall = false; sevSaveDraft(); }
  sevAdminChiudi();
  if(dopo) dopo();
}
function sevAdminApri(dopo, conSalta){
  SEV_ADM_DOPO = typeof dopo === 'function' ? dopo : null;
  let w = document.getElementById('sevAdm');
  if(!w){
    w = document.createElement('div');
    w.id = 'sevAdm';
    w.className = 'sev-adm';
    w.setAttribute('role', 'dialog');
    w.setAttribute('aria-modal', 'true');
    document.body.appendChild(w);
  }
  w.innerHTML = '<button type="button" class="sev-adm-x" onclick="sevAdminChiudi()" aria-label="Chiudi">'
    +   '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '<div class="sev-adm-c">'
    +   '<div class="sev-adm-ill">' + sevAdminIll() + '</div>'
    +   '<h2 class="sev-adm-h">Autorizzazione mancante</h2>'
    +   '<span class="sev-adm-pill">Amministratore dispositivi</span>'
    +   '<p class="sev-adm-p">Serve a impedire la disinstallazione di DreamMap mentre la modalità severa è attiva.</p>'
    + '</div>'
    + '<button type="button" class="sev-adm-go" onclick="sevAdminVai()">Vai alle impostazioni</button>'
    + (conSalta ? '<button type="button" class="sev-adm-salta" onclick="sevAdminSenza()">Continua senza questa protezione</button>' : '');
  clearInterval(SEV_ADM_T);
  SEV_ADM_T = setInterval(function(){ if(!document.hidden) sevAdminControlla(); }, 1500);
}
async function sevAdminVai(){
  if(!NATIVE || typeof NATIVE.requestDeviceAdmin !== 'function'){
    toast('Anteprima: sul telefono qui si apre la richiesta di amministratore dispositivi');
    return;
  }
  try{
    const r = await NATIVE.requestDeviceAdmin();
    if(r && r.via === 'already-active') sevAdminOk();
  }catch(e){ toast(sevErr(e, 'Impossibile aprire la richiesta di amministratore dispositivi')); }
}
async function sevAdminControlla(){
  if(!document.getElementById('sevAdm')){ clearInterval(SEV_ADM_T); SEV_ADM_T = 0; return; }
  if(!NATIVE || typeof NATIVE.isDeviceAdminActive !== 'function') return;
  if(await sevAdminAttivo()) sevAdminOk();
}
function sevAdminOk(){
  const dopo = SEV_ADM_DOPO;
  if(sevState) sevState.deviceAdminActive = true;
  if(sevDraft && sevDraft.opts){ sevDraft.opts.uninstall = true; sevSaveDraft(); }
  sevAdminChiudi();
  toast('Protezione dalla disinstallazione attiva');
  try{ sevRenderOptions(); }catch(_){ }
  if(dopo) dopo();
}
function sevAdminChiudi(){
  clearInterval(SEV_ADM_T); SEV_ADM_T = 0; SEV_ADM_DOPO = null;
  const w = document.getElementById('sevAdm'); if(w) w.remove();
}
document.addEventListener('visibilitychange', function(){ if(!document.hidden && document.getElementById('sevAdm')) sevAdminControlla(); });
(function sevAdminStile(){
  if(document.getElementById('sev-adm-style')) return;
  const st = document.createElement('style');
  st.id = 'sev-adm-style';
  st.textContent = [
    '.sev-adm{position:fixed;inset:0;z-index:9996;display:flex;flex-direction:column;align-items:center;padding:calc(18px + env(safe-area-inset-top,0px)) 22px calc(22px + env(safe-area-inset-bottom,0px));',
    '  background:linear-gradient(180deg,#0E2350 0%,#001E44 55%,#0F2041 100%);color:#fff;text-align:center;animation:sevAdmIn .25s ease-out}',
    '.sev-adm-x{align-self:flex-start;width:44px;height:44px;border:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.12);color:#fff;cursor:pointer}',
    '.sev-adm-c{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;max-width:420px;padding-bottom:40px}',
    '.sev-adm-ill{margin-bottom:22px}',
    '.sev-adm-h{margin:0;font:800 30px/1.15 var(--font-body);color:#fff}',
    '.sev-adm-pill{display:inline-block;margin-top:16px;padding:9px 18px;border-radius:50px;background:rgba(0,117,227,.3);border:1px solid rgba(140,198,255,.35);color:#BCE0FF;font:700 15px var(--font-body)}',
    '.sev-adm-p{margin:16px 0 0;max-width:340px;font:500 15px/1.55 var(--font-body);color:rgba(227,241,255,.78)}',
    '.sev-adm-salta{margin-top:10px;padding:12px 16px;border:0;background:none;color:rgba(255,255,255,.82);font:600 14.5px var(--font-body);cursor:pointer}',
    '.sev-adm-go{width:100%;max-width:420px;border:0;border-radius:50px;padding:17px 20px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 26px rgba(0,117,227,.35)}',
    '@keyframes sevAdmIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------- BOOT ----------
   The engine is the source of truth for the level, not localStorage: a timer that expired while
   the app was closed must show as expired the moment the user looks. */
/* 0.9.310, RIPARAZIONE UNA TANTUM (Andrea: "l'avevo attivata per un minuto per provarla e si e' estesa per un mese").
   L'impronta del difetto: una sessione appena armata e, pochi minuti dopo, un "si'" alla domanda di proroga (che nella
   0.9.309 partiva subito per le sessioni brevi e aggiungeva 30 giorni). Solo allora si chiede al motore di accorciare
   (StrictMode.riparaProroga, una volta sola per telefono) e si toglie il voto e i suoi punti dal registro. */
async function sevRipara310(){
  try{ if (localStorage.getItem('fl_sev_ripara310')) return; }catch(_){ return; }
  if (!NATIVE || typeof NATIVE.riparaProroga !== 'function' || !(sevState && sevState.level >= 1)) return;
  let ini = null, log = null;
  try{ ini = JSON.parse(localStorage.getItem(SVH_INIZIO_KEY) || 'null'); log = JSON.parse(localStorage.getItem('fl_decisions') || 'null'); }catch(_){ }
  if (!ini || !ini.start || !log || !Array.isArray(log.votes)) return;
  const voto = log.votes.filter(function(v){ return v && v.kind === 'strict' && v.yes && v.at >= ini.start && v.at - ini.start < 30 * 60000; }).pop();
  if (!voto) return;
  if (!(sevState.strictUntil - voto.at > 20 * 86400000)) return;
  let r = null;
  try{ r = await NATIVE.riparaProroga({ fino: Date.now() }); }catch(_){ r = null; }
  try{ localStorage.setItem('fl_sev_ripara310', String(Date.now())); }catch(_){ }
  if (!r || !r.ok) return;
  log.votes = log.votes.filter(function(v){ return v !== voto && !(v.kind === voto.kind && v.at === voto.at); });
  log.pts = log.votes.reduce(function(a, v){ return a + (v.pts || 0); }, 0);
  try{ localStorage.setItem('fl_decisions', JSON.stringify(log)); }catch(_){ }
  try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  await sevLoadState();
  try{ toast('Ho annullato la proroga di 30 giorni partita per errore: la modalità severa è spenta.'); }catch(_){ }
}
async function sevBoot(){
  sevDraftReady();
  await sevLoadState();
  try{ await sevRipara310(); }catch(_){ }
  sevRenderLevel((sevState && sevState.level) || 0);
  sevSyncTab();
}
document.addEventListener('fl:screen', function(e){ if(e && e.detail === 's-home') sevSyncTab(); });
document.addEventListener('visibilitychange', () => {
  // Coming back from Settings (device admin) or from a long pause: re-read instead of guessing.
  if(!document.hidden) sevBoot();
});
/* Deferred to DOMContentLoaded on purpose: this module is loaded before nav.js, and sevBoot
   uses esc()/toast() which live there. Running it at parse time would throw on a plain browser,
   where sevLoadState() returns without ever awaiting the bridge. */
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sevBoot);
else sevBoot();
