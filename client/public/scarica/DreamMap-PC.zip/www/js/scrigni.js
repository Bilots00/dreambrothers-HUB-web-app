/* ---------------------------------------------------------------------------------------
   SCRIGNI, DREAM POINTS E MONK MODE

   La parte di gioco che dipende da quanto hai lavorato DAVVERO. Le regole, in breve:

   1. Ogni sessione FullFocus finita vale i suoi Dream Points: minuti per un moltiplicatore
      che cresce con la durata (10 minuti = 1x, 25 = 3x, 50 o piu' = 8x). Il flusso vero
      comincia dopo una ventina di minuti: i primi dieci pagano poco di proposito.
   2. Oltre ai punti, A VOLTE arriva uno scrigno (Bronzo, Argento, Oro, Leggendario). Nelle
      prime cinque sessioni arriva sempre, cosi' si impara cos'e'; a regime circa una volta
      su due per le sessioni corte, sempre per quelle lunghe. Una sessione corta non da' mai
      l'oro: l'oro si guadagna restando.
   3. Dentro: monete, un suono chiuso, una frase che dice chi sei per quello che hai fatto,
      un extra di Dream Points.
   4. Una sessione mollata ROMPE lo scrigno che stava maturando: la perdita si vede.
   5. Dopo una sessione lunga, dieci minuti lontano dal telefono armano un bonus sulla
      sessione successiva: la pausa vera vale, quella a scrollare no.
   6. Il Monk Mode: trenta giorni con un obiettivo settimanale di quindici ore.

   I Dream Points NON si spendono nell'app: si accumulano, e valgono nel programma fedelta'
   dello shop per upgrade ed esperienze. Qui si vede solo il saldo.
   --------------------------------------------------------------------------------------- */
const SCR_KEY = 'fl_scrigni';
const SCR_DP_KEY = 'fl_dream_points';
/* i suoni che i livelli non concedono: si aprono solo con uno scrigno d'oro o leggendario */
const SCR_SUONI = ['storm', 'river', 'forest'];
const SCR_ONBOARDING = 5;            // le prime sessioni: scrigno sempre
const SCR_PAUSA_MIN = 10;            // minuti lontano dal telefono per armare il bonus
const SCR_STAGIONE_GIORNI = 30;
const SCR_STAGIONE_OBIETTIVO = 900;  // minuti a settimana (15 ore)

const SCR_TIER = {
  bronzo:      { n: 'Bronzo',      ico: '📦', col: '#B5703A' },
  argento:     { n: 'Argento',     ico: '🎁', col: '#B8C4D6' },
  oro:         { n: 'Oro',         ico: '🏆', col: '#E8B531' },
  leggendario: { n: 'Leggendario', ico: '💎', col: '#3F9FF4' }
};

/* Frasi di identita': dicono chi sei per quello che hai appena fatto, non per quello che
   vorresti. Una per fascia, scelta a rotazione. */
const SCR_FRASI = {
  breve: [
    'Dieci minuti fatti battono un’ora immaginata.',
    'Hai cominciato. La maggior parte non lo fa.',
    'Il primo mattone non si vede, ma senza non c’è il muro.'
  ],
  media: [
    'Sei uno che resta quando la voglia se ne va.',
    'Mezz’ora di attenzione vera: oggi hai comprato tempo, non l’hai speso.',
    'La testa voleva scappare. Tu no.'
  ],
  lunga: [
    'Un’ora intera. Sei una persona che finisce le cose.',
    'Quello che hai fatto ora lo trovi fra un anno, moltiplicato.',
    'Cinquanta minuti senza cedere: questa è la tua identità, non un episodio.'
  ]
};

function scrStato(){
  let s = null;
  try{ s = JSON.parse(localStorage.getItem(SCR_KEY) || 'null'); }catch(_){ s = null; }
  return Object.assign({ aperti: [], rotti: 0, n: 0, suoni: [], frasi: [], pausa: null, stagione: null, tot: 0 }, s || {});
}
function scrSalva(s){ try{ localStorage.setItem(SCR_KEY, JSON.stringify(s)); }catch(_){ } return s; }
function scrDP(){ try{ return +localStorage.getItem(SCR_DP_KEY) || 0; }catch(_){ return 0; } }
function scrAddDP(n){ try{ localStorage.setItem(SCR_DP_KEY, String(scrDP() + Math.max(0, Math.round(n)))); }catch(_){ } }
function scrSuonoChiuso(id){ return SCR_SUONI.indexOf(id) >= 0 && scrStato().suoni.indexOf(id) < 0; }

/* La fascia di una sessione: moltiplicatore, probabilita' dello scrigno e pesi dei livelli. */
function scrFascia(min){
  if (min < 10) return null;
  if (min < 25) return { k: 'breve', x: 1, prob: 0.45, pesi: { bronzo: 1 } };
  if (min < 50) return { k: 'media', x: 3, prob: 0.5,  pesi: { bronzo: 0.85, argento: 0.10, oro: 0.05 } };
  return              { k: 'lunga', x: 8, prob: 1,    pesi: { argento: 0.5, oro: 0.4, leggendario: 0.1 } };
}
function scrEstrai(pesi){
  let r = Math.random(), acc = 0, ultimo = null;
  for (const k in pesi){ acc += pesi[k]; ultimo = k; if (r < acc) return k; }
  return ultimo;
}

/* Il contenuto di uno scrigno, deciso al momento in cui si apre. */
function scrContenuto(tier, fascia, dpBase){
  const s = scrStato();
  const c = { monete: 0, dp: 0, suono: '', frase: '' };
  const frasi = SCR_FRASI[fascia.k] || SCR_FRASI.breve;
  const frase = frasi[s.tot % frasi.length];
  const suonoLibero = SCR_SUONI.filter(id => s.suoni.indexOf(id) < 0)[0] || '';
  /* 0.9.322, Andrea: "15 monete fanno cagare: su Clash Royale sono 150". E un premio solo: o le monete, o il suono */
  if (tier === 'bronzo'){ c.monete = 100 + Math.floor(Math.random() * 11) * 10; }
  if (tier === 'argento'){ c.monete = 200 + Math.floor(Math.random() * 16) * 10; c.frase = frase; }
  if (tier === 'oro'){ c.frase = frase; if (suonoLibero && Math.random() < .35) c.suono = suonoLibero; else c.monete = 400 + Math.floor(Math.random() * 21) * 10; }
  if (tier === 'leggendario'){ c.frase = frase; if (suonoLibero && Math.random() < .35) c.suono = suonoLibero; else c.monete = 1000; }
  return c;
}

/* ---- il gancio: subito dopo il verdetto della sessione ---------------------------------- */
let SCR_PENDENTE = null;
function scrDopoSessione(ok, run, coins, spentMs){
  const host = document.getElementById('ffDone');
  if (!host) return;
  const s = scrStato();
  const min = Math.round((spentMs || 0) / 60000);
  const btn = host.querySelector('.ffd-go');
  const box = document.createElement('div');
  box.className = 'scr-box';
  box.id = 'scrBox';

  if (!ok){
    /* LA PIANTA APPASSITA BASTA. Lo scrigno rotto era un secondo cartello sulla stessa
       pagina, e due cartelli che dicono la stessa cosa si annullano: chi guarda legge il
       piu' vistoso e l'albero secco diventa decorazione. La perdita resta contata, non
       mostrata. */
    s.rotti++; s.pausa = null; scrSalva(s);
    return;
  }

  const f = scrFascia(min);
  /* 0.9.315, Andrea: le soglie restano del gioco, non si spiegano a schermo */
  if (!f) return;

  /* il bonus della pausa vera: armato se dopo l'ultima sessione lunga sei stato dieci minuti
     lontano dal telefono, e la sessione nuova non e' cominciata prima di quei dieci minuti */
  let bonus = 1, prob = f.prob;
  if (s.pausa && s.pausa.bonus && run.startAt && (run.startAt - s.pausa.dopo) >= SCR_PAUSA_MIN * 60000){ bonus = 1.25; prob = Math.min(1, prob + 0.15); }
  s.pausa = null;

  let dp = Math.round(min * f.x * bonus);
  s.n++; s.tot++;
  const onboarding = s.n <= SCR_ONBOARDING;
  const arriva = onboarding || Math.random() < prob;
  const tier = arriva ? scrEstrai(f.pesi) : '';
  scrAddDP(dp);
  if (f.k === 'lunga') s.pausa = { dopo: Date.now(), bonus: false };
  scrSalva(s);

  let html = '<p class="scr-dp">+' + dp + ' Dream Points</p>';
  if (tier){
    const t = SCR_TIER[tier];
    SCR_PENDENTE = { tier: tier, fascia: f, dp: dp };
    html += '<button type="button" class="scr-chest-btn" onclick="scrApri()">' + scrCassaHtml(tier, false) + '</button>'
      + '<b>Mystery box</b><small>Toccala per aprirla</small>';
  }
  if (f.k === 'lunga') html += '<p class="scr-pausa">⏳ Dieci minuti lontano dal telefono, adesso, e la prossima sessione vale il 25% in più.</p>';
  box.innerHTML = html;
  if (btn) host.insertBefore(box, btn); else host.appendChild(box);
}

/* ---- lo scrigno disegnato: coperchio, corpo, lucchetto. Niente emoji del pacco. ----------
   Lo stesso pezzo serve al verdetto della sessione, al premio di una sfida e al Bentornato. */
function scrCassaHtml(tier, aperta){
  /* 0.9.284, Andrea: "quello scrigno e' una merda". Il forziere in CSS se ne va: al suo posto la mystery box approvata
     (la scatola blu laccata, img/mystery/), chiusa o aperta. */
  return '<div class="scr-mb' + (aperta ? ' open' : '') + '"><img src="img/mystery/' + (aperta ? 'aperta' : 'chiusa') + '.webp" alt="La mystery box"></div>';
}

function scrApri(){
  const p = SCR_PENDENTE; if (!p) return;
  SCR_PENDENTE = null;
  const s = scrStato();
  const c = scrContenuto(p.tier, p.fascia, p.dp);
  if (c.monete && typeof ffAddCoins === 'function') ffAddCoins(c.monete);
  if (c.dp) scrAddDP(c.dp);
  if (c.suono && s.suoni.indexOf(c.suono) < 0) s.suoni.push(c.suono);
  if (c.frase && s.frasi.indexOf(c.frase) < 0) s.frasi.push(c.frase);
  s.aperti.push({ at: Date.now(), tier: p.tier, min: Math.round(p.dp / p.fascia.x), monete: c.monete, dp: c.dp, suono: c.suono, frase: c.frase });
  s.aperti = s.aperti.slice(-60);
  scrSalva(s);
  /* la lettera dell'Io Futuro, se il suo agente l'ha scritta durante la sessione: si apre dopo la scatola */
  let lettera = null;
  try{ lettera = (typeof ifLetteraPronta === 'function') ? ifLetteraPronta() : null; }catch(_){ }
  const extra = scrExtra(c);
  if (lettera) extra.push({ ico: '✉️', t: 'Una lettera dal tuo io futuro', s: 'Si apre appena chiudi la scatola' });
  mbApri({ tier: p.tier, titolo: 'Mystery box', sotto: 'Sessione finita: toccala tre volte per aprirla', premio: scrPremioDi(c), extra: extra,
    onChiudi: function(){
      const box = document.getElementById('scrBox');
      if (box) box.innerHTML = scrCassaHtml(p.tier, true) + '<b>Mystery box aperta</b><small>+' + c.monete + ' monete' + (c.dp ? ' · +' + c.dp + ' Dream Points' : '') + '</small>';
      if (lettera){ try{ ifConsegna('scrigno'); }catch(_){ } }
    } });
  if (typeof sndPaint === 'function') try{ sndPaint(); }catch(_){ }
}
/** Quello che c'e' nella scatola oltre alle monete, una riga per cosa. La frase d'identita' non si mostra piu' qui. */
function scrExtra(c){ return []; }
function scrPremioDi(c){
  if (c.suono) return { ico: '🎵', t: 'Suono sbloccato', s: (typeof sndName === 'function' ? (sndName(c.suono) || '') : '') };
  return { ico: '🪙', t: '+' + c.monete + ' monete', monete: true };
}

/* ---- lo scrigno come PREMIO, fuori dal verdetto di una sessione -------------------------------
   Una sfida vinta o il rientro dopo giorni di assenza aprono uno scrigno con la stessa
   animazione e lo stesso bottino di quelli delle sessioni. Niente scrigno nuovo: e' questo. */
function scrApriPremio(tier, opts){
  opts = opts || {};
  tier = SCR_TIER[tier] ? tier : 'bronzo';
  const s = scrStato();
  const fascia = tier === 'bronzo' ? { k: 'breve', x: 1 } : (tier === 'argento' ? { k: 'media', x: 3 } : { k: 'lunga', x: 8 });
  const c = scrContenuto(tier, fascia, 0);
  if (c.monete && typeof ffAddCoins === 'function') ffAddCoins(c.monete);
  if (c.dp) scrAddDP(c.dp);
  if (c.suono && s.suoni.indexOf(c.suono) < 0) s.suoni.push(c.suono);
  if (c.frase && s.frasi.indexOf(c.frase) < 0) s.frasi.push(c.frase);
  s.aperti.push({ at: Date.now(), tier: tier, min: 0, monete: c.monete, dp: c.dp, suono: c.suono, frase: c.frase, premio: opts.motivo || 'premio' });
  s.aperti = s.aperti.slice(-60);
  scrSalva(s);
  mbApri({ tier: tier, titolo: opts.titolo || 'Mystery box', sotto: opts.sotto, premio: scrPremioDi(c),
    extra: (opts.extra || []), bottone: opts.bottone, onChiudi: opts.onChiudi });
  if (typeof sndPaint === 'function') try{ sndPaint(); }catch(_){ }
  return c;
}

/* ---- LA MYSTERY BOX, UNA SOLA (0.9.284) ------------------------------------------------------
   Andrea: "quel pop-up del Bonus Drop fa schifo, e lo scrigno e' una merda". Ogni scatola del gioco (dopo il Full
   Focus, una riga spuntata, la serie, una sfida, il rientro) si apre come quella della Mappa: a pagina intera, i
   raggi e le stelle, la scatola blu che si tocca tre volte, poi UN premio grande e, sotto, una riga per il resto.
   Niente nomi di livello (Bronzo, Argento...), niente frasi in riquadri. */
const MB = { tocchi: 0, opts: null };
function mbApri(opts){
  try{ localStorage.setItem('fl_box_giorno', (typeof gcOggi === 'function') ? gcOggi() : new Date().toDateString()); }catch(_){ }
  MB.opts = opts || {}; MB.tocchi = 0; MB.visto = false;
  /* 0.9.322, Andrea: "sblocca sia le monete che il suono, non ha senso". I suoni della notte si aprono ogni tanto AL POSTO delle monete, che tornano indietro */
  try{
    const pr = MB.opts.premio;
    if (pr && pr.monete && Math.random() < .22){
      const tr = (typeof suoTracciaDaBox === 'function') ? suoTracciaDaBox(MB.opts.tier) : null;
      if (tr){
        const n = parseInt(String(pr.t).replace(/[^0-9]/g, ''), 10) || 0;
        if (n && typeof ffAddCoins === 'function') ffAddCoins(-n);
        MB.opts.premio = { ico: '🎵', t: 'Suono sbloccato', s: tr.t };
      }
    }
  }catch(_){ }
  const vecchio = document.getElementById('mbBox'); if (vecchio) vecchio.remove();
  const w = document.createElement('div'); w.id = 'mbBox'; w.className = 'mb-box';
  (document.getElementById('phone') || document.body).appendChild(w);
  mbPaint();
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function mbPaint(){
  const w = document.getElementById('mbBox'); if (!w) return;
  const o = MB.opts || {};
  const fondo = (typeof sdScrFondo === 'function') ? sdScrFondo() : '';
  if (MB.tocchi < 3){
    w.innerHTML = fondo + '<div class="sd-scr"><div class="sd-scr-in" onclick="mbTocca()"><small>' + esc(o.titolo || 'Mystery box') + '</small><p class="sd-scr-sotto">' + esc(o.sotto || 'Toccala tre volte per aprirla') + '</p>'
      + '<div class="sd-scr-box forziere t' + MB.tocchi + '"><img src="img/mystery/chiusa.webp" alt="La mystery box"></div>'
      + '<div class="sd-scr-dots">' + [0, 1, 2].map(function(j){ return '<i class="' + (j < MB.tocchi ? 'on' : '') + '"></i>'; }).join('') + '</div></div></div>';
    return;
  }
  /* 0.9.322, Andrea: si apre, un secondo di nero, poi UN premio solo al centro. Niente scatola aperta dietro, niente "Dal mercato" */
  if (!MB.visto){
    MB.visto = true;
    w.innerHTML = fondo + '<div class="sd-scr"><div class="sd-scr-in aperto"><div class="sd-scr-aperto mb-solo-box"><img src="img/mystery/aperta.webp" alt="" onerror="this.remove()"></div></div></div>';
    mbNeroPoi(w, mbPaint);
    return;
  }
  const p = o.premio || { ico: '🪙', t: '' };
  w.innerHTML = fondo + '<div class="sd-scr"><div class="sd-scr-in aperto mb-premio-solo"><span class="mb-premio-ico">' + (p.ico || '🪙') + '</span><b>' + esc(p.t || '') + '</b>' + (p.s ? '<p>' + esc(p.s) + '</p>' : '')
    /* 0.9.317, Andrea: "come Duolingo: Ottieni altre ricompense, che fa vedere un altro annuncio". Una volta per scatola, mai con Premium */
    + (!o.altre && typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile() ? '<button type="button" class="mb-altre" onclick="mbAltre()">▶ Ottieni altre ricompense</button>' : '')
    + '<button type="button" class="cta sd-scr-cta" onclick="mbChiudi()">' + esc(o.bottone || 'Continua') + '</button></div></div>';
}
/* la scatola aperta per un attimo, un secondo di nero, poi il suono del premio e il premio */
function mbNeroPoi(host, poi){
  setTimeout(function(){
    let n = document.getElementById('mbNero');
    if (!n){ n = document.createElement('div'); n.id = 'mbNero'; (document.getElementById('phone') || document.body).appendChild(n); }
    setTimeout(function(){
      try{ poi(); }catch(_){ }
      try{ if (typeof fxSuona === 'function') fxSuona('fine'); flVibra([30, 60, 120]); }catch(_){ }
      n.classList.add('via'); setTimeout(function(){ n.remove(); }, 320);
    }, 1000);
  }, 620);
}
function mbAltre(){
  if (typeof adsRicompensa !== 'function') return;
  adsRicompensa(function(){
    if (!MB.opts) return;
    const c = scrContenuto('bronzo', { k: 'breve', x: 1 }, 0);
    if (c.monete && typeof ffAddCoins === 'function') ffAddCoins(c.monete);
    if (c.dp) scrAddDP(c.dp);
    const s = scrStato();
    if (c.suono && s.suoni.indexOf(c.suono) < 0) s.suoni.push(c.suono);
    scrSalva(s);
    MB.opts.altre = true;
    MB.opts.premio = scrPremioDi(c);
    try{ flVibra([30, 40, 90]); }catch(_){ }
    mbPaint();
  });
}
function mbTocca(){
  MB.tocchi++;
  try{ flVibra(MB.tocchi === 3 ? [30, 40, 90] : 16); if (typeof gnAu !== 'undefined') gnAu.scelta(MB.tocchi + 1); }catch(_){ }
  mbPaint();
}
function mbChiudi(){
  const w = document.getElementById('mbBox'); if (!w) return;
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 260);
  const f = MB.opts && MB.opts.onChiudi; MB.opts = null;
  try{ if (typeof f === 'function') f(); }catch(_){ }
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.mb-box{position:fixed;inset:0;z-index:9850;overflow:hidden;background:radial-gradient(circle at 50% 46%,#1F6FD1 0%,#0B3E86 38%,#001E44 78%);opacity:0;transition:opacity .25s}',
    '.mb-box.in{opacity:1}.mb-box .sd-scr{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;color:#fff}',
    '.mb-box .sd-scr-in b{color:#fff}',
    '.mb-altre{display:block;width:min(320px,100%);min-height:52px;margin:0 auto 10px;border:2px solid rgba(255,255,255,.75);border-radius:26px;background:transparent;color:#fff;font:800 15.5px var(--font-body);cursor:pointer}',
    '.mb-extra{list-style:none;padding:0;margin:14px auto 26px;max-width:320px;display:flex;flex-direction:column;gap:8px;text-align:left}',
    '.mb-extra li{display:flex;gap:12px;align-items:center;background:rgba(255,255,255,.12);border-radius:16px;padding:11px 14px}',
    '.mb-extra li > span{font-size:24px;flex:none}.mb-extra b{display:block;margin:0!important;font:800 14.5px/1.3 var(--font-body)!important;color:#fff}',
    '.mb-extra em{display:block;font:500 12.5px/1.35 var(--font-body);font-style:normal;color:rgba(255,255,255,.75)}',
    '.scr-mb{display:inline-block}.scr-mb img{display:block;width:120px;height:auto;filter:drop-shadow(0 12px 18px rgba(0,30,80,.35))}.scr-mb.open img{width:110px}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---- la pausa vera: dieci minuti con l'app in secondo piano dopo una sessione lunga ------- */
let SCR_HID = 0;
document.addEventListener('visibilitychange', function(){
  if (document.hidden){ SCR_HID = Date.now(); return; }
  const s = scrStato();
  if (!s.pausa || s.pausa.bonus || !SCR_HID) return;
  const via = Date.now() - SCR_HID;
  if (SCR_HID >= s.pausa.dopo - 60000 && via >= SCR_PAUSA_MIN * 60000 && (Date.now() - s.pausa.dopo) < 3 * 3600000){
    s.pausa.bonus = true; scrSalva(s);
    if (typeof toast === 'function') toast('Pausa vera: la prossima sessione vale il 25% in più');
  }
});

/* ---- il Monk Mode: trenta giorni, quindici ore a settimana ------------------------------- */
function scrMinutiTra(da, a){
  let tot = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(h => { const t = h.start || h.at; if (h.ok && t >= da && t < a) tot += Math.round((h.spentMs || h.min * 60000) / 60000); }); }catch(_){ }
  return tot;
}
function scrStagioneInizia(){
  const s = scrStato();
  s.stagione = { inizio: Date.now(), fine: Date.now() + SCR_STAGIONE_GIORNI * 86400000, obiettivo: SCR_STAGIONE_OBIETTIVO };
  scrSalva(s);
  if (typeof toast === 'function') toast('Monk Mode: trenta giorni, quindici ore a settimana');
  if (typeof frPaint === 'function') frPaint();
}
function scrStagioneSettimane(st){
  const out = [];
  for (let t = st.inizio; t < Math.min(st.fine, Date.now() + 1); t += 7 * 86400000){
    const fine = Math.min(t + 7 * 86400000, st.fine);
    out.push({ da: t, a: fine, min: scrMinutiTra(t, fine), corrente: Date.now() >= t && Date.now() < fine });
  }
  return out;
}

/* ---- la sezione nella pagina Amici -------------------------------------------------------- */
function scrSezioneHtml(){
  const s = scrStato();
  const dp = scrDP();
  const ultimi = s.aperti.slice(-4).reverse();
  let html = '<div class="sect" style="margin-top:18px"><b>🎁 Mystery box</b></div>';
  html += '<div class="fr-card scr-card"><div><b>' + dp + ' Dream Points</b><small>Non si spendono qui: valgono nel programma fedeltà dello shop, per upgrade ed esperienze.</small></div><span class="scr-big">✨</span></div>';
  html += '<div class="fr-card scr-card"><div><b>' + s.aperti.length + (s.aperti.length === 1 ? ' mystery box aperta' : ' mystery box aperte') + (s.rotti ? ' · ' + s.rotti + ' rott' + (s.rotti === 1 ? 'a' : 'e') : '') + '</b>'
    + (ultimi.length ? '<small>' + ultimi.map(a => SCR_TIER[a.tier].ico + ' ' + SCR_TIER[a.tier].n + ' · ' + a.min + ' min').join('  ·  ') + '</small>' : '<small>Il primo arriva alla prossima sessione finita.</small>')
    + '</div></div>';
  html += '<div class="scr-tab">'
    + '<div><b>10 min</b><small>×1 · mystery box a volte, mai d’oro</small></div>'
    + '<div><b>25 min</b><small>×3 · argento o oro ogni tanto</small></div>'
    + '<div><b>50+ min</b><small>×8 · mystery box sicura, alta</small></div>'
    + '</div>';
  html += '<p class="hintline" style="padding:6px 2px 0">Una sessione mollata rompe la mystery box. Dieci minuti lontano dal telefono dopo una sessione lunga valgono un 25% in più sulla successiva.</p>';
  if (s.suoni.length) html += '<p class="hintline" style="padding:4px 2px 0">Suoni aperti: ' + s.suoni.map(id => esc(typeof sndName === 'function' ? (sndName(id) || id) : id)).join(', ') + '.</p>';

  html += '<div class="sect" style="margin-top:18px"><b>🏔️ Monk Mode</b></div>';
  const st = s.stagione;
  if (!st || Date.now() >= st.fine){
    if (st){
      const sett = scrStagioneSettimane(st), chiuse = sett.filter(w => w.min >= st.obiettivo).length;
      html += '<div class="fr-card scr-card"><div><b>Stagione finita</b><small>' + chiuse + ' settimane su ' + sett.length + ' sopra le quindici ore.</small></div></div>';
    }
    html += '<div class="fr-card scr-card"><div><b>Trenta giorni, quindici ore a settimana</b><small>Una stagione con un obiettivo che si vede ogni settimana. Chi la chiude sale nel tabellone degli amici.</small></div></div>'
      + '<button type="button" class="cta" style="margin:10px 0" onclick="scrStagioneInizia()">Inizia il Monk Mode</button>';
  } else {
    const sett = scrStagioneSettimane(st);
    const cur = sett.filter(w => w.corrente)[0] || sett[sett.length - 1];
    const pct = Math.min(100, Math.round(cur.min / st.obiettivo * 100));
    const giorni = Math.max(0, Math.ceil((st.fine - Date.now()) / 86400000));
    const chiuse = sett.filter(w => w.min >= st.obiettivo).length;
    html += '<div class="fr-card scr-card scr-stag"><div><b>Settimana ' + (sett.indexOf(cur) + 1) + ': ' + Math.floor(cur.min / 60) + ' h ' + (cur.min % 60) + ' su 15 h</b>'
      + '<div class="scr-bar"><i style="width:' + pct + '%"></i></div>'
      + '<small>' + giorni + (giorni === 1 ? ' giorno' : ' giorni') + ' alla fine della stagione · ' + chiuse + (chiuse === 1 ? ' settimana chiusa' : ' settimane chiuse') + '</small></div></div>';
  }
  return html;
}

(function(){
  const css = [
    '.scr-box{width:100%;max-width:330px;margin:22px auto 0;padding:14px 14px 12px;border-radius:16px;background:rgba(255,255,255,.14);text-align:center}',
    '.scr-box > b{display:block;font:800 16px var(--font-display);font-style:italic;color:#fff}',
    '.scr-box > small{display:block;margin-top:4px;font:500 12.5px/1.5 var(--font-body);color:rgba(255,255,255,.8)}',
    '.scr-dp{margin:0 0 10px;font:800 15px var(--font-body);color:#fff}.scr-dp i{font:600 12px var(--font-body);font-style:normal;color:rgba(255,255,255,.75)}',
    '.scr-chest{display:block;width:76px;height:76px;margin:6px auto 8px;border:none;border-radius:20px;font-size:38px;line-height:76px;background:rgba(255,255,255,.18);color:#fff;animation:scrShake 1.6s ease-in-out infinite;cursor:pointer}',
    '.scr-chest.bronzo{background:#B5703A}.scr-chest.argento{background:#8E9BB0}.scr-chest.oro{background:#E8B531;box-shadow:0 0 24px rgba(232,181,49,.55)}.scr-chest.leggendario{background:#3F9FF4;box-shadow:0 0 28px rgba(63,159,244,.6)}',
    '.scr-chest.open{animation:scrPop .5s ease-out 1}.scr-chest.rotto{animation:none;background:rgba(0,0,0,.25)}',
    '@keyframes scrShake{0%,80%,100%{transform:rotate(0)}84%{transform:rotate(-6deg)}88%{transform:rotate(6deg)}92%{transform:rotate(-4deg)}96%{transform:rotate(4deg)}}',
    '@keyframes scrPop{0%{transform:scale(.6)}60%{transform:scale(1.15)}100%{transform:scale(1)}}',
    '.scr-loot{list-style:none;margin:10px 0 0;padding:0;text-align:left}.scr-loot li{padding:6px 0;border-top:1px solid rgba(255,255,255,.15);font:600 13.5px var(--font-body);color:#fff}',
    '.scr-loot li.scr-frase{font:600 13.5px/1.45 var(--font-display);font-style:italic}',
    '.scr-loot li.scr-lettera button{width:100%;margin-top:6px;border:1.5px dashed var(--blue,#0075E3);border-radius:12px;background:transparent;padding:10px 12px;font:600 13.5px var(--font-body);color:var(--navy);text-align:left;cursor:pointer}',
    '.scr-loot li.scr-lettera button b{float:right;color:var(--blue,#0075E3)}',
    'body.dark .scr-loot li.scr-lettera button{color:#fff}',
    '.scr-pausa{margin:10px 0 0;font:500 12px/1.5 var(--font-body);color:rgba(255,255,255,.8)}',
    '.scr-premio{position:fixed;inset:0;z-index:9150;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(2,9,38,.86);opacity:0;transition:opacity .25s}',
    '.scr-cassa{position:relative;width:132px;height:118px;margin:0 auto;--c0:#E8B078;--c1:#B5703A;--c2:#7A4A22;--gl:rgba(255,184,110,.55)}',
    '.scr-cassa.argento{--c0:#F2F5FA;--c1:#9AA6B8;--c2:#5F6B7D;--gl:rgba(200,214,232,.6)}',
    '.scr-cassa.oro{--c0:#FFE9A8;--c1:#F5B301;--c2:#B9741C;--gl:rgba(255,214,102,.65)}',
    '.scr-cassa.leggendario{--c0:#E3F1FF;--c1:#3F9FF4;--c2:#005BB0;--gl:rgba(140,198,255,.65)}',
    '.scr-cassa .scr-glow{position:absolute;left:50%;top:50%;width:230px;height:230px;margin:-115px 0 0 -115px;border-radius:50%;background:radial-gradient(circle,var(--gl),transparent 62%);opacity:0;transition:opacity .6s;pointer-events:none}',
    '.scr-cassa.open .scr-glow{opacity:1}',
    '.scr-cassa .scr-body{position:absolute;left:10px;right:10px;bottom:6px;height:66px;border-radius:10px 10px 16px 16px;background:linear-gradient(180deg,var(--c1),var(--c2));box-shadow:inset 0 -6px 0 rgba(0,0,0,.18),0 14px 26px rgba(0,0,0,.35);z-index:1}',
    '.scr-cassa .scr-band{position:absolute;left:0;right:0;top:22px;height:10px;background:rgba(0,0,0,.18)}',
    '.scr-cassa .scr-band:before,.scr-cassa .scr-band:after{content:"";position:absolute;top:-22px;bottom:-34px;width:10px;background:rgba(0,0,0,.14)}.scr-cassa .scr-band:before{left:18px}.scr-cassa .scr-band:after{right:18px}',
    '.scr-cassa .scr-lock{position:absolute;left:50%;top:12px;width:22px;height:26px;margin-left:-11px;border-radius:6px;background:linear-gradient(180deg,#FFE08A,#D9A21B);box-shadow:0 2px 6px rgba(0,0,0,.3);z-index:3}',
    '.scr-cassa .scr-lock:after{content:"";position:absolute;left:8px;top:8px;width:6px;height:9px;border-radius:3px;background:rgba(0,0,0,.35)}',
    '.scr-cassa .scr-lid{position:absolute;left:6px;right:6px;top:16px;height:48px;border-radius:30px 30px 6px 6px;background:linear-gradient(180deg,var(--c0),var(--c1));box-shadow:inset 0 -5px 0 rgba(0,0,0,.14);transform-origin:50% 100%;transition:transform .7s cubic-bezier(.2,.8,.2,1);z-index:2}',
    '.scr-cassa .scr-lid i{position:absolute;left:0;right:0;bottom:8px;height:8px;background:rgba(0,0,0,.14)}',
    '.scr-cassa.open .scr-lid{transform:perspective(320px) rotateX(-112deg) translateY(-4px)}',
    '.scr-cassa:not(.open){animation:scrShake 1.6s ease-in-out infinite}',
    '.scr-cassa .scr-sp{position:absolute;color:#FFE08A;font-size:16px;opacity:0;pointer-events:none;z-index:4}',
    '.scr-cassa .scr-sp.a{left:6px;top:18px}.scr-cassa .scr-sp.b{right:4px;top:6px;font-size:20px}.scr-cassa .scr-sp.c{left:56px;top:-14px;font-size:13px}',
    '.scr-cassa.open .scr-sp{animation:scrSpark 1.2s ease-out infinite}.scr-cassa.open .scr-sp.b{animation-delay:.3s}.scr-cassa.open .scr-sp.c{animation-delay:.6s}',
    '@keyframes scrSpark{0%{opacity:0;transform:translateY(6px) scale(.6)}30%{opacity:1}100%{opacity:0;transform:translateY(-18px) scale(1.1)}}',
    '.scr-chest-btn{border:none;background:transparent;cursor:pointer;padding:6px 0 0;margin:0 auto 8px;display:block}',
    '.scr-cassa-host{padding:18px 0 6px}',
    '.scr-premio .scr-loot{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:14px;text-align:center}',
    '.scr-premio .scr-loot li{border-top:0;padding:8px 12px;border-radius:99px;background:rgba(255,255,255,.14);font:700 13px var(--font-body);color:#fff}',
    '.scr-premio .scr-loot li.scr-frase{width:100%;border-radius:14px;font:600 13px/1.45 var(--font-display);font-style:italic}',
    '.scr-premio .am-cta{margin-top:22px}',
    '.scr-premio.in{opacity:1}',
    '.scr-premio-in{width:100%;max-width:340px;padding:26px 22px 24px;border-radius:26px;background:linear-gradient(180deg,rgba(2,9,38,.35),rgba(2,9,38,.86)),url(img/dream-night.jpg) center/cover no-repeat,#020926;border:1px solid rgba(255,255,255,.12);text-align:center;color:#fff;box-shadow:0 24px 60px rgba(0,0,0,.5)}',
    '.scr-premio-in > small{display:block;margin-bottom:8px;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.7)}',
    '.scr-premio-in > b{display:block;font:800 18px var(--font-display);font-style:italic;color:#fff}',
    '.scr-premio-in .scr-loot li{color:#fff}',
    '.scr-premio-in .cta{margin-top:24px}',
    '.scr-card{margin-bottom:8px}.scr-card > div{flex:1}.scr-big{font-size:24px;flex:none}',
    '.scr-tab{display:flex;gap:8px;margin-top:2px}.scr-tab > div{flex:1;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 8px;text-align:center}',
    '.scr-tab b{display:block;font:800 13px var(--font-body);color:var(--navy)}.scr-tab small{display:block;margin-top:2px;font:500 10.5px/1.35 var(--font-body);color:var(--muted)}',
    'body.dark .scr-tab > div{background:#12203A;border-color:#22345A}body.dark .scr-tab b{color:#fff}',
    '.scr-bar{height:8px;margin:8px 0 6px;border-radius:99px;background:rgba(0,117,227,.15);overflow:hidden}.scr-bar i{display:block;height:100%;border-radius:99px;background:var(--blue)}',
    '.snd-row.lock{opacity:.6}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '#mbNero{position:fixed;inset:0;z-index:10040;background:#000;transition:opacity .3s ease}#mbNero.via{opacity:0}'
    + '.mb-solo-box{animation:mbSu .5s ease-out both}@keyframes mbSu{from{transform:scale(.9)}to{transform:scale(1.04)}}'
    + '.mb-premio-solo{justify-content:center;text-align:center}.mb-premio-ico{display:block;font-size:112px;line-height:1.1;animation:mbPop .6s cubic-bezier(.2,1.6,.4,1) both;filter:drop-shadow(0 12px 28px rgba(0,0,0,.4))}@keyframes mbPop{from{transform:scale(.3);opacity:0}to{transform:none;opacity:1}}'
    + '.mb-premio-solo > b{display:block;margin-top:18px;font:800 32px var(--font-display);color:#fff}.mb-premio-solo > p{margin:8px 0 0;font:600 16px var(--font-body);color:#D6E8FF}.mb-premio-solo > .cta,.mb-premio-solo > .mb-altre{margin-top:34px}';
  document.head.appendChild(st);
})();
