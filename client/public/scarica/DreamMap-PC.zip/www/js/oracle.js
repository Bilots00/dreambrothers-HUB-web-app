/* oracle.js - la sfera che indovina chi stai diventando.

   Il gioco delle venti domande, come lo faceva il genio nel 2007: nessun modello di linguaggio,
   nessuna chiamata a un server, nessun token. Un catalogo di otto "te del futuro", ognuno con
   la probabilità di rispondere sì a ciascuna domanda; a ogni risposta le probabilità dei
   profili si aggiornano (regola di Bayes), e la domanda successiva è quella che separa di più
   i profili rimasti (massimo guadagno di informazione). Ci si ferma quando un profilo domina.

   La parte che fa sembrare magia: alcune risposte l'oracolo le sa GIÀ, perché le ha lette nel
   telefono (ore di schermo, focus più lungo, notifiche, ora dell'ultimo sblocco, la striscia
   della Modalità severa). Vengono applicate prima della prima domanda, e dette in faccia. */

const OR = { on: false, step: '', target: '', trigger: [], post: [], asked: [], answers: {}, q: null, n: 0, known: [], result: null, plan: [], hist: [],
  sogno: '', sognoMio: '', ai: null, aiP: null, giro: 0, knownP: null, knownFatti: false, analisi: null, triggerTesto: '', trigScrivi: false,
  idScrivi: false, idTesto: '', idqPrec: null, tgScrivi: false, personaMia: '', corScrivi: false, corTesto: '', planDa: '' };
const OR_KEY = 'fl_oracle';

/* ---------- 0.9.304: la lettura parte dal sogno che l'utente ha GIA' scelto ----------
   Andrea: "Pensa alla persona che vuoi diventare" non va piu', il sogno l'ha gia' scelto. Si conferma il sogno,
   il Genio dice la frase di F.M. Alexander e la lega al sogno (per arrivarci devi diventare una persona con certe
   abitudini), poi legge i dati e fa le domande. Gratis: la persona viene da qui sotto, le domande da OR_Q.
   Premium: l'agente le riscrive sul sogno, e la chiamata parte appena si apre la lettura. */
const OR_ALEXANDER = 'Le persone non decidono il proprio futuro: decidono le proprie abitudini, e le loro abitudini decidono il loro futuro.';
/* 0.9.376, Andrea: "non voglio che dica sempre la frase di F.M. Alexander: che la frase vari di volta in volta, frasi celebri e frasi
   del Genio, cosi' il gioco non e' sempre lo stesso". Ogni lettura ne pesca una diversa dall'ultima */
const OR_FRASI = [
  ['Siamo ciò che facciamo ripetutamente. L\'eccellenza, quindi, non è un atto, ma un\'abitudine.', 'Aristotele'],
  ['Le tue abitudini determineranno il tuo futuro.', 'Jack Canfield'],
  ['Ogni azione che compi è un voto per il tipo di persona che desideri diventare.', 'James Clear'],
  ['Il successo non è altro che poche semplici discipline praticate ogni giorno.', 'Jim Rohn'],
  ['Fai attenzione alle tue abitudini, perché diventano il tuo carattere. Fai attenzione al tuo carattere, perché diventa il tuo destino.', 'Lao Tzu'],
  ['Le persone non decidono il proprio futuro: decidono le proprie abitudini, e le loro abitudini decidono il loro futuro.', 'F.M. Alexander'],
  ['Sei la media delle cinque persone che frequenti di più.', 'Jim Rohn'],
  ['Non ho bisogno di una sfera di cristallo per vedere il tuo domani: mi basta guardare cosa fai oggi senza pensarci.', ''],
  ['Dimmi cosa ripeti ogni giorno e ti dirò dove sarai tra cinque anni. Iniziamo.', ''],
  ['Il destino non è scritto nelle stelle, ma nella tua routine. Vediamo se riesco a indovinarlo.', ''],
  ['I grandi cambiamenti fanno rumore, ma sono i piccoli gesti silenziosi a decidere chi diventerai.', ''],
  ['Credi di scegliere il tuo futuro? In realtà stai solo eseguendo il programma delle tue abitudini. Mettiamolo alla prova.', ''],
  ['Se guardi le persone nella tua cerchia e non ti senti ispirato, allora non hai una cerchia. Hai una gabbia.', ''],
  ['Guarda bene chi hai intorno: ti stanno aiutando a volare o ti tengono chiuso in una gabbia?', ''],
  ['Dimmi con chi passi le tue giornate e non avrò bisogno di altro per indovinare chi sei.', ''],
  ['La tua mente è un proiettore: il futuro che vedrai fuori è solo il riflesso di ciò che credi dentro.', ''],
  ['Non ottieni ciò che desideri, ottieni ciò che credi di meritare. Vediamo cosa racconta la tua mente.', ''],
  ['La zona di comfort è un posto bellissimo, ma lì non cresce mai nulla. Dimmi quanto rischi oggi e ti dirò chi sarai domani.', ''],
  ['Il futuro premia chi osa, non chi aspetta di sentirsi pronto. Scopriamo se stai vivendo o se ti stai solo proteggendo.', ''],
  ['La sicurezza di oggi è spesso la prigione di domani. Vediamo se sei disposto a rompere le sbarre.', ''],
  ['I sogni senza azioni sono solo allucinazioni. Dimmi cosa fai quando nessuno ti guarda e ti svelerò il tuo destino.', ''],
  ['Il tuo futuro non dipende solo da ciò che inizi a fare oggi, ma soprattutto da ciò che hai il coraggio di smettere di fare.', ''],
  ['Un sogno resta un desiderio finché non diventa un\'abitudine. Vediamo quanto è reale il tuo.', ''],
  ['Non dirmi quanto è grande il tuo sogno: mostrami la tua agenda e capirò subito se si avvererà.', ''],
  ['Puoi avere il seme migliore del mondo, ma se lo pianti nel terreno sbagliato non crescerà mai. Com\'è l\'ambiente intorno a te?', ''],
  ['Il tuo futuro è già scritto nelle tue abitudini attuali, ma la penna è ancora in mano tua. Sei pronto a riscrivere la storia?', ''],
  ['Cambia ambiente, cambia abitudini, cambia mente: ecco l\'unica magia capace di alterare il destino.', ''],
  ['Hai il coraggio di guardare la tua vita negli occhi? Vediamo se sei davvero tu a guidarla.', '']
];
function orFraseScegli(){
  let ult = -1; try{ ult = +localStorage.getItem('fl_or_frase'); }catch(_){ }
  let i = Math.floor(Math.random() * OR_FRASI.length); if (i === ult) i = (i + 1) % OR_FRASI.length;
  try{ localStorage.setItem('fl_or_frase', String(i)); }catch(_){ }
  OR.frase = OR_FRASI[i];
}
function orFrase(){ if (!OR.frase) orFraseScegli(); return OR.frase; }
/* 0.9.309, Andrea: la frase di Alexander arrivava "schiaffata li'", senza contesto. Prima il Genio la introduce con
   due battute a macchina da scrivere, una per tocco, poi la frase. */
const OR_ALEX_INTRO = [
  'Prima di leggere il tuo futuro, ti racconto una cosa che ho visto succedere mille volte.',
  'Chi realizza il suo sogno, quasi sempre, ha cominciato cambiando *quello che fa ogni giorno*. Te lo dico così:'
];
/** la chiave della vignetta che si sta battendo: le battute dell'introduzione e la frase hanno ognuna la sua */
function orTwChiave(){ return OR.step === 'alexander' ? 'alexander' + (OR.alxI || 0) : OR.step; }
/* 0.9.377, Andrea: "nessuno si autocita: ~ il Genio sembra una presa in giro". Le frasi celebri hanno virgolette e autore; quelle del
   Genio le dice lui, senza virgolette e senza firma */
function orFraseTesto(){ const f = orFrase(); return f[1] ? '"' + f[0] + '"' : f[0]; }
function orAlexTesto(){ const i = OR.alxI || 0; return i < OR_ALEX_INTRO.length ? (i === OR_ALEX_INTRO.length - 1 && !orFrase()[1] ? OR_ALEX_INTRO[i].replace(/ Te lo dico così:$/, '') : OR_ALEX_INTRO[i]) : orFraseTesto(); }
/* 0.9.306, Andrea: "ogni giorno costruisce un pezzo del suo progetto" e' un'ovvieta' da poster, non trova il collo di
   bottiglia. La persona nasce dai dati veri (orPersonaDaiDati): l'app che lo prende di piu' e l'ora in cui cede, il
   trigger della lettura di prima, l'ostacolo dei suoi episodi, le ore sullo schermo. Questa tabella resta solo per chi
   non ha ancora nessun dato: un'abitudine precisa e misurabile per il tipo di sogno, mai una frase generica. */
const OR_PERSONA = {
  studio:   'una persona che studia due ore ogni mattina, con il telefono in un’altra stanza',
  corpo:    'una persona che si allena tre volte a settimana alla stessa ora, anche quando è stanca',
  lavoro:   'una persona che ogni mattina lavora un’ora al progetto prima di aprire i messaggi',
  arte:     'una persona che crea per mezz’ora ogni mattina, prima di guardare il telefono',
  carriera: 'una persona che ogni mattina finisce la cosa più importante prima di aprire la posta',
  presenza: 'una persona che a cena lascia il telefono in un’altra stanza',
  altro:    'una persona che ogni mattina dedica mezz’ora al sogno, prima di aprire i messaggi'
};
/* i pezzi della frase per ogni tipo di sogno: e = cosa fa al posto del telefono ("chiude Instagram e ..."),
   prima = cosa finisce prima di aprire l'app, n = con cosa comincia la giornata, a = a chi da' l'ora tolta al telefono */
const OR_AZIONE = {
  studio:   { e: 'apre i libri', prima: 'finisce la prima ora di studio', n: 'un’ora di studio', a: 'allo studio', fa: 'studia' },
  corpo:    { e: 'va ad allenarsi', prima: 'si allena', n: 'l’allenamento', a: 'all’allenamento', fa: 'si allena' },
  lavoro:   { e: 'apre il progetto', prima: 'finisce la prima ora di lavoro sul progetto', n: 'un’ora sul progetto', a: 'al progetto', fa: 'lavora' },
  arte:     { e: 'si mette a creare', prima: 'crea per mezz’ora', n: 'mezz’ora di creazione', a: 'a quello che crea', fa: 'crea' },
  carriera: { e: 'si dedica alla cosa che conta di più', prima: 'finisce la cosa più importante della giornata', n: 'la cosa più importante', a: 'alla cosa che conta di più', fa: 'lavora' },
  presenza: { e: 'torna da chi ha accanto', prima: 'passa un’ora vera con chi ama', n: 'mezz’ora con chi ama', a: 'a chi ama', fa: 'sta con chi ama' },
  altro:    { e: 'fa il passo di oggi verso il sogno', prima: 'fa il passo di oggi verso il sogno', n: 'il passo di oggi verso il sogno', a: 'al sogno', fa: 'lavora' }
};
/* l'ostacolo degli episodi (domande.js, DQ_OSTACOLI) o del profilo dell'Io Futuro: l'abitudine che lo smonta */
function orPersonaOstacolo(k, z){
  return ({
    direzione:  'una persona che ogni sera scrive il primo passo del giorno dopo',
    partenza:   'una persona che comincia la giornata con ' + z.n + ', prima di guardare il telefono',
    rimando:    'una persona che la cosa che vorrebbe rimandare la comincia subito, anche solo per due minuti',
    energia:    'una persona che alle 23 spegne il telefono e dorme sette ore',
    attenzione: (z === OR_AZIONE.presenza || z === OR_AZIONE.corpo)
      ? 'una persona che, quando ' + z.fa + ', tiene il telefono in un’altra stanza'
      : 'una persona che ' + z.fa + ' a blocchi di 25 minuti, con il telefono in un’altra stanza',
    paura:      'una persona che ogni giorno finisce un pezzo e lo fa vedere, anche se non è perfetto',
    troppo:     'una persona che ogni mattina sceglie una sola cosa e la finisce prima di passare ad altro',
    ambiente:   'una persona che ogni domenica racconta a qualcuno a che punto è',
    imparare:   'una persona che ogni giorno passa venti minuti a imparare la cosa che le manca',
    invisibili: 'una persona che ogni sera segna il passo che ha fatto',
    identita:   'una persona che ogni giorno comincia con ' + z.n + ', prima di tutto il resto'
  })[k] || '';
}
/* l'ora detta come la direbbe una persona */
function orOraFrase(h){ return h === 0 ? 'a mezzanotte' : (h === 1 ? 'all’una' : (h === 12 ? 'a mezzogiorno' : 'alle ' + h)); }
/** I DATI VERI, letti mentre l'utente conferma il sogno: l'app che apre di piu' (le riprese sotto il mezzo minuto
    contano piu' dei minuti: sono il gesto automatico) e l'ora in cui la apre di piu', negli ultimi tre giorni. */
async function orDatiPersona(){
  const out = { app: '', ora: -1 };
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline || typeof tlGiorno !== 'function') return out;
    const mappa = {};
    let excl = []; try{ if (typeof insExcl === 'function') excl = insExcl() || []; }catch(_){ }
    const fuori = function(p, l){
      const pk = String(p || '').toLowerCase(), lb = String(l || '');
      if (!pk || excl.indexOf(pk) >= 0) return true;
      if (typeof TL_DM !== 'undefined' && pk === TL_DM) return true;
      if (typeof tlLauncher === 'function' && tlLauncher(pk)) return true;
      return /launcher|\.home$|systemui|inputmethod|keyboard|honeyboard|packageinstaller|permissioncontroller|dialer|incallui|camera|clock|settings|calculator|contacts/i.test(pk)
        || /launcher|\bhome$|one ui/i.test(lb);
    };
    for (let off = 1; off <= 3; off++){
      const da = tlGiorno(off);
      let d = null; try{ d = await NATIVE.getTimeline({ from: da, to: da + 86400000, minMs: 0, limit: 1800 }); }catch(_){ d = null; }
      if (!d || !d.granted) continue;
      (d.grani || []).forEach(function(x){
        if (!x || fuori(x.p, x.l)) return;
        const k = x.p;
        const m = mappa[k] || (mappa[k] = { l: x.l || x.p, ms: 0, n: 0, lampi: 0, ore: new Array(24).fill(0) });
        m.ms += x.ms || 0; m.n++; if ((x.ms || 0) < 30000) m.lampi++;
        m.ore[new Date(x.s).getHours()]++;
      });
    }
    const l = Object.keys(mappa).map(function(k){ return mappa[k]; });
    const a = l.filter(function(m){ return m.lampi >= 8; }).sort(function(x, y){ return y.lampi - x.lampi; })[0]
      || l.filter(function(m){ return m.ms >= 20 * 60000; }).sort(function(x, y){ return y.ms - x.ms; })[0];
    if (!a) return out;
    out.app = String(a.l || '').trim();
    let h = -1, top = 0; a.ore.forEach(function(v, i){ if (v > top){ top = v; h = i; } });
    if (top >= 3) out.ora = h;
  }catch(_){ }
  return out;
}
/** La persona del sogno dai dati dell'utente: { t, fonte }. fonte '' = nessun dato, si usa la frase per tipo. */
function orPersonaDaiDati(){
  const z = OR_AZIONE[OR.target] || OR_AZIONE.altro;
  const d = OR.dati || {};
  const app = d.app ? d.app.replace(/[<>"]/g, '') : '';
  /* 1. l'app che lo prende e l'ora in cui cede */
  if (app && d.ora >= 0){
    if (d.ora >= 23 || d.ora < 5) return { t: 'una persona che alle 23 chiude ' + app + ', lascia il telefono fuori dalla camera e va a dormire', fonte: 'tel' };
    return { t: 'una persona che ' + orOraFrase(d.ora) + ' chiude ' + app + ' e ' + z.e, fonte: 'tel' };
  }
  if (app) return { t: 'una persona che ' + z.prima + ' prima di aprire ' + app, fonte: 'tel' };
  /* 2. il trigger che ha scelto nella lettura di prima */
  const tr = (OR.trigger || [])[0];
  const perTrigger = {
    letto: 'una persona che dorme con il telefono fuori dalla camera e la mattina ' + z.e + ' prima di guardarlo',
    noia: 'una persona che, quando si annoia, ' + z.e + ' invece di prendere il telefono',
    morti: 'una persona che nei momenti morti lascia il telefono in tasca',
    stress: 'una persona che, quando è sotto stress, fa un minuto di respiro lento invece di scorrere il telefono',
    lavoro: 'una persona che, quando ' + z.fa + ', tiene il telefono in un’altra stanza'
  }[tr];
  if (perTrigger) return { t: perTrigger, fonte: 'trigger' };
  /* 3. l'ostacolo che e' uscito dagli episodi, o dalle risposte sull'Io Futuro */
  let ost = '';
  try{ if (typeof dqOstacoli === 'function'){ const o = dqOstacoli()[0]; if (o && o.w > 0) ost = o.k; } }catch(_){ }
  if (!ost){
    try{
      if (typeof ifProfiloOra === 'function'){
        const p = ifProfiloOra(), v = p && p.ostacolo && p.ostacolo.valore;
        ost = { dispersione: 'attenzione', procrastinazione: 'rimando', stanchezza: 'energia', perfezionismo: 'paura' }[v] || '';
      }
    }catch(_){ }
  }
  const po = ost ? orPersonaOstacolo(ost, z) : '';
  if (po) return { t: po, fonte: 'ostacolo' };
  /* 4. le ore sullo schermo: un'ora tolta al telefono, data al sogno */
  const k14 = (OR.known || []).filter(function(x){ return x.q === 'q14' && x.a >= .5; })[0];
  if (k14) return { t: 'una persona che ogni giorno toglie un’ora al telefono e la dà ' + z.a, fonte: 'ore' };
  return { t: '', fonte: '' };
}
/* il campo del sogno quando l'onboarding non l'ha salvato: dalle parole del sogno */
function orTargetDaSogno(t){
  const s = String(t || '').toLowerCase();
  if (!s) return '';
  if (/esam|laure|concors|studi|universit|scuola|certificaz|maturit|test d/.test(s)) return 'studio';
  if (/forma|palestr|peso|chil|dimagr|maratona|corsa|correre|allen|muscol|fisico|salute/.test(s)) return 'corpo';
  if (/musica|canzon|album|libro|romanzo|scriver|disegn|dipin|video|canale|youtube|fotograf|film|arte|artist/.test(s)) return 'arte';
  if (/promozion|carriera|lavoro dei sogni|assunt|manager|stipendio|colloquio/.test(s)) return 'carriera';
  if (/famiglia|figli|amici|presente|presenza|partner|relazion/.test(s)) return 'presenza';
  if (/progett|business|aziend|impres|negozio|app\b|startup|libert|soldi|guadagn|vender|brand|clienti|aprire/.test(s)) return 'lavoro';
  return '';
}
/** Il sogno scelto, come lo vede l'utente nell'app (lo stesso nome della pagina Dream). '' se non c'e'. */
function orSognoScelto(){
  let s = '';
  try{ if (typeof nvSogno === 'function') s = nvSogno() || ''; }catch(_){ }
  if (!s){ try{ if (typeof gnLettura === 'function'){ const L = gnLettura(); if (L && L.sogno && L.sogno !== 'quel sogno') s = L.sogno; } }catch(_){ } }
  s = String(s || '').replace(/^[^\p{L}\p{N}"]+/u, '').trim();
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}
function orSognoAttuale(){ return OR.sognoMio || OR.sogno || ''; }
function orPersona(){
  /* 0.9.305: "Lo scrivo io" alla domanda sulla persona: le sue parole vincono su tutto */
  if (OR.personaMia) return OR.personaMia;
  /* 0.9.306: i dati veri vengono prima della frase dell'agente, che il sogno lo conosce ma le abitudini no */
  /* 0.9.376, Andrea: "una persona che alle 23 chiude Telegram? Telegram la uso per lavoro, e andare a dormire presto non e' quello che
     serve per guadagnare con il mio brand". Niente piu' la persona costruita sulle app: prima il capovolgimento del freno del sabotatore,
     poi quella del tuo agente (che conosce il sogno), poi quella del campo del sogno */
  try{ const k = (typeof orFreno === 'function') ? orFreno() : ''; if (k && typeof OR_CAPOVOLTO !== 'undefined' && OR_CAPOVOLTO[k]) return OR_CAPOVOLTO[k][0]; }catch(_){ }
  if (OR.ai && OR.ai.persona) return OR.ai.persona;
  return OR_PERSONA[OR.target] || OR_PERSONA.altro;
}
function orQT(q){ return (q && OR.ai && OR.ai.domande && OR.ai.domande[q.id]) || (q ? q.t : ''); }
function orTrT(t){ return (OR.ai && OR.ai.trigger && OR.ai.trigger[t.id]) || t.t; }
/* Premium come nelle chat della revisione (conversa.js): account collegato e abbonamento, o l'account di Andrea */
function orPremium(){
  try{
    if (!(typeof agPuo === 'function' && agPuo())) return false;
    return (typeof rnPremium === 'function' && rnPremium()) || (typeof flAdmin === 'function' && flAdmin());
  }catch(_){ return false; }
}
/* quello che torna dal server passa da qui: un testo che non e' una domanda non arriva a schermo */
function orAiPulisci(r){
  if (!r || typeof r !== 'object') return null;
  const out = { persona: '', domande: {}, trigger: {} };
  const p = String(r.persona || '').trim().replace(/[.!]+$/, '');
  if (/^una persona che \S/i.test(p) && p.length <= 160) out.persona = p.charAt(0).toLowerCase() + p.slice(1);
  OR_Q.forEach(function(q){ const t = r.domande && r.domande[q.id]; if (typeof t === 'string' && t.trim().length >= 10 && /\?$/.test(t.trim()) && t.length <= 170) out.domande[q.id] = t.trim(); });
  OR_TRIGGER.forEach(function(x){ const t = r.trigger && r.trigger[x.id]; if (typeof t === 'string' && t.trim().length >= 4 && t.length <= 90 && OR_TRIG_MOMENTO.test(t.trim())) out.trigger[x.id] = t.trim().replace(/[.?!]+$/, ''); });
  return (out.persona || Object.keys(out.domande).length) ? out : null;
}
/** PREMIUM: l'agente prepara la lettura mentre l'utente conferma il sogno. Se non risponde, restano i testi gratis. */
function orAgentePrepara(){
  OR.ai = null; OR.aiP = null;
  const giro = ++OR.giro;
  if (!orPremium() || typeof agApi !== 'function' || !orSognoAttuale()) return;
  let d = {};
  try{
    const a = (typeof agDati === 'function') ? agDati() : {};
    d = { nome: a.nome || '', entroQuando: a.quando || '', oreSettimana: a.ore || 0, sessioniFullFocus7giorni: a.sessioni || 0, minutiFullFocus7giorni: a.minuti || 0, freni: a.freni || '' };
    const l = orLast(); if (l && l.profile) d.letturaPrima = { profilo: orProfile(l.profile).name, pct: l.pct };
  }catch(_){ }
  let nomeAg = 'Genio'; try{ if (typeof agNomeAgente === 'function') nomeAg = agNomeAgente() || 'Genio'; }catch(_){ }
  const corpo = { sogno: orSognoAttuale(), tipo: OR.target || '', nomeAgente: nomeAg, dati: d,
    domande: OR_Q.map(function(q){ return { id: q.id, t: q.t }; }), trigger: OR_TRIGGER.map(function(t){ return { id: t.id, t: t.t }; }) };
  OR.aiP = Promise.race([
    Promise.resolve().then(function(){ return agApi('POST', '/api/focuslock/agent/lettura', corpo); }),
    new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, 12000); })
  ]).then(function(r){ if (giro === OR.giro) OR.ai = orAiPulisci(r); }).catch(function(){ });
}

/* ---------- chi vuoi diventare ---------- */
const OR_TARGETS = [
  { id: 'studio',   ico: '🎓', name: 'Chi passa l\'esame',                 sub: 'studio, concorso, certificazione' },
  { id: 'corpo',    ico: '🏃', name: 'Chi si rimette in forma',            sub: 'allenamento, sonno, energia' },
  { id: 'lavoro',   ico: '🚀', name: 'Chi costruisce qualcosa di suo',     sub: 'un business, un progetto, un side project' },
  { id: 'arte',     ico: '🎨', name: 'Chi crea',                            sub: 'musica, scrittura, disegno, video' },
  { id: 'carriera', ico: '💼', name: 'Chi cresce nel lavoro',              sub: 'competenze, focus, promozione' },
  { id: 'presenza', ico: '🌿', name: 'Chi è presente',                      sub: 'famiglia, amici, tempo vero' }
];
/* I TAG DI IDENTITA'. Ogni nodo dell'albero puo' dire qualcosa su CHI e' la persona, oltre che
   su quale profilo le somiglia: tipo di obiettivo (diventare / raggiungere), campo, valore,
   ostacolo. Le risposte date si sommano in un profilo identita' (iofuturo.js), salvato solo
   sul telefono. Il peso e' quanto quella risposta ne e' una prova. */
const OR_TAG_TARGET = {
  studio:   { tipo: { raggiungere: 1 },   dominio: { studio: 1.5 } },
  corpo:    { tipo: { diventare: 1 },     dominio: { fitness: 1.5 } },
  lavoro:   { tipo: { diventare: .5, raggiungere: .5 }, dominio: { business: 1.5 }, valore: { indipendenza: .7, liberta: .5 } },
  arte:     { tipo: { diventare: 1 },     dominio: { creativita: 1.5 }, valore: { padronanza: .7 } },
  carriera: { tipo: { raggiungere: 1 },   dominio: { carriera: 1.5 },  valore: { riconoscimento: .7 } },
  presenza: { tipo: { diventare: 1 },     dominio: { relazioni: 1.5 }, valore: { famiglia: 1 } }
};
const OR_TAG_TRIGGER = {
  letto:  { ostacolo: { stanchezza: 1 } },
  noia:   { ostacolo: { dispersione: .8 } },
  morti:  { ostacolo: { dispersione: 1 } },
  stress: { ostacolo: { stanchezza: .6, perfezionismo: .4 } },
  lavoro: { ostacolo: { dispersione: 1 } }
};
/* sulle domande il tag vale per il «si'»: pesato su quanto e' si' la risposta */
const OR_TAG_Q = {
  q2:  { ostacolo: { dispersione: .6 } },
  q4:  { ostacolo: { procrastinazione: 1 } },
  q6:  { ostacolo: { stanchezza: .7 } },
  q7:  { ostacolo: { procrastinazione: .6, perfezionismo: .3 } },
  q9:  { ostacolo: { dispersione: .6 } },
  q12: { ostacolo: { stanchezza: .5 } }
};
/* LE DOMANDE DI IDENTITA': una sola al giorno, dentro alla partita, e solo sull'attributo che
   il profilo conosce meno. E' lo stesso principio dell'albero: chiedere quello che informa
   di piu'. */
const OR_IDQ = {
  tipo: { t: 'Il tuo sogno è diventare qualcuno, o raggiungere qualcosa?', o: [
    { l: 'Diventare una persona diversa', k: 'diventare', e: '🦋' }, { l: 'Raggiungere un risultato preciso', k: 'raggiungere', e: '🎯' } ] },
  /* 0.9.309: domanda + risposta si leggono come una frase ("Cosa ti ferma piu' spesso? Le distrazioni") */
  dominio: { t: 'Di cosa parla il tuo sogno?', o: [
    /* 0.9.378, Andrea: "o metti 6 opzioni o ne metti 4, mai 5 con la quinta su due colonne: Lo scrivo io resta fuori" */
    { l: 'Di un business mio', k: 'business', e: '💼' }, { l: 'Di creatività', k: 'creativita', e: '🎨' }, { l: 'Di forma fisica', k: 'fitness', e: '💪' }, { l: 'Delle persone che amo', k: 'relazioni', e: '❤️' },
    { l: 'Di studio', k: 'studio', e: '📚' }, { l: 'Di carriera', k: 'carriera', e: '📈' } ] },
  valore: { t: 'Realizzare il tuo sogno, prima di tutto, cosa ti darebbe?', o: [
    { l: 'La libertà', k: 'liberta', e: '🕊️' }, { l: 'Il riconoscimento', k: 'riconoscimento', e: '🏆' }, { l: 'Più tempo per la famiglia', k: 'famiglia', e: '👨‍👩‍👧' },
    { l: 'L’indipendenza', k: 'indipendenza', e: '🗝️' } ] },
  ostacolo: { t: 'Cosa ti ferma più spesso?', o: [
    { l: 'Le distrazioni', k: 'dispersione', e: '🌀' }, { l: 'La voglia di rimandare', k: 'procrastinazione', e: '⏳' }, { l: 'La stanchezza', k: 'stanchezza', e: '😴' },
    { l: 'Il bisogno che sia tutto perfetto', k: 'perfezionismo', e: '🔍' } ] }
};

/* ---------- i te del futuro ----------
   `pct` è quanto spesso quel tipo di persona arriva dove voleva. Non è scienza: è la stima
   onesta di chi ha visto molte persone provarci, e serve a dare un numero che si muove. */
const OR_PROFILES = [
  { id: 'proc', ico: '🛋️', pct: 15, name: 'Il Procrastinatore Seriale',
    desc: 'Sa esattamente cosa dovrebbe fare, e lo farà domani. Il telefono è il posto dove domani non arriva mai.' },
  { id: 'inc',  ico: '🧩', pct: 25, name: 'L\'Inconcludente',
    desc: 'Parte forte. Le prime due settimane sono sempre bellissime. Poi arriva una giornata storta, e il progetto resta lì, a metà, con gli altri.' },
  { id: 'sogn', ico: '☁️', pct: 30, name: 'Il Sognatore',
    desc: 'Obiettivi enormi e nessun sistema. Ha una visione chiarissima di dove vuole arrivare e nessuna idea di cosa farà domani alle sette.' },
  { id: 'reat', ico: '🔔', pct: 20, name: 'Il Reattivo',
    desc: 'La sua giornata la decidono gli altri: una notifica, un messaggio, un video. Non ha mai un\'ora che sia davvero sua.' },
  { id: 'nott', ico: '🌙', pct: 25, name: 'Il Nottambulo',
    desc: 'Le sue giornate cominciano a mezzogiorno perché finiscono alle tre. Lo schermo a letto gli ruba il sonno, e il sonno gli ruba il giorno dopo.' },
  { id: 'equi', ico: '⚖️', pct: 50, name: 'L\'Equilibrista',
    desc: 'Ci prova davvero. Oscilla: settimane buone e settimane no. Non cade mai, ma non sale.' },
  { id: 'disc', ico: '🧱', pct: 70, name: 'Il Disciplinato in costruzione',
    desc: 'Ha le regole e le tiene quasi sempre. Gli manca solo la costanza nei giorni storti, che sono quelli che contano.' },
  { id: 'real', ico: '🏔️', pct: 88, name: 'Il Realizzatore',
    desc: 'Decide, blocca, fa. Non è più forte degli altri: ha solo tolto di mezzo le cose che gli rubavano il tempo.' }
];

/* ---------- le domande ----------
   `e` = probabilità che quel profilo risponda "sì". `data` = come il telefono può rispondere
   al posto dell'utente: torna {a, say} o null. */
const OR_Q = [
  { id: 'q1',  t: 'Il telefono è la prima cosa che prendi appena sveglio?',
    e: { proc: .9, inc: .7, sogn: .7, reat: .95, nott: .9, equi: .5, disc: .3, real: .1 } },
  { id: 'q2',  t: 'Ti capita di aprire un\'app senza un motivo, solo per abitudine?',
    e: { proc: .9, inc: .7, sogn: .8, reat: .95, nott: .8, equi: .6, disc: .35, real: .1 } },
  { id: 'q3',  t: 'Sai già cosa farai domani mattina appena sveglio?',
    e: { proc: .1, inc: .4, sogn: .3, reat: .2, nott: .2, equi: .5, disc: .85, real: .95 } },
  { id: 'q4',  t: 'Rimandi le cose importanti a quando «avrai più tempo»?',
    e: { proc: .95, inc: .7, sogn: .8, reat: .6, nott: .6, equi: .5, disc: .3, real: .1 } },
  { id: 'q5',  t: 'Quando ti dai una regola, la tieni anche la sera che sei stanco?',
    e: { proc: .1, inc: .2, sogn: .2, reat: .3, nott: .3, equi: .5, disc: .7, real: .95 } },
  { id: 'q6',  t: 'Vai a dormire dopo l\'una più di due volte a settimana?',
    e: { proc: .6, inc: .5, sogn: .5, reat: .6, nott: .95, equi: .4, disc: .3, real: .15 } },
  { id: 'q7',  t: 'Negli ultimi sei mesi hai lasciato a metà qualcosa che avevi cominciato?',
    e: { proc: .8, inc: .95, sogn: .85, reat: .6, nott: .6, equi: .6, disc: .4, real: .15 } },
  { id: 'q8',  t: 'Riesci a stare un\'ora intera senza guardare il telefono?',
    e: { proc: .2, inc: .4, sogn: .4, reat: .05, nott: .3, equi: .5, disc: .8, real: .95 } },
  { id: 'q9',  t: 'Quando arriva una notifica, lasci quello che stai facendo per guardarla?',
    e: { proc: .7, inc: .6, sogn: .5, reat: .95, nott: .6, equi: .5, disc: .25, real: .1 } },
  /* 0.9.378, Andrea: "Hai un obiettivo scritto da qualche parte e' una domanda del cazzo: il sogno l'ha gia' scritto nell'app". Tolta:
     il Genio non chiede quello che sa gia' */
  { id: 'q11', t: 'Fai sport o movimento almeno tre volte a settimana?',
    e: { proc: .1, inc: .3, sogn: .3, reat: .3, nott: .2, equi: .5, disc: .7, real: .85 } },
  { id: 'q12', t: 'A letto, ti capita di scorrere per più di mezz\'ora?',
    e: { proc: .85, inc: .6, sogn: .6, reat: .8, nott: .95, equi: .5, disc: .3, real: .1 } },
  /* 0.9.378, Andrea: "ricominci da capo cosa vuol dire? tutti ricominciano. Ricadi nello stesso giro il giorno dopo, allora ha senso".
     La frase e' girata: il si' adesso e' il giro che si ripete, e le attese sono capovolte */
  { id: 'q13', t: 'Dopo una giornata andata male, il giorno dopo ricadi nelle stesse abitudini?',
    e: { proc: .8, inc: .7, sogn: .5, reat: .6, nott: .6, equi: .3, disc: .2, real: .05 } },
  { id: 'q14', t: 'Passi più di tre ore al giorno sul telefono?',
    e: { proc: .9, inc: .7, sogn: .6, reat: .9, nott: .8, equi: .5, disc: .35, real: .15 } },
  /* LA DOMANDA CHE NESSUN NUMERO PUO' RISPONDERE.
     Tutte le altre si possono dedurre dal telefono. Questa no: due giornate identiche nei
     minuti possono essere una vittoria e una tortura, e la differenza non e' misurabile
     dall'esterno. Il controllo di fine giornata la risponde al posto di chi lo compila. */
  { id: 'q15', t: 'La sera, di solito, sei contento di come hai usato la giornata?',
    e: { proc: .2, inc: .35, sogn: .3, reat: .25, nott: .3, equi: .7, disc: .75, real: .9 } },
  /* 0.9.376, Andrea: "le domande dicono poco e sono sempre le stesse: devono mappare come si vede, in cosa crede, cosa lo limita, come le
     domande del sabotatore invisibile". Le domande sull'immagine di se': ognuna dice anche quale freno rivela un si' (fr; con il meno
     davanti lo rivela un no) */
  { id: 'q16', t: 'Pensi che chi ce l\'ha fatta abbia qualcosa che a te manca?', fr: 'valore',
    e: { proc: .8, inc: .7, sogn: .6, reat: .6, nott: .6, equi: .5, disc: .3, real: .1 } },
  { id: 'q17', t: 'Ti frena il pensiero di cosa diranno gli altri se non ce la fai?', fr: 'sguardi',
    e: { proc: .7, inc: .6, sogn: .6, reat: .6, nott: .5, equi: .5, disc: .35, real: .15 } },
  { id: 'q18', t: 'Quando si tratta di investire soldi su di te o sul tuo progetto, rimandi?', fr: 'denaro',
    e: { proc: .8, inc: .6, sogn: .7, reat: .5, nott: .5, equi: .5, disc: .3, real: .1 } },
  { id: 'q19', t: 'Riesci a concentrarti per due ore di fila su una cosa sola?', fr: '-dispersione',
    e: { proc: .1, inc: .3, sogn: .3, reat: .05, nott: .3, equi: .5, disc: .8, real: .95 } },
  { id: 'q20', t: 'Credi davvero che il tuo sogno sia possibile per te?', fr: '-valore',
    e: { proc: .4, inc: .5, sogn: .7, reat: .4, nott: .4, equi: .6, disc: .8, real: .95 } },
  { id: 'q21', t: 'Prima di cominciare una cosa nuova senti di dover sapere tutto?', fr: 'imparare',
    e: { proc: .7, inc: .6, sogn: .8, reat: .4, nott: .5, equi: .5, disc: .35, real: .15 } },
  { id: 'q22', t: 'Un fallimento del passato ti torna in mente quando provi qualcosa di nuovo?', fr: 'passato',
    e: { proc: .7, inc: .8, sogn: .5, reat: .5, nott: .6, equi: .5, disc: .35, real: .15 } },
  { id: 'q23', t: 'Ti senti in ritardo rispetto agli altri della tua età?', fr: 'tempo',
    e: { proc: .8, inc: .7, sogn: .6, reat: .6, nott: .7, equi: .5, disc: .3, real: .15 } },
  { id: 'q24', t: 'Quando una cosa si fa difficile, cerchi una distrazione?', fr: 'dispersione',
    e: { proc: .95, inc: .8, sogn: .7, reat: .9, nott: .8, equi: .5, disc: .3, real: .1 } },
  { id: 'q25', t: 'Le persone con cui passi più tempo ti spingono verso il tuo sogno?', fr: '',
    e: { proc: .2, inc: .3, sogn: .3, reat: .3, nott: .3, equi: .5, disc: .7, real: .9 } },
  { id: 'q26', t: 'Hai più paura di non farcela che di non provarci?', fr: 'paura',
    e: { proc: .8, inc: .7, sogn: .7, reat: .5, nott: .5, equi: .5, disc: .3, real: .1 } },
  { id: 'q27', t: 'Ti capita di cominciare molte cose insieme e di non finirne nessuna?', fr: 'dispersione',
    e: { proc: .7, inc: .95, sogn: .8, reat: .6, nott: .6, equi: .5, disc: .3, real: .1 } },
  { id: 'q28', t: 'Dedichi al tuo sogno almeno un\'ora al giorno, quasi tutti i giorni?', fr: '',
    e: { proc: .05, inc: .3, sogn: .2, reat: .2, nott: .2, equi: .5, disc: .8, real: .95 } },
  { id: 'q29', t: 'Ti guardi allo specchio e vedi già la persona che vuoi diventare?', fr: '-valore',
    e: { proc: .1, inc: .2, sogn: .4, reat: .2, nott: .2, equi: .4, disc: .7, real: .9 } },
  { id: 'q30', t: 'Sotto la pressione di una scadenza ti blocchi invece di accelerare?', fr: 'tempo',
    e: { proc: .8, inc: .6, sogn: .6, reat: .6, nott: .6, equi: .5, disc: .3, real: .1 } },
];
/* IL TRIGGER. Era la terza domanda del primissimo onboarding — «In quale momento prendi il
   telefono senza pensarci?» — ed e' sparita quando il primo avvio e' diventato il film del
   Genio. Torna qui, nella lettura che si apre dalla Roadmap, perche' e' la domanda che rende
   il piano SUO: sapere che lo prende a letto o quando si annoia cambia la prima mossa da
   proporre, e nessun numero del telefono la sa rispondere. Piu' di una risposta: i trigger
   non si escludono. */
const OR_TRIGGER = [
  { id: 'letto',  ico: '🛌', t: 'Prima di dormire o appena sveglio' },
  { id: 'noia',   ico: '🥱', t: 'Quando mi annoio o ho un momento morto' },
  { id: 'stress', ico: '😰', t: 'Quando sono stressato o ansioso' },
  { id: 'lavoro', ico: '📚', t: 'Mentre studio o lavoro' }
];
/* 0.9.309, Andrea: "Vado a letto, prima di dormire o appena sveglio" non ha senso. Era l'agente (Premium) che
   riscriveva le risposte "in prima persona" e ci metteva davanti un verbo. Ogni risposta deve completare
   "Prendo il telefono senza pensarci...": comincia da quando succede. Quella che non lo fa resta la nostra. */
const OR_TRIG_MOMENTO = /^(quando|mentre|prima|appena|dopo|durante|ogni |in |nei |nel |nelle |nella |la sera|la mattina|di sera|di notte|di mattina|tutte le volte)/i;
const OR_ANS = [
  { v: 1,    l: 'Sì' }, { v: .75, l: 'Probabilmente' }, { v: .5, l: 'Non lo so' },
  { v: .25,  l: 'Probabilmente no' }, { v: 0, l: 'No' }
];

/* ---------- il motore ---------- */
const OR_SIGMA = 0.33;
function orLik(a, e){ const d = a - e; return Math.exp(-(d * d) / (2 * OR_SIGMA * OR_SIGMA)) + 0.03; }
function orNorm(v){ const s = v.reduce((x, y) => x + y, 0) || 1; return v.map(x => x / s); }
function orEntropy(p){ return -p.reduce((s, x) => s + (x > 0 ? x * Math.log(x) : 0), 0); }
function orUpdate(post, q, a){
  if (a === .5) return post;                       // "non lo so" non dice niente
  /* L'attesa passa da pvE, non dalla tabella scritta nell'app: e' li' dentro che vivono le
     correzioni di «chi stavi pensando». Se leggessimo ancora q.e, la correzione verrebbe
     salvata e poi ignorata — cioe' il motore direbbe di imparare senza imparare. */
  const att = (i) => {
    const id = OR_PROFILES[i].id;
    if (typeof pvE === 'function'){
      const v = pvE(q.id, id);
      if (v !== null && v !== undefined) return v;
    }
    return q.e[id];
  };
  return orNorm(post.map((p, i) => p * orLik(a, att(i))));
}
/* La domanda che separa di più i profili ancora in gioco: minima entropia attesa dopo la
   risposta, pesata su quanto è probabile ogni risposta. È il cuore del gioco del genio. */
function orNext(post, asked){
  let best = null, bestGain = -1;
  const h0 = orEntropy(post);
  const A = [1, .75, .25, 0];
  OR_Q.forEach(q => {
    if (asked.indexOf(q.id) >= 0) return;
    // P(risposta) = somma sui profili di P(profilo) x P(risposta | profilo). La verosimiglianza
    // del kernel va normalizzata sulle quattro risposte, profilo per profilo: senza, i pesi
    // sommavano a piu' di uno e il guadagno usciva negativo, cioe' nessuna domanda "conveniva".
    const pa = A.map(() => 0);
    post.forEach((p, i) => {
      const e = q.e[OR_PROFILES[i].id];
      const l = A.map(a => orLik(a, e));
      const z = l.reduce((x, y) => x + y, 0) || 1;
      l.forEach((v, k) => { pa[k] += p * v / z; });
    });
    let exp = 0;
    A.forEach((a, k) => { exp += pa[k] * orEntropy(orUpdate(post, q, a)); });
    /* un po' di caso: due letture non fanno mai le stesse domande nello stesso ordine, come nel gioco del Genio */
    const gain = (h0 - exp) * (0.75 + Math.random() * 0.5);
    if (gain > bestGain){ bestGain = gain; best = q; }
  });
  return best;
}
function orTop(post){ let i = 0; post.forEach((p, k) => { if (p > post[i]) i = k; }); return { i: i, p: post[i] }; }

/* ---------- quello che il telefono sa già ---------- */
/* UN DATO SOLO, E OGGETTIVO. Prima qui c'era un muro di cinque righe (le ore senza telefono,
   che magari erano di sonno; la serie severa; le aperture di Samsung Notes): dati veri che
   non c'entrano niente con la domanda che sta per arrivare. Resta la media delle ore sullo
   schermo, in grande: un fatto che l'utente riconosce come vero, e a cui dice si' dentro di se'.
   E' il si' che rende credibile quello che viene dopo. */
async function orEvidence(){
  const out = [];
  try{
    const avg = await scAverages(0);
    if (avg && avg.days >= 1 && avg.screenMs > 0){
      const h = avg.screenMs / 3600000;
      out.push({ q: 'q14', a: h >= 3 ? 1 : (h <= 2 ? 0 : .5), big: scFmtShort(avg.screenMs), say: 'al giorno sullo schermo, in media' + (avg.days >= 7 ? ', negli ultimi sette giorni' : '') + '.' });
    }
  }catch(_){ }
  if (out.length) return out;
  try{
    const r = await scReport(1);
    if (r && r.granted){
      const gap = r.awakeGapMs || r.longestGapMs || 0;
      if (gap >= 3600000) out.push({ q: 'q8', a: 1, say: 'Ieri sei stato <strong>' + scFmtShort(gap) + '</strong> di fila senza toccare il telefono.' });
      else if (gap >= 60000 && gap < 1800000) out.push({ q: 'q8', a: 0, say: 'Ieri non sei mai stato più di <strong>' + scFmtShort(gap) + '</strong> senza toccare il telefono.' });
      if (r.lastUse){
        const hh = new Date(r.lastUse).getHours();
        if (hh >= 1 && hh < 5) out.push({ q: 'q6', a: .75, say: 'Ieri l\'ultimo sblocco è stato alle <strong>' + new Date(r.lastUse).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) + '</strong>.' });
      }
    }
  }catch(_){ }
  try{
    if (NATIVE && NATIVE.getNotifications){
      const d = new Date(); d.setHours(0, 0, 0, 0);
      const n = await NATIVE.getNotifications({ dayStart: d.getTime() - 86400000, limit: 1 });
      const tot = (n && n.total) || 0;
      if (tot >= 80) out.push({ q: 'q9', a: .75, say: 'Ieri hai ricevuto <strong>' + tot + ' notifiche</strong>.' });
      else if (tot > 0 && tot <= 25) out.push({ q: 'q9', a: .25, say: 'Ieri hai ricevuto solo <strong>' + tot + ' notifiche</strong>.' });
    }
  }catch(_){ }
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    let streak = 0;
    if (st && st.start && typeof blkDaysBetween === 'function') streak = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
    const since = Date.now() - 30 * 86400000;
    const breaks = (JSON.parse(localStorage.getItem('fl_breaks') || '[]') || []).filter(t => t >= since).length;
    if (streak >= 3) out.push({ q: 'q5', a: .75, say: 'La Modalità severa è attiva da <strong>' + streak + ' giorni</strong> di fila.' });
    else if (breaks >= 2) out.push({ q: 'q5', a: .25, say: 'Hai messo in pausa il piano <strong>' + breaks + ' volte</strong> nell\'ultimo mese.' });
  }catch(_){ }
  /* LA CRONOLOGIA, CHE E' L'UNICA PROVA CHE NON E' UNA MEDIA.
     Tutto quello che l'oracolo sapeva fin qui erano medie: «passi tre ore al giorno sullo
     schermo». E' un rimprovero, e a un rimprovero si risponde alzando le spalle. «Ieri hai
     aperto Instagram 41 volte e 28 di quelle sei uscito entro mezzo minuto» non e' un
     rimprovero: e' una diagnosi, e a una diagnosi si risponde chiedendo la cura.

     Si legge IERI, non oggi: a meta' mattina la giornata di oggi non ha ancora una forma, e
     una forma letta troppo presto dice il contrario di quello che dira' alla fine. */
  try{
    if (typeof tlRiassuntoDi === 'function'){
      const tl = await tlRiassuntoDi(1);
      if (tl && tl.riprese){
        /* IL LAUNCHER NON E' UN'APP. «Hai aperto One UI Home 101 volte» e' vero e non dice
           niente: la schermata iniziale la si attraversa, non la si usa. Fuori il launcher, la
           tastiera, il sistema e tutto quello che il Report gia' esclude (insExcl). */
        const orEsclusa = function(a){
          const pk = String(a.p || '').toLowerCase(), lb = String(a.l || '').trim();
          try{ if (typeof insExcl === 'function' && insExcl().indexOf(pk) >= 0) return true; }catch(_){ }
          return /launcher|\.home$|systemui|inputmethod|keyboard|honeyboard|packageinstaller|permissioncontroller/i.test(pk)
            || /launcher|\bhome$|one ui/i.test(lb);
        };
        const ab = (tl.perApp || []).filter(function(a){ return a.lampi >= 8 && !orEsclusa(a); })
          .sort(function(a, b){ return b.lampi - a.lampi; })[0];
        if (ab){
          out.push({ q: 'q2', a: 1, say: 'Ieri hai aperto <strong>' + esc(ab.l || ab.p) + '</strong> '
            + ab.n + ' volte, e ' + ab.lampi + ' di quelle sei uscito entro mezzo minuto.' });
        }
        if (tl.notte >= 30 * 60000){
          out.push({ q: 'q12', a: 1, say: 'Ieri, fra mezzanotte e le cinque, hai passato <strong>'
            + tlDur(tl.notte) + '</strong> sullo schermo.' });
        } else if (tl.notte === 0 && tl.tot > 0){
          out.push({ q: 'q12', a: 0, say: 'Ieri notte non hai toccato il telefono nemmeno una volta.' });
        }
      }
    }
  }catch(_){ }
  /* IL COMPUTER — il buco piu' grande che avesse questa funzione.
     Tutto quello che il Genio sapeva veniva dal telefono, cioe' dalle PAUSE di una persona che
     lavora davanti a uno schermo grande. Una previsione costruita li' sopra e' precisa su una
     fetta piccola e muta sulla fetta grande, e presa da sola puo' dire il contrario del vero:
     quaranta aperture di Instagram dentro a nove ore di lavoro e le stesse quaranta dentro a
     una giornata vuota sono due persone diverse. */
  try{
    if (typeof pcFrasi === 'function'){
      if (typeof pcSync === 'function') await pcSync(false);
      const dette = pcFrasi();
      const r = (typeof pcRiassunto === 'function') ? pcRiassunto() : null;
      if (r && dette.length){
        /* La quota di lavoro vero al computer risponde alla stessa domanda di q14 (quanto
           schermo) ma dal lato giusto: non «quanto», ma «quanto di quello contava». */
        if (r.quotaDistr >= 0.35) out.push({ q: 'q14', a: .85, say: dette[Math.min(1, dette.length - 1)] });
        else if (r.media7 && r.media7.prod >= 120) out.push({ q: 'q8', a: .8, say: dette[0] });
        else out.push({ q: 'q2', a: .6, say: dette[0] });
      }
    }
  }catch(_){ }
  try{
    const w = JSON.parse(localStorage.getItem('fl_why') || 'null');
    const written = w && Array.isArray(w.sections) && w.sections.some(s => (s.items || []).some(it => it.text && it.text.trim()));
    if (written) out.push({ q: 'q10', a: .75, say: 'Hai scritto il tuo perché.' });
  }catch(_){ }
  /* COM'E' ANDATA, secondo te.
     Dal controllo di fine giornata arrivano due medie e basta: niente note, che sono private e
     per scegliere una domanda non servirebbero comunque. Serve almeno mezza settimana di
     giornate chiuse: sotto, sono aneddoti, e un aneddoto travestito da media e' peggio di un
     dato mancante. */
  try{
    const u = (typeof umPerGenio === 'function') ? umPerGenio() : null;
    if (u && u.giorni >= 4 && u.fatto && u.sentito){
      if (u.divario >= 1) out.push({ q: 'q15', a: .12,
        say: 'Nelle giornate in cui fai di più, <strong>stai peggio</strong>: è un prezzo che i minuti non mostrano.' });
      else if (u.divario <= -1) out.push({ q: 'q15', a: .6,
        say: 'Stai bene anche nei giorni in cui fai poco. Non è un difetto: è un\'informazione.' });
      else if (u.sentito >= 3.6) out.push({ q: 'q15', a: .88,
        say: 'Chiudendo le giornate ti sei dato <strong>' + u.sentito.toFixed(1) + ' su 5</strong> di media.' });
      else if (u.sentito <= 2.4) out.push({ q: 'q15', a: .15,
        say: 'Le ultime giornate te le sei date <strong>' + u.sentito.toFixed(1) + ' su 5</strong>.' });
    }
  }catch(_){ }
  /* Cinque e non quattro: le due righe nuove sono le piu' precise che l'oracolo abbia mai
     avuto, e farle scavalcare da una media sarebbe un peggioramento travestito da limite. */
  return out.slice(0, 5);
}

/* ---------- la sessione ---------- */
function orLast(){ try{ return JSON.parse(localStorage.getItem(OR_KEY) || 'null'); }catch(_){ return null; } }
function orProfile(id){ return OR_PROFILES.filter(p => p.id === id)[0] || OR_PROFILES[5]; }
function orTargetName(id){ const t = OR_TARGETS.filter(x => x.id === id)[0]; return t ? t.name.replace(/^Chi /, 'chi ') : 'chi vuoi diventare'; }

async function orOpen(){
  /* 0.9.373, Andrea: "nella lettura del Genio non c'e' nessuna musica, come negli episodi o nell'intro": la sigla dell'intro (speranza) */
  try{ if (typeof muSigla === 'function') muSigla('intro'); }catch(_){ }
  orFraseScegli(); OR.sbagli = 0; OR.datiStat = false;
  OR.on = true; OR.ultima = null; OR.post = orNorm(OR_PROFILES.map(() => 1)); OR.asked = []; OR.answers = {}; OR.n = 0; OR.result = null; OR.hist = []; OR.idFatta = false; OR.idq = null;
  OR.known = []; OR.knownFatti = false; OR.analisi = null; OR.sognoMio = ''; OR.triggerTesto = ''; OR.trigScrivi = false;
  OR.idScrivi = false; OR.idTesto = ''; OR.idqPrec = null; OR.tgScrivi = false; OR.personaMia = ''; OR.corScrivi = false; OR.corTesto = ''; OR.planDa = '';
  OR.prob = null; OR.trigFatto = false; OR.idChiesta = false; OR.mantraK = null; OR.mantraScrivi = false; OR.mantraMio = ''; OR.ambFatta = false; OR.ambI = 0;
  const last = orLast();
  OR.trigger = ((last && last.trigger) || []).slice();
  OR.sogno = orSognoScelto();
  let tg = ''; try{ tg = (typeof gnDati === 'function' && gnDati().target) || ''; }catch(_){ }
  OR.target = tg || orTargetDaSogno(OR.sogno) || (last && last.target) || '';
  const el = document.getElementById('orWrap');
  if (el){ el.hidden = false; }
  document.body.classList.add('or-on');
  /* il sogno c'e' quasi sempre (l'ha scelto nel primo avvio): si conferma. Senza sogno resta la scelta del campo. */
  OR.step = OR.sogno ? 'sogno' : 'target';
  orPaint();
  /* PREMIUM: la chiamata all'agente parte adesso, mentre l'utente legge la prima schermata */
  orAgentePrepara();
  /* 0.9.306: i dati per la persona del sogno si leggono adesso, mentre l'utente conferma il sogno */
  OR.dati = null; OR.personaDati = null;
  OR.datiP = orDatiPersona().then(function(d){ OR.dati = d; }).catch(function(){ OR.dati = { app: '', ora: -1 }; });
  OR.knownP = orEvidence().catch(function(){ return []; });
  OR.known = await OR.knownP;
}
/* ---------- 1 · il sogno confermato ---------- */
function orSognoSi(){ try{ flVibra(12); }catch(_){ } orVaiAlexander(); }
/** «Cambia il mio sogno»: il sogno si cambia da Ricomincia da capo, lo stesso posto dove porta «Scegli il prossimo sogno». */
function orSognoCambia(){
  orClose();
  setTimeout(function(){ if (typeof rcApri === 'function') rcApri(); else if (typeof rivediOnboarding === 'function') rivediOnboarding(); }, 320);
}
function orSognoScrivi(){
  OR.step = 'sognoScrivi'; orPaint();
  setTimeout(function(){ try{ const a = document.getElementById('orSognoArea'); if (a) a.focus(); }catch(_){ } }, 250);
}
function orSognoScrittoInput(v){
  const b = document.getElementById('orSognoOk'); if (b) b.disabled = !String(v || '').trim();
}
function orSognoScrittoOk(){
  const a = document.getElementById('orSognoArea'); const v = a ? a.value.trim() : '';
  if (!v) return;
  /* le parole sue valgono per questa lettura: il percorso non cambia senza il suo si' (Ricomincia da capo) */
  OR.sognoMio = v;
  OR.target = orTargetDaSogno(v) || OR.target;
  orAgentePrepara();
  orVaiAlexander();
}
/* ---------- 2 · la frase di F.M. Alexander, legata al sogno ---------- */
async function orVaiAlexander(){
  const attese = [];
  if (OR.aiP && !OR.ai) attese.push(OR.aiP);
  if (OR.datiP && !OR.dati) attese.push(OR.datiP);
  if (attese.length){
    /* l'agente o i dati del telefono stanno finendo: due secondi al massimo, poi si va con quello che c'e' */
    OR.step = 'attesa'; orPaint();
    await Promise.race([Promise.all(attese), new Promise(function(r){ setTimeout(r, 2200); })]);
    if (!OR.on || OR.step !== 'attesa') return;
  }
  OR.personaDati = orPersonaDaiDati();
  OR.twFatto = ''; OR.alxI = 0; OR.alxMax = -1;
  OR.step = 'alexander'; orPaint();
}
/* LE DUE VIGNETTE DEL GENIO (0.9.306). Andrea: la frase di Alexander e la persona del sogno non stanno insieme. Prima la
   frase, battuta a macchina; un tocco, e la seconda vignetta con la persona. E' la macchina da scrivere della scena del
   Genio (gnScrivi in genio-intro.js): stessa velocita' (CIT_MS), stesso ticchettio, la parte fra *asterischi* che si
   accende (gnParti), un tocco che completa la frase e la freccetta che va su e giu' quando si puo' andare avanti. */
const OR_TW = { timer: 0, completa: null };
function orTwFerma(){ clearTimeout(OR_TW.timer); OR_TW.timer = 0; OR_TW.completa = null; }
function orTwParti(testo, fino){
  if (typeof gnParti === 'function') return gnParti(testo, fino);
  const t = String(testo).replace(/\*/g, '');
  return { html: esc(fino === undefined ? t : t.slice(0, fino)), n: t.length };
}
function orScrivi(el, testo, dopo){
  orTwFerma();
  if (!el) return;
  const parti = orTwParti(testo);
  let i = 0;
  const base = (typeof CIT_MS === 'number') ? CIT_MS : 55;
  let fs = 19.5; try{ fs = parseFloat(getComputedStyle(el).fontSize) || 19.5; }catch(_){ }
  const passo = Math.max(24, Math.round(base * Math.min(1, fs / 19.5)));
  /* la frase intera c'e' gia', invisibile, sotto alle lettere battute: la vignetta ha subito la sua altezza e il
     testo non sale di mezza riga a ogni riga nuova */
  el.innerHTML = '<span class="or-tw-v"></span><span class="or-tw-o" aria-hidden="true">' + parti.html + '</span>';
  const v = el.firstChild;
  const fine = function(){ orTwFerma(); el.innerHTML = '<span class="or-tw-v">' + parti.html + '</span>'; if (dopo) dopo(); };
  const batti = function(){
    if (!document.body.contains(el)){ orTwFerma(); return; }
    i++;
    try{ if (i % 2 === 0 && typeof gnAu !== 'undefined') gnAu.tick(); }catch(_){ }
    v.innerHTML = orTwParti(testo, i).html;
    if (i >= parti.n){ fine(); return; }
    OR_TW.timer = setTimeout(batti, passo);
  };
  OR_TW.completa = fine;
  OR_TW.timer = setTimeout(batti, 280);
}
/** il testo della seconda vignetta: la persona fra asterischi, cosi' si accende in rosso */
function orTestoLega(){
  const sg = orSognoAttuale();
  /* 0.9.379, Andrea: "il sogno fra virgolette deve essere blu, come nella prima schermata" */
  const perSogno = (sg && sg.length <= 48) ? 'Per realizzare il sogno *"' + sg.replace(/\*/g, '') + '"*, devi' : 'Per realizzare il tuo sogno devi';
  return perSogno + ' cambiare le tue abitudini e diventare *' + String(orPersona()).replace(/\*/g, '') + '*.';
}
/** la vignetta ha finito di scriversi: la freccetta, e (sulla seconda) il pulsante */
function orVignPronta(){
  OR.twFatto = orTwChiave();
  if (OR.step === 'alexander') OR.alxMax = Math.max(OR.alxMax == null ? -1 : OR.alxMax, OR.alxI || 0);
  const w = document.getElementById('orWrap'); if (!w) return;
  const v = w.querySelector('.or-vign'); if (v) v.classList.add('pronta');
}
/** un tocco sulla vignetta: completa la frase, oppure va avanti */
function orVignTocco(){
  if (OR_TW.completa){ OR_TW.completa(); return; }
  try{ flVibra(10); }catch(_){ }
  if (OR.step === 'alexander' && (OR.alxI || 0) < OR_ALEX_INTRO.length){
    OR.alxI = (OR.alxI || 0) + 1;
    /* una battuta gia' letta (si era tornati indietro) non si batte una seconda volta */
    if (OR.alxI <= (OR.alxMax == null ? -1 : OR.alxMax)) OR.twFatto = orTwChiave();
    orPaint(); return;
  }
  if (OR.step === 'alexander'){ OR.step = 'alexander2'; orPaint(); return; }
  if (OR.step === 'alexander2') orAnalisi();
}
/* ---------- 3 · l'analisi dei dati, poi la lettura a freddo ---------- */
const OR_ANA_RIGHE = { q14: 'Il tempo che passi sullo schermo', q8: 'Le ore che passi senza telefono', q6: 'L’ora dell’ultimo sblocco della sera',
  q9: 'Le notifiche che ricevi', q5: 'Le tue giornate in modalità severa', q2: 'Le app che apri senza pensarci', q12: 'Il telefono di notte',
  q10: 'Il perché che hai scritto', q15: 'Come ti senti a fine giornata' };
function orVoti(){
  try{ const s = (typeof mtState === 'function') ? mtState() : null; if (s) return { neo: +s.neo || 0, old: +s.old || 0 }; }catch(_){ }
  return { neo: 0, old: 0 };
}
function orAnaFonti(){
  const r = [], v = orVoti();
  /* 0.9.381, Andrea: "l'emoji accanto alla spunta no: dopo il testo. Prima la giornata, la partita per ultima, e La tua partita non si
     capisce che e' vecchio te contro nuovo te" */
  r.push('Le tue giornate 🗓️');
  try{ const L = (typeof DP !== 'undefined' && DP && DP.L != null) ? DP.L : null; r.push(L != null ? 'Il carburante: ' + Number(L).toFixed(1).replace('.', ',') + ' ⛽' : 'Il carburante di oggi ⛽'); }catch(_){ r.push('Il carburante di oggi ⛽'); }
  r.push(v.neo + v.old > 0 ? 'Vecchio te contro nuovo te: ' + v.old + ' a ' + v.neo + ' ⚽' : 'La partita fra vecchio te e nuovo te ⚽');
  try{ const a = (typeof etaArrivo === 'function') ? etaArrivo() : null; if (a && isFinite(a.at)) r.push('La data in cui arrivi al sogno'); }catch(_){ }
  try{ const d7 = Date.now() - 7 * 86400000, n = (typeof ffHist === 'function' ? ffHist() : []).filter(function(x){ return x.ok && x.at >= d7; }).length; r.push('Il Full Focus: ' + n + (n === 1 ? ' sessione in 7 giorni' : ' sessioni in 7 giorni')); }catch(_){ }
  return r;
}
async function orAnalisi(){
  OR.step = 'analisi'; OR.analisi = null; orPaint();
  let k = []; try{ k = await OR.knownP; }catch(_){ k = []; }
  OR.known = k || [];
  /* il primo fatto che il Genio dice di sapere: i voti, se ci sono */
  const vt = orVoti();
  if (vt.neo + vt.old >= 2 && !OR.known.some(function(x){ return x.q === 'partita'; })){
    OR.known.unshift({ q: 'partita', big: vt.old + ' a ' + vt.neo, say: vt.neo >= vt.old ? 'È la tua partita: ' + vt.neo + (vt.neo === 1 ? ' voto' : ' voti') + ' per chi vuoi diventare, ' + vt.old + ' per chi eri.' : 'È la tua partita: il vecchio te ha ' + vt.old + ' voti, chi vuoi diventare ne ha ' + vt.neo + '.' });
  }
  if (!OR.on || OR.step !== 'analisi') return;
  /* 0.9.317, Andrea: "dice solo il tempo sullo schermo: deve leggere la partita fra vecchio e nuovo te, il carburante, la timeline...".
     Quello che legge davvero, con il suo numero quando c'e', e la partita per prima: i voti sono il dato che conta di piu'. */
  const righe = orAnaFonti();
  OR.known.forEach(function(x){ const t = OR_ANA_RIGHE[x.q]; if (t && righe.indexOf(t) < 0) righe.push(t); });
  /* 0.9.376, Andrea: "sei righe sono troppe, nessuno le legge: tre o quattro, verdi, sullo sfondo e non nel pannello bianco" */
  /* 0.9.379, Andrea: "quattro spunte sono troppe, meglio tre; e la prima deve essere la piu' corta, quella che si legge al volo" */
  OR.analisi = righe.slice(0, 3); orPaint();
  try{ const b = document.querySelector('#orWrap .or-genio'); if (b) b.classList.add('luce'); if (typeof gnAu !== 'undefined' && gnAu.crescendo) gnAu.crescendo(450 + 650 * OR.analisi.length + 650, function(){ }); }catch(_){ }
  const passo = 650;
  OR.analisi.forEach(function(_, i){
    setTimeout(function(){
      if (OR.step !== 'analisi') return;
      const li = document.querySelectorAll('#orWrap .or-ana li')[i];
      /* 0.9.377, Andrea: "quando sta leggendo le tue abitudini non c'e' la luce sul Genio, la vibrazione e il suono come nell'intro" */
      if (li){ li.classList.add('on'); try{ if (typeof gnAu !== 'undefined') gnAu.tick(); flVibra(10); }catch(_){ } }
    }, 450 + passo * i);
  });
  setTimeout(function(){ if (OR.on && OR.step === 'analisi'){ orApplicaKnown(); OR.step = 'dati'; orPaint(); orDatiCarica(); } }, 450 + passo * OR.analisi.length + 650);
}
/** I fatti letti nel telefono contano come risposte: una volta sola per lettura. */
function orApplicaKnown(){
  if (OR.knownFatti) return; OR.knownFatti = true;
  OR.known.forEach(k => { const q = OR_Q.filter(x => x.id === k.q)[0]; if (q && OR.asked.indexOf(q.id) < 0){ OR.post = orUpdate(OR.post, q, k.a); OR.asked.push(q.id); OR.answers[q.id] = k.a; } });
}
function orVaiTrigger(){ orApplicaKnown(); orAsk(); }
function orTrigScriviApri(){
  OR.trigScrivi = !OR.trigScrivi; if (!OR.trigScrivi) OR.triggerTesto = ''; orPaint();
  if (OR.trigScrivi) setTimeout(function(){ try{ const a = document.getElementById('orTrigArea'); if (a) a.focus(); }catch(_){ } }, 150);
}
function orTrigScrittoInput(v){
  OR.triggerTesto = String(v || '');
  const b = document.getElementById('orTrigOk'); if (b) b.disabled = !(OR.trigger.length || OR.triggerTesto.trim());
}
function orClose(){
  OR.on = false;
  try{ if (typeof muSiglaOff === 'function' && !(typeof GN !== 'undefined' && GN.on)) muSiglaOff(); }catch(_){ }
  orTwFerma();
  const el = document.getElementById('orWrap');
  if (el) el.hidden = true;
  document.body.classList.remove('or-on');
}
/* IL TASTO INDIETRO DI ANDROID (0.9.305). Andrea: "durante Rifai la lettura, indietro fa uscire dall'app". La
   lettura e' un velo a z-index 72 sopra alla casa: navVeloAperto (nav.js) guarda solo i veli dal livello 100 in su,
   quindi nessuno la chiudeva, handleBack restava sulla casa e rispondeva "non gestito", e Android chiudeva l'app.
   Ora handleBackNucleo chiede prima qui: ogni passo torna a quello di prima; dal primo, la lettura si chiude e
   resta la scheda Sogno. True se la lettura era aperta (il tasto e' stato usato qui). */
function orBack(){
  const el = document.getElementById('orWrap');
  if (!OR.on || !el || el.hidden) return false;
  const s = OR.step;
  const vai = function(st){ OR.step = st; orPaint(); return true; };
  if (s === 'think') return true;                                   /* il Genio sta leggendo la risposta: un attimo */
  if (s === 'sognoScrivi') return vai('sogno');
  if (s === 'alexander' && (OR.alxI || 0) > 0){ orTwFerma(); OR.alxI--; OR.twFatto = orTwChiave(); orPaint(); return true; }
  if (s === 'attesa' || s === 'alexander'){ orTwFerma(); OR.tgScrivi = false; return vai(OR.sogno ? 'sogno' : 'target'); }
  /* tornando indietro la vignetta e' gia' scritta: niente macchina da scrivere una seconda volta */
  if (s === 'alexander2'){ orTwFerma(); OR.alxI = OR.alxMax = OR_ALEX_INTRO.length; OR.twFatto = 'alexander' + OR.alxI; return vai('alexander'); }
  if (s === 'stat') return vai('known');
  if (s === 'pano') return vai('mantraOgni');
  if (s === 'diagnosi') return vai('pano');
  if (s === 'known'){ OR.step = 'dati'; orPaint(); orDatiCarica(); return true; }
  if (s === 'analisi' || s === 'dati'){ OR.twFatto = 'alexander2'; return vai('alexander2'); }
  /* le domande a scelta multipla stanno in mezzo alle altre: indietro torna alla domanda di prima */
  if (s === 'trigger'){ OR.trigScrivi = false; if (OR.hist.length) orUndo(); else orPrimaDelleDomande(); return true; }
  if (s === 'identita'){ OR.idScrivi = false; OR.idChiesta = false; if (OR.idq) OR.idqPrec = OR.idq; if (OR.hist.length) orUndo(); else orPrimaDelleDomande(); return true; }
  if (s === 'identikit') return vai('reveal');
  if (s === 'amb'){ if (OR.ambI > 0){ OR.ambI--; orPaint(); return true; } if (OR.hist.length) orUndo(); else orPrimaDelleDomande(); return true; }
  if (s === 'mantra') return vai('identikit');
  if (s === 'mantraOgni') return vai('mantra');
  if (s === 'fatto') return vai('ricalcola');
  if (s === 'ask'){ if (OR.hist.length) orUndo(); else orPrimaDelleDomande(); return true; }
  if (s === 'reveal'){ if (OR.hist.length){ orUndo(); return true; } }
  if (s === 'correggi'){ OR.corScrivi = false; return vai('reveal'); }
  if (s === 'plan' && OR.planDa === 'reveal' && OR.result) return vai('reveal');
  /* il primo passo (il sogno, o la persona) e tutto quello che non ha un passo prima: si chiude, e resta Dream */
  orClose();
  try{ if (typeof order !== 'undefined' && order[cur] === 's-home' && typeof navTabCorrente === 'function' && navTabCorrente() !== 'rotta') switchTab('rotta'); }catch(_){ }
  return true;
}
/* "No, lascialo com'e'": la lettura e' salvata, il percorso resta quello di prima */
/* 0.9.367, Andrea: "a fine lettura del Genio, se l'utente ha Premium, il Genio propone un bivio effetto farfalla: la strada del
   sacrificio, kill the old you before it kills you, con un programma creato da lui in Proteggi i tuoi sogni che blocca i
   comportamenti sabotanti. Bisogna prima morire per rinascere: il bruco che diventa farfalla". Senza Premium si va avanti come prima. */
/* 0.9.376, Andrea: "a fine lettura mi ha creato un programma che bloccava WhatsApp, il Play Store e tre categorie senza chiedermi
   niente: non potevo scrivere a mio padre. L'utente deve sempre scegliere cosa bloccare, e non per categorie". Il Genio non crea piu'
   programmi da solo. Il bivio adesso e': riscrivere chi sei con un mantra su misura (di serie), oppure andare all-in, e allora si
   apre Proteggi i tuoi sogni con i tre modi per bloccare spiegati, e sei tu a scegliere app per app. Vale con e senza Premium */
/* 0.9.378, Andrea: "non ti ho mai detto di fargli scegliere fra mantra e all-in. Il mantra si sceglie comunque, in base a chi deve
   diventare: mostragli l'identikit di chi e' adesso e di chi deve diventare, il passaporto senza l'aeroplano". Quindi dopo "Sono io":
   la carta d'identita' (oggi e domani), poi il mantra da scegliere, poi il quadro e il ricalcolo. Il vecchio bivio resta qui sotto,
   non chiamato */
function orSonoIoBivio(){ try{ flVibra(12); }catch(_){ } OR.step = 'identikit'; orPaint(); }
function orSonoIoBivioVecchio(){
  if (typeof faScena !== 'function'){ OR.step = (typeof pscTreHtml === 'function') ? 'pano' : 'ricalcola'; orPaint(); return; }
  faScena({
    kick: 'Effetto farfalla',
    titolo: 'Il bruco deve cambiare per diventare farfalla.',
    sotto: 'Scegli come vuoi cominciare. Sei tu a decidere, sempre.',
    bivio: true,
    opzioni: [
      { k: 'mantra', ico: '🦋', n: 'Riscrivo chi sono', s: 'Il Genio ti scrive un mantra per il nuovo te, da ripetere ogni giorno.', colore: '#4FB8FF', tinta: 'blu' },
      { k: 'allin', ico: '🔥', n: 'Vado all-in', s: 'Scegli tu cosa bloccare, app per app, e quanto blindarlo.', colore: '#FF5A66', tinta: 'rosso' }
    ],
    onScelta: function(k){
      try{ localStorage.setItem('fl_or_bivio', JSON.stringify({ at: Date.now(), scelta: k })); }catch(_){ }
      if (k === 'mantra') orMantraNuovoTe();
    },
    dopoTitolo: function(k){ return k === 'mantra' ? 'Il tuo mantra è pronto' : 'Il tuo ambiente lo decidi tu'; },
    dopoSotto: function(k){ return k === 'mantra' ? '"' + orMantraTesto() + '" Lo trovi nel Mantra 3-6-9.' : 'Adesso ti porto in Proteggi i tuoi sogni: lì scegli cosa bloccare e quando.'; },
    poi: function(k){ OR.step = (typeof pscTreHtml === 'function') ? 'pano' : 'ricalcola'; orPaint(); if (k === 'allin' || (localStorage.getItem('fl_or_bivio') || '').indexOf('allin') >= 0) setTimeout(orAllInSpiega, 400); }
  });
}
/** Il mantra del nuovo te: il capovolgimento del blocco che il sabotatore ha trovato. */
/* I FRENI DEL SABOTATORE INVISIBILE (blocchi.js, fl_blocchi) e il loro capovolgimento: chi devi diventare, e il mantra */
const OR_CAPOVOLTO = {
  valore: ['una persona che sa di valere e si mette in gioco', 'Io valgo, e mi metto in gioco ogni giorno.'],
  passato: ['una persona che riparte da oggi, non da quello che è andato male', 'Io riparto da oggi: il passato non decide per me.'],
  dispersione: ['una persona che sa concentrarsi e scegliere la cosa che conta', 'Io scelgo la cosa che conta e la porto a termine.'],
  tempo: ['una persona che protegge il suo tempo e lo dà a quello che conta', 'Io ho tempo per quello che conta, perché lo proteggo.'],
  paura: ['una persona che agisce anche quando ha paura', 'Io faccio il primo passo anche quando ho paura.'],
  sguardi: ['una persona che va avanti anche quando gli altri guardano', 'Io agisco anche quando gli altri guardano.'],
  denaro: ['una persona che investe su di sé senza paura di rischiare', 'Io investo su di me senza paura.'],
  imparare: ['una persona che impara facendo, senza aspettare di sapere tutto', 'Io imparo facendo: comincio prima di sentirmi pronto.']
};
function orFreno(){
  try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : JSON.parse(localStorage.getItem('fl_blocchi') || 'null'); if (b && b.primario) return b.primario; }catch(_){ }
  const f = OR.freni || ((orLast() || {}).freni) || {}; let k = '', m = 0.9;
  Object.keys(f).forEach(function(x){ if (f[x] > m){ m = f[x]; k = x; } });
  return k;
}
function orPersonaNuova(r){ const k = orFreno(); if (OR_CAPOVOLTO[k]) return OR_CAPOVOLTO[k][0]; return (r && r.persona) || orTargetName(r && r.target); }
function orMantraTesto(){ const k = orFreno(); return OR_CAPOVOLTO[k] ? OR_CAPOVOLTO[k][1] : 'Io sono la persona che fa ogni giorno quello che il mio sogno chiede.'; }
function orMantraNuovoTe(){
  try{
    if (typeof m369Leggi !== 'function' || typeof m369Salva !== 'function') return;
    const v = m369Leggi(), t = orMantraTesto();
    if (!v.lista.some(function(m){ return m && m.t === t; })) v.lista.unshift({ id: 'genio-io-' + Date.now().toString(36), t: t, media: null });
    v.on = true; v.scelto = v.lista[0].id; m369Salva(v);
  }catch(_){ }
}
/** All-in: i tre modi per blindare l'ambiente, poi Proteggi i tuoi sogni. Niente si blocca da solo. */
function orAllInSpiega(){
  if (typeof inSheet !== 'function'){ try{ blPaginaApri(); }catch(_){ } return; }
  const r = function(e, t, s){ return '<div class="or-ai-r"><span aria-hidden="true">' + e + '</span><div><b>' + t + '</b><small>' + s + '</small></div></div>'; };
  inSheet('<div class="en-foglio or-ai"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="or-info-e" aria-hidden="true">🔥</span><h3>Scegli tu cosa blindare</h3>'
    + r('🗓️', 'Un programma', 'Scegli le app e la condizione: un orario, un limite al giorno, un luogo.')
    + r('⚡', 'Il blocco rapido', 'Per una cosa che non vuoi più fare, da adesso.')
    + r('💊', 'La modalità severa', 'Pillola blu: tutto resta negoziabile. Pillola rossa: chiudi a chiave e la chiave la tiene il tuo garante.')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi();try{orClose()}catch(e){};setTimeout(function(){ try{ blPaginaApri(); }catch(_){ goId(\'s-blocco\'); } },300)">Apri Proteggi i tuoi sogni</button></div>');
}
/** Il programma del sacrificio: le app che ti costano carburante (le distrazioni del catalogo e le tue), mai quelle produttive. */
function orProgrammaSacrificio(){
  try{
    let gia = false; try{ gia = (typeof PROGRAMS !== 'undefined') && PROGRAMS.some(function(p){ return p && p.name === 'Uccidi il vecchio te'; }); }catch(_){ }
    if (gia || typeof frProgrammaDaAgente !== 'function') return;
    const cats = (typeof insCats === 'function') ? insCats(null) : {};
    const m = (typeof dpMappa === 'function') ? dpMappa() : {}, out = {};
    Object.keys(m).forEach(function(p){ if (m[p] >= 0.8 && cats[p] !== 'prod' && cats[p] !== 'neutro') out[p] = 1; });
    Object.keys(cats).forEach(function(p){ if (cats[p] === 'distr') out[p] = 1; else if (cats[p] === 'prod') delete out[p]; });
    frProgrammaDaAgente({ nome: 'Uccidi il vecchio te', app: Object.keys(out).slice(0, 200), dalle: '08:00', alle: '22:00', zitto: true });
  }catch(_){ }
}
function orRicalcoloNo(){
  orClose();
  try{ toast('Il percorso resta com\u2019\u00e8. Puoi ricalcolarlo alla prossima lettura.'); }catch(_){ }
}
function orPickTarget(id){
  OR.target = id;
  orAgentePrepara();
  orVaiAlexander();
}
function orTriggerToggle(id){
  const i = OR.trigger.indexOf(id);
  if (i >= 0) OR.trigger.splice(i, 1); else OR.trigger.push(id);
  orPaint();
}
function orTriggerOk(){
  if (!OR.trigger.length && !String(OR.triggerTesto || '').trim()) return;
  OR.trigFatto = true;
  orDopoMultipla();
}
function orIdentita(i){
  const q = OR.idq;
  if (q && q.o[i] && typeof ifRispostaIdentita === 'function') ifRispostaIdentita(q.attr, q.o[i].k);
  OR.idFatta = true; OR.idqPrec = q; OR.idq = null; OR.idScrivi = false;
  orDopoMultipla();
}
/* 0.9.305: "Lo scrivo io" anche qui, senza limiti. Le sue parole si tengono nel diario dell'Io Futuro (senza una
   chiave: il profilo non si sposta su una categoria che non ha scelto) */
function orIdScriviApri(){
  OR.idScrivi = !OR.idScrivi; orPaint();
  if (OR.idScrivi) setTimeout(function(){ try{ const a = document.getElementById('orIdArea'); if (a) a.focus(); }catch(_){ } }, 150);
}
function orIdScrittoInput(v){
  OR.idTesto = String(v || '');
  const b = document.getElementById('orIdOk'); if (b) b.disabled = !OR.idTesto.trim();
}
function orIdScrittoOk(){
  const v = String(OR.idTesto || '').trim(); const q = OR.idq;
  if (!v || !q) return;
  try{
    if (typeof ifLeggi === 'function' && typeof ifScrivi === 'function' && typeof IF_KEYS !== 'undefined'){
      const l = ifLeggi(IF_KEYS.risposte, []) || []; l.push({ attr: q.attr, testo: v, t: Date.now() }); ifScrivi(IF_KEYS.risposte, l.slice(-60));
    }
  }catch(_){ }
  OR.idFatta = true; OR.idqPrec = q; OR.idq = null; OR.idScrivi = false;
  orDopoMultipla();
}
/* la persona del sogno, con parole sue (passo "target", quando il sogno non c'e') */
function orTgScriviApri(){
  OR.tgScrivi = !OR.tgScrivi; orPaint();
  if (OR.tgScrivi) setTimeout(function(){ try{ const a = document.getElementById('orTgArea'); if (a) a.focus(); }catch(_){ } }, 150);
}
function orTgScrittoInput(v){
  const b = document.getElementById('orTgOk'); if (b) b.disabled = !String(v || '').trim();
}
function orTgScrittoOk(){
  const a = document.getElementById('orTgArea'); let v = a ? a.value.trim() : '';
  if (!v) return;
  v = v.replace(/[.!]+$/, '').replace(/^(io\s+)?(voglio\s+)?diventare\s+/i, '').trim() || v;
  /* "una persona che..." si legge dopo "diventare": se l'ha scritto in un altro modo, resta com'e' */
  OR.personaMia = v.charAt(0).toLowerCase() + v.slice(1);
  OR.target = orTargetDaSogno(v) || OR.target || 'altro';
  OR.tgScrivi = false;
  orAgentePrepara();
  orVaiAlexander();
}
/* "Non sono io": chi sei, con parole tue */
function orCorScriviApri(){
  OR.corScrivi = !OR.corScrivi; orPaint();
  if (OR.corScrivi) setTimeout(function(){ try{ const a = document.getElementById('orCorArea'); if (a) a.focus(); }catch(_){ } }, 150);
}
function orCorScrittoInput(v){
  OR.corTesto = String(v || '');
  const b = document.getElementById('orCorOk'); if (b) b.disabled = !OR.corTesto.trim();
}
function orCorScrittoOk(){
  const v = String(OR.corTesto || '').trim(); if (!v) return;
  OR.result = Object.assign({}, OR.result || {}, { chiSonoTesto: v });
  try{ localStorage.setItem(OR_KEY, JSON.stringify(OR.result)); }catch(_){ }
  OR.corScrivi = false; OR.step = 'reveal'; orPaint();
  try{ toast('Me lo segno: la prossima lettura parte anche da qui'); }catch(_){ }
}
/* 0.9.304: i dati letti nel telefono vengono PRIMA del trigger (orAnalisi): qui partono le domande */
function orDopoTrigger(){ orApplicaKnown(); orAsk(); }
/* Prima della prima domanda: la domanda d'identita' (se c'era) o il trigger. */
function orPrimaDelleDomande(){
  OR.n = 0; OR.q = null; OR.ultima = null;
  if (OR.analisi && OR.analisi.length){ OR.step = 'known'; }
  else { OR.twFatto = 'alexander2'; OR.step = 'alexander2'; }
  orPaint();
}
/* Una domanda indietro: si rimette lo stato di prima e si ripropone quella domanda. */
function orUndo(){
  const h = OR.hist.pop();
  if (!h){ orPrimaDelleDomande(); return; }
  /* 0.9.379, Andrea: "tornando alla domanda precedente, la risposta che avevo scelto deve essere gia' selezionata" */
  OR.giaScelta = (h.q && OR.answers && OR.answers[h.q.id] != null) ? OR.answers[h.q.id] : null;
  OR.post = h.post; OR.asked = h.asked; OR.answers = h.answers; OR.q = h.q; OR.n = h.n; OR.ultima = null;
  OR.step = 'ask';
  orPaint();
}
function orAsk(){
  OR.q = orNext(OR.post, OR.asked);
  if (!OR.q){ orReveal(); return; }
  OR.n++;
  OR.step = 'ask';
  orPaint();
}
/* L'ETICHETTA SOPRA AL PROFILO. "Se continui cosi', rischi di diventare il Disciplinato in costruzione" e' un controsenso: per i profili
   che portano avanti non e' un rischio. 0.9.378, Andrea */
/* 0.9.381, Andrea: "nel messaggio al mio agente c'e' scritto rischio di diventare disciplinato in costruzione: lo sto diventando, e' l'unico
   profilo positivo". La stessa etichetta, in prima persona, per il messaggio */
function orKickIo(id){
  if (id === 'disc' || id === 'real') return 'Sto diventando';
  if (id === 'equi') return 'Oggi sono';
  return 'Se continuo così, rischio di diventare';
}
function orKick(id){
  if (id === 'disc' || id === 'real') return 'Se continui così, diventi';
  if (id === 'equi') return 'Oggi sei';
  return 'Se continui così, rischi di diventare';
}
/* LA PROBABILITA', COERENTE CON L'INTRO. 0.9.378, Andrea: "nell'intro mi dice 42%, nella lettura 17%, poi 20%, poi 25% se dico che non
   sono io: numeri sparati a caso che demoliscono l'autostima". Il numero parte da quello che l'utente ha gia' visto (l'intro o la
   lettura di prima) e si sposta di poco, per ragioni che si possono dire: le risposte, i voti della partita, le promesse tenute.
   Mai piu' di 12 punti sopra o sotto il numero di partenza, mai sotto il 20. Una volta detto, non cambia se il profilo era sbagliato */
function orProbabilita(){
  let base = 0, da = '';
  try{ const l = orLast(); if (l && +l.pct > 0){ base = +l.pct; da = l.intro ? 'intro' : 'lettura'; } }catch(_){ }
  if (!base){ try{ const g = (typeof gnDati === 'function') ? gnDati() : null; if (g && +g.pct > 0){ base = +g.pct; da = 'intro'; } }catch(_){ } }
  if (!base){ base = 40; da = ''; }
  const righe = [], cl = function(x, m){ return Math.max(-m, Math.min(m, x)); };
  const profPct = OR.post.reduce(function(s, p, i){ return s + p * OR_PROFILES[i].pct; }, 0);
  const dR = Math.round(cl((profPct - 45) / 6, 6));
  if (dR) righe.push(['💬', 'Le tue risposte', dR, dR > 0 ? 'Mi hai descritto abitudini che portano avanti.' : 'Mi hai descritto abitudini che ti frenano.']);
  const v = orVoti(), vt = v.neo + v.old;
  if (vt >= 4){ const dV = Math.round(cl((v.neo / vt - .5) * 16, 8)); if (dV) righe.push(['⚽', 'La tua partita', dV, v.neo + ' voti al nuovo te e ' + v.old + ' al vecchio.']); }
  try{
    if (typeof pvRiuscita === 'function'){ const r = pvRiuscita(); if (r && r.domani != null){ const dP = Math.round(cl((r.domani - 50) / 10, 5)); if (dP) righe.push(['🤝', 'Le promesse dei giorni scorsi', dP, 'Hai tenuto il ' + r.domani + '% di quello che avevi detto di fare.']); } }
  }catch(_){ }
  const somma = righe.reduce(function(s, r){ return s + r[2]; }, 0);
  const pct = Math.max(Math.max(20, base - 12), Math.min(Math.min(92, base + 12), base + somma));
  return { pct: Math.round(pct), base: base, da: da, righe: righe };
}
function orPctInfo(){
  const r = OR.result || {}, pr = OR.prob || {};
  if (typeof inSheet !== 'function') return;
  const segno = function(n){ return (n > 0 ? '+' : '−') + Math.abs(n); };
  const l = [['🧭', 'In base a chi sei oggi', 'Conta come vivi le giornate adesso: le abitudini, quello in cui credi, l’ambiente intorno a te.']];
  if (pr.base) l.push(['🎯', 'Il punto di partenza: ' + pr.base + '%', pr.da === 'intro' ? 'È il numero che ti ho dato quando ci siamo conosciuti.' : 'È il numero della tua lettura di prima.']);
  (pr.righe || []).forEach(function(x){ l.push([x[0], x[1] + ': ' + segno(x[2]), x[3]]); });
  l.push(['📈', 'Il numero si muove', 'Sale ogni giorno in cui fai le tappe e voti per il nuovo te.']);
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Da dove viene il ' + (r.pct || pr.pct || '') + '%</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe(l) : '')
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/* LA CARTA D'IDENTITA': chi sei oggi e chi devi diventare, la stessa forma del passaporto della scheda Identita' (senza aeroplano) */
function orIdentikitHtml(){
  const r = OR.result || {}, p = orProfile(r.profile);
  let nome = '', im = '';
  try{ const g = (typeof gnDati === 'function') ? gnDati() : null; nome = g && g.nome ? String(g.nome).split(' ')[0] : ''; }catch(_){ }
  try{ im = (typeof nfImmagine === 'function') ? nfImmagine() : ''; }catch(_){ }
  const foto = im ? '<span class="or-id-foto" style="background-image:url(\'' + String(im).replace(/['()\\]/g, '') + '\')"></span>' : '<span class="or-id-foto"><i aria-hidden="true">🧑‍🚀</i></span>';
  return orBall(false)
    + '<div class="or-card or-qc"><p class="or-q">Ecco chi sei oggi, e chi devi diventare per arrivarci.</p></div>'
    + '<div class="or-id">'
    +   '<div class="or-id-c oggi"><p class="or-id-k">Chi sei oggi</p><div class="or-id-r"><span class="or-id-e" aria-hidden="true">' + p.ico + '</span><b>' + esc(p.name) + '</b></div></div>'
    +   '<div class="or-id-freccia" aria-hidden="true">↓</div>'
    +   '<div class="or-id-c dom"><p class="or-id-k">Chi devi diventare</p><div class="or-id-mid">' + foto + '<div class="or-id-dati">'
    +     (nome ? '<small>Nome</small><b>' + esc(nome) + '</b>' : '') + '<small>Destinazione</small><b>' + esc(orSognoAttuale() || 'Il tuo sogno') + '</b></div></div>'
    +     '<p class="or-id-chi">' + esc(orPersonaNuova(r).replace(/^./, function(c){ return c.toUpperCase(); })) + '.</p></div>'
    + '</div>'
    + '<div class="or-grid one"><button type="button" class="or-a main" onclick="OR.step=\'mantra\';orPaint()">Continua</button></div>';
}
/* IL MANTRA: si sceglie fra i capovolgimenti dei freni che la lettura ha trovato (il primo e' quello piu' forte), oppure lo scrive lui */
function orMantraOpzioni(){
  const f = Object.assign({}, OR.freni || {}), k0 = orFreno(), out = [];
  const ordine = Object.keys(f).sort(function(a, b){ return f[b] - f[a]; });
  [k0].concat(ordine, ['dispersione', 'tempo', 'paura', 'valore']).forEach(function(k){ if (k && OR_CAPOVOLTO[k] && out.indexOf(k) < 0 && out.length < 4) out.push(k); });
  return out;
}
function orMantraSceltaHtml(){
  const op = orMantraOpzioni();
  if (OR.mantraK == null && !OR.mantraScrivi) OR.mantraK = op[0];
  return orBall(false)
    + '<div class="or-card or-qc"><p class="or-q">Scegli la frase che ti ripeterai ogni giorno.</p>'
    + '<button type="button" class="or-info" onclick="event.stopPropagation();orMantraInfo()" aria-label="Perché un mantra">i</button></div>'
    + '<div class="or-mantre">' + op.map(function(k){ return '<button type="button" class="or-mantra' + (OR.mantraK === k && !OR.mantraScrivi ? ' on' : '') + '" onclick="OR.mantraK=\'' + k + '\';OR.mantraScrivi=false;orPaint()">"' + esc(OR_CAPOVOLTO[k][1]) + '"</button>'; }).join('') + '</div>'
    + '<button type="button" class="or-scrivo-l" onclick="OR.mantraScrivi=!OR.mantraScrivi;orPaint();setTimeout(function(){var a=document.getElementById(\'orMaArea\');if(a)a.focus()},150)">✍️ Lo scrivo io</button>'
    + (OR.mantraScrivi ? '<textarea class="or-area or-area-f" id="orMaArea" rows="2" placeholder="Io sono…" oninput="OR.mantraMio=this.value;var b=document.getElementById(\'orMaOk\');if(b)b.disabled=!this.value.trim()">' + esc(OR.mantraMio || '') + '</textarea>' : '')
    + '<div class="or-grid one"><button type="button" class="or-a main" id="orMaOk" ' + (OR.mantraScrivi && !String(OR.mantraMio || '').trim() ? 'disabled' : '') + ' onclick="orMantraOk()">Do il primo voto al nuovo me</button></div>';
}
function orMantraOk(){
  const t = OR.mantraScrivi ? String(OR.mantraMio || '').trim() : (OR_CAPOVOLTO[OR.mantraK] ? OR_CAPOVOLTO[OR.mantraK][1] : orMantraTesto());
  if (!t) return;
  try{
    if (typeof m369Leggi === 'function' && typeof m369Salva === 'function'){
      const v = m369Leggi();
      v.lista = (v.lista || []).filter(function(m){ return m && m.t !== t; });
      v.lista.unshift({ id: 'genio-io-' + Date.now().toString(36), t: t, media: null });
      v.scelto = v.lista[0].id; m369Salva(v);
    }
  }catch(_){ }
  /* 0.9.381: la frase diventa anche il mantra che compare sullo schermo (Il tuo perche'), la cadenza la sceglie nella schermata dopo */
  try{ if (typeof whyLoad === 'function'){ const w = whyLoad(); w.mantra = t.slice(0, 140); localStorage.setItem(WHY_KEY, JSON.stringify(w)); } }catch(_){ }
  OR.mantraT = t;
  try{ localStorage.setItem('fl_or_bivio', JSON.stringify({ at: Date.now(), scelta: 'mantra' })); }catch(_){ }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  /* 0.9.380: niente avviso con il velo scuro: la schermata dopo lo dice gia' */
  OR.step = 'mantraOgni'; orPaint();
}
function orAnswer(v){
  if (!OR.q) return;
  OR.giaScelta = null;
  // Prima di cambiare qualcosa si mette da parte com'era: è quello che permette di tornare
  // indietro di una domanda senza rifare tutta la lettura.
  OR.hist.push({ post: OR.post.slice(), asked: OR.asked.slice(), answers: Object.assign({}, OR.answers), q: OR.q, n: OR.n });
  if (OR.hist.length > 20) OR.hist.shift();
  OR.post = orUpdate(OR.post, OR.q, v);
  OR.asked.push(OR.q.id);
  OR.answers[OR.q.id] = v;
  OR.ultima = v;
  const top = orTop(OR.post);
  orFrenoConta(OR.q, v);
  const enough = orBasta(top);
  // La pausa prima della prossima mossa: il genio "pensa". È la pausa che fa sembrare che
  // stia davvero leggendo qualcosa, ed è quella che il Brain chiama pausa strategica.
  OR.step = 'think';
  orPaint();
  const giro = OR.hist.length;
  setTimeout(() => { if (!OR.on || OR.step !== 'think' || OR.hist.length !== giro) return; orDopoRisposta(enough); }, 850);
}
/* 0.9.378, Andrea: "Akinator fa molte piu' domande. E prima le domande a risposta chiusa, che sono le piu' facili, poi quelle a scelta
   multipla, intervallate". Dieci domande almeno, sedici al massimo; il momento in cui prendi il telefono dopo la quarta, la domanda
   d'identita' dopo l'ottava */
function orBasta(top){ top = top || orTop(OR.post); const s = (OR.sbagli || 0) * 4; return (OR.n >= 10 + s && top.p >= .6) || OR.n >= 16 + s; }
function orDopoRisposta(enough){
  if (!OR.trigFatto && (OR.n >= 4 || enough)){ OR.step = 'trigger'; orPaint(); return; }
  if (OR.trigFatto && !OR.idFatta && !OR.idChiesta && OR.n >= 8){
    OR.idChiesta = true;
    const idq = (typeof ifDomandaDelGiorno === 'function') ? ifDomandaDelGiorno() : null;
    if (idq){ OR.idq = idq; OR.step = 'identita'; orPaint(); return; }
  }
  /* 0.9.380, Andrea: "le domande sull'ambiente mettile nella lettura, invece di bloccarla": due domande sulla casa, dopo l'undicesima */
  if (OR.trigFatto && !OR.ambFatta && OR.n >= 11 && orAmbDaChiedere()){ OR.ambI = 0; OR.step = 'amb'; orPaint(); return; }
  if (enough) orReveal(); else orAsk();
}
function orAmbDaChiedere(){ try{ const c = (typeof pscCasa === 'function') ? pscCasa() : null; return !!c && (c.inneschi == null || c.inneschi === '') && !c.inneschiNo; }catch(_){ return false; } }
const OR_AMB_Q = [
  { t: 'A casa, quante cose hai intorno che ti ricordano il tuo sogno?', s: 'Una foto, un libro, un post-it, un oggetto che lo rappresenta.', k: 'inneschi' },
  { t: 'E quante ti portano lontano dal sogno?', s: 'Il cibo spazzatura in vista, la console accesa, il telefono sul comodino.', k: 'inneschiNo' }
];
const OR_AMB_OPZ = [['🚫', 'Nessuna', 0], ['✌️', 'Una o due', 2], ['🖐️', 'Da tre a cinque', 4], ['🔥', 'Più di cinque', 6]];
function orAmbScegli(v){
  const q = OR_AMB_Q[OR.ambI || 0];
  try{ const c = pscCasa(); c[q.k] = v; pscScriviCasa(c); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  if ((OR.ambI || 0) < OR_AMB_Q.length - 1){ OR.ambI = (OR.ambI || 0) + 1; orPaint(); return; }
  OR.ambFatta = true; orDopoMultipla();
}
function orDopoMultipla(){ orApplicaKnown(); if (orBasta()) orReveal(); else orAsk(); }
async function orReveal(){
  const top = orTop(OR.post);
  const prof = OR_PROFILES[top.i];
  let odds = { pct: 40, why: [] };
  try{ odds = await scSuccessOdds(); }catch(_){ }
  if (!OR.prob) OR.prob = orProbabilita();
  let pct = OR.prob.pct;

  /* IL VETTORE INTERO SOPRAVVIVE ALLA LETTURA.
     Prima di questa riga, di venti minuti di ragionamento bayesiano restava una parola: il nome
     del profilo vincente. Tutto il resto — quanto era vicino il secondo, quanto era escluso
     l'ultimo — spariva, e con esso ogni possibilita' di aggiornare la previsione senza rifare
     il quiz da capo. Da qui in poi il vettore e' il seme del motore, e sara' il comportamento
     dei giorni successivi a muoverlo. */
  let prove = 0;
  try{
    if (typeof pvSemina === 'function') pvSemina(OR.post);
    if (typeof pvGiro === 'function') await pvGiro();
    if (typeof pvRiuscita === 'function'){
      const r = pvRiuscita();
      if (r){ prove = r.prove || 0; }
    }
  }catch(_){ }
  /* 0.9.378: i voti della partita e le promesse tenute pesano dentro a orProbabilita, con un tetto, e si leggono nella (i) */
  odds.why = (OR.prob.righe || []).map(function(x){ return [x[1], (x[2] > 0 ? '+' : '−') + Math.abs(x[2])]; });

  OR.result = { target: OR.target, trigger: OR.trigger.slice(), profile: prof.id, pct: pct, conf: Math.round(top.p * 100), at: Date.now(), answers: OR.answers, why: odds.why, prove: prove,
    sogno: orSognoAttuale(), sognoScritto: !!OR.sognoMio, persona: orPersona(), triggerTesto: String(OR.triggerTesto || '').trim(), agente: !!OR.ai, freni: OR.freni || {} };
  try{ localStorage.setItem(OR_KEY, JSON.stringify(OR.result)); }catch(_){ }
  OR.step = 'reveal';
  orPaint();
  if (typeof scLifePaint === 'function') scLifePaint();
  if (typeof lvBump === 'function') lvBump();
  /* 0.9.380: finita la lettura, il pannello della combinazione segreta mostra il risultato */
  try{ if (typeof pstPaint === 'function') pstPaint(); }catch(_){ }

  /* IL MONITO.
     Quando il numero dice che la cosa piu' probabile e' il fallimento, dirlo a parole non e'
     mai bastato a nessuno — e questa app esiste perche' ad Andrea le parole non bastavano.
     Le due regole di rarita' (una volta a trimestre, mai due volte in sette giorni) stanno
     dentro a monDopoLettura: qui si dice solo «e' andata male», la decisione se proiettare la
     prende chi sa quando e' stata l'ultima volta. */
  try{ if (typeof monDopoLettura === 'function') monDopoLettura(pct, false); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   QUANDO IL GENIO SBAGLIA

   Il gioco di Akinator non è forte perché indovina: è forte perché quando NON indovina chiede
   chi stavi pensando, e quella risposta diventa un esempio. Da fuori sembra modestia; dentro è
   l'unico meccanismo che gli fa alzare la precisione partita dopo partita.

   Qui vale lo stesso, con una differenza importante: le risposte che l'utente ha appena dato
   sono già lì, quindi l'esempio è completo — non si sta chiedendo «chi sei» in astratto, si sta
   dicendo «queste dieci risposte appartengono a QUESTO profilo», che è un'etichetta vera.
   --------------------------------------------------------------------------------------- */
/* 0.9.376, Andrea: "se il Genio non indovina deve andare avanti a fare domande, come Akinator, finche' l'utente dice: mi ha inquadrato".
   Alla prima e alla seconda volta il profilo sbagliato si mette da parte e il Genio fa altre domande; dalla terza si sceglie dalla lista */
function orSbagliato(){
  const restano = OR_Q.filter(function(q){ return OR.asked.indexOf(q.id) < 0; }).length;
  if ((OR.sbagli || 0) < 2 && restano >= 3 && OR.result){
    OR.sbagli = (OR.sbagli || 0) + 1;
    const i = OR_PROFILES.findIndex(function(p){ return p.id === OR.result.profile; });
    if (i >= 0){ OR.post = OR.post.slice(); OR.post[i] *= 0.05; OR.post = orNorm(OR.post); }
    OR.step = 'think'; orPaint();
    setTimeout(function(){ if (OR.on && OR.step === 'think') orAsk(); }, 900);
    return;
  }
  OR.step = 'correggi';
  orPaint();
}
/** Le risposte alle domande sull'immagine di se' contano i freni: senza il sabotatore fatto, il freno lo dice la lettura. */
function orFrenoConta(q, v){
  if (!q || !q.fr || v === .5) return;
  OR.freni = OR.freni || {};
  const meno = q.fr.charAt(0) === '-', k = meno ? q.fr.slice(1) : q.fr;
  OR.freni[k] = (OR.freni[k] || 0) + (meno ? (1 - v) : v);
}

function orSonoIo(id){
  try{ if (typeof pvCorreggi === 'function') pvCorreggi(id, OR.answers); }catch(_){ }
  const p = orProfile(id);
  OR.result = Object.assign({}, OR.result || {}, { profile: id });
  try{ localStorage.setItem(OR_KEY, JSON.stringify(OR.result)); }catch(_){ }
  OR.step = 'reveal';
  orPaint();
  if (typeof scLifePaint === 'function') scLifePaint();
}

/* ---------- il ricalcolo del percorso ---------- */
async function orBuildPlan(){
  const r = OR.result || orLast();
  const plan = [];
  const a = (r && r.answers) || {};
  const yes = id => (a[id] || 0) >= .75;
  const no = id => a[id] !== undefined && a[id] <= .25;
  let topApp = null;
  try{
    if (NATIVE && NATIVE.getTopApps){
      const cats = (typeof insCats === 'function') ? insCats() : {};
      const t = await NATIVE.getTopApps({ from: Date.now() - 7 * 86400000, to: Date.now(), limit: 8, icons: 0 });
      const apps = ((t && t.apps) || []).filter(x => !x.self && !x.launcher);
      topApp = apps.filter(x => cats[x.packageName] === 'distr')[0] || apps[0] || null;
    }
  }catch(_){ }
  OR.planApp = topApp;
  const strictOn = (function(){ try{ return !!JSON.parse(localStorage.getItem('fl_sev_streak') || 'null'); }catch(_){ return false; } })();
  /* 0.9.309, Andrea: con Premium le mosse sono su misura. La prima apre la chat con il proprio agente, che conosce
     le risposte della lettura, e scrive nel campo la richiesta di un piano di prevenzione (parte solo con Invio).
     Il video e la modalita' severa (se non e' gia' attiva) restano per tutti. */
  if (orPremium()){
    let conChi = 'il tuo agente personale';
    try{ if (typeof agNomeA === 'function') conChi = agNomeA().replace(/^al /, 'il ').replace(/^a /, ''); }catch(_){ }
    plan.push({ ico: '🧞', t: 'Prepara il tuo piano di prevenzione', s: 'Lo scrivi con ' + esc(conChi) + ', che conosce già le tue risposte: cosa fare al posto del telefono nei momenti in cui cedi.', go: 'orGoAgente()' });
  }
  /* Guardare dove si sta andando: il filmato parte a tutto schermo, sopra alle mosse (orGoTrailer) */
  /* 0.9.381, Andrea: "Guarda dove stai andando era un video preso da Instagram: rischio diritti. Mostragli piuttosto quando arriva se non
     cambia niente, il calendario memento mori della Timeline". Niente filmato nelle mosse */
  plan.push({ ico: '🗓️', t: 'Guarda quando arrivi, se non cambi niente', s: 'Il calendario della tua vita in settimane ti mostra la data del sogno con le abitudini di oggi.', go: 'orGoMemento()' });
  if (!strictOn) plan.push({ ico: '🔒', t: 'Attiva la modalità severa per sette giorni', s: 'I blocchi non si possono più scavalcare. È la mossa che alza di più la tua probabilità.', go: 'orGoStrict()' });
  /* LA MOSSA DEL TRIGGER: la prima cosa tarata sulla risposta che il telefono non poteva
     dare. Un trigger solo → una mossa sola; piu' trigger → quella del primo scelto. */
  const trig = (r && r.trigger) || OR.trigger || [];
  const T = trig[0];
  if (T === 'letto') plan.push({ ico: '🌙', t: 'Lascia il telefono fuori dalla camera', s: 'Usa la sveglia di DreamMap al posto del telefono e blocca le app dalle 23 alle 7.', go: 'orGoAlarm()' });
  else if (T === 'noia' || T === 'morti') plan.push({ ico: '⏳', t: 'Riempi i tempi morti prima che lo faccia il telefono', s: 'Quando non hai niente da fare, avvia dieci minuti di Full Focus invece di aprire un\'app.', go: 'orGoFocus()' });
  else if (T === 'stress') plan.push({ ico: '🧘', t: 'Quando sale l\'ansia, ascolta il mantra prima di scorrere', s: 'Il telefono ti calma per due minuti e ti scarica per due ore. Il mantra ti dà la stessa pausa, senza il conto dopo.', go: 'orGoMantra()' });
  else if (T === 'lavoro') plan.push({ ico: '🚫', t: 'Blocca le app che ti distraggono mentre studi o lavori', s: 'Ogni sblocco costa venti minuti per tornare concentrato. Blocca solo le ore che contano: il resto della giornata resta libero.', go: 'orGoBlock()' });
  if (topApp) plan.push({ ico: '🚫', t: 'Blocca ' + esc(topApp.label || topApp.packageName) + ' nelle ore che contano', s: 'È l\'app che ti ha preso più tempo questa settimana: ' + scFmtShort(topApp.ms || 0) + '.', go: 'orGoBlock()' });
  if (yes('q1') || yes('q12') || yes('q6')) plan.push({ ico: '⏰', t: 'Svegliati con una voce, non con il telefono in mano', s: 'La sveglia di DreamMap suona con l\'audio che scegli tu, così il primo gesto della giornata non è uno scorrimento.', go: 'orGoAlarm()' });
  if (no('q10') || no('q3')) plan.push({ ico: '📝', t: 'Scrivi il tuo perché, e cosa farai domani', s: 'Un obiettivo che sta solo in testa non ha peso alle sette di mattina.', go: 'orGoWhy()' });
  /* Il consiglio cambia SEGNO a seconda del divario, e nessun altro dato di quest'app puo'
     dirlo: chi fa tanto e sta male non ha bisogno di stringere, ha bisogno del contrario. */
  try{
    const u = (typeof umPerGenio === 'function') ? umPerGenio() : null;
    if (u && u.giorni >= 4){
      if (u.divario >= 1) plan.push({ ico: '\u{1F49B}', t: 'Allarga una scadenza, non stringerla',
        s: 'Stai già facendo tanto e ti costa. Una data più onesta si rispetta; una data che ti svuota si abbandona.',
        go: 'switchTab(\'severa\')' });
      else if (u.divario <= -1) plan.push({ ico: '\u{1F3AF}', t: 'Chiedi di più a te stesso',
        s: 'Le tue giornate ti lasciano bene, ma con poco dentro. Qui non manca la disciplina: manca un traguardo che pesi.',
        go: 'switchTab(\'severa\')' });
    }
  }catch(_){ }
  plan.push({ ico: '🔥', t: 'Ascolta il tuo mantra ogni giorno', s: 'Tocca il + sulla card del mantra e la tua serie sale. È il gesto che vale più punti.', go: 'orGoMantra()' });
  return plan.slice(0, 3);
}
/* 0.9.309, Andrea: "Guarda dove stai andando non apre il video: si sente solo l'audio". CAUSA VERA: il passo chiamava
   cnVaiAlTrailer() senza chiudere la lettura; la sala partiva sotto e il filmato suonava dietro al velo della lettura
   (z-index 72), che restava aperto con le tre mosse. Adesso il filmato parte a tutto schermo (monApri, sopra a tutto);
   alla fine "Chiudi" riporta alle tre mosse, le altre uscite chiudono prima la lettura. */
function orGoTrailer(){
  if (typeof monApri !== 'function'){ orClose(); if (typeof cnVaiAlTrailer === 'function') cnVaiAlTrailer(); return; }
  monApri({});
  const w = document.getElementById('monWrap');
  if (w) w.addEventListener('click', function(e){ const b = e.target.closest && e.target.closest('button'); if (b && !b.hasAttribute('data-chiudi')) orClose(); }, true);
}
/** Premium: la chat con il proprio agente, con la richiesta del piano di prevenzione scritta nel campo (non parte da sola). */
function orGoAgente(){
  const testo = orPrevenzioneTesto();
  orClose();
  if (typeof agPopover === 'function'){ agPopover(testo, { titolo: 'Il mio piano di prevenzione' }); return; }
  if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo);
}
function orPrevenzioneTesto(){
  const r = OR.result || orLast() || {};
  const minu = function(t){ t = String(t || '').trim(); return t ? t.charAt(0).toLowerCase() + t.slice(1) : ''; };
  const righe = ['Ho appena fatto la lettura del futuro.'];
  if (typeof r.pct === 'number'){
    const chi = r.persona || (r.target ? orTargetName(r.target) : '');
    righe.push('Con le abitudini di oggi ho il ' + r.pct + '% di probabilità di diventare ' + (chi || 'la persona che realizza il mio sogno') + '.');
  }
  try{ const p = r.profile ? orProfile(r.profile) : null; if (p && p.name) righe.push(orKickIo(p.id) + ' "' + p.name + '".'); }catch(_){ }
  const trig = (r.trigger || OR.trigger || []).map(function(id){ const x = OR_TRIGGER.filter(function(t){ return t.id === id; })[0]; return x ? minu(orTrT(x)) : ''; }).filter(Boolean);
  const mio = String(r.triggerTesto || OR.triggerTesto || '').trim().replace(/^prendo il telefono( senza pensarci)?[,:]?\s*/i, '');
  if (mio) trig.push(minu(mio));
  if (trig.length) righe.push('Prendo il telefono senza pensarci ' + (trig.length > 1 ? trig.slice(0, -1).join(', ') + ' e ' + trig[trig.length - 1] : trig[0]) + '.');
  const app = OR.planApp;
  if (app && app.ms) righe.push('L\u2019app che mi prende più tempo è ' + (app.label || app.packageName) + ': ' + scFmtShort(app.ms) + ' questa settimana.');
  righe.push('Aiutami a creare un piano di prevenzione: per ogni momento in cui cedo, cosa faccio al posto del telefono e quale blocco attivo. Fammi una domanda alla volta.');
  return righe.join(' ');
}
async function orPlanOpen(){
  OR.planDa = (OR.on && (OR.step === 'reveal' || OR.step === 'ricalcola')) ? 'reveal' : '';
  OR.plan = await orBuildPlan();
  const el = document.getElementById('orWrap');
  if (el) el.hidden = false;
  document.body.classList.add('or-on');
  OR.on = true;
  OR.step = 'plan';
  orPaint();
}
function orGoStrict(){ orClose(); goId('s-home'); switchTab('severa'); setTimeout(() => { const b = document.getElementById('sevTabBox'); if (b) b.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 350); }
function orGoBlock(){ orClose(); goId('s-home'); switchTab('blocco'); }
function orGoAlarm(){ orClose(); goId('s-home'); switchTab('sveglia'); }
function orGoFocus(){ orClose(); goId('s-home'); switchTab('sveglia'); if (typeof stGoFocus === 'function') setTimeout(stGoFocus, 350); }
function orGoWhy(){ orClose(); if (typeof whyOpen === 'function') whyOpen(); }
function orGoMantra(){ orClose(); goId('s-personalize'); if (typeof personalizePaint === 'function') personalizePaint(); }

/* ---------- lo schermo ---------- */
/* IL GENIO AL POSTO DELLA SFERA (0.9.184), come il personaggio di Akinator: la faccia cambia
   con le risposte. Pensa mentre legge la risposta; sorride a un sì; e' giu' a un no; quando
   la lettura sta prendendo forma (un profilo sopra al 50% dopo tre domande) ha l'aria di chi ha
   capito. Prima delle domande saluta. */
function orGenioPosa(thinking){
  if (thinking) return 'pensa';
  if (OR.step === 'alexander') return (OR.alxI || 0) < OR_ALEX_INTRO.length ? 'saluta' : 'rivela';
  if (OR.step !== 'ask' && OR.step !== 'think') return 'saluta';
  const v = OR.ultima;
  if (v != null && v <= .25) return 'triste';
  let quasi = false; try{ quasi = OR.n >= 3 && orTop(OR.post).p >= .5; }catch(_){ }
  if (quasi) return 'rivela';
  if (v == null || v === .5) return 'pensa';
  return 'saluta';
}
function orBall(thinking){
  const posa = orGenioPosa(thinking);
  return '<div class="or-ball or-genio' + (thinking ? ' think' : '') + '"><img class="posa-' + posa + '" src="img/genio/genio-' + posa + '.png" alt=""></div>';
}
/* LE OPZIONI COME NEGLI EPISODI (0.9.305, Andrea): le carte a due colonne con l'emoji (.gn-cards/.gn-card di
   genio-intro.js, le stesse delle domande della serie), e "Lo scrivo io" tratteggiata in fondo. Con un numero
   dispari di opzioni "Lo scrivo io" chiude la griglia accanto all'ultima; con un numero pari prende la riga intera. */
function orSognoEmoji(){
  try{ if (typeof cstIcona === 'function'){ const e = cstIcona(); if (e) return e; } }catch(_){ }
  try{ if (typeof accSognoEmoji === 'function') return accSognoEmoji(); }catch(_){ }
  return '✨';
}
/** La (i) di una domanda: il perche' sta qui, non sotto alla domanda. */
function orInfo(e, t, testo){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="or-info-e" aria-hidden="true">' + e + '</span><h3>' + esc(t) + '</h3><p class="or-info-p">' + esc(testo) + '</p><button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function orCarteHtml(items, scrivo){
  const pari = items.length % 2 === 0;
  return '<div class="gn-cards or-cards' + (pari ? ' dispari-s' : ' or-mezzo') + '">'
    + items.map(function(x){
        return '<button type="button" class="gn-card' + (x.on ? ' on' : '') + '" onclick="' + x.click + '">'
          + '<span>' + x.e + '</span><b>' + esc(x.l) + '</b>' + (x.s ? '<small>' + esc(x.s) + '</small>' : '') + '</button>';
      }).join('')
    + (scrivo ? '<button type="button" class="gn-card tratt' + (scrivo.on ? ' on' : '') + '" onclick="' + scrivo.click + '"><span>✍️</span><b>Lo scrivo io</b><small>Con parole mie</small></button>' : '')
    + '</div>';
}
/* la prima frase di una descrizione: nelle carte strette basta quella */
function orPrimaFrase(t){ const m = String(t || '').match(/^[^.:]+[.:]?/); return m ? m[0].replace(/:$/, '.') : ''; }
function orPaint(){
  const el = document.getElementById('orWrap');
  if (!el) return;
  const canUndo = (OR.step === 'ask' || OR.step === 'think') && OR.hist.length > 0;
  /* La X chiude, e sta sempre dove sta una X. La freccia per tornare indietro di una domanda
     non e' una chiusura: vive sopra al pannello bianco, in basso a sinistra dell'illustrazione,
     dove la mette il gioco a cui somiglia. */
  const top = '<div class="or-top">'
    + '<button type="button" class="or-x" onclick="orChiudiChiedi()" aria-label="Chiudi">'
    +   '<svg viewBox="0 0 14 14" width="14" height="14" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" d="M1 1l12 12M13 1L1 13"/></svg>'
    + '</button>'
    + '<b class="or-n">' + (OR.step === 'ask' || OR.step === 'think' ? 'Domanda n° ' + OR.n : ({ sogno: 'Il tuo sogno', sognoScrivi: 'Il tuo sogno', sognoCambia: 'Il tuo sogno', target: 'Il tuo sogno', attesa: 'Prima della lettura', alexander: 'Prima della lettura', alexander2: 'Prima della lettura', analisi: 'Le tue abitudini', trigger: 'Cosa ti fa cedere', identita: 'Chi sei', known: 'Quello che so già', plan: 'Ricalcolo del percorso', ricalcola: 'Ricalcolo del percorso', fatto: 'Ricalcolo del percorso', mantra: 'Il tuo mantra', mantraOgni: 'Il tuo mantra' }[OR.step] || 'Ho visto')) + '</b><span></span></div>';
  let body = '';
  if (OR.step === 'sogno'){
    /* UNA domanda: e' ancora questo il tuo sogno? Il sogno in grande, fra virgolette, com'e' scritto nell'app */
    body = orBall(false)
      + '<div class="or-card or-centro"><p class="or-pre">Il sogno che hai scelto è questo</p>'
      /* 0.9.342, Andrea: "il sogno appare senza emoji: deve apparire l'emoji. Non te lo voglio piu' dover ripetere" */
      + '<span class="or-sogno-e" aria-hidden="true">' + orSognoEmoji() + '</span>'
      + '<div class="or-sogno">"' + esc(OR.sogno) + '"</div>'
      + '<p class="or-q">È ancora questo il tuo sogno?</p></div>'
      + '<div class="or-grid one">'
      +   '<button type="button" class="or-a main" onclick="orSognoSi()">Sì, confermo</button>'
      /* 0.9.373, Andrea: "Lo scrivo io compare prima di aver toccato Cambia il mio sogno; e Cambia il mio sogno portava subito a
         Ricomincia da capo. Cambiarlo vuol dire prima riscriverlo con parole mie; ricominciare con un sogno diverso e' un'altra scelta" */
      +   '<button type="button" class="or-a" onclick="OR.step=\'sognoCambia\';orPaint()">Cambia il mio sogno</button>'
      + '</div>';
  } else if (OR.step === 'sognoCambia'){
    /* 0.9.375, Andrea: "hai messo il pulsante Torna indietro invece della freccia che c'e' in tutte le altre domande, sopra al pannello
       bianco": la freccia di sempre */
    body = orBall(false) + '<div class="or-backrow"><button type="button" class="or-back" onclick="OR.step=\'sogno\';orPaint()" aria-label="Torna al sogno">'
          + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>'
      + '<div class="or-card or-centro"><p class="or-q">Come vuoi cambiarlo?</p></div>'
      + '<div class="or-grid one">'
      +   '<button type="button" class="or-a main" onclick="orSognoScrivi()">✍️ Lo riscrivo con parole mie</button>'
      +   '<button type="button" class="or-a" onclick="orSognoCambia()">🔄 Scelgo un sogno diverso e ricomincio</button>'
      + '</div>';
  } else if (OR.step === 'sognoScrivi'){
    body = orBall(false)
      + '<div class="or-card or-centro"><p class="or-q">Allora scrivilo tu: qual è il tuo sogno?</p>'
      + '<textarea class="or-area" id="orSognoArea" rows="4" placeholder="Il mio sogno è…" oninput="orSognoScrittoInput(this.value)">' + esc(OR.sognoMio || '') + '</textarea></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" id="orSognoOk" ' + (OR.sognoMio ? '' : 'disabled') + ' onclick="orSognoScrittoOk()">Confermo</button>'
      +   '<button type="button" class="or-a" onclick="OR.step=\'sogno\';orPaint()">Torna al sogno che avevo scelto</button></div>';
  } else if (OR.step === 'attesa'){
    body = orBall(true) + '<div class="or-backrow"></div><div class="or-card ask"><p class="or-q">Mmm…</p></div>';
  } else if (OR.step === 'alexander' || OR.step === 'alexander2'){
    /* 0.9.306: due vignette, la frase poi la persona. Si tocca la vignetta (o il Genio) per andare avanti */
    const prima = OR.step === 'alexander', scritta = OR.twFatto === orTwChiave();
    const intro = prima && (OR.alxI || 0) < OR_ALEX_INTRO.length;
    const freccia = '<span class="or-freccia" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M5 8h14l-7 9z"/></svg></span>';
    body = '<div class="or-vign-w" onclick="orVignTocco()">' + orBall(false)
      + '<div class="or-card or-centro or-vign' + (scritta ? ' pronta' : '') + '">'
      + (intro
          ? '<p class="or-lega" id="orTw">' + (scritta ? '<span class="or-tw-v">' + orTwParti(orAlexTesto()).html + '</span>' : '') + '</p>'
        : prima
          ? '<p class="or-cit' + (orFrase()[1] ? '' : ' or-cit-genio') + '" id="orTw">' + (scritta ? '<span class="or-tw-v">' + orTwParti(orFraseTesto()).html + '</span>' : '') + '</p>' + (orFrase()[1] ? '<small class="or-aut">~ ' + esc(orFrase()[1]) + '</small>' : '')
          : '<p class="or-lega" id="orTw">' + (scritta ? '<span class="or-tw-v">' + orTwParti(orTestoLega()).html + '</span>' : '') + '</p>')
      + freccia + '</div>'
      + (prima ? '<p class="or-tocca">Tocca per continuare</p>' : '')
      + '</div>'
      + (prima ? '' : '<div class="or-grid one or-dopo' + (scritta ? ' on' : '') + '"><button type="button" class="or-a main" onclick="orAnalisi()">Leggi le mie abitudini</button></div>');
  } else if (OR.step === 'analisi'){
    body = orBall(true) + '<div class="or-backrow"></div>'
      + '<div class="or-card ask or-qc"><p class="or-q">Sto leggendo le tue abitudini…</p></div>'
      + (OR.analisi ? '<ul class="or-ana or-ana-f">' + OR.analisi.map(function(t){ return '<li><i></i><span>' + esc(t) + '</span></li>'; }).join('') + '</ul>' : '');
  } else if (OR.step === 'dati'){
    /* 0.9.377, Andrea: "il pannello dentro a un altro pannello bianco, e la panoramica insieme: One Element One Focus. Prima il punteggio,
       poi le statistiche se le vuole". Qui solo dove va la tua attenzione, come nella revisione della sera, senza contenitore */
    body = orBall(false)
      + '<div class="or-card ask or-qc"><p class="or-q">Prima di indovinare, guardiamo i fatti: dove va la tua attenzione.</p></div>'
      + '<div class="or-dati" id="orPan"><p class="or-dati-att">Sto leggendo il telefono…</p></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="OR.step=\'known\';orPaint()">Continua</button></div>';
  } else if (OR.step === 'stat'){
    body = orBall(false)
      + '<div class="or-card ask or-qc"><p class="or-q">Ecco cosa c’è dietro al risultato della tua partita.</p></div>'
      + '<div class="or-dati" id="orStat">' + orStatHtml() + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="orVaiTrigger()">Continua</button></div>';
  } else if (OR.step === 'pano'){
    body = orBall(false)
      + '<div class="or-card ask or-qc"><p class="or-q">E adesso il quadro intero: il numero della combinazione che ti frena.</p></div>'
      /* 0.9.378, Andrea: "Lavora su azione nella lettura non funziona e non serve: ha senso nel pannello della combinazione segreta" */
      + '<div class="or-dati or-dati-tre">' + ((typeof pscTreHtml === 'function') ? pscTreHtml().replace(/<button[^>]*class="pst-cta"[\s\S]*?<\/button>/g, '') : '') + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="OR.step=\'diagnosi\';orPaint()">Continua</button></div>';
  } else if (OR.step === 'diagnosi'){
    body = orDiagnosiHtml();
  } else if (OR.step === 'target'){
    body = orBall(false)
      + '<div class="or-card or-qc"><p class="or-q">Quale persona vuoi diventare, realizzando il tuo sogno?</p></div>'
      + '<div class="gn-carta or-carta">' + orCarteHtml(OR_TARGETS.map(function(t){ return { e: t.ico, l: t.name, s: t.sub, on: OR.target === t.id && !OR.tgScrivi, click: 'orPickTarget(\'' + t.id + '\')' }; }), { on: OR.tgScrivi, click: 'orTgScriviApri()' }) + '</div>'
      + (OR.tgScrivi ? '<textarea class="or-area or-area-f" id="orTgArea" rows="3" placeholder="Una persona che…" oninput="orTgScrittoInput(this.value)">' + esc(OR.personaMia || '') + '</textarea>' : '')
      + (OR.tgScrivi ? '<div class="or-grid one"><button type="button" class="or-a main" id="orTgOk" ' + (OR.personaMia ? '' : 'disabled') + ' onclick="orTgScrittoOk()">Confermo</button></div>' : '');
  } else if (OR.step === 'trigger'){
    const puo = OR.trigger.length || String(OR.triggerTesto || '').trim();
    body = orBall(false)
      /* 0.9.375, Andrea: "le opzioni fuori dal pannello della domanda, come nell'intro e negli episodi; Lo scrivo io leggibile e fuori;
         Riconoscere il tuo trigger... non va detto, sta dietro alla (i)" */
      /* 0.9.378, Andrea: "dopo il punto di domanda non ci deve essere niente; solo se la risposta e' a scelta multipla, una riga piccola
         sotto. Il perche' della domanda c'e' gia' nella (i)" */
      + '<div class="or-card or-qc"><p class="or-q">In quale momento prendi il telefono "senza pensarci"?</p><p class="or-q-nota">Puoi sceglierne più di uno.</p>'
      + '<button type="button" class="or-info" onclick="event.stopPropagation();orInfo(\'🎯\',\'Perché te lo chiedo\',\'Riconoscere il momento in cui prendi il telefono è il primo passo per spezzare l’abitudine.\')" aria-label="Perché te lo chiedo">i</button></div>'
      + '<div class="gn-carta or-carta">' + orCarteHtml(OR_TRIGGER.map(function(t){ return { e: t.ico, l: orTrT(t), on: OR.trigger.indexOf(t.id) >= 0, click: 'orTriggerToggle(\'' + t.id + '\')' }; }), { on: OR.trigScrivi, click: 'orTrigScriviApri()' }) + '</div>'
      + (OR.trigScrivi ? '<textarea class="or-area or-area-f" id="orTrigArea" rows="3" placeholder="Prendo il telefono quando…" oninput="orTrigScrittoInput(this.value)">' + esc(OR.triggerTesto || '') + '</textarea>' : '')
      + '<div class="or-grid one"><button type="button" class="or-a" id="orTrigOk" ' + (puo ? '' : 'disabled') + ' onclick="orTriggerOk()">Continua</button></div>';
  } else if (OR.step === 'identita' && OR.idq){
    body = orBall(false)
      /* 0.9.379, Andrea: "nessuna (i) su Cosa ti ferma piu' spesso: l'utente non sa ancora chi e' il suo Io Futuro" */
      + '<div class="or-card or-qc"><p class="or-q">' + esc(OR.idq.t) + '</p></div>'
      + '<div class="gn-carta or-carta">' + orCarteHtml(OR.idq.o.map(function(o, i){ return { e: o.e || '✨', l: o.l, click: 'orIdentita(' + i + ')' }; }), { on: OR.idScrivi, click: 'orIdScriviApri()' }) + '</div>'
      + (OR.idScrivi ? '<textarea class="or-area or-area-f" id="orIdArea" rows="3" placeholder="Scrivi qui la tua risposta" oninput="orIdScrittoInput(this.value)">' + esc(OR.idTesto || '') + '</textarea>' : '')
      + (OR.idScrivi ? '<div class="or-grid one"><button type="button" class="or-a main" id="orIdOk" ' + (String(OR.idTesto || '').trim() ? '' : 'disabled') + ' onclick="orIdScrittoOk()">Confermo</button></div>' : '');
  } else if (OR.step === 'known' && OR.known[0] && OR.known[0].q === 'partita'){
    /* 0.9.374, Andrea: "il punteggio 1 a 1 dentro al pannello bianco fa schifo: quella e' la nuvoletta di quello che dice il Genio. Il
       tabellone si mostra fuori, con la grafica del tabellone, come nelle revisioni" */
    const v = orVoti();
    const esito = v.neo > v.old ? 'Stai vincendo tu' : (v.old > v.neo ? 'Sta vincendo il vecchio te' : 'Pareggio');
    body = orBall(false)
      + '<div class="or-card"><p class="or-q">Prima che tu risponda, una cosa la so già: com’è andata la tua partita.</p></div>'
      + '<div class="vt scuro or-vt"><p class="vt-kick">La tua partita</p><div class="vt-tab"><div class="vt-sq old' + (v.old > v.neo ? ' su' : '') + '"><small>Vecchio te</small><b>' + v.old + '</b></div><span class="vt-vs">:</span>'
      + '<div class="vt-sq neo' + (v.neo > v.old ? ' su' : '') + '"><small>Nuovo te</small><b>' + v.neo + '</b></div></div><p class="vt-esito">' + esito + '</p></div>'
      + '<button type="button" class="or-dati-stat" onclick="orApplicaKnown();OR.step=\'stat\';orPaint()">⚽ Vuoi vedere le statistiche della partita?</button>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="orVaiTrigger()">Confermo</button></div>';
  } else if (OR.step === 'known'){
    body = orBall(false)
      + '<div class="or-card"><p class="or-q">Prima che tu risponda, una cosa la so già. L\u2019ho letta nel tuo telefono.</p>'
      + (OR.known[0] && OR.known[0].big
          ? '<div class="or-fatto"><b>' + OR.known[0].big + '</b><small>' + OR.known[0].say + '</small></div>'
          : '<ul class="or-known">' + OR.known.map(k => '<li>' + k.say + '</li>').join('') + '</ul>')
      + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="orVaiTrigger()">Confermo</button></div>';
  } else if (OR.step === 'ask' || OR.step === 'think'){
    const thinking = OR.step === 'think';
    body = orBall(thinking)
      + (canUndo ? '<div class="or-backrow"><button type="button" class="or-back" onclick="orUndo()" aria-label="Domanda precedente">'
          + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'
          + '</button></div>' : '<div class="or-backrow"></div>')
      + '<div class="or-card ask"><p class="or-q">' + (thinking ? 'Mmm…' : esc(orQT(OR.q))) + '</p></div>'
      + '<div class="or-grid' + (thinking ? ' off' : '') + '">'
      + [[.75, 'Probabilmente sì'], [.25, 'Probabilmente no'], [1, 'Sì'], [.5, 'Non lo so'], [0, 'No']].map(function(x){ return '<button type="button" class="or-a' + (!thinking && OR.giaScelta === x[0] ? ' or-gia' : '') + '" onclick="orAnswer(' + x[0] + ')">' + x[1] + '</button>'; }).join('')
      + '</div>';
  } else if (OR.step === 'reveal'){
    const r = OR.result; const p = orProfile(r.profile);
    /* 0.9.304: «Stai diventando» suonava come un giudizio (genio-intro.js); la probabilita' e' quella di diventare la
       persona del sogno, la stessa della frase di Alexander */
    body = '<div class="or-reveal"><b class="or-kick">' + orKick(p.id) + '</b>'
      + '<div class="or-who">' + p.ico + '</div><h2 class="or-name">' + esc(p.name) + '</h2>'
      + '<p class="or-desc">' + esc(p.desc) + '</p>'
      /* 0.9.376, Andrea: "la probabilita' e' quella di realizzare il sogno con l'identita', le credenze e le abitudini di OGGI, non di
         diventare la persona che chiude Telegram. E la percentuale in azzurro". Sotto, chi devi diventare: il capovolgimento del freno */
      /* 0.9.378, Andrea: "con chi sei oggi non e' italiano; troppo testo; e il numero deve essere coerente con l'intro, spiegato nella
         (i)". Chi devi diventare va nella schermata dopo, con la carta d'identita' */
      + '<div class="or-pct"><button type="button" class="or-info or-pct-i" onclick="orPctInfo()" aria-label="Da dove viene il numero">i</button><b>' + r.pct + '<span>%</span></b><small>è la probabilità di realizzare il tuo sogno in base a chi sei oggi.</small></div>'
      /* «E SE HO SBAGLIATO?»
         È la domanda che il genio di Akinator fa quando non indovina, ed è l'unico modo che ha
         per migliorare: senza, un motore che impara non ha mai un esempio etichettato da cui
         imparare. Sta sotto la percentuale e non ruba la scena al risultato, ma c'è. */
      /* 0.9.342, Andrea: "troppa roba insieme: prima solo l'esito, con Sono io e Non sono io, e la percentuale. La domanda sul
         ricalcolo va in un'altra schermata". One element, one focus */
      + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="orSonoIoBivio()">Sì, sono io</button>'
      +   '<button type="button" class="or-a or-scrivo" onclick="orSbagliato()">Non sono io. Chi sono, allora?</button></div>';
  } else if (OR.step === 'amb'){
    const q = OR_AMB_Q[OR.ambI || 0];
    body = orBall(false)
      + '<div class="or-card or-qc"><p class="or-q">' + esc(q.t) + '</p><p class="or-q-nota">' + esc(q.s) + '</p></div>'
      + '<div class="gn-carta or-carta">' + orCarteHtml(OR_AMB_OPZ.map(function(o){ return { e: o[0], l: o[1], click: 'orAmbScegli(' + o[2] + ')' }; }), null) + '</div>';
  } else if (OR.step === 'identikit'){
    body = orIdentikitHtml();
  } else if (OR.step === 'mantra'){
    body = orMantraSceltaHtml();
  } else if (OR.step === 'mantraOgni'){
    body = orMantraOgniHtml();
  } else if (OR.step === 'fatto'){
    body = orBall(false)
      + '<div class="or-card or-qc or-fatto-c"><p class="or-q">Fatto: ho ricalcolato la roadmap con quello che ho letto. 🧭</p>'
      + '<p class="or-sub">Per oggi basta così. Le mosse per diventare chi vuoi ti aspettano nella scheda Identità, sotto a chi devi diventare.</p></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="orClose();if(typeof pstVaiAai===\'function\')pstVaiAai(\'io\')">Vedi chi devi diventare</button>'
      +   '<button type="button" class="or-a or-scrivo" onclick="orClose()">Chiudi</button></div>';
  } else if (OR.step === 'ricalcola'){
    /* 0.9.305: "Ricalcola il percorso" e' una proposta: senza il suo si' il percorso resta com'e' */
    body = orBall(false)
      + '<div class="or-card or-centro"><p class="or-q">Vuoi che ricalcoli il percorso con quello che ho letto?</p>'
      + '<p class="or-sub">Se dici di no, il percorso resta com’è.</p></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="orRicalcolaSi()">Sì, ricalcola il percorso</button>'
      +   '<button type="button" class="or-a or-scrivo" onclick="orRicalcoloNo()">No, lascialo com’è</button></div>';
  } else if (OR.step === 'correggi'){
    body = '<div class="or-reveal"><b class="or-kick">Dimmelo tu</b>'
      + '<p class="or-desc">Sceglilo, e le risposte che mi hai dato diventano il tuo esempio: '
      + 'la prossima lettura parte da qui, e le domande che ti ho fatto valgono un po\' diverso.</p>'
      + '<div class="or-card or-card-scelte">'
      + orCarteHtml(OR_PROFILES.map(function(x){ return { e: x.ico, l: x.name, s: orPrimaFrase(x.desc), click: 'orSonoIo(\'' + x.id + '\')' }; }), { on: OR.corScrivi, click: 'orCorScriviApri()' })
      + (OR.corScrivi ? '<textarea class="or-area" id="orCorArea" rows="3" placeholder="Sono una persona che…" oninput="orCorScrittoInput(this.value)">' + esc(OR.corTesto || '') + '</textarea>' : '')
      + '</div></div>'
      + '<div class="or-grid one">' + (OR.corScrivi ? '<button type="button" class="or-a main" id="orCorOk" ' + (String(OR.corTesto || '').trim() ? '' : 'disabled') + ' onclick="orCorScrittoOk()">Confermo</button>' : '')
      +   '<button type="button" class="or-a" onclick="OR.corScrivi=false;OR.step=\'reveal\';orPaint()">Lascia stare</button></div>';
  } else if (OR.step === 'plan'){
    body = '<div class="or-reveal plan"><b class="or-kick">Tre mosse, in ordine</b>'
      + '<p class="or-desc">Non serve fare tutto. Serve fare la prima.</p>'
      + '<div class="or-plan">' + OR.plan.map((s, i) => '<button type="button" class="or-step" onclick="' + s.go + '"><i>' + (i + 1) + '</i><span class="ico">' + s.ico + '</span><div><b>' + s.t + '</b><small>' + s.s + '</small></div><svg class="chev" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="none" stroke="#7A8AA6" stroke-width="2.5" stroke-linecap="round" d="M9 5l7 7-7 7"/></svg></button>').join('') + '</div>'
      + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="orClose(); if(typeof scFutureStory===\'function\') scFutureStory();">Quanti anni ti costa, se non cambi</button></div>';
  }
  el.innerHTML = '<div class="or-sheet">' + top + body + '</div>';
  /* la vignetta si batte a macchina solo la prima volta che compare */
  if ((OR.step === 'alexander' || OR.step === 'alexander2') && OR.twFatto !== orTwChiave()){
    const tw = document.getElementById('orTw');
    orScrivi(tw, OR.step === 'alexander' ? orAlexTesto() : orTestoLega(), function(){
      orVignPronta();
      const d = el.querySelector('.or-dopo'); if (d) d.classList.add('on');
    });
  } else if (OR.step !== 'alexander' && OR.step !== 'alexander2') orTwFerma();
}

registerOverlay('orWrap', '');
(function(){ const el = document.getElementById('orWrap'); if (el) el.hidden = true; })();

(function(){
  const css = [
    '#orWrap[hidden]{display:none}',
    '#orWrap{position:absolute;inset:0;z-index:72;background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C);color:#fff;overflow:auto}',
    '.or-sheet{min-height:100%;display:flex;flex-direction:column;padding:14px 18px 24px}',
    '.or-top{display:flex;align-items:center;justify-content:space-between;height:44px;flex:none}',
    '.or-top span{width:34px}',
    '.or-x{border:0;background:rgba(255,255,255,.1);color:#fff;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    /* la freccia sopra al pannello bianco, a sinistra: e' un passo indietro, non un'uscita */
    '.or-backrow{height:44px;display:flex;align-items:flex-end;padding:0 2px 6px}',
    /* niente backdrop-filter: su questa WebView lascia un rettangolo scuro attorno al cerchio */
    '.or-back{width:44px;height:44px;border-radius:50%;border:1px solid rgba(255,255,255,.28);background:rgba(255,255,255,.16);color:#fff;',
    '  display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.or-back:active{transform:scale(.94)}',
    '.or-n{font:700 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#9EC1FF}',
    /* la sfera: l'aura è la stessa della bolla della Modalità severa */
    '.or-ball{position:relative;width:150px;height:150px;margin:18px auto 0;display:flex;align-items:center;justify-content:center;border-radius:50%}',
    '.or-ball::before{content:"";position:absolute;inset:-14px;border-radius:50%;background:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(16px);opacity:.75;animation:spin 4s linear infinite}',
    '.or-ball.think::before{animation-duration:1.1s;opacity:1}',
    '.or-ball span{position:relative;font-size:104px;line-height:1;filter:drop-shadow(0 10px 24px rgba(0,0,0,.5))}',
    '.or-ball.think span{animation:orPulse 1.1s ease-in-out infinite}',
    '.or-genio img{position:relative;height:168px;width:auto;margin-top:-8px;filter:drop-shadow(0 12px 24px rgba(0,0,0,.5));animation:orGenioPop .38s cubic-bezier(.3,1.5,.5,1) both}',
    '.or-genio.think img{animation:orPulse 1.1s ease-in-out infinite}',
    '@keyframes orGenioPop{from{transform:scale(.88);opacity:.4}to{transform:none;opacity:1}}',
    '@keyframes orPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}',
    '.or-card{flex:1;margin-top:18px;background:#F6F8FC;color:var(--navy);border-radius:22px;padding:24px 20px;text-align:center}',
    '.or-q{margin:0;font:700 21px/1.4 var(--font-display);color:#0E2350}',
    '.or-card,.or-card p,.or-card b,.or-card small,.or-card li{color:#0E2350}',
    '.or-fatto{margin-top:18px;padding:18px 14px;border-radius:18px;background:#fff;border:1.5px solid #C9D6EA}.or-fatto b{display:block;font:900 44px/1 var(--font-display);color:#0075E3}.or-fatto small{display:block;margin-top:8px;font:600 14px/1.4 var(--font-body);color:#0E2350}',
    /* il trigger: righe intere, emoji a sinistra, spunta a destra — come nel primo onboarding */
    '.or-sub{margin:10px 0 0;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.or-trig{display:flex;flex-direction:column;gap:8px;margin-top:18px;text-align:left}',
    '.or-tr{display:flex;align-items:center;gap:12px;border:1.5px solid #C9D6EA;background:#fff;color:#0E2350;border-radius:14px;padding:12px 14px;cursor:pointer;font:inherit;transition:border-color .2s,box-shadow .2s,background .2s}',
    '.or-tr span{font-size:22px;line-height:1;flex:none}',
    '.or-tr b{flex:1;font:700 13.5px/1.35 var(--font-body)}',
    '.or-tr i{width:20px;height:20px;border-radius:50%;border:1.5px solid #C9D6EA;flex:none}',
    /* scelta = bordo azzurro con l'alone, e la spunta blu: uguale in tutte e due le modalita' */
    '.or-tr.on{border-color:#0075E3;background:#EEF4FF;box-shadow:0 0 0 3px rgba(0,117,227,.22)}',
    '.or-tr.on i{background:#0075E3;border-color:#0075E3;position:relative}',
    '.or-tr.on i::after{content:"";position:absolute;left:6px;top:2px;width:5px;height:10px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}',
    '.or-a[disabled]{opacity:.45;box-shadow:none;cursor:default}',
    /* «Non sono io»: deve esserci e non deve gridare. Un pulsante pieno sotto alla percentuale
       inviterebbe a smentire il risultato per curiosita'; una riga sottolineata la trova solo
       chi quel risultato l'ha letto e non ci si riconosce, che e' esattamente chi serve. */
    '.or-sbaglio{display:block;margin:16px auto 0;border:0;background:none;cursor:pointer;',
      'font:700 12px var(--font-body);color:rgba(120,150,190,.95);text-decoration:underline;',
      'text-underline-offset:3px}',
    '.or-scelte{display:flex;flex-direction:column;gap:8px;margin-top:18px;text-align:left}',
    '.or-scelta{display:flex;align-items:flex-start;gap:11px;width:100%;border:1.5px solid var(--line);',
      'border-radius:15px;background:var(--card,#fff);padding:12px;cursor:pointer;text-align:left}',
    '.or-scelta span{font-size:22px;line-height:1.1;flex:0 0 auto}',
    '.or-scelta b{display:block;font:800 13.5px var(--font-body);color:var(--navy)}',
    '.or-scelta small{display:block;margin-top:3px;font:500 11.5px/1.5 var(--font-body);color:var(--muted)}',
    '.or-known{list-style:none;margin:18px 0 0;padding:0;text-align:left}',
    '.or-known li{padding:12px 0;border-top:1px solid #DCE6F2;font:500 15px/1.5 var(--font-body);color:#0E2350}',
    '.or-known strong{font-weight:800}',
    /* i cinque pulsanti, nella griglia del genio: due sopra, tre sotto */
    '.or-grid{display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 1fr;gap:8px;margin-top:14px;flex:none}',
    '.or-grid .or-a:nth-child(1),.or-grid .or-a:nth-child(2){grid-column:span 3}',
    '.or-grid .or-a:nth-child(n+3){grid-column:span 2}',
    '.or-grid.one{grid-template-columns:1fr}.or-grid.one .or-a{grid-column:auto}',
    '.or-grid.off{opacity:.35;pointer-events:none}',
    '.or-a{border:0;border-radius:14px;background:linear-gradient(180deg,#E3F1FF,#BCE0FF);color:#0E2350;padding:17px 6px;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 4px 0 #7FB2E5,0 8px 18px rgba(0,0,0,.35)}',
    '.or-a:active{transform:translateY(3px);box-shadow:0 1px 0 #7FB2E5}',
    '.or-a.main{background:linear-gradient(90deg,#2F8BFF,#006FCF);color:#fff;box-shadow:0 4px 0 #004E8F,0 8px 18px rgba(0,0,0,.35)}',
    '.or-targets{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:18px}',
    '.or-t{border:2px solid var(--line);background:#fff;border-radius:16px;padding:14px 10px;text-align:center;cursor:pointer}',
    '.or-t.on{border-color:#006FCF;background:#EAF3FF}',
    '.or-t span{display:block;font-size:30px}',
    '.or-t b{display:block;margin-top:6px;font:800 13.5px/1.3 var(--font-body);color:var(--navy)}',
    '.or-t small{display:block;margin-top:3px;font:500 11px/1.35 var(--font-body);color:var(--muted)}',
    /* la rivelazione */
    '.or-reveal{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:10px 6px}',
    '.or-kick{display:block;font:700 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#9EC1FF}',
    '.or-who{font-size:88px;line-height:1;margin:22px 0 10px;filter:drop-shadow(0 10px 24px rgba(0,0,0,.5))}',
    '.or-name{margin:0;font:800 30px/1.15 var(--font-display);font-style:italic;color:#fff}',
    '.or-desc{margin:16px 0 0;max-width:22em;font:500 15px/1.6 var(--font-body);color:rgba(255,255,255,.82)}',
    '.or-pct{margin-top:28px;padding:18px 20px;border-radius:18px;background:rgba(255,255,255,.08)}',
    '.or-pct b{display:block;font:800 56px/1 var(--font-display);font-style:italic;color:#8CC6FF}',
    '.or-pct-chi{margin:14px 0 0;padding-top:14px;border-top:1px solid rgba(255,255,255,.14);font:500 14.5px/1.5 var(--font-body);color:rgba(232,241,255,.85)}.or-pct-chi b{display:inline!important;font:800 14.5px/1.5 var(--font-body)!important;font-style:normal!important;color:#fff!important}',
    '.or-pct b span{font-size:24px;margin-left:2px}',
    '.or-pct small{display:block;margin-top:8px;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.75)}',
    '.or-reveal.plan{justify-content:flex-start;padding-top:22px}',
    '.or-plan{width:100%;margin-top:22px;display:flex;flex-direction:column;gap:10px}',
    /* Carta chiara di proposito, inchiostro FISSO: `var(--navy)` di notte e' quasi bianco, e
       su questa carta spariva. Un colore che fa da inchiostro e da carta non regge un tema. */
    '.or-step{display:flex;align-items:center;gap:12px;width:100%;text-align:left;border:0;border-radius:18px;background:#F6F8FC;color:#0E2350;padding:16px 14px;cursor:pointer}',
    '.or-step i{flex:none;width:26px;height:26px;border-radius:50%;background:#0E2350;color:#fff;display:flex;align-items:center;justify-content:center;font:800 13px var(--font-body);font-style:normal}',
    '.or-step .ico{flex:none;font-size:24px}',
    '.or-step div{flex:1;min-width:0}',
    '.or-step b{display:block;font:800 15px/1.3 var(--font-body)}',
    '.or-step small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:#5B6B85}',
    '.or-step b{color:#0E2350}',
    '.or-step .chev{flex:none}',
    '.or-card.ask{display:flex;flex-direction:column;align-items:center;justify-content:center}',
    /* 0.9.304: il sogno confermato, la frase di Alexander, l'analisi. Carta chiara e inchiostro fisso come il resto */
    /* stretch, non center: il campo di testo (e l'involucro col microfono che gli mette attorno la dettatura) prende
       tutta la larghezza; il testo resta centrato con text-align */
    '.or-card.or-centro{display:flex;flex-direction:column;align-items:stretch;justify-content:center;gap:0;text-align:center}',
    '.or-pre{margin:0;font:600 14px/1.4 var(--font-body);color:#5B6B85}',
    '.or-card .or-pre{color:#5B6B85}',
    '.or-sogno{margin:12px 0 18px;font:800 26px/1.25 var(--font-display);font-style:italic;color:#0075E3;overflow-wrap:anywhere}',
    '.or-card .or-sogno{color:#0075E3}',
    '.or-grid.one .or-a+.or-a{margin-top:0}',
    '.or-a.or-scrivo{background:#fff;color:#0E2350;box-shadow:inset 0 0 0 1.5px #BCD3EE,0 6px 14px rgba(0,0,0,.25)}',
    '.or-a.or-scrivo:active{box-shadow:inset 0 0 0 1.5px #BCD3EE}',
    '.or-area{display:block;width:100%;box-sizing:border-box;margin-top:16px;border:1.5px solid #C9D6EA;border-radius:14px;background:#fff;color:#0E2350;',
    '  padding:12px 14px;font:500 15px/1.45 var(--font-body);resize:vertical;text-align:left}',
    '.or-area:focus{outline:none;border-color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.18)}',
    /* 0.9.306, Andrea: la frase in testo normale; in corsivo solo l'autore */
    '.or-cit{margin:0;font:700 20px/1.42 var(--font-display);font-style:normal;color:#0E2350}',
    '.or-aut{display:block;margin-top:12px;font:700 13px var(--font-body);font-style:italic;letter-spacing:.04em;color:#5B6B85}',
    /* le due vignette: tutta la scena si tocca; l'autore, la freccetta e il pulsante arrivano a frase finita */
    '.or-vign-w{flex:1;display:flex;flex-direction:column;justify-content:center;padding-bottom:24px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.or-vign{position:relative;flex:none;min-height:230px;padding-bottom:40px;box-sizing:border-box}',
    '#orTw{display:grid}#orTw>span{grid-area:1/1}.or-tw-o{visibility:hidden}',
    '.or-vign .or-aut{opacity:0;transition:opacity .5s}.or-vign.pronta .or-aut{opacity:1}',
    '.or-vign .or-lega{margin:0;padding:0;border:0;font:600 18px/1.55 var(--font-body)}',
    '.or-freccia{position:absolute;right:18px;bottom:14px;color:#0075E3;opacity:0;pointer-events:none}',
    '.or-vign.pronta .or-freccia{opacity:1;animation:orFreccia 1s ease-in-out infinite}',
    '@keyframes orFreccia{0%,100%{transform:translateY(0);opacity:.55}50%{transform:translateY(4px);opacity:1}}',
    'body.dark .or-card .or-freccia,body.dark .or-card .or-freccia *{color:#0075E3 !important}',
    /* 0.9.353, Andrea: "Tocca per continuare e' attaccato alla nuvoletta del Genio invece di stare in fondo: te l'ho detto, sempre in
       basso". Sta in fondo allo schermo, come negli episodi (.gn-tap) */
    '.or-tocca{position:fixed;left:0;right:0;bottom:calc(26px + env(safe-area-inset-bottom,0px));z-index:3;margin:0;text-align:center;font:700 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#8FA6C8;opacity:0;transition:opacity .4s;pointer-events:none}',
    '.or-vign.pronta + .or-tocca{opacity:1;animation:orTocca 1.8s ease-in-out infinite}',
    '@keyframes orTocca{0%,100%{opacity:.45}50%{opacity:1}}',
    '.or-dopo{opacity:0;pointer-events:none;transform:translateY(8px);transition:opacity .35s,transform .35s}.or-dopo.on{opacity:1;pointer-events:auto;transform:none}',
    '.or-card .or-aut{color:#5B6B85}',
    '.or-lega{margin:20px 0 0;padding-top:18px;border-top:1px solid #DCE6F2;font:600 15.5px/1.55 var(--font-body);color:#0E2350}',
    /* la persona del sogno in rosso: e' la cosa da ricordare (regola del contrasto, 28/10) */
    '.or-card .or-lega b{color:#E63946;font-weight:800}',
    '.or-ana{list-style:none;margin:16px 0 0;padding:0;width:100%;text-align:left}',
    '.or-ana li{display:flex;align-items:center;gap:12px;padding:11px 2px;border-top:1px solid #DCE6F2;font:600 14.5px/1.4 var(--font-body);color:#7A8AA6;transition:color .3s}',
    '.or-ana li i{flex:none;width:22px;height:22px;border-radius:50%;border:1.5px solid #C9D6EA;position:relative;transition:background .3s,border-color .3s}',
    '.or-ana li.on{color:#0E2350}',
    '.or-ana li.on i{background:#0075E3;border-color:#0075E3}',
    /* darkfix.js ridipinge di blu notte TUTTO l'inchiostro della carta (body.dark .or-card *): i due colori che
       contano tornano qui, con un selettore piu' preciso */
    'body.dark .or-card .or-lega b{color:#E63946 !important}',
    'body.dark .or-card .or-sogno{color:#0075E3 !important}',
    'body.dark .or-card .or-pre,body.dark .or-card .or-aut{color:#5B6B85 !important}',
    'body.dark .or-card .or-ana li:not(.on),body.dark .or-card .or-ana li:not(.on) *{color:#7A8AA6 !important}',
    '.or-ana li.on i::after{content:"";position:absolute;left:7px;top:3px;width:5px;height:10px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}',
    /* 0.9.305: le carte degli episodi dentro al foglio chiaro della lettura. La carta resta chiara anche al buio
       (il foglio e' chiaro di proposito, darkfix.js riporta scuro l'inchiostro): qui si tiene chiara anche la carta */
    '#orWrap .or-cards{margin-top:18px;text-align:center}',
    '#orWrap .gn-card{position:relative;background:#fff;border-color:#DCE8F5;color:#0E2350;font:inherit}',
    '#orWrap .gn-card b{color:#0E2350}#orWrap .gn-card small{color:#5B6B85}',
    '#orWrap .gn-card.on{border-color:#0075E3;background:#E3F1FF;transform:none;box-shadow:0 0 0 3px rgba(0,117,227,.18)}',
    /* la spunta blu della scelta fatta (il trigger ne vuole piu' di una) */
    '#orWrap .gn-card.on::after{content:"";position:absolute;top:8px;right:8px;width:18px;height:18px;border-radius:50%;background:#0075E3 url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27%3E%3Cpath d=%27M6 12.5l4 4 8-9%27 fill=%27none%27 stroke=%27%23fff%27 stroke-width=%273%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27/%3E%3C/svg%3E") center/12px no-repeat}',
    '#orWrap .gn-cards.or-mezzo .gn-card.tratt{grid-column:auto}',
    'body.dark #orWrap .gn-card{background:#fff !important;border-color:#DCE8F5 !important}',
    'body.dark #orWrap .gn-card.on{background:#E3F1FF !important;border-color:#0075E3 !important}',
    'body.dark #orWrap .gn-card b{color:#0E2350 !important}body.dark #orWrap .gn-card small{color:#5B6B85 !important}',
    '.or-sogno-e{display:block;font-size:42px;line-height:1;margin:10px 0 4px}',
    '.or-card-scelte{flex:none;margin-top:16px;padding:14px;width:100%;box-sizing:border-box}.or-card-scelte .or-cards{margin-top:0}',
    '.or-propo{margin:22px 0 0;font:700 15px/1.45 var(--font-body);color:#fff}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();

/* 0.9.374: il tabellone della lettura, sotto alla nuvoletta del Genio */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-vt{margin:22px 0 4px}'; document.head.appendChild(st); })();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-card:has(+ .or-vt){min-height:0!important;flex:none!important}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-card.or-qc{flex:none!important;min-height:0!important;position:relative;padding:22px 44px 22px 20px}'
  + '#orWrap .or-carta{margin-top:14px}#orWrap .or-carta .gn-cards{margin:0}'
  + '#orWrap .or-area-f{display:block;width:100%;box-sizing:border-box;margin:14px 0 0}'
  + '.or-q-blu{color:#0075E3!important}'
  + '.or-info{position:absolute;top:12px;right:12px;width:28px;height:28px;border-radius:50%;border:1.5px solid #8CC6FF;background:#F0FBFF;color:#0075E3;font:800 14px/1 var(--font-body);font-style:italic;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}'
  + '.or-info-e{display:block;font-size:40px;line-height:1;margin:6px 0 12px;text-align:center}.or-info-p{margin:0 0 26px;text-align:center;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '.or-ai-r{display:flex;align-items:flex-start;gap:14px;margin:0 0 18px;text-align:left}.or-ai-r > span{font-size:26px;line-height:1}.or-ai-r b{display:block;font:800 15.5px var(--font-display);color:var(--navy)}.or-ai-r small{display:block;margin-top:3px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}body.dark .or-ai-r b{color:#fff}.or-ai h3{margin-bottom:22px}'; document.head.appendChild(st); })();

/* i fatti della lettura (0.9.376): il pannello Dove va la tua attenzione, come nella revisione */
async function orDatiCarica(){
  try{
    const out = (typeof scPannelloHtml === 'function') ? await scPannelloHtml({ range: (typeof scRepRange === 'function' ? scRepRange() : '7d'), dove: 'or' }) : null;
    const pan = document.getElementById('orPan'); if (!pan || OR.step !== 'dati') return;
    /* 0.9.379, Andrea: "nella lettura, toccando il periodo o i tre puntini compare il velo scuro ma il menu no". Il pannello e' una copia
       di quello del Report, con gli stessi id: il tocco apriva il menu dell'altro pannello, nascosto. Qui i menu hanno id loro e scegliere
       una voce ridisegna questo pannello */
    if (out && out.html && !out.negato) pan.innerHTML = out.html.replace(/ onclick="(scTopTap|scOpenApp|scNotifSettings)\([^"]*\)"/g, '')
      .replace(/id="repMenu"/g, 'id="orRepMenu"').replace(/id="repRangeMenu"/g, 'id="orRepRangeMenu"').replace(/id="repScrim"/g, 'id="orRepScrim"')
      .replace(/scRepMenuToggle\(event[^)]*\)/g, "orPanMenu(event,'orRepMenu')").replace(/scRangeMenuToggle\(event[^)]*\)/g, "orPanMenu(event,'orRepRangeMenu')")
      .replace(/scRepSetRange\(/g, 'orPanRange(').replace(/scRepSetMetric\(/g, 'orPanMetric(').replace(/onclick="scMenusClose\(\)"/g, 'onclick="orPanMenuChiudi()"');
    else pan.innerHTML = '<p class="or-dati-att">Per vedere dove va la tua attenzione serve l’accesso ai dati di utilizzo.</p>';
  }catch(_){ const pan = document.getElementById('orPan'); if (pan) pan.innerHTML = '<p class="or-dati-att">Non riesco a leggere il telefono adesso.</p>'; }
}
/* 0.9.377, Andrea: "Le statistiche non sono pronte adesso: o sono pronte o non mostri il pulsante". La causa: si leggeva la cache grezza
   invece dei dati della partita (pstDati). Le statistiche nascono dal registro dei punti, che c'e' sempre: possesso, chi segna, quando */
function orStatHtml(){
  try{
    if (typeof pstDati !== 'function') return '';
    try{ if (typeof pstCarica === 'function') pstCarica(7).then(function(){ const s = document.getElementById('orStat'); if (s && OR.step === 'stat') s.innerHTML = orStatHtml0(); }); }catch(_){ }
    return orStatHtml0();
  }catch(_){ return ''; }
}
function orStatHtml0(){
  const D = pstDati(7);
  let h = '';
  try{ if (typeof pstPossessoHtml === 'function') h += pstPossessoHtml(D); }catch(_){ }
  try{ if (typeof nvpRiepilogoHtml === 'function') h += nvpRiepilogoHtml(); }catch(_){ }
  /* 0.9.378, Andrea: "l'esempio del calcio te l'avevo detto io, a te: non va a schermo. Non tutti amano il calcio" */
  return h;
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-ana-f{margin:22px 0 0;padding:0 8px;width:auto}#orWrap .or-ana-f li{border-top:0;padding:9px 0;color:rgba(232,241,255,.45)!important;font-size:16px}#orWrap .or-ana-f li.on{color:#fff!important}#orWrap .or-ana-f li i{border-color:rgba(255,255,255,.35)}#orWrap .or-ana-f li.on i{background:#1E9E6A;border-color:#1E9E6A}'
  + '#orWrap .or-dati{margin-top:14px;display:flex;flex-direction:column;gap:14px}#orWrap .or-dati-pan,#orWrap #orStat{background:#F6F8FC;border-radius:22px;padding:16px;color:#0E2350;text-align:left}#orWrap .or-dati-tre{background:linear-gradient(170deg,#0B2E5E,#001E44);border:1px solid rgba(140,198,255,.2);border-radius:22px;padding:16px;color:#fff}#orWrap .or-dati-tre .or-dati-k{color:#fff}'
  + '.or-dati-k{margin:0 0 10px;font:800 15px var(--font-display);color:#0E2350;text-align:center}.or-dati-att{margin:6px 0;font:500 14px/1.5 var(--font-body);color:#5B6B85;text-align:center}.or-dati-sc{margin:0 0 12px;text-align:center;font:600 14px var(--font-body);color:#5B6B85}.or-dati-sc b{font:800 22px var(--font-display);color:#0E2350;margin:0 6px}'
  + '.or-dati-stat{align-self:center;padding:10px 16px;border:0;background:none;color:#BCE0FF;font:700 15px var(--font-body);text-decoration:underline;text-underline-offset:4px;cursor:pointer}'; document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-genio.luce img{animation:gnLuce 1.3s ease-in-out infinite!important}#orWrap .or-dati{margin-top:14px;display:flex;flex-direction:column;gap:14px;background:none!important;padding:0!important}#orWrap #orStat{background:linear-gradient(170deg,#0B2E5E,#001E44)!important;border:1px solid rgba(140,198,255,.2);border-radius:22px;padding:16px!important;color:#fff}#orWrap #orStat .or-dati-att{color:#BCE0FF}#orWrap .or-dati-tre{background:linear-gradient(170deg,#0B2E5E,#001E44)!important;border:1px solid rgba(140,198,255,.2);border-radius:22px;padding:16px!important}#orWrap .or-dati > .or-dati-att{color:#BCE0FF}#orWrap .or-dati-stat{display:block;margin:16px auto 0}#orWrap .or-cit-genio{font-style:normal}'; document.head.appendChild(st); })();

/* 0.9.378: la nota della scelta multipla, la (i) del numero, l'emoji del profilo sempre alla stessa distanza dal nome, la carta
   d'identita' e il mantra da scegliere */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-q-nota{margin:10px 0 0;font:500 14.5px/1.4 var(--font-body);color:#5B6B85!important}'
  + '#orWrap .or-who{height:96px;display:flex;align-items:center;justify-content:center;font-size:78px;margin:22px 0 18px}'
  + '#orWrap .or-pct{position:relative;padding:22px 44px 20px}#orWrap .or-pct-i{top:12px;right:12px;background:rgba(255,255,255,.12);border-color:rgba(140,198,255,.5);color:#BCE0FF}#orWrap .or-pct small{font-size:14.5px;color:rgba(232,241,255,.85)}'
  + '#orWrap .or-id{margin-top:16px;display:flex;flex-direction:column;align-items:stretch}#orWrap .or-id-c{border-radius:22px;padding:16px 18px;text-align:left}'
  + '#orWrap .or-id-c.oggi{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14)}#orWrap .or-id-c.dom{background:linear-gradient(160deg,#0075E3,#001E44 80%);border:1px solid rgba(140,198,255,.35)}'
  + '#orWrap .or-id-k{margin:0 0 12px;font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}'
  + '#orWrap .or-id-r{display:flex;align-items:center;gap:14px}#orWrap .or-id-e{font-size:40px;line-height:1}#orWrap .or-id-r b{font:800 19px/1.25 var(--font-display);font-style:italic;color:#fff}'
  + '#orWrap .or-id-freccia{align-self:center;margin:8px 0;font:800 22px/1 var(--font-body);color:#8CC6FF}'
  + '#orWrap .or-id-mid{display:flex;gap:14px;align-items:center}#orWrap .or-id-foto{flex:none;width:72px;height:92px;border-radius:12px;background:#C8EFFD center 30%/cover;border:3px solid #fff;display:flex;align-items:center;justify-content:center}#orWrap .or-id-foto i{font-style:normal;font-size:34px}'
  + '#orWrap .or-id-dati{flex:1;min-width:0;display:flex;flex-direction:column}#orWrap .or-id-dati small{font:800 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}#orWrap .or-id-dati small:not(:first-child){margin-top:8px}#orWrap .or-id-dati b{margin-top:2px;font:700 14.5px/1.3 var(--font-body);color:#fff;overflow-wrap:anywhere}'
  + '#orWrap .or-id-chi{margin:14px 0 0;padding-top:14px;border-top:1px dashed rgba(140,198,255,.45);font:700 16px/1.45 var(--font-body);color:#fff}'
  + '#orWrap .or-mantre{margin-top:16px;display:flex;flex-direction:column;gap:10px}#orWrap .or-mantra{border:1.5px solid rgba(140,198,255,.3);background:rgba(255,255,255,.07);color:#fff;border-radius:18px;padding:16px;font:600 16px/1.45 var(--font-body);font-style:italic;text-align:center;cursor:pointer}'
  + '#orWrap .or-mantra.on{border-color:#3F9FF4;background:rgba(63,159,244,.22);box-shadow:0 0 0 3px rgba(63,159,244,.2)}'
  + '#orWrap .or-scrivo-l{display:block;margin:16px auto 0;border:0;background:none;color:#BCE0FF;font:700 15px var(--font-body);text-decoration:underline;text-underline-offset:4px;cursor:pointer}'; document.head.appendChild(st); })();

function orPanMenuChiudi(){
  ['orRepMenu', 'orRepRangeMenu'].forEach(function(k){ const e = document.getElementById(k); if (!e) return; e.hidden = true;
    if (e.classList.contains('fl-menu-fisso')){ e.classList.remove('fl-menu-fisso'); e.style.left = ''; e.style.top = ''; if (e._casa && document.contains(e._casa)) e._casa.appendChild(e); } });
  const v = document.getElementById('orRepVeil'); if (v) v.remove();
}
function orPanMenu(ev, id){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const m = document.getElementById(id); if (!m) return;
  const aperto = !m.hidden; orPanMenuChiudi(); if (aperto) return;
  m.hidden = false;
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const v = document.createElement('div'); v.id = 'orRepVeil'; v.className = 'arb-veil'; v.style.zIndex = '10040';
  v.addEventListener('click', function(e){ e.stopPropagation(); orPanMenuChiudi(); });
  casa.appendChild(v);
  m._casa = m.parentElement;
  const btn = (ev && ev.currentTarget) || (m._casa && m._casa.querySelector(id === 'orRepRangeMenu' ? '.rep-rangebtn,.rep-range' : '.rep-more'));
  if (typeof flMenuFissa === 'function') flMenuFissa(m, btn);
  m.style.zIndex = '10041';
}
function orPanRange(r){ orPanMenuChiudi(); try{ scRepSetRange(r); }catch(_){ } orDatiCarica(); }
function orPanMetric(k){ orPanMenuChiudi(); try{ scRepSetMetric(k); }catch(_){ } orDatiCarica(); }

/* 0.9.379, Andrea: "alla fine della lettura non dice su cosa lavorare: solo la percentuale e da dove arriva, senza dire come alzarla". La
   diagnosi: il mantra scelto, l'azione che capovolge il freno, e l'ambiente (la stanza in cui passi piu' tempo) */
const OR_AZIONE_FRENO = {
  dispersione: 'Una sessione di Full Focus al giorno, con il telefono in un’altra stanza.',
  tempo: 'Blocca la prima ora della giornata per il tuo sogno, prima di aprire qualsiasi app.',
  paura: 'Fai ogni giorno il passo più piccolo, anche di cinque minuti.',
  valore: 'Segna ogni sera una cosa che hai fatto per il tuo sogno.',
  passato: 'Ogni mattina scegli una sola cosa da fare oggi, senza guardare indietro.',
  sguardi: 'Fai una tappa al giorno senza dirlo a nessuno, finché non diventa abitudine.',
  denaro: 'Scegli un investimento piccolo su di te e fissalo nel calendario.',
  imparare: 'Comincia oggi la prima tappa, anche se non ti senti pronto.'
};
function orDiagnosiHtml(){
  const k = orFreno();
  let mantra = ''; try{ const v = (typeof m369Leggi === 'function') ? m369Leggi() : null; const m = v && v.lista && v.lista.filter(function(x){ return x && x.id === v.scelto; })[0]; mantra = m ? m.t : ''; }catch(_){ }
  if (!mantra) mantra = orMantraTesto();
  let luogo = ''; try{ const l = (typeof pscLuoghi === 'function') ? pscLuoghi() : []; const top = l.slice().sort(function(a, b){ return (+b.ore || 0) - (+a.ore || 0); })[0]; luogo = top ? top.nome : ''; }catch(_){ }
  const riga = function(e, t, s, go){ return '<button type="button" class="or-dg-r"' + (go ? ' onclick="' + go + '"' : '') + '><span aria-hidden="true">' + e + '</span><div><b>' + t + '</b><small>' + esc(s) + '</small></div></button>'; };
  return orBall(false)
    + '<div class="or-card or-qc"><p class="or-q">Ecco su cosa lavorare per alzare il tuo numero.</p></div>'
    + '<div class="or-dg">'
    +   riga('🦋', 'Ripeti ogni giorno', '"' + mantra + '"', '')
    +   riga('⚡', 'Fai ogni giorno', OR_AZIONE_FRENO[k] || OR_AZIONE_FRENO.dispersione, '')
    +   riga('🏠', 'Cambia il tuo ambiente', luogo ? 'In ' + luogo + ' togli una cosa che ti porta lontano dal sogno e mettine una che te lo ricorda.' : 'Segna i posti in cui passi più tempo e le cose che ti portano lontano dal sogno.', '')
    + '</div>'
    + '<div class="or-grid one"><button type="button" class="or-a main" onclick="OR.step=\'ricalcola\';orPaint()">Continua</button></div>';
}
/* 0.9.379, Andrea: "toccando la X esce subito e si perdono le risposte: chiedi se e' sicuro. E rientrando: vuoi riprendere da dove eri
   rimasto o ricominciare da capo?". La lettura in corso si salva a ogni passo (fl_or_bozza, un giorno al massimo) */
const OR_BOZZA = 'fl_or_bozza';
const OR_PASSI_FINE = { reveal: 1, identikit: 1, mantra: 1, mantraOgni: 1, pano: 1, diagnosi: 1, ricalcola: 1, plan: 1, fatto: 1, correggi: 1 };
function orInCorso(){ return OR.on && OR.n > 0 && !OR_PASSI_FINE[OR.step]; }
function orBozzaSalva(){
  if (!orInCorso()) return;
  try{ localStorage.setItem(OR_BOZZA, JSON.stringify({ at: Date.now(), step: OR.step === 'think' ? 'ask' : OR.step, n: OR.n, post: OR.post, asked: OR.asked, answers: OR.answers, q: OR.q ? OR.q.id : '', trigger: OR.trigger, triggerTesto: OR.triggerTesto || '', trigFatto: !!OR.trigFatto, idFatta: !!OR.idFatta, idChiesta: !!OR.idChiesta, freni: OR.freni || {}, sbagli: OR.sbagli || 0, knownFatti: !!OR.knownFatti })); }catch(_){ }
}
function orBozza(){ try{ const b = JSON.parse(localStorage.getItem(OR_BOZZA) || 'null'); return (b && b.n > 0 && Date.now() - b.at < 86400000) ? b : null; }catch(_){ return null; } }
function orBozzaVia(){ try{ localStorage.removeItem(OR_BOZZA); }catch(_){ } }
function orChiudiChiedi(){
  if (!orInCorso() || typeof inSheet !== 'function'){ orClose(); return; }
  orBozzaSalva();
  inSheet('<div class="en-foglio or-esci"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Vuoi uscire dalla lettura?</h3>'
    + '<p class="or-info-p">Hai risposto a ' + OR.n + (OR.n === 1 ? ' domanda' : ' domande') + '. Le tengo da parte: quando torni puoi riprendere da qui.</p>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Resto nella lettura</button>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi();orClose()">Esco</button></div>');
}
function orRiprendi(){
  const b = orBozza(); if (!b){ return; }
  try{ inSheetChiudi(); }catch(_){ }
  OR.post = b.post; OR.asked = b.asked || []; OR.answers = b.answers || {}; OR.n = b.n; OR.trigger = b.trigger || OR.trigger; OR.triggerTesto = b.triggerTesto || '';
  OR.trigFatto = b.trigFatto; OR.idFatta = b.idFatta; OR.idChiesta = b.idChiesta; OR.freni = b.freni || {}; OR.sbagli = b.sbagli || 0; OR.knownFatti = true; OR.hist = [];
  OR.q = OR_Q.filter(function(x){ return x.id === b.q; })[0] || null;
  if (b.step === 'ask' && !OR.q){ OR.n--; orAsk(); return; }
  OR.step = b.step; orPaint();
}
function orRicomincia(){ orBozzaVia(); try{ inSheetChiudi(); }catch(_){ } }
(function(){
  if (typeof orPaint !== 'function') return;
  const p0 = orPaint;
  orPaint = window.orPaint = function(){ const r = p0.apply(this, arguments); try{ if (OR_PASSI_FINE[OR.step]) orBozzaVia(); else orBozzaSalva(); }catch(_){ } return r; };
  const o0 = orOpen;
  orOpen = window.orOpen = async function(){
    const b = orBozza();
    const r = await o0.apply(this, arguments);
    if (b && typeof inSheet === 'function'){
      inSheet('<div class="en-foglio or-esci"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Riprendi la lettura?</h3>'
        + '<p class="or-info-p">L’ultima volta eri arrivato alla domanda ' + b.n + '.</p>'
        + '<button type="button" class="en-cta" onclick="orRiprendi()">Riprendi da dove ero rimasto</button>'
        + '<button type="button" class="am-link" onclick="orRicomincia()">Ricomincio da capo</button></div>');
    }
    return r;
  };
})();
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  /* 0.9.379, Andrea: "il bagliore rosso e blu nella lettura non mi piace: quando legge le tue abitudini il Genio ha una luce intorno, come
     nell'intro". Niente aura colorata dietro al Genio; la luce bianca-azzurra quando legge */
  '#orWrap .or-ball.or-genio::before{display:none!important}#orWrap .or-genio img{filter:drop-shadow(0 12px 24px rgba(0,0,0,.45))}#orWrap .or-genio.luce img{animation:gnLuce 1.3s ease-in-out infinite!important}'
  + '#orWrap .or-ana-f li.on i{background:#1E9E6A!important;border:2px solid #9BE3C2!important;box-shadow:0 0 0 3px rgba(30,158,106,.25)}'
  + '#orWrap .or-a.or-gia{background:#0075E3!important;color:#fff!important;border-color:#0075E3!important;box-shadow:0 0 0 3px rgba(0,117,227,.25)}'
  + '#orWrap .or-dg{margin-top:16px;display:flex;flex-direction:column;gap:10px}#orWrap .or-dg-r{display:flex;align-items:flex-start;gap:14px;padding:16px;border-radius:18px;border:1px solid rgba(140,198,255,.25);background:rgba(255,255,255,.07);color:#fff;text-align:left;font:inherit}'
  + '#orWrap .or-dg-r > span{font-size:28px;line-height:1}#orWrap .or-dg-r b{display:block;font:800 15.5px var(--font-display);color:#fff}#orWrap .or-dg-r small{display:block;margin-top:4px;font:500 14px/1.45 var(--font-body);color:rgba(232,241,255,.85)}'
  + '.or-esci h3{text-align:center}.or-esci .am-link{display:block;margin:12px auto 0}'
  /* la (i) come quella della combinazione segreta: in corsivo, centrata */
  + '#orWrap .or-info{padding:0 1px 0 0!important}'; document.head.appendChild(st); })();

/* ---------- 0.9.381: il mantra spiegato, la sua cadenza, e le mosse che aspettano nella scheda Identita' ----------
   Andrea: "dici che lo trovi nel Mantra 3-6-9, ma il 3-6-9 e' il metodo di Nikola Tesla: uno puo' scegliere anche il mantra normale, che
   compare sullo schermo nei minuti che sceglie lui. Devi spiegarglielo e chiedergli ogni quanto vuole vederlo". E: "le tre mosse subito
   dopo tutte quelle domande sono troppo: ricalcola e basta, le mosse mettile sotto a chi devi diventare, nella scheda Identita'". */
function orMantraInfo(){
  if (typeof inSheet !== 'function') return;
  const righe = [['🦋', 'Perché un mantra', 'Ripetere ogni giorno chi vuoi diventare cambia le scelte che fai senza pensarci.'],
    ['📱', 'Dove lo vedi', 'Compare per qualche secondo sopra qualsiasi app, ogni quanto scegli tu.'],
    ['⚡', 'Il Metodo 3-6-9', 'Se preferisci, lo ripeti 3, 6 e 9 volte in tre momenti della giornata, come faceva Nikola Tesla.']];
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il tuo mantra</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe(righe) : righe.map(function(r){ return '<p class="or-info-p">' + r[0] + ' ' + r[2] + '</p>'; }).join(''))
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
const OR_MANTRA_OGNI = [['⏱️', 'Ogni 30 minuti', 30], ['🕐', 'Ogni ora', 60], ['🕑', 'Ogni due ore', 120], ['⚡', 'Con il Metodo 3-6-9', -369]];
function orMantraOgniHtml(){
  return orBall(false)
    + '<div class="or-card or-qc"><p class="or-q">Ogni quanto vuoi vedere la tua frase sullo schermo?</p>'
    + '<button type="button" class="or-info" onclick="event.stopPropagation();orMantraInfo()" aria-label="Come funziona il mantra">i</button></div>'
    + '<p class="or-mantra-cit">"' + esc(OR.mantraT || '') + '"</p>'
    + '<div class="gn-carta or-carta">' + orCarteHtml(OR_MANTRA_OGNI.map(function(o){ return { e: o[0], l: o[1], click: 'orMantraOgni(' + o[2] + ')' }; }), null) + '</div>'
    + '<p class="or-mantra-nota">Puoi cambiarlo quando vuoi nella pagina Personalizza.</p>';
}
function orMantraOgni(min){
  try{
    if (min === -369){
      if (typeof m369Leggi === 'function'){ const v = m369Leggi(); v.on = true; m369Salva(v); }
    } else {
      localStorage.setItem('fl_mantra_min', String(min));
      if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ mantraEveryMin: min, mantraText: OR.mantraT || '' });
    }
  }catch(_){ }
  try{ flVibra(10); }catch(_){ }
  OR.step = (typeof pscTreHtml === 'function') ? 'pano' : 'ricalcola'; orPaint();
}
const OR_MOSSE_K = 'fl_or_mosse';
async function orRicalcolaSi(){
  let plan = [];
  try{ plan = await orBuildPlan(); }catch(_){ plan = []; }
  try{ localStorage.setItem(OR_MOSSE_K, JSON.stringify({ at: Date.now(), l: plan.map(function(s){ return { ico: s.ico, t: s.t, s: s.s, go: s.go }; }) })); }catch(_){ }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  OR.step = 'fatto'; orPaint();
}
function orMosse(){ try{ const v = JSON.parse(localStorage.getItem(OR_MOSSE_K) || 'null'); return v && Array.isArray(v.l) ? v.l : []; }catch(_){ return []; } }
/** Le mosse per diventare chi vuoi, sotto alla carta d'identita' della scheda Identita'. */
function orMosseHtml(){
  const l = orMosse(); if (!l.length) return '';
  return '<div class="or-mosse"><p class="psc-io-k">Le mosse per diventarlo</p><p class="or-mosse-s">Una alla volta, nell’ordine.</p>'
    + l.map(function(s, i){ return '<button type="button" class="or-mossa" onclick="' + String(s.go || '').replace(/"/g, '&quot;') + '"><i>' + (i + 1) + '</i><span aria-hidden="true">' + s.ico + '</span><div><b>' + s.t + '</b><small>' + s.s + '</small></div></button>'; }).join('') + '</div>';
}
function orGoMemento(){
  orClose();
  try{ if (typeof ACC_TAB !== 'undefined') ACC_TAB = 'timeline'; }catch(_){ }
  try{ if (typeof profileAuth === 'function') profileAuth(); }catch(_){ }
  setTimeout(function(){ try{ if (typeof accTab === 'function') accTab('timeline'); const b = document.getElementById('accTabs'); if (b) b.scrollIntoView({ block: 'start', behavior: 'smooth' }); }catch(_){ } }, 450);
}
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '#orWrap .or-mantra-cit{margin:18px 8px 0;text-align:center;font:italic 700 17px/1.45 var(--font-display);color:#BFE0FF}'
  + '#orWrap .or-mantra-nota{margin:14px 0 0;text-align:center;font:500 13.5px var(--font-body);color:rgba(232,241,255,.7)}'
  /* la spunta al centro del pallino verde, come nell'intro */
  + '#orWrap .or-ana li i{box-sizing:border-box}#orWrap .or-ana li.on i::after{left:50%!important;top:46%!important;width:5px;height:10px;transform:translate(-50%,-60%) rotate(45deg)!important}'
  + '.or-mosse{margin-top:22px}.or-mosse-s{margin:4px 0 12px;font:500 13.5px var(--font-body);color:var(--muted,#64748B);text-align:center}'
  + '.or-mossa{display:flex;align-items:flex-start;gap:12px;width:100%;text-align:left;padding:14px;margin-top:10px;border-radius:16px;border:1px solid var(--line,#DCE6F2);background:var(--card,#fff);color:var(--ink,#0E2350);font:inherit;cursor:pointer}'
  + '.or-mossa i{flex:none;width:24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:800 13px/24px var(--font-body);font-style:normal;text-align:center}'
  + '.or-mossa > span{font-size:22px;line-height:1}.or-mossa b{display:block;font:800 15px/1.3 var(--font-display)}.or-mossa small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#64748B)}';
  document.head.appendChild(st); })();

(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent = '#orWrap .or-fatto-c{flex:none!important}#orWrap .or-fatto-c .or-sub{margin-top:10px}.psc-io .or-mosse-s{color:rgba(200,225,255,.78)!important}.psc-io .or-mosse .psc-io-k{color:#8CC6FF}'; document.head.appendChild(st); })();
