/* ===========================================================================================
   LE SCENE A SCORRIMENTO DEGLI EPISODI (0.9.344)

   Andrea: "la serie e' monotona, sempre il Genio che fa domande a carte. Varia il MEZZO con cui si
   racconta, usando le sezioni del mio tema Shopify come modello". Un passo di content/episodi.json
   scritto cosi':
       { "tipo": "scroll", "stile": "rivela" | "storia" | "parallasse" | "carosello" | "nuvole", ... }
   apre una scena a tutto schermo: si scorre col dito e la scena avanza, in fondo compare il pulsante
   che riporta all'episodio. Ogni stile ricalca una sezione del tema (struttura, tempi, easing):
     rivela      scroll-text-reveal.liquid        il testo si accende parola per parola
     storia      scroll-story.liquid              intro, titolo che si allontana, testo che sale in prospettiva,
                                                  l'aeroplanino che attraversa e lascia la frase finale come scia
     parallasse  GSAP-parallax-scrolling.liquid   si entra nella finestra (scala 5), poi i pannelli salgono
     carosello   3D-CURVED-slider-carousel.liquid le carte sull'arco (stessa formula), mosse dallo scorrimento
     nuvole      dreamland-journey-ATMOS.liquid   il volo fra le nuvole: e' atmPasso di dream-atmos.js, riusato

   LE REGOLE DELL'APP, PERCHE' NON SI RIFACCIA
   · GSAP e ScrollTrigger stanno in js/vendor (l'app gira senza rete) e si caricano SOLO quando serve la prima
     scena: all'avvio non pesano. Alla chiusura ScrollTrigger si spegne (disable): niente ascoltatori in giro.
   · Lo scroller e' il contenitore della scena (#scnG), non window. Il palco resta fermo con position:sticky
     (in un contenitore interno il "pin" di ScrollTrigger sposta il palco con un transform a ogni scroll: su
     Android trema); ScrollTrigger fa solo lo scrub della timeline.
   · Si animano solo transform e opacity (memoria dello scroll a scatti, 0.9.262-268). Nessuna misura letta
     mentre si scorre: le misure si prendono quando la scena si monta e al resize.
   · prefers-reduced-motion: la scena diventa una pagina ferma da leggere, con il pulsante in fondo.
   · Mentre la scena e' aperta l'episodio sotto e' nascosto e le sue animazioni sono in pausa.
   Prefisso scn-.
   =========================================================================================== */
const SCN = { el: null, ctx: null, carico: null, mosso: false, alFine: false, onRes: null };

function scnEsc(s){ return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
/** Il testo di un passo con i dati veri dell'episodio ({sogno}, {sabotatore}...): se un dato manca, alt o vuoto. */
function scnT(t, alt){
  if (!t) return alt || '';
  try{ if (typeof epiRiempi === 'function'){ const r = epiRiempi(t, alt); return r == null ? '' : r; } }catch(_){ }
  return String(t);
}
function scnB(t, alt){ return scnEsc(scnT(t, alt)).replace(/\*([^*]+)\*/g, '<b>$1</b>'); }
function scnUi(k, dflt){ try{ const v = (typeof epiUi === 'function') ? epiUi(k) : ''; return v || dflt; }catch(_){ return dflt; } }
function scnFermo(){ try{ return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); }catch(_){ return false; } }
function scnAperta(){ return !!document.getElementById('scnG'); }

/* ---------------------------------------------------------------- GSAP, solo quando serve */
function scnCaricaGsap(){
  if (window.gsap && window.ScrollTrigger) return Promise.resolve(true);
  if (SCN.carico) return SCN.carico;
  const uno = function(src){
    return new Promise(function(ok, no){
      const s = document.createElement('script'); s.src = src; s.onload = function(){ ok(true); }; s.onerror = function(){ no(new Error(src)); };
      document.head.appendChild(s);
    });
  };
  SCN.carico = uno('js/vendor/gsap.min.js').then(function(){ return uno('js/vendor/ScrollTrigger.min.js'); })
    .then(function(){
      gsap.registerPlugin(ScrollTrigger);
      try{ ScrollTrigger.config({ ignoreMobileResize: true }); }catch(_){ }
      /* acceso solo mentre una scena e' aperta */
      if (!scnAperta()) try{ ScrollTrigger.disable(false, true); }catch(_){ }
      return true;
    })
    .catch(function(){ SCN.carico = null; return false; });
  return SCN.carico;
}
/** L'episodio che sta per aprirsi ha una scena a scorrimento: le librerie si leggono subito, in sottofondo. */
function scnPrepara(){ if (!scnFermo()) scnCaricaGsap(); }

/* ---------------------------------------------------------------- aprire e chiudere */
function scnChiudi(){
  const w = document.getElementById('scnG');
  try{ if (SCN.ctx) SCN.ctx.revert(); }catch(_){ }
  SCN.ctx = null;
  try{
    if (window.ScrollTrigger){
      ScrollTrigger.getAll().forEach(function(t){ t.kill(); });
      ScrollTrigger.disable(false, true);
    }
  }catch(_){ }
  if (SCN.onRes){ try{ removeEventListener('resize', SCN.onRes); }catch(_){ } SCN.onRes = null; }
  if (w) w.remove();
  SCN.el = null; SCN.mosso = false; SCN.alFine = false; SCN.carte = null; SCN.carPos = 0; SCN.carIdx = -1;
  try{ const sg = document.getElementById('s-genio'); if (sg) sg.classList.remove('scn-sotto'); }catch(_){ }
}
function scnAvanti(){ scnChiudi(); try{ if (typeof epiAvanti === 'function') epiAvanti(); }catch(_){ } }
function scnEsci(){ scnChiudi(); try{ if (typeof epiChiudi === 'function') epiChiudi(); }catch(_){ } }
/* se sotto cambia schermata (un avviso che porta altrove, il tasto indietro) la scena non resta appesa */
document.addEventListener('fl:screen', function(e){ try{ if (scnAperta() && e && e.detail !== 's-genio') scnChiudi(); }catch(_){ } });

const SCN_X = '<button type="button" class="scn-x" onclick="event.stopPropagation();scnEsci()" aria-label="Chiudi">✕</button>';
const SCN_GIU = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 14l6-6 6 6"/></svg>';
function scnAereo(){
  if (typeof ATM_AEREO !== 'undefined') return ATM_AEREO;
  return '<svg viewBox="0 0 120 120" aria-hidden="true"><path d="M8 58 112 10 78 108 56 70z" fill="#fff"/><path d="M56 70 112 10 66 92z" fill="#C8EFFD"/></svg>';
}

/* ---------------------------------------------------------------- i quattro stili */
/** Il testo spezzato in parole, una per span. Le parole fra *asterischi* prendono l'azzurro. */
function scnParole(t){
  let acc = false, out = '';
  String(t || '').split('\n').forEach(function(riga, k){
    if (k) out += '<span class="scn-br"></span>';
    riga.split(/\s+/).filter(Boolean).forEach(function(w0){
      const n = (w0.match(/\*/g) || []).length;
      const qui = acc || w0.charAt(0) === '*';
      if (n % 2) acc = !acc;
      const w = w0.replace(/\*/g, '');
      if (w) out += '<span class="scn-w' + (qui ? ' acc' : '') + '">' + scnEsc(w) + '</span> ';
    });
  });
  return out;
}
/* stelle ferme disegnate con una sola ombra a punti: tre strati che brillano, non ottocento elementi */
function scnStelle(){
  let h = '';
  for (let s = 0; s < 3; s++){
    const om = [];
    for (let i = 0; i < 18; i++){
      const x = (i * 37 + s * 53 + (i * i * 7) % 29) % 100, y = (i * 61 + s * 31 + (i * i * 3) % 41) % 100;
      om.push(x + 'vw ' + y + 'vh 0 ' + ((i + s) % 4 === 0 ? '1px' : '0') + ' #fff');
    }
    h += '<i style="box-shadow:' + om.join(',') + ';animation-duration:' + (5 + s * 2.5) + 's;animation-delay:-' + (s * 1.7) + 's"></i>';
  }
  return '<div class="scn-stelle" aria-hidden="true">' + h + '</div>';
}

const SCN_STILI = {
  /* ------------------------------------------------------------ scroll-text-reveal.liquid */
  rivela: {
    scrub: 0.8,
    lungo: function(){ return 350; },                       /* il tema: end "+=250%" */
    html: function(p){
      return '<div class="scn-riv">' + scnStelle()
        + (p.occhiello ? '<small class="scn-occhiello">' + scnEsc(scnT(p.occhiello)) + '</small>' : '')
        + '<h2 class="scn-riv-t">' + scnParole(scnT(p.testo, p.alt)) + '</h2>'
        + (p.firma ? '<p class="scn-riv-firma">' + scnB(p.firma) + '</p>' : '') + '</div>';
    },
    anima: function(tl, w){
      const parole = w.querySelectorAll('.scn-w'), n = parole.length, firma = w.querySelector('.scn-riv-firma');
      /* il tema: opacita' 1, stagger 0.1, durata 3, ease none. Con un testo corto la durata scende in proporzione */
      const dur = n >= 40 ? 3 : Math.max(0.6, 3 * n / 45);
      tl.to(parole, { opacity: 1, stagger: 0.1, duration: dur, ease: 'none' });
      /* il tema, dopo il testo, fa salire il pulsante: opacita' 1, y 0, durata 1, power2.out */
      if (firma) tl.to(firma, { opacity: 1, y: 0, duration: 1, ease: 'power2.out' });
      tl.to({}, { duration: 0.5 });
    },
    fermo: function(p){ return [{ o: scnT(p.occhiello), t: scnT(p.testo, p.alt), s: scnT(p.firma) }]; }
  },

  /* ------------------------------------------------------------ scroll-story.liquid */
  storia: {
    scrub: 1,
    lungo: function(p){ return 400 + Math.max(0, (p.righe || []).length - 4) * 45; },   /* il tema: height 400vh */
    html: function(p){
      return '<div class="scn-st">' + scnStelle()
        + '<div class="scn-st-nave"><span>' + scnAereo() + '</span></div>'
        + '<div class="scn-st-intro"><p>' + scnB(p.intro) + '</p></div>'
        + '<div class="scn-st-titolo"><b>' + scnEsc(scnT(p.titolo)) + '</b></div>'
        + '<div class="scn-st-crawl"><div class="scn-st-righe">' + (p.righe || []).map(function(r){ return '<p>' + scnB(r) + '</p>'; }).join('') + '</div></div>'
        + '<div class="scn-st-outro"><div class="scn-st-scia"><b>' + scnEsc(scnT(p.outro)) + '</b></div></div>'
        + '</div>';
    },
    anima: function(tl, w){
      const palco = w.querySelector('.scn-palco'), nave = w.querySelector('.scn-st-nave');
      const intro = w.querySelector('.scn-st-intro'), titolo = w.querySelector('.scn-st-titolo');
      const crawl = w.querySelector('.scn-st-crawl'), righe = w.querySelector('.scn-st-righe');
      const scia = w.querySelector('.scn-st-scia'), frase = scia.querySelector('b');
      const W = function(){ return palco.clientWidth; }, H = function(){ return palco.clientHeight; };
      /* i tempi sono quelli del tema: 0.3 la nave parte, 0.8 il titolo, 1.8-5.3 il testo che sale, 5.3 la frase finale.
         Come vuole Andrea la nave va dove punta il muso: gira di 180 gradi e scende, poi rientra da sinistra con il
         muso a destra, e la frase finale e' la sua scia. */
      tl.to(nave, { rotation: 180, duration: 0.3, ease: 'power1.inOut' }, 0)
        .to(nave, { y: function(){ return H() * 0.34; }, duration: 0.4, ease: 'power1.in' }, 0.3)
        .to(intro, { opacity: 0, duration: 0.5 }, 0.3)
        .fromTo(titolo, { opacity: 0, scale: 1.2 }, { opacity: 1, scale: 1.2, duration: 0.2 }, 0.8)
        .to(titolo, { scale: 0.1, opacity: 0, duration: 0.6, ease: 'power2.in' }, 1.2)
        .to(crawl, { opacity: 1, duration: 0.4 }, 1.8)
        /* il tema muove "top" fino a -950%: qui e' un transform, lungo quanto serve perche' passi tutto il testo */
        .to(righe, { y: function(){ return -(righe.offsetHeight + crawl.offsetHeight); }, duration: 3.5, ease: 'none' }, 1.8)
        .set(nave, { rotation: 90, x: function(){ return -0.75 * W(); }, y: function(){ return -(H() * 0.33 - 32); } }, 5.28)
        .to(nave, { x: function(){ return 1.2 * W(); }, duration: 3, ease: 'none' }, 5.3)
        /* la scia: la finestra si apre da sinistra a destra dietro alla coda (due transform opposti, niente maschere) */
        .fromTo(scia, { xPercent: -101 }, { xPercent: 0, duration: 1.29, ease: 'none' }, 5.93)
        .fromTo(frase, { xPercent: 101 }, { xPercent: 0, duration: 1.29, ease: 'none' }, 5.93);
    },
    fermo: function(p){
      return [{ t: scnT(p.intro) }, { t: scnT(p.titolo) }].concat((p.righe || []).map(function(r){ return { s: scnT(r) }; })).concat([{ t: scnT(p.outro) }]);
    }
  },

  /* ------------------------------------------------------------ GSAP-parallax-scrolling.liquid */
  parallasse: {
    scrub: true,
    lungo: function(p){ return 100 + (1 + (p.livelli || []).length) * 100 + 30; },   /* il tema: end "+=200%" con due pannelli */
    html: function(p){
      const col = ['blu', 'chiaro', 'rosso', 'notte'];
      const vis = (typeof epiVisHtml === 'function') ? epiVisHtml(p.vis || 'sfera') : '';
      return '<div class="scn-plx"><div class="scn-plx-hero">' + scnStelle() + vis + '</div>'
        + (p.livelli || []).map(function(l, i){
          const c = col.indexOf(l.colore) >= 0 ? l.colore : col[i % col.length];
          return '<section class="scn-plx-p c-' + c + '" style="z-index:' + (i === 0 ? 2 : 4 + i) + '"><h2>' + scnB(l.t) + '</h2>' + (l.s ? '<p>' + scnB(l.s) + '</p>' : '') + '</section>';
        }).join('')
        + '<div class="scn-plx-fin"><div class="scn-plx-vetro">' + (p.titolo ? '<h2>' + scnB(p.titolo) + '</h2>' : '') + '</div></div></div>';
    },
    anima: function(tl, w){
      const vetro = w.querySelector('.scn-plx-vetro'), hero = w.querySelector('.scn-plx-hero'), pann = w.querySelectorAll('.scn-plx-p');
      gsap.set(pann, { yPercent: 100 });
      /* il tema: la finestra scala 5 con z 305, lo sfondo 2.4 sul telefono, power1.inOut; poi i pannelli salgono, ease none */
      tl.to(vetro, { scale: 5, z: 305, transformOrigin: '50% 42%', ease: 'power1.inOut', duration: 1 })
        .to(hero, { scale: 2.4, transformOrigin: '50% 42%', ease: 'power1.inOut', duration: 1 }, '<');
      pann.forEach(function(el){ tl.to(el, { yPercent: 0, ease: 'none', duration: 1 }); });
      tl.to({}, { duration: 0.3 });
    },
    fermo: function(p){ return [{ t: scnT(p.titolo) }].concat((p.livelli || []).map(function(l){ return { t: scnT(l.t), s: scnT(l.s) }; })); }
  },

  /* ------------------------------------------------------------ 3D-CURVED-slider-carousel.liquid */
  carosello: {
    scrub: 0.6,
    lungo: function(p){ return 130 + Math.max(1, (p.carte || []).length - 1) * 62; },
    /* dove la scena si ferma volentieri: una carta al centro (scroll-snap del browser, solo "proximity": non trattiene) */
    tappe: function(p){
      const n = (p.carte || []).length, out = [];
      for (let i = 0; i < n; i++) out.push(i / (Math.max(1, n - 1) + 0.35));
      out.push(1);
      return out;
    },
    html: function(p){
      const carte = p.carte || [];
      return '<div class="scn-car">' + scnStelle()
        + (p.titolo ? '<h2 class="scn-car-tit">' + scnB(p.titolo) + '</h2>' : '')
        + '<div class="scn-car-palco">' + carte.map(function(c){
          return '<article class="scn-carta">' + (c.e ? '<i>' + scnEsc(c.e) + '</i>' : '') + '<b>' + scnB(c.t) + '</b>' + (c.s ? '<span>' + scnB(c.s) + '</span>' : '') + '<u></u></article>';
        }).join('') + '</div>'
        + '<div class="scn-car-punti" aria-hidden="true">' + carte.map(function(_, i){ return '<i' + (i === 0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div></div>';
    },
    /* la formula del tema (applyArc): z = -(k * 0.25) * x^2, rotazione = -(k * 0.6) * x, passo = 1 + gap/100.
       Nel tema la fila gira da sola; qui la muove il dito. Camera a 2 unita' = prospettiva di due carte.
       k e' la "curve" del tema: li' vale 28 su uno schermo largo con sei carte in vista; sul telefono se ne vedono
       due e mezza e con 28 l'arco non si notava, quindi 56 (il tema arriva a 80). */
    disponi: function(w, pos){
      const carte = SCN.carte || w.querySelectorAll('.scn-carta'), W = SCN.cw || 230, k = 0.56, passo = 1.1;
      for (let i = 0; i < carte.length; i++){
        const x = (i - pos) * passo;
        const z = -(k * 0.25) * x * x, rot = -(k * 0.6) * x;
        const el = carte[i];
        if (Math.abs(x) > 2.6){ if (el.style.visibility !== 'hidden') el.style.visibility = 'hidden'; continue; }
        if (el.style.visibility === 'hidden') el.style.visibility = 'visible';
        el.style.transform = 'translate3d(' + (x * W).toFixed(1) + 'px,' + (0.1 * W).toFixed(1) + 'px,' + (z * W).toFixed(1) + 'px) rotateY(' + rot.toFixed(4) + 'rad)';
        /* le carte ai lati si scuriscono con un velo (solo opacita'): la carta resta piena, dietro non si vede niente */
        if (el.lastChild) el.lastChild.style.opacity = Math.min(0.5, Math.abs(x) * 0.42).toFixed(3);
      }
      const idx = Math.max(0, Math.min(carte.length - 1, Math.round(pos)));
      if (idx !== SCN.carIdx){
        SCN.carIdx = idx;
        const punti = w.querySelectorAll('.scn-car-punti i');
        for (let j = 0; j < punti.length; j++) punti[j].classList.toggle('on', j === idx);
        if (SCN.mosso) try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
      }
    },
    misura: function(w){ SCN.carte = w.querySelectorAll('.scn-carta'); const c = SCN.carte[0]; SCN.cw = c ? c.offsetWidth : 230; SCN_STILI.carosello.disponi(w, SCN.carPos || 0); },
    anima: function(tl, w){
      const n = w.querySelectorAll('.scn-carta').length, stato = { pos: 0 };
      SCN.carIdx = -1; SCN.carPos = 0;
      SCN_STILI.carosello.misura(w);
      tl.to(stato, { pos: Math.max(0, n - 1), duration: Math.max(1, n - 1), ease: 'none', onUpdate: function(){ SCN.carPos = stato.pos; SCN_STILI.carosello.disponi(w, stato.pos); } });
      tl.to({}, { duration: 0.35 });
    },
    fermo: function(p){ return [{ t: scnT(p.titolo) }].concat((p.carte || []).map(function(c){ return { k: c.e || '', t: scnT(c.t), s: scnT(c.s) }; })); }
  }
};

/* ---------------------------------------------------------------- il passo */
function scnPasso(p){
  scnChiudi();
  /* il volo fra le nuvole esiste gia' (dream-atmos.js): stesso passo, scritto nel modo nuovo */
  if (p.stile === 'nuvole' && typeof atmPasso === 'function'){
    const cap = (p.frasi || p.atmos || []).map(function(c){ return { e: scnT(c.e), r: (c.r || []).map(function(r){ return scnT(r); }) }; });
    atmPasso({ atmos: cap, fine: p.fine });
    return;
  }
  const stile = SCN_STILI[p.stile] ? p.stile : 'rivela', S = SCN_STILI[stile];
  const w = document.createElement('div');
  w.id = 'scnG'; w.setAttribute('data-cg-no', '');
  const fine = '<div class="scn-fine"><button type="button" class="or-a main" onclick="event.stopPropagation();scnAvanti()">' + scnEsc(p.fine || scnUi('scn_fine', 'Continua')) + '</button></div>';
  (document.getElementById('phone') || document.body).appendChild(w);
  SCN.el = w; SCN.mosso = false; SCN.alFine = false;
  try{ const sg = document.getElementById('s-genio'); if (sg) sg.classList.add('scn-sotto'); }catch(_){ }
  const fermo = function(){
    w.className = 'scn scn-fermo';
    w.innerHTML = SCN_X + '<div class="scn-fermo-in">' + S.fermo(p).filter(function(b){ return b && (b.t || b.s); }).map(function(b){
      return '<section>' + (b.o ? '<small class="scn-occhiello">' + scnEsc(b.o) + '</small>' : '') + (b.k ? '<i>' + scnEsc(b.k) + '</i>' : '') + (b.t ? '<h2>' + scnEsc(b.t).replace(/\*/g, '') + '</h2>' : '') + (b.s ? '<p>' + scnEsc(b.s).replace(/\*/g, '') + '</p>' : '') + '</section>';
    }).join('') + fine + '</div>';
  };
  if (scnFermo()){ fermo(); return; }
  w.className = 'scn scn-' + stile;
  const tappe = S.tappe ? S.tappe(p).map(function(t){ return '<i class="scn-snap" style="top:calc(' + t.toFixed(4) + ' * (100% - var(--scn-h)))"></i>'; }).join('') : '';
  w.innerHTML = '<div class="scn-traccia" style="height:' + Math.round(S.lungo(p)) + '%">' + tappe + '<div class="scn-palco">'
    + S.html(p) + SCN_X
    + '<i class="scn-bar" aria-hidden="true"><b></b></i>'
    + '<p class="scn-scorri"><i>' + SCN_GIU + '</i><span>' + scnEsc(p.scorri || scnUi('scn_scorri', 'Scorri per continuare')) + '</span></p>'
    + fine + '</div></div>';
  const misura = function(){ w.style.setProperty('--scn-h', w.clientHeight + 'px'); if (S.misura) S.misura(w); };
  misura();
  SCN.onRes = function(){ if (SCN.el === w) misura(); };
  addEventListener('resize', SCN.onRes);
  /* 0.9.347, Andrea: "diceva scorri, ma funzionava solo in verticale: chi vede le carte di lato prova a scorrere di lato". Lo scorrimento
     di lato ora vale come quello in verticale: verso sinistra si va avanti di una carta (o di un tratto), verso destra si torna indietro */
  (function(){
    let x0 = 0, y0 = 0, t0 = 0;
    w.addEventListener('touchstart', function(e){ const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); }, { passive: true });
    w.addEventListener('touchend', function(e){
      const t = e.changedTouches[0]; const dx = t.clientX - x0, dy = t.clientY - y0;
      if (Math.abs(dx) < 40 || Math.abs(dx) < Math.abs(dy) * 1.2 || Date.now() - t0 > 900) return;
      const n = (p.carte || []).length;
      const passo = (stile === 'carosello' && n > 1) ? (w.scrollHeight - w.clientHeight) / (n - 1) : w.clientHeight * 0.6;
      const verso = dx < 0 ? 1 : -1;
      const meta = (stile === 'carosello' && n > 1) ? Math.round(w.scrollTop / passo + verso) * passo : w.scrollTop + verso * passo;
      try{ w.scrollTo({ top: Math.max(0, meta), behavior: 'smooth' }); }catch(_){ w.scrollTop = Math.max(0, meta); }
    }, { passive: true });
  })();
  /* chi tocca invece di scorrere (negli altri passi si tocca) avanza di un tratto */
  w.addEventListener('click', function(e){
    if (e.target.closest('button')) return;
    try{ w.scrollBy({ top: w.clientHeight * 0.6, behavior: 'smooth' }); }catch(_){ w.scrollTop += w.clientHeight * 0.6; }
  });
  scnCaricaGsap().then(function(ok){
    if (SCN.el !== w) return;                       /* chiusa mentre le librerie si leggevano */
    if (!ok){ fermo(); return; }
    try{ scnAnima(w, p, stile); }catch(_){ try{ if (SCN.ctx) SCN.ctx.revert(); }catch(__){ } SCN.ctx = null; fermo(); }
  });
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
}
function scnAnima(w, p, stile){
  const S = SCN_STILI[stile], traccia = w.querySelector('.scn-traccia'), barra = w.querySelector('.scn-bar b');
  /* il pulsante finale compare in fondo; nel carosello appena l'ultima carta e' al centro (li' lo scroll si ferma da solo) */
  const soglia = S.tappe ? Math.max(0.5, S.tappe(p).slice(-2)[0] - 0.03) : 0.965;
  try{ ScrollTrigger.enable(); }catch(_){ }
  SCN.ctx = gsap.context(function(){
    const tl = gsap.timeline({
      defaults: { ease: 'none' },
      scrollTrigger: {
        scroller: w, trigger: traccia, start: 'top top', end: 'bottom bottom', scrub: S.scrub, invalidateOnRefresh: true,
        onUpdate: function(st){
          const t = st.progress;
          if (barra) barra.style.transform = 'scaleX(' + t.toFixed(4) + ')';
          if (!SCN.mosso && t > 0.012){ SCN.mosso = true; w.classList.add('mosso'); }
          if (!SCN.alFine && t >= soglia){
            SCN.alFine = true; w.classList.add('al-fine');
            try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
          }
        }
      }
    });
    S.anima(tl, w, p);
  }, w);
  w.classList.add('pronta');
}

/* ---------------------------------------------------------------- lo stile */
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* l'episodio sotto alla scena: nascosto, con le animazioni ferme */
    '#s-genio.scn-sotto .gn{visibility:hidden}#s-genio.scn-sotto,#s-genio.scn-sotto *,#s-genio.scn-sotto *::before,#s-genio.scn-sotto *::after,#s-genio.scn-sotto::before,#s-genio.scn-sotto::after{animation-play-state:paused !important}',
    '.scn{position:fixed;inset:0;z-index:9970;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;scrollbar-width:none;background:#001E44;color:#fff;-webkit-tap-highlight-color:transparent}.scn::-webkit-scrollbar{display:none}',
    '.scn-traccia{position:relative}.scn-carosello{scroll-snap-type:y proximity}.scn-snap{position:absolute;left:0;width:1px;height:1px;scroll-snap-align:start;pointer-events:none}',
    '.scn-palco{position:sticky;top:0;height:var(--scn-h,100vh);overflow:hidden;background:#001E44}',
    '.scn-x{position:absolute;right:14px;top:calc(14px + env(safe-area-inset-top));z-index:9;width:40px;height:40px;padding:0;border:0;border-radius:50%;background:rgba(0,30,68,.6);color:#fff;font-size:16px;line-height:1;cursor:pointer}',
    '.scn-bar{position:absolute;left:0;right:0;top:0;z-index:8;height:3px;background:rgba(255,255,255,.16)}.scn-bar b{display:block;height:100%;background:#8CC6FF;transform:scaleX(0);transform-origin:0 50%;will-change:transform}',
    '.scn-scorri{position:absolute;left:0;right:0;bottom:calc(34px + env(safe-area-inset-bottom));z-index:7;margin:0;display:flex;flex-direction:column;align-items:center;gap:4px;font:700 13px var(--font-body);letter-spacing:.08em;color:#C8EFFD;pointer-events:none;transition:opacity .3s ease}',
    '.scn-scorri i{display:block;line-height:0;animation:scnSu 1.5s ease-in-out infinite}@keyframes scnSu{50%{transform:translateY(-7px)}}',
    '.scn.mosso .scn-scorri{opacity:0}.scn.mosso .scn-scorri i{animation:none}',
    '.scn-fine{position:absolute;left:24px;right:24px;bottom:calc(30px + env(safe-area-inset-bottom));z-index:8;opacity:0;transform:translateY(20px);pointer-events:none;transition:opacity .5s ease,transform .5s cubic-bezier(.22,1,.36,1)}.scn-fine .or-a{width:100%}',
    '.scn.al-fine .scn-fine{opacity:1;transform:none;pointer-events:auto}',
    '.scn-stelle{position:absolute;inset:0;pointer-events:none}.scn-stelle i{position:absolute;left:0;top:0;width:2px;height:2px;border-radius:50%;opacity:.9;will-change:opacity;animation:scnBrilla 6s ease-in-out infinite}@keyframes scnBrilla{50%{opacity:.35}}',
    '.scn-occhiello{display:block;font:700 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    /* rivela */
    '.scn-riv{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:74px 26px 132px;text-align:center;background:radial-gradient(circle at 50% 36%,#0B3266,#001E44 70%)}',
    '.scn-riv .scn-occhiello{position:relative;margin-bottom:28px}.scn-riv .scn-occhiello::before{content:"";display:inline-block;width:6px;height:6px;margin:0 8px 2px 0;border-radius:50%;background:#E63946}',
    '.scn-riv-t{position:relative;margin:0;max-width:440px;font:800 clamp(25px,7.4vw,33px)/1.2 var(--font-display);color:#fff}',
    '.scn-w{display:inline-block;opacity:.12;margin:0 0 .1em;will-change:opacity}.scn-w.acc{color:#8CC6FF}.scn-br{display:block;height:.55em}',
    '.scn-riv-firma{position:relative;margin:30px 0 0;max-width:340px;font:600 16px/1.45 var(--font-body);color:#C8EFFD;opacity:0;transform:translateY(20px)}.scn-riv-firma b{color:#fff;font-weight:800}',
    /* storia */
    '.scn-storia .scn-palco,.scn-st{background:#000D1F}.scn-st{position:absolute;inset:0;overflow:hidden}',
    /* il tema usa perspective 375 e top -30%: sul telefono il testo in alto diventava illeggibile, qui si allontana di meno */
    '.scn-st-nave{position:absolute;left:50%;bottom:17%;z-index:3;width:64px;height:64px;margin-left:-32px;will-change:transform;pointer-events:none}',
    '.scn-st-nave span{display:block;width:100%;height:100%;animation:scnDondola 1s linear infinite alternate}@keyframes scnDondola{to{transform:translateY(-10px)}}.scn.mosso .scn-st-nave span{animation:none}',
    '.scn-st-nave svg{display:block;width:100%;height:100%;transform:rotate(-45deg)}',
    '.scn-st-intro{position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;padding:0 34px 12%;text-align:center;font:600 clamp(21px,5.8vw,27px)/1.45 var(--font-body);color:#8CC6FF}.scn-st-intro p{margin:0}.scn-st-intro b{color:#fff;font-weight:800}',
    '.scn-st-titolo{position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;padding:0 12%;text-align:center;opacity:0;will-change:transform,opacity}.scn-st-titolo b{font:900 clamp(38px,11.6vw,54px)/1.04 var(--font-display);color:#fff}',
    '.scn-st-crawl{position:absolute;top:-12%;bottom:0;left:5%;width:90%;z-index:2;transform:perspective(520px) rotateX(16deg);transform-origin:center bottom;opacity:0;overflow:hidden}',
    '.scn-st-crawl::before,.scn-st-crawl::after{content:"";position:absolute;left:0;top:0;z-index:1;width:100%;height:15.5%;background:linear-gradient(180deg,rgba(0,13,31,.96),rgba(0,13,31,0))}.scn-st-crawl::after{top:auto;bottom:0;transform:rotate(180deg)}',
    '.scn-st-righe{position:absolute;top:100%;left:0;width:100%;will-change:transform}',
    '.scn-st-righe p{margin:0 0 3.2rem;text-align:center;font:800 clamp(25px,7vw,32px)/1.42 var(--font-display);color:#C8EFFD}.scn-st-righe p b{color:#fff}',
    '.scn-st-outro{position:absolute;left:8%;right:8%;top:50%;z-index:2;height:0;display:flex;align-items:center;justify-content:center}',
    '.scn-st-scia{width:100%;overflow:hidden;will-change:transform}.scn-st-scia b{display:block;padding:6px 0;text-align:center;font:900 clamp(26px,7.4vw,34px)/1.2 var(--font-display);color:#fff;will-change:transform}',
    '.scn:not(.pronta) .scn-st-scia,.scn:not(.pronta) .scn-plx-p{visibility:hidden}',
    /* parallasse */
    '.scn-plx{position:absolute;inset:0;overflow:hidden;background:#000D1F}',
    '.scn-plx-hero{position:absolute;inset:0;z-index:1;background:radial-gradient(circle at 50% 42%,#12305E,#000D1F 72%);will-change:transform}',
    '.scn-plx-hero .epi-vis{position:absolute;left:0;right:0;top:42%;width:auto;height:190px;min-height:0;margin-top:-95px}',
    '.scn-plx-fin{position:absolute;inset:0;z-index:3;perspective:500px;overflow:hidden;pointer-events:none}',
    '.scn-plx-vetro{position:absolute;inset:0;background:radial-gradient(circle at 50% 42%,rgba(0,30,68,0) 0,rgba(0,30,68,0) 27vw,#8CC6FF 27.5vw,#8CC6FF 28.5vw,#001E44 29vw);will-change:transform}',
    '.scn-plx-vetro h2{position:absolute;left:26px;right:26px;top:calc(78px + env(safe-area-inset-top));margin:0;text-align:center;font:900 clamp(26px,7.4vw,34px)/1.15 var(--font-display);color:#fff}.scn-plx-vetro h2 b{color:#8CC6FF}',
    '.scn-plx-p{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:0 28px;text-align:center;will-change:transform}',
    '.scn-plx-p h2{margin:0;max-width:420px;font:900 clamp(28px,8vw,36px)/1.14 var(--font-display);color:#fff}.scn-plx-p p{margin:0;max-width:340px;font:600 17px/1.45 var(--font-body);color:#fff}',
    '.scn-plx-p.c-blu{background:linear-gradient(135deg,#0075E3,#3F9FF4)}.scn-plx-p.c-rosso{background:#E63946}.scn-plx-p.c-notte{background:#001E44}',
    '.scn-plx-p.c-chiaro{background:#F0FBFF}.scn-plx-p.c-chiaro h2,.scn-plx-p.c-chiaro p{color:#001E44}.scn-plx-p.c-chiaro h2 b{color:#0075E3}',
    '.scn-plx-p.c-notte h2 b,.scn-plx-p.c-blu h2 b,.scn-plx-p.c-rosso h2 b{color:#C8EFFD}',
    /* carosello */
    '.scn-car{position:absolute;inset:0;overflow:hidden;background:radial-gradient(circle at 50% 30%,#12305E,#001E44 70%);--scn-cw:min(58vw,250px)}',
    '.scn-car-tit{position:absolute;left:26px;right:26px;top:calc(78px + env(safe-area-inset-top));z-index:2;margin:0;text-align:center;font:900 clamp(26px,7.4vw,34px)/1.15 var(--font-display);color:#fff}.scn-car-tit b{color:#8CC6FF}',
    '.scn-car-palco{position:absolute;left:0;right:0;top:53%;height:0;perspective:calc(var(--scn-cw) * 2);perspective-origin:50% 50%}',
    '.scn-plx-vetro h2,.scn-car-tit,.scn-plx-p h2,.scn-st-titolo b,.scn-st-scia b,.scn-carta b,.scn-carta span{text-wrap:balance}',
    '.scn-carta{position:absolute;left:50%;top:0;box-sizing:border-box;width:var(--scn-cw);height:calc(var(--scn-cw) * 1.3);margin:calc(var(--scn-cw) * -.65) 0 0 calc(var(--scn-cw) * -.5);border-radius:calc(var(--scn-cw) * .1);background:#F0FBFF;color:#001E44;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:18px 16px;text-align:center;box-shadow:0 18px 40px rgba(0,0,0,.35);will-change:transform;backface-visibility:hidden}',
    '.scn-carta u{position:absolute;inset:0;border-radius:inherit;background:#001E44;opacity:0;pointer-events:none;will-change:opacity}',
    '.scn-carta i{font-size:46px;font-style:normal;line-height:1}.scn-carta b{font:800 19px/1.2 var(--font-display);color:#001E44}.scn-carta b b{color:#0075E3}.scn-carta span{font:600 14.5px/1.42 var(--font-body);color:#001E44;opacity:.82}',
    '.scn-car-punti{position:absolute;left:0;right:0;bottom:calc(118px + env(safe-area-inset-bottom));display:flex;justify-content:center;gap:8px}.scn-car-punti i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.3)}.scn-car-punti i.on{background:#fff}',
    /* senza movimento: una pagina ferma da leggere */
    '.scn-fermo .scn-x{position:fixed}.scn-fermo-in{max-width:440px;margin:0 auto;padding:calc(84px + env(safe-area-inset-top)) 26px calc(40px + env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:34px;text-align:center}',
    '.scn-fermo-in section{display:flex;flex-direction:column;gap:12px}.scn-fermo-in i{font-size:34px;font-style:normal;line-height:1}.scn-fermo-in h2{margin:0;font:800 26px/1.22 var(--font-display);color:#fff}.scn-fermo-in p{margin:0;font:600 17px/1.5 var(--font-body);color:#C8EFFD}',
    '.scn-fermo .scn-fine{position:static;opacity:1;transform:none;pointer-events:auto;margin-top:10px}'
  ].join('\n');
  document.head.appendChild(st);
})();
