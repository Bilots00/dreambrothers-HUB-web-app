/* LE SCHEDE APERTE DURANTE IL FULL FOCUS (0.9.298).
   Andrea: "nelle impostazioni del Full Focus voglio dare accesso solo a certe parti dell'app: poter tornare
   indietro dalla pagina del Full Focus alla scheda START e alla Mappa, per proseguire la roadmap, e bloccare
   schede come Dream e Profilo una volta avviata la sessione".
   Ogni scheda della barra in basso ha il suo interruttore (ffPref().schede). Mentre la sessione corre
   (FF.run), una scheda chiusa non si apre: la barra la mostra con il lucchetto e un tocco dice quando si
   riapre. Sopra le schede aperte c'e' una pillola con il tempo che resta, per tornare al timer. */
const FFS_SCHEDE = [
  { k: 'rotta', n: 'Sogno', ico: '🧭', sub: 'Il sogno, l’arrivo e le sfide.' },
  { k: 'mappa', n: 'Mappa', ico: '🗺️', sub: 'Il percorso, per fare la prossima tappa.' },
  { k: 'sveglia', n: 'START', ico: '🚀', sub: 'Il foglio di oggi e la partita.' },
  { k: 'profilo', n: 'Profilo', ico: '👤', sub: 'Account, impostazioni e report.' }
];
const FFS_DEF = { rotta: false, mappa: true, sveglia: true, profilo: false };

function ffsSchede(){
  const p = ffPref();
  if (!p.schede || typeof p.schede !== 'object') p.schede = Object.assign({}, FFS_DEF);
  return p.schede;
}
function ffsInCorso(){ return !!(typeof FF !== 'undefined' && FF.run && FF.run.endAt > Date.now()); }
function ffsAperta(k){ const s = ffsSchede(); return s[k] == null ? !!FFS_DEF[k] : !!s[k]; }
function ffsNome(k){ const x = FFS_SCHEDE.filter(function(s){ return s.k === k; })[0]; return x ? x.n : k; }
/** La prima scheda aperta: e' dove si atterra uscendo dal timer. null se sono tutte chiuse. */
function ffsPrimaAperta(){ const x = ['sveglia', 'mappa', 'rotta', 'profilo'].filter(ffsAperta)[0]; return x || null; }

function ffsToggle(k){
  const s = ffsSchede(); s[k] = !ffsAperta(k);
  ffSavePref(); ffsBarra();
  if (typeof ffImpostazioniApri === 'function') ffImpostazioniApri();
}
/** La sezione delle impostazioni del Full Focus (ff-cicli.js la mette in fondo). */
function ffsImpostazioniHtml(){
  return '<div class="ffi-sez">🔓 Le schede aperte</div>'
    + '<div class="ffi-card">'
    + '<p class="ffs-nota">Le schede accese restano aperte mentre il timer corre. Quelle spente si riaprono a fine sessione.</p>'
    + FFS_SCHEDE.map(function(x){ return ffcRigaSw(x.ico + ' ' + x.n, x.sub, ffsAperta(x.k), 'ffsToggle(\'' + x.k + '\')'); }).join('')
    + '</div>';
}

/* La barra in basso: le schede chiuse con il lucchetto, mentre la sessione corre */
function ffsBarra(){
  const on = ffsInCorso();
  FFS_SCHEDE.forEach(function(x){
    const b = document.getElementById('nav-' + x.k); if (!b) return;
    b.classList.toggle('ffs-chiusa', on && !ffsAperta(x.k));
  });
  ffsPillola();
}
/* La pillola per tornare al timer, sopra le schede aperte */
function ffsPillola(){
  let p = document.getElementById('ffsPill');
  const home = typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] === 's-home';
  if (!ffsInCorso() || !home){ if (p) p.hidden = true; return; }
  if (!p){
    p = document.createElement('button'); p.type = 'button'; p.id = 'ffsPill'; p.className = 'ffs-pill';
    p.onclick = function(){ if (typeof ffOpen === 'function') ffOpen(); };
    document.body.appendChild(p);
  }
  const resto = Math.max(0, FF.run.endAt - Date.now());
  p.innerHTML = '<span class="ffs-pt">🌱</span><b>' + (typeof ffFmt === 'function' ? ffFmt(resto) : '') + '</b><span>Torna al Full Focus</span>';
  p.hidden = false;
}

/* switchTab passa di qui: una scheda chiusa durante la sessione non si apre. Si aggancia quando tutti gli script sono
   caricati: nav.js (dove nasce switchTab) arriva dopo questo file. */
function ffsAggancia(){
  if (window.__ffsAgganciato) return; window.__ffsAgganciato = true;
(function(){
  const orig = window.switchTab;
  if (typeof orig !== 'function') return;
  window.switchTab = switchTab = function(name){
    if (ffsInCorso() && FFS_DEF.hasOwnProperty(name) && !ffsAperta(name)){
      const resto = Math.max(1, Math.ceil((FF.run.endAt - Date.now()) / 60000));
      if (typeof toast === 'function') toast(ffsNome(name) + ' si riapre a fine sessione, fra ' + resto + ' min');
      try{ if (typeof flVibra === 'function') flVibra([20]); }catch(_){ }
      return;
    }
    return orig.apply(this, arguments);
  };
})();

/* Uscendo dal timer mentre corre si atterra su una scheda aperta, non su quella di prima */
(function(){
  const orig = window.ffClose;
  if (typeof orig !== 'function') return;
  window.ffClose = ffClose = function(){
    if (ffsInCorso()){
      const k = ffsPrimaAperta();
      if (!k){ if (typeof toast === 'function') toast('Durante la sessione le schede sono chiuse: si riaprono alla fine'); return; }
      orig.apply(this, arguments);
      try{ window.switchTab(k); }catch(_){ }
      ffsBarra();
      return;
    }
    return orig.apply(this, arguments);
  };
})();

}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ffsAggancia); else ffsAggancia();

document.addEventListener('fl:screen', ffsBarra);
setInterval(function(){ if (ffsInCorso() || document.querySelector('.ffs-chiusa') || (document.getElementById('ffsPill') && !document.getElementById('ffsPill').hidden)) ffsBarra(); }, 1000);

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.ffs-nota{margin:12px 0 6px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.ffs-chiusa{opacity:.38;position:relative}',
    '.ffs-chiusa::after{content:"🔒";position:absolute;top:2px;right:calc(50% - 22px);font-size:11px}',
    '.ffs-pill{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:60;display:flex;align-items:center;gap:8px;padding:10px 16px;border:0;border-radius:99px;background:linear-gradient(135deg,#0B3F7A,#001E44);color:#fff;font:700 13px var(--font-body);box-shadow:0 8px 24px rgba(0,30,68,.35);cursor:pointer}',
    '.ffs-pill b{font:900 15px var(--font-display,var(--font-body));font-variant-numeric:tabular-nums}',
    '.ffs-pill[hidden]{display:none}'
  ].join('');
  document.head.appendChild(st);
})();
