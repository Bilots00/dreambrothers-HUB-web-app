/* ===========================================================================================
   L'ARBITRO — il tabellone delle interruzioni

   Il tabellone della scheda START dice chi sta vincendo la giornata. Questo dice una cosa più
   stretta e più scomoda: quante volte, davanti a un blocco, hai detto sì alla distrazione, e
   quante volte hai detto no.

   PERCHÉ È UN TABELLONE A PARTE. «Ho passato 4 ore sul telefono» è una misura del risultato;
   «ho interrotto il blocco 6 volte su 20» è una misura della decisione — e la decisione è
   l'unica cosa su cui si può lavorare domani. Sono due numeri diversi e non vanno sommati.

   CHI ASSEGNA IL PUNTO. Nessuno deve segnare a mano, perché un punteggio che dipende
   dall'onestà di chi lo scrive non è un punteggio. I due numeri li conta il motore mentre fa
   il suo lavoro:

     · HAI TENUTO  — ogni blocco davvero applicato. Il motore lo registra un istante prima di
       mostrare la schermata (Stats.recordBlock), quindi esiste solo se il blocco è scattato
       per davvero su questo telefono.
     · HAI CEDUTO  — ogni interruzione confermata: un programma fermato, il Blocco rapido
       spento prima del tempo. Passa tutto da itBump(), che è l'unico punto dell'app in cui
       una interruzione diventa vera.

   COMPARE SOLO NEL CAMPIONATO. Nella partita del giorno e in quella a tempo il punteggio si
   azzera da solo, e un conteggio che riparte da zero ogni notte non racconta nessuna tendenza:
   qui invece i numeri si accumulano, che è esattamente il motivo per cui si sceglie il
   campionato.
   =========================================================================================== */

/* I periodi. «Oggi» c'e' perche' e' l'unico che risponde alla domanda che uno si fa mentre
   sta cedendo — non «come vado questo mese», ma «quante volte ho gia' ceduto oggi». */
/* «Ieri» e' -1: un giorno solo, spostato indietro di uno. */
const ARB_TFS = [[1, 'Oggi'], [-1, 'Ieri'], [7, 'Ultimi 7 giorni'], [30, 'Ultimi 30 giorni'],
                 [90, 'Ultimi 3 mesi'], [365, 'Quest\'anno'], [0, 'Da sempre']];

function arbTf(){
  try{ const v = +localStorage.getItem('fl_arb_tf'); return ARB_TFS.some(x => x[0] === v) ? v : 30; }
  catch(_){ return 30; }
}
function arbSetTf(v){
  try{ localStorage.setItem('fl_arb_tf', String(v)); }catch(_){ }
  arbMenuClose();
  arbPaint();
}
/* ---------------------------------------------------------------------------------------
   DOVE STA IL PANNELLO

   Sopra alla panoramica o sotto: sono due idee diverse di cosa si guarda per primo entrando
   nella scheda. Sopra, il tabellone e' la prima cosa — ed e' giusto per chi ci sta lavorando
   adesso; sotto, viene dopo il quadro generale, che e' l'ordine naturale di una relazione.
   Nessuna delle due e' sbagliata, quindi si sceglie.
   --------------------------------------------------------------------------------------- */
const ARB_POS = [['sopra', 'Sopra la panoramica'], ['sotto', 'Sotto la panoramica']];

function arbPos(){
  try{ const v = localStorage.getItem('fl_arb_pos'); return (v === 'sopra' || v === 'sotto') ? v : 'sotto'; }
  catch(_){ return 'sotto'; }
}

function arbSetPos(v){
  try{ localStorage.setItem('fl_arb_pos', v); }catch(_){ }
  arbMenuClose();
  arbSistema();
  arbPaint();
  if (typeof toast === 'function') toast(v === 'sopra' ? 'Tabellone sopra la panoramica' : 'Tabellone sopra il Blocco rapido');
}

/** Sposta il pannello nel punto scelto, senza ridisegnarlo. */
function arbSistema(){
  let box = document.getElementById('arbBox');
  const tab = document.getElementById('tab-blocco');
  if (!box || !tab) return;
  /* Se il pannello e' dentro alla sezione a diapositive (focusbox.js), a spostarsi deve
     essere la sezione intera: tirarne fuori una sola diapositiva la lascerebbe orfana. */
  const wrap = document.getElementById('fbWrap');
  if (wrap && wrap.contains(box)) box = wrap;
  const qb = tab.querySelector('.qb');
  if (!qb) return;
  if (arbPos() === 'sopra'){
    /* Sopra a tutto: prima figlia della scheda, davanti anche alla panoramica. */
    if (tab.firstElementChild !== box) tab.insertBefore(box, tab.firstElementChild);
  } else {
    /* Sotto la panoramica vuol dire: attaccato al Blocco rapido, subito prima. */
    if (qb.previousElementSibling !== box) qb.parentNode.insertBefore(box, qb);
  }
}

function arbTfLabel(){
  const v = arbTf();
  return (ARB_TFS.filter(function(x){ return x[0] === v; })[0] || ARB_TFS[1])[1];
}

/** I giorni da guardare, come chiavi «aaaa-mm-gg». Zero giorni = tutto quello che c'è. */
function arbGiorniIndietro(){
  const n = arbTf();
  if (n === -1) return 1;
  return n > 0 ? n : 3650;
}
/** Di quanti giorni e' spostata indietro la finestra: 1 per «Ieri», 0 altrimenti. */
function arbScarto(){ return arbTf() === -1 ? 1 : 0; }
function arbChiave(off){ return new Date(Date.now() - off * 86400000).toISOString().slice(0, 10); }

/* ---------------------------------------------------------------------------------------
   I due numeri
   --------------------------------------------------------------------------------------- */

/** Le interruzioni confermate, dal registro che scrive itBump(). */
function arbCeduto(giorni){
  let tot = 0;
  try{
    const log = (typeof itLog === 'function') ? itLog() : {};
    /* «Oggi» vuol dire oggi: un giorno di finestra parte da stamattina, non da ieri. */
    const off = arbScarto();
    const limite = arbChiave(off + giorni - 1), tetto = arbChiave(off);
    Object.keys(log).forEach(function(day){
      if (day < limite || day > tetto) return;
      const d = log[day] || {};
      Object.keys(d).forEach(function(k){ tot += +d[k] || 0; });
    });
  }catch(_){ }
  return tot;
}

/** I blocchi applicati davvero, dal motore. Asincrono: i conteggi vivono di là. */
async function arbTenuto(giorni){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInsights) return 0;
    const off = arbScarto();
    const r = await NATIVE.getInsights({ days: Math.min(giorni + off, 60) });
    if (!r) return 0;
    if (arbTf() === 0 && typeof r.total === 'number') return r.total;
    const limite = arbChiave(off + giorni - 1), tetto = arbChiave(off);
    return (r.history || []).reduce(function(s, x){
      return (x.day && (x.day < limite || x.day > tetto)) ? s : s + (+x.blocks || 0);
    }, 0);
  }catch(_){ return 0; }
}

/* ---------------------------------------------------------------------------------------
   Il pannello
   --------------------------------------------------------------------------------------- */

(function arbStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.arb{position:relative;background:linear-gradient(160deg,#12203A,#1E3A6B);border-radius:20px;',
      'padding:20px 18px 18px;margin:0 0 14px;color:#fff;text-align:center}',
    '.arb-eyebrow{font:800 9.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;',
      'color:rgba(200,218,242,.72)}',
    '.arb h4{font:800 17px/1.2 var(--font-display);margin:8px 0 2px;color:#fff}',
    '.arb-when{font:600 11px var(--font-body);color:rgba(200,218,242,.62)}',
    '.arb-board{display:flex;align-items:flex-start;justify-content:space-around;margin-top:18px}',
    '.arb-side{flex:1;min-width:0}',
    '.arb-side .n{display:block;font:800 40px/1 var(--font-display)}',
    '.arb-side .n.si{color:#FF8A9B}',
    '.arb-side .n.no{color:var(--neo-soft,#4FB8FF)}',
    '.arb-side small{display:block;margin-top:6px;font:700 10px var(--font-body);letter-spacing:.1em;',
      'text-transform:uppercase;color:rgba(200,218,242,.8)}',
    '.arb-side i{display:block;font-style:normal;font:500 11px/1.4 var(--font-body);',
      'color:rgba(200,218,242,.6);margin-top:4px;padding:0 4px}',
    '.arb-dash{flex:0 0 auto;padding:0 6px;font:800 26px var(--font-display);color:rgba(255,255,255,.3);',
      'align-self:center}',
    '.arb-bar{height:7px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden;margin-top:18px;display:flex}',
    '.arb-bar i{display:block;height:100%}',
    '.arb-bar .si{background:#FF8A9B}',
    '.arb-bar .no{background:var(--neo-soft,#4FB8FF)}',
    '.arb-line{margin-top:12px;font:600 12px/1.5 var(--font-body);color:#C8DAF2}',
    '.arb-dots{position:absolute;top:12px;right:12px;width:34px;height:34px;border:0;border-radius:50%;',
      'background:rgba(255,255,255,.12);color:#fff;font:800 16px var(--font-body);cursor:pointer;line-height:1}',
    '.arb-menu{position:absolute;top:50px;right:12px;z-index:30;background:#fff;border-radius:14px;',
      'overflow:hidden;box-shadow:0 18px 40px rgba(0,0,0,.35);min-width:180px}',
    '.arb-menu button{display:block;width:100%;border:0;background:#fff;padding:12px 14px;text-align:left;',
      'font:600 12.5px var(--font-body);color:#0E1B33;cursor:pointer}',
    '.arb-menu button + button{border-top:1px solid #E7ECF5}',
    '.arb-menu button.on{font-weight:800;color:#0075E3}',
    '.arb-mtit{margin:0;padding:11px 14px 5px;font:800 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:#8B99AC;background:#fff}',
    '.arb-mtit + button{border-top:0}',
    '.fl-menu-fisso{position:fixed;z-index:26;top:auto;right:auto;bottom:auto;',
      'max-height:min(60vh,420px);overflow:auto;transform:none}',
    '.arb-veil{position:fixed;inset:0;z-index:25;background:rgba(0,10,26,.55);',
      'animation:arbVeloIn .16s ease-out}',
    '@keyframes arbVeloIn{from{opacity:0}to{opacity:1}}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* Il pannello si innesta fra la panoramica e il Blocco rapido: è lì che l'occhio passa
   comunque, e non ruba il posto a nessuno dei due. */
(function arbGraft(){
  const tab = document.getElementById('tab-blocco');
  const qb = tab && tab.querySelector('.qb');
  if (!qb) return;
  const box = document.createElement('div');
  box.className = 'arb';
  box.id = 'arbBox';
  box.hidden = true;
  qb.parentNode.insertBefore(box, qb);
})();

function arbMenuClose(){
  const m = document.getElementById('arbMenu');
  if (m) m.remove();
  const v = document.getElementById('arbVeil');
  if (v) v.remove();
}

/* IL VELO. Un menu che si apre su una pagina che resta accesa non sembra un menu: sembra un
   pezzo di pagina comparso dal niente, e il resto continua a chiedere attenzione. Il velo dice
   una cosa sola — adesso conta questo — ed e' anche il posto piu' comodo dove toccare per
   chiudere, che e' il gesto che fanno tutti. */
/**
 * DOVE VA APPESO UN VELO. Dentro al telefono, non al documento.
 *
 * <p>Sopra i 480 pixel — cioe' sul computer — `#phone` prende `transform:translateZ(0)` per
 * ancorare a se' tutto quello che e' `position:fixed`. Una trasformazione pero' crea anche un
 * CONTESTO DI IMPILAMENTO: da li' in avanti nessun `z-index` interno puo' piu' salire sopra a
 * un elemento appeso al documento. Il velo stava sul documento a z-index 25, il menu dentro al
 * telefono a 30 — e il 30 non contava niente. Risultato: sul computer il velo copriva anche il
 * menu, e toccare una voce non faceva altro che chiudere tutto. Sul telefono, sotto i 480
 * pixel, la trasformazione non c'e' e i due numeri si confrontavano davvero: per questo li'
 * funzionava. Appesi nello stesso posto, funziona in tutti e due.</p>
 */
function flVeloCasa(){
  /* la mappa a tutto schermo e' un livello sopra a tutto: un menu appeso al telefono
     finirebbe sotto di lei, e il suo pulsante dei tre puntini sembrerebbe rotto */
  return document.getElementById('mpFull') || document.getElementById('phone') || document.body;
}

/**
 * ...E NON BASTA SPOSTARE IL VELO.
 *
 * <p>Un menu aperto dentro a una diapositiva resta comunque prigioniero: il carosello muove le
 * diapositive con una `transform`, e una trasformazione crea un contesto di impilamento. Da
 * dentro, nessun `z-index` puo' salire sopra a qualcosa che sta fuori — il velo copriva il
 * menu e toccare una voce non faceva altro che chiudere tutto. Sul telefono non si vedeva
 * perche' li' il velo e il menu finivano per caso nello stesso contesto.</p>
 *
 * <p>Quindi il menu esce dalla diapositiva e va accanto al velo, dentro al telefono, con le
 * coordinate prese dal pulsante che l'ha aperto. `position:fixed` dentro al telefono vuol dire
 * «rispetto al telefono» sul computer e «rispetto alla finestra» sul cellulare: in tutti e due
 * i casi e' la stessa cosa, perche' li' il telefono E' la finestra.</p>
 */
function flMenuFissa(m, trigger){
  if (!m) return;
  const casa = flVeloCasa();
  if (m.parentElement !== casa) casa.appendChild(m);
  m.classList.add('fl-menu-fisso');
  const box = casa.getBoundingClientRect();
  const t = (trigger && trigger.getBoundingClientRect) ? trigger.getBoundingClientRect() : null;
  /* si misura dopo essere entrato nel documento, altrimenti larghezza e altezza sono zero */
  const w = m.offsetWidth || 190, h = m.offsetHeight || 160;
  const marg = 10;
  let left = t ? (t.right - w) : (box.right - w - marg);
  let top = t ? (t.bottom + 8) : (box.top + 56);
  left = Math.max(box.left + marg, Math.min(left, box.right - w - marg));
  /* se sotto non ci sta, si apre verso l'alto: un menu tagliato dal bordo non si usa */
  if (top + h > box.bottom - marg) top = t ? Math.max(box.top + marg, t.top - h - 8) : (box.bottom - h - marg);
  /* DENTRO A UN ANTENATO TRASFORMATO, «fisso» VUOL DIRE «rispetto a lui».
     Le coordinate qui sopra sono della finestra; se il telefono e' trasformato (cioe' sul
     computer) vanno riportate al suo riquadro interno, bordo compreso — altrimenti il menu
     finisce a destra della scocca, fuori da tutto, ed e' come non averlo aperto. */
  /* L'antenato trasformato puo' non essere `casa`: la mappa grande sta dentro al telefono,
     e il telefono e' quello con la trasformazione. Si risale finche' non lo si trova. */
  let offX = 0, offY = 0;
  try{
    let n = casa;
    while (n && n !== document.body){
      const cs = getComputedStyle(n);
      if (cs.transform && cs.transform !== 'none'){
        const r = n.getBoundingClientRect();
        offX = r.left + (n.clientLeft || 0);
        offY = r.top + (n.clientTop || 0);
        break;
      }
      n = n.parentElement;
    }
  }catch(_){ }
  m.style.left = Math.round(left - offX) + 'px';
  m.style.top = Math.round(top - offY) + 'px';
}

function arbVelo(){
  if (document.getElementById('arbVeil')) return;
  const v = document.createElement('div');
  v.id = 'arbVeil';
  v.className = 'arb-veil';
  v.addEventListener('click', function(e){ e.stopPropagation(); arbMenuClose(); });
  flVeloCasa().appendChild(v);
}

function arbMenuOpen(ev){
  if (ev) ev.stopPropagation();
  if (document.getElementById('arbMenu')){ arbMenuClose(); return; }
  const box = document.getElementById('arbBox');
  if (!box) return;
  arbVelo();
  const m = document.createElement('div');
  m.className = 'arb-menu';
  m.id = 'arbMenu';
  m.innerHTML = '<p class="arb-mtit">Periodo</p>'
    + ARB_TFS.map(function(t){
        return '<button type="button" class="' + (t[0] === arbTf() ? 'on' : '') + '" onclick="arbSetTf(' + t[0] + ')">'
          + t[1] + '</button>';
      }).join('')
    + '<p class="arb-mtit">Dove sta questo pannello</p>'
    + ARB_POS.map(function(pz){
        return '<button type="button" class="' + (pz[0] === arbPos() ? 'on' : '') + '" onclick="arbSetPos(\'' + pz[0] + '\')">'
          + pz[1] + '</button>';
      }).join('');
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || box.querySelector('.pb-dots, .arb-dots'));
}

async function arbPaint(){
  const box = document.getElementById('arbBox');
  if (!box) return;

  /* Solo nel campionato: negli altri due modi il punteggio si azzera da solo, e un conteggio
     che riparte ogni notte non ha una tendenza da mostrare. */
  const c = (typeof mgCfg === 'function') ? mgCfg() : {};
  if (c.season !== 'campionato'){ box.hidden = true; box.innerHTML = ''; return; }

  const giorni = arbGiorniIndietro();
  const si = arbCeduto(giorni);
  const no = await arbTenuto(giorni);
  const tot = si + no;
  const pct = tot ? Math.round(no * 100 / tot) : 0;

  box.hidden = false;
  box.innerHTML =
      '<button type="button" class="arb-dots" onclick="arbMenuOpen(event)" aria-label="Cambia periodo">⋯</button>'
    + '<p class="arb-eyebrow">L\'arbitro</p>'
    + '<h4>Quando il blocco ti ha fermato</h4>'
    + '<p class="arb-when">' + arbTfLabel() + '</p>'
    + '<div class="arb-board">'
    +   '<div class="arb-side"><b class="n si">' + si + '</b><small>Hai ceduto</small>'
    +     '<i>blocchi interrotti</i></div>'
    +   '<div class="arb-dash">–</div>'
    +   '<div class="arb-side"><b class="n no">' + no + '</b><small>Hai tenuto</small>'
    +     '<i>distrazioni fermate</i></div>'
    + '</div>'
    + (tot
        ? '<div class="arb-bar"><i class="si" style="width:' + (100 - pct) + '%"></i>'
          + '<i class="no" style="width:' + pct + '%"></i></div>'
          + '<p class="arb-line">' + arbFrase(pct, tot) + '</p>'
        : '<p class="arb-line">Ancora niente da arbitrare. Il primo blocco che scatta apre il tabellone.</p>');
}

/* La frase sotto la barra. Non è un complimento: è la lettura del numero, detta come la
   direbbe qualcuno che ha guardato la stessa partita. */
function arbFrase(pct, tot){
  if (pct >= 90) return '<b>' + pct + '% di no.</b> A questo punto non è più forza di volontà: è un\'abitudine.';
  if (pct >= 75) return '<b>' + pct + '% di no.</b> Tre volte su quattro il blocco ha retto. Il quarto è quello su cui lavorare.';
  if (pct >= 50) return '<b>' + pct + '% di no.</b> Più sì che no ancora no, ma la partita è aperta.';
  if (pct > 0) return '<b>' + pct + '% di no.</b> Il blocco c\'è, ma per adesso lo stai aggirando più di quanto lo ascolti.';
  return 'Su ' + tot + ' occasioni, hai ceduto tutte le volte. Non è una condanna: è il punto di partenza.';
}

/* Si ridisegna quando la scheda Blocco torna davanti: i due numeri possono essere cambiati
   mentre l'utente era altrove — anzi, e' esattamente quando cambiano. */
document.addEventListener('fl:tab', function(e){ if (e.detail === 'blocco'){ arbSistema(); arbPaint(); } });
setTimeout(function(){ arbSistema(); arbPaint(); }, 2000);
