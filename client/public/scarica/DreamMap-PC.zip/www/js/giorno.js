/* ===========================================================================================
   IL CAMBIO DI GIORNO — la sveglia che mancava

   IL DIFETTO, detto com'è: **niente, in tutta l'app, si accorgeva che era passata mezzanotte.**

   La frase del giorno è calcolata bene — la chiave della cache è la data del calendario, e a
   mezzanotte quella cambia — ma il calcolo lo faceva solo chi lo chiedeva, e a chiederlo era
   una funzione che gira quando si APRE la scheda. Questa è un'app di concentrazione: resta
   aperta per ore, e spesso sullo schermo c'è ancora la pagina di ieri. Alle 00:46 la frase
   mostrata era quella del giorno prima non perché fosse sbagliata, ma perché nessuno l'aveva
   più chiesta da prima di mezzanotte.

   È lo stesso motivo per cui anche il tabellone, i piani e le sessioni pronte restavano fermi:
   tutti giusti al momento del disegno, tutti disegnati un giorno fa.

   COME FUNZIONA. Un solo orologio, qui dentro, che si sveglia al primo secondo del giorno
   nuovo e rifà tutto quello che dipende dalla data. E non si fida solo del timer: un
   setTimeout lungo, su Android, non sopravvive al telefono che dorme — quindi la data si
   ricontrolla anche ogni volta che l'app torna in primo piano. Le due strade portano allo
   stesso posto, e la seconda è quella che funziona davvero nel 90% dei casi.
   =========================================================================================== */

const GG_KEY = 'fl_giorno_visto';
let GG_TIMER = 0;

function ggOggi(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0')
       + '-' + String(d.getDate()).padStart(2, '0');
}

function ggVisto(){
  try{ return localStorage.getItem(GG_KEY) || ''; }catch(_){ return ''; }
}

/* Quanto manca al primo secondo di domani. Un secondo e mezzo dopo la mezzanotte, non esatto:
   a cavallo del secondo zero `new Date()` può ancora leggere ieri, e una sveglia che suona un
   istante troppo presto ridisegna il giorno vecchio e poi non suona più. */
function ggQuantoManca(){
  const d = new Date();
  d.setHours(24, 0, 0, 0);
  return Math.max(1000, d.getTime() - Date.now() + 1500);
}

/* ---------------------------------------------------------------------------------------
   Cosa si rifà

   L'elenco è esplicito di proposito. Un `location.reload()` sarebbe una riga sola e sarebbe
   sbagliato: butterebbe via una sessione in corso, la tastiera aperta, il foglio a metà. Qui
   si ridisegna, non si ricomincia.
   --------------------------------------------------------------------------------------- */
function ggRidisegna(){
  /* 1. LA FRASE DEL GIORNO. Prima si butta la copia tenuta in memoria, o scQuotes()
        risponderebbe con quella di ieri senza nemmeno chiedere al server. E si riarma la
        macchina da scrivere: una frase nuova che appare già scritta non si nota. */
  try{
    if (typeof SC !== 'undefined' && SC){
      SC.quotes = null;
      SC.typed = false;
    }
    if (typeof scBlockScores === 'function') scBlockScores();
  }catch(_){ }

  /* 2. I DUE TABELLONI. mtRoll() è la funzione che chiude i giorni passati e assegna i punti:
        finché non veniva chiamata, il giorno di ieri restava aperto. */
  try{ if (typeof mtPaint === 'function') mtPaint(); }catch(_){ }
  try{ if (typeof pbPaint === 'function') pbPaint(); }catch(_){ }
  try{ if (typeof spPaint === 'function') spPaint(); }catch(_){ }

  /* 3. Il resto di quello che porta una data addosso. */
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
  try{ if (typeof prPaint === 'function') prPaint(); }catch(_){ }
  try{ if (typeof scoresRefresh === 'function') scoresRefresh(); }catch(_){ }
  try{ if (typeof sevSyncTab === 'function') sevSyncTab(); }catch(_){ }
  try{ if (typeof pfcPaint === 'function') pfcPaint(); }catch(_){ }
  try{ if (typeof ozPaint === 'function') ozPaint(); }catch(_){ }

  /* 4. Per chiunque altro: un annuncio, così un modulo nuovo non deve toccare questo file. */
  try{ document.dispatchEvent(new CustomEvent('fl:giorno', { detail: ggOggi() })); }catch(_){ }
}

/** Controlla la data e, se è cambiata, rifà tutto. Chiamabile quante volte si vuole. */
function ggControlla(){
  const oggi = ggOggi();
  const visto = ggVisto();
  if (visto === oggi){ ggArma(); return false; }
  try{ localStorage.setItem(GG_KEY, oggi); }catch(_){ }
  /* Senza una data segnata è il primissimo avvio: non c'è niente da ridisegnare, la pagina
     sta nascendo adesso. */
  if (visto) ggRidisegna();
  ggArma();
  return !!visto;
}

function ggArma(){
  clearTimeout(GG_TIMER);
  GG_TIMER = setTimeout(function(){
    try{ localStorage.setItem(GG_KEY, ggOggi()); }catch(_){ }
    ggRidisegna();
    ggArma();
  }, ggQuantoManca());
}

/* Le tre strade per accorgersene, in ordine di affidabilità sul telefono vero:
   tornare in primo piano, riprendere il fuoco, e — ultima — il timer. */
document.addEventListener('visibilitychange', function(){ if (!document.hidden) ggControlla(); });
window.addEventListener('focus', ggControlla);
window.addEventListener('pageshow', ggControlla);

/* Alla partenza si registra solo la data: la pagina si sta già disegnando da sola. */
(function ggAvvio(){
  try{ localStorage.setItem(GG_KEY, ggOggi()); }catch(_){ }
  ggArma();
})();
