/* ===========================================================================================
   LO SPECCHIO: il computer vede quello che il telefono ha fatto

   IL DIFETTO, detto com'è. Sul computer la Roadmap diceva «Il tuo viaggio comincia qui», come
   se l'onboarding non fosse mai stato fatto; mancavano «Prevedi il tuo futuro» e «La tua
   mappa»; la priorità di oggi era un'altra; il pannello di panoramica del Blocco e i tre
   punteggi del Profilo non comparivano affatto.

   LA CAUSA è una sola, e vale per tutti e quattro. Il computer è una WebView2 con il **suo**
   archivio locale: la lettura del Genio, il piano del giorno, le note, le serie — tutto quello
   che l'app tiene in `localStorage` — sul computer semplicemente non c'è mai arrivato. Il
   telefono lo pubblica già per intero (`flWebDump()` mette ogni chiave `fl_` dentro alla riga
   `fl:mobile-rules`), ma dall'altra parte nessuno lo rileggeva: il programma del computer di
   quella riga prende solo le regole di blocco, e il resto lo ignora.

   Poi ce n'è una seconda, indipendente: `getDayReport` non esiste nel motore del computer.
   Senza, `scBlockScores()` esce subito — niente panoramica — e i tre punteggi non hanno numeri
   da mostrare. La giornata del telefono la può raccontare solo il telefono, quindi la spedisce
   lui dentro alla riga della dopamina, e qui si legge.

   LA DIREZIONE È UNA SOLA: telefono → computer. Il telefono è il posto dove si vive l'app e
   dove ci sono i permessi di misura; il computer è una finestra su quella vita, più le sue
   regole di blocco. Per questo qui non si scrive mai niente nell'account.
   =========================================================================================== */

const SW_SLOT = 'fl:mobile-rules';
const SW_SLOT_DOPA = 'fl:dopamina';
const SW_TIMBRO = 'fl_specchio_at';
const SW_OGNI = 4 * 60000;
let SW_ULTIMO = 0, SW_PRIMA = true, SW_INCORSO = null;

/* Le chiavi che NON si copiano: parlano di questo dispositivo, non della persona. */
const SW_NO = [
  'fl_pc_usage', 'fl_altro_usage',      // le cache dei dati dell'altro: ognuno legge la sua riga
  'fl_tab', 'fl_screen',                // dove eri, non chi sei
  'fl_regole_cache',                    // ha il suo confronto a timbro, in regole-cache.js
  'fl_rules_pub', 'fl_rules_pub_v2', 'fl_backup_at', 'fl_specchio_at',
  'fl_arbitro_visti',                   // gli eventi vanno applicati una volta per dispositivo
  /* IL TABELLONE NON SI COPIA, MAI.
     La partita ha gia' il suo protocollo fra dispositivi (livescore.js): ognuno tiene il
     conto di quello che ha segnato LUI, e il totale e' la somma. Riversare il tabellone del
     telefono dentro al computer vuol dire dargli come «suo contributo» dei punti che il
     telefono ha gia' dichiarato: alla somma successiva valgono due volte. E' cosi' che un
     8-8 e' diventato 16-16 il 22/09. */
  'fl_match', 'fl_match_hist', 'fl_match_cfg', 'fl_match_lastday', 'fl_match_epoch',
  'fl_match_sync', 'dbdev_id',
  /* 0.9.302: le scelte di questo dispositivo (da quale dispositivo leggere i numeri: di serie ognuno guarda se stesso)
     e i segni della foto stessa (l'elenco delle chiavi, l'impronta, il reset gia' applicato qui) */
  'fl_rep_fonte', 'fl_due_dispositivi', 'fl_specchio_chiavi', 'fl_rules_pub_impronta', 'fl_reset_visto', 'fl_specchio_giorno',
  /* 0.9.303: la scelta del report e' una sola per i due dispositivi, ma viaggia nella sua riga (fl:rep-scelta, motore-web.js)
     con il momento in cui e' stata fatta: copiata da qui, quella vecchia del telefono coprirebbe una scelta nuova del computer */
  'fl_rep_unione', 'fl_rep_scelta_t',
  /* 0.9.306: le pagine gia' disegnate di questo dispositivo (si mostrano subito all'apertura) */
  'fl_dopa_pagina', 'fl_pfc_corpi', 'fl_pfc_giorni'
];
function swSalta(k){
  if (SW_NO.indexOf(k) >= 0) return true;
  return /^fl_(perm|cap)/.test(k);      // i permessi non si ereditano: qui non ci sono
}

/** Questo è il dispositivo che guarda (il computer) e non quello che misura (il telefono)? */
function swSpecchio(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return false;
    /* «Esiste getDayReport?» non distingue piu' niente: gliela innesta motore-web.js. La
       domanda e' se sotto c'e' un motore vero o la nostra ricostruzione. */
    if (typeof mwSoloWeb === 'function') return mwSoloWeb();
    return typeof NATIVE.getDayReport !== 'function';
  }catch(_){ return false; }
}

/**
 * I gruppi del telefono e quelli di qui, in una lista sola.
 * Torna il JSON unito, o null se non c'e' niente di nuovo.
 */
function swGruppiUniti(suoJson){
  let suo = {}, mio = {};
  try{ suo = JSON.parse(suoJson || '{}') || {}; }catch(_){ suo = {}; }
  try{ mio = JSON.parse(localStorage.getItem('fl_groups') || '{}') || {}; }catch(_){ mio = {}; }
  const out = {};
  let cambiato = false;
  const chiavi = Object.keys(mio).concat(Object.keys(suo)).filter(function(v, i, a){ return a.indexOf(v) === i; });
  chiavi.forEach(function(g){
    const m = mio[g] || {}, t = suo[g] || {};
    out[g] = {};
    ['apps', 'sites', 'words'].forEach(function(campo){
      const a1 = Array.isArray(m[campo]) ? m[campo] : [];
      const a2 = Array.isArray(t[campo]) ? t[campo] : [];
      const uniti = a1.concat(a2.filter(function(x){ return a1.indexOf(x) < 0; }));
      out[g][campo] = uniti;
      if (uniti.length !== a1.length) cambiato = true;
    });
  });
  return cambiato ? JSON.stringify(out) : null;
}

/** I check-in del telefono piu' quelli fatti qui (dev 'computer') che il telefono non ha. Null se non cambia niente. */
function swCheckinUniti(suoJson){
  let suo = [], mio = [];
  try{ suo = JSON.parse(suoJson || '[]') || []; }catch(_){ suo = []; }
  try{ mio = JSON.parse(localStorage.getItem('fl_dopa_checkin') || '[]') || []; }catch(_){ mio = []; }
  if (!Array.isArray(suo)) suo = [];
  const qui = (Array.isArray(mio) ? mio : []).filter(function(c){
    return c && c.dev === 'computer' && !suo.some(function(x){ return x && x.t === c.t && x.delta === c.delta; });
  });
  const out = JSON.stringify(suo.concat(qui).sort(function(a, b){ return (a && a.t || 0) - (b && b.t || 0); }).slice(-200));
  return out === localStorage.getItem('fl_dopa_checkin') ? null : out;
}

async function swRiga(slot){
  const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
  return ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === slot; })[0] || null;
}
async function swPayload(riga){
  const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
  return (pieno && pieno.payload) || null;
}

/* ---------------------------------------------------------------------------------------
   LA GIORNATA DEL TELEFONO, che qui non si può misurare
   --------------------------------------------------------------------------------------- */
const SW_GIORNO = { rep: null, sc: null, at: 0, stamp: 0 };
const SW_CACHE = 'fl_specchio_giorno';

/* SUBITO, NON FRA DUE MINUTI.
   La giornata arriva dall'account, e una chiamata di rete all'avvio vuol dire pannelli vuoti
   per un tempo che a chi guarda sembra un guasto — Andrea li ha visti comparire minuti dopo.
   L'ultima fotografia si tiene su disco: alla riapertura i pannelli sono disegnati prima che
   la rete risponda, e quando risponde si aggiornano. */
(function swDallaCache(){
  try{
    const v = JSON.parse(localStorage.getItem(SW_CACHE) || 'null');
    if (!v || !v.rep) return;
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    if (v.rep.dayStart !== oggi.getTime()) return;
    SW_GIORNO.rep = v.rep; SW_GIORNO.sc = v.sc || null; SW_GIORNO.stamp = v.stamp || 0;
  }catch(_){ }
})();

/**
 * `scReport(0)` sul computer non ha un motore a cui chiedere. Qui gli si mette in mano quello
 * che il telefono ha pubblicato: gli stessi campi, con l'etichetta di dove arrivano.
 */
(function swReportAggancia(){
  if (typeof scReport !== 'function' || scReport.__sw) return;
  const o = scReport;
  const w = async function(off){
    const r = await o.apply(this, arguments);
    if (r) return r;
    if (!swSpecchio()) return r;
    if ((off || 0) !== 0 || !SW_GIORNO.rep) return r;
    return SW_GIORNO.rep;
  };
  w.__sw = true;
  scReport = w;
})();

async function swGiornata(){
  /* 0.9.303: PERCHE' LA GIORNATA NON C'E'. Il 28/10 il Profilo del computer diceva "il telefono oggi non ha ancora
     mandato i suoi dati" con il telefono usato tutta la mattina: era il computer a essere scollegato dall'account dal
     20/10 (Google rifiutava il rinnovo silenzioso, "interaction_required"), e ogni lettura qui sotto finiva nel catch
     in silenzio. Il motivo si tiene, cosi' il Profilo dice la cosa vera e offre l'accesso. */
  SW_GIORNO.errore = '';
  try{
    let riga = null;
    try{ riga = await swRiga(SW_SLOT_DOPA); }
    catch(e){
      const m = String((e && e.message) || e || '');
      SW_GIORNO.errore = /accesso scaduto|accedi con google|401/i.test(m) ? 'accesso' : 'rete';
      return false;
    }
    if (!riga) return false;
    const p = await swPayload(riga);
    const d = p && ((p.web && p.web.dopamina) || p.dopamina);
    if (!d || !d.rep) return false;
    /* Solo la giornata di oggi: un rapporto di ieri mostrato come oggi sarebbe peggio di
       nessun rapporto. */
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    if (!d.rep.dayStart || d.rep.dayStart !== oggi.getTime()) return false;
    const nuovo = SW_GIORNO.stamp !== d.at;      // stessa fotografia: niente da ridisegnare
    SW_GIORNO.rep = d.rep; SW_GIORNO.sc = d.sc || null; SW_GIORNO.at = Date.now(); SW_GIORNO.stamp = d.at;
    try{ localStorage.setItem(SW_CACHE, JSON.stringify({ rep: d.rep, sc: d.sc || null, stamp: d.at })); }catch(_){ }
    return nuovo;
  }catch(_){ return false; }
}

/* ---------------------------------------------------------------------------------------
   LO SPECCHIO VERO E PROPRIO
   --------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------
   IL RESET DEL TELEFONO ARRIVA ANCHE QUI (0.9.302)

   Andrea: dopo "Ricomincia da capo" il telefono diceva arrivo previsto 18 luglio 2028, il computer ancora 12 giugno
   2028 ("+13 giorni rispetto a ieri"). Due cause, una per verso:
   1. il telefono non rispediva la foto dopo l'onboarding rifatto (regole-sync.js, rsGuardaViaggio);
   2. qui la foto si COPIAVA SOPRA, chiave per chiave, e basta. Il reset sul telefono CANCELLA: la lettura del Genio,
      l'arrivo previsto con il suo storico, la roadmap se non l'hai tenuta. Le chiavi cancellate non sono nella foto,
      quindi qui nessuno le toglieva: il computer restava con il viaggio di prima, e la data di prima.
   Adesso, quando la foto porta un reset (fl_reset_ultimo) che qui non e' ancora stato applicato, il computer toglie
   le chiavi che sul telefono non ci sono piu' (tranne le sue: regole, programmi, scelte di questo dispositivo, quello
   che il reset tiene sempre), copia il resto e si ricarica, come il telefono. Il collegamento resta: l'account non si
   tocca, e il computer resta lo specchio dello stesso telefono.
   --------------------------------------------------------------------------------------- */
const SW_RESET_VISTO = 'fl_reset_visto';
const SW_TIENI_QUI = /^fl_(specchio_|pc_|rep_|due_dispositivi$|reset_visto$|altro_usage$|regole_cache$|rules_pub|mw_|groups$|programs$|backup_at$|device_id$)/;
function swResetDaApplicare(web){
  const suo = +(web && web.fl_reset_ultimo) || 0;
  if (!suo) return 0;
  let visto = 0;
  try{ visto = +localStorage.getItem(SW_RESET_VISTO) || 0; }catch(_){ }
  if (visto >= suo) return 0;
  /* la prima volta con questa versione non si sa quale reset sia gia' passato di qui: vale quello degli ultimi
     trenta giorni (il reset del 28/10 che ha lasciato il computer indietro); uno piu' vecchio si segna e basta */
  if (!visto && Date.now() - suo > 30 * 86400000){ try{ localStorage.setItem(SW_RESET_VISTO, String(suo)); }catch(_){ } return 0; }
  return suo;
}
function swApplicaReset(web){
  let suoi = null;
  try{ suoi = JSON.parse(web.fl_specchio_chiavi || 'null'); }catch(_){ suoi = null; }
  const ci = new Set(Array.isArray(suoi) ? suoi : Object.keys(web));
  const sempre = (typeof RC_SEMPRE !== 'undefined' && Array.isArray(RC_SEMPRE)) ? RC_SEMPRE : [];
  const via = [];
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (!k || k.indexOf('fl_') !== 0 || ci.has(k)) continue;
      if (swSalta(k) || SW_TIENI_QUI.test(k) || /^fl_match/.test(k)) continue;
      if (sempre.some(function(re){ return re.test(k); })) continue;
      via.push(k);
    }
  }catch(_){ }
  via.forEach(function(k){ try{ localStorage.removeItem(k); }catch(_){ } });
  return via.length;
}

async function swSincronizza(forza){
  if (!swSpecchio()) return false;
  if (SW_INCORSO) return SW_INCORSO;
  if (!forza && Date.now() - SW_ULTIMO < SW_OGNI) return false;
  SW_ULTIMO = Date.now();
  SW_INCORSO = (async function(){
    let cambiato = false;
    try{
      const riga = await swRiga(SW_SLOT);
      if (riga){
        const quando = String(riga.updatedAt || '');
        let visto = '';
        try{ visto = localStorage.getItem(SW_TIMBRO) || ''; }catch(_){ }
        if (quando && quando !== visto){
          const p = await swPayload(riga);
          let web = (p && p.web) || null;
          /* 0.9.302: un telefono a meta' dell'onboarding (dopo un reset) non ha ancora un viaggio da mostrare: si
             aspetta la foto dopo, senza segnare questa come vista */
          if (web && String(web.fl_onboarded || '') !== '1') web = null;
          const reset = web ? swResetDaApplicare(web) : 0;
          if (reset){ try{ swApplicaReset(web); }catch(_){ } }
          if (web){
            let n = 0;
            Object.keys(web).forEach(function(k){
              if (!k || k.indexOf('fl_') !== 0 || swSalta(k)) return;
              const v = String(web[k]);
              try{
                /* I GRUPPI SI FONDONO, NON SI SOSTITUISCONO. «Sempre consentiti» e' una
                   preferenza a cui contribuiscono tutti e due i dispositivi: copiare sopra
                   quello del telefono cancellava i siti aggiunti qui — e con loro i permessi
                   che ne nascono. Qui le due liste si uniscono. */
                if (k === 'fl_groups'){
                  const u = swGruppiUniti(v);
                  if (u === null) return;
                  localStorage.setItem(k, u);
                  n++;
                  if (typeof flGroupPush === 'function') flGroupPush();
                  return;
                }
                /* 0.9.306: il carburante guadagnato QUI (respiro, task chiusa nel tempo) non si cancella copiando sopra
                   quello del telefono: le due liste si uniscono (swCheckinUniti) */
                if (k === 'fl_dopa_checkin'){
                  const u = swCheckinUniti(v);
                  if (u === null) return;
                  localStorage.setItem(k, u);
                  n++;
                  return;
                }
                if (localStorage.getItem(k) === v) return;
                localStorage.setItem(k, v);
                n++;
              }catch(_){ }
            });
            try{ localStorage.setItem(SW_TIMBRO, quando); }catch(_){ }
            if (n) cambiato = true;
            if (reset){
              /* come il telefono dopo il reset: la pagina riparte da capo, con il viaggio nuovo */
              try{ localStorage.setItem(SW_RESET_VISTO, String(reset)); }catch(_){ }
              SW_INCORSO = null;
              setTimeout(function(){ try{ location.reload(); }catch(_){ } }, 300);
              return true;
            }
            /* l'arrivo previsto: qui non si calcola (eta.js, etaAutorita), si legge quello del telefono appena arrivato */
            if (n){ try{ if (typeof ETA !== 'undefined' && ETA && typeof etaLeggi === 'function'){ const st = etaLeggi('stato', null); if (st) ETA.stato = st; } }catch(_){ } }
            /* la lista delle spunte arriva dall'altro dispositivo: di oggi resta solo cio' che oggi esiste */
            try{ if (typeof fsPulisciOggi === 'function') fsPulisciOggi(false); }catch(_){ }
          }
        }
      }
    }catch(_){ }
    const g = await swGiornata();
    SW_INCORSO = null;
    if (cambiato || g) swRidisegna();
    SW_PRIMA = false;
    return cambiato;
  })();
  return SW_INCORSO;
}

/**
 * Ridisegnare senza spostare nessuno. Non si cambia scheda: si rimanda l'evento della scheda
 * che è gia' aperta, che è esattamente il segnale che ogni pannello aspetta per rifarsi.
 */
function swRidisegna(){
  let tab = 'blocco';
  try{
    const on = document.querySelector('.tabpage.on');
    if (on && on.id) tab = on.id.replace('tab-', '');
  }catch(_){ }
  /* 0.9.307: il livello del Profilo si ricalcola ADESSO con fl_lv_tel appena arrivato (lvPaintProfile teneva il
     calcolo di prima per trenta secondi), e l'intestazione e la cartina della Mappa leggono il viaggio nuovo */
  try{ if (typeof LV !== 'undefined' && LV) LV.at = 0; }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:tab', { detail: tab })); }catch(_){ }
  [['scBlockScores'], ['pfcPaint'], ['mpPaint'], ['vgSistema'], ['stPaint'], ['spPaint'], ['orPaint'], ['arbPaint'], ['lvPaintProfile'], ['hdrMatchApply']]
    .forEach(function(x){ try{ if (typeof window[x[0]] === 'function') window[x[0]](); }catch(_){ } });
  try{
    if (typeof mpTappeDi === 'function') mpTappeDi().then(function(t){
      try{ MP_TAPPE = t; }catch(_){ }
      try{ if (typeof mpSlideRidisegna === 'function') mpSlideRidisegna(); }catch(_){ }
    }).catch(function(){ });
  }catch(_){ }
}

document.addEventListener('visibilitychange', function(){ if (!document.hidden) swSincronizza(false); });
setTimeout(function(){ swSincronizza(true); }, 400);
setInterval(function(){ if (!document.hidden) swSincronizza(false); }, SW_OGNI);
