/* ===========================================================================================
   QR CODE, in casa (0.9.204)

   Un generatore piccolo e senza rete: modalita' byte, correzione M, versioni 1-10 (fino a
   213 byte: un link di invito ci sta largo). Serve alla card polaroid del profilo. Si usa
   cosi': qrMatrice('testo') → matrice di booleani (true = modulo scuro); qrSvg(testo, px)
   → stringa SVG pronta da mettere in pagina.
   =========================================================================================== */
(function(){
  /* [codeword totali, ec per blocco, [n blocchi, dati per blocco]...] per livello M */
  const V = [null,
    [26, 10, [[1, 16]]], [44, 16, [[1, 28]]], [70, 26, [[1, 44]]], [100, 18, [[2, 32]]], [134, 24, [[2, 43]]],
    [172, 16, [[4, 27]]], [196, 18, [[4, 31]]], [242, 22, [[2, 38], [2, 39]]], [292, 22, [[3, 36], [2, 37]]], [346, 26, [[4, 43], [1, 44]]]
  ];
  const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];
  /* il campo GF(256) con il polinomio 0x11D */
  const EXP = new Array(512), LOG = new Array(256);
  (function(){ let x = 1; for (let i = 0; i < 255; i++){ EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11D; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; })();
  const mul = function(a, b){ return (!a || !b) ? 0 : EXP[LOG[a] + LOG[b]]; };
  function genPoly(n){ let g = [1]; for (let i = 0; i < n; i++){ const ng = new Array(g.length + 1).fill(0); for (let j = 0; j < g.length; j++){ ng[j] ^= g[j]; ng[j + 1] ^= mul(g[j], EXP[i]); } g = ng; } return g; }
  function rs(data, n){
    const g = genPoly(n); const r = new Array(n).fill(0);
    for (let i = 0; i < data.length; i++){ const f = data[i] ^ r[0]; r.shift(); r.push(0); if (f) for (let j = 0; j < n; j++) r[j] ^= mul(g[j + 1], f); }
    return r;
  }
  function bytes(s){ return Array.from(new TextEncoder().encode(String(s))); }
  function dataCap(v){ return V[v][2].reduce(function(t, b){ return t + b[0] * b[1]; }, 0); }
  function versionePer(n){ for (let v = 1; v <= 10; v++){ const cap = dataCap(v) - (v < 10 ? 2 : 3); if (n <= cap) return v; } return 0; }
  function codewords(b, v){
    const bits = []; const push = function(val, n){ for (let i = n - 1; i >= 0; i--) bits.push((val >> i) & 1); };
    push(4, 4); push(b.length, v < 10 ? 8 : 16); b.forEach(function(x){ push(x, 8); });
    const capBits = dataCap(v) * 8;
    for (let i = 0; i < 4 && bits.length < capBits; i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    const out = []; for (let i = 0; i < bits.length; i += 8){ let x = 0; for (let j = 0; j < 8; j++) x = (x << 1) | bits[i + j]; out.push(x); }
    let pad = 0; while (out.length < dataCap(v)){ out.push(pad ? 0x11 : 0xEC); pad ^= 1; }
    /* i blocchi, con la loro correzione, poi interfogliati */
    const blocks = [], ecs = []; let p = 0; const ecN = V[v][1];
    V[v][2].forEach(function(g){ for (let i = 0; i < g[0]; i++){ const d = out.slice(p, p + g[1]); p += g[1]; blocks.push(d); ecs.push(rs(d, ecN)); } });
    const res = []; const maxD = Math.max.apply(null, blocks.map(function(x){ return x.length; }));
    for (let i = 0; i < maxD; i++) blocks.forEach(function(d){ if (i < d.length) res.push(d[i]); });
    for (let i = 0; i < ecN; i++) ecs.forEach(function(e){ res.push(e[i]); });
    return res;
  }
  function bch(val, poly, bitsPoly){ let v = val; for (let i = 31; i >= bitsPoly - 1; i--) if ((v >> i) & 1) v ^= poly << (i - (bitsPoly - 1)); return v; }
  function matrice(testo){
    const b = bytes(testo); const v = versionePer(b.length); if (!v) return null;
    const N = v * 4 + 17;
    const m = []; const fx = [];
    for (let i = 0; i < N; i++){ m.push(new Array(N).fill(false)); fx.push(new Array(N).fill(false)); }
    const set = function(r, c, val){ m[r][c] = !!val; fx[r][c] = true; };
    const finder = function(r0, c0){ for (let r = -1; r <= 7; r++) for (let c = -1; c <= 7; c++){ const rr = r0 + r, cc = c0 + c; if (rr < 0 || cc < 0 || rr >= N || cc >= N) continue; const on = (r >= 0 && r <= 6 && c >= 0 && c <= 6) && (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4)); set(rr, cc, on); } };
    finder(0, 0); finder(0, N - 7); finder(N - 7, 0);
    const al = ALIGN[v];
    al.forEach(function(r0){ al.forEach(function(c0){
      if (fx[r0][c0]) return;
      for (let r = -2; r <= 2; r++) for (let c = -2; c <= 2; c++) set(r0 + r, c0 + c, Math.max(Math.abs(r), Math.abs(c)) !== 1);
    }); });
    for (let i = 8; i < N - 8; i++){ set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    set(N - 8, 8, true);
    /* le zone del formato (e della versione) si riservano adesso, si scrivono dopo la maschera */
    for (let i = 0; i < 9; i++){ if (i < N){ fx[8][i] = true; fx[i][8] = true; } }
    for (let i = 0; i < 8; i++){ fx[8][N - 1 - i] = true; fx[N - 1 - i][8] = true; }
    if (v >= 7) for (let i = 0; i < 6; i++) for (let j = 0; j < 3; j++){ fx[i][N - 11 + j] = true; fx[N - 11 + j][i] = true; }
    /* i dati, a zig-zag dal basso a destra */
    const cw = codewords(b, v); let bi = 0; const tot = cw.length * 8;
    let up = true;
    for (let c = N - 1; c > 0; c -= 2){
      if (c === 6) c--;
      for (let k = 0; k < N; k++){
        const r = up ? N - 1 - k : k;
        for (let d = 0; d < 2; d++){
          const cc = c - d; if (fx[r][cc]) continue;
          let bit = 0; if (bi < tot){ bit = (cw[bi >> 3] >> (7 - (bi & 7))) & 1; } bi++;
          m[r][cc] = !!bit;
        }
      }
      up = !up;
    }
    const MASK = [function(r, c){ return (r + c) % 2 === 0; }, function(r){ return r % 2 === 0; }, function(r, c){ return c % 3 === 0; }, function(r, c){ return (r + c) % 3 === 0; },
      function(r, c){ return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0; }, function(r, c){ return (r * c) % 2 + (r * c) % 3 === 0; },
      function(r, c){ return ((r * c) % 2 + (r * c) % 3) % 2 === 0; }, function(r, c){ return ((r + c) % 2 + (r * c) % 3) % 2 === 0; }];
    function applica(mk){
      const out = m.map(function(row){ return row.slice(); });
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!fx[r][c] && MASK[mk](r, c)) out[r][c] = !out[r][c];
      /* formato: livello M = 00, poi la maschera */
      const f = (0 << 3) | mk; const fb = ((f << 10) | bch(f << 10, 0x537, 11)) ^ 0x5412;
      const bit = function(i){ return (fb >> i) & 1; };
      for (let i = 0; i < 6; i++){ out[8][i] = !!bit(14 - i); out[i][8] = !!bit(i); }
      out[8][7] = !!bit(8); out[8][8] = !!bit(7); out[7][8] = !!bit(6);
      for (let i = 0; i < 7; i++){ out[8][N - 7 + i] = !!bit(6 - i); }
      for (let i = 0; i < 7; i++){ out[N - 1 - i][8] = !!bit(14 - i); }
      out[N - 8][8] = true;
      if (v >= 7){
        const vb = (v << 12) | bch(v << 12, 0x1F25, 13);
        for (let i = 0; i < 18; i++){ const on = !!((vb >> i) & 1); const a = Math.floor(i / 3), bb = i % 3; out[a][N - 11 + bb] = on; out[N - 11 + bb][a] = on; }
      }
      return out;
    }
    function penalita(g){
      let p = 0;
      const run = function(get){ for (let i = 0; i < N; i++){ let n = 1; for (let j = 1; j < N; j++){ if (get(i, j) === get(i, j - 1)){ n++; if (n === 5) p += 3; else if (n > 5) p++; } else n = 1; } } };
      run(function(i, j){ return g[i][j]; }); run(function(i, j){ return g[j][i]; });
      for (let r = 0; r < N - 1; r++) for (let c = 0; c < N - 1; c++){ const x = g[r][c]; if (x === g[r][c + 1] && x === g[r + 1][c] && x === g[r + 1][c + 1]) p += 3; }
      const pat = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], pat2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
      const cerca = function(get){ for (let i = 0; i < N; i++) for (let j = 0; j <= N - 11; j++){ let a = true, b2 = true; for (let k = 0; k < 11; k++){ const x = get(i, j + k) ? 1 : 0; if (x !== pat[k]) a = false; if (x !== pat2[k]) b2 = false; } if (a) p += 40; if (b2) p += 40; } };
      cerca(function(i, j){ return g[i][j]; }); cerca(function(i, j){ return g[j][i]; });
      let dark = 0; for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (g[r][c]) dark++;
      const pct = dark * 100 / (N * N); p += Math.floor(Math.abs(pct - 50) / 5) * 10;
      return p;
    }
    let best = null, bp = Infinity;
    for (let mk = 0; mk < 8; mk++){ const g = applica(mk); const p = penalita(g); if (p < bp){ bp = p; best = g; } }
    return best;
  }
  function svg(testo, px, colore){
    const g = matrice(testo); if (!g) return '';
    const N = g.length, q = 2, S = N + q * 2;
    let d = '';
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (g[r][c]) d += 'M' + (c + q) + ' ' + (r + q) + 'h1v1h-1z';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + S + ' ' + S + '" width="' + (px || 160) + '" height="' + (px || 160) + '" shape-rendering="crispEdges"><rect width="' + S + '" height="' + S + '" fill="#fff"/><path d="' + d + '" fill="' + (colore || '#001E44') + '"/></svg>';
  }
  window.qrMatrice = matrice; window.qrSvg = svg;
})();
