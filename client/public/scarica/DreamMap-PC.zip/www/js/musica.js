/* ===========================================================================================
   LA MUSICA DELL'APP (0.9.254)

   Andrea: i suoni di Duolingo per la gamification, una musica per l'intro, e musiche per
   concentrarsi e dormire come brain.fm. Tutto sintetizzato con Web Audio: niente file, niente
   licenze, niente limiti al mese. (sounds.js resta per la natura registrata: quella sintetica
   faceva schifo. Le note musicali invece si sintetizzano benissimo.)

   - muJingle(nome): giusta, sbagliata, tappa, capitolo, scrigno, serie, moneta, livello.
     Brevi, maggiori, pentatonici: lo stesso vocabolario dei videogiochi.
   - muIntro() / muIntroOff(): la musica dell'intro e dell'onboarding, un giro di quattro
     accordi (I–V–vi–IV) con arpeggio e basso, che sale piano.
   - muTesta(tipo) / muTestaOff(): 'focus' (battimenti binaurali a 14 Hz su un bordone, con
     un pad che respira), 'relax' (8 Hz), 'sonno' (3 Hz, piu' grave, piu' lento). Come brain.fm:
     la differenza fra le due orecchie e' il ritmo che la testa segue. Servono le cuffie.
   =========================================================================================== */
const MU = { ctx: null, master: null, intro: null, testa: null, vol: 0.5 };
function muOk(){
  try{
    if (!MU.ctx){ const C = window.AudioContext || window.webkitAudioContext; if (!C) return false; MU.ctx = new C(); MU.master = MU.ctx.createGain(); MU.master.gain.value = MU.vol; MU.master.connect(MU.ctx.destination); }
    if (MU.ctx.state === 'suspended') MU.ctx.resume();
    return true;
  }catch(_){ return false; }
}
function muMuto(){ try{ return localStorage.getItem('fl_musica_muto') === '1'; }catch(_){ return false; } }
function muMutoSet(v){ try{ localStorage.setItem('fl_musica_muto', v ? '1' : '0'); }catch(_){ } if (v){ muIntroOff(); muSiglaOff(); muDuelloOff(); muTestaOff(); } }
/* una nota: inviluppo corto, con un filtro che la fa suonare come un "pluck" da videogioco */
function muNota(f, t0, dur, gain, tipo, dest){
  try{
    const c = MU.ctx, o = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter();
    o.type = tipo || 'square'; o.frequency.value = f;
    fl.type = 'lowpass'; fl.frequency.setValueAtTime(Math.min(12000, f * 6), t0); fl.frequency.exponentialRampToValueAtTime(Math.max(300, f * 1.5), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(fl); fl.connect(g); g.connect(dest || MU.master); o.start(t0); o.stop(t0 + dur + 0.05);
  }catch(_){ }
}
const MU_N = { C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.00, A4: 440.00, B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.00, B5: 987.77, C6: 1046.5, E6: 1318.5, G6: 1568.0,
  C3: 130.81, E3: 164.81, F3: 174.61, G3: 196.00, A3: 220.00, Bb3: 233.08, Eb4: 311.13 };
/* I JINGLE. Ogni voce: [nota, inizio in secondi, durata, volume]. */
const MU_JINGLE = {
  giusta:   [['E5', 0, .12, .18], ['G5', .1, .12, .18], ['C6', .2, .3, .2]],
  sbagliata:[['E4', 0, .2, .16, 'sawtooth'], ['Eb4', .18, .35, .16, 'sawtooth']],
  moneta:   [['B5', 0, .08, .15], ['E6', .08, .25, .18]],
  tappa:    [['C5', 0, .11, .16], ['E5', .11, .11, .16], ['G5', .22, .11, .16], ['C6', .33, .4, .2], ['G5', .55, .1, .1], ['C6', .65, .5, .2]],
  capitolo: [['C5', 0, .13, .16], ['E5', .13, .13, .16], ['G5', .26, .13, .16], ['C6', .39, .13, .18], ['E6', .52, .13, .18], ['G6', .65, .7, .22], ['E6', .95, .1, .08], ['G6', 1.05, .6, .18]],
  scrigno:  [['G4', 0, .1, .12], ['C5', .1, .1, .12], ['E5', .2, .1, .12], ['G5', .3, .1, .12], ['C6', .4, .1, .14], ['E6', .5, .55, .2], ['C6', .8, .4, .14]],
  serie:    [['A4', 0, .1, .14], ['C5', .1, .1, .14], ['E5', .2, .1, .14], ['A5', .3, .45, .2], ['E5', .6, .1, .1], ['A5', .7, .5, .18]],
  /* 0.9.267: la barra di una missione che si riempie, e la missione finita */
  barra:    [['C5', 0, .07, .11], ['E5', .07, .07, .11], ['G5', .14, .16, .13]],
  missione: [['G5', 0, .1, .15], ['C6', .1, .1, .15], ['E6', .2, .45, .2]],
  /* 0.9.290: la tappa che entra mentre la mappa si ridisegna */
  tic:      [['A5', 0, .045, .07]],
  livello:  [['C5', 0, .1, .14], ['C5', .12, .1, .14], ['C5', .24, .1, .14], ['E5', .36, .2, .16], ['G5', .56, .2, .16], ['C6', .76, .8, .22]]
};
function muJingle(nome){
  if (muMuto() || !muOk()) return;
  const j = MU_JINGLE[nome] || MU_JINGLE.giusta, t = MU.ctx.currentTime + 0.02;
  j.forEach(function(v){ muNota(MU_N[v[0]] || 440, t + v[1], v[2], v[3], v[4] || 'square'); if (!v[4]) muNota((MU_N[v[0]] || 440) * 2, t + v[1], v[2] * .6, v[3] * .25, 'triangle'); });
}
/* L'INTRO: quattro accordi (do, sol, la minore, fa), basso sul primo tempo, arpeggio sopra, un pad sotto. */
function muIntro(){
  if (muMuto() || !muOk() || MU.intro) return;
  const c = MU.ctx;
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.55, c.currentTime + 3); g.connect(MU.master);
  const pad = c.createGain(); pad.gain.value = 0.05; const pf = c.createBiquadFilter(); pf.type = 'lowpass'; pf.frequency.value = 900; pad.connect(pf); pf.connect(g);
  const acc = [['C3', 'E4', 'G4', 'C5'], ['G3', 'B4', 'D5', 'G4'], ['A3', 'C5', 'E5', 'A4'], ['F3', 'A4', 'C5', 'F5']];
  const osc = [];
  const padOsc = function(f){ const o = c.createOscillator(); o.type = 'triangle'; o.frequency.value = f; const d = c.createOscillator(); d.type = 'sine'; d.frequency.value = f * 1.005; o.connect(pad); d.connect(pad); o.start(); d.start(); osc.push(o, d); return [o, d]; };
  const voci = [padOsc(MU_N.C3 * 2), padOsc(MU_N.E4), padOsc(MU_N.G4)];
  let passo = 0;
  const BPM = 96, beat = 60 / BPM;
  const tick = function(){
    const a = acc[Math.floor(passo / 8) % 4], t = c.currentTime + 0.05, k = passo % 8;
    if (k === 0){ muNota(MU_N[a[0]], t, beat * 1.8, 0.13, 'triangle', g); voci[0][0].frequency.setTargetAtTime(MU_N[a[0]] * 2, t, 0.2); voci[0][1].frequency.setTargetAtTime(MU_N[a[0]] * 2.01, t, 0.2); voci[1][0].frequency.setTargetAtTime(MU_N[a[1]], t, 0.2); voci[1][1].frequency.setTargetAtTime(MU_N[a[1]] * 1.005, t, 0.2); voci[2][0].frequency.setTargetAtTime(MU_N[a[2]], t, 0.2); voci[2][1].frequency.setTargetAtTime(MU_N[a[2]] * 1.005, t, 0.2); }
    if (k === 4) muNota(MU_N[a[0]] * 1.5, t, beat * 0.9, 0.09, 'triangle', g);
    const arp = [a[1], a[2], a[3], a[2]][k % 4];
    muNota(MU_N[arp], t, beat * 0.55, k % 2 ? 0.05 : 0.07, 'square', g);
    if (k === 6 && Math.floor(passo / 8) % 4 === 3) muNota(MU_N.E6, t, beat, 0.05, 'sine', g);
    passo++;
  };
  let scr = ''; try{ scr = (document.querySelector('.screen.active') || {}).id || ''; }catch(_){ }
  MU.intro = { g: g, osc: osc, timer: setInterval(tick, beat * 500), scr: scr };
  tick();
}
function muIntroOff(){
  const i = MU.intro; if (!i) return; MU.intro = null;
  clearInterval(i.timer);
  try{ const t = MU.ctx.currentTime; i.g.gain.cancelScheduledValues(t); i.g.gain.setValueAtTime(Math.max(0.0001, i.g.gain.value), t); i.g.gain.exponentialRampToValueAtTime(0.0001, t + 1.5); }catch(_){ }
  setTimeout(function(){ try{ i.osc.forEach(function(o){ o.stop(); }); i.g.disconnect(); }catch(_){ } }, 1700);
}
/* LA SIGLA DELLA INTRO (0.9.329, Andrea: "per la intro quel suono non e' l'ideale: scegline uno dalla mia libreria; quello di adesso solo al bivio, e dopo la scelta il carillon").
   E' "Northern Horizon" della libreria del sito (relax, hopeful, 64 bpm): due minuti e venti dentro all'app, cosi' parte subito e anche senza rete. Gira da sola, con l'attacco e la coda in dissolvenza. */
/* 0.9.340, Andrea: "negli episodi e nella revisione della sera c'e' lo stesso suono dell'intro dell'onboarding: ogni scena
   deve avere la sua musica, come le missioni di Call of Duty, e non tutte devono essere stimolanti". Tre tracce della
   libreria, scelte per la scena e dentro all'APK: l'intro resta "Northern Horizon" (speranza), gli episodi "Morning Bloom"
   (sognante, morbida), la revisione della sera "Midnight Atlas" (serena, da fine giornata). E "partono in quinta": ogni file
   ha adesso un crescendo di otto secondi che parte dal silenzio e una coda che sfuma, e il lettore sale piano anche lui. */
const MU_SCENE = { intro: 'audio/intro.mp3', episodio: 'audio/episodio.mp3', sera: 'audio/sera.mp3' };
function muScenaDi(){
  let m = ''; try{ m = (typeof GN !== 'undefined' && GN.on) ? (GN.modo || '') : ''; }catch(_){ m = ''; }
  if (m === 'epi' || m === 'dq') return 'episodio';
  if (m === 'rv') return 'sera';
  return 'intro';
}
async function muSigla(scena){
  scena = MU_SCENE[scena] ? scena : muScenaDi();
  if (muMuto() || !muOk()) return;
  if (MU.sigla){ if (MU.sigla.scena === scena) return; muSiglaOff(); }
  const c = MU.ctx, g = c.createGain();
  g.gain.setValueAtTime(0, c.currentTime); g.connect(MU.master);
  const s = { g: g, src: null, scena: scena, scr: (function(){ try{ const x = document.querySelector('.screen.active'); return x ? x.id : ''; }catch(_){ return ''; } })() };
  MU.sigla = s;
  try{
    MU.siglaBufs = MU.siglaBufs || {};
    if (!MU.siglaBufs[scena]){ const r = await fetch(MU_SCENE[scena]); MU.siglaBufs[scena] = await c.decodeAudioData(await r.arrayBuffer()); }
    if (MU.sigla !== s) return;
    const src = c.createBufferSource(); src.buffer = MU.siglaBufs[scena]; src.loop = true; src.connect(g); src.start();
    s.src = src;
    /* il crescendo e' gia' nel file: qui il volume sale in un secondo e mezzo, senza scatti */
    g.gain.setValueAtTime(0, c.currentTime); g.gain.linearRampToValueAtTime(1.6, c.currentTime + 1.5);
  }catch(_){ if (MU.sigla === s) MU.sigla = null; }
}
function muSiglaOff(){
  const s = MU.sigla; if (!s) return; MU.sigla = null;
  /* la coda: tre secondi che scendono, non un taglio */
  try{ const t = MU.ctx.currentTime; s.g.gain.cancelScheduledValues(t); s.g.gain.setValueAtTime(Math.max(0.0001, s.g.gain.value), t); s.g.gain.exponentialRampToValueAtTime(0.0001, t + 3); }catch(_){ }
  setTimeout(function(){ try{ if (s.src) s.src.stop(); s.g.disconnect(); }catch(_){ } }, 3200);
}
/* IL DUELLO (0.9.329, Andrea: "come in Clash Royale i suoni, e una musica in stile quiz televisivo che concentri e non tolga energie"). Scritta qui: un basso che pulsa piano,
   un giro minore lento e un ticchettio appena sotto. Niente melodia da seguire: la testa deve stare sulla domanda. */
function muDuello(){
  if (MU.duello || muMuto() || !muOk()) return;
  let no = false; try{ no = localStorage.getItem('fl_duello_muto') === '1'; }catch(_){ }
  if (no) return;
  const c = MU.ctx, g = c.createGain();
  g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.42, c.currentTime + 1.2); g.connect(MU.master);
  const giro = [[110, 220, 261.63, 329.63], [87.31, 174.61, 261.63, 349.23], [73.42, 146.83, 220, 293.66], [82.41, 164.81, 246.94, 329.63]];
  const beat = 60 / 76;
  let passo = 0;
  const tick = function(){
    if (!MU.duello) return;
    const a = giro[Math.floor(passo / 8) % 4], t = c.currentTime + 0.03, k = passo % 8;
    if (k % 2 === 0) muNota(a[0], t, beat * .9, .2, 'sine', g);
    if (k === 0 || k === 4) [a[1], a[2], a[3]].forEach(function(f){ muNota(f, t, beat * 3.6, .028, 'triangle', g); });
    if (k === 3 || k === 7) muNota(a[2] * 2, t, beat * .5, .012, 'sine', g);
    muNota(1760, t, .03, .006, 'sine', g);
    passo++;
  };
  MU.duello = { g: g, timer: setInterval(tick, beat * 500) };
  tick();
}
function muDuelloOff(){
  const d = MU.duello; if (!d) return; MU.duello = null;
  clearInterval(d.timer);
  try{ const t = MU.ctx.currentTime; d.g.gain.cancelScheduledValues(t); d.g.gain.setValueAtTime(Math.max(0.0001, d.g.gain.value), t); d.g.gain.exponentialRampToValueAtTime(0.0001, t + .6); }catch(_){ }
  setTimeout(function(){ try{ d.g.disconnect(); }catch(_){ } }, 800);
}
/* LE FARFALLE (0.9.288, Andrea: "in Until Dawn, quando volano le farfalle, c'e' una musica particolare che fa capire che
   il corso del futuro e' appena cambiato"). Non l'intro allegra: un bordone basso che cresce (la minore), un carillon
   lento con l'eco che sale di un'ottava, e una nota sospesa alla fine, che non si risolve. Sette secondi, quanto il volo. */
function muFarfalla(){
  if (muMuto() || !muOk()) return;
  muFarfallaOff();
  const c = MU.ctx, t = c.currentTime + 0.03;
  const out = c.createGain(); out.gain.setValueAtTime(0.0001, t); out.gain.exponentialRampToValueAtTime(0.9, t + 0.6); out.connect(MU.master);
  /* l'eco: un ritardo con ritorno, filtrato, per il suono "lontano" del carillon */
  const eco = c.createDelay(1.5); eco.delayTime.value = 0.36;
  const ritorno = c.createGain(); ritorno.gain.value = 0.42;
  const fe = c.createBiquadFilter(); fe.type = 'lowpass'; fe.frequency.value = 2600;
  eco.connect(fe); fe.connect(ritorno); ritorno.connect(eco); fe.connect(out);
  const carillon = c.createGain(); carillon.gain.value = 1; carillon.connect(out); carillon.connect(eco);
  /* il bordone: la e mi, due onde quasi uguali che battono piano */
  const bordone = c.createGain(); bordone.gain.setValueAtTime(0.0001, t); bordone.gain.exponentialRampToValueAtTime(0.07, t + 2.4); bordone.gain.exponentialRampToValueAtTime(0.0001, t + 7.4);
  const fb = c.createBiquadFilter(); fb.type = 'lowpass'; fb.frequency.setValueAtTime(300, t); fb.frequency.exponentialRampToValueAtTime(1400, t + 4);
  bordone.connect(fb); fb.connect(out);
  const osc = [];
  [[110, 'sawtooth'], [110.6, 'sawtooth'], [164.81, 'triangle'], [220, 'sine']].forEach(function(v){ const o = c.createOscillator(); o.type = v[1]; o.frequency.value = v[0]; o.connect(bordone); o.start(t); o.stop(t + 7.6); osc.push(o); });
  /* il carillon: la do mi, poi sale (si, do, mi), e si ferma sospeso su re */
  const note = [[880, 0.3], [1046.5, 0.75], [1318.5, 1.2], [987.77, 1.9], [1046.5, 2.35], [1318.5, 2.8], [1760, 3.5], [1174.66, 4.4]];
  note.forEach(function(n, i){ muNota(n[0], t + n[1], i === note.length - 1 ? 2.6 : 1.1, i === note.length - 1 ? 0.07 : 0.055, 'sine', carillon); muNota(n[0] * 2, t + n[1], 0.5, 0.012, 'triangle', carillon); });
  MU.farfalla = { out: out, osc: osc, fine: setTimeout(function(){ muFarfallaOff(); }, 7600) };
}
function muFarfallaOff(){
  const f = MU.farfalla; if (!f) return; MU.farfalla = null;
  clearTimeout(f.fine);
  try{ const t = MU.ctx.currentTime; f.out.gain.cancelScheduledValues(t); f.out.gain.setValueAtTime(Math.max(0.0001, f.out.gain.value), t); f.out.gain.exponentialRampToValueAtTime(0.0001, t + 1.2); }catch(_){ }
  setTimeout(function(){ try{ f.osc.forEach(function(o){ try{ o.stop(); }catch(_){ } }); f.out.disconnect(); }catch(_){ } }, 1400);
}
/* PER LA TESTA: battimenti binaurali. Sinistra f, destra f + delta: la differenza e' il ritmo
   che il cervello segue (14 Hz beta per il lavoro, 8 Hz alfa per rilassarsi, 3 Hz delta per
   dormire). Sotto, un bordone con due armonici e un pad che respira lentamente. */
const MU_TESTA = {
  focus: { f: 220, delta: 14, pad: [MU_N.A3, MU_N.E4, MU_N.A4], respiro: 9, vol: 0.5, n: 'Concentrazione', d: 'Battimenti a 14 Hz, per lavorare' },
  relax: { f: 174, delta: 8, pad: [MU_N.F3, MU_N.C4 || 261.63, MU_N.A4], respiro: 13, vol: 0.45, n: 'Rilassamento', d: 'Battimenti a 8 Hz, per staccare' },
  sonno: { f: 110, delta: 3, pad: [MU_N.C3, MU_N.G3, MU_N.E4], respiro: 18, vol: 0.4, n: 'Sonno', d: 'Battimenti a 3 Hz, per addormentarsi' }
};
function muTesta(tipo){
  if (!muOk()) return false;
  muTestaOff();
  const P = MU_TESTA[tipo] || MU_TESTA.focus, c = MU.ctx;
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(P.vol, c.currentTime + 4); g.connect(MU.master);
  const osc = [];
  const lato = function(f, pan){
    const o = c.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    const gg = c.createGain(); gg.gain.value = 0.22;
    let p = null; try{ p = c.createStereoPanner(); p.pan.value = pan; }catch(_){ }
    o.connect(gg); if (p){ gg.connect(p); p.connect(g); } else gg.connect(g);
    o.start(); osc.push(o);
  };
  lato(P.f, -1); lato(P.f + P.delta, 1);
  /* il pad che respira */
  const pad = c.createGain(); pad.gain.value = 0.0001; const pf = c.createBiquadFilter(); pf.type = 'lowpass'; pf.frequency.value = 700; pad.connect(pf); pf.connect(g);
  P.pad.forEach(function(f){ const o = c.createOscillator(); o.type = 'triangle'; o.frequency.value = f; o.detune.value = (Math.random() - 0.5) * 8; o.connect(pad); o.start(); osc.push(o); });
  const lfo = c.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 1 / P.respiro; const lg = c.createGain(); lg.gain.value = 0.06; lfo.connect(lg); lg.connect(pad.gain); lfo.start(); osc.push(lfo);
  pad.gain.setValueAtTime(0.07, c.currentTime);
  MU.testa = { g: g, osc: osc, tipo: tipo };
  return true;
}
function muTestaOff(){
  const x = MU.testa; if (!x) return; MU.testa = null;
  try{ const t = MU.ctx.currentTime; x.g.gain.cancelScheduledValues(t); x.g.gain.setValueAtTime(Math.max(0.0001, x.g.gain.value), t); x.g.gain.exponentialRampToValueAtTime(0.0001, t + 2); }catch(_){ }
  setTimeout(function(){ try{ x.osc.forEach(function(o){ o.stop(); }); x.g.disconnect(); }catch(_){ } }, 2200);
}
function muVolume(v){ MU.vol = Math.max(0, Math.min(1, v)); try{ if (MU.master) MU.master.gain.setTargetAtTime(MU.vol, MU.ctx.currentTime, 0.05); }catch(_){ } }
/* ---- i ganci: la tappa, lo scrigno, l'esercizio, la serie ---- */
(function(){
  if (typeof sdFineApri === 'function'){ const v = sdFineApri; window.sdFineApri = sdFineApri = function(nd, det){ const r = v.apply(this, arguments); try{ muJingle('tappa'); }catch(_){ } return r; }; }
  if (typeof sdScrignoApri === 'function'){ const v2 = sdScrignoApri; window.sdScrignoApri = sdScrignoApri = function(){ const r = v2.apply(this, arguments); try{ muJingle('scrigno'); }catch(_){ } return r; }; }
  if (typeof sdSerieApri === 'function'){ const v3 = sdSerieApri; window.sdSerieApri = sdSerieApri = function(){ const r = v3.apply(this, arguments); try{ muJingle('serie'); }catch(_){ } return r; }; }
  /* la pagina del Genio si chiude: la musica dell'intro con lei */
  document.addEventListener('fl:screen', function(){ try{ const cur = document.querySelector('.screen.active'); if (MU.intro && cur && cur.id !== MU.intro.scr) muIntroOff(); if (MU.sigla && cur && MU.sigla.scr && cur.id !== MU.sigla.scr) muSiglaOff(); }catch(_){ } });
  document.addEventListener('visibilitychange', function(){ if (document.hidden){ muIntroOff(); muSiglaOff(); muDuelloOff(); } else { try{ if (typeof DSO !== 'undefined' && DSO.g && document.getElementById('dsoG') && document.querySelector('#dsoG .dso-g-t')) muDuello(); }catch(_){ } } });
})();
