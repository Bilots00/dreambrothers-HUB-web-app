/* ===========================================================================================
   IL MOTORE CHE IMPARA

   COSA C'ERA PRIMA. Il Genio faceva una lettura bayesiana vera — otto profili, quattordici
   domande, kernel gaussiano, domanda scelta a massimo guadagno d'informazione — e poi buttava
   via tutto. Del vettore delle probabilità restava solo il nome del vincitore; la percentuale
   finale era una media a pesi fissi fra il quiz e una manciata di contatori. Da quel momento
   in poi il numero non si muoveva più, qualunque cosa la persona facesse. Era un oroscopo con
   della matematica dentro.

   COSA FA ADESSO, in quattro pezzi che si tengono per mano:

   1. IL VETTORE SOPRAVVIVE. Le otto probabilità restano, e ogni giorno vengono aggiornate con
      la stessa regola di Bayes del quiz — solo che al posto delle risposte ci sono i FATTI:
      quanto schermo, quante riprese compulsive, quanto dopo mezzanotte, se hai scritto il
      piano, se l'hai fatto, se hai mollato una sessione, se hai ceduto a un blocco, quanto del
      tuo computer è stato lavoro. Rispondere a un quiz una volta è un'opinione su di sé; fare
      la stessa cosa per trenta giorni è una prova.

   2. UN MODELLO CHE SI ALLENA SU DI TE. Una regressione logistica online (discesa del
      gradiente, un passo al giorno) che prevede UNA cosa verificabile: domani terrai la
      promessa che hai scritto? I pesi partono da quelli scritti a mano — così funziona anche
      il primo giorno — e giorno dopo giorno si spostano verso quello che conta DAVVERO per
      questa persona. Per uno conterà l'ora in cui va a letto, per un altro se ha scritto il
      piano la sera prima: sono cose diverse, e un peso fisso le tratterebbe uguali.

   3. LA CALIBRAZIONE — ed è qui che il motore impara dai propri errori, come il genio di
      Akinator quando sbaglia personaggio. Ogni previsione viene messa per iscritto con la sua
      data. Quando quella data arriva, la verità si conosce, e la coppia (previsto, successo)
      entra in una correzione di Platt: due parametri, aggiornati anche loro a gradiente. Se
      l'app è sistematicamente ottimista con te, impara a smorzarsi. Il numero che si vede non
      è mai «la previsione grezza»: è la previsione corretta di quanto si è sbagliata finora,
      e quel quanto si può leggere.

   4. «CHI STAVI PENSANDO?» Quando il profilo è sbagliato, lo si dice, e le risposte date
      diventano un esempio etichettato: le verosimiglianze di QUEL profilo si spostano verso
      quelle risposte. Le tabelle spedite con l'app non si toccano mai — le correzioni vivono a
      parte, così restano leggibili, reversibili e non si sommano all'infinito.

   DOVE FINISCE L'ONESTÀ E COMINCIA LA PUBBLICITÀ. Questo è un modello piccolo, che gira sul
   telefono, senza rete e senza server. Non «capisce» niente: pesa delle prove. Quello che sa
   fare davvero è misurare quanto si sbaglia e correggersi, che è l'unica forma di
   intelligenza che si può verificare. Il ragionamento vero — leggere una giornata intera e
   dire cosa è successo — lo fa Jordan, che è un modello grande e sta sul VPS; questo motore
   prepara le prove, Jordan le legge, e quello che Jordan risponde torna qui come un'altra
   prova, non come un verdetto.
   =========================================================================================== */

const PV_KEY = 'fl_prev';

/* Quanto conta un giorno di prove contro la lettura del quiz.
   Basso di proposito: una giornata storta non deve riscrivere chi sei, ma trenta giornate
   storte sì. Con 0.22 servono circa dieci giorni coerenti per spostare il profilo. */
const PV_PESO_GIORNO = 0.22;

/* Il richiamo verso la lettura del quiz. Senza, trenta giorni di rumore porterebbero il
   vettore ovunque; con questo, il quiz resta l'ancora e i fatti la corrente. */
const PV_RICHIAMO = 0.04;

const PV_SIGMA = 0.33;          // la stessa larghezza del kernel del quiz: stessa scala
const PV_LR = 0.08;             // passo della discesa del gradiente
const PV_L2 = 0.02;             // richiamo dei pesi verso quelli di partenza
const PV_LR_CAL = 0.05;         // passo della calibrazione

/* ---------------------------------------------------------------------------------------
   I SEGNALI

   Ogni segnale è un numero fra 0 e 1: «quanto, oggi, questa persona somiglia a un sì».
   `e` è la tabella delle attese per profilo — la stessa forma delle domande del quiz, perché è
   la stessa matematica: un fatto osservato e una risposta data valgono uguale, se sono
   entrambi prove.

   `w` è il peso di partenza nella regressione logistica, con il segno: positivo = spinge verso
   «domani terrai la promessa».

   Gli id dei profili, nell'ordine: proc inc sogn reat nott equi disc real.
   --------------------------------------------------------------------------------------- */
const PV_SEGNALI = [
  { k: 'schermo', nome: 'Tempo di schermo', w: -0.9,
    d: 'Quanto è stato lungo il tempo davanti al telefono, rispetto a tre ore.',
    e: { proc: .85, inc: .7, sogn: .6, reat: .85, nott: .8, equi: .5, disc: .3, real: .15 } },

  { k: 'lampi', nome: 'Aperture a vuoto', w: -1.1,
    d: 'Quante volte hai aperto e chiuso un\'app entro mezzo minuto: il gesto, non il tempo.',
    e: { proc: .85, inc: .65, sogn: .6, reat: .95, nott: .7, equi: .5, disc: .3, real: .1 } },

  { k: 'notte', nome: 'Schermo dopo mezzanotte', w: -0.8,
    d: 'Minuti di telefono fra mezzanotte e le cinque.',
    e: { proc: .6, inc: .5, sogn: .5, reat: .6, nott: .95, equi: .4, disc: .25, real: .1 } },

  { k: 'piano', nome: 'Il piano scritto', w: 1.3,
    d: 'Hai deciso in anticipo cosa avresti fatto.',
    e: { proc: .1, inc: .4, sogn: .35, reat: .15, nott: .25, equi: .5, disc: .85, real: .95 } },

  { k: 'fatte', nome: 'Task portate a termine', w: 1.5,
    d: 'Quante delle cose scritte hai davvero spuntato.',
    e: { proc: .1, inc: .3, sogn: .25, reat: .3, nott: .3, equi: .5, disc: .8, real: .95 } },

  { k: 'sessioni', nome: 'Sessioni tenute', w: 1.4,
    d: 'Sessioni di concentrazione completate rispetto a quelle cominciate.',
    e: { proc: .15, inc: .3, sogn: .3, reat: .25, nott: .35, equi: .55, disc: .8, real: .95 } },

  { k: 'ceduto', nome: 'Blocchi interrotti', w: -1.4,
    d: 'Quante volte hai tolto un muro che ti eri messo da solo.',
    e: { proc: .8, inc: .65, sogn: .6, reat: .8, nott: .6, equi: .45, disc: .2, real: .07 } },

  { k: 'pclavoro', nome: 'Lavoro vero al computer', w: 1.2,
    d: 'Quanta parte delle ore al computer è finita su cose che hai marcato come lavoro.',
    e: { proc: .15, inc: .35, sogn: .3, reat: .3, nott: .4, equi: .55, disc: .8, real: .92 } },

  { k: 'partita', nome: 'La partita', w: 1.0,
    d: 'Quanti punti ha segnato il nuovo te rispetto al vecchio.',
    e: { proc: .15, inc: .35, sogn: .35, reat: .3, nott: .35, equi: .5, disc: .78, real: .93 } }
];

const PV_IDS = ['proc', 'inc', 'sogn', 'reat', 'nott', 'equi', 'disc', 'real'];

/* ---------------------------------------------------------------------------------------
   Lo stato su disco
   --------------------------------------------------------------------------------------- */

function pvVuoto(){
  const w = {};
  PV_SEGNALI.forEach(function(s){ w[s.k] = s.w; });
  return {
    post: null,            // il vettore delle otto probabilità, o null finché non c'è lettura
    ancora: null,          // la lettura del quiz: l'ancora verso cui il vettore viene richiamato
    ultimoGiorno: '',      // l'ultimo giorno già digerito
    w: w, w0: -0.2,        // i pesi della regressione e la sua soglia
    cal: { a: 1, b: 0 },   // la correzione di Platt
    attese: [],            // previsioni fatte e non ancora verificate
    esiti: [],             // {p, y, at} — la memoria degli errori
    corr: {},              // le correzioni «chi stavi pensando»: qid -> profilo -> delta
    giorni: []             // le osservazioni, per i grafici e per riallenare
  };
}

function pvStato(){
  try{
    const s = JSON.parse(localStorage.getItem(PV_KEY) || 'null');
    if (!s) return pvVuoto();
    const base = pvVuoto();
    // Le chiavi nuove non devono far ripartire da zero chi ha già una storia.
    return Object.assign(base, s, { w: Object.assign(base.w, s.w || {}),
                                    cal: Object.assign(base.cal, s.cal || {}) });
  }catch(_){ return pvVuoto(); }
}
function pvScrivi(s){
  try{ localStorage.setItem(PV_KEY, JSON.stringify(s)); }catch(_){ }
}

function pvGiornoKey(off){
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/* ---------------------------------------------------------------------------------------
   MATEMATICA — la stessa del quiz, più quella che serve a imparare
   --------------------------------------------------------------------------------------- */

function pvNorm(v){
  const z = v.reduce(function(a, b){ return a + b; }, 0) || 1;
  return v.map(function(x){ return x / z; });
}

/** Verosimiglianza di un'osservazione contro l'attesa di un profilo. */
function pvLik(osservato, atteso){
  const d = osservato - atteso;
  return Math.exp(-(d * d) / (2 * PV_SIGMA * PV_SIGMA)) + 0.03;
}

function pvSigmoid(z){ return 1 / (1 + Math.exp(-z)); }
function pvLogit(p){
  const q = Math.min(0.999, Math.max(0.001, p));
  return Math.log(q / (1 - q));
}
function pvClamp(x, a, b){ return Math.max(a, Math.min(b, x)); }

/* ---------------------------------------------------------------------------------------
   L'OSSERVAZIONE DI UN GIORNO

   Tutto normalizzato a [0,1], e — questo è il punto delicato — un segnale che non si può
   misurare NON diventa zero: diventa `null`, e viene saltato. Zero vuol dire «misurato, ed era
   niente»; null vuol dire «non lo so». Confonderli significherebbe dire a chi non ha il
   computer collegato che non ha lavorato, che è il modo più veloce per far disinstallare l'app.
   --------------------------------------------------------------------------------------- */

async function pvOsserva(off){
  off = off || 0;
  const giorno = pvGiornoKey(off);
  const o = { giorno: giorno, at: Date.now() };

  // --- il telefono, al granello
  let tl = null;
  try{ if (typeof tlRiassuntoDi === 'function') tl = await tlRiassuntoDi(off); }catch(_){ }
  if (tl && tl.riprese){
    o.schermo = pvClamp(tl.tot / (3 * 3600000), 0, 1);
    o.lampi = pvClamp(tl.lampi / 40, 0, 1);
    o.notte = pvClamp(tl.notte / (60 * 60000), 0, 1);
  }

  // --- il piano: scritto e fatto
  try{
    const done = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
    const fatte = done.filter(function(r){ return r.day === giorno; }).length;
    let righe = 0;
    const foglio = localStorage.getItem('fl_notes_' + giorno);
    if (foglio !== null){
      righe = String(foglio).split('\n').map(function(t){ return t.trim(); }).filter(Boolean).length;
    }
    if (righe > 0 || fatte > 0){
      o.piano = righe > 0 ? 1 : 0;
      o.fatte = righe > 0 ? pvClamp(fatte / righe, 0, 1) : (fatte > 0 ? 1 : 0);
    } else if (foglio !== null){
      o.piano = 0;                    // il foglio c'era, ed era vuoto: è una misura, non un buco
    }
  }catch(_){ }

  // --- le sessioni di concentrazione
  try{
    const hist = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const delGiorno = hist.filter(function(h){ return pvGiornoDi(h.start || h.at) === giorno; });
    if (delGiorno.length){
      o.sessioni = delGiorno.filter(function(h){ return h.ok; }).length / delGiorno.length;
    }
  }catch(_){ }

  // --- le tentazioni a cui hai ceduto
  try{
    const reg = JSON.parse(localStorage.getItem('fl_interrupts_log') || '[]') || [];
    const n = reg.filter(function(r){ return pvGiornoDi(r.at) === giorno; }).length;
    const conta = JSON.parse(localStorage.getItem('fl_interrupts') || '{}') || {};
    if (n > 0 || conta[giorno]) o.ceduto = pvClamp(Math.max(n, 0) / 3, 0, 1);
    else if (Object.keys(conta).length) o.ceduto = 0;   // il registro c'è: zero è uno zero vero
  }catch(_){ }

  // --- il computer
  try{
    if (typeof pcSync === 'function'){
      await pcSync(false);
      const g = (typeof pcGiorno === 'function') ? pcGiorno(off) : null;
      if (g && g.m > 0){
        /* QUANTA GIORNATA HA UN'ETICHETTA.
           Se quasi tutto sta in «neutro» vuol dire che le categorie non sono state impostate,
           non che quella persona non ha lavorato. Misurato sul primo pacchetto vero arrivato da
           un computer: 200 minuti, di cui 192,8 neutri — il rapporto prod/totale faceva 0,007 e
           avrebbe raccontato al motore che chi ha lavorato sei ore non ha fatto niente.
           Un quarto di giornata etichettata e' il minimo perche' il rapporto voglia dire
           qualcosa; sotto, il segnale resta «non lo so» e il motore lo salta. */
        const etichettata = ((g.prod || 0) + (g.distr || 0)) / g.m;
        if (etichettata >= 0.25) o.pclavoro = pvClamp((g.prod || 0) / ((g.prod || 0) + (g.distr || 0)), 0, 1);
      }
    }
  }catch(_){ }

  // --- la partita
  try{
    const h = JSON.parse(localStorage.getItem('fl_match_hist') || '[]') || [];
    const g = h.filter(function(x){ return x.day === giorno; })[0];
    const ev = (g && g.eventi) || [];
    if (ev.length){
      const neo = ev.filter(function(e){ return e.chi === 'neo'; }).length;
      o.partita = neo / ev.length;
    }
  }catch(_){ }

  return o;
}

function pvGiornoDi(ts){
  const d = new Date(ts || 0);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** Quanti segnali sono stati davvero misurati in un'osservazione. */
function pvQuantiSegnali(o){
  return PV_SEGNALI.filter(function(s){ return typeof o[s.k] === 'number'; }).length;
}

/* ---------------------------------------------------------------------------------------
   L'AGGIORNAMENTO BAYESIANO DEL PROFILO
   --------------------------------------------------------------------------------------- */

function pvAggiornaPost(post, o){
  if (!post) return null;
  let v = post.slice();
  PV_SEGNALI.forEach(function(s){
    const x = o[s.k];
    if (typeof x !== 'number') return;      // non misurato: nessuna prova, nessun aggiornamento
    const l = PV_IDS.map(function(id){ return pvLik(x, s.e[id]); });
    /* Il peso del giorno si applica alla verosimiglianza, non al risultato: una prova che vale
       un quinto è una prova attenuata, non un risultato mediato — la differenza si vede dopo
       venti giorni, quando le prove attenuate si sommano correttamente invece di annullarsi. */
    v = v.map(function(p, k){ return p * Math.pow(l[k], PV_PESO_GIORNO); });
    v = pvNorm(v);
  });
  return v;
}

/** Il richiamo verso la lettura del quiz: i fatti muovono, l'ancora trattiene. */
function pvRichiama(post, ancora){
  if (!post || !ancora) return post;
  return pvNorm(post.map(function(p, k){
    return p * (1 - PV_RICHIAMO) + ancora[k] * PV_RICHIAMO;
  }));
}

/* ---------------------------------------------------------------------------------------
   LA REGRESSIONE — «domani terrai la promessa?»
   --------------------------------------------------------------------------------------- */

function pvPredici(s, o){
  let z = s.w0;
  let usati = 0;
  PV_SEGNALI.forEach(function(sg){
    const x = o[sg.k];
    if (typeof x !== 'number') return;
    z += (s.w[sg.k] || 0) * (x - 0.5) * 2;   // centrato: 0.5 è «né sì né no»
    usati++;
  });
  if (!usati) return null;

  /* DUE FRENI, che frenano cose diverse.

     1. QUANTI SEGNALI HO OGGI. Con due misure su nove la previsione si avvicina al 50% invece
        di fingere di sapere: è quello che fa un modello ben calibrato quando gli mancano le
        colonne.

     2. QUANTE VOLTE SONO GIÀ STATO SMENTITO. Questo è il freno che mancava, e si è visto
        provandolo: con i pesi di partenza e una giornata buona il modello diceva 1.00 — «domani
        terrai la promessa, certo» — prima di aver mai osservato un solo giorno di questa
        persona. Una sicurezza non guadagnata, e basta una smentita per non essere più creduti.
        A zero prove le stime si schiacciano verso il mezzo; dopo una quarantina di giorni il
        freno quasi non si sente più. */
  const fiducia = usati / PV_SEGNALI.length;
  const storia = ((s.esiti || []).length);
  const maturita = 0.20 + 0.80 * (storia / (storia + 8));
  const p = pvSigmoid(z * (0.45 + 0.55 * fiducia) * maturita);

  /* E comunque mai una certezza: su una persona, a un giorno di distanza, il 100% non esiste.
     Il tetto vale anche per la calibrazione, che altrimenti si allenerebbe su un logit infinito. */
  return pvClamp(p, 0.05, 0.95);
}

/** La previsione dopo la correzione imparata dagli errori passati. */
function pvCalibra(s, p){
  if (p === null) return null;
  return pvSigmoid(s.cal.a * pvLogit(p) + s.cal.b);
}

/** Un passo di discesa del gradiente su un esempio (osservazione di ieri, esito di oggi). */
function pvImparaPasso(s, o, y){
  const grezza = pvPredici(s, o);
  if (grezza === null) return s;

  // 1. i pesi del modello
  const p = grezza;
  PV_SEGNALI.forEach(function(sg){
    const x = o[sg.k];
    if (typeof x !== 'number') return;
    const xi = (x - 0.5) * 2;
    const g = (p - y) * xi + PV_L2 * ((s.w[sg.k] || 0) - sg.w);
    s.w[sg.k] = pvClamp((s.w[sg.k] || 0) - PV_LR * g, -4, 4);
  });
  s.w0 = pvClamp(s.w0 - PV_LR * (p - y), -3, 3);

  // 2. la calibrazione: quanto il modello, così com'è, si sbaglia
  const L = pvLogit(grezza);
  const pc = pvSigmoid(s.cal.a * L + s.cal.b);
  s.cal.a = pvClamp(s.cal.a - PV_LR_CAL * (pc - y) * L, 0.2, 3);
  s.cal.b = pvClamp(s.cal.b - PV_LR_CAL * (pc - y), -3, 3);

  s.esiti = (s.esiti || []).concat([{ p: Math.round(pc * 1000) / 1000, y: y, at: Date.now() }]).slice(-200);
  return s;
}

/* ---------------------------------------------------------------------------------------
   IL GIRO GIORNALIERO

   Una volta al giorno: si guarda IERI (una giornata finita, non una a metà), si aggiorna il
   profilo, si verifica la previsione che era stata fatta per ieri, e si fa quella per oggi.
   --------------------------------------------------------------------------------------- */

async function pvGiro(){
  const s = pvStato();
  const oggi = pvGiornoKey(0);
  if (s.ultimoGiorno === oggi) return s;

  const ieri = pvGiornoKey(1);
  const o = await pvOsserva(1);
  const misurati = pvQuantiSegnali(o);

  /* Un giorno senza nessuna misura non è un giorno: è un telefono spento, o un'app appena
     installata. Digerirlo insegnerebbe che «non fare niente» è normale. */
  if (misurati > 0){
    if (s.post) s.post = pvRichiama(pvAggiornaPost(s.post, o), s.ancora);

    /* LA VERIFICA. La previsione fatta per ieri adesso si può giudicare: la promessa era
       «domani spunterai almeno una delle cose che hai scritto». È verificabile, è la cosa che
       l'utente ha scelto lui, e non è aggirabile. */
    const attesa = (s.attese || []).filter(function(a){ return a.per === ieri; })[0];
    if (attesa){
      const y = (typeof o.fatte === 'number' && o.fatte > 0) ? 1 : 0;
      pvImparaPasso(s, attesa.o || o, y);
      s.attese = (s.attese || []).filter(function(a){ return a.per !== ieri; });
    }

    s.giorni = (s.giorni || []).filter(function(g){ return g.giorno !== o.giorno; })
      .concat([o]).slice(-60);
  }

  // La previsione per domani, costruita su quello che si sa di oggi.
  try{
    const oggiOss = await pvOsserva(0);
    if (pvQuantiSegnali(oggiOss) > 0){
      const grezza = pvPredici(s, oggiOss);
      if (grezza !== null){
        s.attese = (s.attese || []).filter(function(a){ return a.per !== pvGiornoKey(-1); });
        s.attese.push({ per: pvGiornoKey(-1), p: pvCalibra(s, grezza), o: oggiOss, at: Date.now() });
        s.attese = s.attese.slice(-30);
      }
    }
  }catch(_){ }

  s.ultimoGiorno = oggi;
  pvScrivi(s);
  return s;
}

/* ---------------------------------------------------------------------------------------
   QUANTO CI HA PRESO

   Il numero che rende tutto il resto verificabile invece che suggestivo: su quante previsioni
   ha avuto ragione. Se questo peggiora, il motore sta peggiorando, e si vede.
   --------------------------------------------------------------------------------------- */

function pvBravura(){
  const s = pvStato();
  const e = (s.esiti || []).slice(-60);
  if (e.length < 3) return null;
  const azzeccate = e.filter(function(x){ return (x.p >= 0.5 ? 1 : 0) === x.y; }).length;
  /* Brier: la distanza media al quadrato fra quello che ha detto e quello che è successo.
     Più severo della percentuale di azzeccate, perché punisce anche l'essere sicuri per caso. */
  const brier = e.reduce(function(a, x){ return a + (x.p - x.y) * (x.p - x.y); }, 0) / e.length;
  return { n: e.length, azzeccate: azzeccate, perc: Math.round(azzeccate / e.length * 100),
           brier: Math.round(brier * 1000) / 1000,
           correzione: Math.round((pvCalibra(s, 0.7) - 0.7) * 100) };
}

/* ---------------------------------------------------------------------------------------
   IL PROFILO DI ADESSO
   --------------------------------------------------------------------------------------- */

function pvProfiloOra(){
  const s = pvStato();
  if (!s.post || typeof OR_PROFILES === 'undefined') return null;
  let i = 0;
  s.post.forEach(function(p, k){ if (p > s.post[i]) i = k; });
  return { profilo: OR_PROFILES[i], p: s.post[i], indice: i, post: s.post };
}

/**
 * La probabilità di riuscita, aggiornata.
 *
 * <p>Tre ingredienti, e si vedono tutti e tre: la lettura del quiz (chi hai detto di essere),
 * le prove raccolte da allora (chi ti sei comportato di essere) e la correzione imparata dagli
 * errori del motore stesso.</p>
 */
function pvRiuscita(){
  const s = pvStato();
  if (!s.post || typeof OR_PROFILES === 'undefined') return null;
  let base = 0;
  s.post.forEach(function(p, k){ base += p * (OR_PROFILES[k] ? OR_PROFILES[k].pct : 50); });

  const ultima = (s.attese || [])[(s.attese || []).length - 1];
  const domani = ultima ? ultima.p : null;

  /* La promessa di domani non È la riuscita finale, ma è la sua materia prima: chi tiene la
     parola un giorno su due arriverà da qualche parte, chi non la tiene mai no. Pesa un terzo. */
  const pct = domani === null ? base : base * 0.66 + domani * 100 * 0.34;
  return { pct: Math.round(pvClamp(pct, 3, 97)), base: Math.round(base),
           domani: domani === null ? null : Math.round(domani * 100),
           prove: (s.giorni || []).length };
}

/* ---------------------------------------------------------------------------------------
   «CHI STAVI PENSANDO?»

   Il pezzo di Akinator. Quando il profilo è sbagliato, le risposte già date diventano un
   esempio etichettato: per ogni domanda, l'attesa del profilo VERO si sposta un po' verso la
   risposta che è stata data. Le tabelle spedite con l'app non si toccano — la correzione vive
   a parte, si può leggere, e si può buttare via.
   --------------------------------------------------------------------------------------- */

const PV_PASSO_CORR = 0.18;

function pvCorreggi(profiloId, risposte){
  if (!profiloId) return;
  const s = pvStato();
  s.corr = s.corr || {};
  const r = risposte || ((typeof OR !== 'undefined' && OR.answers) || {});
  Object.keys(r).forEach(function(qid){
    const dato = r[qid];
    if (typeof dato !== 'number') return;
    const attesa = pvE(qid, profiloId);
    if (attesa === null) return;
    s.corr[qid] = s.corr[qid] || {};
    const delta = (s.corr[qid][profiloId] || 0) + (dato - attesa) * PV_PASSO_CORR;
    /* Il tetto non è cautela: senza, dieci correzioni di fila porterebbero l'attesa a 0 o a 1,
       e un profilo con un'attesa di 1 assorbe ogni risposta — il Genio comincerebbe a dire
       sempre lo stesso nome, che è il modo in cui un motore che impara smette di funzionare. */
    s.corr[qid][profiloId] = pvClamp(delta, -0.35, 0.35);
  });

  // E il vettore riparte da quel profilo, perché è la cosa che l'utente ha appena dichiarato.
  const i = PV_IDS.indexOf(profiloId);
  if (i >= 0){
    const v = PV_IDS.map(function(_, k){ return k === i ? 0.55 : 0.45 / (PV_IDS.length - 1); });
    s.post = pvNorm(v);
    s.ancora = s.post.slice();
  }
  pvScrivi(s);
  if (typeof toast === 'function') toast('Me lo ricorderò. La prossima lettura parte da qui.');
}

/**
 * L'attesa di un profilo per una domanda, con la correzione imparata.
 * È questa che il quiz deve usare al posto della tabella cablata.
 */
function pvE(qid, profiloId){
  if (typeof OR_Q === 'undefined') return null;
  const q = OR_Q.filter(function(x){ return x.id === qid; })[0];
  if (!q || !q.e || typeof q.e[profiloId] !== 'number') return null;
  const s = pvStato();
  const d = (s.corr && s.corr[qid] && s.corr[qid][profiloId]) || 0;
  return pvClamp(q.e[profiloId] + d, 0.02, 0.98);
}

/** Quante correzioni sono state date finora: è la memoria del motore, e si può mostrare. */
function pvQuanteCorrezioni(){
  const s = pvStato();
  let n = 0;
  Object.keys(s.corr || {}).forEach(function(q){ n += Object.keys(s.corr[q] || {}).length; });
  return n;
}

/** Il quiz ha finito: il vettore intero si conserva, non solo il vincitore. */
function pvSemina(post){
  if (!post || !post.length) return;
  const s = pvStato();
  s.post = pvNorm(post.slice());
  s.ancora = s.post.slice();
  s.ultimoGiorno = '';           // il giro di oggi va rifatto con l'ancora nuova
  pvScrivi(s);
}

/* Il giro parte da solo quando l'app si apre, ma senza mettersi davanti a niente: è un calcolo
   di fondo, e se fallisce non deve rompere nessuna schermata. */
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(function(){ try{ pvGiro(); }catch(_){ } }, 4000);
});
