/* ===========================================================================================
   LA REVISIONE E IL RIENTRA IN ROTTA, IN CHAT CON IL TUO AGENTE (0.9.301)

   Andrea: "nella revisione della sera e nel ricalcolo della rotta continua a non esserci nessuna
   conversazione con nessun LLM. Il Genio parla in modo scriptato con le stesse opzioni: non
   contestualizza, non dice 'ho capito'". Da qui:

   1. LA RIVELAZIONE, per tutti. Prima di qualunque domanda il Genio mostra dove e' andato il tempo:
      il pannello di "Proteggi i tuoi sogni" (le barre per fascia oraria e le prime app, scores.js),
      fermo su OGGI nella revisione della sera e nel Rientra in rotta, sui giorni nelle revisioni
      di periodo. Le barre salgono una alla volta: e' una scoperta, non una tabella.
   2. LE DOMANDE DI CONSAPEVOLEZZA (Premium, ogni tanto, mai uguali di fila, content/consapevolezza
      .json): prima del pannello il tuo agente personale ti mette alla prova ("Ti ricordi cosa stavi facendo
      stamattina alle 10?"), con l'ora presa dai dati veri; poi "Scoprilo" rivela il pannello con
      quell'ora accesa. Serve a vedere se eri presente o andavi in automatico. Mai colpe.
   3. "COSA SUCCEDE SE NON CAMBIA NIENTE": il navigatore (eta.js, etaSimula, lo stesso calcolo di
      rngFuturi) simula ogni giorno come oggi (o come questa settimana) e lo mette accanto alla
      rotta da tenere, sul bivio disegnato di bivio.js.
   4. LA CHAT (Premium): la revisione e il rientro si fanno parlando con il tuo agente personale (rotta
      /api/focuslock/agent/conversa sul server, modello veloce). Le risposte pronte di oggi sono
      pillole che scorrono sopra al campo: si vedono solo a campo vuoto, un tocco le SCRIVE nel
      campo e il messaggio parte solo con invio. Quando dici cosa ti ha portato fuori strada,
      l'agente propone un piano su misura (blocco, limite o prevenzione): si applica solo con il si'.
   5. I DATI CHE INSEGNANO AL GENIO (alla Akinator): con l'interruttore "Aiuta il Genio a imparare"
      (spento finche' non lo accendi) partono, anonimi, il tipo di sogno, la causa e la contromisura,
      e la sera dopo se ha aiutato. Il Genio a opzioni (gratis) li usa per mettere in cima le
      risposte piu' probabili per il tuo tipo di sogno.

   Si aggancia a revisione.js (RV), revisioni-periodo.js (RVP) e rientro-genio.js (RNG): i passi
   che cominciano con "cv" li disegna questo file.
   =========================================================================================== */
const CV = { modo: '', dom: null, panP: null, pan: null, panV: null, chat: null, vuoleDomanda: false, daMandare: null, stat: {} };
const CV_DOM_KEY = 'fl_cv_consapevolezza';
const CV_CONSENSO_KEY = 'fl_cv_impara';
const CV_STAT_KEY = 'fl_cv_impara_stat';
const CV_ATTESA_KEY = 'fl_cv_impara_attesa';
const CV_NOMI = { sera: 'La revisione della sera', settimana: 'La revisione della settimana', mese: 'La revisione del mese', trimestre: 'La revisione del trimestre', anno: 'La revisione dell’anno', rientro: 'Rientra in rotta' };
const CV_SOGNI = ['studio', 'corpo', 'lavoro', 'arte', 'carriera', 'presenza'];
const CV_INVIA_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></svg>';
const CV_MIC_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><path d="M12 18v3"/></svg>';

function cvEsc(s){ return (typeof gnEsc === 'function') ? gnEsc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function cvLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function cvScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
/** Premium: la chat con l'agente e le domande di consapevolezza. Finche' non c'e' l'abbonamento vero, anche l'account di Andrea. */
function cvPremium(){
  try{
    if (!(typeof agPuo === 'function' && agPuo())) return false;
    return (typeof rnPremium === 'function' && rnPremium()) || (typeof flAdmin === 'function' && flAdmin());
  }catch(_){ return false; }
}
function cvTipo(modo){
  modo = modo || CV.modo;
  if (modo === 'rv') return 'sera';
  if (modo === 'rvp') return (typeof RVP !== 'undefined' && RVP.tipo) || 'settimana';
  return 'rientro';
}
function cvPasso(modo){
  try{
    if (modo === 'rv') return RV.passo;
    if (modo === 'rvp') return RVP.passo;
    if (modo === 'rn') return RNG.passo;
  }catch(_){ }
  return '';
}
/* il passo nuovo, senza lasciare traccia nella storia (quando un passo si sostituisce da solo) */
function cvSostituisci(p){
  const m = CV.modo;
  try{
    if (m === 'rv'){ RV.passo = p; rvBarra(); }
    else if (m === 'rvp'){ RVP.passo = p; rvpBarra(); }
    else { RNG.passo = p; rngBarra(); }
  }catch(_){ }
  GN.step = ''; gnVai(m === 'rn' ? 'rn' : m);
}
function cvVai(p){
  const m = CV.modo;
  if (m === 'rv') rvVai(p); else if (m === 'rvp') rvpVai(p); else rngVai(p);
}
/** Dove riparte il Genio a opzioni dopo la rivelazione (gratis, o quando l'agente non risponde). */
function cvDopoLibero(){
  if (CV.modo === 'rv'){ let nota = ''; try{ nota = String((rvUmoreOggi() || {}).nota || '').trim(); }catch(_){ } return nota ? 'focus' : 'pensiero'; }
  if (CV.modo === 'rvp') return 'recap';
  return 'prima';
}

/* ---------------------------------------------------------------------------------------
   L'INIZIO: chi apre una revisione o un rientro passa di qui
   --------------------------------------------------------------------------------------- */
function cvInizio(modo){
  CV.modo = modo; CV.dom = null; CV.pan = null; CV.chat = null; CV.daMandare = null; CV.datiAg = null;
  CV.primo = null; CV.grani = {}; CV.verP = null;
  const tipo = cvTipo(modo);
  CV.panP = cvPannelloDati(cvRange(tipo)).then(function(p){ CV.pan = p; return p; });
  cvImparaCarica(tipo === 'rientro' ? 'rientro' : tipo);
  /* 0.9.303: la domanda di consapevolezza la fa anche il Genio a opzioni (gratis). La prova che segue un si' e' scritta o
     dettata con Premium, a opzioni costruite dalla giornata vera senza Premium. */
  /* 0.9.321: "Riprendi da dove avevi lasciato" (dream-storia.js): la chat del giorno torna, e si entra li' */
  try{ const ri = (typeof drsCvRipristina === 'function') ? drsCvRipristina() : null; if (ri){ CV.chat = ri; CV.vuoleDomanda = false; return 'cvChat'; } }catch(_){ }
  CV.vuoleDomanda = cvDomandaTocca();
  /* la cronologia di oggi si legge subito: serve alla prova, al controllo e al primo messaggio dell'agente */
  if (cvRange(tipo) === 'oggi') cvGrani(0);
  return CV.vuoleDomanda ? 'cvDomanda' : 'cvRivela';
}
function cvRange(tipo){ return { sera: 'oggi', rientro: 'oggi', settimana: '7d', mese: '30d', trimestre: '90d', anno: '365d' }[tipo] || 'oggi'; }
/* OGNI TANTO, MAI DI FILA: una revisione o un rientro su due al massimo, e dalla seconda occasione dopo l'ultima
   domanda una volta su due (dalla terza sempre). fl_cv_forza = '1' la fa comparire sempre (per le prove). */
function cvDomandaTocca(){
  const st = cvLeggi(CV_DOM_KEY, { ultime: [], occ: 0, ultimaOcc: -99 });
  st.occ = (st.occ || 0) + 1;
  cvScrivi(CV_DOM_KEY, st);
  let forza = false; try{ forza = localStorage.getItem('fl_cv_forza') === '1'; }catch(_){ }
  if (forza) return true;
  const gap = st.occ - (st.ultimaOcc == null ? -99 : st.ultimaOcc);
  return gap >= 3 || (gap === 2 && Math.random() < 0.5);
}

/* ---------------------------------------------------------------------------------------
   IL PANNELLO: lo stesso di "Proteggi i tuoi sogni", fermo sul periodo della revisione
   --------------------------------------------------------------------------------------- */
function cvMezzanotte(off){ if (typeof scDayStart === 'function') return scDayStart(off || 0); const d = new Date(); d.setHours(0, 0, 0, 0); if (off) d.setDate(d.getDate() - off); return d.getTime(); }
function cvFinestra(range){
  const now = Date.now(), d0 = cvMezzanotte(0);
  if (range === 'ieri') return { from: cvMezzanotte(1), to: d0, bucket: 'hour', label: 'ieri' };
  if (range === '7d') return { from: cvMezzanotte(6), to: now, bucket: 'day', label: 'negli ultimi 7 giorni' };
  if (range === '30d') return { from: cvMezzanotte(29), to: now, bucket: 'day', label: 'nell’ultimo mese' };
  if (range === '90d') return { from: cvMezzanotte(89), to: now, bucket: 'day', label: 'negli ultimi tre mesi' };
  if (range === '365d') return { from: cvMezzanotte(364), to: now, bucket: 'day', months: true, label: 'nell’ultimo anno' };
  return { from: d0, to: now, bucket: 'hour', label: 'oggi' };
}
async function cvPannelloDati(range){
  const win = cvFinestra(range);
  const out = { range: range, win: win, buckets: [], top: [], ms: 0, pickups: null, ok: false };
  if (typeof NATIVE === 'undefined' || !NATIVE) return out;
  try{
    const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
    out.buckets = ((a && a.buckets) || []).map(function(k){ return { start: k.start, v: k.ms || 0 }; });
    out.ms = (a && a.ms) || out.buckets.reduce(function(t, b){ return t + b.v; }, 0);
    out.ok = !!(a && (a.buckets || a.ms != null));
  }catch(_){ }
  try{
    const t = await NATIVE.getTopApps({ from: win.from, to: win.to, limit: 9, by: 'ms', icons: 12 });
    out.top = ((t && t.apps) || []).filter(function(x){ return x && !x.self && !/dreambrothers\.focuslock/.test(String(x.packageName || '')); });
  }catch(_){ }
  /* 0.9.302: con i dati del computer scelti e il computer che oggi non ha mandato niente, i numeri qui sopra sono
     zeri che non vogliono dire niente ("0min", "Nessuna app ha superato il minuto"): non sono dati, e non si usano */
  if (range === 'oggi' || range === 'ieri'){
    try{ const r = (typeof scReport === 'function') ? await scReport(range === 'ieri' ? 1 : 0) : null; if (r && !r.granted && r.senzaDati) out.ok = false; }catch(_){ }
  }
  /* gli sblocchi sono del telefono e basta: con un'altra sorgente la domanda "quante volte hai preso in mano il
     telefono" leggeva gli zeri del computer */
  if (range === 'oggi' && cvDove() === 'telefono'){
    try{ const r = (typeof scReportPunteggi === 'function') ? await scReportPunteggi(0) : ((typeof scReport === 'function') ? await scReport(0) : null); if (r && r.granted) out.pickups = r.pickups || 0; }catch(_){ }
  }
  return out;
}
/* IL DISPOSITIVO DEI NUMERI (0.9.302): quello scelto nei tre puntini del pannello (motore-web.js). Le frasi del Genio
   dicono "telefono" solo quando i numeri sono del telefono. */
function cvDove(){ try{ return (typeof mwFonte === 'function') ? mwFonte() : 'telefono'; }catch(_){ return 'telefono'; } }
const CV_DOVE = {
  telefono: { sul: 'sul telefono', Sul: 'Sul telefono', acceso: 'il telefono era acceso', preso: 'il telefono ti ha preso', usato: 'hai preso il telefono', app: 'quale app', App: 'L’app' },
  computer: { sul: 'al computer', Sul: 'Al computer', acceso: 'sei stato al computer', preso: 'il computer ti ha preso', usato: 'hai usato il computer', app: 'quale programma o sito', App: 'Il programma o il sito' },
  insieme: { sul: 'fra telefono e computer', Sul: 'Fra telefono e computer', acceso: 'sei stato fra telefono e computer', preso: 'telefono e computer ti hanno preso', usato: 'hai usato telefono e computer', app: 'quale app o programma', App: 'L’app o il programma' }
};
function cvDoveT(){ return CV_DOVE[cvDove()] || CV_DOVE.telefono; }
/** Il testo di una domanda con il dispositivo giusto ("quanto tempo hai passato al computer"). */
function cvSuDove(t){
  const d = cvDoveT();
  if (d === CV_DOVE.telefono) return t;
  return String(t).replace(/sul telefono/g, d.sul).replace(/il telefono ti ha preso/g, d.preso)
    .replace(/hai preso il telefono/g, d.usato).replace(/quale app ti ha preso/g, d.app + ' ti ha preso');
}
function cvOre(ms){ const m = Math.round((ms || 0) / 60000); if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti'; const h = Math.floor(m / 60), r = m % 60; return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + r + (r === 1 ? ' minuto' : ' minuti') : ''); }
function cvOra(h){ return String(h).padStart(2, '0') + ':00'; }
/** Le prime app di un'ora sola: per accendere l'ora della domanda. */
async function cvAppOra(start){
  try{ const t = await NATIVE.getTopApps({ from: start, to: Math.min(Date.now(), start + 3600000), limit: 4, by: 'ms', icons: 0 }); return ((t && t.apps) || []).filter(function(x){ return x && !x.self && !/dreambrothers\.focuslock/.test(String(x.packageName || '')) && (x.ms || 0) >= 60000; }); }catch(_){ return []; }
}
function cvPannelloHtml(p, evid){
  if (!p || !p.ok){
    return '<div class="rep-panel cv-pan cv-pan-vuoto"><b>Qui c’è il tempo sul telefono, ora per ora.</b><p>Per vederlo serve l’accesso ai dati di utilizzo.</p>'
      + '<button type="button" class="cv-pan-perm" onclick="event.stopPropagation();if(typeof openPerm===\'function\')openPerm(\'usage\')">Dai l’accesso</button></div>';
  }
  const win = Object.assign({}, p.win);
  const chart = (typeof scChartHtml === 'function' && p.buckets.length) ? scChartHtml(p.buckets, win, (typeof scFmtMin === 'function' ? scFmtMin : cvOre), false) : '';
  const righe = (typeof scRigheAttenzione === 'function' ? scRigheAttenzione(p.top) : p.top).slice(0, 5);
  const max = righe.length ? (righe[0].ms || 1) : 1;
  const riga = function(a){
    const ico = a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + cvEsc((a.label || '?').charAt(0).toUpperCase()) + '</span>';
    return (typeof scReportRow === 'function') ? scReportRow('', ico, cvEsc(a.label || a.packageName), (a.ms || 0) / max, (typeof scFmtShort === 'function' ? scFmtShort(a.ms || 0) : cvOre(a.ms)))
      : '<div class="rep-row">' + ico + '<div class="nm"><span>' + cvEsc(a.label) + '</span></div><b class="tm">' + cvOre(a.ms) + '</b></div>';
  };
  const titolo = { oggi: 'Oggi sul telefono', ieri: 'Ieri sul telefono', '7d': 'Negli ultimi 7 giorni', '30d': 'Nell’ultimo mese', '90d': 'Negli ultimi tre mesi', '365d': 'Nell’ultimo anno' }[p.range] || 'Sul telefono';
  let ora = '';
  if (evid && evid.i >= 0 && p.buckets[evid.i]){
    const b = p.buckets[evid.i];
    const fascia = p.win.bucket === 'hour' ? cvOra(new Date(b.start).getHours()) + ' - ' + cvOra((new Date(b.start).getHours() + 1) % 24) : (evid.nome || '');
    const app = (evid.app || []).slice(0, 3).map(function(a){ return cvEsc(a.label || a.packageName) + ' ' + cvOre(a.ms); }).join(', ');
    ora = '<div class="cv-pan-ora"><b>' + cvEsc(fascia) + '</b><span>' + (app || cvOre(b.v) + ' sul telefono') + '</span></div>';
  }
  return '<div class="rep-panel cv-pan"><div class="cv-pan-top"><small>' + titolo + '</small><b class="rep-big">' + (typeof scFmtShort === 'function' ? scFmtShort(p.ms) : cvOre(p.ms)) + '</b></div>'
    + chart + ora
    + '<div class="rep-att"><b>' + (cvDove() === 'computer' ? '💻 Dove va la tua attenzione al computer?' : (cvDove() === 'insieme' ? '📱💻 Dove va la tua attenzione?' : 'Dove va la tua attenzione?')) + '</b>' + (righe.length ? righe.map(riga).join('') : '<p class="hintline">Nessuna app ha superato il minuto.</p>') + '</div></div>';
}
/* le barre salgono una alla volta, e quella della domanda resta accesa */
function cvPannelloVivo(evid){
  const bars = document.querySelectorAll('#gnRisp .cv-pan .rp-bars > b');
  const box = document.querySelector('#gnRisp .cv-pan .rp-bars');
  bars.forEach(function(b, i){ b.style.setProperty('--i', i); });
  if (box){
    box.classList.add('cv-cresce'); if (evid && evid.i >= 0 && bars[evid.i]){ box.classList.add('con-sel'); bars[evid.i].classList.add('sel'); }
    /* su un telefono lento l'animazione puo' restare indietro: dopo due secondi le barre sono comunque alla loro altezza */
    setTimeout(function(){ box.classList.remove('cv-cresce'); }, 2000);
  }
}

/* ---------------------------------------------------------------------------------------
   LE DOMANDE DI CONSAPEVOLEZZA
   --------------------------------------------------------------------------------------- */
let CV_DOMANDE = null;
async function cvDomandeCarica(){
  if (CV_DOMANDE) return CV_DOMANDE;
  try{ const j = await (await fetch('content/consapevolezza.json')).json(); CV_DOMANDE = (j && j.domande) || []; }catch(_){ CV_DOMANDE = []; }
  return CV_DOMANDE;
}
const CV_FASCE = { mattina: [6, 12], pomeriggio: [12, 18], sera: [18, 24], '': [6, 24] };
const CV_FASCE_NOMI = { mattina: 'la mattina', pomeriggio: 'il pomeriggio', sera: 'la sera' };
/** L'ora con piu' telefono dentro una fascia (solo ore gia' finite). */
function cvOraMax(p, fascia, ieri){
  const f = CV_FASCE[fascia || ''] || CV_FASCE[''];
  const adesso = new Date().getHours();
  let best = -1, v = 0;
  (p.buckets || []).forEach(function(b, i){
    const h = new Date(b.start).getHours();
    if (h < f[0] || h >= f[1] || (!ieri && h >= adesso)) return;
    if (b.v > v){ v = b.v; best = i; }
  });
  return v >= 8 * 60000 ? best : -1;
}
function cvSomme(p){
  const s = { mattina: 0, pomeriggio: 0, sera: 0 };
  (p.buckets || []).forEach(function(b){ const h = new Date(b.start).getHours(); if (h >= 6 && h < 12) s.mattina += b.v; else if (h >= 12 && h < 18) s.pomeriggio += b.v; else if (h >= 18) s.sera += b.v; });
  return s;
}
const CV_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
function cvMischia(l){ l = l.slice(); for (let i = l.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); const t = l[i]; l[i] = l[j]; l[j] = t; } return l; }
/** Prepara una domanda con i dati veri; null se i dati non bastano per farla. */
async function cvDomandaPrepara(q, tipo){
  let p = CV.pan || await CV.panP;
  const out = { q: q, testo: cvSuDove(q.t), opzioni: (q.opzioni || []).slice(), range: p.range, evid: null, info: {} };
  if (q.tipo === 'ora' || q.tipo === 'ieri'){
    if (q.tipo === 'ieri') p = await cvPannelloDati('ieri');
    if (!p.ok) return null;
    const i = cvOraMax(p, q.fascia, q.tipo === 'ieri'); if (i < 0) return null;
    const h = new Date(p.buckets[i].start).getHours();
    out.testo = cvSuDove(q.t).replace('{ora}', String(h)); out.range = p.range; out.pan = p;
    out.evid = { i: i, app: await cvAppOra(p.buckets[i].start) };
    out.info = { ora: h, min: Math.round(p.buckets[i].v / 60000), ieri: q.tipo === 'ieri' };
    return out;
  }
  if (!p.ok || !(p.ms > 0)) return (q.tipo === 'controllo' || q.tipo === 'direzione' || q.tipo === 'causa') ? out : null;
  if (q.tipo === 'stima'){ out.info = { ms: p.ms }; return out; }
  if (q.tipo === 'sblocchi'){ if (p.pickups == null) return null; out.info = { n: p.pickups }; return out; }
  if (q.tipo === 'app'){
    const top = (p.top || []).slice(0, 3); if (top.length < 2) return null;
    out.opzioni = cvMischia(top.map(function(a){ return [a.packageName, '📱', a.label || a.packageName]; })).concat([['nonso', '🤷', 'Non lo so']]);
    out.info = { app: top[0].label, pkg: top[0].packageName, ms: top[0].ms };
    return out;
  }
  if (q.tipo === 'fascia'){
    const s = cvSomme(p); const k = Object.keys(s).sort(function(a, b){ return s[b] - s[a]; })[0];
    if (!(s[k] > 0)) return null;
    out.info = { fascia: k, ms: s[k] };
    return out;
  }
  if (q.tipo === 'giornoMax'){
    const b = (p.buckets || []).filter(function(x){ return x.v > 0; }); if (b.length < 3) return null;
    const m = b.slice().sort(function(x, y){ return y.v - x.v; })[0];
    const altri = cvMischia(b.filter(function(x){ return x !== m; })).slice(0, 2);
    out.opzioni = cvMischia([m].concat(altri)).map(function(x){ const g = CV_GIORNI[new Date(x.start).getDay()]; return [String(x.start), '📅', g.charAt(0).toUpperCase() + g.slice(1)]; }).concat([['nonso', '🤷', 'Non lo so']]);
    out.evid = { i: p.buckets.indexOf(m), nome: CV_GIORNI[new Date(m.start).getDay()] };
    out.info = { giorno: CV_GIORNI[new Date(m.start).getDay()], ms: m.v, start: m.start };
    return out;
  }
  return out;
}
async function cvDomandaScegli(){
  const tipo = cvTipo();
  const st = cvLeggi(CV_DOM_KEY, { ultime: [], occ: 1, ultimaOcc: -99 });
  const recenti = (st.ultime || []).slice(-4);
  const lista = cvMischia((await cvDomandeCarica()).filter(function(q){ return (q.per || []).indexOf(tipo) >= 0 && recenti.indexOf(q.id) < 0; }));
  /* le domande sull'ora hanno la precedenza: sono quelle che fanno vedere l'automatico */
  lista.sort(function(a, b){ return (b.tipo === 'ora' || b.tipo === 'ieri' ? 1 : 0) - (a.tipo === 'ora' || a.tipo === 'ieri' ? 1 : 0) + (Math.random() - 0.5) * 0.9; });
  for (let i = 0; i < lista.length; i++){
    const pr = await cvDomandaPrepara(lista[i], tipo);
    if (pr){ st.ultime = (st.ultime || []).concat([lista[i].id]).slice(-8); st.ultimaOcc = st.occ; cvScrivi(CV_DOM_KEY, st); return pr; }
  }
  return null;
}
function cvCarte(voci, fn, scrivo){
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();' + fn + '(' + i + ')"><span>' + o[1] + '</span><b>' + cvEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>'
    + (scrivo ? '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();cvVai(\'cvScrivo\')">✍️ Lo scrivo io</button>' : '');
}
function cvDomandaRisposta(i){
  const d = CV.dom; if (!d) return;
  const o = d.opzioni[i]; if (!o) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  d.risposta = { k: o[0], t: o[2] }; d.cosa = null; d.verdetto = null; CV.verP = null;
  /* 0.9.303, Andrea: "uno puo' anche mentire, deve dimostrare di saperlo". Dopo un si' o un "piu' o meno" la domanda
     vera: cosa stavi facendo a quell'ora. Con "Non ne ho idea" si va dritti al controllo. */
  if (cvDomOra(d) && CV_PROVA.indexOf(o[0]) >= 0){ cvVai('cvCosa'); return; }
  if (cvDomOra(d)){ cvVai('cvRivela'); return; }
  cvVai('cvScopri');
}
function cvScrivoOk(){
  const a = document.getElementById('cvDomTesto'); const t = a ? a.value.trim() : '';
  const d = CV.dom;
  /* 0.9.310: mai obbligatorio. A campo vuoto si va a vedere i dati senza risposta */
  if (!t){ cvSostituisci('cvScopri'); return; }
  if (d){
    /* scritto alla domanda sull'ora (o alla prova che la segue): e' gia' il racconto di cosa stava facendo */
    if (d.cosaChiesta || cvDomOra(d)){ if (!d.cosaChiesta) d.risposta = { k: 'scritto', t: t }; d.cosa = { k: 'scritto', t: t }; cvVerifica(d); }
    else d.risposta = { k: 'scritto', t: t };
  }
  cvSostituisci('cvScopri');
}

/* ---------------------------------------------------------------------------------------
   LA PROVA (0.9.303): "Ti ricordi cosa stavi facendo stamattina alle 9?" "Si'" -> "Cosa stavi facendo?"
   Premium: si scrive o si detta, e l'agente confronta il racconto con la giornata vera. Senza Premium: le opzioni sono
   le cose fatte davvero quel giorno (quella di quell'ora e due di altre ore), piu' "Lo scrivo io". Poi il controllo.
   --------------------------------------------------------------------------------------- */
const CV_PROVA = ['si', 'vago', 'presente'];
function cvDomOra(d){ return !!(d && d.q && (d.q.tipo === 'ora' || d.q.tipo === 'ieri') && d.info && d.info.ora != null); }
/** Il quando detto per intero: "stamattina alle 9", "ieri sera alle 21". */
function cvMomento(d){
  const q = (d && d.q) || {}, inf = (d && d.info) || {};
  return String(q.momento || (inf.ieri ? 'ieri alle {ora}' : 'oggi alle {ora}')).replace('{ora}', String(inf.ora));
}
function cvMai(t){ t = String(t || ''); return t.charAt(0).toUpperCase() + t.slice(1); }
function cvHM(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function cvIso(ms){ const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function cvSelf(pkg){
  try{ if (typeof tlLauncher === 'function' && tlLauncher(pkg)) return true; }catch(_){ }
  return /dreambrothers\.focuslock|launcher|systemui|^android$/i.test(String(pkg || ''));
}
/** La cronologia di un giorno (0 = oggi, 1 = ieri), con i pezzi della stessa app fusi. Una lettura sola per giro. */
function cvGrani(off){
  CV.grani = CV.grani || {};
  if (CV.grani[off]) return CV.grani[off];
  CV.grani[off] = (async function(){
    try{
      if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return [];
      const da = cvMezzanotte(off), a = off ? cvMezzanotte(off - 1) : Date.now();
      const t = await NATIVE.getTimeline({ from: da, to: a, minMs: 0, limit: 6000 });
      if (!t || !t.granted) return [];
      const g = (typeof rngAiFondi === 'function') ? rngAiFondi(t.grani) : (t.grani || []).map(function(x){ return { p: x.p, l: x.l || x.p, s: x.s, ms: x.ms || 0 }; });
      return g.filter(function(x){ return x && x.p && !cvSelf(x.p); });
    }catch(_){ return []; }
  })();
  return CV.grani[off];
}
/**
 * Cosa ha fatto in una finestra, un evento per riga: { t, ms, pkg, app, cosa, tipo, url }. La radiografia della
 * Timeline (tlRadiografia, con la ricerca, il sito, il video...) quando c'e'; se no le sessioni per app.
 */
async function cvEventi(off, da, a){
  if (typeof tlRadiografia === 'function'){
    try{
      const r = await Promise.race([Promise.resolve(tlRadiografia(cvIso(cvMezzanotte(off)), da, a)), new Promise(function(ok){ setTimeout(function(){ ok(null); }, 4000); })]);
      const l = Array.isArray(r) ? r : (r && Array.isArray(r.eventi) ? r.eventi : null);
      if (l && l.length){
        return l.filter(function(e){ return e && !cvSelf(e.pkg) && +e.t < a && +e.t + (+e.durMs || 0) > da; })
          .map(function(e){ return { t: +e.t, ms: +e.durMs || 0, pkg: String(e.pkg || ''), app: String(e.app || e.pkg || ''), cosa: String(e.cosa || '').trim(), tipo: String(e.tipo || ''), url: String(e.url || '') }; })
          .sort(function(x, y){ return x.t - y.t; });
      }
    }catch(_){ }
  }
  const g = await cvGrani(off);
  return g.filter(function(x){ return x.s < a && x.s + x.ms > da; }).map(function(x){ return { t: x.s, ms: x.ms, pkg: x.p, app: x.l, cosa: '', tipo: 'app', url: '' }; });
}
/** Le opzioni della prova senza Premium: l'attivita' vera di quell'ora e due attivita' vere di altre ore, mescolate. */
async function cvCosaOpzioni(d){
  if (d.cosaOpz) return d.cosaOpz;
  const vera = ((d.evid && d.evid.app) || [])[0];
  if (!vera) return null;
  const off = d.info.ieri ? 1 : 0, ora = d.info.ora;
  const nellOra = (d.evid.app || []).map(function(a){ return a.packageName; });
  const per = {};
  const conta = function(pkg, label, ms, h){
    if (!pkg || cvSelf(pkg) || nellOra.indexOf(pkg) >= 0 || h === ora) return;
    const x = per[pkg] = per[pkg] || { pkg: pkg, label: label || pkg, ms: 0, ore: {} };
    x.ms += ms; x.ore[h] = (x.ore[h] || 0) + ms;
  };
  const g = await cvGrani(off);
  if (g.length) g.forEach(function(x){ conta(x.p, x.l, x.ms, new Date(x.s).getHours()); });
  else {
    const p = d.pan || CV.pan;
    const altre = ((p && p.buckets) || []).map(function(b, i){ return { b: b, i: i }; }).filter(function(o){ return o.i !== d.evid.i && o.b.v >= 3 * 60000; }).sort(function(x, y){ return y.b.v - x.b.v; }).slice(0, 6);
    for (let k = 0; k < altre.length; k++){
      const h = new Date(altre[k].b.start).getHours();
      (await cvAppOra(altre[k].b.start)).forEach(function(a){ conta(a.packageName, a.label, a.ms || 0, h); });
    }
  }
  const alt = Object.keys(per).map(function(k){ return per[k]; }).filter(function(x){ return x.ms >= 3 * 60000; }).sort(function(x, y){ return y.ms - x.ms; }).slice(0, 2)
    .map(function(x){ const h = +Object.keys(x.ore).sort(function(a, b){ return x.ore[b] - x.ore[a]; })[0]; return { pkg: x.pkg, label: x.label, ora: h }; });
  if (alt.length < 2) return null;
  const opz = [{ pkg: vera.packageName, label: vera.label || vera.packageName, ora: ora }].concat(alt);
  /* le icone vere delle app (un'emoji del telefono sarebbe uguale per tutte) */
  try{
    const da = cvMezzanotte(off), a = off ? cvMezzanotte(off - 1) : Date.now();
    const t = await NATIVE.getTopApps({ from: da, to: a, limit: 40, by: 'ms', icons: 40 });
    const ic = {}; ((t && t.apps) || []).forEach(function(x){ if (x && x.icon) ic[x.packageName] = x.icon; });
    opz.forEach(function(o){ o.icon = ic[o.pkg] || ''; });
  }catch(_){ }
  d.cosaOpz = cvMischia(opz);
  return d.cosaOpz;
}
function cvIcoApp(o){
  return o.icon ? '<img class="cv-ico-app" src="' + cvEsc(o.icon) + '" alt="">' : '<i class="cv-ico-app cv-ico-let">' + cvEsc(String(o.label || '?').charAt(0).toUpperCase()) + '</i>';
}
function cvCosaScelta(i){
  const d = CV.dom, o = d && d.cosaOpz && d.cosaOpz[i]; if (!o) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  d.cosa = { k: o.pkg, pkg: o.pkg, t: 'Ero su ' + o.label };
  cvVerifica(d);
  cvVai('cvScopri');
}
function cvCosaOk(){
  const a = document.getElementById('cvCosaTesto'); const t = a ? a.value.trim() : '';
  const d = CV.dom; if (!d) return;
  if (!t){ d.cosa = null; d.verdetto = null; CV.verP = null; cvVai('cvRivela'); return; }
  d.cosa = { k: 'scritto', t: t };
  cvVerifica(d);
  cvVai('cvScopri');
}
function cvNorm(t){ return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
/** Il racconto scritto nomina un'app di quell'ora? (il nome intero, o la sua prima parola se e' lunga almeno 4 lettere) */
function cvAppNelTesto(t, app){
  const s = ' ' + cvNorm(t) + ' ';
  return (app || []).filter(function(a){
    const n = cvNorm(a.label || a.packageName); if (!n) return false;
    const w = n.split(' ')[0];
    return s.indexOf(' ' + n + ' ') >= 0 || (w.length >= 4 && s.indexOf(' ' + w) >= 0);
  })[0] || null;
}
/** Il verdetto fatto dall'app, con i dati del telefono: anche il ripiego quando l'agente non risponde. */
function cvVerdettoLocale(d){
  const c = d.cosa || {}, m = cvMomento(d), app = (d.evid && d.evid.app) || [], vera = app[0];
  if (!vera) return { esito: 'nonsi', testo: 'Il telefono ' + m + ' era quasi sempre giù: lì solo tu sai cosa stavi facendo.' };
  const nome = function(a){ return a.label || a.packageName; };
  const veraTxt = '*' + nome(vera) + '* per ' + cvOre(vera.ms);
  let k = c.pkg || '';
  if (!k && c.t){ const x = cvAppNelTesto(c.t, app); if (x) k = x.packageName; }
  if (k === vera.packageName) return { esito: 'preso', testo: 'Ci hai preso: ' + m + ' eri su ' + veraTxt + '.' };
  const anche = app.filter(function(a){ return a.packageName === k; })[0];
  if (anche) return { esito: 'vicino', testo: 'Ci sei andato vicino: ' + m + ' hai usato anche ' + nome(anche) + ', ma soprattutto ' + veraTxt + '.' };
  if (c.pkg){
    const alt = (d.cosaOpz || []).filter(function(o){ return o.pkg === c.pkg; })[0];
    return { esito: 'sbagliato', testo: 'Non era così: ' + m + ' eri su ' + veraTxt + '.' + (alt && alt.ora != null ? ' Su ' + alt.label + ' sei stato alle ' + alt.ora + '.' : '') };
  }
  return { esito: 'nonsi', testo: 'Ecco cosa dice il telefono: ' + m + ' eri su ' + veraTxt + '.' };
}
/**
 * Il controllo del racconto. Scritto con Premium: lo confronta il tuo agente personale con la giornata vera (rotta
 * /api/focuslock/agent/verifica), e se non risponde in tempo lo confronta l'app. Il resto lo confronta l'app.
 */
function cvVerifica(d){
  d.verdetto = null;
  const locale = cvVerdettoLocale(d);
  if (!(d.cosa && d.cosa.k === 'scritto' && cvPremium() && typeof agApi === 'function')){
    d.verdetto = locale; CV.verP = Promise.resolve(locale); return CV.verP;
  }
  CV.verP = (async function(){
    try{
      const off = d.info.ieri ? 1 : 0, da = cvMezzanotte(off) + d.info.ora * 3600000;
      const ev = await cvEventi(off, da, da + 3600000);
      const corpo = { domanda: 'Cosa stavi facendo ' + cvMomento(d) + '?', momento: cvMomento(d), risposta: d.cosa.t,
        nomeAgente: (typeof agNomeAgente === 'function' ? agNomeAgente() : 'Genio'),
        dati: { ora: cvOra(d.info.ora), app: ((d.evid && d.evid.app) || []).slice(0, 4).map(function(a){ return { nome: a.label || a.packageName, min: Math.round((a.ms || 0) / 60000) }; }),
          eventi: cvSequenza(ev, 14) } };
      const r = await Promise.race([agApi('POST', '/api/focuslock/agent/verifica', corpo), new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, 9000); })]);
      if (!r || !r.testo) throw new Error('vuota');
      d.verdetto = { esito: String(r.esito || ''), testo: String(r.testo), agente: true };
    }catch(_){ d.verdetto = locale; }
    return d.verdetto;
  })();
  return CV.verP;
}
/** Gli eventi in fila per il modello: le righe vicine della stessa app si fondono. [{ ora, app, min, cosa }] */
/* 0.9.321, Andrea: "la stessa riga ripetuta quattro volte". Mentre scrivi, lo schermo cambia a ogni lettera ("prima di andare a dorm",
   "a dormk", "a dormkr"): per la cronologia sono righe diverse. Due testi che cominciano quasi uguali sono la stessa cosa. */
function cvStessoTesto(a, b){
  a = String(a || '').trim(); b = String(b || '').trim();
  if (!a || !b) return false;
  if (a === b) return true;
  const n = Math.min(a.length, b.length); let i = 0;
  while (i < n && a[i].toLowerCase() === b[i].toLowerCase()) i++;
  return n >= 12 && i / n >= 0.75;
}
function cvSequenza(ev, max){
  const out = [];
  (ev || []).forEach(function(e){
    const u = out[out.length - 1];
    /* fra gli stessi testi vale l'ultimo, quello finito di scrivere */
    if (u && u.pkg === e.pkg && e.t - u.fine <= 300000 && cvStessoTesto(u.cosa, e.cosa)){ u.ms += e.ms; u.fine = Math.max(u.fine, e.t + e.ms); u.cosa = e.cosa.length >= u.cosa.length ? e.cosa : u.cosa; return; }
    if (u && u.pkg === e.pkg && e.t - u.fine <= 120000 && (!e.cosa || !u.cosa || u.cosa === e.cosa)){ u.ms += e.ms; u.fine = Math.max(u.fine, e.t + e.ms); if (e.cosa && !u.cosa) u.cosa = e.cosa; return; }
    out.push({ t: e.t, fine: e.t + e.ms, ms: e.ms, pkg: e.pkg, app: e.app, cosa: e.cosa, tipo: e.tipo });
  });
  return out.filter(function(x){ return x.ms >= 20000 || x.cosa; }).slice(-(max || 12)).map(function(x){
    const r = { ora: cvHM(x.t), app: x.app, min: Math.max(1, Math.round(x.ms / 60000)) };
    if (x.cosa) r.cosa = x.cosa.slice(0, 140);
    if (x.tipo && x.tipo !== 'app') r.tipo = x.tipo;
    return r;
  });
}

/* ---------------------------------------------------------------------------------------
   LA RIVELAZIONE
   --------------------------------------------------------------------------------------- */
function cvTitoloRivela(){
  const d = CV.dom, tipo = cvTipo();
  /* 0.9.302: i dati del computer scelti e il computer che oggi non ha mandato niente: si dice, e si dice come vedere quelli del telefono */
  if (CV.pan && !CV.pan.ok && cvDove() === 'computer' && (!d || !d.q || ['controllo', 'direzione', 'causa'].indexOf(d.q.tipo) >= 0)){
    return CV_TITOLO_SENZA;
  }
  const quando = { sera: 'oggi', rientro: 'oggi', settimana: 'in questi sette giorni', mese: 'in quest’ultimo mese', trimestre: 'in questi tre mesi', anno: 'in quest’ultimo anno' }[tipo] || 'oggi';
  if (!d || !d.q) return tipo === 'rientro' ? 'Prima di tutto, guarda *dove è andato il tuo tempo* oggi.' : 'Prima di parlarne, guarda *dove è andato il tuo tempo* ' + quando + '.';
  const inf = d.info || {};
  const dv = cvDoveT();
  const app0 = d.evid && d.evid.app && d.evid.app[0];
  switch (d.q.tipo){
    case 'ora': case 'ieri':
      /* 0.9.303: dopo la prova, il verdetto (con il quando e quello che dicono i dati) */
      if (d.cosa && d.verdetto && d.verdetto.testo) return d.verdetto.testo;
      if (d.q.momento) return cvMai(cvMomento(d)) + ' ' + dv.acceso + ' per ' + inf.min + ' minuti' + (app0 ? ', soprattutto su *' + (app0.label || app0.packageName) + '*.' : '.');
      return 'Alle ' + inf.ora + (inf.ieri ? ' di ieri' : '') + ' ' + dv.acceso + ' per ' + inf.min + ' minuti' + (app0 ? ', soprattutto su *' + (app0.label || app0.packageName) + '*.' : '.');
    case 'stima': return dv.Sul + ' ' + quando + ': *' + cvOre(inf.ms) + '*.';
    case 'app': return dv.App + ' che ti ha preso più tempo ' + quando + ' è *' + inf.app + '*: ' + cvOre(inf.ms) + '.';
    case 'fascia': return 'La parte della giornata in cui ' + dv.preso + ' di più è *' + CV_FASCE_NOMI[inf.fascia] + '*: ' + cvOre(inf.ms) + '.';
    case 'sblocchi': return 'Oggi hai preso in mano il telefono *' + inf.n + (inf.n === 1 ? ' volta' : ' volte') + '*.';
    case 'giornoMax': return 'Il giorno in cui ' + dv.preso + ' di più è *' + inf.giorno + '*: ' + cvOre(inf.ms) + '.';
  }
  return 'Ecco *dove è andato il tuo tempo* ' + quando + '.';
}
/* una riga, sopra al pannello, che rimette accanto la risposta data. Mai un giudizio. */
function cvEsitoHtml(){
  const d = CV.dom; if (!d || !d.risposta) return '';
  const r = d.risposta, inf = d.info || {}, k = r.k;
  let t = 'Avevi risposto: "' + r.t + '".';
  const tipo = d.q.tipo;
  if (tipo === 'ora' || tipo === 'ieri'){
    if (d.cosa) t = (d.cosa.k === 'scritto' ? 'Avevi scritto: "' : 'Avevi detto: "') + String(d.cosa.t).replace(/[.\s]+$/, '') + '".';
    else if (k === 'no' || k === 'vago') t = 'Avevi risposto: "' + r.t + '". Quando andiamo avanti in automatico, la memoria non tiene traccia: adesso lo vedi.';
    else if (k === 'automatico') t = 'Avevi detto che andavi avanti in automatico: ecco quanto è durato.';
  } else if (tipo === 'app'){
    t = k === inf.pkg ? 'Avevi detto ' + r.t + ': ci avevi visto giusto.' : (k === 'nonso' ? 'Adesso lo sai.' : 'Avevi detto ' + r.t + ': la tua attenzione è andata altrove.');
  } else if (tipo === 'stima'){
    const h = (inf.ms || 0) / 3600000 / (CV.dom.range === '7d' ? 1 : 1);
    const vero = CV.dom.range === '7d' ? (h < 10 ? 'poco' : h <= 25 ? 'medio' : 'tanto') : (h < 1 ? 'poco' : h <= 3 ? 'medio' : 'tanto');
    t = k === vero ? 'Avevi risposto "' + r.t + '": ci avevi visto giusto.' : 'Avevi risposto "' + r.t + '": il tempo vero è diverso da come lo sentivi.';
  } else if (tipo === 'fascia'){
    t = k === inf.fascia ? 'Avevi detto ' + r.t.toLowerCase() + ': ci avevi visto giusto.' : 'Avevi detto ' + r.t.toLowerCase() + ': ' + cvDoveT().preso + ' di più in un altro momento.';
  } else if (tipo === 'giornoMax'){
    t = k === String(inf.start) ? 'Avevi detto ' + r.t.toLowerCase() + ': ci avevi visto giusto.' : 'Avevi detto ' + r.t.toLowerCase() + ': era un altro giorno.';
  }
  return '<p class="cv-esito">' + cvEsc(t) + '</p>';
}
const CV_TITOLO_SENZA = 'Dal computer oggi *non è ancora arrivato niente*. Tocca "Mostra i dati del telefono" per vedere dove è andato il tuo tempo.';
/* ---------------------------------------------------------------------------------------
   LA COPIA DEL PANNELLO (0.9.302)

   Andrea: "il pannello della rivelazione deve essere LO STESSO IDENTICO pannello di Proteggi i tuoi sogni, clonato:
   con i tre puntini e con i dati veri di quella scelta". Il pannello fatto a mano qui dentro chiedeva i numeri al
   motore senza passare dal rapporto del giorno, si chiamava sempre "Oggi sul telefono" e non aveva i tre puntini:
   con i dati del computer scelti e il computer che oggi non aveva mandato niente diceva "0min" e "Nessuna app ha
   superato il minuto". Adesso esce da scPannelloHtml (scores.js), la stessa funzione di "Proteggi i tuoi sogni":
   stessa sorgente, stessa metrica, stessi tre puntini (metrica e dispositivo), e il periodo della revisione.
   I tocchi che porterebbero via dalla revisione (il Report, la pagina di un'app) qui non ci sono.
   --------------------------------------------------------------------------------------- */
function cvScRange(r){ return { oggi: 'today', ieri: 'yesterday', '7d': '7d', '30d': '30d', '90d': '90d', '365d': '365d' }[r] || 'today'; }
async function cvPanCorpo(evid){
  if (typeof scPannelloHtml !== 'function') return cvPannelloHtml(CV.pan, evid);
  let out = null;
  for (let i = 0; i < 3; i++){
    try{ out = await scPannelloHtml(CV.panV); }catch(_){ out = null; }
    if (out && !out.riprova && !out.annulla) break;
    await new Promise(function(r){ setTimeout(r, 700); });
  }
  if (!out || out.riprova || out.annulla) return null;
  if (out.negato || !out.html){
    return '<div class="rep-panel cv-pan-vuoto"><b>Qui c’è il tempo sul telefono, ora per ora.</b><p>Per vederlo serve l’accesso ai dati di utilizzo.</p>'
      + '<button type="button" class="cv-pan-perm" onclick="event.stopPropagation();if(typeof openPerm===\'function\')openPerm(\'usage\')">Dai l’accesso</button></div>';
  }
  let h = out.html.replace(/ onclick="(scTopTap|scOpenApp|scNotifSettings)\([^"]*\)"/g, '');
  if (out.dopa) setTimeout(function(){ try{ if (typeof dpVivo === 'function') dpVivo(); }catch(_){ } }, 0);
  /* l'ora (o il giorno) della domanda, quando non e' oggi: sotto al pannello, con le sue app */
  if (evid && evid.i >= 0 && !evid.oggi){
    const p = (CV.dom && CV.dom.pan) || CV.pan, b = p && p.buckets && p.buckets[evid.i];
    if (b){
      const fascia = p.win.bucket === 'hour' ? cvOra(new Date(b.start).getHours()) + ' - ' + cvOra((new Date(b.start).getHours() + 1) % 24) : (evid.nome || '');
      const app = (evid.app || []).slice(0, 3).map(function(a){ return cvEsc(a.label || a.packageName) + ' ' + cvOre(a.ms); }).join(', ');
      h += '<div class="cv-pan-ora"><b>' + cvEsc(fascia) + '</b><span>' + (app || cvOre(b.v) + ' ' + cvDoveT().sul) + '</span></div>';
    }
  }
  return h;
}
let CV_PAN_GIRO = 0, CV_PAN_T = 0;
/** La copia si ridisegna a ogni cambio del pannello (metrica, dispositivo, periodo, ora toccata): la chiama scBlockScores. */
function cvPanRidisegna(){
  if (!document.getElementById('cvPan') || !CV.panV) return;
  clearTimeout(CV_PAN_T);
  CV_PAN_T = setTimeout(async function(){
    const box = document.getElementById('cvPan');
    if (!box || !CV.panV) return;
    const giro = ++CV_PAN_GIRO;
    const h = await cvPanCorpo(null);
    const ora = document.getElementById('cvPan');
    if (giro !== CV_PAN_GIRO || !ora || h == null) return;
    ora.innerHTML = h;
    /* la frase sul computer in silenzio non vale piu' quando si guardano i dati del telefono */
    try{
      const el = document.getElementById('gnTesto');
      if (el && cvDove() !== 'computer' && el.textContent === CV_TITOLO_SENZA.replace(/\*/g, '') && typeof gnParti === 'function') el.innerHTML = gnParti('Ecco *dove è andato il tuo tempo* oggi.').html;
    }catch(_){ }
  }, 40);
}
/** Il periodo scelto dai tre puntini della copia: vale solo qui, "Proteggi i tuoi sogni" resta sul suo. */
function cvPanPeriodo(r){
  try{ if (typeof scMenusClose === 'function') scMenusClose(); }catch(_){ }
  if (!CV.panV) return;
  CV.panV.range = r;
  try{ if (typeof scOraVia === 'function') scOraVia(); }catch(_){ }
  cvPanRidisegna();
}
async function cvRivelaEntra(){
  try{ gnPosa('pensa'); const el = document.getElementById('gnTesto'); if (el) el.innerHTML = '<span class="rng-ai-pensa"><i></i><i></i><i></i></span>'; }catch(_){ }
  const passo0 = cvPasso(CV.modo);
  let p = (CV.dom && CV.dom.pan) || CV.pan || await CV.panP;
  /* il verdetto della prova (con Premium lo sta scrivendo il tuo agente personale) */
  if (CV.dom && CV.dom.cosa && CV.verP){ try{ await CV.verP; }catch(_){ } }
  if (cvPasso(CV.modo) !== passo0 || !GN.on) return;
  /* 0.9.303: il primo messaggio della chat parte adesso, mentre guardi i dati: quando tocchi "Parliamone" e' gia' li' */
  cvPrimoPrepara();
  const evid = CV.dom && CV.dom.evid;
  CV.panV = { range: cvScRange(p && p.range), dove: 'cv' };
  /* la domanda era sul tempo di schermo: il pannello si apre li', e l'ora della domanda resta accesa come quando
     la tocchi in "Proteggi i tuoi sogni" (il numero di quell'ora e le sue app) */
  if (evid && evid.i >= 0){
    try{ if (typeof scRepMetric === 'function' && scRepMetric() !== 'screen'){ SC.metric = 'screen'; localStorage.setItem('fl_rep_metric', 'screen'); } }catch(_){ }
    const b = p && p.buckets && p.buckets[evid.i];
    if (b && p.range === 'oggi' && p.win.bucket === 'hour' && typeof SC !== 'undefined'){
      let righe = evid.app || [];
      try{ righe = ((await NATIVE.getTopApps({ from: b.start, to: Math.min(Date.now(), b.start + 3600000), limit: 9, by: 'ms', icons: 12 })) || {}).apps || righe; }catch(_){ }
      SC.oraSel = evid.i; SC.oraDay = scDayStart(0); SC.oraMetric = 'screen'; SC.oraRighe = righe; SC.oraApps = righe;
      evid.oggi = true;
    }
  }
  const corpo = await cvPanCorpo(evid);
  let fila = ''; try{ fila = await cvFilaOraHtml(CV.dom); }catch(_){ fila = ''; }
  if (cvPasso(CV.modo) !== passo0 || !GN.on) return;
  const premium = cvPremium();
  /* la sera, senza chat: i dati li ha appena visti qui, la domanda sul focus arriva da sola (una cosa per schermata) */
  try{ if (CV.modo === 'rv'){ RV.visti = RV.visti || {}; RV.visti.focus = 1; } }catch(_){ }
  const bottoni = '<div class="or-grid one cv-riv-b">'
    + '<button type="button" class="or-a main" onclick="event.stopPropagation();cvDopoRivela()">' + (premium ? 'Parliamone' : 'Continua') + '</button>'
    + (cvVelata() ? '' : '<button type="button" class="or-a" onclick="event.stopPropagation();cvRivelaEsci();cvVai(\'cvFuturo\')">Cosa succede se non cambia niente</button>') + '</div>';
  try{ gnAu.musica && gnAu.musica(); }catch(_){ }
  const pannello = corpo == null ? cvPannelloHtml(p, evid) : '<div class="cv-pan" id="cvPan">' + corpo + '</div>';
  gnDomanda('rivela', cvTitoloRivela(), cvEsitoHtml() + fila + pannello + bottoni, function(){ cvPannelloVivo(evid && !evid.oggi ? evid : null); try{ flVibra([10, 30, 10]); }catch(_){ } });
}
/** Con la radiografia della Timeline: cosa hai fatto in quell'ora, riga per riga (la ricerca, il video, il sito). */
async function cvFilaOraHtml(d){
  if (!cvDomOra(d) || !d.cosa || typeof tlRadiografia !== 'function') return '';
  const off = d.info.ieri ? 1 : 0, da = cvMezzanotte(off) + d.info.ora * 3600000;
  const s = cvSequenza(await cvEventi(off, da, da + 3600000), 30).filter(function(x){ return x.cosa; }).slice(0, 4);
  if (!s.length) return '';
  return '<div class="cv-fila"><small>' + cvEsc(cvMai(cvMomento(d))) + ', riga per riga</small>'
    + s.map(function(x){ return '<p><b>' + cvEsc(x.ora.replace(/^0/, '')) + '</b><span>' + cvEsc(x.app + ': ' + x.cosa) + '</span></p>'; }).join('') + '</div>';
}
/* l'ora accesa dalla domanda vale solo qui: uscendo dalla rivelazione "Proteggi i tuoi sogni" torna a mostrare tutto */
function cvRivelaEsci(){ try{ if (typeof scOraVia === 'function' && SC.oraSel != null){ scOraVia(); if (typeof scBlockScores === 'function') scBlockScores(); } }catch(_){ } }
function cvDopoRivela(){
  cvRivelaEsci();
  if (cvPremium()){ cvVai('cvChat'); return; }
  cvVai(cvDopoLibero());
}

/* ---------------------------------------------------------------------------------------
   COSA SUCCEDE SE NON CAMBIA NIENTE
   --------------------------------------------------------------------------------------- */
function cvArt(t){ return /^(1|8|11)\b/.test(t) ? 'l’' + t : 'il ' + t; }
function cvTraiettoria(tipo){
  try{
    const s = (typeof ETA !== 'undefined') ? ETA.stato : null, inp = (typeof ETA !== 'undefined') ? ETA.inp : null;
    if (!s || !inp || typeof etaSimula !== 'function') return null;
    let rate = null, come = 'come oggi';
    if (tipo === 'sera' || tipo === 'rientro'){ const pian = (s.oreOggi || 0) + (s.creditoOggi || 0); if (pian > 0) rate = (s.creditoOggi || 0) / pian; }
    if (rate === null){
      const giorni = (tipo === 'mese' || tipo === 'trimestre' || tipo === 'anno') ? 30 : 7;
      come = giorni === 7 ? 'come questa settimana' : 'come quest’ultimo mese';
      let c = 0, pi = 0;
      (ETA.serie || []).forEach(function(d){ if (d.eta >= 1 && d.eta <= giorni && d.pian > 0 && !d.pausa){ c += d.credito || 0; pi += d.pian; } });
      if (pi > 0) rate = c / pi;
    }
    if (rate === null) return null;
    const sim = function(r){ return etaSimula(Object.assign({}, inp, { pool: { valori: [r], tabella: [0], media: r, sd: 0, n: 1 }, runs: 1, tilt: null })); };
    const ora = sim(Math.max(0.08, Math.min(2, rate))), piano = sim(Math.max(1, s.rate || 0));
    const fine = new Date().getFullYear() + 40;
    const txt = function(r){ return (r && isFinite(r.p50)) ? 'Arrivi ' + cvArt(etaDataTxt(r.p50)) : 'Non arrivi prima del ' + fine; };
    const out = { come: come, ora: ora.p50, piano: piano.p50, oraTxt: txt(ora), pianoTxt: txt(piano), rate: rate, target: s.target || 0 };
    if (isFinite(ora.p50) && isFinite(piano.p50)){
      const d = Math.round((ora.p50 - piano.p50) / 86400000), a = Math.abs(d);
      const y = Math.floor(a / 365), m = Math.floor((a % 365) / 30);
      out.diff = d; out.diffTxt = y ? y + (y === 1 ? ' anno' : ' anni') + (m ? ' e ' + m + (m === 1 ? ' mese' : ' mesi') : '') : (m ? m + (m === 1 ? ' mese' : ' mesi') : a + (a === 1 ? ' giorno' : ' giorni'));
    }
    if (out.target && typeof etaDataTxt === 'function') out.targetTxt = etaDataTxt(out.target);
    return out;
  }catch(_){ return null; }
}
function cvVelata(){ try{ return (typeof evVelata === 'function') && evVelata(); }catch(_){ return false; } }
function cvFuturoEntra(){
  /* 0.9.344, Andrea: "nella prima settimana la data non si vede, e la revisione fa gia' la previsione: e' prematuro" */
  if (cvVelata()){ cvDopoRivela(); return; }
  const tipo = cvTipo(), f = cvTraiettoria(tipo);
  const torna = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();cvDopoRivela()">' + (cvPremium() ? 'Parliamone' : 'Continua') + '</button></div>'
    + '<button type="button" class="gn-link" onclick="event.stopPropagation();gnIndietro()">Torna ai dati</button>';
  if (!f){
    gnDomanda('pensa', 'Per calcolare dove porta questa strada mi serve *il tuo piano delle ore*: lo imposti nella Mappa.', torna);
    return;
  }
  let titolo;
  if (!isFinite(f.ora)) titolo = 'Se ogni giorno va ' + f.come + ', *il sogno non arriva*. Con la rotta da tenere sì.';
  else if (f.diff > 0) titolo = 'Se ogni giorno va ' + f.come + ', il sogno arriva *' + f.diffTxt + ' più tardi*.';
  else if (f.diff < 0) titolo = 'Se ogni giorno va ' + f.come + ', il sogno arriva *' + f.diffTxt + ' prima*. Questa strada funziona.';
  else titolo = 'Se ogni giorno va ' + f.come + ', *sei sulla rotta giusta*.';
  const biv = (typeof bivSvg === 'function')
    ? '<div class="rng-biv cv-biv">' + bivSvg({ sx: { t: 'Se continui ' + f.come, s: f.oraTxt }, dx: { t: 'Con la rotta da tenere', s: f.pianoTxt }, scuro: f.diff > 0 || !isFinite(f.ora) ? 'sx' : '', compatto: true }) + '</div>'
    : '<div class="rng-futuri"><div class="rng-f giu"><small>Se continui ' + cvEsc(f.come) + '</small><b>' + cvEsc(f.oraTxt) + '</b></div><div class="rng-f su"><small>Con la rotta da tenere</small><b>' + cvEsc(f.pianoTxt) + '</b></div></div>';
  const meta = f.targetTxt ? '<p class="cv-meta">La data che ti eri dato: <b>' + cvEsc(f.targetTxt) + '</b>.' + (isFinite(f.ora) && f.ora > f.target ? ' A questo ritmo la superi.' : (isFinite(f.ora) ? ' A questo ritmo ci arrivi.' : '')) + '</p>' : '';
  gnDomanda(f.diff > 0 || !isFinite(f.ora) ? 'triste' : 'rivela', titolo, biv + meta + torna, function(){ try{ bivPronto(document.querySelector('.cv-biv')); }catch(_){ } });
}

/* ---------------------------------------------------------------------------------------
   LA CHAT CON IL TUO AGENTE
   --------------------------------------------------------------------------------------- */
function cvNomeAgente(){ try{ return (typeof agNomeSoggetto === 'function') ? agNomeSoggetto() : 'Il Genio'; }catch(_){ return 'Il Genio'; } }
function cvNomeA(){ try{ return (typeof agNomeA === 'function') ? agNomeA() : 'al Genio'; }catch(_){ return 'al Genio'; } }
function cvSogno(){
  try{ const o = (typeof orLast === 'function') ? orLast() : JSON.parse(localStorage.getItem('fl_oracle') || 'null'); const t = o && o.target; return CV_SOGNI.indexOf(t) >= 0 ? t : 'altro'; }catch(_){ return 'altro'; }
}
/* le risposte pronte di oggi, per fase: diventano pillole */
const CV_SISTEMA = {
  app: ['Blocco {app} nelle ore di lavoro', 'Telefono in un’altra stanza durante i blocchi', 'Tolgo {app} dal telefono'],
  notifiche: ['Lavoro solo in Full Focus, notifiche chiuse', 'Spengo le notifiche che non servono', 'Rispondo ai messaggi in due finestre fisse'],
  persone: ['Avviso prima: "adesso non ci sono"', 'Delego quello che può fare qualcun altro', 'Telefonate e messaggi in due finestre fisse'],
  testa: ['Le idee nuove nel caveau, subito', 'Scrivo i pensieri che girano, e torno', 'Dieci minuti di respiro prima del blocco'],
  energia: ['Il blocco difficile quando ho più energia', 'Stasera a letto prima', 'Blocchi più corti, con le pause'],
  '': ['Tengo il sistema com’è: funziona', 'Domani alzo l’asticella di un blocco']
};
function cvAppNome(){
  try{ if (CV.modo === 'rv' && RV.dati && RV.dati.app && RV.dati.app[0]) return RV.dati.app[0].nome; }catch(_){ }
  const p = CV.pan; return p && p.top && p.top[0] ? (p.top[0].label || '') : '';
}
/* 0.9.310: con Premium la revisione non chiede piu' "cosa farai": l'agente analizza, chiede il perche' solo quando serve,
   da' il verdetto e, se sei fuori rotta, propone lui il percorso nuovo. Le risposte pronte le scrive l'agente. */
const CV_FASI_REV = { resoconto: [], perche: [], verdetto: ['Sì, applicalo', 'No, tengo il percorso di adesso'] };
function cvFasi(tipo){
  const app = cvAppNome() || 'quell’app';
  if (tipo !== 'rientro') return CV_FASI_REV;
  if (tipo === 'sera'){
    const tr = CV.chat && CV.chat.trigger;
    return {
      focus: ['Sì, quasi sempre', 'A metà', 'Poco', 'Oggi niente lavoro profondo'],
      leva: ['Sulla cosa più importante', 'Su cose utili, non le più importanti', 'Sulle cose facili', 'Su niente del piano'],
      inter: cvOrdinaTesti('inter', [[ 'app', app !== 'quell’app' ? app : 'Un’app' ], ['notifiche', 'Le notifiche'], ['persone', 'Persone o telefonate'], ['testa', 'I miei pensieri, le idee nuove'], ['energia', 'Mi mancava l’energia'], ['niente', 'Niente, è filato liscio']]),
      sistema: (CV_SISTEMA[tr] || CV_SISTEMA['']).map(function(t){ return t.replace('{app}', app); }),
      imprevisto: ['No, tutto come previsto', 'Sì, c’è stato un imprevisto']
    };
  }
  if (tipo === 'rientro'){
    const prima = (typeof RNG_PRIMA !== 'undefined') ? RNG_PRIMA.map(function(o){ return o[2]; }) : [];
    const gr = (typeof RNG_GRILLETTI !== 'undefined') ? (CV.chat && (CV.chat.trigger === 'app' || /tentazione/i.test(CV.chat.prima || '')) ? RNG_GRILLETTI.app : RNG_GRILLETTI.vuoto) : [];
    const ten = (typeof RNG_TENUTO !== 'undefined') ? RNG_TENUTO.map(function(o){ return o[2]; }) : [];
    let allora = []; try{ allora = rngAlloraVoci().slice(0, 4).map(function(o){ return o[2]; }); }catch(_){ }
    return { prima: prima, grilletto: cvOrdinaTesti('grilletto', gr.map(function(o){ return [o[0], o[2]]; })), tenuto: ten, piano: ['Sì, proviamo', 'Preferisco un’altra strada'], patto: allora };
  }
  /* 0.9.310: le fasi dell'albero delle revisioni di periodo (revisioni-periodo.js) */
  try{ if (typeof rvpFasiChat === 'function') return rvpFasiChat(); }catch(_){ }
  return {};
}
function cvChatNuova(){
  CV.chat = { tipo: cvTipo(), msgs: [], fase: '', trigger: '', pillole: [], attesa: false, errore: false, fine: false, riepilogo: null, aiuto: '', applicati: [], dopo: [] };
}
const CV_SCELTE = [['attento', 'Più attento'], ['veloce', 'Veloce']];
function cvScelta(){ try{ return localStorage.getItem('fl_cv_scelta') === 'veloce' ? 'veloce' : 'attento'; }catch(_){ return 'attento'; } }
function cvSceltaSet(v){ try{ localStorage.setItem('fl_cv_scelta', v === 'veloce' ? 'veloce' : 'attento'); }catch(_){ } try{ toast(v === 'veloce' ? 'Risposte veloci' : 'Risposte più ragionate: ci mette qualche secondo in più'); }catch(_){ } }
function cvChatEntra(){
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('cv-on');
  if (!CV.chat) cvChatNuova();
  /* 0.9.335: una modifica lasciata a meta' (indietro prima di inviare) non cancella niente: il messaggio resta com'era */
  if (CV.chat) CV.chat.inModifica = null;
  const r = document.getElementById('gnRisp'); if (!r) return;
  const ph = 'Rispondi ' + cvNomeA() + '…';
  r.innerHTML = '<div class="cv-chat">'
    + '<div class="cv-testa">' + (typeof agAvatarHtml === 'function' ? agAvatarHtml('cv-av') : '<span class="ag-av cv-av">🧞</span>') + '<div><b>' + cvEsc(cvNomeAgente()) + '</b><small>' + cvEsc(CV_NOMI[CV.chat.tipo] || '') + '</small></div></div>'
    + '<div class="cv-lista" id="cvLista"></div>'
    + '<div class="cv-piede" id="cvPiede"><div class="cv-pill" id="cvPill" role="list"></div>'
    + '<div class="cv-comp"><textarea id="cvTesto" rows="1" data-no-dettatura placeholder="' + cvEsc(ph) + '" oninput="cvCampo()" onkeydown="cvTasto(event)" onclick="event.stopPropagation()"></textarea>'
    /* 0.9.335, Andrea: "voglio poter scegliere il modello e il ragionamento anche qui" */
    + '<label class="cv-mod" onclick="event.stopPropagation()"><select aria-label="Il modello" onchange="cvSceltaSet(this.value)">' + CV_SCELTE.map(function(x){ return '<option value="' + x[0] + '"' + (cvScelta() === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><svg viewBox="0 0 12 8" width="10" height="7" aria-hidden="true"><path d="M1 1.5l5 5 5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></label>'
    + (typeof micTocca === 'function' ? '<button type="button" class="cv-mic" aria-label="Detta con la voce" onclick="event.stopPropagation();micTocca(\'cvTesto\', this)">' + CV_MIC_SVG + '</button>' : '')
    + '<button type="button" class="cv-invia" id="cvInvia" aria-label="Invia" onclick="event.stopPropagation();cvInvia()">' + CV_INVIA_SVG + '</button></div></div></div>';
  if (!CV.chat.msgs.length && !CV.chat.attesa && cvPrimoLocale()){ cvChatPaint(true); if (CV.chat.chiediSubito) cvChatChiedi('resoconto'); return; }
  cvChatPaint();
  if (!CV.chat.msgs.length && !CV.chat.attesa) cvChatChiedi('');
}
/* IL PRIMO MESSAGGIO, SUBITO (0.9.310). Andrea (screenshot 731): "toccando Parliamone resta coi tre puntini per tanto
   tempo". La causa: la chat non mostrava niente finche' il modello sul server non rispondeva (la richiesta partiva con
   tutti i dati della giornata o del periodo, e se quella preparata in anticipo falliva ne partiva una seconda, fino a
   25 secondi). Nelle revisioni il primo messaggio lo scrive l'app con i dati veri (il recap e la prima domanda, con
   le sue risposte pronte): compare all'istante, e il tuo agente personale risponde dalla tua prima risposta in poi. */
function cvPrimoLocale(){
  const c = CV.chat; let x = null;
  try{
    if (CV.modo === 'rvp' && typeof rvpPrimiMessaggi === 'function') x = rvpPrimiMessaggi();
    else if (CV.modo === 'rv') x = cvPrimiSera();
  }catch(_){ x = null; }
  if (!x || !x.msgs || !x.msgs.length) return false;
  x.msgs.forEach(function(t, i){ c.msgs.push({ chi: 'genio', t: t, at: Date.now() + i, locale: true }); });
  c.fase = x.fase || ''; c.pillole = x.pillole || [];
  /* 0.9.310 (seconda richiesta di Andrea): dopo il recap il resoconto lo scrive il tuo agente personale, dai dati */
  c.chiediSubito = !!x.chiedi;
  return true;
}
/** La sera: com'e' andata la giornata (Full Focus, le app di oggi) e la prima domanda, sulla concentrazione. */
function cvPrimiSera(){
  const d = (typeof RV !== 'undefined' && RV.dati) || null; if (!d) return null;
  const r = ['Ecco *la tua giornata*.'];
  if (d.ff && d.ff.n) r.push('⏱️ Hai fatto ' + (d.ff.n === 1 ? '1 sessione' : d.ff.n + ' sessioni') + ' di Full Focus, per ' + cvOre(d.ff.min * 60000) + (d.ff.mollate ? ', e ' + (d.ff.mollate === 1 ? 'una l’hai interrotta' : d.ff.mollate + ' le hai interrotte') : '') + '.');
  else r.push('⏱️ Oggi non hai fatto sessioni di Full Focus.');
  if (d.app && d.app[0]) r.push('📱 Sul telefono: ' + cvOre(d.app[0].min * 60000) + ' su ' + d.app[0].nome + (d.app[1] ? ' e ' + cvOre(d.app[1].min * 60000) + ' su ' + d.app[1].nome : '') + '.');
  if (d.prio) r.push((d.prioFatta ? '✅' : '⭕') + ' La priorità di oggi era "' + d.prio + '": ' + (d.prioFatta ? 'l’hai chiusa.' : 'non è ancora chiusa.'));
  /* il resoconto e le domande sul perche' li scrive il tuo agente personale (cvChatChiedi('resoconto')) */
  return { msgs: [r.join('\n')], fase: 'resoconto', pillole: [], chiedi: true };
}
function cvMd(t){
  let h = cvEsc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<b>$1</b>');
  return h.split(/\n{2,}/).map(function(p){ return '<p>' + p.replace(/\n/g, '<br>') + '</p>'; }).join('');
}
function cvGiorniTxt(g){
  if (!Array.isArray(g) || g.every(Boolean)) return 'tutti i giorni';
  if (g.slice(0, 5).every(Boolean) && !g[5] && !g[6]) return 'dal lunedì al venerdì';
  const n = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'];
  return g.map(function(x, i){ return x ? n[i] : ''; }).filter(Boolean).join(', ');
}
function cvAppNomi(pkgs){
  const tutte = ((CV.pan && CV.pan.top) || []).concat((CV.datiAg && CV.datiAg.app) || []);
  return (pkgs || []).map(function(p){ const x = tutte.filter(function(a){ return (a.packageName || a.pkg) === p; })[0]; return x ? (x.label || x.nome) : p; }).join(', ');
}
const CV_AZIONI = {
  focus: 'Quando arriva la tentazione, parte una sessione di Full Focus con le notifiche chiuse.',
  caveau: 'Le idee nuove vanno subito nel caveau, e torni alla priorità.',
  respiro: 'Prima del lavoro sul sogno, un respiro guidato di due minuti.',
  notifiche: 'Spegni le notifiche dell’app che ti interrompe.',
  mattina: 'Il lavoro più difficile la mattina, quando hai più energia.'
};
function cvPianoDesc(p){
  if (p.tipo === 'blocco') return 'Blocco di ' + cvAppNomi(p.app) + ' dalle ' + p.dalle + ' alle ' + p.alle + ', ' + cvGiorniTxt(p.giorni) + '.';
  if (p.tipo === 'limite') return cvAppNomi(p.app) + ' al massimo ' + p.minutiGiorno + ' minuti al giorno, poi si blocca.';
  if (p.azione === 'notifiche' && p.app && p.app.length) return 'Spegni le notifiche di ' + cvAppNomi(p.app) + '.';
  return CV_AZIONI[p.azione] || '';
}
function cvPianoHtml(p, i){
  const stato = p.stato === 'si' ? '<div class="cv-piano-ok">Applicato</div>' : p.stato === 'no' ? '<div class="cv-piano-no">Non applicato</div>'
    : '<div class="cv-piano-b"><button type="button" class="or-a main" onclick="event.stopPropagation();cvPianoSi(' + i + ')">Sì, applicalo</button><button type="button" class="or-a" onclick="event.stopPropagation();cvPianoNo(' + i + ')">No, grazie</button></div>';
  return '<div class="cv-piano"><small>Il piano su misura</small><b>' + cvEsc(p.nome) + '</b><p>' + cvEsc(cvPianoDesc(p)) + '</p>' + (p.perche ? '<p class="cv-perche">' + cvEsc(p.perche) + '</p>' : '') + stato + '</div>';
}
function cvChatPaint(nuovo){
  const c = CV.chat, l = document.getElementById('cvLista'); if (!c || !l) return;
  let h = c.msgs.map(function(m, i){
    if (m.chi === 'nota') return '<div class="cv-nota">' + cvEsc(m.t) + '</div>';
    const lui = m.chi === 'genio';
    return '<div class="cv-m ' + (lui ? 'lui' : 'io') + (nuovo && i === c.msgs.length - 1 && lui ? ' cv-nuovo' : '') + (c.inModifica === i ? ' cv-mod-on' : '') + '"><div class="cv-b">' + (lui ? cvMd(m.t) : cvEsc(m.t).replace(/\n/g, '<br>')) + '</div></div>'
      + (lui && m.piano ? cvPianoHtml(m.piano, i) : '')
      + (lui && m.percorso ? cvPercorsoHtml(m.percorso, i) : '');
  }).join('');
  if (c.attesa) h += '<div class="cv-m lui"><div class="cv-b cv-pensa"><i></i><i></i><i></i><span>' + (cvScelta() === 'veloce' ? '' : 'Sta pensando') + '</span></div></div>';
  /* 0.9.346: se anche la seconda richiesta fallisce, si dice perche', il pulsante c'e' sempre, e intanto l'app riprova da sola ogni 20 secondi */
  if (c.errore) h += '<div class="cv-err cv-err2"><p>Il servizio che fa rispondere ' + cvEsc(cvNomeAgente().replace(/^Il /, 'il ')) + ' è sovraccarico.</p><small>Sto riprovando da solo. La tua risposta è salva.</small>'
    + '<button type="button" class="cv-err-btn" onclick="event.stopPropagation();cvChatChiedi(CV.chat.evento||\'\')">Riprova adesso</button>'
    + ((CV.modo === 'rvp' || CV.modo === 'rv') ? '<button type="button" class="gn-link" onclick="event.stopPropagation();cvChatAlbero()">Continua con le domande del Genio</button>' : '') + '</div>';
  if (c.fine) h += cvFineHtml();
  l.innerHTML = h;
  const piede = document.getElementById('cvPiede'); if (piede) piede.hidden = !!c.fine;
  cvPillPaint();
  cvCampo();
  l.scrollTop = l.scrollHeight;
  cvChatBarra();
  if (nuovo){ const ul = l.querySelector('.cv-m.cv-nuovo .cv-b'); if (ul) cvScrivePiano(ul, l); }
}
/* 0.9.335, Andrea: "nel Rientra non c'e' l'animazione del testo che c'e' nella chat con il mio agente". Lo stesso passo
   di agente.js: circa 45 lettere al secondo, a parole intere; un tocco mostra tutto. */
function cvScrivePiano(el, lista){
  const nodi = []; const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let n; while ((n = w.nextNode())) nodi.push([n, n.nodeValue]);
  const tot = nodi.reduce(function(a, x){ return a + x[1].length; }, 0); if (tot < 2) return;
  nodi.forEach(function(x){ x[0].nodeValue = ''; });
  const D = Math.min(30000, Math.max(900, tot * 22)), t0 = performance.now();
  let fine = false; const tutto = function(){ fine = true; };
  if (lista) lista.addEventListener('click', tutto, { once: true });
  /* 0.9.344, Andrea: "se provo a scorrere mentre compare il nuovo percorso lo schermo trema e torna giu'". Mentre il testo si scriveva
     l'elenco veniva riportato in fondo a ogni fotogramma: appena tocchi o scorri, l'app smette di seguirlo */
  let seguo = true; const mollo = function(){ seguo = false; };
  if (lista){ ['touchstart', 'wheel', 'pointerdown'].forEach(function(k){ lista.addEventListener(k, mollo, { passive: true, once: true }); }); }
  const pill = document.getElementById('cvPill'); if (pill) pill.style.visibility = 'hidden';
  const passo = function(t){
    if (!el.isConnected){ if (pill) pill.style.visibility = ''; return; }
    const q = fine ? 1 : Math.min(1, (t - t0) / D);
    let quanti = Math.round(tot * q);
    nodi.forEach(function(x){ const testo = x[1]; let k = Math.max(0, Math.min(testo.length, quanti)); if (k > 0 && k < testo.length && q < 1){ const sp = testo.lastIndexOf(' ', k); k = sp > 0 ? sp : k; } x[0].nodeValue = testo.slice(0, k); quanti -= testo.length; });
    if (seguo && lista && lista.scrollHeight - lista.scrollTop - lista.clientHeight < 80) lista.scrollTop = lista.scrollHeight;
    if (q < 1) requestAnimationFrame(passo);
    else { if (lista){ lista.removeEventListener('click', tutto); if (seguo) lista.scrollTop = lista.scrollHeight; } if (pill) pill.style.visibility = ''; }
  };
  requestAnimationFrame(passo);
}
function cvChatBarra(){
  const c = CV.chat; if (!c) return;
  const ord = { rientro: ['prima', 'grilletto', 'tenuto', 'piano', 'patto', 'fine'] }[c.tipo] || ['resoconto', 'perche', 'verdetto', 'fine'];
  const i = Math.max(0, ord.indexOf(c.fase));
  const p = c.fine ? 1 : 0.3 + 0.65 * (i / ord.length);
  const bar = document.getElementById('gnProgBar'); if (bar) bar.style.width = Math.round(p * 100) + '%';
}
function cvPillPaint(){
  const c = CV.chat, box = document.getElementById('cvPill'); if (!c || !box) return;
  const fasi = cvFasi(c.tipo);
  /* un piano che aspetta il si' o il no ha i suoi due pulsanti: niente pillole sotto, che distrarrebbero */
  const ultimo = c.msgs.filter(function(m){ return m.chi === 'genio'; }).pop();
  const aspetta = !!(ultimo && ((ultimo.piano && !ultimo.piano.stato) || (ultimo.percorso && !ultimo.percorso.stato)));
  const l = aspetta ? [] : (c.pillole && c.pillole.length ? c.pillole : (fasi[c.fase] || [])).slice(0, 8);
  c.pilloleViste = l;
  box.innerHTML = l.map(function(t, i){ return '<button type="button" role="listitem" onclick="event.stopPropagation();cvPillTocca(' + i + ')">' + cvPillIco(t) + '<span>' + cvEsc(t) + '</span></button>'; }).join('');
  box.classList.toggle('vuota', !l.length || c.attesa);
}
function cvCampo(){
  const t = document.getElementById('cvTesto'); if (!t) return;
  t.style.height = 'auto'; t.style.height = Math.min(160, t.scrollHeight + 2) + 'px';
  const pieno = !!t.value.trim();
  const box = document.getElementById('cvPill'); if (box) box.classList.toggle('via', pieno);
  const b = document.getElementById('cvInvia'); if (b) b.classList.toggle('on', pieno && !(CV.chat && CV.chat.attesa));
}
/* LE ICONE DELLE PILLOLE (0.9.303): le stesse delle pill della home dell'agente (agSugIco e agSvg di agente.js: stesso
   disegno, stesso tratto). Per le risposte che la home non ha, il disegno si aggiunge allo stesso elenco AG_ICO. */
const CV_ICO_IN_PIU = {
  telefono: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M11 18h2"/>',
  batteria: '<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 11v2M6 10v4"/>',
  campanella: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
  lampadina: '<path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.3h6c0-1 .4-1.8 1-2.3A7 7 0 0 0 12 2z"/>',
  respiro: '<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/>'
};
function cvPillIco(t){
  try{
    const base = (typeof agSugIco === 'function') ? agSugIco(t) : '';
    if (base || typeof agSvg !== 'function' || typeof AG_ICO === 'undefined') return base;
    Object.keys(CV_ICO_IN_PIU).forEach(function(k){ if (!AG_ICO[k]) AG_ICO[k] = CV_ICO_IN_PIU[k]; });
    const s = String(t || '').toLowerCase();
    const n = /tentazion|telefono|scroll|instagram|tiktok|youtube|google|chrome|social|reel|video|app\b|l.ho aperto|aperto/.test(s) ? 'telefono'
      : /notific|messagg|chiamat|telefonat/.test(s) ? 'campanella'
      : /stanc|energia|sonno|letto|riposo/.test(s) ? 'batteria'
      : /idea|idee|pensier|caveau|testa|confus/.test(s) ? 'lampadina'
      : /respir/.test(s) ? 'respiro'
      : /persone|delego|avviso|amic|famiglia|qualcun/.test(s) ? 'persona'
      : /strada|piano|rotta|blocco/.test(s) ? 'mappa'
      : /^(sì|si\b|niente|tutto|esatto|giusto|proviamo|confermo|va bene|è andata)/.test(s) ? 'spunta'
      : 'canali';
    return agSvg(n, 15);
  }catch(_){ return ''; }
}
/* 0.9.335, Andrea: "la risposta breve parte subito; quella lunga, con il testo troncato, va nel campo per completarla" */
function cvPillTocca(i){
  const c = CV.chat, t = document.getElementById('cvTesto'); if (!c || !t) return;
  const v = (c.pilloleViste || [])[i]; if (!v) return;
  const b = document.querySelectorAll('#cvPill button')[i], sp = b && b.querySelector('span');
  const tagliata = !sp || sp.scrollWidth > sp.clientWidth + 1 || v.length > 42;
  if (!tagliata){ t.value = v; try{ flVibra(8); }catch(_){ } cvInvia(); return; }
  t.value = v; cvCampo();
  try{ t.focus(); t.setSelectionRange(v.length, v.length); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
}
function cvTasto(e){
  if (e.key !== 'Enter' || e.shiftKey) return;
  let tocco = false; try{ tocco = window.matchMedia('(pointer: coarse)').matches; }catch(_){ }
  if (tocco) return;
  e.preventDefault(); cvInvia();
}
function cvInvia(){
  const c = CV.chat, t = document.getElementById('cvTesto'); if (!c || !t || c.attesa || c.fine) return;
  const all = (typeof DRS_ALL !== 'undefined') ? DRS_ALL.l : [];
  const v = t.value.trim() || (all.length ? (all.length === 1 ? 'Guarda l’allegato.' : 'Guarda gli allegati.') : ''); if (!v) return;
  if (c.inModifica != null){ c.msgs = c.msgs.slice(0, c.inModifica); c.inModifica = null; c.fine = false; c.errore = false; c.pillole = []; }
  /* 0.9.321: foto e file vanno con questo messaggio; nella chat resta il loro nome */
  CV.allegati = all.slice(); if (all.length) DRS_ALL.l = [];
  c.msgs.push({ chi: 'io', t: v + (all.length ? '\n📎 ' + all.map(function(a){ return a.nome || 'Foto'; }).join(', ') : ''), at: Date.now() });
  if (c.tipo === 'rientro' && !c.prima) c.prima = v;
  t.value = '';
  try{ flVibra(10); }catch(_){ }
  cvChatChiedi('');
}
/* LO SPOSTAMENTO DELL'ARRIVO, DETTO COM'E' (0.9.303): "13 ore", "1 giorno e 4 ore", con le cause del navigatore */
function cvTempoParole(ms){ return (typeof etaTempoParole === 'function') ? etaTempoParole(ms) : cvOre(Math.abs(ms)); }
function cvSpostamento(){
  const v = (typeof RNG !== 'undefined') ? RNG.visto : null; if (!v) return null;
  const out = { daQuando: v.giorniFa > 1 ? 'negli ultimi ' + v.giorniFa + ' giorni' : 'da ieri' };
  if (v.nuova){ out.nota = 'La rotta è nuova: il confronto riparte da oggi, non c’è uno spostamento da spiegare.'; return out; }
  if (isFinite(v.delta) && Math.abs(v.delta) >= 60000){ out.quanto = cvTempoParole(v.delta); out.verso = v.delta > 0 ? 'più in là' : 'prima'; }
  else out.quanto = '';
  out.cause = (v.voci || []).slice(0, 5).map(function(x){
    return { cosa: String(x.t || '').replace(/[«»]/g, '"'), spostamento: isFinite(x.delta) && Math.abs(x.delta) >= 60000 ? (x.delta > 0 ? 'più in là di ' : 'prima di ') + cvTempoParole(x.delta) : 'nessuno' };
  });
  return out;
}
/* LO SGARRO E IL SUO GRILLETTO (0.9.303). Andrea: "l'agente non deve far spremere le meningi all'utente: deve dedurre
   da solo il trigger dai dati e mostrarlo". Lo sgarro e' il tratto piu' lungo di oggi passato sulle app che distraggono
   (le pause sotto i 3 minuti non lo spezzano); la sequenza sono i 45 minuti prima e il suo inizio, riga per riga. */
const CV_DISTR_IN_PIU = ['com.android.chrome', 'com.google.android.googlequicksearchbox', 'org.mozilla.firefox', 'com.brave.browser', 'com.sec.android.app.sbrowser', 'com.microsoft.emmx', 'com.opera.browser'];
function cvDistrae(pkg, ts){
  let c = {}; try{ c = (typeof insCats === 'function') ? (insCats(ts) || {}) : {}; }catch(_){ c = {}; }
  if (c[pkg]) return c[pkg] === 'distr';
  const l = (typeof PRC_DISTR !== 'undefined') ? PRC_DISTR : [];
  return l.indexOf(pkg) >= 0 || CV_DISTR_IN_PIU.indexOf(pkg) >= 0;
}
async function cvSgarro(){
  const g = await cvGrani(0); if (!g.length) return null;
  const tot = {};
  g.forEach(function(x){ const t = tot[x.p] = tot[x.p] || { pkg: x.p, nome: x.l, ms: 0 }; t.ms += x.ms; });
  const out = { app: Object.keys(tot).map(function(k){ return tot[k]; }).sort(function(a, b){ return b.ms - a.ms; }).slice(0, 10).map(function(x){ return { pkg: x.pkg, nome: x.nome, min: Math.round(x.ms / 60000) }; }) };
  /* com'e' cominciata la giornata: il primo uso dopo le 4 e la prima ora */
  const giorno = g.filter(function(x){ return new Date(x.s).getHours() >= 4; });
  if (giorno.length){
    const s0 = giorno[0].s, m = {};
    giorno.forEach(function(x){ const a = Math.max(s0, x.s), b = Math.min(s0 + 3600000, x.s + x.ms); if (b > a) m[x.l] = (m[x.l] || 0) + (b - a); });
    out.inizio = { primoUso: cvHM(s0), primaOra: Object.keys(m).map(function(k){ return { app: k, min: Math.round(m[k] / 60000) }; }).filter(function(x){ return x.min >= 1; }).sort(function(a, b){ return b.min - a.min; }).slice(0, 3) };
  }
  const catene = []; let cur = null;
  g.forEach(function(x){
    if (!cvDistrae(x.p, x.s)) return;
    if (cur && x.s - cur.e <= 3 * 60000){ cur.e = Math.max(cur.e, x.s + x.ms); cur.ms += x.ms; cur.app[x.l] = (cur.app[x.l] || 0) + x.ms; return; }
    cur = { s: x.s, e: x.s + x.ms, ms: x.ms, app: {} }; cur.app[x.l] = x.ms; catene.push(cur);
  });
  const sg = catene.sort(function(a, b){ return b.ms - a.ms; })[0];
  if (sg && sg.ms >= 10 * 60000){
    const ev = await cvEventi(0, sg.s - 45 * 60000, Math.min(sg.e, sg.s + 30 * 60000));
    const prima = cvSequenza(ev.filter(function(e){ return e.t < sg.s; }), 10), dentro = cvSequenza(ev.filter(function(e){ return e.t >= sg.s; }), 6);
    out.sgarro = { inizio: cvHM(sg.s), fine: cvHM(sg.e), minuti: Math.round(sg.ms / 60000),
      app: Object.keys(sg.app).map(function(k){ return { nome: k, min: Math.round(sg.app[k] / 60000) }; }).sort(function(a, b){ return b.min - a.min; }).slice(0, 4),
      nellePrimeOreDelGiorno: !!(out.inizio && giorno.length && sg.s - giorno[0].s < 2 * 3600000),
      neiQuarantacinqueMinutiPrima: prima, inizioDelloSgarro: dentro };
  }
  return out;
}
/* IL PRIMO MESSAGGIO, PREPARATO PRIMA (0.9.303). Andrea: "il primo messaggio dell'agente ci mette troppo a comparire".
   La richiesta parte quando si apre la rivelazione (i dati sono gia' letti e la risposta alla domanda c'e'): mentre
   guardi il pannello il tuo agente personale scrive, e la chat si apre con il messaggio gia' li'. */
/* 0.9.346, Andrea: "Il Genio non ha risposto. Perché? Deve rispondere, punto". LA CAUSA (misurata sul server): il modello "Più attento"
   nelle ore di punta risponde "sovraccarico" dopo 32 secondi, o resta appeso oltre i 75 che l'app aspettava. Il server adesso passa alla
   riserva entro 22 secondi (focuslockConversa.ts). Qui: se la prima richiesta fallisce, parte da sola una seconda con il modello veloce. */
function cvChiamaUna(corpo, ms){
  return Promise.race([agApi('POST', '/api/focuslock/agent/conversa', corpo), new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, ms); })])
    .then(function(r){ if (!r || !r.testo) throw new Error((r && r.error) || 'risposta vuota'); return r; });
}
function cvChiamaAgente(corpo){
  corpo.scelta = cvScelta();
  return cvChiamaUna(corpo, 78000).catch(function(){ return cvChiamaUna(Object.assign({}, corpo, { scelta: 'veloce' }), 45000); });
}
async function cvCorpo(c, evento){
  const tipo = c ? c.tipo : cvTipo();
  const dati = Object.assign({}, await cvDatiPerAgente(), { pianiApplicati: c ? c.applicati.slice(-3) : [] });
  return { tipo: tipo, nomeAgente: (typeof agNomeAgente === 'function' ? agNomeAgente() : 'Genio'), sogno: cvSogno(), evento: evento || '',
    messaggi: c ? c.msgs.filter(function(m){ return m.chi !== 'nota'; }).map(function(m){ return { chi: m.chi, t: m.t }; }) : [], dati: dati, fasi: cvFasi(tipo),
    allegati: (function(){ const l = (CV.allegati || []).map(function(a){ return { tipo: a.tipo, mime: a.mime, nome: a.nome, dati: a.dati }; }); CV.allegati = []; return l; })() };
}
function cvPrimoPrepara(){
  if (CV.primo || (CV.chat && CV.chat.msgs.length) || !cvPremium() || typeof agApi !== 'function') return;
  /* 0.9.310: nelle revisioni il recap lo scrive l'app all'istante (cvPrimoLocale); qui parte in anticipo il resoconto
     dell'agente, con l'analisi del periodo (cvDatiPerAgente), mentre guardi i dati */
  const x = { at: Date.now(), ev: (CV.modo === 'rv' || CV.modo === 'rvp') ? 'resoconto' : '' };
  x.p = cvCorpo(null, x.ev).then(cvChiamaAgente);
  x.p.catch(function(){ });
  CV.primo = x;
}
/* I DATI PER IL TUO AGENTE: la giornata vera, niente nomi */
async function cvDatiPerAgente(){
  if (CV.datiAg) return CV.datiAg;
  /* 0.9.335: senza i dati del tempo (permesso mancante, lettura fallita) la chat risponde lo stesso */
  let p = CV.pan; if (!p && CV.panP){ try{ p = await CV.panP; }catch(_){ p = null; } } p = p || { win: {} };
  const ad = new Date();
  const d = { tipo: cvTipo(), adesso: String(ad.getHours()).padStart(2, '0') + ':' + String(ad.getMinutes()).padStart(2, '0'), giorno: CV_GIORNI[ad.getDay()] + ' ' + ad.getDate() + '/' + (ad.getMonth() + 1) };
  try{ const a = (typeof agDati === 'function') ? agDati() : {}; d.sogno = a.sogno || a.target || ''; d.arrivoPrevisto = cvVelata() ? '' : (a.arrivo || ''); if (cvVelata()) d.dataVelata = 'La data di arrivo non è ancora visibile per lui (i primi giorni il Genio impara le sue abitudini): nessuna data e nessuna previsione.'; d.oreSettimana = a.ore || 0; d.righeOggi = (a.righe || []).slice(0, 8); d.orizzonti = (a.orizzonti || []).filter(function(x){ return x.k === 'oggi' || x.k === 'settimana'; }); }catch(_){ }
  d.tempo = { dispositivo: (typeof mwEtichetta === 'function') ? mwEtichetta() : 'telefono', periodo: p.win && p.win.label, totale: cvOre(p.ms), sblocchi: p.pickups,
    fasce: (p.buckets || []).filter(function(b){ return b.v >= 60000; }).map(function(b){ const t = new Date(b.start); return { quando: p.win.bucket === 'hour' ? cvOra(t.getHours()) : CV_GIORNI[t.getDay()] + ' ' + t.getDate(), minuti: Math.round(b.v / 60000) }; }).slice(-24) };
  d.app = (p.top || []).slice(0, 8).map(function(a){ return { pkg: a.packageName, nome: a.label || a.packageName, min: Math.round((a.ms || 0) / 60000) }; });
  /* le app ora per ora, dalla cronologia del telefono (la stessa lettura del rientro) */
  try{
    if (p.win.bucket === 'hour' && NATIVE && NATIVE.getTimeline && typeof rngAiFondi === 'function'){
      /* la cronologia di oggi e' gia' stata letta all'inizio (cvGrani): non si rilegge */
      const t = p.range === 'oggi' ? { granted: true, grani: await cvGrani(0) } : await NATIVE.getTimeline({ from: p.win.from, to: p.win.to, minMs: 0, limit: 6000 });
      if (t && t.granted){
        const ore = {}; rngAiFondi(t.grani).forEach(function(x){ const h = new Date(x.s).getHours(); ore[h] = ore[h] || {}; ore[h][x.l] = (ore[h][x.l] || 0) + x.ms; });
        d.appOraPerOra = Object.keys(ore).map(function(h){ const m = ore[h]; return { ora: cvOra(+h), app: Object.keys(m).map(function(k){ return { nome: k, min: Math.round(m[k] / 60000) }; }).filter(function(x){ return x.min >= 3; }).sort(function(a, b){ return b.min - a.min; }).slice(0, 3) }; }).filter(function(x){ return x.app.length; });
      }
    }
  }catch(_){ }
  if (CV.modo === 'rv'){
    try{ const r = RV.dati || {}; d.fullFocus = r.ff; d.priorita = r.prio; d.prioritaChiusa = !!r.prioFatta; d.coseChiuse = (r.chiuse || []).slice(0, 6); }catch(_){ }
    try{ const u = rvUmoreOggi(); if (u && u.sodd) d.umore = { voto: u.sodd + ' su 5', nota: String(u.nota || '').slice(0, 300) }; }catch(_){ }
  }
  if (CV.modo === 'rvp'){
    try{ d.periodo = RVP.dati; d.tappaDelPeriodo = (RVP.dati || {}).tappa || ''; }catch(_){ }
    try{ d.recapDelPeriodo = rvpRecapRighe().map(function(r){ return r[1]; }); d.quando = rvpParole().in; d.prossimoPeriodo = rvpParole().prossimo; }catch(_){ }
    try{ const ro = (RVP.dati || {}).rotta; if (ro){ d.arrivo = { oggi: rvpDataTxt(ro.oggi), spostamentoGiorni: ro.giorni, dal: ro.daK }; d.fuoriRotta = !!(ro.giorni > 0); } }catch(_){ }
    try{ d.revisioniIncluse = (RVP.inclusi || []).map(function(x){ return x.tipo; }); }catch(_){ }
  }
  if (CV.modo === 'rn'){
    /* 0.9.303, Andrea: "addirittura un giorno per quelle cose mi sembra eccessivo". Lo spostamento passava arrotondato al
       giorno (prcGiorni: 13 ore diventavano "1 giorno") e senza le sue cause: l'agente lo attribuiva ai minuti sulle app
       di oggi. Adesso va detto com'e' (ore se sono ore) e con le cause vere del navigatore, una per una. */
    try{ const sp = cvSpostamento(); if (sp){ d.spostamento = sp; if (sp.quanto) d.arrivoSpostato = sp.quanto + ' ' + (sp.verso || ''); } }catch(_){ }
    try{ d.cosaFare = rnTask() || ''; }catch(_){ }
    /* 0.9.344, Andrea: "dice che ieri non ho lavorato al negozio, e invece ho fatto 2 ore su admin.shopify.com e 5 su Claude". Le ore
       'sul sogno' del navigatore contano solo Full Focus e i programmi segnati produttivi: qui arriva cosa ha fatto davvero al computer */

    try{ d.premi = rngPremi().map(function(x){ return x.az || x.t; }).slice(0, 8); }catch(_){ }
  }
  /* 0.9.303: lo sgarro piu' lungo di oggi con quello che c'era nei 45 minuti prima, e com'e' cominciata la giornata.
     L'agente deduce da qui il grilletto e lo dice lui, invece di chiederlo */
  if ((CV.modo === 'rn' || CV.modo === 'rv') && p.range === 'oggi'){
    try{ const sg = await cvSgarro(); if (sg){ d.sgarro = sg.sgarro; d.inizioGiornata = sg.inizio; d.appTutte = sg.app; } }catch(_){ }
  }
  /* 0.9.346, Andrea: "l'agente deve sempre prendere i dati da tutti e due, telefono e computer, non solo da quello che sto filtrando".
     dati.tempo e dati.app restano della sorgente a schermo; qui arrivano SEMPRE il telefono e il computer di oggi (e il computer di ieri) */
  try{ const lv = cvLavoroVero(); if (lv) d.lavoroVero = lv; }catch(_){ }
  try{ const tl = await Promise.race([cvTelefonoOggi(), new Promise(function(ok){ setTimeout(function(){ ok(null); }, 4000); })]); if (tl) d.telefonoOggi = tl; }catch(_){ }
  /* 0.9.348: le decisioni, il primo parametro della revisione */
  try{ if (typeof cloDecDati === 'function') d.decisioni = cloDecDati(); }catch(_){ }
  if (CV.dom && CV.dom.risposta){
    d.consapevolezza = { domanda: String(CV.dom.testo).replace(/\*/g, ''), risposta: CV.dom.risposta.t, quelloCheDiconoIDati: cvTitoloRivela().replace(/\*/g, '') };
    if (CV.dom.cosa){ d.consapevolezza.provaCosaStavaFacendo = CV.dom.cosa.t; if (CV.dom.verdetto) d.consapevolezza.verdetto = String(CV.dom.verdetto.testo || '').replace(/\*/g, ''); }
  }
  try{ const prima = (typeof rnPerAgente === 'function') ? rnPerAgente() : ''; if (prima) d.precedenti = String(prima).slice(0, 1500); }catch(_){ }
  if (CV.modo === 'rv' || CV.modo === 'rvp'){
    try{ await Promise.race([cvBrief(d), new Promise(function(ok){ setTimeout(ok, 7000); })]); }catch(_){ }
  }
  CV.datiAg = d;
  return d;
}
/* ---------------------------------------------------------------------------------------
   L'ANALISI PRIMA DELLE DOMANDE (0.9.310). Andrea: "con Premium la revisione non deve chiedere cosa farai: e' l'agente
   personale che analizza e ricalcola". Per il periodo della revisione (oggi, la settimana, il mese) all'agente arrivano,
   riassunti e compatti, solo dati che esistono davvero sul telefono:
     - la partita vecchio te contro nuovo te (fl_match_hist, gli eventi scritti da mgLog: quando e perche' ha segnato il
       vecchio te, con l'app quando il punto viene da un'uscita di rotta);
     - il tempo sul telefono per ora del giorno (getScreenTimeRange a ore, al massimo 14 giorni) oltre al pannello;
     - la Timeline con la radiografia (tlRadiografia: la cronologia d'uso di Android incrociata con quello che il servizio
       di accessibilita' annota dentro le app: le ricerche su Google e Chrome, i titoli dei video di YouTube, i siti, le
       domande agli assistenti, reel e storie). Il telefono la tiene 14 giorni e solo con l'accessibilita' accesa: se non
       c'e', non si manda niente;
     - la roadmap di adesso (gli orizzonti) e la strada scelta (Pianifico io o Seguo il Genio).
   --------------------------------------------------------------------------------------- */
function cvFinestraRev(){
  try{ if (CV.modo === 'rvp' && typeof rvpDa === 'function') return { da: rvpDa(RVP.tipo), a: Math.min(Date.now(), rvpFino(RVP.tipo)) }; }catch(_){ }
  return { da: cvMezzanotte(0), a: Date.now() };
}
function cvNomePkg(p){ try{ return (typeof tlNomeApp === 'function') ? tlNomeApp(p) : p; }catch(_){ return p; } }
function cvFascia(h){ return String(h).padStart(2, '0') + '-' + String((h + 1) % 24).padStart(2, '0'); }
/** La partita del periodo: i punti, e quando e perche' ha segnato il vecchio te. */
function cvPartitaBrief(da, a){
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_match_hist') || '[]') || []; }catch(_){ }
  const ev = [];
  h.forEach(function(g){ (g && g.eventi || []).forEach(function(e){ if (e && +e.at >= da && +e.at < a) ev.push(e); }); });
  if (!ev.length) return null;
  let neo = 0, old = 0; const ore = {}, cause = {}, ultimi = [];
  ev.sort(function(x, y){ return x.at - y.at; }).forEach(function(e){
    const n = Math.max(1, +e.punti || 1);
    if (e.chi === 'neo') neo += n;
    else if (e.chi === 'old'){
      old += n;
      const d = new Date(+e.at), app = e.rotta ? cvNomePkg(e.rotta) : '';
      ore[d.getHours()] = (ore[d.getHours()] || 0) + n;
      const k = app ? 'su ' + app : String(e.motivo || '').replace(/\s*\(dal [^)]*\)\s*$/, '').slice(0, 60);
      cause[k] = (cause[k] || 0) + n;
      ultimi.push({ quando: CV_GIORNI[d.getDay()] + ' ' + d.getDate() + '/' + (d.getMonth() + 1) + ' alle ' + cvHM(+e.at), perche: String(e.motivo || '').slice(0, 110), app: app || undefined, punti: n });
    }
  });
  const top = function(o, f){ return Object.keys(o).map(function(k){ return { k: k, n: o[k] }; }).sort(function(x, y){ return y.n - x.n; }).slice(0, 5).map(f); };
  return { puntiNuovoTe: neo, puntiVecchioTe: old,
    vecchioTePerFascia: top(ore, function(x){ return { ore: cvFascia(+x.k), punti: x.n }; }),
    vecchioTePerCausa: top(cause, function(x){ return { causa: x.k, punti: x.n }; }),
    ultimiPuntiVecchioTe: ultimi.slice(-12) };
}
/** Il tempo sul telefono per ora del giorno, in media al giorno (al massimo gli ultimi 14 giorni del periodo). */
async function cvOreBrief(da, a){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return null;
  const da2 = Math.max(da, a - 14 * 86400000);
  const r = await NATIVE.getScreenTimeRange({ from: da2, to: a, bucket: 'hour' });
  const b = (r && r.buckets) || []; if (!b.length) return null;
  const giorni = Math.max(1, Math.round((a - da2) / 86400000));
  const ore = new Array(24).fill(0); b.forEach(function(x){ ore[new Date(x.start).getHours()] += x.ms || 0; });
  const fasce = ore.map(function(ms, h){ return { ore: cvFascia(h), minutiAlGiorno: Math.round(ms / 60000 / giorni) }; }).filter(function(x){ return x.minutiAlGiorno >= 5; })
    .sort(function(x, y){ return y.minutiAlGiorno - x.minutiAlGiorno; }).slice(0, 6);
  return { giorni: giorni, fascePiuPiene: fasce };
}
/** La Timeline: cosa faceva dentro le app (ricerche, video, siti, assistenti), con i minuti e le ore. Al massimo 7 giorni. */
async function cvTimelineBrief(da, a){
  if (typeof tlRadiografia !== 'function') return null;
  const giorni = [];
  for (let t = cvMezzanotte(0); t >= da && giorni.length < 7; t -= 86400000){ if (t < a) giorni.push(t); }
  if (!giorni.length) giorni.push(cvMezzanotte(0));
  const liste = await Promise.all(giorni.map(function(t){ return Promise.resolve(tlRadiografia(cvIso(t))).catch(function(){ return []; }); }));
  const cose = {}, ricerche = [];
  let n = 0;
  liste.forEach(function(l){ (l || []).forEach(function(e){
    if (!e || +e.t < da || +e.t >= a || !e.cosa || e.tipo === 'app' || cvSelf(e.pkg)) return;
    n++;
    const k = e.tipo + '|' + String(e.cosa).trim().toLowerCase().slice(0, 80);
    const x = cose[k] = cose[k] || { app: e.app || cvNomePkg(e.pkg), pkg: e.pkg, tipo: e.tipo, cosa: String(e.cosa).trim().slice(0, 120), ms: 0, volte: 0, ore: {} };
    x.ms += +e.durMs || 0; x.volte++; x.ore[new Date(+e.t).getHours()] = 1;
    if ((e.tipo === 'ricerca' || e.tipo === 'ai') && ricerche.indexOf(x.cosa) < 0) ricerche.push(x.cosa);
  }); });
  if (!n) return null;
  return { giorni: giorni.length,
    cose: Object.keys(cose).map(function(k){ return cose[k]; }).sort(function(x, y){ return (y.ms - x.ms) || (y.volte - x.volte); }).slice(0, 14)
      .map(function(x){ return { app: x.app, pkg: x.pkg, tipo: x.tipo, cosa: x.cosa, minuti: Math.round(x.ms / 60000), volte: x.volte, ore: Object.keys(x.ore).map(function(h){ return cvFascia(+h); }).slice(0, 4) }; }),
    ricerche: ricerche.slice(-15) };
}
/** La roadmap di adesso (gli orizzonti, con i passi ancora aperti) e la strada scelta. */
function cvRoadmapBrief(){
  const out = { strada: '' , orizzonti: [] };
  try{ const sc = (typeof mppSceltaFatta === 'function') ? mppSceltaFatta() : ''; out.strada = sc === 'mia' ? 'Pianifico io' : sc === 'rotta' ? 'Seguo il Genio' : ''; }catch(_){ }
  try{
    ['cinque', 'anno', 'mese', 'settimana', 'oggi'].forEach(function(k){
      const x = (typeof ozAnello === 'function') ? (ozAnello(k) || {}) : {};
      if (!x.testo) return;
      const passi = (x.passi || []);
      out.orizzonti.push({ k: k, testo: String(x.testo).slice(0, 140), aperti: passi.filter(function(p){ return !p.fatto; }).map(function(p){ return String(p.t).slice(0, 100); }).slice(0, 6), fatti: passi.filter(function(p){ return p.fatto; }).length });
    });
  }catch(_){ }
  return out;
}
async function cvBrief(d){
  const f = cvFinestraRev();
  try{ const p = cvPartitaBrief(f.da, f.a); if (p) d.partita = p; }catch(_){ }
  try{ const r = cvRoadmapBrief(); d.roadmap = r.orizzonti; if (r.strada) d.strada = r.strada; }catch(_){ }
  const res = await Promise.all([cvOreBrief(f.da, f.a).catch(function(){ return null; }), cvTimelineBrief(f.da, f.a).catch(function(){ return null; })]);
  if (res[0]) d.abitudini = res[0];
  if (res[1]) d.timeline = res[1];
  return d;
}
/* IL PERCORSO NUOVO, SOLO CON IL SI' (regola: mai ricalcolare senza consenso). Lo propone il tuo agente personale quando
   sei fuori rotta; si applica con lo stesso meccanismo della roadmap su misura della chat (agApplicaPiano in agente.js). */
const CV_ANELLI_NOMI = { cinque: 'Fra cinque anni', anno: 'Quest’anno', mese: 'Questo mese', settimana: 'Questa settimana', oggi: 'Oggi' };
function cvPercorsoHtml(x, i){
  const p = x.piano || {};
  const righe = ['oggi', 'settimana', 'mese', 'anno', 'cinque'].filter(function(k){ return p[k] && p[k].testo; }).slice(0, 4).map(function(k){
    const passi = Array.isArray(p[k].passi) ? p[k].passi : [];
    return '<div class="cv-perc-r"><small>' + cvEsc(CV_ANELLI_NOMI[k]) + '</small><b>' + cvEsc(p[k].testo) + '</b>'
      + (k === 'oggi' && passi.length ? '<ul>' + passi.slice(0, 3).map(function(t){ return '<li>' + cvEsc(t) + '</li>'; }).join('') + '</ul>' : '') + '</div>';
  }).join('');
  const stato = x.stato === 'si' ? '<div class="cv-piano-ok">Applicato</div>' : x.stato === 'no' ? '<div class="cv-piano-no">Hai tenuto il percorso di adesso</div>'
    : '<div class="cv-perc-b"><button type="button" class="or-a main" onclick="event.stopPropagation();cvPercorsoSi(' + i + ')">Applica il nuovo percorso</button><button type="button" class="gn-link" onclick="event.stopPropagation();cvPercorsoNo(' + i + ')">Tengo il percorso di adesso</button></div>';
  return '<div class="cv-piano cv-perc"><small>Il nuovo percorso</small>' + righe + stato + '</div>';
}
function cvPercorsoSi(i){
  const c = CV.chat, m = c && c.msgs[i], x = m && m.percorso; if (!x || x.stato) return;
  x.stato = 'si';
  c.riepilogo = Object.assign({}, c.riepilogo || {}, { ricalcolo: 'sì, nuovo percorso applicato' });
  c.percorsoApplicato = x.piano;
  try{ cvChatSalva(); }catch(_){ }
  try{ flVibra([20, 40, 30]); }catch(_){ }
  cvChiudi();
  setTimeout(function(){ try{ if (typeof agApplicaPiano === 'function') agApplicaPiano(x.piano); }catch(_){ } }, 350);
}
function cvPercorsoNo(i){
  const c = CV.chat, m = c && c.msgs[i], x = m && m.percorso; if (!x || x.stato) return;
  x.stato = 'no';
  cvChatChiedi('percorso_rifiutato');
}
async function cvChatChiedi(evento){
  const c = CV.chat; if (!c || c.attesa) return;
  c.attesa = true; c.errore = false; c.evento = evento || '';
  cvChatPaint();
  try{
    let r = null;
    /* il primo messaggio preparato mentre guardavi i dati (cvPrimoPrepara): se c'e', si usa quello */
    const pr = (CV.primo && !CV.primo.usato && (c.evento || '') === (CV.primo.ev || '') && !c.msgs.some(function(m){ return m.chi === 'io'; })) ? CV.primo : null;
    if (pr){ pr.usato = true; try{ r = await pr.p; }catch(_){ r = null; } }
    if (!r) r = await cvChiamaAgente(await cvCorpo(c, c.evento));
    if (CV.chat !== c) return;
    c.attesa = false; c.evento = ''; c.agente = true; c.autoRiprova = 0; clearTimeout(c.autoT);
    const piano = r.piano ? Object.assign({ stato: '' }, r.piano) : null;
    const percorso = r.percorso && typeof r.percorso === 'object' ? { piano: r.percorso, stato: '' } : null;
    c.msgs.push({ chi: 'genio', t: r.testo, piano: piano, percorso: percorso, at: Date.now() });
    if (r.verdetto) c.verdetto = r.verdetto;
    if (r.riepilogo && typeof r.riepilogo === 'object') c.riepilogo = Object.assign({}, c.riepilogo || {}, r.riepilogo);
    if (r.fase) c.fase = r.fase;
    if (r.trigger) c.trigger = r.trigger;
    c.pillole = Array.isArray(r.pillole) ? r.pillole : [];
    if (piano && piano.aiuto) c.aiuto = piano.aiuto;
    if (r.fine){ c.fine = true; c.riepilogo = Object.assign({}, c.riepilogo || {}, r.riepilogo || {}); cvChatSalva(); }
    try{ flVibra([12, 50, 12]); }catch(_){ }
    cvChatPaint(true);
  }catch(e){
    if (CV.chat !== c) return;
    c.attesa = false;
    /* 0.9.322, Andrea: "ha saltato la chat con il mio agente e sono finito alla domanda dopo". LA CAUSA: se il resoconto non
       arrivava in tempo (15 secondi, poco per un modello con tutti i dati della giornata) la chat si chiudeva da sola e
       partivano le domande a opzioni. Adesso si resta qui: chi scrive decide se riprovare o andare avanti. */
    if (!c.msgs.length){ try{ toast(cvNomeAgente() + ' non risponde: continuo con le domande'); }catch(_){ } cvChatAlbero(); return; }
    c.errore = true; cvChatPaint();
    /* riprova da solo, fino a tre volte, finche' la chat e' quella e l'errore e' ancora a schermo */
    c.autoRiprova = (c.autoRiprova || 0) + 1;
    if (c.autoRiprova <= 3){ const ev = c.evento || ''; clearTimeout(c.autoT); c.autoT = setTimeout(function(){ if (CV.chat === c && c.errore && !c.attesa && document.getElementById('cvPiede')) cvChatChiedi(ev); }, 20000); }
  }
}
/** Dalla chat alle domande del Genio a opzioni, senza perdere le risposte gia' date (revisioni di periodo). */
function cvChatAlbero(){
  const c = CV.chat;
  const risposte = c ? c.msgs.filter(function(m){ return m.chi === 'io'; }).map(function(m){ return m.t; }) : [];
  CV.chat = null;
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('cv-on');
  if (CV.modo === 'rvp' && typeof rvpDaChat === 'function'){ try{ cvSostituisci(rvpDaChat(risposte)); return; }catch(_){ } }
  cvSostituisci(cvDopoLibero());
}
/* IL PIANO SI APPLICA SOLO CON IL SI' (regola: mai ricalcolare o cambiare senza consenso) */
function cvPianoSi(i){
  const c = CV.chat, m = c && c.msgs[i], p = m && m.piano; if (!p || p.stato) return;
  try{
    if ((p.tipo === 'blocco' || p.tipo === 'limite') && typeof frProgrammaDaAgente === 'function'){
      frProgrammaDaAgente({ nome: p.nome, app: p.app, dalle: p.dalle, alle: p.alle, giorni: p.giorni, minutiGiorno: p.minutiGiorno, zitto: true }, false);
    } else if (p.azione === 'notifiche') c.dopo.push({ k: 'notifiche', app: (p.app || [])[0] || '' });
    else if (p.azione === 'focus') c.dopo.push({ k: 'focus' });
    else if (p.azione === 'caveau') c.dopo.push({ k: 'caveau' });
    else if (p.azione === 'respiro') c.dopo.push({ k: 'respiro' });
    const pp = JSON.parse(localStorage.getItem('fl_patti') || '[]') || [];
    pp.push({ at: Date.now(), se: 'la causa che ho detto all’agente torna (' + (c.trigger || 'uscita di rotta') + ')', allora: cvPianoDesc(p), contromisura: p.nome, app: cvAppNomi(p.app) });
    localStorage.setItem('fl_patti', JSON.stringify(pp.slice(-30)));
  }catch(_){ }
  p.stato = 'si'; c.aiuto = p.aiuto || c.aiuto;
  (c.pianiSi = c.pianiSi || []).push(p);
  c.applicati.push(p.nome + ': ' + cvPianoDesc(p));
  c.msgs.push({ chi: 'nota', t: 'Piano applicato: ' + p.nome });
  try{ flVibra([20, 40, 30]); }catch(_){ }
  cvChatChiedi('piano_applicato');
}
function cvPianoNo(i){
  const c = CV.chat, m = c && c.msgs[i], p = m && m.piano; if (!p || p.stato) return;
  p.stato = 'no';
  cvChatChiedi('piano_rifiutato');
}
function cvTrascrizione(){ return (CV.chat.msgs || []).filter(function(m){ return m.chi !== 'nota'; }).map(function(m){ return (m.chi === 'io' ? 'Io: ' : 'Agente: ') + m.t; }).join('\n').slice(0, 4000); }
function cvChatSalva(){
  const c = CV.chat, rp = c.riepilogo || {};
  const applicato = c.applicati.join('; ');
  try{
    if (CV.modo === 'rv'){
      const g = rvOggi();
      const l = rvLista().filter(function(x){ return x.giorno !== g; });
      l.push({ giorno: g, at: Date.now(), focus: rp.focus || '', leva: rp.leva || rp.funzionato || '', interruzione: rp.interruzione || rp.allontanato || '', contromisura: rp.contromisura || rp.cambio || applicato, imprevisto: rp.imprevisto || '', chat: true, trigger: c.trigger, testo: cvTrascrizione(), dati: RV.dati,
        riepilogo: (rp.funzionato || rp.allontanato || rp.mossa) ? { rotta: rp.rotta || '', funzionato: rp.funzionato || '', allontanato: rp.allontanato || '', mossa: rp.mossa || '', ricalcolo: rp.ricalcolo || '' } : undefined, percorso: c.percorsoApplicato ? true : undefined });
      localStorage.setItem(RV_KEY, JSON.stringify(l.slice(-120)));
      RV.r.imprevisto = rp.imprevisto || '';
    } else if (CV.modo === 'rvp'){
      c.riepilogo = rvpSalvaDaChat(rp, cvTrascrizione(), c.percorsoApplicato ? { nuovoPercorso: c.percorsoApplicato } : null);
    } else {
      const l = rnLista();
      l.push({ at: Date.now(), causa: c.trigger || 'conversazione', strada: 'conversazione', app: '', appNome: '', testo: cvTrascrizione(), contromisura: applicato || rp.contromisura || '', patto: rp.patto || '', rimedio: applicato ? 'programma' : 'nessuno', task: (typeof rnTask === 'function' ? rnTask() : ''), delta: (RNG.visto && RNG.visto.delta) || (RN.v && RN.v.delta) || 0 });
      localStorage.setItem(RN_KEY, JSON.stringify(l.slice(-60)));
      /* il patto "se..., allora..." va sulla schermata di blocco delle app appena bloccate, come nel rientro a opzioni */
      const allora = String(rp.patto || '').split(/,?\s*allora\s*,?\s*/i)[1];
      const app = [].concat.apply([], (c.pianiSi || []).map(function(x){ return x.app || []; }));
      if (allora && app.length){
        const m = JSON.parse(localStorage.getItem(RNG_SOST_KEY) || '{}') || {};
        app.forEach(function(pkg){ m[pkg] = allora.charAt(0).toUpperCase() + allora.slice(1).replace(/[.\s]+$/, '') + '.'; });
        localStorage.setItem(RNG_SOST_KEY, JSON.stringify(m));
        try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ sostituzioni: JSON.stringify(m) }).catch(function(){ }); }catch(_){ }
      }
      if (rp.patto){ const pp = JSON.parse(localStorage.getItem(RNG_PATTI_KEY) || '[]') || []; pp.push({ at: Date.now(), se: rp.patto, allora: '', contromisura: applicato, app: '' }); localStorage.setItem(RNG_PATTI_KEY, JSON.stringify(pp.slice(-30))); }
    }
  }catch(_){ }
  cvImparaRegistra(c.tipo, c.trigger, c.aiuto);
}
function cvFineHtml(){
  const c = CV.chat, rp = c.riepilogo || {};
  const voci = (c.tipo === 'sera' || c.tipo === 'rientro')
    ? [['focus', 'Concentrazione'], ['leva', 'Su cosa hai lavorato'], ['interruzione', 'Cosa ti ha interrotto'], ['contromisura', 'Da domani'], ['imprevisto', 'Imprevisto'], ['patto', 'Il tuo patto']]
    : [['rotta', 'Quanto ti sei avvicinato al sogno'], ['funzionato', 'Cosa ha funzionato'], ['allontanato', 'Cosa ti ha fatto perdere tempo'], ['mossa', 'La prossima mossa']];
  const righe = voci.filter(function(v){ return rp[v[0]]; }).map(function(v){ return '<p><span>' + v[1] + '</span>' + cvEsc(rp[v[0]]) + '</p>'; }).join('')
    + c.applicati.map(function(a){ return '<p><span>Piano applicato</span>' + cvEsc(a) + '</p>'; }).join('');
  let serie = 0; try{ if (c.tipo === 'sera') serie = rvSerie(); }catch(_){ }
  let b = '';
  c.dopo.forEach(function(x){
    if (x.k === 'notifiche') b += '<button type="button" class="or-a" onclick="event.stopPropagation();cvFaNotifiche(\'' + cvEsc(x.app) + '\')">Spegni le notifiche di ' + cvEsc(cvAppNomi([x.app]) || 'quell’app') + '</button>';
    if (x.k === 'focus') b += '<button type="button" class="or-a" onclick="event.stopPropagation();cvChiudi();setTimeout(function(){try{if(typeof stGoFocus===\'function\')stGoFocus();}catch(_){}},300)">Parti con una sessione di Full Focus</button>';
    if (x.k === 'caveau') b += '<button type="button" class="or-a" onclick="event.stopPropagation();cvChiudi();setTimeout(function(){try{cvPaginaApri();}catch(_){}},300)">Apri il caveau delle idee</button>';
  });
  if (c.tipo === 'sera'){
    if (rp.imprevisto && typeof rvImprevistoAlGenio === 'function') b = '<button type="button" class="or-a main" onclick="event.stopPropagation();cvChiudiSoft();rvImprevistoAlGenio()">Fai ricalcolare la rotta al Genio</button>' + b;
    if (typeof pkPuntoApri === 'function') b += '<button type="button" class="or-a" onclick="event.stopPropagation();pkPuntoApri()">Prenota il punto di domani</button>';
    b += '<button type="button" class="or-a' + (rp.imprevisto ? '' : ' main') + '" onclick="event.stopPropagation();cvChiudi()">Chiudi la giornata</button>';
  } else if (c.tipo === 'rientro'){
    b += '<button type="button" class="or-a" onclick="event.stopPropagation();cvRicalcolaBozza()">Fai ricalcolare la roadmap al tuo agente personale</button>'
      + '<button type="button" class="or-a main" onclick="event.stopPropagation();cvChiudi()">Torno al sogno</button>';
  } else {
    if (/^s[iì]/i.test(String(rp.ricalcolo || '')) && typeof rvpRicalcolaBozza === 'function') b += '<button type="button" class="or-a rvp-ricalcola" onclick="event.stopPropagation();rvpRicalcolaBozza(CV.chat&&CV.chat.riepilogo)">Chiedi ' + cvEsc(cvNomeA()) + ' di ricalcolare il percorso</button>';
    b += '<button type="button" class="or-a main" onclick="event.stopPropagation();cvChiudi()">Chiudi</button>';
  }
  /* 0.9.310: le revisioni finiscono su una pagina del diario di viaggio (revisioni-periodo.js); il Rientra in rotta resta com'e' */
  let pagina = '';
  try{
    if (typeof rvdPaginaHtml === 'function' && c.tipo === 'sera') pagina = (rp.funzionato || rp.allontanato || rp.mossa)
      ? rvdPaginaHtml({ tipo: 'sera', at: Date.now(), riepilogo: rp }, serie > 1 ? serie + ' sere di fila con la revisione' : '')
      : rvdPaginaHtml({ tipo: 'sera', at: Date.now(), focus: rp.focus || '', leva: rp.leva || '', interruzione: rp.interruzione || '', contromisura: rp.contromisura || (c.applicati[0] || '') }, serie > 1 ? serie + ' sere di fila con la revisione' : '');
    else if (typeof rvdPaginaHtml === 'function' && c.tipo === 'rientro') pagina = rvdPaginaHtml({ tipo: 'rientro', at: Date.now(), trigger: c.trigger || '', riepilogo: rp, applicati: c.applicati || [] }, '');
    else if (typeof rvdPaginaHtml === 'function' && c.tipo !== 'rientro') pagina = rvdPaginaHtml({ tipo: c.tipo, periodo: RVP.periodo, at: Date.now(), r: {}, riepilogo: rp }, '');
  }catch(_){ pagina = ''; }
  if (!pagina) pagina = '<div class="rng-patto"><small>' + cvEsc(CV_NOMI[c.tipo] || '') + '</small>' + righe + (serie > 1 ? '<p class="rng-patto-f">' + serie + ' sere di fila con la revisione.</p>' : '') + '</div>';
  return '<div class="cv-fine">' + pagina
    + cvConsensoHtml() + '<div class="or-grid one cv-fine-b">' + b + '</div></div>';
}
function cvFaNotifiche(pkg){
  try{ if (NATIVE && NATIVE.openAppNotificationSettings){ NATIVE.openAppNotificationSettings({ pkg: pkg, packageName: pkg }); return; } }catch(_){ }
  toast('Apri Impostazioni, poi App, e spegni le notifiche');
}
/* la roadmap la ricalcola l'agente SOLO se lo chiedi tu: la richiesta si scrive nel campo, la mandi tu */
function cvRicalcolaBozza(){
  const c = CV.chat, rp = (c && c.riepilogo) || {};
  const testo = 'Sono appena uscito di rotta e ne ho parlato con te. ' + (rp.interruzione ? 'Cosa mi ha portato fuori strada: ' + rp.interruzione + '. ' : '') + (c.applicati.length ? 'Ho applicato: ' + c.applicati.join('; ') + '. ' : '') + (rp.patto ? 'Il mio patto: ' + rp.patto + '. ' : '') + 'Ricalcola la mia roadmap partendo da questo.';
  cvChiudiSoft();
  try{ if (typeof nvRientroSegna === 'function') nvRientroSegna(); }catch(_){ }
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
  setTimeout(function(){ if (typeof agPopover === 'function') agPopover(testo, { titolo: 'Rientra in rotta' }); else if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo); }, 250);
}
function cvChiudiSoft(){ const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('cv-on'); }
function cvChiudi(){
  cvChiudiSoft();
  if (CV.modo === 'rv'){ try{ rvChiudi(); }catch(_){ } }
  else if (CV.modo === 'rvp'){ try{ rvpChiudi(); }catch(_){ } }
  else { try{ rnScelto(); }catch(_){ } try{ rngChiudi(); }catch(_){ } }
}

/* ---------------------------------------------------------------------------------------
   I DATI CHE INSEGNANO AL GENIO
   --------------------------------------------------------------------------------------- */
function cvConsenso(){ try{ return localStorage.getItem(CV_CONSENSO_KEY) === '1'; }catch(_){ return false; } }
function cvConsensoSet(on){
  try{ localStorage.setItem(CV_CONSENSO_KEY, on ? '1' : '0'); }catch(_){ }
  if (on && CV.daMandare){ const x = CV.daMandare; CV.daMandare = null; cvImparaMandaTutto(x); }
}
function cvConsensoHtml(){
  return '<div class="cv-cons"><div><b>Aiuta il Genio a imparare</b><small>Manda in forma anonima il tipo di sogno, cosa ti ha portato fuori strada e cosa ha aiutato. Niente nomi e niente testi.</small></div>'
    + '<button type="button" class="switch' + (cvConsenso() ? ' on' : '') + '" aria-label="Aiuta il Genio a imparare" onclick="event.stopPropagation();cvConsensoSet(!cvConsenso());this.classList.toggle(\'on\')"></button></div>';
}
function cvPubblica(method, path, body){
  if (typeof agPubblica === 'function') return agPubblica(method, path, body);
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi) return NATIVE.publicApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
  return Promise.reject(new Error('niente rete'));
}
/** A revisione o rientro finiti: la causa e la contromisura di oggi, e se quella di ieri ha aiutato. */
function cvImparaRegistra(tipo, causa, aiuto){
  const contesto = tipo === 'rientro' ? 'rientro' : tipo;
  if (!causa || causa === 'scritto') return;
  const sogno = cvSogno();
  const att = cvLeggi(CV_ATTESA_KEY, {});
  const prima = att[contesto];
  const x = { sogno: sogno, contesto: contesto, causa: causa, aiuto: aiuto || '' };
  /* la contromisura dell'ultima volta ha aiutato se la stessa causa non e' tornata (entro una settimana) */
  if (prima && prima.aiuto && Date.now() - prima.at < 7 * 86400000 && prima.causa !== causa && rvOggiSafe() !== prima.giorno) x.aiutato = { aiuto: prima.aiuto, causa: prima.causa };
  att[contesto] = { at: Date.now(), giorno: rvOggiSafe(), causa: causa, aiuto: aiuto || '' };
  cvScrivi(CV_ATTESA_KEY, att);
  const manda = { sogno: sogno, contesto: contesto, causa: causa, aiuto: aiuto || '', aiutato: x.aiutato ? { aiuto: x.aiutato.aiuto } : null };
  if (x.aiutato) manda.aiutatoDa = x.aiutato.causa;
  if (cvConsenso()) cvImparaMandaTutto(manda); else CV.daMandare = manda;
}
function cvImparaMandaTutto(m){
  /* "ha aiutato" vale per la causa di allora, non per quella di oggi */
  if (m.aiutato) cvPubblica('POST', '/api/focuslock/genio/impara', { sogno: m.sogno, contesto: m.contesto, causa: m.aiutatoDa, aiuto: m.aiutato.aiuto, esito: 'aiutato' }).catch(function(){ });
  cvPubblica('POST', '/api/focuslock/genio/impara', { sogno: m.sogno, contesto: m.contesto, causa: m.causa, aiuto: m.aiuto, esito: 'scelto' }).catch(function(){ });
}
function rvOggiSafe(){ try{ return rvOggi(); }catch(_){ return new Date().toISOString().slice(0, 10); } }
/** Le statistiche anonime per il tuo tipo di sogno: tenute un giorno. */
function cvImparaCarica(contesto){
  const sogno = cvSogno(), k = sogno + ':' + contesto;
  const c = cvLeggi(CV_STAT_KEY, {});
  if (c[k] && Date.now() - c[k].at < 86400000){ CV.stat = c[k].v || {}; cvOrdinaRientro(); return; }
  cvPubblica('GET', '/api/focuslock/genio/impara?sogno=' + encodeURIComponent(sogno) + '&contesto=' + encodeURIComponent(contesto)).then(function(v){
    if (!v || !Array.isArray(v.cause)) return;
    CV.stat = v; c[k] = { at: Date.now(), v: v }; cvScrivi(CV_STAT_KEY, c); cvOrdinaRientro();
  }).catch(function(){ });
}
function cvPunteggi(fase){
  const s = CV.stat || {}, out = {};
  if (fase === 'inter' || fase === 'grilletto' || fase === 'causa') (s.cause || []).forEach(function(x){ out[x.k] = x.n; });
  else if (fase === 'sistema' || fase === 'contromisura'){
    let tr = ''; try{ tr = fase === 'sistema' ? (RV.r.inter || '') : (RN.r.grilletto || RN.r.causa || ''); }catch(_){ }
    ((s.aiuti || {})[tr] || []).forEach(function(x){ out[x.k] = x.aiutato * 3 + x.scelte; });
  }
  return out;
}
/** Le risposte piu' probabili per il tuo tipo di sogno vanno in cima. "Niente" e "non cambio niente" restano in fondo. */
function cvOrdina(voci, fase){
  const pt = cvPunteggi(fase);
  if (!Object.keys(pt).length) return voci;
  const fissi = ['niente', 'uguale', 'alza'];
  return voci.map(function(v, i){ return { v: v, i: i }; }).sort(function(a, b){
    const fa = fissi.indexOf(a.v[0]) >= 0, fb = fissi.indexOf(b.v[0]) >= 0;
    if (fa !== fb) return fa ? 1 : -1;
    return ((pt[b.v[0]] || 0) - (pt[a.v[0]] || 0)) || (a.i - b.i);
  }).map(function(x){ return x.v; });
}
function cvOrdinaTesti(fase, coppie){ return cvOrdina(coppie.map(function(c){ return [c[0], '', c[1]]; }), fase).map(function(v){ return v[2]; }); }
/* nel Rientra in rotta le carte si leggono per posizione: si riordinano gli elenchi stessi, prima di disegnarli */
function cvOrdinaRientro(){
  try{
    if (typeof RNG_CAUSE !== 'undefined'){ const pt = cvPunteggi('causa'); if (Object.keys(pt).length) RNG_CAUSE.sort(function(a, b){ return (pt[b.k] || 0) - (pt[a.k] || 0); }); }
    if (typeof RNG_GRILLETTI !== 'undefined') Object.keys(RNG_GRILLETTI).forEach(function(k){ const o = cvOrdina(RNG_GRILLETTI[k], 'grilletto'); RNG_GRILLETTI[k].splice.apply(RNG_GRILLETTI[k], [0, o.length].concat(o)); });
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   I PASSI "cv", dentro le tre scene
   --------------------------------------------------------------------------------------- */
function cvEntra(modo){
  const passo = cvPasso(modo);
  const sc = document.getElementById('gnScena');
  if (passo !== 'cvChat' && sc) sc.classList.remove('cv-on');
  if (String(passo || '').indexOf('cv') !== 0) return false;
  CV.modo = modo;
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo', 'rng-isola'); }
  /* tornando indietro a una domanda gia' fatta, il primo messaggio preparato e i dati per l'agente non valgono piu' */
  if (passo === 'cvDomanda' || passo === 'cvCosa'){ CV.primo = null; CV.datiAg = null; }
  if (passo === 'cvDomanda'){
    if (CV.dom) CV.dom.cosaChiesta = false;
    if (CV.dom && CV.dom.q){ gnDomanda('pensa', CV.dom.testo, cvCarte(CV.dom.opzioni, 'cvDomandaRisposta', true)); return true; }
    try{ gnPosa('pensa'); const el = document.getElementById('gnTesto'); if (el) el.innerHTML = '<span class="rng-ai-pensa"><i></i><i></i><i></i></span>'; }catch(_){ }
    cvDomandaScegli().then(function(d){
      if (cvPasso(modo) !== 'cvDomanda' || !GN.on) return;
      if (!d){ cvSostituisci('cvRivela'); return; }
      CV.dom = d;
      gnDomanda('pensa', d.testo, cvCarte(d.opzioni, 'cvDomandaRisposta', true));
    }).catch(function(){ cvSostituisci('cvRivela'); });
    return true;
  }
  if (passo === 'cvCosa'){
    const d = CV.dom; if (!d || !d.q){ cvSostituisci('cvRivela'); return true; }
    d.cosaChiesta = true;
    const k = d.risposta && d.risposta.k;
    const apre = k === 'vago' ? 'Proviamo lo stesso' : k === 'presente' ? 'Allora raccontamelo' : 'Bene, ti metto alla prova';
    const titolo = apre + ': *cosa stavi facendo ' + cvMomento(d) + '*?';
    if (cvPremium()){
      gnDomanda('pensa', titolo, (typeof micArea === 'function' ? micArea('cvCosaTesto', 3, 'Scrivi qui o tocca il microfono…') : '<textarea class="gn-area" id="cvCosaTesto" rows="3" placeholder="Scrivi qui…" onclick="event.stopPropagation()"></textarea>')
        + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();cvCosaOk()">Confermo</button></div>', function(){ const a = document.getElementById('cvCosaTesto'); if (a){ if (d.cosa && d.cosa.k === 'scritto') a.value = d.cosa.t; a.focus(); } });
      return true;
    }
    try{ gnPosa('pensa'); const el = document.getElementById('gnTesto'); if (el) el.innerHTML = '<span class="rng-ai-pensa"><i></i><i></i><i></i></span>'; }catch(_){ }
    cvCosaOpzioni(d).then(function(op){
      if (cvPasso(modo) !== 'cvCosa' || !GN.on) return;
      /* senza abbastanza attivita' vere da mettere accanto si scrive: un'opzione sola darebbe la risposta */
      if (!op){ cvSostituisci('cvScrivo'); return; }
      gnDomanda('pensa', titolo, cvCarte(op.map(function(o){ return [o.pkg, cvIcoApp(o), 'Ero su ' + o.label]; }), 'cvCosaScelta', true));
    }).catch(function(){ cvSostituisci('cvScrivo'); });
    return true;
  }
  if (passo === 'cvScrivo'){
    const d = CV.dom;
    const titolo = d && d.cosaChiesta ? 'Scrivi *cosa stavi facendo ' + cvMomento(d) + '*, con parole tue.' : 'Scrivilo *con parole tue*.';
    gnDomanda('pensa', titolo, (typeof micArea === 'function' ? micArea('cvDomTesto', 3, 'Scrivi qui o tocca il microfono…') : '<textarea class="gn-area" id="cvDomTesto" rows="3" placeholder="Scrivi qui…" onclick="event.stopPropagation()"></textarea>')
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();cvScrivoOk()">Confermo</button></div>', function(){ const a = document.getElementById('cvDomTesto'); if (a) a.focus(); });
    return true;
  }
  if (passo === 'cvScopri'){
    const d = CV.dom || {};
    /* 0.9.303: niente "Hai risposto: ..." (la risposta la rimette accanto ai dati la rivelazione). Quando la risposta
       era un'affermazione da controllare, si dice cosi'. */
    const prova = d.cosa || (d.q && ['stima', 'app', 'fascia', 'sblocchi', 'giornoMax'].indexOf(d.q.tipo) >= 0);
    const r = prova ? '*Vediamo se avevi ragione.*' : '*Vediamo cosa dice la tua giornata.*';
    gnDomanda('pensa', r, '<div class="or-grid one"><button type="button" class="or-a main cv-scopri" onclick="event.stopPropagation();cvVai(\'cvRivela\')">' + cvEsc((d.q && d.q.bottone) || 'Scoprilo') + '</button></div>');
    return true;
  }
  if (passo === 'cvRivela'){ cvRivelaEntra(); return true; }
  if (passo === 'cvFuturo'){ cvFuturoEntra(); return true; }
  if (passo === 'cvChat'){ cvChatEntra(); return true; }
  return false;
}

/* ---------------------------------------------------------------------------------------
   L'AGGANCIO
   --------------------------------------------------------------------------------------- */
(function(){
  /* chiudere la scena toglie sempre la chat */
  ['rvChiudi', 'rvpChiudi', 'rngChiudi', 'rngChiudiSoft'].forEach(function(n){
    const v = window[n]; if (typeof v !== 'function') return;
    window[n] = function(){ cvChiudiSoft(); return v.apply(this, arguments); };
  });
  /* il Genio a opzioni (gratis): nella revisione della sera le cause e i rimedi piu' probabili per il tuo tipo di sogno in cima */
  if (typeof rvCarte === 'function'){
    const v = rvCarte;
    window.rvCarte = rvCarte = function(voci, scrivo){ try{ if (RV.passo === 'inter' || RV.passo === 'sistema') voci = cvOrdina(voci, RV.passo); }catch(_){ } return v.call(this, voci, scrivo); };
  }
  if (typeof rngContromisure === 'function'){
    const v2 = rngContromisure;
    window.rngContromisure = rngContromisure = function(){ return cvOrdina(v2.apply(this, arguments), 'contromisura'); };
  }
  /* il Rientra in rotta senza chat manda anche lui la causa e il rimedio, se c'e' il consenso */
  if (typeof rngSalva === 'function'){
    const v3 = rngSalva;
    window.rngSalva = rngSalva = function(){
      const r = v3.apply(this, arguments);
      try{ const x = RN.r || {}; const causa = x.grilletto && x.grilletto !== 'scritto' ? x.grilletto : (x.causa && x.causa.indexOf('chiamata') < 0 ? x.causa : ''); cvImparaRegistra('rientro', causa, x.contromisura && x.contromisura !== 'scritta' ? x.contromisura : ''); }catch(_){ }
      return r;
    };
  }
  /* e la revisione della sera senza chat */
  if (typeof rvFine === 'function'){
    const v4 = rvFine;
    window.rvFine = rvFine = function(){
      try{ const x = RV.r || {}; if (!RV.cvRegistrata){ RV.cvRegistrata = true; cvImparaRegistra('sera', x.inter && x.inter !== 'scritto' ? x.inter : '', x.sistema && x.sistema !== 'scritto' ? x.sistema : ''); } }catch(_){ }
      return v4.apply(this, arguments);
    };
  }
  const st = document.createElement('style');
  st.textContent = [
    /* la rivelazione */
    '#gnRisp .cv-pan{margin:6px 0 14px;text-align:left}',
    '#gnRisp .cv-pan > .rep-panel{margin:0}.cv-pan .rep-panel .rep-solo-prot{display:block}.cv-pan .rep-panel .rep-solo-dream{display:none}.cv-pan .rep-top{cursor:default}.cv-pan .rep-row{cursor:default}',
    '.cv-pan-top{text-align:center}.cv-pan-top small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}.cv-pan-top .rep-big{margin:6px 0 0;color:var(--navy,#14234A)}',
    '.cv-pan .rp-bars.cv-cresce > b{transform-origin:bottom;animation:cvSale .6s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i,0) * 25ms)}@keyframes cvSale{from{transform:scaleY(0)}to{transform:scaleY(1)}}',
    '.cv-pan .rp-bars.con-sel > b{opacity:.3}.cv-pan .rp-bars.con-sel > b.sel{opacity:1;background:var(--blue,#0075E3)}',
    '.cv-pan-ora{display:flex;flex-direction:column;align-items:center;gap:4px;margin:14px 0 0;padding:12px 14px;border-radius:16px;background:#FDECEE;text-align:center}.cv-pan-ora b{font:800 14px var(--font-body);color:#C62835}.cv-pan-ora span{font:600 13.5px/1.45 var(--font-body);color:#14234A}',
    'body.dark .cv-pan-ora{background:#3A1520}body.dark .cv-pan-ora b{color:#FFB3BB}body.dark .cv-pan-ora span{color:#fff}body.dark .cv-pan-top .rep-big{color:#fff}body.dark .cv-pan-top small{color:#8CC6FF}',
    '.cv-pan-vuoto{text-align:center}.cv-pan-vuoto b{display:block;font:800 16px var(--font-body);color:var(--navy,#14234A)}.cv-pan-vuoto p{margin:8px 0 14px;font:500 14px/1.45 var(--font-body);color:var(--muted,#5B6B86)}body.dark .cv-pan-vuoto b{color:#fff}',
    '.cv-pan-perm{border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 14px var(--font-body);padding:11px 20px;cursor:pointer}',
    '.cv-esito{margin:0 4px 10px;text-align:center;font:600 13.5px/1.5 var(--font-body);color:#DCEBFF}',
    '.cv-riv-b .or-a + .or-a{margin-top:10px}',
    '.cv-meta{margin:2px 6px 14px;text-align:center;font:600 13.5px/1.5 var(--font-body);color:#DCEBFF}.cv-meta b{color:#fff}',
    /* la chat: la scena del Genio lascia il posto alla conversazione */
    '.gn.cv-on{overflow:hidden}.gn.cv-on .gn-sopra,.gn.cv-on .gn-box,.gn.cv-on .gn-tap{display:none!important}',
    '.gn.cv-on .gn-risp{min-height:0;justify-content:stretch;padding-top:calc(52px + env(safe-area-inset-top,0px))}',
    '.cv-chat{flex:1;min-height:0;display:flex;flex-direction:column}',
    '.cv-testa{display:flex;align-items:center;justify-content:center;gap:10px;padding:4px 0 12px;border-bottom:1px solid rgba(255,255,255,.12)}.cv-testa b{display:block;font:800 16px var(--font-body);color:#fff}.cv-testa small{display:block;font:600 12px var(--font-body);color:#8CC6FF}',
    '.cv-testa .ag-av{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;font-size:22px;background:#fff;overflow:hidden;flex:none}.cv-testa .ag-av img{width:100%;height:100%;object-fit:cover}',
    '.cv-lista::-webkit-scrollbar{display:none}.cv-lista{scrollbar-width:none;flex:1;min-height:0;overflow-y:auto;padding:16px 2px 12px;display:flex;flex-direction:column;gap:12px}',
    '.cv-m{display:flex}.cv-m.io{justify-content:flex-end}.cv-b{max-width:84%;padding:12px 15px;border-radius:20px;font:500 15px/1.5 var(--font-body)}.cv-b p{margin:0}.cv-b p + p{margin-top:8px}',
    '.cv-m.lui .cv-b{background:#fff;color:#14234A;border-bottom-left-radius:6px}.cv-m.io .cv-b{background:#0075E3;color:#fff;border-bottom-right-radius:6px}',
    'body.dark .cv-m.lui .cv-b{background:#1B2C4F;color:#EEF4FF}',
    '.cv-m.cv-nuovo{animation:gnIn .4s ease-out both}',
    '.cv-pensa{display:inline-flex;gap:6px;padding:16px 18px}.cv-pensa i{width:8px;height:8px;border-radius:99px;background:#5B6B86;opacity:.4;animation:rngPensa 1s infinite}.cv-pensa i:nth-child(2){animation-delay:.15s}.cv-pensa i:nth-child(3){animation-delay:.3s}',
    '.cv-nota{align-self:center;padding:6px 12px;border-radius:99px;background:rgba(27,158,106,.2);color:#9BE8C3;font:700 12.5px var(--font-body)}',
    '.cv-err{align-self:center;text-align:center}.cv-err p{margin:0 0 8px;font:600 13.5px var(--font-body);color:#FFB3BB}',
    '.cv-piano{align-self:stretch;margin:0 0 0 4px;padding:16px;border-radius:20px;background:#fff;color:#14234A;text-align:center;box-shadow:0 0 0 2px #0075E3 inset}',
    '.cv-piano small{display:block;font:800 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}.cv-piano b{display:block;margin-top:6px;font:800 17px var(--font-body)}.cv-piano p{margin:8px 0 0;font:600 14px/1.45 var(--font-body);color:#33476B}.cv-piano .cv-perche{font-weight:500;color:#5B6B86}',
    '.cv-piano-b{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}.cv-piano-b .or-a{margin:0;padding:12px 6px;font-size:14px}',
    '.cv-perc{text-align:left}.cv-perc > small{text-align:center}.cv-perc-r{margin-top:12px;padding-top:10px;border-top:1px solid #E3EAF4}.cv-perc-r small{display:block;font:800 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#5B6B86}.cv-perc-r b{display:block;margin-top:3px;font:700 15px/1.4 var(--font-body)}.cv-perc-r ul{margin:6px 0 0;padding-left:18px;font:500 14px/1.45 var(--font-body);color:#33476B}',
    '.cv-perc-b{display:flex;flex-direction:column;align-items:center;gap:6px;margin-top:16px}.cv-perc-b .or-a{margin:0;width:100%}',
    'body.dark .cv-perc-r{border-top-color:rgba(255,255,255,.14)}body.dark .cv-perc-r small{color:#B9C7DD}body.dark .cv-perc-r ul{color:#C9D6EA}',
    '.cv-piano-ok,.cv-piano-no{margin-top:12px;font:800 13px var(--font-body);color:#1B9E6A}.cv-piano-no{color:#5B6B86}',
    'body.dark .cv-piano{background:#12203A;color:#fff}body.dark .cv-piano p{color:#C9D6EA}',
    '.cv-piede{flex:none;padding-top:10px}.cv-piede[hidden]{display:none}',
    /* le pillole: una riga sola che scorre di lato, solo a campo vuoto */
    '.cv-pill{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:2px 2px 10px;margin:0 -2px}.cv-pill::-webkit-scrollbar{display:none}.cv-pill.via,.cv-pill.vuota{display:none}',
    '.cv-pill button{flex:none;max-width:78%;display:inline-flex;align-items:center;gap:7px;white-space:nowrap;overflow:hidden;border:1.5px solid rgba(140,198,255,.55);border-radius:99px;background:rgba(255,255,255,.1);color:#fff;font:700 13.5px var(--font-body);padding:10px 15px;cursor:pointer}',
    '.cv-pill button span{overflow:hidden;text-overflow:ellipsis}.cv-pill button .ag-ic{flex:none;color:#8CC6FF;stroke-width:2.2}',
    /* la prova: cosa hai fatto in quell'ora, riga per riga */
    '.cv-fila{margin:0 0 12px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.1);text-align:center}.cv-fila small{display:block;margin-bottom:6px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}',
    '.gn-card .cv-ico-app{display:inline-grid;place-items:center;width:34px;height:34px;border-radius:9px;object-fit:cover;vertical-align:middle}.cv-ico-let{background:#0075E3;color:#fff;font:800 17px/1 var(--font-body);font-style:normal}',
    '.cv-fila p{margin:6px 0 0;font:600 13.5px/1.45 var(--font-body);color:#fff}.cv-fila p b{margin-right:6px;color:#BCE0FF}',
    '.cv-pill button:active{transform:scale(.96)}',
    '.cv-comp{display:flex;align-items:flex-end;gap:8px;padding:6px 6px 6px 14px;border-radius:26px;background:#fff}',
    /* 0.9.335: come la chat dell'agente: il testo sopra, sotto il piu', il modello, il microfono e l'invio */
    '.cv-comp{flex-wrap:wrap;align-items:center;padding:10px 8px 8px 14px;border-radius:24px}#cvPiede .cv-comp textarea{order:-1;flex:1 1 100%!important;width:100%!important;min-width:100%;margin-bottom:6px}.cv-mod{position:relative;display:flex;align-items:center;margin-right:auto;color:var(--navy,#001E44)}.cv-mod select{-webkit-appearance:none;appearance:none;border:0;background:none;padding:6px 18px 6px 6px;font:800 13.5px var(--font-body);color:inherit;cursor:pointer}.cv-mod svg{position:absolute;right:4px;pointer-events:none}body.dark .cv-mod{color:#fff}body.dark .cv-mod select option{color:#001E44}',
    '.cv-pensa span{align-self:center;margin-left:6px;font:600 13px var(--font-body);color:#5B6B86}.cv-pensa span:empty{display:none}.cv-m.cv-mod-on .cv-b{outline:2px dashed #0075E3;outline-offset:3px;opacity:.7}',
    '.cv-comp textarea{flex:1;min-width:0;border:0;outline:0;resize:none;background:transparent;color:#14234A;font:500 15.5px/1.45 var(--font-body);padding:9px 0;max-height:160px}',
    '.cv-mic,.cv-invia{flex:none;width:40px;height:40px;border:0;border-radius:50%;display:grid;place-items:center;cursor:pointer;background:#EEF4FF;color:#0075E3}',
    '.cv-invia{background:#C9D6EA;color:#fff}.cv-invia.on{background:#0075E3}',
    'body.dark .cv-comp{background:#1B2C4F}body.dark .cv-comp textarea{color:#fff}body.dark .cv-mic{background:#22345A;color:#8CC6FF}',
    /* la fine */
    '.cv-fine{display:flex;flex-direction:column;gap:12px;margin-top:6px}.cv-fine .rng-patto p{display:flex;flex-direction:column;gap:2px;margin:12px 0 0!important;font:600 14px/1.45 var(--font-body);color:#14234A}.cv-fine .rng-patto p span{font:800 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#5B6B86}',
    '.cv-fine-b .or-a + .or-a{margin-top:10px}',
    '.cv-cons{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:18px;background:rgba(255,255,255,.97);color:#14234A;text-align:left}.cv-cons > div{flex:1}.cv-cons b{display:block;font:800 14.5px var(--font-body)}.cv-cons small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:#5B6B86}',
    'body.dark .cv-cons{background:#12203A;color:#fff}body.dark .cv-cons small{color:#B9C7DD}body.dark .cv-fine .rng-patto p{color:#14234A}'
  ].join('');
  document.head.appendChild(st);
})();

/* 0.9.344: il lavoro vero di ieri e di oggi, dal computer (pcdati.js) e dalle altre AI (ponte.js). Il navigatore conta come ore sul sogno
   solo le sessioni di Full Focus e i programmi segnati produttivi sul computer: senza questi dati il Genio diceva "non hai lavorato" */
function cvLavoroVero(){
  const out = {};
  const giorno = function(off){
    try{
      const d = (typeof pcGiorno === 'function') ? pcGiorno(off) : null; if (!d) return null;
      const cat = { Productive: 'produttivo', Distracting: 'distrazione', Neutral: 'non classificato' };
      return { minutiAlComputer: Math.round(d.m || 0), minutiContatiComeLavoro: Math.round(d.prod || 0),
        voci: (d.top || []).filter(function(t){ return (t.m || 0) >= 5; }).slice(0, 8).map(function(t){ return { nome: String(t.k || ''), minuti: Math.round(t.m || 0), categoria: cat[t.c] || 'non classificato' }; }) };
    }catch(_){ return null; }
  };
  const ieri = giorno(1), oggi = giorno(0);
  if (ieri) out.computerIeri = ieri; if (oggi) out.computerOggi = oggi;
  try{ let ff = 0; const da = cvMezzanotte(1), a = cvMezzanotte(0); (typeof ffHist === 'function' ? ffHist() : []).forEach(function(x){ if (x && x.at >= da && x.at < a && !x.meditazione) ff += +(x.min || x.minutes || 0) || 0; }); out.fullFocusIeriMinuti = Math.round(ff); }catch(_){ }
  try{ if (typeof pntDelGiorno === 'function'){ const l = pntDelGiorno(1); if (l && l.length) out.conLeAltreAiIeri = l.slice(0, 6).map(function(v){ return { cosa: String(v.testo || '').slice(0, 160), minuti: v.minuti || 0 }; }); } }catch(_){ }
  out.comeLeggerlo = 'Le ore "sul sogno" del navigatore contano solo Full Focus e le voci produttive. Le voci "non classificato" possono essere lavoro vero.';
  return (out.computerIeri || out.computerOggi || out.conLeAltreAiIeri) ? out : null;
}
(function(){
  const st = document.createElement('style');
  st.textContent = '#cvPiede .cv-comp:not(.aperto){flex-wrap:nowrap;align-items:center;padding:6px 8px 6px 14px}#cvPiede .cv-comp:not(.aperto) textarea{order:0;flex:1 1 auto!important;width:auto!important;min-width:0;margin-bottom:0}#cvPiede .cv-comp:not(.aperto) .cv-mod{display:none}';
  document.head.appendChild(st);
})();

/* ===========================================================================================
   0.9.344 — LE REVISIONI FINISCONO COME UNA TAPPA
   Andrea: "tutte le revisioni si devono concludere come la tappa della roadmap: il riepilogo di fine livello, con i punti
   esperienza, sulla schermata scura". Quando una revisione arrivata in fondo si chiude (la sera, il rientro in rotta, la settimana,
   il mese...), al posto di tornare di colpo alla Mappa si vede la schermata di fine tappa (sdFineDisegna, sentiero-mappa.js).
   Quello che la revisione aveva messo in coda (il tutorial, i passi, la chat) parte dopo "Continua".
   =========================================================================================== */
const RVF = { dopo: null, t0: 0, inCorso: false };
function rvfFinita(nome){
  /* ogni chiusura guarda solo la SUA revisione: una revisione finita ieri non deve far comparire la schermata oggi */
  try{
    const c = (typeof CV !== 'undefined') ? CV.chat : null, modo = (typeof CV !== 'undefined') ? CV.modo : '';
    const mia = nome === 'rvChiudi' ? modo === 'rv' : (nome === 'rvpChiudi' ? modo === 'rvp' : (modo !== 'rv' && modo !== 'rvp'));
    if (c && c.fine && mia && !c.rvfVisto) return true;
  }catch(_){ }
  try{ if (nome === 'rvChiudi' && typeof RV !== 'undefined' && RV.passo === 'fine') return true; }catch(_){ }
  try{ if (nome === 'rngChiudi' && typeof RNG !== 'undefined' && RNG.passo === 'fine') return true; }catch(_){ }
  return false;
}
function rvfInRevisione(){ try{ const sc = document.getElementById('s-genio'); return !!(sc && sc.classList.contains('active') && (rvfFinita('rvChiudi') || rvfFinita('rvpChiudi') || rvfFinita('rngChiudi'))); }catch(_){ return false; } }
function rvfChiudiRevisione(){ try{ if (typeof CV !== 'undefined' && CV.chat && typeof cvChiudi === 'function') cvChiudi(); else if (typeof rvChiudi === 'function') rvChiudi(); }catch(_){ } }
function rvfApri(tipo){
  if (RVF.inCorso) return;
  if (typeof sdFineDisegna !== 'function' || !document.getElementById('sdFine')){ rvfVia(); return; }
  RVF.inCorso = true;
  const oggi = new Date().toDateString(), k = 'fl_rvf_xp_' + tipo;
  const xp = { sera: 10, rientro: 10, settimana: 20, mese: 30, trimestre: 40, anno: 50 }[tipo] || 10;
  let nuovo = false;
  try{ if (localStorage.getItem(k) !== oggi){ localStorage.setItem(k, oggi); const s = sdStato(); s.xp += xp; sdSalva(s); if (typeof sdXpOggiAdd === 'function') sdXpOggiAdd(xp); nuovo = true; } }catch(_){ }
  const sec = RVF.t0 ? Math.max(1, Math.round((Date.now() - RVF.t0) / 1000)) : 0;
  let serie = 0; try{ if (tipo === 'sera' && typeof rvSerie === 'function') serie = rvSerie(); }catch(_){ }
  const tit = { sera: 'Revisione della sera completata!', rientro: 'Sei rientrato in rotta!', settimana: 'Revisione della settimana completata!', mese: 'Revisione del mese completata!', trimestre: 'Revisione del trimestre completata!', anno: 'Revisione dell’anno completata!' }[tipo] || 'Revisione completata!';
  const sotto = tipo === 'rientro' ? 'Adesso sai cosa ti ha portato fuori strada.' : 'Domani parti sapendo già cosa fare.';
  goId('s-sd-fine');
  const h = document.getElementById('sdFine');
  sdFineDisegna(h, {
    cls: 'rvf', tit: tit, sotto: sotto,
    box: '<div class="sd-box gialla"><small>' + (nuovo ? 'Totale XP' : 'XP già presi oggi') + '</small><b>⚡ ' + xp + '</b></div>'
      + (serie > 0 ? '<div class="sd-box verde giro"><small>Sere di fila</small><b>🔥 ' + serie + '</b></div>' : '<div class="sd-box verde giro"><small>Revisione</small><b>✅ Fatta</b></div>')
      + '<div class="sd-box blu"><small>Tempo</small><b>⏱ ' + (sec && typeof sdMmSs === 'function' ? sdMmSs(sec) : 'Fatto') + '</b></div>',
    cta: '<button type="button" class="cta sd-fine-cta" onclick="rvfVia()">Continua</button>'
  });
}
function rvfVia(){
  RVF.inCorso = false;
  try{ if (document.getElementById('s-sd-fine').classList.contains('active')){ goId('s-home'); try{ switchTab('mappa'); }catch(_){ } } }catch(_){ }
  const d = RVF.dopo; RVF.dopo = null;
  if (d) setTimeout(d, 280);
}
(function(){
  const avvolgi = function(nome, tipoDi){
    const o = window[nome]; if (typeof o !== 'function' || o.__rvf) return false;
    const n = function(){
      let finita = false, tipo = 'sera';
      try{ finita = rvfFinita(nome); tipo = tipoDi(); }catch(_){ }
      /* quello che la revisione della sera teneva in coda (tutorial, passi, punto) parte dopo la schermata di fine */
      try{ if (finita && nome === 'rvChiudi' && typeof RV !== 'undefined' && RV.dopoAzione && typeof rvDomaniAzione === 'function'){ const az = RV.dopoAzione; RV.dopoAzione = ''; if (!RVF.dopo) RVF.dopo = function(){ rvDomaniAzione(az); }; } }catch(_){ }
      const r = o.apply(this, arguments);
      if (finita){
        /* vista una volta: la stessa revisione chiusa non la fa ricomparire */
        try{ if (typeof CV !== 'undefined' && CV.chat) CV.chat.rvfVisto = true; }catch(_){ }
        try{ if (nome === 'rvChiudi' && RV.passo === 'fine') RV.passo = 'chiusa'; }catch(_){ }
        try{ if (nome === 'rngChiudi' && RNG.passo === 'fine') RNG.passo = 'chiusa'; }catch(_){ }
        setTimeout(function(){ rvfApri(tipo); }, 80);
      }
      return r;
    };
    n.__rvf = true; window[nome] = n; return true;
  };
  const prova = function(k){
    const a = avvolgi('rvChiudi', function(){ return 'sera'; });
    const b = avvolgi('rvpChiudi', function(){ return (typeof RVP !== 'undefined' && RVP.tipo) || 'settimana'; });
    const c = avvolgi('rngChiudi', function(){ return 'rientro'; });
    const d = (function(){ const o = window.cvEntra; if (typeof o !== 'function' || o.__rvf) return typeof o === 'function'; const n = function(){ RVF.t0 = Date.now(); return o.apply(this, arguments); }; n.__rvf = true; window.cvEntra = n; return true; })();
    if ((!a || !b || !c || !d) && k < 20) setTimeout(function(){ prova(k + 1); }, 800);
  };
  setTimeout(function(){ prova(0); }, 1500);
})();

/* 0.9.346: il telefono di oggi, qualunque sorgente stia guardando il Report (i granelli del telefono, motore-web.js) */
async function cvTelefonoOggi(){
  if (typeof mwGraniTelefono !== 'function') return null;
  const d0 = cvMezzanotte(0), ora = Date.now();
  const g = (await mwGraniTelefono(d0)) || [];
  const per = {}; let tot = 0;
  g.forEach(function(x){
    if ((x.fonte || x.dev || 'telefono') === 'computer') return;
    const s = Math.max(x.s, d0), e = Math.min(x.s + x.ms, ora); if (!(e > s)) return;
    if (typeof dmNonConta === 'function' && dmNonConta(x.p)) return;
    const k = String(x.l || x.p || '?'); per[k] = (per[k] || 0) + (e - s); tot += e - s;
  });
  const voci = Object.keys(per).map(function(k){ return { nome: k, minuti: Math.round(per[k] / 60000) }; }).filter(function(v){ return v.minuti >= 2; }).sort(function(a, b){ return b.minuti - a.minuti; }).slice(0, 8);
  return voci.length ? { minutiAlTelefono: Math.round(tot / 60000), voci: voci } : null;
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.cv-err2{display:flex;flex-direction:column;align-items:center;gap:6px;padding:6px 10px 2px}.cv-err2 p{margin:0!important;font:700 14.5px/1.4 var(--font-body)!important;color:#FFB3BB!important}.cv-err2 small{font:500 13px/1.4 var(--font-body);color:#BFD3EC}'
    + '.cv-err-btn{margin-top:10px;padding:13px 26px;border:0;border-radius:16px;background:#0075E3;color:#fff;font:800 15px var(--font-body);box-shadow:0 6px 16px rgba(0,117,227,.35);cursor:pointer}.cv-err2 .gn-link{margin-top:8px}';
  document.head.appendChild(st);
})();
