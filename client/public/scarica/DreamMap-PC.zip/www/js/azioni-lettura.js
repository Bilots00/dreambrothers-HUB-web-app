/* ===========================================================================================
   LA LETTURA DELLE TUE AZIONI (0.9.374, prefisso azl-)
   Andrea: "se l'utente clicca su Chiedi al tuo agente personale gli si fa partire, come nel Rientra in rotta, il pannello che
   gli fa vedere dove va la sua attenzione, cosi' si rende conto che le card non erano cagate ma si basavano su dati veri. Per gli
   utenti free non c'e' la chat ma un questionario tipo lettura del Genio, che identifica le azioni".
   Passi: 'dati' (il pannello di Dove va la tua attenzione, lo stesso di Proteggi i tuoi sogni) -> con Premium la chat con il tuo
   agente personale; senza, 'distr' (cosa fai quando ti distrai) -> 'bene' (cosa ti avvicina al sogno) -> 'fine' (le card nuove).
   Indietro (freccia e tasto del telefono) torna al passo prima; dal primo si esce.
   =========================================================================================== */
const AZL = { passo: 'dati', distr: [], bene: [], da: 's-home' };
const AZL_PASSI = ['dati', 'distr', 'bene', 'fine'];
const AZL_DISTR = [
  { k: 'social', em: '📲', t: 'Scrolling sui social' }, { k: 'video', em: '🍿', t: 'Binge watching' },
  { k: 'chat', em: '💬', t: 'Chat e messaggi' }, { k: 'giochi', em: '🎮', t: 'Giochi' },
  { k: 'shop', em: '🛍️', t: 'Shopping online' }, { k: 'news', em: '📰', t: 'Notizie a raffica' },
  { k: 'web', em: '🌐', t: 'Navigazione sul web' }, { k: 'tel', em: '📞', t: 'Telefonate' }
];
const AZL_BENE = [
  { k: 'ff', em: '🎯', t: 'Sessioni di Full Focus' }, { k: 'leggere', em: '📚', t: 'Leggere' },
  { k: 'sport', em: '🏋️', t: 'Allenarmi' }, { k: 'camminare', em: '🚶', t: 'Camminare' },
  { k: 'scrivere', em: '✍️', t: 'Scrivere' }, { k: 'meditare', em: '🧘', t: 'Meditare' },
  { k: 'lavoro', em: '🛠️', t: 'Lavoro sul sogno' }, { k: 'dormire', em: '😴', t: 'Dormire otto ore' }
];
function azlE(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function azlPremium(){ try{ return typeof pscPremium === 'function' && pscPremium(); }catch(_){ return false; } }
function azlApri(){
  AZL.passo = 'dati'; AZL.distr = []; AZL.bene = [];
  try{ AZL.da = order[cur] || 's-home'; }catch(_){ AZL.da = 's-home'; }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  goId('s-azl');
  azlPaint();
}
function azlIndietro(){
  const i = AZL_PASSI.indexOf(AZL.passo);
  if (i > 0 && AZL.passo !== 'fine'){ AZL.passo = AZL_PASSI[i - 1]; azlPaint(); return true; }
  return false;
}
function azlEsci(){ AZL.passo = 'dati'; try{ if (typeof flIndietro === 'function') flIndietro(); else goId('s-home'); }catch(_){ goId('s-home'); } }
function azlVai(p){ AZL.passo = p; try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ } azlPaint(); }
function azlToggle(lista, k){ const l = AZL[lista], i = l.indexOf(k); if (i >= 0) l.splice(i, 1); else l.push(k); azlPaint(); }
function azlGenio(img, testo){
  return '<div class="azl-genio"><img src="img/genio/' + img + '.png" alt=""></div><div class="azl-bolla"><p>' + testo + '</p></div>';
}
function azlScelte(lista, voci){
  return '<div class="azl-g">' + voci.map(function(v){
    const on = AZL[lista].indexOf(v.k) >= 0;
    return '<button type="button" class="azl-o' + (on ? ' on' : '') + '" aria-pressed="' + on + '" onclick="azlToggle(\'' + lista + '\',\'' + v.k + '\')"><span>' + v.em + '</span><b>' + azlE(v.t) + '</b></button>';
  }).join('') + '</div>';
}
async function azlPaint(){
  const box = document.getElementById('azlCorpo'); if (!box) return;
  const p = AZL.passo, prem = azlPremium();
  const n = AZL_PASSI.indexOf(p);
  const bar = document.getElementById('azlBar'); if (bar) bar.style.width = Math.round(((n + 1) / (prem ? 1 : AZL_PASSI.length)) * 100) + '%';
  if (p === 'dati'){
    box.innerHTML = azlGenio('genio-rivela', 'Le tue azioni nascono da qui: <b>dove va la tua attenzione</b>.')
      + '<div class="azl-pan" id="cvPan"><p class="azl-att">Sto leggendo il telefono.</p></div>'
      + '<button type="button" class="azl-cta" onclick="' + (prem ? 'azlChat()' : 'azlVai(\'distr\')') + '">' + (prem ? 'Parliamone' : 'Continua') + '</button>';
    try{
      if (typeof CV !== 'undefined' && CV) CV.panV = { range: (typeof scRepRange === 'function' ? scRepRange() : '7d'), dove: 'cv' };
      const out = (typeof scPannelloHtml === 'function') ? await scPannelloHtml((typeof CV !== 'undefined' && CV && CV.panV) || { range: '7d', dove: 'cv' }) : null;
      const pan = document.getElementById('cvPan');
      if (!pan || AZL.passo !== 'dati') return;
      if (out && out.html && !out.negato) pan.innerHTML = out.html.replace(/ onclick="(scTopTap|scOpenApp|scNotifSettings)\([^"]*\)"/g, '');
      else pan.innerHTML = '<p class="azl-att">Per vedere dove va la tua attenzione serve l’accesso ai dati di utilizzo.</p>';
    }catch(_){ const pan = document.getElementById('cvPan'); if (pan) pan.innerHTML = '<p class="azl-att">Non riesco a leggere il telefono adesso.</p>'; }
    return;
  }
  if (p === 'distr'){
    box.innerHTML = azlGenio('genio-pensa', 'Quando ti distrai, <b>cosa fai più spesso</b>? Puoi sceglierne più di una.')
      + azlScelte('distr', AZL_DISTR)
      + '<button type="button" class="azl-cta" onclick="azlVai(\'bene\')"' + (AZL.distr.length ? '' : ' disabled') + '>Continua</button>';
    return;
  }
  if (p === 'bene'){
    box.innerHTML = azlGenio('genio-saluta', 'E cosa ti fa stare bene <b>e ti avvicina al sogno</b>?')
      + azlScelte('bene', AZL_BENE)
      + '<button type="button" class="azl-cta" onclick="azlFine()"' + (AZL.bene.length ? '' : ' disabled') + '>Vedi le tue azioni</button>';
    return;
  }
  if (p === 'fine'){
    const voci = AZL_DISTR.filter(function(v){ return AZL.distr.indexOf(v.k) >= 0; }).map(function(v){ return [v, 'cambia']; })
      .concat(AZL_BENE.filter(function(v){ return AZL.bene.indexOf(v.k) >= 0; }).map(function(v){ return [v, 'nuova']; }));
    box.innerHTML = azlGenio('genio-rivela', 'Ecco le tue azioni. Le trovi nella scheda <b>Azione</b>.')
      + '<div class="azl-fine">' + voci.map(function(x){ return '<div class="azl-r"><span>' + x[0].em + '</span><b>' + azlE(x[0].t) + '</b><em class="' + x[1] + '">' + (x[1] === 'cambia' ? 'Da cambiare' : 'Da tenere') + '</em></div>'; }).join('') + '</div>'
      + '<button type="button" class="azl-cta" onclick="azlEsci()">Torna alle tue azioni</button>';
  }
}
/* le risposte diventano azioni (fl_azioni_id), senza doppioni: la chiave k e' la stessa delle card proposte */
function azlFine(){
  let l = []; try{ l = (typeof pscAzioni === 'function') ? pscAzioni() : []; }catch(_){ l = []; }
  const gia = l.map(function(a){ return a.k; });
  const metti = function(v, tipo){
    if (gia.indexOf(v.k) >= 0) return;
    l.push({ id: 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), k: v.k, tipo: tipo, t: v.t, em: v.em, img: '', da: { tipo: 'lettura', nome: 'Dalla lettura del Genio', val: '' }, at: Date.now() });
  };
  AZL_DISTR.forEach(function(v){ if (AZL.distr.indexOf(v.k) >= 0) metti(v, 'cambia'); });
  AZL_BENE.forEach(function(v){ if (AZL.bene.indexOf(v.k) >= 0) metti(v, 'nuova'); });
  try{ if (typeof pscScriviAzioni === 'function') pscScriviAzioni(l); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra([10, 30, 10]); }catch(_){ }
  try{ if (typeof pscRidisegna === 'function') pscRidisegna(); }catch(_){ }
  azlVai('fine');
}
async function azlChat(){
  let ok = false;
  try{ if (typeof agPopover === 'function') ok = await agPopover('', { titolo: 'Le mie azioni', pill: ['Quale abitudine mi allontana di più dal sogno?', 'Che azione nuova posso fare domani?', 'Trasforma il mio tempo sul telefono in azioni chiare'] }); }catch(_){ ok = false; }
  if (!ok){ try{ toast('Il tuo agente personale non risponde adesso, riprova fra poco'); }catch(_){ } }
}

registerScreen('s-azl',
  '<div class="azl-top"><button type="button" class="azl-back" aria-label="Indietro" onclick="if(!azlIndietro())azlEsci()"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button>'
  + '<div class="azl-prog"><i id="azlBar"></i></div></div>'
  + '<div class="azl-corpo" id="azlCorpo"></div>',
  /* indietro: il passo prima; dal primo, dove eri (handleBackNucleo prova la storia prima di andare a casa) */
  { back: function(){ if (azlIndietro()) return 's-azl'; return 's-home'; } });

(function(){
  const css = [
    '#s-azl{background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C);color:#fff;padding-top:calc(16px + env(safe-area-inset-top,0px))}',
    '.azl-top{display:flex;align-items:center;gap:14px;flex:none}',
    '.azl-back{flex:none;width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.azl-prog{flex:1;height:10px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}.azl-prog i{display:block;height:100%;width:25%;border-radius:99px;background:linear-gradient(90deg,#8CC6FF,#3F9FF4);transition:width .35s ease}',
    '.azl-corpo{display:flex;flex-direction:column;align-items:center;padding:18px 0 28px}',
    '.azl-genio img{display:block;width:118px;height:auto;margin:6px auto 0}',
    '.azl-bolla{align-self:stretch;margin-top:12px;padding:18px 20px;border-radius:22px;background:#fff;color:#0E2350;text-align:center}.azl-bolla p{margin:0;font:700 17px/1.45 var(--font-body)}.azl-bolla b{color:#0075E3}',
    '.azl-pan{align-self:stretch;margin-top:22px}.azl-att{margin:0;padding:18px;text-align:center;font:600 14px/1.45 var(--font-body);color:#C8EFFD}',
    '.azl-g{align-self:stretch;display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:22px}',
    '.azl-o{min-height:92px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:12px 10px;border:1.5px solid #DCE8F5;border-radius:18px;background:#fff;color:#0E2350;cursor:pointer;font:inherit}',
    '.azl-o span{font-size:26px;line-height:1}.azl-o b{font:700 14px/1.3 var(--font-body);color:#0E2350;text-align:center}',
    '.azl-o.on{border-color:#0075E3;background:#E3F1FF;box-shadow:0 0 0 3px rgba(0,117,227,.22)}',
    '.azl-cta{align-self:stretch;margin-top:28px;min-height:56px;border:0;border-radius:18px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.35)}.azl-cta[disabled]{opacity:.45;box-shadow:none}',
    '.azl-fine{align-self:stretch;display:flex;flex-direction:column;gap:10px;margin-top:22px}',
    '.azl-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.08)}.azl-r span{font-size:22px}.azl-r b{flex:1;font:700 15px var(--font-body);color:#fff;text-align:left}',
    '.azl-r em{font:800 10.5px var(--font-body);font-style:normal;letter-spacing:.06em;text-transform:uppercase;color:#fff;padding:4px 9px;border-radius:99px;background:#0075E3}.azl-r em.cambia{background:#E63946}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
