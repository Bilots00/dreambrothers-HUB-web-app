/* ===========================================================================================
   LA PILLOLA DELL'ATTESA (0.9.351)

   Andrea: "ogni volta che c'e' un'attesa (il promemoria di prova, la roadmap che si crea o si
   ricalcola) la schermata si chiude e resta un cartello che mostra cosa sta succedendo, la
   percentuale e il tempo che manca, come quando si installa un programma su Windows. Toccandolo
   riapro la schermata. Nessuno ha voglia di stare li' a guardare per due minuti."

   flAttesaAvvia(id, { titolo, durataMs, riapri, nascondiSe }) accende la pillola;
   flAttesaFine(id, testo) la fa diventare "fatto" (con il testo) e poi sparire;
   flAttesaVia(id) la toglie subito. Se la durata vera non si sa, la percentuale sale verso il 95%
   e il tempo che manca dice "ancora qualche secondo".
   =========================================================================================== */
const FL_ATT = {};
let FL_ATT_T = 0;
function flAttesaAvvia(id, o){
  o = o || {};
  FL_ATT[id] = { titolo: o.titolo || 'Un attimo', da: Date.now(), durata: Math.max(3000, o.durataMs || 60000), riapri: o.riapri || null, nascondiSe: o.nascondiSe || null, fatto: false, testo: '' };
  flAttesaPaint();
  clearInterval(FL_ATT_T); FL_ATT_T = setInterval(flAttesaPaint, 500);
}
function flAttesaFine(id, testo, riapri){
  const a = FL_ATT[id]; if (!a) return;
  a.fatto = true; a.testo = testo || 'Fatto'; if (riapri) a.riapri = riapri;
  try{ if (typeof flVibra === 'function') flVibra([12, 40, 12]); }catch(_){ }
  flAttesaPaint();
  setTimeout(function(){ if (FL_ATT[id] === a){ delete FL_ATT[id]; flAttesaPaint(); } }, 15000);
}
function flAttesaVia(id){ delete FL_ATT[id]; flAttesaPaint(); }
function flAttesaTocca(id){ const a = FL_ATT[id]; if (!a) return; const f = a.riapri; if (a.fatto) delete FL_ATT[id]; flAttesaPaint(); if (typeof f === 'function'){ try{ f(); }catch(_){ } } }
function flAttesaPaint(){
  let w = document.getElementById('flAtt');
  const ids = Object.keys(FL_ATT).filter(function(k){ const a = FL_ATT[k]; try{ return !(a.nascondiSe && a.nascondiSe()); }catch(_){ return true; } });
  if (!ids.length){ if (w) w.classList.remove('in'); if (!Object.keys(FL_ATT).length) clearInterval(FL_ATT_T); return; }
  if (!w){ w = document.createElement('button'); w.type = 'button'; w.id = 'flAtt'; w.className = 'fl-att'; (document.getElementById('phone') || document.body).appendChild(w); }
  const id = ids[0], a = FL_ATT[id];
  const pass = Date.now() - a.da;
  const pct = a.fatto ? 100 : (pass < a.durata ? Math.round(pass / a.durata * 100) : Math.min(95, 90 + Math.round((pass - a.durata) / 4000)));
  const resta = Math.max(0, Math.ceil((a.durata - pass) / 1000));
  const restaTxt = a.fatto ? 'Tocca per vedere' : (resta > 0 ? (resta >= 60 ? 'mancano ' + Math.floor(resta / 60) + ':' + String(resta % 60).padStart(2, '0') : (resta === 1 ? 'manca 1 secondo' : 'mancano ' + resta + ' secondi')) : 'ancora qualche secondo');
  w.onclick = function(){ flAttesaTocca(id); };
  w.classList.toggle('fatto', a.fatto);
  /* sulle schermate senza la barra delle schede (fine tappa, esercizi, pagine a tutto schermo) il cartello va in alto, cosi' non copre il pulsante in fondo */
  let suTab = false; try{ suTab = typeof order !== 'undefined' && order[cur] === 's-home'; }catch(_){ }
  w.classList.toggle('su', !suTab);
  w.innerHTML = '<span class="fl-att-i" aria-hidden="true">' + (a.fatto ? '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>' : '<i></i>') + '</span>'
    + '<span class="fl-att-t"><b>' + (typeof esc === 'function' ? esc(a.fatto ? a.testo : a.titolo) : (a.fatto ? a.testo : a.titolo)) + '</b><small>' + restaTxt + '</small><span class="fl-att-b"><i style="width:' + pct + '%"></i></span></span>'
    + '<em class="fl-att-p">' + pct + '%</em>';
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.fl-att{position:fixed;left:14px;right:14px;bottom:calc(92px + env(safe-area-inset-bottom,0px));z-index:9600;display:flex;align-items:center;gap:12px;padding:12px 14px;border:0;border-radius:18px;background:linear-gradient(135deg,#0B3E86,#001E44);color:#fff;text-align:left;box-shadow:0 14px 34px rgba(0,19,43,.35);cursor:pointer;transform:translateY(160%);opacity:0;transition:transform .35s cubic-bezier(.2,.9,.3,1.1),opacity .25s;font-family:var(--font-body)}'
    + '.fl-att.su{bottom:auto;top:calc(12px + env(safe-area-inset-top,0px));transform:translateY(-160%)}'
    + '.fl-att.in{transform:none;opacity:1}.fl-att.fatto{background:linear-gradient(135deg,#0075E3,#001E44)}'
    + '.fl-att-i{flex:none;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.14)}.fl-att-i i{width:16px;height:16px;border-radius:50%;border:2.5px solid rgba(255,255,255,.35);border-top-color:#fff;animation:flAttGira .9s linear infinite}@keyframes flAttGira{to{transform:rotate(360deg)}}'
    + '.fl-att-t{flex:1;min-width:0}.fl-att-t b{display:block;font:800 14px/1.25 var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fl-att-t small{display:block;margin-top:2px;font:600 12px var(--font-body);color:#C8EFFD}'
    + '.fl-att-b{display:block;height:5px;margin-top:8px;border-radius:3px;background:rgba(255,255,255,.18);overflow:hidden}.fl-att-b i{display:block;height:100%;border-radius:3px;background:linear-gradient(90deg,#3F9FF4,#8CC6FF);transition:width .5s linear}'
    + '.fl-att-p{flex:none;font:900 15px var(--font-display);font-style:normal;color:#fff;font-variant-numeric:tabular-nums}'
    + '@media (prefers-reduced-motion:reduce){.fl-att-i i{animation:none}}';
  document.head.appendChild(st);
})();
