/* ===========================================================================================
   LO SBLOCCO DI EMERGENZA (0.9.291), come quello di AppBlock

   Andrea: "in Aiuto e altro voglio lo sblocco di emergenza come AppBlock". Il percorso:
     1. "Hai bisogno di disattivare la Modalita' severa in caso di emergenza?" (No e' il pulsante blu)
     2. con il PASS D'EMERGENZA ancora in tasca: si tiene premuto e la severa si spegne subito,
        senza domande ne' testo da copiare. E' l'unico sblocco che il tuo agente personale puo' proporre.
     3. senza pass: sei domande (le stesse di AppBlock: le risposte servono a migliorare l'app),
     4. dal secondo sblocco del mese: "Questo mese hai gia' usato lo sblocco N volte", con
        "Trova un altro metodo" che apre il tuo agente personale, e il testo difficile da copiare esatto,
     5. l'attesa sulla schermata: 1 minuto la prima volta del mese, poi 2, 4, 8... (raddoppia),
        con "Tieni attiva la Modalita' severa!" che porta al cuore "Sapevamo che ce l'avresti fatta",
     6. allo zero: "Modalita' severa disattivata".
   Il conto e' del mese: il primo del mese si riparte da un minuto.
   =========================================================================================== */
const EF = { passo: '', risposte: {}, fine: 0, tick: 0, ultimoSecondo: -1 };
/* il testo da copiare e' lungo apposta (come quello di AppBlock): e' il prezzo del secondo sblocco del mese */
const EF_TESTO = [
  'Se*questa^non@è%una&VERA*emergenza,io$NO',
  'N#spegnerò&la^Modalità@severa-e*non^trad',
  'irò%il$MIO&IMPEGNO-con#me@stesso.Sono^qu',
  'i*per$ridurre%il&TEMPO-al#telefono,ritro',
  'vare^la*concentrazione,e%costruire$abitu',
  'dini&migliori.Niente@SCUSE.È*urgente,e^l',
  'a$prossima%volta&sarò#più@CONSAPEVOLE.'
].join('');
const EF_DOMANDE = [
  { k: 'obiettivo', q: 'Qual è stato il tuo obiettivo numero uno per usare la Modalità severa questa volta?',
    o: ['Concentrarsi su qualcosa di importante', 'Per evitare di scrollare', 'Abbandonare un’abitudine', 'Per tornare alla vita reale', 'Altro'] },
  { k: 'tentazione', q: 'La tentazione di sbloccare è più forte del tuo obiettivo?', o: ['Sì', 'No'] },
  { k: 'dopo', q: 'Ti sentiresti frustrato, in colpa o deluso dopo aver sbloccato?', o: ['Sì', 'No', 'Non sono sicuro'] },
  { k: 'aiuta', q: 'Lasciar perdere il tuo obiettivo ti aiuterà davvero in questo momento?', o: ['Sì', 'No'] },
  { k: 'sicuro', q: 'Hai impostato questo obiettivo per una ragione. Sei sicuro di voler venir meno al tuo impegno?', o: ['Sì', 'No'] },
  { k: 'controllo', q: 'Vuoi sentirti in controllo o semplicemente sentirti meglio per un attimo?', o: ['Voglio il controllo', 'Voglio un comfort veloce', 'Non lo so'] }
];
const EF_X = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const EF_APERTO = '<svg viewBox="0 0 120 120" width="112" height="112" aria-hidden="true"><defs><linearGradient id="efLg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF6B76"/><stop offset="1" stop-color="#C81E2C"/></linearGradient></defs><path d="M38 52V36a22 22 0 0 1 43-6.5" fill="none" stroke="#E63946" stroke-width="11" stroke-linecap="round"/><rect x="22" y="50" width="76" height="58" rx="16" fill="url(#efLg)"/><path d="M64 60 48 82h12l-4 18 17-24H61z" fill="#fff"/></svg>';
const EF_CUORE = '<svg viewBox="0 0 120 108" width="230" height="207" aria-hidden="true"><defs><radialGradient id="efCg" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#8FD0FF"/><stop offset=".45" stop-color="#2F7BFF"/><stop offset="1" stop-color="#1240C8"/></radialGradient></defs><path d="M60 104C24 80 4 60 4 34 4 16 18 4 34 4c11 0 20 6 26 15C66 10 75 4 86 4c16 0 30 12 30 30 0 26-20 46-56 70z" fill="url(#efCg)"/></svg>';

function efMese(){ const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
/** {n: sblocchi senza pass di questo mese, p: con il pass} */
function efConto(){
  try{ const c = JSON.parse(localStorage.getItem('fl_emg_mese') || 'null'); if (c && c.m === efMese()) return { n: +c.n || 0, p: +c.p || 0 }; }catch(_){ }
  return { n: 0, p: 0 };
}
function efContoSegna(conPass){
  const c = efConto();
  if (conPass) c.p++; else c.n++;
  try{ localStorage.setItem('fl_emg_mese', JSON.stringify({ m: efMese(), n: c.n, p: c.p })); }catch(_){ }
}
/** I minuti dell'attesa: 1 la prima volta del mese, poi raddoppia. */
function efMinuti(){ return Math.min(256, Math.pow(2, efConto().n)); }
function efSeveraAccesa(){ try{ return !!(typeof sevState !== 'undefined' && sevState && sevState.level); }catch(_){ return false; } }
async function efPassDisponibile(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.emergencyState) return false;
  try{ const st = await NATIVE.emergencyState(); return !!(st && st.available); }catch(_){ return false; }
}

registerScreen('s-emergenza', '<div class="ef" id="efBody"></div>', { back: function(){ efFerma(); return 's-home'; } });

async function emgFlussoApri(){
  EF.risposte = {}; EF.fine = 0;
  try{ if (typeof sevLoadState === 'function') await sevLoadState(); }catch(_){ }
  goId('s-emergenza');
  if (!efSeveraAccesa()){ efVai('spenta-gia'); return; }
  efVai('chiedi');
}
function efChiudi(){ efFerma(); if (typeof flIndietro === 'function') flIndietro(); else goId('s-home'); }
/* 0.9.309: spenta la Modalita' severa, "Continua" porta alla sua pagina (spenta, come AppBlock), non alla pagina
   da cui si era partiti: la casa sotto, cosi' indietro non torna dentro al flusso di emergenza */
function efAllaPagina(){ efFerma(); goId('s-home'); if (typeof svpApri === 'function') svpApri(); }
function efFerma(){ if (EF.tick){ clearInterval(EF.tick); EF.tick = 0; } EF.fine = 0; }

function efPagina(corpo, conX){
  return (conX === false ? '' : '<button type="button" class="ef-x" aria-label="Chiudi" onclick="efChiudi()">' + EF_X + '</button>') + corpo;
}
function efVai(passo, extra){
  EF.passo = passo;
  const b = document.getElementById('efBody'); if (!b) return;
  b.scrollTop = 0;
  let h = '';
  if (passo === 'spenta-gia'){
    h = efPagina('<div class="ef-centro"><h1>La Modalità severa non è attiva</h1><p>I tuoi blocchi si cambiano già dalla loro pagina.</p></div><button type="button" class="ef-blu" onclick="efChiudi()">Torna indietro</button>');
  } else if (passo === 'chiedi'){
    h = efPagina('<div class="ef-centro ef-alto"><div class="ef-ico">' + EF_APERTO + '</div><h1>Hai bisogno di disattivare la Modalità severa in caso di emergenza?</h1>'
      + '<p>Questo è solo per vere emergenze urgenti. Se non è così, tocca "No" e torna a concentrarti.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="efChiudi()">No, torna a concentrarti</button><button type="button" class="ef-grigio" onclick="efDopoSi()">Sì, sono in emergenza</button></div>');
  } else if (passo === 'pass'){
    h = efPagina('<div class="ef-centro ef-alto"><div class="ef-ico">' + EF_APERTO + '</div><h1>Hai un pass d’emergenza</h1>'
      + '<p>Usalo: spegne subito la Modalità severa.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-tieni" id="efTieni"><span>Tieni premuto per usare il pass d’emergenza</span></button><button type="button" class="ef-grigio" onclick="efChiudi()">Non lo uso</button></div>');
  } else if (passo.indexOf('q') === 0){
    const i = +passo.slice(1), d = EF_DOMANDE[i];
    h = efPagina('<h1 class="ef-dom">' + esc(d.q) + '</h1><div class="ef-opz">'
      + d.o.map(function(o, j){ return '<button type="button" class="ef-opt" onclick="efRispondi(' + i + ',' + j + ')">' + esc(o) + '</button>'; }).join('') + '</div>');
  } else if (passo === 'conta'){
    const c = efConto(), tot = c.n + c.p;
    h = efPagina('<h1 class="ef-dom">Questo mese hai già usato lo sblocco di emergenza per disattivare la Modalità severa</h1>'
      + '<div class="ef-volte">' + tot + '×</div>'
      + '<div class="ef-centro ef-basso"><b>Lo capiamo, le cose succedono.</b><p>Forse è il momento di passare a un metodo di accesso diverso? Perdi l’abitudine, non la concentrazione.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="efAltroMetodo()">Trova un altro metodo</button><button type="button" class="ef-link" onclick="efDopoConta()">Continua lo stesso</button></div>');
  } else if (passo === 'digita'){
    h = efPagina('<h1 class="ef-dom">Per continuare, digita esattamente il seguente testo:</h1>'
      + '<p class="ef-codice" aria-label="Testo da copiare">' + esc(EF_TESTO) + '</p>'
      + '<textarea class="ef-campo" id="efCampo" data-no-mic rows="5" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" oninput="efControlla()" onpaste="return false" ondrop="return false"></textarea>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" id="efContinua" disabled onclick="efVai(\'attesa\')">Continua</button></div>');
  } else if (passo === 'attesa'){
    const min = efMinuti();
    h = efPagina('<div class="ef-centro ef-alto"><div class="ef-anello"><svg viewBox="0 0 120 120" width="210" height="210"><circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="5"/><circle id="efArco" cx="60" cy="60" r="54" fill="none" stroke="#2F9BFF" stroke-width="5" stroke-linecap="round" stroke-dasharray="339.3" stroke-dashoffset="339.3" transform="rotate(-90 60 60)"/></svg><span>' + SVH_LUCCHETTO_EF() + '</span></div>'
      + '<h1>Disattiva tra</h1><div class="ef-tempo" id="efTempo">' + efMmSs(min * 60) + '</div><p>Aspetta su questa schermata fino allo scadere del tempo.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="efResisti()">Tieni attiva la Modalità severa!</button></div>');
  } else if (passo === 'cuore'){
    h = '<div class="ef-centro ef-cuore"><div class="ef-cuore-ico">' + EF_CUORE + '</div><h1>Sapevamo che ce l’avresti fatta!</h1><p>Bel lavoro per rimanere fedele al tuo obiettivo.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="efChiudi()">Torno al mio obiettivo</button></div>';
  } else if (passo === 'spenta'){
    h = '<div class="ef-centro ef-alto"><div class="ef-spento">' + SVH_LUCCHETTO_EF(true) + '</div><h1>Modalità severa disattivata</h1>'
      + '<p>Adesso puoi modificare o interrompere qualsiasi blocco in corso. Se non lo fai, Programmi, Blocco rapido e altri blocchi rimarranno attivi.</p></div>'
      + '<div class="ef-piede"><button type="button" class="ef-blu" onclick="efAllaPagina()">Continua</button></div>';
  } else if (passo === 'errore'){
    h = efPagina('<div class="ef-centro ef-alto"><h1>La Modalità severa non si è spenta</h1><p>' + esc(extra || 'Riprova fra un momento.') + '</p></div><div class="ef-piede"><button type="button" class="ef-blu" onclick="efChiudi()">Chiudi</button></div>');
  }
  b.className = 'ef ef-' + passo.replace(/\d+$/, '');
  b.innerHTML = h;
  if (passo === 'pass') efLegaTieni(document.getElementById('efTieni'));
  if (passo === 'attesa') efAttesaAvvia();
  if (passo === 'cuore' || passo === 'spenta'){ try{ flVibra(passo === 'cuore' ? [30, 60, 30] : 40); }catch(_){ } }
}
function SVH_LUCCHETTO_EF(aperto){
  return '<svg viewBox="0 0 24 24" width="52" height="52" aria-hidden="true"><path d="' + (aperto ? 'M7 10V7.5a5 5 0 0 1 9.6-1.9' : 'M7 10V7.5a5 5 0 0 1 10 0V10') + '" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/><rect x="4" y="10" width="16" height="12" rx="3.2" fill="#fff"/><path d="M12.9 12.4 9.8 16.6h2.4l-.9 3.1 3.1-4.3h-2.4z" fill="#0E2350"/></svg>';
}
function efMmSs(sec){ sec = Math.max(0, Math.ceil(sec)); return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0'); }

async function efDopoSi(){
  try{ flVibra(10); }catch(_){ }
  if (await efPassDisponibile()){ efVai('pass'); return; }
  efVai('q0');
}
function efRispondi(i, j){
  const d = EF_DOMANDE[i];
  EF.risposte[d.k] = d.o[j];
  try{ flVibra(8); }catch(_){ }
  /* "Sei sicuro di voler venir meno al tuo impegno?" No: ha cambiato idea, e si festeggia */
  if (d.k === 'sicuro' && j === 1){ efSalvaRisposte('ha cambiato idea'); efVai('cuore'); return; }
  if (i + 1 < EF_DOMANDE.length){ efVai('q' + (i + 1)); return; }
  efSalvaRisposte('');
  const c = efConto();
  if (c.n + c.p >= 1){ efVai('conta'); return; }
  efVai('attesa');
}
function efDopoConta(){ efVai(efConto().n >= 1 ? 'digita' : 'attesa'); }
function efControlla(){
  const t = document.getElementById('efCampo'), b = document.getElementById('efContinua');
  if (!t || !b) return;
  const ok = t.value === EF_TESTO;
  b.disabled = !ok;
  t.classList.toggle('ok', ok);
}
async function efAltroMetodo(){
  const c = efConto();
  const testo = 'Questo mese ho già usato ' + (c.n + c.p) + (c.n + c.p === 1 ? ' volta' : ' volte') + ' lo sblocco di emergenza per spegnere la Modalità severa. Aiutami a trovare un altro metodo: cosa cambio nelle mie regole, nel metodo di uscita o nella mia giornata per non arrivare di nuovo a volerla spegnere?';
  efFerma();
  if (typeof agPopover === 'function'){
    const ok = await agPopover(testo, { titolo: 'Un altro metodo' });
    if (ok) return;
  }
  if (typeof toast === 'function') toast('Il tuo agente personale non risponde adesso: riprova fra poco');
}
/* le risposte servono a migliorare l'app: restano sul telefono e arrivano anche a chi la sviluppa */
function efSalvaRisposte(nota){
  const r = { at: Date.now(), risposte: EF.risposte, nota: nota || '', volteMese: efConto() };
  try{ const a = JSON.parse(localStorage.getItem('fl_emg_risposte') || '[]'); a.push(r); localStorage.setItem('fl_emg_risposte', JSON.stringify(a.slice(-40))); }catch(_){ }
  try{
    const righe = EF_DOMANDE.map(function(d){ return '- ' + d.q + ' ' + (EF.risposte[d.k] || '(nessuna risposta)'); }).join('\n');
    const payload = { text: '[Sblocco di emergenza] ' + (nota ? nota + '\n' : '') + righe + '\nSblocchi questo mese: ' + (r.volteMese.n + r.volteMese.p), appVersion: (typeof APP_VERSION !== 'undefined' ? APP_VERSION : ''), device: navigator.userAgent.slice(0, 120), locale: navigator.language };
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi) NATIVE.publicApi({ method: 'POST', path: '/api/focuslock/feedback', body: JSON.stringify(payload) }).catch(function(){ });
  }catch(_){ }
}

/* ---- l'attesa: resta su questa schermata, se esci riparte da capo ---- */
function efAttesaAvvia(){
  efFerma();
  const tot = efMinuti() * 60000;
  EF.fine = Date.now() + tot;
  EF.ultimoSecondo = -1;
  const arco = function(){
    const resta = Math.max(0, EF.fine - Date.now());
    const t = document.getElementById('efTempo'); if (t) t.textContent = efMmSs(resta / 1000);
    const a = document.getElementById('efArco'); if (a) a.setAttribute("stroke-dashoffset", String(339.3 * (resta / tot)));
    return resta;
  };
  arco();
  EF.tick = setInterval(function(){
    const pag = document.getElementById('s-emergenza');
    if (!pag || !pag.classList.contains('active') || EF.passo !== 'attesa'){ efFerma(); return; }
    if (arco() <= 0){ efFerma(); efSpegni(false); }
  }, 250);
}
document.addEventListener('visibilitychange', function(){
  /* chi esce dalla schermata durante l'attesa ricomincia: "aspetta su questa schermata" */
  if (document.hidden && EF.passo === 'attesa' && EF.fine){ EF.ripartire = true; }
  if (!document.hidden && EF.ripartire && EF.passo === 'attesa'){
    EF.ripartire = false;
    efAttesaAvvia();
    if (typeof toast === 'function') toast('Sei uscito dalla schermata: l’attesa ricomincia');
  }
});
function efResisti(){ efFerma(); efSalvaRisposte('ha tenuto la Modalità severa durante l’attesa'); efVai('cuore'); }

async function efSpegni(conPass){
  let ok = false, msg = '';
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.emergencyDisableStrict){
    try{ const r = await NATIVE.emergencyDisableStrict({ usaPass: !!conPass }); ok = !!(r && r.disabled); msg = (r && r.message) || ''; }catch(e){ ok = false; msg = (e && e.message) || ''; }
  } else if (typeof NATIVE === 'undefined' || !NATIVE){
    try{ localStorage.removeItem('fl_sev_preview'); }catch(_){ }
    ok = true;   /* anteprima nel browser */
  }
  if (!ok){ efVai('errore', msg || 'Aggiorna l’app e riprova.'); return; }
  efContoSegna(conPass);
  try{ if (typeof sevLoadState === 'function') await sevLoadState(); }catch(_){ }
  try{ if (typeof sevRenderLevel === 'function') sevRenderLevel(0); if (typeof sevSyncTab === 'function') sevSyncTab(); }catch(_){ }
  efVai('spenta');
}

/* ---- tieni premuto: la vibrazione cresce mentre lo tieni, come un motore che si carica ---- */
function efLegaTieni(btn){ if (btn) flTieniPremuto(btn, 2200, function(){ efSpegni(true); }); }
/** Pulsante da tenere premuto, con la barra che si riempie e la vibrazione a ogni passo. Usato anche dal pass d'emergenza. */
function flTieniPremuto(btn, durata, fatto){
  let t0 = 0, giro = 0, ultimo = 0;
  const stop = function(){
    if (giro){ clearInterval(giro); giro = 0; }
    btn.classList.remove('holding'); btn.style.setProperty('--p', '0%');
  };
  const start = function(e){
    try{ e.preventDefault(); }catch(_){ }
    if (giro) return;
    t0 = Date.now(); ultimo = 0;
    btn.classList.add('holding');
    try{ flVibra(12, [90]); }catch(_){ }
    giro = setInterval(function(){
      const p = Math.min(1, (Date.now() - t0) / durata);
      btn.style.setProperty('--p', (p * 100).toFixed(1) + '%');
      /* un battito ogni 140 ms, sempre piu' forte */
      if (Date.now() - ultimo > 140){ ultimo = Date.now(); try{ flVibra(14, [Math.round(60 + 190 * p)]); }catch(_){ } }
      if (p >= 1){ stop(); try{ flVibra([40, 60, 80], [255, 255]); }catch(_){ } fatto(); }
    }, 30);
  };
  btn.addEventListener('pointerdown', start);
  btn.addEventListener('pointerup', stop);
  btn.addEventListener('pointercancel', stop);
  btn.addEventListener('pointerleave', stop);
  btn.addEventListener('contextmenu', function(e){ e.preventDefault(); });
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#s-emergenza{padding:0!important;background:linear-gradient(180deg,#0B2A5C 0%,#001E44 38%,#00132D 100%)}',
    '.ef{position:relative;min-height:100%;display:flex;flex-direction:column;padding:calc(64px + env(safe-area-inset-top,0px)) 24px calc(28px + env(safe-area-inset-bottom,0px));color:#fff;box-sizing:border-box}',
    '.ef-x{position:absolute;top:calc(12px + env(safe-area-inset-top,0px));left:12px;width:44px;height:44px;border:0;border-radius:50%;background:transparent;color:#2F9BFF;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.ef h1{margin:0;font:800 27px/1.25 var(--font-display,var(--font-body));color:#fff;text-align:center}',
    '.ef p{margin:14px auto 0;max-width:32ch;font:500 16px/1.5 var(--font-body);color:rgba(220,234,255,.82);text-align:center}',
    '.ef-centro{display:flex;flex-direction:column;align-items:center;text-align:center}.ef-alto{flex:1;justify-content:center}',
    '.ef-ico{margin-bottom:22px}.ef-piede{margin-top:auto;padding-top:28px;display:flex;flex-direction:column;gap:14px}',
    '.ef-blu,.ef-grigio,.ef-opt,.ef-tieni{width:100%;min-height:60px;border:0;border-radius:30px;font:700 17px/1.3 var(--font-body);cursor:pointer;padding:14px 22px}',
    '.ef-blu{background:linear-gradient(180deg,#2F9BFF,#0075E3);color:#fff;box-shadow:0 12px 30px rgba(0,117,227,.35)}.ef-blu:disabled{background:rgba(255,255,255,.1);color:rgba(255,255,255,.4);box-shadow:none}',
    '.ef-grigio{background:rgba(255,255,255,.1);color:#fff}',
    '.ef-link{border:0;background:transparent;color:rgba(220,234,255,.75);font:600 15px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer;padding:8px}',
    '.ef-dom{margin-bottom:30px!important}.ef-opz{display:flex;flex-direction:column;gap:14px}',
    '.ef-opt{background:rgba(255,255,255,.1);color:#fff}.ef-opt:active{background:rgba(47,155,255,.35)}',
    '.ef-volte{margin:56px 0;text-align:center;font:800 64px/1 var(--font-display,var(--font-body));color:#2F9BFF}',
    '.ef-basso b{font:800 17px var(--font-body);color:#fff}.ef-basso p{margin-top:6px}',
    '.ef-codice{margin:0 0 26px!important;max-width:none!important;font:600 italic 16px/1.55 var(--font-body)!important;color:#4FB8FF!important;word-break:break-all;text-align:center;user-select:none;-webkit-user-select:none}',
    '.ef-campo{width:100%;box-sizing:border-box;min-height:150px;border:2px solid transparent;border-radius:24px;background:rgba(255,255,255,.1);color:#fff;padding:18px;font:500 15px/1.5 var(--font-body);resize:none;outline:none}.ef-campo:focus{border-color:rgba(47,155,255,.6)}.ef-campo.ok{border-color:#2F9BFF}',
    '.ef-anello{position:relative;width:210px;height:210px;margin-bottom:26px}.ef-anello svg{display:block}.ef-anello > span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}',
    '.ef-tempo{margin-top:12px;font:800 44px/1 var(--font-body);color:#2F9BFF;font-variant-numeric:tabular-nums}',
    '.ef-cuore{flex:1;justify-content:center}.ef-cuore-ico{margin-bottom:34px;animation:efBatte 1.3s ease-in-out infinite}@keyframes efBatte{0%,100%{transform:scale(1)}15%{transform:scale(1.07)}30%{transform:scale(.98)}45%{transform:scale(1.04)}}',
    '.ef-spento{width:140px;height:140px;border-radius:50%;background:radial-gradient(circle at 50% 38%,#173A75,#0E2350 70%);box-shadow:0 0 0 2px rgba(255,255,255,.12),0 0 40px rgba(47,155,255,.25);display:flex;align-items:center;justify-content:center;margin-bottom:30px}',
    '.ef-tieni{position:relative;overflow:hidden;background:linear-gradient(180deg,#2F9BFF,#0075E3);color:#fff;box-shadow:0 12px 30px rgba(0,117,227,.35);--p:0%;user-select:none;-webkit-user-select:none;touch-action:none}',
    '.ef-tieni::before{content:"";position:absolute;inset:0;width:var(--p);background:linear-gradient(90deg,rgba(255,255,255,.18),rgba(255,255,255,.38));pointer-events:none}',
    '.ef-tieni span{position:relative}.ef-tieni.holding{transform:scale(.985)}'
  ].join('');
  document.head.appendChild(st);
})();
