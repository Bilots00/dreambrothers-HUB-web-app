/* ===========================================================================================
   LE REGOLE DEL TELEFONO VIAGGIANO DA SOLE

   «Esporta il file, portalo sul computer, importalo»: nessuno lo fa due volte, e infatti le
   parole chiave nuove restavano sul telefono. Qui, ogni volta che una regola cambia (un sito
   aggiunto, una parola, un programma, il blocco rapido acceso), il telefono scrive il suo
   backup in una riga di sistema dell'account — `fl:mobile-rules`, che gli elenchi dei backup
   nascondono — e il computer la legge ogni trenta secondi (RulesSync.cs) con la STESSA
   funzione dell'import a mano. Niente file, niente pulsanti.

   Come si accorge che una regola e' cambiata: tutte le scritture al motore passano da
   `blkNative(...)`. Si avvolge quella funzione una volta, e dopo ogni scrittura riuscita di un
   metodo che tocca le regole si programma la spedizione, tre secondi dopo l'ultima modifica
   (chi aggiunge dieci parole di fila spedisce una volta sola).
   =========================================================================================== */

const RS_SLOT = 'fl:mobile-rules';
const RS_METODI = { setRulesFull: 1, setQuickBlock: 1, saveSchedules: 1, setEnabled: 1, blockApp: 1, unblockApp: 1, setFeatureBlocks: 1 };
let RS_T = 0, RS_BUSY = false, RS_ANCORA = false;

/* LA RIGA SI CHIAMA «regole del telefono», E LA SCRIVE IL TELEFONO.
   Il computer ha anche lui `backupSave`, quindi finora scriveva pure lui in quella riga: la
   sua fotografia sostituiva quella del telefono, e alla lettura successiva il computer
   rileggeva le proprie regole credendole quelle arrivate dall'altra parte. Una riga, un
   autore. Il computer legge e basta. */
function rsCan(){
  try{
    if (!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.backupSave)) return false;
    if (typeof mwSoloWeb === 'function'){ if (mwSoloWeb()) return false; }   // questo e' il computer
    else if (typeof NATIVE.getDayReport !== 'function') return false;
    return true;
  }catch(_){ return false; }
}

function rsPubblica(){
  if (!rsCan()) return;
  clearTimeout(RS_T);
  RS_T = setTimeout(rsOra, 3000);
}

async function rsOra(){
  if (!rsCan()) return;
  if (RS_BUSY){ RS_ANCORA = true; return; }
  /* LE REGOLE DELLA SESSIONE NON SONO LE REGOLE DEL TELEFONO.
     Durante una sessione di concentrazione il motore e' in elenco consentito: «solo queste
     app, per questo tempo». Spedirlo come foto delle regole voleva dire che il computer
     leggeva «blocca tutto tranne queste» e chiudeva qualunque programma aperto — anche
     quello con cui si stava lavorando — e continuava a farlo dopo la fine della sessione,
     perche' nessuno gli mandava la foto buona. Con l'elenco consentito armato non si
     spedisce niente; si riprova fra un minuto, e la chiusura della sessione spedisce lei. */
  try{
    const cur = await blkNative('getRulesFull', {}, true);
    const inSessione = !!(cur && cur.listMode === 'allowlist')
      || (typeof FF !== 'undefined' && FF && FF.run && FF.run.mode === 'allow');
    if (inSessione){ clearTimeout(RS_T); RS_T = setTimeout(rsOra, 60000); return; }
  }catch(_){ }
  RS_BUSY = true;
  try{
    const impronta = rsImpronta();
    /* 0.9.307: se il server ha gia' rifiutato la foto intera per il peso, per un giorno si manda subito quella leggera */
    let leggera = false;
    try{ leggera = Date.now() - (+localStorage.getItem(RS_LEGGERA_KEY) || 0) < 86400000; }catch(_){ }
    let r = null;
    try{
      r = await NATIVE.backupSave({ web: rsFoto(leggera ? RS_TETTO_LEGGERO : RS_TETTO), slot: RS_SLOT, slotName: 'Regole del telefono' });
    }catch(e){
      if (leggera || !rsTroppoPesante(e)) throw e;
      try{ localStorage.setItem(RS_LEGGERA_KEY, String(Date.now())); }catch(_){ }
      r = await NATIVE.backupSave({ web: rsFoto(RS_TETTO_LEGGERO), slot: RS_SLOT, slotName: 'Regole del telefono' });
    }
    if (r && r.saved){ try{ localStorage.setItem('fl_rules_pub', String(Date.now())); localStorage.setItem(RS_IMPRONTA_KEY, impronta); localStorage.removeItem(RS_ERRORE_KEY); }catch(_){ } }
  }catch(e){
    /* il motivo resta scritto (si legge dall'Assistenza e dalle prove), e per cinque minuti non si riprova: prima un
       rifiuto del server ripartiva ogni mezzo minuto con mezzo mega di dati, per due settimane */
    try{ localStorage.setItem(RS_ERRORE_KEY, JSON.stringify({ at: Date.now(), msg: String((e && e.message) || e || '').slice(0, 200) })); }catch(_){ }
    try{ console.warn('[regole] spedizione non riuscita', e && e.message); }catch(_){ }
  }finally{
    RS_BUSY = false;
    if (RS_ANCORA){ RS_ANCORA = false; rsPubblica(); }
  }
}

/* ---------------------------------------------------------------------------------------
   IL SOGNO VIAGGIA ANCHE LUI (0.9.302)

   Andrea: dopo "Ricomincia da capo" il telefono diceva arrivo previsto 18 luglio 2028, il computer ancora 12
   giugno 2028. "Se telefono e computer erano collegati non si devono scollegare, e il computer deve seguire
   l'onboarding rifatto e tutti gli aggiornamenti del telefono."
   LA CAUSA, nel verso telefono -> computer: questa riga partiva solo quando cambiava una REGOLA (o una volta al
   giorno). Il sogno, la lettura del Genio, l'arrivo previsto, la roadmap non sono regole: l'onboarding rifatto
   restava sul telefono, e il computer (specchio-web.js) continuava a mostrare quello di prima. E siccome
   fl_rules_pub sopravvive al reset, nemmeno il giro "una volta al giorno" partiva subito.
   Adesso ogni mezzo minuto si guarda l'impronta delle chiavi del viaggio: se e' cambiata, la foto riparte (non
   durante l'onboarding: a meta' il computer vedrebbe un viaggio senza sogno).
   --------------------------------------------------------------------------------------- */
const RS_IMPRONTA_KEY = 'fl_rules_pub_impronta';
const RS_VIAGGIO = /^fl_(onboarded|reset_ultimo|oracle|estimate|partenza|eta_|orizzonti|rotta|roadmap|rm_|why|mappa_|mp_|sd$|sd_|sentiero|viaggio_opz|sogno|sogni_realizzati|lv_|nv_|modalita|gn_|user$)/;
function rsImpronta(){
  const chiavi = [];
  try{ for (let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); if (k && RS_VIAGGIO.test(k)) chiavi.push(k); } }catch(_){ }
  chiavi.sort();
  let h = 5381;
  chiavi.forEach(function(k){
    let v = ''; try{ v = localStorage.getItem(k) || ''; }catch(_){ }
    const t = k + '=' + v + ';';
    for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0;
  });
  return chiavi.length + ':' + (h >>> 0).toString(36);
}
/* ---------------------------------------------------------------------------------------
   LA FOTO CHE ARRIVA DAVVERO (0.9.307)

   Andrea: "sul telefono sono al livello 3, sul computer il badge dice 1", e la mappa del computer partiva da Lainate a
   0% con sette tappe, mentre il telefono (dopo "Ricomincia da capo") ne ha due davanti.
   LA CAUSA, letta nell'account: la riga fl:mobile-rules era ferma al 15/10 (app 0.9.264, 518.232 byte). Il server
   rifiutava ogni foto sopra i 512 KB con 413 "backup too large", e qui l'errore finiva in un console.warn: dal 15/10 il
   computer non ha piu' ricevuto niente. Ne' fl_lv_tel (il livello del telefono, 0.9.306), ne' il reset del 28/10, ne'
   la roadmap, le tappe e l'arrivo previsto del viaggio nuovo. Il tetto del server ora e' 8 MB (focuslockRoutes.ts).
   Qui, perche' non succeda piu' anche con un server vecchio o un telefono pieno:
   · la foto mette PRIMA le chiavi del viaggio (sogno, reset, livello, roadmap, tappe, arrivo), poi le altre dalla piu'
     leggera: se qualcosa resta fuori per il peso, e' una cache, mai il viaggio. Prima l'ordine era quello del
     localStorage, e nella foto del 15/10 mancava perfino fl_onboarded (il computer la scarta senza);
   · le chiavi che il computer butta comunque (swSalta: tabellone, cache dell'altro dispositivo) non viaggiano;
   · se il server dice "troppo pesante", si rimanda subito una foto leggera, sotto il tetto vecchio.
   --------------------------------------------------------------------------------------- */
const RS_TETTO = 3000000, RS_TETTO_LEGGERO = 330000;
const RS_LEGGERA_KEY = 'fl_rules_pub_leggera', RS_ERRORE_KEY = 'fl_rules_pub_err';
const RS_SEMPRE = /^fl_(regole_cache|groups|user|onboarded|reset_ultimo|lv_tel)$/;
function rsTroppoPesante(e){ return /413|too large|troppo/i.test(String((e && (e.message || e.code)) || e || '')); }
function rsFoto(tetto){
  const salta = (typeof UF_SKIP !== 'undefined' && Array.isArray(UF_SKIP)) ? UF_SKIP : [];
  const voci = [], tutte = [];
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (!k || k.indexOf('fl_') !== 0) continue;
      tutte.push(k);
      if (salta.indexOf(k) >= 0 || k.indexOf('fl_rules_pub') === 0) continue;
      try{ if (typeof swSalta === 'function' && swSalta(k)) continue; }catch(_){ }
      const v = localStorage.getItem(k);
      if (v === null || v.length > 700000) continue;
      voci.push({ k: k, v: v, p: (RS_SEMPRE.test(k) ? 0 : RS_VIAGGIO.test(k) ? 1 : 2) });
    }
  }catch(_){ }
  voci.sort(function(a, b){ return a.p - b.p || a.v.length - b.v.length; });
  const out = {};
  let tot = 0;
  voci.forEach(function(x){
    if (x.p > 0 && tot + x.v.length > tetto) return;      // le chiavi che non stanno restano fuori, le altre si provano lo stesso
    out[x.k] = x.v; tot += x.v.length;
  });
  /* 0.9.302: l'elenco di TUTTE le chiavi del telefono, anche quelle rimaste fuori dalla foto per il peso. Dopo un
     "Ricomincia da capo" il computer toglie le chiavi che sul telefono non ci sono piu' (specchio-web.js), e una
     chiave lasciata fuori solo perche' pesante non deve sembrare cancellata. */
  out.fl_specchio_chiavi = JSON.stringify(tutte);
  return out;
}

function rsGuardaViaggio(){
  try{
    if (!rsCan() || document.hidden) return;
    if (localStorage.getItem('fl_onboarded') !== '1') return;
    /* dopo un rifiuto si aspettano cinque minuti (il motivo e' in fl_rules_pub_err) */
    try{ const er = JSON.parse(localStorage.getItem(RS_ERRORE_KEY) || 'null'); if (er && Date.now() - (+er.at || 0) < 300000) return; }catch(_){ }
    /* al massimo una foto ogni due minuti: chi sta sistemando la roadmap non spedisce a ogni tocco */
    if (Date.now() - (+localStorage.getItem('fl_rules_pub') || 0) < 120000) return;
    if (rsImpronta() !== (localStorage.getItem(RS_IMPRONTA_KEY) || '')) rsPubblica();
  }catch(_){ }
}
setTimeout(rsGuardaViaggio, 8000);
setInterval(rsGuardaViaggio, 30000);

/* L'avvolgimento: una volta sola, appena blocco.js ha definito blkNative. */
(function rsAggancia(){
  if (typeof blkNative !== 'function' || blkNative.__rs) return;
  const orig = blkNative;
  const wrapped = async function(method, args, silent){
    const r = await orig(method, args, silent);
    if (r !== null && RS_METODI[method]) rsPubblica();
    return r;
  };
  wrapped.__rs = true;
  blkNative = wrapped;
})();

/* All'avvio, se l'ultima spedizione e' vecchia di un giorno (o non c'e' mai stata): cosi'
   anche chi aggiorna l'app trova il computer allineato senza toccare niente. */
setTimeout(function(){
  let t = 0; try{ t = +localStorage.getItem('fl_rules_pub') || 0; }catch(_){ }
  /* Una volta, con questa versione: la foto buona parte subito, cosi' un computer rimasto con
     le regole di una sessione le vede sostituite alla prima apertura dell'app. */
  let v2 = false; try{ v2 = localStorage.getItem('fl_rules_pub_v2') === '1'; }catch(_){ }
  if (!v2){ try{ localStorage.setItem('fl_rules_pub_v2', '1'); }catch(_){ } rsPubblica(); return; }
  if (Date.now() - t > 86400000) rsPubblica();
}, 15000);
