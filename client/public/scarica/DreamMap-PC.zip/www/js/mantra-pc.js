/* ---------------------------------------------------------------------------------------
   IL MANTRA SUL COMPUTER

   Sul telefono il mantra lo fa comparire il servizio di blocco, ogni tot minuti. Sul computer
   nessuno lo faceva: la pagina Personalizza diceva «disponibile solo nell'app installata» e
   la frase restava una cosa del telefono. Ma la ripetizione e' la sola cosa che conta, e le
   ore davanti al computer sono la parte piu' lunga della giornata.

   COME FUNZIONA QUI. Questa pagina gira dentro a FocusLock per Windows tutto il giorno (e' la
   vista telefono, anche quando la finestra e' chiusa). Ogni mezzo minuto guarda l'ora: se e'
   passato il tempo scelto, chiede al programma di mostrare la card e suonare. La card la
   disegna il C# (MantraFlash), sopra a qualunque cosa ci sia a schermo.

   LA STESSA FRASE DEL TELEFONO. Il mantra vive nel «perche'» (fl_why), e la cadenza in
   fl_mantra_min: due chiavi che il telefono pubblica e il computer riceve nello specchio.
   Quindi senza toccare niente qui compare la stessa frase, alla stessa cadenza. Se sul
   computer si sceglie un'altra cadenza, resta in una chiave sua (fl_pc_mantra_min), che lo
   specchio non sovrascrive perche' sul telefono non esiste.
   --------------------------------------------------------------------------------------- */

const MPC_KEY = 'fl_pc_mantra_at';

function mpcDesktop(){
  try{ return !!(window.chrome && window.chrome.webview) && typeof NATIVE !== 'undefined' && NATIVE && !!NATIVE.showMantra; }
  catch(_){ return false; }
}

/* Le ore di silenzio scelte in Personalizza valgono anche qui. */
function mpcSilenzio(){
  try{
    if (typeof SETTINGS === 'undefined' || !SETTINGS || !SETTINGS.mantraQuietOn) return false;
    const da = +SETTINGS.mantraQuietFrom, a = +SETTINGS.mantraQuietTo;
    if (isNaN(da) || isNaN(a)) return false;
    const h = new Date().getHours();
    return da <= a ? (h >= da && h < a) : (h >= da || h < a);
  }catch(_){ return false; }
}

function mpcTick(){
  if (!mpcDesktop()) return;
  const every = (typeof mantraEveryMin === 'function') ? mantraEveryMin() : 0;
  const testo = (typeof whyMantra === 'function') ? whyMantra() : '';
  if (!every || !testo || mpcSilenzio()) return;
  let ultimo = 0;
  try{ ultimo = +localStorage.getItem(MPC_KEY) || 0; }catch(_){ }
  if (Date.now() - ultimo < every * 60000) return;
  try{ localStorage.setItem(MPC_KEY, String(Date.now())); }catch(_){ }
  mpcMostra(testo);
}

async function mpcMostra(testo){
  const suona = !(typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.mantraChime === false);
  try{ await NATIVE.showMantra({ text: testo, chime: suona }); }catch(_){ }
}

setTimeout(mpcTick, 20000);
setInterval(mpcTick, 30000);
