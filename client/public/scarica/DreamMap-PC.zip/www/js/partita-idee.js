/* ===========================================================================================
   LA PARTITA DELLE IDEE (0.9.241, solo admin) — una partita dedicata a una cosa sola: aggiungere
   cose nuove contro tagliare e semplificare. Vive in cima a «Mappa · pianifica tu», prima del
   foglio (#mppFoglio), e la vede solo chi ha creato l'app (flAdmin(), admin.js).

   Tre diapositive che scorrono di lato:
     1. La partita di oggi: vecchio te contro nuovo te, con le ultime azioni che hanno segnato.
     2. Gli ultimi giorni: vinti, persi e pari, su una settimana o su un mese.
     3. Come si segna: una riga per parte, da raccontare a chi non conosce l'app.

   Tutto si calcola dai dati che l'app ha gia' in locale (piPunti): questo file non scrive niente
   e non tocca il tabellone della partita grande (match.js).

   0.9.299: la partita delle idee si vede SOLO nelle statistiche della partita (partita-stats.js, scheda
   "Partita delle idee", solo admin). Le schede di questo file non si disegnano piu' (PI_SPENTA).
   =========================================================================================== */

const PI = { i: 0, arco: 7, x0: null, dx: 0 };
/* 0.9.285, Andrea: la partita delle idee e' un blocco che si aggiunge anche a START, alla Roadmap e al Report.
   Ogni posto ha la sua scheda (un id suo) e la sua diapositiva; il disegno e' lo stesso. */
const PI_POSTI = {
  piCard:       { tab: 'tab-mappa' },
  piCardRotta:  { tab: 'tab-mappa' },
  piCardStart:  { tab: 'tab-sveglia' },
  piCardReport: { tab: 'tab-insights' }
};
const PI_S = {};
function piSt(cid){ if (!PI_S[cid]) PI_S[cid] = { i: 0, arco: 7 }; return PI_S[cid]; }

function piJSON(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function piGiorno(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function piNorm(t){ return String(t || '').replace(/^[☐☑•\-]\s*/, '').trim().toLowerCase().replace(/\s+/g, ' '); }
function piPulito(t){ return String(t || '').replace(/^[☐☑•\-]\s*/, '').trim(); }
function piEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }

/** Legge una volta sola tutte le fonti: per trenta giorni di grafico non si rilegge localStorage trenta volte. */
function piDati(){
  return {
    deviazioni: piJSON('fl_deviazioni', []) || [],
    partite: piJSON('fl_match_hist', []) || [],
    orizzonti: piJSON('fl_orizzonti', {}) || {},
    fatte: piJSON('fl_notes_done', []) || [],
    esercizi: (piJSON('fl_esercizi', {}) || {}).storia || [],
    caveau: piJSON('fl_caveau', []) || []
  };
}

/**
 * I punti della partita delle idee in un giorno (dayKey 'AAAA-MM-GG').
 * Restituisce { vecchio, nuovo, voci: [{ chi: 'old'|'new', tipo, t, at }] }, voci dalla piu' recente.
 */
function piPunti(dayKey, dati){
  const D = dati || piDati();
  const voci = [];
  const delGiorno = function(t){ return !!t && piGiorno(+t) === dayKey; };

  /* ---- VECCHIO TE: ogni cosa nuova aggiunta fuori rotta ----
     A) fl_deviazioni (arbitro-claude.js, acDeviazioni): il registro dei punti «fuori rotta» che
        l'hook di Claude Code sul computer deposita nella riga fl:arbitro dell'account, ogni volta
        che una richiesta aggiunge lavoro che la roadmap non prevede. Gli annullati al VAR ne
        escono gia' (acAnnulla), quindi qui c'e' solo quello che vale. { id, at, motivo }        */
  const fuori = [];
  D.deviazioni.forEach(function(e){
    if (!e || !delGiorno(e.at)) return;
    fuori.push(+e.at);
    voci.push({ chi: 'old', tipo: 'fuori', t: String(e.motivo || 'aggiunta non prevista'), at: +e.at });
  });
  /* B) fl_match_hist (match.js, mgLog): i punti al vecchio te con motivo «fuori rotta: ...» scritti
        prima che esistesse il registro, piu' quelli che il telefono segna da solo quando tieni
        righe nuove nel foglio con la priorita' ancora aperta (ulisse.js, ulFuoriTengo). Come in
        rotta-oggi.js (roDeviazioni), un evento a meno di cinque minuti da uno del registro e' lo
        stesso punto e non si conta due volte; gli eventi stornati non contano.                 */
  D.partite.forEach(function(g){
    if (!g || g.day !== dayKey) return;
    (g.eventi || []).forEach(function(e){
      if (!e || e.chi !== 'old' || e.stornato) return;
      const m = String(e.motivo || '');
      const tieni = /^Cose nuove aggiunte a oggi/i.test(m);
      if (!/^fuori rotta/i.test(m) && !tieni) return;
      if (fuori.some(function(at){ return Math.abs(at - (+e.at || 0)) < 5 * 60000; })) return;
      fuori.push(+e.at || 0);
      voci.push({ chi: 'old', tipo: 'fuori', t: tieni ? 'Righe nuove tenute nel foglio con la priorità aperta' : m.replace(/^fuori rotta:\s*/i, '').replace(/\s*\(dal [^)]*\)\s*$/, ''), at: +e.at || 0 });
    });
  });

  /* ---- NUOVO TE: lavoro sulla rotta, tagli, idee chiuse nel caveau ----
     C) fl_orizzonti (orizzonti.js, ozAnello): i passi della roadmap spuntati in quel giorno,
        { t, fatto, il } su ogni livello (oggi, settimana, mese, anno, cinque anni...).           */
  const sullaRotta = {};
  const tuttiIPassi = {};
  Object.keys(D.orizzonti).forEach(function(k){
    const a = D.orizzonti[k]; if (!a || !Array.isArray(a.passi)) return;
    a.passi.forEach(function(p){
      if (!p || !p.t) return;
      tuttiIPassi[piNorm(p.t)] = piPulito(p.t);
      if (p.fatto && p.il === dayKey) sullaRotta[piNorm(p.t)] = { t: piPulito(p.t), at: 0 };
    });
  });
  /* D) fl_notes_done (start.js, stRowDone): le righe spuntate nel foglio di START o nella Mappa
        quel giorno, se il testo e' un passo della roadmap. Di solito la spunta chiude anche il
        passo (e allora e' gia' in C): la chiave comune evita il doppio punto.                    */
  D.fatte.forEach(function(d){
    if (!d || d.day !== dayKey) return;
    const n = piNorm(d.text);
    if (!tuttiIPassi[n]) return;
    if (sullaRotta[n]){ if (!sullaRotta[n].at) sullaRotta[n].at = +d.at || 0; return; }
    sullaRotta[n] = { t: tuttiIPassi[n], at: +d.at || 0 };
  });
  Object.keys(sullaRotta).forEach(function(n){ voci.push({ chi: 'new', tipo: 'rotta', t: sullaRotta[n].t, at: sullaRotta[n].at }); });

  /* E) fl_esercizi.storia (esercizi.js, esTagliaVia): ogni voce tagliata nell'esercizio Taglia,
        { tipo: 'taglia', risposte: [{ azione: 'tagliata', voce, at }] }.                        */
  D.esercizi.forEach(function(s){
    if (!s || s.tipo !== 'taglia') return;
    (s.risposte || []).forEach(function(r){
      if (!r || r.azione !== 'tagliata' || !delGiorno(r.at)) return;
      voci.push({ chi: 'new', tipo: 'taglia', t: String(r.voce || ''), at: +r.at });
    });
  });
  /* F) fl_caveau (ulisse.js): { t, at, stato, decisaAt }.
        - ogni idea messa nel caveau quel giorno (at): e' un'idea che non e' entrata nel foglio;
        - ogni idea tagliata nel Taglia del caveau quel giorno (stato 'tagliata', decisaAt).     */
  D.caveau.forEach(function(x){
    if (!x) return;
    if (delGiorno(x.at)) voci.push({ chi: 'new', tipo: 'caveau', t: String(x.t || ''), at: +x.at });
    if (x.stato === 'tagliata' && delGiorno(x.decisaAt)) voci.push({ chi: 'new', tipo: 'taglia', t: String(x.t || ''), at: +x.decisaAt });
  });

  voci.sort(function(a, b){ return (b.at || 0) - (a.at || 0); });
  return {
    vecchio: voci.filter(function(v){ return v.chi === 'old'; }).length,
    nuovo: voci.filter(function(v){ return v.chi === 'new'; }).length,
    voci: voci
  };
}

/* ---------------------------------------------------------------------------------------
   IL DISEGNO
   --------------------------------------------------------------------------------------- */
const PI_ICO = {
  fuori: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  rotta: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  taglia: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12"/></svg>',
  caveau: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>',
  admin: '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5c0 4.5-3 8.2-7 9.5-4-1.3-7-5-7-9.5V6z"/></svg>'
};
const PI_TIPO = { fuori: 'Fuori rotta', rotta: 'Passo della roadmap', taglia: 'Tagliata', caveau: 'Nel caveau' };

function piOra(t){ const d = new Date(t || 0); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
/* Come il tabellone di una partita di calcio: le due squadre, il risultato, e sotto la cronaca
   (a sinistra le azioni del vecchio te, a destra quelle del nuovo te, con l'ora). */
function piSlideOggi(){
  const p = piPunti(piGiorno(Date.now()));
  const esito = p.nuovo > p.vecchio ? 'Sta vincendo il nuovo te' : p.nuovo < p.vecchio ? 'Sta vincendo il vecchio te' : (p.nuovo ? 'Per ora siete pari' : 'Nessun punto, per ora');
  const cronaca = p.voci.slice(0, 6).map(function(v){
    const riga = '<span class="pi-ev-ico">' + PI_ICO[v.tipo] + '</span><span class="pi-ev-t"><b>' + PI_TIPO[v.tipo] + '</b>' + piEsc(v.t.slice(0, 70)) + '</span>';
    return '<li class="pi-ev ' + v.chi + '"><span class="pi-ev-lato">' + (v.chi === 'old' ? riga : '') + '</span><span class="pi-ev-ora">' + piOra(v.at) + '</span><span class="pi-ev-lato">' + (v.chi === 'new' ? riga : '') + '</span></li>';
  }).join('');
  return '<p class="pi-kick">La partita delle idee · oggi</p>'
    + '<div class="pi-tab">'
    +   '<div class="pi-sq old"><span class="pi-stemma">😈</span><b>Vecchio te</b><small>aggiunge</small></div>'
    +   '<div class="pi-ris"><b class="o">' + p.vecchio + '</b><i>-</i><b class="n">' + p.nuovo + '</b></div>'
    +   '<div class="pi-sq new"><span class="pi-stemma">🚀</span><b>Nuovo te</b><small>taglia e fa</small></div>'
    + '</div>'
    + '<p class="pi-esito">' + esito + '</p>'
    + (cronaca ? '<ul class="pi-cron">' + cronaca + '</ul>' : '<p class="pi-vuoto">Quando tagli un\'idea, la metti nel caveau o chiudi un passo della roadmap, il punto compare qui.</p>');
}

/* Come i "precedenti" fra due squadre: vinte, pari e perse, la barra dei punti, e la forma
   giorno per giorno (un pallino per giorno, il piu' recente a destra). */
function piSlideGiorni(cid){
  const D = piDati();
  const n = piSt(cid || 'piCard').arco;
  const C = JSON.stringify(cid || 'piCard').replace(/"/g, '&quot;');
  const giorni = [];
  for (let k = n - 1; k >= 0; k--){
    const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - k);
    const p = piPunti(piGiorno(d.getTime()), D);
    giorni.push({ d: d, o: p.vecchio, n: p.nuovo });
  }
  const vinti = giorni.filter(function(g){ return g.n > g.o; }).length;
  const persi = giorni.filter(function(g){ return g.n < g.o; }).length;
  const pari = n - vinti - persi;
  const totO = giorni.reduce(function(a, g){ return a + g.o; }, 0), totN = giorni.reduce(function(a, g){ return a + g.n; }, 0);
  const tot = Math.max(1, totO + totN), quotaN = Math.round(totN / tot * 100);
  const pallini = giorni.map(function(g, i){
    const k = g.n > g.o ? 'v' : g.n < g.o ? 'p' : 'x';
    const lettera = k === 'v' ? 'V' : k === 'p' ? 'P' : '=';
    const giorno = g.d.toLocaleDateString('it-IT', { weekday: 'short' }).slice(0, 3);
    return '<span class="pi-f ' + k + '" title="' + g.d.toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }) + '"><i>' + lettera + '</i>' + (n === 7 ? '<small>' + (i === n - 1 ? 'oggi' : giorno) + '</small>' : '') + '</span>';
  }).join('');
  return '<p class="pi-kick">Gli ultimi ' + (n === 7 ? '7 giorni' : '30 giorni') + '</p>'
    + '<div class="pi-seg" role="tablist"><button type="button" class="' + (n === 7 ? 'on' : '') + '" onclick="piArco(7,' + C + ')">Settimana</button><button type="button" class="' + (n === 30 ? 'on' : '') + '" onclick="piArco(30,' + C + ')">Mese</button></div>'
    + '<div class="pi-sfida"><span class="old"><i>😈</i>Vecchio te</span><b>contro</b><span class="new">Nuovo te<i>🚀</i></span></div>'
    + '<div class="pi-h2h">'
    +   '<div class="n"><b>' + vinti + '</b><small>Giorni vinti</small></div>'
    +   '<div class="x"><b>' + pari + '</b><small>Pari</small></div>'
    +   '<div class="o"><b>' + persi + '</b><small>Giorni persi</small></div>'
    + '</div>'
    + '<div class="pi-stat"><div class="pi-stat-n"><span class="o">' + totO + '</span><small>Punti in totale</small><span class="n">' + totN + '</span></div>'
    +   '<div class="pi-stat-bar"><i class="o" style="width:' + (100 - quotaN) + '%"></i><i class="n" style="width:' + quotaN + '%"></i></div>'
    +   '<div class="pi-stat-l"><span>😈 Vecchio te</span><span>Nuovo te 🚀</span></div></div>'
    + '<p class="pi-sub">Giorno per giorno</p>'
    + '<div class="pi-forma' + (n === 30 ? ' mese' : '') + '">' + pallini + '</div>'
    + '<div class="pi-leg"><span><i class="v"></i>Vinto</span><span><i class="x"></i>Pari</span><span><i class="p"></i>Perso</span></div>';
}

function piSlideRegole(){
  return '<p class="pi-kick">Come si segna</p>'
    + '<div class="pi-regola old"><span class="pi-stemma">😈</span><p><b>Un punto al vecchio te</b>ogni volta che aggiungi una cosa fuori rotta: una funzione, una pagina, un\'idea che la roadmap non prevede.</p></div>'
    + '<div class="pi-regola new"><span class="pi-stemma">🚀</span><p><b>Un punto al nuovo te</b>per ogni passo della roadmap chiuso, per ogni idea tagliata e per ogni idea messa nel caveau invece che nel foglio.</p></div>'
    + '<p class="pi-nota">La giornata la vince chi toglie più di quanto aggiunge.</p>';
}

function piHtml(cid){
  cid = cid || 'piCard';
  const st = piSt(cid);
  const C = JSON.stringify(cid).replace(/"/g, '&quot;');
  const slides = [piSlideOggi(), piSlideGiorni(cid), piSlideRegole()];
  return '<div class="pi-top"><span class="pi-badge">' + PI_ICO.admin + 'Solo per te</span></div>'
    + '<div class="pi-vista"><div class="pi-track" id="' + cid + 'Track" style="transform:translateX(' + (-st.i * 100) + '%)">'
    + slides.map(function(s, i){ return '<section class="pi-slide" aria-hidden="' + (i !== st.i) + '">' + s + '</section>'; }).join('')
    + '</div></div>'
    + '<div class="pi-dots">' + slides.map(function(_, i){ return '<button type="button" class="' + (i === st.i ? 'on' : '') + '" aria-label="Diapositiva ' + (i + 1) + '" onclick="piVai(' + i + ',' + C + ')"></button>'; }).join('') + '</div>';
}

function piVai(i, cid){
  cid = cid || 'piCard';
  const st = piSt(cid);
  st.i = Math.max(0, Math.min(2, i));
  const tr = document.getElementById(cid + 'Track');
  if (tr){ tr.style.transition = ''; tr.style.transform = 'translateX(' + (-st.i * 100) + '%)'; }
  document.querySelectorAll('#' + cid + ' .pi-dots button').forEach(function(b, k){ b.classList.toggle('on', k === st.i); });
  document.querySelectorAll('#' + cid + ' .pi-slide').forEach(function(s, k){ s.setAttribute('aria-hidden', String(k !== st.i)); });
  piAltezza(cid);
}
/* la scheda prende l'altezza della diapositiva che si vede: niente vuoto sotto al grafico */
function piAltezza(cid){
  cid = cid || 'piCard';
  const vista = document.querySelector('#' + cid + ' .pi-vista'), s = document.querySelectorAll('#' + cid + ' .pi-slide')[piSt(cid).i];
  if (vista && s && s.offsetHeight) vista.style.height = s.offsetHeight + 'px';
}
function piArco(n, cid){ piSt(cid || 'piCard').arco = n === 30 ? 30 : 7; piPaint(); }

/* lo scorrimento col dito: la diapositiva segue il dito, e oltre un quinto della larghezza cambia */
function piSwipe(card){
  const vista = card.querySelector('.pi-vista'); if (!vista || vista._pi) return;
  vista._pi = 1;
  const cid = card.id;
  vista.addEventListener('touchstart', function(e){ PI.x0 = e.touches[0].clientX; PI.y0 = e.touches[0].clientY; PI.dx = 0; PI.lato = null; }, { passive: true });
  vista.addEventListener('touchmove', function(e){
    if (PI.x0 == null) return;
    const dx = e.touches[0].clientX - PI.x0, dy = e.touches[0].clientY - PI.y0;
    if (PI.lato == null && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) PI.lato = Math.abs(dx) > Math.abs(dy);
    if (!PI.lato) return;
    e.stopPropagation();
    PI.dx = dx;
    const tr = document.getElementById(cid + 'Track'); if (!tr) return;
    tr.style.transition = 'none';
    tr.style.transform = 'translateX(calc(' + (-piSt(cid).i * 100) + '% + ' + dx + 'px))';
  }, { passive: true });
  vista.addEventListener('touchend', function(e){
    if (PI.x0 == null) return;
    if (PI.lato) e.stopPropagation();
    const w = vista.offsetWidth || 300;
    let i = piSt(cid).i;
    if (PI.lato && PI.dx < -w / 5) i++; else if (PI.lato && PI.dx > w / 5) i--;
    PI.x0 = null; PI.dx = 0;
    piVai(i, cid);
  });
}

function piVisibile(){
  let v = 'mia'; try{ if (typeof mppVistaCur === 'function') v = mppVistaCur(); }catch(_){ }
  const a = document.getElementById('piCard'); if (a) a.classList.toggle('mpp-via', v !== 'mia');
  const b = document.getElementById('piCardRotta'); if (b) b.classList.toggle('mpp-via', v === 'mia');
}

/* dove entra la scheda la prima volta; poi l'ordine lo decide Personalizza (start-costruisci.js) */
function piCasa(cid){
  if (cid === 'piCard'){
    const tab = document.getElementById('tab-mappa'); if (!tab) return null;
    const fo = document.getElementById('mppFoglio');
    const rv = document.getElementById('mppRevMia');
    return { dentro: tab, prima: (rv && rv.parentElement === tab && rv.nextElementSibling === fo) ? rv : (fo && fo.parentElement === tab ? fo : tab.firstChild), pag: 'mappa-mia' };
  }
  if (cid === 'piCardRotta'){
    const tab = document.getElementById('tab-mappa'); if (!tab) return null;
    const se = document.getElementById('mppSentiero');
    return { dentro: tab, prima: se && se.parentElement === tab ? se : null, pag: 'mappa-rotta' };
  }
  if (cid === 'piCardStart'){
    const tab = document.getElementById('tab-sveglia'); if (!tab) return null;
    const fo = document.getElementById('stFocus');
    return { dentro: tab, prima: fo && fo.parentElement === tab ? fo : null, pag: 'start' };
  }
  if (cid === 'piCardReport'){
    const body = document.getElementById('insBody'); if (!body) return null;
    return { dentro: body, prima: body.firstChild, pag: 'report' };
  }
  return null;
}
/* 0.9.299, Andrea: "la partita delle idee la togli da tutte le altre schede e pagine e la mostri SOLO dentro la schermata
   delle statistiche della partita". Da qui in poi le schede in START, Mappa, Roadmap e Report non si disegnano piu':
   se ne e' rimasta una nella pagina, si toglie. I calcoli (piPunti, piDati) restano e li usa partita-stats.js; i dati
   salvati non si toccano. Il vecchio disegno resta qui sotto, spento, se mai servisse di nuovo. */
const PI_SPENTA = true;
function piPaintUno(cid){
  const admin = (typeof flAdmin === 'function' && flAdmin());
  let card = document.getElementById(cid);
  const casa = piCasa(cid);
  if (PI_SPENTA || !admin || !casa){ if (card) card.remove(); return; }
  if (!card){ card = document.createElement('div'); card.id = cid; card.className = 'pi-card'; }
  if (card.parentElement !== casa.dentro){
    casa.dentro.insertBefore(card, casa.prima && casa.prima.parentElement === casa.dentro ? casa.prima : null);
    try{ if (typeof scsOrdinaBlocchi === 'function') setTimeout(function(){ scsOrdinaBlocchi(casa.pag); }, 0); }catch(_){ }
  }
  card.innerHTML = piHtml(cid);
  piSwipe(card);
  piAltezza(cid);
}
function piPaint(){
  Object.keys(PI_POSTI).forEach(function(cid){ try{ piPaintUno(cid); }catch(_){ } });
  piVisibile();
}

/* si aggancia al disegno della Mappa come gli altri pezzi (mappa-note.js, revisione.js) */
(function(){
  if (typeof mppPaint === 'function'){ const v = mppPaint; window.mppPaint = mppPaint = function(){ const r = v.apply(this, arguments); try{ piPaint(); }catch(_){ } return r; }; }
  if (typeof mppApplicaVista === 'function'){ const a = mppApplicaVista; window.mppApplicaVista = mppApplicaVista = function(){ const r = a.apply(this, arguments); try{ piVisibile(); }catch(_){ } return r; }; }
  ['fl:admin', 'fl:deviazione', 'fl:spunta', 'fl:caveau', 'fl:regole'].forEach(function(ev){ document.addEventListener(ev, function(){ try{ piPaint(); }catch(_){ } }); });
  /* START e il Report si disegnano quando li apri */
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia' || e.detail === 'insights' || e.detail === 'mappa') setTimeout(function(){ try{ piPaint(); }catch(_){ } }, 450); });
})();

(function(){
  const css = [
    /* da bordo a bordo del telefono: --bleed e' lo spazio fra il contenuto e il bordo (blkhero.js,
       flSetBleed). Con 50vw sul PC la scheda usciva dal telefono disegnato (0.9.252). */
    '#tab-mappa>.pi-card{width:auto!important;max-width:none!important;margin-left:calc(-1 * var(--bleed, 18px))!important;margin-right:calc(-1 * var(--bleed, 18px))!important;border-radius:0!important}',
    /* 0.9.285: in START la stessa scheda da bordo a bordo; nel Report resta dentro ai margini della pagina, con gli angoli tondi */
    '#tab-sveglia>.pi-card{width:auto!important;max-width:none!important;margin-left:calc(-1 * var(--bleed, 18px))!important;margin-right:calc(-1 * var(--bleed, 18px))!important;border-radius:0!important}',
    '#insBody>.pi-card{border-radius:22px;margin:4px 0 18px}',
    '.pi-sfida{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0 0 12px;font:800 14px var(--font-body);color:#fff}.pi-sfida span{display:flex;align-items:center;gap:6px}.pi-sfida i{font-style:normal;font-size:26px}.pi-sfida b{font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#9FB8E6}',
    '.pi-card{margin:14px 0 18px;padding:16px 0 14px;background:radial-gradient(120% 90% at 50% 0%,#1E3366,#0F2041 70%);color:#fff;overflow:hidden}',
    '.pi-top{display:flex;justify-content:center;padding:0 16px}',
    '.pi-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:99px;background:#BCE0FF;color:#14234A;font:800 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase}',
    '.pi-vista{overflow:hidden;touch-action:pan-y;transition:height .3s ease}',
    '.pi-track{display:flex;align-items:flex-start;transition:transform .35s cubic-bezier(.2,.8,.2,1);will-change:transform}',
    '.pi-slide{flex:0 0 100%;box-sizing:border-box;padding:10px 18px 4px;min-width:0}',
    '.pi-kick{margin:6px 0 14px;text-align:center;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#9FB8E6}',
    '.pi-tab{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:6px}',
    '.pi-sq{display:flex;flex-direction:column;align-items:center;text-align:center;gap:4px}.pi-sq b{font:800 15px var(--font-display);color:#fff}.pi-sq small{font:600 12px var(--font-body);color:#B9C9E8}',
    '.pi-stemma{width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;flex:none;font-size:32px;line-height:1}.pi-regola .pi-stemma{width:44px;height:44px;font-size:24px}',
    '.old .pi-stemma{background:#E63946;box-shadow:0 0 0 4px rgba(230,57,70,.25)}.new .pi-stemma{background:#0075E3;box-shadow:0 0 0 4px rgba(0,117,227,.3)}',
    '.pi-ris{display:flex;align-items:center;gap:8px;padding:8px 14px;border-radius:16px;background:rgba(255,255,255,.08)}',
    '.pi-ris b{font:900 46px/1 var(--font-display)}.pi-ris b.o{color:#FF6B76}.pi-ris b.n{color:#5AAEFF}.pi-ris i{font:800 26px var(--font-display);font-style:normal;color:#6F86B3}',
    '.pi-esito{margin:14px 0 10px;text-align:center;font:800 15px var(--font-body);color:#8CC6FF}',
    '.pi-cron{list-style:none;margin:0;padding:10px 0 0;border-top:1px solid rgba(255,255,255,.12);display:flex;flex-direction:column;gap:10px}',
    '.pi-ev{display:grid;grid-template-columns:1fr 46px 1fr;align-items:center;gap:6px}',
    '.pi-ev-ora{text-align:center;font:800 12px var(--font-body);color:#9FB8E6;background:rgba(255,255,255,.08);border-radius:99px;padding:3px 0}',
    '.pi-ev-lato{display:flex;align-items:center;gap:7px;min-width:0}.pi-ev.old .pi-ev-lato:first-child{flex-direction:row-reverse;text-align:right}',
    '.pi-ev-ico{flex:none;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff}.pi-ev-ico svg{width:13px;height:13px}',
    '.pi-ev.old .pi-ev-ico{background:#E63946}.pi-ev.new .pi-ev-ico{background:#0075E3}',
    '.pi-ev-t{min-width:0;font:500 12.5px/1.35 var(--font-body);color:#E6EEFB;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.pi-ev-t b{display:block;font:800 11px var(--font-body);color:#fff;letter-spacing:.02em}',
    '.pi-vuoto{margin:8px 0 0;text-align:center;font:500 13.5px/1.5 var(--font-body);color:#C9D6EE}',
    '.pi-seg{display:flex;margin:0 auto 14px;max-width:240px;padding:3px;border-radius:99px;background:rgba(255,255,255,.1)}',
    '.pi-seg button{flex:1;border:0;background:transparent;padding:8px 0;border-radius:99px;font:700 13.5px var(--font-body);color:#C9D6EE;cursor:pointer}.pi-seg button.on{background:#0075E3;color:#fff}',
    '.pi-h2h{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px}.pi-h2h div{border-radius:16px;padding:10px 4px;text-align:center;background:rgba(255,255,255,.07)}',
    '.pi-h2h b{display:block;font:900 32px/1.1 var(--font-display)}.pi-h2h small{display:block;margin-top:2px;font:700 11.5px var(--font-body);color:#C9D6EE}',
    '.pi-h2h .n b{color:#5AAEFF}.pi-h2h .o b{color:#FF6B76}.pi-h2h .x b{color:#B9C6DD}',
    '.pi-stat{margin:0 0 14px}.pi-stat-n{display:flex;align-items:baseline;justify-content:space-between;font:900 20px var(--font-display)}.pi-stat-n .o{color:#FF6B76}.pi-stat-n .n{color:#5AAEFF}.pi-stat-n small{font:700 12px var(--font-body);color:#C9D6EE}',
    '.pi-stat-bar{display:flex;gap:3px;height:10px;margin:6px 0 4px}.pi-stat-bar i{display:block;border-radius:99px;min-width:4px}.pi-stat-bar i.o{background:#E63946}.pi-stat-bar i.n{background:#0075E3}',
    '.pi-stat-l{display:flex;justify-content:space-between;font:700 11.5px var(--font-body);color:#9FB8E6}',
    '.pi-sub{margin:0 0 8px;text-align:center;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#9FB8E6}',
    '.pi-forma{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;justify-items:center}.pi-forma.mese{grid-template-columns:repeat(10,1fr);gap:6px}',
    '.pi-f{display:flex;flex-direction:column;align-items:center;gap:3px}.pi-f i{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:900 13px var(--font-body);font-style:normal;color:#fff}',
    '.pi-forma.mese .pi-f i{width:24px;height:24px;font-size:11px}.pi-f small{font:700 10.5px var(--font-body);color:#9FB8E6}',
    '.pi-f.v i{background:#0075E3}.pi-f.p i{background:#E63946}.pi-f.x i{background:#4A5D85}',
    '.pi-leg{display:flex;justify-content:center;gap:14px;margin-top:12px;font:700 12px var(--font-body);color:#C9D6EE}',
    '.pi-leg i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:-1px}.pi-leg i.v{background:#0075E3}.pi-leg i.p{background:#E63946}.pi-leg i.x{background:#4A5D85}',
    '.pi-regola{display:flex;gap:12px;align-items:flex-start;margin:0 0 14px}',
    '.pi-regola p{margin:0;font:500 14px/1.5 var(--font-body);color:#E6EEFB}.pi-regola b{display:block;font:800 15px var(--font-body);color:#fff}',
    '.pi-nota{margin:4px 0 0;padding:12px;border-radius:14px;background:rgba(140,198,255,.14);border:1px solid rgba(140,198,255,.45);text-align:center;font:800 14px/1.45 var(--font-body);color:#8CC6FF}',
    '.pi-dots{display:flex;justify-content:center;gap:7px;margin-top:12px}',
    '.pi-dots button{width:7px;height:7px;padding:0;border:0;border-radius:4px;background:rgba(255,255,255,.3);cursor:pointer;transition:width .25s,background .25s}.pi-dots button.on{width:20px;background:#BCE0FF}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
