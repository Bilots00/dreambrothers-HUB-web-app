/* ===========================================================================================
   PERCHE' LA DATA SI E' SPOSTATA (0.9.221)

   Andrea: il bollino «+655 giorni rispetto a ieri» non diceva niente. L'utente non sa cosa ha
   spostato l'arrivo, e quando il Genio gli chiede «che cosa ti ha fermato?» deve fare un esame di
   coscienza tirando a indovinare. Qui l'app dice per prima cosa ha visto:
     - il registro del navigatore (eta.js, etaLog): ogni ricalcolo ha la sua causa e il suo
       scarto in giorni; si prendono quelli dopo l'ultima istantanea con cui il bollino confronta;
     - il tempo sulle app che distraggono nello stesso periodo (NATIVE.getTopApps), perche' le ore
       che mancano al sogno di solito sono finite li'.
   Lo usano il bollino della scheda Sogno (prcApri) e il rientro in rotta col Genio
   (rientro-genio.js), che parte da qui per fare domande precise invece che generiche.
   =========================================================================================== */
const PRC = { app: null, appAt: 0 };
const PRC_DISTR = ['com.zhiliaoapp.musically', 'com.ss.android.ugc.trill', 'com.instagram.android', 'com.google.android.youtube', 'com.facebook.katana', 'com.reddit.frontpage', 'com.twitter.android', 'com.snapchat.android', 'com.netflix.mediaclient', 'tv.twitch.android.app', 'com.facebook.orca', 'com.pinterest'];
function prcEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
const PRC_GIORNO = 86400000;
function prcGiorni(ms){ const g = Math.round(Math.abs(ms) / PRC_GIORNO); return g === 1 ? '1 giorno' : g + ' giorni'; }
function prcOre(h){
  const min = Math.round((+h || 0) * 60);
  if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti';
  const o = Math.floor(min / 60), m = min % 60;
  return (o === 1 ? '1 ora' : o + ' ore') + (m ? ' e ' + m + (m === 1 ? ' minuto' : ' minuti') : '');
}
/** Da quando si confronta: la fine del giorno dell'ultima istantanea (di solito: ieri a mezzanotte). */
function prcDa(){
  let ist = null; try{ ist = (typeof etaIstantaneaPrima === 'function') ? etaIstantaneaPrima() : null; }catch(_){ }
  const oggi = (typeof etaMezzanotte === 'function') ? etaMezzanotte() : new Date().setHours(0, 0, 0, 0);
  if (!ist) return { da: oggi, ist: null, giorniFa: 0 };
  /* ist.k non e' la chiave del giorno (nell'oggetto la sovrascrive il passo k): si parte da giorniFa */
  return { da: oggi - (Math.max(1, ist.giorniFa) - 1) * PRC_GIORNO, ist: ist, giorniFa: ist.giorniFa };
}
/** Una voce del registro detta da una persona, con il soggetto. */
function prcFrase(v){
  const x = v.vars || {}, t = v.testo || '';
  const quando = (typeof etaKey === 'function' && typeof etaOggiK === 'function' && etaKey(v.at) === etaOggiK()) ? 'oggi' : 'ieri';
  switch (v.tipo){
    case 'giornata': return { ico: '📉', t: 'Ieri avevi in programma ' + prcOre(x.pianOre) + ' di lavoro sul sogno e ne hai fatte ' + (x.fatteOre > 0 ? prcOre(x.fatteOre) : 'zero') + '.' };
    case 'giornate': return { ico: '📉', t: 'Negli ultimi ' + x.n + ' giorni avevi in programma ' + prcOre(x.pianOre) + ' di lavoro sul sogno e ne hai fatte ' + (x.fatteOre > 0 ? prcOre(x.fatteOre) : 'zero') + '.' };
    case 'mollata': return { ico: '⏹️', t: 'Hai interrotto la sessione' + (t ? ' su "' + t + '"' : '') + ' dopo ' + (x.min > 1 ? x.min + ' minuti' : (x.min === 1 ? 'un minuto' : 'meno di un minuto')) + '.' };
    case 'rimandata': return { ico: '🔁', t: 'Hai rimandato "' + t + '"' + (x.n > 1 ? ' per la ' + x.n + 'ª volta' : '') + '.' };
    case 'genio': return { ico: '🧞', t: 'Hai rifatto la lettura del sogno con il Genio: la strada è stata ricalcolata da capo, con il sogno e il tempo che hai scelto adesso.' };
    case 'prima': return { ico: '🧞', t: 'È la prima previsione del tuo viaggio.' };
    case 'piano': return { ico: '⚙️', t: 'Hai cambiato il tempo che dai al sogno: da ' + x.prima + ' a ' + x.dopo + ' ore a settimana.' };
    case 'roadmap': return { ico: '🗺️', t: 'Il percorso è cambiato, con dei passi aggiunti o tolti.' };
    case 'storno': return { ico: '↩️', t: 'Una task segnata come completata risulta ancora aperta: "' + t + '".' };
    case 'ritirata': case 'passoTolto': return { ico: '↩️', t: 'Hai tolto la spunta da "' + t + '".' };
    case 'stima': return { ico: '⏱️', t: 'Hai cambiato il tempo previsto per "' + t + '": adesso ' + x.min + ' minuti.' };
    case 'imprevisto': return { ico: '🗓️', t: 'Hai segnato un imprevisto' + (x.motivo ? ': ' + String(x.motivo).toLowerCase() : '') + '.' };
    case 'riga': case 'priorita': case 'passo': case 'completata': case 'sessione': case 'pc':
      return { ico: '✅', t: (quando === 'oggi' ? 'Oggi hai fatto ' : 'Hai fatto ') + (t ? '"' + t + '"' : 'un pezzo di strada') + '.' };
    /* 0.9.308: un'idea fuori rotta, un'app aperta comunque, un imprevisto detto al Genio: con la loro icona, non col pallino */
    case 'deviazione': case 'deviazioneTolta': case 'imprevistoAgente': {
      let s = ''; try{ s = (typeof etaCausaTxt === 'function') ? etaCausaTxt(v) : ''; }catch(_){ }
      return { ico: v.tipo === 'imprevistoAgente' ? '🗓️' : (v.tipo === 'deviazioneTolta' ? '↩️' : '🔀'), t: s || (t ? '"' + t + '"' : 'Un cambio di rotta.') };
    }
    default: {
      let s = ''; try{ s = (typeof etaCausaTxt === 'function') ? etaCausaTxt(v) : ''; }catch(_){ }
      return { ico: '•', t: s || 'Un ricalcolo del navigatore.' };
    }
  }
}
/**
 * Il riepilogo: quanto si e' spostata la data e le cause, le piu' pesanti prima.
 * { delta, prima, dopo, voci: [{ ico, t, delta, tipo, v }], resto, primaCausa }
 */
function prcRiepilogo(){
  const s = (typeof ETA !== 'undefined' && ETA.stato) ? ETA.stato : null;
  const p = prcDa();
  const out = { delta: 0, giorni: 0, prima: NaN, dopo: s ? s.p50 : NaN, voci: [], resto: 0, giorniFa: p.giorniFa, da: p.da };
  /* 0.9.308: il numero di testa e' quello del bollino, dalla stessa funzione (eta.js, etaSpostamento): i giorni di
     calendario fra la data di ieri e quella di oggi. delta resta lo scarto esatto in millisecondi (le cause, il Genio). */
  let sp = null; try{ sp = (typeof etaSpostamento === 'function') ? etaSpostamento() : null; }catch(_){ }
  out.nuova = !!(sp && sp.stato === 'nuova');
  if (sp && sp.stato === 'ok'){ out.prima = sp.prima; out.delta = sp.ms; out.giorni = sp.giorni; out.bollino = etaSpostamentoTxt(sp); }
  const log = (typeof etaLog === 'function') ? etaLog() : [];
  const voci = log.filter(function(v){ return v && v.at >= p.da; });
  let somma = 0;
  voci.forEach(function(v){
    const d = (v.delta === null || !isFinite(v.delta)) ? 0 : v.delta;
    somma += d;
    /* le voci senza scarto contano solo se dicono qualcosa (una giornata vuota, un rinvio) */
    if (Math.abs(d) < 3600000 && ['giornata', 'giornate', 'mollata', 'rimandata', 'genio', 'imprevisto'].indexOf(v.tipo) < 0) return;
    const f = prcFrase(v);
    out.voci.push({ ico: f.ico, t: f.t, delta: d, tipo: v.tipo, v: v });
  });
  /* le cause che hanno allontanato l'arrivo prima, poi quelle che l'hanno avvicinato */
  out.voci.sort(function(a, b){ return b.delta - a.delta; });
  out.resto = out.delta - somma;
  out.primaCausa = out.voci.filter(function(x){ return x.delta > 0 || ['giornata', 'giornate', 'mollata', 'rimandata'].indexOf(x.tipo) >= 0; })[0] || null;
  return out;
}
/** Le app che distraggono nel periodo confrontato (di solito: ieri). Torna [{ pkg, nome, min }]. */
async function prcApp(){
  if (PRC.app && Date.now() - PRC.appAt < 120000) return PRC.app;
  const p = prcDa();
  const oggi = (typeof etaMezzanotte === 'function') ? etaMezzanotte() : new Date().setHours(0, 0, 0, 0);
  const da = Math.min(p.da, oggi - PRC_GIORNO), a = p.giorniFa >= 1 ? oggi : Date.now();
  let l = [];
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps){
      const r = await NATIVE.getTopApps({ from: da, to: a, limit: 40, icons: 0 });
      let cats = {}; try{ cats = (typeof insCats === 'function') ? insCats(null) : {}; }catch(_){ }
      l = ((r && r.apps) || []).filter(function(x){ return cats[x.packageName] === 'distr' || (!cats[x.packageName] && PRC_DISTR.indexOf(x.packageName) >= 0); })
        .map(function(x){ return { pkg: x.packageName, nome: x.label || x.appName || x.packageName, min: Math.round((x.ms || 0) / 60000) }; })
        .filter(function(x){ return x.min >= 1; }).sort(function(x, y){ return y.min - x.min; }).slice(0, 3);
    }
  }catch(_){ l = []; }
  PRC.app = l; PRC.appAt = Date.now();
  return l;
}
function prcQuando(r){ return r.giorniFa > 1 ? 'Negli ultimi ' + r.giorniFa + ' giorni' : 'Ieri'; }
/** La riga del telefono: «Ieri hai passato 3 ore e 10 minuti su TikTok.» */
/* 0.9.297, Andrea: "36 minuti di WhatsApp non sono tanto, e il Genio non deve fargliene una colpa". Le app per parlare con
   le persone (famiglia, amici, lavoro) restano nel conto se l'utente le ha segnate come distrazione, ma la riga che le
   nomina compare solo oltre le 3 ore al giorno. Social e video restano dai 20 minuti. */
const PRC_CHAT = ['com.whatsapp', 'com.whatsapp.w4b', 'org.telegram.messenger', 'org.thoughtcrime.securesms', 'com.google.android.apps.messaging', 'com.samsung.android.messaging', 'com.facebook.orca', 'jp.naver.line.android', 'com.viber.voip', 'com.microsoft.teams', 'com.slack'];
function prcSoglia(r, x){
  const giorni = Math.max(1, r && r.giorniFa > 1 ? r.giorniFa : 1);
  return (PRC_CHAT.indexOf(x.pkg) >= 0 ? 180 : 20) * giorni;
}
function prcAppFrase(r, app){
  const l = (app || []).filter(function(x){ return x.min >= prcSoglia(r, x); });
  if (!l.length) return '';
  const a = l[0];
  return prcQuando(r) + ' hai passato ' + prcOre(a.min / 60) + ' su ' + a.nome + (l[1] ? ', e ' + prcOre(l[1].min / 60) + ' su ' + l[1].nome : '') + '.';
}

/* 0.9.326, Andrea: "da dove cazzo sta prendendo quelle 2 ore e mezza? A me non e' mai stato chiesto". Dalla modalita' scelta (eta-config.js, capacita)
   divisa per i giorni di lavoro, finche' non si cambia nelle Opzioni di viaggio. Ora il foglio lo dice, e porta a cambiarle. */
function prcPianoRigaHtml(){
  let p = null; try{ p = (typeof etaPiano === 'function') ? etaPiano() : null; }catch(_){ }
  if (!p || !p.nGiorni) return '';
  return '<div class="prc-r prc-piano"><span>🗓️</span><p>In programma ci sono ' + prcOre(p.oreSettimana / p.nGiorni) + ' al giorno. ' + (p.daOpzioni ? 'Le hai scelte tu.' : 'Non le hai scelte tu: è il valore di partenza della tua modalità.')
    + '<button type="button" class="prc-cambia" onclick="inSheetChiudi();if(typeof mpOpzioniApri===\'function\')mpOpzioniApri()">Cambia le tue ore</button></p></div>';
}
/* ---- il foglio del bollino ---- */
function prcApri(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (typeof inSheet !== 'function') return;
  try{ flVibra(10); }catch(_){ }
  inSheet(prcHtml(prcRiepilogo(), null));
  prcApp().then(function(app){ const el = document.getElementById('prcAppRiga'); if (!el) return; const f = prcAppFrase(prcRiepilogo(), app); if (f){ el.innerHTML = '<span>📱</span><p>' + prcEsc(f) + '</p>'; el.hidden = false; } });
}
function prcHtml(r){
  /* 0.9.308 (708.jpg): "dal 17 luglio 2028 al 17 luglio 2028: 0 giorni più in là". La testa adesso dice lo stesso numero
     del bollino (r.giorni, giorni di calendario); se la data e' la stessa di ieri il foglio lo dice, senza "si è spostata",
     e le cause mostrano cosa l'ha spinta avanti e cosa indietro. Le cause sono dette com'e' (ore se sono ore). */
  const su = r.giorni > 0, ferma = !r.nuova && isFinite(r.prima) && !r.giorni;
  let titolo = 'Perché la data si è spostata', testa;
  const quando = r.giorniFa > 1 ? 'Rispetto a ' + r.giorniFa + ' giorni fa' : 'Da ieri';
  if (r.nuova) testa = 'Da ieri hai una rotta nuova: il Genio ha riletto il sogno, e la strada è stata ricalcolata da capo. Da domani il confronto riparte da qui.';
  else if (!isFinite(r.prima)){ titolo = 'La tua data d’arrivo'; testa = 'È la prima previsione: da domani vedi di quanto si sposta rispetto al giorno prima.'; }
  else if (ferma){
    titolo = r.giorniFa > 1 ? 'La data è la stessa di ' + r.giorniFa + ' giorni fa' : 'La data è la stessa di ieri';
    testa = 'L’arrivo previsto resta il <b>' + prcEsc(etaDataTxt(r.dopo)) + '</b>.'
      + (Math.abs(r.delta) >= 3600000 ? ' Dentro la giornata si è mosso di ' + prcEsc(prcTempo(r.delta)) + (r.delta > 0 ? ' in avanti' : ' indietro') + ', ma il giorno d’arrivo non è cambiato.' : '');
  } else testa = quando + ' l’arrivo previsto è passato dal <b>' + prcEsc(etaDataTxt(r.prima)) + '</b> al <b>' + prcEsc(etaDataTxt(r.dopo)) + '</b>: ' + prcGiorni(r.giorni * PRC_GIORNO) + (su ? ' più in là.' : ' prima.')
      + (Math.abs(r.delta) < PRC_GIORNO ? ' In tutto si è mosso di ' + prcEsc(prcTempo(r.delta)) + ': abbastanza per cambiare giorno.' : '');
  const righe = r.voci.slice(0, 5).map(function(x){
    const ok = Math.abs(x.delta) >= 60000;
    return '<div class="prc-r"><span>' + x.ico + '</span><p>' + prcEsc(x.t) + '</p>' + (ok ? '<i class="' + (x.delta > 0 ? 'su' : 'giu') + '">' + (x.delta > 0 ? '+' : '−') + prcEsc(prcTempo(x.delta)) + '</i>' : '') + '</div>';
  });
  if (r.voci.some(function(x){ return x.tipo === 'giornata' || x.tipo === 'giornate'; })) righe.push(prcPianoRigaHtml());
  if (Math.abs(r.resto) >= 3600000) righe.push('<div class="prc-r"><span>⏳</span><p>' + (r.resto > 0 ? 'Il resto: il tempo che è passato senza lavoro sul sogno. Ogni giorno così sposta l’arrivo un po’ più in là.' : 'Il resto: il navigatore ha imparato meglio il tuo passo, che è più veloce di quanto pensava.') + '</p><i class="' + (r.resto > 0 ? 'su' : 'giu') + '">' + (r.resto > 0 ? '+' : '−') + prcEsc(prcTempo(r.resto)) + '</i></div>');
  if (!righe.length) righe.push('<div class="prc-r"><span>🔎</span><p>' + (ferma ? 'Da ieri non è successo niente che sposti l’arrivo.' : 'Il navigatore non ha registrato cause precise: la data si muove con i giorni che passano e con il lavoro che fai sul sogno.') + '</p></div>');
  return '<div class="prc"><b class="prc-t">' + titolo + '</b><p class="prc-p">' + testa + '</p>'
    + '<div class="prc-lista">' + righe.join('') + '<div class="prc-r" id="prcAppRiga" hidden></div></div>'
    + (su ? '<button type="button" class="cta prc-cta" onclick="inSheetChiudi();if(typeof nvRientraRicalcolo===\'function\')nvRientraRicalcolo()">Il Genio ti aiuta a rientrare</button>' : '')
    + '<button type="button" class="prc-link" onclick="inSheetChiudi();if(typeof etaTimelineApri===\'function\')etaTimelineApri()">Vedi tutti i ricalcoli</button></div>';
}
/** Uno scarto detto com'e': "9 ore", "1 giorno e 4 ore", "40 minuti" (come il Genio, rientro-genio.js). */
function prcTempo(ms){ return (typeof etaTempoParole === 'function') ? etaTempoParole(ms) : prcGiorni(ms); }
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.prc{padding:6px 4px 4px}.prc-t{display:block;text-align:center;font:800 20px/1.3 var(--font-display);color:var(--navy)}body.dark .prc-t{color:#fff}',
    '.prc-p{text-align:center;margin:8px 0 14px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}.prc-p b{color:var(--navy)}body.dark .prc-p b{color:#fff}',
    '.prc-lista{display:flex;flex-direction:column;gap:8px}.prc-r{display:flex;align-items:flex-start;gap:10px;padding:12px;border-radius:14px;background:#F2F7FD}body.dark .prc-r{background:#1C2E5A}.prc-r[hidden]{display:none}',
    '.prc-r span{font-size:20px;line-height:1.3;flex:none}.prc-r p{flex:1;margin:0;font:600 14px/1.45 var(--font-body);color:var(--navy)}body.dark .prc-r p{color:#E6EEF8}',
    '.prc-r i{flex:none;font:800 12.5px var(--font-body);font-style:normal;padding:4px 9px;border-radius:99px;white-space:nowrap}.prc-r i.su{background:#FDE3E5;color:#C62835}.prc-r i.giu{background:#DDF5EA;color:#137A50}',
    '.prc-cta{width:100%;margin-top:16px}.prc-link{display:block;width:100%;margin-top:6px;padding:12px;border:0;background:transparent;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}',
    '.nv-pill.tocca{border:0;cursor:pointer;display:inline-flex;align-items:center;gap:6px}',
    '.prc-cambia{display:block;margin-top:8px;padding:0;border:0;background:none;color:#0075E3;font:700 13.5px var(--font-body);cursor:pointer}body.dark .prc-cambia{color:#8CC6FF}.prc-r small{display:block;margin-top:3px;font:600 12px var(--font-body);color:var(--muted)}'
  ].join('\n');
  document.head.appendChild(st);
})();
