/* ===========================================================================================
   IL "NON MI PIACE" CON IL MOTIVO, COME SU CLAUDE (0.9.357)

   Andrea: "se l'utente mette non mi piace, voglio che possa motivarlo, esattamente come su Claude: il pop-up
   'invia un feedback negativo' con il menu a tendina, oppure la possibilita' di scriverlo o dirlo a voce".
   I pollici sotto le risposte c'erano gia' (gli attrezzi di dream-storia.js: Copia, Mi piace, Non mi piace,
   nella chat del tuo agente e in quella del Genio). Qui cambia cosa succede quando li tocchi (drsVoto -> agvDaDrs):
   · pollice giu': si apre il foglio "Cosa non va in questa risposta?" con il tipo di problema (facoltativo),
     il racconto con parole sue (facoltativo: il microfono della dettatura compare da solo sul campo,
     dettatura.js) e Invia. Il pollice diventa rosso solo dopo Invia; Annulla non segna niente;
   · toccare di nuovo un pollice acceso toglie il voto.

   Nella chat del TUO AGENTE il voto va al server con il numero della risposta (/api/focuslock/agent/voto,
   focuslockVoti.ts), che lo usa in tre modi:
   1. le segnalazioni di questa persona entrano nelle istruzioni del SUO agente, prima di tutto il resto
      (e le risposte con il pollice su diventano lo stile da tenere);
   2. lo stesso problema segnalato da piu' persone con lo stesso tipo di sogno diventa una regola per tutti
      (vale meno delle preferenze di ognuno);
   3. il Regista e l'agente che corregge l'app le leggono ogni notte, e Andrea riceve l'avviso su Telegram.
   Il voto resta anche nel telefono (AG.stato.voti), cosi' il pollice resta acceso quando la chat si ridisegna.
   Senza rete parte alla prossima apertura (fl_agv_coda): non si perde.
   Nella chat del GENIO il motivo viaggia con il voto di sempre (/api/focuslock/social/voto-chat).
   =========================================================================================== */
const AGV = { id: 0, modo: '', testo: '', riga: null, tipo: '', aperta: false };
/* Le voci si leggono come la risposta alla domanda del foglio: "Cosa non va in questa risposta?" */
const AGV_TIPI = [
  ['capito', 'Non ha capito cosa volevo'],
  ['inventato', 'Ha sbagliato o si è inventato qualcosa'],
  ['incompleta', 'Ha lasciato la risposta a metà'],
  ['lunga', 'Ha scritto troppo, o in modo difficile'],
  ['sogno', 'Non ha tenuto conto del mio sogno'],
  ['memoria', 'Ha dimenticato cosa gli avevo detto'],
  ['rifiuto', 'Si è rifiutato di aiutarmi'],
  ['tono', 'Mi ha parlato con un tono sbagliato'],
  ['app', 'Un pulsante o la schermata non funziona'],
  ['altro', 'Altro']
];
const AGV_TENDINA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const AGV_SPUNTA = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

function agvEsc(s){ return (typeof agEsc === 'function') ? agEsc(s) : String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function agvVoti(){
  try{ const s = agStato(); if (!s.voti || typeof s.voti !== 'object') s.voti = {}; return s.voti; }catch(_){ return {}; }
}
function agvSalva(){ try{ agSalva(); }catch(_){ } }
function agvTipoSogno(){ try{ return (typeof gnDati === 'function' && gnDati().sognoK) || 'generico'; }catch(_){ return 'generico'; } }
function agvVersione(){ try{ return (typeof APP_VERSION !== 'undefined' && APP_VERSION) ? String(APP_VERSION) : ''; }catch(_){ return ''; } }
function agvNomeTipo(k){ const t = AGV_TIPI.filter(function(x){ return x[0] === k; })[0]; return t ? t[1] : ''; }
function agvVibra(n){ try{ if (typeof flVibra === 'function') flVibra(n); }catch(_){ } }
function agvToast(t){ try{ if (typeof drsToast === 'function') drsToast(t); else if (typeof toast === 'function') toast(t); }catch(_){ } }

/** Accende (o spegne) i pollici di una riga di attrezzi: v = 1, -1 o 0 */
function agvRiga(riga, v){
  if (!riga) return;
  const b = riga.querySelectorAll('.drs-v');
  b.forEach(function(x){ x.classList.remove('on'); });
  if (v > 0 && b[0]) b[0].classList.add('on');
  if (v < 0 && b[1]) b[1].classList.add('on');
}
/** Nella chat del tuo agente, la riga di attrezzi di una risposta si disegna gia' con il voto che le hai dato (drsAgAttrezzi) */
function agvStatoRiga(html, m){
  try{
    const v = (m && m.id) ? (agvVoti()[m.id] || 0) : 0;
    if (v > 0) return html.replace('class="drs-v" aria-label="Mi piace"', 'class="drs-v on" aria-label="Mi piace"');
    if (v < 0) return html.replace('class="drs-v" aria-label="Non mi piace"', 'class="drs-v on" aria-label="Non mi piace"');
  }catch(_){ }
  return html;
}

/* ---- la coda: un voto non si perde se manca la rete ---- */
function agvCoda(){ try{ const l = JSON.parse(localStorage.getItem('fl_agv_coda') || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; } }
function agvCodaScrivi(l){ try{ localStorage.setItem('fl_agv_coda', JSON.stringify(l.slice(-30))); }catch(_){ } }
function agvCodaMetti(corpo){
  /* un voto nuovo sulla stessa risposta sostituisce quello in coda */
  const l = agvCoda().filter(function(x){ return x && x.id !== corpo.id; });
  l.push(Object.assign({ at: Date.now() }, corpo)); agvCodaScrivi(l);
}
async function agvManda(corpo){
  try{
    const r = await agApi('POST', '/api/focuslock/agent/voto', corpo);
    return !!(r && r.ok === true);
  }catch(_){ return false; }
}
let AGV_SVUOTA = false;
async function agvCodaSvuota(){
  if (AGV_SVUOTA) return; AGV_SVUOTA = true;
  try{
    const l = agvCoda(), resto = [], limite = Date.now() - 14 * 864e5;
    for (const x of l){
      if (!x || !x.id || (x.at && x.at < limite)) continue;
      const c = Object.assign({}, x); delete c.at;
      if (!(await agvManda(c))) resto.push(x);
    }
    agvCodaScrivi(resto);
  }catch(_){ }
  AGV_SVUOTA = false;
}
async function agvParti(corpo){ if (!(await agvManda(corpo))){ agvCodaMetti(corpo); return false; } return true; }

/** Il tocco su un pollice (drsVoto lo passa qui per primo). Torna true se l'ha gestito. */
function agvDaDrs(v, testo, modo, btn){
  try{
    const riga = btn && btn.parentElement;
    const era = !!(btn && btn.classList.contains('on'));
    const m = btn && btn.closest ? btn.closest('.ag-m') : null;
    const id = (modo === 'agente' && m && m.dataset) ? +m.dataset.id : 0;
    if (id > 0){
      const voti = agvVoti();
      agvVibra(8);
      if (era){ delete voti[id]; agvSalva(); agvRiga(riga, 0); agvParti({ id: id, voto: 0 }); return true; }
      if (v > 0){
        voti[id] = 1; agvSalva(); agvRiga(riga, 1);
        agvToast('Grazie: risposte così ne arrivano di più');
        agvParti({ id: id, voto: 1, tipoSogno: agvTipoSogno(), versione: agvVersione() });
        return true;
      }
      agvApri({ id: id, modo: modo, testo: testo, riga: riga });
      return true;
    }
    /* la chat del Genio: il pollice su resta quello di sempre; il pollice giu' apre il foglio */
    if (v < 0 && !era){ agvVibra(8); agvApri({ id: 0, modo: modo || 'genio', testo: testo, riga: riga }); return true; }
  }catch(_){ }
  return false;
}

/* ---- il foglio "Cosa non va in questa risposta?" ---- */
function agvApri(c){
  AGV.id = +c.id || 0; AGV.modo = c.modo || ''; AGV.testo = String(c.testo || ''); AGV.riga = c.riga || null; AGV.tipo = ''; AGV.aperta = false;
  if (typeof inSheet !== 'function') return;
  inSheet(agvFoglioHtml());
}
function agvFoglioHtml(){
  return '<div class="agv-f">'
    + '<span class="agv-f-ico" aria-hidden="true">👎</span>'
    + '<h3 class="agv-f-t">Cosa non va in questa risposta?</h3>'
    + '<p class="agv-f-l" id="agvSelL">Che tipo di problema è? <i>(facoltativo)</i></p>'
    + '<button type="button" class="agv-f-sel" id="agvSel" aria-haspopup="listbox" aria-expanded="false" aria-labelledby="agvSelL" onclick="agvTendina()">'
    +   '<span id="agvSelT" class="vuoto">Scegli</span>' + AGV_TENDINA + '</button>'
    + '<div class="agv-f-lista" id="agvLista" role="listbox" hidden>'
    +   AGV_TIPI.map(function(t){ return '<button type="button" role="option" data-k="' + t[0] + '" aria-selected="false" onclick="agvScegli(\'' + t[0] + '\')"><span>' + agvEsc(t[1]) + '</span><i>' + AGV_SPUNTA + '</i></button>'; }).join('')
    + '</div>'
    + '<textarea id="agvTesto" class="agv-f-txt" rows="3" maxlength="2000" placeholder="Raccontalo con parole tue (facoltativo)"></textarea>'
    + '<p class="agv-f-nota">Con la segnalazione mandi anche questa risposta e la tua domanda: servono a migliorare DreamMap.</p>'
    + '<div class="agv-f-b"><button type="button" class="agv-f-no" onclick="inSheetChiudi()">Annulla</button>'
    +   '<button type="button" class="agv-f-si" onclick="agvInvia()">Invia</button></div>'
    + '</div>';
}
function agvTendina(forza){
  AGV.aperta = (typeof forza === 'boolean') ? forza : !AGV.aperta;
  const l = document.getElementById('agvLista'), b = document.getElementById('agvSel');
  if (l) l.hidden = !AGV.aperta;
  if (b){ b.setAttribute('aria-expanded', String(AGV.aperta)); b.classList.toggle('aperta', AGV.aperta); }
  if (AGV.aperta && l){ try{ l.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }catch(_){ } }
}
function agvScegli(k){
  AGV.tipo = k;
  const t = document.getElementById('agvSelT');
  if (t){ t.textContent = agvNomeTipo(k) || 'Scegli'; t.classList.toggle('vuoto', !k); }
  document.querySelectorAll('#agvLista [data-k]').forEach(function(b){ const on = b.dataset.k === k; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
  agvVibra(6);
  agvTendina(false);
}
async function agvInvia(){
  const motivo = String((document.getElementById('agvTesto') || {}).value || '').trim().slice(0, 2000);
  const tipo = AGV.tipo || '';
  try{ if (typeof inSheetChiudi === 'function') inSheetChiudi(); }catch(_){ }
  agvRiga(AGV.riga, -1);
  if (AGV.id > 0){
    const voti = agvVoti(); voti[AGV.id] = -1; agvSalva();
    const ok = await agvParti({ id: AGV.id, voto: -1, categoria: tipo, testo: motivo, tipoSogno: agvTipoSogno(), versione: agvVersione() });
    agvToast(ok ? 'Grazie: la segnalazione è arrivata' : 'Segnalazione salvata: parte appena torna la connessione');
    return;
  }
  /* la chat del Genio: il problema e il motivo vanno davanti alla risposta, cosi' restano anche se il testo e' lungo */
  const testo = (tipo ? 'PROBLEMA: ' + agvNomeTipo(tipo) + '\n' : '') + (motivo ? 'MOTIVO: ' + motivo + '\n' : '') + 'SOGNO: ' + agvTipoSogno() + ' · APP ' + agvVersione() + '\n\nRISPOSTA: ' + AGV.testo;
  try{ if (typeof frApi === 'function') frApi('POST', '/api/focuslock/social/voto-chat', { device: (typeof frDevice === 'function') ? frDevice() : '', voto: -1, testo: testo.slice(0, 1500), modo: AGV.modo || 'genio' }); }catch(_){ }
  agvToast('Grazie: la segnalazione è arrivata');
}

setTimeout(function(){ try{ agvCodaSvuota(); }catch(_){ } }, 6000);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(function(){ try{ agvCodaSvuota(); }catch(_){ } }, 2500); });

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.agv-f{display:flex;flex-direction:column;padding:6px 4px 4px;text-align:left}',
    '.agv-f-ico{align-self:center;font-size:34px;line-height:1}',
    '.agv-f-t{margin:12px 28px 26px;font:800 20px/1.25 var(--font-display);color:var(--navy);text-align:center}',
    '.agv-f-l{margin:0 0 10px;font:700 14px/1.35 var(--font-body);color:var(--navy)}.agv-f-l i{font-style:normal;font-weight:600;color:var(--muted)}',
    '.agv-f-sel{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;min-height:50px;padding:12px 14px 12px 16px;border:1.5px solid var(--line);border-radius:14px;background:var(--bg);color:var(--navy);font:600 15px/1.3 var(--font-body);text-align:left;cursor:pointer}',
    '.agv-f-sel .vuoto{color:var(--muted)}',
    '.agv-f-sel svg{flex:none;color:var(--muted);transition:transform .2s}.agv-f-sel.aperta{border-color:#0075E3}.agv-f-sel.aperta svg{transform:rotate(180deg)}',
    '.agv-f-lista{display:flex;flex-direction:column;margin-top:8px;padding:6px;border:1.5px solid var(--line);border-radius:14px;background:var(--card)}',
    '.agv-f-lista[hidden]{display:none}',
    '.agv-f-lista button{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:44px;padding:10px 12px;border:0;border-radius:10px;background:transparent;color:var(--navy);font:600 14.5px/1.3 var(--font-body);text-align:left;cursor:pointer}',
    '.agv-f-lista button:active{background:rgba(0,117,227,.08)}',
    '.agv-f-lista button i{display:inline-flex;color:#0075E3;opacity:0}.agv-f-lista button.on{color:#0075E3}.agv-f-lista button.on i{opacity:1}',
    '.agv-f-txt{box-sizing:border-box;width:100%;min-height:96px;margin-top:30px;padding:14px 16px;border:1.5px solid var(--line);border-radius:14px;background:var(--bg);color:var(--navy);font:500 15px/1.45 var(--font-body);resize:none}',
    '.agv-f-txt::placeholder{color:var(--muted)}.agv-f-txt:focus{outline:none;border-color:#0075E3}',
    '.agv-f-nota{margin:12px 2px 0;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.agv-f-b{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:32px}',
    '.agv-f-b button{min-height:50px;border-radius:14px;font:800 15px var(--font-body);cursor:pointer}',
    '.agv-f-no{border:1.5px solid var(--line);background:transparent;color:var(--navy)}',
    '.agv-f-si{border:0;background:#0075E3;color:#fff}'
  ].join('\n');
  document.head.appendChild(st);
})();
