/* ===========================================================================================
   LA CHIAMATA CON IL TUO IO FUTURO (0.9.192-193) — idea di Andrea, 2/10/2026.

   Parlare con se stessi dal futuro, con la propria voce. Solo voce: la videochiamata col volto
   animato e' la card «Videochiama» accanto, ancora «In arrivo». Si apre dalla card «Chiama il
   tuo Io futuro» in fondo a Dream (porte.js), ed e' Premium.

   0.9.193, come l'ha chiesta Andrea: la prima volta PARLI TU PER PRIMO. Lui ascolta, e mentre
   parli impara la tua voce (30-60 secondi di parlato); poi il server fa clonare la voce a
   ElevenLabs e trascrive quello che hai detto, e lui ti risponde con la tua voce, a quello che
   hai detto. Fa la parte di te nel giorno in cui hai gia' realizzato il sogno, e sa tutto quello
   che l'app sa di te: onboarding, lettura, episodi col Genio, giochi col Genio, conversazioni
   con il tuo agente personale e con l'umore, abitudini dal telefono (icContesto + icMemoria).

   I PEZZI: server meta-ai-media-buyer/server/_core/focuslockIoFuturo.ts (chiave su Railway:
   ELEVENLABS_API_KEY; senza, questa pagina lo dice e basta); la libreria ufficiale
   js/vendor/elevenlabs-client.js (si carica solo quando si chiama: e' un megabyte).
   La voce si cancella da qui quando si vuole (e ElevenLabs la cancella davvero).
   =========================================================================================== */
const IC = { stato: null, rec: null, conv: null, t0: 0, timer: 0, muto: false, consenso: false, fase: '', extra: null, primi: null, luiParla: false, luiFinito: 0, righe: [], convIds: [], inizio: 0, vocePronta: null, cambiando: false, caricando: false, migliorata: false, votoId: 0 };

function icDev(){
  let d = ''; try{ d = localStorage.getItem('fl_io_dev') || ''; }catch(_){ }
  if (!d){ d = 'i' + Math.random().toString(36).slice(2) + Date.now().toString(36); try{ localStorage.setItem('fl_io_dev', d); }catch(_){ } }
  return d;
}
function icEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
/* dal telefono: canale nativo (fetch dalla WebView = CORS); dal computer e dal browser: fetch */
async function icApi(path, body, ms){
  const opz = body ? { method: 'POST', body: JSON.stringify(body) } : { method: 'GET', body: '' };
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi){
      return await Promise.race([
        NATIVE.publicApi({ method: opz.method, path: path, body: opz.body }),
        new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, ms || 20000); })
      ]);
    }
  }catch(_){ return null; }
  try{
    const base = (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app';
    const r = await fetch(base + path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: opz.body } : {});
    return r.ok ? await r.json() : null;
  }catch(_){ return null; }
}

/* ---------- i dati per il personaggio: quello che l'app sa gia' ---------- */
function icMesi(){ return (typeof NV_MESI !== 'undefined') ? NV_MESI : ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']; }
function icArrivo(){ try{ const a = (typeof nvArrivo === 'function') ? nvArrivo() : null; return (a && a.at && isFinite(a.at)) ? new Date(a.at) : null; }catch(_){ return null; } }
function icNome(){ try{ return (typeof gnNome === 'function') ? gnNome().split(' ')[0] : ''; }catch(_){ return ''; } }
async function icContesto(){
  const c = {};
  c.nome = icNome();
  try{ const o = new Date(); c.oggi = o.getDate() + ' ' + icMesi()[o.getMonth()] + ' ' + o.getFullYear(); }catch(_){ }
  try{ c.sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  const d = icArrivo();
  if (d){ c.data = d.getDate() + ' ' + icMesi()[d.getMonth()] + ' ' + d.getFullYear(); c.anno = String(d.getFullYear()); }
  try{ const l = JSON.parse(localStorage.getItem('fl_genio_lettura') || 'null'); if (l && l.n) c.tipo = l.n; }catch(_){ }
  try{ if (typeof dqOstacoli === 'function') c.ostacoli = dqOstacoli().filter(function(o){ return o.w > 0; }).slice(0, 2).map(function(o){ return o.t + ' (' + o.f + ')'; }).join('; '); }catch(_){ }
  try{ const r = (typeof dqRisp === 'function') ? dqRisp('e1q6') : null; if (r && r.v) c.perche = r.v; }catch(_){ }
  try{ const r = (typeof dqRisp === 'function') ? dqRisp('e6q1') : null; if (r && r.v) c.tono = r.v; }catch(_){ }
  const ab = [];
  try{
    const avg = (typeof scAverages === 'function') ? await scAverages(0) : null;
    if (avg && avg.days >= 1 && avg.screenMs > 0) ab.push('in media ' + (avg.screenMs / 3600000).toFixed(1).replace('.', ',') + ' ore al giorno sul telefono');
    if (avg && avg.sleepMs > 0) ab.push('dorme circa ' + (avg.sleepMs / 3600000).toFixed(1).replace('.', ',') + ' ore');
  }catch(_){ }
  try{ const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]').filter(function(x){ return x && x.ok && x.at >= Date.now() - 14 * 86400000; }); ab.push(h.length + ' sessioni di lavoro concentrato nelle ultime due settimane'); }catch(_){ }
  c.abitudini = ab.join('; ');
  const pi = [];
  try{ const t = (typeof stTask === 'function') ? String(stTask() || '').replace(/^[☐☑•]\s*/, '').trim() : ''; if (t) pi.push('oggi: ' + t); }catch(_){ }
  try{ if (typeof ozAnello === 'function'){ ['settimana', 'mese', 'anno'].forEach(function(k){ const a = ozAnello(k); if (a && a.testo) pi.push(k + ': ' + a.testo); }); } }catch(_){ }
  c.piano = pi.join('; ');
  try{ if (typeof agBrief === 'function') c.brief = agBrief().slice(0, 4000); }catch(_){ }
  /* 0.9.253: prima l'identita' scritta da lui (riferimenti.js), poi la memoria; il server taglia dalla fine */
  c.memoria = ((typeof rfPezzi === 'function') ? rfPezzi('iofuturo', 2500) : []).concat([icMemoria()]).filter(Boolean).join(String.fromCharCode(10, 10)).slice(0, 11000);
  return c;
}
/* Tutto quello che l'utente ha raccontato all'app, a pezzi corti: le parti piu' personali prima,
   perche' il server taglia dalla fine. */
function icPulisci(t){ return String(t == null ? '' : t).replace(/\*/g, '').replace(/\s+/g, ' ').trim(); }
function icMemoria(){
  const r = [];
  /* l'onboarding con il Genio */
  try{
    const g = (typeof gnDati === 'function') ? gnDati() : {};
    const v = [];
    Object.keys(g).forEach(function(k){ const x = g[k]; if ((typeof x === 'string' || typeof x === 'number') && String(x).trim() && !/^(at|v)$/.test(k)) v.push(k + ': ' + String(x).slice(0, 120)); });
    if (v.length) r.push('ONBOARDING (quello che ha detto al Genio il primo giorno): ' + v.join('; '));
  }catch(_){ }
  /* la lettura del Genio e il «Leggi me» */
  try{ const L = (typeof gnLettura === 'function') ? gnLettura() : null; if (L && L.sogno) r.push('LETTURA DEL GENIO: sogno «' + icPulisci(L.sogno) + '»' + (L.prof && L.prof.name ? ', profilo ' + L.prof.name : '') + (L.pct ? ', ' + L.pct + '% di probabilità stimata' : '')); }catch(_){ }
  try{
    const l = JSON.parse(localStorage.getItem('fl_genio_lettura') || 'null');
    if (l){ const v = []; Object.keys(l).forEach(function(k){ if (typeof l[k] === 'string' && l[k].trim()) v.push(icPulisci(l[k]).slice(0, 220)); }); if (v.length) r.push('«LEGGI ME», COME LO HA LETTO IL GENIO: ' + v.join(' | ')); }
  }catch(_){ }
  /* gli episodi della prima settimana: domanda e risposta */
  try{
    if (typeof DQ_EPISODI !== 'undefined' && typeof dqRisp === 'function'){
      const v = [];
      DQ_EPISODI.forEach(function(ep){ (ep.domande || []).forEach(function(q0, i){
        let q = q0; try{ q = (typeof dqDomanda === 'function') ? (dqDomanda(ep, i) || q0) : q0; }catch(_){ }
        const a = dqRisp(q.id) || dqRisp(q0.id);
        if (a && a.v !== undefined && a.v !== '') v.push(icPulisci(q.t) + ' → ' + icPulisci(a.v).slice(0, 200));
      }); });
      if (v.length) r.push('EPISODI CON IL GENIO (domanda → sua risposta):\n' + v.join('\n'));
    }
  }catch(_){ }
  /* i giochi: a cosa ha pensato mentre il Genio indovinava */
  try{
    const p = JSON.parse(localStorage.getItem('fl_genio_pensati') || '[]') || [];
    const nomi = { personaggi: 'personaggio', libri: 'libro', film: 'film o serie' };
    if (p.length) r.push('NEI GIOCHI CON IL GENIO HA PENSATO A: ' + p.slice(-15).map(function(x){ return x.n + ' (' + (nomi[x.dom] || x.dom) + ')'; }).join(', '));
  }catch(_){ }
  /* i film e i libri di cui ha parlato con il Genio: cosa gli e' rimasto e cosa ha scelto di fare */
  try{
    const g = (typeof gfGusti === 'function') ? gfGusti() : null;
    if (g && g.opere && g.opere.length) r.push('FILM E LIBRI DI CUI HA PARLATO CON IL GENIO:\n' + g.opere.slice(-6).map(function(x){ return x.t + ': ' + (x.risp || []).map(function(y){ return y.a; }).join(' / ') + (x.azione ? ' -> ha scelto di fare: ' + x.azione : ''); }).join('\n'));
  }catch(_){ }
  /* le conversazioni con il suo agente personale */
  try{
    const s = (typeof agStato === 'function') ? agStato() : null;
    const m = (s && s.msgs) ? s.msgs.filter(function(x){ return x && x.testo; }).slice(-24) : [];
    if (m.length) r.push('CONVERSAZIONI CON IL SUO AGENTE PERSONALE (le più recenti):\n' + m.map(function(x){ return (x.direzione === 'in' ? 'Lui: ' : 'Agente: ') + icPulisci(x.testo).slice(0, 260); }).join('\n'));
  }catch(_){ }
  /* l'umore degli ultimi giorni */
  try{
    const s = (typeof umcStato === 'function') ? umcStato() : null;
    const v = [];
    if (s) Object.keys(s.giorni).sort().slice(-7).forEach(function(k){ const g = s.giorni[k]; const io = (g.msgs || []).filter(function(x){ return x.dir === 'io'; }).map(function(x){ return icPulisci(x.testo).slice(0, 160); }); if (io.length) v.push(k + ': ' + io.join(' / ')); });
    if (v.length) r.push('UMORE E COSA HA SCRITTO NEGLI ULTIMI GIORNI:\n' + v.join('\n'));
  }catch(_){ }
  return r.join('\n\n').slice(0, 9000);
}

/* ---------- la pagina ---------- */
registerScreen('s-iofuturo-chiamata',
  '<div class="topbar"><button class="iconbtn" onclick="icChiudi()">‹</button><b class="blk-title">Il tuo Io futuro</b></div>'
  + '<div class="ic-pag" id="icCorpo"></div>',
  { back: function(){ icChiudi(true); return 's-home'; } });

function icPremium(){ try{ return (typeof Premium !== 'undefined' && Premium.isPremium) ? !!Premium.isPremium() : false; }catch(_){ return false; } }
async function icStato(){
  /* il server su Railway a volte si sveglia lento: due tentativi prima di arrendersi */
  for (let i = 0; i < 2; i++){
    const j = await icApi('/api/focuslock/iofuturo/stato?dev=' + encodeURIComponent(icDev()), null, 20000);
    if (j && j.ok) return j;
  }
  return null;
}
async function icApri(){
  if (!icPremium()){ if (typeof toast === 'function') toast('Chiama il tuo Io futuro è una funzione Premium'); if (typeof go === 'function') go(11); return; }
  goId('s-iofuturo-chiamata');
  icDisegna('carica');
  const j = await icStato();
  /* le voci copiate prima della 0.9.196 (10 s filtrati e dimezzati) si rifanno da capo: con quella
     voce la prima chiamata partirebbe gia' sbagliata */
  try{
    if (j && j.voce && j.fonte === 'file'){ localStorage.setItem('fl_io_voce_ver', IC_VOCE_VER); icVoceSecSalva(999); }
    else if (j && j.voce && localStorage.getItem('fl_io_voce_ver') !== IC_VOCE_VER){ j.voce = false; localStorage.removeItem('fl_io_voce_sec'); }
  }catch(_){ }
  IC.stato = j;
  if (!j) icDisegna('rete');
  else if (!j.acceso) icDisegna('spento');
  else if (j.problema && IC_ERRORI[j.problema]) icDisegna('problema', j.problema);
  else icDisegna('pronto');
}
function icChiudi(daIndietro){
  icRecFerma(true);
  icRaccogliChiudi();
  if (IC.conv){ try{ IC.conv.endSession(); }catch(_){ } IC.conv = null; }
  clearInterval(IC.timer); IC.fase = '';
  if (!daIndietro) goId('s-home');
}
function icAvatar(){
  /* la stessa immagine dell'Io futuro di «Chi sarò» (e della chat dell'umore) */
  let img = ''; try{ const im = (typeof ifImmagini === 'function') ? ifImmagini() : null; img = (im && im.cerchio) || localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
  const n = icNome();
  return img ? '<div class="ic-av"><img src="' + icEsc(img) + '" alt=""></div>' : '<div class="ic-av"><span>' + icEsc((n || '✦').charAt(0).toUpperCase()) + '</span></div>';
}
function icQuando(){ const d = icArrivo(); return d ? 'il ' + d.getDate() + ' ' + icMesi()[d.getMonth()] + ' ' + d.getFullYear() : 'dal futuro'; }
const IC_TEL = '<svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.250.2 2.45.57 3.57a1 1 0 0 1-.25 1L6.6 10.8z"/></svg>';
const IC_GIU = '<svg viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path fill="currentColor" d="M12 9c-1.6 0-3.15.25-4.6.72v3.1a1 1 0 0 1-.56.9 11.5 11.5 0 0 0-2.66 1.850 1 1 0 0 1-1.410 0L.3 13.080a1 1 0 0 1 0-1.410A16.9 16.9 0 0 1 12 7a16.9 16.9 0 0 1 11.7 4.670 1 1 0 0 1 0 1.410l-2.480 2.490a1 1 0 0 1-1.410 0 11.5 11.5 0 0 0-2.660-1.850 1 1 0 0 1-.560-.900v-3.100A15 15 0 0 0 12 9z"/></svg>';
function icTastiHtml(conMuto){
  return '<div class="ic-tasti">'
    + (conMuto ? '<div class="ic-tc"><button type="button" class="ic-tasto" id="icMuto" onclick="icMuto()" aria-label="Microfono">🎙️</button><small id="icMutoT">Microfono</small></div>' : '')
    + '<div class="ic-tc"><button type="button" class="ic-tasto giu" onclick="icRiattacca()" aria-label="Riattacca">' + IC_GIU + '</button><small>Riattacca</small></div></div>';
}
function icDisegna(passo, problema){
  if (passo === 'chiamata'){ try{ localStorage.setItem('fl_ic_ultima', String(Date.now())); }catch(_){ } }
  const el = document.getElementById('icCorpo'); if (!el) return;
  const d = icArrivo();
  const anno = d ? d.getFullYear() : '';
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  const voce = !!(IC.stato && IC.stato.voce);
  let h = '';
  if (passo === 'carica') h = '<div class="ic-centro"><div class="ic-onda"></div><p class="ic-p">Un attimo…</p></div>';
  else if (passo === 'rete') h = '<div class="ic-centro">' + icAvatar() + '<b class="ic-h">Non riesco a raggiungere il server</b><p class="ic-p">Controlla la connessione e riprova.</p><button type="button" class="cta" onclick="icApri()">Riprova</button></div>';
  else if (passo === 'spento') h = '<div class="ic-centro">' + icAvatar() + '<b class="ic-h">Il tuo Io futuro non risponde ancora</b>'
    + '<p class="ic-p">Le chiamate non sono ancora attive sul server. Appena si accendono, da qui gli telefoni e ti risponde con la tua voce.</p><button type="button" class="cta" onclick="icApri()">Riprova</button></div>';
  else if (passo === 'problema') h = '<div class="ic-centro">' + icAvatar() + '<b class="ic-h">Il tuo Io futuro non può rispondere</b>'
    + '<p class="ic-p">' + icEsc(IC_ERRORI[problema] || 'Il servizio delle chiamate ha un problema.') + '</p><button type="button" class="cta" onclick="icApri()">Riprova</button></div>';
  else if (passo === 'pronto') h = '<div class="ic-centro">' + icAvatar() + '<b class="ic-h">Tu, ' + icQuando() + '</b>'
    + '<p class="ic-p">' + (sogno ? 'Il giorno in cui hai realizzato ' + icEsc(sogno.charAt(0).toLowerCase() + sogno.slice(1)) + '. ' : '') + 'Chiedigli cosa ha fatto per arrivarci.</p>'
    + (voce ? '' : '<p class="ic-p ic-nota">La prima volta parli tu per primo: digli come stai, come al telefono. In pochi secondi impara la tua voce e ti risponde con quella.</p>'
      + '<label class="ic-consenso"><input type="checkbox" id="icConsenso"' + (IC.consenso ? ' checked' : '') + ' onchange="IC.consenso=this.checked;icConsensoPaint()"> <span>Acconsento che la mia voce venga inviata a ElevenLabs e copiata, solo per parlare con il mio Io futuro in questa app. Posso cancellarla quando voglio da questa pagina.</span></label>')
    + '<button type="button" class="ic-chiama" id="icChiamaB" onclick="icChiama()" aria-label="Chiama"' + (voce || IC.consenso ? '' : ' disabled') + '>' + IC_TEL + '</button>'
    + '<small class="ic-p2">Chiama</small>'
    + (IC.stato && IC.stato.fonte === 'file'
        ? '<p class="ic-p ic-nota">La sua voce viene dalle tue registrazioni.</p><button type="button" class="ic-link" onclick="icVoceApri()">Cambia le registrazioni della mia voce</button>'
        : '<button type="button" class="ic-voce-cta" onclick="icVoceApri()"><b>Rendi la voce identica alla tua</b><small>Carica 1-2 minuti di registrazioni fatte con il telefono</small></button>')
    + (voce && !(IC.stato && IC.stato.fonte === 'file') ? '<button type="button" class="ic-link" onclick="icRifaiVoce()">Fagli imparare di nuovo la mia voce</button>'
      + '<button type="button" class="ic-link" onclick="icCancellaVoce()">Cancella la mia voce</button>' : (voce ? '<button type="button" class="ic-link" onclick="icCancellaVoce()">Cancella la mia voce</button>' : '')) + '</div>';
  else if (passo === 'ascolta') h = '<div class="ic-centro ic-in">' + icAvatar() + '<b class="ic-h">Tu, ' + (anno || 'dal futuro') + '</b><small class="ic-stato" id="icStato">In linea · ti ascolta</small><b class="ic-timer" id="icTimer">0:00</b>'
    + '<p class="ic-p ic-guida">Parla tu per primo, come al telefono: digli come stai e a che punto sei con il tuo sogno.</p>'
    + '<div class="ic-impara"><div class="ic-livello"><i id="icLivello"></i></div><small id="icImpara">Ti sta ascoltando</small></div>'
    + '<button type="button" class="ic-link" id="icFinito" onclick="icRecFerma(false)" hidden>Ho finito, rispondimi</button>'
    + icTastiHtml(false) + '</div>';
  else if (passo === 'impara') h = '<div class="ic-centro ic-in">' + icAvatar() + '<b class="ic-h">Tu, ' + (anno || 'dal futuro') + '</b><small class="ic-stato" id="icStato">Ti ha sentito</small><b class="ic-timer" id="icTimer"></b>'
    + '<div class="ic-onda ic-onda-s"></div>' + icTastiHtml(false) + '</div>';
  else if (passo === 'voto'){
    const riga = function(k, t){ let b = ''; for (let i = 1; i <= 5; i++) b += '<button type="button" onclick="icVota(\'' + k + '\',' + i + ')" aria-label="' + i + '">' + i + '</button>'; return '<div class="ic-voto" data-k="' + k + '"><b>' + t + '</b><div>' + b + '</div><small><span>Per niente</span><span>Del tutto</span></small></div>'; };
    h = '<div class="ic-centro">' + icAvatar() + '<b class="ic-h">Com’è andata?</b><p class="ic-p">Due risposte, e la prossima chiamata impara da qui.</p>'
      + riga('voce', 'La voce era la tua?') + riga('capito', 'Ti ha capito?')
      + '<button type="button" class="cta" id="icVotoInvia" disabled onclick="icVotoInvia()">Manda</button>'
      + '<button type="button" class="ic-link" onclick="icDisegna(\'pronto\')">Salta</button></div>';
  }
  else if (passo === 'chiamata') h = '<div class="ic-centro ic-in">' + icAvatar() + '<b class="ic-h">Tu, ' + (anno || 'dal futuro') + '</b><small class="ic-stato" id="icStato">Sto chiamando…</small><b class="ic-timer" id="icTimer">0:00</b>'
    + icTastiHtml(true) + '</div>';
  el.innerHTML = h;
  IC.fase = passo;
}
function icConsensoPaint(){ const b = document.getElementById('icChiamaB'); if (b) b.disabled = !(IC.consenso || (IC.stato && IC.stato.voce)); }

/* ---------- la voce: come si registra, e come migliora mentre parli ----------
   0.9.196, dopo la prima chiamata vera di Andrea («la voce non mi somiglia, sembra un robot»).
   ElevenLabs: «conta piu' COME e' registrato l'audio che quanto e' lungo», servono 1-2 minuti
   puliti, e il clone «imita tutto quello che sente: velocita', tono, respiro». Noi gli davamo:
   10 secondi, passati da riduzione del rumore + cancellazione dell'eco + volume automatico del
   telefono, dimezzati a 24 kHz senza filtro (distorsione), e con le pause TAGLIATE (ritmo finto).
   Adesso:
   - audio GREZZO (niente filtri del telefono) alla frequenza piena del microfono;
   - le pause restano fino a mezzo secondo: il respiro e il ritmo sono parte della voce;
   - primo turno di 12-25 secondi per rispondere subito; poi la voce si continua a raccogliere
     mentre parli (mai mentre parla lui), e quando ce n'e' abbastanza la copia si rifa' e la
     chiamata passa alla voce nuova a meta' conversazione, senza che tu faccia niente;
   - a fine chiamata, se c'e' altro audio, si rifa' ancora: fino a circa un minuto e mezzo. */
const IC_VOCE_VER = '196';
const IC_PARLATO_MIN = 12, IC_PARLATO_MAX = 25, IC_PAUSA = 1.0, IC_VOCE_BUONA = 80, IC_VOCE_MAX = 90;
/* «Serve il permesso» solo quando e' davvero un rifiuto: nella 0.9.193 lo diceva anche a chi
   il permesso l'aveva dato (il manifest non dichiarava MODIFY_AUDIO_SETTINGS, e Capacitor nega
   il microfono alla pagina se non li ottiene tutti e due). Gli altri errori hanno il loro nome. */
function icMicErrore(e){
  const n = (e && e.name) || '';
  if (n === 'NotAllowedError' || n === 'SecurityError') toast('Serve il permesso del microfono: consentilo a DreamMap nelle impostazioni del telefono');
  else if (n === 'NotReadableError' || n === 'AbortError') toast('Il microfono è occupato da un’altra app: chiudila e riprova');
  else if (n === 'NotFoundError') toast('Non trovo un microfono su questo telefono');
  else toast('Il microfono non parte (' + (n || 'errore') + '). Riprova');
}
/* I guasti del servizio, con il loro nome (li calcola il server da quello che risponde ElevenLabs). */
const IC_ERRORI = {
  chiave: 'Il servizio delle voci non accetta la chiave del server. Va rimessa la chiave segreta di ElevenLabs (quella che comincia con sk_).',
  permessi: 'La chiave di ElevenLabs sul server non ha i permessi per le voci e le chiamate.',
  piano: 'Il piano di ElevenLabs non permette di copiare le voci: serve almeno Starter.',
  spazio: 'Lo spazio per le voci su ElevenLabs è pieno.',
  crediti: 'I crediti di ElevenLabs di questo mese sono finiti.',
  troppe: 'Per oggi la tua voce è già stata copiata abbastanza volte. Riprova domani.'
};
function icErroreTxt(j, base){ return (j && j.errore && IC_ERRORI[j.errore]) || (j && j.limite ? 'Per questo mese le voci nuove sono finite. Riprova il mese prossimo.' : '') || (j && j.limiteChiamate ? 'Per oggi hai già chiamato abbastanza. Il tuo Io futuro ti aspetta domani.' : '') || base; }
function icVoceSec(){ try{ return Number(localStorage.getItem('fl_io_voce_sec') || 0) || 0; }catch(_){ return 0; } }
function icVoceSecSalva(n){ try{ localStorage.setItem('fl_io_voce_sec', String(Math.round(n || 0))); }catch(_){ } }

/* Il registratore: audio grezzo, tiene i pezzi in cui parli e le pause fino a mezzo secondo
   (oltre, il silenzio non serve alla copia e pesa). `soloSe` e' un controllo in piu' (durante la
   chiamata: solo quando lui sta zitto). `rumore` = quanto e' rumorosa la stanza nelle pause. */
const IC_GREZZO = { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1 };
async function icRegistratore(opz){
  const C = window.AudioContext || window.webkitAudioContext;
  const ctx = opz.ctx || new C();
  try{ ctx.resume().catch(function(){ }); }catch(_){ }
  let stream;
  try{ stream = await navigator.mediaDevices.getUserMedia({ audio: Object.assign({ voiceIsolation: false }, IC_GREZZO) }); }
  catch(e){ if (e && e.name === 'OverconstrainedError') stream = await navigator.mediaDevices.getUserMedia({ audio: IC_GREZZO }); else throw e; }
  const src = ctx.createMediaStreamSource(stream);
  const proc = ctx.createScriptProcessor(4096, 1, 1);
  const codaMax = Math.ceil(0.5 * ctx.sampleRate / 4096);
  const r = { stream: stream, ctx: ctx, proc: proc, src: src, pezzi: [], t0: Date.now(), rate: ctx.sampleRate, parlato: 0, zitto: 0, fondo: 0.004, picco: 0, attivo: true, coda: 0, rumS: 0, rumN: 0, campioni: 0 };
  proc.onaudioprocess = function(e){
    if (!r.attivo) return;
    const x = e.inputBuffer.getChannelData(0);
    let q = 0, n = 0, pk = 0; for (let i = 0; i < x.length; i += 8){ q += x[i] * x[i]; n++; const v = Math.abs(x[i]); if (v > pk) pk = v; }
    const rms = Math.sqrt(q / Math.max(1, n)); const dur = x.length / r.rate;
    r.picco = Math.max(r.picco, pk);
    /* il fondo della stanza si misura SOLO nelle pause: mentre parli quasi non si muove. Nella
       0.9.195 saliva anche sulla voce, e dopo ~16 s di parlato di filato la voce diventava
       «rumore» (smetteva di raccoglierla e accendeva il filtro del rumore per sbaglio). */
    const voce = rms > Math.max(0.006, r.fondo * 3);
    r.fondo = voce ? r.fondo + (rms - r.fondo) * 0.0002 : Math.min(0.015, r.fondo + (rms - r.fondo) * 0.05);
    const ok = !opz.soloSe || opz.soloSe();
    const pieno = r.campioni >= IC_VOCE_MAX * r.rate;
    if (voce && ok){ r.parlato += dur; r.zitto = 0; r.coda = codaMax; if (!pieno){ r.pezzi.push(new Float32Array(x)); r.campioni += x.length; } }
    else {
      r.zitto += dur;
      if (!voce){ r.rumS += rms; r.rumN++; }
      /* le pause brevi restano: il ritmo e il respiro fanno la voce quanto il timbro */
      if (ok && r.coda > 0 && !pieno){ r.coda--; r.pezzi.push(new Float32Array(x)); r.campioni += x.length; }
    }
    if (opz.ogni) opz.ogni(r);
  };
  src.connect(proc); proc.connect(ctx.destination);
  return r;
}
function icRegChiudi(r){
  if (!r) return;
  r.attivo = false;
  try{ r.proc.disconnect(); r.src.disconnect(); r.stream.getTracks().forEach(function(t){ t.stop(); }); r.ctx.close(); }catch(_){ }
}
function icRumore(r){ return !!r && r.rumN > 5 && (r.rumS / r.rumN) > 0.006; }

async function icRecParti(){
  /* il contesto audio nasce DENTRO il tocco, prima di aspettare il microfono: creato dopo,
     la WebView lo lascia sospeso e la registrazione esce muta */
  const C = window.AudioContext || window.webkitAudioContext;
  const ctx = new C();
  let r;
  try{
    r = await icRegistratore({ ctx: ctx, ogni: function(r){
      if (IC.rec !== r) return;
      const pc = Math.min(100, Math.round(r.parlato / IC_PARLATO_MIN * 100));
      const l = document.getElementById('icLivello'); if (l) l.style.width = pc + '%';
      const t = document.getElementById('icImpara'); if (t) t.textContent = r.parlato >= IC_PARLATO_MIN ? 'Ti ha sentito. Fai una pausa e ti risponde.' : 'Ti sta ascoltando';
      const f = document.getElementById('icFinito'); if (f) f.hidden = r.parlato < 6;
      if ((r.parlato >= IC_PARLATO_MIN && r.zitto >= IC_PAUSA) || r.parlato >= IC_PARLATO_MAX) setTimeout(function(){ if (IC.rec === r) icRecFerma(false); }, 0);
    } });
  }catch(e){ try{ ctx.close(); }catch(__){ } icMicErrore(e); icDisegna('pronto'); return false; }
  IC.rec = r;
  clearInterval(IC.timer);
  IC.timer = setInterval(function(){
    const s = Math.floor((Date.now() - r.t0) / 1000);
    const t = document.getElementById('icTimer'); if (t) t.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
    if (s >= 60 && IC.rec === r) icRecFerma(false);
  }, 250);
  return true;
}
function icRecFerma(annulla){
  const r = IC.rec; if (!r) return;
  IC.rec = null; clearInterval(IC.timer);
  icRegChiudi(r);
  if (annulla) return;
  /* contesto rimasto sospeso o microfono muto: niente da mandare, meglio dirlo subito */
  if (r.picco < 0.01){ toast('Non ti ho sentito: controlla il microfono e riprova'); icDisegna('pronto'); return; }
  if (r.parlato < 4){ toast('Non ti ho sentito bene: parlagli ancora un po’, come al telefono'); icDisegna('pronto'); return; }
  IC.primi = { pezzi: r.pezzi, rate: r.rate, sec: r.parlato, rumore: icRumore(r) };
  icImpara(icWav(r.pezzi, r.rate), r.parlato, icRumore(r));
}
/* WAV 16 bit mono alla frequenza del microfono: nessun ricampionamento, quindi nessuna distorsione */
function icWav(pezzi, rate){
  let n = 0; pezzi.forEach(function(p){ n += p.length; });
  n = Math.min(n, Math.floor(IC_VOCE_MAX * rate));
  const buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = function(off, s){ for (let i = 0; i < s.length; i++) v.setUint8(off + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  let o = 44, k = 0;
  for (let j = 0; j < pezzi.length && k < n; j++){
    const p = pezzi[j];
    for (let i = 0; i < p.length && k < n; i++, k++, o += 2){ const s = Math.max(-1, Math.min(1, p[i])); v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true); }
  }
  const b = new Uint8Array(buf); let bin = '';
  for (let i = 0; i < b.length; i += 0x8000) bin += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(bin);
}
/* Un solo viaggio: copia della voce + quello che hai detto + URL della chiamata. Mentre aspetta,
   la pagina dice a che punto e', perche' un silenzio senza segni sembra una linea caduta. */
async function icImpara(b64, sec, rumore){
  icDisegna('impara');
  const passi = ['Ti ha sentito', 'Sta trovando la tua voce…', 'Sta per risponderti…'];
  let i = 0; icStatoTxt(passi[0]);
  const giro = setInterval(function(){ i = Math.min(passi.length - 1, i + 1); if (IC.fase === 'impara') icStatoTxt(passi[i]); }, 1800);
  const contesto = await icContesto();
  const j = await icApi('/api/focuslock/iofuturo/voce', { dev: icDev(), consenso: true, audio: b64, mime: 'audio/wav', rumore: !!rumore, trascrivi: true, chiamata: true, contesto: contesto }, 95000);
  clearInterval(giro);
  if (IC.fase !== 'impara') return;                 /* ha riattaccato mentre aspettava */
  if (j && j.ok){
    if (IC.stato) IC.stato.voce = true;
    icVoceSecSalva(sec);
    try{ localStorage.setItem('fl_io_voce_ver', IC_VOCE_VER); }catch(_){ }
    if (j.signedUrl) icSessione(j, String(j.testo || ''));
    else icAvvia(String(j.testo || ''));
    return;
  }
  toast(icErroreTxt(j, 'Non è riuscito a imparare la tua voce. Riprova fra poco.'));
  icDisegna(j && IC_ERRORI[j.errore] && j.errore !== 'troppe' ? 'problema' : 'pronto', j && j.errore);
}
function icRifaiVoce(){ if (IC.stato) IC.stato.voce = false; IC.consenso = false; try{ localStorage.removeItem('fl_io_voce_sec'); }catch(_){ } icDisegna('pronto'); }
async function icCancellaVoce(){
  if (!confirm('Cancello la copia della tua voce? Alla prossima chiamata la imparerà di nuovo.')) return;
  const j = await icApi('/api/focuslock/iofuturo/voce/cancella', { dev: icDev() }, 20000);
  toast(j && j.ok ? 'La tua voce è stata cancellata' : 'Non sono riuscito a cancellarla. Riprova fra poco.');
  if (j && j.ok){ if (IC.stato) IC.stato.voce = false; IC.consenso = false; try{ localStorage.removeItem('fl_io_voce_sec'); }catch(_){ } icDisegna('pronto'); }
}

/* ---------- la chiamata ---------- */
function icLibreria(){
  return new Promise(function(si, no){
    if (window.ElevenLabsClient) return si(window.ElevenLabsClient);
    const s = document.createElement('script'); s.src = 'js/vendor/elevenlabs-client.js';
    s.onload = function(){ window.ElevenLabsClient ? si(window.ElevenLabsClient) : no(new Error('libreria')); };
    s.onerror = function(){ no(new Error('libreria')); };
    document.head.appendChild(s);
  });
}
function icStatoTxt(t){ const e = document.getElementById('icStato'); if (e) e.textContent = t; }
async function icChiama(){
  IC.righe = []; IC.convIds = []; IC.inizio = Date.now(); IC.cambiata = false; IC.vocePronta = null; IC.caricando = false;
  if (IC.stato && IC.stato.voce) return icAvvia('');
  if (!IC.consenso) return;
  icDisegna('ascolta');
  icLibreria().catch(function(){ });              /* intanto che parla, la libreria si scarica */
  await icRecParti();
}
/* Le chiamate dopo la prima: la voce c'e' gia', serve solo l'URL. */
async function icAvvia(detto){
  icDisegna('chiamata');
  const j = await icApi('/api/focuslock/iofuturo/chiamata', { dev: icDev(), contesto: await icContesto(), detto: detto || '' }, 20000);
  if (IC.fase !== 'chiamata') return;
  if (!j || !j.ok || !j.signedUrl){
    toast(j && j.senzaVoce ? 'Prima deve imparare la tua voce' : icErroreTxt(j, 'La chiamata non parte. Riprova fra poco.'));
    if (j && j.senzaVoce && IC.stato) IC.stato.voce = false;
    icDisegna('pronto'); return;
  }
  icSessione(j, detto);
}
/* `detto` = quello che ha appena detto la prima volta: lui risponde a quello, senza salutare da capo.
   `continua` = cambio di voce a meta' chiamata: stessa schermata, stesso timer, niente saluto. */
async function icSessione(j, detto, continua){
  if (!continua){ icDisegna('chiamata'); icStatoTxt(detto ? 'Sta per risponderti…' : 'Sto chiamando…'); }
  let L;
  try{ L = await icLibreria(); }catch(_){ toast('Non riesco ad aprire la chiamata'); icDisegna('pronto'); return; }
  try{
    const conv = await L.Conversation.startSession({
      signedUrl: j.signedUrl,
      connectionType: 'websocket',
      overrides: { agent: { prompt: { prompt: j.prompt }, firstMessage: (detto || continua) ? '' : j.primaFrase, language: 'it' }, tts: { voiceId: j.voiceId } },
      onConnect: function(){
        if (continua) return;
        IC.t0 = Date.now(); clearInterval(IC.timer);
        IC.timer = setInterval(function(){ const s = Math.floor((Date.now() - IC.t0) / 1000); const t = document.getElementById('icTimer'); if (t) t.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }, 500);
      },
      onModeChange: function(m){
        if (IC.conv && IC.conv !== conv) return;
        const parla = m && m.mode === 'speaking';
        IC.luiParla = parla; if (parla) IC.luiFinito = Date.now() + 99999; else IC.luiFinito = Date.now();
        icStatoTxt(parla ? 'Sta parlando' : 'Ti sta ascoltando');
        const av = document.querySelector('#icCorpo .ic-av'); if (av) av.classList.toggle('parla', parla);
        /* la voce nuova e' pronta: si cambia appena lui ha finito di parlare, cosi' la prossima
           cosa che senti e' gia' con la voce migliore */
        if (!parla && IC.vocePronta) icCambiaVoce();
      },
      /* la memoria della chiamata: tutto quello che vi dite, per la prossima volta */
      onMessage: function(m){ if (m && m.message) IC.righe.push({ r: m.source === 'user' ? 'io' : 'lui', t: String(m.message) }); },
      onDisconnect: function(){ if (IC.chiudendo) return; if (IC.conv === conv || !IC.conv) icFine(); },
      onError: function(){ icStatoTxt('La linea è disturbata…'); }
    });
    if (IC.fase !== 'chiamata'){ try{ conv.endSession(); }catch(_){ } return; }
    IC.conv = conv;
    try{ const id = conv.getId(); if (id) IC.convIds.push(id); }catch(_){ }
    /* la prima volta ha parlato lui per primo: quelle parole arrivano all'Io futuro come se le
       avesse appena sentite al telefono, e la risposta e' gia' con la sua voce */
    if (detto){ IC.righe.push({ r: 'io', t: detto }); try{ conv.sendUserMessage(detto); }catch(_){ } }
    icRaccogliAvvia();
  }catch(_){
    if (continua) return;                         /* il cambio non e' riuscito: resta la chiamata di prima */
    toast('La chiamata non parte. Riprova fra poco.'); IC.conv = null; icDisegna('pronto');
  }
}
/* Il cambio di voce a meta' chiamata: nuova sessione con la voce migliore e tutto quello che vi
   siete detti finora; la vecchia si chiude solo quando la nuova e' collegata. */
async function icCambiaVoce(){
  if (IC.cambiando || !IC.conv) return;
  IC.cambiando = true; IC.vocePronta = null;
  try{
    const j = await icApi('/api/focuslock/iofuturo/chiamata', { dev: icDev(), contesto: await icContesto(), continua: true, ora: IC.righe.slice(-30) }, 20000);
    if (!j || !j.ok || !j.signedUrl || IC.fase !== 'chiamata') return;
    const vecchia = IC.conv;
    IC.conv = null;                               /* da qui gli eventi della vecchia non contano */
    try{ await vecchia.endSession(); }catch(_){ }
    IC.conv = vecchia;                            /* se la nuova non parte, almeno non si riapre la pagina */
    await icSessione(j, '', true);
    if (IC.conv === vecchia) icFine(true);
    else IC.cambiata = true;
  }finally{ IC.cambiando = false; }
}
/* Durante la chiamata: la tua voce si raccoglie solo mentre lui ascolta (e mezzo secondo dopo che
   ha smesso, per non prendere la coda della sua). Quando c'e' abbastanza audio nuovo, la copia
   si rifa' mentre parlate. Se il telefono non regge due microfoni, non succede niente: la
   chiamata va avanti uguale. */
async function icRaccogliAvvia(){
  if (icVoceSec() >= IC_VOCE_BUONA || IC.extra) return;
  try{
    IC.luiFinito = IC.luiFinito || Date.now();
    IC.extra = await icRegistratore({
      soloSe: function(){ return !IC.luiParla && Date.now() - (IC.luiFinito || 0) > 500 && !IC.muto; },
      ogni: function(r){
        if (IC.caricando || IC.migliorata) return;
        const primi = (IC.primi && IC.primi.rate === r.rate) ? IC.primi.sec : 0;
        if (primi + r.parlato >= Math.max(45, icVoceSec() + 25)) icMigliora(false);
      }
    });
  }catch(_){ IC.extra = null; }
}
/* La copia rifatta con piu' audio: la prima registrazione + quello che hai detto in chiamata. */
function icMigliora(fine){
  const r = IC.extra; if (!r || IC.caricando) return;
  const primi = (IC.primi && IC.primi.rate === r.rate) ? IC.primi : { pezzi: [], sec: 0 };
  const sec = primi.sec + r.parlato;
  if (sec < 25 || sec < icVoceSec() + 15) return;
  IC.caricando = true;
  const b64 = icWav(primi.pezzi.concat(r.pezzi), r.rate);
  icApi('/api/focuslock/iofuturo/voce', { dev: icDev(), consenso: true, audio: b64, mime: 'audio/wav', rumore: icRumore(r) || !!(IC.primi && IC.primi.rumore), migliora: true }, 95000).then(function(j){
    IC.caricando = false;
    if (j && j.ok){
      icVoceSecSalva(sec);
      if (!fine){ IC.migliorata = true; if (IC.conv && IC.fase === 'chiamata') IC.vocePronta = j.voiceId || true; }
    }
  });
}
function icRaccogliChiudi(){
  const r = IC.extra; if (!r) { IC.primi = null; return; }
  icRegChiudi(r);
  if (!IC.caricando) icMigliora(true);
  IC.extra = null; IC.primi = null; IC.migliorata = false;
}
function icMuto(){
  if (!IC.conv) return;
  IC.muto = !IC.muto;
  try{ IC.conv.setMicMuted(IC.muto); }catch(_){ }
  const b = document.getElementById('icMuto'); if (b){ b.classList.toggle('off', IC.muto); b.textContent = IC.muto ? '🔇' : '🎙️'; }
  const t = document.getElementById('icMutoT'); if (t) t.textContent = IC.muto ? 'Microfono spento' : 'Microfono';
}
async function icRiattacca(){
  icRecFerma(true);
  const c = IC.conv; IC.conv = null; IC.fase = '';
  /* la chiusura della linea richiama onDisconnect: senza questo la fine partiva due volte e la
     seconda cancellava la schermata del voto */
  IC.chiudendo = true;
  try{ if (c) await c.endSession(); }catch(_){ }
  IC.chiudendo = false;
  icFine(true);
}
/* Fine chiamata: si salva cosa vi siete detti (la prossima volta se lo ricorda) e si chiede com'e'
   andata. Il voto torna nelle istruzioni della chiamata dopo, e regola la voce. */
function icFine(forza){
  if (IC.cambiando && !forza) return;
  const eraInChiamata = forza || IC.fase === 'chiamata';
  clearInterval(IC.timer); IC.conv = null; IC.muto = false; IC.luiParla = false; IC.vocePronta = null;
  icRaccogliChiudi();
  const righe = (IC.righe || []).slice(); IC.righe = [];
  const durata = IC.inizio ? Math.round((Date.now() - IC.inizio) / 1000) : 0;
  if (righe.length){
    IC.votoId = 0;
    icApi('/api/focuslock/iofuturo/fine', { dev: icDev(), righe: righe, convIds: IC.convIds || [], durata: durata }, 20000).then(function(j){ if (j && j.ok) IC.votoId = j.id || 0; });
  }
  if (eraInChiamata) icDisegna(righe.length >= 3 ? 'voto' : 'pronto');
}
const IC_VOTO = { voce: 0, capito: 0 };
function icVota(k, n){
  IC_VOTO[k] = n;
  document.querySelectorAll('#icCorpo .ic-voto[data-k="' + k + '"] button').forEach(function(b, i){ b.classList.toggle('on', i < n); });
  const inv = document.getElementById('icVotoInvia'); if (inv) inv.disabled = !(IC_VOTO.voce && IC_VOTO.capito);
}
async function icVotoInvia(){
  const v = { voce: IC_VOTO.voce, capito: IC_VOTO.capito };
  IC_VOTO.voce = 0; IC_VOTO.capito = 0;
  /* la voce non gli somigliava: si ricomincia a raccoglierla, e la prossima copia avra' piu' audio */
  const daFile = !!(IC.stato && IC.stato.fonte === 'file');
  if (v.voce && v.voce <= 3 && !daFile) icVoceSecSalva(Math.min(icVoceSec(), 20));
  for (let i = 0; i < 10 && !IC.votoId; i++) await new Promise(function(r){ setTimeout(r, 500); });
  if (IC.votoId) icApi('/api/focuslock/iofuturo/voto', { dev: icDev(), id: IC.votoId, voce: v.voce, capito: v.capito }, 20000);
  toast(v.voce <= 3 || v.capito <= 3 ? 'Grazie. La prossima volta impara da qui.' : 'Grazie');
  /* voce che non somiglia e nessuna registrazione caricata: la strada vera e' quella */
  if (v.voce && v.voce <= 3 && !daFile){ icVoceApri(); return; }
  icDisegna('pronto');
}

/* ---------- la voce dalle tue registrazioni (0.9.197) ----------
   Il metodo del video che Andrea ha mandato (Antonio Guadagno, «Come clonare la voce usando
   ElevenLabs»): registrazioni fatte con il registratore del TELEFONO in una stanza silenziosa,
   piu' di un minuto in tutto, anche in piu' file, caricate cosi' come sono. E' la voce piu'
   fedele, e una volta fatta non la tocca nessuno: il miglioramento automatico in chiamata e'
   solo per chi non le carica (il ripiego). Si apre dalla pagina della chiamata e da Personalizza. */
const IC_FILE = { lista: [], consenso: false };
registerScreen('s-iofuturo-voce',
  '<div class="topbar"><button class="iconbtn" onclick="icVoceChiudi()">‹</button><b class="blk-title">La tua voce, identica</b></div>'
  + '<div class="ic-pag" id="icVoceCorpo"></div><input type="file" id="icVoceFile" accept="audio/*,.m4a,.mp3,.wav,.aac,.ogg,.opus,.flac" multiple hidden onchange="icVoceScegli(this)">',
  { back: function(){ return 's-iofuturo-chiamata'; } });
function icVoceApri(){
  if (!icPremium()){ toast('Il tuo Io futuro è una funzione Premium'); if (typeof go === 'function') go(11); return; }
  IC_FILE.lista = []; IC_FILE.consenso = false;
  goId('s-iofuturo-voce'); icVocePaint();
}
function icVoceChiudi(){ goId('s-iofuturo-chiamata'); if (typeof icApri === 'function') icApri(); }
function icMinSec(s){ s = Math.round(s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function icVocePaint(msg){
  const el = document.getElementById('icVoceCorpo'); if (!el) return;
  /* 0.9.321: con il consenso la voce la impara dalla dettatura: nessun file da caricare, a meno di volerlo */
  if (typeof drvOn === 'function' && drvOn() && !IC_FILE.manuale){
    const s = Math.min(DRV.MIN, drvSec());
    el.innerHTML = '<div class="ic-voce"><p class="ic-p">Sta già imparando la tua voce mentre detti: non devi caricare niente.</p>'
      + '<p class="ic-tot"><b>' + icMinSec(s) + ' di voce su ' + icMinSec(DRV.MIN) + '</b></p>'
      + '<button type="button" class="ic-link" onclick="IC_FILE.manuale=true;icVocePaint()">Preferisco caricare una registrazione</button></div>';
    return;
  }
  const tot = IC_FILE.lista.reduce(function(a, f){ return a + (f.sec || 0); }, 0);
  const kb = IC_FILE.lista.reduce(function(a, f){ return a + f.kb; }, 0);
  const noto = IC_FILE.lista.every(function(f){ return f.sec > 0; });
  const giudizio = !IC_FILE.lista.length ? '' : !noto ? '' : tot < 30 ? 'Troppo poco: servono almeno 30 secondi, meglio più di un minuto.' : tot < 60 ? 'Va bene, ma con più di un minuto viene più fedele.' : tot <= 180 ? 'Perfetto: è la durata giusta.' : 'Più di 3 minuti non serve: tieni le registrazioni migliori.';
  const ok = IC_FILE.lista.length && (!noto || tot >= 30) && kb <= 20000 && IC_FILE.consenso;
  el.innerHTML = '<div class="ic-voce">'
    + '<p class="ic-p ic-sx">La voce più fedele nasce da registrazioni fatte con calma, con il registratore del telefono. Bastano due minuti.</p>'
    + '<ol class="ic-passi">'
    +   '<li><b>Vai in una stanza silenziosa</b><span>Niente TV, musica o altre voci. Il telefono a un palmo dalla bocca.</span></li>'
    +   '<li><b>Apri il registratore vocale del telefono</b><span>Quello che c’è già (Registratore, Memo vocali). Non registrare da qui: il registratore del telefono è più pulito.</span></li>'
    +   '<li><b>Parla per 1 o 2 minuti, come parli di solito</b><span>Racconta la tua giornata, un ricordo, cosa vuoi costruire. Con le tue pause e il tuo tono: lui imparerà anche quelli. Puoi fare più registrazioni.</span></li>'
    +   '<li><b>Torna qui e caricale</b><span>MP3, M4A, WAV: vanno bene tutti.</span></li>'
    + '</ol>'
    + '<button type="button" class="cta" onclick="document.getElementById(\'icVoceFile\').click()">' + (IC_FILE.lista.length ? 'Aggiungi altre registrazioni' : 'Scegli le registrazioni') + '</button>'
    + (IC_FILE.lista.length ? '<div class="ic-file">' + IC_FILE.lista.map(function(f, i){ return '<div><span>🎙️</span><b>' + icEsc(f.nome) + '</b><small>' + (f.sec ? icMinSec(f.sec) : '') + '</small><button type="button" onclick="icVoceTogli(' + i + ')" aria-label="Togli">×</button></div>'; }).join('')
        + '<p class="ic-tot"><b>' + (noto ? icMinSec(tot) + ' di voce' : IC_FILE.lista.length + ' registrazioni') + '</b>' + (giudizio ? ' · ' + giudizio : '') + '</p>'
        + (kb > 20000 ? '<p class="ic-tot ko">Sono troppo pesanti per l’invio: tieni al massimo 3 minuti in tutto.</p>' : '') + '</div>' : '')
    + '<label class="ic-consenso"><input type="checkbox"' + (IC_FILE.consenso ? ' checked' : '') + ' onchange="IC_FILE.consenso=this.checked;icVocePaint()"> <span>Acconsento che queste registrazioni della mia voce vengano inviate a ElevenLabs e copiate, solo per parlare con il mio Io futuro in questa app. Posso cancellarla quando voglio.</span></label>'
    + '<button type="button" class="cta" id="icVoceCrea"' + (ok ? '' : ' disabled') + ' onclick="icVoceCrea()">Crea la mia voce</button>'
    + (msg ? '<p class="ic-p">' + icEsc(msg) + '</p>' : '')
    + '</div>';
}
function icVoceMime(f){
  if (f.type) return f.type;
  const e = (String(f.name).split('.').pop() || '').toLowerCase();
  return { m4a: 'audio/mp4', mp4: 'audio/mp4', mp3: 'audio/mpeg', wav: 'audio/wav', aac: 'audio/aac', ogg: 'audio/ogg', opus: 'audio/ogg', flac: 'audio/flac', amr: 'audio/amr', '3gp': 'audio/3gpp' }[e] || 'audio/mpeg';
}
function icVoceScegli(inp){
  const files = Array.prototype.slice.call(inp.files || []);
  inp.value = '';
  files.slice(0, 8 - IC_FILE.lista.length).forEach(function(f){
    const voce = { nome: f.name || 'registrazione', mime: icVoceMime(f), b64: '', sec: 0, kb: Math.round(f.size / 1024) };
    IC_FILE.lista.push(voce);
    const r1 = new FileReader();
    r1.onload = function(){ voce.b64 = String(r1.result || '').split(',')[1] || ''; icVocePaint(); };
    r1.readAsDataURL(f);
    /* la durata, per dire se basta: se il telefono non sa leggere il formato, si manda lo stesso */
    const r2 = new FileReader();
    r2.onload = function(){
      try{
        const C = window.AudioContext || window.webkitAudioContext; const ctx = new C();
        ctx.decodeAudioData(r2.result, function(buf){ voce.sec = buf.duration; try{ ctx.close(); }catch(_){ } icVocePaint(); }, function(){ try{ ctx.close(); }catch(_){ } });
      }catch(_){ }
    };
    r2.readAsArrayBuffer(f);
  });
  icVocePaint();
}
function icVoceTogli(i){ IC_FILE.lista.splice(i, 1); icVocePaint(); }
async function icVoceCrea(){
  if (IC_FILE.lista.some(function(f){ return !f.b64; })){ toast('Un attimo, sto ancora leggendo le registrazioni'); return; }
  const b = document.getElementById('icVoceCrea'); if (b){ b.disabled = true; b.textContent = 'Sta imparando la tua voce…'; }
  const j = await icApi('/api/focuslock/iofuturo/voce', { dev: icDev(), consenso: true, files: IC_FILE.lista.map(function(f){ return { audio: f.b64, mime: f.mime, nome: f.nome }; }) }, 150000);
  if (j && j.ok){
    try{ localStorage.setItem('fl_io_voce_ver', IC_VOCE_VER); }catch(_){ }
    icVoceSecSalva(999);
    IC.stato = Object.assign(IC.stato || {}, { voce: true, fonte: 'file' });
    IC_FILE.lista = [];
    toast('Fatto: adesso ti risponde con la tua voce vera');
    goId('s-iofuturo-chiamata'); icDisegna('pronto');
    return;
  }
  icVocePaint(icErroreTxt(j, 'Non è riuscito a creare la voce. Riprova fra poco.'));
}

/* ---------- la videochiamata: «In arrivo» ----------
   Il volto del tuo Io futuro animato mentre parla, come la videochiamata di Duolingo con Lily.
   Intanto si puo' gia' scegliere l'immagine (la stessa di «Chi sarò»). */
registerScreen('s-iofuturo-video',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Videochiama il tuo Io futuro</b></div>'
  + '<div class="ic-pag" id="icVideoCorpo"></div>', { back: 's-home' });
function icVideoApri(){
  if (typeof flInArrivo === 'function'){ flInArrivo(); return; }
  if (!icPremium()){ if (typeof toast === 'function') toast('Videochiama il tuo Io futuro è una funzione Premium'); if (typeof go === 'function') go(11); return; }
  goId('s-iofuturo-video'); icVideoPaint();
}
function icVideoPaint(){
  const el = document.getElementById('icVideoCorpo'); if (!el) return;
  let propria = false; try{ const im = (typeof ifImmagini === 'function') ? ifImmagini() : null; propria = !!(im && im.propria); }catch(_){ }
  el.innerHTML = '<div class="ic-centro ic-video">' + icAvatar() + '<span class="ic-arrivo">In arrivo</span><b class="ic-h">Guardalo in faccia mentre ti parla</b>'
    + '<p class="ic-p">Presto potrai videochiamare il tuo Io futuro: il suo volto si muoverà mentre parla, con la tua voce, come in una videochiamata vera.</p>'
    + '<p class="ic-p ic-nota">Intanto scegli l’immagine del tuo Io futuro: è quella che vedrai quando ti risponde.</p>'
    + '<button type="button" class="cta" onclick="icVideoImg()">' + (propria ? 'Cambia l’immagine del mio Io futuro' : 'Allega l’immagine del mio Io futuro') + '</button>'
    + '<button type="button" class="ic-link" onclick="icApri()">Intanto chiamalo</button></div>';
}
function icVideoImg(){
  if (typeof flImgPick !== 'function' || typeof IF_IMG_KEY === 'undefined'){ toast('Non riesco ad aprire le immagini qui'); return; }
  flImgPick(IF_IMG_KEY, function(){ icVideoPaint(); try{ if (typeof ifCardPaint === 'function') ifCardPaint(); }catch(_){ } }, true);
}

(function(){
  const css = [
    '#s-iofuturo-chiamata,#s-iofuturo-video{background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C);color:#fff}',
    '#s-iofuturo-chiamata .topbar .blk-title,#s-iofuturo-chiamata .topbar .iconbtn,#s-iofuturo-video .topbar .blk-title,#s-iofuturo-video .topbar .iconbtn{color:#fff}',
    /* .ic-pag e non .ic: «ic» e' la classe delle icone in mezza app (card Esplora, pillole dei
       punteggi), e il padding di questa pagina finiva anche li' (6/10/2026) */
    '.ic-pag{padding:8px 4px 40px}',
    /* 0.9.287, Andrea: la pagina della videochiamata era tutta attaccata */
    '.ic-video{padding:36px 22px 0}.ic-video .ic-h{margin-top:14px}.ic-video .ic-p{margin-top:14px}.ic-video .ic-nota{margin-top:28px;padding-top:22px;border-top:1px solid rgba(255,255,255,.12)}',
    '.ic-video .cta{width:100%;max-width:340px;margin-top:18px}.ic-video .ic-link{margin-top:22px}',
    '.ic-centro{display:flex;flex-direction:column;align-items:center;text-align:center;padding-top:28px}',
    '.ic-av{width:136px;height:136px;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#3F9FF4,#005BB0);display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 6px rgba(255,255,255,.08),0 12px 40px rgba(63,159,244,.4);transition:box-shadow .3s}',
    '.ic-av img{width:100%;height:100%;object-fit:cover}.ic-av span{font:900 54px var(--font-display);color:#fff}',
    '.ic-av.parla{animation:icParla 1.1s ease-in-out infinite}',
    '@keyframes icParla{0%,100%{box-shadow:0 0 0 6px rgba(140,198,255,.25),0 12px 40px rgba(63,159,244,.5)}50%{box-shadow:0 0 0 16px rgba(140,198,255,.12),0 12px 60px rgba(63,159,244,.8)}}',
    '.ic-h{display:block;margin-top:20px;font:900 26px/1.2 var(--font-display);color:#fff}',
    '.ic-p{margin:12px auto 0;max-width:30em;font:500 15px/1.6 var(--font-body);color:rgba(255,255,255,.82)}',
    '.ic-nota{font-size:13.5px;color:rgba(191,224,255,.9)}',
    '.ic-p2{display:block;margin-top:8px;font:700 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CF0C8}',
    '.ic-consenso{display:flex;gap:10px;align-items:flex-start;margin:18px 0 0;padding:14px;border-radius:16px;background:rgba(255,255,255,.08);text-align:left;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.88)}',
    '.ic-consenso input{margin-top:3px;width:18px;height:18px;flex:none;accent-color:#3F9FF4}',
    '.ic-chiama{margin-top:26px;width:82px;height:82px;border-radius:50%;border:0;background:#1FBF73;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 10px 30px rgba(31,191,115,.45);animation:icSuona 1.6s ease-in-out infinite}',
    '.ic-chiama[disabled]{opacity:.35;animation:none;box-shadow:none}',
    '@keyframes icSuona{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}',
    '.ic-link{display:block;margin:18px auto 0;border:0;background:none;color:rgba(191,224,255,.9);font:700 12.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    '.ic-guida{margin-top:18px;font-weight:600}',
    '.ic-impara{width:100%;max-width:300px;margin-top:18px;display:flex;flex-direction:column;gap:8px;align-items:center}.ic-impara small{font:600 12.5px var(--font-body);color:#8CF0C8}',
    '.ic-livello{width:100%;height:6px;border-radius:3px;background:rgba(255,255,255,.15);overflow:hidden}.ic-livello i{display:block;height:100%;width:0;background:linear-gradient(90deg,#8CF0C8,#3F9FF4);transition:width .2s}',
    '.ic-tasto{width:66px;height:66px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;font-size:26px;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.ic-tasto.giu{background:#E63946}.ic-tasto.off{background:rgba(255,255,255,.4)}',
    '.ic-in .ic-stato{display:block;margin-top:8px;font:600 14px var(--font-body);color:#8CF0C8}.ic-timer{display:block;margin-top:6px;min-height:22px;font:700 18px var(--font-display);color:rgba(255,255,255,.8)}',
    '.ic-tasti{display:flex;gap:40px;margin-top:48px}.ic-tc{display:flex;flex-direction:column;align-items:center;gap:8px}.ic-tc small{font:600 12px var(--font-body);color:rgba(255,255,255,.75)}',
    '.ic-onda{width:90px;height:90px;border-radius:50%;margin-top:40px;background:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(8px);animation:spin 2s linear infinite}',
    '.ic-onda-s{width:54px;height:54px;margin-top:26px}',
    '.ic-voto{width:100%;max-width:340px;margin-top:22px;text-align:left}.ic-voto b{display:block;font:800 15px var(--font-body);color:#fff}',
    '.ic-voto div{display:flex;gap:8px;margin-top:10px}.ic-voto button{flex:1;height:46px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.ic-voto button.on{background:#3F9FF4;border-color:#3F9FF4}.ic-voto small{display:flex;justify-content:space-between;margin-top:6px;font:500 11.5px var(--font-body);color:rgba(255,255,255,.6)}',
    '#icVotoInvia{margin-top:24px}#icVotoInvia[disabled]{opacity:.45}',
    '.ic-voce-cta{display:block;width:100%;max-width:340px;margin:22px auto 0;padding:14px 16px;border-radius:16px;border:1px solid rgba(140,240,200,.45);background:rgba(140,240,200,.08);color:#fff;text-align:left;cursor:pointer}',
    '.ic-voce-cta b{display:block;font:800 14.5px var(--font-body)}.ic-voce-cta small{display:block;margin-top:3px;font:500 12.5px var(--font-body);color:rgba(255,255,255,.75)}',
    '#s-iofuturo-voce{background:radial-gradient(120% 70% at 50% 0%,#12305F,#061530 60%,#040B1C);color:#fff}#s-iofuturo-voce .topbar .blk-title,#s-iofuturo-voce .topbar .iconbtn{color:#fff}',
    '.ic-voce{padding:4px 6px 30px}.ic-sx{text-align:left;margin:4px 0 0}',
    '.ic-passi{margin:18px 0 20px;padding:0;list-style:none;counter-reset:p}.ic-passi li{counter-increment:p;position:relative;padding:0 0 14px 42px}',
    '.ic-passi li:before{content:counter(p);position:absolute;left:0;top:0;width:28px;height:28px;border-radius:50%;background:#3F9FF4;color:#fff;font:800 14px var(--font-body);display:flex;align-items:center;justify-content:center}',
    '.ic-passi b{display:block;font:800 15px var(--font-body);color:#fff}.ic-passi span{display:block;margin-top:3px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.78)}',
    '.ic-file{margin-top:14px}.ic-file div{display:flex;align-items:center;gap:10px;padding:10px 12px;margin-top:8px;border-radius:12px;background:rgba(255,255,255,.07)}',
    '.ic-file b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:600 13.5px var(--font-body)}.ic-file small{font:600 12.5px var(--font-body);color:#8CF0C8}',
    '.ic-file button{border:0;background:none;color:rgba(255,255,255,.7);font-size:20px;cursor:pointer}',
    '.ic-tot{margin:10px 2px 0;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.85)}.ic-tot.ko{color:#FF8A8A}',
    '#icVoceCrea{margin-top:16px}#icVoceCrea[disabled]{opacity:.45}',
    /* 0.9.305: "In arrivo" in italiano, col gradiente VERO del brand (il pulsante "Crea il tuo bundle"): bordo rosso-blu, testo bianco con l'ombra */
    '.ic-arrivo{display:inline-block;margin-top:22px;padding:5px 14px;border-radius:999px;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;border:2px solid transparent;color:#fff;text-shadow:1px 2.5px 3px rgba(0,0,0,.9);font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase}',
    /* 0.9.305, Andrea: la pillola sotto al testo rendeva la card della videochiamata piu' alta di "Chiama il tuo Io futuro".
       Ora e' un NASTRO in obliquo nell'angolo in alto a destra, sopra alla card: non spinge giu' il testo, e le due card
       (stessa riga della griglia di Dream) sono alte uguali. E' l'unica cosa col gradiente del brand in quella vista. */
    '.pt-mini:has(.pt-arrivo){position:relative;overflow:hidden}',
    '.pt-mini .pt-arrivo{position:absolute;top:15px;right:-38px;width:132px;box-sizing:border-box;padding:4px 0;transform:rotate(38deg);text-align:center;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;border:2px solid transparent;border-left:0;border-right:0;color:#fff;text-shadow:1px 2.5px 3px rgba(0,0,0,.9);font:800 9.5px/1.3 var(--font-body);font-style:normal;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;pointer-events:none;box-shadow:0 3px 8px rgba(0,30,68,.18)}',
    '#nvChiama .pt-porte,#nvSveglia .pt-porte{height:100%}',
    '#nvSveglia .pt-mini,#nvPorte .pt-mini{position:relative}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
