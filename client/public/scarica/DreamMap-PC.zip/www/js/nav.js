/* nav.js - the common module. Screen list and screen navigation (order, go, goId, cur,
   handleBack, skipAll), home-shell tab switching, the toast, the two helpers shared by more
   than one area (esc, fmtMin), the syncNative refresh fan-out, and the startup bootstrap.
   Loaded LAST on purpose: the bootstrap at the bottom calls into every other module. */

/* `order` and registerScreen() now live in registry.js, which loads first: modules add
   their own screens while they load, well before this file runs. */
/* Navigate by screen id: the new screens are appended, so their numeric index is not
   something any handler should have to know. */
function goId(id){ const i=order.indexOf(id); if(i>=0) go(i); }
/* 0.9.290, Andrea: "se scorro una scheda e cambio scheda, tornando riparte dall'alto; e chiudendo la chat del Genio a
   schermo intero torno in cima alla Mappa". Ogni scheda ricorda dove l'avevi lasciata: la posizione si salva quando
   esci (cambio di scheda o pagina sopra alla casa) e si rimette quando torni. Solo un tocco sulla scheda gia' aperta
   la riporta in cima. I disegni che arrivano subito dopo (la Mappa si ridisegna a 120 e 400 ms) accorciano la
   pagina per un attimo: la posizione si rimette per un secondo, finche' non tocchi tu lo schermo. */
const NAV_SCROLL = {};
let NAV_SCROLL_MANO = 0;
['touchstart', 'wheel', 'pointerdown'].forEach(function(ev){ document.addEventListener(ev, function(){ NAV_SCROLL_MANO = Date.now(); }, { passive: true, capture: true }); });
function navTabCorrente(){
  try{ for (let i = 0; i < TABS.length; i++){ const e = document.getElementById('tab-' + TABS[i]); if (e && e.classList.contains('on')) return TABS[i]; } }catch(_){ }
  return '';
}
function navScrollSalva(t){
  t = t || navTabCorrente(); const e = t && document.getElementById('tab-' + t);
  if (e) NAV_SCROLL[t] = e.scrollTop;
}
function navScrollRipristina(t){
  const e = t && document.getElementById('tab-' + t); if (!e) return;
  const y = NAV_SCROLL[t] || 0, t0 = Date.now();
  e.scrollTop = y;
  if (!y) return;
  let n = 0;
  const ancora = function(){
    if (++n > 12 || NAV_SCROLL_MANO > t0) return;
    if (!e.classList.contains('on')) return;
    /* si rimette solo se un disegno l'ha schiacciata in cima o in fondo: se qualcuno ha portato la visuale altrove
       apposta (la tappa dopo, la roadmap), resta li' */
    const schiacciata = e.scrollTop <= 1 || e.scrollTop >= e.scrollHeight - e.clientHeight - 2;
    if (Math.abs(e.scrollTop - y) > 2 && schiacciata) e.scrollTop = y;
    setTimeout(ancora, 100);
  };
  requestAnimationFrame(ancora);
}
let cur=0;
/* INDIETRO TORNA DOVE ERI (0.9.282, regola di Andrea): "dalla pagina 2 vai alla 3, indietro torna alla 2, non fuori
   dal menu". Ogni volta che si cambia schermata si ricorda da dove si arrivava (e, se era la casa, quale scheda);
   indietro riporta li'. Arrivando alla casa la storia riparte da zero: la casa e' la radice. */
let NAV_STORIA = [], NAV_INDIETRO = false;
function navTabOra(){ try{ return localStorage.getItem('fl_tab') || ''; }catch(_){ return ''; } }
function go(n){
  /* il vecchio paywall resta solo nel primo avvio: da dentro l'app si passa dal funnel (premium-funnel.js) */
  try{ if (n === 11 && localStorage.getItem('fl_onboarded') === '1' && typeof pfApri === 'function'){ pfApri(); return; } }catch(_){ }
  const from=document.getElementById(order[cur]);
  const to=document.getElementById(order[n]);
  if (from !== to){
    if (!NAV_IN_BACK) NAV_BACK_GIRO = [];
    if (order[cur] === 's-home') navScrollSalva();
    if (order[n] === 's-home') NAV_STORIA = [];
    else if (!NAV_INDIETRO){
      const e = { s: order[cur], tab: order[cur] === 's-home' ? navTabOra() : '' };
      const u = NAV_STORIA[NAV_STORIA.length - 1];
      /* 0.9.291, Andrea: "a volte resta incastrato: torna alla pagina di prima, poi con indietro di Android torna alla
         pagina da cui ero uscito invece di uscire". Un pulsante indietro scritto come goId(pagina di prima) veniva
         registrato come un passo AVANTI: la pagina appena lasciata finiva in cima alla storia, e il tasto indietro ci
         riportava dentro. Tornare alla pagina da cui si era arrivati e' un passo indietro, e toglie quel passo. */
      if (u && u.s === order[n]) NAV_STORIA.pop();
      else if (!u || u.s !== e.s) NAV_STORIA.push(e);
      if (NAV_STORIA.length > 40) NAV_STORIA.shift();
    }
  }
  // Navigating to the screen you are already on (openBlocklist() from inside the block list,
  // sevPickLevel() landing back on sev-status) used to run the transition against itself: the
  // element got "prev" AND "active" at once and slid 40px sideways for 400ms before healing.
  // Nothing to animate here - just make sure it is showing.
  if(from===to){ to.classList.remove("prev"); to.classList.add("active"); cur=n; to.scrollTop=0;
    if(order[n]==='s-home') localStorage.setItem('fl_onboarded','1');
    return; }
  from.classList.remove("active");from.classList.add("prev");
  setTimeout(()=>from.classList.remove("prev"),400);
  to.classList.add("active");
  cur=n;
  to.scrollTop=0;
  if (order[n] === 's-home'){ const tc = navTabCorrente(); if (tc) navScrollRipristina(tc); }
  try{ document.dispatchEvent(new CustomEvent('fl:screen', { detail: order[n] })); }catch(_){ }
  /* 0.9.267, Andrea: il permesso del tempo di schermo non si richiede se c'e' gia' (dopo "Ricomincia da capo"): S6 passa
     dritta al rapporto */
  if(order[n]==='s6' && typeof refreshUsageReveal==='function') setTimeout(refreshUsageReveal, 60);
  // Reaching the home shell means onboarding is done: remember it, so a relaunch or a return
  // from the background lands here instead of restarting the quiz. This was THE reset bug.
  if(order[n]==='s-home') localStorage.setItem('fl_onboarded','1');
}
/* Hardware/gesture back walks the onboarding backwards; on the home shell it does nothing
   (the OS will background the app), so the phone's own back button is the only "indietro". */
/* 0.9.294, Andrea: "sono rimasto intrappolato fra la partita e le regole della partita: indietro mi portava dall'una
   all'altra; e nelle note indietro non tornava piu' alla casa". Come su un sito, ma senza trappole: ogni Indietro che
   cambia pagina si segna; se un Indietro riporta a una pagina appena lasciata andando indietro (un giro), si va alla
   casa, sulla scheda Sogno. E fuori dal primo avvio l'Indietro non chiude mai l'app da una pagina interna: porta a casa. */
let NAV_IN_BACK = false, NAV_BACK_GIRO = [];
function navCasa(tab){
  NAV_BACK_GIRO = []; NAV_STORIA = [];
  try{ goId('s-home'); if (typeof switchTab === 'function') switchTab(tab || 'rotta'); }catch(_){ }
}
function handleBack(){
  const prima = order[cur];
  let r;
  NAV_IN_BACK = true;
  try{ r = handleBackNucleo(); } finally { NAV_IN_BACK = false; }
  const dopo = order[cur];
  if (dopo !== prima){
    if (dopo !== 's-home' && NAV_BACK_GIRO.indexOf(dopo) >= 0){ navCasa(); return true; }
    NAV_BACK_GIRO.push(prima);
    if (NAV_BACK_GIRO.length > 12) NAV_BACK_GIRO.shift();
    return r;
  }
  if (!r && prima !== 's-home' && localStorage.getItem('fl_onboarded') === '1' && !/^s\d+$/.test(prima)){ navCasa(); return true; }
  return r;
}
function handleBackNucleo(){
  /* 0.9.335, Andrea: "nel tour guidato dopo l'onboarding, con il tasto indietro si chiude l'app invece di tornare indietro" */
  try{ if (typeof GT !== 'undefined' && GT.on){ if (GT.i > 0 && typeof gtVai === 'function') gtVai(GT.i - 1); return true; } }catch(_){ }
  try{ if (typeof pfAperto === 'function' && pfAperto()){ pfIndietro(); return true; } }catch(_){ }   /* il funnel di Premium: una slide indietro */
  try{ if (typeof dsoIndietro === 'function' && dsoIndietro()) return true; }catch(_){ }   /* il duello (dream-social.js) */
  try{ if (typeof atmIndietro === 'function' && atmIndietro()) return true; }catch(_){ }   /* il volo e il fumetto degli episodi */
  try{ if (typeof ccAperta === 'function' && ccAperta()){ ccChiudi(); return true; } }catch(_){ }   /* la schermata del carburante (carburante-costo.js) */
  /* 0.9.296: il filmato del monito (e la sua schermata nera) si chiude con Indietro, come ogni velo */
  try{ if (document.getElementById('monWrap') && typeof monChiudi === 'function'){ monChiudi(); return true; } }catch(_){ }
  try{ if (typeof agPopoverBack === 'function' && agPopoverBack()) return true; }catch(_){ }   /* la chat dell'agente sopra la pagina (agente.js) */
  try{ if (typeof vsBack === 'function' && vsBack()) return true; }catch(_){ }   /* la pagina del diario della settimana (vita-settimane.js) */
  /* il report della settimana e' un velo sopra a tutto: indietro scorre le sue schermate */
  try{ if (typeof wkBack === 'function' && wkBack()) return true; }catch(_){ }
  /* nel primo avvio indietro e' indietro: un passo del film, non l'uscita dall'app */
  try{ if (typeof gnIndietro === 'function' && gnIndietro()) return true; }catch(_){ }
  /* il piano in Notion: prima i suoi menu, poi l'uscita (notion-ponte.js) */
  try{ if (typeof ntBack === 'function' && ntBack()) return true; }catch(_){ }
  /* le note (mappa-note.js): dentro una nota indietro torna all'elenco, poi esce */
  try{ if (typeof noBack === 'function' && noBack()) return true; }catch(_){ }
  /* i veli sopra la pagina: il popup del livello nuovo (levels.js), il cassetto delle conversazioni (agente.js) */
  try{ if (typeof lvFestaBack === 'function' && lvFestaBack()) return true; }catch(_){ }
  try{ if (typeof agCassettoBack === 'function' && agCassettoBack()) return true; }catch(_){ }
  try{ if (typeof calBack === 'function' && calBack()) return true; }catch(_){ }   /* il foglio del calendario (calendario.js) */
  try{ if (typeof stgBack === 'function' && stgBack()) return true; }catch(_){ }   /* i fogli della stagione, del punto prenotato e della settimana (stagione.js) */
  /* 0.9.291, Andrea: "aperto il popover della serie (o del percorso) e premuto indietro di Android, si chiude l'app
     invece del popover. Il popover e' una pagina aperta". Prima di uscire o di cambiare pagina si chiude il velo piu' in
     alto, con la sua X (o toccando fuori, come farebbe il dito). */
  try{ if (navChiudiVelo()) return true; }catch(_){ }
  /* 0.9.304, Andrea: con le impostazioni del Full Focus aperte, indietro portava alla scheda START invece di
     chiudere il foglio. Il foglio del Full Focus sta sotto al livello 100 che navVeloAperto cerca (z-index 75,
     per stare sotto alla barra del timer): si chiude qui, per nome. */
  try{ const fw = document.getElementById('ffSheetWrap'); if (fw && fw.classList.contains('open') && typeof ffSheetClose === 'function'){ ffSheetClose(); return true; } }catch(_){ }
  /* 0.9.305, Andrea: durante la lettura del Genio indietro chiudeva l'app. La lettura (#orWrap, z-index 72) sta sotto
     al livello 100 di navVeloAperto: torna al passo di prima, e dal primo si chiude (oracle.js, orBack) */
  try{ if (typeof orBack === 'function' && orBack()) return true; }catch(_){ }
  if(order[cur]==='s-home') return false;
  /* Col timer acceso la pagina della concentrazione non ha uscite: nemmeno il tasto indietro
     di Android. L'unica porta e' rinunciare, e sta dentro alla pagina. */
  if(order[cur]==='s-fullfocus' && typeof FF !== 'undefined' && FF && FF.run
     && !(typeof ffInGrace === 'function' && ffInGrace())){
    toast('Il timer va: per uscire, rinuncia');
    return true;
  }
  // The appended screens are not a step in the onboarding line: walking to cur-1 would drop
  // the user into the block list. They go back where they were summoned from.
  if(order[cur]==='s-restricted'){ closeRestricted(); return true; }
  // A screen registered by a module declares where its back leads; without this it would fall
  // to cur-1, which for an appended screen is whatever happened to be registered before it.
  const qui = order[cur];
  const dest = BACK_TO[qui];
  const d = dest ? (typeof dest === 'function' ? dest() : dest) : null;
  /* il modulo vuole restare qui (un passo indietro dentro la stessa pagina), o si e' gia' spostato da solo */
  if (dest && (d === null || d === undefined || d === qui || order[cur] !== qui)) return true;
  if (navTornaDietro(qui)) return true;
  if(d){ goId(d); return true; }
  if(cur>0){ go(cur-1); return true; }
  return false;
}
/** Il velo (popover, foglio, pannello) aperto piu' in alto, o null. Un velo copre lo schermo intero, sta sopra alle
    pagine e si vede; dentro ha una X o si chiude toccando fuori. */
function navVeloAperto(){
  const vw = window.innerWidth || 360, vh = window.innerHeight || 640;
  const cand = [];
  const guarda = function(el){
    if (!el || el.nodeType !== 1 || el.hidden) return;
    if (el.classList.contains('screen') || el.id === 'toast' || el.id === 'phone' || el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
    if (el.getAttribute('data-velo') === 'no') return;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || +cs.opacity < 0.05 || cs.pointerEvents === 'none') return;
    if (cs.position !== 'fixed' && cs.position !== 'absolute') return;
    const z = parseInt(cs.zIndex, 10) || 0; if (z < 100) return;
    /* sul tablet (e su BlueStacks) l'app sta in una cornice da telefono piu' stretta dello schermo: si misura sulla cornice */
    const b = el.getBoundingClientRect(), pr = el.parentElement && el.parentElement !== document.body ? el.parentElement.getBoundingClientRect() : null;
    const cw = pr ? pr.width : vw, ch = pr ? pr.height : vh;
    if (b.width < cw * 0.9 || b.height < ch * 0.85) return;
    cand.push({ el: el, z: z });
  };
  Array.prototype.forEach.call(document.body.children, guarda);
  const ph = document.getElementById('phone'); if (ph) Array.prototype.forEach.call(ph.children, guarda);
  if (!cand.length) return null;
  cand.sort(function(a, b){ return b.z - a.z; });
  return cand[0].el;
}
function navChiudiVelo(){
  const v = navVeloAperto(); if (!v) return false;
  const x = v.querySelector('[aria-label="Chiudi"],[aria-label="Chiudi il foglio"],.hd-x,[data-chiudi]');
  if (x && x.offsetParent !== null){ x.click(); return true; }
  /* niente X: il tocco fuori dal foglio (e.target === velo) */
  const stato = function(){ return v.className + '|' + v.hidden + '|' + document.body.contains(v) + '|' + v.style.display; };
  const prima = stato();
  try{ v.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); }catch(_){ v.click(); }
  /* se il velo non si e' mosso (non si chiude toccando fuori) il tasto indietro fa il suo solito giro */
  return stato() !== prima;
}
/** Torna alla schermata da cui si era arrivati (e alla sua scheda). False se la storia e' vuota. */
function navTornaDietro(qui){
  let e = NAV_STORIA.pop();
  while (e && e.s === qui) e = NAV_STORIA.pop();
  if (!e || order.indexOf(e.s) < 0) return false;
  NAV_INDIETRO = true;
  try{ goId(e.s); }finally{ NAV_INDIETRO = false; }
  if (e.s === 's-home' && e.tab){ try{ switchTab(e.tab); }catch(_){ } }
  return true;
}
/** Per i pulsanti indietro delle pagine: come il tasto indietro del telefono. */
function flIndietro(){ if (!handleBack()) goId('s-home'); }
/* I pulsanti "indietro" in alto a sinistra che portano a una pagina fissa (goId(...)) passano dalla storia:
   cosi' tornano dove eri anche nelle pagine scritte prima di questa regola. */
document.addEventListener('click', function(ev){
  const b = ev.target && ev.target.closest && ev.target.closest('.screen > .topbar > button.iconbtn:first-child');
  if (!b) return;
  const oc = b.getAttribute('onclick') || '';
  if (oc.indexOf('goId(') < 0) return;
  if (!NAV_STORIA.length) return;
  ev.preventDefault(); ev.stopImmediatePropagation();
  flIndietro();
}, true);
function skipAll(){ go(order.indexOf('s-home')); }
function toast(msg){
  const t=document.getElementById("toast");
  t.textContent=msg;t.classList.add("show");
  clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove("show"),2200);
}

/* ---------- TAB SWITCHING ---------- */
/* 27/09/2026: Blocco non e' piu' una scheda ma una pagina (porte.js). Le schede sono Rotta,
   Mappa, Roadmap (severa), START (sveglia) e Profilo; il Report resta raggiungibile. */
const TABS=["rotta","mappa","severa","sveglia","insights","profilo"];
// Only the Report keeps a word in the header: the other tabs open on a sky, and a title over
// a sky fights the words on it.
const TITLES={rotta:"",mappa:"",blocco:"",severa:"",sveglia:"",insights:"Report",profilo:""};
function switchTab(name){
  /*
   * A tab name that no longer exists must not take the shell down with it.
   *
   * Updating from a build that had one tab more, with that tab open, left "members" in
   * fl_tab. The line below that reads tab-<name>.scrollTop then threw on a missing element,
   * switchTab aborted half way, and the home screen came up with NO tab selected and
   * "undefined" as its title. Anything not in TABS falls back to the first one.
   */
  /* «blocco» e' una pagina: dopo l'avvio si apre quella, all'avvio si atterra sulla Rotta. */
  if (name === 'blocco'){ if (window.__flAvviato && typeof blPaginaApri === 'function') blPaginaApri(); name = 'rotta'; }
  /* La Roadmap non e' piu' una scheda (0.9.169): chi chiede «severa» vuole la Modalita' severa,
     che ha la sua pagina. All'avvio si atterra sulla Rotta. */
  if (name === 'severa'){ if (window.__flAvviato && typeof svpApri === 'function'){ svpApri(); return; } name = 'rotta'; }
  if (TABS.indexOf(name) < 0) name = TABS[0];
  const prima = navTabCorrente();
  if (prima && prima !== name) navScrollSalva(prima);
  /* un tocco sulla scheda che e' gia' aperta (la barra in basso) la riporta in cima */
  let ritocco = false;
  try{ const ev = window.event; ritocco = prima === name && ev && ev.type === 'click' && ev.target && ev.target.closest && !!ev.target.closest('#nav-' + name); }catch(_){ }
  TABS.forEach(t=>{
    document.getElementById("tab-"+t).classList.toggle("on",t===name);
    // Il Report non ha più un pulsante in basso: ci si arriva dal Profilo o dal menu. La
    // scheda però esiste ancora, e switchTab('insights') deve continuare a funzionare.
    const b = document.getElementById("nav-"+t);
    /* la Mappa sta dentro alla scheda Sogno: in basso resta acceso Dream */
    if (b) b.classList.toggle("on", t===name);
  });
  /* Dream ricorda dove eri: tornandoci dalla barra in basso si riapre Sogno o Mappa */
  if (name === 'rotta' || name === 'mappa'){ try{ localStorage.setItem('fl_dream_sub', name); }catch(_){ } }
  document.getElementById("headTitle").textContent=TITLES[name];
  if (ritocco){ NAV_SCROLL[name] = 0; const tt = document.getElementById("tab-"+name); try{ tt.scrollTo({ top: 0, behavior: 'smooth' }); }catch(_){ tt.scrollTop = 0; } }
  else if (prima !== name) navScrollRipristina(name);
  hdrTodayApply();
  localStorage.setItem('fl_tab', name); // survive a relaunch on the same tab
  document.dispatchEvent(new CustomEvent('fl:tab', { detail: name }));
  syncNative();
}

function esc(s){ return String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }

function fmtMin(m){ m=Math.round(m||0); return m<60 ? m+'m' : Math.floor(m/60)+'h '+String(m%60).padStart(2,'0')+'m'; }

/* The time pill shows on the first two slides of the Blocco tab and nowhere else: under the
   phrase of the day and on the other tabs it was one more thing pulling at the eye. */
function hdrTodayAllowed(){
  /* La pillola del tempo di schermo si vede quando in Personalizza si e' scelta lei al posto
     della bolla della partita (porte.js: hdrBolla). */
  try{ return (typeof hdrBolla === 'function') ? hdrBolla() === 'tempo' : false; }catch(_){ return false; }
}
function hdrTodayApply(){
  const b = document.getElementById('hdrToday');
  if (!b) return;
  b.hidden = !(hdrTodayAllowed() && b.dataset.ready === '1');
  try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  hdrDreamApply();
}

/* LA SCHEDA DREAM. Sogno e Mappa sono le due facce di «The Dream Map»: in basso c'e' una
   scheda sola, Dream, e un interruttore con due posizioni: 🧭 Sogno (la scheda che era la Rotta)
   e 🗺️ Mappa (la mappa alla Duolingo). I nomi interni restano 'rotta' e 'mappa':
   switchTab('mappa') continua a funzionare ovunque.
     0.9.182 nell'intestazione · 0.9.183 sopra allo slideshow (esperimenti)
     0.9.184: SOTTO ALLE NUVOLE, primo elemento della pagina dopo lo slideshow: in Sogno in cima a
     .nv-page (sopra alla lettura del Genio), in Mappa subito dopo il cielo. L'intestazione resta
     quella delle altre schede. Si disegna anche al primo avvio, non solo cambiando scheda.
     0.9.185: di nuovo SOTTO ALL'INTESTAZIONE, sopra a tutto, con la pillola bianca; in Sogno sotto
     c'e' il pannello dell'arrivo previsto, poi lo slideshow. */
/** Dalla barra in basso: la faccia di Dream dove eri rimasto (Sogno o Mappa). */
function dreamUltima(){ let v = ''; try{ v = localStorage.getItem('fl_dream_sub') || ''; }catch(_){ } return v === 'mappa' ? 'mappa' : 'rotta'; }
function hdrInDream(){
  const r = document.getElementById('tab-rotta'), m = document.getElementById('tab-mappa');
  return !!((r && r.classList.contains('on')) || (m && m.classList.contains('on')));
}
function hdrDreamApply(){
  let w = document.getElementById('dreamSw');
  if (!w){
    w = document.createElement('div'); w.id = 'dreamSw'; w.className = 'dream-sw';
    w.innerHTML = '<div class="hdr-dream" id="hdrDream" role="tablist" data-cg-no><i class="hdr-dream-k"></i>'
      + '<button type="button" id="hdrDreamSogno" role="tab" onclick="switchTab(\'rotta\')">🧭 Sogno</button>'
      + '<button type="button" id="hdrDreamMappa" role="tab" onclick="switchTab(\'mappa\')">🗺️ Mappa</button></div>';
  }
  const mt = document.getElementById('tab-mappa');
  const mappa = !!(mt && mt.classList.contains('on'));
  /* dove va (0.9.185): sotto all'intestazione, primo elemento della pagina accesa; in Sogno
     subito sotto c'e' il pannello dell'arrivo previsto, poi lo slideshow */
  /* in Sogno sta dentro al blocco «Sogno, Mappa e arrivo previsto» (0.9.186: si sposta con lui) */
  const blocco = !mappa ? document.getElementById('nvArrBlock') : null;
  const casa = blocco || document.getElementById(mappa ? 'tab-mappa' : 'tab-rotta');
  if (casa && casa.firstElementChild !== w) casa.insertBefore(w, casa.firstChild);
  const d = document.getElementById('hdrDream');
  const s = document.getElementById('hdrDreamSogno'), m = document.getElementById('hdrDreamMappa');
  if (mappa){
    /* NELLA MAPPA (0.9.205): a sinistra chi si pianifica tutto da sé (appunti, le sue pagine, la
       rotta di oggi), a destra la rotta su misura del Genio, che e' la parte Premium */
    let prem = false; try{ prem = !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ }
    const v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta';
    s.innerHTML = '🗺️ Mappa<small>pianifica tu</small>'; s.setAttribute('onclick', "mppVista('mia')");
    m.innerHTML = '🛣️ Roadmap<small>l’autostrada verso il sogno</small>'; m.setAttribute('onclick', "mppVista('rotta')");
    d.classList.toggle('mappa', v === 'rotta');
    /* scelta fatta nell'effetto farfalla: niente interruttore, solo la vista scelta */
    d.classList.toggle('scelta-fatta', !!(typeof mppSceltaFatta === 'function' && mppSceltaFatta()));
    s.classList.toggle('on', v === 'mia'); m.classList.toggle('on', v === 'rotta');
    s.setAttribute('aria-selected', v === 'mia' ? 'true' : 'false'); m.setAttribute('aria-selected', v === 'rotta' ? 'true' : 'false');
  } else {
    s.innerHTML = '🧭 Sogno'; s.setAttribute('onclick', "switchTab('rotta')");
    m.innerHTML = '🗺️ Mappa'; m.setAttribute('onclick', "switchTab('mappa')");
    d.classList.toggle('mappa', false);
    d.classList.toggle('scelta-fatta', false);
    s.classList.toggle('on', true); m.classList.toggle('on', false);
    s.setAttribute('aria-selected', 'true'); m.setAttribute('aria-selected', 'false');
  }
}
document.addEventListener('DOMContentLoaded', function(){
  [400, 1200, 2500].forEach(function(ms){ setTimeout(function(){ try{ hdrDreamApply(); if (typeof flHeaderSync === 'function') flHeaderSync(); }catch(_){ } }, ms); });
});

/* Re-check everything whenever the app returns to the foreground (after a Settings trip). */
async function refreshHeaderToday(){
  const b = document.getElementById('hdrToday'), t = document.getElementById('hdrTodayTxt');
  if(!b || !t || !NATIVE || !NATIVE.getScreenTimeToday) return;
  try{
    const st = await NATIVE.getScreenTimeToday();
    if(!st || !st.granted){ b.hidden = true; b.dataset.ready = '0'; return; }
    b.dataset.ready = '1';
    const m = st.minutes || 0;
    t.textContent = (m >= 60 ? Math.floor(m/60) + 'h ' : '') + (m % 60) + 'm';
    // With a daily goal the counter is a traffic light: green under three quarters of it,
    // yellow up to the goal, red past it.
    let goal = 0; try{ goal = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ }
    b.classList.remove('hdr-ok', 'hdr-warn', 'hdr-over');
    if(goal > 0) b.classList.add(m < goal * 0.75 ? 'hdr-ok' : (m <= goal ? 'hdr-warn' : 'hdr-over'));
    b.hidden = !hdrTodayAllowed();
  }catch(_){ b.hidden = true; }
}
function syncNative(){
  refreshHeaderToday();
  refreshServiceBanner();
  if (typeof refreshPerms === 'function') refreshPerms();
  refreshScreenTime();
  refreshUsageReveal();
  renderPrograms();
}
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden) syncNative(); });

/* init */
renderProfile();
setStrict(+(localStorage.getItem("fl_strict")||0));

// If onboarding was already completed, land on the home shell — and on the tab last used —
// instead of replaying the whole quiz. This is what stops the app "resetting" on every launch
// and after returning from the background.
// registry.js already put the right screen on screen before the first paint; all that is
// left here is to tell the navigator where we are.
if(LANDING === 's-home'){
  cur = order.indexOf('s-home');
  switchTab(localStorage.getItem('fl_tab') || 'rotta');
}
window.__flAvviato = true;
/* LA TASTIERA.
   Quando si apre, la barra delle quattro schede restava disegnata sopra ai tasti: il menu
   dell'app in mezzo alla tastiera del telefono. E il pulsante del microfono, che sta in fondo
   al foglio, finiva sotto. Qui si misura quanto spazio si e' preso la tastiera e lo si dice a
   tutta la pagina con una variabile: chi deve nascondersi si nasconde, chi deve salire sale.
   La misura e' contro l'altezza MASSIMA vista, non contro window.innerHeight: con
   adjustResize si accorcia anche quella e la differenza sarebbe sempre zero. */
(function flKeyboard(){
  const vv = window.visualViewport;
  if (!vv) return;
  let maxH = 0, lastW = 0, maxWin = 0, kbdUltimo = '';
  const apply = function(){
    if (vv.width !== lastW){ lastW = vv.width; maxH = 0; maxWin = 0; }
    maxH = Math.max(maxH, vv.height);
    const gap = Math.max(0, Math.round(maxH - vv.height));
    const open = gap > 120;
    document.body.classList.toggle('kbd', open);
    document.documentElement.style.setProperty('--kbd', (open ? gap : 0) + 'px');
    /* Due mondi diversi. Se la FINESTRA si e' accorciata (adjustResize) allora tutto quello che
       e' fissato in fondo sta gia' sopra alla tastiera, e aggiungere l'altezza dei tasti lo
       manderebbe a meta' schermo. Se invece il sistema ha spinto su la pagina senza accorciare
       niente, quell'altezza serve davvero. Si distinguono guardando l'altezza della finestra:
       nel primo caso cala, nel secondo no. */
    maxWin = Math.max(maxWin, window.innerHeight || 0);
    const resized = (window.innerHeight || 0) <= maxWin - 60;
    const v = (open && !resized ? gap : 0) + 'px';
    if (v !== kbdUltimo){ kbdUltimo = v; document.documentElement.style.setProperty('--kbdfix', v); }   /* 0.9.263: solo se cambia */
  };
  vv.addEventListener('resize', apply);
  vv.addEventListener('scroll', apply);
  apply();
})();

/* LA TASTIERA.
   Quando si apre, la barra delle quattro schede restava disegnata sopra ai tasti: il menu
   dell'app in mezzo alla tastiera del telefono. E il pulsante del microfono, che sta in fondo
   al foglio, finiva sotto. Qui si misura quanto spazio si e' preso la tastiera e lo si dice a
   tutta la pagina con una variabile: chi deve nascondersi si nasconde, chi deve salire sale.
   La misura e' contro l'altezza MASSIMA vista, non contro window.innerHeight: con
   adjustResize si accorcia anche quella e la differenza sarebbe sempre zero. */
/* (il secondo guardiano della tastiera era una copia identica del primo: due ascoltatori
   per lo stesso lavoro, tolto) */

syncNative();
/* La splash resta su finche' la scheda Blocco non ha i suoi numeri veri: il blocco rapido
   letto dal motore e il pannello del tempo di schermo dipinto. Prima la splash se ne andava
   appena esisteva la WebView, e quello che c'era dopo era una finestra blu e poi la scheda
   con "0 app · 0 siti" e il pannello vuoto, che si riempivano qualche secondo dopo. Un tetto
   di quattro secondi e mezzo, perche' una splash che non se ne va e' peggio dello sfarfallio. */
(function flBootReady(){
  const done = function(){
    /* appReady l'ha gia' chiamata boot.js appena la sua schermata era a video: qui si ripete
       per i casi in cui quel file non ci fosse, ed e' innocuo perche' togliere una schermata
       gia' tolta non fa niente. */
    try{ if (NATIVE && NATIVE.appReady) NATIVE.appReady(); }catch(_){ }
    /* La schermata di caricamento se ne va quando c'e' qualcosa di vero da mostrare, non
       quando esiste la WebView: e' la differenza fra "0 app, 0 siti, Inizia" su un blocco che
       era acceso e la scheda giusta al primo sguardo. */
    try{ if (typeof bootDone === 'function') bootDone(); }catch(_){ }
  };
  const step = function(p){ try{ if (typeof bootTo === 'function') bootTo(p); }catch(_){ } };
  step(0.3);
  const jobs = [];
  const watch = function(pr, p){
    try{ jobs.push(Promise.resolve(pr).then(function(v){ step(p); return v; }, function(e){ step(p); throw e; })); }
    catch(_){ }
  };
  try{ if (typeof loadQuick === 'function') watch(loadQuick(), 0.6); }catch(_){ }
  try{ if (typeof scBlockScores === 'function') watch(scBlockScores(), 0.9); }catch(_){ }
  const cap = new Promise(function(res){ setTimeout(res, 4500); });
  Promise.race([Promise.allSettled(jobs), cap]).then(function(){ requestAnimationFrame(function(){ setTimeout(done, 80); }); });
})();
if("serviceWorker" in navigator){navigator.serviceWorker.register("sw.js").catch(()=>{})}
