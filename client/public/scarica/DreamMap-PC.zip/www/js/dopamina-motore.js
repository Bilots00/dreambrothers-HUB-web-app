/* ---------------------------------------------------------------------------------------
   DOPAMINA — IL MOTORE

   Una giornata, un minuto alla volta. Tre grandezze:
     S  il livello di fondo: torna verso la base (in fretta da sotto, piano da sopra) e sale
        con le azioni sane — sforzo portato a termine, sonno, movimento, pause, costanza;
     D  il debito lasciato dalla stimolazione rapida: cresce durante la sessione e si
        riassorbe del 15% all'ora;
     P  il picco della stimolazione, che sale durante la sessione e si spegne in ~45 minuti.

   LA RISERVA (il tachimetro) e' S − D: lo scroll non la alza mai, nemmeno per un minuto.
   LA STIMOLAZIONE (la curva) e' il picco mentre sei dentro alla sessione, e P − D fuori:
   quando esci il debito si vede tutto insieme, ed e' il crollo.

   PERCHE' GLI INSIGHT TORNANO SEMPRE. Ogni minuto la variazione della riserva si divide fra
   le sue cause — il debito che una sessione accumula, il debito che si riassorbe, il ritorno
   verso la base, l'uso leggero, l'evento puntuale (sonno, full focus, camminata…) — e ogni
   pezzo va sulla voce della sua causa. La somma delle voci e' quindi, per costruzione, la
   differenza fra la riserva di adesso e quella di partenza — e un controllo lo verifica.

   Il motore e' PURO: niente pagina, niente telefono, niente orologio. Riceve i fatti della
   giornata e restituisce il risultato. Cosi' si prova fuori dall'app (tools/test-dopamina.js)
   e il numero, la curva e gli insight escono dallo stesso calcolo.
   --------------------------------------------------------------------------------------- */

/* ---- categorie ---- */
function dmCat(di){
  if (!(di > 0)) return 'neutro';
  if (di >= 0.8) return 'alto';
  if (di <= 0.1) return 'prod';
  return 'medio';
}
function dmLerp(a, b, x){ x = Math.max(0, Math.min(1, x)); return a + (b - a) * x; }
function dmNotte(t, cfg){ const h = new Date(t).getHours(); return h >= cfg.notteDa && h < cfg.notteA; }
function dmClamp(v, cfg){ return Math.max(cfg.min, Math.min(cfg.max, v)); }
/** Il primo scalino raggiunto di una tabella [[soglia, valore], …]. */
function dmScalino(tab, min){
  const r = tab.slice().sort(function(a, b){ return b[0] - a[0]; }).filter(function(x){ return min >= x[0]; })[0];
  return r ? r[1] : 0;
}

/**
 * Il bonus di una sessione FullFocus: si interpola fra i punti della tabella. Sotto il primo
 * punto niente, oltre l'ultimo il tetto.
 */
function dmFFBonus(min, cfg){
  const t = cfg.ffBonus;
  if (!(min >= t[0][0])) return 0;
  if (min >= t[t.length - 1][0]) return t[t.length - 1][1];
  for (let i = 1; i < t.length; i++){
    if (min <= t[i][0]) return t[i - 1][1] + (t[i][1] - t[i - 1][1]) * (min - t[i - 1][0]) / (t[i][0] - t[i - 1][0]);
  }
  return t[t.length - 1][1];
}

/**
 * I granelli si puliscono prima di contare.
 * Solo granelli con orario vero, tagliati alla finestra; lo stesso evento arrivato due volte
 * (stesso dispositivo, stessa app, inizio entro ±5 s) conta una volta; su UNO STESSO
 * dispositivo due cose in primo piano non possono sovrapporsi: se succede si scrive l'errore
 * e si tiene la piu' affidabile (la piu' lunga).
 */
function dmPulisci(grani, from, to, cfg){
  const errori = [];
  const per = {};
  (grani || []).forEach(function(g){
    if (!g || g.stimato || !(g.ms > 0) || !(g.s < to) || !(g.s + g.ms > from)) return;
    const s = Math.max(from, g.s), e = Math.min(to, g.s + g.ms);
    if (e <= s) return;
    const dev = g.dev || g.fonte || 'telefono';
    (per[dev] = per[dev] || []).push(Object.assign({}, g, { s: s, ms: e - s, e: e, dev: dev }));
  });
  const out = [];
  Object.keys(per).forEach(function(dev){
    const l = per[dev].sort(function(a, b){ return a.s - b.s || b.ms - a.ms; });
    const tenuti = [];
    l.forEach(function(g){
      const prec = tenuti[tenuti.length - 1];
      if (prec && prec.p === g.p && Math.abs(prec.s - g.s) <= cfg.dedupeMs){
        if (g.ms > prec.ms){ tenuti[tenuti.length - 1] = g; }
        return;
      }
      if (prec && g.s < prec.e - 2000){
        errori.push({ tipo: 'sovrapposti', dev: dev, a: { p: prec.p, s: prec.s, ms: prec.ms }, b: { p: g.p, s: g.s, ms: g.ms } });
        if (g.ms > prec.ms) tenuti[tenuti.length - 1] = g;
        return;
      }
      if (prec && g.s < prec.e){ g = Object.assign({}, g, { s: prec.e, ms: g.e - prec.e }); if (g.ms <= 0) return; }
      tenuti.push(g);
    });
    tenuti.forEach(function(g){ out.push(g); });
  });
  out.sort(function(a, b){ return a.s - b.s; });
  return { grani: out, errori: errori };
}

/** Le sessioni ad alta intensita': pezzi di app «alte» vicini fra loro, per almeno 10 minuti. */
function dmSessioni(grani, cfg){
  const alti = grani.filter(function(g){ return dmCat(g.di) === 'alto'; });
  const out = [];
  let cur = null;
  alti.forEach(function(g){
    if (cur && g.s - cur.e <= cfg.altoBuco){
      cur.e = Math.max(cur.e, g.e); cur.ms += g.ms; cur.pezzi.push(g);
    } else {
      if (cur) out.push(cur);
      cur = { s: g.s, e: g.e, ms: g.ms, pezzi: [g] };
    }
  });
  if (cur) out.push(cur);
  return out.filter(function(x){ return x.ms >= cfg.altoMinMin * 60000; }).map(function(x){
    const min = x.ms / 60000;
    const f = (min - cfg.piccoMinPer[0]) / (cfg.piccoMinPer[1] - cfg.piccoMinPer[0]);
    const grigio = x.pezzi.filter(function(g){ return g.grigio; }).reduce(function(a, g){ return a + g.ms; }, 0) > x.ms / 2;
    const kg = grigio ? cfg.grigio : 1;
    const app = {};
    x.pezzi.forEach(function(g){ const k = g.l || g.p; app[k] = (app[k] || 0) + g.ms; });
    const nomi = Object.keys(app).sort(function(a, b){ return app[b] - app[a]; });
    const devs = {}; x.pezzi.forEach(function(g){ devs[g.dev] = 1; });
    return { s: x.s, e: x.e, min: min, app: nomi[0], apps: nomi, devs: Object.keys(devs),
             picco: dmLerp(cfg.picco[0], cfg.picco[1], f) * kg,
             debito: dmLerp(cfg.debito[0], cfg.debito[1], f) * kg * (dmNotte(x.s, cfg) ? cfg.notteX : 1) };
  }).map(function(x, i, l){
    /* LA COMBO NEGATIVA (0.9.298). Ogni picco entro tre ore dal precedente moltiplica il suo debito:
       x1, x1,25, x1,5, x1,75, x2 (il tetto). I limiti di sempre restano: ±5 a evento, -8 in un'ora. */
    const fattori = cfg.comboDebito || [1, 1.25, 1.5, 1.75, 2];
    let fila = 0;
    for (let j = i; j > 0; j--){ if (l[j].s - l[j - 1].e <= (cfg.comboFinestraMin || 180) * 60000) fila++; else break; }
    x.combo = fattori[Math.min(fila, fattori.length - 1)];
    x.debito = x.debito * x.combo;
    return x;
  });
}

/* 0.9.317, Andrea: "non sono mai uscito da DreamMap, sto solo cambiando pagina, e me lo conta come cambio d'app". LA CAUSA: qui contava
   ogni cosa in primo piano. DreamMap stessa, la schermata home, la tendina, lo strumento degli screenshot erano "app"; un passaggio
   dalla home contava due volte; e telefono e computer stavano nella stessa fila, quindi due schermi accesi insieme
   facevano un salto a ogni pezzo. Adesso un cambio e' passare da un'app vera a un'altra, sullo stesso dispositivo, restandoci almeno
   qualche secondo. Copia di CarburanteStima.nonConta (il nativo). */
/* 0.9.319, Andrea: "nessuno chiama com.google.android.photopicker un'app". Le schermate di sistema (il selettore delle foto, i file, i
   permessi) non sono un salto d'app. E se un'app non ha il nome, si dice l'ultimo pezzo del pacchetto, mai il pacchetto. */
const DM_NOMI = { photopicker: 'Selettore foto', documentsui: 'File', permissioncontroller: 'Permessi', packageinstaller: 'Installazione app', intentresolver: 'Scelta app' };
function dmNomeBello(n){
  const s = String(n == null ? '' : n).trim();
  if (!/^(com|org|net|android|io|de|ru|tv|me)\.[a-z0-9_.]+$/i.test(s) || /\.(com|org|net|it|io|de|tv|me|app)$/i.test(s)) return s;
  const pz = s.split('.'); const ult = pz[pz.length - 1].toLowerCase();
  if (DM_NOMI[ult]) return DM_NOMI[ult];
  const via = pz.filter(function(x, i){ return i > 0 && !/^(android|app|apps|mobile|client|google|samsung|sec|main|lite)$/i.test(x); });
  const v = via.length ? via[via.length - 1] : pz[pz.length - 1];
  return v.charAt(0).toUpperCase() + v.slice(1);
}
function dmNomiNelTesto(t){ return String(t == null ? '' : t).replace(/\b(com|org|net|android)\.[a-z0-9_]+(\.[a-z0-9_]+)+/gi, function(x){ return dmNomeBello(x); }); }
const DM_NON_APP = ['photopicker', 'documentsui', 'permissioncontroller', 'packageinstaller', 'intentresolver', '.settings', 'dialer', 'incallui', '.contacts', 'deskclock', '.clockpackage', '.clock', 'calculator', '.calendar', '.camera',
  'documentsui', '.myfiles', '.files', 'inputmethod', 'keyboard', 'honeyboard', '.packageinstaller', '.permissioncontroller', 'launcher',
  'smartcapture', 'screenshot', 'screenrecorder', 'cocktailbar', 'systemui'];
const DM_NON_APP_PC = /^(dreammap|focuslock|explorer|esplora|desktop|searchhost|searchapp|shellexperiencehost|startmenuexperiencehost|lockapp|applicationframehost|taskmgr|textinputhost)\b/;
function dmNonConta(p){
  const x = String(p || '').toLowerCase();
  if (!x || x === 'android' || x.indexOf('com.dreambrothers.focuslock') === 0) return true;
  if (DM_NON_APP_PC.test(x)) return true;
  return DM_NON_APP.some(function(k){ return x.indexOf(k) >= 0; });
}
/** I cambi d'app: da un'app vera a un'altra, ogni dispositivo per conto suo. */
function dmCambi(grani, cfg){
  const out = [], prec = {};
  const min = (cfg && cfg.dispMinMs) || 3000;
  grani.forEach(function(g){
    if (dmNonConta(g.p) || (g.e - g.s) < min) return;
    const dev = g.dev || 'telefono';
    if (g.p !== prec[dev]){ if (prec[dev]) out.push({ t: g.s, dev: dev, p: g.p, l: g.l || g.p }); prec[dev] = g.p; }
  });
  return out;
}
/** "Instagram, Chrome e altre 2": le app di una finestra, dalla piu' frequente. */
function dmAppDelCambio(cambi){
  const conti = {};
  cambi.forEach(function(c){ conti[c.l] = (conti[c.l] || 0) + 1; });
  const nomi = Object.keys(conti).sort(function(a, b){ return conti[b] - conti[a]; });
  if (nomi.length <= 2) return nomi.join(' e ');
  if (nomi.length === 3) return nomi[0] + ', ' + nomi[1] + ' e ' + nomi[2];
  return nomi[0] + ', ' + nomi[1] + ' e altre ' + (nomi.length - 2);
}

/**
 * La dispersione, per densita' e non per evento. Una finestra di dieci minuti che parte dal
 * primo cambio non ancora contato: oltre 5 cambi -0,3, oltre 10 -0,6. I cambi di una finestra
 * penalizzata sono consumati: non si contano due volte.
 */
function dmDispersione(cambi, cfg){
  const out = [];
  const W = cfg.dispFinestraMin * 60000;
  let i = 0;
  while (i < cambi.length){
    const t0 = cambi[i].t;
    let j = i;
    while (j < cambi.length && cambi[j].t < t0 + W) j++;
    const n = j - i;
    const soglia = cfg.dispSoglie.filter(function(x){ return n > x[0]; })[0];
    if (soglia){
      out.push({ s: t0, e: cambi[j - 1].t, n: n, app: dmAppDelCambio(cambi.slice(i, j)), delta: soglia[1] * (dmNotte(t0, cfg) ? cfg.notteX : 1) });
      i = j;
    } else i++;
  }
  return out;
}

/** Le camminate: minuti con abbastanza passi, di fila, senza il telefono in mano e fuori dagli allenamenti. */
function dmCamminate(passi, grani, allenamenti, cfg){
  const uso = function(t){ return grani.some(function(g){ return g.dev === 'telefono' && g.s < t + 60000 && g.e > t; }); };
  const allena = function(t){ return (allenamenti || []).some(function(a){ return a.s < t + 60000 && a.e > t; }); };
  const min = (passi || []).slice().sort(function(a, b){ return a.t - b.t; });
  const out = [];
  let cur = null;
  min.forEach(function(m){
    const cammina = m.n >= cfg.cammMinPassiMin && !uso(m.t) && !allena(m.t);
    if (!cammina) return;
    if (cur && m.t - cur.e <= (cfg.cammBucoMin + 1) * 60000){ cur.e = m.t + 60000; cur.passi += m.n; cur.min++; }
    else { if (cur) out.push(cur); cur = { s: m.t, e: m.t + 60000, passi: m.n, min: 1 }; }
  });
  if (cur) out.push(cur);
  return out.filter(function(b){ return b.passi >= cfg.cammMinPassi || b.min >= cfg.camm[0][0]; });
}

/** Le latenze di risposta alle notifiche, per fascia di due ore. */
function dmLatenze(notif, grani, from, to, cfg){
  const fasce = {};
  (notif || []).forEach(function(n){
    if (!(n.t >= from && n.t < to)) return;
    const g = grani.filter(function(x){ return x.p === n.p && x.s >= n.t && x.s - n.t <= cfg.latMaxMs; })[0];
    if (!g) return;
    const d = new Date(n.t); d.setMinutes(0, 0, 0);
    d.setHours(Math.floor(d.getHours() / cfg.latFasciaOre) * cfg.latFasciaOre);
    const k = d.getTime();
    (fasce[k] = fasce[k] || []).push(g.s - n.t);
  });
  const out = [];
  Object.keys(fasce).forEach(function(k){
    const s = +k, e = s + cfg.latFasciaOre * 3600000;
    const l = fasce[k].sort(function(a, b){ return a - b; });
    if (e > to || l.length < cfg.latMinCampioni) return;
    const med = l.length % 2 ? l[(l.length - 1) / 2] : (l[l.length / 2 - 1] + l[l.length / 2]) / 2;
    if (med < cfg.latSogliaMs) out.push({ s: s, e: e, n: l.length, mediana: med, delta: cfg.latPenalita * (dmNotte(s, cfg) ? cfg.notteX : 1) });
  });
  return out;
}

/** La concentrazione misurata: a lungo su una cosa produttiva sola, fuori da FullFocus. */
function dmFocus(grani, ff, cfg){
  const blocchi = [];
  let cur = null;
  grani.forEach(function(g){
    const prod = dmCat(g.di) === 'prod';
    if (cur && prod && g.p === cur.p && g.s - cur.e <= cfg.focusBuco){ cur.e = g.e; cur.ms += g.ms; return; }
    if (cur && (!prod || g.p !== cur.p) && g.dev === cur.dev){ blocchi.push(cur); cur = null; }
    if (prod && !cur) cur = { s: g.s, e: g.e, ms: g.ms, p: g.p, l: g.l || g.p, dev: g.dev };
  });
  if (cur) blocchi.push(cur);
  /* dentro a una sessione FullFocus la concentrazione la paga gia' FullFocus: una volta sola */
  const dentroFF = function(b){ return (ff || []).some(function(f){ return f.s < b.e && f.e > b.s; }); };
  return blocchi.filter(function(b){ return !dentroFF(b); }).map(function(b){
    const min = b.ms / 60000;
    const d = dmScalino(cfg.focus, min);
    return d ? { s: b.s, e: b.e, min: min, l: b.l, dev: b.dev, delta: d } : null;
  }).filter(Boolean);
}

/**
 * LA SIMULAZIONE.
 * inp = { from, to, s0, d0, p0, cfg,
 *         grani, sonni, passi, notif, allenamenti,
 *         ff        [{ s, e, min, tipo:'lavoro'|'meditazione', completata, stornato:{t,motivo}, l }]
 *         spunte    [{ t, l, nuova }]
 *         checkin   [{ t, tipo:'doccia' }]
 *         viste     [t]           le letture del messaggio dal tuo Io Futuro
 *         installazioni [{ t, p, l }]
 *         pianificato [{ s, e }]  le fasce pianificate
 *         serie     n             i giorni di fila con il piano (solo oggi)
 *         riprese, notifiche }
 */
function dmSimula(inp){
  const cfg = inp.cfg;
  const from = inp.from, to = Math.max(inp.from, inp.to);
  let S = (typeof inp.s0 === 'number') ? inp.s0 : cfg.base;
  let P = inp.p0 || 0;
  const debiti = (inp.d0 > 0) ? [{ k: 'ieri', v: inp.d0 }] : [];
  const Dtot = function(){ return debiti.reduce(function(a, d){ return a + d.v; }, 0); };
  const riserva = function(){ return dmClamp(S - Dtot(), cfg); };
  const start = riserva();
  const pul = dmPulisci(inp.grani, from, to, cfg);
  const grani = pul.grani, errori = pul.errori.slice();
  const N = Math.max(0, Math.ceil((to - from) / 60000));
  const idx = function(t){ return Math.floor((t - from) / 60000); };
  const dentro = function(t){ return t >= from && t < to; };

  /* --- il sonno: minuti fermi, e il recupero al risveglio --- */
  const fermo = new Uint8Array(N);
  const risvegli = {};
  (inp.sonni || []).forEach(function(z){
    if (!z || !(z.e > z.s)) return;
    const ore = (z.e - z.s) / 3600000;
    if (ore < cfg.sonnoMinOre) return;
    const passiDentro = (inp.passi || []).filter(function(m){ return m.t >= z.s && m.t < z.e; }).reduce(function(a, m){ return a + m.n; }, 0);
    if (passiDentro > cfg.sonnoPassiMax){ errori.push({ tipo: 'sonno-in-movimento', s: z.s, e: z.e, passi: passiDentro }); return; }
    for (let i = Math.max(0, idx(z.s)); i < Math.min(N, idx(z.e)); i++) fermo[i] = 1;
    if (z.e > from && z.e <= to) risvegli[Math.min(N - 1, idx(z.e))] = { s: z.s, e: z.e, ore: ore };
  });
  const primoRisveglio = Object.keys(risvegli).map(Number).sort(function(a, b){ return a - b; })[0];

  /* --- sessioni, uso, costi, camminate --- */
  const sess = dmSessioni(grani, cfg);
  const inSess = new Int16Array(N).fill(-1);
  sess.forEach(function(x, k){ for (let i = Math.max(0, idx(x.s)); i < Math.min(N, Math.ceil((x.e - from) / 60000)); i++) inSess[i] = k; });
  const minSess = sess.map(function(x, k){ let n = 0; for (let i = 0; i < N; i++) if (inSess[i] === k) n++; return Math.max(1, n); });
  const costo = new Float64Array(N);
  const uso = new Array(N);
  const occupato = new Uint8Array(N);                // qualunque schermo acceso (per la noia sana)
  grani.forEach(function(g){
    const cat = dmCat(g.di);
    for (let i = Math.max(0, idx(g.s)); i <= Math.min(N - 1, idx(g.e - 1)); i++){
      const t = from + i * 60000;
      const quota = Math.max(0, Math.min(t + 60000, g.e) - Math.max(t, g.s)) / 60000;
      if (!uso[i]) uso[i] = {};
      uso[i][g.l || g.p] = (uso[i][g.l || g.p] || 0) + quota;
      uso[i]['@' + g.dev] = 1;
      occupato[i] = 1;
      /* un'apertura sotto al minuto non costa niente: conta solo per la dispersione */
      if ((cat === 'medio' || cat === 'alto') && g.ms >= cfg.aperturaMaxMs && inSess[i] < 0){
        costo[i] += quota * g.di * cfg.costoMedioMin * (g.grigio ? cfg.grigio : 1) * (dmNotte(t, cfg) ? cfg.notteX : 1);
      }
    }
  });
  const ff = (inp.ff || []).filter(function(f){ return f && f.e > from && f.s < to; });
  const allen = (inp.allenamenti || []).filter(function(a){ return a && a.e > from && a.s < to; });
  const camm = dmCamminate(inp.passi, grani, allen, cfg);
  const inCamm = new Uint8Array(N);
  camm.forEach(function(b){ for (let i = Math.max(0, idx(b.s)); i < Math.min(N, idx(b.e)); i++) inCamm[i] = 1; });

  /* --- gli eventi puntuali, con l'ora in cui sono successi --- */
  const ist = [];
  const cambi = dmCambi(grani, cfg);
  dmDispersione(cambi, cfg).forEach(function(w){
    ist.push({ t: w.e, s: w.s, tipo: 'dispersione', l: 'Attenzione divisa', nota: w.n + ' salti fra ' + w.app, delta: w.delta, pen: true });
  });
  Object.keys(risvegli).forEach(function(k){
    const z = risvegli[k];
    const primo = grani.filter(function(g){ return g.s >= z.e && g.s < z.e + cfg.mattinaPulitaMin * 60000; });
    const scroll = primo.filter(function(g){ return dmCat(g.di) === 'alto' && g.s < z.e + cfg.mattinaScrollMin * 60000; })[0];
    if (scroll) ist.push({ t: scroll.s, tipo: 'mattina', l: 'Mattina iniziata sullo scroll', nota: (scroll.l || scroll.p), delta: cfg.mattinaScroll, pen: true });
    else if (z.e + cfg.mattinaPulitaMin * 60000 <= to && !primo.some(function(g){ return dmCat(g.di) === 'alto'; })){
      ist.push({ t: z.e + cfg.mattinaPulitaMin * 60000 - 60000, tipo: 'mattina', l: 'Mattina senza social', nota: 'i primi ' + cfg.mattinaPulitaMin + ' minuti', delta: cfg.mattinaPulita });
    }
  });
  dmLatenze(inp.notif, grani, from, to, cfg).forEach(function(b){
    ist.push({ t: b.e - 60000, s: b.s, tipo: 'latenza', l: 'Risposte in automatico',
               nota: 'mediana ' + Math.round(b.mediana / 1000) + ' s · ' + b.n + ' notifiche', delta: b.delta, pen: true });
  });
  dmFocus(grani, ff, cfg).forEach(function(b){
    if (b.e > to) return;
    ist.push({ t: b.e - 1, s: b.s, tipo: 'focus', l: 'Concentrazione su ' + b.l, nota: Math.round(b.min) + ' min', dev: b.dev, delta: b.delta });
  });

  /* FULL FOCUS: il bonus di concentrazione sui minuti fatti, e quello di completamento */
  const completamenti = [];
  ff.forEach(function(f){
    if (!(f.e <= to) || f.e < from) return;
    const min = Math.max(0, f.min || (f.e - f.s) / 60000);
    const med = f.tipo === 'meditazione';
    const base = med ? dmScalino(cfg.meditazione, min) : dmFFBonus(min, cfg);
    const comp = !med && f.completata ? cfg.ffCompletata : 0;
    if (!(base + comp > 0)) return;
    const m = Math.round(min);
    ist.push({ t: f.e - 1, s: f.s, tipo: med ? 'meditazione' : 'fullfocus',
               l: med ? 'Meditazione ' + m + ' min' : 'Full focus ' + m + ' min' + (comp ? ' + task completata' : ''),
               nota: f.l || '', dev: 'telefono', delta: base + comp });
    if (comp){
      completamenti.push(f.e);
      /* il completamento autodichiarato si puo' stornare: con la sua voce, all'ora dello storno */
      if (f.stornato && f.stornato.t && dentro(f.stornato.t)){
        ist.push({ t: f.stornato.t, tipo: 'storno', l: 'Completamento stornato', nota: f.stornato.motivo || 'la task risulta ancora aperta', delta: -comp });
      }
    }
  });
  /* le attivita' portate a termine; la prima volta di una cosa del piano vale di piu' */
  let spunte = 0, novita = 0;
  (inp.spunte || []).slice().sort(function(a, b){ return a.t - b.t; }).forEach(function(x){
    if (!dentro(x.t)) return;
    completamenti.push(x.t);
    if (x.nuova && novita + cfg.novitaSana <= cfg.novitaMaxGiorno + 1e-9){
      novita += cfg.novitaSana;
      ist.push({ t: x.t, tipo: 'novita', l: 'Una cosa nuova del piano', nota: x.l || '', delta: cfg.novitaSana });
      return;
    }
    const d = Math.min(cfg.spunta, cfg.spunteMaxGiorno - spunte);
    if (d <= 0) return;
    spunte += d;
    ist.push({ t: x.t, tipo: 'spunta', l: 'Attività completata', nota: x.l || '', delta: d });
  });
  /* gustarsi il risultato: cinque minuti senza app che spremono dopo una cosa fatta */
  let gusto = 0;
  completamenti.sort(function(a, b){ return a - b; }).forEach(function(tc, i){
    const fine = tc + cfg.gustoMin * 60000;
    if (fine > to || gusto + cfg.gusto > cfg.gustoMaxGiorno + 1e-9) return;
    if (completamenti[i + 1] !== undefined && completamenti[i + 1] < fine) return;   // una volta per gruppo
    const scroll = grani.some(function(g){ return dmCat(g.di) === 'alto' && g.s < fine && g.e > tc; });
    if (scroll) return;
    gusto += cfg.gusto;
    ist.push({ t: fine - 1, s: tc, tipo: 'gusto', l: 'Ti sei goduto il risultato', nota: cfg.gustoMin + ' min senza scroll', delta: cfg.gusto });
  });
  /* il movimento */
  camm.forEach(function(b){
    const d = dmScalino(cfg.camm, b.min);
    if (!d || b.passi < cfg.cammMinPassi) return;
    ist.push({ t: b.e - 1, s: b.s, tipo: 'camminata', l: 'Camminata senza telefono', nota: b.min + ' min · ' + b.passi.toLocaleString('it-IT') + ' passi', delta: d, mov: true });
  });
  allen.forEach(function(a){
    if (!(a.e <= to)) return;
    const min = (a.e - a.s) / 60000;
    const d = dmScalino(cfg.allenamento, min);
    if (!d) return;
    ist.push({ t: a.e - 1, s: a.s, tipo: 'allenamento', l: a.l || 'Allenamento', nota: Math.round(min) + ' min', delta: d, mov: true });
  });
  (function(){
    let tot = 0;
    const l = (inp.passi || []).filter(function(m){ return dentro(m.t); }).sort(function(a, b){ return a.t - b.t; });
    for (let i = 0; i < l.length; i++){
      tot += l[i].n;
      if (tot >= cfg.passiObiettivo){ ist.push({ t: l[i].t, tipo: 'passi', l: 'Obiettivo passi raggiunto', nota: cfg.passiObiettivo.toLocaleString('it-IT') + ' passi', delta: cfg.passiObiettivoBonus, mov: true }); break; }
    }
  })();
  /* i check-in autodichiarati: poco peso, un tetto */
  let doccia = false;
  (inp.checkin || []).forEach(function(c){
    if (!dentro(c.t)) return;
    if (c.tipo === 'doccia' && !doccia){ doccia = true; ist.push({ t: c.t, tipo: 'doccia', l: 'Doccia fredda', nota: 'dichiarata', delta: cfg.doccia, auto: true }); }
    /* 0.9.214: il carburante promesso dal foglio del tempo (task chiusa nel tempo) e la combo */
    else if (c.tipo === 'tempo' && isFinite(c.delta) && c.delta > 0) ist.push({ t: c.t, tipo: 'tempo', l: c.l || 'Task chiusa nel tempo', nota: c.nota || '', delta: Math.min(45, c.delta) });
  });
  /* la prima lettura del giorno del messaggio dal tuo Io Futuro: le riletture non contano.
     Sostituisce il vecchio bonus dei «progressi guardati»: non si sommano. */
  const vista = (inp.viste || []).filter(dentro).sort(function(a, b){ return a - b; })[0];
  if (vista) ist.push({ t: vista, tipo: 'iofuturo', l: 'Messaggio dal tuo Io Futuro', nota: 'la prima lettura di oggi', delta: cfg.ioFuturo });
  /* la costanza: la serie di giorni con il piano, una volta al giorno, al risveglio */
  if (inp.serie > 0){
    const t = primoRisveglio !== undefined ? from + primoRisveglio * 60000 : from;
    ist.push({ t: t, tipo: 'serie', l: 'Costanza', nota: inp.serie + (inp.serie === 1 ? ' giorno' : ' giorni') + ' di fila con il piano', delta: Math.min(cfg.serieMax, inp.serie * cfg.serieGiorno) });
  }
  /* la novita' fuori dal piano: un'app nuova installata dentro a una fascia pianificata */
  (inp.installazioni || []).forEach(function(x){
    if (!dentro(x.t)) return;
    const pian = (inp.pianificato || []).some(function(b){ return x.t >= b.s && x.t < b.e; });
    if (!pian) return;
    ist.push({ t: x.t, tipo: 'shiny', l: 'Novità fuori dal piano', nota: x.l || x.p || '', delta: cfg.novitaFuori, pen: true });
  });
  /* la noia sana: venti minuti da svegli senza schermi, senza focus e senza allenamento */
  (function(){
    let n = 0, corsa = 0;
    for (let i = 0; i < N; i++){
      const t = from + i * 60000;
      const h = new Date(t).getHours();
      const libero = !fermo[i] && !occupato[i] && h >= cfg.noiaDa && h < cfg.noiaA && !inCamm[i]
        && !ff.some(function(f){ return f.s <= t && f.e > t; }) && !allen.some(function(a){ return a.s <= t && a.e > t; });
      if (!libero){ corsa = 0; continue; }
      corsa++;
      if (corsa === cfg.noiaMin && n < cfg.noiaMaxGiorno){
        n++;
        ist.push({ t: t, s: t - (cfg.noiaMin - 1) * 60000, tipo: 'noia', l: 'Noia sana', nota: cfg.noiaMin + ' min senza schermi', delta: cfg.noia });
      }
    }
  })();
  const istPer = {};
  ist.forEach(function(e){ const i = Math.max(0, Math.min(N - 1, idx(e.t))); (istPer[i] = istPer[i] || []).push(e); });

  /* --- il registro: ogni minuto la variazione si divide fra le sue CAUSE --- */
  const voci = [];
  const penOra = {};
  const tettoOra = function(t, v){
    const h = Math.floor(t / 3600000);
    const gia = penOra[h] || 0;
    const ok = Math.max(0, Math.min(v, cfg.caloOraMax - gia));
    penOra[h] = gia + ok;
    return ok;
  };
  let movimento = 0, auto = 0;
  const aperte = {};
  const GAP = { uso: cfg.usoBucoMin * 60000 };
  const apri = function(key, t){
    let r = aperte[key];
    const gap = GAP[key] || 60000;
    if (r && t - r.fine > gap){ voci.push(r); r = null; }
    if (!r){
      const pezzi = key.split(':');
      r = aperte[key] = { chiave: key, tipo: pezzi[0], t: t, fine: t, min: 0, delta: 0, apps: {}, devs: {}, sess: pezzi[1] === 'ieri' ? -1 : +pezzi[1] };
      if (pezzi[1] === 'ieri') r.ieri = true;
    }
    return r;
  };
  const scrivi = function(key, t, delta, u){
    const r = apri(key, t);
    if (r.fine < t + 60000){ r.min += Math.round((t + 60000 - Math.max(r.fine, t)) / 60000); r.fine = t + 60000; }
    r.delta += delta;
    if (u) Object.keys(u).forEach(function(k){ if (k[0] === '@') r.devs[k.slice(1)] = 1; else r.apps[k] = (r.apps[k] || 0) + u[k]; });
  };
  const chiudiTutte = function(){ Object.keys(aperte).forEach(function(k){ voci.push(aperte[k]); delete aperte[k]; }); };
  const punti = [];
  const stim = function(i){ return (i >= 0 && i < N && inSess[i] >= 0) ? P : P - Dtot(); };
  const punto = function(t, i){ punti.push({ t: t, v: riserva(), s: stim(i) }); };
  for (let i = 0; i < N; i++){
    const t = from + i * 60000;
    const dt = Math.min(1, (to - t) / 60000);
    if (i % cfg.curvaPassoMin === 0) punto(t, i);

    /* il risveglio: il sonno recupera una parte della distanza SOTTO la base; sopra consolida */
    if (risvegli[i]){
      const z = risvegli[i];
      const q = dmScalino(cfg.sonno, z.ore);
      const prima = riserva();
      if (S < cfg.base) S = S + q * (cfg.base - S);
      debiti.forEach(function(d){ d.v *= (1 - q); });
      P = 0;
      if (z.ore < cfg.sonno[cfg.sonno.length - 1][0]) S += cfg.sonnoCorto;
      S = dmClamp(S, cfg);
      const h = Math.floor(z.ore), m = Math.round((z.ore - h) * 60);
      voci.push({ tipo: 'sonno', t: z.e, fine: z.e, l: q > 0 ? 'Sonno' : 'Sonno insufficiente', nota: h + ' h ' + m + ' min', delta: riserva() - prima, devs: { telefono: 1 } });
    }
    /* 0.9.222: nei minuti di sonno stimato si saltava TUTTO, anche il carburante promesso (il
       respiro, una task chiusa nel tempo). Un 4-7-8 fatto a letto prima di addormentarsi cadeva
       dentro il sonno stimato e il suo carburante spariva. I premi a tempo valgono sempre. */
    const eventi = (istPer[i] || []).filter(function(e){ return !fermo[i] || e.tipo === 'tempo'; });
    if (fermo[i] && !eventi.length) continue;

    /* gli eventi puntuali di questo minuto */
    eventi.sort(function(a, b){ return a.t - b.t; }).forEach(function(e){
      /* il carburante promesso dal foglio del tempo (0.9.214) vale quello che promette, fino a 30 */
      let d = Math.max(-cfg.eventoMax, Math.min(e.tipo === 'tempo' ? 45 : cfg.eventoMax, e.delta));
      if (e.mov){ d = Math.max(0, Math.min(d, cfg.movimentoMaxGiorno - movimento)); movimento += d; }
      if (e.auto){ d = Math.max(0, Math.min(d, cfg.autoMaxGiorno - auto)); auto += d; }
      if (e.pen && d < 0) d = -tettoOra(t, -d);
      if (!d) return;
      const prima = riserva();
      S = dmClamp(S + d, cfg);
      voci.push({ tipo: e.tipo, t: e.s || e.t, fine: e.s ? e.t + 1 : e.t, l: e.l, nota: e.nota, delta: riserva() - prima, devs: e.dev ? { [e.dev]: 1 } : {} });
    });
    if (fermo[i]) continue;

    /* la dinamica continua, scomposta */
    const prima = riserva();
    const parti = [];
    const k = inSess[i];
    /* il debito che si riassorbe: la riserva risale, e la risalita e' di chi l'aveva lasciato */
    const fD = Math.pow(1 - cfg.debitoOra, (inCamm[i] ? cfg.cammDebitoX : 1) * dt / 60);
    debiti.forEach(function(d){ const giu = d.v * (1 - fD); if (giu > 1e-12){ d.v -= giu; parti.push(['dopo:' + d.k, giu]); } });
    if (k >= 0){
      /* dentro alla sessione: il picco sale (solo sulla curva), il debito si accumula */
      P = P + (sess[k].picco - P) * (1 - Math.exp(-dt / cfg.piccoSaleMin));
      const add = sess[k].debito / minSess[k] * dt;
      const gia = debiti.filter(function(d){ return d.k === k; })[0];
      if (gia) gia.v += add; else debiti.push({ k: k, v: add });
      parti.push(['sessione:' + k, -add]);
    } else {
      P = P * Math.exp(-dt / cfg.piccoScendeMin);
      const T = cfg.base + (cfg.weatherModifier || 0) + (cfg.sunlightHook || 0);
      const r = S < T ? cfg.ritornoOra : cfg.sopraOra;
      const rit = (T - S) * (1 - Math.pow(r, dt / 60));
      S += rit;
      parti.push(['ritorno', rit]);
      if (costo[i] > 0){
        const c = tettoOra(t, costo[i] * dt);
        if (c > 0){ S -= c; parti.push(['uso', -c]); }
      }
    }
    S = dmClamp(S, cfg);
    /* quello che il tetto a 0/100 ha tolto va alla parte piu' grande: la somma resta esatta */
    const vero = riserva() - prima;
    const somma = parti.reduce(function(a, x){ return a + x[1]; }, 0);
    if (Math.abs(vero - somma) > 1e-12 && parti.length){
      let m = 0; parti.forEach(function(x, j){ if (Math.abs(x[1]) > Math.abs(parti[m][1])) m = j; });
      parti[m][1] += vero - somma;
    }
    parti.forEach(function(x){ if (x[1] !== 0) scrivi(x[0], t, x[1], x[0] === 'uso' || x[0].indexOf('sessione') === 0 ? uso[i] : null); });
    if (uso[i] && k < 0 && !(costo[i] > 0) && aperte.uso && t - aperte.uso.fine <= GAP.uso) scrivi('uso', t, 0, uso[i]);
  }
  chiudiTutte();
  const score = riserva();
  punti.push({ t: to, v: score, s: stim(N - 1) });

  /* --- gli insight --- */
  const finali = dmFinisci(voci, sess, cfg);
  const somma = finali.reduce(function(a, v){ return a + v.delta; }, 0);
  const scarto = start + somma - score;
  /* la riconciliazione: partenza + somma delle voci = riserva di adesso */
  if (Math.abs(scarto) > 0.05){
    errori.push({ tipo: 'riconciliazione', start: start, somma: somma, score: score, scarto: scarto });
    try{ console.warn('[dopamina] riconciliazione: scarto', scarto.toFixed(3)); }catch(_){ }
  }
  pul.errori.forEach(function(e){ try{ console.warn('[dopamina] granelli sovrapposti', e.dev, e.a.p, e.b.p); }catch(_){ } });

  const cause = {};
  finali.forEach(function(v){ const c = v.causa || v.l; cause[c] = (cause[c] || 0) + v.delta; });
  const ordinate = Object.keys(cause).map(function(c){ return { l: c, delta: cause[c] }; });
  /* i cambi per fascia di due ore: servono a imparare le finestre produttive */
  const fasce = new Array(12).fill(0);
  cambi.forEach(function(c){ fasce[Math.floor(new Date(c.t).getHours() / 2)]++; });
  return {
    start: start, score: score, S: S, P: P, D: Dtot(), punti: punti, voci: finali, errori: errori,
    somma: somma, scarto: scarto,
    contatori: { cambi: cambi.length, notifiche: inp.notifiche || (inp.notif || []).length, riprese: inp.riprese || 0 },
    su: ordinate.filter(function(x){ return x.delta > 0.05; }).sort(function(a, b){ return b.delta - a.delta; }).slice(0, 3),
    giu: ordinate.filter(function(x){ return x.delta < -0.05; }).sort(function(a, b){ return a.delta - b.delta; }).slice(0, 3),
    sessioni: sess, camminate: camm, fasce: fasce, autodichiarati: auto
  };
}

/**
 * Le voci come le legge una persona. Ogni voce ha un nome, una durata e il dispositivo; le
 * voci troppo piccole per dire qualcosa finiscono insieme in «Variazioni minori», cosi' la
 * somma resta esatta e l'elenco resta leggibile.
 */
function dmFinisci(voci, sess, cfg){
  const lista = voci.slice().sort(function(a, b){ return a.t - b.t; });
  const out = [];
  let minori = null;
  lista.forEach(function(v){
    if (Math.abs(v.delta) < cfg.voceMin){
      if (!minori) minori = { tipo: 'minori', t: v.t, fine: v.fine || v.t, delta: 0, n: 0, devs: {} };
      minori.delta += v.delta; minori.n++;
      minori.fine = Math.max(minori.fine, v.fine || v.t);
      return;
    }
    out.push(v);
  });
  if (minori && minori.delta !== 0) out.push(minori);
  return out.map(function(v){
    const r = { tipo: v.tipo, t: v.t, fine: v.fine, delta: v.delta, dev: Object.keys(v.devs || {}).join(' + ') || '', min: v.min || 0 };
    const x = (v.sess >= 0 && sess[v.sess]) || null;
    if (v.tipo === 'sessione'){
      r.l = (x && x.app) || 'Sessione'; r.causa = r.l;
      r.nota = Math.round((x && x.min) || v.min) + ' min di fila · debito' + (x && x.combo > 1 ? ' · COMBO ×' + String(x.combo).replace('.', ',') : '');
      if (x && x.combo > 1) r.combo = x.combo;
      if (x) r.dev = x.devs.join(' + ');
    } else if (v.tipo === 'dopo'){
      if (v.ieri){ r.l = 'Il debito di ieri si scarica'; r.causa = 'Debito di ieri'; r.nota = v.min + ' min'; }
      else { r.l = 'Recupero dopo ' + ((x && x.app) || 'la sessione'); r.causa = (x && x.app) || 'Sessione'; r.nota = v.min + ' min'; }
      if (x) r.dev = x.devs.join(' + ');
    } else if (v.tipo === 'ritorno'){
      r.l = v.delta >= 0 ? 'Pausa senza stimoli' : 'Rientro verso la base';
      r.causa = r.l;
      r.nota = v.min + ' min';
      r.dev = '';
    } else if (v.tipo === 'uso'){
      const apps = Object.keys(v.apps || {}).sort(function(a, b){ return v.apps[b] - v.apps[a]; });
      r.l = apps.slice(0, 2).join(', ') || 'Uso leggero';
      r.causa = apps[0] || 'Uso leggero';
      r.nota = v.min + ' min';
    } else if (v.tipo === 'minori'){
      r.l = 'Variazioni minori'; r.causa = r.l;
      r.nota = v.n + (v.n === 1 ? ' voce' : ' voci');
    } else {
      r.l = v.l; r.nota = v.nota || ''; r.causa = v.l;
    }
    return r;
  });
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { dmSimula: dmSimula, dmPulisci: dmPulisci, dmSessioni: dmSessioni, dmDispersione: dmDispersione,
                     dmCambi: dmCambi, dmCat: dmCat, dmFinisci: dmFinisci, dmFFBonus: dmFFBonus };
}
