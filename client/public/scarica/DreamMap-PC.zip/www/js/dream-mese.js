/* ===========================================================================================
   LE DATE IMPORTANTI DEL MESE: la prima slide della scheda Sogno (0.9.285, Andrea)

   "Una slide nuova, la PRIMA, che compare da sola ogni volta che nel mese c'e' una data o un
   evento importante del calendario. Con i tre puntini in alto a destra si vede l'obiettivo del
   mese o quello della settimana, che l'agente scrive quando crea la roadmap su misura con gli
   orizzonti allineati."

   - Una data e' importante se nel calendario di DreamMap l'hai segnata "Data importante del mese"
     (calendario.js), oppure se il titolo dice da solo che lo e' (un esame, una scadenza, un
     colloquio, un viaggio, un compleanno...). I turni di lavoro non contano: sono tutti i giorni.
   - Si guardano i giorni da oggi alla fine del mese (gli ultimi giorni del mese, anche la prima
     settimana del mese dopo). Senza date importanti la slide non c'e'.
   - Le tre viste (i tre puntini): le date del mese, l'obiettivo del mese, l'obiettivo della
     settimana. Gli obiettivi sono gli anelli della roadmap (orizzonti.js, ozAnello 'mese' e
     'settimana'): li scrive l'agente con il blocco del piano.
   =========================================================================================== */
const DM_VISTA_K = 'fl_dream_mese_vista';
const DM = { firma: null, giorno: '' };
const DM_PAROLE = /\b(esam[ei]|scadenz[ae]|colloqui|compleann|anniversari|matrimoni|viaggi|partenz[ae]|volo|consegn[ae]|lanci|gar[ae]|concors|laure[ae]|visit[ae] medic|operazion|traslo|presentazion|udienz|deadline|inaugurazion|esposizion|fiera|interrogazion|discussion|firma del contratto|rogito|trasferta)/i;
const DM_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const DM_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
const DM_TRE = '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2.1"/><circle cx="12" cy="12" r="2.1"/><circle cx="19" cy="12" r="2.1"/></svg>';

function dmEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function dmVista(){ try{ const v = localStorage.getItem(DM_VISTA_K); return v === 'mese' || v === 'settimana' ? v : 'date'; }catch(_){ return 'date'; } }
function dmGiornoK(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }

/** Le date importanti da oggi alla fine del mese (negli ultimi giorni, anche la prima settimana del mese dopo). */
function dmImportanti(){
  if (typeof calEventiTra !== 'function') return [];
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const fineMese = new Date(oggi.getFullYear(), oggi.getMonth() + 1, 1).getTime();
  const fine = Math.max(fineMese, oggi.getTime() + 8 * 86400000);
  let l = [];
  try{ l = calEventiTra(oggi.getTime(), fine) || []; }catch(_){ l = []; }
  const visti = {};
  return l.filter(function(e){
    if (!e || !(+e.fine > Date.now() - 3600000)) return false;
    const t = String(e.titolo || '');
    if (/^turno\b/i.test(t)) return false;
    const chiave = t.toLowerCase() + '|' + new Date(+e.inizio).toDateString();
    if (visti[chiave]) return false;
    const si = e.importante === true || DM_PAROLE.test(t);
    if (si) visti[chiave] = 1;
    return si;
  }).sort(function(a, b){ return a.inizio - b.inizio; });
}
function dmQuando(e){
  const d = new Date(+e.inizio);
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const g = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - oggi.getTime()) / 86400000);
  const ora = e.tuttoIlGiorno ? '' : ' alle ' + d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0');
  if (g <= 0) return 'Oggi' + ora;
  if (g === 1) return 'Domani' + ora;
  return DM_GIORNI[d.getDay()].charAt(0).toUpperCase() + DM_GIORNI[d.getDay()].slice(1) + ' ' + d.getDate() + ' ' + DM_MESI[d.getMonth()] + ' · tra ' + g + ' giorni';
}
/** L'html della slide (data-i="9"), o '' se nel mese non ci sono date importanti. */
function dmSlideHtml(){
  const l = dmImportanti();
  DM.firma = l.map(function(e){ return e.id + '@' + e.inizio; }).join(',');
  DM.giorno = dmGiornoK();
  if (!l.length) return '';
  return '<article class="bh-slide dm-s" data-i="9" style="--bh-img:url(\'img/bg/aurora.jpg\');--bh-pos:center 40%">'
    + '<div class="bh-img"></div><span class="bh-ov dark"></span>'
    + '<button type="button" class="dm-tre" onclick="dmMenu(event)" aria-label="Scegli cosa mostrare">' + DM_TRE + '</button>'
    + '<div class="bh-stack dm-in" id="dmSlide">' + dmCorpo(l) + '</div>'
    + '</article>';
}
function dmCorpo(l){
  const v = dmVista();
  const mese = DM_MESI[new Date().getMonth()];
  if (v === 'date'){
    l = l || dmImportanti();
    if (!l.length) return '';
    const p = l[0];
    const altre = l.slice(1, 3).map(function(e){ const d = new Date(+e.inizio); return '<li><b>' + d.getDate() + ' ' + DM_MESI[d.getMonth()].slice(0, 3) + '</b>' + dmEsc(e.titolo) + '</li>'; }).join('');
    return '<p class="dm-eti">' + dmEsc(mese.charAt(0).toUpperCase() + mese.slice(1)) + ' · la data che conta</p>'
      + '<h2 class="dm-tit">' + dmEsc(p.titolo) + '</h2>'
      + '<p class="dm-quando">' + dmEsc(dmQuando(p)) + '</p>'
      + (altre ? '<ul class="dm-altre">' + altre + '</ul>' : '')
      + (l.length > 3 ? '<p class="dm-piu">E altre ' + (l.length - 3) + ' date importanti nel calendario</p>' : '');
  }
  const a = (typeof ozAnello === 'function') ? ozAnello(v) : { testo: '', passi: [] };
  const fatti = (a.passi || []).filter(function(x){ return x && x.fatto; }).length, tot = (a.passi || []).length;
  const etichetta = v === 'mese' ? 'L’obiettivo del mese' : 'L’obiettivo della settimana';
  if (!a.testo) return '<p class="dm-eti">' + etichetta + '</p><h2 class="dm-tit dm-vuoto">Il tuo agente personale lo scrive quando crea la tua roadmap su misura</h2>'
    + '<button type="button" class="bh-cta dm-btn" onclick="dmChiedi(\'' + v + '\')">Chiedilo al tuo agente personale</button>';
  return '<p class="dm-eti">' + etichetta + '</p>'
    + '<h2 class="dm-tit">' + dmEsc(a.testo) + '</h2>'
    + (tot ? '<p class="dm-quando">' + fatti + ' passi fatti su ' + tot + '</p><div class="dm-bar"><i style="width:' + Math.round(fatti / tot * 100) + '%"></i></div>' : '');
}
function dmPaint(){ const el = document.getElementById('dmSlide'); if (el) el.innerHTML = dmCorpo(); }
function dmMenu(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  dmMenuVia();
  const v = dmVista();
  const voci = [['date', 'Le date importanti del mese'], ['mese', 'L’obiettivo del mese'], ['settimana', 'L’obiettivo della settimana']];
  const velo = document.createElement('div'); velo.id = 'dmVelo'; velo.className = 'arb-veil';
  velo.addEventListener('click', function(e){ e.stopPropagation(); dmMenuVia(); });
  const m = document.createElement('div'); m.id = 'dmMenu'; m.className = 'arb-menu';
  m.innerHTML = '<p class="arb-mtit">Cosa vedi qui</p>' + voci.map(function(x){ return '<button type="button" onclick="dmScegli(\'' + x[0] + '\')">' + dmEsc(x[1]) + '<span class="ck">' + (x[0] === v ? '✓' : '') + '</span></button>'; }).join('');
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  casa.appendChild(velo); casa.appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, ev && ev.currentTarget);
}
function dmMenuVia(){ ['dmMenu', 'dmVelo'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); }); }
function dmScegli(v){
  try{ localStorage.setItem(DM_VISTA_K, v); }catch(_){ }
  dmMenuVia(); dmPaint();
  try{ flVibra(8); }catch(_){ }
}
function dmChiedi(v){
  const testo = v === 'mese' ? 'Scrivi l’obiettivo di questo mese nella mia roadmap, allineato con l’anno e con la settimana.' : 'Scrivi l’obiettivo di questa settimana nella mia roadmap, allineato con il mese.';
  if (typeof agApri === 'function'){ Promise.resolve(agApri()).then(function(){ try{ AG.vista = 'chat'; agPaint(); }catch(_){ } }); setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900); }
}
/* LA SLIDE COMPARE DA SOLA: quando le date importanti cambiano (un evento nuovo, un giorno nuovo),
   lo slideshow si rifa'; se ci sono, si apre su di lei. */
function dmDopoHero(){
  setTimeout(function(){
    try{ if (document.querySelector('#nvHero .dm-s') && typeof flHeroGo === 'function' && FL_HEROES.rotta && FL_HEROES.rotta.slide !== 0) flHeroGo('rotta', 0); }catch(_){ }
  }, 160);
}
function dmControlla(){
  if (typeof FL_HEROES === 'undefined' || !FL_HEROES.rotta || typeof flHeroRifai !== 'function') return;
  const l = dmImportanti();
  const firma = l.map(function(e){ return e.id + '@' + e.inizio; }).join(',');
  if (firma === DM.firma && DM.giorno === dmGiornoK()){ dmPaint(); return; }
  flHeroRifai('rotta');
}
(function(){
  document.addEventListener('fl:calendario', function(){ setTimeout(dmControlla, 300); });
  document.addEventListener('fl:giorno', function(){ setTimeout(dmControlla, 500); });
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'rotta') setTimeout(dmControlla, 250); });
  document.addEventListener('fl:piano', function(){ setTimeout(dmPaint, 300); });
  /* il calendario del telefono arriva dopo (calTelefonoLeggi): si riguarda poco dopo l'avvio */
  setTimeout(dmControlla, 5000);
  const css = [
    '.dm-s .dm-in{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:56px 26px 54px;gap:8px;color:#fff}',
    '.dm-tre{position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:14px;z-index:4;width:40px;height:40px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;display:grid;place-items:center;cursor:pointer;backdrop-filter:blur(6px)}',
    '.dm-eti{margin:0;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#BCE0FF}',
    '.dm-tit{margin:2px 0 0;font:900 30px/1.15 var(--font-display);color:#fff;text-wrap:balance;max-width:20ch}.dm-tit.dm-vuoto{font-size:22px;max-width:24ch}',
    '.dm-quando{margin:2px 0 0;font:700 15px var(--font-body);color:#fff;opacity:.92}',
    '.dm-altre{list-style:none;margin:14px 0 0;padding:0;display:flex;flex-direction:column;gap:6px;width:100%;max-width:300px}',
    '.dm-altre li{display:flex;gap:10px;align-items:center;justify-content:center;padding:8px 12px;border-radius:14px;background:rgba(255,255,255,.12);font:600 13.5px var(--font-body);color:#fff}.dm-altre b{font:800 12px var(--font-body);color:#BCE0FF;text-transform:uppercase}',
    '.dm-piu{margin:6px 0 0;font:600 12.5px var(--font-body);color:#D7E8FF}',
    '.dm-bar{width:min(260px,80%);height:8px;border-radius:99px;background:rgba(255,255,255,.2);overflow:hidden;margin-top:6px}.dm-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#FF8AC2,#5BC0F8)}',
    '.dm-btn{margin-top:10px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
