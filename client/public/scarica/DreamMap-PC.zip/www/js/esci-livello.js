/* ===========================================================================================
   «PERDERAI TUTTI I PROGRESSI» (0.9.213), come su Duolingo

   Quando provi a uscire da un livello a meta' (la X in alto o il tasto indietro di Android), la
   barra dei progressi CADE: si stacca da destra e resta a penzolare. Sotto sale un foglio scuro
   con il Genio triste: «Perderai tutti i progressi di questo livello.» CONTINUA la raddrizza,
   con una vibrazione, come se il progresso tornasse al suo posto; PERDI I PROGRESSI esce.
   Vale per gli episodi del Genio, gli esercizi a tempo, la radiografia del paradigma e la
   sfida del Genio lungo il sentiero.
   =========================================================================================== */
const FLE = { barra: null, esci: null };
function flEsciConferma(barraSel, esci){
  FLE.esci = esci;
  FLE.barra = barraSel ? document.querySelector(barraSel) : null;
  if (FLE.barra){ FLE.barra.classList.remove('fl-risale'); void FLE.barra.offsetWidth; FLE.barra.classList.add('fl-cade'); }
  // la caduta si sente: un tocco subito, un colpo secco quando la barra sbatte in basso (a 350 ms, meta' di flCade),
  // poi due rimbalzi piu' leggeri insieme alle oscillazioni dell'animazione
  flVibra([15, 315, 70, 110, 35, 70, 18], [90, 255, 150, 80]);
  let w = document.getElementById('flEsci');
  if (!w){ w = document.createElement('div'); w.id = 'flEsci'; w.className = 'fle-w'; w.addEventListener('click', function(e){ if (e.target === w) flEsciResta(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="fle-in"><i class="fle-grab"></i><img src="img/genio/genio-triste.png" alt="">'
    + '<h3>Perderai tutti i progressi di questo livello.</h3>'
    + '<button type="button" class="fle-resta" onclick="flEsciResta()">CONTINUA</button>'
    + '<button type="button" class="fle-esci" onclick="flEsciVia()">PERDI I PROGRESSI</button></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function flEsciAperta(){ const w = document.getElementById('flEsci'); return !!(w && !w.hidden); }
function flEsciChiudi(){ const w = document.getElementById('flEsci'); if (w){ w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 220); } }
function flEsciResta(){
  flEsciChiudi();
  const b = FLE.barra; FLE.barra = null;
  if (b){ b.classList.remove('fl-cade'); void b.offsetWidth; b.classList.add('fl-risale'); setTimeout(function(){ b.classList.remove('fl-risale'); }, 600); }
  // la risalita: un ronzio che sale mentre la barra torna su, e lo scatto quando si raddrizza
  flVibra([25, 25, 35, 25, 60, 120, 20], [70, 130, 255, 90]);
}
function flEsciVia(){
  flEsciChiudi();
  if (FLE.barra) FLE.barra.classList.remove('fl-cade');
  FLE.barra = null;
  const f = FLE.esci; FLE.esci = null;
  if (typeof f === 'function') f();
}

/* ---- gli episodi del Genio: la X e il tasto indietro ---- */
(function(){
  if (typeof gnChiudiTop === 'function'){
    const vero = gnChiudiTop;
    window.gnChiudiTop = gnChiudiTop = function(){
      /* 0.9.322: nei livelli a domande niente "perderai i progressi": il punto in cui sei resta (dqRipSalva) */
      return vero.apply(this, arguments);
    };
  }
  if (typeof BACK_TO !== 'undefined'){
    const prima = BACK_TO['s-genio'];
    BACK_TO['s-genio'] = function(){
      if (typeof GN !== 'undefined' && GN.modo === 'dq'){ if (flEsciAperta()) flEsciResta(); else gnChiudiTop(); return 's-genio'; }
      return typeof prima === 'function' ? prima() : (prima || '');
    };
  }
})();
/* ---- gli esercizi a tempo ---- */
(function(){
  if (typeof esX !== 'function') return;
  window.esX = esX = function(){
    const r = (typeof ES !== 'undefined') ? ES.run : null;
    if (!r || r.fase === 'intro' || r.fase === 'esito'){ esTornaMappa(); return; }
    if (r.fase === 'scaduto') return;
    if (flEsciAperta()){ flEsciResta(); return; }
    flEsciConferma('#esBox .es-barra', function(){ esPerso('lasciato'); });
  };
})();
/* ---- la radiografia del paradigma ---- */
(function(){
  if (typeof bqIndietro !== 'function') return;
  const vero = bqIndietro;
  window.bqIndietro = bqIndietro = function(){
    /* dentro al questionario «indietro» torna alla domanda prima; esce solo dalla prima, e li' chiede */
    if (typeof BQ !== 'undefined' && BQ.fase === 'blocco' && BQ.i === 0 && Object.keys(BQ.imp || {}).length > 0 && !flEsciAperta()){
      flEsciConferma('.bq-bar', function(){ BQ.fase = 'intro'; goId('s-home'); }); return;
    }
    return vero.apply(this, arguments);
  };
  if (typeof BACK_TO !== 'undefined') BACK_TO['s-blocchi'] = function(){ if (flEsciAperta()){ flEsciResta(); return 's-blocchi'; } bqIndietro(); const a = document.querySelector('.screen.active'); return (a && a.id) || 's-home'; };
})();
/* ---- la sfida del Genio lungo il sentiero ---- */
function sdEsameX(){
  const e = (typeof SD !== 'undefined') ? SD.esame : null;
  if (e && e.i < e.d.length && e.vite > 0 && !flEsciAperta()){ flEsciConferma('#sdEsame .sd-es-bar', sdEsameEsci); return; }
  sdEsameEsci();
}
(function(){
  if (typeof BACK_TO === 'undefined') return;
  BACK_TO['s-sd-esame'] = function(){
    const e = (typeof SD !== 'undefined') ? SD.esame : null;
    if (flEsciAperta()){ flEsciResta(); return 's-sd-esame'; }
    if (e && e.i < e.d.length && e.vite > 0){ sdEsameX(); return 's-sd-esame'; }
    SD.esame = null; try{ switchTab('mappa'); }catch(_){ } return 's-home';
  };
})();

(function(){
  const css = [
    '.fle-w{position:fixed;inset:0;z-index:9996;display:flex;align-items:flex-end;background:rgba(0,0,0,0);transition:background .22s}.fle-w.in{background:rgba(0,0,0,.45)}',
    '.fle-in{width:100%;max-width:560px;margin:0 auto;padding:12px 24px calc(env(safe-area-inset-bottom,0px) + 26px);border-radius:24px 24px 0 0;background:#1B232E;text-align:center;transform:translateY(100%);transition:transform .3s cubic-bezier(.2,1,.3,1)}.fle-w.in .fle-in{transform:none}',
    '.fle-grab{display:block;width:40px;height:5px;margin:0 auto 18px;border-radius:99px;background:rgba(255,255,255,.25)}',
    '.fle-in img{height:150px;width:auto;filter:drop-shadow(0 10px 18px rgba(0,0,0,.4))}.fle-in h3{margin:16px auto 24px;max-width:22ch;font:800 22px/1.35 var(--font-body);color:#fff}',
    '.fle-resta{width:100%;padding:17px;border:0;border-radius:16px;background:#3F9FF4;color:#062240;font:900 16px var(--font-body);letter-spacing:.08em;box-shadow:0 5px 0 #1E6FBF;cursor:pointer}',
    '.fle-esci{margin-top:18px;border:0;background:transparent;color:#FF6B78;font:900 15px var(--font-body);letter-spacing:.08em;cursor:pointer}',
    '.fl-cade{transform-origin:0% 50%;animation:flCade .7s cubic-bezier(.3,1.6,.5,1) forwards,flPenzola 1.8s .7s ease-in-out infinite alternate}',
    '@keyframes flCade{0%{transform:rotate(0)}50%{transform:rotate(100deg)}70%{transform:rotate(82deg)}85%{transform:rotate(93deg)}100%{transform:rotate(90deg)}}@keyframes flPenzola{from{transform:rotate(90deg)}to{transform:rotate(85deg)}}',
    '.fl-risale{transform-origin:0% 50%;animation:flRisale .55s cubic-bezier(.2,1.4,.4,1)}@keyframes flRisale{0%{transform:rotate(90deg)}60%{transform:rotate(-6deg)}100%{transform:rotate(0)}}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
