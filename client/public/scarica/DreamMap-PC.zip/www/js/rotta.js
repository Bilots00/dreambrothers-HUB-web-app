/* ===========================================================================================
   LA ROTTA — la mappa vera, quando il sogno è un posto vero

   PERCHÉ ESISTE. Il sentiero a zig-zag della sezione «La tua mappa» è una metafora, e va bene
   per un obiettivo che è una trasformazione — «diventare chi non molla». Ma quando il sogno ha
   un indirizzo — New York — una metafora è un downgrade: c'è un posto reale, a una distanza
   reale, e vederlo su una mappa vera fa una cosa che nessun disegno può fare. Smette di essere
   un simbolo e diventa un viaggio che qualcuno, un giorno, prenderà davvero.

   È il motivo per cui Omio e Rome2Rio mostrano l'arco sopra l'oceano invece di una lista di
   città: quell'arco è la promessa. Ed è anche il motivo per cui aprono su una FOTOGRAFIA di un
   posto dove vorresti essere, con il riquadro della ricerca che ci sporge sopra — prima ti
   fanno desiderare la meta, poi ti chiedono da dove parti.

   COSA C'È SOTTO, e perché non costa niente. Due strati di tessere, tutti e due senza chiave e
   senza contratto: OpenStreetMap per la mappa disegnata, Esri World Imagery per il satellite.
   Nessuna API a pagamento, nessun account. Un solo avvertimento, e va detto adesso e non dopo:
   **le tessere di OpenStreetMap hanno una policy d'uso che non regge un'app pubblicata.**
   Finché l'utente è uno e il traffico è quello di una persona sola va bene; prima dello Store
   serve un fornitore di tessere vero. Non è un difetto da sistemare oggi, è una data da segnare.

   QUANDO NON C'È UN POSTO. Se il sogno non è un luogo — «diventare disciplinato» — questa
   sezione non si inventa niente: resta il sentiero delle tappe, qui sotto. Un obiettivo di
   identità non ha una latitudine, e fingere di sì sarebbe la solita bugia carina.
   =========================================================================================== */

const RT_KEY = 'fl_rotta';

/* I due strati. «Mappa» è il disegno, «Satellite» è la fotografia: la stessa scelta che fa
   Google Maps, e per lo stesso motivo — una la leggi, l'altra ti fa venire voglia di partire. */
const RT_STRATI = {
  mappa: { nome: 'Mappa', ico: '🗺️', url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png' },
  satellite: { nome: 'Satellite', ico: '🛰️',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}' },
  /* 0.9.256, Andrea: il terzo tipo di mappa e' il calendario della vita (memento.js), al posto della cartina */
  memento: { nome: 'La tua vita in settimane', ico: '💀', url: '' },
  /* 0.9.267, Andrea: il quarto tipo e' la mappa disegnata delle mosse del Genio (mappa.js), con le tappe a passi */
  mosse: { nome: 'Le mosse del Genio', ico: '🧭', url: '' }
};
/* il giro del pulsante del satellite: satellite → mappa → memento mori → satellite */
/* 0.9.290, Andrea: "nella Mappa compare il calendario della vita al posto della cartina con New York e la mia posizione:
   se l'utente ha scelto un posto sulla mappa, quel calendario li' non deve comparire mai". Con una destinazione il
   giro del pulsante salta il memento mori (il calendario resta nel report della settimana e nella sua pagina). */
function rtConMeta(){ try{ const v = JSON.parse(localStorage.getItem(RT_KEY) || 'null') || {}; return !!(v.da && v.a); }catch(_){ return false; } }
function rtStratoDopo(s){
  if (s === 'satellite') return 'mappa';
  if (s === 'mappa') return rtConMeta() ? 'mosse' : 'memento';
  if (s === 'memento') return 'mosse';
  return 'satellite';
}
function rtMementoHtml(L, H){
  setTimeout(rtMementoDisegna, 40); setTimeout(rtMementoDisegna, 400);
  return '<div class="rt-mm" style="width:' + L + 'px;height:' + H + 'px"><div class="rt-mm-in"><canvas class="rt-mm-cv"></canvas></div></div>';
}
function rtMementoDisegna(){
  document.querySelectorAll('canvas.rt-mm-cv').forEach(function(cv){
    if (cv.dataset.fatto) return;
    if (typeof mmConti !== 'function' || typeof mmDisegna !== 'function') return;
    const c = mmConti();
    if (!c){ cv.parentNode.innerHTML = '<p class="rt-mm-vuoto">Per vedere la tua vita in settimane serve la data di nascita: Mappa, tocca la cartina.</p>'; return; }
    cv.dataset.fatto = '1';
    mmDisegna(c, (typeof mmAnni === 'function') ? mmAnni() : 80, { canvas: cv });
  });
}

/* I panorami che scorrono finché una rotta non c'è. Sono gli sfondi che l'app ha già: nessun
   file nuovo, nessuna foto presa in prestito da chissà dove. */
const RT_PANORAMI = [
  ['img/bg/montagne.jpg', 'Dove ti porterà tutto questo?'],
  ['img/bg/mare.jpg', 'Ogni giornata è un pezzo di strada.'],
  ['img/bg/alba.jpg', 'La destinazione la scegli tu. La rotta la calcolo io.'],
  ['img/bg/dune.jpg', 'Un sogno senza una data resta un desiderio.'],
  ['img/bg/aurora.jpg', 'Dimmi dove vuoi arrivare.']
];

/* Le mete che la gente scrive davvero. Stanno qui perché cercare online per sapere dov'è New
   York è una richiesta sprecata — e un fallimento garantito il giorno che sei senza campo. */
const RT_POSTI = [
  ['new york', 40.7128, -74.0060, 'New York, Stati Uniti', '🗽'],
  ['nyc', 40.7128, -74.0060, 'New York, Stati Uniti', '🗽'],
  ['manhattan', 40.7831, -73.9712, 'Manhattan, New York', '🗽'],
  ['los angeles', 34.0522, -118.2437, 'Los Angeles, Stati Uniti', '🌴'],
  ['miami', 25.7617, -80.1918, 'Miami, Stati Uniti', '🏖️'],
  ['san francisco', 37.7749, -122.4194, 'San Francisco, Stati Uniti', '🌉'],
  ['dubai', 25.2048, 55.2708, 'Dubai, Emirati Arabi', '🏙️'],
  ['tokyo', 35.6762, 139.6503, 'Tokyo, Giappone', '🗼'],
  ['bali', -8.4095, 115.1889, 'Bali, Indonesia', '🌺'],
  ['sydney', -33.8688, 151.2093, 'Sydney, Australia', '🇦🇺'],
  ['londra', 51.5074, -0.1278, 'Londra, Regno Unito', '🎡'],
  ['london', 51.5074, -0.1278, 'Londra, Regno Unito', '🎡'],
  ['parigi', 48.8566, 2.3522, 'Parigi, Francia', '🗼'],
  ['barcellona', 41.3851, 2.1734, 'Barcellona, Spagna', '🏛️'],
  ['madrid', 40.4168, -3.7038, 'Madrid, Spagna', '🇪🇸'],
  ['lisbona', 38.7223, -9.1393, 'Lisbona, Portogallo', '🚋'],
  ['amsterdam', 52.3676, 4.9041, 'Amsterdam, Paesi Bassi', '🚲'],
  ['berlino', 52.5200, 13.4050, 'Berlino, Germania', '🇩🇪'],
  ['milano', 45.4642, 9.1900, 'Milano, Italia', '🇮🇹'],
  ['lainate', 45.5667, 9.0333, 'Lainate, Italia', '🏠'],
  ['roma', 41.9028, 12.4964, 'Roma, Italia', '🏛️'],
  ['napoli', 40.8518, 14.2681, 'Napoli, Italia', '🍕'],
  ['torino', 45.0703, 7.6869, 'Torino, Italia', '🇮🇹'],
  ['firenze', 43.7696, 11.2558, 'Firenze, Italia', '🎨'],
  ['bologna', 44.4949, 11.3426, 'Bologna, Italia', '🇮🇹'],
  ['venezia', 45.4408, 12.3155, 'Venezia, Italia', '🚤'],
  ['palermo', 38.1157, 13.3615, 'Palermo, Italia', '🇮🇹'],
  ['catanzaro', 38.9098, 16.5877, 'Catanzaro, Italia', '🇮🇹'],
  ['reggio calabria', 38.1105, 15.6613, 'Reggio Calabria, Italia', '🇮🇹']
];

/* Quelle che si mostrano a schermo vuoto: mete da sogno, non la lista del comune. */
const RT_POPOLARI = ['new york', 'los angeles', 'miami', 'dubai', 'tokyo', 'bali', 'sydney', 'londra'];

function rtStato(){
  try{
    const v = JSON.parse(localStorage.getItem(RT_KEY) || 'null') || {};
    /* IL SATELLITE E' DI SERIE. La mappa a due colori resta per chi la sceglie a mano
       (stratoScelto): sul telefono era rimasta «mappa» da una prova, senza che nessuno
       l'avesse voluta. */
    return { da: v.da || null, a: v.a || null,
             strato: ((v.strato === 'mappa' || (v.strato === 'memento' && !(v.da && v.a)) || v.strato === 'mosse') && v.stratoScelto) ? v.strato : 'satellite',
             stratoScelto: !!v.stratoScelto };
  }catch(_){ return { da: null, a: null, strato: 'satellite' }; }
}
function rtSalva(p){
  const s = Object.assign(rtStato(), p || {});
  try{ localStorage.setItem(RT_KEY, JSON.stringify(s)); }catch(_){ }
  return s;
}

/* ---------------------------------------------------------------------------------------
   TROVARE UN POSTO
   --------------------------------------------------------------------------------------- */
function rtLocali(q, quanti){
  const n = String(q || '').trim().toLowerCase();
  if (!n) return [];
  const visti = {};
  const out = [];
  RT_POSTI.forEach(function(p){
    if (out.length >= (quanti || 6)) return;
    if (p[0].indexOf(n) !== 0 && p[3].toLowerCase().indexOf(n) < 0) return;
    if (visti[p[3]]) return;
    visti[p[3]] = 1;
    out.push({ nome: p[3], lat: p[1], lon: p[2], ico: p[4] || '📍' });
  });
  return out;
}

function rtLocale(q){ return rtLocali(q, 1)[0] || null; }

/** Nominatim (OpenStreetMap): gratuito, senza chiave. Serve per tutto il resto del mondo. */
async function rtRemoti(q, quanti){
  try{
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit='
      + (quanti || 6) + '&q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } });
    const j = await r.json();
    return (j || []).map(function(x){
      return { nome: String(x.display_name).split(',').slice(0, 2).join(',').trim(),
               lat: parseFloat(x.lat), lon: parseFloat(x.lon), ico: '📍' };
    });
  }catch(_){ return []; }
}

async function rtCerca(q){
  const casa = rtLocale(q);
  if (casa) return casa;
  return (await rtRemoti(q, 1))[0] || null;
}

/* ---------------------------------------------------------------------------------------
   LA PROIEZIONE — Web Mercator, quattro righe invece di una libreria intera
   --------------------------------------------------------------------------------------- */
const RT_TILE = 256;

function rtX(lon, z){ return (lon + 180) / 360 * Math.pow(2, z) * RT_TILE; }
function rtY(lat, z){
  const r = lat * Math.PI / 180;
  return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, z) * RT_TILE;
}

function rtKm(a, b){
  const R = 6371, t = Math.PI / 180;
  const dLat = (b.lat - a.lat) * t, dLon = (b.lon - a.lon) * t;
  const s = Math.sin(dLat / 2) * Math.sin(dLat / 2)
    + Math.cos(a.lat * t) * Math.cos(b.lat * t) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return Math.round(2 * R * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s)));
}

/**
 * Un punto lungo la rotta, alla frazione f del percorso.
 *
 * <p>Interpolazione sferica, non lineare: fra Milano e New York la linea dritta su una mappa
 * piatta passa sotto l'Islanda e la rotta vera ci passa sopra. È la stessa curva che vedi sul
 * monitor in aereo, ed è quella che rende l'arco riconoscibile invece che strano.</p>
 */
function rtLungo(a, b, f){
  const t = Math.PI / 180;
  const la1 = a.lat * t, lo1 = a.lon * t, la2 = b.lat * t, lo2 = b.lon * t;
  const d = 2 * Math.asin(Math.sqrt(
    Math.pow(Math.sin((la1 - la2) / 2), 2)
    + Math.cos(la1) * Math.cos(la2) * Math.pow(Math.sin((lo1 - lo2) / 2), 2)));
  if (!d) return { lat: a.lat, lon: a.lon };
  const A = Math.sin((1 - f) * d) / Math.sin(d), B = Math.sin(f * d) / Math.sin(d);
  const x = A * Math.cos(la1) * Math.cos(lo1) + B * Math.cos(la2) * Math.cos(lo2);
  const y = A * Math.cos(la1) * Math.sin(lo1) + B * Math.cos(la2) * Math.sin(lo2);
  const z = A * Math.sin(la1) + B * Math.sin(la2);
  return { lat: Math.atan2(z, Math.sqrt(x * x + y * y)) / t, lon: Math.atan2(y, x) / t };
}

/** Quanta strada è già stata fatta: i passi spuntati su tutti gli orizzonti. */
/**
 * L'AEREO AVANZA CON IL TEMPO, non con le spunte.
 *
 * <p>La posizione sull'arco non e' dove sei: e' quanto manca. Fra la partenza (la lettura del
 * Genio) e l'arrivo previsto il tempo scorre, e l'aereo scorre con lui; se il ritmo cambia,
 * l'arrivo si sposta e l'aereo con lui. Tempo e distanza sono la stessa cosa, letta in due
 * modi. Senza un arrivo stimato si torna ai passi fatti.</p>
 */
function rtProgresso(){
  /* 0.9.209: l'aereo sta dove dice il percorso (tappe macro + livelli), lo stesso numero dappertutto */
  try{ if (typeof flPercorso === 'function') return Math.max(0.02, Math.min(0.97, flPercorso())); }catch(_){ }
  try{
    /* la percentuale e' fatto / (fatto + strada che resta), la stessa del navigatore: prima era
       il tempo passato sul tempo totale, e la mappa non tornava con la data */
    const arr = (typeof serArrivo === 'function') ? serArrivo() : null;
    if (arr && typeof arr.pct === 'number') return Math.max(0.02, Math.min(0.97, arr.pct));
    if (typeof ozLeggi !== 'function') return 0;
    const s = ozLeggi();
    let tot = 0, fatti = 0;
    Object.keys(s).forEach(function(k){
      if (k.indexOf('__') === 0) return;
      (s[k].passi || []).forEach(function(p){ tot++; if (p.fatto) fatti++; });
    });
    return tot ? Math.min(0.97, fatti / tot) : 0;
  }catch(_){ return 0; }
}

/* ---------------------------------------------------------------------------------------
   IL DISEGNO DELLA MAPPA
   --------------------------------------------------------------------------------------- */
function rtMappaHtml(da, a, strato, L, H, tappe){
  if (strato === 'memento') return rtMementoHtml(L, H);
  if (strato === 'mosse'){ setTimeout(rtMosseRiempi, 0); return '<div class="rt-mosse" id="rtMosse" onclick="if(typeof mpOpen===\'function\')mpOpen()"></div>'; }
  let z = 8;
  for (; z >= 0; z--){
    const dx = Math.abs(rtX(a.lon, z) - rtX(da.lon, z));
    const dy = Math.abs(rtY(a.lat, z) - rtY(da.lat, z));
    if (dx < L * 0.78 && dy < H * 0.62) break;
  }
  if (z < 0) z = 0;

  const cx = (rtX(da.lon, z) + rtX(a.lon, z)) / 2;
  const cy = (rtY(da.lat, z) + rtY(a.lat, z)) / 2;
  const x0 = cx - L / 2, y0 = cy - H / 2;
  const n = Math.pow(2, z);

  let tessere = '';
  const tx0 = Math.floor(x0 / RT_TILE), tx1 = Math.floor((x0 + L) / RT_TILE);
  const ty0 = Math.floor(y0 / RT_TILE), ty1 = Math.floor((y0 + H) / RT_TILE);
  for (let tx = tx0; tx <= tx1; tx++){
    for (let ty = ty0; ty <= ty1; ty++){
      if (ty < 0 || ty >= n) continue;
      const wx = ((tx % n) + n) % n;
      const url = RT_STRATI[strato].url.replace('{z}', z).replace('{x}', wx).replace('{y}', ty);
      /* NIENTE loading="lazy": un'immagine pigra dentro a un contenitore che il browser
         considera fuori vista non parte MAI — misurato, sei tessere ferme all'infinito mentre
         le stesse URL caricavano in mezzo secondo con new Image(). */
      tessere += '<img class="rt-tile" src="' + url + '" alt="" '
        + 'style="left:' + (tx * RT_TILE - x0) + 'px;top:' + (ty * RT_TILE - y0) + 'px">';
    }
  }

  let d = '';
  for (let i = 0; i <= 48; i++){
    const p = rtLungo(da, a, i / 48);
    d += (i ? ' L' : 'M') + (rtX(p.lon, z) - x0).toFixed(1) + ' ' + (rtY(p.lat, z) - y0).toFixed(1);
  }

  const f = rtProgresso();
  const aereo = rtLungo(da, a, f);
  const ax = rtX(aereo.lon, z) - x0, ay = rtY(aereo.lat, z) - y0;
  /* La prua: l'emoji punta a 45°, e verso ovest volerebbe di coda. */
  const avanti = rtLungo(da, a, Math.min(1, f + 0.02));
  const prua = Math.atan2(rtY(avanti.lat, z) - y0 - ay, rtX(avanti.lon, z) - x0 - ax) * 180 / Math.PI + 45;

  return '<div class="rt-tiles">' + tessere + '</div>'
    + '<svg class="rt-linea" viewBox="0 0 ' + L + ' ' + H + '" preserveAspectRatio="none">'
    +   '<path d="' + d + '" class="rt-path"/>'
    /* 0.9.337, Andrea: "la parte gia' fatta, dal punto blu all'aereo, deve essere la linea rossa dell'animazione; il tratteggio solo per
       quella che manca" */
    +   (f > 0.005 ? '<path d="' + (function(){ let q = ''; for (let i = 0; i <= 40; i++){ const pp = rtLungo(da, a, f * i / 40); q += (i ? ' L' : 'M') + (rtX(pp.lon, z) - x0).toFixed(1) + ' ' + (rtY(pp.lat, z) - y0).toFixed(1); } return q; })() + '" class="rt-fatto"/>' : '')
    /* Il punto di partenza e' piu' grande di quello d'arrivo, non per gusto: finche' non si
       parte l'aereo gli sta sopra, e un cerchio piccolo sotto a un'emoji sparisce. */
    +   '<circle cx="' + (rtX(da.lon, z) - x0).toFixed(1) + '" cy="' + (rtY(da.lat, z) - y0).toFixed(1) + '" r="7" class="rt-da"/>'
    +   '<circle cx="' + (rtX(a.lon, z) - x0).toFixed(1) + '" cy="' + (rtY(a.lat, z) - y0).toFixed(1) + '" r="6" class="rt-a"/>'
    /* LE TAPPE SULL'OCEANO (0.9.301). Sono le tappe del VIAGGIO, non le cose di oggi: il sogno
       diviso nei suoi periodi (anni, trimestri o mesi, rtTappeViaggio), ognuna nel suo punto
       di tutto il percorso. Quelle che l'aereo ha gia' passato sono spuntate in blu; quelle
       davanti hanno il numero. Prima qui finivano i passi del periodo scelto nella pagina (di
       solito i prossimi cinque livelli della Roadmap), sempre schiacciati fra l'aereo e
       l'arrivo: al 48% del percorso sembrava di non aver fatto nessuna tappa. Il parametro
       `tappe` resta per chi lo passa, ma la cartina non lo usa piu'. Stanno in un disegno
       SOPRA all'aereo: quando l'aereo e' a un passo da una tappa, il numero resta leggibile. */
    + '</svg>'
    + '<div class="rt-aereo" style="left:' + ax.toFixed(1) + 'px;top:' + ay.toFixed(1)
    +   'px;transform:translate(-50%,-50%) rotate(' + prua.toFixed(0) + 'deg)">✈️</div>'
    + '<svg class="rt-linea rt-linea-tappe" viewBox="0 0 ' + L + ' ' + H + '" preserveAspectRatio="none">'
    +   rtTappeSvg(da, a, z, x0, y0, f)
    + '</svg>';
}

/* ---------------------------------------------------------------------------------------
   LE TAPPE DEL VIAGGIO (0.9.301)

   Andrea, 24/10: "al 48% le tappe 1-5 sono tutte dopo l'aereo, ammassate fra l'aereo e New
   York: sembra che non abbia fatto nessuna tappa". La causa: la cartina metteva le tappe fra
   l'aereo e l'arrivo (f + (1 - f) * i / n), qualunque cosa fossero. Con "Da quando ho
   iniziato il viaggio verso il mio sogno" l'aereo parte gia' avanti (la strada fatta prima di
   DreamMap) e le tappe restavano schiacciate nell'ultimo pezzo.

   Adesso le tappe sono i periodi in cui si divide il sogno, su TUTTO il percorso: un anno se
   il viaggio dura anni, un trimestre se dura piu' di sei mesi, un mese se e' piu' vicino. Con n
   tappe stanno a 1/n, 2/n... e l'ultima tocca il punto rosso dell'arrivo. Quelle prima
   dell'aereo sono superate. Con "Da quando uso DreamMap" il percorso parte dal giorno della
   roadmap e si vedono solo quelle che mancano.
   --------------------------------------------------------------------------------------- */
const RT_ORD = ['primo', 'secondo', 'terzo', 'quarto', 'quinto', 'sesto', 'settimo', 'ottavo', 'nono', 'decimo'];
const RT_MESE_MS = 30.4375 * 86400000;
let RT_TAPPE_V = [];

/** Quanto dura tutto il viaggio, in mesi, e da dove si conta. */
function rtViaggioMesi(){
  let pct = 0, modo = 'sogno';
  try{ pct = (typeof hdPercorso === 'function') ? hdPercorso().pct : rtProgresso(); }catch(_){ pct = 0; }
  try{ modo = (typeof hdPercModo === 'function') ? hdPercModo() : 'sogno'; }catch(_){ }
  /* la stima vera: quanto manca all'arrivo, diviso per la strada che resta */
  let s = null, velata = false;
  try{ s = (typeof ETA !== 'undefined' && ETA.stato) ? ETA.stato : ((typeof etaLeggi === 'function') ? etaLeggi('stato', null) : null); }catch(_){ s = null; }
  try{ velata = (typeof evVelata === 'function') && evVelata(); }catch(_){ }
  if (s && isFinite(s.p50) && !s.senzaPiano && s.p50 > Date.now()){
    const resta = (s.p50 - Date.now()) / RT_MESE_MS;
    return { mesi: Math.min(480, resta / Math.max(0.03, 1 - pct)), pct: pct, modo: modo, stimata: !velata };
  }
  /* senza stima: i mesi della lettura del Genio, che contano tutto il sogno */
  let L = null; try{ L = (typeof gnLettura === 'function') ? gnLettura() : null; }catch(_){ }
  let mesi = (L && +L.mesi) || 12;
  if (modo === 'app'){ let par = 0; try{ par = (typeof ptzPct === 'function') ? ptzPct() : 0; }catch(_){ } mesi = mesi * (1 - par); }
  return { mesi: Math.max(1, Math.min(480, mesi)), pct: pct, modo: modo, stimata: false };
}

/** Le tappe del viaggio: il periodo, il numero, la frazione del percorso e la data stimata. */
function rtTappeViaggio(){
  const v = rtViaggioMesi();
  let u, passo;
  if (v.mesi >= 24){ u = 'anno'; passo = 12; }
  else if (v.mesi >= 6){ u = 'trimestre'; passo = 3; }
  else { u = 'mese'; passo = 1; }
  let n = Math.round(v.mesi / passo);
  /* oltre dieci anni, una tappa ogni due (o piu') anni: dieci cerchi bastano su una cartina */
  if (u === 'anno' && n > 10){ passo = 12 * Math.ceil(n / 10); n = Math.round(v.mesi / passo); u = 'anni'; }
  n = Math.max(2, Math.min(10, n));
  const inizio = Date.now() - v.pct * v.mesi * RT_MESE_MS;
  const out = [];
  for (let k = 1; k <= n; k++){
    out.push({ k: k, n: n, u: u, passo: passo, fr: k / n, at: inizio + k / n * v.mesi * RT_MESE_MS, stimata: v.stimata, modo: v.modo });
  }
  return out;
}

/** I cerchi sull'arco. L'ultima tappa tocca il punto rosso dell'arrivo senza coprirlo. */
function rtTappeSvg(da, a, z, x0, y0, f){
  let lista = [];
  try{ lista = rtTappeViaggio(); }catch(_){ lista = []; }
  const px = function(fr){ const p = rtLungo(da, a, fr); return { x: rtX(p.lon, z) - x0, y: rtY(p.lat, z) - y0 }; };
  const fine = px(1);
  /* la frazione in cui il cerchio dell'ultima tappa (raggio 8) tocca quello dell'arrivo (raggio 6) */
  let frUltima = 1;
  for (let fr = 1; fr > 0.5; fr -= 0.002){ const p = px(fr); if (Math.hypot(p.x - fine.x, p.y - fine.y) >= 14){ frUltima = fr; break; } }
  RT_TAPPE_V = lista.map(function(t){
    const fr = t.k === t.n ? frUltima : t.fr;
    return Object.assign({}, t, { frDisegno: fr, fatta: t.fr <= f });
  });
  const aereo = px(f);
  return RT_TAPPE_V.map(function(t, i){
    /* "Da quando uso DreamMap": si vedono solo le tappe che mancano */
    if (t.fatta && t.modo === 'app') return '';
    const p = px(t.frDisegno);
    /* LA TAPPA SOTTO ALL'AEREO. Al 48% l'aereo copre la tappa del 50%: il cerchio si alza di lato all'arco, come uno
       spillo, con un filo che lo lega al suo punto vero. Cosi' si vedono tutti e due, e la tappa resta dov'e'. */
    let c = p, filo = '';
    if (Math.hypot(p.x - aereo.x, p.y - aereo.y) < 20){
      const p0 = px(Math.max(0, t.frDisegno - 0.01)), p1 = px(Math.min(1, t.frDisegno + 0.01));
      let nx = -(p1.y - p0.y), ny = p1.x - p0.x;
      const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
      if (ny > 0){ nx = -nx; ny = -ny; }
      c = { x: p.x + nx * 24, y: p.y + ny * 24 };
      filo = '<line x1="' + (p.x - c.x).toFixed(1) + '" y1="' + (p.y - c.y).toFixed(1) + '" x2="0" y2="0" stroke="#fff" stroke-width="1.6"/>'
        + '<circle cx="' + (p.x - c.x).toFixed(1) + '" cy="' + (p.y - c.y).toFixed(1) + '" r="2.6" style="fill:#fff;stroke:none"/>';
    }
    const segno = t.fatta
      ? '<path d="M-3.4 0.2l2.3 2.3 4.4-4.6" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>'
      : '<text y="3.2">' + t.k + '</text>';
    return '<g class="rt-tappa' + (t.fatta ? ' fatta' : '') + '" transform="translate(' + c.x.toFixed(1) + ' ' + c.y.toFixed(1) + ')"'
      + ' onclick="rtTappaApri(' + i + ',event)" role="button" aria-label="' + rtEscA(rtTappaNome(t)) + '">'
      + filo + '<circle r="8"/>' + segno + '</g>';
  }).join('');
}
function rtEscA(s){ return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

/** "La fine del secondo anno", "La fine del primo trimestre", "L'arrivo al tuo sogno". */
function rtTappaNome(t){
  if (t.k === t.n) return 'L’arrivo al tuo sogno';
  if (t.u === 'anni') return 'Dopo ' + (t.k * t.passo / 12) + ' anni di viaggio';
  return 'La fine del ' + (RT_ORD[t.k - 1] || (t.k + '°')) + ' ' + t.u;
}
/** Il mese e l'anno, come si dicono: "marzo 2028". */
function rtMeseAnno(ts){
  const d = new Date(ts);
  const m = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  return m[d.getMonth()] + ' ' + d.getFullYear();
}
/** L'orizzonte scritto che copre una data: il mese, l'anno, i cinque anni o il sogno. */
function rtOrizzonteDi(at, ultima){
  const testo = function(k){ try{ return (typeof ozAnello === 'function') ? String(ozAnello(k).testo || '').trim() : ''; }catch(_){ return ''; } };
  const g = (at - Date.now()) / 86400000;
  const ordine = ultima ? ['ungiorno', 'cinque'] : (g <= 31 ? ['mese', 'anno', 'cinque', 'ungiorno'] : g <= 366 ? ['anno', 'cinque', 'ungiorno'] : g <= 1830 ? ['cinque', 'ungiorno'] : ['ungiorno']);
  const frase = {
    mese: 'Il tuo obiettivo per questo mese è',
    anno: 'Il tuo obiettivo per quest’anno è',
    cinque: 'Il tuo obiettivo per i prossimi cinque anni è',
    ungiorno: 'Quello che vuoi fare un giorno è'
  };
  for (let i = 0; i < ordine.length; i++){ const t = testo(ordine[i]); if (t) return frase[ordine[i]] + ' "' + t + '".'; }
  return '';
}
/** Il foglio della tappa toccata sulla cartina. */
function rtTappaApri(i, ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const t = RT_TAPPE_V[i];
  if (!t || typeof stgFoglio !== 'function') return;
  const e = (typeof esc === 'function') ? esc : rtEscA;
  const ultima = t.k === t.n;
  let meta = '';
  try{ const s = rtStato(); meta = s && s.a ? String(s.a.nome || '').split(',')[0] : ''; }catch(_){ }
  const righe = [];
  if (t.fatta){
    righe.push('Questa tappa l’hai già superata: l’aereo è più avanti.');
    if (t.modo === 'sogno') righe.push('Conta anche la strada che avevi fatto prima di DreamMap.');
  } else {
    if (ultima && meta) righe.push('Qui arrivi a ' + e(meta) + ', la meta del tuo viaggio.');
    else righe.push('È la tappa numero ' + t.k + ' di ' + t.n + ' del tuo viaggio.');
    if (t.stimata) righe.push('Secondo la stima di oggi ci arrivi verso ' + rtMeseAnno(t.at) + '.');
    const oz = rtOrizzonteDi(t.at, ultima);
    righe.push(oz ? e(oz) : 'Non hai ancora scritto cosa vuoi raggiungere entro questa tappa: lo scrivi negli orizzonti.');
  }
  stgFoglio('<div class="rt-tf"><small class="stg-eti">' + (t.fatta ? 'Tappa superata' : 'Tappa del viaggio') + '</small>'
    + '<h2 class="stg-h">' + e(rtTappaNome(t)) + '</h2>'
    + righe.map(function(r){ return '<p class="stg-p">' + r + '</p>'; }).join('')
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho capito</button>'
    + (t.fatta ? '' : '<button type="button" class="stg-link" onclick="stgFoglioChiudi();if(typeof mpClose===\'function\')mpClose();if(typeof ozOpen===\'function\')ozOpen()">Apri gli orizzonti</button>')
    + '</div>');
}

/* ---------------------------------------------------------------------------------------
   L'ALTO DELLA PAGINA

   Senza rotta: un panorama che cambia, come aprono Omio e Rome2Rio. Non è decorazione — è la
   domanda fatta con un'immagine invece che con una parola: dove vorresti essere adesso?
   Con la rotta: la mappa vera, l'arco, l'aereo e i chilometri.
   --------------------------------------------------------------------------------------- */
let RT_PANO = 0;
let RT_PANO_TIMER = 0;

function rtHeroHtml(){
  const s = rtStato();
  /* 0.9.267: le mosse del Genio e il memento mori non hanno bisogno di una destinazione sulla cartina */
  if (!(s.da && s.a) && (s.strato === 'mosse' || s.strato === 'memento')){
    return '<div class="rt-mappa" id="rtMappa"></div>'
      + '<button type="button" class="rt-strato" onclick="rtToggleStrato(event)" aria-label="Cambia tipo di mappa">' + RT_STRATI[rtStratoDopo(s.strato)].ico + '</button>';
  }
  if (s.da && s.a){
    const km = rtKm(s.da, s.a);
    const f = rtProgresso();
    /* L'ORDINE LO DECIDE LA MAPPA, non il ruolo.
       rtX() e' una proiezione di Mercatore: la x cresce con la longitudine, quindi chi ha la
       longitudine minore sta a sinistra sul disegno, a qualsiasi zoom. Mettere i nomi in
       quell'ordine e' l'unico modo perche' ogni nome stia sotto al proprio punto. */
    const sinistra = (+s.da.lon <= +s.a.lon) ? 'da' : 'a';
    /* SOLO IL NOME. Il pallino colorato c'era anche qui, accanto alla parola, e sulla mappa
       c'era il pallino vero: due volte lo stesso segno, e uno dei due nel posto sbagliato —
       un puntino accanto a una scritta non indica un luogo, lo indica il punto sulla mappa.
       Il colore lo dice gia' il cerchio disegnato alle coordinate giuste. */
    const capo = function(quale){
      const p = quale === 'da' ? s.da : s.a;
      return '<b class="rt-capo">' + esc(String(p.nome).split(',')[0]) + '</b>';
    };
    return '<div class="rt-mappa" id="rtMappa"></div>'
      + '<div class="rt-hud">'
      +   '<div class="rt-capi">' + capo(sinistra)
      +     '<i>' + km.toLocaleString('it-IT') + ' km</i>'
      +     capo(sinistra === 'da' ? 'a' : 'da') + '</div>'
      +   '<div class="rt-barra"><i style="width:' + Math.round(f * 100) + '%"></i></div>'
      +   '<small>' + (f > 0 ? Math.round(f * 100) + '% del percorso' : 'Non sei ancora partito') + '</small>'
      + '</div>'
      + '<button type="button" class="rt-strato" onclick="rtToggleStrato(event)" '
      +   'aria-label="Cambia tipo di mappa">' + RT_STRATI[rtStratoDopo(s.strato)].ico
      + '</button>';
  }

  const p = RT_PANORAMI[RT_PANO % RT_PANORAMI.length];
  return '<div class="rt-pano" style="background-image:url(' + p[0] + ')"></div>'
    + '<div class="rt-pano-ov"></div>'
    + '<div class="rt-pano-txt"><b>Dove stai andando?</b><p>' + esc(p[1]) + '</p></div>'
    /* anche senza destinazione si puo' passare alle mosse del Genio e al memento mori */
    + '<button type="button" class="rt-strato" onclick="rtToggleStrato(event)" aria-label="Cambia tipo di mappa">' + RT_STRATI[rtStratoDopo(s.strato)].ico + '</button>';
}

function rtHeroEnsure(){
  const tab = document.getElementById('tab-severa');
  if (!tab) return null;
  let h = document.getElementById('rtHero');
  if (!h){
    h = document.createElement('section');
    h.id = 'rtHero';
    h.className = 'rt-hero';
    tab.insertBefore(h, tab.firstChild);
  }
  return h;
}

function rtHeroPaint(){
  const h = rtHeroEnsure();
  if (!h) return;
  h.innerHTML = rtHeroHtml();
  setTimeout(rtPaintMappa, 20);

  /* I panorami scorrono solo finché non c'è una rotta: dopo, l'unica immagine che conta è la
     propria. Il timer si spegne da solo per non far girare niente a vuoto. */
  clearInterval(RT_PANO_TIMER);
  const s = rtStato();
  if (!s.da || !s.a){
    RT_PANO_TIMER = setInterval(function(){
      const box = document.getElementById('rtHero');
      const st = rtStato();
      if (!box || (st.da && st.a)){ clearInterval(RT_PANO_TIMER); return; }
      RT_PANO++;
      box.innerHTML = rtHeroHtml();
    }, 5200);
  }
}

function rtPaintMappa(){
  const box = document.getElementById('rtMappa');
  if (!box) return;
  const s = rtStato();
  if ((!s.da || !s.a) && s.strato !== 'mosse' && s.strato !== 'memento') return;
  const L = Math.max(200, Math.round(box.clientWidth || box.offsetWidth || 360));
  const H = Math.max(160, Math.round(box.clientHeight || 300));
  box.innerHTML = rtMappaHtml(s.da, s.a, s.strato, L, H);
}

function rtToggleStrato(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const s = rtStato();
  rtSalva({ strato: rtStratoDopo(s.strato), stratoScelto: true });
  /* Si ridisegna la TESTA di QUESTA scheda. Prima questa funzione cercava la mappa dentro al
     carosello di «Nuovo te» — dove non c'è più — e quindi il pulsante non faceva niente. */
  rtHeroPaint();
  if (typeof toast === 'function') toast(RT_STRATI[rtStato().strato].nome);
}

function rtRidisegna(){
  rtHeroPaint();
  rtPannello();
}

/* ---------------------------------------------------------------------------------------
   IL PANNELLO — sporge sopra alla foto, come su Omio
   --------------------------------------------------------------------------------------- */
function rtPannello(){
  const el = document.getElementById('scRotta');
  if (!el) return;
  const s = rtStato();
  /* IL PANNELLO «CERCA» NON STA NELLA ROADMAP. La destinazione si sceglie una volta, nel
     quiz del Genio, e si cambia da li'; qui sotto restava una card con due campi e un
     pulsante rosso che chiedeva a ogni apertura una cosa gia' decisa. */
  if (el.closest && el.closest('#tab-severa')){ el.hidden = true; el.innerHTML = ''; return; }

  el.innerHTML = '<div class="rt-form">'
    +   '<button type="button" class="rt-campo" onclick="rtApriCerca(\'da\')">'
    +     '<span class="rt-seg da"></span>'
    +     '<span class="rt-val' + (s.da ? '' : ' vuoto') + '">'
    +       (s.da ? esc(s.da.nome) : 'Scegli il punto di partenza') + '</span></button>'
    +   '<button type="button" class="rt-scambia" onclick="rtScambia()" aria-label="Scambia">⇅</button>'
    +   '<button type="button" class="rt-campo" onclick="rtApriCerca(\'a\')">'
    +     '<span class="rt-pin">📍</span>'
    +     '<span class="rt-val' + (s.a ? '' : ' vuoto') + '">'
    +       (s.a ? esc(s.a.nome) : 'Scegli una destinazione') + '</span></button>'
    +   '<button type="button" class="rt-cerca" onclick="rtVai()">Cerca</button>'
    + '</div>'
    + (s.da && s.a
        ? '<p class="rt-nota">' + rtKm(s.da, s.a).toLocaleString('it-IT') + ' km in linea d\'aria. '
          + 'L\'aereo sull\'arco avanza quando spunti i passi degli orizzonti.</p>'
        : '<p class="rt-nota">Se il tuo sogno ha un indirizzo, mettilo qui: la rotta la calcola '
          + 'l\'app, la strada la fai tu.</p>');
}

function rtVai(){
  const s = rtStato();
  if (!s.da || !s.a){
    if (typeof toast === 'function') toast(!s.da ? 'Manca il punto di partenza' : 'Manca la destinazione');
    rtApriCerca(!s.da ? 'da' : 'a');
    return;
  }
  rtRidisegna();
  if (typeof toast === 'function') toast('Rotta impostata: ' + rtKm(s.da, s.a).toLocaleString('it-IT') + ' km');
}

function rtScambia(){
  const s = rtStato();
  if (!s.da || !s.a) return;
  rtSalva({ da: s.a, a: s.da });
  rtRidisegna();
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA DI RICERCA

   A schermo intero, come su Omio e Rome2Rio, e non un campo che si allarga in mezzo alla
   pagina. Il motivo è pratico: appena compare la tastiera resta mezzo schermo, e in mezzo
   schermo ci sta una cosa sola — o il modulo, o i risultati. A pagina piena, i risultati.

   Prima l'elenco di casa (istantaneo, funziona senza campo), poi OpenStreetMap dopo una pausa
   di un terzo di secondo: senza quella pausa si manderebbe una richiesta per ogni lettera
   digitata, che è il modo migliore per farsi chiudere la porta in faccia da un servizio
   gratuito.
   --------------------------------------------------------------------------------------- */
let RT_QUALE = 'a';
let RT_DEB = 0;

/* Da dove si e' arrivati alla ricerca: le opzioni di viaggio, o il viaggio stesso. */
let RT_RITORNO = '';
function rtRitorno(id){ RT_RITORNO = id || ''; }
function rtCercaIndietro(){
  /* aperta dall'onboarding: si torna al pannello del Genio. Prima si finiva nella scheda Mappa
     con la musica dell'onboarding ancora accesa (0.9.199) */
  if (typeof gnCercaAnnullata === 'function' && gnCercaAnnullata()) return;
  const d = RT_RITORNO; RT_RITORNO = '';
  if (d){ goId(d); if (d === 's-viaggio-opz' && typeof mpOpzPaint === 'function') mpOpzPaint(); return; }
  goId('s-home');
  if (typeof switchTab === 'function') switchTab('mappa');
}

function rtApriCerca(quale){
  RT_QUALE = quale === 'da' ? 'da' : 'a';
  goId('s-rtcerca');
  const inp = document.getElementById('rtCercaInp');
  const tit = document.getElementById('rtCercaTit');
  const box = document.getElementById('rtCercaBody');
  if (tit) tit.textContent = RT_QUALE === 'da' ? 'Partenza' : 'Arrivo';
  if (inp){
    inp.value = '';
    inp.placeholder = RT_QUALE === 'da' ? 'Da: città, aeroporto o porto' : 'A: città, aeroporto o porto';
    setTimeout(function(){ try{ inp.focus(); }catch(_){ } }, 260);
  }
  if (box) box.innerHTML = rtPopolariHtml();
}

function rtPopolariHtml(){
  const righe = RT_POPOLARI.map(function(k){
    const p = RT_POSTI.filter(function(x){ return x[0] === k; })[0];
    return p ? rtRigaHtml({ nome: p[3], lat: p[1], lon: p[2], ico: p[4] }) : '';
  }).join('');
  return '<button type="button" class="rt-qui" onclick="rtQui()">📍 Usa la mia posizione</button>'
    + '<p class="rt-sez">Destinazioni popolari</p>' + righe;
}

function rtRigaHtml(p){
  const dati = encodeURIComponent(JSON.stringify(p));
  return '<button type="button" class="rt-riga" onclick="rtScegli(\'' + dati + '\')">'
    + '<span class="rt-riga-ico">' + (p.ico || '📍') + '</span>'
    + '<b>' + esc(p.nome) + '</b></button>';
}

function rtScegli(dati){
  let p = null;
  try{ p = JSON.parse(decodeURIComponent(dati)); }catch(_){ }
  if (!p) return;
  rtSalva(RT_QUALE === 'da' ? { da: p } : { a: p });
  const s = rtStato();
  /* Se ora ci sono tutti e due i capi si torna al viaggio con la rotta già disegnata; se ne
     manca uno si chiede subito l'altro, invece di far tornare indietro e ricominciare. */
  if (RT_RITORNO){
    /* Si era arrivati qui da un'altra pagina (le opzioni di viaggio): si torna li', con il
       nome nuovo gia' scritto nella riga. */
    const d = RT_RITORNO; RT_RITORNO = '';
    goId(d);
    if (d === 's-viaggio-opz' && typeof mpOpzPaint === 'function') mpOpzPaint();
    setTimeout(rtRidisegna, 140);
  } else if (s.da && s.a){
    goId('s-home');
    if (typeof switchTab === 'function') switchTab('mappa');
    setTimeout(rtRidisegna, 140);
  } else {
    rtApriCerca(RT_QUALE === 'da' ? 'a' : 'da');
  }
}

function rtDigita(v){
  const box = document.getElementById('rtCercaBody');
  if (!box) return;
  const q = String(v || '').trim();
  if (!q){ box.innerHTML = rtPopolariHtml(); return; }

  const casa = rtLocali(q, 6);
  box.innerHTML = casa.map(rtRigaHtml).join('')
    + '<p class="rt-cerco">Cerco «' + esc(q) + '» nel mondo…</p>';

  clearTimeout(RT_DEB);
  RT_DEB = setTimeout(async function(){
    const fuori = await rtRemoti(q, 6);
    const attuale = (document.getElementById('rtCercaInp') || {}).value || '';
    if (String(attuale).trim() !== q) return;   // ha continuato a scrivere: questa risposta è vecchia
    const b = document.getElementById('rtCercaBody');
    if (!b) return;
    const visti = {};
    casa.forEach(function(p){ visti[p.nome.toLowerCase()] = 1; });
    const nuovi = fuori.filter(function(p){ return !visti[p.nome.toLowerCase()]; });
    b.innerHTML = casa.map(rtRigaHtml).join('') + nuovi.map(rtRigaHtml).join('')
      + (casa.length || nuovi.length ? '' : '<p class="rt-cerco">Nessun posto con questo nome.</p>');
  }, 340);
}

function rtQui(){
  if (!navigator.geolocation){
    if (typeof toast === 'function') toast('Il telefono non dà la posizione');
    return;
  }
  if (typeof toast === 'function') toast('Cerco dove sei…');
  navigator.geolocation.getCurrentPosition(function(p){
    rtScegli(encodeURIComponent(JSON.stringify(
      { nome: 'La tua posizione', lat: p.coords.latitude, lon: p.coords.longitude, ico: '📍' })));
  }, function(){
    /* sul PC (e con la posizione spenta) spesso non arriva: si scrive la citta', senza vicoli ciechi */
    if (typeof toast === 'function') toast('Posizione non disponibile: scrivi la tua città qui sopra');
    try{ const inp = document.getElementById('rtCercaInp'); if (inp) inp.focus(); }catch(_){ }
  }, { timeout: 9000, maximumAge: 600000 });
}

registerScreen('s-rtcerca',
  '<div class="topbar">'
  + '<button class="iconbtn" onclick="rtCercaIndietro()">‹</button>'
  + '<b class="blk-title" id="rtCercaTit">Arrivo</b></div>'
  + '<div class="rt-cerca-box"><span class="rt-pin">📍</span>'
  +   '<input id="rtCercaInp" oninput="rtDigita(this.value)" autocomplete="off" '
  +     'placeholder="A: città, aeroporto o porto"></div>'
  + '<div id="rtCercaBody"></div>'
  + '<div class="spacer"></div>',
  { back: function(){ if (typeof gnCercaAnnullata === 'function' && gnCercaAnnullata(true)) return 's-genio';
      if (RT_RITORNO){ const d = RT_RITORNO; RT_RITORNO = ''; return d; }
      if (typeof switchTab === 'function') switchTab('mappa'); return 's-home'; } });

/* La sezione vive nella scheda «Viaggio»: è la prima domanda del viaggio, non l'ultima. */
(function rtGraft(){
  const tab = document.getElementById('tab-severa');
  if (!tab || document.getElementById('scRotta')) return;
  const box = document.createElement('div');
  box.id = 'scRotta';
  tab.appendChild(box);
})();

document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'severa') return;
  setTimeout(function(){ rtHeroPaint(); rtPannello(); }, 220);
});
window.addEventListener('resize', function(){ setTimeout(rtPaintMappa, 200); });

(function rtStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* LA TESTA. Sborda ai lati come gli altri cieli dell'app (--bleed) e il pannello le sale
       sopra di settanta pixel: è quello sbalzo che fa sembrare la card appoggiata sulla foto
       invece che messa in fila sotto. */
    '.rt-hero{position:relative;margin:0 calc(-1 * var(--bleed, 40px));overflow:hidden;',
      'height:calc(300px + env(safe-area-inset-top,0px));background:#0B1524}',
    '.rt-pano{position:absolute;inset:0;background-size:cover;background-position:center;',
      'animation:rtZoom 9s ease-out both}',
    '@keyframes rtZoom{from{transform:scale(1.12)}to{transform:scale(1)}}',
    '.rt-pano-ov{position:absolute;inset:0;background:linear-gradient(180deg,',
      'rgba(0,10,26,.34),rgba(0,10,26,.06) 40%,rgba(0,10,26,.55))}',
    '.rt-pano-txt{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 66px);',
      'padding:0 26px;text-align:center}',
    '.rt-pano-txt b{display:block;font:800 26px/1.2 var(--font-display);color:#fff;',
      'text-shadow:0 2px 12px rgba(0,0,0,.5)}',
    '.rt-pano-txt p{margin:8px 0 0;font:500 13px/1.5 var(--font-body);color:rgba(255,255,255,.9);',
      'text-shadow:0 1px 8px rgba(0,0,0,.5)}',

    '.rt-mappa{position:absolute;inset:0;overflow:hidden;background:#0B1524}',
    '.rt-tiles{position:absolute;inset:0}',
    '.rt-tile{position:absolute;width:256px;height:256px;display:block}',
    '.rt-linea{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}',
    '.rt-fatto{fill:none;stroke:#E63946;stroke-width:4;stroke-linecap:round;filter:drop-shadow(0 1px 2px rgba(0,0,0,.45))}#drsVg .rt-fatto{display:none}',
    '.rt-path{fill:none;stroke:#fff;stroke-width:2.4;stroke-dasharray:7 5;stroke-linecap:round;',
      'filter:drop-shadow(0 1px 2px rgba(0,0,0,.55))}',
    /* Partenza BLU, arrivo ROSSO: gli stessi due colori della legenda qui sotto. Il bordo
       bianco serve perche' sopra a una foto satellitare qualsiasi tinta piena sparisce. */
    '.rt-da{fill:#0075E3;stroke:#fff;stroke-width:2}',
    /* blu dove parti, ROSSO dove arrivi: il rosso era giusto, e' stato cambiato per sbaglio */
    '.rt-a{fill:#E63946;stroke:#fff;stroke-width:2}',
    '.rt-tappa circle{fill:#0B2A55;stroke:#fff;stroke-width:1.6;cursor:pointer}',
    /* 0.9.301: la tappa superata e' blu con la spunta bianca (le spunte dell'app sono blu) */
    '.rt-tappa.fatta circle{fill:#0075E3}',
    '.rt-tf{text-align:center}.rt-tf .stg-h{margin:12px 40px 20px}.rt-tf .stg-p{margin:0 0 12px}.rt-tf .stg-cta{margin-top:24px}',
    '.rt-tappa text{fill:#fff;font:800 9px var(--font-body);text-anchor:middle;pointer-events:none}',
    /* la testa della scheda non c'e' piu': la mappa del mondo vive dentro alla sezione della
       mappa (vista satellite) e nella seconda diapositiva del cielo */
    '#rtHero{display:none}',
    '.rt-aereo{position:absolute;font-size:22px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5))}',

    /* La striscia dei capi sta PIÙ IN ALTO del bordo, perché sotto ci sale la card. */
    '.rt-hud{position:absolute;left:0;right:0;bottom:78px;padding:0 24px}',
    '.rt-capi{display:flex;align-items:center;gap:10px;justify-content:space-between}',
    '.rt-capi b{font:800 14px var(--font-display);color:#fff;flex:1 1 0;min-width:0;',
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-shadow:0 1px 6px rgba(0,0,0,.6)}',
    '.rt-capi b:last-child{text-align:right}',
    /* Il segno vive nel PANNELLO, accanto al campo da compilare, dove dice di che capo si
       tratta. Sulla striscia sopra alla mappa non ci va: li' il punto e' disegnato alle
       coordinate vere, e ripeterlo accanto alla parola faceva due pallini per un luogo solo. */
    '.rt-seg{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;',
      'vertical-align:middle;flex:0 0 auto}',
    '.rt-seg.da{background:#0075E3;box-shadow:0 0 0 2px rgba(255,255,255,.9)}',
    '.rt-seg.a{background:#E63946;box-shadow:0 0 0 2px rgba(255,255,255,.9)}',

    '.rt-capi i{flex:0 0 auto;font-style:normal;font:700 10.5px var(--font-body);color:#fff;',
      'text-shadow:0 1px 6px rgba(0,0,0,.6)}',
    '.rt-barra{height:4px;margin-top:9px;border-radius:99px;background:rgba(255,255,255,.28);overflow:hidden}',
    '.rt-barra i{display:block;height:100%;background:#fff;border-radius:99px}',
    '.rt-hud small{display:block;margin-top:6px;font:600 10.5px var(--font-body);',
      'color:rgba(255,255,255,.85);text-shadow:0 1px 6px rgba(0,0,0,.6)}',

    '.rt-strato{position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:18px;',
      'width:40px;height:40px;border:0;border-radius:12px;background:rgba(255,255,255,.94);',
      'font-size:18px;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,.3);z-index:3}',

    /* IL PANNELLO CHE SPORGE. Il margine negativo è tutto il trucco: la card entra nella foto,
       e la pagina smette di essere «una foto, poi un modulo» e diventa una cosa sola. */
    /* sporge SOLO sul cielo della mappa: da solo, o sotto altro, resta al suo posto */
    '#scRotta{position:relative;z-index:2;margin-top:0;padding:0 0 6px}',
    '#rtHero + #scRotta{margin-top:-70px}',
    '.rt-form{background:var(--card,#fff);border-radius:20px;padding:14px;position:relative;',
      'box-shadow:0 14px 34px rgba(0,30,68,.16)}',
    'body.dark .rt-form{box-shadow:0 14px 34px rgba(0,0,0,.5)}',
    /* `var(--bg)` e non `var(--soft)`: --soft non e' mai stata definita in questa app, quindi
       il fondo restava il grigio chiaro di riserva anche in modalita' scura — mentre il testo,
       che usa var(--navy), diventava quasi bianco. Chiaro su chiaro. */
    '.rt-campo{display:flex;align-items:center;gap:10px;width:100%;border:0;text-align:left;',
      'background:var(--bg,#F1F4F9);border-radius:13px;padding:14px;margin-bottom:9px;cursor:pointer}',
    'body.dark .rt-campo{background:rgba(255,255,255,.07)}',
    '.rt-campo .rt-seg{width:11px;height:11px;margin:0;box-shadow:0 0 0 2px rgba(0,117,227,.18)}',
    '.rt-pin{font-size:13px;color:var(--muted,#7A8AA3);flex:0 0 auto}',
    '.rt-val{flex:1;min-width:0;font:600 14px var(--font-body);color:var(--navy);',
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.rt-val.vuoto{color:var(--muted,#7A8AA3);font-weight:500}',
    '.rt-scambia{position:absolute;right:26px;top:50px;width:38px;height:38px;border-radius:50%;',
      'border:1.5px solid var(--line);background:var(--card,#fff);color:var(--navy);',
      'font-size:15px;cursor:pointer;z-index:2;box-shadow:0 2px 8px rgba(0,30,68,.12)}',
    /* Il rosso del marchio: #E63946, quello scritto nel brand kit. */
    '.rt-cerca{display:block;width:100%;margin-top:4px;border:0;border-radius:13px;padding:15px;',
      'background:#E63946;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.rt-nota{margin:14px 2px 0;font:500 12.5px/1.6 var(--font-body);color:var(--muted,#7A8AA3)}',

    /* LA PAGINA DI RICERCA */
    '.rt-cerca-box{display:flex;align-items:center;gap:10px;background:var(--bg,#F1F4F9);',
      'border:1.5px solid var(--line);border-radius:13px;padding:13px 14px;margin:0 0 14px}',
    'body.dark .rt-cerca-box{background:rgba(255,255,255,.07)}',
    '.rt-cerca-box input{flex:1;min-width:0;border:0;background:none;outline:none;',
      'font:600 14px var(--font-body);color:var(--navy)}',
    '.rt-sez{margin:16px 2px 4px;font:800 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:var(--muted,#7A8AA3)}',
    '.rt-riga{display:flex;align-items:center;gap:12px;width:100%;border:0;background:none;',
      'text-align:left;padding:14px 2px;border-bottom:1px solid var(--line);cursor:pointer}',
    '.rt-riga-ico{font-size:17px;flex:0 0 auto}',
    '.rt-riga b{font:600 14.5px var(--font-body);color:var(--navy);min-width:0;',
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.rt-cerco{margin:14px 2px;font:500 12.5px var(--font-body);color:var(--muted,#7A8AA3)}',
    '.rt-qui{display:block;width:100%;border:0;background:none;text-align:left;',
      'font:700 12.5px var(--font-body);color:var(--neo-soft,#0075E3);cursor:pointer;padding:8px 2px}'
  ].join('');
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.rt-mm{position:relative;overflow:hidden;background:#F7F1EA;border-radius:inherit}body.dark .rt-mm{background:#0F1A33}',
    '.rt-mm-in{position:absolute;inset:0;overflow:auto;padding:10px 12px;scrollbar-width:none}.rt-mm-in::-webkit-scrollbar{display:none}',
    '.rt-mm-vuoto{margin:0;padding:18px 14px;font:600 13.5px/1.5 var(--font-body);color:#3A2E2B;text-align:center}body.dark .rt-mm-vuoto{color:#fff}'
  ].join('');
  document.head.appendChild(st);
})();

/* LE MOSSE DEL GENIO nella cartina (0.9.267): il sentiero disegnato con le tappe, lo stesso della mappa a tutto schermo */
async function rtMosseRiempi(){
  const h = document.getElementById('rtMosse'); if (!h) return;
  try{
    if (typeof mpTappeDi !== 'function' || typeof mpSvg !== 'function'){ h.innerHTML = '<p class="rt-mosse-vuota">Le mosse del Genio arrivano con la sua lettura.</p>'; return; }
    const t = await mpTappeDi();
    if (typeof MP_TAPPE !== 'undefined') MP_TAPPE = t;
    const ancora = document.getElementById('rtMosse'); if (!ancora) return;
    ancora.innerHTML = '<small class="rt-mosse-eti">Le mosse del Genio</small>' + mpSvg(t || [], false, true) + '<span class="rt-mosse-apri">Tocca per aprire</span>';
    /* con le mosse non ci sono citta' ne' chilometri: la riga sotto alla cartina (New York, km, la tua posizione) si nasconde */
    try{ const g = ancora.closest('.sev-globo-in, .mpf-globo, .mp-card') || ancora.parentElement && ancora.parentElement.parentElement; const hud = g && g.querySelector('.mp-globo-hud'); if (hud) hud.style.display = 'none'; }catch(_){ }
  }catch(_){ }
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.rt-mosse{position:absolute;inset:0;background:#0B1530;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:8px 10px 6px}'
    + '.rt-mosse svg{width:100%;max-height:100%;flex:1;min-height:0}.rt-mosse .mp-node text{dominant-baseline:central}'
    + '.rt-mosse-eti{position:absolute;left:14px;top:12px;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#9FB6D8}'
    + '.rt-mosse-apri{position:absolute;right:14px;bottom:10px;font:700 11px var(--font-body);color:#C9D9EE}'
    + '.rt-mosse-vuota{margin:0;padding:0 24px;text-align:center;font:600 14px/1.45 var(--font-body);color:#C9D9EE}';
  document.head.appendChild(st);
})();
