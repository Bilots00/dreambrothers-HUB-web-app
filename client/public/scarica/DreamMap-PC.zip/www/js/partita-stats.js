/* ===========================================================================================
   LE STATISTICHE DELLA PARTITA (0.9.299): vecchio te contro nuovo te, come a fine partita in FIFA

   Andrea: sotto il punteggio della pagina della partita, prima del livello e del riscaldamento, una
   schermata come le statistiche di fine partita di FIFA, rifatta per il telefono in verticale. Le schede:
     Riepilogo, Possesso (chi ha avuto il tempo della giornata, fascia per fascia), Attacco (quello che ha
     fatto il nuovo te), Difesa (quello che ha respinto), La tua identita' (le azioni voto di ifNuovoMe),
     Partita delle idee (solo admin: e' l'UNICO posto in cui si vede; partita-idee.js da' solo i calcoli),
     le schede personalizzate e "+" (Chiedi al tuo agente personale).
   OEOF: in ogni scheda un elemento primario (gli anelli, o il cerchio del possesso), poi al massimo sei righe.

   IL CATALOGO (PST_CAT): le metriche che l'app sa misurare da sola, ognuna con il valore del vecchio te e
   del nuovo te in un periodo (oggi, 7 giorni, 30 giorni). Le schede di serie e quelle personalizzate sono
   solo elenchi di chiavi del catalogo: i valori si calcolano sempre qui, con i dati veri. Una chiave nuova
   va scritta anche nel paragrafo della chat sul server (focuslockChat.ts, LE STATISTICHE SU MISURA).

   LE SCHEDE PERSONALIZZATE: la persona scrive cosa vuole misurare; il server
   (POST /api/focuslock/agent/statistiche) riceve la richiesta e il catalogo e restituisce la specifica
   { titolo, anelli, righe, nota }; senza modello acceso l'abbinamento si fa qui per parole chiave
   (pstAbbina). Anche il tuo agente personale in chat ne crea una: chiude la risposta con un blocco json
   {"statistica": {...}} e agMsgHtml (agente.js) chiama pstAgenteHtml.
   fl_partita_schede = [{ id, titolo, anelli: [{ k, app, dalle, alle }], righe: [...], nota, richiesta, da, at }]
   =========================================================================================== */
const PST_KEY = 'fl_partita_schede';
const PST_FATTI = 'fl_partita_schede_chat';     // { <id del messaggio dell'agente>: id della scheda | 'no' | 'annullata' }
const PST_VISTA = 'fl_partita_stats_vista';     // { tab, per }: la scheda e il periodo dell'ultima volta
const PST = { tab: 'riepilogo', per: 7, anello: {}, cache: {}, carica: {}, modifica: '', bozza: '', esito: null, invio: false };
(function(){
  try{
    const v = JSON.parse(localStorage.getItem(PST_VISTA) || 'null');
    if (v && typeof v.tab === 'string') PST.tab = v.tab;
    if (v && [1, 7, 30].indexOf(v.per) >= 0) PST.per = v.per;
  }catch(_){ }
})();

function pstJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function pstE(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function pstA(s){ return pstE(JSON.stringify(String(s))); }
function pstGiorno(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function pstNorm(s){ return String(s || '').replace(/^[☐☑•\-]\s*/, '').toLowerCase().replace(/[^a-z0-9à-ÿ]+/g, ' ').trim(); }
function pstCopy(t, max){ return String(t == null ? '' : t).replace(/[«»“”]/g, '"').replace(/\s*[—–]\s*/g, ', ').replace(/\s+/g, ' ').trim().slice(0, max); }
function pstAdmin(){ try{ return typeof flAdmin === 'function' && flAdmin(); }catch(_){ return false; } }
function pstSalvaVista(){ try{ localStorage.setItem(PST_VISTA, JSON.stringify({ tab: PST.tab, per: PST.per })); }catch(_){ } }

/* ---------------------------------------------------------------------------------------
   I DATI DI UN PERIODO: si leggono una volta per disegno. Il telefono (le app aperte, i blocchi
   del motore) arriva dopo, in asincrono (pstCarica), e la scheda si ridisegna.
   --------------------------------------------------------------------------------------- */
function pstFinestra(per){
  const a = new Date(); a.setHours(0, 0, 0, 0); a.setDate(a.getDate() - (per - 1));
  const giorni = [];
  for (let i = 0; i < per; i++){ const d = new Date(a); d.setDate(a.getDate() + i); d.setHours(12, 0, 0, 0); giorni.push(pstGiorno(d.getTime())); }
  return { da: a.getTime(), a: Date.now(), giorni: giorni };
}
/** Vero se l'ora di `at` sta nella fascia { dalle, alle } (ore intere), anche a cavallo della mezzanotte. */
function pstFascia(at, p){
  if (!p || (p.dalle == null && p.alle == null)) return true;
  const d = new Date(at), h = d.getHours() + d.getMinutes() / 60;
  const a = p.dalle == null ? 0 : p.dalle, b = p.alle == null ? 24 : p.alle;
  return a <= b ? (h >= a && h < b) : (h >= a || h < b);
}
function pstDati(per){
  const F = pstFinestra(per), set = {};
  F.giorni.forEach(function(k){ set[k] = 1; });
  const D = { F: F, per: per, eventi: [], ff: [], fatte: [], prio: {}, interr: [], pause: [], grani: null, blocchi: null, idee: null };
  try{
    const hist = (typeof mgHist === 'function') ? mgHist() : (pstJ('fl_match_hist', []) || []);
    hist.forEach(function(g){
      (g && g.eventi || []).forEach(function(e){
        if (!e || e.stornato) return;
        const at = +e.at || 0; if (at < F.da || at > F.a) return;
        D.eventi.push({ chi: e.chi === 'old' ? 'old' : 'neo', n: Math.max(1, Math.round(+e.punti || 1)), at: at, m: String(e.motivo || '') });
      });
    });
  }catch(_){ }
  (pstJ('fl_ff_hist', []) || []).forEach(function(x){
    if (!x || !x.at || x.at < F.da || x.at > F.a || x.stornato || x.meditazione || x.tag === 'meditazione') return;
    const min = x.spentMs ? x.spentMs / 60000 : (x.ok ? (+x.min || 25) : 0);
    D.ff.push({ ok: !!x.ok, at: +x.at, s: +x.start || (x.at - min * 60000), min: min });
  });
  (pstJ('fl_notes_done', []) || []).forEach(function(x){
    if (!x || !set[x.day]) return;
    D.fatte.push({ t: String(x.text || ''), day: x.day, at: +x.at || new Date(x.day + 'T12:00:00').getTime() });
  });
  (pstJ('fl_one_hist', []) || []).forEach(function(x){ if (x && x.doneAt >= F.da && x.doneAt <= F.a) D.prio[pstGiorno(x.doneAt)] = 1; });
  F.giorni.forEach(function(k){ try{ if (localStorage.getItem('fl_prio_fatta_' + k)) D.prio[k] = 1; }catch(_){ } });
  (pstJ('fl_interrupts_log', []) || []).forEach(function(x){ if (x && x.at >= F.da && x.at <= F.a) D.interr.push(+x.at); });
  (pstJ('fl_breaks', []) || []).forEach(function(t){ if (+t >= F.da && +t <= F.a) D.pause.push(+t); });
  const c = PST.cache[per];
  if (c){ D.grani = c.grani; D.blocchi = c.blocchi; }
  return D;
}
/** Il primo giorno con un dato: i giorni prima non contano come "giorni senza". */
function pstPrimo(){
  let p = pstGiorno(Date.now());
  try{ ((typeof mgHist === 'function') ? mgHist() : []).forEach(function(g){ if (g && g.day && (g.eventi || []).length && g.day < p) p = g.day; }); }catch(_){ }
  try{ (pstJ('fl_ff_hist', []) || []).forEach(function(x){ if (x && x.at){ const k = pstGiorno(x.at); if (k < p) p = k; } }); }catch(_){ }
  try{ (pstJ('fl_notes_done', []) || []).forEach(function(x){ if (x && x.day && x.day < p) p = x.day; }); }catch(_){ }
  return p;
}
function pstVivi(D){ const p = pstPrimo(); return D.F.giorni.filter(function(k){ return k >= p; }); }
/** I giorni gia' chiusi: oggi non e' ancora un giorno "senza". */
function pstChiusi(D){ const o = pstGiorno(Date.now()); return pstVivi(D).filter(function(k){ return k < o; }); }

async function pstCarica(per){
  const c = PST.cache[per];
  if (PST.carica[per] || (c && Date.now() - c.at < 60000)) return;
  PST.carica[per] = true;
  const F = pstFinestra(per);
  let grani = null, blocchi = null;
  try{ if (typeof dpGraniTelefono === 'function') grani = await dpGraniTelefono(F.da, F.a); }catch(_){ grani = null; }
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInsights){
      const ins = (typeof insGet === 'function') ? await insGet('insights', function(){ return NATIVE.getInsights({ days: 30 }); }) : await NATIVE.getInsights({ days: 30 });
      if (ins && (Array.isArray(ins.history) || ins.today != null)){
        blocchi = {};
        (ins.history || []).forEach(function(r){ if (r && r.day) blocchi[r.day] = +r.blocks || 0; });
        const oggi = pstGiorno(Date.now());
        if (ins.today != null) blocchi[oggi] = Math.max(blocchi[oggi] || 0, +ins.today || 0);
      }
    }
  }catch(_){ blocchi = null; }
  PST.cache[per] = { grani: Array.isArray(grani) ? grani : null, blocchi: blocchi, at: Date.now() };
  PST.carica[per] = false;
  if (pstVisibile()) pstPaint();
}

function pstSomma(l){ const o = { old: 0, neo: 0 }; l.forEach(function(e){ o[e.chi] += e.n; }); return o; }
function pstPerGiorno(D){ const g = {}; D.eventi.forEach(function(e){ const k = pstGiorno(e.at); g[k] = g[k] || { old: 0, neo: 0 }; g[k][e.chi] += e.n; }); return g; }
function pstDistrae(g){ return g && g.di >= 0.8; }
function pstProd(g){ return g && g.di <= 0.05; }
function pstMin(l){ return Math.round(l.reduce(function(t, g){ return t + (g.ms || 0); }, 0) / 60000); }
function pstAppDi(g, app){
  const n = pstNorm(app); if (!n) return false;
  const lab = pstNorm(g.l || ''), pkg = pstNorm(g.p || '');
  if (n.length < 3) return lab === n || pkg.split(' ').indexOf(n) >= 0;
  const t = lab + ' ' + pkg;
  return t.indexOf(n) >= 0 || t.replace(/ /g, '').indexOf(n.replace(/ /g, '')) >= 0;
}
function pstBlocchiTot(D){ if (!D.blocchi) return null; return D.F.giorni.reduce(function(t, k){ return t + (+D.blocchi[k] || 0); }, 0); }
function pstFfMin(D, p){ return Math.round(D.ff.filter(function(x){ return pstFascia(x.s, p); }).reduce(function(t, x){ return t + x.min; }, 0)); }
/** La partita delle idee giorno per giorno (piPunti, partita-idee.js). */
function pstIdee(D){
  if (D.idee) return D.idee;
  D.idee = {};
  if (typeof piPunti !== 'function') return D.idee;
  let dati = null; try{ dati = (typeof piDati === 'function') ? piDati() : null; }catch(_){ }
  D.F.giorni.forEach(function(k){ try{ D.idee[k] = piPunti(k, dati || undefined); }catch(_){ } });
  return D.idee;
}
function pstIdeeTipi(D){
  const o = { fuori: 0, rotta: 0, taglia: 0, caveau: 0 };
  const I = pstIdee(D);
  Object.keys(I).forEach(function(k){ (I[k].voci || []).forEach(function(v){ if (o[v.tipo] != null) o[v.tipo]++; }); });
  return o;
}
/** Le azioni voto dell'identita' (fl_iofuturo) spuntate nel foglio: per azione, i giorni in cui e' stata fatta. */
function pstVoti(D){
  let id = null, dal = '';
  try{ const o = (typeof ifNuovoMe === 'function') ? ifNuovoMe() : (pstJ('fl_iofuturo', {}) || {}); id = o.identita || null; const t = o.partita || o.confermata; if (t) dal = pstGiorno(t); }catch(_){ }
  const azioni = (id && Array.isArray(id.vote_actions)) ? id.vote_actions.filter(Boolean).slice(0, 3) : [];
  const per = azioni.map(function(t){ return { t: String(t), n: pstNorm(t), giorni: {} }; });
  D.fatte.forEach(function(x){
    const n = pstNorm(x.t); if (n.length < 4) return;
    per.forEach(function(a){ if (a.n && (n === a.n || (a.n.length > 8 && (n.indexOf(a.n) >= 0 || a.n.indexOf(n) >= 0)))) a.giorni[x.day] = 1; });
  });
  const chiusi = pstChiusi(D).filter(function(k){ return !dal || k >= dal; });
  let tot = 0;
  per.forEach(function(a){ a.fatti = Object.keys(a.giorni).length; a.saltati = chiusi.filter(function(k){ return !a.giorni[k]; }).length; tot += a.fatti; });
  return { id: id, azioni: per, tot: tot };
}

/* ---------------------------------------------------------------------------------------
   IL CATALOGO. f(D, p) torna { old, neo }; null su un lato = l'app quel dato non ce l'ha
   (per esempio senza il permesso di utilizzo). fascia: true = accetta "dalle" e "alle".
   --------------------------------------------------------------------------------------- */
function pstFasciaTesto(p){
  if (!p || (p.dalle == null && p.alle == null)) return '';
  const a = p.dalle == null ? 0 : p.dalle, b = p.alle == null ? 24 : p.alle;
  if (a > 0 && b >= 24) return ' dopo le ' + a;
  if (a === 0 && b < 24) return ' prima delle ' + b;
  return ' dalle ' + a + ' alle ' + b;
}
const PST_CAT = [
  { k: 'punti', n: 'Punti della partita', d: 'I punti segnati dal vecchio te e dal nuovo te', fascia: true,
    l: function(){ return 'Punti'; }, kw: ['punt', 'gol', 'segn', 'punteggio', 'risultato', 'partita'], vicine: ['giorni_vinti', 'giorni_campo', 'sessioni'],
    f: function(D, p){ return pstSomma(D.eventi.filter(function(e){ return pstFascia(e.at, p); })); } },
  { k: 'giorni_vinti', n: 'Giorni vinti', d: 'I giorni in cui il nuovo te ha fatto piu punti del vecchio te, e il contrario',
    l: function(){ return 'Giorni vinti'; }, kw: ['vint', 'vinc', 'pers', 'giornat'], vicine: ['punti', 'giorni_campo'],
    f: function(D){ const g = pstPerGiorno(D); let o = 0, n = 0; Object.keys(g).forEach(function(k){ if (g[k].neo > g[k].old) n++; else if (g[k].old > g[k].neo) o++; }); return { old: o, neo: n }; } },
  { k: 'giorni_campo', n: 'Giorni in campo', d: 'I giorni con almeno un punto al nuovo te, contro quelli senza',
    l: function(){ return 'Giorni con una mossa'; }, kw: ['serie', 'costan', 'ogni giorno', 'di fila', 'mossa', 'abitudin'], vicine: ['giorni_vinti', 'punti'],
    f: function(D){ const g = pstPerGiorno(D); const v = pstVivi(D), c = pstChiusi(D); const n = v.filter(function(k){ return g[k] && g[k].neo > 0; }).length; return { old: c.filter(function(k){ return !(g[k] && g[k].neo > 0); }).length, neo: n }; } },
  { k: 'sessioni', n: 'Sessioni di Full Focus', d: 'Nuovo te: sessioni portate a termine. Vecchio te: sessioni mollate a meta', fascia: true,
    l: function(){ return 'Sessioni di Full Focus'; }, kw: ['session', 'full focus', 'concentra', 'focus'], vicine: ['tempo', 'priorita', 'punti'],
    f: function(D, p){ const l = D.ff.filter(function(x){ return pstFascia(x.s, p); }); return { old: l.filter(function(x){ return !x.ok; }).length, neo: l.filter(function(x){ return x.ok; }).length }; } },
  { k: 'tempo', n: 'Tempo di lavoro contro distrazione', d: 'Nuovo te: minuti di Full Focus e sulle app di lavoro. Vecchio te: minuti sulle app che distraggono', u: 'min', fascia: true,
    l: function(){ return 'Lavoro e distrazioni'; }, kw: ['tempo', 'minut', 'ore ', 'produttiv', 'lavor'], vicine: ['telefono', 'sessioni', 'duelli'],
    f: function(D, p){
      const g = D.grani ? D.grani.filter(function(x){ return pstFascia(x.s, p); }) : null;
      return { old: g ? pstMin(g.filter(pstDistrae)) : null, neo: pstFfMin(D, p) + (g ? pstMin(g.filter(pstProd)) : 0) };
    } },
  { k: 'telefono', n: 'Tempo sul telefono', d: 'Vecchio te: minuti sul telefono. Nuovo te: minuti di Full Focus', u: 'min', fascia: true,
    l: function(){ return 'Telefono e Full Focus'; }, kw: ['telefono', 'schermo', 'cellulare', 'smartphone'], vicine: ['tempo', 'duelli', 'sessioni'],
    f: function(D, p){
      const g = D.grani ? D.grani.filter(function(x){ return pstFascia(x.s, p) && String(x.p || '').indexOf('com.dreambrothers') !== 0; }) : null;
      return { old: g ? pstMin(g) : null, neo: pstFfMin(D, p) };
    } },
  { k: 'duelli', n: 'Duelli sulle app che distraggono', d: 'Vecchio te: le volte che hai aperto un app che distrae. Nuovo te: le volte che il blocco ti ha fermato', fascia: true,
    l: function(){ return 'Duelli sulle app'; }, kw: ['apr', 'apert', 'distra', 'social', 'tentaz'], vicine: ['blocchi', 'tempo', 'pause'],
    f: function(D, p){ return { old: D.grani ? D.grani.filter(function(x){ return pstDistrae(x) && pstFascia(x.s, p); }).length : null, neo: pstBlocchiTot(D) }; } },
  { k: 'blocchi', n: 'Blocchi tenuti', d: 'Nuovo te: le volte che il blocco ti ha fermato. Vecchio te: i blocchi interrotti', fascia: true,
    l: function(){ return 'Blocchi'; }, kw: ['blocc', 'interrott', 'cedut', 'resist', 'protezion'], vicine: ['duelli', 'pause', 'sessioni'],
    f: function(D, p){ return { old: D.interr.filter(function(t){ return pstFascia(t, p); }).length, neo: pstBlocchiTot(D) }; } },
  { k: 'pause', n: 'Pause delle protezioni', d: 'Vecchio te: le volte che hai messo in pausa o spento una protezione. Nuovo te: i giorni senza pause',
    l: function(){ return 'Pause delle protezioni'; }, kw: ['pausa', 'pause', 'spent', 'emergenz', 'severa', 'sblocc'], vicine: ['blocchi', 'duelli'],
    f: function(D){ const g = {}; D.pause.forEach(function(t){ g[pstGiorno(t)] = 1; }); const neo = pstChiusi(D).filter(function(k){ return !g[k]; }).length; return { old: D.pause.length, neo: neo, ring: { old: Object.keys(g).length, neo: neo } }; } },
  { k: 'priorita', n: 'Priorita chiusa', d: 'Nuovo te: i giorni in cui hai chiuso la priorita. Vecchio te: i giorni in cui e rimasta aperta',
    l: function(){ return 'Priorità chiusa'; }, kw: ['priorit', 'unica cosa', 'cosa importante', 'la cosa che conta'], vicine: ['righe', 'sessioni', 'giorni_campo'],
    f: function(D){ const c = pstChiusi(D); const n = pstVivi(D).filter(function(k){ return D.prio[k]; }).length; return { old: c.filter(function(k){ return !D.prio[k]; }).length, neo: n }; } },
  { k: 'righe', n: 'Righe del foglio', d: 'Nuovo te: le righe del foglio spuntate. Vecchio te: le spunte ritirate', fascia: true,
    l: function(){ return 'Righe del foglio'; }, kw: ['righe', 'riga', 'spunt', 'foglio', 'cose fatte', 'compit', 'task', 'finit'], vicine: ['priorita', 'sessioni'],
    f: function(D, p){ return { old: D.eventi.filter(function(e){ return e.chi === 'old' && /^spunta ritirata/i.test(e.m) && pstFascia(e.at, p); }).length, neo: D.fatte.filter(function(x){ return pstFascia(x.at, p); }).length }; } },
  { k: 'voti', n: 'Voti per la tua identita', d: 'Nuovo te: le azioni voto della tua identita fatte. Vecchio te: i punti al vecchio te',
    l: function(){ return 'Voti per la tua identità'; }, kw: ['voto', 'voti', 'identit', 'persona che', 'io futuro'], vicine: ['punti', 'righe'],
    f: function(D){ return { old: pstSomma(D.eventi).old, neo: pstVoti(D).tot }; } },
  { k: 'fuori_rotta', n: 'Fuori rotta', d: 'Vecchio te: le cose aggiunte fuori dalla roadmap. Nuovo te: i giorni senza',
    l: function(){ return 'Fuori rotta'; }, kw: ['fuori rotta', 'rotta', 'deragli', 'deviaz', 'roadmap', 'cose nuove'], vicine: ['priorita', 'righe'],
    f: function(D){ const I = pstIdee(D); let o = 0; const sporchi = {}; Object.keys(I).forEach(function(k){ const f = (I[k].voci || []).filter(function(v){ return v.tipo === 'fuori'; }).length; o += f; if (f) sporchi[k] = 1; }); const neo = pstChiusi(D).filter(function(k){ return !sporchi[k]; }).length; return { old: o, neo: neo, ring: { old: Object.keys(sporchi).length, neo: neo } }; } },
  { k: 'app_aperture', n: 'Aperture di un app', d: 'Vecchio te: le volte che hai aperto quell app nella fascia oraria. Nuovo te: i giorni senza aperture', app: true, fascia: true,
    l: function(p){ return 'Aperture di ' + p.app + pstFasciaTesto(p); }, kw: ['apr', 'apert', 'volte', 'entr', 'controll'], vicine: ['app_minuti', 'sessioni', 'duelli'],
    f: function(D, p){
      if (!D.grani) return { old: null, neo: null };
      const l = D.grani.filter(function(g){ return pstAppDi(g, p.app) && pstFascia(g.s, p); });
      const g = {}; l.forEach(function(x){ g[pstGiorno(x.s)] = 1; });
      const neo = pstChiusi(D).filter(function(k){ return !g[k]; }).length;
      /* l'anello confronta giorni con giorni: quelli con almeno un'apertura contro quelli senza */
      return { old: l.length, neo: neo, ring: { old: Object.keys(g).length, neo: neo } };
    } },
  { k: 'app_minuti', n: 'Minuti su un app', d: 'Vecchio te: minuti su quell app nella fascia oraria. Nuovo te: minuti di Full Focus nella stessa fascia', app: true, fascia: true, u: 'min',
    l: function(p){ return 'Minuti su ' + p.app + pstFasciaTesto(p); }, kw: ['minut', 'tempo', 'ore ', 'quanto'], vicine: ['app_aperture', 'tempo', 'sessioni'],
    f: function(D, p){ return { old: D.grani ? pstMin(D.grani.filter(function(g){ return pstAppDi(g, p.app) && pstFascia(g.s, p); })) : null, neo: pstFfMin(D, p) }; } },
  /* LA PARTITA DELLE IDEE (solo admin): idee nuove introdotte contro giorni rimasti sul piano */
  { k: 'idee', admin: true, n: 'Partita delle idee', d: 'Vecchio te: idee nuove aggiunte fuori rotta. Nuovo te: passi della roadmap chiusi, idee tagliate o messe nel caveau',
    l: function(){ return 'Punti delle idee'; }, kw: ['idee', 'idea', 'caveau'], vicine: ['idee_giorni', 'giorni_piano', 'idee_tagli'],
    f: function(D){ const I = pstIdee(D); let o = 0, n = 0; Object.keys(I).forEach(function(k){ o += I[k].vecchio || 0; n += I[k].nuovo || 0; }); return { old: o, neo: n }; } },
  { k: 'idee_giorni', admin: true, n: 'Giorni vinti nella partita delle idee', d: 'I giorni in cui hai tolto piu di quanto hai aggiunto, e il contrario',
    l: function(){ return 'Giorni vinti'; }, kw: ['idee vint', 'giorni vinti idee'], vicine: ['idee', 'giorni_piano'],
    f: function(D){ const I = pstIdee(D); let o = 0, n = 0; Object.keys(I).forEach(function(k){ if ((I[k].nuovo || 0) > (I[k].vecchio || 0)) n++; else if ((I[k].vecchio || 0) > (I[k].nuovo || 0)) o++; }); return { old: o, neo: n }; } },
  { k: 'giorni_piano', admin: true, n: 'Giorni sul piano', d: 'Nuovo te: i giorni rimasti sul piano senza idee nuove. Vecchio te: i giorni con almeno un idea nuova',
    l: function(){ return 'Giorni sul piano'; }, kw: ['sul piano', 'senza deragli', 'allung', 'tempi'], vicine: ['idee', 'idee_giorni'],
    f: function(D){ const I = pstIdee(D); const c = pstChiusi(D); const sporco = function(k){ return I[k] && (I[k].vecchio || 0) > 0; }; return { old: pstVivi(D).filter(sporco).length, neo: c.filter(function(k){ return !sporco(k); }).length }; } },
  { k: 'idee_tagli', admin: true, n: 'Idee aggiunte contro idee tolte', d: 'Vecchio te: idee nuove aggiunte. Nuovo te: idee tagliate o chiuse nel caveau',
    l: function(){ return 'Idee aggiunte e tolte'; }, kw: ['tagli', 'taglia'], vicine: ['idee', 'giorni_piano'],
    f: function(D){ const t = pstIdeeTipi(D); return { old: t.fuori, neo: t.taglia + t.caveau }; } }
];
const PST_CAT_K = {};
PST_CAT.forEach(function(m){ PST_CAT_K[m.k] = m; });
/** Il catalogo come lo vede il server: chiave, nome, come si calcola, se vuole un'app. */
function pstCatalogo(){ return PST_CAT.filter(function(m){ return !m.admin || pstAdmin(); }).map(function(m){ return { k: m.k, n: m.n, d: m.d + (m.fascia ? '. Accetta una fascia oraria' : ''), app: !!m.app }; }); }

/* Le schede di serie: liste di chiavi. Gli anelli si sfogliano toccandoli (il primo disponibile e' il primo). */
const PST_SERIE = {
  riepilogo: { anelli: ['punti', 'sessioni'], righe: ['punti', 'giorni_vinti', 'sessioni', 'tempo', 'duelli', 'giorni_campo'] },
  attacco:   { anelli: ['sessioni', 'priorita'], righe: ['sessioni', 'tempo', 'priorita', 'righe', 'voti'] },
  difesa:    { anelli: ['blocchi', 'pause'], righe: ['blocchi', 'duelli', 'pause', 'fuori_rotta', 'sessioni'] },
  idee:      { anelli: ['idee', 'giorni_piano'], righe: ['idee', 'idee_giorni', 'giorni_piano', 'idee_tagli'] }
};

function pstValore(D, x){
  const m = PST_CAT_K[x.k]; if (!m || (m.admin && !pstAdmin())) return null;
  if (m.app && !x.app) return null;
  let v = null; try{ v = m.f(D, x); }catch(_){ v = null; }
  if (!v) v = { old: null, neo: null };
  return { m: m, x: x, old: v.old, neo: v.neo, ring: v.ring || null, ok: v.old != null && v.neo != null, l: x.l || m.l(x) };
}

/* ---------------------------------------------------------------------------------------
   IL DISEGNO
   --------------------------------------------------------------------------------------- */
const PST_ICO = {
  piu: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  scudo: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8.2-7 9.5-4-1.3-7-5-7-9.5V6z"/></svg>',
  chat: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 18l-1.5 3 4-1.6A8.5 8.5 0 1 0 5 18z"/></svg>'
};
const PST_PER = [[1, 'Oggi'], [7, '7 giorni'], [30, '30 giorni']];

function pstMie(){ const l = pstJ(PST_KEY, []); return Array.isArray(l) ? l.filter(function(c){ return c && c.id && Array.isArray(c.righe); }) : []; }
function pstScriviMie(l){ try{ localStorage.setItem(PST_KEY, JSON.stringify(l.slice(-12))); return true; }catch(_){ return false; } }
function pstSchede(){
  const l = [{ id: 'riepilogo', t: 'Riepilogo' }, { id: 'possesso', t: 'Possesso' }, { id: 'attacco', t: 'Attacco' }, { id: 'difesa', t: 'Difesa' }, { id: 'identita', t: 'La tua identità' }];
  if (pstAdmin()) l.push({ id: 'idee', t: 'Partita delle idee' });
  pstMie().forEach(function(c){ l.push({ id: c.id, t: c.titolo, mia: true }); });
  l.push({ id: 'piu', t: 'Chiedi al tuo agente personale', piu: true });
  return l;
}
function pstFmt(v, u){
  if (v == null) return '-';
  if (u === 'min'){ if (v < 100) return v + '\''; if (v < 600) return String(Math.round(v / 6) / 10).replace('.', ',') + ' h'; return Math.round(v / 60) + ' h'; }
  return String(v);
}
function pstPct(o, n){ const t = (o || 0) + (n || 0); if (!t) return { o: 0, n: 0 }; const pn = Math.round((n || 0) / t * 100); return { o: 100 - pn, n: pn }; }

function pstCerchio(pct, col, size, spess){
  const r = (size - spess) / 2, c = 2 * Math.PI * r, d = c * Math.max(0, Math.min(100, pct)) / 100;
  return '<svg viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '" aria-hidden="true">'
    + '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="rgba(255,255,255,.12)" stroke-width="' + spess + '"/>'
    + (pct > 0 ? '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="' + spess + '" stroke-linecap="round" stroke-dasharray="' + d.toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/>' : '')
    + '</svg>';
}
function pstAnelliHtml(lista, chiave){
  if (!lista.length) return '';
  const i = Math.min(PST.anello[chiave] || 0, lista.length - 1), v = lista[i];
  /* ring: l'anello confronta giorni con giorni quando la riga mette insieme due misure diverse */
  const R = v.ring || { old: v.old, neo: v.neo };
  const p = pstPct(R.old, R.neo);
  const sotto = function(val){ return v.ring ? val + (val === 1 ? ' giorno' : ' giorni') : pstFmt(val, v.m.u); };
  const lato = function(cls, pct, col, nome, val){
    return '<div class="pst-an ' + cls + '"><div class="pst-anr">' + pstCerchio(pct, col, 104, 10) + '<b>' + pct + '<i>%</i></b></div>'
      + '<span>' + nome + '</span><small>' + sotto(val) + '</small></div>';
  };
  const dots = lista.length > 1 ? '<div class="pst-dots">' + lista.map(function(_, k){ return '<i class="' + (k === i ? 'on' : '') + '"></i>'; }).join('') + '</div>' : '';
  return '<div class="pst-anelli' + (lista.length > 1 ? ' sfoglia' : '') + '"' + (lista.length > 1 ? ' data-no-swipe="1" data-k="' + pstE(chiave) + '" data-n="' + lista.length + '" role="button" aria-label="Mostra il prossimo anello" onclick="if(Date.now()-(PST.swAt||0)>450)pstAnelloDopo(' + pstA(chiave) + ',' + lista.length + ')"' : '') + '>'
    + lato('old', p.o, '#E63946', 'Vecchio te', R.old)
    + '<div class="pst-an-mid"><span>' + pstE(v.l) + '</span>' + dots + '</div>'
    + lato('neo', p.n, '#3F9FF4', 'Nuovo te', R.neo)
    + '</div>';
}
function pstAnelloDopo(chiave, n, dir){ const k = Math.max(1, n); PST.anello[chiave] = (((PST.anello[chiave] || 0) + (dir || 1)) % k + k) % k; pstPaint(); }
/* 0.9.349, Andrea: "se scorro di lato sugli anelli dei punti non passa alle sessioni di Full Focus: i pallini sono troppo piccoli". Lo
   scorrimento di lato sugli anelli li sfoglia, come una slide (touch-action:pan-y: la pagina scorre in verticale, il lato lo gestiamo noi) */
(function(){
  let x0 = 0, y0 = 0, el = null;
  document.addEventListener('touchstart', function(e){ el = (e.touches.length === 1 && e.target.closest) ? e.target.closest('.pst-anelli.sfoglia') : null; if (el){ x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; } }, { passive: true });
  document.addEventListener('touchend', function(e){
    if (!el) return; const t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0, a = el; el = null;
    if (Math.abs(dx) < 36 || Math.abs(dx) < Math.abs(dy) * 1.2) return;
    PST.swAt = Date.now();
    try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
    pstAnelloDopo(a.getAttribute('data-k'), +a.getAttribute('data-n') || 1, dx < 0 ? 1 : -1);
  }, { passive: true });
})();
/* 0.9.349, Andrea: "se tocco una voce del riepilogo deve spiegarmi cosa misura: Tempo di che? Punti come? Per i punti il registro di
   come li ho fatti. Giorni vinti, duelli e giorni con una mossa sono chiari". */
const PST_CHIARE = { giorni_vinti: 1, giorni_campo: 1, duelli: 1 };
const PST_SPIEGA = {
  punti: ['⚽', 'Punti della partita', [['🚀', 'Il nuovo te segna', 'Una sessione finita, una tappa fatta, un blocco che ti ferma.'], ['😈', 'Il vecchio te segna', 'Una sessione mollata, un blocco interrotto, una spunta ritirata.']]],
  tempo: ['⏱️', 'Lavoro e distrazioni', [['🚀', 'Nuovo te', 'I minuti di Full Focus e quelli sulle app di lavoro.'], ['😈', 'Vecchio te', 'I minuti sulle app che distraggono.']]],
  sessioni: ['🎯', 'Sessioni di Full Focus', [['🚀', 'Nuovo te', 'Le sessioni portate fino alla fine.'], ['😈', 'Vecchio te', 'Le sessioni mollate a metà.']]],
  telefono: ['📱', 'Telefono e Full Focus', [['🚀', 'Nuovo te', 'I minuti di Full Focus.'], ['😈', 'Vecchio te', 'I minuti passati sul telefono.']]],
  blocchi: ['🛡️', 'Blocchi', [['🚀', 'Nuovo te', 'Le volte che il blocco ti ha fermato.'], ['😈', 'Vecchio te', 'I blocchi che hai interrotto.']]],
  pause: ['⏸️', 'Pause delle protezioni', [['🚀', 'Nuovo te', 'I giorni senza pause.'], ['😈', 'Vecchio te', 'Le volte che hai messo in pausa o spento una protezione.']]],
  priorita: ['⭐', 'Priorità chiusa', [['🚀', 'Nuovo te', 'I giorni in cui hai chiuso la priorità.'], ['😈', 'Vecchio te', 'I giorni in cui è rimasta aperta.']]],
  righe: ['📝', 'Righe del foglio', [['🚀', 'Nuovo te', 'Le righe del foglio spuntate.'], ['😈', 'Vecchio te', 'Le spunte ritirate.']]]
};
function pstRigaInfo(k){
  const m = PST_CAT_K[k]; if (!m) return;
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  const sp = PST_SPIEGA[k] || ['📊', m.n, String(m.d || '').split('. ').map(function(p){ const x = p.split(': '); return x.length > 1 ? [/vecchio/i.test(x[0]) ? '😈' : '🚀', x[0], x.slice(1).join(': ') + '.'] : ['📊', m.n, p + '.']; })];
  let reg = '';
  if (k === 'punti'){
    const D = pstDati(PST.per);
    const ev = D.eventi.slice().sort(function(a, b){ return b.at - a.at; }).slice(0, 30);
    const per = (PST_PER.filter(function(p){ return p[0] === PST.per; })[0] || [0, ''])[1];
    const ora = function(t){ const d = new Date(t); const g = pstGiorno(t) === pstGiorno(Date.now()) ? 'oggi' : d.getDate() + '/' + (d.getMonth() + 1); return g + ', ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
    const motivo = function(e){ const t = pstCopy(e.m, 70); return t ? t.charAt(0).toUpperCase() + t.slice(1) : (e.chi === 'neo' ? 'Una mossa del nuovo te' : 'Una mossa del vecchio te'); };
    reg = '<p class="pst-reg-k">Il registro dei punti · ' + pstE(per.toLowerCase()) + '</p>'
      + (ev.length ? '<div class="pst-reg">' + ev.map(function(e){ return '<div class="pst-reg-r ' + e.chi + '"><b>+' + e.n + '</b><span>' + pstE(motivo(e)) + '<small>' + (e.chi === 'neo' ? 'Nuovo te' : 'Vecchio te') + ' · ' + ora(e.at) + '</small></span></div>'; }).join('') + '</div>'
        : '<p class="pst-reg-vuoto">In questo periodo nessuno ha ancora segnato.</p>');
  }
  inSheet('<div class="en-foglio pst-info"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="pst-info-e" aria-hidden="true">' + sp[0] + '</span><h3>' + pstE(sp[1]) + '</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe(sp[2]) : '') + reg
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function pstRigaHtml(v){
  const vo = v.ok && v.old > v.neo, vn = v.ok && v.neo > v.old;
  const k = v.m && v.m.k, tocca = k && !PST_CHIARE[k];
  return '<div class="pst-r' + (tocca ? ' tocca' : '') + '"' + (tocca ? ' role="button" tabindex="0" onclick="pstRigaInfo(' + pstA(k) + ')"' : '') + '><b class="pst-v old' + (vo ? ' su' : '') + '">' + pstFmt(v.old, v.m.u) + '</b><span class="pst-l">' + pstE(v.l) + '</span><b class="pst-v neo' + (vn ? ' su' : '') + '">' + pstFmt(v.neo, v.m.u) + '</b></div>';
}
/** Una scheda fatta di chiavi del catalogo. Nelle schede di serie le righe senza dato non si mostrano. */
function pstSchedaHtml(D, sp, chiave, mia){
  const norm = function(x){ return typeof x === 'string' ? { k: x } : x; };
  const an = (sp.anelli || []).map(function(x){ return pstValore(D, norm(x)); }).filter(function(v){ return v && v.ok; });
  const ri = (sp.righe || []).map(function(x){ return pstValore(D, norm(x)); }).filter(function(v){ return v && (mia || v.ok); }).slice(0, 6);
  const manca = ri.some(function(v){ return !v.ok; });
  return pstAnelliHtml(an, chiave)
    + (ri.length ? '<div class="pst-righe">' + ri.map(pstRigaHtml).join('') + '</div>' : '')
    + (manca ? '<p class="pst-nota">Le app aperte le conta il telefono: serve il permesso di utilizzo.</p>' : '');
}

/* IL POSSESSO, come in FIFA: chi ha avuto il tempo della giornata, fascia per fascia. Con il permesso di
   utilizzo si contano i minuti (app che distraggono contro Full Focus e app di lavoro); senza, i punti. */
const PST_FASCE = [[6, 9], [9, 12], [12, 15], [15, 18], [18, 21], [21, 6]];
function pstFasciaDi(t){ const h = new Date(t).getHours(); for (let i = 0; i < 5; i++){ if (h >= PST_FASCE[i][0] && h < PST_FASCE[i][1]) return i; } return 5; }
function pstPossessoHtml(D){
  const f = PST_FASCE.map(function(){ return { old: 0, neo: 0 }; });
  const minuti = !!D.grani;
  if (minuti){
    D.grani.forEach(function(g){ if (pstDistrae(g)) f[pstFasciaDi(g.s)].old += g.ms / 60000; else if (pstProd(g)) f[pstFasciaDi(g.s)].neo += g.ms / 60000; });
    D.ff.forEach(function(x){ f[pstFasciaDi(x.s)].neo += x.min; });
  } else {
    D.eventi.forEach(function(e){ f[pstFasciaDi(e.at)][e.chi] += e.n; });
  }
  const tot = f.reduce(function(a, x){ return { old: a.old + x.old, neo: a.neo + x.neo }; }, { old: 0, neo: 0 });
  const P = pstPct(tot.old, tot.neo), vuoto = !(tot.old + tot.neo);
  const size = 156, sp = 14, r = (size - sp) / 2, c = 2 * Math.PI * r, dn = c * P.n / 100;
  const cerchio = '<svg viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '" aria-hidden="true">'
    + '<circle cx="78" cy="78" r="' + r + '" fill="none" stroke="' + (vuoto ? 'rgba(255,255,255,.12)' : '#E63946') + '" stroke-width="' + sp + '"/>'
    + (P.n > 0 ? '<circle cx="78" cy="78" r="' + r + '" fill="none" stroke="#3F9FF4" stroke-width="' + sp + '" stroke-dasharray="' + dn.toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 78 78)"/>' : '')
    + '</svg>';
  const righe = f.map(function(x, i){
    const p = pstPct(x.old, x.neo), nulla = !(x.old + x.neo);
    const et = PST_FASCE[i][0] + '-' + PST_FASCE[i][1];
    return '<div class="pst-pr' + (nulla ? ' muta' : '') + '"><b class="pst-pp old">' + (nulla ? '-' : p.o + '%') + '</b><div class="pst-pb old"><i style="width:' + (nulla ? 0 : p.o) + '%"></i></div>'
      + '<span class="pst-pl">' + et + '</span><div class="pst-pb neo"><i style="width:' + (nulla ? 0 : p.n) + '%"></i></div><b class="pst-pp neo">' + (nulla ? '-' : p.n + '%') + '</b></div>';
  }).join('');
  return '<div class="pst-pos">'
    + '<div class="pst-pos-c">' + cerchio + '<div><b>' + (vuoto ? '-' : P.n + '%') + '</b><small>nuovo te</small></div></div>'
    + '<div class="pst-leg"><span class="old"><i></i>Vecchio te ' + (vuoto ? '' : P.o + '%') + '</span><span class="neo"><i></i>Nuovo te ' + (vuoto ? '' : P.n + '%') + '</span></div></div>'
    + '<div class="pst-pr-l">' + righe + '</div>'
    + '<p class="pst-nota">' + (vuoto ? 'In questo periodo nessuno ha ancora avuto la palla.' : (minuti ? 'Minuti sulle app che distraggono contro minuti di lavoro, fascia per fascia.' : 'Dai punti della partita. Con il permesso di utilizzo contano i minuti.')) + '</p>';
}

/* LA TUA IDENTITA': le azioni voto della persona che il sogno richiede (ifNuovoMe, io-futuro-livello.js) */
function pstIdentitaHtml(D){
  const V = pstVoti(D);
  if (!V.id || !V.azioni.length){
    return '<div class="pst-vuoto"><b>La tua identità non c\'è ancora</b><p>Scopri chi è il tuo Io Futuro: le sue azioni diventano i voti di questa scheda.</p>'
      + '<button type="button" class="pst-cta" onclick="if(typeof nfApri===\'function\')nfApri(\'s-partita\')">Scopri il tuo Io Futuro</button></div>';
  }
  const old = pstSomma(D.eventi).old;
  const m = { u: '' };
  const tutto = { m: m, old: old, neo: V.tot, ok: true, l: 'Voti per la tua identità' };
  const righe = V.azioni.map(function(a){ return { m: m, old: a.saltati, neo: a.fatti, ok: true, l: a.t }; });
  righe.push({ m: m, old: old, neo: V.tot, ok: true, l: 'Voti in tutto' });
  /* 0.9.351, Andrea: "nella scheda La tua identita' le decisioni prese, vecchio te contro nuovo te: siamo quello che scegliamo di essere.
     Toccandole si apre la pagina delle decisioni" (decisioni.js). Nuovo te: le decisioni del periodo; vecchio te: i voti presi da lui */
  let decN = 0; try{ const st = (typeof cloDecStoria === 'function') ? cloDecStoria() : {}; D.F.giorni.forEach(function(k){ decN += +st[k] || 0; }); }catch(_){ }
  const decRiga = '<div class="pst-r tocca" role="button" tabindex="0" onclick="if(typeof dcsApri===\'function\')dcsApri(0)"><b class="pst-v old' + (old > decN ? ' su' : '') + '">' + old + '</b><span class="pst-l">Decisioni prese</span><b class="pst-v neo' + (decN > old ? ' su' : '') + '">' + decN + '</b></div>';
  return '<p class="pst-chi">' + pstE(String(V.id.identity_statement || '').slice(0, 160)) + '</p>'
    + pstAnelliHtml([tutto], 'identita')
    + '<div class="pst-righe pst-voti">' + decRiga + righe.map(pstRigaHtml).join('') + '</div>'
    + '<p class="pst-nota">Per ogni azione: i giorni in cui l\'hai fatta e quelli saltati.</p>';
}

/* "+": la persona chiede una statistica nuova; il tuo agente personale costruisce la scheda */
function pstPiuHtml(){
  const es = PST.esito;
  const esempi = ['Quante volte apro Instagram dopo le 22', 'Giorni in cui chiudo la priorità'];
  return '<div class="pst-piu">'
    + '<h3>' + (PST.modifica ? 'Cambia la scheda' : 'Una statistica tutta tua') + '</h3>'
    + '<p>Scrivi cosa vuoi misurare: il tuo agente personale crea la scheda.</p>'
    /* 0.9.353, Andrea: "il testo della casella e' tagliato e il microfono e' troppo grande": tre righe e il microfono piccolo */
    + '<textarea id="pstCampo" rows="3" maxlength="200" placeholder="Per esempio, quante volte apro Instagram dopo le 22" oninput="PST.bozza=this.value">' + pstE(PST.bozza) + '</textarea>'
    + '<button type="button" class="pst-cta" onclick="pstCrea()"' + (PST.invio ? ' disabled' : '') + '>' + (PST.invio ? 'Il tuo agente personale la sta costruendo' : (PST.modifica ? 'Aggiorna la scheda' : 'Crea la scheda')) + '</button>'
    /* 0.9.353, Andrea: "gli esempi sotto Crea la scheda non devono esserci: compaiono come pill solo nella chat con il tuo agente" */
    + (es ? '<div class="pst-esito"><p>' + pstE(es.msg) + '</p>' + (es.proposta ? '<button type="button" class="pst-cta2" onclick="pstAccetta()">Crea "' + pstE(es.proposta.titolo) + '"</button>' : '') + '</div>' : '')
    + '<button type="button" class="pst-link" onclick="pstChat()">' + PST_ICO.chat + '<span>Parlane in chat con il tuo agente personale</span></button>'
    + (PST.modifica ? '<button type="button" class="pst-link muto" onclick="pstAnnullaModifica()">Lascia la scheda com\'era</button>' : '')
    + '</div>';
}
function pstEsempio(t){ PST.bozza = t; PST.esito = null; pstPaint(); const c = document.getElementById('pstCampo'); if (c) c.focus(); }

/* 0.9.349, Andrea: "nella scheda Identita' del tuo viaggio lo STESSO pannello della pagina della partita, con Oggi, 7 giorni e 30 giorni,
   ma solo con la scheda Riepilogo e la scheda +; le altre stanno nella pagina della partita". #pstBoxMini e' quel pannello: stesso disegno,
   stesse funzioni, la sua scheda in PST.miniTab. */
function pstPaint(){
  let fatto = false;
  const box = document.getElementById('pstBox'); if (box){ pstPaintIn(box, false); fatto = true; }
  const mini = document.getElementById('pstBoxMini'); if (mini){ pstPaintIn(mini, true); fatto = true; }
  if (fatto){ const tab = (box && box.offsetParent) ? PST.tab : (PST.miniTab || 'riepilogo'); if (tab !== 'piu' && tab !== 'identita') pstCarica(PST.per); }
}
function pstVaiMini(id){ PST.miniTab = id === 'piu' ? 'piu' : 'riepilogo'; if (id !== 'piu') PST.esito = null; PST.daMini = id === 'piu'; pstPaint(); }
function pstPaintIn(box, mini){
  const tabs = mini ? [{ id: 'riepilogo', t: 'Riepilogo' }, { id: 'piu', t: 'Una statistica tutta tua', piu: true }] : pstSchede();
  let tab = mini ? (PST.miniTab || 'riepilogo') : PST.tab;
  if (!tabs.some(function(t){ return t.id === tab; })){ tab = 'riepilogo'; if (!mini) PST.tab = tab; }
  const D = pstDati(PST.per);
  let corpo = '';
  const mia = mini ? null : pstMie().filter(function(c){ return c.id === tab; })[0];
  try{
    if (tab === 'possesso') corpo = pstPossessoHtml(D);
    else if (tab === 'identita') corpo = pstIdentitaHtml(D);
    else if (tab === 'piu') corpo = pstPiuHtml();
    else if (mia){
      corpo = pstSchedaHtml(D, mia, mia.id, true)
        + (mia.nota || mia.richiesta ? '<p class="pst-nota">' + pstE(mia.nota || ('Hai chiesto: "' + mia.richiesta + '"')) + '</p>' : '')
        + '<div class="pst-azioni"><button type="button" onclick="pstModifica(' + pstA(mia.id) + ')">Cambia</button><button type="button" class="via" onclick="pstElimina(' + pstA(mia.id) + ')">Elimina</button></div>';
    }
    else if (PST_SERIE[tab]){
      corpo = (tab === 'idee' ? '<div class="pst-badge"><span>' + PST_ICO.scudo + 'Solo per te</span></div>' : '') + pstSchedaHtml(D, PST_SERIE[tab], mini ? 'mini-' + tab : tab, false);
    }
  }catch(e){ corpo = '<p class="pst-nota">Questa scheda non si apre adesso. Riprova fra poco.</p>'; }
  const vai = mini ? 'pstVaiMini' : 'pstVai';
  const tabsHtml = '<div class="pst-tabs" role="tablist">' + tabs.map(function(t){
    return '<button type="button" role="tab" aria-selected="' + (t.id === tab) + '" class="pst-tab' + (t.id === tab ? ' on' : '') + (t.piu ? ' piu' : '') + (t.mia ? ' mia' : '') + '"'
      + (t.piu ? ' aria-label="' + pstE(t.t) + '"' : '') + ' onclick="' + vai + '(' + pstA(t.id) + ')">' + (t.piu ? PST_ICO.piu : pstE(t.t)) + '</button>';
  }).join('') + '</div>';
  const perHtml = tab === 'piu' ? '' : '<div class="pst-per" role="group" aria-label="Periodo">' + PST_PER.map(function(p){ return '<button type="button" class="' + (p[0] === PST.per ? 'on' : '') + '" onclick="pstPeriodo(' + p[0] + ')">' + p[1] + '</button>'; }).join('') + '</div>';
  const sx = (box.querySelector('.pst-tabs') || {}).scrollLeft || 0;
  box.className = 'pst' + (mini ? ' pst-mini' : '');
  box.innerHTML = '<p class="pst-kick">Le statistiche della partita</p>' + tabsHtml + perHtml + '<div class="pst-corpo">' + corpo + '</div>';
  const row = box.querySelector('.pst-tabs'), on = box.querySelector('.pst-tab.on');
  if (row){
    row.scrollLeft = sx;
    if (on && (on.offsetLeft < row.scrollLeft || on.offsetLeft + on.offsetWidth > row.scrollLeft + row.clientWidth)) row.scrollLeft = Math.max(0, on.offsetLeft - 24);
  }
}
function pstVai(id){ PST.tab = id; if (id !== 'piu'){ PST.esito = null; } pstSalvaVista(); pstPaint(); }
function pstPeriodo(n){ PST.per = n; pstSalvaVista(); pstPaint(); }

/* ---------------------------------------------------------------------------------------
   LE SCHEDE PERSONALIZZATE
   --------------------------------------------------------------------------------------- */
/** La specifica che arriva dal server, dalla chat o dall'abbinamento locale, ripulita sul catalogo. */
function pstValida(sp, richiesta){
  if (!sp || typeof sp !== 'object') return null;
  const ora = function(v){ if (v === null || v === undefined || v === '') return null; const n = Math.round(+v); return isFinite(n) ? Math.max(0, Math.min(24, n)) : null; };
  const voce = function(x){
    if (typeof x === 'string') x = { k: x };
    if (!x || typeof x !== 'object') return null;
    const k = String(x.k || x.chiave || '').trim(), m = PST_CAT_K[k];
    if (!m || (m.admin && !pstAdmin())) return null;
    const o = { k: k };
    if (m.app){ const a = pstCopy(x.app, 30); if (!a) return null; o.app = a; }
    if (m.fascia){
      const a = ora(x.dalle), b = ora(x.alle);
      if (a != null) o.dalle = a; if (b != null) o.alle = b;
      if ((o.dalle == null || o.dalle === 0) && (o.alle == null || o.alle === 24)){ delete o.dalle; delete o.alle; }
    }
    return o;
  };
  const lista = function(l, n){
    const out = [], visti = {};
    (Array.isArray(l) ? l : []).forEach(function(x){ const o = voce(x); if (!o) return; const f = JSON.stringify(o); if (visti[f]) return; visti[f] = 1; out.push(o); });
    return out.slice(0, n);
  };
  let anelli = lista(sp.anelli, 3), righe = lista(sp.righe, 6);
  if (!anelli.length && righe.length) anelli = [righe[0]];
  if (!righe.length && anelli.length) righe = anelli.slice();
  if (!righe.length) return null;
  const titolo = pstCopy(sp.titolo, 28) || pstCopy(richiesta, 28) || 'La mia scheda';
  return { titolo: titolo, anelli: anelli, righe: righe, nota: pstCopy(sp.nota, 140), richiesta: pstCopy(richiesta || sp.richiesta, 200) };
}
function pstAggiungi(sp, da){
  const l = pstMie();
  if (PST.modifica && da !== 'agente'){
    const i = l.findIndex(function(c){ return c.id === PST.modifica; });
    if (i >= 0){ l[i] = Object.assign({}, l[i], sp, { at: Date.now() }); pstScriviMie(l); return l[i].id; }
  }
  const c = Object.assign({ id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), da: da || 'tu', at: Date.now() }, sp);
  l.push(c);
  if (!pstScriviMie(l)){ try{ toast('La memoria del telefono è piena: la scheda non si salva'); }catch(_){ } return ''; }
  return c.id;
}
function pstSalvaScheda(sp){
  const id = pstAggiungi(sp, 'tu'); if (!id) return;
  const era = !!PST.modifica;
  PST.tab = id; PST.bozza = ''; PST.esito = null; PST.modifica = '';
  const daMini = !!PST.daMini && !(document.getElementById('pstBox') || {}).offsetParent; PST.daMini = false; PST.miniTab = 'riepilogo';
  pstSalvaVista(); pstPaint();
  try{ toast(era ? 'Scheda aggiornata' : (daMini ? 'Scheda creata: la trovi nelle statistiche della partita' : 'Scheda creata: "' + sp.titolo + '"')); }catch(_){ }
}

/* L'abbinamento senza modello: le parole chiave del catalogo, le app che si riconoscono per nome e le
   fasce orarie scritte a parole ("dopo le 22", "la mattina"). */
const PST_APP = [['instagram', 'Instagram'], ['tiktok', 'TikTok'], ['tik tok', 'TikTok'], ['youtube', 'YouTube'], ['facebook', 'Facebook'], ['whatsapp', 'WhatsApp'],
  ['telegram', 'Telegram'], ['reddit', 'Reddit'], ['twitter', 'X'], ['netflix', 'Netflix'], ['twitch', 'Twitch'], ['snapchat', 'Snapchat'], ['pinterest', 'Pinterest'],
  ['threads', 'Threads'], ['linkedin', 'LinkedIn'], ['spotify', 'Spotify'], ['amazon', 'Amazon'], ['discord', 'Discord'], ['gmail', 'Gmail'], ['chrome', 'Chrome'], ['tinder', 'Tinder']];
function pstOrari(t){
  let m;
  if ((m = t.match(/dall[ea']?\s*(\d{1,2})(?:[:.]\d{2})?\s+all[ea']?\s*(\d{1,2})/))) return { dalle: +m[1], alle: +m[2] };
  if ((m = t.match(/(?:tra|fra)\s+le\s+(\d{1,2})\s+e\s+le\s+(\d{1,2})/))) return { dalle: +m[1], alle: +m[2] };
  if ((m = t.match(/dopo\s+(?:le\s+|l'\s*|la\s+)?(\d{1,2})/))) return { dalle: +m[1], alle: 24 };
  if ((m = t.match(/prima\s+(?:delle\s+|dell'\s*|di\s+)?(\d{1,2})/))) return { dalle: 0, alle: +m[1] };
  if (/di notte|la notte|notturn|a letto/.test(t)) return { dalle: 23, alle: 6 };
  if (/la sera|di sera|serale|stasera/.test(t)) return { dalle: 19, alle: 24 };
  if (/mattin/.test(t)) return { dalle: 6, alle: 12 };
  if (/pomerigg/.test(t)) return { dalle: 12, alle: 18 };
  return {};
}
function pstAbbina(testo){
  const t = ' ' + String(testo || '').toLowerCase().replace(/[’]/g, '\'') + ' ';
  const or = pstOrari(t);
  const app = PST_APP.filter(function(a){ return t.indexOf(a[0]) >= 0; })[0];
  let k = '';
  if (app) k = (/minut|tempo|\bore\b|quanto sto|passo su|passato/.test(t) && !/volte|\bapr|apert/.test(t)) ? 'app_minuti' : 'app_aperture';
  else {
    let best = 0;
    PST_CAT.forEach(function(m){
      if (m.app || (m.admin && !pstAdmin())) return;
      const s = m.kw.filter(function(w){ return t.indexOf(w) >= 0; }).length;
      if (s > best){ best = s; k = m.k; }
    });
  }
  if (!k){
    return { misurabile: false, messaggio: 'Questo l\'app non lo vede da sola. La cosa più vicina che misura: i punti della partita, giorno per giorno.',
      scheda: { titolo: 'I miei punti', anelli: ['punti'], righe: ['punti', 'giorni_vinti', 'giorni_campo'] } };
  }
  const m = PST_CAT_K[k];
  const par = function(kk){ const mm = PST_CAT_K[kk]; const o = { k: kk }; if (mm.app){ if (!app) return null; o.app = app[1]; } if (mm.fascia){ if (or.dalle != null) o.dalle = or.dalle; if (or.alle != null) o.alle = or.alle; } return o; };
  const righe = [par(k)].concat((m.vicine || []).map(par)).filter(Boolean).slice(0, 4);
  let titolo = '';
  if (app) titolo = app[1] + pstFasciaTesto(or);
  else { const s = String(testo || '').trim(); titolo = s.length <= 26 ? s.charAt(0).toUpperCase() + s.slice(1) : m.n; }
  return { misurabile: true, scheda: { titolo: titolo, anelli: [righe[0]], righe: righe, nota: '' } };
}
async function pstChiediAgente(t){
  if (typeof agApi !== 'function' || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return null;
  try{
    const j = await Promise.race([
      agApi('POST', '/api/focuslock/agent/statistiche', { richiesta: t, catalogo: pstCatalogo() }),
      new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, 9000); })
    ]);
    return (j && j.scheda && !j.error) ? j : null;
  }catch(_){ return null; }
}
async function pstCrea(){
  const c = document.getElementById('pstCampo');
  const t = String((c && c.value) || PST.bozza || '').trim();
  if (t.length < 4){ try{ toast('Scrivi cosa vuoi misurare'); }catch(_){ } if (c) c.focus(); return; }
  if (PST.invio) return;
  PST.bozza = t; PST.invio = true; PST.esito = null; pstPaint();
  let r = await pstChiediAgente(t);
  if (!r) r = pstAbbina(t);
  PST.invio = false;
  const sp = (r && r.scheda) ? pstValida(r.scheda, t) : null;
  if (sp && r.misurabile !== false){ pstSalvaScheda(sp); return; }
  PST.esito = { msg: (r && r.messaggio) || 'Questo l\'app non lo vede da sola. Prova con un\'altra domanda.', proposta: sp };
  pstPaint();
}
function pstAccetta(){ const p = PST.esito && PST.esito.proposta; if (p) pstSalvaScheda(p); }
function pstModifica(id){
  const c = pstMie().filter(function(x){ return x.id === id; })[0]; if (!c) return;
  PST.modifica = id; PST.bozza = c.richiesta || c.titolo; PST.esito = null; PST.tab = 'piu'; pstPaint();
  const f = document.getElementById('pstCampo'); if (f) f.focus();
}
function pstAnnullaModifica(){ const id = PST.modifica; PST.modifica = ''; PST.bozza = ''; PST.esito = null; PST.tab = id || 'riepilogo'; pstPaint(); }
async function pstElimina(id){
  const c = pstMie().filter(function(x){ return x.id === id; })[0]; if (!c) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Eliminare la scheda "' + c.titolo + '"?', 'I dati restano: sparisce solo la scheda.', 'Elimina', true); }catch(_){ }
  if (!ok) return;
  pstScriviMie(pstMie().filter(function(x){ return x.id !== id; }));
  PST.tab = 'riepilogo'; pstSalvaVista(); pstPaint();
  try{ toast('Scheda eliminata'); }catch(_){ }
}
/** La chat con il proprio agente: lo stesso popover del pannello "Il tuo agente personale" della Mappa. Il messaggio
    resta nel campo: parte solo quando la persona lo manda. */
async function pstChat(){
  const c = document.getElementById('pstCampo');
  const t = String((c && c.value) || PST.bozza || '').trim();
  /* 0.9.353: con la casella vuota la chat si apre vuota, con gli esempi come pill da toccare; con un testo scritto, il testo e' gia' nel campo */
  const testo = t ? 'Crea una scheda nuova nelle statistiche della mia partita, per misurare questo.\n' + t : '';
  const pill = t ? null : ['Voglio misurare quante volte apro Instagram dopo le 22', 'Voglio misurare i giorni in cui chiudo la priorità'];
  let ok = false;
  try{ if (typeof agPopover === 'function') ok = await agPopover(testo, { titolo: 'Una statistica nuova', pill: pill }); }catch(_){ ok = false; }
  if (!ok && typeof agPopover !== 'function'){ try{ toast('Il tuo agente personale non risponde adesso: riprova fra poco'); }catch(_){ } }
}

/* La scheda creata dal tuo agente personale in chat (agente.js, agMsgHtml): entra una volta sola, con il suo Annulla. */
function pstAgenteHtml(a, msgId){
  const fatti = pstJ(PST_FATTI, {}) || {};
  let id = fatti[msgId];
  if (id === 'annullata') return '';
  if (!id){
    const sp = pstValida(Array.isArray(a) ? a[0] : a, a && a.richiesta);
    id = sp ? (pstAggiungi(sp, 'agente') || 'no') : 'no';
    fatti[msgId] = id;
    try{ localStorage.setItem(PST_FATTI, JSON.stringify(fatti)); }catch(_){ }
    try{ if (id !== 'no' && document.getElementById('pstBox')) pstPaint(); }catch(_){ }
  }
  if (id === 'no') return '<div class="jd-piano ag-piano ag-prog"><div class="jd-top"><span>⚽</span><b>Scheda non creata</b></div><p class="jd-piano-sub">Questa statistica parla di qualcosa che l\'app non vede da sola. Chiedi al tuo agente personale la cosa più vicina che può misurare.</p></div>';
  const c = pstMie().filter(function(x){ return x.id === id; })[0];
  if (!c) return '';
  return '<div class="jd-piano ag-piano ag-prog"><div class="jd-top"><span>⚽</span><b>Scheda aggiunta alle statistiche</b></div>'
    + '<p class="jd-piano-sub"><b>' + pstE(c.titolo) + '</b>: ' + c.righe.length + (c.righe.length === 1 ? ' riga' : ' righe') + ' con i dati veri della tua partita.</p>'
    + '<div class="ag-prog-az"><button type="button" class="jd-applica ag-applica" onclick="pstApriScheda(' + pstA(id) + ')"><span>Apri la scheda</span>' + ((typeof agSvg === 'function') ? agSvg('avanti', 16) : '') + '</button>'
    + '<button type="button" class="ag-prog-no" onclick="pstAnnullaAgente(' + pstA(msgId) + ')">Annulla</button></div></div>';
}
function pstAnnullaAgente(msgId){
  const fatti = pstJ(PST_FATTI, {}) || {};
  const id = fatti[msgId];
  if (id && id !== 'no' && id !== 'annullata') pstScriviMie(pstMie().filter(function(x){ return x.id !== id; }));
  fatti[msgId] = 'annullata';
  try{ localStorage.setItem(PST_FATTI, JSON.stringify(fatti)); }catch(_){ }
  try{ if (typeof agRidisegna === 'function') agRidisegna(); }catch(_){ }
  try{ toast('Scheda tolta dalle statistiche'); }catch(_){ }
}
/** Apre la pagina della partita sulla scheda, e la porta sotto gli occhi. */
function pstApriScheda(id){
  try{ if (typeof agPopChiudi === 'function') agPopChiudi(); }catch(_){ }
  PST.tab = id || 'riepilogo'; pstSalvaVista();
  if (typeof paApri === 'function') paApri(); else pstPaint();
  setTimeout(function(){ const b = document.getElementById('pstBox'); if (b) b.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 250);
}

/* il ritorno nella pagina (un blocco, un punto nuovo): i dati del telefono si rileggono */
function pstVisibile(){ const b = document.getElementById('pstBox'), m = document.getElementById('pstBoxMini'); return !!((b && b.offsetParent !== null) || (m && m.offsetParent !== null)); }
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible'){ PST.cache = {}; if (pstVisibile()) pstPaint(); } });
['fl:admin', 'fl:spunta', 'fl:caveau', 'fl:deviazione'].forEach(function(ev){ document.addEventListener(ev, function(){ try{ if (pstVisibile()) pstPaint(); }catch(_){ } }); });

(function(){
  const css = [
    /* la scheda scura di proposito, come lo schermo delle statistiche di FIFA: testo bianco fisso, uguale nei due temi */
    '.pst{background:linear-gradient(168deg,#123A70,#001E44 62%);color:#fff;border-radius:28px;padding:22px 0 26px;display:flex;flex-direction:column;gap:18px;overflow:hidden;box-shadow:0 10px 28px rgba(0,30,68,.18)}',
    'body.dark .pst{box-shadow:0 0 0 1px rgba(140,198,255,.16)}',
    '.pst-kick{margin:0;text-align:center;font:700 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#8CC6FF}',
    '.pst-tabs{display:flex;gap:2px;overflow-x:auto;scrollbar-width:none;padding:0 14px;border-bottom:1px solid rgba(255,255,255,.1);scroll-behavior:smooth}',
    '.pst-tabs::-webkit-scrollbar{display:none}',
    '.pst-tab{flex:none;border:0;background:none;color:rgba(255,255,255,.55);font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;padding:10px 10px 13px;position:relative;cursor:pointer;white-space:nowrap}',
    '.pst-tab.on{color:#fff}.pst-tab.on::after{content:"";position:absolute;left:10px;right:10px;bottom:-1px;height:3px;border-radius:3px;background:#3F9FF4}',
    '.pst-tab.mia{color:rgba(188,224,255,.7)}.pst-tab.mia.on{color:#fff}',
    '.pst-tab.piu{display:flex;align-items:center;justify-content:center;padding:6px 10px 9px}',
    '.pst-tab.piu svg{width:28px;height:28px;padding:6px;box-sizing:border-box;border-radius:14px;background:rgba(63,159,244,.22);color:#BCE0FF}.pst-tab.piu.on svg{background:#0075E3;color:#fff}.pst-tab.piu.on::after{left:12px;right:12px}',
    '.pst-per{display:flex;align-self:center;gap:2px;padding:3px;border-radius:99px;background:rgba(255,255,255,.07)}',
    '.pst-per button{border:0;background:none;color:rgba(255,255,255,.6);font:700 12px var(--font-body);padding:7px 14px;border-radius:99px;cursor:pointer}.pst-per button.on{background:rgba(255,255,255,.16);color:#fff}',
    '.pst-corpo{padding:6px 20px 0;display:flex;flex-direction:column;gap:24px}',
    '.pst-anelli{display:grid;grid-template-columns:1fr minmax(64px,92px) 1fr;align-items:center;gap:6px}.pst-anelli.sfoglia{cursor:pointer}',
    '.pst-an{display:flex;flex-direction:column;align-items:center;gap:6px;min-width:0}',
    '.pst-anr{position:relative;width:104px;height:104px}.pst-anr svg{display:block}',
    '.pst-anr b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:900 28px var(--font-display);letter-spacing:-.02em;font-variant-numeric:tabular-nums}.pst-anr b i{font-style:normal;font-size:14px;margin:6px 0 0 1px;opacity:.7}',
    '.pst-an span{margin-top:4px;font:800 13px var(--font-body)}.pst-an.old span{color:#FF8A94}.pst-an.neo span{color:#8CC6FF}',
    '.pst-an small{font:600 12px var(--font-body);color:rgba(255,255,255,.55);font-variant-numeric:tabular-nums}',
    '.pst-an-mid{display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center}.pst-an-mid span{font:700 12px/1.35 var(--font-body);color:rgba(255,255,255,.78)}',
    '.pst-anelli.sfoglia{touch-action:pan-y}.pst-an-mid .pst-dots{margin-top:4px;padding:8px 6px}.pst-r.tocca{cursor:pointer;-webkit-tap-highlight-color:transparent}.pst-r.tocca .pst-l{text-decoration:underline dotted rgba(255,255,255,.35);text-underline-offset:4px}.pst-r.tocca:active{background:rgba(255,255,255,.05)}',
    '.pst-mini{border-radius:22px;padding:18px 0 20px;gap:16px;box-shadow:none;margin-top:16px}.pst-mini .pst-corpo{padding:4px 14px 0}.pst-mini .pst-anelli{grid-template-columns:1fr minmax(58px,78px) 1fr}.pst-mini .pst-anr{width:86px;height:86px}.pst-mini .pst-anr svg{width:86px;height:86px}.pst-mini .pst-anr b{font-size:23px}',
    '.pst-info-e{display:block;font-size:40px;line-height:1;margin-top:8px}.pst-info h3{margin-top:12px!important}.pst-reg-k{margin:0 0 12px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}body.dark .pst-reg-k{color:#8CC6FF}',
    '.pst-reg{display:flex;flex-direction:column;gap:8px;max-height:44vh;overflow-y:auto;margin:0 0 32px;text-align:left}.pst-reg-r{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:14px;background:#F0FBFF}.pst-reg-r b{flex:none;min-width:34px;font:900 16px var(--font-display);color:#0075E3}.pst-reg-r.old b{color:#E63946}.pst-reg-r span{font:600 14px/1.35 var(--font-body);color:#001E44}.pst-reg-r small{display:block;margin-top:2px;font:600 12px var(--font-body);color:#5B6B86}',
    'body.dark .pst-reg-r{background:#12203A}body.dark .pst-reg-r span{color:#fff}body.dark .pst-reg-r small{color:#9FB3D1}body.dark .pst-reg-r b{color:#8CC6FF}body.dark .pst-reg-r.old b{color:#FF8A94}.pst-reg-vuoto{margin:0 0 32px;font:500 14px var(--font-body);color:var(--muted)}',
    '.pst-dots{display:flex;gap:5px}.pst-dots i{width:6px;height:6px;border-radius:3px;background:rgba(255,255,255,.3);transition:width .2s}.pst-dots i.on{width:16px;background:#fff}',
    '.pst-righe{display:flex;flex-direction:column}',
    '.pst-r{display:grid;grid-template-columns:62px 1fr 62px;align-items:center;gap:10px;min-height:48px;padding:6px 0;border-top:1px solid rgba(255,255,255,.07)}.pst-r:first-child{border-top:0}',
    '.pst-l{text-align:center;font:600 13px/1.35 var(--font-body);color:rgba(255,255,255,.75);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '.pst-v{position:relative;font:800 19px var(--font-display);font-variant-numeric:tabular-nums;color:rgba(255,255,255,.5);white-space:nowrap}',
    '.pst-v.old{text-align:left;padding-left:12px}.pst-v.neo{text-align:right;padding-right:12px}.pst-v.su{color:#fff}',
    '.pst-v.su::before{content:"";position:absolute;top:50%;width:4px;height:22px;margin-top:-11px;border-radius:2px}.pst-v.old.su::before{left:0;background:#E63946}.pst-v.neo.su::before{right:0;background:#3F9FF4}',
    '.pst-nota{margin:0;text-align:center;font:500 12px/1.5 var(--font-body);color:rgba(255,255,255,.55)}',
    '.pst-chi{margin:0;text-align:center;font:italic 500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.72);overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical}',
    '.pst-voti .pst-l{text-align:center;font-size:12.5px}',
    '.pst-badge{display:flex;justify-content:center;margin-bottom:-8px}.pst-badge span{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:99px;background:#BCE0FF;color:#14234A;font:800 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase}',
    '.pst-pos{display:flex;flex-direction:column;align-items:center;gap:14px}',
    '.pst-pos-c{position:relative;width:156px;height:156px}.pst-pos-c svg{display:block}',
    '.pst-pos-c > div{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}.pst-pos-c b{font:900 38px/1 var(--font-display);letter-spacing:-.02em}.pst-pos-c small{font:700 12px var(--font-body);color:#8CC6FF}',
    '.pst-leg{display:flex;justify-content:center;gap:18px;font:700 12px var(--font-body);color:rgba(255,255,255,.75)}.pst-leg span{display:flex;align-items:center;gap:6px}.pst-leg i{width:10px;height:10px;border-radius:5px}.pst-leg .old i{background:#E63946}.pst-leg .neo i{background:#3F9FF4}',
    '.pst-pr-l{display:flex;flex-direction:column;gap:14px}',
    '.pst-pr{display:grid;grid-template-columns:38px 1fr 46px 1fr 38px;align-items:center;gap:8px}',
    '.pst-pb{height:10px;border-radius:5px;background:rgba(255,255,255,.08);display:flex;overflow:hidden}.pst-pb.old{justify-content:flex-end}.pst-pb i{display:block;height:100%;border-radius:5px}.pst-pb.old i{background:#E63946}.pst-pb.neo i{background:#3F9FF4}',
    '.pst-pp{font:800 12.5px var(--font-body);font-variant-numeric:tabular-nums}.pst-pp.old{text-align:left;color:#FF8A94}.pst-pp.neo{text-align:right;color:#8CC6FF}.pst-pr.muta .pst-pp{color:rgba(255,255,255,.35)}',
    '.pst-pl{text-align:center;font:600 12px var(--font-body);color:rgba(255,255,255,.6);font-variant-numeric:tabular-nums}',
    '.pst-vuoto{display:flex;flex-direction:column;align-items:center;text-align:center;padding:8px 0}.pst-vuoto b{font:800 18px var(--font-display);margin:0 0 10px}.pst-vuoto p{margin:0 0 28px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.72)}',
    '.pst-piu{display:flex;flex-direction:column;text-align:center}',
    '.pst-piu h3{margin:0 0 10px;font:800 20px var(--font-display);color:#fff}.pst-piu > p{margin:0 0 20px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.72)}',
    '.pst-piu textarea{width:100%;box-sizing:border-box;margin:0 0 28px;padding:14px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;font:500 15px/1.45 var(--font-body);resize:none;outline:none}',
    '.pst-piu textarea::placeholder{color:rgba(255,255,255,.45)}.pst-piu textarea:focus{border-color:#3F9FF4}',
    '.pst-piu textarea{min-height:96px}.pst-piu .mic-btn{width:32px;height:32px;right:8px;bottom:8px}.pst-piu .mic-btn svg{width:18px;height:18px}',
    '.pst-cta{width:100%;min-height:52px;border:0;border-radius:26px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;padding:0 20px}.pst-cta[disabled]{opacity:.65}',
    '.pst-cta2{margin-top:16px;width:100%;min-height:46px;border:1px solid rgba(140,198,255,.5);border-radius:23px;background:rgba(63,159,244,.14);color:#fff;font:700 14.5px var(--font-body);cursor:pointer;padding:0 16px}',
    '.pst-esempi{display:flex;flex-direction:column;gap:8px;margin-top:20px}',
    '.pst-esempi button{border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:rgba(255,255,255,.8);border-radius:14px;padding:12px 14px;font:500 13.5px var(--font-body);text-align:left;cursor:pointer}',
    '.pst-esito{margin-top:20px;padding:16px;border-radius:16px;background:rgba(255,255,255,.07)}.pst-esito p{margin:0;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.85)}',
    '.pst-link{display:inline-flex;align-items:center;justify-content:center;gap:8px;align-self:center;margin-top:20px;border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);cursor:pointer;padding:6px}.pst-link.muto{margin-top:4px;color:rgba(255,255,255,.55);font-weight:600}',
    '.pst-azioni{display:flex;justify-content:center;gap:28px;margin-top:-6px}.pst-azioni button{border:0;background:none;color:#8CC6FF;font:700 13.5px var(--font-body);cursor:pointer;padding:6px}.pst-azioni button.via{color:#FF8A94}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
