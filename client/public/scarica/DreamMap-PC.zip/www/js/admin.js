/* ===========================================================================================
   L'ADMIN (0.9.241): chi ha creato l'app vede le anteprime (la prova sociale con numeri di prova,
   la partita delle idee). Lo decide il server (/api/focuslock/agent/admin, le email dell'abbonamento
   Max): nell'app non c'e' nessuna email scritta. Il risultato resta in fl_admin.
   =========================================================================================== */
function flAdmin(){ try{ return localStorage.getItem('fl_admin') === '1'; }catch(_){ return false; } }
async function flAdminVerifica(){
  try{
    if (typeof agApi !== 'function') return;
    const r = await agApi('GET', '/api/focuslock/agent/admin');
    const on = !!(r && r.admin), prima = flAdmin();
    try{ localStorage.setItem('fl_admin', on ? '1' : '0'); }catch(_){ }
    if (on !== prima) try{ document.dispatchEvent(new CustomEvent('fl:admin', { detail: on })); }catch(_){ }
  }catch(_){ }
}
setTimeout(flAdminVerifica, 2500);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(flAdminVerifica, 1500); });
