/* =========================================================================================
   LA PAGINA DELLA MAPPA, 0.9.279

   Andrea, 16/10: "se scelgo la mappa con le mosse del Genio la mappa appare scura, senza le
   mosse. Le mosse si vedono solo nella slideshow, dove non dovrebbero esserci: quella e' solo
   la cartina, satellite o minimal, con l'aereo. Toccandola si va alla pagina della mappa, e li'
   si sceglie fra la cartina, il Memento Mori e le mosse. I periodi (mosse del Genio, questa
   settimana... fra cinque anni) non nei tre puntini: pill sempre visibili sopra alla mappa,
   che scorrono di lato. Il Memento Mori intero, non tagliato a 60 anni, zoomabile, con il
   puntino blu della settimana in cui arrivo; e senza la riga della rotta sotto".

   Perche' era scura: nella pagina, lo strato «mosse» passava da rtMappaHtml, che disegna un
   <div id="rtMosse"> e lo riempie cercandolo per id. Lo stesso id c'era gia' nella slideshow:
   il riempimento finiva li', e la pagina restava col riquadro vuoto.
   ========================================================================================= */

/* Le tre viste della pagina: la cartina (satellite o minimal, con le tappe sull'arco), il
   calendario della vita, e il sentiero disegnato delle mosse. */
/* 0.9.305, Andrea: "il calendario Memento Mori e' stato tolto per sbaglio dalla pagina della mappa: va rimesso come vista
   in piu' con il pulsante del teschio, e non deve mai comparire al posto della cartina nella mappa piccola della scheda
   Mappa ne' nel pannello Mappa di Dream". LA CAUSA: dalla 0.9.290 rtStato() (rotta.js) trasforma lo strato "memento" in
   "satellite" quando c'e' una destinazione, e rtStratoDopo lo salta: con una citta' scelta il teschio non c'era piu'.
   Adesso la vista Memento Mori e' una scelta SOLO di questa pagina (fl_mpf_mm): lo strato della rotta, quello che leggono
   la slideshow della Mappa e il pannello di Dream, resta sempre la cartina o le mosse del Genio. */
const MPF_MM_K = 'fl_mpf_mm';
function mpPagMemento(){ try{ return localStorage.getItem(MPF_MM_K) === '1'; }catch(_){ return false; } }
function mpPagVista(){
  const s = (typeof rtStato === 'function') ? rtStato() : {};
  /* "memento" nello strato resta solo da prima della 0.9.305, per chi non ha una destinazione */
  if (mpPagMemento() || s.strato === 'memento') return 'memento';
  if (s.strato === 'mosse' || !s.a) return 'mosse';
  return 'cartina';
}
/* I PULSANTI DELLE VISTE, in alto a sinistra: uno per vista, quella accesa in bianco. Con una destinazione satellite,
   cartina, mosse del Genio e Memento Mori; senza destinazione solo le ultime due. */
function mpPagViste(){
  const s = rtStato(), l = s.a ? ['satellite', 'mappa', 'mosse', 'memento'] : ['mosse', 'memento'];
  const v = mpPagVista(), on = v === 'memento' ? 'memento' : v === 'mosse' ? 'mosse' : (s.strato === 'mappa' ? 'mappa' : 'satellite');
  return { l: l, on: on };
}
function mpPagScegli(v, ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  try{ mpMenuClose(); }catch(_){ }
  const s = rtStato();
  try{ localStorage.setItem(MPF_MM_K, v === 'memento' ? '1' : '0'); }catch(_){ }
  if (v !== 'memento'){
    if ((v === 'satellite' || v === 'mappa') && !s.a) v = 'mosse';
    rtSalva({ strato: v, stratoScelto: true });
  }
  try{ localStorage.setItem('fl_mp_vista', 'globo'); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(6); }catch(_){ }
  mpFullRidisegna();
  if (typeof toast === 'function' && RT_STRATI[v]) toast(RT_STRATI[v].nome);
}
/* il vecchio giro di un pulsante solo (per chi lo chiama ancora): passa alla vista dopo, Memento Mori compreso */
function mpPagCambia(ev){
  const x = mpPagViste(), i = x.l.indexOf(x.on);
  mpPagScegli(x.l[(i + 1) % x.l.length], ev);
}
/* 0.9.317, Andrea: "quattro pulsanti sempre visibili sono troppo ingombranti, il focus si disperde: voglio solo il pulsante della vista
   corrente, e toccandolo si apre un menu con le altre". */
function mpPagBtn(){
  const x = mpPagViste(), r = RT_STRATI[x.on];
  return '<button type="button" class="mpf-vista" id="mpfVista" onclick="mpPagMenu(event)" aria-haspopup="menu" aria-label="Vista: ' + r.nome + '. Tocca per cambiarla"><span>' + r.ico + '</span><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>';
}
function mpPagMenu(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('mpMenu')){ mpMenuClose(); return; }
  const box = document.getElementById('mpFull'); if (!box) return;
  const x = mpPagViste();
  const veil = document.createElement('div');
  veil.id = 'mpVeil'; veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); mpMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(veil);
  const m = document.createElement('div');
  m.id = 'mpMenu'; m.className = 'mpf-vmenu'; m.setAttribute('role', 'menu');
  m.innerHTML = x.l.map(function(k){
    const r = RT_STRATI[k], on = k === x.on;
    return '<button type="button" role="menuitem" class="' + (on ? 'on' : '') + '" onclick="mpPagScegli(\'' + k + '\',event)"><span>' + r.ico + '</span><b>' + r.nome + '</b>' + (on ? '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.500l5 5 9-10.500"/></svg>' : '') + '</button>';
  }).join('');
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(m);
  const b = document.getElementById('mpfVista'), rr = b && b.getBoundingClientRect();
  if (rr){ m.style.left = Math.round(rr.left) + 'px'; m.style.top = Math.round(rr.bottom + 8) + 'px'; }
}
/* LE PILL DEI PERIODI: dal piu' vicino a te (le mosse di oggi del Genio) al piu' lontano */
function mpPagPill(){
  const v = mpOrizzonte();
  return '<div class="mpf-oz" id="mpfOz" role="tablist">' + MP_ORIZZONTI.map(function(o){
    return '<button type="button" role="tab" class="' + (o[0] === v ? 'on' : '') + '" aria-selected="' + (o[0] === v) + '" onclick="mpSetOrizzonte(\'' + o[0] + '\')">' + o[1] + '</button>';
  }).join('') + '</div>';
}

/* IL MEMENTO MORI A PAGINA: tutta la vita, si avvicina con due dita o con + e - */
let MPF_ZOOM = 1;
function mpPagMementoHtml(){
  const c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c) return '<div class="mpf-mm-vuoto"><p>Per vedere la tua vita in settimane mi serve la tua data di nascita.</p>'
    + '<button type="button" class="cta" onclick="mpClose();mmOpen(\'s-home\')">Scrivi la data di nascita</button></div>';
  setTimeout(mpPagMementoDisegna, 30);
  return '<div class="mpf-mm">'
    + '<div class="mpf-mm-zoom"><button type="button" onclick="mpPagZoom(-1)" aria-label="Allontana">−</button><button type="button" onclick="mpPagZoom(1)" aria-label="Avvicina">+</button></div>'
    + '<div class="mpf-mm-scroll" id="mpfMmScroll"><div class="mpf-mm-in" id="mpfMmIn" style="width:' + (MPF_ZOOM * 100) + '%"><canvas id="mpfMmCv"></canvas></div></div>'
    + (typeof vsLegendaHtml === 'function' ? vsLegendaHtml(mpPagMetaSett() >= 0, 'mpf-mm-leg')
        : '<div class="mpf-mm-leg"><span><i class="ora"></i>Questa settimana</span></div>')
    + '</div>';
}
/* la settimana d'arrivo: la stessa del report della settimana (vsMetaIdx, vita-settimane.js), contata come mmConti.
   0.9.305: qui si leggeva lo stato grezzo e si scartava la data con "oltre" acceso, che negli stati salvati prima della
   0.9.304 vuol dire anche "oltre la scadenza scelta": il punto blu spariva. */
function mpPagMetaSett(){
  if (typeof vsMetaIdx === 'function'){ try{ return vsMetaIdx(mmConti()); }catch(_){ return -1; } }
  return -1;
}
function mpPagMementoDisegna(){
  const cv = document.getElementById('mpfMmCv'); if (!cv || typeof mmDisegna !== 'function') return;
  const c = mmConti(); if (!c) return;
  const w = mpPagMetaSett();
  mmDisegna(c, (typeof mmAnni === 'function') ? mmAnni() : 80, { canvas: cv, chiaro: true, segni: w >= 0 ? [{ settimana: w, tipo: 'meta' }] : [] });
  mpPagPizzico();
}
function mpPagZoom(d, fuoco){
  const sc = document.getElementById('mpfMmScroll'), inn = document.getElementById('mpfMmIn');
  const prima = MPF_ZOOM;
  MPF_ZOOM = Math.max(1, Math.min(4, typeof d === 'number' && Math.abs(d) < 1.5 && fuoco === undefined ? MPF_ZOOM + d : d));
  if (!sc || !inn || prima === MPF_ZOOM) return;
  /* si tiene fermo il punto al centro (o fra le dita) */
  const fx = fuoco ? fuoco.x : sc.clientWidth / 2, fy = fuoco ? fuoco.y : sc.clientHeight / 2;
  const rx = (sc.scrollLeft + fx) / (inn.offsetWidth || 1), ry = (sc.scrollTop + fy) / (inn.offsetHeight || 1);
  inn.style.width = (MPF_ZOOM * 100) + '%';
  const cv = document.getElementById('mpfMmCv'); if (cv) delete cv.dataset.fatto;
  mpPagMementoDisegna();
  sc.scrollLeft = rx * inn.offsetWidth - fx; sc.scrollTop = ry * inn.offsetHeight - fy;
}
function mpPagPizzico(){
  const sc = document.getElementById('mpfMmScroll'); if (!sc || sc.dataset.pz) return;
  sc.dataset.pz = '1';
  let d0 = 0, z0 = 1;
  const dist = function(t){ return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); };
  sc.addEventListener('touchstart', function(e){ if (e.touches.length === 2){ d0 = dist(e.touches); z0 = MPF_ZOOM; } }, { passive: true });
  sc.addEventListener('touchmove', function(e){
    if (e.touches.length !== 2 || !d0) return;
    e.preventDefault();
    const r = sc.getBoundingClientRect();
    const fuoco = { x: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, y: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
    const z = Math.round(z0 * dist(e.touches) / d0 * 4) / 4;
    if (z !== MPF_ZOOM) mpPagZoom(z, fuoco);
  }, { passive: false });
  sc.addEventListener('touchend', function(e){ if (e.touches.length < 2) d0 = 0; }, { passive: true });
}

/* LA PAGINA */
mpFullHtml = function(){
  const part = mpPartenza(), arr = mpArrivo();
  if (!part || !arr) return '';
  const vista = mpPagVista(), oz = mpOrizzonte();
  /* 0.9.301: sulla cartina le tappe sono quelle del viaggio intero (rtTappeViaggio, rotta.js), non i passi del periodo
     scelto: le pill dei periodi restano nella vista delle mosse, dove i passi si disegnano sul sentiero */
  const sotto = vista === 'memento'
    ? 'Ogni casella è una settimana della tua vita.' + (mpPagMetaSett() >= 0 ? ' Il mirino blu è la settimana in cui arrivi al tuo sogno.' : '')
    : vista === 'cartina' ? mpPagSottoCartina()
    : (oz === 'genio' ? 'Sulla mappa vedi le mosse che ti consiglia il Genio.' : 'Sulla mappa vedi ' + (MP_PASSI_DI[oz] || 'i tuoi passi').toLowerCase() + '.');
  let mappa;
  if (vista === 'memento') mappa = mpPagMementoHtml();
  else if (vista === 'mosse') mappa = '<div class="mpf-map">' + mpSvg(MP_TAPPE || [], true) + '</div>';
  else mappa = '<div class="mpf-map globo">' + mpFullGlobo() + '</div>';
  return '<div class="mpf-bar">'
    +   mpPagBtn()
    +   '<button type="button" class="mpf-btn mp-dots-full" onclick="mpMenuOpen(event)" aria-label="Opzioni del viaggio">⋯</button>'
    +   '<button type="button" class="mpf-btn" onclick="mpClose()" aria-label="Chiudi la mappa">✕</button>'
    + '</div>'
    + '<header class="mpf-head"><small>Il tuo sogno</small>'
    +   '<h2><span>' + arr.ico + '</span>' + esc(arr.nome) + '</h2>'
    +   '<p>' + sotto + '</p></header>'
    + (vista === 'mosse' ? mpPagPill() : '')
    + mappa
    + mpArrivoCard();
};
/* La frase sotto al sogno, nella vista cartina: di cosa sono le tappe sull'arco. */
function mpPagSottoCartina(){
  let t = null;
  try{ t = (typeof rtTappeViaggio === 'function') ? rtTappeViaggio()[0] : null; }catch(_){ t = null; }
  if (!t) return 'Sulla rotta vedi le tappe del tuo viaggio.';
  const ogni = t.u === 'anno' ? 'una per ogni anno' : t.u === 'trimestre' ? 'una per ogni trimestre' : t.u === 'mese' ? 'una per ogni mese' : 'una ogni ' + (t.passo / 12) + ' anni';
  return 'Sulla rotta vedi le tappe del tuo viaggio, ' + ogni + '. Quelle con la spunta le hai già superate.';
}
/* dopo ogni disegno: il globo (solo nella vista cartina) e la pill scelta in vista */
mpFullRidisegna = function(){
  const b = document.getElementById('mpFull');
  if (!b) return;
  const y = b.scrollTop;
  mpMenuClose();
  b.innerHTML = mpFullHtml();
  b.scrollTop = y;
  if (mpPagVista() === 'cartina') setTimeout(mpPaintGlobo, 20);
  const on = b.querySelector('.mpf-oz .on');
  if (on && on.parentNode) on.parentNode.scrollLeft = Math.max(0, on.offsetLeft - 16);
};
(function(){
  const apri = mpOpen;
  mpOpen = window.mpOpen = function(){
    try{ localStorage.setItem('fl_mp_vista', 'globo'); }catch(_){ }
    apri.apply(this, arguments);
    mpFullRidisegna();
  };
  /* il globo grande: nella pagina lo strato e' sempre una cartina vera */
  const pg = mpPaintGlobo;
  mpPaintGlobo = window.mpPaintGlobo = function(){
    if (!document.getElementById('mpFull') || mpPagVista() === 'cartina') return pg.apply(this, arguments);
  };
})();
/* i tre puntini tengono solo il viaggio e il piano: i periodi sono nelle pill */
mpMenuOpen = function(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('mpMenu')){ mpMenuClose(); return; }
  const box = document.getElementById('mpFull') || document.getElementById('scMap');
  if (!box) return;
  const veil = document.createElement('div');
  veil.id = 'mpVeil'; veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); mpMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(veil);
  const m = document.createElement('div');
  m.className = 'arb-menu'; m.id = 'mpMenu';
  m.innerHTML = '<p class="arb-mtit">Il viaggio</p>'
    + '<button type="button" onclick="mpOpzioniApri()">⚙️ Opzioni di viaggio</button>'
    + '<p class="arb-mtit">Il piano</p>'
    + '<button type="button" onclick="mpClose();ozOpen()">Apri gli orizzonti ' + (typeof flChevSvg === 'function' ? flChevSvg('›') : '') + '</button>';
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || document.querySelector('.mp-dots-full, .mp-dots'));
};

/* LA SLIDESHOW: solo la cartina. Se lo strato salvato e' il memento o le mosse (scelti nella
   pagina), qui si mostra il satellite; il suo pulsante passa solo fra satellite e minimal, e
   toccare la cartina apre la pagina. */
(function(){
  if (typeof sevGloboPaint !== 'function') return;
  const orig = sevGloboPaint;
  sevGloboPaint = window.sevGloboPaint = function(){
    const st = (typeof rtStato === 'function') ? rtStato() : null;
    const box = document.getElementById('sevGlobo');
    if (!st || !box) return orig.apply(this, arguments);
    const vero = st.strato;
    const geo = (vero === 'mappa') ? 'mappa' : 'satellite';
    /* si disegna con lo strato geografico, senza toccare quello scelto nella pagina */
    const rs = rtStato;
    rtStato = window.rtStato = function(){ const x = rs.apply(this, arguments); return Object.assign({}, x, { strato: geo }); };
    try{ orig.apply(this, arguments); } finally { rtStato = window.rtStato = rs; }
    setTimeout(function(){
      const b = box.querySelector('.mpf-strato');
      if (b){
        const dopo = geo === 'satellite' ? 'mappa' : 'satellite';
        b.textContent = RT_STRATI[dopo].ico;
        b.setAttribute('aria-label', 'Passa a: ' + RT_STRATI[dopo].nome);
        b.onclick = function(e){ e.stopPropagation(); rtSalva({ strato: dopo, stratoScelto: true }); delete box.dataset.firma; sevGloboPaint(); try{ toast(RT_STRATI[dopo].nome); }catch(_){ } };
        b.removeAttribute('onclick');
      }
    }, 40);
    if (!box.dataset.apre){
      box.dataset.apre = '1';
      box.style.cursor = 'pointer';
      box.addEventListener('click', function(e){ if (e.target.closest('button,a')) return; if (typeof mpOpen === 'function') mpOpen(); });
    }
  };
})();

/* IL PANNELLO "MAPPA" DI DREAM (rotta-tab.js, nvpMappaHtml), 0.9.305. Andrea: "li' compare sempre la citta' (se il sogno
   ha un luogo fisico) oppure, come ripiego, le mosse del Genio; mai il Memento Mori". Con una destinazione la cartina
   delle mosse lascia il posto alla cartina vera (satellite o minimal, mai lo strato della pagina); senza, resta com'e'.
   Si avvolge qui per non toccare rotta-tab.js. */
(function(){
  if (typeof nvpMappaHtml !== 'function') return;
  const orig = nvpMappaHtml;
  const FINE = '<span>Tocca per aprire la cartina</span></button>';
  nvpMappaHtml = window.nvpMappaHtml = function(){
    let h = orig.apply(this, arguments);
    let s = null; try{ s = rtStato(); }catch(_){ s = null; }
    if (!s || !s.da || !s.a) return h;
    const cart = '<button type="button" class="nvp-map nvp-citta" onclick="mpOpen()" aria-label="Apri la cartina del viaggio"><div class="mp-globo nvp-globo" id="nvpGlobo"></div>' + FINE;
    const i = h.indexOf('<button type="button" class="nvp-map"'), j = i >= 0 ? h.indexOf(FINE, i) : -1;
    if (i >= 0 && j > i) h = h.slice(0, i) + cart + h.slice(j + FINE.length);
    else h = h.replace('<span class="nvp-ico" aria-hidden="true">🗺️</span>', cart);
    setTimeout(mpNvpGloboDisegna, 30);
    return h;
  };
})();
function mpNvpGloboDisegna(){
  const box = document.getElementById('nvpGlobo'); if (!box || typeof rtMappaHtml !== 'function') return;
  const s = rtStato(); if (!s.da || !s.a) return;
  const geo = s.strato === 'mappa' ? 'mappa' : 'satellite';
  /* 0.9.318, Andrea: "toccando Mappa la cartina prima e' scura e poi compare". Il disegno aspettava che la scheda fosse visibile:
     nascosta la larghezza era zero, si riprovava una volta sola dopo 400 ms e le tessere partivano solo allora. Adesso si disegna
     anche da nascosta, con la larghezza del pannello: le immagini partono quando si apre Dream, e al tocco sono gia' li'.
     Le tessere restano nella cache del telefono (sw.js, fx-tessere). */
  const corpo = box.closest('.nvp-corpo');
  const L = Math.max(200, Math.round(box.clientWidth || (corpo && corpo.clientWidth ? corpo.clientWidth - 58 : (innerWidth - 90)))), H = Math.max(140, Math.round(box.clientHeight || 190));
  /* la stessa cartina non si ridisegna (l'aereo ripartirebbe da capo a ogni giro del pannello) */
  const firma = [s.da.lat, s.da.lon, s.a.lat, s.a.lon, geo, L, H].join('|');
  if (box.dataset.firma === firma && box.firstChild) return;
  box.dataset.firma = firma;
  box.innerHTML = rtMappaHtml(s.da, s.a, geo, L, H, (typeof MP_TAPPE !== 'undefined' && MP_TAPPE) || []);
}
document.addEventListener('fl:tab', function(e){ if (e && e.detail === 'rotta'){ setTimeout(mpNvpGloboDisegna, 60); setTimeout(mpNvpGloboDisegna, 600); } });

(function mpPagStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.mpf-oz{display:flex;gap:8px;overflow-x:auto;margin:0 -16px 16px;padding:2px 16px;scrollbar-width:none;scroll-snap-type:x proximity}',
    '.mpf-oz::-webkit-scrollbar{display:none}',
    '.mpf-oz button{flex:none;scroll-snap-align:start;border:0;border-radius:999px;padding:10px 16px;background:#14234A;color:rgba(255,255,255,.82);',
      'font:700 14px var(--font-body);white-space:nowrap;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.14)}',
    '.mpf-oz button.on{background:#fff;color:#0E2350;box-shadow:none}',
    '.mpf-mm{position:relative;border-radius:20px;background:#FBF7F3;overflow:hidden}',
    '.mpf-mm-scroll{max-height:none;overflow:auto;padding:16px 12px;scrollbar-width:none;touch-action:pan-x pan-y}',
    '.mpf-mm-scroll::-webkit-scrollbar{display:none}',
    '.mpf-mm-in{min-width:100%}.mpf-mm-in canvas{display:block}',
    '.mpf-mm-zoom{position:absolute;top:10px;right:10px;z-index:2;display:flex;gap:6px}',
    '.mpf-mm-zoom button{width:36px;height:36px;border:0;border-radius:50%;background:#0E2350;color:#fff;font:800 20px/1 var(--font-body);cursor:pointer;box-shadow:0 4px 12px rgba(0,30,68,.25)}',
    /* la legenda (vsLegendaHtml): una riga centrata sotto al calendario, ogni voce su una riga sola */
    '.mpf-mm-leg,.vs-leg.mpf-mm-leg{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:8px 20px;margin:0;padding:4px 12px 16px;font:700 13px var(--font-body);color:#3A2E2B}',
    '.mpf-mm-leg span,.vs-leg.mpf-mm-leg span{display:inline-flex;align-items:center;gap:8px;white-space:nowrap}',
    '.mpf-mm-leg i.ora{width:11px;height:11px;flex:none;border-radius:2px;background:#E63946}',
    /* 0.9.305: i pulsanti delle viste, a sinistra nella barra; ⋯ e la X restano a destra */
    '.mpf-vista{display:flex;align-items:center;gap:4px;margin-right:auto;height:44px;padding:0 10px 0 12px;border:0;border-radius:99px;background:#14234A;color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.14);cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.mpf-vista span{font-size:21px;line-height:1}',
    '.mpf-vmenu{position:fixed;z-index:9650;min-width:236px;max-width:calc(100vw - 32px);padding:6px;border-radius:18px;background:#14234A;box-shadow:0 14px 34px rgba(0,0,0,.45),inset 0 0 0 1px rgba(255,255,255,.14);animation:mpfVm .16s ease-out}',
    '@keyframes mpfVm{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}',
    '.mpf-vmenu button{display:flex;align-items:center;gap:12px;width:100%;min-height:50px;padding:8px 12px;border:0;border-radius:13px;background:transparent;color:#fff;text-align:left;cursor:pointer}',
    '.mpf-vmenu button span{flex:none;font-size:21px;line-height:1}.mpf-vmenu button b{flex:1;min-width:0;font:700 15px/1.25 var(--font-body)}.mpf-vmenu button svg{flex:none;color:#8CC6FF}',
    '.mpf-vmenu button.on{background:rgba(63,159,244,.18)}',
    /* la cartina vera nel pannello Mappa di Dream */
    '.nvp-map.nvp-citta{padding:8px 8px 12px}.nvp-citta .mp-globo{height:190px;margin:0 0 10px;background:#16406F}',
    '.mpf-mm-vuoto{padding:32px 20px;border-radius:20px;background:#14234A;text-align:center}.mpf-mm-vuoto p{margin:0 0 20px;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.85)}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* =========================================================================================
   I PERIODI DELLA MAPPA, 0.9.281

   Andrea, 17/10: "la prima tab non e' Le mosse del Genio ma Oggi, con le tappe di oggi disegnate come le
   mosse; Le mosse del Genio come ultima. In ogni periodo piu' passi, come nelle mosse (1, 2, 3 e poi il
   risultato), non uno solo: i passi della roadmap che il Genio ha proposto in chat. Il prossimo passo in
   evidenza, gli altri quasi trasparenti, cosi' ci si concentra solo su quello". E "Un giorno" dopo
   "Fra cinque anni" sembrava "oggi": si chiama "Il sogno".
   ========================================================================================= */
MP_ORIZZONTI.length = 0;
[['oggi', 'Oggi'], ['settimana', 'Questa settimana'], ['mese', 'Questo mese'], ['anno', 'Quest\'anno'], ['cinque', 'Fra cinque anni'], ['ungiorno', 'Il sogno'], ['genio', 'Le mosse del Genio']]
  .forEach(function(x){ MP_ORIZZONTI.push(x); });
MP_PASSI_DI.oggi = 'I passi di oggi';
MP_PASSI_DI.ungiorno = 'I passi verso il tuo sogno';
mpOrizzonte = function(){ try{ const v = localStorage.getItem('fl_mp_oz2'); return v || 'oggi'; }catch(_){ return 'oggi'; } };
(function(){
  const vecchia = mpSetOrizzonte;
  mpSetOrizzonte = window.mpSetOrizzonte = function(v){ try{ localStorage.setItem('fl_mp_oz2', v); }catch(_){ } return vecchia.apply(this, arguments); };
})();
/** I passi proposti dal Genio nell'ultima roadmap della chat, per chi non l'ha ancora applicata. */
function mpPropostaDi(k){
  try{
    const l = (typeof agStato === 'function') ? agStato().msgs : [];
    for (let i = l.length - 1; i >= 0; i--){ const p = l[i] && l[i].azioni && l[i].azioni.piano; if (p && p[k] && Array.isArray(p[k].passi) && p[k].passi.length) return p[k].passi.map(String); }
  }catch(_){ }
  return [];
}
function mpEscT(t){ return (typeof esc === 'function') ? esc(t) : String(t || ''); }
mpTappeDi = window.mpTappeDi = async function(){
  const v = mpOrizzonte();
  if (v === 'genio') return (typeof orBuildPlan === 'function') ? await orBuildPlan() : [];
  let passi = [];
  try{ if (typeof ozAnello === 'function'){ const a = ozAnello(v === 'ungiorno' ? 'cinque' : v); passi = (a.passi || []).filter(function(x){ return x && x.t && !x.fatto; }).map(function(x){ return x.t; }); } }catch(_){ }
  let proposta = false;
  if (!passi.length){ passi = mpPropostaDi(v === 'ungiorno' ? 'cinque' : v); proposta = passi.length > 0; }
  /* oggi, senza roadmap: le tappe della mappa ancora da fare */
  if (!passi.length && v === 'oggi'){
    try{
      const s = sdStato();
      const l = sdTutti().filter(function(nd){ return !sdNodoFatto(nd, s); }).slice(0, 5);
      return l.map(function(nd, i){ return { ico: (typeof SD_ICO !== 'undefined' && SD_ICO[nd.tipo]) || '📍', t: mpEscT(sdNomeTappa(nd)), s: i ? 'Una tappa della mappa, dopo quelle prima.' : 'La prossima tappa della mappa: si comincia da qui.', go: 'sdTapVia(\'' + nd.id + '\')', sbiadita: i > 0, prossima: i === 0 }; });
    }catch(_){ return []; }
  }
  return passi.slice(0, 8).map(function(t, i){
    return { ico: i ? '📍' : '👉', t: mpEscT(t), s: (i ? 'Un passo dopo il prossimo: per adesso resta in fondo.' : 'Il prossimo passo: concentrati solo su questo.') + (proposta ? ' Dalla roadmap che ti ha proposto il Genio: la trovi in chat, con "Applica la roadmap".' : ''),
             go: 'ozOpen()', sbiadita: i > 0, prossima: i === 0 };
  });
};
(function mpPeriodiStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.mpf-oz{scroll-padding-inline:16px;scroll-snap-type:none}',
    '.mp-node.step.sbiadita{opacity:.22}',
    '.mp-node.step.prossima circle:first-child{stroke:#fff;stroke-width:1.2}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* LA ROTTA COME GOOGLE MAPS (0.9.281): partenza e arrivo uno sotto l'altro, con il pallino blu e lo spillo
   rosso; un tocco su uno dei due apre la scelta del luogo. Sotto, quanta strada e' gia' fatta. */
mpFullGlobo = window.mpFullGlobo = function(){
  const s = (typeof rtStato === 'function') ? rtStato() : null;
  if (!s || !s.da || !s.a) return '<p class="mpf-vuoto">Se il tuo sogno ha un luogo nel mondo, una città dove vuoi arrivare, sceglila: qui vedrai la rotta.</p>';
  const km = (typeof rtKm === 'function') ? rtKm(s.da, s.a) : 0;
  const nome = function(x){ return mpEscT(String(x.nome || '').split(',')[0]); };
  return '<div class="mp-globo big" id="mpGloboFull"></div>'
    + '<div class="mpf-gm">'
    +   '<div class="mpf-gm-righe">'
    +     '<button type="button" class="mpf-gm-r" onclick="mpClose();rtApriCerca(\'da\')"><i class="mpf-gm-da"></i><span>' + nome(s.da) + '</span></button>'
    +     '<i class="mpf-gm-sep" aria-hidden="true"></i>'
    +     '<button type="button" class="mpf-gm-r" onclick="mpClose();rtApriCerca(\'a\')"><i class="mpf-gm-a"></i><span>' + nome(s.a) + '</span></button>'
    +   '</div>'
    +   (km ? '<small class="mpf-gm-km">' + String(Math.round(km)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' km</small>' : '')
    + '</div>'
    + '<div class="mpf-perc" id="mpfPerc">' + mpFullPercInner() + '</div>';
};
/* LA PERCENTUALE DEL PERCORSO, nella pagina della partenza: dalla strada gia' fatta prima di DreamMap, o solo da
   quando c'e' la roadmap. E' la stessa percentuale dell'intestazione e della Mappa. */
(function(){
  if (typeof rtPopolariHtml !== 'function') return;
  const v = rtPopolariHtml;
  rtPopolariHtml = window.rtPopolariHtml = function(){
    let h = v.apply(this, arguments);
    if (typeof RT_QUALE !== 'undefined' && RT_QUALE !== 'da') return h;
    const m = (typeof hdPercModo === 'function') ? hdPercModo() : 'sogno';
    return '<div class="rt-perc"><div class="rt-perc-t"><b>Il percorso fatto</b><button type="button" class="dp-i rt-perc-i" onclick="mpPercInfo()" aria-label="Come si calcola">i</button></div>'
      + '<button type="button" class="rt-perc-o' + (m === 'sogno' ? ' on' : '') + '" onclick="hdPercModoSet(\'sogno\');rtApriCerca(\'da\')"><b>Da quando ho iniziato il viaggio verso il mio sogno</b><small>Conta anche la strada fatta prima di DreamMap</small></button>'
      + '<button type="button" class="rt-perc-o' + (m === 'app' ? ' on' : '') + '" onclick="hdPercModoSet(\'app\');rtApriCerca(\'da\')"><b>Da quando uso DreamMap</b><small>Conta solo la strada fatta con la tua roadmap</small></button></div>'
      + h;
  };
})();
function mpPercInfo(){
  if (typeof stgFoglio !== 'function') return;
  let par = 0; try{ par = (typeof ptzPct === 'function') ? ptzPct() : 0; }catch(_){ }
  stgFoglio('<small class="stg-eti">Il percorso fatto</small><h2 class="stg-h">Come si calcola la percentuale</h2>'
    + '<div class="sc-come">'
    + '<div><span>🧭</span><p><b>Un numero solo</b>È quello in alto nell\u2019intestazione, ed è lo stesso nella Mappa.</p></div>'
    + '<div><span>🏁</span><p><b>Da quando hai iniziato il viaggio verso il tuo sogno</b>Parte dalla strada che avevi già fatto prima di DreamMap' + (par ? ' (il ' + Math.round(par * 100) + '%, dalla tua risposta "Da dove parti?")' : '') + ', e sale con le tappe che chiudi.</p></div>'
    + '<div><span>📲</span><p><b>Da quando usi DreamMap</b>Parte da zero il giorno della tua roadmap: conta solo le tappe fatte qui.</p></div>'
    + '</div><button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho capito</button>');
}
(function mpGmStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.mpf-gm{display:flex;align-items:center;gap:12px;padding:14px 16px 6px}.mpf-gm-righe{flex:1;min-width:0;display:flex;flex-direction:column}',
    '.mpf-gm-r{display:flex;align-items:center;gap:12px;border:0;background:transparent;padding:8px 0;color:#fff;font:700 16px var(--font-body);text-align:left;cursor:pointer;min-width:0}',
    '.mpf-gm-r span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-bottom:8px;border-bottom:1px solid rgba(255,255,255,.14)}',
    '.mpf-gm-da{flex:none;width:12px;height:12px;border-radius:50%;background:#4FB8FF;box-shadow:0 0 0 3px rgba(79,184,255,.3)}',
    '.mpf-gm-a{flex:none;width:12px;height:12px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:#E63946}',
    '.mpf-gm-sep{display:block;width:2px;height:12px;margin:-4px 0 -4px 5px;background-image:linear-gradient(rgba(255,255,255,.5) 50%,transparent 50%);background-size:2px 4px}',
    '.mpf-gm-km{flex:none;font:700 14px var(--font-body);color:rgba(255,255,255,.7)}',
    '.rt-perc{margin:0 0 18px;padding:16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .rt-perc{background:#14234A;border-color:rgba(255,255,255,.12)}',
    '.rt-perc-t{display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:12px}.rt-perc-t b{font:800 16px var(--font-display);color:var(--navy)}body.dark .rt-perc-t b{color:#fff}.rt-perc-i{width:22px;height:22px}',
    '.rt-perc-o{display:block;width:100%;text-align:center;border:1.5px solid var(--line);border-radius:14px;background:transparent;padding:12px 14px;margin-top:10px;cursor:pointer}',
    '.rt-perc-o b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}.rt-perc-o small{display:block;margin-top:3px;font:500 12.5px var(--font-body);color:var(--muted)}',
    'body.dark .rt-perc-o b{color:#fff}.rt-perc-o.on{border-color:#0075E3;background:rgba(0,117,227,.08)}'
  ].join('\n');
  document.head.appendChild(st);
})();
