/* ===========================================================================================
   LE SFIDE — si vincono con i dati veri, non con le promesse

   Le sfide stanno in content/sfide.json: una nuova si aggiunge li', senza toccare il codice.
   Ogni sfida ha una metrica che l'app misura da sola dai dati che ha gia':
     ff_min            minuti di Full Focus portati a termine nel periodo
     no_social_prima   nessuna app che distrae prima di un'ora, per N giorni (dati d'uso)
     app_zero          zero minuti sull'app piu' distraente dell'utente, per N giorni (dati d'uso)
     categoria_attiva  una categoria del Blocco dentro al Blocco rapido, acceso e mai interrotto
     streak            giorni di fila con la Modalita' severa accesa
   Niente auto-dichiarazioni, niente foto da caricare: o il dato c'e', o la sfida non conta.

   LA POSTA. Al «Accetta» si possono mettere in gioco monete dell'app (mai Dream Points, mai
   soldi): chi arriva in fondo le riprende doppie, chi molla le perde e vede uno schermo nero
   con una parola sola. E' l'avversione alla perdita messa al servizio della persona.

   Qui vivono anche: il Monk Mode (che sta in scrigni.js e qui e' solo una card), il registro
   delle partite (nuovo te contro vecchio te, quattordici giorni) e «Bentornato», la schermata di
   chi torna dopo tre o piu' giorni senza sessioni: si apre da sola all'apertura dell'app, non
   sta nella pagina Amici.
   =========================================================================================== */
const SF = { cfg: null, conta: {}, contaAt: 0, misure: {}, inCorso: false };
const SF_KEY = 'fl_sfide';
const SF_CFG_KEY = 'fl_sfide_cfg';
const SF_PARI_KEY = 'fl_pari_visto';

function sfT(k, v){ return (typeof amT === 'function') ? amT('sfide.' + k, v) : k; }
function sfLeggiJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function sfScriviJ(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function sfDay(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function sfGiorno0(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
const SF_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
function sfDataIt(iso){ const d = new Date(iso + 'T12:00:00'); return d.getDate() + ' ' + SF_MESI[d.getMonth()]; }
function sfDataMs(t){ const d = new Date(t); return d.getDate() + ' ' + SF_MESI[d.getMonth()]; }

async function sfCarica(){
  try{
    const r = await fetch('content/sfide.json', { cache: 'no-cache' });
    const j = await r.json();
    if (j && Array.isArray(j.sfide)){ SF.cfg = j; sfScriviJ(SF_CFG_KEY, j); }
  }catch(_){ }
  if (!SF.cfg) SF.cfg = sfLeggiJ(SF_CFG_KEY, null);
  return SF.cfg;
}
function sfLista(){ return (SF.cfg && SF.cfg.sfide) || []; }
function sfPoste(){ return (SF.cfg && SF.cfg.poste) || [0, 50, 100, 200]; }
function sfCfg(id){ return sfLista().filter(function(c){ return c.id === id; })[0] || null; }
function sfStati(){ return sfLeggiJ(SF_KEY, {}) || {}; }
function sfSalva(s){ sfScriviJ(SF_KEY, s); }
function sfStato(id){ return sfStati()[id] || null; }
/** Per la sync: quali sfide sono in corso (il server conta i partecipanti). */
function sfAttive(){
  const s = sfStati();
  return Object.keys(s).filter(function(id){ return s[id] && (s[id].stato === 'attiva' || s[id].stato === 'iscritto'); }).map(function(id){ return { id: id, stato: 'attiva' }; });
}
async function sfContaCarica(){
  if (typeof frApi !== 'function' || Date.now() - SF.contaAt < 10 * 60000) return SF.conta;
  const ids = sfLista().map(function(c){ return c.id; });
  if (!ids.length) return SF.conta;
  try{ const r = await frApi('GET', '/api/focuslock/social/sfide?ids=' + encodeURIComponent(ids.join(','))); SF.conta = (r && r.partecipanti) || {}; SF.contaAt = Date.now(); sfScriviJ('fl_sfide_conta', SF.conta); }
  catch(_){ if (!Object.keys(SF.conta).length) SF.conta = sfLeggiJ('fl_sfide_conta', {}) || {}; }
  return SF.conta;
}

/* ---------------------------------------------------------------- la finestra e la misura */
function sfFinestra(c, st){
  if (c.inizio && c.fine){
    /* 0.9.344, Andrea: "accetto Novembre pulito e dice subito 'Non e' andata'". La sfida contava dal primo novembre anche per chi entrava
       il 9: i giorni prima di entrare risultavano falliti (blocco non ancora acceso, o un'interruzione di quei giorni). Conta dal giorno
       in cui entri fino alla fine, e i giorni da fare sono quelli che restano */
    let da = sfGiorno0(new Date(c.inizio + 'T00:00:00'));
    const a = sfGiorno0(new Date(c.fine + 'T00:00:00')) + 86400000;
    if (st && st.da && sfGiorno0(st.da) > da) da = Math.min(sfGiorno0(st.da), a - 86400000);
    return { da: da, a: a, fissa: true, giorni: Math.max(1, Math.round((a - da) / 86400000)) };
  }
  const da = sfGiorno0((st && st.da) || Date.now());
  return { da: da, a: da + (c.durataGiorni || 7) * 86400000, fissa: false };
}
function sfDistrae(pkg){
  try{ if (typeof scExcluded === 'function' && scExcluded().indexOf(pkg) >= 0) return false; }catch(_){ }
  try{ return (typeof scIsDistracting === 'function') && scIsDistracting(pkg); }catch(_){ return false; }
}
/** I minuti delle app che distraggono in una finestra (dati d'uso del telefono). */
async function sfMinutiDistrazione(from, to, soloPkg){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return null;
  try{
    const t = await NATIVE.getTopApps({ from: from, to: to, limit: 200, by: 'ms', icons: 0 });
    const apps = (t && t.apps) || [];
    let ms = 0;
    apps.forEach(function(a){ if (soloPkg ? a.packageName === soloPkg : (!a.self && sfDistrae(a.packageName))) ms += a.ms || 0; });
    return Math.round(ms / 60000);
  }catch(_){ return null; }
}
/** L'app piu' distraente degli ultimi sette giorni: { pkg, label } o null. */
async function sfAppTop(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return null;
  try{
    const t = await NATIVE.getTopApps({ from: Date.now() - 7 * 86400000, to: Date.now(), limit: 60, by: 'ms', icons: 0 });
    const a = ((t && t.apps) || []).filter(function(x){ return !x.self && sfDistrae(x.packageName); })[0];
    return a ? { pkg: a.packageName, label: a.label || a.packageName } : null;
  }catch(_){ return null; }
}
function sfSerieSevera(){
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (!st || !st.start) return 0;
    if (typeof sevState !== 'undefined' && sevState !== null && !(sevState && sevState.level)) return 0;
    return Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
  }catch(_){ return 0; }
}
function sfCategoriaAccesa(c){
  try{
    const cat = (typeof flCatById === 'function') ? flCatById(c.categoria) : null;
    if (!cat || typeof QUICK === 'undefined') return false;
    const siti = (typeof flCatItems === 'function' ? flCatItems(cat).sites : cat.sites) || [];
    const tutti = siti.every(function(s){ return (QUICK.sites || []).indexOf(s) >= 0; });
    return !!(QUICK.enabled && tutti);
  }catch(_){ return false; }
}
/* quante interruzioni risultano in un giorno (0.9.344: quelle fatte PRIMA di entrare nella sfida non contano) */
function sfInterrottiN(day){
  try{ const l = (typeof itLog === 'function') ? itLog() : {}; const d = l[day] || {}; return Object.keys(d).reduce(function(t, k){ return t + (+d[k] > 0 ? +d[k] : 0); }, 0); }catch(_){ return 0; }
}
function sfInterrottoIl(day){
  try{ const l = (typeof itLog === 'function') ? itLog() : {}; const d = l[day] || {}; return Object.keys(d).some(function(k){ return +d[k] > 0; }); }catch(_){ return false; }
}
/**
 * Misura una sfida: { fatto, target, pct, vinta, persa, attesa, giorniMancanti, nota }.
 * `nota` e' un testo breve quando manca un dato (permessi) o l'app installata.
 */
async function sfMisura(c, st){
  const ora = Date.now();
  const w = sfFinestra(c, st);
  const out = { fatto: 0, target: (w.fissa && w.giorni && c.metrica !== 'streak') ? Math.min(c.target || 1, w.giorni) : (c.target || 1), pct: 0, vinta: false, persa: false, attesa: ora < w.da, giorniMancanti: Math.max(0, Math.ceil((w.a - ora) / 86400000)), nota: '', fine: w.a, inizio: w.da };
  if (out.attesa) return out;
  const fineOsservata = Math.min(w.a, ora);
  st.giorni = st.giorni || {};
  if (c.metrica === 'ff_min'){
    let min = 0;
    try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){ const t = h.start || h.at; if (h.ok && !h.meditazione && t >= w.da && t < fineOsservata) min += Math.round((h.spentMs || (h.min || 0) * 60000) / 60000); }); }catch(_){ }
    out.fatto = min;
    out.vinta = min >= out.target;
    out.persa = !out.vinta && ora >= w.a;
  } else if (c.metrica === 'streak'){
    const n = sfSerieSevera();
    out.fatto = Math.min(out.target, n);
    out.vinta = n >= out.target;
    let start = ''; try{ start = (JSON.parse(localStorage.getItem('fl_sev_streak') || 'null') || {}).start || ''; }catch(_){ }
    out.persa = !out.vinta && (!n || (start && new Date(start + 'T12:00:00').getTime() > (st.da || 0) + 86400000));
  } else if (c.metrica === 'no_social_prima' || c.metrica === 'app_zero'){
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps){ out.nota = sfT('app.serveDati'); return out; }
    const hm = String(c.ora || '10:00').split(':'); const limMin = (+hm[0]) * 60 + (+hm[1] || 0);
    let ok = 0;
    for (let t = w.da; t < fineOsservata; t += 86400000){
      const day = sfDay(t);
      const fineGiorno = c.metrica === 'no_social_prima' ? t + limMin * 60000 : t + 86400000;
      if (st.giorni[day] === undefined || (st.giorni[day] === 'ok' && ora < fineGiorno)){
        if (ora < fineGiorno){
          const m = await sfMinutiDistrazione(t, ora, c.metrica === 'app_zero' ? (st.app && st.app.pkg) : null);
          if (m === null){ out.nota = sfT('app.serveDati'); return out; }
          if (m >= 1) st.giorni[day] = 'no'; else continue;   /* giornata ancora aperta */
        } else {
          const m = await sfMinutiDistrazione(t, fineGiorno, c.metrica === 'app_zero' ? (st.app && st.app.pkg) : null);
          if (m === null){ out.nota = sfT('app.serveDati'); return out; }
          st.giorni[day] = m >= 1 ? 'no' : 'ok';
        }
      }
      if (st.giorni[day] === 'ok') ok++;
      if (st.giorni[day] === 'no'){ out.persa = true; break; }
    }
    out.fatto = Math.min(out.target, ok);
    out.vinta = !out.persa && ok >= out.target;
    if (!out.vinta && !out.persa && ora >= w.a) out.persa = true;
  } else if (c.metrica === 'categoria_attiva'){
    let ok = 0;
    for (let t = w.da; t < fineOsservata; t += 86400000){
      const day = sfDay(t);
      const chiuso = ora >= t + 86400000;
      if (st.giorni[day] === undefined || !chiuso){
        const acceso = sfCategoriaAccesa(c);
        /* 0.9.344: il giorno in cui entri contano solo le interruzioni fatte dopo; e se il blocco non si e' ancora acceso la sfida
           non e' persa: aspetta che lo accendi */
        const primo = day === sfDay(st.da || Date.now());
        const interrotto = primo ? sfInterrottiN(day) > (+st.intBase || 0) : sfInterrottoIl(day);
        if (primo && !acceso && !interrotto){ out.nota = 'Accendi il blocco dei siti per adulti: la sfida parte da lì.'; continue; }
        if (!acceso || interrotto) st.giorni[day] = 'no';
        else if (chiuso) st.giorni[day] = 'ok';
        else continue;
      }
      if (st.giorni[day] === 'ok') ok++;
      if (st.giorni[day] === 'no'){ out.persa = true; break; }
    }
    out.fatto = Math.min(out.target, ok);
    out.vinta = !out.persa && ok >= out.target;
    if (!out.vinta && !out.persa && ora >= w.a) out.persa = true;
  }
  out.pct = Math.max(0, Math.min(100, Math.round(out.fatto / out.target * 100)));
  return out;
}
/** Rimisura tutte le sfide in corso: chiude quelle vinte o perse. */
async function sfAggiorna(){
  if (SF.inCorso) return; SF.inCorso = true;
  try{
    const s = sfStati();
    for (const id of Object.keys(s)){
      const st = s[id], c = sfCfg(id);
      if (!c || !st || (st.stato !== 'attiva' && st.stato !== 'iscritto')) continue;
      const m = await sfMisura(c, st);
      SF.misure[id] = m;
      if (st.stato === 'iscritto' && !m.attesa) st.stato = 'attiva';
      if (m.vinta){ st.stato = 'vinta'; st.fineAt = Date.now(); sfSalva(s); sfVinta(id, c, st); continue; }
      if (m.persa){ st.stato = 'persa'; st.fineAt = Date.now(); sfSalva(s); sfPersa(id, c, st); continue; }
    }
    sfSalva(s);
  }finally{ SF.inCorso = false; }
}

/* ---------------------------------------------------------------- partecipare */
function sfPartecipaApri(id){
  const c = sfCfg(id); if (!c) return;
  const monete = (typeof ffCoins === 'function') ? ffCoins() : 0;
  const poste = sfPoste();
  const html = '<div class="am-sheet center"><div class="sf-sh-ico">' + (c.icona || '🏁') + '</div><b class="am-sh-title">' + esc(sfTitolo(c)) + '</b><p class="am-sh-p">' + esc(c.regola || '') + '</p>'
    + '<small class="am-lbl">' + esc(sfT('posta.titolo')) + '</small>'
    + '<p class="sf-posta-sotto">' + esc(sfT('posta.sotto')) + ' ' + esc(sfT('posta.hai', { n: monete })) + '</p>'
    + '<div class="sf-poste" id="sfPoste">' + poste.map(function(p, i){ return '<button type="button" class="sf-posta' + (i === 0 ? ' on' : '') + (p > monete ? ' off' : '') + '" data-p="' + p + '" onclick="sfPostaScegli(this)">' + (p ? p + ' 🪙' : esc(sfT('posta.nessuna'))) + '</button>'; }).join('') + '</div>'
    + '<button type="button" class="am-cta" onclick="sfPartecipa(\'' + esc(id) + '\')">' + esc(sfT('posta.conferma')) + '</button>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">' + esc((typeof amT === 'function') ? amT('insieme.annulla') : 'Annulla') + '</button></div>';
  if (typeof inSheet === 'function') inSheet(html);
}
function sfPostaScegli(btn){
  if (btn.classList.contains('off')){ toast(sfT('posta.poche')); return; }
  document.querySelectorAll('#sfPoste .sf-posta').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
}
/* 0.9.347, Andrea: "se accetto una sfida mi fa uscire dalla pagina Amici e mi porta nella scheda Sogno: deve restare nella scheda Sfide".
   Nei quattro secondi dopo "Accetta", se l'app finisce sulla scheda Sogno (un permesso di Android, un ritorno dall'esterno, un premio
   che si chiude), si torna da soli in Amici, scheda Sfide */
function sfRestaQui(){
  const da = Date.now();
  const guarda = function(){
    if (Date.now() - da > 4000) return;
    try{
      const att = document.querySelector('.screen.active'); const id = att && att.id;
      const foglio = document.body.classList.contains('sheet-aperto') || document.getElementById('sfMollato') || document.querySelector('.scr-premio,.scr-wrap.in');
      if (!foglio && id && id !== 's-friends' && /^(s-home|s-dream)$/.test(id) && typeof frOpen === 'function'){ frOpen('sfide'); return; }
    }catch(_){ }
    setTimeout(guarda, 250);
  };
  setTimeout(guarda, 200);
}
async function sfPartecipa(id){
  const c = sfCfg(id); if (!c) return;
  sfRestaQui();
  const on = document.querySelector('#sfPoste .sf-posta.on');
  const posta = on ? (+on.dataset.p || 0) : 0;
  const monete = (typeof ffCoins === 'function') ? ffCoins() : 0;
  if (posta > monete){ toast(sfT('posta.poche')); return; }
  const st = { stato: 'attiva', da: Date.now(), posta: posta, giorni: {} };
  try{ st.intBase = sfInterrottiN(sfDay(Date.now())); }catch(_){ }
  if (c.metrica === 'app_zero'){
    const app = await sfAppTop();
    if (!app){ toast(sfT('app.serveDati')); return; }
    st.app = app;
  }
  if (c.metrica === 'categoria_attiva'){
    try{
      if (typeof flCatToggle === 'function' && typeof flCatById === 'function'){
        const cat = flCatById(c.categoria);
        const target = (typeof flCatTarget === 'function') ? flCatTarget('quick') : null;
        if (cat && target && typeof flCatState === 'function' && flCatState(cat, target) !== 'on') flCatToggle('quick', c.categoria);
        (c.parole || []).forEach(function(p){ if (QUICK.keywords.indexOf(p) < 0) QUICK.keywords.push(p); });
        if (typeof saveQuick === 'function') await saveQuick();
        if (!QUICK.enabled && typeof quickBlockToggle === 'function') await quickBlockToggle(true);
      }
    }catch(_){ }
  }
  const w = sfFinestra(c, st);
  if (Date.now() < w.da) st.stato = 'iscritto';
  if (posta && typeof ffAddCoins === 'function') ffAddCoins(-posta);
  const s = sfStati(); s[id] = st; sfSalva(s);
  if (typeof inSheetChiudi === 'function') inSheetChiudi();
  toast(st.stato === 'iscritto' ? sfT('iscritto') : sfT('stato.attiva'));
  try{ if (typeof frSync === 'function') frSync(true); }catch(_){ }
  await sfAggiorna();
  if (typeof frPaint === 'function') frPaint();
}
function sfRiprova(id){
  const s = sfStati(); delete s[id]; sfSalva(s);
  sfPartecipaApri(id);
}
function sfVinta(id, c, st){
  const pr = c.premio || {};
  let monete = +pr.monete || 0;
  const extra = [];
  if (st.posta){ monete += st.posta * 2; extra.push(esc(sfT('vinta.posta', { n: st.posta * 2 }))); }
  if (monete && typeof ffAddCoins === 'function') ffAddCoins(monete);
  if (pr.dp && typeof scrAddDP === 'function') scrAddDP(+pr.dp);
  extra.unshift(esc(sfT('vinta.sotto', { monete: +pr.monete || 0, dp: +pr.dp || 0 })));
  if (typeof scrApriPremio === 'function') scrApriPremio(pr.scrigno || 'bronzo', { titolo: sfT('vinta.titolo') + ' · ' + sfTitolo(c), extra: extra, motivo: 'sfida:' + id });
  else toast(sfT('vinta.titolo'));
  try{ if (typeof frSync === 'function') frSync(true); }catch(_){ }
}
function sfPersa(id, c, st){
  if (st.posta > 0) sfMollatoApri(id, st.posta);
  else toast(sfT('stato.persa') + ': ' + sfTitolo(c));
  try{ if (typeof frSync === 'function') frSync(true); }catch(_){ }
}
/* Lo schermo nero: una parola, quanto hai perso, un pulsante solo. */
function sfMollatoApri(id, n){
  const old = document.getElementById('sfMollato'); if (old) old.remove();
  const box = document.createElement('div'); box.id = 'sfMollato'; box.className = 'sf-mollato';
  box.innerHTML = '<div><b>' + esc(sfT('mollato.titolo')) + '</b><p>' + esc(n ? sfT('mollato.sotto', { n: n }) : sfT('mollato.sottoZero')) + '</p>'
    + '<button type="button" class="am-cta" onclick="document.getElementById(\'sfMollato\').remove();sfRiprova(\'' + esc(id) + '\')">' + esc(sfT('mollato.btn')) + '</button></div>';
  (document.getElementById('phone') || document.body).appendChild(box);
  requestAnimationFrame(function(){ box.classList.add('in'); });
}

/* ---------------------------------------------------------------- la pagina Sfide */
function sfTitolo(c){
  const st = sfStato(c.id);
  const app = (st && st.app && st.app.label) || sfT('app.nessuna');
  return String(c.titolo || '').replace('{app}', app);
}
function sfManca(m){
  const ms = m.fine - Date.now();
  const g = Math.ceil(ms / 86400000);
  if (g > 1) return sfT('manca.giorni', { n: g });
  if (g === 1) return sfT('manca.giorno');
  const h = Math.floor(ms / 3600000);
  return h >= 1 ? sfT('manca.ore', { h: h }) : sfT('manca.min', { n: Math.max(1, Math.floor(ms / 60000)) });
}
function sfPremioTxt(c){
  const pr = c.premio || {};
  return sfT('premio', { monete: +pr.monete || 0, dp: +pr.dp || 0 });
}
function sfAvanzamento(c, m){
  if (c.metrica === 'ff_min') return sfT('avanzamentoOre', { fatto: (m.fatto / 60).toFixed(1).replace('.0', '').replace('.', ','), target: Math.round(m.target / 60) });
  if (c.metrica === 'no_social_prima' || c.metrica === 'app_zero' || c.metrica === 'categoria_attiva' || c.metrica === 'streak') return sfT('avanzamentoGiorni', { fatto: m.fatto, target: m.target });
  return sfT('avanzamento', { fatto: m.fatto, target: m.target });
}
function sfVerificata(){ return '<span class="sf-ver"><i>✓</i>' + esc(sfT('verificata')) + '</span>'; }
/* una sfida in corso: la card grande con la barra */
function sfCardAttivaHtml(c, st){
  const m = SF.misure[c.id];
  const w = sfFinestra(c, st);
  const prima = Date.now() < w.da;
  let corpo;
  if (prima) corpo = '<div class="sf-riga"><span>' + esc(sfT('iscritto')) + '</span><span>' + esc(sfT('parteIl', { data: sfDataIt(c.inizio) })) + '</span></div>';
  else if (m && m.nota) corpo = '<div class="sf-riga"><span>' + esc(m.nota) + '</span></div>';
  else if (m) corpo = '<div class="sf-bar"><i style="width:' + m.pct + '%"></i></div><div class="sf-riga"><span>' + esc(sfAvanzamento(c, m)) + '</span><span>' + esc(sfManca(m)) + '</span></div>';
  else corpo = '<div class="sf-bar"><i style="width:0%"></i></div>';
  const posta = st.posta ? '<span class="sf-pill oro">' + esc(sfT('posta.inGioco', { n: st.posta })) + '</span>' : '<span class="sf-pill oro">' + esc(sfT('premioBreve', { dp: +(c.premio && c.premio.dp) || 0 })) + '</span>';
  return '<div class="sf-att"><div class="sf-att-top"><span class="sf-ico">' + (c.icona || '🏁') + '</span><div><b>' + esc(sfTitolo(c)) + '</b><small>' + esc(c.regola || '') + '</small></div></div>'
    + corpo + '<div class="sf-att-foot">' + sfVerificata() + posta + '</div></div>';
}
/* una sfida disponibile.
   0.9.340, Andrea: "le card delle sfide fanno cagare: non spiegano nulla, non c'e' un foglio che spiega come funzionano, e c'e' un
   giallo che non e' del mio brand". Ora e' una card vera: l'icona, il titolo e quanto dura; la regola; il premio in pillole
   azzurre; "Come funziona" apre il foglio con i passi; "Accetta la sfida" e' il pulsante pieno. */
function sfDurataTxt(c){
  const w = sfFinestra(c, null), g = Math.max(1, Math.round((w.a - w.da) / 86400000));
  return g === 1 ? '1 giorno' : (g % 7 === 0 && g <= 28 ? (g === 7 ? '1 settimana' : (g / 7) + ' settimane') : g + ' giorni');
}
function sfPremioPillole(c){
  const pr = c.premio || {}, out = [];
  if (+pr.monete) out.push('<span class="sf-pz">\ud83e\ude99 +' + (+pr.monete) + ' monete</span>');
  if (+pr.dp) out.push('<span class="sf-pz">\u2b50 +' + (+pr.dp) + ' Dream Points</span>');
  return out.join('');
}
function sfRigaDisponibileHtml(c){
  const n = SF.conta[c.id] || 0;
  const w = sfFinestra(c, null);
  const prima = w.fissa && Date.now() < w.da;
  return '<div class="sf-card2">'
    + '<div class="sf-c2-top"><span class="sf-c2-ico">' + (c.icona || '🏁') + '</span><div><b>' + esc(sfTitolo(c)) + '</b><small>' + esc(prima ? sfT('parteIl', { data: sfDataIt(c.inizio) }) : 'Dura ' + sfDurataTxt(c)) + (n >= 1 ? ' · ' + esc(sfT('conAltri', { n: n })) : '') + '</small></div></div>'
    + '<p class="sf-c2-regola">' + esc(c.regola || '') + '</p>'
    + '<div class="sf-c2-premio"><small>Se la completi vinci</small><div>' + sfPremioPillole(c) + '</div></div>'
    + '<div class="sf-c2-azioni"><button type="button" class="sf-c2-info" onclick="sfInfo(\'' + esc(c.id) + '\')"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg>Come funziona</button>'
    + '<button type="button" class="sf-c2-go" onclick="sfPartecipaApri(\'' + esc(c.id) + '\')">Accetta la sfida</button></div></div>';
}
/* il foglio "Come funziona": quattro passi, uno per riga, e il pulsante per accettare */
function sfInfo(id){
  const c = sfCfg(id); if (!c || typeof inSheet !== 'function') return;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  const w = sfFinestra(c, null), prima = w.fissa && Date.now() < w.da;
  const pr = c.premio || {};
  const premio = [(+pr.monete ? (+pr.monete) + ' monete' : ''), (+pr.dp ? (+pr.dp) + ' Dream Points' : '')].filter(Boolean).join(' e ');
  const passo = function(ico, t, s){ return '<div class="sf-in-r"><span>' + ico + '</span><div><b>' + esc(t) + '</b><p>' + esc(s) + '</p></div></div>'; };
  inSheet('<div class="sf-in"><div class="sf-in-ico">' + (c.icona || '🏁') + '</div><h3>' + esc(sfTitolo(c)) + '</h3>'
    + passo('\ud83c\udfaf', 'Cosa devi fare', c.regola || '')
    + passo('\ud83d\udcc5', 'Quando', prima ? 'La sfida parte il ' + sfDataIt(c.inizio) + ' e dura ' + sfDurataTxt(c) + '.' : 'La sfida parte quando la accetti e dura ' + sfDurataTxt(c) + '.')
    + passo('\u2705', 'Chi controlla', 'L’app controlla da sola i tuoi dati ogni giorno. Non devi segnare niente.')
    + passo('\ud83c\udfc6', 'Cosa vinci', premio ? 'Se la completi vinci ' + premio + '. Se vuoi, puoi mettere in gioco anche delle monete.' : 'Se vuoi, puoi mettere in gioco delle monete.')
    + '<button type="button" class="am-cta" onclick="inSheetChiudi();setTimeout(function(){sfPartecipaApri(\'' + esc(c.id) + '\')},250)">Accetta la sfida</button></div>');
}
/* una sfida chiusa: medaglia se vinta, «Riprova» se persa */
function sfRigaChiusaHtml(c, st){
  const vinta = st.stato === 'vinta';
  const pr = c.premio || {};
  return '<div class="sf-disp chiusa"><span class="sf-medaglia' + (vinta ? '' : ' no') + '">' + (vinta ? '🏅' : (c.icona || '🏁')) + '</span><div><b>' + esc(sfTitolo(c)) + '</b><small>' + esc(vinta ? sfT('stato.completataIl', { data: sfDataMs(st.fineAt || Date.now()) }) : sfT('stato.chiusaIl', { data: sfDataMs(st.fineAt || Date.now()) })) + '</small>' + (vinta ? sfVerificata() : '') + '</div>'
    + (vinta ? '<span class="sf-pill verde">+' + (+pr.dp || 0) + ' DP</span>' : '<button type="button" class="sf-go ghost" onclick="sfRiprova(\'' + esc(c.id) + '\')">' + esc(sfT('stato.riprova')) + '</button>') + '</div>';
}
function sfInfoMonk(){
  if (typeof inSheet !== 'function') return;
  const passo = function(ico, t, x){ return '<div class="sf-in-r"><span>' + ico + '</span><div><b>' + esc(t) + '</b><p>' + esc(x) + '</p></div></div>'; };
  inSheet('<div class="sf-in"><div class="sf-in-ico">🏔️</div><h3>' + esc(sfT('monk.titolo')) + '</h3>'
    + passo('🎯', 'Cosa devi fare', sfT('monk.regola')) + passo('📅', 'Quanto dura', sfT('monk.durata'))
    + passo('✅', 'Chi controlla', 'L’app conta da sola le ore di Full Focus. Non devi segnare niente.') + passo('🏆', 'Cosa vinci', sfT('monk.premio'))
    + '<button type="button" class="am-cta" onclick="inSheetChiudi();scrStagioneInizia();frPaint()">Accetta la sfida</button></div>');
}
/* il Monk Mode come card: in corso se la stagione e' aperta, altrimenti fra le disponibili */
function sfMonkAttiva(){ try{ const st = scrStato().stagione; return !!(st && Date.now() < st.fine); }catch(_){ return false; } }
function sfMonkHtml(){
  if (typeof scrStato !== 'function') return '';
  const s = scrStato(), st = s.stagione;
  if (!st || Date.now() >= st.fine){
    /* 0.9.340: la stessa card delle altre sfide */
    return '<div class="sf-card2"><div class="sf-c2-top"><span class="sf-c2-ico">🏔️</span><div><b>' + esc(sfT('monk.titolo')) + '</b><small>' + esc(sfT('monk.durata')) + '</small></div></div>'
      + '<p class="sf-c2-regola">' + esc(sfT('monk.regola')) + '</p>'
      + '<div class="sf-c2-premio"><small>Se la completi vinci</small><div><span class="sf-pz">' + esc(sfT('monk.premio')) + '</span></div></div>'
      + '<div class="sf-c2-azioni"><button type="button" class="sf-c2-info" onclick="sfInfoMonk()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg>Come funziona</button>'
      + '<button type="button" class="sf-c2-go" onclick="scrStagioneInizia();frPaint()">Accetta la sfida</button></div></div>';
  }
  const sett = scrStagioneSettimane(st);
  const cur = sett.filter(function(w){ return w.corrente; })[0] || sett[sett.length - 1];
  const pct = Math.min(100, Math.round(cur.min / st.obiettivo * 100));
  const giorni = Math.max(0, Math.ceil((st.fine - Date.now()) / 86400000));
  const chiuse = sett.filter(function(w){ return w.min >= st.obiettivo; }).length;
  return '<div class="sf-att"><div class="sf-att-top"><span class="sf-ico">🏔️</span><div><b>' + esc(sfT('monk.titolo')) + '</b><small>' + esc(sfT('monk.regola')) + '</small></div></div>'
    + '<div class="sf-bar"><i style="width:' + pct + '%"></i></div>'
    + '<div class="sf-riga"><span>' + esc(sfT('monk.settimana', { n: sett.indexOf(cur) + 1, h: (cur.min / 60).toFixed(1).replace('.0', '').replace('.', ',') })) + '</span><span>' + esc(sfT('monk.fine', { n: giorni })) + '</span></div>'
    + '<div class="sf-att-foot">' + sfVerificata() + '<span class="sf-pill oro">' + esc(chiuse ? sfT('monk.chiuse', { n: chiuse }) : sfT('monk.premio')) + '</span></div></div>';
}
/** La scheda Sfide intera: in corso, disponibili, completate, registro. */
/* ---------- LE MISSIONI (0.9.203), come su Duolingo ----------
   In cima alla scheda Sfide: «Segui altri amici e fate squadra» con gli amici suggeriti, e tre
   missioni del giorno che aprono una mystery box. Si rinnovano a mezzanotte. */
function sfMissioniOggi(){
  const k = (typeof sdK === 'function') ? sdK(Date.now()) : String(new Date().toDateString());
  let xp = 0, ffMin = 0, tappe = 0;
  try{ xp = sdXpOggi(); }catch(_){ }
  try{ const d0 = new Date(); d0.setHours(0, 0, 0, 0); (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){ if (x && x.ok && x.at >= d0.getTime()) ffMin += (x.min || 0); }); }catch(_){ }
  try{ tappe = sdTappeOggi(); }catch(_){ }
  let prese = {}; try{ prese = JSON.parse(localStorage.getItem('fl_mis_prese') || '{}') || {}; }catch(_){ }
  const giorno = prese[k] || [];
  return { k: k, m: [
    { i: 0, t: 'Guadagna 30 XP', n: Math.min(30, xp), tot: 30, ico: '🎁' },
    { i: 1, t: 'Fai 10 minuti di Full Focus', n: Math.min(10, Math.round(ffMin)), tot: 10, ico: '🎁' },
    { i: 2, t: 'Completa 2 tappe della mappa', n: Math.min(2, tappe), tot: 2, ico: '🎁' }
  ].map(function(x){ x.fatta = x.n >= x.tot; x.presa = giorno.indexOf(x.i) >= 0; return x; }) };
}
function sfMissionePrendi(i){
  const o = sfMissioniOggi(); const m = o.m[i]; if (!m || !m.fatta || m.presa) return;
  let prese = {}; try{ prese = JSON.parse(localStorage.getItem('fl_mis_prese') || '{}') || {}; }catch(_){ }
  prese = { [o.k]: (prese[o.k] || []).concat([i]) };
  try{ localStorage.setItem('fl_mis_prese', JSON.stringify(prese)); }catch(_){ }
  try{ flVibra([20, 30, 60]); }catch(_){ }
  if (typeof sdScrignoApri === 'function') sdScrignoApri('sc:m:' + o.k + ':' + i); else toast('Missione fatta');
}
function sfSuggeritiHtml(max){
  let membri = []; try{ membri = ((typeof FR !== 'undefined' && FR.lega && FR.lega.membri) || []).filter(function(m){ return !m.me; }); }catch(_){ }
  let amici = []; try{ amici = (FR.amici && FR.amici.amici || []).map(function(a){ return a.device; }); }catch(_){ }
  const sugg = membri.filter(function(m){ return amici.indexOf(m.device) < 0; }).slice(0, max || 8);
  if (!sugg.length) return '<p class="sf-mis-vuoto">Quando qualcuno entra nella tua lega, lo trovi qui.</p>';
  return '<div class="sf-sugg">' + sugg.map(function(m){ return '<div class="sf-sugg-c">' + (typeof frAv === 'function' ? frAv(m.nome, m.device, 'grande') : '') + '<b>' + esc(m.nome || 'Giocatore') + '</b><small>nella tua lega</small><button type="button" class="sf-segui" onclick="if(typeof frSegui===\'function\')frSegui(\'' + esc(m.device) + '\',this)">Segui</button></div>'; }).join('') + '</div>';
}
function sfMissioniHtml(){
  const o = sfMissioniOggi();
  const ore = Math.max(1, Math.ceil((new Date().setHours(24, 0, 0, 0) - Date.now()) / 3600000));
  return '<div class="am-sect first"><b>Missione di gruppo</b></div><p class="sf-mis-sotto">Segui altri amici e fate squadra.</p>' + sfSuggeritiHtml()
    + '<div class="am-sect"><b>Missioni giornaliere</b><span>⏱ ' + ore + 'h</span></div>'
    + '<div class="sf-mis">' + o.m.map(function(m){
        const pct = Math.round(m.n / m.tot * 100);
        return '<div class="sf-mis-r' + (m.fatta ? ' fatta' : '') + (m.presa ? ' presa' : '') + '" onclick="sfMissionePrendi(' + m.i + ')"><div><b>' + esc(m.t) + '</b><div class="sf-mis-bar"><i style="width:' + pct + '%"></i><span>' + m.n + '/' + m.tot + '</span></div></div><span class="sf-mis-ico">' + (m.presa ? '✅' : m.ico) + '</span></div>';
      }).join('') + '</div>'
    /* 0.9.321: quella del mese sta in cima (dsoMeseHtml); qui resta solo una vecchia ancora da aprire */
    + ((typeof mdmSezioneHtml === 'function') ? mdmSezioneHtml() : '');
}
function sfPaginaHtml(){
  const lista = sfLista();
  const attive = [], disp = [], chiuse = [];
  lista.forEach(function(c){ const st = sfStato(c.id); if (st && (st.stato === 'attiva' || st.stato === 'iscritto')) attive.push([c, st]); else if (st && (st.stato === 'vinta' || st.stato === 'persa')) chiuse.push([c, st]); else disp.push(c); });
  const monkOn = sfMonkAttiva();
  const nAtt = attive.length + (monkOn ? 1 : 0);
  /* 0.9.321, Andrea: la missione del mese resta in vista in cima, come su Duolingo */
  /* 0.9.346, Andrea: "il pannello di social proof non come primo pannello: subito prima di Disponibili" */
  const spPrima = (typeof spSfideHtml === 'function') ? spSfideHtml() : '';
  let h = ((typeof dsoMeseHtml === 'function') ? dsoMeseHtml() : '') + sfMissioniHtml();
  if (nAtt){
    h += '<div class="am-sect"><b>' + esc(sfT('inCorso')) + '</b><span>' + esc(nAtt === 1 ? sfT('attiva1') : sfT('attive', { n: nAtt })) + '</span></div><div class="sf-col">';
    if (monkOn) h += sfMonkHtml();
    h += attive.map(function(x){ return sfCardAttivaHtml(x[0], x[1]); }).join('') + '</div>';
  }
  if (disp.length || !monkOn){
    h += spPrima + '<div class="am-sect"><b>' + esc(sfT('disponibili')) + '</b><span>' + esc(sfT('scegline')) + '</span></div><div class="sf-col">';
    if (!monkOn) h += sfMonkHtml();
    h += disp.map(sfRigaDisponibileHtml).join('') + '</div>';
  }
  if (chiuse.length){
    chiuse.sort(function(a, b){ return (b[1].fineAt || 0) - (a[1].fineAt || 0); });
    h += '<div class="am-sect"><b>' + esc(sfT('completate')) + '</b></div><div class="sf-col">' + chiuse.map(function(x){ return sfRigaChiusaHtml(x[0], x[1]); }).join('') + '</div>';
  }
  /* 0.9.321, Andrea: niente piu' "nuovo te contro vecchio te": il registro e' quello dei duelli con altre persone */
  h += (typeof dsoDuelliHtml === 'function') ? dsoDuelliHtml() : '';
  return h;
}

/* ---------------------------------------------------------------- il registro delle partite */
function sfRegistroHtml(){
  const righe = [];
  const hist = (typeof mgHist === 'function') ? mgHist() : [];
  for (let i = 0; i < 14; i++){
    const t = sfGiorno0(Date.now() - i * 86400000), day = sfDay(t);
    const g = hist.filter(function(x){ return x.day === day; })[0];
    let neo = 0, old = 0;
    if (g){
      if (typeof g.neo === 'number' && typeof g.old === 'number' && !(g.eventi || []).length){ neo = g.neo; old = g.old; }
      else (g.eventi || []).forEach(function(e){ if (!e || e.stornato) return; if (e.chi === 'neo') neo++; else if (e.chi === 'old') old++; });
    }
    const punti = (typeof frPuntiGiorno === 'function') ? frPuntiGiorno(t) : 0;
    if (!neo && !old && !punti) continue;
    const esito = neo > old ? 'vittoria' : (neo < old ? 'sconfitta' : 'pari');
    righe.push('<div class="sf-reg"><span class="sf-reg-es ' + esito + '">' + esc(sfT('registro.' + esito)) + '</span><b>' + neo + '<i>–</i>' + old + '</b><small>' + esc(sfT('registro.punti', { n: punti })) + '</small><em>' + esc(new Date(t).toLocaleDateString('it-IT', { weekday: 'short', day: '2-digit', month: '2-digit' })) + '</em></div>');
  }
  return '<div class="am-sect"><b>' + esc(sfT('registro.titolo')) + '</b><span>' + esc(sfT('registro.sotto')) + '</span></div>'
    + (righe.length ? '<div class="am-board sf-registro">' + righe.join('') + '</div>' : '<p class="am-hint">' + esc(sfT('registro.vuoto')) + '</p>');
}

/* ---------------------------------------------------------------- Bentornato */
function sfUltimaSessione(){
  let t = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){ if (h.ok && h.at > t) t = h.at; }); }catch(_){ }
  return t;
}
function sfPariDati(){
  const ultima = sfUltimaSessione();
  if (!ultima) return null;
  const giorni = Math.round((sfGiorno0(Date.now()) - sfGiorno0(ultima)) / 86400000);
  if (giorni < 3) return null;
  const chiave = sfDay(ultima);
  if (sfLeggiJ(SF_PARI_KEY, '') === chiave) return null;
  return { giorni: giorni, chiave: chiave };
}
/* Le righe di «cosa ti sei perso»: lega, amici, serie. Solo quelle che hanno un dato. */
function sfPariRighe(){
  const r = [];
  try{
    const L = (typeof FR !== 'undefined' && FR.lega) ? FR.lega : null;
    if (L && L.mio) r.push(['🏆', sfT('pari.riga.lega', { pos: L.mio.posizione, punti: L.mio.punti })]);
    if (typeof FR !== 'undefined' && FR.amici && FR.me){
      const mio = FR.me.score7 || 0;
      const sopra = (FR.amici.amici || []).filter(function(a){ return a.score7 > mio; }).sort(function(a, b){ return a.score7 - b.score7; })[0];
      if (sopra) r.push(['👥', sfT('pari.riga.amici', { nome: sopra.nome })]);
    }
  }catch(_){ }
  r.push(['🔥', sfT('pari.riga.serie')]);
  if (r.length < 2) r.unshift(['📅', sfT('pari.riga.nessuna')]);
  return r;
}
/** La schermata intera: si apre da sola all'apertura dell'app dopo tre o piu' giorni. */
function sfPariApri(){
  const p = sfPariDati(); if (!p) return;
  if (document.getElementById('sfPari')) return;
  sfScriviJ(SF_PARI_KEY, p.chiave);
  const box = document.createElement('div'); box.id = 'sfPari'; box.className = 'sf-pari';
  box.innerHTML = '<div class="sf-pari-sky"><button type="button" class="sf-pari-x" aria-label="Chiudi" onclick="sfPariChiudi()">✕</button>'
    + '<small>' + esc(sfT('pari.etichetta')) + '</small><h2>' + esc(sfT('pari.titolo', { n: p.giorni })) + '</h2><p>' + esc(sfT('pari.sotto')) + '</p>'
    + '<div class="sf-pari-nuvole"><svg viewBox="0 0 390 40" preserveAspectRatio="none"><path fill="currentColor" d="M0 40V22c30-14 60-14 90-4 30-16 70-18 105-4 35-14 75-12 105 2 30-12 60-10 90 4v20z"/></svg></div></div>'
    + '<div class="sf-pari-body"><div class="am-board sf-pari-righe">' + sfPariRighe().map(function(x){ return '<div><i>' + x[0] + '</i><span>' + esc(x[1]) + '</span></div>'; }).join('') + '</div>'
    + '<div class="sf-pari-chest">' + ((typeof scrCassaHtml === 'function') ? scrCassaHtml('bronzo', false) : '') + '<b>' + esc(sfT('pari.scrigno')) + '</b></div>'
    + '<button type="button" class="am-cta" onclick="sfPariScrigno(' + p.giorni + ')">' + esc(sfT('pari.btn')) + '</button>'
    + '<button type="button" class="am-link" onclick="sfPariChiudi()">' + esc(sfT('pari.dopo')) + '</button></div>';
  (document.getElementById('phone') || document.body).appendChild(box);
  requestAnimationFrame(function(){ box.classList.add('in'); });
}
function sfPariChiudi(){ const b = document.getElementById('sfPari'); if (b){ b.classList.remove('in'); setTimeout(function(){ b.remove(); }, 250); } }
function sfPariScrigno(giorni){
  if (typeof scrApriPremio !== 'function'){ sfPariChiudi(); return; }
  scrApriPremio('bronzo', { titolo: sfT('pari.titolo', { n: giorni }), motivo: 'rientro', bottone: sfT('pari.riparti'), onChiudi: function(){
    sfPariChiudi();
    try{ goId('s-home'); if (typeof stGoFocus === 'function') stGoFocus(); else if (typeof ffOpen === 'function') ffOpen(); }catch(_){ }
  } });
}

/* aggiornamento: dopo ogni sessione finita, e all'apertura dell'app */
setTimeout(function(){
  sfCarica().then(function(){ sfAggiorna(); });
  /* Bentornato: solo se non c'e' una sessione in corso e la schermata e' visibile */
  setTimeout(function(){
    try{
      if (typeof FF !== 'undefined' && FF.run) return;
      if (document.hidden) return;
      if (document.querySelector('.scr-premio, .gn, #sfMollato')) return;
      if (sfPariDati()) sfPariApri();
    }catch(_){ }
  }, 2500);
}, 6000);
(function(){
  if (typeof ffFinish !== 'function') return;
  const orig = ffFinish;
  ffFinish = async function(){ const r = await orig.apply(this, arguments); setTimeout(function(){ try{ sfAggiorna(); }catch(_){ } }, 1200); return r; };
})();

(function(){
  const css = [
    '.am-sect.first{margin-top:4px}',
    '.sf-col{display:flex;flex-direction:column;gap:10px}#spSez-sfide{margin:30px 0 28px}',
    '.sf-mis-sotto{margin:-4px 2px 10px;font:500 13px var(--font-body);color:var(--muted)}.sf-mis-vuoto{margin:0 2px;font:500 13px var(--font-body);color:var(--muted)}',
    '.sf-sugg{display:flex;gap:10px;overflow-x:auto;padding:2px 2px 6px;scrollbar-width:none}.sf-sugg::-webkit-scrollbar{display:none}',
    '.sf-sugg-c{flex:0 0 124px;display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 10px 12px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .sf-sugg-c{background:#12203A;border-color:#22345A}',
    '.sf-sugg-c .am-av{width:48px;height:48px;font-size:20px;margin-bottom:4px}.sf-sugg-c b{font:800 13px var(--font-body);color:var(--navy);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}body.dark .sf-sugg-c b{color:#fff}.sf-sugg-c small{font:500 11px var(--font-body);color:var(--muted)}',
    '.sf-segui{margin-top:6px;border:0;border-radius:10px;background:#0075E3;color:#fff;font:800 12.5px var(--font-body);padding:8px 14px;cursor:pointer}.sf-segui.on,.sf-segui:disabled{background:rgba(0,117,227,.14);color:#0075E3}',
    '.sf-mis{display:flex;flex-direction:column;gap:10px}.sf-mis-r{display:flex;align-items:center;gap:12px;padding:14px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sf-mis-r{background:#12203A;border-color:#22345A}',
    '.sf-mis-r > div{flex:1;min-width:0}.sf-mis-r b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .sf-mis-r b{color:#fff}',
    '.sf-mis-bar{position:relative;height:18px;border-radius:99px;background:rgba(0,117,227,.12);margin-top:8px;overflow:hidden}.sf-mis-bar i{display:block;height:100%;background:#FFB347;border-radius:99px;transition:width .4s}.sf-mis-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:800 11px var(--font-body);color:var(--navy)}body.dark .sf-mis-bar span{color:#fff}',
    '.sf-mis-ico{font-size:30px;opacity:.5}.sf-mis-r.fatta{border-color:#FFB347;cursor:pointer}.sf-mis-r.fatta .sf-mis-ico{opacity:1;animation:sfMisGiu 1.1s ease-in-out infinite}.sf-mis-r.presa .sf-mis-ico{animation:none}.sf-mis-r.presa{opacity:.6}',
    '@keyframes sfMisGiu{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}',
    '.sf-ico{width:44px;height:44px;border-radius:14px;background:var(--blue-soft,#E3F1FF);display:flex;align-items:center;justify-content:center;font-size:22px;flex:none}',
    '.sf-ico.sm{width:40px;height:40px;border-radius:12px;background:var(--bg,#F4F9FF);border:1px solid var(--line);font-size:19px}',
    'body.dark .sf-ico{background:#0F2A4A}body.dark .sf-ico.sm{background:#0B1220;border-color:#22345A}',
    /* la sfida in corso */
    '.sf-att{background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:16px;box-shadow:0 10px 30px rgba(0,30,68,.08)}body.dark .sf-att{background:#12203A;border-color:#22345A}',
    '.sf-att-top{display:flex;gap:12px;align-items:flex-start}.sf-att-top > div{flex:1;min-width:0}',
    '.sf-att-top b{display:block;font:700 14.5px/1.3 var(--font-body);color:var(--navy);text-wrap:pretty}body.dark .sf-att-top b{color:#fff}',
    '.sf-att-top small{display:block;margin-top:3px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.sf-bar{height:8px;border-radius:99px;background:rgba(0,30,68,.09);overflow:hidden;margin-top:14px}.sf-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#0075E3,#3F9FF4);transition:width .6s cubic-bezier(.2,.8,.2,1)}',
    'body.dark .sf-bar{background:rgba(255,255,255,.12)}',
    '.sf-riga{display:flex;justify-content:space-between;gap:12px;margin-top:7px;font:600 11.5px var(--font-body)}.sf-riga span:first-child{color:var(--navy)}.sf-riga span:last-child{color:var(--muted)}body.dark .sf-riga span:first-child{color:#fff}',
    '.sf-att-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--line)}',
    '.sf-ver{font:600 10.5px var(--font-body);color:#0E7C6B;display:inline-flex;align-items:center;gap:5px}.sf-ver i{width:15px;height:15px;border-radius:50%;background:#E2F6F2;display:inline-flex;align-items:center;justify-content:center;font:800 9px var(--font-body);font-style:normal}',
    '.sf-pill{font:700 11px var(--font-body);border-radius:99px;padding:5px 10px;white-space:nowrap}.sf-pill.oro{color:#0075E3;background:rgba(0,117,227,.1)}body.dark .sf-pill.oro{color:#8CC6FF;background:rgba(63,159,244,.16)}.sf-pill.verde{color:#fff;background:#1B9E6A}',
    /* la sfida disponibile e quella chiusa */
    '.sf-disp{background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;padding:14px;display:flex;gap:12px;align-items:center}body.dark .sf-disp{background:#12203A;border-color:#22345A}',
    '.sf-disp > div{flex:1;min-width:0}.sf-disp b{display:block;font:700 13.5px/1.3 var(--font-body);color:var(--navy)}body.dark .sf-disp b{color:#fff}',
    '.sf-disp small{display:block;margin-top:2px;font:500 11.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sf-disp em{display:block;margin-top:5px;font:700 10.5px var(--font-body);font-style:normal;color:#0075E3}body.dark .sf-disp em{color:#8CC6FF}',
    /* 0.9.340: la card della sfida disponibile e il foglio "Come funziona" */
    '.sf-card2{background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:18px 16px 16px;box-shadow:0 6px 18px rgba(0,30,68,.06)}body.dark .sf-card2{background:#12203A;border-color:#22345A}',
    '.sf-c2-top{display:flex;align-items:center;gap:14px}.sf-c2-ico{flex:none;width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:26px;background:linear-gradient(160deg,#0075E3,#001E44);box-shadow:0 6px 14px rgba(0,117,227,.3)}',
    '.sf-c2-top b{display:block;font:800 16.5px/1.25 var(--font-display);color:var(--navy)}body.dark .sf-c2-top b{color:#fff}.sf-c2-top small{display:block;margin-top:3px;font:600 12.5px var(--font-body);color:var(--muted)}',
    '.sf-c2-regola{margin:14px 0 0;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .sf-c2-regola{color:#DCEBFF}',
    '.sf-c2-premio{margin-top:14px;padding:12px 12px 10px;border-radius:16px;background:var(--bg,#F4F9FF)}body.dark .sf-c2-premio{background:#0F1B33}.sf-c2-premio small{display:block;font:800 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}',
    '.sf-c2-premio > div{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.sf-pz{display:inline-flex;align-items:center;gap:5px;padding:6px 11px;border-radius:99px;background:rgba(0,117,227,.1);color:#0075E3;font:800 12.5px var(--font-body)}body.dark .sf-pz{background:rgba(63,159,244,.16);color:#8CC6FF}',
    '.sf-c2-azioni{display:flex;align-items:center;gap:10px;margin-top:16px}.sf-c2-info{display:inline-flex;align-items:center;gap:6px;padding:12px 6px;border:0;background:none;color:#0075E3;font:700 13.5px var(--font-body);cursor:pointer}body.dark .sf-c2-info{color:#8CC6FF}',
    '.sf-c2-go{flex:1;min-height:48px;border:0;border-radius:24px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 8px 18px rgba(0,117,227,.3)}',
    '.sf-in{text-align:center;padding:4px 2px 8px}.sf-in-ico{width:68px;height:68px;margin:0 auto;border-radius:22px;display:flex;align-items:center;justify-content:center;font-size:34px;background:linear-gradient(160deg,#0075E3,#001E44)}.sf-in h3{margin:16px 0 22px;font:800 21px/1.25 var(--font-display);color:var(--navy)}',
    '.sf-in-r{display:flex;align-items:flex-start;gap:14px;margin:0 0 18px;text-align:left}.sf-in-r > span{flex:none;width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;background:var(--bg,#F4F9FF)}body.dark .sf-in-r > span{background:#12203A}',
    '.sf-in-r b{display:block;font:800 15px var(--font-body);color:var(--navy)}.sf-in-r p{margin:4px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}.sf-in .am-cta{margin-top:8px}',
    '.sf-disp .sf-ver{margin-top:5px}',
    '.sf-go{flex:none;border:none;cursor:pointer;border-radius:99px;min-height:40px;padding:0 16px;font:700 12.5px var(--font-body);color:#fff;background:linear-gradient(135deg,#0075E3,#005BB0);box-shadow:0 6px 14px rgba(0,117,227,.28)}',
    /* 0.9.344: "Riprova" usciva dal pannello: resta della sua misura, e il testo accanto ha lo spazio che gli serve */
    '.sf-disp.chiusa{flex-wrap:nowrap}.sf-disp.chiusa > div{flex:1 1 auto;min-width:0}.sf-disp.chiusa > .sf-go{flex:0 0 auto!important;width:auto!important;max-width:42%;min-width:0;padding:0 16px!important;margin:0!important;white-space:nowrap}',
    '.sf-go:active{transform:scale(.95)}.sf-go.ghost{background:var(--blue-soft,#E3F1FF);color:#0075E3;box-shadow:none}',
    '.sf-medaglia{width:52px;height:52px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font-size:26px;background:radial-gradient(circle at 35% 30%,#FFE9A8,#F5B301 60%,#B9741C);box-shadow:0 0 0 3px #FFF3D6,0 8px 18px rgba(245,179,1,.3)}',
    '.sf-medaglia.no{background:rgba(0,30,68,.07);box-shadow:none;font-size:22px;filter:grayscale(1);opacity:.7}',
    /* la posta */
    '.am-sheet.center{text-align:center}.sf-sh-ico{font-size:40px;line-height:1;margin-bottom:8px}',
    '.sf-posta-sotto{margin:0 0 12px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.sf-poste{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}',
    '.sf-posta{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:11px 16px;font:700 14px var(--font-body);color:var(--navy);cursor:pointer}',
    '.sf-posta.on{background:#001E44;border-color:#001E44;color:#fff}.sf-posta.off{opacity:.4}body.dark .sf-posta{background:#12203A;border-color:#22345A;color:#fff}body.dark .sf-posta.on{background:#0075E3;border-color:#0075E3}',
    /* hai mollato */
    '.sf-mollato{position:fixed;inset:0;z-index:9300;display:flex;align-items:center;justify-content:center;background:#000;color:#fff;text-align:center;padding:32px;opacity:0;transition:opacity .35s}',
    '.sf-mollato.in{opacity:1}',
    '.sf-mollato b{display:block;font:800 40px var(--font-display);font-style:italic;color:#fff}',
    '.sf-mollato p{margin:12px 0 32px;font:500 16px var(--font-body);color:rgba(255,255,255,.75)}',
    '.sf-mollato .am-cta{max-width:260px;margin:0 auto}',
    /* il registro */
    '.sf-registro{display:flex;flex-direction:column}',
    '.sf-reg{display:flex;align-items:center;gap:12px;padding:10px 10px;border-radius:14px}.sf-reg + .sf-reg{border-top:1px solid var(--line)}',
    '.sf-reg-es{flex:none;width:76px;font:800 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase}.sf-reg-es.vittoria{color:#0E7C6B}.sf-reg-es.sconfitta{color:#E63946}.sf-reg-es.pari{color:var(--muted)}',
    '.sf-reg b{font:800 15px var(--font-display);color:var(--navy)}.sf-reg b i{font-style:normal;color:var(--faint);margin:0 2px}body.dark .sf-reg b{color:#fff}',
    '.sf-reg small{flex:1;font:600 12px var(--font-body);color:var(--muted)}.sf-reg em{font:600 11.5px var(--font-body);font-style:normal;color:var(--faint)}',
    /* Bentornato */
    '.sf-pari{position:fixed;inset:0;z-index:9200;display:flex;flex-direction:column;background:var(--bg,#F4F9FF);opacity:0;transform:translateY(16px);transition:opacity .3s,transform .3s;overflow-y:auto}',
    '.sf-pari.in{opacity:1;transform:none}body.dark .sf-pari{background:#0B1220}',
    '.sf-pari-sky{position:relative;flex:none;padding:calc(58px + env(safe-area-inset-top,0px)) 24px 56px;text-align:center;color:#fff;background:linear-gradient(180deg,rgba(2,9,38,.45),rgba(2,9,38,.78)),url(img/dream-night.jpg) center/cover no-repeat,#020926}',
    '.sf-pari-x{position:absolute;left:20px;top:calc(44px + env(safe-area-inset-top,0px));width:34px;height:34px;border:none;background:rgba(255,255,255,.16);border-radius:50%;font-size:14px;color:#fff;cursor:pointer}',
    '.sf-pari-sky small{display:block;font:700 11px var(--font-body);letter-spacing:.18em;text-transform:uppercase;color:#9EC1FF}',
    '.sf-pari-sky h2{margin:10px auto 0;max-width:14em;font:800 28px/1.2 var(--font-display);font-style:italic;text-shadow:0 2px 12px rgba(0,0,0,.5);text-wrap:balance}',
    '.sf-pari-sky p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.85)}',
    '.sf-pari-nuvole{position:absolute;left:0;right:0;bottom:-1px;line-height:0;color:var(--bg,#F4F9FF)}.sf-pari-nuvole svg{display:block;width:100%;height:34px}body.dark .sf-pari-nuvole{color:#0B1220}',
    '.sf-pari-body{flex:1;padding:8px 22px calc(28px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column}',
    '.sf-pari-righe{padding:6px 12px}.sf-pari-righe > div{display:flex;gap:12px;align-items:center;padding:10px 0;font:600 13px/1.4 var(--font-body);color:var(--navy)}.sf-pari-righe > div + div{border-top:1px solid var(--line)}.sf-pari-righe i{font-style:normal;font-size:18px}body.dark .sf-pari-righe > div{color:#fff}',
    '.sf-pari-chest{margin:26px 0 0;text-align:center}.sf-pari-chest b{display:block;margin-top:12px;font:800 15px var(--font-display);font-style:italic;color:var(--navy)}body.dark .sf-pari-chest b{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
