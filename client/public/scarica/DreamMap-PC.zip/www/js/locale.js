/* ---------------------------------------------------------------------------------------
   IL PAESE DI CHI GUARDA

   Due cose in questa app erano scritte in italiano dentro al codice: la data (19/09/2026) e
   l'euro. Vanno bene finche' l'app la usa qualcuno che vive qui. A chi la apre a New York la
   data dice il mese al posto del giorno e il campo del budget chiede euro che non ha.

   Qui non si traduce niente: si chiede al sistema operativo come si scrive una data e quali
   soldi si usano dove sta chi guarda, e si usa la sua risposta.
   --------------------------------------------------------------------------------------- */

/** La lingua-e-paese del dispositivo, per esempio «it-IT» o «en-US». */
function flLocale(){
  try{
    const l = (navigator.languages && navigator.languages[0]) || navigator.language;
    return l || 'it-IT';
  }catch(_){ return 'it-IT'; }
}

/** La lingua di chi legge, due lettere minuscole: «it», «en», «es»… */
function flLingua(){ return String(flLocale()).slice(0, 2).toLowerCase(); }
/** Il testo nella lingua di chi legge; se non c'e', l'inglese. */
function flTesto(m){ return m[flLingua()] || m.en || m[Object.keys(m)[0]]; }

/** Il paese, due lettere. Se la lingua non lo dice (solo «en»), si prova il fuso orario. */
function flPaese(){
  const l = flLocale();
  const m = /[-_]([A-Za-z]{2})\b/.exec(l);
  if (m) return m[1].toUpperCase();
  try{
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    if (/^America\//.test(tz)) return 'US';
    if (/^Europe\/London/.test(tz)) return 'GB';
    if (/^Europe\/Zurich/.test(tz)) return 'CH';
    if (/^Australia\//.test(tz)) return 'AU';
    if (/^Asia\/Tokyo/.test(tz)) return 'JP';
  }catch(_){ }
  return 'IT';
}

/* I paesi che NON usano l'euro e che l'app puo' davvero incontrare. Tutto il resto cade
   sull'euro: e' meglio di un elenco di duecento voci che nessuno verifica. */
const FL_VALUTE = {
  US: 'USD', GB: 'GBP', CH: 'CHF', CA: 'CAD', AU: 'AUD', NZ: 'NZD', JP: 'JPY',
  SE: 'SEK', NO: 'NOK', DK: 'DKK', PL: 'PLN', CZ: 'CZK', HU: 'HUF', RO: 'RON',
  BG: 'BGN', CH_: 'CHF', BR: 'BRL', MX: 'MXN', IN: 'INR', AE: 'AED', SG: 'SGD',
  ZA: 'ZAR', TR: 'TRY', IL: 'ILS', KR: 'KRW', CN: 'CNY', HK: 'HKD', RU: 'RUB',
  AR: 'ARS', CL: 'CLP', CO: 'COP', TH: 'THB', ID: 'IDR', MY: 'MYR', PH: 'PHP'
};
function flValuta(){ return FL_VALUTE[flPaese()] || 'EUR'; }

/** Il simbolo dei soldi di chi guarda: «€», «$», «£»… */
function flSimbolo(){
  try{
    const parti = new Intl.NumberFormat(flLocale(), { style: 'currency', currency: flValuta() }).formatToParts(0);
    const s = parti.filter(function(p){ return p.type === 'currency'; })[0];
    if (s && s.value) return s.value;
  }catch(_){ }
  return '€';
}

/** Una cifra con i suoi soldi: «1.200 €», «$1,200». */
function flSoldi(n){
  try{
    return new Intl.NumberFormat(flLocale(), { style: 'currency', currency: flValuta(), maximumFractionDigits: 0 }).format(+n || 0);
  }catch(_){ return (+n || 0) + ' ' + flSimbolo(); }
}

/** La data come la scrive il paese di chi guarda: 19/09/2026, o 9/19/2026. */
function flData(ts){
  try{ return new Date(ts).toLocaleDateString(flLocale()); }
  catch(_){ const d = new Date(ts); return d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear(); }
}

/** La stessa data con davanti il giorno della settimana: «Sabato 19/09/2026». */
function flDataConGiorno(ts){
  let g = '';
  try{ g = new Intl.DateTimeFormat(flLocale(), { weekday: 'long' }).format(new Date(ts)); }catch(_){ g = ''; }
  if (!g) return flData(ts);
  g = g.charAt(0).toUpperCase() + g.slice(1);
  return g + ' ' + flData(ts);
}
