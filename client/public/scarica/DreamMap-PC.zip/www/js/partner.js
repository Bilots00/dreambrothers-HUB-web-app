/* partner.js - Focus Partner: invita un amico, Pass Ospite di 14 giorni, e il confronto.

   Modelled on AppBlock's Guest Pass card and BlockSite's "Amici della produttività", cut down
   to what works without push notifications: a code to share, a link that makes two people
   partners and gives both 14 days of Premium, and a board where each partner's day (screen
   time, blocks) sits next to yours — plus "tu contro te stesso", today against last week and
   last month, which needs no friend at all.

   Everything server-side goes through NATIVE.accountApi (Google ID token, same identity as
   the backup). Without a Google login the screen explains and offers the login. */

const PARTNER_SHARE_URL = 'https://dream-brothers.com/pages/focuslock';
let PARTNER = { me: null, partners: [], passDays: 14, loadedAt: 0 };
let partnerTab = 'partners';

/* ---------------- screen ---------------- */
registerScreen('s-partner',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">Focus Partner</b></div>' +
  '<div class="pt-hero">' +
    '<div class="pt-pass">PREMIUM<br>GUEST<br>PASS<span class="gem">💎</span></div>' +
    '<h2>Invita un amico, concentratevi insieme</h2>' +
    '<p>Concentrarsi è più facile in due. Chi entra con il tuo codice riceve <b>14 giorni di Premium</b>, e li ricevi anche tu. Poi vi vedete i numeri a vicenda: chi ha usato meno il telefono oggi, chi ha retto più blocchi.</p>' +
    '<button class="cta" onclick="partnerShare()">📤 Condividi Pass Ospite</button>' +
    '<div class="pt-code" id="ptCode" hidden>Il tuo codice: <b id="ptCodeVal">—</b><button class="ghostmini" onclick="partnerCopyCode()">Copia</button></div>' +
  '</div>' +
  '<div id="ptLogin" class="uf-honest" hidden><span>👤</span><p><b>Serve l\'accesso con Google.</b> Il codice e i partner sono legati al tuo account, così li ritrovi su ogni telefono. <a href="#" onclick="partnerLogin();return false">Accedi con Google</a></p></div>' +
  '<div class="sect" style="margin-top:14px"><b>Hai un codice?</b></div>' +
  '<div class="addrow"><input class="fin" id="ptRedeem" placeholder="Codice dell\'amico, es. K7PX2Q" autocomplete="off" autocapitalize="characters" maxlength="12"><button class="addbtn" type="button" onclick="partnerRedeem()">✓</button></div>' +
  '<div class="bltabs" style="margin-top:16px">' +
    '<button class="bltab on" data-pt="partners" onclick="partnerTabGo(\'partners\')">Partner</button>' +
    '<button class="bltab" data-pt="me" onclick="partnerTabGo(\'me\')">Tu contro te</button>' +
  '</div>' +
  '<div id="ptPartners"></div>' +
  '<div id="ptMe" hidden></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

(function partnerStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.pt-hero{background:linear-gradient(170deg,#0B2A55,#001E44);border-radius:22px;padding:22px 18px 18px;color:#fff;text-align:center}',
    '.pt-hero h2{font:800 22px/1.2 var(--font-display);font-style:italic;margin:14px 0 8px;color:#fff}',
    '.pt-hero p{font:500 12.5px/1.6 var(--font-body);color:#DCE8F7;margin:0 0 16px}',
    '.pt-hero .cta{width:100%;background:#0075E3}',
    '.pt-pass{display:inline-block;position:relative;background:linear-gradient(160deg,#E63946,#C42B38);color:#fff;border-radius:14px;padding:16px 20px;',
    '  font:800 15px/1.25 var(--font-display);letter-spacing:.5px;text-align:left;box-shadow:0 14px 30px rgba(196,43,56,.35);transform:rotate(-3deg)}',
    '.pt-pass .gem{position:absolute;right:-10px;bottom:-10px;font-size:30px;transform:rotate(3deg)}',
    '.pt-code{margin-top:12px;font:600 12.5px var(--font-body);color:#DCE8F7;display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap}',
    '.pt-code b{font:800 20px var(--font-display);letter-spacing:.18em;color:#fff}',
    '.pt-code .ghostmini{background:rgba(255,255,255,.14);color:#fff;border-color:transparent}',
    '.pt-row{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:16px;padding:12px 14px;margin-bottom:8px}',
    '.pt-row .av{width:42px;height:42px;border-radius:50%;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;font:800 18px var(--font-display);flex:none}',
    '.pt-row .av.me{background:#001E44}',
    '.pt-row .who{flex:1;min-width:0}',
    '.pt-row .who b{display:block;font:700 13.5px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.pt-row .who small{display:block;font:500 11px var(--font-body);color:var(--muted);margin-top:2px}',
    '.pt-row .num{text-align:right;flex:none}',
    '.pt-row .num b{display:block;font:800 18px var(--font-display);color:var(--navy)}',
    '.pt-row .num small{font:600 10.5px var(--font-body);color:var(--muted)}',
    '.pt-row.lead{border-color:#22B14C;background:#F1FBF4}',
    '.pt-crown{font-size:14px;margin-left:4px}',
    '.pt-vs{background:#fff;border:1px solid var(--line);border-radius:18px;padding:16px;margin-bottom:10px}',
    '.pt-vs h3{font:800 15px var(--font-display);color:var(--navy);margin:0 0 10px}',
    '.pt-vs .line{display:flex;align-items:center;gap:10px;padding:8px 0;border-top:1px solid var(--line);font:600 12.5px var(--font-body);color:var(--muted)}',
    '.pt-vs .line:first-of-type{border-top:0}',
    '.pt-vs .line b{margin-left:auto;font:800 16px var(--font-display);color:var(--navy)}',
    '.pt-vs .line .d{font:800 12px var(--font-body);padding:3px 8px;border-radius:99px;background:#E2F5EA;color:#1B7F4B}',
    '.pt-vs .line .d.bad{background:var(--red-soft);color:var(--red-deep)}',
    '.pt-empty{text-align:center;padding:26px 14px;color:var(--muted);font:500 12.5px/1.6 var(--font-body)}',
    '.pt-empty .big{font-size:46px;margin-bottom:8px}',
    'body.dark .pt-row,body.dark .pt-vs{background:#12203A;border-color:#22345A}',
    'body.dark .pt-row .who b,body.dark .pt-row .num b,body.dark .pt-vs h3,body.dark .pt-vs .line b{color:#fff}',
    'body.dark .pt-row.lead{background:#0F2A1C}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------------- data ---------------- */
function partnerSignedIn(){
  let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ }
  return !!(u && u.provider === 'google');
}
async function partnerApi(method, path, body){
  if(!NATIVE || !NATIVE.accountApi) throw new Error('Disponibile solo nell\'app installata');
  const r = await NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
  return r || {};
}

async function partnerOpen(){
  goId('s-partner');
  partnerTabGo(partnerTab);
  await partnerRefresh(true);
}
async function partnerRefresh(force){
  const login = document.getElementById('ptLogin');
  const codeBox = document.getElementById('ptCode');
  if(!partnerSignedIn() || !NATIVE || !NATIVE.accountApi){
    if(login) login.hidden = false;
    if(codeBox) codeBox.hidden = true;
    partnerPaint();
    return;
  }
  if(login) login.hidden = true;
  if(!force && Date.now() - PARTNER.loadedAt < 60000){ partnerPaint(); return; }
  try{
    await partnerReport();            // my numbers first, so the board is never stale on my row
    const r = await partnerApi('GET', '/api/focuslock/partner');
    PARTNER.me = r.me || null; PARTNER.partners = r.partners || []; PARTNER.passDays = r.passDays || 14;
    PARTNER.loadedAt = Date.now();
    partnerApplyPass(PARTNER.me);
  }catch(e){ toast(e && e.message ? e.message : 'Server non raggiungibile'); }
  partnerPaint();
}

/* The Pass is decided by the server; the phone only mirrors it. */
function partnerApplyPass(me){
  if(!me) return;
  try{
    // Take the later of the two: a Guest Pass must not cut a 7-day trial short, and the trial
    // must not hide a longer pass.
    const cur = localStorage.getItem('fl_premium_until');
    const server = me.premiumUntil ? new Date(me.premiumUntil).getTime() : 0;
    const local = cur ? new Date(cur).getTime() : 0;
    if(server > local) localStorage.setItem('fl_premium_until', me.premiumUntil);
  }catch(_){ }
  if(typeof Premium !== 'undefined' && Premium._notify) Premium._notify();
  if(typeof renderProfile === 'function') renderProfile();
}

/* My day, as the partners will see it. Same numbers the Approfondimenti tab shows. */
let partnerReportedAt = 0;
async function partnerReport(){
  if(!partnerSignedIn() || !NATIVE || !NATIVE.accountApi) return;
  /* PRIVACY: il tempo di schermo esce dal telefono solo se l'utente l'ha acceso in Amici →
     «Cosa vedono gli amici». Di serie e' spento: gli amici vedono focus, serie e partita. */
  try{ if (localStorage.getItem('fl_privacy_extra') !== '1') return; }catch(_){ return; }
  if(Date.now() - partnerReportedAt < 10 * 60000) return;
  let todayMinutes = 0, blocksToday = 0, weekAvgMinutes = 0, name = null;
  try{ const t = await NATIVE.getScreenTimeToday(); if(t && t.granted) todayMinutes = t.minutes || 0; }catch(_){ }
  try{ const s = await NATIVE.getStats(); if(s) blocksToday = s.today || 0; }catch(_){ }
  try{
    const start = new Date(); start.setHours(0,0,0,0);
    const r = await NATIVE.getScreenTimeRange({ from: start.getTime() - 7*86400000, to: start.getTime(), bucket: 'day' });
    const days = (r && r.granted) ? (r.buckets || []).map(b => b.minutes || 0) : [];
    if(days.length) weekAvgMinutes = Math.round(days.reduce((a,b)=>a+b,0) / days.length);
  }catch(_){ }
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); name = u && u.name ? u.name : null; }catch(_){ }
  try{
    await partnerApi('POST', '/api/focuslock/partner/report', { todayMinutes, blocksToday, weekAvgMinutes, name });
    partnerReportedAt = Date.now();
  }catch(_){ }
}

/* ---------------- actions ---------------- */
function partnerShareText(){
  const code = PARTNER.me && PARTNER.me.code ? PARTNER.me.code : '';
  return 'Ti regalo 14 giorni di DreamMap Premium 🎁 L\'app dei DreamBrothers che blocca le distrazioni e ti fa concentrare sui tuoi sogni.\n'
    + 'Scaricala qui: ' + PARTNER_SHARE_URL + '\n'
    + (code ? 'Poi inserisci il mio codice in Profilo › Focus Partner: ' + code : '');
}
async function partnerShare(){
  if(!partnerSignedIn()){ toast('Accedi con Google per avere il tuo codice'); partnerLogin(); return; }
  if(!PARTNER.me) await partnerRefresh(true);
  if(!PARTNER.me){ return; }
  const text = partnerShareText();
  if(NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: text, title: 'Pass Ospite DreamMap' }); return; }catch(_){ } }
  if(navigator.share){ try{ await navigator.share({ text: text }); return; }catch(_){ } }
  partnerCopy(text); toast('Messaggio copiato: incollalo dove vuoi');
}
function partnerCopy(text){
  try{ navigator.clipboard && navigator.clipboard.writeText(text); }catch(_){ }
}
function partnerCopyCode(){
  if(PARTNER.me && PARTNER.me.code){ partnerCopy(PARTNER.me.code); toast('Codice copiato: ' + PARTNER.me.code); }
}
async function partnerRedeem(){
  const el = document.getElementById('ptRedeem');
  const code = (el ? el.value : '').trim().toUpperCase();
  if(code.length < 4){ toast('Scrivi il codice del tuo amico'); return; }
  if(!partnerSignedIn()){ toast('Prima accedi con Google'); partnerLogin(); return; }
  try{
    const r = await partnerApi('POST', '/api/focuslock/partner/redeem', { code: code });
    if(el) el.value = '';
    PARTNER.me = r.me || PARTNER.me; PARTNER.partners = r.partners || PARTNER.partners; PARTNER.loadedAt = Date.now();
    partnerApplyPass(PARTNER.me);
    partnerPaint();
    toast('Ora sei partner di ' + (r.partnerName || 'un amico') + ': ' + (r.passDays || 14) + ' giorni di Premium per tutti e due 🎉');
  }catch(e){ toast(e && e.message ? e.message : 'Codice non accettato'); }
}
async function partnerRemove(linkId, name){
  const ok = await blkConfirm('Chiudere il collegamento?', 'Non vedrai più i numeri di ' + name + ' e loro non vedranno i tuoi. Il Pass già ricevuto resta.', 'Chiudi', true);
  if(!ok) return;
  try{
    const r = await partnerApi('POST', '/api/focuslock/partner/remove', { linkId: linkId });
    PARTNER.partners = r.partners || []; partnerPaint();
  }catch(e){ toast(e && e.message ? e.message : 'Non riuscito'); }
}
function partnerLogin(){
  if(typeof nativeGoogleLogin === 'function'){
    Promise.resolve(nativeGoogleLogin()).then(function(){ setTimeout(function(){ partnerRefresh(true); }, 1200); });
  } else toast('Accesso non disponibile in anteprima');
}
function partnerTabGo(which){
  partnerTab = which;
  document.querySelectorAll('#s-partner .bltab').forEach(function(b){ b.classList.toggle('on', b.dataset.pt === which); });
  const p = document.getElementById('ptPartners'), m = document.getElementById('ptMe');
  if(p) p.hidden = which !== 'partners';
  if(m) m.hidden = which !== 'me';
  if(which === 'me') partnerPaintMe();
}

/* ---------------- painting ---------------- */
function ptFmt(min){ min = Math.max(0, Math.round(min || 0)); return (min >= 60 ? Math.floor(min/60) + 'h ' : '') + (min % 60) + 'm'; }
function ptInitial(n){ return (n || '?').trim().charAt(0).toUpperCase() || '?'; }

function partnerPaint(){
  const codeBox = document.getElementById('ptCode'), codeVal = document.getElementById('ptCodeVal');
  if(codeBox){ codeBox.hidden = !(PARTNER.me && PARTNER.me.code); }
  if(codeVal && PARTNER.me) codeVal.textContent = PARTNER.me.code || '—';
  const host = document.getElementById('ptPartners');
  if(!host) return;
  const me = PARTNER.me;
  const list = PARTNER.partners || [];
  if(!list.length){
    host.innerHTML = '<div class="pt-empty"><div class="big">🤝</div><b style="display:block;font:800 15px var(--font-display);color:var(--navy);margin-bottom:6px">Nessun partner ancora</b>'
      + 'Condividi il tuo Pass Ospite: chi entra con il tuo codice compare qui, con il suo tempo di schermo e i suoi blocchi di oggi. Vi tenete d\'occhio a vicenda, e vince chi usa meno il telefono.</div>';
    return;
  }
  // The board: me plus the partners, least screen time first. A partner who has not
  // reported today sits at the bottom, with the date of the last number.
  let myName = 'Tu'; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); if(u && u.name) myName = u.name + ' (tu)'; }catch(_){ }
  const rowsAll = [{ me:true, name: myName, todayMinutes: me ? me.todayMinutes : 0, blocksToday: me ? me.blocksToday : 0, reportedAt: me ? me.reportedAt : null }]
    .concat(list.map(function(p){ return Object.assign({ me:false }, p); }));
  const today = new Date().toDateString();
  const fresh = function(r){ return r.reportedAt && new Date(r.reportedAt).toDateString() === today; };
  rowsAll.sort(function(a,b){ const fa = fresh(a) ? 0 : 1, fb = fresh(b) ? 0 : 1; if(fa !== fb) return fa - fb; return (a.todayMinutes||0) - (b.todayMinutes||0); });
  const leader = rowsAll.filter(fresh)[0];
  host.innerHTML = rowsAll.map(function(r){
    const isLead = leader && r === leader && rowsAll.filter(fresh).length > 1;
    const when = fresh(r) ? 'oggi' : (r.reportedAt ? 'ultimo dato: ' + new Date(r.reportedAt).toLocaleDateString('it-IT') : 'nessun dato ancora');
    return '<div class="pt-row' + (isLead ? ' lead' : '') + '">'
      + '<div class="av' + (r.me ? ' me' : '') + '">' + esc(ptInitial(r.name)) + '</div>'
      + '<div class="who"><b>' + esc(r.name) + (isLead ? '<span class="pt-crown">👑</span>' : '') + '</b><small>' + esc(when) + ' · ' + (r.blocksToday || 0) + ' blocchi' + (r.me ? '' : (r.invitedByMe ? ' · invitato da te' : ' · ti ha invitato')) + '</small></div>'
      + '<div class="num"><b>' + ptFmt(r.todayMinutes) + '</b><small>schermo oggi</small></div>'
      + (r.me ? '' : '<button class="del" onclick="partnerRemove(' + r.linkId + ',\'' + esc(r.name).replace(/'/g, '&#39;') + '\')">✕</button>')
      + '</div>';
  }).join('');
}

/* "Tu contro te stesso": today against the average of the last 7 and of the last 30 days.
   No friend needed, and the honest baseline for anyone who wants to beat last month. */
async function partnerPaintMe(){
  const host = document.getElementById('ptMe');
  if(!host) return;
  if(!NATIVE || !NATIVE.getScreenTimeRange){ host.innerHTML = '<div class="pt-empty">Disponibile nell\'app installata.</div>'; return; }
  host.innerHTML = '<div class="pt-empty">Leggo i tuoi dati…</div>';
  try{
    const start = new Date(); start.setHours(0,0,0,0);
    const day = 86400000;
    const t = await NATIVE.getScreenTimeToday();
    if(!(t && t.granted)){
      host.innerHTML = '<div class="pt-empty"><div class="big">📊</div>Per il confronto serve l\'accesso ai dati di utilizzo. <a href="#" onclick="openPerm(\'usage\');return false">Abilita</a></div>';
      return;
    }
    const w = await NATIVE.getScreenTimeRange({ from: start.getTime() - 7*day, to: start.getTime(), bucket: 'day' });
    const m = await NATIVE.getScreenTimeRange({ from: start.getTime() - 30*day, to: start.getTime(), bucket: 'day' });
    const avg = function(r){ const d = (r && r.buckets || []).map(b => b.minutes || 0).filter(x => x > 0); return d.length ? Math.round(d.reduce((a,b)=>a+b,0)/d.length) : 0; };
    const today = t.minutes || 0, wk = avg(w), mo = avg(m);
    let blocks = 0, total = 0; try{ const s = await NATIVE.getStats(); blocks = s.today || 0; total = s.total || 0; }catch(_){ }
    const now = new Date(); const dayFrac = Math.max(0.05, (now.getHours()*60 + now.getMinutes()) / 1440);
    const line = function(label, base){
      if(!base) return '<div class="line">' + label + '<b>—</b></div>';
      // Compared pro rata: at 10 in the morning today's total is not yet a whole day.
      const expected = Math.round(base * dayFrac);
      const diff = today - expected;
      const pct = expected ? Math.round(Math.abs(diff) / expected * 100) : 0;
      const good = diff <= 0;
      return '<div class="line">' + label + ' <span class="d' + (good ? '' : ' bad') + '">' + (good ? '−' : '+') + pct + '%</span><b>' + ptFmt(base) + '</b></div>';
    };
    host.innerHTML = '<div class="pt-vs"><h3>Oggi finora: ' + ptFmt(today) + '</h3>'
      + line('Media ultimi 7 giorni', wk) + line('Media ultimi 30 giorni', mo)
      + '<p class="hintline" style="padding:8px 0 0">La percentuale confronta oggi con la stessa ora della giornata media: verde vuol dire che stai battendo il te stesso di prima.</p></div>'
      + '<div class="pt-vs"><h3>Blocchi</h3><div class="line">Oggi<b>' + blocks + '</b></div><div class="line">In totale<b>' + total + '</b></div></div>';
  }catch(e){ host.innerHTML = '<div class="pt-empty">Dati non disponibili adesso.</div>'; }
}

/* Report quietly whenever the home shell is on screen, so partners see today's numbers
   even from someone who never opens this page. Throttled inside partnerReport(). */
document.addEventListener('fl:screen', function(e){
  if(e && e.detail === 's-home') setTimeout(function(){ partnerReport(); }, 3000);
});
