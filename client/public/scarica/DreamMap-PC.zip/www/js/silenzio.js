/* ===========================================================================================
   QUANDO TACERE — una pagina sola per tutta l'app

   Prima il silenzio stava dentro alla chiamata dei sogni (una fascia, «dalla sera alla
   mattina») e il mantra aveva il suo, solo per il campanellino: la card compariva lo stesso,
   anche nel mezzo di una telefonata. Adesso qui si scelgono piu' fasce, ognuna con i suoi
   giorni (la notte, il turno di lavoro, le ore in macchina), e il Non disturbare del telefono.
   In quei momenti tacciono il mantra, la chiamata dei sogni, i promemoria e i premi dell'Io
   Futuro. Durante una telefonata l'app tace sempre, senza bisogno di sceglierlo.

   Lo legge il telefono (Silenzio.java) dall'impostazione `silenzio`; la pagina tiene una copia
   in `fl_silenzio` per il computer e per quando il motore non risponde.
   =========================================================================================== */
const SIL_GIORNI = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
function silDefault(){
  let da = 23 * 60 + 30, a = 7 * 60;
  try{ const dc = (typeof dcCfg === 'function') ? dcCfg() : null; if (dc && dc.quietFrom >= 0){ da = dc.quietFrom; a = dc.quietTo; } }catch(_){ }
  return { fasce: [{ da: da, a: a, giorni: [true, true, true, true, true, true, true], on: true }], dnd: true };
}
/* Vince la copia piu' recente: quella del telefono (SETTINGS) o quella della pagina
   (fl_silenzio, con la sua ora). Cosi' una modifica appena fatta non viene coperta da una
   rilettura del motore. */
function silLeggi(){
  const prova = function(raw){ try{ const o = raw ? JSON.parse(raw) : null; return (o && Array.isArray(o.fasce)) ? o : null; }catch(_){ return null; } };
  let mia = null, sua = null;
  try{ mia = prova(localStorage.getItem('fl_silenzio')); }catch(_){ }
  try{ sua = prova(typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.silenzio); }catch(_){ }
  if (mia && sua) return (+mia.at || 0) >= (+sua.at || 0) ? mia : sua;
  return mia || sua || silDefault();
}
async function silSalva(cfg){
  cfg.at = Date.now();
  const s = JSON.stringify(cfg);
  try{ localStorage.setItem('fl_silenzio', s); }catch(_){ }
  try{ if (typeof settingsSave === 'function') await settingsSave({ silenzio: s }); else if (typeof SETTINGS !== 'undefined') SETTINGS.silenzio = s; }catch(_){ }
}
function silHhmm(m){ return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); }
function silMin(v){ const p = String(v || '').split(':'); return (+p[0] || 0) * 60 + (+p[1] || 0); }
/** Solo le fasce: per il computer e per quando il telefono non risponde. */
function silInFascia(d){
  d = d || new Date();
  const now = d.getHours() * 60 + d.getMinutes();
  const oggi = (d.getDay() + 6) % 7, ieri = (oggi + 6) % 7;
  return (silLeggi().fasce || []).some(function(f){
    if (!f || f.on === false || f.da === f.a) return false;
    const g = f.giorni || [true, true, true, true, true, true, true];
    return f.da < f.a ? (g[oggi] && now >= f.da && now < f.a) : ((g[oggi] && now >= f.da) || (g[ieri] && now < f.a));
  });
}
/** Deve tacere adesso? Chiede al telefono (chiamate, Non disturbare, fasce); altrimenti le fasce. */
async function silOra(){
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.silenzioOra){
      const r = await NATIVE.silenzioOra();
      if (r && typeof r.silenzio === 'boolean') return r.silenzio;
    }
  }catch(_){ }
  return silInFascia();
}
function silRiassunto(){
  const c = silLeggi();
  const on = (c.fasce || []).filter(function(f){ return f.on !== false; });
  if (!on.length) return c.dnd ? 'Solo in Non disturbare' : 'Mai, tranne in chiamata';
  return on.map(function(f){ return silHhmm(f.da) + '–' + silHhmm(f.a); }).join(', ');
}

registerScreen('s-silenzio',
  '<div class="topbar"><button class="iconbtn" onclick="handleBack()">‹</button><b class="blk-title">Quando tacere</b></div>'
  + '<div id="silBody" class="sil-page"></div>', { back: 's-settings' });
function silApri(){ goId('s-silenzio'); silPaint(); }
function silPaint(){
  const host = document.getElementById('silBody'); if (!host) return;
  const c = silLeggi();
  host.innerHTML = '<p class="sil-intro">In queste ore tacciono il mantra, la chiamata dei sogni, i promemoria e i premi. Durante una telefonata l’app tace sempre.</p>'
    + '<div class="sect"><b>🔕 Fasce orarie</b></div>'
    + (c.fasce || []).map(function(f, i){
        const g = f.giorni || [true, true, true, true, true, true, true];
        return '<div class="ps-block sil-fascia' + (f.on === false ? ' spenta' : '') + '">'
          + '<div class="sil-riga"><input class="fin sil-ora" type="time" value="' + silHhmm(f.da) + '" onchange="silSet(' + i + ',\'da\',this.value)">'
          +   '<span class="sil-a">→</span>'
          +   '<input class="fin sil-ora" type="time" value="' + silHhmm(f.a) + '" onchange="silSet(' + i + ',\'a\',this.value)">'
          +   '<button type="button" class="switch' + (f.on === false ? '' : ' on') + '" onclick="silOn(' + i + ')" aria-label="Accesa"></button></div>'
          + '<div class="sil-giorni">' + SIL_GIORNI.map(function(x, j){ return '<button type="button" class="ff-pre' + (g[j] ? ' on' : '') + '" onclick="silGiorno(' + i + ',' + j + ')">' + x + '</button>'; }).join('') + '</div>'
          + '<button type="button" class="sil-via" onclick="silVia(' + i + ')">Togli questa fascia</button>'
          + '</div>';
      }).join('')
    + '<button type="button" class="sil-add" onclick="silAggiungi()">＋ Aggiungi una fascia</button>'
    + '<div class="sect"><b>Il telefono</b></div>'
    + '<div class="ps-block"><div class="blk-swrow" style="margin-top:0"><div><b>In Non disturbare</b><small>Se il telefono è in Non disturbare, tace anche l’app.</small></div>'
    +   '<button type="button" class="switch' + (c.dnd !== false ? ' on' : '') + '" onclick="silDnd()"></button></div></div>';
}
async function silModifica(fn){ const c = silLeggi(); fn(c); await silSalva(c); silPaint(); }
function silSet(i, k, v){ silModifica(function(c){ if (c.fasce[i]) c.fasce[i][k] = silMin(v); }); }
function silOn(i){ silModifica(function(c){ if (c.fasce[i]) c.fasce[i].on = c.fasce[i].on === false; }); }
function silGiorno(i, j){ silModifica(function(c){ const f = c.fasce[i]; if (!f) return; f.giorni = f.giorni || [true, true, true, true, true, true, true]; f.giorni[j] = !f.giorni[j]; }); }
function silVia(i){ silModifica(function(c){ c.fasce.splice(i, 1); }); }
function silAggiungi(){ silModifica(function(c){ c.fasce.push({ da: 14 * 60, a: 18 * 60, giorni: [true, true, true, true, true, false, false], on: true }); }); }
function silDnd(){ silModifica(function(c){ c.dnd = c.dnd === false; }); }
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-silenzio' && typeof settingsLoad === 'function') settingsLoad().then(silPaint); });

(function(){
  const css = [
    '.sil-page{padding:0 18px 32px}',
    /* la riga dentro alla chiamata dei sogni respira: non sta attaccata alle pillole */
    '.dc-sec .sil-link{margin-top:20px}',
    '.sil-intro{margin:4px 0 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.sil-fascia.spenta{opacity:.55}',
    '.sil-riga{display:flex;align-items:center;gap:8px}',
    '.sil-ora{flex:1;min-width:0;text-align:center;font-size:17px;padding-left:6px !important;padding-right:6px !important}',
    '.sil-ora::-webkit-calendar-picker-indicator{display:none}',
    '.sil-a{color:var(--faint);font-weight:800}',
    '.sil-giorni{display:flex;gap:6px;justify-content:center;margin-top:12px}',
    '.sil-giorni .ff-pre{flex:1 1 0;min-width:0;max-width:40px;padding:8px 0;text-align:center}',
    '.sil-via{display:block;margin:12px auto 0;border:0;background:transparent;color:var(--faint);font:700 12.5px var(--font-body);cursor:pointer}',
    '.sil-add{width:100%;margin:4px 0 16px;border:1.5px dashed var(--line);border-radius:14px;background:transparent;padding:12px;color:var(--blue,#0075E3);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .sil-add{color:#7FC3FF}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
