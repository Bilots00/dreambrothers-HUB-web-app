/* ===========================================================================================
   L'ALBERO MAESTRO: IL PROMPT PER LE AI (0.9.253)

   Andrea: un testo da dare alle AI con cui lavora (Claude, ChatGPT, Gemini, Cursor…) che le
   lega al suo albero maestro: le fa rifiutare le aggiunte fuori rotta e le mette dalla parte
   del nuovo te, contro il vecchio te che aggiunge. Il testo vive in content/albero-maestro.md;
   qui si riempie con il SUO albero (sogno, anno, mese, settimana, oggi: orizzonti.js e il
   foglio) e si copia o si condivide. Si apre dalla pagina del caveau.
   =========================================================================================== */
const AM = { md: '' };
function amEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function amAlbero(){
  const a = {};
  try{ a.SOGNO = (typeof nvSogno === 'function') ? String(nvSogno() || '').trim() : ''; }catch(_){ a.SOGNO = ''; }
  ['anno', 'mese', 'settimana'].forEach(function(k){ try{ a[k.toUpperCase()] = (typeof ozAnello === 'function') ? String((ozAnello(k) || {}).testo || '').trim() : ''; }catch(_){ a[k.toUpperCase()] = ''; } });
  try{ a.OGGI = (typeof stTask === 'function') ? String(stTask() || '').replace(/^[☐☑•]\s*/, '').trim() : ''; }catch(_){ a.OGGI = ''; }
  return a;
}
function amTesto(){
  const a = amAlbero();
  let t = AM.md.replace(/\{\{(SOGNO|ANNO|MESE|SETTIMANA|OGGI)\}\}/g, function(_, k){ return a[k] || '(ancora da scrivere)'; });
  /* 0.9.333: con il ponte acceso, il prompt dice all'AI come avvisare il Genio */
  if (typeof pntOn === 'function'){
    t += '\n\n## Il ponte con DreamMap\n\nAlla fine di ogni lavoro fai sapere al mio Genio cosa ho fatto: un riassunto di una o due frasi, mai la conversazione intera, mai dati sensibili.\n\n'
      + (pntOn() ? '- Se hai i connettori MCP, il server è ' + pntMcpUrl() + ' e lo strumento è `registra_lavoro`.\n- Se puoi fare una chiamata HTTP: POST ' + pntHttpUrl() + ' con JSON {"chiave":"' + pntChiave() + '","riassunto":"...","fonte":"il tuo nome","minuti":0,"in_rotta":true}.\n' : '')
      /* 0.9.353: nella Timeline il riquadro per incollare il resoconto non c'e' piu' (Andrea: "nessuno sta li' a copiare e incollare") */
      + '- Se non puoi chiamare niente, chiudi con un resoconto di due righe che comincia con "Resoconto per DreamMap:": lo mando io al mio Genio in chat.';
  }
  return t;
}
async function amCarica(){
  if (AM.md) return AM.md;
  try{ const r = await fetch('content/albero-maestro.md'); AM.md = await r.text(); }catch(_){ AM.md = ''; }
  return AM.md;
}
async function amApri(){
  await amCarica();
  if (!AM.md){ toast('Il testo non è disponibile adesso'); return; }
  let w = document.getElementById('amSheet');
  if (!w){ w = document.createElement('div'); w.id = 'amSheet'; w.className = 'alm-sheet'; w.addEventListener('click', function(e){ if (e.target === w) amChiudi(); }); document.body.appendChild(w); }
  const a = amAlbero();
  const vuoti = ['SOGNO', 'ANNO', 'MESE', 'SETTIMANA', 'OGGI'].filter(function(k){ return !a[k]; });
  /* 0.9.333, Andrea: "troppo testo, il prompt sotto al testo non e' pulito". Due blocchi, una cosa da fare per blocco; il testo del prompt si apre solo se lo vuoi leggere */
  const on = (typeof pntOn === 'function') && pntOn();
  w.innerHTML = '<div class="am-in"><i class="pr-grab"></i><button type="button" class="am-x" aria-label="Chiudi" onclick="amChiudi()">✕</button>'
    + '<span class="alm-ico" aria-hidden="true">🌳</span>'
    + '<h3>Il tuo piano, dentro le tue AI</h3>'
    + '<p class="am-sotto">Da lì in poi l’AI lavora per il nuovo te e rifiuta quello che è fuori rotta.</p>'
    + '<section class="alm-b"><b>Dai il piano alla tua AI</b><small>Incolla il prompt all’inizio di una chat con Claude, ChatGPT, Gemini o Cursor.</small>'
    +   '<div class="alm-az"><button type="button" class="cta" onclick="amCopia()">Copia il prompt</button><button type="button" class="alm-sec" onclick="amCondividi()">Condividi</button></div>'
    +   '<button type="button" class="alm-link" onclick="amTestoMostra(this)">Leggi il prompt</button><div class="am-box" id="amBox" hidden>' + amEsc(amTesto()) + '</div>'
    +   (vuoti.length ? '<p class="alm-manca">' + (vuoti.length === 1 ? 'Manca un livello' : 'Mancano ' + vuoti.length + ' livelli') + ' del tuo piano: ' + vuoti.map(function(k){ return k.toLowerCase(); }).join(', ') + '.</p>' : '')
    + '</section>'
    + '<section class="alm-b"><div class="alm-r"><div><b>Fai sapere al Genio cosa fai</b><small>La tua AI gli scrive su cosa hai lavorato. Solo un riassunto.</small></div><button type="button" class="switch' + (on ? ' on' : '') + '" onclick="amPonteTocca(this)" aria-label="Collega le tue AI"></button></div>'
    +   (on ? '<div class="alm-url"><code>' + amEsc(pntMcpUrl()) + '</code></div><div class="alm-az"><button type="button" class="cta" onclick="amPonteCopia()">Copia il collegamento</button><button type="button" class="alm-sec" onclick="amPonteInfo()">Come si usa</button></div>' : '')
    + '</section>'
    /* 0.9.348: la roadmap scritta dalla tua AI e il resoconto della sera che la aggiorna da sola (ponte.js) */
    + '<section class="alm-b"><b>La roadmap, aggiornata dalla tua AI</b><small>Ogni sera la tua AI racconta al Genio cosa hai fatto e, se serve, riscrive la roadmap.</small>'
    +   '<div class="alm-az"><button type="button" class="cta" onclick="amChiudi();setTimeout(function(){ if(typeof pntRoadmapApri===\'function\')pntRoadmapApri(); },250)">Imposta il resoconto della sera</button></div></section>'
    + '</div>';
  w.hidden = false;
  try{ flVibra(8); }catch(_){ }
}
function amTestoMostra(b){ const x = document.getElementById('amBox'); if (!x) return; x.hidden = !x.hidden; b.textContent = x.hidden ? 'Leggi il prompt' : 'Nascondi il prompt'; }
async function amPonteTocca(b){
  if (b) b.disabled = true;
  try{
    if (pntOn()){ await pntScollega(); toast('Scollegato: quello che le tue AI avevano scritto è cancellato'); }
    else { await pntCollega(); toast('Collegato'); }
  }catch(_){ toast('Serve la rete per collegare le tue AI'); }
  amApri();
}
async function amPonteCopia(){
  let ok = false;
  try{ await navigator.clipboard.writeText(pntMcpUrl()); ok = true; }catch(_){ }
  if (!ok){ try{ const ta = document.createElement('textarea'); ta.value = pntMcpUrl(); ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); }catch(_){ } }
  toast(ok ? 'Collegamento copiato' : 'Non sono riuscito a copiare');
}
/* 0.9.341, Andrea: "il testo e' tutto attaccato e non ci sono istruzioni pratiche, step 1, step 2, step 3: vai nella tua AI, vai su
   connettori, aggiungi il connettore". Una sezione per AI, con i passi numerati, e i due pulsanti per copiare quello che serve. */
const AM_PASSI = [
  { ico: '🟠', t: 'Claude, nell’app o sul sito', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'Apri Claude e vai in Impostazioni, poi in Connettori.',
    'Tocca "Aggiungi un connettore personalizzato", scrivi DreamMap come nome e incolla il collegamento.',
    'In una chat nuova scrivi "Leggi il mio piano DreamMap".'] },
  /* 0.9.353, Andrea: "deve esserci la possibilita' di collegarla, non il copia e incolla": per ChatGPT e Claude il collegamento come connettore */
  { ico: '💬', t: 'ChatGPT', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'In ChatGPT apri Impostazioni, poi App e connettori, attiva la modalità sviluppatore e crea un connettore con il collegamento.',
    'Da lì in poi ChatGPT legge il tuo piano e scrive al Genio da solo.'] },
  { ico: '🟠', t: 'Claude, sul sito e nell’app', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'Su claude.ai apri Impostazioni, poi Connettori, tocca "Aggiungi connettore personalizzato" e incolla il collegamento.',
    'Da lì in poi Claude legge il tuo piano e scrive al Genio da solo.'] },
  { ico: '💻', t: 'Claude Code e Cursor', p: [
    'Tocca "Copia il collegamento" qui sotto.',
    'In Claude Code scrivi nel terminale claude mcp add --transport http dreammap e incolla il collegamento.',
    'In Cursor apri Impostazioni, poi MCP, tocca "Aggiungi un nuovo server" e incolla il collegamento.',
    'Da lì in poi l’AI legge il tuo piano e scrive al Genio da sola.'] },
  { ico: '✨', t: 'Gemini e le altre AI', p: [
    'Tocca "Copia il prompt" qui sotto.',
    'Incolla il prompt come primo messaggio di una chat nuova.',
    'Alla fine chiedi il resoconto per DreamMap e mandalo al Genio nella chat.'] }
];
function amPonteInfo(){
  const on = (typeof pntOn === 'function') && pntOn();
  inSheet('<div class="en-foglio am-come"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="rmp-i-ico" aria-hidden="true">🔌</span><h3>Come si usa</h3>'
    + '<p class="am-come-s">Scegli la tua AI e segui i passi.</p>'
    + AM_PASSI.map(function(x){
        return '<section class="am-come-b"><b><span>' + x.ico + '</span>' + amEsc(x.t) + '</b><ol>' + x.p.map(function(r){ return '<li>' + amEsc(r) + '</li>'; }).join('') + '</ol></section>';
      }).join('')
    + '<div class="am-come-az">' + (on ? '<button type="button" class="cta" onclick="amPonteCopia()">Copia il collegamento</button>' : '') + '<button type="button" class="alm-sec" onclick="amCopia()">Copia il prompt</button></div>'
    + '<p class="am-come-n">🔒 Il collegamento è solo tuo. Non darlo ad altri.</p></div>');
}
function amChiudi(){ const w = document.getElementById('amSheet'); if (w) w.hidden = true; }
async function amCopia(){
  const t = amTesto();
  let ok = false;
  try{ if (navigator.clipboard && navigator.clipboard.writeText){ await navigator.clipboard.writeText(t); ok = true; } }catch(_){ }
  if (!ok){ try{ const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); }catch(_){ } }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast(ok ? 'Copiato: incollalo nella chat con l’AI' : 'Non sono riuscito a copiare: usa Condividi');
}
function amCondividi(){
  const t = amTesto();
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ NATIVE.shareText({ text: t, title: 'L’albero maestro' }); return; } }catch(_){ }
  try{ if (navigator.share){ navigator.share({ title: 'L’albero maestro', text: t }); return; } }catch(_){ }
  amCopia();
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.am-come{text-align:center}.am-come h3,.am-come .rmp-i-ico{text-align:center}.am-come-s{margin:6px 0 20px!important;text-align:center;font:500 14px var(--font-body);color:var(--muted)}',
    '.am-come-b{margin:0 0 16px;padding:16px;border-radius:18px;background:var(--bg,#F4F9FF);border:1px solid var(--line)}body.dark .am-come-b{background:#12203A;border-color:#22345A}',
    '.am-come-b > b{display:flex;align-items:center;justify-content:center;gap:10px;font:800 16px var(--font-display);color:var(--navy)}.am-come-b > b span{font-size:20px}',
    '.am-come-b ol{margin:14px 0 0;padding:0;list-style:none;counter-reset:pa;text-align:left}.am-come-b li{position:relative;counter-increment:pa;margin:0 0 10px;padding-left:36px;font:500 14px/1.5 var(--font-body);color:var(--navy)}body.dark .am-come-b li{color:#DCEBFF}.am-come-b li:last-child{margin-bottom:0}',
    '.am-come-b li::before{content:counter(pa);position:absolute;left:0;top:0;width:24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:800 12.5px/24px var(--font-body);text-align:center}',
    '.am-come-az .alm-sec{display:block;width:100%;margin:0;padding:15px 18px;border-radius:50px;border:1.5px solid #0075E3;background:transparent;color:#0075E3;font:800 15px var(--font-body);cursor:pointer}body.dark .am-come-az .alm-sec{color:#8CC6FF;border-color:#8CC6FF}',
    '.am-come-az{display:flex;flex-direction:column;gap:10px;margin:22px 0 14px}.am-come-az .cta{width:100%;margin:0}.am-come-n{margin:0!important;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.alm-sheet{position:fixed;inset:0;z-index:9400;background:rgba(5,12,30,.55);display:flex;align-items:flex-end;justify-content:center}.alm-sheet[hidden]{display:none}',
    '.am-in{width:100%;max-width:520px;max-height:88vh;overflow:auto;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:10px 18px calc(18px + env(safe-area-inset-bottom))}',
    'body.dark .am-in{background:#14234A;color:#fff}',
    '.am-in{position:relative}.alm-ico{display:block;margin:12px 0 8px;font-size:40px;line-height:1;text-align:center}.alm-b{margin-top:14px;padding:16px;border-radius:20px;background:#F0FBFF;text-align:center}body.dark .alm-b{background:#1C2E5A}.alm-b b{display:block;font:800 16px var(--font-display);color:var(--navy,#14234A)}body.dark .alm-b b{color:#fff}.alm-b small{display:block;margin-top:4px;font:500 13.5px/1.4 var(--font-body);color:var(--muted,#5B6B86)}body.dark .alm-b small{color:#C9D6EE}',
    '.alm-az{display:flex;gap:8px;margin-top:14px}.alm-az .cta{flex:1;margin:0}.alm-sec{flex:none;padding:0 16px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}body.dark .alm-sec{color:#fff}.alm-link{margin-top:12px;padding:0;border:0;background:none;color:#0075E3;font:700 13.5px var(--font-body);cursor:pointer}body.dark .alm-link{color:#8CC6FF}.alm-b .am-box{margin-top:10px;max-height:220px;overflow:auto;text-align:left}.alm-b .am-box[hidden]{display:none}.alm-manca{margin:12px 0 0;font:600 13px var(--font-body);color:#C62835}.alm-r{display:flex;align-items:center;gap:12px;text-align:left}.alm-r > div{flex:1;min-width:0}.alm-url{margin-top:12px;padding:10px;border-radius:12px;background:var(--card,#fff);overflow:hidden}body.dark .alm-url{background:#14234A}.alm-url code{display:block;font:500 11.5px monospace;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.am-kick{margin:10px 0 4px;text-align:center;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}',
    '.am-in h3{margin:0;text-align:center;font:800 20px var(--font-display,var(--font-body));color:var(--navy,#14234A)}body.dark .am-in h3{color:#fff}',
    '.am-sotto{margin:8px 0 10px;text-align:center;font:500 13.5px/1.5 var(--font-body);color:var(--muted,#5B6B86)}body.dark .am-sotto{color:#C9D6EE}',
    '.am-avviso{margin:0 0 10px;padding:9px 12px;border-radius:12px;background:rgba(255,214,107,.18);border:1px solid rgba(255,214,107,.6);font:600 12.5px/1.45 var(--font-body);color:#C42B38}body.dark .am-avviso{color:#FF8A93}',
    '.am-box{max-height:38vh;overflow:auto;white-space:pre-wrap;padding:12px;border-radius:14px;background:var(--bg,#F3F6FB);font:500 12.5px/1.5 var(--font-body);color:var(--navy,#14234A)}body.dark .am-box{background:rgba(255,255,255,.06);color:#EEF4FF}',
    '.am-btn{display:flex;gap:8px;margin:12px 0 4px}.am-btn .cta{flex:1;margin:0}',
    '.am-share{flex:0 0 auto;padding:0 16px;border:0;border-radius:99px;background:transparent;box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}body.dark .am-share{color:#fff;box-shadow:0 0 0 1.5px rgba(255,255,255,.25)}',
    '.cvp-prompt{display:flex;align-items:center;gap:12px;width:100%;margin:0 0 12px;padding:14px;border:0;border-radius:18px;text-align:left;background:linear-gradient(135deg,#1E2A5A,#0F2041);color:#fff;cursor:pointer}',
    '.cvp-prompt span{font-size:26px;flex:none}.cvp-prompt b{display:block;font:800 14.5px var(--font-body)}.cvp-prompt small{display:block;margin-top:2px;font:500 12.5px/1.4 var(--font-body);color:#C9D6EE}'
  ].join('');
  document.head.appendChild(st);
})();
