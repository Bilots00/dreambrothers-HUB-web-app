/* ===========================================================================================
   MIND MOVIE — la sala chiusa in fondo alla scheda

   Questa sezione è grigia, spenta e non si apre. È voluto, ed è l'unica funzione dell'app che
   esiste per NON essere usata: sta in fondo a «Nuovo te» perché ogni volta che si scorre fin
   qui ricordi che prima di aggiungere un'altra funzione c'è una partita da vincere.

        «Action without vision is a nightmare.
         Vision without action is a daydream.»
                                — proverbio giapponese

   Il biglietto non si compra: si guadagna, e ci sono due sole strade.

     1. L'ULTIMO LIVELLO. Il decimo, quello che arriva dai blocchi tenuti, dalle sessioni
        finite e dai giorni di mantra: è la strada lunga, quella di chi accumula.
     2. IL CAMPIONATO VINTO. Una stagione intera — trecentosessantacinque giorni — e alla fine
        il nuovo te davanti al vecchio. È la strada difficile, perché non basta un mese buono:
        serve un anno in cui hai vinto più giorni di quanti ne hai persi.

   Una volta aperta resta aperta: un premio che si può riperdere non è un premio, è un ricatto.

   COSA C'È DENTRO, quando si apre. Il mind movie è una pratica vecchia quanto lo sport: le
   immagini della vita che vuoi, in fila, con la tua frase sopra, guardate ogni giorno finché
   il cervello smette di trattarle come un'ipotesi. Qui sono scene — un'immagine e una riga —
   che scorrono a schermo intero.
   =========================================================================================== */

const CN_KEY = 'fl_cinema';            // { aperto: bool, apertoIl: ts, scene: [{img, riga}] }
const CN_LIVELLO_FINALE = 10;
const CN_STAGIONE_GG = 365;

function cnStato(){
  try{
    const v = JSON.parse(localStorage.getItem(CN_KEY) || 'null') || {};
    return { aperto: !!v.aperto, apertoIl: v.apertoIl || 0, scene: Array.isArray(v.scene) ? v.scene : [] };
  }catch(_){ return { aperto: false, apertoIl: 0, scene: [] }; }
}

function cnSalva(p){
  const s = Object.assign(cnStato(), p || {});
  try{ localStorage.setItem(CN_KEY, JSON.stringify(s)); }catch(_){ }
  return s;
}

/** Il giorno in cui è cominciata la stagione: il primo giorno dell'app. */
function cnStagioneDa(){
  const t = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0;
  return t || Date.now();
}

function cnGiorniStagione(){
  return Math.floor((Date.now() - cnStagioneDa()) / 86400000);
}

/* ---------------------------------------------------------------------------------------
   Il biglietto

   Le due strade si controllano qui, in un posto solo, e appena una delle due è aperta il
   risultato si scrive su disco: da lì in poi la sala è aperta e basta, anche se il punteggio
   dovesse tornare indietro il giorno dopo.
   --------------------------------------------------------------------------------------- */
/** L'unico che puo' aprire e chiudere la porta a mano: chi sviluppa l'app. */
function cnAdmin(){
  try{ return typeof FL_DEBUG_PREMIUM !== 'undefined' && !!FL_DEBUG_PREMIUM; }catch(_){ return false; }
}
/** Il Genio ha prescritto il trailer, e non e' ancora stato visto. */
function cnTrailerPronto(){
  try{
    return !!((typeof monPrescritto === 'function') && monPrescritto()
      && (typeof monPuo !== 'function' || monPuo(true)));
  }catch(_){ return false; }
}
/** Lo stato del cassetto: 'aperta' | 'trailer' | 'admin' | 'serrata'. */
function cnPorta(s){
  if (s && s.aperto) return 'aperta';
  if (cnTrailerPronto()) return 'trailer';
  if (cnAdmin()) return 'admin';
  return 'serrata';
}

/* LA SALA SI RICHIUDE, una volta sola.
   Era tornata aperta su tutti e due i dispositivi senza che nessuno avesse vinto niente: il
   tabellone gonfiato dalla somma diceva «sei avanti», e a quel punto bastava. Una stagione
   vera dura trecentosessantacinque giorni, e quelli non c'erano. Chi ha davvero chiuso una
   stagione in vantaggio se la riapre al primo controllo, perche' cnControlla() lo rifa'. */
(function cnRichiudi(){
  const K = 'fl_cn_richiusa_v2';
  try{
    if (localStorage.getItem(K)) return;
    localStorage.setItem(K, '1');
    const raw = JSON.parse(localStorage.getItem(CN_KEY) || 'null') || {};
    if (!raw.aperto) return;
    const gg = (typeof cnGiorniStagione === 'function') ? cnGiorniStagione() : 0;
    if (gg >= CN_STAGIONE_GG) return;                 // stagione vera finita: resta sua
    raw.aperto = false; raw.apertoIl = 0; raw.come = '';
    localStorage.setItem(CN_KEY, JSON.stringify(raw));
  }catch(_){ }
})();

function cnControlla(){
  let s = cnStato();
  /* CHI L'HA VISTA APRIRSI PER IL LIVELLO SE LA RITROVA CHIUSA, una volta sola.
     Il livello 13 e' arrivato in un tocco per un difetto della scala dei punti, non per un
     anno di partite: quella porta non era stata guadagnata, e una porta aperta per sbaglio
     non e' un premio. La ragione e' scritta qui perche' non sembri un capriccio. */
  try{
    const raw = JSON.parse(localStorage.getItem(CN_KEY) || 'null') || {};
    if (raw.aperto && raw.come === 'livello'){
      s = cnSalva({ aperto: false, apertoIl: 0, come: '' });
    }
  }catch(_){ }
  if (s.aperto) return s;

  /* UNA STRADA SOLA: il campionato. La strada del livello e' stata tolta — dieci livelli si
     scalano in due settimane buone, una stagione intera vinta no. */
  const gg = cnGiorniStagione();
  const punti = (typeof mtRoll === 'function') ? mtRoll() : { old: 0, neo: 0 };
  const campionatoVinto = gg >= CN_STAGIONE_GG && (punti.neo || 0) > (punti.old || 0);
  if (campionatoVinto) return cnSalva({ aperto: true, apertoIl: Date.now(), come: 'campionato' });
  return s;
}

/* ---------------------------------------------------------------------------------------
   LO SCHERMO PICCOLO — il film parte nella card, il tutto schermo e' una scelta

   «Guardalo» spalancava una sala nera a tutto schermo. E' troppo, per un tocco: il film parte
   dove sta il poster — tre, due, uno — e chi vuole il buio lo chiede col pulsante. Lo stesso
   schermo proietta il trailer del Genio quando la sala e' chiusa: e' la sua anteprima
   esclusiva, l'unica cosa che si vede li' dentro prima di aver vinto.
   --------------------------------------------------------------------------------------- */
let CN_PIC_T = 0, CN_PIC_I = 0;

function cnSchermo(){ return document.getElementById('cnPoster'); }

/** 3, 2, 1 nello schermo piccolo, poi `dopo()`. */
function cnConto(dopo){
  const sc = cnSchermo();
  if (!sc){ dopo(); return; }
  let n = 3;
  const tick = function(){
    if (!cnSchermo()) return;                      // la card e' stata ridisegnata: si ferma
    sc.innerHTML = '<span class="cn-conto">' + n + '</span>';
    if (n-- > 1){ CN_PIC_T = setTimeout(tick, 800); return; }
    CN_PIC_T = setTimeout(dopo, 800);
  };
  clearTimeout(CN_PIC_T);
  tick();
}

/** Le scene, nello schermo piccolo. */
function cnProiettaScene(){
  const s = cnStato();
  if (!s.scene.length){ cnMontaOpen(); return; }
  CN_PIC_I = 0;
  cnConto(function(){
    const gira = function(){
      const sc = cnSchermo(), st = cnStato();
      if (!sc || !st.scene.length){ clearTimeout(CN_PIC_T); return; }
      const x = st.scene[CN_PIC_I % st.scene.length];
      sc.innerHTML = '<div class="cn-pic" style="background-image:url(' + (x.img || '').replace(/[()"]/g, '') + ')"></div>'
        + (x.riga ? '<p class="cn-pic-riga">' + esc(x.riga) + '</p>' : '')
        + '<button type="button" class="cn-full" onclick="cnSalaOpen()" aria-label="Schermo intero">⛶</button>';
      CN_PIC_I++;
      CN_PIC_T = setTimeout(gira, 5000);
    };
    gira();
  });
}

/** Il trailer del Genio, nello schermo piccolo, con il tutto schermo a portata di pollice. */
function cnProiettaTrailer(){
  const src = (typeof monVideo === 'function') ? monVideo() : '';
  if (!src) return;
  /* SUBITO, SU NERO. Il 3-2-1 veniva scritto sopra alla locandina, che restava li' come sfondo:
     numeri bianchi sopra a un'immagine, e poi il video che partiva sotto. Un trailer parte. */
  (function(dopo){ const sc = cnSchermo(); if (sc) sc.classList.add('in-onda'); dopo(); })(function(){
    const sc = cnSchermo();
    if (!sc) return;
    sc.innerHTML = '<video class="cn-pic-vid" id="cnTrailer" playsinline autoplay preload="auto">'
      + '<source src="' + src.replace(/"/g, '') + '" type="video/mp4"></video>'
      + '<button type="button" class="cn-full" onclick="cnTrailerIntero()" aria-label="Schermo intero">⛶</button>';
    const v = document.getElementById('cnTrailer');
    if (v){
      try{ const p = v.play(); if (p && p.catch) p.catch(function(){}); }catch(_){ }
      /* Vista qui o a tutto schermo, e' vista: vale la stessa rarita' del trimestre. */
      const presc = (typeof monPrescritto === 'function') && monPrescritto();
      v.addEventListener('ended', function(){
        /* conta per la rarita' del Genio solo se era lui a prescriverlo: guardarlo da soli
           non deve togliergli la possibilita' di mostrarlo quando serve */
        if (presc && typeof monSegnaVisto === 'function') monSegnaVisto();
        if (typeof monFineApri === 'function') monFineApri(presc);
        cnPaint();
      });
    }
  });
}
/* UNO SCHERMO ALLA VOLTA.
   Aprire il tutto schermo non toglieva di mezzo lo schermo piccolo: il video restava a
   suonare dietro all'overlay, e si sentivano due colonne sonore sfasate di mezzo secondo.
   Un video che non si vede piu' non deve nemmeno sentirsi. Muto PRIMA di mettere in pausa:
   su alcune WebView la pausa impiega un frame, e in quel frame l'audio si sovrappone. */
function cnFermaSchermo(){
  clearTimeout(CN_PIC_T);
  const v = document.getElementById('cnTrailer');
  if (!v) return 0;
  const t = v.currentTime || 0;
  try{ v.muted = true; v.pause(); }catch(_){ }
  return t;
}

function cnTrailerIntero(){
  const t = cnFermaSchermo();
  const presc = (typeof monPrescritto === 'function') && monPrescritto();
  if (typeof monApri === 'function') monApri({ da: t, manuale: !presc, genio: presc });
}

/** La tappa della mappa porta QUI, non al video: si arriva davanti allo schermo, poi si guarda. */
function cnVaiAlTrailer(){
  if (typeof mpClose === 'function') try{ mpClose(); }catch(_){ }
  if (typeof vzApri === 'function') vzApri();
  setTimeout(function(){
    try{ localStorage.setItem(CN_TAB_KEY, 'nightmare'); }catch(_){ }
    cnPaint();
    const b = document.getElementById('cnBox');
    if (b && b.scrollIntoView) b.scrollIntoView({ block: 'center', behavior: 'smooth' });
    setTimeout(cnProiettaTrailer, 500);
  }, 420);
}

/* ---------------------------------------------------------------------------------------
   Il pannello
   --------------------------------------------------------------------------------------- */

/**
 * LA SALA E' UN CASSETTO, e di serie e' chiuso a chiave.
 *
 * <p>Una sezione che non si e' guadagnata non deve occupare mezzo schermo con il suo poster
 * grigio: occupa una riga, con il lucchetto, e dice cosa la apre. Il cassetto si apre in tre
 * casi soli: la stagione vinta (e allora e' la sala vera), il trailer prescritto dal Genio
 * (una volta sola: quando e' stato visto si richiude da se'), e chi sviluppa l'app.</p>
 */
const CN_TAB_KEY = 'fl_cn_tab';
function cnTab(){
  /* il trailer prescritto dal Genio si vede per primo: e' l'unica cosa urgente della sala */
  const presc = (typeof monPrescritto === 'function') && monPrescritto() && (typeof monPuo !== 'function' || monPuo(true));
  try{ const v = localStorage.getItem(CN_TAB_KEY); if (v === 'dreamlife' && !presc) return 'dreamlife'; }catch(_){ }
  return 'nightmare';
}
function cnSetTab(t){
  try{ localStorage.setItem(CN_TAB_KEY, t); }catch(_){ }
  cnFermaSchermo();
  cnPaint();
}

/**
 * LA SALA HA DUE SCHERMI.
 *
 * <p>NIGHTMARE e' aperto a tutti: e' dove porta la strada di adesso, un minuto al buio. E' il
 * filmato che il Genio prescrive quando la probabilita' di arrivare scende, e chiunque puo'
 * guardarlo quando vuole. Alla fine c'e' la vita in settimane.</p>
 *
 * <p>DREAMLIFE e' la sala vera, quella della vita che stai costruendo, e resta chiusa finche'
 * non vinci il campionato: un premio che si compra non e' un premio.</p>
 */
let CN_DL_T = 0;
let CN_HOST = 'cnBox';
function cnPaint(hostId){
  if (hostId) CN_HOST = hostId;
  const el = document.getElementById(CN_HOST) || document.getElementById('cnBox');
  if (!el) return;
  clearTimeout(CN_DL_T);
  CN_DL_T = setTimeout(function(){ const p = el.querySelector('.cn-dl'); if (p) p.classList.add('cs'); }, 2000);
  const s = cnControlla();
  const tab = cnTab();
  el.innerHTML = '<div class="sev-intro cn-intro"><div class="sev-intro-ic">\ud83c\udfac</div>'
    + '<h2>Mind Movie</h2></div>'
    /* IL CONCEPT, in due righe: il film della tua vita futura, come i fantasmi che mostrano a
       Scrooge dove porta la strada che sta facendo. Due schermi: le conseguenze e la ricompensa. */
    + '<p class="life-sub cn-pitch"><b>Il film della tua vita, prima che accada.</b></p>'
    + '<p class="life-sub cn-pitch">Come i fantasmi che mostrano a Scrooge il suo futuro: <b>Nightmare</b> \u00e8 dove ti portano le abitudini di oggi, <b>Dreamlife</b> \u00e8 la vita che potresti vivere se segui la tua roadmap.</p>'
    + '<div class="cn-tabs" role="tablist">'
    +   '<button type="button" role="tab" class="cn-t-nm' + (tab === 'nightmare' ? ' on' : '') + '" onclick="cnSetTab(\'nightmare\')">\ud83d\udc80 Nightmare</button>'
    +   '<button type="button" role="tab" class="cn-t-dl' + (tab === 'dreamlife' ? ' on' : '') + '" onclick="cnSetTab(\'dreamlife\')">'
    +     '\u2728 Dreamlife</button>'
    + '</div>'
    + (tab === 'nightmare' ? cnNightmare() : cnDreamlife(s));
}

function cnNightmare(){
  const presc = (typeof monPrescritto === 'function') && monPrescritto() && (typeof monPuo !== 'function' || monPuo(true));
  let visto = false;
  try{ visto = localStorage.getItem('fl_mm_visto') === '1'; }catch(_){ }
  return '<div class="cn-card">'
    +   '<div class="cn-poster cn-nm" id="cnPoster">'
    +     '<button type="button" class="cn-play" onclick="cnProiettaTrailer()" aria-label="Guarda">\u25b6</button>'
    +     '<small class="cn-play-l">' + (presc ? 'Il Genio te l\u2019ha prescritto' : 'Trailer') + '</small>'
    +   '</div>'
    +   '<p class="cn-why">\u00c8 solo il trailer. Il film intero sulla tua vita futura \u00e8 in lavorazione, e se continui cos\u00ec esce presto.</p>'
    +   '<p class="cn-soon">COMING SOON</p>'
    +   (visto ? '<button type="button" class="cta cn-mm" onclick="mmOpen(\'s-home\')">\u231b La tua vita in settimane</button>' : '')
    + '</div>';
}

function cnDreamlife(s){
  if (cnPorta(s) === 'aperta') return cnAperto(s, true);
  const gg = cnGiorniStagione();
  const mancano = Math.max(0, CN_STAGIONE_GG - gg);
  const p = (typeof mtRoll === 'function') ? mtRoll() : { old: 0, neo: 0 };
  const avanti = (p.neo || 0) > (p.old || 0);
  return '<div class="cn-locked">'
    + '<div class="cn-card">'
    /* lo schermo chiuso resta com'era per due secondi, poi si apre sul cinema: in sala c'e'
       gia' qualcosa in programmazione, solo non e' ancora il tuo turno */
    +   '<div class="cn-poster cn-dl" id="cnPoster"><span class="cn-ico">\ud83c\udf9e\ufe0f</span><div class="cn-lock">\ud83c\udf9f\ufe0f</div>'
    +     '<div class="cn-dl-img"><b>COMING SOON</b></div></div>'
    +   '<blockquote class="cn-quote">Action without vision is a nightmare.<br>'
    +     '<b>Vision without action is a daydream.</b>'
    +     '<cite>proverbio giapponese</cite></blockquote>'
    +   '<p class="cn-why">Il biglietto non si compra: si vince.</p>'
    +   '<div class="cn-ways">'
    +     '<div class="cn-way' + (gg >= CN_STAGIONE_GG && avanti ? ' ok' : '') + '">'
    +       '<span>\ud83c\udfc6</span><div><b>Vinci il campionato</b>'
    +       '<small>' + (mancano > 0
            ? 'Una stagione intera. Mancano <b>' + mancano + '</b> giorni, e adesso sei '
              + (avanti ? 'avanti' : 'sotto') + ' <b>' + (p.old || 0) + ' \u2013 ' + (p.neo || 0) + '</b>'
            : 'Stagione finita: ' + (avanti ? 'hai vinto' : 'chiusa sotto, ' + (p.old || 0) + ' \u2013 ' + (p.neo || 0)))
    +       '</small></div></div>'
    +   '</div>'
    + '</div></div>';
}

/** La riga del cassetto, per chi la usa ancora da fuori (la mappa). */
function cnRigaChiusa(porta){
  const trailer = porta === 'trailer';
  const sotto = trailer ? 'Il Genio ti ha lasciato un\u2019anteprima' : 'Si apre quando vinci il campionato';
  return '<span class="cn-key">' + (trailer ? '\ud83c\udfac' : '\ud83d\udd12') + '</span>'
    + '<span class="cn-nome"><b>Mind Movie</b><small>' + sotto + '</small></span>';
}

function cnAperto(s, senzaTesta){
  const n = (s.scene || []).length;
  return (senzaTesta ? '' : '<div class="sev-intro cn-intro"><div class="sev-intro-ic">\ud83c\udfac</div><h2>Mind Movie</h2></div>')
    + '<p class="life-sub">Ce l\'hai fatta. La sala \u00e8 aperta: le immagini della vita che stai '
    + 'costruendo, con la tua frase sopra.</p>'
    + '<div class="cn-card">'
    +   '<div class="cn-poster open" id="cnPoster"><span class="cn-ico">\ud83c\udf7f</span></div>'
    +   '<p class="cn-why">' + (n
          ? '<b>' + n + (n === 1 ? ' scena</b> nel tuo film.' : ' scene</b> nel tuo film.')
          : 'Non c\'\u00e8 ancora nessuna scena. Una foto e una riga: si comincia da l\u00ec.') + '</p>'
    +   '<button type="button" class="cta" onclick="' + (n ? 'cnProiettaScene()' : 'cnSalaOpen()') + '">' + (n ? '\u25b6 Guardalo' : 'Monta la prima scena') + '</button>'
    +   (n ? '<button type="button" class="life-edit cn-edit" onclick="cnMontaOpen()">Cambia le scene</button>' : '')
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   Il montaggio e la proiezione
   --------------------------------------------------------------------------------------- */

function cnMontaOpen(){
  const s = cnStato();
  let box = document.getElementById('cnMonta');
  if (!box){
    box = document.createElement('div');
    box.id = 'cnMonta';
    box.className = 'cn-monta';
    document.body.appendChild(box);
  }
  box.innerHTML = '<div class="cn-monta-top">'
    + '<button type="button" class="iconbtn" onclick="cnMontaClose()">‹</button><b>Le tue scene</b></div>'
    + '<div class="cn-list">'
    + (s.scene.length ? s.scene.map(function(sc, i){
        return '<div class="cn-scene">'
          + (sc.img ? '<img src="' + sc.img.replace(/"/g, '') + '" alt="">' : '<i class="cn-noimg">🖼️</i>')
          + '<input value="' + esc(sc.riga || '') + '" maxlength="90" placeholder="La riga di questa scena" '
          +   'onchange="cnSetRiga(' + i + ', this.value)">'
          + '<button type="button" onclick="cnDelScena(' + i + ')" aria-label="Togli">✕</button></div>';
      }).join('') : '<p class="cn-vuoto">Nessuna scena. Aggiungi la prima: una foto di dove vuoi arrivare, e una riga che la dica.</p>')
    + '</div>'
    + '<button type="button" class="cta" onclick="cnAddScena()">+ Aggiungi una scena</button>';
  box.hidden = false;
}

function cnMontaClose(){
  const b = document.getElementById('cnMonta');
  if (b) b.remove();
  cnPaint();
}

function cnSetRiga(i, v){
  const s = cnStato();
  if (!s.scene[i]) return;
  s.scene[i].riga = String(v || '').trim().slice(0, 90);
  cnSalva({ scene: s.scene });
}

function cnDelScena(i){
  const s = cnStato();
  s.scene.splice(i, 1);
  cnSalva({ scene: s.scene });
  cnMontaOpen();
}

/* La foto: rimpicciolita prima di essere tenuta, come tutte le altre di quest'app. Un mind
   movie di dieci scene con dieci foto da telefono riempirebbe da solo la memoria del browser. */
function cnAddScena(){
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    const fr = new FileReader();
    fr.onload = function(){
      const img = new Image();
      img.onload = function(){
        try{
          const W = 720, cv = document.createElement('canvas');
          const scala = Math.min(1, W / Math.max(img.width, img.height));
          cv.width = Math.round(img.width * scala);
          cv.height = Math.round(img.height * scala);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          let out = cv.toDataURL('image/jpeg', 0.78);
          if (out.length > 500000) out = cv.toDataURL('image/jpeg', 0.6);
          const s = cnStato();
          s.scene.push({ img: out, riga: '' });
          cnSalva({ scene: s.scene });
          cnMontaOpen();
        }catch(e){ if (typeof toast === 'function') toast('Immagine troppo grande'); }
      };
      img.onerror = function(){ if (typeof toast === 'function') toast('Non riesco a leggere questa immagine'); };
      img.src = fr.result;
    };
    fr.readAsDataURL(f);
  });
  document.body.appendChild(inp);
  inp.click();
}

let CN_T = 0, CN_I = 0;

/** La proiezione: una scena ogni cinque secondi, a schermo intero, senza niente intorno. */
function cnSalaOpen(){
  const s = cnStato();
  if (!s.scene.length){ cnMontaOpen(); return; }
  /* Lo schermo piccolo si spegne quando si apre la sala: le scene sono immagini e non fanno
     rumore, ma una giostra che continua a girare dietro consuma e, al ritorno, riporta a una
     scena diversa da quella da cui si era usciti. */
  cnFermaSchermo();
  CN_I = 0;
  let box = document.getElementById('cnSala');
  if (!box){
    box = document.createElement('div');
    box.id = 'cnSala';
    box.className = 'cn-sala';
    document.body.appendChild(box);
  }
  box.hidden = false;
  cnSalaPaint();
  clearInterval(CN_T);
  CN_T = setInterval(function(){
    const n = cnStato().scene.length;
    if (!n){ cnSalaClose(); return; }
    CN_I = (CN_I + 1) % n;
    cnSalaPaint();
  }, 5000);
  try{ window.addEventListener('popstate', cnSalaClose, { once: true }); history.pushState({ cn: 1 }, ''); }catch(_){ }
}

function cnSalaPaint(){
  const box = document.getElementById('cnSala');
  const s = cnStato();
  const sc = s.scene[CN_I];
  if (!box || !sc) return;
  box.innerHTML = '<button type="button" class="ls-x" onclick="cnSalaClose()" aria-label="Chiudi">✕</button>'
    + '<div class="cn-frame" style="background-image:url(' + (sc.img || '').replace(/[()"]/g, '') + ')"></div>'
    + (sc.riga ? '<p class="cn-riga">' + esc(sc.riga) + '</p>' : '')
    + '<div class="cn-prog">' + s.scene.map(function(_, i){
        return '<i class="' + (i === CN_I ? 'on' : '') + '"></i>';
      }).join('') + '</div>';
}

function cnSalaClose(){
  clearInterval(CN_T);
  const b = document.getElementById('cnSala');
  if (b) b.remove();
}

(function cnStileCass(){
  const st = document.createElement('style');
  st.textContent = [
    '.cn-cassetto{margin:18px 0 6px;border:1px solid var(--line);border-radius:18px;background:#fff;overflow:hidden}',
    'body.dark .cn-cassetto{background:#12203A;border-color:#22345A}',
    '.cn-cassetto>summary,.cn-riga{display:flex;align-items:center;gap:12px;padding:15px 16px;cursor:pointer;list-style:none}',
    '.cn-cassetto>summary::-webkit-details-marker{display:none}',
    '.cn-serrata .cn-riga{cursor:default;opacity:.62}',
    '.cn-key{font-size:22px;flex:none}',
    '.cn-nome b{display:block;font:800 15px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .cn-nome b{color:#fff}',
    '.cn-nome small{display:block;margin-top:2px;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.cn-cassetto .cn-locked{padding:0 14px 14px}'
  ].join('');
  document.head.appendChild(st);
})();

(function cnStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* GRIGIO E SPENTO. Il filtro sta sulla card e non sui singoli pezzi: così qualsiasi cosa
       ci si metta dentro domani nasce già chiusa, e non c'è modo di dimenticarsene una. */
    '.cn-card{background:linear-gradient(170deg,#12203A,#0A1527);border-radius:22px;',
      'padding:20px 18px;color:#fff;text-align:center}',
    '.cn-locked{filter:grayscale(1) contrast(.92) brightness(.86);opacity:.92}',
    /* In questa app i <b> dentro alle righe sono spesso blocchi: qui devono restare parole
       dentro a una frase, o «sei al livello 1 di 10» diventa tre righe. */
    '.cn-way small b,.cn-why b{display:inline}',
    '.cn-poster{position:relative;height:150px;border-radius:16px;display:flex;align-items:center;',
      'justify-content:center;background:repeating-linear-gradient(90deg,#0B1220 0 14px,#101A2E 14px 28px)}',
    '.cn-poster.open{background:linear-gradient(135deg,#1B3A6B,#0E2350)}',
    /* LO SCHERMO PICCOLO: tutto quello che ci passa dentro sta nei suoi bordi. */
    '.cn-poster{overflow:hidden}',
    '.cn-conto{font:900 64px/1 var(--font-display);color:#fff;animation:cnPop .75s ease-out}',
    '@keyframes cnPop{from{transform:scale(1.6);opacity:0}to{transform:scale(1);opacity:1}}',
    '.cn-pic{position:absolute;inset:0;background-size:cover;background-position:center}',
    '.cn-pic-riga{position:absolute;left:12px;right:52px;bottom:10px;margin:0;font:800 14px/1.3 var(--font-display);',
      'color:#fff;text-align:left;text-shadow:0 1px 8px rgba(0,0,0,.7)}',
    '.cn-pic-vid{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000}',
    '.cn-full{position:absolute;right:10px;bottom:10px;width:36px;height:36px;border:0;border-radius:10px;',
      'background:rgba(0,0,0,.55);color:#fff;font-size:18px;cursor:pointer;z-index:2}',
    '.cn-play{width:64px;height:64px;border:0;border-radius:50%;background:#fff;color:#0E2350;',
      'font-size:24px;padding-left:5px;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.45)}',
    '.cn-play-l{position:absolute;left:0;right:0;bottom:12px;font:700 10.5px var(--font-body);',
      'letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.7)}',
    /* Con il trailer prescritto la sala resta chiusa ma lo schermo si accende: il grigio va
       via SOLO dal poster. */
    '.cn-anteprima .cn-poster{filter:none;opacity:1;background:#000}',
    '.cn-locked.cn-anteprima{filter:grayscale(1) contrast(.92) brightness(.86)}',
    '.cn-locked.cn-anteprima .cn-poster{filter:grayscale(0) contrast(1.1) brightness(1.18)}',
    '.cn-ico{font-size:58px;line-height:1}',
    '.cn-lock{position:absolute;right:14px;bottom:12px;font-size:30px}',
    '.cn-quote{margin:18px 0 0;font:600 13.5px/1.7 var(--font-body);color:#C8DAF2;font-style:italic}',
    '.cn-quote b{color:#fff;font-weight:800}',
    '.cn-quote cite{display:block;margin-top:8px;font:600 10.5px var(--font-body);font-style:normal;',
      'letter-spacing:.1em;text-transform:uppercase;color:rgba(200,218,242,.5)}',
    '.cn-why{margin:16px 0 0;font:500 12.5px/1.65 var(--font-body);color:rgba(200,218,242,.86)}',
    '.cn-why b{color:#fff}',
    '.cn-ways{display:flex;flex-direction:column;gap:10px;margin-top:18px}',
    '.cn-way{display:flex;align-items:center;gap:12px;text-align:left;background:rgba(255,255,255,.06);',
      'border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:13px 14px}',
    '.cn-way.ok{border-color:#8CF0C8}',
    '.cn-way.spenta{opacity:.62}',
    '.cn-way small i{display:block;margin-top:5px;font-style:italic;color:rgba(200,218,242,.55)}',
    '.cn-way span{font-size:24px;line-height:1;flex:none}',
    '.cn-way b{display:block;font:800 13.5px var(--font-body);color:#fff}',
    '.cn-way small{display:block;margin-top:3px;font:500 11.5px/1.5 var(--font-body);color:rgba(200,218,242,.72)}',
    '.cn-way small b{font-weight:800;color:#fff}',
    '.cn-card .cta{margin:18px 0 0}',
    '.cn-edit{display:block;margin:10px auto 0;color:rgba(200,218,242,.8)}',

    '.cn-monta{position:fixed;inset:0;z-index:9991;background:var(--bg,#0B1220);overflow-y:auto;',
      'padding:calc(env(safe-area-inset-top,0px) + 10px) 18px calc(env(safe-area-inset-bottom,0px) + 22px)}',
    '.cn-monta-top{display:flex;align-items:center;gap:10px;margin-bottom:16px}',
    '.cn-monta-top b{font:800 17px var(--font-display);color:var(--navy)}',
    '.cn-list{display:flex;flex-direction:column;gap:10px;margin-bottom:16px}',
    '.cn-scene{display:flex;align-items:center;gap:10px;background:var(--card,#fff);',
      'border:1px solid var(--line);border-radius:16px;padding:10px}',
    '.cn-scene img{width:56px;height:56px;border-radius:12px;object-fit:cover;flex:none}',
    '.cn-noimg{width:56px;height:56px;border-radius:12px;display:flex;align-items:center;',
      'justify-content:center;background:rgba(0,117,227,.1);font-size:24px;font-style:normal;flex:none}',
    '.cn-scene input{flex:1;min-width:0;border:0;background:transparent;font:600 13px var(--font-body);',
      'color:var(--navy);outline:none}',
    '.cn-scene button{flex:none;border:0;background:transparent;color:#E5515F;font:700 15px var(--font-body);cursor:pointer}',
    '.cn-vuoto{font:500 13px/1.6 var(--font-body);color:var(--muted);text-align:center;padding:26px 10px}',

    '.cn-sala{position:fixed;inset:0;z-index:9993;background:#000;display:flex;flex-direction:column;',
      'align-items:center;justify-content:center;padding:40px 22px}',
    '.cn-frame{flex:1;width:100%;background-size:cover;background-position:center;border-radius:18px}',
    '.cn-riga{margin:20px 0 0;font:800 20px/1.4 var(--font-display);color:#fff;text-align:center;max-width:20em}',
    '.cn-prog{display:flex;gap:5px;margin-top:20px}',
    '.cn-prog i{width:22px;height:3px;border-radius:99px;background:rgba(255,255,255,.28)}',
    '.cn-prog i.on{background:#fff}',

    '.cn-slides{margin:26px 0 18px}',
    '#cnHero{position:relative}',
    '#cnHero .vz-mia{text-transform:none;font-size:24px;max-width:100%}',
    '#cnHero .vz-aut{display:block;margin-top:14px;font:700 14px var(--font-body);color:rgba(255,255,255,.72)}',
    /* Le due diapositive con il testo: fondi scuri, perche' il testo bianco animato e' quello
       della scheda START e li' funziona su scuro. */
    '.cn-sl1{background:linear-gradient(150deg,#11294F,#061634 70%,#02050D)}',
    '.cn-sl3{background:linear-gradient(150deg,#0E2350,#0F2041 70%,#001E44)}',
    /* IL MANIFESTO: carta chiara, inchiostro nero, maiuscolo stretto. E la carta non si
       ribalta in modalita scura — un poster e un poster. */
    '.cn-poster-sl{background:#F2F0EA;display:flex;align-items:center;justify-content:center;padding:26px}',
    '.cn-manifesto{margin:0;text-align:center;color:#14120F;font:800 30px/1.14 var(--font-display);',
      'letter-spacing:-.01em;text-transform:uppercase}',
    'body.dark .cn-poster-sl{background:#F2F0EA}',
    'body.dark .cn-manifesto{color:#14120F}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ===========================================================================================
   LE DIAPOSITIVE SOPRA ALLA SALA

   Servono a preparare quello che viene dopo. La sala e' chiusa e resta chiusa: se il primo
   pensiero di chi arriva qui in fondo fosse «perche' non posso entrare», la sezione avrebbe
   fallito. Queste tre frasi rispondono prima che la domanda si formi.

     1. ONCE YOU NEED LESS, YOU WILL HAVE MORE — la stessa animazione di «Where attention goes /
        Energy flows» nella scheda START: la prima riga come sopratitolo, la seconda come
        titolo, una lettera dopo l'altra.
     2. IL PROVERBIO, accorciato alla meta' che punge — quella che parla di te che guardi una
        sala chiusa.

   ERANO TRE. In mezzo c'era la stessa frase della prima, stampata come su un poster: una
   ripetizione a sette secondi di distanza, che e' il modo piu' sicuro di far smettere di
   leggere una frase buona.
   =========================================================================================== */

function cnSlides(){
  if (typeof flHeroEnsure !== 'function') return null;
  const host = flHeroEnsure('cinema', 'tab-severa', 'cnHero', [
    /* 0.9.309, Andrea: "Quando ti serve meno" era una traduzione sbagliata di «Once you need less,
       you will have more». E le frasi si cambiano dai tre puntini, come la seconda slide di START. */
    '<article class="bh-slide on" data-i="0">'
    +   '<div class="bh-img cn-sl1"></div><span class="bh-ov"></span>'
    +   '<div class="bh-text" id="vzTesto0">' + vzFraseHtml(0) + '</div>'
    + '</article>',
    /* QUI C'ERA IL MANIFESTO — la stessa frase della diapositiva sopra, stampata su carta
       chiara. Due volte la stessa cosa a sette secondi di distanza non e' un'eco: e' un giro
       a vuoto, e la seconda volta nessuno la legge piu'. */
    '<article class="bh-slide" data-i="1">'
    +   '<div class="bh-img cn-sl3"></div><span class="bh-ov"></span>'
    +   '<div class="bh-text" id="vzTesto1">' + vzFraseHtml(1) + '</div>'
    + '</article>'
  ], { into: 'cnSlides', clouds: false, h: 300, auto: true });
  /* I tre puntini: la frase di questa slide, come nella seconda slide della scheda START */
  if (host && !document.getElementById('vzDots')){
    host.insertAdjacentHTML('beforeend',
      '<button type="button" class="mid-dots" id="vzDots" onclick="vzMenuApri(event)" aria-label="Cambia la frase">\u22ef</button>');
  }
  return host;
}

/* ===========================================================================================
   LE FRASI DELLA PAGINA VISUALIZATION, MODIFICABILI (0.9.309)

   Stesso meccanismo della seconda slide di START (piani.js, midMenuOpen/midChiediTesto): i tre
   puntini aprono il menu, "Scrivi la tua frase" apre il foglio con il campo grande e l'autore,
   "Rimetti la frase di serie" torna a quella originale. Una frase per slide, in fl_vz_frasi.
   =========================================================================================== */
const VZ_FRASI_KEY = 'fl_vz_frasi';
const VZ_FRASI_SERIE = [
  { su: 'Quando avrai bisogno di meno,', giu: 'avrai di più.', piatta: 'Quando avrai bisogno di meno, avrai di più.' },
  { su: 'Una visione senza azione', giu: 'resta un sogno a occhi aperti.', piatta: 'Una visione senza azione resta un sogno a occhi aperti.' }
];
function vzFrasi(){
  try{ const v = JSON.parse(localStorage.getItem(VZ_FRASI_KEY) || 'null'); return Array.isArray(v) ? v : []; }catch(_){ return []; }
}
function vzFrase(i){ const f = vzFrasi()[i]; return (f && f.testo) ? { testo: String(f.testo), autore: String(f.autore || '') } : null; }
function vzFraseHtml(i){
  const f = vzFrase(i);
  if (f) return '<h2 class="bh-title vz-mia">' + flHeroLine(f.testo, 0) + '</h2>'
    + (f.autore ? '<small class="vz-aut">\u2053 ' + esc(f.autore) + '</small>' : '');
  const d = VZ_FRASI_SERIE[i] || VZ_FRASI_SERIE[0];
  return '<p class="bh-eyebrow">' + flHeroLine(d.su, 0) + '</p><h2 class="bh-title">' + flHeroLine(d.giu, 1) + '</h2>';
}
/* 0.9.317, Andrea: "al posto del testo della slide voglio poter mettere un'immagine o un video, da una pagina apposita". fl_vz_media[i] =
   { tipo: 'immagine' | 'video', src }. L'immagine e' ridotta a 1080px come la copertina di Dream; il video resta sul telefono (NATIVE.pickMedia). */
const VZ_MEDIA_KEY = 'fl_vz_media';
function vzMedia(i){ try{ const l = JSON.parse(localStorage.getItem(VZ_MEDIA_KEY) || '[]'); return (l && l[i] && l[i].src) ? l[i] : null; }catch(_){ return null; } }
function vzMediaSalva(i, m){
  let l = []; try{ l = JSON.parse(localStorage.getItem(VZ_MEDIA_KEY) || '[]') || []; }catch(_){ l = []; }
  while (l.length <= i) l.push(null);
  l[i] = m;
  try{ localStorage.setItem(VZ_MEDIA_KEY, JSON.stringify(l)); }catch(_){ toast('Questa immagine è troppo grande per essere salvata'); return false; }
  vzFrasiApplica();
  return true;
}
function vzMediaHtml(m){
  const src = String(m.src).replace(/"/g, '');
  return m.tipo === 'video' ? '<video class="vz-media" src="' + src + '" autoplay muted loop playsinline></video>' : '<img class="vz-media" src="' + src + '" alt="">';
}
function vzFrasiApplica(){
  VZ_FRASI_SERIE.forEach(function(_, i){
    const t = document.getElementById('vzTesto' + i); if (!t) return;
    const m = vzMedia(i);
    const slide = t.closest ? t.closest('.bh-slide') : null;
    let v = slide ? slide.querySelector(':scope > .vz-media') : null;
    if (v) v.remove();
    if (m && slide){ slide.insertAdjacentHTML('afterbegin', vzMediaHtml(m)); t.innerHTML = ''; }
    else t.innerHTML = vzFraseHtml(i);
  });
}
function vzSlideOra(){
  try{ return (typeof FL_HEROES !== 'undefined' && FL_HEROES.cinema) ? (FL_HEROES.cinema.slide || 0) : 0; }catch(_){ return 0; }
}
function vzFraseSalva(i, f){
  const l = vzFrasi();
  while (l.length < VZ_FRASI_SERIE.length) l.push(null);
  l[i] = (f && f.testo) ? { testo: f.testo, autore: f.autore || '' } : null;
  try{ localStorage.setItem(VZ_FRASI_KEY, JSON.stringify(l)); }catch(_){ }
  vzFrasiApplica();
}
function vzMenuChiudi(){
  const m = document.getElementById('vzMenu'); if (m) m.remove();
  const v = document.getElementById('vzVeil'); if (v) v.remove();
}
function vzMenuApri(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('vzMenu')){ vzMenuChiudi(); return; }
  const i = vzSlideOra();
  const mia = !!vzFrase(i);
  const v = document.createElement('div');
  v.id = 'vzVeil'; v.className = 'arb-veil';
  v.addEventListener('click', function(e){ e.stopPropagation(); vzMenuChiudi(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(v);
  const m = document.createElement('div');
  m.className = 'arb-menu mid-menu'; m.id = 'vzMenu';
  m.innerHTML = '<p class="arb-mtit">Questa slide</p>'
    + '<button type="button" onclick="vzChiediTesto(' + i + ')">' + (mia ? 'Cambia la tua frase' : 'Scrivi la tua frase') + '</button>'
    + '<button type="button" onclick="vzMenuChiudi();vzPaginaApri(' + i + ')">Metti un’immagine o un video</button>'
    + (mia ? '<button type="button" onclick="vzMenuChiudi();vzFraseSalva(' + i + ', null)">Rimetti la frase di serie</button>' : '');
  (document.getElementById('phone') || document.body).appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, (ev && ev.currentTarget) || document.getElementById('vzDots'));
}
/* LA PAGINA DELLA SLIDE: cosa c'e' adesso, e le tre cose che si possono metterci */
let VZ_SLIDE = 0;
function vzPaginaApri(i){ VZ_SLIDE = i; goId('s-vz-slide'); vzPaginaPaint(); }
function vzPaginaPaint(){
  const b = document.getElementById('vzSlideBody'); if (!b) return;
  const i = VZ_SLIDE, m = vzMedia(i), f = vzFrase(i), d = VZ_FRASI_SERIE[i] || VZ_FRASI_SERIE[0];
  const anteprima = m ? vzMediaHtml(m) : '<p class="vz-pag-frase">' + esc(f ? f.testo : d.piatta) + '</p>';
  const riga = function(ico, t, s, az){ return '<button type="button" class="vz-pag-r" onclick="' + az + '"><span>' + ico + '</span><div><b>' + t + '</b><small>' + s + '</small></div></button>'; };
  b.innerHTML = '<div class="vz-pag-prev">' + anteprima + '</div>'
    + '<p class="vz-pag-s">Scegli cosa vuoi vedere in questa slide.</p>'
    + riga('🖼️', 'Un’immagine', 'Una foto dalla tua galleria', "document.getElementById('vzImgIn').click()")
    + riga('🎬', 'Un video', 'Parte da solo, senza audio, e ricomincia', 'vzScegliVideo()')
    + riga('✍️', 'Una frase', 'Il testo che vuoi leggere qui', 'vzChiediTesto(' + i + ')')
    + (m ? '<button type="button" class="vz-pag-via" onclick="vzMediaSalva(VZ_SLIDE, null);vzPaginaPaint()">Togli ' + (m.tipo === 'video' ? 'il video' : 'l’immagine') + ' e rimetti la frase</button>' : '')
    + '<input type="file" id="vzImgIn" accept="image/*" hidden onchange="vzImgCarica(this)">';
}
function vzImgCarica(inp){
  const f = inp && inp.files && inp.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = function(){
    const img = new Image();
    img.onload = function(){
      const M = 1080, s = Math.min(1, M / Math.max(img.width, img.height));
      const cv = document.createElement('canvas'); cv.width = Math.round(img.width * s); cv.height = Math.round(img.height * s);
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      let d = ''; try{ d = cv.toDataURL('image/jpeg', .82); }catch(_){ }
      if (!d){ toast('Non riesco a leggere questa foto'); return; }
      if (vzMediaSalva(VZ_SLIDE, { tipo: 'immagine', src: d })) vzPaginaPaint();
    };
    img.src = r.result;
  };
  r.readAsDataURL(f);
  inp.value = '';
}
async function vzScegliVideo(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickMedia){ toast('Disponibile nell\'app installata'); return; }
    const r = await NATIVE.pickMedia({ kind: 'video' });
    const uri = r && (r.uri || r.dataUri || r.path);
    if (!uri) return;
    if (vzMediaSalva(VZ_SLIDE, { tipo: 'video', src: uri })) vzPaginaPaint();
  }catch(_){ }
}
registerScreen('s-vz-slide', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title">Questa slide</b></div><div id="vzSlideBody" class="vz-pag"></div>', { back: 's-visualization' });
(function(){
  const st = document.createElement('style');
  st.textContent = '.vz-media{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0}'
    + '.vz-pag{display:flex;flex-direction:column;gap:12px;padding:8px 2px 40px}'
    + '.vz-pag-prev{position:relative;height:210px;border-radius:22px;overflow:hidden;background:linear-gradient(168deg,#123A70,#001E44);display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box}'
    + '.vz-pag-frase{margin:0;font:800 21px/1.3 var(--font-display);color:#fff;text-align:center}'
    + '.vz-pag-s{margin:10px 0 6px;font:500 15px var(--font-body);color:var(--muted);text-align:center}'
    + '.vz-pag-r{display:flex;align-items:center;gap:14px;width:100%;padding:16px;border:1px solid var(--line);border-radius:20px;background:var(--card,#fff);color:var(--navy);text-align:left;cursor:pointer}body.dark .vz-pag-r{color:#fff}'
    + '.vz-pag-r span{flex:none;font-size:28px;line-height:1}.vz-pag-r b{display:block;font:800 16px var(--font-display)}.vz-pag-r small{display:block;margin-top:2px;font:500 13.5px var(--font-body);color:var(--muted)}'
    + '.vz-pag-via{margin-top:6px;min-height:44px;border:0;background:none;color:#E63946;font:700 14.5px var(--font-body);cursor:pointer}';
  document.head.appendChild(st);
})();
/* Il foglio dal basso: la frase di adesso gia' dentro, e l'autore. Nessun limite di lunghezza. */
function vzChiediTesto(i){
  vzMenuChiudi();
  const f = vzFrase(i), d = VZ_FRASI_SERIE[i] || VZ_FRASI_SERIE[0];
  const testo = f ? f.testo : d.piatta;
  const autore = f ? f.autore : '';
  if (typeof stgFoglio !== 'function'){ const v = prompt('La frase che vuoi leggere qui:', testo); if (v !== null && String(v).trim()) vzFraseSalva(i, { testo: String(v).trim(), autore: autore }); return; }
  stgFoglio('<small class="stg-eti">La frase della slide</small><h2 class="stg-h">Cosa vuoi leggere qui?</h2>'
    + '<textarea class="mid-area" id="vzTxt" rows="4" placeholder="Scrivi la tua frase">' + esc(testo) + '</textarea>'
    + '<input class="mid-aut" id="vzAut" placeholder="Di chi è la frase? (facoltativo)" value="' + esc(autore) + '">'
    + '<button type="button" class="stg-cta" onclick="vzTestoSalva(' + i + ')">Salva la frase</button>'
    + (f ? '<button type="button" class="mid-serie" onclick="vzFraseSalva(' + i + ', null);stgFoglioChiudi()">Rimetti la frase di serie</button>' : ''));
  setTimeout(function(){ const t = document.getElementById('vzTxt'); if (t){ t.focus(); t.setSelectionRange(t.value.length, t.value.length); } }, 250);
}
function vzTestoSalva(i){
  const t = document.getElementById('vzTxt'), a = document.getElementById('vzAut');
  const v = t ? t.value.trim() : '';
  const d = VZ_FRASI_SERIE[i] || VZ_FRASI_SERIE[0];
  /* lasciata vuota, o uguale a quella di serie, e' la frase di serie */
  vzFraseSalva(i, (v && v !== d.piatta) ? { testo: v, autore: a ? a.value.trim() : '' } : null);
  try{ stgFoglioChiudi(); }catch(_){ }
}

/* In fondo alla scheda «Nuovo te»: dopo il lucchetto e dopo il primo passo, che è l'ultimo
   posto in cui si arriva scorrendo — ed è esattamente dove deve stare un premio non ancora
   guadagnato. */
(function cnGraft(){
  const tab = document.getElementById('tab-severa');
  if (!tab || document.getElementById('cnBox')) return;
  /* Le diapositive stanno SOPRA alla sezione, in un contenitore loro: cosi' la sala puo'
     cambiare stato (chiusa o aperta) senza ricostruirle ogni volta. */
  const slides = document.createElement('div');
  slides.id = 'cnSlides';
  slides.className = 'cn-slides';
  tab.appendChild(slides);

  const box = document.createElement('div');
  box.id = 'cnBox';
  box.className = 'cn-box';
  tab.appendChild(box);
})();

document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'severa') return;
  setTimeout(function(){ cnSlides(); cnPaint(); }, 320);
});
setTimeout(function(){ cnSlides(); cnPaint(); }, 3200);

(function cnStileTab(){
  const css = [
    '.cn-tabs{display:flex;gap:4px;padding:4px;margin:14px 0 14px;border-radius:14px;background:rgba(0,30,68,.07)}',
    'body.dark .cn-tabs{background:rgba(255,255,255,.08)}',
    '.cn-tabs button{flex:1;border:0;background:transparent;border-radius:11px;padding:10px 6px;font:800 13px var(--font-body);color:var(--muted);cursor:pointer}',
    '.cn-tabs button.on{background:#0E2350;color:#fff;box-shadow:0 2px 8px rgba(0,0,0,.18)}',
    'body.dark .cn-tabs button.on{background:#fff;color:#0E2350}',
    '.cn-poster.cn-nm{height:200px;background:#000 url(video/nightmare-poster.jpg) center/cover no-repeat}',
    '.cn-poster.cn-nm::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.15),rgba(0,0,0,.6));pointer-events:none}',
    '.cn-poster.cn-nm .cn-play,.cn-poster.cn-nm .cn-play-l{z-index:1}',
    '.cn-mm{margin-top:14px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function cnStilePillole(){
  const css = [
    /* la pillola rossa e la pillola blu: i due colori del brand */
    '.cn-tabs button.cn-t-nm{color:#E63946}',
    '.cn-tabs button.cn-t-dl{color:#0075E3}',
    'body.dark .cn-tabs button.cn-t-nm{color:#FF6B78}',
    'body.dark .cn-tabs button.cn-t-dl{color:#4FB8FF}',
    '.cn-tabs button.cn-t-nm.on,body.dark .cn-tabs button.cn-t-nm.on{background:#E63946;color:#fff;box-shadow:0 4px 14px rgba(230,57,70,.4)}',
    '.cn-tabs button.cn-t-dl.on,body.dark .cn-tabs button.cn-t-dl.on{background:#0075E3;color:#fff;box-shadow:0 4px 14px rgba(0,117,227,.4)}',
    '.cn-pitch{margin-top:6px}.cn-pitch + .cn-pitch{margin-top:4px}',
    /* la locandina del trailer: il teschio */
    '.cn-poster.cn-nm{background:#000 url(img/memento-skull.jpg) 30% 45%/cover no-repeat}',
    '.cn-poster.in-onda{background:#000 !important}',
    '.cn-poster.in-onda::after{display:none}',
    '.cn-soon{margin:10px 0 0;font:800 12px var(--font-body);letter-spacing:.32em;color:#E63946;text-align:center}',
    /* Dreamlife: le emoji, poi il cinema con COMING SOON */
    '.cn-dl-img{position:absolute;inset:0;border-radius:inherit;opacity:0;transition:opacity 1s ease;display:flex;align-items:center;justify-content:center;',
      'background:linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.72)),url(img/cinema-coming.jpg) center/cover no-repeat}',
    '.cn-dl-img b{font:800 22px var(--font-display);letter-spacing:.24em;color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.6)}',
    '.cn-dl.cs .cn-dl-img{opacity:1}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
