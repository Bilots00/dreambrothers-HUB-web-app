/* decision.js - il momento in cui si vota.

   Due sole schermate in tutta l'app chiedono qualcosa che non si può rimandare, e sono le uniche
   che usano il pannello olografico: la Modalità severa che sta per scadere, e la domanda sulla
   app dopo qualche settimana d'uso. Il motivo per cui somigliano a un terminale e non a un avviso
   di sistema è che un avviso di sistema si chiude senza guardarlo.

   La tesi sotto, che è di Aristotele prima che di chiunque altro: siamo ciò che facciamo
   ripetutamente. Ogni volta che si sceglie a favore della persona che si vuole diventare, quella
   persona diventa un po' più reale; ogni volta che si sceglie contro, si smagrisce — come un
   muscolo che smette di essere allenato. Per questo la decisione vale punti veri in entrambe le
   direzioni, e per questo il rifiuto non è gratis. */

const DEC = { open: false, kind: '', data: null };
const DEC_KEY = 'fl_decisions';

/* ---------- il registro dei voti ---------- */
function decLog(){
  try{ const v = JSON.parse(localStorage.getItem(DEC_KEY) || 'null'); return v && Array.isArray(v.votes) ? v : { votes: [], pts: 0 }; }
  catch(_){ return { votes: [], pts: 0 }; }
}
function decVote(kind, yes, pts){
  const l = decLog();
  l.votes.push({ kind: kind, yes: !!yes, pts: pts, at: Date.now() });
  if (l.votes.length > 200) l.votes = l.votes.slice(-200);
  l.pts = l.votes.reduce((a, v) => a + (v.pts || 0), 0);
  try{ localStorage.setItem(DEC_KEY, JSON.stringify(l)); }catch(_){ }
  if (typeof lvBump === 'function') lvBump();
  return l;
}
/* I punti delle decisioni, per il livello e per la classifica. */
function decPoints(){ return decLog().pts; }
function decCount(yes){ return decLog().votes.filter(v => !!v.yes === !!yes).length; }

/* ---------- il pannello ---------- */
function decOpen(kind, data){
  DEC.kind = kind; DEC.data = data || {}; DEC.open = true;
  const el = document.getElementById('decWrap');
  if (!el) return;
  el.hidden = false;
  document.body.classList.add('dec-on');
  /* la domanda «ti serve FocusLock?» a tutto schermo, come su Duolingo (0.9.203) */
  document.body.classList.toggle('dec-full', kind === 'rate');
  decPaint();
}
function decClose(){
  DEC.open = false;
  const el = document.getElementById('decWrap');
  if (el){ el.hidden = true; el.innerHTML = ''; }
  document.body.classList.remove('dec-on'); document.body.classList.remove('dec-full');
  /* chi aspetta la decisione (il tour del Genio) lo sa da qui */
  try{ document.dispatchEvent(new CustomEvent('fl:decisione', { detail: DEC.last || null })); }catch(_){ }
}

function decPaint(){
  const el = document.getElementById('decWrap');
  if (!el) return;
  const d = DEC.data || {};
  let kicker, title, line, left, right, leftAct, rightAct;

  if (DEC.kind === 'strict' && d.tour){
    /* LA PRIMA SCELTA, nel tour del Genio: stesso pannello, stesse conseguenze. */
    kicker = 'La tua prima scelta';
    title = 'CHI VUOI ESSERE?';
    line = 'Il nuovo te rinuncia alle abitudini che rimandano il sogno. Il vecchio te le tiene. <b>Il tabellone segna quello che scegli.</b>';
    left = 'RESTA<br>COM\'ERI';
    right = 'NUOVO TE<br>' + (d.extendDays || 7) + ' GIORNI';
    leftAct = 'decStrictNo()';
    rightAct = 'decStrictYes()';
  } else if (DEC.kind === 'strict'){
    kicker = 'La Modalità severa scade ' + (d.whenTxt || 'presto');
    title = 'PRENDI UNA DECISIONE';
    line = d.days ? 'Sei stato coerente per <b>' + d.days + (d.days === 1 ? ' giorno' : ' giorni') + '</b>. Adesso puoi lasciar cadere tutto, o rimetterci la firma.' : '';
    left = 'TORNA<br>COM\'ERI';
    right = 'CONTINUA<br>' + (d.extendDays || 30) + ' GIORNI';
    leftAct = 'decStrictNo()';
    rightAct = 'decStrictYes()';
  } else if (DEC.kind === 'rate'){
    kicker = 'Sei con noi da ' + (d.days || 0) + ' giorni';
    title = 'TI SERVE DREAMMAP?';
    line = 'Rispondere costa dieci secondi e decide cosa costruiamo dopo.';
    left = 'NON<br>MOLTO';
    right = 'MI STA<br>CAMBIANDO';
    leftAct = 'decRateNo()';
    rightAct = 'decRateYes()';
  } else if (DEC.kind === 'custom'){
    /* IL PANNELLO GENERICO. Le due schermate di sopra hanno le loro regole; tutto il resto —
       il primo passo dopo la chiamata dei sogni, le decisioni dell'agente — passa da qui con
       gli stessi angoli, la stessa scansione, le stesse due scelte. `extra` e' un pezzo in
       piu' (la «i» per farsi scomporre la task, il conto alla rovescia). */
    kicker = d.kicker || ''; title = d.title || ''; line = d.line || '';
    left = d.left || 'NO'; right = d.right || 'S\u00cc';
    leftAct = d.leftAct || 'decClose()'; rightAct = d.rightAct || 'decClose()';
  } else return;

  el.innerHTML =
      '<div class="dec-scrim"></div>'
    + '<div class="dec-holo">'
    +   '<div class="dec-frame">'
    +     '<span class="dec-c tl"></span><span class="dec-c tr"></span><span class="dec-c bl"></span><span class="dec-c br"></span>'
    +     '<div class="dec-bar">' + Array.from({ length: 5 }).map(() => '<i></i>').join('') + '</div>'
    +     '<div class="dec-kick">' + esc(kicker) + '</div>'
    +     '<div class="dec-title">' + title + '</div>'
    +     (line ? '<p class="dec-line">' + line + '</p>' : '')
    +     '<div class="dec-opts">'
    +       '<button type="button" class="dec-opt ' + (d.leftClass || 'no') + '" onclick="' + leftAct + '">' + left + '</button>'
    +       '<button type="button" class="dec-opt yes" onclick="' + rightAct + '">' + right + '</button>'
    +     '</div>'
    +     (d.extra || '')
    +     (d.foot === '' ? '' : '<div class="dec-foot">' + esc(d.foot || 'Siamo ciò che facciamo ripetutamente.') + '</div>')
    +   '</div>'
    + '</div>';
}
/** L'esito, con dei pulsanti propri (html gia' pronto) al posto del solo «Chiudi». */
function decResultCon(html, pts, good, bottoni, kicker){
  const el = document.getElementById('decWrap');
  if (!el) return;
  el.innerHTML = '<div class="dec-scrim"></div><div class="dec-holo"><div class="dec-frame">'
    + '<div class="dec-kick">' + esc(kicker || 'Registrato') + '</div>'
    + (pts === null || pts === undefined ? '' : '<div class="dec-pts ' + (good ? 'up' : 'down') + '">' + (pts >= 0 ? '+' : '') + pts + '</div>')
    + '<p class="dec-line">' + html + '</p>'
    + '<div class="dec-opts' + (bottoni.length === 1 ? ' one' : '') + '">' + bottoni.join('') + '</div>'
    + '</div></div>';
}

/* ---------- l'esito della decisione ---------- */
function decResult(html, pts, good){
  const el = document.getElementById('decWrap');
  if (!el) return;
  el.innerHTML = '<div class="dec-scrim"></div><div class="dec-holo"><div class="dec-frame">'
    + '<div class="dec-kick">' + (good ? 'Registrato' : 'Registrato') + '</div>'
    + '<div class="dec-pts ' + (good ? 'up' : 'down') + '">' + (pts >= 0 ? '+' : '') + pts + '</div>'
    + '<p class="dec-line">' + html + '</p>'
    + '<div class="dec-opts one"><button type="button" class="dec-opt yes" onclick="decClose()">CHIUDI</button></div>'
    + '</div></div>';
}

/* ---------- Modalità severa in scadenza ---------- */
/* 60 e non 300. Resta la scelta che pesa di piu' in un giorno solo, ma una scelta sola non
   puo' valere tre settimane di blocchi: con 300 punti un «si'» faceva salire di dieci
   livelli in un tocco, e apriva cose che andavano guadagnate. */
const DEC_STRICT_PTS = 60;
const DEC_STRICT_LOSS = -30;

async function decStrictYes(){
  const d = DEC.data || {};
  const days = d.extendDays || 30;
  if (d.tour){
    /* La scelta È l'azione: vale il voto e il punto, come alla scadenza. La Modalità severa
       vera si accende dalla scheda Blocco (livello, metodo, protezioni): qui si firma
       l'intenzione, e resta scritta. */
    decVote('strict', true, DEC_STRICT_PTS);
    let inPartita = false;
    try{ inPartita = (typeof mgFocusPoint === 'function') && mgFocusPoint('La prima scelta: nuovo te, Modalità severa per ' + days + ' giorni', true); }catch(_){ }
    try{ localStorage.setItem('fl_sev_promessa', JSON.stringify({ days: days, at: Date.now() })); }catch(_){ }
    DEC.last = { kind: 'strict', yes: true, tour: true };
    decResult('Hai scelto il nuovo te per <b>' + days + ' giorni</b>.' + (inPartita ? '<br><b>+1 al nuovo te</b> sul tabellone della partita.' : '') + '<br>La firma vera la metti nella scheda Blocco → Modalità severa.', DEC_STRICT_PTS, true);
    return;
  }
  if (d.preview){ decResult('Così apparirà. In quel momento la scelta varrà <b>+' + DEC_STRICT_PTS + '</b> punti, <b>+1 al nuovo te</b> sul tabellone, e prorogherà la Modalità severa di ' + days + ' giorni.', DEC_STRICT_PTS, true); return; }
  /* Prorogare non e' "allentare": il motore rifiuta una scadenza piu' vicina mentre la sessione
     e' chiusa a chiave, ma una piu' lontana la accetta. Quindi basta setStrictConfig. */
  let ok = false;
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setStrictConfig){
    try{
      const st = await NATIVE.getStrictState();
      const base = Math.max(Date.now(), (st && st.strictUntil) || 0);
      const r = await NATIVE.setStrictConfig({ strictUntil: base + days * 86400000 });
      ok = r !== false;
    }catch(_){ ok = false; }
  }
  decVote('strict', true, DEC_STRICT_PTS);
  /* E UN PUNTO SUL TABELLONE.
     Le persone che riescono decidono in fretta e cambiano idea lentamente; le altre ci
     mettono settimane a decidere e disfano tutto alla prima difficolta'. Confermare alla
     scadenza, nel momento esatto in cui si potrebbe andar via senza spiegazioni, e' il
     paradigma tenuto: non e' un'impostazione toccata, e' uno scambio vinto contro il
     vecchio te. Il punto lo prende il nuovo te, con la prova in mano — la prova e' la
     scelta stessa, quindi l'arbitro non deve chiedere una sessione di concentrazione. */
  let inPartita = false;
  try{ inPartita = (typeof mgFocusPoint === 'function')
    && mgFocusPoint('Modalità severa confermata alla scadenza', true); }catch(_){ }
  try{ localStorage.setItem('fl_strict_asked', String(Date.now())); }catch(_){ }
  /* IL PUNTO SI DICE ANCHE QUANDO IL MOTORE FA CILECCA: e' stato dato lo stesso, perche' a
     prenderlo e' la decisione, non la proroga. Tacerlo nel ramo storto vorrebbe dire far
     trovare il tabellone cambiato senza aver detto da dove arriva quel punto. */
  const nota = inPartita ? '<br><b>+1 al nuovo te</b> sul tabellone della partita.' : '';
  decResult((ok
    ? 'Hai firmato per altri <b>' + days + ' giorni</b>. La persona che vuoi diventare è appena diventata un po\' più vera.'
    : 'Il voto è registrato, ma il motore non ha preso la proroga: aprila dalla scheda Nuovo te.') + nota, DEC_STRICT_PTS, true);
  if (typeof sevSyncTab === 'function') setTimeout(sevSyncTab, 400);
}
function decStrictNo(){
  if ((DEC.data || {}).tour){
    decVote('strict', false, DEC_STRICT_LOSS);
    let suo = false;
    try{ suo = (typeof mgOldPoint === 'function') && mgOldPoint('La prima scelta: sei rimasto com\'eri'); }catch(_){ }
    DEC.last = { kind: 'strict', yes: false, tour: true };
    decResult('Sei rimasto com\'eri.' + (suo ? '<br><b>+1 al vecchio te</b> sul tabellone della partita.' : '') + '<br>Nessun giudizio: le scelte contano in tutte e due le direzioni, e la prossima è ancora tua.', DEC_STRICT_LOSS, false);
    return;
  }
  if ((DEC.data || {}).preview){ decResult('Così apparirà. In quel momento rifiutare costerebbe <b>' + DEC_STRICT_LOSS + '</b> punti e lascerebbe scadere la Modalità severa.', DEC_STRICT_LOSS, false); return; }
  decVote('strict', false, DEC_STRICT_LOSS);
  try{ localStorage.setItem('fl_strict_asked', String(Date.now())); }catch(_){ }
  decResult('Alla scadenza i blocchi tornano negoziabili. Nessun giudizio: è una scelta, e le scelte contano in tutte e due le direzioni.', DEC_STRICT_LOSS, false);
}

/* Quanto manca alla scadenza, e se è il momento di chiedere. */
async function decStrictCheck(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getStrictState) return;
  let cfg = {};
  try{ cfg = JSON.parse(localStorage.getItem('fl_strict_cfg') || '{}') || {}; }catch(_){ }
  if (cfg.ask === false) return;
  let s = null;
  try{ s = await NATIVE.getStrictState(); }catch(_){ return; }
  if (!s || !(s.level >= 1) || !s.strictUntil) return;
  const left = s.strictUntil - Date.now();
  const window = (cfg.askHours || 24) * 3600000;
  /* 0.9.310, Andrea: un timer di 1 minuto e' diventato un mese. La domanda parte solo per sessioni di almeno due
     giorni e nell'ultimo quarto (DecisionNotice.vaChiesto), e la proroga non supera la durata della sessione. */
  let inizio = +s.armedAt || 0;
  if (!inizio){ try{ const x = JSON.parse(localStorage.getItem('fl_sev_inizio') || 'null'); if (x && x.until === s.strictUntil) inizio = +x.start || 0; }catch(_){ } }
  const durata = inizio ? s.strictUntil - inizio : 0;
  if (durata < 48 * 3600000 || left <= 0 || left > Math.min(window, durata / 4)) return;
  let asked = 0;
  try{ asked = +localStorage.getItem('fl_strict_asked') || 0; }catch(_){ }
  if (Date.now() - asked < 20 * 3600000) return;      // una volta al giorno, non di più
  const h = Math.max(1, Math.round(left / 3600000));
  let days = 0;
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (st && st.start && typeof blkDaysBetween === 'function') days = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
  }catch(_){ }
  decOpen('strict', { whenTxt: h <= 1 ? 'fra meno di un\'ora' : 'fra ' + h + ' ore', days: days,
    extendDays: Math.max(1, Math.min(cfg.extendDays || 30, Math.round(durata / 86400000))), foot: 'Ogni volta che scegli contro, quella versione di te si smagrisce.' });
}

/* ---------- ti serve FocusLock? ---------- */
function decRateYes(){
  decVote('rate', true, 60);
  try{ localStorage.setItem('fl_rated', '1'); }catch(_){ }
  const el = document.getElementById('decWrap');
  el.innerHTML = '<div class="dec-scrim"></div><div class="dec-holo"><div class="dec-frame">'
    + '<div class="dec-kick">Allora serve una mano</div>'
    + '<div class="dec-title" style="font-size:26px">DILLO A CHI<br>NE HA BISOGNO</div>'
    + '<p class="dec-line">Una recensione sul Play Store fa arrivare DreamMap a chi sta perdendo le stesse ore che stavi perdendo tu. Ci vogliono venti secondi.</p>'
    + '<div class="dec-opts"><button type="button" class="dec-opt no" onclick="decClose()">PIÙ TARDI</button>'
    + '<button type="button" class="dec-opt yes" onclick="decReview()">VALUTA<br>ADESSO</button></div>'
    + '</div></div>';
}
function decRateNo(){
  decVote('rate', false, 0);
  try{ localStorage.setItem('fl_rated', '1'); }catch(_){ }
  const el = document.getElementById('decWrap');
  el.innerHTML = '<div class="dec-scrim"></div><div class="dec-holo"><div class="dec-frame">'
    + '<div class="dec-kick">Va bene così</div>'
    + '<div class="dec-title" style="font-size:26px">DIMMI<br>COSA MANCA</div>'
    + '<p class="dec-line">Preferisco saperlo adesso che leggerlo fra sei mesi in una recensione a una stella.</p>'
    + '<div class="dec-opts"><button type="button" class="dec-opt no" onclick="decClose()">LASCIA STARE</button>'
    + '<button type="button" class="dec-opt yes" onclick="decFeedback()">SCRIVIMI</button></div>'
    + '</div></div>';
}
/* LE STELLE SENZA USCIRE DALL'APP (0.9.203): il foglio di Google Play si apre qui dentro, come
   su Duolingo. Se il telefono non lo ha (fuori dal Play Store), si va alla pagina dello store. */
async function decReview(){
  decClose();
  try{
    if (NATIVE && typeof NATIVE.inAppReview === 'function'){ const r = await NATIVE.inAppReview(); if (r && r.ok) return; }
  }catch(_){ }
  decStore();
}
function decStore(){
  decClose();
  const url = 'https://play.google.com/store/apps/details?id=com.dreambrothers.focuslock';
  try{ if (NATIVE && NATIVE.openUrl) { NATIVE.openUrl({ url: url }); return; } }catch(_){ }
  try{ window.open(url, '_blank'); }catch(_){ }
}
function decFeedback(){
  decClose();
  if (typeof drawerGo === 'function'){ drawerGo('s-help'); return; }
  try{ window.open('mailto:info@dream-brothers.com?subject=DreamMap', '_blank'); }catch(_){ }
}

/* Quando chiedere: lo decidiamo noi, non l'utente. Dopo dieci giorni dall'installazione e
   solo a chi la sta usando davvero — chi ha almeno un blocco attivo e qualche giorno alle
   spalle. Chiederlo al primo avvio è il modo migliore per prendersi una stella. */
function decRateCheck(){
  try{
    if (localStorage.getItem('fl_rated') === '1') return;
    /* Una lettura sola per tutta l'app, e da adesso si scrive solo l'ISO: era proprio questa
       riga a mettere in giro il formato numerico che gli altri moduli non sapevano leggere. */
    const first = flPrimoAvvio();
    if (!first){ flPrimoAvvioSegna(); return; }
    const days = Math.floor((Date.now() - first) / 86400000);
    if (days < 10) return;
    let used = false;
    try{
      const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
      const ff = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
      used = !!st || ff.length >= 3 || (typeof PROGRAMS !== 'undefined' && PROGRAMS && PROGRAMS.length > 0);
    }catch(_){ }
    if (!used) return;
    decOpen('rate', { days: days, foot: 'Rispondere è già una scelta su chi vuoi essere.' });
  }catch(_){ }
}

/* Chi ha toccato la notifica arriva qui: la decisione si apre subito, senza aspettare il giro
   della scheda. Il flag si consuma una volta sola, come per la chiamata dei sogni. */
async function decFromNotice(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.consumeDecision) return;
  try{
    const r = await NATIVE.consumeDecision();
    if (r && r.kind === 'strict'){
      try{ localStorage.removeItem('fl_strict_asked'); }catch(_){ }
      decStrictCheck();
    }
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) decFromNotice(); });
setTimeout(decFromNotice, 1400);

/* All'apertura della scheda: prima la scadenza (urgente), poi la domanda sull'app. */
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'severa' && e.detail !== 'blocco') return;
  setTimeout(function(){
    if (DEC.open) return;
    decStrictCheck().then(function(){ if (!DEC.open) setTimeout(decRateCheck, 1200); });
  }, 1500);
});

registerOverlay('decWrap', '');
(function(){ const el = document.getElementById('decWrap'); if (el) el.hidden = true; })();

(function(){
  const css = [
    '#decWrap[hidden]{display:none}',
    '#decWrap{position:absolute;inset:0;z-index:90;display:flex;align-items:center;justify-content:center}',
    '.dec-scrim{position:absolute;inset:0;background:radial-gradient(120% 80% at 50% 50%,rgba(4,18,38,.86),rgba(2,8,18,.97))}',
    /* il pannello: un terminale che galleggia, non una finestra di sistema */
    '.dec-holo{position:relative;width:min(92%,420px);animation:decIn .5s cubic-bezier(.2,.8,.3,1) both}',
    'body.dec-full .dec-holo{width:100%;height:100%;display:flex;align-items:stretch;justify-content:center;animation:none}body.dec-full .dec-frame{width:100%;border:0;border-radius:0;background:transparent;box-shadow:none;display:flex;flex-direction:column;justify-content:center;padding:48px 28px}body.dec-full .dec-c{width:22px;height:22px}body.dec-full .dec-c.tl,body.dec-full .dec-c.tr{top:18px}body.dec-full .dec-c.bl,body.dec-full .dec-c.br{bottom:18px}body.dec-full .dec-c.tl,body.dec-full .dec-c.bl{left:18px}body.dec-full .dec-c.tr,body.dec-full .dec-c.br{right:18px}',
    '@keyframes decIn{from{opacity:0;transform:translateY(18px) scale(.96)}to{opacity:1;transform:none}}',
    '.dec-frame{position:relative;padding:30px 24px 24px;border:1px solid rgba(90,200,255,.55);border-radius:6px;',
    '  background:linear-gradient(180deg,rgba(10,42,74,.55),rgba(6,24,46,.75));',
    '  box-shadow:0 0 0 1px rgba(90,200,255,.15) inset,0 0 40px rgba(40,160,255,.28),0 0 90px rgba(20,90,180,.25);',
    '  text-align:center;overflow:hidden}',
    /* la scansione che passa, lentissima */
    '.dec-frame::after{content:"";position:absolute;left:0;right:0;height:38%;top:-38%;pointer-events:none;',
    '  background:linear-gradient(180deg,rgba(140,225,255,0),rgba(140,225,255,.10),rgba(140,225,255,0));animation:decScan 4.5s linear infinite}',
    '@keyframes decScan{to{top:110%}}',
    /* gli angoli, come su un mirino */
    '.dec-c{position:absolute;width:16px;height:16px;border:2px solid rgba(120,215,255,.95)}',
    '.dec-c.tl{top:8px;left:8px;border-right:0;border-bottom:0}',
    '.dec-c.tr{top:8px;right:8px;border-left:0;border-bottom:0}',
    '.dec-c.bl{bottom:8px;left:8px;border-right:0;border-top:0}',
    '.dec-c.br{bottom:8px;right:8px;border-left:0;border-top:0}',
    '.dec-bar{display:flex;gap:4px;justify-content:center;margin-bottom:18px}',
    '.dec-bar i{width:16px;height:6px;background:rgba(120,215,255,.5);animation:decBlink 1.8s ease-in-out infinite}',
    '.dec-bar i:nth-child(2){animation-delay:.2s}.dec-bar i:nth-child(3){animation-delay:.4s}',
    '.dec-bar i:nth-child(4){animation-delay:.6s}.dec-bar i:nth-child(5){animation-delay:.8s}',
    '@keyframes decBlink{0%,100%{opacity:.25}50%{opacity:1}}',
    '.dec-kick{font:700 10.5px var(--font-body);letter-spacing:.22em;text-transform:uppercase;color:rgba(150,225,255,.85)}',
    '.dec-title{margin-top:14px;font:800 32px/1.05 var(--font-body);letter-spacing:.04em;color:#EAF6FF;text-shadow:0 0 18px rgba(90,200,255,.7)}',
    '.dec-line{margin:16px auto 0;max-width:26em;font:500 13.5px/1.65 var(--font-body);color:rgba(226,243,255,.82)}',
    '.dec-line b{color:#EAF6FF;font-weight:800}',
    '.dec-opts{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:26px}',
    '.dec-opts.one{grid-template-columns:1fr}',
    '.dec-opt{border:1px solid rgba(120,215,255,.6);background:rgba(12,48,84,.5);color:#DCF1FF;padding:16px 10px;',
    '  font:800 14px/1.25 var(--font-body);letter-spacing:.06em;cursor:pointer;border-radius:3px;transition:.18s}',
    '.dec-opt:active{transform:translateY(2px)}',
    '.dec-opt.yes{border-color:rgba(140,240,200,.9);background:rgba(14,90,74,.5);color:#D6FFF0;box-shadow:0 0 22px rgba(40,220,170,.28)}',
    '.dec-opt.no{border-color:rgba(255,120,140,.55);color:#FFD8DE;background:rgba(70,16,28,.42)}',
    '.dec-foot{margin-top:18px;font:600 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:rgba(150,225,255,.5)}',
    '.dec-pts{margin:10px 0 4px;font:800 58px/1 var(--font-display);font-style:italic}',
    '.dec-pts.up{color:#8CF0C8;text-shadow:0 0 26px rgba(60,230,180,.5)}',
    '.dec-pts.down{color:#FF8A9B;text-shadow:0 0 26px rgba(240,80,110,.45)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
