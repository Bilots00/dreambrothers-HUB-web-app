/* boot.js — la schermata di caricamento.

   COSA RISOLVE.
   All'avvio si vedeva una pagina bianca, a volte per parecchi secondi, e spesso spariva solo
   toccando lo schermo: segno che la pagina era già pronta e la WebView non aveva ancora
   disegnato niente. Nel frattempo, anche quando il bianco non c'era, la scheda Blocco compariva
   vuota — nessuna parola chiave, nessuna app, il pulsante "Inizia" al posto di "Stop" su un
   blocco rapido che era invece acceso — e il pannello del tempo di schermo arrivava dopo. Tutto
   questo perché quei dati li chiede il telefono e arrivano quando arrivano.

   LA SOLUZIONE è quella dei videogiochi: invece di nascondere l'attesa, la si occupa. Una
   schermata che c'è dal primo fotogramma (sta nell'HTML, non la crea nessuno script), una
   barra che avanza sui passi VERI del caricamento, e una frase diversa a ogni avvio. Chi
   aspetta tre secondi leggendo qualcosa che gli serve non ha aspettato: ha letto.

   TRE REGOLE, e valgono più della grafica:
   1. la barra dice la verità — avanza quando un pezzo è pronto davvero, non a tempo;
   2. c'è un tetto (5 secondi): una schermata di caricamento che non se ne va è peggio del
      bianco, perché il bianco almeno sembra un problema e non una scelta;
   3. all'uscita si forza il disegno, che è quello che il tocco faceva a mano. */

/* Le frasi. Brevi: chi aspetta non legge un poema, e una frase lunga la si salta.
   Sono di autori classici — di chi è morto da un pezzo e non ha editori da consultare — più
   qualche riga scritta qui. Niente citazioni di autori viventi: in un'app pubblicata quelle
   sono un problema legale, non una scelta di stile. */
const BOOT_LINES = [
  ['Ricorda che non ottenere ciò che vuoi a volte è un meraviglioso colpo di fortuna.', 'Dalai Lama'],
  ['Ogni progresso avviene fuori dalla zona di comfort.', 'Michael John Bobak'],
  /* L'unica di un autore vivente, e ci sta per scelta di Andrea: e' un aforisma di due righe
     citato ovunque, e dice in una frase quello che fa tutta questa app — il piano batte il
     talento. Da tenere presente solo prima della pubblicazione sullo store, dove le citazioni
     di autori viventi vanno verificate una per una. */
  ['Un idiota con un piano può battere un genio senza un piano.', 'Warren Buffett'],
  /* scelte da Andrea (7/10/2026) */
  ['Se domani non dovesse esserci, faresti comunque quello che stai per fare oggi? Se la risposta è no, sei vivo, ma non stai vivendo.', 'Greg Plitt'],
  ['Ogni momento è un nuovo momento. Hai pagato per quello che eri ieri. Quello che sei oggi lo decidi tu.', 'Raymond Douglas Stanford'],
  ['Fai come Napoleone: vedi solo l’obiettivo. L’ostacolo dovrà spostarsi.', 'Bob Proctor'],
  ['Cosa proveresti a fare, se sapessi di non poter fallire?', 'Robert H. Schuller'],
  ['Cosa sogneresti, se sapessi di non poter fallire? Un sogno piccolo costa la stessa fatica di uno grande.', 'Orrin Woodward'],
  /* scelte da Andrea (19/10/2026): sono anche frasi del giorno (scores.js, SC_SCELTE) */
  ['Il successo è andare da un fallimento all’altro senza perdere l’entusiasmo.', 'Winston Churchill'],
  ['Siamo ciò che facciamo ripetutamente; l’eccellenza, quindi, non è un atto, ma un’abitudine.', 'Will Durant'],
  ['Non abbiamo poco tempo: ne perdiamo molto.', 'Seneca'],
  ['Mentre si rimanda, la vita passa.', 'Seneca'],
  ['Nessuno ti restituirà gli anni. Nessuno ti renderà a te stesso.', 'Seneca'],
  ['Non è che abbiamo poco tempo: è che ne sprechiamo molto.', 'Seneca'],
  ['Comincia. Il coraggio ha in sé genio e potere.', 'Goethe'],
  ['Le cose che contano di più non devono mai cedere a quelle che contano di meno.', 'Goethe'],
  ['Non rimandare a domani quello che puoi fare oggi.', 'Benjamin Franklin'],
  ['Il tempo perduto non si ritrova mai più.', 'Benjamin Franklin'],
  ['Ama la vita? Allora non sprecare il tempo: è la stoffa di cui è fatta.', 'Benjamin Franklin'],
  ['Chi insegue due conigli non ne prende nessuno.', 'Proverbio'],
  ['Un viaggio di mille miglia comincia con un passo.', 'Lao Tzu'],
  ['La natura non ha fretta, eppure tutto si compie.', 'Lao Tzu'],
  ['Non importa quanto vai piano, purché tu non ti fermi.', 'Confucio'],
  ['Il momento migliore per piantare un albero era vent’anni fa. Il secondo è adesso.', 'Proverbio'],
  ['La conoscenza non basta: bisogna applicarla. Volere non basta: bisogna fare.', 'Bruce Lee'],
  ['Chi è dappertutto non è in nessun posto.', 'Seneca'],
  ['Vivi come se dovessi morire domani. Impara come se dovessi vivere per sempre.', 'Gandhi'],
  ['Prima fai il necessario, poi il possibile: e all’improvviso stai facendo l’impossibile.', 'Francesco d’Assisi'],
  ['La disciplina è il ponte fra i sogni e i risultati.', 'Proverbio'],
  ['Se conosci il nemico e conosci te stesso, non temere il risultato di cento battaglie.', 'Sun Tzu'],
  ['Le occasioni si moltiplicano quando vengono colte.', 'Sun Tzu'],
  ['La fortuna è ciò che succede quando la preparazione incontra l’occasione.', 'Seneca'],
  ['Ogni cosa ha due manici: da uno si può portare, dall’altro no.', 'Epitteto'],
  ['Non sono le cose a turbarci, ma le opinioni che ne abbiamo.', 'Epitteto'],
  ['Conosci te stesso.', 'Socrate'],
  ['La vita non esaminata non è degna di essere vissuta.', 'Socrate'],
  ['Fai ogni cosa come se fosse l’ultima della tua vita.', 'Marco Aurelio'],
  ['Hai potere sulla tua mente, non sugli eventi. Rendendotene conto, troverai la forza.', 'Marco Aurelio'],
  ['Smettila di discutere su cosa sia un uomo buono: siilo.', 'Marco Aurelio'],
  ['L’ostacolo alla via diventa la via.', 'Marco Aurelio'],
  ['Chi ha un perché abbastanza forte sopporta quasi ogni come.', 'Nietzsche'],
  ['Chi guarda fuori sogna, chi guarda dentro si sveglia.', 'Carl Gustav Jung'],
  ['La perfezione si raggiunge quando non c’è più niente da togliere.', 'Antoine de Saint-Exupéry'],
  ['Un obiettivo senza un piano è solo un desiderio.', 'Antoine de Saint-Exupéry'],
  ['Le persone di successo prendono decisioni prontamente e le cambiano lentamente, se mai le cambiano.', 'Napoleon Hill'],
  /* 0.9.335, Andrea: simmetria, due righe gemelle con la virgola, non "e" in mezzo */
  ['La paura dice "E se...",\nla fede dice "Anche se..."', ''],
  ['Concentrarsi vuol dire saper dire di no.', 'Steve Jobs', 'Focus is about saying no.'],
  ['Il genio è un per cento ispirazione e novantanove per cento sudore.', 'Thomas Edison'],
  ['Non ho fallito. Ho solo trovato diecimila modi che non funzionano.', 'Thomas Edison'],
  ['Se il tuo domani sarà uguale a quello di ieri, avrai vissuto un giorno solo.', 'Gianluca Liguori'],
  ['La felicità è quando ciò che pensi, ciò che dici e ciò che fai sono in armonia.', 'Mahatma Gandhi'],
  ['L’unico modo di fare un gran lavoro è amare quello che fai.', 'Proverbio'],
  ['Fatto è meglio di perfetto.', 'Proverbio'],
  ['Chi vuole fare qualcosa trova un modo. Chi non vuole trova una scusa.', 'Proverbio arabo'],
  ['La goccia scava la pietra non con la forza, ma cadendo spesso.', 'Ovidio'],
  /* scelte da Andrea (22/10/2026): le brevi anche qui, le altre solo come frasi del giorno (scores.js, SC_SCELTE).
     Il terzo elemento e' l'originale inglese, per chi usa il telefono in inglese. */
  ['Tutto quello che non stai cambiando, lo stai scegliendo.', 'Laurie Buchanan', 'Whatever you are not changing, you are choosing.'],
  ['Noi siamo quello che scegliamo di essere. Ora scegli!', 'Green Goblin', 'We are who we choose to be. Now choose!'],
  ['La vita si restringe o si espande in proporzione al proprio coraggio.', 'Anaïs Nin', 'Life shrinks or expands in proportion to one\u2019s courage.'],
  ['Tutto ciò che hai sempre voluto è dall’altra parte della paura.', 'George Addair', 'Everything you\u2019ve ever wanted is on the other side of fear.'],
  ['L’unico limite a ciò che realizzeremo domani saranno i nostri dubbi di oggi.', 'Franklin D. Roosevelt', 'The only limit to our realization of tomorrow will be our doubts of today.'],
  ['Ogni battaglia viene vinta o persa prima ancora di essere combattuta.', 'Sun Tzu', 'Every battle is won or lost before it is ever fought.'],
  ['Non ci sono limiti. Ci sono solo plateau: non devi restarci, devi andare oltre.', 'Bruce Lee', 'There are no limits. There are only plateaus, and you must not stay there, you must go beyond them.'],
  ['Presto e bene raramente vanno insieme.', 'Proverbio'],
  ['Sono un vecchio e ho avuto molti guai, la maggior parte dei quali non è mai accaduta.', 'Mark Twain'],
  ['Il segreto per andare avanti è cominciare.', 'Mark Twain'],
  ['Fra vent’anni sarai più deluso per le cose che non hai fatto che per quelle che hai fatto.', 'Mark Twain'],
  ['Chi rimanda l’ora di vivere bene è come il contadino che aspetta che il fiume finisca.', 'Orazio'],
  ['Cogli l’attimo, fidandoti il meno possibile del domani.', 'Orazio'],
  ['Il tempo è la moneta della tua vita. Spendila tu, o la spenderanno altri per te.', 'Carl Sandburg'],
  ['Due cose sono infinite: l’universo e la distrazione. E dell’universo non sono sicuro.', 'DreamMap'],
  ['Il telefono non ruba tempo. Lo chiede, e noi diciamo di sì.', 'DreamMap'],
  ['Una cosa alla volta. È tutto qui il segreto.', 'DreamMap'],
  ['Non devi vincere la giornata. Devi vincere la prossima ora.', 'DreamMap'],
  ['Quello che rimandi oggi lo pagherai domani, con gli interessi.', 'DreamMap'],
  ['Il lavoro si allarga fino a riempire il tempo che gli lasci.', 'Cyril N. Parkinson'],
  ['La concentrazione non è un talento. È una cosa che si allena.', 'DreamMap'],
  ['Chi controlla la sua attenzione controlla la sua vita.', 'DreamMap'],
  ['Il momento in cui non hai voglia è il momento che conta.', 'DreamMap'],
  ['Ogni notifica è una domanda. Non sei obbligato a rispondere.', 'DreamMap'],
  /* 0.9.343, Andrea */
  ['Quando cominci a camminare sulla via, la via appare.', 'Rumi'],
  ['La calma non è assenza di rumore: è sapere cosa stai facendo.', 'DreamMap']
];

const BOOT = { el: null, bar: null, pct: 0, shown: 0, done: false, timer: 0 };

/* Il passo avanti della barra. Non va mai indietro, non salta: arriva dove deve arrivare
   scorrendo, perché una barra che salta al 90% e resta lì sembra bloccata. */
function bootTo(p){
  BOOT.pct = Math.max(BOOT.pct, Math.min(1, p));
}

function bootPaint(){
  if (!BOOT.bar) return;
  /* si avvicina al valore vero di un quinto per fotogramma: morbido, e mai fermo del tutto */
  BOOT.shown += (BOOT.pct - BOOT.shown) * 0.2;
  if (BOOT.pct - BOOT.shown < 0.004) BOOT.shown = BOOT.pct;
  BOOT.bar.style.width = Math.round(BOOT.shown * 100) + '%';
  if (!BOOT.done) requestAnimationFrame(bootPaint);
}

function bootStart(){
  BOOT.el = document.getElementById('boot');
  if (!BOOT.el) return;
  BOOT.bar = document.getElementById('bootBar');
  const q = BOOT_LINES[Math.floor(Math.random() * BOOT_LINES.length)];
  const t = document.getElementById('bootQuote');
  const a = document.getElementById('bootWho');
  /* le virgolette normali (regola di Andrea), e l'originale inglese per chi ha il telefono in inglese */
  const en = q[2] && typeof flLingua === 'function' && flLingua() === 'en';
  /* una frase che ha gia' le sue virgolette dentro non ne prende altre; l'a capo resta a capo */
  if (t){ const f = en ? q[2] : q[0]; t.style.whiteSpace = 'pre-line'; t.textContent = f.indexOf('"') >= 0 ? f : '"' + f + '"'; }
  if (a) a.textContent = q[1];
  bootTo(0.12);
  requestAnimationFrame(bootPaint);
  /* IL PASSAGGIO DI CONSEGNE.

     Sopra a tutto c'e' ancora la schermata di avvio di Android — il lucchetto su fondo blu —
     e finche' c'e' quella, questa non la vede nessuno. La si toglie appena la frase e' stata
     disegnata davvero (due fotogrammi: uno per applicare il testo, uno per comporlo), non
     quando i dati sono pronti: da li' in poi ad aspettare ci pensa questa schermata, che
     almeno ha qualcosa da dire. */
  requestAnimationFrame(function(){ requestAnimationFrame(bootHandoff); });
  /* Il tetto: oltre i cinque secondi si entra comunque. Meglio una scheda che si completa
     sotto gli occhi che una porta chiusa. */
  BOOT.timer = setTimeout(bootDone, 5000);
}

/* Il ponte verso la schermata di avvio di Android.

   NATIVE non esiste ancora quando questo file parte: il ponte con il telefono lo costruisce
   js/native.js, che viene caricato dopo. Quindi si riprova, per qualche secondo: appena c'e',
   si dice al telefono che puo' togliere il lucchetto e lasciare il posto a questa schermata.
   Se non arriva mai (siamo in un browser) non succede niente di male. */
function bootHandoff(){
  let tries = 0;
  const go = function(){
    try{
      if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.appReady){ NATIVE.appReady(); return; }
    }catch(_){ }
    if (++tries < 50) setTimeout(go, 60);
  };
  go();
}

/* Chiamata da nav.js quando i pezzi veri sono pronti. */
function bootDone(){
  if (BOOT.done) return;
  BOOT.done = true;
  clearTimeout(BOOT.timer);
  bootTo(1);
  if (BOOT.bar) BOOT.bar.style.width = '100%';
  const el = BOOT.el || document.getElementById('boot');
  if (!el) return;
  el.classList.add('gone');
  setTimeout(function(){
    try{ el.remove(); }catch(_){ }
    bootRepaint();
  }, 420);
}

/* LA SPINTA AL DISEGNO.

   È la parte che risolve il bianco che spariva al tocco. Su questa WebView capita che il
   primo fotogramma dopo l'avvio non venga composto finché non arriva un evento: la pagina
   c'è, è completa, e non si vede. Toccare lo schermo la faceva comparire — cioè il tocco
   faceva da sveglia. Qui la sveglia la diamo noi: si tocca una proprietà che obbliga a
   ricomporre il livello, e si rilascia al fotogramma dopo. */
function bootRepaint(){
  const ph = document.getElementById('phone');
  if (!ph) return;
  try{
    ph.style.transform = 'translateZ(0)';
    void ph.offsetHeight;
    requestAnimationFrame(function(){
      ph.style.transform = '';
      void ph.offsetHeight;
      try{ window.scrollTo(0, 0); }catch(_){ }
    });
  }catch(_){ }
}

bootStart();

/* Lo stile di questa schermata sta nella TESTA di index.html, non qui: uno script in fondo
   alla pagina puo' arrivare dopo il primo fotogramma, e una schermata di caricamento che per
   un istante appare senza stile e' peggio di non averla. */
