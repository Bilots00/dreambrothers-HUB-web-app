/* =========================================================================================
   IL GIOCO CHE TIENE INCOLLATI AL SOGNO (0.9.283)

   Andrea, 18/10: le leve dei casino' e dei social, usate a fin di bene.
   1. LA SCOMMESSA D'ONORE. 0.9.310: e' un EVENTO RARO della storia, non un passaggio di ogni Full
      Focus (gcEventoPronto): "Il Vecchio te ti sfida", poi "Il Vecchio te dice che oggi cederai".
      Punti delle monete; se finisci la sessione ne vinci il triplo, se molli le prende il Vecchio te.
      Annullare nei dieci secondi di ripensamento restituisce la posta.
   2. IL CONTO ALLA ROVESCIA. 0.9.310 (Andrea, 739): niente Genio e niente frasi da presentatore che
      arrivavano fuori tempo. Una riga che dice cos'e' ("Hai 10 secondi per ripensarci", con lo stesso
      numero che si vede grande), il razzo pronto a partire, Annulla.
   3. LA RIPROVA SOCIALE, SOLO VITTORIE VERE. Le vittorie degli altri (sessioni finite, idee nel
      caveau, arrivo anticipato, rompicapo risolti), prima di chi ha il tuo stesso obiettivo, in
      un nastro nella scheda Sogno e nella Lega. Mai nomi o vittorie inventate: se non ce ne
      sono, il nastro non compare.
   4. LA MYSTERY BOX DEL LAVORO VERO. Lo scrigno dopo il Full Focus c'era gia' (scrigni.js); in
      piu': una riga spuntata nel foglio di oggi puo' far uscire uno scrigno (al massimo due al
      giorno), e quando la serie di giorni cresce puo' arrivare un Bonus Drop (un distintivo
      raro o un messaggio del Genio che non si trova altrove). Le probabilita' si vedono.
   ========================================================================================= */
const GC = { ok: false, feed: [], i: 0, t: 0, giro: 0 };
function gcLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function gcScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function gcEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function gcOggi(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }

/* ---------- 1. la scommessa d'onore ---------- */
const GC_POSTE = [20, 50, 100];
/* 0.9.310, Andrea (738): "compare a ogni avvio di Full Focus: deve diventare un evento raro, come un momento della
   storia". LA REGOLA DELLA RARITA':
   - solo dopo almeno GC_EVENTO_SESSIONI sessioni di Full Focus portate a termine (prima si impara il Full Focus);
   - al massimo una volta ogni GC_EVENTO_GIORNI giorni (quindi mai due giorni di fila);
   - passata la settimana, ogni giorno si tira UNA volta il dado (GC_EVENTO_PROB): se esce, la sfida arriva alla prima
     sessione del giorno; se no, non si ritenta fino a domani. Cosi' non cade sempre lo stesso giorno della settimana
     e chi fa cinque sessioni al giorno non la vede di piu'.
   Il giorno in cui compare si segna in fl_gc_evento, anche se la si rifiuta. */
const GC_EVENTO_SESSIONI = 3, GC_EVENTO_GIORNI = 7, GC_EVENTO_PROB = 0.5;
function gcSessioniFinite(){
  try{ return ((typeof ffHist === 'function') ? ffHist() : []).filter(function(h){ return h && h.ok && !h.meditazione; }).length; }
  catch(_){ return 0; }
}
function gcEventoPronto(ora){
  ora = +ora || Date.now();
  if (gcSessioniFinite() < GC_EVENTO_SESSIONI) return false;
  const ultimo = +gcLeggi('fl_gc_evento', 0) || 0;
  if (ultimo && ora - ultimo < GC_EVENTO_GIORNI * 86400000) return false;
  const d = new Date(ora), g = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  const dado = gcLeggi('fl_gc_evento_dado', {});
  if (dado.g !== g){ dado.g = g; dado.si = Math.random() < GC_EVENTO_PROB; gcScrivi('fl_gc_evento_dado', dado); }
  return !!dado.si;
}
function gcChiediScommessa(){
  try{
    if (gcLeggi('fl_gc_noscommessa', false)) return false;
    const p = (typeof ffPref === 'function') ? ffPref() : {};
    if (p.tag === 'meditazione' || (+p.minutes || 0) < 15) return false;
    if ((typeof ffCoins === 'function' ? ffCoins() : 0) < GC_POSTE[0]) return false;
    return gcEventoPronto();
  }catch(_){ return false; }
}
/* L'evento: prima il momento della storia, poi la scommessa. Il giorno si segna appena compare. */
function gcEventoApri(){
  gcScrivi('fl_gc_evento', Date.now());
  ffSheetOpen('<div class="gc-sc gc-ev">'
    + '<div class="gc-sc-top">'
    +   '<button type="button" class="gc-sc-tondo" onclick="ffSheetClose()" aria-label="Chiudi">'
    +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '</div>'
    + '<small class="gc-ev-kick">Un evento raro della tua storia</small>'
    + '<span class="gc-sc-emo gc-ev-emo gc-sc-diavolo">\uD83D\uDE08</span>'
    + '<b class="gc-sc-tit gc-ev-tit">Il Vecchio te ti sfida</b>'
    + '<p class="gc-sc-p">Succede una volta ogni tanto, e oggi ha scelto proprio questa sessione.</p>'
    + '<button type="button" class="gc-sc-go" onclick="gcScommessaApri()">Vediamo la sfida</button>'
    + '<button type="button" class="gc-sc-no" onclick="gcParti(0)">Oggi non la accetto</button>'
    + '</div>');
}
/* 0.9.309, Andrea (721): "troppi pulsanti e tutto compresso". Il foglio adesso e' OEOF: il
   titolo, una frase, UN selettore della puntata (tre chip piccole), la riga "ne vinci" che si
   aggiorna, UN pulsante blu "Scommetto X" e sotto il link "Parto senza scommettere".
   "Non chiedermelo piu'" sta nei tre puntini. Il diavolo non e' piu' viola (brand): e' rosso. */
function gcScommessaApri(){
  const m = ffCoins(), min = (ffPref().minutes || 25);
  const ok = GC_POSTE.filter(function(n){ return n <= m; });
  GC.posta = ok.indexOf(50) >= 0 ? 50 : (ok[ok.length - 1] || GC_POSTE[0]);
  ffSheetOpen('<div class="gc-sc">'
    + '<div class="gc-sc-top">'
    +   '<button type="button" class="gc-sc-tondo" onclick="gcScMenu(event)" aria-label="Altre scelte">'
    +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="5" cy="12" r="2" fill="currentColor"/><circle cx="12" cy="12" r="2" fill="currentColor"/><circle cx="19" cy="12" r="2" fill="currentColor"/></svg></button>'
    +   '<button type="button" class="gc-sc-tondo" onclick="ffSheetClose()" aria-label="Chiudi">'
    +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '</div>'
    + '<div class="gc-sc-vs"><span class="gc-sc-emo gc-sc-diavolo">\uD83D\uDE08</span><i>VS</i><span class="gc-sc-emo">\uD83D\uDE80</span></div>'
    + '<b class="gc-sc-tit">Il Vecchio te dice che oggi cederai.</b>'
    + '<p class="gc-sc-p">Resta per tutti i ' + min + ' minuti e vinci <b>il triplo</b> di quello che punti. Se molli, le monete le prende lui.</p>'
    + '<p class="gc-sc-lab">Quanto punti? Ne hai ' + m + ' \uD83E\uDE99</p>'
    + '<div class="gc-sc-poste" role="radiogroup">' + GC_POSTE.map(function(n){
        return '<button type="button" role="radio" data-n="' + n + '" aria-checked="' + (n === GC.posta) + '"'
          + ' class="' + (n === GC.posta ? 'on' : '') + '"' + (m < n ? ' disabled' : '')
          + ' onclick="gcScPosta(' + n + ')">' + n + ' \uD83E\uDE99</button>';
      }).join('') + '</div>'
    + '<p class="gc-sc-vinci" id="gcScVinci">' + gcScVinciTesto(GC.posta) + '</p>'
    + '<button type="button" class="gc-sc-go" id="gcScGo" onclick="gcParti(GC.posta)">Scommetto ' + GC.posta + ' \uD83E\uDE99</button>'
    + '<button type="button" class="gc-sc-no" onclick="gcParti(0)">Parto senza scommettere</button>'
    + '</div>');
}
function gcScVinciTesto(n){ return 'Se resti fino alla fine ne vinci <b>' + (n * 3) + ' \uD83E\uDE99</b>'; }
function gcScPosta(n){
  if (n > ffCoins()) return;
  GC.posta = n;
  document.querySelectorAll('.gc-sc-poste button').forEach(function(b){
    const su = +b.dataset.n === n;
    b.classList.toggle('on', su);
    b.setAttribute('aria-checked', String(su));
  });
  const v = document.getElementById('gcScVinci'); if (v) v.innerHTML = gcScVinciTesto(n);
  const g = document.getElementById('gcScGo'); if (g) g.textContent = 'Scommetto ' + n + ' \uD83E\uDE99';
  try{ flVibra(6); }catch(_){ }
}
function gcScMenuVia(){
  const m = document.getElementById('gcScMenu'); if (m) m.remove();
  const v = document.getElementById('gcScVelo'); if (v) v.remove();
}
function gcScMenu(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('gcScMenu')){ gcScMenuVia(); return; }
  const sh = document.getElementById('ffSheet');
  if (!sh) return;
  const v = document.createElement('div');
  v.id = 'gcScVelo'; v.className = 'gc-sc-velo';
  v.addEventListener('click', function(e){ e.stopPropagation(); gcScMenuVia(); });
  const m = document.createElement('div');
  m.id = 'gcScMenu'; m.className = 'arb-menu gc-sc-menu';
  m.innerHTML = '<p class="arb-mtit">La scommessa</p>'
    + '<button type="button" onclick="gcScMenuVia();gcScrivi(\'fl_gc_noscommessa\',true);gcParti(0)">Non chiedermelo più</button>';
  sh.appendChild(v);
  sh.appendChild(m);
}
async function gcParti(posta){
  posta = Math.max(0, Math.min(+posta || 0, ffCoins()));
  if (posta) ffAddCoins(-posta);
  GC.ok = true;
  try{ await ffStart(); }finally{ GC.ok = false; }
  if (posta){
    if (typeof FF !== 'undefined' && FF.run){ FF.run.posta = posta; ffWrite('fl_ff_session', FF.run); try{ flVibra([10, 30, 10]); }catch(_){ } }
    else ffAddCoins(posta); /* la sessione non e' partita: la posta torna indietro */
  }
  gcLancioApri(posta);
}

/* ---------- 2. il conto alla rovescia nei dieci secondi di ripensamento ----------
   0.9.310, Andrea (739): "troppa roba, e il testo non e' sincronizzato". Prima c'erano il Genio, quattro frasi da
   presentatore che cambiavano ogni 2,6 secondi (e "Ultimi secondi per ripensarci" arrivava col numero gia' a 1), il
   razzo, il numero e Annulla. Adesso una riga sola che dice cos'e', scritta con LO STESSO numero che si vede grande
   (si ricalcolano insieme a ogni giro), il razzo pronto a partire e Annulla. */
function gcLancioSecondi(run){ return Math.max(0, Math.ceil((((run && run.graceUntil) || 0) - Date.now()) / 1000)); }
function gcLancioRiga(n){ return n <= 0 ? 'Si parte. Buon lavoro!' : (n === 1 ? 'Hai 1 secondo per ripensarci' : 'Hai ' + n + ' secondi per ripensarci'); }
function gcLancioApri(posta){
  const run = (typeof FF !== 'undefined') ? FF.run : null;
  if (!run || run.meditazione || !run.graceUntil || Date.now() >= run.graceUntil) return;
  gcLancioVia(true);
  const n0 = gcLancioSecondi(run);
  const el = document.createElement('div');
  el.id = 'gcLancio'; el.className = 'gc-lancio';
  el.innerHTML = '<div class="gc-l-stelle"></div>'
    + '<p class="gc-l-frase" id="gcLFrase">' + gcEsc(gcLancioRiga(n0)) + '</p>'
    + '<b class="gc-l-n" id="gcLN">' + n0 + '</b>'
    + '<div class="gc-l-base"><span class="gc-l-razzo" aria-hidden="true">\uD83D\uDE80</span></div>'
    + '<button type="button" class="gc-l-x" onclick="gcLancioAnnulla()">Annulla</button>';
  document.body.appendChild(el);
  const giro = function(){
    const r = FF.run; const e = document.getElementById('gcLancio');
    if (!e) return;
    if (!r){ gcLancioVia(); return; }
    const resto = gcLancioSecondi(r);
    const n = document.getElementById('gcLN'), fr = document.getElementById('gcLFrase');
    if (resto <= 0){
      e.classList.add('via');
      if (fr) fr.textContent = gcLancioRiga(0);
      if (n) n.textContent = '';
      try{ flVibra([20, 40, 80]); }catch(_){ }
      setTimeout(gcLancioVia, 1100); return;
    }
    /* il numero e la riga cambiano INSIEME: mai "1 secondo" sotto a un 3 */
    if (n && n.textContent !== String(resto)){
      n.textContent = String(resto); n.classList.remove('pop'); void n.offsetWidth; n.classList.add('pop');
      if (fr) fr.textContent = gcLancioRiga(resto);
    }
    GC.giro = setTimeout(giro, 150);
  };
  giro();
}
function gcLancioVia(subito){ clearTimeout(GC.giro); const e = document.getElementById('gcLancio'); if (e){ if (subito) e.remove(); else { e.classList.add('fuori'); setTimeout(function(){ e.remove(); }, 400); } } }
function gcLancioAnnulla(){ gcLancioVia(true); if (typeof ffCancelGrace === 'function') ffCancelGrace(); }

/* ---------- 3. le vittorie della community ---------- */
function gcVittoria(tipo, valore, cosa){
  try{ if (typeof frApi !== 'function' || typeof frDevice !== 'function' || !frDevice()) return; frApi('POST', '/api/focuslock/social/vittoria', { device: frDevice(), tipo: tipo, valore: Math.round(valore || 0), cosa: String(cosa || '').slice(0, 60) }).catch(function(){ }); }catch(_){ }
}
async function gcFeedCarica(){
  try{
    if (typeof frApi !== 'function' || typeof frDevice !== 'function') return;
    const r = await frApi('GET', '/api/focuslock/social/vittorie?device=' + encodeURIComponent(frDevice() || ''));
    GC.feed = (r && Array.isArray(r.vittorie)) ? r.vittorie : [];
    GC.i = 0; gcFeedPaint();
  }catch(_){ }
}
function gcFeedTesto(v){
  const n = gcEsc(v.nome || 'Qualcuno');
  if (v.tipo === 'ff') return '🔥 <b>' + n + '</b> ha appena completato ' + v.valore + ' minuti di focus' + (v.cosa ? ' su ' + gcEsc(v.cosa) : '');
  if (v.tipo === 'caveau') return '🔒 <b>' + n + '</b> ha messo un’idea nel caveau';
  if (v.tipo === 'arrivo') return '🚀 <b>' + n + '</b> ha anticipato il suo arrivo di ' + v.valore + (v.valore === 1 ? ' giorno' : ' giorni');
  if (v.tipo === 'rompicapo') return '🧩 <b>' + n + '</b> ha risolto un rompicapo invece di aprire un’app';
  if (v.tipo === 'serie') return '📅 <b>' + n + '</b> è a ' + v.valore + ' giorni di fila';
  return '⭐ <b>' + n + '</b> ha fatto un passo verso il sogno';
}
function gcFa(at){ const m = Math.max(0, Math.round((Date.now() - new Date(at).getTime()) / 60000)); return m < 1 ? 'adesso' : (m < 60 ? m + ' min fa' : Math.round(m / 60) + ' h fa'); }
function gcFeedHtml(){ return '<div class="gc-feed" hidden></div>'; }
function gcFeedPaint(){
  const els = document.querySelectorAll('.gc-feed'); if (!els.length) return;
  if (!GC.feed.length){ els.forEach(function(e){ e.hidden = true; }); return; }
  const v = GC.feed[GC.i % GC.feed.length];
  const html = '<span class="gc-f-live"><i></i>Dal vivo</span><p class="gc-f-t">' + gcFeedTesto(v) + ' <small>· ' + gcFa(v.at) + '</small></p>';
  els.forEach(function(e){ e.hidden = false; e.innerHTML = html; });
}
function gcFeedGira(){
  clearInterval(GC.t);
  GC.t = setInterval(function(){ if (document.hidden || !GC.feed.length) return; GC.i++; gcFeedPaint(); }, 4500);
}
function gcFeedMonta(){
  try{
    const host = document.getElementById('nvArrivo'); if (!host || document.getElementById('gcFeedDream')) return;
    const d = document.createElement('div'); d.id = 'gcFeedDream'; d.className = 'gc-feed'; d.hidden = true;
    const card = host.closest('.nv-arr-card, #nvArrCard') || host;
    card.parentNode.insertBefore(d, card.nextSibling);
    gcFeedPaint();
  }catch(_){ }
}

/* ---------- 4. mystery box dal foglio e Bonus Drop dalla serie ---------- */
const GC_BADGE = [['🔥', 'Fenice', 'Ti sei rialzato e hai tenuto la serie.'], ['☄️', 'Cometa', 'Giorni di fila che lasciano la scia.'], ['🗼', 'Faro', 'Costante anche quando nessuno guarda.'],
  ['🐺', 'Lupo solitario', 'Hai lavorato mentre gli altri scorrevano.'], ['🏛️', 'Architetto', 'Mattone dopo mattone, ogni giorno.'], ['💎', 'Diamante', 'La pressione ti rende più forte.']];
const GC_KAIROS = [
  'Ogni giorno di fila è un voto che dai alla persona che vuoi diventare.',
  'Il Vecchio te conta sui giorni storti. Tu gliene stai togliendo uno alla volta.',
  'Lo sai cosa succede a chi tiene il passo per cento giorni? Smette di chiedersi se ce la farà.',
  'La motivazione va e viene. La serie resta: è la prova che sei già un’altra persona.',
  'Il tuo sogno non ha bisogno di giorni perfetti. Ha bisogno di giorni come questo.',
  'Nessuno vede questi giorni. Fra un anno tutti vedranno dove ti hanno portato.'
];
const GC_PROB_FOGLIO = { prob: 0.3, pesi: { bronzo: 0.7, argento: 0.25, oro: 0.05 } };
/* 0.9.294, Andrea: "tre mystery box di fila dopo due tappe: e' una minchiata". Le scatole a sorpresa (riga fatta, serie)
   non arrivano nei primi tre giorni e non piu' di una al giorno, contando anche quelle della mappa. */
function gcScatolaPermessa(){
  try{
    const d = (typeof gnDati === 'function') ? gnDati() : {};
    const inizio = +d.tourFatto || +localStorage.getItem('fl_installato') || 0;
    if (!inizio){ localStorage.setItem('fl_installato', String(Date.now())); return false; }
    if (Date.now() - inizio < 3 * 86400000) return false;
    return localStorage.getItem('fl_box_giorno') !== gcOggi();
  }catch(_){ return false; }
}
function gcEstrai(pesi){ let r = Math.random(), acc = 0, u = 'bronzo'; for (const k in pesi){ acc += pesi[k]; u = k; if (r < acc) return k; } return u; }
document.addEventListener('fl:spunta', function(e){
  try{
    if (!e.detail || e.detail.azione !== 'fatta') return;
    const st = gcLeggi('fl_gc_foglio', {}); const g = gcOggi();
    if (st.g !== g){ st.g = g; st.n = 0; }
    if (st.n >= 2 || !gcScatolaPermessa() || Math.random() >= GC_PROB_FOGLIO.prob){ gcScrivi('fl_gc_foglio', st); return; }
    st.n++; gcScrivi('fl_gc_foglio', st);
    const tier = gcEstrai(GC_PROB_FOGLIO.pesi);
    setTimeout(function(){ if (typeof scrApriPremio === 'function') scrApriPremio(tier, { titolo: 'Riga fatta', sotto: 'È uscita una mystery box: toccala tre volte per aprirla', motivo: 'foglio' }); }, 900);
  }catch(_){ }
});
function gcSerie(){ try{ return (typeof sdSerieMappa === 'function') ? (+sdSerieMappa() || 0) : 0; }catch(_){ return 0; } }
function gcControllaSerie(){
  /* una scatola alla volta: se ce n'e' gia' una aperta, si riprova quando si chiude */
  if (document.getElementById('mbBox')){ setTimeout(gcControllaSerie, 3000); return; }
  const n = gcSerie(); const st = gcLeggi('fl_gc_serie', { n: 0, g: '' });
  if (n <= st.n || st.g === gcOggi()){ if (n < st.n) { st.n = n; gcScrivi('fl_gc_serie', st); } return; }
  st.n = n; st.g = gcOggi(); gcScrivi('fl_gc_serie', st);
  if (n >= 3) gcVittoria('serie', n);
  if (n < 2 || !gcScatolaPermessa()) return;
  const prob = Math.min(0.6, 0.25 + 0.05 * n);
  if (Math.random() >= prob) return;
  const tier = n >= 21 ? gcEstrai({ argento: 0.5, oro: 0.4, leggendario: 0.1 }) : (n >= 7 ? gcEstrai({ bronzo: 0.4, argento: 0.45, oro: 0.15 }) : gcEstrai({ bronzo: 0.75, argento: 0.25 }));
  const extra = [];
  if (Math.random() < 0.5){
    const presi = gcLeggi('fl_badge_rari', []); const liberi = GC_BADGE.filter(function(b){ return !presi.some(function(p){ return p.n === b[1]; }); });
    if (liberi.length){ const b = liberi[Math.floor(Math.random() * liberi.length)]; presi.push({ n: b[1], ico: b[0], at: Date.now() }); gcScrivi('fl_badge_rari', presi); extra.push({ ico: b[0], t: 'Distintivo raro: ' + b[1], s: b[2] }); }
  }
  /* 0.9.284, Andrea: niente frasi in riquadri dentro la scatola (il messaggio del Genio e la frase d'identita'): le
     monete grandi e, se esce, il distintivo raro sotto */
  setTimeout(function(){ if (typeof scrApriPremio === 'function') scrApriPremio(tier, { titolo: 'Bonus Drop', sotto: n + ' giorni di fila: toccala tre volte per aprirla', motivo: 'serie', extra: extra }); }, 1600);
}
/* ---------- gli agganci ---------- */
(function(){
  if (typeof ffStart === 'function'){
    const v = ffStart;
    ffStart = async function(){
      if (GC.ok) return v.apply(this, arguments);
      if (gcChiediScommessa()){ gcEventoApri(); return; }
      const r = await v.apply(this, arguments);
      gcLancioApri(0);
      return r;
    };
  }
  if (typeof ffCancelGrace === 'function'){
    const v2 = ffCancelGrace;
    ffCancelGrace = async function(){
      const run = (typeof FF !== 'undefined') ? FF.run : null;
      if (run && run.posta){ ffAddCoins(run.posta); run.posta = 0; }
      gcLancioVia(true);
      return v2.apply(this, arguments);
    };
  }
  if (typeof ffFinish === 'function'){
    const v3 = ffFinish;
    ffFinish = async function(ok){
      const run = (typeof FF !== 'undefined') ? FF.run : null;
      gcLancioVia(true);
      const r = await v3.apply(this, arguments);
      try{
        if (run && run.posta){
          let riga = '';
          if (ok){ ffAddCoins(run.posta * 3); riga = '🎲 <b>Scommessa vinta:</b> hai battuto il Vecchio te. +' + (run.posta * 3) + ' monete.'; try{ flVibra([10, 30, 10, 30, 80]); }catch(_){ } }
          else { gcScrivi('fl_vecchio_monete', (+gcLeggi('fl_vecchio_monete', 0) || 0) + run.posta); riga = '🎲 <b>Scommessa persa:</b> ' + run.posta + ' monete al Vecchio te. La prossima te le riprendi.'; }
          const host = document.getElementById('ffDone');
          if (host){ const p = document.createElement('p'); p.className = 'gc-sc-esito' + (ok ? ' vinta' : ''); p.innerHTML = riga; const msg = host.querySelector('.ffd-msg'); if (msg) msg.after(p); else host.prepend(p); }
        }
        if (ok && run && !run.meditazione){ const min = Math.round((run.minutes || 0)); if (min >= 10){ let cosa = ''; try{ const t = ffTag(); cosa = t && t.id !== 'altro' ? (t.name || t.n || '') : ''; }catch(_){ } gcVittoria('ff', min, cosa); } }
        setTimeout(gcControllaSerie, 1500);
      }catch(_){ }
      return r;
    };
  }
  if (typeof frLegaHtml === 'function'){ const v4 = frLegaHtml; frLegaHtml = function(){ const h = v4.apply(this, arguments); setTimeout(gcFeedPaint, 0); return gcFeedHtml() + h; }; }
  if (typeof nvPaint === 'function'){ const v5 = nvPaint; nvPaint = function(){ const r = v5.apply(this, arguments); gcFeedMonta(); gcArrivo(); return r; }; }
  document.addEventListener('fl:caveau', function(e){ gcVittoria('caveau', (e.detail && e.detail.n) || 1); });
  /* 0.9.284, Andrea: "il Bonus Drop e' comparso appena ho aperto l'app, senza aver fatto niente". La serie si guarda
     solo subito dopo un'azione vera (una sessione finita, una riga spuntata): il premio arriva come conseguenza. */
  document.addEventListener('visibilitychange', function(){ if (!document.hidden){ if (Date.now() - (GC.preso || 0) > 120000){ GC.preso = Date.now(); gcFeedCarica(); } } });
  document.addEventListener('fl:spunta', function(e){ if (e.detail && e.detail.azione === 'fatta') setTimeout(gcControllaSerie, 2500); });
  setTimeout(function(){ GC.preso = Date.now(); gcFeedCarica(); gcFeedGira(); }, 6000);
})();
/* l'arrivo che si avvicina: una vittoria da raccontare (una volta al giorno) */
function gcArrivo(){
  try{
    const a = (typeof nvArrivo === 'function') ? nvArrivo() : null; if (!a || !isFinite(a.at)) return;
    const st = gcLeggi('fl_gc_arrivo', null);
    if (!st){ gcScrivi('fl_gc_arrivo', { at: a.at, g: gcOggi() }); return; }
    const giorni = Math.round((st.at - a.at) / 86400000);
    if (giorni >= 1 && st.g !== gcOggi()){ gcVittoria('arrivo', giorni); gcScrivi('fl_gc_arrivo', { at: a.at, g: gcOggi() }); }
    else if (a.at > st.at) gcScrivi('fl_gc_arrivo', { at: a.at, g: st.g });
  }catch(_){ }
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.gc-sc{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;padding:4px 4px 2px}',
    '.gc-sc-top{align-self:stretch;display:flex;justify-content:flex-end;gap:8px;margin:-8px -6px 0}',
    '.gc-sc-tondo{width:36px;height:36px;border:0;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(0,30,68,.07);color:#0F2041;cursor:pointer}',
    'body.dark .gc-sc-tondo{background:rgba(255,255,255,.14);color:#fff}',
    '.gc-sc-vs{display:flex;align-items:center;gap:16px;margin-top:2px}',
    '.gc-sc-vs i{font:900 15px var(--font-body);font-style:normal;color:#E63946;letter-spacing:.1em}',
    'body.dark .gc-sc-vs i{color:#FF8A94}',
    '.gc-sc-emo{width:64px;height:64px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:36px;line-height:1;box-shadow:0 0 0 1.5px #E3F1FF,0 6px 16px rgba(0,30,68,.12)}',
    '.gc-sc-diavolo{filter:hue-rotate(80deg) saturate(1.25)}',
    '.gc-sc-tit{margin-top:20px;font:800 21px/1.25 var(--font-body);color:var(--navy)}',
    '.gc-sc-p{margin:10px 0 0;max-width:340px;font:500 15px/1.5 var(--font-body);color:var(--ink,var(--navy))}',
    'body.dark .gc-sc-p{color:#C9D8EE}',
    '.gc-sc-lab{margin:28px 0 0;font:700 13.5px var(--font-body);color:var(--muted)}',
    'body.dark .gc-sc-lab{color:#BCE0FF}',
    '.gc-sc-poste{display:flex;justify-content:center;gap:10px;margin-top:12px}',
    '.gc-sc-poste button{min-width:84px;border:1.5px solid #D5E3F5;border-radius:50px;padding:10px 16px;background:transparent;color:#0F2041;cursor:pointer;font:800 15px var(--font-body)}',
    'body.dark .gc-sc-poste button{border-color:rgba(188,224,255,.35);color:#fff}',
    '.gc-sc-poste button.on{border:2px solid #0075E3;background:#E3F1FF;color:#005BB0}',
    'body.dark .gc-sc-poste button.on{border-color:#8CC6FF;background:rgba(140,198,255,.2);color:#fff}',
    '.gc-sc-poste button:disabled{opacity:.35;cursor:default}',
    '.gc-sc-vinci{margin:14px 0 0;font:600 14px var(--font-body);color:var(--muted)}',
    '.gc-sc-vinci b{color:#005BB0;font-weight:800}',
    'body.dark .gc-sc-vinci{color:#C9D8EE}',
    'body.dark .gc-sc-vinci b{color:#8CC6FF}',
    '.gc-sc-go{width:100%;margin-top:28px;border:0;border-radius:50px;padding:16px 20px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.3)}',
    '.gc-sc-no{margin-top:10px;border:0;background:transparent;padding:10px 12px;color:#0F2041;font:700 14.5px var(--font-body);cursor:pointer}',
    'body.dark .gc-sc-no{color:#fff}',
    '.gc-sc-velo{position:absolute;inset:0;z-index:29;border-radius:inherit;background:rgba(0,8,20,.4)}',
    'body.dark .gc-sc-velo{background:rgba(0,4,14,.55)}',
    '.gc-sc-menu{top:64px;right:20px;left:auto;min-width:220px;border-radius:16px}',
    '.gc-sc-menu button{padding:15px 16px;font:700 14.5px var(--font-body)}',
    'body.dark #gcScMenu.arb-menu,body.dark #gcScMenu button,body.dark #gcScMenu .arb-mtit{background:#2A4380 !important}',
    'body.dark #gcScMenu.arb-menu{border:1px solid rgba(188,224,255,.3);box-shadow:0 18px 44px rgba(0,0,0,.6)}',
    'body.dark #gcScMenu .arb-mtit{color:#BCE0FF !important}',
    '.gc-sc-esito{margin:8px auto 0;max-width:320px;padding:10px 14px;border-radius:14px;background:#FDECEC;color:#7A1F24;font:500 14px/1.45 var(--font-body);text-align:center}',
    '.gc-sc-esito.vinta{background:#E3F1FF;color:#0E2350}',
    '.gc-ev .gc-sc-top{justify-content:flex-end}',
    '.gc-ev-kick{margin-top:2px;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#E63946}',
    'body.dark .gc-ev-kick{color:#FF8A94}',
    '.gc-ev-emo{margin-top:18px;width:84px;height:84px;font-size:46px;animation:gcEvEntra .6s cubic-bezier(.2,1.4,.4,1) both}',
    '.gc-ev-tit{margin-top:18px;font-size:25px}',
    '@keyframes gcEvEntra{from{transform:scale(.4) rotate(-12deg);opacity:0}to{transform:none;opacity:1}}',
    '.gc-lancio{position:fixed;inset:0;z-index:9800;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:24px;text-align:center;color:#fff;background:radial-gradient(circle at 50% 30%,#1D5FB8 0%,#0E2350 55%,#001E44 100%);overflow:hidden;animation:gcIn .35s ease-out}',
    '.gc-l-stelle{position:absolute;inset:-50%;background-image:radial-gradient(2px 2px at 20% 30%,#fff,transparent),radial-gradient(2px 2px at 70% 20%,#BCE0FF,transparent),radial-gradient(1.5px 1.5px at 40% 80%,#BCE0FF,transparent),radial-gradient(2px 2px at 85% 65%,#fff,transparent),radial-gradient(1.5px 1.5px at 10% 70%,#8CC6FF,transparent);background-size:220px 220px;animation:gcStelle 2.4s linear infinite;opacity:.6}',
    '.gc-l-frase{position:relative;margin:0;max-width:330px;font:800 21px/1.3 var(--font-body);color:#fff}',
    '.gc-l-n{position:relative;min-height:96px;font:900 96px/1 var(--font-body);color:#fff;text-shadow:0 0 28px rgba(63,159,244,.75)}',
    '.gc-l-n.pop{animation:gcPop .35s ease-out}',
    '.gc-l-base{position:relative;width:112px;height:112px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 6px rgba(188,224,255,.25),0 0 44px rgba(63,159,244,.55)}',
    '.gc-l-razzo{display:block;font-size:58px;line-height:1;transform:rotate(-45deg);animation:gcVibra .14s linear infinite}',
    '.gc-lancio.via .gc-l-base{background:transparent;box-shadow:none;transition:background .3s,box-shadow .3s}',
    '.gc-lancio.via .gc-l-razzo{animation:gcDecolla 1s ease-in forwards}',
    '.gc-lancio.via .gc-l-x{visibility:hidden}',
    '.gc-lancio.fuori{opacity:0;transition:opacity .4s}',
    '.gc-l-x{position:relative;margin-top:14px;min-width:160px;border:1.5px solid rgba(255,255,255,.55);background:rgba(255,255,255,.1);color:#fff;border-radius:50px;padding:13px 30px;font:800 15px var(--font-body);cursor:pointer}',
    '@keyframes gcIn{from{opacity:0}to{opacity:1}}@keyframes gcStelle{from{transform:translateY(0)}to{transform:translateY(220px)}}',
    '@keyframes gcVibra{0%,100%{transform:rotate(-45deg) translate(0,0)}50%{transform:rotate(-45deg) translate(1px,-1px)}}',
    '@keyframes gcPop{0%{transform:scale(1.4);opacity:.8}100%{transform:scale(1);opacity:1}}@keyframes gcFrase{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '@keyframes gcDecolla{to{transform:rotate(-45deg) translate(70vh,-70vh) scale(1.2)}}',
    '.gc-feed{display:flex;align-items:center;gap:10px;margin:12px 0;padding:10px 14px;border-radius:16px;background:var(--card);border:1px solid var(--line);overflow:hidden}',
    '.gc-feed[hidden]{display:none}',
    '.gc-f-live{flex:none;display:inline-flex;align-items:center;gap:5px;font:800 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#E5484D}',
    '.gc-f-live i{width:7px;height:7px;border-radius:50%;background:#E5484D;animation:gcLive 1.2s ease-in-out infinite}',
    '.gc-f-t{margin:0;flex:1;min-width:0;font:500 13.5px/1.35 var(--font-body);color:var(--navy);animation:gcFrase .45s ease-out}.gc-f-t small{color:var(--muted)}',
    '@keyframes gcLive{0%,100%{opacity:1}50%{opacity:.25}}',
  ].join('\n');
  document.head.appendChild(st);
})();
