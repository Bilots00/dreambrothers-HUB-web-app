/* ===========================================================================================
   IL BIVIO DISEGNATO (0.9.288, Andrea)

   "Le schermate delle decisioni a effetto farfalla non mi fanno impazzire: trasformale in una
   rappresentazione della decisione, una strada che si divide in due, come OutRun o Fable (la scia
   luminosa). Non chiediamo se l'utente e' maschio o femmina: niente avatar, una luce che si sposta
   a sinistra o a destra."

   Una strada vista da dietro che si apre a Y verso l'orizzonte, due cartelli, e una luce in fondo
   alla strada (il "te" di adesso). Scelta una strada, la luce la percorre fino all'orizzonte e
   l'altra si spegne nella nebbia. Lo usano:
   - farfalla.js (faScena con cfg.bivio): la strada (Pianifico io / Seguo il Genio) e i pedaggi;
   - rientro-genio.js: il bivio con le due date ("se ogni giorno va come ieri" / "se fai le ore").
   Tutto SVG: niente immagini da scaricare, nitido su ogni schermo.
   =========================================================================================== */
const BIV_PERCORSO = {
  sx: 'M180 212 L180 163 C158 144 118 129 70 119',
  dx: 'M180 212 L180 163 C202 144 242 129 290 119'
};
function bivEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }

/**
 * Il disegno. o = { sx: { t, s }, dx: { t, s }, scuro: 'sx'|'dx'|'' (la strada nella nebbia, rossa), compatto }
 * t = il nome sul cartello, s = una riga sotto (una data, una conseguenza).
 */
function bivSvg(o){
  o = o || {};
  const scuro = o.scuro || '';
  const nebbia = function(lato){ return scuro === lato; };
  const cartello = function(lato){
    const d = o[lato] || {};
    /* 0.9.294, Andrea: "Pianifico io in blu con la freccia verso sinistra, Seguo il Genio in rosso con la freccia verso
       destra, icone SVG; e i pannelli sotto dello stesso colore del cartello". d.tinta = 'blu' | 'rosso'. */
    const fr = d.tinta ? (lato === 'sx'
      ? '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
      : '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>') : '';
    const t = bivEsc(d.t || '');
    return '<div class="biv-c biv-c-' + lato + (d.tinta ? ' tinta-' + d.tinta : (nebbia(lato) ? ' giu' : ' su')) + '"><small>' + (lato === 'sx' ? fr + t : t + fr) + '</small>' + (d.s ? '<b>' + bivEsc(d.s) + '</b>' : '') + '</div>';
  };
  const bagliore = function(lato, x){
    return nebbia(lato)
      ? '<circle cx="' + x + '" cy="114" r="46" fill="url(#bivRosso)"/>'
      : '<circle cx="' + x + '" cy="112" r="56" fill="url(#bivLuce)"/>';
  };
  return '<div class="biv' + (o.compatto ? ' compatto' : '') + '" data-scuro="' + scuro + '">'
    + '<svg class="biv-svg" viewBox="0 0 360 220" preserveAspectRatio="xMidYMax slice" aria-hidden="true">'
    + '<defs>'
    +   '<linearGradient id="bivCielo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#061430"/><stop offset=".62" stop-color="#123B7A"/><stop offset="1" stop-color="#3F6FB8"/></linearGradient>'
    +   '<linearGradient id="bivTerra" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B2246"/><stop offset="1" stop-color="#04112A"/></linearGradient>'
    +   '<linearGradient id="bivAsfalto" gradientUnits="userSpaceOnUse" x1="0" y1="220" x2="0" y2="118"><stop offset="0" stop-color="#6286C2"/><stop offset=".55" stop-color="#4466A0"/><stop offset="1" stop-color="#2E4A7E"/></linearGradient>'
    +   '<radialGradient id="bivLuce"><stop offset="0" stop-color="#BFE3FF" stop-opacity=".95"/><stop offset=".35" stop-color="#5BC0F8" stop-opacity=".45"/><stop offset="1" stop-color="#5BC0F8" stop-opacity="0"/></radialGradient>'
    +   '<radialGradient id="bivRosso"><stop offset="0" stop-color="#FF8A95" stop-opacity=".55"/><stop offset=".45" stop-color="#E5515F" stop-opacity=".25"/><stop offset="1" stop-color="#E5515F" stop-opacity="0"/></radialGradient>'
    +   '<radialGradient id="bivTe"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".45" stop-color="#BFE3FF" stop-opacity=".9"/><stop offset="1" stop-color="#5BC0F8" stop-opacity="0"/></radialGradient>'
    + '</defs>'
    + '<rect width="360" height="122" fill="url(#bivCielo)"/>'
    + '<g class="biv-stelle" fill="#fff"><circle cx="30" cy="22" r="1"/><circle cx="96" cy="40" r=".8"/><circle cx="150" cy="14" r="1.1"/><circle cx="214" cy="30" r=".8"/><circle cx="262" cy="12" r="1"/><circle cx="330" cy="36" r=".9"/><circle cx="300" cy="64" r=".7"/><circle cx="58" cy="70" r=".7"/></g>'
    + bagliore('sx', 70) + bagliore('dx', 290)
    + '<path d="M0 122 C40 104 70 112 104 106 C140 100 160 112 196 108 C236 103 262 96 300 104 C326 109 344 104 360 108 L360 122 Z" fill="#0A1E44"/>'
    + '<rect y="120" width="360" height="100" fill="url(#bivTerra)"/>'
    /* le due strade e il tronco */
    + '<path class="biv-r biv-r-sx" d="M162 162 L182 162 C160 143 118 129 80 119 L60 119 C100 129 144 142 162 162 Z" fill="url(#bivAsfalto)"/>'
    + '<path class="biv-r biv-r-dx" d="M178 162 L198 162 C216 142 260 129 300 119 L280 119 C242 129 200 143 178 162 Z" fill="url(#bivAsfalto)"/>'
    + '<path d="M124 220 L236 220 L198 160 L162 160 Z" fill="url(#bivAsfalto)"/>'
    + '<g fill="none" stroke="#FFFFFF" stroke-width="1.3" opacity=".42"><path d="M124 220 L162 160 C144 142 100 129 60 119"/><path d="M236 220 L198 160 C216 142 260 129 300 119"/><path class="biv-bordo-in" d="M182 162 C160 143 118 129 80 119"/><path class="biv-bordo-in" d="M178 162 C200 143 242 129 280 119"/></g>'
    + '<g fill="none" stroke="#E8F2FF" stroke-width="1.8" stroke-dasharray="6 7" opacity=".8"><path d="M180 218 L180 165"/><path class="biv-l-sx" d="M180 163 C158 144 118 129 70 119"/><path class="biv-l-dx" d="M180 163 C202 144 242 129 290 119"/></g>'
    /* i percorsi della luce (invisibili) */
    + '<path class="biv-p biv-p-sx" d="' + BIV_PERCORSO.sx + '" fill="none" stroke="none"/>'
    + '<path class="biv-p biv-p-dx" d="' + BIV_PERCORSO.dx + '" fill="none" stroke="none"/>'
    + '<g class="biv-te" transform="translate(180 212)"><circle r="16" fill="url(#bivTe)" opacity=".85"/><circle r="4.5" fill="#FFFFFF"/></g>'
    + '</svg>'
    + cartello('sx') + cartello('dx')
    + '</div>';
}

/** Mette la luce al suo posto di partenza (da chiamare dopo aver messo il disegno nella pagina). */
function bivPronto(el){
  const w = el && (el.classList && el.classList.contains('biv') ? el : el.querySelector('.biv'));
  if (!w) return;
  const te = w.querySelector('.biv-te');
  if (te) te.setAttribute('transform', 'translate(180 212)');
}

/** La luce percorre la strada scelta ('sx' o 'dx'), l'altra si spegne. Poi `poi()`. */
function bivVai(el, lato, poi){
  const w = el && (el.classList && el.classList.contains('biv') ? el : el.querySelector('.biv'));
  const fine = function(){ if (typeof poi === 'function') try{ poi(); }catch(_){ } };
  if (!w){ fine(); return; }
  const p = w.querySelector('.biv-p-' + lato), te = w.querySelector('.biv-te');
  if (!p || !te || !p.getTotalLength){ fine(); return; }
  w.classList.add('scelto', 'scelto-' + lato);
  try{ if (typeof muJingle === 'function') muJingle('barra'); }catch(_){ }
  try{ flVibra(12); }catch(_){ }
  const L = p.getTotalLength(), D = 1150, t0 = performance.now();
  const passo = function(t){
    const q = Math.min(1, (t - t0) / D);
    const e = q < 0.5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2;
    const pt = p.getPointAtLength(L * e);
    const sc = 1 - 0.55 * e;                        // la luce si allontana verso l'orizzonte
    te.setAttribute('transform', 'translate(' + pt.x.toFixed(1) + ' ' + pt.y.toFixed(1) + ') scale(' + sc.toFixed(3) + ')');
    if (q < 1) requestAnimationFrame(passo);
    else setTimeout(fine, 260);
  };
  requestAnimationFrame(passo);
}

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.biv{position:relative;width:100%;border-radius:22px;overflow:hidden;background:#061430;box-shadow:0 14px 34px rgba(0,20,60,.35);aspect-ratio:360/220;max-height:34vh}',
    '.biv.compatto{max-height:24vh;border-radius:18px}',
    '.biv-svg{display:block;width:100%;height:100%}',
    '.biv-te{transition:opacity .3s}',
    '.biv-te circle:first-child{animation:bivRespira 1.6s ease-in-out infinite;transform-box:fill-box;transform-origin:center}',
    '@keyframes bivRespira{0%,100%{opacity:.55}50%{opacity:1}}',
    '.biv-r,.biv-l-sx,.biv-l-dx{transition:opacity .6s ease}',
    '.biv.scelto-sx .biv-r-dx,.biv.scelto-sx .biv-l-dx,.biv.scelto-dx .biv-r-sx,.biv.scelto-dx .biv-l-sx{opacity:.18}',
    '.biv.scelto-sx .biv-l-sx,.biv.scelto-dx .biv-l-dx{stroke:#BFE3FF;stroke-dasharray:none;stroke-width:2.6;opacity:1;filter:drop-shadow(0 0 4px #5BC0F8)}',
    '.biv-c{position:absolute;top:10px;max-width:46%;padding:8px 10px;border-radius:12px;background:rgba(6,20,48,.72);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);text-align:left;transition:opacity .5s,transform .5s}',
    '.biv-c-sx{left:10px}.biv-c-dx{right:10px;text-align:right}',
    '.biv-c small{display:block;font:800 10.5px/1.3 var(--font-body);letter-spacing:.04em;text-transform:uppercase}',
    '.biv-c b{display:block;margin-top:3px;font:800 13.5px/1.25 var(--font-body);color:#fff}',
    '.biv-c.su small{color:#9FD8FF}.biv-c.giu small{color:#FFB3BB}',
    '.biv-c small svg{vertical-align:-2px}.biv-c-sx small svg{margin-right:4px}.biv-c-dx small svg{margin-left:4px}',
    '.biv-c.tinta-blu{background:#0075E3;box-shadow:0 6px 16px rgba(0,117,227,.45)}.biv-c.tinta-blu small{color:#fff}',
    '.biv-c.tinta-rosso{background:#E63946;box-shadow:0 6px 16px rgba(230,57,70,.45)}.biv-c.tinta-rosso small{color:#fff}',
    '.biv-c.su{box-shadow:inset 0 0 0 1.5px rgba(91,192,248,.55)}.biv-c.giu{box-shadow:inset 0 0 0 1.5px rgba(229,81,95,.5)}',
    '.biv.scelto-sx .biv-c-dx,.biv.scelto-dx .biv-c-sx{opacity:.25}',
    '.biv.scelto-sx .biv-c-sx,.biv.scelto-dx .biv-c-dx{transform:scale(1.05)}'
  ].join('\n');
  document.head.appendChild(st);
})();
