/* ===========================================================================================
   IL TEMPO DENTRO LE APP SOCIAL, PER SEZIONE (0.9.300)

   Andrea: "dentro ogni card dei social, sopra agli interruttori, il grafico ad anello degli
   ultimi 7 giorni con il tempo diviso per sezione, come StayFree: Instagram (Storie, Reels,
   Esplora, DM, Altro), YouTube, TikTok, Facebook, WhatsApp. E lo stesso approfondimento nel
   Report, dentro un cassetto sotto ogni app social delle App piu' usate".

   Il conto lo tiene il motore (SezioniTempo.java): la stessa lettura dello schermo che blocca
   Reels e Shorts dice quale sezione e' aperta. Qui si legge (NATIVE.getSezioni) e si disegna:
   - socIcona: l'icona vera dell'app installata, o quella in img/social finche' non arriva;
   - socLeggi: le sezioni di una finestra di tempo, con «Altro» = il tempo dell'app che nessuna
     sezione ha riconosciuto (dal registro di sistema), mai inventato;
   - socAnello: l'anello, con la legenda e le percentuali fuori, come nel modello.
   Prefisso soc-.
   =========================================================================================== */

const SOC_APPS = {
  'com.instagram.android':     { nome: 'Instagram', img: 'img/social/instagram.svg', host: ['instagram.com'] },
  'com.google.android.youtube':{ nome: 'YouTube',   img: 'img/social/youtube.svg',   host: ['youtube.com', 'm.youtube.com', 'youtu.be'] },
  'com.zhiliaoapp.musically':  { nome: 'TikTok',    img: 'img/social/tiktok.svg',    host: ['tiktok.com'], altri: ['com.ss.android.ugc.trill'] },
  'com.facebook.katana':       { nome: 'Facebook',  img: 'img/social/facebook.svg',  host: ['facebook.com', 'm.facebook.com'] },
  'com.whatsapp':              { nome: 'WhatsApp',  img: 'img/social/whatsapp.svg',  host: ['web.whatsapp.com', 'whatsapp.com'] }
};
/* Le sezioni di serie, se il motore non ha ancora risposto (anteprima nel browser). */
const SOC_SEZ_BASE = {
  'com.instagram.android': [['storie', 'Storie'], ['reels', 'Reels'], ['dm', 'DM'], ['esplora', 'Esplora']],
  'com.google.android.youtube': [['shorts', 'Shorts'], ['video', 'Video']],
  'com.zhiliaoapp.musically': [['commenti', 'Commenti'], ['shop', 'Shop'], ['messaggi', 'Messaggi'], ['perte', 'Per te']],
  'com.facebook.katana': [['storie', 'Storie'], ['reels', 'Reels'], ['marketplace', 'Marketplace'], ['feed', 'Feed']],
  'com.whatsapp': [['stati', 'Stati'], ['canali', 'Canali'], ['metaai', 'Meta AI'], ['chat', 'Chat']]
};
/* I colori del modello: azzurro, arancio, verde per le prime tre, rosso per «Altro". */
/* L'ordine in cui si mostrano (quello della richiesta di Andrea): il motore le prova in ordine di priorita'. */
const SOC_ORDINE = {
  'com.instagram.android': ['storie', 'reels', 'esplora', 'dm'],
  'com.google.android.youtube': ['shorts', 'video'],
  'com.zhiliaoapp.musically': ['perte', 'commenti', 'messaggi', 'shop'],
  'com.facebook.katana': ['storie', 'reels', 'marketplace', 'feed'],
  'com.whatsapp': ['chat', 'stati', 'canali', 'metaai']
};
const SOC_COL = ['#29A8F0', '#FF8A1F', '#76C043', '#E71D4F', '#14B8A6'];
const SOC_ALTRO_COL = '#E63946';

/** Il pacchetto «di catalogo» (TikTok ne ha due). */
function socPkg(pkg){
  if (SOC_APPS[pkg]) return pkg;
  for (const k in SOC_APPS){ if ((SOC_APPS[k].altri || []).indexOf(pkg) >= 0) return k; }
  return null;
}
function socE(pkg){ return !!socPkg(pkg); }

/* ---------------------------------------------------------------- le icone */
const SOC_ICONE = {};
/** L'<img> dell'app: parte con il disegno di img/social e passa all'icona vera appena il telefono la da'. */
function socIcona(pkg, cls){
  const p = socPkg(pkg) || pkg;
  const vera = SOC_ICONE[p];
  const src = vera && vera !== 'none' ? vera : ((SOC_APPS[p] && SOC_APPS[p].img) || '');
  return '<img class="' + (cls || 'soc-ico') + '" data-soc-pkg="' + esc(p) + '" src="' + esc(src) + '" alt="">';
}
/** Chiede al telefono le icone vere delle app installate e le mette al posto dei disegni. */
async function socIconeRiempi(box){
  const root = box || document;
  const els = Array.prototype.slice.call(root.querySelectorAll('img[data-soc-pkg]'));
  if (!els.length || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getAppIcon) return;
  for (let i = 0; i < els.length; i++){
    const el = els[i], pkg = el.getAttribute('data-soc-pkg');
    if (!pkg) continue;
    let icon = SOC_ICONE[pkg];
    if (icon === undefined){
      try{
        const r = await NATIVE.getAppIcon({ packageName: pkg });
        icon = (r && r.icon) || '';
        /* TikTok: se manca il pacchetto principale, quello dell'altra versione */
        if (!icon) for (const alt of ((SOC_APPS[pkg] || {}).altri || [])){
          try{ const r2 = await NATIVE.getAppIcon({ packageName: alt }); if (r2 && r2.icon){ icon = r2.icon; break; } }catch(_){ }
        }
      }catch(_){ icon = ''; }
      SOC_ICONE[pkg] = icon || 'none';
    }
    if (icon && icon !== 'none') document.querySelectorAll('img[data-soc-pkg="' + pkg + '"]').forEach(function(x){ x.src = icon; });
  }
}

/* ---------------------------------------------------------------- i dati */
const SOC_CACHE = new Map();
/**
 * Le sezioni di ogni app social fra from e to: { pkg: [{k, l, ms, col}] }, con «Altro" in fondo.
 * «Altro" e' il tempo dell'app (dal registro di sistema) che nessuna sezione ha riconosciuto: se il
 * motore ha contato piu' di quanto il registro dice, vale il conto del motore.
 */
async function socLeggi(from, to){
  const chiave = from + ':' + Math.floor(to / 60000);
  const hit = SOC_CACHE.get(chiave);
  if (hit && Date.now() - hit.t < 60000) return hit.v;
  let r = null;
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getSezioni){
    try{ r = await NATIVE.getSezioni({ from: from, to: to, appTotals: true }); }catch(_){ r = null; }
  }
  const out = {};
  const cat = {};
  ((r && r.catalogo) || []).forEach(function(a){ cat[a.pkg] = (a.sezioni || []).filter(function(z){ return z.k !== 'altro'; }).map(function(z){ return [z.k, z.l]; }); });
  Object.keys(SOC_APPS).forEach(function(pkg){
    const ord = SOC_ORDINE[pkg] || [];
    const sez = (cat[pkg] || SOC_SEZ_BASE[pkg] || []).slice().sort(function(x, y){
      const a = ord.indexOf(x[0]), c = ord.indexOf(y[0]);
      return (a < 0 ? 99 : a) - (c < 0 ? 99 : c);
    });
    const visti = (r && r.apps && r.apps[pkg]) || {};
    let nominate = 0;
    const righe = sez.map(function(z, i){ const ms = +visti[z[0]] || 0; nominate += ms; return { k: z[0], l: z[1], ms: ms, col: SOC_COL[i % SOC_COL.length] }; });
    const totale = (r && r.appMs && +r.appMs[pkg]) || 0;
    const altro = Math.max(+visti.altro || 0, totale - nominate);
    righe.push({ k: 'altro', l: 'Altro', ms: Math.max(0, altro), col: SOC_ALTRO_COL });
    out[pkg] = righe;
  });
  const v = { apps: out, motore: !!r };
  SOC_CACHE.set(chiave, { t: Date.now(), v: v });
  return v;
}
function socTotale(righe){ return (righe || []).reduce(function(t, x){ return t + (x.ms || 0); }, 0); }
function socPct(v){ return (Math.round(v * 1000) / 10).toFixed(1).replace('.', ',') + '%'; }
function socDurata(ms){
  if (typeof insFmt === 'function') return insFmt(ms);
  const m = Math.round((ms || 0) / 60000);
  return m >= 60 ? Math.floor(m / 60) + ' h ' + (m % 60) + ' min' : m + ' min';
}

/* ---------------------------------------------------------------- l'anello */
/**
 * L'anello come nel modello: parte dalle tre e gira in senso orario, sezioni separate da un
 * filo, percentuali fuori dall'anello per le fette che si leggono (dal 3% in su).
 * opts.piccolo: la versione del Report, senza percentuali e con il totale al centro.
 */
function socAnello(righe, opts){
  opts = opts || {};
  const tot = socTotale(righe);
  /* 0.9.301, Andrea: "Altro e 100% sono sovrapposti, sembra un bug". La legenda stava sopra al disegno
     (position:absolute) e la percentuale di una fetta a sinistra ci cadeva sotto. Adesso legenda e anello
     stanno affiancati in due colonne, e l'anello ha il suo riquadro con lo spazio per le percentuali. */
  const W = opts.piccolo ? 120 : 260, H = opts.piccolo ? 120 : 260;
  const cx = opts.piccolo ? 60 : 130, cy = opts.piccolo ? 60 : 130;
  const r = opts.piccolo ? 48 : 78, sw = opts.piccolo ? 12 : 9;
  const C = 2 * Math.PI * r;
  let s = '<svg class="soc-ring" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Tempo per sezione">';
  s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" class="soc-ring-vuoto" stroke-width="' + sw + '"/>';
  if (tot > 0){
    let ang = 0;
    const vive = righe.filter(function(x){ return x.ms > 0; });
    /* una fetta sola: la percentuale va al centro, non appesa a un lato */
    const unica = vive.length === 1;
    const gap = vive.length > 1 ? Math.min(2.2, C * 0.006) : 0;
    vive.forEach(function(x){
      const fr = x.ms / tot;
      const len = Math.max(0, fr * C - gap);
      s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + x.col + '" stroke-width="' + sw + '"'
        + ' stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '"'
        + ' transform="rotate(' + (ang * 360).toFixed(2) + ' ' + cx + ' ' + cy + ')"/>';
      if (!opts.piccolo && fr >= 0.03){
        const mid = (ang + fr / 2) * 2 * Math.PI;
        const lx = unica ? cx : cx + (r + 30) * Math.cos(mid), ly = unica ? cy : cy + (r + 30) * Math.sin(mid);
        s += '<text x="' + lx.toFixed(1) + '" y="' + (ly + 4).toFixed(1) + '" text-anchor="middle" class="soc-ring-pct">' + socPct(fr) + '</text>';
      }
      ang += fr;
    });
  }
  if (opts.piccolo){
    s += '<text x="' + cx + '" y="' + (cy + 5) + '" text-anchor="middle" class="soc-ring-tot">' + esc(tot > 0 ? socDurata(tot) : '0 min') + '</text>';
  } else if (!(tot > 0)){
    s += '<text x="' + cx + '" y="' + (cy - 4) + '" text-anchor="middle" class="soc-ring-vuoto-t">Ancora nessun dato</text>'
      + '<text x="' + cx + '" y="' + (cy + 16) + '" text-anchor="middle" class="soc-ring-vuoto-s">Si conta da quando la usi</text>';
  }
  return s + '</svg>';
}
function socLegenda(righe){
  return '<div class="soc-leg">' + righe.map(function(x){
    return '<span><i style="background:' + x.col + '"></i>' + esc(x.l) + '</span>';
  }).join('') + '</div>';
}

/** Il blocco grande della pagina Blocco funzionalità: titolo con il punto di domanda, legenda, anello. */
function socGrafico7(pkg, dati){
  const righe = (dati && dati.apps && dati.apps[socPkg(pkg)]) || [];
  return '<div class="soc-g7">'
    + '<div class="soc-g7-t">Ultimi 7 giorni di utilizzo<button type="button" class="soc-q" aria-label="Come si misura" onclick="event.stopPropagation();socSpiega()">?</button></div>'
    + '<div class="soc-g7-box">' + socLegenda(righe) + socAnello(righe) + '</div>'
    + '</div>';
}
function socSpiega(){
  if (typeof toast === 'function') toast('DreamMap riconosce la sezione aperta mentre usi l\'app. Il tempo che non riconosce va in Altro.');
}

/* ---------------------------------------------------------------- stile */
(function socStile(){
  if (document.getElementById('soc-style')) return;
  const st = document.createElement('style');
  st.id = 'soc-style';
  st.textContent = [
    '.soc-ico{width:30px;height:30px;border-radius:8px;object-fit:cover;flex:none;display:block}',
    '.soc-g7{padding:16px 2px 6px;border-bottom:1px solid var(--line)}',
    '.soc-g7-t{display:flex;align-items:center;justify-content:center;gap:8px;font:600 14px var(--font-body);color:var(--muted)}',
    '.soc-q{width:20px;height:20px;border-radius:50%;border:1.6px solid currentColor;background:none;color:var(--muted);font:700 11px var(--font-body);padding:0;line-height:1;cursor:pointer}',
    '.soc-g7-box{display:flex;align-items:center;gap:6px;margin-top:8px}',
    '.soc-g7-box .soc-leg{flex:none;min-width:84px}',
    '.soc-g7-box .soc-ring{flex:1;min-width:0;max-width:260px;margin:0 auto}',
    '.soc-leg{display:flex;flex-direction:column;gap:5px}',
    '.soc-leg span{display:flex;align-items:center;gap:8px;font:500 13px var(--font-body);color:var(--navy)}',
    '.soc-leg i{width:13px;height:13px;border-radius:2px;flex:none}',
    '.soc-ring{display:block;width:100%;height:auto}',
    '.soc-ring-vuoto{stroke:#E3ECF6}',
    '.soc-ring-pct{font:600 12.5px var(--font-body);fill:var(--navy)}',
    '.soc-ring-tot{font:700 13px var(--font-body);fill:var(--navy)}',
    '.soc-ring-vuoto-t{font:700 13px var(--font-body);fill:var(--navy)}',
    '.soc-ring-vuoto-s{font:500 11.5px var(--font-body);fill:var(--muted)}',
    'body.dark .soc-ring-vuoto{stroke:#22345A}',
    'body.dark .soc-ring-pct,body.dark .soc-ring-tot,body.dark .soc-ring-vuoto-t,body.dark .soc-leg span{fill:#fff;color:#fff}',
    'body.dark .soc-g7{border-color:#22345A}'
  ].join('\n');
  document.head.appendChild(st);
})();
