/* ===========================================================================================
   IL MICROFONO CHE COMPARE QUANDO SCRIVI (0.9.217)

   Andrea: il widget della dettatura non compare piu' (era nel campo «Scrivi una cosa» del
   pannello di prima, che il foglio a schede della Mappa ha sostituito). Ora e' un pulsante che
   galleggia sopra alla tastiera ogni volta che il cursore sta in un campo del foglio della Mappa
   o del piano in Notion (l'iframe e' sulla stessa origine: si ascolta il suo documento). Si
   tocca, si parla, la frase si vede mentre la dici; la spunta la scrive dove c'era il cursore,
   la X la butta. Premium, e accesa in Personalizza → Dettatura vocale (stDictAllowed).
   =========================================================================================== */
const DT = { el: null, doc: null, on: false, testo: '', cur: '', t: 0, lvl: 0, onda: [], giro: 0, fatto: null, ancora: null };
/* 0.9.229, Andrea: il testo che si scrive mentre parli distrae. Durante la dettatura si vede solo
   la forma d'onda: lineette alte quando la voce e' forte, basse (quasi puntini) nelle pause. Scorre
   da destra a sinistra, un passo ogni 70 ms. Il testo si scrive nel campo solo con la spunta. */
const DT_BARRE = 14;
function dtOndaGiro(on){
  clearInterval(DT.giro); DT.giro = 0;
  if (!on){ DT.onda = []; return; }
  DT.onda = Array.from({ length: DT_BARRE }, function(){ return 0; });
  DT.giro = setInterval(function(){
    const w = document.getElementById('dtW'); if (!w || !DT.on){ clearInterval(DT.giro); return; }
    const v = DT.lvl < 0.12 ? 0 : DT.lvl;
    DT.onda.push(v); if (DT.onda.length > DT_BARRE) DT.onda.shift();
    DT.lvl *= 0.82; /* senza voce nuova la lineetta si abbassa da sola */
    const bb = w.querySelectorAll('.dt-onda i');
    for (let i = 0; i < bb.length; i++){ const x = DT.onda[i] || 0; bb[i].style.height = (x ? Math.round(4 + 16 * Math.min(1, x)) : 3) + 'px'; bb[i].style.opacity = x ? '1' : '.45'; }
  }, 70);
}
function dtPuo(){ try{ return typeof stDictAllowed === 'function' && stDictAllowed(); }catch(_){ return false; } }
function dtCampo(el){
  if (!el || !el.tagName) return false;
  if (el.isContentEditable) return true;
  return el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|)$/i.test(el.type || ''));
}
/* 0.9.230, Andrea: il microfono compare SEMPRE quando si apre la tastiera, in tutta l'app (il Genio,
   "Lo scrivo io", la chat dell'agente, il piano, le note), non solo nel foglio della Mappa. Restano
   fuori solo i campi dove la voce non ha senso (numeri, email, password, date). */
function dtDove(el){
  if (!el) return false;
  if (el.closest && el.closest('[data-no-dettatura]')) return false;
  const t = (el.getAttribute && (el.getAttribute('inputmode') || '')).toLowerCase();
  return !/^(numeric|decimal|tel|email|none)$/.test(t);
}
function dtW(){
  let w = document.getElementById('dtW');
  if (w) return w;
  w = document.createElement('div'); w.id = 'dtW'; w.className = 'dt-w'; w.hidden = true;
  w.innerHTML = '<button type="button" class="dt-mic" aria-label="Detta a voce"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>'
    + '<div class="dt-pill"><button type="button" class="dt-x" aria-label="Annulla">✕</button><div class="dt-cosa"><div class="dt-onda" aria-label="Ti sto ascoltando">' + Array.from({ length: DT_BARRE }).map(function(){ return '<i></i>'; }).join('') + '</div></div><button type="button" class="dt-ok" aria-label="Scrivi">✓</button></div>';
  /* pointerdown senza default: il cursore resta nel campo, la tastiera non si chiude */
  w.addEventListener('pointerdown', function(e){ e.preventDefault(); });
  w.querySelector('.dt-mic').addEventListener('click', function(){ if (!DT.drag) dtVia(); });
  w.querySelector('.dt-x').addEventListener('click', function(){ if (!DT.drag) dtAnnulla(); });
  w.querySelector('.dt-ok').addEventListener('click', function(){ if (!DT.drag) dtFatto(); });
  document.body.appendChild(w);
  dtTrascina(w);
  dtApplicaPos(w);
  return w;
}
/* 0.9.253, Andrea: il microfono si trascina dove si vuole, anche con la tastiera aperta (come
   Wispr Flow). La posizione resta (fl_dt_pos) e si somma a quella che dtPosiziona calcola sopra
   alla tastiera. Un trascinamento non e' un tocco: i pulsanti ignorano il click che lo segue. */
try{ DT.pos = JSON.parse(localStorage.getItem('fl_dt_pos') || 'null'); }catch(_){ DT.pos = null; }
/* una posizione salvata fuori dallo schermo (altro telefono, rotazione) si butta */
try{ if (DT.pos && (Math.abs(DT.pos.x) > window.innerWidth || Math.abs(DT.pos.y) > window.innerHeight)) { DT.pos = null; localStorage.removeItem('fl_dt_pos'); } }catch(_){ }
/* 0.9.256, Andrea: il microfono era sparito con la tastiera aperta. Se il fuoco e' su un campo e la pillola
   non c'e', la si rimostra quando la finestra si restringe (tastiera) e un attimo dopo. */
function dtRiprova(){
  if (DT.kbNativo){ dtStato(); return; }
  try{
    const w = document.getElementById('dtW');
    if (w && !w.hidden) { dtPosiziona(); return; }
    let el = document.activeElement;
    if (el && el.tagName === 'IFRAME'){ try{ el = el.contentDocument.activeElement; }catch(_){ } }
    if (el && dtCampo(el) && dtDove(el) && dtPuo()) dtMostra(el);
  }catch(_){ }
}
if (window.visualViewport) window.visualViewport.addEventListener('resize', function(){ setTimeout(dtRiprova, 120); setTimeout(dtRiprova, 600); });
addEventListener('resize', function(){ setTimeout(dtRiprova, 200); });
/* 0.9.270, Andrea: il microfono non compariva piu' con la tastiera aperta, con la dettatura accesa. La posizione
   trascinata (fl_dt_pos) e' uno spostamento rispetto al posto di partenza, che cambia: a tastiera chiusa sta in fondo
   allo schermo, a tastiera aperta sta sopra alla tastiera. Trascinato in alto a tastiera chiusa (le note veloci), lo
   stesso spostamento a tastiera aperta lo mandava SOPRA il bordo dello schermo (provato su BlueStacks: -66 px). Ora lo
   spostamento si applica sempre dentro alla parte visibile: il microfono resta dove l'hai messo finche' ci sta, e
   quando non ci sta si ferma al bordo. */
function dtApplicaPos(w){
  if (!w) return;
  const p = DT.pos;
  let x = p ? (p.x || 0) : 0, y = p ? (p.y || 0) : 0;
  if (!w.hidden && (x || y)){
    try{
      const r = w.getBoundingClientRect();
      if (r.width){
        /* lo spostamento applicato in questo momento (anche a meta' della calamita): letto dallo stile, non ricordato */
        let ax = 0, ay = 0;
        try{ const m = new DOMMatrixReadOnly(getComputedStyle(w).transform === 'none' ? undefined : getComputedStyle(w).transform); ax = m.m41; ay = m.m42; }catch(_){ ax = DT.app ? DT.app.x : 0; ay = DT.app ? DT.app.y : 0; }
        const l0 = r.left - ax, t0 = r.top - ay;                          /* il posto di partenza */
        const vv = window.visualViewport;
        const alto = vv ? vv.offsetTop : 0, basso = vv ? vv.offsetTop + vv.height : window.innerHeight;
        x = Math.max(6 - l0, Math.min(window.innerWidth - 6 - r.width - l0, x));
        y = Math.max(alto + 6 - t0, Math.min(basso - 6 - r.height - t0, y));
      }
    }catch(_){ }
  }
  DT.app = { x: x, y: y };
  w.style.transform = (x || y) ? 'translate(' + Math.round(x) + 'px,' + Math.round(y) + 'px)' : '';
}
function dtTrascina(w){
  let x0 = 0, y0 = 0, px = 0, py = 0, on = false;
  w.addEventListener('pointerdown', function(e){
    x0 = e.clientX; y0 = e.clientY; const ap = DT.app || DT.pos; px = ap ? (ap.x || 0) : 0; py = ap ? (ap.y || 0) : 0; on = false; DT.drag = false;
    try{ w.setPointerCapture(e.pointerId); }catch(_){ }
  });
  w.addEventListener('pointermove', function(e){
    if (!e.buttons && !on) return;
    const dx = e.clientX - x0, dy = e.clientY - y0;
    if (!on && Math.hypot(dx, dy) < 8) return;
    on = true; DT.drag = true;
    const r = w.getBoundingClientRect();
    const ap = DT.app || DT.pos;
    const curX = ap ? (ap.x || 0) : 0, curY = ap ? (ap.y || 0) : 0;
    const bl = r.left - curX, bt = r.top - curY;
    const vv = window.visualViewport;
    const fondo = vv ? vv.offsetTop + vv.height : window.innerHeight;
    const nx = Math.max(6 - bl, Math.min(window.innerWidth - 6 - r.width - bl, px + dx));
    const ny = Math.max(6 - bt, Math.min(fondo - 6 - r.height - bt, py + dy));
    DT.pos = { x: nx, y: ny };
    dtApplicaPos(w);
  });
  const fine = function(){
    if (!on) return;
    on = false;
    /* 0.9.258, Andrea: come Wispr Flow, lasciato a meta' schermo si calamita al bordo piu' vicino */
    try{
      const r = w.getBoundingClientRect();
      const curX = DT.app ? DT.app.x : (DT.pos ? (DT.pos.x || 0) : 0);
      const bl = r.left - curX;                       /* dove starebbe senza spostamento (bordo destro) */
      const centro = r.left + r.width / 2;
      const aDestra = centro >= window.innerWidth / 2;
      const nx = aDestra ? 0 : (14 - bl);
      w.classList.add('calamita');
      DT.pos = { x: nx, y: DT.pos ? (DT.pos.y || 0) : 0 };
      dtApplicaPos(w);
      setTimeout(function(){ w.classList.remove('calamita'); }, 260);
    }catch(_){ }
    try{ localStorage.setItem('fl_dt_pos', JSON.stringify(DT.pos || { x: 0, y: 0 })); }catch(_){ }
    setTimeout(function(){ DT.drag = false; }, 80);
  };
  w.addEventListener('pointerup', fine);
  w.addEventListener('pointercancel', fine);
}
function dtPosiziona(){
  const w = document.getElementById('dtW'); if (!w || w.hidden) return;
  const vv = window.visualViewport;
  const sotto = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
  let giu = sotto + 14;
  /* 0.9.231, Andrea: nelle note il microfono stava sulla barra degli strumenti. Se nel documento
     del campo c'e' una barra in basso (le note: .editor-toolbar), il pulsante sta sopra di lei */
  try{
    const d = DT.doc;
    const tb = d && d.querySelector('.editor-toolbar');
    if (tb && tb.getClientRects().length){
      let su = tb.getBoundingClientRect().top;
      if (d !== document){ const fr = Array.prototype.filter.call(document.querySelectorAll('iframe'), function(f){ try{ return f.contentDocument === d; }catch(_){ return false; } })[0]; if (fr) su += fr.getBoundingClientRect().top; }
      if (su > 0) giu = Math.max(giu, window.innerHeight - su + 10);
    }
  }catch(_){ }
  /* 0.9.231: un campo di una riga in fondo allo schermo (la chat del Genio) ha accanto il suo
     pulsante Invia: il microfono sta sopra al campo, non sopra al pulsante */
  try{
    const el = DT.ancora || DT.el;
    if (el && el.getBoundingClientRect && (DT.ancora || !el.getAttribute('data-dt-aggiungi'))){
      const r = el.getBoundingClientRect();
      let top = r.top;
      if (DT.doc && DT.doc !== document){ const fr = Array.prototype.filter.call(document.querySelectorAll('iframe'), function(f){ try{ return f.contentDocument === DT.doc; }catch(_){ return false; } })[0]; if (fr) top += fr.getBoundingClientRect().top; }
      const fondo = window.innerHeight - sotto;
      if (r.height > 0 && r.height < 160 && top + r.height > fondo - 150) giu = Math.max(giu, window.innerHeight - top + 8);
    }
  }catch(_){ }
  w.style.bottom = giu + 'px';
  dtApplicaPos(w);
}
/* 0.9.231, Andrea: chiusa la tastiera, il microfono restava in basso a destra. Si guarda l'altezza
   della finestra: con la tastiera aperta e' piu' bassa; quando torna alta il microfono sparisce */
DT.hMax = window.innerHeight; DT.hW = window.innerWidth; DT.kb = false;
function dtTastiera(){
  if (DT.kbNativo){ dtAltezzaDice(); dtStato(); return; }
  const vv = window.visualViewport;
  const sotto = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
  if (!DT.kb && sotto < 40) DT.hMax = Math.max(DT.hMax || 0, window.innerHeight);
  const aperta = sotto > 120 || window.innerHeight < (DT.hMax || window.innerHeight) - 120;
  if (DT.kb && !aperta && !DT.on && !DT.fatto){
    const w = document.getElementById('dtW');
    const senza = DT.el && DT.el.getAttribute && DT.el.getAttribute('data-dt-aggiungi');
    if (w && !senza) w.hidden = true;
  }
  DT.kb = aperta;
}
/* 0.9.260, Andrea: il microfono spariva con la tastiera aperta, a volte compariva a tastiera chiusa e a volte
   restava dopo averla chiusa. La pagina indovinava la tastiera dall'altezza della finestra, e il fuoco nel testo
   resta anche quando la tastiera si chiude col tasto indietro. Adesso e' Android a dire quando la tastiera e'
   aperta (MenuCaveau.tastiera -> flTastiera) e la regola e' una sola: il microfono c'e' se la tastiera e' aperta
   su un campo dove si puo' dettare, oppure se si sta dettando. */
function dtStato(){
  if (DT.on || DT.fatto) return;
  const w = document.getElementById('dtW');
  if (w && w.classList.contains('solo')) return;           // il dettato senza tastiera (note veloci): e' suo
  let el = document.activeElement;
  if (el && el.tagName === 'IFRAME'){ try{ el = el.contentDocument.activeElement; }catch(_){ } }
  const campo = !!(el && dtCampo(el) && dtDove(el) && dtPuo());
  const aperta = DT.kbNativo ? (!!DT.kb || dtAltezzaDice()) : (DT.kb || window.__flKb === true);
  if (campo && aperta){ dtMostra(el); return; }
  if (w && !w.hidden){ clearTimeout(DT.t); w.hidden = true; }
}
/* 0.9.270: se l'avviso di Android non arriva (o arriva tardi), basta l'altezza: con la tastiera aperta la finestra
   si accorcia (MainActivity e NoteActivity la riducono della tastiera). La piu' alta vista con questa larghezza e'
   quella a tastiera chiusa; ruotando il telefono si ricomincia a contare. */
function dtAltezzaDice(){
  try{
    const vv = window.visualViewport;
    const sotto = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
    if (DT.hW !== window.innerWidth){ DT.hW = window.innerWidth; DT.hMax = window.innerHeight; }
    if (!DT.kb && sotto < 40) DT.hMax = Math.max(DT.hMax || 0, window.innerHeight);
    return sotto > 120 || window.innerHeight < (DT.hMax || window.innerHeight) - 120;
  }catch(_){ return false; }
}
window.flTastiera = function(aperta){
  DT.kbNativo = true; DT.kb = !!aperta;
  dtStato();
  setTimeout(dtStato, 250);
  if (aperta) setTimeout(dtPosiziona, 300);
};
try{ if (window.__flKb === true || window.__flKb === false){ DT.kbNativo = true; DT.kb = window.__flKb; } }catch(_){ }
/* la pagina caricata dopo l'ultimo avviso non l'ha sentito: lo chiede ad Android una volta */
try{ const P = window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.FocusLock; if (P && P.tastieraStato) P.tastieraStato().then(function(r){ if (r && typeof r.aperta === 'boolean' && !(window.__flKb === true || window.__flKb === false)) window.flTastiera(r.aperta); }).catch(function(){ }); }catch(_){ }
function dtMostra(el){
  if (DT.fatto) return; /* un campo col suo microfono sta dettando: la pillola resta sua */
  /* con la tastiera chiusa (lo dice Android) il microfono non compare, anche se il fuoco e' rimasto nel testo */
  if (DT.kbNativo && !DT.kb && !DT.on && !dtAltezzaDice()) return;
  if (!dtPuo() || !dtCampo(el) || !dtDove(el)) return;
  clearTimeout(DT.t);
  DT.el = el; DT.doc = el.ownerDocument;
  const w = dtW(); w.hidden = false; w.classList.toggle('on', DT.on);
  dtPosiziona(); setTimeout(dtPosiziona, 350); setTimeout(dtPosiziona, 900);
}
function dtNascondi(){
  clearTimeout(DT.t);
  DT.t = setTimeout(function(){ if (DT.on || DT.fatto) return; const w = document.getElementById('dtW'); if (w) w.hidden = true; }, 250);
}
/* ===========================================================================================
   0.9.290 — LA DETTATURA CON UN MODELLO CHE ASCOLTA DAVVERO (come Wispr Flow)

   Andrea: "la trascrizione vocale fa cagare: non usa l'AI, capisce male le parole e si mangia pezzi all'inizio e alla
   fine". Con gli Appunti AI accesi l'app non usa piu' il riconoscitore del telefono (ascolta a pezzi e indovina parola
   per parola): registra la voce intera dal primo istante, e alla spunta la manda al server, che la fa trascrivere a
   ElevenLabs Scribe v2 (punteggiatura, niente "ehm"). La forma d'onda e' quella vera del microfono. Se il microfono
   della pagina non c'e', o i minuti di oggi sono finiti, si torna da soli alla dettatura del telefono.
   =========================================================================================== */
const DTR = { rec: null, stream: null, ctx: null, an: null, buf: null, pezzi: [], t0: 0, raf: 0, mime: '', ultimo: null };
function dtRegistraPuo(){
  try{
    if (!dtAiOn() || typeof agApi !== 'function') return false;
    if (localStorage.getItem('fl_dt_ai_pausa') === new Date().toDateString()) return false;
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && typeof MediaRecorder !== 'undefined');
  }catch(_){ return false; }
}
async function dtRegistraVia(){
  /* un microfono che non risponde non deve lasciare la pillola appesa: dopo 4 secondi si passa al riconoscitore del telefono */
  let scaduto = false;
  const chiede = navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
  chiede.then(function(st){ if (scaduto) try{ st.getTracks().forEach(function(t){ t.stop(); }); }catch(_){ } }, function(){ });
  const stream = await Promise.race([
    chiede,
    new Promise(function(_, no){ setTimeout(function(){ scaduto = true; no(new Error('microfono senza risposta')); }, 4000); })
  ]);
  const tipi = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
  let mime = ''; try{ mime = tipi.filter(function(t){ return MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t); })[0] || ''; }catch(_){ }
  const rec = new MediaRecorder(stream, mime ? { mimeType: mime, audioBitsPerSecond: 32000 } : undefined);
  DTR.pezzi = []; DTR.stream = stream; DTR.rec = rec; DTR.mime = rec.mimeType || mime || 'audio/webm'; DTR.t0 = Date.now();
  rec.ondataavailable = function(e){ if (e.data && e.data.size) DTR.pezzi.push(e.data); };
  rec.start(1000);
  /* la forma d'onda: il volume vero del microfono, letto 60 volte al secondo */
  try{
    const AC = window.AudioContext || window.webkitAudioContext;
    DTR.ctx = new AC(); const src = DTR.ctx.createMediaStreamSource(stream);
    DTR.an = DTR.ctx.createAnalyser(); DTR.an.fftSize = 512; src.connect(DTR.an);
    DTR.buf = new Uint8Array(DTR.an.fftSize);
    const giro = function(){
      if (!DTR.an) return;
      DTR.an.getByteTimeDomainData(DTR.buf);
      let q = 0; for (let i = 0; i < DTR.buf.length; i++){ const v = (DTR.buf[i] - 128) / 128; q += v * v; }
      const rms = Math.sqrt(q / DTR.buf.length);
      DT.lvl = Math.max(DT.lvl, Math.min(1, rms * 7));
      DTR.raf = requestAnimationFrame(giro);
    };
    DTR.raf = requestAnimationFrame(giro);
  }catch(_){ }
}
async function dtRegistraFine(butta){
  const rec = DTR.rec; if (!rec) return null;
  try{ if (rec.state !== 'inactive') await new Promise(function(ok){ rec.onstop = ok; try{ rec.stop(); }catch(_){ ok(); } setTimeout(ok, 1500); }); }catch(_){ }
  try{ DTR.stream.getTracks().forEach(function(t){ t.stop(); }); }catch(_){ }
  cancelAnimationFrame(DTR.raf); DTR.raf = 0; DTR.an = null;
  try{ if (DTR.ctx) DTR.ctx.close(); }catch(_){ }
  const sec = Math.round((Date.now() - DTR.t0) / 1000);
  DTR.rec = null; DTR.stream = null; DTR.ctx = null;
  if (butta || !DTR.pezzi.length) return null;
  return { blob: new Blob(DTR.pezzi, { type: DTR.mime }), mime: DTR.mime, sec: sec };
}
function dtBase64(blob){
  return new Promise(function(ok, no){ const fr = new FileReader(); fr.onload = function(){ ok(String(fr.result || '').split(',')[1] || ''); }; fr.onerror = no; fr.readAsDataURL(blob); });
}
function dtCoda(){
  return new Promise(function(ok){
    const t0 = Date.now(); let quieto = 0, prima = t0;
    const giro = function(){
      const an = DTR.an, ora = Date.now();
      let rms = 0;
      try{ if (an && DTR.buf){ an.getByteTimeDomainData(DTR.buf); let q = 0; for (let i = 0; i < DTR.buf.length; i++){ const v = (DTR.buf[i] - 128) / 128; q += v * v; } rms = Math.sqrt(q / DTR.buf.length); } }catch(_){ }
      if (rms < 0.018) quieto += ora - prima; else quieto = 0;
      prima = ora;
      const e = ora - t0;
      if (!an){ if (e >= 600) return ok(); }
      else if ((e >= 350 && quieto >= 300) || e >= 1400) return ok();
      setTimeout(giro, 40);
    };
    giro();
  });
}
/* 0.9.342: le parole che il riconoscitore deve conoscere (come il dizionario di Wispr Flow, che manda nomi, parole del testo e
   vocabolario personale): il nome, le parole del sogno, i nomi dell'app e le parole aggiunte dall'utente (fl_dt_parole) */
function dtParoleChiave(){
  const out = [], visto = {};
  const metti = function(w){ w = String(w || '').replace(/[<>{}\[\]\\]/g, '').trim(); if (w.length < 3 || w.length > 40) return; const k = w.toLowerCase(); if (visto[k]) return; visto[k] = 1; out.push(w); };
  ['DreamMap', 'Genio', 'Full Focus', 'Roadmap', 'caveau', 'Academy', 'Io Futuro', 'Modalità severa', 'Taglia', 'Dreambrother'].forEach(metti);
  try{ if (typeof frName === 'function') metti(frName()); }catch(_){ }
  try{ const s = (typeof nvSogno === 'function') ? nvSogno() : ''; String(s || '').split(/[\s,.;:!?"'’()]+/).forEach(function(p){ if (p.length >= 5) metti(p); }); }catch(_){ }
  try{ (JSON.parse(localStorage.getItem('fl_dt_parole') || '[]') || []).forEach(metti); }catch(_){ }
  return out.slice(0, 60);
}
async function dtTrascrivi(a){
  const b64 = await dtBase64(a.blob);
  /* 0.9.321, Andrea: "a volte resta li' per ore". La richiesta non aveva un tetto, e la seconda prova ne aggiungeva un altro giro.
     Adesso ogni giro ha un tempo massimo (20 secondi piu' la durata dell'audio), e dopo 8 secondi lo si dice. */
  const tetto = Math.min(75000, 20000 + (a.sec || 0) * 1000);
  const giro = function(ms){ return Promise.race([agApi('POST', '/api/focuslock/agent/trascrivi', { audio: b64, mime: a.mime, durata: a.sec, lingua: 'it', parole: dtParoleChiave() }), new Promise(function(_, no){ setTimeout(function(){ const e = new Error('tempo scaduto'); e.code = 'tempo'; no(e); }, ms); })]); };
  const avviso = setTimeout(function(){ try{ toast('Ci sta mettendo più del solito: la rete è lenta'); }catch(_){ } }, 8000);
  let r;
  try{ r = await giro(tetto); }
  catch(e){
    const c = String((e && e.code) || '');
    if (c === 'http-402' || c === 'http-429' || c === 'http-503' || c === 'tempo'){ clearTimeout(avviso); throw e; }
    r = await giro(20000);   /* una seconda volta: la rete del telefono cade spesso per un attimo */
  } finally { clearTimeout(avviso); }
  return String((r && r.testo) || '').trim();
}
async function dtVia(){
  if (DT.on) return;
  DT.testo = ''; DT.cur = '';
  DT.range = null;
  try{ const sel = DT.doc && DT.doc.getSelection && DT.doc.getSelection(); if (sel && sel.rangeCount) DT.range = sel.getRangeAt(0).cloneRange(); }catch(_){ }
  if (dtRegistraPuo()){
    try{
      await dtRegistraVia();
      DT.reg = true; DT.pronto = true;
      DT.on = true; dtW().classList.add('on'); dtW().classList.remove('attesa', 'scrive'); dtOndaGiro(true);
      try{ flSchermoAcceso('dettatura', true); }catch(_){ }
      try{ flVibra(12); }catch(_){ }
      return;
    }catch(e){ DT.reg = false; try{ await dtRegistraFine(true); }catch(_){ } }
  }
  DT.reg = false;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.dictationStart){ toast('Disponibile solo nell’app installata'); return; }
  try{
    /* 0.9.285: con gli Appunti AI il telefono mette anche la punteggiatura (Android 13+) */
    await NATIVE.dictationStart({ formatta: dtAiOn() });
    /* 0.9.289, Andrea: "si mangia pezzi all'inizio". Il riconoscitore ascolta davvero solo da quando dice "pronto"
       (onReadyForSpeech): fino ad allora la pillola resta in attesa, e al "pronto" vibra. */
    DT.pronto = false;
    DT.on = true; dtW().classList.add('on', 'attesa'); dtOndaGiro(true);
    try{ flSchermoAcceso('dettatura', true); }catch(_){ }
    try{ flVibra(12); }catch(_){ }
  }catch(e){ toast(e && e.code === 'permission' ? 'Concedi il microfono e ritocca il pulsante' : 'Dettatura non disponibile'); }
}
function dtTesto(){ /* niente testo a schermo: lo legge solo dtScrivi; la forma d'onda la disegna dtOndaGiro */ }
/* 0.9.285, Andrea: "con gli Appunti AI mi mangia le parole". Il parziale del telefono contiene gia' i pezzi chiusi
   (FocusLockPlugin: quello che hai detto finora + il pezzo in corso): attaccarlo a DT.testo ripeteva tutto due volte, e
   chi riceveva il doppione (gli appunti) ne toglieva un pezzo. Si unisce senza doppioni. */
function dtUnisci(a, b){
  a = String(a || '').trim(); b = String(b || '').trim();
  if (!b) return a;
  if (!a) return b;
  if (b.indexOf(a) === 0) return b;
  if (a.indexOf(b) === 0) return a;
  return a + ' ' + b;
}
function dtOra(){ return dtUnisci(DT.testo, DT.cur); }
function dtParole(t){ return String(t || '').trim() ? String(t).trim().split(/\s+/).length : 0; }
async function dtFatto(){
  if (!DT.on) return;
  if (DT.reg){
    /* 0.9.342, Andrea: "si mangia le ultime parole". Come Wispr Flow (holdForPostRelease: dopo il rilascio il microfono resta
       acceso e misura il volume finche' la voce non tace): si registra ancora finche' ci sono 300 ms di silenzio, al massimo 1,4 s */
    await dtCoda();
    const el0 = DT.el, doc0 = DT.doc, fatto0 = DT.fatto, range0 = DT.range;
    const a = await dtRegistraFine(false);
    DT.on = false; DT.reg = false; dtOndaGiro(false);
    const w = document.getElementById('dtW'); if (w){ w.classList.remove('on'); w.classList.add('scrive'); }
    if (!a){ if (w) w.classList.remove('scrive'); try{ flSchermoAcceso('dettatura', false); }catch(_){ } return; }
    DTR.ultimo = a;
    try{ if (typeof drvAggiungi === 'function') drvAggiungi(a.blob, a.mime, a.sec); }catch(_){ }
    let t = '';
    try{ t = await dtTrascrivi(a); }
    catch(e){
      const c = String((e && e.code) || '');
      if (w) w.classList.remove('scrive');
      try{ flSchermoAcceso('dettatura', false); }catch(_){ }
      if (c === 'http-402' || c === 'http-429'){ try{ localStorage.setItem('fl_dt_ai_pausa', new Date().toDateString()); }catch(_){ } toast('I minuti della dettatura con l’AI sono finiti per oggi: da adesso detti con il telefono'); }
      else toast('Non sono riuscito a trascrivere: tocca il microfono e riprova');
      return;
    }
    if (w) w.classList.remove('scrive');
    DT.el = el0; DT.doc = doc0; DT.fatto = fatto0; DT.range = range0;
    if (!t){ try{ flSchermoAcceso('dettatura', false); }catch(_){ } toast('Non ho sentito parole: riprova più vicino al telefono'); if (DT.fatto) dtSoloFine(); return; }
    dtConsegna(t);
    return;
  }
  /* 0.9.289: "e alla fine della frase": la spunta fermava subito il microfono e l'ultima parola, ancora da elaborare,
     si perdeva. Si ascolta ancora un attimo, poi si chiude. */
  await new Promise(function(ok){ setTimeout(ok, 650); });
  try{ await NATIVE.dictationStop(); }catch(_){ }
  /* il riconoscitore consegna la frase finale poco dopo: se non arriva, vale tutto quello che si e' sentito fin qui */
  setTimeout(function(){ if (DT.on) dtScrivi(); }, 2000);
}
/* 0.9.254, Andrea: la dettatura standard e' per tutti; con Premium e l'interruttore «Appunti AI»
   la frase passa dal server (/api/focuslock/agent/chat/appunti) e torna con punteggiatura, a capo
   ed elenchi. Se il server non risponde entro pochi secondi, vale la frase com'era. */
function dtAiOn(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium() && typeof SETTINGS !== 'undefined' && SETTINGS.dictationAi === true); }catch(_){ return false; } }
async function dtAppuntiAi(t){
  if (typeof agApi !== 'function') return t;
  const r = await Promise.race([agApi('POST', '/api/focuslock/agent/chat/appunti', { testo: t }), new Promise(function(ok){ setTimeout(function(){ ok(null); }, 9000); })]);
  const out = r && typeof r.testo === 'string' ? r.testo.trim() : '';
  return out || t;
}
function dtScrivi(){
  const t0 = dtOra();
  if (t0.length >= 15 && dtAiOn()){
    const el0 = DT.el, doc0 = DT.doc, fatto0 = DT.fatto;
    try{ toast('Sistemo gli appunti…'); }catch(_){ }
    dtAppuntiAi(t0).then(function(t){ DT.el = el0; DT.doc = doc0; DT.fatto = fatto0; dtConsegna(t); }, function(){ DT.el = el0; DT.doc = doc0; DT.fatto = fatto0; dtConsegna(t0); });
    DT.on = false; DT.testo = ''; DT.cur = ''; dtOndaGiro(false);
    try{ flSchermoAcceso('dettatura', false); }catch(_){ }
    const w0 = document.getElementById('dtW'); if (w0) w0.classList.remove('on');
    return;
  }
  dtConsegna(t0);
}
function dtConsegna(t){
  try{ flSchermoAcceso('dettatura', false); }catch(_){ }
  DT.on = false; DT.testo = ''; DT.cur = ''; dtOndaGiro(false);
  const w = document.getElementById('dtW'); if (w) w.classList.remove('on');
  const el = DT.el, doc = DT.doc;
  /* 0.9.235: un campo col suo microfono (la ricerca delle note) riceve la frase dalla sua funzione */
  if (DT.fatto){ const f = DT.fatto; dtSoloFine(); if (t){ try{ f(t); flVibra([10, 30, 10]); }catch(_){ } } return; }
  /* 0.9.231: il microfono delle note veloci detta senza aprire la tastiera: la frase va a una funzione */
  const fn = el && el.getAttribute && el.getAttribute('data-dt-aggiungi');
  if (fn && typeof window[fn] === 'function'){ try{ if (t) window[fn](t); else window[fn](''); }catch(_){ } return; }
  if (!t || !doc) return;
  /* 0.9.282, Andrea: "nelle note premo la spunta e il testo non arriva". Il fuoco era gia' uscito dalla nota, e l'editor
     delle note puo' aver ricreato il campo: si ritrova il campo vero, si rimette il cursore dov'era e si scrive li'.
     Se il comando del browser non scrive, il testo si inserisce a mano e si avvisa l'editor con un evento input. */
  let campo = el;
  try{
    if (!campo || !campo.isConnected) campo = (doc.activeElement && (doc.activeElement.isContentEditable || /^(INPUT|TEXTAREA)$/.test(doc.activeElement.tagName))) ? doc.activeElement : doc.querySelector('[contenteditable="true"]');
  }catch(_){ }
  if (!campo) return;
  try{
    try{ if (doc.defaultView && doc.defaultView.focus) doc.defaultView.focus(); }catch(_){ }
    campo.focus();
    const prima = campo.isContentEditable ? (campo.textContent || '') : (campo.value || '');
    const spazio = prima && !/\s$/.test(prima) ? ' ' : '';
    if (campo.isContentEditable){
      const sel = doc.getSelection && doc.getSelection();
      if (sel && DT.range && campo.contains(DT.range.startContainer)){ sel.removeAllRanges(); sel.addRange(DT.range); }
      else if (sel && (!sel.rangeCount || !campo.contains(sel.anchorNode))){ const r = doc.createRange(); r.selectNodeContents(campo); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); }
      let ok = false; try{ ok = doc.execCommand('insertText', false, spazio + t); }catch(_){ ok = false; }
      if (!ok && sel && sel.rangeCount){
        const r = sel.getRangeAt(0); r.deleteContents(); const n = doc.createTextNode(spazio + t); r.insertNode(n);
        r.setStartAfter(n); r.collapse(true); sel.removeAllRanges(); sel.addRange(r);
        campo.dispatchEvent(new (doc.defaultView || window).Event('input', { bubbles: true }));
      }
    } else { campo.value = prima + spazio + t; campo.dispatchEvent(new (doc.defaultView || window).Event('input', { bubbles: true })); }
    DT.range = null;
    try{ flVibra([10, 30, 10]); }catch(_){ }
  }catch(_){ }
}
async function dtAnnulla(){
  if (!DT.on) return;
  try{ flSchermoAcceso('dettatura', false); }catch(_){ }
  DT.on = false; DT.testo = ''; DT.cur = ''; dtOndaGiro(false);
  if (DT.reg){ DT.reg = false; try{ await dtRegistraFine(true); }catch(_){ } }
  else try{ await NATIVE.dictationCancel(); }catch(_){ }
  const w = document.getElementById('dtW'); if (w) w.classList.remove('on');
  if (DT.fatto){ dtSoloFine(); return; }
  /* dettato senza tastiera (le note veloci): annullando il microfono sparisce */
  try{ if (w && DT.el && DT.el.getAttribute && DT.el.getAttribute('data-dt-aggiungi') && !(DT.el.ownerDocument && DT.el.ownerDocument.activeElement === DT.el)) w.hidden = true; }catch(_){ }
}
/* 0.9.235, Andrea: UN SOLO MICROFONO. Un campo che ha gia' il suo pulsante (la barra di ricerca delle
   note, nell'iframe) chiama dtAvviaSu(campo, fatto, ancora): il microfono che galleggia non compare
   (il campo ha data-no-dettatura), si vede subito la pillola con l'onda sopra ad ancora (la barra), la
   spunta passa la frase a fatto(t), la X la butta. Risponde "ok" se ascolta, "spenta" se la dettatura
   non e' accesa (Premium e Personalizza), "no" senza l'app installata, "errore" se non e' partita. */
/* 0.9.242: opz.nascosto (la chat dell'agente): la pillola non compare per niente, perche' il campo
   mostra da solo che sta ascoltando (il microfono del campo diventa l'onda con il tempo). Il livello
   della voce si legge da DT.lvl. */
async function dtAvviaSu(el, fatto, ancora, opz){
  if (!el) return 'no';
  if (!dtPuo()) return 'spenta';
  if ((typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.dictationStart) && !dtRegistraPuo()) return 'no';
  if (DT.on) return DT.fatto ? 'ok' : 'errore';
  clearTimeout(DT.t);
  DT.el = el; DT.doc = el.ownerDocument; DT.fatto = typeof fatto === 'function' ? fatto : null; DT.ancora = ancora || el;
  const w = dtW();
  if (opz && opz.nascosto){ w.classList.remove('solo', 'on'); w.hidden = true; DT.nascosto = true; }
  else { w.classList.add('solo', 'on'); w.hidden = false; dtPosiziona(); setTimeout(dtPosiziona, 350); setTimeout(dtPosiziona, 900); }
  await dtVia();
  if (!DT.on){ dtSoloFine(); return 'errore'; }
  return 'ok';
}
/* uscendo dal campo mentre ascolta (si chiude la ricerca), la dettatura si ferma */
function dtFermaSu(el){
  if (!DT.fatto || DT.el !== el) return;
  if (DT.on) dtAnnulla(); else dtSoloFine();
}
function dtSoloFine(){
  DT.fatto = null; DT.ancora = null; DT.nascosto = false;
  const w = document.getElementById('dtW');
  if (w){ w.classList.remove('solo', 'on'); w.hidden = true; }
}
function dtAscolta(doc){
  if (!doc || doc._dt) return; doc._dt = true;
  doc.addEventListener('focusin', function(e){ dtMostra(e.target); });
  doc.addEventListener('focusout', function(){ dtNascondi(); setTimeout(dtStato, 300); });
  /* il tocco e la scrittura lo richiamano anche se l'evento del fuoco non arriva (alcune WebView) */
  doc.addEventListener('pointerup', function(){ setTimeout(function(){ dtMostra(doc.activeElement); }, 60); });
  doc.addEventListener('input', function(e){ dtMostra(e.target); });
}
dtAscolta(document);
/* il Notion: il suo documento si ascolta appena l'iframe ha caricato */
(function aggancia(){
  const f = document.getElementById('ntFrame');
  if (!f){ setTimeout(aggancia, 1500); return; }
  const prova = function(){ try{ if (f.contentDocument && f.contentDocument.readyState !== 'uninitialized') dtAscolta(f.contentDocument); }catch(_){ } };
  f.addEventListener('load', function(){ try{ f.contentDocument._dt = false; }catch(_){ } prova(); });
  prova();
})();
/* le note (mappa-note.js): anche il loro documento */
(function agganciaNote(){
  const f = document.getElementById('noFrame');
  if (!f){ setTimeout(agganciaNote, 1500); return; }
  const prova = function(){ try{ if (f.contentDocument && f.contentDocument.readyState !== 'uninitialized') dtAscolta(f.contentDocument); }catch(_){ } };
  f.addEventListener('load', function(){ try{ f.contentDocument._dt = false; }catch(_){ } prova(); });
  prova();
})();
if (window.visualViewport){ window.visualViewport.addEventListener('resize', function(){ dtTastiera(); dtPosiziona(); }); window.visualViewport.addEventListener('scroll', dtPosiziona); }
window.addEventListener('resize', function(){ dtTastiera(); dtPosiziona(); });
try{
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.addListener) NATIVE.addListener('dictation', function(ev){
    if (!DT.on || !ev) return;
    if (ev.state === 'ready' && !DT.pronto){ DT.pronto = true; const w = document.getElementById('dtW'); if (w) w.classList.remove('attesa'); try{ flVibra(15); }catch(_){ } return; }
    if (ev.state === 'partial'){ DT.cur = ev.text || ''; dtTesto(); }
    else if (ev.state === 'segment'){ DT.testo = ev.text || DT.testo; DT.cur = ''; dtTesto(); }
    else if (ev.state === 'final'){
      /* la frase finale vince, ma mai se ha meno parole di quelle gia' sentite: il resto andrebbe perso */
      const fin = String(ev.text || '').trim(), ora = dtOra();
      DT.testo = (fin && dtParole(fin) >= dtParole(ora) - 1) ? fin : ora;
      DT.cur = ''; dtScrivi();
    }
    else if (ev.state === 'level'){ DT.lvl = Math.max(DT.lvl, Math.max(0, Math.min(1, ((+ev.rms || 0) + 2) / 12))); }
    /* 0.9.285: si e' interrotta, ma quello che hai gia' detto non si butta */
    else if (ev.state === 'error'){
      if (dtOra()){ toast('La dettatura si è interrotta: scrivo quello che hai detto'); dtScrivi(); }
      else { toast('La dettatura si è interrotta'); dtAnnulla(); }
    }
  });
}catch(_){ }

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.dt-w{position:fixed;right:14px;bottom:14px;z-index:9500;display:flex;justify-content:flex-end;transition:bottom .15s;touch-action:none}.dt-w.calamita{transition:bottom .15s,transform .22s cubic-bezier(.2,.8,.2,1)}.dt-w[hidden]{display:none}',
    '.dt-mic{width:54px;height:54px;border-radius:50%;border:0;background:#E3F1FF;color:#0075E3;box-shadow:0 8px 22px rgba(0,117,227,.3);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.dt-pill{display:none;align-items:center;gap:6px;background:#0E2350;border-radius:99px;padding:4px;box-shadow:0 8px 22px rgba(0,30,68,.35)}',
    '.dt-w.on .dt-mic{display:none}.dt-w.on .dt-pill{display:flex}.dt-w.solo .dt-mic{display:none}',
    '.dt-w.attesa .dt-onda{opacity:.35}.dt-w.attesa .dt-pill{box-shadow:0 0 0 3px rgba(91,192,248,.5)}',
    /* mentre il testo arriva da Scribe: la pillola resta, con i tre puntini al posto dell'onda */
    '.dt-w.scrive .dt-mic{display:none}.dt-w.scrive .dt-pill{display:flex}.dt-w.scrive .dt-x,.dt-w.scrive .dt-ok{opacity:.35;pointer-events:none}.dt-w.scrive .dt-onda i{animation:dtPunti 1s ease-in-out infinite}.dt-w.scrive .dt-onda i:nth-child(3n+2){animation-delay:.15s}.dt-w.scrive .dt-onda i:nth-child(3n){animation-delay:.3s}@keyframes dtPunti{0%,100%{height:3px;opacity:.4}50%{height:12px;opacity:1}}',
    '.dt-x,.dt-ok{flex:none;width:30px;height:30px;border-radius:50%;border:0;display:grid;place-items:center;font:800 13px var(--font-body);cursor:pointer}.dt-x{background:rgba(255,255,255,.14);color:#fff}.dt-ok{background:#0075E3;color:#fff}',
    '.dt-cosa{width:70px;display:flex;align-items:center;padding:0 2px}',
    '.dt-onda{display:flex;align-items:center;justify-content:space-between;height:22px;width:100%}.dt-onda i{flex:none;width:2.5px;height:3px;border-radius:2px;background:#fff;opacity:.45;transition:height .07s linear}'
  ].join('');
  document.head.appendChild(st);
})();

/* 0.9.282, Andrea: "ogni domanda a opzioni deve avere Lo scrivo io, con il microfono DENTRO al riquadro".
   micArea(id) disegna il riquadro con il suo microfono nell'angolo; micAvvolgi(box) lo aggiunge ai riquadri
   gia' disegnati (le scene del Genio). Tocco sul microfono: parte la dettatura con la sua pillola (spunta e X);
   la spunta aggiunge la frase in fondo a quello che c'e' gia' scritto. */
const MIC_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>';
function micArea(id, righe, segnaposto){
  return '<div class="mic-box"><textarea class="gn-area" id="' + id + '" rows="' + (righe || 3) + '" placeholder="' + String(segnaposto || 'Scrivi qui…').replace(/"/g, '&quot;') + '" data-no-dettatura onclick="event.stopPropagation()"></textarea>'
    + '<button type="button" class="mic-btn" aria-label="Detta con la voce" onclick="event.stopPropagation();micTocca(\'' + id + '\', this)">' + MIC_SVG + '</button></div>';
}
function micAvvolgi(box){
  if (!box || !box.querySelectorAll) return;
  box.querySelectorAll('textarea.gn-area').forEach(function(t){
    if (t.closest('.mic-box') || !t.id) return;
    const w = document.createElement('div'); w.className = 'mic-box';
    t.parentNode.insertBefore(w, t); w.appendChild(t);
    t.setAttribute('data-no-dettatura', '');
    const b = document.createElement('button'); b.type = 'button'; b.className = 'mic-btn'; b.setAttribute('aria-label', 'Detta con la voce'); b.innerHTML = MIC_SVG;
    b.addEventListener('click', function(e){ e.stopPropagation(); micTocca(t.id, b); });
    w.appendChild(b);
  });
}
/* 0.9.288, Andrea: "il pulsante per il microfono nella text area dovrebbe SEMPRE comparire". Ogni casella di testo a
   piu' righe riceve il suo microfono da sola, appena compare: niente piu' caselle dimenticate (come quella della
   stagione di spinta). Restano fuori le righe singole (hanno il microfono che galleggia sulla tastiera), quelle di
   sola lettura, quelle nascoste e chi chiede data-no-mic. */
let MIC_N = 0;
function micAvvolgiTutte(){
  try{
    document.querySelectorAll('textarea').forEach(function(t){
      if (t.closest('.mic-box') || t.hasAttribute('data-no-mic') || t.closest('[data-no-mic]') || t.readOnly || t.hidden) return;
      const righe = +t.getAttribute('rows') || 2;
      if (righe < 2 || t.closest('.ag-comp, .umc-comp')) return;
      if (document.activeElement === t) return;
      if (!t.id) t.id = 'micT' + (++MIC_N);
      const w = document.createElement('div'); w.className = 'mic-box';
      /* 0.9.289, Andrea: "il microfono compare fuori dalla casella". Il margine sotto della casella finiva dentro al
         riquadro e il pulsante (in basso a destra del riquadro) cadeva nello spazio vuoto: il margine passa al riquadro. */
      try{ const cs = getComputedStyle(t); w.style.marginTop = cs.marginTop; w.style.marginBottom = cs.marginBottom; t.style.setProperty('margin-top', '0', 'important'); t.style.setProperty('margin-bottom', '0', 'important'); }catch(_){ }
      t.parentNode.insertBefore(w, t); w.appendChild(t);
      t.setAttribute('data-no-dettatura', '');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'mic-btn'; b.setAttribute('aria-label', 'Detta con la voce'); b.innerHTML = MIC_SVG;
      b.addEventListener('click', function(e){ e.stopPropagation(); micTocca(t.id, b); });
      w.appendChild(b);
    });
    /* 0.9.294, Andrea: "nella casella del nome, quando il Genio chiede come ti chiami, non c'e' il microfono: deve esserci
       sempre, in ogni casella, a destra". Anche le caselle a una riga, con il microfono centrato sulla destra. Restano
       fuori password, email, numeri, ore e date, e le caselle troppo strette per starci. */
    document.querySelectorAll('input').forEach(function(t){
      const tipo = (t.getAttribute('type') || 'text').toLowerCase();
      if (tipo !== 'text' && tipo !== 'search') return;
      if (t.closest('.mic-box') || t.hasAttribute('data-no-mic') || t.closest('[data-no-mic]') || t.readOnly || t.disabled || t.hidden) return;
      if (t.closest('.ag-comp, .umc-comp')) return;
      /* 0.9.295: nelle pagine fatte di righe (Il tuo perche', gli orizzonti) ogni riga e' una casella: un microfono per riga
         era un muro di microfoni. Li' detta la tastiera, con il suo microfono. */
      if (t.closest('.why-rows, .why-sechead, .oz-passi, .rs-righe, [data-righe]')) return;
      if (!t.offsetParent || t.offsetWidth < 150) return;
      if (document.activeElement === t) return;
      if (!t.id) t.id = 'micT' + (++MIC_N);
      const w = document.createElement('div'); w.className = 'mic-box mic-riga';
      try{
        const cs = getComputedStyle(t);
        w.style.marginTop = cs.marginTop; w.style.marginBottom = cs.marginBottom;
        if (cs.display !== 'block' && cs.flexGrow !== '0') w.style.flex = cs.flex;
        if (cs.textAlign === 'center') t.style.setProperty('padding-left', '50px', 'important');
        t.style.setProperty('margin-top', '0', 'important'); t.style.setProperty('margin-bottom', '0', 'important');
      }catch(_){ }
      t.parentNode.insertBefore(w, t); w.appendChild(t);
      t.setAttribute('data-no-dettatura', '');
      const b = document.createElement('button'); b.type = 'button'; b.className = 'mic-btn'; b.setAttribute('aria-label', 'Detta con la voce'); b.innerHTML = MIC_SVG;
      b.addEventListener('click', function(e){ e.stopPropagation(); micTocca(t.id, b); });
      w.appendChild(b);
    });
  }catch(_){ }
}
if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined'){
  let micT = 0;
  const avvia = function(){
    try{ new MutationObserver(function(){ clearTimeout(micT); micT = setTimeout(micAvvolgiTutte, 60); }).observe(document.body, { childList: true, subtree: true }); }catch(_){ }
    micAvvolgiTutte();
  };
  if (document.body) avvia(); else document.addEventListener('DOMContentLoaded', avvia);
}
async function micTocca(id, btn){
  const t = document.getElementById(id); if (!t) return;
  if (DT.on && DT.el === t){ dtFatto(); return; }
  if (btn) btn.classList.add('on');
  const fine = function(){ if (btn) btn.classList.remove('on'); };
  const r = await dtAvviaSu(t, function(frase){
    fine();
    const prima = t.value || '';
    t.value = prima + (prima && !/\s$/.test(prima) ? ' ' : '') + frase;
    t.dispatchEvent(new Event('input', { bubbles: true }));
  }, t.closest('.mic-box') || t);
  if (r !== 'ok'){
    fine();
    if (r === 'spenta') toast('Accendi la dettatura in Personalizza');
    else if (r === 'no') toast('Disponibile solo nell’app installata');
  } else {
    const giro = setInterval(function(){ if (!DT.on && !DT.fatto){ fine(); clearInterval(giro); } }, 400);
  }
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.mic-box{position:relative}.mic-box textarea{padding-right:52px !important;width:100%;box-sizing:border-box}'
    + '.mic-box.mic-riga{display:block;width:100%}.mic-box.mic-riga input{padding-right:50px !important;width:100%;box-sizing:border-box}'
    + '.mic-box.mic-riga .mic-btn{bottom:auto;top:50%;transform:translateY(-50%);width:34px;height:34px}'
    + '.mic-btn{position:absolute;right:8px;bottom:10px;width:38px;height:38px;border-radius:50%;border:0;background:#E3F1FF;color:#0075E3;display:flex;align-items:center;justify-content:center;cursor:pointer}'
    + '.mic-btn.on{background:#E5484D;color:#fff;animation:micPulsa 1.2s ease-in-out infinite}'
    + 'body.dark .mic-btn{background:#16305A;color:#BCE0FF}body.dark .mic-btn.on{background:#E5484D;color:#fff}'
    + '@keyframes micPulsa{0%,100%{box-shadow:0 0 0 0 rgba(229,72,77,.45)}50%{box-shadow:0 0 0 8px rgba(229,72,77,0)}}';
  document.head.appendChild(st);
})();
