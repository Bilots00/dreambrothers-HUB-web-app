/* ===========================================================================================
   LE REVISIONI DELLA SETTIMANA, DEL MESE, DEL TRIMESTRE E DELL'ANNO (0.9.253, rifatte nella 0.9.310)

   Andrea: oltre alla revisione della sera (revisione.js) servono una revisione settimanale, una
   mensile, una trimestrale e una dell'anno, con la stessa card in cima alle schede quando e' il momento.

   0.9.310, Andrea (screenshot 731-737): "le revisioni sono pessime".
     1. UNA REVISIONE SOLA. Se nello stesso giorno toccano la sera, la settimana e il mese, in Dream
        c'erano piu' pannelli e non si capiva quale fare. Adesso c'e' una card sola, quella del periodo
        piu' grande, e chi la fa chiude anche le altre (la settimana dentro al mese, la sera di oggi:
        rvpInclusi). La card della sera si nasconde da sola finche' c'e' una revisione di periodo da
        fare (rvStato in revisione.js).
     2. PRIMA IL RECAP, POI LA DOMANDA. I numeri del periodo (dove sta l'arrivo al sogno e quanto si
        e' spostato, le sessioni di Full Focus, le tappe) stanno in una schermata loro, "Ecco com'e'
        andato ottobre", e la domanda arriva dopo con subito le sue opzioni.
     3. DOMANDE CHE SEGUONO LE RISPOSTE. Niente piu' quattro domande fisse senza filo: un albero, come
        il motore della sfida del Genio. Ogni opzione porta alla sua domanda ("Instagram" -> "In quale
        momento ti prendeva di piu' Instagram?" -> "Cosa cambi con Instagram da domani?"). Con Premium
        la revisione e' una chat con il tuo agente personale (conversa.js): il primo messaggio (il
        recap e la prima domanda) lo scrive l'app all'istante, l'agente continua dalla risposta.
     4. MAI OBBLIGATORIO. Lo scritto e' sempre facoltativo: a campo vuoto il pulsante dice "Salta".
     5. IL RIEPILOGO SERVE: cosa ha funzionato, cosa ti ha fatto perdere tempo, la prossima mossa (con
        il pulsante che la fa, quando si puo'), e il ricalcolo del percorso solo con il tuo si'.

   Quando compare:
     - settimana: dalla domenica alle 15 a tutto il lunedi'  (periodo: anno-Wnn)
     - mese: dall'ultimo giorno del mese alle 12 fino al 2 del mese dopo  (periodo: anno-mm)
     - trimestre: dagli ultimi tre giorni di marzo/giugno/settembre/dicembre fino al 5 del
       mese dopo  (periodo: anno-Qn)
     - anno: dal 27 dicembre al 7 gennaio
   Si salva in fl_revisioni_periodo: [{ tipo, periodo, at, r: { <chiave>, <chiave>Testo }, riepilogo,
   percorso, inclusi, dati }], e la legge il tuo agente personale (rvpPerAgente, dentro rnPerAgente:
   finisce nel brief con cui l'agente rifa' la roadmap).
   =========================================================================================== */
const RVP_KEY = 'fl_revisioni_periodo';
const RVP = { tipo: '', passo: '', storia: [], r: {}, dati: null, opz: [], scrivoPer: '', percorso: [], inclusi: [], app: null, fatto: false };
const RVP_NOMI = { settimana: 'La revisione della settimana', mese: 'La revisione del mese', trimestre: 'La revisione del trimestre', anno: 'La revisione dell’anno' };
const RVP_ICO = { settimana: '📅', mese: '🗓️', trimestre: '🧭', anno: '🎆' };
const RVP_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
function rvpEsc(s){ return (typeof gnEsc === 'function') ? gnEsc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function rvpLista(){ try{ return JSON.parse(localStorage.getItem(RVP_KEY) || '[]') || []; }catch(_){ return []; } }
function rvpSalvaLista(l){ try{ localStorage.setItem(RVP_KEY, JSON.stringify(l.slice(-60))); }catch(_){ } }
function rvpSettimanaIso(d){
  const x = new Date(d); x.setHours(0, 0, 0, 0);
  const g = (x.getDay() + 6) % 7; x.setDate(x.getDate() - g + 3);
  const anno = x.getFullYear();
  const g4 = new Date(anno, 0, 4); const n = 1 + Math.round(((x - g4) / 86400000 - 3 + ((g4.getDay() + 6) % 7)) / 7);
  return anno + '-W' + String(n).padStart(2, '0');
}
/** Il periodo che una revisione di quel tipo riguarda, se adesso e' il momento di farla; altrimenti ''. */
function rvpPeriodoDovuto(tipo){
  const d = new Date(), h = d.getHours(), g = d.getDay(), gm = d.getDate();
  const ultimo = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  if (tipo === 'settimana'){
    if ((g === 0 && h >= 15) || g === 1){ const rif = new Date(d); if (g === 1) rif.setDate(rif.getDate() - 1); return rvpSettimanaIso(rif); }
    return '';
  }
  if (tipo === 'mese'){
    if (gm === ultimo && h >= 12) return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
    if (gm <= 2){ const p = new Date(d.getFullYear(), d.getMonth() - 1, 1); return p.getFullYear() + '-' + String(p.getMonth() + 1).padStart(2, '0'); }
    return '';
  }
  if (tipo === 'anno'){
    /* dal 27 dicembre al 7 gennaio: l'anno che finisce */
    if (d.getMonth() === 11 && gm >= 27) return String(d.getFullYear());
    if (d.getMonth() === 0 && gm <= 7) return String(d.getFullYear() - 1);
    return '';
  }
  if (tipo === 'trimestre'){
    const m = d.getMonth();
    if ([2, 5, 8, 11].indexOf(m) >= 0 && gm >= ultimo - 2) return d.getFullYear() + '-Q' + (Math.floor(m / 3) + 1);
    if ([0, 3, 6, 9].indexOf(m) >= 0 && gm <= 5){ const p = new Date(d.getFullYear(), m - 1, 1); return p.getFullYear() + '-Q' + (Math.floor(p.getMonth() / 3) + 1); }
    return '';
  }
  return '';
}
function rvpFatta(tipo, periodo){ return rvpLista().some(function(x){ return x.tipo === tipo && x.periodo === periodo; }); }
const RVP_ORDINE = ['anno', 'trimestre', 'mese', 'settimana'];
/** La revisione da fare adesso (la piu' grande prima), o null. */
function rvpDovuta(){
  for (let i = 0; i < RVP_ORDINE.length; i++){ const p = rvpPeriodoDovuto(RVP_ORDINE[i]); if (p && !rvpFatta(RVP_ORDINE[i], p)) return { tipo: RVP_ORDINE[i], periodo: p }; }
  return null;
}
/**
 * UNA REVISIONE SOLA (0.9.310): le revisioni piu' piccole che si chiudono insieme a questa. Le revisioni di
 * periodo piu' piccole ancora da fare, e la revisione della sera di oggi (anche prima delle 17: in un giorno
 * si fa una revisione sola).
 */
function rvpInclusi(tipo){
  const out = [];
  RVP_ORDINE.slice(RVP_ORDINE.indexOf(tipo) + 1).forEach(function(t){ const p = rvpPeriodoDovuto(t); if (p && !rvpFatta(t, p)) out.push({ tipo: t, periodo: p }); });
  try{ if (typeof rvFattaOggi === 'function' && !rvFattaOggi()) out.push({ tipo: 'sera', periodo: (typeof rvOggi === 'function') ? rvOggi() : '' }); }catch(_){ }
  return out;
}

/* ---------- le parole del periodo ---------- */
function rvpMeseDi(periodo){ const m = /^(\d{4})-(\d{2})$/.exec(String(periodo || '')); return m ? +m[2] - 1 : new Date().getMonth(); }
/* "ad aprile", "ad agosto", ma "a ottobre" */
function rvpA(m){ return /^a/.test(RVP_MESI[m]) ? 'ad ' + RVP_MESI[m] : 'a ' + RVP_MESI[m]; }
function rvpParole(tipo, periodo){
  tipo = tipo || RVP.tipo; periodo = periodo || RVP.periodo;
  if (tipo === 'mese'){
    const m = rvpMeseDi(periodo), dopo = (m + 1) % 12;
    return { in: rvpA(m), nome: RVP_MESI[m], recap: 'Ecco *com’è andato ' + RVP_MESI[m] + '*.', prossimo: rvpA(dopo), card: 'Com’è andato ' + RVP_MESI[m] + ': cosa ti ha avvicinato al sogno e cosa cambiare.' };
  }
  if (tipo === 'trimestre') return { in: 'in questi tre mesi', nome: 'il trimestre', recap: 'Ecco *com’è andato il trimestre*.', prossimo: 'nei prossimi tre mesi', card: 'Tre mesi verso il sogno: cosa ha funzionato e cosa cambiare.' };
  if (tipo === 'anno'){
    const a = /^\d{4}$/.test(String(periodo)) ? +periodo : new Date().getFullYear();
    return { in: 'nel ' + a, nome: 'il ' + a, recap: 'Ecco *com’è andato il ' + a + '*.', prossimo: 'nel ' + (a + 1), card: 'Il ' + a + ' verso il sogno: cosa ha funzionato e cosa cambiare.' };
  }
  return { in: 'in questi sette giorni', nome: 'la settimana', recap: 'Ecco *com’è andata la settimana*.', prossimo: 'la prossima settimana', card: 'Com’è andata la settimana: cosa ti ha avvicinato al sogno e cosa cambiare.' };
}

/* ---------- i dati veri del periodo ---------- */
function rvpDa(tipo){
  const d = new Date();
  if (tipo === 'settimana'){ const x = new Date(d); x.setDate(x.getDate() - 7); return x.getTime(); }
  if (tipo === 'mese'){ const x = new Date(d.getFullYear(), d.getMonth() - (d.getDate() <= 2 ? 1 : 0), 1); return x.getTime(); }
  if (tipo === 'anno'){ const x = new Date(d); x.setDate(x.getDate() - 365); return x.getTime(); }
  const x = new Date(d); x.setDate(x.getDate() - 91); return x.getTime();
}
/* la fine del periodo: per il mese rivisto il 1 o il 2 del mese dopo, l'ultimo giorno del mese rivisto */
function rvpFino(tipo){
  const d = new Date();
  if (tipo === 'mese' && d.getDate() <= 2) return new Date(d.getFullYear(), d.getMonth(), 1).getTime();
  return Date.now() + 60000;
}
function rvpRaccogli(tipo){
  const da = rvpDa(tipo), fino = rvpFino(tipo);
  const out = { ff: 0, min: 0, mollate: 0, tappe: 0, sere: 0, tappa: '', vinti: 0, persi: 0, app: '', ffFasce: { mattina: 0, pomeriggio: 0, sera: 0 } };
  try{ (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
    if (!x || x.meditazione || x.at < da || x.at >= fino) return;
    out.ff++; if (x.ok){ out.min += (x.spentMs || 0) / 60000; const h = new Date(x.at).getHours(); out.ffFasce[h < 12 ? 'mattina' : h < 18 ? 'pomeriggio' : 'sera']++; } else out.mollate++;
  }); }catch(_){ }
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; Object.keys(g).forEach(function(k){ const t = new Date(k + 'T12:00:00').getTime(); if (g[k] > 0 && t >= da && t < fino) out.tappe += g[k]; }); }catch(_){ }
  try{ out.sere = ((typeof rvLista === 'function') ? rvLista() : []).filter(function(x){ return x.at >= da && x.at < fino && !x.inclusaIn; }).length; }catch(_){ }
  try{ if (typeof ozAnello === 'function'){ const k = tipo === 'settimana' ? 'settimana' : tipo === 'mese' ? 'mese' : 'anno'; out.tappa = String((ozAnello(k) || {}).testo || '').trim(); } }catch(_){ }
  out.rotta = rvpRotta(da);
  return out;
}
/**
 * SEI SULLA ROTTA? Il giorno in cui arrivi al sogno oggi e com'era all'inizio del periodo (le istantanee
 * giornaliere del navigatore, eta.js, dello stesso sogno). { oggi, inizio, daK, giorni } o null.
 */
function rvpRotta(da){
  try{
    const s = (typeof ETA !== 'undefined' && ETA.stato) || ((typeof etaLeggi === 'function') ? etaLeggi('stato', null) : null);
    if (!s || !isFinite(s.p50)) return null;
    const out = { oggi: s.p50, inizio: null, daK: '', giorni: null };
    const snap = (typeof etaLeggi === 'function') ? (etaLeggi('snap', {}) || {}) : {};
    let sogno = ''; try{ const vg = (typeof etaViaggio === 'function') ? etaViaggio() : null; sogno = vg && typeof etaNorm === 'function' ? etaNorm(vg.target) : ''; }catch(_){ }
    const daK = (typeof etaKey === 'function') ? etaKey(da) : new Date(da).toISOString().slice(0, 10);
    const k = Object.keys(snap).sort().filter(function(x){ const v = snap[x]; return x >= daK && v && isFinite(v.p50) && (!sogno || !v.sogno || v.sogno === sogno); })[0];
    if (k && k < ((typeof etaOggiK === 'function') ? etaOggiK() : '9999')){
      out.inizio = snap[k].p50; out.daK = k;
      const mz = function(t){ const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
      out.giorni = Math.round((mz(out.oggi) - mz(out.inizio)) / 86400000);
    }
    return out;
  }catch(_){ return null; }
}
function rvpDataTxt(ts){ const d = new Date(ts); return d.getDate() + ' ' + RVP_MESI[d.getMonth()] + ' ' + d.getFullYear(); }
function rvpDalTxt(k){ const d = new Date(k + 'T12:00:00'); return 'dal ' + (d.getDate() === 1 ? '1°' : d.getDate()) + ' ' + RVP_MESI[d.getMonth()]; }
function rvpGiorniTxt(n){ n = Math.abs(n); return n === 1 ? '1 giorno' : n + ' giorni'; }
/** Fuori rotta: l'arrivo si e' spostato piu' in la', o la risposta dice fermo o indietro, o il sogno e' cambiato. */
function rvpFuoriRotta(){
  const r = RVP.r, ro = RVP.dati && RVP.dati.rotta;
  if (['fermo', 'indietro'].indexOf(r.rotta) >= 0) return true;
  if (['cambiato', 'strada', 'nonso'].indexOf(r.sogno) >= 0) return true;
  return !!(ro && ro.giorni > 0);
}
function rvpOre(min){ min = Math.round(min || 0); if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti'; const h = Math.floor(min / 60), m = min % 60; return h + (h === 1 ? ' ora' : ' ore') + (m ? ' e ' + m + (m === 1 ? ' minuto' : ' minuti') : ''); }
/** I fatti del periodo, uno per riga, scelti per importanza: dove sta l'arrivo, il lavoro concentrato, le tappe. */
function rvpRecapRighe(){
  const d = RVP.dati || {}, v = [];
  const ro = d.rotta;
  if (ro){
    let t = 'Il giorno in cui arrivi al sogno è il ' + rvpDataTxt(ro.oggi);
    if (ro.giorni != null && ro.daK){
      if (ro.giorni > 0) t += ': ' + rvpDalTxt(ro.daK) + ' si è spostato ' + rvpGiorniTxt(ro.giorni) + ' più in là.';
      else if (ro.giorni < 0) t += ': ' + rvpDalTxt(ro.daK) + ' si è avvicinato di ' + rvpGiorniTxt(ro.giorni) + '.';
      else t += ': ' + rvpDalTxt(ro.daK) + ' non si è spostato.';
    } else t += '.';
    v.push(['🧭', t]);
  }
  if (d.ff){
    const fin = d.ff - d.mollate;
    v.push(['⏱️', 'Hai fatto ' + (d.ff === 1 ? '1 sessione' : d.ff + ' sessioni') + ' di Full Focus: ' + rvpOre(d.min) + ' di lavoro concentrato'
      + (d.mollate ? (fin > 0 ? ', e ' + (d.mollate === 1 ? 'una l’hai interrotta' : d.mollate + ' le hai interrotte') : ', tutte interrotte') : '') + '.']);
  } else v.push(['⏱️', 'Non hai fatto sessioni di Full Focus.']);
  if (d.tappe) v.push(['🗺️', 'Hai completato ' + (d.tappe === 1 ? '1 tappa' : d.tappe + ' tappe') + ' della mappa.']);
  else v.push(['🗺️', 'Non hai completato tappe della mappa.']);
  if (d.sere && RVP.tipo !== 'settimana') v.push(['🌙', 'Hai fatto ' + (d.sere === 1 ? '1 revisione della sera' : d.sere + ' revisioni della sera') + '.']);
  return v;
}
/** Il recap per la chat (una bolla): la frase e i fatti, uno per riga. */
function rvpRecapTesto(){
  return rvpParole().recap + '\n' + rvpRecapRighe().map(function(r){ return r[0] + ' ' + r[1]; }).join('\n');
}
/** Le app che ti hanno preso piu' tempo nel periodo (dal pannello della rivelazione, conversa.js). */
function rvpApp(n){
  try{
    const p = (typeof CV !== 'undefined' && CV.pan) || null;
    return ((p && p.top) || []).filter(function(a){ return a && a.packageName && !a.self && !/dreambrothers\.focuslock/.test(a.packageName) && (a.ms || 0) >= 5 * 60000; })
      .slice(0, n || 4).map(function(a){ return { pkg: a.packageName, label: a.label || a.packageName, icon: a.icon || '', ms: a.ms || 0 }; });
  }catch(_){ return []; }
}
function rvpIcoApp(a){ return (typeof cvIcoApp === 'function') ? cvIcoApp(a) : '📱'; }
function rvpNomeAgente(){
  let n = 'Il Genio'; try{ n = (typeof agNomeSoggetto === 'function') ? agNomeSoggetto() : 'Il Genio'; }catch(_){ }
  return n === 'Il Genio' ? 'il Genio' : n;
}
function rvpMin(t){ t = String(t || ''); return t.charAt(0).toLowerCase() + t.slice(1); }

/* ---------------------------------------------------------------------------------------
   L'ALBERO DELLE DOMANDE (0.9.310). Ogni opzione: [chiave, icona, testo, nodo dopo]. "Lo scrivo io" porta a
   `dopo` (il nodo dopo quando la risposta e' scritta o saltata). Le domande dicono sempre il loro soggetto
   e il momento; le opzioni completano la domanda in italiano vero.
   --------------------------------------------------------------------------------------- */
function rvpRadice(){ return (RVP.tipo === 'trimestre' || RVP.tipo === 'anno') ? 'sogno' : 'rotta'; }
function rvpDopoCambio(){ return rvpFuoriRotta() ? 'ricalcolo' : 'fine'; }
function rvpNodo(id){
  const P = rvpParole(), app = RVP.app || {}, nomeApp = app.label || 'quell’app', d = RVP.dati || {};
  const dc = rvpDopoCambio();
  switch (id){
    case 'sogno': return { k: 'sogno', t: 'Il *sogno* da cui sei partito è ancora il tuo?', dopo: 'rotta', ph: 'Esempio: è lo stesso, ma adesso lo voglio fare in un’altra città',
      opz: [['si', '🎯', 'Sì, è ancora quello', 'rotta'], ['strada', '🛤️', 'Sì, ma cambio strada', 'rotta'], ['cambiato', '🔄', 'No, è cambiato', 'rotta'], ['nonso', '🌫️', 'Non lo so più', 'rotta']] };
    case 'rotta': return { k: 'rotta', t: 'Quanto ti sei *avvicinato al sogno* ' + P.in + '?', dopo: 'aiuto', ph: 'Esempio: ho fatto la parte facile, quella difficile no',
      opz: [['molto', '🚀', 'Molto', 'aiuto'], ['poco', '🚶', 'Un po’', 'aiuto'], ['fermo', '⏸️', 'Per niente', 'perso'], ['indietro', '↩️', 'Mi sono allontanato', 'perso']] };
    case 'aiuto': {
      const o = [];
      if (d.ff) o.push(['ff', '⏱️', 'Le sessioni di Full Focus', 'aiutoFf']);
      if (d.tappe) o.push(['tappe', '🗺️', 'Le tappe della mappa', 'aiutoQuando']);
      o.push(['orario', '⏰', 'Un orario fisso per il sogno', 'aiutoQuando'], ['blocchi', '🛡️', 'Le app bloccate mentre lavoro', 'perso'], ['persona', '🤝', 'Una persona che mi ha spinto', 'aiutoChi']);
      return { k: 'aiuto', t: 'Cosa ti ha *aiutato di più* ad avvicinarti al sogno ' + P.in + '?', dopo: 'perso', ph: 'Esempio: lavorare in biblioteca la mattina', opz: o };
    }
    case 'aiutoFf': return { k: 'quando', t: 'In quale momento della giornata ti riuscivano *meglio le sessioni di Full Focus*?', dopo: 'perso', ph: 'Esempio: subito dopo colazione',
      opz: rvpFasceOrdinate([['mattina', '🌅', 'La mattina', 'perso'], ['pomeriggio', '☀️', 'Il pomeriggio', 'perso'], ['sera', '🌙', 'La sera', 'perso']]).concat([['sempre', '🔁', 'In ogni momento', 'perso']]) };
    case 'aiutoQuando': return { k: 'quando', t: 'In quale momento della giornata *lavoravi meglio* al sogno ' + P.in + '?', dopo: 'perso', ph: 'Esempio: subito dopo colazione',
      opz: [['mattina', '🌅', 'La mattina', 'perso'], ['pomeriggio', '☀️', 'Il pomeriggio', 'perso'], ['sera', '🌙', 'La sera', 'perso'], ['sempre', '🔁', 'In ogni momento', 'perso']] };
    case 'aiutoChi': return { k: 'chi', t: 'Chi ti ha *spinto ad andare avanti* verso il sogno?', dopo: 'perso', ph: 'Esempio: mio fratello, che mi chiedeva ogni sera a che punto ero',
      opz: [['amico', '🙌', 'Un amico o un’amica', 'perso'], ['partner', '❤️', 'Il mio partner', 'perso'], ['famiglia', '🏠', 'Qualcuno della famiglia', 'perso'], ['collega', '💼', 'Un collega o un socio', 'perso']] };
    case 'perso': {
      const a = rvpApp(1)[0], o = [];
      if (a) o.push(['app:' + a.pkg, rvpIcoApp(a), a.label, 'appQuando', a]);
      else o.push(['app', '📱', 'Un’app sul telefono', 'appQuale']);
      o.push(['sera', '🌙', 'Un’abitudine della sera', 'seraQuale'], ['impegni', '🗓️', 'Gli impegni', 'impegniQuali'], ['energia', '🪫', 'La stanchezza', 'energiaPerche'], ['idee', '💡', 'Le idee nuove', 'ideeCosa'], ['niente', '🧭', 'Niente di particolare', 'mossa']);
      return { k: 'perso', t: 'Cosa ti ha fatto *perdere più tempo* ' + P.in + '?', dopo: 'mossa', ph: 'Esempio: le mattine passate a rispondere ai messaggi', opz: o };
    }
    case 'appQuale': {
      const l = rvpApp(4);
      return { k: 'app', t: 'Quale *app* ti ha fatto perdere più tempo ' + P.in + '?', dopo: 'mossa', ph: 'Esempio: YouTube',
        opz: l.map(function(a){ return ['app:' + a.pkg, rvpIcoApp(a), a.label, 'appQuando', a]; }) };
    }
    case 'appQuando': return { k: 'appQuando', t: 'In quale momento ti prendeva di più *' + nomeApp + '*?', dopo: 'mossa', ph: 'Esempio: quando aspettavo il treno',
      opz: [['sveglio', '🌅', 'Appena sveglio', 'mossa'], ['lavoro', '💼', 'Mentre lavoravo', 'mossa'], ['pause', '☕', 'Nelle pause', 'mossa'], ['letto', '🛏️', 'La sera a letto', 'mossa']] };
    case 'seraQuale': return { k: 'sera', t: 'Quale *abitudine della sera* ti ha tolto più tempo per il sogno?', dopo: 'mossa', ph: 'Esempio: i videogiochi fino all’una',
      opz: [['letto', '🛏️', 'Il telefono a letto', 'mossa'], ['serie', '📺', 'Serie e video fino a tardi', 'mossa'], ['tardi', '🌙', 'Andare a dormire tardi', 'mossa'], ['uscite', '🍻', 'Uscire tutte le sere', 'mossa']] };
    case 'impegniQuali': return { k: 'impegni', t: 'Quali *impegni* ti hanno tolto più tempo per il sogno?', dopo: 'mossa', ph: 'Esempio: i turni di notte al lavoro',
      opz: [['lavoro', '💼', 'Il lavoro', 'mossa'], ['studio', '📚', 'Lo studio', 'mossa'], ['famiglia', '🏠', 'La famiglia', 'mossa'], ['amici', '🗣️', 'Gli amici e le uscite', 'mossa'], ['imprevisti', '⚠️', 'Gli imprevisti', 'mossa']] };
    case 'energiaPerche': return { k: 'energia', t: 'Da cosa veniva la tua *stanchezza* ' + P.in + '?', dopo: 'mossa', ph: 'Esempio: un periodo difficile a casa',
      opz: [['sonno', '😴', 'Dormivo poco', 'mossa'], ['lavoro', '💼', 'Il lavoro mi svuotava', 'mossa'], ['corpo', '🏃', 'Mi muovevo poco', 'mossa'], ['testa', '🌫️', 'Avevo troppi pensieri', 'mossa']] };
    case 'ideeCosa': return { k: 'idee', t: 'Cosa è successo con le *idee nuove* ' + P.in + '?', dopo: 'mossa', ph: 'Esempio: ho passato una settimana su un’idea che poi ho lasciato',
      opz: [['parallelo', '🧩', 'Ho cominciato un progetto parallelo', 'mossa'], ['salto', '🦘', 'Saltavo da un’idea all’altra', 'mossa'], ['strada', '🔀', 'Ho cambiato strada più volte', 'mossa']] };
    case 'mossa': {
      /* 0.9.310, Andrea: "il finale non chiede cosa farai: propone la mossa del Genio dai dati e la fa confermare" */
      const pr = rvpProposta();
      const blocco = pr.azione && (pr.azione.k === 'blocco' || pr.azione.k === 'limite');
      return { k: 'mossa', t: (pr.perche ? pr.perche + ' ' : '') + 'La mia proposta: *' + pr.testo + '*. ' + (blocco ? 'Lo attivo?' : 'Ci stai?'), dopo: dc, ph: 'Esempio: preferisco spegnere il telefono alle 22',
        opz: [['si', '✅', blocco ? 'Sì, attivalo' : 'Sì, ci sto', dc], ['no', '✋', 'No, non ora', dc]] };
    }
    case 'ricalcolo': return { k: 'ricalcolo', t: 'Vuoi che ' + rvpNomeAgente() + ' *ricalcoli il percorso* partendo da questa revisione?', dopo: 'fine', noScrivo: true,
      opz: [['si', '🧭', 'Sì, ricalcolalo', 'fine'], ['no', '✋', 'No, va bene così', 'fine']] };
  }
  return null;
}
/** L'ora in cui il vecchio te ha segnato di piu' su quell'app nel periodo (la partita, fl_match_hist), o null. */
function rvpMgOra(pkg){
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_match_hist') || '[]') || []; }catch(_){ }
  const da = rvpDa(RVP.tipo), ore = {};
  h.forEach(function(g){ (g && g.eventi || []).forEach(function(e){ if (e && e.chi === 'old' && e.rotta === pkg && +e.at >= da){ const x = new Date(+e.at).getHours(); ore[x] = (ore[x] || 0) + Math.max(1, +e.punti || 1); } }); });
  const k = Object.keys(ore).sort(function(a, b){ return ore[b] - ore[a]; })[0];
  return k == null ? null : { ora: +k, n: ore[k] };
}
const RVP_TUTTI = [true, true, true, true, true, true, true];
/**
 * LA MOSSA DEL GENIO: dalle risposte e dai dati veri del periodo, una mossa sola e concreta. { testo (all'imperativo),
 * perche (il dato che la giustifica, o ''), azione: { k: 'blocco'|'caveau'|'focus', app, f } | null }
 */
function rvpProposta(){
  const r = RVP.r, a = RVP.app;
  const hh = function(h){ return String(h).padStart(2, '0') + ':00'; };
  if ((r.perso === 'app' || r.app) && a && a.pkg){
    let f = RVP_FASCIA_BLOCCO[r.appQuando] || RVP_FASCIA_BLOCCO.lavoro, perche = '';
    const mg = rvpMgOra(a.pkg);
    if (mg && mg.n >= 2){
      const h2 = (mg.ora + 2) % 24;
      f = { dalle: hh(mg.ora), alle: hh(h2), giorni: RVP_TUTTI, txt: 'dalle ' + mg.ora + ' alle ' + h2 };
      perche = 'Il vecchio te ha segnato ' + mg.n + ' punti su ' + a.label + ' fra le ' + mg.ora + ' e le ' + ((mg.ora + 1) % 24) + '.';
    }
    const feriali = f.giorni && !f.giorni[5] && !f.giorni[6];
    return { testo: 'blocca ' + a.label + ' ' + f.txt + (feriali ? ', dal lunedì al venerdì' : ', tutti i giorni'), perche: perche, azione: { k: 'blocco', app: [a.pkg], f: f, desc: a.label + ' bloccato ' + f.txt } };
  }
  const notte = function(fallback){
    const l = rvpApp(3).map(function(x){ return x.pkg; });
    if (!l.length) return { testo: fallback, perche: '', azione: null };
    return { testo: 'blocca le app che ti prendono più tempo dalle 23 alle 7', perche: '', azione: { k: 'blocco', app: l, f: RVP_FASCIA_BLOCCO.letto, desc: 'Le app che ti prendono più tempo bloccate dalle 23 alle 7' } };
  };
  if (r.perso === 'sera'){
    if (r.sera === 'uscite') return { testo: 'tieni due sere a settimana solo per il sogno', perche: '', azione: null };
    return notte('metti in carica il telefono fuori dalla camera alle 23');
  }
  if (r.perso === 'impegni') return { testo: 'tieni un’ora al giorno solo per il sogno, sempre alla stessa ora', perche: '', azione: null };
  if (r.perso === 'energia'){
    if (r.energia === 'sonno') return notte('vai a letto entro le 23');
    if (r.energia === 'corpo') return { testo: 'fai dieci minuti di camminata prima di lavorare al sogno', perche: '', azione: null };
    if (r.energia === 'testa') return { testo: 'fai due minuti di respiro prima di lavorare al sogno', perche: '', azione: null };
    return { testo: 'lavora al sogno nella prima ora libera della giornata, prima che il lavoro ti svuoti', perche: '', azione: null };
  }
  if (r.perso === 'idee') return { testo: 'metti ogni idea nuova nel caveau e torna alla priorità', perche: '', azione: { k: 'caveau' } };
  if (r.aiuto === 'ff') return { testo: 'aggiungi una sessione di Full Focus al giorno' + (r.quando && r.quando !== 'sempre' ? ', ' + rvpMin(r.quandoTesto || '') : ''), perche: '', azione: { k: 'focus' } };
  return { testo: 'tieni il ritmo che hai', perche: '', azione: null };
}
/* le fasce in cui le sessioni di Full Focus finite sono state di piu' vanno in cima */
function rvpFasceOrdinate(l){ const f = (RVP.dati && RVP.dati.ffFasce) || {}; return l.slice().sort(function(a, b){ return (f[b[0]] || 0) - (f[a[0]] || 0); }); }
const RVP_FASCIA_BLOCCO = {
  sveglio: { dalle: '06:00', alle: '09:00', giorni: [true, true, true, true, true, true, true], txt: 'dalle 6 alle 9' },
  lavoro: { dalle: '09:00', alle: '13:00', giorni: [true, true, true, true, true, false, false], txt: 'dalle 9 alle 13' },
  pause: { dalle: '09:00', alle: '18:00', giorni: [true, true, true, true, true, false, false], txt: 'dalle 9 alle 18' },
  letto: { dalle: '23:00', alle: '07:00', giorni: [true, true, true, true, true, true, true], txt: 'dalle 23 alle 7' }
};
/** Dove porta un nodo quando la risposta e' scritta, o saltata. */
function rvpDopo(n){ return (n && n.dopo) || 'fine'; }

/* ---------- la scena ---------- */
/* 0.9.322: come la sera, le revisioni di settimana, mese e trimestre riprendono da dove eri */
const RVP_RIP_K = 'fl_rvp_ripresa';
let RVP_RIPRESA = null;
function rvpRipSalva(){
  try{
    if (!RVP.passo || RVP.passo === 'fine' || !RVP.storia.length) return;
    localStorage.setItem(RVP_RIP_K, JSON.stringify({ tipo: RVP.tipo, periodo: RVP.periodo, passo: RVP.passo, storia: RVP.storia, r: RVP.r, percorso: RVP.percorso, bozze: RVP.bozze, scrivoPer: RVP.scrivoPer || '' }));
  }catch(_){ }
}
function rvpRipLeggi(tipo){
  try{
    const o = JSON.parse(localStorage.getItem(RVP_RIP_K) || 'null'); if (!o) return null;
    const dov = rvpDovuta(), t = tipo || (dov && dov.tipo) || 'settimana';
    if (o.tipo !== t || rvpFatta(t, o.periodo)){ if (o.tipo === t) localStorage.removeItem(RVP_RIP_K); return null; }
    return o;
  }catch(_){ return null; }
}
function rvpRipVia(){ try{ localStorage.removeItem(RVP_RIP_K); }catch(_){ } }
async function rvpApri(tipo){
  const dov = rvpDovuta();
  tipo = tipo || (dov && dov.tipo) || 'settimana';
  if (typeof GN === 'undefined' || typeof gnVai !== 'function'){ toast('Il Genio non è pronto, riprova'); return; }
  try{ RVP.daTab = localStorage.getItem('fl_tab') || ''; }catch(_){ RVP.daTab = ''; }
  RVP.tipo = tipo; RVP.periodo = rvpPeriodoDovuto(tipo) || rvpPeriodoDovuto('settimana') || rvpSettimanaIso(new Date());
  RVP.r = {}; RVP.storia = []; RVP.percorso = []; RVP.app = null; RVP.fatto = false; RVP.bozze = {}; RVP.azioneFatta = false;
  RVP.inclusi = rvpInclusi(tipo);
  RVP.dati = rvpRaccogli(tipo);
  /* 0.9.301: prima la rivelazione (e con Premium la domanda di consapevolezza e la chat con il tuo agente personale), conversa.js */
  RVP.passo = (typeof cvInizio === 'function') ? cvInizio('rvp') : 'recap';
  const rip = RVP_RIPRESA; RVP_RIPRESA = null;
  if (rip && rip.tipo === RVP.tipo){
    RVP.r = rip.r || {}; RVP.storia = rip.storia || []; RVP.percorso = rip.percorso || []; RVP.bozze = rip.bozze || {}; RVP.scrivoPer = rip.scrivoPer || '';
    RVP.passo = /^cv(Cosa|Scrivo|Scopri)$/.test(rip.passo) ? 'cvRivela' : rip.passo;
  }
  GN.on = true; GN.modo = 'rvp'; GN.audio = true; GN.storia = [];
  goId('s-genio');
  rvpBarra();
  GN.step = ''; gnVai('rvp');
}
function rvpBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const fissi = { cvDomanda: 0.06, cvCosa: 0.07, cvScrivo: 0.08, cvScopri: 0.1, cvRivela: 0.12, cvFuturo: 0.14, cvChat: 0.3, recap: 0.2, ricalcolo: 0.9, fine: 1 };
  const p = fissi[RVP.passo] != null ? fissi[RVP.passo] : Math.min(0.86, 0.3 + 0.12 * (RVP.percorso || []).length);
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(p * 100) + '%';
  if (txt) txt.textContent = RVP_NOMI[RVP.tipo] || 'La revisione';
}
function rvpVai(p){ RVP.storia.push(RVP.passo); RVP.passo = p; rvpRipSalva(); rvpBarra(); GN.step = ''; gnVai('rvp'); }
function rvpIndietro(){
  if (!RVP.storia.length || RVP.passo === 'fine'){ rvpChiudi(); return true; }
  RVP.passo = RVP.storia.pop();
  /* la risposta della domanda a cui si torna non vale piu' nel percorso */
  const i = RVP.percorso.map(function(x){ return x.id; }).lastIndexOf(RVP.passo); if (i >= 0) RVP.percorso = RVP.percorso.slice(0, i);
  rvpBarra(); GN.step = ''; gnVai('rvp'); return true;
}
function rvpChiudi(){
  rvpRipSalva();
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab(RVP.daTab === 'insights' ? 'insights' : RVP.daTab === 'rotta' ? 'rotta' : 'mappa'); }catch(_){ }
  try{ if (typeof rvOvunquePaint === 'function') rvOvunquePaint(); }catch(_){ }
  try{ rvpOvunquePaint(); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}
function rvpCarte(voci, scrivo){
  RVP.opz = voci;
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();rvpScegli(' + i + ')"><span>' + o[1] + '</span><b>' + rvpEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>'
    + (scrivo ? '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rvpScrivo()">✍️ Lo scrivo io</button>' : '');
}
/* LO SCRITTO E' FACOLTATIVO (0.9.310, Andrea: "Scrivi qualcosa, anche poche parole" bloccava la revisione): a campo
   vuoto il pulsante dice "Salta" e va avanti lo stesso */
function rvpCampo(ph, val){
  return '<textarea class="gn-area" id="rvpTesto" rows="4" placeholder="' + rvpEsc(ph || 'Scrivi qui…') + '" oninput="rvpCampoInput(this)" onclick="event.stopPropagation()">' + rvpEsc(val || '') + '</textarea>'
    + '<div class="or-grid one"><button type="button" class="or-a main" id="rvpTestoOk" onclick="event.stopPropagation();rvpScrivoOk()">' + (String(val || '').trim() ? 'Avanti' : 'Salta') + '</button></div>';
}
function rvpCampoInput(a){ RVP.bozze = RVP.bozze || {}; RVP.bozze[RVP.scrivoPer] = a.value; const b = document.getElementById('rvpTestoOk'); if (b) b.textContent = a.value.trim() ? 'Avanti' : 'Salta'; }
function rvpEntra(){
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo'); }
  if (typeof cvEntra === 'function' && cvEntra('rvp')) return;
  const p = RVP.passo;
  if (p === 'fine'){ rvpFine(); return; }
  if (p === 'recap'){
    gnDomanda('rivela', rvpParole().recap, (typeof rvVisto === 'function' ? rvVisto(rvpRecapRighe()) : '')
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvpVai(rvpRadice())">Continua</button></div>');
    return;
  }
  if (p === 'scrivo'){
    const n = rvpNodo(RVP.scrivoPer);
    const val = (RVP.bozze && RVP.bozze[RVP.scrivoPer]) || (n && RVP.r[n.k] === 'scritto' ? RVP.r[n.k + 'Testo'] : '');
    gnDomanda('pensa', 'Scrivilo *con parole tue*.', rvpCampo(n && n.ph, val), function(){ const a = document.getElementById('rvpTesto'); if (a) a.focus(); });
    return;
  }
  const n = rvpNodo(p); if (!n){ rvpFine(); return; }
  /* una domanda senza opzioni (nessuna app nei dati): si scrive, e si puo' saltare */
  if (!n.opz.length){ RVP.scrivoPer = p; gnDomanda('pensa', n.t, rvpCampo(n.ph, '')); return; }
  gnDomanda('pensa', n.t, rvpCarte(n.opz, !n.noScrivo));
}
function rvpRegistra(n, o){
  RVP.r[n.k] = o[0].indexOf('app:') === 0 ? 'app' : o[0]; RVP.r[n.k + 'Testo'] = o[2];
  if (o[5]) RVP.r[n.k + 'Frase'] = o[5]; else delete RVP.r[n.k + 'Frase'];
  if (o[4] && o[4].pkg){ RVP.app = o[4]; RVP.r.appPkg = o[4].pkg; }
  RVP.percorso.push({ id: RVP.passo, q: String(n.t).replace(/\*/g, ''), a: o[2], k: o[0] });
}
function rvpScegli(i){
  const o = RVP.opz[i]; if (!o) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  const n = rvpNodo(RVP.passo); if (!n) return;
  rvpRegistra(n, o);
  if (n.k === 'mossa' && o[0] === 'si'){
    const pr = rvpProposta(); RVP.r.mossaFrase = pr.testo;
    if (pr.azione && (pr.azione.k === 'blocco' || pr.azione.k === 'limite')) rvpAzioneFai(null);
  }
  /* la fine si decide dopo la risposta: un "Per niente" appena scelto porta alla domanda sul ricalcolo */
  let dopo = o[3];
  if (dopo === 'ricalcolo' || dopo === 'fine') dopo = (n.k !== 'ricalcolo' && rvpFuoriRotta()) ? 'ricalcolo' : 'fine';
  rvpVai(dopo);
}
function rvpScrivo(){ RVP.scrivoPer = RVP.passo; rvpVai('scrivo'); }
function rvpScrivoOk(){
  const a = document.getElementById('rvpTesto'); const t = a ? a.value.trim() : '';
  const per = RVP.scrivoPer || RVP.passo;
  const n = rvpNodo(per); if (!n){ rvpVai('fine'); return; }
  if (t){
    RVP.r[n.k] = 'scritto'; RVP.r[n.k + 'Testo'] = t;
    RVP.percorso.push({ id: per, q: String(n.t).replace(/\*/g, ''), a: t, k: 'scritto' });
  }
  /* dal passo "scrivo" si torna alla domanda nella storia, cosi' l'indietro dalla domanda dopo riporta alla domanda */
  if (RVP.passo === 'scrivo') RVP.passo = RVP.storia.pop() || per;
  let dopo = rvpDopo(n);
  if (dopo === 'ricalcolo' || dopo === 'fine') dopo = (n.k !== 'ricalcolo' && rvpFuoriRotta()) ? 'ricalcolo' : 'fine';
  rvpVai(dopo);
}

/* ---------- il riepilogo ---------- */
/** Cosa ha funzionato, cosa ti ha fatto perdere tempo, la prossima mossa: frasi intere, dalle risposte. */
function rvpRiepilogo(){
  const r = RVP.r, out = { rotta: r.rottaTesto || '', funzionato: '', allontanato: '', cambio: '', mossa: '', ricalcolo: r.ricalcolo === 'si' ? 'sì' : (r.ricalcolo ? 'no' : ''), sogno: r.sognoTesto || '' };
  if (r.aiutoTesto){
    const det = r.quandoTesto || r.chiTesto || '';
    out.funzionato = r.aiutoTesto + (det && r.quando !== 'sempre' ? ', ' + rvpMin(det) : '');
  }
  if (r.perso === 'app' || r.app){
    const nome = (RVP.app && RVP.app.label) || r.appTesto || r.persoTesto || 'Un’app';
    out.allontanato = nome + (r.appQuandoTesto ? ', ' + rvpMin(r.appQuandoTesto) : '');
  } else if (r.perso === 'sera') out.allontanato = r.seraTesto || r.persoTesto;
  else if (r.perso === 'impegni') out.allontanato = r.impegniTesto ? 'Gli impegni, soprattutto ' + rvpMin(r.impegniTesto) : r.persoTesto;
  else if (r.perso === 'energia') out.allontanato = r.energiaTesto ? (r.energia === 'scritto' ? 'La stanchezza: ' + rvpMin(r.energiaTesto) : 'La stanchezza, perché ' + rvpMin(r.energiaTesto)) : r.persoTesto;
  else if (r.perso === 'idee') out.allontanato = r.ideeTesto || r.persoTesto;
  else if (r.perso && r.perso !== 'niente') out.allontanato = r.persoTesto;
  if (r.mossa === 'si' && r.mossaFrase) out.cambio = r.mossaFrase.charAt(0).toUpperCase() + r.mossaFrase.slice(1);
  else if (r.mossa === 'scritto' && r.mossaTesto) out.cambio = r.mossaTesto;
  out.mossa = out.cambio ? 'Da domani: ' + rvpMin(out.cambio).replace(/[.\s]+$/, '') + '.' : '';
  return out;
}
/** La prossima mossa che si fa con un tocco: un blocco, un limite, il caveau, una sessione di Full Focus. */
function rvpAzione(){
  const r = RVP.r, a = RVP.app;
  if (r.mossa === 'si'){
    const z = rvpProposta().azione; if (!z) return null;
    if (z.k === 'blocco') return { k: 'blocco', label: 'Attiva il blocco', app: z.app, f: z.f, desc: z.desc };
    if (z.k === 'caveau' && typeof cvPaginaApri === 'function') return { k: 'caveau', label: 'Apri il caveau delle idee' };
    if (z.k === 'focus' && typeof stGoFocus === 'function') return { k: 'focus', label: 'Parti con una sessione di Full Focus' };
    return null;
  }
  if (r.cambio === 'blocco' && a && a.pkg && r.appQuando){ const f = RVP_FASCIA_BLOCCO[r.appQuando] || RVP_FASCIA_BLOCCO.lavoro; return { k: 'blocco', label: 'Attiva il blocco di ' + a.label, app: [a.pkg], f: f, desc: a.label + ' bloccato ' + f.txt }; }
  if (r.cambio === 'limite' && a && a.pkg) return { k: 'limite', label: 'Attiva il limite su ' + a.label, app: [a.pkg], desc: a.label + ' al massimo 30 minuti al giorno' };
  if (r.cambio === 'blocco' && r.sera){
    const l = rvpApp(3).map(function(x){ return x.pkg; });
    if (l.length) return { k: 'blocco', label: 'Attiva il blocco dopo le 23', app: l, f: RVP_FASCIA_BLOCCO.letto, desc: 'Le app che ti prendono più tempo bloccate dalle 23 alle 7' };
  }
  if (r.cambio === 'caveau' && typeof cvPaginaApri === 'function') return { k: 'caveau', label: 'Apri il caveau delle idee' };
  if (r.cambio === 'ff' && typeof stGoFocus === 'function') return { k: 'focus', label: 'Parti con una sessione di Full Focus' };
  return null;
}
function rvpAzioneFai(b){
  const z = rvpAzione(); if (!z) return;
  if (z.k === 'blocco' || z.k === 'limite'){
    if (typeof frProgrammaDaAgente !== 'function'){ toast('Il blocco si imposta dalla pagina Blocco'); return; }
    frProgrammaDaAgente({ nome: 'Dalla revisione', app: z.app, dalle: z.f && z.f.dalle, alle: z.f && z.f.alle, giorni: z.f && z.f.giorni, minutiGiorno: z.k === 'limite' ? 30 : 0, zitto: true }, false);
    RVP.azioneFatta = true;
    const l = rvpLista(); const x = l.filter(function(e){ return e.tipo === RVP.tipo && e.periodo === RVP.periodo; })[0];
    if (x){ x.azione = z.desc; rvpSalvaLista(l); }
    if (b){ b.disabled = true; b.textContent = z.k === 'limite' ? 'Limite attivato' : 'Blocco attivato'; b.classList.add('fatto'); }
    try{ toast(z.desc + ': fatto'); flVibra([20, 40, 30]); }catch(_){ }
    return;
  }
  rvpChiudi();
  if (z.k === 'caveau') setTimeout(function(){ try{ cvPaginaApri(); }catch(_){ } }, 300);
  if (z.k === 'focus') setTimeout(function(){ try{ stGoFocus(); }catch(_){ } }, 300);
}
/** Salva la revisione e chiude insieme le revisioni piu' piccole (la settimana dentro al mese, la sera di oggi). */
function rvpSalva(extra){
  const tipo = RVP.tipo, rp = (extra && extra.riepilogo) || rvpRiepilogo();
  const l = rvpLista().filter(function(x){ return !(x.tipo === tipo && x.periodo === RVP.periodo); });
  const zf = RVP.azioneFatta ? rvpAzione() : null;
  const voce = Object.assign({ tipo: tipo, periodo: RVP.periodo, at: Date.now(), r: RVP.r, riepilogo: rp, percorso: RVP.percorso, inclusi: (RVP.inclusi || []).map(function(x){ return x.tipo; }), dati: RVP.dati }, zf ? { azione: zf.desc } : {}, extra || {});
  voce.riepilogo = rp;
  l.push(voce);
  (RVP.inclusi || []).forEach(function(x){
    if (x.tipo === 'sera' || !x.periodo) return;
    for (let i = l.length - 1; i >= 0; i--) if (l[i].tipo === x.tipo && l[i].periodo === x.periodo) l.splice(i, 1);
    l.push({ tipo: x.tipo, periodo: x.periodo, at: Date.now(), r: voce.r, riepilogo: rp, inclusaIn: tipo, dati: null });
  });
  rvpSalvaLista(l);
  /* la sera di oggi: fatta dentro questa revisione (la serie delle sere non si rompe) */
  if ((RVP.inclusi || []).some(function(x){ return x.tipo === 'sera'; }) && typeof rvLista === 'function' && typeof rvOggi === 'function'){
    try{
      const g = rvOggi(); const s = rvLista().filter(function(x){ return x.giorno !== g; });
      s.push({ giorno: g, at: Date.now(), focus: '', leva: rp.funzionato || '', interruzione: rp.allontanato || '', contromisura: rp.cambio || '', imprevisto: '', inclusaIn: tipo, dati: null });
      localStorage.setItem('fl_revisioni', JSON.stringify(s.slice(-120)));
    }catch(_){ }
  }
  RVP.fatto = true;
  return rp;
}
function rvpFine(){
  rvpRipVia();
  const tipo = RVP.tipo;
  const rp = RVP.fatto ? rvpRiepilogo() : rvpSalva();
  const fuori = rvpFuoriRotta();
  const P = rvpParole();
  const titolo = fuori ? 'Sei *fuori rotta*, ma adesso sai cosa cambiare.' : (rp.cambio ? 'Sei *sulla rotta*. Ecco cosa tenere e cosa cambiare.' : 'Sei *sulla rotta*. Ecco cosa tenere.');
  const z = rvpAzione();
  const nomeA = (typeof cvNomeA === 'function') ? cvNomeA() : 'al Genio';
  const inclusi = (RVP.inclusi || []).map(function(x){ return x.tipo === 'sera' ? 'quella della sera' : x.tipo === 'settimana' ? 'quella della settimana' : x.tipo === 'mese' ? 'quella del mese' : 'quella del trimestre'; });
  let b = '';
  if (z && !RVP.azioneFatta) b += '<button type="button" class="or-a main rvp-az" onclick="event.stopPropagation();rvpAzioneFai(this)">' + rvpEsc(z.label) + '</button>';
  if (RVP.r.ricalcolo === 'si') b += '<button type="button" class="or-a rvp-ricalcola" onclick="event.stopPropagation();rvpRicalcolaBozza()">Chiedi ' + rvpEsc(nomeA) + ' di ricalcolare il percorso</button>';
  b += b ? '<button type="button" class="gn-link" onclick="event.stopPropagation();rvpChiudi()">Chiudi</button>' : '<button type="button" class="or-a main" onclick="event.stopPropagation();rvpChiudi()">Chiudi</button>';
  gnDomanda(fuori ? 'pensa' : 'rivela', titolo,
    /* 0.9.310: una pagina del diario di viaggio, non un muro di domande e risposte */
    rvdPaginaHtml({ tipo: tipo, periodo: RVP.periodo, at: Date.now(), r: RVP.r, riepilogo: rp }, '')
    + '<div class="or-grid one rvp-fine-b">' + b + '</div>');
  try{ flVibra([20, 40, 30]); }catch(_){ }
}
/* IL RICALCOLO SOLO CON IL TUO SI': la richiesta si scrive nel campo dell'agente, e parte solo quando la mandi tu */
function rvpRicalcolaBozza(rpIn){
  const rp = rpIn || rvpRiepilogo(), P = rvpParole();
  const t = ['Ho appena fatto ' + rvpMin(RVP_NOMI[RVP.tipo] || 'la revisione') + '.'];
  if (rp.rotta) t.push('Quanto mi sono avvicinato al sogno ' + P.in + ': ' + rvpMin(rp.rotta) + '.');
  if (rp.sogno) t.push('Il mio sogno: ' + rvpMin(rp.sogno) + '.');
  if (rp.funzionato) t.push('Cosa ha funzionato: ' + rvpMin(rp.funzionato) + '.');
  if (rp.allontanato) t.push('Cosa mi ha fatto perdere tempo: ' + rvpMin(rp.allontanato) + '.');
  if (rp.cambio) t.push('Cosa cambio da domani: ' + rvpMin(rp.cambio) + '.');
  t.push('Ricalcola la mia roadmap partendo da questo, e mostrami cosa cambia prima di applicarlo.');
  const testo = t.join(' ').replace(/\.\./g, '.');
  try{ if (typeof cvChiudiSoft === 'function') cvChiudiSoft(); }catch(_){ }
  rvpChiudi();
  setTimeout(function(){ if (typeof agPopover === 'function') agPopover(testo, { titolo: RVP_NOMI[RVP.tipo] }); else if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo); }, 250);
}
/** Per il tuo agente personale (e per la roadmap): le ultime revisioni di periodo, in frasi intere. */
function rvpPerAgente(){
  const l = rvpLista().filter(function(x){ return !x.inclusaIn; }).slice(-4); if (!l.length) return '';
  return 'Revisioni di periodo (da usare per la roadmap): ' + l.map(function(x){
    const rp = x.riepilogo, nome = (RVP_NOMI[x.tipo] || x.tipo) + ' ' + x.periodo;
    if (rp){
      return nome + ': ' + [rp.rotta ? 'quanto si è avvicinato al sogno "' + rp.rotta + '"' : '', rp.sogno ? 'il sogno "' + rp.sogno + '"' : '', rp.funzionato ? 'ha funzionato "' + rp.funzionato + '"' : '', rp.allontanato ? 'gli ha fatto perdere tempo "' + rp.allontanato + '"' : '',
        rp.cambio ? 'cambia "' + rp.cambio + '"' : '', x.azione ? 'ha attivato "' + x.azione + '"' : '', rp.ricalcolo ? 'ricalcolo del percorso: ' + rp.ricalcolo : ''].filter(Boolean).join(', ');
    }
    const r = x.r || {};
    return nome + ': ' + Object.keys(r).filter(function(k){ return /Testo$/.test(k); }).map(function(k){ return k.replace(/Testo$/, '') + ' "' + r[k] + '"'; }).join(', ');
  }).join('; ') + '.';
}
/* ---------- la chat (Premium): le risposte pronte per fase e il ritorno all'albero ---------- */
function rvpFasiChat(){
  const out = {};
  const testi = function(id){ const n = rvpNodo(id); return n ? n.opz.map(function(o){ return o[2]; }) : []; };
  if (rvpRadice() === 'sogno') out.sogno = testi('sogno');
  out.rotta = testi('rotta'); out.aiuto = testi('aiuto'); out.perso = testi('perso');
  out.cambio = ['Blocco l’app che mi distrae mentre lavoro', 'Tengo un’ora al giorno solo per il sogno', 'Vado a letto prima delle 23', 'Le idee nuove nel caveau'];
  out.ricalcolo = ['Sì, ricalcolalo', 'No, va bene così'];
  return out;
}
/** Il primo messaggio della chat, scritto subito dall'app: il recap del periodo e la prima domanda. */
function rvpPrimiMessaggi(){
  /* 0.9.310 (seconda richiesta): niente domande da pianificatore. Il recap dei numeri e' dell'app, il resoconto (dove vinci,
     dove perdi) lo scrive il tuo agente personale dai dati (conversa.js, cvChatChiedi('resoconto')) */
  return { msgs: [rvpRecapTesto()], fase: 'resoconto', pillole: [], chiedi: true };
}
/** L'agente non risponde: si continua con le domande del Genio, dalla risposta gia' data in chat. */
function rvpDaChat(risposte){
  let id = rvpRadice();
  (risposte || []).forEach(function(t){
    const n = rvpNodo(id); if (!n || id === 'fine') return;
    RVP.passo = id;
    const o = n.opz.filter(function(x){ return x[2] === t; })[0];
    if (o){ rvpRegistra(n, o); id = o[3]; }
    else { RVP.r[n.k] = 'scritto'; RVP.r[n.k + 'Testo'] = t; RVP.percorso.push({ id: id, q: String(n.t).replace(/\*/g, ''), a: t, k: 'scritto' }); id = rvpDopo(n); }
    if (id === 'ricalcolo' || id === 'fine') id = rvpFuoriRotta() && n.k !== 'ricalcolo' ? 'ricalcolo' : 'fine';
  });
  return id;
}
/** La chat finita: si salva con le stesse chiavi del Genio a opzioni, e chiude anche le revisioni incluse. */
function rvpSalvaDaChat(rp, testo, extra){
  rp = rp || {};
  const r = {}; Object.keys(rp).forEach(function(k){ if (rp[k]) r[k + 'Testo'] = rp[k]; });
  if (/^s[iì]/i.test(String(rp.ricalcolo || ''))) r.ricalcolo = 'si';
  RVP.r = Object.assign({}, RVP.r, r);
  const riep = { rotta: rp.rotta || '', funzionato: rp.funzionato || '', allontanato: rp.allontanato || '', cambio: rp.cambio || '', mossa: rp.mossa || (rp.cambio ? 'Da domani: ' + rvpMin(rp.cambio) : ''), ricalcolo: rp.ricalcolo || '', sogno: rp.sogno || '' };
  rvpSalva(Object.assign({ chat: true, testo: testo || '', riepilogo: riep }, extra || {}));
  return riep;
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA DEL DIARIO DI VIAGGIO (0.9.310). Andrea (screenshot 750): il riepilogo era "un muro di testo
   centrato con domande e risposte in grassetto, inguardabile". Adesso ogni revisione (sera, settimana, mese,
   unita, a opzioni o in chat) finisce su una pagina di carta come la lettera dal futuro (io-futuro-livello.js:
   .nf-df-pag, font a mano DM Caveat): la data in alto, al massimo tre voci (un'emoji in bolla, l'etichetta
   corta, la risposta scritta a mano, "Leggi tutto" se e' lunga) e la prossima mossa evidenziata in fondo.
   Le revisioni di periodo finiscono anche nel diario sfogliabile del Profilo (diario.js), come ricordo.
   --------------------------------------------------------------------------------------- */
const RVD_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
const RVD_ROTTA = { molto: 'Molto più vicino al sogno', poco: 'Un po’ più vicino al sogno', fermo: 'Fermo, senza passi avanti', indietro: 'Più lontano dal sogno di prima' };
const RVD_ROTTA_TESTI = { 'Molto': 'molto', 'Un po’': 'poco', 'Un po\'': 'poco', 'Per niente': 'fermo', 'Mi sono allontanato': 'indietro' };
const RVD_FOCUS = { 'Sì, quasi sempre': 'Concentrato quasi sempre', 'A metà': 'Concentrato a metà', 'Poco': 'Poco concentrato', 'Oggi niente lavoro profondo': 'Oggi niente lavoro profondo' };
function rvdData(t){ const d = new Date(t); return RVD_GIORNI[d.getDay()] + ' ' + d.getDate() + ' ' + RVP_MESI[d.getMonth()] + ' ' + d.getFullYear(); }
function rvdRotta(chiave, testo){ const k = chiave && RVD_ROTTA[chiave] ? chiave : RVD_ROTTA_TESTI[String(testo || '').trim()]; return (k && RVD_ROTTA[k]) || String(testo || ''); }
function rvdMossa(t){ t = String(t || '').trim().replace(/[.\s]+$/, ''); return t ? t.charAt(0).toUpperCase() + t.slice(1) + '.' : ''; }
/**
 * Le voci di una revisione salvata: [emoji, etichetta corta, risposta] (al massimo tre) e la prossima mossa.
 * x = una voce di fl_revisioni_periodo, oppure { tipo: 'sera', ...una voce di fl_revisioni }.
 */
function rvdVoci(x){
  const v = [];
  /* 0.9.337, Andrea: "il riepilogo del Rientra in rotta fa cagare: deve avere lo stile della pagina del diario" */
  if (x.tipo === 'rientro'){
    const rp = x.riepilogo || {};
    if (rp.interruzione || x.trigger) v.push(['🔀', 'Cosa ti ha portato fuori strada', rp.interruzione || x.trigger]);
    if (rp.patto) v.push(['🤝', 'Il tuo patto', rp.patto]);
    if ((x.applicati || [])[0]) v.push(['🛠️', 'Il piano che hai scelto', String(x.applicati[0]).split(':')[0]]);
    const dom = rp.contromisura || rp.mossa || '';
    return { voci: v.slice(0, 3), mossa: dom ? rvdMossa('Da domani: ' + rvpMin(dom)) : '', nome: 'Rientra in rotta' };
  }
  if (x.tipo === 'sera' && x.riepilogo){
    const rs = x.riepilogo;
    if (rs.rotta) v.push(['🧭', 'Com’è andata oggi', rs.rotta]);
    if (rs.funzionato) v.push(['✅', 'Ti ha avvicinato', rs.funzionato]);
    if (rs.allontanato) v.push(['⏳', 'Ti ha allontanato', rs.allontanato]);
    return { voci: v.slice(0, 3), mossa: rvdMossa(rs.mossa || ''), nome: 'La revisione della sera' };
  }
  if (x.tipo === 'sera'){
    if (x.focus) v.push(['🎯', 'La concentrazione', RVD_FOCUS[x.focus] || x.focus]);
    if (x.leva) v.push(['🧩', x.inclusaIn ? 'Ti ha avvicinato' : 'Su cosa hai lavorato', x.leva]);
    if (x.interruzione) v.push(['⏳', x.inclusaIn ? 'Ti ha allontanato' : 'Ti ha interrotto', x.interruzione]);
    return { voci: v.slice(0, 3), mossa: x.contromisura ? rvdMossa('Da domani: ' + rvpMin(x.contromisura)) : '', nome: 'La revisione della sera' };
  }
  const rp = x.riepilogo || {}, r = x.r || {};
  const P = rvpParole(x.tipo, x.periodo);
  const quando = String(P.recap || '').replace(/^Ecco\s+/, '').replace(/[*.]/g, '');
  const rotta = rvdRotta(r.rotta, rp.rotta || r.rottaTesto);
  if (rotta) v.push(['🧭', quando.charAt(0).toUpperCase() + quando.slice(1), rotta]);
  if (rp.funzionato) v.push(['✅', 'Ti ha avvicinato', rp.funzionato]);
  if (rp.allontanato) v.push(['⏳', 'Ti ha allontanato', rp.allontanato]);
  if (v.length < 3 && rp.sogno) v.push(['🎯', 'Il tuo sogno', rp.sogno]);
  return { voci: v.slice(0, 3), mossa: rvdMossa(rp.mossa || (rp.cambio ? 'Da domani: ' + rvpMin(rp.cambio) : '')), nome: RVP_NOMI[x.tipo] || 'La revisione' };
}
/** La pagina: carta, data, voci, mossa. `nota` e' una riga piccola in fondo (la serie delle sere). */
function rvdPaginaHtml(x, nota){
  const o = rvdVoci(x);
  const voci = o.voci.map(function(v){
    const lungo = String(v[2]).length > 64;
    return '<div class="rvd-v"><span class="rvd-ico" aria-hidden="true">' + v[0] + '</span><div class="rvd-c"><small>' + rvpEsc(v[1]) + '</small>'
      + '<p class="rvd-t' + (lungo ? ' corto' : '') + '">' + rvpEsc(v[2]) + '</p>'
      + (lungo ? '<button type="button" class="rvd-leggi" onclick="event.stopPropagation();rvdLeggi(this)">Leggi tutto</button>' : '') + '</div></div>';
  }).join('');
  return '<div class="rvd"><div class="nf-df-scena"><article class="nf-df-pag rvd-pag" aria-label="' + rvpEsc(o.nome) + '">'
    + '<p class="nf-df-data">' + rvpEsc(rvdData(x.at || Date.now())) + '</p><p class="rvd-nome">' + rvpEsc(o.nome) + '</p>'
    + voci
    + (o.mossa ? '<div class="rvd-mossa"><small>La prossima mossa</small><p><b>' + rvpEsc(o.mossa) + '</b></p></div>' : '')
    + (nota ? '<p class="rvd-nota">' + rvpEsc(nota) + '</p>' : '')
    + '</article></div></div>';
}
function rvdLeggi(b){ const p = b.previousElementSibling; if (!p) return; p.classList.toggle('corto'); b.textContent = p.classList.contains('corto') ? 'Leggi tutto' : 'Mostra meno'; }
/** Le revisioni di periodo come pagine del diario di viaggio (quelle fatte da sole: le incluse sono la stessa pagina). */
function rvdPagineDiario(){
  return rvpLista().filter(function(x){ return x && !x.inclusaIn && x.riepilogo && x.at; }).map(function(x){
    const o = rvdVoci(x);
    return { id: 'rev' + x.tipo + x.periodo, tipo: 'revisione', t: x.at, titolo: o.nome, testo: o.voci.map(function(v){ return v[1] + ': ' + v[2]; }).concat(o.mossa ? ['La prossima mossa: ' + o.mossa] : []).join('\n'), voci: o.voci, mossa: o.mossa, ico: RVP_ICO[x.tipo] || '🗓️' };
  });
}
function rvdDiarioAggancia(){
  if (typeof dvPagine === 'function' && !dvPagine.__rvd){
    const v = dvPagine;
    const w = function(){
      const P = v.apply(this, arguments);
      try{
        const extra = rvdPagineDiario(); if (!extra.length) return P;
        const cover = P.length && P[0].tipo === 'copertina' ? P.shift() : null;
        const fine = P.length && P[P.length - 1].tipo === 'prossima' ? P.pop() : null;
        extra.forEach(function(x){ if (!P.some(function(p){ return p.id === x.id; })) P.push(x); });
        P.sort(function(a, b){ return a.t - b.t; });
        if (cover) P.unshift(cover); if (fine) P.push(fine);
      }catch(_){ }
      return P;
    };
    w.__rvd = true; window.dvPagine = dvPagine = w;
  }
  if (typeof dvPaginaHtml === 'function' && !dvPaginaHtml.__rvd){
    const v2 = dvPaginaHtml;
    const w2 = function(p, num, tot){
      if (!p || p.tipo !== 'revisione') return v2.apply(this, arguments);
      const data = '<small class="dv-data">' + rvpEsc(typeof dvDataLunga === 'function' ? dvDataLunga(p.t) : rvdData(p.t)) + '</small>';
      const corpo = '<h2>' + rvpEsc(p.titolo) + '</h2>' + (p.voci || []).map(function(v){ return '<div class="dv-rv"><span>' + v[0] + '</span><p class="dv-mano"><small>' + rvpEsc(v[1]) + '</small>' + rvpEsc(v[2]) + '</p></div>'; }).join('')
        + (p.mossa ? '<p class="dv-mano dv-rv-mossa"><small>La prossima mossa</small><b>' + rvpEsc(p.mossa) + '</b></p>' : '');
      return '<div class="dv-pg dv-carta revisione">' + data + corpo + '<small class="dv-npag">' + num + '</small></div>';
    };
    w2.__rvd = true; window.dvPaginaHtml = dvPaginaHtml = w2;
  }
}

/* ---------- la card in cima alle schede, quando e' il momento: UNA sola, quella del periodo piu' grande ---------- */
function rvpCardHtml(){
  const d = rvpDovuta(); if (!d) return '';
  const P = rvpParole(d.tipo, d.periodo);
  /* 0.9.311, Andrea: che questa chiuda anche le altre e' affar nostro, non si scrive a schermo. */
  return '<div class="rv-card rvp-card ' + d.tipo + '" onclick="rvpApri(\'' + d.tipo + '\')" role="button"><span class="rv-ico">' + RVP_ICO[d.tipo] + '</span><div><small>' + rvpEsc(RVP_NOMI[d.tipo]) + '</small><b>' + rvpEsc(P.card) + '</b>'
    + '</div>'
    + '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></div>';
}
function rvpOvunquePaint(){
  /* 0.9.337: anche le revisioni di periodo stanno solo nella slide di Sogno (dream-storia.js, drsRevSlideHtml) */
  ['mppRevPerMia', 'mppRevPer', 'stRevPer', 'nvRevPer'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
  return;
  if (typeof rvSlot !== 'function') return;
  const card = rvpCardHtml();
  const metti = function(id, rif, dopo, nascosto){
    const h = rvSlot(id, rif, dopo); if (!h) return;
    h.classList.add('rvp-slot'); if (nascosto != null) h.classList.toggle('mpp-via', nascosto);
    if (h._html !== card){ h._html = card; h.innerHTML = card; } h.hidden = !card;
  };
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  metti('mppRevPerMia', document.getElementById('mppRevMia') || document.getElementById('mppFoglio'), false, v !== 'mia');
  metti('mppRevPer', document.getElementById('mppRevisione') || document.getElementById('mppSentiero'), false, v !== 'rotta');
  /* 0.9.265 (lag): DOPO la revisione. Messa prima, la revisione (che vuole stare subito sotto a stHero) e lei si
     scambiavano di posto a ogni disegno: la pagina si muoveva da sola ogni pochi secondi. */
  metti('stRevPer', document.getElementById('stRevisione') || document.getElementById('stHero'), true, null);
  metti('nvRevPer', document.getElementById('nvRevisione') || document.getElementById('nvTop'), false, null);
}
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.rvp = { entra: rvpEntra };
  try{ rvdDiarioAggancia(); }catch(_){ }
  if (typeof rvOvunquePaint === 'function'){ const v = rvOvunquePaint; window.rvOvunquePaint = rvOvunquePaint = function(){ const r = v.apply(this, arguments); try{ rvpOvunquePaint(); }catch(_){ } return r; }; }
  if (typeof rvCardPaint === 'function'){ const v2 = rvCardPaint; window.rvCardPaint = rvCardPaint = function(){ const r = v2.apply(this, arguments); try{ rvpOvunquePaint(); }catch(_){ } return r; }; }
  if (typeof gnChiudiTop === 'function'){ const v3 = gnChiudiTop; gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'rvp'){ rvpChiudi(); return; } return v3.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v4 = gnIndietro; gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rvp') return rvpIndietro(); return v4.apply(this, arguments); }; }
  if (typeof rnPerAgente === 'function'){ const v5 = rnPerAgente; window.rnPerAgente = rnPerAgente = function(){ return [v5.apply(this, arguments), rvpPerAgente()].filter(Boolean).join(' '); }; }
  document.addEventListener('fl:giorno', function(){ try{ rvpOvunquePaint(); }catch(_){ } });
  setInterval(function(){ try{ rvpOvunquePaint(); }catch(_){ } }, 120000);
  const st = document.createElement('style');
  st.textContent = [
    '.rvp-slot[hidden]{display:none}#mppRevPerMia,#mppRevPer{padding:0 16px;margin:8px 0 10px}#stRevPer{padding:0 16px;margin:10px 0 12px}#nvRevPer{margin:0 0 14px}',
    '.rv-card.rvp-card.settimana{background:linear-gradient(135deg,#0B5E6B,#0F2041)}',
    '.rv-card.rvp-card.mese{background:linear-gradient(135deg,#005BB0,#0F2041)}',
    '.rv-card.rvp-card.trimestre{background:linear-gradient(135deg,#8A3B1C,#0F2041)}',
    '.rv-card.rvp-card.anno{background:linear-gradient(135deg,#C42B38,#0F2041)}',
    /* il riepilogo: una pagina del diario di viaggio (la carta e il font a mano della lettera dal futuro, .nf-df-pag) */
    '.rvd{margin:2px 0 18px}.rvd-pag{padding:26px 22px 28px !important;text-align:left !important}.rvd-pag .nf-df-data{display:table;margin:0 auto 4px}',
    '.rvd-nome{margin:0 0 20px;text-align:center;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#7a5634}',
    '.rvd-v{display:flex;align-items:flex-start;gap:12px;margin:0 0 16px}.rvd-c{flex:1;min-width:0}',
    '.rvd-ico{flex:none;width:40px;height:40px;border-radius:50%;display:grid;place-items:center;font-size:20px;background:#fbf8f0;box-shadow:0 2px 6px rgba(60,40,20,.22)}',
    '.rvd-c small{display:block;font:800 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8a6a4a}',
    '.rvd-t{margin:2px 0 0;font:500 23px/1.2 "DM Caveat","Caveat","Segoe Print",cursive;color:#3b2d20;overflow-wrap:anywhere}',
    '.rvd-t.corto{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden}',
    '.rvd-leggi{margin:2px 0 0;padding:2px 0;border:0;background:none;color:#0B4F9C;font:800 13px var(--font-body);cursor:pointer}',
    '.rvd-mossa{margin:22px 0 0;padding-top:16px;border-top:1.5px dashed rgba(122,86,52,.45);text-align:center}',
    '.rvd-mossa small{display:block;font:800 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#C42B38}',
    '.rvd-mossa p{margin:6px 0 0;font:700 25px/1.25 "DM Caveat","Caveat","Segoe Print",cursive;color:#2b1f14}.rvd-mossa b{font-weight:700;padding:0 4px;border-radius:4px;background:rgba(140,198,255,.5);-webkit-box-decoration-break:clone;box-decoration-break:clone}',
    '.rvd-nota{margin:18px 0 0;text-align:center;font:600 19px/1.25 "DM Caveat","Caveat","Segoe Print",cursive;color:#7a5634}',
    'body.dark .rvd-t,body.dark .rvd-mossa p,body.dark .rvd-mossa b{color:#2b1f14 !important}body.dark .rvd-nome,body.dark .rvd-c small,body.dark .rvd-nota{color:#7a5634 !important}body.dark .rvd-mossa small{color:#C42B38 !important}body.dark .rvd-leggi{color:#0B4F9C !important}body.dark .rvd-ico{background:#fbf8f0 !important}',
    /* la stessa pagina nel diario sfogliabile del Profilo (diario.js) */
    '.dv-rv{display:flex;gap:10px;align-items:flex-start;margin:10px 0;text-align:left}.dv-rv > span{flex:none;font-size:20px;line-height:1.4}.dv-rv .dv-mano{margin:0}',
    '.dv-rv small,.dv-rv-mossa small{display:block;font:800 10px var(--font-body);letter-spacing:.1em;text-transform:uppercase;opacity:.7}',
    '.dv-rv-mossa{margin-top:14px;text-align:center}.dv-rv-mossa b{padding:0 4px;border-radius:4px;background:rgba(140,198,255,.45);-webkit-box-decoration-break:clone;box-decoration-break:clone}',
    '.rvp-fine-b .or-a + .or-a{margin-top:10px}.rvp-fine-b .gn-link{margin-top:6px}.or-a.rvp-ricalcola,body.dark .or-a.rvp-ricalcola{background:#E63946!important;color:#fff!important;border-color:#E63946!important}.cv-fine-b .or-a.rvp-ricalcola + .or-a{margin-top:10px}.rvp-fine-b .rvp-az.fatto{background:#1B9E6A;border-color:#1B9E6A;color:#fff;opacity:1}',
  ].join('');
  document.head.appendChild(st);
})();
