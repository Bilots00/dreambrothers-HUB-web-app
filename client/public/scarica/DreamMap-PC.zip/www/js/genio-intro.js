/* ===========================================================================================
   IL PRIMO AVVIO — il Genio ti legge il futuro.

   COME E' FATTO, E DA CHI L'HO IMPARATO (tutto visto di persona dentro BlueStacks, 19/09/2026,
   note in docs/onboarding-pattern-dalle-app.md):

   · POKÉMON (Bianco/Nero, Y): sfondo neutro, UN personaggio a figura intera, un riquadro di
     testo in basso con le lettere che compaiono una alla volta e il triangolino che lampeggia
     quando la frase e' finita. Si avanza toccando. Il professore parla, poi chiede nome e sesso.
   · AKINATOR: il genio resta a schermo per tutto il quiz e CAMBIA POSA; la domanda e' una riga
     in una striscia sottile; cinque pulsanti gialli sempre nello stesso posto.
   · FOCUS FRIEND: il pulsante e' la battuta di chi legge («Hello!», «A bean?»); e la leva piu'
     forte: «it will be sad if you disappoint him» — il personaggio si intristisce davvero.
   · DETOX: una frase intera per volta, l'accento con il colore, «tocca per continuare».
   · MYFUTURESELF: le due domande che servono a farsi riconoscere, non a configurare.
   · CLASH ROYALE: anche la domanda piu' burocratica (l'eta') ha il Re davanti; la prima cosa
     che succede e' un'azione, non un menu.

   REGOLE CHE QUI NON SI ROMPONO: frasi intere con il soggetto; avanza il dito e non un
   cronometro; il Genio e' un personaggio disegnato (img/genio/*.png), non un'emoji; l'immagine
   dell'aereo compare SOLO quando si sceglie partenza e destinazione.

   Il suono e' sintetizzato con WebAudio: un giro enigmatico da genio della lampada sotto tutto
   il film, il ticchettio delle lettere, il crescendo della lettura, il colpo del punto.
   =========================================================================================== */

const GN_KEY = 'fl_intro';
const GN = { on: false, step: '', timer: null, typing: null, audio: true, dati: null, attesaDove: false, attesaAuth: false, storia: [], tornando: false };

function gnDati(){
  if (!GN.dati){
    try{ GN.dati = JSON.parse(localStorage.getItem(GN_KEY) || 'null'); }catch(_){ }
    if (!GN.dati) GN.dati = { nome: '', target: '', posto: '', ore: '', stato: '', conti: [], anno: '', at: 0 };
  }
  return GN.dati;
}
function gnSalva(){ try{ localStorage.setItem(GN_KEY, JSON.stringify(GN.dati)); }catch(_){ } }
function gnEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function gnNome(){ return (gnDati().nome || '').trim(); }

/* I nomi dei due contendenti, per il tabellone di START e per chi li vuole altrove. */
function gnNomi(){
  /* 0.9.318, Andrea: "dice il vecchio Liliana: non teniamo conto del sesso perche' non lo chiediamo". Senza il sesso, con un nome
     si resta su "te" (mai indovinare dal nome). */
  const n = gnNome(), sx = gnSesso();
  if (sx === 'f') return { nome: n, vecchio: 'la vecchia ' + (n || 'te'), nuovo: 'la nuova ' + (n || 'te') };
  return { nome: n, vecchio: sx === 'm' && n ? 'il vecchio ' + n : 'il vecchio te', nuovo: sx === 'm' && n ? 'il nuovo ' + n : 'il nuovo te' };
}
function gnSesso(){
  const s = gnDati().sesso; if (s === 'm' || s === 'f') return s;
  try{ const g = (typeof ifIdentita === 'function') ? ifIdentita().genere : ''; if (g === 'm' || g === 'f') return g; }catch(_){ }
  return '';
}
/** "a" + il vecchio Andrea = "al vecchio Andrea", "a" + la vecchia Liliana = "alla vecchia Liliana". */
function gnA2(x){ return String(x).replace(/^il /, 'al ').replace(/^la /, 'alla '); }
function gnSessoScegli(i, s){
  gnDati().sesso = s; gnSalva();
  /* e' la stessa risposta che chiede l'Io futuro: non si ripete */
  try{ if (s && typeof ifIdentita === 'function' && typeof ifScrivi === 'function' && typeof IF_KEYS !== 'undefined'){ const id = ifIdentita(); id.genere = s; ifScrivi(IF_KEYS.ident, id); } }catch(_){ }
  gnRisposta(i, 'nome');
}
function inVecchio(){ return gnNomi().vecchio; }
function inNuovo(){ return gnNomi().nuovo; }

/* ---------- il suono ---------- */
const gnAu = {
  ctx: null, master: null, loop: null, pad: null, passo: 0,
  ok: function(){
    if (!GN.audio) return false;
    try{
      if (!this.ctx){
        const C = window.AudioContext || window.webkitAudioContext; if (!C) return false;
        this.ctx = new C(); this.master = this.ctx.createGain(); this.master.gain.value = 0.42; this.master.connect(this.ctx.destination);
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return true;
    }catch(_){ return false; }
  },
  tono: function(f, t0, dur, gain, tipo){
    try{
      const o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = tipo || 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(gain, t0 + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(this.master); o.start(t0); o.stop(t0 + dur + 0.05);
    }catch(_){ }
  },
  /* IL GIRO DEL GENIO: un arpeggio in scala «orientale» (mi frigio dominante), pizzicato,
     con un bordone grave sotto. E' la musichetta enigmatica di Akinator e della lampada,
     rifatta con due oscillatori: nessun file, nessuna licenza. */
  musica: function(){
    /* 0.9.321, Andrea: "rifacendo l'onboarding non si sente nessun suono". musica.js spegne l'intro quando l'app va in secondo piano
       o cambia schermata, ma qui restava scritto 'mu': da quel momento il film era muto per sempre, fino a riaprire l'app. */
    if (this.loop === 'mu' && !(typeof MU !== 'undefined' && MU.sigla)) this.loop = null;
    if (this.loop) return;
    /* 0.9.261, Andrea: nel film del Genio la musica e' quella a quattro accordi (musica.js, muIntro), non
       l'arpeggio orientale di prima. Quella vecchia resta solo se musica.js non c'e'. */
    if (typeof muSigla === 'function'){ try{ muSigla(); }catch(_){ } this.loop = 'mu'; return; }
    if (!this.ok()) return;
    const self = this, c = this.ctx;
    try{
      const g = c.createGain(); g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.06, c.currentTime + 2);
      const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 320;
      const o1 = c.createOscillator(); o1.type = 'triangle'; o1.frequency.value = 82.41;   // mi grave
      const o2 = c.createOscillator(); o2.type = 'sine'; o2.frequency.value = 123.47; o2.detune.value = 4;
      o1.connect(f); o2.connect(f); f.connect(g); g.connect(this.master); o1.start(); o2.start();
      this.pad = { g: g, o: [o1, o2] };
    }catch(_){ }
    const scala = [329.63, 349.23, 415.30, 440.00, 493.88, 523.25, 587.33, 659.25]; // E F G# A B C D E
    const giro = [0, 2, 4, 7, 4, 2, 3, 1, 0, 2, 4, 6, 4, 2, 1, 0];
    this.passo = 0;
    this.loop = setInterval(function(){
      if (!self.ctx) return;
      const t = self.ctx.currentTime;
      const n = scala[giro[self.passo % giro.length]];
      self.tono(n, t, 0.42, 0.05, 'triangle');
      self.tono(n * 2, t, 0.18, 0.012, 'sine');
      if (self.passo % 16 === 15) self.tono(1318.5, t + 0.1, 1.2, 0.03, 'sine');
      self.passo++;
    }, 340);
  },
  musicaOff: function(){
    if (this.loop === 'mu'){ this.loop = null; try{ if (typeof muSiglaOff === 'function') muSiglaOff(); }catch(_){ } return; }
    if (this.loop){ clearInterval(this.loop); this.loop = null; }
    try{ if (this.pad){ const p = this.pad, t = this.ctx.currentTime; this.pad = null; p.g.gain.linearRampToValueAtTime(0.0001, t + 1.2); setTimeout(function(){ try{ p.o.forEach(function(o){ o.stop(); }); }catch(_){ } }, 1400); } }catch(_){ }
  },
  /* il ticchettio delle lettere, come nei Pokémon: un colpetto ogni due caratteri */
  tick: function(){ if (!this.ok()) return; this.tono(1480, this.ctx.currentTime, 0.035, 0.05, 'square'); },
  scelta: function(i){ if (!this.ok()) return; const s = [523.25, 587.33, 659.25, 783.99, 880, 987.77, 1046.5]; this.tono(s[Math.min(6, i)], this.ctx.currentTime, 0.4, 0.12); },
  crescendo: function(ms, fine){
    if (!this.ok()){ setTimeout(fine, ms); return; }
    try{
      const c = this.ctx, t = c.currentTime, s = ms / 1000;
      const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.09, t + s);
      const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(160, t); f.frequency.exponentialRampToValueAtTime(2600, t + s);
      const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(82.41, t); o.frequency.linearRampToValueAtTime(164.81, t + s);
      o.connect(f); f.connect(g); g.connect(this.master); o.start(t); o.stop(t + s + 0.05);
      const self = this;
      setTimeout(function(){ const t2 = self.ctx.currentTime; [329.63, 415.30, 493.88, 659.25].forEach(function(fr, i){ self.tono(fr, t2 + i * 0.05, 2.4, 0.11); }); fine(); }, ms);
    }catch(_){ setTimeout(fine, ms); }
  },
  punto: function(){ if (!this.ok()) return; const t = this.ctx.currentTime; this.tono(783.99, t, 0.18, 0.16); this.tono(1046.5, t + 0.16, 0.55, 0.16); },
  triste: function(){ if (!this.ok()) return; const t = this.ctx.currentTime; this.tono(392, t, 0.5, 0.08); this.tono(349.23, t + 0.45, 0.9, 0.08); }
};
function gnVibra(p){ try{ flVibra(p); }catch(_){ } }
function gnAudioToggle(){
  GN.audio = !GN.audio;
  try{ localStorage.setItem('fl_intro_audio', GN.audio ? '1' : '0'); }catch(_){ }
  if (!GN.audio) gnAu.musicaOff(); else gnAu.musica();
  const b = document.getElementById('gnMute'); if (b) b.textContent = GN.audio ? '🔊' : '🔇';
}

/* ---------- I TESTI DEL GENIO ----------
   Tutti qui, in un posto solo: li scrive il Copywriter (ruolo nel company brain), non il
   codice. {segnaposto} fra graffe; la parte fra *asterischi* si accende. */
/* REGOLA DI CHIAREZZA (Andrea, 30/09): dentro all'app ogni frase ha soggetto e complemento,
   niente sottintesi, niente ambiguita'. «Cosi' come vai» non lo dice nessuno: si dice «ad oggi». */
const GN_TESTI = {
  apertura: 'Ciao. Sono il Genio. Faccio una cosa sola: guardo dove sta andando una persona, e glielo dico *prima che ci arrivi*.',
  b2: 'Ho letto migliaia di persone. Tutte avevano un sogno in testa. Ma quasi tutte, la sera, avevano *il telefono in mano*.',
  b3: 'Quindi il sogno restava lì. Un anno dopo era nello stesso punto. *E loro pure.*',
  b4: 'Tu però hai continuato fino a qui. Rispondi a poche domande, e ti dico *dove stai andando davvero*.',
  b4_btn: 'Leggimi il futuro',
  sogno_domanda: 'se potessi realizzare un sogno e renderlo *inevitabile*, con quest\u2019app, quale sarebbe?',
  chi_domanda: 'E chi vuoi diventare, *di preciso*?',
  verdetto_intro: '{nome}ecco cosa vedo. Se continui così, rischi di diventare *{profilo}*.',
  verdetto_btn: 'Continua ›',
  verdetto2: 'Ad oggi, la probabilità che tu arrivi a {sogno} è *{pct}*.',
  verdetto2_btn: 'Scopri cosa la tiene bassa ›',
  /* 0.9.264, Andrea: "La alzano le 3 ore..." diceva il contrario di quello che intendeva (le ore al telefono la ABBASSANO). */
  verdetto3: 'A tenerla bassa sono le {ore} al giorno sul telefono che hai appena visto. Se quelle ore tornano tue, la probabilità sale al *{pct2}*.',
  verdetto3_btn: 'Me le riprendo'
};
/* 0.9.300: i testi dell'episodio 1 (La luce) stanno in content/episodi.json (episodi.js). Se il file non c'e'
   restano quelli di prima, scritti qui. */
function gnC(k, fb, v){
  let t = ''; try{ t = (typeof epiIntroT === 'function') ? epiIntroT(k, v) : ''; }catch(_){ t = ''; }
  if (t) return t;
  let s = fb || '';
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  return s;
}
function gnT(k, v){
  let s = GN_TESTI[k] || '';
  if (v) Object.keys(v).forEach(function(x){ s = s.split('{' + x + '}').join(String(v[x])); });
  /* "arrivi a il tuo sogno" -> "arrivi al tuo sogno" */
  return s.replace(/ a il /g, ' al ').replace(/ di il /g, ' del ').replace(/ da il /g, ' dal ');
}

/* ---------- la scena ---------- */
function gnHtml(){
  return '<div class="gn" id="gnScena">'
    + '<div class="gn-top" id="gnTop" hidden><button type="button" class="gn-x" onclick="event.stopPropagation();gnChiudiTop()" aria-label="Chiudi">✕</button><div class="gn-prog"><div><i id="gnProgBar"></i></div><small id="gnProgTxt"></small></div></div>'
    + '<div class="gn-sopra" id="gnSopra"><img class="gn-genio" id="gnGenio" src="img/genio/genio-saluta.png" alt=""></div>'
    + '<div class="gn-box" id="gnBox"><p id="gnTesto"></p><span class="gn-freccia" id="gnFreccia" hidden><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M5 8h14l-7 9z"/></svg></span></div>'
    + '<div class="gn-tap" id="gnTap" hidden>tocca per continuare</div>'
    + '<div class="gn-risp" id="gnRisp"></div>'
    + '</div>';
}
/* la X in alto: chiude gli episodi, o la sfida del Genio (genio-sfida.js) */
function gnChiudiTop(){
  if (GN.modo === 'ak' && typeof akChiudi === 'function'){ akChiudi(); return; }
  if (GN.modo === 'epi' && typeof epiChiudi === 'function'){ epiChiudi(); return; }
  if (typeof dqChiudi === 'function') dqChiudi();
}
/* 0.9.253, Andrea: il Genio si muove come Akinator. Respira sempre; a ogni posa la sua mossa:
   saluta ondeggiando, pensa dondolando, rivela con un balzo, triste si affloscia. */
function gnPosa(p){
  const img = document.getElementById('gnGenio'); if (!img) return;
  const src = 'img/genio/genio-' + p + '.png';
  img.classList.remove('posa-saluta', 'posa-pensa', 'posa-rivela', 'posa-triste');
  void img.offsetWidth;
  img.classList.add('posa-' + p);
  if (img.getAttribute('src') === src) return;
  img.classList.add('cambia');
  setTimeout(function(){ img.src = src; img.classList.remove('cambia'); }, 160);
}

/* LA MACCHINA DA SCRIVERE. Una lettera ogni 26 ms con un ticchettio ogni due; un tocco
   durante la scrittura completa la frase, un tocco a frase finita va avanti. E' il ritmo dei
   Pokémon: chi legge veloce non aspetta, chi legge piano non viene lasciato indietro. */
function gnScrivi(testo, dopo){
  const el = document.getElementById('gnTesto'), fr = document.getElementById('gnFreccia');
  if (!el) return;
  clearTimeout(GN.typing); clearInterval(GN.typing); GN.typing = null;
  if (fr) fr.hidden = true;
  el.classList.remove('gn-sale');
  el.innerHTML = '';
  const parti = gnParti(testo);
  let i = 0;
  const fine = function(){
    clearTimeout(GN.typing); clearInterval(GN.typing); GN.typing = null;
    el.innerHTML = parti.html;
    if (fr) fr.hidden = false;
    if (dopo) dopo();
  };
  /* 40 ms a lettera (26 erano illeggibili), e una pausa dove la voce si fermerebbe: dopo il
     punto, dopo la virgola. GN.typing resta un handle vero: chi tocca lo azzera. */
  /* IL TESTO PICCOLO VA A 26 MS (Andrea: «perfetta»); quello grande delle domande andava
     alla stessa velocita' e con lettere il doppio sembrava correre: solo li' 40 ms e il
     respiro sulla punteggiatura. */
  /* 0.9.263, Andrea: tutte le macchine da scrivere alla velocita' della frase del giorno (55 ms a lettera,
     CIT_MS in citazioni.js): "quella e' la calibrazione perfetta, tutto il resto e' sballato". */
  let grande = false; try{ grande = parseFloat(getComputedStyle(el).fontSize) >= 20; }catch(_){ }
  const base = (typeof CIT_MS === 'number') ? CIT_MS : 55;
  const passo = function(){
    i++;
    if (i % 2 === 0) gnAu.tick();
    el.innerHTML = gnParti(testo, i).html;
    if (i >= parti.n){ fine(); return; }
    const ch = gnLetteraN(testo, i);
    const pausa = 0;
    GN.typing = setTimeout(passo, base + pausa);
  };
  GN.typing = setTimeout(passo, base);
  GN.completa = fine;
}
/* la n-esima lettera visibile (gli asterischi non contano) */
function gnLetteraN(testo, n){
  let k = 0;
  for (let j = 0; j < testo.length; j++){ if (testo[j] === '*') continue; k++; if (k === n) return testo[j]; }
  return '';
}
/* LA PRIMA FRASE NON SI BATTE A MACCHINA: sale dal basso, in dissolvenza, tutta insieme. */
function gnMostra(testo, dopo){
  const el = document.getElementById('gnTesto'), fr = document.getElementById('gnFreccia');
  if (!el) return;
  clearTimeout(GN.typing); clearInterval(GN.typing); GN.typing = null;
  if (fr) fr.hidden = true;
  el.innerHTML = gnParti(testo).html;
  el.classList.remove('gn-sale'); void el.offsetWidth; el.classList.add('gn-sale');
  GN.completa = null;
  if (dopo) setTimeout(dopo, 900);
}
/* Il testo puo' avere una parte fra *asterischi*: e' quella che si accende, dentro la frase. */
function gnParti(testo, fino){
  let n = 0, html = '', acceso = false;
  for (let k = 0; k < testo.length; k++){
    const ch = testo[k];
    if (ch === '*'){ acceso = !acceso; html += acceso ? '<b>' : '</b>'; continue; }
    n++;
    if (fino !== undefined && n > fino) break;
    html += gnEsc(ch);
  }
  if (acceso) html += '</b>';
  return { html: html, n: n };
}
function gnTocco(){
  if (!GN.on) return;
  gnAu.musica();
  /* un tocco nei primi istanti di un passo e' quasi sempre il residuo del tocco precedente
     (o del boot): non deve mangiarsi una battuta intera */
  if (performance.now() - (GN.entrato || 0) < 500) return;
  if (GN.typing){ GN.completa && GN.completa(); return; }
  const s = GN_PASSI[GN.step];
  if (s && s.tocco) s.tocco();
}

/* ---------- i passi ---------- */
function gnVai(step){
  /* 0.9.282, Andrea: "Ciao, sono il Genio" a volte compariva due volte (grande, e poi di nuovo nella nuvoletta). Il
     film partiva due volte in pochi istanti (l'avvio e "Rivedi"): la seconda partenza non riscrive la battuta. */
  if (step === 'b1' && GN.step === 'b1' && performance.now() - (GN.entrato || 0) < 4000) return;
  clearTimeout(GN.timer); GN.timer = null;
  if (GN.step === 'dove' && step !== 'dove'){
    const sopra = document.getElementById('gnSopra');
    if (sopra) sopra.innerHTML = '<img class="gn-genio" id="gnGenio" src="img/genio/genio-rivela.png" alt="">';
  }
  /* LA STORIA, per il tasto indietro del telefono: ogni passo lasciato si mette da parte,
     tranne i due che non si rivedono (il «Mmm…» e la lettura, che sono transizioni). */
  if (GN.step && GN.step !== step && !GN.tornando && ['mmm', 'lettura'].indexOf(GN.step) < 0) GN.storia.push(GN.step);
  GN.tornando = false;
  GN.step = step; GN.entrato = performance.now();
  const r = document.getElementById('gnRisp'), tap = document.getElementById('gnTap');
  const sc = document.getElementById('gnScena');
  const domanda = ['sesso', 'nome', 'sogno', 'quale', 'qualeScrivo', 'chi', 'chiScrivo', 'scrivo', 'daquando', 'quando', 'quandoScrivo', 'posto', 'ore', 'stato', 'conti', 'anno', 'mmm', 'verita', 'prezzo'].indexOf(step) >= 0 && GN.modo !== 'dq';
  if (sc){
    sc.classList.toggle('molte', ['sogno', 'quale', 'chi', 'conti', 'verdetto', 'anno', 'ore', 'tut4', 'scrivo', 'verita', 'prezzo'].indexOf(step) >= 0);
    sc.classList.toggle('carte', ['sogno', 'quale', 'chi'].indexOf(step) >= 0);
    sc.classList.toggle('volo', step === 'dove');
    sc.classList.toggle('con-top', GN.modo === 'dq');
    /* la prima schermata: nessuna nuvoletta, il Genio grande, il testo bianco sul cielo */
    sc.classList.toggle('apertura', step === 'b1');
    sc.classList.remove('ore-centro');
    /* le domande: la nuvoletta si allarga, il testo cresce */
    sc.classList.toggle('domanda', domanda);
  }
  /* lo sfondo: sfocato e piu' scuro sotto alle domande, bianco con l'aereo sul navigatore */
  try{
    const sg = document.getElementById('s-genio');
    if (sg){ sg.classList.toggle('domanda', domanda); sg.classList.toggle('volo', step === 'dove'); sg.classList.toggle('apertura', step === 'b1'); }
  }catch(_){ }
  if (r) r.innerHTML = '';
  if (tap) tap.hidden = true;
  const s = GN_PASSI[step];
  if (s) s.entra();
}
/* IL TASTO INDIETRO DEL TELEFONO torna al passo prima. Vero = l'ho gestito io. */
function gnIndietro(){
  /* la sfida del Genio (genio-sfida.js) decide da sola: domanda prima, oppure uscita */
  if (GN.on && GN.modo === 'ak' && /^gf/.test(GN.step || '') && typeof gfIndietro === 'function') return gfIndietro();
  if (GN.on && GN.modo === 'ak') return (typeof akTastoIndietro === 'function') ? akTastoIndietro() : false;
  /* negli episodi il tasto indietro del telefono torna alla domanda prima, come la freccia */
  /* la serie del Genio (episodi.js): la schermata prima; dalla prima si esce dall'episodio */
  if (GN.on && GN.modo === 'epi'){ if (typeof epiIndietro === 'function' && epiIndietro()) return true; if (typeof epiChiudi === 'function') epiChiudi(); return true; }
  if (GN.on && GN.modo === 'dq'){ if ((GN.step === 'dq' || GN.step === 'dqmmm') && typeof dqIndietro === 'function' && typeof DQ !== 'undefined' && DQ.cron && DQ.cron.length) return dqIndietro(); return false; }
  if (!GN.on) return false;
  try{ if (typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] !== 's-genio') return false; }catch(_){ return false; }
  if (GN.step === 'lettura') return true;            /* la sfera sta leggendo: non si interrompe */
  if (GN.typing){ GN.completa && GN.completa(); return true; }
  if (!GN.storia.length){
    if (GN.rivedi){ gnFine(); return true; }
    return false;                                     /* al primo passo indietro e' uscire, come ovunque */
  }
  const prev = GN.storia.pop();
  GN.tornando = true;
  try{ gnAu.scelta(0); }catch(_){ }
  gnVai(prev);
  return true;
}
function gnBattuta(posa, testo, prossimo){
  gnPosa(posa);
  gnScrivi(testo, function(){ const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false; });
  return { entra: function(){}, tocco: function(){ gnVai(prossimo); } };
}
/* `dopo` gira quando le risposte sono DAVVERO nel DOM, cioe' a macchina da scrivere finita:
   un setTimeout(0) lanciato prima non trova ancora niente (e' cosi' che lo slider restava
   vuoto). */
function gnDomanda(posa, testo, rispHtml, dopo){
  gnPosa(posa);
  gnScrivi(testo, function(){ const r = document.getElementById('gnRisp'); if (r){ r.innerHTML = rispHtml; try{ if (typeof micAvvolgi === 'function') micAvvolgi(r); }catch(_){ } } if (dopo) try{ dopo(); }catch(_){ } });
}
function gnGriglia(voci, fn, uno){
  return '<div class="or-grid' + (uno ? ' one' : '') + '">' + voci.map(function(v){
    return '<button type="button" class="or-a" onclick="event.stopPropagation();' + fn + '(\'' + v.replace(/'/g, '\\\'') + '\')">' + gnEsc(v) + '</button>';
  }).join('') + '</div>';
}

const GN_PASSI = {
  /* le quattro battute: contesto, conflitto, quindi, ma — la danza di Callaway */
  b1: { entra: function(){
    /* 0.9.300: il primo avvio e' l'episodio 1 della serie del Genio (episodi.js): sigla, poi l'apertura */
    if (typeof epiIntroParte === 'function' && epiIntroParte()){ this.tocco = function(){}; return; }
    gnPosa('saluta');
    gnMostra(gnT('apertura'), function(){ const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false; });
    this.tocco = function(){ gnVai('b2'); };
  } },
  b2: { entra: function(){ Object.assign(this, gnBattuta('pensa', gnT('b2'), 'b3')); } },
  b3: { entra: function(){ gnAu.triste(); Object.assign(this, gnBattuta('triste', gnT('b3'), 'b4')); } },
  b4: { entra: function(){
    gnPosa('rivela');
    gnScrivi(gnT('b4'), function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'sesso\')">' + gnEsc(gnT('b4_btn')) + '</button></div>';
    });
  } },

  sesso: { entra: function(){
    gnDomanda('pensa', gnC('sesso', 'Sei un ragazzo o una ragazza?'),
      '<div class="or-grid quattro"><button type="button" class="or-a" onclick="event.stopPropagation();gnSessoScegli(0,\'m\')">Un ragazzo</button><button type="button" class="or-a" onclick="event.stopPropagation();gnSessoScegli(1,\'f\')">Una ragazza</button>'
      + '<button type="button" class="or-a" onclick="event.stopPropagation();gnSessoScegli(2,\'\')">Altro</button><button type="button" class="or-a" onclick="event.stopPropagation();gnSessoScegli(3,\'\')">Preferisco non dirlo</button></div>');
  } },

  /* 1 · IL NOME. Lo chiede il personaggio, come il professore dei Pokémon. */
  nome: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', gnC('nome', 'Come ti chiami?'),
      '<input class="gn-campo" id="gnNome" placeholder="il tuo nome" value="' + gnEsc(d.nome) + '" onclick="event.stopPropagation()" oninput="gnDati().nome=this.value.trim();gnSalva()">'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnRisposta(0,\'sogno\')">Mi chiamo così</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();gnDati().nome=\'\';gnSalva();gnRisposta(0,\'sogno\')">Preferisco non dirlo</button>');
    setTimeout(function(){ try{ const i = document.getElementById('gnNome'); if (i && !d.nome) i.focus(); }catch(_){ } }, 900);
  } },

  /* 2 · IL SOGNO. Le sei carte del Genio: e' la stessa domanda della sua lettura. */
  /* 2 · IL SOGNO. Non tutti vogliono «diventare qualcuno»: c'e' chi vuole vedere il mondo,
     chi vuole la persona giusta, chi vuole imparare uno strumento. La domanda resta quella
     del nome dell'app, ma si dirama: solo chi sceglie di migliorare se stesso si sente
     chiedere CHI vuole diventare (le sei carte del Genio); chi scrive di suo ha un campo. */
  sogno: { entra: function(){
    const n = gnNome(), d = gnDati();
    /* LE CARTE, come in «Pensa alla persona che vuoi diventare»: pannello bianco, due colonne,
       l'emoji sopra al testo. Tutte le voci, senza limite: chi non si trova scrive la sua. */
    gnDomanda('pensa', (n ? n + ', ' : '') + gnT('sogno_domanda'),
      '<div class="gn-carta"><div class="gn-cards">' + gnSogniMostrati().map(function(v){
        return '<button type="button" class="gn-card' + (d.sognoK === v.k ? ' on' : '') + (v.k === 'scrivo' ? ' tratt' : '') + '" onclick="event.stopPropagation();gnSogno(\'' + v.k + '\')"><span>' + v.ico + '</span><b>' + gnEsc(v.t) + '</b><small>' + gnEsc(v.s) + '</small></button>';
      }).join('') + '</div></div>');
  } },
  chi: { entra: function(){
    const T = (typeof OR_TARGETS !== 'undefined') ? OR_TARGETS : [];
    gnDomanda('pensa', gnT('chi_domanda'),
      '<div class="gn-carta"><div class="gn-cards">' + T.map(function(t){
        return '<button type="button" class="gn-card" onclick="event.stopPropagation();gnTarget(\'' + t.id + '\')"><span>' + t.ico + '</span><b>' + gnEsc(t.name) + '</b><small>' + gnEsc(t.sub) + '</small></button>';
      }).join('') + '<button type="button" class="gn-card tratt" onclick="event.stopPropagation();gnVai(\'chiScrivo\')"><span>✍️</span><b>Lo scrivo io</b><small>Con parole mie</small></button></div></div>');
  } },
  chiScrivo: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', 'Dimmelo tu, *con parole tue*. Chi vuoi diventare?',
      '<textarea class="gn-area" id="gnChiArea" rows="3" placeholder="Voglio diventare…" onclick="event.stopPropagation()" oninput="gnDati().targetTesto=this.value.trim();gnSalva()">' + gnEsc(d.targetTesto || '') + '</textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnChiScrivoOk()">Confermo</button></div>');
    setTimeout(function(){ try{ const a = document.getElementById('gnChiArea'); if (a) a.focus(); }catch(_){ } }, 900);
  } },
  quale: { entra: function(){
    const d = gnDati(), g = GN_QUALE[d.sognoK] || GN_QUALE.progetto;
    gnDomanda('pensa', g.q,
      '<div class="gn-carta"><div class="gn-cards">' + g.voci.map(function(v, i){
        return '<button type="button" class="gn-card' + (d.sognoDettaglio === v[3] ? ' on' : '') + '" onclick="event.stopPropagation();gnQuale(' + i + ')"><span>' + v[0] + '</span><b>' + gnEsc(v[1]) + '</b><small>' + gnEsc(v[2]) + '</small></button>';
      }).join('') + '<button type="button" class="gn-card tratt" onclick="event.stopPropagation();gnVai(\'qualeScrivo\')"><span>✍️</span><b>Lo scrivo io</b><small>Con parole mie</small></button></div></div>');
  } },
  qualeScrivo: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', 'Dimmelo tu, *con parole tue*. Di cosa si tratta?',
      '<textarea class="gn-area" id="gnQualeArea" rows="3" placeholder="Per esempio: aprire una scuola di surf" onclick="event.stopPropagation()" oninput="gnDati().sognoDettaglio=this.value.trim();gnSalva()">' + gnEsc(d.sognoDettaglio || '') + '</textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnQualeOk()">Confermo</button></div>');
    setTimeout(function(){ try{ const a = document.getElementById('gnQualeArea'); if (a) a.focus(); }catch(_){ } }, 900);
  } },
  scrivo: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', 'Allora scrivilo tu, *con parole tue*.',
      '<textarea class="gn-area" id="gnArea" rows="4" placeholder="Il mio sogno è…" onclick="event.stopPropagation()" oninput="gnDati().sognoTesto=this.value.trim();gnSalva()">' + gnEsc(d.sognoTesto || '') + '</textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnScrivoOk()">Confermo</button></div>');
    setTimeout(function(){ try{ const a = document.getElementById('gnArea'); if (a) a.focus(); }catch(_){ } }, 900);
  } },

  /* 2a · DA QUANTO TEMPO (0.9.275). Andrea: il primo livello della mappa chiedeva "Da quanto tempo lavori a
     'creare il mio progetto'?", fuori contesto e con l'etichetta della carta al posto del sogno. La domanda sta
     qui, subito dopo il sogno, quando e' ancora davanti agli occhi: la carta scelta si rivede sopra alle
     risposte. Da qui il Genio stima la strada gia' fatta (fl_partenza), senza far calcolare percentuali. */
  daquando: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', 'E per questo sogno, *da quanto tempo ci stai lavorando*?',
      '<div class="or-grid one">' + GN_DAQUANDO.map(function(v, i){
        return '<button type="button" class="or-a' + (d.daQuando === i ? ' main' : '') + '" onclick="event.stopPropagation();gnDaQuando(' + i + ')">' + v[0] + '</button>';
      }).join('') + '</div>');
  } },

  /* 2b · ENTRO QUANDO. La data la sceglie chi sogna; la modalità la calcola il Genio. */
  quando: { entra: function(){
    const d = gnDati();
    gnDomanda('pensa', 'Entro quando vuoi *arrivarci*?',
      '<div class="or-grid quattro">' + GN_QUANDO.map(function(v){
        return '<button type="button" class="or-a' + (d.scadenzaTxt === v[0] ? ' main' : '') + '" onclick="event.stopPropagation();gnQuando(' + v[1] + ',\'' + v[0] + '\')">' + v[0] + '</button>';
      }).join('') + '</div><button type="button" class="gn-link gn-scrivo-link" onclick="event.stopPropagation();gnVai(\'quandoScrivo\')">\u270D\uFE0F Lo scrivo io</button>');
  } },
  /* 0.9.302: la Roadmap dura il tempo scelto qui (sdDurata in sentiero-mappa.js). Chi ha in mente 18 mesi o 4 anni lo
     scrive: un numero e mesi o anni, senza limiti. */
  quandoScrivo: { entra: function(){
    const d = gnDati();
    const anni = d.scadenza >= 12 && d.scadenza % 12 === 0;
    GN.quandoU = GN.quandoU || (anni ? 'anni' : 'mesi');
    const n = d.scadenza ? (GN.quandoU === 'anni' ? d.scadenza / 12 : d.scadenza) : '';
    gnDomanda('pensa', 'Scrivilo tu: *fra quanto tempo* vuoi arrivarci?',
      '<div class="gn-q-riga"><input type="number" inputmode="decimal" min="1" step="any" class="gn-area gn-q-num" id="gnQuandoN" placeholder="18" value="' + gnEsc(String(n)) + '" onclick="event.stopPropagation()" aria-label="Fra quanto tempo">'
      + ['mesi', 'anni'].map(function(u){ return '<button type="button" class="or-a gn-q-u' + (GN.quandoU === u ? ' main' : '') + '" onclick="event.stopPropagation();gnQuandoU(\'' + u + '\', this)">' + u + '</button>'; }).join('') + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnQuandoScrivoOk()">Confermo</button></div>');
    setTimeout(function(){ try{ const a = document.getElementById('gnQuandoN'); if (a) a.focus(); }catch(_){ } }, 900);
  } },

  /* 3 · IL POSTO. La domanda che nessun blocco fa: e' quella che apre il navigatore. */
  posto: { entra: function(){
    gnDomanda('pensa', 'Quel sogno ha un *luogo nel mondo*? Una città o un paese dove ti vedi mentre lo vivi, per esempio New York o Tokyo.',
      gnGriglia(['Sì', 'Non ancora', 'No'], 'gnPosto').replace('or-grid', 'or-grid tre'));
  } },

  /* 3b · DOVE. Qui, e solo qui, l'aereo fra le nuvole: si parte da un posto e si arriva a un
     altro. E' il pannello del navigatore, sopra l'immagine, dentro il film. */
  /* 3b · LA PROMESSA, con il Genio, senza dire «blocco»: chi non vuole bloccare niente non
     deve sentirsi fuori posto. */
  dove0: { entra: function(){
    Object.assign(this, gnBattuta('rivela', 'Allora facciamo una cosa che *nessun\u2019altra app fa*: tracciamo la rotta del tuo sogno, e vediamo se la strada che stai facendo ci porta.', 'dove'));
  } },
  /* 3c · IL NAVIGATORE. L'aereo e' un'immagine orizzontale: a tutto schermo, su un telefono,
     finiva tagliato e coperto dalla vignetta. Qui e' un banner in alto, con il pannello di
     ricerca che gli sporge sopra — com'era nella scheda Viaggio. */
  dove: { entra: function(){
    const st = (typeof rtStato === 'function') ? rtStato() : {};
    const nome = function(p){ return p ? (p.nome || p.name || p.t || p.label || '') : ''; };
    const da = nome(st.da), a = nome(st.a);
    const w = document.getElementById('gnScena');
    const sopra = document.getElementById('gnSopra');
    if (sopra) sopra.innerHTML = '<div class="gn-banner"><div class="gn-banner-img"></div></div>'
      + '<div class="gn-nav">'
      + '<button type="button" class="gn-navrow" onclick="event.stopPropagation();gnCerca(\'da\')"><i>🔵</i><span class="' + (da ? 'on' : '') + '">' + gnEsc(da || 'Da dove parti') + '</span></button>'
      + '<button type="button" class="gn-navrow" onclick="event.stopPropagation();gnCerca(\'a\')"><i>📍</i><span class="' + (a ? 'on' : '') + '">' + gnEsc(a || 'Dove vuoi arrivare') + '</span></button>'
      + '</div>';
    gnScrivi('Da dove parti, e dove vuoi arrivare. *La città in cui ti vedi.*', function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnDopoDove()">' + (a ? 'È qui che voglio arrivare' : 'Lo decido dopo') + '</button></div>';
    });
  } },

  /* 4 · LE ORE. La domanda di Detox, con la risposta di chi non vuole ammetterlo. */
  ore: { entra: function(){
    /* LO SLIDER, non quattro pulsanti: un numero si sceglie con la mano, e la mano dice la
       verita' piu' volentieri di quattro etichette. */
    const d = gnDati(); const v0 = Math.max(1, Math.min(10, Math.round(d.oreN || 3)));
    /* 0.9.284, Andrea (la diciottesima volta): "dici 'ultima domanda' e poi me ne fai un'altra; e chiedi le ore senza
       contestualizzarle". Adesso e' questa l'ultima, e dice perche' conta: subito dopo arriva il tempo vero. */
    gnDomanda('pensa', gnC('ore', 'Ultima domanda, ed è quella che pesa di più sul tuo futuro: quante ore al giorno finiscono sul telefono *senza che tu l’abbia deciso*?'),
      '<div class="gn-carta gn-slider"><b id="gnOreVal">' + gnOreTxt(v0) + '</b>'
      + '<input type="range" id="gnOreRange" min="1" max="10" step="1" value="' + v0 + '" oninput="flRangeFill(this);document.getElementById(\'gnOreVal\').textContent=gnOreTxt(+this.value)" onclick="event.stopPropagation()">'
      + '<div class="gn-ends"><span>1 ora</span><span>10 ore</span></div></div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnOreOk()">Confermo</button></div>',
      /* LA BARRA PIENA SI VEDE DA SUBITO (flRangeFill a DOM pronto e a ogni input). E LO
         SLIDER STA AL CENTRO: a frase finita il Genio e la nuvoletta si stringono, e lo
         slider prende il centro dello schermo. */
      function(){
        flRangeFill(document.getElementById('gnOreRange'));
        const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('ore-centro');
      });
  } },

  /* 5 · COME STAI. La domanda di MyFutureSelf: serve a farsi riconoscere. */
  stato: { entra: function(){
    gnDomanda('pensa', 'Quale di queste frasi ti descrive meglio, *oggi*?',
      gnGriglia(['🧱 Mi sento bloccato', '🎢 Ci provo, ma non sono costante', '📈 Sto facendo progressi', '🚀 Vado bene, ma voglio di più'], 'gnStato', true));
  } },

  /* 6 · I CONTI. Piu' di una risposta: e' il quadro, non la diagnosi. */
  conti: { entra: function(){
    const d = gnDati(), l = d.conti || [];
    const voci = ['⏳ Rimando tutto', '🌀 Penso troppo', '😴 Dormo male', '🔋 Poca motivazione', '🐿️ Mi distraggo con niente', '🧭 Nessuna direzione chiara', '🪞 Poca fiducia in me'];
    gnDomanda('pensa', 'Con che cosa stai facendo i conti, in questo periodo? *Puoi dirmene più di una.*',
      '<div class="gn-multi">' + voci.map(function(v){
        return '<button type="button" class="gn-opt' + (l.indexOf(v) >= 0 ? ' on' : '') + '" onclick="event.stopPropagation();gnConti(this,\'' + v + '\')">' + gnEsc(v) + '</button>';
      }).join('') + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a" id="gnContiOk" ' + (l.length ? '' : 'disabled') + ' onclick="event.stopPropagation();gnContiOk()">Confermo</button></div>');
  } },

  /* 7 · FRA UN ANNO. I cinque pulsanti di Akinator, nella sua griglia. */
  anno: { entra: function(){
    gnDomanda('pensa', 'Se continui *esattamente così*, fra un anno sei più vicino a quel sogno?',
      '<div class="or-grid">' + ['Probabilmente', 'Probabilmente no', 'Sì', 'Non lo so', 'No'].map(function(v){
        return '<button type="button" class="or-a" onclick="event.stopPropagation();gnAnno(\'' + v + '\')">' + v + '</button>';
      }).join('') + '</div>');
  } },

  mmm: { entra: function(){
    gnPosa('pensa');
    gnScrivi('Mmm…', function(){ setTimeout(function(){ if (GN.step !== 'mmm') return; gnScrivi(GN.mmmFrase || '', function(){ const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false; }); }, 420); });
  }, tocco: function(){ gnVai(GN.mmmNext || 'stato'); } },

  /* 8 · LA LETTURA. Il Genio pensa, la sfera si illumina, e le cose che sta guardando
     compaiono una alla volta con la spunta: si vede che i dati vengono presi in considerazione,
     non che gira una ruota. La musica sale, e il verdetto cade con il picco. */
  lettura: { entra: function(){
    gnApplica();
    let sogno = 'quel sogno'; try{ sogno = gnLettura().sogno || sogno; }catch(_){ }
    gnTraiettoria(['Come stai, oggi', 'Con che cosa stai facendo i conti', 'La strada fino a ' + sogno.toLowerCase()], function(){ if (GN.step === 'lettura') gnVai('verdetto'); });
  } },
  verdetto: { entra: function(){
    const L = gnLettura(), d = gnDati(), n = gnNome();
    gnPosa('rivela'); gnVibra(60);
    /* NON E' UN'ETICHETTA SU CHI SEI: e' dove porta la strada di adesso, se resta questa.
       «Stai diventando» suonava come un giudizio; «rischi di diventare» e' una previsione, e
       una previsione si puo' smentire. */
    /* UNA COSA ALLA VOLTA. Prima c'erano quattro riquadri insieme, con la data d'arrivo e una
       «modalita' difficile, cinque passi al giorno» che nessuno aveva mai spiegato. La data si
       guadagna in sette giorni (domande.js); la modalita' si calcola e basta. Qui resta la
       carta di chi rischi di diventare, e dopo un tocco la probabilita'. */
    gnScrivi(gnT('verdetto_intro', { nome: (n ? n + ', ' : ''), profilo: L.prof.name }), function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="gn-profilo"><span>' + L.prof.ico + '</span><b>' + gnEsc(L.prof.name) + '</b><p>' + gnEsc(L.prof.desc || '') + '</p></div>'
        + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnVai(\'verdetto2\')">' + gnEsc(gnT('verdetto_btn')) + '</button></div>';
    });
  } },
  /* LA PENNA LA CHIEDE LUI. Prima qui c'era il confronto «così / con una rotta», pronto,
     servito: e un confronto servito prima che uno lo chieda sa di vendita, e chi sente
     odore di vendita chiude l'app. Adesso il Genio da' UN numero e sta zitto. Il pulsante
     e' la domanda dell'utente; solo dopo arriva la risposta, e la risposta non e' l'app:
     sono le sue ore. */
  verdetto2: { entra: function(){
    const L = gnLettura();
    gnPosa('pensa');
    gnScrivi(gnT('verdetto2', { sogno: L.sognoBreve || L.sogno, pct: L.pct + '%' }), function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="gn-prob uno"><div><small>Ad oggi</small><b class="rosso">' + L.pct + '%</b></div></div>'
        + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();gnVai(\'verdetto3\')">' + gnEsc(gnT('verdetto2_btn')) + '</button></div>';
    });
  } },
  verdetto3: { entra: function(){
    const L = gnLettura();
    const oreAnno = Math.round(L.ore * 365);
    /* gli anni che restano fino a 80: dalla data di nascita se c'e', altrimenti 50 */
    let restano = 50; try{ const b = (typeof mmNascita === 'function') ? mmNascita() : ''; if (b){ const eta = (Date.now() - new Date(b + 'T00:00:00').getTime()) / (365.25 * 86400000); restano = Math.max(5, Math.round(80 - eta)); } }catch(_){ }
    const anniVita = Math.max(1, Math.round(L.ore * 365 * restano / 8766));
    gnPosa('rivela'); gnVibra(40);
    const dv = gnDati(); const oreTxt = (+dv.oreVere > 0) ? gnDurataTxt(dv.oreVere * 60) : gnOreTxt(L.ore);
    gnScrivi(gnT('verdetto3', { ore: oreTxt, oreAnno: oreAnno, anniVita: anniVita, pct2: L.pctRotta + '%' }), function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="gn-prob"><div><small>Ad oggi</small><b class="rosso">' + L.pct + '%</b></div><i>→</i><div><small>Con quelle ore</small><b class="verde">' + L.pctRotta + '%</b></div></div>'
        + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'patto\')">' + gnEsc(gnT('verdetto3_btn')) + '</button></div>';
    });
  } },

  /* 9 · IL PATTO. La leva di Focus Friend: il Genio ci resta male, e si vede. Poi si
     rialza, e nasce la partita. */
  /* 9 · LA SFERA E' SUA. Il Genio triste senza una causa non reggeva: perche' dovrebbe restarci
     male lui, se a distrarsi e' l'utente? Focus Friend funziona perche' il fagiolo VIVE nel
     telefono e ogni distrazione gli fa cadere i punti a maglia: causa ed effetto. Qui la causa
     e' la sfera: e' legata a chi legge, si accende con i suoi passi, si spegne con le sue
     distrazioni — e quando e' spenta il Genio non vede piu' il suo futuro. La posa triste ha la
     sfera grigia proprio per questo. */
  patto: { entra: function(){
    /* 0.9.300: il patto e il cliffhanger dell'episodio 1 vengono da content/episodi.json */
    if (typeof epiIntroPatto === 'function' && epiIntroPatto()) return;
    Object.assign(this, gnBattuta('rivela', 'La sfera che tengo in mano non è mia: *è tua*. Si accende ogni volta che fai un passo verso il tuo sogno, e mi fa vedere dove stai andando.', 'patto2'));
  } },
  patto2: { entra: function(){
    gnAu.triste();
    Object.assign(this, gnBattuta('triste', 'Ogni volta che il telefono ti porta via, *si spegne un po\u2019*. E io perdo un pezzo del tuo futuro, senza poterlo riaccendere da solo.', 'patto3'));
  } },
  patto3: { entra: function(){
    const n = gnNomi();
    gnPosa('rivela'); gnAu.punto();
    gnScrivi('Ogni volta che resisti, *torna a brillare*. Per questo terrò il conto, giorno per giorno: tu contro ' + n.vecchio + '.', function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'salva\')">La tengo accesa io</button></div>';
    });
  } },

  /* 10 · SALVA LA ROTTA. Il login in fondo, solo Google o email, al centro. */
  salva: { entra: function(){
    let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ }
    if (u && u.mail){ gnFine(); return; }
    const n = gnNome();
    gnDomanda('saluta', 'Adesso salva la rotta' + (n ? ' di ' + n : '') + ', così la ritrovi anche sul PC *o se cambi telefono*.',
      '<div class="gn-auth"><button type="button" class="gn-authbtn" onclick="event.stopPropagation();gnAuth(\'google\')">Salva con Google</button>'
      + '<button type="button" class="gn-authbtn sec" onclick="event.stopPropagation();gnAuth(\'email\')">Con l’email</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();gnFine()">Dopo</button>');
  } }
};

/* ---------- le risposte ---------- */
function gnRisposta(i, prossimo){ gnAu.scelta(i); gnVibra(18); gnVai(prossimo); }
/* I sogni, con la persona del Genio che ci sta dietro (serve alla sua lettura) e con il
   segno di chi cerca liberta' e tempo: e' a loro che il blocco va spiegato come protezione. */
/* I SOGNI: un catalogo solo, e a ogni persona se ne mostrano QUATTRO piu' «lo scrivo io».
   Nove voci in fila erano una decisione di troppo; e chi arriva dal quadro con il cane non
   cerca le stesse cose di chi arriva dalla Focus Box. La FONTE la porta il link di download
   (`?fonte=focusbox`, `arte`, `fede`, `coscienza`, `fitness`, `creator`, `studenti`) e resta
   salvata. Un flusso solo; cambiano le carte e una battuta. */
/* UN SOGNO E' UNA CONSEGUENZA DESIDERATA, mai una fuga. «Dominare la sessione» e «riprendere
   il controllo» non sono sogni: sono un dolore da cui scappare. Chi va bene a scuola sogna la
   carriera, o vivere della materia che ama; chi va male, quella scuola la odia. Le carte dicono
   il traguardo, non il muro. I testi li scrive il Copywriter. */
/* IL COPY E' DI ANDREA (30/09): titolo e descrizione come li ha scritti lui, area per area.
   `alt` e' la variante per un pubblico preciso (la fonte del link di download): «Costruire il
   mio impero» a chi arriva dal pubblico giovane e dai creator, «Scolpire il mio corpo» a chi
   arriva dal fitness. La liberta' si vende con il viaggio e il mondo, non con una scrivania. */
const GN_SOGNI = [
  /* 0.9.293, Andrea: "creare il mio progetto e' troppo generico, eccellere nello studio non lo sogna nessuno: si sogna
     di vivere della propria passione". Dopo queste due carte il Genio chiede di che cosa si tratta (passo «quale»). */
  { k: 'progetto',   ico: '💡', t: 'Realizzare il mio progetto', s: 'Avviare un\u2019attività, un business, dare vita a una mia idea', target: 'lavoro',
    alt: { creator: { t: 'Costruire il mio impero', s: 'Un\u2019attività mia: il primo cliente, poi cento' }, focusbox: { t: 'Costruire il mio impero', s: 'Un\u2019attività mia: il primo cliente, poi cento' }, studenti: { t: 'Costruire il mio impero', s: 'Un\u2019attività mia: il primo cliente, poi cento' } } },
  { k: 'passione',   ico: '💼', t: 'Vivere della mia passione', s: 'Trasformare quello che amo nel mio lavoro', target: 'studio' },
  { k: 'famiglia',   ico: '❤️', t: 'Costruire la mia famiglia', s: 'Trovare la persona giusta, o coltivare le mie relazioni più importanti', target: 'presenza' },
  { k: 'corpo',      ico: '👟', t: 'Trasformare il mio corpo', s: 'Raggiungere la massima forma fisica, salute e vitalità', target: 'corpo',
    alt: { fitness: { t: 'Scolpire il mio corpo', s: 'Raggiungere la massima forma fisica e disciplina' } } },
  { k: 'capolavoro', ico: '🎨', t: 'Creare il mio capolavoro', s: 'Scrivere un libro, lanciare un album o creare arte', target: 'arte' },
  { k: 'voce',       ico: '🎙️', t: 'Far sentire la mia voce', s: 'Diventare un creator, un influencer o uno YouTuber di successo', target: 'lavoro' },
  { k: 'fede',       ico: '🙏', t: 'Nutrire la mia fede', s: 'Vivere secondo la Parola, pregare e proteggere la mia anima dalle tentazioni moderne', target: 'presenza' },
  { k: 'coscienza',  ico: '✨', t: 'Risvegliare la mia coscienza', s: 'Praticare meditazione, connettermi con la mia anima e allinearmi con l\u2019Universo', target: 'presenza' },
  { k: 'liberta',    ico: '🌍', t: 'Viaggiare ed essere libero', s: 'Vedere il mondo e lavorare da dove voglio', target: 'lavoro' },
  { k: 'scrivo',     ico: '✍️', t: 'Ho un sogno unico ✨', s: 'Voglio scriverlo io…', target: 'lavoro' }
];
const GN_FONTI = {
  base:      ['progetto', 'passione', 'famiglia', 'liberta'],
  focusbox:  ['liberta', 'progetto', 'passione', 'corpo'],
  arte:      ['capolavoro', 'passione', 'progetto', 'famiglia'],
  fede:      ['fede', 'famiglia', 'liberta', 'corpo'],
  coscienza: ['coscienza', 'liberta', 'capolavoro', 'famiglia'],
  fitness:   ['corpo', 'liberta', 'progetto', 'famiglia'],
  creator:   ['voce', 'progetto', 'capolavoro', 'passione'],
  studenti:  ['passione', 'progetto', 'liberta', 'famiglia']
};
function gnFonte(){
  let f = '';
  try{ f = new URLSearchParams(location.search).get('fonte') || ''; if (f) localStorage.setItem('fl_fonte', f); }catch(_){ }
  if (!f){ try{ f = localStorage.getItem('fl_fonte') || ''; }catch(_){ } }
  return GN_FONTI[f] ? f : 'base';
}
function gnSogniMostrati(){
  const f = gnFonte();
  const chiavi = GN_FONTI[f].concat(['scrivo']);
  return chiavi.map(function(k){
    const v = GN_SOGNI.filter(function(x){ return x.k === k; })[0]; if (!v) return null;
    const a = v.alt && v.alt[f];
    return a ? Object.assign({}, v, a) : v;
  }).filter(Boolean);
}
function gnSogno(k){
  const v = gnSogniMostrati().filter(function(x){ return x.k === k; })[0] || GN_SOGNI.filter(function(x){ return x.k === k; })[0]; if (!v) return;
  const d = gnDati(); d.sogno = v.ico + ' ' + v.t.replace(/\s*✨$/, ''); d.sognoK = k; d.liberta = (k === 'liberta');
  if (v.target) d.target = v.target;
  gnSalva(); gnAu.scelta(1); gnVibra(18);
  /* «Riprendere il controllo» dice il come, non il dove: si chiede chi vuole diventare */
  if (!v.target && k !== 'scrivo'){ gnVai('chi'); return; }
  if (k === 'scrivo'){ gnVai('scrivo'); return; }
  if (GN_QUALE[k]){ d.sognoDettaglio = ''; gnSalva(); gnVai('quale'); return; }
  gnVai('daquando');
}
/* 0.9.293: "di che progetto si tratta?". La carta dice l'area; qui si sceglie la cosa vera, e il sogno salvato diventa
   quella (la roadmap, la spinta e la mappa la mostrano al posto dell'etichetta della carta). */
const GN_QUALE = {
  progetto: { q: 'Di che *progetto* si tratta?', voci: [
    ['🏪', 'Un\u2019attività o un business', 'Un servizio, uno studio, un locale', 'Avviare la mia attività'],
    ['🛒', 'Un negozio online', 'Vendere prodotti su internet', 'Aprire il mio negozio online'],
    ['🧪', 'Un prodotto nuovo', 'Un\u2019invenzione che risolve un problema', 'Lanciare il mio prodotto'],
    ['🤝', 'Un\u2019associazione', 'Beneficenza, volontariato, una causa', 'Fondare la mia associazione'],
    ['🎭', 'Arte e spettacolo', 'Attore, cantante, musicista', 'Vivere di arte e spettacolo'] ] },
  passione: { q: 'Quale *passione* vuoi far diventare il tuo lavoro?', voci: [
    ['📚', 'Insegnarla agli altri', 'Una materia che ami, da spiegare', 'Insegnare quello che amo'],
    ['🎭', 'Arte, musica o spettacolo', 'Attore, cantante, musicista', 'Vivere di arte e spettacolo'],
    ['🩺', 'La professione che sogno', 'Medico, avvocato, architetto…', 'Diventare il professionista che sogno'],
    ['🏅', 'Lo sport', 'Atleta, allenatore, istruttore', 'Vivere del mio sport'],
    ['🎙️', 'Contenuti online', 'Video, podcast, social', 'Vivere dei miei contenuti'] ] }
};
function gnQuale(i){
  const d = gnDati(), g = GN_QUALE[d.sognoK]; if (!g || !g.voci[i]) return;
  const v = g.voci[i]; d.sognoDettaglio = v[3]; d.sogno = v[0] + ' ' + v[3];
  gnSalva(); gnRisposta(1, 'daquando');
}
function gnQualeOk(){
  const d = gnDati(), t = (d.sognoDettaglio || '').trim();
  if (!t){ try{ document.getElementById('gnQualeArea').focus(); }catch(_){ } return; }
  const v = GN_SOGNI.filter(function(x){ return x.k === d.sognoK; })[0];
  d.sogno = ((v && v.ico) || '✨') + ' ' + t.charAt(0).toUpperCase() + t.slice(1);
  gnSalva(); gnAu.scelta(1); gnVibra(18);
  gnMmm('Mmm… *adesso so di cosa parliamo.* Me lo segno.', 'daquando');
}
function gnScrivoOk(){
  gnAu.scelta(1); gnVibra(18);
  if ((gnDati().sognoTesto || '').trim()){ gnMmm('Mmm… *con parole tue.* Le tengo da parte: un giorno te le rileggerò, e vedrai che effetto fa.', 'daquando'); return; }
  gnVai('daquando');
}
function gnTarget(id){ const d = gnDati(); d.target = id; d.targetTesto = ''; gnSalva(); gnRisposta(1, 'daquando'); }
function gnChiScrivoOk(){
  const d = gnDati(); if (!d.target) d.target = 'lavoro'; gnSalva(); gnAu.scelta(1); gnVibra(18);
  if ((d.targetTesto || '').trim()){ gnMmm('Mmm… *con parole tue.* Meglio di qualunque etichetta mia. Le tengo.', 'daquando'); return; }
  gnVai('daquando');
}
/* ENTRO QUANDO. Chi ha una data ha fretta, e la fretta decide la modalità della partita:
   quanti passi al giorno servono per arrivare in tempo. Chi non ce l'ha gioca normale. */
const GN_QUANDO = [['6 mesi', 6], ['1 anno', 12], ['2 anni', 24], ['Non ho una data', 0]];
/* le risposte, e la strada gia' fatta che il Genio ne deduce (la ricalibra l'agente, o "Da dove parti?") */
const GN_DAQUANDO = [['Non ho ancora iniziato', 0], ['Da meno di un anno', 0.10], ['Da uno a tre anni', 0.25], ['Da più di tre anni', 0.40]];
function gnDaQuando(i){
  const d = gnDati(); d.daQuando = i; gnSalva();
  try{
    const prima = JSON.parse(localStorage.getItem('fl_partenza') || 'null');
    if (!prima || prima.da === 'onboarding') localStorage.setItem('fl_partenza', JSON.stringify({ pct: GN_DAQUANDO[i][1], at: Date.now(), da: 'onboarding', risposte: { tempo: i } }));
  }catch(_){ }
  gnRisposta(i, 'quando');
}
function gnQuando(m, t){
  const d = gnDati(); d.scadenza = +m || 0; d.scadenzaTxt = (+m ? t : ''); gnSalva();
  /* 0.9.302: la scelta nuova vale per la durata della Roadmap (sdDurata), anche al posto di una decisa prima */
  try{ localStorage.removeItem('fl_sd_durata'); }catch(_){ }
  gnRisposta(1, 'posto');
}
function gnQuandoU(u, btn){
  GN.quandoU = u;
  try{ btn.parentNode.querySelectorAll('.gn-q-u').forEach(function(b){ b.classList.toggle('main', b === btn); }); }catch(_){ }
  gnVibra(8);
}
function gnQuandoScrivoOk(){
  const el = document.getElementById('gnQuandoN');
  const n = parseFloat(String((el && el.value) || '').replace(',', '.'));
  if (!(n > 0)){ try{ el.focus(); }catch(_){ } return; }
  const mesi = Math.max(1, Math.round(GN.quandoU === 'anni' ? n * 12 : n));
  const a = Math.floor(mesi / 12), m = mesi % 12;
  const txt = (a ? (a === 1 ? '1 anno' : a + ' anni') : '') + (a && m ? ' e ' : '') + (m ? (m === 1 ? '1 mese' : m + ' mesi') : '');
  const d = gnDati(); d.scadenza = mesi; d.scadenzaTxt = txt; gnSalva();
  try{ localStorage.removeItem('fl_sd_durata'); }catch(_){ }
  gnRisposta(1, 'posto');
}
/* Chi arriva dalla Focus Box sa gia' di avere un problema di distrazione: la domanda sulle
   ore non gliela si fa, si passa avanti (il rapporto del tempo dira' il numero vero). */
/* 0.9.260, Andrea: le ore al telefono si chiedevano DUE volte (qui, prima di "Quale di queste frasi ti
   descrive meglio", e di nuovo prima del rapporto del tempo). Si chiedono una volta sola, li', subito prima
   di vedere il tempo vero: qui si passa direttamente a come stai. */
/* 0.9.267, Andrea: la domanda delle ore (lo slider) non si faceva piu' — nessuno ci arrivava. Si chiede sempre,
   prima dello stato d'animo; il rapporto vero (S6) poi la confronta con la stima. */
/* 0.9.280, Andrea: "la domanda delle ore la stai facendo troppo presto, e poi non mostri neanche il tempo vero.
   Va fatta per ultima, subito prima del permesso di leggere i dati di utilizzo". Qui si passa a come stai;
   le ore si chiedono in gnFine, un attimo prima della pagina del permesso e del rapporto (s6). */
function gnDopoDove(){
  gnRisposta(2, 'stato');
}
function gnPosto(v){
  const d = gnDati(); d.posto = v; gnSalva(); gnAu.scelta(2); gnVibra(18);
  gnVai(v === 'Sì' ? 'dove0' : 'stato');
}
function gnCerca(quale){ GN.attesaDove = true; if (typeof rtApriCerca === 'function') rtApriCerca(quale); }
/* indietro dalla ricerca del luogo aperta dall'onboarding: si torna al pannello «Da dove parti».
   `dallaNav` = la chiama il tasto indietro, che poi va da solo su s-genio. */
function gnCercaAnnullata(dallaNav){
  if (!GN.attesaDove) return false;
  GN.attesaDove = false;
  if (!dallaNav) goId('s-genio');
  setTimeout(function(){ gnVai('dove'); }, dallaNav ? 60 : 0);
  return true;
}
/** La parte piena di uno slider, prima della maniglia (input[type=range] usa --fill). */
function flRangeFill(el){
  if (!el) return;
  const min = +el.min || 0, max = +el.max || 100, v = +el.value || 0;
  el.style.setProperty('--fill', Math.round((v - min) / Math.max(1e-6, max - min) * 100) + '%');
  /* la traccia la disegna registry.js con --p (il suo foglio vince su --fill): si scrivono tutte e due */
  try{ if (typeof flRangeSync === 'function') flRangeSync(el); }catch(_){ }
}
/* ore intere: «3 ore», non «3h»; se arriva un mezzo da una versione vecchia, si arrotonda */
function gnOreTxt(v){ v = Math.round(+v || 0); return v === 1 ? '1 ora' : v + ' ore'; }
function gnOreOk(){
  const el = document.getElementById('gnOreRange'); const v = el ? +el.value : 3;
  const d = gnDati(); d.oreN = v;
  try{ localStorage.setItem('fl_estimate', String(v)); }catch(_){ }   /* la stima che il rapporto S6 confronta */
  /* l'etichetta di prima, per chi la legge ancora (la lettura, il rapporto) */
  d.ore = v < 2 ? '⏱ Meno di 2' : v < 4 ? '⏱ Da 2 a 4' : v < 6 ? '⏱ Da 4 a 6' : '🙈 Più di quante voglio ammettere';
  gnSalva();
  GN.oreChieste = true;
  if (v >= 6){ gnMmm(gnC('ore_mmm', 'Mmm… *{ore}.* Non ti giudico: me lo segno. Adesso vediamo cosa dice il tuo telefono.', { ore: gnOreTxt(v) }), 'verita'); return; }
  gnVai('verita');
}
function gnOre(v){ const d = gnDati(); d.ore = v; gnSalva(); gnRisposta(3, 'stato'); }
/* «MMM…». Quando la risposta merita una pausa, il Genio la fa: prima il mugugno, poi la
   frase, poi si tocca per andare avanti. E' lo stesso «Mmm…» della lettura dalla sfera. */
function gnMmm(frase, prossimo){ GN.mmmFrase = frase; GN.mmmNext = prossimo; gnVai('mmm'); }
function gnStato(v){
  const d = gnDati(); d.stato = v.replace(/^[^ ]+ /, ''); gnSalva();
  try{ if (typeof ONB !== 'undefined'){ ONB.stato = d.stato; onbSave(); } }catch(_){ }
  if (/bloccato/i.test(v)){ gnMmm('Mmm… *bloccato.* Chi me lo dice così, di solito, sa già da dove ripartire. Vediamo se è vero.', 'conti'); return; }
  gnRisposta(4, 'conti');
}
function gnConti(el, v){
  const d = gnDati(); const l = (d.conti || []).slice(); const j = l.indexOf(v);
  if (j >= 0) l.splice(j, 1); else l.push(v);
  d.conti = l; gnSalva(); el.classList.toggle('on', j < 0); gnVibra(12);
  try{ if (typeof ONB !== 'undefined'){ ONB.conti = l.map(function(x){ return x.replace(/^[^ ]+ /, ''); }); onbSave(); } }catch(_){ }
  const b = document.getElementById('gnContiOk'); if (b) b.disabled = !l.length;
}
function gnAnno(v){
  const d = gnDati(); d.anno = v; gnSalva(); gnAu.scelta(6); gnVibra(18);
  /* 0.9.282, Andrea (la decima volta): la domanda delle ore va SUBITO PRIMA della probabilita' di successo, perche'
     e' lei che la tiene bassa. Dopo l'anno: le ore; dopo le ore: la lettura e il verdetto con il conto della vita. */
  if (v === 'No'){ gnMmm('Mmm… *lo sai.* È già più di quanto sappia chi non se lo chiede mai. Un\u2019ultima domanda, poi guardo.', 'ore'); return; }
  gnVai('ore');
}
function gnContiOk(){
  const l = gnDati().conti || [];
  if (l.some(function(x){ return /direzione chiara/.test(x); })){ gnMmm('Mmm… *senza direzione.* Allora la prima cosa che ti do non è una regola: è una rotta.', 'anno'); return; }
  gnRisposta(5, 'anno');
}
function gnAuth(kind){ GN.attesaAuth = true; try{ openSheet(kind); }catch(_){ GN.attesaAuth = false; } }

/* ---------- IL TEMPO VERO, SUBITO DOPO LA STIMA (0.9.284) ----------
   Andrea, diciotto volte: "dopo che l'utente ha detto quante ore pensa di passare sul telefono, mostragli il report vero
   del tempo speso, e il prezzo che paga in tempo perso se continua cosi'". Prima il report vero arrivava solo in fondo al
   film (la pagina s6, dopo il patto e il login) e in "Rivedi soltanto" non arrivava mai. Adesso sta qui, nel film: la
   stima, il numero vero degli ultimi sette giorni accanto, poi il prezzo. Senza il permesso dei dati d'uso, il Genio lo
   chiede proprio qui; senza telefono (anteprima nel browser) il prezzo si fa con la stima, e lo dice. */
const GN_VER = { dati: null, attesa: false };
async function gnVeritaLeggi(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return null;
  try{
    const g = NATIVE.isUsageAccessGranted ? await NATIVE.isUsageAccessGranted() : await NATIVE.getScreenTimeToday();
    if (!g || !g.granted) return { negato: true };
    const start = new Date(); start.setHours(0, 0, 0, 0);
    /* 0.9.331: qui si parla del telefono, e il conto parte dai millisecondi */
    const r = await (typeof mwTelefono === 'function' ? mwTelefono('getScreenTimeRange', { from: start.getTime() - 6 * 86400000, to: Date.now(), bucket: 'day' }) : NATIVE.getScreenTimeRange({ from: start.getTime() - 6 * 86400000, to: Date.now(), bucket: 'day' }));
    const giorni = ((r && r.buckets) || []).map(function(b){ return { d: new Date(b.start), min: b.ms != null ? b.ms / 60000 : (b.minutes || 0) }; });
    const piene = giorni.slice(0, -1).filter(function(x){ return x.min > 0; });
    const base = piene.length ? piene : giorni;
    const min = base.reduce(function(a, x){ return a + x.min; }, 0) / (base.length || 1);
    return { min: min, giorni: giorni };
  }catch(_){ return null; }
}
function gnDurataTxt(min){
  min = Math.max(0, Math.round(min || 0));
  const h = Math.floor(min / 60), m = min % 60;
  if (!h) return m + ' minuti';
  return (h === 1 ? '1 ora' : h + ' ore') + (m ? ' e ' + m + ' minuti' : '');
}
function gnOreBreve(min){ min = Math.round(min || 0); return (min >= 60 ? Math.floor(min / 60) + 'h ' : '') + (min % 60) + 'm'; }
GN_PASSI.verita = { entra: function(){
  const d = gnDati(); const stima = +d.oreN || 3;
  gnPosa('pensa');
  GN_VER.prossimo = null;
  /* 0.9.300: il tempo vero e' il momento in cui il Genio smaschera il primo ladro: l'app che si prende piu' tempo */
  GN_VER.ladro = null;
  try{ if (typeof epiLadroLeggi === 'function') epiLadroLeggi().then(function(l){ GN_VER.ladro = l; }); }catch(_){ }
  gnScrivi(gnC('verita_attesa', 'Hai detto *{ore}*. Vediamo cosa dice il tuo telefono…', { ore: gnOreTxt(stima) }), function(){
    /* 0.9.292, Andrea: "dopo Hai detto 4 ore, vediamo cosa dice il tuo telefono, va avanti da solo senza che abbia
       toccato niente". La frase resta finche' non tocchi, come tutte le altre battute del Genio; intanto il tempo
       vero si legge gia', cosi' al tocco arriva subito. */
    const lettura = gnVeritaLeggi();
    const tap0 = document.getElementById('gnTap'); if (tap0) tap0.hidden = false;
    GN_VER.prossimo = function(){
    if (tap0) tap0.hidden = true;
    /* 0.9.331, Andrea: i tre puntini restavano li' a fluttuare mentre il Genio scriveva, come un caricamento che non finisce. Il dato e' gia' stato letto */
    const r = document.getElementById('gnRisp');
    if (r) r.innerHTML = '';
    lettura.then(function(v){
      if (GN.step !== 'verita') return;
      GN_VER.dati = v;
      /* un telefono senza dati non e' un telefono che dice "0 minuti": il prezzo si fa con la stima */
      if (!v || (!v.negato && !(v.min >= 1))){ gnVai('prezzo'); return; }
      if (v.negato){
        gnScrivi(gnC('verita_permesso', 'Il tuo telefono sa quante ore sono davvero. *Mi dai il permesso di guardare?* Leggo solo il tempo, e quello che leggo resta sul telefono.'), function(){
          const rr = document.getElementById('gnRisp');
          if (rr) rr.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVeritaPermesso()">' + gnEsc(gnC('verita_permesso_btn', 'Mostrami il tempo vero')) + '</button></div>';
          /* 0.9.293, Andrea: niente "Continua con la mia stima": e' la polvere sotto il tappeto, il tempo vero si mostra */
        });
        return;
      }
      /* il tempo vero c'e': si salva, cosi' la lettura, il verdetto e il rapporto usano questo */
      d.oreVere = Math.round(v.min / 60 * 10) / 10; gnSalva();
      try{ localStorage.setItem('fl_report', JSON.stringify({ avg: Math.round(v.min), years: (v.min / 1440) * 30, at: Date.now() })); }catch(_){ }
      GN.veritaFatta = true;
      const diff = Math.round(v.min - stima * 60);
      const giudizio = Math.abs(diff) < 20 ? gnC('giudizio_uguale', 'Ci hai preso: lo sai già.') : (diff > 0 ? gnC('giudizio_piu', 'È *{diff} in più* di quanto pensavi.', { diff: gnDurataTxt(diff) }) : gnC('giudizio_meno', 'Meno di quanto pensavi: *{diff}* in meno.', { diff: gnDurataTxt(-diff) }));
      gnPosa(diff > 20 ? 'triste' : 'rivela');
      gnScrivi(gnC('verita_dato', 'Il tuo telefono dice *{vere}* al giorno. {giudizio}', { vere: gnDurataTxt(v.min), giudizio: giudizio }), function(){
        const rr = document.getElementById('gnRisp'); if (!rr) return;
        const max = Math.max(60, v.giorni.reduce(function(m, x){ return Math.max(m, x.min); }, 0));
        const dn = ['D', 'L', 'M', 'M', 'G', 'V', 'S'];
        const ladro = GN_VER.ladro;
        rr.innerHTML = '<div class="gn-ver"><small>' + gnEsc(gnC('verita_media', 'La tua media degli ultimi 7 giorni')) + '</small><b class="gn-ver-n">' + gnOreBreve(v.min) + '</b><span>' + gnEsc(gnC('verita_sotto', 'al giorno, sul telefono')) + '</span>'
          + '<div class="gn-ver-barre">' + v.giorni.map(function(x){ return '<div><i style="height:' + Math.max(4, Math.round(x.min / max * 100)) + '%"></i><small>' + dn[x.d.getDay()] + '</small></div>'; }).join('') + '</div>'
          + '<p class="gn-ver-cfr"><span>' + gnEsc(gnC('verita_stima', 'La tua stima')) + '</span><b>' + gnOreTxt(stima) + '</b></p>'
          + (ladro && typeof epiUi === 'function' ? '<p class="gn-ver-cfr gn-ver-ladro"><span>' + gnEsc(epiUi('ladro_kick')) + '</span><b>' + gnEsc(epiUi('ladro_riga', { ladro: ladro.nome, tempo: ladro.tempo })) + '</b></p>' : '') + '</div>'
          + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'prezzo\')">' + gnEsc(gnC('verita_btn', 'Quanto mi costa, se continuo così?')) + '</button></div>';
      });
    });
    };
  });
}, tocco: function(){
  if (typeof GN_VER.prossimo !== 'function') return;
  const f = GN_VER.prossimo; GN_VER.prossimo = null; f();
} };
function gnVeritaPermesso(){
  GN_VER.attesa = true;
  try{ if (typeof openPerm === 'function') openPerm('usage'); }catch(_){ }
}
/* tornando dalle Impostazioni di Android con il permesso dato, il Genio rilegge e mostra il tempo vero */
document.addEventListener('visibilitychange', function(){
  if (document.hidden || !GN_VER.attesa) return;
  setTimeout(function(){ if (GN.on && GN.step === 'verita'){ GN_VER.attesa = false; GN.step = ''; gnVai('verita'); } }, 500);
});
GN_PASSI.prezzo = { entra: function(){
  const d = gnDati();
  const vero = +d.oreVere > 0;
  const ore = vero ? +d.oreVere : (+d.oreN || 3);
  const oreAnno = Math.round(ore * 365), giorniAnno = Math.round(ore * 365 / 24);
  let restano = 50; try{ const b = (typeof mmNascita === 'function') ? mmNascita() : ''; if (b){ const eta = (Date.now() - new Date(b + 'T00:00:00').getTime()) / (365.25 * 86400000); restano = Math.max(5, Math.round(80 - eta)); } }catch(_){ }
  const anni = Math.max(1, Math.round(ore * 365 * restano / 8766));
  gnPosa('triste'); gnVibra(40);
  gnScrivi(gnC('prezzo', 'Se continui così, *questo è il prezzo*.'), function(){
    const r = document.getElementById('gnRisp'); if (!r) return;
    r.innerHTML = '<div class="gn-prezzo"><div class="gn-pz-r"><small>In un anno</small><b>' + String(oreAnno).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' ore</b><span>cioè ' + giorniAnno + ' giorni interi</span></div>'
      + '<div class="gn-pz-r grande"><small>Da qui agli 80 anni</small><b>' + anni + (anni === 1 ? ' anno' : ' anni') + '</b><span>della tua vita, sul telefono</span></div>'
      + (vero ? '' : '<p class="gn-pz-nota">Calcolato con la tua stima di ' + gnOreTxt(ore) + ' al giorno.</p>') + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnVai(\'lettura\')">' + gnEsc(gnC('prezzo_btn', 'Leggimi il futuro')) + '</button></div>';
  });
} };

/* ---------- la lettura: deterministica, con i numeri veri ---------- */
function gnLettura(){
  const d = gnDati();
  const profili = (typeof OR_PROFILES !== 'undefined') ? OR_PROFILES : [];
  const prof = function(id){ return profili.filter(function(p){ return p.id === id; })[0] || { id: id, ico: '🔮', name: 'L’Equilibrista', pct: 50 }; };
  const no = d.anno === 'No' || d.anno === 'Probabilmente no';
  const conti = d.conti || [];
  const ha = function(s){ return conti.some(function(c){ return c.indexOf(s) >= 0; }); };
  let base;
  if (d.posto === 'Sì') base = 'sogn';
  else if (no && ha('Rimando')) base = 'proc';
  else if (no) base = 'inc';
  else if (ha('Dormo male')) base = 'nott';
  else if (ha('distraggo')) base = 'reat';
  else if (d.anno === 'Sì') base = 'disc';
  else base = 'equi';
  const ore = (+d.oreVere > 0) ? +d.oreVere : (+d.oreN > 0) ? +d.oreN : ({ 'Meno di 2': 1.5, 'Da 2 a 4': 3, 'Da 4 a 6': 5, 'Più di quante voglio ammettere': 7 }[(d.ore || '').replace(/^[^ ]+ /, '')] || 3);
  let pct = { 'Sì': 55, 'Probabilmente': 45, 'Non lo so': 38, 'Probabilmente no': 32, 'No': 26 }[d.anno] || 40;
  pct -= Math.round((ore - 1.5) * 2);
  if (ha('Rimando')) pct -= 4;
  pct = Math.max(12, pct);
  const pctRotta = Math.min(85, pct + 38);
  let mesi = { studio: 12, corpo: 6, lavoro: 18, arte: 9, carriera: 24, presenza: 6 }[d.target] || 12;
  if (no) mesi += 3; if (d.anno === 'Sì') mesi -= 2;
  const arr = new Date(); arr.setMonth(arr.getMonth() + Math.max(1, mesi));
  const MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  const T = (typeof OR_TARGETS !== 'undefined') ? OR_TARGETS.filter(function(t){ return t.id === d.target; })[0] : null;
  /* il sogno con le sue parole: chi ha scritto, il suo testo; chi ha scelto «diventare», la
     carta del Genio; gli altri, la voce scelta senza l'emoji */
  let sogno = 'quel sogno';
  if (d.sognoK === 'scrivo' && d.sognoTesto) sogno = d.sognoTesto;
  else if (d.sognoK === 'meglio' && T) sogno = T.name.replace(/^Chi /, 'diventare chi ');
  else if (d.sogno) sogno = d.sogno.replace(/^[^ ]+ /, '').replace(/^./, function(c){ return c.toLowerCase(); });
  /* LA MODALITÀ. Se la data che vuole è prima dell'arrivo stimato, deve correre: difficile,
     cinque passi al giorno. Se ha respiro, normale (tre). Chi non ha una data gioca normale;
     chi ha molto più tempo del necessario può giocare facile (uno). */
  let modalita = 'normale';
  const sc = +d.scadenza || 0;
  if (sc && sc < mesi) modalita = 'difficile';
  else if (sc && sc > mesi * 2) modalita = 'facile';
  try{ localStorage.setItem('fl_modalita', modalita); }catch(_){ }
  /* 0.9.264, Andrea: il sogno scritto a mano e' una frase lunga, e il Genio la ripeteva intera in mezzo alle sue
     frasi. Nelle frasi del Genio va il nome breve; il testo intero resta dov'e' (Dream, Orizzonti). */
  const sognoBreve = (sogno.length > 42 || sogno === 'quel sogno') ? 'il tuo sogno' : sogno;
  return { prof: prof(base), pct: pct, pctRotta: pctRotta, ore: ore, arrivo: MESI[arr.getMonth()] + ' ' + arr.getFullYear(), sogno: sogno, sognoBreve: sognoBreve, modalita: modalita, mesi: mesi };
}
/* le risposte cambiano l'app: la lettura del Genio (mappa, previsione), il traguardo «un
   giorno» negli Orizzonti, i nomi del tabellone */
function gnApplica(){
  const d = gnDati(), L = gnLettura();
  d.profile = L.prof.id; d.pct = L.pct; d.at = d.at || Date.now(); gnSalva();
  try{
    if (!localStorage.getItem('fl_oracle')){
      localStorage.setItem('fl_oracle', JSON.stringify({ target: d.target || 'lavoro', profile: L.prof.id, pct: L.pct, conf: 70, at: Date.now(), answers: { intro: 1 }, why: [], prove: 0, intro: true }));
    }
  }catch(_){ }
  try{
    if (typeof ozAnello === 'function' && typeof ozSalvaAnello === 'function' && !ozAnello('ungiorno').testo && L.sogno !== 'quel sogno'){
      ozSalvaAnello('ungiorno', { testo: L.sogno.replace(/^chi /, 'Diventare chi '), passi: [] });
    }
  }catch(_){ }
}

/* LA TRAIETTORIA. Il Genio con la luce intorno, e sotto le cose che sta guardando, una per
   volta, ognuna con la sua spunta. Riusata dal finale della lettura a episodi (domande.js). */
function gnTraiettoria(righe, poi){
  gnPosa('pensa');
  const img = document.getElementById('gnGenio'); if (img){ img.classList.add('pensa'); img.classList.add('luce'); }
  gnScrivi('Sto guardando la tua traiettoria…', null);
  const r = document.getElementById('gnRisp');
  if (r) r.innerHTML = '<ul class="gn-tra">' + righe.map(function(x){ return '<li><i></i><span>' + gnEsc(x) + '</span></li>'; }).join('') + '</ul>';
  const passo = 900, tot = passo * righe.length + 900;
  righe.forEach(function(_, i){
    setTimeout(function(){ const li = r ? r.querySelectorAll('.gn-tra li')[i] : null; if (li){ li.classList.add('on'); try{ gnAu.tick(); gnVibra(10); }catch(_){ } } }, 500 + passo * i);
  });
  try{ gnAu.crescendo(tot, function(){ if (img){ img.classList.remove('pensa'); img.classList.remove('luce'); } if (poi) poi(); }); }
  catch(_){ setTimeout(function(){ if (img){ img.classList.remove('pensa'); img.classList.remove('luce'); } if (poi) poi(); }, tot); }
}

/* ---------- ingresso e uscita ---------- */
function gnFine(){
  gnAu.musicaOff();
  GN.on = false;
  if (GN.rivedi){
    GN.rivedi = false; gnRivediRipristina(); skipAll();
    try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
    /* 0.9.329, Andrea: "dopo la intro deve esserci il tour di Sogno e Mappa, tassativo: da' il contesto di come funziona l'app" */
    try{ gnAu.musicaOff(); }catch(_){ }
    setTimeout(function(){ try{ if (typeof gtStart === 'function'){ GT.rivedi = true; gtStart(); } }catch(_){ } }, 700);
    return;
  }
  /* Dopo un Game Over il film rifa' solo la lettura: i permessi sono gia' concessi e il
     rapporto del tempo l'utente lo conosce. Si torna dritti a casa, con la rotta nuova. */
  let riparti = false;
  try{ riparti = localStorage.getItem('fl_gn_riparti') === '1'; if (riparti) localStorage.removeItem('fl_gn_riparti'); }catch(_){ }
  if (riparti){
    skipAll();
    try{ if (typeof switchTab === 'function') switchTab('sveglia'); }catch(_){ }
    return;
  }
  /* PRIMA LA STIMA, POI IL TEMPO VERO (0.9.280): l'ultima domanda del film e' quante ore finiscono sul
     telefono; subito dopo la pagina del permesso, e il rapporto le mette a confronto */
  /* il film consegna al rapporto del tempo (s6): e' la prova, con i numeri del telefono, di
     quello che il Genio ha appena detto */
  /* 0.9.284: il tempo vero e il prezzo li ha gia' visti nel film, subito dopo la stima: niente doppione */
  if (GN.veritaFatta || +gnDati().oreVere > 0){ if (typeof gnPonte === 'function') gnPonte(); else skipAll(); return; }
  const i = (typeof order !== 'undefined') ? order.indexOf('s6') : -1;
  if (i >= 0) go(i); else skipAll();
}
/* 0.9.293, Andrea: "perche' chiediamo due volte quante ore passa sul telefono, e il rapporto esce due volte con due numeri
   diversi?". Il Genio consegna a "Cosa ti ruba piu' tempo" (s4), e l'Indietro di s4 andava a s6 (il vecchio permesso,
   che rifaceva il rapporto con un altro conto) e da li' a s3 (la vecchia domanda sulle ore). Se il Genio ha gia' mostrato
   il tempo vero, Indietro da s4 torna al Genio. */
function gnTempoVisto(){ try{ return !!(GN.veritaFatta || +gnDati().oreVere > 0 || +gnDati().oreN > 0); }catch(_){ return false; }
}
if (typeof BACK_TO !== 'undefined'){
  BACK_TO.s4 = function(){ if (gnTempoVisto()){ gnPonte(); return null; } return 's6'; };
  BACK_TO.s6 = function(){ if (gnTempoVisto()){ gnPonte(); return null; } return 's3'; };
  BACK_TO.s3 = function(){ if (gnTempoVisto()){ gnPonte(); return null; } return 's2'; };
}
/* IL PONTE. Dopo il rapporto del tempo (s6) — che ora mostra un numero alla volta — il Genio
   torna per una frase sola: e' qui, e non prima, che il blocco ha senso. Chi ha appena visto
   gli anni di vita che finiscono nel telefono capisce da solo cosa c'e' da proteggere. */
function gnPonte(){
  GN.on = true;
  goId('s-genio');
  gnVai('ponte');
}
GN_PASSI.ponte = { entra: function(){
  const d = gnDati(), L = gnLettura();
  const lib = d.liberta ? gnC('ponte_liberta', 'Volevi tempo e libertà. ') : '';
  gnPosa('pensa');
  gnScrivi(gnC('ponte', '{liberta}Il futuro è scritto nelle abitudini, e l\u2019hai appena visto. Da adesso proteggiamo *{sogno}* dai ladri di tempo.', { liberta: lib, sogno: (L.sognoBreve || L.sogno) }), function(){
    const r = document.getElementById('gnRisp');
    if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();gnAu.musicaOff();GN.on=false;go(4)">' + gnEsc(gnC('ponte_btn', 'Proteggiamolo')) + '</button></div>';
  });
} };

/* IL TUTORIAL DELLA PARTITA, alla Clash Royale: il Re non spiega, ti fa giocare. Qui il
   Genio sta accanto al tabellone VERO e ti fa segnare il primo punto con il dito. */
function gnTutorial(){
  /* IL TOUR SULLA CASA VERA (genio-tour.js): niente scena a parte, niente pulsante da tenere
     premuto. Il Genio porta l'utente su Roadmap e START, gli fa PRENOTARE il primo punto nel
     foglio vero, gli mostra il tabellone e il Blocco, poi i permessi. */
  gnAu.musicaOff(); GN.on = false;
  if (typeof gtStart === 'function'){ gtStart(); return; }
  gnPermessi();
}
function gnTabHtml(v, n){
  const nm = gnNomi();
  return '<div class="gn-tab" id="gnTab"><div><small>' + gnEsc(nm.vecchio) + '</small><b class="rosso" id="gnTabV">' + v + '</b></div><span>–</span><div><small>' + gnEsc(nm.nuovo) + '</small><b class="blu" id="gnTabN">' + n + '</b></div></div>';
}
function gnTabSegna(chi){
  const el = document.getElementById(chi === 'v' ? 'gnTabV' : 'gnTabN'); if (!el) return;
  el.textContent = String((parseInt(el.textContent, 10) || 0) + 1);
  el.classList.add('segna'); setTimeout(function(){ el.classList.remove('segna'); }, 700);
}
GN_PASSI.tut1 = { entra: function(){
  gnPosa('saluta');
  gnScrivi('Questo è il tabellone. Da oggi lo vedi ogni giorno sulla scheda START, e ogni sera lo guardo *anch\u2019io*.', function(){
    const r = document.getElementById('gnRisp'); if (r) r.innerHTML = gnTabHtml(0, 0);
    const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false;
  });
}, tocco: function(){ gnVai('tut2'); } };
GN_PASSI.tut2 = { entra: function(){
  const nm = gnNomi();
  gnPosa('triste'); gnAu.triste();
  gnScrivi('Quando apri un\u2019app che ti ruba il tempo, segna il telefono: *punto ' + gnA2(nm.vecchio) + '*.', function(){
    const r = document.getElementById('gnRisp'); if (r) r.innerHTML = gnTabHtml(0, 0);
    setTimeout(function(){ gnTabSegna('v'); gnVibra(40); }, 500);
    const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false;
  });
}, tocco: function(){ gnVai('tut3'); } };
GN_PASSI.tut3 = { entra: function(){
  const nm = gnNomi();
  gnPosa('rivela');
  gnScrivi('Quando resisti, o finisci una sessione di focus, segni tu: *punto ' + gnA2(nm.nuovo) + '*.', function(){
    const r = document.getElementById('gnRisp'); if (r) r.innerHTML = gnTabHtml(1, 0);
    setTimeout(function(){ gnTabSegna('n'); gnAu.punto(); gnVibra([20, 40, 20]); }, 500);
    const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false;
  });
}, tocco: function(){ gnVai('tut4'); } };
GN_PASSI.tut4 = { entra: function(){
  gnPosa('rivela');
  gnScrivi('Prova adesso. Tieni premuto tre secondi e *segna il tuo primo punto vero*.', function(){
    const r = document.getElementById('gnRisp');
    if (r) r.innerHTML = gnTabHtml(1, 1) + '<div class="gn-hold" id="gnHold"><span>tieni<br>premuto</span></div>';
    gnHoldSetup();
  });
} };
function gnHoldSetup(){
  const h = document.getElementById('gnHold'); if (!h) return;
  let t0 = 0, raf = 0, fatto = false;
  const disegna = function(){
    if (!t0) return;
    const p = Math.min(1, (performance.now() - t0) / 3000);
    h.style.setProperty('--p', Math.round(p * 100) + '%');
    if (p >= 1){ fatto = true; t0 = 0; gnHoldFatto(h); return; }
    raf = requestAnimationFrame(disegna);
  };
  const giu = function(e){ if (fatto) return; e.preventDefault(); e.stopPropagation(); t0 = performance.now(); gnVibra(12); raf = requestAnimationFrame(disegna); };
  const su = function(){ if (fatto) return; t0 = 0; cancelAnimationFrame(raf); h.style.setProperty('--p', '0%'); };
  h.addEventListener('pointerdown', giu); h.addEventListener('pointerup', su);
  h.addEventListener('pointercancel', su); h.addEventListener('pointerleave', su);
  h.addEventListener('click', function(e){ e.stopPropagation(); });
}
function gnHoldFatto(h){
  h.classList.add('done'); h.innerHTML = '<span>🔒</span>';
  gnVibra([30, 40, 80]); gnAu.punto(); gnTabSegna('n');
  /* UNA VOLTA SOLA. «Rivedi il primo avvio» rifaceva il tutorial e il tabellone prendeva un
     punto a ogni giro (tre volte il 19/09). Il tabellone e' l'unica cosa dell'app che deve
     poter essere creduta: un punto che si rigenera da solo lo smentisce. */
  try{
    const d = gnDati();
    if (!d.puntoDato && typeof mgFocusPoint === 'function' && mgFocusPoint('il primo punto: il patto del primo avvio', true)){
      d.puntoDato = Date.now(); gnSalva();
    }
  }catch(_){ }
  /* 0.9.260, Andrea: dopo "Ricomincia da capo" i permessi si richiedevano anche se erano gia' tutti dati. Prima si
     guarda: se ci sono gia', il Genio non li chiede e si parte. */
  gnPermessiDati().then(function(ok){
    GN.permessiOk = ok;
    gnScrivi(ok ? '*Uno a due.* Hai già capito come si gioca, e i permessi li avevi già dati. Si parte.'
                : '*Uno a due.* Hai già capito come si gioca. Ora l\u2019app ha bisogno di due permessi per fare la sua parte.', function(){
      const r = document.getElementById('gnRisp');
      const b = document.createElement('div'); b.className = 'or-grid one';
      b.innerHTML = '<button type="button" class="or-a main" onclick="event.stopPropagation();gnPermessi()">Andiamo</button>';
      if (r) r.appendChild(b);
    });
  });
}
/** true se i permessi della pagina s15 sono gia' tutti dati (accessibilita', utilizzo, notifiche, e la finestra sopra le app se serve). */
async function gnPermessiDati(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.isServiceEnabled) return false;
    const acc = await NATIVE.isServiceEnabled();
    const usage = await NATIVE.isUsageAccessGranted();
    const notif = NATIVE.isNotificationAccessGranted ? await NATIVE.isNotificationAccessGranted() : { granted: true };
    let ov = { granted: true };
    if (NATIVE.isOverlayGranted){ const o = await NATIVE.isOverlayGranted(); ov = { granted: o.required === false || !!o.granted }; }
    return !!(acc && acc.enabled && usage && usage.granted && notif && notif.granted && ov.granted);
  }catch(_){ return false; }
}
async function gnPermessi(){
  gnAu.musicaOff(); GN.on = false;
  if (GN.permessiOk || await gnPermessiDati()){ GN.dopoPermessi = false; skipAll(); return; }
  let desktop = false; try{ desktop = !!(window.Capacitor && Capacitor.getPlatform && Capacitor.getPlatform() === 'desktop'); }catch(_){ }
  if (document.getElementById('s15') && !desktop){ GN.dopoPermessi = true; goId('s15'); } else skipAll();
}
/* Da s15 (permessi) si usciva sul vecchio riepilogo del blocco (s16): chi viene dal film
   va in casa. Il nome e' quello che le uscite di s15 chiamano gia'. */
function inDopoPermessi(){
  if (GN.dopoPermessi){ GN.dopoPermessi = false; skipAll(); return true; }
  return false;
}

function gnParte(){
  /* 0.9.300: i testi dell'episodio 1 arrivano da content/episodi.json: si aspetta il file (al massimo un secondo e mezzo) */
  if (typeof epiCarica === 'function' && typeof EPI !== 'undefined' && !EPI.cfg && !GN.attesoEpi){
    GN.attesoEpi = true; let via = false;
    const parti = function(){ if (via) return; via = true; gnParte(); };
    epiCarica().then(parti); setTimeout(parti, 1500);
    return;
  }
  GN.on = true; GN.storia = []; GN.tornando = false;
  /* LA MUSICA C'E' SEMPRE. Il tasto per spegnerla e' sparito in 0.9.174, ma la preferenza
     salvata da chi l'aveva toccato prima restava «spenta» per sempre, e il film partiva muto. */
  GN.audio = true; try{ localStorage.removeItem('fl_intro_audio'); }catch(_){ }
  goId('s-genio');
  gnVai('b1');
}
/* Rivedere il primo avvio senza disinstallare: si azzera solo il racconto. */
/* RIVEDERE E' RIVEDERE. Prima azzerava il segno «primo avvio fatto»: chi chiudeva l'app a
   meta' film la ritrovava all'inizio del racconto, e ci restava. Adesso il film si rifa'
   con le risposte di allora, e alla fine si torna a casa: niente rapporto, niente giro,
   niente permessi. */
/* RIVEDERE NON CAMBIA NIENTE (0.9.236, Andrea). Il papa' ha rifatto il primo avvio da "Rivedi il primo
   avvio" scrivendo il suo nome e il suo obiettivo: le risposte sono finite al posto di quelle di Andrea e
   la data d'arrivo e' saltata di due anni. Adesso durante il rivedere ogni scrittura in localStorage
   ricorda il valore di prima (fl_rivedi_orig, salvato a ogni chiave nuova, cosi' regge anche se l'app si
   chiude a meta'); alla fine, o al prossimo avvio, tutto torna com'era. */
const GN_RIV_KEY = 'fl_rivedi_orig';
const GN_RIV_FUORI = ['fl_tab', 'fl_backup_at', 'fl_intro_audio', GN_RIV_KEY];
let GN_RIV_SET = null, GN_RIV_DEL = null;
function gnRivediTraccia(){
  if (GN_RIV_SET) return;
  const S = Storage.prototype; GN_RIV_SET = S.setItem; GN_RIV_DEL = S.removeItem;
  const ricorda = function(st, k){
    if (st !== localStorage || !k || String(k).indexOf('fl_') !== 0 || GN_RIV_FUORI.indexOf(k) >= 0 || /^fl_(dp|notif|usage)/.test(k)) return;
    let o = {}; try{ o = JSON.parse(localStorage.getItem(GN_RIV_KEY) || '{}') || {}; }catch(_){ o = {}; }
    if (Object.prototype.hasOwnProperty.call(o, k)) return;
    o[k] = localStorage.getItem(k);
    try{ GN_RIV_SET.call(localStorage, GN_RIV_KEY, JSON.stringify(o)); }catch(_){ }
  };
  S.setItem = function(k, v){ ricorda(this, k); return GN_RIV_SET.call(this, k, v); };
  S.removeItem = function(k){ ricorda(this, k); return GN_RIV_DEL.call(this, k); };
}
function gnRivediEsci(){
  GN.rivedi = false; GN.on = false; GN.modo = '';
  try{ gnAu.musicaOff(); }catch(_){ }
  try{ if (typeof muSiglaOff === 'function') muSiglaOff(); }catch(_){ }
  gnRivediRipristina();
  const x = document.getElementById('gnRivX'); if (x) x.remove();
  try{ document.documentElement.classList.add('fl-home'); }catch(_){ }
  goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
}
function gnRivediRipristina(){
  try{ const x = document.getElementById('gnRivX'); if (x && !GN.rivedi) x.remove(); }catch(_){ }
  if (GN_RIV_SET){ Storage.prototype.setItem = GN_RIV_SET; Storage.prototype.removeItem = GN_RIV_DEL; GN_RIV_SET = null; GN_RIV_DEL = null; }
  let o = null; try{ o = JSON.parse(localStorage.getItem(GN_RIV_KEY) || 'null'); }catch(_){ o = null; }
  if (!o) return false;
  Object.keys(o).forEach(function(k){ try{ if (o[k] === null) localStorage.removeItem(k); else localStorage.setItem(k, o[k]); }catch(_){ } });
  try{ localStorage.removeItem(GN_RIV_KEY); }catch(_){ }
  GN.dati = null;
  try{ if (typeof ETA !== 'undefined'){ ETA.stato = null; } if (typeof etaRicalcola === 'function') etaRicalcola(null); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
  return true;
}
/* l'app si e' chiusa a meta' del rivedere: al prossimo avvio si rimette tutto com'era */
setTimeout(function(){ try{ if (!GN.rivedi) gnRivediRipristina(); }catch(_){ } }, 1500);
/* uscito dal rivedere in qualunque modo (la X, il tasto indietro, un'altra scheda): si rimette tutto */
setInterval(function(){
  try{
    if (!GN.rivedi) return;
    const fuori = !GN.on || (typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] !== 's-genio');
    if (fuori){ GN.rivedi = false; gnRivediRipristina(); }
  }catch(_){ }
}, 2000);
function gnRivedi(){
  try{ localStorage.removeItem(GN_RIV_KEY); }catch(_){ }
  gnRivediTraccia();
  GN.rivedi = true;
  try{ document.documentElement.classList.remove('fl-home'); }catch(_){ }
  gnParte();
  /* 0.9.335, Andrea: "se faccio ripartire per errore un episodio gia' completato, come La luce, non si puo' uscire" */
  setTimeout(function(){
    const sc = document.getElementById('gnScena'); if (!sc || document.getElementById('gnRivX')) return;
    const b = document.createElement('button'); b.type = 'button'; b.id = 'gnRivX'; b.className = 'gn-riv-x'; b.setAttribute('aria-label', 'Esci'); b.textContent = '✕';
    b.onclick = function(e){ e.stopPropagation(); gnRivediEsci(); };
    sc.appendChild(b);
  }, 200);
  /* il tocco su "Rivedi soltanto" basta per far partire il suono: la sigla non resta muta fino al tocco dopo */
  GN.audio = true;
  try{ gnAu.musicaOff(); gnAu.musica(); }catch(_){ }
}
/* tornando sul film dopo uno schermo spento o un cambio d'app, la musica riparte */
document.addEventListener('visibilitychange', function(){
  if (document.hidden || !GN.on || !GN.audio) return;
  try{ const cur = document.querySelector('.screen.active'); if (cur && cur.id === 's-genio') gnAu.musica(); }catch(_){ }
});

(function gnStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.gn-riv-x{position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:14px;z-index:60;width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font:700 17px var(--font-body);cursor:pointer}',
    /* IL CIELO STELLATO CON LA FORESTA, come nel prototipo: e' la notte in cui si legge il
       futuro. La nuvoletta resta bianca con il bordo scuro, i pulsanti restano gialli. */
    /* LO SFONDO E' A STRATI: la foto sotto (::before), il velo sopra (::after), la scena
       davanti. Cosi' sotto alle domande la foto si sfoca e si scurisce da sola, con una
       transizione, e la nuvoletta resta l'unica cosa a fuoco. */
    '#s-genio{padding:0;overflow:hidden;background:#00132B}',
    '#s-genio::before{content:"";position:absolute;inset:-14px;background:#00132B url("img/bg/montagne.jpg") center bottom/cover no-repeat;transition:filter .7s ease,transform .7s ease;pointer-events:none}',
    '#s-genio::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,19,43,.18) 0%,rgba(0,19,43,.5) 55%,rgba(0,19,43,.82) 100%);pointer-events:none;transition:opacity .7s}',
    '#s-genio.domanda::before{filter:blur(7px) brightness(.55);transform:scale(1.05)}',
    /* il navigatore: bianco, con il solo aereo. Niente foresta. */
    '#s-genio.volo{background:#fff}#s-genio.volo::before,#s-genio.volo::after{display:none}',
    '.gn.volo .gn-tap{color:#6A7B99 !important}.gn.volo .gn-link{color:#5B6B85 !important}',
    /* sul bianco del navigatore i pannelli restano chiari anche con il tema scuro */
    'body.dark .gn.volo .gn-box{background:#fff;border-color:#0E2350;box-shadow:0 8px 24px rgba(14,35,80,.12)}',
    'body.dark .gn.volo .gn-box p{color:#0E2350}body.dark .gn.volo .gn-box p b{color:#0075E3}body.dark .gn.volo .gn-freccia{color:#0075E3}',
    'body.dark .gn.volo .gn-nav{background:#fff;border-color:#0E2350}',
    'body.dark .gn.volo .gn-navrow{background:#F4F8FF;border-color:#C9D6EA;color:#0E2350}body.dark .gn.volo .gn-navrow span{color:#6A7B99}body.dark .gn.volo .gn-navrow span.on{color:#0E2350}',
    /* la prima schermata: il Genio grande, il testo bianco sul cielo, nessuna nuvoletta */
    '.gn.apertura .gn-sopra{height:50vh;min-height:260px}',
    '.gn.apertura .gn-genio{max-width:92%}',
    '.gn.apertura .gn-box{background:transparent !important;border:0 !important;box-shadow:none !important;padding:10px 8px;min-height:0}',
    '.gn.apertura .gn-box p{color:#fff !important;font:800 24px/1.3 var(--font-display);text-align:center;text-shadow:0 2px 14px rgba(0,0,0,.55)}',
    '.gn.apertura .gn-box p b{color:#8CC6FF !important}',
    '.gn.apertura .gn-freccia{display:none}',
    '.gn.apertura .gn-box,.gn.apertura .gn-box p{transition:none !important}',
    '.gn-sale{animation:gnSale .9s ease-out both}',
    /* lo slider delle ore al centro: il Genio si fa piccolo, la nuvoletta si stringe */
    '.gn.ore-centro .gn-sopra,.gn.molte.ore-centro .gn-sopra{height:14vh !important;min-height:88px !important}',
    '.gn.ore-centro .gn-box{padding:12px 30px 12px 16px;min-height:0;transition:padding .4s}',
    '.gn.ore-centro .gn-box p,.gn.domanda.ore-centro .gn-box p{font:600 15px/1.45 var(--font-body);min-height:0;text-align:left;transition:font-size .4s}',
    '.gn.ore-centro .gn-risp{justify-content:flex-end}',
    '.gn.ore-centro .gn-slider{margin:auto 0;padding:22px 18px}',
    '.gn.ore-centro .gn-slider b{font-size:56px}',
    '@keyframes gnSale{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:none}}',
    /* le domande: la nuvoletta si allarga e il testo cresce, come nella lettura dalla sfera */
    '.gn.domanda .gn-box{padding:22px 30px 22px 22px;border-radius:22px}',
    '.gn.domanda .gn-box p{font:800 21px/1.35 var(--font-display);text-align:center}',
    /* quattro risposte: due e due, mai tre e una */
    '.gn-risp .or-grid.quattro{grid-template-columns:1fr 1fr}.gn-risp .or-grid.quattro .or-a{grid-column:auto}',
    '.gn-prob.uno{justify-content:center}.gn-prob.uno b{font-size:54px}',
    '.gn{z-index:1}',
    '.gn-tap{color:#BFE0FF !important}',
    '.gn-mute{background:rgba(255,255,255,.16) !important;color:#fff !important}',
    '.gn-link{color:#BFE0FF !important}',
    '.gn-genio{filter:drop-shadow(0 12px 22px rgba(0,0,0,.45))}',
    '.gn-genio.luce{animation:gnLuce 1.3s ease-in-out infinite !important}',
    '@keyframes gnLuce{0%,100%{filter:drop-shadow(0 0 18px rgba(63,159,244,.45))}50%{filter:drop-shadow(0 0 46px rgba(140,198,255,.95))}}',
    /* il pannello bianco con le carte in due colonne, e la luce che gira dietro al Genio */
    '.gn-carta{background:#F6F8FC;border-radius:22px;padding:14px;color:#0E2350}',
    'body.dark .gn-carta{background:#141C2C;color:#EEF4FF}',
    '.gn-cards{display:grid;grid-template-columns:1fr 1fr;gap:10px}.gn-cards.due{grid-template-columns:1fr 1fr}.gn-cards.dispari .gn-card:first-child{grid-column:1 / -1;flex-direction:row;justify-content:center;gap:12px;padding-top:14px;padding-bottom:14px}.gn-cards.dispari .gn-card:first-child span{font-size:28px}',
    '.gn-card{border:1.5px solid #DCE8F5;background:#fff;border-radius:16px;padding:14px 10px;text-align:center;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:6px;color:#0E2350;transition:transform .2s,border-color .2s}',
    'body.dark .gn-card{background:#0B1220;border-color:#25314A;color:#EEF4FF}',
    '.gn-sogno-chip{margin:0 auto 12px;max-width:92%;padding:10px 14px;border-radius:14px;background:#E3F1FF;color:#0E2350;font:700 14px/1.35 var(--font-body);text-align:center}',
    'body.dark .gn-sogno-chip{background:#12325A;color:#EEF4FF}',
    '.gn-card span{font-size:30px;line-height:1}.gn-card b{font:800 12.5px/1.25 var(--font-display);text-transform:uppercase;letter-spacing:.02em}.gn-card small{font:500 11px/1.35 var(--font-body);color:#6A7B99}',
    '.gn-profilo{background:#fff;border:2px solid #0E2350;border-radius:22px;padding:22px 18px;text-align:center;color:#0E2350;animation:gnIn .4s ease-out both}',
    'body.dark .gn-profilo{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.gn-profilo span{display:block;font-size:46px;line-height:1}.gn-profilo b{display:block;margin-top:10px;font:900 24px/1.15 var(--font-display)}.gn-profilo p{margin:10px 0 0;font:500 14px/1.55 var(--font-body)}',
    '.gn-prob{display:flex;align-items:center;justify-content:center;gap:14px;background:#fff;border:2px solid #0E2350;border-radius:22px;padding:22px 14px;color:#0E2350;animation:gnIn .4s ease-out both}',
    'body.dark .gn-prob{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.gn-prob div{text-align:center}.gn-prob small{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#6A7B99}.gn-prob b{display:block;margin-top:4px;font:900 44px/1 var(--font-display)}.gn-prob i{font-style:normal;font-size:26px;color:#8B99AC}',
    '.gn-prob .rosso{color:#E5515F}.gn-prob .verde{color:#1B9E6A}',
    '.gn-card.on{border-color:#0075E3;background:#F0FBFF;transform:scale(1.03)}body.dark .gn-card.on{background:#14305E}',
    '.gn-card.tratt{border-style:dashed;grid-column:1 / -1}',
    '.gn-cards.due .gn-card{padding:20px 10px}.gn-cards.due .gn-card span{font-size:34px}',
    '.gn-slider{text-align:center}',
    '.gn-slider b{display:block;font:900 44px/1 var(--font-display);color:#0E2350;margin:6px 0 14px}body.dark .gn-slider b{color:#fff}',
    '.gn-slider input[type=range]{width:100%;margin:0;accent-color:#0075E3;height:36px}',
    '.gn-ends{display:flex;justify-content:space-between;margin-top:4px;font:600 11px var(--font-body);color:#6A7B99}',
    '.gn-tra{list-style:none;margin:0 0 auto;padding:6px 4px 0;display:flex;flex-direction:column;gap:10px;align-self:stretch}',
    '.gn-tra li{display:flex;align-items:center;gap:10px;opacity:.3;transform:translateX(-6px);transition:opacity .4s,transform .4s;font:600 14px var(--font-body);color:#fff}',
    '.gn-tra li.on{opacity:1;transform:none}',
    '.gn-tra li i{width:22px;height:22px;flex:none;border-radius:50%;border:2px solid rgba(255,255,255,.5);display:flex;align-items:center;justify-content:center}',
    '.gn-tra li.on i{border-color:#8CF0C8;background:#1B9E6A}.gn-tra li.on i::after{content:"✓";color:#fff;font:800 12px var(--font-body)}',
    '.gn{position:absolute;inset:0;display:flex;flex-direction:column;padding:16px 18px calc(18px + env(safe-area-inset-bottom));overflow:auto;-webkit-tap-highlight-color:transparent}',
    '.gn-mute{position:absolute;top:14px;right:14px;z-index:5;width:34px;height:34px;border-radius:50%;border:0;background:rgba(14,35,80,.12);color:#0E2350;font-size:15px;cursor:pointer;padding:0}',
    'body.dark .gn-mute{background:rgba(255,255,255,.12);color:#fff}',
    '.gn-sopra{flex:0 0 auto;height:38vh;min-height:190px;display:flex;align-items:flex-end;justify-content:center;padding-top:22px;transition:height .6s ease}',
    '.gn.molte .gn-sopra{height:22vh;min-height:120px}',
    /* 0.9.319, Andrea: "non puoi a volte metterli in pila e a volte in due colonne". Con il Genio le scelte stanno sempre in due colonne; se sono dispari, il pulsante principale (o il primo) prende tutta la riga */
    '.gn-risp .or-grid.one:has(> .or-a:nth-child(2)){grid-template-columns:1fr 1fr}.gn-risp .or-grid.one:has(> .or-a:nth-child(3)):not(:has(> .or-a:nth-child(4))) > .or-a:first-child{grid-column:1/-1}',
    '.gn-risp .or-grid.tre{grid-template-columns:1fr 1fr 1fr}.gn-risp .or-grid.tre .or-a{grid-column:auto}',
    '.gn-genio{height:100%;width:auto;max-width:78%;object-fit:contain;filter:drop-shadow(0 12px 22px rgba(14,35,80,.25));transition:opacity .16s,transform .16s}',
    '.gn-genio.cambia{opacity:0;transform:translateY(6px)}',
    '.gn-genio.pensa{animation:gnPensa 1.1s ease-in-out infinite}',
    /* 0.9.260, Andrea: niente piu' movimento continuo (il dondolio faceva venire il mal di mare e toglieva
       l'attenzione dalla domanda). Resta solo una mossa breve quando cambia la posa, e poi il Genio sta fermo. */
    '.gn-genio{transform-origin:50% 100%}',
    '.gn-genio.posa-saluta{animation:gnSaluta 1s cubic-bezier(.3,1.4,.4,1) 1}',
    '.gn-genio.posa-pensa{animation:gnPensaUna .8s ease-in-out 1}',
    '.gn-genio.posa-rivela{animation:gnRivela .6s cubic-bezier(.2,1.6,.4,1) 1}',
    '.gn-genio.posa-triste{animation:gnTriste .9s ease-in-out 1}',
    '@keyframes gnSaluta{0%{transform:rotate(0)}30%{transform:rotate(-4deg) translateY(-4px)}65%{transform:rotate(3deg) translateY(-2px)}100%{transform:rotate(0)}}',
    '@keyframes gnPensaUna{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}',
    '@keyframes gnRivela{0%{transform:scale(.9) translateY(6px)}60%{transform:scale(1.06) translateY(-6px)}100%{transform:scale(1) translateY(0)}}',
    '@keyframes gnTriste{0%,100%{transform:translateY(0)}50%{transform:translateY(4px) scale(.99)}}',
    '@keyframes gnPensa{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}',
    /* il riquadro dei Pokémon: carta chiara, bordo scuro, inchiostro FISSO */
    '.gn-box{position:relative;flex:0 0 auto;margin-top:14px;min-height:104px;border:2px solid #0E2350;border-radius:18px;background:#fff;padding:16px 34px 16px 18px;box-shadow:0 8px 24px rgba(14,35,80,.12)}',
    'body.dark .gn-box{background:#141C2C;border-color:#4FA8FF;box-shadow:none}',
    '.gn-box p{margin:0;font:600 16px/1.55 var(--font-body);color:#0E2350;min-height:50px}',
    'body.dark .gn-box p{color:#EEF4FF}',
    '.gn-box p b{font-weight:800;color:#0075E3}',
    'body.dark .gn-box p b{color:#8CC6FF}',
    '.gn-freccia{position:absolute;right:14px;bottom:10px;font-size:12px;color:#0075E3;animation:gnFreccia 1s ease-in-out infinite}',
    'body.dark .gn-freccia{color:#8CC6FF}',
    '@keyframes gnFreccia{0%,100%{transform:translateY(0);opacity:.5}50%{transform:translateY(3px);opacity:1}}',
    /* in fondo allo schermo, come in Detox: non appeso alla vignetta */
    '.gn-tap{position:absolute;left:0;right:0;bottom:calc(22px + env(safe-area-inset-bottom));text-align:center;font:700 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#6A7B99;animation:gnTap 1.8s ease-in-out infinite;pointer-events:none}',
    '.gn-risp .or-a{color:#0E2350}.gn-risp .or-a.main{color:#fff}',
    'body.dark .gn-tap{color:#8FA6C8}',
    '@keyframes gnTap{0%,100%{opacity:.45}50%{opacity:1}}',
    '.gn-risp{flex:1;display:flex;flex-direction:column;justify-content:flex-end;padding-top:12px;animation:gnIn .35s ease-out both}',
    '@keyframes gnIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}',
    '.gn-risp .or-grid{margin-top:8px}',
    '.gn-risp .or-targets{margin-top:0}',
    '.gn-risp .or-t{padding:10px 8px}.gn-risp .or-t span{font-size:26px}.gn-risp .or-t b{font-size:12.5px}.gn-risp .or-t small{font-size:10.5px}',
    '.gn-campo{width:100%;border:2px solid #C9D6EA;border-radius:14px;background:#fff;color:#0E2350;padding:14px;font:600 16px var(--font-body);text-align:center;outline:0}',
    'body.dark .gn-campo{background:#141C2C;border-color:#25314A;color:#EEF4FF}',
    '.gn-link{display:block;margin:10px auto 0;border:0;background:none;color:#5B6B85;font:700 12.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    'body.dark .gn-link{color:#9FB6CF}',
    '.gn-multi{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:18px 0 22px}',
    '.gn-scrivo-link{margin-top:16px;font-size:14.5px}',
    '.gn-opt{border:1.5px solid #C9D6EA;background:#fff;color:#0E2350;border-radius:99px;padding:11px 14px;font:600 13.5px var(--font-body);cursor:pointer}',
    'body.dark .gn-opt{background:#141C2C;border-color:#25314A;color:#EEF4FF}',
    '.gn-opt.on{background:#0E2350;border-color:#0E2350;color:#fff}',
    'body.dark .gn-opt.on{background:#4FA8FF;border-color:#4FA8FF;color:#061634}',
    /* il verdetto */
    '.gn-verdetto{display:flex;flex-direction:column;gap:8px}',
    /* 0.9.284: il tempo vero e il prezzo, una carta ciascuno */
    '.gn-ver,.gn-prezzo{background:#F4F8FD;color:#0E2350;border-radius:24px;padding:22px 20px 18px;text-align:center;box-shadow:0 14px 34px rgba(0,0,0,.28)}',
    '.gn-ver > small,.gn-pz-r small{display:block;font:800 11.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#5B7091}',
    '.gn-ver-n{display:block;margin:6px 0 2px;font:900 52px/1 var(--font-display);color:#0E2350}',
    '.gn-ver > span{display:block;font:600 14px var(--font-body);color:#5B7091}',
    '.gn-ver-barre{display:flex;align-items:flex-end;gap:8px;height:84px;margin:18px 6px 6px}',
    '.gn-ver-barre > div{flex:1;height:100%;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:4px}',
    '.gn-ver-barre i{display:block;width:100%;border-radius:6px 6px 3px 3px;background:linear-gradient(180deg,#FF8AC2,#5BC0F8)}',
    '.gn-ver-barre small{font:700 11px var(--font-body);color:#7B8DA8}',
    '.gn-ver-cfr{display:flex;justify-content:space-between;align-items:center;margin:14px 0 0;padding-top:12px;border-top:1px solid #DCE6F3;font:600 14px var(--font-body);color:#5B7091}.gn-ver-cfr b{color:#0E2350;font-size:16px}',
    '.gn-prezzo{display:flex;flex-direction:column;gap:14px}',
    '.gn-pz-r b{display:block;margin:4px 0 2px;font:900 30px/1.05 var(--font-display);color:#0E2350}.gn-pz-r span{display:block;font:600 14px var(--font-body);color:#5B7091}',
    '.gn-pz-r.grande{padding-top:14px;border-top:1px solid #DCE6F3}.gn-pz-r.grande b{font-size:48px;color:#E5484D}',
    '.gn-pz-nota{margin:0;font:500 12.5px var(--font-body);color:#7B8DA8}',
    '.gn-riga{display:flex;gap:10px;align-items:flex-start;background:#fff;border:1.5px solid #C9D6EA;border-radius:14px;padding:11px 12px;font:500 13.5px/1.5 var(--font-body);color:#0E2350}',
    'body.dark .gn-riga{background:#141C2C;border-color:#25314A;color:#EEF4FF}',
    '.gn-riga i{font-style:normal;font-size:18px;flex:none}',
    '.gn-riga b{font-weight:800}.gn-riga .rosso{color:#E5515F}.gn-riga .verde{color:#1B9E6A}',
    'body.dark .gn-riga .verde{color:#8CF0C8}',
    /* il tabellone del patto */
    '.gn-tab{display:flex;align-items:center;justify-content:center;gap:18px;background:#fff;border:2px solid #0E2350;border-radius:18px;padding:12px 18px}',
    'body.dark .gn-tab{background:#141C2C;border-color:#4FA8FF}',
    '.gn-tab div{text-align:center}.gn-tab small{display:block;font:700 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#6A7B99}',
    '.gn-tab b{display:block;font:800 34px/1.1 var(--font-display);font-style:italic}.gn-tab .rosso{color:#E5515F}.gn-tab .blu{color:#0075E3}',
    'body.dark .gn-tab .blu{color:#4FA8FF}.gn-tab > span{font:800 24px var(--font-display);color:#6A7B99}',
    '.gn-area{width:100%;border:2px solid #C9D6EA;border-radius:14px;background:#fff;color:#0E2350;padding:12px 14px;font:600 15px/1.45 var(--font-body);outline:0;resize:none}',
    'body.dark .gn-area{background:#141C2C;border-color:#25314A;color:#EEF4FF}',
    '.gn-risp .or-grid.quattro .gn-q-scrivo{grid-column:1 / -1}.gn-q-riga{display:flex;gap:8px;align-items:stretch;margin-bottom:10px}.gn-q-riga .gn-q-num{flex:1;min-width:0;text-align:center;font-size:20px}.gn-q-riga .gn-q-u{flex:none;width:auto;padding:0 16px}',
    '.gn-tab b.segna{animation:gnSegna .6s ease}',
    '@keyframes gnSegna{0%{transform:scale(1)}40%{transform:scale(1.5)}100%{transform:scale(1)}}',
    '.gn-hold{width:132px;height:132px;margin:14px auto 0;border-radius:50%;position:relative;display:flex;align-items:center;justify-content:center;background:conic-gradient(#0075E3 var(--p,0%),#C9D6EA 0);cursor:pointer;-webkit-tap-highlight-color:transparent;user-select:none;touch-action:none}',
    'body.dark .gn-hold{background:conic-gradient(#8CF0C8 var(--p,0%),rgba(255,255,255,.12) 0)}',
    '.gn-hold::before{content:"";position:absolute;inset:8px;border-radius:50%;background:#fff}',
    'body.dark .gn-hold::before{background:#0B1A3F}',
    '.gn-hold span{position:relative;z-index:1;font:800 14px var(--font-body);color:#0E2350;text-align:center}',
    'body.dark .gn-hold span{color:#fff}',
    '.gn-hold.done{background:#2ECC71}.gn-hold.done::before{background:#1B9E6A}.gn-hold.done span{color:#fff;font-size:30px}',
    '.gn-auth{display:flex;flex-direction:column;gap:10px}',
    /* sul cielo scuro il blu notte spariva: il pulsante principale e' azzurro con il testo scuro */
    '.gn-authbtn{border:0;border-radius:99px;background:#3F9FF4;color:#001E44;padding:15px 18px;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 6px 18px rgba(63,159,244,.35)}',
    'body.dark .gn-authbtn{background:#4FA8FF;color:#061634}',
    '.gn-authbtn.sec{background:#fff;color:#0E2350;border:1.5px solid #C9D6EA}',
    'body.dark .gn-authbtn.sec{background:#141C2C;color:#EEF4FF;border-color:#25314A}',
    /* il navigatore: l'aereo compare solo qui */
    /* il banner dell'aereo, e il pannello che gli sporge sopra */
    '.gn.volo .gn-sopra{display:block;height:auto;min-height:0;padding:0;margin:-16px -18px 0}',
    '.gn-banner{height:34vh;min-height:170px;position:relative;overflow:hidden;border-radius:0 0 26px 26px}',
    '.gn-banner-img{position:absolute;inset:0;background:url("img/bg/take-flight.jpg") center 45%/cover no-repeat;transform:scale(1.04)}',
    '.gn-banner::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(4,10,28,.15),rgba(4,10,28,.55))}',
    '.gn.volo .gn-nav{position:relative;z-index:2;margin:-46px 18px 0;background:#fff;border:2px solid #0E2350;border-radius:18px;padding:10px;box-shadow:0 8px 24px rgba(14,35,80,.18)}',
    'body.dark .gn.volo .gn-nav{background:#141C2C;border-color:#4FA8FF}',
    '.gn-nav{display:flex;flex-direction:column;gap:8px}',
    '.gn-navrow{display:flex;align-items:center;gap:10px;width:100%;border:1.5px solid #C9D6EA;border-radius:14px;background:#F4F8FF;color:#0E2350;padding:14px;font:600 14px var(--font-body);cursor:pointer;text-align:left}',
    'body.dark .gn-navrow{background:#0B1220;border-color:#25314A;color:#EEF4FF}',
    '.gn-navrow i{font-style:normal}.gn-navrow span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#6A7B99}.gn-navrow span.on{color:#0E2350}',
    'body.dark .gn-navrow span.on{color:#fff}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function gnBoot(){
  registerScreen('s-genio', gnHtml(), { back: function(){ return ''; } });
  const sc = document.getElementById('gnScena');
  if (sc) sc.addEventListener('click', function(e){ if (e.target.closest('button,input,.gn-navrow')) return; gnTocco(); });
  /* il ritorno dalla ricerca della rotta riporta al pannello, pieno */
  if (typeof rtScegli === 'function'){
    const orig = rtScegli;
    rtScegli = function(dati){
      if (!GN.attesaDove) return orig(dati);
      GN.attesaDove = false;
      let p = null; try{ p = JSON.parse(decodeURIComponent(dati)); }catch(_){ }
      if (p && typeof rtSalva === 'function') rtSalva((typeof RT_QUALE !== 'undefined' && RT_QUALE === 'da') ? { da: p } : { a: p });
      goId('s-genio'); gnVai('dove');
    };
  }
  document.addEventListener('fl:screen', function(e){
    if (e.detail === 's-home' && GN.attesaDove){ GN.attesaDove = false; goId('s-genio'); gnVai('dove'); }
    if (e.detail === 's4'){
      /* i ladri di tempo hanno un nome: il sogno di chi legge */
      try{
        const sub = document.querySelector('#s4 .q-sub'); const L = gnLettura();
        if (sub && L.sogno !== 'quel sogno') sub.textContent = 'I ladri di tempo che stanno fra te e ' + (L.sognoBreve || L.sogno) + '. Segna tutto quello che ti riguarda.';
      }catch(_){ }
    }
  });
  if (typeof login === 'function'){
    const origLogin = login;
    login = function(n, m, p){ origLogin(n, m, p); if (GN.attesaAuth){ GN.attesaAuth = false; setTimeout(function(){ if (GN.step === 'salva') gnFine(); }, 600); } };
  }
  let fatto = false; try{ fatto = localStorage.getItem('fl_onboarded') === '1'; }catch(_){ }
  if (!fatto) document.addEventListener('DOMContentLoaded', function(){ setTimeout(gnParte, 120); });
})();
