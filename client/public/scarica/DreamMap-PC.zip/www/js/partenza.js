/* ===========================================================================================
   DA DOVE PARTI? (0.9.238)

   Andrea: "non posso essere allo 0% o al 5%: faccio e-commerce da anni, dovrei essere almeno al
   50-60%". Come su Duolingo chi sa gia' l'inglese non riparte dall'abc: un livello all'inizio del
   capitolo 1 fa il punto con tre domande (una per schermata) e propone la strada gia' fatta. Si
   sceglie se contarla (il percorso parte da li') o se partire da zero da oggi.
   - fl_partenza = { pct: 0..0.9, at, risposte }.
   - La percentuale del percorso (hdPercorso) diventa: partenza + (1 - partenza) x il cammino nell'app.
   - Il viaggio stimato dal Genio (eta.js etaViaggio: W) si accorcia della strada gia' fatta; e' una
     scelta, quindi la data riparte ("Rotta nuova").
   - Con Premium il tuo agente personale puo' ricalibrare la roadmap da quel punto.
   =========================================================================================== */
const PTZ = { i: 0, r: {}, slider: 0 };
function ptzLeggi(){ try{ const v = JSON.parse(localStorage.getItem('fl_partenza') || 'null'); return v && isFinite(v.pct) ? v : null; }catch(_){ return null; } }
function ptzPct(){ const v = ptzLeggi(); return v ? Math.max(0, Math.min(0.9, +v.pct || 0)) : 0; }
function ptzSogno(){ try{ const s = (typeof nvSogno === 'function') ? nvSogno() : ''; return s || 'il tuo sogno'; }catch(_){ return 'il tuo sogno'; } }
const PTZ_DOMANDE = [
  { k: 'tempo', q: function(){ return 'Da quanto tempo lavori a "' + ptzSogno() + '"?'; }, o: [['Non ho ancora cominciato', 0], ['Da meno di un anno', 15], ['Da uno a tre anni', 35], ['Da più di tre anni', 50]] },
  { k: 'base', q: function(){ return 'Per "' + ptzSogno() + '", cosa hai già costruito?'; }, o: [['Niente, parto adesso', 0], ['Le prime prove', 15], ['Risultati veri, ancora piccoli', 35], ['Una base solida: ora devo crescere', 55]] }
];
registerScreen('s-partenza',
  '<div class="topbar"><button class="iconbtn" onclick="ptzIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Da dove parti?</b></div>'
  + '<div id="ptzBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('mappa'); }catch(_){ } }, 0); return 's-home'; } });
function ptzApri(){ PTZ.i = 0; PTZ.r = {}; const v = ptzLeggi(); PTZ.slider = v ? Math.round(v.pct * 100) : 0; goId('s-partenza'); ptzPaint(); }
function ptzIndietro(){ if (PTZ.i > 0){ PTZ.i--; ptzPaint(); return; } if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('mappa'); }catch(_){ } } }
function ptzProposta(){
  /* 0.9.275, Andrea: niente percentuale da calcolare a mano ("un utente non ha voglia di prendere la
     calcolatrice"). La stima la fa il Genio dalle due risposte. */
  const a = (PTZ.r.tempo || 0), b = (PTZ.r.base || 0);
  return Math.max(0, Math.min(90, Math.round(0.5 * a + 0.5 * b)));
}
function ptzPaint(){
  const h = document.getElementById('ptzBody'); if (!h) return;
  const passi = '<div class="ptz-passi">' + [0, 1, 2, 4].map(function(i){ return '<i class="' + (i <= PTZ.i ? 'on' : '') + '"></i>'; }).join('') + '</div>';
  if (PTZ.i === 0){
    h.innerHTML = passi + '<div class="ptz-card"><img src="img/genio/genio-saluta.png" alt=""><b>Non tutti partono da zero</b>'
      + '<p>Se hai già fatto strada verso "' + ptzSogno() + '", la contiamo: il percorso parte da lì e la data d’arrivo si avvicina. Due domande, poi scegli tu.</p>'
      + '<button type="button" class="cta" onclick="PTZ.i=1;ptzPaint()">Cominciamo</button></div>';
    return;
  }
  if (PTZ.i === 1 || PTZ.i === 2){
    const d = PTZ_DOMANDE[PTZ.i - 1];
    h.innerHTML = passi + '<div class="ptz-card"><b>' + esc(d.q()) + '</b><div class="ptz-opz">'
      + d.o.map(function(o, j){ return '<button type="button" class="' + (PTZ.r[d.k] === o[1] ? 'on' : '') + '" onclick="ptzScegli(\'' + d.k + '\',' + o[1] + ')">' + esc(o[0]) + '</button>'; }).join('') + '</div></div>';
    return;
  }
  if (PTZ.i === 3) PTZ.i = 4;
  if (PTZ.i === 3){
    const v = PTZ.r.dove != null ? PTZ.r.dove : 0;
    h.innerHTML = passi + '<div class="ptz-card"><b>Rispetto al traguardo, dove sei oggi?</b>'
      + '<p>Pensa ai numeri del tuo sogno. Esempio: se il traguardo è 200.000 € al mese e oggi ne fai 40.000, sei circa al 20%. Se il sogno è un esame, conta i libri già fatti.</p>'
      + '<div class="ptz-val" id="ptzDove">' + v + '%</div>'
      + '<input type="range" class="ptz-range" min="0" max="90" step="5" value="' + v + '" oninput="PTZ.r.dove=+this.value;document.getElementById(\'ptzDove\').textContent=this.value+\'%\'">'
      + '<button type="button" class="cta" onclick="if(PTZ.r.dove==null)PTZ.r.dove=0;PTZ.slider=ptzProposta();PTZ.i=4;ptzPaint()">Avanti</button></div>';
    return;
  }
  const p = PTZ.slider;
  const premium = (function(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } })();
  h.innerHTML = passi + '<div class="ptz-card"><b>Da dove vuoi partire?</b>'
    + '<p>Dalle tue risposte, il Genio conta già fatta questa parte della strada:</p>'
    + '<div class="ptz-val">' + ptzProposta() + '%</div>'
    + '<button type="button" class="cta" onclick="ptzSalva(ptzProposta())">Parto da qui</button>'
    + '<button type="button" class="ptz-zero" onclick="ptzSalva(0)">Parto da zero, da oggi</button>'
    + (premium && typeof agNuovaConversazione === 'function' ? '<p class="ptz-nota">Dopo, il tuo agente personale può ricalibrare la roadmap da questo punto.</p>' : '')
    + '</div>';
}
function ptzScegli(k, v){ PTZ.r[k] = v; try{ flVibra(8); }catch(_){ } PTZ.i++; ptzPaint(); }
function ptzSalva(pct){
  const v = Math.max(0, Math.min(90, +pct || 0)) / 100;
  try{ localStorage.setItem('fl_partenza', JSON.stringify({ pct: v, at: Date.now(), risposte: PTZ.r })); }catch(_){ }
  try{ if (typeof etaRicalcola === 'function') etaRicalcola({ tipo: 'genio', testo: 'Punto di partenza: ' + Math.round(v * 100) + '% di strada già fatta' }); }catch(_){ }
  try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast(v > 0 ? 'Il tuo percorso parte dal ' + Math.round(v * 100) + '%' : 'Si parte da zero, da oggi');
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
  const premium = (function(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } })();
  if (premium && typeof agNuovaConversazione === 'function'){
    setTimeout(function(){ try{ agNuovaConversazione('Ho fatto il punto della situazione: per il mio sogno "' + ptzSogno() + '" la strada già fatta vale circa il ' + Math.round(v * 100) + '%. Ricalibra la mia roadmap partendo da qui: togli i passi da principiante che ho già superato e dammi quelli giusti per il punto in cui sono.'); }catch(_){ } }, 600);
  }
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#ptzBody{padding:8px 16px 0}.ptz-passi{display:flex;gap:6px;margin:4px 0 16px}.ptz-passi i{flex:1;height:5px;border-radius:99px;background:var(--line,#E5ECF6)}.ptz-passi i.on{background:#0075E3}',
    '.ptz-card{border-radius:22px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:20px 18px;text-align:center}',
    '.ptz-card img{width:110px;height:auto;margin:0 auto 6px;display:block}.ptz-card>b{display:block;font:800 20px/1.3 var(--font-display,var(--font-body));color:var(--navy,#14234A);margin-bottom:10px}',
    '.ptz-card p{font:500 14.5px/1.55 var(--font-body);color:var(--muted,#5B6B86);margin:0 0 16px}',
    '.ptz-opz{display:flex;flex-direction:column;gap:10px}.ptz-opz button{border:0;border-radius:16px;padding:15px 14px;background:#F2F6FC;color:var(--navy,#14234A);font:700 15px var(--font-body);cursor:pointer;text-align:left}.ptz-opz button.on{background:#0075E3;color:#fff}',
    '.ptz-val{font:900 46px var(--font-display,var(--font-body));color:#0075E3;margin:4px 0 6px}.ptz-range{width:100%;margin:0 0 18px;accent-color:#0075E3}',
    '.ptz-zero{display:block;width:100%;margin-top:10px;padding:13px;border:0;border-radius:99px;background:transparent;box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}',
    '.ptz-nota{margin-top:14px!important;font-size:13px!important}'
  ].join('');
  document.head.appendChild(st);
})();
