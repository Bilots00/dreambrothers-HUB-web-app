/* =========================================================================================
   IL NEGOZIO, IL MERCATO E L'ENERGIA (0.9.317)

   Andrea: "toccando le monete del Full Focus voglio una pagina del negozio esattamente come quella di Duolingo, con un
   mercato con le offerte giornaliere come su Clash Royale, che cambia ogni giorno, con cose da comprare con le monete e un
   pugno di monete gratis da riscuotere ogni giorno. Per alcune missioni l'energia che si consuma con il piano gratis:
   limitata, cosi' chi vuole fa l'upgrade, e puo' guardare annunci".

   Il riferimento e' nella cartella The Dream Map/Duolingo/Negozio. Dall'alto: il riquadro Premium, le offerte speciali (la
   box del mattino, quella della sera, quella gratis con un annuncio), lo slancio (protezione della serie), i potenziamenti,
   l'energia, il codice promo. Il mercato e' di Clash Royale: sei caselle, due chiuse dal livello.
   Non ci sono pacchetti di monete a pagamento: servono i prodotti sul Play Store, e quelli li decide Andrea.

   Gli annunci passano da adsRicompensa (ads.js): finche' non c'e' l'unita' Rewarded vera su AdMob sono quelli di prova di Google.
   ========================================================================================= */
const NG_KEY = 'fl_negozio';
const EN_KEY = 'fl_energia';
const EN_MAX = 25;
const EN_RICARICA_MIN = 20;     // un punto ogni venti minuti: piena in poco piu' di otto ore
const EN_COSTO = { es: 5, ep: 5 };  // gli esercizi e gli episodi della Mappa. Full Focus, missioni e tutto il resto non consumano
const EN_PREZZO_PIENO = 210;

function ngEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function ngOggi(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function ngPremium(){ try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; } }
function ngStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(NG_KEY) || 'null'); }catch(_){ }
  if (!s || typeof s !== 'object') s = {};
  if (s.giorno !== ngOggi()) s = { giorno: ngOggi(), presi: [], codici: s.codici || [], mattino: s.mattino || '', sera: s.sera || '' };
  return s;
}
function ngSalva(s){ try{ localStorage.setItem(NG_KEY, JSON.stringify(s)); }catch(_){ } }
function ngMonete(){ try{ return (typeof ffCoins === 'function') ? ffCoins() : 0; }catch(_){ return 0; } }
function ngPaga(prezzo){
  if (ngMonete() < prezzo){ toast('Ti mancano ' + (prezzo - ngMonete()) + ' monete'); return false; }
  ffAddCoins(-prezzo);
  return true;
}
function ngLivello(){ try{ return (typeof lvInfo === 'function') ? (lvInfo().level || 1) : 1; }catch(_){ return 1; } }
function ngVibra(p){ try{ if (typeof flVibra === 'function') flVibra(p || 12); }catch(_){ } }

/* ---------------------------------------------------------------- l'energia */
function enStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(EN_KEY) || 'null'); }catch(_){ }
  if (!s || !(s.at > 0)) s = { v: EN_MAX, at: Date.now() };
  const passati = Math.floor((Date.now() - s.at) / (EN_RICARICA_MIN * 60000));
  if (passati > 0){
    s.v = Math.min(EN_MAX, (+s.v || 0) + passati);
    s.at = s.v >= EN_MAX ? Date.now() : s.at + passati * EN_RICARICA_MIN * 60000;
    try{ localStorage.setItem(EN_KEY, JSON.stringify(s)); }catch(_){ }
  }
  return s;
}
function enValore(){ return ngPremium() ? EN_MAX : enStato().v; }
function enAggiungi(n){
  const s = enStato();
  /* si puo' superare il tetto solo con una ricarica comprata, mai oltre il doppio */
  s.v = Math.max(0, Math.min(EN_MAX * 2, (+s.v || 0) + n));
  if (s.v >= EN_MAX) s.at = Date.now();
  try{ localStorage.setItem(EN_KEY, JSON.stringify(s)); }catch(_){ }
}
/** Serve energia per partire? Con Premium no. Se non basta si apre il foglio, e la tappa parte solo dopo la ricarica. */
function enUsa(costo, poi){
  if (ngPremium() || !(costo > 0)){ poi(); return; }
  if (enValore() < costo){ enFoglio(costo, poi); return; }
  enAggiungi(-costo);
  try{ toast('⚡ ' + enValore() + ' di ' + EN_MAX + ' di energia'); }catch(_){ }
  poi();
}
let EN_POI = null, EN_COSTO_ORA = 0, EN_SCELTA = 'annuncio';
function enFoglio(costo, poi){
  EN_POI = poi || null; EN_COSTO_ORA = costo || 0;
  EN_SCELTA = (typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile()) ? 'annuncio' : 'monete';
  enFoglioDisegna();
}
function enFoglioDisegna(){
  const puoAd = typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile();
  const card = function(k, testa, nome, sotto, cl){
    return '<button type="button" class="en-card ' + (cl || '') + (EN_SCELTA === k ? ' on' : '') + '" onclick="enSceglie(\'' + k + '\')">' + testa + '<b>' + nome + '</b><small>' + sotto + '</small></button>';
  };
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="enFoglioChiudi()">✕</button>'
    + '<div class="en-saldo">🪙 ' + ngMonete() + '<span>⚡ ' + enValore() + ' di ' + EN_MAX + '</span></div>'
    + '<h3>Vuoi ricaricare l’energia prima di questa tappa?</h3>'
    + '<div class="en-carte">'
    +   card('premium', '<i class="en-bat inf">∞</i>', 'Illimitata', 'Passa a Premium', 'prem')
    +   card('monete', '<i class="en-bat">' + EN_MAX + '</i>', 'Ricarica', '🪙 ' + EN_PREZZO_PIENO)
    +   (puoAd ? card('annuncio', '<i class="en-bat poca">5</i>', '+5 energia', 'Guarda un annuncio') : '')
    + '</div>'
    + '<button type="button" class="en-cta" onclick="enConferma()">' + (EN_SCELTA === 'annuncio' ? '▶ Guarda per ricaricare l’energia' : EN_SCELTA === 'monete' ? 'Ricarica con ' + EN_PREZZO_PIENO + ' monete' : 'Prova Premium gratis') + '</button>'
    + '<button type="button" class="en-no" onclick="enFoglioChiudi()">No, grazie</button></div>');
}
function enSceglie(k){ EN_SCELTA = k; ngVibra(8); enFoglioDisegna(); }
function enFoglioChiudi(){ EN_POI = null; try{ inSheetChiudi(); }catch(_){ } }
function enRiprendi(){
  const f = EN_POI, c = EN_COSTO_ORA; EN_POI = null;
  try{ inSheetChiudi(); }catch(_){ }
  ngRidisegna();
  if (f && enValore() >= c) setTimeout(function(){ enUsa(c, f); }, 250);
  else if (f){ try{ toast('Ti servono ' + c + ' punti di energia per questa tappa'); }catch(_){ } }
}
function enConferma(){
  if (EN_SCELTA === 'premium'){ const f = EN_POI; EN_POI = null; try{ inSheetChiudi(); }catch(_){ } pfApri(); return; }
  if (EN_SCELTA === 'monete'){
    if (!ngPaga(EN_PREZZO_PIENO)) return;
    enAggiungi(EN_MAX); ngVibra([20, 40, 60]); enRiprendi(); return;
  }
  if (typeof adsRicompensa === 'function') adsRicompensa(function(){ enAggiungi(5); ngVibra([20, 40, 60]); enRiprendi(); });
}
/* la Mappa: gli esercizi e gli episodi consumano energia, una volta sola per tappa non ancora fatta */
(function(){
  if (typeof sdTapVia !== 'function') return;
  const orig = sdTapVia;
  sdTapVia = window.sdTapVia = function(id){
    try{
      const nd = (typeof sdCorrente === 'function') ? sdCorrente().tutti.filter(function(x){ return x.id === id; })[0] : null;
      const costo = nd ? (EN_COSTO[nd.tipo] || 0) : 0;
      if (costo && !sdNodoFatto(nd, sdStato())){ enUsa(costo, function(){ orig(id); }); return; }
    }catch(_){ }
    return orig(id);
  };
})();

/* ---------------------------------------------------------------- il mercato */
/* 0.9.331, Andrea: "dal mercato 300, nello slancio 120: un'incongruenza". Un prezzo solo */
const NG_PREZZO_PROT = 120;
/* Il catalogo. peso: quante volte puo' uscire. Ogni offerta dice cosa da' con parole vere. */
const NG_OFFERTE = {
  box: { nome: 'Mystery box', raro: 'Comune', ico: '<img src="img/mystery/chiusa.webp" alt="">', qta: '', prezzo: 300, peso: 3, fa: function(){ ngChiudiSoprapposti(); scrApriPremio('bronzo', { onChiudi: ngRidisegna }); } },
  boxrara: { nome: 'Mystery box', raro: 'Rara', ico: '<img src="img/mystery/chiusa.webp" alt="">', qta: '×3', prezzo: 800, peso: 1, fa: function(){ ngChiudiSoprapposti(); scrApriPremio('argento', { onChiudi: ngRidisegna }); } },
  suono: { nome: 'Suono della notte', raro: 'Rara', ico: '🎵', qta: '', prezzo: 150, peso: 3, puo: function(){ return typeof suoTracciaDaBox === 'function'; }, fa: function(){ const t = suoTracciaDaBox('argento'); toast(t ? 'Suono sbloccato: ' + t.t : 'Hai già tutti i suoni di questa notte: ti ridò le monete'); if (!t) ffAddCoins(150); } },
  gettone: { nome: 'Congelamento della serie', raro: 'Rara', ico: '🧊', qta: '×1', prezzo: NG_PREZZO_PROT, peso: 2, puo: function(){ return ngGettoni() < 3; }, fa: function(){ ngGettoneAggiungi(); ngFestaProtezione(); } },
  energia: { nome: 'Energia', raro: 'Comune', ico: '⚡', qta: '+10', prezzo: 150, peso: 3, puo: function(){ return !ngPremium(); }, fa: function(){ enAggiungi(10); toast('⚡ +10 di energia'); } },
  punti: { nome: 'Dream Points', raro: 'Comune', ico: '✨', qta: '+50', prezzo: 40, peso: 3, fa: function(){ if (typeof scrAddDP === 'function') scrAddDP(50); toast('+50 Dream Points'); } },
  pozione: { nome: 'Pozione XP tripli', raro: 'Epica', ico: '🧪', qta: '15 min', prezzo: 180, peso: 1, puo: function(){ return typeof sdBoostDai === 'function'; }, fa: function(){ sdBoostDai(typeof SD_BOOST_MIN !== 'undefined' ? SD_BOOST_MIN : 15, 3); toast('Per 15 minuti ogni tappa vale il triplo'); } }
};
const NG_SLOT_LIVELLO = [0, 0, 0, 0, 7, 9];
function ngSeme(giorno){ let h = 7; String(giorno).split('').forEach(function(c){ h = (h * 31 + c.charCodeAt(0)) >>> 0; }); return h; }
function ngRnd(st){ st.h = (st.h * 1664525 + 1013904223) >>> 0; return st.h / 4294967296; }
/** Le offerte di oggi, sempre le stesse per tutta la giornata. La prima casella e' il pugno di monete gratis. */
function ngOfferteOggi(){
  const st = { h: ngSeme(ngOggi()) };
  const chiavi = Object.keys(NG_OFFERTE).filter(function(k){ const o = NG_OFFERTE[k]; return !o.puo || o.puo(); });
  const sacco = [];
  chiavi.forEach(function(k){ for (let i = 0; i < NG_OFFERTE[k].peso; i++) sacco.push(k); });
  const out = ['gratis'];
  while (out.length < NG_SLOT_LIVELLO.length && sacco.length){
    const k = sacco[Math.floor(ngRnd(st) * sacco.length)];
    if (out.indexOf(k) < 0) out.push(k);
    for (let i = sacco.length - 1; i >= 0; i--) if (sacco[i] === k) sacco.splice(i, 1);
  }
  return out;
}
function ngGratisQuanti(){ return 10 + (ngSeme(ngOggi()) % 3) * 5; }
function ngMercatoHtml(){
  const off = ngOfferteOggi(), s = ngStato(), lv = ngLivello();
  const fine = new Date(); fine.setHours(24, 0, 0, 0);
  const min = Math.max(1, Math.round((fine.getTime() - Date.now()) / 60000));
  const caselle = NG_SLOT_LIVELLO.map(function(liv, i){
    if (lv < liv) return '<div class="ng-off chiusa"><i>🔒</i><small>Si sblocca al</small><b>livello ' + liv + '</b></div>';
    const k = off[i];
    if (!k) return '<div class="ng-off chiusa"><i>🔒</i><small>Domani</small><b>una nuova offerta</b></div>';
    const preso = s.presi.indexOf(k) >= 0;
    if (k === 'gratis'){
      const n = ngGratisQuanti();
      return '<button type="button" class="ng-off gratis' + (preso ? ' presa' : '') + '" ' + (preso ? 'disabled' : 'onclick="ngCompra(\'gratis\')"') + '>'
        + '<small class="ng-raro">Pugno di monete</small><span class="ng-ico">🪙</span><em class="ng-qta">×' + n + '</em>'
        + '<b class="ng-pr">' + (preso ? '✓ Ottenuto' : 'Gratis') + '</b></button>';
    }
    const o = NG_OFFERTE[k];
    return '<button type="button" class="ng-off r-' + o.raro.toLowerCase() + (preso ? ' presa' : '') + '" ' + (preso ? 'disabled' : 'onclick="ngCompra(\'' + k + '\')"') + '>'
      + '<small class="ng-raro">' + ngEsc(o.nome) + '</small><span class="ng-ico">' + o.ico + '</span>' + (o.qta ? '<em class="ng-qta">' + o.qta + '</em>' : '')
      + '<b class="ng-pr">' + (preso ? '✓ Acquistato' : '🪙 ' + o.prezzo) + '</b></button>';
  }).join('');
  return '<section class="ng-mer"><h2 class="ng-mer-t">Mercato</h2><p class="ng-mer-s">Offerte giornaliere<span>Nuove offerte fra ' + Math.floor(min / 60) + ' h ' + (min % 60) + ' min</span></p><div class="ng-griglia">' + caselle + '</div></section>';
}
function ngCompra(k){
  const s = ngStato(); if (s.presi.indexOf(k) >= 0) return;
  if (k === 'gratis'){
    const n = ngGratisQuanti();
    ffAddCoins(n); s.presi.push(k); ngSalva(s); ngVibra([20, 40, 60]);
    toast('+' + n + ' monete'); ngRidisegna(); return;
  }
  const o = NG_OFFERTE[k]; if (!o) return;
  if (!ngPaga(o.prezzo)){ ngRidisegna(); return; }
  s.presi.push(k); ngSalva(s); ngVibra([20, 40, 60]);
  ngRidisegna();
  try{ o.fa(); }catch(_){ }
  ngRidisegna();
}
function ngChiudiSoprapposti(){ }
function ngGettoni(){ try{ return (typeof snStato === 'function') ? (snStato().serie.gettoni || 0) : 0; }catch(_){ return 0; } }
function ngGettoneAggiungi(){ try{ const sn = snStato(); sn.serie.gettoni = Math.min(3, (sn.serie.gettoni || 0) + 1); snSalva(sn); }catch(_){ } }

/* ---------------------------------------------------------------- le offerte speciali */
function ngOraDi(){ return new Date().getHours(); }
function ngTappaStasera(){
  try{ return (typeof sdTappeOggi === 'function') && sdTappeOggi() > 0 && ngOraDi() >= 18; }catch(_){ return false; }
}
function ngSpecialiHtml(){
  const s = ngStato(), h = ngOraDi();
  const fatto = function(c){ return c === ngOggi(); };
  let mattino;
  if (fatto(s.mattino)) mattino = '<p>La riapri domani, dalle <b>6:00</b>.</p>';
  else if (h >= 6 && h < 12) mattino = '<p>È pronta: si apre fino a <b>mezzogiorno</b>.</p><button type="button" class="ng-az" onclick="ngBoxMattino()">Aprila</button>';
  else { const ore = h < 6 ? 6 - h : 30 - h; mattino = '<p>La tua prossima box sarà pronta fra <b class="ng-ora">' + ore + (ore === 1 ? ' ora' : ' ore') + '</b>.</p>'; }
  let sera;
  if (fatto(s.sera)) sera = '<p>La riapri domani sera.</p>';
  else if (ngTappaStasera()) sera = '<p>Hai fatto una tappa stasera: è tua.</p><button type="button" class="ng-az" onclick="ngBoxSera()">Aprila</button>';
  else sera = '<p>Fai una tappa fra le <b>18:00 e mezzanotte</b> per sbloccarla.</p><small class="ng-chiuso">Bloccata</small>';
  const ad = typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile();
  const riga = function(img, t, corpo, cl){ return '<div class="ng-card ' + (cl || '') + '"><span class="ng-card-i">' + img + '</span><div><b>' + t + '</b>' + corpo + '</div></div>'; };
  const box = function(cl){ return '<img class="ng-box ' + cl + '" src="img/mystery/chiusa.webp" alt="">'; };
  return '<h2 class="ng-t">Offerte speciali</h2>'
    + riga(box('m'), 'Box del mattino', mattino)
    + riga(box('s'), 'Box della sera', sera)
    + (ad ? riga(box('g'), 'Box gratuita', '<p>Guarda un annuncio per guadagnare dei premi.</p><button type="button" class="ng-az ad" onclick="ngBoxAnnuncio()">▶ Ottieni la box</button>') : '');
}
function ngBoxMattino(){ const s = ngStato(); s.mattino = ngOggi(); ngSalva(s); scrApriPremio('bronzo', { titolo: 'Box del mattino', onChiudi: ngRidisegna }); }
function ngBoxSera(){ const s = ngStato(); s.sera = ngOggi(); ngSalva(s); scrApriPremio('argento', { titolo: 'Box della sera', onChiudi: ngRidisegna }); }
function ngBoxAnnuncio(){ if (typeof adsRicompensa === 'function') adsRicompensa(function(){ scrApriPremio('bronzo', { titolo: 'Box gratuita', onChiudi: ngRidisegna }); }); }

/* ---------------------------------------------------------------- il codice promo */
const NG_CODICI = { DREAMMAP: 100 };
function ngCodiceApri(){
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<h3>Scrivi il tuo codice promo</h3>'
    + '<input class="ng-cod" id="ngCod" autocapitalize="characters" autocomplete="off" placeholder="Il codice">'
    + '<button type="button" class="en-cta" onclick="ngCodiceUsa()">Attiva il codice</button></div>');
  setTimeout(function(){ const i = document.getElementById('ngCod'); if (i) i.focus(); }, 200);
}
function ngCodiceUsa(){
  const i = document.getElementById('ngCod'), c = String(i ? i.value : '').trim().toUpperCase();
  if (!c){ if (i) i.focus(); return; }
  const s = ngStato();
  if ((s.codici || []).indexOf(c) >= 0){ toast('Hai già usato questo codice'); return; }
  const n = NG_CODICI[c];
  if (!n){ toast('Questo codice non è valido'); return; }
  s.codici = (s.codici || []).concat([c]); ngSalva(s);
  ffAddCoins(n); ngVibra([20, 40, 60]);
  try{ inSheetChiudi(); }catch(_){ }
  toast('+' + n + ' monete'); ngRidisegna();
}

/* ---------------------------------------------------------------- la pagina */
function ngCardRiga(ico, t, p, azione){ return '<div class="ng-card"><span class="ng-card-i grande">' + ico + '</span><div><b>' + t + '</b><p>' + p + '</p>' + (azione || '') + '</div></div>'; }
function ngPremiumAltroHtml(){
  let cr = null; try{ cr = (typeof AG !== 'undefined' && AG) ? AG.crediti : null; }catch(_){ cr = null; }
  try{ if (!cr && typeof agCrediti === 'function') agCrediti().then(function(){ try{ if (document.getElementById('ngBody') && AG.crediti && !AG.crediti.illimitato && AG.crediti.saldo <= 20) ngPaint(); }catch(_){ } }); }catch(_){ }
  const pochi = cr && !cr.illimitato && (cr.saldo || 0) <= 20;
  return (pochi ? '<section class="ng-cred"><span aria-hidden="true">⚡</span><div><b>' + (cr.saldo > 0 ? 'Ti restano ' + cr.saldo + ' crediti del tuo agente' : 'Hai finito i crediti del tuo agente') + '</b><p>Ricaricali e il tuo agente riprende da dove eravate rimasti.</p></div><button type="button" onclick="pfApri()">Ricarica</button></section>' : '')
    /* 0.9.349, Andrea: "in alto, al posto del Premium, un'altra offerta". Il quadro su misura del tema ("Hang your dream") */
    + '<section class="ng-prem ng-hang"><div class="ng-prem-su"><div><span class="ng-prem-b">DREAMBROTHERS</span><h2>Appendi il tuo sogno</h2><p>Un quadro fatto con la tua frase e la tua immagine, da guardare ogni mattina.</p></div><span class="ng-hang-e" aria-hidden="true">🖼️</span></div>'
    + '<button type="button" onclick="ufOpenUrl(\'' + NG_SHOP.crea + '\')">Crea il tuo quadro</button></section>';
}
/* 0.9.349, Andrea: "azione, identita' e ambiente spiegato cosi' e' troppo testo in una slide: un carosello come su Instagram, in fondo al
   negozio, che ci arriva per gradi". I link sono gli stessi dei pulsanti della slide "Shop by Dream" del tema: Elevate your space porta a
   tutti i quadri, Wear your vision a tutto l'abbigliamento */
const NG_SHOP = { quadri: 'https://dream-brothers.com/collections/all-wall-art', vestiti: 'https://dream-brothers.com/collections/all-apparel', crea: 'https://dream-brothers.com/products/create-your-own-wall-art' };
function ngAmbHtml(){
  const vai = function(u, t, sec){ return '<button type="button" class="ng-amb-b' + (sec ? ' sec' : '') + '" onclick="event.stopPropagation();ufOpenUrl(\'' + u + '\')">' + t + '</button>'; };
  const sl = [
    ['🧩', 'Azione, identità, ambiente', 'Tre cose decidono se ce la fai', 'Quello che fai, chi pensi di essere e quello che hai intorno.', ''],
    ['⚡', 'Azione', 'L’azione la rende facile l’app', 'Blocchi, tappe e Full Focus fanno del lavoro sul sogno la scelta più semplice.', ''],
    ['🪞', 'Identità', 'L’identità la porti addosso', 'Un vestito che ti ricorda chi stai diventando, ogni volta che ti guardi allo specchio.', vai(NG_SHOP.vestiti, 'Vedi i vestiti')],
    ['🖼️', 'Ambiente', 'L’ambiente lo guardi ogni giorno', 'Un quadro nella tua stanza ti richiama al sogno prima ancora del telefono.', vai(NG_SHOP.quadri, 'Vedi i quadri')],
    ['✨', 'Tutti e tre insieme', 'Quando vanno d’accordo, costa meno fatica', 'L’app l’hai già. Scegli da quale delle altre due partire.', vai(NG_SHOP.quadri, 'Un quadro per la stanza') + vai(NG_SHOP.vestiti, 'Vestiti da chi diventi', true)]
  ];
  return '<h2 class="ng-t">Azione, identità, ambiente</h2><section class="ng-amb2"><div class="ng-amb2-car" onscroll="ngAmbDot(this)">'
    + sl.map(function(x, i){ return '<div class="ng-amb2-s s' + i + '"><span class="ng-amb2-e" aria-hidden="true">' + x[0] + '</span><small>' + x[1] + '</small><h3>' + x[2] + '</h3><p>' + x[3] + '</p>' + (x[4] ? '<div class="ng-amb2-bb">' + x[4] + '</div>' : (i < sl.length - 1 ? '<em class="ng-amb2-av">Scorri →</em>' : '')) + '</div>'; }).join('')
    + '</div><div class="ng-amb2-dots">' + sl.map(function(_, i){ return '<i' + (i ? '' : ' class="on"') + '></i>'; }).join('') + '</div></section>';
}
function ngAmbDot(c){ const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)); const d = c.nextElementSibling; if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); }
(function(){ const st = document.createElement('style'); st.textContent = '.ng-hang .ng-hang-e{flex:none;font-size:64px;line-height:1;filter:drop-shadow(0 8px 16px rgba(0,0,0,.3))}'
  + '.ng-amb2{margin:0 0 26px}.ng-amb2-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;gap:12px;overscroll-behavior-x:contain}.ng-amb2-car::-webkit-scrollbar{display:none}'
  + '.ng-amb2-s{flex:0 0 100%;box-sizing:border-box;min-width:0;scroll-snap-align:center;min-height:300px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:30px 22px 26px;border-radius:24px;background:linear-gradient(160deg,#0075E3 0%,#001E44 78%);color:#fff}'
  + '.ng-amb2-s.s1{background:linear-gradient(160deg,#3F9FF4 0%,#001E44 80%)}.ng-amb2-s.s2{background:linear-gradient(160deg,#E63946 0%,#001E44 78%)}.ng-amb2-s.s4{background:linear-gradient(135deg,#E63946 0%,#0075E3 55%,#001E44 100%)}'
  + '.ng-amb2-e{font-size:48px;line-height:1;margin-bottom:16px}.ng-amb2-s small{font:800 11.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#C8EFFD}.ng-amb2-s h3{margin:10px 0 0;font:800 22px/1.25 var(--font-display);color:#fff;max-width:18ch}.ng-amb2-s p{margin:12px auto 0;max-width:30ch;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.88)}'
  + '.ng-amb2-bb{display:flex;flex-direction:column;gap:10px;width:100%;margin-top:26px}.ng-amb2-b{min-height:50px;border:0;border-radius:25px;background:#fff;color:#001E44;font:800 15px var(--font-body);cursor:pointer}.ng-amb2-b.sec{background:none;border:2px solid rgba(255,255,255,.6);color:#fff}.ng-amb2-av{margin-top:24px;font:700 13px var(--font-body);font-style:normal;color:#C8EFFD}'
  + '.ng-amb2-dots{display:flex;justify-content:center;gap:6px;margin-top:14px}.ng-amb2-dots i{width:7px;height:7px;border-radius:4px;background:#BCE0FF;transition:width .2s}.ng-amb2-dots i.on{width:20px;background:#0075E3}body.dark .ng-amb2-dots i{background:#2C4170}body.dark .ng-amb2-dots i.on{background:#8CC6FF}';
  document.head.appendChild(st); })();
(function(){ const st = document.createElement('style'); st.textContent = '.ng-cred{display:flex;align-items:center;gap:12px;margin:0 0 18px;padding:14px 16px;border-radius:20px;background:#F0FBFF;border:1.5px solid #C8EFFD}.ng-cred > span{font-size:26px}.ng-cred div{flex:1;min-width:0}.ng-cred b{display:block;font:800 15px var(--font-body);color:var(--navy)}.ng-cred p{margin:3px 0 0;font:500 13px/1.4 var(--font-body);color:var(--muted)}.ng-cred button{flex:none;padding:10px 14px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13.5px var(--font-body);cursor:pointer}body.dark .ng-cred{background:#12203A;border-color:#22345A}body.dark .ng-cred b{color:#fff}'
  + '.ng-amb{margin:0 0 22px;padding:20px 18px;border-radius:24px;background:linear-gradient(135deg,#0075E3,#001E44);color:#fff;text-align:center}.ng-amb-k{display:block;font:800 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#C8EFFD}.ng-amb h2{margin:8px 0 8px;font:800 19px/1.3 var(--font-display);color:#fff}.ng-amb p{margin:0 0 16px;font:500 14px/1.5 var(--font-body);color:#C8EFFD}'
  + '.ng-amb-g{display:grid;grid-template-columns:1fr 1fr;gap:10px}.ng-amb-c{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 10px;border-radius:18px;border:0;background:rgba(255,255,255,.12);color:#fff;cursor:pointer;font-family:var(--font-body)}.ng-amb-c span{font-size:28px}.ng-amb-c b{font:800 14px/1.3 var(--font-body);color:#fff}.ng-amb-c small{font:500 12px/1.35 var(--font-body);color:#C8EFFD}'; document.head.appendChild(st); })();
function ngPaint(){
  const h = document.getElementById('ngBody'); if (!h) return;
  const prem = ngPremium(), g = ngGettoni(), en = enValore();
  const c = document.getElementById('ngSaldo'); if (c) c.textContent = ngMonete();
  /* 0.9.318, Andrea: il riquadro come quello di Duolingo apre il funnel; per primo il riquadro e le offerte speciali, il mercato in fondo.
     Finche' Premium e' acceso per le prove (FL_DEBUG_PREMIUM) si vede lo stesso: altrimenti il funnel non lo vedrebbe nessuno. */
  /* 0.9.348, Andrea: "dice Passa a Premium anche se sono gia' Premium". Il riquadro Premium lo vede solo chi non ce l'ha. Chi ce l'ha
     trova al suo posto i crediti (se stanno finendo) e l'ambiente e l'identita': azione, identita' e ambiente allineati, e tutto costa
     meno fatica (i quadri cambiano la stanza, i vestiti ricordano chi stai diventando) */
  const vedi = !prem;
  let prova = false; try{ prova = typeof pwTrialUsed === 'function' && !pwTrialUsed(); }catch(_){ }
  h.innerHTML = (vedi ? '<section class="ng-prem"><div class="ng-prem-su"><div><span class="ng-prem-b">PREMIUM</span><h2>Arriva al sogno senza freni</h2><p>Energia illimitata, zero annunci e il tuo agente personale.</p></div><img src="img/genio/genio-rivela.png" alt=""></div><button type="button" onclick="pfApri()">' + (prova ? 'Prova gratis per 1 settimana' : 'Passa a Premium') + '</button></section>' : '')
    + (vedi ? '' : ngPremiumAltroHtml())
    + ngSpecialiHtml()
    + '<h2 class="ng-t">Slancio</h2>'
    + ngCardRiga('🧊', 'Congelamento della serie', 'Congela la serie se salti un giorno di tappe.',
        g >= 3 ? '<small class="ng-attive">3/3 attive</small>' : '<button type="button" class="ng-az" onclick="ngCompraGettone()">🪙 ' + NG_PREZZO_PROT + '</button><small class="ng-attive">' + g + '/3 attive</small>')
    + '<h2 class="ng-t">Potenziamenti</h2>'
    + ngCardRiga('🧪', 'Pozione XP tripli', 'Per 15 minuti ogni tappa della Mappa vale il triplo dei punti.', '<button type="button" class="ng-az" onclick="ngCompraPozione()">🪙 450</button>')
    + '<h2 class="ng-t">Energia</h2>'
    + ngCardRiga('<i class="en-bat inf">∞</i>', 'Illimitata', 'Con Premium non resti mai senza energia.', prem ? '<small class="ng-attive">Attiva</small>' : '<button type="button" class="ng-az prem" onclick="pfApri()">Prova gratis</button>')
    + (prem ? '' : ngCardRiga('<i class="en-bat">⚡</i>', 'Ricarica', 'Hai ' + en + ' punti di energia su ' + EN_MAX + '. Gli esercizi e gli episodi della Mappa ne usano 5.', '<button type="button" class="ng-az" onclick="ngCompraEnergia()">🪙 ' + EN_PREZZO_PIENO + '</button>'))
    + '<h2 class="ng-t">Codice promo</h2>'
    + ngCardRiga('🎟️', 'Usa un codice promo', 'Scrivi un codice promo per vincere dei premi.', '<button type="button" class="ng-az" onclick="ngCodiceApri()">Attiva</button>')
    + ngMercatoHtml()
    + (vedi ? '' : ngAmbHtml())
    + '<div class="ng-fondo"></div>';
}
function ngRidisegna(){ try{ ngPaint(); }catch(_){ } }
function ngCompraGettone(){ if (ngGettoni() >= 3 || !ngPaga(NG_PREZZO_PROT)) return; ngGettoneAggiungi(); ngRidisegna(); ngFestaProtezione(); }
/* 0.9.331, Andrea: "non c'e' nessun feedback, in Clash Royale quando compri qualcosa lo senti". Lo scudo arriva dall'alto, si accende e riempie il suo posto fra le tre protezioni */
function ngFestaProtezione(){
  const n = ngGettoni();
  const w = document.createElement('div'); w.id = 'ngFesta';
  w.innerHTML = '<div class="ngf-raggi"></div><div class="ngf-c"><div class="ngf-scudo" aria-hidden="true"><svg viewBox="0 0 120 140"><defs><linearGradient id="ngfG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8CC6FF"/><stop offset="1" stop-color="#0075E3"/></linearGradient></defs><path d="M60 6l50 18v42c0 34-22 56-50 68C32 122 10 100 10 66V24z" fill="url(#ngfG)" stroke="#fff" stroke-width="5"/><path d="M38 68l16 16 30-34" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/></svg></div>'
    + '<small>Congelamento della serie</small><h2>La tua serie è più al sicuro</h2><p>Se salti un giorno di tappe, la serie non si spezza.</p>'
    + '<div class="ngf-tre">' + [1, 2, 3].map(function(i){ return '<i class="' + (i < n ? 'pieno' : (i === n ? 'nuovo' : '')) + '"></i>'; }).join('') + '</div><b class="ngf-n">' + n + ' su 3</b>'
    + '<button type="button" class="ngf-cta">Fantastico</button></div>';
  const via = function(){ w.classList.add('via'); setTimeout(function(){ w.remove(); }, 260); };
  w.querySelector('.ngf-cta').addEventListener('click', via);
  (document.getElementById('phone') || document.body).appendChild(w);
  try{ flVibra([20, 40, 30, 40, 80]); }catch(_){ }
  try{ if (typeof fxSuona === 'function') fxSuona('sblocco'); else if (typeof muJingle === 'function') muJingle('missione'); }catch(_){ }
}
function ngCompraPozione(){ if (typeof sdBoostDai !== 'function' || !ngPaga(450)) return; sdBoostDai(typeof SD_BOOST_MIN !== 'undefined' ? SD_BOOST_MIN : 15, 3); ngVibra([20, 40, 60]); toast('Per 15 minuti ogni tappa vale il triplo'); ngRidisegna(); }
function ngCompraEnergia(){ if (!ngPaga(EN_PREZZO_PIENO)) return; enAggiungi(EN_MAX); ngVibra([20, 40, 60]); toast('⚡ Energia ricaricata'); ngRidisegna(); }
function ngApri(){ goId('s-negozio'); ngPaint(); }
registerScreen('s-negozio',
  '<div class="ng-top"><button type="button" class="ng-x" aria-label="Chiudi" onclick="flIndietro()"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button><b>Negozio</b><span class="ng-saldo">🪙 <i id="ngSaldo">0</i></span></div>'
  + '<div class="ng-pag" id="ngBody"></div>', { back: 's-home' });
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-negozio') ngPaint(); });

(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* il negozio e' scuro in entrambi i temi, con il testo bianco fisso: e' il disegno del riferimento, nei colori del brand */
    '#s-negozio{padding:0;background:#0B1B3E;color:#fff;overflow:hidden}',
    '.ng-top{position:absolute;left:0;right:0;top:0;z-index:2;display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:calc(env(safe-area-inset-top,0px) + 10px) 16px 12px;background:#0B1B3E;border-bottom:2px solid rgba(188,224,255,.14)}',
    '.ng-top b{font:800 19px var(--font-display);color:#BCE0FF}',
    '.ng-x{justify-self:start;width:44px;height:44px;margin-left:-8px;border:0;background:none;color:#BCE0FF;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.ng-saldo{justify-self:end;font:800 17px var(--font-body);color:#FFD66B}.ng-saldo i{font-style:normal}',
    '.ng-pag{position:absolute;inset:0;overflow-y:auto;padding:calc(env(safe-area-inset-top,0px) + 86px) 16px calc(env(safe-area-inset-bottom,0px) + 40px);box-sizing:border-box;-webkit-overflow-scrolling:touch}',
    '.ng-t{margin:34px 4px 14px;font:800 24px var(--font-display);color:#fff}',
    '.ng-prem{padding:22px 18px 20px;border-radius:24px;background:linear-gradient(145deg,#0075E3,#123C86 72%);box-shadow:0 12px 28px rgba(0,117,227,.28)}',
    '.ng-prem-su{display:flex;align-items:center;gap:6px;margin-bottom:18px}.ng-prem-su > div{flex:1;min-width:0}.ng-prem-su img{flex:none;width:112px;height:auto;margin-right:-6px;filter:drop-shadow(2px 0 0 #fff) drop-shadow(-2px 0 0 #fff) drop-shadow(0 2px 0 #fff) drop-shadow(0 -2px 0 #fff);animation:pfFluttua 3s ease-in-out infinite}',
    '.ng-prem-b{display:inline-block;padding:4px 12px;border-radius:8px;background:#fff;color:#0075E3;font:900 12px var(--font-body);letter-spacing:.08em;transform:skewX(-8deg)}',
    '.ng-prem h2{margin:14px 0 8px;font:800 24px/1.2 var(--font-display);color:#fff}.ng-prem p{margin:0;font:500 14.5px/1.45 var(--font-body);color:rgba(255,255,255,.92)}',
    '.ng-prem button{width:100%;min-height:54px;border-radius:16px;border:2px solid transparent;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;color:#fff;text-shadow:1px 2.5px 3px rgba(0,0,0,.9);font:800 15px var(--font-body);letter-spacing:.04em;text-transform:uppercase;cursor:pointer;box-shadow:0 4px 0 rgba(0,30,68,.4)}',
    '.ng-mer{margin-top:38px;text-align:center}.ng-mer-t{margin:0;font:900 27px var(--font-display);color:#fff}',
    '.ng-mer-s{margin:6px 0 16px;font:700 15px var(--font-body);color:#BCE0FF}.ng-mer-s span{display:block;margin-top:2px;font:500 13px var(--font-body);color:rgba(188,224,255,.78)}',
    '.ng-griglia{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}',
    '.ng-off{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:space-between;gap:6px;min-height:168px;box-sizing:border-box;padding:10px 6px;border:2px solid rgba(188,224,255,.22);border-radius:16px;background:#14306B;color:#fff;font-family:var(--font-body);cursor:pointer;overflow:hidden}',
    '.ng-raro{font:800 11.5px/1.2 var(--font-body);color:#BCE0FF;text-align:center;min-height:28px;display:flex;align-items:center}',
    '.ng-ico{font-size:40px;line-height:1}.ng-ico img{display:block;width:52px;height:52px;object-fit:contain}',
    '.ng-qta{font:900 14px var(--font-display);font-style:normal;color:#fff}',
    '.ng-pr{font:800 14px var(--font-body);color:#FFD66B}',
    '.ng-off.gratis{background:linear-gradient(170deg,#0075E3,#123C86);border-color:#8CC6FF}.ng-off.gratis .ng-pr{color:#fff}',
    /* 0.9.349, Andrea: "Gratis e' troppo piccolo, si vede piu' il x10": una pillola rossa, grande */
    '.ng-off.gratis .ng-pr{display:inline-block;margin-top:2px;padding:7px 16px;border-radius:99px;background:#E63946;color:#fff!important;font:900 17px/1 var(--font-display);letter-spacing:.04em;text-transform:uppercase;box-shadow:0 4px 12px rgba(230,57,70,.45)}.ng-off.gratis .ng-qta{font-size:12.5px;opacity:.85}.ng-off.presa .ng-pr{background:none;box-shadow:none;padding:0;font-size:14px}',
    '.ng-off.r-rara{border-color:#3F9FF4}.ng-off.r-epica{border-color:#E63946}',
    '.ng-off.presa{opacity:.55;cursor:default}.ng-off.presa .ng-pr{color:#BCE0FF}',
    '.ng-off.chiusa{justify-content:center;background:rgba(255,255,255,.04);border-style:dashed;cursor:default}.ng-off.chiusa i{font-style:normal;font-size:30px;line-height:1}.ng-off.chiusa small{margin-top:8px;font:600 12px var(--font-body);color:rgba(188,224,255,.78)}.ng-off.chiusa b{font:800 13px var(--font-body);color:#fff;text-align:center}',
    '.ng-card{display:flex;align-items:center;gap:16px;margin-bottom:12px;padding:18px 16px;border:2px solid rgba(188,224,255,.2);border-radius:20px}',
    '.ng-card-i{flex:none;width:76px;display:flex;align-items:center;justify-content:center;line-height:1}.ng-card-i.grande{font-size:50px}',
    '.ng-box{display:block;width:74px;height:74px;object-fit:contain}.ng-box.s{filter:hue-rotate(345deg) saturate(1.3)}',
    '.ng-card b{display:block;font:800 18px var(--font-display);color:#fff}.ng-card p{margin:6px 0 0;font:500 14.5px/1.45 var(--font-body);color:rgba(255,255,255,.86)}.ng-card p b{display:inline;font:800 14.5px var(--font-body)}.ng-card p b.ng-ora{color:#8CC6FF}',
    '.ng-az{display:inline-flex;align-items:center;gap:6px;margin-top:10px;padding:0;border:0;background:none;color:#8CC6FF;font:800 15px var(--font-body);cursor:pointer;min-height:32px}.ng-az.prem{color:#FF8A92}',
    '.ng-attive{display:inline-block;margin:10px 0 0 10px;padding:4px 10px;border-radius:9px;background:rgba(63,159,244,.2);color:#BCE0FF;font:800 13px var(--font-body)}',
    '.ng-az + .ng-attive{vertical-align:middle}.ng-card > div > .ng-attive:first-of-type:not(:nth-child(n+4)){margin-left:0}',
    '.ng-chiuso{display:block;margin-top:10px;font:800 13.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:rgba(188,224,255,.7)}',
    '.ng-fondo{height:20px}',
    '.ng-cod{display:block;width:100%;box-sizing:border-box;margin:6px 0 14px;padding:14px;border:1.5px solid #BCE0FF;border-radius:14px;background:var(--card,#fff);color:var(--navy);font:800 17px var(--font-body);text-align:center;text-transform:uppercase}',
    /* il foglio dell'energia */
    '.en-foglio{position:relative;text-align:center}.en-foglio h3{margin:10px 26px 18px;font:800 21px/1.25 var(--font-display);color:var(--navy)}body.dark .en-foglio h3{color:#fff}',
    '.en-saldo{display:flex;justify-content:center;gap:16px;font:800 14.5px var(--font-body);color:#0075E3}.en-saldo span{color:var(--navy)}body.dark .en-saldo{color:#8CC6FF}body.dark .en-saldo span{color:#fff}',
    '.en-carte{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:8px;margin-bottom:18px}',
    '.en-card{display:flex;flex-direction:column;align-items:center;gap:8px;padding:14px 6px;border:2px solid #BCE0FF;border-radius:18px;background:var(--card,#fff);color:var(--navy);cursor:pointer}body.dark .en-card{background:#14234A;color:#fff;border-color:rgba(188,224,255,.25)}',
    '.en-card.on{border-color:#0075E3;box-shadow:0 0 0 2px #0075E3}.en-card b{font:800 14px/1.2 var(--font-body)}.en-card small{font:700 12px/1.3 var(--font-body);color:#0075E3}body.dark .en-card small{color:#8CC6FF}.en-card.prem small{color:#E63946}',
    '.en-bat{display:inline-flex;align-items:center;justify-content:center;min-width:48px;height:34px;padding:0 6px;border-radius:9px;background:#0075E3;color:#fff;font:900 16px var(--font-body);font-style:normal;position:relative}',
    '.en-bat::after{content:"";position:absolute;right:-5px;top:10px;width:4px;height:14px;border-radius:0 3px 3px 0;background:inherit}',
    '.en-bat.inf{background:linear-gradient(135deg,#0075E3,#E63946);font-size:22px}.en-bat.poca{background:linear-gradient(90deg,#3F9FF4 35%,#27406F 35%)}',
    '.en-cta{display:block;width:100%;min-height:54px;border:0;border-radius:27px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.en-no{display:block;width:100%;margin-top:6px;min-height:44px;border:0;background:none;color:#0075E3;font:800 14.5px var(--font-body);cursor:pointer}body.dark .en-no{color:#8CC6FF}'
  ].join('');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '#ngFesta{position:fixed;inset:0;z-index:10100;display:flex;align-items:center;justify-content:center;overflow:hidden;background:radial-gradient(circle at 50% 40%,#0B3C86,#00132B 70%);color:#fff;text-align:center;animation:ngfIn .25s ease both;transition:opacity .25s}#ngFesta.via{opacity:0}@keyframes ngfIn{from{opacity:0}to{opacity:1}}'
    + '.ngf-raggi{position:absolute;left:50%;top:38%;width:760px;height:760px;margin:-380px 0 0 -380px;background:repeating-conic-gradient(rgba(140,198,255,.12) 0 12deg,transparent 12deg 30deg);border-radius:50%;animation:ngfGira 16s linear infinite}@keyframes ngfGira{to{transform:rotate(360deg)}}'
    + '.ngf-c{position:relative;width:100%;max-width:340px;padding:24px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center}'
    + '.ngf-scudo{width:150px;margin-bottom:26px;animation:ngfScudo .75s cubic-bezier(.2,1.5,.4,1) both;filter:drop-shadow(0 0 26px rgba(140,198,255,.8))}.ngf-scudo svg{display:block;width:100%}@keyframes ngfScudo{0%{opacity:0;transform:translateY(-220px) scale(.5) rotate(-14deg)}100%{opacity:1;transform:none}}'
    + '.ngf-c small{font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.ngf-c h2{margin:8px 0 8px;font:800 24px/1.2 var(--font-display);color:#fff}.ngf-c p{margin:0;font:500 15px/1.45 var(--font-body);color:#D6E8FF}'
    + '.ngf-tre{display:flex;gap:10px;margin-top:26px}.ngf-tre i{width:26px;height:30px;background:rgba(255,255,255,.16);clip-path:polygon(50% 0,100% 16%,100% 58%,50% 100%,0 58%,0 16%)}.ngf-tre i.pieno{background:#8CC6FF}.ngf-tre i.nuovo{background:#fff;animation:ngfNuovo .6s .55s cubic-bezier(.2,1.6,.4,1) both}@keyframes ngfNuovo{0%{transform:scale(0)}100%{transform:scale(1)}}'
    + '.ngf-n{margin-top:10px;font:800 15px var(--font-body);color:#fff}.ngf-cta{width:100%;min-height:56px;margin-top:30px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 16px var(--font-body);cursor:pointer}';
  document.head.appendChild(st);
})();
