/* ===========================================================================================
   GLI ORIZZONTI — il piano scomposto, e la stima di arrivo che si muove

   Gary Keller, «The One Thing», capitolo «Goal Setting to the Now». Non è una lista di
   obiettivi: è una CATENA, e ogni anello nasce dalla domanda fatta sull'anello sopra.

        Un giorno        →  Qual è l'UNICA cosa che voglio fare, un giorno?
        Fra cinque anni  →  Basandomi su quella, qual è l'UNICA cosa che posso fare in 5 anni?
        Quest'anno       →  Basandomi su quella…
        Questo mese      →  …
        Questa settimana →  …
        Oggi             →  …
        Adesso           →  Qual è l'UNICA cosa che posso fare ADESSO?

   IL PUNTO DELLA CATENA è che «adesso» non è una cosa qualsiasi: è l'unica cosa che, fatta
   adesso, tira il filo fino al sogno. Un piano che salta gli anelli in mezzo è un desiderio con
   una to-do list sotto.

   DUE ANELLI L'APP LI HA GIÀ, e non li chiediamo di nuovo:
     · FRA CINQUE ANNI  — è il traguardo scelto davanti al Genio (fl_oracle.target).
     · OGGI             — è l'UNICA cosa della scheda START (stOne).
   Gli altri quattro si scrivono qui, e l'ultimo — «adesso» — non si scrive affatto: è la prima
   riga non spuntata del foglio di oggi. Quella la sa già l'app.

   ===========================================================================================
   LA STIMA DI ARRIVO

   Come su Google Maps: un orario che si muove da solo, e si muove perché cambiano i dati sotto,
   non perché qualcuno lo ritocca. Qui i dati sotto sono due, e sono entrambi misurati:

     · IL RITMO — quanti passi spunti al giorno, contati dalle date in cui li hai spuntati.
     · IL TRAFFICO — il ritmo degli ultimi sette giorni contro quello degli ultimi trenta. Se
       questa settimana vai più piano, l'arrivo si sposta in là: è l'ingorgo.

   Quello che NON faccio: inventare un ritmo quando non c'è niente da cui ricavarlo. Senza
   almeno un passo spuntato la stima non esiste, e lo dice — «ancora non lo so» è una risposta,
   un numero inventato no.
   =========================================================================================== */

const OZ_KEY = 'fl_orizzonti';

/* La catena, dall'alto in basso. `giorni` è quanto dura quell'orizzonte: serve a capire se un
   ritmo è abbastanza per arrivarci in tempo. */
const OZ_LIVELLI = [
  { k: 'ungiorno', ico: '🌌', nome: 'Un giorno',        giorni: 0,
    q: 'Qual è l\'UNICA cosa che vuoi fare, un giorno?',
    da: null },
  { k: 'cinque',   ico: '🔭', nome: 'Fra cinque anni',  giorni: 1825,
    q: 'Basandoti su quello, qual è l\'UNICA cosa che puoi fare nei prossimi cinque anni?',
    da: 'ungiorno' },
  { k: 'anno',     ico: '🗓️', nome: 'Quest\'anno',      giorni: 365,
    q: 'Basandoti su quello, qual è l\'UNICA cosa che puoi fare quest\'anno?',
    da: 'cinque' },
  { k: 'mese',     ico: '🌙', nome: 'Questo mese',      giorni: 30,
    q: 'Basandoti su quello, qual è l\'UNICA cosa che puoi fare questo mese?',
    da: 'anno' },
  { k: 'settimana', ico: '📆', nome: 'Questa settimana', giorni: 7,
    q: 'Basandoti su quello, qual è l\'UNICA cosa che puoi fare questa settimana?',
    da: 'mese' },
  { k: 'oggi',     ico: '🎯', nome: 'Oggi',             giorni: 1,
    q: 'Basandoti su quello, qual è l\'UNICA cosa che puoi fare oggi?',
    da: 'settimana' },
  { k: 'adesso',   ico: '⚡', nome: 'Adesso',           giorni: 0,
    q: 'E allora: qual è l\'UNICA cosa che puoi fare ADESSO?',
    da: 'oggi' }
];

/* ---------------------------------------------------------------------------------------
   Lo stato
   --------------------------------------------------------------------------------------- */

function ozLeggi(){
  try{ return JSON.parse(localStorage.getItem(OZ_KEY) || '{}') || {}; }catch(_){ return {}; }
}

function ozScrivi(s){
  try{ localStorage.setItem(OZ_KEY, JSON.stringify(s || {})); }catch(_){ }
}

/** Un anello: { testo, passi: [{t, fatto, il}] }. `il` è il giorno in cui è stato spuntato. */
function ozAnello(k){
  const s = ozLeggi();
  const a = s[k] || {};
  return { testo: a.testo || '', passi: Array.isArray(a.passi) ? a.passi : [] };
}

function ozSalvaAnello(k, a){
  const s = ozLeggi();
  /* 0.9.305: la frase di prima non si perde. Quando un obiettivo cambia (lo riscrive l'utente, o lo applica la
     roadmap del tuo agente personale), quella vecchia resta in __prima e si puo' rimettere dalla riga in modifica. */
  const prima = (s[k] && s[k].testo) || '', nuovo = (a && a.testo) || '';
  if (prima && nuovo !== prima){ s.__prima = s.__prima || {}; s.__prima[k] = { testo: prima, at: Date.now() }; }
  s[k] = { testo: nuovo, passi: (a && a.passi) || [] };
  ozScrivi(s);
}

function ozGiorno(d){
  const x = d ? new Date(d) : new Date();
  return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0');
}

/* ------------------------------------------------------------------ i due anelli già esistenti

   Non si chiedono di nuovo: chiederli una seconda volta vorrebbe dire che la prima risposta non
   contava, ed è il modo più rapido per far smettere di rispondere. */

function ozCinqueAnni(){
  const mio = ozAnello('cinque');
  if (mio.testo) return mio.testo;
  try{
    const last = (typeof orLast === 'function') ? orLast() : null;
    if (!last) return '';
    const t = (typeof OR_TARGETS !== 'undefined')
      ? OR_TARGETS.filter(function(x){ return x.id === last.target; })[0] : null;
    return t ? t.name : '';
  }catch(_){ return ''; }
}

function ozOggi(){
  const mio = ozAnello('oggi');
  if (mio.testo) return mio.testo;
  try{
    /* L'UNICA cosa della scheda START si chiama `task`, non `text`: il campo giusto lo decide
       chi l'ha scritta (stOneSave in start.js), non chi la legge. */
    const o = (typeof stOne === 'function') ? stOne() : null;
    return (o && o.task) ? String(o.task) : '';
  }catch(_){ return ''; }
}

/**
 * «Adesso»: la prima riga non spuntata del foglio di oggi.
 *
 * <p>Non si scrive e non si sceglie. È l'unico anello che l'app può rispondere da sola, ed è
 * anche l'unico che conta nel momento in cui lo si legge.</p>
 */
function ozAdesso(){
  try{
    const testo = (typeof stNotes === 'function') ? String(stNotes() || '') : '';
    const righe = testo.split('\n');
    for (let i = 0; i < righe.length; i++){
      const r = righe[i].trim();
      if (!r) continue;
      if (r.indexOf('☑') === 0) continue;              // ☑ già fatta
      const nuda = r.replace(/^[☐☑•]\s*/, '').replace(/^\d+\.\s+/, '').trim();
      if (nuda) return nuda;
    }
  }catch(_){ }
  return '';
}

function ozTesto(k){
  if (k === 'cinque') return ozCinqueAnni();
  if (k === 'oggi') return ozOggi();
  if (k === 'adesso') return ozAdesso();
  return ozAnello(k).testo;
}

/* ---------------------------------------------------------------------------------------
   IL RITMO E IL TRAFFICO

   Il ritmo si misura, non si stima: ogni passo spuntato porta con sé il giorno in cui è stato
   spuntato, e da quelle date esce quanti passi al giorno fa davvero questa persona.
   --------------------------------------------------------------------------------------- */

function ozTuttiIPassi(){
  const s = ozLeggi();
  const out = [];
  Object.keys(s).forEach(function(k){
    (s[k].passi || []).forEach(function(p){ if (p && p.fatto && p.il) out.push(p.il); });
  });
  return out;
}

/**
 * Passi al giorno, su una finestra di N giorni.
 *
 * <p>Si divide per i giorni ATTIVI, non per quelli del calendario: chi lavora tre giorni a
 * settimana e ne spunta sei ha un ritmo di due, non di 0,86. La finestra serve a capire se sta
 * andando più veloce o più piano di prima, ed è lì che nasce il «traffico».</p>
 */
function ozRitmo(finestra){
  const limite = ozGiorno(Date.now() - finestra * 86400000);
  const dentro = ozTuttiIPassi().filter(function(g){ return g >= limite; });
  if (!dentro.length) return 0;
  const giorniAttivi = new Set(dentro).size;
  return dentro.length / Math.max(1, giorniAttivi);
}

/**
 * Quanto spesso, dei giorni che ti sei giocato, ne hai usato uno.
 *
 * <p><b>La finestra parte da quando hai cominciato, non trenta giorni fa.</b> Prima si divideva
 * sempre per trenta, e per chi aveva cominciato l'altro ieri quel trenta era un giudizio su
 * ventotto giorni in cui l'app nemmeno lo conosceva: quattro passi in tre giorni — un ritmo
 * ottimo — diventavano «0,2 al giorno», e la mappa gli diceva che era irrimediabilmente in
 * ritardo. Il contrario esatto di quello che era vero, detto proprio nella settimana in cui uno
 * ha bisogno di sentirsi dire che sta andando bene.</p>
 *
 * <p>Il tetto della finestra resta: passato un mese, un mese è la memoria giusta.</p>
 */
function ozDensita(finestra){
  const limite = ozGiorno(Date.now() - finestra * 86400000);
  const dentro = ozTuttiIPassi().filter(function(g){ return g >= limite; }).sort();
  /* CONTANO ANCHE I GIORNI DI SOLA CONCENTRAZIONE.
     Un giorno con due sessioni chiuse e nessun passo spuntato non e' un giorno fermo: e' un
     giorno in cui si e' lavorato su un passo che non era ancora finito. Contarlo come vuoto
     faceva allontanare la data di arrivo proprio nei giorni migliori — e la data di arrivo e'
     la cosa che l'utente guarda per capire se quello che fa serve. */
  const sessioni = [];
  try{
    if (typeof serSessioniDi === 'function' && typeof serDayKey === 'function'){
      const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
      for (let i = 0; i < finestra; i++){
        const k = serDayKey(oggi.getTime() - i * 86400000);
        if (k >= limite && serSessioniDi(k) > 0) sessioni.push(k);
      }
    }
  }catch(_){ }
  if (!dentro.length && !sessioni.length) return 0;
  if (!dentro.length) dentro.push(sessioni.slice().sort()[0]);

  const distinti = new Set(dentro.concat(sessioni)).size;
  const primo = new Date(dentro[0] + 'T00:00:00');
  const oggi = new Date();
  oggi.setHours(0, 0, 0, 0);
  const osservati = Math.round((oggi.getTime() - primo.getTime()) / 86400000) + 1;

  return distinti / Math.max(1, Math.min(finestra, osservati));
}

/* ---------------------------------------------------------------------------------------
   LA SCADENZA

   Ogni orizzonte ce l'ha scritta nel nome, ed è l'informazione che rendeva possibile la domanda
   vera — «ce la faccio?» — senza che nessuno la usasse. «Questo mese» finisce l'ultimo del mese,
   non fra trenta giorni da oggi: se è il 28, ti restano tre giorni, e una stima che fingesse di
   averne trenta sarebbe rassicurante e falsa.

   «Un giorno» e «Adesso» non ne hanno, di proposito. Il primo è il sogno e non si mette in
   scadenza senza svuotarlo; il secondo dura quanto la prossima ora.
   --------------------------------------------------------------------------------------- */
function ozScadenza(k){
  const d = new Date();
  d.setHours(23, 59, 59, 0);
  if (k === 'oggi') return d.getTime();
  if (k === 'settimana'){
    // Domenica di questa settimana: la settimana italiana finisce lì, non fra sette giorni.
    const gg = (d.getDay() + 6) % 7;            // 0 = lunedì
    d.setDate(d.getDate() + (6 - gg));
    return d.getTime();
  }
  if (k === 'mese'){ d.setMonth(d.getMonth() + 1, 0); return d.getTime(); }
  if (k === 'anno'){ d.setMonth(11, 31); return d.getTime(); }
  if (k === 'cinque'){ d.setFullYear(d.getFullYear() + 5, 11, 31); return d.getTime(); }
  return 0;                                      // 'ungiorno', 'adesso': nessuna scadenza
}

/** Mezzanotte del giorno che contiene un istante: serve per contare GIORNI, non durate. */
function ozMezzanotte(ts){
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

/**
 * Quanti giorni mancano alla scadenza, contati sul calendario.
 *
 * <p>Non con una divisione arrotondata per eccesso: mercoledì pomeriggio mancano «4 giorni e 22
 * ore» a domenica sera, e un {@code Math.ceil} li chiama cinque. Con cinque, la stima atterrava
 * di lunedì — un giorno OLTRE la scadenza — e il semaforo diventava giallo su un piano che era
 * in orario per costruzione. Un errore di un giorno, in una schermata che esiste per dire se sei
 * in ritardo, non è un dettaglio.</p>
 */
function ozGiorniAllaScadenza(k){
  const sc = ozScadenza(k);
  if (!sc) return 0;
  return Math.max(1, Math.round((ozMezzanotte(sc) - ozMezzanotte(Date.now())) / 86400000));
}

/** Quante prove abbiamo: passi spuntati nell'ultimo mese, su tutti gli anelli. */
function ozProve(){
  const limite = ozGiorno(Date.now() - 30 * 86400000);
  return ozTuttiIPassi().filter(function(g){ return g >= limite; }).length;
}

/**
 * La stima di arrivo di un anello.
 *
 * <p>Torna {@code null} solo quando non c'è proprio niente da stimare — nessun passo scritto,
 * oppure tutti già fatti. In quei due casi la frase giusta non è una data: la scrive
 * {@link ozStimaTxt}, perché «non lo so» detto bene vale più di un numero inventato.</p>
 */
/* Quante prove servono perché il ritmo misurato conti quanto quello richiesto.
   Tre: sotto, un paio di giorni buoni per caso sposterebbero l'arrivo di mesi. */
const OZ_PESO_PRIOR = 3;

function ozStima(k){
  const a = (k === 'adesso') ? { passi: [] } : ozAnello(k);
  const passi = a.passi || [];
  const rimasti = passi.filter(function(p){ return !p.fatto; }).length;
  if (!rimasti) return null;

  /* IL RITMO RICHIESTO — quello che il piano pretende da te.
     Non ha bisogno di storia: dipende solo da quanti passi mancano e da quanto manca alla
     scadenza. È il motivo per cui adesso una stima esiste dal primo giorno. */
  const allaScadenza = ozGiorniAllaScadenza(k);
  const richiesto = allaScadenza > 0 ? rimasti / allaScadenza : 0;

  /* IL RITMO MISURATO — quello che fai davvero. Il lungo è la storia, il corto è la settimana
     che stai vivendo: la differenza fra i due è il traffico. */
  const lungo = ozRitmo(30);
  const corto = ozRitmo(7);
  const densita = Math.max(0.15, ozDensita(30));
  const ritmo = corto > 0 ? corto : lungo;
  const misurato = ritmo > 0 ? ritmo * densita : 0;

  /* LA MISCELA. Non un interruttore fra i due — una media pesata da quante prove ci sono.
     Con zero passi spuntati vince il richiesto (e lo diciamo: è un piano, non una previsione);
     dopo dieci passi il richiesto pesa quasi niente e parla solo quello che fai davvero.
     Un interruttore secco farebbe saltare l'arrivo di settimane il giorno del primo passo,
     e un orario che salta non lo guarda più nessuno. */
  const prove = ozProve();
  let alGiorno, fonte;
  if (misurato > 0 && richiesto > 0){
    alGiorno = (prove * misurato + OZ_PESO_PRIOR * richiesto) / (prove + OZ_PESO_PRIOR);
    fonte = prove >= OZ_PESO_PRIOR ? 'misurato' : 'misto';
  } else if (misurato > 0){
    alGiorno = misurato;
    fonte = 'misurato';
  } else if (richiesto > 0){
    alGiorno = richiesto;
    fonte = 'richiesto';
  } else {
    return null;                                 // nessuna scadenza e nessuna storia
  }

  const giorni = Math.max(1, Math.ceil(rimasti / alGiorno));
  const quando = new Date();
  quando.setHours(12, 0, 0, 0);
  quando.setDate(quando.getDate() + giorni);

  /* IL SEMAFORO GUARDA LA SCADENZA, NON IL PASSATO.
     Prima diceva «stai andando più piano di prima»: vero e inutile, perché più piano di prima
     può essere comunque in tempo, e più veloce di prima può essere comunque tardi. La domanda
     è una sola, ed è se ci arrivi. */
  const scadenza = ozScadenza(k);
  let semaforo = 'neutro';
  let margine = 0;
  if (scadenza){
    // Anche qui giorni di calendario: «arrivo domenica, scadenza domenica» deve fare zero.
    margine = Math.round((ozMezzanotte(scadenza) - ozMezzanotte(quando.getTime())) / 86400000);
    if (margine >= 0) semaforo = 'verde';
    else semaforo = margine > -Math.max(2, allaScadenza * 0.15) ? 'giallo' : 'rosso';
  }

  let traffico = 'stabile';
  if (lungo > 0 && corto > 0){
    if (corto > lungo * 1.2) traffico = 'veloce';
    else if (corto < lungo * 0.8) traffico = 'lento';
  }

  return { giorni: giorni, quando: quando.getTime(), rimasti: rimasti,
           alGiorno: alGiorno, traffico: traffico, fonte: fonte,
           scadenza: scadenza, margine: margine, semaforo: semaforo,
           richiesto: richiesto, misurato: misurato, prove: prove };
}

/** L'arrivo di ieri, per dire di quanto si è mosso. Si registra a ogni disegno. */
function ozRicorda(k, stima){
  const s = ozLeggi();
  s.__eta = s.__eta || {};
  const prima = s.__eta[k];
  const oggi = ozGiorno();
  if (!prima || prima.giorno !== oggi){
    s.__eta[k] = { giorno: oggi, quando: stima ? stima.quando : 0, prima: prima ? prima.quando : 0 };
    ozScrivi(s);
    return prima ? prima.quando : 0;
  }
  return prima.prima || 0;
}

function ozDataTxt(ts){
  const d = new Date(ts);
  const mesi = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
  return d.getDate() + ' ' + mesi[d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : '');
}

/**
 * Il ritmo detto come lo direbbe una persona.
 *
 * <p>«0,2 al giorno» e' il numero giusto e la frase sbagliata: chi la legge deve fare una
 * divisione in testa per capire che vuol dire «uno ogni cinque giorni», e nessuno la fa —
 * quindi il dato passa come un rumore invece che come la cosa che spiega la data. Sotto il
 * passo al giorno si gira la frazione; sopra, si dice quanti.</p>
 */
function ozRitmoTxt(alGiorno){
  if (!alGiorno || alGiorno <= 0) return 'ritmo ancora da capire';
  if (alGiorno >= 1.4){
    return 'circa ' + (Math.round(alGiorno * 10) / 10).toString().replace('.', ',') + ' passi al giorno';
  }
  /* Il gradino di mezzo esisteva ma partiva troppo in alto: 0,8 al giorno finiva in
     «uno ogni 2 giorni», che vuol dire 0,5 — cioè la frase diceva quasi la metà del numero da
     cui nasceva, e la data sopra non tornava con la spiegazione sotto. */
  if (alGiorno >= 0.75) return 'circa un passo al giorno';
  const ogni = Math.max(2, Math.round(1 / alGiorno));
  return 'un passo ogni ' + ogni + ' giorni';
}

/** Il primo orizzonte dell'utente con una scadenza e passi ancora da fare, dal piu' vicino. */
function ozProssimoOrizzonte(){
  const conData = OZ_LIVELLI
    .map(function(l){ return l.k; })
    .filter(function(k){ return ozScadenza(k) > 0; })
    .sort(function(a, b){ return ozScadenza(a) - ozScadenza(b); });
  for (let i = 0; i < conData.length; i++){
    const passi = ozAnello(conData[i]).passi || [];
    if (passi.length && passi.some(function(p){ return !p.fatto; })) return conData[i];
  }
  return '';
}

function ozGiorniTxt(n){
  n = Math.abs(n);
  return n + (n === 1 ? ' giorno' : ' giorni');
}

/**
 * La riga del navigatore.
 *
 * <p>Torna SEMPRE qualcosa per un orizzonte vero, anche quando non c'è una data: prima qui si
 * restituiva stringa vuota e la sezione spariva, che è il modo più sicuro di far credere che
 * una funzione non sia stata fatta. «Non lo so ancora, e serve questo perché lo sappia» è una
 * risposta; il silenzio no.</p>
 */
function ozStimaTxt(k){
  if (k === 'adesso') return '';

  /* «LE MOSSE DEL GENIO» È L'ORIZZONTE DI FABBRICA, E TACEVA.
     Le tre mosse che consiglia l'oracolo non hanno una scadenza e non si spuntano: una stima di
     arrivo lì sarebbe inventata. Ma restare muti sull'unico orizzonte che l'utente vede appena
     installa l'app vuol dire che, per lui, la funzione non esiste — ed è esattamente il motivo
     per cui mi è stato detto «non mostra nessun tempo di arrivo». Si dice perché non c'è, e da
     dove si ottiene. */
  if (k === 'genio'){
    /* IL GENIO NON HA UNA DATA SUA; LA STRADA SI'. Si prende il primo orizzonte dell'utente
       con passi ancora da fare e una scadenza, e si mostra il SUO arrivo: e' quello che il
       navigatore avrebbe dovuto fare da subito, invece di dire «non c'e'» guardando il tasto
       sbagliato. */
    const kk = ozProssimoOrizzonte();
    if (kk){
      const nome = (OZ_LIVELLI.filter(function(x){ return x.k === kk; })[0] || {}).nome || '';
      return '<p class="oz-eta-di">Prossima scadenza: <b>' + esc(nome) + '</b>'
        + (ozTesto(kk) ? ' · «' + esc(ozTesto(kk)) + '»' : '') + '</p>' + ozStimaTxt(kk);
    }
    return '<div class="oz-eta oz-eta-vuota">🧭 Le mosse del Genio non hanno una scadenza: sono '
      + 'consigli per adesso. L\'orario di arrivo nasce dai <b>tuoi</b> pezzi di strada. '
      + '<button type="button" class="oz-eta-btn" onclick="event.stopPropagation();ozOpen()">'
      + 'Scrivi il piano ›</button></div>';
  }

  const a = ozAnello(k);
  const passi = a.passi || [];
  const nome = (OZ_LIVELLI.filter(function(x){ return x.k === k; })[0] || {}).nome || 'questo pezzo di strada';

  if (!passi.length){
    return '<div class="oz-eta oz-eta-vuota">🧭 Nessun passo scritto qui: senza tappe non c\'è '
      + 'un arrivo da stimare. <button type="button" class="oz-eta-btn" '
      + 'onclick="event.stopPropagation();ozOpen()">Scrivi i passi ›</button></div>';
  }
  if (!passi.filter(function(p){ return !p.fatto; }).length){
    return '<div class="oz-eta oz-eta-fatto">🏁 <b>Arrivato.</b> Tutti i passi di questo pezzo '
      + 'di strada sono spuntati.</div>';
  }

  const s = ozStima(k);
  if (!s) return '';

  /* IL RITMO RICHIESTO NON E' UNA PREVISIONE, ED E' SCORRETTO SPACCIARLO PER TALE.
     Finché non c'è un passo spuntato, l'unica cosa vera che si può dire è quanto servirebbe.
     Detto così è utile; detto come «arrivo stimato» sarebbe una profezia che si autoavvera. */
  if (s.fonte === 'richiesto' && ozGiorniAllaScadenza(k) <= 1){
    return '<div class="oz-eta oz-eta-piano">🔵 <b>' + s.rimasti + (s.rimasti === 1 ? ' passo' : ' passi') + '</b> da fare oggi. <small>Spuntane uno e comincio a misurare il ritmo vero.</small></div>';
  }
  if (s.fonte === 'richiesto'){
    return '<div class="oz-eta oz-eta-piano">🔵 Per arrivare entro <b>' + ozDataTxt(s.scadenza)
      + '</b> ti serve <b>' + ozRitmoTxt(s.richiesto) + '</b>'
      + ' <small>· ' + s.rimasti + (s.rimasti === 1 ? ' passo' : ' passi') + ' in '
      + ozGiorniTxt(ozGiorniAllaScadenza(k)) + '. Spuntane uno e comincio a misurare il ritmo vero.</small></div>';
  }

  const prima = ozRicorda(k, s);
  let delta = '';
  if (prima){
    const gg = Math.round((s.quando - prima) / 86400000);
    if (gg < 0) delta = '<i class="oz-su">' + ozGiorniTxt(gg) + ' prima di ieri</i>';
    else if (gg > 0) delta = '<i class="oz-giu">' + ozGiorniTxt(gg) + ' dopo di ieri</i>';
  }

  const luce = s.semaforo === 'verde' ? '🟢' : (s.semaforo === 'giallo' ? '🟡' : (s.semaforo === 'rosso' ? '🔴' : '⚪'));
  let esito = '';
  if (s.scadenza){
    esito = s.margine >= 0
      ? '<small>· ' + ozGiorniTxt(s.margine) + ' di margine sulla scadenza</small>'
      : '<small>· <b>' + ozGiorniTxt(s.margine) + ' oltre</b> la scadenza del ' + ozDataTxt(s.scadenza) + '</small>';
  }

  return '<div class="oz-eta">' + luce + ' Arrivo stimato <b>' + ozDataTxt(s.quando) + '</b> '
    + esito
    + '<small>· ' + s.rimasti + (s.rimasti === 1 ? ' passo' : ' passi') + ', '
    /* Con poche prove il numero mostrato è in buona parte il ritmo che il piano PRETENDE, non
       quello che l'utente fa: chiamarlo «il tuo ritmo» sarebbe un complimento non guadagnato.
       Si dice quante prove ci sono, e chi legge sa quanto fidarsi. */
    + (s.fonte === 'misto'
        ? 'stima provvisoria (' + s.prove + (s.prove === 1 ? ' passo spuntato' : ' passi spuntati') + ' finora)'
        : ozRitmoTxt(s.alGiorno))
    + (s.traffico === 'lento' ? ' · questa settimana vai più piano' : '')
    + (s.traffico === 'veloce' ? ' · questa settimana vai più forte' : '') + '</small>'
    + delta + '</div>';
}

/* ---------------------------------------------------------------------------------------
   La pagina (0.9.305)

   Andrea, 28/10: "fa cagare, troppo confusionale, troppo testo, non si scansiona, nessuna emoji; l'itinerario
   proposto e' letteralmente una merda". Adesso e' UN pannello come "Le statistiche della partita"
   (partita-stats.js: si usano le sue classi .pst, .pst-kick, .pst-tabs, .pst-tab), con due schede:
     Orizzonti  : dal sogno, con la sua data, fino a oggi. Un obiettivo per riga, con la sua emoji, che si scrive
                  con un tocco. Sotto, "Fallo scrivere al mio agente": l'intervista del piano su misura
                  (intervista.js), con il messaggio pronto nel campo che parte solo quando lo manda lui.
     Itinerario : per ogni orizzonte, dal piu' vicino al sogno, le tappe dei capitoli della Roadmap
                  (sentiero-mappa.js) che cadono in quel tempo, una riga per tappa con ✅ fatta, 🔵 in corso,
                  un anello bianco da fare (non ⬜ o ⚪: su Windows si disegnano lilla, e il viola non e' del brand).
                  Le missioni dicono il passo del percorso su misura, quando c'e'.
   La card blu "Adesso" non c'e' piu': la cosa di oggi e' la riga "Oggi", e l'unico pulsante pieno e' quello
   dell'agente (OEOF). Niente gradiente: nel pannello non serve.

   LA CAUSA DEGLI ORIZZONTI DI TROPPO: la catena era una lista fissa (OZ_LIVELLI) disegnata tutta, senza guardare
   la durata scelta (sdDurata, "Entro quando vuoi arrivarci?"). Con un sogno a 6 mesi c'erano "Fra cinque anni" e
   "Quest'anno" anche quando finivano dopo il sogno, e lo stesso nella catena della Mappa (mappa-tab.js) e in
   "Il tuo percorso" (roadmap-livelli.js). Adesso un orizzonte c'e' solo se finisce prima della data del sogno
   (ozVisibile), e il primo orizzonte e' il sogno stesso. Quello che l'utente aveva scritto negli orizzonti
   nascosti non si perde: resta salvato e si rivede con "Mostra quello che hai scritto oltre la data del sogno".
   --------------------------------------------------------------------------------------- */

const OZ_ICO = { sogno: '🏁', cinque: '🔭', anno: '🏔️', mese: '🗓️', settimana: '📅', oggi: '🎯' };
const OZ_CATENA = ['cinque', 'anno', 'mese', 'settimana', 'oggi'];
const OZ_DOMANDA = {
  cinque: 'Qual è l’unica cosa da fare nei prossimi cinque anni per arrivare al sogno?',
  anno: 'Qual è l’unica cosa da fare quest’anno per avvicinarti al sogno?',
  mese: 'Qual è l’unica cosa da fare questo mese per avvicinarti al sogno?',
  settimana: 'Qual è l’unica cosa da fare questa settimana per avvicinarti al sogno?',
  oggi: 'Qual è l’unica cosa da fare oggi per avvicinarti al sogno?'
};
const OZ_TAB_KEY = 'fl_oz_scheda', OZ_BOZZA_KEY = 'fl_oz_bozza';
var OZ = { edit: '', bozza: '', fuoco: false, oltre: false, aperti: { oggi: true } };

/** La data del sogno: l'inizio del viaggio piu' la durata scelta (sdDurata), la stessa su cui finisce la Roadmap. */
function ozSognoFine(){
  let mesi = 12;
  try{ if (typeof sdDurata === 'function') mesi = +sdDurata().mesi || 12; }catch(_){ }
  let ini = 0;
  try{ const v = (typeof etaViaggio === 'function') ? etaViaggio() : null; if (v && v.inizio) ini = v.inizio; }catch(_){ }
  if (!ini){ try{ if (typeof serInizioViaggio === 'function') ini = serInizioViaggio(); }catch(_){ } }
  if (!ini) ini = Date.now();
  const d = new Date(ini);
  d.setMonth(d.getMonth() + mesi);
  d.setHours(23, 59, 59, 0);
  return d.getTime();
}
/** Un orizzonte c'e' solo se finisce prima del sogno. Oggi c'e' sempre. */
function ozVisibile(k){
  if (k === 'oggi' || k === 'adesso' || k === 'ungiorno') return true;
  const sc = ozScadenza(k);
  if (!sc) return true;
  return ozMezzanotte(sc) < ozMezzanotte(ozSognoFine());
}
function ozVisibili(){ return OZ_CATENA.filter(ozVisibile); }
function ozNome(k){ return (OZ_LIVELLI.filter(function(x){ return x.k === k; })[0] || {}).nome || ''; }
/** "28 aprile 2027", "31 dicembre": il mese per intero, l'anno solo se non e' questo. */
function ozDataLunga(ts){
  const d = new Date(ts);
  const mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  return d.getDate() + ' ' + mesi[d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : '');
}
/** "il 28 aprile 2027", "l’8 maggio": l'articolo giusto davanti al giorno. */
function ozIlData(ts){ const g = new Date(ts).getDate(); return (g === 1 || g === 8 || g === 11 ? 'l’' : 'il ') + ozDataLunga(ts); }
function ozFinoTxt(k){
  if (k === 'oggi') return '';
  if (k === 'settimana') return 'fino a domenica';
  const sc = ozScadenza(k);
  if (!sc) return '';
  const g = new Date(sc).getDate();
  return (g === 1 || g === 8 || g === 11 ? 'fino all’' : 'fino al ') + ozDataLunga(sc);
}
function ozSenzaMinuti(t){ return String(t || '').replace(/\s*\(\d+\s*min[^)]*\)\s*$/i, '').trim(); }
/** L'obiettivo da mostrare: quello scritto; per oggi l'UNICA cosa del foglio; se manca, il primo passo ancora aperto. */
function ozMostra(k){
  let t = (k === 'oggi') ? (ozOggi() || ozAdesso()) : ozAnello(k).testo;
  if (!t){ const p = (ozAnello(k).passi || []).filter(function(x){ return x && x.t && !x.fatto; })[0]; if (p) t = ozSenzaMinuti(p.t); }
  return t || '';
}
function ozRoadmapC(){ try{ return !!localStorage.getItem('fl_piano_fatto'); }catch(_){ return false; } }
function ozPrima(k){
  try{ const p = (ozLeggi().__prima || {})[k]; if (p && p.testo && p.testo !== ozAnello(k).testo) return p.testo; }catch(_){ }
  return '';
}

registerScreen('s-orizzonti',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button>'
  + '<b class="blk-title">Gli orizzonti</b></div>'
  + '<div id="ozBody"></div><div class="spacer"></div>', { back: 's-home' });

function ozOpen(){
  /* la bozza di un obiettivo lasciato a meta' torna com'era: chi scrive non perde niente */
  try{ const b = JSON.parse(localStorage.getItem(OZ_BOZZA_KEY) || 'null'); if (b && b.k && OZ_CATENA.indexOf(b.k) >= 0){ OZ.edit = b.k; OZ.bozza = String(b.v || ''); } }catch(_){ }
  goId('s-orizzonti');
  ozPaint();
}
function ozScheda(){ let v = ''; try{ v = localStorage.getItem(OZ_TAB_KEY) || ''; }catch(_){ } return v === 'itinerario' ? 'itinerario' : (v === 'periodi' && OZ.fuori) ? 'periodi' : 'orizzonti'; }
function ozOltre(si){ OZ.oltre = !!si; ozPaint(); }
function ozAperto(k, si){ OZ.aperti[k] = !!si; }
function ozVai(id){
  try{ localStorage.setItem(OZ_TAB_KEY, id); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  ozPaint();
}

/* IL PANNELLO SERVE DUE PAGINE (0.9.318). Andrea: "il blocco Orizzonti temporali nella replica di Notion deve essere uguale a quello
   della pagina degli orizzonti". Il pannello si scrive UNA volta (ozPannelloHtml); la replica di Notion gli presta un suo riquadro
   (flPiano.ozAggancia) e riceve lo stesso disegno, piu' la scheda Periodi con trimestri, mesi, settimane e giorni. */
function ozPannelloHtml(cur, conPeriodi){
  const tabs = [['orizzonti', 'Orizzonti', '⛰️'], ['itinerario', 'Percorso', '🧭']];
  if (conPeriodi) tabs.push(['periodi', 'Periodi', '🗓️']);
  let corpo = '';
  if (cur !== 'periodi') try{ corpo = cur === 'itinerario' ? ozItinerarioHtml() : ozOrizzontiHtml(); }catch(e){ corpo = '<p class="oz-it-vuoto">Questa scheda non si è caricata. Riapri la pagina.</p>'; }
  return '<p class="pst-kick">Dal sogno a oggi</p>'
    + '<div class="pst-tabs oz-tabs" role="tablist">' + tabs.map(function(t){
        return '<button type="button" role="tab" aria-selected="' + (t[0] === cur) + '" class="pst-tab oz-tab' + (t[0] === cur ? ' on' : '') + '" onclick="ozVai(\'' + t[0] + '\')">'
          + '<i class="oz-tem" aria-hidden="true">' + t[2] + '</i><span>' + t[1] + '</span></button>';
      }).join('') + '</div>'
    + (cur === 'periodi' ? '' : '<div class="oz-corpo">' + corpo + '</div>');
}
function ozPaint(){
  const fuori = OZ.fuori;
  const host = fuori ? fuori.el : document.getElementById('ozBody');
  if (!host) return;
  const cur = ozScheda();
  if (fuori){
    host.innerHTML = ozPannelloHtml(cur === 'periodi' ? 'orizzonti' : cur, false);
    try{ if (fuori.scheda) fuori.scheda(cur); }catch(_){ }
  } else {
    const c = cur === 'periodi' ? 'orizzonti' : cur;
    host.innerHTML = '<section class="pst oz-pan">' + ozPannelloHtml(c, false) + '</section>';
  }
  const campo = host.querySelector('#ozCampo');
  if (campo){
    ozCresci(campo);
    if (OZ.fuoco){ OZ.fuoco = false; try{ campo.focus(); campo.setSelectionRange(campo.value.length, campo.value.length); }catch(_){ } }
  }
}

/* ---------------------------------------------------------------- la scheda Orizzonti */
function ozOrizzontiHtml(){
  let sogno = '';
  try{ sogno = (typeof nvSogno === 'function' && nvSogno()) || ozAnello('ungiorno').testo || ''; }catch(_){ }
  const PENNA = '<svg class="oz-penna" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>';
  const riga = function(k, oltre){
    const nome = ozNome(k), fino = ozFinoTxt(k);
    if (OZ.edit === k){
      const prima = ozPrima(k);
      return '<li class="oz-o edit"><div class="oz-o-in"><span class="oz-em" aria-hidden="true">' + OZ_ICO[k] + '</span><div class="oz-o-t">'
        + '<small>' + nome + (fino ? ' · ' + fino : '') + '</small>'
        + '<textarea id="ozCampo" rows="2" placeholder="' + esc(OZ_DOMANDA[k]) + '" oninput="ozBozza(this)">' + esc(OZ.bozza) + '</textarea>'
        + (prima ? '<button type="button" class="oz-prima" onclick="ozRimetti(\'' + k + '\')">Prima c’era scritto "' + esc(prima) + '". Tocca qui per rimetterlo.</button>' : '')
        + '<div class="oz-ed-az"><button type="button" class="oz-annulla" onclick="ozAnnulla()">Annulla</button><button type="button" class="oz-salva" onclick="ozSalvaTesto(\'' + k + '\')">Salva</button></div>'
        + '</div></div></li>';
    }
    const t = ozMostra(k);
    const passi = ozAnello(k).passi || [];
    const fatti = passi.filter(function(p){ return p && p.fatto; }).length;
    return '<li class="oz-o' + (t ? '' : ' vuoto') + (oltre ? ' oltre' : '') + '"><button type="button" class="oz-o-in" onclick="ozScriviTesto(\'' + k + '\')">'
      + '<span class="oz-em" aria-hidden="true">' + OZ_ICO[k] + '</span>'
      + '<span class="oz-o-t"><small>' + nome + (fino ? ' · ' + fino : '') + '</small><b>' + (t ? esc(t) : 'Scrivi l’obiettivo') + '</b></span>'
      + (passi.length ? '<em class="oz-n">' + fatti + '/' + passi.length + '</em>' : (t ? '' : PENNA)) + '</button></li>';
  };
  let h = '<ol class="oz-cat">'
    + '<li class="oz-o sogno"><div class="oz-o-in"><span class="oz-em" aria-hidden="true">' + OZ_ICO.sogno + '</span>'
    + '<span class="oz-o-t"><small>Il sogno · entro ' + ozIlData(ozSognoFine()) + '</small><b>' + esc(sogno || 'Il tuo sogno') + '</b></span></div></li>'
    + ozVisibili().map(function(k){ return riga(k, false); }).join('')
    + '</ol>';
  /* gli orizzonti oltre la data del sogno con qualcosa di scritto: non si cancellano, si nascondono */
  const oltre = OZ_CATENA.filter(function(k){ const a = ozAnello(k); return !ozVisibile(k) && (a.testo || (a.passi || []).length); });
  if (oltre.length){
    h += OZ.oltre
      ? '<ol class="oz-cat oz-cat-oltre">' + oltre.map(function(k){ return riga(k, true); }).join('') + '</ol><button type="button" class="pst-link muto oz-oltre-btn" onclick="ozOltre(false)">Nascondi quello che va oltre la data del sogno</button>'
      : '<button type="button" class="pst-link muto oz-oltre-btn" onclick="ozOltre(true)">Mostra quello che hai scritto oltre la data del sogno</button>';
  }
  const c = ozRoadmapC();
  h += '<div class="oz-cta-box">'
    + (c
      ? '<button type="button" class="pst-cta2 oz-cta" onclick="ozAgente()">Fallo riscrivere al mio agente</button><p class="oz-cta-p">Quello che hai scritto tu resta salvato.</p>'
      : '<button type="button" class="pst-cta oz-cta" onclick="ozAgente()">Fallo scrivere al mio agente</button><p class="oz-cta-p">Ti fa qualche domanda, poi scrive un obiettivo per ogni orizzonte.</p>')
    + '</div>';
  return h;
}
function ozAgente(){
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  if (typeof ivApri === 'function'){ ivApri(); return; }
  if (typeof agNuovaConversazione === 'function') agNuovaConversazione('Costruisci il mio percorso su misura. Prima fammi le tue domande, una alla volta.');
}

/* ---------------------------------------------------------------- la scheda Itinerario

   Quali capitoli cadono in quale orizzonte. La Roadmap va a passo fisso: i capitoli 1-14 sono uno al giorno, poi
   uno a settimana (sentiero-mappa.js, sdCapitoliBase e sdCapitoloSettimana). Partendo dal capitolo in corso, la
   fine di ogni orizzonte dice fino a quale capitolo si arriva; gli orizzonti si prendono in ordine di fine, cosi'
   ogni capitolo sta in un orizzonte solo. Nei capitoli a settimana "Oggi" sono le tappe del giorno (tre, come la
   meta della giornata) e la settimana e' il capitolo intero. */
const OZ_IT_MAX = 3;
function ozCapAl(c, giorni){
  let x;
  if (c <= 14){ x = c + giorni; if (x > 14) x = 14 + Math.ceil((x - 14) / 7); }
  else { const dow = (new Date().getDay() + 6) % 7; x = c + Math.floor((dow + giorni) / 7); }
  return Math.min(sdUltimoCap(), x);
}
function ozGiorniA(k){ return Math.max(0, Math.round((ozMezzanotte(ozScadenza(k)) - ozMezzanotte(Date.now())) / 86400000)); }
function ozItPiano(){
  const cr = sdCorrente();
  const tutti = cr.tutti || [];
  const c = (cr.nodo && cr.nodo.cap) ? cr.nodo.cap.cap : ((tutti[tutti.length - 1] || {}).cap || {}).cap || 1;
  const out = [{ k: 'oggi', da: c, a: c, giorno: c > 14 }];
  let da = c > 14 ? c : c + 1;
  /* nell'ordine di Keller letto al contrario (settimana, mese, anno): se il mese finisce prima della domenica, le sue
     tappe sono gia' nella settimana e lo si dice, invece di mettere il mese sopra alla settimana */
  ozVisibili().filter(function(k){ return k !== 'oggi'; }).reverse()
    .forEach(function(k){ const a = ozCapAl(c, ozGiorniA(k)); out.push({ k: k, da: da, a: a }); if (a >= da) da = a + 1; });
  out.push({ k: 'sogno', da: da, a: sdUltimoCap() });
  return { c: c, cur: cr.nodo ? cr.nodo.id : '', voci: out };
}
/** Il nome di una tappa, senza scrivere niente: le missioni non ancora legate a un passo si mostrano con il passo che le
 *  aspetta (in ordine, come farebbe sdMissione), ma il legame vero lo fa la Roadmap quando ci arriva. */
function ozNomeTappa(nd, ctx){
  if (nd.tipo === 'mis' && typeof sdStradaMia === 'function' && !sdStradaMia()){
    const m = (typeof sdMisRm === 'function' ? sdMisRm() : {})[nd.id];
    if (m && m.t) return ozSenzaMinuti(sdAcc(m.t));
    if (!(nd.id in ctx.prev)) ctx.prev[nd.id] = ctx.liberi.length ? ctx.liberi.shift() : null;
    if (ctx.prev[nd.id]) return ozSenzaMinuti(ctx.prev[nd.id].t);
    const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : [];
    const x = l.length ? l[sdMisIndice(nd) % l.length] : null;
    return x && x.t ? ozSenzaMinuti(x.t) : 'Missione';
  }
  return sdNomeTappa(nd) || 'Tappa';
}
function ozItinerarioHtml(){
  if (typeof sdCorrente !== 'function' || typeof sdCapitoli !== 'function') return '<p class="oz-it-vuoto">Il percorso non è ancora pronto.</p>';
  const P = ozItPiano();
  const s = sdStato();
  const base = sdCapitoli();
  const cap = function(n){ return base.filter(function(x){ return x.cap === n; })[0] || (n > 14 ? sdCapitoloSettimana(n - 14) : null); };
  /* i passi del percorso su misura non ancora legati a una missione, nell'ordine in cui la Roadmap li prendera' */
  const ctx = { prev: {}, liberi: [] };
  try{
    const presi = {};
    const mm = sdMisRm(); Object.keys(mm).forEach(function(k){ const x = mm[k]; if (x) presi[x.k + ':' + x.j] = 1; });
    const pp = sdPrimoLeggi(); if (pp && pp.rm) presi[pp.rm.k + ':' + pp.rm.j] = 1;
    ctx.liberi = sdRoadmapPassi().filter(function(x){ return !presi[x.k + ':' + x.j]; });
  }catch(_){ }
  const oggi0 = ozMezzanotte(Date.now());
  const fatto = function(nd){ return sdNodoFatto(nd, s); };
  const rigaTappa = function(nd){
    const f = fatto(nd), ora = !f && nd.id === P.cur;
    const nome = esc(ozNomeTappa(nd, ctx));
    if (ora) return '<button type="button" class="oz-tp ora" onclick="ozVaiRoadmap()"><i aria-hidden="true">🔵</i><span>' + nome + '</span><u>Inizia</u></button>';
    return '<div class="oz-tp' + (f ? ' fatta' : '') + '"><i aria-hidden="true">' + (f ? '✅' : '<b class="oz-anello"></b>') + '</i><span>' + nome + '</span></div>';
  };
  const blocco = function(C, nodi){
    return '<div class="oz-cap"><p class="oz-cap-t">Capitolo ' + C.cap + ' · ' + esc(C.titolo || '') + '</p>' + nodi.map(rigaTappa).join('') + '</div>';
  };
  const voci = P.voci.map(function(v){
    let corpo = '', fatte = 0, tot = 0, sotto = '';
    const nCap = v.a - v.da + 1;
    if (v.giorno){
      /* nei capitoli a settimana, oggi: le tappe fatte oggi e le prossime, fino a tre */
      const C = cap(v.da);
      const nodi = C ? C.nodi.filter(function(nd){ return !sdSaltata(nd); }) : [];
      const oggiF = nodi.filter(function(nd){ return (s.fatti[nd.id] || 0) >= oggi0; });
      const aperte = nodi.filter(function(nd){ return !fatto(nd); }).slice(0, Math.max(1, 3 - oggiF.length));
      const scelte = nodi.filter(function(nd){ return oggiF.indexOf(nd) >= 0 || aperte.indexOf(nd) >= 0; });
      fatte = oggiF.length; tot = scelte.length;
      corpo = C ? blocco(C, scelte) : '';
      sotto = C ? 'Capitolo ' + C.cap : '';
    } else if (nCap <= 0){
      corpo = '<p class="oz-it-vuoto">Finisce prima dell’orizzonte sopra: le sue tappe sono già lì.</p>';
    } else {
      for (let n = v.da; n <= v.a; n++){
        const C = cap(n); if (!C) continue;
        const nodi = C.nodi.filter(function(nd){ return !sdSaltata(nd); });
        tot += nodi.length; fatte += nodi.filter(fatto).length;
        if (n - v.da < OZ_IT_MAX) corpo += blocco(C, nodi);
      }
      if (nCap > OZ_IT_MAX) corpo += '<p class="oz-it-piu">' + (nCap - OZ_IT_MAX === 1 ? 'C’è un altro capitolo: lo trovi' : 'Ci sono altri ' + (nCap - OZ_IT_MAX) + ' capitoli: li trovi') + ' nel percorso.</p><button type="button" class="pst-link oz-it-link" onclick="ozVaiRoadmap()">Apri il percorso</button>';
      sotto = nCap === 1 ? 'Capitolo ' + v.da : 'Capitoli ' + v.da + '-' + v.a;
    }
    const nome = v.k === 'sogno' ? 'Il sogno' : ozNome(v.k);
    const aperto = OZ.aperti[v.k] != null ? OZ.aperti[v.k] : v.k === 'oggi';
    /* in grande l'obiettivo dell'orizzonte (la sua "One Thing"), in piccolo dove sta nella Roadmap: le tappe sotto sono
       i passi che lo compongono */
    let obiettivo = '';
    try{ obiettivo = v.k === 'sogno' ? ((typeof nvSogno === 'function' && nvSogno()) || '') : ozMostra(v.k); }catch(_){ }
    /* 0.9.353, Andrea: "l'hai peggiorato: il pallino bianco con l'emoji torna a fianco del testo, e Hai fatto 0 tappe su 2 fra due
       righe non si capisce a quale periodo appartiene. Rivedila come il miglior UI designer, margini e spazi fanno schifo".
       Ogni periodo e' una card a se': i bordi della card dicono cosa appartiene a cosa (niente piu' righe divisorie in mezzo).
       Il pallino sta a sinistra, il testo a destra; quando si apre, le tappe e il conto rientrano esattamente sotto al titolo
       (stesso bordo sinistro del testo), e il conto chiude la card, dentro. */
    const pc = tot ? Math.round(fatte / tot * 100) : 0;
    return '<details class="oz-it oz-it2"' + (aperto ? ' open' : '') + ' ontoggle="ozAperto(\'' + v.k + '\',this.open)">'
      + '<summary><span class="oz-em" aria-hidden="true">' + OZ_ICO[v.k] + '</span><span class="oz-o-t"><small>' + nome + (sotto ? ' · ' + sotto : '') + '</small><b' + (obiettivo ? '' : ' class="vuoto"') + '>' + esc(obiettivo || (v.k === 'sogno' ? 'Il tuo sogno' : 'Obiettivo ancora da scrivere')) + '</b>'
      + (tot ? '<span class="oz-it-riga"><span class="oz-it-bar"><i style="--w:' + pc + '%"></i></span><b class="oz-it-pc">' + pc + '%</b></span>' : '')
      + '</span>'
      + '<svg class="oz-it-chev" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></summary>'
      + '<div class="oz-it-corpo">' + corpo + (tot ? '<p class="oz-it-conto">' + (fatte === 1 ? 'Hai fatto 1 tappa su ' : 'Hai fatto ' + fatte + ' tappe su ') + tot + (v.k === 'oggi' ? ' di oggi' : '') + '</p>' : '') + '</div></details>';
  });
  return '<div class="oz-its">' + voci.join('') + '</div>';
}
function ozVaiRoadmap(){
  goId('s-home');
  try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('rotta'); }catch(_){ }
  setTimeout(function(){
    try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n && n.scrollIntoView) n.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
  }, 450);
}

(function(){
  const st = document.createElement('style');
  /* Il contenitore, la riga delle linguette e il titolo sono quelli di partita-stats.js (.pst, .pst-kick, .pst-tabs,
     .pst-tab, .pst-cta, .pst-cta2, .pst-link); qui solo cio' che sta dentro. Scuro in tutti e due i temi. */
  st.textContent = [
    '#s-orizzonti .oz-pan{margin:6px 0 0}',
    '.oz-tabs{justify-content:center}',
    '.oz-tab{display:inline-flex;align-items:center;gap:7px}',
    /* 0.9.318, regola di Andrea: il pallino con l'emoji solo sulla scheda attiva */
    '.oz-tab:not(.on) .oz-tem{display:none}',
    '.oz-tem{flex:none;width:22px;height:22px;border-radius:11px;background:#fff;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:13px;line-height:1;letter-spacing:0}',
    '.oz-corpo{padding:0 16px}',
    '.oz-cat{position:relative;list-style:none;margin:0;padding:0}',
    '.oz-cat:not(.oz-cat-oltre)::before{content:"";position:absolute;left:24px;top:34px;bottom:34px;width:2px;border-radius:1px;background:rgba(140,198,255,.28)}',
    '.oz-o{position:relative}',
    '.oz-o-in{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;padding:18px 4px;border:0;background:none;color:#fff;text-align:left;font:inherit;cursor:pointer}',
    'div.oz-o-in{cursor:default}',
    '.oz-em{position:relative;z-index:1;flex:none;width:42px;height:42px;border-radius:21px;background:#fff;display:flex;align-items:center;justify-content:center;font-size:21px;line-height:1;box-shadow:0 4px 12px rgba(0,0,0,.28)}',
    '.oz-o-t{flex:1;min-width:0}',
    '.oz-o-t small{display:block;font:800 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.oz-o-t b{margin-top:3px;font:700 15.5px/1.35 var(--font-display);color:#fff;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:anywhere}',
    '.oz-o.vuoto .oz-o-t b,.oz-o-t b.vuoto{color:rgba(255,255,255,.5);font-weight:600}',
    '.oz-o.sogno .oz-o-t small{color:#FF8A94}',
    '.oz-o.oltre{opacity:.62}',
    /* 0.9.348: come nella roadmap del Genio: il periodo in azzurro, i passi in rosso */
    '.oz-n{flex:none;font:800 12px var(--font-body);font-style:normal;color:#BCE0FF;background:rgba(63,159,244,.22);padding:4px 9px;border-radius:99px;font-variant-numeric:tabular-nums}',
    '.oz-penna{flex:none;color:rgba(255,255,255,.5)}',
    '.oz-o.edit .oz-o-in{align-items:flex-start;cursor:default}',
    '.oz-o.edit textarea{display:block;width:100%;box-sizing:border-box;margin-top:8px;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#fff;font:500 15px/1.45 var(--font-body);resize:none;outline:none;min-height:72px}',
    '.oz-o.edit textarea::placeholder{color:rgba(255,255,255,.5)}.oz-o.edit textarea:focus{border-color:#3F9FF4}',
    '.oz-prima{display:block;margin-top:8px;border:0;background:none;padding:0;color:#8CC6FF;font:600 12.5px/1.45 var(--font-body);text-align:left;cursor:pointer}',
    '.oz-ed-az{display:flex;justify-content:flex-end;align-items:center;gap:8px;margin-top:10px}',
    '.oz-salva{border:0;border-radius:20px;background:#0075E3;color:#fff;font:800 14px var(--font-body);padding:10px 22px;cursor:pointer}',
    '.oz-annulla{border:0;background:none;color:#8CC6FF;font:700 14px var(--font-body);padding:10px 8px;cursor:pointer}',
    '.oz-oltre-btn{display:flex;margin:8px auto 0}',
    '.oz-cat-oltre{margin-top:6px;padding-top:6px;border-top:1px solid rgba(255,255,255,.08)}',
    '.oz-cta-box{display:flex;flex-direction:column;align-items:center;text-align:center;margin-top:16px;padding-top:20px;border-top:1px solid rgba(255,255,255,.1)}',
    '.oz-cta-box .pst-cta2{margin-top:0}',
    '.oz-cta-p{margin:10px 0 0;max-width:30ch;font:500 13px/1.45 var(--font-body);color:rgba(255,255,255,.65)}',
    /* Itinerario */
    '.oz-it{border-top:1px solid rgba(255,255,255,.08)}.oz-it:first-child{border-top:0}',
    '.oz-it-bar{display:block;height:7px;margin-top:10px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}.oz-it-bar i{display:block;height:100%;width:var(--w);min-width:0;border-radius:99px;background:linear-gradient(90deg,#0075E3,#8CC6FF);animation:ozBarra 1.1s cubic-bezier(.2,.7,.2,1) both}',
    '@keyframes ozBarra{from{width:0}to{width:var(--w)}}',
    '.oz-it-pct{display:block;margin-top:7px;font:600 12.5px var(--font-body);color:#BCE0FF}.oz-o-t .oz-it-pct b{display:inline;margin:0;font:800 12.5px var(--font-body);color:#fff;-webkit-line-clamp:unset}',
    '.oz-it>summary{list-style:none;display:flex;align-items:center;gap:14px;padding:18px 4px;cursor:pointer}.oz-it>summary::-webkit-details-marker{display:none}',
    '.oz-it-chev{flex:none;color:rgba(255,255,255,.6);transition:transform .2s}.oz-it[open] .oz-it-chev{transform:rotate(180deg)}',
    '.oz-it-corpo{padding:0 4px 20px}',
    '.oz-it-k{display:flex!important;align-items:center;gap:8px;margin-bottom:6px}.oz-em.mini{width:26px;height:26px;border-radius:13px;font-size:14px;box-shadow:0 2px 6px rgba(0,0,0,.25)}',
    '.oz-it-riga{display:flex;align-items:center;gap:10px;margin-top:10px}.oz-it-riga .oz-it-bar{flex:1;margin:0}.oz-o-t .oz-it-pc{flex:none;display:inline;margin:0;font:800 13px var(--font-body);color:#fff;-webkit-line-clamp:unset}',
    '.oz-it-conto{margin:14px 0 0;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);font:600 13px var(--font-body);color:#BCE0FF}',
    /* 0.9.353: le card dell'Itinerario */
    '.oz-its{display:flex;flex-direction:column;gap:12px;padding:4px 0 6px}',
    '.oz-it.oz-it2{border:1px solid rgba(140,198,255,.16);border-radius:18px;background:rgba(255,255,255,.05);transition:background .2s}.oz-it.oz-it2[open]{background:rgba(255,255,255,.09);border-color:rgba(140,198,255,.28)}',
    '.oz-it2 > summary{align-items:flex-start;gap:14px;padding:16px 14px 16px 14px}.oz-it2 .oz-em{width:40px;height:40px;font-size:20px;margin-top:2px}',
    '.oz-it2 .oz-o-t small{margin-bottom:6px}.oz-it2 .oz-o-t b{line-height:1.3}.oz-it2 .oz-it-chev{margin-top:10px}',
    '.oz-it2 .oz-it-riga{margin-top:12px}',
    '.oz-it2 > .oz-it-corpo{padding:2px 14px 16px 68px}',
    '.oz-it2 .oz-it-conto{margin:16px 0 0;padding:0;border:0;font:600 12.5px var(--font-body);color:#8CC6FF}',
    '.oz-it2 .oz-cap+.oz-cap{margin-top:16px}',
    '.oz-cap+.oz-cap{margin-top:12px}',
    '.oz-cap-t{margin:0 0 4px;font:800 11px/1.4 var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}',
    '.oz-tp{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;padding:7px 0;border:0;background:none;text-align:left;color:rgba(255,255,255,.88);font:500 14px/1.35 var(--font-body)}',
    '.oz-tp i{flex:none;width:20px;font-style:normal;font-size:15px;line-height:1;text-align:center;display:flex;justify-content:center}',
    '.oz-anello{display:block;width:12px;height:12px;border-radius:50%;border:2px solid rgba(255,255,255,.7)}',
    '.oz-tp span{flex:1;min-width:0}',
    '.oz-tp.fatta span{color:rgba(255,255,255,.5);text-decoration:line-through}',
    '.oz-tp.ora{cursor:pointer}.oz-tp.ora span{color:#fff;font-weight:700}',
    '.oz-tp u{flex:none;text-decoration:none;font:800 12px var(--font-body);color:#fff;background:#0075E3;border-radius:99px;padding:6px 12px}',
    '.oz-it-vuoto,.oz-it-piu{margin:6px 0 0;font:500 13px/1.45 var(--font-body);color:rgba(255,255,255,.62)}',
    '.oz-it-link{margin-top:6px;padding:6px 0}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   Le mosse
   --------------------------------------------------------------------------------------- */

/* Scrivere un obiettivo (0.9.305): non piu' con il prompt() del browser ma nella riga stessa, con Salva e Annulla.
   La bozza si salva mentre si scrive (fl_oz_bozza): chi esce a meta' la ritrova. Senza limite di caratteri. */
function ozScriviTesto(k){
  if (OZ_CATENA.indexOf(k) < 0) return;
  OZ.edit = k;
  OZ.bozza = ozAnello(k).testo || (k === 'oggi' ? ozOggi() : '');
  OZ.fuoco = true;
  if (!ozVisibile(k)) OZ.oltre = true;
  try{ localStorage.setItem(OZ_TAB_KEY, 'orizzonti'); }catch(_){ }
  ozPaint();
}
function ozCresci(t){ try{ t.style.height = 'auto'; t.style.height = Math.max(72, t.scrollHeight + 2) + 'px'; }catch(_){ } }
function ozBozza(t){
  OZ.bozza = t.value;
  ozCresci(t);
  try{ localStorage.setItem(OZ_BOZZA_KEY, JSON.stringify({ k: OZ.edit, v: t.value, at: Date.now() })); }catch(_){ }
}
function ozBozzaVia(){ try{ localStorage.removeItem(OZ_BOZZA_KEY); }catch(_){ } }
function ozRimetti(k){
  const p = ozPrima(k); if (!p) return;
  OZ.bozza = p; OZ.fuoco = true;
  try{ localStorage.setItem(OZ_BOZZA_KEY, JSON.stringify({ k: k, v: p, at: Date.now() })); }catch(_){ }
  ozPaint();
}
function ozAnnulla(){ OZ.edit = ''; OZ.bozza = ''; ozBozzaVia(); ozPaint(); }
function ozSalvaTesto(k){
  const t = (OZ.fuori ? OZ.fuori.el : document).querySelector('#ozCampo');
  const v = String(t ? t.value : (OZ.bozza || '')).trim();
  const a = ozAnello(k);
  a.testo = v;
  ozSalvaAnello(k, a);
  /* «Oggi» è l'UNICA cosa della scheda START: scriverla qui deve scriverla anche lì, o le due
     pagine racconterebbero due priorità diverse per lo stesso giorno. */
  if (k === 'oggi' && v && typeof stOneSave === 'function'){
    try{
      const o = (typeof stOne === 'function' && stOne()) || { done: false, rest: [] };
      o.task = v;
      if (!o.forDay) o.forDay = ozGiorno();
      stOneSave(o);
      if (typeof stPaint === 'function') stPaint();
    }catch(_){ }
  }
  OZ.edit = ''; OZ.bozza = ''; ozBozzaVia();
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  try{ if (typeof etaEvento === 'function') etaEvento('roadmap', {}); }catch(_){ }
  try{ if (typeof mpPaint === 'function') mpPaint(); }catch(_){ }
  ozPaint();
}

function ozAggiungi(k){
  const v = prompt('Un passo verso «' + (ozTesto(k) || OZ_LIVELLI.filter(function(x){ return x.k === k; })[0].nome) + '»:', '');
  if (v === null) return;
  const t = String(v).trim().slice(0, 90);
  if (!t) return;
  const a = ozAnello(k);
  a.passi.push({ t: t, fatto: false, il: '' });
  ozSalvaAnello(k, a);
  ozPaint();
}

/**
 * Spunta un passo, e da lì si muove tutto.
 *
 * <p>Il giorno della spunta viene scritto accanto al passo: è l'unico dato da cui esce il
 * ritmo, e quindi l'unico da cui esce la stima di arrivo. Senza quella data la stima sarebbe
 * un'opinione.</p>
 */
function ozSpunta(k, j){
  const a = ozAnello(k);
  const p = a.passi[j];
  if (!p) return;
  p.fatto = !p.fatto;
  p.il = p.fatto ? ozGiorno() : '';
  ozSalvaAnello(k, a);
  ozPaint();
  try{ if (typeof mpPaint === 'function') mpPaint(); }catch(_){ }
  if (p.fatto && typeof toast === 'function'){
    const s = ozStima(k);
    toast(s ? 'Arrivo aggiornato: ' + ozDataTxt(s.quando) : 'Fatto');
  }
}

function ozMenu(k, ev){
  if (ev) ev.stopPropagation();
  ozMenuClose();
  const host = document.querySelector('.oz-lv .oz-corpo');
  const box = ev && ev.target ? ev.target.closest('.oz-corpo') : host;
  if (!box) return;
  const veil = document.createElement('div');
  veil.id = 'ozVeil';
  veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); ozMenuClose(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(veil);
  const m = document.createElement('div');
  m.className = 'arb-menu';
  m.id = 'ozMenu';
  m.innerHTML = '<p class="arb-mtit">Questo orizzonte</p>'
    + '<button type="button" onclick="ozMenuClose();ozScriviTesto(\'' + k + '\')">Riscrivi la frase</button>'
    + '<button type="button" onclick="ozMenuClose();ozAggiungi(\'' + k + '\')">Aggiungi un passo</button>'
    + '<button type="button" onclick="ozPulisci(\'' + k + '\')">Togli i passi fatti</button>';
  box.appendChild(m);
  flMenuFissa(m, (ev && ev.currentTarget) || box);
}

function ozMenuClose(){
  const m = document.getElementById('ozMenu');
  if (m) m.remove();
  const v = document.getElementById('ozVeil');
  if (v) v.remove();
}

function ozPulisci(k){
  const a = ozAnello(k);
  a.passi = (a.passi || []).filter(function(p){ return !p.fatto; });
  ozSalvaAnello(k, a);
  ozMenuClose();
  ozPaint();
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */

(function ozStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.oz-lv{display:flex;gap:12px;align-items:stretch}',
    /* L'asta verticale che unisce gli anelli: senza, sono sette schede; con, è una catena. */
    '.oz-asta{flex:0 0 12px;display:flex;justify-content:center;padding-top:34px}',
    '.oz-asta i{display:block;width:2px;flex:1;background:var(--line);border-radius:2px}',
    '.oz-corpo{position:relative;flex:1;min-width:0;padding-bottom:20px}',
    '.oz-top{display:flex;align-items:center;gap:9px}',
    '.oz-ico{font-size:19px;line-height:1}',
    '.oz-top b{flex:1;font:800 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}',
    '.oz-top em{font:700 9.5px var(--font-body);font-style:normal;letter-spacing:.08em;',
      'text-transform:uppercase;color:var(--blue);background:rgba(0,117,227,.12);',
      'border-radius:99px;padding:3px 8px}',
    '.oz-dots{width:28px;height:28px;border:0;border-radius:50%;background:transparent;',
      'color:var(--faint);font:800 15px var(--font-body);cursor:pointer;line-height:1}',
    '.oz-testo{margin:8px 0 0;font:700 16px/1.45 var(--font-display);color:var(--navy);cursor:pointer}',
    'body.dark .oz-testo{color:#fff}',
    '.oz-chiedi{display:block;width:100%;margin-top:8px;text-align:left;border:1.5px dashed var(--line);',
      'border-radius:14px;background:transparent;padding:13px 14px;cursor:pointer;',
      'font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.oz-nota{margin:8px 0 0;font:500 11.5px var(--font-body);color:var(--faint)}',
    '.oz-passi{display:flex;flex-direction:column;gap:6px;margin-top:12px}',
    '.oz-passo{display:flex;align-items:flex-start;gap:9px;width:100%;text-align:left;border:0;',
      'background:transparent;padding:4px 0;cursor:pointer}',
    '.oz-passo i{font-style:normal;font-size:15px;line-height:1.4;color:var(--blue)}',
    '.oz-passo span{flex:1;font:500 13.5px/1.45 var(--font-body);color:var(--navy)}',
    'body.dark .oz-passo span{color:#fff}',
    '.oz-passo.fatto span{text-decoration:line-through;color:var(--faint)}',
    '.oz-fondo{display:flex;align-items:center;gap:10px;margin-top:10px}',
    '.oz-fondo small{flex:1;font:700 11px var(--font-body);color:var(--faint)}',
    '.oz-add{border:0;background:transparent;color:var(--blue);font:700 12px var(--font-body);cursor:pointer;padding:0}',
    /* LA STIMA: una riga sola, con il semaforo del traffico davanti. */
    '.oz-eta{margin-top:10px;font:600 12px/1.6 var(--font-body);color:var(--muted)}',
    '.oz-eta b{color:var(--navy);font-weight:800}',
    'body.dark .oz-eta b{color:#fff}',
    '.oz-eta small{font-weight:500;color:var(--faint)}',
    '.oz-eta i{display:block;font-style:normal;font-weight:800;font-size:11.5px;margin-top:2px}',
    '.oz-eta .oz-su{color:#1B9E6A}',
    '.oz-eta .oz-giu{color:#E5515F}',
    /* LE TRE RISPOSTE CHE NON SONO UNA DATA.
       Vuota = non hai ancora scritto i passi. Piano = so cosa servirebbe ma non ancora cosa fai.
       Fatto = sei arrivato. Erano tutte e tre «niente» prima, cioe' la sezione spariva. */
    '.oz-eta-vuota,.oz-eta-piano,.oz-eta-fatto{display:block;margin-top:12px;padding:11px 13px;',
      'border-radius:13px;line-height:1.6}',
    '.oz-eta-vuota{background:rgba(255,255,255,.06);color:rgba(200,218,242,.88)}',
    '.oz-eta-piano{background:rgba(0,117,227,.14);color:rgba(214,232,255,.95)}',
    '.oz-eta-fatto{background:rgba(27,158,106,.16);color:#9CE9C6}',
    '.oz-eta-btn{display:inline-block;margin-top:8px;border:0;border-radius:99px;padding:7px 14px;',
      'background:#0075E3;color:#fff;font:800 11.5px var(--font-body);cursor:pointer}',
    /* Dentro alla scheda della mappa il fondo e' gia' scuro; dentro alla pagina Orizzonti,
       che e' chiara, gli stessi tre riquadri hanno bisogno dell'inchiostro opposto. */
    '#s-orizzonti .oz-eta-vuota{background:var(--soft,#EEF2F8);color:var(--navy)}',
    '#s-orizzonti .oz-eta-piano{background:rgba(0,117,227,.10);color:#0B3E77}',
    '#s-orizzonti .oz-eta-fatto{background:rgba(27,158,106,.12);color:#12694A}',
    'body.dark .oz-eta .oz-su{color:#8CF0C8}',
    'body.dark .oz-eta .oz-giu{color:#FF8A9B}',
    '.oz-lv.adesso .oz-corpo{background:linear-gradient(135deg,rgba(0,117,227,.12),rgba(0,117,227,.04));',
      'border:1px solid rgba(0,117,227,.3);border-radius:18px;padding:14px 16px 16px;margin-top:4px}',
    '.oz-lv.adesso .oz-testo{font-size:19px;cursor:default}',
    '.oz-lv.vuoto .oz-ico{opacity:.45}'
  ].join('\n');
  document.head.appendChild(st);
})();
