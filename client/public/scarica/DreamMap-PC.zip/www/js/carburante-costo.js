/* =========================================================================================
   QUANTO CARBURANTE TI E' COSTATO OGGI (0.9.317)

   Andrea: "la bolla apre la pagina della dopamina, che dice cose generiche e non specifica quali app hanno fatto scattare la
   dispersione. '11 cambi d'app' non vuol dire niente. Deve aprire la stessa schermata del carburante della schermata di
   blocco, con il tachimetro, e dire quali app nello specifico. L'utente deve capire le cause e cosa smettere di fare".

   ccApri() e' la schermata scura che apre la bolla (la nativa e quella dentro all'app). ccListeHtml() sono le stesse due liste, e
   stanno anche nella pagina Dopamina. Tutti i numeri vengono dal calcolo vero di oggi (dpCalcola, DP.dett).
   ========================================================================================= */
function ccNomi(t){ return (typeof dmNomiNelTesto === 'function') ? dmNomiNelTesto(t) : t; }
function ccNum(v){ return (Math.round(v * 10) / 10).toFixed(1).replace('.', ','); }
function ccOra(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function ccMin(m){ return (typeof frMinuti === 'function') ? frMinuti(m) : Math.round(m) + ' min'; }
/** Le app di oggi, dalla piu' costosa: i minuti, le aperture, il costo. Solo le app che pesano sulla riserva. */
function ccApp(d){
  const per = {};
  (d.grani || []).forEach(function(g){
    if (!(g.di >= 0.2) || (typeof dmNonConta === 'function' && dmNonConta(g.p))) return;
    const ms = g.ms != null ? g.ms : (g.e - g.s);
    if (!(ms > 0)) return;
    const n = (typeof dmNomeBello === 'function') ? dmNomeBello(g.l || g.p) : (g.l || g.p);
    if (!per[n]) per[n] = { nome: n, p: g.p, ms: 0, ap: 0, di: 0, dev: g.dev };
    per[n].ms += ms; per[n].ap++; per[n].di = Math.max(per[n].di, g.di);
  });
  const l = Object.keys(per).map(function(k){
    const x = per[k], min = x.ms / 60000;
    x.min = min;
    x.costo = (typeof frCarbCosto === 'function' ? frCarbCosto(min) : min * 0.06) * Math.min(1, x.di * 1.2);
    return x;
  }).filter(function(x){ return x.min >= 1; });
  /* 0.9.337, Andrea: "in alto -0,1, in Cosa e' successo -0,1, e nelle app WhatsApp circa -1,1: sembra un bug". La lista delle app usava
     una stima per minuto, il resto il calcolo vero di oggi. Adesso le app si dividono quello che il calcolo vero ha tolto davvero oggi
     (le voci con il segno meno), in proporzione al loro peso: la somma delle app non supera mai quello che e' successo. */
  const speso = ((d.ris && d.ris.voci) || []).reduce(function(t, v){ return t + (v && v.delta < 0 && v.tipo !== 'sonno' ? -v.delta : 0); }, 0);
  const stima = l.reduce(function(t, x){ return t + x.costo; }, 0);
  l.forEach(function(x){ x.costo = stima > 0 ? x.costo / stima * speso : 0; });
  return l.filter(function(x){ return x.costo >= 0.05; }).sort(function(a, b){ return b.costo - a.costo; });
}
/* DOVE ARRIVI STASERA (0.9.319). Andrea: "e' a 50 e dice che se continui cosi' arrivi a 55: sembra un bug". Prima si allungava il saldo della
   giornata, recuperi compresi: chi aveva dormito poco e poi posato il telefono "saliva" anche mentre le app gli costavano carburante.
   La domanda vera e' un'altra: quanto ti resta se continui a spendere cosi'. Si contano solo le spese di oggi, per le ore che restano. */
function ccProiezione(d){
  const ora = new Date(), ore = (ora.getTime() - d.from) / 3600000;
  if (ore < 1 || ora.getHours() >= 23) return null;
  const speso = ((d.ris && d.ris.voci) || []).reduce(function(t, v){ return t + (v.delta < 0 ? -v.delta : 0); }, 0);
  if (!(speso > 0.05)) return null;
  const restano = 23 - (ora.getHours() + ora.getMinutes() / 60);
  const fine = Math.max(0, d.riserva - speso / ore * restano);
  return fine < d.riserva - 0.05 ? { fine: fine } : null;
}
function ccVoci(d){
  const no = { minori: 1, tempo: 1, spunta: 1 };
  return ((d.ris && d.ris.voci) || []).filter(function(v){ return !no[v.tipo] && Math.abs(v.delta) >= 0.05; }).slice().sort(function(a, b){ return b.t - a.t; }).slice(0, 12);
}
function ccListeHtml(d, scuro, soloApp, schede){
  const app = ccApp(d).slice(0, 5), voci = ccVoci(d);
  const riga = function(t, s, val, buono){ return '<li><div><b>' + dpEsc(typeof dmNomiNelTesto === 'function' ? dmNomiNelTesto(t) : t) + '</b><small>' + dpEsc(s) + '</small></div><em class="' + (buono ? 'su' : 'giu') + '">' + val + '</em></li>'; };
  const pz1 = schede ? '<div class="cc-sch" data-cc="app">' : '', pz2 = schede ? '</div><div class="cc-sch" data-cc="mosse" hidden>' : '', pz3 = schede ? '</div>' : '';
  return '<div class="cc-liste' + (scuro ? ' scuro' : '') + '">' + pz1
    + (app.length ? '<h3>Le app che ti sono costate di più oggi</h3><ul>' + app.map(function(x){
        return riga(x.nome, ccMin(x.min) + ' in ' + x.ap + (x.ap === 1 ? ' volta' : ' volte'), 'circa −' + ccNum(x.costo), false);
      }).join('') + '</ul>' : '<h3>Le app di oggi</h3><p class="cc-vuoto">Oggi nessuna app ti è costata carburante.</p>')
    + pz2
    + (voci.length && !soloApp ? '<h3>Cosa ha spostato il tuo carburante oggi</h3><ul>' + voci.map(function(v){
        const d0 = v.delta;
        return riga(v.tipo === 'dispersione' ? v.nota : (v.l || ''), ccOra(v.t) + (v.tipo !== 'dispersione' && v.nota ? ' · ' + String(v.nota).split(' · ')[0] : ''), (d0 < 0 ? '−' : '+') + ccNum(Math.abs(d0)), d0 > 0);
      }).join('') + '</ul>' : (schede ? '<h3>Cosa ha spostato il tuo carburante oggi</h3><p class="cc-vuoto">Oggi il tuo carburante non si è ancora mosso.</p>' : ''))
    + pz3 + '</div>';
}
function ccTab(k, muto){
  const w = document.getElementById('ccVelo'); if (!w) return;
  w.querySelectorAll('.cc-tab').forEach(function(b){ const on = b.getAttribute('data-k') === k; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
  w.querySelectorAll('.cc-sch').forEach(function(s){ s.hidden = s.getAttribute('data-cc') !== k; });
  if (!muto) try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
}
/* 0.9.367, Andrea: "tutto in una schermata e' overwhelming: il focus si perde dal tachimetro. E '6 salti' che cazzo vuol dire?
   Mostragli da quale app a quale e' passato, e il prezzo del task switching". Ora e' una storia a slide, una cosa per slide:
   1. il tachimetro e il numero (con l'ultima cosa che l'ha mosso);
   2. i salti, disegnati app per app, e cosa costano (solo se oggi c'e' stata attenzione divisa);
   3. dove arrivi stasera, se continui cosi';
   4. cosa e' successo, la cronologia;
   5. le app che ti sono costate di piu', con il pulsante per bloccare la prima. */
function ccSalti(d){
  const tutte = ccVoci(d).filter(function(v){ return v.tipo === 'dispersione'; });
  const w = tutte[0]; if (!w) return null;
  const da = w.s || (w.t - 20 * 60000), a = w.t;
  const seq = [];
  (d.grani || []).filter(function(g){ return g.s >= da - 1000 && g.s <= a + 1000; }).sort(function(x, y){ return x.s - y.s; }).forEach(function(g){
    const n = (typeof dmNomeBello === 'function') ? dmNomeBello(g.l || g.p) : (g.l || g.p);
    if (!n || (seq.length && seq[seq.length - 1].n === n)) return;
    seq.push({ n: n, t: g.s });
  });
  const m = String(w.nota || '').match(/(\d+)\s+salti/);
  return { n: m ? +m[1] : Math.max(1, seq.length - 1), seq: seq.slice(0, 9), piu: Math.max(0, seq.length - 9), da: da, a: a, delta: w.delta, volte: tutte.length };
}
function ccSlide(html, cls){ return '<section class="cc-sl' + (cls ? ' ' + cls : '') + '"><div class="cc-sl-in">' + html + '</div></section>'; }
function ccVai(i){
  const c = document.querySelector('#ccVelo .cc-car'); if (!c) return;
  try{ c.scrollTo({ left: i * c.clientWidth, behavior: 'smooth' }); }catch(_){ c.scrollLeft = i * c.clientWidth; }
}
function ccScorri(c){
  const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth));
  const w = document.getElementById('ccVelo'); if (!w) return;
  w.querySelectorAll('.cc-dots i').forEach(function(x, k){ x.classList.toggle('on', k === i); });
  const n = w.querySelectorAll('.cc-sl').length, av = w.querySelector('.cc-avanti');
  if (av) av.hidden = i >= n - 1;
}
async function ccApri(){
  let w = document.getElementById('ccVelo');
  if (!w){ w = document.createElement('div'); w.id = 'ccVelo'; w.className = 'cc'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.innerHTML = '<div class="cc-in"><p class="cc-kick">Il tuo carburante</p><p class="cc-attesa">Sto guardando la tua giornata…</p></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  let d = null; try{ d = await dpCalcola(); }catch(_){ d = null; }
  if (!document.getElementById('ccVelo') || w.hidden) return;
  if (!d || d.senzaDati){
    w.innerHTML = '<div class="cc-in"><button type="button" class="cc-x" onclick="ccChiudi()" aria-label="Chiudi">✕</button><p class="cc-kick">Il tuo carburante</p><h2>Mi serve l’accesso ai dati di utilizzo</h2><p class="cc-s">Senza, non posso dirti quali app ti costano carburante.</p></div>';
    return;
  }
  const L = d.riserva, col = (typeof dpFascia === 'function') ? dpFascia(L) : '#fff';
  const banda = L >= 56 ? 'Alta' : L >= 44 ? 'Base' : 'Bassa';
  const ultima = ccVoci(d)[0];
  const pr = ccProiezione(d), top = ccApp(d)[0], sa = ccSalti(d);
  const sl = [];
  /* 1. il tachimetro: il numero e basta, con l'ultima cosa che l'ha mosso */
  const perche = ultima ? (ultima.tipo === 'dispersione' && sa ? 'Hai saltato ' + sa.n + ' volte fra un’app e l’altra' : ccNomi(ultima.l + (ultima.nota ? ': ' + String(ultima.nota).split(' · ')[0] : ''))) : '';
  sl.push(ccSlide('<p class="cc-kick">Il tuo carburante</p>'
    + '<div class="cc-tach">' + dpGaugeSvg(L) + '</div>'
    + '<b class="cc-num" style="color:' + col + '">' + ccNum(L) + '</b><small class="cc-banda">' + banda + '</small>'
    + (ultima ? '<span class="cc-badge ' + (ultima.delta < 0 ? 'giu' : 'su') + '">' + (ultima.delta < 0 ? '−' : '+') + ccNum(Math.abs(ultima.delta)) + '</span><p class="cc-why">' + dpEsc(perche) + '</p>' : '')));
  /* 2. i salti, app per app */
  if (sa && sa.seq.length >= 2){
    const catena = sa.seq.map(function(x, k){
      return (k ? '<span class="cc-fr" aria-hidden="true">↓</span>' : '') + '<div class="cc-app"><small>' + ccOra(x.t) + '</small><b>' + dpEsc(x.n) + '</b></div>';
    }).join('') + (sa.piu ? '<p class="cc-piu">e altri ' + sa.piu + ' cambi</p>' : '');
    sl.push(ccSlide('<p class="cc-kick">Cosa vuol dire ' + sa.n + ' salti</p>'
      + '<h2 class="cc-h">Fra ' + ccOra(sa.da) + ' e ' + ccOra(sa.a) + ' sei passato così</h2>'
      + '<div class="cc-catena">' + catena + '</div>'
      + '<div class="cc-prezzo"><span aria-hidden="true">🧠</span><b>Ogni salto ha un prezzo</b><p>Quando cambi app, un pezzo della tua attenzione resta su quella di prima. Per tornare concentrato servono minuti, non secondi.</p></div>'
      + '<span class="cc-badge giu">' + '−' + ccNum(Math.abs(sa.delta || 0)) + ' di carburante</span>', 'cc-sl-salti'));
  }
  /* 3. dove arrivi stasera */
  if (pr){
    sl.push(ccSlide('<p class="cc-kick">Se continui così</p>'
      + '<div class="cc-proi"><div><small>Adesso</small><b>' + ccNum(L) + '</b></div><span class="cc-proi-fr" aria-hidden="true">→</span><div class="giu"><small>Stasera</small><b>' + ccNum(pr.fine) + '</b></div></div>'
      + '<p class="cc-s">È dove arrivi se continui a perdere carburante al ritmo di oggi.</p>'));
  }
  /* 4 e 5. cosa e' successo, poi le app (le stesse liste della pagina Dopamina, una per slide) */
  sl.push(ccSlide('<p class="cc-kick">Cosa è successo</p>' + ccListeHtml(d, true, false, true).replace('<div class="cc-sch" data-cc="mosse" hidden>', '<div class="cc-sch" data-cc="mosse">').replace('<div class="cc-sch" data-cc="app">', '<div class="cc-sch" data-cc="app" hidden>'), 'cc-sl-lista'));
  const cta = top && top.dev !== 'computer'
    ? '<button type="button" class="cc-cta" onclick="ccChiudi();if(typeof blPaginaApri===\'function\')blPaginaApri()">Blocca ' + dpEsc(top.nome) + '</button>'
    : '<button type="button" class="cc-cta" onclick="ccChiudi();if(typeof stGoFocus===\'function\')stGoFocus();else if(typeof ffOpen===\'function\')ffOpen()">Fai una sessione di Full Focus</button>';
  sl.push(ccSlide('<p class="cc-kick">Le app</p>' + ccListeHtml(d, true, true, true) + cta
    + '<button type="button" class="cc-link" onclick="ccChiudi();dpApri()">Vedi tutti i giorni</button>', 'cc-sl-lista'));
  w.innerHTML = '<div class="cc-story"><button type="button" class="cc-x" onclick="ccChiudi()" aria-label="Chiudi">✕</button>'
    + '<div class="cc-car" onscroll="ccScorri(this)">' + sl.join('') + '</div>'
    + '<div class="cc-piede"><div class="cc-dots">' + sl.map(function(_, k){ return '<i' + (k ? '' : ' class="on"') + '></i>'; }).join('') + '</div>'
    + '<button type="button" class="cc-avanti" onclick="ccVai(Math.round(document.querySelector(\'#ccVelo .cc-car\').scrollLeft/document.querySelector(\'#ccVelo .cc-car\').clientWidth)+1)">Avanti</button></div></div>';
}
function ccChiudi(){ const w = document.getElementById('ccVelo'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 220); }
function ccAperta(){ const w = document.getElementById('ccVelo'); return !!(w && !w.hidden); }

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.cc{position:fixed;inset:0;z-index:9690;overflow-y:auto;overscroll-behavior:none;background:#001E44;color:#fff;opacity:0;transition:opacity .2s}.cc.in{opacity:1}.cc[hidden]{display:none}',
    '.cc-in{position:relative;min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 26px) 22px calc(env(safe-area-inset-bottom,0px) + 30px)}',
    '.cc-x{position:absolute;right:14px;top:calc(env(safe-area-inset-top,0px) + 14px);width:42px;height:42px;border:0;border-radius:21px;background:rgba(255,255,255,.12);color:#fff;font-size:17px;cursor:pointer}',
    '.cc-kick{margin:8px 0 14px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.cc-attesa,.cc-s{margin:8px 0;font:500 15px/1.45 var(--font-body);color:rgba(255,255,255,.8)}.cc-in h2{margin:0;font:800 22px/1.25 var(--font-display)}',
    '.cc-tach{width:min(250px,76vw);color:#fff}.cc-tach svg{display:block;width:100%;height:auto}.cc-tach .dp-ax{fill:rgba(255,255,255,.6)}.cc-tach .dp-svg,body.dark .cc-tach .dp-svg{color:#fff}',
    '.cc-num{margin-top:16px;font:900 46px/1 var(--font-display)}.cc-banda{margin-top:8px;font:700 14px var(--font-body);color:#BCE0FF}',
    '.cc-badge{margin-top:24px;padding:6px 16px;border-radius:99px;font:800 15px var(--font-body);color:#fff}.cc-badge.giu{background:#E63946}.cc-badge.su{background:#0075E3}',
    '.cc-why{margin:14px 0 0;max-width:34ch;overflow-wrap:anywhere;font:600 15px/1.4 var(--font-body);color:#fff}',
    '.cc-prev{width:100%;box-sizing:border-box;margin-top:32px;padding:20px 16px;border-radius:18px;background:rgba(255,255,255,.07)}.cc-prev small{display:block;font:600 13px var(--font-body);color:#BCE0FF}.cc-prev b{display:block;margin-top:8px;font:800 19px var(--font-display);color:#fff}',
    '.cc-tabs{display:flex;justify-content:center;gap:8px;width:100%;margin-top:36px;border-bottom:1px solid rgba(255,255,255,.14)}',
    '.cc-tab{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;min-height:50px;padding:6px 6px 12px;border:0;border-bottom:3px solid transparent;margin-bottom:-1px;background:none;color:rgba(255,255,255,.62);font:800 13px var(--font-body);white-space:nowrap;cursor:pointer}',
    '.cc-tab.on{color:#fff;border-bottom-color:#3F9FF4}.cc-tab i{display:none;flex:none;width:24px;height:24px;border-radius:12px;background:#fff;align-items:center;justify-content:center;font-style:normal;font-size:13px;line-height:1}.cc-tab.on i{display:inline-flex}',
    '.cc-sch[hidden]{display:none}',
    '.cc-liste{width:100%;margin-top:6px}.cc-liste h3{margin:26px 0 18px;font:800 16px/1.3 var(--font-display);text-align:center;color:var(--navy)}body.dark .cc-liste h3{color:#fff}.cc-liste.scuro h3{color:#fff}',
    '.cc-liste ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}',
    '.cc-liste li{display:flex;align-items:center;gap:14px;padding:16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);text-align:left}.cc-liste.scuro li{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.08)}',
    '.cc-liste li > div{flex:1;min-width:0}.cc-liste li b{display:block;font:700 14.5px/1.3 var(--font-body);color:var(--navy)}body.dark .cc-liste li b,.cc-liste.scuro li b{color:#fff}',
    '.cc-liste li small{display:block;margin-top:2px;font:500 12.5px/1.35 var(--font-body);color:var(--muted)}.cc-liste.scuro li small{color:#BCE0FF}',
    '.cc-liste li em{flex:none;font:800 14px var(--font-body);font-style:normal}.cc-liste li em.giu{color:#E63946}.cc-liste.scuro li em.giu,body.dark .cc-liste li em.giu{color:#FF8A92}.cc-liste li em.su{color:#0075E3}.cc-liste.scuro li em.su,body.dark .cc-liste li em.su{color:#8CC6FF}',
    '.cc-vuoto{margin:0;font:500 14px var(--font-body);text-align:center;color:var(--muted)}.cc-liste.scuro .cc-vuoto{color:#BCE0FF}',
    '.cc-cta{width:100%;min-height:54px;margin-top:32px;border:0;border-radius:27px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.cc-link{margin-top:8px;min-height:44px;border:0;background:none;color:#8CC6FF;font:700 14.5px var(--font-body);cursor:pointer}',
    '.cc-story{position:relative;height:100%;display:flex;flex-direction:column}',
    '.cc-story > .cc-x{z-index:3}',
    '.cc-car{flex:1;min-height:0;display:flex;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none}.cc-car::-webkit-scrollbar{display:none}',
    '.cc-sl{flex:0 0 100%;scroll-snap-align:center;scroll-snap-stop:always;overflow-y:auto;box-sizing:border-box}',
    '.cc-sl-in{min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 70px) 24px 24px}',
    '.cc-sl-lista .cc-sl-in{justify-content:flex-start}',
    '.cc-sl .cc-kick{margin:0 0 18px}',
    '.cc-h{margin:0 0 26px;max-width:22ch;font:800 21px/1.3 var(--font-display);color:#fff}',
    '.cc-catena{display:flex;flex-direction:column;align-items:center;gap:4px;width:100%}',
    '.cc-app{display:flex;align-items:center;gap:12px;min-width:200px;padding:11px 16px;border-radius:14px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12)}',
    '.cc-app small{font:600 12px var(--font-body);color:#8CC6FF}.cc-app b{font:700 15px var(--font-body);color:#fff}',
    '.cc-fr{font:700 16px/1 var(--font-body);color:#E63946}',
    '.cc-piu{margin:10px 0 0;font:600 13px var(--font-body);color:#BCE0FF}',
    '.cc-prezzo{width:100%;box-sizing:border-box;margin:32px 0 0;padding:20px 18px;border-radius:18px;background:rgba(230,57,70,.12);border:1px solid rgba(230,57,70,.35)}',
    '.cc-prezzo > span{display:block;font-size:30px;margin-bottom:10px}.cc-prezzo b{display:block;font:800 17px var(--font-display);color:#fff}.cc-prezzo p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:#DDEBFA}',
    '.cc-proi{display:flex;align-items:center;gap:18px;margin:10px 0 26px}.cc-proi small{display:block;font:700 13px var(--font-body);color:#BCE0FF}.cc-proi b{display:block;margin-top:6px;font:900 44px/1 var(--font-display);color:#fff}.cc-proi .giu b{color:#FF8A92}',
    '.cc-proi-fr{font:700 30px var(--font-body);color:#8CC6FF}',
    '.cc-sl .cc-liste{margin-top:0}.cc-sl .cc-liste h3{margin-top:0}',
    '.cc-piede{flex:none;display:flex;flex-direction:column;align-items:center;gap:16px;padding:14px 22px calc(env(safe-area-inset-bottom,0px) + 22px)}',
    '.cc-dots{display:flex;gap:8px}.cc-dots i{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.28);transition:background .2s,transform .2s}.cc-dots i.on{background:#fff;transform:scale(1.25)}',
    '.cc-avanti{width:100%;min-height:52px;border:0;border-radius:26px;background:#fff;color:#001E44;font:800 16px var(--font-body);cursor:pointer}.cc-avanti[hidden]{display:none}',
    '.cc.in .cc-story{height:100%}'

  ].join('');
  document.head.appendChild(st);
})();
