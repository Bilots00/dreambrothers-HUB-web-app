/* ===========================================================================================
   LE RIGHE CHE SCORRONO DI LATO (0.9.302, Andrea)

   "Non voglio che ci sia mai piu' nessuna pill tagliata": nella cronologia dei blocchi la pill "Tutti" era
   tagliata a sinistra, nella Lega di Amici "Tappe fatte" e "Tempo di schermo". La causa era la stessa ovunque:
   ogni riga che scorre di lato (overflow-x:auto) finiva dove finisce il CONTENUTO della pagina, cioe' 18-22px
   prima del bordo dello schermo o della card. Scorrendo, le pill sparivano contro una linea invisibile in mezzo
   al pannello, e a riposo l'ultima pill visibile era tagliata li', non al bordo.

   LA REGOLA UNICA (classe .riga-scorre in css/app.css): la riga si allarga fino al bordo del contenitore che la
   contiene davvero (lo schermo, la card, il foglio), con un margine negativo uguale allo spazio che c'era, e
   rimette lo stesso spazio come padding interno e come scroll-padding. Cosi' la prima pill parte allineata al
   contenuto (al titolo sopra), scorrendo le pill arrivano fino al bordo, e l'ultima si raggiunge intera.

   Quanto allargare dipende da dove sta la riga (lo schermo ha 22px, una card 14-18px, un foglio altro): qui si
   MISURA, riga per riga, e si scrivono le misure nelle variabili --scorre-* che la classe usa. Le righe si
   trovano da sole: ogni elemento che scorre solo di lato, senza un fondo o un bordo suo (una riga di pill, non
   un riquadro), riceve la classe. Le righe nuove (disegnate dopo) si misurano appena compaiono.
   Fuori: i pager (figli larghi quanto la riga), le righe con data-scorre="no", i campi di testo.
   Prefisso scorre-.
   =========================================================================================== */

(function(){
  const FATTO = 'scorreW';               // data-scorre-w: dove stava la riga nel suo contenitore all'ultima misura

  function px(v){ const n = parseFloat(v); return isFinite(n) ? n : 0; }
  function trasparente(c){ return !c || c === 'transparent' || /rgba\([^)]*,\s*0\)$/.test(c); }

  /** Una riga che scorre solo di lato, e non e' un riquadro con fondo o bordo suo. */
  function eRiga(el, cs){
    if (!el || el.nodeType !== 1) return false;
    if (el.dataset && el.dataset.scorre === 'no') return false;
    const tag = el.tagName;
    if (tag === 'TEXTAREA' || tag === 'INPUT' || tag === 'PRE' || tag === 'CODE' || tag === 'SELECT' || tag === 'svg' || tag === 'CANVAS') return false;
    cs = cs || getComputedStyle(el);
    if (cs.overflowX !== 'auto' && cs.overflowX !== 'scroll') return false;
    if (cs.display === 'none' || cs.display === 'contents' || cs.position === 'fixed') return false;
    /* scorre anche in verticale: e' una pagina o un foglio, non una riga */
    if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 2) return false;
    if (el.classList.contains('screen')) return false;
    /* un riquadro con il suo fondo o il suo bordo resta com'e': allargarlo cambierebbe la sua forma */
    if (!trasparente(cs.backgroundColor) || cs.backgroundImage !== 'none') return false;
    if (px(cs.borderLeftWidth) > 0 && !trasparente(cs.borderLeftColor)) return false;
    /* un pager: il primo figlio e' largo quasi quanto la riga, si scorre una pagina alla volta */
    const f = el.firstElementChild;
    if (f && el.clientWidth > 0 && f.getBoundingClientRect().width >= el.clientWidth * 0.85) return false;
    return true;
  }

  /* 0.9.308, Andrea: "la linguetta Calendario esce dal bordo sinistro del pannello". Il pannello del foglio della Mappa,
     in chiaro, non ha ne' fondo ne' bordo (la classe .st-tutto, che e' anche lo stile di un pulsante "Vedi tutto", glieli
     azzera): il suo bordo blu e' solo un'ombra ad anello (box-shadow 0 0 0 1.5px). La ricerca del contenitore non lo
     vedeva, saliva fino alla scheda e allargava le linguette di 36px fuori dal pannello. Un anello d'ombra e' un bordo. */
  function anello(cs){
    const b = cs.boxShadow; if (!b || b === 'none') return false;
    const m = /(?:rgba?\([^)]*\)\s*)?(-?[\d.]+)px\s+(-?[\d.]+)px\s+([\d.]+)px\s+([\d.]+)px/.exec(b);
    return !!(m && +m[1] === 0 && +m[2] === 0 && +m[3] === 0 && +m[4] > 0 && !/^inset|\binset\b/.test(b.slice(0, m.index + m[0].length)));
  }
  /** Il contenitore che si vede: il primo antenato che taglia (overflow) o che ha un fondo o un bordo suo. */
  function contenitore(el){
    let p = el.parentElement;
    while (p && p !== document.body && p !== document.documentElement){
      const cs = getComputedStyle(p);
      if (cs.overflowX !== 'visible' || !trasparente(cs.backgroundColor) || cs.backgroundImage !== 'none'
          || (px(cs.borderLeftWidth) > 0 && !trasparente(cs.borderLeftColor)) || cs.position === 'fixed' || anello(cs)) {
        const r = p.getBoundingClientRect();
        return { el: p, l: r.left + px(cs.borderLeftWidth), r: r.right - px(cs.borderRightWidth) };
      }
      p = p.parentElement;
    }
    return { el: null, l: 0, r: document.documentElement.clientWidth };
  }

  /**
   * C'e' qualcos'altro accanto alla riga, fra lei e il bordo (un pulsante X, un'icona, un titolo sulla stessa linea)?
   * Allora da quella parte la riga non si allarga: coprirebbe quell'elemento.
   */
  function vicino(el, c, r, lato){
    let n = el;
    while (n && n.parentElement && n !== c.el){
      const p = n.parentElement;
      for (let i = 0; i < p.children.length; i++){
        const s = p.children[i];
        if (s === n) continue;
        const q = s.getBoundingClientRect();
        if (q.width === 0 || q.height === 0) continue;
        if (q.bottom <= r.top + 1 || q.top >= r.bottom - 1) continue;          // non sulla stessa linea
        if (lato < 0 ? q.right <= r.left + 1 && q.right > c.l + 0.5 : q.left >= r.right - 1 && q.left < c.r - 0.5) return true;
      }
      if (p === c.el) break;
      n = p;
    }
    return false;
  }

  /** Misura una riga e la allarga fino al bordo del suo contenitore. */
  function allinea(el){
    if (!el || !el.isConnected) return;
    const cs0 = getComputedStyle(el);
    if (!el.classList.contains('riga-scorre') && !eRiga(el, cs0)) return;
    /* si riparte dalla riga com'e' scritta nel suo CSS, senza le misure di prima */
    el.classList.remove('riga-scorre-on', 'riga-scorre-larga', 'riga-scorre-centro');
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    if (r.width < 40 || r.height === 0) { el.classList.add('riga-scorre'); return; }
    const c = contenitore(el);
    let gl = Math.max(0, Math.round(r.left - c.l)), gr = Math.max(0, Math.round(c.r - r.right));
    if (gl > 0 && vicino(el, c, r, -1)) gl = 0;
    if (gr > 0 && vicino(el, c, r, 1)) gr = 0;
    /* 0.9.304, Andrea: "le tab dentro a un pannello non devono fuoriuscire". Dentro un pannello (una card, un
       foglio: non lo schermo) la riga si ferma 8px prima del bordo, cosi' non passa sopra all'angolo
       arrotondato, e il pannello la taglia di lato: scorrendo, le pill spariscono dentro al pannello. */
    const pannello = c.el && c.el !== document.body && !c.el.classList.contains('screen') && getComputedStyle(c.el).position !== 'fixed';
    if (pannello){
      gl = Math.max(0, gl - 8); gr = Math.max(0, gr - 8);
      c.el.classList.add('scorre-taglia');
    }
    el.classList.add('riga-scorre');
    el.dataset[FATTO] = chiave(el, c);
    if (gl < 1 && gr < 1) return;
    const ml = px(cs.marginLeft), mr = px(cs.marginRight), pl = px(cs.paddingLeft), pr = px(cs.paddingRight);
    const s = el.style;
    s.setProperty('--scorre-ml', (ml - gl) + 'px');
    s.setProperty('--scorre-mr', (mr - gr) + 'px');
    s.setProperty('--scorre-pl', (pl + gl) + 'px');
    s.setProperty('--scorre-pr', (pr + gr) + 'px');
    el.classList.add('riga-scorre-on');
    /* una riga con la larghezza scritta (width:100%, un elemento flex) non si allarga con i margini: allora la
       larghezza si scrive intera, e il contenuto resta largo uguale */
    const n = el.getBoundingClientRect();
    if (n.left > c.l + gl * 0.5 + 1 || n.right < c.r - gr * 0.5 - 1){
      s.setProperty('--scorre-w', Math.round(r.width + gl + gr) + 'px');
      el.classList.add('riga-scorre-larga');
    }
    /* centrato e piu' largo dello schermo: "center" taglia le prime pill a sinistra, "safe center" no */
    if (cs.justifyContent === 'center') el.classList.add('riga-scorre-centro');
    el.dataset[FATTO] = chiave(el, c);
  }

  /** Dove sta la riga rispetto al suo contenitore: se non e' cambiato, non c'e' niente da rifare. */
  function chiave(el, c){
    const r = el.getBoundingClientRect();
    return Math.round(c.r - c.l) + ':' + Math.round(r.left - c.l) + ':' + Math.round(c.r - r.right);
  }

  /** Cerca le righe dentro un pezzo di pagina appena disegnato (o in tutta la pagina). */
  function cerca(radice){
    const root = radice && radice.nodeType === 1 ? radice : document.body;
    const tutti = root.getElementsByTagName('*');
    const da = [];
    if (root !== document.body && root.scrollWidth > root.clientWidth + 1) da.push(root);
    for (let i = 0; i < tutti.length; i++){
      const el = tutti[i];
      if (el.classList.contains('riga-scorre')) { da.push(el); continue; }
      /* solo chi trabocca davvero: leggere scrollWidth costa poco, lo stile di ogni elemento no */
      if (el.scrollWidth > el.clientWidth + 1 && el.clientWidth > 0) da.push(el);
    }
    for (let i = 0; i < da.length; i++){
      const el = da[i];
      if (el.classList.contains('riga-scorre') && el.dataset[FATTO] && chiave(el, contenitore(el)) === el.dataset[FATTO]) continue;
      try{ allinea(el); }catch(_){ }
    }
  }

  let coda = [], tutto = false, timer = 0;
  function programma(nodo, ripasso){
    if (nodo === 'tutto') tutto = true; else if (nodo && coda.indexOf(nodo) < 0) coda.push(nodo);
    if (timer) return;
    timer = setTimeout(function(){
      timer = 0;
      const c = coda; coda = [];
      /* una seconda misura a transizione finita (schede e schermate entrano scorrendo per .38s): la prima puo'
         essere caduta a meta' movimento */
      if (!ripasso) setTimeout(function(){ if (tutto || !c.length) programma('tutto', true); else c.forEach(function(n){ programma(n, true); }); }, 450);
      if (tutto){ tutto = false; cerca(document.body); return; }
      for (let i = 0; i < c.length; i++){
        let n = c[i];
        if (!n.isConnected) continue;
        cerca(n);
        /* una riga gia' in pagina che riceve pill nuove: si guarda anche chi la contiene */
        for (let k = 0; k < 2 && n.parentElement; k++){ n = n.parentElement; if (n.scrollWidth > n.clientWidth + 1 || n.classList.contains('riga-scorre')) try{ allinea(n); }catch(_){ } }
      }
    }, 80);
  }
  window.scorreAllinea = function(el){ if (el) allinea(el); else programma('tutto'); };

  function avvia(){
    programma('tutto');
    try{
      new MutationObserver(function(ms){
        for (let i = 0; i < ms.length; i++){
          const m = ms[i];
          if (m.type === 'childList'){
            for (let j = 0; j < m.addedNodes.length; j++){ const a = m.addedNodes[j]; if (a.nodeType === 1) programma(a); }
          } else if (m.type === 'attributes' && m.target.nodeType === 1){
            const t = m.target;
            /* una schermata, una scheda o un foglio che diventa visibile: le sue righe ora hanno una misura */
            if (m.attributeName === 'hidden' ? !t.hidden
                : (t.classList.contains('screen') || t.classList.contains('on') || t.classList.contains('active') || t.classList.contains('show') || t.classList.contains('open'))) programma(t);
          }
        }
      }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] });
    }catch(_){ }
    window.addEventListener('resize', function(){ programma('tutto'); });
    /* i caratteri arrivano dopo: le pill cambiano larghezza */
    try{ if (document.fonts && document.fonts.ready) document.fonts.ready.then(function(){ programma('tutto'); }); }catch(_){ }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', avvia); else avvia();
})();
