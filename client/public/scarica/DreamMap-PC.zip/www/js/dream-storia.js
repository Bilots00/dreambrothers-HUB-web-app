/* ===========================================================================================
   IL PANNELLO BIANCO DI DREAM, RIPRENDI DA DOVE ERI, LA CHAT E LA PRIMA VOLTA NELLE PAGINE (0.9.321)

   Andrea: "la scheda La tua storia fa schifo e non sta nel pannello Il tuo viaggio". Sopra a quel
   pannello ce n'e' uno bianco, ed e' la prima cosa che si vede:
     1. Ti riporto in rotta: solo quando c'e' un ritardo (la decide rotta-tab.js, nvPaint)
     2. La tua storia: gli episodi
     3. Controlla la rotta: la revisione chiesta da te, quando non c'e' il ritardo. Premium: la bozza
        per il tuo agente (parte solo con invio, regola di Andrea); gratis: l'anteprima e il funnel.

   Riprendi: il rientro in rotta e il piano su misura non ripartono da zero. La chat si salva a ogni
   messaggio (fl_rn_ripresa, fl_cv_chat_<modo>): all'apertura si chiede se riprendere o ricominciare.

   La chat: copia su ogni messaggio, matita sui miei (si riparte da li'), pollice su e giu' sulle risposte,
   il piu' per allegare. Prefisso nvs- per il pannello, drs- per il resto.

   La prima volta in una pagina: invece di un tour infinito, come SweetCase, la pagina si spiega da sola
   quando l'utente ci entra. Una volta sola per pagina. Il tour del primo avvio resta sul percorso vero:
   Dream, Mappa, START.
   =========================================================================================== */
const NVS = { rientro: '' };
const DRS_PLAY = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M7 4.500v15a1 1 0 0 0 1.520.850l12-7.500a1 1 0 0 0 0-1.700l-12-7.500A1 1 0 0 0 7 4.500z"/></svg>';
function drsEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function drsVibra(p){ try{ if (typeof flVibra === 'function') flVibra(p); }catch(_){ } }
function drsToast(m){ try{ if (typeof toast === 'function') toast(m); }catch(_){ } }
function drsPremium(){ try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; } }

/* 0.9.322, Andrea: "non voglio le tab: se il titolo e' gia' Ti riporto in rotta, e' una ripetizione. Due pallini sotto, ed e' un carosello". */
function nvsCrea(blocco, prima){
  if (document.getElementById('nvsPan')) return;
  const p = document.createElement('section');
  p.id = 'nvsPan'; p.className = 'nvs';
  p.innerHTML = '<div class="nvs-car" id="nvsCar"></div><div class="nvs-dots" id="nvsDots"></div>';
  blocco.insertBefore(p, prima);
  const c = p.querySelector('.nvs-car');
  let t = 0;
  c.addEventListener('scroll', function(){ clearTimeout(t); t = setTimeout(nvsDotPaint, 60); }, { passive: true });
}
function nvsDotPaint(){
  const c = document.getElementById('nvsCar'), d = document.getElementById('nvsDots'); if (!c || !d) return;
  const n = c.children.length, i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth));
  d.querySelectorAll('i').forEach(function(x, k){ x.classList.toggle('on', k === i); });
  void n;
}
function nvsPaint(rientro){
  /* il pannello scuro puo' nascere prima che questo file sia caricato: il bianco si mette qui */
  if (!document.getElementById('nvsPan')){ const pn = document.getElementById('nvPannello'); if (pn && pn.parentNode) nvsCrea(pn.parentNode, pn); }
  const c = document.getElementById('nvsCar'), d = document.getElementById('nvsDots'); if (!c || !d) return;
  NVS.rientro = rientro || '';
  const rv = drsRevSlideHtml();
  const slide = (rv ? [rv] : []).concat(rientro ? [rientro, nvsStoriaHtml()] : [nvsStoriaHtml(), nvsControllaHtml()]);
  const html = slide.map(function(h, i){ const k = rv && i === 0 ? ' rv' : ((rientro && i === (rv ? 1 : 0)) ? ' rotta' : ''); return '<div class="nvs-s' + k + '">' + h + '</div>'; }).join('');
  if (c._h === html) return;
  const sx = c.scrollLeft, nuovo = !!rientro !== !!c._r;
  c._h = html; c._r = !!rientro;
  c.innerHTML = html;
  c.scrollLeft = nuovo ? 0 : sx;
  d.innerHTML = slide.map(function(){ return '<i></i>'; }).join('');
  nvsDotPaint();
}

/* la seconda slide: come l'anteprima di una serie su Netflix. Una sola cosa da fare: il tasto play */
function drsSerieIniziata(){
  try{ const o = epiOggi(); const x = o && o.x; return !!(x && (x.n > 1 || x.s > 1 || (o.st && o.st.k === 'in-corso'))); }catch(_){ return false; }
}
function nvsStoriaHtml(){
  if (typeof epiOggi !== 'function') return '';
  let o = null; try{ if (typeof EPI !== 'undefined' && !EPI.cfg){ epiCarica().then(function(){ try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ } }); return '<div class="nvs-tv"></div>'; } o = epiOggi(); }catch(_){ return ''; }
  const x = (o && o.x) || (o && o.lista && o.lista[o.lista.length - 1]); if (!x) return '';
  const aperto = !!o.x && (o.st.k === 'da-vedere' || o.st.k === 'in-corso');
  let cta = '', riga = '';
  if (!o.x) riga = epiUi('riga_fine', { s: x.s });
  else if (aperto){ riga = (typeof epiSotto === 'function') ? epiSotto(x) : ''; cta = '<button type="button" class="nvs-play" onclick="event.stopPropagation();epiTocca(' + x.s + ',' + x.n + ')">' + DRS_PLAY + '<span>' + (drsSerieIniziata() ? 'Riprendi' : 'Inizia') + '</span></button>'; }
  else if (o.st.k === 'tappa'){ riga = o.st.motivo; cta = '<button type="button" class="nvs-play" onclick="event.stopPropagation();epiVaiMappa()">Fai una tappa sulla Mappa</button>'; }
  else riga = o.st.motivo || epiUi('motivo_domani');
  return '<div class="nvs-tv" role="button" onclick="epiSerieApri()"><div class="nvs-tv-art">' + ((typeof epiVisHtml === 'function') ? epiVisHtml(x.vis || 'sfera') : '') + '</div>'
    + '<div class="nvs-tv-c"><small>La tua storia</small><h3>Verso il sogno</h3>'
    + '<p class="nvs-tv-ep"><b>S' + x.s + ' E' + x.n + '</b> · ' + drsEsc(x.titolo) + '</p>'
    + (riga ? '<p class="nvs-tv-r">' + drsEsc(riga) + '</p>' : '') + cta
    + '<span class="nvs-tv-tutti">Tutti gli episodi</span></div></div>';
}
/* LA REVISIONE, come prima slide (0.9.337, Andrea): grande, nel carosello della tua storia, solo quando c'e' da farla. Prima quella di
   periodo (che contiene anche la sera), poi quella della sera. */
function drsRevSlideHtml(){
  let tipo = '', nome = '', titolo = '', ico = '🌙', fn = '';
  try{
    const d = (typeof rvpDovuta === 'function') ? rvpDovuta() : null;
    if (d){
      tipo = d.tipo; nome = (typeof RVP_NOMI !== 'undefined' && RVP_NOMI[d.tipo]) || 'La revisione';
      titolo = (typeof rvpParole === 'function') ? rvpParole(d.tipo, d.periodo).card : '';
      ico = (typeof RVP_ICO !== 'undefined' && RVP_ICO[d.tipo]) || '🗓️'; fn = 'rvpApri(\'' + d.tipo + '\')';
    } else if (typeof rvStato === 'function' && rvStato() === 'da-fare'){
      tipo = 'sera'; nome = 'La revisione della sera'; titolo = 'Tre domande sulla giornata, e una cosa da cambiare nel sistema.'; fn = 'rvApri()';
    }
  }catch(_){ return ''; }
  if (!tipo) return '';
  let serie = 0; try{ serie = (typeof rvSerie === 'function') ? rvSerie() : 0; }catch(_){ }
  /* 0.9.340, Andrea: "il pulsante deve dire solo Inizia, e l'etichetta e' attaccata alla luna: tutto ammassato". Tre gruppi con
     aria fra loro: la luna, poi etichetta e titolo, poi il pulsante */
  return '<div class="drs-rv ' + tipo + '" role="button" onclick="' + fn + '"><span class="drs-rv-ico">' + ico + '</span>'
    + '<div class="drs-rv-testo"><small>' + drsEsc(nome) + '</small><h3>' + drsEsc(titolo) + '</h3>'
    + (serie > 1 && tipo === 'sera' ? '<p class="drs-rv-serie">' + serie + ' sere di fila</p>' : '') + '</div>'
    + '<button type="button" class="nvs-play" onclick="event.stopPropagation();' + fn + '">' + DRS_PLAY + '<span>Inizia</span></button></div>';
}
/* la scheda Controlla la rotta */
const DRS_LENTE = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.500-3.500"/></svg>';
function nvsControllaHtml(){
  if (!drsPremium()) return '<div class="nvs-ctl"><div class="nvs-ctl-art"><img src="img/genio/genio-rivela.png" alt=""><span class="nvs-ctl-lock">Premium</span></div>'
    + '<b>Il tuo agente controlla la tua rotta</b>'
    + '<ul><li>Guarda la tua giornata fino a questo momento</li><li>Ti dice cosa sta funzionando e cosa no</li><li>Ti propone come rimetterla a posto</li></ul>'
    + '<button type="button" class="nvs-cta" onclick="if(typeof pfApri===\'function\')pfApri()">Scopri Premium</button></div>';
  /* 0.9.335, Andrea: "prima di controllare la rotta, il Genio trovi il collo di bottiglia che blocca il progresso" (collo.js) */
  /* 0.9.349, Andrea: "un'emoji in alto come nelle revisioni, il pannello azzurro chiaro che stacchi dallo sfondo bianco, il testo in un
     contenitore bianco, la lente per cercare e l'ostacolo (la stessa emoji della pallina del collo) per segnalare" */
  /* 0.9.353, Andrea: "fa cagare, troppo confusionario: era meglio quando era minimal. Via l'emoji della bottiglia, l'azzurrino al
     contrario (chiaro in alto, azzurro in basso dove ci sono i pulsanti), Segnala un imprevisto come primo pulsante blu con la
     transenna, Trova il mio collo di bottiglia bianco con la lente". La frase lunga sta dietro alla (i) del titolo */
  return '<div class="nvs-ctl nvs-ctl-az nvs-ctl-min"><h3 class="nvs-ctl-h">Cosa ti sta bloccando?<button type="button" class="nvs-ctl-i" onclick="event.stopPropagation();nvsCtlInfo()" aria-label="Cosa fanno questi pulsanti">i</button></h3>'
    + '<div class="nvs-ctl-btns"><button type="button" class="nvs-cta" onclick="nvsImprevisto()"><span class="nvs-cta-e" aria-hidden="true">🚧</span><span>Segnala un imprevisto</span></button>'
    + '<button type="button" class="nvs-cta sec" onclick="if(typeof cloChiedi===\'function\')cloChiedi(false);else nvsControlla()"><span class="nvs-cta-e" aria-hidden="true">🔍</span><span>Trova il mio collo di bottiglia</span></button></div></div>';
}
function nvsCtlInfo(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Cosa ti sta bloccando?</h3>'
    + flInfoRighe([
        ['🧭', 'Il tuo agente guarda la tua rotta', 'Cerca il punto che rallenta tutto il resto.'],
        ['🔍', 'Trova il collo di bottiglia', 'Ti dice qual è e la prima mossa per toglierlo. Sbloccato quello, il resto diventa facile.'],
        ['🚧', 'Segnala un imprevisto', 'Se ti è capitato qualcosa, il tuo agente rimette in piedi il percorso.']
      ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
/* la richiesta si scrive nel campo: parte solo con invio */
function nvsControlla(){
  try{ localStorage.setItem('fl_ctl_giorno', new Date().toDateString()); }catch(_){ }
  drsVibra(10);
  if (typeof agApri !== 'function') return;
  agApri();
  setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza('Controlla la mia rotta: guarda la mia giornata fino a questo momento e dimmi cosa sta funzionando, cosa no e cosa migliorare adesso.'); }catch(_){ } }, 300);
}
function nvsImprevisto(){
  drsVibra(10);
  if (typeof agApri !== 'function') return;
  agApri();
  setTimeout(function(){ try{ if (typeof agBozza === 'function') agBozza('Mi è capitato un imprevisto: '); }catch(_){ } }, 300);
}

/* ---------------------------------------------------------------- riprendi da dove eri */
const DRS_RN_K = 'fl_rn_ripresa';
function drsRnSalva(){
  try{
    if (typeof RNG === 'undefined' || typeof RN === 'undefined' || !GN.on || GN.modo !== 'rn') return;
    const passo = RNG.passo; if (!passo || passo === 'fine' || passo === 'nulla' || passo === 'scelta') return;
    const oggi = (typeof etaOggiK === 'function') ? etaOggiK() : new Date().toDateString();
    const chat = (typeof CV !== 'undefined' && CV.modo === 'rn') ? CV.chat : null;
    /* una chat che non ha ancora un mio messaggio non vale la domanda: si riparte da capo senza chiederlo */
    const ha = (chat && chat.msgs.some(function(m){ return m.chi === 'io'; })) || Object.keys(RN.r || {}).length > 0 || (RNG.storia || []).length > 1;
    if (!ha) return;
    localStorage.setItem(DRS_RN_K, JSON.stringify({ g: oggi, at: Date.now(), passo: passo, storia: RNG.storia, r: RN.r, v: RN.v, chat: chat }));
  }catch(_){ }
}
function drsRnLeggi(){
  try{
    const o = JSON.parse(localStorage.getItem(DRS_RN_K) || 'null'); if (!o) return null;
    const oggi = (typeof etaOggiK === 'function') ? etaOggiK() : new Date().toDateString();
    if (o.g !== oggi){ localStorage.removeItem(DRS_RN_K); return null; }
    return o;
  }catch(_){ return null; }
}
function drsRnVia(){ try{ localStorage.removeItem(DRS_RN_K); }catch(_){ } }
function drsRientroPronto(){ return !!drsRnLeggi(); }
(function(){
  /* si avvolgono le due porte del rientro: chi l'ha gia' iniziato sceglie; a cosa fatta il salvataggio sparisce */
  const avvolgi = function(n, f){ const o = window[n]; if (typeof o === 'function') window[n] = function(){ return f.call(this, o, arguments); }; };
  const monta = function(){
    avvolgi('rnApri', function(orig, a){
      const v = a[0], s = drsRnLeggi();
      if (!s || DRS_ORA.salta){ DRS_ORA.salta = false; return orig.apply(this, a); }
      inSheet('<div class="am-sheet center drs-ri"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="drs-ri-ico" aria-hidden="true">🧭</span>'
        + '<b class="am-sh-title">Hai già iniziato questo rientro</b><p class="am-sh-p">Vuoi riprendere da dove avevi lasciato o ricominciare da capo l’analisi?</p>'
        + '<button type="button" class="nvs-cta" onclick="inSheetChiudi();drsRnRiprendi()">Riprendi da dove avevi lasciato</button>'
        + '<button type="button" class="nvs-cta sec" onclick="inSheetChiudi();drsRnDaCapo()">Ricomincia da capo</button></div>');
      DRS_ORA.v = v;
    });
    /* la revisione della sera e quelle di settimana, mese e trimestre: la stessa domanda, sulla chat del giorno */
    const porta = function(n, modo, ico, cosa){
      avvolgi(n, function(orig, a){
        const tipo = a[0];
        const s = drsCvLeggi(modo, tipo);
        /* 0.9.322: non solo la chat: anche le domande gia' fatte fuori dalla chat */
        const rip = modo === 'rv' ? rvRipLeggi() : rvpRipLeggi(tipo);
        if ((!s && !rip) || DRS_ORA.salta){ DRS_ORA.salta = false; return orig.apply(this, a); }
        const self = this;
        DRS_ORA.fai = function(ri){
          DRS_ORA.salta = true; DRS_ORA.cv = ri ? s : null;
          if (modo === 'rv') RV_RIPRESA = ri ? rip : null; else RVP_RIPRESA = ri ? rip : null;
          if (!ri){ if (s) drsCvVia(modo); if (modo === 'rv') rvRipVia(); else rvpRipVia(); }
          return orig.apply(self, a);
        };
        inSheet('<div class="am-sheet center drs-ri"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="drs-ri-ico" aria-hidden="true">' + ico + '</span>'
          + '<b class="am-sh-title">Hai già iniziato ' + cosa + '</b><p class="am-sh-p">Vuoi riprendere da dove avevi lasciato o ricominciare da capo?</p>'
          + '<button type="button" class="nvs-cta" onclick="inSheetChiudi();DRS_ORA.fai(true)">Riprendi da dove avevi lasciato</button>'
          + '<button type="button" class="nvs-cta sec" onclick="inSheetChiudi();DRS_ORA.fai(false)">Ricomincia da capo</button></div>');
      });
    };
    porta('rvApri', 'rv', '🌙', 'questa revisione');
    porta('rvpApri', 'rvp', '📅', 'questa revisione');
    avvolgi('agInviaDaCampo', function(orig, a){
      if (DRS_ORA.correzione){ DRS_ORA.correzione = false; const t = document.getElementById('agTesto'); if (t && t.value.trim()) t.value = '[correzione] ' + t.value; }
      return orig.apply(this, a);
    });
    avvolgi('rngVai', function(orig, a){ const r = orig.apply(this, a); drsRnSalva(); return r; });
    avvolgi('rngChiudi', function(orig, a){ drsRnSalva(); const r = orig.apply(this, a); return r; });
    avvolgi('rngSalva', function(orig, a){ drsRnVia(); return orig.apply(this, a); });
    avvolgi('nvRientroSegna', function(orig, a){ drsRnVia(); return orig.apply(this, a); });
    avvolgi('cvChatPaint', function(orig, a){ const r = orig.apply(this, a); drsRnSalva(); drsCvSalva(); drsCvAttrezzi(); return r; });
    avvolgi('agMsgHtml', function(orig, a){ return drsAgAttrezzi(orig.apply(this, a), a[0]); });
    avvolgi('sdPianoVia', function(orig, a){
      /* il piano su misura: l'intervista gia' iniziata non riparte da zero */
      const iv = drsPianoInCorso();
      /* 0.9.331, Andrea: "riprendendo, il foglio del piano resta sopra alla chat" */
      try{ if (typeof sdMissioneChiudi === 'function') sdMissioneChiudi(); }catch(_){ }
      if (!iv || DRS_ORA.salta){ DRS_ORA.salta = false; return orig.apply(this, a); }
      inSheet('<div class="am-sheet center drs-ri"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="drs-ri-ico" aria-hidden="true">🗺️</span>'
        + '<b class="am-sh-title">Hai già iniziato il tuo piano su misura</b><p class="am-sh-p">Vuoi riprendere da dove avevi lasciato o ricominciare da capo?</p>'
        + '<button type="button" class="nvs-cta" onclick="inSheetChiudi();drsPianoRiprendi()">Riprendi da dove avevi lasciato</button>'
        + '<button type="button" class="nvs-cta sec" onclick="inSheetChiudi();drsPianoDaCapo()">Ricomincia da capo</button></div>');
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else setTimeout(monta, 0);
})();
const DRS_ORA = { salta: false, v: null };
function drsRnDaCapo(){ drsRnVia(); DRS_ORA.salta = true; rnApri(DRS_ORA.v); }
function drsRnRiprendi(){
  const s = drsRnLeggi(); if (!s){ DRS_ORA.salta = true; rnApri(DRS_ORA.v); return; }
  DRS_ORA.salta = true;
  rnApri(s.v);
  /* rnApri ha preparato i dati del giorno (il pannello, il tempo sulle app): sopra si rimette il punto in cui si era */
  try{
    RN.r = s.r || {};
    RNG.storia = s.storia || [];
    RNG.passo = s.passo;
    if (s.chat && typeof CV !== 'undefined'){ CV.modo = 'rn'; CV.chat = s.chat; if (!Array.isArray(CV.chat.applicati)) CV.chat.applicati = []; }
    RNG.barraP = 0; rngBarra(); GN.step = ''; gnVai('rn');
  }catch(_){ }
}
/* l'intervista sta in una conversazione dell'agente: gia' iniziata se ha un mio messaggio e ancora nessun piano */
function drsPianoInCorso(){
  try{
    const s = agStato(); if (!s || !s.sess) return '';
    const l = s.sess.filter(function(q){ return q.intervista; });
    for (let i = l.length - 1; i >= 0; i--){
      const m = agSessMsgs(l[i].id);
      if (m.some(function(x){ return x.direzione === 'in'; }) && !m.some(function(x){ return x.direzione === 'out' && x.azioni && x.azioni.piano; })) return l[i].id;
    }
  }catch(_){ }
  return '';
}
function drsPianoDaCapo(){ DRS_ORA.salta = true; sdPianoVia(); }
function drsPianoRiprendi(){ const id = drsPianoInCorso(); if (!id) return drsPianoDaCapo(); try{ goId('s-agente'); agSessApri(id); agPollAvvia(); }catch(_){ } }

/* le revisioni della sera, della settimana e del mese: la chat del giorno si tiene */
function drsCvK(){ return 'fl_cv_chat_' + (CV.modo || ''); }
function drsCvVia(modo){ try{ localStorage.removeItem('fl_cv_chat_' + modo); }catch(_){ } }
function drsCvLeggi(modo, tipo){
  try{
    const o = JSON.parse(localStorage.getItem('fl_cv_chat_' + modo) || 'null'); if (!o || !o.chat) return null;
    if (o.g !== new Date().toDateString()){ drsCvVia(modo); return null; }
    if (modo === 'rvp' && tipo && o.chat.tipo !== tipo) return null;
    return o;
  }catch(_){ return null; }
}
/* cvInizio chiede qui se c'e' una chat da rimettere (DRS_ORA.cv l'ha scelta chi ha detto Riprendi) */
function drsCvRipristina(){ const s = DRS_ORA.cv; DRS_ORA.cv = null; return (s && s.chat) ? s.chat : null; }
function drsCvSalva(){
  try{
    if (typeof CV === 'undefined' || !CV.chat || CV.modo === 'rn') return;
    if (CV.chat.fine){ localStorage.removeItem(drsCvK()); return; }
    if (!CV.chat.msgs.some(function(m){ return m.chi === 'io'; })) return;
    localStorage.setItem(drsCvK(), JSON.stringify({ g: new Date().toDateString(), chat: CV.chat }));
  }catch(_){ }
}

/* ---------------------------------------------------------------- la chat: copia, matita, voti, allegati */
const DRS_IC = {
  copia: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  matita: '<path d="M4 20h4L19 9a2.800 2.800 0 0 0-4-4L4 16z"/><path d="M13.500 6.500l4 4"/>',
  su: '<path d="M7 11v9H4v-9zM7 11l4-8c1.700 0 3 1.300 3 3v3h5a2 2 0 0 1 2 2.400l-1.400 6.700A2.300 2.300 0 0 1 17.300 20H7"/>',
  giu: '<path d="M17 13V4h3v9zM17 13l-4 8c-1.700 0-3-1.300-3-3v-3H5a2 2 0 0 1-2-2.400l1.400-6.700A2.300 2.300 0 0 1 6.700 4H17"/>',
  piu: '<path d="M12 5v14M5 12h14"/>'
};
function drsSvg(k){ return '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + DRS_IC[k] + '</svg>'; }
function drsCopiaTesto(t){
  const fatto = function(){ drsToast('Copiato'); drsVibra(8); };
  try{ if (navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(t).then(fatto).catch(function(){ drsCopiaVecchia(t); fatto(); }); return; } }catch(_){ }
  drsCopiaVecchia(t); fatto();
}
function drsCopiaVecchia(t){ try{ const a = document.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = '0'; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); }catch(_){ } }
function drsVoto(v, testo, modo, btn){
  /* 0.9.357: il "non mi piace" apre il foglio con il motivo, come su Claude; nella chat del tuo agente il voto va al server
     con il numero della risposta (agente-voti.js) */
  if (typeof agvDaDrs === 'function' && agvDaDrs(v, testo, modo, btn)) return;
  const riga = btn.parentElement;
  const era = btn.classList.contains('on');
  riga.querySelectorAll('.drs-v').forEach(function(b){ b.classList.remove('on'); });
  if (!era) btn.classList.add('on');
  drsVibra(8);
  if (era) return;
  drsToast(v > 0 ? 'Grazie: risposte così ne arrivano di più' : 'Grazie: lo terrò a mente');
  try{ if (typeof frApi === 'function') frApi('POST', '/api/focuslock/social/voto-chat', { device: frDevice(), voto: v, testo: String(testo || '').slice(0, 1500), modo: modo }); }catch(_){ }
}
function drsCvAttrezzi(){
  const l = document.getElementById('cvLista'); if (!l || typeof CV === 'undefined' || !CV.chat) return;
  /* la lista si ridisegna intera: gli attrezzi si rimettono a ogni disegno */
  const msgs = CV.chat.msgs.filter(function(m){ return m.chi !== 'nota'; });
  const els = l.querySelectorAll('.cv-m:not(:has(.cv-pensa))');
  els.forEach(function(el, i){
    const m = msgs[i]; if (!m) return;
    const r = document.createElement('div'); r.className = 'drs-at ' + (m.chi === 'io' ? 'io' : 'lui');
    r.innerHTML = m.chi === 'io'
      ? '<button type="button" aria-label="Copia" onclick="event.stopPropagation();drsCvCopia(' + CV.chat.msgs.indexOf(m) + ')">' + drsSvg('copia') + '</button><button type="button" aria-label="Modifica e riparti da qui" onclick="event.stopPropagation();drsCvModifica(' + CV.chat.msgs.indexOf(m) + ')">' + drsSvg('matita') + '</button>'
      : '<button type="button" aria-label="Copia" onclick="event.stopPropagation();drsCvCopia(' + CV.chat.msgs.indexOf(m) + ')">' + drsSvg('copia') + '</button><button type="button" class="drs-v" aria-label="Mi piace" onclick="event.stopPropagation();drsCvVota(' + CV.chat.msgs.indexOf(m) + ',1,this)">' + drsSvg('su') + '</button><button type="button" class="drs-v" aria-label="Non mi piace" onclick="event.stopPropagation();drsCvVota(' + CV.chat.msgs.indexOf(m) + ',-1,this)">' + drsSvg('giu') + '</button>';
    el.parentNode.insertBefore(r, el.nextSibling);
  });
  /* il piu' per allegare, accanto al campo */
  const comp = document.querySelector('.cv-comp');
  if (comp && !comp.querySelector('.drs-piu')){
    const b = document.createElement('button'); b.type = 'button'; b.className = 'drs-piu'; b.setAttribute('aria-label', 'Aggiungi una foto o un file'); b.innerHTML = drsSvg('piu');
    b.onclick = function(e){ e.stopPropagation(); drsCvAllega(); };
    comp.insertBefore(b, comp.firstChild);
  }
  drsCvAllPaint();
}
function drsCvCopia(i){ const m = CV.chat && CV.chat.msgs[i]; if (m) drsCopiaTesto(m.t); }
function drsCvVota(i, v, btn){ const m = CV.chat && CV.chat.msgs[i]; if (m) drsVoto(v, m.t, CV.chat.tipo || 'rientro', btn); }
/* la matita: si torna a prima di quel messaggio, e il testo torna nel campo da correggere */
/* 0.9.335, Andrea: "tocco la matita, torno indietro senza confermare, rientro con Parliamone e il messaggio e' sparito".
   Il messaggio e quello che viene dopo restano finche' la correzione non parte davvero (cvInvia): fino ad allora e' solo segnato. */
function drsCvModifica(i){
  const c = CV.chat, m = c && c.msgs[i]; if (!m || c.attesa) return;
  c.inModifica = i;
  const testo = m.t;
  cvChatPaint();
  const t = document.getElementById('cvTesto');
  if (t){ t.value = testo; cvCampo(); try{ t.focus(); t.setSelectionRange(testo.length, testo.length); }catch(_){ } }
  drsVibra(10);
}
/* gli allegati: stessi tipi dell'agente (foto, PDF, testo). Vanno con il prossimo messaggio */
const DRS_ALL = { l: [] };
function drsCvAllega(){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.multiple = true; inp.style.display = 'none';
  inp.accept = 'image/*,application/pdf,text/plain,text/markdown,text/csv,.pdf,.txt,.md,.csv';
  inp.addEventListener('change', async function(){
    const f = Array.prototype.slice.call(inp.files || []); inp.remove();
    for (let i = 0; i < f.length && DRS_ALL.l.length < 3; i++){
      try{ const a = await agAllegatoDa(f[i]); if (a) DRS_ALL.l.push(a); }catch(e){ drsToast(e && e.message === 'grande' ? 'Il file è troppo grande' : 'Questo file non si riesce a leggere'); }
    }
    drsCvAllPaint();
  });
  document.body.appendChild(inp); inp.click();
}
function drsCvAllPaint(){
  const p = document.getElementById('cvPiede'); if (!p) return;
  let b = document.getElementById('drsAll');
  if (!DRS_ALL.l.length){ if (b) b.remove(); return; }
  if (!b){ b = document.createElement('div'); b.id = 'drsAll'; b.className = 'drs-all'; p.insertBefore(b, p.querySelector('.cv-comp')); }
  b.innerHTML = DRS_ALL.l.map(function(a, i){
    return '<span class="drs-all-c">' + (a.tipo === 'image' && a.anteprima ? '<img src="' + drsEsc(a.anteprima) + '" alt="">' : '<b>' + drsEsc(a.nome || 'File') + '</b>') + '<button type="button" aria-label="Togli" onclick="event.stopPropagation();DRS_ALL.l.splice(' + i + ',1);drsCvAllPaint()">✕</button></span>';
  }).join('');
}
/* nella chat dell'agente: gli stessi attrezzi sotto ai messaggi */
function drsAgAttrezzi(html, m){
  try{
    if (!m || !m.id || !m.testo) return html;
    const mio = m.direzione === 'in';
    const r = mio
      ? '<div class="drs-at io"><button type="button" aria-label="Copia" onclick="event.stopPropagation();drsAgCopia(this)">' + drsSvg('copia') + '</button><button type="button" aria-label="Modifica e riparti da qui" onclick="event.stopPropagation();drsAgModifica(this)">' + drsSvg('matita') + '</button></div>'
      : '<div class="drs-at lui"><button type="button" aria-label="Copia" onclick="event.stopPropagation();drsAgCopia(this)">' + drsSvg('copia') + '</button><button type="button" class="drs-v" aria-label="Mi piace" onclick="event.stopPropagation();drsAgVota(1,this)">' + drsSvg('su') + '</button><button type="button" class="drs-v" aria-label="Non mi piace" onclick="event.stopPropagation();drsAgVota(-1,this)">' + drsSvg('giu') + '</button></div>';
    const i = html.indexOf('</div>', html.indexOf('<small>'));
    /* 0.9.357: il pollice resta acceso con il voto che hai dato a questa risposta (agente-voti.js) */
    const rr = (!mio && typeof agvStatoRiga === 'function') ? agvStatoRiga(r, m) : r;
    return i < 0 ? html : html.slice(0, i) + rr + html.slice(i);
  }catch(_){ return html; }
}
function drsAgTesto(btn){ const m = btn.closest('.ag-m'), b = m && m.querySelector('.ag-b'); return b ? (b.innerText || b.textContent || '').trim() : ''; }
function drsAgCopia(btn){ drsCopiaTesto(drsAgTesto(btn)); }
function drsAgVota(v, btn){ drsVoto(v, drsAgTesto(btn), 'agente', btn); }
/* l'agente tiene la conversazione sul server: la correzione parte con un segno che lui capisce (e che a schermo non si vede) */
function drsAgModifica(btn){
  const t = document.getElementById('agTesto'); if (!t) return;
  t.value = drsAgTesto(btn);
  try{ if (typeof agCampoCresce === 'function') agCampoCresce(t); if (typeof agCompStato === 'function') agCompStato(); }catch(_){ }
  DRS_ORA.correzione = true;
  try{ t.focus(); t.setSelectionRange(t.value.length, t.value.length); }catch(_){ }
  drsVibra(10);
}

/* ---------------------------------------------------------------- la prima volta in una pagina */
const DRS_VISTE = 'fl_pagine_viste';
const DRS_PAGINE = {
  's-suoni': ['🎧', 'I suoni', 'Musica e suoni per concentrarti, rilassarti e dormire.', 'Scegli un suono, oppure crea un programma che parte da solo.'],
  's-sounds': ['🎧', 'I suoni', 'Musica e suoni per concentrarti, rilassarti e dormire.', 'Scegli un suono, oppure crea un programma che parte da solo.'],
  's-note': ['📝', 'Le tue note', 'Qui scrivi quello che vuoi: si salva da solo mentre scrivi.', 'Selezionando una riga la sposti nel caveau, così non ti distrae.'],
  's-notion': ['🗺️', 'Il piano', 'Le stesse schede del pannello nella Mappa, in una pagina tutta tua.', 'Una spunta qui vale anche là.'],
  's-respiro': ['🌬️', 'Il respiro', 'Pochi minuti per ritrovare la concentrazione o prendere sonno.', 'Sceglilo prima di una sessione, o quando ti senti agitato.'],
  's-friends': ['👥', 'Gli amici', 'Il feed, le sfide e la lega: arrivare al sogno pesa meno in compagnia.', 'Da qui puoi anche mandare regali e sfidare qualcuno a duello.'],
  's-negozio': ['🪙', 'Il negozio', 'Qui spendi le monete che guadagni facendo le tappe.', 'Le protezioni salvano la serie quando salti un giorno.'],
  's-partita': ['⚽', 'La partita', 'Il nuovo te contro il vecchio te: ogni scelta di oggi è un punto.', 'Finisci una sessione per segnare. Se molli, segna lui.'],
  's-agente': ['🤖', 'Il tuo agente', 'Conosce il tuo sogno e i tuoi dati: chiedigli quello che vuoi.', 'Può riscrivere il piano e aiutarti quando sei fuori rotta.'],
  's-orizzonti': ['🔭', 'Gli orizzonti', 'Dal sogno a oggi: l’anno, il trimestre, il mese, la settimana.', 'Scrivi un obiettivo per ogni periodo, e la giornata prende senso.'],
  's-memento': ['⌛', 'La tua vita in settimane', 'Ogni casella è una settimana. Le nere sono passate.', 'Tocca una settimana per scriverci una pagina di diario.'],
  's-dopamina': ['⛽', 'Il tuo carburante', 'Le app che ti svuotano lo fanno calare, le pause vere lo ricaricano.', 'Guardalo quando non hai voglia di cominciare: spesso il motivo è qui.'],
  's-fullfocus': ['🌱', 'Full Focus', 'Scegli quanto tempo: il telefono resta bloccato fino alla fine.', 'Ogni sessione finita è un punto per il nuovo te.']
};
function drsViste(){ try{ return JSON.parse(localStorage.getItem(DRS_VISTE) || '{}') || {}; }catch(_){ return {}; } }
function drsPagina(id){
  const p = DRS_PAGINE[id]; if (!p) return;
  try{ if (localStorage.getItem('fl_onboarded') !== '1') return; }catch(_){ return; }
  if (typeof GT !== 'undefined' && GT.on) return;
  if (typeof GN !== 'undefined' && GN.on) return;
  const v = drsViste(); if (v[id]) return;
  v[id] = Date.now();
  try{ localStorage.setItem(DRS_VISTE, JSON.stringify(v)); }catch(_){ }
  setTimeout(function(){
    const cur = document.querySelector('.screen.active'); if (!cur || cur.id !== id) return;
    if (document.body.classList.contains('sheet-aperto')) return;
    let w = document.getElementById('drsPg'); if (w) w.remove();
    w = document.createElement('div'); w.id = 'drsPg';
    w.innerHTML = '<div class="drs-pg-velo" onclick="drsPaginaVia()"></div><div class="drs-pg-c"><img src="img/genio/genio-saluta.png" alt=""><div class="drs-pg-b"><b>' + drsEsc(p[1]) + '</b><p>' + drsEsc(p[2]) + '</p><p>' + drsEsc(p[3]) + '</p><button type="button" onclick="drsPaginaVia()">Ho capito</button></div></div>';
    (document.getElementById('phone') || document.body).appendChild(w);
    drsVibra(8);
  }, 550);
}
function drsPaginaVia(){ const w = document.getElementById('drsPg'); if (w){ w.classList.add('via'); setTimeout(function(){ w.remove(); }, 220); } }
document.addEventListener('fl:screen', function(e){ try{ drsPagina(e && e.detail); }catch(_){ } });

/* ---------------------------------------------------------------- il finestrino dell'aereo */
/* 0.9.321, Andrea: "l'animazione del finestrino che apre la mappa del mondo, come SweetCase": il finestrino si avvicina fino
   a passarci attraverso, le nuvole corrono, e dietro c'e' la cartina. Disegno e colori sono i nostri. */
const DRS_FIN = '<svg class="drs-fin-a" viewBox="0 0 240 320" aria-hidden="true"><defs><linearGradient id="drsCielo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0075E3"/><stop offset="1" stop-color="#BCE0FF"/></linearGradient><clipPath id="drsVetro"><rect x="26" y="26" width="188" height="268" rx="94"/></clipPath></defs>'
  + '<g clip-path="url(#drsVetro)"><rect width="240" height="320" fill="url(#drsCielo)"/>'
  + '<g class="drs-nu a"><ellipse cx="62" cy="96" rx="34" ry="15" fill="#fff"/><ellipse cx="84" cy="86" rx="24" ry="14" fill="#fff"/></g>'
  + '<g class="drs-nu b"><ellipse cx="170" cy="166" rx="40" ry="17" fill="#fff" opacity=".92"/><ellipse cx="146" cy="176" rx="26" ry="12" fill="#fff" opacity=".92"/></g>'
  + '<g class="drs-nu c"><ellipse cx="70" cy="232" rx="30" ry="13" fill="#fff" opacity=".85"/></g>'
  + '<path d="M104 330L142 188c3-10 12-14 18-8l6 6-22 144z" fill="#F4F8FF" stroke="#001E44" stroke-width="3"/><path d="M142 188l8-22 14 6-4 14z" fill="#E63946" stroke="#001E44" stroke-width="3"/></g>'
  + '<rect x="26" y="26" width="188" height="268" rx="94" fill="none" stroke="#8CC6FF" stroke-width="6"/><rect x="12" y="12" width="216" height="296" rx="108" fill="none" stroke="#3F6FA8" stroke-width="9"/>'
  + '<rect x="84" y="27" width="72" height="14" rx="7" fill="#3F6FA8"/></svg>';
function drsFinestrino(poi){
  let meno = false; try{ meno = window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  if (meno || document.getElementById('drsFin')){ poi(); return; }
  const w = document.createElement('div'); w.id = 'drsFin'; w.innerHTML = DRS_FIN;
  (document.getElementById('phone') || document.body).appendChild(w);
  drsVibra(10);
  const svg = w.firstChild;
  try{
    const zoom = svg.animate([{ transform: 'scale(.86)', offset: 0 }, { transform: 'scale(1)', offset: .32, easing: 'cubic-bezier(.6,0,.9,.4)' }, { transform: 'scale(9)', offset: 1 }], { duration: 1500, fill: 'forwards', easing: 'ease-out' });
    /* a meta' volo la cartina e' gia' pronta sotto */
    setTimeout(function(){ try{ poi(); const f = document.getElementById('mpFull'); (document.getElementById('phone') || document.body).appendChild(w); if (f) f.style.visibility = 'visible'; }catch(_){ } }, 700);
    const velo = w.animate([{ opacity: 1, offset: 0 }, { opacity: 1, offset: .72 }, { opacity: 0, offset: 1 }], { duration: 1500, fill: 'forwards' });
    velo.onfinish = function(){ w.remove(); };
    void zoom;
  }catch(_){ w.remove(); poi(); }
}
/* entrando in Full Focus (dal pulsante e rispondendo alla chiamata dei sogni) si passa dal finestrino */
(function(){
  const monta = function(){
    const o = window.stGoFocus; if (typeof o !== 'function' || o.__fin) return;
    const nuovo = function(){ const a = arguments, t = this; drsFinestrino(function(){ o.apply(t, a); }); };
    nuovo.__fin = true; window.stGoFocus = nuovo;
    /* 0.9.326, Andrea: "non ha sempre l'animazione del finestrino, invece dovrebbe averla sempre": vale per ogni strada che entra in Full Focus. Se una sessione e' gia' in corso non si sta entrando, si sta tornando */
    const ff = window.ffOpen;
    if (typeof ff === 'function' && !ff.__fin){
      const n3 = function(){ const a = arguments, t = this; let inCorso = false; try{ inCorso = !!(typeof FF !== 'undefined' && FF.run); }catch(_){ } if (inCorso || document.getElementById('s-focus-pass')) return ff.apply(t, a); drsFinestrino(function(){ ff.apply(t, a); }); };
      n3.__fin = true; window.ffOpen = n3;
    }
    const m = window.mpOpen;
    if (typeof m === 'function' && !m.__viaggio){
      const n2 = function(){ const a = arguments, t = this; if (document.getElementById('mpFull')) return m.apply(t, a); drsViaggio(function(){ m.apply(t, a); }); };
      n2.__viaggio = true; window.mpOpen = n2;
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else setTimeout(monta, 0);
})();

/* ---------------------------------------------------------------- la rotta sulla cartina, come nei film di avventura */
/* 0.9.322, Andrea: aprendo la mappa si rivive il viaggio: l'aereo vola e dietro di lui si disegna la linea rossa, dal giorno in cui
   sei partito a oggi. La cartina e' quella vera del viaggio, invecchiata con un filtro. Tocca per saltare. */
function drsViaggio(poi){
  let meno = false; try{ meno = window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  let s = null; try{ s = rtStato(); }catch(_){ }
  if (meno || !s || !s.da || !s.a || typeof rtMappaHtml !== 'function' || document.getElementById('drsVg')){ poi(); return; }
  const w = document.createElement('div'); w.id = 'drsVg';
  (document.getElementById('phone') || document.body).appendChild(w);
  const L = Math.max(280, w.clientWidth || 360), H = Math.max(420, w.clientHeight || 700);
  w.innerHTML = '<div class="drs-vg-m">' + rtMappaHtml(s.da, s.a, 'satellite', L, H, []) + '</div><div class="drs-vg-vel"></div>'
    + '<div class="drs-vg-t"><small>Il tuo viaggio</small><b>' + drsEsc((s.da.nome || '').split(',')[0]) + ' \u2192 ' + drsEsc((s.a.nome || '').split(',')[0]) + '</b></div>';
  const finito = function(){ if (!w.parentNode) return; clearTimeout(fine); poi(); w.classList.add('via'); (document.getElementById('phone') || document.body).appendChild(w); setTimeout(function(){ w.remove(); }, 420); };
  let fine = setTimeout(finito, 3200);
  w.addEventListener('click', finito);
  const orig = w.querySelector('.rt-path');
  if (!orig || !orig.getTotalLength){ finito(); return; }
  const svg = orig.ownerSVGElement, NS = 'http://www.w3.org/2000/svg';
  const linea = document.createElementNS(NS, 'path');
  linea.setAttribute('d', orig.getAttribute('d'));
  linea.setAttribute('fill', 'none'); linea.setAttribute('stroke', '#E63946'); linea.setAttribute('stroke-width', '5'); linea.setAttribute('stroke-linecap', 'round');
  svg.appendChild(linea);
  const aereo = document.createElementNS(NS, 'g');
  aereo.innerHTML = '<path d="M0-16 3-5 16 3V7L3 3 2 11 6 14V17L0 15-6 17V14L-2 11-3 3-16 7V3L-3-5Z" fill="#fff" stroke="#001E44" stroke-width="1.500"/>';
  svg.appendChild(aereo);
  const tot = linea.getTotalLength();
  let pct = .4; try{ pct = Math.max(.08, Math.min(1, hdPercorso().pct || 0)); }catch(_){ }
  linea.style.strokeDasharray = tot + ' ' + tot;
  const t0 = performance.now(), D = 2300;
  const giro = function(t){
    if (!w.parentNode) return;
    const k = Math.min(1, (t - t0) / D), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2, l = tot * pct * e;
    linea.style.strokeDashoffset = String(tot - l);
    const p = linea.getPointAtLength(l), q = linea.getPointAtLength(Math.min(tot, l + 2));
    aereo.setAttribute('transform', 'translate(' + p.x + ' ' + p.y + ') rotate(' + (Math.atan2(q.y - p.y, q.x - p.x) * 180 / Math.PI + 90) + ')');
    if (k < 1) requestAnimationFrame(giro); else { clearTimeout(fine); fine = setTimeout(finito, 450); }
  };
  requestAnimationFrame(giro);
}

/* ---------------------------------------------------------------- le icone sulla Home */
async function drsIconaHome(id, label, target, emoji){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pinShortcut){ drsToast('Disponibile solo nell’app installata'); return; }
    const r = await NATIVE.pinShortcut({ id: id, label: String(label || '').slice(0, 24), target: target, emoji: emoji || '' });
    if (r && r.already) drsToast('L’icona è già sulla schermata Home');
    else if (r && r.ok) drsToast('Conferma sul telefono per aggiungere l’icona');
    else drsToast('Questo telefono non permette di aggiungere icone');
  }catch(_){ drsToast('L’icona non si è potuta creare'); }
}
function drsPianoPagina(id){
  try{ if (typeof ntApri !== 'function') return; ntApri(0); const f = document.getElementById('ntFrame'); if (f) f.setAttribute('src', 'notion/index.html?v=' + Date.now() + '#p=' + encodeURIComponent(id)); }catch(_){ }
}

/* ---------------------------------------------------------------- i popover e la gerarchia */
/* 0.9.322, Andrea: "nei popover le cose ben distanziate, con un'emoji per separare i paragrafi": un blocco per idea */
function flInfoRighe(l){
  return '<div class="fl-info">' + l.map(function(r){ return '<div><span aria-hidden="true">' + r[0] + '</span><b>' + r[1] + '</b><p>' + r[2] + '</p></div>'; }).join('') + '</div>';
}
/* i blocchi di una pagina o di un foglio compaiono quando ci si arriva scorrendo, come le sezioni del tema */
/* 0.9.349, Andrea: "la timeline del foglio deve animarsi man mano che scorro, come le sezioni GSAP del tema: il primo blocco si vede, gli
   altri troncati con una sfumatura e si accendono scorrendo, cosi' non vieni sopraffatto". Come ScrollTrigger con scrub: ogni blocco ha
   un'opacita' legata alla sua posizione nel foglio. Se il foglio non scorre (pochi blocchi), si accendono uno alla volta da soli. */
function flScrubRivela(root, sel){
  if (!root) return;
  const l = Array.prototype.slice.call(root.querySelectorAll(sel)).filter(function(x){ return !x.hidden; });
  if (l.length < 2) return;
  let box = root; while (box && box !== document.body && !/auto|scroll/.test(getComputedStyle(box).overflowY)) box = box.parentElement;
  if (!box || box === document.body) box = null;
  const metti = function(el, p){ p = Math.max(0, Math.min(1, p)); el.style.opacity = String(.14 + .86 * p); el.style.transform = 'translateY(' + Math.round((1 - p) * 18) + 'px)'; el.style.filter = p < 1 ? 'blur(' + ((1 - p) * 2.5).toFixed(1) + 'px)' : ''; };
  l.forEach(function(el, i){ el.style.transition = 'opacity .35s ease,transform .35s ease,filter .35s ease'; if (i) metti(el, 0); });
  const scorre = box && box.scrollHeight > box.clientHeight + 24;
  if (!scorre){ l.slice(1).forEach(function(el, i){ setTimeout(function(){ metti(el, 1); }, 650 + i * 520); }); return; }
  const giro = function(){
    const bb = box.getBoundingClientRect(), fondo = bb.top + bb.height;
    l.forEach(function(el, i){ if (!i) return; const t = el.getBoundingClientRect().top; metti(el, (fondo - t) / (bb.height * .38)); });
  };
  box.addEventListener('scroll', giro, { passive: true });
  setTimeout(giro, 60); setTimeout(giro, 450);
}
function flRivela(root, sel){
  if (!root || !('IntersectionObserver' in window)) return;
  const l = root.querySelectorAll(sel); if (!l.length) return;
  /* ridisegnata per un interruttore toccato: non c'e' niente di nuovo da svelare, e far ricomparire tutto sarebbe un lampo */
  const ora = Date.now(); if (root.__riv && ora - root.__riv < 120000){ root.__riv = ora; return; } root.__riv = ora;
  let box = root; while (box && box !== document.body && !(box.scrollHeight > box.clientHeight + 4 && /auto|scroll/.test(getComputedStyle(box).overflowY))) box = box.parentElement;
  const io = new IntersectionObserver(function(v){ v.forEach(function(e){ if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } }); }, { root: (box && box !== document.body) ? box : null, threshold: .12 });
  l.forEach(function(el, i){ el.classList.add('fl-riv'); if (i < 2) el.classList.add('in'); else io.observe(el); });
}

/* ---------------------------------------------------------------- le bolle sulle schede in basso */
/* 0.9.322, Andrea: "come su Clash Royale: una bolla rossa sulla scheda quando c'e' qualcosa da vedere" */
const DRS_BDG = 'fl_bolla_visti';
/* 0.9.326, Andrea: "non si capisce qual e' l'elemento da guardare: ricompare appena esco". Una bolla adesso ha un suo blocco e un suo segno di "visto".
   Entrando nella scheda il blocco si porta in vista e il resto si oscura; da li' in poi quella cosa non conta piu', finche' non ne arriva una nuova. */
function drsFirma(s){ let h = 0; s = String(s || ''); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return String(h); }
function drsBollaLista(visti){
  const l = { rotta: [], mappa: [], sveglia: [], profilo: [] };
  const oggi = (typeof etaOggiK === 'function') ? etaOggiK() : '';
  /* 0.9.350: il nuovo episodio uscito oggi, finche' non l'hai visto (episodi.js, epiAnnuncioPronto) */
  try{ const a = (typeof epiAnnuncioPronto === 'function') ? epiAnnuncioPronto() : null; if (a && visti.epi !== String(a.n)) l.rotta.push({ k: 'epi', v: String(a.n), sel: '#epiCard' }); }catch(_){ }
  try{ if (NVS.rientro && visti.rientro !== drsFirma(NVS.rientro)) l.rotta.push({ k: 'rientro', v: drsFirma(NVS.rientro), sel: '.nvs-s.rotta .nv-rientro' }); }catch(_){ }
  try{ if (((typeof rvStato === 'function' && rvStato() === 'da-fare') || (typeof rvpDovuta === 'function' && rvpDovuta())) && visti.rv !== oggi) l.rotta.push({ k: 'rv', v: oggi, sel: '.nvs-s.rv .drs-rv' }); }catch(_){ }
  /* la data che si e' spostata oggi: finche' non l'hai vista */
  try{ const sp = (typeof etaSpostamento === 'function') ? etaSpostamento() : null; if (sp && sp.stato === 'ok' && sp.giorni && visti.data !== oggi && !l.rotta.length) l.rotta.push({ k: 'data', v: oggi, sel: '#nvArrCard' }); }catch(_){ }
  /* la tappa di oggi da fare */
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}, k = (typeof sdK === 'function') ? sdK(Date.now()) : ''; if (k && !(g[k] > 0) && visti.mappa !== k) l.mappa.push({ k: 'mappa', v: k, sel: '#mppSentiero .sd-nodo.corrente' }); }catch(_){ }
  try{ if (typeof wkDaVedere === 'function' && wkDaVedere()) l.profilo.push({ k: 'wk', sel: '#pfrNuovo' }); }catch(_){ }
  try{ ((FR.amici && FR.amici.doni) || []).forEach(function(){ l.profilo.push({ k: 'dono' }); }); }catch(_){ }
  return l;
}
function drsBollaVisti(){ try{ return JSON.parse(localStorage.getItem(DRS_BDG) || '{}') || {}; }catch(_){ return {}; } }
function drsBollaConti(){
  const l = drsBollaLista(drsBollaVisti()), c = {};
  Object.keys(l).forEach(function(k){ c[k] = l[k].length; });
  return c;
}
/* il faro: il blocco nella luce, il resto al buio. Un tocco lo chiude, e dopo tre secondi va via da solo */
function drsFaro(sel, n){
  const el0 = sel ? document.querySelector(sel) : null;
  if (!el0 || !el0.offsetParent || document.getElementById('gnTour')) return;
  try{ el0.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ }
  setTimeout(function(){
    /* la scheda si ridisegna entrando: il blocco si cerca di nuovo, dopo lo scorrimento */
    const el = document.querySelector(sel); if (!el) return;
    const r = el.getBoundingClientRect(); if (!r.width || document.getElementById('drsFaro')) return;
    const w = document.createElement('div'); w.id = 'drsFaro';
    const m = 6, cs = getComputedStyle(el);
    w.innerHTML = '<div class="drs-faro-b" style="left:' + (r.left - m) + 'px;top:' + (r.top - m) + 'px;width:' + (r.width + m * 2) + 'px;height:' + (r.height + m * 2) + 'px;border-radius:' + (parseFloat(cs.borderRadius) + m || 18) + 'px"><i class="nv-bolla">' + (n > 9 ? '9+' : n) + '</i></div>';
    const via = function(){ w.remove(); };
    w.addEventListener('click', via);
    document.body.appendChild(w);
    setTimeout(via, 3000);
  }, 450);
}
function drsBollaPaint(){
  const c = drsBollaConti();
  Object.keys(c).forEach(function(k){
    const b = document.getElementById('nav-' + k); if (!b) return;
    let i = b.querySelector('.nv-bolla');
    /* la scheda in cui sei non ha bisogno della bolla */
    if (!c[k] || b.classList.contains('on')){ if (i) i.remove(); return; }
    if (!i){ i = document.createElement('i'); i.className = 'nv-bolla'; b.appendChild(i); }
    i.textContent = c[k] > 9 ? '9+' : String(c[k]);
  });
}
document.addEventListener('fl:tab', function(e){
  const tab = e.detail;
  setTimeout(function(){
    try{
      const v = drsBollaVisti(), voci = drsBollaLista(v)[tab] || [];
      if (!voci.length) return;
      const prima = voci.filter(function(x){ return x.sel; })[0];
      voci.forEach(function(x){ if (x.v) v[x.k] = x.v; });
      localStorage.setItem(DRS_BDG, JSON.stringify(v));
      if (prima) drsFaro(prima.sel, voci.length);
    }catch(_){ }
    drsBollaPaint();
  }, 450);
  setTimeout(drsBollaPaint, 300);
});
setInterval(function(){ try{ drsBollaPaint(); }catch(_){ } }, 45000);
setTimeout(function(){ try{ drsBollaPaint(); }catch(_){ } }, 3500);

/* il video a schermo intero puo' girare, e all'uscita l'app torna dritta */
document.addEventListener('fullscreenchange', function(){
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.orientamento) NATIVE.orientamento({ libero: !!document.fullscreenElement }); }catch(_){ }
});

/* ---------------------------------------------------------------- la voce dell'Io futuro, dalla dettatura */
/* 0.9.321, Andrea: "se parla gia' per la trascrizione vocale e ha dato il consenso, niente file MP3 da caricare". Con il consenso i pezzi
   della dettatura (solo quelli con l'AI, gli unici in cui l'app registra) restano sul telefono; a un minuto di voce si manda tutto al
   servizio che la impara, poi i pezzi si cancellano. Si spegne dalle impostazioni, e allora si cancellano subito. */
const DRV = { K: 'fl_voce_dettatura', SEC: 'fl_voce_dett_sec', MIN: 60, MAX: 180, invio: false };
function drvOn(){ try{ return localStorage.getItem(DRV.K) === '1'; }catch(_){ return false; } }
function drvSec(){ try{ return +localStorage.getItem(DRV.SEC) || 0; }catch(_){ return 0; } }
function drvDb(){
  return new Promise(function(ok, no){
    const r = indexedDB.open('fl_voce', 1);
    r.onupgradeneeded = function(){ r.result.createObjectStore('pezzi', { autoIncrement: true }); };
    r.onsuccess = function(){ ok(r.result); }; r.onerror = function(){ no(r.error); };
  });
}
async function drvAggiungi(blob, mime, sec){
  if (!drvOn() || !(sec >= 4) || drvSec() >= DRV.MAX) return;
  try{ const st = (typeof IC !== 'undefined' && IC.stato) || null; if (st && st.voce) return; }catch(_){ }
  try{
    const b64 = await dtBase64(blob), db = await drvDb();
    await new Promise(function(ok, no){ const t = db.transaction('pezzi', 'readwrite'); t.objectStore('pezzi').add({ audio: b64, mime: mime, nome: 'dettatura-' + Date.now() + '.webm', sec: sec }); t.oncomplete = ok; t.onerror = no; });
    db.close();
    const tot = drvSec() + sec;
    localStorage.setItem(DRV.SEC, String(tot));
    if (tot >= DRV.MIN) drvInvia();
  }catch(_){ }
}
async function drvCancella(){
  try{ const db = await drvDb(); await new Promise(function(ok){ const t = db.transaction('pezzi', 'readwrite'); t.objectStore('pezzi').clear(); t.oncomplete = ok; t.onerror = ok; }); db.close(); }catch(_){ }
  try{ localStorage.removeItem(DRV.SEC); }catch(_){ }
}
async function drvInvia(){
  if (DRV.invio || !drvOn() || typeof icApi !== 'function') return;
  DRV.invio = true;
  try{
    const db = await drvDb();
    const l = await new Promise(function(ok){ const q = db.transaction('pezzi').objectStore('pezzi').getAll(); q.onsuccess = function(){ ok(q.result || []); }; q.onerror = function(){ ok([]); }; });
    db.close();
    if (!l.length) return;
    const j = await icApi('/api/focuslock/iofuturo/voce', { dev: icDev(), consenso: true, files: l.map(function(f){ return { audio: f.audio, mime: f.mime, nome: f.nome }; }) }, 150000);
    if (j && j.ok){
      try{ localStorage.setItem('fl_io_voce_ver', IC_VOCE_VER); icVoceSecSalva(999); if (IC.stato) Object.assign(IC.stato, { voce: true, fonte: 'dettatura' }); }catch(_){ }
      await drvCancella();
    }
  }catch(_){ } finally { DRV.invio = false; }
}
/* il consenso: si chiede quando si accende la dettatura con l'AI, una volta, ed e' sempre revocabile */
function drvConsensoApri(){
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Vuoi parlare con il tuo Io futuro con la tua voce?</h3>'
    /* 0.9.343, Andrea: "sei righe di paragrafo attaccate al pulsante Acconsento". Tre righe con l'emoji, poi i pulsanti staccati */
    + flInfoRighe([
        ['🎙️', 'Impara mentre detti', 'Niente file da caricare.'],
        ['🔒', 'Solo per le chiamate', 'La tua voce va a ElevenLabs e serve solo al tuo Io futuro.'],
        ['↩️', 'Cambi idea quando vuoi', 'Da questa stessa impostazione.']
      ])
    + '<div class="drv-btns"><button type="button" class="nvs-cta" onclick="drvScegli(true)">Acconsento</button><button type="button" class="nvs-cta sec" onclick="drvScegli(false)">No, grazie</button></div></div>');
  try{ if (!document.getElementById('drvCss')){ const st = document.createElement('style'); st.id = 'drvCss'; st.textContent = '.drv-btns{display:flex;flex-direction:column;gap:10px;margin-top:26px}.drv-btns .nvs-cta{margin:0}'; document.head.appendChild(st); } }catch(_){ }
}
function drvScegli(si){
  try{ localStorage.setItem(DRV.K, si ? '1' : '0'); }catch(_){ }
  if (!si) drvCancella();
  try{ inSheetChiudi(); }catch(_){ }
  drvRiga();
}
function drvRiga(){
  const b = document.getElementById('psDictVoce'); if (b) b.classList.toggle('on', drvOn());
}
function drvToggle(){ if (drvOn()) drvScegli(false); else drvConsensoApri(); }

/* ---------------------------------------------------------------- lo stile */
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.nvs{margin:0 0 14px}',
    '.drs-rv{box-sizing:border-box;height:100%;min-height:300px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:28px 22px;border-radius:24px;background:radial-gradient(120% 90% at 50% 0%,#24407A 0%,#14234A 55%,#0A1632 100%);color:#fff;text-align:center;cursor:pointer}.drs-rv.settimana{background:radial-gradient(120% 90% at 50% 0%,#127A8A,#0B3F5A 55%,#0A1632)}.drs-rv.mese{background:radial-gradient(120% 90% at 50% 0%,#1478E0,#0A3F86 55%,#0A1632)}.drs-rv.trimestre,.drs-rv.anno{background:radial-gradient(120% 90% at 50% 0%,#E63946,#7A1B26 50%,#0A1632)}'
      + '.drs-rv-ico{font-size:56px;line-height:1;filter:drop-shadow(0 6px 16px rgba(140,198,255,.45))}.drs-rv small{display:block;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}.drs-rv h3{margin:10px auto 0;max-width:290px;font:800 21px/1.35 var(--font-display);color:#fff}.drs-rv-serie{margin:12px 0 0;font:700 13.5px var(--font-body);color:#BCE0FF}.drs-rv .nvs-play{margin-top:0;min-width:150px;justify-content:center}',
      /* 0.9.340: aria fra la luna, il testo e il pulsante */
      '.drs-rv{gap:0!important;padding:36px 24px 32px!important}.drs-rv-ico{margin-bottom:26px}.drs-rv-testo{margin-bottom:30px}',
    '.nvs-car{display:flex;gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch}.nvs-car::-webkit-scrollbar{display:none}',
    '.nvs-s{flex:0 0 100%;box-sizing:border-box;scroll-snap-align:center;display:flex;min-width:0}.nvs-s > *{flex:1;min-width:0}',
    '.nvs-dots{display:flex;justify-content:center;gap:7px;margin:12px 0 0}.nvs-dots i{width:7px;height:7px;border-radius:50%;background:#C9D9EE;transition:background .2s,transform .2s}.nvs-dots i.on{background:#0075E3;transform:scale(1.25)}body.dark .nvs-dots i{background:#2C4170}body.dark .nvs-dots i.on{background:#8CC6FF}',
    /* la slide del ritardo: il bordo rosso, e il titolo che gira */
    '#drsFaro{position:fixed;inset:0;z-index:9990}.drs-faro-b{position:fixed;box-shadow:0 0 0 200vmax rgba(0,19,43,.68),0 0 22px 4px rgba(140,198,255,.75);pointer-events:none}.drs-faro-b .nv-bolla{position:absolute;left:auto;right:-8px;top:-8px;width:24px;height:24px;min-width:0;padding:0;display:flex;align-items:center;justify-content:center;border-radius:50%;background:#E63946;color:#fff;font:800 12.5px var(--font-body);font-style:normal}',
    '.nvs-car:has(.nvs-s.rotta){margin:-40px -40px -34px;padding:40px 40px 34px;gap:80px;scroll-padding:40px;pointer-events:none}.nvs-car:has(.nvs-s.rotta) > .nvs-s{pointer-events:auto}.nvs-car:has(.nvs-s.rotta){touch-action:pan-x pan-y}.nvs-s.rotta .nv-rientro{animation:nvGlowRosso 1.6s ease-in-out infinite}',
    '.nvs-s.rotta .nv-rientro{box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;border:2px solid #E63946;background:var(--card,#fff)}body.dark .nvs-s.rotta .nv-rientro{background:#12203A}',
    '.nv-rot{display:grid;justify-items:center;margin-top:12px}.nv-rot > b{grid-area:1/1;margin:0 !important;animation:nvRot 7s ease-in-out infinite;opacity:0}.nv-rot > b.b2{animation-delay:3.5s}@keyframes nvRot{0%{opacity:0;transform:translateY(14px) rotateX(-60deg)}6%,44%{opacity:1;transform:none}50%,100%{opacity:0;transform:translateY(-14px) rotateX(60deg)}}',
    /* la storia: la locandina di una serie */
    '.nvs-tv{position:relative;box-sizing:border-box;min-height:356px;border-radius:24px;overflow:hidden;background:radial-gradient(120% 80% at 50% 0,#1A3A6B,#04122A 62%,#000 100%);color:#fff;display:flex;flex-direction:column;justify-content:flex-end;cursor:pointer}',
    '.nvs-tv-art{position:absolute;left:0;right:0;top:0;height:190px;display:flex;align-items:center;justify-content:center}.nvs-tv-art .epi-vis{min-height:0;height:100%;transform:scale(.8)}',
    '.nvs-tv-c{position:relative;display:flex;flex-direction:column;align-items:center;text-align:center;padding:96px 20px 18px;background:linear-gradient(180deg,rgba(0,0,0,0),rgba(0,0,0,.72) 44%,#000 100%)}',
    '.nvs-tv-c small{font:800 11.5px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#8CC6FF}.nvs-tv-c h3{margin:6px 0 10px;font:900 32px/1.08 var(--font-display);font-style:italic;color:#fff}',
    '.nvs-tv-ep{margin:0;font:600 14px var(--font-body);color:#fff}.nvs-tv-ep b{font-weight:800;color:#8CC6FF}.nvs-tv-r{margin:8px 0 0;max-width:32ch;font:500 13.5px/1.4 var(--font-body);color:#BFD3EC}',
    '.nvs-play{display:inline-flex;align-items:center;justify-content:center;gap:9px;margin-top:16px;padding:13px 28px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 15px var(--font-body);cursor:pointer}.nvs-play:active{transform:scale(.97)}',
    '.nvs-tv-tutti{margin-top:12px;font:700 13px var(--font-body);color:#BFD3EC}',
    '.nvs-ctl{box-sizing:border-box;padding:20px 18px;border-radius:24px;background:var(--card,#fff);border:1px solid var(--line);justify-content:center;display:flex;flex-direction:column;align-items:center;text-align:center;}.nvs-ctl > b{font:800 19px/1.25 var(--font-display);color:var(--navy)}body.dark .nvs-ctl > b{color:#fff}.nvs-ctl p{margin:8px 0 16px;font:500 14.5px/1.45 var(--font-body);color:var(--muted)}',
    '.nvs-ctl-az{background:linear-gradient(180deg,#C8EFFD 0%,#F0FBFF 100%)!important;border:1px solid #BCE0FF!important;padding:26px 18px 22px!important}.nvs-ctl-ico{display:block;font-size:40px;line-height:1;margin-bottom:12px}.nvs-ctl-az .nvs-ctl-h{margin:0 0 16px!important;color:#001E44!important}',
    '.nvs-ctl-az .nvs-ctl-box{margin:0 0 22px!important;padding:14px 16px;border-radius:16px;background:#fff;color:#33476A!important;box-shadow:0 2px 10px rgba(0,30,68,.06)}.nvs-ctl-az .nvs-cta.sec{background:#fff!important;border-color:#BCE0FF!important;color:#0075E3!important;margin-top:12px}.nvs-cta-e{font-size:18px;line-height:1}',
    '.nvs-ctl-min{background:linear-gradient(180deg,#FFFFFF 0%,#F0FBFF 42%,#C8EFFD 100%)!important;padding:24px 18px 20px!important}.nvs-ctl-min .nvs-ctl-h{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 28px!important}',
    '.nvs-ctl-i{flex:none;box-sizing:border-box;width:22px;height:22px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid #3F9FF4;border-radius:50%;background:#fff;color:#0075E3;font:800 12px/1 var(--font-body);cursor:pointer}',
    '.nvs-ctl-btns{display:flex;flex-direction:column;gap:12px}.nvs-ctl-btns .nvs-cta{margin:0!important;gap:10px;text-align:center;white-space:nowrap}.nvs-ctl-btns .nvs-cta > span:last-child{min-width:0;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .nvs-ctl-min{background:linear-gradient(180deg,#12264C 0%,#1A3C6E 100%)!important}body.dark .nvs-ctl-i{background:#0E1D3D;color:#8CC6FF;border-color:#3F9FF4}',
    'body.dark .nvs-ctl-az{background:linear-gradient(180deg,#1A3C6E 0%,#12264C 100%)!important;border-color:#2C4170!important}body.dark .nvs-ctl-az .nvs-ctl-h{color:#fff!important}body.dark .nvs-ctl-az .nvs-ctl-box{background:#0E1D3D;color:#D6E8FF!important}body.dark .nvs-ctl-az .nvs-cta.sec{background:#0E1D3D!important;border-color:#2C4170!important;color:#8CC6FF!important}',
    '.nvs-ctl ul{margin:12px 0 18px;padding:0;list-style:none;text-align:left}.nvs-ctl li{position:relative;padding:5px 0 5px 24px;font:600 14px/1.35 var(--font-body);color:var(--navy)}body.dark .nvs-ctl li{color:#E8F1FF}.nvs-ctl li::before{content:"";position:absolute;left:2px;top:11px;width:12px;height:7px;border-left:2.500px solid #0075E3;border-bottom:2.500px solid #0075E3;transform:rotate(-45deg)}',
    '.nvs-ctl-art{position:relative;height:120px;margin-bottom:10px}.nvs-ctl-art img{height:100%}.nvs-ctl-lock{position:absolute;right:-30px;top:8px;padding:4px 10px;border-radius:9px;background:linear-gradient(90deg,#E63946,#0075E3);color:#fff;font:800 11px var(--font-body);font-style:italic;text-transform:uppercase}',
    '.nvs-cta{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:52px;box-sizing:border-box;padding:12px 16px;border:0;border-radius:16px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 4px 0 #00459A}.nvs-cta:active{transform:translateY(3px);box-shadow:0 1px 0 #00459A}.nvs-cta.sec{margin-top:10px;background:none;border:2px solid #BCE0FF;color:#0075E3;box-shadow:none}body.dark .nvs-cta.sec{border-color:#2C4170;color:#8CC6FF}',
    '.drs-ri-ico{display:block;font-size:44px;text-align:center;margin-bottom:8px}.drs-ri .nvs-cta:first-of-type{margin-top:16px}',
    '.en-foglio > h3{box-sizing:border-box;padding:0 32px}',
    '.drs-ri .am-sh-title{display:block;margin:10px 26px 0}.drs-ri .am-sh-p{margin:10px auto 26px;max-width:30ch}.drs-ri .nvs-cta + .nvs-cta{margin-top:12px}',
    /* 0.9.349, Andrea: "l'emoji e' attaccata al titolo, 'Ho capito' e' attaccato al paragrafo, e il titolo deve stare distante dal contenuto" */
    '.fl-info{display:flex;flex-direction:column;gap:30px;margin:28px 0 36px}.fl-info > div{text-align:center}.fl-info span{display:block;font-size:32px;line-height:1.1}.fl-info b{display:block;margin-top:12px;font:800 16px var(--font-display);color:var(--navy)}body.dark .fl-info b{color:#fff}.fl-info p{margin:5px auto 0;max-width:32ch;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    '.fl-riv{opacity:0;transform:translateY(16px);transition:opacity .55s ease,transform .55s cubic-bezier(.2,.8,.2,1)}.fl-riv.in{opacity:1;transform:none}',
    '.nv-bolla{position:absolute;left:50%;top:0;margin-left:8px;min-width:18px;height:18px;padding:0 5px;box-sizing:border-box;border-radius:99px;background:#E63946;color:#fff;font:800 11px/18px var(--font-body);font-style:normal;text-align:center;box-shadow:0 0 0 2px var(--card,#fff);z-index:2;animation:nvBolla .35s cubic-bezier(.3,1.8,.5,1) both}@keyframes nvBolla{from{transform:scale(0)}to{transform:none}}#nav-rotta,#nav-mappa,#nav-sveglia,#nav-profilo{position:relative}',
    /* il volo sulla cartina */
    '#drsVg{position:fixed;inset:0;z-index:9994;background:#2A2118;overflow:hidden;transition:opacity .4s ease}#drsVg.via{opacity:0;pointer-events:none}.drs-vg-m{position:absolute;inset:0}.drs-vg-m .rt-tiles,.drs-vg-m .rt-linea{position:absolute;inset:0}.drs-vg-m .rt-linea{width:100%;height:100%}.drs-vg-m .rt-aereo,.drs-vg-m .rt-linea-tappe{display:none}.drs-vg-m .rt-tiles{filter:sepia(.75) saturate(.8) contrast(1.05) brightness(.92)}.drs-vg-vel{position:absolute;inset:0;pointer-events:none;box-shadow:inset 0 0 120px rgba(40,20,0,.75)}',
    '.drs-vg-t{position:absolute;left:0;right:0;bottom:calc(40px + env(safe-area-inset-bottom));text-align:center;color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.7)}.drs-vg-t small{display:block;font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase}.drs-vg-t b{display:block;margin-top:4px;font:800 24px var(--font-display)}',
    /* la chat */
    '.cv-b,.ag-b{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default}',
    '.drs-at{display:flex;gap:2px;margin:2px 0 8px}.drs-at.io{justify-content:flex-end}.drs-at button{display:flex;align-items:center;justify-content:center;width:34px;height:32px;padding:0;border:0;border-radius:9px;background:none;color:#8CA5C4;cursor:pointer}.drs-at button:active{background:rgba(140,198,255,.2)}.drs-at button.on{color:#0075E3}body.dark .drs-at button.on,#gnScena .drs-at button.on{color:#8CC6FF}',
    '.ag-m .drs-at{margin:4px 0 0}',
    '.cv-comp{align-items:flex-end}.drs-piu{flex:none;display:flex;align-items:center;justify-content:center;width:38px;height:38px;margin:0 2px 2px 0;padding:0;border:0;border-radius:50%;background:#E3F1FF;color:#0075E3;cursor:pointer}body.dark .drs-piu{background:#1B2C4F;color:#8CC6FF}',
    '#cvPill{margin-bottom:12px}#cvPill.vuota{margin-bottom:0}',
    '.drs-all{display:flex;gap:8px;overflow-x:auto;margin-bottom:8px}.drs-all-c{position:relative;flex:none;display:flex;align-items:center;max-width:170px;min-height:52px;padding:0 26px 0 10px;border-radius:12px;background:#E3F1FF;color:#0E2350}.drs-all-c img{width:52px;height:52px;margin-left:-10px;border-radius:12px;object-fit:cover}.drs-all-c b{font:700 12.5px var(--font-body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.drs-all-c button{position:absolute;right:3px;top:3px;width:20px;height:20px;padding:0;border:0;border-radius:50%;background:#0E2350;color:#fff;font-size:11px;cursor:pointer}',
    /* la prima volta in una pagina */
    '#drsPg{position:fixed;inset:0;z-index:9980;animation:drsPgIn .25s ease-out}#drsPg.via{opacity:0;transition:opacity .2s ease}@keyframes drsPgIn{from{opacity:0}to{opacity:1}}',
    '.drs-pg-velo{position:absolute;inset:0;background:rgba(0,19,43,.5)}.drs-pg-c{position:absolute;left:14px;right:14px;bottom:calc(92px + env(safe-area-inset-bottom));display:flex;align-items:flex-end;gap:4px}.drs-pg-c img{flex:none;width:88px;margin-right:-12px;position:relative;z-index:1;filter:drop-shadow(0 6px 12px rgba(0,0,0,.35))}',
    '.drs-pg-b{flex:1;min-width:0;padding:16px 16px 12px 22px;border-radius:20px;background:#fff;color:#0E2350;box-shadow:0 12px 30px rgba(0,20,60,.3)}.drs-pg-b b{display:block;margin-bottom:6px;font:800 18px var(--font-display);color:#0E2350}.drs-pg-b p{margin:0 0 6px;font:500 14px/1.4 var(--font-body);color:#14234A}.drs-pg-b button{display:block;margin:10px 0 0 auto;padding:9px 16px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13.5px var(--font-body);cursor:pointer}',
    /* il finestrino */
    '#drsFin{position:fixed;inset:0;z-index:9995;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 45%,#0B2A63,#001E44 70%);overflow:hidden;pointer-events:none}.drs-fin-a{width:66%;max-width:300px;transform-origin:50% 50%}',
    '.drs-nu{animation:drsNu 1.5s linear forwards}.drs-nu.b{animation-duration:1.1s}.drs-nu.c{animation-duration:1.3s}@keyframes drsNu{from{transform:translateX(26px)}to{transform:translateX(-46px)}}',
    /* le righe delle missioni di gruppo e il pulsante con il bordo, come Duolingo */
    '.as-mis-art{display:flex;align-items:center;justify-content:center;gap:16px;margin:-4px -4px 14px;padding:20px 8px;border-radius:16px;background:linear-gradient(135deg,#E3F1FF,#BCE0FF)}body.dark .as-mis-art{background:linear-gradient(135deg,#1A3A6B,#0F2A4A)}.as-mis-art .am-av{width:72px;height:72px;font-size:28px;box-shadow:0 0 0 3px #fff}',
    '.dso-mis-btn{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.dso-mis-btn button{min-height:50px;padding:10px 6px;border:2px solid #BCE0FF !important;border-radius:14px;background:var(--card,#fff) !important;color:#0E2350 !important;font:800 13.5px var(--font-body);box-shadow:0 3px 0 #BCE0FF;cursor:pointer}.dso-mis-btn button:active{transform:translateY(2px);box-shadow:0 1px 0 #BCE0FF}body.dark .dso-mis-btn button{background:#12203A !important;border-color:#3A4F78 !important;color:#fff !important;box-shadow:0 3px 0 #3A4F78}'
  ].join('\n');
  document.head.appendChild(st);
})();
