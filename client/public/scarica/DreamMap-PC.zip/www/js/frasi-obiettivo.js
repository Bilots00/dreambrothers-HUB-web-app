/* ===========================================================================================
   LE FRASI SUL TUO OBIETTIVO, SULLA SCHERMATA DI BLOCCO DEL TELEFONO (0.9.264, Premium)

   Andrea: la schermata di blocco del telefono (quella che vedi quando lo sblocchi, con la frase del
   giorno) per chi ha Premium puo' mostrare SOLO frasi allineate al suo obiettivo. Non preimpostate:
   le scrive un'AI (il server dell'agente, /api/focuslock/frasi-obiettivo) partendo da quello che la
   persona ha scritto: il sogno (anche quello scritto a mano nell'onboarding), "Chi saro'", il perche',
   i prossimi passi e cosa la frena. Frasi sull'identita' di chi ci arriva e sulle azioni che fa.
   Ventuno frasi = tre settimane di scorta: il telefono cambia frase da solo a mezzanotte (LockQuote).
   Si riscrivono quando il sogno cambia o quando la scorta finisce.
   (0.9.263 le aveva messe per sbaglio sulla schermata dei blocchi delle app: tolte.)
   =========================================================================================== */
const FO_K = 'fl_frasi_obiettivo';           // { on, frasi[], firma, at }
/* 0.9.337: anche le frasi gia' scelte e salvate perdono quella di Bob Marley sui soldi */
function foLeggi(){
  let o; try{ o = JSON.parse(localStorage.getItem(FO_K) || 'null') || { on: false, frasi: [] }; }catch(_){ o = { on: false, frasi: [] }; }
  if (Array.isArray(o.frasi)) o.frasi = o.frasi.filter(function(x){ const t = (typeof x === 'string' ? x : ((x && x.t) || '') + ' ' + ((x && x.a) || '')); return !/marley|povere|poveri|ricco non|uomo ricco/i.test(t); });
  return o;
}
function foScrivi(o){ try{ localStorage.setItem(FO_K, JSON.stringify(o)); }catch(_){ } }
function foPulisci(s, n){ return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n || 300); }
function foPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function foContesto(){
  const c = {};
  try{
    const d = (typeof gnDati === 'function') ? gnDati() : {};
    c.sogno = foPulisci((d.sognoK === 'scrivo' && d.sognoTesto) ? d.sognoTesto : (d.sognoTesto || d.sogno || ''), 300);
  }catch(_){ }
  try{ if (typeof ifIdentita === 'function'){ const i = ifIdentita(); c.chi = foPulisci(i.chiSaro, 200); c.perche = foPulisci(i.perche, 400); } }catch(_){ }
  try{ if (typeof dqOstacoli === 'function') c.freni = dqOstacoli().filter(function(o){ return o.w > 0; }).slice(0, 3).map(function(o){ return o.t; }).join('; '); }catch(_){ }
  try{
    const rm = JSON.parse(localStorage.getItem('fl_roadmap_agente') || 'null');
    const passi = rm && (rm.passi || rm.steps || rm.oggi || []);
    if (Array.isArray(passi)) c.passi = passi.slice(0, 6).map(function(p){ return typeof p === 'string' ? p : (p.t || p.titolo || p.testo || ''); }).filter(Boolean).join('; ');
  }catch(_){ }
  return c;
}
/* 0.9.280: "v2" nella firma, cosi' le frasi scritte dall'AI senza autore si riscrivono da sole */
function foFirma(c){ return ['v3', c.sogno, c.chi, c.perche].join('|').slice(0, 900); }
/** Chiede all'agente le frasi nuove (la stessa coda della chat: per gli account con il lavoratore
    sul VPS risponde lui, per gli altri il fornitore a crediti). La richiesta e la risposta non
    compaiono nella chat (agEScomponi, prefisso [frasi]). Torna l'elenco, o null (motivo in FO_ERR). */
let FO_ERR = '';
/* 0.9.280, Andrea: "stanno uscendo frasi a caso, senza virgolette, senza autore: scritte dall'AI. Sembra
   la mamma che ti dice cosa fare, non ha lo stesso effetto. Devono essere aforismi e citazioni VERE di
   persone celebri, allineate a chi devo diventare e a cosa devo fare. Anonimo solo come ultima spiaggia,
   una o due volte l'anno". */
function foRichiesta(c){
  return '[frasi] Scegli 21 citazioni per la mia schermata di blocco del telefono, una al giorno per tre settimane. '
    + 'Devono essere CITAZIONI VERE, dette o scritte davvero da persone celebri (imprenditori, atleti, scrittori, filosofi, scienziati, artisti), che puoi attribuire con sicurezza: niente frasi inventate da te, niente parafrasi spacciate per citazioni. '
    + 'Scegli quelle più allineate al mio sogno: a chi devo diventare per arrivarci (identità, convinzioni) e a quello che devo fare e imparare ogni giorno. '
    /* 0.9.322, Andrea: "Un uomo ricco non e' altro che un uomo povero con i soldi", attribuita male a Bob Marley e contro il mio obiettivo; e la
       frase di Edison sui tentativi uscita due volte con altre parole. */
    + 'Prima di scegliere una frase chiediti: mi spinge ad agire verso questo sogno oggi? Se è solo filosofia, scartala. '
    + 'Scarta le frasi che sminuiscono la ricchezza, il successo o l\'ambizione, e quelle che parlano di soldi o povertà fini a se stessi: chi vuole riuscire ragiona da chi vive nell\'abbondanza prima ancora di arrivarci. '
    + 'Se non sei certo di chi l\'ha detta davvero, scartala: niente attribuzioni dubbie. '
    + 'Ogni frase deve dire una cosa diversa: mai due frasi con lo stesso concetto, nemmeno con altre parole o autori diversi (per esempio una sola sui tentativi falliti). '
    + 'In italiano (traduci bene le citazioni straniere), al massimo 130 caratteri l\'una, senza emoji. Ogni autore al massimo due volte. '
    + 'Usa "Anonimo" solo se proprio non trovi una citazione vera adatta, al massimo una volta su 21. '
    + 'Rispondi SOLO con 21 righe nel formato: citazione | Nome Cognome dell\'autore. Senza numeri, senza virgolette, senza nient\'altro.'
    + '\n\nIl mio sogno, con le mie parole: ' + c.sogno
    + (c.chi ? '\nChi sarò quando ci arrivo: ' + c.chi : '')
    + (c.perche ? '\nIl mio perché: ' + c.perche : '')
    + (c.passi ? '\nI miei prossimi passi: ' + c.passi : '')
    + (c.freni ? '\nCosa mi frena: ' + c.freni : '')
    + (foViste().length ? '\n\nQueste le ho già viste, non riproporle e non riproporre lo stesso concetto:\n' + foViste().slice(-60).join('\n') : '');
}
/* le frasi gia' uscite restano in memoria: la stessa idea non torna con altre parole */
const FO_VISTE_K = 'fl_frasi_viste';
function foViste(){ try{ return JSON.parse(localStorage.getItem(FO_VISTE_K) || '[]') || []; }catch(_){ return []; } }
function foRicorda(l){ try{ const v = foViste(); l.forEach(function(x){ const t = foT(x); if (t && v.indexOf(t) < 0) v.push(t); }); localStorage.setItem(FO_VISTE_K, JSON.stringify(v.slice(-200))); }catch(_){ } }
/* quello che non deve uscire nemmeno se l'AI lo propone */
const FO_NO = /\b(pover[oaie]|ricco|ricchi|ricca|ricche)\b.*\b(soldi|denaro)\b|\b(soldi|denaro)\b.*\b(pover[oaie]|ricco|ricchi|ricca|ricche)\b|i soldi non (fanno|danno|comprano)/i;
function foParole(t){ return String(t).toLowerCase().replace(/[^a-zàèéìòù ]/g, ' ').split(/\s+/).filter(function(p){ return p.length > 4; }); }
function foSimili(a, b){ const x = foParole(a), y = foParole(b); if (!x.length || !y.length) return false; const c = x.filter(function(p){ return y.indexOf(p) >= 0; }).length; return c / Math.min(x.length, y.length) >= 0.5; }
function foFiltra(l){
  const fuori = [], viste = foViste();
  return l.filter(function(x){
    const t = foT(x);
    if (FO_NO.test(t) || /marley|povere|poveri|ricco non|uomo ricco/i.test(t + ' ' + foA(x)) || viste.some(function(v){ return foSimili(v, t); }) || fuori.some(function(v){ return foSimili(v, t); })) return false;
    fuori.push(t); return true;
  });
}
function foEstrai(testo){
  /* ogni riga: "citazione | Autore". Una riga senza autore non entra: e' proprio la frase inventata che non vogliamo */
  return String(testo || '').split(/\n+/).map(function(r){
    r = r.replace(/^\s*(?:\d+[.)]|[-•*])\s*/, '').trim();
    const m = /^(.*?)\s*(?:\||\s[\u2013\u2014~-]\s)\s*([^|]{2,60})$/.exec(r);
    if (!m) return null;
    const t = m[1].replace(/["«»“”]/g, '').trim(), a = m[2].replace(/["«»“”]/g, '').trim();
    if (t.length < 8 || t.length > 170 || /^\[/.test(t)) return null;
    return { t: t, a: a };
  }).filter(Boolean).slice(0, 21);
  /* (il filtro sulle frasi gia' viste sta in foGenera, dove si scrive la scorta) */
}
function foT(x){ return typeof x === 'string' ? x : (x && x.t) || ''; }
function foA(x){ return typeof x === 'string' ? '' : (x && x.a) || ''; }
async function foGenera(){
  FO_ERR = '';
  const c = foContesto();
  if (!c.sogno){ FO_ERR = 'Prima scrivi il tuo sogno: le frasi partono da lì.'; return null; }
  if (typeof agApi !== 'function' || typeof agPuo !== 'function' || !agPuo()){ FO_ERR = 'Disponibile nell’app installata, con il tuo agente personale'; return null; }
  try{
    const r = await agApi('POST', '/api/focuslock/agent/chat', { testo: foRichiesta(c), brief: (typeof agBrief === 'function') ? agBrief() : '' });
    if (!r || !r.id){ FO_ERR = 'Il tuo agente personale non ha ricevuto la richiesta'; return null; }
    if (typeof agNascondi === 'function') agNascondi(r.id);
    /* la risposta: si aspetta fino a cinque minuti */
    const da = Date.now();
    while (Date.now() - da < 5 * 60000){
      await new Promise(function(ok){ setTimeout(ok, 5000); });
      const g = await agApi('GET', '/api/focuslock/agent/chat?after=' + (r.id - 1)).catch(function(){ return null; });
      const risp = ((g && g.messaggi) || []).filter(function(m){ return m.direzione === 'out' && m.inReplyTo === r.id; })[0];
      if (risp){
        const frasi = foFiltra(foEstrai(risp.testo));
        if (frasi.length < 5){ FO_ERR = 'Il tuo agente personale non ha scritto le frasi: riprova'; return null; }
        const o = foLeggi(); o.frasi = frasi; o.firma = foFirma(c); o.at = Date.now(); foScrivi(o);
        return frasi;
      }
    }
    FO_ERR = 'Il tuo agente personale ci sta mettendo troppo: riprova fra poco';
    return null;
  }catch(e){
    const msg = String((e && (e.message || e.data && e.data.message)) || e);
    FO_ERR = /429|crediti|limit/i.test(msg) ? 'Hai finito i crediti del tuo agente personale per oggi' : 'Il tuo agente personale non è raggiungibile';
    return null;
  }
}
/* 0.9.286, Andrea: "la frase del giorno si aggiorna verso le 9-11, non a mezzanotte". La causa: il giorno della
   frase si contava dalle ore passate da quando l'agente le aveva scritte (verso le 10). Il telefono a mezzanotte
   metteva quella giusta, poi l'app aperta al mattino la rimetteva indietro di un giorno fino alle 10.
   Adesso conta il calendario: quante mezzanotti sono passate dal giorno della scrittura. */
function foPassati(o){
  const a = new Date(o && o.at || Date.now()); a.setHours(12, 0, 0, 0);
  const b = new Date(); b.setHours(12, 0, 0, 0);
  return Math.max(0, Math.round((b - a) / 86400000));
}
function foGiorno(off){ const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + off); return (typeof scKey === 'function') ? scKey(d.getTime()) : d.toISOString().slice(0, 10); }
/** La scorta per il telefono: una frase al giorno, da oggi. */
function foScorta(frasi){
  const out = [];
  /* sempre fra virgolette, con l'autore sotto (il telefono lo scrive con la tilde davanti) */
  for (let i = 0; i < frasi.length; i++){
    const t = foT(frasi[i]); if (!t) continue;
    /* 0.9.289, Andrea: "a mezzanotte doveva esserci una frase del mio obiettivo, invece c'e' ancora Churchill". Le frasi
       scelte da lui (scores.js, SC_SCELTE) passavano davanti anche qui: con "Solo frasi sul mio obiettivo" acceso la
       schermata di blocco mostra SOLO le frasi del suo agente. Le sue frasi restano nella frase del giorno normale. */
    out.push({ d: foGiorno(i), t: '"' + t + '"', a: foA(frasi[i]) || 'Anonimo' });
  }
  return out;
}
async function foApplica(){
  const o = foLeggi(); if (!o.on || !o.frasi || !o.frasi.length) return false;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setLockQuote) return false;
  /* la scorta parte dalla frase di oggi: quante ne sono gia' passate dalla scrittura */
  const passati = foPassati(o);
  /* 0.9.322: anche nelle frasi gia' scritte: fuori quelle che non devono uscire e quelle che ripetono la stessa idea con altre parole */
  const fuori = [], frasi = o.frasi.filter(function(x){ const t = foT(x); if (FO_NO.test(t) || fuori.some(function(v){ return foSimili(v, t); })) return false; fuori.push(t); return true; });
  if (!frasi.length) return false;
  const resto = frasi.slice(passati % frasi.length).concat(frasi.slice(0, passati % frasi.length));
  const pool = foScorta(resto);
  if (!pool.length) return false;
  foRicorda(resto.slice(0, 1));
  try{ await NATIVE.setLockQuote({ on: true, text: pool[0].t, author: pool[0].a, day: pool[0].d, pool: pool }); try{ localStorage.setItem('fl_lockquote_on', '1'); }catch(_){ } return true; }catch(_){ return false; }
}
/** Ogni avvio: se l'opzione e' accesa, il sogno cambiato o la scorta finita fanno riscrivere le frasi. */
async function foControlla(){
  const o = foLeggi(); if (!o.on) return;
  if (!foPremium()){ o.on = false; foScrivi(o); return; }
  const c = foContesto();
  const vecchie = !o.at || Date.now() - o.at > 20 * 86400000;
  const senzaAutore = (o.frasi || []).some(function(x){ return typeof x === 'string'; });
  if (vecchie || senzaAutore || o.firma !== foFirma(c) || !(o.frasi || []).length) await foGenera();
  await foApplica();
}
async function foToggle(){
  if (!foPremium()){
    try{ toast('Le frasi sul tuo obiettivo sono Premium'); }catch(_){ }
    try{ if (typeof pwOpen === 'function') pwOpen(); }catch(_){ }
    return;
  }
  const o = foLeggi();
  if (o.on){ o.on = false; foScrivi(o); foRigaPaint(); try{ toast('Torna la frase del giorno'); }catch(_){ } try{ if (typeof scLockQuoteDaily === 'function' && typeof scQuotes === 'function') scLockQuoteDaily(await scQuotes()); }catch(_){ } return; }
  o.on = true; foScrivi(o); foRigaPaint(true);
  const frasi = await foGenera();
  if (!frasi){ const x = foLeggi(); x.on = false; foScrivi(x); foRigaPaint(); try{ toast(FO_ERR || 'Non riuscito'); }catch(_){ } return; }
  await foApplica();
  foRigaPaint();
  try{ toast('Fatto: guarda la schermata di blocco'); }catch(_){ }
}
function foRigaHtml(scrivendo){
  const o = foLeggi();
  const sotto = scrivendo ? 'Il tuo agente personale sta scrivendo le tue frasi…'
    : (o.on && o.frasi && o.frasi.length ? (function(){ const x = o.frasi[foPassati(o) % o.frasi.length]; return 'Oggi: "' + foPulisci(foT(x), 90) + '"' + (foA(x) ? ' ' + foA(x) : ''); })()
      : 'Al posto della frase del giorno, citazioni di persone celebri scelte dal tuo agente personale sul tuo sogno: su chi diventi e su cosa fai per arrivarci.');
  return '<div><b>🎯 Solo frasi sul mio obiettivo' + (foPremium() ? '' : ' <i class="lp-pro">⚡ PRO</i>') + '</b><small id="foSub">' + (typeof esc === 'function' ? esc(sotto) : sotto) + '</small></div>'
    + '<button class="switch' + (o.on || scrivendo ? ' on' : '') + '" onclick="foToggle()"></button>';
}
function foRigaPaint(scrivendo){ const h = document.getElementById('foRiga'); if (h) h.innerHTML = foRigaHtml(scrivendo); }
/* con l'opzione accesa, la frase del giorno di sempre non deve sovrascrivere le frasi dell'agente */
(function(){
  if (typeof scLockQuoteDaily === 'function'){
    const v = scLockQuoteDaily;
    window.scLockQuoteDaily = scLockQuoteDaily = function(){ if (foLeggi().on) return foApplica(); return v.apply(this, arguments); };
  }
  /* 0.9.263 le aveva messe sulla schermata dei blocchi delle app: si spengono li' */
  setTimeout(function(){ try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ lockGoalOn: false }); }catch(_){ } }, 4000);
  setTimeout(function(){ try{ foControlla(); }catch(_){ } }, 7000);
})();
