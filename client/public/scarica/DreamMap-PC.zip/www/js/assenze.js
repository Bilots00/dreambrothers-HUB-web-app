/* ===========================================================================================
   DATE D'ASSENZA e NON DISTURBARE (0.9.208), come su Asana

   Due pagine, dentro a «Quando tacere». Le date d'assenza sono i giorni in cui l'app non
   deve giudicare: si sta sviluppando l'app, si e' in ferie, si e' malati. Non disturbare
   sospende tutto per un po' (30 minuti … fino a domani), tiene liberi certi giorni della
   settimana e, se si pianifica, tace nelle fasce scelte.
   Cosa tace: la chiamata dei sogni (la configurazione nativa si spegne e si riaccende da
   sola), i trigger in JS, il mantra e i premi che chiedono asSilenzioAttivo().
   =========================================================================================== */
const AS_KEY = 'fl_assenze', ND_KEY = 'fl_nd';
function asEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function asLista(){ try{ return JSON.parse(localStorage.getItem(AS_KEY) || '[]') || []; }catch(_){ return []; } }
function asSalva(l){ try{ localStorage.setItem(AS_KEY, JSON.stringify(l.slice(-50))); }catch(_){ } ndApplica(); }
function ndCfg(){ let c = {}; try{ c = JSON.parse(localStorage.getItem(ND_KEY) || '{}') || {}; }catch(_){ } return Object.assign({ fino: 0, liberi: [false, false, false, false, false, false, false], pianifica: false, fasce: [{ da: '22:00', a: '08:00' }] }, c); }
function ndSalva(c){ try{ localStorage.setItem(ND_KEY, JSON.stringify(c)); }catch(_){ } ndApplica(); }
function asOggiIso(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function asData(iso){ if (!iso) return ''; const d = new Date(iso + 'T12:00:00'); return d.getDate() + ' ' + ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'][d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : ''); }
/** Vero se adesso l'app deve tacere: assenza in corso, Non disturbare acceso, giorno libero, fascia pianificata. */
function asSilenzioAttivo(){
  const oggi = asOggiIso();
  if (asLista().some(function(a){ return a.da <= oggi && oggi <= a.a; })) return 'assenza';
  const c = ndCfg(); const now = new Date();
  if (c.fino && c.fino > Date.now()) return 'sospeso';
  if (c.liberi[(now.getDay() + 6) % 7]) return 'libero';
  if (c.pianifica){
    const m = now.getHours() * 60 + now.getMinutes();
    const toMin = function(s){ const p = /^(\d{2}):(\d{2})$/.exec(s || ''); return p ? (+p[1]) * 60 + (+p[2]) : -1; };
    if ((c.fasce || []).some(function(f){ const a = toMin(f.da), b = toMin(f.a); if (a < 0 || b < 0) return false; return a <= b ? (m >= a && m < b) : (m >= a || m < b); })) return 'fascia';
  }
  return '';
}
function asPerche(k){ return { assenza: 'date d’assenza', sospeso: 'Non disturbare', libero: 'giorno libero', fascia: 'fascia di silenzio' }[k] || ''; }
/* la chiamata dei sogni nativa si spegne mentre si tace, e si riaccende da sola dopo */
function ndApplica(){
  try{
    if (typeof dcCfg !== 'function' || typeof dcSave !== 'function') return;
    const c = dcCfg(); const tace = !!asSilenzioAttivo();
    if (tace && c.on){ dcSave({ on: false, sospesaDaNd: true }); }
    else if (!tace && !c.on && c.sospesaDaNd){ dcSave({ on: true, sospesaDaNd: false }); }
  }catch(_){ }
}
document.addEventListener('fl:tab', function(){ setTimeout(ndApplica, 800); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(ndApplica, 800); });

/* ---------------------------------------------------------------- i due pannelli, dentro a «Quando tacere» */
function asPannelliHtml(){
  const n = asLista().filter(function(a){ return a.a >= asOggiIso(); }).length;
  const k = asSilenzioAttivo();
  return '<div class="as-pann"><button type="button" class="as-p" onclick="asApri()"><span>📅</span><b>Date d’assenza</b><small>' + (n ? n + (n === 1 ? ' periodo' : ' periodi') : 'Ferie, malattia, giorni fuori') + '</small></button>'
    + '<button type="button" class="as-p' + (k && k !== 'assenza' ? ' on' : '') + '" onclick="ndApri()"><span>🔕</span><b>Non disturbare</b><small>' + (k && k !== 'assenza' ? 'Acceso: ' + asPerche(k) : 'Sospendi, giorni liberi, fasce') + '</small></button></div>';
}

/* ---------------------------------------------------------------- Date d'assenza */
registerScreen('s-assenze',
  '<div class="topbar"><button class="iconbtn" onclick="asIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Date d’assenza</b></div>'
  + '<div id="asBody"></div><div class="spacer"></div>', { back: function(){ if (AS_DA === 'dream'){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } return 's-personalize'; } });
function asApri(da){ AS_DA = da || 'impostazioni'; goId('s-assenze'); asPaint(); }
let AS_DA = 'impostazioni';
function asIndietro(){ if (AS_DA === 'dream'){ if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } } return; } goId('s-personalize'); }
function asPaint(){
  const h = document.getElementById('asBody'); if (!h) return;
  const l = asLista().sort(function(a, b){ return a.da < b.da ? -1 : 1; }); const oggi = asOggiIso();
  h.innerHTML = (l.length ? '<div class="as-lista">' + l.map(function(a, i){ const corso = a.da <= oggi && oggi <= a.a; return '<div class="as-riga' + (corso ? ' on' : '') + '"><span>' + (corso ? '🏖️' : '📅') + '</span><div><b>' + asEsc(asData(a.da)) + ' → ' + asEsc(asData(a.a)) + '</b><small>' + (corso ? 'In corso: l’app tace' : (a.a < oggi ? 'Passata' : 'In arrivo')) + (a.nota ? ' · ' + asEsc(a.nota) : '') + '</small></div><button type="button" class="as-x" onclick="asTogli(' + i + ')" aria-label="Togli">✕</button></div>'; }).join('') + '</div>'
      : '<div class="as-vuoto"><span>📅</span><h3>Imposta le date d’assenza</h3><p>Nei giorni che segni l’app non giudica: niente chiamata dei sogni, niente punti al vecchio te per il tempo di schermo.</p></div>')
    + '<button type="button" class="cta as-cta" onclick="asAggiungiApri()">＋ Aggiungi date d’assenza</button>';
}
function asTogli(i){ const l = asLista().sort(function(a, b){ return a.da < b.da ? -1 : 1; }); l.splice(i, 1); asSalva(l); asPaint(); }
function asAggiungiApri(){
  if (typeof inSheet !== 'function') return;
  const oggi = asOggiIso();
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3 class="fr-agg-h">Aggiungi date d’assenza</h3>'
    + '<div class="as-due"><label><small>Primo giorno</small><input class="fin" type="date" id="asDa" value="' + oggi + '" onclick="try{this.showPicker()}catch(_){}" onfocus="try{this.showPicker()}catch(_){}"></label><label><small>Ultimo giorno</small><input class="fin" type="date" id="asA" value="' + oggi + '" onclick="try{this.showPicker()}catch(_){}" onfocus="try{this.showPicker()}catch(_){}"></label></div>'
    + '<label class="as-nota-l"><small>Perché (facoltativo)</small><textarea class="fin" id="asNota" rows="4" placeholder="Ferie, malattia, sto sviluppando un progetto…" maxlength="160"></textarea></label>'
    + '<button type="button" class="cta" onclick="asAggiungi()">Salva le date</button></div>');
}
function asAggiungi(){
  const da = (document.getElementById('asDa') || {}).value, a = (document.getElementById('asA') || {}).value, nota = ((document.getElementById('asNota') || {}).value || '').trim();
  if (!da || !a){ toast('Scegli il primo e l’ultimo giorno'); return; }
  if (a < da){ toast('L’ultimo giorno viene prima del primo'); return; }
  const l = asLista(); l.push({ da: da, a: a, nota: nota }); asSalva(l);
  try{ inSheetChiudi(); }catch(_){ }
  asPaint(); toast('Segnato: l’app tace in quei giorni');
}

/* ---------------------------------------------------------------- Non disturbare */
registerScreen('s-nd',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-personalize\')">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Non disturbare</b></div>'
  + '<div id="ndBody"></div><div class="spacer"></div>', { back: 's-personalize' });
function ndApri(){ goId('s-nd'); ndPaint(); }
function ndPaint(){
  const h = document.getElementById('ndBody'); if (!h) return;
  const c = ndCfg(); const sosp = c.fino && c.fino > Date.now();
  const G = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
  h.innerHTML = '<div class="sect as-sect"><b>Sospendi ora</b></div>'
    + (sosp ? '<div class="as-riga on"><span>🔕</span><div><b>In pausa fino alle ' + new Date(c.fino).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) + (new Date(c.fino).getDate() !== new Date().getDate() ? ' di domani' : '') + '</b><small>Niente chiamate, mantra e premi fino ad allora.</small></div><button type="button" class="as-x" onclick="ndSospendi(0)" aria-label="Riprendi">✕</button></div>' : '')
    + '<div class="as-lista">' + [[30, '30 minuti'], [60, '1 ora'], [120, '2 ore'], [240, '4 ore'], [480, '8 ore'], [-1, 'Fino a domani']].map(function(o){ return '<button type="button" class="as-riga vai" onclick="ndSospendi(' + o[0] + ')"><b>' + o[1] + '</b><span class="chev"></span></button>'; }).join('') + '</div>'
    + '<div class="sect as-sect"><b>Giorni liberi</b></div><p class="as-p-nota">Nei giorni liberi l’app non chiama e non giudica.</p>'
    + '<div class="as-giorni">' + G.map(function(g, i){ return '<button type="button" class="' + (c.liberi[i] ? 'on' : '') + '" onclick="ndGiorno(' + i + ')">' + g + '</button>'; }).join('') + '</div>'
    + '<div class="sect as-sect"><b>Sospendi più tardi</b></div>'
    + '<div class="as-riga"><span>🗓️</span><div><b>Pianifica</b><small>Fasce in cui tacere ogni giorno.</small></div><button type="button" class="switch' + (c.pianifica ? ' on' : '') + '" onclick="ndPianifica(!this.classList.contains(\'on\'))"></button></div>'
    + (c.pianifica ? '<div class="as-fasce">' + (c.fasce || []).map(function(f, i){ return '<div class="as-fascia"><input class="fin" type="time" value="' + f.da + '" onchange="ndFascia(' + i + ',\'da\',this.value)"><span>→</span><input class="fin" type="time" value="' + f.a + '" onchange="ndFascia(' + i + ',\'a\',this.value)"><button type="button" class="as-x" onclick="ndFasciaVia(' + i + ')" aria-label="Togli">✕</button></div>'; }).join('') + '<button type="button" class="ghostmini" onclick="ndFasciaPiu()">＋ Aggiungi una fascia</button></div>' : '');
}
function ndSospendi(min){ const c = ndCfg(); if (min === 0) c.fino = 0; else if (min < 0){ const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(8, 0, 0, 0); c.fino = d.getTime(); } else c.fino = Date.now() + min * 60000; ndSalva(c); ndPaint(); try{ flVibra(10); }catch(_){ } toast(min === 0 ? 'Ripreso' : 'In pausa'); }
function ndGiorno(i){ const c = ndCfg(); c.liberi[i] = !c.liberi[i]; ndSalva(c); ndPaint(); }
function ndPianifica(on){ const c = ndCfg(); c.pianifica = !!on; ndSalva(c); ndPaint(); }
function ndFascia(i, k, v){ const c = ndCfg(); if (c.fasce[i]) c.fasce[i][k] = v; ndSalva(c); }
function ndFasciaVia(i){ const c = ndCfg(); c.fasce.splice(i, 1); ndSalva(c); ndPaint(); }
function ndFasciaPiu(){ const c = ndCfg(); c.fasce.push({ da: '13:00', a: '14:00' }); ndSalva(c); ndPaint(); }

(function(){
  const css = [
    '.as-pann{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0 6px}.as-p{display:flex;flex-direction:column;align-items:center;gap:4px;padding:16px 10px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff);text-align:center;cursor:pointer}.as-p span{font-size:26px}.as-p b{font:800 14px var(--font-body);color:var(--navy)}.as-p small{font:500 11.5px/1.4 var(--font-body);color:var(--muted)}.as-p.on{border-color:#E63946}body.dark .as-p{background:#12203A;border-color:#22345A}body.dark .as-p b{color:#fff}',
    '#asBody,#ndBody{padding:0 18px}.as-vuoto{text-align:center;padding:30px 10px 10px}.as-vuoto span{font-size:64px}.as-vuoto h3{margin:12px 0 6px;font:800 22px var(--font-display);color:var(--navy)}body.dark .as-vuoto h3{color:#fff}.as-vuoto p{margin:0 auto;max-width:32ch;font:500 14px/1.55 var(--font-body);color:var(--muted)}.as-cta{width:100%;margin-top:22px}',
    '.as-lista{display:flex;flex-direction:column;gap:10px}.as-riga{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:14px 14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff)}body.dark .as-riga{background:#12203A;border-color:#22345A}.as-riga.vai{cursor:pointer}.as-riga > span:first-child{font-size:24px}.as-riga > div{flex:1}.as-riga b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .as-riga b{color:#fff}.as-riga small{display:block;margin-top:2px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}.as-riga.on{border-color:#E63946}.as-x{width:34px;height:34px;border:0;border-radius:50%;background:transparent;color:var(--muted);font-size:16px;cursor:pointer}',
    '.as-sect{margin:26px 2px 10px}.as-p-nota{margin:-4px 2px 10px;font:500 13px/1.5 var(--font-body);color:var(--muted)}.as-giorni{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}.as-giorni button{padding:12px 2px;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);font:800 12px var(--font-body);color:var(--navy);cursor:pointer}.as-giorni button.on{border-color:#0075E3;background:rgba(0,117,227,.12);color:#0075E3}body.dark .as-giorni button{background:#12203A;border-color:#22345A;color:#fff}',
    '.as-fasce{margin-top:10px;display:flex;flex-direction:column;gap:8px}.as-fascia{display:flex;align-items:center;gap:8px}.as-fascia .fin{flex:1;margin:0}.as-due{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}.as-due label small{display:block;margin:0 0 4px;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.as-due .fin{margin:0;width:100%;box-sizing:border-box;cursor:pointer}.as-nota-l small{display:block;margin:4px 0 4px;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}#asNota{display:block;width:100%;box-sizing:border-box;min-height:120px;margin:0 0 18px;resize:none}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* ---- LE NOTIFICHE CHE APRONO UNA PAGINA (0.9.209): «umore» apre il controllo dell'umore ---- */
async function flApriDaNotifica(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.consumeApri) return;
    const r = await NATIVE.consumeApri(); const k = r && r.apri;
    if (k) flApriDaNotificaK(k);
  }catch(_){ }
}
function flApriDaNotificaK(k){
  try{
    if (!k) return;
    /* 0.9.305: il bivio della schermata fuori rotta (Blinda il nuovo te / Apri comunque): fuori-rotta.js */
    if (typeof frApriDaBlocco === 'function' && frApriDaBlocco(k)) return;
    if (k === 'umore'){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } setTimeout(function(){ try{ if (typeof umScorciatoia === 'function') umScorciatoia(); }catch(_){ } }, 500); try{ if (typeof rpUmPromArma === 'function') rpUmPromArma(); }catch(_){ } }
    else if (k === 'amici'){ try{ if (typeof frOpen === 'function') frOpen('lega'); }catch(_){ } }
    /* 0.9.305: la notifica di un incoraggiamento o di una pozione (AmiciNovita.java): la scheda Amici, dove la pozione si apre */
    else if (k === 'amici-novita'){ try{ if (typeof frOpen === 'function') frOpen('amici'); }catch(_){ } }
    /* 0.9.264: la notifica e il widget del Genio triste (serie a rischio) portano alla Mappa, sulla tappa di oggi */
    /* 0.9.310: l'avviso per salvare la serie (SerieAvvisi.java): dritti alla tappa di oggi sulla Mappa */
    else if (k === 'serie'){ goId('s-home'); try{ if (typeof hdTappaVia === 'function') hdTappaVia(); else switchTab('mappa'); }catch(_){ } }
    /* 0.9.311: la bolla del carburante (CarburanteBolla.java): la pagina Dopamina, con cosa ha mosso il numero */
    else if (k === 'dopamina'){ try{ if (typeof dpApri === 'function') dpApri(); }catch(_){ } }
    else if (k === 'carburante'){ try{ if (typeof ccApri === 'function') ccApri(); else if (typeof dpApri === 'function') dpApri(); }catch(_){ } }
    else if (k === 'mappa'){ goId('s-home'); try{ switchTab('mappa'); }catch(_){ } setTimeout(function(){ try{ const n = document.querySelector('#mppSentiero .sd-nodo.corrente'); if (n) n.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ } }, 600); }
    /* l'icona "Note" sulla schermata Home (e il tocco lungo sull'icona dell'app): stesso extra "apri" */
    /* 0.9.297: il caveau toccato nelle note aperte dall'icona sulla Home */
    else if (k === 'caveau'){ try{ if (typeof cvPaginaApri === 'function') cvPaginaApri(); else if (typeof mnCaveauApri === 'function') mnCaveauApri(); }catch(_){ } }
    /* 0.9.298: dal caveau dentro le note (aperte dall'icona) il prompt dell'albero maestro vive in DreamMap */
    else if (k === 'albero'){ try{ if (typeof cvPaginaApri === 'function') cvPaginaApri(); if (typeof amApri === 'function') setTimeout(amApri, 300); }catch(_){ } }
    else if (k === 'note'){ try{ if (typeof noApri === 'function') noApri('', true); }catch(_){ } }
    /* 0.9.322: le icone sulla Home dei suoni e delle pagine del piano */
    else if (k === 'suoni'){ try{ if (typeof sndPaginaApri === 'function') sndPaginaApri(); }catch(_){ } }
    else if (String(k).indexOf('piano:') === 0){ try{ if (typeof drsPianoPagina === 'function') drsPianoPagina(String(k).slice(6)); }catch(_){ } }
    /* 0.9.299: "Il piano" nel menu delle note aperte dall'icona sulla Home: il piano (Notion) vive in DreamMap */
    else if (k === 'piano'){ try{ if (typeof ntApri === 'function') ntApri(0); }catch(_){ } }
    /* 0.9.283: il pulsante del rompicapo sulla schermata di blocco */
    /* 0.9.302: "Rileggi il contratto" sulla schermata di blocco */
    else if (k === 'contratto'){ try{ if (typeof ctrApri === 'function') ctrApri(); }catch(_){ } }
    else if (k === 'rompicapo' || k === 'cruciverba'){ try{ if (typeof rcpApri === 'function') rcpApri(k === 'cruciverba' ? 'cruciverba' : 'enigma'); }catch(_){ } }
    /* 0.9.285: la notifica dei turni (TurniFoto.java): il calendario della Mappa */
    else if (k === 'calendario'){ goId('s-home'); try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ } setTimeout(function(){ try{ if (typeof mfTab === 'function') mfTab('cal'); const f = document.getElementById('mppFoglio'); if (f) f.scrollIntoView({ block: 'start', behavior: 'smooth' }); }catch(_){ } }, 600); }
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) { setTimeout(flApriDaNotifica, 60); setTimeout(flApriDaNotifica, 400); } });
/* LE NOTE DALLA SCHERMATA HOME, A FREDDO. Aspettare due secondi e mezzo voleva dire vedere
   prima la scheda di Dream e poi lo scatto verso le note. L'intento si chiede subito, appena il
   ponte col telefono c'e', mentre la schermata di avvio copre ancora tutto: se sono le note,
   si aprono li' sotto e quando l'avvio si toglie ci sono gia'. Gli altri intenti restano al
   loro passo (si rimettono in coda per il giro di sempre). */
(function flApriPresto(){
  let tentativi = 0;
  const prova = async function(){
    try{
      if (!window.__flAvviato || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.consumeApri){ if (++tentativi < 15) setTimeout(prova, 150); return; }
      const r = await NATIVE.consumeApri(); const k = r && r.apri;
      if (k === 'note'){ try{ if (typeof noApri === 'function') noApri('', true); }catch(_){ } }
      else if (k) setTimeout(function(){ flApriDaNotificaK(k); }, 2200);
    }catch(_){ }
  };
  setTimeout(prova, 300);
})();
setTimeout(flApriDaNotifica, 2500);
setTimeout(function(){ try{ if (typeof rpUmPromArma === 'function') rpUmPromArma(); }catch(_){ } }, 6000);

/* ---- LA BOLLA DEL TIMER (0.9.209, scelta dal 0.9.210): durante il Full Focus, ogni cinque
   minuti, per qualche secondo, una bolla con il tempo. Di serie il tempo che SCORRE: il conto
   alla rovescia mette ansia, il tempo fatto e' una cosa guadagnata. Chi preferisce il conto
   alla rovescia lo sceglie nelle Impostazioni del Full Focus. Dentro all'app la mostra questa
   pagina; fuori, sul telefono la bolla del tempo e sul computer la bolla dell'app desktop. ---- */
const FFB = { ultimo: 0 };
function ffBollaModo(){ try{ const v = localStorage.getItem('fl_ff_bolla'); return (v === 'giu' || v === 'off') ? v : 'su'; }catch(_){ return 'su'; } }
function ffBollaModoSet(v){
  try{ localStorage.setItem('fl_ff_bolla', v); }catch(_){ }
  try{ if (typeof SETTINGS !== 'undefined') SETTINGS.ffBolla = v; if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ ffBolla: v }); }catch(_){ }
  try{ if (typeof ffImpostazioniApri === 'function') ffImpostazioniApri(); }catch(_){ }
}
function ffBollaFmt(ms){ const s = Math.max(0, Math.floor(ms / 1000)), m = Math.floor(s / 60); return m >= 60 ? Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm' : m + ':' + String(s % 60).padStart(2, '0'); }
function ffBollaTick(){
  try{
    if (typeof FF === 'undefined' || !FF || !FF.run || FF.run.pausedAt){ FFB.ultimo = 0; return; }
    const passati = Math.floor((Date.now() - FF.run.startAt) / 300000);
    if (passati <= 0 || passati === FFB.ultimo) return;
    FFB.ultimo = passati;
    const modo = ffBollaModo(); if (modo === 'off') return;
    const left = Math.max(0, (typeof ffLeft === 'function') ? ffLeft() : FF.run.endAt - Date.now());
    let b = document.getElementById('ffBolla');
    if (!b){ b = document.createElement('div'); b.id = 'ffBolla'; b.className = 'ff-bolla'; (document.getElementById('phone') || document.body).appendChild(b); }
    b.innerHTML = modo === 'giu'
      ? '<span>⏳</span><div><b>' + ffBollaFmt(left) + '</b><small>alla fine della sessione</small></div>'
      : '<span>⏱</span><div><b>' + ffBollaFmt(Date.now() - FF.run.startAt) + '</b><small>di concentrazione · resta su una cosa sola</small></div>';
    b.classList.remove('in'); void b.offsetWidth; b.classList.add('in');
    try{ flVibra(12); }catch(_){ }
    clearTimeout(FFB.t); FFB.t = setTimeout(function(){ b.classList.remove('in'); }, 6000);
  }catch(_){ }
}
setTimeout(function(){ try{ const v = ffBollaModo(); if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ ffBolla: v }); }catch(_){ } }, 5000);
setInterval(ffBollaTick, 15000);
(function(){
  const st = document.createElement('style');
  st.textContent = '.ff-bolla{position:absolute;left:50%;top:calc(env(safe-area-inset-top,0px) + 70px);z-index:9997;display:flex;align-items:center;gap:10px;padding:10px 16px;border-radius:99px;background:#001E44;color:#fff;box-shadow:0 10px 26px rgba(0,0,0,.3);transform:translate(-50%,-30px);opacity:0;pointer-events:none;transition:transform .35s cubic-bezier(.2,1.3,.4,1),opacity .25s}.ff-bolla.in{transform:translate(-50%,0);opacity:1}.ff-bolla > span{font-size:22px}.ff-bolla b{display:block;font:900 18px var(--font-display);font-variant-numeric:tabular-nums}.ff-bolla small{font:600 11px var(--font-body);opacity:.8}';
  document.head.appendChild(st);
})();
