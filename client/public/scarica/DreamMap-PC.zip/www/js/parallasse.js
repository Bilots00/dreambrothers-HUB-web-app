/* ===========================================================================================
   IL PARALLASSE DELLO SLIDESHOW, COME collection-banner.liquid DEL TEMA SHOPIFY (0.9.268)

   LA STORIA, PERCHE' NON SI RIFACCIA. Dalla 0.9.261 alla 0.9.267 il parallasse era fatto con le
   animazioni CSS legate allo scroll (animation-timeline: view()). Sul computer (WebView2) e su
   BlueStacks era perfetto; sul telefono di Andrea le schede con lo slideshow scattavano, e la
   scheda Profilo — senza slideshow — no. Il suo tema Shopify, con lo stesso identico effetto,
   sul suo telefono va liscio: la differenza e' che il tema muove foto e testo CON JAVASCRIPT allo
   scroll (theme.js, image-with-text-overlay), senza timeline legate allo scroll. Su alcuni WebView
   Android una timeline legata allo scroll non composta obbliga lo scroll stesso a passare dal
   thread principale: e' lo scroll intero che scatta, non l'animazione.

   Adesso e' fatto come il tema, e basta:
   - allo scroll della scheda (un evento per fotogramma, passivo) si legge scrollTop e si scrivono
     DUE cose: lo spostamento della foto (transform sul contenitore .bh-plx, un livello della
     scheda grafica) e l'opacita' del testo (will-change: opacity, idem). Niente layout, niente
     ridisegno: solo due valori che il compositore applica.
   - la foto scende al massimo di 100 px su tutta l'uscita della sezione (s = bordo basso,
     n = altezza: 100 - 100 * s/n); il testo resta pieno e sbiadisce solo dopo una soglia, fino a
     sparire quando un terzo della sezione e' uscito (1 - 3 * (1 - s/n)). Stesse formule del tema.
   - le misure (dove sta ogni slideshow dentro alla scheda, quanto e' alto) si prendono UNA volta
     per gesto di scroll, non a ogni fotogramma: niente letture di layout mentre si scorre.
   =========================================================================================== */
const PLX = { mis: new WeakMap(), misuratoA: 0, ultimoScroll: 0 };
/* compatibilita' con chi guardava PLX.css: il parallasse non usa piu' il CSS legato allo scroll */
PLX.css = false;

/* ogni foto dello slideshow dentro al suo contenitore del parallasse (una volta sola) */
function plxAvvolgi(){
  document.querySelectorAll('.bh .bh-img').forEach(function(img){
    const p = img.parentElement;
    if (!p || p.classList.contains('bh-plx')) return;
    const w = document.createElement('span'); w.className = 'bh-plx'; w.setAttribute('aria-hidden', 'true');
    p.insertBefore(w, img); w.appendChild(img);
  });
}

/* Le misure di una scheda: per ogni slideshow, il bordo alto rispetto all'inizio del contenuto e
   l'altezza. Si rifanno quando sono vecchie di piu' di un gesto (300 ms senza scroll). */
function plxMisura(tab){
  const st = tab.scrollTop;
  const tr = tab.getBoundingClientRect();
  const lista = [];
  tab.querySelectorAll('.bh').forEach(function(bh){
    const r = bh.getBoundingClientRect();
    if (!(r.height > 0)) return;
    lista.push({ bh: bh, top: r.top - tr.top + st, h: r.height, tr: tr.top,
                 plx: bh.querySelectorAll('.bh-plx'), testi: bh.querySelectorAll('.bh-text, .bh-stack') });
  });
  PLX.mis.set(tab, { at: Date.now(), lista: lista, scrollAt: 0 });
  return PLX.mis.get(tab);
}
function plxApplica(tab, forza){
  if (!tab || !tab.classList.contains('on')) return;
  let m = PLX.mis.get(tab);
  /* 0.9.268: le misure si prendono fuori dallo scroll (cambio scheda, ridisegno, resize). Durante lo scroll MAI:
     una lettura di layout nel gestore costringeva a ricalcolare la pagina all'inizio di ogni gesto. Se mancano, si
     prendono al fotogramma dopo. */
  if (!m || forza){
    if (!forza && PLX.rafMis) return;
    if (!forza){ PLX.rafMis = requestAnimationFrame(function(){ PLX.rafMis = 0; plxApplica(tab, true); }); return; }
    m = plxMisura(tab);
  }
  const st = tab.scrollTop;
  for (let i = 0; i < m.lista.length; i++){
    const x = m.lista[i];
    const s = x.top - st + x.h;                       /* il bordo basso della sezione, rispetto all'alto della scheda */
    const q = Math.min(Math.max(s / x.h, 0), 1);
    const y = Math.round((100 - 100 * q) * 2) / 2;
    if (x.y !== y){
      x.y = y;
      const tf = y ? 'translate3d(0,' + y + 'px,0)' : '';
      for (let k = 0; k < x.plx.length; k++) x.plx[k].style.transform = tf;
    }
    const op = Math.round(Math.max(0, Math.min(1, 1 - 3 * (1 - Math.min(q / 0.92, 1)))) * 100) / 100;
    if (x.op !== op){
      x.op = op;
      const v = op >= 1 ? '' : String(op);
      for (let k = 0; k < x.testi.length; k++) x.testi[k].style.opacity = v;
    }
  }
}
function plxScheda(){ return document.querySelector('.tabpage.on'); }
/* compatibilita': chi chiamava plxAggiorna/plxRinfresca trova ancora le funzioni */
function plxAggiorna(tab){ plxAvvolgi(); plxApplica(tab || plxScheda(), true); }
function plxRinfresca(){ plxAvvolgi(); plxApplica(plxScheda(), true); }
(function(){
  try{ if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return; }catch(_){ }
  const st = document.createElement('style');
  st.textContent = [
    '.bh-plx{position:absolute;inset:0;pointer-events:none;will-change:transform}',
    '.bh .bh-text,.bh .bh-stack{will-change:opacity}'
  ].join('');
  document.head.appendChild(st);
  /* lo scroll delle schede: un evento per fotogramma, applicato subito (senza rimandare al fotogramma dopo) */
  document.addEventListener('scroll', function(e){
    const t = e.target;
    if (!t || !t.classList || !t.classList.contains('tabpage')) return;
    plxApplica(t, false);
  }, { capture: true, passive: true });
  const rifai = function(){ plxAvvolgi(); plxApplica(plxScheda(), true); };
  document.addEventListener('fl:tab', function(){ setTimeout(rifai, 60); setTimeout(rifai, 700); });
  document.addEventListener('fl:screen', function(){ setTimeout(rifai, 60); });
  addEventListener('resize', function(){ setTimeout(rifai, 120); });
  [300, 1200, 3000].forEach(function(ms){ setTimeout(rifai, ms); });
  /* i pannelli che si ridisegnano (lo slideshow li ricrea): si riavvolgono e si rimisurano al fotogramma dopo */
  try{
    let raf = 0;
    new MutationObserver(function(m){
      if (raf) return;
      for (let i = 0; i < m.length; i++){
        const a = m[i].addedNodes;
        for (let j = 0; j < a.length; j++){
          const n = a[j];
          if (n.nodeType === 1 && !n.classList.contains('bh-plx') && (n.classList.contains('bh') || n.classList.contains('bh-img') || n.querySelector('.bh, .bh-img'))){ raf = requestAnimationFrame(function(){ raf = 0; rifai(); }); return; }
        }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }catch(_){ }
})();
