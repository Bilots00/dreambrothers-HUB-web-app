/* ===========================================================================================
   CATEGORIE — liste pronte di siti e app (Social, Video, Notizie, Shopping, Gioco, Adulti…)

   Tre posti le usano:
     · i suggerimenti scorrevoli nel Blocco rapido (sopra le righe Applicazioni / Siti web);
     · gli stessi suggerimenti nell'editor di un programma;
     · la pagina Categorie (dal Profilo), dove ogni lista si può correggere: togliere un sito
       o un'app che non c'entra, aggiungerne uno che manca. Le correzioni restano sul telefono
       (localStorage) e i suggerimenti del picker Web (blocklist.js) le seguono.

   Un chip acceso vuol dire che tutto ciò che la categoria contiene è già nella lista del
   blocco; toccarlo lo toglie. Spento o a metà: toccarlo aggiunge quello che manca. Le app
   entrano solo se installate, quando l'elenco delle installate è noto.
   =========================================================================================== */

const FL_CATS = [
  { id:'social', ic:'💬', name:'Social',
    sites:['facebook.com','instagram.com','tiktok.com','x.com','twitter.com','snapchat.com','reddit.com','linkedin.com','pinterest.com','threads.net'],
    apps:['com.instagram.android','com.facebook.katana','com.zhiliaoapp.musically','com.ss.android.ugc.trill','com.twitter.android','com.snapchat.android','com.reddit.frontpage','com.linkedin.android','com.pinterest','com.instagram.barcelona'] },
  { id:'msg', ic:'💭', name:'Messaggi',
    sites:['web.whatsapp.com','web.telegram.org','discord.com','messenger.com'],
    apps:['com.whatsapp','org.telegram.messenger','com.facebook.orca','com.discord','com.viber.voip','com.skype.raider'] },
  { id:'video', ic:'▶️', name:'Video e streaming',
    sites:['youtube.com','netflix.com','twitch.tv','primevideo.com','disneyplus.com','dailymotion.com','vimeo.com'],
    apps:['com.google.android.youtube','com.netflix.mediaclient','tv.twitch.android.app','com.amazon.avod.thirdpartyclient','com.disney.disneyplus','com.dailymotion.dailymotion'] },
  { id:'news', ic:'📰', name:'Notizie',
    sites:['repubblica.it','corriere.it','ansa.it','fanpage.it','ilfattoquotidiano.it','tgcom24.mediaset.it','news.google.com'],
    apps:['com.google.android.apps.magazines','flipboard.app','com.microsoft.amp.apps.bingnews'] },
  { id:'shop', ic:'🛒', name:'Shopping',
    sites:['amazon.it','ebay.it','aliexpress.com','temu.com','shein.com','zalando.it','subito.it','vinted.it'],
    apps:['com.amazon.mShop.android.shopping','com.ebay.mobile','com.alibaba.aliexpresshd','com.einnovation.temu','com.zzkko','de.zalando.mobile','it.subito','fr.vinted'] },
  { id:'games', ic:'🎮', name:'Giochi',
    sites:['roblox.com','epicgames.com','steampowered.com','miniclip.com','poki.com','y8.com','ea.com'],
    apps:['com.roblox.client','com.mojang.minecraftpe','com.supercell.clashofclans','com.supercell.brawlstars','com.king.candycrushsaga','com.dts.freefireth','com.tencent.ig','com.activision.callofduty.shooter','com.miHoYo.GenshinImpact','com.epicgames.fortnite'] },
  { id:'bet', ic:'🎰', name:'Scommesse',
    sites:['bet365.it','sisal.it','snai.it','eurobet.it','lottomatica.it','betfair.it','williamhill.it','pokerstars.it','goldbet.it','planetwin365.it'],
    apps:[] },
  { id:'dating', ic:'❤️', name:'Incontri',
    sites:['tinder.com','badoo.com','bumble.com','meetic.it','grindr.com','happn.com'],
    apps:['com.tinder','com.badoo.mobile','com.bumble.app','com.grindrapp.android','com.ftw_and_co.happn'] },
  { id:'sport', ic:'⚽', name:'Sport',
    sites:['gazzetta.it','corrieredellosport.it','tuttosport.com','sport.sky.it','dazn.com','espn.com','sportmediaset.mediaset.it','goal.com','transfermarkt.it','livescore.com'],
    apps:['com.dazn','com.espn.score_center','com.onefootball','com.sofascore.results','com.fivemobile.thescore','com.livescore','it.rcs.gazzetta','com.corrieredellosport'] },
  { id:'adult', ic:'🔞', name:'Adulti (18+)',
    sites:['pornhub.com','xvideos.com','xnxx.com','onlyfans.com','redtube.com','youporn.com','chaturbate.com','stripchat.com'],
    apps:[] }
];
/* Names for the packages of the default lists, so an app that is not installed still reads as
   "Facebook" on the Categories page and not as com.facebook.katana. */
const FL_APP_NAMES = {
  'com.instagram.android':'Instagram','com.facebook.katana':'Facebook','com.zhiliaoapp.musically':'TikTok','com.ss.android.ugc.trill':'TikTok (Asia)',
  'com.twitter.android':'X (Twitter)','com.snapchat.android':'Snapchat','com.reddit.frontpage':'Reddit','com.linkedin.android':'LinkedIn','com.pinterest':'Pinterest','com.instagram.barcelona':'Threads',
  'com.whatsapp':'WhatsApp','org.telegram.messenger':'Telegram','com.facebook.orca':'Messenger','com.discord':'Discord','com.viber.voip':'Viber','com.skype.raider':'Skype',
  'com.google.android.youtube':'YouTube','com.netflix.mediaclient':'Netflix','tv.twitch.android.app':'Twitch','com.amazon.avod.thirdpartyclient':'Prime Video','com.disney.disneyplus':'Disney+','com.dailymotion.dailymotion':'Dailymotion',
  'com.google.android.apps.magazines':'Google News','flipboard.app':'Flipboard','com.microsoft.amp.apps.bingnews':'Microsoft Start',
  'com.amazon.mShop.android.shopping':'Amazon','com.ebay.mobile':'eBay','com.alibaba.aliexpresshd':'AliExpress','com.einnovation.temu':'Temu','com.zzkko':'SHEIN','de.zalando.mobile':'Zalando','it.subito':'Subito','fr.vinted':'Vinted',
  'com.roblox.client':'Roblox','com.mojang.minecraftpe':'Minecraft','com.supercell.clashofclans':'Clash of Clans','com.supercell.brawlstars':'Brawl Stars','com.king.candycrushsaga':'Candy Crush','com.dts.freefireth':'Free Fire','com.tencent.ig':'PUBG Mobile','com.activision.callofduty.shooter':'Call of Duty Mobile','com.miHoYo.GenshinImpact':'Genshin Impact','com.epicgames.fortnite':'Fortnite',
  'com.dazn':'DAZN','com.espn.score_center':'ESPN','com.onefootball':'OneFootball','com.sofascore.results':'Sofascore','com.fivemobile.thescore':'theScore','com.livescore':'LiveScore','it.rcs.gazzetta':'Gazzetta dello Sport','com.corrieredellosport':'Corriere dello Sport',
  'com.tinder':'Tinder','com.badoo.mobile':'Badoo','com.bumble.app':'Bumble','com.grindrapp.android':'Grindr','com.ftw_and_co.happn':'happn'
};
const FL_CATS_KEY = 'fl_cats_edit';
let FL_CATS_BACK = 's-home';
let FL_CATS_OPEN = {};
let FL_CAT_APPS = null;          // installed apps [{packageName,label}], read once

function flCatsEdits(){
  try{ return JSON.parse(localStorage.getItem(FL_CATS_KEY) || '{}') || {}; }catch(_){ return {}; }
}
function flCatsSaveEdits(e){
  try{ localStorage.setItem(FL_CATS_KEY, JSON.stringify(e)); }catch(_){ }
  flCatsSyncSugg();
}
function flCatEdit(id){
  const e = flCatsEdits()[id] || {};
  return { offSites: e.offSites || [], offApps: e.offApps || [], addSites: e.addSites || [], addApps: e.addApps || [] };
}
/* What the category contains today: defaults minus what was removed, plus what was added. */
function flCatItems(cat){
  const e = flCatEdit(cat.id);
  const sites = cat.sites.filter(s => e.offSites.indexOf(s) < 0).concat(e.addSites.filter(s => cat.sites.indexOf(s) < 0));
  const apps = cat.apps.filter(a => e.offApps.indexOf(a) < 0).concat(e.addApps.filter(a => cat.apps.indexOf(a) < 0));
  return { sites: sites, apps: apps };
}
function flCatById(id){ return FL_CATS.filter(c => c.id === id)[0]; }
/* The apps a chip would really add: only the installed ones, once the list is known. */
function flCatInstalledApps(cat){
  const apps = flCatItems(cat).apps;
  if (typeof BLK_INSTALLED !== 'undefined' && BLK_INSTALLED) return apps.filter(a => BLK_INSTALLED.has(a));
  return apps;
}

/* The Web picker's suggestions (blocklist.js) are these same lists. */
function flCatsSyncSugg(){
  if (typeof UB_SUGGESTIONS === 'undefined') return;
  UB_SUGGESTIONS.length = 0;
  FL_CATS.forEach(c => {
    const items = flCatItems(c);
    if (items.sites.length) UB_SUGGESTIONS.push({ name: c.name, icon: c.ic, sites: items.sites });
  });
}

/* ---------------------------------------------------------------------------------------
   The chips, in the Quick Block and in the program editor
   --------------------------------------------------------------------------------------- */

function flCatTarget(where){
  if (where === 'quick'){
    if (typeof QUICK === 'undefined') return null;
    if (typeof EXTRA !== 'undefined' && EXTRA.listMode === 'allowlist') return null;   // an allow-list is not a place for "block Social"
    QUICK.keywords = QUICK.keywords || [];
    return { apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords };
  }
  if (typeof DRAFT === 'undefined' || !DRAFT) return null;
  DRAFT.apps = DRAFT.apps || []; DRAFT.sites = DRAFT.sites || []; DRAFT.keywords = DRAFT.keywords || [];
  return { apps: DRAFT.apps, sites: DRAFT.sites, keywords: DRAFT.keywords };
}
function flCatState(cat, target){
  const apps = flCatInstalledApps(cat), sites = flCatItems(cat).sites;
  const all = apps.length + sites.length;
  if (!all) return 'empty';
  const have = apps.filter(a => target.apps.indexOf(a) >= 0).length + sites.filter(s => target.sites.indexOf(s) >= 0).length;
  return have === 0 ? 'off' : (have === all ? 'on' : 'part');
}
/* The cards: a square with the emoji, the name under it, a green tick when the whole
   category is already in the list — the shape of the row in the reference app. */
function flCatsChips(where){
  const target = flCatTarget(where);
  if (!target) return '';
  return '<div class="cat-scroll">' + FL_CATS.map(c => {
    const st = flCatState(c, target);
    if (st === 'empty') return '';
    return '<button type="button" class="cat-card ' + st + '" onclick="flCatToggle(\'' + where + '\',\'' + c.id + '\')">'
      + '<span class="cat-ic">' + c.ic + '<i class="cat-chk"></i></span><span class="cat-nm">' + esc(c.name) + '</span></button>';
  }).join('') + '</div>';
}
function flCatsPaint(where){
  const host = document.getElementById(where === 'quick' ? 'qkCats' : 'edCats');
  if (!host) return;
  const chips = flCatsChips(where);
  const conGruppi = (typeof flGroupCount === 'function')
    && (flGroupCount('always') || flGroupCount('never') || flGroupCount('distract'));
  host.hidden = !chips && !conGruppi;
  if (host.hidden) return;
  const gruppi = (typeof flGroupChips === 'function') ? flGroupChips(where) : '';
  host.innerHTML = '<div class="cat-head"><b>Categorie</b><button type="button" onclick="flCatsOpen(\'' + (where === 'quick' ? 's-quick' : 's-editor') + '\')">Gestisci</button></div>' + chips + gruppi;
}
function flCatToggle(where, id){
  const cat = flCatById(id), target = flCatTarget(where);
  if (!cat || !target) return;
  const apps = flCatInstalledApps(cat), sites = flCatItems(cat).sites;
  const st = flCatState(cat, target);
  if (st === 'on'){
    apps.forEach(a => { const i = target.apps.indexOf(a); if (i >= 0) target.apps.splice(i, 1); });
    sites.forEach(s => { const i = target.sites.indexOf(s); if (i >= 0) target.sites.splice(i, 1); });
  } else {
    apps.forEach(a => { if (target.apps.indexOf(a) < 0) target.apps.push(a); });
    sites.forEach(s => { if (target.sites.indexOf(s) < 0) target.sites.push(s); });
    if (!apps.length && cat.apps.length && typeof BLK_INSTALLED !== 'undefined' && BLK_INSTALLED) toast('Nessuna app di questa categoria è installata: aggiunti i siti');
  }
  if (where === 'quick'){ if (typeof paintQuick === 'function') paintQuick(); }
  else if (typeof refreshEditorCounts === 'function') refreshEditorCounts();
}

/* The two hosts are put into the frozen screens once, next to the rows they feed. */
/* Between the Applications row and the Sites row, in both screens. */
function flCatsEnsureHosts(){
  if (!document.getElementById('qkCats')){
    const chips = document.getElementById('qkChipApps');
    if (chips && chips.parentNode){
      const box = document.createElement('div'); box.className = 'cat-block'; box.id = 'qkCats';
      chips.parentNode.insertBefore(box, chips.nextSibling);
    }
  }
  if (!document.getElementById('edCats')){
    const cnt = document.getElementById('edWebCount');
    let row = cnt; while (row && !(row.classList && row.classList.contains('setrow'))) row = row.parentElement;
    if (row && row.parentNode){
      const box = document.createElement('div'); box.className = 'cat-block'; box.id = 'edCats';
      row.parentNode.insertBefore(box, row);
    }
  }
}

/* ---------------------------------------------------------------------------------------
   The Categories page
   --------------------------------------------------------------------------------------- */

registerScreen('s-cats', `
  <div class="topbar"><button class="iconbtn" onclick="flCatsClose()">‹</button><b class="blk-title">Categorie</b></div>
  <div class="hintline" style="padding:0 2px 12px">Ogni categoria è una lista pronta di siti e app. Togli quello che non c'entra, aggiungi quello che manca: i suggerimenti del Blocco rapido e dei programmi seguono queste liste.</div>
  <div id="catsList"></div>
  <div class="spacer"></div>
`, { back: 's-home' });

async function flCatsOpen(back){
  FL_CATS_BACK = back || 's-home';
  goId('s-cats');
  flCatsPaintPage();
  if (!FL_CAT_APPS && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInstalledApps){
    try{ const r = await flApps(); FL_CAT_APPS = (r && r.apps) || []; flCatsPaintPage(); }catch(_){ FL_CAT_APPS = []; }
  }
}
function flCatsClose(){
  goId(FL_CATS_BACK);
  if (FL_CATS_BACK === 's-home' && typeof switchTab === 'function') switchTab('profilo');
  flCatsPaint('quick'); flCatsPaint('draft');
}
function flCatAppLabel(pkg){
  const a = (FL_CAT_APPS || []).filter(x => x.packageName === pkg)[0]
         || (typeof APPS_CACHE !== 'undefined' ? APPS_CACHE.filter(x => x.packageName === pkg)[0] : null);
  return a && a.label ? a.label : (FL_APP_NAMES[pkg] || pkg);
}
function flCatsPaintPage(){
  const box = document.getElementById('catsList');
  if (!box) return;
  const installedKnown = typeof BLK_INSTALLED !== 'undefined' && BLK_INSTALLED;
  box.innerHTML = FL_CATS.map(c => {
    const e = flCatEdit(c.id), items = flCatItems(c), open = !!FL_CATS_OPEN[c.id];
    const edited = e.offSites.length || e.offApps.length || e.addSites.length || e.addApps.length;
    const allSites = c.sites.concat(e.addSites.filter(s => c.sites.indexOf(s) < 0));
    const allApps = c.apps.concat(e.addApps.filter(a => c.apps.indexOf(a) < 0));
    const sitesHtml = allSites.map(s =>
      '<label class="catc-row"><input type="checkbox"' + (items.sites.indexOf(s) >= 0 ? ' checked' : '') + ' onchange="flCatSet(\'' + c.id + '\',\'site\',\'' + esc(s) + '\',this.checked)"><span>' + esc(s) + '</span></label>').join('');
    const appsHtml = allApps.length ? allApps.map(a =>
      '<label class="catc-row"><input type="checkbox"' + (items.apps.indexOf(a) >= 0 ? ' checked' : '') + ' onchange="flCatSet(\'' + c.id + '\',\'app\',\'' + esc(a) + '\',this.checked)"><span>' + esc(flCatAppLabel(a)) + '</span>'
      + (installedKnown && !BLK_INSTALLED.has(a) ? '<small>non installata</small>' : '') + '</label>').join('')
      : '<div class="hintline" style="padding:6px 0">Nessuna app in questa categoria.</div>';
    return '<div class="catc' + (open ? ' open' : '') + '" id="catc-' + c.id + '">'
      + '<div class="catc-h" onclick="flCatsToggleOpen(\'' + c.id + '\')"><span class="em">' + c.ic + '</span><div><b>' + esc(c.name) + '</b>'
      + '<small>' + items.sites.length + ' siti · ' + items.apps.length + ' app' + (edited ? ' · modificata' : '') + '</small></div><span class="blk-tplchev' + (open ? ' up' : '') + '"></span></div>'
      + '<div class="catc-b">'
      + '<div class="catc-sub">Siti</div>' + sitesHtml
      + '<div class="catc-add"><input class="fin" id="catAddSite-' + c.id + '" placeholder="es. sito.com" autocomplete="off" inputmode="url" enterkeyhint="done" onkeydown="if(event.key===\'Enter\'){flCatAddSite(\'' + c.id + '\');return false}"><button type="button" class="ghostmini" onclick="flCatAddSite(\'' + c.id + '\')">Aggiungi</button></div>'
      + '<div class="catc-sub">App</div>' + appsHtml
      + '<div class="catc-add"><input class="fin" id="catAddApp-' + c.id + '" placeholder="Cerca un\'app installata…" autocomplete="off" oninput="flCatFindApp(\'' + c.id + '\')"></div>'
      + '<div class="catc-found" id="catFound-' + c.id + '"></div>'
      + (edited ? '<button type="button" class="ghostmini catc-reset" onclick="flCatReset(\'' + c.id + '\')">Ripristina la lista originale</button>' : '')
      + '</div></div>';
  }).join('');

  /* In fondo, i tre gruppi tuoi. Le categorie qui sopra sono liste che valgono per tutti;
     quelle no — sono quello che serve a te, scritto una volta e riusato a ogni sessione. */
  if (typeof flGroupsCardsHtml === 'function'){
    box.innerHTML += flGroupsCardsHtml();
    if (typeof ubFillIcons === 'function') ubFillIcons(box);
  }
}
function flCatsToggleOpen(id){ FL_CATS_OPEN[id] = !FL_CATS_OPEN[id]; flCatsPaintPage(); }
function flCatSet(id, kind, item, on){
  const cat = flCatById(id); if (!cat) return;
  const all = flCatsEdits(); const e = all[id] || {}; all[id] = e;
  const isDefault = (kind === 'site' ? cat.sites : cat.apps).indexOf(item) >= 0;
  const offK = kind === 'site' ? 'offSites' : 'offApps', addK = kind === 'site' ? 'addSites' : 'addApps';
  e[offK] = e[offK] || []; e[addK] = e[addK] || [];
  if (isDefault){
    if (on) e[offK] = e[offK].filter(x => x !== item);
    else if (e[offK].indexOf(item) < 0) e[offK].push(item);
  } else {
    if (on){ if (e[addK].indexOf(item) < 0) e[addK].push(item); }
    else e[addK] = e[addK].filter(x => x !== item);
  }
  flCatsSaveEdits(all);
  flCatsPaintPage();
}
function flCatAddSite(id){
  const inp = document.getElementById('catAddSite-' + id); if (!inp) return;
  let v = (inp.value || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[\/?#]/)[0];
  if (!v || v.indexOf('.') < 0){ toast('Scrivi un dominio, es. sito.com'); return; }
  flCatSet(id, 'site', v, true);
  FL_CATS_OPEN[id] = true; flCatsPaintPage();
}
function flCatFindApp(id){
  const inp = document.getElementById('catAddApp-' + id), out = document.getElementById('catFound-' + id);
  if (!inp || !out) return;
  const q = (inp.value || '').trim().toLowerCase();
  if (!q){ out.innerHTML = ''; return; }
  const list = FL_CAT_APPS || (typeof APPS_CACHE !== 'undefined' ? APPS_CACHE : []);
  const cat = flCatById(id), have = flCatItems(cat).apps;
  const hits = list.filter(a => (a.label || '').toLowerCase().indexOf(q) >= 0 && have.indexOf(a.packageName) < 0).slice(0, 6);
  out.innerHTML = hits.length
    ? hits.map(a => '<button type="button" class="catc-hit" onclick="flCatSet(\'' + id + '\',\'app\',\'' + esc(a.packageName) + '\',true);FL_CATS_OPEN[\'' + id + '\']=true;flCatsPaintPage()">＋ ' + esc(a.label) + '</button>').join('')
    : '<div class="hintline" style="padding:6px 0">' + (list.length ? 'Nessuna app installata con questo nome.' : 'Leggo le app installate…') + '</div>';
}
function flCatReset(id){
  const all = flCatsEdits(); delete all[id]; flCatsSaveEdits(all); flCatsPaintPage();
}

/* ---------------------------------------------------------------------------------------
   Wiring: the hosts, the repaints, the styles
   --------------------------------------------------------------------------------------- */

(function flCatsWire(){
  flCatsEnsureHosts();
  flCatsSyncSugg();
  const prevQuick = window.paintQuick;
  window.paintQuick = function(){
    try{ if (typeof prevQuick === 'function') prevQuick.apply(this, arguments); }catch(e){}
    try{ flCatsPaint('quick'); }catch(e){}
  };
  const prevCounts = window.refreshEditorCounts;
  window.refreshEditorCounts = function(){
    try{ if (typeof prevCounts === 'function') prevCounts.apply(this, arguments); }catch(e){}
    try{ flCatsPaint('draft'); }catch(e){}
  };
  const css = [
    '.cat-block{margin:6px 0 14px}',
    '.cat-head{display:flex;align-items:center;justify-content:space-between;padding:0 2px 8px}',
    '.cat-head b{font:800 15px var(--font-display);color:var(--navy)}',
    '.cat-head button{border:0;background:none;font:700 12px var(--font-body);color:var(--blue);cursor:pointer;padding:0}',
    '.cat-scroll{display:flex;gap:10px;overflow-x:auto;scrollbar-width:none;padding:12px;background:#F3F5F8;border-radius:18px}',
    '.cat-scroll::-webkit-scrollbar{display:none}',
    '.cat-card{flex:0 0 auto;width:96px;border:0;background:transparent;padding:0;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.cat-ic{position:relative;width:96px;height:92px;border-radius:14px;background:#fff;border:1.5px solid #E3E8F0;display:grid;place-items:center;font-size:40px;line-height:1;transition:background .2s,border-color .2s}',
    '.cat-nm{font:600 12.5px var(--font-body);color:var(--navy);white-space:nowrap;max-width:96px;overflow:hidden;text-overflow:ellipsis}',
    '.cat-chk{position:absolute;top:6px;right:6px;width:20px;height:20px;border-radius:50%;background:#22A06B;display:none}',
    '.cat-chk::after{content:"";position:absolute;left:6px;top:3px;width:5px;height:9px;border:solid #fff;border-width:0 2.2px 2.2px 0;transform:rotate(45deg)}',
    '.cat-card.on .cat-ic{background:#DDF3E8;border-color:#22A06B}',
    '.cat-card.on .cat-chk{display:block}',
    '.cat-card.part .cat-ic{background:var(--blue-soft);border-color:var(--blue)}',
    'body.dark .cat-scroll{background:#0E1B33}body.dark .cat-ic{background:#12203A;border-color:#22345A}body.dark .cat-nm{color:#fff}',
    '.catc{background:#fff;border:1px solid var(--line);border-radius:14px;margin-bottom:10px;overflow:hidden}',
    '.catc-h{display:flex;align-items:center;gap:12px;padding:13px 14px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.catc-h .em{font-size:22px;line-height:1}',
    '.catc-h > div{flex:1;min-width:0}',
    '.catc-h b{display:block;font:700 14px var(--font-body);color:var(--navy)}',
    '.catc-h small{display:block;font:500 11.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.catc-h .blk-tplchev.up{transform:rotate(180deg)}',
    '.catc-b{display:none;padding:0 14px 14px;border-top:1px solid var(--line)}',
    '.catc.open .catc-b{display:block}',
    '.catc-sub{font:700 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:12px 0 2px}',
    '.catc-row{display:flex;align-items:center;gap:10px;padding:7px 0;font:600 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.catc-row input{width:18px;height:18px;margin:0;accent-color:var(--blue);flex:none}',
    '.catc-row span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.catc-row small{font:500 11px var(--font-body);color:var(--faint);white-space:nowrap}',
    '.catc-add{display:flex;gap:8px;align-items:center;margin-top:6px}',
    '.catc-add .fin{flex:1;margin:0}',
    '.catc-add .ghostmini{margin:0;flex:none}',
    '.catc-found{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}',
    '.catc-hit{border:1px solid var(--line);background:#fff;border-radius:99px;padding:6px 11px;font:600 12px var(--font-body);color:var(--navy);cursor:pointer}',
    '.catc-reset{margin:12px 0 0;width:100%}',
    'body.dark .catc,body.dark .catc-hit{background:#12203A;border-color:#22345A}',
    'body.dark .catc-h b,body.dark .catc-row,body.dark .catc-hit{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
