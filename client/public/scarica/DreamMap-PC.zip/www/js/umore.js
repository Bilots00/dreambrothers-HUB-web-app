/* ===========================================================================================
   IL CONTROLLO DELL'UMORE — una domanda sola, e una nota

   PERCHÉ ESISTE, E DOVE NON DEVE ARRIVARE.

   Tutto il resto di quest'app misura FATTI: minuti di schermo, blocchi tenuti, sessioni finite,
   righe spuntate. È di proposito, e non cambia: l'orario di arrivo a destinazione e la
   traiettoria si calcolano solo su quelli. Un'ora è un'ora anche nei giorni in cui ti sembrava
   di non combinare niente, e una previsione costruita su come ti sentivi sarebbe una previsione
   che si muove insieme all'umore di chi la legge — cioè inutile proprio nei giorni storti, che
   sono gli unici in cui serve.

   Ma «come è andata» non è la stessa domanda di «quanto hai fatto», e la differenza è tutta
   qui: due giornate identiche nei numeri possono essere una vittoria e una tortura. Quella
   differenza non serve a PREVEDERE, serve a DECIDERE COME CHIEDERE. C'è chi vuole essere
   spinto e arriva prima con una scadenza stretta, e chi davanti alla stessa scadenza si blocca.
   Trattarli allo stesso modo vuol dire sbagliare con uno dei due, sempre.

   QUINDI, e questa è la regola che governa tutto il file:

     · agli ORIZZONTI e alle PREVISIONI questi dati NON arrivano. Mai. La stima resta oggettiva.
     · a JORDAN arrivano per intero: è lui che riordina le priorità, e riordinarle senza sapere
       se la settimana è stata una salita o una passeggiata è riordinare alla cieca.
     · al GENIO arriva solo il DIVARIO — quanto l'app ha contato contro quanto hai sentito — e
       serve a una cosa sola: scegliere quali domande fare.

   SI CHIEDE UNA COSA SOLA: come ti sei sentito. «Quanto hai fatto» era una domanda a cui
   l'app sa già rispondere — le sessioni finite e le righe spuntate le ha contate lei — e
   chiederla voleva dire chiedere un'opinione su un fatto già misurato. Il confronto che ne
   esce adesso è più onesto: un fatto contro un'opinione, non due opinioni.

   Dove sta: in fondo al Report del giorno, che è l'unico posto dove uno ha appena finito di
   guardare com'è andata davvero. Chiederlo prima sarebbe chiedere un'opinione a chi non ha
   ancora visto i fatti.
   =========================================================================================== */

const UM_KEY = 'fl_umore';

/* LE ICONE SONO SVG, NON CARATTERI (regola 16 del copy UI, 10/10/2026). Chevron e matita
   disegnate a tratto come le icone del tema Shopify: currentColor, 16-18px, stesse linee
   arrotondate. Un carattere come «›» o «⌄» cambia forma e peso da un font all'altro. */
function umIco(d, cls, px){ return '<svg class="um-ico' + (cls ? ' ' + cls : '') + '" width="' + (px || 17) + '" height="' + (px || 17) + '" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + d + '</svg>'; }
const UM_ICO_GIU = umIco('<path d="M5 7.5l5 5 5-5"/>', 'giu');
const UM_ICO_AVANTI = umIco('<path d="M7.5 4.5l5.5 5.5-5.5 5.5"/>', 'avanti');
const UM_ICO_INDIETRO = umIco('<path d="M12.5 4.5L7 10l5.5 5.5"/>', 'indietro', 18);
const UM_ICO_MATITA = umIco('<path d="M13.6 3.6a1.9 1.9 0 0 1 2.8 2.8L7 15.8l-3.6.8.8-3.6z"/><path d="M12 5.2l2.8 2.8"/>', 'matita', 18);
const UM_ICO_PIU = umIco('<path d="M10 4v12M4 10h12"/>', 'piu', 18);
const UM_ICO_INVIA = umIco('<path d="M10 16V4.5M5 9.5l5-5 5 5"/>', 'invia', 20);

/* Cinque gradini, con un nome ciascuno. Un cursore da 1 a 10 sembra più preciso e non lo è:
   nessuno sa che differenza c'è fra un 6 e un 7 della propria giornata, e la finta precisione
   fa rispondere a caso. Cinque parole invece si scelgono.

   UNA SOLA DOMANDA. C'era anche «quanto hai fatto», ed era una domanda a cui l'app sa già
   rispondere da sola: le sessioni finite e le righe spuntate le ha contate lei, tutto il
   giorno. Chiederla voleva dire chiedere un'opinione su un fatto già misurato, e la risposta
   sarebbe stata peggiore del dato. Resta l'unica cosa che nessun sensore può leggere. */
const UM_VOCI = ['Malissimo', 'Storta', 'Così così', 'Bene', 'Benissimo'];
const UM_EMOJI = ['\u{1F62B}', '\u{1F615}', '\u{1F610}', '\u{1F642}', '\u{1F929}'];

function umTutti(){
  try{ return JSON.parse(localStorage.getItem(UM_KEY) || '{}') || {}; }catch(_){ return {}; }
}
function umSalvaTutti(v){
  try{ localStorage.setItem(UM_KEY, JSON.stringify(v || {})); }catch(_){ }
}

/** Il controllo di un giorno, o null se quel giorno non è stato chiuso. */
function umLeggi(day){
  const v = umTutti()[day];
  return v && (v.prod || v.sodd || v.nota) ? v : null;
}

function umScrivi(day, patch){
  const t = umTutti();
  t[day] = Object.assign({ prod: 0, sodd: 0, nota: '', at: 0 }, t[day] || {}, patch || {});
  t[day].at = Date.now();
  umSalvaTutti(t);
}

function umGiorno(off){
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - (off || 0));
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/**
 * Quanto ha fatto davvero quel giorno, secondo l'app: sessioni di concentrazione portate a
 * termine e righe spuntate.
 *
 * <p>Non si chiede, si conta. Ed è meglio così anche per il confronto che ne esce: da una
 * parte un FATTO misurato, dall'altra un'opinione. Prima erano due opinioni.</p>
 */
function umGiornoDi(ts){
  const d = new Date(ts);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0')
    + '-' + String(d.getDate()).padStart(2, '0');
}

function umFattoVero(day){
  let n = 0;
  try{
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    n += h.filter(function(x){ return x && x.ok && umGiornoDi(x.at) === day; }).length;
  }catch(_){ }
  try{
    const d = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
    n += d.filter(function(x){ return x && x.day === day; }).length;
  }catch(_){ }
  /* Da un conteggio ai soliti cinque gradini, così i due numeri si possono mettere uno
     accanto all'altro senza convertire niente. */
  if (n <= 0) return 1;
  if (n === 1) return 2;
  if (n === 2) return 3;
  if (n <= 4) return 4;
  return 5;
}

/* ---------------------------------------------------------------------------------------
   La riga in fondo al Report
   --------------------------------------------------------------------------------------- */

/**
 * Una riga e un più, come su AppBlock.
 *
 * <p>Qui c'era un paragrafo di tre righe che spiegava a cosa serviva la sezione. Chi apre il
 * Report in fondo a una giornata non legge una spiegazione su una funzione: o capisce in mezzo
 * secondo, o passa oltre — e passando oltre non la userà mai. Un titolo e un più si capiscono
 * senza leggere niente.</p>
 *
 * @param oggi solo oggi si può ancora chiudere una giornata: riaprire una settimana fa e
 *             inventarsi come ci si sentiva non è un ricordo, è un dato falso messo lì adesso.
 */
function umCard(day, oggi){
  /* 0.9.302, Andrea: "se provo a modificare l'umore messo il giorno prima non me lo fa fare: deve essere possibile
     cambiare anche quello di ieri". Oggi e ieri si cambiano; piu' indietro resta un ricordo, non si riscrive. */
  const ieri = day === umGiorno(1);
  const quando = oggi ? 'di oggi' : 'di ieri';
  oggi = oggi || ieri;
  const v = umLeggi(day);
  const testa = '<div class="um-testa"><b>Controllo dell\'umore</b>'
    + (oggi ? '<button type="button" class="um-piu" onclick="umApri(\'' + day + '\')"'
        + ' aria-label="' + (v ? 'Cambia l\u2019umore ' + quando : 'Segna l\u2019umore ' + quando) + '">' + (v ? UM_ICO_MATITA : UM_ICO_PIU) + '</button>' : '')
    + '</div>';
  if (!v) return testa + (oggi ? '' : '<p class="um-niente">Quel giorno non hai segnato come ti sentivi.</p>');
  const n = v.sodd || 0;
  return testa
    + '<div class="um-card"' + (oggi ? ' onclick="umApri(\'' + day + '\')"' : '') + '>'
    /* niente «4/5» accanto alla faccina: sembra il voto del professore (regola 15) */
    +   '<div class="um-riga"><span>' + (n ? UM_EMOJI[n - 1] : '') + '</span>'
    +     '<div><b>' + (n ? esc(UM_VOCI[n - 1]) : '') + '</b></div></div>'
    +   (v.nota ? '<p class="um-nota">“' + esc(v.nota) + '”</p>' : '')
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   Il foglio
   --------------------------------------------------------------------------------------- */

let UM_DAY = '';

let UM_SOLO = false;
/* 0.9.326, Andrea: "prima risponde votando tra le 5 emoji, poi se c'e' qualcosa da scrivere; e il pulsante dei grafici solo dopo aver risposto a tutto". Vale anche per la scorciatoia. */
let UM_PASSO = 1;
/* LA SCELTA NON E' UN VOTO FINCHE' NON SI PREME «SALVA» (0.9.217, bug di Andrea). Prima ogni
   faccina toccata scriveva subito in fl_umore: dalla scorciatoia di Dream bastava sfiorare una
   faccina e chiudere il foglio per avere il voto salvato. Adesso la faccina scelta e il testo
   vivono solo qui, in memoria, e finiscono in fl_umore (con chat, diario e il resto) soltanto
   in umConferma(). Chiudere il foglio senza «Salva» butta via la scelta. */
let UM_SCELTA = 0;
let UM_BOZZA = '';
/* opz.soloVoto: solo la domanda, senza la casella del testo (la scorciatoia della Rotta) */
function umApri(day, opz){
  UM_DAY = day || umGiorno(0);
  UM_SOLO = !!(opz && opz.soloVoto);
  UM_PASSO = 1;
  const gia = umLeggi(UM_DAY) || {};
  UM_SCELTA = +gia.sodd || 0;
  UM_BOZZA = String(gia.nota || '');
  let w = document.getElementById('umSheet');
  if (!w){
    w = document.createElement('div');
    w.id = 'umSheet';
    w.className = 'um-sheet';
    w.addEventListener('click', function(e){ if (e.target === w) umChiudi(); });
    document.body.appendChild(w);
  }
  umPaint();
  w.hidden = false;
}

function umChiudi(){
  const w = document.getElementById('umSheet');
  if (w) w.remove();
}

function umPaint(){
  const w = document.getElementById('umSheet');
  if (!w) return;
  const v = { sodd: UM_SCELTA, nota: UM_BOZZA };
  let b = '';
  for (let n = 1; n <= 5; n++){
    b += '<button type="button" class="um-p' + (v.sodd === n ? ' on' : '') + '"'
      + ' onclick="umVoto(' + n + ')" aria-label="' + UM_VOCI[n - 1] + '"><span>' + UM_EMOJI[n - 1] + '</span></button>';
  }
  /* 0.9.305: il foglio si apre anche da solo entrando nel Report (rpUmoreForse): ha la sua X, oltre al tocco fuori */
  const ieri = UM_DAY === umGiorno(1);
  const x = '<button type="button" class="um-x" onclick="umChiudi()" aria-label="Chiudi">✕</button><i class="pr-grab"></i>';
  if (UM_PASSO === 3){
    w.innerHTML = '<div class="um-in um-fine">' + x + '<span class="um-fine-e">' + UM_EMOJI[(UM_SCELTA || 3) - 1] + '</span><h3>Salvato nel tuo diario di viaggio</h3>'
      + '<button type="button" class="cta" onclick="umChiudi();umInfoApri()">Guarda come cambia il tuo umore</button>'
      + '<button type="button" class="um-info-link" onclick="umChiudi()">Chiudi</button></div>';
    return;
  }
  if (UM_PASSO === 2){
    w.innerHTML = '<div class="um-in">' + x
      + '<button type="button" class="um-rivota" onclick="UM_PASSO=1;umSalvaBozza();umPaint()" aria-label="Cambia il voto"><span>' + UM_EMOJI[(UM_SCELTA || 3) - 1] + '</span></button>'
      + '<h3>Vuoi scrivere qualcosa su ' + (ieri ? 'ieri' : 'oggi') + '?</h3>'
      + '<p class="um-sub">Resta nel tuo diario di viaggio. Anche una riga va bene.</p>'
      + '<textarea class="fin um-ta" id="umNota" rows="4" placeholder="' + (ieri ? 'Cosa ti ha aiutato ieri, e cosa ti ha pesato…' : 'Cosa ti ha aiutato oggi, e cosa ti ha pesato…') + '">' + esc(v.nota || '') + '</textarea>'
      + '<button type="button" class="cta" onclick="umConferma()">Salva</button>'
      + '<button type="button" class="um-info-link" onclick="umConferma()">Salta, non scrivo niente</button></div>';
    return;
  }
  w.innerHTML = '<div class="um-in">' + x
    + '<h3>' + (ieri ? 'Com’è andata ieri?' : 'Come ti senti oggi?') + '</h3>'
    /* La riga che dice cosa vale la faccina più contenta, e nient'altro. Senza, la si sceglie
       a caso: nessuno sa rispetto a cosa sta votando. In parole, non «5 =» (regola 12). */
    + '<p class="um-sub">La faccina più contenta vuol dire: una giornata che rifaresti identica.</p>'
    + '<div class="um-p-row">' + b + '</div>'
    + '<p class="um-sc-v">' + (v.sodd ? esc(UM_VOCI[v.sodd - 1]) : '&nbsp;') + '</p>'
    + '</div>';
}
function umSalvaBozza(){ const ta = document.getElementById('umNota'); if (ta) UM_BOZZA = String(ta.value || ''); }

function umVoto(n){
  /* solo la scelta, in memoria: niente fl_umore, niente chat, niente diario fino a «Salva».
     Il testo gia' scritto nel riquadro resta (0.9.214): si tiene in UM_BOZZA prima di ridisegnare. */
  const ta = document.getElementById('umNota');
  if (ta) UM_BOZZA = String(ta.value || '');
  UM_SCELTA = n;
  try{ flVibra(10); }catch(_){ }
  umPaint();
  /* si vede la faccina scelta, poi la domanda dopo */
  clearTimeout(umVoto._t);
  umVoto._t = setTimeout(function(){ if (UM_PASSO === 1 && document.getElementById('umSheet')){ UM_PASSO = 2; umPaint(); } }, 380);
}

function umConferma(){
  const t = document.getElementById('umNota');
  if (t) UM_BOZZA = String(t.value || '');
  if (!UM_SCELTA){ if (typeof toast === 'function') toast('Scegli la faccina che descrive la tua giornata'); return; }
  const prima = +((umLeggi(UM_DAY) || {}).sodd) || 0;
  const patch = { sodd: UM_SCELTA };
  if (t) patch.nota = UM_BOZZA.trim();
  umScrivi(UM_DAY, patch);
  try{ flVibra(18); }catch(_){ }
  /* 0.9.217: dopo «Salva» di oggi si apre la breve conversazione con il Genio, per tutti
     (con Premium le reazioni le scrive l'agente vero, senza Premium sono scritte qui) */
  try{ if (document.getElementById('s-umore-info').classList.contains('active')) umInfoPaint(); }catch(_){ }
  /* Il backup se lo porta via da solo al prossimo giro: sta in localStorage come tutto il
     resto delle preferenze, e flWebDump() prende tutto. */
  if (typeof insRender === 'function') try{ insRender(); }catch(_){ }
  /* 0.9.219: dalla scorciatoia di Dream si può CAMBIARE l'umore di oggi. Se la faccina salvata
     è la stessa di prima e la conversazione di oggi c'è già, non si riapre la conversazione:
     basta dire che l'umore è salvato. */
  const chatFatta = (function(){ try{ const g = umcStato().giorni[UM_DAY]; return !!(g && g.q1); }catch(_){ return false; } })();
  if (UM_DAY === umGiorno(0) && typeof umChatApri === 'function' && !(prima && prima === UM_SCELTA && chatFatta)){ umChiudi(); umChatApri(UM_DAY); return; }
  UM_PASSO = 3; umPaint();
}

/* ---------------------------------------------------------------------------------------
   INFORMAZIONI SULL'UMORE (0.9.181) — come la pagina di Meditopia, con i colori del brand:
     · 7 giorni: una colonna per giorno che si riempie dal basso, con la faccina in cima;
       sotto, la media di questa settimana e quella della settimana scorsa;
     · 30 giorni: una linea sui voti da 1 a 5, con i giorni del mese sotto; sotto, la media
       del mese e il numero di controlli;
     · «Più selezionato»: i motivi scelti più spesso nella chat dell'umore;
     · il pannello «Come ti senti oggi?» c'è solo finché oggi non hai votato: per cambiare il
       voto ci sono la scorciatoia di Dream (0.9.219) e il Report.
   --------------------------------------------------------------------------------------- */
const UM_INFO = { giorni: 7 };
const UM_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
registerScreen('s-umore-info',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')" aria-label="Indietro">' + UM_ICO_INDIETRO + '</button><b class="blk-title">Informazioni sull’umore</b></div>'
  + '<div class="al-page" id="umInfoBody"></div><div class="spacer"></div>', { back: 's-home' });
function umInfoApri(){ goId('s-umore-info'); umInfoPaint(); }
function umInfoGiorni(n){ UM_INFO.giorni = n; umInfoPaint(); }
/* La media in faccina e parola, non in numero: «3,4» da solo non dice di cosa è il conto (regola 15). */
function umNum(x){ if (!x) return '<span class="umi-vuoto">Ancora nessun voto</span>'; const k = Math.min(5, Math.max(1, Math.round(x))); return '<span class="umi-fac">' + UM_EMOJI[k - 1] + '</span>' + UM_VOCI[k - 1]; }
function umDataTxt(d){ return (d.getDate() === 1 ? '1°' : d.getDate()) + ' ' + UM_MESI[d.getMonth()]; }
/** «Dal 4 al 10 ottobre», con l'apostrofo davanti all'8 e all'11: «Dall’8», «all’11». */
function umDalAl(a, b){
  const ap = function(d){ return d.getDate() === 8 || d.getDate() === 11; };
  return (ap(a) ? 'Dall’' : 'Dal ') + umDataTxt(a) + (ap(b) ? ' all’' : ' al ') + umDataTxt(b);
}
/** I giorni del periodo, dal più vecchio a oggi. `da` = quanti giorni indietro comincia la finestra. */
function umPeriodo(n, da){
  const tutti = umTutti(), out = [];
  for (let i = (da || 0) + n - 1; i >= (da || 0); i--){
    const k = umGiorno(i), v = tutti[k];
    const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - i);
    out.push({ k: k, d: d, v: v && v.sodd ? v.sodd : 0, motivi: (v && v.motivi) || [] });
  }
  return out;
}
function umMedia(g){ const c = g.filter(function(x){ return x.v; }); return c.length ? c.reduce(function(a, x){ return a + x.v; }, 0) / c.length : 0; }
function umInfoPaint(){
  const host = document.getElementById('umInfoBody'); if (!host) return;
  const n = UM_INFO.giorni;
  const giorni = umPeriodo(n, 0), prima = umPeriodo(n, n);
  const con = giorni.filter(function(g){ return g.v; });
  const oggiV = umLeggi(umGiorno(0));
  const G = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
  let grafico = '', boxes = '';
  if (n === 7){
    grafico = '<div class="umi-c7">' + giorni.map(function(g, i){
      const h = g.v ? Math.max(22, g.v / 5 * 100) : 0;
      return '<div class="umi-col"><div class="umi-track">' + (g.v ? '<div class="umi-fill v' + g.v + '" data-h="' + h + '" style="--d:' + (i * 70) + 'ms"><span>' + UM_EMOJI[g.v - 1] + '</span></div>' : '') + '</div><small>' + G[g.d.getDay()] + '</small></div>';
    }).join('') + '</div>';
    boxes = '<div class="umi-box blu"><small>Il tuo umore di questa settimana</small><b>' + umNum(umMedia(giorni)) + '</b></div>'
      + '<div class="umi-box rosa"><small>Il tuo umore della settimana scorsa</small><b>' + umNum(umMedia(prima)) + '</b></div>';
  } else {
    const W = 300, H = 170, x0 = 28, x1 = 292, y = function(v){ return 12 + (5 - v) * 36; };
    const x = function(i){ return x0 + i * (x1 - x0) / (n - 1); };
    let svg = '';
    /* sull'asse le faccine, non i numeri da 1 a 5 */
    for (let v = 1; v <= 5; v++) svg += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + y(v) + '" y2="' + y(v) + '" class="umi-griglia"/><text x="11" y="' + (y(v) + 5) + '" class="umi-asse fac">' + UM_EMOJI[v - 1] + '</text>';
    [0, 7, 14, 21, 28].forEach(function(i){ if (i < n){ svg += '<line x1="' + x(i) + '" x2="' + x(i) + '" y1="' + y(5) + '" y2="' + y(1) + '" class="umi-vert"/><text x="' + x(i) + '" y="' + (H - 2) + '" class="umi-asse c">' + giorni[i].d.getDate() + '</text>'; } });
    const punti = giorni.map(function(g, i){ return g.v ? [x(i), y(g.v), g.v] : null; }).filter(Boolean);
    if (punti.length > 1) svg += '<polyline class="umi-linea" points="' + punti.map(function(p){ return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ') + '"/>';
    punti.forEach(function(p){ svg += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="5" class="umi-punto v' + p[2] + '"/>'; });
    grafico = '<svg class="umi-c30" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Come è cambiato il tuo umore negli ultimi 30 giorni">' + svg + '</svg>';
    boxes = '<div class="umi-box blu"><small>Il tuo umore in questi 30 giorni</small><b>' + umNum(umMedia(giorni)) + '</b></div>'
      + '<div class="umi-box rosa"><small>Giorni in cui hai segnato il tuo umore</small><b>' + con.length + '</b></div>';
  }
  /* i motivi scelti più spesso, nel periodo */
  const conta = {};
  giorni.forEach(function(g){ g.motivi.forEach(function(m){ conta[m] = (conta[m] || 0) + 1; }); });
  const top = Object.keys(conta).sort(function(a, b){ return conta[b] - conta[a]; }).slice(0, 3);
  host.innerHTML = '<div class="umi-tabs"><button type="button" class="' + (n === 7 ? 'on' : '') + '" onclick="umInfoGiorni(7)">7 giorni</button><button type="button" class="' + (n === 30 ? 'on' : '') + '" onclick="umInfoGiorni(30)">30 giorni</button></div>'
    + (oggiV && oggiV.sodd ? '' : '<div class="umi-card umi-centro"><img class="umi-genio" src="img/genio/genio-pensa.png" alt=""><h3>Come ti senti oggi?</h3><p>Segna il tuo umore ogni giorno: in questa pagina vedrai come cambia il tuo umore, giorno dopo giorno.</p>'
      + '<button type="button" class="cta umi-cta" onclick="umApri(umGiorno(0),{soloVoto:true})">Registra il tuo umore</button></div>')
    + '<div class="umi-card umi-centro"><h4>Come cambia il tuo umore</h4><small class="umi-range">' + umDalAl(giorni[0].d, giorni[giorni.length - 1].d) + '</small>'
    +   grafico + '<div class="umi-boxes">' + boxes + '</div></div>'
    + '<div class="umi-card umi-centro"><h4>Le tue risposte più frequenti</h4>'
    +   (top.length ? '<div class="umi-top">' + top.map(function(m){ const o = umMotivoInfo(m); return '<div><span>' + o.ico + '</span><b>' + esc(o.t) + '</b><i>' + conta[m] + (conta[m] === 1 ? ' volta' : ' volte') + '</i></div>'; }).join('') + '</div>'
          : '<p class="umi-p">Qui compaiono le risposte che scegli più spesso quando il Genio ti chiede cosa ha contato di più nella tua giornata.</p>')
    + '</div>'
    + '<div class="umi-priv">🛡️ Questa pagina è visibile solo a te.</div>';
  /* le colonne si riempiono dal basso */
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ host.querySelectorAll('.umi-fill').forEach(function(f){ f.style.height = f.getAttribute('data-h') + '%'; }); }); });
}
/* il pannello nel Report, sopra al controllo dell'umore */
function umInfoPannelloHtml(){
  return '<button type="button" class="umi-porta" onclick="umInfoApri()"><span>🌤️</span><div><b>Informazioni sull’umore</b><small>Come è cambiato il tuo umore negli ultimi 7 e 30 giorni</small></div><i>' + UM_ICO_AVANTI + '</i></button>';
}
/* LA SCORCIATOIA DI DREAM (0.9.219, Andrea): apre SEMPRE le faccine. Se oggi hai già votato,
   la faccina salvata è già selezionata e «Salva» la sostituisce; finché non premi «Salva» il
   voto di prima resta quello. Prima, dopo il voto, la scorciatoia portava alle informazioni,
   e cambiare l'umore della giornata dalla scorciatoia era impossibile. Le informazioni
   restano a un tocco, dal link sotto «Salva». */
function umScorciatoia(){ umApri(umGiorno(0), { soloVoto: true }); }

/* ---------------------------------------------------------------------------------------
   IL CONTROLLO QUOTIDIANO CON IL GENIO (0.9.217, prima era la chat con l'Io futuro)

   PERCHE' IL GENIO E NON L'IO FUTURO. Parlare con il proprio io futuro deve restare una cosa
   rara e preziosa (la chiamata, i messaggi dopo un passo vero). Un controllo che arriva tutti
   i giorni lo consumerebbe. Qui parla il Genio, come su Meditopia: una conversazione corta che
   FINISCE.

   COME VA, per tutti:
     1. il saluto del Genio, secondo il voto appena salvato;
     2. UNA domanda della banca UM_DOMANDE, a rotazione (mai la stessa due giorni di fila), con
        le risposte da toccare; solo dove la domanda lo prevede c'e' «Lo scrivo io»;
     3. la reazione del Genio alla risposta;
     4. venerdi', sabato e domenica, una volta a settimana: la SECONDA domanda, quella sul carico
        di lavoro della settimana (mai a inizio settimana: a lunedi' la settimana non c'e' ancora);
     5. la chiusura e il pulsante grande «Guarda come cambia il tuo umore», che apre i grafici.
   Al massimo due domande, poi la conversazione e' chiusa: niente casella libera infinita.

   PREMIUM (agente acceso): le reazioni le scrive l'agente vero, nella stessa conversazione a
   parte di prima (prefisso [umore], storico separato sul server). Le istruzioni viaggiano dentro
   al messaggio: parla il Genio, una o due frasi, al massimo due domande in tutto. Se nel giorno
   senza la domanda sul lavoro l'agente fa UNA domanda di approfondimento, si risponde in breve
   (o si salta) e la conversazione si chiude. Se l'agente non risponde entro un minuto, la
   reazione scritta qui prende il suo posto: la conversazione non resta mai appesa.

   Dove finiscono le risposte: fl_umore[giorno].risposte = [{ q, i, t }] (q = id della domanda,
   i = indice della risposta, -1 per il testo libero, t = testo libero). Per compatibilita'
   restano anche fl_umore[giorno].motivi (per «Più selezionato») e .carico.
   --------------------------------------------------------------------------------------- */
const UMC_KEY = 'fl_umore_chat';
const UMC_ROT_KEY = 'fl_umore_domande';      // { p: posto nella rotazione, g: giorno, q: domanda }
const UMC_CARICO_KEY = 'fl_umore_carico_sett'; // il lunedi' della settimana in cui e' stata fatta
const UMC = { day: '', poll: 0, visti: 0, altri: false };
const UMC_ATTESA_MAX = 60000;

/* LA BANCA DELLE DOMANDE. Ogni risposta ha:
     t  = il testo del pulsante;
     r  = la reazione del Genio (deve reggere con qualsiasi voto: niente «che bello» a chi ha
          dato 1, niente prediche a chi ha dato 5);
     d  = la frase del diario, in prima persona e senza genere («mi sentivo», non «mi sono
          sentito»: il genere di chi scrive l'app non lo sa).
   Le tre domande sui motivi (meglio / pesato / deciso) dipendono dal voto e riempiono anche
   «Più selezionato» nella pagina delle informazioni. */
const UM_DOMANDE = {
  meglio: { q: 'Cosa ti ha fatto stare meglio oggi?', motivi: true, libero: 'Scrivi in breve cosa ti ha fatto stare meglio oggi', opz: [
    { ico: '✨', t: 'Il lavoro o la giornata sono andati bene', r: 'Quando il lavoro gira, tutta la giornata va meglio. Ricordati com’è andata oggi, nei giorni in cui il lavoro fa fatica.', d: 'Mi ha fatto stare meglio il lavoro, che oggi è andato bene.' },
    { ico: '🏃', t: 'Ho fatto attività fisica', r: 'Muovere il corpo aiuta anche la testa. L’attività fisica di oggi è stata una bella scelta.', d: 'Mi ha fatto stare meglio l’attività fisica.' },
    { ico: '👥', t: 'Ho passato del tempo con chi amo', r: 'Il tempo passato con le persone che ami ricarica più di qualsiasi pausa. Sono contento che oggi ci sia stato.', d: 'Mi ha fatto stare meglio il tempo passato con chi amo.' },
    { ico: '🧘', t: 'Ho trovato del tempo per me', r: 'Il tempo per te ti aiuta a reggere tutto il resto. Domani tieni da parte di nuovo un po’ di tempo per te.', d: 'Mi ha fatto stare meglio il tempo che ho trovato per me.' },
    { ico: '🎨', t: 'Ho dedicato tempo a un hobby', r: 'Le cose che fai solo perché ti piacciono sono quelle che ricaricano di più. Tieni vivo il tuo hobby.', d: 'Mi ha fatto stare meglio il tempo dedicato a un hobby.' },
    { ico: '🛌', t: 'Ho riposato o dormito bene', r: 'Una notte buona cambia tutta la giornata. Stasera prova ad andare a letto alla stessa ora di ieri.', d: 'Mi ha fatto stare meglio aver riposato e dormito bene.' },
    { ico: '🎯', t: 'Ho fatto un passo verso il mio sogno', r: 'Un passo vero verso il tuo sogno fa stare bene come poche cose. Domani fai un altro passo, anche piccolo.', d: 'Mi ha fatto stare meglio un passo fatto verso il mio sogno.' },
    { ico: '➖', t: 'Nulla in particolare', r: 'Ci sono giornate che vanno bene senza un motivo preciso. Va benissimo anche così.', d: 'Non c’è stato un motivo preciso: la giornata è andata bene così.' }
  ]},
  pesato: { q: 'Cosa ti ha pesato di più oggi?', motivi: true, libero: 'Scrivi in breve cosa ti ha pesato oggi', opz: [
    { ico: '💼', t: 'Il lavoro o lo studio', r: 'Il lavoro pesa di più quando non se ne vede la fine. Domani scegli una sola cosa da chiudere per prima.', d: 'Oggi mi ha pesato soprattutto il lavoro, o lo studio.' },
    { ico: '📱', t: 'Il telefono mi ha rubato tempo', r: 'Il telefono tira forte, lo so bene. Domani mattina accendi il blocco delle app appena ti svegli.', d: 'Oggi mi ha pesato il tempo che il telefono mi ha rubato.' },
    { ico: '😴', t: 'Ho dormito poco', r: 'Con poco sonno tutto sembra più pesante. Stasera prova ad andare a letto mezz’ora prima.', d: 'Oggi mi ha pesato aver dormito poco.' },
    { ico: '🗯️', t: 'Una discussione con qualcuno', r: 'Una discussione resta addosso per ore. Lascia passare la notte: domani la discussione ti sembrerà più piccola.', d: 'Oggi mi ha pesato una discussione con qualcuno.' },
    { ico: '⏳', t: 'Mi sento indietro sul mio sogno', r: 'Sentirsi indietro fa male, e succede solo a chi tiene davvero al proprio sogno. Domani basta un passo piccolo per ripartire.', d: 'Oggi mi ha pesato sentirmi indietro sul mio sogno.' },
    { ico: '🤒', t: 'Stanchezza o salute', r: 'Quando il corpo chiede una pausa, la cosa giusta è dargliela. Stasera riposa senza sensi di colpa.', d: 'Oggi mi hanno pesato la stanchezza e la salute.' },
    { ico: '➖', t: 'Nulla in particolare', r: 'A volte una giornata va storta senza un perché. Domani si riparte da capo.', d: 'Non c’è stato un motivo preciso: la giornata è andata storta e basta.' }
  ]},
  deciso: { q: 'Cosa ha contato di più nella tua giornata di oggi?', motivi: true, libero: 'Scrivi cosa ha contato di più oggi', opz: [
    { ico: '💼', t: 'Il lavoro o lo studio', r: 'Quando il lavoro occupa tutto, si porta via anche l’umore. Stasera stacca dal lavoro, anche solo per un’ora.', d: 'A decidere la mia giornata è stato il lavoro, o lo studio.' },
    { ico: '😴', t: 'Il sonno', r: 'Il sonno decide più cose di quanto pensiamo. Stasera dai al sonno un po’ di spazio in più.', d: 'A decidere la mia giornata è stato il sonno.' },
    { ico: '👥', t: 'Le persone intorno a me', r: 'Le persone intorno cambiano l’aria di una giornata. Tieni vicine le persone che ti fanno bene.', d: 'A decidere la mia giornata sono state le persone intorno a me.' },
    { ico: '📱', t: 'Il telefono', r: 'Se il telefono decide la giornata, il telefono la decide al posto tuo. Domani mattina accendi il blocco delle app appena ti svegli.', d: 'A decidere la mia giornata è stato il telefono.' },
    { ico: '🧘', t: 'Il tempo per me', r: 'Il tempo per te ti aiuta a reggere tutto il resto. Domani tieni da parte almeno quindici minuti solo per te.', d: 'A decidere la mia giornata è stato il tempo che ho avuto per me.' },
    { ico: '🎯', t: 'Il mio sogno', r: 'Bello che oggi al centro ci sia stato il tuo sogno. Domani tieni il tuo sogno al primo posto.', d: 'A decidere la mia giornata è stato il mio sogno.' },
    { ico: '➖', t: 'Nulla in particolare', r: 'Anche le giornate tranquille contano. Domani può essere la giornata giusta per un passo in più.', d: 'Non c’è stato niente in particolare a decidere la mia giornata.' }
  ]},
  piacere: { q: 'Nell’ultima settimana, quante volte ti è capitato di provare un piacere sincero nel fare qualcosa?', opz: [
    { t: 'Quasi ogni giorno', r: 'Se il piacere arriva quasi ogni giorno, stai facendo cose che ti piacciono davvero. Tienilo a mente anche nelle giornate storte.', d: 'Nell’ultima settimana ho provato un piacere sincero quasi ogni giorno.' },
    { t: 'Qualche volta', r: 'Qualche volta è già un buon punto di partenza. Prova a ricordare cosa stavi facendo in quei momenti: da quelle cose si riparte.', d: 'Nell’ultima settimana ho provato un piacere sincero qualche volta.' },
    { t: 'Raramente', r: 'Nelle settimane piene il piacere è la prima cosa che sparisce. Domani ritagliati mezz’ora per una cosa che ti piace, solo per te.', d: 'Nell’ultima settimana ho provato un piacere sincero di rado.' },
    { t: 'Mai', r: 'Grazie per avermelo detto con sincerità. Domani scegli una cosa piccola che ti faceva stare bene e falla, anche solo per dieci minuti.', d: 'Nell’ultima settimana non ho mai provato un piacere sincero.' }
  ]},
  sonno: { q: 'Come hai dormito stanotte?', opz: [
    { t: 'Benissimo', r: 'Una notte così è metà della giornata già fatta. Stasera prova a rifare le stesse cose di ieri sera.', d: 'Stanotte ho dormito benissimo.' },
    { t: 'Abbastanza bene', r: 'Dormire abbastanza bene è una buona base. Se stasera vai a letto alla stessa ora, domani ti svegli con la stessa energia.', d: 'Stanotte ho dormito abbastanza bene.' },
    { t: 'Poco', r: 'Con poco sonno tutto pesa di più. Stasera prova ad andare a letto mezz’ora prima.', d: 'Stanotte ho dormito poco.' },
    { t: 'Male', r: 'Una notte storta si sente per tutto il giorno. Stasera lascia il telefono lontano dal letto: aiuta più di quanto sembri.', d: 'Stanotte ho dormito male.' }
  ]},
  energia: { q: 'Quanta energia hai avuto oggi?', opz: [
    { t: 'Tantissima', r: 'Oggi avevi il pieno di energia. Ricordati cosa hai fatto ieri sera e stamattina: sono cose da rifare.', d: 'Oggi avevo tantissima energia.' },
    { t: 'Abbastanza', r: 'Oggi avevi abbastanza energia per fare le cose che contano. Domani usa l’energia della mattina per la cosa più importante.', d: 'Oggi avevo abbastanza energia.' },
    { t: 'Poca', r: 'Con poca energia conta scegliere bene: una cosa sola, quella giusta, e il resto può aspettare.', d: 'Oggi avevo poca energia.' },
    { t: 'Ero a terra', r: 'Quando l’energia è a zero, la cosa più utile è recuperare. Stasera riposa senza sensi di colpa.', d: 'Oggi ero a terra, senza energia.' }
  ]},
  persone: { q: 'Oggi hai passato del tempo con qualcuno a cui tieni?', opz: [
    { t: 'Sì, ed è stato bello', r: 'Le ore con le persone a cui tieni sono quelle che si ricordano. Bello che oggi ci siano state.', d: 'Oggi ho passato del tempo con qualcuno a cui tengo, ed è stato bello.' },
    { t: 'Sì, ma poco', r: 'Anche poco tempo con chi ti vuole bene conta. Domani scrivi un messaggio a una di quelle persone.', d: 'Oggi ho passato un po’ di tempo con qualcuno a cui tengo, ma poco.' },
    { t: 'No, oggi no', r: 'Ci sono giornate che si passano per conto proprio, e va bene. Se ti manca qualcuno, domani scrivigli due righe.', d: 'Oggi non ho visto nessuna delle persone a cui tengo.' },
    { t: 'Ne avrei avuto bisogno', r: 'Grazie per avermelo detto. Scrivi adesso a una persona a cui tieni: anche un messaggio corto avvicina.', d: 'Oggi avrei avuto bisogno di stare con qualcuno a cui tengo.' }
  ]},
  concentrazione: { q: 'Oggi quanto ti è stato facile concentrarti?', opz: [
    { t: 'Facilissimo', r: 'Oggi la concentrazione c’era tutta. Ricordati com’era il tuo spazio di lavoro oggi: vale la pena preparare il tuo spazio di lavoro così anche domani.', d: 'Oggi concentrarmi è stato facilissimo.' },
    { t: 'Abbastanza facile', r: 'Oggi la concentrazione è stata buona. Domani proteggi la prima ora della giornata: la prima ora è quella in cui la concentrazione rende di più.', d: 'Oggi concentrarmi è stato abbastanza facile.' },
    { t: 'Difficile', r: 'Ci sono giornate in cui la testa scappa. Domani prova con una sessione corta di Full Focus, venticinque minuti e basta.', d: 'Oggi concentrarmi è stato difficile.' },
    { t: 'Impossibile', r: 'Ci sono giornate così. Domani parti da una cosa piccola e chiudila: il resto viene dopo.', d: 'Oggi concentrarmi è stato impossibile.' }
  ]},
  telefono: { q: 'Oggi il telefono ti ha tolto tempo che volevi usare per altro?', opz: [
    { t: 'No, per niente', r: 'Il tempo che oggi non hai dato al telefono l’hai dato a te. Per il telefono, oggi è stata un’ottima giornata.', d: 'Oggi il telefono non mi ha tolto tempo.' },
    { t: 'Un po’', r: 'Un po’ di tempo al telefono lo perdiamo tutti. Domani accendi il blocco delle app nelle ore in cui ti serve concentrazione.', d: 'Oggi il telefono mi ha tolto un po’ di tempo.' },
    { t: 'Parecchio', r: 'Il telefono tira forte, lo so bene. Domani mattina accendi il blocco delle app appena ti svegli.', d: 'Oggi il telefono mi ha tolto parecchio tempo.' },
    { t: 'Tantissimo', r: 'Grazie per la sincerità: accorgersi del tempo perso è il primo passo. Domani accendi la Modalità severa nelle ore che contano.', d: 'Oggi il telefono mi ha tolto tantissimo tempo.' }
  ]},
  tempo_me: { q: 'Oggi hai trovato del tempo solo per te?', opz: [
    { t: 'Sì, abbastanza', r: 'Il tempo per te ti aiuta a reggere tutto il resto. Fai bene a difendere il tempo per te.', d: 'Oggi ho trovato del tempo solo per me.' },
    { t: 'Un po’', r: 'Un po’ di tempo per te è meglio di niente. Domani metti il tempo per te in agenda, come un impegno vero.', d: 'Oggi ho trovato un po’ di tempo per me.' },
    { t: 'No, per niente', r: 'Le giornate senza un momento tuo pesano di più. Domani scegli anche solo quindici minuti per te e difendili.', d: 'Oggi non ho avuto tempo per me.' }
  ]},
  sogno: { q: 'Oggi hai fatto qualcosa per il tuo sogno?', opz: [
    { t: 'Sì, un passo vero', r: 'Un passo vero verso il tuo sogno è quello che conta. Domani basta un altro passo.', d: 'Oggi ho fatto un passo vero verso il mio sogno.' },
    { t: 'Una cosa piccola', r: 'Le cose piccole fatte ogni giorno portano lontano. Anche la cosa piccola di oggi conta.', d: 'Oggi ho fatto una cosa piccola per il mio sogno.' },
    { t: 'Oggi no', r: 'Un giorno senza passi non cambia la strada verso il tuo sogno. Domani scegli una cosa piccola e falla per prima.', d: 'Oggi non ho fatto niente per il mio sogno.' }
  ]},
  corpo: { q: 'Oggi hai fatto un po’ di movimento?', opz: [
    { t: 'Sì, ho fatto sport', r: 'Lo sport aiuta anche la testa, non solo il corpo. Lo sport di oggi è stato una bella scelta.', d: 'Oggi ho fatto sport.' },
    { t: 'Ho camminato un po’', r: 'Anche una camminata conta. Domani prova ad allungare la camminata di dieci minuti.', d: 'Oggi ho camminato un po’.' },
    { t: 'Quasi niente', r: 'Nelle giornate piene il movimento è la prima cosa che salta. Domani bastano dieci minuti a piedi, magari senza telefono.', d: 'Oggi ho fatto pochissimo movimento.' }
  ]},
  stress: { q: 'Quanta pressione hai sentito oggi?', opz: [
    { t: 'Nessuna', r: 'Una giornata senza pressione ogni tanto ci vuole. Goditi la serata.', d: 'Oggi non ho sentito nessuna pressione.' },
    { t: 'Un po’', r: 'Un po’ di pressione tiene svegli. L’importante è che domani la pressione non cresca.', d: 'Oggi ho sentito un po’ di pressione.' },
    { t: 'Tanta', r: 'Quando la pressione è tanta, aiuta scrivere le tre cose che contano davvero e lasciare andare il resto.', d: 'Oggi ho sentito tanta pressione.' },
    { t: 'Troppa', r: 'Troppa pressione stanca anche le persone più forti. Stasera stacca: domani guarderai le cose con la testa più fresca.', d: 'Oggi ho sentito troppa pressione.' }
  ]},
  ricordo: { q: 'C’è una cosa di oggi che vuoi ricordare?', libero: 'Scrivi la cosa di oggi che vuoi ricordare', liberoT: 'Sì, te la scrivo',
    liberoR: 'Grazie. Ho scritto questo ricordo nel tuo diario di oggi: fra un mese rileggere questo ricordo ti farà bene.', liberoD: 'Oggi è successa una cosa che voglio ricordare.', opz: [
    { t: 'Più di una', r: 'Una giornata con più cose da ricordare vale doppio. Stasera, prima di dormire, ripensa un attimo a quelle cose.', d: 'Oggi sono successe più cose che voglio ricordare.' },
    { t: 'Niente di speciale', r: 'Anche le giornate normali servono: sono le giornate che reggono tutte le altre.', d: 'Oggi non è successo niente di speciale da ricordare.' }
  ]},
  risate: { q: 'Oggi hai riso di gusto almeno una volta?', opz: [
    { t: 'Sì, più volte', r: 'Ridere scarica la tensione meglio di tante pause. Per le risate, oggi è stata una buona giornata.', d: 'Oggi ho riso di gusto più volte.' },
    { t: 'Una volta', r: 'Una risata vera vale tanto. Tieniti vicino chi oggi ti ha fatto ridere.', d: 'Oggi ho riso di gusto una volta.' },
    { t: 'Oggi no', r: 'Nelle giornate pesanti si ride poco. Domani cerca una cosa che ti fa ridere, anche un video di due minuti.', d: 'Oggi non ho riso.' }
  ]},
  calma: { q: 'Oggi hai avuto un momento di calma, senza pensare a niente?', opz: [
    { t: 'Sì', r: 'I momenti di calma ricaricano la testa più di quanto sembri. Bello che oggi ci sia stato.', d: 'Oggi ho avuto un momento di calma.' },
    { t: 'Solo un attimo', r: 'Anche un attimo di calma serve. Domani prova con tre minuti di respiro lento.', d: 'Oggi ho avuto solo un attimo di calma.' },
    { t: 'No, mai', r: 'Una giornata senza pause stanca il doppio. Stasera prenditi cinque minuti senza telefono, solo per respirare.', d: 'Oggi non ho avuto nessun momento di calma.' }
  ]},
  domani: { q: 'Come ti senti all’idea della giornata di domani?', opz: [
    { t: 'Con entusiasmo', r: 'L’entusiasmo è la benzina migliore. Stasera scegli la prima cosa da fare domattina, così parti subito.', d: 'Penso alla giornata di domani con entusiasmo.' },
    { t: 'Con calma', r: 'La calma è un ottimo punto di partenza. Domani fai una cosa alla volta.', d: 'Penso alla giornata di domani con calma.' },
    { t: 'Con un po’ di ansia', r: 'Un po’ d’ansia prima di una giornata piena è normale. Scrivi adesso la prima cosa da fare domani: aiuta a dormire meglio.', d: 'Penso alla giornata di domani con un po’ di ansia.' },
    { t: 'Con tanta ansia', r: 'Grazie per avermelo detto. Scrivi adesso tutto quello che ti preoccupa: messe su carta, le preoccupazioni pesano meno.', d: 'Penso alla giornata di domani con tanta ansia.' }
  ]},
  soddisfazione: { q: 'Oggi hai fatto qualcosa che ti ha dato soddisfazione?', opz: [
    { t: 'Sì, più di una cosa', r: 'Oggi hai lavorato bene. Ricordatelo nei giorni in cui ti sembra di non fare niente.', d: 'Oggi ho fatto più di una cosa che mi ha dato soddisfazione.' },
    { t: 'Sì, una', r: 'Una cosa fatta bene basta. Da cose così si costruisce tutto il resto.', d: 'Oggi ho fatto una cosa che mi ha dato soddisfazione.' },
    { t: 'Non ancora', r: 'Domani scegli una cosa piccola da finire. Chiudere una cosa dà più soddisfazione di quanto sembri.', d: 'Oggi non ho fatto niente che mi abbia dato soddisfazione.' }
  ]},
  mangiare: { q: 'Oggi hai mangiato con calma, almeno una volta?', opz: [
    { t: 'Sì', r: 'Fermarsi a mangiare con calma è già una pausa. Fai bene.', d: 'Oggi ho mangiato con calma.' },
    { t: 'Di corsa', r: 'Nelle giornate piene si mangia di corsa. Domani prova a fare almeno un pasto senza schermo davanti.', d: 'Oggi ho mangiato di corsa.' },
    { t: 'Ho saltato i pasti', r: 'Saltare i pasti toglie energia senza che te ne accorga. Domani tieni qualcosa da mangiare a portata di mano.', d: 'Oggi ho saltato i pasti.' }
  ]},
  gentilezza: { q: 'Oggi qualcuno è stato gentile con te, o tu con qualcuno?', opz: [
    { t: 'Qualcuno con me', r: 'Le gentilezze piccole cambiano una giornata intera. Bello che oggi ne sia arrivata una.', d: 'Oggi qualcuno è stato gentile con me.' },
    { t: 'Io con qualcuno', r: 'Hai fatto un bel gesto. Spesso una gentilezza fa bene più a chi la fa che a chi la riceve.', d: 'Oggi ho fatto una gentilezza a qualcuno.' },
    { t: 'Tutte e due', r: 'Una giornata con gentilezze date e ricevute è una giornata piena di cose buone.', d: 'Oggi ho ricevuto e fatto una gentilezza.' },
    { t: 'Oggi no', r: 'Succede a tutti. Domani prova a fare una piccola gentilezza a qualcuno: spesso la gentilezza torna indietro.', d: 'Oggi non c’è stata nessuna gentilezza, né data né ricevuta.' }
  ]},
  /* la seconda domanda, solo venerdì, sabato e domenica, una volta a settimana */
  carico: { q: 'Nell’ultima settimana, quante volte hai avuto la sensazione che il tuo carico di lavoro fosse troppo pesante da gestire?', opz: [
    { t: 'Mai', r: 'Una settimana in equilibrio è una base solida per la prossima. Tieni lo stesso ritmo.', d: 'Questa settimana il lavoro non è mai stato troppo da gestire.' },
    { t: 'Quasi mai', r: 'Questa settimana il lavoro è stato quasi sempre sotto controllo. Lascia un po’ di spazio libero anche nella prossima settimana.', d: 'Questa settimana il lavoro è stato quasi sempre gestibile.' },
    { t: 'A volte', r: 'In certe settimane il lavoro si accumula. Lunedì metti le cose più pesanti all’inizio della giornata.', d: 'Questa settimana il lavoro è stato tanto, ma l’ho retto.' },
    { t: 'Spesso', r: 'Una settimana così stanca chiunque. Prima di lunedì stacca davvero, e lunedì scegli le tre cose che contano.', d: 'Questa settimana il lavoro è stato spesso troppo da gestire.' },
    { t: 'Molto spesso', r: 'Grazie per avermelo detto. Con un carico così, lunedì la prima cosa da fare è togliere qualcosa dalla lista, prima di aggiungere altro.', d: 'Questa settimana il lavoro è stato quasi sempre troppo da gestire.' }
  ]}
};
/* La rotazione: «motivi» (meglio / pesato / deciso, secondo il voto) torna ogni 5 giorni, mai
   due giorni di fila; le altre domande una volta per giro. 22 giorni, poi si ricomincia. */
const UM_ROTAZIONE = ['motivi', 'sonno', 'piacere', 'energia', 'persone', 'motivi', 'concentrazione', 'tempo_me', 'sogno', 'corpo',
  'motivi', 'stress', 'ricordo', 'telefono', 'risate', 'motivi', 'calma', 'domani', 'soddisfazione', 'mangiare', 'motivi', 'gentilezza'];
const UM_CARICO = UM_DOMANDE.carico.opz.map(function(o){ return o.t; });

/* le liste di prima, ricavate dalla banca: servono alle icone di «Più selezionato» */
function umMotiviLista(id){ return UM_DOMANDE[id].opz.map(function(o){ return [o.ico, o.t]; }); }
const UM_MOTIVI_SU = umMotiviLista('meglio'), UM_MOTIVI_GIU = umMotiviLista('pesato'), UM_MOTIVI_MEZZO = umMotiviLista('deciso');
function umMotiviId(v){ return v >= 4 ? 'meglio' : (v <= 2 ? 'pesato' : 'deciso'); }
function umMotivi(v){ return umMotiviLista(umMotiviId(v)); }
function umMotivoInfo(t){
  const tutti = UM_MOTIVI_SU.concat(UM_MOTIVI_GIU, UM_MOTIVI_MEZZO);
  const o = tutti.filter(function(x){ return x[1] === t; })[0];
  return o ? { ico: o[0], t: o[1] } : { ico: '💬', t: t };
}

/** La domanda di oggi: una volta scelta resta quella per tutto il giorno. */
function umDomandaDelGiorno(day, v){
  let s = null; try{ s = JSON.parse(localStorage.getItem(UMC_ROT_KEY) || 'null'); }catch(_){ }
  s = s || { p: -1, g: '', q: '' };
  let slot;
  if (s.g === day && s.q) slot = s.q;
  else {
    let p = s.p, giri = 0;
    do { p = (p + 1) % UM_ROTAZIONE.length; giri++; } while (UM_ROTAZIONE[p] === s.q && giri < UM_ROTAZIONE.length);
    slot = UM_ROTAZIONE[p];
    try{ localStorage.setItem(UMC_ROT_KEY, JSON.stringify({ p: p, g: day, q: slot })); }catch(_){ }
  }
  return slot === 'motivi' ? umMotiviId(v) : slot;
}
/** Il lunedì della settimana di quel giorno, come chiave. */
function umLunedi(d){ const x = new Date(d || Date.now()); x.setHours(12, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return umGiornoDi(x.getTime()); }
/** La domanda sul carico di lavoro: solo venerdì, sabato o domenica, e una volta a settimana. */
function umCaricoDovuto(day){
  const d = day ? new Date(day + 'T12:00:00') : new Date();
  const dow = d.getDay();
  if (!(dow === 5 || dow === 6 || dow === 0)) return false;
  try{ return localStorage.getItem(UMC_CARICO_KEY) !== umLunedi(d.getTime()); }catch(_){ return true; }
}

/** Chi ha le reazioni scritte dall'agente: Premium con l'agente acceso. */
function umChatPuo(){
  try{ if (typeof agPuo === 'function' && !agPuo()) return false; }catch(_){ return false; }
  try{ if (typeof agAbilitatoOra === 'function' && agAbilitatoOra()) return true; }catch(_){ }
  try{ return typeof adsUserIsPremium === 'function' && adsUserIsPremium(); }catch(_){ return false; }
}
function umcAgente(){ return typeof agAbilitatoOra === 'function' && agAbilitatoOra() && typeof agApi === 'function'; }
function umcStato(){ let s = null; try{ s = JSON.parse(localStorage.getItem(UMC_KEY) || 'null'); }catch(_){ } s = s || {}; s.giorni = s.giorni || {}; return s; }
function umcSalva(s){ try{ const k = Object.keys(s.giorni).sort(); while (k.length > 30) delete s.giorni[k.shift()]; localStorage.setItem(UMC_KEY, JSON.stringify(s)); }catch(_){ } }
function umcGiorno(s, day){ if (!s.giorni[day]) s.giorni[day] = { msgs: [], passo: '', voto: 0 }; return s.giorni[day]; }
function umcNome(){ try{ return (typeof gnNome === 'function') ? gnNome() : ''; }catch(_){ return ''; } }
function umcSaluto(v){
  const n = umcNome(), c = n ? ', ' + n : '';
  if (v >= 5) return 'Ciao' + c + '! Che bella giornata hai avuto oggi.';
  if (v === 4) return 'Ciao' + c + '! Mi fa piacere che oggi sia andata bene.';
  if (v === 3) return 'Ciao' + c + '. Una giornata così così capita a tutti, e conta lo stesso.';
  if (v === 2) return 'Ciao' + c + '. Mi dispiace che oggi la giornata sia andata storta.';
  return 'Ciao' + c + '. Mi dispiace, oggi è stata una giornata davvero dura.';
}
function umcChiusura(v){
  const n = umcNome(), c = n ? ', ' + n : '';
  if (v <= 2) return 'Grazie' + c + '. Ho segnato tutto. Stasera trattati bene: ci sentiamo domani.';
  return 'Grazie' + c + '. Ho segnato tutto: nella pagina del tuo umore vedi come sta andando la settimana.';
}
function umcGrazieLibero(v){
  if (v <= 2) return 'Grazie per avermelo scritto. Mettere in parole quello che pesa aiuta già a lasciarlo andare un po’.';
  if (v >= 4) return 'Grazie per avermelo scritto. Quello che hai scritto lo ritrovi nel tuo diario di oggi.';
  return 'Grazie per avermelo scritto. Ho messo quello che hai scritto nel tuo diario di oggi.';
}
function umcTestoDomanda(q){ return (UM_DOMANDE[q] || {}).q || ''; }
/** La risposta di un giorno, in parole: il pulsante toccato o il testo scritto. */
function umcRispostaTesto(r){
  if (!r) return '';
  if (r.i < 0) return String(r.t || '');
  const o = ((UM_DOMANDE[r.q] || {}).opz || [])[r.i];
  return o ? o.t : '';
}

registerScreen('s-umore-chat',
  '<div class="topbar umc-top"><button class="iconbtn" onclick="umChatChiudi()" aria-label="Indietro">' + UM_ICO_INDIETRO + '</button><b class="umc-titolo">Controllo quotidiano dell’umore</b></div>'
  + '<div class="umc-voti" id="umcVoti"></div><div class="umc-lista" id="umcLista"></div>'
  + '<div class="umc-input" hidden><textarea id="umcTesto" rows="1" maxlength="300" placeholder="Scrivi in breve" onkeydown="if(event.key===\'Enter\'&&!event.shiftKey){event.preventDefault();umChatScrivi();}"></textarea><button type="button" onclick="umChatScrivi()" aria-label="Invia">' + UM_ICO_INVIA + '</button></div>',
  { back: function(){ umChatFerma(); return 's-home'; } });

/** Dopo «Salva»: la conversazione del giorno. Se è già finita, si rivede com'è. */
function umChatApri(day){
  day = day || umGiorno(0);
  const v = (umLeggi(day) || {}).sodd || 0; if (!v) return;
  const s = umcStato(), g = umcGiorno(s, day);
  const risposte = (umLeggi(day) || {}).risposte || [];
  if (!g.voto || !g.q1 || (g.voto !== v && !risposte.length && g.passo !== 'fine')){
    /* conversazione nuova (o voto cambiato prima di aver risposto a niente): si riparte */
    g.msgs = []; g.voto = v; g.risp = {}; g.scrivi = false; g.srv = 0; g.attesa = null;
    g.q1 = umDomandaDelGiorno(day, v);
    g.q2 = umCaricoDovuto(day) ? 'carico' : '';
    g.msgs.push({ dir: 'lui', testo: umcSaluto(v), at: Date.now() });
    g.msgs.push({ dir: 'lui', testo: umcTestoDomanda(g.q1), at: Date.now(), opz: g.q1 });
    g.passo = 'q1';
    UMC.visti = 0;
  } else if (g.voto !== v){
    /* voto cambiato (dalla scorciatoia di Dream o dal Report) a conversazione avviata: si
       segna, senza nuove domande; si animano solo le due battute nuove */
    g.voto = v;
    UMC.visti = g.msgs.length;
    g.msgs.push({ dir: 'io', testo: UM_EMOJI[v - 1] + ' ' + UM_VOCI[v - 1], at: Date.now() });
    g.msgs.push({ dir: 'lui', testo: 'Ho segnato il cambio: oggi la tua giornata è andata ' + UM_VOCI[v - 1].toLowerCase() + '.', at: Date.now() });
  } else {
    UMC.visti = g.msgs.length;
  }
  umcSalva(s);
  UMC.day = day; UMC.altri = false;
  goId('s-umore-chat');
  umChatPaint();
  /* chi aveva lasciato la conversazione sui tre puntini con una versione vecchia riparte subito */
  if (g.passo === 'attesa' && g.attesa){ const a0 = g.attesa, s0 = s || umcStato(); g.msgs.push({ dir: 'lui', testo: a0.fallback, at: Date.now() }); umcAvanti(s0, g, a0.tipo, false); }
  if (g.agente) umChatAttendi(day);
}
function umChatChiudi(){ umChatFerma(); goId('s-home'); }
function umChatFerma(){ if (UMC.poll){ clearTimeout(UMC.poll); UMC.poll = 0; } }
function umcAvatar(){ return '<div class="umc-av" aria-hidden="true"></div>'; }
function umChatPaint(){
  const s = umcStato(), g = umcGiorno(s, UMC.day);
  const v = g.voto || 0;
  const vb = document.getElementById('umcVoti');
  /* le faccine in alto dicono solo il voto salvato: per cambiarlo ci sono la scorciatoia di Dream e il Report */
  if (vb) vb.innerHTML = UM_EMOJI.map(function(e, i){ return '<span class="' + (v === i + 1 ? 'on' : '') + ' v' + (i + 1) + '" aria-label="' + UM_VOCI[i] + '">' + e + '</span>'; }).join('');
  const l = document.getElementById('umcLista'); if (!l) return;
  const av = umcAvatar();
  let html = '', ritardo = 0, ultimoLui = -1;
  const nuovo = function(i){ if (i < UMC.visti) return ''; const d = ritardo; ritardo += 120; return ' umc-nuovo" style="--d:' + d + 'ms'; };
  g.msgs.forEach(function(m, i){ if (m.dir === 'lui') ultimoLui = i; });
  g.msgs.forEach(function(m, i){
    if (m.dir === 'io'){ html += '<div class="umc-m io' + nuovo(i) + '"><div class="umc-b">' + esc(m.testo) + '</div></div>'; return; }
    const primo = i === 0 || g.msgs[i - 1].dir !== 'lui';
    html += '<div class="umc-m lui' + nuovo(i) + '">' + (primo ? av : '<div class="umc-av spazio"></div>') + '<div class="umc-b">' + esc(m.testo).replace(/\n/g, '<br>') + '</div></div>';
    const aperta = i === ultimoLui && ((m.opz && g.passo === (m.opz === g.q2 && g.q2 ? 'q2' : 'q1') && !(g.risp || {})[m.opz]) || (m.segue && g.passo === 'segue'));
    if (aperta){
      const d = ritardo; ritardo += 300;
      const st = ' style="--d:' + d + 'ms"';
      if (m.segue){
        html += '<div class="umc-opz umc-nuovo"' + st + '><button type="button" class="umc-salta" onclick="umChatSalta()">Preferisco non rispondere</button></div>';
      } else {
        const D = UM_DOMANDE[m.opz] || { opz: [] };
        /* le liste lunghe (i motivi) mostrano le prime quattro risposte, poi «Visualizza altro» */
        const corta = D.opz.length > 5 && !UMC.altri && !g.scrivi;
        const vis = corta ? D.opz.slice(0, 4) : D.opz;
        html += '<div class="umc-opz umc-nuovo"' + st + '>' + vis.map(function(o, j){ return '<button type="button" onclick="umChatScegli(\'' + m.opz + '\',' + j + ')">' + (o.ico ? '<span>' + o.ico + '</span>' : '') + esc(o.t) + '</button>'; }).join('')
          + (corta ? '<button type="button" class="umc-altro" onclick="umChatAltri()">Visualizza altro' + UM_ICO_GIU + '</button>'
            : (D.libero ? '<button type="button" class="umc-libero' + (g.scrivi ? ' on' : '') + '" onclick="umChatLibero()"><span>✍️</span>' + esc(D.liberoT || 'Lo scrivo io') + '</button>' : '')) + '</div>';
      }
    }
  });
  if (g.passo === 'attesa') html += '<div class="umc-m lui umc-nuovo" style="--d:' + ritardo + 'ms">' + av + '<div class="umc-b umc-pensa"><i></i><i></i><i></i></div></div>';
  if (g.passo === 'fine'){
    /* 0.9.287, Andrea: con un umore basso, ansia o tanta pressione il Genio propone un respiro adatto (e qui non e' una
       perdita di tempo: serve a calmarsi). Il respiro si apre anche durante la stagione di spinta (blocchi-sezioni.js). */
    const rc = umcRespiroConsigliato(g);
    if (rc) html += '<div class="umc-resp umc-nuovo" style="--d:' + ritardo + 'ms"><img src="img/genio/genio-pensa.png" alt=""><div><b>' + esc(rc.t) + '</b><small>' + esc(rc.s) + '</small><button type="button" class="umc-resp-b" onclick="umcRespiroApri(\'' + rc.k + '\',' + rc.sec + ')">' + esc(rc.b) + '</button></div></div>';
    html += '<div class="umc-fine umc-nuovo" style="--d:' + ritardo + 'ms"><button type="button" class="cta umc-info" onclick="umChatInfo()">Guarda come cambia il tuo umore</button></div>';
  }
  l.innerHTML = html;
  UMC.visti = g.msgs.length;
  const inp = document.querySelector('#s-umore-chat .umc-input');
  const scrive = (g.scrivi && (g.passo === 'q1' || g.passo === 'q2')) || g.passo === 'segue';
  if (inp){
    inp.hidden = !scrive;
    const t = document.getElementById('umcTesto');
    if (t && scrive){
      const D = UM_DOMANDE[g.passo === 'q2' ? g.q2 : g.q1] || {};
      t.placeholder = g.passo === 'segue' ? 'Rispondi in breve al Genio' : (D.libero || 'Scrivi in breve');
    }
  }
  /* si scorre in fondo, ma l'ultima battuta del Genio resta sempre visibile dall'inizio */
  const giu = function(){
    const ult = l.querySelectorAll('.umc-m.lui'); const u = ult[ult.length - 1];
    const fondo = l.scrollHeight - l.clientHeight;
    l.scrollTop = u ? Math.min(fondo, Math.max(0, u.offsetTop - l.offsetTop - 8)) : fondo;
  };
  setTimeout(giu, 30); setTimeout(giu, ritardo + 400);
}
/** Il respiro da proporre oggi: per l'umore basso, l'ansia o la pressione. null se oggi non serve. */
function umcAnsiaOggi(g){
  const r = (g && g.risp) || {};
  const t = function(q){ const x = r[q], D = UM_DOMANDE[q]; return x && D && x.i >= 0 && D.opz[x.i] ? D.opz[x.i].t : ''; };
  const scritto = Object.keys(r).some(function(q){ const x = r[q]; return x && x.i < 0 && /ansi|stress|agitat|panico|nervos|angosci/i.test(x.t || ''); });
  return scritto || /tanta ansia|un po’ di ansia/i.test(t('domani')) || /Tanta|Troppa/.test(t('stress')) || /No, mai/.test(t('calma'));
}
function umcRespiroConsigliato(g){
  const v = (g && g.voto) || 0;
  const ansia = umcAnsiaOggi(g);
  if (!ansia && !(v > 0 && v <= 2)) return null;
  if (typeof rsApri !== 'function') return null;
  if (ansia) return { k: 'sospiro', sec: 120, t: 'Prima di chiudere, due minuti di respiro', s: 'Il sospiro ciclico abbassa l’ansia in pochi respiri: due inspirazioni dal naso e una lunga espirazione.', b: 'Fai il sospiro ciclico, 2 minuti' };
  return { k: 'rilassamento', sec: 180, t: 'Una giornata pesante si chiude meglio così', s: 'Tre minuti di respiro lento: inspiri in quattro tempi, espiri in sei.', b: 'Respira con me, 3 minuti' };
}
function umcRespiroApri(k, sec){
  try{ flVibra(10); }catch(_){ }
  umChatFerma();
  try{ const d = new Date(); localStorage.setItem('fl_umore_ansia', d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')); }catch(_){ } rsApri({ tecnica: k, durata: sec, libera: k, da: 'umore' }); }
function umChatAltri(){ UMC.altri = true; UMC.visti = 1e9; try{ flVibra(8); }catch(_){ } umChatPaint(); }
function umChatInfo(){ try{ flVibra(12); }catch(_){ } umChatFerma(); if (typeof umInfoApri === 'function') umInfoApri(); }
/** «Lo scrivo io»: compare la casella, i pulsanti restano lì se uno cambia idea. */
function umChatLibero(){
  const s = umcStato(), g = umcGiorno(s, UMC.day);
  if (g.passo !== 'q1' && g.passo !== 'q2') return;
  g.scrivi = true; umcSalva(s); umChatPaint();
  try{ flVibra(8); }catch(_){ }
  const t = document.getElementById('umcTesto'); if (t) setTimeout(function(){ try{ t.focus(); }catch(_){ } }, 60);
}
function umChatScegli(q, j){
  const s = umcStato(), g = umcGiorno(s, UMC.day);
  const qq = g.passo === 'q1' ? g.q1 : (g.passo === 'q2' ? g.q2 : '');
  if (!qq || qq !== q) return;
  const o = (UM_DOMANDE[q] || { opz: [] }).opz[j]; if (!o) return;
  try{ flVibra(10); }catch(_){ }
  umcRisposta(s, g, q, { q: q, i: j, t: '' }, o.t);
}
function umChatScrivi(){
  const t = document.getElementById('umcTesto'); if (!t) return;
  const testo = String(t.value || '').trim().slice(0, 300); if (!testo) return;
  const s = umcStato(), g = umcGiorno(s, UMC.day);
  if (g.passo === 'segue'){
    t.value = '';
    g.msgs.push({ dir: 'io', testo: testo, at: Date.now() });
    g.risp = g.risp || {}; g.risp.segue = testo;
    const u = umLeggi(UMC.day) || {};
    umScrivi(UMC.day, { risposte: (u.risposte || []).concat([{ q: 'segue', i: -1, t: testo, d: g.segueQ || '' }]) });
    umcReagisci(s, g, 'segue', 'Grazie per avermelo detto. Nei prossimi giorni terrò conto di quello che mi hai scritto.');
    return;
  }
  if (!g.scrivi || (g.passo !== 'q1' && g.passo !== 'q2')) return;
  t.value = '';
  const q = g.passo === 'q1' ? g.q1 : g.q2;
  umcRisposta(s, g, q, { q: q, i: -1, t: testo }, testo);
}
/** Una risposta data: si salva (adesso, non prima), poi reagisce il Genio. */
function umcRisposta(s, g, q, r, testoBolla){
  g.msgs.push({ dir: 'io', testo: testoBolla, at: Date.now() });
  g.risp = g.risp || {}; g.risp[q] = r; g.scrivi = false;
  const D = UM_DOMANDE[q] || {};
  const u = umLeggi(UMC.day) || {};
  const patch = { risposte: (u.risposte || []).filter(function(x){ return x.q !== q; }).concat([r]) };
  if (D.motivi && r.i >= 0) patch.motivi = (u.motivi || []).concat([D.opz[r.i].t]).filter(function(x, i, a){ return a.indexOf(x) === i; });
  if (q === 'carico'){
    patch.carico = D.opz[r.i] ? D.opz[r.i].t : '';
    try{ localStorage.setItem(UMC_CARICO_KEY, umLunedi(new Date(UMC.day + 'T12:00:00').getTime())); }catch(_){ }
  }
  umScrivi(UMC.day, patch);
  const fallback = r.i >= 0 ? D.opz[r.i].r : (D.liberoR || umcGrazieLibero(g.voto));
  umcReagisci(s, g, q, fallback);
}
/* LA REAZIONE, SUBITO (0.9.319). Andrea: "ho risposto no, oggi no, e ci mette vent'anni a fare la domanda dopo". La causa: la
   conversazione si fermava sui tre puntini finche' l'agente non rispondeva dal server, e poteva durare fino a un minuto (UMC_ATTESA_MAX),
   anche quando la domanda dopo era gia' scritta qui. Adesso la frase e la domanda dopo sono immediate. L'agente lavora dietro: se
   ha qualcosa di suo da dire arriva dopo, come un messaggio in piu', e non ferma mai nessuno. */
function umcReagisci(s, g, tipo, fallback){
  const day = UMC.day;
  const conAgente = umcAgente();
  const testo = conAgente ? umcMessaggioAgente(g, tipo) : '';
  g.msgs.push({ dir: 'lui', testo: fallback, at: Date.now() });
  if (conAgente) g.agente = { tipo: tipo, at: Date.now() };
  umcAvanti(s, g, tipo, false);
  if (conAgente) umcMandaAgente(day, testo);
}
/** Dopo la reazione: la seconda domanda, o la domanda dell'agente, o la chiusura. */
function umcAvanti(s, g, tipo, domandaAgente){
  if (tipo === g.q1 && g.q2 && !(g.risp || {})[g.q2]){
    g.msgs.push({ dir: 'lui', testo: 'Un’ultima domanda, visto che la settimana sta finendo.', at: Date.now() });
    g.msgs.push({ dir: 'lui', testo: umcTestoDomanda(g.q2), at: Date.now(), opz: g.q2 });
    g.passo = 'q2';
  } else if (domandaAgente && tipo === g.q1 && !g.q2){
    const ult = g.msgs[g.msgs.length - 1]; if (ult) ult.segue = true;
    g.segueQ = ult ? ult.testo : '';
    g.passo = 'segue';
  } else {
    g.msgs.push({ dir: 'lui', testo: umcChiusura(g.voto), at: Date.now() });
    g.passo = 'fine';
  }
  g.attesa = null;
  umcSalva(s); umChatPaint();
}
function umChatSalta(){
  const s = umcStato(), g = umcGiorno(s, UMC.day);
  if (g.passo !== 'segue') return;
  try{ flVibra(8); }catch(_){ }
  g.msgs.push({ dir: 'lui', testo: umcChiusura(g.voto), at: Date.now() });
  g.passo = 'fine'; umcSalva(s); umChatPaint();
}
/* Il messaggio per l'agente: le istruzioni di questo controllo, poi i fatti di oggi. Il server
   aggiunge in coda le sue istruzioni generali dell'umore: queste dicono che valgono di più. */
function umcMessaggioAgente(g, tipo){
  const puoChiedere = tipo === g.q1 && !g.q2;
  const istr = 'ISTRUZIONI PER QUESTA RISPOSTA, valgono più di quelle generali: nel controllo quotidiano dell’umore oggi parla il GENIO di DreamMap, non il suo io futuro. '
    + 'Rispondi in italiano parlato, con 1 o 2 frasi brevi, soggetto e oggetto sempre espliciti, coerenti con il voto e con la risposta. Parole semplici che capirebbe anche una persona di novant’anni: niente gergo, sigle, abbreviazioni o parole inglesi. Niente trattini lunghi, niente frasi da poster, niente elenchi, niente voti scritti in numeri. Il tono è di chi aiuta, mai di chi sgrida o vuole capire cosa hai sbagliato. '
    + 'In tutto il controllo il Genio fa al massimo 2 domande, poi la conversazione si chiude. '
    + (puoChiedere ? 'Puoi fare UNA sola domanda breve di approfondimento alla fine, a cui si risponde in poche parole; se non serve, nessuna domanda.' : 'NON fare domande: con questa risposta la conversazione si chiude.');
  const righe = ['Voto di oggi: ' + UM_VOCI[g.voto - 1] + ' (' + g.voto + ' su 5).'];
  [g.q1, g.q2].forEach(function(q){
    const r = q && (g.risp || {})[q]; if (!r) return;
    righe.push('Domanda del Genio: «' + umcTestoDomanda(q) + '» Risposta: «' + umcRispostaTesto(r) + '».');
  });
  if (tipo === 'segue') righe.push('Domanda di approfondimento del Genio: «' + (g.segueQ || '') + '» Risposta: «' + ((g.risp || {}).segue || '') + '».');
  return istr + '\n\n' + righe.join('\n');
}
async function umcMandaAgente(day, testo){
  try{
    const r = await agApi('POST', '/api/focuslock/agent/chat', { testo: '[umore] ' + testo, brief: (typeof agBrief === 'function') ? agBrief() : '' });
    if (!r || !r.id) throw new Error('nessun id');
    const s = umcStato(), g = umcGiorno(s, day); g.srv = r.id; umcSalva(s);
    umChatAttendi(day);
  }catch(_){ umcRicevi(day, null); }
}
function umChatAttendi(day){
  umChatFerma();
  const giro = async function(){
    const s0 = umcStato(), g0 = umcGiorno(s0, day);
    if (!g0.agente) return;
    if (Date.now() - (g0.agente.at || 0) > UMC_ATTESA_MAX){ g0.agente = null; umcSalva(s0); return; }
    if (!g0.srv){ UMC.poll = setTimeout(giro, 2500); return; }      // il messaggio e' ancora in viaggio
    try{
      const id = g0.srv;
      const r = await agApi('GET', '/api/focuslock/agent/chat?after=' + (id - 1));
      const risp = ((r && r.messaggi) || []).filter(function(m){ return m.direzione === 'out' && (m.inReplyTo === id || (m.id > id && m.azioni && m.azioni.umore)); })[0];
      if (risp){ umcRicevi(day, String(risp.testo || '').trim(), risp.id); return; }
    }catch(_){ }
    UMC.poll = setTimeout(giro, 2500);
  };
  UMC.poll = setTimeout(giro, 2500);
}
/** Il messaggio dell'agente, quando arriva: uno in piu', dopo quelli che ci sono gia'. Puo' aprire una domanda solo a conversazione finita. */
function umcRicevi(day, testo, srvId){
  const s = umcStato(), g = umcGiorno(s, day);
  const a = g.agente; if (!a) return;
  g.agente = null; g.srv = 0;
  const t = String(testo || '').replace(/^\s*(genio|il genio)\s*:\s*/i, '').replace(/\s*[—–]\s*/g, ', ').trim().slice(0, 500);
  if (t && !g.msgs.some(function(m){ return srvId && m.srv === srvId; })){
    const m = { dir: 'lui', testo: t, at: Date.now(), srv: srvId || 0 };
    /* se c'e' una domanda aperta resta l'ultima: le sue risposte si vedono solo sotto all'ultimo messaggio */
    let iq = -1; if (g.passo === 'q1' || g.passo === 'q2') g.msgs.forEach(function(x, n){ if (x.opz) iq = n; });
    if (iq >= 0) g.msgs.splice(iq, 0, m); else g.msgs.push(m);
    if (g.passo === 'fine' && !g.q2 && a.tipo === g.q1 && /\?/.test(t)){ m.segue = true; g.segueQ = t; g.passo = 'segue'; }
  }
  umcSalva(s);
  if (UMC.day === day && document.getElementById('umcLista')) umChatPaint();
}

/* ---------------------------------------------------------------------------------------
   PER IL DIARIO DI VIAGGIO (diario.js le chiama: questo file non tocca il diario)

   umDiarioRighe(iso) → array di frasi brevi in prima persona, già pronte da stampare una per
     riga, per il controllo dell'umore di quel giorno. La prima dice come ci si sentiva, le
     altre traducono le risposte alle domande del Genio. Mai «Domanda: risposta», mai il
     numero del voto. Le frasi non hanno genere («mi sentivo», non «mi sono sentito»).
     Esempio: ['Oggi mi sentivo benissimo.', 'Stanotte ho dormito poco.',
               'Questa settimana il lavoro è stato tanto, ma l’ho retto.']
     Array vuoto se quel giorno non c'è un voto.
   umDiarioNota(iso) → il testo scritto a mano quel giorno (la nota del Report, più le risposte
     scritte nella conversazione con il Genio), oppure ''. Va stampato com'è, magari fra
     virgolette: sono parole dell'utente, non dell'app.
   --------------------------------------------------------------------------------------- */
const UM_DIARIO_VOTO = ['Oggi mi sentivo malissimo.', 'Oggi mi sentivo giù: la giornata è andata storta.', 'Oggi mi sentivo così così.', 'Oggi mi sentivo bene.', 'Oggi mi sentivo benissimo.'];
function umDiarioRighe(iso){
  const v = umLeggi(iso);
  const n = v ? (+v.sodd || 0) : 0;
  if (!n || n < 1 || n > 5) return [];
  const out = [UM_DIARIO_VOTO[n - 1]];
  const risposte = v.risposte || [];
  const fatte = {};
  risposte.forEach(function(r){
    const D = UM_DOMANDE[r.q];
    if (!D) return;
    fatte[r.q] = true;
    if (r.i >= 0 && D.opz[r.i] && D.opz[r.i].d) out.push(D.opz[r.i].d);
    else if (r.i < 0 && D.liberoD) out.push(D.liberoD);
  });
  /* i giorni di prima della 0.9.217: motivi e carico salvati senza risposte */
  if (!fatte.meglio && !fatte.pesato && !fatte.deciso && (v.motivi || []).length){
    const id = umMotiviId(n);
    (v.motivi || []).forEach(function(m){
      const o = UM_DOMANDE[id].opz.filter(function(x){ return x.t === m; })[0]
        || UM_DOMANDE.meglio.opz.concat(UM_DOMANDE.pesato.opz, UM_DOMANDE.deciso.opz).filter(function(x){ return x.t === m; })[0];
      if (o && out.indexOf(o.d) < 0) out.push(o.d);
    });
  }
  if (!fatte.carico && v.carico){
    const o = UM_DOMANDE.carico.opz.filter(function(x){ return x.t.toLowerCase() === String(v.carico).toLowerCase(); })[0];
    if (o) out.push(o.d);
  }
  return out;
}
function umDiarioNota(iso){
  const v = umLeggi(iso); if (!v) return '';
  const parti = [];
  if (v.nota && String(v.nota).trim()) parti.push(String(v.nota).trim());
  (v.risposte || []).forEach(function(r){ if (r.i < 0 && r.t && String(r.t).trim()) parti.push(String(r.t).trim()); });
  /* prima della 0.9.217 il testo scritto in chat finiva fra i motivi */
  if (!(v.risposte || []).length){
    const noti = UM_MOTIVI_SU.concat(UM_MOTIVI_GIU, UM_MOTIVI_MEZZO).map(function(x){ return x[1]; });
    (v.motivi || []).forEach(function(m){ if (noti.indexOf(m) < 0 && m !== 'Altro' && parti.indexOf(m) < 0) parti.push(String(m)); });
  }
  return parti.filter(function(x, i, a){ return a.indexOf(x) === i; }).join('\n');
}

(function(){
  const css = [
    '.um-ico{display:inline-block;flex:none;vertical-align:middle}',
    '.um-info-link{display:flex;align-items:center;justify-content:center;gap:4px;width:100%;margin-top:10px;border:0;background:transparent;color:#0075E3;font:700 13.5px var(--font-body);cursor:pointer;padding:8px}',
    '.umi-fac{font-size:19px;margin-right:5px;vertical-align:-2px}.umi-vuoto{font:600 14px var(--font-body)}',
    '.umi-asse.fac{font-size:12px;text-anchor:middle;fill:initial}',
    '.umi-tabs{display:flex;background:#DCE6F2;border-radius:99px;padding:4px;margin:6px 0 14px;box-shadow:inset 0 1px 3px rgba(0,30,68,.12)}body.dark .umi-tabs{background:#1A2338;box-shadow:none}',
    '.umi-tabs button{flex:1;border:0;border-radius:99px;background:transparent;color:var(--muted);padding:12px;font:700 15px var(--font-body);cursor:pointer;transition:background .2s,color .2s}.umi-tabs button.on{background:#0075E3;color:#fff;box-shadow:0 4px 12px rgba(0,117,227,.35)}',
    '.umi-card{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:20px 18px;margin-bottom:14px}body.dark .umi-card{background:#141C2C;border-color:#25314A}',
    '.umi-centro{text-align:center}.umi-genio{height:110px;width:auto}',
    '.umi-card h3{margin:10px 0 6px;font:800 21px/1.25 var(--font-display);color:var(--navy)}body.dark .umi-card h3{color:#fff}',
    '.umi-card h4{margin:0;font:800 18px var(--font-display);color:var(--navy);text-align:center}body.dark .umi-card h4{color:#fff}',
    '.umi-range{display:block;margin:4px 0 14px;padding-bottom:12px;border-bottom:1px solid var(--line);font:600 12.5px var(--font-body);color:var(--muted);text-align:center}body.dark .umi-range{border-color:#25314A}',
    '.umi-card p,.umi-p{margin:8px 0 14px;font:500 14px/1.55 var(--font-body);color:var(--muted);text-align:center}',
    '.umi-cta{background:#0075E3;box-shadow:0 8px 22px rgba(0,117,227,.35)}',
    /* 7 giorni: le colonne che si riempiono dal basso, con la faccina in cima */
    '.umi-c7{display:flex;justify-content:space-between;gap:8px;height:200px;margin:4px 0 6px}',
    '.umi-col{flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;height:100%}',
    '.umi-track{position:relative;flex:1;width:100%;max-width:38px;border-radius:99px;background:#E9EFF7;overflow:visible}body.dark .umi-track{background:rgba(255,255,255,.07)}',
    '.umi-fill{position:absolute;left:0;right:0;bottom:0;height:0;border-radius:99px;transition:height .9s cubic-bezier(.25,1,.35,1) var(--d,0ms)}',
    '.umi-fill span{position:absolute;left:50%;top:0;transform:translate(-50%,-2px);width:34px;height:34px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;box-shadow:0 3px 10px rgba(0,30,68,.18)}',
    '.umi-fill.v1{background:#E63946}.umi-fill.v2{background:#F6A5B5}.umi-fill.v3{background:#D0D7FD}.umi-fill.v4{background:#3F9FF4}.umi-fill.v5{background:#0075E3}',
    '.umi-col small{font:600 11.5px var(--font-body);color:var(--muted)}',
    /* 30 giorni: la linea */
    '.umi-c30{display:block;width:100%;height:auto;margin:2px 0 4px}.umi-griglia{stroke:#DCE8F5;stroke-width:1}body.dark .umi-griglia{stroke:#25314A}.umi-vert{stroke:#DCE8F5;stroke-width:1;stroke-dasharray:3 4}body.dark .umi-vert{stroke:#25314A}',
    '.umi-asse{font:600 11px var(--font-body);fill:var(--muted)}.umi-asse.c{text-anchor:middle}',
    '.umi-linea{fill:none;stroke:#3F9FF4;stroke-width:2.5;stroke-linejoin:round;stroke-linecap:round;stroke-dasharray:900;stroke-dashoffset:900;animation:umiLinea 1.2s ease-out forwards}@keyframes umiLinea{to{stroke-dashoffset:0}}',
    '.umi-punto{stroke:#fff;stroke-width:2}.umi-punto.v1{fill:#E63946}.umi-punto.v2{fill:#F6A5B5}.umi-punto.v3{fill:#D0D7FD}.umi-punto.v4{fill:#3F9FF4}.umi-punto.v5{fill:#0075E3}',
    /* le due medie sotto al grafico */
    '.umi-boxes{display:flex;gap:10px;margin-top:14px}.umi-box{flex:1;border-radius:16px;padding:12px 10px;text-align:center}.umi-box small{display:block;font:600 12px/1.35 var(--font-body)}.umi-box b{display:block;margin-top:6px;font:800 17px var(--font-display);white-space:nowrap}',
    '.umi-box.blu{background:#E3F1FF}.umi-box.blu small,.umi-box.blu b{color:#005BB0}.umi-box.rosa{background:#FDEAF2}.umi-box.rosa small,.umi-box.rosa b{color:#A3386A}',
    'body.dark .umi-box.blu{background:#0F2A4D}body.dark .umi-box.blu small,body.dark .umi-box.blu b{color:#BCE0FF}body.dark .umi-box.rosa{background:#3A1A2E}body.dark .umi-box.rosa small,body.dark .umi-box.rosa b{color:#F6CCE4}',
    /* più selezionato */
    '.umi-top{margin-top:12px;text-align:left}.umi-top div{display:flex;align-items:center;gap:12px;padding:10px 4px;border-top:1px solid var(--line)}body.dark .umi-top div{border-color:#25314A}.umi-top span{font-size:22px}.umi-top b{flex:1;font:600 14px/1.4 var(--font-body);color:var(--navy)}body.dark .umi-top b{color:#fff}.umi-top i{font:800 14px var(--font-display);font-style:normal;color:#0075E3;white-space:nowrap}',
    '.umi-priv{margin:6px 0 0;padding:14px 10px;border-radius:18px;background:#0075E3;color:#fff;text-align:center;font:600 13px var(--font-body);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.umi-porta{display:flex;align-items:center;gap:12px;width:100%;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);color:var(--navy);padding:14px;margin:8px 0 12px;cursor:pointer;text-align:left}body.dark .umi-porta{background:#141C2C;border-color:#25314A;color:#fff}',
    '.umi-porta span{font-size:22px}.umi-porta div{flex:1}.umi-porta b{display:block;font:700 15px var(--font-body)}.umi-porta small{display:block;font:500 12px var(--font-body);color:var(--muted)}.umi-porta i{font-style:normal;color:var(--muted);display:flex}',
    /* il controllo quotidiano con il Genio (0.9.217): titolo centrato su una riga, come Meditopia */
    '#s-umore-chat{display:flex;flex-direction:column}#s-umore-chat.active{display:flex}',
    '.umc-top{position:relative;justify-content:center;min-height:40px}.umc-top .iconbtn{position:absolute;left:0;top:50%;transform:translateY(-50%)}',
    /* 0.9.219: il titolo grande quanto ci sta su una riga (Andrea): 16px a 360, 18px a 390, 19px a 412.
       Occupa tutto lo spazio a destra del pulsante indietro (non uno spazio uguale anche a destra):
       con lo spazio simmetrico, a 360px il titolo intero ci starebbe solo sotto i 15px. */
    '.umc-titolo{display:block;width:calc(100% - 44px);max-width:none;margin:0 0 0 44px;font:700 clamp(15px,calc(6vw - 5.5px),19px)/1.2 var(--font-display);font-style:normal;color:var(--navy);text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-.01em}body.dark .umc-titolo{color:#fff}',
    '.umc-voti{display:flex;justify-content:space-between;gap:8px;margin:4px 0 12px}.umc-voti span{flex:1;aspect-ratio:1;max-width:62px;display:flex;align-items:center;justify-content:center;border:2px solid var(--line);border-radius:18px;background:var(--card,#fff);font-size:26px;opacity:.45;filter:grayscale(.6)}body.dark .umc-voti span{background:#141C2C;border-color:#25314A}',
    '.umc-voti span.on{opacity:1;filter:none;border-color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.25)}',
    '.umc-lista{flex:1;overflow-y:auto;padding:4px 2px 12px}',
    '.umc-m{display:flex;align-items:flex-end;gap:8px;margin:0 0 10px}.umc-m.io{justify-content:flex-end}',
    '.umc-nuovo{opacity:0;animation:umcEntra .35s ease-out var(--d,0ms) forwards}@keyframes umcEntra{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '.umc-b{max-width:78%;padding:12px 14px;border-radius:18px;font:500 14.5px/1.5 var(--font-body)}.umc-m.lui .umc-b{background:var(--card,#fff);border:1px solid var(--line);color:var(--navy);border-bottom-left-radius:6px}body.dark .umc-m.lui .umc-b{background:#141C2C;border-color:#25314A;color:#fff}',
    '.umc-m.io .umc-b{background:#0075E3;color:#fff;border-bottom-right-radius:6px}',
    /* l'avatar del Genio: la testa, ritagliata da genio-saluta.png */
    '.umc-av{flex:none;width:34px;height:34px;border-radius:50%;background:#E3F1FF url(img/genio/genio-saluta.png) no-repeat;background-size:300% auto;background-position:50% 4%;box-shadow:0 0 0 2px #fff,0 2px 6px rgba(0,30,68,.15)}body.dark .umc-av{background-color:#0F2A4D;box-shadow:0 0 0 2px #141C2C}.umc-av.spazio,body.dark .umc-av.spazio{background:none;box-shadow:none}',
    '.umc-opz{margin:2px 0 14px 42px;display:flex;flex-direction:column;gap:8px}.umc-opz button{display:flex;align-items:center;gap:10px;width:100%;padding:13px 14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff);color:var(--navy);font:600 14px/1.35 var(--font-body);text-align:left;cursor:pointer}body.dark .umc-opz button{background:#141C2C;border-color:#25314A;color:#fff}',
    '.umc-opz button:active{transform:scale(.98)}.umc-opz button span{font-size:18px}',
    '.umc-opz .umc-libero{border-style:dashed;color:#0075E3}.umc-opz .umc-libero.on{border-style:solid;border-color:#0075E3;background:#E3F1FF}body.dark .umc-opz .umc-libero{color:#BCE0FF}body.dark .umc-opz .umc-libero.on{background:#0F2A4D}',
    '.umc-opz .umc-altro{justify-content:center;gap:6px;border-style:dashed;color:#0075E3}body.dark .umc-opz .umc-altro{color:#BCE0FF}',
    '.umc-opz .umc-salta{justify-content:center;border-style:dashed;color:var(--muted)}',
    '.umc-pensa{display:flex;gap:5px}.umc-pensa i{width:7px;height:7px;border-radius:50%;background:#8B99AC;animation:umcPensa 1s infinite}.umc-pensa i:nth-child(2){animation-delay:.15s}.umc-pensa i:nth-child(3){animation-delay:.3s}@keyframes umcPensa{50%{opacity:.25;transform:translateY(-3px)}}',
    /* 0.9.307: tutto centrato e due CTA di colori diversi (Andrea 30/10): il respiro e' rosso,
       il pulsante grande dei grafici resta blu; entrambi a pillola piena. */
    '.umc-resp{display:flex;flex-direction:column;align-items:center;text-align:center;gap:6px;margin:14px 0 6px;padding:18px 16px;border-radius:20px;background:linear-gradient(135deg,rgba(127,209,255,.16),rgba(0,117,227,.10));border:1.5px solid rgba(0,117,227,.22)}',
    '.umc-resp img{width:52px;height:52px;object-fit:contain}.umc-resp b{display:block;font:800 16.5px/1.3 var(--font-body);color:var(--navy);text-wrap:balance}.umc-resp small{display:block;margin:2px 0 12px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#5A6B85)}',
    '.umc-resp-b{background:#E63946;color:#fff;font:800 15px var(--font-body);padding:13px 24px;border-radius:50px;border:0;box-shadow:0 8px 20px rgba(230,57,70,.30)}',
    '.umc-fine{padding:14px 0 6px}.umc-info{display:block;width:100%;background:#0075E3;color:#fff;font:800 16.5px var(--font-body);padding:17px 18px;border-radius:50px;box-shadow:0 10px 26px rgba(0,117,227,.35)}',
    '.umc-input{display:flex;gap:8px;padding:8px 0 calc(8px + env(safe-area-inset-bottom))}.umc-input[hidden]{display:none}.umc-input textarea{flex:1;resize:none;border:1px solid var(--line);border-radius:18px;padding:12px 14px;font:500 14.5px var(--font-body);background:var(--card,#fff);color:var(--ink)}body.dark .umc-input textarea{background:#141C2C;border-color:#25314A;color:#fff}',
    '.umc-input button{flex:none;width:48px;border:0;border-radius:50%;background:#0075E3;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   Quello che esce di qui

   Due porte, e sono diverse apposta. A Jordan va tutto, perché deve riordinare le priorità.
   Al Genio va il minimo che gli serve per scegliere le domande — non i testi, che sono
   privati e non gli servirebbero a niente: gli serve sapere se la settimana è pesante.
   --------------------------------------------------------------------------------------- */

/** Per Jordan: gli ultimi `n` giorni, per intero. */
function umPerJordan(n){
  const out = [];
  for (let off = 0; off < (n || 7); off++){
    const d = umGiorno(off), v = umLeggi(d);
    if (v) out.push({ giorno: d, sentito: v.sodd || 0, fatto: umFattoVero(d), nota: v.nota || '', frasi: umDiarioRighe(d) });
  }
  return out;
}

/**
 * Per il Genio: due medie e quanti giorni le sostengono. Niente testi.
 *
 * <p>Il divario fra i due voti è la cosa più utile che ci sia qui dentro, e non si vede
 * guardandoli separatamente: chi fa tanto e sta male sta pagando un prezzo che i numeri non
 * mostrano, e chi fa poco ed è sereno non ha un problema di disciplina. Sono due persone che
 * vanno interrogate in modo opposto.</p>
 */
function umPerGenio(){
  const g = umPerJordan(14);
  if (!g.length) return null;
  const m = function(k){
    const v = g.filter(function(x){ return x[k] > 0; });
    return v.length ? v.reduce(function(a, x){ return a + x[k]; }, 0) / v.length : 0;
  };
  const fatto = m('fatto'), sentito = m('sentito');
  return {
    giorni: g.length,
    fatto: +fatto.toFixed(2),
    sentito: +sentito.toFixed(2),
    /* Positivo: fa più di quanto goda. Negativo: sta bene facendo poco. */
    divario: +(fatto - sentito).toFixed(2)
  };
}

(function umStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* La riga con il piu', come su AppBlock: un titolo e un gesto, niente da leggere. */
    '.um-testa{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:26px 0 10px}',
    '.um-testa b{font:700 14.5px var(--font-display);color:var(--navy)}',
    'body.dark .um-testa b{color:#fff}',
    '.um-piu{width:40px;height:40px;flex:none;border:0;border-radius:50%;background:var(--blue);',
      'color:#fff;font:400 22px/1 var(--font-body);cursor:pointer;display:flex;align-items:center;justify-content:center}',
    '.um-niente{margin:0;font:500 12.5px var(--font-body);color:var(--faint)}',
    '.um-card{background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;',
      'padding:14px 16px;cursor:pointer}',
    '.um-riga{display:flex;align-items:center;gap:12px;padding:9px 0}',
    '.um-riga > span{font-size:26px;line-height:1;flex:none}',
    '.um-riga > div{flex:1;min-width:0}',
    '.um-riga b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .um-riga b{color:#fff}',
    '.um-pt{font-style:normal;font:800 21px var(--font-display);color:var(--blue);flex:none}',
    '.um-pt u{text-decoration:none;font:600 11px var(--font-body);color:var(--faint)}',
    '.um-nota{margin:12px 0 0;padding-top:12px;border-top:1px solid var(--line);',
      'font:500 13px/1.6 var(--font-body);font-style:italic;color:var(--navy)}',
    'body.dark .um-nota{color:#E8F1FF}',

    '.um-sheet{position:fixed;inset:0;z-index:9994;background:rgba(0,8,20,.7);display:flex;',
      'align-items:flex-end;justify-content:center}',
    '.um-in{width:100%;max-width:460px;background:var(--card,#fff);border-radius:26px 26px 0 0;',
      'padding:12px 22px calc(24px + env(safe-area-inset-bottom,0px));',
      'max-height:92vh;overflow-y:auto;animation:prUp .22s ease-out}',
    '.um-in{position:relative}',
    '.um-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,30,68,.07);color:var(--navy);font:800 15px var(--font-body);cursor:pointer;display:grid;place-items:center}',
    'body.dark .um-x{background:rgba(255,255,255,.1);color:#fff}',
    /* al buio il foglio stacca dal velo: piu' chiaro, con il bordo chiaro (regola del 28/10) */
    'body.dark .um-in{background:#1C2E5A;border-top:1px solid rgba(188,224,255,.28)}',
    'body.dark .um-p{background:#22376B;border-color:rgba(188,224,255,.22)}',
    'body.dark .um-p.on{background:var(--blue);border-color:#8CC6FF}',
    '.um-in h3{margin:4px 0 6px;font:800 21px var(--font-display);color:var(--navy);text-align:center}',
    'body.dark .um-in h3{color:#fff}',
    '.um-sub{margin:0 0 18px;font:500 12.5px/1.6 var(--font-body);color:var(--muted);text-align:center}',
    '.um-p-row{display:flex;gap:8px}',
    '.um-p{flex:1;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;',
      'padding:11px 0;font:800 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.um-p span{display:block;font-size:26px;line-height:1.2}',
    'body.dark .um-p{color:#fff}',
    '.um-p.on{background:var(--blue);border-color:var(--blue);color:#fff}',
    '.um-sc-v{margin:10px 0 16px;min-height:1.2em;font:700 13px var(--font-body);color:var(--navy);text-align:center}',
    'body.dark .um-sc-v{color:#fff}',
    '.um-ta{width:100%;box-sizing:border-box;margin:0 0 16px;resize:none}'
  ].join('\n');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '.um-rivota{display:block;margin:0 auto 10px;padding:0;border:0;background:none;font-size:44px;line-height:1;cursor:pointer}.um-in .um-ta{display:block;margin:18px 0 22px}.um-in .um-info-link{display:block;margin:10px auto 0}.um-fine{text-align:center}.um-fine-e{display:block;font-size:52px;line-height:1;margin:6px 0 12px}.um-fine h3{margin-bottom:26px}';
  document.head.appendChild(st);
})();
