/* ===========================================================================================
   LE SESSIONI IN COPPIA (0.9.285) — come Focusmate

   Andrea: "voglio replicare le stesse funzioni di Focusmate". Dal codice della loro app:
     - si prenota una sessione di 25, 50 o 75 minuti che comincia a un quarto d'ora preciso;
     - si sceglie il tipo di lavoro (alla scrivania, in movimento, qualsiasi), il silenzio (niente
       microfono) e se preferire le persone preferite; si scrivono i compiti della sessione;
     - l'app trova il compagno (il server: focuslockCompagni.ts, stessa ora e stessa durata);
     - all'ora giusta si entra nella stanza: il video da telefono a telefono, il tempo, i compiti di
       tutti e due; se il compagno non arriva, se ne trova un altro rimasto da solo;
     - alla fine: com'e' andata e com'era la chiamata; le persone, i preferiti, i numeri.
   La prenotazione entra nel calendario di DreamMap con la Chiamata dei sogni all'inizio: e' cosi'
   che il telefono ti avvisa. Se il video non si collega (certe reti dei telefoni), la stanza resta:
   la presenza dell'altro, il tempo e i suoi compiti si aggiornano ogni pochi secondi.
   =========================================================================================== */
const CPL = { agenda: null, giorno: 0, durata: 50, slot: 0, att: 'scrivania', silenzio: false, preferiti: true, compiti: [], stanza: null, pc: null, loc: null, segn: 0, poll: 0, batt: 0, tick: 0, mic: true, cam: true, coda: [], persone: null, fine: null };
const CPL_ATT = [['scrivania', 'Alla scrivania', '💻'], ['movimento', 'In movimento', '🚶'], ['qualsiasi', 'Qualsiasi', '🔀']];
const CPL_DUR = [25, 50, 75];
const CPL_CAL_K = 'fl_coppia_cal';      // { <id prenotazione>: <id evento del calendario> }
const CPL_STORIA_K = 'fl_coppia_storia'; // [{ id, slotAt, durata, esito, nome }] le sessioni fatte (le legge il patto)
const CPL_I = {
  indietro: '<path d="M15 18l-6-6 6-6"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  micOff: '<path d="M3 3l18 18"/><path d="M9 9v2a3 3 0 0 0 5 2.2M15 9.3V6a3 3 0 0 0-5.6-1.5"/><path d="M5 11a7 7 0 0 0 11 5.7M19 11a7 7 0 0 1-.4 2.3M12 18v3"/>',
  cam: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3z"/>',
  camOff: '<path d="M3 3l18 18"/><path d="M10.5 6H14a2 2 0 0 1 2 2v3.5l5-3v10M16 16a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2"/>',
  esci: '<path d="M10 17l5-5-5-5"/><path d="M15 12H3M21 3v18"/>',
  stella: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  /* 0.9.353: la (i) della pagina, la freccia delle porte, la X delle righe, la lente del compagno da trovare */
  info: '<circle cx="12" cy="12" r="9.5"/><path d="M12 11v5.5M12 7.6h.01"/>',
  avanti: '<path d="M9 6l6 6-6 6"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  cerca: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
  piu: '<path d="M12 5v14M5 12h14"/>'
};
function cplIco(n, px){ return '<svg viewBox="0 0 24 24" width="' + (px || 20) + '" height="' + (px || 20) + '" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (CPL_I[n] || '') + '</svg>'; }
function cplEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function cplJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function cplScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function cplPuo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.accountApi === 'function'; }
async function cplApi(method, path, body){
  if (!cplPuo()) throw new Error('Le sessioni in coppia funzionano nell’app sul telefono');
  return NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
}
function cplOra(ms){ const d = new Date(ms); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function cplGiornoTxt(ms){
  const d = new Date(ms), oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const g = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - oggi.getTime()) / 86400000);
  if (g === 0) return 'Oggi'; if (g === 1) return 'Domani';
  return d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' }).replace(/^./, function(c){ return c.toUpperCase(); });
}
function cplNome(){ try{ const p = JSON.parse(localStorage.getItem('fl_profilo') || '{}') || {}; if (p.nome) return String(p.nome); }catch(_){ } try{ if (typeof nvNome === 'function' && nvNome()) return nvNome(); }catch(_){ } return ''; }
function cplTopbar(titolo, indietro){ return '<div class="topbar"><button class="iconbtn" onclick="' + (indietro || 'flIndietro()') + '" aria-label="Indietro">' + cplIco('indietro', 22) + '</button><b class="blk-title">' + titolo + '</b></div>'; }

/* 0.9.353, Andrea: "la pagina Sessioni in coppia e' una merda, rifalla completamente". Il come funziona sta nella (i) in alto a destra */
registerScreen('s-coppia', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + cplIco('indietro', 22) + '</button><b class="blk-title">Sessioni in coppia</b>'
  + '<button class="iconbtn cpl-i" onclick="cplInfo()" aria-label="Come funzionano le sessioni in coppia">' + cplIco('info', 22) + '</button></div><div id="cplBody"></div><div class="spacer"></div>');
/* 0.9.351, Andrea: "la pagina Prenota una sessione fa cagare: Impostazioni della sessione copre gli orari, e chiedi cosa farai tutto
   insieme. Una cosa alla volta; le impostazioni nei tre puntini in alto". Prima l'ora, poi (Continua) cosa farai, e le impostazioni nel ⋮ */
registerScreen('s-coppia-prenota', '<div class="topbar"><button class="iconbtn" onclick="cplPrenIndietro()" aria-label="Indietro">' + cplIco('indietro', 22) + '</button><b class="blk-title">Prenota una sessione</b><button class="iconbtn cpl-menu" onclick="cplImpApri()" aria-label="Impostazioni della sessione"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="12" cy="5" r="2" fill="currentColor"/><circle cx="12" cy="12" r="2" fill="currentColor"/><circle cx="12" cy="19" r="2" fill="currentColor"/></svg></button></div><div id="cplPren"></div><div class="spacer"></div>');
/* 0.9.371: indietro fa un passo indietro (cosa farai, ora, durata, giorno), poi esce */
function cplPrenIndietro(){ const prima = { compito: 'ora', ora: 'durata', durata: 'giorno' }[CPL.passo]; if (prima){ CPL.passo = prima; cplPrenPaint(); return; } if (typeof flIndietro === 'function') flIndietro(); else goId('s-coppia'); }
function cplImpApri(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio cpl-impf"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Impostazioni della sessione</h3><div id="cplImpBody">' + cplImpHtml() + '</div>'
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Fatto</button></div>');
}
function cplImpHtml(){
  return '<p class="cpl-l">Che lavoro fai</p><div class="cpl-att">' + CPL_ATT.map(function(a){ return '<button type="button" class="' + (a[0] === CPL.att ? 'on' : '') + '" onclick="CPL.att=\'' + a[0] + '\';document.getElementById(\'cplImpBody\').innerHTML=cplImpHtml()">' + a[2] + ' ' + cplEsc(a[1]) + '</button>'; }).join('') + '</div>'
    + '<div class="cpl-sw"><div><b>In silenzio</b><small>Senza microfono: vi vedete e basta.</small></div><button type="button" class="switch' + (CPL.silenzio ? ' on' : '') + '" onclick="CPL.silenzio=!CPL.silenzio;this.classList.toggle(\'on\',CPL.silenzio)" aria-label="In silenzio"></button></div>'
    + '<div class="cpl-sw"><div><b>Prima i miei preferiti</b><small>Se uno dei tuoi preferiti prenota la stessa ora, lavori con lui.</small></div><button type="button" class="switch' + (CPL.preferiti ? ' on' : '') + '" onclick="CPL.preferiti=!CPL.preferiti;this.classList.toggle(\'on\',CPL.preferiti)" aria-label="Prima i miei preferiti"></button></div>'
    + '<div class="cpl-sw"><div><b>Chiamami all’inizio</b><small>La Chiamata dei sogni all’ora della sessione. Spenta: ti avvisa il calendario.</small></div><button type="button" class="switch' + (cplChiamataOn() ? ' on' : '') + '" onclick="cplChiamataCambia(this)" aria-label="Chiamami all\'inizio"></button></div>';
}
registerScreen('s-coppia-persone', cplTopbar('Le persone') + '<div id="cplPers"></div><div class="spacer"></div>');
registerScreen('s-coppia-stanza', '<div id="cplStanza" class="cpl-stanza"></div>', { back: function(){ cplEsciChiedi(); return null; } });
registerScreen('s-coppia-fine', cplTopbar('Com’è andata?', 'cplFineSalta()') + '<div id="cplFine"></div><div class="spacer"></div>');

/* ---------------------------------------------------------------------------------------
   LA PAGINA: la prossima sessione, "unisciti adesso", prenota, le persone, i numeri
   --------------------------------------------------------------------------------------- */
async function cplApri(){ goId('s-coppia'); cplPaint(); await cplCarica(); cplPaint(); }
async function cplCarica(){
  try{ CPL.agenda = await cplApi('GET', '/api/focuslock/fm/agenda'); }catch(e){ CPL.agenda = { errore: String((e && e.message) || e) }; }
  try{ const p = await cplApi('GET', '/api/focuslock/fm/persone'); CPL.persone = p; }catch(_){ }
  try{ cplCalendarioAllinea(); }catch(_){ }
}
function cplProssima(){
  const a = CPL.agenda; if (!a || !a.mie) return null;
  const ora = Date.now();
  return a.mie.filter(function(s){ return s.stato !== 'annullata' && s.slotAt + s.durata * 60000 > ora && !s.esito; })[0] || null;
}
/* 0.9.353, Andrea: "e' una merda, rifalla completamente". Rifatta da zero con un elemento solo in primo piano (OEOF):
   - il palco con i due riquadri video, tu e un'altra persona, dice cos'e' in un colpo d'occhio, con una frase sola sotto;
   - con una sessione prenotata il palco diventa quella sessione: con chi, quando, ed Entra nella stanza quando apre;
   - sotto, in ordine di peso: prenota, chi comincia adesso, le altre sessioni, i numeri piccoli (solo quelli che non sono zero)
     e le due porte secondarie, Le persone e Il patto. Il come funziona sta nella (i) in alto. La logica non cambia. */
const CPL_SIL = '<svg class="cpl-sil" viewBox="0 0 120 112" aria-hidden="true"><circle cx="60" cy="40" r="19" fill="currentColor"/><path d="M20 112c0-25 18-42 40-42s40 17 40 42z" fill="currentColor"/><rect class="cpl-pc" x="33" y="80" width="54" height="32" rx="5"/><circle cx="60" cy="96" r="3" fill="#fff" opacity=".55"/></svg>';
function cplIniziale(n){ return cplEsc(String(n || '').trim().charAt(0).toUpperCase() || '?'); }
/* il nome da mostrare nel tuo riquadro (quello che va al server resta cplNome) */
function cplMioNome(){ const n = cplNome(); if (n) return n; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); return (u && (u.name || u.nome)) || ''; }catch(_){ return ''; } }
function cplPalco(p){
  if (!p){
    return '<div class="cpl-palco"><div class="cpl-tele">'
      + '<div class="cpl-t cpl-t-a">' + CPL_SIL + '<span class="cpl-t-tag">Tu</span></div>'
      + '<div class="cpl-t cpl-t-b">' + CPL_SIL + '<span class="cpl-t-tag">Un’altra persona</span></div>'
      + '<span class="cpl-timer" aria-hidden="true"><i></i>50:00</span></div></div>';
  }
  const ora = Date.now(), apre = p.slotAt - 5 * 60000, c = p.compagno, mio = cplMioNome();
  const sotto = c ? p.durata + ' minuti con ' + cplEsc(c.nome) + (c.silenzio ? ', senza microfono' : '') : p.durata + ' minuti. Sto cercando il tuo compagno.';
  return '<div class="cpl-palco sess"><div class="cpl-tele">'
    + '<div class="cpl-t cpl-t-a">' + (mio ? '<b class="cpl-t-ini">' + cplIniziale(mio) + '</b>' : CPL_SIL) + '<span class="cpl-t-tag">Tu</span></div>'
    + (c ? '<div class="cpl-t cpl-t-b"><b class="cpl-t-ini">' + cplIniziale(c.nome) + '</b><span class="cpl-t-tag">' + cplEsc(c.nome) + '</span></div>'
      : '<div class="cpl-t cpl-t-b cerca"><span class="cpl-cerca">' + cplIco('cerca', 30) + '</span><span class="cpl-t-tag">Il tuo compagno</span></div>')
    + '</div><div class="cpl-p-info"><b>' + cplEsc(cplGiornoTxt(p.slotAt)) + ' alle ' + cplOra(p.slotAt) + '</b><small>' + sotto + '</small></div>'
    + (ora >= apre ? '<button type="button" class="am-cta cpl-p-cta" onclick="cplEntra(' + p.id + ')">Entra nella stanza</button>' : '<span class="cpl-p-apre">La stanza apre alle ' + cplOra(apre) + '</span>')
    + '<button type="button" class="cpl-p-no" onclick="cplAnnulla(' + p.id + ')">Annulla la sessione</button></div>';
}
function cplInfo(){
  if (typeof inSheet !== 'function' || typeof flInfoRighe !== 'function') return;
  inSheet('<div class="en-foglio cpl-info"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Come funzionano le sessioni in coppia</h3>'
    + flInfoRighe([
      ['📅', 'Prenoti un’ora', 'Scegli il giorno, l’ora e se la sessione dura 25, 50 o 75 minuti.'],
      ['📝', 'Scrivi cosa farai', 'Prima di cominciare metti in fila i compiti della sessione.'],
      ['🎥', 'Lavorate in video', 'Vi vedete per tutta la sessione e ognuno fa la sua cosa.'],
      ['👥', 'Ritrovi chi ti è piaciuto', 'Con la stella, se prenotate la stessa ora lavorate di nuovo insieme.']
    ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function cplPaint(){
  const host = document.getElementById('cplBody'); if (!host) return;
  const puo = cplPuo(), a = CPL.agenda;
  const p = (puo && a && !a.errore) ? cplProssima() : null;
  let h = cplPalco(p);
  if (!p) h += '<p class="cpl-frase">Vi collegate in video, vi dite cosa farete e lo fate insieme.</p>';
  if (!puo){ host.innerHTML = '<div class="cpl-pg">' + h + '<p class="cpl-nota">Le sessioni in coppia funzionano nell’app sul telefono, con il tuo account Google.</p></div>'; return; }
  if (a && a.errore){
    host.innerHTML = '<div class="cpl-pg">' + h + '<p class="cpl-nota">Non riesco a leggere le tue sessioni. Controlla la connessione e riprova.</p><button type="button" class="am-cta cpl-go" onclick="cplApri()">Riprova</button></div>';
    return;
  }
  h += p ? '<button type="button" class="cpl-go2" onclick="cplPrenotaApri()">Prenota un’altra sessione</button>' : '<button type="button" class="am-cta cpl-go" onclick="cplPrenotaApri()">Prenota una sessione</button>';
  if (!a) h += '<p class="cpl-carica">Carico le tue sessioni…</p>';
  const adesso = ((a && a.aspettano) || []).filter(function(x){ return x.slotAt <= Date.now() + 10 * 60000 && x.slotAt >= Date.now() - 5 * 60000; })[0];
  if (adesso && (!p || p.slotAt !== adesso.slotAt)) h += '<button type="button" class="cpl-adesso" onclick="cplUnisciti(' + adesso.slotAt + ',' + adesso.durata + ')"><span class="cpl-puls" aria-hidden="true"></span>'
    + '<span class="cpl-adesso-t"><b>' + (adesso.n === 1 ? 'Una persona comincia' : adesso.n + ' persone cominciano') + ' alle ' + cplOra(adesso.slotAt) + '</b><small>Unisciti e lavorate insieme per ' + adesso.durata + ' minuti</small></span>' + cplIco('avanti', 18) + '</button>';
  const future = ((a && a.mie) || []).filter(function(s){ return s !== p && s.slotAt > Date.now() && s.stato !== 'annullata'; });
  if (future.length) h += '<p class="cpl-sez">Le altre sessioni prenotate</p>' + future.map(function(s){
    return '<div class="cpl-riga"><div><b>' + cplEsc(cplGiornoTxt(s.slotAt)) + ' alle ' + cplOra(s.slotAt) + '</b><small>' + s.durata + ' minuti' + (s.compagno ? ' con ' + cplEsc(s.compagno.nome) : ', sto cercando il tuo compagno') + '</small></div>'
      + '<button type="button" class="cpl-x" onclick="cplAnnulla(' + s.id + ')" aria-label="Annulla la sessione">' + cplIco('x', 16) + '</button></div>';
  }).join('');
  /* i numeri restano piccoli, e si vedono solo quelli che non sono zero */
  const n = (CPL.persone && CPL.persone.numeri) || {};
  const num = [[n.sessioni, n.sessioni === 1 ? 'sessione fatta' : 'sessioni fatte'], [n.settimana, 'questa settimana'], [n.serie, n.serie === 1 ? 'giorno di fila' : 'giorni di fila']].filter(function(x){ return x[0] > 0; });
  if (num.length) h += '<div class="cpl-num">' + num.map(function(x){ return '<div><b>' + x[0] + '</b><small>' + x[1] + '</small></div>'; }).join('') + '</div>';
  const np = ((CPL.persone && CPL.persone.persone) || []).length;
  h += '<div class="cpl-porte">'
    + '<button type="button" class="cpl-porta" onclick="cplPersoneApri()"><span aria-hidden="true">👥</span><b>Le persone</b><small>' + (np ? (np === 1 ? 'Hai lavorato con una persona' : 'Hai lavorato con ' + np + ' persone') : 'Qui trovi chi ha lavorato con te') + '</small>' + cplIco('avanti', 18) + '</button>'
    + '<button type="button" class="cpl-porta" onclick="if(typeof patApri===\'function\')patApri()"><span aria-hidden="true">✍️</span><b>Il patto</b><small>Un amico fa da garante del tuo impegno</small>' + cplIco('avanti', 18) + '</button></div>';
  host.innerHTML = '<div class="cpl-pg">' + h + '</div>';
}
async function cplAnnulla(id){
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Annullare la sessione?', 'Il tuo compagno ne trova un altro alla stessa ora.', 'Annulla la sessione', true); }catch(_){ }
  if (!ok) return;
  try{ await cplApi('POST', '/api/focuslock/fm/annulla', { id: id }); }catch(e){ toast('Non sono riuscito ad annullarla'); return; }
  cplCalTogli(id);
  toast('Sessione annullata');
  await cplCarica(); cplPaint();
}
async function cplUnisciti(slotAt, durata){
  CPL.slot = slotAt; CPL.durata = durata;
  await cplPrenota();
}

/* ---------------------------------------------------------------------------------------
   PRENOTA: il giorno, la durata, l'ora (con chi aspetta), le impostazioni, i compiti
   --------------------------------------------------------------------------------------- */
function cplPrenotaApri(){ CPL.giorno = 0; CPL.slot = 0; CPL.compiti = []; CPL.passo = 'giorno'; goId('s-coppia-prenota'); cplPrenPaint(); }
function cplSlotDelGiorno(g){
  const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + g);
  const inizio = d.getTime(), fine = inizio + 86400000;
  const Q = 15 * 60000;
  let t = Math.max(inizio, Math.ceil((Date.now() - 4 * 60000) / Q) * Q);
  const out = [];
  for (; t < fine; t += Q) out.push(t);
  return out;
}
function cplAspettano(t, durata){ const l = (CPL.agenda && CPL.agenda.aspettano) || []; const x = l.filter(function(a){ return a.slotAt === t && a.durata === durata; })[0]; return x ? x.n : 0; }
function cplPrenPaint(){
  const host = document.getElementById('cplPren'); if (!host) return;
  const giorni = [];
  for (let g = 0; g < 7; g++){ const d = new Date(); d.setDate(d.getDate() + g); giorni.push([g, g === 0 ? 'Oggi' : g === 1 ? 'Domani' : d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric' })]); }
  const slot = cplSlotDelGiorno(CPL.giorno);
  if (CPL.slot && slot.indexOf(CPL.slot) < 0) CPL.slot = 0;
  const att = CPL_ATT.filter(function(a){ return a[0] === CPL.att; })[0] || CPL_ATT[0];
  if (CPL.passo === 'compito' && CPL.slot){
    host.innerHTML = '<div class="cpl-pass2"><span class="cpl-pass2-o">' + cplEsc(cplGiornoTxt(CPL.slot)) + ', alle ' + cplOra(CPL.slot) + ' · ' + CPL.durata + ' minuti</span><h2 class="cpl-pass2-h">Cosa farai in questa sessione?</h2>'
      + '<div class="cpl-compiti">' + CPL.compiti.map(function(c, i){ return '<div class="cpl-comp"><span>' + cplEsc(c.t) + '</span><button type="button" onclick="CPL.compiti.splice(' + i + ',1);cplPrenPaint()" aria-label="Togli">✕</button></div>'; }).join('')
      +   (CPL.compiti.length < 3 ? '<input id="cplCompIn" class="fin" placeholder="Scrivi un compito e premi invio" onkeydown="if(event.key===\'Enter\'){event.preventDefault();cplCompAggiungi()}" onblur="cplCompAggiungi()">' : '') + '</div>'
      + '<button type="button" class="am-cta cpl-pass2-go" onclick="cplPrenota()">Prenota alle ' + cplOra(CPL.slot) + '</button>'
      + '<button type="button" class="am-link" onclick="CPL.passo=\'ora\';cplPrenPaint()">Cambia l’ora</button></div>';
    return;
  }
  /* 0.9.371, Andrea: "la pagina fa cagare: orari tagliati, il pulsante appoggiato li', e chiedi giorno, durata e ora tutto insieme. Prima
     il giorno con un calendario, come Calendly; una cosa alla volta, ovunque". Tre passi, uno per schermata: il giorno sul calendario
     del mese, la durata, l'ora in una lista che scorre con la pagina. Ogni tocco porta al passo dopo; sopra resta scritto quello che hai
     gia' scelto, e si tocca per cambiarlo */
  void giorni;
  const giornoMs = function(g){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + g); return d.getTime(); };
  const scelto = function(testo, passo){ return '<button type="button" class="cpl-scelto" onclick="CPL.passo=\'' + passo + '\';cplPrenPaint()">' + cplEsc(testo) + '<span>Cambia</span></button>'; };
  const gTxt = function(){ const d = new Date(giornoMs(CPL.giorno)); const t = d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' }); return CPL.giorno === 0 ? 'Oggi, ' + t : CPL.giorno === 1 ? 'Domani, ' + t : t.charAt(0).toUpperCase() + t.slice(1); };
  if (CPL.passo === 'durata'){
    host.innerHTML = '<div class="cpl-passo">' + scelto(gTxt(), 'giorno') + '<h2 class="cpl-pass2-h">Quanto dura?</h2>'
      + '<div class="cpl-dur2">' + CPL_DUR.map(function(m){ return '<button type="button" class="' + (m === CPL.durata ? 'on' : '') + '" onclick="CPL.durata=' + m + ';CPL.passo=\'ora\';cplPrenPaint()"><b>' + m + ' minuti</b></button>'; }).join('') + '</div></div>';
    return;
  }
  if (CPL.passo === 'ora'){
    host.innerHTML = '<div class="cpl-passo">' + scelto(gTxt() + ' · ' + CPL.durata + ' minuti', 'giorno') + '<h2 class="cpl-pass2-h">A che ora?</h2>'
      + '<div class="cpl-ore">' + (slot.length ? slot.map(function(t){
          const n = cplAspettano(t, CPL.durata);
          return '<button type="button" class="' + (n ? 'qualcuno' : '') + '" onclick="CPL.slot=' + t + ';CPL.passo=\'compito\';cplPrenPaint()"><b>' + cplOra(t) + '</b>' + (n ? '<small>' + (n === 1 ? 'Una persona aspetta' : n + ' persone aspettano') + '</small>' : '') + '</button>';
        }).join('') : '<p class="cpl-vuoto">Per oggi le ore sono finite: scegli un altro giorno.</p>') + '</div></div>';
    return;
  }
  /* il giorno: il mese, con i prossimi 14 giorni prenotabili */
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const primo = new Date(oggi.getFullYear(), oggi.getMonth() + (CPL.mese || 0), 1);
  const ultimoOk = giornoMs(13);
  const vuoti = (primo.getDay() + 6) % 7, nGiorni = new Date(primo.getFullYear(), primo.getMonth() + 1, 0).getDate();
  let celle = '';
  for (let i = 0; i < vuoti; i++) celle += '<span></span>';
  for (let d = 1; d <= nGiorni; d++){
    const ms = new Date(primo.getFullYear(), primo.getMonth(), d).getTime();
    const g = Math.round((ms - oggi.getTime()) / 86400000);
    const ok = ms >= oggi.getTime() && ms <= ultimoOk && !(g === 0 && !cplSlotDelGiorno(0).length);
    celle += ok ? '<button type="button" class="' + (g === CPL.giorno ? 'on' : '') + (g === 0 ? ' oggi' : '') + '" onclick="CPL.giorno=' + g + ';CPL.slot=0;CPL.passo=\'durata\';cplPrenPaint()">' + d + '</button>' : '<span class="no">' + d + '</span>';
  }
  const meseTxt = primo.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' });
  const puoAvanti = new Date(primo.getFullYear(), primo.getMonth() + 1, 1).getTime() <= ultimoOk;
  host.innerHTML = '<div class="cpl-passo"><h2 class="cpl-pass2-h">Che giorno?</h2>'
    + '<div class="cpl-cal"><div class="cpl-cal-m"><button type="button" ' + ((CPL.mese || 0) > 0 ? '' : 'disabled') + ' onclick="CPL.mese=(CPL.mese||0)-1;cplPrenPaint()" aria-label="Mese prima">' + cplIco('indietro', 20) + '</button><b>' + cplEsc(meseTxt.charAt(0).toUpperCase() + meseTxt.slice(1)) + '</b><button type="button" class="avanti" ' + (puoAvanti ? '' : 'disabled') + ' onclick="CPL.mese=(CPL.mese||0)+1;cplPrenPaint()" aria-label="Mese dopo">' + cplIco('indietro', 20) + '</button></div>'
    + '<div class="cpl-cal-s">' + ['L', 'M', 'M', 'G', 'V', 'S', 'D'].map(function(x){ return '<i>' + x + '</i>'; }).join('') + '</div>'
    + '<div class="cpl-cal-g">' + celle + '</div></div></div>';
}
function cplCompAggiungi(){
  const i = document.getElementById('cplCompIn'); const v = i ? i.value.trim() : '';
  if (!v) return;
  CPL.compiti.push({ t: v.slice(0, 140), fatto: false }); cplPrenPaint();
  setTimeout(function(){ const j = document.getElementById('cplCompIn'); if (j) j.focus(); }, 30);
}
/* 0.9.289, Andrea: "alle 23:45 mi e' arrivata la Chiamata dei sogni per una sessione in coppia che non ricordo di aver
   prenotato". Un tocco su "Prenota alle..." (o su "Unisciti") prenotava subito e metteva SEMPRE la chiamata. Adesso:
   - prima di prenotare un foglio dice giorno, ora e durata, e si conferma TENENDO PREMUTO (un tocco per sbaglio non basta);
   - la chiamata all'inizio parte solo se e' accesa "Chiamami all'inizio" (di serie spenta): altrimenti c'e' il
     promemoria del calendario del telefono. */
function cplChiamataOn(){ try{ return localStorage.getItem('fl_coppia_chiamata') === '1'; }catch(_){ return false; } }
function cplChiamataCambia(b){ const on = !cplChiamataOn(); try{ localStorage.setItem('fl_coppia_chiamata', on ? '1' : '0'); }catch(_){ } if (b) b.classList.toggle('on', on); try{ flVibra(8); }catch(_){ } }
function flTieniConferma(titolo, testo, etichetta){
  return new Promise(function(fatto){
    let w = document.getElementById('flTieni'); if (w) w.remove();
    w = document.createElement('div'); w.id = 'flTieni'; w.className = 'fl-tieni';
    w.innerHTML = '<div class="fl-tieni-f"><button type="button" class="fl-tieni-x" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button><b>' + cplEsc(titolo) + '</b><p>' + cplEsc(testo) + '</p>'
      + '<button type="button" class="fl-tieni-b"><i></i><span>' + cplEsc(etichetta) + '</span></button><small>Tieni premuto per confermare</small>'
      + '<button type="button" class="fl-tieni-no">Annulla</button></div>';
    document.body.appendChild(w);
    const chiudi = function(v){ w.remove(); fatto(v); };
    w.addEventListener('click', function(e){ if (e.target === w) chiudi(false); });
    w.querySelector('.fl-tieni-no').onclick = function(){ chiudi(false); };
    w.querySelector('.fl-tieni-x').onclick = function(){ chiudi(false); };
    const b = w.querySelector('.fl-tieni-b'), barra = b.querySelector('i');
    let t0 = 0, raf = 0;
    const giro = function(){ const q = Math.min(1, (performance.now() - t0) / 1000); barra.style.width = (q * 100) + '%'; if (q >= 1){ try{ flVibra([10, 30, 20]); }catch(_){ } chiudi(true); return; } raf = requestAnimationFrame(giro); };
    const via = function(e){ e.preventDefault(); t0 = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(giro); try{ flVibra(6); }catch(_){ } };
    const stop = function(){ cancelAnimationFrame(raf); raf = 0; barra.style.transition = 'width .25s'; barra.style.width = '0'; setTimeout(function(){ barra.style.transition = ''; }, 260); };
    b.addEventListener('pointerdown', via); b.addEventListener('pointerup', stop); b.addEventListener('pointerleave', stop); b.addEventListener('pointercancel', stop);
    b.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  });
}
async function cplPrenota(){
  if (!CPL.slot) return;
  cplCompAggiungi();
  const quando = cplGiornoTxt(CPL.slot) + ' alle ' + cplOra(CPL.slot);
  const ok = await flTieniConferma('Prenoti una sessione in coppia?', quando + ', per ' + CPL.durata + ' minuti. ' + (cplChiamataOn() ? 'All’inizio ti arriva la Chiamata dei sogni.' : 'All’inizio ti avvisa il calendario del telefono.'), 'Prenota ' + quando.charAt(0).toLowerCase() + quando.slice(1));
  if (!ok) return;
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/prenota', { slotAt: CPL.slot, durata: CPL.durata, attivita: CPL.att, silenzio: CPL.silenzio, preferiti: CPL.preferiti, compiti: CPL.compiti, nome: cplNome() }); }
  catch(e){ toast(/gia' una sessione|409/.test(String(e && e.message)) ? 'A quell’ora hai già una sessione' : 'Non sono riuscito a prenotare: riprova'); return; }
  const s = r && r.sessione;
  if (s) cplCalMetti(s);
  try{ flVibra([10, 30, 10]); }catch(_){ }
  const avviso = cplChiamataOn() ? 'All’inizio ti chiamo' : 'All’inizio ti avvisa il calendario';
  toast(s && s.compagno ? 'Prenotata con ' + s.compagno.nome + '. ' + avviso : 'Prenotata: appena trovo il tuo compagno lo vedi qui. ' + avviso);
  CPL.compiti = []; CPL.slot = 0;
  goId('s-coppia'); await cplCarica(); cplPaint();
}

/* ---- il calendario: la sessione entra con la Chiamata dei sogni all'inizio (e' il promemoria) ---- */
function cplCalMetti(s){
  if (typeof calSalvaEvento !== 'function') return;
  const m = cplJ(CPL_CAL_K, {}) || {};
  const titolo = 'Sessione in coppia' + (s.compagno ? ' con ' + s.compagno.nome : '');
  const descr = (s.compiti || []).map(function(c){ return '• ' + c.t; }).join('\n');
  const ev = calSalvaEvento({ id: m[s.id] || undefined, titolo: titolo, inizio: s.slotAt, fine: s.slotAt + s.durata * 60000, descr: descr, colore: '#FF6FA8', chiamata: cplChiamataOn() });
  if (ev && ev.id){ m[s.id] = ev.id; cplScrivi(CPL_CAL_K, m); }
}
function cplCalTogli(id){
  const m = cplJ(CPL_CAL_K, {}) || {};
  if (m[id] && typeof calEliminaEvento === 'function') calEliminaEvento(m[id]);
  delete m[id]; cplScrivi(CPL_CAL_K, m);
}
/* il compagno trovato dopo: il titolo dell'evento lo dice */
function cplCalendarioAllinea(){
  const a = CPL.agenda; if (!a || !a.mie || typeof calEventi !== 'function') return;
  const m = cplJ(CPL_CAL_K, {}) || {};
  a.mie.forEach(function(s){
    if (!m[s.id]) return;
    const ev = calEventi().filter(function(e){ return e.id === m[s.id]; })[0];
    const titolo = 'Sessione in coppia' + (s.compagno ? ' con ' + s.compagno.nome : '');
    if (ev && ev.titolo !== titolo) cplCalMetti(s);
  });
}

/* ---------------------------------------------------------------------------------------
   LA STANZA: il video, il tempo, i compiti di tutti e due
   --------------------------------------------------------------------------------------- */
async function cplEntra(id){
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/entra', { id: id }); }
  catch(e){ toast(/cinque minuti/.test(String(e && e.message)) ? 'La stanza apre cinque minuti prima' : 'Non riesco a entrare nella stanza'); return; }
  CPL.stanza = r; CPL.segn = 0; CPL.coda = []; CPL.mic = !(r.sessione && r.sessione.silenzio); CPL.cam = true; CPL.collegato = false; CPL.entratoAt = Date.now();
  CPL.compiti = (r.sessione && r.sessione.compiti) || [];
  goId('s-coppia-stanza');
  try{ flSchermoAcceso('coppia', true); }catch(_){ }
  cplStanzaPaint();
  cplVideo();
  clearInterval(CPL.batt); CPL.batt = setInterval(cplBattito, 5000);
  clearInterval(CPL.tick); CPL.tick = setInterval(cplTempo, 1000);
}
function cplStanzaPaint(){
  const host = document.getElementById('cplStanza'); if (!host || !CPL.stanza) return;
  const s = CPL.stanza.sessione, c = s.compagno;
  host.innerHTML = '<div class="cpl-v-altro"><video id="cplVAltro" autoplay playsinline></video><div class="cpl-v-vuoto" id="cplVVuoto"><span class="cpl-av">' + cplEsc(((c && c.nome) || '?').charAt(0).toUpperCase()) + '</span><b id="cplStato">' + (c ? (c.presente ? cplEsc(c.nome) + ' è nella stanza' : 'Aspetto ' + cplEsc(c.nome)) : 'Cerco il tuo compagno') + '</b></div></div>'
    + '<video id="cplVMio" class="cpl-v-mio" autoplay playsinline muted></video>'
    + '<div class="cpl-alto"><b id="cplTempo">--:--</b><small id="cplNome">' + (c ? cplEsc(c.nome) + (c.silenzio ? ' · in silenzio' : '') : '') + '</small></div>'
    + '<div class="cpl-pannello" id="cplPannello"></div>'
    + '<div class="cpl-ctl"><button type="button" id="cplMic" onclick="cplMic()" aria-label="Microfono">' + cplIco(CPL.mic ? 'mic' : 'micOff', 22) + '</button>'
    + '<button type="button" id="cplCam" onclick="cplCam()" aria-label="Videocamera">' + cplIco(CPL.cam ? 'cam' : 'camOff', 22) + '</button>'
    + '<button type="button" class="cpl-esci" onclick="cplEsciChiedi()" aria-label="Esci dalla sessione">' + cplIco('esci', 22) + '</button></div>';
  cplPannelloPaint();
  if (CPL.loc){ const v = document.getElementById('cplVMio'); if (v) v.srcObject = CPL.loc; }
  if (CPL.remoto){ const v = document.getElementById('cplVAltro'); if (v){ v.srcObject = CPL.remoto; document.getElementById('cplVVuoto').hidden = true; } }
}
function cplPannelloPaint(){
  const p = document.getElementById('cplPannello'); if (!p || !CPL.stanza) return;
  const c = CPL.stanza.sessione.compagno;
  p.innerHTML = '<p class="cpl-pl">I tuoi compiti</p>'
    + CPL.compiti.map(function(x, i){ return '<label class="cpl-ck"><input type="checkbox" ' + (x.fatto ? 'checked' : '') + ' onchange="CPL.compiti[' + i + '].fatto=this.checked;cplBattito(true)"><span>' + cplEsc(x.t) + '</span></label>'; }).join('')
    + (CPL.compiti.length < 8 ? '<input id="cplStCompIn" class="cpl-st-in" placeholder="Aggiungi un compito" onkeydown="if(event.key===\'Enter\'){event.preventDefault();cplStComp()}">' : '')
    + (c ? '<p class="cpl-pl">I compiti di ' + cplEsc(c.nome) + '</p>' + ((c.compiti || []).length ? c.compiti.map(function(x){ return '<div class="cpl-ck altro' + (x.fatto ? ' fatto' : '') + '"><i>' + (x.fatto ? '✓' : '') + '</i><span>' + cplEsc(x.t) + '</span></div>'; }).join('') : '<p class="cpl-pv">Ancora nessun compito scritto.</p>') : '');
}
function cplStComp(){ const i = document.getElementById('cplStCompIn'); const v = i ? i.value.trim() : ''; if (!v) return; CPL.compiti.push({ t: v.slice(0, 140), fatto: false }); cplPannelloPaint(); cplBattito(true); }
function cplTempo(){
  if (!CPL.stanza) return;
  const s = CPL.stanza.sessione, ora = Date.now();
  const inizio = s.slotAt, fine = s.slotAt + s.durata * 60000;
  const el = document.getElementById('cplTempo');
  const mmss = function(ms){ const t = Math.max(0, Math.round(ms / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  if (el) el.textContent = ora < inizio ? 'Comincia fra ' + mmss(inizio - ora) : mmss(fine - ora);
  /* il compagno non e' arrivato cinque minuti dopo l'inizio: se ne cerca un altro */
  const c = s.compagno;
  if (ora > inizio + 5 * 60000 && (!c || !c.dentro) && !CPL.offertoAltro){ CPL.offertoAltro = true; cplNonArrivato(); }
  if (ora >= fine){ cplChiudiStanza(); cplFineApri(); }
}
function cplNonArrivato(){
  const host = document.getElementById('cplPannello'); if (!host) return;
  const c = CPL.stanza && CPL.stanza.sessione.compagno;
  host.insertAdjacentHTML('afterbegin', '<div class="cpl-assente"><b>' + (c ? cplEsc(c.nome) + ' non è arrivato' : 'Nessun compagno, per ora') + '</b><button type="button" class="am-cta" onclick="cplRiabbina()">Trova un altro compagno</button><button type="button" class="am-link" onclick="this.parentElement.remove()">Lavoro da solo</button></div>');
}
async function cplRiabbina(){
  try{
    const r = await cplApi('POST', '/api/focuslock/fm/riabbina', { id: CPL.stanza.sessione.id });
    if (r && r.ok){ toast('Trovato: entro di nuovo nella stanza'); const id = CPL.stanza.sessione.id; cplChiudiStanza(true); setTimeout(function(){ cplEntra(id); }, 400); }
    else toast('Adesso non c’è nessun altro: lavora da solo, il tempo continua');
  }catch(_){ toast('Non sono riuscito a cercare un altro compagno'); }
}
async function cplBattito(conCompiti){
  if (!CPL.stanza) return;
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/battito', Object.assign({ id: CPL.stanza.sessione.id }, conCompiti ? { compiti: CPL.compiti } : {})); }catch(_){ return; }
  if (!r || !r.sessione || !CPL.stanza) return;
  const prima = CPL.stanza.sessione.compagno;
  CPL.stanza.sessione.compagno = r.sessione.compagno;
  CPL.stanza.sessione.stanza = r.sessione.stanza;
  const c = r.sessione.compagno;
  const st = document.getElementById('cplStato');
  if (st && c) st.textContent = c.presente ? c.nome + ' è nella stanza' : 'Aspetto ' + c.nome;
  const nm = document.getElementById('cplNome'); if (nm && c) nm.textContent = c.nome + (c.silenzio ? ' · in silenzio' : '');
  /* un compagno nuovo (trovato dopo): si ricollega il video con la sua stanza */
  if (c && (!prima || prima.id !== c.id) && r.sessione.stanza && !CPL.pc){ CPL.stanza.primo = CPL.stanza.sessione.id < c.id; cplVideo(); }
  cplPannelloPaint();
}

/* ---- il video: WebRTC da telefono a telefono, i messaggi per collegarsi passano dal server ---- */
async function cplVideo(){
  const st = CPL.stanza; if (!st || !st.sessione.stanza || CPL.pc) { cplCamera(); return; }
  await cplCamera();
  let pc;
  try{ pc = new RTCPeerConnection({ iceServers: st.ice || [] }); }catch(_){ return; }
  CPL.pc = pc;
  if (CPL.loc) CPL.loc.getTracks().forEach(function(t){ pc.addTrack(t, CPL.loc); });
  else { try{ pc.addTransceiver('video', { direction: 'recvonly' }); pc.addTransceiver('audio', { direction: 'recvonly' }); }catch(_){ } }
  pc.ontrack = function(e){
    CPL.remoto = e.streams[0];
    const v = document.getElementById('cplVAltro'); if (v){ v.srcObject = CPL.remoto; }
    const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = true;
  };
  pc.onicecandidate = function(e){ if (e.candidate) cplSegnale('ice', JSON.stringify(e.candidate)); };
  pc.onconnectionstatechange = function(){
    CPL.collegato = pc.connectionState === 'connected';
    if (pc.connectionState === 'failed'){ const st2 = document.getElementById('cplStato'); if (st2) st2.textContent = 'Il video non si collega su questa rete: il tempo e i compiti restano'; const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = false; }
  };
  if (st.primo){
    try{ const o = await pc.createOffer(); await pc.setLocalDescription(o); cplSegnale('offerta', JSON.stringify(pc.localDescription)); }catch(_){ }
  } else cplSegnale('ancora', '');
  clearInterval(CPL.poll); CPL.poll = setInterval(cplSegnali, 1500);
}
async function cplCamera(){
  if (CPL.loc) return;
  try{
    CPL.loc = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: { echoCancellation: true, noiseSuppression: true } });
    CPL.loc.getAudioTracks().forEach(function(t){ t.enabled = CPL.mic; });
    const v = document.getElementById('cplVMio'); if (v) v.srcObject = CPL.loc;
  }catch(_){
    CPL.loc = null;
    toast('Senza videocamera e microfono il tuo compagno non ti vede: il tempo e i compiti restano');
  }
}
async function cplSegnale(tipo, dati){
  const st = CPL.stanza; if (!st || !st.sessione.stanza) return;
  try{ await cplApi('POST', '/api/focuslock/fm/segnale', { stanza: st.sessione.stanza, tipo: tipo, dati: dati }); }catch(_){ }
}
async function cplSegnali(){
  const st = CPL.stanza, pc = CPL.pc; if (!st || !pc || !st.sessione.stanza) return;
  let r; try{ r = await cplApi('GET', '/api/focuslock/fm/segnali?stanza=' + encodeURIComponent(st.sessione.stanza) + '&dopo=' + CPL.segn); }catch(_){ return; }
  for (const s of ((r && r.segnali) || [])){
    CPL.segn = Math.max(CPL.segn, s.id);
    try{
      if (s.tipo === 'offerta'){
        await pc.setRemoteDescription(JSON.parse(s.dati));
        const a = await pc.createAnswer(); await pc.setLocalDescription(a);
        cplSegnale('risposta', JSON.stringify(pc.localDescription));
        await cplCodaIce();
      } else if (s.tipo === 'risposta'){
        if (pc.signalingState === 'have-local-offer') await pc.setRemoteDescription(JSON.parse(s.dati));
        await cplCodaIce();
      } else if (s.tipo === 'ice'){
        const c = JSON.parse(s.dati);
        if (pc.remoteDescription && pc.remoteDescription.type) await pc.addIceCandidate(c); else CPL.coda.push(c);
      } else if (s.tipo === 'ancora' && st.primo && pc.localDescription){
        /* il compagno e' entrato dopo: gli si rimanda l'offerta */
        cplSegnale('offerta', JSON.stringify(pc.localDescription));
      } else if (s.tipo === 'fine'){
        const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = false;
        const st2 = document.getElementById('cplStato'); if (st2) st2.textContent = 'Il tuo compagno è uscito';
      }
    }catch(_){ }
  }
}
async function cplCodaIce(){ const pc = CPL.pc; while (pc && CPL.coda.length){ try{ await pc.addIceCandidate(CPL.coda.shift()); }catch(_){ } } }
function cplMic(){ CPL.mic = !CPL.mic; if (CPL.loc) CPL.loc.getAudioTracks().forEach(function(t){ t.enabled = CPL.mic; }); const b = document.getElementById('cplMic'); if (b) b.innerHTML = cplIco(CPL.mic ? 'mic' : 'micOff', 22); }
function cplCam(){ CPL.cam = !CPL.cam; if (CPL.loc) CPL.loc.getVideoTracks().forEach(function(t){ t.enabled = CPL.cam; }); const b = document.getElementById('cplCam'); if (b) b.innerHTML = cplIco(CPL.cam ? 'cam' : 'camOff', 22); }
async function cplEsciChiedi(){
  if (!CPL.stanza){ goId('s-coppia'); return; }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Uscire dalla sessione?', 'Il tuo compagno resta nella stanza da solo.', 'Esci', true); }catch(_){ }
  if (!ok) return;
  cplSegnale('fine', '');
  cplChiudiStanza(); cplFineApri();
}
function cplChiudiStanza(silenzioso){
  clearInterval(CPL.poll); clearInterval(CPL.batt); clearInterval(CPL.tick);
  try{ if (CPL.pc) CPL.pc.close(); }catch(_){ }
  CPL.pc = null; CPL.remoto = null; CPL.offertoAltro = false;
  try{ if (CPL.loc) CPL.loc.getTracks().forEach(function(t){ t.stop(); }); }catch(_){ }
  CPL.loc = null;
  try{ flSchermoAcceso('coppia', false); }catch(_){ }
  if (!silenzioso && CPL.stanza) CPL.fine = { sessione: CPL.stanza.sessione, esito: '', voto: '', preferito: !!(CPL.stanza.sessione.compagno && CPL.stanza.sessione.compagno.preferito) };
  if (silenzioso) CPL.stanza = null;
}

/* ---------------------------------------------------------------------------------------
   LA FINE: com'e' andata, com'era la chiamata, il compagno fra i preferiti
   --------------------------------------------------------------------------------------- */
function cplFineApri(){ CPL.stanza = null; goId('s-coppia-fine'); cplFinePaint(); }
function cplFinePaint(){
  const host = document.getElementById('cplFine'); if (!host || !CPL.fine) return;
  const f = CPL.fine, c = f.sessione.compagno;
  const scelta = function(chiave, l){ return '<div class="cpl-scelte">' + l.map(function(x){ return '<button type="button" class="' + (f[chiave] === x[0] ? 'on' : '') + '" onclick="CPL.fine.' + chiave + '=\'' + x[0] + '\';cplFinePaint()">' + x[1] + '</button>'; }).join('') + '</div>'; };
  host.innerHTML = '<p class="cpl-l">Hai fatto quello che avevi detto?</p>' + scelta('esito', [['fatto', '✅ Tutto'], ['parte', '🌓 In parte'], ['no', '❌ No']])
    + (c ? '<p class="cpl-l">Com’era la chiamata?</p>' + scelta('voto', [['ottima', 'Ottima'], ['lievi', 'Qualche problema'], ['gravi', 'Problemi gravi']])
      + '<div class="cpl-sw"><div><b>' + cplEsc(c.nome) + ' fra i tuoi preferiti</b><small>Se prenotate la stessa ora, lavorate di nuovo insieme.</small></div><button type="button" class="switch' + (f.preferito ? ' on' : '') + '" onclick="CPL.fine.preferito=!CPL.fine.preferito;this.classList.toggle(\'on\',CPL.fine.preferito)" aria-label="Fra i preferiti"></button></div>' : '')
    + (f.voto === 'gravi' ? '<textarea id="cplNota" class="fin" rows="2" placeholder="Cosa non è andato? Resta privato: il tuo compagno non lo vede"></textarea>' : '')
    + '<button type="button" class="am-cta" ' + (f.esito ? '' : 'disabled') + ' onclick="cplFineSalva()">Salva</button>';
}
async function cplFineSalva(){
  const f = CPL.fine; if (!f || !f.esito) return;
  const s = f.sessione;
  const nota = (document.getElementById('cplNota') || {}).value || '';
  try{ await cplApi('POST', '/api/focuslock/fm/fine', { id: s.id, esito: f.esito, voto: f.voto || null, nota: nota }); }catch(_){ }
  if (s.compagno && f.preferito !== !!s.compagno.preferito){ try{ await cplApi('POST', '/api/focuslock/fm/preferito', { sessione: s.id, on: f.preferito }); }catch(_){ } }
  /* la sessione fatta: la leggono il patto (verifica "coppia") e la partita */
  const l = cplJ(CPL_STORIA_K, []) || [];
  l.push({ id: s.id, slotAt: s.slotAt, durata: s.durata, esito: f.esito, nome: (s.compagno && s.compagno.nome) || '' });
  cplScrivi(CPL_STORIA_K, l.slice(-200));
  if (f.esito !== 'no'){ try{ if (typeof mgFocusPoint === 'function') mgFocusPoint('sessione portata a termine in coppia', true); }catch(_){ } }
  CPL.fine = null;
  toast(f.esito === 'fatto' ? 'Fatto. Alla prossima sessione' : 'Salvato');
  goId('s-coppia'); await cplCarica(); cplPaint();
}
function cplFineSalta(){ CPL.fine = null; goId('s-coppia'); cplPaint(); }

/* ---------------------------------------------------------------------------------------
   LE PERSONE: chi ha lavorato con te, con la stella dei preferiti
   --------------------------------------------------------------------------------------- */
async function cplPersoneApri(){
  goId('s-coppia-persone');
  const host = document.getElementById('cplPers'); if (host) host.innerHTML = '<p class="cpl-carica">Carico le persone…</p>';
  try{ CPL.persone = await cplApi('GET', '/api/focuslock/fm/persone'); }catch(_){ }
  cplPersonePaint();
}
function cplPersonePaint(){
  const host = document.getElementById('cplPers'); if (!host) return;
  const l = (CPL.persone && CPL.persone.persone) || [];
  host.innerHTML = l.length ? '<p class="cpl-intro">Con la stella, <b>se prenotate la stessa ora lavorate di nuovo insieme.</b></p>' + l.map(function(p){
    return '<div class="cpl-riga"><span class="cpl-av piccolo">' + cplEsc(String(p.nome || '?').charAt(0).toUpperCase()) + '</span><div><b>' + cplEsc(p.nome) + '</b><small>' + p.sessioni + (p.sessioni === 1 ? ' sessione' : ' sessioni') + ' insieme · l’ultima ' + cplEsc(cplGiornoTxt(p.ultima).toLowerCase()) + '</small></div>'
      + '<button type="button" class="cpl-stella' + (p.preferito ? ' on' : '') + '" onclick="cplStella(\'' + cplEsc(p.persona) + '\',' + (!p.preferito) + ')" aria-label="' + (p.preferito ? 'Togli dai preferiti' : 'Aggiungi ai preferiti') + '">' + cplIco('stella', 20) + '</button></div>';
  }).join('') : '<p class="cpl-intro">Qui compaiono le persone con cui hai fatto una sessione.</p>';
}
async function cplStella(persona, on){
  try{ await cplApi('POST', '/api/focuslock/fm/preferito', { persona: persona, on: on }); }catch(_){ toast('Non sono riuscito a cambiarlo'); return; }
  (CPL.persone.persone || []).forEach(function(p){ if (p.persona === persona) p.preferito = on; });
  cplPersonePaint();
}

/* ---- IL BLOCCO IN START: "Lavora in compagnia", con la porta delle sessioni in coppia (il patto vive dentro la loro pagina) ---- */
function cplStartBlocco(){
  const tab = document.getElementById('tab-sveglia'); if (!tab) return;
  let b = document.getElementById('cplHost');
  if (!b){
    b = document.createElement('div'); b.id = 'cplHost'; b.className = 'cpl-start';
    const sp = document.getElementById('spHost');
    tab.insertBefore(b, sp && sp.parentElement === tab ? sp : null);
    try{ if (typeof scsOrdinaBlocchi === 'function') setTimeout(function(){ scsOrdinaBlocchi('start'); }, 0); }catch(_){ }
  }
  /* 0.9.290, Andrea: "Lavora in compagnia deve comparire solo in In gruppo, non in Da solo; ed e' attaccato al pannello
     di Full Focus". Si vede solo con l'interruttore su In gruppo, con l'aria delle altre sezioni. */
  b.hidden = typeof stModo === 'function' && stModo() !== 'gruppo';
  /* 0.9.353, Andrea: "l'opzione il patto la leverei da li', metterei semplicemente sessioni in coppia, punto". Il patto sta gia' dentro
     la pagina delle sessioni: qui resta una porta sola. Se la prossima sessione e' gia' nota, la riga dice quando */
  const p = (CPL.agenda && !CPL.agenda.errore) ? cplProssima() : null;
  const sotto = p ? cplGiornoTxt(p.slotAt) + ' alle ' + cplOra(p.slotAt) + (p.compagno ? ', con ' + p.compagno.nome : '') : 'Vi vedete in video e ognuno lavora alla sua cosa';
  b.innerHTML = '<div class="cpl-start-in2"><span class="cpl-start-ico2" aria-hidden="true">🤝</span><b>Lavora in compagnia</b><p>Con qualcuno accanto mollare è più difficile.</p></div>'
    + '<button type="button" class="cpl-start-r" onclick="cplApri()"><span aria-hidden="true">🎥</span><div><b>Sessioni in coppia</b><small>' + cplEsc(sotto) + '</small></div>' + cplIco('avanti', 18) + '</button>';
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia') setTimeout(cplStartBlocco, 300); });
(function(){ if (typeof stModoSet === 'function'){ const v = stModoSet; window.stModoSet = stModoSet = function(){ const r = v.apply(this, arguments); try{ cplStartBlocco(); }catch(_){ } return r; }; } })();
setTimeout(cplStartBlocco, 2500);

/* ---- la sessione che comincia: la notifica della Chiamata dei sogni porta qui (e la pagina si aggiorna) ---- */
(function(){
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.getElementById('s-coppia') && document.getElementById('s-coppia').classList.contains('active')) cplCarica().then(cplPaint); });
  const css = [
    '.cpl-menu{margin-left:auto}.cpl-pren-piede{position:sticky;bottom:0;padding:14px 0 calc(10px + env(safe-area-inset-bottom,0px));background:linear-gradient(180deg,rgba(244,249,255,0),var(--bg,#F4F9FF) 30%)}body.dark .cpl-pren-piede{background:linear-gradient(180deg,rgba(12,18,32,0),var(--bg,#0C1220) 30%)}.cpl-pren-piede .am-cta{margin:0}',
    '.cpl-pass2{text-align:center;padding-top:18px}.cpl-pass2-o{display:inline-block;padding:7px 14px;border-radius:99px;background:#F0FBFF;border:1px solid #C8EFFD;font:800 13px var(--font-body);color:#0075E3}.cpl-pass2-h{margin:18px 0 24px;font:800 22px/1.3 var(--font-display);color:var(--navy)}body.dark .cpl-pass2-h{color:#fff}body.dark .cpl-pass2-o{background:#12203A;border-color:#22345A;color:#8CC6FF}.cpl-pass2 .cpl-compiti{text-align:left}.cpl-pass2-go{margin-top:28px!important}.cpl-impf .cpl-l{margin-top:4px}',
    '.cpl-intro{margin:4px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.cpl-intro b{color:var(--navy)}body.dark .cpl-intro b{color:#fff}',
    '.cpl-carica{margin:14px 0 0;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    /* 0.9.353: la pagina rifatta. Il palco porta il gradiente del brand (l'unico della schermata); i riquadri video sono le due persone */
    '.cpl-pg{display:flex;flex-direction:column;padding-top:16px}',
    '.cpl-palco{position:relative;border-radius:26px;padding:22px 18px 34px;border:2px solid transparent;background:var(--dream) padding-box,linear-gradient(135deg,#E63946,#0075E3) border-box;box-shadow:0 14px 34px rgba(0,30,68,.12)}',
    'body.dark .cpl-palco{background:linear-gradient(160deg,#17305C,#0C1A36) padding-box,linear-gradient(135deg,#E63946,#0075E3) border-box;box-shadow:0 14px 34px rgba(0,0,0,.35)}',
    '.cpl-palco.sess{padding-bottom:20px}',
    '.cpl-tele{position:relative;display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.cpl-t{position:relative;min-width:0;aspect-ratio:1/1.08;border-radius:20px;overflow:hidden;display:flex;align-items:flex-end;justify-content:center}.cpl-palco.sess .cpl-t{aspect-ratio:1/.84;align-items:center}',
    '.cpl-t-a{background:#0075E3;color:#C8EFFD}.cpl-t-b{background:#001E44;color:#8CC6FF;box-shadow:inset 0 0 0 1.5px rgba(140,198,255,.3)}',
    '.cpl-sil{display:block;width:78%;height:auto}.cpl-t-a .cpl-pc{fill:#001E44;opacity:.88}.cpl-t-b .cpl-pc{fill:#0075E3}',
    '.cpl-t-tag{position:absolute;left:9px;top:9px;max-width:calc(100% - 18px);box-sizing:border-box;overflow:hidden;text-overflow:ellipsis;padding:4px 9px;border-radius:99px;background:rgba(0,30,68,.55);color:#fff;font:700 11.5px/1.3 var(--font-body);white-space:nowrap}.cpl-t-b .cpl-t-tag{background:rgba(255,255,255,.16)}',
    '.cpl-timer{position:absolute;left:50%;bottom:-16px;transform:translateX(-50%);display:inline-flex;align-items:center;gap:7px;padding:7px 14px;border-radius:99px;background:#fff;color:#001E44;font:800 14px/1 var(--font-display);box-shadow:0 6px 16px rgba(0,30,68,.22);white-space:nowrap}',
    '.cpl-timer i{width:8px;height:8px;border-radius:50%;background:#E63946;animation:cplLive 1.6s infinite}@keyframes cplLive{50%{opacity:.3}}',
    '.cpl-t-ini{font:900 46px/1 var(--font-display);color:#fff}',
    '.cpl-t-b.cerca{background:rgba(255,255,255,.5);box-shadow:none;border:2px dashed #3F9FF4;box-sizing:border-box}.cpl-cerca{display:grid;place-items:center;width:62px;height:62px;border-radius:50%;background:#fff;color:#0075E3;animation:cplCerca 1.8s ease-in-out infinite}@keyframes cplCerca{50%{transform:scale(1.08)}}',
    'body.dark .cpl-t-b.cerca{background:rgba(255,255,255,.05)}body.dark .cpl-cerca{background:#22345A;color:#8CC6FF}',
    '.cpl-p-info{margin-top:24px;text-align:center}.cpl-p-info b{display:block;font:900 24px/1.2 var(--font-display);color:#001E44}.cpl-p-info small{display:block;margin-top:8px;font:600 14.5px/1.4 var(--font-body);color:#33476A}',
    'body.dark .cpl-p-info b{color:#fff}body.dark .cpl-p-info small{color:#C8DDF8}',
    '.cpl-palco .cpl-p-cta{margin:24px 0 0;width:100%}',
    '.cpl-p-apre{display:block;width:max-content;max-width:100%;box-sizing:border-box;margin:22px auto 0;padding:9px 16px;border-radius:99px;background:rgba(255,255,255,.72);color:#001E44;font:700 13.5px var(--font-body)}body.dark .cpl-p-apre{background:rgba(255,255,255,.1);color:#fff}',
    '.cpl-p-no{display:block;margin:10px auto 0;border:0;background:none;padding:8px 12px;font:700 14px var(--font-body);color:#0075E3;cursor:pointer}body.dark .cpl-p-no{color:#8CC6FF}',
    '.cpl-frase{margin:30px auto 0;max-width:30ch;text-align:center;font:600 17px/1.45 var(--font-body);color:var(--navy)}',
    '.cpl-nota{margin:24px auto 0;max-width:32ch;text-align:center;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.cpl-pg .cpl-go{margin:32px 0 0}',
    '.cpl-go2{display:block;width:100%;min-height:52px;margin:30px 0 0;border:1.5px solid #0075E3;border-radius:999px;background:transparent;color:#0075E3;font:800 15.5px var(--font-body);cursor:pointer}body.dark .cpl-go2{border-color:#8CC6FF;color:#8CC6FF}',
    '.cpl-adesso{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;margin:30px 0 0;padding:16px;border-radius:20px;border:1.5px solid #8CC6FF;background:var(--card);text-align:left;cursor:pointer}',
    '.cpl-adesso-t{flex:1;min-width:0}.cpl-adesso b{display:block;font:800 15px var(--font-body);color:var(--navy)}.cpl-adesso small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}.cpl-adesso svg{flex:none;color:#0075E3}body.dark .cpl-adesso svg{color:#8CC6FF}',
    '.cpl-puls{flex:none;width:12px;height:12px;border-radius:50%;background:#E63946;box-shadow:0 0 0 0 rgba(230,57,70,.55);animation:cplPuls 1.6s infinite}@keyframes cplPuls{to{box-shadow:0 0 0 12px rgba(230,57,70,0)}}',
    '.cpl-num{display:flex;margin:30px 0 0;padding:14px 4px;border-radius:18px;border:1px solid var(--line)}.cpl-num > div{flex:1;min-width:0;text-align:center;padding:0 6px}.cpl-num > div + div{border-left:1px solid var(--line)}',
    '.cpl-num b{display:block;font:900 20px/1 var(--font-display);color:var(--navy)}.cpl-num small{display:block;margin-top:6px;font:600 12px/1.3 var(--font-body);color:var(--muted)}',
    '.cpl-porte{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:30px 0 0}',
    '.cpl-porta{position:relative;min-width:0;display:flex;flex-direction:column;align-items:flex-start;padding:18px 16px;border-radius:22px;border:1px solid var(--line);background:var(--card);text-align:left;cursor:pointer;box-shadow:0 4px 14px rgba(0,30,68,.05)}',
    '.cpl-porta > span{font-size:28px;line-height:1}.cpl-porta b{display:block;margin-top:14px;font:800 15.5px var(--font-body);color:var(--navy)}.cpl-porta small{display:block;margin-top:5px;font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    '.cpl-porta svg{position:absolute;right:14px;top:20px;color:#0075E3}body.dark .cpl-porta svg{color:#8CC6FF}',
    '.cpl-info h3{margin-left:44px!important;margin-right:44px!important;padding:0!important}',
    '.fl-tieni{position:fixed;inset:0;z-index:99980;background:rgba(0,8,20,.62);display:flex;align-items:flex-end;justify-content:center}',
    '.fl-tieni-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .fl-tieni-x{background:rgba(255,255,255,.1);color:#fff}',
    '.fl-tieni-f{position:relative;padding-top:34px!important;width:100%;max-width:520px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:26px 22px calc(22px + env(safe-area-inset-bottom));text-align:center}',
    '.fl-tieni-f > b{display:block;font:800 21px/1.3 var(--font-display,var(--font-body));color:var(--navy)}.fl-tieni-f p{margin:10px 0 22px;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.fl-tieni-b{position:relative;width:100%;overflow:hidden;padding:17px;border:0;border-radius:999px;background:#0E2350;color:#fff;font:800 16px var(--font-body);touch-action:none;-webkit-user-select:none;user-select:none}',
    '.fl-tieni-b i{position:absolute;left:0;top:0;bottom:0;width:0;background:#0075E3}.fl-tieni-b span{position:relative}',
    '.fl-tieni-f small{display:block;margin-top:10px;font:700 12.5px var(--font-body);color:var(--muted)}.fl-tieni-no{margin-top:8px;border:0;background:none;padding:10px;font:700 15px var(--font-body);color:var(--muted)}',
    'body.dark .fl-tieni-f{background:#12203A}body.dark .fl-tieni-f > b{color:#fff}',
    '.cpl-sez{margin:30px 4px 12px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);text-align:center}',
    '.cpl-riga{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:8px}body.dark .cpl-riga{background:#12203A;border-color:#22345A}',
    '.cpl-riga > div{flex:1;min-width:0}.cpl-riga b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-riga b{color:#fff}.cpl-riga small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-x{flex:none;width:36px;height:36px;padding:0;border-radius:50%;border:1px solid var(--line);background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}',
    '.cpl-giorni{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:2px 0 12px}.cpl-giorni::-webkit-scrollbar{display:none}',
    '.cpl-giorni button,.cpl-dur button,.cpl-att button,.cpl-scelte button{flex:none;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:9px 14px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}body.dark .cpl-giorni button,body.dark .cpl-dur button,body.dark .cpl-att button,body.dark .cpl-scelte button{background:#12203A;border-color:#22345A;color:#fff}',
    '.cpl-giorni button.on,.cpl-dur button.on,.cpl-att button.on,.cpl-scelte button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.cpl-dur{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}',
    '.cpl-passo{padding-top:6px}.cpl-passo .cpl-pass2-h{margin:0 0 26px;text-align:center}',
    '.cpl-scelto{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin:0 0 26px;padding:12px 16px;border:1.5px solid var(--line);border-radius:16px;background:var(--card,#fff);font:700 14.5px var(--font-body);color:var(--navy);cursor:pointer}.cpl-scelto span{color:#0075E3;text-decoration:underline;text-underline-offset:3px;font-weight:700}body.dark .cpl-scelto{background:#12203A;border-color:#22345A;color:#fff}body.dark .cpl-scelto span{color:#8CC6FF}',
    '.cpl-cal{border:1.5px solid var(--line);border-radius:22px;background:var(--card,#fff);padding:16px 14px 18px}body.dark .cpl-cal{background:#12203A;border-color:#22345A}',
    '.cpl-cal-m{display:flex;align-items:center;justify-content:space-between;margin:0 0 16px}.cpl-cal-m b{font:800 17px var(--font-display);color:var(--navy)}body.dark .cpl-cal-m b{color:#fff}',
    '.cpl-cal-m button{width:38px;height:38px;border:0;border-radius:50%;background:var(--bg);color:#0075E3;display:grid;place-items:center;cursor:pointer}.cpl-cal-m button.avanti svg{transform:scaleX(-1)}.cpl-cal-m button:disabled{opacity:.3;cursor:default}',
    '.cpl-cal-s,.cpl-cal-g{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;text-align:center}.cpl-cal-s{margin-bottom:8px}.cpl-cal-s i{font:700 12px var(--font-body);font-style:normal;color:var(--muted)}',
    '.cpl-cal-g span,.cpl-cal-g button{aspect-ratio:1;display:grid;place-items:center;border-radius:50%;font:700 15px var(--font-body)}.cpl-cal-g span.no{color:var(--muted);opacity:.45}',
    '.cpl-cal-g button{border:0;background:#E3F1FF;color:#0075E3;cursor:pointer}.cpl-cal-g button.oggi{box-shadow:inset 0 0 0 2px #0075E3}.cpl-cal-g button.on{background:#0075E3;color:#fff}body.dark .cpl-cal-g button{background:#1B2E52;color:#8CC6FF}body.dark .cpl-cal-g button.on{background:#0075E3;color:#fff}',
    '.cpl-dur2{display:flex;flex-direction:column;gap:12px}.cpl-dur2 button{padding:18px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);cursor:pointer}.cpl-dur2 b{font:800 17px var(--font-body);color:var(--navy)}.cpl-dur2 button.on{border-color:#0075E3;box-shadow:inset 0 0 0 1.5px #0075E3}body.dark .cpl-dur2 button{background:#12203A;border-color:#22345A}body.dark .cpl-dur2 b{color:#fff}',
    '.cpl-ore{display:flex;flex-direction:column;gap:10px;padding-bottom:20px}.cpl-ore button{display:flex;align-items:center;justify-content:center;gap:10px;min-height:54px;border:1.5px solid #8CC6FF;border-radius:14px;background:var(--card,#fff);cursor:pointer}.cpl-ore b{font:800 16px var(--font-body);color:#0075E3}.cpl-ore small{font:600 12.5px var(--font-body);color:var(--muted)}.cpl-ore button.qualcuno{border-color:#0075E3;box-shadow:inset 0 0 0 1px #0075E3}body.dark .cpl-ore button{background:#12203A;border-color:#2B4C7E}body.dark .cpl-ore b{color:#8CC6FF}',
    '.cpl-slot{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-height:300px;overflow-y:auto;margin-bottom:14px;padding:2px}',
    '.cpl-slot button{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;padding:10px 4px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px}body.dark .cpl-slot button{background:#12203A;border-color:#22345A}',
    '.cpl-slot b{font:800 15px var(--font-body);color:var(--navy)}body.dark .cpl-slot b{color:#fff}.cpl-slot small{font:600 10.5px var(--font-body);color:#D63384}',
    '.cpl-slot button.qualcuno{border-color:#FF8AC2}.cpl-slot button.on{background:#0075E3;border-color:#0075E3}.cpl-slot button.on b,.cpl-slot button.on small{color:#fff}',
    '.cpl-vuoto{grid-column:1/-1;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.cpl-imp{margin:0 0 14px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .cpl-imp{background:#12203A;border-color:#22345A}',
    '.cpl-imp summary{list-style:none;cursor:pointer;display:flex;flex-direction:column;gap:2px}.cpl-imp summary::-webkit-details-marker{display:none}.cpl-imp summary span{font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-imp summary span{color:#fff}.cpl-imp summary small{font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-l{margin:12px 2px 8px;font:700 13.5px var(--font-body);color:var(--navy)}body.dark .cpl-l{color:#fff}',
    '.cpl-att{display:flex;flex-wrap:wrap;gap:8px}',
    '.cpl-sw{display:flex;align-items:center;gap:12px;padding:12px 0 0}.cpl-sw > div{flex:1}.cpl-sw b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-sw b{color:#fff}.cpl-sw small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-compiti{display:flex;flex-direction:column;gap:8px;margin-bottom:16px}.cpl-comp{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:var(--bg,#F4F9FF)}body.dark .cpl-comp{background:#0F1B33}',
    '.cpl-comp span{flex:1;font:600 13.5px var(--font-body);color:var(--navy)}body.dark .cpl-comp span{color:#fff}.cpl-comp button{border:0;background:transparent;color:var(--muted);cursor:pointer}',
    '.cpl-stanza{position:fixed;inset:0;background:#06142B;color:#fff;overflow:hidden}',
    '.cpl-v-altro{position:absolute;inset:0}.cpl-v-altro video{width:100%;height:100%;object-fit:cover;background:#06142B}',
    '.cpl-v-vuoto{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:radial-gradient(120% 90% at 50% 20%,#1E3366,#06142B 70%)}.cpl-v-vuoto[hidden]{display:none}.cpl-v-vuoto b{font:700 15px var(--font-body);color:#D7E8FF;text-align:center;padding:0 30px}',
    '.cpl-av{width:84px;height:84px;border-radius:50%;display:grid;place-items:center;font:900 34px var(--font-display);color:#fff;background:linear-gradient(135deg,#FF8AC2,#5BC0F8)}.cpl-av.piccolo{width:38px;height:38px;font-size:16px;flex:none}',
    '.cpl-v-mio{position:absolute;right:14px;top:calc(env(safe-area-inset-top,0px) + 70px);width:96px;height:132px;border-radius:16px;object-fit:cover;background:#0F1B33;border:2px solid rgba(255,255,255,.4);z-index:3;transform:scaleX(-1)}',
    '.cpl-alto{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 14px);display:flex;flex-direction:column;align-items:center;z-index:3;text-shadow:0 2px 10px rgba(0,0,0,.5)}.cpl-alto b{font:900 34px var(--font-display)}.cpl-alto small{font:700 13px var(--font-body);color:#D7E8FF}',
    '.cpl-pannello{position:absolute;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom,0px) + 92px);max-height:38%;overflow-y:auto;z-index:3;padding:12px 14px;border-radius:18px;background:rgba(6,20,43,.72);backdrop-filter:blur(10px)}',
    '.cpl-pl{margin:4px 0 6px;font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#BCE0FF}',
    '.cpl-ck{display:flex;align-items:center;gap:10px;padding:6px 0;font:600 14px var(--font-body);color:#fff}.cpl-ck input{width:20px;height:20px;accent-color:#0075E3}.cpl-ck.altro i{width:20px;height:20px;border-radius:6px;border:2px solid #BCE0FF;display:grid;place-items:center;font-style:normal;font-size:12px}.cpl-ck.fatto span{text-decoration:line-through;opacity:.7}',
    '.cpl-st-in{width:100%;margin:6px 0;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#fff;border-radius:12px;padding:9px 12px;font:600 13.5px var(--font-body)}.cpl-st-in::placeholder{color:#9FB8E6}',
    '.cpl-pv{margin:0;font:500 13px var(--font-body);color:#9FB8E6}',
    '.cpl-assente{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;padding:12px;border-radius:14px;background:rgba(255,111,168,.16);text-align:center}.cpl-assente b{font:800 14px var(--font-body)}.cpl-assente .am-link{color:#BCE0FF}',
    '.cpl-ctl{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 22px);display:flex;justify-content:center;gap:18px;z-index:3}',
    '.cpl-ctl button{width:58px;height:58px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;display:grid;place-items:center;cursor:pointer;backdrop-filter:blur(8px)}.cpl-ctl .cpl-esci{background:#E63946}',
    '.cpl-scelte{display:flex;flex-wrap:wrap;gap:8px}',
    '.cpl-start[hidden]{display:none!important}.cpl-start{margin:28px 0 28px;padding:18px 16px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .cpl-start{background:#12203A;border-color:#22345A}',
    '.cpl-start{background:linear-gradient(180deg,#C8EFFD 0%,#F0FBFF 100%)!important;border:1px solid #BCE0FF!important;padding:24px 16px 16px!important}.cpl-start-in2{text-align:center;margin-bottom:32px}.cpl-start-ico2{display:block;font-size:40px;line-height:1;margin-bottom:12px}.cpl-start-in2 b{display:block;font:800 19px var(--font-display);color:#001E44}.cpl-start-in2 p{margin:8px auto 0;max-width:28ch;font:500 14.5px/1.45 var(--font-body);color:#33476A}',
    '.cpl-start-r{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;margin:0 0 10px;padding:14px;border-radius:18px;border:0;background:#fff;text-align:left;cursor:pointer;box-shadow:0 2px 10px rgba(0,30,68,.06);color:#001E44}.cpl-start-r:last-child{margin-bottom:0}.cpl-start-r > span{flex:none;width:42px;height:42px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:21px;background:#F0FBFF}.cpl-start-r > div{flex:1;min-width:0}.cpl-start-r b{display:block;font:800 15.5px var(--font-body);color:#001E44}.cpl-start-r small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:#5B6B86}.cpl-start-r svg{flex:none;color:#0075E3}',
    'body.dark .cpl-start{background:linear-gradient(180deg,#1A3C6E,#12264C)!important;border-color:#2C4170!important}body.dark .cpl-start-in2 b{color:#fff}body.dark .cpl-start-in2 p{color:#D6E8FF}body.dark .cpl-start-r{background:#0E1D3D;color:#fff}body.dark .cpl-start-r b{color:#fff}body.dark .cpl-start-r small{color:#9FB3D1}body.dark .cpl-start-r > span{background:#12264C}body.dark .cpl-start-r svg{color:#8CC6FF}',
    /* 0.9.358, Andrea: "Lavora in compagnia e' uguale a Protezione dello slancio subito sotto: sono uno sotto l'altro e si contendono
       l'attenzione, non c'e' gerarchia visiva. Ogni pannello di un colore diverso, che si alterna, sempre con i colori del brand".
       In START adesso si alternano tre fondi: questo con il gradiente del brand (lo stesso della card "Concentrarsi e' piu' facile
       in due" degli Amici: in coppia si riconosce dal colore), Protezione dello slancio azzurro chiaro, Suoni blu notte.
       Il gradiente non cambia col tema: titolo e frase restano blu notte anche in scuro. */
    '.cpl-start,body.dark .cpl-start{background:var(--dream) padding-box,linear-gradient(135deg,#E63946 0%,#0075E3 100%) border-box!important;border:2px solid transparent!important;box-shadow:0 12px 28px rgba(0,30,68,.12)}',
    '.cpl-start-in2 b,body.dark .cpl-start-in2 b{color:#001E44}.cpl-start-in2 p,body.dark .cpl-start-in2 p{color:#33476A}',
    '.cpl-start-r{box-shadow:0 6px 16px rgba(0,30,68,.12)}',
    /* 0.9.353: la stella dei preferiti nei colori del brand (niente giallo) */
    '.cpl-stella{width:40px;height:40px;border-radius:20px;border:1px solid var(--line);background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}.cpl-stella.on{color:#0075E3;border-color:#0075E3}.cpl-stella.on svg{fill:#0075E3}body.dark .cpl-stella.on{color:#8CC6FF;border-color:#8CC6FF}body.dark .cpl-stella.on svg{fill:#8CC6FF}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
