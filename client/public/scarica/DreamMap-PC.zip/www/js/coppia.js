/* ===========================================================================================
   LE SESSIONI IN COPPIA (0.9.285) — come Focusmate

   Andrea: "voglio replicare le stesse funzioni di Focusmate". Dal codice della loro app:
     - si prenota una sessione di 25, 50 o 75 minuti che comincia a un quarto d'ora preciso;
     - si sceglie il tipo di lavoro (alla scrivania, in movimento, qualsiasi), il silenzio (niente
       microfono) e se preferire le persone preferite; si scrivono i compiti della sessione;
     - l'app trova il compagno (il server: focuslockCompagni.ts, stessa ora e stessa durata);
     - all'ora giusta si entra nella stanza: il video da telefono a telefono, il tempo, i compiti di
       tutti e due; se il compagno non arriva, se ne trova un altro rimasto da solo;
     - alla fine: com'e' andata e com'era la chiamata; le persone, i preferiti, i numeri.
   La prenotazione entra nel calendario di DreamMap con la Chiamata dei sogni all'inizio: e' cosi'
   che il telefono ti avvisa. Se il video non si collega (certe reti dei telefoni), la stanza resta:
   la presenza dell'altro, il tempo e i suoi compiti si aggiornano ogni pochi secondi.
   =========================================================================================== */
const CPL = { agenda: null, giorno: 0, durata: 50, slot: 0, att: 'scrivania', silenzio: false, preferiti: true, compiti: [], stanza: null, pc: null, loc: null, segn: 0, poll: 0, batt: 0, tick: 0, mic: true, cam: true, coda: [], persone: null, fine: null };
const CPL_ATT = [['scrivania', 'Alla scrivania', '💻'], ['movimento', 'In movimento', '🚶'], ['qualsiasi', 'Qualsiasi', '🔀']];
const CPL_DUR = [25, 50, 75];
const CPL_CAL_K = 'fl_coppia_cal';      // { <id prenotazione>: <id evento del calendario> }
const CPL_STORIA_K = 'fl_coppia_storia'; // [{ id, slotAt, durata, esito, nome }] le sessioni fatte (le legge il patto)
const CPL_I = {
  indietro: '<path d="M15 18l-6-6 6-6"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  micOff: '<path d="M3 3l18 18"/><path d="M9 9v2a3 3 0 0 0 5 2.2M15 9.3V6a3 3 0 0 0-5.6-1.5"/><path d="M5 11a7 7 0 0 0 11 5.7M19 11a7 7 0 0 1-.4 2.3M12 18v3"/>',
  cam: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3z"/>',
  camOff: '<path d="M3 3l18 18"/><path d="M10.5 6H14a2 2 0 0 1 2 2v3.5l5-3v10M16 16a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2"/>',
  esci: '<path d="M10 17l5-5-5-5"/><path d="M15 12H3M21 3v18"/>',
  stella: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'
};
function cplIco(n, px){ return '<svg viewBox="0 0 24 24" width="' + (px || 20) + '" height="' + (px || 20) + '" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (CPL_I[n] || '') + '</svg>'; }
function cplEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function cplJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function cplScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function cplPuo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.accountApi === 'function'; }
async function cplApi(method, path, body){
  if (!cplPuo()) throw new Error('Le sessioni in coppia funzionano nell’app sul telefono');
  return NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
}
function cplOra(ms){ const d = new Date(ms); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function cplGiornoTxt(ms){
  const d = new Date(ms), oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const g = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - oggi.getTime()) / 86400000);
  if (g === 0) return 'Oggi'; if (g === 1) return 'Domani';
  return d.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' }).replace(/^./, function(c){ return c.toUpperCase(); });
}
function cplNome(){ try{ const p = JSON.parse(localStorage.getItem('fl_profilo') || '{}') || {}; if (p.nome) return String(p.nome); }catch(_){ } try{ if (typeof nvNome === 'function' && nvNome()) return nvNome(); }catch(_){ } return ''; }
function cplTopbar(titolo, indietro){ return '<div class="topbar"><button class="iconbtn" onclick="' + (indietro || 'flIndietro()') + '" aria-label="Indietro">' + cplIco('indietro', 22) + '</button><b class="blk-title">' + titolo + '</b></div>'; }

registerScreen('s-coppia', cplTopbar('Sessioni in coppia') + '<div id="cplBody"></div><div class="spacer"></div>');
registerScreen('s-coppia-prenota', cplTopbar('Prenota una sessione') + '<div id="cplPren"></div><div class="spacer"></div>');
registerScreen('s-coppia-persone', cplTopbar('Le persone') + '<div id="cplPers"></div><div class="spacer"></div>');
registerScreen('s-coppia-stanza', '<div id="cplStanza" class="cpl-stanza"></div>', { back: function(){ cplEsciChiedi(); return null; } });
registerScreen('s-coppia-fine', cplTopbar('Com’è andata?', 'cplFineSalta()') + '<div id="cplFine"></div><div class="spacer"></div>');

/* ---------------------------------------------------------------------------------------
   LA PAGINA: la prossima sessione, "unisciti adesso", prenota, le persone, i numeri
   --------------------------------------------------------------------------------------- */
async function cplApri(){ goId('s-coppia'); cplPaint(); await cplCarica(); cplPaint(); }
async function cplCarica(){
  try{ CPL.agenda = await cplApi('GET', '/api/focuslock/fm/agenda'); }catch(e){ CPL.agenda = { errore: String((e && e.message) || e) }; }
  try{ const p = await cplApi('GET', '/api/focuslock/fm/persone'); CPL.persone = p; }catch(_){ }
  try{ cplCalendarioAllinea(); }catch(_){ }
}
function cplProssima(){
  const a = CPL.agenda; if (!a || !a.mie) return null;
  const ora = Date.now();
  return a.mie.filter(function(s){ return s.stato !== 'annullata' && s.slotAt + s.durata * 60000 > ora && !s.esito; })[0] || null;
}
function cplPaint(){
  const host = document.getElementById('cplBody'); if (!host) return;
  if (!cplPuo()){ host.innerHTML = '<p class="cpl-intro">Le sessioni in coppia funzionano nell’app sul telefono, con il tuo account Google.</p>'; return; }
  const a = CPL.agenda;
  if (!a){ host.innerHTML = '<p class="cpl-intro">Lavori in video con un’altra persona: vi dite cosa farete e lo fate insieme.</p><p class="cpl-carica">Carico le tue sessioni…</p>'; return; }
  if (a.errore){ host.innerHTML = '<p class="cpl-intro">Non riesco a leggere le sessioni: ' + cplEsc(a.errore) + '</p><button type="button" class="am-cta" onclick="cplApri()">Riprova</button>'; return; }
  const p = cplProssima();
  let html = '<p class="cpl-intro">Lavori in video con un’altra persona: <b>vi dite cosa farete e lo fate insieme.</b></p>';
  if (p){
    const ora = Date.now(), apre = p.slotAt - 5 * 60000;
    const comp = p.compagno;
    html += '<div class="cpl-pross"><small>' + cplEsc(cplGiornoTxt(p.slotAt)) + ' · ' + cplOra(p.slotAt) + ' · ' + p.durata + ' minuti</small>'
      + '<b>' + (comp ? 'Con ' + cplEsc(comp.nome) : 'Cerco il tuo compagno') + '</b>'
      + '<p>' + (comp ? (comp.silenzio ? 'Lavora in silenzio, senza microfono.' : 'Vi vedete in video e vi dite cosa farete.') : 'Appena qualcuno prenota la stessa ora, lo trovi qui.') + '</p>'
      + (ora >= apre ? '<button type="button" class="am-cta" onclick="cplEntra(' + p.id + ')">Entra nella stanza</button>' : '<p class="cpl-apre">La stanza apre alle ' + cplOra(apre) + '</p>')
      + '<button type="button" class="am-link" onclick="cplAnnulla(' + p.id + ')">Annulla la sessione</button></div>';
  }
  const adesso = (a.aspettano || []).filter(function(x){ return x.slotAt <= Date.now() + 10 * 60000 && x.slotAt >= Date.now() - 5 * 60000; })[0];
  if (adesso && (!p || p.slotAt !== adesso.slotAt)) html += '<button type="button" class="cpl-adesso" onclick="cplUnisciti(' + adesso.slotAt + ',' + adesso.durata + ')"><span class="cpl-puls"></span><span><b>' + (adesso.n === 1 ? 'Una persona comincia' : adesso.n + ' persone cominciano') + ' alle ' + cplOra(adesso.slotAt) + '</b><small>Lavora con lei per ' + adesso.durata + ' minuti</small></span></button>';
  html += '<button type="button" class="am-cta cpl-prenota" onclick="cplPrenotaApri()">Prenota una sessione</button>';
  const n = (CPL.persone && CPL.persone.numeri) || null;
  if (n) html += '<div class="cpl-numeri"><div><b>' + n.sessioni + '</b><small>sessioni fatte</small></div><div><b>' + n.settimana + '</b><small>questa settimana</small></div><div><b>' + n.serie + '</b><small>giorni di fila</small></div></div>';
  const future = (a.mie || []).filter(function(s){ return s !== p && s.slotAt > Date.now() && s.stato !== 'annullata'; });
  if (future.length) html += '<p class="cpl-sez">Le altre sessioni prenotate</p>' + future.map(function(s){ return '<div class="cpl-riga"><div><b>' + cplEsc(cplGiornoTxt(s.slotAt)) + ' · ' + cplOra(s.slotAt) + '</b><small>' + s.durata + ' minuti · ' + (s.compagno ? 'con ' + cplEsc(s.compagno.nome) : 'compagno da trovare') + '</small></div><button type="button" class="cpl-x" onclick="cplAnnulla(' + s.id + ')" aria-label="Annulla la sessione">✕</button></div>'; }).join('');
  html += '<button type="button" class="cpl-entra-riga" onclick="cplPersoneApri()"><span>👥</span><span><b>Le persone</b><small>Chi ha lavorato con te, e i tuoi preferiti</small></span><span class="chev"></span></button>';
  html += '<button type="button" class="cpl-entra-riga" onclick="if(typeof patApri===\'function\')patApri()"><span>🤝</span><span><b>Il patto con il tuo Dreambrother</b><small>Un’abitudine, un garante, e i soldi che partono da soli se manchi</small></span><span class="chev"></span></button>';
  host.innerHTML = html;
}
async function cplAnnulla(id){
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Annullare la sessione?', 'Il tuo compagno ne trova un altro alla stessa ora.', 'Annulla la sessione', true); }catch(_){ }
  if (!ok) return;
  try{ await cplApi('POST', '/api/focuslock/fm/annulla', { id: id }); }catch(e){ toast('Non sono riuscito ad annullarla'); return; }
  cplCalTogli(id);
  toast('Sessione annullata');
  await cplCarica(); cplPaint();
}
async function cplUnisciti(slotAt, durata){
  CPL.slot = slotAt; CPL.durata = durata;
  await cplPrenota();
}

/* ---------------------------------------------------------------------------------------
   PRENOTA: il giorno, la durata, l'ora (con chi aspetta), le impostazioni, i compiti
   --------------------------------------------------------------------------------------- */
function cplPrenotaApri(){ CPL.giorno = 0; CPL.slot = 0; CPL.compiti = []; goId('s-coppia-prenota'); cplPrenPaint(); }
function cplSlotDelGiorno(g){
  const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + g);
  const inizio = d.getTime(), fine = inizio + 86400000;
  const Q = 15 * 60000;
  let t = Math.max(inizio, Math.ceil((Date.now() - 4 * 60000) / Q) * Q);
  const out = [];
  for (; t < fine; t += Q) out.push(t);
  return out;
}
function cplAspettano(t, durata){ const l = (CPL.agenda && CPL.agenda.aspettano) || []; const x = l.filter(function(a){ return a.slotAt === t && a.durata === durata; })[0]; return x ? x.n : 0; }
function cplPrenPaint(){
  const host = document.getElementById('cplPren'); if (!host) return;
  const giorni = [];
  for (let g = 0; g < 7; g++){ const d = new Date(); d.setDate(d.getDate() + g); giorni.push([g, g === 0 ? 'Oggi' : g === 1 ? 'Domani' : d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric' })]); }
  const slot = cplSlotDelGiorno(CPL.giorno);
  if (CPL.slot && slot.indexOf(CPL.slot) < 0) CPL.slot = 0;
  const att = CPL_ATT.filter(function(a){ return a[0] === CPL.att; })[0] || CPL_ATT[0];
  host.innerHTML = '<div class="cpl-giorni">' + giorni.map(function(g){ return '<button type="button" class="' + (g[0] === CPL.giorno ? 'on' : '') + '" onclick="CPL.giorno=' + g[0] + ';CPL.slot=0;cplPrenPaint()">' + cplEsc(g[1]) + '</button>'; }).join('') + '</div>'
    + '<div class="cpl-dur" role="tablist">' + CPL_DUR.map(function(m){ return '<button type="button" class="' + (m === CPL.durata ? 'on' : '') + '" onclick="CPL.durata=' + m + ';cplPrenPaint()">' + m + ' minuti</button>'; }).join('') + '</div>'
    + '<div class="cpl-slot">' + (slot.length ? slot.map(function(t){
        const n = cplAspettano(t, CPL.durata);
        return '<button type="button" class="' + (t === CPL.slot ? 'on' : '') + (n ? ' qualcuno' : '') + '" onclick="CPL.slot=' + t + ';cplPrenPaint()"><b>' + cplOra(t) + '</b>' + (n ? '<small>' + (n === 1 ? 'una persona aspetta' : n + ' persone aspettano') + '</small>' : '') + '</button>';
      }).join('') : '<p class="cpl-vuoto">Per oggi le ore sono finite: scegli un altro giorno.</p>') + '</div>'
    + '<details class="cpl-imp"><summary><span>Impostazioni della sessione</span><small>' + att[2] + ' ' + cplEsc(att[1]) + (CPL.silenzio ? ' · in silenzio' : '') + (CPL.preferiti ? ' · prima i preferiti' : '') + '</small></summary>'
    +   '<p class="cpl-l">Che lavoro fai</p><div class="cpl-att">' + CPL_ATT.map(function(a){ return '<button type="button" class="' + (a[0] === CPL.att ? 'on' : '') + '" onclick="CPL.att=\'' + a[0] + '\';cplPrenPaint();this.closest(\'details\')&&(document.querySelector(\'.cpl-imp\').open=true)">' + a[2] + ' ' + cplEsc(a[1]) + '</button>'; }).join('') + '</div>'
    +   '<div class="cpl-sw"><div><b>In silenzio</b><small>Senza microfono: vi vedete e basta.</small></div><button type="button" class="switch' + (CPL.silenzio ? ' on' : '') + '" onclick="CPL.silenzio=!CPL.silenzio;this.classList.toggle(\'on\',CPL.silenzio)" aria-label="In silenzio"></button></div>'
    +   '<div class="cpl-sw"><div><b>Prima i miei preferiti</b><small>Se uno dei tuoi preferiti prenota la stessa ora, lavori con lui.</small></div><button type="button" class="switch' + (CPL.preferiti ? ' on' : '') + '" onclick="CPL.preferiti=!CPL.preferiti;this.classList.toggle(\'on\',CPL.preferiti)" aria-label="Prima i miei preferiti"></button></div>'
    +   '<div class="cpl-sw"><div><b>Chiamami all’inizio</b><small>La Chiamata dei sogni all’ora della sessione. Spenta: ti avvisa il calendario.</small></div><button type="button" class="switch' + (cplChiamataOn() ? ' on' : '') + '" onclick="cplChiamataCambia(this)" aria-label="Chiamami all\'inizio"></button></div>'
    + '</details>'
    + '<p class="cpl-l">Cosa farai in questa sessione?</p>'
    + '<div class="cpl-compiti">' + CPL.compiti.map(function(c, i){ return '<div class="cpl-comp"><span>' + cplEsc(c.t) + '</span><button type="button" onclick="CPL.compiti.splice(' + i + ',1);cplPrenPaint()" aria-label="Togli">✕</button></div>'; }).join('')
    +   (CPL.compiti.length < 3 ? '<input id="cplCompIn" class="fin" placeholder="Aggiungi un compito, poi premi invio" onkeydown="if(event.key===\'Enter\'){event.preventDefault();cplCompAggiungi()}" onblur="cplCompAggiungi()">' : '') + '</div>'
    + '<button type="button" class="am-cta" ' + (CPL.slot ? '' : 'disabled') + ' onclick="cplPrenota()">' + (CPL.slot ? 'Prenota alle ' + cplOra(CPL.slot) + ' (' + CPL.durata + ' minuti)' : 'Scegli un’ora') + '</button>';
}
function cplCompAggiungi(){
  const i = document.getElementById('cplCompIn'); const v = i ? i.value.trim() : '';
  if (!v) return;
  CPL.compiti.push({ t: v.slice(0, 140), fatto: false }); cplPrenPaint();
  setTimeout(function(){ const j = document.getElementById('cplCompIn'); if (j) j.focus(); }, 30);
}
/* 0.9.289, Andrea: "alle 23:45 mi e' arrivata la Chiamata dei sogni per una sessione in coppia che non ricordo di aver
   prenotato". Un tocco su "Prenota alle..." (o su "Unisciti") prenotava subito e metteva SEMPRE la chiamata. Adesso:
   - prima di prenotare un foglio dice giorno, ora e durata, e si conferma TENENDO PREMUTO (un tocco per sbaglio non basta);
   - la chiamata all'inizio parte solo se e' accesa "Chiamami all'inizio" (di serie spenta): altrimenti c'e' il
     promemoria del calendario del telefono. */
function cplChiamataOn(){ try{ return localStorage.getItem('fl_coppia_chiamata') === '1'; }catch(_){ return false; } }
function cplChiamataCambia(b){ const on = !cplChiamataOn(); try{ localStorage.setItem('fl_coppia_chiamata', on ? '1' : '0'); }catch(_){ } if (b) b.classList.toggle('on', on); try{ flVibra(8); }catch(_){ } }
function flTieniConferma(titolo, testo, etichetta){
  return new Promise(function(fatto){
    let w = document.getElementById('flTieni'); if (w) w.remove();
    w = document.createElement('div'); w.id = 'flTieni'; w.className = 'fl-tieni';
    w.innerHTML = '<div class="fl-tieni-f"><button type="button" class="fl-tieni-x" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button><b>' + cplEsc(titolo) + '</b><p>' + cplEsc(testo) + '</p>'
      + '<button type="button" class="fl-tieni-b"><i></i><span>' + cplEsc(etichetta) + '</span></button><small>Tieni premuto per confermare</small>'
      + '<button type="button" class="fl-tieni-no">Annulla</button></div>';
    document.body.appendChild(w);
    const chiudi = function(v){ w.remove(); fatto(v); };
    w.addEventListener('click', function(e){ if (e.target === w) chiudi(false); });
    w.querySelector('.fl-tieni-no').onclick = function(){ chiudi(false); };
    w.querySelector('.fl-tieni-x').onclick = function(){ chiudi(false); };
    const b = w.querySelector('.fl-tieni-b'), barra = b.querySelector('i');
    let t0 = 0, raf = 0;
    const giro = function(){ const q = Math.min(1, (performance.now() - t0) / 1000); barra.style.width = (q * 100) + '%'; if (q >= 1){ try{ flVibra([10, 30, 20]); }catch(_){ } chiudi(true); return; } raf = requestAnimationFrame(giro); };
    const via = function(e){ e.preventDefault(); t0 = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(giro); try{ flVibra(6); }catch(_){ } };
    const stop = function(){ cancelAnimationFrame(raf); raf = 0; barra.style.transition = 'width .25s'; barra.style.width = '0'; setTimeout(function(){ barra.style.transition = ''; }, 260); };
    b.addEventListener('pointerdown', via); b.addEventListener('pointerup', stop); b.addEventListener('pointerleave', stop); b.addEventListener('pointercancel', stop);
    b.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  });
}
async function cplPrenota(){
  if (!CPL.slot) return;
  cplCompAggiungi();
  const quando = cplGiornoTxt(CPL.slot) + ' alle ' + cplOra(CPL.slot);
  const ok = await flTieniConferma('Prenoti una sessione in coppia?', quando + ', per ' + CPL.durata + ' minuti. ' + (cplChiamataOn() ? 'All’inizio ti arriva la Chiamata dei sogni.' : 'All’inizio ti avvisa il calendario del telefono.'), 'Prenota ' + quando.charAt(0).toLowerCase() + quando.slice(1));
  if (!ok) return;
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/prenota', { slotAt: CPL.slot, durata: CPL.durata, attivita: CPL.att, silenzio: CPL.silenzio, preferiti: CPL.preferiti, compiti: CPL.compiti, nome: cplNome() }); }
  catch(e){ toast(/gia' una sessione|409/.test(String(e && e.message)) ? 'A quell’ora hai già una sessione' : 'Non sono riuscito a prenotare: riprova'); return; }
  const s = r && r.sessione;
  if (s) cplCalMetti(s);
  try{ flVibra([10, 30, 10]); }catch(_){ }
  const avviso = cplChiamataOn() ? 'All’inizio ti chiamo' : 'All’inizio ti avvisa il calendario';
  toast(s && s.compagno ? 'Prenotata con ' + s.compagno.nome + '. ' + avviso : 'Prenotata: appena trovo il tuo compagno lo vedi qui. ' + avviso);
  CPL.compiti = []; CPL.slot = 0;
  goId('s-coppia'); await cplCarica(); cplPaint();
}

/* ---- il calendario: la sessione entra con la Chiamata dei sogni all'inizio (e' il promemoria) ---- */
function cplCalMetti(s){
  if (typeof calSalvaEvento !== 'function') return;
  const m = cplJ(CPL_CAL_K, {}) || {};
  const titolo = 'Sessione in coppia' + (s.compagno ? ' con ' + s.compagno.nome : '');
  const descr = (s.compiti || []).map(function(c){ return '• ' + c.t; }).join('\n');
  const ev = calSalvaEvento({ id: m[s.id] || undefined, titolo: titolo, inizio: s.slotAt, fine: s.slotAt + s.durata * 60000, descr: descr, colore: '#FF6FA8', chiamata: cplChiamataOn() });
  if (ev && ev.id){ m[s.id] = ev.id; cplScrivi(CPL_CAL_K, m); }
}
function cplCalTogli(id){
  const m = cplJ(CPL_CAL_K, {}) || {};
  if (m[id] && typeof calEliminaEvento === 'function') calEliminaEvento(m[id]);
  delete m[id]; cplScrivi(CPL_CAL_K, m);
}
/* il compagno trovato dopo: il titolo dell'evento lo dice */
function cplCalendarioAllinea(){
  const a = CPL.agenda; if (!a || !a.mie || typeof calEventi !== 'function') return;
  const m = cplJ(CPL_CAL_K, {}) || {};
  a.mie.forEach(function(s){
    if (!m[s.id]) return;
    const ev = calEventi().filter(function(e){ return e.id === m[s.id]; })[0];
    const titolo = 'Sessione in coppia' + (s.compagno ? ' con ' + s.compagno.nome : '');
    if (ev && ev.titolo !== titolo) cplCalMetti(s);
  });
}

/* ---------------------------------------------------------------------------------------
   LA STANZA: il video, il tempo, i compiti di tutti e due
   --------------------------------------------------------------------------------------- */
async function cplEntra(id){
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/entra', { id: id }); }
  catch(e){ toast(/cinque minuti/.test(String(e && e.message)) ? 'La stanza apre cinque minuti prima' : 'Non riesco a entrare nella stanza'); return; }
  CPL.stanza = r; CPL.segn = 0; CPL.coda = []; CPL.mic = !(r.sessione && r.sessione.silenzio); CPL.cam = true; CPL.collegato = false; CPL.entratoAt = Date.now();
  CPL.compiti = (r.sessione && r.sessione.compiti) || [];
  goId('s-coppia-stanza');
  try{ flSchermoAcceso('coppia', true); }catch(_){ }
  cplStanzaPaint();
  cplVideo();
  clearInterval(CPL.batt); CPL.batt = setInterval(cplBattito, 5000);
  clearInterval(CPL.tick); CPL.tick = setInterval(cplTempo, 1000);
}
function cplStanzaPaint(){
  const host = document.getElementById('cplStanza'); if (!host || !CPL.stanza) return;
  const s = CPL.stanza.sessione, c = s.compagno;
  host.innerHTML = '<div class="cpl-v-altro"><video id="cplVAltro" autoplay playsinline></video><div class="cpl-v-vuoto" id="cplVVuoto"><span class="cpl-av">' + cplEsc(((c && c.nome) || '?').charAt(0).toUpperCase()) + '</span><b id="cplStato">' + (c ? (c.presente ? cplEsc(c.nome) + ' è nella stanza' : 'Aspetto ' + cplEsc(c.nome)) : 'Cerco il tuo compagno') + '</b></div></div>'
    + '<video id="cplVMio" class="cpl-v-mio" autoplay playsinline muted></video>'
    + '<div class="cpl-alto"><b id="cplTempo">--:--</b><small id="cplNome">' + (c ? cplEsc(c.nome) + (c.silenzio ? ' · in silenzio' : '') : '') + '</small></div>'
    + '<div class="cpl-pannello" id="cplPannello"></div>'
    + '<div class="cpl-ctl"><button type="button" id="cplMic" onclick="cplMic()" aria-label="Microfono">' + cplIco(CPL.mic ? 'mic' : 'micOff', 22) + '</button>'
    + '<button type="button" id="cplCam" onclick="cplCam()" aria-label="Videocamera">' + cplIco(CPL.cam ? 'cam' : 'camOff', 22) + '</button>'
    + '<button type="button" class="cpl-esci" onclick="cplEsciChiedi()" aria-label="Esci dalla sessione">' + cplIco('esci', 22) + '</button></div>';
  cplPannelloPaint();
  if (CPL.loc){ const v = document.getElementById('cplVMio'); if (v) v.srcObject = CPL.loc; }
  if (CPL.remoto){ const v = document.getElementById('cplVAltro'); if (v){ v.srcObject = CPL.remoto; document.getElementById('cplVVuoto').hidden = true; } }
}
function cplPannelloPaint(){
  const p = document.getElementById('cplPannello'); if (!p || !CPL.stanza) return;
  const c = CPL.stanza.sessione.compagno;
  p.innerHTML = '<p class="cpl-pl">I tuoi compiti</p>'
    + CPL.compiti.map(function(x, i){ return '<label class="cpl-ck"><input type="checkbox" ' + (x.fatto ? 'checked' : '') + ' onchange="CPL.compiti[' + i + '].fatto=this.checked;cplBattito(true)"><span>' + cplEsc(x.t) + '</span></label>'; }).join('')
    + (CPL.compiti.length < 8 ? '<input id="cplStCompIn" class="cpl-st-in" placeholder="Aggiungi un compito" onkeydown="if(event.key===\'Enter\'){event.preventDefault();cplStComp()}">' : '')
    + (c ? '<p class="cpl-pl">I compiti di ' + cplEsc(c.nome) + '</p>' + ((c.compiti || []).length ? c.compiti.map(function(x){ return '<div class="cpl-ck altro' + (x.fatto ? ' fatto' : '') + '"><i>' + (x.fatto ? '✓' : '') + '</i><span>' + cplEsc(x.t) + '</span></div>'; }).join('') : '<p class="cpl-pv">Ancora nessun compito scritto.</p>') : '');
}
function cplStComp(){ const i = document.getElementById('cplStCompIn'); const v = i ? i.value.trim() : ''; if (!v) return; CPL.compiti.push({ t: v.slice(0, 140), fatto: false }); cplPannelloPaint(); cplBattito(true); }
function cplTempo(){
  if (!CPL.stanza) return;
  const s = CPL.stanza.sessione, ora = Date.now();
  const inizio = s.slotAt, fine = s.slotAt + s.durata * 60000;
  const el = document.getElementById('cplTempo');
  const mmss = function(ms){ const t = Math.max(0, Math.round(ms / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  if (el) el.textContent = ora < inizio ? 'Comincia fra ' + mmss(inizio - ora) : mmss(fine - ora);
  /* il compagno non e' arrivato cinque minuti dopo l'inizio: se ne cerca un altro */
  const c = s.compagno;
  if (ora > inizio + 5 * 60000 && (!c || !c.dentro) && !CPL.offertoAltro){ CPL.offertoAltro = true; cplNonArrivato(); }
  if (ora >= fine){ cplChiudiStanza(); cplFineApri(); }
}
function cplNonArrivato(){
  const host = document.getElementById('cplPannello'); if (!host) return;
  const c = CPL.stanza && CPL.stanza.sessione.compagno;
  host.insertAdjacentHTML('afterbegin', '<div class="cpl-assente"><b>' + (c ? cplEsc(c.nome) + ' non è arrivato' : 'Nessun compagno, per ora') + '</b><button type="button" class="am-cta" onclick="cplRiabbina()">Trova un altro compagno</button><button type="button" class="am-link" onclick="this.parentElement.remove()">Lavoro da solo</button></div>');
}
async function cplRiabbina(){
  try{
    const r = await cplApi('POST', '/api/focuslock/fm/riabbina', { id: CPL.stanza.sessione.id });
    if (r && r.ok){ toast('Trovato: entro di nuovo nella stanza'); const id = CPL.stanza.sessione.id; cplChiudiStanza(true); setTimeout(function(){ cplEntra(id); }, 400); }
    else toast('Adesso non c’è nessun altro: lavora da solo, il tempo continua');
  }catch(_){ toast('Non sono riuscito a cercare un altro compagno'); }
}
async function cplBattito(conCompiti){
  if (!CPL.stanza) return;
  let r;
  try{ r = await cplApi('POST', '/api/focuslock/fm/battito', Object.assign({ id: CPL.stanza.sessione.id }, conCompiti ? { compiti: CPL.compiti } : {})); }catch(_){ return; }
  if (!r || !r.sessione || !CPL.stanza) return;
  const prima = CPL.stanza.sessione.compagno;
  CPL.stanza.sessione.compagno = r.sessione.compagno;
  CPL.stanza.sessione.stanza = r.sessione.stanza;
  const c = r.sessione.compagno;
  const st = document.getElementById('cplStato');
  if (st && c) st.textContent = c.presente ? c.nome + ' è nella stanza' : 'Aspetto ' + c.nome;
  const nm = document.getElementById('cplNome'); if (nm && c) nm.textContent = c.nome + (c.silenzio ? ' · in silenzio' : '');
  /* un compagno nuovo (trovato dopo): si ricollega il video con la sua stanza */
  if (c && (!prima || prima.id !== c.id) && r.sessione.stanza && !CPL.pc){ CPL.stanza.primo = CPL.stanza.sessione.id < c.id; cplVideo(); }
  cplPannelloPaint();
}

/* ---- il video: WebRTC da telefono a telefono, i messaggi per collegarsi passano dal server ---- */
async function cplVideo(){
  const st = CPL.stanza; if (!st || !st.sessione.stanza || CPL.pc) { cplCamera(); return; }
  await cplCamera();
  let pc;
  try{ pc = new RTCPeerConnection({ iceServers: st.ice || [] }); }catch(_){ return; }
  CPL.pc = pc;
  if (CPL.loc) CPL.loc.getTracks().forEach(function(t){ pc.addTrack(t, CPL.loc); });
  else { try{ pc.addTransceiver('video', { direction: 'recvonly' }); pc.addTransceiver('audio', { direction: 'recvonly' }); }catch(_){ } }
  pc.ontrack = function(e){
    CPL.remoto = e.streams[0];
    const v = document.getElementById('cplVAltro'); if (v){ v.srcObject = CPL.remoto; }
    const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = true;
  };
  pc.onicecandidate = function(e){ if (e.candidate) cplSegnale('ice', JSON.stringify(e.candidate)); };
  pc.onconnectionstatechange = function(){
    CPL.collegato = pc.connectionState === 'connected';
    if (pc.connectionState === 'failed'){ const st2 = document.getElementById('cplStato'); if (st2) st2.textContent = 'Il video non si collega su questa rete: il tempo e i compiti restano'; const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = false; }
  };
  if (st.primo){
    try{ const o = await pc.createOffer(); await pc.setLocalDescription(o); cplSegnale('offerta', JSON.stringify(pc.localDescription)); }catch(_){ }
  } else cplSegnale('ancora', '');
  clearInterval(CPL.poll); CPL.poll = setInterval(cplSegnali, 1500);
}
async function cplCamera(){
  if (CPL.loc) return;
  try{
    CPL.loc = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: { echoCancellation: true, noiseSuppression: true } });
    CPL.loc.getAudioTracks().forEach(function(t){ t.enabled = CPL.mic; });
    const v = document.getElementById('cplVMio'); if (v) v.srcObject = CPL.loc;
  }catch(_){
    CPL.loc = null;
    toast('Senza videocamera e microfono il tuo compagno non ti vede: il tempo e i compiti restano');
  }
}
async function cplSegnale(tipo, dati){
  const st = CPL.stanza; if (!st || !st.sessione.stanza) return;
  try{ await cplApi('POST', '/api/focuslock/fm/segnale', { stanza: st.sessione.stanza, tipo: tipo, dati: dati }); }catch(_){ }
}
async function cplSegnali(){
  const st = CPL.stanza, pc = CPL.pc; if (!st || !pc || !st.sessione.stanza) return;
  let r; try{ r = await cplApi('GET', '/api/focuslock/fm/segnali?stanza=' + encodeURIComponent(st.sessione.stanza) + '&dopo=' + CPL.segn); }catch(_){ return; }
  for (const s of ((r && r.segnali) || [])){
    CPL.segn = Math.max(CPL.segn, s.id);
    try{
      if (s.tipo === 'offerta'){
        await pc.setRemoteDescription(JSON.parse(s.dati));
        const a = await pc.createAnswer(); await pc.setLocalDescription(a);
        cplSegnale('risposta', JSON.stringify(pc.localDescription));
        await cplCodaIce();
      } else if (s.tipo === 'risposta'){
        if (pc.signalingState === 'have-local-offer') await pc.setRemoteDescription(JSON.parse(s.dati));
        await cplCodaIce();
      } else if (s.tipo === 'ice'){
        const c = JSON.parse(s.dati);
        if (pc.remoteDescription && pc.remoteDescription.type) await pc.addIceCandidate(c); else CPL.coda.push(c);
      } else if (s.tipo === 'ancora' && st.primo && pc.localDescription){
        /* il compagno e' entrato dopo: gli si rimanda l'offerta */
        cplSegnale('offerta', JSON.stringify(pc.localDescription));
      } else if (s.tipo === 'fine'){
        const vu = document.getElementById('cplVVuoto'); if (vu) vu.hidden = false;
        const st2 = document.getElementById('cplStato'); if (st2) st2.textContent = 'Il tuo compagno è uscito';
      }
    }catch(_){ }
  }
}
async function cplCodaIce(){ const pc = CPL.pc; while (pc && CPL.coda.length){ try{ await pc.addIceCandidate(CPL.coda.shift()); }catch(_){ } } }
function cplMic(){ CPL.mic = !CPL.mic; if (CPL.loc) CPL.loc.getAudioTracks().forEach(function(t){ t.enabled = CPL.mic; }); const b = document.getElementById('cplMic'); if (b) b.innerHTML = cplIco(CPL.mic ? 'mic' : 'micOff', 22); }
function cplCam(){ CPL.cam = !CPL.cam; if (CPL.loc) CPL.loc.getVideoTracks().forEach(function(t){ t.enabled = CPL.cam; }); const b = document.getElementById('cplCam'); if (b) b.innerHTML = cplIco(CPL.cam ? 'cam' : 'camOff', 22); }
async function cplEsciChiedi(){
  if (!CPL.stanza){ goId('s-coppia'); return; }
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Uscire dalla sessione?', 'Il tuo compagno resta nella stanza da solo.', 'Esci', true); }catch(_){ }
  if (!ok) return;
  cplSegnale('fine', '');
  cplChiudiStanza(); cplFineApri();
}
function cplChiudiStanza(silenzioso){
  clearInterval(CPL.poll); clearInterval(CPL.batt); clearInterval(CPL.tick);
  try{ if (CPL.pc) CPL.pc.close(); }catch(_){ }
  CPL.pc = null; CPL.remoto = null; CPL.offertoAltro = false;
  try{ if (CPL.loc) CPL.loc.getTracks().forEach(function(t){ t.stop(); }); }catch(_){ }
  CPL.loc = null;
  try{ flSchermoAcceso('coppia', false); }catch(_){ }
  if (!silenzioso && CPL.stanza) CPL.fine = { sessione: CPL.stanza.sessione, esito: '', voto: '', preferito: !!(CPL.stanza.sessione.compagno && CPL.stanza.sessione.compagno.preferito) };
  if (silenzioso) CPL.stanza = null;
}

/* ---------------------------------------------------------------------------------------
   LA FINE: com'e' andata, com'era la chiamata, il compagno fra i preferiti
   --------------------------------------------------------------------------------------- */
function cplFineApri(){ CPL.stanza = null; goId('s-coppia-fine'); cplFinePaint(); }
function cplFinePaint(){
  const host = document.getElementById('cplFine'); if (!host || !CPL.fine) return;
  const f = CPL.fine, c = f.sessione.compagno;
  const scelta = function(chiave, l){ return '<div class="cpl-scelte">' + l.map(function(x){ return '<button type="button" class="' + (f[chiave] === x[0] ? 'on' : '') + '" onclick="CPL.fine.' + chiave + '=\'' + x[0] + '\';cplFinePaint()">' + x[1] + '</button>'; }).join('') + '</div>'; };
  host.innerHTML = '<p class="cpl-l">Hai fatto quello che avevi detto?</p>' + scelta('esito', [['fatto', '✅ Tutto'], ['parte', '🌓 In parte'], ['no', '❌ No']])
    + (c ? '<p class="cpl-l">Com’era la chiamata?</p>' + scelta('voto', [['ottima', 'Ottima'], ['lievi', 'Qualche problema'], ['gravi', 'Problemi gravi']])
      + '<div class="cpl-sw"><div><b>' + cplEsc(c.nome) + ' fra i tuoi preferiti</b><small>Se prenotate la stessa ora, lavorate di nuovo insieme.</small></div><button type="button" class="switch' + (f.preferito ? ' on' : '') + '" onclick="CPL.fine.preferito=!CPL.fine.preferito;this.classList.toggle(\'on\',CPL.fine.preferito)" aria-label="Fra i preferiti"></button></div>' : '')
    + (f.voto === 'gravi' ? '<textarea id="cplNota" class="fin" rows="2" placeholder="Cosa non è andato? Resta privato: il tuo compagno non lo vede"></textarea>' : '')
    + '<button type="button" class="am-cta" ' + (f.esito ? '' : 'disabled') + ' onclick="cplFineSalva()">Salva</button>';
}
async function cplFineSalva(){
  const f = CPL.fine; if (!f || !f.esito) return;
  const s = f.sessione;
  const nota = (document.getElementById('cplNota') || {}).value || '';
  try{ await cplApi('POST', '/api/focuslock/fm/fine', { id: s.id, esito: f.esito, voto: f.voto || null, nota: nota }); }catch(_){ }
  if (s.compagno && f.preferito !== !!s.compagno.preferito){ try{ await cplApi('POST', '/api/focuslock/fm/preferito', { sessione: s.id, on: f.preferito }); }catch(_){ } }
  /* la sessione fatta: la leggono il patto (verifica "coppia") e la partita */
  const l = cplJ(CPL_STORIA_K, []) || [];
  l.push({ id: s.id, slotAt: s.slotAt, durata: s.durata, esito: f.esito, nome: (s.compagno && s.compagno.nome) || '' });
  cplScrivi(CPL_STORIA_K, l.slice(-200));
  if (f.esito !== 'no'){ try{ if (typeof mgFocusPoint === 'function') mgFocusPoint('sessione portata a termine in coppia', true); }catch(_){ } }
  CPL.fine = null;
  toast(f.esito === 'fatto' ? 'Fatto. Alla prossima sessione' : 'Salvato');
  goId('s-coppia'); await cplCarica(); cplPaint();
}
function cplFineSalta(){ CPL.fine = null; goId('s-coppia'); cplPaint(); }

/* ---------------------------------------------------------------------------------------
   LE PERSONE: chi ha lavorato con te, con la stella dei preferiti
   --------------------------------------------------------------------------------------- */
async function cplPersoneApri(){
  goId('s-coppia-persone');
  const host = document.getElementById('cplPers'); if (host) host.innerHTML = '<p class="cpl-carica">Carico le persone…</p>';
  try{ CPL.persone = await cplApi('GET', '/api/focuslock/fm/persone'); }catch(_){ }
  cplPersonePaint();
}
function cplPersonePaint(){
  const host = document.getElementById('cplPers'); if (!host) return;
  const l = (CPL.persone && CPL.persone.persone) || [];
  host.innerHTML = l.length ? '<p class="cpl-intro">Con la stella, <b>se prenotate la stessa ora lavorate di nuovo insieme.</b></p>' + l.map(function(p){
    return '<div class="cpl-riga"><span class="cpl-av piccolo">' + cplEsc(String(p.nome || '?').charAt(0).toUpperCase()) + '</span><div><b>' + cplEsc(p.nome) + '</b><small>' + p.sessioni + (p.sessioni === 1 ? ' sessione' : ' sessioni') + ' insieme · l’ultima ' + cplEsc(cplGiornoTxt(p.ultima).toLowerCase()) + '</small></div>'
      + '<button type="button" class="cpl-stella' + (p.preferito ? ' on' : '') + '" onclick="cplStella(\'' + cplEsc(p.persona) + '\',' + (!p.preferito) + ')" aria-label="' + (p.preferito ? 'Togli dai preferiti' : 'Aggiungi ai preferiti') + '">' + cplIco('stella', 20) + '</button></div>';
  }).join('') : '<p class="cpl-intro">Qui compaiono le persone con cui hai fatto una sessione.</p>';
}
async function cplStella(persona, on){
  try{ await cplApi('POST', '/api/focuslock/fm/preferito', { persona: persona, on: on }); }catch(_){ toast('Non sono riuscito a cambiarlo'); return; }
  (CPL.persone.persone || []).forEach(function(p){ if (p.persona === persona) p.preferito = on; });
  cplPersonePaint();
}

/* ---- IL BLOCCO IN START: "Lavora in compagnia", con le due porte (le sessioni in coppia e il patto) ---- */
function cplStartBlocco(){
  const tab = document.getElementById('tab-sveglia'); if (!tab) return;
  let b = document.getElementById('cplHost');
  if (!b){
    b = document.createElement('div'); b.id = 'cplHost'; b.className = 'cpl-start';
    const sp = document.getElementById('spHost');
    tab.insertBefore(b, sp && sp.parentElement === tab ? sp : null);
    try{ if (typeof scsOrdinaBlocchi === 'function') setTimeout(function(){ scsOrdinaBlocchi('start'); }, 0); }catch(_){ }
  }
  /* 0.9.290, Andrea: "Lavora in compagnia deve comparire solo in In gruppo, non in Da solo; ed e' attaccato al pannello
     di Full Focus". Si vede solo con l'interruttore su In gruppo, con l'aria delle altre sezioni. */
  b.hidden = typeof stModo === 'function' && stModo() !== 'gruppo';
  /* 0.9.350, Andrea: "il pannello fa cagare, con il Patto quadrato accanto a Sessioni in coppia: rifallo". Due strade, una riga ciascuna,
     ognuna con il suo esito scritto: si legge, si sceglie */
  b.innerHTML = '<div class="cpl-start-in2"><span class="cpl-start-ico2" aria-hidden="true">🤝</span><b>Lavora in compagnia</b><p>Con qualcuno accanto mollare è più difficile.</p></div>'
    + '<button type="button" class="cpl-start-r" onclick="cplApri()"><span aria-hidden="true">🎥</span><div><b>Sessione in coppia</b><small>Vi vedete in video, ognuno lavora alla sua cosa</small></div><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>'
    + '<button type="button" class="cpl-start-r" onclick="patApri()"><span aria-hidden="true">✍️</span><div><b>Il patto</b><small>Un amico fa da garante del tuo impegno</small></div><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>';
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia') setTimeout(cplStartBlocco, 300); });
(function(){ if (typeof stModoSet === 'function'){ const v = stModoSet; window.stModoSet = stModoSet = function(){ const r = v.apply(this, arguments); try{ cplStartBlocco(); }catch(_){ } return r; }; } })();
setTimeout(cplStartBlocco, 2500);

/* ---- la sessione che comincia: la notifica della Chiamata dei sogni porta qui (e la pagina si aggiorna) ---- */
(function(){
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.getElementById('s-coppia') && document.getElementById('s-coppia').classList.contains('active')) cplCarica().then(cplPaint); });
  const css = [
    '.cpl-intro{margin:4px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.cpl-intro b{color:var(--navy)}body.dark .cpl-intro b{color:#fff}',
    '.cpl-carica{text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.cpl-pross{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;padding:20px 16px;border-radius:22px;background:linear-gradient(160deg,#0B3F7A,#001E44);color:#fff;margin-bottom:14px}',
    '.cpl-pross small{font:700 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#BCE0FF}.cpl-pross b{font:900 24px var(--font-display);color:#fff}.cpl-pross p{margin:0 0 6px;font:500 13.5px/1.45 var(--font-body);color:#D7E8FF}',
    '.cpl-pross .am-cta{width:100%}.cpl-pross .am-link{color:#BCE0FF}.cpl-apre{font:700 13px var(--font-body)!important;color:#fff!important}',
    '.cpl-adesso{display:flex;align-items:center;gap:12px;width:100%;text-align:left;padding:14px;border-radius:18px;border:1.5px solid #FF8AC2;background:var(--card,#fff);margin-bottom:12px;cursor:pointer}body.dark .cpl-adesso{background:#12203A}',
    '.cpl-adesso b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .cpl-adesso b{color:#fff}.cpl-adesso small{display:block;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.cpl-puls{flex:none;width:12px;height:12px;border-radius:50%;background:#FF6FA8;box-shadow:0 0 0 0 rgba(255,111,168,.6);animation:cplPuls 1.6s infinite}@keyframes cplPuls{to{box-shadow:0 0 0 12px rgba(255,111,168,0)}}',
    '.cpl-prenota{margin:4px 0 18px}',
    '.fl-tieni{position:fixed;inset:0;z-index:99980;background:rgba(0,8,20,.62);display:flex;align-items:flex-end;justify-content:center}',
    '.fl-tieni-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .fl-tieni-x{background:rgba(255,255,255,.1);color:#fff}',
    '.fl-tieni-f{position:relative;padding-top:34px!important;width:100%;max-width:520px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:26px 22px calc(22px + env(safe-area-inset-bottom));text-align:center}',
    '.fl-tieni-f > b{display:block;font:800 21px/1.3 var(--font-display,var(--font-body));color:var(--navy)}.fl-tieni-f p{margin:10px 0 22px;font:500 15.5px/1.5 var(--font-body);color:var(--muted)}',
    '.fl-tieni-b{position:relative;width:100%;overflow:hidden;padding:17px;border:0;border-radius:999px;background:#0E2350;color:#fff;font:800 16px var(--font-body);touch-action:none;-webkit-user-select:none;user-select:none}',
    '.fl-tieni-b i{position:absolute;left:0;top:0;bottom:0;width:0;background:#0075E3}.fl-tieni-b span{position:relative}',
    '.fl-tieni-f small{display:block;margin-top:10px;font:700 12.5px var(--font-body);color:var(--muted)}.fl-tieni-no{margin-top:8px;border:0;background:none;padding:10px;font:700 15px var(--font-body);color:var(--muted)}',
    'body.dark .fl-tieni-f{background:#12203A}body.dark .fl-tieni-f > b{color:#fff}',
    '.cpl-numeri{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:18px}.cpl-numeri div{text-align:center;padding:12px 4px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .cpl-numeri div{background:#12203A;border-color:#22345A}',
    '.cpl-numeri b{display:block;font:900 24px var(--font-display);color:#0075E3}.cpl-numeri small{font:600 11.5px var(--font-body);color:var(--muted)}',
    '.cpl-sez{margin:6px 4px 8px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.cpl-riga{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:8px}body.dark .cpl-riga{background:#12203A;border-color:#22345A}',
    '.cpl-riga > div{flex:1;min-width:0}.cpl-riga b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-riga b{color:#fff}.cpl-riga small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-x{width:34px;height:34px;border-radius:17px;border:1px solid var(--line);background:transparent;color:var(--muted);cursor:pointer}',
    '.cpl-entra-riga{display:flex;align-items:center;gap:12px;width:100%;text-align:left;border:0;background:transparent;padding:14px 4px;border-top:1px solid var(--line);cursor:pointer}.cpl-entra-riga > span:first-child{font-size:22px}.cpl-entra-riga > span:nth-child(2){flex:1}',
    '.cpl-entra-riga b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .cpl-entra-riga b{color:#fff}.cpl-entra-riga small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-giorni{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:2px 0 12px}.cpl-giorni::-webkit-scrollbar{display:none}',
    '.cpl-giorni button,.cpl-dur button,.cpl-att button,.cpl-scelte button{flex:none;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:9px 14px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}body.dark .cpl-giorni button,body.dark .cpl-dur button,body.dark .cpl-att button,body.dark .cpl-scelte button{background:#12203A;border-color:#22345A;color:#fff}',
    '.cpl-giorni button.on,.cpl-dur button.on,.cpl-att button.on,.cpl-scelte button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.cpl-dur{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}',
    '.cpl-slot{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-height:300px;overflow-y:auto;margin-bottom:14px;padding:2px}',
    '.cpl-slot button{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;padding:10px 4px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px}body.dark .cpl-slot button{background:#12203A;border-color:#22345A}',
    '.cpl-slot b{font:800 15px var(--font-body);color:var(--navy)}body.dark .cpl-slot b{color:#fff}.cpl-slot small{font:600 10.5px var(--font-body);color:#D63384}',
    '.cpl-slot button.qualcuno{border-color:#FF8AC2}.cpl-slot button.on{background:#0075E3;border-color:#0075E3}.cpl-slot button.on b,.cpl-slot button.on small{color:#fff}',
    '.cpl-vuoto{grid-column:1/-1;text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.cpl-imp{margin:0 0 14px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .cpl-imp{background:#12203A;border-color:#22345A}',
    '.cpl-imp summary{list-style:none;cursor:pointer;display:flex;flex-direction:column;gap:2px}.cpl-imp summary::-webkit-details-marker{display:none}.cpl-imp summary span{font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-imp summary span{color:#fff}.cpl-imp summary small{font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-l{margin:12px 2px 8px;font:700 13.5px var(--font-body);color:var(--navy)}body.dark .cpl-l{color:#fff}',
    '.cpl-att{display:flex;flex-wrap:wrap;gap:8px}',
    '.cpl-sw{display:flex;align-items:center;gap:12px;padding:12px 0 0}.cpl-sw > div{flex:1}.cpl-sw b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .cpl-sw b{color:#fff}.cpl-sw small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.cpl-compiti{display:flex;flex-direction:column;gap:8px;margin-bottom:16px}.cpl-comp{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:var(--bg,#F4F9FF)}body.dark .cpl-comp{background:#0F1B33}',
    '.cpl-comp span{flex:1;font:600 13.5px var(--font-body);color:var(--navy)}body.dark .cpl-comp span{color:#fff}.cpl-comp button{border:0;background:transparent;color:var(--muted);cursor:pointer}',
    '.cpl-stanza{position:fixed;inset:0;background:#06142B;color:#fff;overflow:hidden}',
    '.cpl-v-altro{position:absolute;inset:0}.cpl-v-altro video{width:100%;height:100%;object-fit:cover;background:#06142B}',
    '.cpl-v-vuoto{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:radial-gradient(120% 90% at 50% 20%,#1E3366,#06142B 70%)}.cpl-v-vuoto[hidden]{display:none}.cpl-v-vuoto b{font:700 15px var(--font-body);color:#D7E8FF;text-align:center;padding:0 30px}',
    '.cpl-av{width:84px;height:84px;border-radius:50%;display:grid;place-items:center;font:900 34px var(--font-display);color:#fff;background:linear-gradient(135deg,#FF8AC2,#5BC0F8)}.cpl-av.piccolo{width:38px;height:38px;font-size:16px;flex:none}',
    '.cpl-v-mio{position:absolute;right:14px;top:calc(env(safe-area-inset-top,0px) + 70px);width:96px;height:132px;border-radius:16px;object-fit:cover;background:#0F1B33;border:2px solid rgba(255,255,255,.4);z-index:3;transform:scaleX(-1)}',
    '.cpl-alto{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 14px);display:flex;flex-direction:column;align-items:center;z-index:3;text-shadow:0 2px 10px rgba(0,0,0,.5)}.cpl-alto b{font:900 34px var(--font-display)}.cpl-alto small{font:700 13px var(--font-body);color:#D7E8FF}',
    '.cpl-pannello{position:absolute;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom,0px) + 92px);max-height:38%;overflow-y:auto;z-index:3;padding:12px 14px;border-radius:18px;background:rgba(6,20,43,.72);backdrop-filter:blur(10px)}',
    '.cpl-pl{margin:4px 0 6px;font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#BCE0FF}',
    '.cpl-ck{display:flex;align-items:center;gap:10px;padding:6px 0;font:600 14px var(--font-body);color:#fff}.cpl-ck input{width:20px;height:20px;accent-color:#0075E3}.cpl-ck.altro i{width:20px;height:20px;border-radius:6px;border:2px solid #BCE0FF;display:grid;place-items:center;font-style:normal;font-size:12px}.cpl-ck.fatto span{text-decoration:line-through;opacity:.7}',
    '.cpl-st-in{width:100%;margin:6px 0;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#fff;border-radius:12px;padding:9px 12px;font:600 13.5px var(--font-body)}.cpl-st-in::placeholder{color:#9FB8E6}',
    '.cpl-pv{margin:0;font:500 13px var(--font-body);color:#9FB8E6}',
    '.cpl-assente{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;padding:12px;border-radius:14px;background:rgba(255,111,168,.16);text-align:center}.cpl-assente b{font:800 14px var(--font-body)}.cpl-assente .am-link{color:#BCE0FF}',
    '.cpl-ctl{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 22px);display:flex;justify-content:center;gap:18px;z-index:3}',
    '.cpl-ctl button{width:58px;height:58px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;display:grid;place-items:center;cursor:pointer;backdrop-filter:blur(8px)}.cpl-ctl .cpl-esci{background:#E63946}',
    '.cpl-scelte{display:flex;flex-wrap:wrap;gap:8px}',
    '.cpl-start[hidden]{display:none!important}.cpl-start{margin:28px 0 28px;padding:18px 16px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .cpl-start{background:#12203A;border-color:#22345A}',
    '.cpl-start{background:linear-gradient(180deg,#C8EFFD 0%,#F0FBFF 100%)!important;border:1px solid #BCE0FF!important;padding:24px 16px 16px!important}.cpl-start-in2{text-align:center;margin-bottom:20px}.cpl-start-ico2{display:block;font-size:40px;line-height:1;margin-bottom:12px}.cpl-start-in2 b{display:block;font:800 19px var(--font-display);color:#001E44}.cpl-start-in2 p{margin:8px auto 0;max-width:28ch;font:500 14.5px/1.45 var(--font-body);color:#33476A}',
    '.cpl-start-r{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;margin:0 0 10px;padding:14px;border-radius:18px;border:0;background:#fff;text-align:left;cursor:pointer;box-shadow:0 2px 10px rgba(0,30,68,.06);color:#001E44}.cpl-start-r:last-child{margin-bottom:0}.cpl-start-r > span{flex:none;width:42px;height:42px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:21px;background:#F0FBFF}.cpl-start-r > div{flex:1;min-width:0}.cpl-start-r b{display:block;font:800 15.5px var(--font-body);color:#001E44}.cpl-start-r small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:#5B6B86}.cpl-start-r svg{flex:none;color:#0075E3}',
    'body.dark .cpl-start{background:linear-gradient(180deg,#1A3C6E,#12264C)!important;border-color:#2C4170!important}body.dark .cpl-start-in2 b{color:#fff}body.dark .cpl-start-in2 p{color:#D6E8FF}body.dark .cpl-start-r{background:#0E1D3D;color:#fff}body.dark .cpl-start-r b{color:#fff}body.dark .cpl-start-r small{color:#9FB3D1}body.dark .cpl-start-r > span{background:#12264C}body.dark .cpl-start-r svg{color:#8CC6FF}',
    '.cpl-start-in{display:flex;gap:12px;align-items:flex-start}.cpl-start-ico{font-size:28px;line-height:1}.cpl-start-in b{display:block;font:800 16px var(--font-body);color:var(--navy)}body.dark .cpl-start-in b{color:#fff}.cpl-start-in small{display:block;margin-top:2px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.cpl-start-bt{display:grid;grid-template-columns:1.4fr 1fr;gap:8px;margin-top:12px}.cpl-start-bt .am-cta{margin:0}.cpl-start-2{border:1.5px solid var(--line);background:transparent;border-radius:14px;font:700 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .cpl-start-2{color:#fff;border-color:#22345A}',
    '.cpl-stella{width:40px;height:40px;border-radius:20px;border:1px solid var(--line);background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}.cpl-stella.on{color:#F5B301;border-color:#F5B301}.cpl-stella.on svg{fill:#F5B301}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
