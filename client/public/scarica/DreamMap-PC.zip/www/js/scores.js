/* scores.js - the numbers of the day, and the two places they live.

   The Profile opens on the night sky of the wishlist page: the name under a starfield, then a
   slideshow that rotates on its own between the phrase of the day (typed out letter by letter,
   ending on a "Vedi dettagli" that opens Ispirazione quotidiana) and the day's focus hours and
   streak. Below it, the report: today's screen time against yesterday, blocked and unlocks
   with their explanations, and where the attention went.

   The four scores live at the top of the Blocco tab, each ring filling to its own percentage
   every time that tab is opened.

   Every figure is read from the engine's getDayReport(); a score whose inputs are missing is
   shown as "-", never as a guess. The formulas are written down in SC_META where the user can
   read them. */

const SC_DAY_MS = 86400000;
const SC_H = 3600000;
const SC = { mem: {}, view: 'total', dayOff: 0, tipTimer: 0, typed: false, slide: 0,
             rotate: 0, held: 0, quotes: null, insDay: 0 };

/* Packages that count as distracting until the user says otherwise from the Report tab. */
const SC_DEFAULT_DISTRACT = ['com.instagram.android','com.instagram.lite','com.zhiliaoapp.musically','com.ss.android.ugc.trill',
  'com.facebook.katana','com.facebook.lite','com.google.android.youtube','com.twitter.android','com.snapchat.android',
  'com.reddit.frontpage','tv.twitch.android.app','com.pinterest','com.netflix.mediaclient','com.tumblr','com.discord',
  'com.tinder','com.badoo.mobile','com.disney.disneyplus','com.amazon.avod.thirdpartyclient','com.twitch.android.app'];

/* When the store cannot be reached the day still has a phrase. */
/* LA SCORTA DELL'APP.
   Serve quando il sito non risponde, e serve anche quando l'elenco che arriva ha poche frasi
   LEGGIBILI: in tutti e due i casi e' quella che tiene in piedi la pagina. Con sei frasi si
   ripeteva ogni sei giorni, che e' un difetto diverso dallo stesso problema; diciotto fanno
   quasi tre settimane. Tutte corte, perche' e' il loro mestiere: devono stare sulla schermata
   di blocco senza finire sotto all'orologio. */
const SC_FALLBACK_QUOTES = [
  'Il futuro dipende da quello che fai oggi. ~ Mahatma Gandhi',
  'Se il tuo domani sarà uguale a quello di ieri, avrai vissuto un giorno solo. ~ Gianluca Liguori',
  'La felicità è quando ciò che pensi, ciò che dici e ciò che fai sono in armonia. ~ Mahatma Gandhi',
  'Non è che abbiamo poco tempo: è che ne perdiamo molto. ~ Seneca',
  'La disciplina è scegliere tra ciò che vuoi ora e ciò che vuoi di più. ~ Abraham Lincoln',
  'Ogni volta che dici sì a una distrazione, dici no a qualcosa che conta. ~ Anonimo',
  'Siamo ciò che facciamo ripetutamente. ~ Aristotele',
  'Il modo per iniziare è smettere di parlare e cominciare a fare. ~ Walt Disney',
  'Un idiota con un piano può battere un genio senza un piano. ~ Warren Buffett',
  'Mentre si rimanda, la vita passa. ~ Seneca',
  'Chi insegue due conigli non ne prende nessuno. ~ Proverbio',
  'Un viaggio di mille miglia comincia con un passo. ~ Lao Tzu',
  'Non importa quanto vai piano, purché tu non ti fermi. ~ Confucio',
  'Chi è dappertutto non è in nessun posto. ~ Seneca',
  'Comincia. Il coraggio ha in sé genio e potere. ~ Goethe',
  'Il tempo perduto non si ritrova mai più. ~ Benjamin Franklin',
  'La conoscenza non basta: bisogna applicarla. ~ Bruce Lee',
  'La disciplina è il ponte fra i sogni e i risultati. ~ Proverbio',
  'Nessuno ti restituirà gli anni. ~ Seneca',
  'Prima il necessario, poi il possibile: e all\'improvviso stai facendo l\'impossibile. ~ Francesco d\'Assisi'
];
const SC_MONTHS = ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

function scIsDistracting(pkg){
  let c = null;
  try{ c = (typeof insCats === 'function') ? insCats()[pkg] : null; }catch(_){ c = null; }
  if (c) return c === 'distr';
  return SC_DEFAULT_DISTRACT.indexOf(pkg) >= 0;
}
/* I NAVIGATORI (0.9.204). Waze e Google Maps misurano la strada, non il telefono in mano: il loro
   tempo non entra nel tempo di schermo della panoramica. Dalla lista «Dove va la tua attenzione?»
   escono solo se lo scegli dal menu ⋯. Le altre app escluse dal Report restano qui: la panoramica
   dice dove va l'attenzione, il Report cosa conti. */
const SC_NAV_PKG = /waze|google\.android\.apps\.maps|\.maps$|navigat|sygic|tomtom|here\.app|osmand|mapfactor|magicearth|moovit|citymapper/i;
function scIsNav(a){ return SC_NAV_PKG.test(String((a && a.packageName) || '')) || /^(waze|google maps|maps|mappe|here wego|moovit)$/i.test(String((a && a.label) || '').trim()); }
function scNavMs(rows){ return (rows || []).filter(scIsNav).reduce(function(t, a){ return t + (a.ms || 0); }, 0); }
function scNavNascosti(){ try{ return localStorage.getItem('fl_nav_nascondi') === '1'; }catch(_){ return false; } }
function scNavNascondiSet(on){ try{ localStorage.setItem('fl_nav_nascondi', on ? '1' : '0'); }catch(_){ } scMenusClose(); scBlockScores(); }
/** Le righe della panoramica: sempre le prime cinque (i navigatori restano, salvo scelta). */
function scRigheAttenzione(rows){ const r = (rows || []).filter(function(a){ return !a.launcher && (!scNavNascosti() || !scIsNav(a)); }); return r.slice(0, 5); }
function scExcluded(){ try{ return (typeof insExcl === 'function') ? insExcl() : []; }catch(_){ return []; } }
/* 0.9.286: la mezzanotte di un altro giorno si trova spostando la data, non togliendo 24 ore: il 25 ottobre
   (si torna all'ora solare) dura 25 ore, e "oggi + 7 x 24 ore" cadeva alle 23 del giorno prima. La scorta
   delle frasi del telefono finiva con i giorni sfasati di uno. */
function scDayStart(off){ const d = new Date(); d.setHours(0,0,0,0); if (off) d.setDate(d.getDate() - off); return d.getTime(); }
function scKey(ts){ const d = new Date(ts); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); }
function scClamp(x){ return Math.max(0, Math.min(1, x)); }
function scMinOfDay(ts){ const d = new Date(ts); return d.getHours() * 60 + d.getMinutes(); }
function scFmt(ms){
  ms = Math.max(0, Math.round(ms || 0));
  const m = Math.floor(ms / 60000), h = Math.floor(m / 60);
  if (h > 0) return h + 'h ' + String(m % 60).padStart(2,'0') + 'm';
  if (m > 0) return m + 'm';
  return Math.floor(ms / 1000) + 's';
}
function scFmtShort(ms){
  const m = Math.round((ms || 0) / 60000), h = Math.floor(m / 60);
  if (h > 0) return m % 60 ? h + 'h ' + (m % 60) + 'min' : h + 'h';
  return m + 'min';
}
function scDistractions(r){
  const ex = scExcluded();
  return (r && r.top || []).filter(a => ex.indexOf(a.packageName) < 0 && !a.launcher && scIsDistracting(a.packageName))
                            .reduce((s, a) => s + (a.ms || 0), 0);
}

/* ---------------------------------------------------------------------------------------
   DATA
   --------------------------------------------------------------------------------------- */

/* IL CANCELLO NON E' PIU' «il motore sa misurare», MA «c'e' una giornata da mostrare».
   Sul computer `getDayReport` non esiste: con la vecchia domanda questi pannelli sparivano
   del tutto, e chi guardava vedeva una scheda mezza vuota senza capire perche'. La giornata
   la misura il telefono e la pubblica; qui basta averla. */
function scHaGiornata(){
  try{
    if (NATIVE && typeof NATIVE.getDayReport === 'function') return true;
    return !!(typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.rep);
  }catch(_){ return false; }
}

let SC_PC_LETTO = 0;
const SC_IN_CORSO = {};
async function scReport(off){
  const start = scDayStart(off);
  const key = scKey(start);
  /* PRIMA DI QUALUNQUE GIUDIZIO SULLA NOTTE, il primo segno di vita sul computer. Era letto
     solo dalla pagina del punteggio: le pillole del Profilo e il rapporto pubblicato al
     computer partivano senza, e la sveglia restava quella del telefono (11:03). */
  if ((off || 0) === 0 && Date.now() - SC_PC_LETTO > 3 * 60000){
    SC_PC_LETTO = Date.now();
    try{ if (typeof dpLeggiComputer === 'function') await dpLeggiComputer(); }catch(_){ }
  }
  if (off > 0){
    /* un giorno salvato prima del motore unico del sonno (0.9.236) si rilegge una volta */
    try{ const c = localStorage.getItem('fl_dayrep_' + key); if (c){ const v = JSON.parse(c); if (v && v.granted && (v.sonnoV === SN_V || snQuiComputer())) return v; } }catch(_){ }
  }
  const mem = SC.mem[key];
  if (mem && Date.now() - mem.t < 45000) return mem.v;
  /* chi arriva mentre il giorno si sta leggendo aspetta la stessa lettura: il motore risponde a
     una domanda alla volta, e dieci domande uguali in fila facevano scadere quelle dopo */
  if (SC_IN_CORSO[key]) return SC_IN_CORSO[key];
  if (!NATIVE || !NATIVE.getDayReport) return null;
  SC_IN_CORSO[key] = (async function(){
    let r = null;
    try{ r = await NATIVE.getDayReport({ dayStart: start }); }catch(_){ r = null; }
    if (!r) return null;
    /* LA NOTTE DAL MOTORE UNICO, sempre dal telefono: anche quando il Report guarda il
       computer o i due insieme e questo rapporto e' una ricostruzione (sonno.js) */
    try{ r = await snConNotte(r, start); }catch(_){ }
    return r;
  })();
  let r = null;
  try{ r = await SC_IN_CORSO[key]; }finally{ delete SC_IN_CORSO[key]; }
  if (!r) return null;
  SC.mem[key] = { t: Date.now(), v: r };
  if (off > 0 && r.granted){
    try{
      const slim = Object.assign({}, r, { top: (r.top || []).map(a => ({ packageName: a.packageName, label: a.label, ms: a.ms, launcher: !!a.launcher })) });
      localStorage.setItem('fl_dayrep_' + key, JSON.stringify(slim));
    }catch(_){ }
  }
  return r;
}

/**
 * LA GIORNATA DEI TRE PUNTEGGI: sempre quella del telefono (0.9.302).
 *
 * <p>Sonno, Focus e Riposo li misura il telefono ("I PUNTEGGI RESTANO DEL TELEFONO", motore-web.js), qualunque
 * dispositivo sia scelto nei tre puntini del pannello. La 0.9.301 l'aveva corretto solo nella card del Profilo:
 * toccando un punteggio, la pagina del dettaglio leggeva ancora scReport, cioe' la sorgente scelta. Con "solo il
 * computer" e il computer che oggi non aveva mandato niente, il rapporto tornava { granted: false, senzaDati } e la
 * pagina diceva "Serve l'accesso ai dati di utilizzo" a chi l'accesso l'aveva dato; con il computer acceso giudicava
 * il sonno e il riposo sui programmi del PC. Le medie dei sette giorni avevano lo stesso difetto.</p>
 *
 * <p>Sul telefono si chiede al suo motore vero (mwReportVero), con la notte del motore unico; sul computer la
 * giornata di oggi e' quella che il telefono ha pubblicato (specchio-web.js, SW_GIORNO).</p>
 */
/* 0.9.303: sul computer la giornata del telefono arriva dall'account. Se il computer non e' piu' collegato (il 28/10 lo era
   stato fino al 20/10, poi Google ha chiesto di nuovo l'accesso) la colpa non e' del telefono: lo si dice, e si offre
   l'accesso (specchio-web.js, SW_GIORNO.errore). */
function scPcScollegato(){
  try{ return typeof mwMotoreVero === 'function' && !mwMotoreVero() && typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.errore === 'accesso'; }
  catch(_){ return false; }
}
async function scPcAccedi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.googleSignIn) return;
    const r = await NATIVE.googleSignIn();
    if (r && r.signedIn && typeof toast === 'function') toast('Collegato: ' + r.email);
  }catch(e){ if (typeof toast === 'function') toast(e && e.message ? e.message : 'Accesso non riuscito'); return; }
  try{ if (typeof swSincronizza === 'function') await swSincronizza(true); }catch(_){ }
  try{ scoresRefresh(); }catch(_){ }
  try{ if (document.getElementById('scBody')) scRender(); }catch(_){ }
}

const SC_MEM_TEL = {};
async function scReportPunteggi(off){
  off = off || 0;
  const vero = typeof mwMotoreVero === 'function' && mwMotoreVero();
  if (!vero){
    /* il computer: oggi e' la giornata pubblicata dal telefono, gli altri giorni quello che si sa */
    try{
      if (off === 0 && typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.rep && SW_GIORNO.rep.dayStart === scDayStart(0)) return SW_GIORNO.rep;
    }catch(_){ }
    return await scReport(off);
  }
  /* il telefono con la sua sorgente: e' gia' la lettura del suo motore (e la cache e' la stessa) */
  if (typeof mwFonte !== 'function' || mwFonte() === 'telefono' || typeof mwReportVero !== 'function') return await scReport(off);
  const start = scDayStart(off), key = scKey(start);
  const m = SC_MEM_TEL[key];
  if (m && (off > 0 || Date.now() - m.t < 45000)) return m.v;
  let v = await mwReportVero(start);
  if (v && v.granted){ try{ v = await snConNotte(v, start); }catch(_){ } }
  if (v) SC_MEM_TEL[key] = { t: Date.now(), v: v };
  return v;
}

/*
 * The three scores, recalibrated on a real day.
 *
 * The first formulas were built on the calendar day, and a night that crossed midnight broke
 * all three at once: bed at 04:00, up at 10:00, on the phone all day. Sleep came out as "not
 * measured" (the day's first use was at 00:10), Rest came out 100 (the six hours asleep were
 * counted as time awake and away from the phone), Focus came out 47 for a day with almost no
 * distracting apps in it. The reference app read the same day as 25 / 90 / 25.
 *
 * The engine now hands over the night as a night (sleepMs, sleepStart, wakeAt) and the waking
 * day measured from waking (awakeScreenMs, awakeGapMs), and each score reads its own thing:
 *   Sonno   how long the night was, and how late it began. An inverted U (SC_SONNO_CURVA):
 *           4h or less = 0, 7h30-8h30 = 100, then down again (10h = 78, 12h = 50); bed after
 *           01:00 costs 8, after 03:00 costs 12. Six hours begun at 04:00 is 58.
 *   Focus   how much went to distracting apps, first of all; total screen time and pickups
 *           weigh less. A long day of work on the phone with no social in it stays high.
 *   Riposo  how much of the waking day was spent off the screen, and the longest break in it.
 *           A day spent entirely on the phone is low, however long the night was.
 */
/**
 * IL PRIMO SEGNO DI VITA, ovunque sia.
 *
 * <p>La notte finiva al primo sblocco del TELEFONO. Chi si alza alle otto e va dritto al
 * computer lascia il telefono fermo fino a mezza mattina: il 22/09 il punteggio leggeva la
 * notte da 01:22 a 11:03 — nove ore e quarantuno — e dava 92, mentre le ore dormite erano
 * sei e mezza. Il computer pubblica il suo primo segno di vita della giornata (`fl:pc-grani`,
 * scritto dal computer stesso): se e' piu' presto, la notte finisce li'.</p>
 */
/* LA SVEGLIA DAL COMPUTER E' UNA SCELTA (0.9.202, Andrea): di serie conta solo il telefono.
   Chi lavora al computer appena sveglio la accende dalla pagina del punteggio Sonno. */
function scSvegliaPcOn(){ try{ return localStorage.getItem('fl_sveglia_pc') === '1'; }catch(_){ return false; } }
function scSvegliaPcSet(on){ try{ localStorage.setItem('fl_sveglia_pc', on ? '1' : '0'); }catch(_){ } }
/* Un primo segno di vita del COMPUTER prima delle quattro non e' una sveglia: e' la sera
   (0.9.202). Vale solo per il computer: per il telefono decide il motore del sonno. */
const SC_SVEGLIA_MIN = 4 * 60;
function scPcSveglia(r){
  try{
    if (!scSvegliaPcOn()) return 0;
    if (typeof dpComputerPrimo !== 'function' || typeof dpChiave !== 'function') return 0;
    if (!r || !r.dayStart) return 0;
    const p = dpComputerPrimo(dpChiave(r.dayStart));
    if (!p) return 0;
    /* dentro alla giornata, e dopo il momento in cui la notte e' cominciata */
    if (p < r.dayStart || p > r.dayStart + 86400000) return 0;
    if (r.sleepStart && p <= r.sleepStart) return 0;
    if (scMinOfDay(p) < SC_SVEGLIA_MIN) return 0;
    return p;
  }catch(_){ return 0; }
}

/* IL SONNO E' UNA COLLINA, NON UNA SCALA (12/10/2026, Andrea).
   Prima otto ore valevano 100 e ogni ora in piu' restava 100: undici ore e mezza prendevano il
   voto pieno. Dormire molto oltre le nove ore e mezza sballa l'orologio del corpo e di solito
   lascia piu' intontiti, quindi sopra le otto ore e mezza il punteggio scende di nuovo.
   [ore, punti]: fra due righe si va in linea retta; sotto la prima 0, sopra l'ultima 0. */
/* 0.9.236: la collina vive in sonno-motore.js (SN_CURVA), con il resto del conto della notte. */
const SC_SONNO_CURVA = SN_CURVA;
/* Da qui in su il punteggio scende perche' hai dormito TROPPO (serve all'etichetta). */
const SC_SONNO_TROPPO_H = 8.5;
function scSonnoPunti(ore){ return snCurva(ore); }

function scCompute(r){
  if (!r || !r.granted) return null;
  /* SUL COMPUTER I TRE PUNTEGGI SONO QUELLI DEL TELEFONO. Sonno, Focus e Riposo li misura il
     telefono: qui si giudica la giornata che ha spedito lui, qualunque sorgente sia scelta
     per i rapporti. Un computer acceso e lasciato li' direbbe zero riposo. */
  try{
    if (typeof mwSoloWeb === 'function' && mwSoloWeb() && typeof SW_GIORNO !== 'undefined'
        && SW_GIORNO && SW_GIORNO.rep && SW_GIORNO.rep.dayStart === r.dayStart && !r.daTelefono){
      r = SW_GIORNO.rep;
    }
  }catch(_){ }
  const now = Date.now();
  const today = r.dayStart === scDayStart(0);
  const screen = r.screenMs || 0;
  const distr = scDistractions(r);
  const pickups = r.pickups || 0;
  const gap = r.longestGapMs || 0;
  /* LA NOTTE E' QUELLA DEL MOTORE UNICO (sonno-motore.js), arrivata dentro al rapporto
     (scReport -> snConNotte). Niente piu' conti qui: la vecchia regola "un risveglio prima
     delle quattro e' la sera" e il ripiego sul primo uso del giorno di calendario sono finiti
     li', e il ripiego era proprio il "Primo sblocco 00:00" del 13/10: un uso cominciato prima
     di mezzanotte, tagliato alle 00:00. Un rapporto ricostruito in pagina (sorgente del
     Report "computer" o "insieme") non sa niente della notte: senza la notte del motore,
     la notte non c'e'. */
  const n = r.notte || null;
  let notte = n;
  let wake = n ? (n.sveglia || 0) : (r.daMotoreWeb ? 0 : (r.wakeAt || 0));
  let sleepMs = n ? (n.ok ? (n.sonnoMs || 0) : 0) : (r.daMotoreWeb ? 0 : (r.sleepMs || 0));
  const sleepStart = n ? (n.inizio || 0) : (r.daMotoreWeb ? 0 : (r.sleepStart || r.prevLastUse || 0));
  if (!n && sleepMs > 0) notte = { ok: true, inizio: sleepStart, sveglia: wake, sonnoMs: sleepMs, effettivoMs: sleepMs, interruzioni: [] };
  const pcSveglia = scPcSveglia(r);
  if (pcSveglia && sleepStart && pcSveglia > sleepStart && (!wake || pcSveglia < wake)){
    wake = pcSveglia;
    const prima = ((notte && notte.interruzioni) || []).filter(function(x){ return x.at < pcSveglia; });
    sleepMs = Math.max(0, pcSveglia - sleepStart - prima.reduce(function(t, x){ return t + x.ms; }, 0));
    notte = { ok: true, inizio: sleepStart, sveglia: pcSveglia, sonnoMs: sleepMs, effettivoMs: sleepMs, interruzioni: prima, svegliaDa: 'computer' };
  }
  const awakeFrom = r.awakeFrom || wake || r.firstUse || 0;
  const end = r.lastUse ? (today ? now : r.lastUse) : 0;
  const span = (awakeFrom && end) ? Math.max(0, end - awakeFrom) : 0;
  const awakeScreen = (typeof r.awakeScreenMs === 'number') ? r.awakeScreenMs : screen;
  const offline = Math.max(0, span - awakeScreen);
  const awakeGap = r.awakeGapMs || 0;
  const o = { screenMs: screen, distrMs: distr, pickups: pickups, gapMs: gap, spanMs: span, offlineMs: offline,
              sleepMs: sleepMs, first: wake, last: r.lastUse || 0,
              prevLast: sleepStart, sleepStart: sleepStart, wake: wake, notte: notte,
              sveglia: wake, daComputer: !!(pcSveglia && pcSveglia === wake),
              blocks: r.blocks || 0, sessions: r.sessions || 0, hasUse: !!(r.firstUse || screen > 0) };
  /* il voto: la collina sulle ore (il sonno leggero dopo una sveglia rimandata vale meta'),
     meno l'ora tarda del letto, meno un poco per ogni interruzione (snPunteggio) */
  o.sleep = (o.sleepMs > 0 && notte) ? snPunteggio(Object.assign({}, notte, { ok: true, sonnoMs: o.sleepMs })) : null;
  if (o.hasUse){
    const f = 100 - 70 * scClamp(distr / (3 * SC_H)) - 20 * scClamp(screen / (10 * SC_H))
                  - 10 * scClamp((pickups - 30) / 70);
    o.focus = Math.round(Math.max(0, Math.min(100, f)));
  } else o.focus = null;
  // Rest reads the whole day so far, not only the stretch since waking: at 10:42 someone who
  // slept until 10:30 has rested all night, and a score that read "—" for the first hour of
  // every day was the score nobody understood. Share of the day spent off the screen: a
  // quarter is 0, four fifths is 100 (Opal's 70 sits at about 62%).
  const dayEnd = today ? now : (r.dayStart ? r.dayStart + 86400000 : 0);
  const elapsed = (r.dayStart && dayEnd) ? Math.max(0, dayEnd - r.dayStart) : 0;
  o.elapsedMs = elapsed; o.dayOfflineMs = Math.max(0, elapsed - screen); o.awakeGapMs = awakeGap;
  if (elapsed >= 60 * 60000){
    const ratio = o.dayOfflineMs / elapsed;
    o.rest = Math.round(Math.max(0, Math.min(100, (ratio - 0.25) / 0.55 * 100)));
  } else o.rest = null;
  const parts = [o.sleep, o.focus, o.rest].filter(v => v !== null);
  o.total = parts.length ? Math.round(parts.reduce((a, b) => a + b, 0) / parts.length) : null;
  return o;
}

async function scAverages(off){
  const acc = {}, n = {};
  const add = (k, v) => { if (v === null || v === undefined) return; acc[k] = (acc[k] || 0) + v; n[k] = (n[k] || 0) + 1; };
  for (let i = 1; i <= 7; i++){
    const r = await scReportPunteggi(off + i);
    const c = scCompute(r);
    if (!c || !c.hasUse) continue;
    add('screenMs', c.screenMs); add('distrMs', c.distrMs); add('pickups', c.pickups);
    add('gapMs', c.awakeGapMs > 0 ? c.awakeGapMs : c.gapMs); add('offlineMs', c.elapsedMs > 0 ? c.dayOfflineMs : null);
    add('sleepMs', c.sleepMs > 0 ? c.sleepMs : null);
    add('firstMin', c.first ? scMinOfDay(c.first) : null);
    add('lastMin', c.prevLast ? ((scMinOfDay(c.prevLast) + 12 * 60) % (24 * 60)) : null);
    add('blocks', c.blocks);
  }
  const out = {};
  Object.keys(acc).forEach(k => { out[k] = acc[k] / n[k]; });
  out.days = Math.max.apply(null, [0].concat(Object.keys(n).map(k => n[k])));
  return out;
}

/* ---------------------------------------------------------------------------------------
   THE PHRASE OF THE DAY - the store's own list, the store's own arithmetic
   --------------------------------------------------------------------------------------- */

/* The cache is keyed on the day, not on twenty-four elapsed hours: a phrase fetched at 23:50
   has to change at midnight, like the website's does. */
/* 0.9.337, Andrea: "la frase di Bob Marley sui soldi continua a comparire: non la voglio piu' vedere". Arriva dalle frasi del
   giorno del sito, o dalla memoria di ieri: si scarta qui, da qualunque fonte, e anche sul server (focuslockQuotes.ts). */
const SC_BANDITE = /marley|povere|poveri|ricco non|uomo ricco|poor man|so poor|rich man/i;
function scPulisci(o){
  if (!o) return o;
  if (o.today && SC_BANDITE.test(o.today)) o.today = '';
  if (Array.isArray(o.list)) o.list = o.list.filter(function(q){ return !SC_BANDITE.test(typeof q === 'string' ? q : JSON.stringify(q)); });
  return o;
}
async function scQuotes(){
  const day = scKey(scDayStart(0));
  if (SC.quotes && SC.quotes.day === day) return SC.quotes;
  let cached = null;
  try{ cached = JSON.parse(localStorage.getItem('fl_quotes') || 'null'); }catch(_){ cached = null; }
  scPulisci(cached);
  if (cached && cached.day === day && (cached.today || (cached.list || []).length)){ SC.quotes = cached; return cached; }
  let got = null;
  if (NATIVE && NATIVE.publicApi){
    try{
      const j = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/quotes' });
      /* 0.9.288: la frase "di oggi" del server vale solo se il server parla dello stesso giorno. Prima si teneva per
         tutta la giornata anche quando arrivava dalla memoria di ieri (alle 8 c'era ancora la frase del giorno prima). */
      if (j && (j.today || (j.quotes && j.quotes.length))) got = { day: day, today: (!j.day || j.day === day) ? (j.today || '') : '', list: j.quotes || [], serverDay: j.day || '' };
    }catch(_){ }
  }
  if (!got){
    if (cached && (cached.today || (cached.list || []).length)) return cached;   // ieri è meglio di niente
    got = { day: day, today: '', list: SC_FALLBACK_QUOTES, fallback: true };
  } else {
    if (!got.serverDay || got.serverDay === day){ try{ localStorage.setItem('fl_quotes', JSON.stringify(got)); }catch(_){ } }
  }
  SC.quotes = scPulisci(got);
  return got;
}
/* ---------------------------------------------------------------------------------------
   QUANTO PUO' ESSERE LUNGA UNA FRASE

   Il limite non e' un gusto: e' una misura. Sulla schermata di blocco la frase sta sotto
   all'orologio e ha quattro righe scarse prima di finire fuori — circa centosettanta
   caratteri a corpo normale su uno schermo da telefono. Oltre, l'ultima parte non si legge, e
   una frase che finisce a meta' e' peggio di una frase che non c'e'.

   Il taglio tiene dentro le brevi e le medio-lunghe, e lascia fuori solo i racconti: chi ha
   scritto un pezzo da millecinquecento caratteri non stava scrivendo una frase del giorno.
   --------------------------------------------------------------------------------------- */
const SC_MAX_LEN = 170;
/* E una lunghezza MINIMA, che serve per una ragione diversa e altrettanto concreta.
   La traduzione italiana dell'elenco e' uscita dallo strumento di traduzione con qualche
   pezzo rotto: fra le 276 frasi ce ne sono tre che sono solo frammenti — «.», «.»,
   «. Sognano."» — rimasti attaccati alla frase sbagliata. Ventidue altre cominciano con un
   punto e uno spazio di troppo, e quelle non sono rotte: sono buone, con davanti della
   sporcizia. Quindi due trattamenti diversi: le prime si scartano, le seconde si puliscono.
   «"Pensa, credi, sogna e osa."» sta in ventotto caratteri ed e' una frase intera: la soglia
   deve stare sotto, o si butterebbe via la piu' bella. */
const SC_MIN_LEN = 20;
const SC_MIN_POOL = 20;

/** Via la punteggiatura orfana in testa, che arriva dalla traduzione e non dall'autore. */
function scPulisci(raw){
  return String(raw || '').replace(/^[\s.,;:)\]}’”]+/, '').trim();
}

/** Da scartare: troppo lunga per la schermata di blocco, o troppo corta per essere una frase. */
function scTroppoLunga(raw){
  const p = scSplitQuote(raw);
  return !p || p.text.length > SC_MAX_LEN || p.text.length < SC_MIN_LEN;
}

/**
 * La frase del giorno `off`, cercando dall'indice in avanti finche' non se ne trova una che
 * ci sta.
 *
 * <p>NON si filtra l'elenco: filtrarlo sposterebbe tutti gli indici, e l'indice e' l'unica
 * cosa che tiene l'app allineata a quello che il sito ha mostrato quel giorno. Si parte
 * dall'indice giusto e, se quella frase e' un racconto, si prende la successiva — il che vuol
 * dire che nei giorni normali, che sono la grande maggioranza, l'app dice esattamente quello
 * che diceva il sito.</p>
 */
function scDalGiorno(list, off){
  const n = list.length;
  if (!n) return null;
  const giorno = Math.floor(scDayStart(off) / 1000 / 86400);
  const i0 = ((giorno % n) + n) % n;
  /* ELENCO CORTO: si filtra e si allunga con la scorta.
     Qui prima c'era `if (n < SC_MIN_POOL) return scSplitQuote(list[i0])` — cioe' «se l'elenco
     e' corto, non controllare la lunghezza». Una rete di sicurezza messa DAVANTI al cancello
     invece che dietro: bastava che la chiamata al server fallisse e tornasse la copia di ieri
     (una frase sola) perche' tutti e sette i giorni mostrassero la stessa frase da
     trecentoventi caratteri, illeggibile sulla schermata di blocco.
     Con un elenco corto l'allineamento con il sito non esiste comunque — il sito ha il suo
     elenco intero — quindi qui si puo' filtrare senza perdere niente. */
  if (n < SC_MIN_POOL){
    const scorta = list.filter(function(q){ return !scTroppoLunga(q); }).concat(SC_FALLBACK_QUOTES);
    if (!scorta.length) return null;
    return scSplitQuote(scorta[((giorno % scorta.length) + scorta.length) % scorta.length]);
  }

  if (!scTroppoLunga(list[i0])) return scSplitQuote(list[i0]);

  /* SI SALTA A MEZZO ELENCO, non alla successiva.
     Prendere semplicemente «quella dopo» fa una cosa brutta: se la frase del giorno D e'
     lunga e quella di D+1 va bene, D mostra la frase di D+1 e il giorno dopo la rimostra.
     Misurato su un anno: 71 giorni su 366 uguali al giorno prima. Saltando a meta' elenco il
     sostituto finisce lontano da qualsiasi vicino, e due giorni consecutivi atterrano su due
     posizioni diverse: 2 ripetizioni su 366, con gli stessi 294 giorni identici al sito. */
  const base = (i0 + Math.floor(n / 2)) % n;
  for (let k = 0; k < n; k++){
    const c = list[(base + k) % n];
    if (!scTroppoLunga(c)) return scSplitQuote(c);
  }
  /* Tutte lunghe: meglio la scorta che una frase illeggibile. Non si torna MAI su list[i0]. */
  return scSplitQuote(SC_FALLBACK_QUOTES[((giorno % SC_FALLBACK_QUOTES.length) + SC_FALLBACK_QUOTES.length) % SC_FALLBACK_QUOTES.length]);
}

/* Splits "testo ~ autore". */
function scSplitQuote(raw){
  const chosen = scPulisci(raw);
  if (!chosen) return null;
  const parts = chosen.split('~');
  if (parts.length > 1) return { text: parts.slice(0, -1).join('~').trim(), author: parts[parts.length - 1].trim() || 'Anonimo' };
  return { text: chosen, author: 'Anonimo' };
}
/**
 * La frase di un giorno, con la stessa aritmetica del sito.
 *
 * <p>NIENTE ORDINAMENTO. Qui c'era `sort((a,b) => a.length - b.length)`, messo per rispecchiare
 * il `{% assign quotes = quotes | sort: 'size' %}` del tema. Quel Liquid pero' non ordina per
 * lunghezza: `sort: 'proprieta''` legge `item['proprieta'']`, e su una STRINGA Ruby quella e'
 * una ricerca di sottostringa — `"una frase"["size"]` e' nil a meno che dentro non ci sia
 * scritto «size», e su 276 frasi non succede mai. L'elenco resta nell'ordine in cui arriva.
 *
 * <p>Verificato il 17/09/2026 sull'elenco vero: la frase che il sito mostrava oggi sta alla
 * posizione 13 dell'ordine originale, e i giorni dall'epoch modulo 276 fanno 13. Con
 * l'ordinamento per lunghezza usciva la posizione 60, cioe' un'altra frase — ed e' quello che
 * l'app avrebbe mostrato per ogni giorno passato.</p>
 */
/* 0.9.286, Andrea: "fai in modo che compaiano anche come frasi del giorno, oltre alle frasi del mio sito".
   Le frasi scelte da lui passano davanti a quella del sito in giorni fissi: i primi giorni dal 20 ottobre una
   dopo l'altra, poi una ogni sette giorni, a turno. Gli altri giorni restano quelli del sito, con il suo indice.
   Le usa anche frasi-obiettivo.js: compaiono pure con "solo frasi sul mio obiettivo" acceso. */
const SC_SCELTE = [
  '"Concentrarsi vuol dire saper dire di no." ~ Steve Jobs',
  '"Il successo è andare da un fallimento all’altro senza perdere l’entusiasmo." ~ Winston Churchill',
  '"Siamo ciò che facciamo ripetutamente; l’eccellenza, quindi, non è un atto, ma un’abitudine." ~ Will Durant',
  /* 0.9.289, Andrea */
  '"Quanto tempo hai intenzione di aspettare prima di pretendere il meglio per te stesso?" ~ Epitteto',
  /* 0.9.296, Andrea (22/10/2026): in italiano per chi usa il telefono in italiano, l'originale per chi lo usa in inglese */
  { it: '"Non ci sono limiti. Ci sono solo plateau: non devi restarci, devi andare oltre." ~ Bruce Lee', en: '"There are no limits. There are only plateaus, and you must not stay there, you must go beyond them." ~ Bruce Lee' },
  { it: '"Le paure che non affrontiamo diventano i nostri limiti. Le occasioni che non cogliamo diventano i nostri muri." ~ Robin Sharma', en: '"The fears we don\u2019t face become our limits. The opportunities we don\u2019t seize become our walls." ~ Robin Sharma' },
  { it: '"Tutto quello che non stai cambiando, lo stai scegliendo." ~ Laurie Buchanan', en: '"Whatever you are not changing, you are choosing." ~ Laurie Buchanan' },
  { it: '"Noi siamo quello che scegliamo di essere. Ora scegli!" ~ Green Goblin', en: '"We are who we choose to be. Now choose!" ~ Green Goblin' },
  /* 0.9.306, Andrea (29/10/2026) */
  { it: '"Non aspettare il momento perfetto: prendi il momento e rendilo perfetto." ~ Zoey Sayward', en: '"Don\u2019t wait for the perfect moment. Take the moment and make it perfect." ~ Zoey Sayward' },
  { it: '"La vita si restringe o si espande in proporzione al proprio coraggio." ~ Anaïs Nin', en: '"Life shrinks or expands in proportion to one\u2019s courage." ~ Anaïs Nin' },
  { it: '"Tutto ciò che hai sempre voluto è dall’altra parte della paura." ~ George Addair', en: '"Everything you\u2019ve ever wanted is on the other side of fear." ~ George Addair' },
  { it: '"L’unico limite a ciò che realizzeremo domani saranno i nostri dubbi di oggi." ~ Franklin D. Roosevelt', en: '"The only limit to our realization of tomorrow will be our doubts of today." ~ Franklin D. Roosevelt' },
  { it: '"Ogni battaglia viene vinta o persa prima ancora di essere combattuta." ~ Sun Tzu', en: '"Every battle is won or lost before it is ever fought." ~ Sun Tzu' },
  { it: '"Se conosci il nemico e conosci te stesso, non devi temere il risultato di cento battaglie." ~ Sun Tzu', en: '"If you know the enemy and know yourself, you need not fear the result of a hundred battles." ~ Sun Tzu' },
  { it: '"Puoi avere la nave migliore del mondo, l’aereo migliore del mondo, ma se il capitano o il pilota non sa dove andare, la nave andrà alla deriva e non arriverà mai da nessuna parte." ~ Arnold Schwarzenegger', en: '"You can have the best ship in the world, you can have the best airplane in the world, but if the captain or the pilot doesn\u2019t know where to go, that ship will drift around and is never going to end up anywhere." ~ Arnold Schwarzenegger' }
];
function scScelta(x){ return (x && typeof x === 'object') ? ((typeof flTesto === 'function') ? flTesto(x) : (x.it || x.en)) : x; }
const SC_SCELTE_DAL = new Date(2026, 9, 20).getTime();
/** La frase scelta da Andrea per il giorno che comincia a `inizio` (una mezzanotte), o null. */
function scSceltaDelGiorno(inizio){
  const n = SC_SCELTE.length; if (!n) return null;
  const g = Math.round((inizio - SC_SCELTE_DAL) / SC_DAY_MS);
  if (g < 0) return null;
  if (g < n) return scScelta(SC_SCELTE[g]);
  if (g % 7 === 0) return scScelta(SC_SCELTE[(g / 7) % n]);
  return null;
}
function scQuoteFor(q, off){
  const scelta = scSceltaDelGiorno(scDayStart(off));
  if (scelta) return scSplitQuote(scelta);
  /* Anche OGGI passa dal taglio: se il sito sta mostrando un racconto da millecento caratteri,
     l'app prende la successiva. Preferisco una frase diversa dal sito a una che sulla
     schermata di blocco finisce sotto all'orologio. */
  if (!off && q.today && !scTroppoLunga(q.today)) return scSplitQuote(q.today);
  const list = (q.list || []).map(s => String(s).trim()).filter(Boolean);
  /* Un elenco di una voce sola NON vuol dire «quella frase tutti i giorni»: e' esattamente
     come sono finiti sette giorni di fila con la stessa citazione lunghissima. Si passa da
     scDalGiorno, che con un elenco corto usa la scorta e fa variare i giorni. */
  return scDalGiorno(list.length ? list : [], off);
}

/* ---------------------------------------------------------------------------------------
   PROFILE - the night sky
   --------------------------------------------------------------------------------------- */

function scStars(){
  const host = document.getElementById('profStars');
  if (!host || host.childElementCount) return;
  let html = '';
  for (let i = 0; i < 70; i++){
    const big = i % 5 === 0;
    html += '<i class="star' + (big ? ' big' : '') + '" style="left:' + (Math.random() * 100).toFixed(1) + '%;top:' + (Math.random() * 100).toFixed(1)
      + '%;animation-delay:' + (-Math.random() * 6).toFixed(2) + 's;animation-duration:' + (4 + Math.random() * 5).toFixed(2) + 's"></i>';
  }
  host.innerHTML = html;
}

function scStreak(){
  let up = false, n = 0;
  try{
    if (typeof blkProtectionUp === 'function' && typeof blkStreak === 'function'){
      up = blkProtectionUp();
      if (up || (typeof BLK_QUICK_KNOWN === 'undefined' || BLK_QUICK_KNOWN)) n = blkStreak(up);
    }
  }catch(_){ }
  return { up: up, days: up ? n : 0 };
}

async function scoresRefresh(){
  const host = document.getElementById('profSlides');
  scStars();
  if (typeof flSetBleed === 'function') flSetBleed();
  if (!host) return;
  if (!scHaGiornata()){ host.innerHTML = ''; return; }
  /* 0.9.301: i tre punteggi li misura il telefono (motore-web.js, "I PUNTEGGI RESTANO DEL TELEFONO"). Con i dati del
     computer scelti nel pannello, qui arrivava il rapporto del computer, e se il computer oggi era spento usciva
     "Abilita l'accesso ai dati di utilizzo" con il permesso gia' concesso. 0.9.302: la stessa lettura vale per la
     pagina del dettaglio e per le medie (scReportPunteggi). */
  const r = await scReportPunteggi(0);
  /* una lettura fallita (il motore occupato) non e' un permesso negato: si riprova fra poco */
  if (!r){ if (!scoresRefresh._riprova) scoresRefresh._riprova = setTimeout(function(){ scoresRefresh._riprova = 0; scoresRefresh(); }, 2000); return; }
  if (!r.granted){
    host.innerHTML = r.senzaDati
      ? (scPcScollegato()
        ? '<div class="sc-grant" onclick="scPcAccedi()"><b>Il tuo punteggio del giorno</b><small>Il computer non è più collegato al tuo account, quindi non riceve i punteggi del telefono. Tocca qui per accedere con Google.</small></div>'
        : '<div class="sc-grant"><b>Il tuo punteggio del giorno</b><small>Lo misura il telefono: oggi non ha ancora mandato i suoi dati.</small></div>')
      : '<div class="sc-grant" onclick="openPerm(\'usage\')"><b>Il tuo punteggio del giorno</b><small>Abilita l\'accesso ai dati di utilizzo per vederlo.</small></div>';
    return;
  }
  host.innerHTML = scSkyHtml(scCompute(r));
  scAnimateArcs(host);
}

function scSkyHtml(sc){
  const v = x => (x === null || x === undefined) ? '\u2014' : x;
  const pill = (k, ico, label) =>
    '<div class="bs-pill" onclick="scOpen(\'' + k + '\')"><div class="cap">'
    + '<svg class="arc"><path data-pct="' + (sc[k] === null || sc[k] === undefined ? 0 : sc[k]) + '"/></svg>'
    + '<span class="ic">' + ico + '</span><b>' + v(sc[k]) + '</b></div><small>' + label + '</small></div>';
  return '<div class="bh-scorebox prof-scorebox">'
    + '<div class="bh-sc-total" onclick="scOpen(\'total\')"><small>PUNTEGGIO</small>'
    +   '<b>' + v(sc.total) + '<span class="caret">\u25be</span></b></div>'
    + '<div class="bh-bracket"><i></i><i></i><i></i></div>'
    + '<div class="bh-row">' + pill('sleep', '\uD83C\uDF19', 'Sonno') + pill('focus', '\u23F3', 'Focus') + pill('rest', '\uD83C\uDF32', 'Riposo') + '</div>'
    + '</div>';
}

/* I record personali: aggiornati qui, mostrati SOLO dentro ai due tooltip. Una riga in più
   nel cielo era una riga in più da leggere; il record è una cosa che si va a cercare. */
function scRecords(focusH, streakDays){
  let rec = null; try{ rec = JSON.parse(localStorage.getItem('fl_records') || 'null'); }catch(_){ }
  rec = rec || { focusH: 0, streak: 0 };
  if (focusH > rec.focusH || streakDays > rec.streak){
    rec = { focusH: Math.max(rec.focusH, focusH), streak: Math.max(rec.streak, streakDays) };
    try{ localStorage.setItem('fl_records', JSON.stringify(rec)); }catch(_){ }
  }
  return rec;
}
/* Quante volte hai ascoltato il mantra, e da quanti giorni di fila: lo conta il servizio
   (MantraLog), perché il gesto avviene sulla card a schermo, non dentro all'app. */
let SC_MANTRA = { days: 0, total: 0, today: false, best: 0, bestDay: 0, todayN: 0 };
async function scMantraLoad(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getMantraLog) return SC_MANTRA;
  try{
    const r = await NATIVE.getMantraLog();
    SC_MANTRA = { days: (r && r.days) || 0, total: (r && r.total) || 0, today: !!(r && r.today),
                  best: (r && r.best) || 0, bestDay: (r && r.bestDay) || 0, todayN: (r && r.todayN) || 0 };
  }catch(_){ }
  return SC_MANTRA;
}
function scFocusHtml(sc, streak){
  const focusH = sc && sc.spanMs > 0 ? Math.floor(sc.offlineMs / SC_H) : 0;
  // I giorni di blocco stanno già in fondo alla scheda ("Il primo passo"): qui in cielo vale
  // di più la costanza del mantra, che è l'unica cosa che si sceglie di fare ogni giorno.
  const days = SC_MANTRA.days;
  const rec = scRecords(focusH, days);
  const cmp = '<button type="button" class="sc-tipbtn" onclick="scTipHide();if(typeof frOpen===\'function\')frOpen()">Confronta con gli amici</button>';
  const t1 = 'Le ore di oggi passate da sveglio senza toccare il telefono: dal primo sblocco della mattina a adesso, tolto il tempo di schermo.\n\nIl tuo record: ' + rec.focusH + (rec.focusH === 1 ? ' ora' : ' ore') + '.';
  /* IL RECORD, ACCANTO ALLA STRISCIA. La striscia viva dice come stai andando adesso; il
     record dice di cosa sei stato capace — ed e' l'unica frase che serve il giorno dopo averne
     persa una lunga. Sono due numeri diversi, e vanno detti tutti e due. */
  const recStreak = Math.max(rec.streak, SC_MANTRA.best);
  const t2 = 'Giorni di fila in cui hai ascoltato il tuo mantra, toccando il play sulla card che compare a schermo. Ogni ascolto vale molti punti.'
    + '\n\nIn tutto: ' + SC_MANTRA.total + (SC_MANTRA.total === 1 ? ' ascolto' : ' ascolti') + '.'
    + '\nRecord di giorni di fila: ' + recStreak + (recStreak === 1 ? ' giorno' : ' giorni') + '.'
    + (SC_MANTRA.bestDay ? '\nRecord di ascolti in un giorno solo: ' + SC_MANTRA.bestDay + '.' : '')
    + (SC_MANTRA.todayN ? '\nOggi: ' + SC_MANTRA.todayN + (SC_MANTRA.todayN === 1 ? ' ascolto' : ' ascolti') + '.' : '')
    + (SC_MANTRA.today ? '' : '\n\nOggi non l\'hai ancora ascoltato.');
  return '<div class="pf-stat sev-rise" style="--d:.62s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t1)) + ', ' + esc(JSON.stringify(cmp)) + ')">'
    +   '<span class="ico glow-mint">⏳</span><b class="num mint">' + focusH + '</b><small>ORE DI FOCUS<i class="q">i</i></small></div>'
    + '<div class="pf-stat sev-rise" style="--d:.78s" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t2)) + ', ' + esc(JSON.stringify(cmp)) + ')">'
    +   '<span class="ico glow-fire">🔥</span><b class="num gold">' + days + '</b><small>MANTRA DI FILA<i class="q">i</i></small></div>';
}
/* Letter by letter, with the blinking caret of the website; at the end the button appears. */
function scTypeQuote(){
  const el = document.getElementById('bhQuote');
  if (!el || SC.typing) return;
  const text = el.dataset.text || '';
  if (!text) return;
  SC.typing = true;
  // Hold the slideshow while the letters appear: the section rotates every 7 seconds and a
  // phrase cut in half mid-word is worse than no animation at all.
  try{ if (typeof FL_HEROES !== 'undefined' && FL_HEROES.blocco) FL_HEROES.blocco.held = Date.now(); }catch(_){ }
  el.innerHTML = '';
  /* Il suono della macchina da scrivere, lo stesso della pagina Wishlist del sito: la frase
     del giorno si animava in silenzio, e un'animazione muta sembra un rendering lento. */
  if (typeof itTypeSound === 'function') itTypeSound(true);
  el.classList.toggle('long', text.length > 105);
  // Exactly the site's karaoke (wishlist.js): the letters are ADDED one at a time in front
  // of the caret, so the caret is always right after the last letter. The first version put
  // every letter in place invisible and only revealed them: the caret sat at the end of the
  // whole phrase from the first frame, waiting.
  const chars = Array.from(text);
  const cur = document.createElement('span'); cur.className = 'typewriter-cursor'; cur.textContent = '|';
  el.appendChild(cur);
  let i = 0;
  const step = function(){
    if (!document.body.contains(el)){ SC.typing = false; if (typeof itTypeSound === 'function') itTypeSound(false); return; }
    if (i < chars.length){
      const sp = document.createElement('span'); sp.className = 'typewriter-char visible'; sp.textContent = chars[i++];
      el.insertBefore(sp, cur);
      if ((i & 7) === 0) scHeroFit();
      setTimeout(step, 55);
      return;
    }
    SC.typing = false; SC.typed = true;
    if (typeof itTypeSound === 'function') itTypeSound(false);
    setTimeout(function(){ cur.remove(); }, 1600);
    scShowDetails();
  };
  step();
}
function scQuotePreview(text){
  const el = document.getElementById('bhQuote');
  if (!el) return;
  /* Dieci caratteri tagliavano a meta' della prima parola e l'anteprima non diceva niente.
     Sessanta sono una riga e mezza: abbastanza per capire di che parla, non abbastanza per
     togliere il gusto di aprirla. */
  const head = Array.from(String(text || '')).slice(0, 22).join('');
  el.innerHTML = esc(head) + '… <button type="button" class="bh-q-more" onclick="scTypeQuote()">🔍 Scopri di più</button>';
  scHeroFit();
}
document.addEventListener('fl:slide', function(e){
  const d = e.detail || {};
  if (d.key !== 'rotta') return;
  // la slide cambia altezza solo quando la frase e' davanti (seconda della Rotta), per intero
  if (d.i !== 1){ scHeroFit(true); return; }
  const el = document.getElementById('bhQuote');
  if (!el || !el.dataset.text) return;
  if (SC.typed){ el.textContent = el.dataset.text; scShowDetails(); scHeroFit(); }
});
function scShowDetails(){
  const b = document.getElementById('bhQuoteBtn');
  if (b){ b.hidden = false; b.classList.add('bh-cta--glow'); b.classList.add('bh-q-in'); }
  scHeroFit();
  try{ if (typeof nvHeroPareggia === 'function') setTimeout(nvHeroPareggia, 600); }catch(_){ }
}
/* La slide si allunga con la frase, come il riquadro della pagina Wishlist: il pulsante
   "Vedi dettagli" finiva sopra alle tre lineette perche' l'altezza era fissa a 340. */
function scHeroFit(reset){
  const host = document.getElementById('blkHero');
  if (!host) return;
  if (reset){ host.style.setProperty('--bh-h', '340px'); return; }
  const box = host.querySelector('.bh-slide[data-i="2"] .bh-quote');
  if (!box) return;
  /* Si misura il CONTENUTO, non il contenitore: .bh-quote e' assoluto e alto quanto la
     pista, quindi il suo scrollHeight e' sempre almeno l'altezza corrente — misurarlo e
     aggiungerci otto pixel faceva crescere la slide a ogni lettera, fino a 3600px. */
  const cs = getComputedStyle(box);
  let need = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
  Array.prototype.forEach.call(box.children, function(k){
    if (k.hidden) return;
    const ks = getComputedStyle(k);
    need += k.offsetHeight + (parseFloat(ks.marginTop) || 0) + (parseFloat(ks.marginBottom) || 0);
  });
  host.style.setProperty('--bh-h', Math.max(340, Math.ceil(need)) + 'px');
}

/* ---------------------------------------------------------------------------------------
   PROFILE - the report under the screen time
   --------------------------------------------------------------------------------------- */

/* The three quantities the panel can show. The choice is remembered: the panel is the first
   thing on the Blocco tab and should open on what the person looked at last. */
/* La quinta voce e' la riserva di dopamina: qui SOLO la giornata di oggi. Il confronto fra
   settimana e mese vive nella scheda Profilo — qui si entra per sapere come si sta adesso. */
const SC_METRICS = [['screen', '⏱ Tempo di schermo'], ['launch', '🚀 Avvii dell\'app'], ['web', '🌐 Tempo di navigazione'], ['notif', '🔔 Notifiche'], ['dopa', '🧠 Riserva di dopamina']];
function scRepMetric(){
  if (!SC.metric){ try{ SC.metric = localStorage.getItem('fl_rep_metric') || 'screen'; }catch(_){ SC.metric = 'screen'; } }
  if (!SC_METRICS.some(x => x[0] === SC.metric)) SC.metric = 'screen';
  return SC.metric;
}
function scRepSetMetric(m){
  SC.metric = m;
  try{ localStorage.setItem('fl_rep_metric', m); }catch(_){ }
  document.querySelectorAll('#blkReport .rep-metrics button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  scBlockScores();
}
/* The choice now lives inside the panel, behind the three dots in its corner: the row of
   pills above it was one more strip between the sky and the number. */
function scRepMetricsHtml(){ return ''; }
/* 0.9.302: LO STESSO PANNELLO IN DUE POSTI. Il pannello di "Proteggi i tuoi sogni" (dove 'blk') e la sua copia nella
   rivelazione della revisione e del Rientra in rotta (dove 'cv', conversa.js) escono dalla stessa funzione
   (scPannelloHtml): stessi dati, stessa sorgente, stessi tre puntini. La metrica e il dispositivo sono una scelta
   sola per tutti e due; il periodo della copia e' quello della revisione (oggi, la settimana...). Gli id dei menu
   hanno un prefisso per pannello, cosi' i tre puntini aprono il menu del pannello toccato e non quello dell'altro. */
function scVista(v){ return v || { metric: scRepMetric(), range: scRepRange(), dove: 'blk' }; }
function scMenuId(base, v){ return (v && v.dove === 'cv') ? 'cv' + base.charAt(0).toUpperCase() + base.slice(1) : base; }
function scRepMenuHtml(v){
  v = scVista(v);
  const m = scRepMetric();
  const dove = v.dove === 'cv' ? ',\'cv\'' : '';
  return '<div class="rep-scrim" id="' + scMenuId('repScrim', v) + '" hidden onclick="scMenusClose()"></div>'
    + '<button type="button" class="rep-more" onclick="scRepMenuToggle(event' + dove + ')" aria-label="Cosa mostrare">⋯</button>'
    + '<div class="rep-menu" id="' + scMenuId('repMenu', v) + '" hidden>' + SC_METRICS.map(x =>
      '<button type="button"' + (x[0] === m ? ' class="on"' : '') + ' onclick="scRepSetMetric(\'' + x[0] + '\')">' + x[1] + '</button>').join('')
      /* DA DOVE ARRIVANO QUESTI NUMERI. La voce compare solo a chi ha davvero i due
         dispositivi collegati allo stesso account: a tutti gli altri sarebbe una domanda
         senza risposte. */
      /* 0.9.280, Andrea: le due levette (tempo dietro al blocco schermo, Maps e Waze) stanno nelle impostazioni del Report */
      + ((typeof mwMenuHtml === 'function') ? mwMenuHtml() : '') + '</div>';
}
/* Il periodo. Oggi, ieri, sette giorni, il mese, l'anno, da sempre: il confronto che serve
   e' con ieri e con la propria storia, non con un semestre. */
const SC_RANGES = [['today', 'Oggi'], ['yesterday', 'Ieri'], ['7d', 'Ultimi 7 giorni'], ['30d', 'Ultimo mese'], ['365d', 'Ultimo anno'], ['all', 'Da sempre']];
function scRepRange(){
  if (!SC.range){ try{ SC.range = localStorage.getItem('fl_rep_range') || 'today'; }catch(_){ SC.range = 'today'; } }
  if (!SC_RANGES.some(x => x[0] === SC.range)) SC.range = 'today';
  return SC.range;
}
function scRepSetRange(r){
  SC.range = r;
  try{ localStorage.setItem('fl_rep_range', r); }catch(_){ }
  scBlockScores();
}
/* from/to della finestra, la finestra precedente per il confronto, e la grana delle barre. */
function scRangeWindow(r){
  const now = Date.now(), d0 = scDayStart(0);
  if (r === 'yesterday') return { from: scDayStart(1), to: d0, pfrom: scDayStart(2), pto: scDayStart(1), bucket: 'hour', label: 'ieri', vs: 'l\'altro ieri' };
  if (r === '7d') return { from: scDayStart(6), to: now, pfrom: scDayStart(13), pto: scDayStart(6), bucket: 'day', label: 'negli ultimi 7 giorni', vs: 'la settimana prima' };
  if (r === '30d') return { from: scDayStart(29), to: now, pfrom: scDayStart(59), pto: scDayStart(29), bucket: 'day', label: 'nell\'ultimo mese', vs: 'il mese prima' };
  if (r === '365d') return { from: scDayStart(364), to: now, pfrom: scDayStart(729), pto: scDayStart(364), bucket: 'day', months: true, label: 'nell\'ultimo anno', vs: 'l\'anno prima' };
  /* 0.9.302: il periodo della revisione del trimestre (la copia del pannello in conversa.js) */
  if (r === '90d') return { from: scDayStart(89), to: now, pfrom: scDayStart(179), pto: scDayStart(89), bucket: 'day', label: 'negli ultimi tre mesi', vs: 'i tre mesi prima' };
  if (r === 'all') return { from: scDayStart(399), to: now, pfrom: 0, pto: 0, bucket: 'day', months: true, label: 'da sempre', vs: '' };
  return { from: d0, to: now, pfrom: scDayStart(1), pto: d0, bucket: 'hour', label: 'oggi', vs: 'ieri' };
}
/* L'intestazione del pannello E il selettore del periodo sono la stessa cosa.
   Prima erano due: una scritta al centro che diceva "di oggi", e un pulsantino in alto a
   sinistra che diceva la stessa parola occupando un angolo. Ne basta uno, e sta dove si
   guarda per primo. */
function scRangeBtn(label, v){
  v = scVista(v);
  const r = v.range;
  /* la copia del pannello nella revisione del trimestre parte dagli ultimi tre mesi: la voce c'e' solo li' */
  const voci = r === '90d' ? SC_RANGES.slice(0, 4).concat([['90d', 'Ultimi tre mesi']], SC_RANGES.slice(4)) : SC_RANGES;
  const cur = (voci.filter(x => x[0] === r)[0] || voci[0])[1];
  const cv = v.dove === 'cv';
  return '<button type="button" class="rep-rangebtn" onclick="scRangeMenuToggle(event' + (cv ? ',\'cv\'' : '') + ')">'
    + label + ' \u00b7 ' + cur + '<i></i></button>'
    + '<div class="rep-menu rep-rangemenu" id="' + scMenuId('repRangeMenu', v) + '" hidden>' + voci.map(x =>
      '<button type="button"' + (x[0] === r ? ' class="on"' : '') + ' onclick="' + (cv ? 'cvPanPeriodo' : 'scRepSetRange') + '(\'' + x[0] + '\')">' + x[1] + '</button>').join('') + '</div>';
}
function scRangeMenuHtml(){
  const r = scRepRange();
  const cur = (SC_RANGES.filter(x => x[0] === r)[0] || SC_RANGES[0])[1];
  return '<button type="button" class="rep-range" onclick="scRangeMenuToggle(event)">' + cur + ' <i></i></button>'
    + '<div class="rep-menu rep-rangemenu" id="repRangeMenu" hidden>' + SC_RANGES.map(x =>
      '<button type="button"' + (x[0] === r ? ' class="on"' : '') + ' onclick="scRepSetRange(\'' + x[0] + '\')">' + x[1] + '</button>').join('') + '</div>';
}

/* ---- il grafico a barre: le ore del giorno, o i giorni, o i mesi ----
   Lo stesso disegno dell'app di riferimento: barre chiare, righe di griglia con i valori a
   destra, le etichette dell'asse sotto, e la barra dell'ora corrente segnata. */
function scChartHtml(buckets, win, fmt, tocco){
  if (!buckets || !buckets.length) return '';
  /* 0.9.299: nel grafico di oggi del pannello "Dove va la tua attenzione?" un'ora si tocca (scOraTap) */
  const conTocco = !!tocco && win.bucket === 'hour';
  if (conTocco) SC.oggiBuckets = buckets;
  const oraSel = conTocco && scOraAttiva() ? SC.oraSel : -1;
  let bars = buckets.map(b => ({ t: b.start, v: b.v || 0 }));
  let labels = [];
  if (win.bucket === 'hour'){
    labels = bars.map((b, i) => (i % 6 === 0 ? ('0' + new Date(b.t).getHours()).slice(-2) + ':00' : ''));
  } else if (win.months){
    const byM = {};
    bars.forEach(b => { const d = new Date(b.t); const k = d.getFullYear() * 100 + d.getMonth(); byM[k] = byM[k] || { t: b.t, v: 0 }; byM[k].v += b.v; });
    bars = Object.keys(byM).sort().map(k => byM[k]);
    labels = bars.map(b => 'GFMAMGLASOND'.charAt(new Date(b.t).getMonth()));
  } else if (bars.length <= 7){
    labels = bars.map(b => 'DLMMGVS'.charAt(new Date(b.t).getDay()));
  } else {
    labels = bars.map((b, i) => (i % 5 === 0 ? String(new Date(b.t).getDate()) : ''));
  }
  const max = Math.max(1, Math.max.apply(null, bars.map(b => b.v)));
  const nowT = Date.now();
  const step = win.bucket === 'hour' ? 3600000 : 86400000;
  const grid = [1, .66, .33].map(k => '<i class="g" style="bottom:' + Math.round(k * 100) + '%"><span>' + fmt(max * k) + '</span></i>').join('');
  return '<div class="rp-chart" onclick="scGraficoTap(event)">'
    + '<div class="rp-bars' + (oraSel >= 0 ? ' con-sel' : '') + '">' + grid + bars.map((b, i) => {
        const h = Math.max(b.v > 0 ? 3 : 1, Math.round(b.v / max * 100));
        const now = !win.months && nowT >= b.t && nowT < b.t + step;
        return '<b class="' + (now ? 'now' : '') + (i === oraSel ? ' sel' : '') + '" style="height:' + h + '%"'
          + (conTocco ? ' onclick="scOraTap(event,' + i + ')"' : '') + '></b>';
      }).join('') + '</div>'
    + '<div class="rp-axis">' + labels.map(l => '<span>' + l + '</span>').join('') + '</div>'
    + '</div>';
}
function scFmtCount(v){ return String(Math.round(v)); }
/* il tocco su una barra del grafico di oggi: quell'ora in evidenza, le altre sbiadite; lo stesso tocco la toglie */
/* 0.9.300, Andrea: "scegliendo dai tre puntini le app, la navigazione o le notifiche non si puo' piu' filtrare ora per
   ora". Ogni metrica di oggi si filtra per ora: avvii, navigazione e notifiche leggono la loro ora con la stessa
   lettura del pannello, ristretta a quell'ora. La selezione vale solo per la metrica in cui e' stata fatta. */
function scOraAttiva(){ return SC.oraSel != null && SC.oraDay === scDayStart(0) && SC.oraMetric === scRepMetric(); }
function scOraVia(){ SC.oraSel = null; SC.oraApps = null; SC.oraRighe = null; SC.oraMetric = null; }
async function scOraTap(ev, i){
  try{ if (ev) ev.stopPropagation(); }catch(_){ }
  const b = (SC.oggiBuckets || [])[i];
  if (!b) return;
  const metric = scRepMetric();
  if (SC.oraSel === i && scOraAttiva()){ scOraVia(); }
  else {
    if (!(b.v > 0)) return;
    const da = b.start, a = Math.min(Date.now(), b.start + 3600000);
    let righe = [];
    try{
      if (metric === 'launch') righe = ((await NATIVE.getTopApps({ from: da, to: a, limit: 5, by: 'launches', icons: 5 })) || {}).apps || [];
      else if (metric === 'web') righe = ((await NATIVE.getWebTime({ from: da, to: a, bucket: 'none', limit: 5 })) || {}).sites || [];
      else if (metric === 'notif') righe = ((await NATIVE.getNotifications({ from: da, to: a, limit: 5 })) || {}).apps || [];
      else righe = ((await NATIVE.getTopApps({ from: da, to: a, limit: 9, by: 'ms', icons: 12 })) || {}).apps || [];
    }catch(_){ righe = []; }
    if (scRepMetric() !== metric) return;
    SC.oraSel = i; SC.oraDay = scDayStart(0); SC.oraMetric = metric; SC.oraRighe = righe;
    SC.oraApps = metric === 'screen' ? righe : null;
  }
  try{ if (typeof flVibra === 'function') flVibra([8]); }catch(_){ }
  try{ await scBlockScores(); }catch(_){ }
}
/* "Toccando fuori dalla barra deve tornare a mostrare tutto": un tocco in qualunque altro punto toglie il filtro.
   Il tocco sulle barre si ferma in scOraTap (stopPropagation) e non arriva fin qui. */
document.addEventListener('click', function(e){
  if (typeof SC === 'undefined' || SC.oraSel == null) return;
  /* i menu del pannello (tre puntini, periodo) si aprono senza togliere il filtro: ridisegnare li chiuderebbe */
  try{ if (e && e.target && e.target.closest && e.target.closest('.rep-more,.rep-rangebtn,.rep-menu,.rep-scrim')) return; }catch(_){ }
  scOraVia();
  try{ scBlockScores(); }catch(_){ }
});
document.addEventListener('fl:tab', function(){ if (typeof SC !== 'undefined') scOraVia(); });
/* la fascia scritta come nel Report: "13:00 - 14:00" */
function scOraFascia(start){
  const hh = new Date(start).getHours();
  return String(hh).padStart(2, '0') + ':00 - ' + String((hh + 1) % 24).padStart(2, '0') + ':00';
}
function scFmtMin(ms){ const m = Math.round(ms / 60000); return m >= 60 ? Math.floor(m / 60) + 'h' : m + 'm'; }

/* Un solo motore per i due menu del pannello, con il suo velo.
   Prima ognuno si apriva per conto suo, senza niente dietro: il menu galleggiava sopra alla
   pagina e l'occhio continuava a leggere i numeri sotto invece delle voci. E soprattutto le
   voci stavano DENTRO a .rep-top, che porta al Report: sceglierne una faceva due cose — la
   scelta e il salto di pagina — e si finiva su una schermata che nessuno aveva chiesto. */
/* 0.9.302: i menu del pannello copiato nella rivelazione (conversa.js) hanno il prefisso cv: cvRepMenu, cvRepRangeMenu */
const SC_MENU_COPPIE = { repMenu: 'repRangeMenu', repRangeMenu: 'repMenu', cvRepMenu: 'cvRepRangeMenu', cvRepRangeMenu: 'cvRepMenu' };
function scMenuOpen(id){
  const m = document.getElementById(id);
  if (!m) return;
  const cv = id.indexOf('cv') === 0;
  const other = document.getElementById(SC_MENU_COPPIE[id] || 'repMenu');
  if (other) other.hidden = true;
  const wasOpen = !m.hidden;
  scMenusClose();
  if (wasOpen) return;
  m.hidden = false;
  /* 0.9.280, Andrea: "l'overlay scuro non copre l'intestazione". Velo e menu erano chiusi dentro al
     pannello, sotto all'intestazione: escono nel telefono (come i menu dei tre puntini delle mappe),
     e alla chiusura tornano al loro posto. */
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : null;
  if (casa && typeof flMenuFissa === 'function'){
    const v = document.createElement('div'); v.id = 'repVeil'; v.className = 'arb-veil';
    v.addEventListener('click', function(e){ e.stopPropagation(); scMenusClose(); });
    casa.appendChild(v);
    m._casa = m.parentElement;
    flMenuFissa(m, m._casa && m._casa.querySelector(/RangeMenu$/.test(id) ? '.rep-rangebtn,.rep-range' : '.rep-more'));
  } else {
    const sc = document.getElementById(cv ? 'cvRepScrim' : 'repScrim');
    if (sc){ sc.hidden = false; requestAnimationFrame(function(){ sc.classList.add('in'); }); }
  }
  setTimeout(function(){
    document.addEventListener('click', function once(){ scMenusClose(); document.removeEventListener('click', once); });
  }, 0);
}
function scMenusClose(){
  ['repMenu', 'repRangeMenu', 'cvRepMenu', 'cvRepRangeMenu'].forEach(function(k){ document.querySelectorAll('#' + k).forEach(function(e){
    e.hidden = true;
    if (e.classList.contains('fl-menu-fisso')){
      e.classList.remove('fl-menu-fisso'); e.style.left = ''; e.style.top = '';
      if (e._casa && document.contains(e._casa) && !e._casa.querySelector('#' + k)) e._casa.appendChild(e); else e.remove();
    }
  }); });
  const vv = document.getElementById('repVeil'); if (vv) vv.remove();
  ['repScrim', 'cvRepScrim'].forEach(function(k){ const sc = document.getElementById(k); if (sc){ sc.classList.remove('in'); sc.hidden = true; } });
}
function scRepMenuToggle(ev, dove){ if (ev) ev.stopPropagation(); scMenuOpen(dove === 'cv' ? 'cvRepMenu' : 'repMenu'); }
function scRangeMenuToggle(ev, dove){ if (ev) ev.stopPropagation(); scMenuOpen(dove === 'cv' ? 'cvRepRangeMenu' : 'repRangeMenu'); }
/* Il pannello porta al Report, ma non quando il tocco e' finito su un pulsante o dentro a un
   menu: quelli hanno gia' un loro mestiere. */
/* 0.9.305, Andrea: nel pannello di "Proteggi i tuoi sogni" un tocco sul grafico che NON cade su una barra porta al Report.
   Una barra che ha un suo mestiere (l'ora di oggi: scOraTap) lo fa e ferma il tocco li'. Solo nel pannello vero
   (#blkReport): la copia nella revisione (conversa.js) sta dentro a un racconto che non si interrompe. */
function scGraficoTap(ev){
  const t = ev && ev.target;
  if (!t || !t.closest || !t.closest('#blkReport')) return;
  if (t.closest('.rp-bars b[onclick]') || t.closest('button') || t.closest('.rep-menu')) return;
  scVaiAlReport();
}
/* Il pannello sta nella pagina "Proteggi i tuoi sogni" (s-blocco), fuori dalla Home: switchTab da solo cambiava la
   scheda dietro, e a schermo non succedeva niente. Prima si torna alla Home, poi si apre il Report. */
function scVaiAlReport(){
  try{ if (typeof order !== 'undefined' && order[cur] !== 's-home' && typeof goId === 'function') goId('s-home'); }catch(_){ }
  switchTab('insights');
}
function scTopTap(ev){
  const t = ev && ev.target;
  if (t && t.closest && (t.closest('button') || t.closest('.rep-menu'))) return;
  /* la copia nella revisione (conversa.js) resta dov'e', come prima */
  if (t && t.closest && t.closest('#blkReport')) scVaiAlReport(); else switchTab('insights');
}
/* "rispetto a ieri", the same way for every quantity: nothing when yesterday is unknown. */
/* 0.9.302: "rispetto a la settimana prima", "Nessun dato su il mese prima": la preposizione si unisce all'articolo */
function scPrep(p, who){
  const a = p === 'su' ? 'su' : 'a';
  let m;
  if ((m = /^la (.*)$/.exec(who))) return a + 'lla ' + m[1];
  if ((m = /^il (.*)$/.exec(who))) return a + 'l ' + m[1];
  if ((m = /^l'(.*)$/.exec(who))) return a + "ll'" + m[1];
  if ((m = /^i (.*)$/.exec(who))) return a + 'i ' + m[1];
  return a + ' ' + who;
}
function scDelta(cur, prev, fmt, unit, vs){
  const who = vs || 'ieri';
  if (!who) return '';
  if (prev === null || prev === undefined) return '<span class="rep-badge flat">Nessun dato ' + scPrep('su', who) + '</span>';
  const diff = cur - prev;
  if (Math.abs(diff) < (unit || 1)) return '<span class="rep-badge flat">= come ' + who + '</span>';
  return '<span class="rep-badge ' + (diff > 0 ? 'up' : 'down') + '">' + (diff > 0 ? '↗ ' : '↘ ') + fmt(Math.abs(diff)) + ' rispetto ' + scPrep('a', who) + '</span>';
}
async function scNotifSettings(pkg){
  if (NATIVE && NATIVE.openAppNotificationSettings){
    try{ await NATIVE.openAppNotificationSettings({ packageName: pkg }); return; }catch(_){ }
  }
  scOpenApp(pkg);
}
/* The small arrow inside a card: fewer than yesterday is green, more is red. */
function scMini(cur, prev){
  if (prev === null || prev === undefined || prev === cur) return '';
  return '<em class="' + (cur < prev ? 'down' : 'up') + '">' + (cur < prev ? '↘ ' : '↗ ') + Math.abs(cur - prev) + '</em>';
}
function scReportRow(onclick, icon, name, width, value){
  return '<div class="rep-row"' + (onclick ? ' onclick="' + onclick + '"' : '') + '>' + icon
    + '<div class="nm"><span>' + name + '</span><i class="track"><b style="width:' + Math.max(4, Math.round(width * 100)) + '%"></b></i></div>'
    + '<b class="tm">' + value + '</b></div>';
}

/* `x` carries the figures of the chosen metric when it is not the screen time:
   { cur, prev, rows } — today's total, yesterday's (null when unknown), the top rows. */
function scReportHtml(r, y, x, v){
  v = scVista(v);
  const metric = scRepMetric();
  const win = scRangeWindow(v.range);
  const screen = r.screenMs || 0;
  const yOk = !!(y && y.granted);
  let top, title, rows, empty, chart = '', extra = '';
  if (metric === 'launch' && x){
    const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
    top = scRangeBtn('🚀 Avvii dell\'app', v) + '<b class="rep-big">' + (sel ? (sel.v || 0) : x.cur) + '</b>'
      + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, n => n + (n === 1 ? ' avvio' : ' avvii'), 1, win.vs));
    chart = scChartHtml(x.buckets, win, scFmtCount, true);
    const righeL = sel ? (SC.oraRighe || []) : x.rows;
    const max = righeL.length ? (righeL[0].launches || 1) : 1;
    title = 'Le app che apri più spesso' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
    rows = righeL.slice(0, 5).map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.launches || 0) / max, (a.launches || 0) + (a.launches === 1 ? ' avvio' : ' avvii'))).join('');
    empty = sel ? 'In quest\'ora nessuna app aperta.' : 'Nessuna app aperta, oggi.';
  } else if (metric === 'web' && x){
    const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
    top = scRangeBtn('🌐 Navigazione', v) + '<b class="rep-big">' + scFmtShort(sel ? (sel.v || 0) : x.cur) + '</b>'
      + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, scFmtShort, 60000, win.vs));
    chart = scChartHtml(x.buckets, win, scFmtMin, true);
    const righeW = sel ? (SC.oraRighe || []) : x.rows;
    const max = righeW.length ? (righeW[0].ms || 1) : 1;
    title = 'Dove navighi di più' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
    rows = righeW.slice(0, 5).map(w => scReportRow('',
      (typeof flFavHtml === 'function' ? flFavHtml(w.host, 'big') : '<span class="ico">' + esc(w.host.charAt(0).toUpperCase()) + '</span>'),
      esc(w.host), (w.ms || 0) / max, scFmtShort(w.ms || 0))).join('');
    empty = sel ? 'In quest\'ora nessun sito registrato.' : 'Nessun sito registrato, oggi: il tempo per sito si misura mentre navighi nei browser supportati.';
  } else if (metric === 'notif' && x){
    if (x.granted === false){
      top = scRangeBtn('🔔 Notifiche', v) + '<b class="rep-big">\u2014</b><span class="rep-badge flat">Serve l\'accesso alle notifiche</span>';
      title = 'Chi ti ha scritto di più'; rows = '';
      empty = '<a href="#" onclick="openPerm(\'notif\');return false">Abilita l\'accesso alle notifiche</a> per contare quante ne arrivano e da quali app.';
    } else {
      const sel = scOraAttiva() && x.buckets && x.buckets[SC.oraSel] ? x.buckets[SC.oraSel] : null;
      top = scRangeBtn('🔔 Notifiche', v) + '<b class="rep-big">' + (sel ? (sel.v || 0) : x.cur) + '</b>'
        + (sel ? '<span class="rep-badge flat">' + scOraFascia(sel.start) + '</span>' : scDelta(x.cur, x.prev, n => n + (n === 1 ? ' notifica' : ' notifiche'), 1, win.vs));
      chart = scChartHtml(x.buckets, win, scFmtCount, true);
      const righeN = sel ? (SC.oraRighe || []) : x.rows;
      const max = righeN.length ? (righeN[0].count || 1) : 1;
      title = 'Chi ti ha scritto di più' + (sel ? ' \u00b7 ' + scOraFascia(sel.start) : '');
      /* Toccare l'app porta alla SUA pagina delle notifiche di Android: la lista non e' una
         classifica, e' l'elenco di cosa spegnere. */
      rows = righeN.slice(0, 5).map(a => scReportRow('scNotifSettings(\'' + esc(a.packageName) + '\')',
        a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
        esc(a.label || a.packageName), (a.count || 0) / max, (a.count || 0) + (a.count === 1 ? ' notifica' : ' notifiche'))).join('');
      empty = sel ? 'In quest\'ora nessuna notifica.' : 'Nessuna notifica, oggi.';
    }
  /* 0.9.292, Andrea: "da quando hai messo il grafico di oggi non compare piu' nessun dato su dove va la tua attenzione".
     Il grafico di oggi arrivava in x ({oggi}) e questo ramo, pensato per gli altri periodi, lo prendeva per buono: niente
     righe e "Nessuna app ha superato il minuto". I dati c'erano tutti: oggi le righe tornano da r.top. */
  } else if (metric === 'screen' && x && !x.oggi){
    extra = '';
    const navX = scNavMs(x.rows || []);
    top = scRangeBtn('⏱ Tempo di schermo', v) + '<b class="rep-big">' + scFmtShort(Math.max(0, x.cur - navX)) + '</b>' + scDelta(Math.max(0, x.cur - navX), x.prev, scFmtShort, 60000, win.vs);
    chart = scChartHtml(x.buckets, win, scFmtMin);
    const righeS = scRigheAttenzione(x.rows || []);
    const max = righeS.length ? (righeS[0].ms || 1) : 1;
    title = 'Dove va la tua attenzione?';
    rows = righeS.slice(0, 5).map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.ms || 0) / max, scFmtShort(a.ms || 0))).join('');
    empty = 'Nessuna app ha superato il minuto.';
  } else {
    const navT = scNavMs(r.top || []), navY = yOk ? scNavMs(y.top || []) : 0;
    top = scRangeBtn('⏱ Tempo di schermo', v) + '<b class="rep-big">' + scFmtShort(Math.max(0, screen - navT)) + '</b>' + scDelta(Math.max(0, screen - navT), yOk && (y.screenMs || 0) > 0 ? Math.max(0, y.screenMs - navY) : null, scFmtShort, 60000);
    const apps = scRigheAttenzione(r.top || []);
    const max = apps.length ? apps[0].ms : 1;
    title = 'Dove va la tua attenzione?';
    rows = apps.map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), a.ms / max, scFmtShort(a.ms))).join('');
    empty = 'Nessuna app ha superato il minuto, oggi.';
    /* IL TEMPO DIETRO AL BLOCCO SCHERMO. Una sveglia che suona, una notifica che accende lo
       schermo, un lettore musicale: il telefono porta davanti un'app senza che nessuno la usi.
       Di serie non si conta — altre app di misura lo contano, e i totali non tornano. Qui si
       dice quanto e', e si lascia scegliere. */
    const lk = r.lockedMs || 0, conta = !!r.countLocked;
    /* Il tempo dietro al blocco schermo non si dice piu' qui: si sceglie dal menu ⋯ del
       pannello (di serie non si conta). */
    SC.countLocked = conta; SC.lockedMs = lk;
  }
  const blocks = r.blocks || 0, yb = yOk ? (y.blocks || 0) : null;
  const pickups = r.pickups || 0, yp = yOk ? (y.pickups || 0) : null;
  /* Le due card (bloccato oggi, sblocchi) restano solo sul tempo di schermo di oggi. Per tutto
     il resto al loro posto c'e' il grafico: in quale ora, in quale giorno. */
  const oggiChart = !chart && x && x.oggi && x.oggi.length ? scChartHtml(x.oggi, win, scFmtMin, true) : '';
  /* L'ORA SCELTA (0.9.299), come nel Report: il numero, il titolo e le app di quell'ora sola */
  if (!chart && x && x.oggi && scOraAttiva() && SC.oraApps && x.oggi[SC.oraSel]){
    const hh = new Date(x.oggi[SC.oraSel].start).getHours();
    const fascia = String(hh).padStart(2, '0') + ':00 - ' + String((hh + 1) % 24).padStart(2, '0') + ':00';
    top = scRangeBtn('\u23f1 Tempo di schermo', v) + '<b class="rep-big">' + scFmtShort(x.oggi[SC.oraSel].v || 0) + '</b><span class="rep-badge flat">' + fascia + '</span>';
    const appsO = scRigheAttenzione(SC.oraApps);
    const maxO = appsO.length ? (appsO[0].ms || 1) : 1;
    title = 'Dove va la tua attenzione? \u00b7 ' + fascia;
    rows = appsO.map(a => scReportRow('scOpenApp(\'' + esc(a.packageName) + '\')',
      a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="ico">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</span>',
      esc(a.label || a.packageName), (a.ms || 0) / maxO, scFmtShort(a.ms || 0))).join('');
    empty = 'In quest\'ora nessuna app ha superato il minuto.';
  }
  const cards = chart ? chart
    : (oggiChart ? '<div class="rep-solo-prot">' + oggiChart + '</div>' : '')
    + '<div class="rep-cards' + (oggiChart ? ' rep-solo-dream' : '') + '">'
    + '<div class="rep-card"><small>Bloccato oggi<i onclick="scTipAt(this, SC_TIPS.blocked)">i</i></small><b>' + blocks + scMini(blocks, yb) + '</b></div>'
    + '<div class="rep-card"><small>Sblocchi<i onclick="scTipAt(this, SC_TIPS.pickups)">i</i></small><b>' + pickups + scMini(pickups, yp) + '</b></div>'
    + '</div>';
  return '<div class="rep-panel">' + scRepMenuHtml(v)
    + '<div class="rep-top" onclick="scTopTap(event)">' + top + '</div>'
    + cards
    + '<div class="rep-att"><b>' + title + '</b>'
    + (rows || '<p class="hintline" style="padding:6px 0 0">' + empty + '</p>') + '</div>'
    + extra
    + '</div>';
}
/* La scelta vale per tutto: la pillola in cima, la bolla del motore, i punteggi. Le giornate
   gia' lette si buttano, altrimenti ieri resterebbe misurato con l'altra regola. */
async function scLockedToggle(on){
  SC.countLocked = !!on;
  try{ if (typeof settingsSave === 'function') await settingsSave({ usageCountLocked: !!on }); }catch(_){ }
  SC.mem = {};
  Object.keys(SC_MEM_TEL).forEach(function(k){ delete SC_MEM_TEL[k]; });
  try{ Object.keys(localStorage).forEach(function(k){ if (k.indexOf('fl_dayrep_') === 0) localStorage.removeItem(k); }); }catch(_){ }
  try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ }
  try{ if (typeof flHeaderSync === 'function') flHeaderSync(); }catch(_){ }
}
const SC_TIPS = {
  blocked: 'Ogni volta che un\'app o un sito bloccato ha provato ad aprirsi, l\'abbiamo bloccato. Questo è il tuo totale di oggi.',
  pickups: 'Quante volte hai sbloccato il telefono oggi. Più sblocchi di solito significano più occasioni di distrazione.'
};

/* A real tooltip: a dark bubble floating over the page, its arrow on the "i" it explains. */
function scTipAt(anchor, text, extra){
  if (!anchor) return;
  const phone = document.getElementById('phone');
  let tip = document.getElementById('scTip');
  if (!tip){
    tip = document.createElement('div');
    tip.id = 'scTip';
    tip.className = 'sc-tip';
    tip.innerHTML = '<i class="arrow"></i><span class="txt"></span>';
    phone.appendChild(tip);
    document.addEventListener('touchstart', function(ev){ if (tip.style.display === 'block' && !tip.contains(ev.target)) scTipHide(); }, { passive: true });
  }
  clearTimeout(SC.tipTimer);
  SC.held = Date.now();
  if (tip.style.display === 'block' && tip.dataset.for === text){ scTipHide(); return; }
  tip.dataset.for = text;
  const box = tip.querySelector('.txt');
  /* DUE COSE DIVERSE NELLO STESSO FUMETTO: la spiegazione, che e' prosa e si legge da
     sinistra, e i numeri, che si guardano. La riga vuota che gia' li divideva nel testo
     diventa il taglio fra i due blocchi, e i numeri vanno al centro. */
  const pezzi = String(text).split('\n\n');
  box.textContent = pezzi[0];
  if (pezzi.length > 1){
    /* I record sono un ELENCO: a sinistra, un punto davanti a ognuno. Centrati, righe di
       lunghezza diversa fanno uno zig-zag che l'occhio non riesce a scorrere. */
    const ul = document.createElement('ul');
    ul.className = 'dati';
    pezzi.slice(1).join('\n').split('\n').forEach(function(r){
      r = String(r).trim();
      if (!r) return;
      const li = document.createElement('li');
      li.textContent = r;
      ul.appendChild(li);
    });
    box.appendChild(ul);
  }
  if (extra) box.insertAdjacentHTML('beforeend', extra);
  tip.style.display = 'block';
  const pr = phone.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
  const width = Math.min(pr.width - 24, 290);
  tip.style.width = width + 'px';
  let left = ar.left + ar.width / 2 - pr.left - width / 2;
  left = Math.max(12, Math.min(pr.width - width - 12, left));
  tip.style.left = left + 'px';
  tip.style.top = (ar.bottom - pr.top + 10) + 'px';
  tip.querySelector('.arrow').style.left = (ar.left + ar.width / 2 - pr.left - left - 7) + 'px';
  SC.tipTimer = setTimeout(scTipHide, extra ? 12000 : 7000);
}
function scTipHide(){ const t = document.getElementById('scTip'); if (t) t.style.display = 'none'; }
function scOpenApp(pkg){
  /* da dove si arriva (0.9.203): tornando indietro si torna LI', non nel Report */
  try{ const b = document.getElementById('s-blocco'); INS.detailFrom = (b && b.classList.contains('active')) ? 'blocco' : ''; }catch(_){ }
  if (typeof insOpenDetail === 'function'){ INS.dayOff = 0; insOpenDetail(pkg); }
  else switchTab('insights');
}
document.addEventListener('fl:tab', function(e){
  scTipHide();
  if (!e) return;
  if (e.detail === 'profilo') scoresRefresh();
  // Blocco owns the phrase of the day and the screen time; the Profile owns the score.
  if (e.detail === 'blocco'){ scBlockScores(); if (typeof blkHeroReplay === 'function') blkHeroReplay(); }
  // Coming to Modalita severa re-reads the streak and the two figures in its sky.
  if (e.detail === 'severa' && typeof sevSyncTab === 'function') sevSyncTab();
  // The Report closes on what this pace costs over the years that are left.
  if (e.detail === 'severa') setTimeout(scLifePaint, 260);
});

/* ---------------------------------------------------------------------------------------
   BLOCCO TAB - the phrase of the day in the slideshow, the screen time under it
   --------------------------------------------------------------------------------------- */

/** Il pannello quando il dispositivo scelto non ha ancora mandato niente oggi. */
function scSenzaDatiHtml(r, v){
  const pc = r && r.fonte === 'computer';
  const quiPc = typeof mwQuiComputer === 'function' && mwQuiComputer();
  const altro = pc ? !quiPc : quiPc;
  return '<div class="rep-panel rep-senza">' + scRepMenuHtml(v)
    + '<div class="rep-top"><b class="rep-senza-t">' + (pc ? '💻 Il computer' : (r && r.fonte === 'insieme' ? '🔗 Telefono e computer' : '📱 Il telefono')) + '</b>'
    + '<p class="rep-senza-p">' + (altro ? (pc ? 'Oggi il computer non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul computer.' : 'Oggi il telefono non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul telefono.') : 'Oggi non ci sono ancora dati da mostrare.') + '</p>'
    + (pc && !quiPc && typeof mwScegli === 'function' ? '<button type="button" class="rep-senza-b" onclick="mwScegli(\'telefono\')">📱 Mostra i dati del telefono</button>' : '')
    + '</div></div>';
}
async function scBlockScores(){
  if (typeof blkHeroEnsure !== 'function') return;
  blkHeroEnsure();

  // 1. the phrase, into the first slide
  const el = document.getElementById('bhQuote'), au = document.getElementById('bhQuoteAuthor');
  if (el){
    scQuotes().then(function(q){
      const pick = scQuoteFor(q, 0);
      if (!pick) return;
      el.dataset.text = pick.text;
      if (au) au.textContent = '~ ' + pick.author;
      /* Come sulla pagina Wishlist del sito: i primi dieci caratteri e "Scopri di piu'". La
         frase si scrive a macchina — col suo suono — solo quando la si chiede. Prima partiva
         da sola a ogni rotazione delle slide, e il suono di una macchina da scrivere che
         parte mentre stai facendo altro non e' un effetto, e' un disturbo. */
      if (SC.typed){ el.textContent = pick.text; scShowDetails(); }
      else scQuotePreview(pick.text);
      scLockQuoteDaily(q);
    });
  }

  // 2. the screen time, between the sky and the quick block
  const rep = (typeof blkReportEnsure === 'function') ? blkReportEnsure() : null;
  if (!rep) return;
  const out = await scPannelloHtml(scVista());
  /* 0.9.291, Andrea: "entrando in un programma e uscendo sparisce il pannello della panoramica". Salvando un programma
     il motore e' occupato a riscrivere le regole e la lettura del giorno torna vuota: quel vuoto cancellava il
     pannello. Una lettura fallita non e' un "permesso negato": il pannello resta com'era e si riprova fra poco. */
  if (out.riprova){
    if (!scBlockScores._riprova){ scBlockScores._riprova = setTimeout(function(){ scBlockScores._riprova = 0; scBlockScores(); }, 1500); }
    return;
  }
  if (out.annulla) return;   // the person switched again while we were reading
  rep.innerHTML = out.html;
  if (out.dopa){ try{ if (typeof dpVivo === 'function') dpVivo(); }catch(_){ } }
  /* 0.9.302: la copia del pannello nella rivelazione (conversa.js) segue ogni cambio: metrica, dispositivo, ora toccata */
  try{ if (typeof cvPanRidisegna === 'function') cvPanRidisegna(); }catch(_){ }
}

/**
 * IL PANNELLO "DOVE VA LA TUA ATTENZIONE?", per chiunque lo mostri (0.9.302).
 *
 * <p>Prima viveva dentro a scBlockScores e la rivelazione della revisione e del Rientra in rotta (conversa.js) se ne
 * era fatto un altro a mano: niente tre puntini, il titolo "Oggi sul telefono" fisso, e i numeri chiesti al motore
 * senza passare dal rapporto del giorno. Con i dati del computer scelti e il computer che oggi non aveva mandato
 * niente, la copia diceva "0min" e "Nessuna app ha superato il minuto" mentre "Proteggi i tuoi sogni" diceva il vero.
 * Adesso il pannello e' uno: `v` dice solo dove sta (dove), su quale periodo (range) e quale metrica.</p>
 *
 * Torna { html } da mettere a schermo, { riprova } se il motore non ha risposto, { annulla } se nel frattempo la
 * scelta e' cambiata, { negato } se manca il permesso di misura.
 */
async function scPannelloHtml(v){
  v = scVista(v);
  if (!scHaGiornata()) return { html: '' };
  let r = await scReport(0);
  if (!r) return { riprova: true };
  /* 0.9.301: il dispositivo scelto oggi non ha dati (il computer spento): il pannello resta, con i tre puntini per
     cambiare sorgente e una frase vera. Prima spariva, e con lui la strada per tornare ai dati del telefono.
     0.9.302: vale per oggi. Sugli altri periodi i giorni passati ci sono (i totali che il computer pubblica). */
  if (!r.granted && r.senzaDati){
    if (v.range === 'today') return { html: scSenzaDatiHtml(r, v) };
    r = { granted: true, dayStart: scDayStart(0), screenMs: 0, top: [], blocks: 0, pickups: 0 };
  }
  if (!r.granted) return { html: '', negato: true };
  const y = await scReport(1);
  // the other two quantities are fetched only when they are the ones on screen
  let x = null;
  const metric = scRepMetric();
  const range = v.range;
  const win = scRangeWindow(range);
  try{
    if (metric === 'launch' && NATIVE.getScreenTimeRange && NATIVE.getTopApps){
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      const b = win.pto ? await NATIVE.getScreenTimeRange({ from: win.pfrom, to: win.pto, bucket: 'none' }) : null;
      const t = await NATIVE.getTopApps({ from: win.from, to: win.to, limit: 5, by: 'launches' });
      x = { cur: a.launches || 0, prev: b && (y && y.granted) ? (b.launches || 0) : null, rows: t.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.launches || 0 })) };
    } else if (metric === 'web' && NATIVE.getWebTime){
      const a = await NATIVE.getWebTime({ from: win.from, to: win.to, bucket: win.bucket, limit: 5 });
      const b = win.pto ? await NATIVE.getWebTime({ from: win.pfrom, to: win.pto, bucket: 'none', limit: 1 }) : null;
      x = { cur: a.ms || 0, prev: b ? (b.ms || 0) : null, rows: a.sites || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    } else if (metric === 'notif' && NATIVE.getNotifications){
      const a = await NATIVE.getNotifications({ from: win.from, to: win.to, bucket: win.bucket, limit: 5 });
      const b = win.pto ? await NATIVE.getNotifications({ from: win.pfrom, to: win.pto, limit: 1 }) : null;
      x = { granted: a.granted !== false, cur: a.total || 0, prev: (a.granted === false || !b) ? null : (b.total || 0), rows: a.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.count || 0 })) };
    } else if (metric === 'screen' && range === 'today' && NATIVE.getScreenTimeRange){
      /* 0.9.290, Andrea: "nella pagina Proteggi i tuoi sogni voglio il grafico anche per oggi; i due pannelli Bloccato
         oggi e Sblocchi restano solo nella panoramica di Dream". Il grafico di oggi si legge sempre: lo stesso pannello
         passa da una pagina all'altra e lo foglio di stile mostra quello giusto. */
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      x = { oggi: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    } else if (metric === 'screen' && range !== 'today' && NATIVE.getScreenTimeRange && NATIVE.getTopApps){
      const a = await NATIVE.getScreenTimeRange({ from: win.from, to: win.to, bucket: win.bucket });
      const b = win.pto ? await NATIVE.getScreenTimeRange({ from: win.pfrom, to: win.pto, bucket: 'none' }) : null;
      const t = await NATIVE.getTopApps({ from: win.from, to: win.to, limit: 9, by: 'ms' });
      x = { cur: a.ms || 0, prev: b ? (b.ms || 0) : null, rows: t.apps || [],
            buckets: (a.buckets || []).map(k => ({ start: k.start, v: k.ms || 0 })) };
    }
  }catch(_){ x = null; }
  if (scRepMetric() !== metric || (v.dove !== 'cv' && scRepRange() !== range)) return { annulla: true };
  if (metric === 'dopa' && typeof dpCardHtml === 'function'){
    let d = null;
    try{ d = await dpCalcola(); }catch(_){ d = null; }
    if (scRepMetric() !== 'dopa') return { annulla: true };
    return { html: '<div class="rep-panel rep-dopa">' + scRepMenuHtml(v) + dpCardHtml(d, 'panoramica', 'giorno') + '</div>', dopa: true };
  }
  return { html: scRepMetricsHtml() + scReportHtml(r, y, x, v) };
}

/* The outline of a rounded rectangle, from the top centre, clockwise: the arc has to start
   where a gauge starts and travel the way a clock does. */
function scRoundedPath(w, h, r){
  return 'M' + (w / 2) + ' 0'
    + 'H' + (w - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + w + ' ' + r
    + 'V' + (h - r) + 'A' + r + ' ' + r + ' 0 0 1 ' + (w - r) + ' ' + h
    + 'H' + r + 'A' + r + ' ' + r + ' 0 0 1 0 ' + (h - r)
    + 'V' + r + 'A' + r + ' ' + r + ' 0 0 1 ' + r + ' 0Z';
}
/*
 * Each ring draws itself from nothing to its percentage.
 *
 * The first attempt drew an SVG <rect> in a viewBox with preserveAspectRatio="none" and then
 * rotated it -90deg to start the stroke at the top. Both were wrong: the stretch distorted
 * the stroke, and rotating a wide rectangle by a quarter turn stands it on end - which is the
 * vertical capsule that appeared around "Focus". The path is now built from the pill's real
 * size in pixels, so there is nothing to stretch and nothing to rotate.
 */
function scAnimateArcs(root){
  if (!root) return;
  root.querySelectorAll('.bs-pill .cap').forEach(function(cap){
    const svg = cap.querySelector('svg.arc'), path = cap.querySelector('svg.arc path');
    if (!svg || !path) return;
    const w = cap.clientWidth, h = cap.clientHeight;
    if (!w || !h) return;
    const r = h / 2;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    path.setAttribute('d', scRoundedPath(w, h, r));
    let len = 2 * (w + h);
    try{ if (path.getTotalLength) len = path.getTotalLength() || len; }catch(_){ }
    const pct = Math.max(0, Math.min(100, +path.dataset.pct || 0));
    path.style.transition = 'none';
    path.style.strokeDasharray = len;
    path.style.strokeDashoffset = len;
    // one frame with the ring empty, so the browser has something to animate away from
    requestAnimationFrame(function(){
      requestAnimationFrame(function(){
        path.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)';
        path.style.strokeDashoffset = len * (1 - pct / 100);
      });
    });
  });
}

/* ---------------------------------------------------------------------------------------
   ISPIRAZIONE QUOTIDIANA
   --------------------------------------------------------------------------------------- */

registerScreen('s-inspire',
  '<div class="insp-sky">'
  + '<div class="topbar insp-bar"><button class="iconbtn light" onclick="goId(\'s-home\')">‹</button><b>Ispirazione quotidiana</b></div>'
  + '<div class="insp-days" id="inspDays"></div>'
  + '<div class="insp-body" id="inspBody"></div>'
  + '<div class="insp-acts"><button class="insp-act" onclick="scInspireShare()" aria-label="Condividi">'
  +   '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'
  +     '<g transform="translate(-1,0)"><circle cx="17.2" cy="5" r="2.8"></circle><circle cx="6" cy="12" r="2.8"></circle>'
  +     '<circle cx="17.2" cy="19" r="2.8"></circle><line x1="9" y1="13" x2="14.7" y2="17"></line>'
  +     '<line x1="14.7" y1="7" x2="9" y2="10"></line></g></svg></button></div>'
  + '<div class="insp-share-menu" id="inspShareMenu" hidden>'
  +   '<button type="button" onclick="scShareImage()"><b>Immagine con la frase</b><small>per le storie, con lo sfondo del giorno</small></button>'
  +   '<button type="button" onclick="scShareText()"><b>Solo il testo</b><small>frase e autore, da incollare ovunque</small></button>'
  + '</div>'
  + '<p class="insp-credit" id="inspCredit"></p>'
  + '<div class="insp-lock"><div><b>Aggiorna citazione su schermata di blocco</b><small id="inspLockSub">Ogni giorno la frase nuova diventa il tuo sfondo di blocco.</small></div>'
  + '<button class="switch" id="inspLockSw" onclick="scToggleLockQuote()"></button></div>'
  /* 0.9.264 (Premium): al posto della frase del giorno, le frasi sul tuo obiettivo scritte dall'agente (frasi-obiettivo.js) */
  + '<div class="insp-lock" id="foRiga"></div></div>',
  { back: function(){ switchTab('profilo'); return 's-home'; } });

async function scOpenInspire(){
  SC.insDay = 0;
  goId('s-inspire');
  // no starfield here: the twinkling pulled the eye off the phrase, which is the whole page
  scInspirePaint();
  try{ if (typeof foRigaPaint === 'function') foRigaPaint(); }catch(_){ }
  if (NATIVE && NATIVE.getLockQuote){
    try{
      const st = await NATIVE.getLockQuote();
      const sw = document.getElementById('inspLockSw');
      if (sw) sw.className = 'switch' + (st && st.on ? ' on' : '');
      try{ if (st && st.on) localStorage.setItem('fl_lockquote_on', '1'); }catch(_){ }
      const sub = document.getElementById('inspLockSub');
      if (sub && st && !st.supported) sub.textContent = 'Non disponibile su questa versione di Android.';
    }catch(_){ }
  }
}
/* ---- the background of the day: one of the store's own artworks ----------------------------

   The images come from /api/focuslock/backgrounds, which reads the motivational, spiritual and
   landscape collections of the shop. The day picks its picture with the same arithmetic the
   phrase uses (epoch day modulo the list), so everyone sees the same artwork on the same day,
   and yesterday's chip shows yesterday's. Without network the night sky stays. */
const SC_BG_URL = 'https://meta-ai-media-buyer-production.up.railway.app/api/focuslock/backgrounds';
async function scBackgrounds(){
  // Only a list with something in it is worth remembering: an empty answer (the server was
  // restarting, the phone was offline for a second) must be asked again next time, not kept
  // for the whole session as "there are no pictures".
  if (SC.bgs && SC.bgs.length) return SC.bgs;
  const day = scKey(scDayStart(0));
  try{
    const c = JSON.parse(localStorage.getItem('fl_bgs') || 'null');
    if (c && c.day === day && Array.isArray(c.items) && c.items.length){ SC.bgs = c.items; return SC.bgs; }
  }catch(_){ }
  try{
    // Through the native client, like the quotes: a fetch from the WebView is a cross-origin
    // request the server does not answer for, and it failed on every phone.
    let j = null;
    if (NATIVE && NATIVE.publicApi) j = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/backgrounds' });
    else { const r = await fetch(SC_BG_URL, { cache: 'no-store' }); j = await r.json(); }
    if (j && Array.isArray(j.items) && j.items.length){
      SC.bgs = j.items;
      try{ localStorage.setItem('fl_bgs', JSON.stringify({ day: day, items: j.items })); }catch(_){ }
      return SC.bgs;
    }
  }catch(_){ }
  // stale copy beats no copy
  try{ const c = JSON.parse(localStorage.getItem('fl_bgs') || 'null'); if (c && c.items && c.items.length){ SC.bgs = c.items; return SC.bgs; } }catch(_){ }
  SC.bgs = [];
  return SC.bgs;
}
/* ---------------------------------------------------------------------------------------
   Lo sfondo del giorno.

   Nessuna intelligenza artificiale: la scelta è una riga di aritmetica. Un'opera dello store
   compare SOLO se il titolo (inglese) contiene una parola della frase del giorno — le frasi
   sono italiane, quindi le parole passano da un piccolo vocabolario italiano→inglese scritto
   a mano qui sotto. Se nessun quadro corrisponde, lo sfondo è uno degli otto paesaggi
   minimal disegnati dall'app (www/img/bg), scelti a rotazione per giorno.
   --------------------------------------------------------------------------------------- */
const SC_MIN_BGS = [
  { image: 'img/bg/alba.jpg',     title: 'Alba',              minimal: true },
  { image: 'img/bg/montagne.jpg', title: 'Montagne',          minimal: true },
  { image: 'img/bg/mare.jpg',     title: 'Mare',              minimal: true },
  { image: 'img/bg/foresta.jpg',  title: 'Foresta',           minimal: true },
  { image: 'img/bg/dune.jpg',     title: 'Dune',              minimal: true },
  { image: 'img/bg/aurora.jpg',   title: 'Aurora',            minimal: true },
  { image: 'img/bg/nebbia.jpg',   title: 'Nebbia',            minimal: true },
  { image: 'img/bg/luna.jpg',     title: 'Luna',              minimal: true }
];
const SC_IT_EN = {
  sogno:['dream'], sogni:['dream','dreams'], sognare:['dream'], sognatore:['dreamer'],
  tempo:['time'], ora:['now'], oggi:['today'], domani:['tomorrow'], futuro:['future'],
  fuoco:['fire','burn'], luce:['light'], buio:['dark'], notte:['night'], giorno:['day'],
  stella:['star'], stelle:['stars','star'], cielo:['sky'], luna:['moon'], sole:['sun','sunrise'],
  mare:['sea','ocean'], onda:['wave'], onde:['waves'], montagna:['mountain'], montagne:['mountains'],
  vetta:['peak','summit'], strada:['road'], cammino:['path'], viaggio:['journey'], passo:['step'],
  silenzio:['silence'], calma:['calm'], pace:['peace'], respiro:['breathe','breath'],
  liberta:['freedom'], libero:['free'], coraggio:['courage','brave'], paura:['fear','fearless'],
  mente:['mind','mindset'], pensiero:['thought'], anima:['soul'], cuore:['heart'],
  forza:['strength','power'], forte:['strong'], disciplina:['discipline'], abitudine:['habit'],
  focus:['focus'], concentrazione:['focus','focused'], attenzione:['attention'],
  successo:['success'], vittoria:['victory','win'], vincere:['win'], obiettivo:['goal'], obiettivi:['goals'],
  lavoro:['work','hustle'], fatica:['grind'], pazienza:['patience'], costanza:['consistency'],
  crescita:['growth'], crescere:['grow'], vita:['life','live'], vivere:['live'],
  credere:['believe'], fede:['faith'], speranza:['hope'], amore:['love'], passione:['passion'],
  energia:['energy'], destino:['destiny'], inizio:['start','beginning'], iniziare:['start','begin'],
  mai:['never'], sempre:['always'], possibile:['possible'], impossibile:['impossible'],
  foresta:['forest'], albero:['tree'], alberi:['trees'], ali:['wings'], volare:['fly'],
  casa:['home'], terra:['earth'], mondo:['world'], universo:['universe'], magia:['magic'],
  ricordo:['memory'], memoria:['memory'], errore:['mistake'], cadere:['fall'], rialzarsi:['rise'],
  salire:['rise','climb'], sorriso:['smile'], gratitudine:['gratitude'], scelta:['choice'], scegliere:['choose']
};
function scWords(t){
  return String(t || '').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length >= 3);
}
/* The English tokens a phrase is about: its own words (some phrases are English already)
   plus the translations of the Italian ones. */
function scEnTokens(text){
  const out = {};
  scWords(text).forEach(w => {
    if (w.length >= 4) out[w] = 1;
    (SC_IT_EN[w] || []).forEach(e => { out[e] = 1; });
    // "sogni" and "sogno" both reach "sogn-": a light stem for the commonest endings
    const stem = w.replace(/(are|ere|ire|zione|mente|i|o|e|a)$/, '');
    if (stem.length >= 4) (SC_IT_EN[stem] || []).forEach(e => { out[e] = 1; });
  });
  return Object.keys(out);
}
function scMatchesQuote(item, tokens){
  const words = scWords((item.title || '') + ' ' + (item.handle || '').replace(/-/g, ' '));
  const set = {};
  words.forEach(w => { set[w] = 1; if (w.endsWith('s')) set[w.slice(0, -1)] = 1; else set[w + 's'] = 1; });
  return tokens.some(t => set[t] === 1);
}
/* `list` are the store's works, `quote` the phrase of the day. Same day, same picture, for
   everyone: the index is the epoch day. */
function scPickBg(list, off, quote){
  const epochDay = Math.floor(scDayStart(off) / SC_DAY_MS);
  const pickFrom = arr => arr[((epochDay % arr.length) + arr.length) % arr.length];
  if (list && list.length && quote && quote.text){
    const tokens = scEnTokens(quote.text + ' ' + (quote.author || ''));
    const hits = list.filter(it => scMatchesQuote(it, tokens));
    if (hits.length) return pickFrom(hits);
  }
  return pickFrom(SC_MIN_BGS);
}
/* kept for any older call site */
function scBgFor(list, off){ return scPickBg(list, off, null); }
function scInspireBg(bg){
  const sky = document.querySelector('.insp-sky');
  if (!sky) return;
  if (!bg){ sky.style.backgroundImage = ''; return; }
  // paint only once the picture is in, so the sky never flashes empty between two days
  const im = new Image();
  im.onload = function(){
    sky.style.backgroundImage = 'linear-gradient(180deg,rgba(3,10,26,.5),rgba(3,10,26,.86)),url("' + bg.image + '")';
  };
  im.src = bg.image;
}

async function scInspirePaint(){
  const q = await scQuotes();
  const days = document.getElementById('inspDays'), body = document.getElementById('inspBody');
  if (!days || !body) return;
  /* LE FRASI DEI GIORNI PASSATI SONO PREMIUM (Andrea, 30/09): i sei giorni prima di oggi
     portano il lucchetto per chi non ce l'ha. Oggi e' di tutti. */
  const prem = (typeof adsUserIsPremium === 'function') ? adsUserIsPremium() : false;
  let chips = '';
  for (let off = 6; off >= 0; off--){
    const d = new Date(scDayStart(off));
    const chiuso = off > 0 && !prem;
    chips += '<button class="insp-day' + (off === SC.insDay ? ' on' : '') + (chiuso ? ' chiuso' : '') + '" onclick="scInspireDay(' + off + ')">' + d.getDate() + (chiuso ? '<i class="insp-lock-ico">🔒</i>' : '') + '</button>';
  }
  days.innerHTML = chips;
  const pick = scQuoteFor(q, SC.insDay);
  const d = new Date(scDayStart(SC.insDay));
  body.innerHTML = '<div class="insp-date"><b>' + d.getDate() + '</b><span>' + SC_MONTHS[d.getMonth()] + ' ' + d.getFullYear() + '</span></div>'
    + (pick
        ? '<p class="insp-quote" id="inspQuote">' + flHeroLine(pick.text, 0) + '</p><p class="insp-author">~ ' + esc(pick.author) + '</p>'
        : '<p class="insp-quote">Per questo giorno non ho ancora una frase.</p>');
  scInspireMenu(false);
  const bgs = await scBackgrounds();
  const bg = scPickBg(bgs, SC.insDay, pick);
  SC.insBg = bg;
  scInspireBg(bg);
  const credit = document.getElementById('inspCredit');
  if (credit){
    credit.innerHTML = !bg ? ''
      /* 0.9.302, Andrea: gli sfondi disegnati dall'app non si firmano ("Sfondo Aurora · disegnato da DreamMap" via) */
      : (bg.minimal ? ''
                    : 'Opera: <b>' + esc(bg.title) + '</b> · parla di questa frase · dream-brothers.com');
    credit.onclick = (bg && !bg.minimal) ? function(){ if (typeof ufOpenUrl === 'function') ufOpenUrl(bg.url); } : null;
  }
}
function scInspireDay(off){
  if (off > 0 && !((typeof adsUserIsPremium === 'function') && adsUserIsPremium())){
    toast('Le frasi dei giorni scorsi si aprono con Premium');
    try{ if (typeof premiumBuy === 'function') premiumBuy(); }catch(_){ }
    return;
  }
  SC.insDay = off; scInspirePaint();
}

/* ---- sharing: the words alone, or the picture with the words on it ----------------------- */
function scInspireMenu(open){
  const m = document.getElementById('inspShareMenu');
  if (!m) return;
  if (typeof open !== 'boolean') open = m.hidden;
  m.hidden = !open;
}
/* The store's phrases arrive already wrapped in quotation marks; a second pair printed
   ""…"" on the story. Quote only what is not quoted. */
function scQuoted(t){ return /^["“«]/.test(t) ? t : '"' + t + '"'; }
function scShareCaption(pick){
  return scQuoted(pick.text) + '\n~ ' + pick.author + '\n\n— la mia ispirazione di oggi su DreamMap';
}
async function scShareText(){
  scInspireMenu(false);
  const q = await scQuotes();
  const pick = scQuoteFor(q, SC.insDay);
  if (!pick){ toast('Niente da condividere'); return; }
  const txt = scShareCaption(pick);
  try{
    if (NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: txt, title: 'Frase del giorno' }); return; }
    if (navigator.share){ await navigator.share({ text: txt }); return; }
    if (navigator.clipboard){ await navigator.clipboard.writeText(txt); toast('Copiata negli appunti'); return; }
  }catch(_){ return; }
  toast('Condivisione non disponibile qui');
}
/* A 1080x1920 story: the day's artwork, the veil, the phrase set large, the author, the mark. */
async function scShareImage(){
  scInspireMenu(false);
  const q = await scQuotes();
  const pick = scQuoteFor(q, SC.insDay);
  if (!pick){ toast('Niente da condividere'); return; }
  toast('Preparo l\'immagine…');
  const W = 1080, H = 1920;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  const bg = SC.insBg;
  const paintBase = () => {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#020926'); g.addColorStop(.35, '#06214F'); g.addColorStop(.65, '#1B4E8C'); g.addColorStop(1, '#08295B');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  };
  const drawCover = (im) => {
    const s = Math.max(W / im.width, H / im.height);
    const w = im.width * s, h = im.height * s;
    ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h);
  };
  const loadImg = (src) => new Promise((ok, ko) => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => ok(im); im.onerror = ko; im.src = src; });
  try{
    if (bg) drawCover(await loadImg(bg.image)); else drawCover(await loadImg('img/dream-night.jpg'));
  }catch(_){ paintBase(); }
  // the veil, so the words read on any picture
  const veil = ctx.createLinearGradient(0, 0, 0, H);
  veil.addColorStop(0, 'rgba(3,10,26,.55)'); veil.addColorStop(.5, 'rgba(3,10,26,.62)'); veil.addColorStop(1, 'rgba(3,10,26,.9)');
  ctx.fillStyle = veil; ctx.fillRect(0, 0, W, H);
  // the words
  ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
  const wrap = (text, font, maxW) => {
    ctx.font = font;
    const words = text.split(' '), lines = []; let line = '';
    words.forEach(w => { const t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line){ lines.push(line); line = w; } else line = t; });
    if (line) lines.push(line);
    return lines;
  };
  const quote = scQuoted(pick.text);
  let size = 72;
  let lines = wrap(quote, '700 ' + size + 'px Poppins, sans-serif', W - 240);
  while (lines.length > 8 && size > 44){ size -= 4; lines = wrap(quote, '700 ' + size + 'px Poppins, sans-serif', W - 240); }
  const lh = size * 1.32;
  let y = H / 2 - (lines.length * lh) / 2 + size * 0.35;
  ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 6;
  ctx.font = '700 ' + size + 'px Poppins, sans-serif';
  lines.forEach(l => { ctx.fillText(l, W / 2, y); y += lh; });
  ctx.font = 'italic 500 40px Poppins, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.88)';
  ctx.fillText('~ ' + pick.author, W / 2, y + 30);
  ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
  // the mark at the foot
  ctx.font = '800 34px Montserrat, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.9)';
  ctx.fillText('DreamMap', W / 2, H - 150);
  ctx.font = '500 26px Poppins, sans-serif'; ctx.fillStyle = 'rgba(255,255,255,.6)';
  ctx.fillText(bg ? 'Opera: ' + bg.title + ' · dream-brothers.com' : 'dream-brothers.com', W / 2, H - 104);
  let data;
  try{ data = cv.toDataURL('image/png'); }
  catch(e){ toast('Non riesco a comporre l\'immagine con questo sfondo'); return; }
  const caption = scShareCaption(pick) + (bg ? '\n' + bg.url : '');
  try{
    if (NATIVE && NATIVE.shareImage){ await NATIVE.shareImage({ base64: data, title: 'Frase del giorno', text: caption }); return; }
    if (navigator.share && navigator.canShare){
      const blob = await (await fetch(data)).blob();
      const file = new File([blob], 'focuslock-frase.png', { type: 'image/png' });
      if (navigator.canShare({ files: [file] })){ await navigator.share({ files: [file], text: caption }); return; }
    }
  }catch(_){ return; }
  toast('Condivisione immagine non disponibile qui');
}
/* kept as the button's entry point: it opens the two choices */
function scInspireShare(){ scInspireMenu(); }
async function scToggleLockQuote(){
  const sw = document.getElementById('inspLockSw');
  if (!sw) return;
  const on = !sw.classList.contains('on');
  if (!NATIVE || !NATIVE.setLockQuote){ toast('Disponibile nell\'app installata'); return; }
  if (!on){
    try{ await NATIVE.setLockQuote({ on: false }); }catch(_){ }
    try{ localStorage.removeItem('fl_lockquote_on'); }catch(_){ }
    try{ const fo = JSON.parse(localStorage.getItem('fl_frasi_obiettivo') || 'null'); if (fo && fo.on){ fo.on = false; localStorage.setItem('fl_frasi_obiettivo', JSON.stringify(fo)); if (typeof foRigaPaint === 'function') foRigaPaint(); } }catch(_){ }
    sw.className = 'switch';
    toast('Lo sfondo di blocco resta quello che c\'è ora');
    return;
  }
  const q = await scQuotes();
  const pick = scQuoteFor(q, 0);
  if (!pick){ toast('Non ho ancora una frase da mettere'); return; }
  try{
    await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: scKey(scDayStart(0)) });
    sw.className = 'switch on';
    try{ localStorage.setItem('fl_lockquote_on', '1'); }catch(_){ }
    try{ if (typeof rscPaint === 'function') rscPaint(); }catch(_){ }
    toast('Fatto: guarda la schermata di blocco');
  }catch(e){ toast(e && e.message ? e.message : 'Non riuscito'); }
}
/* Once a day, silently: the switch promised a phrase that changes, not one frozen on the day
   it was turned on. */
async function scLockQuoteDaily(q){
  if (!NATIVE || !NATIVE.getLockQuote || !NATIVE.setLockQuote) return;
  try{
    const st = await NATIVE.getLockQuote();
    if (!st || !st.on) return;
    const today = scKey(scDayStart(0));
    const pick = scQuoteFor(q, 0);
    if (!pick) return;
    /* LA SCORTA.
       A mezzanotte questa pagina non esiste: l'app e' chiusa, e la frase sullo sfondo restava
       quella del giorno prima finche' qualcuno non la riapriva. Adesso il telefono si porta
       avanti tre settimane di frasi e se la cava da solo, con la sua sveglia. */
    const pool = scLockPool(q);
    if (st.day === today){
      try{ await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: today, pool: pool }); }catch(_){ }
      return;
    }
    await NATIVE.setLockQuote({ on: true, text: pick.text, author: pick.author, day: today, pool: pool });
  }catch(_){ }
}

/* Le frasi dei prossimi ventuno giorni, nello stesso ordine che userebbe questa pagina.

   Se il server ne ha mandata una sola, la scorta si costruisce sull'elenco di riserva che l'app
   si porta dentro: una scorta con dentro solo oggi non e' una scorta, ed e' esattamente il caso
   in cui domani lo sfondo resterebbe fermo a ieri. */
function scLockPool(q){
  const out = [];
  /* La stessa funzione che usa la pagina, per tutti e ventuno i giorni: due aritmetiche
     diverse per la stessa cosa divergono sempre, e qui divergerebbero in silenzio — la
     schermata di blocco direbbe una frase e l'app un'altra, lo stesso giorno. */
  const vuoto = ((q && q.list) || []).filter(Boolean).length < 2;
  const qq = vuoto ? { today: '', list: SC_FALLBACK_QUOTES.slice() } : q;
  for (let i = 0; i < 21; i++){
    try{
      const p = scQuoteFor(qq, -i);
      if (!p) continue;
      out.push({ d: scKey(scDayStart(-i)), t: p.text, a: p.author || '' });
    }catch(_){ }
  }
  return out;
}

/* ---------------------------------------------------------------------------------------
   BREAKDOWN SCREEN
   --------------------------------------------------------------------------------------- */

registerScreen('s-score',
  /* 0.9.281, Andrea (come la pagina Sleep che ha mandato): il titolo del punteggio, le tab Giorno, Settimana,
     Mese, Anno, sotto le frecce dei giorni, poi il tachimetro, il pannello con la spiegazione e i fattori. */
  '<div class="topbar sc-top"><button class="iconbtn" onclick="scClose()">‹</button><b class="sc-titolo" id="scTitolo">Punteggio</b></div>'
  + '<div class="sc-per" id="scPer"></div>'
  + '<div class="sc-daynav"><button class="iconbtn" id="scBack" onclick="scStep(1)">‹</button><b id="scDayLbl">Oggi</b><button class="iconbtn" id="scFwd" onclick="scStep(-1)">›</button></div>'
  + '<div id="scBody"><div class="ins-load">Leggo i dati…</div></div>',
  { back: function(){ return 's-home'; } });

function scClose(){ /* 0.9.282: indietro torna da dove eri (il Profilo), non a Proteggi i tuoi sogni */ if (typeof flIndietro === 'function') flIndietro(); else goId('s-home'); }
/* 0.9.276, Andrea: i giorni passati dei tre punteggi (sonno, focus, riposo) sono Premium. Il report resta per tutti. */
function scPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function scStep(dir){
  if (dir > 0 && !scPremium()){
    try{ toast('I giorni passati dei punteggi sono con Premium'); }catch(_){ }
    try{ if (typeof pwUpsellApri === 'function') pwUpsellApri(); }catch(_){ }
    return;
  }
  SC.dayOff = Math.max(0, Math.min(14, SC.dayOff + dir)); scRender();
}
async function scOpen(kind){
  SC.view = kind || 'total';
  SC.dayOff = 0; SC.periodo = 'giorno';
  goId('s-score');
  scRender();
}

const SC_META = {
  /* 0.9.276, Andrea: "una pappardella lunghissima che nessuno leggera' mai". Una frase sotto al titolo; come
     si calcola sta in un foglio a parte, a punti, solo per chi lo vuole sapere. */
  total: { name: 'Punteggio', q: 'Cos\'è il Punteggio?', breve: 'Sonno, focus e riposo in un solo numero: la media dei tre.',
    come: [['🧮', 'La media', 'Dei tre punteggi che oggi hanno dati.'], ['🤝', 'Cosa racconta', 'Quanto la tecnologia, oggi, è stata dalla tua parte.']] },
  sleep: { name: 'Sonno', q: 'Cos\'è il punteggio Sonno?', breve: 'Quanto hai dormito. Il massimo è fra 7 ore e mezza e 8 ore e mezza.',
    come: [['🌙', 'Quando comincia la notte', 'Dall\'ultima volta che usi il telefono la sera.'],
           ['☀️', 'Quando finisce', 'Quando spegni la sveglia e usi il telefono per qualche minuto. Un\'occhiata nella notte non conta.'],
           ['🎯', 'Il punteggio pieno', 'Fra 7 ore e mezza e 8 ore e mezza. Sei ore valgono 70, dieci ore 78.'],
           ['⏰', 'Cosa toglie punti', 'Andare a letto dopo l\'una (8 punti), dopo le tre (12), e ogni risveglio (2).']] },
  focus: { name: 'Focus', q: 'Cos\'è il punteggio Focus?', breve: 'Quanto del tuo tempo è finito nelle app che distraggono.',
    come: [['📱', 'Le app che distraggono', 'Pesano più di tutto il resto.'], ['🔓', 'Schermo e sblocchi', 'Contano meno.'], ['💼', 'Il lavoro', 'Una giornata lunga al telefono per lavorare, senza social, resta alta.']] },
  rest:  { name: 'Riposo', q: 'Cos\'è il punteggio Riposo?', breve: 'Quanto della giornata hai passato lontano dallo schermo.',
    come: [['🌿', 'Da mezzanotte a adesso', 'La notte a riposo conta, il telefono in mano no.'], ['🎯', 'Il punteggio', 'Un quarto del tempo lontano vale 0, quattro quinti valgono 100.']] }
};
function scComeApri(k){
  const m = SC_META[k] || SC_META.total;
  if (typeof stgFoglio !== 'function') return;
  stgFoglio('<small class="stg-eti">Come si calcola</small><h2 class="stg-h">Il punteggio ' + (k === 'total' ? '' : m.name) + '</h2>'
    + '<div class="sc-come">' + m.come.map(function(c){ return '<div><span>' + c[0] + '</span><p><b>' + c[1] + '</b>' + c[2] + '</p></div>'; }).join('') + '</div>'
    + '<button type="button" class="stg-cta" onclick="stgFoglioChiudi()">Ho capito</button>');
}

function scScoresHtml(sc, selected){
  const v = x => (x === null || x === undefined) ? '—' : x;
  const pill = (k, ico, label) =>
    '<div class="sc-pill' + (selected === k ? ' on' : (selected ? ' dim' : '')) + '" onclick="scOpen(\'' + k + '\')">'
    + '<div class="cap"><span class="ic">' + ico + '</span><b>' + v(sc[k]) + '</b></div><small>' + label + '</small></div>';
  return '<div class="sc-wrap">'
    + '<div class="sc-total' + (selected && selected !== 'total' ? ' dim' : '') + '" onclick="scOpen(\'total\')"><small>Punteggio</small><b>' + v(sc.total) + '</b></div>'
    + '<div class="sc-bracket"><i></i><i></i><i></i></div>'
    + '<div class="sc-row">' + pill('sleep', '🌙', 'Sonno') + pill('focus', '⏳', 'Focus') + pill('rest', '🌲', 'Riposo') + '</div>'
    + '</div>';
}

const SC_PER_NOME = { giorno: 'Giorno', settimana: 'Settimana', mese: 'Mese', anno: 'Anno' };
const SC_PER_TXT = { giorno: 'Oggi', settimana: 'Ultimi 7 giorni', mese: 'Ultimi 30 giorni', anno: 'Ultimo anno' };
const SC_PER_GIORNI = { giorno: 1, settimana: 7, mese: 30, anno: 365 };
function scPeriodo(k){
  if (k !== 'giorno' && !scPremium()){
    try{ toast('Le medie della settimana, del mese e dell\'anno sono con Premium'); }catch(_){ }
    try{ if (typeof pwUpsellApri === 'function') pwUpsellApri(); }catch(_){ }
    return;
  }
  SC.periodo = k; SC.dayOff = 0; scRender();
}
/* LA MEDIA DEL PERIODO: il voto di ogni giorno con dati. Per l'anno un giorno ogni sette (52 letture invece di 365). */
async function scMediaPeriodo(k, giorni){
  const passo = giorni > 60 ? 7 : 1;
  let t = 0, n = 0;
  for (let i = 0; i < giorni; i += passo){
    try{ const c = scCompute(await scReportPunteggi(i)); const v = c ? c[k] : null; if (v !== null && v !== undefined && !isNaN(v)){ t += v; n++; } }catch(_){ }
  }
  return { v: n ? Math.round(t / n) : null, n: n };
}
function scGiudizio(v){
  if (v === null || v === undefined) return { t: 'Nessun dato', c: '#9DB7D6' };
  if (v >= 85) return { t: 'Ottimale', c: '#2ECC71' };
  if (v >= 70) return { t: 'Buono', c: '#4FB8FF' };
  if (v >= 50) return { t: 'Discreto', c: '#F5A623' };
  return { t: 'Da migliorare', c: '#E63946' };
}
/* IL TACHIMETRO: un arco di 240 gradi, pieno quanto il voto, con la tacca bianca alla fine.
   0.9.315, Andrea: 1) la punta arrotondata superava la tacca di mezzo spessore: adesso il riempimento finisce piatto, esattamente
   sotto la tacca; 2) un voto basso non puo' essere azzurro: l'arco comincia rosso e diventa blu lungo la strada, passando per il
   chiaro per non fare mai il viola. Gli stessi colori per sonno, focus e riposo. */
const SC_ARCO_COL = [[0, [230, 57, 70]], [.3, [236, 96, 104]], [.44, [245, 190, 190]], [.54, [176, 216, 252]], [.68, [63, 159, 244]], [1, [0, 117, 227]]];
function scArcoColore(u){
  let i = 0; while (i < SC_ARCO_COL.length - 2 && u > SC_ARCO_COL[i + 1][0]) i++;
  const a = SC_ARCO_COL[i], b = SC_ARCO_COL[i + 1], k = Math.max(0, Math.min(1, (u - a[0]) / (b[0] - a[0])));
  return 'rgb(' + a[1].map(function(x, j){ return Math.round(x + (b[1][j] - x) * k); }).join(',') + ')';
}
function scGaugeHtml(v, k, per, giorniMedia, c){
  const meta = SC_META[k] || SC_META.total, g = scGiudizio(v);
  const R = 80, cx = 100, cy = 100, a0 = 150, sweep = 240;
  const pt = function(a){ const r = a * Math.PI / 180; return [cx + R * Math.cos(r), cy + R * Math.sin(r)]; };
  const arco = function(da, a){ const p = pt(da), q = pt(a), large = (a - da) > 180 ? 1 : 0; return 'M' + p[0].toFixed(2) + ' ' + p[1].toFixed(2) + ' A' + R + ' ' + R + ' 0 ' + large + ' 1 ' + q[0].toFixed(2) + ' ' + q[1].toFixed(2); };
  const f = (v === null || v === undefined) ? 0 : Math.max(0, Math.min(100, v)) / 100;
  const fine = a0 + sweep * f, tac = pt(fine), tacIn = [cx + (R - 12) * Math.cos(fine * Math.PI / 180), cy + (R - 12) * Math.sin(fine * Math.PI / 180)], tacOut = [cx + (R + 12) * Math.cos(fine * Math.PI / 180), cy + (R + 12) * Math.sin(fine * Math.PI / 180)];
  let frase = '';
  if (v !== null && v !== undefined){
    const quando = per === 'giorno' ? (SC.dayOff === 0 ? 'Oggi' : (SC.dayOff === 1 ? 'Ieri' : 'Quel giorno')) : ({ settimana: 'Negli ultimi 7 giorni', mese: 'Negli ultimi 30 giorni', anno: 'Nell\'ultimo anno' }[per]);
    const cosa = { sleep: 'il tuo sonno', focus: 'il tuo focus', rest: 'il tuo riposo', total: 'la tua giornata' }[k] || 'il punteggio';
    frase = quando + ' ' + cosa + ' è ' + (per === 'giorno' ? 'stato ' : 'stato in media ') + g.t.toLowerCase() + '.';
    if (k === 'sleep' && per === 'giorno' && c && typeof scNotteRighe === 'function'){ const n = scNotteRighe(c).replace(/<[^>]+>/g, ''); if (n) frase += ' ' + n; }
    if (per !== 'giorno' && giorniMedia) frase += ' Media di ' + giorniMedia + (giorniMedia === 1 ? ' giorno' : ' giorni') + ' con dati.';
  }
  return '<div class="sc-gauge">'
    + '<svg viewBox="0 0 200 175" aria-hidden="true">' + scArcoTacche(f, a0, sweep, arco)
    + (f > 0 ? '<line x1="' + tacIn[0].toFixed(2) + '" y1="' + tacIn[1].toFixed(2) + '" x2="' + tacOut[0].toFixed(2) + '" y2="' + tacOut[1].toFixed(2) + '" class="sc-g-tac"/>' : '')
    + '</svg>'
    + '<div class="sc-g-mid"><b>' + (v === null || v === undefined ? '—' : v) + '</b><span><i style="background:' + g.c + '"></i>' + g.t + '</span></div></div>'
    + '<div class="sc-panel">' + (frase ? '<p class="sc-panel-f">' + esc(frase) + '</p>' : '')
    + '<p class="sc-panel-q"><b>' + meta.q + '</b><button type="button" class="dp-i sc-i" onclick="scComeApri(\'' + (k || 'total') + '\')" aria-label="Come si calcola">i</button></p><p class="sc-panel-t">' + meta.breve + '</p></div>';
}
/* 0.9.319, Andrea: i colori del tachimetro della Dopamina, dal rosso al verde, come un semaforo, e a tacche: sei fasce staccate. La parte
   non ancora raggiunta resta pallida, dello stesso colore. */
const SC_TACCHE = ['#E63946', '#F0603C', '#F5921E', '#F2C21B', '#A8C93A', '#22C55E'];
function scArcoTacche(f, a0, sweep, arco){
  const pezzo = sweep / SC_TACCHE.length, fine = a0 + sweep * f;
  return SC_TACCHE.map(function(c, i){
    const a = a0 + i * pezzo + (i ? 1.4 : 0), z = a0 + (i + 1) * pezzo - (i < SC_TACCHE.length - 1 ? 1.4 : 0);
    return '<path d="' + arco(a, z) + '" class="sc-g-fill" stroke="' + c + '" stroke-opacity=".2"/>'
      + (fine > a ? '<path d="' + arco(a, Math.min(z, fine)) + '" class="sc-g-fill" stroke="' + c + '"/>' : '');
  }).join('');
}
/* il riempimento: tanti pezzi corti, ognuno del colore del suo punto dell'arco; la partenza e' tonda, la fine piatta */
function scArcoPieno(f, a0, sweep, arco, pt){
  if (!(f > 0)) return '';
  const passo = 2, fine = a0 + sweep * f, inizio = pt(a0);
  let h = '<circle cx="' + inizio[0].toFixed(2) + '" cy="' + inizio[1].toFixed(2) + '" r="7" fill="' + scArcoColore(0) + '"/>';
  for (let a = a0; a < fine; a += passo){
    const z = Math.min(fine, a + passo);
    /* ogni pezzo si appoggia sul successivo per non lasciare fessure; l'ultimo si ferma alla tacca */
    h += '<path d="' + arco(a, z < fine ? z + .4 : z) + '" class="sc-g-fill" stroke="' + scArcoColore((a - a0) / sweep) + '"/>';
  }
  return h;
}
async function scRender(){
  const body = document.getElementById('scBody');
  const lbl = document.getElementById('scDayLbl'), fwd = document.getElementById('scFwd');
  if (!body) return;
  const per = SC.periodo || 'giorno';
  /* 0.9.308, Andrea: dall'altro ieri in poi l'etichetta diceva solo "28 ottobre". Sempre col giorno della settimana: "mercoledì 28 ottobre". */
  if (lbl) lbl.textContent = per !== 'giorno' ? SC_PER_TXT[per] : (SC.dayOff === 0 ? 'Oggi' : (SC.dayOff === 1 ? 'Ieri' : new Date(scDayStart(SC.dayOff)).toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })));
  if (fwd) fwd.disabled = SC.dayOff === 0;
  const bk = document.getElementById('scBack'); if (bk) bk.style.visibility = per === 'giorno' ? '' : 'hidden'; if (fwd) fwd.style.visibility = per === 'giorno' ? '' : 'hidden';
  const tit = document.getElementById('scTitolo'); if (tit) tit.textContent = (SC_META[SC.view] || SC_META.total).name;
  const pb = document.getElementById('scPer'); if (pb) pb.innerHTML = Object.keys(SC_PER_TXT).map(function(k){ return '<button type="button" class="' + (k === per ? 'on' : '') + '" onclick="scPeriodo(\'' + k + '\')">' + SC_PER_NOME[k] + '</button>'; }).join('');
  body.innerHTML = '<div class="ins-load">Leggo i dati…</div>';
  /* Prima di giudicare la notte: il primo segno di vita sul computer. Senza, la sveglia
     resta quella del telefono e chi si alza e va alla scrivania si vede regalare ore. */
  try{ if (typeof dpLeggiComputer === 'function') await dpLeggiComputer(); }catch(_){ }
  const r = await scReportPunteggi(SC.dayOff);
  /* una lettura fallita (il motore occupato) non e' un permesso negato: si riprova fra poco */
  if (!r){ if (!scRender._riprova) scRender._riprova = setTimeout(function(){ scRender._riprova = 0; if (document.getElementById('scBody')) scRender(); }, 2000); return; }
  if (!r.granted){
    body.innerHTML = r.senzaDati
      ? (scPcScollegato()
        ? '<div class="ins-miss">Il computer non è più collegato al tuo account, quindi non riceve i punteggi del telefono.<button type="button" class="cta" style="display:block;margin:14px auto 0" onclick="scPcAccedi()">Accedi con Google</button></div>'
        : '<div class="ins-miss">I punteggi li misura il telefono, e oggi non ha ancora mandato i suoi dati. Arrivano quando apri DreamMap sul telefono.</div>')
      : '<div class="ins-miss">Serve l\'accesso ai dati di utilizzo.</div>';
    return;
  }
  const c = scCompute(r);
  const avg = await scAverages(SC.dayOff);
  const meta = SC_META[SC.view] || SC_META.total;
  /* il voto da mostrare: quello del giorno, o la media del periodo */
  let voto = c ? c[SC.view] : null, giorniMedia = 0;
  if (per !== 'giorno'){ const m = await scMediaPeriodo(SC.view, SC_PER_GIORNI[per]); voto = m.v; giorniMedia = m.n; }
  let html = scGaugeHtml(voto, SC.view, per, giorniMedia, c);
  /* LE TACCHETTE STANNO SOPRA AL TITOLO. Sono il giudizio della notte in una parola sola:
     appiccicate al numero, dentro alla riga della metrica, arrivavano dopo tre paragrafi. */
  /* 0.9.280, Andrea: "Eccellente" sopra a "Cos'e' il punteggio Sonno?" non lo vuole: il numero dice gia' tutto */
  /* una riga vuota nel testo e' un paragrafo nuovo: niente muro di testo */
  /* 0.9.279, Andrea: niente pulsante "Come si calcola": la "i" tonda delle slide, accanto al titolo */
  html += '<h3 class="sc-ff">Fattori di valutazione</h3>';
  html += scMetrics(SC.view, c, avg);
  /* 0.9.315, Andrea: nel Riposo c'era anche il tachimetro della dopamina, e con "100" sopra e "53,2" sotto non si capiva quale
     guardare. In questa pagina il numero e' uno solo. La dopamina ha la sua pagina: qui resta la strada per arrivarci, senza voto. */
  if (SC.view === 'rest' && SC.dayOff === 0 && typeof dpApri === 'function'){
    html += '<button type="button" class="sc-dopa-riga" onclick="dpApri()"><span>🧠</span><div><b>Riserva di dopamina</b><small>Guarda cosa l’ha alzata e cosa l’ha abbassata oggi</small></div><svg viewBox="0 0 8 12" width="8" height="12" aria-hidden="true"><path fill="none" d="M1 1l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>';
  }
  html += '<p class="sc-foot">Le medie sono degli ultimi ' + (avg.days || 0) + ' giorni con dati. Tutto è misurato dal telefono; niente è stimato.</p>';
  body.innerHTML = html;
}

function scMetric(label, value, avgValue, fmt, better, extra){
  const has = value !== null && value !== undefined;
  const hasAvg = avgValue !== null && avgValue !== undefined && !isNaN(avgValue);
  let delta = '';
  let cls = 'flat';
  if (has && hasAvg){
    const d = value - avgValue;
    /* 'otto': il sonno e' meglio quanto piu' e' vicino alle otto ore, non quanto piu' e' lungo */
    const good = better === 'otto' ? Math.abs(value - 8 * SC_H) < Math.abs(avgValue - 8 * SC_H)
               : better === 'higher' ? d > 0 : d < 0;
    const tiny = Math.abs(d) < (fmt === scFmt ? 60000 : 0.5);
    cls = tiny ? 'flat' : (good ? 'good' : 'bad');
    delta = '<span class="delta ' + cls + '">' + (tiny ? '=' : (d > 0 ? '▲ ' : '▼ ')) + (tiny ? '' : fmt(Math.abs(d))) + '</span>';
  }
  let bar = '';
  if (has && hasAvg && avgValue > 0){
    const pos = scClamp(value / (2 * avgValue)) * 100;
    const left = Math.min(pos, 50), width = Math.abs(pos - 50);
    bar = '<div class="sc-bar"><i class="fill ' + cls + '" style="left:' + left + '%;width:' + width + '%"></i><span class="mark"></span></div><small class="sc-avg">MEDIA</small>';
  }
  return '<div class="sc-met"><div class="head"><b>' + label + '</b><span class="val">' + (has ? fmt(value) : '—') + '</span>' + delta + '</div>' + (extra || '') + bar + '</div>';
}
/** Sotto al numero del Sonno, la notte detta a parole: dal motore unico (sonno-motore.js). */
function scNotteRighe(c){
  const n = c && c.notte;
  if (!(c && c.sleepMs > 0)) return '<p class="sc-none">' + esc(snFraseManca(n || { motivo: 'dati' })) + '</p>';
  if (!n || !n.inizio || !c.wake) return '';
  let t = 'A letto alle ' + snOra(n.inizio) + ', sveglia alle ' + snOra(c.wake)
    + (n.svegliaDa === 'sveglia' ? ', quando hai spento la sveglia.' : '.');
  const i = snFraseInterruzioni(n), l = snFraseLeggero(n);
  if (i) t += ' ' + i;
  if (l) t += ' ' + l;
  return '<p class="sc-none">' + esc(t) + '</p>';
}
function scSleepBars(ms){
  const n = ms ? Math.max(1, Math.min(6, Math.round(ms / SC_H / 9 * 6))) : 0;
  /* «Eccellente» solo dove il punteggio e' pieno: undici ore e mezza dicevano «Eccellente» */
  const q = !ms ? '' : (ms > 9.5 * SC_H ? 'Troppo lungo' : ms > SC_SONNO_TROPPO_H * SC_H ? 'Buono'
            : ms >= 7.5 * SC_H ? 'Eccellente' : ms >= 6.5 * SC_H ? 'Buono' : ms >= 5 * SC_H ? 'Corto' : 'Poco');
  let b = '<div class="sc-sleep"><span class="q">' + q + '</span><div class="bars">';
  for (let i = 0; i < 6; i++) b += '<i class="' + (i < n ? 'on' : '') + '"></i>';
  return b + '</div></div>';
}
function scMetrics(view, c, avg){
  const min = v => String(Math.floor(v / 60)).padStart(2,'0') + ':' + String(Math.round(v % 60)).padStart(2,'0');
  const fmtMinDelta = v => Math.round(v) + ' min';
  const firstMin = c.first ? scMinOfDay(c.first) : null;
  const lastMin = c.prevLast ? ((scMinOfDay(c.prevLast) + 12 * 60) % (24 * 60)) : null;
  const hasSpan = c.spanMs > 0;
  let h = '';
  if (view === 'total'){
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Distrazioni', c.distrMs, avg.distrMs, scFmt, 'lower');
    h += scMetric('Sonno', c.sleepMs > 0 ? c.sleepMs : null, avg.sleepMs, scFmt, 'otto', c.sleepMs > 0 ? scSleepBars(c.sleepMs) : '');
    h += scMetric('Sblocchi del telefono', c.hasUse ? c.pickups : null, avg.pickups, v => Math.round(v), 'lower');
  } else if (view === 'sleep'){
    /* Le tacchette salgono in cima alla pagina (scRender): qui sotto resta il numero. */
    /* 0.9.284, Andrea: la notte detta a parole sta SOLO nel pannello in alto; qui si ripeteva. Resta solo il perche' manca. */
    h += scMetric('Sonno', c.sleepMs > 0 ? c.sleepMs : null, avg.sleepMs, scFmt, 'otto', c.sleepMs > 0 ? '' : scNotteRighe(c));
    /* 0.9.236: "Primo sblocco" diceva 00:00 (il primo uso del giorno di calendario, tagliato a
       mezzanotte). Adesso e' la sveglia del motore del sonno, o niente. */
    h += scMetric(c.daComputer ? 'Sveglia (dal computer)' : 'Sveglia', firstMin, avg.firstMin, v => (typeof v === 'number' && v > 24 * 60 ? fmtMinDelta(v) : min(v)), 'higher');
    h += scMetric('Ultimo uso della sera', lastMin, avg.lastMin, v => min((v + 12 * 60) % (24 * 60)), 'lower');
    /* la scelta vive qui, accanto al numero che cambia (0.9.202) */
    h += '<div class="sc-opt"><div><b>La sveglia la segna anche il computer</b><small>Se al mattino apri prima il computer, la notte finisce lì. Spento: conta solo il telefono.</small></div>'
      + '<button type="button" class="switch' + (scSvegliaPcOn() ? ' on' : '') + '" onclick="scSvegliaPcSet(!scSvegliaPcOn());this.classList.toggle(\'on\');if(typeof scRender===\'function\')scRender()"></button></div>';
  } else if (view === 'focus'){
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Distrazioni', c.distrMs, avg.distrMs, scFmt, 'lower');
    h += scMetric('Focus più lungo', c.awakeGapMs > 0 ? c.awakeGapMs : (c.gapMs > 0 ? c.gapMs : null), avg.gapMs, scFmt, 'higher');
    h += scMetric('Sblocchi del telefono', c.hasUse ? c.pickups : null, avg.pickups, v => Math.round(v), 'lower');
  } else {
    h += scMetric('Tempo schermo', c.screenMs, avg.screenMs, scFmt, 'lower');
    h += scMetric('Offline (oggi)', c.elapsedMs > 0 ? c.dayOfflineMs : null, avg.offlineMs, scFmt, 'higher');
    // the longest break while awake: the night is the Sleep score's, not a "focus" of six hours
    h += scMetric('Focus più lungo', c.awakeGapMs > 0 ? c.awakeGapMs : (c.gapMs > 0 ? c.gapMs : null), avg.gapMs, scFmt, 'higher');
  }
  return h;
}

/* ---------------------------------------------------------------------------------------
   SE CONTINUI COSÌ - what this pace costs over the years that are left

   The rest of the Report answers "how much today". This answers "how much of my life", which
   is the only version of the number that changes behaviour. It sits at the foot of the tab,
   after every figure it is built on.

   The arithmetic is deliberately simple and it is written on screen, because a projection
   nobody can check is a scare story:
      hours a day   the average of the last seven days (today alone is too noisy)
      years left    LIFE_SPAN - the age the user typed in
      years lost    years left * hours a day / 24
   LIFE_SPAN is a round 80 and WAKE_H a round 16. Both are averages, both are stated under the
   figure, and neither is dressed up as a fact about this person.
   --------------------------------------------------------------------------------------- */

const SC_AGE_KEY = 'fl_age';
const SC_LIFE_SPAN = 80;   // the horizon the estimate is drawn against
const SC_WAKE_H = 16;      // hours awake in an average day
const SC_LIFE_MIN_DAYS = 3;  // full days of measurement before the estimate means anything

function scAgeGet(){
  let v = 0;
  try{ v = parseInt(localStorage.getItem(SC_AGE_KEY) || '0', 10); }catch(_){ v = 0; }
  return (v >= 10 && v <= 99) ? v : 0;
}

/* The host is appended to the tab and kept last, the same way the streak panel is in Severa:
   insights.js rewrites its own containers and would otherwise carry this away with them. */
/* Il posto è scritto nell'HTML, subito sotto al cielo: è la prima cosa che si legge scendendo,
   prima ancora del lucchetto. Qui si riempie e basta. */
function scLifeEnsure(){ return document.getElementById('scLife'); }

function scAgeSave(){
  const i = document.getElementById('scAgeInput');
  const n = i ? parseInt(i.value, 10) : NaN;
  if (!(n >= 10 && n <= 99)){ toast('Scrivi un\'età fra 10 e 99'); return; }
  try{ localStorage.setItem(SC_AGE_KEY, String(n)); }catch(_){ }
  scLifePaint();
}
function scAgeEdit(){
  try{ localStorage.removeItem(SC_AGE_KEY); }catch(_){ }
  scLifePaint();
}

/* One decimal, comma as the separator, because the app speaks Italian. */
function scNum(x, dec){
  const s = (Math.round(x * Math.pow(10, dec)) / Math.pow(10, dec)).toFixed(dec);
  return s.replace('.', ',');
}

async function scLifePaint(){
  const el = scLifeEnsure();
  if (!el) return;
  if (!scHaGiornata()){ el.innerHTML = ''; return; }
  /* 0.9.288: "Prevedi il tuo futuro" e' uno dei giochi del Genio: spento con la stagione di spinta */
  if (typeof flSezioneBloccata === 'function' && flSezioneBloccata('genio-giochi')){ el.innerHTML = ''; return; }

  /* 0.9.304, Andrea: niente piu' titolo "Prevedi il tuo futuro" ne' la frase di F.M. Alexander sopra al pannello:
     il pannello sta nella scheda Identita' del pannello di Dream (rotta-tab.js), e la frase va nella lettura del Genio */
  const wrap = inner => '<div class="life-wrap"><div class="life">' + inner + '</div></div>';

  /*
   * Nel pannello resta UN elemento (regola OEOF): prima della lettura, l'invito; dopo, il
   * nome di chi stai diventando. Domande, numeri e Jung vivono a schermo intero, uno per volta.
   */
  const last = (typeof orLast === 'function') ? orLast() : null;
  if (!last){
    el.innerHTML = wrap('<b class="life-t">Pensa alla persona che vuoi diventare</b>'
      + '<p class="life-p">Ti farò qualche domanda. Alcune risposte le conosco già: le ho lette nel tuo telefono.</p>'
      + '<button class="life-go" onclick="orOpen()">Sfidami · ti dirò chi stai diventando</button>');
    return;
  }
  const prof = orProfile(last.profile);
  /* non un'etichetta su chi sei: dove porta la strada di adesso */
  el.innerHTML = wrap('<b class="life-t">Se continui così, rischi di diventare</b>'
    + '<div class="life-who">' + prof.ico + '</div>'
    + '<div class="life-big who">' + esc(prof.name) + '</div>'
    + '<p class="life-p">Oggi hai il <strong>' + last.pct + '%</strong> di probabilità di diventare <strong>' + esc(last.persona || orTargetName(last.target)) + '</strong>.</p>'
    /* 0.9.305, Andrea: tre pulsanti si contendevano il focus. Qui restano "Rifai la lettura" (il principale) e
       "Quanti anni ti costa"; "Ricalcola il percorso" compare solo alla fine della lettura, come proposta (oracle.js) */
    + '<button class="life-go" onclick="orOpen()">Rifai la lettura</button>'
    + '<div class="life-links"><button class="life-edit" onclick="scFutureStory()">Quanti anni ti costa</button></div>');
}

/* ---- Jung, l'ultimo passo del racconto ------------------------------------------------

   L'immagine originale aveva la frase stampata sopra, in inglese. Il ritratto qui è nudo e la
   frase la scrive l'app, nella lingua del telefono: chi ha il telefono in spagnolo la legge in
   spagnolo. */
const SC_JUNG = {
  it: "Finché non rendi cosciente l'inconscio, esso guiderà la tua vita e tu lo chiamerai destino.",
  en: 'Until you make the unconscious conscious, it will direct your life and you will call it fate.',
  es: 'Hasta que hagas consciente lo inconsciente, dirigirá tu vida y lo llamarás destino.',
  fr: "Tant que vous ne rendez pas l'inconscient conscient, il dirigera votre vie et vous appellerez cela le destin.",
  de: 'Bis du das Unbewusste bewusst machst, wird es dein Leben lenken und du wirst es Schicksal nennen.',
  pt: 'Até que você torne o inconsciente consciente, ele dirigirá a sua vida e você vai chamá-lo de destino.'
};
function scJungText(){
  let l = 'en';
  try{ l = String(navigator.language || 'en').slice(0, 2).toLowerCase(); }catch(_){ }
  return SC_JUNG[l] || SC_JUNG.en;
}

/* Il racconto degli anni: un passo, un dato, una frase intera. Jung chiude.
   Si calcola qui, quando serve: prima stava dentro al pannello e restava lì a metà. */
async function scFutureStory(){
  if (typeof fuOpen !== 'function') return;
  const f = scFuture();
  if (!f.birth){
    // La data si chiede QUI, una volta, e finisce nel profilo: non si richiede mai più.
    fuOpen([{ birth: true, kicker: 'Una cosa sola, una volta sola', line: 'Per contare gli anni che hai davanti mi serve la tua data di nascita. Resta sul telefono e non te la richiedo più.',
      onSave: function(v){ scFutureSetBirth(v); const g = scFuture(); g.birth = v; scStore('fl_future', JSON.stringify(g)); scFutureStory(); } }]);
    return;
  }
  const avg = await scAverages(0);
  const days = (avg && avg.days) || 0;
  if (days < SC_LIFE_MIN_DAYS){
    const missing = SC_LIFE_MIN_DAYS - days;
    fuOpen([{ kicker: 'Ancora un po\' di pazienza', big: String(missing), unit: missing === 1 ? 'giorno' : 'giorni',
      line: 'Per dirti quanti anni ti costa il ritmo di adesso mi servono almeno ' + SC_LIFE_MIN_DAYS + ' giorni interi di misure. Su un giorno solo il conto direbbe qualunque cosa, e sarebbe falso.' }]);
    return;
  }
  const age = scAgeExact(f.birth);
  const left = Math.max(0, SC_LIFE_SPAN - age);
  const h = avg.screenMs / SC_H;
  let goalMin = f.goalMin || 0;
  try{ if (!goalMin) goalMin = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ }
  if (!goalMin) goalMin = 120;
  const goalH = goalMin / 60;
  const years = left * h / 24;
  const yearsGoal = left * goalH / 24;
  const back = Math.max(0, years - yearsGoal);
  const backH = back * 365 * 24;
  const backPerYear = left > 0 ? backH / left : 0;
  const daysPerYear = h * 365 / 24;
  const wakePct = Math.min(100, h / SC_WAKE_H * 100);
  const odds = await scSuccessOdds();
  const it = n => Math.round(n).toLocaleString('it-IT');
  const goalTxt = scNum(goalH, 1).replace(',0', '') + (goalH === 1 ? ' ora' : ' ore');
  const last = (typeof orLast === 'function') ? orLast() : null;
  const want = last ? orTargetName(last.target) : '';

  const steps = [];
  steps.push({ kicker: 'Il tempo che hai davanti', big: String(left), unit: 'anni',
    line: 'Hai ' + age + ' anni. Se la vita dura ' + SC_LIFE_SPAN + ', te ne restano ' + left + '.' });
  steps.push({ kicker: 'Se continui così', big: scNum(years, 1), unit: 'anni', tone: 'warn',
    line: 'Ne passerai <strong>' + scNum(years, 1) + '</strong> davanti a uno schermo. È la tua media di adesso, ' + scFmtShort(avg.screenMs) + ' al giorno, portata avanti fino alla fine.' });
  steps.push({ kicker: 'Ogni anno', big: it(daysPerYear), unit: 'giorni', tone: 'warn',
    line: 'Sono <strong>' + it(daysPerYear) + ' giorni interi</strong> all\'anno passati sullo schermo, dal primo minuto all\'ultimo, senza dormire.' });
  steps.push({ kicker: 'Delle tue ore da sveglio', big: Math.round(wakePct) + '%', tone: 'warn',
    line: (wakePct >= 30 ? 'Quasi un terzo' : 'Una parte') + ' di ogni giornata se ne va lì. Il resto è quello che avanza.' });
  steps.push({ kicker: 'Se tieni il tuo obiettivo', big: scNum(yearsGoal, 1), unit: 'anni', tone: 'good',
    line: 'A ' + goalTxt + ' al giorno ne passeresti <strong>' + scNum(yearsGoal, 1) + '</strong>, non ' + scNum(years, 1) + '.' });
  steps.push({ kicker: 'Ti riprendi', big: scLifeSpan(back), tone: 'good',
    line: '<strong>' + scLifeSpan(back) + '</strong> di vita che tornano tuoi' + (want ? ', per diventare <strong>' + esc(want) + '</strong>.' : '.') });
  steps.push({ kicker: 'Ogni anno', big: it(backPerYear), unit: 'ore', tone: 'good',
    line: '<strong>' + it(backPerYear) + ' ore</strong> all\'anno che tornano tue: il tempo di leggere ' + it(backPerYear / 6) + ' libri, o ' + scNum(backPerYear / 10000 * 100, 0) + '% delle diecimila ore che fanno un maestro.' });
  steps.push({ kicker: 'Le tue probabilità di riuscirci, oggi', big: String(odds.pct), unit: '%',
    tone: odds.pct >= 55 ? 'good' : (odds.pct >= 35 ? '' : 'warn'),
    line: 'Con le abitudini che hai adesso. Non è un oroscopo: è la somma di quello che hai fatto finora, e si muove ogni volta che fai qualcosa.' });
  steps.push({ kicker: 'Da dove viene quel numero', list: odds.why.map(w => [w[0], w[1]]) });
  steps.push({ img: 'img/jung.jpg', quote: scJungText(), by: '— Carl Jung' });
  fuOpen(steps);
}

/* ---- le risposte, su questo telefono ---- */
function scFuture(){
  let f = null;
  try{ f = JSON.parse(localStorage.getItem('fl_future') || 'null'); }catch(_){ f = null; }
  f = f || {};
  // La data di nascita è del profilo: si scrive una volta sola, toccando la propria immagine.
  if (!f.birth){
    try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); if (u && u.birth) f.birth = u.birth; }catch(_){ }
  }
  // chi aveva già scritto solo l'età non la riscrive: diventa un 1° gennaio approssimato
  if (!f.birth){
    let old = 0; try{ old = parseInt(localStorage.getItem(SC_AGE_KEY) || '0', 10) || 0; }catch(_){ }
    if (old >= 10 && old <= 99) f.birth = (new Date().getFullYear() - old) + '-01-01';
  }
  if (!f.goalMin){ try{ f.goalMin = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ f.goalMin = 0; } }
  return f;
}
function scFutureSave(){
  const b = document.getElementById('fuBirth'), w = document.getElementById('fuWant');
  const birth = b ? b.value : '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birth)){ toast('Scegli la tua data di nascita'); return; }
  const age = scAgeExact(birth);
  if (age === null || age < 8 || age > 110){ toast('Controlla la data: non torna'); return; }
  const f = scFuture();
  f.birth = birth;
  f.want = w ? w.value.trim().slice(0, 70) : '';
  if (!f.goalMin) f.goalMin = 120;
  if (!scStore('fl_future', JSON.stringify(f))){ toast('Memoria piena: non sono riuscito a salvare'); return; }
  scFutureSetBirth(birth);
  scLifePaint();
}
/* La data finisce anche nel profilo, che è il posto dove l'utente la cerca. */
function scFutureSetBirth(birth){
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null') || { local: true };
    if (u.birth !== birth){ u.birth = birth; scStore('fl_user', JSON.stringify(u)); }
  }catch(_){ }
}
/* localStorage pieno: le immagini del perché e le cache dei giorni lo riempiono davvero, e
   un salvataggio che fallisce in silenzio è il motivo per cui la data di nascita "non si
   salvava mai". Si buttano le cache e si riprova una volta. */
function scStore(key, value){
  try{ localStorage.setItem(key, value); return true; }catch(_){ }
  try{
    const drop = [];
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (k && (k.indexOf('fl_dayrep_') === 0 || k === 'fl_bgs')) drop.push(k);
    }
    drop.forEach(k => { try{ localStorage.removeItem(k); }catch(__){ } });
    localStorage.setItem(key, value);
    return true;
  }catch(_){ return false; }
}
function scFutureGoal(min){
  const f = scFuture();
  f.goalMin = min;
  scStore('fl_future', JSON.stringify(f));
  const host = document.getElementById('fuGoal');
  if (host) host.innerHTML = scFutureGoalChips(min);
}
function scFutureGoalChips(cur){
  return [60, 90, 120, 180, 240].map(m =>
    '<button type="button" class="life-chip' + (cur === m ? ' on' : '') + '" onclick="scFutureGoal(' + m + ')">'
    + (m % 60 === 0 ? (m / 60) + 'h' : Math.floor(m / 60) + 'h' + (m % 60)) + '</button>').join('');
}
/* La data di nascita si scrive una volta e resta: la versione precedente la cancellava a ogni
   "cambia le risposte", e la pagina la richiedeva ogni volta. Adesso "cambiare" vuol dire
   rifare la lettura dell'oracolo; la data la si tocca solo dal profilo. */
function scFutureEdit(){ if (typeof orOpen === 'function') orOpen(); }
/* Anni compiuti, non "anno corrente meno anno di nascita". */
function scAgeExact(birth){
  if (!birth || !/^\d{4}-\d{2}-\d{2}$/.test(birth)) return null;
  const b = new Date(birth + 'T00:00:00');
  if (isNaN(b)) return null;
  const now = new Date();
  let a = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) a--;
  return a;
}
/* "2 anni e 4 mesi", "7 mesi": gli anni da soli, sotto l'unità, non dicono niente. */
function scLifeSpan(years){
  const months = Math.round(years * 12);
  const y = Math.floor(months / 12), mo = months % 12;
  if (y <= 0) return mo + (mo === 1 ? ' mese' : ' mesi');
  if (mo === 0) return y + (y === 1 ? ' anno' : ' anni');
  return y + (y === 1 ? ' anno' : ' anni') + ' e ' + mo + (mo === 1 ? ' mese' : ' mesi');
}

/* ---- quante probabilità hai di riuscirci ----------------------------------------------

   Niente oroscopi: ogni punto viene da una cosa che è successa. I giorni di fila in Modalità
   severa e le sessioni di concentrazione portate a termine aggiungono; le pause del piano
   (blocco rapido messo in pausa, programmi spenti) tolgono. L'elenco degli ingredienti è
   sotto il numero, perché un numero che non si può controllare non serve a nessuno. */
async function scSuccessOdds(){
  const why = [];
  let pct = 40;

  let streak = 0;
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (st && st.start && typeof blkDaysBetween === 'function' && typeof blkToday === 'function'){
      streak = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
    }
  }catch(_){ }
  const sPts = Math.min(25, Math.round(streak * 2.5));
  if (sPts) why.push([streak + (streak === 1 ? ' giorno di fila con il piano attivo' : ' giorni di fila con il piano attivo'), '+' + sPts]);

  let ff7 = 0;
  try{
    const since = Date.now() - 7 * 86400000;
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(x => { if (x && x.ok && x.at >= since) ff7++; });
  }catch(_){ }
  const fPts = Math.min(15, ff7 * 3);
  if (fPts) why.push([ff7 + (ff7 === 1 ? ' sessione FullFocus questa settimana' : ' sessioni FullFocus questa settimana'), '+' + fPts]);

  // giorni degli ultimi sette in cui sei rimasto sotto il tuo obiettivo
  let under = 0, goalMin = scFuture().goalMin || 0;
  if (goalMin > 0){
    for (let i = 1; i <= 7; i++){
      const r = await scReport(i);
      if (r && r.granted && r.screenMs > 0 && r.screenMs / 60000 <= goalMin) under++;
    }
  }
  const uPts = Math.min(10, under * 2.5);
  if (uPts) why.push([under + (under === 1 ? ' giorno sotto il tuo obiettivo' : ' giorni sotto il tuo obiettivo'), '+' + Math.round(uPts)]);

  let breaks = 0;
  try{
    const since = Date.now() - 30 * 86400000;
    (JSON.parse(localStorage.getItem('fl_breaks') || '[]') || []).forEach(t => { if (t >= since) breaks++; });
  }catch(_){ }
  const bPts = Math.min(35, breaks * 5);
  if (bPts) why.push([breaks + (breaks === 1 ? ' volta che hai messo in pausa il piano (30 giorni)' : ' volte che hai messo in pausa il piano (30 giorni)'), '−' + bPts]);

  pct = pct + sPts + fPts + Math.round(uPts) - bPts;
  pct = Math.max(5, Math.min(95, Math.round(pct)));
  if (!why.length) why.push(['Non hai ancora abbastanza storia: parte da qui', '40']);
  return { pct: pct, why: why };
}

/* ---------------------------------------------------------------------------------------
   STYLE
   --------------------------------------------------------------------------------------- */
(function scStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '@property --angle{syntax:"<angle>";initial-value:0deg;inherits:false}',
    /* the night sky, edge to edge: the tab pads by 18 and the screen by 22, so it has to give
       back 40 on each side to touch the glass */
    '.prof-sky{position:relative;margin:0 calc(-1 * var(--bleed, 40px));padding:22px 26px 78px;overflow:hidden;',
    '  background:linear-gradient(180deg,rgba(2,9,38,.5),rgba(2,9,38,.74)),url("img/dream-night.jpg") center/cover no-repeat,linear-gradient(180deg,#020926 0%,#06214F 30%,#1B4E8C 62%,#0C3A76 82%,#08295B 100%);background-color:#020926}',
    '.starfield{position:absolute;inset:0;pointer-events:none;z-index:0;overflow:hidden}',
    '.prof-sky > *:not(.starfield):not(.prof-clouds){position:relative;z-index:1}',
    '.star{position:absolute;background:#fff;width:1.2px;height:1.2px;border-radius:50%;opacity:.18;animation:twinkle 6s linear infinite both}',
    '.star.big{width:2px;height:2px;opacity:.35}',
    '@keyframes twinkle{0%,100%{opacity:.15;transform:scale(1)}50%{opacity:1;transform:scale(1.7)}}',
    '.prof-clouds{position:absolute;left:0;right:0;bottom:-1px;z-index:2;line-height:0;color:var(--bg);pointer-events:none}',
    '.prof-clouds svg{display:block;width:100%;height:64px}',
    '.prof-sky .prof-hero{padding:6px 8px 0}',
    '.prof-sky .prof-hero .av{width:78px;height:78px;font-size:32px;cursor:pointer;box-shadow:0 0 0 4px rgba(255,255,255,.14),0 12px 30px rgba(0,0,0,.4)}',
    '.prof-sky .prof-hero h2{color:#fff;font-size:31px;margin:14px 0 2px;text-shadow:0 2px 12px rgba(0,0,0,.5)}',
    /* la riga che ruota (data, mantra dell'inizio, mantra di adesso) parla con la stessa
       voce del livello: stesso azzurro, niente corsivo, niente gerarchia inventata */
    '.prof-sky .prof-hero .since{color:#9EC1FF;font-style:normal;font-weight:600;min-height:34px;padding:0 18px}',
    '.prof-sky .prof-hero small{color:rgba(255,255,255,.6)}',
    /* the black box with the spinning glow of .wishlist-quote */
    '.pf-box{position:relative;margin-top:18px;border-radius:25px;background:#000;color:#fff;padding:16px 0 12px;z-index:1}',
    '.pf-box::before{content:"";position:absolute;inset:-8px;border-radius:25px;background-image:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(12px);animation:spin 3s linear infinite;z-index:-3;pointer-events:none}',
    '.pf-box::after{content:"";position:absolute;inset:0;background:#000;border-radius:25px;z-index:-2;pointer-events:none}',
    '@keyframes spin{from{--angle:0deg}to{--angle:360deg}}',
    '.pf-track{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;scrollbar-width:none}',
    '.pf-track::-webkit-scrollbar{display:none}',
    '.pf-slide{flex:0 0 100%;scroll-snap-align:start;box-sizing:border-box;padding:6px 20px 4px;min-height:170px;text-align:center}',
    '.pf-dots{display:flex;justify-content:center;gap:6px;margin-top:10px}',
    '.pf-dots i{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.3)}.pf-dots i.on{background:#fff}',
    '.pf-opal{display:flex;justify-content:space-around;align-items:flex-start;padding-top:22px}',
    '.pf-stat{text-align:center;cursor:pointer}',
    '.pf-stat .ico{display:block;font-size:46px;line-height:1}',
    '.pf-stat .glow-mint{filter:drop-shadow(0 0 14px rgba(140,240,200,.9)) drop-shadow(0 0 4px rgba(140,240,200,.9))}',
    '.pf-stat .glow-fire{filter:drop-shadow(0 0 14px rgba(255,150,40,.9)) drop-shadow(0 0 4px rgba(255,200,80,.9))}',
    '.pf-stat .num{display:block;font:800 34px/1.1 var(--font-display);margin-top:10px}',
    '.pf-stat .num.mint{color:#8CF0C8}.pf-stat .num.gold{color:#F5C542}',
    /* IL PUNTEGGIO DEL NUOVO TE HA UN COLORE SUO, e non e' il verde delle ore di focus.
       Passa da una variabile perche' si cambia dalle impostazioni: il verde dice «va bene
       cosi'», l'azzurro dice «continua», e quale delle due funzioni su una persona si scopre
       solo provandole per qualche settimana. */
    '.pf-stat .num.neo{color:var(--neo-soft,#4FB8FF)}',
    '.pf-stat .num.neo + small{color:var(--neo-soft,#4FB8FF)}',
    '.pf-stat .glow-neo{filter:drop-shadow(0 0 14px var(--neo-glow,rgba(79,184,255,.9))) drop-shadow(0 0 4px var(--neo-glow,rgba(79,184,255,.9)))}',
    '.pf-stat small{display:flex;align-items:center;justify-content:center;gap:5px;font:700 11px var(--font-body);letter-spacing:.12em;margin-top:4px}',
    '.pf-stat .num.mint + small{color:#8CF0C8}.pf-stat .num.gold + small{color:#F5C542}',
    '.pf-stat i.q{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;width:14px;height:14px;border-radius:50%;border:1px solid currentColor;font:700 9px/1 var(--font-body);font-style:normal;opacity:.8;margin-left:4px;vertical-align:middle;padding-top:1px}',
    /* The day's score, in the sky under the name. The padding above it is the point: it is
       the first thing the eye lands on after the name, and it needs room to be read as a
       result rather than as a caption of the portrait. */
    '.prof-scorebox{display:flex;flex-direction:column;align-items:center;text-align:center;color:#fff;padding:46px 22px 8px}',
    '.pf-quote{font-weight:700}',
    '.pf-quote strong{display:block;font-size:14px;margin-bottom:12px}',
    '.pf-text{display:block;font-size:1.2em;line-height:1.45;min-height:52px}',
    '.pf-author{display:block;font-style:italic;font-weight:500;margin-top:10px;color:rgba(255,255,255,.85);text-align:center}',
    '.pf-details{margin-top:14px;border:none;border-radius:99px;background:rgba(255,255,255,.14);color:#fff;font:700 12.5px var(--font-body);padding:9px 18px;cursor:pointer;backdrop-filter:blur(6px)}',
    '.typewriter-char{opacity:0;display:inline;transition:opacity .05s linear}.typewriter-char.visible{opacity:1}',
    '.typewriter-cursor{display:inline;color:#fff;animation:blink-caret .8s step-end infinite;font-weight:normal!important}',
    '@keyframes blink-caret{from,to{opacity:0}50%{opacity:1}}',
    /* the scores at the top of the Blocco tab */
    '.blk-scores{margin:14px 0 4px;text-align:center}',
    '.bs-total{display:inline-block;cursor:pointer}',
    '.bs-total small{display:block;font:600 12px var(--font-body);color:var(--muted)}',
    '.bs-total b{display:block;font:800 38px/1 var(--font-display);color:var(--navy)}',
    '.bs-total .caret{font-size:15px;color:var(--blue);margin-left:4px;vertical-align:middle}',
    '.bs-row{display:flex;justify-content:space-around;gap:8px;margin-top:2px}',
    '.bs-pill{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer}',
    '.bs-pill .cap{position:relative;display:flex;align-items:center;justify-content:center;gap:6px;width:100%;height:44px;border-radius:22px;background:#EEF4FF;font:800 18px var(--font-display);color:var(--navy)}',
    '.bs-pill .cap .ic{font-size:15px}',
    '.bs-pill .arc{position:absolute;inset:0;width:100%;height:100%;overflow:visible}',
    '.bs-pill .arc rect{fill:none;stroke:var(--blue);stroke-width:3;stroke-linecap:round;transform:rotate(-90deg);transform-origin:50% 50%}',
    '.bs-pill small{font:600 12px var(--font-body);color:var(--muted)}',
    'body.dark .bs-pill .cap{background:#1B2E52;color:#fff}body.dark .bs-total b{color:#fff}',
    /* scores, shared with the breakdown screen */
    '.sc-wrap{margin:6px 0}',
    '.sc-total{display:inline-block;cursor:pointer}',
    '.sc-total small{display:block;font:600 12px var(--font-body);color:var(--muted)}',
    '.sc-total b{display:block;font:800 40px/1 var(--font-display);color:var(--navy)}',
    '.sc-wrap{text-align:center}',
    '.sc-bracket{display:flex;justify-content:center;height:16px;margin:6px 0 4px;position:relative}',
    '.sc-bracket::before{content:"";position:absolute;left:18%;right:18%;top:8px;border-top:1.5px solid var(--line)}',
    '.sc-bracket::after{content:"";position:absolute;left:50%;top:0;height:8px;border-left:1.5px solid var(--line)}',
    '.sc-bracket i{position:absolute;top:8px;height:8px;border-left:1.5px solid var(--line)}',
    '.sc-bracket i:nth-child(1){left:18%}.sc-bracket i:nth-child(2){left:50%}.sc-bracket i:nth-child(3){right:18%}',
    '.sc-row{display:flex;justify-content:space-around;gap:8px}',
    '.sc-pill{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;transition:opacity .25s,filter .25s}',
    '.sc-opt{display:flex;align-items:center;gap:14px;margin:18px 0 6px;padding:14px 16px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sc-opt{background:#12203A;border-color:#22345A}.sc-opt > div{flex:1}.sc-opt b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .sc-opt b{color:#fff}.sc-opt small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.sc-pill .cap{display:flex;align-items:center;gap:6px;padding:9px 16px;border-radius:99px;background:#EEF4FF;border:2px solid transparent;font:800 18px var(--font-display);color:var(--navy)}',
    '.sc-pill .cap .ic{font-size:15px}',
    '.sc-pill small{font:600 12px var(--font-body);color:var(--muted)}',
    '.sc-pill.on .cap{border-color:var(--blue);background:#E6F2FD;box-shadow:0 0 0 3px rgba(0,117,227,.12)}',
    '.sc-pill.on small{color:var(--blue)}',
    '.sc-pill.dim,.sc-total.dim{opacity:.35;filter:blur(1.2px)}',
    /* 0.9.301, Andrea: titolo sopra e testo sotto, al centro (prima titolo a sinistra e testo a destra) */
    '.sc-grant{display:flex;flex-direction:column;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);border-radius:16px;padding:16px 18px;margin:16px 0 4px;cursor:pointer;text-align:center;color:#fff}',
    '.sc-grant b{font:800 16px var(--font-body);display:block;color:#fff}',
    '.sc-grant small{display:block;font:500 13px/1.45 var(--font-body);color:rgba(255,255,255,.85)}',
    '.rep-senza .rep-top{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;padding:22px 18px 20px}.rep-senza-t{font:800 17px var(--font-body);color:var(--navy,#14234A)}',
    '.rep-senza-p{margin:0;font:500 14px/1.5 var(--font-body);color:var(--muted,#5B6B86);max-width:300px}',
    '.rep-senza-b{margin-top:6px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 14px var(--font-body);padding:11px 18px;cursor:pointer}',
    'body.dark .rep-senza-t{color:#fff}body.dark .rep-senza-p{color:#B9C7DD}',
    '.sc-grant .chev{margin-left:auto;color:#fff}',
    '.sc-daynav{display:flex;align-items:center;justify-content:center;gap:6px;margin:0 auto}',
    '.sc-daynav b{font:700 15px var(--font-display);color:var(--navy);min-width:60px;text-align:center}',
    '.sc-daynav .iconbtn:disabled{opacity:.3}',
    '.sc-q{font:800 17px var(--font-display);color:var(--navy);margin:22px 0 6px}',
    '.sc-top{position:relative}.sc-titolo{position:absolute;left:56px;right:56px;text-align:center;font:800 19px var(--font-display);color:var(--navy)}body.dark .sc-titolo{color:#fff}',
    '.sc-per{display:flex;gap:4px;margin:4px 16px 14px;padding:4px;border-radius:14px;background:rgba(0,30,68,.06)}body.dark .sc-per{background:rgba(255,255,255,.06)}',
    '.sc-per button{flex:1;border:0;border-radius:10px;padding:9px 4px;background:transparent;font:700 14px var(--font-body);color:var(--muted);cursor:pointer}',
    '.sc-per button.on{background:var(--card,#fff);color:var(--navy);box-shadow:0 2px 8px rgba(0,30,68,.1)}body.dark .sc-per button.on{background:#1C2B4D;color:#fff}',
    '.sc-gauge{position:relative;width:min(78vw,300px);margin:6px auto 0}.sc-gauge svg{display:block;width:100%;height:auto}',
    '.sc-g-track{fill:none;stroke:rgba(0,30,68,.1);stroke-width:14;stroke-linecap:round}body.dark .sc-g-track{stroke:rgba(255,255,255,.12)}',
    '.sc-g-track.pieno{stroke-linecap:butt}',
    '.sc-g-fill{fill:none;stroke-width:14;stroke-linecap:butt}.sc-g-tac{stroke:#fff;stroke-width:4;stroke-linecap:round;filter:drop-shadow(0 1px 2px rgba(0,0,0,.35))}',
    '.sc-g-mid{position:absolute;left:0;right:0;top:34%;text-align:center}.sc-g-mid b{display:block;font:900 54px/1 var(--font-display);color:var(--navy)}body.dark .sc-g-mid b{color:#fff}',
    '.sc-g-mid span{display:inline-flex;align-items:center;gap:6px;margin-top:8px;font:700 14px var(--font-body);color:var(--muted)}.sc-g-mid i{width:8px;height:8px;border-radius:2px}',
    '.sc-panel{margin:8px 0 0;padding:16px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sc-panel{background:#14234A;border-color:rgba(255,255,255,.1)}',
    '.sc-panel-f{margin:0 0 14px;font:600 15px/1.55 var(--font-body);color:var(--navy)}body.dark .sc-panel-f{color:#fff}',
    '.sc-panel-q{display:flex;align-items:center;gap:8px;margin:0}.sc-panel-q b{font:800 15px var(--font-display);color:var(--navy)}body.dark .sc-panel-q b{color:#fff}',
    '.sc-panel-t{margin:6px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.sc-ff{margin:28px 0 4px;font:800 18px var(--font-display);color:var(--navy)}body.dark .sc-ff{color:#fff}',
    '.sc-i{width:24px;height:24px;margin-left:10px;font-size:12px;vertical-align:2px}',
    '.sc-txt{font:500 13px/1.6 var(--font-body);color:var(--muted);margin:0 0 16px}',
    '.sc-met{padding:14px 0;border-bottom:1px solid var(--line)}',
    '.sc-met .head{display:flex;align-items:baseline;gap:10px}',
    '.sc-met .head b{font:800 15px var(--font-display);color:var(--navy)}',
    '.sc-met .head .val{font:600 14px var(--font-body);color:var(--muted)}',
    '.sc-met .delta{margin-left:auto;font:800 13px var(--font-body)}',
    '.sc-met .delta.good{color:#0E7C6B}.sc-met .delta.bad{color:var(--red)}.sc-met .delta.flat{color:var(--muted)}',
    /* 0.9.295, Andrea: "nei fattori di valutazione, nel Giorno, le frecce e i numeri sono bianchi finche' non cambio periodo".
       Al buio il verde scuro (#0E7C6B) su fondo blu notte non si leggeva, e il guardiano del contrasto (darkfix.js) lo
       ridipingeva di bianco al primo disegno; cambiando periodo il pannello si ridisegnava dopo il suo passaggio. Al buio i
       colori sono quelli chiari, e il guardiano non ha niente da correggere. */
    'body.dark .sc-met .delta.good{color:#3DDC97!important}body.dark .sc-met .delta.bad{color:#FF7A85!important}body.dark .sc-met .delta.flat{color:#9FB2D0!important}',
    '.sc-bar{position:relative;height:10px;border-radius:99px;background:#EDF3FA;margin-top:12px;overflow:hidden}',
    '.sc-bar .fill{position:absolute;top:0;bottom:0;border-radius:99px}',
    '.sc-bar .fill.good{background:linear-gradient(90deg,#9FE3D2,#14A38B)}.sc-bar .fill.bad{background:linear-gradient(90deg,#FFC2C8,#E63946)}.sc-bar .fill.flat{background:#C3D3E4}',
    '.sc-bar .mark{position:absolute;left:50%;top:-2px;bottom:-2px;width:3px;background:#fff;box-shadow:0 0 0 1px rgba(0,30,68,.25);border-radius:2px}',
    '.sc-avg{display:block;text-align:center;font:700 9.5px var(--font-body);letter-spacing:.08em;color:var(--faint);margin-top:4px}',
    '.sc-sleep{display:flex;align-items:center;gap:10px;margin-top:8px}',
    '.sc-sleep .q{font:800 13px var(--font-body);color:#0E7C6B;margin-left:auto;order:2}',
    '.sc-sleep .bars{display:flex;gap:5px;flex:1}',
    '.sc-sleep .bars i{flex:1;height:7px;border-radius:99px;background:#EDF3FA}.sc-sleep .bars i.on{background:#14A38B}',
    '.sc-none{font:500 12px/1.5 var(--font-body);color:var(--muted);margin:6px 0 0}',
    '.sc-foot{font:500 11.5px/1.5 var(--font-body);color:var(--faint);margin:16px 0 0;text-align:center}',
    /* tooltip */
    '.sc-tip{display:none;position:absolute;z-index:120;background:#22314A;color:#fff;font:500 13px/1.5 var(--font-body);border-radius:12px;padding:12px 14px;box-shadow:0 12px 30px rgba(0,30,68,.35)}',
    '.sc-tipbtn{display:block;width:100%;margin-top:12px;border:0;border-radius:99px;background:#fff;color:#0B1A3A;padding:10px;font:800 12px var(--font-body);cursor:pointer}',
    '.sc-tip .txt{white-space:pre-line;display:block;text-align:center}',
    '.sc-tip .dati{display:block;margin:12px 0 0;padding:11px 0 0 18px;text-align:left;list-style:disc;',
      'border-top:1px solid rgba(255,255,255,.16);font:600 13px/1.75 var(--font-body);color:#fff}',
    '.sc-tip .dati li{padding-left:2px}',
    '.sc-tip .dati li::marker{color:#4FB8FF}',
    '.sc-tip .arrow{position:absolute;top:-7px;width:14px;height:14px;background:#22314A;transform:rotate(45deg);border-radius:2px}',
    /* report panel */
    '.rep-panel{background:#fff;border:1px solid var(--line);border-radius:22px;padding:18px 16px;margin:18px 0;position:relative}',
    /* La riserva di dopamina dentro alla panoramica: la card e' gia' una card, qui serve
       solo l'aria sopra ai tre puntini. */
    '.rep-dopa{padding-top:34px}',
    '.sc-dopa-riga{display:flex;align-items:center;gap:14px;width:100%;margin:22px 0 4px;padding:16px;box-sizing:border-box;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);color:var(--navy);text-align:left;font:inherit;cursor:pointer}',
    '.sc-dopa-riga > span{font-size:24px;line-height:1}.sc-dopa-riga > div{flex:1;min-width:0}',
    '.sc-dopa-riga b{display:block;font:800 16px var(--font-body);color:var(--navy)}.sc-dopa-riga small{display:block;margin-top:3px;font:500 13.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sc-dopa-riga svg{flex:none;color:var(--muted)}',
    /* il titoletto di sezione dentro ai menu (categorie, da dove) */
    '.rep-menu .arb-mtit,.ins-menu .arb-mtit{margin:8px 10px 4px;font:800 9.5px var(--font-body);',
      'letter-spacing:.14em;text-transform:uppercase;color:var(--faint)}',
    '.rep-menu .arb-mtit:first-child,.ins-menu .arb-mtit:first-child{margin-top:2px}',
    /* il verdetto della notte, in cima: una riga di tacchette e una parola */
    '.sc-verdetto{margin:16px 0 4px;display:flex;justify-content:center}',
    '.sc-verdetto .sc-sleep{margin:0}',
    '.rep-more{position:absolute;top:10px;right:10px;width:34px;height:34px;border-radius:50%;border:1px solid var(--line);background:#fff;color:var(--navy);font:800 18px/1 var(--font-body);cursor:pointer;z-index:2}',
    '.rep-scrim{position:fixed;inset:0;z-index:4;background:rgba(3,10,26,.55);opacity:0;transition:opacity .2s ease}',
    '.rep-scrim.in{opacity:1}',
    '.rep-scrim[hidden]{display:none}',
    '.rep-menu{position:absolute;top:48px;right:10px;z-index:5;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 12px 30px rgba(0,30,68,.18);padding:6px;min-width:210px}',
    '.rep-menu[hidden]{display:none}',
    '.rep-menu button{display:block;width:100%;text-align:left;border:0;background:none;border-radius:10px;padding:11px 12px;font:600 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.rep-menu button.on{background:var(--blue-soft);color:var(--blue)}',
    'body.dark .rep-more,body.dark .rep-menu{background:#12203A;border-color:#22345A;color:#fff}body.dark .rep-menu button{color:#fff}',
    '.rep-top{text-align:center;cursor:pointer}',
    '.rep-top small{display:block;font:600 13px var(--font-body);color:var(--muted)}',
    '.rep-big{display:block;font:800 40px/1.15 var(--font-display);color:var(--navy);margin:4px 0 8px}',
    '.rep-badge{display:inline-block;font:700 12px var(--font-body);padding:5px 12px;border-radius:99px}',
    '.rep-badge.up{color:var(--red);background:var(--red-soft)}.rep-badge.down{color:#0E7C6B;background:#E2F6F2}.rep-badge.flat{color:var(--muted);background:rgba(0,30,68,.07)}',
    /* il periodo: un'intestazione che si tocca, non un francobollo in un angolo */
    '.rep-rangebtn{display:inline-flex;align-items:center;gap:7px;margin:0 auto;border:0;background:none;color:var(--muted);font:600 13px var(--font-body);cursor:pointer;padding:4px 8px}',
    '.rep-rangebtn i{width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:5px solid currentColor;opacity:.8}',
    '.rep-rangemenu{left:50%;right:auto;transform:translateX(-50%);top:54px}',
    /* il grafico: barre chiare, griglia con i valori a destra, l'ora corrente segnata */
    '.rp-chart{margin-top:20px}',
    '.rep-panel .rep-solo-prot{display:none}#tab-blocco .rep-panel .rep-solo-prot{display:block}#tab-blocco .rep-panel .rep-solo-dream{display:none}',
    '.rp-bars{position:relative;display:flex;align-items:flex-end;gap:3px;height:120px;padding-right:34px;border-bottom:1px solid var(--line)}',
    /* 0.9.290, Andrea: "i minuti escono dal pannello". La riga arrivava fino al bordo e l'etichetta stava 34 px piu' in la':
       la riga si ferma prima della colonna delle etichette, e l'etichetta resta dentro. */
    '.rp-bars .g{position:absolute;left:0;right:34px;border-top:1px solid rgba(0,30,68,.08);pointer-events:none}',
    '.rp-bars .g span{position:absolute;right:-34px;top:-8px;width:30px;text-align:left;font:600 10px var(--font-body);color:var(--muted)}',
    '.rp-bars > b{flex:1;min-width:0;border-radius:3px 3px 0 0;background:#BCE0FF;transition:height .5s cubic-bezier(.2,.8,.2,1)}',
    '.rp-bars > b.now{background:var(--blue,#006FCF);box-shadow:0 0 0 1px rgba(0,111,207,.35)}',
    '.rp-bars > b[onclick]{cursor:pointer;transition:height .5s cubic-bezier(.2,.8,.2,1),opacity .25s}.rp-bars.con-sel > b{opacity:.3}.rp-bars.con-sel > b.sel{opacity:1;background:var(--blue,#006FCF)}',
    'body.dark .rp-bars > b:not(.now):not(.sel){background:rgba(140,198,255,.24)}body.dark .rp-bars .g{border-top-color:rgba(255,255,255,.08)}',
    '.rp-axis{display:flex;gap:3px;padding-right:34px;margin-top:6px}',
    '.rp-axis span{flex:1;min-width:0;text-align:center;font:600 10px var(--font-body);color:var(--muted);white-space:nowrap;overflow:visible}',
    '.rep-cards{display:flex;gap:10px;margin-top:16px}',
    '.rep-card{flex:1;border:1px solid var(--line);border-radius:14px;padding:12px 14px}',
    '.rep-card small{display:flex;align-items:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.rep-metrics{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin:0 calc(-1 * var(--bleed, 0px)) 12px;padding:2px var(--bleed, 0px) 4px}',
    '.rep-metrics::-webkit-scrollbar{display:none}',
    '.rep-metrics button{flex:0 0 auto;border:1px solid var(--line);background:#fff;border-radius:99px;padding:8px 14px;font:700 12px var(--font-body);color:var(--muted);white-space:nowrap;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.rep-metrics button.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .rep-metrics button{background:#12203A;border-color:#22345A}',
    'body.dark .rep-metrics button.on{background:var(--blue);border-color:var(--blue)}',
    '.rep-card small i{margin-left:auto;width:18px;height:18px;border-radius:50%;border:1.5px solid var(--faint);color:var(--faint);font:700 10px/16px var(--font-body);text-align:center;font-style:normal;cursor:pointer}',
    '.rep-card b{display:flex;align-items:center;gap:8px;font:800 24px var(--font-display);color:var(--navy);margin-top:6px}',
    '.rep-card b em{font:700 12px var(--font-body);font-style:normal;padding:3px 8px;border-radius:99px}',
    '.rep-card b em.down{color:#0E7C6B;background:#E2F6F2}.rep-card b em.up{color:var(--red);background:var(--red-soft)}',
    '.rep-att{margin-top:18px}',
    '.rep-att > b{display:block;font:800 16px var(--font-display);color:var(--navy);margin-bottom:12px}',
    '.rep-row{display:flex;align-items:center;gap:12px;padding:8px 0;cursor:pointer}',
    '.rep-row img,.rep-row .ico{width:36px;height:36px;border-radius:10px;flex:none;object-fit:cover}',
    '.rep-row .ico{background:var(--blue);color:#fff;display:flex;align-items:center;justify-content:center;font:800 15px var(--font-display)}',
    '.rep-row .nm{flex:1;min-width:0}',
    '.rep-row .nm span{display:block;font:600 13px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.rep-row .track{display:block;height:4px;margin-top:6px;border-radius:99px;background:repeating-linear-gradient(90deg,#D6E1EE 0 6px,transparent 6px 10px)}',
    '.rep-row .track b{display:block;height:100%;border-radius:99px;background:var(--navy)}',
    '.rep-row .tm{font:800 13px var(--font-body);color:var(--navy);flex:none}',
    'body.dark .rep-panel,body.dark .rep-card{background:#12203A;border-color:#22345A}',
    'body.dark .rep-big,body.dark .rep-att > b,body.dark .rep-row .nm span,body.dark .rep-row .tm,body.dark .rep-card b,body.dark .sc-total b,body.dark .sc-q,body.dark .sc-met .head b{color:#fff}',
    'body.dark .sc-pill .cap{background:#1B2E52;color:#fff}body.dark .rep-row .track b{background:#8FB4FF}',
    /* Ispirazione quotidiana */
    '#s-inspire{padding:0}',
    '.insp-sky{position:relative;flex:1;overflow-y:auto;display:flex;flex-direction:column;padding:22px 22px calc(24px + env(safe-area-inset-bottom));',
    '  background:linear-gradient(180deg,rgba(3,10,26,.45),rgba(3,10,26,.82)),url("img/dream-night.jpg") center/cover no-repeat,#0A1830}',
    '.insp-sky > *:not(.starfield){position:relative;z-index:1}',
    '.insp-bar b{font:700 15px var(--font-display);color:#fff;flex:1;min-width:0;text-align:center;margin-right:48px}',
    '.insp-bar .iconbtn.light{background:rgba(255,255,255,.15);color:#fff}',
    '.insp-days{display:flex;gap:8px;justify-content:center;margin:8px 0 26px;flex-wrap:wrap}',
    '.insp-day{width:38px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.22);background:rgba(255,255,255,.1);color:#fff;font:700 14px var(--font-body);cursor:pointer}',
    '.insp-day{position:relative}.insp-day.chiuso{opacity:.78;padding-bottom:12px}.insp-lock-ico{position:absolute;left:50%;bottom:3px;transform:translateX(-50%);font-size:9px;line-height:1;font-style:normal}',
    '.insp-day.on{background:#fff;color:#0A1830;border-color:#fff}',
    '.insp-date{text-align:center;color:#fff;margin-bottom:20px}',
    '.insp-date b{display:block;font:800 42px/1 var(--font-display)}',
    '.insp-date span{font:600 13px var(--font-body);opacity:.85}',
    /* Lo stesso carattere della frase del giorno sulla pagina Wishlist del sito: Poppins
       in grassetto, 1.4em del corpo (19.5px), interlinea 1.714. Non un serif diverso. */
    '.insp-quote{font:700 19.5px/1.714 var(--font-body);color:#fff;text-align:center;text-shadow:0 2px 12px rgba(0,0,0,.45);margin:0}',
    '.insp-quote .ln > i{animation:bhLine .85s cubic-bezier(.22,.61,.36,1) forwards;animation-delay:.15s}',
    '.insp-author{font:italic 500 14px var(--font-body);color:rgba(255,255,255,.85);text-align:center;margin-top:16px}',
    '.insp-acts{display:flex;justify-content:center;gap:14px;margin:28px 0}',
    '.insp-act{width:46px;height:46px;border-radius:50%;border:none;background:rgba(255,255,255,.16);color:#fff;font-size:18px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}',
    /* 0.9.267, Andrea: i due blocchi si toccavano ed erano trasparenti (poco leggibili): fondo scuro e 12 px di aria */
    '.insp-lock{display:flex;align-items:center;gap:12px;background:rgba(10,30,70,.78);border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:14px;margin-top:auto}',
    '.insp-lock + .insp-lock,.insp-lock + #foRiga,#foRiga > .insp-lock{margin-top:12px}',
    '.insp-lock > div{flex:1;min-width:0}',
    '.insp-lock b{display:block;font:700 13.5px/1.35 var(--font-body);color:#fff}',
    '.insp-lock small{display:block;font:500 11.5px/1.45 var(--font-body);color:rgba(255,255,255,.75);margin-top:3px}',
    /* the two ways to share, under the share button */
    '.insp-share-menu{display:flex;flex-direction:column;gap:8px;margin:-14px 0 18px}',
    '.insp-share-menu[hidden]{display:none}',
    '.insp-share-menu button{display:block;width:100%;text-align:left;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.12);border-radius:14px;padding:12px 16px;color:#fff;cursor:pointer;backdrop-filter:blur(6px)}',
    '.insp-share-menu b{display:block;font:700 13.5px var(--font-body)}',
    '.insp-share-menu small{display:block;font:500 11.5px var(--font-body);color:rgba(255,255,255,.7);margin-top:2px}',
    '.insp-credit{margin:0 0 14px;text-align:center;font:500 11px var(--font-body);color:rgba(255,255,255,.55);cursor:pointer}',
    '.insp-credit b{font-weight:700;color:rgba(255,255,255,.8)}',
    /* "Se continui cosi": the closing panel of the Report */
    /* l'aura della bolla della Modalità severa, intorno alla card: la stessa luce che gira */
    '.life-intro{padding:22px 0 4px}',
    '.life-sub{margin:10px 18px 16px;font:italic 600 13px/1.6 var(--font-body);color:var(--muted);text-align:center}',
    '.life-sub i{display:block;margin-top:6px;font:600 12px var(--font-body);font-style:normal;color:var(--faint)}',
    /* Jung: il ritratto a destra, la frase nella nebbia a sinistra, nella lingua del telefono */
    '.jung{position:relative;margin:24px -6px -6px;border-radius:18px;overflow:hidden;aspect-ratio:3/2;',
    '  background:url("img/jung.jpg") center/cover no-repeat;animation:sevRise .9s ease-out both;animation-delay:.35s}',
    '.jung-in{position:absolute;inset:0;width:56%;display:flex;flex-direction:column;justify-content:center;padding:16px 8px 16px 16px;text-align:left}',
    /* un velo chiaro sotto le parole: la nebbia dell'illustrazione cambia tono, il testo no */
    '.jung-in::before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(238,243,240,.82),rgba(238,243,240,.68) 72%,rgba(238,243,240,0));z-index:0}',
    '.jung-in p,.jung-in small{position:relative;z-index:1}',
    '.jung-in p{margin:0;font:700 13px/1.45 var(--font-display);color:#0F2B33;letter-spacing:.1px}',
    '.jung-in small{display:block;margin-top:10px;font:800 11px var(--font-body);color:#1C4652}',
    '@media (min-width:400px){.jung-in p{font-size:14.5px}}',
    '.rep-locked{margin:12px 0 0;padding-top:10px;border-top:1px solid var(--line);font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.rep-locked b{color:var(--navy);font-weight:800}',
    'body.dark .rep-locked b{color:#fff}',
    '.rep-locked button{border:0;background:none;padding:0;margin-left:4px;font:800 12px var(--font-body);color:var(--blue,#0075E3);cursor:pointer;text-decoration:underline}',
    '.life-wrap{position:relative;margin:6px 0 14px;isolation:isolate}',
    /* Lo stesso meccanismo della bolla (.pf-box::before): non gira l'elemento, gira l'ANGOLO del
       conic-gradient, che è una proprietà registrata (@property --angle) e quindi animabile.
       Prima c'era "from 0deg" con un'animazione che non esisteva: il gradiente restava fermo. */
    '.life-wrap::before{content:"";position:absolute;inset:-8px;border-radius:30px;z-index:-1;pointer-events:none;',
    '  background:conic-gradient(from var(--angle),#3F9FF4,#0075E3,#E63946,#3F9FF4);filter:blur(13px);animation:spin 3s linear infinite}',
    /* "Il primo passo" chiude la scheda, staccato dal pannello del futuro */
    '#sevStreakFoot{margin:72px 0 48px}',
    '.life{background:var(--navy);color:#fff;border-radius:22px;padding:30px 22px 24px;margin:0;text-align:center;position:relative;z-index:1}',
    '.life-q{margin:18px 0 0;text-align:left}',
    '.life-q label{display:block;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.66);margin-bottom:8px}',
    '.life-q input{width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.08);border-radius:14px;padding:13px 16px;font:600 15px var(--font-body);color:#fff}',
    '.life-q input::placeholder{color:rgba(255,255,255,.4);font-weight:500}',
    '.life-chips{display:flex;gap:8px;flex-wrap:wrap}',
    '.life-chip{border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.06);border-radius:99px;padding:10px 16px;font:700 13px var(--font-body);color:#fff;cursor:pointer}',
    '.life-chip.on{background:#fff;color:var(--navy);border-color:#fff}',
    '.life-go{width:100%;margin-top:20px;border:0;border-radius:99px;background:#fff;color:var(--navy);padding:15px;font:800 14px var(--font-body);letter-spacing:.04em;cursor:pointer}',
    '.life-go + .life-edit{margin-top:12px}',
    '.life-who{margin-top:14px;font-size:64px;line-height:1;filter:drop-shadow(0 8px 18px rgba(0,0,0,.35))}',
    '.life-big.who{font-size:30px;line-height:1.15;margin-top:10px;color:#fff}',
    /* 0.9.305: in scuro darkfix.js tinge di verde ogni .life-big: il nome di chi rischi di diventare resta bianco come in chiaro (il verde e' solo per i miglioramenti) */
    'body.dark .life-big.who{color:#fff !important}',
    '.life-links{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px}',
    '.life-links .life-edit{margin-top:0}',
    '.life-alt{margin-top:26px;padding-top:22px;border-top:1px solid rgba(255,255,255,.16)}',
    '.life-big.alt{color:#9EC1FF}',
    '.life-odds{margin-top:26px;padding:20px 16px 16px;border-radius:18px;background:rgba(255,255,255,.07)}',
    '.life-oddsnum{font:800 52px/1 var(--font-display);font-style:italic;color:#8CF0C8}',
    '.life-oddsnum span{font-size:22px;margin-left:2px}',
    '.life-odds > b{display:block;margin-top:6px;font:700 13px var(--font-body);color:#fff}',
    '.life-why{list-style:none;margin:14px 0 10px;padding:0;text-align:left}',
    '.life-why li{display:flex;gap:10px;align-items:baseline;padding:7px 0;font:500 12.5px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.life-why i{font-style:normal;font-weight:800;min-width:38px;color:#8CF0C8}',
    '.life-why li:has(i:first-child) i{}',
    '.life-odds small{display:block;font:500 11px/1.5 var(--font-body);color:rgba(255,255,255,.55)}',
    '.life-t{display:block;font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.66)}',
    '.life-big{margin-top:14px;font:800 56px/1 var(--font-display);font-style:italic;color:#8CF0C8}',
    '.life-big span{font:800 18px var(--font-display);font-style:italic;color:rgba(255,255,255,.8);margin-left:8px}',
    '.life-p{margin:14px 0 0;font:500 14px/1.6 var(--font-body);color:rgba(255,255,255,.88)}',
    '.life-p strong{font-weight:800;color:#fff}',
    '.life-list{list-style:none;margin:22px 0 0;padding:0;border-top:1px solid rgba(255,255,255,.16)}',
    '.life-list li{display:flex;gap:8px;align-items:baseline;justify-content:center;text-align:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1);font:500 13px var(--font-body);color:rgba(255,255,255,.78)}',
    '.life-list b{font:800 15px var(--font-display);color:#fff;flex:none}',
    '.life-note{display:block;margin-top:22px;font:500 11px/1.5 var(--font-body);color:rgba(255,255,255,.52)}',
    '.life-edit{margin-top:14px;border:1px solid rgba(255,255,255,.24);background:none;border-radius:99px;padding:8px 16px;font:700 11.5px var(--font-body);color:#fff;cursor:pointer}',
    '.life-ask{display:flex;gap:10px;margin-top:16px;justify-content:center}',
    '.life-ask input{flex:1;min-width:0;border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.08);border-radius:14px;padding:13px 16px;font:700 16px var(--font-body);color:#fff}',
    '.life-ask input::placeholder{color:rgba(255,255,255,.45);font-weight:500}',
    '.life-ask button{flex:none;border:0;border-radius:14px;background:var(--blue);color:#fff;padding:13px 20px;font:800 13px var(--font-body);cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();
/* 0.9.291: tornando a Proteggi i tuoi sogni (anche con indietro) la panoramica si rilegge se era rimasta vuota */
document.addEventListener('fl:screen', function(e){
  if (e.detail !== 's-blocco') return;
  const rep = document.getElementById('blkReport');
  if (!rep || !rep.children.length){ try{ scBlockScores(); }catch(_){ } }
});
