/* interrupt.js — il momento in cui stai per mollare.

   Due schermate, un solo scopo: mettere fra il dito e l'interruzione abbastanza attrito da
   far passare l'impulso. Non un ostacolo per punire — l'impulso dura venti secondi, e tutto
   quello che serve è che la strada per cedere sia più lunga di venti secondi.

     · INTERROMPI UN PROGRAMMA — quante volte l'hai già interrotto oggi, la frase che ti sei
       scritto da lucido, e un pulsante rosso da tenere premuto mentre il telefono trema.
     · STOP AL BLOCCO RAPIDO — il pannello olografico della decisione, con il conto da pagare:
       un punto al vecchio te e punti tolti al livello.

   La frase compare a macchina da scrivere, con il suo suono: è lo stesso effetto della pagina
   Wishlist del sito (stessa registrazione), e serve a far leggere la frase invece di saltarla.
*/

/* ---------- la macchina da scrivere ---------- */
const IT_TW = { audio: null };
/* Il file e' un anello di cinque secondi a 22 kHz: venti chili, non centosessanta.
   E si prepara una volta sola quando il telefono non sta facendo altro — la prima
   decodifica in mezzo all'animazione era una pausa a meta' della prima parola. */
function itTypeReady(){
  if (IT_TW.audio) return IT_TW.audio;
  try{
    const a = new Audio('audio/typewriter.ogg');
    a.loop = true;
    a.preload = 'auto';
    a.volume = 0.75;
    IT_TW.audio = a;
  }catch(_){ IT_TW.audio = null; }
  return IT_TW.audio;
}
function itTypeSound(on){
  try{
    const a = itTypeReady();
    if (!a) return;
    if (on){ try{ a.currentTime = 0; }catch(_){ } const p = a.play(); if (p && p.catch) p.catch(function(){}); }
    else { a.pause(); }
  }catch(_){ }
}
if (typeof requestIdleCallback === 'function') requestIdleCallback(itTypeReady);
else setTimeout(itTypeReady, 4000);
/* Le lettere si AGGIUNGONO davanti al cursore, non si svelano: un cursore che aspetta in fondo
   alla frase dal primo fotogramma racconta già il finale. Stessa scelta di scores.js. */
function itType(el, text, speed, done){
  if (!el) return;
  el.innerHTML = '';
  const chars = Array.from(String(text || ''));
  const cur = document.createElement('span');
  cur.className = 'typewriter-cursor';
  cur.textContent = '|';
  el.appendChild(cur);
  itTypeSound(true);
  let i = 0;
  const step = function(){
    if (!document.body.contains(el)){ itTypeSound(false); return; }
    if (i < chars.length){
      const sp = document.createElement('span');
      sp.className = 'typewriter-char visible';
      sp.textContent = chars[i++];
      el.insertBefore(sp, cur);
      setTimeout(step, (typeof CIT_MS === 'number') ? CIT_MS : 55);   /* 0.9.263: la velocita' della frase del giorno */
      return;
    }
    itTypeSound(false);
    setTimeout(function(){ if (cur.parentNode) cur.remove(); }, 900);
    if (done) done();
  };
  setTimeout(step, 260);
}

/* ---------- quante volte oggi ---------- */
const IT_KEY = 'fl_interrupts';
function itDay(){ const d = new Date(); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
function itLog(){ try{ return JSON.parse(localStorage.getItem(IT_KEY) || '{}') || {}; }catch(_){ return {}; } }
function itCount(id){ const l = itLog()[itDay()] || {}; return l[id] || 0; }
function itBump(id){
  /* Ogni interruzione confermata e' uno scambio perso, e sul tabellone si vede. Passa da qui
     sia l'interruzione di un programma sia lo stop del blocco rapido: un posto solo. */
  try{ if (typeof mgOldPoint === 'function') mgOldPoint(id === 'quick' ? 'blocco rapido fermato' : 'blocco interrotto'); }catch(_){ }
  /* IL CONTATORE PERDE L'ISTANTE, ED E' L'ISTANTE CHE SERVE.
     «Oggi hai interrotto tre blocchi» non si puo' curare. «Alle 21:47, dopo undici minuti su
     YouTube, hai fermato il blocco» si': dice l'ora in cui la giornata si e' rotta. Il contatore
     resta — lo leggono il tabellone e l'arbitro — e accanto nasce il registro. */
  try{
    const reg = JSON.parse(localStorage.getItem('fl_interrupts_log') || '[]') || [];
    reg.push({ at: Date.now(), id: id });
    localStorage.setItem('fl_interrupts_log', JSON.stringify(reg.slice(-600)));
  }catch(_){ }

  const all = itLog(), day = itDay();
  all[day] = all[day] || {};
  all[day][id] = (all[day][id] || 0) + 1;
  const days = Object.keys(all).sort();
  while (days.length > 60) delete all[days.shift()];
  try{ localStorage.setItem(IT_KEY, JSON.stringify(all)); }catch(_){ }
  /* Il tabellone dell'arbitro ha appena preso un punto: ridisegnarlo adesso e' l'unico modo
     perche' chi torna indietro veda il numero cambiato invece di quello di prima. */
  try{ if (typeof arbPaint === 'function') arbPaint(); }catch(_){ }
}

/** «Niente pause» (Impostazioni): un blocco partito non si ferma a meta'. */
function itNoPause(){ try{ return localStorage.getItem('fl_no_pause') === '1'; }catch(_){ return false; } }
function itNoPauseDice(){
  if (typeof toast === 'function') toast('Hai scelto niente pause: questo blocco va fino in fondo. Lo cambi in Impostazioni.');
}

/** Una pausa finita: il blocco e' tornato acceso. Con l'interruzione, fa la durata della pausa. */
function itRipresa(id){
  try{
    const reg = JSON.parse(localStorage.getItem('fl_riprese_log') || '[]') || [];
    reg.push({ at: Date.now(), id: id });
    localStorage.setItem('fl_riprese_log', JSON.stringify(reg.slice(-600)));
  }catch(_){ }
}

/* ---------- la schermata ---------- */
registerOverlay('itWrap', '');
/* Cintura e bretelle: anche se qualcuno domani togliesse la regola CSS, il pannello nasce
   spento. Un contenitore a tutto schermo che nessuno ha chiesto non deve mai essere vivo. */
(function(){ const el = document.getElementById('itWrap'); if (el){ el.hidden = true; el.classList.remove('open', 'in'); } })();

const IT = { onYes: null, timer: null, t0: 0 };

/* La frase che ti fermerà: quella scritta nel programma, altrimenti il mantra del proprio
   perché, altrimenti una di riserva. Non si lascia mai vuoto questo spazio: è l'unico posto
   della schermata in cui parli tu e non l'app. */
function itNote(p){
  if (p && p.stopNote && p.stopNote.trim()) return p.stopNote.trim();
  try{ if (typeof whyMantra === 'function'){ const m = whyMantra(); if (m && m.trim()) return m.trim(); } }catch(_){ }
  return 'Ricordati perché l\'hai acceso.';
}

function itOpen(opts){
  const el = document.getElementById('itWrap');
  if (!el) return;
  IT.onYes = opts.onYes || null;
  el.innerHTML =
      '<div class="it-bg"></div>'
    + '<button type="button" class="it-x" onclick="itClose()" aria-label="Chiudi">'
    +   '<svg viewBox="0 0 14 14" width="16" height="16"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg></button>'
    + '<div class="it-body">'
    +   '<h2 class="it-h"><span class="ln" style="--i:0"><i>' + esc(opts.title) + '</i></span></h2>'
    +   '<div class="it-count"><b>' + opts.count + '<span>×</span></b><small>' + esc(opts.countLabel) + '</small>'
    +     (opts.cost ? '<em>' + esc(opts.cost) + '</em>' : '') + '</div>'
    +   '<p class="it-note" id="itNote"></p>'
    +   '<div class="it-acts">'
    +     '<button type="button" class="it-hold" id="itHold"><i></i><span>' + esc(opts.yes) + '</span></button>'
    +     '<button type="button" class="it-keep" onclick="itClose()">' + esc(opts.no) + '</button>'
    +   '</div>'
    + '</div>';
  el.hidden = false;
  el.classList.add('open');
  document.body.classList.add('it-on');
  requestAnimationFrame(function(){ el.classList.add('in'); });
  setTimeout(function(){ itType(document.getElementById('itNote'), opts.note, 42); }, 620);
  itBindHold();
}
function itClose(){
  const el = document.getElementById('itWrap');
  itTypeSound(false);
  itStopHold();
  if (!el) return;
  el.classList.remove('in');
  setTimeout(function(){ el.classList.remove('open'); el.hidden = true; el.innerHTML = ''; document.body.classList.remove('it-on'); }, 260);
}

/* Tieni premuto, e il telefono trema sempre più forte.
   Un tocco si dà per sbaglio, due secondi e mezzo di pressione no — ed è il tempo che serve
   perché l'impulso passi. La vibrazione che cresce dice quanto manca senza una barra. */
const IT_HOLD_MS = 2500;
function itBindHold(){
  const b = document.getElementById('itHold');
  if (!b) return;
  const start = function(e){
    if (e && e.preventDefault) e.preventDefault();
    if (IT.timer) return;
    IT.t0 = Date.now();
    b.classList.add('holding');
    IT.timer = setInterval(function(){
      const k = Math.min(1, (Date.now() - IT.t0) / IT_HOLD_MS);
      try{ flVibra(Math.round(8 + 42 * k)); }catch(_){ }
      if (k >= 1){
        itStopHold();
        try{ flVibra([0, 120]); }catch(_){ }
        const f = IT.onYes; IT.onYes = null;
        itClose();
        if (f) setTimeout(f, 280);
      }
    }, 90);
  };
  b.addEventListener('touchstart', start, { passive: false });
  b.addEventListener('mousedown', start);
  ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(function(ev){
    b.addEventListener(ev, function(){ itStopHold(); });
  });
}
function itStopHold(){
  if (IT.timer){ clearInterval(IT.timer); IT.timer = null; }
  try{ flVibra(0); }catch(_){ }
  const b = document.getElementById('itHold');
  if (b) b.classList.remove('holding');
}

/* ---------- interrompere un programma ---------- */
function itProgramAsk(i){
  const p = (typeof PROGRAMS !== 'undefined' && PROGRAMS) ? PROGRAMS[i] : null;
  if (!p){ if (typeof toggleProgram === 'function') toggleProgram(i); return; }
  const id = 'p' + (p.id || i);
  if (itNoPause()){ itNoPauseDice(); return; }
  itOpen({
    title: 'Davvero vuoi interrompere?',
    count: itCount(id),
    countLabel: 'Interrotto oggi',
    note: itNote(p),
    yes: 'Tieni premuto per interrompere',
    no: 'Mantieni il blocco',
    onYes: function(){
      itBump(id);
      if (typeof toggleProgram === 'function') toggleProgram(i);
    }
  });
}

/* ---------- lo STOP del blocco rapido ----------
   La stessa schermata dell'interruzione, non il pannello olografico: quello resta alla
   Modalita' severa. Il conto e' uno solo e si dice in una riga: fermarlo costa punti al
   livello. Tenerlo non ne da' — un pulsante che regala punti a ogni tocco si munge, e un
   punteggio che si munge non misura niente. */
const IT_QUIT_LOSS = -120;
function itQuickAsk(){
  if (itNoPause()){ itNoPauseDice(); return; }
  itOpen({
    title: 'Vuoi davvero fermarlo?',
    count: itCount('quick'),
    countLabel: 'Fermato oggi',
    cost: 'Fermarlo adesso vale ' + IT_QUIT_LOSS + ' punti rispetto al livello che hai raggiunto.',
    note: itNote(null),
    yes: 'Tieni premuto per fermare',
    no: 'Mantieni il blocco',
    onYes: function(){
      itBump('quick');
      if (typeof decVote === 'function') decVote('quit', false, IT_QUIT_LOSS);
      if (typeof quickBlockToggle === 'function') quickBlockToggle(true);
    }
  });
}

(function(){
  const css = [
    /* display:none di base, e si accende con una classe.
       registerOverlay crea il contenitore SENZA hidden: con position:fixed, inset:0 e
       opacity:0 questo pannello e' rimasto una lastra di vetro invisibile sopra a tutta
       l'app, che si prendeva ogni tocco e ogni scorrimento. Un pannello nascosto deve
       essere fuori dal flusso, non trasparente. */
    '#itWrap{display:none;position:fixed;inset:0;z-index:88;background:#050A14;color:#fff;opacity:0;transition:opacity .26s ease;overflow-y:auto}',
    '#itWrap.open{display:block}',
    '#itWrap.in{opacity:1}',
    'body.it-on{overflow:hidden}',
    /* un fondo che respira: la stessa notte delle altre schermate, senza fotografie */
    '.it-bg{position:absolute;inset:0;background:radial-gradient(120% 80% at 50% -10%,#0E2350 0%,#050A14 62%)}',
    '.it-x{position:absolute;top:calc(14px + env(safe-area-inset-top));left:14px;z-index:2;width:40px;height:40px;border:0;border-radius:50%;background:rgba(255,255,255,.08);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.it-body{position:relative;z-index:1;min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:calc(80px + env(safe-area-inset-top)) 26px calc(40px + env(safe-area-inset-bottom))}',
    /* Il titolo sale da sotto, come le righe delle diapositive: stessa .ln, stessa animazione. */
    '.it-h{margin:0;font:800 30px/1.2 var(--font-display);font-style:italic}',
    '.it-h .ln > i{animation:bhLine .85s cubic-bezier(.22,.61,.36,1) forwards;animation-delay:.12s}',
    '.it-count{margin-top:52px}',
    '.it-count b{display:block;font:800 62px/1 var(--font-display);color:#2F8BFF}',
    '.it-count b span{font-size:34px;margin-left:2px}',
    '.it-count small{display:block;margin-top:12px;font:600 15px var(--font-body);color:rgba(255,255,255,.8)}',
    '.it-count em{display:block;margin:14px auto 0;max-width:24em;font:500 13.5px/1.55 var(--font-body);font-style:normal;color:rgba(255,255,255,.62)}',
    /* La frase: il posto in cui parli tu. Grande, con aria sopra e sotto, e battuta a macchina. */
    '.it-note{margin:52px 0 0;min-height:3.2em;font:500 17px/1.65 var(--font-body);font-style:italic;color:rgba(255,255,255,.92);max-width:22em}',
    '.it-acts{width:100%;max-width:340px;margin-top:56px}',
    '.it-hold{position:relative;overflow:hidden;width:100%;border:0;border-radius:99px;padding:19px;background:#E5515F;color:#fff;font:800 15px var(--font-body);cursor:pointer;user-select:none;-webkit-user-select:none}',
    '.it-hold span{position:relative;z-index:1}',
    '.it-hold i{position:absolute;top:0;left:0;bottom:0;width:0;background:rgba(255,255,255,.28)}',
    '.it-hold.holding i{width:100%;transition:width 2.5s linear}',
    '.it-hold.holding{transform:scale(.985)}',
    /* blu, non grigio: restare è la scelta che l'app consiglia, e si vede */
    '.it-keep{width:100%;margin-top:14px;border:0;border-radius:99px;padding:19px;background:var(--blue,#006FCF);color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '@media (max-height:680px){.it-count{margin-top:34px}.it-note{margin-top:34px}.it-acts{margin-top:36px}}'
  ].join('\n');
  const st = document.createElement('style');
  st.textContent = css;
  document.head.appendChild(st);
})();
