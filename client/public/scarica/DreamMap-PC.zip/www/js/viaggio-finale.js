/* viaggio-finale.js — IL VIAGGIO DEL LIVELLO FINALE A STORIE (0.9.351)
   Andrea: la schermata bianca "Ecco la strada che hai fatto." con quattro box tutti insieme e senza emoji non va,
   e "Dove vuoi andare adesso?" senza immagine nemmeno. Da "Guarda il tuo viaggio" ora parte un riepilogo scuro a
   tutto schermo come le storie di Instagram: barre in alto (una per storia, avanti da sola ogni 4,5 s), tocco a
   destra = avanti, a sinistra = indietro, tenuto premuto = pausa, X per chiudere. Un dato per storia, con l'emoji
   grande, il numero che sale e una riga sola. Poi "Dove vuoi andare adesso?" scuro, con le montagne in alto.
   Questo file carica DOPO sentiero-mappa.js e ne sostituisce le globali sdFinalePaint / sdFinaleAvanti /
   sdFinaleChiudi / sdFinaleAnteprima; i numeri restano quelli di sdViaggioNumeri() e lo stato resta SD.finale
   (passo 0 = l'arrivo, disegnato dal codice di prima; passo 1 = le storie, SD.finale.storia; passo 2 = il prossimo
   viaggio). L'anteprima per l'admin (sdFinaleAnteprima dal nodo del sogno) non scrive niente, come prima. */
(function(){
  if (typeof sdFinalePaint !== 'function') return;
  const vfPaintArrivo = sdFinalePaint;
  const DUR = 4500;
  const VF = { F: null, i: 0, el: 0, last: 0, pausa: false, raf: 0, giu: 0, tenuto: false, fermo: false };

  const ridotto = function(){ try{ return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ return false; } };
  const vibra = function(p){ try{ flVibra(p); }catch(_){ } };
  const pl = function(v, u){ return v === 1 ? u[0] : u[1]; };
  const esc = function(x){ try{ return sdEsc(x); }catch(_){ return String(x == null ? '' : x); } };
  const icona = function(){ try{ return (typeof cstIcona === 'function' && cstIcona()) || '🏁'; }catch(_){ return '🏁'; } };
  const oreTxt = function(h){ try{ return sdOreTxt(h); }catch(_){ return String(Math.round(h)); } };
  const X_SVG = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg>';
  const SCHERMO = function(){ return document.getElementById('s-sd-sogno'); };

  function css(){
    if (document.getElementById('vf-css')) return;
    const s = document.createElement('style'); s.id = 'vf-css';
    s.textContent = [
      '#s-sd-sogno.vf-scuro,body.dark #s-sd-sogno.vf-scuro{background:#001E44}',
      '#sdSg.vf-on{overflow:hidden;color:#fff;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}',
      /* le storie */
      '.vf-st{position:absolute;inset:0;overflow:hidden;background:#001E44;touch-action:manipulation}',
      '.vf-bg{position:absolute;inset:0;opacity:0;transition:opacity .7s ease;pointer-events:none}.vf-bg.on{opacity:1}',
      '.vf-bg0{background:linear-gradient(180deg,rgba(0,30,68,.55) 0%,rgba(0,30,68,.82) 55%,#001E44 100%),#001E44 url("img/bg/montagne.jpg") center bottom/cover no-repeat}',
      '.vf-bg1{background:radial-gradient(90% 55% at 50% 30%,rgba(0,117,227,.55) 0%,rgba(0,117,227,0) 70%),#001E44}',
      '.vf-bg2{background:radial-gradient(85% 50% at 20% 22%,rgba(63,159,244,.45) 0%,rgba(63,159,244,0) 70%),radial-gradient(70% 45% at 90% 85%,rgba(0,117,227,.35) 0%,rgba(0,117,227,0) 70%),#001E44}',
      '.vf-bg3{background:radial-gradient(90% 55% at 80% 25%,rgba(0,117,227,.5) 0%,rgba(0,117,227,0) 70%),#001E44}',
      '.vf-bg4{background:radial-gradient(95% 55% at 50% 35%,rgba(140,198,255,.32) 0%,rgba(140,198,255,0) 70%),#001E44}',
      '.vf-bg5{background:radial-gradient(90% 55% at 30% 30%,rgba(63,159,244,.42) 0%,rgba(63,159,244,0) 70%),radial-gradient(80% 50% at 80% 90%,rgba(0,117,227,.4) 0%,rgba(0,117,227,0) 70%),#001E44}',
      '.vf-barre{position:absolute;z-index:3;top:calc(env(safe-area-inset-top,0px) + 12px);left:12px;right:12px;display:flex;gap:4px;pointer-events:none}',
      '.vf-barre span{flex:1;height:3px;border-radius:99px;background:rgba(255,255,255,.28);overflow:hidden}',
      '.vf-barre i{display:block;height:100%;width:100%;background:#fff;border-radius:99px;transform-origin:left center;transform:scaleX(0)}',
      '.vf-x{position:absolute;z-index:4;top:calc(env(safe-area-inset-top,0px) + 24px);right:8px;width:44px;height:44px;border:0;border-radius:50%;background:transparent;color:#fff;display:grid;place-items:center;cursor:pointer}',
      '.vf-x svg{filter:drop-shadow(0 1px 3px rgba(0,30,68,.6))}',
      '.vf-tap{position:absolute;inset:0;z-index:1}',
      '.vf-c{position:absolute;inset:0;z-index:2;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 88px) 28px calc(env(safe-area-inset-bottom,0px) + 40px);box-sizing:border-box;pointer-events:none}',
      '.vf-c button{pointer-events:auto}',
      '.vf-c.dx{animation:vfDx .55s cubic-bezier(.2,.8,.2,1) both}.vf-c.sx{animation:vfSx .55s cubic-bezier(.2,.8,.2,1) both}',
      '@keyframes vfDx{from{opacity:0;transform:translateX(28px)}to{opacity:1;transform:none}}',
      '@keyframes vfSx{from{opacity:0;transform:translateX(-28px)}to{opacity:1;transform:none}}',
      '.vf-ico{width:132px;height:132px;border-radius:50%;padding:3px;box-sizing:border-box;background:linear-gradient(160deg,#E63946 0%,#0075E3 55%,#001E44 100%);margin:0 0 32px;flex:none}',
      '.vf-ico span{width:100%;height:100%;border-radius:50%;background:#0B2C5C;display:flex;align-items:center;justify-content:center;font-size:62px;line-height:1}',
      '.vf-c.dx .vf-ico span,.vf-c.sx .vf-ico span{animation:vfPop .7s .1s cubic-bezier(.3,1.4,.5,1) both}',
      '@keyframes vfPop{from{transform:scale(.6);opacity:0}to{transform:none;opacity:1}}',
      '.vf-num{margin:0;font:900 96px/1 var(--font-display);color:#fff;letter-spacing:-.02em;font-variant-numeric:tabular-nums}',
      '.vf-frase{margin:14px 0 0;max-width:15em;font:800 23px/1.3 var(--font-display);color:#fff}',
      '.vf-sub{margin:24px 0 0;max-width:30ch;font:500 15.5px/1.55 var(--font-body);color:#C8EFFD}',
      '.vf-pre{margin:0;font:700 15px/1.4 var(--font-body);color:#8CC6FF}',
      '.vf-sogno{margin:24px 0 0;max-width:13em;font:900 32px/1.2 var(--font-display);color:#fff}',
      '.vf-hint{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 34px);display:flex;align-items:center;justify-content:center;gap:6px;font:600 13.5px var(--font-body);color:#C8EFFD;opacity:.85}',
      '.vf-hint svg{flex:none}',
      '.vf-ok{margin-top:36px;width:100%;max-width:340px;border:0;border-radius:99px;padding:17px 20px;background:#fff;color:#001E44;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 26px rgba(0,10,30,.35);display:flex;align-items:center;justify-content:center;gap:8px}',
      /* il prossimo viaggio */
      '.vf-pv{position:absolute;inset:0;overflow-y:auto;background:#001E44;color:#fff;display:flex;flex-direction:column;animation:vfFade .6s ease both}',
      '@keyframes vfFade{from{opacity:0}to{opacity:1}}',
      '.vf-hero{position:relative;flex:none;height:clamp(220px,46vh,430px);overflow:hidden}',
      '.vf-hero b{position:absolute;inset:0;background:#001E44 url("img/bg/montagne.jpg") center 70%/cover no-repeat;animation:vfZoom 2.4s cubic-bezier(.2,.7,.2,1) both}',
      '@keyframes vfZoom{from{transform:scale(1.08)}to{transform:none}}',
      '.vf-hero::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,30,68,.15) 0%,rgba(0,30,68,.35) 55%,#001E44 100%)}',
      '.vf-pv-ico{position:absolute;z-index:1;left:50%;bottom:6px;transform:translateX(-50%);width:84px;height:84px;border-radius:50%;padding:3px;box-sizing:border-box;background:linear-gradient(160deg,#E63946 0%,#0075E3 55%,#001E44 100%)}',
      '.vf-pv-ico span{width:100%;height:100%;border-radius:50%;background:#0B2C5C;display:flex;align-items:center;justify-content:center;font-size:40px;line-height:1}',
      '.vf-pv-in{flex:1;display:flex;flex-direction:column;align-items:center;text-align:center;padding:28px 28px calc(env(safe-area-inset-bottom,0px) + 28px);animation:vfSu .7s .15s cubic-bezier(.2,.8,.2,1) both}',
      '@keyframes vfSu{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}',
      '.vf-eti{display:block;margin:0 0 12px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
      '.vf-pv h2{margin:0;font:900 30px/1.2 var(--font-display);color:#fff}',
      '.vf-pv p{margin:24px auto 0;max-width:30ch;font:500 15.5px/1.55 var(--font-body);color:#C8EFFD}',
      '.vf-azioni{width:100%;max-width:360px;margin-top:auto;padding-top:32px;display:flex;flex-direction:column;align-items:center}',
      '.vf-cta{width:100%;border:0;border-radius:99px;padding:17px 20px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 28px rgba(0,117,227,.45)}',
      '.vf-link{margin-top:10px;border:0;background:none;color:#C8EFFD;font:700 14.5px var(--font-body);padding:12px;cursor:pointer}',
      '@media (max-height:700px){.vf-ico{width:108px;height:108px;margin-bottom:24px}.vf-ico span{font-size:50px}.vf-num{font-size:80px}.vf-frase{font-size:21px}.vf-sub{margin-top:18px}.vf-ok{margin-top:28px}.vf-hero{height:34vh}.vf-pv-in{padding-top:24px}}',
      '@media (prefers-reduced-motion:reduce){.vf-c.dx,.vf-c.sx,.vf-c.dx .vf-ico span,.vf-c.sx .vf-ico span,.vf-pv,.vf-pv-in,.vf-hero b{animation:none!important}.vf-bg{transition:none}}'
    ].join('');
    document.head.appendChild(s);
  }

  /* le storie, dai numeri veri del viaggio */
  function storie(F){
    const n = F.n || {}, sogno = sdSognoMaiuscolo(F.sogno);
    const ore = +n.ore || 0, oreS = oreTxt(ore), ses = +n.sessioni || 0;
    let dataInizio = ''; try{ dataInizio = sdData(n.inizio).replace(/ /g, ' '); }catch(_){ }
    const giorni = +n.giorni || 0, tappe = +n.tappe || 0, record = +n.record || 0, attivi = Math.min(+n.attivi || 0, giorni);
    return [
      { intro: true, ico: icona(), sogno: sogno, sub: 'Guarda quanta strada hai fatto per arrivarci.' },
      { ico: '🗓️', v: giorni, frase: pl(giorni, ['giorno è passato dal tuo primo passo.', 'giorni sono passati dal tuo primo passo.']), sub: dataInizio ? 'Il primo passo l’hai fatto il ' + dataInizio + '.' : 'Il primo passo l’hai fatto tu.' },
      { ico: '🗺️', v: tappe, frase: pl(tappe, ['tappa hai completato sulla tua Roadmap.', 'tappe hai completato sulla tua Roadmap.']), sub: 'Le hai fatte una alla volta, fino al traguardo.' },
      { ico: '⏱️', v: ore, ore: true, frase: (oreS === '1' ? 'ora' : 'ore') + ' di Full Focus hai dedicato al tuo sogno.', sub: ses > 0 ? 'Le hai divise in ' + (ses === 1 ? 'una sessione.' : ses + ' sessioni.') : 'Nel prossimo viaggio puoi provare il Full Focus.' },
      { ico: '🔥', v: record, frase: pl(record, ['giorno di fila hai tenuto accesa la serie.', 'giorni di fila hai tenuto accesa la serie.']), sub: 'È il tuo record in questo viaggio.' },
      { ico: '🧭', v: attivi, fine: true, frase: pl(attivi, ['giorno su ', 'giorni su ']) + giorni + ' hai fatto almeno una tappa.', sub: (giorni > 0 && attivi >= giorni) ? 'Non hai saltato neanche un giorno.' : 'Gli altri giorni la strada ti ha aspettato.' }
    ];
  }

  function attivo(){
    const F = SD.finale, s = SCHERMO();
    return !!(F && F === VF.F && F.passo === 1 && s && s.classList.contains('active'));
  }
  function ferma(){ if (VF.raf) cancelAnimationFrame(VF.raf); VF.raf = 0; }
  function barre(){
    const st = document.querySelectorAll('#vfSt .vf-barre i');
    st.forEach(function(b, k){ b.style.transform = 'scaleX(' + (k < VF.i ? 1 : k > VF.i ? 0 : Math.min(1, VF.el / DUR)) + ')'; });
  }
  function giro(ts){
    VF.raf = 0;
    if (!attivo()) return;
    if (!VF.last) VF.last = ts;
    if (!VF.pausa && !document.hidden) VF.el += Math.min(ts - VF.last, 100);
    VF.last = ts;
    barre();
    const L = storie(VF.F).length;
    if (VF.el >= DUR){
      if (VF.i < L - 1){ vai(VF.i + 1, 1); return; }
      VF.el = DUR; barre(); return;   /* l'ultima storia resta ferma sul pulsante */
    }
    VF.raf = requestAnimationFrame(giro);
  }
  function parti(){ ferma(); VF.last = 0; VF.raf = requestAnimationFrame(giro); }

  function conta(el, fino, ore){
    if (!el) return;
    const scrivi = function(v){ el.textContent = ore ? oreTxt(v) : String(Math.round(v)); };
    if (ridotto() || !(fino > 0)){ scrivi(fino || 0); return; }
    const t0 = performance.now(), d = 1100;
    const passo = function(t){
      if (!el.isConnected) return;
      const p = Math.min(1, (t - t0) / d), e = 1 - Math.pow(1 - p, 3);
      scrivi(p >= 1 ? fino : fino * e);
      if (p < 1) requestAnimationFrame(passo);
    };
    scrivi(0); requestAnimationFrame(passo);
  }

  function storiaHtml(S){
    const ico = '<div class="vf-ico" aria-hidden="true"><span>' + S.ico + '</span></div>';
    if (S.intro){
      return ico + '<p class="vf-pre">Ripercorri il tuo viaggio, dall’inizio.</p>'
        + (S.sogno ? '<h2 class="vf-sogno">"' + esc(S.sogno) + '"</h2>' : '<h2 class="vf-sogno">Il tuo sogno</h2>')
        + '<p class="vf-sub">' + S.sub + '</p>'
        + '<div class="vf-hint" aria-hidden="true">Tocca a destra per andare avanti<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></div>';
    }
    return ico + '<p class="vf-num" data-vf-num>0</p>'
      + '<p class="vf-frase">' + S.frase + '</p>'
      + '<p class="vf-sub">' + S.sub + '</p>'
      + (S.fine ? '<button type="button" class="vf-ok" data-cg-no onclick="sdFinaleAvanti()">Guarda cosa viene dopo<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>' : '');
  }

  function vai(i, dir){
    const L = storie(VF.F).length;
    i = Math.max(0, Math.min(L - 1, i));
    const cambia = i !== VF.i || dir === 0;
    VF.i = i; VF.el = 0; VF.F.storia = i;
    const c = document.getElementById('vfC'); if (!c) return;
    if (cambia){
      const S = storie(VF.F)[i];
      document.querySelectorAll('#vfSt .vf-bg').forEach(function(b, k){ b.classList.toggle('on', k === i); });
      c.className = 'vf-c'; void c.offsetWidth; c.className = 'vf-c ' + (dir < 0 ? 'sx' : 'dx');
      c.innerHTML = storiaHtml(S);
      if (!S.intro) conta(c.querySelector('[data-vf-num]'), S.v, S.ore);
      if (dir !== 0) vibra(8);
    }
    barre(); parti();
  }

  function costruisci(h){
    const L = storie(VF.F).length;
    let bg = '', bar = '';
    for (let k = 0; k < L; k++){ bg += '<div class="vf-bg vf-bg' + k + '"></div>'; bar += '<span><i></i></span>'; }
    h.innerHTML = '<div class="vf-st" id="vfSt">' + bg
      + '<div class="vf-barre" aria-hidden="true">' + bar + '</div>'
      + '<div class="vf-tap" id="vfTap"></div>'
      + '<div class="vf-c" id="vfC" aria-live="polite"></div>'
      + '<button type="button" class="vf-x" onclick="sdFinaleChiudi()" aria-label="Chiudi">' + X_SVG + '</button>'
      + '</div>';
    const st = document.getElementById('vfSt');
    /* tocco breve: a destra avanti, a sinistra indietro; tenuto premuto: pausa finche' non lasci */
    st.addEventListener('pointerdown', function(e){
      if (e.target.closest('button')) return;
      VF.giu = Date.now(); VF.pausa = true; VF.tenuto = true;
    });
    const su = function(e, annulla){
      if (!VF.tenuto) return;
      VF.tenuto = false; VF.pausa = false;
      if (annulla || Date.now() - VF.giu > 260) return;
      const r = st.getBoundingClientRect();
      if (e.clientX - r.left >= r.width / 2){
        if (VF.i < storie(VF.F).length - 1) vai(VF.i + 1, 1); else sdFinaleAvanti();
      } else if (VF.i > 0) vai(VF.i - 1, -1);
      else { VF.el = 0; barre(); parti(); }
    };
    st.addEventListener('pointerup', function(e){ su(e, false); });
    st.addEventListener('pointercancel', function(e){ su(e, true); });
    st.addEventListener('pointerleave', function(e){ if (VF.tenuto && e.pointerType === 'mouse') su(e, true); });
    st.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  }

  function storieDisegna(h){
    const F = SD.finale;
    if (VF.F !== F || !document.getElementById('vfSt')){
      VF.F = F; VF.i = -1; VF.pausa = false; VF.tenuto = false;
      costruisci(h);
      vai(F.storia || 0, 0);
    } else vai(F.storia || 0, 0);
  }

  function prossimoHtml(F){
    const sogno = sdSognoMaiuscolo(F.sogno);
    return '<div class="vf-pv">'
      + '<div class="vf-hero"><b aria-hidden="true"></b><div class="vf-pv-ico" aria-hidden="true"><span>' + icona() + '</span></div></div>'
      + '<div class="vf-pv-in">'
      +   '<small class="vf-eti">Il prossimo viaggio</small>'
      +   '<h2>Dove vuoi andare adesso?</h2>'
      +   '<p>Il viaggio verso ' + (sogno ? '"' + esc(sogno) + '"' : 'il tuo sogno') + ' resta tuo, con le tappe e le ore, nei sogni realizzati del Profilo.</p>'
      +   '<div class="vf-azioni">'
      +     '<button type="button" class="vf-cta" data-cg-no onclick="sdFinaleNuovo()">Scegli il prossimo sogno</button>'
      +     '<button type="button" class="vf-link" onclick="sdFinaleChiudi()">Resto qui ancora un po’</button>'
      +   '</div>'
      + '</div>'
      + '</div>'
      + '<button type="button" class="vf-x" onclick="sdFinaleChiudi()" aria-label="Chiudi">' + X_SVG + '</button>';
  }

  window.sdFinalePaint = function(){
    const F = SD.finale, h = document.getElementById('sdSg'), s = SCHERMO();
    if (!F || !h) return;
    css();
    if (F.passo === 1 || F.passo === 2){
      if (s) s.classList.add('vf-scuro');
      h.classList.add('vf-on');
      if (F.passo === 1){ storieDisegna(h); return; }
      ferma(); VF.F = null;
      h.innerHTML = prossimoHtml(F);
      return;
    }
    ferma(); VF.F = null;
    if (s) s.classList.remove('vf-scuro');
    h.classList.remove('vf-on');
    vfPaintArrivo();
  };
  window.sdFinaleAvanti = function(){
    const F = SD.finale; if (!F) return;
    if (F.passo === 0){ F.passo = 1; F.storia = 0; }
    else F.passo = 2;
    sdFinalePaint(); vibra(8);
  };
  const chiudiPrima = window.sdFinaleChiudi;
  window.sdFinaleChiudi = function(){
    ferma(); VF.F = null;
    if (typeof chiudiPrima === 'function') chiudiPrima();
    else { SD.finale = null; goId('s-home'); try{ switchTab('mappa'); }catch(_){ } }
  };
  /** Anteprima (console, o dal nodo del sogno per l'admin): sdFinaleAnteprima(1, 3) apre la quarta storia. Non scrive niente. */
  window.sdFinaleAnteprima = function(passo, storia){
    sdFinaleApri(true);
    if (passo){
      SD.finale.passo = Math.max(0, Math.min(2, +passo || 0));
      SD.finale.storia = Math.max(0, Math.min(5, +storia || 0));
      sdFinalePaint();
    }
  };
  /* da tastiera (PC): frecce avanti e indietro, Esc chiude */
  document.addEventListener('keydown', function(e){
    if (!attivo()) return;
    if (e.key === 'ArrowRight'){ e.preventDefault(); if (VF.i < storie(VF.F).length - 1) vai(VF.i + 1, 1); else sdFinaleAvanti(); }
    else if (e.key === 'ArrowLeft'){ e.preventDefault(); if (VF.i > 0) vai(VF.i - 1, -1); }
    else if (e.key === 'Escape'){ e.preventDefault(); sdFinaleChiudi(); }
  });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && attivo()) parti(); });
})();
