/* ===========================================================================================
   GLI AVVISI PER SALVARE LA SERIE (0.9.310, Andrea, screenshot 747 di Duolingo:
   "0 Congelazioni slancio! Il tempo stringe, Andrea", con il conto alla rovescia)

   Se la serie della mappa e' accesa e oggi manca ancora la tappa, alle 20, alle 22 e alle 23
   arriva un avviso con l'urgenza che sale e il conto alla rovescia vero fino a mezzanotte.
   Le sveglie e i testi stanno nel telefono (SerieAvvisi.java), cosi' partono anche ad app chiusa:
   questa pagina dice al telefono com'e' la serie adesso, ogni volta che puo' cambiare (all'avvio,
   a ogni tappa finita, quando l'app va in secondo piano, quando cambia l'interruttore).

   LA REGOLA DELLA SERIE e' quella di sdSerieMappa (sentiero-mappa.js): un giorno conta con una
   tappa della mappa; un giorno saltato lo copre una congelazione della serie. Al telefono va:
   - fatto: l'ultimo giorno vivo (con una tappa, o coperto da una congelazione);
   - serie: i giorni di fila (sdSerieMappa), gettoni: le congelazioni che restano;
   - muti: i prossimi giorni in cui si tace (date d'assenza, giorni liberi, Non disturbare
     sospeso fino a dopo le 23); fasce: le fasce del Non disturbare di DreamMap, se pianificate.
   Il silenzio del telefono (chiamata, Non disturbare, «Quando tacere») lo guarda il telefono.

   Prima c'erano due avvisi della serie (il Genio triste alle 18 e "Il Genio" alle 21:30 di
   sentiero.js): sono confluiti qui. L'interruttore e' nelle Impostazioni, sezione "La sera".
   =========================================================================================== */
const SVA_KEY = 'fl_serie_avvisi';          /* '0' = spenti dall'utente; di serie accesi */
function svaOn(){ try{ return localStorage.getItem(SVA_KEY) !== '0'; }catch(_){ return true; } }
/* 0.9.322, Andrea: i messaggi del Genio, come Lily e Duo su Duolingo */
const GM_KEY = 'fl_genio_messaggi';
function gmOn(){ try{ return localStorage.getItem(GM_KEY) !== '0'; }catch(_){ return true; } }
function gmToggle(){
  const on = !gmOn();
  try{ localStorage.setItem(GM_KEY, on ? '1' : '0'); }catch(_){ }
  svaPaint(); svaSync();
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
}
function svaK(t){ return (typeof sdK === 'function') ? sdK(t) : new Date(t).toISOString().slice(0, 10); }
function svaMin(s){ const p = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return p ? (+p[1]) * 60 + (+p[2]) : -1; }

/** Com'e' la serie adesso, nelle parole che il telefono capisce. */
function svaStato(){
  let g = {}; try{ g = sdGiorniFatti(); }catch(_){ }
  const base = new Date(); base.setHours(12, 0, 0, 0);
  let fatto = '';
  for (let i = 0; i < 400; i++){
    const k = svaK(base.getTime() - i * 86400000);
    /* oggi conta solo con una tappa vera; i giorni prima anche se coperti da una congelazione (-1) */
    if (g[k] > 0 || (i > 0 && g[k] === -1)){ fatto = k; break; }
  }
  let serie = 0; try{ serie = sdSerieMappa(); }catch(_){ }
  let gettoni = 0; try{ gettoni = snStato().serie.gettoni || 0; }catch(_){ }
  let nome = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = (u && u.name) ? String(u.name).trim().split(/\s+/)[0] : ''; }catch(_){ }
  /* i giorni in cui l'app tace del tutto: oggi e i due dopo (le sveglie coprono tre giorni) */
  const muti = [];
  let assenze = []; try{ assenze = (typeof asLista === 'function') ? asLista() : []; }catch(_){ }
  let nd = null; try{ nd = (typeof ndCfg === 'function') ? ndCfg() : null; }catch(_){ }
  for (let i = 0; i < 3; i++){
    const t = base.getTime() + i * 86400000, k = svaK(t), d = new Date(t);
    let muto = assenze.some(function(a){ return a && a.da <= k && k <= a.a; });
    if (nd && nd.liberi && nd.liberi[(d.getDay() + 6) % 7]) muto = true;
    if (nd && nd.fino){ const ultimo = new Date(t); ultimo.setHours(23, 0, 0, 0); if (nd.fino >= ultimo.getTime()) muto = true; }
    if (muto) muti.push(k);
  }
  const fasce = (nd && nd.pianifica ? (nd.fasce || []) : []).map(function(f){ return [svaMin(f.da), svaMin(f.a)]; }).filter(function(f){ return f[0] >= 0 && f[1] >= 0; });
  /* aperta: l'ultimo giorno in cui l'app si e' vista; serve ai messaggi del Genio (GenioAvvisi.java) */
  return { on: svaOn(), serie: serie, gettoni: gettoni, fatto: fatto, nome: nome, muti: muti, fasce: fasce, genio: gmOn(), aperta: svaK(Date.now()) };
}

let SVA_T = 0;
function svaSync(){
  clearTimeout(SVA_T);
  SVA_T = setTimeout(function(){
    try{
      if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.serieAvvisi) return;
      NATIVE.serieAvvisi(svaStato()).catch(function(){ });
    }catch(_){ }
  }, 250);
}
/** Per le prove sul telefono (console): mostra subito l'avviso del livello 0, 1 o 2 con i dati veri. */
function svaProva(livello){ try{ svaSync(); setTimeout(function(){ NATIVE.serieAvvisi({ prova: livello || 0 }); }, 600); }catch(_){ } }

/* ---------------------------------------------------------------- l'interruttore nelle Impostazioni */
function svaPaint(){
  const sw = document.getElementById('svaSw'); if (sw) sw.className = 'switch' + (svaOn() ? ' on' : '');
  const gm = document.getElementById('gmSw'); if (gm) gm.className = 'switch' + (gmOn() ? ' on' : '');
  const sub = document.getElementById('svaSub');
  if (sub) sub.textContent = svaOn()
    ? 'Se oggi manca ancora la tappa, alle 20, alle 22 e alle 23 arriva un avviso con il tempo che resta fino a mezzanotte.'
    : 'Spenti: la serie può spegnersi a mezzanotte senza che nessuno te lo ricordi.';
  if (typeof ntAvvisoPaint === 'function') ntAvvisoPaint();
}
async function svaToggle(){
  const on = !svaOn();
  try{ localStorage.setItem(SVA_KEY, on ? '1' : '0'); }catch(_){ }
  svaPaint();
  svaSync();
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  /* il permesso si chiede quando si accende la cosa che ne ha bisogno (notifiche.js) */
  if (on && typeof ntChiedi === 'function'){ try{ await ntChiedi(); }catch(_){ } svaPaint(); }
}

/* ---------------------------------------------------------------- quando dirlo al telefono */
setTimeout(svaSync, 5500);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') svaSync(); else setTimeout(svaSync, 1500); });
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-settings') setTimeout(svaPaint, 30); });
(function(){
  /* una tappa finita (la fine tappa) salva la serie di oggi: le sveglie di stasera si tolgono subito */
  if (typeof sdFineApri === 'function'){ const v = sdFineApri; window.sdFineApri = sdFineApri = function(){ const r = v.apply(this, arguments); svaSync(); return r; }; }
  /* una congelazione che copre un giorno saltato cambia l'ultimo giorno vivo */
  if (typeof sdCopriBuchi === 'function'){ const c = sdCopriBuchi; window.sdCopriBuchi = sdCopriBuchi = function(){ const r = c.apply(this, arguments); svaSync(); return r; }; }
})();
