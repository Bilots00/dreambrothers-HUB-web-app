/* ===========================================================================================
   RIENTRA IN ROTTA, PARLANDO (0.9.218, rifatto nella 0.9.221)

   0.9.218: la scena scura del Genio (s-genio), una domanda alla volta, «Lo scrivo io».
   0.9.221, Andrea: «che cosa ti ha fermato in questi giorni?» e' poco specifica. L'utente deve
   fare un esame di coscienza tirando a indovinare, quando l'app SA gia' cosa e' successo. E
   «Lo scrivo io» aveva un limite di 300 lettere. Adesso il Genio fa lo psicologo:
     1. VISTO: prima mostra cosa ha spostato la data (perche.js: il registro del navigatore e il
        tempo sulle app che distraggono). «Ieri avevi due ore per il sogno e ne hai fatte zero.
        Ieri hai passato tre ore su TikTok.»
     2. IL GRILLETTO: una domanda precisa su QUELLA causa («cosa ti ha portato dentro TikTok?»,
        «cosa e' successo quando hai interrotto la sessione?»), con le macro-risposte e
        «Lo scrivo io» senza limiti. Per le app, anche: cosa ti ha tenuto li'.
     3. IL BIVIO, come in Until Dawn: due futuri con la data vera di ognuno, simulata dal
        navigatore (ogni giorno come ieri, oppure ogni giorno come il piano), e le contromisure
        fra cui scegliere. Anche «per ora non cambio niente»: e' una scelta, con la sua data.
     4. IL PATTO «se… allora…» (le intenzioni di attuazione di Gollwitzer): «la prossima volta
        che ti viene voglia di aprire TikTok mentre lavori, cosa farai invece?»
     5. LA FINE: il patto scritto, UN pulsante. Con Premium il tuo agente personale ricalcola la roadmap con
        tutto quello che hai detto; senza, parte la contromisura scelta e si vede cosa
        cambierebbe il ricalcolo.
   Quello che si scrive a mano va al server (senza nome): il Genio impara, come Akinator.
   =========================================================================================== */
const RNG = { passo: '', storia: [], visto: null, app: [], futuri: null };
const RNG_PATTI_KEY = 'fl_patti';
/* il ripiego, quando l'app non ha visto una causa precisa */
const RNG_CAUSE = [
  { k: 'app', ico: '📱', t: 'Un’app mi ha preso' },
  { k: 'stanco', ico: '🪫', t: 'Mi mancava l’energia' },
  { k: 'idee', ico: '💡', t: 'Ho fatto altre cose' },
  { k: 'confuso', ico: '🧭', t: 'Non sapevo da dove partire' },
  { k: 'paura', ico: '😰', t: 'Avevo paura di sbagliare' },
  { k: 'imprevisto', ico: '🗓️', t: 'Un imprevisto vero' }
];
/* i grilletti, per ogni strada. [chiave, emoji, risposta] */
const RNG_GRILLETTI = {
  app: [['notifica', '🔔', 'Una notifica'], ['stanco', '🥱', 'Stanchezza o noia'], ['pausa', '☕', 'Volevo staccare cinque minuti'], ['evito', '😰', 'Non avevo voglia di cominciare il lavoro'], ['automatico', '🤖', 'L’ho aperta senza pensarci'], ['messaggio', '💬', 'Qualcuno mi ha mandato qualcosa']],
  mollata: [['difficile', '🧱', 'Era più difficile del previsto'], ['noia', '🥱', 'Mi annoiavo'], ['notifica', '🔔', 'Una notifica o una chiamata'], ['idea', '💡', 'Mi è venuta in mente un’altra cosa'], ['stanco', '🪫', 'Mi mancava l’energia']],
  rimandata: [['grande', '⛰️', 'È troppo grande'], ['come', '❔', 'Non so bene come si fa'], ['paura', '🎯', 'Ho paura che venga male'], ['urgente', '🕰️', 'Non è urgente'], ['voglia', '😑', 'Non mi va proprio']],
  vuoto: [['impegni', '💼', 'Lavoro o impegni che non potevo spostare'], ['stanco', '🪫', 'Mi mancava l’energia'], ['altro', '💡', 'Ho fatto altre cose'], ['confuso', '🧭', 'Non sapevo da dove partire'], ['paura', '😰', 'Avevo paura di sbagliare'], ['imprevisto', '🗓️', 'Un imprevisto vero']]
};
const RNG_TENUTO = [['scroll', '🔄', 'Un video tirava l’altro'], ['tempo', '⏰', 'Non mi accorgevo del tempo'], ['fuga', '🙈', 'Non volevo pensare al lavoro'], ['colpa', '😔', 'Mi sentivo in colpa, e continuavo']];
/* le contromisure: [chiave, emoji, testo, azione] */
function rngContromisure(){
  const r = RN.r, g = r.grilletto || '', app = r.appNome || 'quell’app';
  const l = [];
  if (r.strada === 'app'){
    l.push(['blocco', '🛡️', 'Blocco ' + app + ' nelle ore in cui lavoro']);
    if (g === 'notifica' || g === 'messaggio') l.push(['notifiche', '🔕', 'Spengo le notifiche di ' + app]);
    l.push(['stanza', '📵', 'Telefono in un’altra stanza quando lavoro']);
    if (g === 'evito' || r.tenuto === 'fuga') l.push(['cinque', '⏱️', 'Comincio con due minuti e miglioro strada facendo']);
  } else {
    const k = g || r.causa || '';
    if (['difficile', 'grande', 'confuso'].indexOf(k) >= 0) l.push(['pezzi', '✂️', 'Divido il lavoro in pezzi da quindici minuti']);
    if (k === 'come') l.push(['tutorial', '🎥', 'Venti minuti di tutorial, con gli appunti']);
    if (['paura', 'evito', 'voglia'].indexOf(k) >= 0) l.push(['cinque', '⏱️', 'Comincio con due minuti e miglioro strada facendo']);
    if (['stanco', 'noia'].indexOf(k) >= 0) l.push(['energia', '🌅', 'Sposto il sogno quando ho più energia']);
    if (['idea', 'altro', 'idee'].indexOf(k) >= 0) l.push(['caveau', '🔒', 'Metto da parte le idee nuove e resto sulla priorità']);
    if (k === 'notifica') l.push(['focus', '🔕', 'Lavoro solo in Full Focus, con il telefono chiuso']);
    if (k === 'impegni') l.push(['ore', '⚙️', 'Do al sogno meno ore, ma ore vere']);
    if (k === 'urgente') l.push(['scadenza', '📅', 'Mi do una scadenza vera per questa cosa']);
    if (k === 'imprevisto') l.push(['riparto', '🗓️', 'Domani riparto dalla stessa cosa']);
    if (l.length < 2) l.push(['cinque', '⏱️', 'Comincio con due minuti e miglioro strada facendo']);
  }
  l.push(['niente', '🤷', 'Per ora non cambio niente']);
  return l;
}
const RNG_ALLORA = [['respiro', '🌬️', 'Tre respiri lenti e torno al lavoro'], ['caveau', '🔒', 'Scrivo il pensiero nel caveau e torno'], ['acqua', '💧', 'Mi alzo e bevo un bicchiere d’acqua'], ['mappa', '🗺️', 'Guardo il prossimo passo nella Mappa'], ['focus', '⏱️', 'Faccio partire cinque minuti di Full Focus']];
/* 0.9.282, Andrea: il cambio alla James Clear. Prima il Genio chiede cosa ti fa stare bene in due minuti, poi lo usa
   come azione al posto dell'app; quando l'app e' bloccata, la schermata di blocco ti ricorda la tua promessa. */
const RNG_PREMI_KEY = 'fl_premi';
const RNG_SOST_KEY = 'fl_sostituzioni';
/* 0.9.283, Andrea: il cioccolato e' "il tuo preferito" (non a tutti piace fondente); via i "due passi", troppo vaghi.
   Le prime sei si vedono subito, le altre stanno dietro "Altre opzioni". Il rompicapo e il cruciverba aprono un
   enigma vero in DreamMap (rompicapo.js) dal pulsante della schermata di blocco. */
const RNG_PREMI = [
  ['cioccolato', '🍫', 'Un pezzetto del tuo cioccolato preferito', 'Mangio un pezzetto del mio cioccolato preferito'],
  ['flessioni', '💪', 'Flessioni, squat o jumping jack', 'Faccio un set veloce di flessioni o squat'],
  ['viso', '🧼', 'Acqua gelida sul viso', 'Mi sciacquo il viso con acqua gelida'],
  ['caffe', '☕', 'Un caffè, un ginseng o un matcha', 'Mi preparo e sorseggio un caffè, un ginseng o un matcha'],
  ['rompicapo', '🧩', 'Un rompicapo da risolvere', 'Risolvo un rompicapo'],
  ['respiro', '🧘', 'Una respirazione guidata', 'Faccio una respirazione guidata'],
  ['animale', '🐾', 'Coccole al tuo cane o gatto', 'Accarezzo il mio cane o il mio gatto'],
  ['aroma', '🌿', 'Un olio essenziale o un incenso', 'Annuso un olio essenziale o accendo un incenso'],
  ['salti', '🔋', 'Un minuto di salti sul posto', 'Faccio un minuto di salti sul posto'],
  ['frutta', '🥜', 'Una manciata di frutta secca', 'Sgranocchio una manciata di frutta secca'],
  ['acqua', '🍹', 'Acqua ghiacciata con limone e menta', 'Bevo un bicchiere d’acqua ghiacciata con limone e menta'],
  ['cruciverba', '📝', 'Un mini cruciverba', 'Risolvo un mini cruciverba'],
  ['diario', '✍️', 'Tre pensieri liberi sul diario', 'Scrivo tre pensieri liberi sul diario'],
  ['gratitudine', '🙏', 'Tre cose belle di oggi', 'Scrivo 3 cose belle delle ultime 24 ore'],
  ['vocale', '🎙️', 'Un vocale a una persona cara', 'Mando un vocale di 30 secondi a una persona cara'],
  ['abbraccio', '🤗', 'Un abbraccio di 20 secondi', 'Chiedo un abbraccio di almeno 20 secondi'],
  ['finestra', '🪟', 'Un minuto a guardare lontano', 'Guardo fuori dalla finestra il punto più lontano per un minuto'],
  ['pagina', '📚', 'Una pagina di un libro di carta', 'Leggo una pagina di un libro di carta'],
  ['ordine', '🧹', 'Due minuti di ordine sulla scrivania', 'Riordino la scrivania per due minuti'],
  ['complimento', '💬', 'Un complimento sincero', 'Faccio un complimento sincero a una persona cara'],
  /* 0.9.294, Andrea: "se sceglie una musica che gli piace, deve poter scegliere QUELLA canzone, e la schermata di blocco
     gli mostra il pulsante per farla partire al posto di Torna in rotta" */
  ['musica', '🎵', 'La canzone che ti fa stare bene', 'Ascolto la mia canzone preferita']
];
const RNG_PREMI_SUBITO = 6;
/* 0.9.284, Andrea: "mangio un quadratino di cioccolato fondente" compariva ancora: erano le ricompense salvate con la
   0.9.282. Si rileggono dall'elenco di adesso (testo e azione nuovi); quelle tolte (i "due passi", la canzone) spariscono,
   il tè passa al caffè e il frullato all'acqua fresca. Quelle scritte a mano restano com'erano. */
const RNG_PREMI_VECCHI = { te: 'caffe', frullato: 'acqua' };
function rngPremi(){
  let l = [];
  try{ l = JSON.parse(localStorage.getItem(RNG_PREMI_KEY) || '[]'); }catch(_){ l = []; }
  if (!Array.isArray(l)) return [];
  let cambiato = false; const visti = {};
  const out = [];
  l.forEach(function(o){
    if (!o) return;
    if (o.k === 'mio'){ out.push(o); return; }
    const k = RNG_PREMI_VECCHI[o.k] || o.k;
    const n = RNG_PREMI.filter(function(x){ return x[0] === k; })[0];
    if (!n){ cambiato = true; return; }
    if (visti[k]){ cambiato = true; return; }
    visti[k] = 1;
    const nuovo = { k: n[0], ico: n[1], t: n[2], az: n[3] };
    if (nuovo.k !== o.k || nuovo.t !== o.t || nuovo.az !== o.az || nuovo.ico !== o.ico) cambiato = true;
    out.push(nuovo);
  });
  if (cambiato){ try{ localStorage.setItem(RNG_PREMI_KEY, JSON.stringify(out)); }catch(_){ } }
  return out;
}
/* e la promessa gia' scritta sulla schermata di blocco: il cioccolato fondente diventa il tuo preferito */
(function(){
  try{
    const m = JSON.parse(localStorage.getItem('fl_sostituzioni') || '{}') || {};
    let cambiato = false;
    Object.keys(m).forEach(function(k){
      const v = String(m[k] || '');
      const nv = v.replace('Mangio un quadratino di cioccolato fondente', 'Mangio un pezzetto del mio cioccolato preferito')
        .replace('Mi preparo un tè o un caffè', 'Mi preparo e sorseggio un caffè, un ginseng o un matcha');
      if (nv !== v){ m[k] = nv; cambiato = true; }
    });
    if (cambiato){
      localStorage.setItem('fl_sostituzioni', JSON.stringify(m));
      setTimeout(function(){ try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ sostituzioni: JSON.stringify(m) }); }catch(_){ } }, 4000);
    }
  }catch(_){ }
})();
function rngPremiSalva(l){ try{ localStorage.setItem(RNG_PREMI_KEY, JSON.stringify(l.slice(0, 24))); }catch(_){ } }
function rngPremiCarte(){
  const sel = RNG.premiSel || {};
  const mie = rngPremi().filter(function(x){ return x.k === 'mio'; });
  const voci = RNG_PREMI.map(function(o){ return { k: o[0], ico: o[1], t: o[2], az: o[3] }; }).concat(mie);
  RNG.premiVoci = voci;
  /* le altre si aprono con "Altre opzioni"; una gia' scelta fra le altre le tiene aperte */
  const aperte = RNG.premiTutte || voci.some(function(o, i){ return i >= RNG_PREMI_SUBITO && sel[o.k + ':' + o.t]; });
  const viste = aperte ? voci : voci.slice(0, RNG_PREMI_SUBITO);
  return '<div class="gn-carta"><div class="gn-cards' + (viste.length % 2 ? ' dispari' : '') + '">' + viste.map(function(o, i){
    return '<button type="button" class="gn-card' + (sel[o.k + ':' + o.t] ? ' on' : '') + '" onclick="event.stopPropagation();rngPremio(' + i + ')"><span>' + o.ico + '</span><b>' + gnEsc(o.t) + '</b></button>';
  }).join('') + '</div></div>'
    + (aperte ? '' : '<button type="button" class="gn-link rng-altre" onclick="event.stopPropagation();RNG.premiTutte=true;document.getElementById(\'gnRisp\').innerHTML=rngPremiCarte()">Altre opzioni <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>')
    + '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rngScrivo(\'premi\')">✍️ Lo scrivo io</button>'
    + '<div class="or-grid one"><button type="button" class="or-a main" id="rngPremiOk"' + (Object.keys(sel).some(function(k){ return sel[k]; }) ? '' : ' disabled') + ' onclick="event.stopPropagation();rngPremiOk()">Confermo</button></div>';
}
function rngPremio(i){
  const o = (RNG.premiVoci || [])[i]; if (!o) return;
  RNG.premiSel = RNG.premiSel || {};
  const k = o.k + ':' + o.t; RNG.premiSel[k] = !RNG.premiSel[k];
  try{ gnAu.scelta(i); flVibra(10); }catch(_){ }
  const r = document.getElementById('gnRisp'); if (r) r.innerHTML = rngPremiCarte();
}
function rngPremiOk(){
  const sel = RNG.premiSel || {};
  const scelti = (RNG.premiVoci || []).filter(function(o){ return sel[o.k + ':' + o.t]; });
  if (!scelti.length) return;
  rngPremiSalva(scelti);
  RNG.premiTutte = false;
  /* il rompicapo si prepara subito: quando servira' sulla schermata di blocco si apre senza attese */
  scelti.forEach(function(o){ if ((o.k === 'rompicapo' || o.k === 'cruciverba') && typeof rcpPrepara === 'function') rcpPrepara(o.k === 'cruciverba' ? 'cruciverba' : 'enigma'); });
  rngVai('patto');
}
/* 0.9.287, Andrea: "mostra solo quattro opzioni": qui ci sono TUTTE le cose che hai scelto fra quelle che ti fanno stare
   bene; se sono meno di quattro, si aggiungono le altre proposte. */
function rngAlloraVoci(){
  const premi = rngPremi().map(function(o){ return [o.k === 'rompicapo' || o.k === 'cruciverba' || o.k === 'musica' ? o.k : 'premio', o.ico, o.az || o.t]; });
  const altri = RNG_ALLORA.filter(function(o){ return o[0] !== 'focus'; });
  return premi.concat(altri).slice(0, Math.max(4, premi.length));
}
const RNG_ALLORA_SUBITO = 4;
function rngAlloraCarte(){
  const voci = RNG.alloraVoci || [];
  const tutte = RNG.alloraTutte || voci.length <= RNG_ALLORA_SUBITO + 1;
  const viste = tutte ? voci : voci.slice(0, RNG_ALLORA_SUBITO);
  /* 0.9.295, Andrea: "Mostra altro e Cambia dentro al pannello bianco, minimal; Lo scrivo io da solo, fuori; e
     un'opzione a sorpresa: una ruota da girare sulla schermata di blocco, fra le cose che hai scelto". */
  const ruota = voci.filter(function(v){ return v[0] === 'premio' || v[0] === 'rompicapo' || v[0] === 'cruciverba'; }).length >= 2;
  const carte = viste.map(function(o){ return o; });
  const idx = function(o){ return voci.indexOf(o); };
  const MATITA = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';
  return '<div class="gn-carta"><div class="gn-cards' + ((carte.length + (ruota ? 1 : 0)) % 2 ? ' dispari' : '') + '">'
    + (ruota ? '<button type="button" class="gn-card rng-ruota" onclick="event.stopPropagation();rngAlloraRuota()"><span>🎡</span><b>A sorpresa: gira la ruota</b></button>' : '')
    + carte.map(function(o){ return '<button type="button" class="gn-card" onclick="event.stopPropagation();rngAllora(' + idx(o) + ')"><span>' + o[1] + '</span><b>' + gnEsc(o[2]) + '</b></button>'; }).join('')
    + '</div><div class="rng-pied">'
    + (tutte ? '' : '<button type="button" class="rng-pbtn" onclick="event.stopPropagation();RNG.alloraTutte=true;document.getElementById(\'gnRisp\').innerHTML=rngAlloraCarte()">Mostra altro (' + (voci.length - RNG_ALLORA_SUBITO) + ')</button>')
    + '<button type="button" class="rng-pbtn" onclick="event.stopPropagation();RNG.premiSel=null;RNG.alloraTutte=false;rngVai(\'premi\')">' + MATITA + ' Cambia</button></div></div>'
    + '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rngScrivo(\'allora\')">Lo scrivo io</button>';
}
function rngAlloraRuota(){
  try{ gnAu.scelta(1); flVibra(14); }catch(_){ }
  const opz = (RNG.alloraVoci || []).filter(function(v){ return v[0] === 'premio' || v[0] === 'rompicapo' || v[0] === 'cruciverba'; }).map(function(v){ return v[2]; });
  RN.r.allora = 'ruota'; RN.r.ruota = opz.slice(0, 12); RN.r.alloraTesto = 'Giro la ruota e faccio quello che esce';
  rngVai('fine');
}
function rngAlloraCarteVecchie(){
  const voci = RNG.alloraVoci || [];
  const tutte = RNG.alloraTutte || voci.length <= RNG_ALLORA_SUBITO + 1;
  const viste = tutte ? voci : voci.slice(0, RNG_ALLORA_SUBITO);
  return rngCarte(viste, 'rngAllora', '')
    + (tutte ? '' : '<button type="button" class="gn-link rng-altre" onclick="event.stopPropagation();RNG.alloraTutte=true;document.getElementById(\'gnRisp\').innerHTML=rngAlloraCarte()">Mostra altro (' + (voci.length - RNG_ALLORA_SUBITO) + ') <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>')
    + '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rngScrivo(\'allora\')">✍️ Lo scrivo io</button>'
    + '<button type="button" class="gn-link" onclick="event.stopPropagation();RNG.premiSel=null;RNG.alloraTutte=false;rngVai(\'premi\')">Cambia le cose che ti fanno stare bene</button>';
}
/** Le ore scritte a mano ("dalle 21 alle 23", "verso le 22:30"): la fascia per il blocco. */
function rngOreDaTesto(t){
  const m = String(t || '').match(/(\d{1,2})(?:[:.](\d{2}))?/g);
  if (!m || !m.length) return null;
  const hh = function(x){ const p = x.split(/[:.]/); const h = Math.min(23, +p[0]); return String(h).padStart(2, '0') + ':' + (p[1] || '00'); };
  const a = hh(m[0]);
  const b = m[1] ? hh(m[1]) : String(Math.min(23, +m[0].split(/[:.]/)[0] + 2)).padStart(2, '0') + ':00';
  return ['scritto', '✍️', 'Quando l’hai scritto tu', a, b];
}
const RNG_ORE = [['mattina', '🌅', 'La mattina', '07:00', '12:00'], ['pomeriggio', '☀️', 'Il pomeriggio', '12:00', '18:00'], ['sera', '🌆', 'La sera', '18:00', '22:30'], ['notte', '🌙', 'La notte', '22:30', '02:00']];

/* ---------- la porta ---------- */
function rnApri(v){
  RN.v = v || null; RN.i = 0; RN.r = {}; RN.rimedio = null; RN.app = [];
  rngImparateCarica();
  if (typeof GN === 'undefined' || typeof gnVai !== 'function'){ goId('s-rientro'); rnPaint(); return; }
  GN.on = true; GN.modo = 'rn'; GN.audio = true; GN.storia = [];
  RNG.storia = []; RNG.visto = (typeof prcRiepilogo === 'function') ? prcRiepilogo() : null; RNG.app = []; RNG.futuri = null;
  /* il tempo sulle app arriva dal telefono: si aspetta un attimo prima di parlare */
  RNG.attesa = (typeof prcApp === 'function') ? prcApp().then(function(a){ RNG.app = a || []; }).catch(function(){ }) : Promise.resolve();
  /* 0.9.295, Andrea: "come prima cosa si chiede se c'e' stato un imprevisto, se sei caduto in una tentazione, o se non
     hai niente da segnalare: l'imprevisto lo chiedevamo per ultimo" */
  RNG.passo = (v && v.tipo === 'chiamata') ? 'chiamata' : 'prima';
  /* 0.9.301: prima la rivelazione di dove e' andato il tempo oggi; con Premium la domanda di consapevolezza e poi la
     chat con il tuo agente personale (conversa.js), che prende il posto delle domande del modello veloce della 0.9.296 */
  const chat = RNG.passo === 'prima' && typeof cvInizio === 'function';
  if (chat) RNG.passo = cvInizio('rn');
  RNG_AI.spento = false; RNG_AI.on = RNG.passo === 'prima' && rngAiOk() && !(typeof cvPremium === 'function' && cvPremium());
  if (RNG_AI.on) rngAiReset();
  RNG.barraP = 0;
  goId('s-genio');
  rngBarra();
  GN.step = ''; gnVai('rn');
}
function rngBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  /* 0.9.295, Andrea: "la barra a volte va avanti, a volte torna indietro". Tre passi (le cose che ti fanno stare bene,
     la canzone, la chiamata) non avevano una posizione e ripartivano dal 30%; "Lo scrivo io" stava al 50% anche alla
     fine. Ogni passo ha la sua posizione, "Lo scrivo io" resta dove era la domanda, e andando avanti la barra non scende. */
  const POS = { cvDomanda: 0.04, cvCosa: 0.045, cvScrivo: 0.05, cvScopri: 0.06, cvRivela: 0.08, cvFuturo: 0.1, cvChat: 0.3, prima: 0.12, chiamata: 0.1, visto: 0.14, nulla: 1, scelta: 1, causa: 0.22, grilletto: 0.3, tenuto: 0.38, costo: 0.48, bivio: 0.56, ora: 0.62, tecnica: 0.68, premi: 0.74, patto: 0.82, canzone: 0.9, fine: 1 };
  let p = RNG.passo === 'ai' ? rngAiPos() : POS[RNG.passo];
  if (p == null) p = RNG.barraP || 0.3;
  if (!RNG.indietro && RNG.barraP && p < RNG.barraP) p = RNG.barraP;
  RNG.barraP = p; RNG.indietro = false;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(p * 100) + '%';
  if (txt) txt.textContent = 'Rientra in rotta';
}
function rngVai(p){ RNG.storia.push(RNG.passo); RNG.passo = p; rngBarra(); GN.step = ''; gnVai('rn'); }
function rngIndietro(){
  if (RNG.passo === 'fine' || !RNG.storia.length){ rngChiudi(); return true; }
  if (RNG.passo === 'ai'){ RNG_AI.pila.pop(); RNG_AI.storia.pop(); }
  RNG.passo = RNG.storia.pop(); RNG.indietro = true; RNG.barraP = 0; rngBarra(); GN.step = ''; gnVai('rn'); return true;
}
function rngRipensa(){ if (!RNG.storia.length) return; if (RNG.passo === 'ai'){ RNG_AI.pila.pop(); RNG_AI.storia.pop(); } RNG.passo = RNG.storia.pop(); RNG.indietro = true; RNG.barraP = 0; rngBarra(); GN.step = ''; gnVai('rn'); }
function rngChiudi(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}
/* esce dalla scena del Genio senza ridisegnare la Dream: il rimedio porta dove serve */
function rngChiudiSoft(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
}
function rngCarte(voci, fn, scrivo){
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();' + fn + '(' + i + ')"><span>' + o[1] + '</span><b>' + gnEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>'
    + (scrivo ? '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rngScrivo(\'' + scrivo + '\')">✍️ Lo scrivo io</button>' : '');
}

/* 0.9.303: lo spostamento dell'arrivo detto com'e' ("13 ore", "1 giorno e 4 ore"), non arrotondato al giorno */
function rngTempo(ms){ return (typeof etaTempoParole === 'function') ? etaTempoParole(ms) : prcGiorni(ms); }
/* ---------- cosa ha visto l'app: la strada ---------- */
function rngStrada(){
  const v = RNG.visto, app = RNG.app || [];
  const pc = v && v.primaCausa;
  const tipi = v ? v.voci.map(function(x){ return x.tipo; }) : [];
  const giornata = v ? v.voci.filter(function(x){ return x.tipo === 'giornata' || x.tipo === 'giornate'; })[0] : null;
  const vuota = giornata && giornata.v.vars && giornata.v.vars.fatteOre < giornata.v.vars.pianOre * 0.6;
  if (app[0] && app[0].min >= 45 && (vuota || !giornata)) return 'app';
  if (tipi.indexOf('mollata') >= 0) return 'mollata';
  if (tipi.indexOf('rimandata') >= 0) return 'rimandata';
  if (vuota) return 'vuoto';
  /* la data si e' spostata per una scelta: un sogno riletto, meno ore */
  if (pc && (pc.tipo === 'genio' || pc.tipo === 'piano' || pc.tipo === 'roadmap')) return 'scelta';
  return '';
}
function rngVistoHtml(){
  const v = RNG.visto, righe = [];
  if (v && v.voci) v.voci.filter(function(x){ return x.delta > 0 || ['giornata', 'giornate', 'mollata', 'rimandata'].indexOf(x.tipo) >= 0; }).slice(0, 3).forEach(function(x){
    /* 0.9.303: lo scarto com'e' (ore se sono ore): arrotondato al giorno, 13 ore diventavano "+1 giorno" */
    righe.push('<div class="rng-v"><span>' + x.ico + '</span><p>' + gnEsc(x.t) + '</p>' + (x.delta >= 60000 ? '<i>+' + rngTempo(x.delta) + '</i>' : '') + '</div>');
  });
  const af = (typeof prcAppFrase === 'function' && v) ? prcAppFrase(v, RNG.app) : '';
  if (af) righe.push('<div class="rng-v"><span>📱</span><p>' + gnEsc(af) + '</p></div>');
  return righe.join('');
}

/* ---------- i passi ---------- */
function rngEntra(){
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo', 'rng-isola'); }
  if (typeof cvEntra === 'function' && cvEntra('rn')) return;
  const p = RNG.passo, r = RN.r;
  if (p === 'ai'){ rngAiEntra(); return; }
  if (p === 'prima'){
    gnDomanda('pensa', 'Partiamo da qui: *da ieri, cosa è successo* con il tuo sogno?',
      rngCarte(RNG_PRIMA, 'rngPrima', ''));
    /* con l'agente, la domanda dopo ognuna delle tre risposte si chiede subito */
    if (RNG_AI.on) RNG_PRIMA.forEach(function(o){ rngAiChiedi(RNG_AI_DOMANDA0, o[2]).catch(function(){ }); });
    return;
  }
  if (p === 'nulla'){
    gnDomanda('rivela', 'Non vedo niente fuori rotta: *continua così*. Il tempo sul telefono e le ore per il sogno sono in linea con il piano.',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rnScelto();rngChiudi()">Torno al sogno</button></div>');
    return;
  }
  if (p === 'costo'){
    /* 0.9.295, Andrea: "il costo di restare come sei deve far male, e la scena del bivio va isolata: una cosa alla volta".
       Prima solo le due strade e quanto costa la prima; poi, in un passo a parte, la scelta. */
    const f = rngFuturi();
    if (!f){ RNG.passo = 'bivio'; rngBarra(); GN.step = ''; gnVai('rn'); return; }
    const sc0 = document.getElementById('gnScena'); if (sc0) sc0.classList.add('rng-isola');
    /* 0.9.297, Andrea: "Voglio cambiare strada e Guarda il futuro se non cambi portano tutti e due a cambiare: o cambi o
       cambi. L'utente deve sentirsi libero e arrivarci da solo". E "quando c'e' una decisione lo sfondo si oscura, niente
       stelle e foresta: la schermata del bivio, come l'effetto farfalla". La scelta e' la stessa scena delle pillole:
       a sinistra resto come oggi (e vedo il futuro se non cambio), a destra cambio strada. Sotto resta il passo, con un
       pulsante per riaprirla. */
    gnDomanda('triste', (f.anniTxt ? 'Se ogni giorno va come ieri, il sogno arriva *' + f.anniTxt + ' più tardi*.' : 'Se ogni giorno va come ieri, *ogni giorno sposta l’arrivo di un giorno*.'),
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rngCostoScelta()">Scegli la tua strada</button></div>');
    setTimeout(rngCostoScelta, 600);
    return;
  }
  if (p === 'tecnica'){
    /* 0.9.295, Andrea: "prima di chiedere quale abitudine metti al posto della tentazione, spiega la tecnica: altrimenti non
       si capisce di cosa parli". La lezione in breve: la voglia si sostituisce, non si toglie. */
    gnDomanda('rivela', 'Una tentazione non si toglie e basta: *si sostituisce*. Il cervello cerca la sua piccola dose di piacere. Se al posto di ' + gnEsc(r.appNome || 'quell’app') + ' gliene dai una sana, non ne sente la mancanza.',
      '<div class="rng-lez"><b>La sostituzione dell’abitudine</b><p>Quando arriva la voglia, fai una cosa che ti fa stare bene e dura due minuti. La schermata di blocco te la ricorderà.</p></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rngVai(\'premi\')">Scegliamo cosa mi fa stare bene</button></div>');
    return;
  }
  if (p === 'visto'){
    try{ gnPosa('pensa'); const el = document.getElementById('gnTesto'); if (el) el.textContent = '…'; const rr = document.getElementById('gnRisp'); if (rr) rr.innerHTML = ''; }catch(_){ }
    const t0 = Date.now();
    Promise.race([RNG.attesa, new Promise(function(ok){ setTimeout(ok, 2500); })]).then(function(){
      setTimeout(function(){
        if (RNG.passo !== 'visto' || !GN.on || GN.modo !== 'rn') return;
        const corpo = rngVistoHtml();
        RN.r.strada = rngStrada();
        if (!corpo){ RNG.passo = 'causa'; GN.step = ''; gnVai('rn'); return; }
        const delta = RNG.visto && RNG.visto.delta > 0 ? RNG.visto.delta : (RN.v && RN.v.delta > 0 ? RN.v.delta : 0);
        gnDomanda('pensa', (delta ? 'Da ieri il tuo arrivo si è spostato in avanti di *' + rngTempo(delta) + '*. Ecco cosa ho visto.' : 'Ecco cosa ho visto da ieri.'),
          '<div class="rng-visto">' + corpo + '</div><div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rngDopoVisto()">Continua</button></div>');
      }, Math.max(0, 900 - (Date.now() - t0)));
    });
    return;
  }
  /* 0.9.235: dopo un "Non ora" alla chiamata dei sogni il Genio chiede subito cosa e' successo */
  if (p === 'chiamata'){
    RNG.voci = RNG_CHIAMATA.map(function(c){ return [c[0], c[1], c[2]]; });
    const t = RN.v && RN.v.titolo ? ' per *' + gnEsc(RN.v.titolo) + '*' : '';
    gnDomanda('pensa', 'Hai detto "Non ora" alla chiamata dei sogni' + t + '. Nessun processo: *cosa ti ha impedito di rispondere*?',
      rngCarte(RNG.voci, 'rngChiamata', 'causa'));
    return;
  }
  if (p === 'scelta'){
    gnDomanda('pensa', 'La data si è spostata per una *scelta tua*: hai cambiato il sogno, il tempo che gli dai o i passi del percorso. Non è un passo falso.',
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rnScelto();rngChiudi()">Va bene così</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();RN.r.strada=\'vuoto\';rngVai(\'grilletto\')">Voglio parlarne lo stesso</button>');
    return;
  }
  if (p === 'causa'){
    const imparate = (RNG.imparate || []).slice(0, 2);
    RNG.voci = RNG_CAUSE.map(function(c){ return [c.k, c.ico, c.t]; }).concat(imparate.map(function(x){ return ['imp:' + x.causa, '💬', x.testo]; }));
    const g = (RN.v && RN.v.delta > 0) ? rngTempo(RN.v.delta) : '';
    gnDomanda('pensa', (g ? 'Il tuo arrivo si è spostato di ' + g + ' da ieri, ma non ho visto una causa precisa. ' : 'Non ho visto una causa precisa. ') + 'In questi giorni, *cosa ti ha tenuto lontano dal sogno*?',
      rngCarte(RNG.voci, 'rngCausa', 'causa'));
    return;
  }
  if (p === 'grilletto'){
    const s = r.strada || 'vuoto';
    RNG.opz = RNG_GRILLETTI[s] || RNG_GRILLETTI.vuoto;
    const t = rngVoceTesto(s);
    const q = {
      app: 'Ieri, la prima volta che hai aperto ' + (r.appNome || 'quell’app') + ', *cosa ti ci ha portato*?',
      mollata: 'Quando hai interrotto la sessione' + (t ? ' su "' + t + '"' : '') + ', *cosa è successo* un attimo prima?',
      rimandata: 'Cosa ti fa *rimandare "' + (t || 'questa cosa') + '"* ogni volta?',
      vuoto: 'Ieri le ore per il sogno sono scivolate via. *Dove sono finite*?'
    }[s] || 'Da ieri, *cosa ti ha tenuto lontano dal sogno*?';
    gnDomanda('pensa', q, rngCarte(RNG.opz, 'rngGrilletto', 'grilletto'));
    return;
  }
  if (p === 'tenuto'){
    gnDomanda('pensa', 'E una volta dentro ' + (r.appNome || 'l’app') + ', *cosa ti ha tenuto lì* così a lungo?', rngCarte(RNG_TENUTO, 'rngTenuto', 'tenuto'));
    return;
  }
  if (p === 'bivio'){
    RNG.cm = rngContromisure();
    const f = rngFuturi();
    /* 0.9.288, Andrea: "il pannello rosso e quello verde non mi fanno impazzire". Le due date diventano un bivio
       disegnato (bivio.js): a sinistra la strada di ieri, nella nebbia; a destra quella del piano, nella luce. La
       scelta qui sotto fa muovere la luce sulla strada che prendi. */
    const due = f ? (typeof bivSvg === 'function'
      ? '<div class="rng-biv">' + bivSvg({ sx: { t: 'Se ogni giorno va come ieri', s: f.ieriTxt }, dx: { t: 'Se fai le ore del piano', s: f.pattoTxt }, scuro: 'sx', compatto: true }) + '</div>'
      : '<div class="rng-futuri"><div class="rng-f giu"><small>Se ogni giorno va come ieri</small><b>' + gnEsc(f.ieriTxt) + '</b></div><div class="rng-f su"><small>Se fai le ore del piano</small><b>' + gnEsc(f.pattoTxt) + '</b></div></div>') : '';
    setTimeout(function(){ try{ bivPronto(document.querySelector('.rng-biv')); }catch(_){ } }, 0);
    gnDomanda('pensa', 'Bene. *Cosa cambi da domani* per prendere la strada del piano?',
      rngCarte(RNG.cm, 'rngBivio', 'bivio'));
    return;
  }
  if (p === 'ora'){
    gnDomanda('pensa', r.contromisura === 'energia' ? 'Di solito, *in che momento della giornata* hai più energia?' : 'Di solito, *a che ora* ti prende ' + (r.appNome || 'quell’app') + '?', rngCarte(RNG_ORE, 'rngOra', 'ora'));
    return;
  }
  if (p === 'patto' && !rngPremi().length){ RNG.passo = 'premi'; rngBarra(); }
  if (RNG.passo === 'premi'){
    if (!RNG.premiSel){ RNG.premiSel = {}; rngPremi().forEach(function(o){ RNG.premiSel[o.k + ':' + o.t] = true; }); }
    gnDomanda('pensa', 'Prima una cosa su di te: *cosa ti fa stare bene* in due minuti? Scegli tutte quelle che ti piacciono: ' + (r.strada === 'app' && r.appNome ? 'le userò al posto di ' + r.appNome + '.' : 'le userò per farti ripartire.'), rngPremiCarte());
    return;
  }
  if (p === 'patto'){
    /* 0.9.290, Andrea: "la domanda e' posta male: deve dire, se cadrai in tentazione, quale abitudine metti al suo posto;
       e non mostra tutte le opzioni che ho scelto (ne avevo messe 10 o 11). Al massimo 4 o 5 a vista, le altre dietro
       Mostra altro". Ci sono TUTTE le cose scelte; le prime quattro si vedono, le altre si aprono. */
    RNG.alloraVoci = rngAlloraVoci();
    gnDomanda('pensa', 'Ultima cosa, la più importante. Quando ti viene voglia di aprire ' + gnEsc(r.appNome || 'quell’app') + ', *quale di queste fai al suo posto*?', rngAlloraCarte());
    return;
  }
  if (p === 'canzone'){
    let prima = ''; try{ const c = JSON.parse(localStorage.getItem('fl_canzone') || 'null'); if (c) prima = c.titolo || c.url || ''; }catch(_){ }
    /* 0.9.295, Andrea: "oltre al link, poter scegliere un file mp3 che ho sul telefono" */
    gnDomanda('pensa', 'Quale *canzone* ti fa stare bene? Scegli il file dal telefono, oppure scrivi il titolo o incolla il link.',
      '<label class="or-a main rng-file" onclick="event.stopPropagation()">🎵 Scegli il file dal telefono<input type="file" accept="audio/*" id="rngCanzoneFile" hidden onchange="rngCanzoneFile(this)"></label>'
      + '<input class="gn-campo" id="rngCanzone" placeholder="Titolo o link" value="' + String(prima).replace(/"/g, '&quot;') + '" onclick="event.stopPropagation()">'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();rngCanzoneOk()">Confermo</button></div>',
      function(){ const a = document.getElementById('rngCanzone'); if (a) a.focus(); });
    return;
  }
  if (p === 'scrivo'){
    const per = RNG.scrivoPer;
    const dom = { causa: 'Dimmelo *con parole tue*: cosa ti ha tenuto lontano dal sogno?', grilletto: 'Raccontamelo *con parole tue*: cosa è successo un attimo prima?', tenuto: 'Dimmelo *con parole tue*: cosa ti ha tenuto lì?', bivio: 'Scrivi *la tua contromisura*: cosa cambi da domani?', allora: 'Scrivi *cosa farai al suo posto*, la prossima volta.', premi: 'Scrivi *una cosa che ti fa stare bene* in due minuti.', ora: 'Scrivilo *con parole tue*: quando ti prende ' + (r.appNome || 'quell’app') + '? Va bene anche "dipende": dimmi da cosa.', ai: 'Raccontamelo *con parole tue*: ' + String((r.ai && r.ai.testo) || '').replace(/\*/g, '') }[per] || 'Dimmelo *con parole tue*.';
    gnDomanda('pensa', dom, (typeof micArea === 'function' ? micArea('rngTesto', 4, 'Scrivi qui o tocca il microfono…') : '<textarea class="gn-area" id="rngTesto" rows="4" placeholder="Scrivi qui…" onclick="event.stopPropagation()"></textarea>')
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();rngScrivoOk()">Confermo</button></div>',
      function(){ const a = document.getElementById('rngTesto'); if (a) a.focus(); });
    return;
  }
  if (p === 'fine'){ rngFine(); return; }
}
const RNG_PRIMA = [['imprevisto', '🌧️', 'Ho avuto un imprevisto'], ['tentazione', '📱', 'Sono caduto in una tentazione'], ['niente', '✅', 'Niente da segnalare']];
function rngPrima(i){
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  const o = RNG_PRIMA[i]; if (!o) return;
  RN.r.prima = o[0];
  if (RNG_AI.on && !RNG_AI.spento){ rngAiAvanza(RNG_AI_DOMANDA0, o[2]); return; }
  rngPrimaVai(o[0]);
}
function rngPrimaVai(k){
  RN.r.prima = k;
  if (k === 'imprevisto'){ RN.r.causa = 'imprevisto'; RN.r.strada = 'vuoto'; RN.r.grilletto = 'imprevisto'; rngVai('costo'); return; }
  rngVai('visto');
}
function rngVoceTesto(tipo){
  const v = RNG.visto; if (!v) return '';
  const x = v.voci.filter(function(y){ return y.tipo === tipo; })[0];
  return x && x.v ? String(x.v.testo || '') : '';
}
function rngDopoVisto(){
  const s = RN.r.strada;
  if (RN.r.prima === 'niente' && !s){ rngVai('nulla'); return; }
  if (s === 'app'){ const a = RNG.app[0]; RN.r.app = a.pkg; RN.r.appNome = a.nome; RN.r.appMin = a.min; RN.r.causa = 'app'; rngVai('grilletto'); return; }
  if (s === 'scelta'){ rngVai('scelta'); return; }
  if (s){ RN.r.causa = s; rngVai('grilletto'); return; }
  rngVai('causa');
}
const RNG_CHIAMATA = [
  ['luogo', '📍', 'Ero in un posto dove non potevo'],
  ['occupato', '⏳', 'Stavo facendo un’altra cosa importante'],
  ['voglia', '🥱', 'Non avevo voglia di cominciare'],
  ['sorpresa', '😮', 'Mi ha preso alla sprovvista'],
  ['app', '📱', 'Ero su un’app che mi aveva preso']
];
function rngChiamata(i){
  const c = RNG_CHIAMATA[i]; if (!c) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  RN.r.causa = 'chiamata-' + c[0]; RN.r.testo = c[2];
  if (c[0] === 'app'){ RN.r.strada = 'app'; const a = RNG.app[0]; if (a){ RN.r.app = a.pkg; RN.r.appNome = a.nome; } rngVai('grilletto'); return; }
  if (c[0] === 'voglia'){ RN.r.strada = 'rimandata'; rngVai('grilletto'); return; }
  RN.r.strada = 'vuoto'; RN.r.grilletto = 'imprevisto'; rngVai('costo');
}
function rngCausa(i){
  const v = (RNG.voci || [])[i];
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  if (v && String(v[0]).indexOf('imp:') === 0){ RN.r.causa = v[0].slice(4); RN.r.grilletto = v[0].slice(4); RN.r.testo = v[2]; RN.r.strada = 'vuoto'; rngVai('costo'); return; }
  const c = RNG_CAUSE[i]; RN.r.causa = c.k;
  if (c.k === 'app'){ RN.r.strada = 'app'; const a = RNG.app[0]; if (a){ RN.r.app = a.pkg; RN.r.appNome = a.nome; } rngVai('grilletto'); return; }
  RN.r.strada = 'vuoto'; RN.r.grilletto = { stanco: 'stanco', idee: 'altro', confuso: 'confuso', paura: 'paura', imprevisto: 'imprevisto' }[c.k] || '';
  rngVai('costo');
}
function rngGrilletto(i){
  const o = RNG.opz[i];
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  RN.r.grilletto = o[0]; RN.r.grillettoTesto = o[2];
  rngVai(RN.r.strada === 'app' ? 'tenuto' : 'costo');
}
function rngTenuto(i){
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  RN.r.tenuto = RNG_TENUTO[i][0]; RN.r.tenutoTesto = RNG_TENUTO[i][2];
  rngVai('costo');
}
function rngBivio(i){
  const o = RNG.cm[i];
  /* la luce prende la strada: "non cambio niente" resta su quella di ieri */
  const biv = document.querySelector('.rng-biv .biv');
  if (biv && !RNG.bivVia && typeof bivVai === 'function'){
    RNG.bivVia = true;
    bivVai(biv, o[0] === 'niente' ? 'sx' : 'dx', function(){ RNG.bivVia = false; rngBivioVai(i); });
    return;
  }
  rngBivioVai(i);
}
function rngBivioVai(i){
  const o = RNG.cm[i];
  try{ gnAu.scelta(i); flVibra(o[0] === 'niente' ? [10, 40, 10] : 14); }catch(_){ }
  RN.r.contromisura = o[0]; RN.r.contromisuraTesto = o[2];
  if (o[0] === 'niente'){ rngVai('fine'); return; }
  if (o[0] === 'blocco' || o[0] === 'energia'){ rngVai('ora'); return; }
  /* 0.9.295, Andrea: "se non sta togliendo un'abitudine ma vuole essere piu' produttivo, la domanda sulla tentazione non
     c'entra". La sostituzione si chiede solo quando c'e' un'app che tenta. */
  rngVai(RN.r.strada === 'app' ? 'tecnica' : 'fine');
}
function rngOra(i){
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  RN.r.ora = RNG_ORE[i][0]; RN.r.oraTesto = '';
  rngVai(RN.r.strada === 'app' ? 'tecnica' : 'fine');
}
function rngAllora(i){
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  const v = (RNG.alloraVoci || RNG_ALLORA)[i]; if (!v) return;
  RN.r.allora = v[0]; RN.r.alloraTesto = v[2];
  if (v[0] === 'musica'){ rngVai('canzone'); return; }
  rngVai('fine');
}
/* la canzone: un link (YouTube, Spotify, qualunque) o il titolo, che diventa una ricerca su YouTube */
function rngCanzoneFile(inp){
  const f = inp && inp.files && inp.files[0]; if (!f) return;
  if (f.size > 25 * 1024 * 1024){ toast('Il file è troppo grande: scegline uno sotto i 25 MB'); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.salvaCanzone){ toast('Disponibile nell’app installata'); return; }
  const fr = new FileReader();
  fr.onload = async function(){
    try{
      const est = (String(f.name).split('.').pop() || 'mp3').toLowerCase().slice(0, 4);
      const r = await NATIVE.salvaCanzone({ dati: String(fr.result), est: est });
      const titolo = String(f.name).replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ').trim();
      RN.r.musica = 'file:' + r.path; RN.r.musicaTitolo = titolo;
      RN.r.alloraTesto = 'Ascolto "' + titolo + '"';
      try{ localStorage.setItem('fl_canzone', JSON.stringify({ url: RN.r.musica, titolo: titolo, at: Date.now() })); }catch(_){ }
      rngVai('fine');
    }catch(e){ toast('Non riesco a salvare la canzone, riprova'); }
  };
  fr.readAsDataURL(f);
}
function rngCanzoneOk(){
  const a = document.getElementById('rngCanzone'); const t = a ? a.value.trim() : '';
  if (!t){ toast('Scrivi il titolo o incolla il link della canzone'); return; }
  const url = /^https?:\/\//i.test(t) ? t : 'https://www.youtube.com/results?search_query=' + encodeURIComponent(t);
  RN.r.musica = url; RN.r.musicaTitolo = /^https?:/i.test(t) ? '' : t;
  if (RN.r.musicaTitolo) RN.r.alloraTesto = 'Ascolto "' + RN.r.musicaTitolo + '"';
  try{ localStorage.setItem('fl_canzone', JSON.stringify({ url: url, titolo: RN.r.musicaTitolo, at: Date.now() })); }catch(_){ }
  rngVai('fine');
}
function rngScrivo(per){ RNG.scrivoPer = per; rngVai('scrivo'); }
function rngScrivoOk(){
  const a = document.getElementById('rngTesto'); const t = a ? a.value.trim() : '';
  if (!t){ toast('Scrivi qualcosa, anche poche parole'); return; }
  const per = RNG.scrivoPer, r = RN.r;
  /* il passo «scrivo» non resta nella storia: indietro si torna alla domanda */
  RNG.passo = RNG.storia.pop() || RNG.passo;
  if (per === 'ai' && r.ai){ rngAiAvanza(String(r.ai.testo).replace(/\*/g, ''), t); return; }
  if (per === 'causa'){ r.causa = 'altro'; r.testo = t; r.strada = 'vuoto'; r.grilletto = 'altro'; rngImpara('altro', t); rngVai('bivio'); return; }
  if (per === 'grilletto'){ r.grilletto = 'scritto'; r.grillettoTesto = t; rngImpara(r.strada || 'altro', t); rngVai(r.strada === 'app' ? 'tenuto' : 'bivio'); return; }
  if (per === 'tenuto'){ r.tenuto = 'scritto'; r.tenutoTesto = t; rngVai('bivio'); return; }
  if (per === 'bivio'){ r.contromisura = 'scritta'; r.contromisuraTesto = t; rngVai(r.strada === 'app' ? 'tecnica' : 'fine'); return; }
  if (per === 'ora'){ r.ora = 'scritto'; r.oraTesto = t; rngVai(r.strada === 'app' ? 'tecnica' : 'fine'); return; }
  if (per === 'premi'){
    const l = rngPremi().filter(function(x){ return x.t !== t; }); const nuovo = { k: 'mio', ico: '✨', t: t, az: t.charAt(0).toUpperCase() + t.slice(1) };
    rngPremiSalva(l.concat([nuovo])); RNG.premiSel = RNG.premiSel || {}; RNG.premiSel['mio:' + t] = true;
    RNG.passo = 'premi'; rngBarra(); GN.step = ''; gnVai('rn'); return;
  }
  r.allora = 'scritto'; r.alloraTesto = t; rngVai('fine');
}
/* 0.9.284, Andrea: "le ore per il sogno non scivolano via, e' un copy di merda: devi dirgli QUANDO SUCCEDE X, FARO' Y".
   La situazione e' quella che la persona ha appena raccontato (il grilletto o la causa), detta come un fatto. */
const RNG_SITUAZIONI = {
  impegni: ['il lavoro o un impegno ti occupano le ore che avevi dato al sogno', 'il lavoro o un impegno mi occupano le ore che avevo dato al sogno'],
  stanco: ['arrivi all’ora del sogno senza energia', 'arrivo all’ora del sogno senza energia'],
  altro: ['ti metti a fare altre cose al posto del sogno', 'mi metto a fare altre cose al posto del sogno'],
  idee: ['ti metti a fare altre cose al posto del sogno', 'mi metto a fare altre cose al posto del sogno'],
  confuso: ['non sai da dove cominciare', 'non so da dove cominciare'],
  paura: ['hai paura di sbagliare', 'ho paura di sbagliare'],
  imprevisto: ['un imprevisto ti porta via il tempo del sogno', 'un imprevisto mi porta via il tempo del sogno'],
  difficile: ['il lavoro diventa più difficile del previsto', 'il lavoro diventa più difficile del previsto'],
  noia: ['ti annoi mentre lavori al sogno', 'mi annoio mentre lavoro al sogno'],
  notifica: ['una notifica ti chiama mentre lavori', 'una notifica mi chiama mentre lavoro'],
  idea: ['ti viene in mente un’altra cosa mentre lavori', 'mi viene in mente un’altra cosa mentre lavoro']
};
function rngSituazioneK(){ const r = RN.r; return r.grilletto && RNG_SITUAZIONI[r.grilletto] ? r.grilletto : (r.causa && RNG_SITUAZIONI[r.causa] ? r.causa : ''); }
function rngSituazione(){
  const r = RN.r;
  if (r.strada === 'app') return 'ti verrà voglia di aprire ' + (r.appNome || 'quell’app') + ' mentre lavori al sogno';
  if (r.strada === 'mollata') return 'ti verrà voglia di interrompere una sessione';
  if (r.strada === 'rimandata') return 'ti verrà voglia di rimandare "' + (rngVoceTesto('rimandata') || 'quella cosa') + '"';
  const k = rngSituazioneK();
  if (k) return RNG_SITUAZIONI[k][0];
  if (r.grillettoTesto && r.grilletto === 'scritto') return 'succede di nuovo quello che mi hai scritto ("' + r.grillettoTesto.slice(0, 60) + '")';
  return 'arriva l’ora del sogno e non cominci';
}

/* la scelta del passo "costo", a tutto schermo (farfalla.js) */
function rngCostoScelta(){
  const f = rngFuturi();
  if (!f || typeof faScena !== 'function'){ rngVai('bivio'); return; }
  faScena({
    kick: 'Rientra in rotta',
    titolo: f.anniTxt ? 'Il sogno può arrivare ' + f.anniTxt + ' prima.' : 'Da qui la strada si divide.',
    sotto: '',
    bivio: true,
    opzioni: [
      { k: 'resto', ico: '<span class="fa-pill blu"></span>', n: 'Resto come oggi', s: (f.ieriTxt || '') + '.', colore: '#4FB8FF', tinta: 'blu', cartello: f.ieriTxt },
      { k: 'cambio', ico: '<span class="fa-pill rossa"></span>', n: 'Cambio strada', s: (f.pattoTxt || '') + '.', colore: '#FF5A66', tinta: 'rosso', cartello: f.pattoTxt }
    ],
    senzaFarfalle: function(k){ return k === 'resto'; },
    onScelta: function(k){ RNG.costoScelta = k; },
    dopoTitolo: function(){ return 'Hai scelto di cambiare strada'; },
    dopoSotto: function(){ return 'Adesso decidiamo cosa cambia da domani.'; },
    poi: function(k){
      if (k === 'resto'){ if (typeof monApri === 'function') monApri({ manuale: true, ritorno: 's-genio' }); return; }
      rngVai('bivio');
    }
  });
}

/* ---------- i due futuri: il navigatore simula ogni giorno come ieri, e ogni giorno come il piano ---------- */
function rngFuturi(){
  if (RNG.futuri) return RNG.futuri;
  try{
    const s = ETA.stato, inp = ETA.inp;
    if (!s || !inp || typeof etaSimula !== 'function') return null;
    const ieri = (ETA.serie || []).filter(function(d){ return d.eta === 1 && d.pian > 0 && !d.pausa; })[0];
    const rIeri = ieri ? Math.min(2, ieri.credito / ieri.pian) : null;
    const sim = function(rate){ const p = { valori: [rate], tabella: [0], media: rate, sd: 0, n: 1 }; return etaSimula(Object.assign({}, inp, { pool: p, runs: 1, tilt: null })); };
    /* 0.9.300, Andrea: "non deve spiegare, deve mostrare una data". Anche per "resto come oggi" una data vera:
       un giorno a zero non si ripete identico per sempre, quindi il ritmo di ieri ha un pavimento dell'8% del piano.
       "l'11 aprile", "l'8 maggio", "il 3 giugno". */
    const art = function(t){ return /^(1|8|11)/.test(t) ? 'l’' + t : 'il ' + t; };
    const txt = function(r){ return (r && isFinite(r.p50)) ? 'Arrivi ' + art(etaDataTxt(r.p50)) : 'Arrivi dopo il ' + (new Date().getFullYear() + 40); };
    const patto = sim(Math.max(1, s.rate || 0));
    const vieri = rIeri === null ? null : sim(Math.max(0.08, rIeri));
    if (!vieri) return null;
    RNG.futuri = { ieri: vieri.p50, patto: patto.p50, ieriTxt: txt(vieri), pattoTxt: txt(patto) };
    /* quanto piu' tardi, detto in tempo di vita */
    try{
      const d = Math.round((vieri.p50 - patto.p50) / 86400000);
      if (isFinite(d) && d > 0){
        const a = Math.floor(d / 365), m = Math.floor((d % 365) / 30);
        RNG.futuri.anniTxt = a ? a + (a === 1 ? ' anno' : ' anni') + (m ? ' e ' + m + (m === 1 ? ' mese' : ' mesi') : '') : (m ? m + (m === 1 ? ' mese' : ' mesi') : d + (d === 1 ? ' giorno' : ' giorni'));
      }
    }catch(_){ }
    return RNG.futuri;
  }catch(_){ return null; }
}

/* ---------- la fine: il patto, un pulsante ---------- */
/** La stessa situazione detta da chi fa il patto, in prima persona. */
function rngSituazioneIo(){
  const r = RN.r;
  if (r.strada === 'app') return 'mi viene voglia di aprire ' + (r.appNome || 'quell’app') + ' mentre lavoro al sogno';
  if (r.strada === 'mollata') return 'mi viene voglia di interrompere una sessione';
  if (r.strada === 'rimandata') return 'mi viene voglia di rimandare "' + (rngVoceTesto('rimandata') || 'quella cosa') + '"';
  const k = rngSituazioneK();
  if (k) return RNG_SITUAZIONI[k][1];
  if (r.grillettoTesto && r.grilletto === 'scritto') return 'succede di nuovo quello che mi ha fermato ("' + r.grillettoTesto.slice(0, 60) + '")';
  return 'arriva l’ora del sogno e non comincio';
}
function rngPattoTesto(){
  const r = RN.r;
  if (!r.alloraTesto) return '';
  return 'Se ' + rngSituazioneIo() + ', allora: ' + r.alloraTesto.charAt(0).toLowerCase() + r.alloraTesto.slice(1) + '.';
}
function rngSalva(rimedio){
  const r = RN.r;
  const l = rnLista();
  l.push({ at: Date.now(), causa: r.causa || r.strada || '', strada: r.strada || '', app: r.app || '', appNome: r.appNome || '', ora: r.ora || '', grilletto: r.grillettoTesto || '', tenuto: r.tenutoTesto || '',
           testo: r.testo || '', contromisura: r.contromisuraTesto || '', patto: rngPattoTesto(), rimedio: rimedio || r.contromisuraTesto || '', task: rnTask(), delta: (RNG.visto && RNG.visto.delta) || (RN.v && RN.v.delta) || 0 });
  try{ localStorage.setItem(RN_KEY, JSON.stringify(l.slice(-60))); }catch(_){ }
  if (r.alloraTesto && r.app){
    try{
      const m = JSON.parse(localStorage.getItem(RNG_SOST_KEY) || '{}') || {};
      /* il rompicapo porta con se' il suo segno: la schermata di blocco mostra il pulsante che lo apre */
      m[r.app] = (r.allora === 'rompicapo' ? '@rompicapo ' : (r.allora === 'cruciverba' ? '@cruciverba ' : (r.allora === 'musica' && r.musica ? '@musica ' + r.musica + ' ' : (r.allora === 'ruota' && r.ruota && r.ruota.length ? '@ruota ' + r.ruota.join('|').replace(/\s+/g, ' ') + '\n' : '')))) + r.alloraTesto.replace(/[.\s]+$/, '') + '.';
      localStorage.setItem(RNG_SOST_KEY, JSON.stringify(m));
      if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ sostituzioni: JSON.stringify(m) }).catch(function(){ });
    }catch(_){ }
  }
  if (r.alloraTesto){
    try{ const p = JSON.parse(localStorage.getItem(RNG_PATTI_KEY) || '[]') || []; p.push({ at: Date.now(), se: rngSituazioneIo(), allora: r.alloraTesto, contromisura: r.contromisuraTesto || '', app: r.appNome || '' }); localStorage.setItem(RNG_PATTI_KEY, JSON.stringify(p.slice(-30))); }catch(_){ }
  }
}
/** La contromisura scelta: { btn, fa } */
function rngAzione(){
  const r = RN.r, o = RNG_ORE.filter(function(x){ return x[0] === r.ora; })[0];
  switch (r.contromisura){
    case 'blocco': return { btn: 'Crea il blocco', fa: 'rngFaBlocco()' };
    case 'notifiche': return { btn: 'Apri le notifiche di ' + (r.appNome || 'quell’app'), fa: 'rngFaNotifiche()' };
    case 'stanza': case 'focus': return { btn: 'Parti con 25 minuti di Full Focus', fa: 'rngFocus(25, \'' + String(rnTask() || 'Il lavoro sul sogno').replace(/'/g, '’') + '\')' };
    case 'cinque': return { btn: 'Parti con 5 minuti', fa: 'rnFaCinque()' };
    case 'pezzi': return { btn: 'Scrivi i primi tre pezzi', fa: 'rngFocus(5, \'Scrivere i primi tre pezzi da quindici minuti\')' };
    case 'tutorial': return { btn: 'Parti con 20 minuti', fa: 'rngFocus(20, \'Guardare un tutorial e prendere appunti\')' };
    case 'energia': return { btn: r.ora === 'mattina' ? 'Spostalo a domattina' : 'Va bene, domani lo metto ' + (o ? o[2].toLowerCase() : 'lì'), fa: r.ora === 'mattina' ? 'rnFaMattina()' : 'rnFaImprevisto()' };
    case 'caveau': return { btn: 'Apri il caveau delle idee', fa: 'rnFaUlisse()' };
    case 'ore': return { btn: 'Cambia le ore a settimana', fa: 'rngFaOre()' };
    case 'scadenza': case 'riparto': case 'scritta': return { btn: 'Va bene, domani riparto', fa: 'rnFaImprevisto()' };
  }
  return { btn: 'Va bene, domani riparto', fa: 'rnFaImprevisto()' };
}
function rngFine(){
  const r = RN.r, f = rngFuturi();
  if (r.contromisura === 'niente'){
    rngSalva('nessuna contromisura');
    gnDomanda('pensa', 'Va bene, la scelta è tua. Ricorda solo dove porta la strada di ieri.',
      (f ? '<div class="rng-futuri"><div class="rng-f giu solo"><small>Se ogni giorno va come ieri</small><b>' + gnEsc(f.ieriTxt) + '</b></div></div>' : '')
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rnScelto();rngChiudi()">Ho capito</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();rngRipensa()">Ci ripenso</button>');
    return;
  }
  const az = rngAzione();
  rngSalva();
  /* 0.9.295, Andrea: "il riepilogo fa schifo: tutto attaccato, a sinistra, il testo verde". Centrato, a righe con aria,
     la data in fondo come una conseguenza. */
  const patto = '<div class="rng-patto"><small>Da domani</small>'
    + (r.contromisuraTesto ? '<b>' + gnEsc(r.contromisuraTesto) + '</b>' : '')
    + (r.alloraTesto && r.strada === 'app' ? '<p>Quando ti viene voglia di ' + gnEsc(r.appNome || 'quell’app') + ': ' + gnEsc(r.alloraTesto.charAt(0).toLowerCase() + r.alloraTesto.slice(1)) + '.</p>' : '')
    + (f ? '<i>' + gnEsc(f.pattoTxt) + '</i>' : '') + '</div>';
  if (rnPremium() || rnAgente()){
    /* il blocco si crea subito: l'agente riceve il patto e ricalcola la roadmap */
    if (r.contromisura === 'blocco') rngFaBlocco(true);
    gnDomanda('rivela', 'Ecco il tuo patto. Il tuo agente personale ricalcola il percorso *partendo da questo*.',
      patto + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rngAgente()">Ricalcola il percorso</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();rnScelto();rngChiudi()">Non ora</button>');
    return;
  }
  gnDomanda('rivela', 'Ecco il tuo patto. Scritto così, *è molto più facile da mantenere*.',
    patto + (typeof cvConsensoHtml === 'function' ? cvConsensoHtml() : '') + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rnScelto();rngChiudiSoft();' + az.fa + '">' + gnEsc(az.btn) + '</button></div>'
    + '<button type="button" class="gn-link" onclick="event.stopPropagation();rnScelto();rngChiudi()">Non ora</button>'
    + rngAssaggioHtml());
}
function rngFaBlocco(zitto){
  const r = RN.r, o = (r.ora === 'scritto' && rngOreDaTesto(r.oraTesto)) || RNG_ORE.filter(function(x){ return x[0] === r.ora; })[0] || RNG_ORE[1];
  if (r.app && typeof frProgrammaDaAgente === 'function'){
    frProgrammaDaAgente({ nome: 'Il mio patto: ' + (r.appNome || 'app'), app: [r.app], dalle: o[3], alle: o[4] }, false);
    if (zitto){ toast(r.appNome + ' bloccata dalle ' + o[3] + ' alle ' + o[4]); return; }
    rnFatto(r.appNome + ' bloccata dalle ' + o[3] + ' alle ' + o[4] + ', tutti i giorni');
    goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
    return;
  }
  if (!zitto){ goId('s-home'); try{ switchTab('severa'); }catch(_){ } toast('Crea un programma per la fascia ' + o[2].toLowerCase()); }
}
function rngFaNotifiche(){
  const r = RN.r;
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.openAppNotificationSettings){ NATIVE.openAppNotificationSettings({ pkg: r.app }); rnFatto('Spegni le notifiche e torna qui'); return; } }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.openAppSettings){ NATIVE.openAppSettings({ pkg: r.app }); rnFatto('Tocca Notifiche e spegnile'); return; } }catch(_){ }
  rnFatto('Apri Impostazioni, poi App, poi ' + (r.appNome || 'l’app') + ', e spegni le notifiche');
  goId('s-home'); try{ switchTab('rotta'); }catch(_){ }
}
function rngFaOre(){ goId('s-home'); if (typeof mpOpzioniApri === 'function') mpOpzioniApri(); else try{ switchTab('rotta'); }catch(_){ } }
/* le cause scritte a mano: si mandano al server (senza nome) e si leggono quelle piu' frequenti */
function rngImpara(causa, testo){ try{ if (typeof frApi === 'function') frApi('POST', '/api/focuslock/rientro/causa', { device: (typeof frDevice === 'function') ? frDevice() : '', causa: causa || 'altro', testo: String(testo || '').slice(0, 2000) }).catch(function(){ }); }catch(_){ } }
async function rngImparateCarica(){ try{ if (typeof frApi !== 'function') return; const r = await frApi('GET', '/api/focuslock/rientro/cause'); RNG.imparate = (r && Array.isArray(r.cause)) ? r.cause.filter(function(x){ return x && x.testo; }) : []; }catch(_){ RNG.imparate = []; } }
/* i prossimi passi del percorso: quelli che il ricalcolo del tuo agente personale riscriverebbe */
function rngPassiRoadmap(){
  const out = [];
  try{ ['oggi', 'settimana', 'mese'].forEach(function(k){ (ozAnello(k).passi || []).forEach(function(p){ if (p && p.t && !p.fatto && out.length < 3) out.push(String(p.t)); }); }); }catch(_){ }
  return out;
}
function rngAgente(){
  const r = RN.r;
  const v = RNG.visto;
  const visto = v ? v.voci.slice(0, 3).map(function(x){ return x.t; }).join(' ') : '';
  const af = (typeof prcAppFrase === 'function' && v) ? prcAppFrase(v, RNG.app) : '';
  const dati = { giorni: (v && v.delta > 0) ? rngTempo(v.delta) : ((RN.v && RN.v.delta > 0) ? rngTempo(RN.v.delta) : ''), causa: r.causa || r.strada || '',
    causaTesto: [visto, af].filter(Boolean).join(' '), dettaglio: r.grilletto || '', dettaglioTesto: [r.grillettoTesto, r.tenutoTesto].filter(Boolean).join('; '),
    testoLibero: r.testo || '', contromisura: r.contromisuraTesto || '', patto: rngPattoTesto(), task: rnTask() };
  rngChiudiSoft();
  try{ if (typeof nvRientroSegna === 'function') nvRientroSegna(); }catch(_){ }
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
  setTimeout(function(){
    if (typeof agRientro === 'function'){ agRientro(dati); return; }
    if (typeof agNuovaConversazione === 'function') agNuovaConversazione('La data in cui arrivo al mio sogno si è spostata' + (dati.giorni ? ' di ' + dati.giorni : '') + '. ' + dati.causaTesto + ' Cosa mi ha portato fuori strada: ' + (dati.dettaglioTesto || dati.testoLibero) + '. Da domani: ' + dati.contromisura + '. ' + dati.patto + ' Ricalcola il mio percorso partendo da questo.');
  }, 250);
}
function rngAssaggioHtml(){
  const passi = rngPassiRoadmap();
  if (!passi.length) return '<p class="rng-prem" onclick="event.stopPropagation();if(typeof pwUpsellApri===\'function\')pwUpsellApri()">Con Premium il tuo agente personale riscrive il tuo percorso partendo dal tuo patto.</p>';
  return '<div class="rng-ass" onclick="event.stopPropagation();if(typeof pwUpsellApri===\'function\')pwUpsellApri()">'
    + '<small>Il ricalcolo del percorso</small><p>Con il tuo patto, il tuo agente personale riscriverebbe questi passi:</p>'
    + passi.map(function(t){ return '<div class="rng-ass-r"><span>' + gnEsc(t) + '</span><i>🔒 la versione nuova</i></div>'; }).join('')
    + '<b>Ricalcola con il tuo agente personale</b></div>';
}
function rngFocus(min, intento){
  goId('s-home'); try{ switchTab('sveglia'); }catch(_){ }
  setTimeout(function(){ try{ const p = ffPref(); p.minutes = min; p.intent = intento; ffSavePref(); if (typeof stGoFocus === 'function') stGoFocus(); else if (typeof ffOpen === 'function') ffOpen(); }catch(_){ } }, 350);
}
/** Per il tuo agente personale: i patti fatti, oltre alle uscite di rotta. */
function rngPattiPerAgente(){
  try{ const p = JSON.parse(localStorage.getItem(RNG_PATTI_KEY) || '[]') || []; if (!p.length) return ''; return 'Patti dell’utente: ' + p.slice(-5).map(function(x){ return 'se ' + x.se + ', allora ' + x.allora.toLowerCase(); }).join('; ') + '.'; }catch(_){ return ''; }
}

/* ===========================================================================================
   0.9.296, Andrea: "le domande senza filo logico rispetto alla risposta di prima mi frustrano; veloce come Google AI
   Mode, zero attesa". Con l'agente (Premium, o l'account di Andrea) le domande non sono piu' scritte qui: dopo la
   prima, ogni domanda la sceglie un modello veloce sul server (/api/focuslock/agent/rientro) partendo dalla risposta
   appena data e dai dati della giornata. Mentre si legge una domanda, l'app chiede gia' il passo dopo per OGNI
   opzione: al tocco la risposta e' pronta. Per una tentazione il Genio mostra cosa c'era subito prima e subito dopo
   (la timeline delle app nell'ora della caduta). Alla fine un programma di blocco vero (frProgrammaDaAgente) e la
   sostituzione dell'abitudine sulla schermata di blocco, non un patto a parole. Senza agente, o se il server non
   risponde, resta il flusso scritto qui sopra.
   =========================================================================================== */
const RNG_AI = { storia: [], pila: [], cache: {}, pronti: {}, dati: null, datiP: null, spento: false };
const RNG_AI_DOMANDA0 = 'Da ieri, cosa è successo con il tuo sogno?';
const RNG_AI_ATTESA = 12000;
function rngAiOk(){ return !RNG_AI.spento && typeof agApi === 'function' && (rnPremium() || rnAgente()); }
function rngAiReset(){
  RNG_AI.storia = []; RNG_AI.pila = []; RNG_AI.cache = {}; RNG_AI.pronti = {}; RNG_AI.dati = null; RNG_AI.spento = false;
  RNG_AI.datiP = Promise.resolve(RNG.attesa).then(rngAiDati).catch(function(){ return {}; }).then(function(d){ RNG_AI.dati = d || {}; return RNG_AI.dati; });
}
function rngAiHHMM(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
/** I granelli del telefono fusi per app (due accensioni a meno di due secondi sono la stessa). */
function rngAiFondi(grani){
  const out = [];
  (grani || []).slice().sort(function(a, b){ return a.s - b.s; }).forEach(function(x){
    const u = out[out.length - 1];
    if (u && u.p === x.p && x.s - (u.s + u.ms) <= 2000){ u.ms = Math.max(u.ms, x.s + (x.ms || 0) - u.s); return; }
    out.push({ p: x.p, l: x.l || x.p, s: x.s, ms: x.ms || 0 });
  });
  return out;
}
/** Minuti per app dentro una finestra, i piu' lunghi prima: [{ nome, min }] */
function rngAiSomma(g, da, a, salta){
  const m = {};
  g.forEach(function(x){
    if (x.p === salta) return;
    const s = Math.max(da, x.s), e = Math.min(a, x.s + x.ms);
    if (e > s){ m[x.l] = (m[x.l] || 0) + (e - s); }
  });
  return Object.keys(m).map(function(k){ return { nome: k, min: Math.max(1, Math.round(m[k] / 60000)) }; }).filter(function(x){ return m[x.nome] >= 30000; }).sort(function(x, y){ return y.min - x.min; }).slice(0, 4);
}
/**
 * La caduta: la sessione piu' lunga sull'app che distrae di piu', con le app usate nei venti minuti prima e dopo
 * (e i siti, quando il telefono li conta). E' quello che il Genio mostra prima di chiedere cosa ti ci ha portato.
 */
function rngAiCaduta(g, app){
  if (!app || !g.length) return null;
  const sess = [];
  g.filter(function(x){ return x.p === app.pkg; }).forEach(function(x){
    const u = sess[sess.length - 1];
    if (u && x.s - u.e <= 120000){ u.e = Math.max(u.e, x.s + x.ms); return; }
    sess.push({ s: x.s, e: x.s + x.ms });
  });
  const lunga = sess.sort(function(a, b){ return (b.e - b.s) - (a.e - a.s); })[0];
  if (!lunga || lunga.e - lunga.s < 5 * 60000) return null;
  const VENTI = 20 * 60000;
  const prima = rngAiSomma(g, lunga.s - VENTI, lunga.s, app.pkg);
  const ultima = g.filter(function(x){ return x.p !== app.pkg && x.s < lunga.s && x.s + x.ms > lunga.s - VENTI; }).pop();
  return { app: app.nome, pkg: app.pkg, inizio: rngAiHHMM(lunga.s), fine: rngAiHHMM(lunga.e), min: Math.round((lunga.e - lunga.s) / 60000),
           da: lunga.s, a: lunga.e, prima: prima, ultimaPrima: ultima ? ultima.l : '', dopo: rngAiSomma(g, lunga.e, lunga.e + VENTI, app.pkg) };
}
/** I dati della giornata per il modello: niente nomi, solo app, orari, minuti e passi. */
async function rngAiDati(){
  const v = RNG.visto || {};
  const oggi = (typeof etaMezzanotte === 'function') ? etaMezzanotte() : new Date().setHours(0, 0, 0, 0);
  const da = Math.min(v.da || oggi, oggi - 86400000), a = (v.giorniFa >= 1) ? oggi : Date.now();
  const d = { adesso: rngAiHHMM(Date.now()), periodo: (v.giorniFa > 1 ? 'gli ultimi ' + v.giorniFa + ' giorni' : 'ieri') };
  try{ const o = JSON.parse(localStorage.getItem('fl_oracle') || 'null'); if (o && o.target) d.sogno = String(o.target).slice(0, 200); }catch(_){ }
  try{ d.task = rnTask() || ''; }catch(_){ }
  if (v.voci) d.visto = v.voci.slice(0, 5).map(function(x){ return x.t; });
  if (v.delta > 0) d.arrivoSpostato = rngTempo(v.delta);
  try{ const gg = (v.voci || []).filter(function(x){ return x.tipo === 'giornata' || x.tipo === 'giornate'; })[0]; if (gg && gg.v && gg.v.vars) d.piano = { oreInProgramma: gg.v.vars.pianOre, oreFatte: gg.v.vars.fatteOre }; }catch(_){ }
  d.appGiorno = (RNG.app || []).map(function(x){ return { pkg: x.pkg, nome: x.nome, min: x.min }; });
  /* il tempo per app, ora per ora, dalla timeline del telefono */
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTimeline){
      const t = await NATIVE.getTimeline({ from: da, to: a, minMs: 0, limit: 6000 });
      if (t && t.granted){
        const g = rngAiFondi(t.grani);
        const ore = {}, tot = {};
        g.forEach(function(x){
          tot[x.p] = tot[x.p] || { pkg: x.p, nome: x.l, ms: 0 }; tot[x.p].ms += x.ms;
          const h = new Date(x.s).getHours(); ore[h] = ore[h] || {}; ore[h][x.l] = (ore[h][x.l] || 0) + x.ms;
        });
        d.appOre = Object.keys(ore).map(function(h){
          const m = ore[h]; const app = Object.keys(m).map(function(k){ return { nome: k, min: Math.round(m[k] / 60000) }; }).filter(function(x){ return x.min >= 3; }).sort(function(x, y){ return y.min - x.min; }).slice(0, 3);
          return { ora: String(h).padStart(2, '0') + ':00', app: app };
        }).filter(function(x){ return x.app.length; });
        d.appTutte = Object.keys(tot).map(function(k){ return tot[k]; }).sort(function(x, y){ return y.ms - x.ms; }).slice(0, 8).map(function(x){ return { pkg: x.pkg, nome: x.nome, min: Math.round(x.ms / 60000) }; });
        d.caduta = rngAiCaduta(g, (RNG.app || [])[0]);
      }
    }
  }catch(_){ }
  /* i siti aperti nei venti minuti prima della caduta, quando il telefono li conta */
  try{
    if (d.caduta && NATIVE && NATIVE.getWebTime){
      const w = await NATIVE.getWebTime({ from: d.caduta.da - 20 * 60000, to: d.caduta.a, bucket: 'none', limit: 5 });
      const siti = ((w && (w.sites || w.siti)) || []).map(function(x){ return { sito: x.domain || x.host || x.site || x.name || x.d || '', min: Math.round((x.ms || 0) / 60000) }; }).filter(function(x){ return x.sito && x.min >= 1; });
      if (siti.length) d.caduta.siti = siti;
    }
  }catch(_){ }
  /* le sessioni di Full Focus e i passi del percorso */
  try{
    const ff = (typeof dpFF === 'function') ? dpFF(da, Date.now()) : [];
    d.sessioni = ff.slice(-6).map(function(x){ return { ora: rngAiHHMM(x.s), minuti: Math.round(x.min), finita: x.ok, task: String(x.l || '').slice(0, 80) }; });
  }catch(_){ }
  try{
    const fatti = [], mancati = [];
    ['oggi', 'settimana'].forEach(function(k){ (ozAnello(k).passi || []).forEach(function(p){ if (!p || !p.t) return; (p.fatto ? fatti : mancati).push(String(p.t).slice(0, 80)); }); });
    d.roadmap = { fatti: fatti.slice(0, 5), mancati: mancati.slice(0, 5) };
  }catch(_){ }
  d.premi = rngPremi().map(function(x){ return x.az || x.t; }).concat(RNG_PREMI.slice(0, 6).map(function(x){ return x[3]; })).slice(0, 10);
  return d;
}
function rngAiChiave(domanda, risposta){ return JSON.stringify([RNG_AI.storia.map(function(x){ return x.r; }), domanda, risposta]); }
/** Il passo dopo una risposta: dalla cache se e' gia' stato chiesto (in anticipo), altrimenti lo chiede adesso. */
function rngAiChiedi(domanda, risposta){
  const k = rngAiChiave(domanda, risposta);
  if (RNG_AI.cache[k]) return RNG_AI.cache[k];
  const storia = RNG_AI.storia.slice();
  const p = RNG_AI.datiP.then(function(dati){
    return Promise.race([
      agApi('POST', '/api/focuslock/agent/rientro', { domanda: domanda, risposta: risposta, storia: storia, dati: dati }),
      new Promise(function(_, no){ setTimeout(function(){ no(new Error('tempo scaduto')); }, RNG_AI_ATTESA); })
    ]);
  }).then(function(r){
    if (!r || (r.tipo !== 'domanda' && r.tipo !== 'fine')) throw new Error((r && r.error) || 'risposta vuota');
    RNG_AI.pronti[k] = r;
    return r;
  });
  p.catch(function(){ delete RNG_AI.cache[k]; });
  RNG_AI.cache[k] = p;
  return p;
}
/** La risposta data: entra nella storia e il Genio passa alla domanda dopo (gia' pronta, di solito). */
function rngAiAvanza(domanda, risposta){
  const k = rngAiChiave(domanda, risposta);
  const p = rngAiChiedi(domanda, risposta);
  RNG_AI.storia.push({ d: domanda, r: risposta });
  RNG_AI.pila.push({ k: k, p: p });
  rngVai('ai');
}
function rngAiPos(){ return Math.min(0.9, 0.14 + 0.15 * RNG_AI.pila.length); }
function rngAiEntra(){
  const top = RNG_AI.pila[RNG_AI.pila.length - 1];
  if (!top){ RNG.passo = 'prima'; GN.step = ''; gnVai('rn'); return; }
  const pronto = RNG_AI.pronti[top.k];
  if (pronto){ rngAiMostra(pronto); return; }
  /* non ancora pronto (una risposta scritta a mano, o la rete lenta): il Genio pensa */
  try{ gnPosa('pensa'); const el = document.getElementById('gnTesto'); if (el) el.innerHTML = '<span class="rng-ai-pensa"><i></i><i></i><i></i></span>'; const rr = document.getElementById('gnRisp'); if (rr) rr.innerHTML = ''; }catch(_){ }
  top.p.then(function(r){
    if (RNG.passo !== 'ai' || !GN.on || GN.modo !== 'rn' || RNG_AI.pila[RNG_AI.pila.length - 1] !== top) return;
    rngAiMostra(r);
  }).catch(function(){
    if (RNG.passo !== 'ai' || !GN.on || GN.modo !== 'rn' || RNG_AI.pila[RNG_AI.pila.length - 1] !== top) return;
    rngAiFallisce();
  });
}
/** Il server non risponde: si torna alle domande scritte, dalla prima risposta. */
function rngAiFallisce(){
  RNG_AI.spento = true;
  try{ toast('Il Genio non risponde: continuo con le domande di sempre'); }catch(_){ }
  RNG_AI.pila = []; RNG_AI.storia = [];
  while (RNG.storia.length && RNG.passo !== 'prima') RNG.passo = RNG.storia.pop();
  RNG.passo = 'prima';
  rngPrimaVai(RN.r.prima || 'tentazione');
}
function rngAiMostra(r){
  RN.r.ai = r;
  if (r.tipo === 'fine'){ RNG.barraP = 1; const b = document.getElementById('gnProgBar'); if (b) b.style.width = '100%'; rngAiFine(r); return; }
  RNG.aiOpz = r.opzioni || [];
  const voci = RNG.aiOpz.map(function(o, i){ return [i, gnEsc(o.ico || '•'), o.t]; });
  const cad = r.mostraCaduta ? rngAiCadutaHtml() : '';
  gnDomanda('pensa', r.testo, cad + rngCarte(voci, 'rngAiScegli', 'ai'));
  /* intanto si prepara il passo dopo per ogni opzione: al tocco e' gia' li' */
  const dom = String(r.testo).replace(/\*/g, '');
  RNG.aiOpz.forEach(function(o){ rngAiChiedi(dom, o.t).catch(function(){ }); });
}
function rngAiScegli(i){
  const o = (RNG.aiOpz || [])[i], r = RN.r.ai; if (!o || !r) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  rngAiAvanza(String(r.testo).replace(/\*/g, ''), o.t);
}
const RNG_AI_ICO = {
  prima: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  caduta: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18h2"/></svg>',
  dopo: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="M13 6l6 6-6 6"/></svg>'
};
/** Cosa c'era subito prima e subito dopo la caduta, in tre righe. */
function rngAiCadutaHtml(){
  const c = RNG_AI.dati && RNG_AI.dati.caduta; if (!c) return '';
  const lista = function(l){ return l.map(function(x){ return gnEsc(x.nome) + ' ' + x.min + ' min'; }).join(', '); };
  const siti = (c.siti || []).map(function(x){ return gnEsc(x.sito); }).join(', ');
  return '<div class="rng-cad">'
    + '<div class="rng-cad-r"><span>' + RNG_AI_ICO.prima + '</span><p><small>Nei 20 minuti prima</small>' + (c.prima.length ? lista(c.prima) : 'Il telefono era fermo') + (siti ? '<br>Siti aperti: ' + siti : '') + '</p></div>'
    + '<div class="rng-cad-r on"><span>' + RNG_AI_ICO.caduta + '</span><p><small>Alle ' + c.inizio + '</small>Apri ' + gnEsc(c.app) + ' e resti ' + c.min + ' minuti, fino alle ' + c.fine + '</p></div>'
    + '<div class="rng-cad-r"><span>' + RNG_AI_ICO.dopo + '</span><p><small>Nei 20 minuti dopo</small>' + (c.dopo.length ? lista(c.dopo) : 'Hai chiuso il telefono') + '</p></div>'
    + '</div>';
}
function rngAiNomeApp(pkg){
  const d = RNG_AI.dati || {};
  const x = (d.appTutte || []).concat(d.appGiorno || []).filter(function(a){ return a.pkg === pkg; })[0];
  return x ? x.nome : pkg;
}
const RNG_AI_GIORNI = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'];
function rngAiGiorniTxt(g){
  if (!Array.isArray(g) || g.every(Boolean)) return 'tutti i giorni';
  if (g.slice(0, 5).every(Boolean) && !g[5] && !g[6]) return 'dal lunedì al venerdì';
  return g.map(function(x, i){ return x ? RNG_AI_GIORNI[i] : ''; }).filter(Boolean).join(', ');
}
function rngAiFine(r){
  const p = r.programma;
  RNG.passo = 'ai';
  if (!p){
    rngAiSalva(r, false);
    gnDomanda('rivela', r.testo, (r.patto ? '<div class="rng-patto"><small>Da domani</small><b>' + gnEsc(r.patto) + '</b></div>' : '')
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rnScelto();rngChiudi()">Torno al sogno</button></div>');
    return;
  }
  const app = p.app.map(rngAiNomeApp).join(', ');
  gnDomanda('rivela', r.testo,
    '<div class="rng-patto rng-prog"><small>Il programma</small><b>' + gnEsc(p.nome) + '</b>'
    + '<p>Blocca ' + gnEsc(app) + ' dalle ' + p.dalle + ' alle ' + p.alle + ', ' + gnEsc(rngAiGiorniTxt(p.giorni)) + '.</p>'
    + (r.sostituzione ? '<p>Quando ti viene voglia, la schermata di blocco ti ricorda: "' + gnEsc(r.sostituzione) + '"</p>' : '')
    + (r.patto ? '<i>' + gnEsc(r.patto) + '</i>' : '') + '</div>'
    + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rngAiCrea()">Crea il programma</button></div>'
    + '<button type="button" class="gn-link" onclick="event.stopPropagation();rngAiSalva(RN.r.ai,false);rnScelto();rngChiudi()">Non ora</button>');
}
/** Il rientro nel registro (per il tuo agente personale e per la Timeline) e, se c'e', la sostituzione sulla schermata di blocco. */
function rngAiSalva(r, creato){
  if (!r || RNG_AI.salvato === r) return;
  RNG_AI.salvato = r;
  const p = r.programma, c = RNG_AI.dati && RNG_AI.dati.caduta;
  const l = rnLista();
  l.push({ at: Date.now(), causa: 'conversazione', strada: RN.r.prima || '', app: p && p.app[0] || (c && c.pkg) || '', appNome: p ? rngAiNomeApp(p.app[0]) : (c ? c.app : ''),
           testo: RNG_AI.storia.map(function(x){ return x.d + ' ' + x.r; }).join(' | ').slice(0, 1500), contromisura: p && creato ? 'Programma "' + p.nome + '" dalle ' + p.dalle + ' alle ' + p.alle : '',
           patto: r.patto || '', rimedio: creato ? 'programma' : 'nessuno', task: rnTask(), delta: (RNG.visto && RNG.visto.delta) || (RN.v && RN.v.delta) || 0 });
  try{ localStorage.setItem(RN_KEY, JSON.stringify(l.slice(-60))); }catch(_){ }
  if (r.patto){
    try{ const pp = JSON.parse(localStorage.getItem(RNG_PATTI_KEY) || '[]') || []; pp.push({ at: Date.now(), se: r.patto, allora: r.sostituzione || '', contromisura: p ? p.nome : '', app: p ? rngAiNomeApp(p.app[0]) : '' }); localStorage.setItem(RNG_PATTI_KEY, JSON.stringify(pp.slice(-30))); }catch(_){ }
  }
  if (creato && p && r.sostituzione){
    try{
      const m = JSON.parse(localStorage.getItem(RNG_SOST_KEY) || '{}') || {};
      p.app.forEach(function(pkg){ m[pkg] = r.sostituzione.replace(/[.\s]+$/, '') + '.'; });
      localStorage.setItem(RNG_SOST_KEY, JSON.stringify(m));
      if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSettings) NATIVE.setSettings({ sostituzioni: JSON.stringify(m) }).catch(function(){ });
    }catch(_){ }
  }
}
function rngAiCrea(){
  const r = RN.r.ai, p = r && r.programma; if (!p) return;
  try{ gnAu.scelta(0); flVibra([20, 40, 30]); }catch(_){ }
  if (typeof frProgrammaDaAgente === 'function') frProgrammaDaAgente({ nome: p.nome, app: p.app, dalle: p.dalle, alle: p.alle, giorni: p.giorni, zitto: true }, false);
  rngAiSalva(r, true);
  rngChiudiSoft();
  rnFatto('Programma "' + p.nome + '" creato: ' + p.app.map(rngAiNomeApp).join(', ') + ' bloccata dalle ' + p.dalle + ' alle ' + p.alle);
}

/* ---------- l'aggancio alla scena del Genio ---------- */
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.rn = { entra: rngEntra };
  if (typeof gnChiudiTop === 'function'){
    const vero = gnChiudiTop;
    gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'rn'){ rngChiudi(); return; } return vero.apply(this, arguments); };
  }
  if (typeof gnIndietro === 'function'){
    const vero2 = gnIndietro;
    gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rn') return rngIndietro(); return vero2.apply(this, arguments); };
  }
  /* l'agente legge anche i patti */
  if (typeof rnPerAgente === 'function'){
    const vero3 = rnPerAgente;
    window.rnPerAgente = rnPerAgente = function(){ return [vero3.apply(this, arguments), rngPattiPerAgente()].filter(Boolean).join(' '); };
  }
  const st = document.createElement('style');
  st.textContent = [
    '.rng-mio{display:block;margin:14px auto 0}',
    '.rng-file{display:flex;align-items:center;justify-content:center;gap:8px;margin:0 0 12px;cursor:pointer}',
    '.rng-pied{display:flex;justify-content:center;gap:10px;margin-top:12px}.rng-pbtn{display:inline-flex;align-items:center;gap:6px;border:1.5px solid #D6E2F2;border-radius:99px;background:#fff;color:#0E2350;font:700 13.5px var(--font-body);padding:8px 14px;cursor:pointer}',
    '.gn-card.rng-ruota{background:linear-gradient(135deg,#FCE4EC,#E3F2FD)}',
    '.rng-lez{margin:4px 0 14px;padding:16px;border-radius:18px;background:rgba(255,255,255,.97);color:#0E2350;text-align:center}.rng-lez b{display:block;font:800 16px var(--font-display)}.rng-lez p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:#3B4A63}',
    '.rng-isola #gnGenio{display:none}',
    /* 0.9.296: la caduta (prima, durante, dopo) e il Genio che pensa */
    '.rng-cad{display:flex;flex-direction:column;gap:6px;margin:0 0 12px}.rng-cad-r{display:flex;align-items:flex-start;gap:10px;padding:11px 14px;border-radius:16px;background:rgba(255,255,255,.96);color:#0E2350;text-align:left}.rng-cad-r span{flex:none;display:flex;width:30px;height:30px;border-radius:99px;align-items:center;justify-content:center;background:#E3F0FF;color:#0075E3}.rng-cad-r p{margin:0;font:700 14px/1.4 var(--font-body)}.rng-cad-r small{display:block;font:800 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#5A6B86;margin-bottom:2px}.rng-cad-r.on{box-shadow:0 0 0 2px #E5394A inset}.rng-cad-r.on span{background:#FDE3E5;color:#C62835}',
    '.rng-ai-pensa{display:inline-flex;gap:6px;padding:6px 0}.rng-ai-pensa i{width:8px;height:8px;border-radius:99px;background:currentColor;opacity:.35;animation:rngPensa 1s infinite}.rng-ai-pensa i:nth-child(2){animation-delay:.15s}.rng-ai-pensa i:nth-child(3){animation-delay:.3s}@keyframes rngPensa{50%{opacity:1;transform:translateY(-3px)}}',
    '.rng-prog p{margin-top:10px!important}',
    '.rng-altre{display:flex;align-items:center;gap:6px;margin:14px auto 0;font-weight:800}',
    '#gnRisp .gn-carta .gn-card.on{border-color:#3D9BFF !important;background:rgba(61,155,255,.24) !important;color:#0E2350 !important;box-shadow:0 0 0 2px #3D9BFF inset,0 0 18px rgba(61,155,255,.45);position:relative}',
    /* 0.9.287: sulla carta chiara il testo della scelta resta scuro (prima era bianco e la guardia del contrasto lo correggeva dopo un secondo: il lampo) */
    '#gnRisp .gn-carta .gn-card.on b{color:#0E2350 !important}body.dark #gnRisp .gn-carta .gn-card.on,body.dark #gnRisp .gn-carta .gn-card.on b{color:#fff !important}',
    /* 0.9.290, Andrea: "le card scelte non devono avere la spunta blu: basta il bordo evidenziato" */
    '.rng-visto{display:flex;flex-direction:column;gap:8px;margin:0 0 12px}',
    '.rng-v{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.96);text-align:left;color:#0E2350}.rng-v span{font-size:20px;line-height:1.3;flex:none}.rng-v p{flex:1;margin:0;font:700 14.5px/1.45 var(--font-body);color:#0E2350}.rng-v i{flex:none;padding:4px 9px;border-radius:99px;background:#FDE3E5;color:#C62835;font:800 12px var(--font-body);font-style:normal;white-space:nowrap}',
    '.rng-biv{margin:0 0 12px}.rng-biv .biv{max-height:26vh}',
    '.rng-futuri{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 0 12px}.rng-f{padding:12px;border-radius:16px;text-align:left}.rng-f small{display:block;font:800 10.5px/1.35 var(--font-body);letter-spacing:.06em;text-transform:uppercase}.rng-f b{display:block;margin-top:5px;font:800 14px/1.35 var(--font-body)}',
    '.rng-f.giu{background:#3A1520;color:#FFB3BB}.rng-f.giu b{color:#fff}.rng-f.su{background:#0F3A2A;color:#9BE8C3}.rng-f.su b{color:#fff}.rng-f.solo{grid-column:1 / -1}',
    '.rng-patto{background:rgba(255,255,255,.97);border-radius:20px;padding:20px 18px;margin:4px 0 14px;text-align:center;color:#0E2350}.rng-patto i{display:block;margin-top:14px;padding-top:12px;border-top:1px solid #E3EAF4;font:700 14px var(--font-body);font-style:normal;color:#0075E3}.rng-patto b{margin-top:8px!important}.rng-patto p{margin-top:12px!important}.rng-patto small{display:block;font:800 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}.rng-patto b{display:block;margin-top:5px;font:800 16.5px/1.4 var(--font-body)}.rng-patto p{margin:8px 0 0;font:600 13.5px/1.45 var(--font-body);color:#33476B}.rng-patto .rng-patto-f{color:#137A50}',
    '.rng-ass{margin:16px 0 0;padding:14px 16px;border-radius:18px;background:rgba(255,255,255,.08);border:1px solid rgba(140,198,255,.35);text-align:left;cursor:pointer}',
    '.rng-ass small{display:block;font:800 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.rng-ass p{margin:6px 0 10px;font:600 13.5px/1.45 var(--font-body);color:#DCEBFF}',
    '.rng-ass-r{display:flex;flex-direction:column;gap:3px;padding:9px 0;border-top:1px solid rgba(140,198,255,.2)}.rng-ass-r span{font:600 13.5px/1.4 var(--font-body);color:#fff}.rng-ass-r i{font:700 12px var(--font-body);font-style:normal;color:#8CC6FF}',
    '.rng-ass b{display:block;margin-top:10px;text-align:center;font:800 14px var(--font-body);color:#8CC6FF}',
    '.rng-prem{margin:14px 6px 0;text-align:center;font:600 12.5px/1.45 var(--font-body);color:#BFE0FF;cursor:pointer;text-decoration:underline;text-underline-offset:3px}'
  ].join('');
  document.head.appendChild(st);
})();
