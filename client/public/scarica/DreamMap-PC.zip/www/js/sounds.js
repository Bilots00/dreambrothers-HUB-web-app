/* sounds.js - i suoni di sottofondo: registrazioni vere, non sintesi.

   La versione precedente sintetizzava tutto con Web Audio, e faceva schifo: rumore filtrato non
   è pioggia, per quanto lo si moduli. Qui ci sono registrazioni sul campo prese da Freesound
   con licenza CC0 (nessun diritto riservato: si usano ovunque, anche in un'app a pagamento,
   senza permessi né pagamenti), tagliate a un minuto, cucite in loop con una dissolvenza di
   tre secondi e portate allo stesso volume percepito. Chi le ha registrate è scritto in
   audio/nature/credits.json e in fondo alla lista: la licenza non lo chiede, la decenza sì.

   Il loop lo fa Web Audio (AudioBufferSourceNode.loop), non <audio loop>: il tag ha un buco
   udibile a ogni ripetizione su Android, il buffer no. */

const SND = { ctx: null, src: null, gain: null, id: 'none', vol: 0.5, buffers: {}, bytes: {}, credits: null,
              loading: '', playing: false, nativeOk: false, volT: 0, volPend: 0, avvisato: false, warming: '' };
const SND_KEY = 'fl_sound';
/* 0.9.326, Andrea: il brusio di un locale non esiste piu' */
try{ if (localStorage.getItem(SND_KEY) === 'cafe') localStorage.removeItem(SND_KEY); }catch(_){ }

const SOUNDS = [
  { g: 'Natura', items: [
    { id: 'rain',      ico: '🌧️', n: 'Pioggia',            d: 'Pioggia fitta, registrata sotto una tettoia' },
    { id: 'storm',     ico: '⛈️', n: 'Temporale',           d: 'Pioggia e tuoni lontani' },
    { id: 'ocean',     ico: '🌊', n: 'Onde del mare',       d: 'Risacca su una spiaggia' },
    { id: 'river',     ico: '🏞️', n: 'Ruscello',            d: 'Acqua che corre fra le pietre' },
    { id: 'wind',      ico: '🍃', n: 'Vento fra gli alberi', d: 'Foglie e raffiche' },
    { id: 'fire',      ico: '🔥', n: 'Camino',              d: 'Legna che scoppietta' },
    { id: 'night',     ico: '🌙', n: 'Notte d’estate', d: 'Grilli e aria ferma' },
    { id: 'forest',    ico: '🌲', n: 'Bosco al mattino',    d: 'Uccelli e silenzio' }
  ] },
  /* 0.9.254, Andrea: come brain.fm. Non sono registrazioni: li suona musica.js (battimenti binaurali
     e un pad che respira), quindi servono le cuffie e non passano dal servizio nativo. */
  { g: 'Per la testa (con le cuffie)', items: [
    { id: 'focus',     ico: '🎯', n: 'Concentrazione',      d: 'Battimenti a 14 Hz, per lavorare' },
    { id: 'relax',     ico: '🌤️', n: 'Rilassamento',        d: 'Battimenti a 8 Hz, per staccare' },
    { id: 'sonno',     ico: '😴', n: 'Sonno',               d: 'Battimenti a 3 Hz, per addormentarsi' }
  ] }
];
function sndGenerato(id){ return !!(typeof MU_TESTA !== 'undefined' && MU_TESTA[id]); }

/* Chi suona: il telefono, se c'e'.

   Dentro all'app installata il suono lo riproduce un servizio nativo (SoundService), che lo
   tiene in vita quando l'app passa dietro e fa comparire il lettore con la pausa nella tendina
   di Android — come fanno le app di musica. Web Audio resta per l'anteprima nel browser, dove
   un servizio Android non esiste. */
function sndNative(){ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.soundPlay); }

function sndAll(){ return SOUNDS.reduce((a, g) => a.concat(g.items), []); }
function sndName(id){ const s = sndAll().filter(x => x.id === id)[0]; if (s) return s.n; const v = sndSpeciale(id) ? sndVoceDi(id) : null; return v ? v.t : ''; }
function sndAvailable(id){ return sndGenerato(id) || sndSpeciale(id) || !!(SND.credits && SND.credits[id]); }

async function sndCredits(){
  if (SND.credits) return SND.credits;
  try{ const r = await fetch('audio/nature/credits.json'); SND.credits = await r.json(); }
  catch(_){ SND.credits = {}; }
  return SND.credits;
}
function sndCtx(){
  if (!SND.ctx){
    try{ SND.ctx = new (window.AudioContext || window.webkitAudioContext)(); }catch(_){ SND.ctx = null; }
  }
  if (SND.ctx && SND.ctx.state === 'suspended'){ try{ SND.ctx.resume(); }catch(_){ } }
  return SND.ctx;
}
function sndLevel(){ return SND.vol * SND.vol; }

/* SCALDARE IL SUONO. Il tempo fra il tocco e il suono era tutto qui: prendere il file e
   decodificarlo, un paio di secondi buoni. Si fa prima — l'ultimo suono usato appena si apre
   la scheda, e quello sotto al dito appena il dito si appoggia, che e' un attimo prima del
   click. Chi tocca «play» trova il suono gia' pronto. */
function sndWarm(id){
  if (!id || id === 'none' || SND.buffers[id] || SND.warming === id) return;
  SND.warming = id;
  sndBuffer(id).catch(function(){ }).then(function(){ if (SND.warming === id) SND.warming = ''; });
}
function sndPrefetch(){
  const idle = window.requestIdleCallback || function(f){ setTimeout(f, 800); };
  idle(function(){
    let ultimo = '';
    try{ ultimo = localStorage.getItem(SND_KEY) || ''; }catch(_){ }
    if (ultimo && ultimo !== 'none') sndWarm(ultimo);
    sndCredits().then(function(cr){
      sndAll().forEach(function(x){ if (cr && cr[x.id]) sndBytes(x.id).catch(function(){ }); });
    });
  });
}
/* La scialuppa si ritira piano quando il lettore del telefono ha preso il timone. */
function sndWebOff(ms){
  const src = SND.src, g = SND.gain, ctx = SND.ctx;
  if (!src) return;
  SND.src = null; SND.gain = null;
  try{
    if (g && ctx && ms){
      g.gain.setValueAtTime(Math.max(0.0001, g.gain.value), ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + ms / 1000);
      setTimeout(function(){ try{ src.stop(); }catch(_){ } }, ms + 60);
    } else src.stop();
  }catch(_){ }
}   // curva quadratica: a metà corsa è un quarto, come si aspetta l'orecchio

/* I byte codificati (un megabyte l'uno) si tengono tutti: sono la parte lenta da prendere e
   la parte leggera da tenere. La decodifica, che pesa dieci volte tanto, si fa a richiesta. */
async function sndBytes(id){
  if (SND.bytes[id]) return SND.bytes[id];
  const r = await fetch('audio/nature/' + id + '.mp3');
  const ab = await r.arrayBuffer();
  SND.bytes[id] = ab;
  return ab;
}
async function sndBuffer(id){
  if (SND.buffers[id]) return SND.buffers[id];
  const ctx = sndCtx();
  if (!ctx) return null;
  const ab = await sndBytes(id);
  /* decodeAudioData si prende il buffer e lo svuota: gli si da' una copia, o il secondo
     avvio dello stesso suono troverebbe zero byte */
  const buf = await new Promise((ok, ko) => { try{ ctx.decodeAudioData(ab.slice(0), ok, ko); }catch(e){ ko(e); } });
  SND.buffers[id] = buf;
  // se ne tengono in memoria quattro: un minuto stereo decodificato pesa una decina di MB
  const keys = Object.keys(SND.buffers);
  if (keys.length > 4) delete SND.buffers[keys[0]];
  return buf;
}

/* senzaServizio: chi sta per far partire una lista non manda lo stop al servizio. I comandi viaggiano in parallelo: lo stop arrivava DOPO la partenza
   e spegneva il suono appena nato (provato su BlueStacks, 0.9.320). La lista sostituisce da sola quello che sta suonando. */
function sndStop(senzaServizio){
  try{ if (typeof muTestaOff === 'function') muTestaOff(); }catch(_){ }
  if (SND.audioX){ try{ SND.audioX.pause(); SND.audioX.removeAttribute('src'); }catch(_){ } SND.audioX = null; }
  if (sndNative()){
    SND.playing = false;
    SND.nativeOk = false;
    if (!senzaServizio) try{ NATIVE.soundCommand({ what: 'stop' }); }catch(_){ }
    /* e si prosegue: se stava suonando la scialuppa (Web Audio), va fermata anche quella */
  }
  const ctx = SND.ctx;
  const src = SND.src, gain = SND.gain;
  SND.src = null; SND.gain = null;
  if (!ctx || !src) return;
  try{
    gain.gain.cancelScheduledValues(ctx.currentTime);
    gain.gain.setValueAtTime(Math.max(0.0001, gain.gain.value), ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8);
  }catch(_){ }
  setTimeout(() => { try{ src.stop(); }catch(_){ } try{ src.disconnect(); gain.disconnect(); }catch(_){ } }, 900);
}
/* IL VOLUME.

   Prima ogni evento del cursore faceva un giro completo: comando al servizio, servizio riavviato
   in primo piano, notifica ricostruita. Trascinare il cursore voleva dire decine di quei giri al
   secondo, e il pallino arrivava dove lo avevi lasciato mezzo secondo prima. Adesso il valore si
   scrive subito (l'interfaccia non aspetta nessuno) e al telefono ne arriva al massimo uno ogni
   centoventi millisecondi, con un comando che tocca solo il volume del player. */
function sndVolume(v){
  SND.vol = Math.max(0, Math.min(1, v));
  /* 0.9.308: lo stesso cursore regola le tracce della libreria (effetti.js) */
  try{ if (typeof fxBranoVolume === 'function') fxBranoVolume(SND.vol * SND.vol); }catch(_){ }
  try{ if (typeof suoVolume === 'function') suoVolume(); }catch(_){ }
  try{ if (sndGenerato(SND.id) && typeof muVolume === 'function') muVolume(SND.vol * SND.vol); }catch(_){ }
  try{ localStorage.setItem(SND_KEY + '_vol', String(SND.vol)); }catch(_){ }
  if (SND.ctx && SND.gain){ try{ SND.gain.gain.setTargetAtTime(sndLevel(), SND.ctx.currentTime, 0.15); }catch(_){ } }
  if (sndNative() && SND.id !== 'none') sndVolumePush();
}
function sndVolumePush(){
  const wait = Math.max(0, 120 - (Date.now() - SND.volT));
  if (SND.volPend) clearTimeout(SND.volPend);
  SND.volPend = setTimeout(function(){
    SND.volT = Date.now(); SND.volPend = 0;
    try{ NATIVE.soundCommand({ what: 'volume', volume: sndLevel() }); }catch(_){ }
  }, wait);
}

async function sndPlay(id){
  /* un suono alla volta: chi parte da un altro pezzo dell'app chiude la sessione delle schede */
  try{ if (typeof suoStaccata === 'function') suoStaccata(); }catch(_){ }
  /* 0.9.308: un suono alla volta. Se suona una traccia della libreria (effetti.js), si ferma */
  try{ if (typeof fxBranoFerma === 'function' && fxBranoFerma() && typeof fxPaginaRidisegna === 'function') setTimeout(fxPaginaRidisegna, 0); }catch(_){ }
  if (sndSpeciale(id)) return sndPlaySpeciale(id);
  /* i suoni generati (musica.js): si accendono e si spengono qui, senza file e senza servizio */
  if (sndGenerato(id)){
    if (id === SND.id){ muTestaOff(); SND.id = 'none'; SND.playing = false; sndPaint(); return; }
    sndStop();
    if (!muTesta(id)){ toast('Il suono non parte su questo telefono'); return; }
    try{ muVolume(sndLevel()); }catch(_){ }
    SND.id = id; SND.playing = true; try{ localStorage.setItem(SND_KEY, id); }catch(_){ }
    sndPaint(); return;
  }
  /* Toccare il suono che sta gia' suonando lo mette in pausa, e ritoccarlo lo riprende: e'
     quello che fa chiunque, ed e' il motivo per cui il pulsante "Ferma il suono" non serve
     piu' a niente. */
  if (id === SND.id && id !== 'none'){
    if (sndNative() && SND.nativeOk){
      const next = !SND.playing;
      SND.playing = next;
      try{ await NATIVE.soundCommand({ what: next ? 'resume' : 'pause', volume: sndLevel() }); }catch(_){ }
      sndPaint();
      return;
    }
    sndStop(); SND.id = 'none'; SND.playing = false; sndPaint(); return;
  }
  sndStop();
  SND.id = id;
  SND.nativeOk = false;
  if (id === 'none'){ if (sndNative()){ try{ await NATIVE.soundCommand({ what: 'stop' }); }catch(_){ } } SND.playing = false; sndPaint(); return; }
  await sndCredits();
  if (!sndAvailable(id)){ toast('Questo suono non è ancora nell’app'); SND.id = 'none'; sndPaint(); return; }
  if (typeof scrSuonoChiuso === 'function' && scrSuonoChiuso(id)){ toast('Questo suono si trova in una mystery box'); SND.id = 'none'; sndPaint(); return; }

  if (sndNative()){
    /* PRIMA IL SUONO, POI IL LETTORE.
       Il servizio del telefono e' la strada giusta — tiene il suono vivo quando l'app passa
       dietro e mette il lettore nella tendina — ma e' lenta a partire e su qualche telefono
       non parte. Quindi il suono lo fa partire SUBITO la pagina (Web Audio, gia' scaldato), e
       il telefono viene chiamato in parallelo: se conferma che sta suonando, la pagina si
       ritira con una dissolvenza e resta lui; se non conferma, resta la pagina, e il motivo
       si legge nel toast. In nessun caso si aspetta in silenzio. */
    SND.playing = true; sndPaint();
    try{ localStorage.setItem(SND_KEY, id); }catch(_){ }
    sndPlayWeb(id);
    try{ await NATIVE.soundPlay({ id: id, name: sndName(id), volume: sndLevel() }); }catch(_){ }
    setTimeout(async function(){
      if (SND.id !== id || !SND.playing) return;
      let st = null;
      try{ if (NATIVE.soundState) st = await NATIVE.soundState(); }catch(_){ }
      if (SND.id !== id || !SND.playing) return;
      if (st && st.playing && st.id === id){ SND.nativeOk = true; sndWebOff(1200); return; }
      SND.nativeOk = false;
      if (st && st.error && !SND.avvisato){
        SND.avvisato = true;
        try{ toast('Lettore di sistema non partito (' + st.error + '): suono dall\u2019app'); }catch(_){ }
      }
      if (!SND.src) sndPlayWeb(id);
    }, 3000);
    return;
  }
  await sndPlayWeb(id);
}

/* Il suono dentro alla pagina: e' la strada del browser, ed e' la scialuppa del telefono. */
async function sndPlayWeb(id){
  SND.loading = id; sndPaint();
  let buf = null;
  try{ buf = await sndBuffer(id); }catch(_){ buf = null; }
  SND.loading = '';
  if (!buf || SND.id !== id){ if (!buf){ toast('Non riesco a leggere il suono'); SND.id = 'none'; SND.playing = false; } sndPaint(); return; }
  if (SND.nativeOk || SND.src) { sndPaint(); return; }     // il telefono ha gia' preso il timone, o la pagina sta gia' suonando
  const ctx = sndCtx();
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  const gain = ctx.createGain();
  gain.gain.value = 0.0001;
  src.connect(gain); gain.connect(ctx.destination);
  src.start();
  gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, sndLevel()), ctx.currentTime + 1.5);
  SND.src = src; SND.gain = gain;
  SND.playing = true;
  try{ localStorage.setItem(SND_KEY, id); }catch(_){ }
  sndPaint();
}

/* ---------- la tendina in fondo alla Sveglia ---------- */
function sndToggleOpen(){
  const el = document.getElementById('sndWrap');
  if (!el) return;
  el.classList.toggle('open');
  try{ localStorage.setItem(SND_KEY + '_open', el.classList.contains('open') ? '1' : '0'); }catch(_){ }
  sndPaint();
}
function sndPaint(){
  const head = document.getElementById('sndHeadSub');
  if (head) head.textContent = SND.id !== 'none' ? sndName(SND.id) + ' · in riproduzione' : 'Lavoro profondo, relax, sonno e meditazione';
  /* la pagina a schede (suoni-start.js) segue lo stato del suono: pausa dalla tendina, stop */
  try{ if (typeof suoStatoPaint === 'function') suoStatoPaint(); }catch(_){ }
  const host = document.getElementById('sndBody');
  if (!host) return;
  /* 0.9.331, Andrea: "ti avevo detto che non lo volevo piu' quel collassabile". LA CAUSA: chi l'aveva aperto una volta se lo ritrovava aperto per sempre (fl_sound_open). La lista sta nella pagina dei suoni */
  host.innerHTML = '';
}
/* la pagina «Suoni per concentrarsi»: dal 0.9.311 a schede, in suoni-start.js */
registerScreen('s-suoni', '<div id="suoPag" class="suo-pag"></div>', { back: function(){ try{ switchTab('rotta'); }catch(_){ } return 's-home'; } });
function sndPaginaApri(){
  if (typeof suoApri === 'function') suoApri();
}

/* ---------------------------------------------------------------------------------------
   I PROGRAMMI DEI SUONI (1/10). Come i programmi della scheda Blocco: ora, giorni, Wi-Fi,
   posizione, combinazione, con lo stesso editor. A quell'ora il suono parte da solo, con il
   lettore nella tendina del telefono (pausa e stop restano li'). Serve a rendere piu'
   piacevoli i compiti noiosi o difficili: la pioggia dalle 9 alle 12, il camino la sera.
   Il motore li controlla una volta al minuto (SoundPrograms.java).
   --------------------------------------------------------------------------------------- */
const SND_PROG_KEY = 'fl_sound_programs';
function sndProgrammi(){ try{ return JSON.parse(localStorage.getItem(SND_PROG_KEY) || '[]') || []; }catch(_){ return []; } }
function sndProgrammiSalva(l){
  try{ localStorage.setItem(SND_PROG_KEY, JSON.stringify(l)); }catch(_){ }
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setSoundPrograms){
      NATIVE.setSoundPrograms({ programs: l.map(function(p){
        const sc = (typeof programToSchedule === 'function') ? programToSchedule(p) : p;
        const vx = sndSpeciale(p.suono) ? sndVoceDi(p.suono) : null;
        return Object.assign({}, sc, { type: p.type || 'ora', sound: p.suono || 'rain', soundName: sndName(p.suono || 'rain'), volume: p.volume || 0.5, voce: vx || undefined,
          shuffle: !!p.shuffle, playlist: sndAll().filter(function(x){ return (sndAvailable(x.id) || !SND.credits) && !(typeof scrSuonoChiuso === 'function' && scrSuonoChiuso(x.id)); }).map(function(x){ return { id: x.id, name: x.n }; }) });
      }) });
    }
  }catch(_){ }
}
/* 0.9.317, Andrea: "fra le condizioni non c'e' dentro l'app: facendo una sessione di Full Focus, o andando in una sezione di DreamMap, deve
   poter partire da solo un suono". Stanno sul telefono e non nel motore nativo: e' l'app stessa a sapere dove sei. */
const SND_DENTRO_KEY = 'fl_snd_dentro';
const SND_MOMENTI = [
  { k: 'fullfocus', ico: '🌱', t: 'Una sessione di Full Focus', s: 'Parte finiti i dieci secondi per ripensarci' },
  { k: 's-agente', ico: '🧞', t: 'Il tuo agente personale', s: 'Parte quando apri la chat, si ferma quando esci' },
  { k: 's-diario', ico: '📔', t: 'Il diario di viaggio', s: 'Parte quando apri il diario, si ferma quando esci' },
  { k: 's-note', ico: '📝', t: 'Le tue note', s: 'Parte quando apri le note, si ferma quando esci' }
];
function sndDentroLista(){ try{ return JSON.parse(localStorage.getItem(SND_DENTRO_KEY) || '[]') || []; }catch(_){ return []; } }
function sndDentroSalva(l){ try{ localStorage.setItem(SND_DENTRO_KEY, JSON.stringify(l)); }catch(_){ } }
/** Il suono del programma acceso per quel momento, o niente. */
function sndDentro(k){ const p = sndDentroLista().filter(function(x){ return x.k === k && x.on !== false; })[0]; return p ? p.suono : ''; }
let SND_DENTRO_SEL = { k: 'fullfocus', suono: '' }, SND_DENTRO_ON = '';
function sndDentroApri(){ window.BLK_SOUND = false; SND_DENTRO_SEL = { k: 'fullfocus', suono: '' }; goId('s-suoni-dentro'); sndDentroPaint(); }
/* LA SCELTA DEL SUONO (0.9.319). Andrea: "3000 pill: voglio quattro schede come nella pagina dei suoni, e i suoni di quella scheda compaiono
   dopo averla toccata; e la possibilita' di scegliere un suono dal proprio telefono". Le voci sono le stesse del lettore: tracce della libreria aperte
   (id dbm-...), registrazioni dell'app, suoni generati; i miei file hanno id mio-... (fl_snd_miei). */
const SND_MIEI_K = 'fl_snd_miei';
let SND_SCELTA_TAB = 'focus';
function sndMiei(){ try{ return JSON.parse(localStorage.getItem(SND_MIEI_K) || '[]') || []; }catch(_){ return []; } }
function sndSpeciale(id){ return /^(dbm-|mio-)/.test(String(id || '')); }
function sndVociTab(k){
  let l = []; try{ l = (typeof suoCatalogo === 'function') ? suoCatalogo() : []; }catch(_){ l = []; }
  return l.filter(function(t){ return !t.chiusa && (t.scopo === 'natura' ? k === 'relax' : ((t.scopo === 'relax' || t.scopo === 'sleep' || t.scopo === 'meditate') ? t.scopo : 'focus') === k); });
}
function sndSceltaHtml(sel, azione){
  const tabs = (typeof SUO_TAB !== 'undefined') ? SUO_TAB : [];
  const voci = sndVociTab(SND_SCELTA_TAB), miei = sndMiei();
  return '<div class="snd-sc-tabs" role="tablist">' + tabs.map(function(t){ return '<button type="button" role="tab" aria-selected="' + (t.k === SND_SCELTA_TAB) + '" class="' + (t.k === SND_SCELTA_TAB ? 'on' : '') + '" onclick="sndSceltaTab(\'' + t.k + '\',\'' + azione + '\')">' + esc(t.n) + '</button>'; }).join('') + '</div>'
    + '<div class="sd-d-c snd-sc-voci">' + (voci.length ? voci.map(function(x){ return '<button type="button" class="' + (sel === x.id ? 'on' : '') + '" onclick="' + azione + '(\'' + x.id + '\')">' + esc(x.t) + '</button>'; }).join('') : '<p class="snd-sc-vuoto">Non ci sono ancora suoni aperti in questa scheda.</p>') + '</div>'
    + '<h4 class="snd-sc-h">Dal tuo telefono</h4><div class="sd-d-c snd-sc-voci">' + miei.map(function(x){ return '<button type="button" class="' + (sel === x.id ? 'on' : '') + '" onclick="' + azione + '(\'' + x.id + '\')">🎵 ' + esc(x.n) + '</button>'; }).join('')
    + '<button type="button" class="snd-sc-mio" onclick="sndMioScegli(\'' + azione + '\')">+ Scegli un suono dal telefono</button></div>';
}
function sndSceltaTab(k, azione){ SND_SCELTA_TAB = k; try{ flVibra(6); }catch(_){ } if (azione === 'sndDentroScegli') sndDentroPaint(); else if (typeof sndEditorMode === 'function') sndEditorMode(true); }
async function sndMioScegli(azione){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickMedia){ toast('Si sceglie dall’app sul telefono'); return; }
  let r = null; try{ r = await NATIVE.pickMedia({ kind: 'audio' }); }catch(_){ return; }
  if (!r || !r.uri) return;
  const l = sndMiei(), id = 'mio-' + Date.now().toString(36);
  l.push({ id: id, n: String(r.name || 'Il mio suono').replace(/\.[a-z0-9]{2,4}$/i, ''), f: r.uri });
  try{ localStorage.setItem(SND_MIEI_K, JSON.stringify(l)); }catch(_){ }
  try{ window[azione](id); }catch(_){ }
}
function sndVoceDi(id){
  const m = sndMiei().filter(function(x){ return x.id === id; })[0];
  if (m) return { id: id, t: m.n, file: m.f };
  let t = null; try{ t = (typeof suoCatalogo === 'function') ? suoCatalogo().filter(function(x){ return x.id === id; })[0] : null; }catch(_){ t = null; }
  return t ? { id: id, t: t.t, url: t.url, fine: t.loop ? t.loop.startSec + t.loop.lengthSec : 0 } : null;
}
/* un suono scelto dalla libreria o dal telefono: lo suona il servizio, con il lettore nella tendina; senza servizio, la pagina */
async function sndPlaySpeciale(id){
  if (id === SND.id && id !== 'none'){
    const next = SND.playing === false;
    SND.playing = next;
    if (SND.audioX){ try{ if (next) SND.audioX.play(); else SND.audioX.pause(); }catch(_){ } }
    else if (sndNative()){ try{ await NATIVE.soundCommand({ what: next ? 'resume' : 'pause', volume: sndLevel() }); }catch(_){ } }
    sndPaint(); return;
  }
  const conLista = sndNative() && typeof NATIVE.suoLista === 'function';
  sndStop(conLista);
  const v = sndVoceDi(id); if (!v){ if (conLista) try{ NATIVE.soundCommand({ what: 'stop' }); }catch(_){ } toast('Questo suono non c’è più'); SND.id = 'none'; sndPaint(); return; }
  SND.id = id; SND.playing = true; SND.nativeOk = false;
  try{ localStorage.setItem(SND_KEY, id); }catch(_){ }
  if (sndNative() && typeof NATIVE.suoLista === 'function'){
    try{ await NATIVE.suoLista({ lista: [v], i: 0, volume: sndLevel(), casuale: false }); SND.nativeOk = true; sndPaint(); return; }catch(_){ }
  }
  try{
    const a = new Audio(v.url || (window.Capacitor && Capacitor.convertFileSrc ? Capacitor.convertFileSrc(v.file) : v.file)); a.loop = true; a.volume = sndLevel(); SND.audioX = a; await a.play();
  }catch(_){ toast('Questo suono adesso non parte'); }
  sndPaint();
}
function sndDentroScegli(id){ SND_DENTRO_SEL.suono = id; sndDentroPaint(); }
function sndDentroPaint(){
  const b = document.getElementById('sndDentroBody'); if (!b) return;
  b.innerHTML = '<h3 class="sd-d-t">Quando deve partire?</h3><div class="sd-d-l">' + SND_MOMENTI.map(function(m){
      return '<button type="button" class="sd-d-r' + (SND_DENTRO_SEL.k === m.k ? ' on' : '') + '" onclick="SND_DENTRO_SEL.k=\'' + m.k + '\';sndDentroPaint()"><span>' + m.ico + '</span><div><b>' + m.t + '</b><small>' + m.s + '</small></div></button>';
    }).join('') + '</div>'
    + '<h3 class="sd-d-t">Quale suono?</h3>' + sndSceltaHtml(SND_DENTRO_SEL.suono, 'sndDentroScegli')
    + '<button type="button" class="cta sd-d-ok" onclick="sndDentroOk()">Crea il programma</button>';
}
function sndDentroOk(){
  if (!SND_DENTRO_SEL.suono){ toast('Scegli quale suono deve partire'); return; }
  const l = sndDentroLista().filter(function(x){ return x.k !== SND_DENTRO_SEL.k; });
  l.push({ k: SND_DENTRO_SEL.k, suono: SND_DENTRO_SEL.suono, on: true });
  sndDentroSalva(l);
  toast('Programma di suoni creato');
  if (typeof suoProgApri === 'function') suoProgApri();
}
function sndDentroToggle(i){ const l = sndDentroLista(); if (!l[i]) return; l[i].on = l[i].on === false; sndDentroSalva(l); if (typeof suoProgPaint === 'function') suoProgPaint(); }
function sndDentroElimina(i){ const l = sndDentroLista(); l.splice(i, 1); sndDentroSalva(l); if (typeof suoProgPaint === 'function') suoProgPaint(); }
function sndDentroRigheHtml(){
  return sndDentroLista().map(function(p, i){
    const m = SND_MOMENTI.filter(function(x){ return x.k === p.k; })[0] || { ico: '🎵', t: 'DreamMap' };
    const off = p.on === false;
    return '<div class="snd-prog' + (off ? ' off' : '') + '"><span class="ico">' + m.ico + '</span><div><b>' + esc(sndName(p.suono) || 'Suono') + '</b><small>Dentro DreamMap · ' + esc(m.t) + '</small></div>'
      + '<button type="button" class="switch' + (off ? '' : ' on') + '" onclick="sndDentroToggle(' + i + ')" aria-label="Attivo"></button>'
      + '<button type="button" class="snd-prog-x" onclick="sndDentroElimina(' + i + ')" aria-label="Elimina">✕</button></div>';
  }).join('');
}
/* le sezioni: si accende entrando, si spegne uscendo. Non tocca un suono partito a mano o una sessione di Full Focus. */
document.addEventListener('fl:screen', function(e){
  const id = e && e.detail;
  try{
    if (typeof FF !== 'undefined' && FF && FF.run) return;
    if (SND_DENTRO_ON && SND_DENTRO_ON !== id){ const era = SND_DENTRO_ON; SND_DENTRO_ON = ''; const su = sndDentro(era); if (su && typeof SND !== 'undefined' && SND.id === su && typeof sndStop === 'function') sndStop(); }
    const su = sndDentro(id);
    if (su && typeof sndPlay === 'function' && (typeof SND === 'undefined' || SND.id !== su || SND.playing === false)){ SND_DENTRO_ON = id; sndPlay(su); }
  }catch(_){ }
});
function sndSaveProgram(clean, idx){
  const l = sndProgrammi();
  if (idx >= 0 && l[idx]) l[idx] = clean; else l.push(clean);
  sndProgrammiSalva(l);
}
function sndProgToggle(i){ const l = sndProgrammi(); if (!l[i]) return; l[i].on = l[i].on === false; sndProgrammiSalva(l); if (typeof suoProgPaint === 'function') suoProgPaint(); }
async function sndProgElimina(i){
  if (!sndProgrammi()[i] || !(await blkEliminaChiedi())) return;
  const l = sndProgrammi(); if (!l[i]) return;
  l.splice(i, 1); sndProgrammiSalva(l); if (typeof suoProgPaint === 'function') suoProgPaint();
}
function sndProgModifica(i){
  const p = sndProgrammi()[i]; if (!p || typeof openEditor !== 'function') return;
  window.BLK_GREY = false; window.BLK_SOUND = true;
  DRAFT = JSON.parse(JSON.stringify(p)); DRAFT.sound = true; DRAFT.idx = i;
  if (!Array.isArray(DRAFT.days) || DRAFT.days.length !== 7) DRAFT.days = [true, true, true, true, true, true, true];
  openEditor();
}
/* 0.9.321, Andrea: "sei righe attaccate sono troppe, e Programmi e' gia' nel titolo della pagina": la spiegazione sta qui */
function sndProgInfo(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<h3>A cosa serve un programma</h3>'
    + (typeof flInfoRighe === 'function' ? flInfoRighe([
        ['🧠', 'Una decisione in meno', 'Non devi scegliere cosa ascoltare: il suono è già lì.'],
        ['🧹', 'I compiti noiosi pesano meno', 'Un suono legato a un compito ti aiuta a cominciarlo.'],
        ['🔁', 'Diventa un’abitudine', 'Stesso suono, stesso momento: la testa impara a entrare nel lavoro.']
      ]) : '') + '</div>');
}
function sndProgrammiHtml(){
  const l = sndProgrammi();
  return '<div class="snd-prog-box"><div class="snd-prog-t"><b>Crea un programma<button type="button" class="snd-prog-i" onclick="sndProgInfo()" aria-label="A cosa serve un programma"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 11v7M12 6.5v.2"/></svg></button></b><small>Il suono parte da solo quando ti serve: a un\u2019ora, in un posto o mentre usi un\u2019app.</small></div>'
    + sndDentroRigheHtml()
    + (l.length ? l.map(function(p, i){
        const paused = p.on === false;
        return '<div class="snd-prog' + (paused ? ' off' : '') + '" onclick="sndProgModifica(' + i + ')" role="button">'
          + '<span class="ico">' + (p.icon || '🎵') + '</span>'
          + '<div><b>' + esc(p.name || 'Programma') + '</b><small>' + esc(p.shuffle ? 'Casuale' : sndName(p.suono || 'rain')) + ' · ' + esc(sndProgDescr(p)) + '</small></div>'
          + '<button type="button" class="switch' + (paused ? '' : ' on') + '" onclick="event.stopPropagation();sndProgToggle(' + i + ')" aria-label="Attivo"></button>'
          + '<button type="button" class="snd-prog-x" onclick="event.stopPropagation();sndProgElimina(' + i + ')" aria-label="Elimina">✕</button></div>';
      }).join('')
      : '')
    + '<button type="button" class="snd-prog-nuovo" onclick="if(typeof newBlock===\'function\')newBlock(\'sound\')">＋ Nuovo programma</button></div>';
}
/* la riga sotto al nome: quando parte */
function sndProgDescr(p){
  if (p.type === 'app'){
    const a = (p.apps || []).length, s = (p.sites || []).length;
    const pezzi = []; if (a) pezzi.push(a === 1 ? '1 app' : a + ' app'); if (s) pezzi.push(s === 1 ? '1 sito' : s + ' siti');
    return 'Mentre usi ' + (pezzi.join(' e ') || 'un\u2019app');
  }
  return (typeof describeProgram === 'function' ? describeProgram(p) : '').replace(/\s*·\s*\d+ app.*$/, '');
}
/* l'editor dei programmi, in versione suoni: via la lista di blocco, dentro la scelta del suono */
function sndEditorMode(on){
  const ed = document.getElementById('s-editor'); if (!ed) return;
  const da = document.getElementById('edPlaceBox');
  let n = da ? da.nextElementSibling : null;
  while (n && !(n.tagName === 'BUTTON' && n.classList.contains('cta'))){
    if (n.id !== 'edSoundBox') n.classList.toggle('snd-nascosto', !!on);
    n = n.nextElementSibling;
  }
  let box = document.getElementById('edSoundBox');
  if (!box){
    box = document.createElement('div'); box.id = 'edSoundBox';
    const cta = ed.querySelector('button.cta');
    if (cta) ed.insertBefore(box, cta); else ed.appendChild(box);
  }
  box.hidden = !on;
  /* la lista di blocco diventa la lista delle app e dei siti che fanno partire il suono */
  const app = !!(on && typeof DRAFT !== 'undefined' && DRAFT && DRAFT.type === 'app');
  let trig = document.getElementById('edSndTrig');
  const rApp = ed.querySelector('.setrow[onclick*="openBlocklist(\'app\')"], .setrow[onclick*="s-blocklist"]'), rWeb = ed.querySelector('.setrow[onclick*="openBlocklist(\'web\')"]');
  if (!trig && rApp){ trig = document.createElement('div'); trig.id = 'edSndTrig'; trig.className = 'sect'; trig.style.marginTop = '14px'; trig.innerHTML = '<b>App e siti</b><span style="font:600 11px var(--font-body);color:var(--muted)">il suono parte quando li apri</span>'; rApp.parentNode.insertBefore(trig, rApp); }
  if (trig){ trig.hidden = !app; trig.classList.remove('snd-nascosto'); }
  [rApp, rWeb].forEach(function(r){ if (r && on) r.classList.toggle('snd-nascosto', !app); });
  const bl = document.querySelector('#s-blocklist h2'); if (bl) bl.textContent = app ? 'App e siti del programma' : 'Lista di blocco';
  if (!on) return;
  const cur = (typeof DRAFT !== 'undefined' && DRAFT && DRAFT.suono) || 'rain';
  const casuale = !!(DRAFT && DRAFT.shuffle);
  box.innerHTML = '<div class="sect" style="margin-top:14px"><b>Suono</b><span style="font:600 11px var(--font-body);color:var(--muted)">parte da solo</span></div>'
    + sndSceltaHtml(cur, 'sndEditorScegli') + '<div class="snd-scelta" hidden>' + [].map(function(x){ return '<button type="button" class="' + (x.id === cur ? 'on' : '') + '" onclick="sndEditorScegli(\'' + x.id + '\')"><span>' + x.ico + '</span>' + esc(x.n) + '</button>'; }).join('') + '</div>'
    + '<div class="setrow" onclick="sndEditorCasuale()"><span>🔀</span><b>Riproduzione casuale</b><button type="button" class="switch' + (casuale ? ' on' : '') + '" onclick="event.stopPropagation();sndEditorCasuale()" aria-label="Riproduzione casuale"></button></div>'
    + '<p class="hintline" style="padding:6px 2px 0">' + (casuale ? 'Parte dal suono scelto, poi ogni 10 minuti passa da solo a un altro, a caso.' : 'Il suono scelto resta lo stesso finché il programma è attivo.') + ' Lo trovi nel lettore della tendina del telefono: lì lo metti in pausa o lo fermi.</p>';
}
function sndEditorCasuale(){ if (typeof DRAFT !== 'undefined' && DRAFT){ DRAFT.shuffle = !DRAFT.shuffle; sndEditorMode(true); } }
function sndEditorScegli(id){ if (typeof DRAFT !== 'undefined' && DRAFT){ DRAFT.suono = id; sndEditorMode(true); try{ sndWarm(id); }catch(_){ } } }
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.snd-nascosto{display:none !important}',
    '.snd-prog-box{border:1px solid var(--line);border-radius:20px;padding:16px;margin:6px 0 18px;background:var(--card,#fff)}body.dark .snd-prog-box{background:#141C2C;border-color:#25314A}',
    '.snd-prog-i{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;margin-left:8px;padding:0;vertical-align:2px;border:1.5px solid var(--blue,#0075E3);border-radius:50%;background:none;color:var(--blue,#0075E3);cursor:pointer}body.dark .snd-prog-i{border-color:#8CC6FF;color:#8CC6FF}',
    '.snd-prog-t{text-align:center;margin-bottom:6px}.snd-prog-t b{display:block;font:800 17px var(--font-display);color:var(--navy)}body.dark .snd-prog-t b{color:#fff}.snd-prog-t small{display:block;margin:6px auto 4px;max-width:34ch;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.snd-prog{display:flex;align-items:center;gap:10px;padding:12px 0;border-bottom:1px solid var(--line);cursor:pointer}.snd-prog.off{opacity:.55}.snd-prog .ico{font-size:22px}.snd-prog > div{flex:1;min-width:0}.snd-prog b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .snd-prog b{color:#fff}.snd-prog small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.snd-prog-x{border:0;background:transparent;color:var(--muted);font-size:14px;cursor:pointer;padding:6px}',
    '.snd-prog-nuovo{display:block;width:100%;margin-top:12px;border:0;border-radius:99px;background:#0075E3;color:#fff;padding:13px;font:800 14px var(--font-body);cursor:pointer}',
    '.snd-scelta{display:flex;flex-wrap:wrap;gap:8px}.snd-scelta button{display:flex;align-items:center;gap:6px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy);padding:9px 13px;font:600 13px var(--font-body);cursor:pointer}body.dark .snd-scelta button{background:#141C2C;color:#fff;border-color:#25314A}',
    '.snd-scelta button.on,body.dark .snd-scelta button.on{border-color:#0075E3;background:#0075E3;color:#fff}'
  ].join('\n');
  document.head.appendChild(st);
  /* all'avvio il motore riceve i programmi salvati (dopo una reinstallazione o un ripristino) */
  document.addEventListener('DOMContentLoaded', function(){ setTimeout(function(){ try{ const l = sndProgrammi(); if (l.length) sndProgrammiSalva(l); }catch(_){ } }, 7000); });
})();
function sndListaHtml(){
  const cr = SND.credits || {};
  const groups = SOUNDS.map(g => {
    const items = g.items.filter(s => cr[s.id]);
    if (!items.length) return '';
    const chiuso = id => (typeof scrSuonoChiuso === 'function') && scrSuonoChiuso(id);
    return '<div class="snd-g"><h5>' + g.g + '</h5>'
      + items.map(s => chiuso(s.id)
        ? '<button type="button" class="snd-row lock" onclick="toast(\'Lo trovi in una mystery box d\\u2019oro, dopo una sessione lunga\')">'
          + '<span class="ico">' + s.ico + '</span><div><b>' + s.n + '</b><small>In una mystery box</small></div><span class="play">\ud83d\udd12</span></button>'
        : '<button type="button" class="snd-row' + (SND.id === s.id ? ' on' : '') + '" ontouchstart="sndWarm(\'' + s.id + '\')" onmousedown="sndWarm(\'' + s.id + '\')" onclick="sndPlay(\'' + s.id + '\')">'
          + '<span class="ico">' + s.ico + '</span><div><b>' + s.n + '</b><small>' + s.d + '</small></div>'
          + '<span class="play">' + (SND.loading === s.id ? '…' : (SND.id === s.id && SND.playing !== false ? '❚❚' : '▶')) + '</span></button>').join('')
      + '</div>';
  }).join('');
  const names = Object.keys(cr).map(k => cr[k].author).filter((v, i, a) => a.indexOf(v) === i);
  return '<div class="snd-vol"><span>🔈</span><input type="range" min="0" max="100" value="' + Math.round(SND.vol * 100) + '" oninput="sndVolume(this.value/100)"><span>🔊</span></div>'
    /* 0.9.308: in cima le tracce nuove della libreria della web app (effetti.js), che arrivano da sole ogni notte */
    + (typeof fxMusicaHtml === 'function' ? fxMusicaHtml() : '')
    + (groups || '<p class="snd-note">I suoni non sono ancora stati caricati in questa versione.</p>')
    /* Niente muro di testo: chi sceglie un suono vuole sentirlo, non leggere come funziona.
       I nomi di chi le ha registrate restano perche' la decenza li chiede, in piccolo. */
    + (names.length ? '<p class="snd-note">Registrazioni di ' + esc(names.join(', ')) + ' \u00b7 Freesound, CC0.</p>' : '');
}

document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia'){ sndCredits().then(sndPaint); sndPrefetch(); } });
document.addEventListener('fl:screen', function(e){
  if (e.detail !== 's-fullfocus') return;
  try{ const p = (typeof ffPref === 'function') ? ffPref() : null; if (p && p.sound) sndWarm(p.sound); }catch(_){ }
  sndPrefetch();
});
(function(){
  try{ SND.vol = Math.max(0, Math.min(1, parseFloat(localStorage.getItem(SND_KEY + '_vol')) || 0.5)); }catch(_){ }
  try{ localStorage.removeItem(SND_KEY + '_open'); }catch(_){ }
})();

(function(){
  const css = [
    '#sndWrap{margin:26px 0 0}',
    '.snd-head{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;border:0;border-radius:22px;background:linear-gradient(135deg,#0B2A63,#001E44);color:#fff;padding:20px 18px;cursor:pointer;text-align:left;box-shadow:0 10px 24px rgba(0,30,68,.2)}',
    'body.dark .snd-head{background:linear-gradient(135deg,#14305E,#0B1F44);color:#fff}.snd-head b{color:#fff}.snd-head small{color:#BFD3EC!important}.snd-head svg path{stroke:#BFD3EC}',
    '.snd-head .ico{font-size:22px;flex:none}',
    /* 0.9.347, Andrea: "l'emoji della musica e' scura su sfondo scuro, non si vede: un'icona con contrasto, e il testo al centro del pannello,
       con l'icona centrata". Le cuffie bianche in un cerchio azzurro, poi titolo e sottotitolo, tutto al centro; la freccia resta a destra */
    '.snd-head{position:relative;flex-direction:column!important;justify-content:center;gap:10px!important;text-align:center!important;padding:22px 44px!important}',
    '.snd-head .snd-ico{width:52px;height:52px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#3F9FF4,#0075E3);box-shadow:0 0 0 5px rgba(140,198,255,.18),0 8px 18px rgba(0,117,227,.45)}',
    '.snd-head > div{text-align:center}.snd-head > svg{position:absolute;right:16px;top:50%;transform:translateY(-50%)}',
    '.snd-head > div{flex:1;min-width:0}',
    '.snd-head b{display:block;font:800 17px var(--font-display);font-style:italic}',
    '.snd-head small{display:block;margin-top:3px;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.snd-head .fl-arrdown{flex:none;width:18px;height:18px;transition:transform .25s}',
    '#sndWrap.open .snd-head .fl-arrdown{transform:rotate(180deg)}',
    '.snd-vol{display:flex;align-items:center;gap:10px;margin:14px 0 6px;font-size:15px}',
    '.snd-vol input{flex:1;--rc:var(--blue,#006FCF);--rt:#DCE6F5}',
    'body.dark .snd-vol input{--rt:#2E2E36}',
    '.snd-g h5{margin:18px 0 6px;font:700 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--blue,#006FCF)}',
    '.snd-row{display:flex;align-items:center;gap:12px;width:100%;border:1px solid var(--line);border-radius:14px;background:#fff;color:var(--navy);padding:13px 14px;margin-top:8px;cursor:pointer;text-align:left}',
    'body.dark .snd-row{background:#141419;border-color:#232328;color:#fff}',
    '.snd-row.on{background:#F2F8FF;box-shadow:inset 0 0 0 1px var(--blue,#006FCF)}',
    'body.dark .snd-row.on{background:#16233A}',
    '.snd-row .ico{font-size:22px;flex:none}',
    '.snd-row > div{flex:1;min-width:0}',
    '.snd-row b{display:block;font:600 15px var(--font-body)}',
    '.snd-row small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.snd-row .play{flex:none;font-size:15px;color:var(--blue,#006FCF)}',
    '.snd-stop{width:100%;margin-top:16px;border:1px solid var(--line);border-radius:99px;background:transparent;color:var(--navy);padding:13px;font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .snd-stop{border-color:#3A3A40;color:#fff}',
    '.snd-note{margin:16px 0 0;font:500 12px/1.55 var(--font-body);color:var(--muted)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();

/* La tendina puo' mettere in pausa o fermare: la pagina se ne accorge e aggiorna il pulsante
   sulla riga, altrimenti resta a mostrare due barrette per un suono che non suona piu'. */
try{
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.addListener) NATIVE.addListener('sound', function(ev){
    if (!ev) return;
    /* il lettore dei suoni (suoni-start.js) ha la sua lista: non e' il suono singolo di questa pagina */
    if (ev.lista){
      try{ if (typeof suoNativoEvento === 'function') suoNativoEvento(ev); }catch(_){ }
      /* un suono scelto in un programma: la stessa lista del servizio, di una voce sola */
      if (sndSpeciale(SND.id) && (typeof SUO === 'undefined' || !SUO.sess)){ if (ev.fermo){ SND.id = 'none'; SND.playing = false; } else SND.playing = !!ev.playing; sndPaint(); }
      return;
    }
    /* Un errore dal servizio non deve cancellare la scelta dell'utente: il suono resta quello,
       cambia solo chi lo suona. La rete di sicurezza in sndPlay fa il resto. */
    /* L'errore si DICE. Restava in console — cioe' da nessuna parte, per chi usa un
       telefono — e l'unico sintomo era il silenzio: il difetto piu' difficile da segnalare
       che esista. La scialuppa parte lo stesso; qui si spiega solo perche' il lettore nella
       tendina non c'e'. */
    if (ev.error){
      console.warn('suono: ' + ev.error);
      SND.nativeOk = false;
      if (!SND.avvisato){
        SND.avvisato = true;
        try{ toast('Il lettore di sistema non è partito: suono dall’app'); }catch(_){ }
      }
      sndPaint();
      return;
    }
    SND.id = ev.id || 'none';
    SND.playing = !!ev.playing;
    SND.nativeOk = !!(ev.id && ev.playing);
    if (SND.nativeOk) sndWebOff(1200);
    try{ localStorage.setItem(SND_KEY, SND.id); }catch(_){ }
    sndPaint();
  });
}catch(_){ }
