/* ===========================================================================================
   LA PAGINA DELLE DECISIONI (0.9.351)

   Andrea: "decisioni vuol dire tutto e niente. Voglio una pagina delle decisioni come quella
   dell'umore, con il grafico degli ultimi 7 e 30 giorni; ci si arriva da 'Vedi quali e a che
   ora' e dalla riga delle decisioni nella scheda La tua identita' delle statistiche della
   partita. E ogni voto al vecchio te o al nuovo te deve dire perche' e' stato dato. E deve
   dire quanto ci metti a scrivere alla tua AI, e il tempo medio per ogni decisione."

   I dati sono quelli che l'app ha gia':
   - le decisioni di ogni giorno: collo.js (fl_decisioni_giorni, cloDecisioniLista(giorno));
   - i voti della partita, ognuno con il suo motivo: partita-stats.js (pstDati().eventi);
   - il tempo per scrivere alla tua AI: collo.js (fl_ai_tempi, cloAiMedia).
   La grafica riusa quella della pagina dell'umore (classi umi-, umore.js).
   =========================================================================================== */
const DCS = { giorni: 7, giorno: 0 };
const DCS_IND = '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.5 4.5L7 10l5.5 5.5"/></svg>';
registerScreen('s-decisioni',
  '<div class="topbar"><button class="iconbtn" onclick="if(typeof flIndietro===\'function\')flIndietro();else goId(\'s-home\')" aria-label="Indietro">' + DCS_IND + '</button><b class="blk-title">Le tue decisioni</b></div>'
  + '<div class="al-page" id="dcsBody"></div><div class="spacer"></div>', { back: 's-home' });

function dcsApri(giorno){ DCS.giorno = giorno || 0; goId('s-decisioni'); dcsPaint(); try{ const s = document.getElementById('s-decisioni'); if (s) s.scrollTop = 0; }catch(_){ } }
function dcsGiorni(n){ DCS.giorni = n; DCS.giorno = 0; dcsPaint(); }
function dcsVaiGiorno(i){ DCS.giorno = i; dcsPaint(); const c = document.getElementById('dcsLista'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
/* 0.9.351: "Vedi quali e a che ora" e ogni altra porta alle decisioni aprono la pagina, non piu' il foglio */
function cloDecisioniApri(){ dcsApri(0); }

function dcsK(t){ return (typeof cloDecKey === 'function') ? cloDecKey(t) : ''; }
function dcsG0(i){ const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); return d.getTime(); }
function dcsOra(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function dcsEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function dcsDurata(sec){ sec = Math.round(sec); if (sec < 60) return sec + (sec === 1 ? ' secondo' : ' secondi'); const m = Math.round(sec / 60); if (m < 60) return m + (m === 1 ? ' minuto' : ' minuti'); const h = Math.floor(m / 60), r = m % 60; return h + (h === 1 ? ' ora' : ' ore') + (r ? ' e ' + r + ' minuti' : ''); }
/** quante decisioni in un giorno: oggi si contano dal vivo, gli altri giorni dallo storico */
function dcsN(i){
  if (i === 0 && typeof cloDecisioniOggi === 'function'){ try{ return cloDecisioniOggi(); }catch(_){ } }
  const st = (typeof cloDecStoria === 'function') ? cloDecStoria() : {};
  return +st[dcsK(dcsG0(i))] || 0;
}
/** il tempo medio fra una decisione e la successiva, in un giorno (servono almeno due decisioni con l'ora) */
function dcsTraDecisioni(l){
  const t = l.map(function(x){ return x.at; }).filter(Boolean).sort(function(a, b){ return a - b; });
  if (t.length < 2) return null;
  return (t[t.length - 1] - t[0]) / (t.length - 1) / 1000;
}
function dcsPaint(){
  const host = document.getElementById('dcsBody'); if (!host) return;
  const n = DCS.giorni;
  const G = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
  const giorni = []; for (let i = n - 1; i >= 0; i--) giorni.push({ i: i, d: new Date(dcsG0(i)), v: dcsN(i) });
  const max = Math.max(1, Math.max.apply(null, giorni.map(function(g){ return g.v; })));
  const tot = giorni.reduce(function(a, g){ return a + g.v; }, 0), con = giorni.filter(function(g){ return g.v > 0; }).length;
  const serie = (typeof cloDecSerie === 'function') ? cloDecSerie() : 0;
  let grafico;
  if (n === 7){
    grafico = '<div class="umi-c7 dcs-c7">' + giorni.map(function(g, k){
      const h = g.v ? Math.max(14, g.v / max * 100) : 0;
      return '<button type="button" class="umi-col dcs-col' + (g.i === DCS.giorno ? ' on' : '') + '" onclick="dcsVaiGiorno(' + g.i + ')" aria-label="Le decisioni di ' + G[g.d.getDay()] + '"><div class="umi-track">' + (g.v ? '<div class="umi-fill dcs-fill" data-h="' + h + '" style="--d:' + (k * 70) + 'ms"><span>' + g.v + '</span></div>' : '') + '</div><small>' + (g.i === 0 ? 'Oggi' : G[g.d.getDay()]) + '</small></button>';
    }).join('') + '</div>';
  } else {
    const W = 300, H = 160, x0 = 22, x1 = 292, y = function(v){ return 14 + (1 - v / max) * 120; }, x = function(k){ return x0 + k * (x1 - x0) / (n - 1); };
    let svg = '';
    [0, .5, 1].forEach(function(f){ const v = Math.round(max * f); svg += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + y(v) + '" y2="' + y(v) + '" class="umi-griglia"/><text x="4" y="' + (y(v) + 4) + '" class="umi-asse">' + v + '</text>'; });
    [0, 7, 14, 21, 28].forEach(function(k){ if (k < n) svg += '<text x="' + x(k) + '" y="' + (H - 2) + '" class="umi-asse c">' + giorni[k].d.getDate() + '</text>'; });
    svg += '<polyline class="umi-linea" points="' + giorni.map(function(g, k){ return x(k).toFixed(1) + ',' + y(g.v).toFixed(1); }).join(' ') + '"/>';
    giorni.forEach(function(g, k){ if (g.v) svg += '<circle cx="' + x(k).toFixed(1) + '" cy="' + y(g.v).toFixed(1) + '" r="4.5" class="umi-punto dcs-punto"/>'; });
    grafico = '<svg class="umi-c30" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Le decisioni degli ultimi 30 giorni">' + svg + '</svg>';
  }
  /* le decisioni del giorno scelto, con l'ora */
  const l = (typeof cloDecisioniLista === 'function') ? cloDecisioniLista(dcsG0(DCS.giorno)) : [];
  const nomeG = DCS.giorno === 0 ? 'oggi' : (DCS.giorno === 1 ? 'ieri' : G[new Date(dcsG0(DCS.giorno)).getDay()].toLowerCase() + ' ' + new Date(dcsG0(DCS.giorno)).getDate());
  const ai = (typeof cloAiMedia === 'function') ? cloAiMedia() : null;
  const tra = dcsTraDecisioni(l);
  let part = null; try{ part = DCS.giorno === 0 && typeof cloPartenzaMin === 'function' ? cloPartenzaMin() : null; }catch(_){ part = null; }
  /* i voti della partita, ognuno con il suo perche' */
  let voti = [];
  try{ if (typeof pstDati === 'function'){ const D = pstDati(n); voti = D.eventi.slice().sort(function(a, b){ return b.at - a.at; }).slice(0, 25); } }catch(_){ voti = []; }
  const vo = voti.filter(function(e){ return e.chi === 'old'; }).reduce(function(a, e){ return a + e.n; }, 0), vn = voti.filter(function(e){ return e.chi === 'neo'; }).reduce(function(a, e){ return a + e.n; }, 0);
  const motivo = function(e){ const t = String(e.m || '').trim(); return t ? t.charAt(0).toUpperCase() + t.slice(1) : (e.chi === 'neo' ? 'Una mossa verso il sogno' : 'Una mossa del vecchio te'); };
  const quando = function(t){ const k = dcsK(t); return (k === dcsK(Date.now()) ? 'oggi' : new Date(t).getDate() + '/' + (new Date(t).getMonth() + 1)) + ', ' + dcsOra(t); };
  host.innerHTML = '<div class="umi-tabs"><button type="button" class="' + (n === 7 ? 'on' : '') + '" onclick="dcsGiorni(7)">7 giorni</button><button type="button" class="' + (n === 30 ? 'on' : '') + '" onclick="dcsGiorni(30)">30 giorni</button></div>'
    + '<div class="umi-card umi-centro"><h4>Le decisioni di ogni giorno</h4>' + (n === 7 ? '<small class="umi-range">Tocca un giorno per vedere quali decisioni hai preso</small>' : '')
    + grafico
    + '<div class="umi-boxes"><div class="umi-box blu"><small>Decisioni in ' + n + ' giorni</small><b>' + tot + '</b></div>'
    + '<div class="umi-box rosa"><small>' + (serie ? 'Giorni di fila con decisioni' : 'Giorni con almeno una decisione') + '</small><b>' + (serie || con) + '</b></div></div></div>'
    /* i tempi */
    + '<div class="umi-card umi-centro"><h4>Quanto ci metti a decidere</h4><div class="dcs-tempi">'
    +   '<div><span aria-hidden="true">💬</span><b>' + (ai ? dcsDurata(ai) : 'Non ancora misurato') + '</b><small>per scrivere e mandare un messaggio alla tua AI</small></div>'
    +   '<div><span aria-hidden="true">⏱️</span><b>' + (tra !== null ? dcsDurata(tra) : 'Servono due decisioni') + '</b><small>in media fra una decisione e l’altra, ' + dcsEsc(nomeG) + '</small></div>'
    +   (part !== null ? '<div><span aria-hidden="true">🌅</span><b>' + (part < 0 ? 'Ancora nessuna' : dcsDurata(part * 60)) + '</b><small>' + (part < 0 ? 'prima mossa dopo la sveglia' : 'dalla sveglia alla prima mossa') + '</small></div>' : '')
    + '</div></div>'
    /* l'elenco del giorno */
    + '<div class="umi-card" id="dcsLista"><h4 class="dcs-h">Le decisioni di ' + dcsEsc(nomeG) + '</h4>'
    + (l.length ? '<div class="dcs-l">' + l.map(function(x){ return '<div class="dcs-r"><span class="dcs-o">' + (x.at ? dcsOra(x.at) : 'in giornata') + '</span><span class="dcs-i" aria-hidden="true">' + x.ico + '</span><p>' + dcsEsc(x.t) + '</p></div>'; }).join('') + '</div>'
      : '<p class="umi-p">' + (DCS.giorno === 0 ? 'Oggi nessuna decisione ancora. Una sessione di Full Focus o una tappa della mappa sono la prima.' : 'In questo giorno non risultano decisioni.') + '</p>')
    + '</div>'
    /* i voti della partita */
    + '<div class="umi-card"><h4 class="dcs-h">I voti della partita, uno per uno</h4><p class="dcs-sotto">Ogni decisione dà un voto al nuovo te o al vecchio te. Qui vedi chi l’ha preso e perché.</p>'
    + '<div class="dcs-score"><div class="old"><b>' + vo + '</b><small>Vecchio te</small></div><div class="neo"><b>' + vn + '</b><small>Nuovo te</small></div></div>'
    + (voti.length ? '<div class="dcs-l">' + voti.map(function(e){ return '<div class="dcs-v ' + e.chi + '"><b>+' + e.n + '</b><p>' + dcsEsc(motivo(e)) + '<small>' + (e.chi === 'neo' ? 'Al nuovo te' : 'Al vecchio te') + ' · ' + quando(e.at) + '</small></p></div>'; }).join('') + '</div>'
      : '<p class="umi-p">In questo periodo nessuno ha ancora preso voti.</p>')
    + '</div>'
    + '<div class="umi-priv">🛡️ Questa pagina è visibile solo a te.</div>';
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ host.querySelectorAll('.umi-fill').forEach(function(f){ f.style.height = f.getAttribute('data-h') + '%'; }); }); });
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.dcs-col{border:0;background:none;padding:0;cursor:pointer;font:inherit}.dcs-col.on small{color:#0075E3;font-weight:800}body.dark .dcs-col.on small{color:#8CC6FF}',
    '.dcs-fill{background:linear-gradient(180deg,#3F9FF4,#0075E3)!important}.dcs-fill span{font:800 13px var(--font-body);color:#fff}.dcs-punto{fill:#0075E3;stroke:#fff;stroke-width:2}',
    '.dcs-tempi{display:flex;flex-direction:column;gap:14px;margin-top:16px;text-align:left}.dcs-tempi > div{display:grid;grid-template-columns:36px 1fr;column-gap:12px;align-items:center;padding:14px;border-radius:16px;background:var(--bg,#F0FBFF)}.dcs-tempi span{grid-row:1/3;font-size:24px;text-align:center}.dcs-tempi b{font:800 16px var(--font-display);color:var(--navy)}.dcs-tempi small{font:500 13px/1.4 var(--font-body);color:var(--muted)}',
    'body.dark .dcs-tempi > div{background:#12203A}body.dark .dcs-tempi b{color:#fff}',
    '.dcs-h{margin:0 0 14px;text-align:center}.dcs-sotto{margin:-4px auto 18px;max-width:32ch;text-align:center;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    '.dcs-l{display:flex;flex-direction:column;gap:10px}.dcs-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--bg,#F0FBFF);border:1px solid var(--line)}.dcs-o{flex:none;min-width:54px;padding:4px 8px;border-radius:99px;background:#0075E3;color:#fff;font:800 12px var(--font-body);text-align:center}.dcs-i{flex:none;font-size:20px}.dcs-r p{flex:1;min-width:0;text-align:left;margin:0;font:600 14px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .dcs-r{background:#12203A;border-color:#22345A}body.dark .dcs-r p{color:#fff}',
    '.dcs-score{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 16px}.dcs-score > div{padding:12px;border-radius:16px;text-align:center}.dcs-score .old{background:rgba(230,57,70,.1)}.dcs-score .neo{background:rgba(0,117,227,.1)}.dcs-score b{display:block;font:900 28px/1 var(--font-display)}.dcs-score .old b{color:#E63946}.dcs-score .neo b{color:#0075E3}.dcs-score small{font:700 12.5px var(--font-body);color:var(--muted)}',
    '.dcs-v{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--bg,#F0FBFF)}.dcs-v > b{flex:none;min-width:34px;font:900 16px var(--font-display)}.dcs-v.neo > b{color:#0075E3}.dcs-v.old > b{color:#E63946}.dcs-v p{margin:0;font:600 14px/1.35 var(--font-body);color:var(--navy)}.dcs-v small{display:block;margin-top:2px;font:600 12px var(--font-body);color:var(--muted)}',
    'body.dark .dcs-v{background:#12203A}body.dark .dcs-v p{color:#fff}body.dark .dcs-score .neo b{color:#8CC6FF}body.dark .dcs-score .old b{color:#FF8A94}'
  ].join('\n');
  document.head.appendChild(st);
})();
