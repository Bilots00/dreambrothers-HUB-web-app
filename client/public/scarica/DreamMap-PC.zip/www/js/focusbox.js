/* ---------------------------------------------------------------------------------------
   LA FOCUS BOX — il tabellone delle notti nella scatola

   Andrea ha una scatola con un timer: la sera ci chiude dentro il telefono e la scatola si
   apre da sola la mattina dopo, a un'ora che decide lui.

   LA REGOLA. Fra l'ora in cui vai a letto e l'ora in cui la scatola si apre il telefono non
   deve essere usato. Se nel frattempo non e' stato toccato, la notte era nella scatola: un
   punto. Le due ore si scelgono nelle impostazioni del pannello (tre puntini, ingranaggio).

   SOLO IL MOTORE VERO DEL TELEFONO. Il Report puo' mostrare i numeri del computer, o di
   tutti e due insieme: per farlo, i dati del telefono vengono sostituiti da una
   ricostruzione, e in quella il tempo del computer di un giorno passato e' spalmato dalle otto
   in poi. La finestra fino alle dieci ne conteneva sempre un'ora circa — «stanotte l'hai
   usato 60 minuti», qualunque fosse l'ora del letto. Questo pannello chiede al telefono e
   basta, qualunque sorgente sia scelta nel Report.

   Il tempo di schermo lo sa solo il telefono: sul computer il pannello non si mostra. Per
   adesso lo vede solo chi sviluppa l'app.
   --------------------------------------------------------------------------------------- */

const FB_KEY = 'fl_focusbox';
const FB_TOLLERANZA = 3 * 60000;   // tre minuti di schermo acceso non sono «usare il telefono»
const FB_TFS = [[7, 'Ultimi 7 giorni'], [30, 'Ultimo mese'], [365, 'Ultimo anno'], [0, 'Da sempre']];
const FB_V = 'v3';                  // cambia quando cambia il modo di contare: le notti vecchie si rileggono

function fbStato(){
  let s = null;
  try{ s = JSON.parse(localStorage.getItem(FB_KEY) || 'null'); }catch(_){ s = null; }
  s = Object.assign({ notti: {}, lettoMin: 0, apreMin: 600, tf: 7 }, s || {});
  /* le ore del letto di prima erano ore intere: diventano minuti */
  if (typeof s.letto === 'number' && s.lettoMin === 0 && s.letto > 0){ s.lettoMin = s.letto * 60; delete s.letto; }
  return s;
}
function fbSalva(s){ try{ localStorage.setItem(FB_KEY, JSON.stringify(s)); }catch(_){ } return s; }
function fbMezzanotte(off){ const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime() - (off || 0) * 86400000; }
function fbChiave(ts){ const d = new Date(ts); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function fbOra(ts){ const d = new Date(ts); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function fbMinTxt(m){ m = ((+m % 1440) + 1440) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); }
function fbTf(){ const v = +fbStato().tf; return FB_TFS.some(function(x){ return x[0] === v; }) ? v : 7; }
function fbTfLabel(){ const v = fbTf(); return (FB_TFS.filter(function(x){ return x[0] === v; })[0] || FB_TFS[0])[1]; }

/** Questo tabellone ha senso qui? Solo sul telefono, e per ora solo per chi sviluppa. */
function fbVisibile(){
  try{
    if (typeof mwQuiComputer === 'function' && mwQuiComputer()) return false;
    if (typeof mwMotoreVero === 'function' && !mwMotoreVero()) return false;
    return (typeof FL_DEBUG_PREMIUM !== 'undefined') && !!FL_DEBUG_PREMIUM;
  }catch(_){ return false; }
}

/** Il motore del TELEFONO, anche quando il Report guarda il computer. */
async function fbNativo(metodo, a){
  const f = (typeof MW_NATIVO !== 'undefined' && MW_NATIVO && MW_NATIVO[metodo]) ? MW_NATIVO[metodo]
    : ((typeof NATIVE !== 'undefined' && NATIVE && NATIVE[metodo]) ? NATIVE[metodo].bind(NATIVE) : null);
  if (!f) return null;
  /* UN TETTO DI TRE SECONDI. Una risposta che non arriva teneva il pannello su «Leggo le
     notti» per sempre: adesso una notte che non risponde resta «non si sa», e il resto va avanti. */
  try{ return await Promise.race([f(a), new Promise(function(r){ setTimeout(function(){ r(null); }, 3000); })]); }
  catch(_){ return null; }
}

/** La finestra della notte che finisce nel giorno `ds`: dall'ora del letto all'apertura. */
function fbFinestra(ds, s){
  s = s || fbStato();
  const letto = s.lettoMin, apre = s.apreMin;
  const inizio = letto >= 720 ? ds - 86400000 + letto * 60000 : ds + letto * 60000;
  return { da: inizio, a: ds + apre * 60000 };
}

/**
 * Com'e' andata la notte che finisce nel giorno `ds`.
 * 'si' punto, 'no' telefono usato, 'corso' non e' ancora finita, '?' il telefono non lo sa.
 *
 * <p>Una notte senza un minuto di schermo puo' voler dire due cose: telefono nella scatola,
 * oppure un giorno cosi' vecchio che Android ne ha buttato via la cronologia. Per non dare
 * punti a giorni che nessuno ricorda si chiede anche se quel giorno il telefono e' stato
 * usato: se non c'e' nessuna traccia, la notte resta «non si sa».</p>
 *
 * <p>Le notti chiuse restano scritte qui, con le ore con cui sono state lette: cambiare le
 * ore cambia la domanda, e allora si rilegge.</p>
 */
async function fbNotte(ds, s){
  s = s || fbStato();
  const k = fbChiave(ds) + '@' + s.lettoMin + '-' + s.apreMin + '@' + FB_V;
  const f = fbFinestra(ds, s);
  const chiusa = Date.now() >= f.a;
  if (chiusa && s.notti[k]) return s.notti[k];
  const r = await fbNativo('getScreenTimeRange', { from: f.da, to: Math.min(f.a, Date.now()), bucket: 'none' });
  if (!r || r.granted === false) return { st: '?', ms: -1 };
  const ms = +r.ms || 0;
  let st;
  if (ms > FB_TOLLERANZA) st = 'no';
  else if (!chiusa) st = 'corso';
  else {
    const rep = await fbNativo('getDayReport', { dayStart: ds });
    st = (rep && rep.granted && (rep.firstUse || 0) > 0) ? 'si' : '?';
  }
  const esito = { st: st, ms: ms };
  if (chiusa){
    const s2 = fbStato();
    s2.notti[k] = esito;
    fbSalva(s2);
  }
  return esito;
}

/** I giorni del periodo scelto, dal piu' recente. */
function fbGiorniPeriodo(){
  const tf = fbTf();
  const oggi = fbMezzanotte(0);
  let giorni = tf || 400;
  if (!tf){
    const primo = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0;
    if (primo) giorni = Math.min(400, Math.max(1, Math.floor((oggi - primo) / 86400000) + 1));
  }
  const out = [];
  for (let off = 0; off < giorni; off++) out.push(oggi - off * 86400000);
  return out;
}
/** La notte dalla cache, senza chiedere niente al telefono; null se non c'e'. */
function fbNotteCache(ds, s){
  const k = fbChiave(ds) + '@' + s.lettoMin + '-' + s.apreMin + '@' + FB_V;
  return s.notti[k] || null;
}

/** I conti del periodo, da notti gia' lette. Oggi non ancora deciso non rompe la serie. */
function fbConti(notti, tf){
  let serie = 0;
  for (let i = 0; i < notti.length; i++){
    const n = notti[i];
    if (n.st === 'corso' || (i === 0 && n.st === '?')) continue;
    if (n.st === 'si'){ serie++; continue; }
    break;
  }
  let migliore = 0, cur = 0, punti = 0, contate = 0;
  for (let i = notti.length - 1; i >= 0; i--){
    const n = notti[i];
    if (n.st === 'si'){ cur++; punti++; contate++; if (cur > migliore) migliore = cur; }
    else if (n.st === 'no'){ cur = 0; contate++; }
    else if (n.st === '?' && i > 0){ cur = 0; }
  }
  return { serie: serie, migliore: migliore, punti: punti, contate: contate, notti: notti, tf: tf };
}

/**
 * Le notti del periodo. `soloCache`: niente telefono, solo quello che e' gia' scritto — serve a
 * ridisegnare SUBITO quando si cambia periodo. Poi le notti mancanti si leggono sei alla volta:
 * un anno intero, una notte dopo l'altra, erano minuti.
 */
async function fbSerie(soloCache){
  const s = fbStato();
  const tf = fbTf();
  const notti = fbGiorniPeriodo().map(function(ds){
    const c = fbNotteCache(ds, s);
    return { ds: ds, st: c ? c.st : '?', ms: c ? c.ms : -1, cache: !!c };
  });
  if (!soloCache){
    const mancano = notti.filter(function(n, i){ return !n.cache || i === 0; });
    for (let i = 0; i < mancano.length; i += 6){
      await Promise.all(mancano.slice(i, i + 6).map(async function(n){
        const e = await fbNotte(n.ds, s);
        n.st = e.st; n.ms = e.ms;
      }));
    }
  }
  return fbConti(notti, tf);
}

/* ---- la settimana del calendario, da lunedi' (o da domenica, se cosi' e' impostato) ---- */
function fbSettimana(notti){
  const inizio = (typeof flWeekStart === 'function') ? flWeekStart() : 1;
  const oggi = fbMezzanotte(0);
  const dow = new Date(oggi).getDay();
  const primo = oggi - ((dow - inizio + 7) % 7) * 86400000;
  const per = {};
  notti.forEach(function(n){ per[fbChiave(n.ds)] = n; });
  const out = [];
  for (let i = 0; i < 7; i++){
    const ds = primo + i * 86400000;
    const n = per[fbChiave(ds)];
    out.push({ ds: ds, st: ds > oggi ? 'fut' : (n ? n.st : '?') });
  }
  return out;
}

/* ---- il pannello ------------------------------------------------------------------------ */
let FB_GIRO = 0;
/**
 * Due passate: la prima con quello che c'e' gia' (istantanea), la seconda quando il telefono
 * ha risposto. Il pannello non si svuota mai: cambiare periodo cambia i numeri sul posto.
 */
/* LA SLIDE della pagina «Proteggi i tuoi sogni» (0.9.188): gli stessi numeri del pannello */
/* 0.9.202 (Andrea): la slide E' il pannello, con la settimana a pallini e la riga di stanotte,
   non una frase sopra alla foto della scatola. */
async function fbSlidePaint(){
  const s = document.getElementById('fbSlideBox'); if (!s) return;
  let c = null; try{ c = await fbSerie(false); }catch(_){ }
  if (!c) return;
  let notte = null; try{ notte = await fbNotteMotore(); }catch(_){ }
  const sonno = notte && notte.ok ? snRigaStanotte(notte) : '';
  const dots = fbSettimana(c.notti).map(function(g){
    const cl = g.st === 'si' ? 'si' : (g.st === 'no' ? 'no' : (g.st === 'fut' ? 'fut' : 'na'));
    return '<i class="fb-d ' + cl + '">' + ['D', 'L', 'M', 'M', 'G', 'V', 'S'][new Date(g.ds).getDay()] + '</i>';
  }).join('');
  s.innerHTML = '<div class="fb-slide-pan">'
    + '<p class="arb-eyebrow">La Focus Box \u00b7 ultimi 7 giorni</p>'
    + '<h4>Notti con il telefono nella scatola</h4>'
    + '<div class="fb-num"><b>' + c.serie + '</b><small>' + (c.serie === 1 ? 'notte di fila' : 'notti di fila') + '</small></div>'
    + '<div class="fb-dots">' + dots + '</div>'
    + (sonno ? '<p class="arb-line fb-sonno">' + esc(sonno) + '</p>' : '')
    + '<div class="fb-tot"><span><b>' + c.punti + '</b>notti nella scatola</span><span><b>' + c.migliore + '</b>serie pi\u00f9 lunga</span></div>'
    + '</div>';
  const art = s.closest('.bh-slide'); if (art) art.classList.add('fb-slide');
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'blocco') setTimeout(fbSlidePaint, 200); });
document.addEventListener('fl:slide', function(e){ if (e.detail && e.detail.key === 'blocco') fbSlidePaint(); });
async function fbPaint(){
  fbSlidePaint();
  const box = document.getElementById('fbBoard');
  if (!box) return;
  const giro = ++FB_GIRO;
  fbDisegna(box, await fbSerie(true), null, true);
  const notte = await fbNotteMotore();
  const c = await fbSerie(false);
  if (giro !== FB_GIRO) return;              // nel frattempo e' partito un giro piu' nuovo
  fbDisegna(box, c, notte, false);
}

/**
 * LA NOTTE DI STANOTTE, DAL MOTORE UNICO DEL SONNO (0.9.236).
 *
 * <p>Il 13/10 il pannello diceva "Il telefono non ha ancora i dati di stanotte" mentre la
 * Cronologia mostrava la notte intera. La riga chiedeva getDayReport al motore con un tetto
 * di tre secondi, e nello stesso momento la pagina gli metteva in coda le letture delle sette
 * notti del pannello (il motore risponde a una domanda alla volta): la risposta arrivava dopo
 * il tetto e valeva come "nessun dato". In piu' leggeva la notte a modo suo, con un conto
 * diverso da quello del punteggio Sonno.</p>
 *
 * <p>Adesso la notte e' quella del motore unico (sonno.js / sonno-motore.js), la stessa del
 * Profilo, senza tetto di tre secondi: finche' non arriva resta la riga di prima. "Non ha
 * ancora i dati" esce solo quando il telefono i dati davvero non li ha.</p>
 */
async function fbNotteMotore(){
  if (typeof snNotteDi !== 'function') return null;
  try{ return await snNotteDi(fbMezzanotte(0)); }catch(_){ return null; }
}

function fbDisegna(box, c, notte, provvisorio){
  /* LA RIGA DI SOTTO: quando sei andato a letto e quando ti sei svegliato, misurato dal motore
     unico del sonno (la stessa notte del punteggio Sonno). Il verdetto a parole e' tolto: i
     pallini e il numero dicono gia' se la notte vale, e l'ora della sveglia dice perche'.
     Finche' la notte non e' arrivata (o qui non si misura) resta la riga di prima. */
  let sonno = '';
  if (notte && !provvisorio){
    sonno = snRigaStanotte(notte);
  } else {
    const vecchia = box.querySelector('.fb-sonno');
    sonno = vecchia ? vecchia.textContent : '';
  }

  let centro;
  if (c.tf === 7){
    centro = '<div class="fb-dots">' + fbSettimana(c.notti).map(function(g){
      const cl = g.st === 'si' ? 'si' : (g.st === 'no' ? 'no' : (g.st === 'fut' ? 'fut' : 'na'));
      return '<i class="fb-d ' + cl + '">' + ['D', 'L', 'M', 'M', 'G', 'V', 'S'][new Date(g.ds).getDay()] + '</i>';
    }).join('') + '</div>';
  } else {
    const pct = c.contate ? Math.round(c.punti / c.contate * 100) : 0;
    centro = '<div class="fb-perc"><div class="fb-bar"><i style="width:' + pct + '%"></i></div>'
      + '<small><b>' + c.punti + '</b> notti su <b>' + c.contate + '</b> nella scatola</small></div>';
  }

  box.innerHTML =
      '<button type="button" class="arb-dots" onclick="fbMenuOpen(event)" aria-label="Opzioni">\u22ef</button>'
    + '<p class="arb-eyebrow">La Focus Box \u00b7 ' + esc(fbTfLabel().toLowerCase()) + '</p>'
    + '<h4>Notti con il telefono nella scatola</h4>'
    + '<div class="fb-num"><b>' + c.serie + '</b><small>' + (c.serie === 1 ? 'notte di fila' : 'notti di fila') + '</small></div>'
    + centro
    + (sonno ? '<p class="arb-line fb-sonno">' + esc(sonno) + '</p>' : '')
    + '<div class="fb-tot"><span><b>' + c.punti + '</b>notti nella scatola</span><span><b>' + c.migliore + '</b>serie pi\u00f9 lunga</span></div>';
}

/* ---- i tre puntini: il periodo, e le impostazioni --------------------------------------- */
function fbMenuClose(){
  ['fbMenu', 'fbVeil'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); });
}
function fbMenuOpen(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('fbMenu')){ fbMenuClose(); return; }
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const v = document.createElement('div');
  v.id = 'fbVeil'; v.className = 'arb-veil';
  v.addEventListener('click', function(e){ e.stopPropagation(); fbMenuClose(); });
  casa.appendChild(v);
  const m = document.createElement('div');
  m.id = 'fbMenu'; m.className = 'arb-menu';
  const tf = fbTf();
  m.innerHTML = '<p class="arb-mtit">Periodo</p>'
    + FB_TFS.map(function(x){
        return '<button type="button" class="' + (x[0] === tf ? 'on' : '') + '" onclick="fbSetTf(' + x[0] + ')">' + x[1] + '</button>';
      }).join('')
    + '<button type="button" class="fb-mimp" onclick="fbImpOpen()">' + flIngranaggio(18) + ' Impostazioni</button>';
  casa.appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, ev && ev.currentTarget);
}
function fbSetTf(v){
  const s = fbStato(); s.tf = v; fbSalva(s);
  fbMenuClose();
  fbPaint();
}

/* ---- la pagina delle impostazioni: le due ore ------------------------------------------- */
registerScreen('s-fbimp', '<div class="topbar"><button class="iconbtn" onclick="fbImpChiudi()">‹</button>'
  + '<b class="blk-title">La Focus Box</b></div>'
  + '<div id="fbImpBody"></div><div class="spacer"></div>', { back: function(){ fbImpChiudi(true); return 's-home'; } });

function fbImpOpen(){
  fbMenuClose();
  goId('s-fbimp');
  const s = fbStato();
  const b = document.getElementById('fbImpBody');
  if (!b) return;
  b.innerHTML =
      '<div class="ps-block fb-imp">'
    +   '<div class="fb-imp-r"><div><b>🛏️ Vado a letto alle</b>'
    +     '<small>Da quest’ora il telefono è nella scatola.</small></div>'
    +     '<input class="fin fb-time" type="time" id="fbLetto" value="' + fbMinTxt(s.lettoMin) + '" onchange="fbImpSalva()"></div>'
    +   '<div class="fb-imp-r"><div><b>🔓 La scatola si apre alle</b>'
    +     '<small>Se il telefono resta chiuso fino a quest’ora, la notte vale un punto.</small></div>'
    +     '<input class="fin fb-time" type="time" id="fbApre" value="' + fbMinTxt(s.apreMin) + '" onchange="fbImpSalva()"></div>'
    + '</div>'
    + '<p class="hintline" style="padding:12px 4px 0;text-align:center">Tre minuti di schermo acceso in mezzo non contano: una sveglia spenta non è usare il telefono.</p>';
}
function fbImpMin(id){
  const v = (document.getElementById(id) || {}).value || '';
  const m = /^(\d{2}):(\d{2})$/.exec(v);
  return m ? (+m[1]) * 60 + (+m[2]) : null;
}
function fbImpSalva(){
  const l = fbImpMin('fbLetto'), a = fbImpMin('fbApre');
  if (l === null || a === null) return;
  if (l < 720 && l >= a){ toast('La scatola deve aprirsi dopo l’ora del letto'); return; }
  const s = fbStato(); s.lettoMin = l; s.apreMin = a; fbSalva(s);
  toast('A letto alle ' + fbMinTxt(l) + ', apertura alle ' + fbMinTxt(a));
}
function fbImpChiudi(soloSalva){
  fbImpSalva();
  if (soloSalva === true) return;
  if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); if (typeof switchTab === 'function') switchTab('blocco'); }
  fbPaint();
}

/**
 * Il tabellone della scatola prende il posto del pannello dell'arbitro, sopra al Blocco
 * rapido. L'arbitro resta nella pagina ma nascosto: chi non vede il tabellone continua a
 * vedere l'arbitro dov'era.
 */
function fbInnesta(){
  const tab = document.getElementById('tab-blocco');
  const arb = document.getElementById('arbBox');
  if (!tab || !arb) return;
  const qb = tab.querySelector('.qb');
  if (!qb) return;
  if (!fbVisibile()){
    const vecchio = document.getElementById('fbWrap');
    if (vecchio){ vecchio.parentNode.insertBefore(arb, vecchio); vecchio.remove(); }
    const b = document.getElementById('fbBoard'); if (b) b.remove();
    return;
  }
  if (document.getElementById('fbBoard')) return;
  const board = document.createElement('div');
  board.id = 'fbBoard'; board.className = 'arb fb-board';
  qb.parentNode.insertBefore(board, qb);
  const wrap = document.createElement('div');
  wrap.id = 'fbWrap'; wrap.hidden = true; wrap.style.display = 'none';
  qb.parentNode.insertBefore(wrap, qb);
  wrap.appendChild(arb);
  fbPaint();
  try{ if (typeof flPaginaApplica === 'function') flPaginaApplica('blocco'); }catch(_){ }
}

document.addEventListener('fl:tab', function(e){ if (e.detail === 'blocco'){ fbInnesta(); fbPaint(); } });
setTimeout(function(){ fbInnesta(); }, 2200);

(function fbStyle(){
  const css = [
    '.fb-board{margin:0 0 14px}',
    '.bh-slide.fb-slide .bh-img,.bh-slide.fb-slide .bh-ov{display:none}.bh-slide.fb-slide{background:radial-gradient(120% 90% at 50% 0%,#17407A,#0B2A5B 55%,#071B3E)}',
    '.bh-slide.fb-slide .bh-text{top:0;bottom:0;display:flex;align-items:center;justify-content:center;padding:12px 20px 34px}',
    '.fb-slide-pan{width:100%;max-width:340px;text-align:center;color:#fff}.fb-slide-pan h4{margin:4px 0 0;font:800 20px/1.2 var(--font-display);color:#fff}.fb-slide-pan .arb-eyebrow{color:rgba(200,218,242,.8)}',
    '.fb-slide-pan .fb-num{margin-top:8px}.fb-slide-pan .fb-num b{font-size:40px}.fb-slide-pan .fb-dots{margin:8px 0 2px}.fb-slide-pan .fb-tot{margin-top:8px;padding-top:8px;padding-bottom:6px}.fb-slide-pan h4{font-size:18px}',
    '.fb-num{margin-top:16px}',
    '.fb-num b{display:block;font:800 52px/1 var(--font-display);color:#8CF0C8}',
    '.fb-num small{display:block;margin-top:6px;font:700 10px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:rgba(200,218,242,.8)}',
    '.fb-dots{display:flex;gap:6px;justify-content:center;margin:14px 0 2px}',
    '.fb-d{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;',
      'font:800 10px var(--font-body);font-style:normal;color:rgba(255,255,255,.9)}',
    '.fb-d.si{background:rgba(140,240,200,.9);color:#0E3A2B}',
    '.fb-d.no{background:rgba(255,138,155,.85);color:#4A1420}',
    '.fb-d.na{background:rgba(255,255,255,.12)}',
    '.fb-d.fut{background:transparent;border:1px dashed rgba(255,255,255,.25);color:rgba(255,255,255,.45)}',
    '.fb-perc{margin:14px 8px 2px}.fb-bar{height:8px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}',
    '.fb-bar i{display:block;height:100%;background:#8CF0C8;border-radius:99px}',
    '.fb-perc small{display:block;margin-top:8px;font:600 11.5px var(--font-body);color:rgba(200,218,242,.85)}.fb-perc b{color:#fff}',
    '.fb-tot{display:flex;gap:18px;justify-content:center;margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.12)}',
    '.fb-tot span{font:600 10.5px var(--font-body);color:rgba(200,218,242,.75);display:flex;flex-direction:column;gap:2px}',
    '.fb-tot b{font:800 18px var(--font-display);color:#fff}',
    '.arb-menu .fb-mimp{border-top:1px solid var(--line)}',
    '.fb-imp{display:flex;flex-direction:column;gap:18px}',
    '.fb-imp-r{display:flex;align-items:center;gap:12px}',
    '.fb-imp-r > div{flex:1;min-width:0}',
    '.fb-imp-r b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .fb-imp-r b{color:#fff}',
    '.fb-imp-r small{display:block;margin-top:3px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.fb-time{width:104px;flex:none;text-align:center}'
  ].join('\n');
  const s = document.createElement('style'); s.id = 'fb-style'; s.textContent = css; document.head.appendChild(s);
})();
