/* ===========================================================================================
   LE SFIDE DELLA SCHEDA DREAM (0.9.210) — il pannello «Sfide» di Meditopia

   Un pannello scuro con il titolo, «Vedi tutto», una riga che dice a cosa servono, e un
   carosello di card che scorre di lato: l'immagine, il nome della sfida, cosa succede, e
   «Partecipa». Quattro sfide:
     1. 🦹 Indovina il mio sabotatore — il quiz dei freni (blocchi.js). E' la PRIMA cosa da
        fare nel viaggio: finche' il freno resta senza nome, decide lui («Finché non renderai
        conscio l'inconscio, esso dirigerà la tua vita e tu lo chiamerai destino», Jung). Il
        risultato va al tuo agente personale (bqPerAgente) e stringe l'intervallo dell'arrivo previsto.
     2. 📜 Indovina il mio rimpianto futuro — la leva dell'avversione alla perdita: domande
        indirette, e il Genio mostra il finale a cui vai incontro se oggi non cambi rotta
        (lo spirito del Natale futuro di Scrooge). Da li', la Modalità severa.
     3. 🗺️ Indovina la mia prossima tappa — l'Oracolo del giorno (oracolo-tappa.js): come ti
        senti, quanto tempo hai, cosa rimandi. Se sei in ansia, prima due minuti di respiro.
     4. 🏆 Le sfide della settimana — quelle misurate con i dati veri (sfide.js).
     0.9.220: 🌬️ Quale respiro ti serve adesso? Il Genio consiglia il respiro (respiro.js,
     rsConsiglioApri) da obiettivo, tempo, posto e ora del giorno.
   Niente numeri di «partecipanti» inventati: sotto ogni card c'e' quanto dura.
   =========================================================================================== */
const SFD_NOMI = { valore: 'Il blocco del valore', passato: 'Il blocco del passato', dispersione: 'Il blocco del focus', tempo: 'Il blocco del tempo', paura: 'Il blocco della paura', sguardi: 'Il blocco del giudizio', denaro: 'Il blocco del denaro', imparare: 'Il blocco dell’imparare' };
function sfdEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function sfdOggi(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function sfdLista(){
  const bq = (typeof bqLeggi === 'function') ? bqLeggi() : null;
  const rf = rfLeggi();
  let tappa = false; try{ tappa = localStorage.getItem('fl_orc_giorno') === sfdOggi(); }catch(_){ }
  const l = [
    { k: 'demone', ico: '🦹', img: 'img/sfide/sabotatore.jpg', t: 'Indovina il mio sabotatore',
      s: bq && bq.primario ? 'Il tuo sabotatore: ' + (SFD_NOMI[bq.primario] || bq.primario).toLowerCase() + '. Il Genio costruisce la tua rotta e la tua previsione partendo da qui.' : 'Il Genio fa la radiografia del paradigma che ti tiene fermo. Finché resta inconscio, decide lui al posto tuo: e tu lo chiami destino.',
      meta: '5 minuti', fatta: !!(bq && bq.primario), via: 'sfdDemone()' },
    { k: 'rimpianto', ico: '📜', img: 'img/sfide/rimpianto.jpg', t: 'Indovina il mio rimpianto futuro',
      s: rf ? 'Il finale da evitare: ' + rfScenario(rf.k).t.toLowerCase() + '. Ogni giorno in rotta lo allontana.' : 'Sei domande indirette, e il Genio ti mostra il finale a cui vai incontro se oggi non cambi rotta.',
      meta: '3 minuti', fatta: !!rf, via: 'rfApri()' },
    { k: 'tappa', ico: '🗺️', img: 'img/sfide/tappa.jpg', t: 'Indovina la mia prossima tappa',
      s: 'Come ti senti, quanto tempo hai, cosa stai rimandando: il Genio indovina l’unica cosa da fare nelle prossime due ore.',
      meta: '1 minuto', fatta: tappa, via: 'if(typeof orcApri===\'function\')orcApri(\'dream\')' },
    { k: 'respiro', ico: '🌬️', img: 'img/sfide/respiro.jpg', t: 'Quale respiro ti serve adesso?',
      s: 'Dimmi cosa vuoi ottenere, quanto tempo hai e dove sei: il Genio sceglie il respiro giusto per quel momento e te lo guida secondo per secondo.',
      meta: 'Da 1 a 10 minuti', fatta: false, via: 'if(typeof rsConsiglioApri===\'function\')rsConsiglioApri(\'dream\')' },
    { k: 'reset', ico: '🧠', img: 'img/sfide/testa.jpg', t: 'Come sta la tua testa?',
      s: 'Tre domande sulla testa di adesso, e il Genio ti propone l’esercizio giusto: respiro, caveau delle idee o una pausa per gli occhi.',
      meta: '1 minuto', fatta: false, via: 'if(typeof rstApri===\'function\')rstApri()' },
    { k: 'settimana', ico: '🏆', img: 'img/sfide/settimana.jpg', t: 'Le sfide della settimana',
      s: 'Sfide misurate con i tuoi dati veri: minuti di Full Focus, mattine senza social, zero minuti sull’app che ti ruba più tempo.',
      meta: 'Monete in palio', fatta: false, via: 'sfdTutte()' }
  ];
  /* 0.9.242: la stagione di spinta (stagione.js) entra per prima, finche' non e' cominciata */
  try{ if (typeof stgSfidaCard === 'function'){ const c = stgSfidaCard(); if (c) l.unshift(c); } }catch(_){ }
  const chiuse = function(k){ return typeof flSezioneBloccata === 'function' && flSezioneBloccata(k); };
  return l.filter(function(c){
    if (c.k === 'respiro' && chiuse('respiro')) return false;
    if (c.k === 'settimana' && chiuse('lega')) return false;
    return true;
  });
}
/* 0.9.323, Andrea (Meditopia): accanto a Partecipa le bolle di chi l'ha accettata, se sono abbastanza; se no quanto dura, con l'orologio, su una riga */
const SFD_OROLOGIO = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
function sfdPersone(c){
  const n = +c.accettate || 0, facce = c.facce || [];
  if (n >= 20 && facce.length) return '<small class="sfd-gente"><span>' + facce.slice(0, 4).map(function(x){ return '<img src="' + x + '" alt="">'; }).join('') + '</span>' + n.toLocaleString('it-IT') + '</small>';
  return '<small class="sfd-tempo">' + SFD_OROLOGIO + '<em>' + sfdEsc(c.meta) + '</em></small>';
}
function sfdCard(c){
  return '<article class="sfd-c" onclick="' + c.via + '"><div class="sfd-img" style="background-image:url(\'' + c.img + '\')">' + (c.fatta ? '<span class="sfd-ok">✓ Fatta</span>' : '') + '</div>'
    + '<div class="sfd-corpo"><b>' + sfdEsc(c.t) + '</b><p>' + sfdEsc(c.s) + '</p>'
    + '<div class="sfd-piede">' + sfdPersone(c) + '<span class="sfd-go">' + (c.fatta ? (c.k === 'tappa' ? 'Di nuovo' : 'Rivedi') : 'Partecipa') + '</span></div></div></article>';
}
/* 0.9.353, Andrea: "il titolo Sfide al centro, con un'emoji tipo le spade; Vedi tutto come ultima card del carosello con una freccia
   verso destra; la frase sotto il titolo ruba il focus alla card: va nella (i). E il pannello deve staccare dalla card scura: chiaro
   in alto, o azzurro chiaro". Le card restano scure, il pannello diventa azzurro chiaro */
const SFD_AVANTI = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';
function sfdHtml(){
  const l = sfdLista();
  const tutte = '<article class="sfd-c sfd-vedi" onclick="sfdTutte()"><div class="sfd-vedi-in"><span class="sfd-vedi-ico">' + SFD_AVANTI + '</span><b>Vedi tutte le sfide</b><small>Le missioni, quelle in corso e quelle del Genio</small></div></article>';
  return '<section class="sfd"><div class="sfd-h"><b><span aria-hidden="true">⚔️</span>Sfide<button type="button" class="sfd-i" onclick="event.stopPropagation();sfdInfo()" aria-label="A cosa servono le sfide">i</button></b></div>'
    + '<div class="sfd-track" id="sfdTrack" onscroll="sfdPunti()">' + l.map(sfdCard).join('') + tutte + '</div>'
    + '<div class="sfd-punti" id="sfdPunti">' + l.concat([0]).map(function(_, i){ return '<i class="' + (i ? '' : 'on') + '"></i>'; }).join('') + '</div></section>';
}
function sfdInfo(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Perché fare le sfide</h3>'
    + flInfoRighe([
        ['⚔️', 'Una sfida ha un traguardo e una scadenza', 'Sai cosa fare e entro quando.'],
        ['👥', 'Con gli altri ti impegni di più', 'Chi ha un obiettivo e si confronta con altre persone si motiva e si impegna di più: lo dicono gli studi.'],
        ['📈', 'Così cresci più in fretta', 'Più impegno vuol dire imparare e migliorare prima.']
      ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}
function sfdPaint(){
  const host = document.getElementById('nvSfide'); if (!host) return;
  /* 0.9.242: spente dalla Modalità severa o dalla stagione di spinta (blocchi-sezioni.js), le sfide spariscono */
  const via = (typeof flSezioneBloccata === 'function') && flSezioneBloccata('sfide');
  host.hidden = via;
  host.innerHTML = via ? '' : sfdHtml();
}
function sfdPunti(){
  const t = document.getElementById('sfdTrack'), d = document.getElementById('sfdPunti');
  if (!t || !d || !t.firstElementChild) return;
  const i = Math.round(t.scrollLeft / Math.max(1, t.firstElementChild.getBoundingClientRect().width + 12));
  Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
}
function sfdDemone(){ if (typeof blocchiApri === 'function') blocchiApri(false); }

registerScreen('s-sfide-dream',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\');switchTab(\'rotta\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></button><b class="blk-title">Sfide</b></div>'
  + '<p class="sfd-tutte-sotto">Con un traguardo e altre persone accanto ti impegni di più, e cresci prima.</p>'
  + '<div id="sfdTutteBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });
/* 0.9.350, Andrea: "Vedi tutto deve portare a una pagina Sfide sola, senza la pagina Amici intorno: le missioni di gruppo e giornaliere,
   quelle in corso, quelle disponibili (Novembre pulito, 20 ore di Full Focus...) E quelle del Genio con la foto. E le card non devono
   essere grigie con Partecipa sbiadito" (erano disegnate per il pannello scuro, e su una pagina bianca diventavano grigie) */
function sfdTutte(){
  if (order[cur] !== 's-sfide-dream') goId('s-sfide-dream');
  const h = document.getElementById('sfdTutteBody'); if (!h) return;
  if (typeof sfLista === 'function' && !sfLista().length && typeof sfCarica === 'function' && !sfdTutte._car){ sfdTutte._car = 1; sfCarica().then(function(){ sfdTutte._car = 0; if (order[cur] === 's-sfide-dream') sfdTutte(); }); }
  let pag = ''; try{ pag = (typeof sfPaginaHtml === 'function') ? sfPaginaHtml() : ''; }catch(_){ pag = ''; }
  const genio = sfdLista().filter(function(c){ return c.k !== 'settimana'; });
  h.innerHTML = '<div class="sfp-pag">' + pag + '</div>'
    + '<div class="am-sect"><b>Le sfide del Genio</b></div><div class="sfd-tutte">' + genio.map(sfdCard).join('') + '</div>';
  try{ if (typeof sfContaCarica === 'function') sfContaCarica().then(function(){ const sp = document.getElementById('spSez-sfide'); if (!sp && order[cur] === 's-sfide-dream' && typeof spSfideHtml === 'function' && spSfideHtml()) sfdTutte(); }); }catch(_){ }
}
/* le azioni dentro la pagina (missioni, partecipa, riprova) ridisegnano Amici con frPaint: se la pagina Sfide e' aperta, si ridisegna lei */
(function(){
  const prova = function(k){
    const o = window.frPaint; if (typeof o !== 'function'){ if (k < 20) setTimeout(function(){ prova(k + 1); }, 1000); return; }
    if (o.__sfd) return;
    const n = function(){ const r = o.apply(this, arguments); try{ if (order[cur] === 's-sfide-dream') sfdTutte(); }catch(_){ } return r; };
    n.__sfd = true; window.frPaint = n;
  };
  setTimeout(function(){ prova(0); }, 1500);
})();

/* ===========================================================================================
   INDOVINA IL MIO RIMPIANTO FUTURO — la leva dell'avversione alla perdita
   Sei domande che non chiedono mai «di cosa hai paura»: chiedono cosa ti brucia, cosa guardi
   la sera, cosa rimandi. Ogni risposta pesa sui sei finali possibili; vince il piu' pesante.
   =========================================================================================== */
const RF_KEY = 'fl_rimpianto';
const RF_SCENARI = [
  { k: 'libro', ico: '📕', t: 'Il libro mai scritto', scena: 'Hai settant’anni. Sulla scrivania c’è ancora la cartella con le prime pagine, quelle scritte a trent’anni. Le idee c’erano tutte. Mancava solo il giorno giusto per cominciare, e il giorno giusto non è mai arrivato.' },
  { k: 'impero', ico: '🏛️', t: 'L’impresa rimasta nel cassetto', scena: 'Hai settant’anni. Qualcun altro ha costruito l’impresa che avevi in mente: la stessa idea, dieci anni dopo di te. L’idea l’avevi vista prima tu. Mancava solo il primo passo.' },
  { k: 'isolamento', ico: '🪑', t: 'La tavola vuota a cinquant’anni', scena: 'Hai cinquant’anni e una casa silenziosa. Le persone che contavano hanno smesso di chiamare, una alla volta: eri sempre lì con il telefono in mano, e mai con la testa. Nessuna lite, solo una distanza che cresceva ogni sera.' },
  { k: 'corpo', ico: '🫀', t: 'Il corpo lasciato andare', scena: 'Hai sessant’anni e le scale pesano. Il medico ripete le stesse frasi da dieci anni. Ogni lunedì doveva essere quello buono per ricominciare a muoverti, e i lunedì sono finiti prima della voglia.' },
  { k: 'talento', ico: '🎻', t: 'Il talento sprecato', scena: 'Hai settant’anni e a una cena qualcuno ricorda quello che sapevi fare da giovane. Tutti dicevano che avevi qualcosa di raro. Il talento c’era: è mancato chi lo allenasse ogni giorno.' },
  { k: 'finestra', ico: '🪟', t: 'La vita vista dalla finestra', scena: 'Hai settant’anni e un elenco di posti, di persone e di cose che volevi provare. L’hai riletto così tante volte che lo sai a memoria. Non hai mai spuntato una riga: aspettavi il momento giusto.' }
];
const RF_DOMANDE = [
  { q: 'Quando vedi una persona della tua età che ce l’ha fatta, <b>cosa ti brucia di più</b>?', o: [
    ['🏗️', 'Che ha costruito qualcosa di suo', { impero: 2, libro: .5 }], ['🌍', 'Che vive dove e come vuole', { finestra: 2 }],
    ['🏠', 'Che non torna mai in una casa vuota', { isolamento: 2 }], ['💪', 'Che sta bene nel proprio corpo', { corpo: 2 }],
    ['🎨', 'Che vive di quello che crea', { libro: 1.5, talento: 1 }], ['🏆', 'Che vince nel suo campo', { talento: 2 }]] },
  { q: 'La sera, mentre scorri i video sul telefono, <b>quali video ti fermano</b>?', o: [
    ['🚀', 'Chi ha fondato un’azienda da zero', { impero: 1.5 }], ['✈️', 'I viaggi in posti lontani', { finestra: 1.5 }],
    ['🔥', 'Le trasformazioni fisiche', { corpo: 1.5 }], ['✍️', 'Gli artisti al lavoro', { libro: 1.5 }],
    ['🍝', 'Famiglie e amici a tavola', { isolamento: 1.5 }], ['🎯', 'I campioni in allenamento', { talento: 1.5 }]] },
  { q: 'Fra queste cose, <b>quale rimandi da più di un anno</b>?', o: [
    ['💼', 'Un progetto tutto mio', { impero: 1.5, libro: .5 }], ['📞', 'Chiamare persone che non sento più', { isolamento: 2 }],
    ['🏃', 'Ricominciare a muovermi', { corpo: 2 }], ['🧳', 'Prenotare il viaggio che sogno', { finestra: 2 }],
    ['🎸', 'Riprendere una cosa che mi riusciva benissimo', { talento: 2 }], ['📝', 'Scrivere quello che ho in testa', { libro: 2 }]] },
  { q: 'Se domani perdessi un anno intero, <b>cosa ti mancherebbe di più</b>?', o: [
    ['💶', 'I soldi che avrei potuto guadagnare', { impero: 1.5 }], ['👥', 'Le persone', { isolamento: 1.5 }],
    ['🫀', 'La salute', { corpo: 1.5 }], ['🌅', 'Le esperienze', { finestra: 1.5 }],
    ['📖', 'Il tempo per creare', { libro: 1.5 }], ['📈', 'I progressi nella mia passione', { talento: 1.5 }]] },
  { q: 'A settant’anni, <b>quale frase non vorresti mai sentirti dire</b>?', o: [
    ['🎻', '«Avevi tutto per farcela»', { talento: 2 }], ['💡', '«Era una bella idea»', { impero: 2 }],
    ['📕', '«Ne parlavi sempre, di quel libro»', { libro: 2 }], ['🚪', '«Non ti abbiamo più visto»', { isolamento: 2 }],
    ['🪜', '«Alla tua età non si può più»', { corpo: 2 }], ['🗺️', '«Prima o poi ci andrai»', { finestra: 2 }]] },
  { q: 'Oggi, <b>cosa ti manca di più per cominciare</b>?', o: [
    ['⏳', 'Il tempo', { impero: .5, libro: .5 }], ['🔋', 'L’energia', { corpo: 1 }],
    ['🦁', 'Il coraggio', { finestra: 1, talento: .5 }], ['🤝', 'Le persone giuste', { isolamento: 1 }],
    ['🧭', 'Un piano', { impero: 1 }], ['🔁', 'La costanza', { talento: 1, libro: .5 }]] }
];
const RF = { i: 0, p: {} };
function rfLeggi(){ try{ return JSON.parse(localStorage.getItem(RF_KEY) || 'null'); }catch(_){ return null; } }
function rfScenario(k){ return RF_SCENARI.filter(function(x){ return x.k === k; })[0] || RF_SCENARI[0]; }
/** Per il tuo agente personale: il finale da evitare, in una riga. */
function rfPerAgente(){ const r = rfLeggi(); return r ? 'Rimpianto futuro da evitare: ' + rfScenario(r.k).t.toLowerCase() + '.' : ''; }

registerScreen('s-rimpianto',
  '<div class="topbar"><button class="iconbtn" onclick="rfIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Il rimpianto futuro</b></div>'
  + '<div id="rfBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });
function rfApri(){
  RF.i = 0; RF.p = {};
  goId('s-rimpianto');
  const r = rfLeggi();
  if (r){ RF.ris = r.k; RF.i = RF_DOMANDE.length; }
  rfPaint();
}
function rfIndietro(){
  if (RF.i > 0 && RF.i < RF_DOMANDE.length){ RF.i--; rfPaint(); return; }
  if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } }
}
function rfRisp(j){
  const d = RF_DOMANDE[RF.i]; const pesi = d.o[j][2];
  Object.keys(pesi).forEach(function(k){ RF.p[k] = (RF.p[k] || 0) + pesi[k]; });
  try{ flVibra(10); }catch(_){ }
  RF.i++;
  if (RF.i >= RF_DOMANDE.length){
    let max = -1, k = 'impero'; RF_SCENARI.forEach(function(s){ if ((RF.p[s.k] || 0) > max){ max = RF.p[s.k] || 0; k = s.k; } });
    RF.ris = k;
    try{ localStorage.setItem(RF_KEY, JSON.stringify({ k: k, p: RF.p, at: Date.now() })); }catch(_){ }
    RF.svela = true;
  }
  rfPaint();
}
function rfRifai(){ try{ localStorage.removeItem(RF_KEY); }catch(_){ } RF.i = 0; RF.p = {}; RF.ris = ''; rfPaint(); }
function rfPaint(){
  const h = document.getElementById('rfBody'); if (!h) return;
  if (RF.i < RF_DOMANDE.length){
    const d = RF_DOMANDE[RF.i];
    h.innerHTML = '<div class="orc-dots">' + RF_DOMANDE.map(function(_, i){ return '<i class="' + (i <= RF.i ? 'on' : '') + '"></i>'; }).join('') + '</div>'
      + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div><p class="orc-q">' + d.q + '</p>'
      + '<div class="rf-opz">' + d.o.map(function(o, j){ return '<button type="button" onclick="rfRisp(' + j + ')"><span>' + o[0] + '</span>' + sfdEsc(o[1]) + '</button>'; }).join('') + '</div>';
    return;
  }
  const s = rfScenario(RF.ris);
  const svela = RF.svela; RF.svela = false;
  h.innerHTML = '<div class="rf-ris' + (svela ? ' svela' : '') + '"><div class="orc-genio"><img src="img/genio/genio-rivela.png" alt=""></div>'
    + '<p class="orc-eti">Il tuo rimpianto futuro</p><h2 class="rf-h"><span>' + s.ico + '</span>' + sfdEsc(s.t) + '</h2>'
    + '<div class="rf-scena"><p>' + sfdEsc(s.scena) + '</p></div>'
    + '<p class="rf-svolta">Questo finale non è scritto. È la strada di oggi, se oggi non cambi rotta. Il fantasma del Natale futuro mostrò a Scrooge proprio questo: non il destino, ma dove portava la strada.</p>'
    + '<button type="button" class="cta rf-cta" onclick="rfSevera()">Attiva la modalità severa</button>'
    + '<button type="button" class="cta rf-sec" onclick="if(typeof orcApri===\'function\')orcApri(\'dream\')">Cambia il finale: la prossima tappa</button>'
    + '<button type="button" class="sd-btn-link" onclick="rfRifai()">Rifai le domande</button></div>';
}
function rfSevera(){ if (typeof sevBackToTab === 'function') sevBackToTab(); else { goId('s-home'); try{ switchTab('severa'); }catch(_){ } } }

(function(){
  const css = [
    '#nvSfide{padding:0 14px;margin:6px 0 18px}.sfd{padding:20px 0 16px;border-radius:26px;background:linear-gradient(180deg,#14234A 0%,#0B1530 100%);color:#fff;box-shadow:0 14px 30px rgba(0,20,60,.22)}',
    /* 0.9.323, Andrea (Meditopia): il pannello ha un bel gradiente, le card sono piu' larghe */
    /* 0.9.354, Andrea: "riportalo a quel blu di prima, e anche le card della stagione di spinta e delle sfide: non ti ho mai detto di
       cambiare il loro gradiente". Il pannello e le card tornano quelli del 0.9.352; restano il titolo al centro con le spade, la (i)
       (bianca sul blu: sull'azzurro chiaro non sembrava un pulsante) e la card Vedi tutte le sfide */
    '.sfd{padding:22px 0 18px;border-radius:26px;background:linear-gradient(180deg,#071A3F 0%,#0A3C8C 62%,#0075E3 130%)}',
    '.sfd .sfd-h{justify-content:center;margin-bottom:18px}.sfd .sfd-h b{display:inline-flex;align-items:center;gap:10px;color:#fff}',
    /* .sfd .sfd-h .sfd-i: la regola .sfd-h button (bordo 0, fondo trasparente) vinceva e la (i) restava una lettera senza cerchio */
    '.sfd .sfd-h .sfd-i{flex:none;box-sizing:border-box;width:24px;height:24px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid rgba(255,255,255,.85);border-radius:50%;background:rgba(255,255,255,.18);color:#fff;font:800 13px/1 var(--font-body);cursor:pointer}',
    '.sfd-vedi{align-items:center;justify-content:center;min-height:260px}.sfd-vedi-in{display:flex;flex-direction:column;align-items:center;gap:12px;padding:24px;text-align:center}.sfd-vedi-ico{display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:#fff;color:#0075E3}.sfd-vedi-in b{font:800 19px var(--font-display);color:#fff}.sfd-vedi-in small{max-width:24ch;font:600 13px/1.4 var(--font-body);color:#C8EFFD}',
    '.sfd-tutte-sotto{margin:2px 18px 18px;text-align:center;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.sfd-h{display:flex;align-items:center;justify-content:space-between;padding:0 18px}.sfd-h b{font:800 24px var(--font-display);color:#fff}.sfd-h button{border:0;background:transparent;color:rgba(255,255,255,.72);font:600 15px var(--font-body);cursor:pointer}',
    '.sfd-p{margin:8px 18px 16px;font:500 14px/1.5 var(--font-body);color:rgba(255,255,255,.7)}',
    '.sfd-track{display:flex;gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;padding:0 16px 4px;scrollbar-width:none}.sfd-track::-webkit-scrollbar{display:none}',
    '.sfd-c{flex:0 0 91%;scroll-snap-align:center;border-radius:20px;overflow:hidden;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);cursor:pointer;display:flex;flex-direction:column}',
    '.sfd-img{position:relative;height:150px;background:center/cover no-repeat}.sfd-img::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,0) 40%,rgba(11,21,48,.55))}.sfd-ico{position:absolute;left:14px;bottom:10px;z-index:1;font-size:40px;filter:drop-shadow(0 4px 10px rgba(0,0,0,.45))}.sfd-ok{position:absolute;right:12px;top:12px;z-index:1;padding:5px 10px;border-radius:99px;background:#fff;color:#0075E3;font:800 12px var(--font-body)}',
    '.sfd-corpo{padding:16px 16px 14px;display:flex;flex-direction:column;flex:1}.sfd-corpo b{font:800 17px/1.3 var(--font-body);color:#fff}.sfd-corpo p{margin:6px 0 14px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.72);flex:1}',
    '.sfd-piede{display:flex;align-items:center;justify-content:space-between;gap:10px;padding-top:12px;border-top:1px solid rgba(255,255,255,.14)}.sfd-piede small{min-width:0;font:600 12.5px var(--font-body);color:rgba(255,255,255,.75)}.sfd-tempo{display:flex;align-items:center;gap:6px}.sfd-tempo svg{flex:none}.sfd-tempo em{font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sfd-gente{display:flex;align-items:center;gap:6px}.sfd-gente span{display:flex}.sfd-gente img{width:26px;height:26px;margin-left:-8px;border-radius:50%;border:2px solid #0A2A63;object-fit:cover}.sfd-gente img:first-child{margin-left:0}.sfd-go{flex:none;padding:8px 16px;border-radius:99px;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.3);font:700 13px var(--font-body);color:#fff}',
    '.sfd-punti{display:flex;justify-content:center;gap:7px;margin-top:14px}.sfd-punti i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.3)}.sfd-punti i.on{background:#fff}',
    /* 0.9.349, Andrea: "il bianco sull'azzurro della card non si legge: lo scuro della sezione gymshark-features-slider del tema, piu' scuro dove
       c'e' il testo e che sfuma verso il basso, lasciando chiara la parte con Partecipa" (lo stesso gradiente di .vs-overlay-bg, girato) */
    '.sfd-corpo{background:linear-gradient(180deg,rgba(0,12,36,.66) 0%,rgba(0,12,36,.4) 45%,rgba(0,12,36,0) 85%)}.sfd-corpo p{color:rgba(255,255,255,.9)!important}.sfd-corpo b{text-shadow:0 1px 8px rgba(0,0,0,.25)}',
    '#sfdTutteBody .dso-mese{position:static!important;margin-top:8px}#sfdTutteBody .sfd-c{background:linear-gradient(165deg,#0B3E86 0%,#001E44 100%)!important;border-color:transparent!important;box-shadow:0 10px 24px rgba(0,30,68,.18)}#sfdTutteBody .sfd-go{opacity:1!important}#sfdTutteBody .am-sect{margin-top:26px}#sfdTutteBody .sfd-tutte{margin-top:12px}',
    '#sfdTutteBody{padding:0 18px}.sfd-tutte-p{margin:10px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted)}.sfd-tutte{display:flex;flex-direction:column;gap:16px}.sfd-tutte .sfd-c{flex:none}',
    '#rfBody{padding:0 18px}.rf-opz{display:grid;grid-template-columns:1fr 1fr;gap:10px}.rf-opz button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:16px 8px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);font:700 13.5px/1.35 var(--font-body);color:var(--navy);cursor:pointer;box-shadow:0 3px 0 var(--line)}.rf-opz button span{font-size:28px}body.dark .rf-opz button{background:#12203A;border-color:#22345A;color:#fff;box-shadow:0 3px 0 #22345A}',
    '.rf-ris{text-align:center}.rf-ris.svela{animation:rfSvela 1.1s ease both}@keyframes rfSvela{0%{opacity:0;filter:blur(8px)}100%{opacity:1;filter:none}}.rf-h{margin:6px 0 14px;font:800 24px/1.25 var(--font-display);color:var(--navy)}body.dark .rf-h{color:#fff}.rf-h span{display:block;font-size:46px;margin-bottom:6px}',
    '.rf-scena{padding:18px 18px;border-radius:20px;background:#0B1530;text-align:left}.rf-scena p{margin:0;font:500 15.5px/1.65 var(--font-body);color:#E6ECF5;font-style:italic}',
    '.rf-svolta{margin:16px 0 0;font:600 14px/1.55 var(--font-body);color:var(--muted)}.rf-cta{width:100%;margin-top:20px;background:#E63946 !important;color:#fff !important}.rf-sec{width:100%;margin-top:10px;background:#EAF2FB !important;color:var(--navy) !important}body.dark .rf-sec{background:#1B2B48 !important;color:#fff !important}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
