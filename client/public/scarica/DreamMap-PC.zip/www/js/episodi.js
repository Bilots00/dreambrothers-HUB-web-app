/* ===========================================================================================
   LA SERIE DEL GENIO (0.9.300) — gli episodi in Dream, uno al giorno, separati dalla Roadmap

   Andrea, 24/10/2026: "lo storytelling sta negli episodi giornalieri, slide dopo slide, discorso
   dopo discorso... in stile serie Netflix, viaggio dell'eroe, un episodio da completare ogni
   giorno, con cliffhanger che si interrompono sul piu' bello". E: "l'episodio e' una cosa, il
   livello un'altra: devono essere scollegati". La Roadmap (sentiero-mappa.js) adesso ha solo
   tappe di vita reale; gli episodi vivono qui e si vedono nella scheda Sogno.

   LA BIBBIA della serie e' docs/bibbia-serie.md. I TESTI stanno tutti in content/episodi.json:
   qui non c'e' una frase da leggere a schermo.

   COME E' FATTO
   · La scena e' quella del Genio (genio-intro.js, #s-genio): stessa nuvoletta con la macchina da
     scrivere, stessi pulsanti, GN.modo = 'epi'. Un passo del file = una schermata.
   · L'episodio 1 e' il primo avvio (il film del Genio): genio-intro.js prende da qui la sigla,
     l'apertura, il patto e il cliffhanger (epiIntroParte, epiIntroPatto).
   · Le domande sono quelle di domande.js (stessi id, stesse risposte in fl_domande): chi ha gia'
     risposto non se le sente richiedere, e l'agente le legge come prima (iofuturo-chiamata.js).
     "Lo scrivo io" c'e' solo dove una risposta sua ha senso (0.9.344: flag scrivo, vedi epiScrivoSi).
   · 0.9.344: due tipi di passo nuovi. { tipo: 'scroll', stile } apre una scena a scorrimento (episodi-scroll.js,
     GSAP ScrollTrigger sulle sezioni del tema Shopify); { tipo: 'frase', k } e' l'esercizio "completa la frase" che
     scova la credenza limitante (piu' sotto: epiFrasePasso).
   · 0.9.307: le domande dell'Io Futuro che non stanno piu' nella chiamata (troppe tutte insieme) arrivano qui, una
     per episodio: passo {"nf": chiave}. Si apre la stessa schermata della chiamata (io-futuro-livello.js,
     nfDomandaEpisodio) e la risposta finisce in fl_iofuturo come le altre. Chi ha gia' risposto non la rivede.
   · Le azioni (il sabotatore, le pillole, l'Io Futuro, la strada, il piano) sono i pezzi veri
     dell'app: se la scelta c'e' gia', l'episodio la mostra e va avanti (Until Dawn: niente
     riavvolgimento). Se no l'episodio si mette in pausa, apre il pezzo, e riparte quando e' fatto.
   · Lo sblocco: un episodio al giorno; dal giorno 8 l'episodio del giorno si sblocca con la prima
     tappa reale della Mappa di quel giorno ("il tuo focus ha ricaricato la sfera").
   · Premium (dopo il lancio): le scene segnate "scena" si sostituiscono con quelle scritte
     dall'agente (fl_epi_scene), solo con content premium.attivo e fl_epi_personalizza accesi.
   =========================================================================================== */

const EPI_KEY = 'fl_epi';
const EPI = { cfg: null, carico: null, ep: null, i: 0, sub: '', rivedi: false, ladro: null, sab: {}, dopo: '', poll: 0, q: null, aperto: 0, indietro: false, giaDa: null, reazI: -9, pgS: 0, tSeg: 0, backOk: false };
const EPI_XP = 15;

/* IL TEMPO PASSATO NELL'EPISODIO (0.9.308), per il riquadro "Tempo" della schermata di fine. Si conta a pezzi: da quando
   l'episodio e' aperto e in primo piano fino a una pausa (un'azione, una domanda dell'Io Futuro, l'app in sottofondo, la X).
   Un pezzo vale al massimo 20 minuti, cosi' un telefono lasciato acceso sul tavolo non diventa un'ora di episodio. Il
   tempo dentro un'azione (la chiamata dell'Io Futuro, le pillole...) conta se l'episodio riparte entro mezz'ora.
   Sta in fl_epi.tempo[n] (rivedere: tempo['r' + n]); una visione nuova lo azzera. */
const EPI_SEG_MAX = 20 * 60000;
function epiTempoK(){ return (EPI.rivedi ? 'r' : '') + (EPI.ep ? EPI.ep.n : ''); }
function epiTempoSegna(){
  if (!EPI.ep || !EPI.tSeg) return;
  const seg = Math.min(Date.now() - EPI.tSeg, EPI_SEG_MAX); EPI.tSeg = 0;
  if (!(seg > 0)) return;
  const s = epiStato(); s.tempo = s.tempo || {}; const k = epiTempoK();
  s.tempo[k] = (s.tempo[k] || 0) + seg; epiSalva(s);
}
document.addEventListener('visibilitychange', function(){
  try{
    if (document.visibilityState === 'hidden') epiTempoSegna();
    else if (EPI.ep && !EPI.tSeg && EPI.sub !== 'fine' && epiSchermo() === 's-genio' && typeof GN !== 'undefined' && GN.on && GN.modo === 'epi') EPI.tSeg = Date.now();
  }catch(_){ }
});

/* ---------------------------------------------------------------- i contenuti */
function epiCarica(){
  if (EPI.cfg) return Promise.resolve(EPI.cfg);
  if (EPI.carico) return EPI.carico;
  EPI.carico = fetch('content/episodi.json', { cache: 'no-cache' })
    .then(function(r){ return r.ok ? r.json() : null; })
    .then(function(j){ EPI.cfg = j; epiApplicaIntro(); return j; })
    .catch(function(){ EPI.carico = null; return null; });
  /* i nomi dei blocchi, per chiamare il sabotatore con il suo nome */
  fetch('content/blocchi.json', { cache: 'no-cache' }).then(function(r){ return r.ok ? r.json() : null; }).then(function(j){
    ((j && j.blocchi) || []).forEach(function(b){ if (b && b.k) EPI.sab[b.k] = b.nome || ''; });
  }).catch(function(){ });
  return EPI.carico;
}
function epiEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function epiFill(s, v){
  s = String(s || '');
  if (v) Object.keys(v).forEach(function(k){ s = s.split('{' + k + '}').join(String(v[k])); });
  return s;
}
function epiUi(k, v){ const u = (EPI.cfg && EPI.cfg.ui) || {}; return epiFill(u[k] || '', v); }
/* i testi del primo avvio, per genio-intro.js: null se il file non c'e' (allora restano quelli di prima) */
function epiIntro(){ return (EPI.cfg && EPI.cfg.intro) || null; }
function epiIntroT(k, v){ const i = epiIntro(); return (i && typeof i[k] === 'string') ? epiFill(i[k], v) : ''; }
function epiApplicaIntro(){
  try{ const t = epiIntroT('sogno_domanda'); if (t && typeof GN_TESTI !== 'undefined') GN_TESTI.sogno_domanda = t; }catch(_){ }
}

/* ---------------------------------------------------------------- lo stato */
function epiStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(EPI_KEY) || 'null'); }catch(_){ }
  if (!s || typeof s !== 'object') s = {};
  s.visti = s.visti || {};
  return s;
}
function epiSalva(s){ try{ localStorage.setItem(EPI_KEY, JSON.stringify(s)); }catch(_){ } }
function epiK(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
/* chi ha gia' fatto il primo avvio ha visto l'episodio 1 (prima della 0.9.300 si chiamava "il film del Genio") */
function epiMigra(){
  const s = epiStato();
  if (s.visti[1]) return;
  let at = 0; try{ at = (typeof gnDati === 'function') ? (+gnDati().at || 0) : 0; }catch(_){ }
  if (!at) return;
  s.visti[1] = { at: at, giorno: epiK(at) }; epiSalva(s);
}
function epiSegnaVisto(n){
  const s = epiStato();
  if (!s.visti[n]) s.visti[n] = { at: Date.now(), giorno: epiK() };
  if (s.pos && s.pos.n === n) delete s.pos;
  epiSalva(s);
}
/** Il giorno del viaggio: 1 il giorno del primo avvio. */
function epiInizio(){
  const s = epiStato();
  if (s.visti[1] && s.visti[1].at) return s.visti[1].at;
  try{ const a = +gnDati().at; if (a) return a; }catch(_){ }
  try{ if (typeof evPrimoAvvio === 'function') return evPrimoAvvio(); }catch(_){ }
  return Date.now();
}
function epiGiorno(){
  const a = new Date(epiInizio()); a.setHours(12, 0, 0, 0);
  const b = new Date(); b.setHours(12, 0, 0, 0);
  return Math.round((b - a) / 86400000) + 1;
}
/** Vero se oggi un episodio e' gia' stato visto (della serie o della stagione 2): il prossimo e' domani. */
function epiVistoOggi(){
  const k = epiK(), s = epiStato();
  if (Object.keys(s.visti).some(function(n){ return s.visti[n] && s.visti[n].giorno === k; })) return true;
  try{ const f = dqStato().fatti; return Object.keys(f).some(function(n){ return /^\d+$/.test(n) && f[n] && f[n].giorno === k; }); }catch(_){ return false; }
}
/** Vero se oggi c'e' gia' una tappa reale della Mappa fatta (le mystery box non contano). */
function epiTappaOggi(){
  try{ if (typeof sdFatteOggi === 'function') return sdFatteOggi().some(function(nd){ return nd.tipo !== 'sc'; }); }catch(_){ }
  return false;
}
/** La data d'arrivo si vede: l'ha svelata l'episodio 7 (eta.js, evVelata). */
function epiDataSvelata(){ return !!epiStato().dataSvelata; }

/* ---------------------------------------------------------------- l'elenco */
function epiLista(){
  const out = [];
  const st = (EPI.cfg && EPI.cfg.stagioni) || [];
  st.forEach(function(S){ (S.episodi || []).forEach(function(e){ out.push({ s: S.s, n: e.n, titolo: e.titolo, vis: e.vis || 'sfera', tipo: 'epi', e: e }); }); });
  /* la stagione 2: gli episodi a domande di content/sentiero.json, nella scena di domande.js */
  try{ DQ_EPISODI.forEach(function(e){ if (e.stagione === 2 && typeof e.n === 'number') out.push({ s: 2, n: e.n, titolo: e.titolo, vis: 'sfera', tipo: 'dq' }); }); }catch(_){ }
  return out;
}
function epiVisto(x){
  if (x.tipo === 'dq'){ try{ return !!dqStato().fatti[x.n]; }catch(_){ return false; } }
  if (x.n === 1){ epiMigra(); }
  return !!epiStato().visti[x.n];
}
function epiStatoDi(lista, idx){
  const x = lista[idx];
  if (epiVisto(x)) return { k: 'visto' };
  const prima = lista[idx - 1];
  if (prima && !epiVisto(prima)) return { k: 'bloccato', motivo: epiUi('motivo_prima', { n: prima.n }) };
  if (epiVistoOggi()) return { k: 'domani', motivo: epiUi('motivo_domani') };
  if (epiGiorno() >= 8 && !epiTappaOggi()) return { k: 'tappa', motivo: epiUi('motivo_tappa') };
  const s = epiStato();
  if (x.tipo === 'epi' && ((s.pos && s.pos.n === x.n) || (s.sospeso && s.sospeso.n === x.n))) return { k: 'in-corso' };
  return { k: 'da-vedere' };
}
/** L'episodio di oggi: il primo non visto, con il suo stato. */
function epiOggi(){
  const l = epiLista();
  for (let i = 0; i < l.length; i++){ if (!epiVisto(l[i])) return { x: l[i], st: epiStatoDi(l, i), i: i, lista: l }; }
  return { x: null, lista: l };
}

/* ---------------------------------------------------------------- la card in Dream */
/* 0.9.301, Andrea sul pannello della 0.9.300: "mi fa schifo per come lo hai fatto". L'episodio di oggi non si
   distingueva (bordo solo sotto), meta' pannello a sinistra e meta' al centro, sparita la sfera accanto a "Il Genio ti
   conosce", la striscia attaccata al bordo. Il modello e' Zombies, Run!: in Dream la card della stagione con la sola
   copertina dell'episodio di oggi; toccandola si apre la pagina della serie (copertina, schede delle stagioni, episodi
   uno sotto l'altro, e in fondo i libri e i film per il viaggio). Tutto centrato. */
const EPI_LUCCHETTO = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const EPI_SPUNTA = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
const EPI_PLAY = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M7 4.5v15a1 1 0 0 0 1.52.85l12-7.5a1 1 0 0 0 0-1.7l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>';
const EPI_AVANTI = '<svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.5 4.5l5.5 5.5-5.5 5.5"/></svg>';
const EPI_INDIETRO = '<svg viewBox="0 0 17 14" width="18" height="15" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
/** La riga sotto al titolo: quella dell'episodio, o quella della stagione 2 (content/sentiero.json non ce l'ha). */
function epiSotto(x){
  if (!x) return '';
  if (x.e && x.e.sotto) return x.e.sotto;
  return String((((EPI.cfg && EPI.cfg.sottotitoli) || {})[x.n]) || '');
}
/** La copertina grande: l'immagine dell'episodio con stagione, numero e titolo sopra. */
function epiCopertinaHtml(x, chiusa){
  return '<div class="epi-cov' + (chiusa ? ' chiusa' : '') + '"><div class="epi-cov-art">' + epiVisHtml(x.vis) + '</div>'
    + (chiusa ? '<span class="epi-cov-lock">' + EPI_LUCCHETTO + '</span>' : '')
    + '<div class="epi-cov-txt"><small>' + epiEsc(epiUi('sigla', { s: x.s, n: x.n })) + '</small><b>' + epiEsc(x.titolo) + '</b></div></div>';
}
function epiConosceHtml(){
  let pct = 0; try{ pct = dqConoscenza(); }catch(_){ }
  return '<div class="epi-conosce"><span class="dq-card-ball">🔮</span><b>' + epiEsc(epiUi('conosce', { pct: pct })) + '</b></div>';
}
/* 0.9.304, Andrea: la card sta nella scheda "La tua storia" del pannello di Dream (rotta-tab.js). Con { pannello: true }
   niente titolo "La serie del Genio" (lo dice la linguetta) e niente "Il Genio ti conosce": quello sta nella scheda Identita'. */
function epiCardHtml(opz){
  const pann = !!(opz && opz.pannello);
  if (!EPI.cfg){ epiCarica().then(function(){ try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ } }); return ''; }
  epiMigra();
  try{ epiIspControlla(); }catch(_){ }
  const o = epiOggi();
  const lista = o.lista;
  /* lo sblocco con la tappa della Mappa si annuncia una volta sola */
  try{
    if (o.x && o.st.k !== 'tappa' && epiGiorno() >= 8 && epiTappaOggi() && !epiVistoOggi()){
      const s = epiStato(); if (s.annuncio !== epiK()){ s.annuncio = epiK(); epiSalva(s); setTimeout(function(){ try{ epiSferaAvviso(o.x.n); }catch(_){ } }, 600); }
    }
  }catch(_){ }
  const x = o.x || lista[lista.length - 1];
  if (!x) return '';
  const aperto = !!o.x && (o.st.k === 'da-vedere' || o.st.k === 'in-corso');
  let riga = '', btn = '';
  if (!o.x){
    riga = epiUi('riga_fine', { s: x.s });
  } else if (aperto){
    riga = epiSotto(x);
    btn = '<button type="button" class="am-cta epi-cta" onclick="event.stopPropagation();epiTocca(' + x.s + ',' + x.n + ')">' + EPI_PLAY + '<span>' + ((typeof drsSerieIniziata === 'function' && drsSerieIniziata()) ? 'Riprendi' : 'Inizia') + '</span></button>';
  } else if (o.st.k === 'tappa'){
    riga = o.st.motivo;
    btn = '<button type="button" class="am-cta epi-cta sec" onclick="event.stopPropagation();epiVaiMappa()">' + epiEsc(epiUi('cta_tappa')) + '</button>';
  } else {
    riga = o.st.motivo || epiUi('motivo_domani');
  }
  return '<div class="epi-card" id="epiCard" role="button" tabindex="0" onclick="epiSerieApri()">'
    + (pann ? '' : '<small class="epi-kick">' + epiEsc(epiUi('serie_kick')) + '</small>')
    + epiCopertinaHtml(x, !aperto && !!o.x)
    + (riga ? '<p class="epi-hook">' + epiEsc(riga) + (o.x && o.st.k === 'tappa' ? epiSferaInfoBtn() : '') + '</p>' : '')
    + btn
    + (pann ? '' : epiConosceHtml())
    + '<span class="epi-tutti">' + epiEsc(epiUi('card_tutti')) + EPI_AVANTI + '</span></div>';
}
/* la striscia di copertine non c'e' piu': rotta-tab.js la chiama ancora dopo il disegno */
function epiStripCentra(){ }
function epiVaiMappa(){ try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('rotta'); }catch(_){ } }
function epiTocca(s, n){
  const lista = epiLista();
  const idx = lista.findIndex(function(x){ return x.s === s && x.n === n; }); if (idx < 0) return;
  const x = lista[idx], st = epiStatoDi(lista, idx);
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  if (st.k === 'visto'){
    if (x.tipo === 'dq'){ try{ dqApriEp(n, true); }catch(_){ } return; }
    if (n === 1 || (x.e && x.e.primoAvvio)){ try{ if (typeof gnRivedi === 'function') gnRivedi(); }catch(_){ } return; }
    epiApri(n, { rivedi: true });
    return;
  }
  if (st.k === 'da-vedere' || st.k === 'in-corso'){
    if (x.tipo === 'dq'){ try{ dqApriEp(n, false); }catch(_){ } return; }
    const ss = epiStato();
    const da = (ss.sospeso && ss.sospeso.n === n) ? ss.sospeso.i : ((ss.pos && ss.pos.n === n) ? ss.pos.i : 0);
    /* 0.9.322, Andrea: "come su Netflix: riprendi o ricomincia" */
    if (da > 0 && typeof inSheet === 'function'){
      inSheet('<div class="am-sheet center drs-ri"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="drs-ri-ico" aria-hidden="true">🎬</span>'
        + '<b class="am-sh-title">Hai già iniziato questo episodio</b><p class="am-sh-p">Vuoi riprendere da dove avevi lasciato o rivederlo dall’inizio?</p>'
        + '<button type="button" class="nvs-cta" onclick="inSheetChiudi();epiApri(' + n + ',{ da: ' + da + ', senzaSigla: true })">Riprendi da dove avevi lasciato</button>'
        + '<button type="button" class="nvs-cta sec" onclick="inSheetChiudi();epiApri(' + n + ',{ da: 0, senzaSigla: false })">Ricomincia da capo</button></div>');
      return;
    }
    epiApri(n, { da: da, senzaSigla: da > 0 });
    return;
  }
  try{ toast(st.motivo || epiUi('motivo_domani')); }catch(_){ }
}

/* ---------------------------------------------------------------- la pagina della serie */
/* Come la pagina di una stagione di Zombies, Run!: la copertina in alto, le schede "Stagione 1 Stagione 2...", gli
   episodi uno sotto l'altro (miniatura con il numero nell'angolo, titolo, una riga che incuriosisce, lo stato). Le
   stagioni che non hanno ancora episodi si vedono, chiuse. In fondo i libri e i film del viaggio. */
registerScreen('s-serie', '<div class="epi-pg" id="epiPg"></div>');
function epiStagioni(){
  const l = epiLista(), ss = [];
  l.forEach(function(x){ if (ss.indexOf(x.s) < 0) ss.push(x.s); });
  if (!ss.length) ss.push(1);
  ss.push(ss[ss.length - 1] + 1);   /* la prossima, ancora senza episodi: si vede chiusa */
  return ss;
}
/** La stagione dell'episodio di oggi (l'ultima, se sono stati visti tutti). */
function epiStagioneOra(){
  const o = epiOggi();
  if (o.x) return o.x.s;
  return o.lista.length ? o.lista[o.lista.length - 1].s : 1;
}
async function epiSerieApri(s){
  await epiCarica();
  EPI.pgS = s || epiStagioneOra();
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  epiSeriePaint();
  goId('s-serie');
}
function epiSerieScheda(s){ EPI.pgS = s; try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ } epiSeriePaint(); }
function epiRigaEpHtml(x, st, oggi){
  const stato = st.k === 'visto' ? '<span class="epi-st visto">' + EPI_SPUNTA + epiEsc(epiUi('stato_visto')) + '</span>'
    : (st.k === 'da-vedere' || st.k === 'in-corso') ? '<span class="epi-st oggi">' + EPI_PLAY + epiEsc(epiUi(st.k === 'in-corso' ? 'stato_in_corso' : 'stato_oggi')) + '</span>'
    : '<span class="epi-st chiuso">' + EPI_LUCCHETTO + epiEsc(st.motivo || epiUi('motivo_domani')) + '</span>';
  const chiuso = !(st.k === 'visto' || st.k === 'da-vedere' || st.k === 'in-corso');
  return '<li' + (oggi ? ' class="oggi"' : '') + '><button type="button" class="epi-ep' + (oggi ? ' oggi' : '') + (chiuso ? ' chiuso' : '') + '" onclick="epiTocca(' + x.s + ',' + x.n + ')">'
    + '<span class="epi-th">' + epiVisHtml(x.vis, true) + '<i class="epi-th-n">' + x.n + '</i>' + (chiuso ? '<span class="epi-th-lock">' + EPI_LUCCHETTO + '</span>' : '') + '</span>'
    + '<span class="epi-ep-txt"><b>' + epiEsc(x.titolo) + '</b>' + (epiSotto(x) ? '<em>' + epiEsc(epiSotto(x)) + '</em>' : '') + stato + '</span></button></li>';
}
function epiSeriePaint(){
  const w = document.getElementById('epiPg'); if (!w) return;
  if (!EPI.cfg){ epiCarica().then(epiSeriePaint); return; }
  try{ epiIspControlla(); }catch(_){ }
  const lista = epiLista(), o = epiOggi(), ss = epiStagioni();
  const s = ss.indexOf(EPI.pgS) >= 0 ? EPI.pgS : epiStagioneOra();
  const della = lista.filter(function(x){ return x.s === s; });
  /* la copertina: l'episodio di oggi se e' di questa stagione, se no il primo della stagione */
  const cop = (o.x && o.x.s === s) ? o.x : (della[0] || o.x || lista[0] || { vis: 'sfera' });
  const tabs = ss.map(function(k){
    const vuota = !lista.some(function(x){ return x.s === k; });
    return '<button type="button" class="epi-tab' + (k === s ? ' on' : '') + (vuota ? ' vuota' : '') + '" onclick="epiSerieScheda(' + k + ')">' + (vuota ? EPI_LUCCHETTO : '') + '<span>' + epiEsc(epiUi('stagione', { s: k })) + '</span></button>';
  }).join('');
  let corpo = '';
  if (della.length){
    corpo = '<ol class="epi-lista">' + della.map(function(x){ const idx = lista.indexOf(x); return epiRigaEpHtml(x, epiStatoDi(lista, idx), !!(o.x && o.x.s === x.s && o.x.n === x.n)); }).join('') + '</ol>';
  } else {
    corpo = '<div class="epi-vuota">' + EPI_LUCCHETTO + '<p>' + epiEsc(epiUi('stagione_chiusa', { s: s, p: s - 1 })) + '</p></div>';
  }
  w.innerHTML = '<div class="epi-hero"><div class="epi-hero-art">' + epiVisHtml(cop.vis || 'sfera') + '</div>'
    + '<div class="epi-hero-top"><button type="button" class="epi-hero-back" onclick="flIndietro()" aria-label="Indietro">' + EPI_INDIETRO + '</button><b>' + epiEsc(epiUi('pagina_titolo')) + '</b></div></div>'
    + epiConosceHtml()
    + '<div class="epi-tabs" role="tablist">' + tabs + '</div>'
    + corpo
    + ((typeof gfGiochiHtml === 'function') ? gfGiochiHtml() : '')
    + epiIspHtml(ss);
  epiIspDopoDisegno();
}
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-serie') epiSeriePaint(); });

/* ---------------------------------------------------------------- libri e film per il viaggio */
/* Andrea, 24/10/2026: "se metti un film come compito, diventa la scusa perfetta per procrastinare". E' un premio, con
   tre regole: 1. si sblocca dopo un boss (la sfida del Genio vinta sulla Mappa, fl_sd_boss_<capitolo>) o quando il
   Genio vede un calo di motivazione (umore Malissimo o Storta, oggi o ieri: fl_umore); 2. uno per stagione; 3. dopo,
   una prova: un'azione ispirata entro 24 ore, che si segna fatta. Il film diventa benzina, non un parcheggio.
   I titoli stanno in content/episodi.json (ispirazione), per tipo di sogno. Lo stato in fl_epi_isp, per stagione. */
const EPI_ISP_KEY = 'fl_epi_isp';
const EPI_ISP_ORE = 24;
function epiIspStato(){ let o = null; try{ o = JSON.parse(localStorage.getItem(EPI_ISP_KEY) || 'null'); }catch(_){ } return (o && typeof o === 'object') ? o : {}; }
function epiIspSalva(o){ try{ localStorage.setItem(EPI_ISP_KEY, JSON.stringify(o)); }catch(_){ } }
/** Il titolo della stagione s per il tuo tipo di sogno (quello gia' sbloccato resta quello, anche se cambi sogno). */
function epiIspOpera(s){
  const fissato = epiIspStato()[s]; if (fissato && fissato.opera) return fissato.opera;
  const C = (EPI.cfg && EPI.cfg.ispirazione) || {};
  let k = ''; try{ k = (typeof gnDati === 'function' && gnDati().sognoK) || ''; }catch(_){ }
  const l = (Array.isArray(C[k]) && C[k].length) ? C[k] : (C.generico || []);
  /* 0.9.317: con quello che ha detto al Genio (genio-film.js) la sorpresa si avvicina ai suoi gusti: prima fra quelle del suo sogno, poi fra tutte */
  try{
    if (typeof gfPreferita === 'function'){
      const tutte = Object.keys(C).filter(function(x){ return Array.isArray(C[x]); }).reduce(function(a, x){ return a.concat(C[x]); }, []);
      const m = gfPreferita(l) || gfPreferita(tutte);
      if (m) return m;
    }
  }catch(_){ }
  return l.length ? l[(s - 1) % l.length] : null;
}
/** Quando e' cominciata la stagione s: il primo giorno del viaggio, o l'ultimo episodio della stagione prima. */
function epiStagioneInizio(s){
  if (s <= 1) return epiInizio();
  const prima = epiLista().filter(function(x){ return x.s === s - 1; });
  const u = prima[prima.length - 1]; if (!u) return Infinity;
  if (u.tipo === 'dq'){ try{ const f = dqStato().fatti[u.n]; return (f && f.at) || Infinity; }catch(_){ return Infinity; } }
  const v = epiStato().visti[u.n]; return (v && v.at) || Infinity;
}
/** Il segnale che sblocca il premio dopo l'inizio della stagione: un boss battuto, o un umore basso oggi o ieri. */
function epiIspSegnale(da){
  if (!isFinite(da)) return null;
  let boss = 0;
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i); if (!/^fl_sd_boss_/.test(k)) continue;
      const t = +localStorage.getItem(k) || 0;
      if (t >= da && (!boss || t < boss)) boss = t;
    }
  }catch(_){ }
  if (boss) return { motivo: 'boss', at: boss };
  try{
    const U = JSON.parse(localStorage.getItem('fl_umore') || '{}') || {};
    for (let off = 0; off < 2; off++){
      const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - off);
      const v = U[epiK(d.getTime())];
      if (v && +v.sodd >= 1 && +v.sodd <= 2 && (+v.at || d.getTime()) >= da) return { motivo: 'calo', at: +v.at || Date.now() };
    }
  }catch(_){ }
  return null;
}
/** Controlla il premio della stagione di oggi: se arriva il segnale, si sblocca (una volta sola) e si annuncia. */
function epiIspControlla(){
  if (!EPI.cfg || !EPI.cfg.ispirazione) return false;
  const s = epiStagioneOra(), o = epiIspStato();
  if (o[s]) return false;
  const sig = epiIspSegnale(epiStagioneInizio(s)); if (!sig) return false;
  const op = epiIspOpera(s); if (!op) return false;
  o[s] = { motivo: sig.motivo, at: Date.now(), opera: op };
  epiIspSalva(o);
  setTimeout(function(){ try{ toast(epiUi('isp_toast', { s: s })); }catch(_){ } }, 700);
  return true;
}
/* 0.9.317, Andrea: "ti restano 24 ore per la prova e' un'interrogazione, fa schifo". Niente piu' scadenza: c'e' una conversazione con il Genio. */
function epiIspScaduta(x){ return false; }
function epiIspVisto(s){
  const o = epiIspStato(); if (!o[s] || o[s].vistoAt) return;
  o[s].vistoAt = Date.now(); epiIspSalva(o);
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  EPI.ispSel = s; epiIspRidisegna(); epiIspScorri();
}
function epiIspProva(s){
  const a = document.getElementById('epiIspArea'), t = String(a ? a.value : '').trim();
  if (!t){ try{ toast(epiUi('isp_vuoto')); if (a) a.focus(); }catch(_){ } return; }
  const o = epiIspStato(); if (!o[s] || !o[s].vistoAt || epiIspScaduta(o[s])) return;
  o[s].azione = { t: t, at: Date.now() }; epiIspSalva(o);
  try{ if (typeof flVibra === 'function') flVibra([20, 40, 60]); }catch(_){ }
  EPI.ispSel = s; epiIspRidisegna(); epiIspScorri();
}
function epiIspScorri(){ try{ const c = document.getElementById('epiIspDet'); if (c) c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }catch(_){ } }
/* 0.9.302, Andrea sui pannelli della 0.9.301: "stai gia' spoilerando quale sara' il film consigliato... troppo testo... i pannelli
   bianchi fanno cagare". Adesso e' una fila di copertine coperte, scure come la copertina della serie. Finche' il premio non si
   sblocca il titolo NON c'e' nemmeno nella pagina (si legge solo da fl_epi_isp, dove entra allo sblocco): la copertina dice la
   stagione e una riga sola su cosa la apre. Allo sblocco si gira, una volta sola, quando e' davvero sullo schermo (rivelato).
   Sotto la fila, solo per la copertina scelta, il dettaglio: il pulsante della prova, il campo, la prova fatta. */
/** La fase del premio della stagione s: futuro | chiuso | perso | nuovo | prova | fatta | scaduta. */
function epiIspFase(s, ora){
  const st = epiIspStato()[s] || null;
  if (s > ora) return 'futuro';
  if (!st || !st.opera) return s === ora ? 'chiuso' : 'perso';
  if (st.azione) return 'fatta';
  if (epiIspScaduta(st)) return 'scaduta';
  if (st.vistoAt) return 'prova';
  return 'nuovo';
}
function epiIspCoperta(f){ return f === 'futuro' || f === 'chiuso' || f === 'perso'; }
function epiIspCopHtml(s, ora){
  const f = epiIspFase(s, ora), coperta = epiIspCoperta(f);
  const st = epiIspStato()[s] || null;
  const op = coperta ? null : st.opera;
  const sel = !coperta && EPI.ispSelOra === s;
  const rivela = !coperta && !st.rivelato;
  const riga = f === 'chiuso' ? epiUi('isp_chiuso') : (f === 'perso' ? epiUi('isp_perso') : '');
  const segno = f === 'futuro' ? '<i class="epi-isp-mist lucchetto">' + EPI_LUCCHETTO + '</i>' : '<i class="epi-isp-mist">?</i>';
  let fronte = '';
  if (op){
    const libro = op.tipo === 'libro';
    const badge = f === 'fatta' ? '<em class="epi-isp-badge ok">' + EPI_SPUNTA + epiEsc(epiUi('isp_badge_fatta')) + '</em>'
      : f === 'prova' ? '<em class="epi-isp-badge">' + epiEsc(epiUi('isp_badge_prova')) + '</em>'
      : f === 'scaduta' ? '<em class="epi-isp-badge spento">' + epiEsc(epiUi('isp_badge_scaduta')) + '</em>'
      : '<em class="epi-isp-badge nuovo">' + epiEsc(epiUi('isp_badge_nuovo')) + '</em>';
    fronte = '<span class="epi-isp-faccia epi-isp-fronte"><small>' + epiEsc(epiUi(libro ? 'isp_libro' : 'isp_film')) + '</small>'
      + '<i class="epi-isp-emo">' + (libro ? '📖' : '🎬') + '</i><b>' + epiEsc(op.t) + '</b>' + badge + '</span>';
  }
  const aria = coperta ? epiUi('stagione', { s: s }) + '. ' + (riga || epiUi('isp_futuro_toast', { s: s })) : epiUi('stagione', { s: s }) + '. ' + op.t;
  return '<button type="button" class="epi-isp-cop f-' + f + (coperta ? '' : (rivela ? ' da-rivelare' : ' aperta')) + (sel ? ' sel' : '') + (s === ora ? ' ora' : '') + '" data-s="' + s + '" onclick="epiIspTocca(' + s + ')" aria-label="' + epiEsc(aria) + '">'
    + '<span class="epi-isp-giro"><span class="epi-isp-faccia epi-isp-retro">' + segno + (riga ? '<em>' + epiEsc(riga) + '</em>' : '') + '</span>' + fronte + '</span>'
    + '<span class="epi-isp-lab">' + epiEsc(epiUi('stagione', { s: s })) + '</span></button>';
}
/** Il dettaglio della copertina scelta, sotto la fila: solo per un premio gia' sbloccato. */
function epiIspDetHtml(s, ora){
  const f = epiIspFase(s, ora); if (epiIspCoperta(f)) return '';
  const st = epiIspStato()[s], op = st.opera, libro = op.tipo === 'libro';
  let corpo = '';
  if (f === 'nuovo'){
    corpo = '<p class="epi-isp-perche">' + epiEsc(op.perche || '') + '</p>'
      + '<p class="epi-isp-nota">' + epiEsc(epiUi(libro ? 'isp_come_libro' : 'isp_come_film')) + '</p>'
      + '<button type="button" class="am-cta epi-isp-btn" onclick="epiIspVisto(' + s + ')">' + epiEsc(epiUi(libro ? 'isp_visto_libro' : 'isp_visto_film')) + '</button>';
  } else if (f === 'prova'){
    corpo = '<p class="epi-isp-nota">' + epiEsc(epiUi(libro ? 'isp_parla_libro' : 'isp_parla_film')) + '</p>'
      + '<button type="button" class="am-cta epi-isp-btn" onclick="if(typeof gfApri===\'function\')gfApri(' + s + ')">' + epiEsc(epiUi('isp_parla_ok')) + '</button>';
  } else if (f === 'fatta'){
    corpo = '<p class="epi-isp-ok">' + EPI_SPUNTA + epiEsc(epiUi(libro ? 'isp_fatta_libro' : 'isp_fatta')) + '</p><blockquote>' + epiEsc(st.azione.t) + '</blockquote>';
  } else {
    corpo = '<p class="epi-isp-nota">' + epiEsc(epiUi('isp_scaduta', { s: s + 1 })) + '</p>';
  }
  const motivo = f === 'nuovo' ? '<small>' + epiEsc(epiUi(st.motivo === 'boss' ? 'isp_motivo_boss' : 'isp_motivo_calo')) + '</small>' : '';
  /* finche' la copertina non si e' girata, il dettaglio (che ha il titolo) aspetta: la sorpresa la fa la copertina */
  return '<div class="epi-isp-det' + (st.rivelato ? '' : ' in-attesa') + '" id="epiIspDet">' + motivo + '<h3>' + epiEsc(op.t) + '</h3>'
    + '<span class="epi-isp-di">' + epiEsc(epiUi(libro ? 'isp_di_libro' : 'isp_di_film', { autore: op.autore || '', anno: op.anno || '' })) + '</span>' + corpo + '</div>';
}
function epiIspHtml(ss){
  if (!EPI.cfg || !EPI.cfg.ispirazione) return '';
  const ora = epiStagioneOra(), lista = ss || epiStagioni();
  /* la copertina aperta di default: quella che aspetta qualcosa da te (premio nuovo o prova in corso) */
  let sel = EPI.ispSel;
  if (sel === undefined){ sel = 0; lista.forEach(function(s){ const f = epiIspFase(s, ora); if (!sel && (f === 'nuovo' || f === 'prova')) sel = s; }); }
  EPI.ispSelOra = sel || 0;
  return '<section class="epi-isp" id="epiIsp"><h2>' + epiEsc(epiUi('isp_titolo')) + '</h2><p class="epi-isp-sotto">' + epiEsc(epiUi('isp_sotto')) + '</p>'
    /* data-cg-no: le copertine sono scure in tutti e due i temi e il testo e' bianco fisso; la guardia del contrasto
       (darkfix.js) non legge il gradiente e scuriva il punto di domanda */
    + '<div class="epi-isp-fila" data-cg-no>' + lista.map(function(s){ return epiIspCopHtml(s, ora); }).join('') + '</div>'
    + (sel ? epiIspDetHtml(sel, ora) : '') + '</section>';
}
/** Ridisegna solo la sezione del premio (il resto della pagina resta dov'e'). */
function epiIspRidisegna(){
  const v = document.getElementById('epiIsp'); if (!v){ epiSeriePaint(); return; }
  const t = document.createElement('div'); t.innerHTML = epiIspHtml();
  const n = t.firstElementChild; if (!n) return;
  v.parentNode.replaceChild(n, v);
  epiIspDopoDisegno();
}
function epiIspTocca(s){
  const ora = epiStagioneOra(), f = epiIspFase(s, ora);
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  if (epiIspCoperta(f)){
    try{ toast(f === 'chiuso' ? epiUi('isp_chiuso_toast', { s: s }) : f === 'perso' ? epiUi('isp_perso_toast', { s: s }) : epiUi('isp_futuro_toast', { s: s })); }catch(_){ }
    const b = document.querySelector('#epiIsp .epi-isp-cop[data-s="' + s + '"]');
    if (b){ b.classList.remove('scuoti'); void b.offsetWidth; b.classList.add('scuoti'); }
    return;
  }
  EPI.ispSel = (EPI.ispSelOra === s) ? 0 : s;
  epiIspRidisegna();
  if (EPI.ispSel) epiIspScorri();
}
/** Dopo il disegno: il microfono sul campo della prova, e la rivelazione delle copertine appena sbloccate. */
function epiIspDopoDisegno(){
  try{ if (typeof micAvvolgi === 'function'){ const a = document.getElementById('epiIspArea'); if (a && a.parentNode) micAvvolgi(a.parentNode); } }catch(_){ }
  const da = document.querySelectorAll('#epiIsp .epi-isp-cop.da-rivelare'); if (!da.length) return;
  const gira = function(b){
    if (!b.classList.contains('da-rivelare')) return;
    b.classList.remove('da-rivelare'); b.classList.add('aperta', 'luce');
    const s = +b.dataset.s, o = epiIspStato(); if (o[s] && !o[s].rivelato){ o[s].rivelato = Date.now(); epiIspSalva(o); }
    try{ if (typeof flVibra === 'function') flVibra([10, 60, 18]); }catch(_){ }
    setTimeout(function(){ b.classList.remove('luce'); }, 1600);
    setTimeout(function(){ const d = document.querySelector('#epiIspDet.in-attesa'); if (d && EPI.ispSelOra === s) d.classList.remove('in-attesa'); }, 950);
  };
  /* si gira quando la copertina e' davvero sullo schermo, non mentre e' ancora in fondo alla pagina */
  if (typeof IntersectionObserver !== 'function'){ da.forEach(function(b){ setTimeout(function(){ gira(b); }, 500); }); return; }
  const io = new IntersectionObserver(function(es){
    es.forEach(function(e){ if (e.isIntersecting && e.intersectionRatio >= 0.6){ io.unobserve(e.target); setTimeout(function(){ gira(e.target); }, 450); } });
  }, { threshold: [0.6] });
  da.forEach(function(b){ io.observe(b); });
}

/* ---------------------------------------------------------------- le immagini delle schermate */
/* Disegnate con il CSS, niente file: la luce, le luci che si spengono, la sfera accesa e spenta,
   l'ombra, il telefono dei ladri, le pillole, la chiamata, il bivio, la mappa. */
function epiVisHtml(t, mini){
  const pos = [[22, 30], [70, 22], [48, 58], [14, 66], [84, 60], [36, 18], [60, 78], [28, 84], [78, 40], [54, 34], [8, 42], [92, 82]];
  let h = '';
  if (t === 'luce') h = '<i class="epi-luce"></i>';
  else if (t === 'luci' || t === 'luci-spente') h = pos.map(function(p, k){ return '<i class="epi-luce p" style="left:' + p[0] + '%;top:' + p[1] + '%;--d:' + (k * 0.35).toFixed(2) + 's"></i>'; }).join('');
  else if (t === 'sfera' || t === 'sfera-spenta') h = '<i class="epi-sfera"></i>';
  /* 0.9.331, Andrea: "la palla scura non si capisce cosa sia". E' il ladro dentro la testa: la testa, dentro la mascherina da ladro, e dalla bocca esce la sua voce, che e' la tua */
  /* 0.9.342, Andrea: "la testa e' di profilo e la maschera e' frontale, sembra Arlecchino: nessun ladro va in giro con quella roba rossa".
     Il ladro classico, di fronte: berretto, mascherina scura sugli occhi, maglia a righe. */
  else if (t === 'ombra') h = '<svg class="epi-ladro" viewBox="0 0 200 200" aria-hidden="true"><defs><clipPath id="epiLdC"><path d="M34 200c2-38 30-60 66-60s64 22 66 60z"/></clipPath></defs>'
    + '<path class="corpo" d="M34 200c2-38 30-60 66-60s64 22 66 60z"/><g clip-path="url(#epiLdC)" class="righe"><rect x="0" y="160" width="200" height="10"/><rect x="0" y="182" width="200" height="10"/></g>'
    + '<circle class="viso" cx="100" cy="98" r="44"/><path class="cuffia" d="M55 86c0-31 20-52 45-52s45 21 45 52z"/><rect class="risvolto" x="51" y="74" width="98" height="17" rx="8.5"/><circle class="pon" cx="100" cy="31" r="9"/>'
    + '<path class="nodo" d="M56 99l-14-7M56 104l-14 5"/><path class="masch" d="M54 103c0-8 6-13 14-13h64c8 0 14 5 14 13s-6 14-14 14c-12 0-19-6-32-6s-20 6-32 6c-8 0-14-6-14-14z"/>'
    + '<ellipse class="occhio" cx="79" cy="103" rx="9" ry="6"/><ellipse class="occhio" cx="121" cy="103" rx="9" ry="6"/><g class="pupille"><circle cx="80" cy="104" r="3.4"/><circle cx="122" cy="104" r="3.4"/></g>'
    + '<path class="bocca" d="M88 126c8 4 17 4 25-2"/></svg>';
  else if (t === 'telefono') h = '<span class="epi-tel"><i></i><b>3</b><b class="b2">9</b><b class="b3">1</b></span>';
  else if (t === 'pillole') h = '<span class="epi-pill rossa"></span><span class="epi-pill blu"></span>';
  else if (t === 'chiamata') h = '<span class="epi-onda"></span><span class="epi-onda o2"></span><svg class="epi-cornetta" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg>';
  else if (t === 'bivio') h = '<svg class="epi-bivio" viewBox="0 0 120 120" aria-hidden="true"><path class="tronco" d="M60 118V70"/><path class="sx" d="M60 72C60 52 34 44 22 10"/><path class="dx" d="M60 72C60 52 86 44 98 10"/></svg>';
  else if (t === 'mappa') h = '<svg class="epi-mappa" viewBox="0 0 120 120" aria-hidden="true"><path d="M18 104C40 96 30 74 56 70S88 52 74 34 98 14 104 14"/><circle cx="18" cy="104" r="6"/><circle cx="56" cy="70" r="6"/><circle cx="74" cy="34" r="6"/><circle class="arrivo" cx="104" cy="14" r="8"/></svg>';
  else h = '<i class="epi-sfera"></i>';
  return '<div class="epi-vis v-' + epiEsc(t) + (mini ? ' mini' : '') + '">' + h + '</div>';
}
function epiGenioImg(){
  const sopra = document.getElementById('gnSopra'); if (!sopra) return;
  if (!document.getElementById('gnGenio')) sopra.innerHTML = '<img class="gn-genio" id="gnGenio" src="img/genio/genio-pensa.png" alt="">';
}
/** La schermata: un'immagine (vis) a tutto cielo con il testo bianco, oppure il Genio con la nuvoletta. */
function epiScena(p){
  const sc = document.getElementById('gnScena'), sopra = document.getElementById('gnSopra');
  if (p && p.vis){
    if (sopra) sopra.innerHTML = epiVisHtml(p.vis);
    if (sc) sc.classList.add('epi-cine');
  } else {
    epiGenioImg();
    if (sc) sc.classList.remove('epi-cine');
    try{ gnPosa((p && p.posa) || 'pensa'); }catch(_){ }
  }
}

/* ---------------------------------------------------------------- i dati veri */
/* IL LADRO: l'app che negli ultimi sette giorni si e' presa piu' tempo (non DreamMap, non il telefono stesso). */
const EPI_NON_LADRI = /launcher|systemui|\.home$|inputmethod|keyboard|settings|dreambrothers|focuslock|packageinstaller|permissioncontroller/i;
async function epiLadroLeggi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return null;
    const g = NATIVE.isUsageAccessGranted ? await NATIVE.isUsageAccessGranted() : { granted: true };
    if (!g || !g.granted) return null;
    const d0 = new Date(); d0.setHours(0, 0, 0, 0);
    const da = d0.getTime() - 6 * 86400000, a = Date.now();
    const r = await (typeof mwTelefono === 'function' ? mwTelefono('getTopApps', { from: da, to: a, limit: 15 }) : NATIVE.getTopApps({ from: da, to: a, limit: 15 }));
    const app = ((r && r.apps) || []).filter(function(x){ return x && !x.self && x.ms > 0 && !EPI_NON_LADRI.test((x.packageName || '') + ' ' + (x.label || '')); })[0];
    if (!app) return null;
    const giorni = Math.max(1, (a - da) / 86400000);
    const min = app.ms / 60000 / giorni;
    if (min < 1) return null;
    return { nome: app.label || app.packageName, min: min, tempo: (typeof gnDurataTxt === 'function') ? gnDurataTxt(min) : Math.round(min) + ' minuti' };
  }catch(_){ return null; }
}
function epiSabotatore(){
  try{ const b = (typeof bqLeggi === 'function') ? bqLeggi() : null; if (b && b.primario) return EPI.sab[b.primario] || ''; }catch(_){ }
  return '';
}
function epiPillola(){ try{ const p = faSevera(); return p && p.scelta ? p.scelta : ''; }catch(_){ return ''; } }
/* 0.9.347, Andrea: "l'episodio Le due strade arriva dopo che ho gia' creato il piano su misura: sembra di tornare indietro nella storia".
   Chi ha gia' una roadmap scritta dal suo agente ha gia' scelto la strada tracciata, anche senza la farfalla */
function epiStrada(){
  try{ const u = faStrada(); if (u && u.scelta) return u.scelta; }catch(_){ }
  try{ const rm = JSON.parse(localStorage.getItem('fl_roadmap_agente') || 'null'); if (rm && (rm.passi || rm.capitoli || rm.oggi || rm.settimana)) return 'rotta'; }catch(_){ }
  return '';
}
function epiDati(){
  let sogno = ''; try{ const L = gnLettura(); sogno = (L.sognoBreve && L.sognoBreve !== 'il tuo sogno') ? L.sognoBreve : ''; }catch(_){ }
  let vecchio = 'il vecchio te'; try{ vecchio = gnNomi().vecchio; }catch(_){ }
  const pil = epiPillola(), str = epiStrada();
  return {
    sogno: sogno,
    /* il sogno dentro a una frase ("Vorrei avviare la mia attivita', ma"): quello scritto a mano perde la maiuscola */
    sogno_frase: /^[A-ZÀ-Ý][a-zà-ÿ’' ]/.test(sogno) ? sogno.charAt(0).toLowerCase() + sogno.slice(1) : sogno,
    vecchio: vecchio,
    sabotatore: epiSabotatore(),
    pillola: pil ? ((typeof FA_PILLOLE !== 'undefined' && FA_PILLOLE[pil]) || '').toLowerCase() : '',
    strada: str ? ((typeof FA_NOMI !== 'undefined' && FA_NOMI[str]) || '') : '',
    ladro: EPI.ladro ? EPI.ladro.nome : '',
    ladro_tempo: EPI.ladro ? EPI.ladro.tempo : '',
    /* 0.9.344: quello che ha scritto negli esercizi "completa la frase", per le frasi che lo riprendono */
    credenza: epiFraseBreve('credenza'),
    paura_successo: epiFraseBreve('paura'),
    azione_contro: epiFraseBreve('impegno_azione'),
    impegno: epiFraseBreve('impegno')
  };
}
/** Un testo qualsiasi con i dati veri. Se un dato manca si usa alt; senza alt null (il passo si salta). */
function epiRiempi(t, alt){
  if (!t) return null;
  const dati = epiDati();
  let manca = false;
  const out = String(t).replace(/\{([a-z_]+)\}/g, function(m, k){ if (Object.prototype.hasOwnProperty.call(dati, k)){ if (!dati[k]) manca = true; return dati[k]; } return m; });
  if (!manca) return out;
  return alt ? alt : null;
}
/** Il testo di un passo con i dati veri. Se un dato manca si usa "alt"; senza alt il passo si salta (null). */
function epiTesto(p, chiave){
  const t = p[chiave || 't']; if (!t) return null;
  return epiRiempi(t, p.alt);
}
function epiSeOk(p){
  if (!p || !p.se) return true;
  const se = String(p.se);
  if (se === 'data') return !!EPI.dataOk;
  const m = se.match(/^(pillola|strada)(!?=)(\w+)$/); if (!m) return true;
  const v = m[1] === 'pillola' ? epiPillola() : epiStrada();
  /* 0.9.347: "strada=nessuna" = non l'ha ancora scelta (ne' con la farfalla ne' creando il piano su misura) */
  const cerca = m[3] === 'nessuna' ? '' : m[3];
  return m[2] === '=' ? v === cerca : v !== cerca;
}
/* PREMIUM, ALLA UNTIL DAWN (struttura, spenta): una scena riscritta dall'agente prende il posto di quella scritta a mano */
function epiPersonalizza(){
  try{ if (!(EPI.cfg && EPI.cfg.premium && EPI.cfg.premium.attivo)) return false; }catch(_){ return false; }
  try{ if (localStorage.getItem('fl_epi_personalizza') !== '1') return false; }catch(_){ return false; }
  try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; }
}
function epiPassi(ep){
  const base = (ep && ep.passi) || [];
  if (!epiPersonalizza()) return base;
  let sc = {}; try{ sc = (JSON.parse(localStorage.getItem('fl_epi_scene') || '{}') || {})[ep.n] || {}; }catch(_){ sc = {}; }
  const out = []; const fatte = {};
  base.forEach(function(p){
    if (p.scena && Array.isArray(sc[p.scena]) && sc[p.scena].length){
      if (fatte[p.scena]) return;
      fatte[p.scena] = true;
      sc[p.scena].forEach(function(t){ out.push(Object.assign({}, p, { t: String(t), alt: '' })); });
      return;
    }
    out.push(p);
  });
  return out;
}

/* ---------------------------------------------------------------- aprire e chiudere */
function epiTrova(n){
  const st = (EPI.cfg && EPI.cfg.stagioni) || [];
  for (let i = 0; i < st.length; i++){ const e = (st[i].episodi || []).filter(function(x){ return x.n === n; })[0]; if (e) return Object.assign({ s: st[i].s }, e); }
  return null;
}
async function epiApri(n, opz){
  opz = opz || {};
  await epiCarica();
  const ep = epiTrova(n); if (!ep || !ep.passi || typeof GN === 'undefined') return false;
  EPI.pcOra = false;
  EPI.ep = ep; EPI.passi = epiPassi(ep); EPI.i = Math.max(0, Math.min(EPI.passi.length, opz.da || 0)); EPI.rivedi = !!opz.rivedi; EPI.dopo = ''; EPI.sub = ''; EPI.dataOk = false; EPI.lez = null;
  EPI.aperto = Date.now(); EPI.indietro = false; EPI.giaDa = null; EPI.reazI = -9;
  EPI.ladro = null; epiLadroLeggi().then(function(l){ EPI.ladro = l; });
  EPI.specchio = false; EPI.fraseRifai = false;
  /* 0.9.344: se l'episodio ha una scena a scorrimento, le sue librerie si leggono adesso (episodi-scroll.js) */
  try{ if (typeof scnPrepara === 'function' && EPI.passi.some(function(x){ return x && x.tipo === 'scroll' && x.stile !== 'nuvole'; })) scnPrepara(); }catch(_){ }
  const s = epiStato();
  /* il tempo dell'episodio: una visione da capo lo azzera; una ripresa dopo un'azione aggiunge il tempo passato li' */
  s.tempo = s.tempo || {}; const kT = epiTempoK();
  if (!(opz.da > 0)) s.tempo[kT] = 0;
  else if (s.sospeso && s.sospeso.n === n && s.sospeso.at){ const fuori = Date.now() - s.sospeso.at; if (fuori > 0 && fuori < 30 * 60000) s.tempo[kT] = (s.tempo[kT] || 0) + fuori; }
  if (s.sospeso && s.sospeso.n === n) delete s.sospeso;
  epiSalva(s);
  EPI.tSeg = Date.now();
  GN.on = true; GN.modo = 'epi'; GN.audio = true;
  goId('s-genio');
  epiBarra();
  try{ gnAu.musica(); }catch(_){ }
  if (EPI.i === 0 && !opz.senzaSigla){ epiSigla(); return true; }
  gnVai('epi');
  return true;
}
function epiBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  const tot = (EPI.passi || []).length || 1;
  if (bar) bar.style.width = Math.round(Math.min(tot, EPI.i) / tot * 100) + '%';
  if (txt && EPI.ep) txt.textContent = epiUi('sigla', { s: EPI.ep.s, n: EPI.ep.n }) + ' · ' + EPI.ep.titolo;
}
/* LA SIGLA: la cornice fissa della serie. Stagione, numero, titolo, il colpo della sfera. */
function epiSigla(cfg){
  const sc = document.getElementById('gnScena'); if (!sc) return;
  cfg = cfg || { s: EPI.ep.s, n: EPI.ep.n, titolo: EPI.ep.titolo, vis: EPI.ep.vis };
  const r = document.getElementById('gnRisp'); if (r) r.innerHTML = '';
  const tx = document.getElementById('gnTesto'); if (tx) tx.innerHTML = '';
  let w = document.getElementById('epiSigla');
  if (!w){ w = document.createElement('div'); w.id = 'epiSigla'; w.className = 'epi-sigla'; sc.appendChild(w); }
  w.innerHTML = epiVisHtml(cfg.vis || 'sfera') + '<small>' + epiEsc(epiUi('sigla', { s: cfg.s, n: cfg.n })) + '</small><b>' + epiEsc(cfg.titolo) + '</b><span>' + epiEsc(epiUi('tocca')) + '</span>';
  w.onclick = function(e){ e.stopPropagation(); epiSiglaVia(cfg.poi); };
  w.hidden = false; w.classList.remove('via'); void w.offsetWidth; w.classList.add('su');
  try{ gnAu.punto(); gnVibra([20, 40, 20]); }catch(_){ }
}
function epiSiglaVia(poi){
  const w = document.getElementById('epiSigla'); if (!w || w.hidden) return;
  w.classList.add('via');
  setTimeout(function(){ w.hidden = true; w.classList.remove('su', 'via'); }, 420);
  if (typeof poi === 'function'){ poi(); return; }
  gnVai('epi');
}
function epiChiudi(){
  epiTempoSegna();
  try{ if (typeof scnChiudi === 'function') scnChiudi(); }catch(_){ }
  EPI.specchio = false;
  try{ gnAu.musicaOff(); }catch(_){ }
  const w = document.getElementById('epiSigla'); if (w) w.hidden = true;
  const dopo = EPI.dopo;
  GN.on = false; GN.modo = ''; EPI.ep = null; EPI.dopo = '';
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('epi-cine', 'molte', 'carte', 'domanda', 'epi-frase');
  try{ const sg = document.getElementById('s-genio'); if (sg) sg.classList.remove('domanda'); }catch(_){ }
  epiGenioImg();
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home');
  try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
  try{ if (typeof snTick === 'function') snTick(); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
  if (dopo) setTimeout(function(){ epiDopoApri(dopo); }, 450);
}
function epiDopoApri(k){
  try{
    if (k === 'piano' && typeof sdPianoApri === 'function'){ switchTab('mappa'); sdPianoApri(); }
    if (k === 'severa' && typeof svpApri === 'function') svpApri();
    if (k === 'albero' && typeof amApri === 'function') amApri();
    if (k === 'pc') epiPcApri();
  }catch(_){ }
}
/* il tasto indietro del telefono e la freccia: la schermata prima dell'episodio */
function epiIndietro(){
  if (!EPI.ep) return false;
  /* 0.9.344: la scena a scorrimento aperta si chiude; dallo specchio di un esercizio si torna alla frase da completare */
  try{ if (typeof scnAperta === 'function' && scnAperta()) scnChiudi(); }catch(_){ }
  if (EPI.specchio){ EPI.specchio = false; EPI.fraseRifai = true; EPI.indietro = true; try{ gnAu.scelta(0); }catch(_){ } gnVai('epi'); return true; }
  if (EPI.i <= 0) return false;
  if (EPI.sub === 'gia' && EPI.giaDa != null){ if (EPI.giaDa <= 0) return false; EPI.i = EPI.giaDa; }
  EPI.i--;
  EPI.indietro = true;
  /* le schermate che non si rivedono (le condizioni non vere) si saltano anche all'indietro */
  while (EPI.i > 0 && !epiSeOk(EPI.passi[EPI.i])) EPI.i--;
  try{ gnAu.scelta(0); }catch(_){ }
  gnVai('epi');
  return true;
}
function epiPos(){
  if (EPI.rivedi || !EPI.ep) return;
  const s = epiStato(); s.pos = { n: EPI.ep.n, i: EPI.i, at: Date.now() }; epiSalva(s);
}
function epiAvanti(){ EPI.i++; EPI.sub = ''; EPI.indietro = false; gnVai('epi'); }

/* ---------------------------------------------------------------- il disegno di una schermata */
if (typeof GN_PASSI !== 'undefined'){
  GN_PASSI.epi = { entra: function(){ epiDisegna(); }, tocco: function(){ epiTocco(); } };
}
function epiClassi(domanda){
  const sc = document.getElementById('gnScena'), sg = document.getElementById('s-genio');
  if (sc){ sc.classList.add('con-top'); sc.classList.toggle('domanda', !!domanda); sc.classList.toggle('molte', !!domanda); sc.classList.remove('carte', 'apertura', 'epi-frase'); }
  if (sg){ sg.classList.toggle('domanda', !!domanda); sg.classList.remove('apertura', 'volo'); }
}
function epiTap(si){ const tap = document.getElementById('gnTap'); if (tap){ tap.hidden = !si; if (si) tap.textContent = epiUi('tocca') || tap.textContent; } }
/* 0.9.347, Andrea (terza volta): "la freccia indietro deve esserci SOLO quando c'e' una domanda. Quando il Genio parla da solo
   c'e' solo 'tocca per continuare'; per tornare indietro c'e' il tasto del telefono". La freccia resta solo nelle domande
   (gnDomanda, Lo scrivo io, la frase da completare). */
function epiFreccia(){
  if (EPI.i <= 0) return '';
  return '<button type="button" class="ak-indietro" onclick="event.stopPropagation();epiIndietro()" aria-label="Torna alla schermata prima">'
    + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
}
function epiDisegna(){
  const ep = EPI.ep; if (!ep) return;
  const passi = EPI.passi || [];
  if (EPI.i >= passi.length){ epiFine(); return; }
  const p = passi[EPI.i];
  if (!epiSeOk(p)){ EPI.i++; epiDisegna(); return; }
  epiPos(); epiBarra(); epiClassi(false); epiTap(false);
  const r = document.getElementById('gnRisp'); if (r) r.innerHTML = '';
  EPI.sub = ''; EPI.giaDa = null; EPI.specchio = false;
  try{ if (typeof scnChiudi === 'function') scnChiudi(); }catch(_){ }
  /* 0.9.344: la scena a scorrimento (episodi-scroll.js) e l'esercizio "completa la frase" */
  if (p.tipo === 'scroll'){
    if (typeof scnPasso !== 'function'){ EPI.i++; epiDisegna(); return; }
    EPI.sub = 'scn';
    const tx = document.getElementById('gnTesto'); if (tx) tx.innerHTML = '';
    return scnPasso(p);
  }
  if (p.tipo === 'frase') return epiFrasePasso(p);
  if (p.atmos && typeof atmPasso === 'function') return atmPasso(p);
  if (p.fumetto && typeof fumPasso === 'function') return fumPasso(p);
  if (p.nf) return epiNfPasso(p);
  if (p.d) return epiDomandaPasso(p);
  if (p.lezione) return epiLezionePasso(p);
  if (p.azione) return epiAzionePasso(p);
  if (p.dato) return epiDatoPasso(p);
  let t = epiTesto(p);
  if (t == null){ EPI.i++; epiDisegna(); return; }
  if (EPI.reazI === EPI.i - 1) t = epiSenzaMmm(t);
  epiRiga(p, t);
}
/* "Mmm..." una volta sola: due reazioni di fila (o una reazione e una frase che comincia uguale) suonavano come un
   disco incantato. La seconda perde il "Mmm..." e comincia con la maiuscola. */
function epiSenzaMmm(t){
  const r = String(t || '').replace(/^Mmm…\s*/, '');
  if (r === t || !r) return t;
  return r.charAt(0) === '*' ? '*' + r.charAt(1).toUpperCase() + r.slice(2) : r.charAt(0).toUpperCase() + r.slice(1);
}
/** Una frase, con la sua immagine o il Genio, e il tocco (o il pulsante del passo) per andare avanti. */
function epiRiga(p, t, dopoHtml){
  epiScena(p);
  EPI.sub = p.btn ? 'btn' : 't';
  gnScrivi(t, function(){
    const r = document.getElementById('gnRisp');
    if (p.btn){ if (r) r.innerHTML = (dopoHtml || '') + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();epiAvanti()">' + epiEsc(p.btn) + '</button></div>'; return; }
    if (r) r.innerHTML = (dopoHtml || '');
    epiTap(true);
  });
}
function epiTocco(){
  if (EPI.sub === 't' || EPI.sub === 'mmm' || EPI.sub === 'gia') epiAvanti();
}

/* ---------------------------------------------------------------- le domande della sfera */
function epiDomandaDi(p){
  let base = null;
  try{ DQ_EPISODI.forEach(function(e){ (e.domande || []).forEach(function(q){ if (q.id === p.d) base = q; }); }); }catch(_){ }
  if (!base && typeof p.d === 'object') base = p.d;
  if (!base) return null;
  /* la variante (la stessa di domande.js): se la risposta di prima la chiede, si fa l'altra domanda */
  let q = base;
  try{ if (q.variante && q.variante.se && q.variante.se(dqStato().risposte)) q = q.variante.q; }catch(_){ }
  q = Object.assign({}, q);
  /* il testo del passo riscrive la domanda (perche' dica di cosa parla), non la sua variante */
  if (p.t && q.id === base.id) q.t = p.t;
  return q;
}
function epiDomandaPasso(p){
  const q = epiDomandaDi(p);
  if (!q){ EPI.i++; epiDisegna(); return; }
  EPI.q = q;
  /* GIA' RISPOSTA: non si richiede. Il Genio la ricorda e si va avanti. 0.9.301: le domande di fila gia' risposte
     diventano UNA frase sola ("L'altra volta mi hai detto "A" e "B". Me lo ricordo."), non una schermata a testa. */
  const G = epiGiaGruppo();
  if (G){
    EPI.giaDa = G.da; EPI.i = G.a;
    epiScena({ posa: 'rivela' });
    EPI.sub = 'gia';
    epiBarra();
    gnScrivi(epiUi('gia_risposta', { risposte: epiGiaElenco(G.valori) }), function(){ const r = document.getElementById('gnRisp'); if (r) r.innerHTML = ''; epiTap(true); });
    return;
  }
  epiScena({ posa: 'pensa' });
  epiClassi(true);
  const sc = document.getElementById('gnScena');
  if (sc) sc.classList.toggle('carte', q.tipo === 'scelta' || q.tipo === 'due');
  /* 0.9.344, Andrea: "Lo scrivo io" sotto a una domanda chiusa con due risposte opposte non ha senso. Adesso e' un flag
     della domanda (scrivo: true | false, sul passo o sulla domanda); senza flag c'e' solo nelle scelte con piu' di due carte. */
  const conScrivo = epiScrivoSi(p, q);
  const scrivo = conScrivo ? '<button type="button" class="gn-card tratt" onclick="event.stopPropagation();epiScrivoApri()"><span>✍️</span><b>' + epiEsc(epiUi('scrivo_t')) + '</b><small>' + epiEsc(epiUi('scrivo_s')) + '</small></button>' : '';
  let html = '';
  if (q.tipo === 'cinque'){
    html = '<div class="or-grid">' + [1, 3, 0, 2, 4].map(function(i){ return '<button type="button" class="or-a" onclick="event.stopPropagation();epiCinque(' + i + ')">' + DQ_CINQUE[i][0] + '</button>'; }).join('') + '</div>'
      + (conScrivo ? '<button type="button" class="gn-link epi-scrivo-link" onclick="event.stopPropagation();epiScrivoApri()">' + epiEsc(epiUi('scrivo_t')) + '</button>' : '');
  } else if (q.tipo === 'scelta' || q.tipo === 'due'){
    const n = q.opz.length + (conScrivo ? 1 : 0);
    /* scorre.js (flScrivoLink) porta "Lo scrivo io" sotto al pannello e lo toglie alle domande con due carte: data-scrivo="si" lo tiene */
    html = '<div class="gn-carta"><div class="gn-cards' + (n % 2 ? ' dispari-s' : '') + '"' + (conScrivo ? ' data-scrivo="si"' : '') + '>' + q.opz.map(function(o, i){
      return '<button type="button" class="gn-card" onclick="event.stopPropagation();epiScelta(' + i + ')"><span>' + o[0] + '</span><b>' + epiEsc(o[1]) + '</b></button>';
    }).join('') + scrivo + '</div></div>';
  } else if (q.tipo === 'scala'){
    html = '<div class="gn-carta gn-slider"><b id="epiScalaVal">5</b><input type="range" id="epiScalaRange" min="' + q.min + '" max="' + q.max + '" step="1" value="5" oninput="flRangeFill(this);document.getElementById(\'epiScalaVal\').textContent=this.value" onclick="event.stopPropagation()"></div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();epiScala()">' + epiEsc(epiUi('scrivo_ok')) + '</button></div>';
  } else {
    html = '<textarea class="gn-area" id="epiScrivoArea" rows="3" placeholder="' + epiEsc(epiUi('scrivo_ph')) + '" onclick="event.stopPropagation()"></textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();epiScrivoOk()">' + epiEsc(epiUi('scrivo_ok')) + '</button></div>';
  }
  gnDomanda('pensa', q.t, epiFreccia() + html, function(){ if (q.tipo === 'scala') try{ flRangeFill(document.getElementById('epiScalaRange')); }catch(_){ } });
}
/** "Lo scrivo io" c'e'? Lo dice il passo, poi la domanda; senza flag solo le scelte con piu' di due carte. */
function epiScrivoSi(p, q){
  if (p && typeof p.scrivo === 'boolean') return p.scrivo;
  if (q && typeof q.scrivo === 'boolean') return q.scrivo;
  return !!q && q.tipo === 'scelta' && (q.opz || []).length > 2;
}
/** La risposta gia' data a un passo domanda (prima di questo episodio), o null. */
function epiGiaDi(j){
  const p = (EPI.passi || [])[j];
  if (!p || !p.d || !epiSeOk(p)) return null;
  const q = epiDomandaDi(p); if (!q) return null;
  const g = (typeof dqRisp === 'function') ? dqRisp(q.id) : null;
  if (!g || g.v === undefined || g.v === null || g.v === '' || (Array.isArray(g.v) && !g.v.length)) return null;
  /* una risposta data in questo episodio non e' "l'altra volta": tornando indietro la domanda si rivede */
  if (+g.at && EPI.aperto && +g.at >= EPI.aperto) return null;
  return g;
}
/** Il gruppo di domande di fila gia' risposte che comincia (o, tornando indietro, finisce) qui. */
function epiGiaGruppo(){
  if (!epiGiaDi(EPI.i)) return null;
  let da = EPI.i, a = EPI.i;
  if (EPI.indietro) while (da > 0 && epiGiaDi(da - 1)) da--;
  while (epiGiaDi(a + 1)) a++;
  const valori = [];
  for (let j = da; j <= a; j++){
    const v = epiGiaDi(j).v;
    (Array.isArray(v) ? v : [v]).forEach(function(x){ x = String(x == null ? '' : x).replace(/\s+/g, ' ').trim(); if (x && valori.indexOf(x) < 0) valori.push(x); });
  }
  return valori.length ? { da: da, a: a, valori: valori } : null;
}
/** "A"  /  "A" e "B"  /  "A", "B" e "C". Una risposta lunghissima scritta a mano si accorcia. */
function epiGiaElenco(l){
  const e = epiUi('gia_e') || 'e';
  const q = l.map(function(x){ if (x.length > 110) x = x.slice(0, 107).replace(/\s+\S*$/, '') + '…'; return '"' + x + '"'; });
  return q.length < 2 ? q.join('') : q.slice(0, -1).join(', ') + ' ' + e + ' ' + q[q.length - 1];
}
function epiSegna(v, extra){
  const q = EPI.q; if (!q) return;
  try{
    const s = dqStato();
    s.risposte[q.id] = Object.assign({ v: v, at: Date.now(), ep: 'serie' + (EPI.ep ? EPI.ep.n : '') }, extra || {});
    dqSalva(s);
  }catch(_){ }
  try{ gnAu.scelta(2); gnVibra(18); }catch(_){ }
}
function epiReazione(m){
  if (!m){ epiAvanti(); return; }
  epiClassi(false);
  epiScena({ posa: 'pensa' });
  const r = document.getElementById('gnRisp'); if (r) r.innerHTML = '';
  const diFila = EPI.reazI === EPI.i - 1;
  EPI.reazI = EPI.i;
  if (diFila){ EPI.sub = 'mmm'; gnScrivi(epiSenzaMmm(m), function(){ epiTap(true); }); return; }
  EPI.sub = 'attesa';
  gnScrivi('Mmm…', function(){ setTimeout(function(){ if (!EPI.ep || EPI.sub !== 'attesa') return; EPI.sub = 'mmm'; gnScrivi(m, function(){ epiTap(true); }); }, 420); });
}
function epiCinque(i){
  const c = DQ_CINQUE[i], q = EPI.q;
  epiSegna(c[0]);
  try{ if (!EPI.rivedi) dqPesa(q.o, c[1]); }catch(_){ }
  epiReazione(q.mmm && (c[1] > 0 ? q.mmm.si : (c[1] < 0 ? q.mmm.no : null)));
}
function epiScelta(i){
  const q = EPI.q, o = q.opz[i];
  epiSegna(o[1], { i: i });
  try{ if (!EPI.rivedi) dqPesa(o[2]); }catch(_){ }
  epiReazione(Array.isArray(q.mmm) ? q.mmm[i] : null);
}
function epiScala(){
  const el = document.getElementById('epiScalaRange'); const v = el ? +el.value : 5;
  epiSegna(v);
  try{ if (!EPI.rivedi) dqPesa(EPI.q.o, v - 5); }catch(_){ }
  epiAvanti();
}
/* LO SCRIVO IO: senza limiti di lunghezza, salvato come risposta con il testo dell'utente */
function epiScrivoApri(){
  const r = document.getElementById('gnRisp'); if (!r) return;
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('carte');
  r.innerHTML = epiFreccia() + '<textarea class="gn-area" id="epiScrivoArea" rows="3" placeholder="' + epiEsc(epiUi('scrivo_ph')) + '" onclick="event.stopPropagation()"></textarea>'
    + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();epiScrivoOk()">' + epiEsc(epiUi('scrivo_ok')) + '</button></div>';
  try{ if (typeof micAvvolgi === 'function') micAvvolgi(r); }catch(_){ }
  setTimeout(function(){ try{ const a = document.getElementById('epiScrivoArea'); if (a) a.focus(); }catch(_){ } }, 200);
}
function epiScrivoOk(){
  const a = document.getElementById('epiScrivoArea'); const v = String(a ? a.value : '').trim();
  if (!v){ try{ if (a) a.focus(); }catch(_){ } return; }
  epiSegna(v, { testo: true });
  epiReazione(epiUi('scrivo_mmm'));
}

/* ---------------------------------------------------------------- completa la frase (0.9.344) */
/* Andrea: "dentro agli episodi voglio gli esercizi che scovano la credenza limitante". Sono tre, presi dalla PNL e da
   Immunity to Change di Robert Kegan: l'utente completa una frase senza pensarci, e quello che scrive dopo il "ma" e' la
   regola a cui crede per proteggersi dal fallimento.
     credenza        "Vorrei [sogno], ma..."
     paura           "Voglio assolutamente [sogno], ma la mia paura piu' grande se ci riuscissi e' che..."
     impegno_azione  "Voglio [sogno], ma l'azione che sto facendo, o non sto facendo, e che va contro..."   (senza specchio)
     impegno         "Se smettessi e facessi l'esatto opposto, la cosa piu' spiacevole che mi sentirei addosso sarebbe..."
   Il passo: { tipo: 'frase', k, t, inizio, inizio_alt, ph, specchio, specchio_kick }. Un campo solo. Dopo la risposta UNA
   schermata (lo specchio) gli restituisce le sue parole con il loro nome. Le risposte stanno in fl_domande come le altre
   (dqStato().risposte.cr_*), con l'inizio della frase e l'etichetta: epiCredenzePerAgente() le porta al brief dell'agente. */
const EPI_FRASI = {
  credenza: { id: 'cr_credenza', et: 'Credenza limitante' },
  paura: { id: 'cr_paura', et: 'Paura del successo' },
  impegno_azione: { id: 'cr_impegno_azione', et: 'Impegno nascosto, azione che va contro il sogno' },
  impegno: { id: 'cr_impegno', et: 'Impegno nascosto' }
};
function epiFraseDi(k){ return EPI_FRASI[k] || { id: 'cr_' + k, et: String(k || '') }; }
function epiFraseRisp(k){ try{ const r = dqRisp(epiFraseDi(k).id); return (r && r.v) ? r : null; }catch(_){ return null; } }
function epiFraseBreve(k){
  const r = epiFraseRisp(k); if (!r) return '';
  let v = String(r.v).replace(/\s+/g, ' ').trim();
  if (v.length > 90) v = v.slice(0, 87).replace(/\s+\S*$/, '') + '…';
  return v;
}
/** L'inizio della frase con il sogno dentro; se il sogno non ha un nome breve, quello generico. */
function epiFraseInizio(p){ return epiRiempi(p.inizio, p.inizio_alt) || p.inizio_alt || ''; }
function epiFrasePasso(p){
  const gia = epiFraseRisp(p.k);
  /* scritta in un'altra visione dell'episodio: non si richiede (come le domande della sfera) */
  const prima = !!gia && !(+gia.at && EPI.aperto && +gia.at >= EPI.aperto);
  const rifai = !!EPI.fraseRifai; EPI.fraseRifai = false;
  if (prima && !rifai){
    if (p.specchio === false){ if (EPI.indietro && EPI.i > 0) EPI.i--; else EPI.i++; epiDisegna(); return; }
    epiFraseSpecchio(p, gia.v, true);
    return;
  }
  EPI.q = null;
  epiScena({ posa: 'pensa' });
  epiClassi(true);
  epiFraseClasse();
  EPI.sub = 'frase';
  const html = epiFreccia() + '<div class="epi-fr"><p class="epi-fr-inizio">' + epiEsc(epiFraseInizio(p)) + '…</p>'
    + '<textarea class="gn-area" id="epiFraseArea" rows="3" placeholder="' + epiEsc(p.ph || epiUi('frase_ph')) + '" onclick="event.stopPropagation()"></textarea></div>'
    + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();epiFraseOk()">' + epiEsc(epiUi('scrivo_ok')) + '</button></div>';
  gnDomanda('pensa', epiTesto(p) || p.alt || '', html, function(){
    const a = document.getElementById('epiFraseArea');
    if (a && gia) a.value = String(gia.v);
  });
}
function epiFraseOk(){
  const p = (EPI.passi || [])[EPI.i]; if (!p || p.tipo !== 'frase') return;
  const a = document.getElementById('epiFraseArea');
  const v = String(a ? a.value : '').replace(/\s+/g, ' ').replace(/^[….\s]+/, '').trim().slice(0, 1200);
  if (!v){ try{ if (a) a.focus(); }catch(_){ } return; }
  const F = epiFraseDi(p.k);
  try{
    const s = dqStato();
    s.risposte[F.id] = { v: v, at: Date.now(), ep: 'serie' + (EPI.ep ? EPI.ep.n : ''), testo: true, frase: epiFraseInizio(p), etichetta: F.et };
    dqSalva(s);
  }catch(_){ }
  try{ gnAu.scelta(2); gnVibra(18); }catch(_){ }
  try{ if (a) a.blur(); }catch(_){ }
  if (p.specchio === false){ epiAvanti(); return; }
  epiFraseSpecchio(p, v, false);
}
/** Lo specchio: le sue parole, con il nome che hanno. Un tocco e si va avanti; indietro riapre la frase. */
function epiFraseSpecchio(p, v, gia){
  /* stessa disposizione della frase da completare (nuvoletta grande, Genio piccolo): la carta ha tutto il suo spazio */
  epiClassi(true);
  epiFraseClasse();
  const carta = '<div class="epi-dato epi-regola"><small>' + epiEsc(p.specchio_kick || epiFraseDi(p.k).et) + '</small><b>"' + epiEsc(v) + '"</b></div>'
    + (gia ? '<button type="button" class="gn-link epi-fr-rifai" onclick="event.stopPropagation();epiFraseRifai()">' + epiEsc(epiUi('frase_rifai')) + '</button>' : '');
  epiRiga({ posa: 'rivela' }, gia ? (p.gia || epiUi('frase_gia')) : (p.specchio || epiUi('frase_gia')), carta);
  EPI.specchio = !gia;
}
/* epi-frase: sugli schermi bassi (e con la tastiera aperta) il Genio lascia il posto al campo e al pulsante */
function epiFraseClasse(){ const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('epi-frase'); }
function epiFraseRifai(){ EPI.fraseRifai = true; EPI.indietro = false; EPI.specchio = false; gnVai('epi'); }
/** Per il tuo agente personale: le frasi completate, ognuna con la sua etichetta. Vuoto se non ne ha scritte. */
function epiCredenzePerAgente(){
  const v = function(k){ const r = epiFraseRisp(k); return r ? String(r.v).replace(/\s+/g, ' ').trim().slice(0, 400) : ''; };
  const inizio = function(k){ const r = epiFraseRisp(k); return (r && r.frase) ? String(r.frase).trim() + ' ' : ''; };
  const out = [];
  if (v('credenza')) out.push('Credenza limitante (la regola a cui crede): "' + inizio('credenza') + v('credenza') + '"');
  if (v('paura')) out.push('Paura del successo: "' + inizio('paura') + v('paura') + '"');
  const az = v('impegno_azione'), im = v('impegno');
  if (az || im) out.push('Impegno nascosto' + (az ? ', quello che fa o non fa contro il suo sogno: "' + az + '"' : '') + (im ? ', quello che sentirebbe facendo il contrario: "' + im + '"' : ''));
  if (!out.length) return '';
  return 'FRASI COMPLETATE DI GETTO NEGLI EPISODI. ' + out.join('. ') + '. '
    + 'Usale per riconoscere le sue scuse e per proporre passi piccoli che le smentiscono.';
}
/* Il brief dell'agente (agente.js, agDati) legge i freni da bqPerAgente() di blocchi.js: le frasi si accodano li',
   nella riga "Paradigma". blocchi.js si carica dopo questo file, per questo l'aggancio aspetta la pagina pronta. */
function epiAgenteAggancia(){
  try{
    if (typeof bqPerAgente !== 'function' || bqPerAgente.__epi) return;
    const v = bqPerAgente;
    const w = function(){
      let a = '', b = '';
      try{ a = v.apply(this, arguments) || ''; }catch(_){ }
      try{ b = epiCredenzePerAgente(); }catch(_){ }
      return [a, b].filter(Boolean).join(' ');
    };
    w.__epi = true; window.bqPerAgente = w;
  }catch(_){ }
}
if (typeof document !== 'undefined'){
  document.addEventListener('DOMContentLoaded', epiAgenteAggancia);
  addEventListener('load', epiAgenteAggancia);
  setTimeout(epiAgenteAggancia, 2500);
}

/* ---------------------------------------------------------------- le domande del tuo Io Futuro (0.9.307) */
function epiNfPasso(p){
  const fatta = (typeof nfHaRisposto === 'function') ? nfHaRisposto(p.nf) : true;
  if (fatta || typeof nfDomandaEpisodio !== 'function'){
    /* gia' risposta (anche nella chiamata, prima della 0.9.307): non si richiede. All'indietro si salta all'indietro. */
    if (EPI.indietro && EPI.i > 0) EPI.i--; else EPI.i++;
    epiDisegna(); return;
  }
  epiScena({ posa: 'pensa' });
  EPI.sub = 'btn';
  gnScrivi(epiTesto(p) || '', function(){
    const r = document.getElementById('gnRisp');
    if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();epiNfVia()">' + epiEsc(p.btn || epiUi('nf_btn')) + '</button></div>';
  });
}
/** La domanda si apre a schermo intero; quando ha risposto l'episodio riparte dal passo dopo, con Indietro da questo. */
function epiNfVia(){
  const p = (EPI.passi || [])[EPI.i]; if (!p || !p.nf || !EPI.ep) return;
  const sp = { n: EPI.ep.n, i: EPI.i, rivedi: EPI.rivedi, dopo: EPI.dopo };
  epiTempoSegna();
  const s = epiStato(); s.sospeso = { n: sp.n, i: sp.i, az: 'nf', at: Date.now() }; epiSalva(s);
  try{ gnAu.musicaOff(); }catch(_){ }
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  GN.on = false;
  nfDomandaEpisodio(p.nf, function(fatto){
    epiApri(sp.n, { da: fatto ? sp.i + 1 : sp.i, senzaSigla: true, rivedi: sp.rivedi }).then(function(){ if (sp.dopo) EPI.dopo = sp.dopo; });
  });
}

/* ---------------------------------------------------------------- la lezione dell'Academy */
/* I temi dell'utente: le cose con cui ha detto di fare i conti nel primo avvio, il sogno, le risposte. */
function epiTemi(){
  const t = {};
  try{
    const d = gnDati(), c = (d.conti || []).join(' ');
    if (/Rimando/.test(c)) t.rimando = 1;
    if (/Penso troppo/.test(c)) t.pensiero = 1;
    if (/Dormo male/.test(c)) t.sonno = 1;
    if (/motivazione/.test(c)) t.motivazione = 1;
    if (/distraggo/.test(c)) t.distrazione = 1;
    if (/direzione/.test(c)) t.direzione = 1;
    if (/fiducia/.test(c)) t.fiducia = 1;
    if (d.sognoK === 'famiglia') t.relazioni = 1;
    if (+d.oreVere >= 3) t.distrazione = 1;
  }catch(_){ }
  try{ const r = dqStato().risposte; if (r.e2q5 && /Meno di 5|5 o 6/.test(r.e2q5.v)) t.sonno = 1; if (dqNeg(r.e1q2)) t.direzione = 1; }catch(_){ }
  return t;
}
function epiLezioneScegli(lista){
  if (typeof ACADEMY === 'undefined') return null;
  /* 0.9.306: una lezione gia' consegnata da un episodio (Nuova nell'Academy) conta come letta: non si ripropone */
  const temi = epiTemi(), letti = Object.assign({}, (typeof acNuove === 'function') ? acNuove() : {}, (typeof acDone === 'function') ? acDone() : {});
  const cand = [];
  (lista || []).forEach(function(v){
    const m = String(v).match(/^(?:(\w+)>)?([\w-]+):(.+)$/); if (!m) return;
    const mod = ACADEMY.filter(function(x){ return x.id === m[2]; })[0]; if (!mod) return;
    const i = mod.lessons.findIndex(function(l){ return l.t === m[3]; }); if (i < 0) return;
    const punto = ((EPI.cfg && EPI.cfg.lezioni) || {})[m[2] + ':' + m[3]]; if (!punto) return;
    cand.push({ tema: m[1] || '', mod: mod, i: i, punto: punto, letta: !!letti[mod.id + ':' + i] });
  });
  if (!cand.length) return null;
  /* prima una lezione sul tema dell'utente che non ha ancora letto, poi quella di base */
  return cand.filter(function(c){ return c.tema && temi[c.tema] && !c.letta; })[0]
    || cand.filter(function(c){ return !c.tema && !c.letta; })[0]
    || cand.filter(function(c){ return c.tema && temi[c.tema]; })[0]
    || cand[0];
}
function epiLezionePasso(p){
  const L = epiLezioneScegli(p.lezione);
  if (!L){ EPI.i++; epiDisegna(); return; }
  EPI.lez = L;
  epiScena({ posa: 'rivela' });
  EPI.sub = 'lez';
  gnScrivi(epiTesto(p, 'intro') || '', function(){
    const r = document.getElementById('gnRisp'); if (!r) return;
    const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('molte');
    /* 0.9.306, Andrea (episodio 4, "I due tipi di motivazione"): niente descrizione della lezione (era uno spoiler), testo
       al centro, la riga dell'Academy che risalta, e chi non conosce l'Academy deve capire dov'e': il lucchetto si apre, la
       lezione vola nell'Academy e sotto c'e' scritto dove trovarla. Il tocco porta all'Academy solo a fine episodio (epiFine). */
    r.innerHTML = '<div class="epi-lez"><small>' + epiEsc(epiUi('lezione_kick', { modulo: L.mod.name })) + '</small>'
      + '<div class="epi-lez-art"><span class="epi-lez-ico">' + epiEsc(L.mod.icon || '📘') + '</span><span class="epi-lez-chiuso">' + '<svg class="epi-lez-luc" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path class="epi-lez-arco" d="M8 11V8a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><rect x="5" y="11" width="14" height="10" rx="2.5" fill="currentColor"/></svg>' + '</span>'
      + '<span class="epi-lez-volo" aria-hidden="true">' + epiEsc(L.mod.icon || '📘') + '</span></div>'
      + '<b>' + epiEsc(L.mod.lessons[L.i].t) + '</b>'
      + '<strong class="epi-lez-nota">' + epiEsc(epiUi('lezione_nota')) + '</strong>'
      + '<span class="epi-lez-dove"><i class="epi-lez-cap" aria-hidden="true">🎓</i><span>' + epiEsc(epiUi('lezione_dove')) + '</span></span></div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();epiLezioneOk()">' + epiEsc(epiUi('lezione_ok')) + '</button></div>';
    epiLezioneVolo(r);
  });
}
/** Il volo della lezione: dal cerchio dell'emoji al cappello dell'Academy (la distanza si misura, cambia con lo schermo). */
function epiLezioneVolo(r){
  try{
    const art = r.querySelector('.epi-lez-art'), v = r.querySelector('.epi-lez-volo'), cap = r.querySelector('.epi-lez-cap');
    if (!art || !v || !cap) return;
    const a = v.getBoundingClientRect(), b = cap.getBoundingClientRect();
    v.style.setProperty('--dx', Math.round(b.left + b.width / 2 - (a.left + a.width / 2)) + 'px');
    v.style.setProperty('--dy', Math.round(b.top + b.height / 2 - (a.top + a.height / 2)) + 'px');
    art.classList.add('via');
    setTimeout(function(){ try{ gnVibra(12); }catch(_){ } }, 650);
  }catch(_){ }
}
function epiLezioneOk(){
  /* 0.9.306: "Ho capito" non segna piu' la lezione come letta (nell'Academy compariva con la spunta senza averla letta).
     La lezione si ricorda per la fine dell'episodio, che la mette nell'Academy come Nuova. */
  try{ if (EPI.lez && EPI.ep){ const s = epiStato(); s.lezEp = { n: EPI.ep.n, mod: EPI.lez.mod.id, i: EPI.lez.i }; epiSalva(s); } }catch(_){ }
  try{ gnAu.punto(); }catch(_){ }
  epiAvanti();
}
/** La lezione consegnata da questo episodio: { mod, i } oppure null. */
function epiLezioneDellEp(){
  try{
    if (EPI.lez && EPI.lez.mod) return { mod: EPI.lez.mod, i: EPI.lez.i };
    const l = epiStato().lezEp; if (!l || !EPI.ep || l.n !== EPI.ep.n || typeof acModule !== 'function') return null;
    const m = acModule(l.mod); return m && m.lessons[l.i] ? { mod: m, i: l.i } : null;
  }catch(_){ return null; }
}
/** Dalla fine dell'episodio: chiude l'episodio e apre la lezione nell'Academy del Profilo. */
function epiLezioneApri(){
  const L = epiLezioneDellEp(); EPI.dopo = '';
  epiChiudi();
  if (!L) return;
  setTimeout(function(){
    try{ if (typeof switchTab === 'function') switchTab('profilo'); }catch(_){ }
    try{ academyOpen(); acOpenModule(L.mod.id); acOpenLesson(L.i); }catch(_){ }
  }, 350);
}

/* ---------------------------------------------------------------- le azioni: i pezzi veri dell'app */
const EPI_AZIONI = {
  sabotatore: {
    fatto: function(){ try{ const b = bqLeggi(); return !!(b && b.primario); }catch(_){ return false; } },
    apri: function(){ blocchiApri(true); },
    chiusa: function(){ return epiSchermo() !== 's-blocchi'; }
  },
  pillole: {
    fatto: function(){ return !!epiPillola(); },
    /* la scelta si fa qui; la durata della Modalita' severa (pillola rossa) si sceglie a fine episodio */
    apri: function(){
      const c = faPillolaCfg();
      c.poi = function(k){ if (k === 'rossa') EPI.dopoAzione = 'severa'; epiRiprendi(); };
      faScena(c);
    },
    subito: true
  },
  iofuturo: {
    fatto: function(){ try{ return !!(ifNuovoMe().partita); }catch(_){ return false; } },
    apri: function(){ nfApri(); },
    chiusa: function(){ return epiSchermo() !== 's-nuovome'; }
  },
  strada: {
    fatto: function(){ return !!epiStrada(); },
    apri: function(){ faApriStrada(function(){ try{ if (typeof sdAggiorna === 'function') sdAggiorna(false); }catch(_){ } epiRiprendi(); }); },
    subito: true
  },
  piano: {
    fatto: function(){ try{ return !!(localStorage.getItem('fl_piano_fatto') || localStorage.getItem('fl_piano_avviato')); }catch(_){ return false; } },
    apri: function(){ }
  }
};
function epiSchermo(){ try{ return (typeof order !== 'undefined' && typeof cur !== 'undefined') ? order[cur] : ''; }catch(_){ return ''; } }
function epiAzionePasso(p){
  const A = EPI_AZIONI[p.azione];
  if (!A){ EPI.i++; epiDisegna(); return; }
  if (A.fatto()){
    const t = epiTesto(p, 'gia');
    if (t == null){ EPI.i++; epiDisegna(); return; }
    epiScena({ posa: 'rivela' });
    EPI.sub = 'gia';
    gnScrivi(t, function(){ const r = document.getElementById('gnRisp'); if (r) r.innerHTML = ''; epiTap(true); });
    return;
  }
  /* non bloccante (il piano su misura): si dice, e si apre a fine episodio */
  if (p.bloccante === false){
    EPI.dopo = p.azione;
    epiRiga(Object.assign({}, p, { posa: 'rivela' }), epiTesto(p) || '');
    return;
  }
  epiScena({ posa: 'rivela', vis: p.vis });
  EPI.sub = 'btn';
  gnScrivi(epiTesto(p) || '', function(){
    const r = document.getElementById('gnRisp');
    if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();epiAzioneVia()">' + epiEsc(p.btn || '') + '</button></div>'
      + '<p class="epi-nota">' + epiEsc(epiUi('azione_torna')) + '</p>';
  });
}
/* L'EPISODIO IN PAUSA: si apre il pezzo vero, e l'episodio riparte quando il pezzo e' fatto e chiuso */
function epiAzioneVia(){
  const p = EPI.passi[EPI.i], A = EPI_AZIONI[p.azione]; if (!A) return;
  epiTempoSegna();
  const s = epiStato(); s.sospeso = { n: EPI.ep.n, i: EPI.i, az: p.azione, at: Date.now() }; epiSalva(s);
  EPI.sospeso = { n: EPI.ep.n, i: EPI.i, rivedi: EPI.rivedi, dopo: EPI.dopo };
  try{ gnAu.musicaOff(); }catch(_){ }
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  GN.on = false;
  if (!A.subito) goId('s-home');
  try{ A.apri(); }catch(_){ }
  if (A.subito) return;
  clearInterval(EPI.poll);
  const t0 = Date.now();
  EPI.poll = setInterval(function(){
    if (!EPI.sospeso || Date.now() - t0 > 3600000){ clearInterval(EPI.poll); return; }
    try{ if (A.fatto() && A.chiusa()){ clearInterval(EPI.poll); epiRiprendi(); } }catch(_){ }
  }, 900);
}
function epiRiprendi(){
  const sp = EPI.sospeso; if (!sp) return;
  EPI.sospeso = null; clearInterval(EPI.poll);
  const dopo = EPI.dopoAzione || sp.dopo || ''; EPI.dopoAzione = '';
  setTimeout(function(){
    epiApri(sp.n, { da: sp.i + 1, senzaSigla: true, rivedi: sp.rivedi }).then(function(){ if (dopo) EPI.dopo = dopo; });
  }, 700);
}

/* ---------------------------------------------------------------- i dati: tappe, data, ladro */
function epiProssimeTappe(n){
  try{
    const s = sdStato();
    return sdTutti().filter(function(nd){ return !sdNodoFatto(nd, s) && !(typeof sdSaltata === 'function' && sdSaltata(nd)) && nd.tipo !== 'sc'; })
      .slice(0, n).map(function(nd){ return { ico: (SD_ICO && SD_ICO[nd.tipo]) || '•', nome: sdNomeTappa(nd) }; }).filter(function(x){ return x.nome; });
  }catch(_){ return []; }
}
function epiData(){
  try{
    const a = etaArrivo(); if (!a || !isFinite(a.at)) return null;
    const d = new Date(a.at), M = (typeof NV_MESI !== 'undefined') ? NV_MESI : ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
    let pct = null; try{ pct = gnLettura().pct; }catch(_){ }
    return { txt: d.getDate() + ' ' + M[d.getMonth()] + ' ' + d.getFullYear(), pct: pct };
  }catch(_){ return null; }
}
function epiDatoPasso(p){
  const r0 = document.getElementById('gnRisp');
  if (p.dato === 'tappe'){
    const l = epiProssimeTappe(3);
    if (!l.length){ epiRiga(p, p.alt || ''); return; }
    epiRiga(Object.assign({}, p, { posa: 'rivela' }), epiTesto(p) || '', '<div class="epi-dato"><small>' + epiEsc(epiUi('tappe_kick')) + '</small><ol>' + l.map(function(x){ return '<li><span>' + epiEsc(x.ico) + '</span>' + epiEsc(x.nome) + '</li>'; }).join('') + '</ol></div>');
    return;
  }
  if (p.dato === 'data'){
    const d = epiData();
    if (!d){ EPI.dataOk = false; epiRiga(p, p.alt || ''); return; }
    EPI.dataOk = true;
    if (!EPI.rivedi){
      const s = epiStato(); if (!s.dataSvelata){ s.dataSvelata = Date.now(); epiSalva(s); }
      try{ const q = dqStato(); if (!q.finale){ q.finale = Date.now(); dqSalva(q); } }catch(_){ }
    }
    epiScena({ posa: 'pensa' });
    EPI.sub = 'attesa';
    if (r0) r0.innerHTML = '';
    let sogno = ''; try{ sogno = gnLettura().sognoBreve || ''; }catch(_){ }
    const righe = [epiUi('conosce', { pct: (function(){ try{ return dqConoscenza(); }catch(_){ return 0; } })() })];
    try{ gnTraiettoria(righe.concat(sogno ? [sogno] : []), function(){
      if (!EPI.ep) return;
      epiRiga(Object.assign({}, p, { posa: 'rivela' }), epiTesto(p) || '', '<div class="epi-dato data"><small>' + epiEsc(epiUi('data_kick')) + '</small><b>' + epiEsc(d.txt) + '</b>' + (d.pct != null ? '<p>' + epiEsc(epiUi('data_prob', { pct: d.pct })) + '</p>' : '') + '</div>');
      try{ gnAu.punto(); gnVibra([30, 40, 80]); }catch(_){ }
    }); }catch(_){ epiRiga(p, epiTesto(p) || ''); }
    return;
  }
  if (p.dato === 'ladro'){
    const go = function(){
      const t = epiTesto(p);
      const card = EPI.ladro ? '<div class="epi-dato ladro"><small>' + epiEsc(epiUi('ladro_kick')) + '</small><b>' + epiEsc(epiUi('ladro_riga', { ladro: EPI.ladro.nome, tempo: EPI.ladro.tempo })) + '</b></div>' : '';
      epiRiga(p, t == null ? (p.alt || '') : t, card);
    };
    if (EPI.ladro) go(); else epiLadroLeggi().then(function(l){ EPI.ladro = l; if (EPI.ep) go(); });
    return;
  }
  EPI.i++; epiDisegna();
}

/* ---------------------------------------------------------------- la fine dell'episodio */
/* 0.9.308, Andrea sulla vecchia fine ("Fine dell'episodio 4", la pillola +15 XP e "Domani il prossimo episodio si
   sblocca con la prima tappa della Mappa"): gli faceva schifo. Adesso e' LA STESSA schermata di fine tappa della Roadmap
   (sentiero-mappa.js, s-sd-fine, sdFineDisegna): il Genio, "Episodio N completato!", i tre riquadri che entrano uno alla
   volta (XP presi, la stagione a che punto e', il tempo passato nell'episodio), poi la lezione nuova dell'Academy se
   l'episodio ne ha consegnata una, il prossimo episodio detto come in una serie, e il pulsante. */
/* 0.9.333, Andrea: "il Genio chieda se usa gia' le AI, e nel caso proponga subito il prompt dell'albero maestro" */
function epiAiChiesta(){ try{ return !!localStorage.getItem('fl_ai_chiesto'); }catch(_){ return true; } }
function epiAiRisposta(usa){
  try{ localStorage.setItem('fl_ai_chiesto', usa); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  if (usa !== 'no') EPI.dopo = EPI.dopo || 'albero';
  epiFine();
}
/* 0.9.335, Andrea: "se l'utente ha un PC, una delle prime cose e' chiedergli se lo usa per il sogno o per lavoro, e proporgli di
   collegarlo: il Genio vede anche il tempo al computer e le previsioni sono piu' precise" */
function epiPcChiesta(){
  try{ if (localStorage.getItem('fl_pc_chiesto')) return true; }catch(_){ return true; }
  try{ if (typeof mwQuiComputer === 'function' && mwQuiComputer()) return true; if (typeof mwDueDispositivi === 'function' && mwDueDispositivi()) return true; }catch(_){ }
  return false;
}
function epiPcRisposta(k){
  try{ localStorage.setItem('fl_pc_chiesto', k); }catch(_){ }
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  if (k !== 'no') EPI.dopo = EPI.dopo || 'pc';
  EPI.pcOra = true;
  epiFine();
}
function epiPcApri(){
  const url = 'https://meta-ai-media-buyer-production.up.railway.app/scarica/#computer';
  const testo = 'DreamMap per il computer: ' + url;
  inSheet('<div class="epi-pc"><span class="epi-pc-ico">💻</span><b>Collega il tuo computer</b>'
    + '<p>Installa DreamMap sul computer e accedi con lo stesso account. Il tuo agente vede anche il tempo al computer, e la tua data d’arrivo diventa più precisa.</p>'
    + '<button type="button" class="cta" onclick="epiPcManda()">Mandami il link per il computer</button>'
    + '<button type="button" class="ghostmini" onclick="inSheetChiudi()">Lo faccio dopo</button></div>');
  EPI.pcTesto = testo;
}
async function epiPcManda(){
  const t = EPI.pcTesto || 'https://meta-ai-media-buyer-production.up.railway.app/scarica/#computer';
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: t, title: 'DreamMap per il computer' }); inSheetChiudi(); return; } }catch(_){ }
  try{ await navigator.clipboard.writeText(t); toast('Link copiato: aprilo sul computer'); }catch(_){ toast(t); }
  inSheetChiudi();
}
function epiFine(){
  const ep = EPI.ep; if (!ep) return;
  if (!EPI.rivedi && ep.n >= 2 && !epiPcChiesta()){
    gnDomanda('pensa', 'Dimmi una cosa: *usi un computer* per lavorare al tuo sogno, o per il tuo lavoro?',
      '<div class="or-grid quattro"><button type="button" class="or-a" onclick="event.stopPropagation();epiPcRisposta(\'ogni giorno\')">Sì, ogni giorno</button><button type="button" class="or-a" onclick="event.stopPropagation();epiPcRisposta(\'a volte\')">A volte</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();epiPcRisposta(\'no\')">No, solo il telefono</button>');
    return;
  }
  if (!EPI.rivedi && ep.n >= 2 && !EPI.pcOra && !epiAiChiesta() && typeof amApri === 'function'){
    gnDomanda('pensa', 'Dimmi una cosa: *usi già l’intelligenza artificiale* nella tua vita di tutti i giorni?',
      '<div class="or-grid quattro"><button type="button" class="or-a" onclick="event.stopPropagation();epiAiRisposta(\'si\')">Sì, ogni giorno</button><button type="button" class="or-a" onclick="event.stopPropagation();epiAiRisposta(\'ogni tanto\')">Ogni tanto</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();epiAiRisposta(\'no\')">No, non la uso</button>');
    return;
  }
  epiTempoSegna();
  let xp = 0;
  const nuovo = !EPI.rivedi && !epiStato().visti[ep.n];
  if (nuovo){
    epiSegnaVisto(ep.n);
    try{ const s = sdStato(); xp = (typeof sdXpPer === 'function') ? sdXpPer('ep', EPI_XP) : EPI_XP; s.xp = (s.xp || 0) + xp; sdSalva(s); if (typeof sdXpOggiAdd === 'function') sdXpOggiAdd(xp); if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  }
  const s = epiStato();
  const msTot = (s.tempo && s.tempo[epiTempoK()]) || 0;
  const sec = Math.max(1, Math.round(msTot / 1000));
  const v = s.visti[ep.n];
  if (nuovo && v){ v.xp = xp; v.sec = sec; }
  if (!nuovo && v && v.xp) xp = v.xp;
  else if (!nuovo) xp = EPI_XP;
  if (s.pos && s.pos.n === ep.n) delete s.pos;
  epiSalva(s);
  EPI.sub = 'fine';
  if (typeof sdFineDisegna !== 'function'){ EPI.dopo = ''; epiChiudi(); return; }
  const lista = epiLista(), idx = lista.findIndex(function(x){ return x.tipo === 'epi' && x.n === ep.n; }), dopo = lista[idx + 1];
  const fineStag = !dopo || dopo.s !== ep.s;
  /* i tre riquadri, con le classi della fine tappa */
  const doppi = nuovo && xp > EPI_XP;
  const totStag = (((EPI.cfg && EPI.cfg.stagioni) || []).filter(function(S){ return S.s === ep.s; })[0] || { episodi: [] }).episodi.length;
  const voto = (typeof sdFineVoto === 'function') ? sdFineVoto(sec) : '';
  const box = '<div class="sd-box gialla"><small>' + epiEsc(doppi && typeof sdBoostNome === 'function' ? sdBoostNome() : epiUi(nuovo ? 'fine_box_xp' : 'fine_box_xp_rivedi')) + '</small><b>⚡ ' + xp + '</b></div>'
    + '<div class="sd-box verde giro"><small>' + epiEsc(epiUi('fine_box_stagione', { s: ep.s })) + '</small><b>🎬 ' + ep.n + (totStag ? '/' + totStag : '') + '</b></div>'
    + '<div class="sd-box blu"><small>' + epiEsc(voto || epiUi('fine_box_tempo')) + '</small><b>⏱ ' + epiEsc(typeof sdMmSs === 'function' ? sdMmSs(sec) : String(sec)) + '</b></div>';
  const tit = fineStag ? epiUi('fine_tit_stagione', { s: ep.s }) : epiUi('fine_tit', { n: ep.n });
  let pct = 0; try{ pct = dqConoscenza(); }catch(_){ }
  const sotto = EPI.rivedi ? epiUi('fine_sotto_titolo', { titolo: ep.titolo }) : (pct ? epiUi('fine_sotto', { pct: pct }) : epiUi('fine_sotto_poco'));
  /* 0.9.306: la lezione dell'Academy consegnata dall'episodio entra nell'Academy (Nuova) e da qui si apre */
  const lez = epiLezioneDellEp();
  if (lez && typeof acNuovaSegna === 'function') acNuovaSegna(lez.mod.id, lez.i);
  const lezHtml = lez ? '<button type="button" class="epi-fine-ac" onclick="epiFineVia(\'lez\')" aria-label="' + epiEsc(epiUi('fine_lezione_apri')) + '">'
    + '<span class="epi-fine-ac-ico">' + epiEsc(lez.mod.icon || '📘') + '</span><span class="epi-fine-ac-t"><small>' + epiEsc(epiUi('fine_lezione_kick')) + '</small><b>' + epiEsc(lez.mod.lessons[lez.i].t) + '</b></span>'
    + '<span class="epi-fine-ac-va"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg></span></button>' : '';
  /* il prossimo episodio, come alla fine di una puntata: cosa arriva e quando. Rivedendo un episodio non serve. */
  let prossHtml = '';
  if (!EPI.rivedi){
    const quando = epiUi((epiGiorno() + 1 >= 8) ? 'fine_pross_tappa' : 'fine_pross_domani');
    if (!fineStag) prossHtml = '<div class="epi-fs-pross"><small>' + epiEsc(epiUi('fine_pross_kick')) + '</small><b>' + epiEsc(epiUi('fine_pross_titolo', { n: dopo.n, titolo: dopo.titolo })) + '</b><p>' + epiEsc(quando) + '</p></div>';
    else if (dopo) prossHtml = '<div class="epi-fs-pross"><small>' + epiEsc(epiUi('fine_pross_stag_kick')) + '</small><b>' + epiEsc(epiUi('fine_pross_stag_titolo', { s: dopo.s, titolo: dopo.titolo })) + '</b><p>' + epiEsc(quando) + '</p></div>';
    else prossHtml = '<div class="epi-fs-pross"><small>' + epiEsc(epiUi('fine_pross_stag_kick')) + '</small><p>' + epiEsc(epiUi('sfera_stato_fine')) + '</p></div>';
  }
  /* il piano su misura o la durata della modalita' severa, quando l'episodio li ha promessi: secondo pulsante, contornato */
  const extra = EPI.dopo === 'piano' ? '<button type="button" class="epi-fs-sec" onclick="epiFineVia(\'piano\')">' + epiEsc(epiUi('fine_piano')) + '</button>'
    : EPI.dopo === 'severa' ? '<button type="button" class="epi-fs-sec" onclick="epiFineVia(\'severa\')">' + epiEsc(epiUi('fine_severa')) + '</button>' : '';
  epiFineBack();
  /* la scena del Genio e' finita: senza questo il tasto indietro del telefono (gnIndietro) tornava a un passo
     dell'episodio dietro alla schermata di fine */
  GN.on = false;
  goId('s-sd-fine');
  const h = document.getElementById('sdFine'); if (!h){ EPI.dopo = ''; epiChiudi(); return; }
  /* 0.9.341, Andrea: "nella schermata dell'episodio completato non ci deve essere tutta quella pappardella: la nuova lezione e il
     prossimo episodio tolgono il focus da XP, stagione e tempo. Una cosa alla volta". Prima le statistiche, poi (se c'e')
     la lezione nuova in una schermata sua, poi il prossimo episodio in una schermata sua. */
  const passi = [];
  if (lez) passi.push({ tit: epiUi('fine_lezione_tit'), sotto: epiUi('fine_lezione_sotto', { modulo: lez.mod.name || 'Academy' }), dopo: lezHtml,
    cta: '<button type="button" class="cta sd-fine-cta" onclick="epiFineVia(\'lez\')">' + epiEsc(epiUi('fine_lezione_apri')) + '</button><button type="button" class="epi-fs-sec" onclick="epiFineAvanti()">' + epiEsc(epiUi('fine_lezione_dopo')) + '</button>' });
  if (prossHtml) passi.push({ tit: fineStag ? epiUi(dopo ? 'fine_pross_stag_tit' : 'fine_ultima_tit') : epiUi('fine_pross_tit'), sotto: '', dopo: prossHtml, cta: '' });
  EPI.finePassi = passi; EPI.fineExtra = extra;
  sdFineDisegna(h, {
    cls: 'epi-fs', tit: epiEsc(tit), sotto: epiEsc(sotto), box: box, dopo: '',
    cta: passi.length ? '<button type="button" class="cta sd-fine-cta" onclick="epiFineAvanti()">' + epiEsc(epiUi('fine_continua')) + '</button>'
      : '<button type="button" class="cta sd-fine-cta" onclick="epiFineVia(\'\')">' + epiEsc(epiUi('fine_btn')) + '</button>' + extra
  });
}
/** La schermata dopo, nella fine dell'episodio: la lezione nuova, poi il prossimo episodio, poi si torna a Sogno. */
function epiFineAvanti(){
  const h = document.getElementById('sdFine'); const l = EPI.finePassi || [];
  const p = l.shift();
  if (!h || !p){ epiFineVia(''); return; }
  const ultimo = !l.length;
  h.className = 'sd-fine epi-fs epi-fs-passo';
  h.innerHTML = '<div class="sd-fine-in"><img src="img/genio/genio-rivela.png" alt=""><h2>' + epiEsc(p.tit) + '</h2>' + (p.sotto ? '<p>' + epiEsc(p.sotto) + '</p>' : '')
    + (p.dopo || '')
    + (p.cta || (ultimo ? '<button type="button" class="cta sd-fine-cta" onclick="epiFineVia(\'\')">' + epiEsc(epiUi('fine_btn')) + '</button>' + (EPI.fineExtra || '')
                        : '<button type="button" class="cta sd-fine-cta" onclick="epiFineAvanti()">' + epiEsc(epiUi('fine_continua')) + '</button>'))
    + '</div>';
  try{ if (typeof gnAu !== 'undefined') gnAu.scelta(2); flVibra(12); }catch(_){ }
}
/** Dalla schermata di fine: k = '' torna a Dream, 'lez' apre la lezione nell'Academy, 'piano'/'severa' aprono quello promesso. */
function epiFineVia(k){
  if (!EPI.ep) return;
  if (k === 'lez'){ EPI.finePassi = []; epiLezioneApri(); return; }
  EPI.dopo = k || '';
  epiChiudi();
}
/* il tasto indietro del telefono sulla fine dell'episodio torna a Dream (sulla fine della tappa resta quello della Mappa) */
function epiFineBack(){
  if (EPI.backOk || typeof BACK_TO === 'undefined') return;
  EPI.backOk = true;
  const prima = BACK_TO['s-sd-fine'];
  BACK_TO['s-sd-fine'] = function(){
    const h = document.getElementById('sdFine');
    if (h && h.classList.contains('epi-fs') && EPI.ep){ epiFineVia(''); return 's-home'; }
    return typeof prima === 'function' ? prima() : (prima || 's-home');
  };
}

/* ---------------------------------------------------------------- l'episodio 1 nel primo avvio */
/* genio-intro.js chiama epiIntroParte() dal passo b1 e epiIntroPatto() dal passo patto. Le frasi
   diventano passi del film (ia0, ia1... / ip0... / ic0...): il tasto indietro del telefono le
   ripercorre come tutti gli altri passi. */
function epiIntroRegistra(){
  const I = epiIntro(); if (!I || typeof GN_PASSI === 'undefined') return false;
  const registra = function(lista, pre, fine){
    (lista || []).forEach(function(p, k){
      const id = pre + k, prossimo = (k + 1 < lista.length) ? pre + (k + 1) : null;
      GN_PASSI[id] = { entra: function(){
        const sc = document.getElementById('gnScena');
        if (sc){ sc.classList.remove('apertura'); }
        epiScena(p);
        const tx = epiFill(p.t, { vecchio: (function(){ try{ return gnNomi().vecchio; }catch(_){ return 'il vecchio te'; } })() });
        gnScrivi(tx, function(){
          const r = document.getElementById('gnRisp');
          if (p.btn){ if (r) r.innerHTML = '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();' + (prossimo ? 'gnVai(\'' + prossimo + '\')' : fine) + '">' + epiEsc(p.btn) + '</button></div>'; return; }
          const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false;
        });
      }, tocco: function(){ if (p.btn) return; if (prossimo) gnVai(prossimo); else { try{ (new Function(fine))(); }catch(_){ } } } };
    });
  };
  /* 0.9.321, Andrea: "non ha mai chiesto il sesso prima del nome". Si saltava se il genere c'era gia' (l'Io futuro lo salva): il film lo chiede sempre */
  registra(I.apertura, 'ia', "gnVai('sesso')");
  registra(I.patto, 'ip', "gnVai('ic0')");
  registra(I.cliff, 'ic', "epiSegnaVisto(1);gnVai('salva')");
  return true;
}
function epiIntroParte(){
  if (!epiIntroRegistra() || !GN_PASSI.ia0) return false;
  const I = epiIntro();
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('apertura');
  try{ const sg = document.getElementById('s-genio'); if (sg) sg.classList.remove('apertura'); }catch(_){ }
  epiSigla({ s: 1, n: 1, titolo: I.titolo || '', vis: I.vis || 'luce', poi: function(){ try{ gnAu.musica(); }catch(_){ } gnVai('ia0'); } });
  return true;
}
function epiIntroPatto(){
  if (!epiIntroRegistra() || !GN_PASSI.ip0) return false;
  gnVai('ip0');
  return true;
}

/* ---------------------------------------------------------------- lo stile */
(function(){
  const css = [
    /* la card in Dream (0.9.301): una sola copertina, tutto centrato, bordo vero */
    '.epi-card{background:var(--card,#fff);border:1.5px solid var(--line);border-radius:24px;padding:20px 18px 18px;display:flex;flex-direction:column;align-items:center;gap:14px;text-align:center;cursor:pointer;box-shadow:0 8px 24px rgba(0,30,68,.08)}',
    'body.dark .epi-card{background:#12203A;border-color:#2C4170;box-shadow:none}',
    '.epi-kick{font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#E63946}',
    '.epi-cov{position:relative;align-self:stretch;height:212px;border-radius:20px;overflow:hidden;background:radial-gradient(circle at 50% 34%,#1A3A6B,#06101F 74%);border:1px solid rgba(140,198,255,.3);box-shadow:0 10px 26px rgba(0,30,68,.22)}',
    '.epi-cov-art{position:absolute;left:0;right:0;top:0;height:150px;display:flex;align-items:center;justify-content:center}',
    '.epi-cov-art .epi-vis{min-height:0;height:100%;transform:scale(.72)}',
    '.epi-cov-txt{position:absolute;left:0;right:0;bottom:0;padding:36px 16px 16px;background:linear-gradient(180deg,rgba(2,10,24,0),rgba(2,10,24,.88) 55%);display:flex;flex-direction:column;align-items:center;gap:4px}',
    '.epi-cov-txt small{font:700 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.epi-cov-txt b{font:800 22px/1.2 var(--font-display);color:#fff;text-shadow:0 2px 10px rgba(0,0,0,.5)}',
    '.epi-cov.chiusa .epi-cov-art{filter:grayscale(.85) brightness(.6)}',
    '.epi-cov-lock{position:absolute;top:12px;right:12px;width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.94);color:#0E2350;display:flex;align-items:center;justify-content:center}.epi-cov-lock svg{width:16px;height:16px}',
    '.epi-hook{margin:0;max-width:320px;font:600 15px/1.45 var(--font-body);color:var(--navy)}body.dark .epi-hook{color:#E8F1FF}',
    '.epi-card .epi-cta{box-sizing:border-box;align-self:stretch;width:auto;margin:14px 0 0;display:flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap}.epi-card .epi-cta.sec{background:#E63946;box-shadow:0 12px 26px rgba(230,57,70,.3)}',
    '.epi-conosce{display:flex;align-items:center;justify-content:center;gap:10px}',
    '.epi-conosce .dq-card-ball{width:40px;height:40px;font-size:21px}',
    '.epi-conosce b{font:800 15px var(--font-display);color:var(--navy)}body.dark .epi-conosce b{color:#fff}',
    '.epi-tutti{display:inline-flex;align-items:center;gap:4px;font:700 14px var(--font-body);color:#0075E3}body.dark .epi-tutti{color:#8CC6FF}',
    /* la pagina della serie, come la pagina di una stagione di Zombies, Run! */
    '#s-serie{padding-top:0}',
    '.epi-pg{display:flex;flex-direction:column;padding-bottom:48px}',
    '.epi-hero{position:relative;flex:none;margin:0 -22px;height:280px;overflow:hidden;border-radius:0 0 28px 28px;background:radial-gradient(circle at 50% 44%,#1A3A6B,#06101F 72%)}',
    /* al buio la copertina sfuma nella pagina, come in Zombies, Run!; in chiaro finisce con gli angoli tondi (sfumata nel chiaro diventava grigia) */
    'body.dark .epi-hero{border-radius:0}body.dark .epi-hero::after{content:"";position:absolute;left:0;right:0;bottom:0;height:120px;background:linear-gradient(180deg,rgba(6,16,31,0),var(--bg))}',
    '.epi-hero-art{position:absolute;left:0;right:0;top:64px;height:170px;display:flex;align-items:center;justify-content:center}',
    '.epi-hero-art .epi-vis{min-height:0;height:100%}',
    '.epi-hero-top{position:absolute;left:0;right:0;top:0;z-index:2;display:flex;align-items:center;padding:calc(16px + env(safe-area-inset-top,0px)) 16px 0}',
    '.epi-hero-back{width:40px;height:40px;flex:none;border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.epi-hero-top b{flex:1;min-width:0;margin-right:40px;text-align:center;font:800 18px var(--font-display);color:#fff}',
    '.epi-pg > .epi-conosce{margin-top:20px}',
    '.epi-tabs{display:flex;justify-content:safe center;gap:26px;overflow-x:auto;scrollbar-width:none;margin:22px -22px 6px;padding:0 22px}.epi-tabs::-webkit-scrollbar{display:none}',
    '.epi-tab{flex:none;border:0;background:none;padding:6px 0;display:inline-flex;align-items:center;gap:5px;font:600 17px var(--font-display);color:var(--faint,#8B99AC);cursor:pointer}',
    '.epi-tab.on{font-weight:800;color:var(--navy)}body.dark .epi-tab.on{color:#fff}',
    '.epi-lista{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column}',
    '.epi-lista li{position:relative}',
    '.epi-lista li + li::before{content:"";position:absolute;left:132px;right:0;top:0;height:1px;background:var(--line)}',
    '.epi-lista li.oggi::before,.epi-lista li.oggi + li::before{display:none}',
    '.epi-ep{width:100%;display:flex;align-items:flex-start;gap:16px;padding:16px 0;border:0;background:none;text-align:left;cursor:pointer;color:inherit;font:inherit}',
    '.epi-th{position:relative;flex:none;width:116px;height:72px;border-radius:8px;overflow:hidden;background:radial-gradient(circle at 50% 40%,#1A3A6B,#06101F 75%)}',
    '.epi-th-n{position:absolute;left:0;top:0;z-index:2;min-width:26px;height:26px;padding:0 6px;display:flex;align-items:center;justify-content:center;background:#fff;color:#E63946;font:800 14px var(--font-display);font-style:normal;border-bottom-right-radius:6px}',
    '.epi-th-lock{position:absolute;right:6px;bottom:6px;z-index:2;width:24px;height:24px;border-radius:50%;background:rgba(255,255,255,.94);color:#0E2350;display:flex;align-items:center;justify-content:center}.epi-th-lock svg{width:12px;height:12px}',
    '.epi-ep.chiuso .epi-th .epi-vis{filter:grayscale(.85) brightness(.6)}',
    '.epi-ep-txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px;padding-top:1px}',
    '.epi-ep-txt b{font:700 16px/1.3 var(--font-display);color:var(--navy)}body.dark .epi-ep-txt b{color:#fff}',
    '.epi-ep-txt em{font:500 14px/1.4 var(--font-body);font-style:normal;color:var(--muted)}',
    '.epi-ep.chiuso .epi-ep-txt b{color:var(--muted)}',
    '.epi-st{display:inline-flex;align-items:center;gap:5px;margin-top:5px;font:700 12.5px/1.35 var(--font-body);color:var(--faint,#8B99AC)}.epi-st svg{flex:none}',
    '.epi-st.visto{color:#0075E3}body.dark .epi-st.visto{color:#8CC6FF}',
    '.epi-st.oggi{align-self:flex-start;padding:5px 11px;border-radius:99px;background:#0075E3;color:#fff}.epi-st.oggi svg{width:12px;height:12px}',
    '.epi-st.chiuso{align-items:flex-start}.epi-st.chiuso svg{margin-top:2px}',
    '.epi-ep.oggi{margin:8px 0;padding:14px;border:2px solid #0075E3;border-radius:18px;background:#EAF4FF;box-shadow:0 8px 22px rgba(0,117,227,.18)}',
    'body.dark .epi-ep.oggi{background:rgba(0,117,227,.16);border-color:#4FA8FF;box-shadow:none}',
    '.epi-vuota{margin:22px 0 8px;padding:28px 20px;border:1.5px dashed var(--line);border-radius:20px;display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center;color:var(--muted)}.epi-vuota svg{width:26px;height:26px}.epi-vuota p{margin:0;max-width:300px;font:600 14.5px/1.5 var(--font-body)}',
    /* libri e film per il viaggio */
    '.epi-isp{margin-top:40px;padding-top:32px;border-top:1px solid var(--line);display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.epi-isp h2{margin:0;font:800 21px/1.25 var(--font-display);color:var(--navy)}body.dark .epi-isp h2{color:#fff}',
    '.epi-isp-sotto{margin:10px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    /* la fila di copertine: tre per schermata, scorre di lato se le stagioni crescono (mai tagliata ai bordi) */
    '.epi-isp-fila{align-self:stretch;display:grid;grid-auto-flow:column;grid-auto-columns:calc((100% - 24px) / 3);gap:12px;margin:22px -22px 0;padding:6px 22px 8px;overflow-x:auto;scroll-padding:0 22px;scroll-snap-type:x mandatory;scrollbar-width:none}.epi-isp-fila::-webkit-scrollbar{display:none}',
    '.epi-isp-cop{scroll-snap-align:start;display:flex;flex-direction:column;align-items:center;gap:10px;margin:0;padding:0;border:0;background:none;color:inherit;font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;perspective:900px}',
    /* 0.9.317, Andrea: "Prova in corso viene tagliato". L'altezza la decide il contenuto piu' lungo che ci puo' stare, non un rapporto fisso */
    '.epi-isp-giro{position:relative;display:block;width:100%;height:184px;transform-style:preserve-3d;transition:transform .9s cubic-bezier(.3,.7,.2,1)}',
    '.epi-isp-cop.aperta .epi-isp-giro{transform:rotateY(180deg)}',
    '.epi-isp-faccia{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:14px 8px;border-radius:14px;overflow:hidden;color:#fff;-webkit-backface-visibility:hidden;backface-visibility:hidden;box-shadow:0 10px 22px rgba(6,16,40,.28)}',
    /* la copertina coperta: il cielo della serie, con qualche stella e il punto di domanda che respira */
    '.epi-isp-retro{background:radial-gradient(2px 2px at 22% 18%,rgba(255,255,255,.75),transparent 70%),radial-gradient(1.5px 1.5px at 76% 28%,rgba(255,255,255,.6),transparent 70%),radial-gradient(1.5px 1.5px at 64% 78%,rgba(255,255,255,.5),transparent 70%),radial-gradient(1.5px 1.5px at 18% 70%,rgba(255,255,255,.45),transparent 70%),radial-gradient(120% 70% at 50% 0%,#1E3F7A 0%,#0B1A3D 58%,#050D22 100%);border:1px solid rgba(140,198,255,.22)}',
    '.epi-isp-mist{width:48px;height:48px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;font:400 28px/1 Georgia,"Times New Roman",serif;font-style:normal;color:#fff;background:rgba(255,255,255,.1);box-shadow:0 0 0 1px rgba(255,255,255,.3),0 0 24px rgba(79,168,255,.5)}',
    '.epi-isp-mist.lucchetto svg{width:18px;height:18px}',
    '.epi-isp-cop.f-chiuso .epi-isp-mist{animation:epiIspRespira 2.6s ease-in-out infinite}',
    '@keyframes epiIspRespira{0%,100%{box-shadow:0 0 0 1px rgba(255,255,255,.3),0 0 16px rgba(79,168,255,.35)}50%{box-shadow:0 0 0 1px rgba(255,255,255,.5),0 0 30px rgba(79,168,255,.75)}}',
    '.epi-isp-retro em{max-width:100%;font:600 12px/1.35 var(--font-body);font-style:normal;color:#D6E6FA}',
    /* le stagioni che verranno (e quella rimasta chiusa): stesso cielo, piu' piatto, senza bordo acceso */
    '.epi-isp-cop.f-futuro .epi-isp-retro,.epi-isp-cop.f-perso .epi-isp-retro{background:radial-gradient(1.5px 1.5px at 22% 18%,rgba(255,255,255,.5),transparent 70%),radial-gradient(1.5px 1.5px at 70% 74%,rgba(255,255,255,.4),transparent 70%),linear-gradient(180deg,#2A4A86 0%,#1A3166 100%);box-shadow:0 6px 16px rgba(6,16,40,.18)}',
    '.epi-isp-cop.f-futuro .epi-isp-mist,.epi-isp-cop.f-perso .epi-isp-mist{box-shadow:0 0 0 1px rgba(255,255,255,.22)}',
    /* la stagione di adesso, ancora chiusa: il bordo che si accende */
    '.epi-isp-cop.f-chiuso .epi-isp-retro{border-color:rgba(79,168,255,.7)}',
    /* la copertina scoperta */
    '.epi-isp-fronte{transform:rotateY(180deg);justify-content:flex-start;gap:7px;padding:14px 8px 8px;background:linear-gradient(165deg,#0075E3 0%,#123C86 45%,#0B1A3D 100%);border:1px solid rgba(255,255,255,.28)}',
    '.epi-isp-fronte small{font:800 10px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#D6EBFF}',
    '.epi-isp-emo{width:34px;height:34px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;font-style:normal;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,.25)}',
    '.epi-isp-fronte b{flex:none;max-width:100%;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font:800 13.5px/1.2 var(--font-display);color:#fff}',
    '.epi-isp-badge{align-self:stretch;margin-top:auto;flex:none;display:flex;align-items:center;justify-content:center;gap:4px;padding:5px 4px;border-radius:99px;background:rgba(255,255,255,.18);font:700 10.5px/1.2 var(--font-body);font-style:normal;color:#fff}',
    '.epi-isp-badge.nuovo{background:#E63946}.epi-isp-badge.ok{background:#fff;color:#0075E3}.epi-isp-badge.ok svg{width:11px;height:11px;flex:none}.epi-isp-badge.spento{background:rgba(255,255,255,.12);color:#C9D6EA}',
    '.epi-isp-cop.f-scaduta .epi-isp-fronte{filter:brightness(.72)}',
    '.epi-isp-cop.sel .epi-isp-faccia{box-shadow:0 0 0 2.5px #4FA8FF,0 12px 26px rgba(0,117,227,.35)}',
    '.epi-isp-cop.luce .epi-isp-fronte{animation:epiIspLuce 1.5s ease-out}',
    '@keyframes epiIspLuce{0%{box-shadow:0 0 0 0 rgba(140,198,255,0)}35%{box-shadow:0 0 0 4px rgba(140,198,255,.9),0 0 44px rgba(79,168,255,.85)}100%{box-shadow:0 0 0 2.5px #4FA8FF,0 12px 26px rgba(0,117,227,.35)}}',
    '.epi-isp-cop.scuoti .epi-isp-giro{animation:epiIspScuoti .42s ease}',
    '@keyframes epiIspScuoti{0%,100%{transform:none}25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}',
    '.epi-isp-lab{font:700 12.5px var(--font-body);color:var(--faint,#8B99AC)}',
    '.epi-isp-cop.ora .epi-isp-lab,.epi-isp-cop.sel .epi-isp-lab{color:var(--navy)}body.dark .epi-isp-cop.ora .epi-isp-lab,body.dark .epi-isp-cop.sel .epi-isp-lab{color:#fff}',
    '@media (prefers-reduced-motion:reduce){.epi-isp-giro{transition:none}.epi-isp-cop.f-chiuso .epi-isp-mist,.epi-isp-cop.luce .epi-isp-fronte{animation:none}}',
    /* il dettaglio della copertina scelta */
    '.epi-isp-det{align-self:stretch;margin-top:22px;padding:24px 18px 22px;border:1.5px solid var(--line);border-radius:22px;background:var(--card,#fff);display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;animation:gnIn .4s ease-out both}',
    'body.dark .epi-isp-det{background:#141C2C;border-color:#25314A}.epi-isp-det.in-attesa{display:none}',
    '.epi-isp-det small{margin-bottom:6px;font:700 11px/1.4 var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#E63946}body.dark .epi-isp-det small{color:#FF8A93}',
    '.epi-isp-det h3{margin:0;font:800 20px/1.25 var(--font-display);color:var(--navy)}body.dark .epi-isp-det h3{color:#fff}',
    '.epi-isp-di{font:600 12.5px var(--font-body);color:var(--faint,#8B99AC)}',
    '.epi-isp-perche{margin:10px 0 0;max-width:320px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.epi-isp-nota{margin:12px 0 0;max-width:320px;font:600 14px/1.5 var(--font-body);color:var(--navy)}body.dark .epi-isp-nota{color:#E8F1FF}',
    '.epi-isp-resta{margin:14px 0 0;padding:6px 12px;border-radius:99px;background:#E3F1FF;color:#0E2350;font:700 13px var(--font-body)}body.dark .epi-isp-resta{background:rgba(63,159,244,.18);color:#EEF4FF}',
    '.epi-isp-q{margin-top:12px;font:800 16px/1.35 var(--font-display);color:var(--navy)}body.dark .epi-isp-q{color:#fff}',
    '.epi-isp-campo{align-self:stretch;margin-top:8px}',
    '.epi-isp-area{display:block;width:100%;box-sizing:border-box;min-height:84px;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--bg);color:var(--ink);font:500 15px/1.45 var(--font-body);resize:vertical}',
    '.epi-isp .epi-isp-btn{box-sizing:border-box;align-self:stretch;width:auto;margin-top:22px}',
    '.epi-isp-ok{margin:14px 0 0;display:inline-flex;align-items:center;gap:6px;font:700 14px var(--font-body);color:#0075E3}body.dark .epi-isp-ok{color:#8CC6FF}',
    '.epi-isp-det blockquote{margin:8px 0 0;max-width:320px;font:500 14px/1.5 var(--font-body);font-style:italic;color:var(--navy)}body.dark .epi-isp-det blockquote{color:#E8F1FF}',
    /* le immagini disegnate */
    '.epi-vis{position:relative;width:100%;height:100%;min-height:200px;display:flex;align-items:center;justify-content:center}',
    '.epi-vis.mini{min-height:0;position:absolute;inset:0;transform:scale(.42);transform-origin:50% 50%}',
    '.epi-luce{display:block;width:18px;height:18px;border-radius:50%;background:#FFF6D6;box-shadow:0 0 18px 8px rgba(255,232,170,.75),0 0 60px 26px rgba(140,198,255,.35);animation:epiRespira 2.4s ease-in-out infinite}',
    '.epi-luce.p{position:absolute;width:9px;height:9px;animation:epiRespira 2.8s ease-in-out infinite;animation-delay:var(--d)}',
    '.v-luci-spente .epi-luce.p{animation:epiSpegni 5.5s ease-in forwards;animation-delay:calc(var(--d) * 1.4)}',
    '.v-luci-spente .epi-luce.p:nth-child(3),.v-luci-spente .epi-luce.p:nth-child(9){animation:epiRespira 2.8s ease-in-out infinite}',
    '@keyframes epiRespira{0%,100%{transform:scale(1);opacity:.9}50%{transform:scale(1.25);opacity:1}}',
    '@keyframes epiSpegni{0%{opacity:1}70%{opacity:.9}100%{opacity:.06;box-shadow:none;background:#3A4A66}}',
    '.epi-sfera{display:block;width:150px;height:150px;border-radius:50%;background:radial-gradient(circle at 32% 26%,rgba(255,255,255,.6),rgba(140,198,255,.4) 30%,rgba(0,117,227,.45) 60%,rgba(0,30,68,.8));box-shadow:0 0 50px rgba(63,159,244,.6),inset 0 -20px 40px rgba(0,60,140,.45);animation:epiRespira 3s ease-in-out infinite}',
    '.v-sfera-spenta .epi-sfera{background:radial-gradient(circle at 32% 26%,rgba(255,255,255,.25),rgba(120,134,158,.35) 35%,rgba(40,52,74,.9));box-shadow:inset 0 -18px 30px rgba(0,0,0,.45);animation:none}',
    '.epi-sfera.fioca{opacity:.55;animation:none}',
    '.epi-ladro{width:190px;height:190px;overflow:visible}.epi-vis.mini .epi-ladro{width:150px;height:150px}.epi-ladro .corpo{fill:#0B2A63;stroke:#8CC6FF;stroke-width:3}.epi-ladro .righe rect{fill:#8CC6FF;opacity:.45}.epi-ladro .viso{fill:#F4D3B8}.epi-ladro .cuffia{fill:#E63946}.epi-ladro .risvolto{fill:#B8222F}.epi-ladro .pon{fill:#fff}',
    '.epi-ladro .masch{fill:#001E44}.epi-ladro .nodo{fill:none;stroke:#001E44;stroke-width:4;stroke-linecap:round}.epi-ladro .occhio{fill:#fff}.epi-ladro .pupille{fill:#001E44;animation:epiSguardo 3.2s ease-in-out infinite}.epi-ladro .bocca{fill:none;stroke:#7A3B2E;stroke-width:3.5;stroke-linecap:round}',
    '@keyframes epiSguardo{0%,35%{transform:translateX(0)}45%,75%{transform:translateX(4px)}85%,100%{transform:translateX(-3px)}}',
    '.epi-ombra{position:absolute;width:150px;height:150px;border-radius:50%;background:radial-gradient(circle at 60% 60%,rgba(6,10,20,.95),rgba(6,10,20,.5) 45%,transparent 70%);animation:epiOmbra 4s ease-in-out infinite alternate}',
    '@keyframes epiOmbra{from{transform:translate(28px,18px) scale(.7)}to{transform:translate(-6px,-4px) scale(1.05)}}',
    '.epi-tel{position:relative;width:78px;height:140px;border-radius:16px;border:4px solid #8CC6FF;background:rgba(0,30,68,.6)}',
    '.epi-tel i{position:absolute;left:50%;bottom:8px;width:22px;height:4px;margin-left:-11px;border-radius:2px;background:#8CC6FF}',
    '.epi-tel b{position:absolute;top:-10px;right:-12px;width:26px;height:26px;border-radius:50%;background:#E63946;color:#fff;font:800 13px/26px var(--font-body);text-align:center;animation:epiNotifica 1.8s ease-in-out infinite}',
    '.epi-tel b.b2{top:34px;left:-16px;right:auto;animation-delay:.6s}.epi-tel b.b3{top:84px;right:-16px;animation-delay:1.2s}',
    '@keyframes epiNotifica{0%,100%{transform:scale(.85)}50%{transform:scale(1.15)}}',
    '.epi-pill{display:inline-block;width:46px;height:110px;margin:0 16px;border-radius:23px;transform:rotate(-14deg);box-shadow:0 0 28px rgba(255,255,255,.18)}',
    '.epi-pill.rossa{background:linear-gradient(180deg,#FF8A93 0 50%,#E63946 50%);box-shadow:0 0 34px rgba(230,57,70,.6)}',
    '.epi-pill.blu{background:linear-gradient(180deg,#8CC6FF 0 50%,#0075E3 50%);transform:rotate(14deg);box-shadow:0 0 34px rgba(0,117,227,.6)}',
    '.epi-cornetta{position:relative;width:64px;height:64px;color:#fff;animation:epiSquilla 1.2s ease-in-out infinite}',
    '.epi-onda{position:absolute;width:90px;height:90px;border-radius:50%;border:3px solid rgba(140,198,255,.7);animation:epiOnda 1.8s ease-out infinite}.epi-onda.o2{animation-delay:.9s}',
    '@keyframes epiOnda{from{transform:scale(.6);opacity:1}to{transform:scale(1.9);opacity:0}}',
    '@keyframes epiSquilla{0%,100%{transform:rotate(0)}20%{transform:rotate(-14deg)}40%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}}',
    '.epi-bivio,.epi-mappa{width:170px;height:170px;overflow:visible}',
    '.epi-bivio path{fill:none;stroke-width:9;stroke-linecap:round}.epi-bivio .tronco{stroke:#BFD4EE}.epi-bivio .sx{stroke:#0075E3;filter:drop-shadow(0 0 8px rgba(0,117,227,.8))}.epi-bivio .dx{stroke:#E63946;filter:drop-shadow(0 0 8px rgba(230,57,70,.8))}',
    '.epi-mappa path{fill:none;stroke:#8CC6FF;stroke-width:4;stroke-dasharray:8 9;stroke-linecap:round;animation:epiTraccia 3s linear infinite}.epi-mappa circle{fill:#0075E3;stroke:#fff;stroke-width:3}.epi-mappa .arrivo{fill:#E63946}',
    '@keyframes epiTraccia{to{stroke-dashoffset:-68}}',
    /* la scena: con un'immagine il testo e' bianco sul cielo, senza nuvoletta (come l'apertura) */
    '.gn.epi-cine .gn-sopra{display:flex;align-items:center;justify-content:center}',
    '.gn.epi-cine .gn-box{background:transparent !important;border:0 !important;box-shadow:none !important;padding:10px 8px;min-height:0}',
    '.gn.epi-cine .gn-box p{color:#fff !important;font:800 22px/1.32 var(--font-display);text-align:center;text-shadow:0 2px 14px rgba(0,0,0,.55)}',
    '.gn.epi-cine .gn-box p b{color:#8CC6FF !important}',
    '.gn.epi-cine .gn-freccia{display:none}',
    /* la sigla */
    '.epi-sigla{position:absolute;inset:0;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;background:radial-gradient(circle at 50% 38%,#12305E,#020A18 72%);text-align:center;cursor:pointer}',
    '.epi-sigla[hidden]{display:none}',
    '.epi-sigla .epi-vis{flex:none;height:220px;min-height:0;width:100%}',
    '.epi-sigla small{font:700 12px var(--font-body);letter-spacing:.22em;text-transform:uppercase;color:#8CC6FF;opacity:0}',
    '.epi-sigla b{font:900 34px/1.15 var(--font-display);color:#fff;max-width:320px;opacity:0}',
    '.epi-sigla > span{margin-top:18px;font:600 12px var(--font-body);color:#BFD4EE;opacity:0}',
    '.epi-sigla.su small{animation:gnIn .6s .2s ease-out forwards}.epi-sigla.su b{animation:gnIn .7s .55s ease-out forwards}.epi-sigla.su > span{animation:gnIn .6s 1.4s ease-out forwards}',
    '.epi-sigla.via{animation:epiVia .42s ease-in forwards}',
    '@keyframes epiVia{to{opacity:0;transform:scale(1.04)}}',
    /* la lezione, i dati, la fine */
    '.epi-lez{background:#fff;border:2px solid #0E2350;border-radius:22px;padding:20px 18px;color:#0E2350;text-align:center;animation:gnIn .4s ease-out both}',
    'body.dark .epi-lez{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.epi-lez small{display:block;font:700 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}body.dark .epi-lez small{color:#8CC6FF}',
    /* 0.9.306: tutto al centro; l'emoji in un cerchio bianco con il lucchetto che si apre e la lezione che vola nell'Academy */
    '#gnRisp > .ak-indietro + .epi-lez{margin-top:16px}#gnRisp > .ak-indietro:has(+ .epi-lez){margin-top:10px}',
    '.epi-lez-art{position:relative;width:72px;height:72px;margin:14px auto 12px}',
    '.epi-lez-ico{display:flex;align-items:center;justify-content:center;width:72px;height:72px;border-radius:50%;background:#E3F1FF;font-size:36px;line-height:1}body.dark .epi-lez-ico{background:#fff}',
    '.epi-lez-chiuso{position:absolute;right:-6px;bottom:-4px;width:32px;height:32px;border-radius:50%;background:#E63946;color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 3px #fff}body.dark .epi-lez-chiuso{box-shadow:0 0 0 3px #141C2C}',
    '.epi-lez-arco{transform-origin:16px 11px;transition:transform .45s cubic-bezier(.3,1.6,.5,1) .35s}',
    '.epi-lez-art.via .epi-lez-arco{transform:translate(0,-3px) rotate(32deg)}',
    '.epi-lez-art.via .epi-lez-chiuso{animation:epiLucVia .4s ease-in 1s both}',
    '@keyframes epiLucVia{to{opacity:0;transform:scale(.4)}}',
    '.epi-lez-volo{position:absolute;left:0;top:0;width:72px;height:72px;display:flex;align-items:center;justify-content:center;font-size:36px;line-height:1;opacity:0;pointer-events:none;z-index:2}',
    '.epi-lez-art.via .epi-lez-volo{animation:epiLezVolo .8s cubic-bezier(.5,0,.6,1) 1.25s both}',
    '@keyframes epiLezVolo{0%{opacity:1;transform:none}80%{opacity:1}100%{opacity:0;transform:translate(var(--dx,0),var(--dy,90px)) scale(.35)}}',
    '.epi-lez b{display:block;font:800 19px/1.25 var(--font-display)}',
    '.epi-lez-nota{display:block;margin:10px 0 0;font:800 15.5px/1.4 var(--font-body);color:#0075E3}body.dark .epi-lez-nota{color:#8CC6FF}',
    '.epi-lez-dove{display:flex;align-items:center;justify-content:center;gap:8px;margin:14px auto 0;padding:9px 14px;border-radius:14px;background:#E3F1FF;font:600 13.5px/1.4 var(--font-body);color:#0E2350;max-width:300px}body.dark .epi-lez-dove{background:rgba(140,198,255,.14);color:#DCE8F5}',
    '.epi-lez-cap{flex:none;width:30px;height:30px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:17px;font-style:normal;line-height:1}',
    '.epi-lez-art.via ~ .epi-lez-dove .epi-lez-cap{animation:epiCapPop .5s ease-out 2s both}',
    '@keyframes epiCapPop{0%{transform:scale(1)}45%{transform:scale(1.35);box-shadow:0 0 0 6px rgba(0,117,227,.25)}100%{transform:scale(1);box-shadow:none}}',
    '@media (prefers-reduced-motion:reduce){.epi-lez-art.via .epi-lez-volo{animation:none}.epi-lez-art.via .epi-lez-chiuso{animation:none;opacity:0}}',
    /* la lezione a fine episodio: si tocca e porta all'Academy del Profilo */
    /* 0.9.308: sta nella schermata di fine tappa (s-sd-fine, sempre blu notte), testo al centro fra icona e freccia */
    '.epi-fs-passo .sd-fine-in > h2{margin-top:18px}.epi-fs-passo .epi-fine-ac{margin:22px 0 26px}.epi-fs-passo .epi-fs-pross{margin:18px 0 28px}.epi-fs-passo .epi-fs-sec{margin-top:12px}.epi-fs-passo .epi-fs-pross small{display:none}',
    '.epi-fine-ac{display:flex;align-items:center;gap:10px;width:100%;margin:0 0 18px;padding:12px;border:1.5px solid rgba(140,198,255,.55);border-radius:18px;background:rgba(255,255,255,.08);color:#fff;text-align:center;cursor:pointer;font-family:var(--font-body)}',
    '.epi-fine-ac-ico{flex:none;width:44px;height:44px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;line-height:1}',
    '.epi-fine-ac-va{flex:none;width:44px;display:flex;align-items:center;justify-content:center;color:#8CC6FF}',
    '.epi-fine-ac-t{flex:1;min-width:0}.epi-fine-ac-t small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.epi-fine-ac-t b{display:block;margin-top:3px;font:800 15px/1.3 var(--font-display);color:#fff}',
    /* la fine dell'episodio nella schermata di fine tappa: se il telefono e' basso scorre, invece di tagliare il pulsante */
    '#sdFine.epi-fs{overflow-y:auto;align-items:safe center;padding-top:calc(20px + env(safe-area-inset-top,0px));padding-bottom:calc(20px + env(safe-area-inset-bottom,0px))}',
    '#sdFine.epi-fs .sd-box3{margin-bottom:24px}',
    '.epi-fs-pross{margin:0 0 24px;text-align:center}',
    '.epi-fs-pross small{display:block;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#F6CCE4}',
    '.epi-fs-pross b{display:block;margin-top:5px;font:800 18px/1.25 var(--font-display);color:#fff}',
    '#sdFine .epi-fs-pross p{margin:5px auto 0;max-width:30ch;font:600 14px/1.45 var(--font-body);color:#C8D6EA}',
    '.epi-fs-sec{display:block;width:100%;margin-top:12px;padding:15px 20px;border-radius:50px;border:2px solid rgba(255,255,255,.7);background:transparent;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.epi-dato{margin-top:8px;background:rgba(255,255,255,.1);border:1px solid rgba(140,198,255,.35);border-radius:18px;padding:14px 16px;color:#fff;text-align:left;animation:gnIn .4s ease-out both}',
    '.epi-dato small{display:block;font:700 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#8CC6FF}',
    '.epi-dato ol{list-style:none;margin:8px 0 0;padding:0}.epi-dato li{display:flex;align-items:center;gap:10px;padding:8px 0;font:700 14px/1.35 var(--font-body);border-top:1px solid rgba(255,255,255,.1)}.epi-dato li:first-child{border-top:0}.epi-dato li span{font-size:20px}',
    '.epi-dato.data{text-align:center}.epi-dato.data b{display:block;margin:6px 0;font:900 30px/1.15 var(--font-display);color:#fff}.epi-dato p{margin:4px 0 0;font:500 13.5px/1.5 var(--font-body);color:#DCE8F5}',
    '.epi-dato.ladro b{display:block;margin-top:6px;font:800 18px var(--font-display);color:#FF8A93}',
    '.gn:not(.epi-cine) .epi-dato{background:#F4F8FF;border-color:#C9D6EA;color:#0E2350}.gn:not(.epi-cine) .epi-dato small{color:#0075E3}.gn:not(.epi-cine) .epi-dato.data b{color:#0E2350}.gn:not(.epi-cine) .epi-dato p{color:#4A5B78}',
    'body.dark .gn:not(.epi-cine) .epi-dato{background:#141C2C;border-color:#2C3C5C;color:#EEF4FF}body.dark .gn:not(.epi-cine) .epi-dato.data b{color:#fff}body.dark .gn:not(.epi-cine) .epi-dato p{color:#BFD0E8}',
    '.epi-nota{margin:10px 0 0;text-align:center;font:600 12.5px var(--font-body);color:#BFD4EE}',
    /* 0.9.344: completa la frase. L'inizio della frase sta sopra al campo, grande; lo specchio e' una carta con le sue parole */
    '.epi-fr{display:flex;flex-direction:column;gap:14px;margin:10px 0 18px}',
    '.epi-fr-inizio{margin:0;text-align:center;font:800 19px/1.35 var(--font-display);color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.5)}',
    '.epi-dato.epi-regola{margin:8px 0 48px;padding:22px 18px;text-align:center;border-color:rgba(140,198,255,.55)}',
    '.epi-dato.epi-regola small{font-size:12px}body.dark .gn .epi-dato.epi-regola small{color:#8CC6FF}',
    '.epi-dato.epi-regola b{display:block;margin-top:12px;font:800 20px/1.36 var(--font-display);color:inherit;overflow-wrap:anywhere}',
    '@media (max-height:700px){.gn.epi-frase .gn-sopra{display:none}.gn.epi-frase .gn-box{margin-top:44px}}',
    '.gn-link.epi-fr-rifai{align-self:center;margin:-30px 0 44px;font-size:14px}',
    '.epi-scrivo-link{display:block;margin:10px auto 0}',
    '.gn-cards .gn-card.tratt{border-style:dashed}',
    /* "Lo scrivo io" in fondo, largo, quando le carte sono dispari */
    '.gn-cards.dispari-s .gn-card.tratt{grid-column:1 / -1;flex-direction:row;justify-content:center;gap:10px;padding-top:12px;padding-bottom:12px}.gn-cards.dispari-s .gn-card.tratt small{display:none}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* ---------------------------------------------------------------- la sfera del Genio, spiegata (0.9.306)
   Andrea, 29/10: "Il tuo focus ha ricaricato la sfera..." non si capiva perche' compariva, durava due secondi (un toast)
   e non diceva niente. COS'E' DAVVERO: dall'ottavo giorno del viaggio l'episodio del giorno si sblocca solo con la prima
   tappa reale della Mappa di quel giorno (epiStatoDi, k 'tappa'); "la sfera" e' l'immagine di quel cancello. Non ha una
   quantita': oggi e' accesa (tappa fatta, o primi sette giorni) o spenta. L'avviso adesso dice quale tappa l'ha accesa,
   resta 7 secondi (o finche' non lo tocchi), e toccandolo si apre il foglio che spiega la sfera con lo stato di oggi.
   I testi stanno in content/episodi.json (ui.sfera_*). */
const EPI_SF = { t: 0 };
const EPI_X = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const EPI_INFO = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg>';
/** La prima tappa reale fatta oggi sulla Mappa: e' lei che ha acceso la sfera. '' se non si sa. */
function epiSferaTappa(){
  try{
    const l = (typeof sdFatteOggi === 'function' ? sdFatteOggi() : []).filter(function(nd){ return nd.tipo !== 'sc'; });
    const nd = l[l.length - 1];
    return nd && typeof sdNomeTappa === 'function' ? String(sdNomeTappa(nd) || '').trim() : '';
  }catch(_){ return ''; }
}
function epiSferaInfoBtn(){
  return ' <button type="button" class="epi-sf-info" onclick="event.stopPropagation();epiSferaApri()" aria-label="' + epiEsc(epiUi('sfera_info')) + '">' + EPI_INFO + '</button>';
}
/** L'avviso dello sblocco: in alto, 7 secondi o finche' non lo tocchi; il tocco apre la spiegazione. */
function epiSferaAvviso(n){
  epiSferaAvvisoVia();
  const tappa = epiSferaTappa();
  const w = document.createElement('div');
  w.id = 'epiSfAvviso'; w.className = 'epi-sf-avviso'; w.setAttribute('role', 'status');
  w.innerHTML = '<button type="button" class="epi-sf-avx" aria-label="Chiudi l’avviso" onclick="event.stopPropagation();epiSferaAvvisoVia()">' + EPI_X + '</button>'
    + '<span class="epi-sf-avico" aria-hidden="true">🔮</span>'
    + '<b>' + epiEsc(epiUi('sfera_avviso_t', { n: n })) + '</b>'
    + '<p>' + epiEsc(tappa ? epiUi('sfera_avviso_tappa', { tappa: tappa }) : epiUi('sfera_avviso_prima')) + '</p>'
    + '<small>' + epiEsc(epiUi('sfera_avviso_tocca')) + '</small>';
  w.onclick = function(){ epiSferaAvvisoVia(); epiSferaApri(); };
  (document.getElementById('phone') || document.body).appendChild(w);
  try{ flVibra(12); }catch(_){ }
  clearTimeout(EPI_SF.t);
  EPI_SF.t = setTimeout(function(){ const a = document.getElementById('epiSfAvviso'); if (!a) return; a.classList.add('via'); setTimeout(function(){ if (a.parentNode) a.remove(); }, 320); }, 7000);
}
function epiSferaAvvisoVia(){ clearTimeout(EPI_SF.t); const a = document.getElementById('epiSfAvviso'); if (a) a.remove(); }
/** Il foglio: cos'e' la sfera, come si accende, a cosa serve, e com'e' oggi. */
function epiSferaApri(){
  epiSferaChiudi();
  const o = epiOggi(), g = epiGiorno();
  const vistoOggi = epiVistoOggi();
  const accesa = g < 8 || epiTappaOggi();
  const aperto = !!o.x && (o.st.k === 'da-vedere' || o.st.k === 'in-corso');
  let stato;
  if (!o.x) stato = epiUi('sfera_stato_fine');
  else if (vistoOggi) stato = epiUi('sfera_stato_visto');
  else if (!accesa) stato = epiUi('sfera_stato_spenta');
  else if (o.st.k === 'bloccato') stato = o.st.motivo;
  else stato = epiUi(g < 8 ? 'sfera_stato_primi' : 'sfera_stato_ep', { n: o.x.n });
  const tappa = (g >= 8 && accesa) ? epiSferaTappa() : '';
  let cta;
  if (aperto) cta = '<button type="button" class="epi-sf-cta" onclick="epiSferaChiudi();epiTocca(' + o.x.s + ',' + o.x.n + ')">' + epiEsc(epiUi(o.st.k === 'in-corso' ? 'cta_riprendi' : 'cta_guarda', { n: o.x.n })) + '</button>';
  else if (o.x && !accesa && !vistoOggi) cta = '<button type="button" class="epi-sf-cta" onclick="epiSferaChiudi();epiVaiMappa()">' + epiEsc(epiUi('cta_tappa')) + '</button>';
  else cta = '<button type="button" class="epi-sf-cta" onclick="epiSferaChiudi()">' + epiEsc(epiUi('sfera_ok')) + '</button>';
  const punti = [['🔮', 'sfera_p1'], ['🗺️', 'sfera_p2'], ['🎬', 'sfera_p3']].map(function(p){
    return '<li><i aria-hidden="true">' + p[0] + '</i><span>' + epiEsc(epiUi(p[1])) + '</span></li>';
  }).join('');
  const v = document.createElement('div');
  v.id = 'epiSfVelo'; v.className = 'epi-sf-velo';
  v.onclick = function(e){ if (e.target === v) epiSferaChiudi(); };
  v.innerHTML = '<div class="epi-sf-f" role="dialog" aria-modal="true">'
    + '<button type="button" class="epi-sf-x" aria-label="Chiudi" onclick="epiSferaChiudi()">' + EPI_X + '</button>'
    + '<div class="epi-sf-ball' + (accesa ? '' : ' v-sfera-spenta') + '"><i class="epi-sfera"></i></div>'
    + '<small class="epi-sf-kick">' + epiEsc(epiUi('sfera_kick')) + '</small>'
    + '<h2 class="epi-sf-h">' + epiEsc(epiUi(accesa ? 'sfera_accesa' : 'sfera_spenta')) + '</h2>'
    + (tappa ? '<p class="epi-sf-tappa">' + epiEsc(epiUi('sfera_da_tappa', { tappa: tappa })) + '</p>' : '')
    + '<p class="epi-sf-stato">' + epiEsc(stato) + '</p>'
    + '<ul class="epi-sf-punti">' + punti + '</ul>'
    + cta + '</div>';
  (document.getElementById('phone') || document.body).appendChild(v);
}
function epiSferaChiudi(){ const v = document.getElementById('epiSfVelo'); if (v) v.remove(); }
(function(){
  const css = [
    '.epi-sf-info{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;margin:-4px 0 -6px 2px;padding:0;border:0;border-radius:50%;background:transparent;color:#0075E3;vertical-align:middle;cursor:pointer}body.dark .epi-sf-info{color:#8CC6FF}',
    /* l'avviso: blu notte su tutte e due le modalita', con il bordo azzurro che lo stacca dal fondo scuro */
    '.epi-sf-avviso{position:fixed;left:14px;right:14px;top:calc(14px + env(safe-area-inset-top,0px));z-index:9550;display:flex;flex-direction:column;align-items:center;gap:4px;padding:16px 46px 14px;border-radius:22px;background:#0E2350;border:1px solid #3F9FF4;color:#fff;text-align:center;box-shadow:0 14px 34px rgba(0,30,68,.38);cursor:pointer;animation:epiSfGiu .35s ease-out both}',
    '.epi-sf-avviso.via{animation:epiSfSu .3s ease-in forwards}',
    '@keyframes epiSfGiu{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:none}}@keyframes epiSfSu{to{opacity:0;transform:translateY(-16px)}}',
    '.epi-sf-avico{width:38px;height:38px;border-radius:50%;background:#fff;display:grid;place-items:center;font-size:21px;line-height:1;margin-bottom:4px}',
    '.epi-sf-avviso b{font:800 16px/1.3 var(--font-display);color:#fff}',
    '.epi-sf-avviso p{margin:0;font:500 14px/1.45 var(--font-body);color:#DCE8F5}',
    '.epi-sf-avviso small{margin-top:4px;font:700 12.5px var(--font-body);color:#8CC6FF}',
    '.epi-sf-avx{position:absolute;top:8px;right:8px;width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;display:grid;place-items:center;padding:0}',
    /* il foglio */
    '.epi-sf-velo{position:fixed;inset:0;z-index:9600;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,30,68,.55);animation:epiSfVelo .2s ease-out both}body.dark .epi-sf-velo{background:rgba(2,8,22,.74)}',
    '@keyframes epiSfVelo{from{opacity:0}to{opacity:1}}',
    '.epi-sf-f{position:relative;width:100%;max-width:520px;max-height:92vh;overflow:auto;box-sizing:border-box;padding:30px 26px calc(26px + env(safe-area-inset-bottom,0px));border-radius:26px 26px 0 0;background:#fff;color:#0E2350;text-align:center;box-shadow:0 -10px 40px rgba(0,30,68,.28)}',
    'body.dark .epi-sf-f{background:#1C2E5A;border:1px solid #3A5590;border-bottom:0;color:#fff}',
    '.epi-sf-x{position:absolute;top:12px;right:12px;width:38px;height:38px;border:0;border-radius:50%;background:#E3F1FF;color:#0E2350;display:grid;place-items:center;padding:0}body.dark .epi-sf-x{background:rgba(255,255,255,.14);color:#fff}',
    '.epi-sf-ball{display:flex;justify-content:center;margin:2px 0 14px}.epi-sf-ball .epi-sfera{width:92px;height:92px}',
    '.epi-sf-kick{display:block;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}body.dark .epi-sf-kick{color:#8CC6FF}',
    '.epi-sf-h{margin:6px 0 10px;font:800 24px/1.25 var(--font-display);color:#0E2350}body.dark .epi-sf-h{color:#fff}',
    '.epi-sf-tappa{margin:0 auto 6px;max-width:330px;font:700 15px/1.45 var(--font-body);color:#0075E3}body.dark .epi-sf-tappa{color:#8CC6FF}',
    '.epi-sf-stato{margin:0 auto 26px;max-width:330px;font:500 15px/1.5 var(--font-body);color:#4A5A72}body.dark .epi-sf-stato{color:#D6E4F7}',
    '.epi-sf-punti{list-style:none;margin:0 auto;padding:0;max-width:330px;display:grid;gap:18px}',
    '.epi-sf-punti li{display:flex;flex-direction:column;align-items:center;gap:8px;font:500 15px/1.45 var(--font-body);color:#0E2350}body.dark .epi-sf-punti li{color:#EEF4FF}',
    '.epi-sf-punti i{width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:#E3F1FF;font-style:normal;font-size:21px;line-height:1}body.dark .epi-sf-punti i{background:#fff}',
    '.epi-sf-cta{display:block;width:100%;margin-top:30px;padding:16px;border:0;border-radius:999px;background:#0075E3;color:#fff;font:800 17px var(--font-body);box-shadow:0 8px 20px rgba(0,117,227,.28);cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

epiCarica();
setTimeout(epiMigra, 1500);
(function(){ const st = document.createElement('style'); st.textContent = '.epi-pc{display:flex;flex-direction:column;align-items:center;gap:12px;padding:6px 4px 4px;text-align:center}.epi-pc-ico{display:flex;align-items:center;justify-content:center;width:72px;height:72px;border-radius:50%;background:#F0FBFF;font-size:36px}.epi-pc b{font:800 20px var(--font-display);color:var(--navy)}.epi-pc p{margin:0 0 6px;font:500 14.5px/1.5 var(--font-body);color:var(--muted)}.epi-pc .cta{width:100%}body.dark .epi-pc-ico{background:#14305E}'; document.head.appendChild(st); })();
