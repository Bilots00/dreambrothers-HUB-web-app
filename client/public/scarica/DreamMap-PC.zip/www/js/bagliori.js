/* ===========================================================================================
   I BAGLIORI CHE GIRANO, SENZA RIDISEGNARE (0.9.262)

   Andrea: scorrendo, START (e le schede con lo slideshow) andavano a scatti. Misurato con il
   profiler su BlueStacks: il JS pesava poco; a pesare era il motore che RIDISEGNAVA a ogni
   fotogramma. Fra le cause, i bagliori colorati (il pannello "Sessioni di oggi", la bolla della
   frase nel Profilo, la serie dei blocchi): giravano animando l'ANGOLO di un conic-gradient
   sfocato. Un angolo che cambia e' un'immagine nuova: gradiente ridipinto e risfocato a ogni
   fotogramma, sul filo principale.

   Adesso il gradiente e' fermo dentro a uno strato quadrato che RUOTA (transform): lo gira la
   scheda grafica. Per le forme rotonde basta ruotare il disco (identico a se stesso); per i
   pannelli rettangolari il disco e' piu' grande della diagonale e lo ritaglia la cornice
   (.glw, stessi bordi e stessa sfocatura di prima). A schermo non cambia niente.
   =========================================================================================== */
const GLW_HOST = [
  { sel: '.life-wrap', inset: 8, r: 30, blur: 13, z: -1, dur: 3 },
  { sel: '.pf-box', inset: 8, r: 25, blur: 12, z: -3, dur: 3 },
  { sel: '.blk-streak', inset: 7, r: 29, blur: 12, z: -2, dur: 3 }
];
/* 0.9.264: la sfocatura non si rifa' piu' a ogni fotogramma. La forma sfocata del pannello si disegna UNA volta
   su un canvas (quando il pannello cambia misura) e diventa la maschera della cornice: dietro gira solo il disco
   colorato. Prima la scheda grafica risfocava 13 px dell'intero pannello a ogni fotogramma, anche scorrendo. */
function glwConf(host){ for (let i = 0; i < GLW_HOST.length; i++){ if (host.matches(GLW_HOST[i].sel)) return GLW_HOST[i]; } return GLW_HOST[0]; }
function glwMisura(host){
  const box = host.querySelector(':scope > .glw'); const g = box && box.querySelector('b'); if (!g) return;
  const w = host.offsetWidth, h = host.offsetHeight;
  if (!w || !h) return;
  const k = w + 'x' + h;
  if (box._k === k) return;
  box._k = k;
  const c = glwConf(host);
  const pad = c.inset + c.blur * 2;
  const W2 = w + pad * 2, H2 = h + pad * 2;
  try{
    const cv = document.createElement('canvas'); cv.width = W2; cv.height = H2;
    const x = cv.getContext('2d');
    x.filter = 'blur(' + c.blur + 'px)';
    x.fillStyle = '#fff';
    const rx = pad - c.inset, ry = pad - c.inset, rw = w + c.inset * 2, rh = h + c.inset * 2, rr = c.r;
    x.beginPath();
    x.moveTo(rx + rr, ry); x.arcTo(rx + rw, ry, rx + rw, ry + rh, rr); x.arcTo(rx + rw, ry + rh, rx, ry + rh, rr);
    x.arcTo(rx, ry + rh, rx, ry, rr); x.arcTo(rx, ry, rx + rw, ry, rr); x.closePath(); x.fill();
    const url = 'url(' + cv.toDataURL('image/png') + ')';
    box.style.inset = '-' + pad + 'px';
    box.style.webkitMaskImage = url; box.style.maskImage = url;
    box.style.webkitMaskSize = '100% 100%'; box.style.maskSize = '100% 100%';
  }catch(_){ }
  const lato = Math.ceil(Math.hypot(W2, H2)) + 20;
  g.style.width = g.style.height = lato + 'px';
  g.style.marginLeft = g.style.marginTop = (-lato / 2) + 'px';
}
let GLW_RO = null;
function glwMetti(host){
  /* si guarda il figlio, non un segno: chi ridisegna il pannello con innerHTML lo toglie, e qui si rimette */
  if (!host || host.querySelector(':scope > .glw')) return;
  const i = document.createElement('i'); i.className = 'glw'; i.setAttribute('aria-hidden', 'true');
  i.appendChild(document.createElement('b'));
  host.insertBefore(i, host.firstChild);
  glwMisura(host);
  try{ if (!GLW_RO) GLW_RO = new ResizeObserver(function(l){ l.forEach(function(x){ glwMisura(x.target); }); }); if (!host._glwOss){ host._glwOss = 1; GLW_RO.observe(host); } }catch(_){ }
}
function glwCerca(radice){
  GLW_HOST.forEach(function(h){
    if (radice.matches && radice.matches(h.sel)) glwMetti(radice);
    if (radice.querySelectorAll) radice.querySelectorAll(h.sel).forEach(glwMetti);
  });
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* i vecchi bagliori dipinti si spengono */
    GLW_HOST.map(function(h){ return h.sel + '::before'; }).join(',') + '{animation:none !important;background:none !important;filter:none !important}',
    /* la cornice: stessi bordi e stessa sfocatura di prima; dentro, il disco che gira */
    '.glw{position:absolute;pointer-events:none;overflow:hidden;display:block}',
    GLW_HOST.map(function(h){ return h.sel + ' > .glw{inset:-' + (h.inset + h.blur * 2) + 'px;z-index:' + h.z + '}'; }).join(''),
    /* 0.9.265 (lag): il disco si centra con i margini, non con translate. translate + l'animazione di transform sullo stesso
       elemento non si possono dare alla scheda grafica: la rotazione la ricalcolava il thread principale 60 volte al secondo,
       anche a schermo fermo (misurato: 240 fotogrammi in 4 s da fermi, 47 con il bagliore spento). */
    '.glw > b{position:absolute;left:50%;top:50%;width:200%;height:200%;margin:-100% 0 0 -100%;border-radius:50%;',
      'background:conic-gradient(#3F9FF4,#0075E3,#E63946,#3F9FF4);animation:glwGira 3s linear infinite;will-change:transform}',
    '@keyframes glwGira{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}',
    /* la serie dei blocchi: il bagliore solo quando e' accesa, e il respiro della nascita */
    '.blk-streak:not(.accesa) > .glw{display:none}',
    '.blk-streak.accesa.nuova > .glw{animation:blkNato 1.2s ease-out}',
    /* le forme rotonde: basta ruotare il disco (identico a se stesso), niente angolo ridipinto */
    '.strict-bubble::before,.or-ball::before,.nv-cover-aura i,.ic-onda{animation-name:flGlowSpin !important}',
    /* 0.9.263, Andrea: lo scroll scattava ancora. Le sfocature dello sfondo (backdrop-filter) sopra a
       contenuti che scorrono obbligano a ridisegnare e risfocare tutto quello che sta dietro a ogni
       fotogramma (le card dei programmi in START venivano ridisegnate 900 volte in 5 s). Via la sfocatura,
       gli sfondi restano i loro (gia' semitrasparenti): a schermo quasi non cambia. */
    '.bottomnav,.hdr-cont button,.hdr-match,.pr-go,.mt-kick,.mt-clock,.nv-fumetto,.pf-details,.sev-face-x,.home-head{-webkit-backdrop-filter:none !important;backdrop-filter:none !important}',
    '.pr-go{background:rgba(255,255,255,.26)}',
    '.bh-plx{will-change:transform}',
    /* 0.9.267: la scheda che scorre e' composta dalla scheda grafica fin dal primo fotogramma (Chrome altrimenti la
       promuove solo DOPO il primo scroll e la smonta a ogni cambio scheda: e' il "lagga al primo scroll" di Andrea);
       cosi' anche le animazioni legate allo scroll hanno sempre una sorgente composta. */
    '.tabpage{will-change:scroll-position}',
    /* la bolla del lucchetto chiusa (scale 0) faceva girare il suo anello per sempre, invisibile */
    '.strict-bubble:not(.on)::before{animation:none !important}',
    /* la cerchiatura disegnata nel titolo (stroke-dashoffset, per forza sul thread principale): in un livello suo,
       cosi' ridisegna solo se stessa e non la slide intera */
    '.fl-hl-svg{will-change:transform}'
  ].join('');
  document.head.appendChild(st);
  const parti = function(){
    glwCerca(document.body);
    try{
      let glwRaf = 0;
      new MutationObserver(function(m){
        if (glwRaf) return;
        glwRaf = requestAnimationFrame(function(){ glwRaf = 0; glwCerca(document.body); });
        return;
        for (let k = 0; k < m.length; k++){
          const a = m[k].addedNodes;
          for (let j = 0; j < a.length; j++){ if (a[j].nodeType === 1 && a[j].className !== 'glw') glwCerca(a[j]); }
          /* un pannello ridisegnato dentro (innerHTML): il suo bagliore si rimette */
          if (m[k].target && m[k].target.nodeType === 1 && m[k].removedNodes.length) glwCerca(m[k].target);
        }
      }).observe(document.body, { childList: true, subtree: true });
    }catch(_){ }
  };
  if (document.body) parti(); else document.addEventListener('DOMContentLoaded', parti);
})();
