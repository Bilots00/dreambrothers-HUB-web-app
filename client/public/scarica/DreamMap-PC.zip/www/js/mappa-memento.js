/* ===========================================================================================
   MEMENTO MORI DENTRO ALLA MAPPA (0.9.253)

   Andrea: il calendario della vita in settimane e' una VISTA della scheda Mappa, e si apre
   toccando la cartina con l'aereo (la prima diapositiva della Roadmap). Non e' una pagina a
   parte: la scheda resta la Mappa, cambia solo quello che mostra. In alto una riga per tornare
   alla cartina; sotto, lo stesso calendario di memento.js disegnato qui dentro (mmPaint con un
   contenitore diverso). Cambiando scheda o vista, la Mappa torna com'era.
   =========================================================================================== */
function mppMementoHost(){
  const tab = document.getElementById('tab-mappa'); if (!tab) return null;
  let h = document.getElementById('mppMemento');
  if (!h){
    h = document.createElement('div'); h.id = 'mppMemento'; h.className = 'mpp-mm';
    h.innerHTML = '<div class="mpp-mm-top"><button type="button" class="mpp-mm-back" onclick="mppMementoChiudi()" aria-label="Torna alla cartina">' + '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>' + '<span>La cartina</span></button><b>La tua vita in settimane</b></div>'
      + '<div id="mppMementoBody"></div>';
    tab.insertBefore(h, tab.firstChild);
  }
  return h;
}
function mppMementoApri(){
  const tab = document.getElementById('tab-mappa'), h = mppMementoHost(); if (!tab || !h) return;
  try{ localStorage.setItem('fl_mm_visto', '1'); }catch(_){ }
  tab.classList.add('mpp-memento');
  try{ flVibra(8); }catch(_){ }
  try{ mmPaint('mppMementoBody'); }catch(_){ }
  tab.scrollTop = 0;
}
function mppMementoChiudi(){
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  tab.classList.remove('mpp-memento');
  /* il calendario a pagina intera (s-memento) deve tornare a disegnare nel suo posto */
  try{ if (typeof MM_HOST !== 'undefined') MM_HOST = 'mmBody'; }catch(_){ }
  tab.scrollTop = 0;
}
function mppMementoAperto(){ const tab = document.getElementById('tab-mappa'); return !!(tab && tab.classList.contains('mpp-memento')); }
(function(){
  /* 0.9.256, Andrea: la cartina NON si tocca piu' per aprire il calendario: il memento mori e' il
     terzo tipo di mappa del pulsante del satellite (rotta.js, RT_STRATI). Questa vista a tutta scheda
     resta per chi la vuole (mppMementoApri), ma non parte da sola. */
  document.addEventListener('fl:tab', function(e){ if (e.detail !== 'mappa') mppMementoChiudi(); });
  if (typeof mppVista === 'function'){ const v = mppVista; window.mppVista = mppVista = function(){ mppMementoChiudi(); return v.apply(this, arguments); }; }
  /* se la Mappa si ridisegna da capo mentre il calendario e' aperto, resta aperto */
  if (typeof mppPaint === 'function'){ const p = mppPaint; window.mppPaint = mppPaint = function(){ const r = p.apply(this, arguments); try{ if (mppMementoAperto()){ mppMementoHost(); mmPaint('mppMementoBody'); } }catch(_){ } return r; }; }
  const st = document.createElement('style');
  st.textContent = [
    '#tab-mappa.mpp-memento > :not(#mppMemento){display:none!important}',
    '#tab-mappa:not(.mpp-memento) > #mppMemento{display:none}',
    '.mpp-mm{padding:4px 0 24px}',
    '.mpp-mm-top{display:flex;align-items:center;gap:10px;padding:8px 0 10px}',
    '.mpp-mm-top b{font:800 17px var(--font-display,var(--font-body));color:var(--navy,#14234A)}body.dark .mpp-mm-top b{color:#fff}',
    '.mpp-mm-back{display:inline-flex;align-items:center;gap:4px;height:34px;padding:0 12px 0 8px;border:0;border-radius:99px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 13px var(--font-body);cursor:pointer}',
    'body.dark .mpp-mm-back{background:rgba(255,255,255,.08);color:#fff;box-shadow:0 0 0 1.5px rgba(255,255,255,.18)}',
    '#mppMementoBody .mm-hero{border-radius:22px;overflow:hidden}'
  ].join('');
  document.head.appendChild(st);
})();
