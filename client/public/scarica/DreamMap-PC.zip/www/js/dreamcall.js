/* dreamcall.js - la chiamata dei sogni: impostazioni, anteprima, e il video di chi risponde.

   La telefonata vera e propria la fa il servizio (DreamCall.java + DreamCallOverlay.java),
   perché deve poter comparire sopra qualunque app. Qui c'è tutto il resto: cosa la fa partire,
   con quale immagine, e cosa si vede dopo aver risposto.

   La regola che tiene in piedi la funzione è una sola: deve suonare di rado. Una telefonata
   che arriva quando non serve viene spenta il secondo giorno, e allora non suona mai più. */

const DC = { cfg: null, state: null, ytReady: false };
const DC_DEF = {
  on: false, title: 'I tuoi sogni', sub: 'ti stanno chiamando', label: 'Scorri per rispondere',
  images: [], shuffle: true, video: '', videoName: '', videos: [], playlist: '',
  /* 0.9.306: come si risponde. 'scorri' = la barra da far scorrere; 'pulsanti' = Rispondi (verde) e Rifiuta (rosso),
     come il pannello della chiamata sopra all'oblo' del Full Focus. Lo legge anche DreamCallOverlay.java. */
  risposta: 'scorri',
  marathon: true, marathonMin: 45, ceiling: true, pact: true, oldRun: true, oldRunN: 3, behind: false, behindN: 3, rimandata: true, rimandataN: 3, sforo: true, emergenza: true,
  drift: true, driftDaysNeed: 3, late: false, lateMin: 90, appuntamento: true,
  maxPerDay: 1, quietFrom: 1410, quietTo: 420, distr: [], driftDays: 0
};

/* L'appuntamento con te stesso ha un interruttore anche nelle impostazioni del calendario
   (fl_cal_chiamata, '1' o '0'): e' lo stesso interruttore, e quello scritto per ultimo vince. */
function dcCfg(){
  const o = Object.assign({}, DC_DEF, DC.cfg || {});
  try{ const k = localStorage.getItem('fl_cal_chiamata'); if (k === '0' || k === '1') o.appuntamento = k === '1'; }catch(_){ }
  /* 0.9.306: il formato scelto a mano (9:16 / 16:9) non esiste piu': ogni video tiene il suo (dcRapporto) */
  delete o.formati;
  if (o.risposta !== 'pulsanti') o.risposta = 'scorri';
  return o;
}

async function dcLoad(){
  if (!NATIVE || !NATIVE.getDreamCall) { DC.cfg = Object.assign({}, DC_DEF); return DC.cfg; }
  try{
    const r = await NATIVE.getDreamCall();
    DC.cfg = Object.assign({}, DC_DEF, (r && r.config) || {});
    DC.state = (r && r.state) || {};
    /* 0.9.306: via i formati scelti a mano dalla configurazione salvata nel telefono. I video scelti restano tutti:
       si riscrive la stessa configurazione, solo senza "formati". */
    /* 0.9.307: il telefono mostra il motivo della chiamata da solo (DreamCallOverlay.java): gli servono i testi delle
       condizioni, gli stessi di Personalizza. Si mandano una volta, e di nuovo se cambiano. */
    const motivi = dcMotiviNativi();
    const motiviNuovi = JSON.stringify((r && r.config && r.config.motivi) || null) !== JSON.stringify(motivi);
    if (r && r.config && Object.keys(r.config).length && (('formati' in r.config) || motiviNuovi) && NATIVE.setDreamCall){
      delete DC.cfg.formati;
      DC.cfg.motivi = motivi;
      try{ await NATIVE.setDreamCall({ config: DC.cfg }); }catch(_){ }
    }
  }catch(_){ DC.cfg = Object.assign({}, DC_DEF); }
  return DC.cfg;
}

/* Le app segnate come distrazione e i giorni di deriva li sa la pagina, non il servizio:
   glieli passiamo insieme al resto della configurazione, a ogni salvataggio. */
async function dcDriftDays(){
  let goal = 0;
  try{ goal = +(localStorage.getItem('fl_goal_min') || 0) || 0; }catch(_){ }
  if (!goal || typeof scReport !== 'function') return 0;
  let n = 0;
  for (let i = 1; i <= 10; i++){
    let r = null;
    try{ r = await scReport(i); }catch(_){ r = null; }
    if (!r || !r.granted || !r.screenMs) break;
    if (r.screenMs / 60000 > goal) n++; else break;
  }
  return n;
}
async function dcSave(patch){
  if (patch && 'appuntamento' in patch){
    try{ localStorage.setItem('fl_cal_chiamata', patch.appuntamento ? '1' : '0'); }catch(_){ }
    setTimeout(dcaSincronizza, 0);
  }
  DC.cfg = Object.assign(dcCfg(), patch || {});
  delete DC.cfg.formati;
  try{
    const cats = (typeof insCats === 'function') ? insCats() : {};
    const base = (typeof insCats === 'function') ? insCats(null) : cats;
    DC.cfg.distr = Object.keys(base).filter(k => base[k] === 'distr');
    /* le fasce orarie: il servizio le guarda all'ora in cui suona */
    const f = (typeof insFasce === 'function') ? insFasce() : {};
    DC.cfg.fasce = {};
    Object.keys(f).forEach(function(p){ DC.cfg.fasce[p] = (f[p] || []).map(function(x){ return [insHM(x.da), insHM(x.a), x.cat]; }); });
  }catch(_){ DC.cfg.distr = []; }
  DC.cfg.driftDays = await dcDriftDays();
  DC.cfg.motivi = dcMotiviNativi();
  if (NATIVE && NATIVE.setDreamCall){
    try{ await NATIVE.setDreamCall({ config: DC.cfg }); }catch(_){ toast('Non salvata nel telefono'); }
  }
  dcPaint();
}

/* ---------- le impostazioni ----------

   Meno manopole, e ognuna con una frase intera accanto. Le condizioni restano cinque perché
   descrivono momenti diversi, ma i numeri da scegliere sono due soli: dopo quanti minuti di
   fila, e dopo quanti giorni di deriva. Tutto il resto lo decide l'app. */
const DC_ICO_APP = '<svg class="dc-ico" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3" fill="none" stroke="#0075E3" stroke-width="2"/><path d="M3.5 10h17M8 3v4M16 3v4" fill="none" stroke="#0075E3" stroke-width="2" stroke-linecap="round"/><path d="M9 15l2 2 4-4" fill="none" stroke="#0075E3" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const DC_TRIGGERS = [
  { k: 'appuntamento', ico: DC_ICO_APP, t: 'Appuntamento con te stesso',
    s: 'Ti chiama all\'inizio degli eventi che metti nel calendario: o ti presenti, o il punto va al vecchio te.',
    nota: 'Rispondi e fai partire il Full Focus entro 15 minuti dall\'inizio: due punti al nuovo te. Se dici "Non ora", o non rispondi, il punto va al vecchio te. Suona anche nelle fasce di silenzio, perché l\'ora l\'hai scelta tu. Durante una telefonata aspetta che finisca.' },
  { k: 'marathon', ico: '🌀', t: 'Quando ti perdi dentro a un\'app',
    s: 'Sei nella stessa app che hai segnato come distrazione da troppo tempo di fila. Non è una scelta: è inerzia.',
    num: 'marathonMin', opts: [[30, 'dopo 30 minuti'], [45, 'dopo 45 minuti'], [60, 'dopo un\'ora'], [90, 'dopo un\'ora e mezza']] },
  { k: 'ceiling',  ico: '🚧', t: 'Quando sfondi il tuo tetto',
    s: 'Il tempo di schermo di oggi ha superato di una volta e mezza l\'obiettivo giornaliero che ti sei dato: non di poco, di molto.' },
  { k: 'oldRun', ico: '😈', t: 'Quando il vecchio te segna di fila',
    s: 'Nella partita fra il vecchio e il nuovo te, il vecchio te ha segnato più punti di fila senza che tu ne segnassi uno.',
    num: 'oldRunN', opts: [[2, 'dopo 2 punti di fila'], [3, 'dopo 3 punti di fila'], [5, 'dopo 5 punti di fila']] },
  { k: 'behind', ico: '📊', t: 'Quando vai in svantaggio',
    s: 'Nella partita il nuovo te è sotto di troppi punti rispetto al vecchio te.',
    num: 'behindN', opts: [[2, 'sotto di 2'], [3, 'sotto di 3'], [5, 'sotto di 5']] },
  { k: 'rimandata', ico: '⏭️', t: 'Quando rimandi la priorità',
    s: 'La priorità del giorno è rimasta senza spunta per più giorni di fila: la stai rimandando.',
    num: 'rimandataN', opts: [[2, 'dopo 2 giorni'], [3, 'dopo 3 giorni'], [5, 'dopo 5 giorni']] },
  { k: 'sforo', ico: '⏳', t: 'Quando sfori di molto il tempo previsto',
    s: 'Una cosa stimata in un\'ora te ne ha prese tre. Non scatta se alla fine hai votato che il tempo previsto era davvero troppo poco.' },
  { k: 'emergenza', ico: '🌅', t: 'L\'emergenza: chiama il tuo Io futuro',
    s: 'Solo con Premium. Giorni di inattività sulla tua unica cosa, o un ricalcolo che allontana l\'arrivo di molto: al posto della chiamata scriptata ti chiama il tuo Io futuro, con la sua voce.',
    premium: true },
  { k: 'pact',     ico: '🔓', t: 'Quando rompi il patto',
    s: 'Hai messo in pausa il piano e sei andato dritto dove avevi detto di non andare.' },
  { k: 'drift',    ico: '📉', t: 'Quando stai andando alla deriva',
    s: 'Più giorni di fila sopra il tuo obiettivo. Non è una serata storta: è una traiettoria.',
    num: 'driftDaysNeed', opts: [[2, 'dopo 2 giorni'], [3, 'dopo 3 giorni'], [5, 'dopo 5 giorni'], [7, 'dopo una settimana']] },
  { k: 'late',     ico: '🌙', t: 'Quando fai troppo tardi',
    s: 'Sei ancora davanti allo schermo oltre l\'ora che ti sei dato per andare a letto.', time: 'lateMin' }
];

/* I testi delle condizioni per la schermata "Motivo della chiamata" del telefono. L'icona dell'appuntamento e' un
   disegno (svg) che il telefono non sa leggere: li' diventa il calendario. */
function dcMotiviNativi(){
  const out = {};
  DC_TRIGGERS.forEach(function(t){ out[t.k] = { ico: /^</.test(t.ico) ? '\ud83d\udcc5' : t.ico, t: t.t, s: t.s }; });
  return out;
}
function dcMinLabel(m){ const h = Math.floor(m / 60), r = m % 60; return String(h).padStart(2, '0') + ':' + String(r).padStart(2, '0'); }
function dcSw(on, action){
  return '<button type="button" class="switch' + (on ? ' on' : '') + '" onclick="' + action + '" aria-pressed="' + (on ? 'true' : 'false') + '"></button>';
}

function dcPaint(){
  const host = document.getElementById('dcBlock');
  if (!host) return;
  const c = dcCfg();
  const st = DC.state || {};
  host.innerHTML =
      '<div class="dc-head"><div><b>📞 La chiamata dei sogni</b>'
    +   '<small>Quando stai andando dalla parte opposta a quella che hai scelto, il telefono squilla davvero: schermo intero, la tua suoneria, e una barra da far scorrere per rispondere.</small></div>'
    +   dcSw(c.on, 'dcSave({on:' + (c.on ? 'false' : 'true') + '})') + '</div>'
    + (c.on ? dcBody(c, c.images || [], st) : dcSoloAppuntamento(c));
  if (c.on) setTimeout(dcFormatiScopri, 0);
}
/* Con la chiamata dei sogni spenta resta l'appuntamento: lo accendi tu, evento per evento,
   nel calendario. Qui si vede e si puo' spegnere. */
function dcSoloAppuntamento(c){
  const t = DC_TRIGGERS.filter(function(x){ return x.k === 'appuntamento'; })[0];
  if (!t) return '';
  return '<div class="dc-sec"><h4>Resta attiva anche così</h4>'
    + '<p>Questa chiamata la scegli tu nel calendario, evento per evento. Per questo suona anche con l’interruttore qui sopra spento.</p>'
    + dcTrigger(t, c) + '</div>';
}
function dcBody(c, imgs, st){
  const pulsanti = c.risposta === 'pulsanti';
  return '<div class="dc-sec"><h4>Che aspetto ha</h4>'
    +   '<p>' + (pulsanti ? 'Due righe' : 'Tre righe') + ' e un\'immagine. Scrivi quello che vuoi leggere nel momento in cui ti fermi.</p>'
    /* 0.9.306: come si risponde. Le due scelte si vedono gia' disegnate: la barra, o i due pulsanti verde e rosso */
    +   '<div class="dc-line dc-risp-l"><span>Come rispondi alla chiamata</span>'
    +     '<div class="dc-risp" role="radiogroup" aria-label="Come rispondi alla chiamata">'
    +       '<button type="button" role="radio" aria-checked="' + !pulsanti + '" class="dc-risp-o' + (pulsanti ? '' : ' on') + '" onclick="dcSave({risposta:\'scorri\'})">'
    +         '<i class="dc-risp-bar" aria-hidden="true"><em>📞</em></i><b>Scorri per rispondere</b></button>'
    +       '<button type="button" role="radio" aria-checked="' + pulsanti + '" class="dc-risp-o' + (pulsanti ? ' on' : '') + '" onclick="dcSave({risposta:\'pulsanti\'})">'
    +         '<i class="dc-risp-due" aria-hidden="true"><em class="si">📞</em><em class="no">📞</em></i><b>Rispondi o rifiuta</b></button>'
    +     '</div></div>'
    +   '<div class="dc-fields">'
    +     '<input class="fin" maxlength="30" value="' + esc(c.title) + '" placeholder="I tuoi sogni" onchange="dcSave({title:this.value})">'
    +     '<input class="fin" maxlength="40" value="' + esc(c.sub) + '" placeholder="ti stanno chiamando" onchange="dcSave({sub:this.value})">'
    +     (pulsanti ? '' : '<input class="fin" maxlength="30" value="' + esc(c.label) + '" placeholder="Scorri per rispondere" onchange="dcSave({label:this.value})">')
    +   '</div>'
    +   '<div class="dc-imgs">' + (imgs.length
          ? imgs.map((u, i) => '<div class="dc-img" style="background-image:url(\'' + dcSrc(u) + '\')"><button type="button" onclick="dcRemoveImage(' + i + ')" aria-label="Togli">✕</button></div>').join('')
          : '') + '</div>'
    +   '<p class="dc-note">' + (imgs.length
          ? (imgs.length === 1 ? 'Una immagine scelta.' : 'Hai scelto ' + imgs.length + ' immagini: a ogni chiamata ne compare una a caso.')
          : 'Senza immagini la chiamata arriva su fondo scuro.') + '</p>'
    +   '<div class="ps-row"><button type="button" class="ghostmini" onclick="dcPickImages(true)">' + (imgs.length ? 'Aggiungi immagini' : 'Scegli dal telefono') + '</button>'
    +     '<button type="button" class="ghostmini" onclick="dcPreview()">Guarda come appare</button></div>'
    + '</div>'

    + '<div class="dc-sec"><h4>Cosa vedi dopo aver risposto</h4>'
    +   '<p>I tuoi video e la tua playlist di YouTube: a ogni risposta ne parte uno, a turno, e nessuno si ripete finch\u00e9 non li hai visti tutti.</p>'
    +   (dcVideoLista(c).length
          ? '<div class="dc-vids">' + dcVideoLista(c).map(function(u, i){
              const rotto = !!dcRotti()[u];
              const nome = u === DC_VIDEO_APP ? 'Now choose (video dell\u2019app)' : (String(u).replace(/^.*[\/:]/, '').slice(0, 28) || 'video ' + (i + 1));
              return '<div class="dc-vid' + (rotto ? ' rotto' : '') + '"><span>' + (rotto ? '\u26a0\ufe0f' : '\ud83c\udfac') + '</span><b>' + esc(nome)
                + (rotto ? '<small>Non si apre pi\u00f9: toglilo e sceglilo di nuovo</small>' : '') + '</b>'
                + '<button type="button" class="ghostmini" onclick="dcRemoveVideo(' + i + ')">Togli</button></div>';
            }).join('') + '</div>'
          : '')
    +   '<p class="dc-note">' + dcNotaScelta(c) + '</p>'
    +   '<div class="ps-row"><button type="button" class="ghostmini" onclick="dcPickVideo()">' + (dcVideoLista(c).length ? 'Aggiungi un video' : 'Scegli un video') + '</button>'
    +     (dcVideoLista(c).indexOf(DC_VIDEO_APP) < 0 ? '<button type="button" class="ghostmini" onclick="dcAggiungiApp()">\ud83c\udfac Now choose</button>' : '') + '</div>'
    +   '<input class="fin" value="' + esc(c.playlist) + '" placeholder="Incolla qui una playlist di YouTube" inputmode="url" onchange="dcSave({playlist:this.value.trim()})">'
    +   '<div class="ps-row"><button type="button" class="ghostmini" onclick="dcAnswerOpen(true)">Prova cosa vedo dopo</button></div>'
    + '</div>'

    + '<div class="dc-sec"><h4>Quando deve squillare</h4>'
    +   '<p>Tieni accesi i momenti che per te contano davvero: più ne accendi, più spesso la chiamata arriva, e una chiamata che arriva troppo spesso si finisce per ignorarla.</p>'
    +   DC_TRIGGERS.map(t => dcTrigger(t, c)).join('')
    + '</div>'

    + '<div class="dc-sec"><h4>Quando deve tacere</h4>'
    +   '<p>Non squilla mai a schermo spento, sul blocco schermo, durante una telefonata, né a meno di quattro ore dall\'ultima. Le fasce di silenzio valgono per tutta l\'app.</p>'
    +   '<div class="dc-line"><span>Quante volte al giorno può squillare</span>'
    +     '<div class="sev-chips">' + [[1, 'una sola'], [2, 'due'], [3, 'tre']].map(n => '<button type="button" class="sev-chip' + (c.maxPerDay === n[0] ? ' on' : '') + '" onclick="dcSave({maxPerDay:' + n[0] + '})">' + n[1] + '</button>').join('') + '</div></div>'
    +   ((typeof asPannelliHtml === 'function') ? asPannelliHtml() : '')
    +   '<div class="setrow sil-link" onclick="silApri()"><span>🔕</span><b>Fasce di silenzio</b><small>' + (typeof silRiassunto === 'function' ? esc(silRiassunto()) : '') + '</small><span class="chev"></span></div>'
    +   (st.lastAt ? '<p class="dc-note">Ultima chiamata: ' + new Date(st.lastAt).toLocaleString('it-IT') + '. Oggi ha squillato ' + (st.todayCount || 0) + (st.todayCount === 1 ? ' volta.' : ' volte.') + '</p>' : '')
    + '</div>';
}
/* IL PANNELLO DEL PRIMO PASSO, CONDIZIONE PER CONDIZIONE (0.9.210). Dopo una chiamata per
   «troppo tardi» proporre di prenotare il punto e partire e' fuori luogo: si sta andando a
   dormire. Ogni condizione ha la sua spunta; di serie il pannello c'e' per tutte tranne quella. */
const DC_PANN_KEY = 'fl_dc_pannello';
function dcPannelli(){ let v = null; try{ v = JSON.parse(localStorage.getItem(DC_PANN_KEY) || 'null'); }catch(_){ } return v || {}; }
function dcPannelloOn(k){ const v = dcPannelli(); if (k in v) return !!v[k]; return k !== 'late' && k !== 'appuntamento'; }
function dcPannelloSet(k){ const v = dcPannelli(); v[k] = !dcPannelloOn(k); try{ localStorage.setItem(DC_PANN_KEY, JSON.stringify(v)); }catch(_){ } dcPaint(); }
function dcUltimoMotivoSegna(k, riga){ try{ localStorage.setItem('fl_dc_ultimo', JSON.stringify({ k: k, riga: String(riga || '').slice(0, 200), at: Date.now() })); }catch(_){ } }
async function dcUltimoMotivo(){
  try{ const v = JSON.parse(localStorage.getItem('fl_dc_ultimo') || 'null'); if (v && v.k && Date.now() - v.at < 15 * 60000) return v.k; }catch(_){ }
  try{ await dcLoad(); }catch(_){ }
  return (DC.state && DC.state.lastReason) || '';
}
function dcTrigger(t, c){
  const on = !!c[t.k];
  return '<div class="dc-trig' + (on ? ' on' : '') + '">'
    + '<div class="dc-head"><div><b>' + t.ico + ' ' + t.t + '</b><small>' + t.s + '</small></div>'
    +   dcSw(on, 'dcSave({' + t.k + ':' + (on ? 'false' : 'true') + '})') + '</div>'
    + (on && t.num ? '<div class="sev-chips">' + t.opts.map(o => '<button type="button" class="sev-chip' + (c[t.num] === o[0] ? ' on' : '') + '" onclick="dcSave({' + t.num + ':' + o[0] + '})">' + o[1] + '</button>').join('') + '</div>' : '')
    + (on && t.time ? '<div class="ps-row"><span class="dc-lab">Oltre le</span><input class="fin dc-time" type="time" value="' + dcMinLabel(c[t.time]) + '" onchange="dcSetLate(this.value)"></div>' : '')
    + (t.premium && !(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()) ? '<p class="dc-note">🔒 Con Premium: la voce del tuo Io futuro.</p>' : '')
    + (on && t.nota ? '<p class="dc-note">' + t.nota + '</p>' : '')
    + (on && t.k !== 'emergenza' && t.k !== 'appuntamento' ? '<label class="dc-pann" onclick="event.preventDefault();dcPannelloSet(\'' + t.k + '\')"><input type="checkbox"' + (dcPannelloOn(t.k) ? ' checked' : '') + '><span>Dopo la chiamata, proponi il primo passo di oggi</span></label>' : '')
    + '</div>';
}
/* ---- LE CONDIZIONI DEL TELEFONO (0.9.208): partita, priorita', tempo, emergenza. Le valuta
   l'app (i dati stanno qui), una al giorno al massimo, mai in silenzio. Squilla con la stessa
   schermata della chiamata; l'emergenza Premium apre la chiamata con l'Io futuro. ---- */
function dcJsOggi(){ try{ const v = JSON.parse(localStorage.getItem('fl_dc_js') || '{}'); const k = new Date().toDateString(); return v.k === k ? v : { k: k, n: 0, visti: {} }; }catch(_){ return { k: new Date().toDateString(), n: 0, visti: {} }; } }
function dcJsSalva(v){ try{ localStorage.setItem('fl_dc_js', JSON.stringify(v)); }catch(_){ } }
function dcTaceOra(c){
  try{ if (typeof asSilenzioAttivo === 'function' && asSilenzioAttivo()) return true; }catch(_){ }
  const m = new Date().getHours() * 60 + new Date().getMinutes();
  const a = c.quietFrom, b = c.quietTo; if (a >= 0 && b >= 0 && (a <= b ? (m >= a && m < b) : (m >= a || m < b))) return true;
  try{ if (typeof FF !== 'undefined' && FF && FF.run) return true; }catch(_){ }
  /* 0.9.311: mai sopra a un esercizio di respirazione (758.jpg): il controllo torna al prossimo cambio di scheda */
  try{ if (typeof RS !== 'undefined' && RS && RS.timer) return true; }catch(_){ }
  return false;
}
/* 0.9.264, Andrea: la chiamata "Sei sotto 3 a 10" interrompeva l'onboarding subito dopo "Ricomincia da
   capo". Durante il primo avvio (il film, il giro del Genio) e nelle 24 ore dopo un reset il telefono
   non squilla: chi ha appena ricominciato non e' sotto di niente. */
function dcInAvvio(){
  try{
    if (localStorage.getItem('fl_onboarded') !== '1') return true;
    if (typeof GT !== 'undefined' && GT && GT.on) return true;
    if (typeof GN !== 'undefined' && GN && GN.on) return true;
    const r = +localStorage.getItem('fl_reset_ultimo') || 0;
    if (r && Date.now() - r < 86400000) return true;
  }catch(_){ }
  return false;
}
async function dcControllaJs(){
  const c = dcCfg(); if (!c.on || dcTaceOra(c) || dcInAvvio()) return;
  const oggi = dcJsOggi(); if (oggi.n >= (c.maxPerDay || 1)) return;
  const prem = !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium());
  let motivo = '', k = '';
  try{
    const st = (typeof mtState === 'function') ? mtState() : null;
    const hist = (typeof mgHist === 'function') ? mgHist() : [];
    const ev = []; hist.slice(-3).forEach(function(g){ (g.eventi || []).forEach(function(e){ if (e && !e.stornato) ev.push(e); }); });
    ev.sort(function(a, b){ return (a.at || 0) - (b.at || 0); });
    let fila = 0; for (let i = ev.length - 1; i >= 0; i--){ if (ev[i].chi === 'old') fila++; else break; }
    if (c.oldRun && fila >= (c.oldRunN || 3) && !oggi.visti.oldRun){ k = 'oldRun'; motivo = 'Il vecchio te ha segnato ' + fila + ' punti di fila. Tocca a te.'; }
    if (!k && c.behind && st && (st.old || 0) - (st.neo || 0) >= (c.behindN || 3) && !oggi.visti.behind){ k = 'behind'; motivo = 'Sei sotto ' + st.neo + ' a ' + st.old + '. La prossima palla è tua.'; }
  }catch(_){ }
  try{
    if (!k && c.rimandata && typeof stPriorita === 'function' && typeof stRigheDi === 'function'){
      let giorni = 0;
      for (let i = 1; i <= 7; i++){ const day = mtKey(Date.now() - i * 86400000); const righe = stRigheDi(day); const p = stPriorita(day, righe); if (p && !stIsDone(p, day)) giorni++; else break; }
      if (giorni >= (c.rimandataN || 3) && !oggi.visti.rimandata){ k = 'rimandata'; motivo = 'La priorità è rimasta senza spunta per ' + giorni + ' giorni di fila.'; }
    }
  }catch(_){ }
  try{
    if (!k && c.sforo && !oggi.visti.sforo){
      const h = (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).filter(function(x){ return x && x.ok && x.at > Date.now() - 86400000 && x.intent; });
      const meta = JSON.parse(localStorage.getItem('fl_notes_meta') || '{}') || {};
      const sforata = h.filter(function(x){ const key = Object.keys(meta).filter(function(q){ return q.split('|').slice(1).join('|') === x.intent; })[0]; const m = key ? meta[key] : null; return m && m.stima && (x.spentMs || x.min * 60000) > m.stima * 60000 * 2.5 && m.voto !== 'troppo pochi'; })[0];
      if (sforata){ k = 'sforo'; motivo = '"' + String(sforata.intent).slice(0, 40) + '" ha preso più del doppio del tempo previsto.'; }
    }
  }catch(_){ }
  try{
    if (!k && c.emergenza && prem && !oggi.visti.emergenza){
      let inattivi = 0; try{ const g = sdGiorniFatti(); for (let i = 1; i <= 10; i++){ if (!g[sdK(Date.now() - i * 86400000)]) inattivi++; else break; } }catch(_){ }
      let peggio = false; try{ const a = etaArrivo(); const prev = +localStorage.getItem('fl_eta_prev_at') || 0; if (a && isFinite(a.at)){ if (prev && a.at - prev > 14 * 86400000) peggio = true; localStorage.setItem('fl_eta_prev_at', String(a.at)); } }catch(_){ }
      if (inattivi >= 3 || peggio){ k = 'emergenza'; motivo = inattivi >= 3 ? inattivi + ' giorni senza una tappa.' : 'L’arrivo si è allontanato di più di due settimane.'; }
    }
  }catch(_){ }
  if (!k) return;
  oggi.n++; oggi.visti[k] = Date.now(); dcJsSalva(oggi);
  dcUltimoMotivoSegna(k, motivo);
  if (k === 'emergenza' && typeof icChiama === 'function'){ try{ toast('📞 Il tuo Io futuro ti chiama: ' + motivo); if (typeof icVideoApri === 'function') icVideoApri(); else icChiama(); return; }catch(_){ } }
  /* UNA CHIAMATA VERA, con il "Non ora" e il suo esito (Rientra in rotta). L'anteprima resta
     solo per le versioni del telefono che non sanno ancora farla. */
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.ringDreamCall){ try{ const r = await NATIVE.ringDreamCall({ title: c.title, sub: c.sub, label: c.label, line: motivo, motivo: k, titolo: motivo }); if (r && r.shown) return; }catch(_){ } }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.previewDreamCall){ try{ await NATIVE.previewDreamCall({ title: c.title, sub: c.sub, label: c.label, line: motivo }); return; }catch(_){ } }
  toast('📞 ' + motivo);
}
document.addEventListener('fl:tab', function(){ setTimeout(function(){ dcControllaJs().catch(function(){ }); }, 2500); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(function(){ dcControllaJs().catch(function(){ }); }, 2500); });
function dcTimeToMin(v){ const m = /^(\d{2}):(\d{2})$/.exec(v || ''); return m ? (+m[1]) * 60 + (+m[2]) : -1; }
function dcSetQuiet(which, v){ const n = dcTimeToMin(v); if (n < 0) return; dcSave(which === 'from' ? { quietFrom: n } : { quietTo: n }); }
function dcSetLate(v){ const n = dcTimeToMin(v); if (n < 0) return; dcSave({ lateMin: n }); }

/* Un file dell'app non si può mettere in un src così com'è: Capacitor lo serve da un indirizzo suo. */
function dcSrc(u){
  if (!u) return '';
  /* un video dell'app (video/…) e' gia' un indirizzo della pagina */
  if (/^video\//.test(u)) return u;
  try{ if (window.Capacitor && Capacitor.convertFileSrc) return Capacitor.convertFileSrc(u); }catch(_){ }
  return u;
}
async function dcPickImages(aggiungi){
  if (!NATIVE || !NATIVE.pickImages){ toast('Disponibile solo sul telefono'); return; }
  try{
    const r = await NATIVE.pickImages();
    const list = (r && r.images) || [];
    if (!list.length) return;
    /* «Aggiungi» aggiunge: prima ogni scelta cancellava le precedenti, e per avere sei
       immagini bisognava sceglierle tutte in una volta. */
    const base = aggiungi ? (dcCfg().images || []).slice() : [];
    list.forEach(function(u){ if (base.indexOf(u) < 0) base.push(u); });
    dcSave({ images: base.slice(0, 8) });
  }catch(_){ }
}
/* Il filmato «Now choose»: non e' piu' il trailer di serie, si sceglie qui se lo si vuole. */
const DC_VIDEO_APP = 'video/now-choose.mp4';
function dcAggiungiApp(){
  const l = dcVideoLista(dcCfg());
  if (l.indexOf(DC_VIDEO_APP) < 0) l.push(DC_VIDEO_APP);
  dcSave({ videos: l.slice(0, 8), video: '', videoName: '' });
}
function dcNotaScelta(c){
  const v = dcVideoLista(c).length, pl = !!dcPlaylistId(c.playlist);
  const tot = v + (pl ? 1 : 0);
  if (!tot) return 'Niente di scelto.';
  const pezzi = (v ? v + (v === 1 ? ' video' : ' video') : '') + (v && pl ? ' e ' : '') + (pl ? 'una playlist' : '');
  return tot === 1 ? 'Hai scelto ' + pezzi + ': parte sempre quello.' : 'Hai scelto ' + pezzi + ': a turno, uno per risposta.';
}
function dcRemoveVideo(i){
  const l = dcVideoLista(dcCfg());
  l.splice(i, 1);
  dcSave({ videos: l, video: '', videoName: '' });
}
function dcRemoveImage(i){
  const c = dcCfg();
  const imgs = (c.images || []).slice();
  imgs.splice(i, 1);
  dcSave({ images: imgs });
}
async function dcPickVideo(){
  if (!NATIVE || !NATIVE.pickMedia){ toast('Disponibile solo sul telefono'); return; }
  try{
    const r = await NATIVE.pickMedia({ kind: 'video' });
    const uri = r && (r.uri || r.value);
    if (!uri) return;
    const l = dcVideoLista(dcCfg());
    if (l.indexOf(uri) < 0) l.push(uri);
    dcSave({ videos: l.slice(0, 8), video: '', videoName: '' });
  }catch(_){ }
}
async function dcPreview(){
  const c = dcCfg();
  /* 0.9.306: dove la finestra del telefono non c'e' (computer, browser) l'anteprima la disegna la pagina, uguale */
  if (!NATIVE || !NATIVE.previewDreamCall){ dcPreviewWeb(c); return; }
  try{
    const r = await NATIVE.previewDreamCall({ title: c.title, sub: c.sub, label: c.label, risposta: c.risposta, line: 'Anteprima · rispondi per vedere il seguito' });
    if (!r || !r.shown) dcPreviewWeb(c);
  }catch(_){ dcPreviewWeb(c); }
}

/* ---------------------------------------------------------------------------------------
   L'ANTEPRIMA NELLA PAGINA (0.9.306)

   La stessa schermata di DreamCallOverlay.java: immagine scurita, "I tuoi sogni" / "ti stanno chiamando", e in basso o
   la barra da far scorrere (fino in fondo = risposto) o i due pulsanti, verde Rispondi e rosso Rifiuta, come nel
   pannello della chiamata sopra all'oblo' del Full Focus (start.js, dcoOverlayHtml). Rispondi fa vedere il seguito
   (dcAnswerOpen in anteprima), Rifiuta e "Chiudi l'anteprima" chiudono.
   --------------------------------------------------------------------------------------- */
/* 0.9.318, Andrea: "la schermata deve essere completamente scura e si legge solo il testo. Solo dopo che si e' risposto si illumina
   leggermente". Prima il velo era .8 e trascinando spariva del tutto: il titolo bianco finiva sull'immagine chiara e non si leggeva. */
const DC_BUIO_RISPOSTA = .62;
function dcPreviewWeb(c){
  c = c || dcCfg();
  dcPreviewChiudi();
  const imgs = c.images || [];
  const sfondo = imgs.length ? ' style="background-image:url(\'' + dcSrc(imgs[Math.floor(Math.random() * imgs.length)]) + '\')"' : '';
  const pulsanti = c.risposta === 'pulsanti';
  const el = document.createElement('div');
  el.id = 'dcPrev';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-label', 'Anteprima della chiamata dei sogni');
  el.innerHTML = '<i class="dcp-img"' + sfondo + '></i><i class="dcp-buio"></i>'
    + '<div class="dcp-col">'
    +   '<b class="dcp-t">' + esc(c.title || 'I tuoi sogni') + '</b>'
    +   '<span class="dcp-s">' + esc(c.sub || 'ti stanno chiamando') + '</span>'
    +   '<span class="dcp-vuoto"></span>'
    +   (pulsanti
          ? '<div class="dcp-tasti">'
          +   '<button type="button" class="dcp-si" onclick="dcPreviewRispondi()"><i>📞</i><small>Rispondi</small></button>'
          +   '<button type="button" class="dcp-no" data-chiudi onclick="dcPreviewChiudi()"><i>📞</i><small>Rifiuta</small></button>'
          + '</div>'
          : '<div class="dcp-bar"><span class="dcp-lbl">' + esc(c.label || 'Scorri per rispondere') + '</span><button type="button" class="dcp-pollice" aria-label="Trascina per rispondere">📞</button></div>')
    /* con i due pulsanti, Rifiuta e' gia' l'uscita: la riga sotto servirebbe due volte */
    +   (pulsanti ? '' : '<button type="button" class="dcp-chiudi" data-chiudi onclick="dcPreviewChiudi()">Chiudi l’anteprima</button>')
    + '</div>';
  document.body.appendChild(el);
  if (!pulsanti) dcPreviewBarra(el);
}
function dcPreviewChiudi(){ const el = document.getElementById('dcPrev'); if (el) el.remove(); }
function dcPreviewRispondi(){
  const el = document.getElementById('dcPrev'), b = el && el.querySelector('.dcp-buio');
  if (b && !b.dataset.acceso){ b.dataset.acceso = '1'; b.style.transition = 'opacity .45s'; b.style.opacity = String(DC_BUIO_RISPOSTA); setTimeout(function(){ dcPreviewChiudi(); dcAnswerOpen(true); }, 460); return; }
  if (!b){ dcPreviewChiudi(); dcAnswerOpen(true); }
}
/* la barra: come nel telefono, il buio si alza mentre il pollice scorre, e arrivato in fondo hai risposto */
function dcPreviewBarra(el){
  const bar = el.querySelector('.dcp-bar'), th = el.querySelector('.dcp-pollice'), buio = el.querySelector('.dcp-buio'), lbl = el.querySelector('.dcp-lbl');
  if (!bar || !th) return;
  let x0 = 0, x = 0, giu = false;
  const max = function(){ return bar.clientWidth - th.offsetWidth - 4; };
  const muovi = function(nx){
    x = Math.max(0, Math.min(max(), nx));
    const pr = max() > 0 ? x / max() : 0;
    th.style.transform = 'translateX(' + x + 'px)';
    if (buio) buio.style.opacity = String(1 - (1 - DC_BUIO_RISPOSTA) * pr);
    if (lbl) lbl.style.opacity = pr > 0.4 ? '0' : '1';
    if (x >= max() - 6){ giu = false; dcPreviewRispondi(); }
  };
  th.addEventListener('pointerdown', function(e){ giu = true; x0 = e.clientX - x; try{ th.setPointerCapture(e.pointerId); }catch(_){ } });
  th.addEventListener('pointermove', function(e){ if (giu) muovi(e.clientX - x0); });
  const su = function(){
    if (!giu) return; giu = false;
    x = 0; th.style.transition = 'transform .25s'; th.style.transform = 'translateX(0)';
    if (buio){ buio.style.transition = 'opacity .25s'; buio.style.opacity = '1'; }
    if (lbl) lbl.style.opacity = '1';
    setTimeout(function(){ th.style.transition = ''; if (buio) buio.style.transition = ''; }, 260);
  };
  th.addEventListener('pointerup', su);
  th.addEventListener('pointercancel', su);
}

/* ---------- chi ha risposto ---------- */
/** Tutti i video scelti: la lista nuova piu' quello singolo di prima, se c'era. */
function dcVideoLista(c){
  const out = (c.videos || []).slice();
  if (c.video && out.indexOf(c.video) < 0) out.push(c.video);
  return out;
}
/**
 * PERCHE' GIRAVANO SEMPRE GLI STESSI DUE.
 *
 * <p>Due difetti insieme. Con una playlist di YouTube incollata, la playlist vinceva sempre e i
 * video scelti non partivano mai — mentre la pagina diceva «a ogni risposta ne parte uno a
 * caso». E un video scelto con una versione vecchia dell'app non era stato copiato nel
 * telefono: al primo riavvio non si apriva piu', la risposta si chiudeva in silenzio, e di tre
 * video se ne vedevano due.</p>
 *
 * <p>Adesso tutto quello che hai scelto — ogni video e la playlist — sta in un mazzo che si
 * mescola: a ogni risposta se ne pesca uno, e finche' il mazzo non e' finito nessuno si
 * ripete. Un video che non si apre si salta, si segna, e nella pagina lo vedi.</p>
 */
const DC_MAZZO_KEY = 'fl_dc_mazzo';
const DC_ROTTI_KEY = 'fl_dc_rotti';
function dcCandidati(c){
  const out = dcVideoLista(c).slice();
  const pl = dcPlaylistId(c.playlist);
  if (pl) out.push('yt:' + pl);
  return out;
}
function dcRotti(){
  let r = {}; try{ r = JSON.parse(localStorage.getItem(DC_ROTTI_KEY) || '{}') || {}; }catch(_){ r = {}; }
  /* 0.9.307: il video ora lo apre il telefono, e i video guasti li segna lui (state.rotti) */
  try{ const n = (DC.state && DC.state.rotti) || {}; Object.keys(n).forEach(function(u){ if (!(u in r)) r[u] = n[u]; }); }catch(_){ }
  return r;
}
function dcSegnaRotto(u, rotto){
  const r = dcRotti();
  if (rotto) r[u] = Date.now(); else delete r[u];
  try{ localStorage.setItem(DC_ROTTI_KEY, JSON.stringify(r)); }catch(_){ }
}
function dcVideoScelto(c){
  const tutti = dcCandidati(c);
  if (!tutti.length) return '';
  const online = navigator.onLine !== false;
  const validi = tutti.filter(function(u){ return online || u.indexOf('yt:') !== 0; });
  if (!validi.length) return '';
  let mazzo = [];
  try{ mazzo = JSON.parse(localStorage.getItem(DC_MAZZO_KEY) || '[]') || []; }catch(_){ mazzo = []; }
  mazzo = mazzo.filter(function(u){ return validi.indexOf(u) >= 0; });
  if (!mazzo.length){
    mazzo = validi.slice();
    for (let i = mazzo.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); const t = mazzo[i]; mazzo[i] = mazzo[j]; mazzo[j] = t; }
    /* il primo del mazzo nuovo non e' l'ultimo visto: niente due volte di fila a cavallo */
    let ultimo = ''; try{ ultimo = localStorage.getItem(DC_MAZZO_KEY + '_ultimo') || ''; }catch(_){ }
    if (mazzo.length > 1 && mazzo[0] === ultimo) mazzo.push(mazzo.shift());
  }
  const u = mazzo.shift();
  try{ localStorage.setItem(DC_MAZZO_KEY, JSON.stringify(mazzo)); localStorage.setItem(DC_MAZZO_KEY + '_ultimo', u); }catch(_){ }
  return u;
}
function dcPlaylistId(url){
  const m = /[?&]list=([A-Za-z0-9_-]+)/.exec(url || '');
  return m ? m[1] : '';
}
async function dcAnswerOpen(preview){
  /* 0.9.273, Andrea: "se rispondo mentre sto usando l'app il video non parte subito, parte dopo, scollegato".
     Due cause. (1) La risposta arriva alla pagina per DUE strade: l'avviso diretto (dreamAnswer) e il segno lasciato
     ad Android per chi apre l'app da chiusa. Con l'app gia' davanti l'avviso apriva il video, ma il segno restava
     li' e al primo rientro nell'app (visibilitychange) il video ripartiva una seconda volta, minuti dopo. Ora chi
     apre il video consuma anche il segno, e una seconda apertura nel giro di due minuti non si fa.
     (2) Il video stava sotto a quello che avevi aperto (fogli, note, il Genio): ora sta sopra a tutto (css sotto). */
  if (!preview){
    if (DC.apertoAt && Date.now() - DC.apertoAt < 120000) return;
    DC.apertoAt = Date.now();
    try{ if (NATIVE && NATIVE.consumeDreamAnswer) NATIVE.consumeDreamAnswer(); }catch(_){ }
  }
  /* l'appuntamento con te stesso non apre il video: apre la scheda per cominciare */
  if (!preview){ try{ if (await dcaDopoRisposta()) return; }catch(_){ } }
  /* A TELEFONO FREDDO la configurazione non e' ancora stata letta: senza questa riga il video
     scelto non partiva mai, e compariva l'invito a sceglierne uno.
     0.9.307: dopo una risposta vera si rilegge sempre, perche' lo stato dice fin dove e' arrivato il telefono. */
  if (!DC.cfg || !preview) await dcLoad();
  const c = dcCfg();
  const n = preview ? null : dcNativoFatto();
  /* la stessa risposta arrivata di nuovo (il segno di Android letto al rientro nell'app, anche minuti dopo): gia' fatta */
  if (n && n.gia) return;
  /* 0.9.307: motivo e video li ha gia' mostrati la finestra della chiamata (DreamCallOverlay.java): qui solo il seguito */
  if (n && n.fase === 'fine'){ DC.ultimaPreview = false; dcDopoVideo(false); return; }
  const el = document.getElementById('dcVideo');
  if (!el) return;
  el.hidden = false;
  document.body.classList.add('dc-on');
  DC.ultimaPreview = !!preview;
  /* il motivo l'ha gia' mostrato il telefono: dritti al video (la playlist di YouTube pescata dal suo mazzo) */
  if (n && n.fase === 'motivo'){ dcProietta(el, c, false, dcCandidati(c).length, n.u || ''); return; }
  /* 0.9.305: prima il motivo della chiamata, poi il video (dcMotivoMostra qui sotto) */
  dcMotivoMostra(el, c, preview);
}
/* Fin dove e' arrivata la finestra della chiamata (DreamCall.nativo): vale una volta sola, e solo se e' di adesso.
   Se l'ultima risposta l'ha gia' chiusa il telefono e la pagina ha gia' fatto il seguito, torna { gia: true }: il segno
   "ha risposto" che Android lascia all'app puo' arrivare di nuovo al rientro, e non deve riaprire il motivo. */
function dcNativoFatto(){
  const n = DC.state && DC.state.nativo;
  if (!n || !n.at || !n.fase) return null;
  let visto = 0; try{ visto = +localStorage.getItem('fl_dc_nativo_at') || 0; }catch(_){ }
  const rispostaDopo = DC.state && DC.state.answeredAt && DC.state.answeredAt > n.at;
  if (visto === +n.at) return (!rispostaDopo && Date.now() - n.at < 60 * 60000) ? { gia: true } : null;
  if (Date.now() - n.at > 3 * 60000) return null;
  try{ localStorage.setItem('fl_dc_nativo_at', String(n.at)); }catch(_){ }
  return n;
}
/* Pesca dal mazzo e proietta. Se il video non si apre si segna e si pesca il prossimo, fino a
   quanti ne hai scelti: una risposta non deve mai chiudersi in silenzio. */
function dcProietta(el, c, preview, tentativi, gia){
  const u = gia || dcVideoScelto(c);
  const skip = '<button type="button" class="dc-skip" onclick="dcAnswerClose()">' + (preview ? 'Chiudi' : 'Salta') + '</button>';
  if (!u || tentativi <= 0){
    el.innerHTML = skip + '<div class="dc-none"><b>Hai risposto.</b><p>' + (dcCandidati(c).length
      ? 'I video scelti non si aprono pi\u00f9. Sceglili di nuovo in Personalizza.'
      : 'Non hai ancora scelto cosa vedere dopo. Lo scegli in Personalizza: un video, o una playlist di YouTube.') + '</p></div>';
    return;
  }
  if (u.indexOf('yt:') === 0){
    el.innerHTML = skip + '<div id="dcYt"></div>';
    dcYouTube(u.slice(3));
    return;
  }
  el.innerHTML = skip + '<video id="dcVid" playsinline autoplay src="' + dcSrc(u) + '"></video>';
  const v = document.getElementById('dcVid');
  if (!v) return;
  /* 0.9.306: il riquadro prende la forma del video. Prima quella gia' letta (se il video si era gia' aperto), poi quella
     vera appena il file dice le sue misure. */
  dcRapportoApplica(v, dcRapporto(u));
  v.onloadedmetadata = function(){ dcRapportoApplica(v, dcRapportoVisto(u, v.videoWidth, v.videoHeight)); };
  v.onended = dcAnswerClose;
  v.onplaying = function(){ dcSegnaRotto(u, false); };
  v.onerror = function(){ dcSegnaRotto(u, true); dcProietta(el, c, preview, tentativi - 1); };
  try{ v.muted = false; v.play().catch(function(){ v.muted = true; v.play().catch(function(){}); }); }catch(_){ }
}
/* ---------------------------------------------------------------------------------------
   IL MOTIVO DELLA CHIAMATA, DOPO LA RISPOSTA (0.9.305)

   Andrea: "nessuna chiamata ti dice in anteprima di cosa si tratta". Prima il motivo ("Sei sotto 3 a 9. La prossima
   palla è tua.") stava sulla schermata che squilla, sotto "I tuoi sogni ti stanno chiamando": si leggeva il motivo e
   si decideva se rispondere, cioè la chiamata era un avviso. Adesso in arrivo c'è solo "I tuoi sogni ti stanno
   chiamando" (DreamCallOverlay.java non scrive più la riga) e il motivo compare qui, dopo aver risposto: il titolo
   "Motivo della chiamata", il fatto con i suoi numeri, e la condizione che l'ha fatta scattare. Poi parte il video,
   da solo dopo qualche secondo o subito col pulsante.

   Da dove arriva il motivo: l'esito "risposto" della coda del telefono (motivo + riga, salvato in fl_dc_risposta da
   dcaConsumaOra), oppure il segno lasciato da dcControllaJs per le chiamate che fa partire la pagina (fl_dc_ultimo),
   oppure, se c'è solo la condizione, l'ultima registrata dal servizio. Niente di inventato: se non si sa il motivo,
   si va dritti al video.
   --------------------------------------------------------------------------------------- */
const DC_MOT_MS = 5000;   /* 0.9.307: erano 8 secondi e sembrava un'attesa; uguale a MOT_MS di DreamCallOverlay.java */
function dcMotivoDati(preview){
  if (preview) return { k: 'behind', riga: 'Sei sotto 3 a 9. La prossima palla è tua.', esempio: true };
  const fresco = function(v){ return v && v.at && Date.now() - v.at < 15 * 60000; };
  let v = null;
  try{ v = JSON.parse(localStorage.getItem('fl_dc_risposta') || 'null'); }catch(_){ v = null; }
  if (fresco(v) && (v.k || v.riga)) return v;
  try{ v = JSON.parse(localStorage.getItem('fl_dc_ultimo') || 'null'); }catch(_){ v = null; }
  if (fresco(v) && v.k && v.k !== 'appuntamento') return v;
  const st = DC.state || {};
  if (st.lastReason && st.lastReason !== 'appuntamento' && st.lastAt && Date.now() - st.lastAt < 15 * 60000) return { k: st.lastReason, riga: '' };
  return null;
}
function dcMotivoMostra(el, c, preview){
  clearTimeout(DC.motT);
  const d = dcMotivoDati(preview);
  const t = d ? DC_TRIGGERS.filter(function(x){ return x.k === d.k; })[0] : null;
  const riga = d ? String(d.riga || '').trim() : '';
  const tentativi = dcCandidati(c).length;
  if (!t && !riga){ dcProietta(el, c, preview, tentativi); return; }
  const imgs = c.images || [];
  const sfondo = imgs.length ? ' style="background-image:url(\'' + dcSrc(imgs[Math.floor(Math.random() * imgs.length)]) + '\')"' : '';
  el.innerHTML = '<button type="button" class="dc-skip" onclick="dcAnswerClose()">' + (preview ? 'Chiudi' : 'Salta') + '</button>'
    + '<div class="dc-mot"><i class="dc-mot-img"' + sfondo + '></i>'
    +   '<div class="dc-mot-in">'
    +     '<h2>Motivo della chiamata</h2>'
    +     (riga ? '<p class="dc-mot-riga">' + esc(riga) + '</p>' : '')
    +     (t ? '<div class="dc-mot-cond"><span class="dc-mot-ico">' + t.ico + '</span><b>' + esc(t.t) + '</b><small>' + esc(t.s) + '</small></div>' : '')
    +     (d.esempio ? '<p class="dc-mot-nota">Questo è un esempio: nella chiamata vera qui leggi il motivo vero.</p>' : '')
    +     '<button type="button" class="dc-mot-vai" onclick="dcMotivoVai()">' + (tentativi ? 'Guarda il video' : 'Avanti') + '</button>'
    +     (tentativi ? '<div class="dc-mot-bar" aria-hidden="true"><i style="animation-duration:' + DC_MOT_MS + 'ms"></i></div><p class="dc-mot-nota">Il video parte da solo fra pochi secondi.</p>' : '')
    +   '</div>'
    + '</div>';
  DC.mot = { c: c, preview: preview, tentativi: tentativi };
  if (tentativi) DC.motT = setTimeout(dcMotivoVai, DC_MOT_MS);
}
function dcMotivoVai(){
  clearTimeout(DC.motT);
  const el = document.getElementById('dcVideo');
  const m = DC.mot; DC.mot = null;
  if (!el || el.hidden || !m) return;
  dcProietta(el, m.c, m.preview, m.tentativi);
}

/* ---------------------------------------------------------------------------------------
   LA FORMA DEL VIDEO (0.9.303, rifatta nella 0.9.306)

   0.9.303: la scena di Goblin caricata dopo la chiamata usciva tagliata, perche' #dcVideo video era sempre a tutto
   schermo con object-fit:cover. Allora si era aggiunto, per ogni video, un selettore 9:16 / 16:9.
   0.9.306, Andrea (screenshot 673): via i selettori. Un video non va costretto in un formato: il riquadro prende la
   forma del video. Si legge il rapporto vero (videoWidth / videoHeight) quando il video si apre, e nella pagina delle
   impostazioni appena lo scegli (cosi' alla risposta il riquadro e' gia' giusto). Il riquadro e' largo quanto lo
   schermo e alto quanto serve, oppure alto quanto lo schermo e largo quanto serve: il video si vede intero, sempre.
   La playlist di YouTube sta in un riquadro a tutto schermo: il lettore di YouTube mette ogni video, verticale o
   orizzontale, nella sua forma, senza tagliarlo.
   I vecchi formati scelti a mano (config.formati) si tolgono alla prima lettura (dcLoad); i video restano.
   --------------------------------------------------------------------------------------- */
const DC_FMT_VISTI = 'fl_dc_formati_visti';
function dcFormatiVisti(){ try{ return JSON.parse(localStorage.getItem(DC_FMT_VISTI) || '{}') || {}; }catch(_){ return {}; } }
/** Larghezza / altezza del video, se si sa gia' (0 se non si sa). Le righe vecchie ('16:9', '9:16') valgono come prima stima. */
function dcRapporto(u){
  const v = dcFormatiVisti()[u];
  if (typeof v === 'number' && v > 0) return v;
  if (v === '16:9') return 16 / 9;
  if (v === '9:16') return 9 / 16;
  return 0;
}
function dcRapportoVisto(u, w, h){
  if (!u || !(w > 0) || !(h > 0)) return 0;
  const r = Math.round((w / h) * 10000) / 10000;
  const v = dcFormatiVisti();
  if (v[u] !== r){ v[u] = r; try{ localStorage.setItem(DC_FMT_VISTI, JSON.stringify(v)); }catch(_){ } }
  return r;
}
/** Il riquadro del video con la forma del video: largo al massimo quanto lo schermo, alto al massimo quanto lo schermo. */
function dcRapportoApplica(v, r){
  if (!v) return;
  if (!(r > 0)){ v.classList.remove('dc-ar'); v.style.removeProperty('--dc-ar'); return; }
  v.style.setProperty('--dc-ar', String(r));
  v.classList.add('dc-ar');
}
/* nella pagina delle impostazioni: i video di cui non si sa ancora la forma si aprono solo per leggerne le misure */
const DC_FMT_IN_CORSO = {};
function dcFormatiScopri(){
  const c = dcCfg();
  dcVideoLista(c).forEach(function(u){
    if (!u || typeof dcFormatiVisti()[u] === 'number' || DC_FMT_IN_CORSO[u] || dcRotti()[u]) return;
    DC_FMT_IN_CORSO[u] = 1;
    try{
      const v = document.createElement('video');
      v.preload = 'metadata'; v.muted = true;
      v.onloadedmetadata = function(){
        dcRapportoVisto(u, v.videoWidth, v.videoHeight);
        v.removeAttribute('src'); try{ v.load(); }catch(_){ }
      };
      v.onerror = function(){ };
      v.src = dcSrc(u);
    }catch(_){ }
  });
}

function dcAnswerClose(){
  clearTimeout(DC.motT); DC.mot = null;
  const el = document.getElementById('dcVideo');
  if (el){ el.innerHTML = ''; el.hidden = true; }
  document.body.classList.remove('dc-on');
  dcDopoVideo(DC.ultimaPreview);
  DC.ultimaPreview = false;
}
/* DOPO IL FILMATO, LA SCELTA: il pannello olografico del primo passo. Solo dopo una
   chiamata vera, non dopo l'anteprima dalle impostazioni. */
function dcDopoVideo(preview){
  if (!preview && typeof pkDopoChiamata === 'function'){
    dcUltimoMotivo().then(function(k){ if (dcPannelloOn(k || '')) setTimeout(pkDopoChiamata, 350); });
  }
}
/* La playlist si incorpora con il lettore ufficiale di YouTube: nessuna chiave, nessuna
   quota, nessun file scaricato, e il conteggio delle visualizzazioni resta a chi ha caricato
   il video (scaricarlo sarebbe un'altra cosa, e non si fa).

   L'iframe si scrive a mano e parte SUBITO: se poi la libreria del lettore si carica, si
   attacca a quell'iframe (serve enablejsapi=1), fa saltare a un video a caso e chiude quando
   finisce. Se la libreria non arriva, il video sta già suonando lo stesso. La versione
   precedente lasciava creare l'iframe alla libreria, e senza libreria non si vedeva niente. */
function dcYouTube(pl){
  const mount = document.getElementById('dcYt');
  if (!mount) return;
  const origin = encodeURIComponent(location.origin);
  const url = 'https://www.youtube-nocookie.com/embed/videoseries?list=' + encodeURIComponent(pl)
    + '&autoplay=1&playsinline=1&rel=0&modestbranding=1&enablejsapi=1&origin=' + origin;
  mount.innerHTML = '<iframe id="dcYtFrame" allow="autoplay; encrypted-media" allowfullscreen src="' + url + '"></iframe>';

  const attach = () => {
    try{
      const p = new YT.Player('dcYtFrame', {
        events: {
          onReady: e => {
            try{
              const list = e.target.getPlaylist() || [];
              if (list.length > 1) e.target.playVideoAt(Math.floor(Math.random() * list.length));
              e.target.playVideo();
            }catch(_){ }
          },
          onStateChange: e => { if (e.data === 0) dcAnswerClose(); }
        }
      });
      DC.player = p;
    }catch(_){ }
  };
  if (window.YT && YT.Player){ attach(); return; }
  const prev = window.onYouTubeIframeAPIReady;
  window.onYouTubeIframeAPIReady = function(){ try{ if (typeof prev === 'function') prev(); }catch(_){ } attach(); };
  if (!DC.ytReady){
    DC.ytReady = true;
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(s);
  }
}

/* LA DERIVA SI RICONTA OGNI GIORNO, non solo quando si salva la pagina.
   Il motore giudica «alla deriva» con il numero che gli e' stato passato l'ultima volta: fermo
   a settimane prima, chiamava per una traiettoria che non era piu' quella. Qui si riconta a
   ogni cambio di giorno e a ogni apertura, e si manda al motore senza cartelli. */
let DC_DERIVA_GIORNO = '';
async function dcAggiornaDeriva(){
  if (!NATIVE || !NATIVE.setDreamCall) return;
  const oggi = new Date().toDateString();
  if (DC_DERIVA_GIORNO === oggi) return;
  DC_DERIVA_GIORNO = oggi;
  try{
    if (!DC.cfg) await dcLoad();
    if (!DC.cfg || !DC.cfg.on) return;
    const n = await dcDriftDays();
    if (n === DC.cfg.driftDays) return;
    DC.cfg.driftDays = n;
    await NATIVE.setDreamCall({ config: DC.cfg });
  }catch(_){ DC_DERIVA_GIORNO = ''; }
}
document.addEventListener('fl:giorno', function(){ DC_DERIVA_GIORNO = ''; dcAggiornaDeriva(); });
setTimeout(dcAggiornaDeriva, 6000);

/* Chi ha risposto lo dice il servizio aprendo l'app: lo si raccoglie al rientro. */
async function dcCheckAnswer(){
  if (!NATIVE || !NATIVE.consumeDreamAnswer) return;
  try{
    const r = await NATIVE.consumeDreamAnswer();
    if (r && r.answered) dcAnswerOpen(false);
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) dcCheckAnswer(); });
/* L'avviso diretto dal servizio: è la strada buona, perché rispondere alla chiamata non
   nasconde mai la pagina e quindi nessun evento di ritorno in primo piano scatta. Il giro
   qui sopra resta per il caso in cui l'app fosse chiusa e venga aperta adesso. */
try{ if (NATIVE && NATIVE.addListener) NATIVE.addListener('dreamAnswer', function(){ dcAnswerOpen(false); }); }catch(_){ }
setTimeout(dcCheckAnswer, 1200);

/* ---------- APPUNTAMENTO CON TE STESSO ----------

   L'abitudine piu' importante e' mantenere le promesse fatte a se stessi. Un evento del
   calendario di DreamMap con la chiamata accesa (fl_cal_eventi, chiamata: true) fa squillare la
   chiamata dei sogni all'ora d'inizio. La sveglia la arma il telefono (Appuntamento.java): qui
   gli si manda l'elenco, si leggono gli esiti e si danno i punti.

   Come si conta, una volta sola per evento:
   - rispondi e il Full Focus parte fra 10 minuti prima e 15 minuti dopo l'inizio: 2 punti al
     nuovo te (anche se eri gia' in Full Focus quando doveva squillare);
   - "Non ora", o nessuna risposta: 1 punto al vecchio te;
   - rispondi ma il Full Focus non parte entro 15 minuti dall'inizio: 1 punto al vecchio te;
   - la chiamata non e' riuscita a squillare (telefonata lunga, schermo spento): niente punti,
     a meno che il Full Focus sia partito lo stesso, e allora 2 al nuovo te.

   Il "Non ora" di QUALUNQUE chiamata dei sogni scrive fl_rientro_forzato: il pannello
   "Rientra in rotta" (rotta-tab.js) lo legge e compare subito. */
const DCA_KEY = 'fl_dc_app';
const DCA_PRIMA = 10 * 60000, DCA_DOPO = 15 * 60000;
function dcaStato(){
  let v = null; try{ v = JSON.parse(localStorage.getItem(DCA_KEY) || 'null'); }catch(_){ v = null; }
  v = (v && typeof v === 'object') ? v : {};
  v.esiti = v.esiti || {}; v.fatti = v.fatti || {}; v.usate = v.usate || {};
  return v;
}
function dcaSalva(st){
  const limite = Date.now() - 3 * 86400000;
  ['esiti', 'fatti', 'usate'].forEach(function(k){ Object.keys(st[k] || {}).forEach(function(id){ if ((st[k][id].at || 0) < limite) delete st[k][id]; }); });
  try{ localStorage.setItem(DCA_KEY, JSON.stringify(st)); }catch(_){ }
}
function dcaOn(){ return dcCfg().appuntamento !== false; }
/** I punti li da' solo il telefono: e' li' che la chiamata squilla. */
function dcaNativo(){
  if (typeof mgDesktop === 'function' && mgDesktop()) return false;
  return typeof NATIVE !== 'undefined' && !!NATIVE && typeof NATIVE.dcAppuntamenti === 'function';
}
/** Gli eventi del calendario con la chiamata accesa. */
function dcaEventi(){
  let l = null;
  try{ if (typeof calEventi === 'function') l = calEventi(); }catch(_){ l = null; }
  if (!Array.isArray(l)){ try{ l = JSON.parse(localStorage.getItem('fl_cal_eventi') || '[]'); }catch(_){ l = []; } }
  return (Array.isArray(l) ? l : []).filter(function(e){ return e && e.id != null && e.chiamata === true && isFinite(+e.inizio) && +e.inizio > 0; });
}
function dcaOra(t){ const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); }
function dcaTit(t){ t = String(t || '').trim(); return t ? '"' + (t.length > 50 ? t.slice(0, 47) + '...' : t) + '"' : 'il tuo appuntamento'; }

/* L'elenco al telefono: quelli che devono ancora cominciare, e quelli cominciati da meno di un
   quarto d'ora (cosi' il telefono capisce se uno in attesa e' stato cancellato). */
let DCA_T = 0;
function dcaSincronizzaPresto(){ clearTimeout(DCA_T); DCA_T = setTimeout(dcaSincronizza, 400); }
async function dcaSincronizza(){
  if (!dcaNativo()) return null;
  const ora = Date.now(), on = dcaOn();
  const eventi = on ? dcaEventi()
    .filter(function(e){ return +e.inizio > ora - DCA_DOPO && +e.inizio < ora + 60 * 86400000; })
    .sort(function(a, b){ return a.inizio - b.inizio; }).slice(0, 50)
    .map(function(e){ return { id: String(e.id), titolo: String(e.titolo || '').slice(0, 80), at: +e.inizio }; }) : [];
  try{ return await NATIVE.dcAppuntamenti({ on: on, eventi: eventi }); }catch(_){ return null; }
}
/* L'aggancio del calendario (calendario.js chiama window.calDopoModifica dopo ogni salvataggio
   o cancellazione), piu' l'evento fl:calendario: se arrivano tutti e due, l'elenco si manda una
   volta sola. */
(function(){
  const prima = window.calDopoModifica;
  window.calDopoModifica = function(ev, azione){
    try{ if (typeof prima === 'function') prima(ev, azione); }catch(_){ }
    dcaSincronizzaPresto();
  };
})();
document.addEventListener('fl:calendario', dcaSincronizzaPresto);

/* Gli esiti delle chiamate, dalla coda del telefono. Uno dietro l'altro: l'avviso diretto e il
   giro di ritorno in primo piano possono arrivare insieme. */
let DCA_CODA = Promise.resolve();
function dcaConsumaEsiti(){ DCA_CODA = DCA_CODA.then(dcaConsumaOra, dcaConsumaOra); return DCA_CODA; }
async function dcaConsumaOra(){
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.consumeDreamEsiti !== 'function'){ dcaValuta(); return; }
  let l = [];
  try{ const r = await NATIVE.consumeDreamEsiti(); l = (r && r.esiti) || []; }catch(_){ l = []; }
  if (l.length){
    const st = dcaStato();
    l.forEach(function(x){
      if (!x || !x.esito) return;
      if (x.esito === 'rifiutato') dcaRientro(x);
      /* 0.9.305: di cosa parlava la chiamata a cui hai risposto: la pagina lo mostra DOPO la risposta (dcMotivoDati) */
      if (x.esito === 'risposto' && x.motivo && x.motivo !== 'appuntamento'){ try{ localStorage.setItem('fl_dc_risposta', JSON.stringify({ k: x.motivo, riga: String(x.titolo || '').slice(0, 200), at: +x.at || Date.now() })); }catch(_){ } }
      if (x.motivo === 'appuntamento' && x.ev){
        const prima = st.esiti[x.ev];
        if (!prima || prima.esito === 'saltata') st.esiti[x.ev] = { esito: x.esito, at: +x.at || Date.now(), quando: +x.quando || 0, titolo: x.titolo || '', nota: x.nota || '' };
        if (x.esito === 'risposto') st.risposta = { ev: x.ev, titolo: x.titolo || '', quando: +x.quando || 0, at: +x.at || Date.now() };
        if (x.esito === 'saltata' && Date.now() - (+x.quando || 0) < 2 * 3600000)
          toast(x.nota === 'telefonata' ? 'La chiamata delle ' + dcaOra(+x.quando) + ' non è partita: eri al telefono' : x.nota === 'sessione' ? 'La chiamata delle ' + dcaOra(+x.quando) + ' non è partita: stavi facendo un esercizio di respirazione' : 'La chiamata delle ' + dcaOra(+x.quando) + ' non è partita: il telefono era spento o bloccato');
      }
    });
    dcaSalva(st);
  }
  dcaValuta();
}
/* "Non ora" a qualunque chiamata dei sogni: il pannello Rientra in rotta compare subito.
   Ogni rifiuto riscrive il segno, quindi il pannello torna anche se era gia' stato visto. */
function dcaRientro(x){
  const f = { at: +x.at || Date.now(), causa: 'chiamata', titolo: String(x.titolo || '').slice(0, 120), condizione: x.motivo || '' };
  try{ localStorage.setItem('fl_rientro_forzato', JSON.stringify(f)); }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:rientro-forzato', { detail: f })); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}

/* SI E' PRESENTATO? L'unico segnale misurabile: un Full Focus partito fra 10 minuti prima e 15
   minuti dopo l'inizio, e tenuto acceso almeno DCA_MIN_SESS (finito bene, o ancora acceso da
   almeno due minuti). Una sessione mollata dopo trenta secondi non e' "esserci". E una sessione
   vale per un appuntamento solo: dieci eventi alla stessa ora non fanno venti punti.
   Torna 'si' (con la sessione), 'forse' (partita, ma non ancora da due minuti) o ''. */
const DCA_MIN_SESS = 2 * 60000;
function dcaPresente(inizio, st, id){
  const ora = Date.now();
  const dentro = function(t){ return t >= inizio - DCA_PRIMA && t <= inizio + DCA_DOPO; };
  const libera = function(t){ const u = st && st.usate[String(t)]; return !u || u.id === id; };
  let forse = false;
  try{
    const r = JSON.parse(localStorage.getItem('fl_ff_session') || 'null');
    if (r && r.startAt && dentro(+r.startAt) && libera(+r.startAt)){
      if (ora - r.startAt >= DCA_MIN_SESS) return { si: true, start: +r.startAt };
      forse = true;
    }
  }catch(_){ }
  try{
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const x = h.filter(function(x){ return x && x.start && dentro(+x.start) && libera(+x.start) && (x.ok || (+x.spentMs || 0) >= DCA_MIN_SESS); })[0];
    if (x) return { si: true, start: +x.start };
  }catch(_){ }
  return forse ? { forse: true } : null;
}

/** La sessione di Full Focus accesa all'istante t (il suo inizio), se la pagina la conosce. */
function dcaSessioneA(t){
  try{
    const r = JSON.parse(localStorage.getItem('fl_ff_session') || 'null');
    if (r && r.startAt && +r.startAt <= t && (+r.endAt || 0) >= t) return +r.startAt;
  }catch(_){ }
  try{
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const x = h.filter(function(x){ return x && x.start && +x.start <= t && +x.start + (+x.spentMs || 0) >= t; })[0];
    if (x) return +x.start;
  }catch(_){ }
  return 0;
}

let DCA_GIRO = 0;
function dcaValuta(){
  if (!dcaNativo() || !dcaOn()) return;
  const st = dcaStato(), ora = Date.now();
  const evs = {}; dcaEventi().forEach(function(e){ evs[String(e.id)] = e; });
  const ids = {};
  Object.keys(st.esiti).forEach(function(id){ ids[id] = 1; });
  Object.keys(evs).forEach(function(id){ const i = +evs[id].inizio; if (i <= ora + DCA_PRIMA && i >= ora - 86400000) ids[id] = 1; });
  let aperti = false;
  Object.keys(ids).forEach(function(id){
    if (st.fatti[id]) return;
    const ev = evs[id], es = st.esiti[id];
    const inizio = ev ? +ev.inizio : ((es && es.quando) || 0);
    const titolo = (ev && ev.titolo) || (es && es.titolo) || '';
    if (!inizio) return;
    /* un esito di un orario vecchio (l'evento e' stato spostato) non vale per quello nuovo */
    const e = (es && (!es.quando || !ev || Math.abs(es.quando - inizio) < 60000)) ? es.esito : '';
    let chi = '', perche = '', sess = null;
    const pr = ora >= inizio - DCA_PRIMA ? dcaPresente(inizio, st, id) : null;
    if (ora - inizio > 86400000) chi = 'scaduto';
    else if (e === 'rifiutato' || e === 'persa'){ chi = 'old'; perche = e; }
    else if (e === 'presente'){
      /* il Full Focus era gia' acceso quando doveva squillare: vale, se quella sessione non ha
         gia' dato i punti a un altro appuntamento */
      sess = dcaSessioneA(inizio);
      const u = sess ? st.usate[String(sess)] : null;
      chi = (u && u.id !== id) ? 'nessuno' : 'neo';
      if (chi !== 'neo') sess = null;
    }
    else if (pr && pr.si){ chi = 'neo'; sess = pr.start; }
    else if (pr && pr.forse){ aperti = true; return; }
    else if (ora > inizio + DCA_DOPO){ if (e === 'risposto'){ chi = 'old'; perche = 'assente'; } else chi = 'nessuno'; }
    else { aperti = true; return; }
    st.fatti[id] = { chi: chi, esito: e || '', at: ora };
    if (sess) st.usate[String(sess)] = { id: id, at: ora };
    dcaSalva(st);   // prima il segno, poi il punto: un secondo giro non lo ripete
    if (chi === 'neo') dcaPuntoNuovo(titolo, inizio);
    else if (chi === 'old') dcaPuntoVecchio(titolo, inizio, perche);
  });
  /* finche' c'e' un appuntamento aperto, si ricontrolla ogni quindici secondi */
  if (aperti && !DCA_GIRO) DCA_GIRO = setInterval(dcaValuta, 15000);
  if (!aperti && DCA_GIRO){ clearInterval(DCA_GIRO); DCA_GIRO = 0; }
}
/* Due punti in un colpo solo: una riga nel registro, un cartello del gol. */
function dcaPuntoNuovo(titolo, inizio){
  const motivo = 'Appuntamento delle ' + dcaOra(inizio) + ' mantenuto: ' + dcaTit(titolo) + ' (punto doppio)';
  try{
    if (typeof mgLog === 'function' && typeof mtRoll === 'function' && typeof mtWrite === 'function' && typeof MT_KEY !== 'undefined'){
      mgLog('neo', motivo, { punti: 2 });
      const s = mtRoll(); s.neo += 2; mtWrite(MT_KEY, s);
      if (typeof mtGoal === 'function') mtGoal('neo');
      if (typeof mtPaint === 'function') mtPaint();
    } else if (typeof mgFocusPoint === 'function'){ if (mgFocusPoint(motivo, true)) mgFocusPoint(motivo, true); }
  }catch(_){ }
  toast('Sei qui: punto doppio al nuovo te');
}
function dcaPuntoVecchio(titolo, inizio, perche){
  const t = dcaTit(titolo), o = dcaOra(inizio);
  const motivo = perche === 'rifiutato' ? 'Appuntamento delle ' + o + ' rimandato con "Non ora": ' + t
    : perche === 'persa' ? 'Chiamata dell\'appuntamento delle ' + o + ' senza risposta: ' + t
    : 'Appuntamento delle ' + o + ' non cominciato entro 15 minuti: ' + t;
  try{ if (typeof mgOldPoint === 'function') mgOldPoint(motivo); }catch(_){ }
  if (perche === 'assente') toast('Il quarto d\'ora è passato: il punto va al vecchio te');
}

/* DOPO LA RISPOSTA: niente video, la scheda per cominciare. Torna vero se l'ha aperta (o se era
   gia' aperta: la risposta arriva per due strade, e il video non deve partire alla seconda). */
async function dcaDopoRisposta(){
  if (DC.appScheda && Date.now() - DC.appScheda < 90000) return true;
  await dcaConsumaEsiti();
  const st = dcaStato(), u = st.risposta;
  if (!u || !u.ev || u.aperta || Date.now() - u.at > 10 * 60000 || st.fatti[u.ev]) return false;
  u.aperta = Date.now(); dcaSalva(st);
  const ev = dcaEventi().filter(function(e){ return String(e.id) === u.ev; })[0];
  dcaScheda(ev ? ev.titolo : u.titolo, ev ? +ev.inizio : u.quando);
  return true;
}
let DCA_TITOLO = '';
function dcaScheda(titolo, inizio){
  DC.appScheda = Date.now();
  DCA_TITOLO = String(titolo || '').trim();
  const entro = dcaOra((inizio || Date.now()) + DCA_DOPO);
  const cosa = DCA_TITOLO ? '<b>' + esc(DCA_TITOLO) + '</b>' : 'il tuo appuntamento';
  if (typeof decOpen === 'function' && !(typeof DEC !== 'undefined' && DEC.open)){
    decOpen('custom', {
      /* 0.9.305: la chiamata in arrivo non dice piu' di cosa si tratta: lo dice questa scheda, dopo la risposta */
      kicker: 'Motivo della chiamata',
      title: 'SEI QUI.<br>ADESSO COMINCIA',
      line: 'È l\'ora del tuo appuntamento con te stesso: ' + cosa + '.<br>Fai partire il Full Focus entro le <b>' + entro + '</b>: il nuovo te prende <b>due punti</b>. Se non parte, il punto va al vecchio te.',
      left: 'PIÙ<br>TARDI', right: 'COMINCIA<br>ADESSO',
      leftAct: 'decClose()', rightAct: 'dcaComincia()',
      foot: 'La promessa che conta di più è quella che fai a te.'
    });
  } else toast('È l\'ora di: ' + (DCA_TITOLO || 'il tuo appuntamento') + '. Full Focus entro le ' + entro + ': due punti al nuovo te');
}
function dcaComincia(){
  if (typeof decClose === 'function') decClose();
  try{
    if (typeof ffPref === 'function' && DCA_TITOLO){
      const p = ffPref(); p.intent = DCA_TITOLO.slice(0, 250);
      if (typeof ffSavePref === 'function') ffSavePref();
    }
    if (typeof stSaltaSync === 'function') stSaltaSync();
    /* 0.9.322, Andrea: rispondendo alla chiamata dei sogni si passa dal finestrino dell'aereo */
    if (typeof drsFinestrino === 'function') drsFinestrino(function(){ ffOpen(); }); else if (typeof ffOpen === 'function') ffOpen();
  }catch(_){ }
}

try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.addListener) NATIVE.addListener('dreamEsito', function(){ dcaConsumaEsiti(); }); }catch(_){ }
document.addEventListener('visibilitychange', function(){ if (!document.hidden){ dcaConsumaEsiti(); dcaSincronizzaPresto(); } });
document.addEventListener('fl:tab', function(){ dcaValuta(); });
document.addEventListener('fl:giorno', dcaSincronizzaPresto);
/* all'avvio: l'elenco al telefono (il calendario puo' essere cambiato da un'altra parte) e gli
   esiti arrivati ad app chiusa */
setTimeout(function(){ dcaSincronizza(); dcaConsumaEsiti(); }, 3000);

registerOverlay('dcVideo', '');
(function(){ const el = document.getElementById('dcVideo'); if (el) el.hidden = true; })();

(function(){
  const css = [
    '#dcVideo[hidden]{display:none}',
    '#dcVideo{position:fixed;inset:0;z-index:99990;background:#000;display:flex;align-items:center;justify-content:center}',
    /* 0.9.306: il video non si taglia mai (contain). Finche' la sua forma non si sa occupa lo schermo; appena si sa
       (dc-ar, --dc-ar = larghezza / altezza) il riquadro prende la forma del video, al centro (dcRapportoApplica) */
    '#dcVideo video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;border:0;background:#000}',
    '#dcVideo video.dc-ar{inset:auto;left:50%;top:50%;transform:translate(-50%,-50%);width:min(100vw,calc(100vh * var(--dc-ar)));height:auto;max-height:100vh;aspect-ratio:var(--dc-ar)}',
    /* 0.9.306: come si risponde (impostazioni) */
    '.dc-risp{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.dc-risp-o{display:flex;flex-direction:column;align-items:center;gap:10px;padding:14px 8px 12px;border:1.5px solid var(--line);border-radius:14px;background:var(--card);cursor:pointer;text-align:center}',
    '.dc-risp-o b{font:700 12.5px/1.3 var(--font-body);color:var(--navy)}',
    '.dc-risp-o.on{border-color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.14)}',
    'body.dark .dc-risp-o b{color:#fff}',
    'body.dark .dc-risp-o.on{border-color:#3F9FF4;box-shadow:0 0 0 3px rgba(63,159,244,.22)}',
    '.dc-risp-o i{font-style:normal;display:flex;align-items:center;height:30px}',
    '.dc-risp-bar{width:104px;border-radius:99px;padding:2px;box-sizing:border-box;border:2px solid transparent;background:linear-gradient(135deg,#f6cce4,#dfd2f8 40%,#c1dbff 60%,#b6e9fe 88%,#ddfefc) padding-box,linear-gradient(135deg,#E71D4F,#0075E3) border-box}',
    '.dc-risp-bar em,.dc-risp-due em{font-style:normal;display:flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;font-size:13px;line-height:1}',
    '.dc-risp-bar em{background:#fff}',
    '.dc-risp-due{gap:14px}',
    '.dc-risp-due em{width:28px;height:28px;font-size:14px}',
    '.dc-risp-due .si{background:#22C55E}',
    '.dc-risp-due .no{background:#EF4444;transform:rotate(135deg)}',
    '.dc-risp-l{margin-bottom:6px}',
    /* 0.9.306: l'anteprima nella pagina, uguale alla finestra del telefono (DreamCallOverlay.java). Scura in tutti e due i temi */
    '#dcPrev{position:fixed;inset:0;z-index:99995;background:#000;overflow:hidden}',
    '#dcPrev .dcp-img{position:absolute;inset:0;background:#0B1730 center/cover no-repeat}',
    '#dcPrev .dcp-buio{position:absolute;inset:0;background:#000;opacity:1}',
    '#dcPrev .dcp-col{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;padding:64px 24px 40px;text-align:center}',
    '#dcPrev .dcp-t{font:800 34px/1.15 var(--font-display);color:#fff;text-shadow:0 2px 16px rgba(0,0,0,.8)}',
    '#dcPrev .dcp-s{margin-top:6px;font:500 17px var(--font-body);color:rgba(255,255,255,.9);text-shadow:0 2px 12px rgba(0,0,0,.8)}',
    '#dcPrev .dcp-vuoto{flex:1}',
    '#dcPrev .dcp-bar{position:relative;width:280px;height:60px;box-sizing:border-box;border-radius:99px;border:2px solid transparent;background:linear-gradient(135deg,#f6cce4,#dfd2f8 40%,#c1dbff 60%,#b6e9fe 88%,#ddfefc) padding-box,linear-gradient(135deg,#E71D4F,#0075E3) border-box;margin-bottom:28px;touch-action:none}',
    '#dcPrev .dcp-lbl{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding-left:40px;font:500 15px var(--font-body);color:#555}',
    '#dcPrev .dcp-pollice{position:absolute;left:0;top:0;width:56px;height:56px;border:0;border-radius:50%;background:#fff;font-size:24px;line-height:1;box-shadow:0 4px 10px rgba(0,0,0,.3);cursor:grab;touch-action:none;padding:0}',
    '#dcPrev .dcp-tasti{display:flex;justify-content:space-between;width:100%;box-sizing:border-box;padding:0 20px;margin-bottom:36px}',
    '#dcPrev .dcp-tasti button{border:0;background:none;padding:0;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:9px}',
    '#dcPrev .dcp-tasti i{display:flex;align-items:center;justify-content:center;width:72px;height:72px;border-radius:50%;font-size:32px;font-style:normal;box-shadow:0 6px 18px rgba(0,0,0,.4)}',
    '#dcPrev .dcp-si i{background:#22C55E;animation:dcpSquilla 1.4s ease-in-out infinite}',
    '#dcPrev .dcp-no i{background:#EF4444;transform:rotate(135deg)}',
    '#dcPrev .dcp-tasti small{font:600 14px var(--font-body);color:#fff}',
    '@keyframes dcpSquilla{0%,100%{transform:scale(1)}50%{transform:scale(1.09)}}',
    '@media (prefers-reduced-motion:reduce){#dcPrev .dcp-si i{animation:none}}',
    '#dcPrev .dcp-chiudi{border:0;background:none;padding:12px 28px;font:500 15px var(--font-body);color:rgba(255,255,255,.7);cursor:pointer}',
    '#dcYt,#dcVideo iframe{position:absolute;inset:0;width:100%;height:100%;border:0}',
    '.dc-skip{position:absolute;top:14px;right:14px;z-index:2;border:1px solid rgba(255,255,255,.5);background:rgba(255,255,255,.14);color:#fff;padding:8px 14px;border-radius:99px;font:700 13px var(--font-body);cursor:pointer}',
    '.dc-none{position:relative;z-index:1;color:#fff;text-align:center;padding:0 32px}',
    /* 0.9.305: il motivo della chiamata, dopo la risposta e prima del video. Come la chiamata, e' scuro anche nel tema chiaro */
    '.dc-mot{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:72px 24px 40px;overflow:auto;background:linear-gradient(180deg,#0E2350 0%,#001E44 100%)}',
    '.dc-mot-img{position:absolute;inset:0;background-size:cover;background-position:center;opacity:.22;filter:blur(2px)}',
    '.dc-mot-in{position:relative;z-index:1;width:100%;max-width:360px;display:flex;flex-direction:column;align-items:center;text-align:center;color:#fff}',
    '.dc-mot-in h2{margin:0;font:800 28px/1.15 var(--font-display);color:#fff;letter-spacing:-.01em}',
    '.dc-mot-riga{margin:14px 0 0;font:700 20px/1.4 var(--font-body);color:#fff;text-wrap:balance}',
    '.dc-mot-cond + .dc-mot-nota{margin-top:14px}',
    '.dc-mot-cond{display:flex;flex-direction:column;align-items:center;gap:6px;width:100%;box-sizing:border-box;margin-top:24px;padding:18px 16px;border:1px solid rgba(188,224,255,.35);border-radius:18px;background:rgba(255,255,255,.08)}',
    '.dc-mot-ico{display:inline-flex;align-items:center;justify-content:center;width:46px;height:46px;border-radius:50%;background:#fff;font-size:22px;line-height:1;margin-bottom:4px}',
    '.dc-mot-ico .dc-ico{margin:0}',
    '.dc-mot-cond b{font:800 15px var(--font-body);color:#fff}',
    '.dc-mot-cond small{font:500 13px/1.5 var(--font-body);color:#BCE0FF}',
    '.dc-mot-vai{margin-top:28px;border:0;border-radius:99px;padding:15px 30px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.4)}',
    '.dc-mot-vai:active{transform:scale(.97)}',
    '.dc-mot-bar{width:140px;height:4px;margin-top:18px;border-radius:99px;background:rgba(255,255,255,.18);overflow:hidden}',
    '.dc-mot-bar i{display:block;height:100%;width:0;background:#8CC6FF;border-radius:99px;animation:dcMotBar linear forwards}',
    '@keyframes dcMotBar{from{width:0}to{width:100%}}',
    '.dc-mot-nota{margin:10px 0 0;font:500 12.5px/1.45 var(--font-body);color:rgba(255,255,255,.72)}',
    '.dc-vids{display:flex;flex-direction:column;gap:6px;margin:8px 0}',
    '.dc-vid{display:flex;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--line);border-radius:12px;background:var(--card)}',
    '.dc-vid b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:600 12.5px var(--font-body);color:var(--navy)}',
    '.dc-vid b small{display:block;white-space:normal;font:600 11px var(--font-body);color:#E5515F}',
    '.dc-vid.rotto{border-color:rgba(229,81,95,.5)}',
    'body.dark .dc-vid b{color:#fff}',
    '.dc-none b{display:block;font:800 26px var(--font-display);font-style:italic}',
    '.dc-none p{margin-top:12px;font:500 14px/1.6 var(--font-body);color:rgba(255,255,255,.75)}',
    /* le impostazioni: ogni sezione è un paragrafo, con la sua aria attorno */
    '.dc-head{display:flex;align-items:flex-start;gap:12px}',
    '.dc-head > div{flex:1;min-width:0}',
    '.dc-head b{display:block;font:800 14px var(--font-body);color:var(--navy)}',
    '.dc-head small{display:block;margin-top:5px;font:500 12px/1.55 var(--font-body);color:var(--muted)}',
    '.dc-head .switch{margin-top:2px}',
    'body.dark .dc-head b{color:#fff}',
    '.dc-sec{margin-top:26px;padding-top:20px;border-top:1px solid var(--line)}',
    '.dc-sec h4{margin:0;font:700 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--blue,#006FCF)}',
    '.dc-sec > p{margin:8px 0 14px;font:500 12.5px/1.6 var(--font-body);color:var(--muted)}',
    '.dc-sec .ps-row{margin-top:12px}',
    '.dc-sec .fin{margin-top:10px}',
    '.dc-note{margin:10px 0 0;font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.dc-pann{display:flex;align-items:center;gap:10px;margin:12px 0 2px;font:600 13px/1.4 var(--font-body);color:var(--navy);cursor:pointer}.dc-pann input{width:20px;height:20px;accent-color:#0075E3;flex:none;pointer-events:none}body.dark .dc-pann{color:#fff}',
    '.dc-line{margin-top:18px}',
    '.dc-line > span{display:block;margin-bottom:8px;font:600 13px var(--font-body);color:var(--navy)}',
    'body.dark .dc-line > span{color:#fff}',
    '.dc-fields{display:flex;flex-direction:column;gap:8px}',
    '.dc-imgs{display:flex;gap:8px;flex-wrap:wrap;margin-top:4px}',
    '.dc-img{position:relative;width:64px;height:64px;border-radius:12px;background-size:cover;background-position:center;border:1px solid var(--line)}',
    '.dc-img button{position:absolute;top:-6px;right:-6px;width:22px;height:22px;border:0;border-radius:50%;background:var(--navy);color:#fff;font:700 12px/1 var(--font-body);cursor:pointer}',
    '.dc-inline{display:inline-flex;align-items:center;gap:6px;font:600 12.5px var(--font-body);color:var(--muted)}',
    '.dc-inline input{accent-color:var(--blue,#006FCF);width:16px;height:16px}',
    '.dc-trig{margin-top:16px;padding:14px;border:1px solid var(--line);border-radius:14px}',
    '.dc-trig.on{border-color:var(--blue,#006FCF);background:rgba(0,111,207,.04)}',
    'body.dark .dc-trig.on{background:rgba(46,139,255,.10)}',
    '.dc-trig .sev-chips{margin-top:12px}',
    '.dc-lab{font:600 12.5px var(--font-body);color:var(--muted)}',
    '.dc-time{width:110px;flex:none}',
    '.dc-ico{vertical-align:-3px;margin-right:4px;flex:none}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
