/* =========================================================================================
   IL FUNNEL DI PREMIUM (0.9.318)

   Andrea: "il pulsante del negozio deve portare alla prima slide del funnel, una feature alla volta con Continua, esattamente come
   Duolingo, con le nuvole belle curve e la mascotte, le animazioni in ogni slide; poi la schermata del confronto, poi i pacchetti, e
   Visualizza tutti i piani". Il modello sono gli screenshot di Super Duolingo: tre slide, il confronto Gratis/Premium, i piani.

   Niente numeri inventati: Duolingo scrive "4,2 volte" perche' ha i dati di milioni di abbonati; qui c'e' la probabilita' vera di chi
   legge (fl_oracle). Quando ci saranno i dati veri di chi paga contro chi non paga, PF_VOLTE diventa quel numero e il titolo lo dice.

   I piani nuovi (Lite, Pro) non si possono ancora comprare: Premium.buy risponde "non configurato" finche' non c'e' Play Billing e non
   esistono i prodotti con questi id nella Play Console. La prova di 7 giorni invece e' vera: pwStartTrial, senza carta.
   Niente piano Famiglia: per venderlo servirebbe la gestione del gruppo, che non esiste.
   ========================================================================================= */
const PF_VOLTE = 0;
const PF_PIANI = {
  pro: {
    nome: 'Pro', anno: { k: 'pro_annual', id: 'dreammap_pro_annual', prezzo: '69,99 €', mese: '5,83 €' }, mensile: { k: 'pro_monthly', id: 'dreammap_pro_monthly', prezzo: '6,99 €' },
    voci: ['Tutto quello che c’è in Premium', 'Chiamate con il tuo Io futuro', 'Più messaggi con il tuo agente'], art: 'pro'
  },
  premium: {
    nome: 'Premium', anno: { k: 'annual', prezzo: '29,99 €', mese: '2,50 €' }, mensile: { k: 'monthly', prezzo: '2,49 €' },
    voci: ['Energia illimitata', 'Il tuo agente personale', 'Zero annunci'], art: 'inf'
  },
  lite: {
    nome: 'Lite (con annunci)', anno: { k: 'lite_annual', id: 'dreammap_lite_annual', prezzo: '14,99 €', mese: '1,25 €' }, mensile: { k: 'lite_monthly', id: 'dreammap_lite_monthly', prezzo: '1,49 €' },
    voci: ['Energia doppia ogni giorno', 'Ricarica dell’energia più veloce'], art: 'doppia'
  }
};
const PF_SLIDE = [
  { t: 'Tappe illimitate.', art: 'energia' },
  { t: 'Il viaggio senza annunci.', art: 'annunci' },
  { t: 'Un agente personale che conosce il tuo sogno.', art: 'agente' }
];
const PF = { i: 0, piano: 'premium', durata: 'anno', vista: 'slide' };
(function(){
  try{
    if (typeof PREMIUM_PLANS === 'undefined') return;
    /* il listino del Play Store li legge da qui; il vecchio paywall mostra solo i suoi due (pwPlansHTML) */
    Object.keys(PF_PIANI).forEach(function(k){
      [PF_PIANI[k].anno, PF_PIANI[k].mensile].forEach(function(v, j){
        if (v.id && !PREMIUM_PLANS[v.k]) Object.defineProperty(PREMIUM_PLANS, v.k, { enumerable: false, value: { id: v.id, label: PF_PIANI[k].nome + (j ? ' mensile' : ' annuale'), listPrice: v.prezzo, price: v.prezzo, perMonth: v.mese || v.prezzo, discount: null, billing: j ? 'Addebito ogni mese' : 'Addebito ogni anno' } });
      });
    });
  }catch(_){ }
})();
function pfProb(){
  try{ const o = JSON.parse(localStorage.getItem('fl_oracle') || 'null'); if (o && o.pct > 0) return Math.round(o.pct); }catch(_){ }
  return 0;
}
function pfProva(){ try{ return typeof pwTrialUsed === 'function' && !pwTrialUsed(); }catch(_){ return false; } }
function pfVibra(n){ try{ if (typeof flVibra === 'function') flVibra(n || 10); }catch(_){ } }
function pfGenio(posa, cl){ return '<img class="pf-genio ' + (cl || '') + '" src="img/genio/genio-' + posa + '.png" alt="">'; }
const PF_X = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const PF_SPUNTA = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
/* le nuvole del riferimento: curve grandi, una bianca davanti e una azzurrina dietro */
function pfNuvole(){
  return '<svg class="pf-nuvole" viewBox="0 0 360 150" preserveAspectRatio="none" aria-hidden="true">'
    + '<path d="M0 74C22 34 66 30 92 56 112 18 168 6 204 44 232 16 292 18 316 56 332 42 350 46 360 58V150H0Z" fill="#CFE6FF" opacity=".55"/>'
    + '<path d="M0 96C26 58 70 54 104 82 128 44 180 38 214 72 244 46 300 50 324 82 340 72 352 74 360 82V150H0Z" fill="#fff"/></svg>';
}
function pfArte(k){
  if (k === 'energia') return '<div class="pf-arte"><div class="pf-bat"><i class="pf-bat-c"></i><span>∞</span></div><i class="pf-gambo"></i>' + pfGenio('saluta', 'su') + '<i class="pf-sc a">✦</i><i class="pf-sc b">✦</i><i class="pf-sc c">✦</i></div>';
  if (k === 'annunci') return '<div class="pf-arte">'
    + '<div class="pf-bolla a"><svg viewBox="0 0 24 24" width="30" height="30" fill="#8CC6FF" aria-hidden="true"><path d="M8 5l11 7-11 7z"/></svg></div>'
    + '<div class="pf-bolla b"><svg viewBox="0 0 24 24" width="30" height="30" fill="#8CC6FF" aria-hidden="true"><path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/></svg></div>'
    + '<div class="pf-bolla c"><svg viewBox="0 0 24 24" width="30" height="30" fill="#8CC6FF" aria-hidden="true"><path d="M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3L3 9.5l6.4-.6z"/></svg></div>'
    + pfGenio('pensa', 'centro') + '</div>';
  return '<div class="pf-arte">'
    + '<div class="pf-chat a"><i></i><i></i><i></i></div><div class="pf-chat b">Da dove riparti domani?</div>'
    + pfGenio('rivela', 'centro') + '</div>';
}
function pfApri(){
  PF.i = 0; PF.vista = 'slide'; PF.piano = 'premium'; PF.durata = 'anno';
  pfVibra(12);
  let w = document.getElementById('pfW');
  if (!w){ w = document.createElement('div'); w.id = 'pfW'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.hidden = false;
  pfDisegna();
}
function pfChiudi(){ const w = document.getElementById('pfW'); if (w){ w.hidden = true; w.innerHTML = ''; } }
function pfAperto(){ const w = document.getElementById('pfW'); return !!(w && !w.hidden); }
/** L'indietro del telefono: una slide indietro; dalla prima, fuori. */
function pfIndietro(){
  if (PF.vista === 'tutti'){ PF.vista = 'piani'; pfDisegna(); return; }
  if (PF.vista === 'piani'){ PF.vista = 'confronto'; pfDisegna(); return; }
  if (PF.vista === 'confronto'){ PF.vista = 'slide'; PF.i = PF_SLIDE.length - 1; pfDisegna(); return; }
  if (PF.i > 0){ PF.i--; pfDisegna(); return; }
  pfChiudi();
}
function pfContinua(){
  pfVibra(12);
  if (PF.vista === 'slide'){ if (PF.i < PF_SLIDE.length - 1) PF.i++; else PF.vista = 'confronto'; }
  else if (PF.vista === 'confronto') PF.vista = 'piani';
  pfDisegna();
}
function pfTesta(){
  return '<div class="pf-testa"><button type="button" class="pf-x" aria-label="Chiudi" onclick="pfChiudi()">' + PF_X + '</button><span class="pf-marchio">PREMIUM</span></div>';
}
function pfDisegna(){
  const w = document.getElementById('pfW'); if (!w) return;
  if (PF.vista === 'slide') w.innerHTML = pfSlideHtml();
  else if (PF.vista === 'confronto') w.innerHTML = pfConfrontoHtml();
  else w.innerHTML = pfPianiHtml(PF.vista === 'tutti');
}
function pfSlideHtml(){
  const s = PF_SLIDE[PF.i];
  return '<div class="pf pf-slide">' + pfTesta() + '<h2 class="pf-t pf-entra">' + s.t + '</h2>' + pfArte(s.art) + pfNuvole()
    + '<div class="pf-fondo"><button type="button" class="pf-cta" onclick="pfContinua()">Continua</button></div></div>';
}
function pfConfrontoHtml(){
  const p = pfProb();
  const tit = PF_VOLTE > 0 ? 'Hai una probabilità <em>' + String(PF_VOLTE).replace('.', ',') + ' volte</em> maggiore di arrivare al tuo sogno!'
    : p ? 'Oggi hai il <em>' + p + '%</em> di probabilità di arrivare al tuo sogno. Premium ti dà tutto per alzarla!'
    : 'Premium ti dà tutto quello che serve per arrivare al tuo sogno!';
  const righe = [['Il viaggio verso il sogno', 1], ['Energia illimitata', 0], ['Zero annunci', 0], ['Il tuo agente personale', 0], ['Chiamate con il tuo Io futuro', 0]];
  const trattino = '<i class="pf-no"></i>';
  return '<div class="pf pf-conf">' + pfTesta() + '<h2 class="pf-t pf-entra">' + tit + '</h2>'
    + pfNuvole()
    + '<div class="pf-tav"><div class="pf-col-prem"></div><div class="pf-tav-h"><span></span><b>GRATIS</b><b class="pf-tav-p">PREMIUM</b></div>'
    + righe.map(function(r, i){
        return '<div class="pf-tav-r" style="animation-delay:' + (240 + i * 110) + 'ms"><span>' + r[0] + '</span><i class="pf-sp g">' + (r[1] ? PF_SPUNTA : trattino) + '</i><i class="pf-sp b">' + PF_SPUNTA + '</i></div>';
      }).join('')
    + '</div><div class="pf-fondo bianco"><button type="button" class="pf-cta" onclick="pfContinua()">Continua</button></div></div>';
}
function pfAddebito(){
  const v = PF_PIANI[PF.piano][PF.durata];
  return { v: v, prova: PF.piano === 'premium' && pfProva() };
}
function pfArtePiano(k){
  if (k === 'inf') return '<span class="pf-mini inf">∞</span>';
  if (k === 'doppia') return '<span class="pf-mini doppia">2×</span>';
  return '<img class="pf-mini-g" src="img/genio/genio-saluta.png" alt="">';
}
function pfScegli(k, durata){ PF.piano = k; if (durata) PF.durata = durata; pfVibra(8); const sc = document.querySelector('.pf-scorre'), y = sc ? sc.scrollTop : 0; pfDisegna(); const s2 = document.querySelector('.pf-scorre'); if (s2) s2.scrollTop = y; }
function pfPianiHtml(tutti){
  const a = pfAddebito();
  const card = function(k){
    const p = PF_PIANI[k], on = PF.piano === k;
    return '<button type="button" class="pf-card' + (on ? ' on' : '') + '" onclick="pfScegli(\'' + k + '\',\'anno\')">'
      + (on ? '<i class="pf-card-ok">' + PF_SPUNTA + '</i>' : '')
      + '<span class="pf-card-t"><b>' + p.nome + '</b><em>' + p.anno.mese + ' / mese</em></span>'
      + '<small>' + p.anno.prezzo + ' / anno</small>'
      + '<span class="pf-card-g"><ul>' + p.voci.map(function(x){ return '<li>' + PF_SPUNTA + x + '</li>'; }).join('') + '</ul>' + pfArtePiano(p.art) + '</span></button>';
  };
  const riga = function(k, durata){
    const p = PF_PIANI[k], v = p[durata], on = PF.piano === k && PF.durata === durata;
    return '<button type="button" class="pf-riga' + (on ? ' on' : '') + '" onclick="pfScegli(\'' + k + '\',\'' + durata + '\')"><i class="pf-radio"></i><span><b>' + p.nome + '</b><small>' + (durata === 'anno' ? 'Addebito ogni anno' : 'Addebito ogni mese') + '</small></span><em>' + v.prezzo + (durata === 'anno' ? ' / anno' : ' / mese') + '</em></button>';
  };
  const corpo = tutti
    ? '<button type="button" class="pf-torna" onclick="PF.vista=\'piani\';pfDisegna()">Torna ai piani consigliati</button><div class="pf-righe">' + ['pro', 'premium', 'lite'].map(function(k){ return riga(k, 'anno') + riga(k, 'mensile'); }).join('') + '</div>'
    : ['pro', 'premium', 'lite'].map(card).join('')
      + '<p class="pf-altri">Cerchi altri modi per abbonarti?</p><button type="button" class="pf-link" onclick="PF.vista=\'tutti\';pfDisegna()">Visualizza tutti i piani</button>';
  const nome = PF_PIANI[PF.piano].nome.replace(' (con annunci)', '');
  return '<div class="pf pf-piani"><div class="pf-cielo">' + pfTesta() + '<h2 class="pf-t pf-entra">Inizia con Premium oggi stesso!</h2>' + pfNuvole() + '</div>'
    + '<div class="pf-scorre">' + corpo + '<button type="button" class="pf-rip" onclick="pfRipristina()">Ripristina gli acquisti</button></div>'
    + '<div class="pf-piede"><p>' + (a.prova ? 'Nessuna carta: fra 7 giorni torna la versione gratuita da sola.' : 'Addebito periodico, annullabile in qualsiasi momento.') + '</p>'
    + '<button type="button" class="pf-cta" onclick="pfCompra()">' + (a.prova ? 'Prova gratis per 7 giorni' : 'Passa a ' + nome) + '</button>'
    + (a.prova ? '' : '<small>Il tuo abbonamento si rinnova automaticamente per la stessa durata e allo stesso prezzo, a meno che non venga annullato almeno 24 ore prima della fine del periodo in corso. Puoi annullare in qualsiasi momento su Google Play.</small>')
    + '</div></div>';
}
async function pfCompra(){
  const a = pfAddebito();
  pfVibra(14);
  if (a.prova){ pfChiudi(); try{ pwStartTrial(); }catch(_){ } return; }
  const res = await Premium.buy(a.v.k);
  if (res && res.ok){ toast(PF_PIANI[PF.piano].nome + ' attivo: grazie!'); pfChiudi(); try{ renderProfile(); }catch(_){ } return; }
  toast(res && res.reason === 'not-configured' ? 'Questo piano non si può ancora acquistare' : (res && res.message) || 'Acquisto non riuscito');
}
function pfRipristina(){ try{ premiumRestore(); }catch(_){ } }
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* scuro e bianco in entrambi i temi, con l'inchiostro fisso: e' il disegno del riferimento nei colori del brand */
    '#pfW{position:fixed;inset:0;z-index:9700}#pfW[hidden]{display:none}',
    '.pf{position:absolute;inset:0;overflow:hidden;display:flex;flex-direction:column;background:linear-gradient(180deg,#0B1B3E 0%,#123C86 58%,#1B56B0 100%);color:#fff;text-align:center}',
    '.pf-testa{flex:none;display:flex;align-items:center;justify-content:space-between;padding:calc(env(safe-area-inset-top,0px) + 12px) 16px 0;position:relative;z-index:3}',
    '.pf-x{width:44px;height:44px;margin-left:-6px;border:0;background:none;color:#BCE0FF;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.pf-marchio{padding:5px 13px;border-radius:9px;background:linear-gradient(135deg,#E71D4F,#0075E3);color:#fff;font:900 12.5px var(--font-display);letter-spacing:.09em;transform:skewX(-10deg)}',
    '.pf-t{position:relative;z-index:3;margin:26px 26px 0;font:800 29px/1.22 var(--font-display);font-style:normal;color:#fff}',
    '.pf-t em{font-style:normal;color:#8CC6FF}',
    '.pf-entra{animation:pfSu .55s cubic-bezier(.2,.8,.2,1) both}',
    '@keyframes pfSu{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}',
    '@keyframes pfFluttua{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}',
    '@keyframes pfPop{0%{opacity:0;transform:scale(.3)}70%{opacity:1;transform:scale(1.08)}100%{opacity:1;transform:scale(1)}}',
    '@keyframes pfCade{0%{opacity:0;transform:translate(-50%,-70px)}70%{opacity:1;transform:translate(-50%,6px)}100%{opacity:1;transform:translate(-50%,0)}}',
    '@keyframes pfBrilla{0%,100%{opacity:.2;transform:scale(.7)}50%{opacity:1;transform:scale(1.15)}}',
    '.pf-nuvole{position:absolute;left:0;right:0;bottom:0;width:100%;height:clamp(190px,27vh,240px);z-index:1;animation:pfNuvola .7s ease-out both}',
    '@keyframes pfNuvola{from{transform:translateY(46px)}to{transform:none}}',
    '.pf-fondo{position:absolute;left:0;right:0;bottom:0;z-index:4;padding:0 24px calc(env(safe-area-inset-bottom,0px) + 26px)}',
    '.pf-cta{display:block;width:100%;min-height:56px;border:0;border-radius:18px;background:#0075E3;color:#fff;font:800 16px var(--font-body);letter-spacing:.07em;text-transform:uppercase;box-shadow:0 5px 0 #004FA0;cursor:pointer}',
    '.pf-cta:active{transform:translateY(3px);box-shadow:0 2px 0 #004FA0}',
    /* la mascotte con il bordo bianco da adesivo, come il riferimento */
    '.pf-genio{display:block;width:auto;filter:drop-shadow(3px 0 0 #fff) drop-shadow(-3px 0 0 #fff) drop-shadow(0 3px 0 #fff) drop-shadow(0 -3px 0 #fff) drop-shadow(0 10px 14px rgba(0,20,60,.35))}',
    '.pf-arte{position:absolute;left:0;right:0;top:0;bottom:0;z-index:2;pointer-events:none}',
    '.pf-genio.centro{position:absolute;left:50%;bottom:19%;height:40vh;max-height:330px;margin-left:calc(min(40vh,330px) * -.34);animation:pfFluttua 3.4s ease-in-out .6s infinite,pfSu .6s ease-out both}',
    '.pf-genio.su{position:absolute;left:50%;bottom:17%;height:34vh;max-height:280px;margin-left:calc(min(34vh,280px) * -.34);animation:pfFluttua 3.4s ease-in-out .6s infinite,pfSu .6s ease-out both}',
    /* la batteria infinita */
    '.pf-bat{position:absolute;left:50%;top:clamp(170px,24vh,210px);width:150px;height:96px;border:5px solid #fff;border-radius:24px;box-sizing:border-box;background:linear-gradient(135deg,#f6cce4 0%,#dfd2f8 40%,#c1dbff 60%,#b6e9fe 88%,#ddfefc 100%);display:flex;align-items:center;justify-content:center;color:#0B2A5B;font:900 60px/1 var(--font-display);box-shadow:0 10px 22px rgba(0,20,60,.35);animation:pfCade .8s cubic-bezier(.2,.9,.3,1) both;z-index:1}',
    '.pf-bat-c{position:absolute;right:-16px;top:26px;width:11px;height:34px;border-radius:0 8px 8px 0;background:#fff}',
    '.pf-sc{position:absolute;font-style:normal;color:#BCE0FF;font-size:22px;animation:pfBrilla 2.2s ease-in-out infinite}.pf-sc.a{left:13%;top:30%}.pf-sc.b{right:12%;top:26%;animation-delay:.6s;font-size:28px}.pf-sc.c{right:18%;top:48%;animation-delay:1.1s;font-size:16px}',
    /* le bolle degli annunci */
    '.pf-bolla{position:absolute;width:72px;height:72px;border:4px solid #fff;border-radius:18px;box-sizing:border-box;background:#E9F4FF;display:flex;align-items:center;justify-content:center;animation:pfPop .55s cubic-bezier(.2,.9,.3,1) both,pfSparisce 1.2s ease-in 2.4s both}',
    '.pf-bolla.a{left:9%;top:38%;animation-delay:.25s,2.3s}.pf-bolla.b{right:9%;top:28%;animation-delay:.45s,2.6s}.pf-bolla.c{right:7%;top:52%;animation-delay:.65s,2.9s}',
    '@keyframes pfSparisce{to{opacity:0;transform:scale(.4) rotate(14deg)}}',
    /* i messaggi dell'agente */
    '.pf-chat{position:absolute;padding:13px 18px;border:4px solid #fff;border-radius:22px;box-sizing:border-box;background:#E9F4FF;color:#0B2A5B;font:700 14.5px/1.3 var(--font-body);animation:pfPop .5s cubic-bezier(.2,.9,.3,1) both}',
    '.pf-chat.a{left:9%;top:44%;display:flex;gap:5px;border-bottom-right-radius:6px;animation-delay:.3s}.pf-chat.a i{width:9px;height:9px;border-radius:50%;background:#0075E3;animation:pfBrilla 1.1s ease-in-out infinite}.pf-chat.a i:nth-child(2){animation-delay:.18s}.pf-chat.a i:nth-child(3){animation-delay:.36s}',
    '.pf-chat.b{right:7%;top:32%;max-width:170px;border-bottom-left-radius:6px;animation-delay:.9s}',
    /* il confronto */
    '.pf-conf .pf-t{font-size:23px;margin-top:12px}',
    '.pf-conf .pf-nuvole{height:auto;top:30%;bottom:auto;aspect-ratio:360/150;width:100%}',
    '.pf-conf::after{content:"";position:absolute;left:0;right:0;bottom:0;top:calc(30% + 41.6vw);background:#fff;z-index:1}',
    '.pf-conf-genio{position:absolute;left:50%;top:calc(30% - 50px);z-index:0}.pf-genio.sbircia{height:150px;margin-left:-52px;animation:pfSu .6s ease-out both}',
    '.pf-tav{position:absolute;left:16px;right:16px;top:calc(30% + 96px);z-index:3;color:#001E44;text-align:left}',
    '.pf-col-prem{position:absolute;right:0;top:-8px;bottom:-8px;width:82px;border-radius:18px;background:#E3F1FF}',
    '.pf-tav-h,.pf-tav-r{position:relative;display:grid;grid-template-columns:1fr 66px 82px;align-items:center;min-height:44px}',
    '.pf-tav-h b{font:800 11.5px var(--font-body);letter-spacing:.05em;text-align:center;color:#4A5A72}.pf-tav-h b.pf-tav-p{color:#0075E3}',
    '.pf-tav-r{min-height:clamp(40px,6vh,50px);opacity:0;animation:pfSu .45s ease-out both}',
    '.pf-tav-r span{font:600 14px/1.25 var(--font-body);color:#001E44;padding-right:4px}',
    '.pf-sp{display:flex;justify-content:center;font-style:normal}.pf-sp.g{color:#4A5A72}.pf-sp.b{color:#0075E3}',
    '.pf-no{display:block;width:16px;height:4px;border-radius:2px;background:#C9D6E6}',
    /* i piani */
    '.pf-piani{background:#fff}',
    '.pf-cielo{flex:none;position:relative;background:linear-gradient(180deg,#0B1B3E 0%,#123C86 100%);height:clamp(210px,28vh,250px);overflow:hidden}',
    '.pf-cielo .pf-t{margin-top:8px;font-size:25px}',
    '.pf-cielo .pf-nuvole{height:96px}',
    '.pf-scorre{flex:1;min-height:0;overflow-y:auto;padding:4px 16px 22px;-webkit-overflow-scrolling:touch;color:#001E44;text-align:left}',
    '.pf-card{position:relative;display:block;width:100%;box-sizing:border-box;margin:0 0 16px;padding:18px 16px;border:3px solid #DCE8F5;border-radius:22px;background:#fff;color:#001E44;font-family:var(--font-body);text-align:left;cursor:pointer;box-shadow:0 4px 0 #DCE8F5}',
    '.pf-card.on{border-color:transparent;background:linear-gradient(#fff,#fff) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;box-shadow:0 4px 0 #BCE0FF}',
    '.pf-card-ok{position:absolute;right:-8px;top:-12px;width:36px;height:36px;border-radius:50%;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center}',
    '.pf-card-t{display:flex;align-items:baseline;justify-content:space-between;gap:10px}.pf-card-t b{font:800 18.5px var(--font-display);color:#001E44}.pf-card-t em{flex:none;font:800 15px var(--font-body);font-style:normal;color:#001E44}',
    '.pf-card small{display:block;margin-top:4px;font:700 14px var(--font-body);color:#4A5A72}',
    '.pf-card-g{display:flex;align-items:center;gap:10px;margin-top:12px}.pf-card-g ul{flex:1;min-width:0;list-style:none;margin:0;padding:0}',
    '.pf-card-g li{display:flex;align-items:flex-start;gap:8px;margin:0 0 7px;font:500 14px/1.3 var(--font-body);color:#001E44}.pf-card-g li svg{flex:none;width:17px;height:17px;margin-top:1px;color:#0075E3}',
    '.pf-mini{flex:none;display:flex;align-items:center;justify-content:center;width:68px;height:46px;border-radius:13px;color:#fff;font:900 24px var(--font-display);position:relative}.pf-mini::after{content:"";position:absolute;right:-6px;top:15px;width:5px;height:16px;border-radius:0 4px 4px 0;background:inherit}',
    '.pf-mini.inf{background:#0075E3}.pf-mini.doppia{background:#E63946;font-size:20px}',
    '.pf-mini-g{flex:none;width:68px;height:auto}',
    '.pf-altri{margin:18px 0 6px;text-align:center;font:500 15px var(--font-body);color:#4A5A72}',
    '.pf-link{display:block;width:100%;min-height:44px;border:0;background:none;color:#0075E3;font:800 14.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;cursor:pointer}',
    '.pf-rip{display:block;width:100%;min-height:40px;margin-top:4px;border:0;background:none;color:#4A5A72;font:600 13.5px var(--font-body);cursor:pointer}',
    '.pf-torna{display:block;width:100%;min-height:40px;margin-bottom:6px;border:0;background:none;color:#0075E3;font:800 14px var(--font-body);cursor:pointer}',
    '.pf-righe{display:flex;flex-direction:column;gap:10px}',
    '.pf-riga{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;padding:14px;border:2px solid #DCE8F5;border-radius:16px;background:#fff;color:#001E44;font-family:var(--font-body);text-align:left;cursor:pointer}.pf-riga.on{border-color:#0075E3;background:#F0F7FF}',
    '.pf-radio{flex:none;width:20px;height:20px;border:2px solid #BCE0FF;border-radius:50%;box-sizing:border-box}.pf-riga.on .pf-radio{border:6px solid #0075E3}',
    '.pf-riga span{flex:1;min-width:0}.pf-riga b{display:block;font:800 15px var(--font-body);color:#001E44}.pf-riga small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:#4A5A72}.pf-riga em{flex:none;font:800 14.5px var(--font-body);font-style:normal;color:#001E44}',
    '.pf-piede{flex:none;padding:12px 20px calc(env(safe-area-inset-bottom,0px) + 16px);background:#fff;border-top:1px solid #E3ECF6;text-align:center}',
    '.pf-piede p{margin:0 0 12px;font:500 14px/1.4 var(--font-body);color:#4A5A72}',
    '.pf-piede small{display:block;margin-top:12px;font:500 11px/1.4 var(--font-body);color:#4A5A72}'
  ].join('');
  document.head.appendChild(st);
})();
