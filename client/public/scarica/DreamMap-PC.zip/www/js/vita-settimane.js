/* ===========================================================================================
   LA MIA VITA IN SETTIMANE (0.9.286, Andrea)

   "Il memento mori come un calendario dell'avvento: e' l'utente che annerisce la casella della
   settimana appena chiusa. Zoom sulla casella, la penna che la annerisce come farebbe una persona,
   poi lo zoom indietro su tutto il calendario: Tu sei qui, e cerchiata in blu la settimana in cui
   arriva a destinazione. Il titolo e' La mia vita in settimane, e compare come passaggio dell'ultima
   slide del report settimanale, prima della frase della settimana."
   "Dopo averla annerita, la possibilita' di scrivere la pagina del diario della settimana, con foto
   e video degli eventi importanti. Se la rende pubblica dal Profilo, gli amici dalla sua Timeline
   toccano quelle caselle e leggono cosa ha fatto in quella settimana della sua vita."

   I conti delle settimane sono quelli di memento.js (mmConti: le domeniche dalla nascita).
   Le pagine stanno sul telefono: il testo in localStorage (fl_vita_pagine), foto e video in
   IndexedDB (fl_vita). Al server (focuslockVita.ts) va solo quello che e' pubblico.
   =========================================================================================== */
const VS_PAGINE_K = 'fl_vita_pagine';      // { "<settimana>": { testo, media: [id], inizio, at, su } }
const VS_ANNERITE_K = 'fl_vita_annerite';  // le settimane chiuse a mano nel report: [settimana]
const VS_PUB_K = 'fl_vita_pubblica';
const VS_BASE = 'https://meta-ai-media-buyer-production.up.railway.app';
const VS_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const VS_INK = '#2A1F1D', VS_VUOTA = '#E6D6CC', VS_ORA = '#E63946', VS_BLU = '#0075E3';
const VS_PENNA = '<svg viewBox="0 0 48 48" width="46" height="46" aria-hidden="true"><path d="M6 42l3.2-11.5L33.5 6.2a4 4 0 0 1 5.6 0l2.7 2.7a4 4 0 0 1 0 5.6L17.5 38.8z" fill="#0075E3" stroke="#0B3D7A" stroke-width="1.6" stroke-linejoin="round"/><path d="M9.2 30.5l8.3 8.3" stroke="#0B3D7A" stroke-width="1.6"/><path d="M6 42l3.2-11.5 8.3 8.3z" fill="#F4D7B5"/><path d="M6 42l1.5-5.2 3.7 3.7z" fill="#2A1F1D"/><path d="M29.5 10.2l8.3 8.3" stroke="#fff" stroke-opacity=".55" stroke-width="2"/></svg>';
const VS_X = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>';
const VS_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';

function vsEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function vsLeggi(k, def){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; }catch(_){ return def; } }
function vsScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); return true; }catch(_){ return false; } }
function vsPagine(){ const p = vsLeggi(VS_PAGINE_K, {}); return p && typeof p === 'object' ? p : {}; }
function vsPagina(i){ return vsPagine()[String(i)] || null; }
function vsPaginaPiena(p){ return !!(p && (String(p.testo || '').trim() || (p.media || []).length)); }
function vsPagineSet(){ const s = new Set(); const P = vsPagine(); Object.keys(P).forEach(function(k){ if (vsPaginaPiena(P[k])) s.add(+k); }); return s; }
function vsAnnerite(){ const a = vsLeggi(VS_ANNERITE_K, []); return Array.isArray(a) ? a : []; }
function vsPubblica(){ try{ return localStorage.getItem(VS_PUB_K) === '1'; }catch(_){ return false; } }

/* ---------- le date di una settimana (la stessa regola di mmConti: finisce di domenica) ---------- */
function vsPrimaDom(){
  const b = (typeof mmNascita === 'function') ? mmNascita() : ''; if (!b) return null;
  const d = new Date(b + 'T00:00:00'); d.setDate(d.getDate() + ((7 - d.getDay()) % 7)); return d;
}
function vsDate(i){
  const p = vsPrimaDom(); if (!p) return null;
  const dom = new Date(p); dom.setDate(dom.getDate() + 7 * i);
  const lun = new Date(dom); lun.setDate(lun.getDate() - 6);
  return { lun: lun, dom: dom };
}
function vsIso(d){ return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function vsRangeDa(lun){
  const dom = new Date(lun); dom.setDate(dom.getDate() + 6);
  const anno = dom.getFullYear() === new Date().getFullYear() ? '' : ' ' + dom.getFullYear();
  if (lun.getMonth() === dom.getMonth()) return 'dal ' + lun.getDate() + ' al ' + dom.getDate() + ' ' + VS_MESI[dom.getMonth()] + anno;
  return 'dal ' + lun.getDate() + ' ' + VS_MESI[lun.getMonth()] + ' al ' + dom.getDate() + ' ' + VS_MESI[dom.getMonth()] + anno;
}
function vsRange(i, inizio){
  if (inizio && /^\d{4}-\d{2}-\d{2}$/.test(inizio)) return vsRangeDa(new Date(inizio + 'T00:00:00'));
  const d = vsDate(i); return d ? vsRangeDa(d.lun) : '';
}
/** La settimana in cui arrivi a destinazione (la stima di oggi dell'arrivo), o -1. */
/* 0.9.305, Andrea: "la casella della settimana di arrivo non si vede piu'". LA CAUSA: qui si leggeva lo stato grezzo
   (ETA.stato o quello salvato) e si scartava la data se stato.oltre era acceso. Fino alla 0.9.304 "oltre" voleva dire
   anche "la data supera la scadenza che hai scelto": negli stati salvati prima (e in quelli che arrivano dal computer)
   resta acceso con una data vera, e il mirino spariva. etaArrivo() (eta.js) e' la data che vede il resto dell'app:
   oltre = solo "nessuna data", la scadenza superata e' oltreScadenza e la data si disegna lo stesso. */
function vsMetaIdx(c){
  if (!c) c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c) return -1;
  let a = null;
  try{ a = (typeof etaArrivo === 'function') ? etaArrivo() : null; }catch(_){ a = null; }
  if (!a || !isFinite(a.at) || a.oltre) return -1;
  /* la data ancora velata (i sette giorni del Genio, "Leggi me"): niente spoiler neanche qui */
  try{ if (typeof evVelata === 'function' && evVelata()) return -1; }catch(_){ }
  const d = vsDate(c.vissute); if (!d) return -1;
  const i = c.vissute + Math.floor((a.at - d.lun.getTime()) / (7 * 86400000));
  return i >= c.vissute && i < c.totale ? i : -1;
}
/* il mirino della settimana d'arrivo: un quadrato blu intorno alla casella, con il pallino blu al centro.
   Lo stesso segno nel report della settimana, nella pagina della mappa e nella legenda. */
function vsMirino(x, cx, cy, lato, mezzo, linea){
  x.save();
  x.fillStyle = 'rgba(0,117,227,.16)'; x.fillRect(cx - mezzo, cy - mezzo, mezzo * 2, mezzo * 2);
  x.strokeStyle = VS_BLU; x.lineWidth = linea; x.lineJoin = 'miter';
  x.strokeRect(cx - mezzo, cy - mezzo, mezzo * 2, mezzo * 2);
  x.fillStyle = VS_BLU; x.beginPath(); x.arc(cx, cy, Math.max(lato * 0.62, linea * 1.2), 0, Math.PI * 2); x.fill();
  x.restore();
}
/* la legenda sotto al calendario: il quadratino rosso di adesso e il mirino dell'arrivo (se c'e' una data) */
const VS_LEG_MIRINO = '<svg viewBox="0 0 14 14" width="14" height="14" aria-hidden="true"><rect x="1" y="1" width="12" height="12" fill="rgba(0,117,227,.16)" stroke="#0075E3" stroke-width="1.6"/><circle cx="7" cy="7" r="2.6" fill="#0075E3"/></svg>';
function vsLegendaHtml(conArrivo, cls){
  return '<div class="vs-leg' + (cls ? ' ' + cls : '') + '"><span><i class="vs-leg-ora"></i>Questa settimana</span>'
    + (conArrivo ? '<span>' + VS_LEG_MIRINO + 'Il giorno in cui arrivi</span>' : '') + '</div>';
}

/* ---------- la geometria del calendario (la stessa di mmDisegna, a una larghezza fissa) ---------- */
function vsGeo(anni){
  const W = 340, lab = 26, gapB = 5, gapBanda = 7;
  const passo = (W - lab - gapB * 3) / 52, lato = passo * 0.72, bande = Math.ceil(anni / 5);
  return { W: W, H: Math.ceil(anni * passo + (bande - 1) * gapBanda) + 4, lab: lab, gapB: gapB, gapBanda: gapBanda, passo: passo, lato: lato, anni: anni };
}
function vsPos(g, i){ const anno = Math.floor(i / 52), s = i % 52; return { x: g.lab + s * g.passo + Math.floor(s / 13) * g.gapB, y: anno * g.passo + Math.floor(anno / 5) * g.gapBanda }; }
function vsAschermo(st, x, y){ return { x: (x - st.cam.cx) * st.cam.s + st.vw / 2, y: (y - st.cam.cy) * st.cam.s + st.vh / 2 }; }

/* il disegno, con la "telecamera": s e' lo zoom, (cx, cy) il punto del calendario al centro della vista */
function vsDisegna(cv, st){
  const g = st.g, cam = st.cam, dpr = window.devicePixelRatio || 1;
  const W = Math.round(st.vw * dpr), H = Math.round(st.vh * dpr);
  if (cv.width !== W || cv.height !== H){ cv.width = W; cv.height = H; cv.style.width = st.vw + 'px'; cv.style.height = st.vh + 'px'; }
  const x = cv.getContext('2d');
  x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H);
  const k = dpr * cam.s;
  x.setTransform(k, 0, 0, k, dpr * (st.vw / 2 - cam.cx * cam.s), dpr * (st.vh / 2 - cam.cy * cam.s));
  const x0 = cam.cx - st.vw / 2 / cam.s - g.passo, x1 = cam.cx + st.vw / 2 / cam.s + g.passo;
  const y0 = cam.cy - st.vh / 2 / cam.s - g.passo, y1 = cam.cy + st.vh / 2 / cam.s + g.passo;
  x.font = '700 9px ' + (getComputedStyle(document.body).fontFamily || 'sans-serif');
  x.textAlign = 'right'; x.textBaseline = 'middle';
  for (let anno = 0; anno < g.anni; anno++){
    const y = anno * g.passo + Math.floor(anno / 5) * g.gapBanda;
    if (y + g.passo < y0 || y > y1) continue;
    if (anno % 5 === 4){ x.fillStyle = '#3A2E2B'; x.fillText(String(anno + 1), g.lab - 6, y + g.lato / 2); }
    for (let s = 0; s < 52; s++){
      const i = anno * 52 + s, px = g.lab + s * g.passo + Math.floor(s / 13) * g.gapB;
      if (px + g.lato < x0 || px > x1) continue;
      x.fillStyle = i < st.pieni ? (st.pagine.has(i) ? VS_BLU : VS_INK) : (i === st.corrente ? VS_ORA : VS_VUOTA);
      x.fillRect(px, y, g.lato, g.lato);
    }
  }
  /* la casella da chiudere: un anello che pulsa finche' non la tocchi */
  if (st.alone >= 0 && !st.tratto){
    const p = vsPos(g, st.alone), t = (Date.now() % 1400) / 1400, a = 0.35 + 0.45 * Math.sin(t * Math.PI * 2) * 0.5 + 0.2;
    x.strokeStyle = 'rgba(0,117,227,' + a.toFixed(3) + ')'; x.lineWidth = 2.2 / cam.s;
    const m = g.lato * (0.18 + 0.08 * Math.sin(t * Math.PI * 2));
    x.strokeRect(p.x - m, p.y - m, g.lato + 2 * m, g.lato + 2 * m);
  }
  /* il tratto della penna */
  if (st.tratto){
    const T = st.tratto, l = T.lunghezza * Math.min(1, T.p);
    x.save();
    x.beginPath(); x.rect(T.bx - g.lato * 0.04, T.by - g.lato * 0.04, g.lato * 1.08, g.lato * 1.08); x.clip();
    x.strokeStyle = VS_INK; x.lineWidth = g.lato * 0.13; x.lineCap = 'round'; x.lineJoin = 'round'; x.globalAlpha = 0.9;
    x.beginPath();
    x.moveTo(T.punti[0][0], T.punti[0][1]);
    let fatto = 0;
    for (let i = 0; i < T.punti.length - 1; i++){
      const a = T.punti[i], b = T.punti[i + 1];
      if (T.salti[i + 1]){ x.moveTo(b[0], b[1]); continue; }
      const d = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (fatto + d <= l){ x.lineTo(b[0], b[1]); fatto += d; continue; }
      const q = Math.max(0, (l - fatto) / d);
      x.lineTo(a[0] + (b[0] - a[0]) * q, a[1] + (b[1] - a[1]) * q);
      break;
    }
    x.stroke();
    if (T.pieno > 0){ x.globalAlpha = Math.min(1, T.pieno); x.fillStyle = VS_INK; x.fillRect(T.bx, T.by, g.lato, g.lato); }
    x.restore();
  }
  /* la settimana d'arrivo: il mirino quadrato blu */
  if (st.meta >= 0 && st.metaVisibile){
    const p = vsPos(g, st.meta);
    x.globalAlpha = st.metaVisibile;
    vsMirino(x, p.x + g.lato / 2, p.y + g.lato / 2, g.lato, Math.max(g.lato * 1.5, 6.5 / cam.s), 2 / cam.s);
    x.globalAlpha = 1;
  }
}
/* il tratteggio a mano: linee a zig-zag in diagonale, poi una seconda passata incrociata, un po' storte */
function vsScarabocchio(bx, by, l){
  const P = [], S = [];
  const tremo = function(){ return (Math.random() - 0.5) * l * 0.06; };
  const n = 13;
  for (let k = 0; k < n; k++){
    const c = (k + 0.5) / n * 2 * l;
    const a = [bx + Math.max(0, c - l), by + Math.min(c, l)], b = [bx + Math.min(c, l), by + Math.max(0, c - l)];
    const da = k % 2 ? b : a, aa = k % 2 ? a : b;
    P.push([da[0] + tremo(), da[1] + tremo()]); S.push(false);
    P.push([aa[0] + tremo(), aa[1] + tremo()]); S.push(false);
  }
  const m = 10;
  for (let k = 0; k < m; k++){
    const c = (k + 0.5) / m * 2 * l - l;
    const a = [bx + Math.max(0, c), by + Math.max(0, -c)], b = [bx + Math.min(l, l + c), by + Math.min(l, l - c)];
    const da = k % 2 ? b : a, aa = k % 2 ? a : b;
    P.push([da[0] + tremo(), da[1] + tremo()]); S.push(k === 0);
    P.push([aa[0] + tremo(), aa[1] + tremo()]); S.push(false);
  }
  let L = 0; for (let i = 0; i < P.length - 1; i++) if (!S[i + 1]) L += Math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1]);
  return { punti: P, salti: S, lunghezza: L, p: 0, pieno: 0, bx: bx, by: by };
}
function vsPuntaA(T, l){
  let fatto = 0;
  for (let i = 0; i < T.punti.length - 1; i++){
    if (T.salti[i + 1]) continue;
    const a = T.punti[i], b = T.punti[i + 1], d = Math.hypot(b[0] - a[0], b[1] - a[1]);
    if (fatto + d >= l){ const q = (l - fatto) / d; return [a[0] + (b[0] - a[0]) * q, a[1] + (b[1] - a[1]) * q]; }
    fatto += d;
  }
  return T.punti[T.punti.length - 1];
}
const vsEase = function(t){ return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };

/* ===========================================================================================
   IL CALENDARIO DELL'AVVENTO, NEL REPORT DELLA SETTIMANA
   host: il contenitore; opz.dopo: cosa fare con "Continua" (la frase della settimana).
   =========================================================================================== */
const VSA = { st: null, raf: 0, fase: '' };
function vsAvvento(host, opz){
  opz = opz || {};
  const c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c || !host || c.vissute < 1){ if (opz.dopo) opz.dopo(); return false; }
  const anni = (typeof mmAnni === 'function') ? mmAnni() : 80, g = vsGeo(anni);
  const idx = c.vissute - 1, gia = vsAnnerite().indexOf(idx) >= 0, meta = vsMetaIdx(c);
  const range = vsRange(idx);
  VSA.metaTesto = null;
  host.innerHTML = '<div class="vs">'
    /* 0.9.290, Andrea: "Ogni casella e' una settimana della tua vita" va SOTTO al calendario, prima di "Scrivi la pagina del
       diario", non sotto al titolo */
    + '<p class="vs-tit">La tua vita in settimane</p>'
    /* 0.9.305: cosa sono il quadratino rosso e il mirino blu lo dice la legenda sotto al calendario */
    + '<p class="vs-istr" id="vsIstr">' + (gia ? '' : 'Tocca la casella per chiudere la settimana ' + vsEsc(range) + '.') + '</p>'
    /* 0.9.308, Andrea: la legenda sta DENTRO la carta bianca del calendario, in fondo; sullo sfondo scuro restano solo
       "Ogni casella e' una settimana della tua vita." e i pulsanti */
    + '<div class="vs-carta" id="vsCarta"><div class="vs-vista" id="vsVista" role="button" aria-label="Chiudi la settimana ' + vsEsc(range) + '"><canvas id="vsCv"></canvas><div class="vs-segni" id="vsSegni"></div></div>'
    + vsLegendaHtml(meta >= 0, 'vs-leg-report') + '</div>'
    + '<p class="vs-sotto">Ogni casella è una settimana della tua vita.</p>'
    + '<div class="vs-azioni" id="vsAzioni" hidden>'
    +   '<button type="button" class="vs-b2" onclick="vsPaginaApri(' + idx + ')">' + VS_PENNA.replace('width="46" height="46"', 'width="20" height="20"') + '<span>Scrivi la pagina del diario</span></button>'
    +   '<button type="button" class="vs-b1" id="vsAvanti">Continua</button>'
    + '</div></div>';
  const vista = document.getElementById('vsVista'), cv = document.getElementById('vsCv');
  /* il foglio e' largo quanto il calendario, senza bordi bianchi ai lati */
  const largo = Math.max(220, Math.floor((host.clientWidth || 340) - 20));
  /* 0.9.321, Andrea: "c'e' una striscia vuota a destra e il calendario e' troppo piccolo". Il tetto del 56% dell'altezza lo stringeva:
     prende tutta la larghezza, e la pagina scorre */
  let fit = largo / g.W;
  const vw = Math.round(g.W * fit), vh = Math.round(g.H * fit);
  fit = Math.min(vw / g.W, vh / g.H);
  vista.style.width = vw + 'px'; vista.style.height = vh + 'px';
  if (meta >= 0) vista.dataset.meta = '1';
  const p = vsPos(g, idx);
  const Z = Math.min(14, 56 / g.lato);
  const st = {
    g: g, vw: vw, vh: vh, fit: fit, idx: idx, meta: meta, metaVisibile: gia ? 1 : 0,
    pieni: gia ? c.vissute : c.vissute - 1, corrente: c.vissute, pagine: vsPagineSet(), alone: gia ? -1 : idx, tratto: null,
    cam: gia ? { s: fit, cx: g.W / 2, cy: g.H / 2 } : { s: Z, cx: p.x + g.lato / 2, cy: p.y + g.lato / 2 }
  };
  VSA.st = st; VSA.fase = gia ? 'fine' : 'attesa';
  const avanti = document.getElementById('vsAvanti');
  if (avanti) avanti.onclick = function(){ vsFerma(); if (opz.dopo) opz.dopo(); };
  vsDisegna(cv, st);
  if (gia){ const durata = vsSegniMostra(st); setTimeout(vsMostraDopo, (+durata || 0) + 350); return true; }
  vsGiro();
  vista.addEventListener('click', function(){ if (VSA.fase === 'attesa') vsAnnerisci(); });
  return true;
}
function vsFerma(){ cancelAnimationFrame(VSA.raf); VSA.raf = 0; }
function vsGiro(){
  vsFerma();
  const passo = function(){
    const cv = document.getElementById('vsCv'), st = VSA.st;
    if (!cv || !st){ VSA.raf = 0; return; }
    vsDisegna(cv, st);
    if (VSA.fase === 'attesa' || VSA.fase === 'penna' || VSA.fase === 'zoom') VSA.raf = requestAnimationFrame(passo);
  };
  VSA.raf = requestAnimationFrame(passo);
}
function vsAnnerisci(){
  const st = VSA.st; if (!st) return;
  VSA.fase = 'penna';
  const g = st.g, p = vsPos(g, st.idx);
  st.tratto = vsScarabocchio(p.x, p.y, g.lato);
  const istr = document.getElementById('vsIstr'); if (istr) istr.classList.add('via');
  VSA.metaTesto = '';
  const segni = document.getElementById('vsSegni');
  const penna = document.createElement('div'); penna.className = 'vs-penna'; penna.innerHTML = VS_PENNA;
  if (segni) segni.appendChild(penna);
  const DUR = 1700, t0 = performance.now();
  let ultimoTic = 0;
  try{ flVibra(8); }catch(_){ }
  const muovi = function(now){
    if (VSA.fase !== 'penna' || !document.getElementById('vsCv')) return;
    const t = Math.min(1, (now - t0) / DUR);
    st.tratto.p = t;
    const punta = vsPuntaA(st.tratto, st.tratto.lunghezza * t), s = vsAschermo(st, punta[0], punta[1]);
    penna.style.transform = 'translate(' + (s.x - 3).toFixed(1) + 'px,' + (s.y - 43).toFixed(1) + 'px)';
    if (now - ultimoTic > 120){ ultimoTic = now; try{ flVibra(4); }catch(_){ } }
    if (t < 1){ requestAnimationFrame(muovi); return; }
    /* l'inchiostro si chiude, la penna si alza */
    const t1 = performance.now();
    const chiudi = function(n2){
      const q = Math.min(1, (n2 - t1) / 260);
      st.tratto.pieno = q;
      penna.style.opacity = String(1 - q);
      if (q < 1){ requestAnimationFrame(chiudi); return; }
      penna.remove();
      st.pieni = st.idx + 1; st.alone = -1;
      try{ flVibra([10, 40, 20]); }catch(_){ }
      try{ if (typeof muJingle === 'function') muJingle('moneta'); }catch(_){ }
      const a = vsAnnerite(); if (a.indexOf(st.idx) < 0){ a.push(st.idx); vsScrivi(VS_ANNERITE_K, a.slice(-400)); }
      setTimeout(vsZoomVia, 420);
    };
    requestAnimationFrame(chiudi);
  };
  requestAnimationFrame(muovi);
}
function vsZoomVia(){
  const st = VSA.st; if (!st || !document.getElementById('vsCv')) return;
  VSA.fase = 'zoom';
  const da = { s: st.cam.s, cx: st.cam.cx, cy: st.cam.cy }, a = { s: st.fit, cx: st.g.W / 2, cy: st.g.H / 2 };
  const DUR = 1700, t0 = performance.now();
  vsGiro();
  const passo = function(now){
    if (VSA.fase !== 'zoom') return;
    const t = Math.min(1, (now - t0) / DUR), e = vsEase(t);
    st.cam.s = Math.exp(Math.log(da.s) + (Math.log(a.s) - Math.log(da.s)) * e);
    st.cam.cx = da.cx + (a.cx - da.cx) * e; st.cam.cy = da.cy + (a.cy - da.cy) * e;
    if (t < 1){ requestAnimationFrame(passo); return; }
    VSA.fase = 'fine';
    const t1 = performance.now();
    const cerchio = function(n2){ st.metaVisibile = Math.min(1, (n2 - t1) / 500); const cv = document.getElementById('vsCv'); if (cv) vsDisegna(cv, st); if (st.metaVisibile < 1) requestAnimationFrame(cerchio); };
    requestAnimationFrame(cerchio);
    /* 0.9.308: i pulsanti arrivano dopo la legenda, un elemento alla volta (prima comparivano insieme ai fumetti) */
    const durata = vsSegniMostra(st);
    setTimeout(vsMostraDopo, (+durata || 0) + 350);
  };
  requestAnimationFrame(passo);
}
/* Tu sei qui (la settimana di adesso) e l'arrivo, sopra al disegno.
   0.9.308, Andrea: "Qui arrivi viene tagliato al bordo sinistro e non e' blu pieno; Tu sei qui e Qui arrivi compaiono e
   spariscono insieme". LE CAUSE: (1) il fumetto era centrato sulla casella con translate(-50%) dentro .vs-vista, che ha
   overflow:hidden: con l'arrivo nelle prime colonne meta' fumetto finiva fuori e veniva tagliato; (2) un solo timer
   accendeva e spegneva tutti e due i fumetti e la legenda insieme, e nello stesso secondo si leggevano due fumetti che
   gia' sbiadivano. ADESSO: una sequenza, un segno alla volta: Tu sei qui (rosso), poi Qui arrivi (blu), poi la legenda,
   che sta dentro la carta del calendario. Ogni fumetto e' tenuto dentro la vista (vsEtDentro) e la sua punta si sposta
   per indicare lo stesso la casella giusta. */
const VS_ET_TIENI = 900, VS_ET_SFUMA = 300;   /* ogni fumetto: 0,3 s per entrare, 0,9 s fermo, 0,3 s per andarsene */
function vsEtDentro(el, x, vw){
  const w = el.offsetWidth || 92, m = 4;
  const c = Math.max(w / 2 + m, Math.min(vw - w / 2 - m, x));
  el.style.left = c.toFixed(1) + 'px';
  /* la punta resta sopra la casella anche quando il fumetto si sposta (mai oltre gli angoli arrotondati) */
  el.style.setProperty('--coda', Math.max(-w / 2 + 12, Math.min(w / 2 - 12, x - c)).toFixed(1) + 'px');
}
function vsSegniMostra(st){
  const segni = document.getElementById('vsSegni'); if (!segni) return;
  const g = st.g, fumetti = [];
  (VSA.tFumetti || []).forEach(clearTimeout); VSA.tFumetti = [];
  segni.querySelectorAll('.vs-et').forEach(function(e){ e.remove(); });
  const qui = vsPos(g, st.corrente), q = vsAschermo(st, qui.x + g.lato / 2, qui.y + g.lato / 2);
  fumetti.push({ cls: 'vs-qui ' + (q.y > 44 ? 'su' : 'giu'), x: q.x, y: q.y, t: 'Tu sei qui' });
  if (st.meta >= 0){
    const m = vsPos(g, st.meta), s = vsAschermo(st, m.x + g.lato / 2, m.y + g.lato / 2);
    /* sotto al mirino se c'e' posto, cosi' il fumetto non copre le settimane gia' vissute */
    fumetti.push({ cls: 'vs-arrivo ' + (s.y < st.vh - 40 ? 'giu' : 'su'), x: s.x, y: s.y, t: 'Qui arrivi' });
  }
  const leg = document.querySelector('.vs-leg-report');
  if (leg) leg.classList.remove('in');
  const tieni = function(fn, ms){ VSA.tFumetti.push(setTimeout(fn, ms)); };
  fumetti.forEach(function(f, i){
    const t0 = i * (VS_ET_TIENI + VS_ET_SFUMA);
    tieni(function(){
      if (!segni.isConnected) return;
      const el = document.createElement('div');
      el.className = 'vs-et ' + f.cls;
      el.style.top = f.y.toFixed(1) + 'px';
      el.innerHTML = '<span>' + f.t + '</span>';
      segni.appendChild(el);
      vsEtDentro(el, f.x, st.vw);
      requestAnimationFrame(function(){ el.classList.add('in'); });
      tieni(function(){ el.classList.add('via'); }, VS_ET_TIENI);
      tieni(function(){ el.remove(); }, VS_ET_TIENI + VS_ET_SFUMA + 100);
    }, t0);
  });
  /* per ultima la legenda, quando l'ultimo fumetto se n'e' andato: resta, con il quadratino rosso e il mirino blu */
  const fine = fumetti.length * (VS_ET_TIENI + VS_ET_SFUMA);
  tieni(function(){ if (leg) leg.classList.add('in'); }, fine);
  return fine;
}
function vsMostraDopo(){
  const d = document.getElementById('vsIstr'), a = document.getElementById('vsAzioni');
  /* senza una frase nuova l'istruzione resta trasparente al suo posto: il calendario non salta in su */
  if (d && VSA.metaTesto){ d.textContent = VSA.metaTesto; d.classList.remove('via'); }
  if (a){ a.hidden = false; requestAnimationFrame(function(){ a.classList.add('in'); }); }
}
/* dopo la pagina scritta, la settimana diventa blu anche qui */
function vsAvventoRidisegna(){ const st = VSA.st, cv = document.getElementById('vsCv'); if (!st || !cv) return; st.pagine = vsPagineSet(); vsDisegna(cv, st); }

/* ===========================================================================================
   LA PAGINA DELLA SETTIMANA: testo, foto e video
   =========================================================================================== */
/* I post della scheda Media usano le stesse pagine sul server, dalla "settimana" 5000 in su: una vita di 90 anni ne ha 4680 (profile.js) */
const AP_SLOT = 5000;
let VS_DB = null;
function vsDb(){
  if (VS_DB) return VS_DB;
  VS_DB = new Promise(function(ok, ko){
    try{
      const r = indexedDB.open('fl_vita', 1);
      r.onupgradeneeded = function(){ const d = r.result; if (!d.objectStoreNames.contains('media')) d.createObjectStore('media', { keyPath: 'id' }); };
      r.onsuccess = function(){ ok(r.result); };
      r.onerror = function(){ VS_DB = null; ko(r.error); };
    }catch(e){ VS_DB = null; ko(e); }
  });
  return VS_DB;
}
async function vsMediaScrivi(m){ const d = await vsDb(); return new Promise(function(ok, ko){ const t = d.transaction('media', 'readwrite'); t.objectStore('media').put(m); t.oncomplete = function(){ ok(true); }; t.onerror = function(){ ko(t.error); }; }); }
async function vsMediaLeggi(id){ try{ const d = await vsDb(); return await new Promise(function(ok){ const q = d.transaction('media', 'readonly').objectStore('media').get(id); q.onsuccess = function(){ ok(q.result || null); }; q.onerror = function(){ ok(null); }; }); }catch(_){ return null; } }
async function vsMediaTogli(id){ try{ const d = await vsDb(); await new Promise(function(ok){ const t = d.transaction('media', 'readwrite'); t.objectStore('media').delete(id); t.oncomplete = function(){ ok(true); }; t.onerror = function(){ ok(false); }; }); }catch(_){ } }
function vsNuovoId(){ return 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

const VSP = { idx: -1, t: 0, url: {} };
function vsPaginaSalvaTesto(idx, testo){
  const P = vsPagine(), k = String(idx);
  const p = P[k] || { testo: '', media: [], inizio: '', at: 0 };
  p.testo = String(testo || '').slice(0, 6000); p.at = Date.now(); p.su = false;
  if (!p.inizio){ const d = vsDate(idx); if (d) p.inizio = vsIso(d.lun); }
  P[k] = p;
  const ok = vsScrivi(VS_PAGINE_K, P);
  if (!ok){ try{ toast('Memoria piena: la pagina non si è salvata'); }catch(_){ } }
  return ok;
}
function vsPaginaApri(idx){
  if (!(idx >= 0)) return;
  VSP.idx = idx;
  const p = vsPagina(idx) || { testo: '', media: [] };
  const w = document.createElement('div'); w.id = 'vspVelo'; w.className = 'vsp-velo';
  w.innerHTML = '<section class="vsp" role="dialog" aria-modal="true">'
    + '<div class="vsp-h"><div><small>La pagina del diario</small><b>La settimana ' + vsEsc(vsRange(idx)) + '</b></div><button type="button" class="vsp-x" onclick="vsPaginaChiudi()" aria-label="Chiudi">' + VS_X + '</button></div>'
    + '<textarea id="vspTesto" class="vsp-testo" rows="6" placeholder="Com’è andata? Scrivi cosa vuoi ricordare di questa settimana." oninput="vsPaginaScrive(this)">' + vsEsc(p.testo || '') + '</textarea>'
    + '<div class="vsp-media" id="vspMedia"></div>'
    + '<input type="file" id="vspFile" accept="image/*,video/*" multiple hidden onchange="vsFileScelti(this)">'
    + '<button type="button" class="vsp-agg" onclick="document.getElementById(\'vspFile\').click()"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="3"/><circle cx="9" cy="11" r="2"/><path d="M21 17l-5-5-9 8"/></svg>Aggiungi foto o video</button>'
    + '<p class="vsp-nota">' + (vsPubblica() ? 'I tuoi amici la vedono nella tua Timeline.' : 'La vedi solo tu. Puoi renderla pubblica dal Profilo, nella scheda Timeline.') + '</p>'
    + '<button type="button" class="vsp-salva" onclick="vsPaginaFatta()">Salva la pagina</button>'
    + '</section>';
  w.addEventListener('click', function(e){ if (e.target === w) vsPaginaChiudi(); });
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('su'); });
  vsMediaPaint();
}
function vsPaginaScrive(t){ clearTimeout(VSP.t); const v = t.value; VSP.t = setTimeout(function(){ vsPaginaSalvaTesto(VSP.idx, v); }, 300); }
function vsPaginaChiudi(){
  const t = document.getElementById('vspTesto'); if (t){ clearTimeout(VSP.t); vsPaginaSalvaTesto(VSP.idx, t.value); }
  const w = document.getElementById('vspVelo'); if (w) w.remove();
  Object.keys(VSP.url).forEach(function(k){ try{ URL.revokeObjectURL(VSP.url[k]); }catch(_){ } }); VSP.url = {};
  try{ vsAvventoRidisegna(); }catch(_){ }
  try{ if (typeof mmPaint === 'function' && document.getElementById('mmCanvas')) mmPaint(); }catch(_){ }
  vsSyncPresto();
}
function vsPaginaFatta(){
  vsPaginaChiudi();
  try{ flVibra([10, 30, 10]); }catch(_){ }
  try{ toast(vsPubblica() ? 'Pagina salvata: i tuoi amici la vedono nella tua Timeline' : 'Pagina salvata nel tuo diario'); }catch(_){ }
}
async function vsMediaPaint(){
  const box = document.getElementById('vspMedia'); if (!box) return;
  const p = vsPagina(VSP.idx) || { media: [] };
  const l = [];
  for (const id of (p.media || [])){
    const m = await vsMediaLeggi(id); if (!m || !m.blob) continue;
    if (!VSP.url[id]) VSP.url[id] = URL.createObjectURL(m.blob);
    l.push('<figure class="vsp-m">' + (m.tipo === 'video' ? '<video src="' + VSP.url[id] + '" muted playsinline preload="metadata"></video><i class="vsp-play" aria-hidden="true"></i>' : '<img src="' + VSP.url[id] + '" alt="">')
      + '<button type="button" class="vsp-m-via" onclick="vsMediaVia(\'' + id + '\')" aria-label="Togli">' + VS_X + '</button></figure>');
  }
  box.innerHTML = l.join('');
}
/* una foto si rimpicciolisce (lato lungo 1600 px, JPEG): resta nitida e non riempie il telefono */
function vsRimpicciolisci(file){
  return new Promise(function(ok){
    const u = URL.createObjectURL(file), img = new Image();
    img.onload = function(){
      const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(u);
      c.toBlob(function(b){ ok(b); }, 'image/jpeg', 0.82);
    };
    img.onerror = function(){ URL.revokeObjectURL(u); ok(null); };
    img.src = u;
  });
}
async function vsFileScelti(inp){
  const files = Array.prototype.slice.call((inp && inp.files) || []); if (inp) inp.value = '';
  const P = vsPagine(), k = String(VSP.idx);
  const p = P[k] || { testo: (document.getElementById('vspTesto') || {}).value || '', media: [], inizio: '', at: 0 };
  let aggiunte = 0;
  for (const f of files){
    if ((p.media || []).length >= 12){ try{ toast('In una pagina entrano al massimo 12 foto e video'); }catch(_){ } break; }
    try{
      const video = /^video\//.test(f.type);
      if (!video && !/^image\//.test(f.type)) continue;
      if (video && f.size > 30 * 1024 * 1024){ try{ toast('Questo video pesa troppo: scegline uno sotto i 30 MB'); }catch(_){ } continue; }
      const blob = video ? f : await vsRimpicciolisci(f);
      if (!blob) continue;
      const id = vsNuovoId();
      await vsMediaScrivi({ id: id, idx: VSP.idx, tipo: video ? 'video' : 'foto', mime: video ? (f.type || 'video/mp4') : 'image/jpeg', blob: blob, at: Date.now(), su: false });
      p.media = (p.media || []).concat([id]); aggiunte++;
    }catch(_){ try{ toast('Non riesco a salvare questo file sul telefono'); }catch(__){ } }
  }
  if (!p.inizio){ const d = vsDate(VSP.idx); if (d) p.inizio = vsIso(d.lun); }
  p.at = Date.now(); p.su = false; P[k] = p; vsScrivi(VS_PAGINE_K, P);
  if (aggiunte) try{ flVibra(8); }catch(_){ }
  vsMediaPaint();
}
async function vsMediaVia(id){
  const P = vsPagine(), k = String(VSP.idx), p = P[k]; if (!p) return;
  p.media = (p.media || []).filter(function(x){ return x !== id; }); p.su = false; P[k] = p; vsScrivi(VS_PAGINE_K, P);
  const m = await vsMediaLeggi(id);
  await vsMediaTogli(id);
  if (m && m.su){ try{ if (typeof frApi === 'function' && typeof frDevice === 'function') await frApi('POST', '/api/focuslock/vita/media/via', { device: frDevice(), chiave: id }); }catch(_){ } }
  if (VSP.url[id]){ try{ URL.revokeObjectURL(VSP.url[id]); }catch(_){ } delete VSP.url[id]; }
  vsMediaPaint();
}

/* ---------- leggere una pagina (la propria o quella di un amico) ---------- */
async function vsPaginaVedi(idx, pag, opz){
  opz = opz || {};
  const p = pag || vsPagina(idx); if (!p) return;
  const urls = [];
  let media = '';
  if (opz.amico){
    media = (p.media || []).map(function(m){ return '<figure class="vsp-m vsp-m-v">' + (m.tipo === 'video' ? '<video src="' + vsEsc(m.url) + '" controls playsinline preload="metadata"></video>' : '<img src="' + vsEsc(m.url) + '" alt="" loading="lazy">') + '</figure>'; }).join('');
  } else {
    for (const id of (p.media || [])){
      const m = await vsMediaLeggi(id); if (!m || !m.blob) continue;
      const u = URL.createObjectURL(m.blob); urls.push(u);
      media += '<figure class="vsp-m vsp-m-v">' + (m.tipo === 'video' ? '<video src="' + u + '" controls playsinline preload="metadata"></video>' : '<img src="' + u + '" alt="">') + '</figure>';
    }
  }
  const testo = String(p.testo || '').trim();
  const w = document.createElement('div'); w.id = 'vspVelo'; w.className = 'vsp-velo';
  w.innerHTML = '<section class="vsp vsp-leggi" role="dialog" aria-modal="true">'
    + '<div class="vsp-h"><div><small>' + vsEsc(opz.amico ? 'Il diario di ' + (opz.nome || 'un amico') : 'La pagina del diario') + '</small><b>' + (opz.post ? 'Un post' : 'La settimana ' + vsEsc(vsRange(idx, p.inizio))) + '</b></div><button type="button" class="vsp-x" onclick="vsPaginaChiudiVista()" aria-label="Chiudi">' + VS_X + '</button></div>'
    + (testo ? '<div class="vsp-t">' + testo.split(/\n{2,}/).map(function(par){ return '<p>' + vsEsc(par).replace(/\n/g, '<br>') + '</p>'; }).join('') + '</div>' : '')
    + (media ? '<div class="vsp-media vsp-media-v">' + media + '</div>' : '')
    + (opz.amico ? '' : '<button type="button" class="vsp-salva" onclick="vsPaginaChiudiVista();vsPaginaApri(' + idx + ')">Modifica la pagina</button>')
    + '</section>';
  w._urls = urls;
  w.addEventListener('click', function(e){ if (e.target === w) vsPaginaChiudiVista(); });
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('su'); });
}
function vsPaginaChiudiVista(){ const w = document.getElementById('vspVelo'); if (!w) return; (w._urls || []).forEach(function(u){ try{ URL.revokeObjectURL(u); }catch(_){ } }); w.remove(); }
function vsBack(){ if (document.getElementById('vspVelo')){ if (document.getElementById('vspTesto')) vsPaginaChiudi(); else vsPaginaChiudiVista(); return true; } return false; }

/* ===========================================================================================
   PUBBLICA: quello che va agli amici (solo se le settimane sono pubbliche)
   =========================================================================================== */
let VS_SYNC_T = 0, VS_SYNC_ON = false, VS_PIENO = false;
function vsSyncPresto(){ clearTimeout(VS_SYNC_T); VS_SYNC_T = setTimeout(function(){ vsSync().catch(function(){ }); }, 1500); }
async function vsCarica(m, dev, idx){
  try{
    const q = 'device=' + encodeURIComponent(dev) + '&chiave=' + encodeURIComponent(m.id) + '&settimana=' + idx + '&tipo=' + m.tipo + '&mime=' + encodeURIComponent(m.mime || '');
    const r = await fetch(VS_BASE + '/api/focuslock/vita/media?' + q, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: m.blob });
    if (r.status === 413){ if (!VS_PIENO){ VS_PIENO = true; try{ toast('Lo spazio delle tue settimane è pieno: le nuove foto restano sul telefono'); }catch(_){ } } return false; }
    return r.ok;
  }catch(_){ return false; }
}
async function vsSync(){
  if (VS_SYNC_ON || typeof frApi !== 'function' || typeof frDevice !== 'function') return;
  const dev = frDevice(); if (!dev) return;
  VS_SYNC_ON = true;
  try{
    const c = (typeof mmConti === 'function') ? mmConti() : null;
    const pub = vsPubblica();
    await frApi('POST', '/api/focuslock/vita/stato', { device: dev, vissute: c ? c.vissute : 0, anni: (typeof mmAnni === 'function') ? mmAnni() : 80, pubblica: pub });
    if (!pub) return;
    const P = vsPagine();
    for (const k of Object.keys(P)){
      const p = P[k]; if (!p || p.su) continue;
      let tutti = true;
      for (const id of (p.media || [])){
        const m = await vsMediaLeggi(id); if (!m || m.su) continue;
        if (await vsCarica(m, dev, +k)){ m.su = true; await vsMediaScrivi(m); } else tutti = false;
      }
      await frApi('POST', '/api/focuslock/vita/pagina', vsPaginaPiena(p) ? { device: dev, settimana: +k, inizio: p.inizio || '', testo: p.testo || '', media: p.media || [] } : { device: dev, settimana: +k, via: true });
      if (tutti){ const P2 = vsPagine(); if (P2[k] && P2[k].at === p.at){ P2[k].su = true; vsScrivi(VS_PAGINE_K, P2); } }
    }
  }catch(_){ }
  finally{ VS_SYNC_ON = false; }
}
async function vsPubblicaSet(on){
  try{ localStorage.setItem(VS_PUB_K, on ? '1' : '0'); }catch(_){ }
  if (on){ const P = vsPagine(); Object.keys(P).forEach(function(k){ P[k].su = false; }); vsScrivi(VS_PAGINE_K, P); }
  try{ toast(on ? 'Settimane pubbliche: i tuoi amici le aprono dalla tua Timeline' : 'Settimane private: le vedi solo tu'); }catch(_){ }
  try{ if (typeof mmPaint === 'function') mmPaint(); }catch(_){ }
  vsSync().catch(function(){ });
}

/* ===========================================================================================
   NELLA TIMELINE DEL PROFILO: le settimane blu hanno una pagina, e si toccano
   =========================================================================================== */
function vsGeoCanvas(cv, anni){
  /* le stesse misure di mmDisegna, alla larghezza vera della tela */
  const W = parseFloat(cv.style.width) || cv.clientWidth || 300;
  const lab = 26, gapB = 5, gapBanda = 7, passo = (W - lab - gapB * 3) / 52;
  return { W: W, lab: lab, gapB: gapB, gapBanda: gapBanda, passo: passo, lato: Math.max(1.5, passo * 0.72), anni: anni };
}
function vsVicina(g, x, y, set){
  let meglio = -1, d0 = Infinity;
  set.forEach(function(i){ const p = vsPos(g, i), d = Math.hypot(p.x + g.lato / 2 - x, p.y + g.lato / 2 - y); if (d < d0){ d0 = d; meglio = i; } });
  return d0 <= Math.max(14, g.passo * 2.5) ? meglio : -1;
}
function vsTocca(e, cv, set, apri){
  const r = cv.getBoundingClientRect(), anni = (typeof mmAnni === 'function') ? mmAnni() : 80;
  const g = vsGeoCanvas(cv, anni);
  const k = (parseFloat(cv.style.width) || r.width) / (r.width || 1);
  const i = vsVicina(g, (e.clientX - r.left) * k, (e.clientY - r.top) * k, set);
  if (i >= 0){ try{ flVibra(6); }catch(_){ } apri(i); }
}
function vsTimelineHtml(){
  const pub = vsPubblica();
  return '<div class="blk-swrow vs-tl-pub"><div><b>Settimane pubbliche</b><small>I tuoi amici possono aprire le tue pagine dalla tua Timeline.</small></div>'
    + '<button type="button" class="switch' + (pub ? ' on' : '') + '" onclick="vsPubblicaSet(' + (pub ? 'false' : 'true') + ')" aria-label="Settimane pubbliche"></button></div>';
}
(function(){
  if (typeof document === 'undefined') return;
  /* mmPaint (memento.js): le settimane con la pagina in blu, il tocco, e nella Timeline del profilo l'interruttore */
  setTimeout(function(){
    try{
      if (typeof mmPaint !== 'function' || mmPaint.__vs) return;
      const vero = mmPaint;
      const nuovo = function(){
        const r = vero.apply(this, arguments);
        try{
          const host = document.getElementById(typeof MM_HOST !== 'undefined' ? MM_HOST : 'mmBody');
          const cv = host && host.querySelector('#mmCanvas');
          if (cv && !cv.__vs){
            cv.__vs = true;
            /* 0.9.319: una settimana con la pagina si legge; una settimana passata senza pagina si scrive, e diventa blu */
            cv.addEventListener('click', function(e){
              const pag = vsPagineSet();
              const c1 = (typeof mmConti === 'function') ? mmConti() : null, tutte = new Set(pag);
              if (c1) for (let n = 0; n < c1.vissute; n++) tutte.add(n);
              vsTocca(e, cv, tutte, function(i){ if (pag.has(i)) vsPaginaVedi(i); else vsPaginaApri(i); });
            });
          }
        }catch(_){ }
        return r;
      };
      nuovo.__vs = true; window.mmPaint = nuovo; try{ mmPaint = nuovo; }catch(_){ }
    }catch(_){ }
  }, 900);
  /* all'avvio e al ritorno nell'app: quello che non e' ancora arrivato agli amici */
  setTimeout(function(){ if (vsPubblica()) vsSync().catch(function(){ }); }, 15000);
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && vsPubblica()) vsSyncPresto(); });
})();

/* ===========================================================================================
   LA VITA DI UN AMICO IN SETTIMANE (dalla sua scheda, fra gli amici)
   =========================================================================================== */
/* 0.9.322, Andrea: "Apri il suo profilo", con le stesse quattro schede del tuo. About: la sua settimana. Story: il diario, se lo tiene aperto.
   Media: i post che ha scelto di far vedere. Timeline: la sua vita in settimane, con le pagine pubbliche. */
if (typeof registerScreen === 'function') registerScreen('s-profilo-amico',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + VS_INDIETRO + '</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Profilo</b></div>'
  + '<div class="acc-av" id="vsaAv"></div><h2 class="acc-nome" id="vsaNome"></h2><p class="acc-pub-liv" id="vsaLiv"></p>'
  + '<div class="acc-top3" id="vsaTop"></div><div class="acc-tabs" id="vsaTabs"></div><div id="vsaBody" class="acc-tabbody"></div><div class="spacer"></div>');
const VSAM = { dati: null, nome: '', device: '', tab: 'about', post: [], gia: false, diario: null };
function vsaAmico(){ try{ return ((FR.amici && FR.amici.amici) || []).filter(function(x){ return x.device === VSAM.device; })[0] || {}; }catch(_){ return {}; } }
function frProfiloApri(device, nome){
  Object.assign(VSAM, { dati: null, nome: nome || '', device: device, tab: 'about', post: [], gia: false, diario: null });
  goId('s-profilo-amico');
  const a = vsaAmico(), av = document.getElementById('vsaAv'), nn = document.getElementById('vsaNome'), lv = document.getElementById('vsaLiv'), t3 = document.getElementById('vsaTop');
  if (av) av.innerHTML = frAv(nome, device, 'lg');
  if (nn) nn.textContent = nome || '';
  if (lv) lv.textContent = 'Livello ' + (a.level || 1) + (a.online ? ' · 🟢 online' : '');
  const lega = a.tier && FR_TIER[a.tier] ? amT('lega.tier.' + a.tier) : 'Fuori lega';
  if (t3) t3.innerHTML = '<div class="acc-forest">' + accStat('🔥 ' + (a.streak || 0), 'Serie', 'I giorni di fila in cui ha fatto la sua parte.') + '<i class="sep"></i>' + accStat(frOre(a.ffMin7), 'Full Focus', 'Il tempo in Full Focus negli ultimi 7 giorni.') + '<i class="sep"></i>' + accStat(lega, 'Lega', 'La lega in cui gioca questa settimana.') + '</div>';
  vsaPaint();
}
function vsaScheda(k){ VSAM.tab = k; try{ flVibra(8); }catch(_){ } vsaPaint(); }
function vsaVuoto(e, t, p){ return '<div class="acc-vuoto"><span>' + e + '</span><b>' + vsEsc(t) + '</b><p>' + vsEsc(p) + '</p></div>'; }
function vsaPaint(){
  const tabs = document.getElementById('vsaTabs'), body = document.getElementById('vsaBody'); if (!tabs || !body) return;
  tabs.innerHTML = ACC_TABS.map(function(t){ return '<button type="button" class="' + (VSAM.tab === t[0] ? 'on' : '') + '" onclick="vsaScheda(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('');
  const nome = VSAM.nome || 'Questa persona';
  if (VSAM.tab === 'about'){
    const a = vsaAmico(), m = FR_METRICHE.map(function(k){ const v = (typeof frMetVal === 'function') ? frMetVal(a.metriche, k, 'settimana') : null; return v === null || v === undefined ? '' : '<div><span>' + FR_MET_ICO[k] + '</span><b>' + vsEsc(frMetFmt(k, v)) + '</b><small>' + vsEsc(amT('amici.classifica.metriche.' + k)) + '</small></div>'; }).join('');
    body.innerHTML = '<div class="acc-ab-sez"><div class="sect acc-sect"><b>La partita di questa settimana</b></div><div class="vsa-partita"><div><b>' + (a.neo || 0) + '</b><small>' + vsEsc(amT('amici.riga.nuovoSe')) + '</small></div><i>-</i><div><b>' + (a.old || 0) + '</b><small>' + vsEsc(amT('amici.riga.vecchioSe')) + '</small></div></div></div>'
      + (m ? '<div class="acc-ab-sez"><div class="sect acc-sect"><b>Questa settimana</b></div><div class="vsa-met">' + m + '</div></div>' : '');
    return;
  }
  if (VSAM.tab === 'story'){
    if (VSAM.diario === null){ body.innerHTML = '<p class="vs-tl-nota">Apro il suo diario…</p>'; vsaDiario(); return; }
    if (!VSAM.diario.ok){ body.innerHTML = vsaVuoto('📔', 'Non riesco ad aprirlo adesso', 'Controlla la connessione e riprova.'); return; }
    if (!VSAM.diario.pubblico){ body.innerHTML = vsaVuoto('🔒', 'Diario privato', nome + ' tiene il diario per sé.'); return; }
    body.innerHTML = '<button type="button" class="acc-story" onclick="dvApriDi(' + vsEsc(JSON.stringify(VSAM.device)) + ',' + vsEsc(JSON.stringify(VSAM.nome)) + ')"><span class="acc-story-cov">📔</span><div><b>Il diario di viaggio</b><small>' + VSAM.diario.n + (VSAM.diario.n === 1 ? ' pagina' : ' pagine') + ' · tocca per sfogliarlo</small></div><span class="chev"></span></button>';
    return;
  }
  if (!VSAM.gia){ body.innerHTML = '<p class="vs-tl-nota">Un momento…</p>'; vsaVita(); return; }
  const r = VSAM.dati;
  if (!r){ body.innerHTML = vsaVuoto('📅', 'Non riesco ad aprirle adesso', 'Controlla la connessione e riprova.'); return; }
  if (!r.pubblica){ body.innerHTML = VSAM.tab === 'media' ? vsaVuoto('🔒', 'Niente da vedere', nome + ' non ha scelto di far vedere i suoi post.') : vsaVuoto('🔒', 'Settimane private', nome + ' tiene le sue settimane per sé.'); return; }
  const pagine = new Map((r.pagine || []).filter(function(p){ return +p.settimana < AP_SLOT; }).map(function(p){ return [+p.settimana, p]; }));
  if (VSAM.tab === 'media'){
    const posts = VSAM.post;
    body.innerHTML = posts.length ? '<div class="acc-post-griglia">' + posts.map(function(p, i){ const m = (p.media || [])[0]; return '<button type="button" class="acc-post" onclick="vsAmicoPost(' + i + ')">' + (m ? (m.tipo === 'video' ? '<video src="' + vsEsc(m.url) + '" muted playsinline preload="metadata"></video>' : '<img src="' + vsEsc(m.url) + '" alt="">') : '') + '</button>'; }).join('') + '</div>'
      : vsaVuoto('📷', 'Ancora nessun post', nome + ' non ha pubblicato niente per ora.');
    return;
  }
  body.innerHTML = '<div class="mm-griglia"><canvas id="vsAmicoCv"></canvas></div><p class="vs-tl-nota">' + (pagine.size ? 'Le settimane blu hanno una pagina del diario: toccale per leggerla.' : 'Non ha ancora scritto pagine delle sue settimane.') + '</p>';
  const cv = document.getElementById('vsAmicoCv');
  const anni = +r.anni === 90 ? 90 : 80, totale = anni * 52, v = Math.min(+r.vissute || 0, totale);
  requestAnimationFrame(function(){
    if (typeof mmDisegna === 'function') mmDisegna({ vissute: v, totale: totale, restano: totale - v, pct: v / totale * 100 }, anni, { canvas: cv, pagine: new Set(pagine.keys()) });
    cv.addEventListener('click', function(e){ vsTocca(e, cv, new Set(pagine.keys()), function(i){ vsPaginaVedi(i, pagine.get(i), { amico: true, nome: VSAM.nome }); }); });
  });
}
async function vsaDiario(){
  const dev = VSAM.device;
  let esito = { ok: false };
  try{ const r = await frApi('GET', '/api/focuslock/social/diario?device=' + encodeURIComponent(frDevice()) + '&of=' + encodeURIComponent(dev)); if (r) esito = { ok: true, pubblico: !!r.pubblico, n: (r.pagine || []).length }; }catch(_){ }
  if (dev !== VSAM.device) return;
  VSAM.diario = esito; vsaPaint();
}
async function vsaVita(){
  const dev = VSAM.device;
  let r = null;
  try{ r = await frApi('GET', '/api/focuslock/vita?device=' + encodeURIComponent(frDevice()) + '&of=' + encodeURIComponent(dev)); }catch(_){ r = null; }
  if (dev !== VSAM.device) return;
  VSAM.gia = true; VSAM.dati = r;
  VSAM.post = ((r && r.pagine) || []).filter(function(p){ return +p.settimana >= AP_SLOT; }).sort(function(a, b){ return b.settimana - a.settimana; });
  vsaPaint();
}

function vsAmicoPost(i){ const p = VSAM.post && VSAM.post[i]; if (p) vsPaginaVedi(p.settimana, p, { amico: true, nome: VSAM.nome, post: true }); }
/* L'ANTEPRIMA NEL PROFILO PUBBLICO ("cosi' ti vedono gli amici"): la tua vita in settimane, con le pagine pubbliche */
function vsAnteprimaHtml(){
  const c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!c) return '<div class="acc-vuoto"><span>📅</span><b>Manca la data di nascita</b><p>Scrivila nella scheda Timeline del tuo profilo.</p></div>';
  if (!vsPubblica()) return '<div class="acc-vuoto"><span>🔒</span><b>Settimane private</b><p>Gli amici non le vedono. Le rendi pubbliche dalla scheda Timeline del tuo profilo.</p></div>';
  return '<div class="mm-griglia"><canvas id="vsPubCv"></canvas></div><p class="vs-tl-nota">Gli amici toccano le settimane blu e leggono la pagina di quella settimana.</p>';
}
function vsAnteprimaDisegna(){
  const cv = document.getElementById('vsPubCv'), c = (typeof mmConti === 'function') ? mmConti() : null;
  if (!cv || !c || typeof mmDisegna !== 'function') return;
  const set = vsPagineSet();
  requestAnimationFrame(function(){
    mmDisegna(c, (typeof mmAnni === 'function') ? mmAnni() : 80, { canvas: cv, pagine: set });
    if (!cv.__vs){ cv.__vs = true; cv.addEventListener('click', function(e){ vsTocca(e, cv, vsPagineSet(), function(i){ vsPaginaVedi(i); }); }); }
  });
}

/* ---------- lo stile ---------- */
(function(){
  if (typeof document === 'undefined') return;
  const css = [
    '.vsa-partita{display:flex;align-items:center;justify-content:center;gap:22px;padding:16px;border-radius:18px;background:#E3F1FF;text-align:center}body.dark .vsa-partita{background:#12203A}.vsa-partita b{display:block;font:900 34px/1 var(--font-display);color:#0075E3}body.dark .vsa-partita b{color:#8CC6FF}.vsa-partita small{display:block;margin-top:5px;font:700 12.5px var(--font-body);color:var(--muted)}.vsa-partita i{font:800 24px var(--font-display);font-style:normal;color:var(--muted)}',
    '.vsa-met{display:grid;grid-template-columns:1fr 1fr;gap:10px}.vsa-met > div{padding:14px 10px;border:1.5px solid var(--line);border-radius:16px;text-align:center}.vsa-met span{display:block;font-size:22px}.vsa-met b{display:block;margin-top:4px;font:800 17px var(--font-display);color:var(--navy)}body.dark .vsa-met b{color:#fff}.vsa-met small{display:block;margin-top:2px;font:600 12px var(--font-body);color:var(--muted)}',
    /* nel report (sfondo blu notte): il titolo, la carta del calendario, i segni */
    '.vs{width:100%;display:flex;flex-direction:column;align-items:center}',
    '.vs-tit{margin:0 0 12px;font:800 24px/1.2 var(--font-display,var(--font-body));color:#fff;text-align:center}',
    '.vs-sotto{margin:16px 0 0;font:700 15px/1.4 var(--font-body);color:#fff;text-align:center;opacity:.92}',
    '.vs-istr:empty{display:none}.vs-istr{margin:0 0 10px;max-width:22em;font:600 14px/1.45 var(--font-body);color:rgba(200,218,242,.86);text-align:center;transition:opacity .35s}.vs-istr.via{opacity:0}',
    '.vs-carta{display:block;box-sizing:border-box;width:100%;padding:8px;border-radius:16px;background:#FBF7F2;box-shadow:0 10px 30px rgba(0,0,0,.35)}',
    '.vs-vista{position:relative;width:100%;overflow:hidden;border-radius:10px;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.vs-vista canvas{display:block}',
    '.vs-segni{position:absolute;inset:0;pointer-events:none}',
    '.vs-penna{position:absolute;left:0;top:0;width:46px;height:46px;filter:drop-shadow(0 6px 8px rgba(0,0,0,.28));transition:opacity .2s}',
    '.vs-et{position:absolute;transform:translate(-50%,-100%);opacity:0;transition:opacity .3s ease,transform .3s cubic-bezier(.2,.8,.2,1)}',
    '.vs-et.su{transform:translate(-50%,calc(-100% - 6px))}.vs-et.giu{transform:translate(-50%,6px)}',
    '.vs-et.in{opacity:1}.vs-et.in.via{opacity:0;transition:opacity .3s ease}',
    '.vs-et span{display:block;white-space:nowrap;padding:5px 10px;border-radius:99px;font:800 12px var(--font-body);color:#fff;box-shadow:0 4px 12px rgba(0,0,0,.25)}',
    '.vs-qui span{background:#E63946}.vs-arrivo span{background:#0075E3}',
    '.vs-et.su span::after,.vs-et.giu span::before{content:"";position:absolute;left:calc(50% + var(--coda,0px));width:0;height:0;border:6px solid transparent;transform:translateX(-50%)}',
    /* 0.9.308: il fumetto sopra alla griglia, blu o rosso pieno, sempre leggibile */
    '.vs-et{z-index:2}.vs-et span{position:relative}',
    '.vs-et.su span::after{top:100%;margin-top:-1px}.vs-et.giu span::before{bottom:100%;margin-bottom:-1px}',
    '.vs-qui.su span::after{border-top-color:#E63946}.vs-qui.giu span::before{border-bottom-color:#E63946}',
    '.vs-arrivo.su span::after{border-top-color:#0075E3}.vs-arrivo.giu span::before{border-bottom-color:#0075E3}',
    /* la legenda: una riga centrata, ogni voce intera su una riga sola */
    '.vs-leg{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:8px 20px;margin:14px 0 0;font:700 13.5px var(--font-body);color:#fff}',
    '.vs-leg span{display:inline-flex;align-items:center;gap:8px;white-space:nowrap}.vs-leg svg{flex:none;display:block}',
    '.vs-leg-ora{display:block;flex:none;width:11px;height:11px;border-radius:2px;background:#E63946}',
    '.vs-leg-report{opacity:0;transition:opacity .45s ease}.vs-leg-report.in{opacity:1}',
    /* 0.9.308: dentro la carta del calendario (sempre chiara, anche al buio): testo d'inchiostro */
    '.vs-carta .vs-leg-report{margin:10px 4px 4px;color:#2A1F1D;font-size:13px}',
    '.vs-dopo{margin:16px 0 0;max-width:24em;font:600 14.5px/1.5 var(--font-body);color:rgba(220,232,250,.9);text-align:center;opacity:0;transition:opacity .5s}.vs-dopo.in{opacity:1}',
    '.vs-azioni{width:100%;max-width:420px;display:flex;flex-direction:column;gap:12px;margin-top:24px;opacity:0;transform:translateY(10px);transition:opacity .5s ease .15s,transform .5s ease .15s}.vs-azioni.in{opacity:1;transform:none}',
    '.vs-b1{width:100%;padding:15px 18px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 6px 18px rgba(0,117,227,.35)}',
    '.vs-b2{display:flex;align-items:center;justify-content:center;gap:9px;width:100%;padding:13px 18px;border:1.5px solid rgba(200,218,242,.45);border-radius:99px;background:rgba(255,255,255,.06);color:#fff;font:700 15px var(--font-body);cursor:pointer}',
    /* la pagina del diario (sopra al report): segue il tema dell'app */
    '.vsp-velo{position:fixed;inset:0;z-index:10050;background:rgba(5,14,34,.55);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .2s}',
    '.vsp-velo.su{opacity:1}',
    '.vsp{width:100%;max-width:560px;max-height:92vh;overflow-y:auto;box-sizing:border-box;padding:18px 18px calc(22px + env(safe-area-inset-bottom,0px));border-radius:24px 24px 0 0;background:var(--card,#fff);color:var(--navy,#14234A);transform:translateY(30px);transition:transform .25s cubic-bezier(.2,.8,.2,1)}',
    '.vsp-velo.su .vsp{transform:none}',
    '.vsp-h{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}',
    '.vsp-h small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3;margin-bottom:4px}',
    '.vsp-h b{display:block;font:800 19px/1.25 var(--font-display,var(--font-body));color:var(--navy,#14234A)}',
    '.vsp-x{flex:none;width:38px;height:38px;border-radius:50%;border:1px solid var(--line,#E5ECF6);background:var(--bg,#F4F7FB);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.vsp-testo{width:100%;box-sizing:border-box;min-height:140px;padding:14px;border:1.5px solid var(--line,#E5ECF6);border-radius:16px;background:var(--bg,#F4F7FB);color:var(--navy,#14234A);font:500 16px/1.55 var(--font-body);resize:vertical;outline:none}',
    '.vsp-testo:focus{border-color:#0075E3}',
    '.vsp-media{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}.vsp-media:empty{display:none}',
    '.vsp-m{position:relative;margin:0;aspect-ratio:1;border-radius:12px;overflow:hidden;background:var(--bg,#F4F7FB)}',
    '.vsp-m img,.vsp-m video{width:100%;height:100%;object-fit:cover;display:block}',
    '.vsp-play{position:absolute;left:50%;top:50%;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;background:rgba(0,30,68,.6)}.vsp-play::after{content:"";position:absolute;left:13px;top:10px;border:7px solid transparent;border-left:11px solid #fff;border-right:0}',
    '.vsp-m-via{position:absolute;right:5px;top:5px;width:28px;height:28px;border-radius:50%;border:0;background:rgba(0,30,68,.65);color:#fff;display:flex;align-items:center;justify-content:center;padding:0;cursor:pointer}.vsp-m-via svg{width:16px;height:16px}',
    '.vsp-agg{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin-top:12px;padding:13px;border:1.5px dashed rgba(0,117,227,.5);border-radius:16px;background:transparent;color:#0075E3;font:700 15px var(--font-body);cursor:pointer}',
    '.vsp-nota{margin:12px 2px 0;font:500 13px/1.45 var(--font-body);color:var(--muted,#6B7A90);text-align:center}',
    '.vsp-salva{width:100%;margin-top:14px;padding:15px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.vsp-t p{margin:0 0 12px;font:500 16px/1.6 var(--font-body);color:var(--navy,#14234A)}',
    '.vsp-media-v{grid-template-columns:1fr}.vsp-m-v{aspect-ratio:auto}.vsp-m-v img,.vsp-m-v video{height:auto;max-height:70vh;object-fit:contain;background:#000}',
    'body.dark .vsp{background:#101C33;color:#fff}body.dark .vsp-h b,body.dark .vsp-t p{color:#fff}body.dark .vsp-x{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.16);color:#fff}',
    'body.dark .vsp-testo{background:#0B1528;border-color:#22345A;color:#fff}body.dark .vsp-m{background:#0B1528}body.dark .vsp-agg{color:#7DBEFF;border-color:rgba(125,190,255,.5)}',
    /* la Timeline del profilo e la pagina dell'amico */
    '.vs-tl-nota{margin:12px 4px 0;font:600 13px/1.45 var(--font-body);color:var(--muted,#6B7A90);text-align:center}',
    '.vs-tl-pub{margin:0 0 18px}.vs-post-t{margin:28px 0 12px;font:800 18px var(--font-display);color:var(--navy);text-align:center}body.dark .vs-post-t{color:#fff}',
    '.vs-amico{padding-top:6px}',
    '#mmCanvas,#vsAmicoCv{cursor:pointer}'
  ].join('\n');
  const s = document.createElement('style'); s.id = 'vs-style'; s.textContent = css; document.head.appendChild(s);
})();
