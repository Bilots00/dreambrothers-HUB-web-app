/* ===========================================================================================
   PORTA LA TUA MEMORIA DA UN'ALTRA AI (0.9.289, Andrea)

   "Prima di mandare il messaggio al mio agente per creare la roadmap su misura, voglio poter importare
   la memoria da un'altra intelligenza artificiale, come fanno Gemini e Claude: chi usa gia' ChatGPT o
   Gemini non deve rispiegare tutto da capo, e risponde a meno domande. E il messaggio per l'agente
   deve essere gia' scritto, ma partire solo quando premo invio."

   Il giro, dopo la strada e i pedaggi (sentiero-mappa.js -> mdStradaScegli -> ivApri):
   1. una pagina con due scelte: "Importa la memoria da un'altra AI" o "Rispondo alle domande";
   2. importare: si copia il messaggio (strutturato come quello di Gemini), lo si incolla nell'altra AI,
      si incolla qui la risposta. Diventa un documento di riferimento del tuo agente personale (riferimenti.js,
      fl_rif_agente): l'agente lo legge in ogni messaggio;
   3. in tutti e due i casi si apre la chat del piano con il messaggio gia' scritto nella casella:
      parte solo quando lo mandi tu.
   =========================================================================================== */
const IMEM_PROMPT = [
  'Mi stai aiutando a portare il contesto da un assistente AI a un altro. Il tuo compito è ripercorrere le nostre conversazioni passate e riassumere quello che sai di me.',
  '',
  'Nella risposta non usare pronomi di prima persona (io, mio, me) né di seconda persona (tu, tuo). Chiama la persona di cui hai imparato le cose "l’utente", oppure usa frasi neutre.',
  '',
  'Riporta le parole dell’utente alla lettera dove possibile, soprattutto per istruzioni e preferenze.',
  '',
  'Categorie (in quest’ordine):',
  '1. Dati personali: nomi preferiti, professione, studi, zona in cui vive.',
  '2. Obiettivi e sogni: cosa vuole ottenere, entro quando, e perché conta per l’utente.',
  '3. Progetti: un elemento per progetto, con cosa fa, a che punto è e le decisioni già prese.',
  '4. Tempo e abitudini: quante ore ha davvero ogni settimana e in quali momenti, le routine, cosa lo distrae, cosa lo ha fatto mollare le altre volte.',
  '5. Interessi e preferenze: impegni costanti e attivi (non un acquisto fatto una volta).',
  '6. Relazioni: relazioni confermate e durature.',
  '7. Eventi, progetti e piani con una data: un registro delle attività recenti importanti.',
  '8. Istruzioni: le regole che l’utente ti ha chiesto di seguire ("fai sempre X", "non fare mai Y") e le correzioni al tuo comportamento. Solo regole salvate in memoria, non dalle conversazioni.',
  '',
  'Formato:',
  'Dividi il contenuto in sezioni con i titoli delle categorie qui sopra. Per ogni elemento aggiungi, se puoi, la frase dell’utente che lo dimostra. Scrivi ogni elemento così:',
  '* Il nome dell’utente è <nome>.',
  '    * Prova: l’utente ha scritto "chiamami <nome>". Data: [AAAA-MM-GG].',
  '',
  'Risposta:',
  '- Scrivi SOLO le informazioni richieste: niente introduzioni, commenti o saluti.',
  '',
  'Alla fine completa la frase "Importato da: <nome>", dove il nome è ChatGPT, Claude, Gemini, Grok o l’assistente che sei. Deve essere l’ultimo testo della risposta.'
].join('\n');
const IMEM = { poi: null };

registerScreen('s-imem',
  '<div class="topbar"><button class="iconbtn" onclick="imemIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">Il tuo piano su misura</b></div>'
  + '<div class="imem" id="imemBody"></div>', { back: function(){ imemIndietro(); return null; } });

function imemEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function imemGia(){ try{ return (typeof rfLista === 'function' ? rfLista('agente') : []).some(function(x){ return x && x.memoriaAi; }); }catch(_){ return false; } }

/** Il primo passo del piano su misura: importare la memoria, o rispondere alle domande. poi(importata) apre la chat. */
function imemApri(poi){
  IMEM.poi = poi || null;
  goId('s-imem'); imemPasso1();
}
function imemIndietro(){
  const corpo = document.getElementById('imemBody');
  if (corpo && corpo.dataset.passo === '2'){ imemPasso1(); return; }
  goId('s-home'); try{ if (typeof switchTab === 'function') switchTab('mappa'); }catch(_){ }
}
function imemPasso1(){
  const h = document.getElementById('imemBody'); if (!h) return;
  h.dataset.passo = '1';
  h.innerHTML = '<h2 class="imem-h">Il tuo agente personale può già conoscerti</h2>'
    + '<p class="imem-p">Se usi ChatGPT, Gemini, Claude o un’altra AI, porta qui quello che sa di te. Il tuo agente personale ti farà meno domande.</p>'
    + '<button type="button" class="imem-c on" onclick="imemPasso2()"><span class="imem-i">' + IMEM_ICO.importa + '</span><div><b>Importa la memoria da un’altra AI</b><small>Copi un messaggio, lo incolli nella tua AI e porti qui la risposta.</small></div></button>'
    + '<button type="button" class="imem-c" onclick="imemVai(false)"><span class="imem-i">' + IMEM_ICO.domande + '</span><div><b>Rispondo alle domande del mio agente</b><small>Ti fa qualche domanda, una alla volta, poi ti propone il piano.</small></div></button>'
    + (imemGia() ? '<p class="imem-nota">Hai già importato una memoria: il tuo agente personale la usa. Puoi importarne un’altra.</p>' : '');
}
function imemPasso2(){
  const h = document.getElementById('imemBody'); if (!h) return;
  h.dataset.passo = '2';
  h.innerHTML = '<h2 class="imem-h">Porta qui la tua memoria</h2>'
    + '<div class="imem-n"><span>1</span><div><b>Copia questo messaggio e mandalo alla tua AI</b>'
    +   '<div class="imem-prompt" id="imemPrompt">' + imemEsc(IMEM_PROMPT).replace(/\n/g, '<br>') + '</div>'
    +   '<button type="button" class="imem-copia" onclick="imemCopia()">' + IMEM_ICO.copia + '<span>Copia il messaggio</span></button></div></div>'
    + '<div class="imem-n"><span>2</span><div><b>Incolla qui la risposta</b>'
    +   '<textarea class="imem-area" id="imemRisp" rows="6" data-no-mic placeholder="Incolla qui la risposta della tua AI"></textarea></div></div>'
    + '<button type="button" class="cta imem-cta" onclick="imemImporta()">Importa la memoria</button>';
}
async function imemCopia(){
  const ok = function(){ try{ toast('Messaggio copiato: incollalo nella tua AI'); flVibra(10); }catch(_){ } };
  try{ await navigator.clipboard.writeText(IMEM_PROMPT); ok(); return; }catch(_){ }
  try{
    const t = document.createElement('textarea'); t.value = IMEM_PROMPT; t.setAttribute('data-no-mic', ''); t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.appendChild(t); t.select(); const r = document.execCommand('copy'); t.remove();
    if (r) ok(); else toast('Tieni premuto sul messaggio per copiarlo');
  }catch(_){ toast('Tieni premuto sul messaggio per copiarlo'); }
}
function imemImporta(){
  const a = document.getElementById('imemRisp');
  let t = String(a ? a.value : '').replace(/\r\n/g, '\n').trim();
  if (t.length < 40){ toast('Incolla la risposta della tua AI'); return; }
  const m = t.match(/(?:importato da|imported from)\s*:\s*([^\n]+)\s*$/i);
  const da = m ? m[1].trim().slice(0, 40) : 'un’altra AI';
  if (t.length > 20000) t = t.slice(0, 20000) + '\n…';
  /* la memoria e' un documento di riferimento del tuo agente personale: la legge in ogni messaggio (agente.js, agBrief) */
  const l = (typeof rfLista === 'function') ? rfLista('agente').filter(function(x){ return !(x && x.memoriaAi); }) : [];
  l.push({ id: 'rf' + Date.now().toString(36), nome: 'La mia memoria da ' + da + '.md', tipo: 'testo', testo: t, at: Date.now(), memoriaAi: true, da: da });
  if (typeof rfSalva === 'function' && !rfSalva('agente', l)) return;
  try{ if (typeof rfRipaint === 'function') rfRipaint('agente'); }catch(_){ }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Memoria importata da ' + da);
  imemVai(true, da);
}
function imemVai(importata, da){
  const f = IMEM.poi; IMEM.poi = null;
  if (typeof f === 'function') f({ importata: !!importata, da: da || '' });
}

const IMEM_ICO = {
  importa: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>',
  domande: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12z"/></svg>',
  copia: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>'
};

(function(){
  if (typeof document === 'undefined') return;
  const st = document.createElement('style');
  st.textContent = [
    '.imem{padding:8px 20px 40px}',
    '.imem-h{margin:8px 0 10px;font:800 25px/1.25 var(--font-display,var(--font-body));color:var(--navy)}',
    '.imem-p{margin:0 0 24px;font:500 16px/1.55 var(--font-body);color:var(--muted)}',
    '.imem-c{display:flex;align-items:center;gap:14px;width:100%;margin:0 0 12px;padding:18px 16px;border-radius:18px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);text-align:left;cursor:pointer;font:inherit}',
    '.imem-c.on{border-color:#0075E3;background:#EEF6FF}.imem-c > div{flex:1;min-width:0}',
    '.imem-c b{display:block;font:800 16px var(--font-body);color:var(--navy)}.imem-c small{display:block;margin-top:4px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}',
    '.imem-i{flex:none;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:#E3F1FF;color:#0075E3}',
    '.imem-nota{margin:14px 0 0;font:600 13.5px/1.45 var(--font-body);color:#0B7A55}',
    '.imem-n{display:flex;gap:12px;margin:0 0 22px}.imem-n > span{flex:none;width:28px;height:28px;border-radius:50%;background:#0075E3;color:#fff;display:grid;place-items:center;font:800 14px var(--font-body)}.imem-n > div{flex:1;min-width:0}',
    '.imem-n b{display:block;margin:3px 0 10px;font:800 15.5px var(--font-body);color:var(--navy)}',
    '.imem-prompt{max-height:150px;overflow:auto;padding:12px 14px;border-radius:14px;background:var(--bg,#F4F9FF);border:1.5px solid var(--line,#DCE8F5);font:500 13px/1.5 var(--font-body);color:var(--ink);-webkit-user-select:text;user-select:text}',
    '.imem-copia{display:inline-flex;align-items:center;gap:8px;margin-top:10px;padding:10px 16px;border-radius:999px;border:0;background:#0075E3;color:#fff;font:800 14px var(--font-body);cursor:pointer}',
    '.imem-area{display:block;width:100%;box-sizing:border-box;padding:14px;border-radius:14px;border:1.5px solid var(--line,#DCE8F5);background:var(--bg,#F4F9FF);color:var(--ink);font:500 15px/1.5 var(--font-body)}',
    '.imem-cta{width:100%;margin-top:6px}',
    'body.dark .imem-h,body.dark .imem-c b,body.dark .imem-n b{color:#fff}body.dark .imem-c{background:#12203A;border-color:#22345A}body.dark .imem-c.on{background:#0E2B57;border-color:#3F9FF4}body.dark .imem-i{background:#16305A;color:#BCE0FF}'
  ].join('\n');
  document.head.appendChild(st);
})();
