/* ===========================================================================================
   JORDAN — l'arbitro che non sta dentro al telefono

   PERCHÉ SERVE UNO DI FUORI. Il motore che gira qui dentro (previsione.js) è piccolo per
   scelta: pesa delle prove, misura quanto si sbaglia, si corregge. Quello che NON sa fare è
   leggere una giornata intera e dire cosa è successo — «hai mollato la sessione delle 21:35
   undici minuti dopo aver aperto YouTube, ed è la terza volta questa settimana che succede
   dopo cena». Quella è una frase che richiede un modello grande, e un modello grande sul
   telefono non ci sta e non ci deve stare.

   Jordan sta sul VPS di Andrea, è operativo ventiquattro ore su ventiquattro, ed è già il
   revisore del piano della sera. Qui diventa anche l'arbitro della partita: guarda le stesse
   cifre che vede l'utente e assegna i punti fra il vecchio te e il nuovo te.

   COME PARLANO, e perché in questo verso. Il telefono deposita quello che ha osservato in una
   riga del suo archivio (`fl:agent-in`); Jordan la legge quando vuole e deposita il verdetto in
   un'altra riga (`fl:jordan`); il telefono la rilegge. Nessuno chiama nessuno: è lo stesso
   schema con cui il mastermind e l'agente Claude parlano già con questa applicazione — il VPS
   fa polling, il server non bussa mai a una porta di casa.

   COSA JORDAN NON PUÒ FARE, e non è una dimenticanza. Non può cambiare una regola, togliere un
   blocco, spegnere la modalità severa. Deposita un'opinione; è l'app a decidere se mostrarla.
   Un agente che potesse aprire i muri che l'utente si è messo sarebbe esattamente la cosa da
   cui l'utente si stava proteggendo.

   COSA VIAGGIA: numeri e frasi già riassunte, mai la cronologia al granello. A un arbitro serve
   sapere che il blocco è stato interrotto alle 21:47, non ogni schermata toccata in tredici ore.
   =========================================================================================== */

const JD_IN = 'fl:agent-in';
const JD_OUT = 'fl:jordan';
const JD_KEY = 'fl_jordan';

/* Ogni quanto ha senso depositare. Una volta ogni sei ore: la giornata cambia lentamente, e
   una riga riscritta ogni minuto farebbe solo credere a Jordan che ci sia qualcosa di nuovo. */
const JD_OGNI_MS = 6 * 3600000;

function jdPuo(){
  try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; }
}

function jdCache(){
  try{ return JSON.parse(localStorage.getItem(JD_KEY) || 'null'); }catch(_){ return null; }
}

/* ---------------------------------------------------------------------------------------
   CHI CE L'HA

   La risposta arriva dal server, con il token dell'utente, ed e' un si' o un no. Non sta
   nell'app: un elenco di email dentro a un APK si legge aprendo il pacchetto, e per cambiarlo
   servirebbe ripubblicare sullo store. Cosi' invece, il giorno in cui l'agente diventa di tutti,
   si cambia una variabile sul server e le app se ne accorgono da sole.

   Si ricorda per un giorno: e' una cosa che cambia forse una volta nella vita di un account, e
   chiederla a ogni apertura sarebbe una richiesta di rete per sapere una cosa gia' saputa.
   --------------------------------------------------------------------------------------- */
const JD_ABIL_MS = 24 * 3600000;

async function jdAbilitato(){
  const c = jdCache();
  if (c && typeof c.abil === 'boolean' && (Date.now() - (c.abilIl || 0)) < JD_ABIL_MS) return c.abil;
  if (!jdPuo()) return false;
  try{
    const r = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/agent/enabled', body: '' });
    const v = !!(r && r.enabled);
    try{ localStorage.setItem(JD_KEY, JSON.stringify(Object.assign({}, c || {}, { abil: v, abilIl: Date.now() }))); }catch(_){ }
    return v;
  }catch(_){
    /* Senza risposta si resta su quello che si sapeva, e in mancanza di tutto si dice di no:
       l'errore che costa meno e' non mostrare una funzione a chi ce l'ha, non il contrario. */
    return !!(c && c.abil);
  }
}

/* ---------------------------------------------------------------------------------------
   QUELLO CHE DEPOSITA IL TELEFONO

   Già riassunto, di proposito. Sette giorni di cronologia al granello sarebbero centinaia di
   migliaia di righe: Jordan ci si perderebbe e il tetto del server direbbe di no. Qui c'è la
   forma della settimana, che è quello su cui si esprime un arbitro.
   --------------------------------------------------------------------------------------- */
/** Le app per nome, divise per etichetta: dal telefono (Report → etichette) e dal computer. */
function jdAppEtichette(){
  const out = { produttive: [], neutre: [], distrattive: [] };
  const metti = function(lista, nome){ nome = String(nome || '').trim(); if (nome && lista.indexOf(nome) < 0) lista.push(nome); };
  try{
    const cats = (typeof insCats === 'function') ? insCats() : {};
    /* i nomi leggibili delle app del telefono: l'app li impara dal Report e li tiene qui */
    let nomi = {}; try{ nomi = JSON.parse(localStorage.getItem('fl_app_nomi') || '{}') || {}; }catch(_){ }
    Object.keys(cats).forEach(function(pkg){
      const nome = nomi[pkg] || pkg;
      if (cats[pkg] === 'prod') metti(out.produttive, nome);
      else if (cats[pkg] === 'distr') metti(out.distrattive, nome);
      else metti(out.neutre, nome);
    });
  }catch(_){ }
  try{
    for (let off = 0; off < 7; off++){
      const p = (typeof pcGiorno === 'function') ? pcGiorno(off) : null;
      ((p && p.top) || []).forEach(function(x){
        if (/^Prod/i.test(x.c)) metti(out.produttive, x.k);
        else if (/^Distr/i.test(x.c)) metti(out.distrattive, x.k);
        else metti(out.neutre, x.k);
      });
    }
  }catch(_){ }
  return out;
}
/** I nomi delle app, imparati ogni volta che il Report li legge (insights.js li passa qui). */
function jdImparaNomi(apps){
  try{
    const nomi = JSON.parse(localStorage.getItem('fl_app_nomi') || '{}') || {};
    let n = 0;
    (apps || []).forEach(function(a){ if (a && a.packageName && a.label && nomi[a.packageName] !== a.label){ nomi[a.packageName] = a.label; n++; } });
    if (n) localStorage.setItem('fl_app_nomi', JSON.stringify(nomi));
  }catch(_){ }
}
/** Vero se un testo nomina un'app che non va bloccata (produttiva o neutra). */
function jdNominaProtetta(testo){
  const s = String(testo || '').toLowerCase();
  if (!s) return false;
  const ap = jdAppEtichette();
  return ap.produttive.concat(ap.neutre).some(function(n){ n = String(n).toLowerCase(); return n.length >= 4 && s.indexOf(n) >= 0; });
}
async function jdRaccogli(){
  const b = { kind: 'focuslock-agent-in', v: 1, at: Date.now(), giorni: [] };

  for (let off = 0; off < 7; off++){
    const g = { giorno: (typeof pvGiornoKey === 'function') ? pvGiornoKey(off) : '' };
    try{
      if (typeof tlRiassuntoDi === 'function'){
        const t = await tlRiassuntoDi(off);
        if (t && t.riprese){
          g.telefono = { ms: t.tot, riprese: t.riprese, lampi: t.lampi, notte: t.notte,
                         vuotoPiuLungo: t.fuoco, oraPiuRotta: t.oraRotta,
                         app: (t.perApp || []).slice(0, 5).map(function(a){
                           return { nome: a.l, ms: a.ms, riprese: a.n, lampi: a.lampi };
                         }) };
        }
      }
    }catch(_){ }
    try{
      if (typeof pcGiorno === 'function'){
        const p = pcGiorno(off);
        if (p) g.computer = { min: p.m, lavoro: p.prod, distrazione: p.distr,
                              top: (p.top || []).slice(0, 5) };
      }
    }catch(_){ }
    try{
      if (typeof pvOsserva === 'function'){
        const o = await pvOsserva(off);
        g.segnali = o;
      }
    }catch(_){ }
    /* Le righe spuntate, per esteso. Servono all'archivio dei successi, che con una
       percentuale non ci fa niente: li' deve finire la frase che hai scritto tu. */
    try{
      const giorno = (typeof pvGiornoKey === 'function') ? pvGiornoKey(off) : '';
      const done = JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || [];
      const spunte = done.filter(function(r){ return r && r.day === giorno && r.text; })
                         .map(function(r){ return String(r.text); });
      if (spunte.length) g.spunte = spunte.slice(0, 20);
    }catch(_){ }
    if (g.telefono || g.computer) b.giorni.push(g);
  }

  /* LE ETICHETTE DELLE APP, e la regola che ne discende. Jordan proponeva di bloccare Claude
     Code, l'app con cui Andrea lavora: vedeva l'app in cima al tempo del computer e non aveva
     modo di sapere che era produttiva. Adesso gliele diciamo per nome, con una regola che non
     lascia interpretazioni, e in piu' l'app filtra (prenota.js) qualunque decisione che nomini
     un'app produttiva o neutra: una regola detta due volte, da tutte e due le parti. */
  try{
    const ap = jdAppEtichette();
    b.app = { produttive: ap.produttive, neutre: ap.neutre, distrattive: ap.distrattive };
    b.regole = [
      'Proponi di bloccare, limitare o rinunciare SOLO alle app elencate in app.distrattive.',
      'Le app in app.produttive sono gli strumenti con cui l\'utente lavora al suo sogno: non proporre mai di bloccarle, limitarle o evitarle, anche se sono in cima al tempo di schermo.',
      'Le app in app.neutre non si toccano.'
    ];
  }catch(_){ }

  /* COM'E' ANDATA, secondo chi l'ha vissuta.
     Non entra in nessun calcolo di traiettoria — quelli restano sui fatti — ma Jordan
     riordina le priorità, e riordinarle senza sapere se la settimana è stata una salita o
     una passeggiata è riordinarle alla cieca. Due settimane identiche nei numeri possono
     chiedere due piani opposti. */
  try{ if (typeof umPerJordan === 'function') b.umore = umPerJordan(7); }catch(_){ }

  /* IL PIANO E LA PARTITA: sono la metà su cui l'arbitro deve pronunciarsi. Senza, Jordan
     vedrebbe solo il consumo e nessuna promessa — e un arbitro che non conosce le regole del
     gioco può solo commentare il meteo. */
  try{
    const oz = JSON.parse(localStorage.getItem('fl_orizzonti') || '{}') || {};
    b.orizzonti = {};
    Object.keys(oz).forEach(function(k){
      if (k.indexOf('__') === 0) return;
      const a = oz[k] || {};
      b.orizzonti[k] = {
        testo: a.testo || '',
        passi: (a.passi || []).map(function(p){ return { t: p.t, fatto: !!p.fatto, il: p.il || '' }; })
      };
      try{ if (typeof ozStima === 'function') b.orizzonti[k].stima = ozStima(k); }catch(_){ }
    });
  }catch(_){ }

  try{
    const h = JSON.parse(localStorage.getItem('fl_match_hist') || '[]') || [];
    b.partita = h.slice(-14).map(function(g){
      const ev = (g.eventi || []);
      return { giorno: g.day,
               nuovo: ev.filter(function(e){ return e.chi === 'neo'; }).length,
               vecchio: ev.filter(function(e){ return e.chi === 'old'; }).length,
               eventi: ev.slice(-20) };
    });
  }catch(_){ }

  /* LE IDEE DA RIVEDERE: quello che Andrea ha mandato in revisione dalle note. Jordan risponde
     nel verdetto con `revisioni` (id, esito, motivo, sostituisce, dove). */
  try{
    if (typeof stRevLista === 'function'){
      const rev = stRevLista().filter(function(x){ return x && x.stato === 'attesa'; }).slice(-12);
      if (rev.length) b.revisione = rev.map(function(x){ return { id: x.id, testo: x.testo, giorno: x.giorno, at: x.at }; });
    }
  }catch(_){ }
  /* LE COSE DA SCOMPORRE: una riga troppo grossa per starci in una sessione. Jordan risponde
     nel verdetto con `scomposizioni` (id, passi[], motivo). */
  try{
    if (typeof stScompLista === 'function'){
      const sc = stScompLista().filter(function(x){ return x && x.stato === 'attesa'; }).slice(-8);
      if (sc.length) b.scomporre = sc.map(function(x){ return { id: x.id, testo: x.testo, giorno: x.giorno }; });
    }
  }catch(_){ }
  try{
    if (typeof pvStato === 'function'){
      const s = pvStato();
      b.motore = { post: s.post, pesi: s.w, calibrazione: s.cal,
                   bravura: (typeof pvBravura === 'function') ? pvBravura() : null,
                   correzioni: (typeof pvQuanteCorrezioni === 'function') ? pvQuanteCorrezioni() : 0 };
    }
    if (typeof orLast === 'function'){
      const r = orLast();
      if (r) b.lettura = { profilo: r.profile, obiettivo: r.target, pct: r.pct, at: r.at };
    }
  }catch(_){ }

  /* LE FINESTRE PRODUTTIVE: dove le sessioni riescono davvero. Jordan le usa per mettere le
     cose piu' impegnative del piano nelle ore che rendono di piu'. E i completamenti
     autodichiarati degli ultimi giorni, da controllare contro la Roadmap. */
  try{
    if (typeof dpFinestre === 'function' && typeof dpGiorni === 'function'){
      const f = dpFinestre(dpGiorni());
      b.finestre = f.pronto
        ? { pronte: true, giorni: f.giorni, base: f.base, fasce: f.fasce.map(function(x){ return { da: x.da, a: x.a, sessioni: x.tot, riuscita: Math.round(x.tasso * 100), minutiMedi: Math.round(x.media) }; }),
            consiglio: 'metti qui le cose più impegnative della roadmap' }
        : { pronte: false, giorni: f.giorni };
    }
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const recenti = h.filter(function(x){ return x && x.completed_self_reported && !x.stornato && x.at > Date.now() - 7 * 86400000; });
    if (recenti.length) b.completamentiDichiarati = recenti.map(function(x){ return { at: x.at, task: x.task || x.intent || '', minuti: Math.round((x.spentMs || 0) / 60000) }; });
    /* I PUNTI PRENOTATI E LE DECISIONI (prenota.js): l'agente vede cosa e' stato prenotato, cosa
       confermato, e come ha risposto alle sue domande — e' da qui che decide le `revoche`. */
    if (typeof pkPerAgente === 'function'){
      const pk = pkPerAgente();
      if (pk.prenotazioni.length) b.prenotazioni = pk.prenotazioni;
      if (pk.decisioniRisposte.length) b.decisioniRisposte = pk.decisioniRisposte;
    }
  }catch(_){ }

  return b;
}

/**
 * GLI STORNI DEL COMPLETAMENTO. Il «Si', completata» di FullFocus e' autodichiarato: se Jordan
 * vede che la task risulta ancora aperta, nel verdetto mette `storni: [{ at, motivo }]` (at =
 * la fine della sessione). Si toglie il bonus di completamento, mai quello di concentrazione,
 * e negli insight compare la voce «Completamento stornato» con il motivo.
 */
function jdStorni(v){
  try{
    if (!Array.isArray(v.storni) || typeof ffStorna !== 'function') return;
    let n = 0;
    v.storni.forEach(function(s){ if (s && s.at && ffStorna(+s.at, s.motivo)) n++; });
    if (n && typeof dpCalcola === 'function') dpCalcola(true);
  }catch(_){ }
}

/** Deposita, se è passato abbastanza tempo. Non blocca niente e non dice niente se fallisce. */
async function jdDeposita(forza){
  if (!jdPuo()) return false;
  if (!(await jdAbilitato())) return false;   // niente agente, niente da depositare
  const c = jdCache();
  if (!forza && c && (Date.now() - (c.inviatoIl || 0)) < JD_OGNI_MS) return false;
  try{
    const b = await jdRaccogli();
    if (!b.giorni.length && !b.orizzonti) return false;
    await NATIVE.accountApi({
      method: 'PUT', path: '/api/focuslock/backups',
      body: JSON.stringify({ deviceId: JD_IN, deviceName: 'Osservazioni', backup: b,
                             summary: { programs: b.giorni.length, apps: 0, sites: 0, keywords: 0 } })
    });
    const nuovo = Object.assign({}, c || {}, { inviatoIl: Date.now() });
    try{ localStorage.setItem(JD_KEY, JSON.stringify(nuovo)); }catch(_){ }
    return true;
  }catch(_){ return false; }
}

/** Il verdetto di Jordan, se ne ha depositato uno. */
async function jdLeggi(forza){
  const c = jdCache();
  if (!jdPuo()) return (c && c.verdetto) || null;
  if (!(await jdAbilitato())) return null;
  if (!forza && c && (Date.now() - (c.lettoIl || 0)) < 30 * 60000) return c.verdetto || null;
  try{
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === JD_OUT; })[0];
    if (!riga){
      try{ localStorage.setItem(JD_KEY, JSON.stringify(Object.assign({}, c || {}, { lettoIl: Date.now() }))); }catch(_){ }
      return (c && c.verdetto) || null;
    }
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const v = (pieno && pieno.payload) || null;
    if (v && v.kind === 'focuslock-jordan'){
      try{ localStorage.setItem(JD_KEY, JSON.stringify(Object.assign({}, c || {}, { verdetto: v, lettoIl: Date.now() }))); }catch(_){ }
      jdStorni(v);
      return v;
    }
    return (c && c.verdetto) || null;
  }catch(_){ return (c && c.verdetto) || null; }
}

/* ---------------------------------------------------------------------------------------
   COME SI VEDE

   Un pannello solo, con la data: un verdetto di tre giorni fa letto come se fosse di stamattina
   sarebbe peggio di nessun verdetto. Se Jordan non ha ancora parlato, lo si dice — perché una
   sezione che sparisce si legge come una funzione che non è stata fatta.
   --------------------------------------------------------------------------------------- */
function jdQuando(ts){
  if (!ts) return '';
  const h = Math.round((Date.now() - ts) / 3600000);
  if (h < 1) return 'poco fa';
  if (h < 24) return h + (h === 1 ? ' ora fa' : ' ore fa');
  const g = Math.round(h / 24);
  return g + (g === 1 ? ' giorno fa' : ' giorni fa');
}

/* ---------------------------------------------------------------------------------------
   L'ITINERARIO PROPOSTO

   Gli anelli, nell'ordine in cui li legge Keller: dalla destinazione lontana giu' fino a oggi.
   Ogni riga e' «l'UNICA cosa che, fatta, rende il resto piu' facile o inutile».
   --------------------------------------------------------------------------------------- */
const JD_ANELLI = [
  ['cinque', 'Fra cinque anni'],
  ['anno', "Quest'anno"],
  ['mese', 'Questo mese'],
  ['settimana', 'Questa settimana'],
  ['oggi', 'Oggi']
];

function jdPianoCard(v){
  const p = v && v.piano;
  if (!p || typeof p !== 'object') return '';
  const righe = JD_ANELLI.filter(function(a){ return p[a[0]] && p[a[0]].testo; });
  if (!righe.length) return '';

  return '<div class="jd-piano"><div class="jd-top"><span>🧭</span><b>L\'itinerario che propone</b></div>'
    + '<p class="jd-piano-sub">Tu hai scelto la destinazione. Questa è la catena per arrivarci: '
    + 'ogni riga nasce dalla domanda fatta su quella sopra.</p>'
    + righe.map(function(a){
        const x = p[a[0]];
        const passi = Array.isArray(x.passi) ? x.passi : [];
        /* 0.9.296, Andrea: "sotto Fra cinque anni, Quest'anno, Questo mese i punti elenco devono essere dei collapsible".
           Chiuso si legge l'orizzonte e quanti passi propone; i passi si aprono con un tocco. */
        return '<details class="jd-anello"><summary><span><small>' + a[1] + '</small><b>' + esc(String(x.testo)) + '</b></span>'
          + (passi.length ? '<em>' + Math.min(passi.length, 6) + (passi.length === 1 ? ' passo' : ' passi') + '</em>' : '')
          + '<svg class="jd-chev" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></summary>'
          + (passi.length
              ? '<ul>' + passi.slice(0, 6).map(function(t){ return '<li>' + esc(String(t)) + '</li>'; }).join('') + '</ul>'
              : '')
          + '</details>';
      }).join('')
    + (Array.isArray(v.pedaggi) && v.pedaggi.length
        ? '<div class="jd-pedaggi"><small>Le scorciatoie: investimenti che comprano tempo</small>'
          + v.pedaggi.slice(0, 3).map(function(t){
              return '<p>💰 <b>' + esc(String(t.cosa || '')) + '</b> — costa ' + esc(String(t.costa || '?'))
                + ', ti fa guadagnare ' + esc(String(t.risparmia || '?')) + '</p>';
            }).join('')
          + '</div>'
        : '')
    + '<button type="button" class="jd-applica" onclick="jdApplica()">Applica l\'itinerario</button>'
    + '<p class="jd-piano-nota">I passi che hai già spuntato restano dove sono.</p>'
    + '</div>';
}

/**
 * Scrive l'itinerario dentro agli orizzonti, senza distruggere niente.
 *
 * <p>Il confronto si fa sul testo del passo, non sulla posizione: se Jordan ripropone «Aprire
 * la partita IVA» e tu l'hai gia' spuntato, quel passo resta spuntato con la sua data — che e'
 * anche l'unico modo di non perdere il ritmo misurato, cioe' la cosa da cui nasce la stima di
 * arrivo. Riscrivere tutto da capo azzererebbe la misura ogni volta che Jordan parla.</p>
 */
function jdApplica(){
  const c = jdCache();
  const v = (c && c.verdetto) || null;
  const p = v && v.piano;
  if (!p || typeof ozAnello !== 'function' || typeof ozSalvaAnello !== 'function'){
    if (typeof toast === 'function') toast('Non c\'è nessun itinerario da applicare');
    return;
  }

  let nuovi = 0;
  JD_ANELLI.forEach(function(a){
    const x = p[a[0]];
    if (!x || !x.testo) return;
    const mio = ozAnello(a[0]);
    const avuti = mio.passi || [];
    const visti = {};
    avuti.forEach(function(q){ visti[String(q.t || '').trim().toLowerCase()] = 1; });

    const passi = avuti.slice();
    (Array.isArray(x.passi) ? x.passi : []).forEach(function(t){
      const k = String(t || '').trim().toLowerCase();
      if (!k || visti[k]) return;
      visti[k] = 1;
      passi.push({ t: String(t), fatto: false, il: '' });
      nuovi++;
    });

    ozSalvaAnello(a[0], { testo: mio.testo || String(x.testo), passi: passi });
  });

  try{ if (typeof ozPaint === 'function') ozPaint(); }catch(_){ }
  try{ if (typeof mpPaint === 'function') mpPaint(); }catch(_){ }
  if (typeof toast === 'function'){
    toast(nuovi ? 'Itinerario applicato: ' + nuovi + (nuovi === 1 ? ' passo nuovo' : ' passi nuovi')
                : 'Era già tutto al suo posto');
  }
}

function jdCard(v){
  /* Niente verdetto = niente riquadro. Non un segnaposto, non un «in arrivo»: chi non ha
     l'agente non deve nemmeno sapere che esiste, e chi ce l'ha sa gia' che parla quando ha
     qualcosa da dire. Un riquadro vuoto in cima alla pagina piu' densa dell'app sarebbe
     rumore nel primo caso e una promessa mai mantenuta nel secondo. */
  if (!v) return '';
  const punti = v.punti || null;
  return '<div class="jd-card"><div class="jd-top"><span>🧑‍⚖️</span><b>Jordan</b>'
    + '<i>' + jdQuando(v.at) + '</i></div>'
    + (punti ? '<div class="jd-punti"><em>🕳️ ' + (punti.vecchio || 0) + '</em>'
        + '<span>–</span><em class="neo">' + (punti.nuovo || 0) + ' 🚀</em></div>' : '')
    + (v.verdetto ? '<p class="jd-verdetto">' + esc(String(v.verdetto)) + '</p>' : '')
    + (Array.isArray(v.note) && v.note.length
        ? '<ul class="jd-note">' + v.note.slice(0, 4).map(function(n){ return '<li>' + esc(String(n)) + '</li>'; }).join('') + '</ul>'
        : '')
    + (v.prossimoPasso ? '<p class="jd-passo">👉 ' + esc(String(v.prossimoPasso)) + '</p>' : '')
    + '</div>'
    + jdPianoCard(v);
}

(function jdStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.jd-card{margin-top:16px;border-radius:18px;padding:15px;background:#0B1524;color:#fff}',
    '.jd-card.jd-muto{background:transparent;border:1.5px dashed var(--line);color:var(--muted,#7A8AA3)}',
    '.jd-top{display:flex;align-items:center;gap:9px}',
    '.jd-top span{font-size:20px;line-height:1}',
    '.jd-top b{font:800 14px var(--font-body)}',
    '.jd-top i{margin-left:auto;font-style:normal;font:600 10.5px var(--font-body);',
      'color:rgba(200,218,242,.6)}',
    '.jd-muto .jd-top b{color:var(--navy)}',
    '.jd-card p{margin:10px 0 0;font:500 13px/1.6 var(--font-body)}',
    '.jd-punti{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:12px}',
    '.jd-punti em{font-style:normal;font:900 24px var(--font-body);color:#FF8A8A}',
    '.jd-punti em.neo{color:var(--neo-soft,#4FB8FF)}',
    '.jd-punti span{color:rgba(200,218,242,.5);font-weight:800}',
    '.jd-verdetto{font-weight:600}',
    '.jd-note{margin:10px 0 0;padding-left:18px}',
    '.jd-note li{font:500 12.5px/1.6 var(--font-body);color:rgba(200,218,242,.9)}',
    '.jd-passo{margin-top:12px;padding-top:10px;border-top:1px solid rgba(255,255,255,.12);',
      'font-weight:700}',

    '.jd-piano{margin-top:12px;border:1.5px solid var(--line);border-radius:18px;padding:15px}',
    '.jd-piano .jd-top b{color:var(--navy)}',
    '.jd-piano-sub{margin:9px 0 14px;font:500 12.5px/1.6 var(--font-body);color:var(--muted,#7A8AA3)}',
    '.jd-anello{padding:10px 0;border-top:1px solid var(--line)}',
    '.jd-anello small{display:block;font:800 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:#0075E3;font-size:11px}body.dark .jd-anello small{color:#8CC6FF}',
    '.jd-anello b{display:block;margin-top:4px;font:800 14px/1.4 var(--font-body);color:var(--navy)}',
    '.jd-anello ul{margin:7px 0 0;padding-left:18px}',
    '.jd-anello li{font:500 12.5px/1.6 var(--font-body);color:var(--muted,#7A8AA3)}',
    '.jd-pedaggi{margin-top:12px;padding-top:10px;border-top:1px solid var(--line)}',
    '.jd-pedaggi small{display:block;font:800 9.5px var(--font-body);letter-spacing:.14em;',
      'text-transform:uppercase;color:var(--muted,#7A8AA3);margin-bottom:6px}',
    '.jd-pedaggi p{margin:6px 0 0;font:500 12.5px/1.6 var(--font-body);color:var(--navy)}',
    '.jd-applica{display:block;width:100%;margin-top:14px;border:0;border-radius:99px;padding:13px;',
      'background:#0075E3;color:#fff;font:800 13.5px var(--font-body);cursor:pointer}',
    '.jd-piano-nota{margin:9px 0 0;text-align:center;font:500 11px var(--font-body);',
      'color:var(--muted,#7A8AA3)}'
  ].join('');
  document.head.appendChild(st);
})();

/* Il deposito parte da solo, tardi e in silenzio: è lavoro di fondo, non deve rallentare
   l'apertura dell'app né comparire da nessuna parte se la rete non c'è. */
document.addEventListener('DOMContentLoaded', function(){
  setTimeout(function(){ try{ jdDeposita(false); }catch(_){ } }, 9000);
});

(function(){
  const st = document.createElement('style');
  st.textContent = '.jd-anello>summary{list-style:none;display:flex;align-items:center;gap:10px;cursor:pointer}.jd-anello>summary::-webkit-details-marker{display:none}'
    + '.jd-anello>summary>span{flex:1;min-width:0}.jd-anello>summary em{flex:none;font:700 11.5px var(--font-body);font-style:normal;color:var(--muted)}'
    + '.jd-chev{flex:none;color:var(--muted);transition:transform .2s}.jd-anello[open] .jd-chev{transform:rotate(180deg)}'
    + '.jd-anello ul{margin:8px 0 2px}';
  document.head.appendChild(st);
})();
