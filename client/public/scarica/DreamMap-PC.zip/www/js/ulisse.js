/* ===========================================================================================
   L'ADHD MODE E IL CAVEAU DELLE IDEE (0.9.211)

   IL PROBLEMA. Con la testa a 3000 giri le idee nuove arrivano a decine, e sono belle davvero.
   La task noiosa che sposta il risultato non da' segni di progresso; l'idea nuova si'. Se le
   idee restano visibili (nelle note, nel foglio), ogni volta che le rileggi ti chiamano, e la
   giornata finisce su un'idea nuova invece che sull'unica cosa.

   LE DUE REGOLE. L'obiettivo e l'unica cosa di oggi: sempre visibili, sono l'ancora. Le idee
   nuove: invisibili, sono le sirene.

   IL CAVEAU (per tutti). Nel foglio di oggi c'e' un riquadro dove un'idea si scrive e sparisce:
   e' al sicuro, ma non si rilegge. Si vede solo quante sono. Si chiude con un timer (0.9.311, vedi
   cvStato) e allo scadere si riapre e resta aperto. Si rilegge nel Taglia: una idea alla volta,
   sessanta secondi in tutto, «Taglia» o «Tieni per domani». Un'idea segnata «urgente» puo' saltare la coda solo dopo
   48 ore, e solo se alla domanda «senza questa, il tuo obiettivo non si puo' raggiungere?» la
   risposta e' si'.

   L'ADHD MODE (un interruttore, non un profilo: non chiediamo la diagnosi e non la salviamo).
   Si accende dai tre puntini del foglio nella Mappa. Finche' e' accesa: il foglio grande e' chiuso
   (si scarica tutto nel caveau), le righe di domani si scrivono ma non si rileggono fino al
   Taglia di domattina. Come la Modalita' severa, non si spegne prima della data scelta; a quella
   data il pannello olografico chiede: rinnovi (un punto al nuovo te) o lasci che tutto torni
   negoziabile (un punto al vecchio te). Il testo dice cosa fa, mai cosa cura: «progettata per
   chi ha l'ADHD», mai «risolve l'ADHD».

   LA PROPOSTA. Non si impone a nessuno. Si propone quando l'utente ha provato a pianificare da
   solo e la lista ha vinto sulla priorita' (tre giorni su sette con la priorita' aperta sotto a
   una lista lunga), oppure quando all'episodio 7 ha risposto «a tutto quello che mi rallenta».
   =========================================================================================== */
const UL_KEY = 'fl_ulisse';      // { on, fino, at, giorni, rinnovi, chiesta }
const CV_KEY = 'fl_caveau';      // [{ id, t, at, urg, stato: 'chiusa'|'tagliata'|'tenuta'|'promossa', urgVista }]
const UL_PROP_KEY = 'fl_ulisse_proposta';
const UL_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const UL_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
function ulEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function ulLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function ulScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function ulStato(){ return ulLeggi(UL_KEY, {}) || {}; }
function ulAttiva(){ const u = ulStato(); return !!(u.on && u.fino > Date.now()); }
function ulScaduta(){ const u = ulStato(); return !!(u.on && u.fino && u.fino <= Date.now()); }
function ulData(t){ const d = new Date(t); return UL_GIORNI[d.getDay()] + ' ' + d.getDate() + ' ' + UL_MESI[d.getMonth()]; }
function ulDomenica(){ const d = new Date(); d.setHours(21, 0, 0, 0); let add = (7 - d.getDay()) % 7; if (add === 0 && Date.now() > d.getTime()) add = 7; d.setDate(d.getDate() + add); return d.getTime(); }
function ulOggiK(){ return (typeof stDayKey === 'function') ? stDayKey('today') : ''; }
function ulDomaniK(){ return (typeof mtKey === 'function') ? mtKey(Date.now() + 86400000) : ''; }
function ulRighe(day){ try{ return (typeof stRigheDi === 'function') ? stRigheDi(day) : []; }catch(_){ return []; } }
function ulAggiungiRiga(day, t){
  const r = ulRighe(day); if (r.indexOf(t) >= 0) return;
  try{ localStorage.setItem('fl_notes_' + day, r.concat([t]).join('\n')); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(day); }catch(_){ }
}

/* ---------------------------------------------------------------- il caveau */
function cvLista(){ return ulLeggi(CV_KEY, []) || []; }
function cvSalva(l){ ulScrivi(CV_KEY, l.slice(-500)); }
function cvChiuse(){ return cvLista().filter(function(x){ return x && x.stato === 'chiusa'; }); }
/* IL CAVEAU A TIMER (0.9.311, Andrea). Prima si apriva in un giorno fisso (la domenica). Adesso funziona come la modalita'
   severa: si chiude con un timer scelto dall'utente (i rulli giorni|ore|min di severe.js, al massimo 365 giorni), allo
   scadere si riapre e RESTA aperto finche' l'utente non lo richiude. Ogni chiusura e' un voto per la nuova identita':
   +1 al nuovo te, una volta al giorno (cvVoto), come prolungare la modalita' severa.
   Alla scadenza, per i timer di almeno 2 giorni, il pannello olografico (decision.js) propone la stessa durata di prima,
   mai una fissa; sotto i 2 giorni si apre e basta (la regola di DecisionNotice.vaChiesto). Rifiutare non costa punti: il
   timer l'ha scelto l'utente, e sta finendo come aveva deciso.
   fl_caveau_stato = { v, aperto, fino, inizio, durataMin, avvisa, migrato }.
   MIGRAZIONE dal giorno fisso, una volta sola (cvStatoMigra): chi oggi poteva rileggere (domenica, ADHD Mode finita) resta
   aperto; chi usa gia' il caveau e oggi lo trovava chiuso resta chiuso fino alla prossima apertura prevista (domenica alle
   00:00, durata 7 giorni: il suo ritmo di prima); chi non l'ha mai usato parte aperto. Le idee non si toccano mai.
   L'ADHD Mode accesa tiene chiuso sopra a tutto: quando finisce, conta di nuovo il timer. */
const CVS_KEY = 'fl_caveau_stato';
const CV_VOTO_KEY = 'fl_caveau_voto';
const CV_MAX_MIN = 365 * 1440;
const CV_DOMANDA_MIN = 2 * 1440;
const CV_VOTO_PTS = 40;   // quanto prolungare la modalita' severa (SEV_PROLUNGA_PTS)
function cvStatoMigra(){
  const ora = new Date();
  const poteva = ora.getDay() === 0 || ulScaduta() || !!ulStato().apriCaveau;
  if (ulAttiva() || poteva || !cvLista().length) return { v: 1, aperto: true, fino: 0, inizio: 0, durataMin: 0 };
  const d = new Date(ora.getTime()); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + ((7 - d.getDay()) % 7));
  return { v: 1, aperto: false, fino: d.getTime(), inizio: d.getTime() - 7 * 864e5, durataMin: 7 * 1440, migrato: Date.now() };
}
function cvStato(){
  let s = ulLeggi(CVS_KEY, null);
  if (!s || !s.v){ s = cvStatoMigra(); ulScrivi(CVS_KEY, s); }
  /* timer brevissimo finito: si apre e basta. L'avviso lo da' cvScadenzaControlla */
  if (!s.aperto && (s.fino || 0) <= Date.now() && (s.durataMin || 0) < CV_DOMANDA_MIN){ s.aperto = true; s.fino = 0; s.avvisa = true; ulScrivi(CVS_KEY, s); }
  return s;
}
function cvApribile(){ return !ulAttiva() && !!cvStato().aperto; }
/** Fino a quando resta chiuso (0 = aperto). Oltre il momento attuale, se il timer e' finito e aspetta la risposta. */
function cvFino(){ const s = cvStato(); return Math.max(s.aperto ? 0 : (s.fino || 0), ulAttiva() ? ulStato().fino : 0); }
function cvInAttesa(){ const s = cvStato(); return !ulAttiva() && !s.aperto && (s.fino || 0) <= Date.now(); }
function cvOraTxt(t){ const d = new Date(t), p = function(x){ return (x < 10 ? '0' : '') + x; }; return p(d.getHours()) + ':' + p(d.getMinutes()); }
function cvQuandoTxt(){
  const f = cvFino(); if (f <= Date.now()) return 'oggi';
  const g = new Date(f), o = new Date(), dom = new Date(o.getTime() + 864e5);
  const giorno = g.toDateString() === o.toDateString() ? 'oggi' : g.toDateString() === dom.toDateString() ? 'domani' : ulData(f);
  return giorno + ' alle ' + cvOraTxt(f);
}
/** Il voto per la nuova identita': una volta al giorno, come sevPremiaVoto. Senza cancello ci si regalerebbero i punti. */
function cvVoto(motivo){
  const d = new Date(); d.setHours(0, 0, 0, 0);
  let ultimo = 0; try{ ultimo = +localStorage.getItem(CV_VOTO_KEY) || 0; }catch(_){ }
  if (ultimo >= d.getTime()) return { pts: 0, punto: false };
  try{ localStorage.setItem(CV_VOTO_KEY, String(Date.now())); }catch(_){ }
  try{ if (typeof decVote === 'function') decVote('caveau', true, CV_VOTO_PTS); }catch(_){ }
  let punto = false; try{ punto = (typeof mgFocusPoint === 'function') && !!mgFocusPoint(motivo, true); }catch(_){ }
  return { pts: CV_VOTO_PTS, punto: punto };
}
function cvRidisegna(){
  try{ cvBoxPaint(); }catch(_){ }
  try{ if (typeof order !== 'undefined' && order[cur] === 's-caveau-pag') cvPaginaPaint(); }catch(_){ }
  try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ }
  try{ if (typeof mnPaint === 'function') mnPaint(); }catch(_){ }
}
/* il foglio con i rulli: gli stessi della modalita' severa */
function cvChiudiApri(){
  if (ulAttiva()){ toast('Il caveau è già chiuso fino a ' + ulData(ulStato().fino)); return; }
  if (typeof svhFoglio !== 'function' || typeof svtRulliHtml !== 'function') return;
  const s = cvStato();
  const w = svhFoglio('cvTimer', '<h3>Per quanto tempo lo chiudi?</h3>' + svtRulliHtml()
    + '<p class="svt-fine" data-svt-fine></p>'
    + '<button type="button" class="svh-cta svt-salva" data-svt-salva onclick="cvChiudiSalva()" disabled>Chiudi il caveau</button>');
  const f = w.querySelector('.svt-foglio'); f.dataset.modo = 'imposta';
  requestAnimationFrame(function(){ svtMonta(f, s.durataMin || 7 * 1440); });
}
function cvChiudiSalva(){
  const w = document.getElementById('cvTimer'); if (!w) return;
  const tot = svtTotale(w.querySelector('.svt-foglio')); if (tot < 1) return;
  svhFoglioChiudi('cvTimer');
  cvChiudiTimer(tot);
}
function cvChiudiTimer(min){
  min = Math.max(1, Math.min(CV_MAX_MIN, Math.round(+min || 0)));
  const ora = Date.now(), s = cvStato();
  s.aperto = false; s.inizio = ora; s.durataMin = min; s.fino = ora + min * 60000; delete s.avvisa;
  ulScrivi(CVS_KEY, s);
  cvTimerArma();
  const v = cvVoto('Hai richiuso il caveau delle idee con un nuovo timer');
  try{ flVibra([20, 40, 80]); }catch(_){ }
  toast('Il caveau si riapre ' + cvQuandoTxt() + (v.punto ? ': +1 al nuovo te' : ''));
  cvRidisegna();
}
/* ---- alla scadenza ---- */
let CV_ALLARME = 0, CV_RITENTA = 0;
function cvTimerArma(){
  clearTimeout(CV_ALLARME);
  const s = cvStato(), resta = (s.fino || 0) - Date.now();
  if (!s.aperto && resta > 0 && resta < 2147000000) CV_ALLARME = setTimeout(cvScadenzaControlla, resta + 400);
}
function cvScadenzaControlla(){
  try{
    const s = cvStato();
    if (s.avvisa){
      delete s.avvisa; ulScrivi(CVS_KEY, s);
      if (cvChiuse().length) toast('Il caveau delle idee è di nuovo aperto');
      cvRidisegna();
    }
    if (s.aperto || (s.fino || 0) > Date.now() || ulAttiva() || document.hidden) return;
    if (localStorage.getItem('fl_onboarded') !== '1' || typeof decOpen !== 'function') return;
    /* un'altra decisione a schermo: questa aspetta il suo turno, e intanto il caveau resta chiuso */
    if (typeof DEC !== 'undefined' && DEC.open){ clearTimeout(CV_RITENTA); CV_RITENTA = setTimeout(cvScadenzaControlla, 20000); return; }
    const n = cvChiuse().length, dur = (typeof sevFmtDur === 'function') ? sevFmtDur(s.durataMin) : Math.round(s.durataMin / 1440) + ' giorni';
    DEC.last = null;
    decOpen('custom', {
      kicker: 'Il timer del caveau è finito',
      title: 'PRENDI UNA DECISIONE',
      line: 'Hai tenuto chiuso il caveau per <b>' + dur + '</b>' + (n ? ', con dentro <b>' + n + (n === 1 ? ' idea' : ' idee') + '</b>' : '') + '. Puoi riaprirlo adesso, o tenerlo chiuso per altri <b>' + dur + '</b>.',
      left: 'APRI<br>IL CAVEAU', right: 'CONTINUA<br>' + dur.toUpperCase(),
      leftAct: 'cvScadenzaApri()', rightAct: 'cvScadenzaEstendi()'
    });
  }catch(_){ }
}
function cvScadenzaEstendi(){
  const s = cvStato(), min = Math.min(CV_MAX_MIN, s.durataMin || CV_DOMANDA_MIN), ora = Date.now();
  s.aperto = false; s.inizio = ora; s.durataMin = min; s.fino = ora + min * 60000;
  ulScrivi(CVS_KEY, s);
  cvTimerArma();
  const v = cvVoto('Hai tenuto chiuso il caveau delle idee alla scadenza del timer');
  const testo = 'Il caveau si riapre <b>' + cvQuandoTxt() + '</b>.' + (v.punto ? '<br><b>+1 al nuovo te</b> sul tabellone della partita.' : '');
  if (v.pts) decResult(testo, v.pts, true);
  else decResultCon(testo, null, true, ['<button type="button" class="dec-opt yes" onclick="decClose()">CHIUDI</button>']);
  cvRidisegna();
}
function cvScadenzaApri(){
  const s = cvStato();
  s.aperto = true; s.fino = 0; delete s.avvisa;
  ulScrivi(CVS_KEY, s);
  clearTimeout(CV_ALLARME);
  const n = cvChiuse().length;
  decResultCon('Il caveau è aperto. Resta aperto finché non lo richiudi tu.', null, true,
    n ? ['<button type="button" class="dec-opt no" onclick="decClose()">PIÙ TARDI</button>', '<button type="button" class="dec-opt yes" onclick="decClose();cvPaginaApri()">RILEGGI<br>LE IDEE</button>']
      : ['<button type="button" class="dec-opt yes" onclick="decClose()">CHIUDI</button>'], 'Il caveau delle idee');
  cvRidisegna();
}
function cvAggiungi(t, urg){
  t = String(t || '').trim(); if (!t) return false;
  const l = cvLista();
  t.split(/\n+/).map(function(x){ return x.trim(); }).filter(Boolean).forEach(function(x){ l.push({ id: 'cv' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), t: x.slice(0, 400), at: Date.now(), urg: !!urg, stato: 'chiusa' }); });
  cvSalva(l);
  return true;
}
/** 0.9.283: un'immagine nel caveau (gia' rimpicciolita da csImmagineDato). Se la memoria e' piena risponde false. */
function cvAggiungiImmagine(dato, testo){
  if (!dato) return false;
  const l = cvLista();
  l.push({ id: 'cv' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), t: String(testo || 'Un’immagine').slice(0, 400), img: dato, at: Date.now(), urg: false, stato: 'chiusa' });
  try{ localStorage.setItem(CV_KEY, JSON.stringify(l.slice(-500))); return true; }catch(_){ return false; }
}
function cvSalvaDaCampo(){
  const a = document.getElementById('cvIn'), u = document.getElementById('cvUrg');
  if (!a || !a.value.trim()){ toast('Scrivi l’idea da mettere al sicuro'); return; }
  cvAggiungi(a.value, u && u.checked);
  a.value = ''; if (u) u.checked = false;
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast(cvApribile() ? 'Al sicuro nel caveau' : 'Al sicuro nel caveau: la rileggi ' + cvQuandoTxt());
  cvBoxPaint();
}
function cvBoxHtml(){
  const n = cvChiuse().length;
  const aperto = cvApribile(), apri = aperto && n > 0;
  return '<div class="cv-box' + (ulAttiva() ? ' ul-on' : '') + '" id="cvBox">'
    + '<div class="cv-h"><span class="cv-lock">' + (aperto ? '🔓' : '🔒') + '</span><div><b>Il caveau delle idee</b><small>' + (aperto ? 'Scrivi l’idea che ti distrae, poi chiudi il caveau con un timer: le idee spariscono dalla vista.' : 'Scrivi l’idea che ti distrae: va al sicuro e sparisce dalla vista. La rileggi ' + cvQuandoTxt() + ', nel Taglia.') + '</small></div>'
    + '<button type="button" class="cv-q" onclick="cvInfoApri()" aria-label="Come funziona il caveau">?</button></div>'
    + '<textarea id="cvIn" class="fin cv-in" rows="2" placeholder="Un’idea, un pensiero, una cosa da non dimenticare…"></textarea>'
    + '<div class="cv-riga"><label class="cv-urg"><input type="checkbox" id="cvUrg"><span>È urgente</span></label><button type="button" class="cta cv-via" onclick="cvSalvaDaCampo()">Mettila al sicuro</button></div>'
    + '<p class="cv-conta">' + (n ? '🔐 <b>' + n + (n === 1 ? ' idea' : ' idee') + ' al sicuro</b>' : 'Il caveau è vuoto: le idee nuove vengono qui, non nel foglio.') + '</p>'
    + (apri ? '<button type="button" class="cv-taglia" onclick="cvTagliaApri()">✂️ Il Taglia del caveau · ' + n + (n === 1 ? ' idea' : ' idee') + '</button>' : '')
    + (aperto ? '<button type="button" class="cv-chiudi" onclick="cvChiudiApri()">Chiudi il caveau con un timer</button>' : '')
    + '</div>';
}
function cvBoxPaint(){ const b = document.getElementById('cvBox'); if (b) b.outerHTML = cvBoxHtml(); }

/* ---- LA PAGINA DEL CAVEAU (0.9.232): si apre toccando il caveau in Le tue note ----
   Le idee restano chiuse (il caveau e' a sola scrittura): si vede quante sono, di che giorno, quali
   sono urgenti e quando si riaprono; si scrive un'idea nuova; la domenica parte il Taglia. */
registerScreen('s-caveau-pag',
  '<div class="topbar"><button class="iconbtn" onclick="cvPaginaChiudi()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" style="flex:1;text-align:center">Il caveau delle idee</b><button class="iconbtn" onclick="cvInfoApri()" aria-label="Come funziona il caveau"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.2"/></svg></button></div>'
  + '<div id="cvpBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(cvPaginaDopo, 0); return CVP.da || 's-home'; } });
const CVP = { da: '', tab: '' };
function cvPaginaApri(){
  CVP.da = (typeof order !== 'undefined' && order[cur] && order[cur] !== 's-caveau-pag') ? order[cur] : 's-home';
  try{ CVP.tab = localStorage.getItem('fl_tab') || ''; }catch(_){ CVP.tab = ''; }
  goId('s-caveau-pag'); cvPaginaPaint();
  cvScadenzaControlla();
}
function cvPaginaDopo(){ if (CVP.da === 's-home' && CVP.tab){ try{ switchTab(CVP.tab); }catch(_){ } } try{ if (typeof mnPaint === 'function') mnPaint(); }catch(_){ } }
function cvPaginaChiudi(){ goId(CVP.da || 's-home'); cvPaginaDopo(); }
function cvPaginaPaint(){
  const h = document.getElementById('cvpBody'); if (!h) return;
  const chiuse = cvChiuse(), tutte = cvLista(), n = chiuse.length;
  const conta = function(st){ return tutte.filter(function(x){ return x && x.stato === st; }).length; };
  const aperto = cvApribile(), attesa = cvInAttesa();
  /* chiuso: si vede la busta, non il testo. Aperto: le idee si rileggono. */
  let dentro = '';
  if (aperto){
    /* 0.9.342, Andrea: "se apro il caveau l'idea si apre nell'esercizio Taglia: voglio aprirla come una pagina delle note".
       Ogni idea e' una riga che si tocca e si apre come nota; il Taglia resta un pulsante a parte. */
    dentro = '<p class="cvp-p cvp-tocca">Tocca un’idea per aprirla come una nota.</p>' + chiuse.slice().reverse().map(function(x){ return '<button type="button" class="cvp-idea" onclick="cvIdeaApri(\'' + x.id + '\')">' + (x.img ? '<img src="' + x.img + '" alt="">' : '') + '<div><b>' + ulEsc(cvIdeaTesto(x)) + '</b><small>Scritta ' + ulData(x.at || Date.now()) + (x.urg ? ', urgente' : '') + (x.tenutaAt ? ', tenuta al Taglia' : '') + '</small></div><svg class="cvp-chev" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg></button>'; }).join('');
  } else {
    const perGiorno = {};
    chiuse.forEach(function(x){ const d = new Date(x.at || Date.now()); const k = d.getFullYear() * 10000 + d.getMonth() * 100 + d.getDate(); (perGiorno[k] = perGiorno[k] || { d: d, n: 0, urg: 0 }).n++; if (x.urg) perGiorno[k].urg++; });
    dentro = Object.keys(perGiorno).sort(function(a, b){ return b - a; }).map(function(k){ const g = perGiorno[k];
      return '<div class="cvp-g"><span class="cvp-busta">✉️</span><div><b>' + ulData(g.d.getTime()) + '</b><small>' + g.n + (g.n === 1 ? ' idea chiusa' : ' idee chiuse') + (g.urg ? ', ' + g.urg + (g.urg === 1 ? ' urgente' : ' urgenti') : '') + '</small></div></div>'; }).join('');
  }
  const testa = aperto
    ? (n ? '<p>Il caveau è aperto. Resta aperto finché non lo richiudi.</p>' : '<p>Il caveau è aperto e vuoto. Scrivi qui le idee che ti distraggono, poi chiudilo con un timer.</p>')
      + (n ? '<button type="button" class="cta cvp-taglia" onclick="cvTagliaApri()">✂️ Inizia il Taglia · ' + n + (n === 1 ? ' idea' : ' idee') + '</button>' : '')
      + '<button type="button" class="cvp-chiudi" onclick="cvChiudiApri()">Chiudi il caveau</button>'
    : attesa
      ? '<p>Il timer è finito.</p><button type="button" class="cta cvp-taglia" onclick="cvScadenzaControlla()">Decidi adesso</button>'
      : '<p>Si riapre ' + cvQuandoTxt() + '.</p><div class="cvp-conto" id="cvpConto"></div>';
  h.innerHTML = '<div class="cvp-testa"><div class="cvp-lucchetto">' + (aperto ? '🔓' : '🔒') + '</div><b class="cvp-num">' + n + '</b><span>' + (aperto ? (n === 1 ? 'idea da rileggere' : 'idee da rileggere') : (n === 1 ? 'idea al sicuro' : 'idee al sicuro')) + '</span>' + testa + '</div>'
    + '<div class="cvp-card"><b class="cvp-tit">Metti al sicuro un\'idea</b>'
    +   '<textarea id="cvIn" class="fin cv-in" rows="3" placeholder="Un\'idea, un pensiero, una cosa da non dimenticare…"></textarea>'
    +   '<div class="cv-riga"><label class="cv-urg"><input type="checkbox" id="cvUrg"><span>È urgente</span></label><button type="button" class="cta cv-via" onclick="cvSalvaDaCampo();cvPaginaPaint()">Mettila al sicuro</button></div></div>'
    + (dentro ? '<div class="cvp-card"><b class="cvp-tit">Dentro al caveau</b>' + dentro + '</div>' : '')
    + '<button type="button" class="cvp-prompt" onclick="amApri()"><span>🌳</span><div><b>Il prompt dell\'albero maestro</b><small>Un testo da dare alle AI con cui lavori: rifiutano le aggiunte fuori rotta e stanno dalla parte del nuovo te.</small></div></button>'
    + '<div class="cvp-card"><b class="cvp-tit">Finora</b><div class="cvp-stat"><div><b>' + conta('tagliata') + '</b><small>tagliate</small></div><div><b>' + tutte.filter(function(x){ return x && (x.tenutaAt || x.stato === 'tenuta'); }).length + '</b><small>tenute</small></div><div><b>' + conta('promossa') + '</b><small>urgenti passate</small></div></div></div>'
    + '<button type="button" class="cvp-imp" onclick="ulImpApri()">ADHD Mode e impostazioni della pianificazione</button>';
  cvPaginaConto();
}
/* il conto alla rovescia in testa alla pagina: gira solo finche' la pagina e' a schermo */
/* il testo dell'idea: se e' gia' stata aperta come nota, quello che c'e' scritto nella nota adesso */
function cvIdeaNota(x){
  try{ if (!x || !x.notaId || typeof mnLista !== 'function') return null; return mnLista().filter(function(n){ return n && n.id === x.notaId; })[0] || null; }catch(_){ return null; }
}
function cvIdeaTesto(x){
  const n = cvIdeaNota(x);
  const t = n ? String(n.text || '').replace(/\s+/g, ' ').trim() : '';
  return (t || String(x && x.t || '')).slice(0, 220);
}
/* 0.9.354, Andrea: "tocco una nota dentro al caveau e me la ritrovo in cima a tutte le note, ma non l'ho toccata e deve restare nel
   caveau". LA CAUSA: per aprirla come nota la si scriveva fra le note (con la data di adesso, quindi in cima) senza nessun segno, e
   chiudendola si tornava all'elenco di tutte le note. Adesso la nota porta caveau:true (la replica non la mostra in Tutte le note,
   nelle cartelle e nella ricerca, e il segno resta anche quando la scrivi), tiene la data dell'idea, e chiudendola torni al caveau. */
function cvIdeaApri(id){
  const l = cvLista(); const x = l.filter(function(y){ return y && y.id === id; })[0]; if (!x) return;
  if (typeof mnLista !== 'function' || typeof mnSalva !== 'function' || typeof noApri !== 'function'){ toast('Le note non sono pronte: riprova'); return; }
  let n = cvIdeaNota(x);
  if (!n){
    const t = String(x.t || '').trim(), e = (typeof mnEsc === 'function') ? mnEsc : ulEsc;
    n = { id: 'cv-' + x.id, title: t.split(/\s+/).slice(0, 6).join(' ').slice(0, 60) || 'Idea dal caveau', text: t,
      html: '<p>' + e(t) + '</p>' + (x.img ? '<p><img src="' + x.img + '"></p>' : ''), date: (typeof mnData === 'function') ? mnData(x.at) : '', folder: 'Cartelle', mod: x.at || Date.now(), caveau: true };
    const nl = mnLista(); nl.push(n); mnSalva(nl);
    x.notaId = n.id; cvSalva(l);
  } else if (!n.caveau){
    const nl = mnLista(); nl.forEach(function(y){ if (y && y.id === n.id) y.caveau = true; }); mnSalva(nl);
  }
  try{ flVibra(8); }catch(_){ }
  noApri(n.id, false, 's-caveau-pag');
}
/* 0.9.354: le idee gia' aperte come nota prima di questa versione stavano fra le note senza segno: tornano nel caveau, una volta sola */
function cvNoteSegna354(){
  try{
    if (localStorage.getItem('fl_cv_note_354') === '1' || typeof mnLista !== 'function' || typeof mnSalva !== 'function') return;
    const ids = {}; cvLista().forEach(function(x){ if (x && x.notaId) ids[x.notaId] = 1; });
    const nl = mnLista(); let n = 0;
    nl.forEach(function(y){ if (y && !y.caveau && (ids[y.id] || /^cv-cv/.test(String(y.id)))){ y.caveau = true; n++; } });
    if (n) mnSalva(nl);
    localStorage.setItem('fl_cv_note_354', '1');
  }catch(_){ }
}
setTimeout(cvNoteSegna354, 2500);
/* 0.9.342: le idee tenute al Taglia (stato "tenuta") erano finite nel foglio di domani e nelle cose da fare del Full Focus.
   Tornano nel caveau, una volta sola, e dal foglio si tolgono solo le righe identiche a quelle idee. */
function cvRientro342(){
  try{
    if (localStorage.getItem('fl_cv_rientro_342') === '1') return;
    const l = cvLista();
    const tornate = l.filter(function(x){ return x && x.stato === 'tenuta'; });
    if (tornate.length){
      const testi = {}; tornate.forEach(function(x){ testi[String(x.t || '').trim()] = 1; });
      tornate.forEach(function(x){ x.stato = 'chiusa'; x.tenutaAt = x.decisaAt || Date.now(); delete x.decisaAt; });
      cvSalva(l);
      const chiavi = [];
      for (let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); if (k && /^fl_notes_\d/.test(k)) chiavi.push(k); }
      chiavi.forEach(function(k){
        const v = localStorage.getItem(k) || ''; const r = v.split('\n');
        const tieni = r.filter(function(x){ return !testi[String(x).trim()]; });
        if (tieni.length !== r.length){ localStorage.setItem(k, tieni.join('\n')); try{ if (typeof fsToccato === 'function') fsToccato(k.slice(9)); }catch(_){ } }
      });
      try{ if (typeof ffPref === 'function' && typeof ffSavePref === 'function'){ const p = ffPref(); if (p.intent && testi[String(p.intent).trim()]){ p.intent = ''; ffSavePref(); } } }catch(_){ }
      try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
      try{ if (typeof ffPaint === 'function') ffPaint(); }catch(_){ }
      try{ cvRidisegna(); }catch(_){ }
      try{ toast(tornate.length === 1 ? 'L’idea tenuta è tornata nel caveau' : 'Le ' + tornate.length + ' idee tenute sono tornate nel caveau'); }catch(_){ }
    }
    localStorage.setItem('fl_cv_rientro_342', '1');
  }catch(_){ }
}
setTimeout(cvRientro342, 3500);
function cvPaginaConto(){
  clearInterval(CVP.tick); CVP.tick = 0;
  const giro = function(){
    const el = document.getElementById('cvpConto');
    if (!el || (typeof order !== 'undefined' && order[cur] !== 's-caveau-pag')){ clearInterval(CVP.tick); CVP.tick = 0; return; }
    const resta = cvFino() - Date.now();
    if (resta <= 0){ clearInterval(CVP.tick); CVP.tick = 0; cvScadenzaControlla(); cvPaginaPaint(); return; }
    el.textContent = 'Mancano ' + ((typeof sevFmtDur === 'function') ? sevFmtDur(Math.ceil(resta / 60000)) : Math.ceil(resta / 60000) + ' min');
  };
  if (document.getElementById('cvpConto')){ giro(); if (document.getElementById('cvpConto')) CVP.tick = setInterval(giro, 5000); }
}
/* la (i): cosa fare, in quattro righe */
function cvInfoApri(){
  if (typeof svhFoglio !== 'function') return;
  const r = function(ico, t){ return '<div class="cvi-r"><span>' + ico + '</span><p>' + t + '</p></div>'; };
  svhFoglio('cvInfo', '<h3>Come si usa il caveau</h3>'
    + r('✍️', 'Quando arriva un\'idea mentre lavori, scrivila qui o trascinaci una nota.')
    + r('🔒', 'Chiudi il caveau con il timer che scegli: le idee spariscono dalla vista.')
    + r('✂️', 'Quando il timer finisce, il caveau resta aperto finché non lo richiudi. Nel Taglia decidi quali idee tenere.')
    + r('🚨', 'Un\'idea urgente esce prima solo dopo 48 ore, e solo se senza di lei il tuo obiettivo non si può raggiungere.'));
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#cvpBody{padding:6px 16px 0}',
    '.cvp-testa{text-align:center;border-radius:22px;padding:22px 16px 18px;margin:4px 0 14px;background:linear-gradient(160deg,#1E2A5A,#0F2041);color:#fff}',
    '.cvp-lucchetto{font-size:40px;line-height:1}.cvp-num{display:block;font:900 44px/1.1 var(--font-display,var(--font-body));margin-top:6px}.cvp-testa span{font:700 14px var(--font-body);color:#C9D6EE}',
    '.cvp-testa p{margin:10px 0 0;font:600 14px/1.45 var(--font-body);color:#8CC6FF}.cvp-taglia{margin-top:14px}',
    '.cvp-card{border-radius:18px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:14px;margin:0 0 12px}',
    '.cvp-tit{display:block;text-align:center;font:800 15px var(--font-display,var(--font-body));color:var(--navy,#14234A);margin-bottom:8px}',
    '.cvp-p{font:500 13.5px/1.45 var(--font-body);color:var(--muted,#5B6B86);margin:0 0 8px}',
    '.cvp-g{display:flex;align-items:center;gap:10px;padding:9px 0;border-top:1px solid var(--line,#E5ECF6)}.cvp-g:first-of-type{border-top:0}.cvp-busta{font-size:22px}.cvp-g b{display:block;font:700 14px var(--font-body);color:var(--navy,#14234A)}.cvp-g small{font:500 12.5px var(--font-body);color:var(--muted,#5B6B86)}',
    '.cvp-conto{display:inline-block;margin-top:12px;padding:8px 16px;border-radius:99px;background:rgba(188,224,255,.14);font:800 14px var(--font-body);color:#fff}',
    '.cvp-chiudi{display:block;width:100%;margin-top:10px;padding:15px;border:0;border-radius:50px;background:#E63946;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.cvp-tocca{text-align:center;margin:0 0 6px!important}button.cvp-idea{width:100%;border:0;background:transparent;text-align:left;cursor:pointer;align-items:center!important}.cvp-chev{flex:none;margin-left:auto;color:var(--muted,#5B6B86)}.cvp-idea > div{flex:1;min-width:0}',
    '.cvp-idea{display:flex;gap:10px;align-items:flex-start;padding:10px 0;border-top:1px solid var(--line,#E5ECF6)}.cvp-idea:first-of-type{border-top:0}.cvp-idea img{flex:none;width:56px;height:56px;border-radius:10px;object-fit:cover}.cvp-idea b{display:block;font:600 14px/1.4 var(--font-body);color:var(--navy,#14234A);overflow-wrap:anywhere}body.dark .cvp-idea b{color:#fff}.cvp-idea small{display:block;margin-top:3px;font:500 12px var(--font-body);color:var(--muted,#5B6B86)}',
    '.cvi-r{display:flex;gap:12px;align-items:center;text-align:left;margin:12px 0}.cvi-r span{flex:none;width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:#fff;box-shadow:0 0 0 1.5px #BCE0FF;font-size:20px}.cvi-r p{margin:0;font:500 14px/1.45 var(--font-body);color:var(--navy,#14234A)}body.dark .cvi-r p{color:#fff}',
    '.cv-chiudi{display:block;width:100%;margin-top:10px;padding:13px;border:1.5px solid #E63946;border-radius:50px;background:transparent;color:#E63946;font:800 14px var(--font-body);cursor:pointer}body.dark .cv-chiudi{color:#FF8A95;border-color:#FF8A95}',
    '.cvt-torna{display:block;width:100%;margin-top:10px;padding:13px;border:1.5px solid var(--line,#E5ECF6);border-radius:50px;background:transparent;color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}body.dark .cvt-torna{color:#fff;border-color:#2F4A75}',
    '.cvp-passo{display:flex;gap:10px;align-items:flex-start;margin:8px 0}.cvp-passo span{flex:none;width:24px;height:24px;border-radius:50%;background:#0075E3;color:#fff;font:800 12px var(--font-body);display:grid;place-items:center}.cvp-passo p{margin:2px 0 0;font:500 13.5px/1.45 var(--font-body);color:var(--navy,#14234A)}',
    '.cvp-stat{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center}.cvp-stat b{display:block;font:900 22px var(--font-display,var(--font-body));color:var(--navy,#14234A)}.cvp-stat small{font:600 11.5px var(--font-body);color:var(--muted,#5B6B86)}',
    '.cvp-imp{display:block;width:100%;margin:2px 0 8px;padding:13px;border:0;border-radius:99px;background:transparent;box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}',
    '.ul-ripristina{display:block;width:100%;margin-top:10px;padding:12px;border:0;border-radius:99px;background:#EAF3FE;color:#0B4F9C;font:700 14px var(--font-body);cursor:pointer}'
  ].join('');
  document.head.appendChild(st);
})();

/* ---- il Taglia del caveau: una idea alla volta, sessanta secondi in tutto ---- */
const CVT = { voci: [], i: 0, fine: 0, timer: 0, tagliate: 0, tenute: 0 };
registerScreen('s-caveau',
  '<div class="topbar"><button class="iconbtn" onclick="cvTagliaFine()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Il Taglia del caveau</b></div>'
  + '<div id="cvtBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(cvTagliaFine, 0); return 's-home'; } });
function cvTagliaApri(){
  if (!cvApribile()){ toast('Il caveau si riapre ' + cvQuandoTxt()); return; }
  CVT.voci = cvChiuse(); CVT.i = 0; CVT.tagliate = 0; CVT.tenute = 0;
  if (!CVT.voci.length){ toast('Il caveau è vuoto'); return; }
  CVT.fine = Date.now() + 60000;
  goId('s-caveau'); cvtPaint();
  clearInterval(CVT.timer); CVT.timer = setInterval(cvtTick, 250);
}
function cvtTick(){
  const b = document.getElementById('cvtBar'), s = document.getElementById('cvtSec');
  const resta = Math.max(0, CVT.fine - Date.now());
  if (b) b.style.width = (resta / 600) + '%';
  if (s) s.textContent = Math.ceil(resta / 1000) + ' s';
  if (resta <= 0){ clearInterval(CVT.timer); CVT.timer = 0; CVT.i = CVT.voci.length; cvtPaint(); }
}
function cvtPaint(){
  const h = document.getElementById('cvtBody'); if (!h) return;
  if (CVT.i >= CVT.voci.length){
    clearInterval(CVT.timer); CVT.timer = 0;
    const restano = cvChiuse().length;
    h.innerHTML = '<div class="cvt-fine"><span>✂️</span><h2>Taglio fatto</h2><p>Hai tagliato <b>' + CVT.tagliate + '</b> ' + (CVT.tagliate === 1 ? 'idea' : 'idee') + ' e ne hai ' + (CVT.tenute === 1 ? 'tenuta' : 'tenute') + ' <b>' + CVT.tenute + '</b> nel caveau.' + (restano ? ' In tutto restano nel caveau ' + restano + (restano === 1 ? ' idea' : ' idee') + ', fino al prossimo Taglia.' : '') + '</p>'
      + '<p class="cvt-nota">Le idee tagliate non sono perse: aspettano la prossima stagione, quando la cosa che conta sarà fatta.</p>'
      + (cvApribile() ? '<button type="button" class="cta" onclick="cvChiudiApri()">Richiudi il caveau</button><button type="button" class="cvt-torna" onclick="cvTagliaFine()">Torna al foglio</button>' : '<button type="button" class="cta" onclick="cvTagliaFine()">Torna al foglio</button>') + '</div>';
    try{ const u = ulStato(); if (u.apriCaveau){ u.apriCaveau = false; ulScrivi(UL_KEY, u); } }catch(_){ }
    return;
  }
  const v = CVT.voci[CVT.i];
  h.innerHTML = '<div class="cvt-bar"><i id="cvtBar"></i></div><p class="cvt-conta">Idea ' + (CVT.i + 1) + ' di ' + CVT.voci.length + ' · <span id="cvtSec">60 s</span></p>'
    + '<div class="cvt-carta"><small>Scritta ' + ulData(v.at) + (v.urg ? ' · segnata urgente' : '') + '</small>' + (v.img ? '<img class="cvt-img" src="' + v.img + '" alt="">' : '') + (v.img && v.t === 'Un’immagine' ? '' : '<p>' + ulEsc(v.t) + '</p>') + '</div>'
    + '<p class="cvt-q">Ti avvicina all’obiettivo, adesso?</p>'
    + '<div class="cvt-due"><button type="button" class="taglia" onclick="cvtScelta(false)">✂️ Taglia</button><button type="button" class="tieni" onclick="cvtScelta(true)">🔐 Tienila nel caveau</button></div>';
  cvtTick();
}
/* 0.9.342, Andrea: "tutto quello che avevo messo Tieni per domani dal caveau e' finito come task della pagina Full Focus, invece
   di restare nel caveau". "Tieni" scriveva l'idea nel foglio di domani (che il Full Focus mostra come cose da fare) e la toglieva
   dal caveau. Adesso l'idea tenuta RESTA nel caveau, chiusa come prima, e torna al prossimo Taglia. */
function cvtScelta(tieni){
  const v = CVT.voci[CVT.i]; if (!v) return;
  const l = cvLista(); const x = l.filter(function(y){ return y.id === v.id; })[0];
  if (x){ if (tieni){ x.stato = 'chiusa'; x.tenutaAt = Date.now(); } else { x.stato = 'tagliata'; x.decisaAt = Date.now(); } cvSalva(l); }
  if (tieni) CVT.tenute++; else CVT.tagliate++;
  try{ flVibra(tieni ? 12 : [8, 20, 8]); }catch(_){ }
  CVT.i++; cvtPaint();
}
function cvTagliaFine(){ clearInterval(CVT.timer); CVT.timer = 0; goId('s-home'); try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ } }

/* ---- l'idea urgente: dopo 48 ore, una domanda sola ---- */
function cvUrgenteControlla(){
  try{
    if (typeof DEC !== 'undefined' && DEC.open) return;
    const l = cvLista();
    const v = l.filter(function(x){ return x.stato === 'chiusa' && x.urg && !x.urgVista && Date.now() - x.at >= 48 * 3600000; })[0];
    if (!v || typeof decOpen !== 'function') return;
    v.urgVista = Date.now(); cvSalva(l);
    UL_URG = v.id;
    decOpen('custom', {
      kicker: 'Un’idea urgente di due giorni fa',
      title: 'SENZA QUESTA<br>NON SI ARRIVA?',
      line: '«' + ulEsc(v.t) + '»<br>Sono passate 48 ore da quando l’hai scritta. Senza questa idea il tuo obiettivo <b>non si può raggiungere</b>?',
      left: 'NO,<br>ASPETTA', right: 'SÌ,<br>È VITALE',
      leftAct: 'cvUrgente(false)', rightAct: 'cvUrgente(true)',
      foot: 'L’urgenza che senti è spesso la trappola.'
    });
  }catch(_){ }
}
let UL_URG = '';
function cvUrgente(si){
  const l = cvLista(); const v = l.filter(function(x){ return x.id === UL_URG; })[0];
  if (v){ if (si){ v.stato = 'promossa'; ulAggiungiRiga(ulOggiK(), v.t); } else v.urg = false; cvSalva(l); }
  if (typeof decClose === 'function') decClose();
  toast(si ? 'È nel foglio di oggi' : 'Resta nel caveau, senza urgenza');
  cvBoxPaint();
}

/* ---------------------------------------------------------------- l'ADHD Mode */
registerScreen('s-foglio-imp',
  '<div class="topbar"><button class="iconbtn" onclick="ulImpChiudi()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Impostazioni del piano</b></div>'
  + '<div id="ulImpBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('mappa'); }catch(_){ } }, 0); return 's-home'; } });
const UL = { giorni: 0, data: '' };
/* 0.9.238: due pagine di impostazioni distinte, quella del piano della Mappa e quella della Roadmap */
function ulImpApri(ctx){
  UL.giorni = 0; UL.data = ''; UL.ctx = ctx === 'roadmap' ? 'roadmap' : 'mappa';
  goId('s-foglio-imp');
  const t = document.querySelector('#s-foglio-imp .blk-title'); if (t) t.textContent = UL.ctx === 'roadmap' ? 'Impostazioni della Roadmap' : 'Impostazioni del piano';
  ulImpPaint();
}
function ulImpChiudi(){ const r = UL.ctx === 'roadmap'; if (typeof navTornaDietro === 'function' && navTornaDietro(order[cur])) return; goId('s-home'); try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista(r ? 'rotta' : 'mia'); }catch(_){ } }
const UL_DURATE = [[0, 'Fino a domenica'], [7, '7 giorni'], [14, '14 giorni'], [30, '30 giorni']];
function ulFinoScelto(){
  if (UL.data){ const d = new Date(UL.data + 'T21:00:00'); if (!isNaN(d.getTime()) && d.getTime() > Date.now()) return d.getTime(); }
  if (!UL.giorni) return ulDomenica();
  const d = new Date(Date.now() + UL.giorni * 86400000); d.setHours(21, 0, 0, 0); return d.getTime();
}
function ulImpPaint(){
  const h = document.getElementById('ulImpBody'); if (!h) return;
  const u = ulStato(), on = ulAttiva(), n = cvChiuse().length;
  /* 0.9.237, Andrea: l'ADHD Mode in fondo, per ultima; prima le impostazioni del piano */
  h.innerHTML = (UL.ctx === 'roadmap' && typeof rmpImpHtml === 'function' ? rmpImpHtml() : ulImpFoglioHtml()) + '<div class="ul-card' + (on ? ' on' : '') + '">'
    + '<div class="ul-testa"><span class="ul-ico">⚡</span><div><b>ADHD Mode</b><small>Progettata per chi ha l’ADHD e per chiunque abbia la testa a 3000 giri.</small></div>'
    + '<button type="button" class="cv-q" onclick="ulAiuto()" aria-label="Come funziona">?</button>'
    + '<button type="button" class="switch' + (on ? ' on bloccato' : '') + '" onclick="ulInterruttore()" aria-label="ADHD Mode"></button></div>'
    + (on
        ? '<p class="ul-stato">Accesa fino a <b>' + ulData(u.fino) + '</b>. Prima di quella data non si spegne: è il patto.</p>'
        : '<p class="ul-p">Le idee nuove vanno nel caveau e restano chiuse fino alla data che scegli. Il foglio grande si chiude, le righe di domani si scrivono ma si rileggono solo nel Taglia di domattina. Davanti resta l’obiettivo e l’unica cosa di oggi.</p>'
          + '<p class="ul-sez">Fino a quando</p><div class="ul-chips">' + UL_DURATE.map(function(d){ return '<button type="button" class="' + (!UL.data && UL.giorni === d[0] ? 'on' : '') + '" onclick="UL.giorni=' + d[0] + ';UL.data=\'\';ulImpPaint()">' + d[1] + '</button>'; }).join('')
          + '<label class="ul-data' + (UL.data ? ' on' : '') + '"><span>Scelgo la data</span><input type="date" value="' + UL.data + '" onclick="try{this.showPicker()}catch(_){}" onchange="UL.data=this.value;ulImpPaint()"></label></div>'
          + '<p class="ul-fino">Si spegne ' + ulData(ulFinoScelto()) + ', alle 21.</p>'
          + '<button type="button" class="cta ul-via" onclick="ulAccendi()">Accendi l’ADHD Mode</button>')
    + '</div>'
    + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">' + (cvApribile() ? '🔓' : '🔒') + '</span><div><b>Il caveau delle idee</b><small>' + (n ? n + (n === 1 ? ' idea al sicuro.' : ' idee al sicuro.') : 'Ancora vuoto.') + (cvApribile() ? ' È aperto.' : ' Si rilegge ' + cvQuandoTxt() + ', nel Taglia.') + '</small></div></div>'
    + '<p class="ul-p">Un’idea segnata "urgente" salta la coda solo se sono passate 48 ore da quando l’hai scritta e se, rileggendola, rispondi sì: senza questa idea il tuo obiettivo non si può raggiungere.</p>'
    + (cvApribile() && n ? '<button type="button" class="cv-taglia" onclick="cvTagliaApri()">✂️ Il Taglia del caveau · ' + n + (n === 1 ? ' idea' : ' idee') + '</button>' : '')
    + (cvApribile() ? '<button type="button" class="cv-chiudi" onclick="cvChiudiApri()">Chiudi il caveau con un timer</button>' : '')
    + '</div>'
    + '';
}
function ulImpFoglioHtml(){
  const lista = (typeof mfLista === 'function') && mfLista();
  /* 0.9.232: le schede del pannello, da accendere e spegnere, e il ripristino di quelle di partenza */
  let schede = '';
  try{
    if (typeof MF_TABS !== 'undefined' && typeof mfSchedeCfg === 'function'){
      const c = mfSchedeCfg();
      schede = '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🗂️</span><div><b>Le schede</b><small>Quali schede vedi nel pannello di pianificazione. Per rinominarne una, tocca la scheda già aperta; per spostarla, tienila premuta e trascinala.</small></div></div>'
        + MF_TABS.map(function(x){ const on = c.via.indexOf(x[0]) < 0; return '<div class="blk-swrow"><div><b>' + ulEsc(c.nomi[x[0]] || x[1]) + '</b>' + (c.nomi[x[0]] ? '<small>Si chiamava ' + ulEsc(x[1]) + '</small>' : '') + '</div><button type="button" class="switch' + (on ? ' on' : '') + '" aria-label="Mostra la scheda ' + ulEsc(x[1]) + '" onclick="mfSchedaMostra(\'' + x[0] + '\',' + (on ? 'false' : 'true') + ')"></button></div>'; }).join('')
        + '<button type="button" class="ul-ripristina" onclick="mfSchedeRipristina()">Ripristina le schede di partenza</button>'
        + '</div>';
    }
  }catch(_){ schede = ''; }
  const c = function(k){ return (typeof pnCond === 'function') && pnCond(k); };
  let rm = '';
  try{ if (typeof rmpModificabile === 'function'){ const on = rmpModificabile();
    rm = '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🛣️</span><div><b>Il piano della Roadmap</b><small>Di serie lo scrive la roadmap e non si cambia: segui i passi e arrivi in tempo.</small></div></div>'
      + '<div class="blk-swrow"><div><b>Posso modificarlo</b><small>Aggiungi righe tue sotto ai passi, e compare la scheda Note.</small></div><button type="button" class="switch' + (on ? ' on' : '') + '" aria-label="Il piano della Roadmap si puo modificare" onclick="rmpModificabileSet(' + (on ? 'false' : 'true') + ')"></button></div></div>'; } }catch(_){ rm = ''; }
  rm = ''; /* 0.9.238: la card del piano della Roadmap sta nelle impostazioni della Roadmap */
  return schede + rm + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">📝</span><div><b>La scheda Oggi</b><small>Una cosa sola, o una lista dove scrivi sotto alla prima riga.</small></div></div>'
    + '<div class="ul-scelta"><button type="button" class="' + (lista ? '' : 'on') + '" onclick="mfListaSet(false)"><b>Una cosa sola</b><small>La priorità di oggi, e basta</small></button>'
    + '<button type="button" class="' + (lista ? 'on' : '') + '" onclick="mfListaSet(true)"><b>Una lista</b><small>Da fare oggi, una riga per cosa</small></button></div></div>'
    + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🔒</span><div><b>Quando si apre domani</b><small>Spenti tutti e due, il piano di domani si vede sempre.</small></div></div>'
    + '<div class="blk-swrow"><div><b>Dopo la priorità di oggi</b><small>Prima chiudi la cosa che conta.</small></div><button type="button" class="switch' + (c('prio') ? ' on' : '') + '" onclick="pnCondSet(\'prio\');ulImpPaint()"></button></div>'
    + '<div class="blk-swrow"><div><b>Dopo la fine del lavoro</b><small>Domani si guarda a giornata chiusa.</small></div><button type="button" class="switch' + (c('fine') ? ' on' : '') + '" onclick="pnCondSet(\'fine\');ulImpPaint()"></button></div>'
    /* l'ora serve solo se l'interruttore e' acceso: prima stava sempre in vista, in un pannello a parte */
    + (c('fine') ? '<label class="ul-ora"><span>La giornata di lavoro finisce alle</span><input type="time" class="fin pn-ora" value="' + ((typeof pnFineLavoro === 'function') ? pnFineLavoro() : '18:00') + '" onchange="pnFineSet(this.value)"></label>' : '')
    + '</div>';
}
function ulInterruttore(){
  if (ulAttiva()){ toast('L’ADHD Mode resta accesa fino a ' + ulData(ulStato().fino)); try{ flVibra([30, 30, 30]); }catch(_){ } return; }
  ulAccendi();
}
function ulAccendi(){
  const fino = ulFinoScelto();
  if (typeof decOpen !== 'function'){ ulConferma(fino); return; }
  UL.finoScelto = fino;
  decOpen('custom', {
    kicker: 'ADHD Mode',
    title: 'LEGATI<br>ALL’ALBERO MAESTRO',
    line: 'Fino a <b>' + ulData(fino) + '</b> le idee nuove vanno nel caveau e non si rileggono. Davanti restano l’obiettivo e l’unica cosa di oggi.<br><b>Prima di quella data non si spegne.</b>',
    left: 'NON<br>ANCORA', right: 'MI<br>LEGO',
    leftAct: 'decClose()', rightAct: 'ulConferma()',
    foot: 'Ulisse non ha battuto le sirene: le ha rese innocue.'
  });
}
function ulConferma(fino){
  fino = fino || UL.finoScelto || ulDomenica();
  const u = ulStato();
  u.on = true; u.fino = fino; u.at = Date.now(); u.giorni = Math.max(1, Math.round((fino - Date.now()) / 86400000)); u.chiesta = 0;
  ulScrivi(UL_KEY, u);
  if (typeof decClose === 'function') decClose();
  try{ flVibra([20, 40, 80]); }catch(_){ }
  toast('ADHD Mode accesa fino a ' + ulData(fino));
  ulImpPaint();
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
}
/** La spiegazione dietro il «?»: cosa fa, senza promettere cure. */
function ulAiuto(){
  let w = document.getElementById('ulAiutoW');
  if (!w){ w = document.createElement('div'); w.id = 'ulAiutoW'; w.className = 'ul-aiuto-w'; w.addEventListener('click', function(e){ if (e.target === w) w.remove(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="ul-aiuto"><div class="ul-onde"><i></i><i></i><span>⚡</span></div><h3>ADHD Mode</h3>'
    + '<p>Con l’ADHD Mode le idee nuove vanno al sicuro nel caveau e si riaprono solo nel Taglia. La testa si calma perché sa che non le perderà, e le idee non ti portano fuori strada. Davanti resta solo l’obiettivo, con l’unica cosa di oggi.</p>'
    + '<p>Progettata per chi ha l’ADHD e per chiunque abbia la testa a 3000 giri. Non è una cura: è un sistema che ti toglie le scappatoie.</p>'
    + '<p class="ul-forte">Accendila, e resta sulla tua strada.</p>'
    + '<button type="button" class="ul-ok" onclick="document.getElementById(\'ulAiutoW\').remove()">HO CAPITO</button></div>';
}

/* ---- a periodo finito: rinnovi, o tutto torna negoziabile ---- */
function ulFineControlla(){
  try{
    const u = ulStato();
    if (!u.on || !u.fino || u.fino > Date.now() || u.chiesta) return;
    if (typeof DEC !== 'undefined' && DEC.open) return;
    if (typeof decOpen !== 'function') return;
    u.chiesta = Date.now(); ulScrivi(UL_KEY, u);
    const g = Math.max(1, u.giorni || 7);
    decOpen('custom', {
      kicker: 'ADHD Mode',
      title: 'IL PATTO<br>È FINITO',
      line: 'Hai tenuto le idee nel caveau fino a oggi. Rinnovi il patto per altri <b>' + g + (g === 1 ? ' giorno' : ' giorni') + '</b>, o lasci che tutto torni negoziabile?<br>Rinnovi: un punto al nuovo te. Lasci andare: un punto al vecchio te.',
      left: 'TORNI<br>NEGOZIABILE', right: 'RINNOVO',
      leftAct: 'ulNegoziabile()', rightAct: 'ulRinnova()',
      foot: 'Siamo ciò che facciamo ripetutamente.'
    });
  }catch(_){ }
}
function ulRinnova(){
  const u = ulStato(); const g = Math.max(1, u.giorni || 7);
  const d = new Date(Date.now() + g * 86400000); d.setHours(21, 0, 0, 0);
  u.on = true; u.fino = d.getTime(); u.at = Date.now(); u.chiesta = 0; u.rinnovi = (u.rinnovi || 0) + 1; u.apriCaveau = false;
  ulScrivi(UL_KEY, u);
  try{ if (typeof mgFocusPoint === 'function') mgFocusPoint('ADHD Mode rinnovata: la parola data è stata mantenuta'); }catch(_){ }
  if (typeof decClose === 'function') decClose();
  toast('Rinnovata fino a ' + ulData(u.fino) + ': +1 al nuovo te');
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
}
function ulNegoziabile(){
  const u = ulStato(); u.on = false; u.apriCaveau = true; ulScrivi(UL_KEY, u);
  try{ if (typeof mgOldPoint === 'function') mgOldPoint('ADHD Mode lasciata andare: tutto torna negoziabile'); }catch(_){ }
  if (typeof decClose === 'function') decClose();
  toast('Tutto torna negoziabile: +1 al vecchio te');
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
}

/* ---- la proposta, solo dopo averci provato da soli ---- */
function ulPropostaControlla(){
  try{
    if (ulAttiva() || (typeof DEC !== 'undefined' && DEC.open) || typeof decOpen !== 'function') return;
    const p = ulLeggi(UL_PROP_KEY, {}) || {};
    if (p.at && Date.now() - p.at < 7 * 86400000) return;
    let motivo = '';
    try{ const r = (typeof dqStato === 'function') ? dqStato().risposte : null; if (r && r.e7q1 && r.e7q1.i === 0 && !p.e7) motivo = 'e7'; }catch(_){ }
    let aperte = 0, lunghe = 0;
    if (!motivo){
      for (let i = 1; i <= 7; i++){
        const day = (typeof mtKey === 'function') ? mtKey(Date.now() - i * 86400000) : ''; if (!day) continue;
        const righe = ulRighe(day); if (righe.length < 6) continue;
        lunghe++;
        try{ const pr = stPriorita(day, righe); if (pr && !stIsDone(pr, day)) aperte++; }catch(_){ }
      }
      if (aperte >= 3) motivo = 'lista';
    }
    if (!motivo) return;
    p.at = Date.now(); if (motivo === 'e7') p.e7 = true; ulScrivi(UL_PROP_KEY, p);
    decOpen('custom', {
      kicker: motivo === 'e7' ? 'Hai detto: a tutto' : 'Il Genio ha notato',
      title: motivo === 'e7' ? 'ALLORA<br>LEGATI ALL’ALBERO' : 'TROPPA CARNE<br>AL FUOCO',
      line: motivo === 'e7'
        ? 'Nel patto hai scritto che per il sogno lasci andare tutto quello che ti rallenta. Le idee nuove sono la prima cosa che rallenta. L’ADHD Mode le tiene nel caveau fino alla data che scegli. Molte persone con l’ADHD la trovano decisiva.'
        : 'Negli ultimi sette giorni la priorità è rimasta aperta <b>' + aperte + ' volte</b>, sotto a una lista lunga. Non è mancanza di volontà: è la novità che vince sulla cosa noiosa. L’ADHD Mode tiene le idee nuove nel caveau e ti lascia davanti solo l’unica cosa. Molte persone con l’ADHD la trovano decisiva.',
      left: 'NON<br>ORA', right: 'LA<br>PROVO',
      leftAct: 'decClose()', rightAct: 'decClose();ulImpApri()',
      foot: 'Pianificare da soli va bene. Finché la lista non vince.'
    });
  }catch(_){ }
}

/* ---------------------------------------------------------------- dentro al foglio */
/* il foglio grande: con l'ADHD Mode accesa e' chiuso, e si scarica tutto nel caveau */
(function(){
  if (typeof stFullOpen !== 'function') return;
  const apriVero = stFullOpen;
  window.stFullOpen = stFullOpen = function(){
    if (ulAttiva()){
      toast('Il foglio grande è chiuso fino a ' + ulData(ulStato().fino) + ': scarica l’idea nel caveau');
      try{ const a = document.getElementById('cvIn'); if (a){ a.scrollIntoView({ behavior: 'smooth', block: 'center' }); setTimeout(function(){ a.focus(); }, 350); } }catch(_){ }
      return;
    }
    /* FUORI ROTTA? (0.9.211) si fotografa il foglio di oggi: alla chiusura si guarda cosa e' stato aggiunto */
    try{ UL.prima = ulRighe(ulOggiK()).slice(); }catch(_){ UL.prima = null; }
    return apriVero.apply(this, arguments);
  };
})();
(function(){
  if (typeof stFullClose !== 'function') return;
  const chiudiVero = stFullClose;
  window.stFullClose = stFullClose = function(){
    const r = chiudiVero.apply(this, arguments);
    setTimeout(ulFuoriRottaControlla, 700);
    return r;
  };
})();
/** Righe nuove nel foglio di oggi mentre la priorita' e' ancora aperta: ti avvicinano, o e' carne al fuoco? */
function ulFuoriRottaControlla(){
  try{
    const prima = UL.prima; UL.prima = null;
    if (!prima || typeof decOpen !== 'function') return;
    const day = ulOggiK(); const ora = ulRighe(day);
    const nuove = ora.filter(function(r){ return prima.indexOf(r) < 0 && r.indexOf('☑') !== 0; });
    if (!nuove.length) return;
    const pr = stPriorita(day, ora); if (!pr || stIsDone(pr, day) || nuove.indexOf(pr) >= 0) return;
    UL.nuove = nuove;
    const elenco = nuove.slice(0, 3).map(function(t){ return '«' + ulEsc(t.replace(/^[☐•\-]\s*/, '').slice(0, 60)) + '»'; }).join(', ') + (nuove.length > 3 ? ' e altre ' + (nuove.length - 3) : '');
    decOpen('custom', {
      kicker: 'Fuori rotta?',
      title: nuove.length === 1 ? 'UNA COSA NUOVA<br>PER OGGI' : nuove.length + ' COSE NUOVE<br>PER OGGI',
      line: 'Hai aggiunto ' + elenco + ' alla giornata di oggi, mentre «' + ulEsc(String(pr).slice(0, 60)) + '» è ancora aperta. Ti avvicinano al sogno, o è carne al fuoco?',
      left: 'NEL<br>CAVEAU', right: 'MI<br>AVVICINANO',
      leftAct: 'ulFuoriCaveau()', rightAct: 'decClose()',
      extra: '<button type="button" class="dec-link ul-tengo" onclick="ulFuoriTengo()">Le tengo lo stesso: un punto al vecchio te</button>',
      foot: 'Ogni cosa in più allontana l’unica cosa.'
    });
  }catch(_){ }
}
function ulFuoriCaveau(){
  const day = ulOggiK(); const n = UL.nuove || [];
  cvAggiungi(n.map(function(t){ return t.replace(/^[☐•\-]\s*/, ''); }).join('\n'), false);
  try{ const r = ulRighe(day).filter(function(x){ return n.indexOf(x) < 0; }); localStorage.setItem('fl_notes_' + day, r.join('\n')); if (typeof fsToccato === 'function') fsToccato(day); }catch(_){ }
  if (typeof decClose === 'function') decClose();
  toast('Al sicuro nel caveau. Davanti resta l’unica cosa');
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
}
function ulFuoriTengo(){
  try{ if (typeof mgOldPoint === 'function') mgOldPoint('Cose nuove aggiunte a oggi con la priorità ancora aperta'); }catch(_){ }
  if (typeof decClose === 'function') decClose();
  toast('Restano nel foglio: +1 al vecchio te');
}

/* le righe di domani, con l'ADHD Mode accesa: si scrivono, non si rileggono */
(function(){
  if (typeof pnDomaniHtml !== 'function') return;
  const vero = pnDomaniHtml;
  window.pnDomaniHtml = pnDomaniHtml = function(){
    if (!ulAttiva()) return vero.apply(this, arguments);
    if (typeof pnDomaniAperto === 'function' && !pnDomaniAperto()) return vero.apply(this, arguments);
    const n = ulRighe(ulDomaniK()).length;
    return '<p class="st-onelbl">Il piano di domani</p>'
      + '<p class="st-vuoto">Con l’ADHD Mode le righe di domani si scrivono a mente fredda e si rileggono domattina, nel Taglia: una sola resterà la priorità.</p>'
      + '<textarea id="ulDomIn" class="fin cv-in" rows="2" placeholder="Una cosa da fare domani…"></textarea>'
      + '<button type="button" class="cta cv-via" onclick="ulDomaniSalva()">Aggiungi a domani</button>'
      + '<p class="cv-conta">' + (n ? '📅 <b>' + n + (n === 1 ? ' riga' : ' righe') + ' per domani</b>, al sicuro fino al Taglia.' : 'Ancora niente per domani.') + '</p>';
  };
})();
function ulDomaniSalva(){
  const a = document.getElementById('ulDomIn'); const v = a ? a.value.trim() : '';
  if (!v){ toast('Scrivi la cosa da fare domani'); return; }
  v.split(/\n+/).map(function(x){ return x.trim(); }).filter(Boolean).forEach(function(x){ ulAggiungiRiga(ulDomaniK(), x); });
  a.value = '';
  try{ flVibra(10); }catch(_){ }
  try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ }
}

/* i controlli: all'apertura e al rientro nell'app */
function ulControlli(){ ulFineControlla(); setTimeout(cvScadenzaControlla, 700); setTimeout(cvUrgenteControlla, 1500); setTimeout(ulPropostaControlla, 3500); }
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(ulControlli, 1800); });
setTimeout(ulControlli, 9000);
setTimeout(cvTimerArma, 9000);
document.addEventListener('fl:tab', function(){ setTimeout(cvScadenzaControlla, 1200); });

(function(){
  const css = [
    '.cv-box{margin:14px 0 4px;padding:16px 14px;border-radius:18px;border:1.5px dashed #9DB7D6;background:rgba(0,117,227,.04)}.cv-box.ul-on{border-style:solid;border-color:#3F9FF4;background:rgba(63,159,244,.08)}body.dark .cv-box{background:rgba(255,255,255,.03);border-color:#2F4A75}',
    '.cv-h{display:flex;align-items:flex-start;gap:10px;margin-bottom:10px}.cv-lock{font-size:24px;line-height:1}.cv-h > div{flex:1}.cv-h b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .cv-h b{color:#fff}.cv-h small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.cv-q{flex:none;width:28px;height:28px;border-radius:50%;border:0;background:rgba(107,122,144,.18);color:var(--navy);font:800 14px var(--font-body);cursor:pointer}body.dark .cv-q{color:#fff;background:rgba(255,255,255,.12)}',
    '.cv-in{display:block;width:100%;box-sizing:border-box;margin:0 0 10px;resize:none;min-height:64px}',
    '.cv-riga{display:flex;align-items:center;gap:10px}.cv-urg{display:flex;align-items:center;gap:6px;font:600 13px var(--font-body);color:var(--navy);cursor:pointer}body.dark .cv-urg{color:#fff}.cv-urg input{width:18px;height:18px;accent-color:#E63946}.cv-via{flex:1;margin:0 !important;padding:12px 14px !important;font-size:14px !important}',
    '.cv-conta{margin:10px 0 0;font:500 13px var(--font-body);color:var(--muted)}.cv-conta b{color:var(--navy)}body.dark .cv-conta b{color:#fff}',
    '.cv-taglia{width:100%;margin-top:12px;padding:12px;border:0;border-radius:14px;background:#001E44;color:#fff;font:800 14px var(--font-body);cursor:pointer}',
    '.st-dots{position:absolute;right:8px;top:6px;z-index:3;width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--navy);font:900 20px var(--font-body);cursor:pointer}body.dark .st-dots{color:#fff}#mppFoglio .st-note{position:relative}',
    '.ul-ora{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:12px;padding:12px 14px;border-radius:14px;background:#F4F8FF}body.dark .ul-ora{background:rgba(255,255,255,.06)}.ul-ora span{font:600 13.5px var(--font-body);color:var(--navy)}body.dark .ul-ora span{color:#fff}.ul-ora .pn-ora{margin:0 !important;width:auto !important;min-width:110px}.ul-scelta{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.ul-scelta button{border:1.5px solid var(--line);border-radius:16px;background:transparent;padding:12px 10px;text-align:left;cursor:pointer}.ul-scelta button.on{border-color:#0075E3;background:#E6F2FF}body.dark .ul-scelta button.on{background:rgba(0,117,227,.18)}.ul-scelta b{display:block;font:800 14px var(--font-body);color:var(--navy)}body.dark .ul-scelta b{color:#fff}.ul-scelta small{display:block;margin-top:3px;font:500 12px/1.35 var(--font-body);color:var(--muted)}.ul-card .blk-swrow{margin-top:12px}.ul-card .pn-ora{margin-top:12px;width:100%}',
    '#ulImpBody,#cvtBody{padding:0 18px}.ul-card{margin-top:16px;padding:18px 16px;border-radius:20px;border:1px solid var(--line);background:var(--card,#fff)}body.dark .ul-card{background:#12203A;border-color:#22345A}.ul-card.on{border-color:#3F9FF4;box-shadow:0 0 0 3px rgba(63,159,244,.18)}',
    '.ul-testa{display:flex;align-items:center;gap:10px}.ul-testa > div{flex:1}.ul-ico{font-size:26px}.ul-testa b{display:block;font:800 17px var(--font-body);color:var(--navy)}body.dark .ul-testa b{color:#fff}.ul-testa small{display:block;margin-top:2px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}.switch.bloccato{opacity:.7}',
    '.ul-p{margin:12px 0 0;font:500 14px/1.55 var(--font-body);color:var(--muted)}.ul-stato{margin:12px 0 0;font:600 14px/1.5 var(--font-body);color:var(--navy)}body.dark .ul-stato{color:#fff}.ul-sez{margin:18px 0 8px;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}',
    '.ul-chips{display:flex;flex-wrap:wrap;gap:8px}.ul-chips button,.ul-data{padding:10px 14px;border:1.5px solid var(--line);border-radius:99px;background:transparent;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}body.dark .ul-chips button,body.dark .ul-data{color:#fff;border-color:#22345A}.ul-chips button.on,.ul-data.on{border-color:#0075E3;background:rgba(0,117,227,.12);color:#0075E3}.ul-data{position:relative;display:inline-flex}.ul-data input{position:absolute;inset:0;opacity:0;cursor:pointer}',
    '.ul-fino{margin:12px 0 0;font:600 13px var(--font-body);color:var(--muted)}.ul-via{width:100%;margin-top:16px}',
    '.ul-aiuto-w{position:fixed;inset:0;z-index:9995;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,0,0,.6)}.ul-aiuto{width:100%;max-width:400px;padding:28px 22px 22px;border-radius:22px;background:#2B2840;color:#fff;text-align:center}',
    '.ul-onde{position:relative;width:120px;height:120px;margin:0 auto 6px;display:flex;align-items:center;justify-content:center}.ul-onde i{position:absolute;border-radius:50%;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04)}.ul-onde i:nth-child(1){inset:0}.ul-onde i:nth-child(2){inset:22px}.ul-onde span{position:relative;width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;font-size:26px}',
    '.ul-aiuto h3{margin:6px 0 12px;font:800 24px var(--font-body);color:#fff}.ul-aiuto p{margin:0 0 12px;font:500 15px/1.55 var(--font-body);color:rgba(255,255,255,.88)}.ul-aiuto .ul-forte{font-weight:800;color:#fff}.ul-ok{width:100%;margin-top:8px;padding:16px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 14px var(--font-body);letter-spacing:.12em;cursor:pointer}',
    '.cvt-bar{height:8px;margin:14px 0 8px;border-radius:99px;background:rgba(230,57,70,.15);overflow:hidden}.cvt-bar i{display:block;height:100%;width:100%;background:#E63946;transition:width .25s linear}.cvt-conta{margin:0 0 16px;text-align:center;font:700 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.cvt-carta{padding:22px 18px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 10px 26px rgba(0,30,68,.1)}body.dark .cvt-carta{background:#12203A;border-color:#22345A}.cvt-carta small{display:block;margin-bottom:8px;font:600 12px var(--font-body);color:var(--muted)}.cvt-img{display:block;max-width:100%;max-height:46vh;margin:0 auto 10px;border-radius:14px}.cvt-carta p{margin:0;font:700 19px/1.4 var(--font-body);color:var(--navy)}body.dark .cvt-carta p{color:#fff}',
    '.cvt-q{margin:22px 0 12px;text-align:center;font:700 15px var(--font-body);color:var(--navy)}body.dark .cvt-q{color:#fff}.cvt-due{display:grid;grid-template-columns:1fr 1fr;gap:12px}.cvt-due button{padding:18px 8px;border-radius:18px;font:800 15px var(--font-body);cursor:pointer}.cvt-due .taglia{border:0;background:#E63946;color:#fff;box-shadow:0 4px 0 #B91C2C}.cvt-due .tieni{border:1.5px solid var(--line);background:var(--card,#fff);color:var(--navy);box-shadow:0 4px 0 var(--line)}body.dark .cvt-due .tieni{background:#12203A;border-color:#22345A;color:#fff}',
    '.cvt-fine{text-align:center;padding-top:30px}.cvt-fine span{font-size:56px}.cvt-fine h2{margin:10px 0 8px;font:800 24px var(--font-display);color:var(--navy)}body.dark .cvt-fine h2{color:#fff}.cvt-fine p{margin:0 auto 12px;max-width:34ch;font:500 15px/1.55 var(--font-body);color:var(--muted)}.cvt-fine .cta{width:100%;margin-top:14px}.cvt-nota{font-size:13px !important}',
    '.dec-link.ul-tengo{display:block;margin:12px auto 0;border:0;background:transparent;color:rgba(255,255,255,.7);font:600 13px var(--font-body);text-decoration:underline;cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
