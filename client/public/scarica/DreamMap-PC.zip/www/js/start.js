/* start.js - la scheda START: il cielo, la partita, la scrematura, la concentrazione.

   Sopra c'è la stessa cornice delle altre schede — la fascia con le nuvole che taglia il cielo
   — e tre diapositive:

     0. il video: "Where attention goes / ENERGY FLOWS". La frase è di movimento e un'immagine
        ferma la racconterebbe male.
     1. IL TABELLONE. La partita vera è contro se stessi: da una parte il vecchio te, dall'altra
        quello nuovo, e il punteggio lo segna la giornata. Chi vince si vede, e questo è il
        punto: senza prove, il vecchio paradigma torna a comandare dicendoti che sei cambiato.
     2. il cielo notturno, lo stesso del Profilo e di Nuovo te: "il resto può aspettare".

   Sotto il cielo, in quest'ordine, e l'ordine è il punto:

     1. LA SCREMATURA — l'esercizio di "The One Thing" di Gary Keller. Si scrive tutto quello
        che sembra da fare, si applica Pareto (il 20% produce l'80%) e si taglia finché non
        resta una cosa sola. Finché non sai QUALE cosa, bloccare il tempo non serve a niente:
        proteggeresti un'ora per fare la cosa sbagliata.

     2. UNA COSA ALLA VOLTA — la legge di Parkinson. Il lavoro si espande fino a riempire il
        tempo che gli lasci, quindi alla priorità scelta sopra si dà un confine: la sessione
        di concentrazione totale. È la porta di FullFocus.

   La spunta della priorità non la mette l'utente: la mette il lavoro. Quando una sessione
   intensiva arriva in fondo, ffFinish chiama stOneComplete(), la priorità va in archivio e
   la giornata chiede la prossima. */

/* ---------- il cielo ---------- */
function stHeroEnsure(){
  const first = !document.getElementById('stHero');
  const out = flHeroEnsure('start', 'tab-sveglia', 'stHero', [
    /* Il tabellone per primo: la prima cosa che si vede aprendo la scheda e' chi sta
       vincendo la partita, non un video. */
    '<article class="bh-slide on" data-i="0">'
    +   '<div class="bh-img"></div><span class="bh-ov"></span>'
    +   '<div class="bh-stack" id="stMatchBox"></div>'
    + '</article>',
    /* La seconda: il tabellone dei PIANI. Il primo dice chi sta vincendo, questo dice da cosa
       dipende — e quella e' l'unica delle due su cui si puo' fare qualcosa stasera. */
    /* LA SECONDA: quella che apriva la Roadmap — la bolla, «Ricordati perche' hai iniziato», il
       mantra e i tre puntini (blkhero.js: sevHeroPaint disegna dentro #sevHeroBox). */
    '<article class="bh-slide" data-i="1">'
    +   '<div class="bh-img"></div><span class="bh-ov"></span>'
    +   '<div class="bh-stack" id="sevHeroBox"></div>'
    + '</article>',
    '<article class="bh-slide" data-i="2">'
    +   '<div class="bh-img"></div><span class="bh-ov"></span>'
    +   '<div class="bh-stack" id="stPlanBox"></div>'
    + '</article>'
  ].concat((typeof stPianoVisibile === 'function' && stPianoVisibile()) ? [
    /* La terza: le notti di fila andate a letto con il piano scritto. Per chi il piano se lo
       scrive da solo — cioe' chi non ha il Premium, dove lo scrive l'agente — e per chi sviluppa. */
    '<article class="bh-slide" data-i="3">'
    +   '<div class="bh-img"></div><span class="bh-ov"></span>'
    +   '<div class="bh-stack" id="stPianoBox"></div>'
    + '</article>'
  ] : []), { tall: true, auto: false });
  if (first){ mtPaint(); if (typeof pbPaint === 'function') pbPaint(); if (typeof stPianoPaint === 'function') stPianoPaint(); }
  return out;
}

/* L'intermezzo fra le due sezioni: una diapositiva sola, senza testo sopra, perche' il testo
   e' gia' dentro. Sta li' per rompere il ritmo — chi scorre due pannelli di fila smette di
   leggerli, e la frase in mezzo e' la sola cosa di questa scheda che non chiede niente. */
/* LE DUE DIAPOSITIVE SI SCAMBIANO OGNI GIORNO.
   Il video in cima ruba la prima occhiata; la frase in cima la ruba il giorno dopo. Chi vede
   sempre la stessa cosa per prima smette di vederla in una settimana: a giorni alterni una
   comincia e l'altra segue. L'ordine lo decide il giorno (citazioni.js: `citGiorno`), quindi
   e' lo stesso per tutta la giornata e cambia da solo a mezzanotte. */
function stVidPrima(){
  const g = (typeof citGiorno === 'function') ? citGiorno() : Math.floor(Date.now() / 86400000);
  return g % 2 === 0;
}
/** Dove sta il video adesso: serve a chi decide se farlo andare. */
function stVidIdx(){ return stVidPrima() ? 0 : 1; }

function stMidEnsure(){
  /* Se il giorno e' cambiato mentre l'app era aperta, l'intermezzo si rifa': altrimenti
     l'ordine nuovo si vedrebbe solo al riavvio. */
  const vecchio = document.getElementById('stMidHero');
  if (vecchio && vecchio.dataset.giorno !== String(stVidPrima() ? 1 : 0)){
    vecchio.remove();
    try{ if (typeof FL_HEROES !== 'undefined'){ clearInterval((FL_HEROES.startmid || {}).timer); delete FL_HEROES.startmid; } }catch(_){ }
  }
  const slideVideo = function(i){
    return '<article class="bh-slide' + (i === 0 ? ' on' : '') + '" data-i="' + i + '">'
      +   '<div class="st-vidwrap"><video class="st-vid" id="stVid" muted playsinline loop preload="auto" poster="video/energy-poster.jpg"><source src="video/energy.mp4" type="video/mp4"></video></div>'
      +   '<span class="bh-ov st-ov"></span>'
      +   '<div class="bh-text">'
      +     '<p class="bh-eyebrow">' + flHeroLine('Dove va l’attenzione', 0) + '</p>'
      +     '<h2 class="bh-title">' + flHeroLine('va l’energia', 1) + '</h2>'
      +   '</div>'
      + '</article>';
  };
  const slideImg = function(i){
    /* 0.9.280, Andrea: "credevo che la frase fosse scritta, non un'immagine: scrivendo la mia finiva sopra".
       Adesso e' testo vero sul fondo scuro: la frase di serie e' quella di Hormozi, la tua la sostituisce. */
    return '<article class="bh-slide st-cit-s' + (i === 0 ? ' on' : '') + '" data-i="' + i + '" style="--bh-img:none">'
      +   '<div class="bh-img"></div>'
      +   '<div class="bh-text st-cit" id="midTesto"></div>'
      + '</article>';
  };
  const prima = stVidPrima();
  const host = flHeroEnsure('startmid', 'tab-sveglia', 'stMidHero',
    prima ? [slideVideo(0), slideImg(1)] : [slideImg(0), slideVideo(1)],
    { into: 'stMid', clouds: false, h: 270, auto: true });
  if (host) host.dataset.giorno = String(prima ? 1 : 0);
  /* I tre puntini: la frase, la rotazione, e ogni quanto. Nessuna velocita' va bene per
     tutti, e una diapositiva che gira mentre stai leggendo e' peggio di una ferma. */
  if (host && !document.getElementById('midDots')){
    host.insertAdjacentHTML('beforeend',
      '<button type="button" class="mid-dots" id="midDots" onclick="midMenuOpen(event)" aria-label="Opzioni">⋯</button>');
  }
  if (typeof midApply === 'function') midApply();
  return host;
}

/* Il video parte solo quando la sua diapositiva è davanti e la scheda è aperta: un video che
   gira dietro a una scheda chiusa è batteria buttata. */
function stVideoSync(){
  const v = document.getElementById('stVid');
  if (!v) return;
  /* Il video adesso e' la prima diapositiva dell'intermezzo, non piu' la seconda del cielo:
     se questa riga fosse rimasta indietro, il video girerebbe quando non si vede e starebbe
     fermo quando si vede — cioe' batteria buttata e un poster immobile. */
  const tabOn = (document.querySelector('.tabpage.on') || {}).id === 'tab-sveglia';
  const slide = (typeof FL_HEROES !== 'undefined' && FL_HEROES.startmid) ? FL_HEROES.startmid.slide : 0;
  /* La diapositiva del video non e' sempre la prima: si scambia con l'altra ogni giorno. */
  const show = tabOn && slide === stVidIdx() && !document.hidden;
  try{ if (show) v.play().catch(function(){}); else v.pause(); }catch(_){ }
}

/* =========================================================================================
   IL TABELLONE — la partita contro se stessi

   Due squadre e un punteggio che si aggiorna da solo, una volta al giorno:

     · chiudi la giornata avendo scelto l'unica cosa del giorno dopo  → punto al NUOVO te
     · te ne dimentichi                                               → punto al VECCHIO te
     · porti a termine una sessione di concentrazione totale          → punto al NUOVO te

   La serie conta i giorni di fila con il piano. Vale la regola dei due giorni: saltarne uno
   è perdonato (due protezioni a settimana), saltarne due di fila no. Il punto al vecchio te
   però viene assegnato lo stesso: la protezione salva la serie, non cancella il fatto.
   ========================================================================================= */
const MT_KEY = 'fl_match';
const MT_PLAN = 'fl_plan_days';
const MT_SAVES_WEEK = 2;
/* Quanto costa una protezione, in punti esperienza.

   Usarla a mano costa poco: vuol dire che la persona ha guardato la giornata, ha visto che non
   ci stava, e l'ha detto. Lasciarla scattare da sola costa quattro volte tanto, perche' quella
   non e' una decisione — e' un giorno passato senza accorgersene, ed e' esattamente la cosa da
   cui l'app dovrebbe proteggere. La differenza non e' una punizione: e' l'unico modo di far
   pesare di piu' il non esserci. */
const SP_TOLL_KEY = 'fl_sp_toll';
const SP_MANUAL_TOLL = 15;
const SP_AUTO_TOLL = 60;

function mtRead(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function mtWrite(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function mtKey(t){ const d = new Date(t); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
/* La settimana serve solo a rimettere le protezioni: basta il lunedì di riferimento. */
function mtWeek(t){ const d = new Date(t); const dow = (d.getDay() + 6) % 7; d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - dow); return mtKey(d.getTime()); }
function mtState(){
  const s = mtRead(MT_KEY, null);
  return s || { old: 0, neo: 0, streak: 0, best: 0, miss: 0, saves: MT_SAVES_WEEK, week: mtWeek(Date.now()), day: mtKey(Date.now()) };
}
/* Il giorno in cui la regola del registro e' stata corretta. Prima di questa data i segni
   sul disco seguono la vecchia convenzione, e vanno letti con quella. */
const MT_PLAN_FIX = '2026-09-17';

function mtGiornoPrima(day){ return mtKey(new Date(day + 'T12:00:00').getTime() - 86400000); }
function mtGiornoDopo(day){ return mtKey(new Date(day + 'T12:00:00').getTime() + 86400000); }

/**
 * Quel giorno e' stato chiuso avendo pianificato?
 *
 * <p>Da oggi il registro segna il giorno in cui si e' pianificato. Prima segnava il giorno
 * PER CUI valeva il piano — cioe' quello dopo — ed e' il motivo per cui un piano scritto la
 * sera faceva comunque segnare il vecchio te a mezzanotte. Per i giorni gia' passati si
 * continua a leggere con la vecchia regola: correggere il futuro non autorizza a cambiare
 * la storia sotto i piedi di chi l'ha vissuta.</p>
 */
function mtPlanned(day){
  const m = mtRead(MT_PLAN, {});
  if (m[day]) return true;
  /* IL PIANO SCRITTO SU UN ALTRO DISPOSITIVO. Il segno stava solo nella memoria del
     dispositivo dove lo si scriveva, mentre il «giorno senza piano» lo calcolava ognuno per
     conto suo e lo condivideva: il computer non aveva il piano del telefono, addebitava il
     giorno, e il telefono riceveva a mezzanotte un punto senza motivo (20/09). */
  try{ if (typeof lsPlanned === 'function' && lsPlanned(day)) return true; }catch(_){ }
  if (day < MT_PLAN_FIX && m[mtGiornoDopo(day)]) return true;
  return false;
}

/* IL RIMBORSO, una volta sola.
   Un punto gia' preso dal vecchio te per un giorno che invece era stato pianificato non si
   puo' lasciare li': il tabellone e' l'unica cosa di quest'app che deve poter essere creduta.
   Si contano solo i giorni che l'arbitro ha GIA' chiuso (quelli prima di s.day), perche' per
   quelli il punto e' certamente stato assegnato; per i giorni ancora aperti non c'e' niente
   da restituire, ci pensera' la regola nuova. */
const MT_FIX_KEY = 'fl_plan_fix_v1';
(function mtRiparaPiani(){
  try{
    if (localStorage.getItem(MT_FIX_KEY)) return;
    localStorage.setItem(MT_FIX_KEY, '1');
    const m = mtRead(MT_PLAN, {});
    const s = mtState();
    const chiusiFinoA = s.day || mtKey(Date.now());
    let primo = '';
    try{ const t = flPrimoAvvio(); if (t) primo = mtKey(t); }catch(_){ }
    let rimborsi = 0;
    Object.keys(m).forEach(function(k){
      if (!m[k] || !/^\d{4}-\d{2}-\d{2}$/.test(k)) return;
      const prima = mtGiornoPrima(k);
      if (prima >= chiusiFinoA) return;      // non ancora chiuso: nessun punto da restituire
      if (primo && prima < primo) return;    // prima dell'app: l'arbitro non c'era
      if (m[prima]) return;                  // quel giorno aveva gia' un segno suo
      rimborsi++;
    });
    if (!rimborsi) return;
    s.old = Math.max(0, (s.old || 0) - rimborsi);
    mtWrite(MT_KEY, s);
  }catch(_){ }
})();

/* ---------- le protezioni serie ---------- */
function spToll(n){
  let cur = 0;
  try{ cur = parseInt(localStorage.getItem(SP_TOLL_KEY) || '0', 10) || 0; }catch(_){ }
  try{ localStorage.setItem(SP_TOLL_KEY, String(cur + n)); }catch(_){ }
  if (typeof lvBump === 'function') try{ lvBump(); }catch(_){ }
}
function spDays(a, b){
  const A = new Date(a + 'T12:00:00'), B = new Date(b + 'T12:00:00');
  return Math.round((A - B) / 86400000);
}
/* Il bordo rosso vale il giorno dopo: la protezione scatta a mezzanotte, e l'unico momento
   utile per accorgersene e' la prima volta che si riapre l'app. */
function spAutoFresh(s){
  if (!s || !s.autoAt) return false;
  const d = spDays(mtKey(Date.now()), s.autoAt);
  return d >= 0 && d <= 1;
}
function spUsedOn(s, day){ return ((s && s.used) || {})[day] || ''; }
/* La protezione usata a mano, per oggi. */
function spUseManual(){
  const s = mtRoll();
  const day = mtKey(Date.now());
  if (s.saves <= 0 || spUsedOn(s, day)) return;
  s.used = s.used || {};
  s.used[day] = 'manual';
  s.saves--;
  mtWrite(MT_KEY, s);
  spToll(SP_MANUAL_TOLL);
  spPaint();
  pnPush();
  toast('Protezione usata: oggi la serie \u00e8 al sicuro');
}
/* Scrivere il piano segna la SERIE, non un punto.

   Il giro prima dava un punto — con tanto di festa — nel momento in cui scrivevi. E' la
   trappola che Huberman e Dweck descrivono da anni: il picco di dopamina arriva sull'intenzione,
   e quando tocca fare la cosa il serbatoio e' gia' vuoto. Un'app che premia prima dello sforzo
   non e' un'app di produttivita', e' un social con un altro nome. Quindi qui: la serie (la
   costanza del pianificare) e una riga discreta. Il punto lo assegna l'arbitro, dopo. */
function mtPlanMark(day){
  const m = mtRead(MT_PLAN, {}); m[day] = 1; mtWrite(MT_PLAN, m);
  try{ if (typeof lsPlanMark === 'function') lsPlanMark(day); }catch(_){ }
  mtRoll();
  mtPaint();
  spPaint();
  /* Il telefono deve saperlo: altrimenti il promemoria della sera suona anche a chi ha gia'
     scritto il piano, e un promemoria che suona a vuoto insegna solo a ignorarlo. */
  pnPush();
}

/* ---------- l'arbitro ----------
   Il punto va al nuovo te solo quando l'app ha VISTO il lavoro: una sessione di FullFocus
   intensiva, portata a termine, con quella riga come intenzione — e' l'unica cosa che il
   motore misura davvero, perche' e' lui a tenere chiuse le altre app. La spunta e' la
   dichiarazione della persona; la sessione e' la prova. Le regole si toccano in Personalizza,
   ma di serie l'arbitro non si fida della parola. */
const REF_KEY = 'fl_ref';
function refRules(){
  const d = { needSession: true, minMin: 25, planBy: '00:00' };
  try{ return Object.assign(d, JSON.parse(localStorage.getItem(REF_KEY) || 'null') || {}); }catch(_){ return d; }
}
function refSave(patch){ const r = Object.assign(refRules(), patch || {}); try{ localStorage.setItem(REF_KEY, JSON.stringify(r)); }catch(_){ } return r; }
/* La sessione che copre una riga: oggi, intensiva, finita bene, abbastanza lunga, con quella
   intenzione. Se ce n'e' una, il punto e' guadagnato. */
function refSessionFor(line, day){
  const r = refRules();
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const want = String(line || '').trim().toLowerCase();
  return h.filter(function(x){
    return x && x.ok && x.intensive && (x.min || 0) >= r.minMin && mtKey(x.at) === day
      && String(x.intent || '').trim().toLowerCase() === want;
  })[0] || null;
}
function mtScore(){
  const s = mtRoll();
  s.neo++;
  mtWrite(MT_KEY, s);
  mtGoal('neo');
  mtPaint();
}

/* ---------- il gol ----------
   Un punto che compare in un tabellone che non stai guardando non premia nessuno. Questa e'
   la sola animazione dell'app che interrompe: dura due secondi e mezzo e dice una cosa sola,
   che quello che hai appena fatto conta. */
const MT_GOAL_LINES = [
  'Fatta, e l\'ho vista fare. Questo il vecchio te non lo puù raccontare diversamente.',
  'Detto, fatto, misurato. È così che si diventa qualcun altro.',
  'Non un\'intenzione: un fatto. I punti qui si danno solo a quelli.',
  'Una cosa finita vale più di dieci cominciate. Segnato.',
  'Il lavoro c\'è stato, e c\'era il timer a dirlo. Punto.'
];
/* Le frasi di quando segna l'altro. Non sono una sgridata: sono il tabellone che dice cosa e'
   appena successo. Un gol subito che nessuno annuncia non e' un gol, e' una cosa che sparisce. */
const MT_GOAL_LINES_OLD = [
  'Segna lui. Non e\' una punizione: e\' quello che e\' appena successo.',
  'Uno a lui. La prossima palla e\' ancora tua.',
  'Il vecchio te ha vinto questo scambio. Uno solo.',
  'Punto per lui. Te lo ricordi stasera, non domani.',
  'Gliel\'hai lasciato. Capita: quello che conta e\' il prossimo.'
];

/* IL GOL SI ANNUNCIA DA TUTTE E DUE LE PARTI.
   Prima questa schermata esisteva solo per il nuovo te, e sempre con la stessa scritta: quando
   segnava l'altro il punteggio cambiava in silenzio, e un tabellone che si muove di nascosto
   non insegna niente. */
function mtGoal(chi){
  /* Sul computer festeggia il programma — cartello sopra a tutto, suono, bagliore sul
     tabellone — cosi' il gol si vede anche a pannello chiuso. La pagina qui tace. */
  if (typeof mgDesktop === 'function' && mgDesktop()) return;
  const cfg = (typeof mgCfg === 'function') ? mgCfg() : {};
  if (cfg.goalSound !== false && typeof mgPlayGoal === 'function') mgPlayGoal();
  if (cfg.goalPopup === false) return;
  const el = document.getElementById('goalWrap');
  if (!el) return;
  const s = mtState();
  const suo = chi === 'old';
  const lista = suo ? MT_GOAL_LINES_OLD : MT_GOAL_LINES;
  const line = lista[(s.neo + s.old) % lista.length];
  /* IL MOTIVO, SCRITTO. Un gol del vecchio te che sparisce in due secondi senza dire perche'
     e' un'accusa senza capo d'imputazione: l'arbitro il motivo lo registra (mgLog), quindi
     si legge da li' e resta a schermo il tempo di leggerlo. */
  let perche = '';
  try{
    const ev = ((typeof mgToday === 'function' ? mgToday() : {}).eventi || []).filter(function(e){ return e.chi === (suo ? 'old' : 'neo'); }).pop();
    if (ev && ev.motivo) perche = ev.motivo;
  }catch(_){ }
  el.innerHTML =
      '<div class="gl-scrim" onclick="mtGoalClose()"></div>'
    + '<div class="gl-card' + (suo ? ' loro' : '') + '" onclick="mtGoalApri(event)">'
    +   '<div class="gl-ico">' + (suo ? '\ud83d\udd73\ufe0f' : '\u26bd') + '</div>'
    +   '<b class="gl-k">' + (suo ? 'Punto per ' + (typeof inVecchio === 'function' ? inVecchio() : 'il vecchio te') : 'Punto per ' + (typeof inNuovo === 'function' ? inNuovo() : 'il nuovo te')) + '</b>'
    +   '<div class="gl-score"><span class="old">' + s.old + '</span><i>\u2013</i><span class="neo">' + s.neo + '</span></div>'
    +   '<p class="gl-p">' + line + '</p>'
    +   (perche ? '<p class="gl-p" style="margin-top:8px;font-weight:700">Motivo: ' + esc(perche) + '</p>' : '')
    +   '<p class="gl-p" style="margin-top:10px;opacity:.8;font-size:12px">Tocca per aprire il registro \u203a</p>'
    + '</div>';
  el.hidden = false;
  el.classList.add('open');
  requestAnimationFrame(function(){ el.classList.add('in'); });
  clearTimeout(MT_GOAL_T);
  /* Il tempo di LEGGERE il motivo, da tutte e due le parti. Un cartello che sparisce in due
     secondi e' un numero che cambia senza spiegazione. */
  MT_GOAL_T = setTimeout(mtGoalClose, 9000);
}
/* Toccare il cartello apre il registro dei punti: la regola, con la data e l'ora. */
function mtGoalApri(ev){
  if (ev && ev.stopPropagation) ev.stopPropagation();
  mtGoalClose();
  try{ if (typeof insApriRegistro === 'function') insApriRegistro(); }catch(_){ }
}
let MT_GOAL_T = 0;
function mtGoalClose(){
  const el = document.getElementById('goalWrap');
  if (!el || !el.classList.contains('open')) return;
  clearTimeout(MT_GOAL_T);
  el.classList.remove('in');
  setTimeout(function(){ el.classList.remove('open'); el.hidden = true; el.innerHTML = ''; }, 240);
}

/* Il conteggio dei giorni passati. Gira a ogni apertura della scheda e recupera anche i giorni
   in cui l'app non è stata aperta: una partita che si ferma quando smetti di guardarla non
   misura niente. */
function mtRoll(){
  const s = mtState();
  const today = mtKey(Date.now());
  if (s.day === today){ mtWrite(MT_KEY, s); return s; }
  let cur = new Date(s.day + 'T12:00:00');
  const end = new Date(today + 'T12:00:00');
  let guard = 0;
  while (guard++ < 400){
    const k = mtKey(cur.getTime());
    if (k === today) break;
    const w = mtWeek(cur.getTime());
    if (w !== s.week){ s.week = w; s.saves = MT_SAVES_WEEK; }
    /* LA GIORNATA SI CHIUDE SULLE SESSIONI, NON SUI PIANI.
       Contava i giorni con un piano scritto, e un piano scritto e non fatto lascia esattamente
       dove si era: si poteva tenere una serie di trenta giorni senza essersi mai mossi. Una
       sessione di concentrazione totale portata a termine e' l'unica cosa qui dentro che
       avvicina alla destinazione, ed e' anche l'unica che non si puo' fingere. Ne basta UNA:
       chi gioca in difficile e ne fa due su cinque si e' mosso piano, non si e' fermato — la
       differenza la paga la data di arrivo (serie.js), non la serie. */
    if ((typeof serSessioniDi === 'function' ? serSessioniDi(k) : 0) > 0){
      s.streak++; s.miss = 0;
      if (s.streak > s.best) s.best = s.streak;
    } else {
      /* Un giorno senza piano. Se la persona aveva gia' speso una protezione a mano per quel
         giorno, il conto e' chiuso: era la stessa protezione, l'ha solo usata prima e a occhi
         aperti. Altrimenti scatta da sola, e costa di piu'. */
      const mark = spUsedOn(s, k);
      s.miss++;
      /* IL PUNTO, E IL MOTIVO. Chi ha rifiutato la chiamata con «oggi non posso» il punto
         l'ha gia' preso in quel momento: qui non si ripete. Chi non ha risposto per tutto il
         giorno lo prende adesso, e il registro dice esattamente questo. */
      let risposta = '';
      try{ risposta = (typeof dcoStato === 'function') ? (dcoStato()[k] || '') : ''; }catch(_){ }
      /* NIENTE PUNTO AL VECCHIO TE per il giorno senza piano: il piano lo scrive il Genio, non
         Andrea (vedi lsGiorniValidi). La serie e le protezioni qui sotto restano: sono la
         contabilita' dei giorni, non un giudizio. */
      void risposta;
      if (s.miss >= 2) s.streak = 0;
      else if (mark === 'manual'){ /* gia' pagata, e a prezzo ridotto */ }
      else if (s.saves > 0){
        s.saves--;
        s.used = s.used || {};
        s.used[k] = 'auto';
        s.autoAt = k;
        spToll(SP_AUTO_TOLL);
      }
      else s.streak = 0;
    }
    cur = new Date(cur.getTime() + 86400000);
    if (cur > end) break;
  }
  s.day = today;
  if (mtWeek(Date.now()) !== s.week){ s.week = mtWeek(Date.now()); s.saves = MT_SAVES_WEEK; }
  mtWrite(MT_KEY, s);
  return s;
}
/* Una sessione di concentrazione totale portata a termine vale un punto: è una prova, non una
   promessa, ed è di prove che il nuovo te ha bisogno per esistere. */
/* Un punto al vecchio te: lo segna chi interrompe un blocco o ferma il blocco rapido.
   Non e' una multa, e' il tabellone che registra chi ha vinto quello scambio. */
function mtOldPoint(){
  const s = mtRoll();
  s.old++;
  mtWrite(MT_KEY, s);
  mtGoal('old');
  mtPaint();
}
function mtFocusPoint(){
  const s = mtRoll();
  s.neo++;
  mtWrite(MT_KEY, s);
  mtGoal('neo');
  mtPaint();
}

/* IL PUNTEGGIO ESCE DALL'APP.

   Un tabellone che si vede solo aprendo la scheda START serve la meta': quando stai perdendo
   tempo, la scheda START non ce l'hai davanti — hai davanti la cosa che te lo sta rubando. Da
   qui il punteggio va fuori, a chi lo sa mostrare sopra a tutto il resto: la finestrella sempre
   in vista sul computer, la bolla sul telefono. Parte solo quando il risultato CAMBIA, cosi'
   quello che si vede comparire e' un gol, non un aggiornamento. */
let MT_SENT = null;

/* IL TABELLONE CHE RESTA.

   Quattro secondi sono giusti per un gol e non bastano per il resto: quando stai per aprire
   la cosa che ti frega, il punteggio deve essere gia' li'. Bloccato, la pillola resta sullo
   schermo sopra a qualsiasi app finche' non la spegni — esattamente come la finestrella sul
   computer, cosi' i due si somigliano anche in questo.

   La scelta sta nel localStorage con il prefisso fl_, quindi viaggia con il backup: un
   telefono nuovo ritrova il tabellone dov'era. */
function mtPin(){ try{ return localStorage.getItem('fl_score_pin') === '1'; }catch(_){ return false; } }
function mtPinSet(on){ try{ localStorage.setItem('fl_score_pin', on ? '1' : '0'); }catch(_){ } }

function mtPinToggle(){
  const on = !mtPin();
  mtPinSet(on);
  MT_SENT = null;                     // il prossimo invio deve partire anche a punteggio fermo
  try{ mtBroadcast(mtRoll()); }catch(_){ }
  if (!on){
    /* Spegnere deve togliere la pillola SUBITO, non al prossimo gol. */
    try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.scoreBubble) NATIVE.scoreBubble({ old: 0, neo: 0, goal: '', pin: false, hide: true }); }catch(_){ }
    try{ if (window.focusdesk && window.focusdesk.score) window.focusdesk.score({ pin: false, hide: true }); }catch(_){ }
  }
  try{ mtPaint(); }catch(_){ }
  if (typeof toast === 'function') toast(on ? 'Tabellone sempre in vista' : 'Tabellone solo quando cambia il punteggio');
}

function mtBroadcast(s){
  if (!s) return;
  /* Il tabellone sull'account: quello che e' cambiato QUI diventa il contributo di questo
     dispositivo, e parte verso gli altri. Passa di qui perche' questo e' l'unico punto da cui
     un punteggio cambiato esce davvero dall'app. */
  try{ if (typeof lsSeen === 'function') lsSeen(s); }catch(_){ }
  const cur = s.old + ':' + s.neo;
  if (MT_SENT === cur && !mtPin()) return;
  let goal = '';
  if (MT_SENT !== null){
    const p = MT_SENT.split(':');
    if (s.neo > +p[1]) goal = 'neo';
    else if (s.old > +p[0]) goal = 'old';
  }
  MT_SENT = cur;
  /* Il minuto viaggia con il punteggio: il tabellone sopra le altre app e quello sul
     computer lo mostrano accanto ai numeri, come un punteggio in diretta. */
  /* E con il punteggio viaggia anche il VESTITO della bolla. Mandarlo qui, invece che
     farlo leggere al motore dalle sue preferenze, ha un motivo preciso: la bolla compare
     anche quando l'app non e' aperta e nessuno le ha detto niente da ore — l'ultimo invio
     valido e' l'unica cosa su cui puo' contare, e deve essere completo. */
  const payload = { old: s.old, neo: s.neo, goal: goal, pin: mtPin(),
                    minute: (typeof koLabel === 'function') ? koLabel() : '',
                    skin: (typeof slSkin === 'function') ? slSkin() : '',
                    emojiOld: (typeof SETTINGS !== 'undefined' && SETTINGS.scoreEmojiOld) || '',
                    emojiNeo: (typeof SETTINGS !== 'undefined' && SETTINGS.scoreEmojiNeo) || '',
                    imgOld: (typeof SETTINGS !== 'undefined' && SETTINGS.scoreImgOld) || '',
                    imgNeo: (typeof SETTINGS !== 'undefined' && SETTINGS.scoreImgNeo) || '',
                    tint: (typeof slTint === 'function') ? slTint() : '' };
  /* E al computer di casa, se e' stato collegato: il tabellone e' uno solo. */
  try{ if (typeof mgSendScore === 'function') mgSendScore(payload); }catch(_){ }
  try{ if (window.focusdesk && window.focusdesk.score) window.focusdesk.score(payload); }catch(_){ }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.scoreBubble) NATIVE.scoreBubble(payload); }catch(_){ }
}
/* Anche all'avvio, cosi' il tabellone non parte da zero-zero mentre la partita e' in corso. */
setTimeout(function(){ try{ mtBroadcast(mtRoll()); }catch(_){ } }, 3000);

/* IL TABELLONE NON RIFA L'ENTRATA A OGNI CAMBIO DI SCHEDA.
   Le schede spente stanno in display:none, e un elemento che torna visibile riparte con le
   sue animazioni: ogni volta che si apriva START il punteggio rientrava da capo, anche se era
   lo stesso di un minuto prima. L'entrata adesso si vede solo quando il punteggio e' davvero
   cambiato dall'ultima volta che e' stato sotto gli occhi (fl_mt_visto); altrimenti il
   tabellone e' gia' li', fermo. */
const MT_VISTO_KEY = 'fl_mt_visto';
function mtVistoKey(s){ return String(s.old) + ':' + String(s.neo); }
/* 0.9.300, Andrea: "l'animazione dello score nella prima slide non c'e' mai: metti la stessa della seconda".
   Il "visto" era salvato per sempre: lo stesso punteggio non rientrava piu'. Ora vale per una visita sola:
   entrando in START o tornando sulla prima slide il tabellone rientra come "Ricordati perche' hai iniziato";
   i ridisegni durante la stessa visita restano fermi. */
let MT_VISTO_MEM = '';
function mtVistoGet(){ return MT_VISTO_MEM; }
function mtVistoSegna(){
  const box = document.getElementById('stMatchBox');
  if (!box || !box.dataset.punti || box.offsetParent === null || document.hidden) return;
  MT_VISTO_MEM = box.dataset.punti;
}
function mtRientra(){ MT_VISTO_MEM = ''; mtPaint(); }
function mtPaint(){
  const s = mtRoll();
  mtBroadcast(s);
  const box = document.getElementById('stMatchBox');
  if (!box) return;
  const punti = mtVistoKey(s);
  const fermo = punti === mtVistoGet();
  box.dataset.punti = punti;
  box.classList.toggle('mt-fermo', fermo);
  const hero = document.getElementById('stHero');
  if (hero) hero.classList.toggle('mt-fermo', fermo);
  /* visto davvero solo se adesso e' davanti: altrimenti l'entrata resta per quando lo sara' */
  if (!fermo) setTimeout(mtVistoSegna, 50);
  const lead = s.neo - s.old;
  /* Niente frase quando non c'e' niente da dire. Uno che legge 0 a 0 sa gia' che siete pari:
     scriverglielo sotto e' una didascalia che ruba spazio al tabellone. */
  const line = lead > 0 ? 'Stai vincendo tu.' : (lead < 0 ? 'È avanti il vecchio te.' : '');
  const t1 = 'Il vecchio te segna ogni giorno che finisce senza che tu abbia scelto l\'unica cosa del giorno dopo.\n\nNon è una punizione: è la prova che il paradigma di prima ha ripreso il volante mentre guardavi altrove.';
  const t2 = 'Il nuovo te segna ogni giorno che chiudi con il piano del giorno dopo, e ogni sessione di concentrazione totale portata a termine.\n\nSerie attuale: ' + s.streak + (s.streak === 1 ? ' giorno' : ' giorni') + '.\nIl tuo record: ' + s.best + (s.best === 1 ? ' giorno' : ' giorni') + '.';
  box.innerHTML =
      /* la matita (0.9.186): apre «Personalizza START»; le regole restano nel link qui sotto */
      '<button type="button" class="mt-more mt-edit" onclick="scsApri()" aria-label="Personalizza START">✎</button>'
    + '<p class="mt-eyebrow sev-rise" style="--d:.1s">La partita vera</p>'
    + '<h2 class="mt-title sev-rise" style="--d:.22s">Contro te stesso</h2>'
    + '<div class="pf-opal mt-board">'
    /* 0.9.293, Andrea: "cliccando sullo score si va dritti alla pagina della partita"; la (i) apre ancora la spiegazione */
    +   '<div class="pf-stat sev-rise" style="--d:.5s" onclick="if(event.target.closest(\'i.q\'))scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t1)) + ');else if(typeof paApri===\'function\')paApri()">'
    +     '<span class="ico glow-red">' + ((typeof slCrestTag === 'function') ? slCrestTag('Old', 46) : '🕳️') + '</span>'
    +     '<b class="num red">' + s.old + '</b><small>IL VECCHIO TE<i class="q">i</i></small></div>'
    +   '<div class="mt-dash sev-rise" style="--d:.62s" onclick="if(typeof paApri===\'function\')paApri()">&#8211;</div>'
    +   '<div class="pf-stat sev-rise" style="--d:.74s" onclick="if(event.target.closest(\'i.q\'))scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(t2)) + ');else if(typeof paApri===\'function\')paApri()">'
    +     '<span class="ico glow-neo">' + ((typeof slCrestTag === 'function') ? slCrestTag('Neo', 46) : '🚀') + '</span>'
    +     '<b class="num neo">' + s.neo + '</b><small>IL NUOVO TE<i class="q">i</i></small></div>'
    + '</div>'
    /* I giorni di fila con il piano sono passati al tabellone dei piani, che e' il loro:
       qui sotto restava una didascalia che parlava di un'altra partita. */
    + (line ? '<p class="mt-line sev-rise" style="--d:.9s">' + line + '</p>' : '')
    + mtTempoHtml()
    + '<button type="button" class="mt-rules" onclick="mgOpen()">Regole della partita ›</button>';
}

/* =========================================================================================
   IL FOGLIO BIANCO

   La prima cosa della scheda non chiede di scegliere: chiede solo di scrivere. Scegliere
   l'unica cosa fra dieci e' un esercizio, e un esercizio in cima a una pagina mette pressione
   a chi apre l'app per fare il contrario — togliersela. Qui c'e' un foglio, come nell'app
   delle note, e la prima riga e' quella che vale: diventa la sessione di FullFocus, nei due
   sensi. Scrivi qui e la ritrovi la'; la cambi la' e cambia qui.
   ========================================================================================= */
const ST_NOTES_KEY = 'fl_notes';
const ST_DONE_KEY = 'fl_notes_done';
/* Il foglio ha un giorno: OGGI o DOMANI. Pianificare il giorno dopo e' la disciplina che la
   serie misura, e va tenuta separata dallo scrivere quello che si sta gia' facendo. */
const STN = { day: 'today', tab: 'oggi' };
function stDayKey(which){ return mtKey(Date.now() + ((which || STN.day) === 'tomorrow' ? 86400000 : 0)); }
function stNotes(which){
  const k = ST_NOTES_KEY + '_' + stDayKey(which);
  try{
    let v = localStorage.getItem(k);
    if (v === null && (which || STN.day) === 'today'){
      /* il foglio unico dei giri precedenti diventa quello di oggi, una volta sola */
      v = localStorage.getItem(ST_NOTES_KEY) || '';
      localStorage.setItem(k, v); localStorage.removeItem(ST_NOTES_KEY);
    }
    return v || '';
  }catch(_){ return ''; }
}
function stNotesSave(v, which){
  try{ localStorage.setItem(ST_NOTES_KEY + '_' + stDayKey(which), v); }catch(_){ }
  /* l'ora dell'ultima scrittura, per il foglio che viaggia (foglio-sync.js) */
  try{ if (typeof fsToccato === 'function') fsToccato(stDayKey(which)); }catch(_){ }
}

/* ---------- IL VAR DEL FOGLIO ----------
   Una riga vale come passo solo se sta SULLA ROTTA: se parla della stessa cosa della prossima
   tappa scritta negli Orizzonti, del sogno, o degli orizzonti stessi. Le altre righe non si
   buttano: restano nel foglio, sotto un cassetto, con un'etichetta (urgente / altro). Il
   punto si prenota solo con una riga sulla rotta: il Genio semplifica, e lascia in vista il
   prossimo passo che conta. Senza rotta scritta (nessun orizzonte, nessun sogno) non c'è VAR,
   e tutto vale: giudicare senza un metro sarebbe inventare. */
const ST_STOP = ['della','delle','dello','degli','nella','nelle','sulla','sulle','come','anche','quello','quella','questo','questa','fare','cosa','cose','oggi','domani','ancora','sempre','tutto','tutti','dove','quando','perche','essere','avere','minuti','minuto','poi','prima','dopo','verso','primo','prima','passo','telefono','chiuso'];
function stParole(s){
  return (String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').match(/[a-z0-9]{4,}/g) || [])
    .filter(function(w){ return ST_STOP.indexOf(w) < 0; });
}
function stMissione(){
  try{
    if (typeof ozAnello !== 'function') return null;
    const ord = ['adesso', 'oggi', 'settimana', 'mese', 'anno', 'cinque', 'ungiorno'];
    for (let i = 0; i < ord.length; i++){
      const a = ozAnello(ord[i]);
      const p = (a.passi || []).filter(function(x){ return x && !x.fatto && x.t; })[0];
      if (p) return { t: p.t, k: ord[i] };
    }
  }catch(_){ }
  return null;
}
let ST_ROTTA_CACHE = { at: 0, w: [] };
function stRotta(){
  if (Date.now() - ST_ROTTA_CACHE.at < 3000) return ST_ROTTA_CACHE.w;
  let out = [];
  try{
    const d = (typeof gnDati === 'function') ? gnDati() : null;
    if (d){ out = out.concat(stParole(d.sognoTesto || ''), stParole((d.sogno || '').replace(/^[^ ]+ /, ''))); }
  }catch(_){ }
  try{
    if (typeof ozAnello === 'function') ['adesso', 'oggi', 'settimana', 'mese', 'anno', 'cinque', 'ungiorno'].forEach(function(k){
      const a = ozAnello(k);
      out = out.concat(stParole(a.testo));
      (a.passi || []).forEach(function(p){ if (p && !p.fatto) out = out.concat(stParole(p.t)); });
    });
  }catch(_){ }
  ST_ROTTA_CACHE = { at: Date.now(), w: out };
  return out;
}
function stAllineata(line){
  const R = stRotta();
  if (!R.length) return true;
  const w = stParole(line);
  return w.some(function(x){
    return R.some(function(r){ return r === x || (x.length >= 5 && r.length >= 5 && (r.slice(0, 5) === x.slice(0, 5))); });
  });
}
/* ---------- LA MATRICE ----------
   Due domande sole, quelle di Eisenhower: questa cosa mi avvicina al sogno (importante), e
   ha una scadenza addosso (urgente)? Importante lo dice la rotta — le parole in comune con
   il sogno e con le tappe scritte. Urgente lo dice la riga stessa.

   I quattro esiti non sono etichette decorative: dicono cosa farne. Il quadrante che conta
   e' il secondo — importante e non urgente — perche' e' l'unico in cui si costruisce
   qualcosa invece di spegnere incendi. */
const ST_URG = /\b(entro|scadenz|urgent|subito|stasera|deadline|alle \d|ore \d|oggi\b)/i;
const ST_QUAD = {
  fai:     { t: '\ud83d\udd25 Fai subito',      cls: 'q1', spiega: 'Ti avvicina al sogno, e ha una scadenza addosso.' },
  passo:   { t: '\ud83c\udfaf Il passo che conta', cls: 'q2', spiega: 'Ti avvicina al sogno. Nessuno te la chiede: e\u2019 per questo che vale.' },
  sbriga:  { t: '\u26a1 Urgente, ma non ti avvicina', cls: 'q3', spiega: 'Va fatta in fretta e chiusa. Non \u00e8 la cosa di oggi.' },
  aspetta: { t: '\ud83d\udce6 Pu\u00f2 aspettare', cls: 'q4', spiega: 'Non ti avvicina e non scade. Tienila scritta, falla quando avanza tempo.' }
};
function stEtichetta(line){
  const imp = stAllineata(line), urg = ST_URG.test(line);
  const k = imp ? (urg ? 'fai' : 'passo') : (urg ? 'sbriga' : 'aspetta');
  return Object.assign({ k: k, importante: imp, urgente: urg }, ST_QUAD[k]);
}
function stAltroAperto(){ try{ return localStorage.getItem('fl_notes_altro') === '1'; }catch(_){ return false; } }
function stAltroToggle(el){ try{ localStorage.setItem('fl_notes_altro', el.open ? '1' : '0'); }catch(_){ } }
/* ---------- LE SEZIONI DEL FOGLIO ----------
   Le stesse cinque del suo Notion, nello stesso ordine: la priorita' assoluta (una riga sola:
   il 20% che fa l'80%), l'importante, le scadenze, le idee, e le completate. La sezione la
   decide la matrice (importante = sulla rotta, urgente = le parole della riga), a meno che
   la persona non l'abbia spostata a mano dalla pagina della riga. */
const ST_SEZIONI = [
  ['one',   'La priorit\u00e0 assoluta',    'il 20% che fa l\u201980%'],
  ['imp',   'Importante',                   'dopo la priorit\u00e0'],
  ['scad',  'Scadenze e appuntamenti',      'urgenti, non tue'],
  ['idee',  'Non urgente',                  'idee per il futuro'],
  ['fatte', 'Completate',                   'successi']
];
function stRigheDi(day){
  try{ return (localStorage.getItem('fl_notes_' + day) || '').split('\n').map(function(t){ return t.trim(); }).filter(Boolean); }
  catch(_){ return []; }
}
function stSezManuale(line, day){ const m = stMeta(line, day); return m.sez || ''; }
/* LA PRIORITA' DEL GIORNO: una riga sola. Quella messa a mano; altrimenti la prima importante
   e urgente; altrimenti il primo passo che conta; altrimenti la prima scritta. */
/* ---------------------------------------------------------------------------------------
   LA PRIORITA' DI OGGI VIENE DALLA ROADMAP.
   Prima era la prima riga del foglio che cominciava con un verbo: e il foglio di oggi e' la
   pagina di Notion, con dentro righe scritte a mano anche anni fa. Cosi' la «sola cosa» di oggi
   era «Creare creative x giveaway» del 2023 invece di un passo della rotta. Adesso: il primo
   passo aperto dell'orizzonte «Oggi»; se oggi e' vuoto, quello di «Questa settimana», poi
   «Questo mese». E' anche la pianificazione del giorno dopo: quando un passo si chiude, il
   successivo della roadmap prende il suo posto, senza che nessuno debba scriverlo.
   --------------------------------------------------------------------------------------- */
const ST_RM_LIVELLI = ['oggi', 'settimana', 'mese'];
function stNormRiga(t){ return String(t || '').replace(/^[☐☑•]\s*/, '').trim().toLowerCase().replace(/\s+/g, ' '); }
/** Il prossimo passo della roadmap: { livello, indice, testo }, o null. */
function stPassoRoadmap(){
  try{
    if (typeof ozAnello !== 'function') return null;
    for (let i = 0; i < ST_RM_LIVELLI.length; i++){
      const k = ST_RM_LIVELLI[i];
      const passi = ozAnello(k).passi || [];
      for (let j = 0; j < passi.length; j++){
        const p = passi[j];
        if (p && p.t && !p.fatto) return { livello: k, indice: j, testo: String(p.t).trim() };
      }
    }
  }catch(_){ }
  return null;
}
/** Il passo della roadmap entra in cima al foglio di oggi, se non c'e' gia'. */
function stRoadmapNelFoglio(day){
  const p = stPassoRoadmap();
  if (!p) return null;
  day = day || stDayKey('today');
  if (day !== stDayKey('today')) return p;
  const righe = stRigheDi(day);
  const n = stNormRiga(p.testo);
  if (righe.some(function(r){ return stNormRiga(r) === n; })) return p;
  if (stDone().some(function(d){ return d && d.day === day && stNormRiga(d.text) === n; })) return p;
  try{
    localStorage.setItem('fl_notes_' + day, [p.testo].concat(righe).join('\n'));
    if (typeof fsToccato === 'function') fsToccato(day);
  }catch(_){ }
  return p;
}
function stPriorita(day, righe){
  const rows = righe || stRigheDi(day);
  const vive = rows.filter(function(r){ return !stIsDone(r, day); });
  if (!vive.length) return '';
  const man = vive.filter(function(r){ return stSezManuale(r, day) === 'one'; })[0];
  if (man) return man;
  const rm = stPassoRoadmap();
  if (rm){
    const n = stNormRiga(rm.testo);
    const riga = vive.filter(function(r){ return stNormRiga(r) === n; })[0];
    if (riga) return riga;
  }
  const auto = vive.filter(function(r){ return !stSezManuale(r, day); });
  const fai = auto.filter(function(r){ return stEtichetta(r).k === 'fai'; })[0];
  if (fai) return fai;
  const passo = auto.filter(function(r){ return stEtichetta(r).k === 'passo'; })[0];
  if (passo) return passo;
  return auto[0] || vive[0];
}
function stSezione(line, day, righe){
  if (stIsDone(line, day)) return 'fatte';
  if (line === stPriorita(day, righe)) return 'one';
  const man = stSezManuale(line, day);
  if (man && man !== 'one') return man;
  const k = stEtichetta(line).k;
  return (k === 'fai' || k === 'passo') ? 'imp' : (k === 'sbriga' ? 'scad' : 'idee');
}
function stSezNome(k){ const s = ST_SEZIONI.filter(function(x){ return x[0] === k; })[0]; return s ? s[1] : ''; }
function stLines(which){ return stNotes(which).split('\n').map(function(t){ return t.trim(); }).filter(Boolean); }
function stDone(){ try{ return JSON.parse(localStorage.getItem(ST_DONE_KEY) || '[]') || []; }catch(_){ return []; } }

/* LA PULIZIA, una volta sola: i doppioni gia' scritti vanno tolti, altrimenti il conto di
   oggi resta sbagliato per sempre. Si tiene la prima spunta di ogni riga, che e' quella con
   l'ora giusta. */
(function stPuliscoDoppioni(){
  const K = 'fl_notes_done_dedup';
  try{
    if (localStorage.getItem(K)) return;
    localStorage.setItem(K, '1');
    const d = stDone();
    const visti = {}, out = [];
    d.forEach(function(x){
      if (!x || !x.day || !x.text) return;
      const k = x.day + '\u0000' + x.text;
      if (visti[k]) return;
      visti[k] = 1; out.push(x);
    });
    if (out.length !== d.length) localStorage.setItem(ST_DONE_KEY, JSON.stringify(out));
  }catch(_){ }
})();
function stIsDone(line, day){ const w = line.trim().toLowerCase(); return stDone().some(function(d){ return d.day === day && d.text === w; }); }
/* La riga che conta: la prima di oggi non ancora spuntata. */
function stTask(){
  return stPriorita(stDayKey('today'), stLines('today')) || '';
}
/* Il legame con FullFocus, in tutti e due i versi. */
/* La bandierina di una apertura sola: chi fa partire una sessione con un obiettivo gia'
   deciso la alza, e la prima ffOpen() la legge e la abbassa. */
let ST_FF_SALTA = false;
function stSaltaSync(){ ST_FF_SALTA = true; }

function stSyncToFF(){
  if (typeof ffPref !== 'function') return;
  /* VINCE L'ULTIMO CHE HA SCELTO, non sempre il foglio.
     Questo sincronismo serve quando FullFocus si apre dalla scheda START: li' l'unica cosa del
     giorno e' quella scritta nel foglio. Ma se la sessione parte da una card, la scelta e'
     stata fatta un istante prima ed e' piu' recente: sovrascriverla voleva dire dire a chi ha
     scelto «Lettura» che stara' facendo tutt'altro. */
  if (ST_FF_SALTA){ ST_FF_SALTA = false; return; }
  const t = stTask();
  try{
    const p = ffPref();
    if (p.intent !== t){ p.intent = t; ffSavePref(); if (typeof ffPaint === 'function' && document.getElementById('ffIntent')) ffPaint(); }
  }catch(_){ }
}
function stSyncFromFF(text){
  const t = String(text || '').trim();
  const rows = stNotes('today').split('\n');
  let i = 0;
  while (i < rows.length && !rows[i].trim()) i++;
  if (i < rows.length) rows[i] = t; else rows.push(t);
  stNotesSave(rows.join('\n'), 'today');
  if (STN.day === 'today'){ const box = document.getElementById('stNotes'); if (box) box.value = stNotes('today'); }
  stNoteFoot(); stListPaint();
}
let ST_NOTE_T = 0;
/* Il campo in cima e' una RIGA DA AGGIUNGERE, non il foglio.
   Prima era il foglio: quello che scrivevi restava li' e ricompariva sotto come casella, e la
   stessa frase si leggeva due volte a due centimetri di distanza. Adesso scrivi, premi invio,
   la riga scende nell'elenco e il campo torna vuoto — come in qualunque lista di cose da fare.
   Il foglio intero, per chi vuole scrivere di seguito, si apre a tutto schermo. */
function stNotesInput(){
  const box = document.getElementById('stNotes');
  if (!box) return;
  stNoteGrow(box);
  /* Invio dentro al testo (o dettatura che finisce con un a capo): la riga si stacca. */
  if (box.value.indexOf('\n') >= 0) stNotesCommit();
}
function stNotesCommit(){
  const box = document.getElementById('stNotes');
  if (!box) return;
  const add = box.value.split('\n').map(function(t){ return t.trim(); }).filter(Boolean);
  box.value = '';
  stNoteGrow(box);
  if (!add.length) return;
  const cur = stLines();
  const nuove = [];
  add.forEach(function(t){ if (cur.indexOf(t) < 0){ cur.push(t); nuove.push(t); } });
  stNotesSave(cur.join('\n'));
  /* IL FOGLIO NON PUO' CAMBIARE FORMA, MA PUO' LASCIARE UN'OMBRA.
     Il foglio e' una stringa per giorno, riscritta intera a ogni modifica: dentro non c'e' posto
     per un'ora, e cambiarne il formato vorrebbe dire toccare schermata di blocco, promemoria e
     widget che lo leggono cosi'. Il registro parallelo costa niente e risponde alla domanda che
     conta davvero: a che ora, di solito, questa persona decide la sua giornata? Chi scrive il
     piano alle 23 e chi lo scrive alle 8 non sono la stessa persona. */
  try{
    if (nuove.length){
      const reg = JSON.parse(localStorage.getItem('fl_notes_log') || '[]') || [];
      nuove.forEach(function(t){ reg.push({ at: Date.now(), t: t, k: 'scritta' }); });
      localStorage.setItem('fl_notes_log', JSON.stringify(reg.slice(-600)));
    }
  }catch(_){ }
  stListPaint(); stNoteFoot(); stSyncToFF(); stPlanned();
  try{ document.dispatchEvent(new CustomEvent('fl:piano', { detail: { day: stDayKey(), righe: cur.length } })); }catch(_){ }
}
/* La riga si toglie dall'elenco: scritta per sbaglio, o cambiata idea. */
function stRowDel(i){
  const rows = stLines();
  const via = rows[i];
  try{
    const reg = JSON.parse(localStorage.getItem('fl_notes_log') || '[]') || [];
    reg.push({ at: Date.now(), t: via || '', k: 'tolta' });
    localStorage.setItem('fl_notes_log', JSON.stringify(reg.slice(-600)));
  }catch(_){ }
  rows.splice(i, 1);
  stNotesSave(rows.join('\n'));
  stListPaint(); stNoteFoot(); stSyncToFF();
}
/* Il piano scritto segna la serie — e solo se arriva entro l'ora limite dell'arbitro, quando
   e' per domani. Un piano per domani scritto alle due di notte non e' pianificare: e' non
   dormire. Niente punto qui, niente festa: una riga sola. */
function stPlanned(){
  if (!stLines().length) return;
  if (!stLines().some(stAllineata)){
    stNoteHint('Salvata nel cassetto. Non \u00e8 un passo della tua rotta: il punto non si prenota.');
    return;
  }
  const day = stDayKey();
  if (STN.day === 'tomorrow'){
    const r = refRules();
    const lim = String(r.planBy || '00:00').split(':');
    const now = new Date();
    const limMin = (+lim[0] || 0) * 60 + (+lim[1] || 0);
    const nowMin = now.getHours() * 60 + now.getMinutes();
    /* 00:00 vuol dire "entro mezzanotte", cioe' tutto il giorno; un'altra ora e' un limite vero */
    if (limMin > 0 && nowMin >= limMin){ stNoteHint('Dopo le ' + r.planBy + ' il piano di domani non conta per la serie.'); return; }
  }
  /* IL REGISTRO SEGNA OGGI, anche quando il piano e' per domani: la disciplina che il
     tabellone misura e' «ho chiuso la giornata avendo deciso», e quella succede adesso. */
  const segna = mtKey(Date.now());
  if (mtPlanned(segna)) return;
  mtPlanMark(segna);
  stNoteHint(STN.day === 'tomorrow' ? 'Domani ha un piano. La serie lo sa.' : 'Segnato. Adesso il punto si guadagna facendolo.');
}
let ST_HINT_T = 0;
function stNoteHint(t){
  const el = document.getElementById('stNoteHint');
  if (!el) return;
  el.textContent = t; el.classList.add('on');
  clearTimeout(ST_HINT_T); ST_HINT_T = setTimeout(function(){ el.classList.remove('on'); }, 3600);
}
function stNoteGrow(box){
  if (!box) return;
  box.style.height = 'auto';
  box.style.height = Math.max(box.id === 'stFull' ? 200 : 32, box.scrollHeight) + 'px';
}
function stNoteFoot(){
  /* Era «In FullFocus la prossima sessione si chiamera' …»: superfluo e ingombrante sotto alla
     priorita'. La sessione prende il nome della priorita' da sola, non serve dirlo. */
  const el = document.getElementById('stNoteFoot');
  if (el) el.innerHTML = '';
}
function stDaySet(which){ STN.day = which; stPaint(); }
/* IN START SI GUARDA, NELLA MAPPA SI SCRIVE (0.9.217): Domani e Calendario si vedono qualche
   secondo e poi scivolano via con «L'ostacolo dovra' spostarsi»; toccarli porta al foglio della
   Mappa su quella scheda, dove il piano si scrive. */
function stTabMappa(k, label){ return '<button type="button" class="st-daytab" data-k="' + k + '" onclick="event.stopPropagation();stApriInMappa(\'' + k + '\')">' + label + '</button>'; }
function stApriInMappa(k){
  STN.tab = k; STN.day = 'today';
  try{ localStorage.setItem('fl_mappa_vista', 'mia'); }catch(_){ }
  switchTab('mappa');
  setTimeout(function(){ try{ if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ } try{ stPaint(); }catch(_){ } const f = document.getElementById('mppFoglio'); if (f && f.scrollIntoView) f.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 120);
}
function stTabSet(t){ STN.tab = t; STN.day = 'today'; stPaint(); }

/* ---------- IL FOGLIO A TUTTO SCHERMO ----------
   La stessa pagina del suo Notion, dentro l'app: i cassetti della rotta (priorita', importante,
   completate), un paragrafo «Fuori rotta» con Urgente (che contiene Scadenze e appuntamenti) e
   Non urgente, un paragrafo «Note» libero — con la barra di formattazione delle note di Samsung
   quando la tastiera sale — e in fondo il riquadro «Da rivedere», dove le idee aspettano il
   verdetto di Jordan. In alto: i giorni, e i tre puntini che aprono il calendario. */
const STF = { off: 0 };
function stfKey(){ return mtKey(Date.now() + STF.off * 86400000); }
function stfTitolo(){
  if (STF.off === 0) return 'Oggi';
  if (STF.off === 1) return 'Domani';
  if (STF.off === -1) return 'Ieri';
  const d = new Date(Date.now() + STF.off * 86400000);
  const G = ['domenica', 'luned\u00ec', 'marted\u00ec', 'mercoled\u00ec', 'gioved\u00ec', 'venerd\u00ec', 'sabato'];
  const M = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
  return G[d.getDay()] + ' ' + d.getDate() + ' ' + M[d.getMonth()];
}
function stfRighe(){ return stRigheDi(stfKey()); }
function stfSalva(righe){
  const k = stfKey();
  try{ localStorage.setItem('fl_notes_' + k, righe.join('\n')); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(k); }catch(_){ }
}
registerScreen('s-notes', '<div class="stf-wrap" id="stfWrap">'
  /* indietro e tre puntini nella testata; le sei schede su una riga tutta loro, sotto,
     cosi' nessuna viene tagliata dai due pulsanti */
  + '<div class="stf-top pn-head">'
  +   '<button class="iconbtn" onclick="stFullClose()" aria-label="Indietro">\u2039</button>'
  +   '<b class="pn-head-t">Il piano</b>'
  +   '<button type="button" class="stf-dots" onclick="stfDrawerOpen()" aria-label="Impostazioni del piano">\u22ef</button>'
  + '</div>'
  + '<div class="pn-tabs" id="pnTabs"></div>'
  + '<div class="stf-daynav" id="stfDayNav">'
  +   '<button type="button" class="stf-nav" onclick="stfGiorno(-1)" aria-label="Il giorno prima">\u2039</button>'
  +   '<b id="stfTitle">Oggi</b>'
  +   '<button type="button" class="stf-nav" id="stfAvanti" onclick="stfGiorno(1)" aria-label="Il giorno dopo">\u203a</button>'
  + '</div>'
  + '<div class="stf-body" id="stfBody"></div>'
  + '<div class="stf-add" id="stfAdd">'
  +   '<textarea id="stfNuova" class="stf-input" rows="1" placeholder="Scrivi una cosa e premi invio\u2026" '
  +     'oninput="stNoteGrow(this)" onkeydown="if(event.key===\'Enter\'&&!event.shiftKey){event.preventDefault();stfAggiungi();}"></textarea>'
  +   '<button type="button" class="st-mic" onmousedown="event.preventDefault()" onclick="stDictStart()" aria-label="Detta a voce">'
  +     '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>'
  + '</div>'
  + '<div class="stf-bar" id="stfBar" hidden></div>'
  + '</div>', { back: 's-home' });

function stFullOpen(){
  STF.off = 0;
  STF.tab = 'giorni';
  goId('s-notes');
  setTimeout(function(){ try{ stNotesCommit(); }catch(_){ } stfPaint(); }, 30);
}
function stFullClose(){
  stfNoteSalva();
  const torna = STF.ritorno || 'sveglia'; STF.ritorno = '';
  try{ const sn = document.getElementById('s-notes'); if (sn) sn.classList.remove('solo-note'); }catch(_){ }
  goId('s-home');
  switchTab(torna);
  setTimeout(function(){ stPaint(); stSyncToFF(); }, 160);
}
function stfGiorno(d){
  const next = STF.off + d;
  if (next > 2 || next < -60) return;
  stfNoteSalva();
  STF.off = next;
  stfPaint();
}
function stfAperte(){
  try{ return JSON.parse(localStorage.getItem('fl_stf_open') || 'null') || { one: 1, imp: 1, fuori: 1 }; }catch(_){ return { one: 1, imp: 1, fuori: 1 }; }
}
function stfToggle(k, el){
  const a = stfAperte(); a[k] = el.open ? 1 : 0;
  try{ localStorage.setItem('fl_stf_open', JSON.stringify(a)); }catch(_){ }
}
/* 0.9.290: la riga a schermo con gli accenti veri e senza i minuti fra parentesi alla fine (sono nel tempo della riga) */
function stVedi(r){ return typeof rgfPulito === 'function' ? rgfPulito(r) : String(r || ''); }
function stfRiga(r, i, day, prio){
  const fatta = stIsDone(r, day);
  const et = stEtichetta(r);
  return '<div class="stf-row' + (fatta ? ' done' : '') + '">'
    + '<button type="button" class="stf-box' + (fatta ? ' on' : '') + '" onclick="stfTick(' + i + ')" aria-label="' + (fatta ? 'Togli la spunta' : 'Segna come fatta') + '">' + (fatta ? '\u2713' : '') + '</button>'
    + '<div class="stf-txt" onclick="stfApri(' + i + ')">' + esc(stVedi(r))
    +   (fatta ? '' : '<small class="stf-quad ' + et.cls + '">' + et.t + '</small>') + '</div>'
    + '<button type="button" class="st-info" onclick="stfApri(' + i + ')" aria-label="Dettagli">i</button>'
    /* la priorita' non ha la X: e' il passo della rotta, non si negozia */
    + (prio ? '' : '<button type="button" class="st-del" onclick="stfVia(' + i + ')" aria-label="Togli">\u2715</button>')
    + '</div>';
}
function stfCassetto(k, titolo, sotto, idx, righe, day, aperte){
  return '<details class="stf-sez ' + k + '"' + (aperte[k] ? ' open' : '') + ' ontoggle="stfToggle(\'' + k + '\', this)">'
    + '<summary><b>' + titolo + '</b><small>' + (idx.length ? idx.length : sotto) + '</small></summary>'
    + (idx.length ? idx.map(function(i){ return stfRiga(righe[i], i, day, k === 'one'); }).join('') : '<p class="stf-vuoto piccolo">Niente qui.</p>')
    + '</details>';
}
function stfPaint(){
  /* le sei schede del piano (piano.js): tutte tranne «Giorni» le disegna lui */
  if (typeof pnTabsPaint === 'function') pnTabsPaint();
  if (STF.tab && STF.tab !== 'giorni' && typeof pnPaintTab === 'function'){ pnPaintTab(); return; }
  const nav = document.getElementById('stfDayNav'); if (nav) nav.hidden = false;
  const add0 = document.getElementById('stfAdd'); if (add0) add0.hidden = false;
  const t = document.getElementById('stfTitle');
  if (t) t.textContent = stfTitolo();
  const av = document.getElementById('stfAvanti');
  if (av) av.disabled = STF.off >= 2;
  const host = document.getElementById('stfBody');
  if (!host) return;
  const day = stfKey();
  /* domani (e dopodomani) si vedono solo a priorita' di oggi fatta e a giornata finita */
  if (STF.off >= 1 && typeof pnDomaniAperto === 'function' && !pnDomaniAperto()){
    host.innerHTML = pnLucchettoHtml();
    const add = document.getElementById('stfAdd'); if (add) add.hidden = true;
    return;
  }
  const righe = stfRighe();
  const gruppi = {};
  ST_SEZIONI.forEach(function(sz){ gruppi[sz[0]] = []; });
  righe.forEach(function(r, i){ gruppi[stSezione(r, day, righe)].push(i); });
  const ap = stfAperte();
  host.innerHTML =
      stfCassetto('one',   'La priorit\u00e0 assoluta', 'il 20% che fa l\u201980%', gruppi.one,   righe, day, ap)
    + stfCassetto('imp',   'Importante',               'dopo la priorit\u00e0',    gruppi.imp,   righe, day, ap)
    + stfCassetto('fatte', 'Completate',               'successi',                 gruppi.fatte, righe, day, ap)
    /* fuori rotta: due cassetti, e dentro al primo quello delle scadenze */
    + '<div class="stf-par">Fuori rotta</div>'
    + '<details class="stf-sez urg"' + (ap.urg ? ' open' : '') + ' ontoggle="stfToggle(\'urg\', this)">'
    +   '<summary><b>Urgente</b><small>' + (gruppi.scad.length || 'non tue') + '</small></summary>'
    +   stfCassetto('scad', 'Scadenze e appuntamenti', 'niente in scadenza', gruppi.scad, righe, day, Object.assign({ scad: 1 }, ap))
    + '</details>'
    + stfCassetto('idee',  'Non urgente',              'idee per il futuro',       gruppi.idee,  righe, day, ap);
  /* le note libere e «Da rivedere» vivono nell'ultima scheda, Note (piano.js) */
}
function stfAggiungi(){
  const box = document.getElementById('stfNuova');
  if (!box) return;
  const add = box.value.split('\n').map(function(t){ return t.trim(); }).filter(Boolean);
  if (!add.length) return;
  box.value = ''; stNoteGrow(box);
  const righe = stfRighe();
  add.forEach(function(t){ if (righe.indexOf(t) < 0) righe.push(t); });
  stfSalva(righe);
  stfPaint();
  if (STF.off >= 0 && STF.off <= 1){
    const prima = STN.day;
    STN.day = STF.off === 1 ? 'tomorrow' : 'today';
    try{ stPlanned(); }catch(_){ }
    STN.day = prima;
  }
}
function stfVia(i){
  const righe = stfRighe();
  if (!righe[i]) return;
  righe.splice(i, 1);
  stfSalva(righe);
  stfPaint();
}
function stfTick(i){
  const righe = stfRighe(), day = stfKey();
  if (!righe[i]) return;
  stSpunta(righe[i], day, stfPaint);
}
function stfApri(i){
  const righe = stfRighe();
  if (!righe[i]) return;
  stRigaOpen(righe[i], stfKey(), 's-notes');
}

/* ---------- LE NOTE: l'editor e la barra ----------
   Un blocco di testo formattabile per giorno (`fl_note_html_<giorno>`), con la barra delle
   note di Samsung: casella, spunta, elenco, numerato, rientro, grassetto, corsivo,
   sottolineato, barrato, colore, evidenziatore, grandezza, allineamento, immagine, annulla,
   ripeti — e il genio, che manda in revisione quello che hai selezionato. Compare quando
   scrivi nelle note, sopra alla tastiera, e sparisce quando ne esci. */
let STF_NOTE_T = 0, STF_NOTE_DIRTY = false;
function stfNoteKey(day){ return 'fl_note_html_' + (day || stfKey()); }
function stfNoteDirty(){ STF_NOTE_DIRTY = true; clearTimeout(STF_NOTE_T); STF_NOTE_T = setTimeout(stfNoteSalva, 900); }
/* stfNoteSalva vive in piano.js: le note sono pagine, non un blocco per giorno. */
const STF_BAR = [
  ['\u2610', 'Casella',        function(){ stfCmdRiga('\u2610 '); }],
  ['\u2611', 'Spunta',         function(){ stfCmdSpunta(); }],
  ['\u2022', 'Elenco',         function(){ document.execCommand('insertUnorderedList'); }],
  ['1.',     'Numerato',       function(){ document.execCommand('insertOrderedList'); }],
  ['\u2192|','Rientra',        function(){ document.execCommand('indent'); }],
  ['|\u2190','Sporgi',         function(){ document.execCommand('outdent'); }],
  ['|', '', null],
  ['<b>B</b>', 'Grassetto',    function(){ document.execCommand('bold'); }],
  ['<i>I</i>', 'Corsivo',      function(){ document.execCommand('italic'); }],
  ['<u>U</u>', 'Sottolineato', function(){ document.execCommand('underline'); }],
  ['<s>S</s>', 'Barrato',      function(){ document.execCommand('strikeThrough'); }],
  ['<span class="stf-col">A</span>', 'Colore', function(){ stfColore('foreColor'); }],
  ['<span class="stf-hl">A</span>',  'Evidenzia', function(){ stfColore('hiliteColor'); }],
  ['Aa',     'Grandezza',      function(){ stfGrandezza(); }],
  ['|', '', null],
  ['\u2261', 'Allinea',        function(){ stfAllinea(); }],
  ['\ud83d\uddbc', 'Immagine', function(){ stfImmagine(); }],
  ['\u21b6', 'Annulla',        function(){ document.execCommand('undo'); }],
  ['\u21b7', 'Ripeti',         function(){ document.execCommand('redo'); }],
  ['|', '', null],
  ['\ud83e\uddde', 'In revisione', function(){ stfRevSelezione(); }]
];
function stfBarShow(on){
  const bar = document.getElementById('stfBar'), wrap = document.getElementById('stfWrap');
  if (!bar) return;
  if (on && !bar.dataset.ok){
    bar.dataset.ok = '1';
    bar.innerHTML = STF_BAR.map(function(b, i){
      if (b[0] === '|') return '<i class="stf-sep"></i>';
      return '<button type="button" data-i="' + i + '" aria-label="' + b[1] + '">' + b[0] + '</button>';
    }).join('');
    /* mousedown/touchstart con preventDefault: il fuoco resta nell'editor, la tastiera resta su */
    bar.addEventListener('mousedown', function(e){ e.preventDefault(); });
    bar.addEventListener('touchstart', function(e){ e.preventDefault(); const b = e.target.closest('button'); if (b) stfBarTocca(+b.dataset.i); }, { passive: false });
    bar.addEventListener('click', function(e){ const b = e.target.closest('button'); if (b && !('ontouchstart' in window)) stfBarTocca(+b.dataset.i); });
  }
  bar.hidden = !on;
  if (wrap) wrap.classList.toggle('scrive', !!on);
  const add = document.getElementById('stfAdd'); if (add) add.hidden = !!on;
}
function stfBarTocca(i){ const b = STF_BAR[i]; if (b && b[2]) try{ b[2](); }catch(_){ } }
function stfCmdRiga(prefisso){
  const sel = window.getSelection(); if (!sel || !sel.rangeCount) return;
  let n = sel.anchorNode; while (n && n.nodeType !== 1) n = n.parentNode;
  const blocco = n && n.closest ? (n.closest('p, div, li') || n) : null;
  if (blocco && blocco.id !== 'stfNote'){
    const t = blocco.textContent || '';
    if (t.indexOf('\u2610 ') === 0){ blocco.innerHTML = blocco.innerHTML.replace('\u2610 ', ''); return; }
    blocco.innerHTML = prefisso + blocco.innerHTML;
  } else document.execCommand('insertText', false, prefisso);
  stfNoteDirty();
}
function stfCmdSpunta(){
  const sel = window.getSelection(); if (!sel || !sel.rangeCount) return;
  let n = sel.anchorNode; while (n && n.nodeType !== 1) n = n.parentNode;
  const blocco = n && n.closest ? (n.closest('p, div, li') || n) : null;
  if (!blocco || blocco.id === 'stfNote') return;
  const h = blocco.innerHTML;
  if (h.indexOf('\u2611 ') === 0) blocco.innerHTML = '\u2610 ' + h.slice(2);
  else if (h.indexOf('\u2610 ') === 0) blocco.innerHTML = '\u2611 ' + h.slice(2);
  else blocco.innerHTML = '\u2611 ' + h;
  stfNoteDirty();
}
const STF_COLORI = ['#0075E3', '#C42B38', '#1B9E6A', '#9A6800', '#3F9FF4'];
const STF_EVID = ['#FFF3B0', '#FFD6DB', '#D6F5E6', '#DCEBFF', 'transparent'];
function stfColore(cmd){
  const lista = cmd === 'foreColor' ? STF_COLORI : STF_EVID;
  const k = cmd === 'foreColor' ? 'fl_note_col' : 'fl_note_hl';
  let i = 0; try{ i = (+localStorage.getItem(k) || 0) % lista.length; }catch(_){ }
  document.execCommand(cmd, false, lista[i]);
  try{ localStorage.setItem(k, String((i + 1) % lista.length)); }catch(_){ }
  stfNoteDirty();
}
function stfGrandezza(){
  let i = 0; try{ i = +localStorage.getItem('fl_note_fs') || 0; }catch(_){ }
  const sizes = ['3', '5', '6', '2'];
  document.execCommand('fontSize', false, sizes[i % sizes.length]);
  try{ localStorage.setItem('fl_note_fs', String((i + 1) % sizes.length)); }catch(_){ }
  stfNoteDirty();
}
function stfAllinea(){
  let i = 0; try{ i = +localStorage.getItem('fl_note_al') || 0; }catch(_){ }
  const cmds = ['justifyCenter', 'justifyRight', 'justifyLeft'];
  document.execCommand(cmds[i % cmds.length]);
  try{ localStorage.setItem('fl_note_al', String((i + 1) % cmds.length)); }catch(_){ }
  stfNoteDirty();
}
async function stfImmagine(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickImages){ toast('Le immagini si allegano dal telefono'); return; }
  try{
    const r = await NATIVE.pickImages();
    const u = (r && r.images && r.images[0]) || (r && r.uris && r.uris[0]) || (r && r.uri) || '';
    if (!u) return;
    const src = (window.Capacitor && Capacitor.convertFileSrc) ? Capacitor.convertFileSrc(u) : u;
    const ed = document.getElementById('stfNote'); if (!ed) return;
    ed.focus();
    document.execCommand('insertHTML', false, '<p><img src="' + esc(src) + '" alt="" style="max-width:100%;border-radius:12px"></p><p><br></p>');
    stfNoteDirty();
  }catch(_){ }
}
function stfRevSelezione(){
  const sel = window.getSelection();
  let t = sel ? String(sel.toString() || '').trim() : '';
  if (!t){
    let n = sel && sel.anchorNode; while (n && n.nodeType !== 1) n = n.parentNode;
    const blocco = n && n.closest ? (n.closest('p, div, li')) : null;
    if (blocco && blocco.id !== 'stfNote') t = (blocco.textContent || '').trim();
  }
  if (!t){ toast('Seleziona la frase da mandare in revisione'); return; }
  stRevChiedi(t);
}

/* ---------- DA RIVEDERE: le idee aspettano Jordan ----------
   Un'idea scritta nelle note non entra nella rotta da sola: la mandi in revisione, l'app la
   deposita fra le osservazioni per Jordan (fl:agent-in), e lui alle 22:45 risponde nel
   verdetto: accettata (e cosa sostituisce), oppure no, e perche'. Le rifiutate finiscono nel
   cassetto dove lui le ha catalogate. */
const ST_REV_KEY = 'fl_revisione';
function stRevLista(){ try{ return JSON.parse(localStorage.getItem(ST_REV_KEY) || '[]') || []; }catch(_){ return []; } }
function stRevSalva(l){ try{ localStorage.setItem(ST_REV_KEY, JSON.stringify(l.slice(-60))); }catch(_){ } }
function stRevChiedi(testo){
  testo = String(testo || '').trim().slice(0, 300);
  if (!testo) return;
  const l = stRevLista();
  if (l.some(function(x){ return x.stato === 'attesa' && x.testo.toLowerCase() === testo.toLowerCase(); })){ toast('\u00c8 gi\u00e0 in revisione'); return; }
  l.push({ id: 'r' + Date.now().toString(36), testo: testo, giorno: stDayKey(), at: Date.now(), stato: 'attesa' });
  stRevSalva(l);
  stRevPaint();
  toast('Mandata a Jordan: risponde nel verdetto della sera');
  try{ if (typeof jdDeposita === 'function') jdDeposita(true); }catch(_){ }
}
function stRevVia(id){ stRevSalva(stRevLista().filter(function(x){ return x.id !== id; })); stRevPaint(); }
function stRevPaint(){
  const el = document.getElementById('stfRev'); if (!el) return;
  const l = stRevLista().slice().reverse();
  el.innerHTML = (l.length ? l.map(function(x){
    const esito = x.stato === 'attesa' ? '<small class="attesa">In attesa del verdetto di Jordan (22:45)</small>'
      : x.stato === 'accettata' ? '<small class="ok">\u2705 Accettata' + (x.sostituisce ? ': al posto di "' + esc(x.sostituisce) + '"' : '') + (x.motivo ? ' \u00b7 ' + esc(x.motivo) : '') + '</small>'
      : '<small class="no">\u274c ' + esc(x.motivo || 'Non abbastanza importante adesso') + (x.dove ? ' \u00b7 messa in ' + esc(stSezNome(x.dove) || x.dove) : '') + '</small>';
    return '<div class="stf-revrow"><div><b>' + esc(x.testo) + '</b>' + esito + '</div>'
      + '<button type="button" class="st-del" onclick="stRevVia(\'' + x.id + '\')" aria-label="Togli">\u2715</button></div>';
  }).join('') : '<p class="stf-vuoto piccolo">Seleziona una frase nelle note e tocca il genio nella barra: Jordan la valuta contro la tua rotta e risponde.</p>');
}
/* Il verdetto di Jordan porta le risposte: si applicano una volta sola. */
function stRevApplica(v){
  try{ stScompApplica(v); }catch(_){ }
  if (!v || !Array.isArray(v.revisioni) || !v.revisioni.length) return;
  const l = stRevLista();
  let cambiato = false;
  const DOVE = { ONE: 'one', PRIORITA: 'one', DESIGNATE: 'imp', IMPORTANTE: 'imp', DELEGATE: 'scad', SCADENZE: 'scad', DO_IT_AFTER: 'idee', NON_URGENTE: 'idee' };
  v.revisioni.forEach(function(r){
    if (!r) return;
    const x = l.filter(function(y){ return y.id === r.id || (y.stato === 'attesa' && y.testo.toLowerCase() === String(r.testo || '').toLowerCase()); })[0];
    if (!x || x.stato !== 'attesa') return;
    const ok = /^(ok|accett|s\u00ec|si)/i.test(String(r.esito || ''));
    x.stato = ok ? 'accettata' : 'rifiutata';
    x.motivo = String(r.motivo || '').slice(0, 200);
    x.sostituisce = String(r.sostituisce || '').slice(0, 120);
    x.dove = DOVE[String(r.dove || '').toUpperCase().replace(/ /g, '_')] || (ok ? 'imp' : 'idee');
    x.rispostaAt = Date.now();
    /* entra nel foglio di oggi, nel cassetto deciso da lui */
    try{
      const day = stDayKey();
      const righe = stRigheDi(day);
      if (righe.indexOf(x.testo) < 0){
        righe.push(x.testo);
        localStorage.setItem('fl_notes_' + day, righe.join('\n'));
        if (typeof fsToccato === 'function') fsToccato(day);
      }
      stMetaSave(x.testo, day, { sez: x.dove });
      if (ok && x.sostituisce){
        const i = righe.map(function(t){ return t.toLowerCase(); }).indexOf(x.sostituisce.toLowerCase());
        if (i >= 0) stMetaSave(righe[i], day, { sez: 'idee' });
      }
    }catch(_){ }
    cambiato = true;
  });
  if (cambiato){ stRevSalva(l); stRevPaint(); try{ stListPaint(); }catch(_){ } }
}
document.addEventListener('DOMContentLoaded', function(){
  /* il verdetto di Jordan passa di qui: quando arriva, le revisioni si applicano */
  if (typeof jdLeggi === 'function' && !jdLeggi.__rev){
    const orig = jdLeggi;
    const w = async function(f){ const v = await orig(f); try{ stRevApplica(v); }catch(_){ } return v; };
    w.__rev = true; jdLeggi = w;
  }
});

/* ---------- IL CASSETTO DEL CALENDARIO ----------
   I tre puntini in alto aprono, da destra, quasi a tutto schermo: il mese a calendario con un
   punto sui giorni in cui hai fatto qualcosa, e sopra le due schede — Trimestri e Mesi — con
   l'obiettivo di quel periodo e i suoi passi, presi dagli Orizzonti (dove il Genio o Jordan
   li hanno gia' scritti). Toccare un giorno apre il suo foglio. */
const STFD = { m: null, tab: 'mesi' };
function stfDrawerOpen(){
  let el = document.getElementById('stfDrawer');
  if (!el){
    el = document.createElement('div'); el.id = 'stfDrawer';
    (document.getElementById('phone') || document.body).appendChild(el);
  }
  const d = new Date(Date.now() + STF.off * 86400000);
  STFD.m = new Date(d.getFullYear(), d.getMonth(), 1);
  el.hidden = false;
  stfDrawerPaint();
  requestAnimationFrame(function(){ el.classList.add('in'); });
}
function stfDrawerClose(){ const el = document.getElementById('stfDrawer'); if (!el) return; el.classList.remove('in'); setTimeout(function(){ el.hidden = true; }, 220); }
function stfDrawerMese(d){ STFD.m = new Date(STFD.m.getFullYear(), STFD.m.getMonth() + d, 1); stfDrawerPaint(); }
function stfDrawerTab(t){ STFD.tab = t; stfDrawerPaint(); }
function stfDrawerGiorno(iso){
  const oggi = mtKey(Date.now());
  const off = Math.round((new Date(iso + 'T12:00:00') - new Date(oggi + 'T12:00:00')) / 86400000);
  if (off > 2) { toast('Il foglio si scrive fino a dopodomani'); return; }
  stfNoteSalva(); STF.off = off; stfPaint(); stfDrawerClose();
}
/* stfDrawerPaint vive in piano.js: i tre puntini ora tengono solo l'ora di fine lavoro;
   calendario, trimestri e mesi sono schede del foglio grande. */

/* ---------- LE CASELLE ----------
   Spuntare e' dire «fatta»: si conferma, perche' una casella toccata per sbaglio mentre si
   scorre non e' una dichiarazione. E si puo' RITIRARE, perche' prima non si poteva e una
   spunta messa per errore restava li' per sempre.

   Il ritiro pero' costa: dichiarare fatta una cosa e poi rimangiarsela e' l'unico modo di
   imbrogliare in questo gioco, e l'arbitro lo tratta come tale — il punto va al vecchio te.
   Non e' una punizione morale: e' la regola detta prima, sul foglio di conferma. */
/* 0.9.281, Andrea: "Il primo passo verso il mio sogno (10 min, telefono chiuso)" non e' una cosa da fare. Era la
   riga che il giro del Genio metteva nel foglio il primo giorno: si toglie, ovunque sia rimasta. */
const ST_RIGA_VECCHIA = /^il primo passo verso il mio sogno/i;
function stTogliRigaVecchia(day){
  try{
    const r = stRigheDi(day); const l = r.filter(function(x){ return !ST_RIGA_VECCHIA.test(String(x).trim()); });
    if (l.length !== r.length){ localStorage.setItem('fl_notes_' + day, l.join('\n')); if (typeof fsToccato === 'function') fsToccato(day); }
  }catch(_){ }
}
/* Senza un passo scritto nella roadmap, la priorita' di oggi e' la prossima tappa della mappa: la stessa del
   piano della Roadmap ("Il prossimo passo"). */
function stTappaOggi(){
  try{ const cur = (typeof sdCorrente === 'function') ? sdCorrente() : null; if (cur && cur.nodo) return { id: cur.nodo.id, nome: sdNomeTappa(cur.nodo), ico: (typeof SD_ICO !== 'undefined' && SD_ICO[cur.nodo.tipo]) || '' }; }catch(_){ }
  return null;
}
function stListPaint(){
  const el = document.getElementById('stList');
  if (!el) return;
  try{ stTogliRigaVecchia(stDayKey('today')); }catch(_){ }
  if (STN.day !== 'tomorrow') stRoadmapNelFoglio();
  const day = stDayKey();
  const rows = stLines();
  const one = stPriorita(day, rows);
  const i = rows.indexOf(one);
  const fatte = rows.filter(function(r){ return stIsDone(r, day); });
  let html = '';
  if (one && i >= 0){
    const backed = !!refSessionFor(one, day);
    const m = stMeta(one, day);
    /* NON NEGOZIABILE: la priorita' non ha la X. E' il passo che il Genio ti ha messo davanti
       per rispettare la rotta; si fa, o resta li'. Le altre righe si tolgono dal foglio grande. */
    html += '<p class="st-onelbl">La priorit\u00e0 di oggi</p>'
      + '<div class="st-row st-one">'
      + '<button type="button" class="stf-box" onclick="stRowTick(' + i + ')" aria-label="Segna come fatta"></button>'
      + '<div class="st-lab" onclick="stRowInfo(' + i + ')">' + esc(stVedi(one)) + '</div>'
      + (backed ? '<i class="st-seen" title="Sessione fatta">\u23f1</i>' : '')
      + '<button type="button" class="st-info" onclick="stRowInfo(' + i + ')" aria-label="Dettagli">i</button>'
      + '</div>'
      /* IL TEMPO PREVISTO (0.9.207): sotto alla riga, una pillola; tocco = foglio dal basso con le scelte.
         Se nessuno l'ha scritto, vale 25 minuti: una sessione. */
      + '<div class="st-tempo-r"><button type="button" class="st-tempo" onclick="stStimaSheet(' + i + ')">⏱ ' + stStimaTxt(m.stima || 25) + (m.stima ? '' : ' <em>di serie</em>') + '<span class="chev"></span></button></div>';
  } else if (!rows.length && STN.day !== 'tomorrow' && stTappaOggi()){
    const tp = stTappaOggi();
    html += '<p class="st-onelbl">La priorit\u00e0 di oggi</p>'
      + '<div class="st-row st-one st-tappa"><span class="st-tappa-ico" aria-hidden="true">' + tp.ico + '</span><div class="st-lab" onclick="sdTapVia(\'' + tp.id + '\')">' + esc(tp.nome) + '</div>'
      + '<button type="button" class="st-tappa-via" onclick="sdTapVia(\'' + tp.id + '\')">Inizia</button></div>';
  } else if (!rows.length){
    html += '<p class="st-onelbl">La priorit\u00e0 di oggi</p><p class="st-vuoto">' + ((typeof ulAttiva === 'function' && ulAttiva()) ? 'Ancora niente. Il Genio la scrive dalla tua rotta, oppure la scegli tu domattina, nel Taglia delle righe di domani.' : 'Ancora niente. Il Genio la scrive dalla tua rotta, oppure la scrivi tu dal foglio grande.') + '</p>';
  } else {
    html += '<p class="st-onelbl">La priorit\u00e0 di oggi</p><p class="st-vuoto">Tutto fatto per oggi.</p>';
  }
  /* L'UNICO cassetto del pannello: le cose fatte oggi, per vedersele tutte in un colpo d'occhio. */
  html += '<details class="st-fatte"' + (stAltroAperto() ? ' open' : '') + ' ontoggle="stAltroToggle(this)">'
    + '<summary><b>Completate</b><small>' + fatte.length + (fatte.length === 1 ? ' oggi' : ' oggi') + '</small></summary>'
    + (fatte.length
        ? fatte.map(function(r){ const j = rows.indexOf(r); return '<div class="st-row done">'
            + '<button type="button" class="stf-box on" onclick="stRowTick(' + j + ')" aria-label="Togli la spunta">\u2713</button>'
            + '<div class="st-lab" onclick="stRowInfo(' + j + ')">' + esc(stVedi(r)) + '</div>'
            + '<button type="button" class="st-info" onclick="stRowInfo(' + j + ')" aria-label="Dettagli">i</button>'
            + '</div>'; }).join('')
        : '<p class="stf-vuoto piccolo">Niente ancora. La prima che spunti finisce qui.</p>')
    + '</details>';
  /* il caveau delle idee sta nella scheda Note della Mappa (mappa-foglio.js, 0.9.216) */
  el.innerHTML = html;
}
/* ---------- LE NOTE DEL GIORNO (scheda Note del pannello) ----------
   Righe libere: appunti, idee, cose da rivedere. Finiscono nel paragrafo «Note» del foglio
   grande, dove si formattano, si spostano e si mandano in revisione. */
function stAppuntiKey(day){ return 'fl_appunti_' + (day || stDayKey()); }
function stAppunti(day){ try{ return JSON.parse(localStorage.getItem(stAppuntiKey(day)) || '[]') || []; }catch(_){ return []; } }
function stAppuntiSave(list, day){
  try{ localStorage.setItem(stAppuntiKey(day), JSON.stringify(list.slice(-200))); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(day || stDayKey()); }catch(_){ }
}
function stAppuntoCommit(){
  const box = document.getElementById('stNotes');
  if (!box) return;
  const add = box.value.split('\n').map(function(t){ return t.trim(); }).filter(Boolean);
  box.value = ''; stNoteGrow(box);
  if (!add.length) return;
  const list = stAppunti();
  add.forEach(function(t){ list.push({ t: t, at: Date.now() }); });
  stAppuntiSave(list);
  stAppuntiPaint();
  stNoteHint('Segnata nelle note di oggi.');
}
function stAppuntoVia(i){ const l = stAppunti(); l.splice(i, 1); stAppuntiSave(l); stAppuntiPaint(); }
function stAppuntiPaint(){
  const el = document.getElementById('stAppunti'); if (!el) return;
  const l = stAppunti();
  el.innerHTML = l.length ? l.map(function(a, i){
    return '<div class="st-row st-app"><i class="st-appdot">\u2022</i><div class="st-lab">' + esc(a.t) + '</div>'
      + '<button type="button" class="st-info" onclick="stRevChiedi(' + JSON.stringify(a.t).replace(/"/g, '&quot;') + ')" aria-label="Manda in revisione">\ud83e\uddde</button>'
      + '<button type="button" class="st-del" onclick="stAppuntoVia(' + i + ')" aria-label="Togli">\u2715</button></div>';
  }).join('') : '<p class="stf-vuoto piccolo">Idee, appunti, cose da rivedere. Una per riga.</p>';
}
/* ---------- LA MAPPA DI OGGI (scheda Mappa del pannello) ----------
   I passi di oggi e della settimana, presi dagli Orizzonti: gli stessi che la Roadmap disegna
   sulla mappa, qui in fila, senza dover cambiare scheda. */
function stMappaHtml(){
  let passi = [];
  try{
    if (typeof ozAnello === 'function'){
      ['oggi', 'settimana'].forEach(function(k){
        const a = ozAnello(k);
        (a.passi || []).forEach(function(p){ if (p && p.t) passi.push({ t: p.t, fatto: !!p.fatto, k: k }); });
      });
    }
  }catch(_){ }
  const prio = stPriorita(stDayKey(), stLines());
  if (prio && !passi.some(function(p){ return p.t === prio; })) passi.unshift({ t: prio, fatto: stIsDone(prio, stDayKey()), k: 'oggi', prio: true });
  const oggi = passi.filter(function(p){ return p.k === 'oggi'; }), sett = passi.filter(function(p){ return p.k === 'settimana'; });
  const riga = function(p){
    return '<div class="st-tappa' + (p.fatto ? ' fatta' : '') + (p.prio ? ' prio' : '') + '"><i>' + (p.fatto ? '\u2713' : (p.prio ? '\ud83c\udfaf' : '\ud83d\udccd')) + '</i><span>' + esc(p.t) + '</span></div>';
  };
  /* LA MAPPA E' LA MAPPA. Qui c'erano due paragrafi di righe; la scheda si chiama «Mappa» e
     mostra il sentiero disegnato della settimana — lo stesso della Roadmap — con le tappe.
     Toccarla apre la mappa grande, dove si cambia il pezzo di strada. */
  if (typeof mpSvg === 'function' && typeof mpTappeSettimana === 'function' && typeof mpPartenza === 'function' && mpPartenza()){
    const tappe = mpTappeSettimana();
    if (prio && !tappe.some(function(t){ return t.t === prio; })) tappe.unshift({ ico: '\ud83c\udfaf', t: prio, s: 'La priorit\u00e0 di oggi.', go: '' });
    const arr = (typeof mpArrivo === 'function') ? mpArrivo() : null;
    return '<div class="st-mappa">'
      + '<div class="mp-card" onclick="mpApriSettimana()">'
      +   '<p class="mp-oz">Questa settimana</p>'
      +   (tappe.length ? mpSvg(tappe.slice(0, 6), false) : '<p class="life-sub" style="color:#cfe0ff">Nessun passo scritto per questa settimana. Scrivili negli Orizzonti.</p>')
      +   (arr ? '<div class="mp-foot"><span>' + arr.ico + '</span><div><small>Vuoi diventare</small><b>' + esc(arr.nome) + '</b></div></div>' : '')
      +   '<div class="mp-open">Apri la mappa \u203a</div>'
      + '</div></div>';
  }
  return '<div class="st-mappa">'
    + (oggi.length ? '<p class="st-onelbl">Oggi</p>' + oggi.map(riga).join('') : '')
    + (sett.length ? '<p class="st-onelbl" style="margin-top:16px">Questa settimana</p>' + sett.map(riga).join('') : '')
    + (!oggi.length && !sett.length ? '<p class="st-vuoto">Prima la lettura del Genio: la mappa si disegna da li\'.</p>' : '')
    + '<button type="button" class="st-tutto" onclick="switchTab(\'severa\')">Apri la Roadmap \u203a</button>'
    + '</div>';
}
function stRowInfo(i){
  const rows = stLines();
  if (rows[i]) stRigaOpen(rows[i], stDayKey(), 's-home');
}
function stRowTick(i){
  const rows = stLines();
  if (!rows[i]) return;
  const riga = rows[i], day = stDayKey();
  stSpunta(riga, day, function(){
    stListPaint(); stNoteFoot(); stSyncToFF();
    /* IL BONUS VELOCITA' (0.9.206): finita in meno dell'80% del tempo previsto = XP in piu' */
    try{
      const m = stMeta(riga, day); const sess = refSessionFor(riga, day);
      if (m.stima && sess && sess.spentMs && sess.spentMs <= m.stima * 60000 * 1.1 && !m.bonus && !sess.completata && stIsDone(riga, day)){
        stMetaSave(riga, day, { bonus: 1 });
        const premio = (typeof fcAggiungi === 'function') ? fcAggiungi(fcPremio(m.stima), 'Task chiusa nel tempo: ' + riga.slice(0, 40), m.stima + ' min') : 0;
        try{ flVibra([20, 30, 60]); }catch(_){ }
        toast('⛽ Finita nel tempo: +' + premio + ' carburante');
      }
    }catch(_){ }
  });
}
function stStimaTxt(n){ return n >= 60 ? Math.floor(n / 60) + ' h' + (n % 60 ? ' ' + (n % 60) : '') : n + ' min'; }
/* IL FOGLIO DEL TEMPO (0.9.214), pulito come i template di «Per te»: l'immagine con l'emoji
   della task (scelta dalle parole della task), il nome al centro, il selettore − 25 min + come
   quello del carrello dello store (il numero si tocca e si riscrive), il carburante che vale,
   le tre scelte rapide sotto e il pulsante per partire subito. */
const ST_EMOJI = [
  [/video|youtube|girar|montag|reel|tiktok|short|clip/i, '🎬', '#E63946,#7A1F3D'], [/scriv|libro|capitol|articol|post|blog|copy|testo/i, '✍️', '#0075E3,#062B5C'],
  [/studi|esam|lezion|ripass|corso|imparar/i, '📚', '#0075E3,#0E2350'], [/codic|app|bug|svilupp|programm|deploy|sito/i, '💻', '#0EA5E9,#0C4A6E'],
  [/chiam|telefon|client|riunion|meeting|call/i, '📞', '#F59E0B,#7C2D12'], [/vend|offert|prezz|fattur|soldi|budget|ordin/i, '💰', '#EAB308,#713F12'],
  [/palestr|allen|corsa|cammin|sport|yoga/i, '🏋️', '#EF4444,#450A0A'], [/mail|email|messagg|rispond/i, '📧', '#3B82F6,#1E3A8A'],
  [/design|grafic|foto|logo|immagin|disegn/i, '🎨', '#EC4899,#500724'], [/marketing|ads|campagn|annunc|pubblicit/i, '📣', '#F97316,#7C2D12'],
  [/pulizi|casa|ordin|spesa|cucin/i, '🧹', '#14B8A6,#134E4A'], [/medit|respir|riposo/i, '🧘', '#3F9FF4,#0E2350']
];
function stEmojiDi(t){ const x = ST_EMOJI.filter(function(e){ return e[0].test(String(t || '')); })[0]; return x ? { ico: x[1], bg: x[2] } : { ico: '🎯', bg: '#0075E3,#001E44' }; }
const STT = { i: -1, min: 25 };
function stStimaSheet(i){
  const rows = stLines(); if (!rows[i] || typeof inSheet !== 'function') return;
  const m = stMeta(rows[i], stDayKey()); STT.i = i; STT.min = Math.max(1, Math.min(90, m.stima || 25));
  const e = stEmojiDi(rows[i]);
  inSheet('<div class="am-sheet stt"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="stt-img" style="background:linear-gradient(160deg,' + e.bg + ')">' + e.ico + '</div>'
    + '<h3 class="stt-nome">' + esc(typeof rgfPulito === 'function' ? rgfPulito(rows[i]) : rows[i]) + '</h3>'
    + '<div class="stt-qty"><button type="button" onclick="stTempoPasso(-5)" aria-label="Meno">−</button><input id="sttMin" type="number" inputmode="numeric" min="1" max="90" value="' + STT.min + '" oninput="stTempoScritto(this.value)" onfocus="this.select()"><span>min</span><button type="button" onclick="stTempoPasso(5)" aria-label="Più">+</button></div>'
    + '<p class="stt-carb" id="sttCarb"></p>'
    + '<div class="stt-chips">' + [[10, 'rompi l’inerzia'], [25, 'una sessione piena'], [45, 'lavoro profondo']].map(function(o){ return '<button type="button" data-m="' + o[0] + '" onclick="stTempoSet(' + o[0] + ')"><b>' + o[0] + ' min</b><small>' + o[1] + '</small></button>'; }).join('') + '</div>'
    + '<button type="button" class="stt-via" id="sttVia" onclick="stTempoVia()"></button></div>');
  stTempoPaint();
}
function stTempoPaint(){
  const c = document.getElementById('sttCarb'), v = document.getElementById('sttVia'), inp = document.getElementById('sttMin');
  const premio = (typeof fcPremio === 'function') ? fcPremio(STT.min) : 15;
  if (c) c.innerHTML = '⛽ <b>+' + premio + ' carburante</b> se la chiudi entro ' + STT.min + ' minuti';
  if (v) v.innerHTML = 'INIZIA • ' + STT.min + ' min <span class="chev"></span>';
  if (inp && document.activeElement !== inp) inp.value = STT.min;
  document.querySelectorAll('.stt-chips button').forEach(function(b){ b.classList.toggle('on', +b.getAttribute('data-m') === STT.min); });
}
function stTempoSalva(){ const rows = stLines(); if (rows[STT.i]) stMetaSave(rows[STT.i], stDayKey(), { stima: STT.min }); try{ stListPaint(); }catch(_){ } }
/* AL MASSIMO UN'ORA E MEZZA (0.9.216): piu' tempo ti dai, piu' ne sprechi. Sotto i cinque minuti
   si scende di uno alla volta, e il carburante scende con il tempo (fcPremio). */
function stTempoSet(v){ STT.min = Math.max(1, Math.min(90, Math.round(+v || 25))); stTempoSalva(); stTempoPaint(); try{ flVibra(8); }catch(_){ } }
function stTempoPasso(d){ stTempoSet(d < 0 ? (STT.min <= 5 ? STT.min - 1 : STT.min + d) : (STT.min < 5 ? 5 : STT.min + d)); }
function stTempoScritto(v){ const n = Math.round(+v || 0); if (n > 90){ toast('Al massimo un’ora e mezza: più tempo ti dai, più ne sprechi'); stTempoSet(90); return; } if (n >= 1){ STT.min = n; stTempoSalva(); stTempoPaint(); } }
/** Parte subito: la task diventa l'obiettivo della sessione, con il tempo scelto. */
function stTempoVia(){
  const rows = stLines(); const t = rows[STT.i]; if (!t) return;
  stTempoSalva();
  try{ inSheetChiudi(); }catch(_){ }
  try{ const p = ffPref(); p.minutes = STT.min; p.intent = String(t).replace(/^[☐☑•\-]\s*/, '').slice(0, 250); ffSavePref(); }catch(_){ }
  try{ ffOpen(); setTimeout(function(){ try{ ffStart(); }catch(_){ } }, 350); }catch(_){ }
}
function stRigaStimaRiga(i, v){ const rows = stLines(); if (!rows[i]) return; stMetaSave(rows[i], stDayKey(), { stima: +v || 0 }); stListPaint(); }

/* ---------- IL FOGLIO DI CONFERMA ----------
   Una domanda sola, la riga che riguarda, due vie d'uscita scritte. */
function stChiedi(o){
  let el = document.getElementById('stAsk');
  if (!el){
    el = document.createElement('div');
    el.id = 'stAsk';
    (document.getElementById('phone') || document.body).appendChild(el);
  }
  el.innerHTML = '<div class="sta-scrim" onclick="stChiediChiudi()"></div>'
    + '<div class="sta-card">'
    +   '<b class="sta-t">' + o.titolo + '</b>'
    +   '<p class="sta-riga">"' + esc(o.riga) + '"</p>'
    +   (o.nota ? '<p class="sta-nota">' + o.nota + '</p>' : '')
    +   '<div class="sta-btns">'
    +     '<button type="button" class="sta-no" onclick="stChiediChiudi()">' + o.no + '</button>'
    +     '<button type="button" class="sta-si' + (o.rischio ? ' rischio' : '') + '" id="staSi">' + o.si + '</button>'
    +   '</div>'
    + '</div>';
  el.hidden = false;
  document.body.classList.add('sta-on');
  const b = document.getElementById('staSi');
  if (b) b.onclick = function(){ stChiediChiudi(); setTimeout(o.fn, 120); };
}
function stChiediChiudi(){
  const el = document.getElementById('stAsk');
  if (el){ el.hidden = true; el.innerHTML = ''; }
  document.body.classList.remove('sta-on');
}

/** Spunta o ritiro di una riga, da qualunque foglio. `dopo` ridisegna chi ha chiamato. */
/* LA SPUNTA SI VEDE (0.9.232, Andrea): la riga spuntata non sparisce subito. Prima resta li', con la
   casella piena e il testo barrato; poi si chiude e una sua copia scivola verso "Completate", che si
   illumina. ST_TAP ricorda la riga toccata (la conferma "L'hai fatta davvero?" arriva dopo). */
const ST_TAP = { el: null };
document.addEventListener('pointerdown', function(e){
  const b = e.target && e.target.closest ? e.target.closest('.stf-box, .mf-box') : null; if (!b || b.classList.contains('on') || b.classList.contains('vuota')) return;
  ST_TAP.el = b.closest('.st-row, .mf-riga');
}, true);
function stAnimaFatta(el, dopo){
  if (!el || !el.isConnected){ if (dopo) dopo(); return; }
  el.classList.add('st-spuntata');
  const box = el.querySelector('.stf-box, .mf-box'); if (box){ box.classList.add('on'); box.textContent = '\u2713'; }
  try{ flVibra(15); }catch(_){ }
  const zona = el.closest('#mfCorpo') || el.closest('.st-sec') || el.closest('.st-note') || document;
  setTimeout(function(){
    if (!el.isConnected){ if (dopo) dopo(); return; }
    const r = el.getBoundingClientRect(); const sum = zona.querySelector('.st-fatte summary');
    const g = el.cloneNode(true); g.classList.add('st-spunta-vola'); g.removeAttribute('id');
    Object.assign(g.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px' });
    document.body.appendChild(g);
    el.style.height = r.height + 'px'; void el.offsetHeight; el.classList.add('st-chiude');
    let tx = 0, ty = 48; if (sum){ const q = sum.getBoundingClientRect(); tx = q.left - r.left; ty = q.top - r.top; }
    requestAnimationFrame(function(){ g.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(.55)'; g.style.opacity = '0'; });
    setTimeout(function(){
      g.remove(); if (dopo) dopo();
      const s2 = zona.querySelector('.st-fatte summary'); if (s2){ s2.classList.remove('st-lampo'); void s2.offsetWidth; s2.classList.add('st-lampo'); setTimeout(function(){ s2.classList.remove('st-lampo'); }, 1000); }
    }, 480);
  }, 700);
}
function stSpunta(line, day, dopo){
  const fatta = stIsDone(line, day);
  if (fatta){
    stChiedi({
      titolo: 'La togli dalle fatte?',
      riga: line,
      nota: 'L\u2019avevi dichiarata fatta. Rimangiarsela vale <b>un punto al vecchio te</b>: \u00e8 l\u2019unico modo di imbrogliare qui, e l\u2019arbitro lo vede.',
      no: 'Lascia stare', si: 'Non l\u2019ho fatta', rischio: true,
      fn: function(){ stRitira(line, day, dopo); }
    });
    return;
  }
  stChiedi({
    titolo: 'L\u2019hai fatta davvero?',
    riga: line,
    nota: 'Spunta solo quello che hai finito. Il punto lo d\u00e0 l\u2019arbitro, e guarda se c\u2019\u00e8 stata una sessione.',
    no: 'Non ancora', si: 'S\u00ec, fatta',
    fn: function(){ const el = ST_TAP.el; ST_TAP.el = null; stFatta(line, day, el ? function(){ stAnimaFatta(el, dopo); } : dopo); }
  });
}
function stFatta(line, day, dopo){
  /* la priorita' del giorno spuntata apre la scheda Domani (piano.js) a fine giornata */
  try{ if (line === stPriorita(day)) localStorage.setItem('fl_prio_fatta_' + day, line); }catch(_){ }
  const r = refRules();
  const seen = refSessionFor(line, day);
  const d = stDone();
  const w = line.trim().toLowerCase();
  /* UNA COSA SI SPUNTA UNA VOLTA SOLA.
     Il registro non controllava, e ogni strada che porta qui — la casella, il foglio grande,
     la sessione che chiude una riga — ne scriveva un'altra. Il 22/09 la giornata ne contava
     ottantadue per una manciata di righe vere, e la riserva di dopamina, che da li' prende il
     bonus, regalava dieci punti a ripetizione. */
  if (!d.some(function(x){ return x && x.day === day && x.text === w; })){
    d.push({ day: day, text: w, at: Date.now(), verified: !!seen });
    try{ localStorage.setItem(ST_DONE_KEY, JSON.stringify(d.slice(-2000))); }catch(_){ }
  }
  /* La lancetta della dopamina si muove ADESSO, non al prossimo giro di orologio: finire una
     cosa e' l'unico momento della giornata in cui il numero deve salire sotto gli occhi. */
  try{ document.dispatchEvent(new CustomEvent('fl:spunta', { detail: { line: line, day: day, azione: 'fatta' } })); }catch(_){ }
  /* se la riga era un passo della roadmap, il passo si chiude: e' cosi' che il successivo
     diventa la priorita' di domani (o di adesso) senza che nessuno lo pianifichi a mano */
  try{
    if (typeof ozLeggi === 'function' && typeof ozSalvaAnello === 'function'){
      const n = stNormRiga(line);
      ST_RM_LIVELLI.concat(['anno', 'cinque']).some(function(k){
        const a = ozAnello(k);
        const p = (a.passi || []).filter(function(x){ return x && !x.fatto && stNormRiga(x.t) === n; })[0];
        if (!p) return false;
        p.fatto = true; p.il = (typeof ozGiorno === 'function') ? ozGiorno() : day;
        ozSalvaAnello(k, a);
        return true;
      });
    }
  }catch(_){ }
  if (seen || !r.needSession) mtScore();
  else stNoteHint('Archiviata. L\'arbitro d' + '\u00e0' + ' il punto solo a quello che ha visto fare in FullFocus.');
  if (dopo) dopo();
  /* la frase di oggi si apre nell'istante in cui te la sei guadagnata, non al prossimo giro */
  try{ if (typeof citAggiornaPremio === 'function') citAggiornaPremio(); }catch(_){ }
  /* Il voto sulla stima, e solo dopo la prova: chiederla prima di aver fatto la cosa e'
     pressione inutile. */
  const m = stMeta(line, day);
  if (m.stima && !m.voto) setTimeout(function(){ stVotoChiedi(line, day); }, 900);
}
function stRitira(line, day, dopo){
  try{ document.dispatchEvent(new CustomEvent('fl:spunta', { detail: { line: line, day: day, azione: 'ritirata' } })); }catch(_){ }
  const w = String(line || '').trim().toLowerCase();
  try{ if (localStorage.getItem('fl_prio_fatta_' + day) === line) localStorage.removeItem('fl_prio_fatta_' + day); }catch(_){ }
  const d = stDone().filter(function(x){ return !(x.day === day && x.text === w); });
  try{ localStorage.setItem(ST_DONE_KEY, JSON.stringify(d)); }catch(_){ }
  let suo = false;
  try{ suo = (typeof mgOldPoint === 'function') && mgOldPoint('spunta ritirata: «' + String(line).slice(0, 60) + '»'); }catch(_){ }
  if (dopo) dopo();
  stNoteHint(suo ? 'Ritirata. Il punto va al vecchio te.' : 'Ritirata.');
}
/* LA PROVA IN FOTO NON SI CHIEDE PIU'.
   Arrivava da sola un secondo dopo ogni spunta — «Vuoi lasciarne una prova? Vale esperienza» —
   proprio nell'istante in cui uno aveva appena finito una cosa e stava per cominciare la
   prossima. Un invito che nessuno ha chiesto, in cambio di punti che nella partita non
   contano, e' una distrazione con il vestito buono. Chi vuole documentare una cosa fatta lo
   fa da se'. La funzione resta, vuota: chiamarla non deve rompere niente. */
function stProvaInvito(){ }

/* ---------- I DETTAGLI DI UNA RIGA ----------
   La riga resta corta e con un verbo; il resto sta dietro alla «i»: il tempo stimato (che poi
   si vota), i passi in cui spezzarla, una foto come prova (facoltativa: vale esperienza,
   non punti della partita). `fl_notes_meta` = { "<giorno>|<riga>": { stima, micro, foto, voto } }. */
const ST_META_KEY = 'fl_notes_meta';
function stMetaAll(){ try{ return JSON.parse(localStorage.getItem(ST_META_KEY) || '{}') || {}; }catch(_){ return {}; } }
function stMetaKey(line, day){ return (day || stDayKey()) + '|' + String(line || '').trim().toLowerCase(); }
function stMeta(line, day){
  const all = stMetaAll();
  const m = all[stMetaKey(line, day)] || {};
  if (!m.stima){
    /* la stima scritta nella riga stessa: «(10 min)», «· 25 min», «30 minuti» */
    const x = String(line || '').match(/(\d{1,3})\s*min/i);
    if (x) m.stima = +x[1];
  }
  return m;
}
function stMetaSave(line, day, patch){
  const all = stMetaAll();
  const k = stMetaKey(line, day);
  all[k] = Object.assign({}, all[k] || {}, patch || {});
  const keys = Object.keys(all);
  if (keys.length > 400) keys.slice(0, keys.length - 400).forEach(function(x){ delete all[x]; });
  try{ localStorage.setItem(ST_META_KEY, JSON.stringify(all)); }catch(_){ }
  if (typeof lvBump === 'function') try{ lvBump(); }catch(_){ }
}
/* ---------- LA PAGINA DELLA RIGA ----------
   Si guarda per una cosa sola: capire cosa devo fare adesso. Quindi in cima c'e' la riga
   INTERA (niente troncamento: era illeggibile), poi il quadrante che dice che tipo di cosa
   e', poi i passi. Il tempo stimato sta in fondo, perche' e' una scelta che si fa dopo aver
   letto, non prima. La prova non esiste finche' la cosa non e' fatta: mostrarla prima e'
   chiedere il conto a chi non ha ancora mangiato.

   Un'emoji sola in tutta la pagina — quella del quadrante — perche' se ce l'hanno tutti i
   titoli non ce l'ha piu' nessuno. */
const STR = { line: '', day: '', back: 's-home' };
registerScreen('s-riga', '<div class="str-wrap">'
  + '<div class="str-top"><button class="iconbtn" onclick="stRigaClose()" aria-label="Indietro">\u2039</button></div>'
  + '<div class="str-body" id="strBody"></div>'
  + '</div>', { back: 's-home' });
function stRigaOpen(line, day, back){
  /* Si accetta anche il vecchio modo (un indice nel foglio di oggi), cosi' nessun richiamo
     rimasto in giro apre una pagina vuota. */
  if (typeof line === 'number'){ const r = stLines(); line = r[line] || ''; day = stDayKey(); }
  if (!line) return;
  STR.line = line; STR.day = day || stDayKey(); STR.back = back || 's-home';
  goId('s-riga');
  stRigaPaint();
}
function stRigaClose(){
  stRigaSalvaTesto();
  if (STR.back === 's-notes'){ goId('s-notes'); stfPaint(); return; }
  goId('s-home'); switchTab('sveglia');
  setTimeout(function(){ stListPaint(); stNoteFoot(); }, 120);
}
function stRigaPaint(){
  const host = document.getElementById('strBody');
  if (!host) return;
  const m = stMeta(STR.line, STR.day);
  const q = stEtichetta(STR.line);
  const fatta = stIsDone(STR.line, STR.day);
  const righe = stRigheDi(STR.day);
  const sez = stSezione(STR.line, STR.day, righe);
  const premium = (typeof Premium !== 'undefined') && Premium.isPremium();
  const passi = !!((m.micro && m.micro.length) || m.passiChiesti);

  host.innerHTML =
    /* 1 · la cosa da fare */
      '<textarea class="str-testo" id="strTesto" rows="2" oninput="stNoteGrow(this)">' + esc(STR.line) + '</textarea>'
    + '<div class="str-quad ' + q.cls + '"><b>' + q.t + '</b><small>' + q.spiega + '</small></div>'

    /* 2 · dove sta nel foglio: la matrice decide, tu puoi spostarla */
    + '<div class="str-sez">Dove sta</div>'
    + (fatta
        ? '<p class="str-hint">Fatta: sta in <b>Completate</b>.</p>'
        : '<div class="str-chips">' + ST_SEZIONI.filter(function(x){ return x[0] !== 'fatte'; }).map(function(x){
            return '<button type="button" class="' + (sez === x[0] ? 'on' : '') + '" onclick="stRigaSez(\'' + x[0] + '\')">' + x[1] + '</button>';
          }).join('') + '</div>'
          + '<p class="str-hint">' + (m.sez ? 'L\u2019hai messa tu qui.' : 'Decisa dalla matrice: importante se sta sulla rotta, urgente se ha una scadenza.') + '</p>')

    /* 3 · i passi: compaiono quando li chiedi, non prima */
    + '<div class="str-sez">I passi</div>'
    + (function(){
        const q = stScompDi(STR.line, STR.day);
        const attesa = q && q.stato === 'attesa';
        const campo = '<textarea class="str-micro" id="strMicro" rows="3" placeholder="Un passo per riga: da dove parti, cosa fai, come sai che \u00e8 finita" onblur="stRigaMicro()">' + esc((m.micro || []).join('\n')) + '</textarea>';
        const bottone = premium
          ? '<button type="button" class="str-btn ghost" onclick="stRigaChiediPassi()"' + (attesa ? ' disabled' : '') + '>\ud83e\uddde ' + (attesa ? 'Il tuo agente personale ci sta pensando' : 'Falli scrivere al tuo agente personale') + '</button>'
          : '<button type="button" class="str-btn ghost premium" onclick="go(11)">\ud83d\udd12 Falli scrivere al tuo agente personale \u00b7 Premium</button>';
        const nota = attesa
          ? '<p class="str-hint">Risponde nel verdetto della sera (22:45). Nel frattempo puoi scriverli tu: i suoi si aggiungono, non sostituiscono.</p>'
          : (q && q.stato === 'vuota' && q.motivo)
            ? '<p class="str-hint">Il tuo agente personale non l\'ha scomposta: ' + esc(q.motivo) + '</p>'
            : premium
              ? '<p class="str-hint">Lui conosce la tua rotta: divide in passi che stanno dentro a una sessione.</p>'
              : '<p class="str-hint">Con Premium li scrive il tuo agente personale, gi\u00e0 divisi. Senza, scrivili tu: uno per riga.</p>';
        return passi ? campo + bottone + nota
          : '<button type="button" class="str-btn ghost" onclick="stRigaPassi()">Scomponi in passi</button>'
            + '<p class="str-hint">Solo se ti serve. ' + (premium ? 'Poi puoi scriverli tu o farli scrivere al tuo agente personale.' : 'Con Premium li scrive il tuo agente personale.') + '</p>';
      })()

    /* 3b · una mano (0.9.206): il tutorial, o il tuo agente personale */
    + '<div class="str-sez">Se non sai da dove partire</div>'
    + '<button type="button" class="str-btn ghost" onclick="aiApri(STR.line)">🎥 Chiedi una mano: un tutorial, o il tuo agente personale</button>'
    + '<p class="str-hint">Un video che mostra come si fa, con un tempo deciso prima. Poi il Full Focus.</p>'

    /* 4 · il tempo, per ultimo */
    + '<div class="str-sez">Tempo stimato</div>'
    + '<div class="str-chips">' + [10, 25, 45, 60, 90].map(function(n){
        return '<button type="button" class="' + (m.stima === n ? 'on' : '') + '" onclick="stRigaStima(' + n + ')">' + (n >= 60 ? Math.floor(n / 60) + ' h' + (n % 60 ? ' ' + (n % 60) : '') : n + ' min') + '</button>';
      }).join('') + '</div>'
    + '<p class="str-hint">' + (m.voto
        ? 'Quando l\u2019hai fatta hai detto che erano <b>' + esc(m.voto) + '</b>.'
        : 'Quando la spunti ti chiedo se erano giusti.') + '</p>'

    /* 4b · a Jordan */
    + '<div class="str-sez">Jordan</div>'
    + '<button type="button" class="str-btn ghost" onclick="stRevChiedi(STR.line)">Manda in revisione</button>'
    + '<p class="str-hint">Lui la confronta con la tua rotta e risponde nel verdetto della sera.</p>'

    /* 5 · una prova gia' allegata resta visibile e si puo' togliere; di nuove non se ne chiedono */
    + (fatta && m.foto
        ? '<div class="str-sez">La prova</div>'
          + '<div class="str-foto"><img src="' + esc((window.Capacitor && Capacitor.convertFileSrc) ? Capacitor.convertFileSrc(m.foto) : m.foto) + '" alt="">'
          + '<button type="button" class="str-btn ghost" onclick="stRigaFotoVia()">Togli la prova</button></div>'
        : '');
  const a = document.getElementById('strTesto');
  if (a) stNoteGrow(a);
}
function stRigaSez(k){ stMetaSave(STR.line, STR.day, { sez: k }); stRigaPaint(); try{ ntToccato(); }catch(_){ } }
function stRigaPassi(){
  stMetaSave(STR.line, STR.day, { passiChiesti: true });
  stRigaPaint();
  setTimeout(function(){ const a = document.getElementById('strMicro'); if (a) a.focus(); }, 150);
}

/* ---------- SCOMPORRE UNA COSA GROSSA, CHIEDENDOLO ALL'AGENTE ----------
   LA PARTE CHE NON DEVE FARE L'UTENTE. Pianificare costa la stessa energia che serve a fare,
   e quando finisce vince quella delle due che si puo' fare seduti: si riscrive l'elenco. Il
   piano lo scrive l'agente in base alla rotta che il Genio ha tracciato; a chi usa l'app
   restano le cose da fare. Qui dentro vale per una riga sola: «questa e' troppo grossa,
   spaccala in passi che stiano dentro a una sessione».

   PERCHE' E' PREMIUM. E' l'unica cosa in quest'app che costa davvero qualcosa a ogni uso —
   gira su un agente vero, non su una formula scritta qui dentro. Chi non ce l'ha non trova
   una porta chiusa: trova il campo di testo, e li scrive lui. */
const ST_SCOMP_KEY = 'fl_scomponi';
function stScompLista(){ try{ return JSON.parse(localStorage.getItem(ST_SCOMP_KEY) || '[]') || []; }catch(_){ return []; } }
function stScompSalva(l){ try{ localStorage.setItem(ST_SCOMP_KEY, JSON.stringify(l.slice(-40))); }catch(_){ } }
function stScompDi(line, day){
  return stScompLista().filter(function(x){ return x.testo === line && x.giorno === day; }).pop() || null;
}
function stRigaChiediPassi(){
  if (stScompChiedi(STR.line, STR.day)) stRigaPaint();
}
/**
 * «Non so da dove partire»: la riga va al tuo agente personale, che risponde nel verdetto della sera con
 * i passi in cui spaccarla. Torna true se la richiesta e' partita. La chiama il foglio (la
 * riga) e il pannello del primo passo dopo la chiamata dei sogni (prenota.js).
 */
function stScompChiedi(line, day){
  /* chi ha il suo agente: la riga parte adesso e i passi arrivano in un minuto (Opus, a crediti) */
  const conAgente = (typeof agAbilitatoOra === 'function') && agAbilitatoOra() && (typeof agPuo === 'function') && agPuo();
  if (!conAgente && !((typeof Premium !== 'undefined') && Premium.isPremium())){
    toast('Con Premium te li scrive il tuo agente personale');
    return false;
  }
  line = String(line || '').trim(); day = day || stDayKey();
  if (!line) return false;
  const gia = stScompDi(line, day);
  if (gia && gia.stato === 'attesa'){ toast(gia.msgId ? 'Gi\u00e0 chiesto: i passi arrivano fra poco' : 'Gi\u00e0 chiesto: risponde nel verdetto della sera'); return false; }
  const l = stScompLista();
  const q = { id: 's' + Date.now().toString(36), testo: line, giorno: day, at: Date.now(), stato: 'attesa' };
  l.push(q);
  stScompSalva(l);
  try{ stMetaSave(line, day, { passiChiesti: true }); }catch(_){ }
  if (conAgente && typeof agScomponi === 'function'){
    toast('Chiesto al tuo agente personale: i passi arrivano fra poco');
    agScomponi(q);
    return true;
  }
  toast('Chiesto al tuo agente personale: risponde nel verdetto della sera');
  try{ if (typeof jdDeposita === 'function') jdDeposita(true); }catch(_){ }
  return true;
}
/* La risposta dell'agente arriva dentro al verdetto, insieme a tutto il resto: si applica
   una volta sola, e i passi che l'utente ha gia' scritto a mano non si toccano. */
function stScompApplica(v){
  if (!v || !Array.isArray(v.scomposizioni) || !v.scomposizioni.length) return;
  const l = stScompLista();
  let cambiati = 0;
  v.scomposizioni.forEach(function(r){
    const q = l.filter(function(x){ return x.id === r.id && x.stato === 'attesa'; })[0];
    if (!q) return;
    const passi = (Array.isArray(r.passi) ? r.passi : []).map(function(t){ return String(t).trim(); }).filter(Boolean);
    q.stato = passi.length ? 'fatta' : 'vuota';
    q.motivo = String(r.motivo || '');
    if (passi.length){
      const m = stMeta(q.testo, q.giorno);
      const avuti = (m.micro || []).filter(Boolean);
      const visti = {};
      avuti.forEach(function(t){ visti[t.toLowerCase()] = 1; });
      const nuovi = avuti.slice();
      passi.forEach(function(t){ if (!visti[t.toLowerCase()]){ visti[t.toLowerCase()] = 1; nuovi.push(t); } });
      stMetaSave(q.testo, q.giorno, { micro: nuovi, passiChiesti: true });
      cambiati++;
    }
  });
  stScompSalva(l);
  if (cambiati && typeof toast === 'function') toast('Il tuo agente personale ha scomposto ' + cambiati + (cambiati === 1 ? ' cosa' : ' cose'));
}
function stRigaSalvaTesto(){
  const a = document.getElementById('strTesto');
  if (!a) return;
  const nuovo = a.value.replace(/\n+/g, ' ').trim();
  if (!nuovo || nuovo === STR.line) return;
  /* la riga vive nel foglio del suo giorno, che non e' per forza oggi */
  let righe = [];
  try{ righe = (localStorage.getItem('fl_notes_' + STR.day) || '').split('\n').map(function(t){ return t.trim(); }).filter(Boolean); }catch(_){ }
  const i = righe.indexOf(STR.line);
  if (i < 0) return;
  const all = stMetaAll(); const vecchio = all[stMetaKey(STR.line, STR.day)];
  righe[i] = nuovo;
  try{ localStorage.setItem('fl_notes_' + STR.day, righe.join('\n')); }catch(_){ }
  try{ if (typeof fsToccato === 'function') fsToccato(STR.day); }catch(_){ }
  if (vecchio){
    delete all[stMetaKey(STR.line, STR.day)];
    all[stMetaKey(nuovo, STR.day)] = vecchio;
    try{ localStorage.setItem(ST_META_KEY, JSON.stringify(all)); }catch(_){ }
  }
  STR.line = nuovo;
}
function stRigaStima(n){ stMetaSave(STR.line, STR.day, { stima: n }); stRigaPaint(); }
function stRigaMicro(){
  const a = document.getElementById('strMicro');
  if (!a) return;
  stMetaSave(STR.line, STR.day, { micro: a.value.split('\n').map(function(x){ return x.trim(); }).filter(Boolean).slice(0, 12) });
}
function stRigaFoto(){ stRigaFotoDa(STR.line, STR.day, stRigaPaint); }
async function stRigaFotoDa(line, day, dopo){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.pickImages){ toast('Disponibile sul telefono'); return; }
  try{
    const r = await NATIVE.pickImages();
    const u = (r && r.images && r.images[0]) || (r && r.uris && r.uris[0]) || (r && r.uri) || '';
    if (!u) return;
    stMetaSave(line, day, { foto: u, fotoAt: Date.now() });
    toast('Prova allegata: +25 esperienza');
    if (dopo) dopo();
  }catch(_){ }
}
function stRigaFotoVia(){ stMetaSave(STR.line, STR.day, { foto: '', fotoAt: 0 }); stRigaPaint(); }
/* Il voto sul tempo stimato, dopo la spunta. */
function stVotoChiedi(line, day){
  const m = stMeta(line, day);
  const el = document.getElementById('stNoteHint'); if (!el) return;
  el.innerHTML = 'I <b>' + m.stima + ' min</b> stimati erano: '
    + ['troppo pochi', 'giusti', 'troppi'].map(function(v){ return '<button type="button" class="st-voto" onclick="stVotoDai(' + JSON.stringify(line).replace(/"/g, '&quot;') + ',\'' + day + '\',\'' + v + '\')">' + v + '</button>'; }).join('');
  el.classList.add('on');
  clearTimeout(ST_HINT_T); ST_HINT_T = setTimeout(function(){ el.classList.remove('on'); }, 15000);
}
function stVotoDai(line, day, v){
  stMetaSave(line, day, { voto: v, votoAt: Date.now() });
  stNoteHint({ 'troppo pochi': 'Segnato: la prossima volta stima pi\u00f9 largo.', 'giusti': 'Segnato: stima giusta, occhio allenato.', 'troppi': 'Segnato: la prossima volta stima pi\u00f9 stretto.' }[v] || 'Segnato.');
  stListPaint();
}

/* ---------- la dettatura ----------
   Il pulsante rosa e' il microfono. Mentre parli, al suo posto c'e' la pillola con l'onda e i
   due gesti: la X butta via, la spunta tiene. Il testo compare nel foglio mentre lo dici, e
   se annulli il foglio torna com'era. Premium, e da accendere in Personalizza. */
const STD = { on: false, before: '', text: '', cur: '', lvl: 0 };
function stDictAllowed(){
  /* 0.9.254, Andrea: la dettatura standard e' per tutti; Premium sono gli appunti AI (dettatura.js, dtAiOn) */
  /* 0.9.267, Andrea: il microfono era sparito (onboarding, note). Dopo "Ricomincia da capo" l'interruttore non era
     piu' acceso, e la dettatura "standard per tutti" era di fatto spenta per tutti. Accesa di serie: si spegne solo se
     l'utente la spegne (dictation === false). */
  return !(typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.dictation === false);
}
async function stDictStart(){
  if (STD.on) return;
  STD.full = !!(document.querySelector('.screen.active') && document.querySelector('.screen.active').id === 's-notes');
  if (!NATIVE || !NATIVE.dictationStart){ toast('Disponibile solo nell\'app installata'); return; }
  const premium = (typeof Premium !== 'undefined') && Premium.isPremium();
  if (!premium){ toast('La dettatura vocale è Premium'); if (typeof pwOpen === 'function') pwOpen(); return; }
  if (!stDictAllowed()){ toast('Accendila in Personalizza: Dettatura vocale'); goId('s-personalize'); return; }
  const box = stDictBox();
  STD.before = box ? box.value : '';
  STD.text = ''; STD.cur = '';
  try{
    await NATIVE.dictationStart();
    STD.on = true;
    stDictPaint();
  }catch(e){
    const code = e && e.code;
    toast(code === 'permission' ? 'Concedi il microfono e ritocca il pulsante' : (e && e.message) || 'Dettatura non disponibile');
  }
}
function stDictBox(){
  /* nel foglio grande si detta nel campo della riga nuova; nel pannello, nella scheda Note */
  const attiva = document.querySelector('.screen.active');
  if (attiva && attiva.id === 's-notes') return document.getElementById('stfNuova');
  return document.getElementById('stNotes');
}
/* Quello che si vede mentre parli: quello che c'era gia', piu' i pezzi consegnati, piu' il
   pezzo che stai dicendo adesso. Niente di tutto questo e' ancora salvato. */
function stDictText(){
  /* 0.9.285: il parziale contiene gia' i pezzi chiusi (dtUnisci, dettatura.js): niente doppioni */
  if (typeof dtUnisci === 'function') return dtUnisci(STD.text, STD.cur);
  const a = (STD.text || '').trim(), b = (STD.cur || '').trim();
  return (a && b) ? (b.indexOf(a) === 0 ? b : a + ' ' + b) : (a || b);
}
function stDictPreview(){
  const box = stDictBox();
  if (!box) return;
  const t = stDictText();
  const base = STD.before.replace(/\s+$/, '');
  box.value = t ? (base ? base + '\n' : '') + t : STD.before;
  stNoteGrow(box);
}
async function stDictOk(){
  if (!STD.on) return;
  /* La spunta e' l'unico modo di finire: il silenzio non conta, e nemmeno una pausa lunga. */
  try{ await NATIVE.dictationStop(); }catch(_){ }
  setTimeout(function(){ if (STD.on) stDictCommit(); }, 2000);
}
function stDictCommit(){
  if (!STD.on) return;
  STD.on = false;
  const box = stDictBox();
  if (box){
    const base = STD.before.replace(/\s+$/, '');
    const t = stDictText();
    box.value = t ? (base ? base + '\n' : '') + t : STD.before;
    if (box.id === 'stfNuova'){ stfAggiungi(); }
    else stNotesCommit();
  }
  stDictPaint();
}
async function stDictCancel(){
  if (!STD.on) return;
  STD.on = false;
  try{ await NATIVE.dictationCancel(); }catch(_){ }
  const box = stDictBox();
  if (box){ box.value = STD.before; stNoteGrow(box); }
  stDictPaint();
}
function stDictPaint(){
  const el = document.getElementById('stDict');
  if (!el) return;
  el.classList.toggle('on', STD.on);
  const bars = el.querySelector('.st-wave');
  if (bars) bars.style.setProperty('--lvl', STD.lvl.toFixed(2));
}
try{
  if (NATIVE && NATIVE.addListener) NATIVE.addListener('dictation', function(ev){
    if (!STD.on || !ev) return;
    /* partial = quello che sto dicendo adesso; segment = un pezzo chiuso dal riconoscitore
       perche' mi sono fermato a pensare, e NON finisce la dettatura; final = arriva solo dopo
       la spunta. */
    if (ev.state === 'partial'){ STD.cur = ev.text || ''; stDictPreview(); }
    else if (ev.state === 'segment'){ STD.text = ev.text || STD.text; STD.cur = ''; stDictPreview(); }
    else if (ev.state === 'final'){
      /* 0.9.285: la frase finale vince, ma mai se ha meno parole di quelle gia' sentite */
      const fin = String(ev.text || '').trim(), ora = stDictText();
      const parole = function(t){ return String(t || '').trim() ? String(t).trim().split(/\s+/).length : 0; };
      STD.text = (fin && parole(fin) >= parole(ora) - 1) ? fin : ora;
      STD.cur = ''; stDictCommit();
    }
    else if (ev.state === 'level'){ STD.lvl = Math.max(0, Math.min(1, ((+ev.rms || 0) + 2) / 12)); stDictPaint(); }
    /* 0.9.285: interrotta, ma quello che hai gia' detto resta nel foglio */
    else if (ev.state === 'error'){
      if (stDictText()){ toast('La dettatura si è interrotta: scrivo quello che hai detto'); stDictCommit(); }
      else { toast('La dettatura si è interrotta'); stDictCancel(); }
    }
  });
}catch(_){ }

/* Il carosello: due pannelli, e si passa al secondo solo con un pulsante. Niente scorrimento
   laterale — chi arriva qui non deve scoprire per sbaglio un esercizio che non ha chiesto. */
/* I caroselli si sfogliano col dito. Sono due — quello della scelta e quello della spinta —
   e la stessa funzione li serve entrambi: `data-car` dice quale. */
function stCarSwipe(){
  document.querySelectorAll('.st-car').forEach(function(car){
    if (car.dataset.swipe) return;
    car.dataset.swipe = '1';
    let x0 = 0, y0 = 0, t0 = 0;
    car.addEventListener('touchstart', function(e){ const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); }, { passive: true });
    car.addEventListener('touchend', function(e){
      const t = e.changedTouches[0]; const dx = t.clientX - x0, dy = t.clientY - y0;
      if (Math.abs(dx) < 48 || Math.abs(dy) > Math.abs(dx) || Date.now() - t0 > 700) return;
      const on = Array.prototype.indexOf.call(car.children, car.querySelector('.st-pane.on'));
      const next = dx < 0 ? on + 1 : on - 1;
      if (next >= 0 && next < car.children.length) stCarGo(next, car.id);
    }, { passive: true });
  });
}
/* I pannelli del primo carosello si chiamano per nome. Erano numeri scritti a mano dentro
   gli onclick, e infilare la frase del giorno in seconda posizione li avrebbe spostati tutti
   di uno in silenzio: «Le sveglie ›» avrebbe portato alla scrematura. */
const ST_PANE = { foglio: 0, frase: 1, scrematura: 2, sveglie: 3, promemoria: 4 };
function stCarVai(nome){ stCarGo(ST_PANE[nome] || 0, 'stCar'); }
function stCarGo(i, carId){
  const car = document.getElementById(carId || 'stCar');
  if (!car) return;
  Array.prototype.forEach.call(car.children, function(p, k){ p.classList.toggle('on', k === i); });
  const dots = document.getElementById(car.id + 'Dots');
  if (dots) Array.prototype.forEach.call(dots.children, function(d, k){ d.classList.toggle('on', k === i); });
  /* la citazione si scrive quando la sua diapositiva arriva davanti, non prima: una macchina
     da scrivere che batte dietro a un pannello chiuso è lavoro per nessuno */
  const pane = car.children[i];
  const cit = pane && pane.querySelector('.cit-slide');
  if (cit && typeof citBattiSlide === 'function') setTimeout(function(){ citBattiSlide(cit.dataset.cit); }, 260);
}

/* =========================================================================================
   IL PROMEMORIA DELLA PIANIFICAZIONE
   Un'ora per ricordare di scrivere cosa vuoi fare, e un'ora entro cui deve esistere.
   ========================================================================================= */
const PN_KEY = 'fl_plan_notif';
function pnRead(){
  const d = { on: false, at: '21:00', by: '23:00' };
  try{ return Object.assign(d, JSON.parse(localStorage.getItem(PN_KEY) || 'null') || {}); }
  catch(_){ return d; }
}
function pnMin(hhmm){
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || ''));
  return m ? Math.max(0, Math.min(1439, (+m[1]) * 60 + (+m[2]))) : -1;
}
/* Il giorno per cui un piano esiste gia': domani se c'e', altrimenti oggi. */
function pnDoneDay(){
  const t = mtKey(Date.now() + 86400000), o = mtKey(Date.now());
  return mtPlanned(t) ? t : (mtPlanned(o) ? o : '');
}
function pnPush(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setSettings) return;
  const p = pnRead(), st = mtState();
  const patch = {
    planRemind: p.on ? pnMin(p.at) : -1,
    planRemindBy: p.on ? pnMin(p.by) : -1,
    planDoneDay: pnDoneDay(),
    planSaves: st.saves
  };
  try{
    if (typeof SETTINGS !== 'undefined') Object.assign(SETTINGS, patch);
    /* SOLO LA PATCH, MAI L'OGGETTO INTERO. `SETTINGS` in memoria parte dai valori di fabbrica
       (usageToastMin: 0, lockStyle: 'base'…) e si riempie dal motore solo quando si apre una
       pagina impostazioni. Spedirlo intero da qui voleva dire: apri l'app, scrivi il piano, e
       il motore riceve «messaggio del tempo totale: spento» insieme al promemoria. E' la
       causa dell'interruttore che si spegneva da solo dopo qualche minuto, segnalata tre
       volte. Il motore unisce le patch da se': mandargli solo cio' che e' cambiato e' l'unica
       cosa corretta. */
    NATIVE.setSettings(patch);
  }catch(_){ }
}
function pnSet(k, v){
  const p = pnRead();
  p[k] = v;
  /* ACCENDERE IL PROMEMORIA E' IL MOMENTO GIUSTO PER CHIEDERE IL PERMESSO.
     Prima non si capirebbe perche', altrove non ci passa nessuno, dopo e' gia' tardi: la
     notifica delle 22:15 sarebbe partita e il sistema l'avrebbe buttata in silenzio. */
  if (k === 'on' && v && typeof ntChiedi === 'function'){
    ntChiedi().then(function(){ if (typeof ntAvvisoPaint === 'function') ntAvvisoPaint(); });
  }
  try{ localStorage.setItem(PN_KEY, JSON.stringify(p)); }catch(_){ }
  /* L'ora limite e' una sola: quella che l'arbitro guarda per dare il punto e quella oltre la
     quale scatta la protezione. Tenerne due sarebbe un modo elegante di mentire all'utente. */
  if (k === 'by' && typeof refSave === 'function') refSave({ planBy: v });
  pnPush();
  stPaint();
  stCarVai('promemoria');
}

/* =========================================================================================
   PROTEZIONE SERIE — la regola dei due giorni
   ========================================================================================= */
registerOverlay('spWrap', '<div class="sp-scrim" onclick="spClose()"></div><div class="sp-sheet" id="spSheet"></div>');
registerOverlay('goalWrap', '');
/* Spento alla nascita: registerOverlay crea il contenitore senza `hidden`, e un pannello a
   tutto schermo trasparente ma vivo si prende ogni tocco dell'app. Gia' pagata una volta. */
(function(){ const el = document.getElementById('goalWrap'); if (el){ el.hidden = true; el.classList.remove('open', 'in'); } })();

function spPaint(){
  const host = document.getElementById('spHost');
  if (!host) return;
  const s = mtRoll();
  const glow = spAutoFresh(s);
  const today = mtKey(Date.now());
  const serie = (typeof serStreak === 'function') ? serStreak() : 0;
  host.innerHTML =
    /* IL CASSETTO. La card resta quella — un tocco sulla riga la apre, e sotto c'e' il
       calendario del mese con i giorni tenuti. Chiuso di serie: una serie si guarda quando
       si ha voglia di guardarla, non ogni volta che si passa di li'. */
      '<div id="serWrap" class="' + (typeof serAperta === 'function' && serAperta() ? 'open' : '') + '">'
    /* 0.9.350, Andrea: "Nessun serie in corso non e' italiano e va a capo parola per parola; il ? accanto al titolo, il titolo su una riga,
       il pannello azzurro chiaro; e la protezione del Full Focus non si confonde con il congelamento delle tappe". Qui e' la protezione
       dello slancio, con lo scudo; il ghiaccio resta alle tappe della mappa */
    + '<div class="sp-card sp-card2' + (glow ? ' burnt' : '') + '" onclick="serToggle()">'
    +   '<span class="sp-ico">🛡️</span>'
    +   '<div class="sp-txt">'
    +     '<div class="sp-row"><b>Protezione dello slancio</b><button type="button" class="sp-q" onclick="event.stopPropagation();spOpen()" aria-label="Come funziona">?</button></div>'
    /* CORTA. La spiegazione intera sta nel «?» e nel cassetto qui sotto: scritta anche qui
       rendeva la colonna alta quattro righe, e l'icona finiva a mezza card per conto suo. */
    +     '<small>' + (glow
            ? 'Ne \u00e8 scattata una da sola'
            : serie
              ? serie + (serie === 1 ? ' giorno di fila in Full Focus' : ' giorni di fila in Full Focus')
              : 'Salva i giorni di fila in Full Focus') + '</small>'
    /* 0.9.353, Andrea: "il titolo va a capo su tre righe e il riquadro 2 protezioni ruba lo spazio". La pillola scende sotto la
       riga dei giorni, in orizzontale e con il verbo; il titolo resta su una riga con il ? accanto. E la riga senza giorni di
       fila e' piu' corta ("Protegge i tuoi giorni di fila in Full Focus" andava a capo anche lei) */
    +     '<span class="sp-n-pill' + (s.saves ? '' : ' zero') + '">' + (s.saves
            ? 'Hai <b>' + s.saves + '</b> ' + (s.saves === 1 ? 'protezione' : 'protezioni')
            : 'Non ti restano protezioni') + '</span>'
    /* IL PULSANTE NON STA PIU' QUI.
       «Usane una per oggi» in bella vista sulla card e' un invito a saltare la giornata: lo
       vedi ogni volta che passi di li', e ogni volta e' un pochino piu' facile. Sta dentro al
       foglio del punto di domanda, prima di «Ho capito» — dove ci arrivi solo se hai deciso
       di cercarlo, dopo aver letto quanto costa. La protezione resta a un tocco di distanza,
       ma quel tocco adesso e' una scelta, non un riflesso. */
    +   '</div>'
    +   '<svg class="sp-chev" viewBox="0 0 24 24" width="17" height="17" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" d="M6 9l6 6 6-6"/></svg>'
    + '</div>'
    + '<div id="serBody"></div>'
    + '</div>';
  try{ if (typeof serPaint === 'function') serPaint(); }catch(_){ }
  /* Il telefono tiene il numero per scriverlo nell'ultima chiamata della sera. */
  pnPush();
}
/** Se oggi la protezione si puo' ancora usare: ne resta almeno una, non ne e' gia' scattata
    una oggi, e il piano di oggi non c'e' (con il piano fatto non c'e' niente da proteggere). */
function spPuoUsarla(){
  const s = mtRoll();
  const today = mtKey(Date.now());
  /* Con una sessione gia' chiusa non c'e' niente da proteggere: la giornata e' salva da se'. */
  const fatte = (typeof serSessioniDi === 'function') ? serSessioniDi(today) : 0;
  return s.saves > 0 && !spUsedOn(s, today) && !fatte;
}

function spOpen(){
  const w = document.getElementById('spWrap'), sh = document.getElementById('spSheet');
  if (!w || !sh) return;
  const s = mtRoll();
  /* 0.9.309, Andrea (715): il conteggio sta SOTTO AL TITOLO, come un sottotitolo, e non in
     fondo fra il testo e i pulsanti; e i pulsanti hanno una gerarchia vera. Se oggi la
     protezione serve (spPuoUsarla: ne resta una, non e' gia' scattata, nessuna sessione oggi)
     "Usane una per oggi" e' il pulsante blu e "Ho capito" il secondario subito sotto; se non
     serve, resta solo "Ho capito", blu. Pillole da 50px, vicine. */
  const conto = s.saves > 0
    ? 'Ne hai ' + s.saves + ' su ' + MT_SAVES_WEEK + ' questa settimana'
    : 'Le hai già usate tutte questa settimana';
  sh.innerHTML =
      '<div class="sp-grab"></div>'
    + '<button type="button" class="sp-x" onclick="spClose()" aria-label="Chiudi">'
    +   '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '<div class="sp-bigico">🛡️</div>'
    + '<h2 class="sp-h">Proteggi il tuo slancio</h2>'
    + '<div class="sp-count' + (s.saves > 0 ? '' : ' zero') + '">' + conto + '</div>'
    /* CORTO. Tre frasi, una cosa per frase. Il resto lo racconta la card. */
    + '<p class="sp-p">Un giorno senza sessioni di Full Focus <strong>non spezza lo slancio</strong>: lo copre una protezione.</p>'
    + '<p class="sp-p"><strong>Due di fila</strong> sì. E per tenerla basta una sessione al giorno.</p>'
    /* 0.9.322, Andrea: "come su Duolingo: scatta da sola, l'utente non deve decidere niente" */
    + '<p class="sp-p sp-note">Scatta da sola: non devi ricordarti niente.</p>'
    + '<div class="sp-btns"><button type="button" class="sp-btn sp-btn-blu" onclick="spClose()">Ho capito</button></div>';
  w.classList.remove('closing');
  w.classList.add('open');
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
(function spSheetStyle(){
  const st = document.createElement('style');
  /* 0.9.309: conteggio sotto al titolo, X, pulsanti a pillola con gerarchia, foglio scuro che
     stacca dal velo (piu' chiaro del velo, bordo chiaro in cima). */
  st.textContent = '.sp-x{position:absolute;top:14px;right:16px;width:36px;height:36px;border:0;border-radius:50%;'
    + 'display:flex;align-items:center;justify-content:center;background:rgba(0,30,68,.07);color:#0F2041;cursor:pointer}'
    + 'body.dark .sp-x{background:rgba(255,255,255,.14);color:#fff}'
    + '#spSheet .sp-h{margin-top:18px}'
    + '#spSheet .sp-count{margin-top:12px;padding:8px 16px;background:#E3F1FF;color:#005BB0;font:800 13px var(--font-body)}'
    + '#spSheet .sp-count.zero{background:#FDECEC;color:#C42B38}'
    + 'body.dark #spSheet .sp-count{background:rgba(140,198,255,.16);color:#BCE0FF}'
    + 'body.dark #spSheet .sp-count.zero{background:rgba(230,57,70,.2);color:#FFC2C7}'
    + '#spSheet .sp-p{margin-top:16px}'
    + '#spSheet .sp-count + .sp-p{margin-top:22px}'
    + '.sp-btns{display:flex;flex-direction:column;gap:10px;margin-top:30px}'
    + '.sp-btn{display:block;width:100%;border-radius:50px;padding:16px 20px;font:800 15px var(--font-body);cursor:pointer;border:0}'
    + '.sp-btn-blu{background:#0075E3;color:#fff;box-shadow:0 8px 20px rgba(0,117,227,.28)}'
    + '.sp-btn-sec{background:transparent;border:1.5px solid #BCE0FF;color:#0F2041}'
    + 'body.dark .sp-btn-sec{border-color:rgba(188,224,255,.45);color:#fff}'
    + 'body.dark #spWrap .sp-sheet{background:#1C2E5A;box-shadow:0 -1px 0 rgba(188,224,255,.35),0 -14px 40px rgba(0,0,0,.45)}'
    + 'body.dark #spWrap .sp-scrim{background:rgba(0,8,24,.66)}'
    + 'body.dark #spSheet .sp-p{color:#C9D8EE}'
    + 'body.dark #spSheet .sp-grab{background:rgba(188,224,255,.4)}';
  document.head.appendChild(st);
})();

function spClose(){
  const w = document.getElementById('spWrap');
  if (!w || !w.classList.contains('open')) return;
  w.classList.remove('in');
  w.classList.add('closing');
  setTimeout(function(){ w.classList.remove('open', 'closing'); }, 280);
}

/* =========================================================================================
   LA SCREMATURA — l'esercizio dell'UNICA cosa (Gary Keller, "The One Thing")
   ========================================================================================= */

/* La domanda del libro, per esteso. È lei a fare il lavoro: non chiede cosa è urgente, chiede
   cosa rende il resto più facile o inutile. */
const ST_Q = 'Qual è l\'UNICA cosa che posso fare, tale che facendola tutto il resto diventerà più facile o addirittura inutile?';
const ST_ONE_KEY = 'fl_one';
const ST_ONE_HIST = 'fl_one_hist';

function stOne(){ try{ return JSON.parse(localStorage.getItem(ST_ONE_KEY) || 'null'); }catch(_){ return null; } }
function stOneSave(v){ try{ v ? localStorage.setItem(ST_ONE_KEY, JSON.stringify(v)) : localStorage.removeItem(ST_ONE_KEY); }catch(_){ } }
function stOneHist(){ try{ return JSON.parse(localStorage.getItem(ST_ONE_HIST) || '[]') || []; }catch(_){ return []; } }

/* Lo stato dell'esercizio vive in memoria: una lista buttata giù a metà non è una cosa da
   ricordare il giorno dopo, è una cosa da rifare. */
const OT = { step: 0, items: [], keep: [], when: 'today' };

registerScreen('s-onething', '<div class="ot-wrap" id="otBody"></div>', { back: 's-home' });

function stExerciseOpen(){
  OT.step = 0; OT.items = []; OT.keep = [];
  /* Dopo le 18 la domanda naturale non è più "cosa faccio oggi": è "cosa faccio domani".
     Resta cambiabile con un tocco nell'ultimo passo. */
  OT.when = new Date().getHours() >= 18 ? 'tomorrow' : 'today';
  goId('s-onething');
  otPaint();
}

/* Quante ne restano dopo il taglio: il 20% di Pareto, mai più di tre — tre è già il limite
   oltre il quale "priorità" torna a essere un plurale, che è il punto del libro — e mai meno
   di due, perché l'ultimo passo è una domanda, e una domanda con una risposta sola non è una
   domanda: è un modulo da firmare. */
function otCut(n){ return Math.min(3, Math.max(2, Math.round(n * 0.2))); }

function otPaint(){
  const host = document.getElementById('otBody');
  if (!host) return;
  const back = '<button type="button" class="ot-back" onclick="' + (OT.step ? 'otStep(' + (OT.step - 1) + ')' : 'goId(\'s-home\')') + '" aria-label="Indietro">'
    + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
  const dots = '<div class="ot-dots">' + [0, 1, 2, 3].map(function(i){ return '<i class="' + (i <= OT.step ? 'on' : '') + '"></i>'; }).join('') + '</div>';

  let body = '';
  if (OT.step === 0){
    body = '<div class="ot-ic">🎯</div>'
      + '<h2 class="ot-h">L\'esercizio dell\'UNICA cosa</h2>'
      + '<p class="ot-p">L\'ottanta per cento del risultato arriva dal venti per cento di quello che fai. Il problema è che quel venti per cento non si riconosce a occhio: si trova togliendo.</p>'
      + '<p class="ot-p">Tre passi. Scrivi tutto, tieni solo quello che pesa, e alla fine resta una cosa sola.</p>'
      + '<blockquote class="ot-q">«' + esc(ST_Q) + '»<i>~ Gary Keller, The One Thing</i></blockquote>'
      + '<button type="button" class="cta ot-go" onclick="otStep(1)">Comincia</button>';
  } else if (OT.step === 1){
    body = '<div class="ot-ic">📝</div>'
      + '<h2 class="ot-h">Scrivi tutto</h2>'
      + '<p class="ot-p">Tutto quello che ti sembra da fare, nell\'ordine in cui ti viene. Senza giudicare: serve la lista lunga, è da lì che si taglia.</p>'
      + '<div class="ot-list" id="otList">' + (OT.items.length ? OT.items.map(function(t, i){
          return '<div class="ot-item"><span>' + esc(t) + '</span><button type="button" onclick="otDel(' + i + ')" aria-label="Togli">✕</button></div>';
        }).join('') : '') + '</div>'
      + '<div class="ot-add"><input id="otIn" placeholder="es. finire la proposta per il cliente" maxlength="90" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();otAdd();}"><button type="button" onclick="otAdd()">＋</button></div>'
      + '<p class="ot-note">' + (OT.items.length < 3 ? 'Scrivine almeno tre.' : OT.items.length + ' cose. Quando hai finito, si taglia.') + '</p>'
      + '<button type="button" class="cta ot-go"' + (OT.items.length < 3 ? ' disabled' : '') + ' onclick="otStep(2)">Ho finito</button>';
  } else if (OT.step === 2){
    const k = otCut(OT.items.length);
    body = '<div class="ot-ic">✂️</div>'
      + '<h2 class="ot-h">Taglia</h2>'
      + '<p class="ot-p">Di queste ' + OT.items.length + ', solo poche producono quasi tutto il risultato. Tieni le <strong>' + k + '</strong> che peserebbero di più se le facessi.</p>'
      + '<div class="ot-list">' + OT.items.map(function(t, i){
          const on = OT.keep.indexOf(i) >= 0;
          return '<button type="button" class="ot-pick' + (on ? ' on' : '') + '" onclick="otKeep(' + i + ')"><i></i><span>' + esc(t) + '</span></button>';
        }).join('') + '</div>'
      + '<p class="ot-note">' + OT.keep.length + ' di ' + k + ' scelte</p>'
      + '<button type="button" class="cta ot-go"' + (OT.keep.length === k ? '' : ' disabled') + ' onclick="otStep(3)">Avanti</button>';
  } else {
    body = '<div class="ot-ic">🔮</div>'
      + '<h2 class="ot-h">Una sola</h2>'
      + '<blockquote class="ot-q ot-q--big">«' + esc(ST_Q) + '»</blockquote>'
      + '<div class="ot-when"><button type="button" class="' + (OT.when === 'today' ? 'on' : '') + '" onclick="otWhen(\'today\')">Per oggi</button>'
      +   '<button type="button" class="' + (OT.when === 'tomorrow' ? 'on' : '') + '" onclick="otWhen(\'tomorrow\')">Per domani</button></div>'
      + '<div class="ot-list">' + OT.keep.map(function(i){
          return '<button type="button" class="ot-pick ot-final" onclick="otChoose(' + i + ')"><span>' + esc(OT.items[i]) + '</span></button>';
        }).join('') + '</div>'
      + '<p class="ot-note">Le altre non spariscono: aspettano il loro turno, dopo questa.</p>';
  }
  host.innerHTML = '<div class="ot-top">' + back + dots + '<span></span></div>' + body;
  if (OT.step === 1){ const i = document.getElementById('otIn'); if (i) setTimeout(function(){ i.focus(); }, 150); }
}
function otStep(n){ OT.step = n; if (n < 2) OT.keep = []; otPaint(); }
function otWhen(w){ OT.when = w; otPaint(); }
function otAdd(){
  const inp = document.getElementById('otIn');
  const v = inp ? inp.value.trim() : '';
  if (!v) return;
  OT.items.push(v);
  if (inp) inp.value = '';
  otPaint();
}
function otDel(i){ OT.items.splice(i, 1); OT.keep = []; otPaint(); }
function otKeep(i){
  const k = otCut(OT.items.length);
  const at = OT.keep.indexOf(i);
  if (at >= 0) OT.keep.splice(at, 1);
  else { if (OT.keep.length >= k) OT.keep.shift(); OT.keep.push(i); }
  otPaint();
}
function otChoose(i){
  const forDay = mtKey(Date.now() + (OT.when === 'tomorrow' ? 86400000 : 0));
  stOneSave({ task: OT.items[i], at: Date.now(), forDay: forDay, done: false,
              rest: OT.keep.filter(function(x){ return x !== i; }).map(function(x){ return OT.items[x]; }) });
  /* La riga vale per `forDay`, ma il registro della serie segna il giorno in cui la scelta
     e' stata fatta: e' quello che l'arbitro controlla quando chiude la giornata. */
  mtPlanMark(mtKey(Date.now()));
  goId('s-home');
  switchTab('sveglia');
  setTimeout(function(){
    stPaint();
    const el = document.getElementById('stPark');
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    toast(OT.when === 'tomorrow' ? 'Domani hai già una cosa sola da fare' : 'La tua unica cosa di oggi è scelta');
  }, 220);
}

/* La sessione intensiva portata a termine è la prova che la priorità è stata fatta.
   Chiamata da ffFinish(). */
function stOneComplete(prova){
  /* IL PUNTO, FINALMENTE.
     Per settimane questa funzione archiviava la riga e basta: mtFocusPoint esisteva e non lo
     chiamava nessuno, quindi il tabellone restava 0 a 0 qualunque cosa uno facesse. L'arbitro
     adesso c'e' davvero, e decide secondo le regole scelte in Impostazioni → La partita: al
     livello normale e severo vuole una sessione di concentrazione a dimostrarlo, al livello
     morbido si fida della spunta. */
  stListPaint();
  const one = stOne();
  if (!one || one.done) return;

  if (typeof mgFocusPoint === 'function'){
    const conProva = (prova === true) || (typeof mgProofToday === 'function' && mgProofToday());
    if (!mgFocusPoint('unica cosa: ' + ((one.task && (one.task.text || one.task)) || ''), conProva)) return;
  }
  const h = stOneHist();
  h.push({ task: one.task, at: one.at, doneAt: Date.now() });
  try{ localStorage.setItem(ST_ONE_HIST, JSON.stringify(h.slice(-200))); }catch(_){ }
  stOneSave(null);
  stPaint();
  setTimeout(function(){ toast('Fatta. Oggi la tua unica cosa è archiviata'); }, 1200);
}
/* La spunta a mano: stessa strada, senza aspettare la sessione. */
function stOneTick(){
  if (!stOne()) return;
  stOneComplete(false);
}

/* =========================================================================================
   UNA COSA ALLA VOLTA — la legge di Parkinson, e la porta di FullFocus
   ========================================================================================= */
/* ---- DA SOLO | IN GRUPPO (0.9.206): chi non trova la spinta da solo la trova guardando qualcuno
   che fa la stessa cosa. A destra: un focus partner, una lega, gli amici. ---- */
function stModo(){ try{ return localStorage.getItem('fl_start_modo') === 'gruppo' ? 'gruppo' : 'solo'; }catch(_){ return 'solo'; } }
function stModoSet(m){ try{ localStorage.setItem('fl_start_modo', m); }catch(_){ } try{ flVibra(8); }catch(_){ } stPaint(); }
function stModoHtml(){
  const g = stModo() === 'gruppo';
  return '<div class="st-modo" role="tablist" data-cg-no><i class="st-modo-k' + (g ? ' dx' : '') + '"></i><button type="button" class="' + (g ? '' : 'on') + '" onclick="stModoSet(\'solo\')">🎯 Da solo</button><button type="button" class="' + (g ? 'on' : '') + '" onclick="stModoSet(\'gruppo\')">👥 In gruppo</button></div>';
}
function stGruppoHtml(){
  let amici = 0; try{ amici = ((typeof FR !== 'undefined' && FR.amici && FR.amici.amici) || []).length; }catch(_){ }
  let lega = ''; try{ lega = (typeof FR !== 'undefined' && FR.lega && FR.lega.nome) || ''; }catch(_){ }
  return '<section class="st-sec"><div class="sev-intro st-intro"><div class="sev-intro-ic">👥</div><p class="mt-eyebrow st-eyebrow">La forza dell’esempio</p>' + flTitolo('Lavori meglio se qualcuno lavora con te.', 'con te.') + '</div>'
    + '<div class="st-gr">'
    + '<button type="button" class="st-gr-row" onclick="if(typeof frOpen===\'function\')frOpen(\'amici\')"><span>⏳</span><div><b>Trova un focus partner</b><small>Una sessione a due, stesso orario. ' + (amici ? amici + (amici === 1 ? ' amico pronto' : ' amici pronti') : 'Aggiungi un amico e invitalo') + '.</small></div><span class="chev"></span></button>'
    + '<button type="button" class="st-gr-row" onclick="if(typeof frOpen===\'function\')frOpen(\'lega\')"><span>🏆</span><div><b>Entra in una lega</b><small>' + (lega ? 'Sei in ' + esc(lega) + ': la classifica la vedi da Amici.' : 'Un gruppo di pari che fa le tue stesse ore. La classifica la vedi da Amici.') + '</small></div><span class="chev"></span></button>'
    + '<button type="button" class="st-gr-row" onclick="if(typeof frAggiungiApri===\'function\')frAggiungiApri(\'start\')"><span>🤝</span><div><b>Fate squadra</b><small>Dai contatti, per nome, o con il tuo codice.</small></div><span class="chev"></span></button>'
    + '</div></section>';
}
function stPaint(){
  const host = document.getElementById('stFocus');
  const host2 = document.getElementById('stPark');
  if (!host || !host2) return;
  const one = stOne();
  const done = stOneHist().length;
  let mins = 25, week = 0;
  try{
    const p = JSON.parse(localStorage.getItem('fl_ff_pref') || 'null');
    if (p && p.minutes) mins = p.minutes;
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const since = Date.now() - 7 * 86400000;
    week = h.filter(function(x){ return x && x.ok && x.at >= since; }).length;
  }catch(_){ }
  const forTomorrow = one && one.forDay && one.forDay > mtKey(Date.now());

  /* 1. il foglio bianco, e dietro di lui la scrematura */
  const dayTab = function(w, label){
    return '<button type="button" class="st-daytab' + (STN.day === w ? ' on' : '') + '" onclick="stDaySet(\'' + w + '\')">' + label + '</button>';
  };
  const tab = function(k, label){
    return '<button type="button" class="st-daytab' + (STN.tab === k ? ' on' : '') + '" data-k="' + k + '" onclick="stTabSet(\'' + k + '\')">' + label + '</button>';
  };
  /* Tre schede: la mappa dei passi di oggi (dalla Roadmap), la priorita' di oggi, le note.
     Niente «Domani»: il piano di domani si scrive dal foglio grande, e la scheda serviva solo
     a confondere. Niente «?» e niente «Scremale»: le righe le propone il Genio. */
  let corpo = '';
  /* Le Note non stanno piu' qui: sono l'ultima scheda del foglio grande. Al loro posto Domani,
     che si apre solo a priorita' fatta e a giornata finita (piano.js). */
  /* la Mappa ha le sue schede (mappa-foglio.js): Note e Calendario sono solo li' */
  const inMappa0 = !!(host.closest && host.closest('#mppFoglio'));
  if (!inMappa0 && (STN.tab === 'note' || STN.tab === 'cal')) STN.tab = 'oggi';
  if (STN.tab === 'mappa') corpo = stMappaHtml();
  else if (STN.tab === 'domani') corpo =
      '<div class="st-list st-oggi pn-domani">' + (typeof pnDomaniHtml === 'function' ? pnDomaniHtml() : '') + '</div>'
    + '<div class="st-dict st-solo" id="stDict">'
    +   '<button type="button" class="st-expand" onclick="stFullOpen()" aria-label="A tutto schermo">'
    +     '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H3v6M15 3h6v6M9 21H3v-6M15 21h6v-6"/></svg></button>'
    + '</div>';
  else if (STN.tab === 'note-vecchie') corpo =
      '<textarea id="stNotes" class="st-notearea" rows="1" oninput="stNotesInput()" onblur="stAppuntoCommit()" '
    +   'onkeydown="if(event.key===\'Enter\'&&!event.shiftKey){event.preventDefault();stAppuntoCommit();}" '
    +   'placeholder="Scrivi una cosa e premi invio\u2026"></textarea>'
    + '<div class="st-list" id="stAppunti"></div>'
    + '<p class="st-notehint" id="stNoteHint"></p>'
    + '<div class="st-dict" id="stDict">'
    +   '<button type="button" class="st-expand" onclick="stFullOpen()" aria-label="A tutto schermo">'
    +     '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H3v6M15 3h6v6M9 21H3v-6M15 21h6v-6"/></svg></button>'
    +   '<button type="button" class="st-mic" onmousedown="event.preventDefault()" onclick="stDictStart()" aria-label="Detta a voce">'
    +     '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>'
    +   '<div class="st-pill">'
    +     '<button type="button" class="st-pillbtn" onclick="stDictCancel()" aria-label="Annulla">\u2715</button>'
    +     '<div class="st-wave">' + Array.from({ length: 11 }).map(function(){ return '<i></i>'; }).join('') + '</div>'
    +     '<button type="button" class="st-pillbtn ok" onclick="stDictOk()" aria-label="Conferma">\u2713</button>'
    +   '</div>'
    + '</div>';
  else corpo =
      '<div class="st-list st-oggi" id="stList"></div>'
    + '<p class="st-notefoot" id="stNoteFoot"></p>'
    + '<p class="st-notehint" id="stNoteHint"></p>'
    + '<p class="st-synctxt" id="stSyncTxt"></p>'
    + '<div class="st-dict st-solo" id="stDict">'
    +   '<button type="button" class="st-expand" onclick="stFullOpen()" aria-label="A tutto schermo">'
    +     '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H3v6M15 3h6v6M9 21H3v-6M15 21h6v-6"/></svg></button>'
    + '</div>';
  const paneNotes =
      '<div class="st-note">'
    +   '<div class="st-notehead" onclick="STN.tutto=true;this.parentElement.classList.add(\'st-tutto\')"><div class="st-days">' + tab('mappa', 'Mappa') + tab('oggi', 'Oggi') + stTabMappa('domani', 'Domani') + stTabMappa('cal', 'Calendario') + '</div></div>'
    +   corpo
    + '</div>';

  const paneEx =
      '<div class="life-wrap"><div class="life">'
    +   (one
        ? '<b class="life-t">' + (forTomorrow ? 'La tua unica cosa di domani' : 'La tua unica cosa di oggi') + '</b>'
          + '<label class="st-task' + (one.done ? ' done' : '') + '"><input type="checkbox" onchange="stOneTick()"' + (one.done ? ' checked' : '') + '><span>' + esc(one.task) + '</span></label>'
          + '<p class="life-p">Si spunta da sola quando porti a termine una sessione di concentrazione intensiva. Fino ad allora è l\'unica cosa che conta.</p>'
          + '<button class="life-edit st-again" onclick="stExerciseOpen()">Rifai la scrematura</button>'
        : '<b class="life-t">L\'esercizio della scrematura</b>'
          + '<div class="life-big">20<span>%</span></div>'
          + '<p class="life-p">Il venti per cento di quello che fai produce quasi tutto il risultato. Scrivi tutto quello che ti sembra da fare, taglia, e resta con una cosa sola.'
          + (done ? ' Ne hai già chiuse <strong>' + done + '</strong>.' : '') + '</p>'
          + '<button class="life-go" onclick="stExerciseOpen()">Fai l\'esercizio</button>')
    + '</div></div>'
    + '<div class="st-carnav">'
    +   '<button type="button" class="st-toex" onclick="stCarVai(\'foglio\')">\u2039 Il foglio</button>'
    +   '<button type="button" class="st-toex" onclick="stCarVai(\'sveglie\')">Le sveglie \u203a</button>'
    + '</div>';

  /* 3. le sveglie. Qui c'e' la porta, non l'elenco: l'elenco ha una pagina sua. */
  const al = stAlarmsInfo();
  const paneAl =
      '<div class="life-wrap"><div class="life st-portal">'
    +   '<div class="st-portal-ic">\u23f0</div>'
    +   '<b class="life-t">Le tue sveglie</b>'
    +   '<div class="life-big">' + al.on + '<span>' + (al.on === 1 ? 'attiva' : 'attive') + '</span></div>'
    +   '<p class="life-p">' + (al.next
          ? 'La prossima suona alle <strong>' + al.next + '</strong>. La mattina comincia la sera prima: decidi adesso a che ora ti alzi.'
          : 'Nessuna sveglia impostata. La mattina comincia la sera prima: decidi adesso a che ora ti alzi.') + '</p>'
    +   '<button class="life-go" onclick="alPageOpen()">Apri le sveglie</button>'
    + '</div></div>'
    + '<div class="st-carnav">'
    +   '<button type="button" class="st-toex" onclick="stCarVai(\'scrematura\')">\u2039 Indietro</button>'
    +   '<button type="button" class="st-toex" onclick="stCarVai(\'promemoria\')">Promemoria \u203a</button>'
    + '</div>';

  /* 4. il promemoria: l'ora in cui l'app ti ricorda di scrivere, e l'ora entro cui deve esserci. */
  const pn = pnRead();
  const panePn =
      '<div class="life-wrap"><div class="life st-portal">'
    +   '<div class="st-portal-ic">\ud83d\udd14</div>'
    +   '<b class="life-t">Ricordamelo</b>'
    +   '<p class="life-p">Se all\'ora che scegli non hai ancora scritto niente, DreamMap te lo ricorda. E poco prima del limite te lo dice un\'ultima volta.</p>'
    +   '<label class="pn-row"><span>Promemoria</span>'
    +     '<input type="checkbox"' + (pn.on ? ' checked' : '') + ' onchange="pnSet(\'on\', this.checked)"></label>'
    +   '<label class="pn-row' + (pn.on ? '' : ' off') + '"><span>Me lo ricordi alle</span>'
    +     '<input type="time" value="' + pn.at + '"' + (pn.on ? '' : ' disabled') + ' onchange="pnSet(\'at\', this.value)"></label>'
    +   '<label class="pn-row' + (pn.on ? '' : ' off') + '"><span>Scritto entro le</span>'
    +     '<input type="time" value="' + pn.by + '"' + (pn.on ? '' : ' disabled') + ' onchange="pnSet(\'by\', this.value)"></label>'
    +   '<p class="life-p pn-note">Dopo quell\'ora senza piano parte una protezione dello slancio. Finite quelle, lo slancio riparte da zero.</p>'
    /* L'avviso delle notifiche sta QUI, dove il promemoria si accende: e' il momento in cui
       serve saperlo, ed e' l'unico in cui una richiesta di permesso si capisce. */
    +   '<div id="ntWarnPn"></div>'
    + '</div></div>'
    + '<div class="st-carnav">'
    +   '<button type="button" class="st-toex" onclick="stCarVai(\'sveglie\')">\u2039 Indietro</button>'
    + '</div>';

  const block1 =
      '<section class="st-sec">'
    +   '<div class="sev-intro st-intro"><div class="sev-intro-ic">\ud83c\udfaf</div>'
    +     '<p class="mt-eyebrow st-eyebrow">Fai come Napoleone:</p>' + flTitolo('vedi solo l\u2019obiettivo.', 'solo l\u2019obiettivo.') + '<p class="st-ostacolo">L\u2019ostacolo dovrà spostarsi.</p></div>'
    /* La frase non sta più sotto al titolo: è la SECONDA diapositiva, di fianco al foglio. */
    +   '<div class="st-car" id="stCar">'
    +     '<div class="st-pane on">' + paneNotes + '</div>'
    +     '<div class="st-pane">' + citSlide('scelta') + '</div>'
    +     '<div class="st-pane">' + paneEx + '</div>'
    +     '<div class="st-pane">' + paneAl + '</div>'
    +     '<div class="st-pane">' + panePn + '</div>'
    +   '</div>'
    +   '<div class="st-cardots" id="stCarDots"><i class="on"></i><i></i><i></i><i></i><i></i></div>'
    + '</section>';

  /* 2. una cosa alla volta */
  const block2 =
      '<section class="st-sec">'
    +   '<div class="sev-intro st-intro"><div class="sev-intro-ic">🚀</div>'
    +     flTitoloDelGiorno('spinta') + '</div>'
    /* Tre diapositive di UN carosello: l'oblo' con la porta di FullFocus, la frase che si
       guadagna, e la carta di Parkinson (il confine al tempo). Stavano una sotto l'altra come
       due pannelli separati: e' un carosello, e la terza sta di fianco alle altre due. */
    +   '<div class="st-car" id="stCar2">'
    +     '<div class="st-pane on">' + stObloCard() + '</div>'
    +     '<div class="st-pane">' + citSlide('profondo') + '</div>'
    +     '<div class="st-pane"><div class="life-wrap"><div class="life">'
    +       '<b class="life-t">Concentrazione totale</b>'
    +       '<div class="life-big">' + mins + '<span>min</span></div>'
    +       '<p class="life-p">'
    +         (one && !forTomorrow
                ? 'Dai un confine a <strong>' + esc(one.task) + '</strong>: blocca tutto il resto e non toccare il telefono finché il tempo non finisce.'
                : 'Il lavoro si allarga fino a riempire il tempo che gli lasci. Dagli un confine: una cosa sola, tutto il resto bloccato.')
    +         (week ? ' Questa settimana ce l\'hai fatta <strong>' + week + (week === 1 ? ' volta' : ' volte') + '</strong>.' : '')
    +       '</p>'
    +       '<button class="life-go" onclick="stGoFocus()">Entra in Full Focus</button>'
    +       (done || week ? '<div class="life-links"><button class="life-edit" onclick="stGoForest()">Il tuo cielo</button></div>' : '')
    +     '</div></div></div>'
    +   '</div>'
    +   '<div class="st-cardots" id="stCar2Dots"><i class="on"></i><i></i><i></i></div>'
    + '</section>';

  /* nella Mappa il foglio e' sempre il foglio: l'interruttore Da solo | In gruppo e' solo di START */
  const inMappa = !!(host.closest && host.closest('#mppFoglio'));
  /* NELLA MAPPA (0.9.210): il titolo del giorno della pianificazione (non Napoleone), niente
     «L'ostacolo dovrà spostarsi», e le schede e le cose fatte restano sempre: l'animazione
     che le porta via e' solo di START, dove conta solo adesso. */
  /* 0.9.211, come Dream Life Mindmap: sotto al titolo del giorno la domanda della scheda, le
     schede sono solo Oggi e Domani, e i tre puntini aprono le impostazioni del foglio (l'ADHD Mode) */
  if (inMappa && STN.tab === 'mappa') STN.tab = 'oggi';
  const sottoMappa = '<p class="st-domanda">' + (STN.tab === 'domani' ? '“Qual è il tuo piano per domani?”' : '“Qual è il tuo piano per la prossima ora?”') + '</p>';
  const block1Mappa = block1.replace(/<p class="mt-eyebrow st-eyebrow">[\s\S]*?<p class="st-ostacolo">[\s\S]*?<\/p>/, flTitoloDelGiorno('focus') + sottoMappa)
    .replace('<div class="st-note">', '<div class="st-note"><button type="button" class="st-dots" onclick="event.stopPropagation();if(typeof ulImpApri===\'function\')ulImpApri()" aria-label="Impostazioni del foglio">⋯</button>');
  host.innerHTML = inMappa ? (typeof mfHtml === 'function' ? mfHtml(flTitoloDelGiorno('focus')) : block1Mappa) : (stModoHtml() + (stModo() === 'gruppo' ? stGruppoHtml() : block1));
  host.classList.toggle('st-in-mappa', inMappa);
  if (STN.tutto || inMappa){ const n0 = host.querySelector('.st-note'); if (n0) n0.classList.add('st-tutto'); }
  host2.innerHTML = block2;
  stCarSwipe();
  try{ if (typeof citOsserva === 'function') citOsserva(); }catch(_){ }
  /* Il testo si rimette DOPO il disegno: scriverlo nell'HTML significherebbe sfuggirlo, e un
     foglio di appunti in cui le virgolette diventano entita' non e' un foglio di appunti. */
  /* Il campo in cima resta VUOTO: e' una riga da aggiungere, non il foglio. Quello che e'
     gia' scritto sta nell'elenco qui sotto, una volta sola. */
  const box = document.getElementById('stNotes');
  if (box){ box.value = ''; stNoteGrow(box); }
  stNoteFoot();
  stListPaint();
  stAppuntiPaint();
  stDictPaint();
  if (inMappa && typeof mfDopo === 'function') mfDopo();
}
/* ---------- LA CARTA DELL'OBLÒ ----------
   La porta di FullFocus, con dentro la cosa che quella porta promette: il finestrino, e fuori
   l'ora che c'è davvero. In cima i pallini delle sessioni di oggi — pieni quelli fatti, vuoti
   quelli che mancano — perché una fila di pallini si legge in un colpo d'occhio, mentre «2 su
   3» si legge e basta. L'obiettivo del giorno viene dalla modalità scelta: un passo, tre o
   cinque. */
function stSessioniOggi(){
  try{
    const alba = new Date(); alba.setHours(0, 0, 0, 0);
    return (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [])
      .filter(function(x){ return x && x.ok && x.at >= alba.getTime(); }).length;
  }catch(_){ return 0; }
}
function stObiettivoOggi(){
  /* la stessa modalita' che decide il punto: facile un passo, normale tre, difficile cinque */
  let m = 'normale';
  try{ m = (typeof fsModalita === 'function') ? fsModalita() : (localStorage.getItem('fl_modalita') || 'normale'); }catch(_){ }
  return { facile: 1, normale: 3, difficile: 5 }[m] || 3;
}
/* ---------- LA CHIAMATA DEI SOGNI ----------
   Sopra al finestrino, la prima volta che si apre la scheda in una giornata ancora vuota:
   «I tuoi sogni ti stanno chiamando», e due tasti come su una telefonata vera. Rispondere
   apre FullFocus. Rifiutare non fa niente di male subito — segna solo il motivo, e a
   mezzanotte l'arbitro lo scrive accanto al punto del vecchio te.

   0.9.354, Andrea: resta anche dopo la prima sessione (prima compariva solo a giornata
   vuota). Se ne va solo quando oggi l'hai rifiutata: allora il punto e' gia' sul tabellone. */
const DCO_KEY = 'fl_chiamata';
function dcoStato(){
  try{ return JSON.parse(localStorage.getItem(DCO_KEY) || '{}') || {}; }catch(_){ return {}; }
}
function dcoSalva(o){ try{ localStorage.setItem(DCO_KEY, JSON.stringify(o)); }catch(_){ } }
/** Il motivo scelto oggi: 'scelto' | 'potuto' | '' (non ha ancora risposto). */
function dcoOggi(){ const st = dcoStato(); return st[stDayKey()] || ''; }

/* La lingua dell'app: la scelta dell'utente, se l'ha fatta, altrimenti sempre italiano, come il
   resto dell'app (Impostazioni dice "Lingua: come il sistema (oggi italiano)"). Finche' l'italiano
   e' l'unica lingua vera, questa frase non deve mai leggere la lingua del telefono. */
function dcoLingua(){
  let v = 'system';
  try{ v = localStorage.getItem('fl_lang') || 'system'; }catch(_){ }
  if (v !== 'system') return v.slice(0, 2).toLowerCase();
  return 'it';
}
const DCO_T = {
  it: { t: 'I TUOI SOGNI', s: 'ti stanno chiamando', si: 'Rispondi', no: 'Rifiuta',
        perche: 'Perché no, oggi?', potuto: 'Oggi non posso', arreso: 'Mi arrendo, cambio strada',
        fatto: 'Punto al vecchio te. Domani squilla di nuovo.' },
  en: { t: 'YOUR DREAMS', s: 'are calling you', si: 'Accept', no: 'Decline',
        perche: 'Why not, today?', potuto: 'Not today', arreso: 'I give up, new path',
        fatto: 'Point to the old you. It rings again tomorrow.' }
};
function dcoTxt(){ return DCO_T[dcoLingua()] || DCO_T.it; }

function dcoOverlayHtml(){
  const T = dcoTxt();
  /* Rifiutata: l'oblo' torna pulito. Il punto e' gia' sul tabellone, e una riga che lo
     ripete sopra al finestrino per tutto il giorno e' una lapide. */
  if (dcoOggi()) return '';
  return '<div class="dco" id="dcoBox">'
    + '<div class="dco-testa"><b>' + T.t + '</b><span>' + T.s + '</span></div>'
    + '<div class="dco-tasti">'
    +   '<button type="button" class="dco-si" onclick="dcoRispondi()"><i>\ud83d\udcde</i><small>' + T.si + '</small></button>'
    +   '<button type="button" class="dco-no" onclick="dcoRifiuta()"><i>\ud83d\udcde</i><small>' + T.no + '</small></button>'
    + '</div></div>';
}
function dcoRispondi(){
  try{ if (typeof flVibra === 'function') flVibra(20); }catch(_){ }
  stGoFocus();
}
function dcoRifiuta(){
  const T = dcoTxt();
  const box = document.getElementById('dcoBox');
  if (!box) return;
  /* Due rifiuti diversi: «oggi non posso» e' un giorno storto, «mi arrendo» e' un'altra
     destinazione. Il primo costa un punto adesso; il secondo chiude la partita. */
  box.innerHTML = '<div class="dco-testa"><b>' + T.perche + '</b></div>'
    + '<div class="dco-motivi">'
    +   '<button type="button" onclick="dcoMotivo(\'potuto\')">' + T.potuto + '</button>'
    +   '<button type="button" class="arreso" onclick="dcoMotivo(\'arreso\')">' + T.arreso + '</button>'
    + '</div>';
}
function dcoMotivo(k){
  if (k === 'arreso'){
    if (typeof goApri === 'function') goApri();
    return;
  }
  const st = dcoStato();
  st[stDayKey()] = k;
  dcoSalva(st);
  /* Il punto va SUBITO al vecchio te, non a mezzanotte: chi ha detto «oggi no» lo ha
     deciso adesso, e il tabellone lo segna adesso. A mezzanotte non si ripete. */
  try{ if (typeof mgOldPoint === 'function') mgOldPoint('hai rifiutato la chiamata: oggi non potevi'); }catch(_){ }
  stPaint();
}

function stObloCard(){
  const fatte = stSessioniOggi();
  const meta = Math.max(stObiettivoOggi(), fatte);
  const src = (typeof obloSrc === 'function') ? obloSrc() : 'img/oblo/giorno.jpg';
  let pallini = '';
  for (let i = 0; i < meta; i++) pallini += '<i class="' + (i < fatte ? 'on' : '') + '"></i>';
  /* La stessa carta navy con il glow del pannello «Concentrazione totale»: in modalita'
     chiara una carta chiara non dava nessun contrasto al pulsante che e' il motivo della
     carta. */
  return '<div class="life-wrap"><div class="life oblo">'
    + '<b class="life-t">Sessioni di oggi · ' + fatte + ' / ' + meta + '</b>'
    + '<div class="oblo-dots">' + pallini + '</div>'
    + '<div class="oblo-img">'
    +   '<img src="' + src + '" alt="" loading="lazy">'
    /* La scritta sta SOPRA all'immagine, non dentro: e' testo dell'app, quindi segue la
       lingua e si legge anche a schermo piccolo. Dentro all'immagine sarebbe un pixel. */
    /* 0.9.354, Andrea: "dopo la prima sessione spariscono I tuoi sogni ti stanno chiamando, Rispondi e Rifiuta: devono restare".
       Prima comparivano solo a giornata vuota; adesso restano, e se ne vanno solo quando oggi hai rifiutato (dcoOggi) */
    +   dcoOverlayHtml()
    + '</div>'
    + '<button class="life-go oblo-go" onclick="stGoFocus()">Entra in Full Focus</button>'
    + '</div></div>';
}

/* Quante sveglie sono accese e a che ora suona la prossima: il portale deve dire qualcosa di
   vero, altrimenti e' solo un pulsante con un'icona. */
function stAlarmsInfo(){
  let list = [];
  try{ if (typeof AL !== 'undefined' && AL && AL.list) list = AL.list; }catch(_){ }
  const on = list.filter(function(a){ return a && a.on; });
  if (!on.length) return { on: 0, next: '' };
  const now = new Date();
  const cur = now.getHours() * 60 + now.getMinutes();
  let best = null, bestD = 1e9;
  on.forEach(function(a){
    const m = a.hour * 60 + a.minute;
    const d = m > cur ? m - cur : m + 1440 - cur;
    if (d < bestD){ bestD = d; best = a; }
  });
  const f = (typeof alFmt === 'function' && best) ? alFmt(best.hour, best.minute) : null;
  return { on: on.length, next: f ? (f.t + (f.ap ? ' ' + f.ap : '')) : '' };
}

function stGoFocus(){ if (typeof ffOpen === 'function') ffOpen(); }
function stGoForest(){ if (typeof ffOpen === 'function'){ ffOpen(); setTimeout(function(){ if (typeof ffForestOpen === 'function') ffForestOpen(); }, 260); } }

/* a mezzanotte la frase e il titolo del giorno cambiano anche con l'app lasciata aperta (citazioni.js) */
document.addEventListener('fl:giorno', function(){ try{ if (typeof stPaint === 'function') stPaint(); }catch(_){ } });
document.addEventListener('fl:tab', function(e){
  if (e.detail !== 'sveglia') return;
  /* in START c'e' solo Oggi (0.9.207): Mappa e Domani vivono nella scheda Mappa */
  STN.tab = 'oggi'; STN.day = 'today';
  stHeroEnsure();
  stMidEnsure();
  MT_VISTO_MEM = '';
  mtPaint();
  stPaint();
  spPaint();
  setTimeout(stVideoSync, 120);
});
/* IL VIDEO SI FERMAVA E NON RIPARTIVA PIU'.
   Questa riga ascoltava la diapositiva 'start' — il cielo con i due tabelloni — ma il video
   non vive li': sta nell'intermezzo, che si chiama 'startmid'. Quindi quando la diapositiva
   del video andava via nessuno metteva in pausa, e quando tornava nessuno faceva ripartire:
   restava l'ultimo fotogramma, fermo per sempre. */
document.addEventListener('fl:slide', function(e){
  if (e.detail && (e.detail.key === 'startmid' || e.detail.key === 'start')) stVideoSync();
  if (e.detail && e.detail.key === 'start' && e.detail.i === 0) mtRientra();
});
/* E LA GUARDIA. Su questa WebView capita che play() vada a buon fine e i fotogrammi non
   avanzino lo stesso — succede dopo una lunga pausa in secondo piano, quando il decoder e'
   stato riciclato. Un video che dovrebbe andare e ha lo stesso istante di due secondi fa non
   e' in pausa: e' morto, e l'unico modo di svegliarlo e' ricaricarlo. */
let ST_VID_T = 0, ST_VID_LAST = -1;
setInterval(function(){
  const v = document.getElementById('stVid');
  if (!v || document.hidden) return;
  const tabOn = (document.querySelector('.tabpage.on') || {}).id === 'tab-sveglia';
  const slide = (typeof FL_HEROES !== 'undefined' && FL_HEROES.startmid) ? FL_HEROES.startmid.slide : 0;
  if (!tabOn || slide !== 0){ ST_VID_LAST = -1; return; }
  if (v.paused){ try{ v.play().catch(function(){}); }catch(_){ } ST_VID_LAST = -1; return; }
  const ora = v.currentTime;
  if (ST_VID_LAST >= 0 && Math.abs(ora - ST_VID_LAST) < 0.02 && ++ST_VID_T >= 2){
    ST_VID_T = 0;
    try{ v.load(); v.play().catch(function(){}); }catch(_){ }
  } else if (Math.abs(ora - ST_VID_LAST) >= 0.02){ ST_VID_T = 0; }
  ST_VID_LAST = ora;
}, 2000);
document.addEventListener('visibilitychange', stVideoSync);

(function(){
  const css = [
    /* Il video sta dentro a un contenitore, e non e' un vezzo.
       Un <video> e' un elemento sostituito: con height:auto prende la propria altezza naturale
       e `bottom` viene ignorato, quindi i soli inset non lo allungano; e height:100% contro un
       genitore di altezza automatica ricade anch'esso sul naturale. Il <div> invece si stende
       davvero sugli inset, e a quel punto il 100% del video ha un'altezza vera contro cui
       misurarsi. */
    '.st-vidwrap{position:absolute;top:0;right:0;bottom:0;left:0;overflow:hidden;z-index:0}',
    '.st-vid{width:100%;height:100%;object-fit:cover;display:block}',
    /* Il velo sopra al video e' quasi niente: un video coperto da un velo scuro non e' piu' un
       video, e questa diapositiva esiste per farlo vedere. Il poco che c'e' sta in basso, dove
       servono i due centimetri di contrasto per reggere il titolo bianco. */
    '.st-ov{background:linear-gradient(180deg,rgba(2,9,38,0) 0%,rgba(2,9,38,.08) 42%,rgba(2,9,38,.42) 100%)}',
    '#stHero .bh-eyebrow,#stHero .bh-title{text-shadow:0 2px 18px rgba(0,0,0,.75),0 0 3px rgba(0,0,0,.45)}',
    /* In "bh--tall" le diapositive sono in flusso: quella nascosta occupava comunque il suo
       spazio, e sotto al video restava una fascia vuota alta quanto la seconda. Fuori flusso
       tutte tranne quella davanti. */
    '#stHero .bh-slide{min-height:52vh}',
    '#stHero .bh-slide:not(.on){position:absolute;top:0;right:0;bottom:0;left:0;min-height:0}',
    '#stHero .bh-text{min-height:52vh}',

    /* il tabellone */
    /* IL TABELLONE STA AL CENTRO DELLA SUA SLIDE.
       Con un'imbottitura fissa in cima, il titolo finiva incollato all'intestazione e il
       tabellone galleggiava nella meta' alta: la slide e' un quadro, e il soggetto di un
       quadro sta al centro. */
    '#stMatchBox{display:flex;flex-direction:column;justify-content:center;min-height:100%;'
      + 'padding:calc(30px + var(--hdr-h,0px)) 18px 96px;text-align:center}',
    '.mt-more{position:absolute;top:calc(14px + var(--hdr-h,0px));right:14px;z-index:2;width:34px;height:34px;'
      + 'border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font:700 18px/1 var(--font-body);cursor:pointer}',
    '.mt-rules{margin:22px auto 0;border:0;background:transparent;color:rgba(255,255,255,.78);'
      + 'font:600 12.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    /* AL CENTRO, come i numeri che stanno sotto. Erano a bandiera sinistra mentre il
       tabellone sotto era centrato: due allineamenti diversi nella stessa diapositiva fanno
       sembrare storto il pezzo piu' piccolo, che qui e' il titolo. */
    '.mt-eyebrow{margin:0;text-align:center;font:700 10.5px var(--font-body);letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.82)}',
    '.mt-title{margin:10px 0 0;text-align:center;font:800 24px/1.16 var(--font-display);font-style:italic;text-transform:uppercase;color:#fff;text-shadow:0 2px 14px rgba(0,0,0,.45)}',
    '.mt-board{align-items:center;padding-top:26px}',
    /* punteggio gia' visto: niente entrata, niente zoom della foto */
    '#stMatchBox.mt-fermo .sev-rise{animation:none}',
    '#stHero.mt-fermo .bh-slide[data-i="0"] .bh-img{animation:none;transform:scale(1)}',
    /* Il trattino sta in mezzo ai due numeri, non in mezzo alle due colonne: le icone sono
       alte 46px e i numeri cominciano dopo, quindi scende di altrettanto. */
    '.mt-dash{align-self:flex-start;font:800 34px/1.1 var(--font-display);color:rgba(255,255,255,.55);padding-top:56px}',
    '.pf-stat .glow-red{filter:drop-shadow(0 0 14px rgba(255,110,130,.85)) drop-shadow(0 0 4px rgba(255,110,130,.85))}',
    '.pf-stat .num.red{color:#FF8A9B}.pf-stat .num.red + small{color:#FF8A9B}',
    '.mt-line{margin:26px 0 0;text-align:center;font:500 13px/1.6 var(--font-body);color:rgba(255,255,255,.86)}',
    '.mt-line b{color:#fff}',

    /* la protezione della serie */
    '#spHost{margin-top:36px;padding:0 18px}',
    '.sp-card2{background:linear-gradient(180deg,#C8EFFD 0%,#F0FBFF 100%)!important;border-color:#BCE0FF!important;gap:14px!important;padding:16px!important}.sp-card2 .sp-ico{font-size:30px}.sp-card2 .sp-row{display:flex;align-items:center;gap:8px;flex-wrap:nowrap}.sp-card2 .sp-row b{white-space:nowrap;font-size:16px;color:#001E44}.sp-card2 small{display:block;margin-top:4px;color:#33476A!important;line-height:1.35}.sp-card2 .sp-q{flex:none;width:24px!important;height:24px!important;margin:0!important}',
    'body.dark .sp-card2{background:linear-gradient(180deg,#1A3C6E,#12264C)!important;border-color:#2C4170!important}body.dark .sp-card2 .sp-row b{color:#fff}body.dark .sp-card2 small{color:#D6E8FF!important}',
    /* 0.9.353, Andrea: "Protezione dello slancio va a capo su tre righe, 1 giorno di fila in Full Focus va a capo, il riquadro delle
       protezioni ruba lo spazio". Tre righe pulite: il titolo con il ? (mai a capo, si stringe un poco solo sui telefoni stretti),
       la riga dei giorni, la pillola "Hai 2 protezioni". La freccia esce dalla riga del titolo: sta a destra, sulla riga della pillola.
       Con #spHost davanti, perche' serie.js rimette .sp-card .sp-row{display:block} e la pillola in colonna */
    '#spHost .sp-card2{position:relative;align-items:flex-start;gap:10px!important;padding:18px 16px!important}',
    '#spHost .sp-card2 .sp-ico{font-size:24px;line-height:1;margin-top:-1px}',
    '#spHost .sp-card2 .sp-txt{flex:1;min-width:0}',
    '#spHost .sp-card2 .sp-row{display:flex;align-items:center;gap:8px;flex-wrap:nowrap;min-width:0}',
    '#spHost .sp-card2 .sp-row b{flex:0 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:min(16px,4vw);line-height:1.3}',
    '#spHost .sp-card2 .sp-txt small{margin-top:6px;font-size:13px;line-height:1.4}',
    '#spHost .sp-card2 .sp-n-pill{display:inline-flex;flex-direction:row;align-items:center;gap:5px;min-width:0;margin:14px 0 0;padding:6px 13px;',
    '  border-radius:99px;background:#fff;border:1px solid #8CC6FF;font:600 13px/1.2 var(--font-body);color:#001E44;white-space:nowrap}',
    '#spHost .sp-card2 .sp-n-pill b{font:900 16px/1 var(--font-display);color:#0075E3}',
    '#spHost .sp-card2 .sp-n-pill.zero{opacity:.78}',
    'body.dark #spHost .sp-card2 .sp-n-pill{background:#001E44;border-color:#3F9FF4;color:#fff}body.dark #spHost .sp-card2 .sp-n-pill b{color:#8CC6FF}',
    '#spHost .sp-card2 .sp-chev{position:absolute;right:14px;top:auto;bottom:24px;margin:0}',
    /* 0.9.353, Andrea: "il calendario Le tue sessioni di Full Focus e' diventato minuscolo e stretto". Torna largo quanto il
       pannello (niente rientro ai lati) e i giorni sono quadrati che crescono con lo schermo: numeri a 16px, cerchi al 90%
       del giorno, scudi grandi. Le regole di serie.js restano, queste le superano solo qui dentro */
    '#spHost #serWrap.open #serBody{padding:14px 0 4px}',
    '#spHost #serBody .ser-cal{margin:0;padding:18px 12px;border-radius:20px}',
    '#spHost #serBody .ser-cal-tit{margin:0 0 14px;font-size:12.5px}',
    '#spHost #serBody .ser-top{margin:0 2px 14px}#spHost #serBody .ser-top b{font-size:17px}',
    '#spHost #serBody .ser-top button{width:40px;height:40px;font-size:26px}',
    '#spHost #serBody .ser-dow{gap:0;padding-bottom:6px}#spHost #serBody .ser-dow span{font-size:13px}',
    '#spHost #serBody .ser-grid{gap:4px 0}',
    '#spHost #serBody .ser-g,#spHost #serBody .ser-vuota{height:auto;aspect-ratio:1/1}',
    '#spHost #serBody .ser-g b{font-size:16px}',
    '#spHost #serBody .ser-g::before{width:90%;height:90%}',
    '#spHost #serBody .ser-g.f::after,#spHost #serBody .ser-g.fl::after,#spHost #serBody .ser-g.fr::after,#spHost #serBody .ser-g.flr::after{height:90%}',
    '#spHost #serBody .ser-g.oggi{background:radial-gradient(circle closest-side,#E63946 0 89%,transparent 91%)!important}',
    '#spHost #serBody .ser-g.coperto b{font-size:22px;line-height:1}',
    '#spHost #serBody .ser-leg{gap:20px;margin-top:16px}#spHost #serBody .ser-leg span{font-size:12.5px}#spHost #serBody .ser-leg i{width:14px;height:14px}',
    '.sp-card{display:flex;align-items:center;gap:16px;border:1px solid var(--line);border-radius:20px;padding:18px;background:#fff}',
    'body.dark .sp-card{background:#12203A;border-color:#22345A}',
    '.sp-ico{font-size:34px;flex:none}.sp-txt small{word-break:normal;overflow-wrap:normal}',
    '.sp-txt{flex:1;min-width:0;text-align:left}',
    '.sp-txt b{display:block;font:700 16px var(--font-body);color:var(--navy)}',
    'body.dark .sp-txt b{color:#fff}',
    '.sp-txt small{display:block;margin-top:6px;font:500 13px/1.35 var(--font-body);color:var(--muted)}',
    '.sp-q{flex:none;width:26px;height:26px;border-radius:50%;border:0;background:#EEF2F7;color:var(--muted);font:700 14px var(--font-body);cursor:pointer}',
    /* Il "?" sale sulla riga del titolo, e a destra ci va il numero: quello che serve sapere
       di questo pannello e' quante protezioni restano, e un numero grande lo dice senza
       doverlo leggere. */
    '.sp-row{display:flex;align-items:center;gap:10px}',
    '.sp-row b{flex:none}',
    '.sp-n{flex:none;min-width:34px;text-align:center;font:800 40px/1 var(--font-display);font-style:italic;color:#2F8BFF}',
    '.sp-n.zero{color:#E5515F}',
    '.sp-use{display:block;margin-top:12px;border:1px solid var(--line);background:#fff;color:var(--navy);',
    '  border-radius:99px;padding:9px 16px;font:700 12.5px var(--font-body);cursor:pointer}',
    'body.dark .sp-use{background:#16233A;border-color:#22345A;color:#fff}',
    /* Il giorno dopo una protezione scattata da sola il bordo si accende: stesso effetto del
       foglio degli appunti, rosso invece che blu. E' l'unica cosa che cambia aspetto in tutta
       la scheda, e deve saltare all'occhio una volta sola. */
    '.sp-card.burnt{border-color:#FF3B30;',
    '  box-shadow:0 0 0 1.5px #FF6B6B,0 8px 18px rgba(230,57,70,.28),0 22px 44px rgba(230,57,70,.16)}',
    '.sp-card.burnt .sp-n{color:#E5515F}',
    'body.dark .sp-q{background:#16233A;color:#fff}',
    '#serWrap .sp-card{cursor:pointer}',
    '.str-btn.ghost.premium{border-color:#E0A400;color:#8A5A00}',
    'body.dark .str-btn.ghost.premium{border-color:#E0A400;color:#FFD066}',
    '.str-btn.ghost[disabled]{opacity:.55;cursor:default}',
    '.sp-chev{flex:none;color:var(--faint);margin-left:8px;transition:transform .22s ease}',
    '#serWrap.open .sp-chev{transform:rotate(180deg)}',
    '#serBody{overflow:hidden}',
    '#serWrap.open #serBody{padding:6px 16px 18px}',
    '#spWrap{position:fixed;inset:0;z-index:78;display:none}#spWrap.open{display:block}',
    '.sp-scrim{position:absolute;inset:0;background:rgba(0,0,0,.4);opacity:0;transition:opacity .26s ease}',
    '#spWrap.in .sp-scrim{opacity:1}',
    '.sp-sheet{position:absolute;left:0;right:0;bottom:0;max-height:88%;overflow-y:auto;background:#fff;border-radius:26px 26px 0 0;',
    '  padding:14px 24px calc(28px + env(safe-area-inset-bottom));color:var(--navy);text-align:center;transform:translateY(100%);transition:transform .3s cubic-bezier(.2,.8,.3,1)}',
    'body.dark .sp-sheet{background:#12203A;color:#fff}',
    '#spWrap.in .sp-sheet{transform:none}',
    '.sp-grab{width:44px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 24px}',
    '.sp-bigico{font-size:56px;line-height:1}',
    '.sp-h{margin:20px 0 0;font:800 24px var(--font-display);font-style:italic}',
    '.sp-p{margin:18px 0 0;font:500 14px/1.65 var(--font-body);color:var(--muted)}',
    '.sp-note{font-size:13px;opacity:.9}',
    '.sp-count{margin-top:24px;display:inline-block;padding:10px 18px;border-radius:99px;background:#F3F5F8;font:700 13px var(--font-body);color:var(--navy)}',
    'body.dark .sp-count{background:#0E1B33;color:#fff}',
    '.sp-go{margin-top:32px}',

    /* il carosello: due pannelli sovrapposti, uno solo visibile */
    '.st-car{position:relative}',
    '.st-pane{display:none}',
    '.st-pane.on{display:block;animation:stPane .32s ease-out both}',
    '@keyframes stPane{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '.st-cardots{display:flex;gap:7px;justify-content:center;margin-top:16px}',
    '.st-cardots i{width:22px;height:3px;border-radius:99px;background:var(--line)}',
    '.st-cardots i.on{background:var(--blue,#006FCF)}',
    /* il foglio: lo stesso alone azzurro del Blocco rapido quando sta bloccando */
    '.st-note{background:var(--card);border:1px solid #0B84FF;border-radius:22px;padding:18px;',
    '  box-shadow:0 0 0 1.5px #3F9FF4,0 8px 18px rgba(11,132,255,.28),0 22px 44px rgba(11,132,255,.16)}',
    'body.dark .st-note{background:#0E1E3A}',
    '.st-notehead{display:flex;align-items:center;gap:10px}',
    '.st-days{flex:1;display:flex;gap:4px;background:var(--blue-soft,#E8F2FF);border-radius:99px;padding:3px;max-width:190px}',
    'body.dark .st-days{background:#0E1B33}',
    '.st-daytab{flex:1;border:0;border-radius:99px;background:transparent;color:var(--muted);padding:7px 10px;font:700 12px var(--font-body);cursor:pointer}',
    '.st-daytab.on{background:#fff;color:var(--blue,#006FCF);box-shadow:0 1px 4px rgba(0,30,68,.12)}',
    'body.dark .st-daytab.on{background:#1B2B47;color:#fff}',
    /* le caselle: una per riga, spuntata = archiviata; l'orologio dice che c'e' la sessione */
    '.st-list{margin-top:8px;border-top:1px solid var(--line);padding-top:6px}',
    'body.dark .st-list{border-top-color:#22345A}',
    '.st-row{display:flex;align-items:flex-start;gap:12px;padding:9px 2px;cursor:pointer;text-align:left}',
    /* il VAR: l'etichetta sulle righe fuori rotta e il cassetto che le tiene */
    '.st-et{display:block;margin-top:2px;font:600 10.5px var(--font-body);letter-spacing:.04em;color:var(--muted)}',
    '.st-altro{margin-top:6px;border-top:1px dashed var(--line);padding-top:4px}',
    '.st-altro summary{cursor:pointer;list-style:none;padding:8px 2px;font:700 12px var(--font-body);color:var(--muted)}',
    '.st-altro summary::-webkit-details-marker{display:none}',
    '.st-altro summary::before{content:"\\25B8";display:inline-block;margin-right:6px;transition:transform .2s}',
    '.st-altro[open] summary::before{transform:rotate(90deg)}',
    '.st-row.st-fuori .st-lab{color:var(--muted)}',
    '.btn{display:inline-block;border:0;border-radius:12px;padding:10px 14px;background:#0075E3;color:#fff;font:700 13px var(--font-body);cursor:pointer}',
    '.st-info{flex:none;width:24px;height:24px;border-radius:50%;border:1.5px solid var(--line);background:transparent;color:var(--muted);font:800 12px var(--font-display);font-style:italic;cursor:pointer}',
    '.st-synctxt{margin:4px 0 0;font:500 11px var(--font-body);color:var(--faint);text-align:center}.st-synctxt:empty{display:none}.st-synctxt.ko{color:#E5515F}',
    '.st-voto{display:inline-block;margin:4px 4px 0 0;border:1.5px solid var(--line);border-radius:999px;background:transparent;color:var(--navy);font:700 12px var(--font-body);padding:5px 10px;cursor:pointer}',
    'body.dark .st-voto{color:var(--ink)}',

    /* ---------- la casella, una sola forma in tutta l'app ---------- */
    '.stf-box{flex:none;width:23px;height:23px;margin-top:1px;border:2px solid var(--line);border-radius:7px;',
      'background:transparent;color:#fff;font:800 13px var(--font-body);line-height:1;cursor:pointer;',
      'display:flex;align-items:center;justify-content:center;transition:background .15s,border-color .15s}',
    '.stf-box.on{background:var(--blue,#0075E3);border-color:var(--blue,#0075E3)}',
    '.st-lab{flex:1;min-width:0;font:500 14.5px/1.5 var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .st-lab{color:#fff}',
    '.st-row.done .st-lab{opacity:.45;text-decoration:line-through}',

    /* ---------- il foglio a tutto schermo ---------- */
    '.stf-nav{flex:none;width:34px;height:34px;border:0;border-radius:50%;background:transparent;',
      'color:var(--muted);font:700 20px var(--font-body);line-height:1;cursor:pointer}',
    '.stf-nav:disabled{opacity:.25}',
    '.stf-body{flex:1;overflow-y:auto;padding:8px 0 16px}',
    '.stf-vuoto{margin:32px 8px;font:500 14px/1.6 var(--font-body);color:var(--faint);text-align:center}',
    '.stf-row{display:flex;align-items:flex-start;gap:12px;padding:12px 2px;border-bottom:1px solid var(--line)}',
    '.stf-txt{flex:1;min-width:0;font:500 15px/1.5 var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .stf-txt{color:#fff}',
    '.stf-row.done .stf-txt{opacity:.45;text-decoration:line-through}',
    '.stf-quad{display:block;margin-top:4px;font:700 11px var(--font-body);color:var(--muted);text-decoration:none}',
    '.stf-quad.q1{color:#C42B38}.stf-quad.q2{color:var(--blue,#0075E3)}.stf-quad.q3{color:#9A6800}',
    'body.dark .stf-quad.q1{color:#FF8A9B}body.dark .stf-quad.q2{color:#7FC3FF}body.dark .stf-quad.q3{color:#FFC53D}',
    /* la sola priorita' nella scheda START, e la porta al foglio intero */
    '.st-onelbl{margin:4px 0 6px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.st-row.st-one .st-lab{font-weight:700;font-size:15.5px}',
    '.st-tutto{display:block;width:100%;margin-top:12px;border:0;border-radius:12px;padding:12px;background:transparent;',
      'color:var(--blue,#0075E3);font:700 13px var(--font-body);text-align:left;cursor:pointer}',
    /* le sezioni del foglio grande */
    '.stf-sez{margin:0 0 8px;border-radius:16px;border:1.5px solid var(--line);padding:0 12px}',
    '.stf-sez summary{list-style:none;display:flex;align-items:baseline;gap:10px;padding:14px 2px;cursor:pointer}',
    '.stf-sez summary::-webkit-details-marker{display:none}',
    '.stf-sez summary b{flex:1;font:800 14px var(--font-body);color:var(--navy)}',
    'body.dark .stf-sez summary b{color:#fff}',
    '.stf-sez summary small{font:700 12px var(--font-body);color:var(--faint)}',
    '.stf-sez summary::after{content:"\\25B8";color:var(--faint);transition:transform .2s}',
    '.stf-sez[open] summary::after{transform:rotate(90deg)}',
    '.stf-sez.one{border-color:var(--blue,#0075E3)}',
    '.stf-sez.one summary b{color:var(--blue,#0075E3)}',
    'body.dark .stf-sez.one summary b{color:#7FC3FF}',
    '.stf-sez .stf-row:last-child{border-bottom:0}',
    '.stf-vuoto.piccolo{margin:0 0 14px;font-size:12.5px;text-align:left}',
    /* l'oblò: la porta di FullFocus con l'ora che c'è fuori */
    '.life.oblo{padding:22px 16px 20px}',
    '.oblo-dots{display:flex;gap:8px;justify-content:center;margin:12px 0 16px;flex-wrap:wrap}',
    '.oblo-dots i{width:10px;height:10px;border-radius:50%;background:rgba(255,255,255,.22)}',
    '.oblo-dots i.on{background:#8CF0C8;box-shadow:0 0 10px rgba(140,240,200,.7)}',
    '.oblo-img{position:relative;border-radius:16px;overflow:hidden;background:#0B1220}',
    /* la chiamata: sopra all'oblo', con il velo che tiene leggibile il bianco sul cielo */
    '.dco{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:space-between;',
      'padding:18px 14px;background:linear-gradient(180deg,rgba(4,10,24,.66),rgba(4,10,24,.12) 42%,rgba(4,10,24,.72))}',
    '.dco-testa{text-align:center}',
    '.dco-testa b{display:block;font:800 25px/1.1 var(--font-display);color:#fff;letter-spacing:.02em;',
      'text-shadow:0 2px 14px rgba(0,0,0,.6)}',
    '.dco-testa span{display:block;margin-top:6px;font:700 13px var(--font-body);color:#6FE9DA;',
      'text-shadow:0 2px 10px rgba(0,0,0,.6)}',
    '.dco-tasti{display:flex;justify-content:space-between;align-items:flex-end;padding:0 6px}',
    '.dco-tasti button{border:0;background:none;padding:0;cursor:pointer;display:flex;',
      'flex-direction:column;align-items:center;gap:7px}',
    '.dco-tasti i{display:flex;align-items:center;justify-content:center;width:56px;height:56px;',
      'border-radius:50%;font-size:25px;font-style:normal;box-shadow:0 6px 18px rgba(0,0,0,.4)}',
    '.dco-si i{background:#22C55E}',
    '.dco-no i{background:#EF4444;transform:rotate(135deg)}',
    '.dco-tasti small{font:600 12px var(--font-body);color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.7)}',
    '.dco-si i{animation:dcoSquilla 1.4s ease-in-out infinite}',
    '@keyframes dcoSquilla{0%,100%{transform:scale(1)}50%{transform:scale(1.09)}}',
    '.dco-motivi{display:flex;flex-direction:column;gap:9px;padding:0 4px}',
    '.dco-motivi button{border:1.5px solid rgba(255,255,255,.35);background:rgba(4,10,24,.45);',
      'color:#fff;border-radius:14px;padding:13px;font:700 13.5px var(--font-body);cursor:pointer}',
    '.dco-motivi button.arreso{border-color:rgba(239,68,68,.7);color:#FFB4B4}',
    '.dco-chiuso{position:absolute;left:0;right:0;bottom:0;padding:14px;',
      'background:linear-gradient(180deg,rgba(4,10,24,0),rgba(4,10,24,.8))}',
    '.dco-chiuso p{margin:0;text-align:center;font:600 12.5px/1.5 var(--font-body);color:#fff}',
    '@media (prefers-reduced-motion:reduce){.dco-si i{animation:none}}',
    '.oblo-img img{display:block;width:100%;height:auto;max-height:340px;object-fit:cover}',
    '.oblo-go{margin-top:16px}',
    '.st-list.st-oggi{padding-top:12px}',
    '.st-vuoto{margin:8px 0 12px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.st-dict.st-solo{justify-content:flex-end}',
    '.st-fatte{margin-top:20px;border-top:1px solid var(--line);padding-top:4px}',
    '.st-spuntata .st-lab,.st-spuntata .mf-t{text-decoration:line-through;color:var(--muted);transition:color .2s}',
    '.st-chiude{height:0!important;min-height:0!important;opacity:0;margin-top:0!important;margin-bottom:0!important;padding-top:0!important;padding-bottom:0!important;overflow:hidden;transition:height .38s ease,opacity .25s ease,margin .38s ease,padding .38s ease}',
    '.st-spunta-vola{position:fixed;z-index:9999;pointer-events:none;margin:0!important;background:var(--card,#fff);border-radius:12px;box-shadow:0 12px 28px rgba(15,32,65,.22);transform-origin:left top;transition:transform .46s cubic-bezier(.4,0,.2,1),opacity .46s ease}',
    '@keyframes stLampo{0%{background:transparent}30%{background:rgba(0,117,227,.14)}100%{background:transparent}}.st-fatte summary.st-lampo{animation:stLampo 1s ease;border-radius:10px}',
    '.st-fatte summary{list-style:none;display:flex;align-items:baseline;gap:8px;padding:10px 2px;cursor:pointer}',
    '.st-fatte summary::-webkit-details-marker{display:none}',
    '.st-fatte summary b{flex:1;font:800 13px var(--font-body);color:var(--navy)}',
    'body.dark .st-fatte summary b{color:#fff}',
    '.st-fatte summary small{font:700 12px var(--font-body);color:var(--faint)}',
    '.st-fatte summary::after{content:"\\25B8";color:var(--faint);transition:transform .2s}.st-fatte[open] summary::after{transform:rotate(90deg)}',
    '.st-appdot{flex:none;font-style:normal;color:var(--faint);margin-top:2px}',
    '.st-tappa{display:flex;align-items:flex-start;gap:10px;padding:8px 2px;font:500 14px/1.5 var(--font-body);color:var(--navy)}',
    'body.dark .st-tappa{color:#fff}',
    '.st-tappa i{flex:none;font-style:normal;width:22px;text-align:center}',
    '.st-tappa.fatta{opacity:.5;text-decoration:line-through}.st-tappa.prio span{font-weight:700}',
    /* il foglio grande: niente scorrimento laterale, paragrafi, editor, barra, revisioni */
    '.stf-body{overflow-x:hidden}.stf-txt,.stf-note{overflow-wrap:anywhere;word-break:break-word;min-width:0}',
    '.stf-dots{flex:none;width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--navy);font:800 20px var(--font-body);cursor:pointer}',
    'body.dark .stf-dots{color:#fff}',
    '.stf-par{margin:32px 0 10px;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.stf-sez.urg > .stf-sez{margin:0 0 8px;border-style:dashed}',
    '.stf-note{min-height:160px;padding:14px;border:1.5px solid var(--line);border-radius:16px;font:500 15px/1.6 var(--font-body);color:var(--navy);outline:0}',
    'body.dark .stf-note{color:#fff}',
    '.stf-note:empty::before{content:attr(data-placeholder);color:var(--faint)}',
    '.stf-note img{max-width:100%;border-radius:12px}',
    '.stf-bar{position:sticky;bottom:0;z-index:5;display:flex;gap:2px;align-items:center;overflow-x:auto;scrollbar-width:none;',
      'margin:0 -18px;padding:6px 10px calc(6px + env(safe-area-inset-bottom));background:var(--card,#fff);border-top:1px solid var(--line)}',
    '.stf-bar::-webkit-scrollbar{display:none}',
    '.stf-bar button{flex:0 0 auto;min-width:40px;height:38px;border:0;border-radius:10px;background:transparent;color:var(--navy);font:700 15px var(--font-body);cursor:pointer}',
    'body.dark .stf-bar button{color:#fff}',
    '.stf-bar button:active{background:rgba(0,117,227,.14)}',
    '.stf-sep{flex:0 0 1px;height:22px;background:var(--line);margin:0 4px}',
    '.stf-col{border-bottom:3px solid #C42B38}.stf-hl{background:#FFF3B0;color:#0E2350;padding:0 4px;border-radius:4px}',
    '.stf-wrap.scrive .stf-body{padding-bottom:8px}',
    '.stf-rev{display:flex;flex-direction:column;gap:8px;padding-bottom:24px}',
    '.stf-revrow{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px}',
    '.stf-revrow > div{flex:1;min-width:0}.stf-revrow b{display:block;font:700 14px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .stf-revrow b{color:#fff}',
    '.stf-revrow small{display:block;margin-top:4px;font:500 12px/1.5 var(--font-body);color:var(--muted)}',
    '.stf-revrow small.ok{color:#1B9E6A}.stf-revrow small.no{color:#C42B38}',
    'body.dark .stf-revrow small.ok{color:#5FD3A0}body.dark .stf-revrow small.no{color:#FF8A9B}',
    /* il cassetto del calendario */
    '#stfDrawer{position:absolute;inset:0;z-index:65}#stfDrawer[hidden]{display:none}',
    '.stfd-scrim{position:absolute;inset:0;background:rgba(4,10,28,.5);opacity:0;transition:opacity .22s}',
    '#stfDrawer.in .stfd-scrim{opacity:1}',
    '.stfd-pane{position:absolute;top:0;right:0;bottom:0;width:92%;max-width:420px;background:var(--card,#fff);',
      'box-shadow:-12px 0 40px rgba(0,0,0,.3);padding:calc(14px + env(safe-area-inset-top)) 18px 24px;overflow-y:auto;overflow-x:hidden;',
      'transform:translateX(100%);transition:transform .22s ease}',
    '#stfDrawer.in .stfd-pane{transform:none}',
    '.stfd-tabs{display:flex;gap:6px;align-items:center;margin-bottom:16px}',
    '.stfd-tabs button{border:1.5px solid var(--line);border-radius:999px;background:transparent;color:var(--muted);font:700 13px var(--font-body);padding:8px 14px;cursor:pointer}',
    '.stfd-tabs button.on{background:var(--blue,#0075E3);border-color:var(--blue,#0075E3);color:#fff}',
    '.stfd-tabs .stfd-x{margin-left:auto;border:0;width:36px;height:36px;padding:0;border-radius:50%}',
    '.stfd-titolo{font:800 20px var(--font-display);font-style:italic;color:var(--navy);margin-bottom:12px}',
    'body.dark .stfd-titolo{color:#fff}',
    '.stfd-ob{padding:14px 16px;border:1.5px solid var(--line);border-radius:16px;margin-bottom:24px}',
    '.stfd-ob small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint);margin-bottom:6px}',
    '.stfd-ob b{display:block;font:800 15px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .stfd-ob b{color:#fff}',
    '.stfd-passi{margin-top:10px}.stfd-passi div{display:flex;gap:8px;padding:4px 0;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.stfd-passi div.fatto{text-decoration:line-through;opacity:.6}.stfd-passi i{font-style:normal;flex:none}',
    '.stfd-nav{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}',
    '.stfd-nav b{font:800 14px var(--font-body);color:var(--navy);text-transform:capitalize}',
    'body.dark .stfd-nav b{color:#fff}',
    '.stfd-nav button{width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--muted);font:700 20px var(--font-body);cursor:pointer}',
    '.stfd-sett{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;font:700 11px var(--font-body);color:var(--faint);margin-bottom:4px}',
    '.stfd-griglia{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}',
    '.stfd-g{position:relative;aspect-ratio:1;border:0;border-radius:12px;background:transparent;color:var(--navy);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .stfd-g{color:#fff}',
    '.stfd-g.oggi{background:var(--blue,#0075E3);color:#fff}',
    '.stfd-g i{position:absolute;left:50%;bottom:6px;width:5px;height:5px;margin-left:-2px;border-radius:50%;background:var(--faint)}',
    '.stfd-g.fatte i{background:#1B9E6A}.stfd-g.oggi i{background:#fff}',
    '.stf-add{display:flex;align-items:flex-end;gap:12px;padding:12px 0 8px;border-top:1px solid var(--line)}',
    '.stf-input{flex:1;border:0;outline:0;resize:none;background:transparent;color:var(--navy);',
      'font:500 15px/1.5 var(--font-body);max-height:140px}',
    'body.dark .stf-input{color:#fff}',

    /* ---------- il foglio di conferma ---------- */
    '#stAsk{position:absolute;inset:0;z-index:70;display:flex;align-items:flex-end;justify-content:center}',
    '#stAsk[hidden]{display:none}',
    '.sta-scrim{position:absolute;inset:0;background:rgba(4,10,28,.62)}',
    '.sta-card{position:relative;width:100%;margin:0 12px 12px;background:var(--card,#fff);border-radius:22px;',
      'padding:24px;box-shadow:0 18px 50px rgba(0,0,0,.35);animation:staUp .22s ease}',
    '@keyframes staUp{from{transform:translateY(16px);opacity:0}to{transform:none;opacity:1}}',
    '.sta-t{display:block;font:800 19px/1.3 var(--font-display);color:var(--navy);margin-bottom:12px}',
    '.sta-riga{margin:0;font:500 15px/1.5 var(--font-body);color:var(--navy);opacity:.75}',
    '.sta-nota{margin:16px 0 0;font:500 13px/1.6 var(--font-body);color:var(--muted)}',
    '.sta-btns{display:flex;gap:12px;margin-top:24px}',
    '.sta-no,.sta-si{flex:1;border:0;border-radius:14px;padding:14px 8px;font:800 14px var(--font-body);cursor:pointer}',
    '.sta-no{background:transparent;border:1.5px solid var(--line);color:var(--muted)}',
    'body.dark .sta-no{border-color:rgba(255,255,255,.22);color:#C8DAF2}',
    '.sta-si{background:var(--blue,#0075E3);color:#fff}',
    '.sta-si.rischio{background:#C42B38}',

    /* ---------- la pagina della riga ---------- */
    '.str-wrap{display:flex;flex-direction:column;height:100%;padding:0 20px calc(16px + env(safe-area-inset-bottom))}',
    '.str-top{padding:10px 0 4px}',
    '.str-body{flex:1;overflow-y:auto;padding-bottom:48px}',
    /* 1 · la cosa da fare: l'unico elemento primario della pagina */
    '.str-testo{width:100%;border:0;outline:0;resize:none;background:transparent;',
      'font:800 21px/1.35 var(--font-display);color:var(--navy);padding:0;margin:0}',
    'body.dark .str-testo{color:#fff}',
    /* 2 · il quadrante: l'unica emoji, l'unico colore */
    '.str-quad{margin-top:16px;padding:14px 16px;border-radius:16px;border:1.5px solid var(--line);background:transparent}',
    '.str-quad b{display:block;font:800 14px var(--font-body);color:var(--navy)}',
    'body.dark .str-quad b{color:#fff}',
    '.str-quad small{display:block;margin-top:4px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    '.str-quad.q1{border-color:rgba(196,43,56,.45);background:rgba(196,43,56,.08)}.str-quad.q1 b{color:#C42B38}',
    'body.dark .str-quad.q1 b{color:#FF8A9B}',
    '.str-quad.q2{border-color:rgba(0,117,227,.45);background:rgba(0,117,227,.08)}.str-quad.q2 b{color:#0075E3}',
    'body.dark .str-quad.q2 b{color:#7FC3FF}',
    '.str-quad.q3{border-color:rgba(154,104,0,.45);background:rgba(255,197,61,.10)}.str-quad.q3 b{color:#9A6800}',
    'body.dark .str-quad.q3 b{color:#FFC53D}',
    /* 3 · i cartelli di sezione: tutti uguali, smorzati, senza emoji */
    '.str-sez{margin:32px 0 12px;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.str-micro{width:100%;border:1.5px solid var(--line);border-radius:14px;padding:14px;resize:none;',
      'background:transparent;color:var(--navy);font:500 14px/1.6 var(--font-body);min-height:96px}',
    'body.dark .str-micro{color:#fff}',
    '.str-hint{margin:12px 0 0;font:500 12.5px/1.6 var(--font-body);color:var(--muted)}',
    '.str-chips{display:flex;flex-wrap:wrap;gap:8px}',
    '.str-chips button{border:1.5px solid var(--line);border-radius:999px;background:transparent;',
      'color:var(--navy);font:700 13px var(--font-body);padding:9px 14px;cursor:pointer}',
    'body.dark .str-chips button{color:#fff}',
    '.str-chips button.on{background:var(--blue,#0075E3);border-color:var(--blue,#0075E3);color:#fff}',
    '.str-btn{width:100%;border:0;border-radius:14px;padding:14px;background:var(--blue,#0075E3);color:#fff;',
      'font:800 14px var(--font-body);cursor:pointer}',
    '.str-btn.ghost{background:transparent;border:1.5px solid var(--line);color:var(--muted)}',
    '.str-foto img{width:100%;max-height:280px;object-fit:cover;border-radius:16px;margin-bottom:12px}',

    '.st-del{flex:none;border:0;background:none;color:var(--faint);font:600 14px var(--font-body);cursor:pointer;padding:2px 4px}',
    '.st-seen{flex:none;font-style:normal;font-size:14px;color:#0E7C6B;margin-top:2px}',
    '.st-notehint{margin:8px 0 0;min-height:0;max-height:0;overflow:hidden;font:600 12.5px/1.5 var(--font-body);color:var(--blue,#006FCF);transition:max-height .25s ease;text-align:left}',
    '.st-notehint.on{max-height:4em}',
    /* la dettatura: il microfono rosa, e al suo posto la pillola con l'onda */
    '.st-dict{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:14px;min-height:46px}',
    '.st-expand{width:40px;height:40px;border-radius:50%;border:0;background:#EEF2F7;color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .st-expand{background:#16233A;color:#fff}',
    '.st-dict.on .st-expand{display:none}',
    /* Con la tastiera aperta il microfono sale sopra ai tasti invece di finirci sotto: e'
       li' che serve, ed e' li' che lo mette l'app da cui viene l'idea. */
    /* Con adjustResize la finestra finisce dove comincia la tastiera: basta appoggiarlo al
       fondo. Sommare anche l'altezza dei tasti lo faceva salire il doppio del dovuto — era il
       "salgono troppo". --kbdfix vale 0 quando la finestra si e' davvero accorciata, e torna a
       valere l'altezza dei tasti solo sui telefoni che invece spingono su la pagina. */
    'body.kbd .st-dict{position:fixed;right:18px;bottom:calc(var(--kbdfix, 0px) + 14px);z-index:60;margin:0}',
    /* il foglio a tutto schermo */
    '.stf-wrap{display:flex;flex-direction:column;height:100%;padding:0 18px calc(12px + env(safe-area-inset-bottom))}',
    '.stf-top{display:flex;align-items:center;gap:12px;padding:10px 0 6px}',
    '.stf-top b{flex:1;font:800 17px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .stf-top b{color:#fff}',
    '.stf-mic{width:42px;height:42px}',
    '.stf-area{flex:1;width:100%;border:0;outline:0;resize:none;background:transparent;color:var(--navy);',
    '  font:500 16px/1.85 var(--font-body);padding:8px 0 0}',
    'body.dark .stf-area{color:#fff}',
    '.st-mic{width:46px;height:46px;border-radius:50%;border:0;background:#E3F1FF;color:#0075E3;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 6px 16px rgba(0,117,227,.18)}',
    '.st-dict.on .st-mic{display:none}',
    '.st-pill{display:none;align-items:center;gap:10px}',
    '.st-dict.on .st-pill{display:flex}',
    '.st-pillbtn{width:46px;height:46px;border-radius:50%;border:0;background:#E3F1FF;color:#0E2350;font:600 18px var(--font-body);cursor:pointer}',
    '.st-pillbtn.ok{background:#0075E3;color:#fff}',
    '.st-wave{display:flex;align-items:center;gap:3px;height:46px;padding:0 16px;border-radius:99px;background:#E3F1FF;--lvl:0}',
    '.st-wave i{display:block;width:3px;height:8px;border-radius:2px;background:#0075E3;animation:stWave .9s ease-in-out infinite;transform-origin:center}',
    '.st-wave i:nth-child(2n){animation-delay:.15s}.st-wave i:nth-child(3n){animation-delay:.3s}.st-wave i:nth-child(5n){animation-delay:.45s}',
    '@keyframes stWave{0%,100%{transform:scaleY(calc(.5 + var(--lvl)))}50%{transform:scaleY(calc(1.6 + var(--lvl) * 2))}}',
    '.st-notehead b{flex:1;text-align:left;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--blue,#006FCF)}',
    '.st-q{flex:none;width:26px;height:26px;border-radius:50%;border:0;background:var(--blue-soft,#E8F2FF);color:var(--blue,#006FCF);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .st-q{background:#16233A;color:#8FB4FF}',
    /* Una riga, non un foglio: adesso questo campo serve ad aggiungere una cosa. */
    '.st-notearea{display:block;width:100%;min-height:32px;margin-top:14px;border:0;outline:0;resize:none;background:transparent;',
    '  color:var(--navy);font:500 15.5px/1.75 var(--font-body);text-align:left}',
    'body.dark .st-notearea{color:#fff}',
    '.st-notearea::placeholder{color:var(--faint)}',
    '.st-notefoot{margin:14px 0 0;font:500 12.5px/1.6 var(--font-body);color:var(--muted);text-align:left}',
    '.st-notefoot b{color:var(--navy)}',
    'body.dark .st-notefoot b{color:#fff}',
    /* .life-edit e' pensato per il pannello scuro: bianco su trasparente. Qui sta sulla
       pagina chiara, e il pulsante per passare all'altro pannello spariva. */
    '.st-toex{display:block;margin:18px auto 0;border:1px solid var(--line);background:#fff;color:var(--navy);',
    '  border-radius:99px;padding:11px 20px;font:700 12.5px var(--font-body);cursor:pointer}',
    'body.dark .st-toex{background:#12203A;border-color:#22345A;color:#fff}',
    '.st-carnav{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:18px}',
    '.st-carnav .st-toex{margin:0}',
    /* i due portali: stessa scatola scura degli altri pannelli, meno roba dentro */
    '.st-portal{text-align:center}',
    '.st-portal-ic{font-size:44px;line-height:1;margin-bottom:6px}',
    '.pn-row{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:14px;',
    '  padding:14px 16px;border-radius:16px;background:rgba(255,255,255,.06);cursor:pointer}',
    '.pn-row span{font:600 14.5px var(--font-body);color:#fff;text-align:left}',
    '.pn-row.off{opacity:.45}',
    '.pn-row input[type=checkbox]{width:22px;height:22px;accent-color:#2F8BFF}',
    '.pn-row input[type=time]{border:0;border-radius:10px;padding:8px 10px;background:rgba(255,255,255,.12);',
    '  color:#fff;font:700 15px var(--font-body);cursor:pointer}',
    '.pn-note{font-size:12.5px;opacity:.8}',
    /* il gol */
    '#goalWrap{display:none;position:fixed;inset:0;z-index:95}',
    '#goalWrap.open{display:block}',
    '#goalWrap[hidden]{display:none}',
    '.gl-scrim{position:absolute;inset:0;background:rgba(3,10,26,.62);opacity:0;transition:opacity .24s ease}',
    '#goalWrap.in .gl-scrim{opacity:1}',
    '.gl-card{position:absolute;left:22px;right:22px;top:50%;transform:translateY(-50%) scale(.9);opacity:0;transition:transform .32s cubic-bezier(.2,.9,.3,1.2),opacity .24s ease;',
    '  background:linear-gradient(160deg,#0E2350,#061634);border-radius:26px;padding:32px 24px;text-align:center;color:#fff;box-shadow:0 24px 60px rgba(0,0,0,.5)}',
    '#goalWrap.in .gl-card{transform:translateY(-50%) scale(1);opacity:1}',
    '.gl-ico{font-size:54px;line-height:1;animation:glPop .5s cubic-bezier(.2,.9,.3,1.4) both}',
    '@keyframes glPop{from{transform:scale(.3) rotate(-25deg)}to{transform:none}}',
    '.gl-k{display:block;margin-top:16px;font:800 11.5px var(--font-body);letter-spacing:.18em;text-transform:uppercase;color:#8CF0C8}',
    '.gl-card.loro .gl-k{color:#FF8A9B}',
    '.gl-score{display:flex;align-items:center;justify-content:center;gap:16px;margin-top:14px;font:800 46px/1 var(--font-display)}',
    '.gl-score .old{color:#FF8A9B}.gl-score .neo{color:#8CF0C8}.gl-score i{font-style:normal;font-size:28px;color:rgba(255,255,255,.5)}',
    '.gl-p{margin:18px auto 0;max-width:22em;font:500 14px/1.6 var(--font-body);color:rgba(255,255,255,.86)}',
    '.st-intro{padding:30px 0 4px}',
    '#stFocus{padding:0 18px}',
    '.st-intro .st-eyebrow{margin:16px 0 6px;text-align:center;font:700 12px var(--font-body);letter-spacing:.18em;text-transform:uppercase;color:var(--muted) !important;text-shadow:none}.st-intro .fl-titolo{margin-top:0}',
    /* 0.9.260, Andrea: senza l'occhiello sopra, il titolo restava attaccato al razzo */
    '.st-intro .sev-intro-ic + .fl-titolo{margin-top:20px !important}',
    /* L'OSTACOLO SI SPOSTA (0.9.209): resta qualche secondo, poi scivola a destra svanendo, e con lui
       se ne vanno Domani e le Completate. Il pannello resta su quello che c'e' da fare adesso. */
    '.sev-intro.st-intro .st-ostacolo{margin:10px 18px 26px !important}.sev-intro.st-intro p.st-eyebrow{margin:18px 18px 6px !important}',
    '.st-ostacolo{margin:8px 0 22px;text-align:center;font:500 15px/1.4 var(--font-body);color:var(--muted);animation:stScivola 5.72s cubic-bezier(.5,0,.7,1) forwards;overflow:hidden;max-height:120px;will-change:transform,opacity}',
    '.st-note:not(.st-tutto) .st-daytab[data-k="domani"]:not(.on),.st-note:not(.st-tutto) .st-fatte{animation:stScivola 5.72s cubic-bezier(.5,0,.7,1) forwards;overflow:hidden;max-height:120px;will-change:transform,opacity}',
    /* 0.9.267: due animazioni sullo stesso elemento (una di layout, anche se in ritardo) mandano TUTTE E DUE sul thread
       principale per tutta la durata: 6,5 s di ricalcoli a ogni fotogramma appena si apre START. Adesso la scivolata e'
       una sola (trasformazione e opacita', scheda grafica); a fine corsa un evento mette .st-via e lo spazio si chiude
       con una transizione breve. */
    '.st-ostacolo.st-via,.st-daytab.st-via,.st-fatte.st-via{transition:max-height .5s ease-in,max-width .5s ease-in,margin .5s ease-in,padding .5s ease-in,border-width .5s ease-in;max-height:0 !important;max-width:0 !important;margin:0 !important;padding:0 !important;border-width:0 !important;animation:none !important;opacity:0;pointer-events:none}',
    /* 0.9.264, Andrea (lag nello scroll): la scivolata animava max-height per 6,5 secondi, e una proprieta' di layout
       animata ricalcola la pagina a ogni fotogramma: aprendo START lo scroll scattava. Adesso la scivolata e' solo
       opacita' e spostamento (li muove la scheda grafica), e lo spazio si chiude in un colpo breve alla fine. */
    '@keyframes stScivola{0%,70%{opacity:1;transform:none}100%{opacity:0;transform:translateX(90px)}}',

    '.st-modo{position:relative;display:flex;margin:4px 0 18px;padding:4px;border-radius:99px;background:#0A2A57;box-shadow:0 8px 20px rgba(0,30,68,.22)}body.dark .st-modo{background:#1A2338;box-shadow:none}.st-modo button{position:relative;z-index:1;flex:1;border:0;background:transparent;color:#fff;font:800 14px var(--font-body);padding:11px 6px;border-radius:99px;cursor:pointer}.st-modo button.on{color:#001E44}',
    '.st-modo-k{position:absolute;top:4px;bottom:4px;left:4px;width:calc(50% - 4px);border-radius:99px;background:#fff;box-shadow:0 4px 12px rgba(0,8,30,.25);transition:transform .32s cubic-bezier(.2,.8,.3,1)}.st-modo-k.dx{transform:translateX(100%)}',
    '.st-gr{display:flex;flex-direction:column;gap:12px}.st-gr-row{display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:16px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);cursor:pointer}body.dark .st-gr-row{background:#12203A;border-color:#22345A}.st-gr-row > span:first-child{font-size:26px;width:34px;text-align:center}.st-gr-row > div{flex:1}.st-gr-row b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .st-gr-row b{color:#fff}.st-gr-row small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.st-tempo-r{padding:4px 0 8px 46px}.st-tempo{display:inline-flex;align-items:center;gap:6px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy);font:700 12.5px var(--font-body);padding:7px 12px;cursor:pointer}.st-tempo em{font-style:normal;font-weight:500;color:var(--muted)}body.dark .st-tempo{background:#12203A;border-color:#22345A;color:#fff}#mppFoglio .st-tempo-r{display:none}',
    '.stt{text-align:center}.stt-img{width:120px;height:120px;margin:6px auto 14px;border-radius:28px;display:flex;align-items:center;justify-content:center;font-size:62px;box-shadow:0 12px 26px rgba(0,30,68,.25)}.stt-nome{margin:0 0 14px;font:800 21px/1.3 var(--font-display);color:var(--navy)}body.dark .stt-nome{color:#fff}',
    '.stt-qty{display:inline-flex;align-items:center;gap:0;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);overflow:hidden}.stt-qty button{width:52px;height:48px;border:0;background:transparent;font:500 24px var(--font-body);color:var(--navy);cursor:pointer}.stt-qty input{width:58px;height:48px;border:0;background:transparent;text-align:center;font:800 18px var(--font-body);color:var(--navy);-moz-appearance:textfield}.stt-qty input::-webkit-inner-spin-button{-webkit-appearance:none}.stt-qty span{font:600 13px var(--font-body);color:var(--muted);margin-right:4px}body.dark .stt-qty{background:#12203A;border-color:#22345A}body.dark .stt-qty button,body.dark .stt-qty input{color:#fff}',
    /* 0.9.343, Andrea: "i pulsanti meno e piu' non hanno nessuna shadow, c'e' solo un bordo grigio poco visibile; quelli delle prime
       versioni erano perfetti perche' si vedevano grazie all'ombra". Due bottoni tondi bianchi con l'ombra, il numero in mezzo */
    '.stt-qty{gap:14px;border:0!important;background:transparent!important;overflow:visible}.stt-qty button{width:50px;height:50px;border-radius:50%;background:#fff;color:#0075E3;font:700 28px/1 var(--font-body);box-shadow:0 6px 16px rgba(0,30,68,.18),0 1px 3px rgba(0,30,68,.12)}.stt-qty button:active{transform:scale(.94);box-shadow:0 2px 6px rgba(0,30,68,.18)}body.dark .stt-qty button{background:#1B2E52;color:#8CC6FF;box-shadow:0 6px 16px rgba(0,0,0,.45)}.stt-qty input{width:64px;font-size:24px}',
    '.stt-carb{margin:12px 0 14px;font:500 13.5px var(--font-body);color:var(--muted)}.stt-carb b{color:#C2410C}',
    '.stt-chips{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:16px}.stt-chips button{display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px 4px;border:1.5px solid var(--line);border-radius:12px;background:var(--card,#fff);cursor:pointer}.stt-chips b{font:800 14px var(--font-body);color:var(--navy)}.stt-chips small{font:500 10.5px var(--font-body);color:var(--muted)}.stt-chips button.on{border-color:#0075E3;background:rgba(0,117,227,.1)}body.dark .stt-chips button{background:#12203A;border-color:#22345A}body.dark .stt-chips b{color:#fff}',
    '.stt-via{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:17px 20px;border:0;border-radius:99px;background:linear-gradient(90deg,#E63946,#FF7A59);color:#fff;font:900 15px var(--font-body);letter-spacing:.06em;cursor:pointer;box-shadow:0 8px 20px rgba(230,57,70,.3)}.stt-via .chev{border-color:#fff !important}',
    '.st-tempo-p{margin:0 0 14px;font:600 14px/1.4 var(--font-body);color:var(--navy)}body.dark .st-tempo-p{color:#fff}.st-tempo-l{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}.st-tempo-l button{display:flex;flex-direction:column;align-items:center;gap:3px;padding:14px 6px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);font:800 15px var(--font-body);color:var(--navy);cursor:pointer}.st-tempo-l button b{font:800 17px var(--font-body)}.st-tempo-l button em{font:800 11.5px var(--font-body);font-style:normal;color:#C2410C}.st-tempo-l button small{font:500 10.5px var(--font-body);color:var(--muted)}.st-tempo-l button.on{border-color:#0075E3;background:rgba(0,117,227,.1);color:#0075E3;box-shadow:0 0 0 3px rgba(0,117,227,.2)}body.dark .st-tempo-l button{background:#12203A;border-color:#22345A;color:#fff}',
    '.st-tempo-mio{display:flex;align-items:center;gap:12px;margin-top:12px;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff)}.st-tempo-mio.on{border-color:#0075E3}.st-tempo-mio > div{flex:1}.st-tempo-mio b{display:block;font:800 14px var(--font-body);color:var(--navy)}.st-tempo-mio small{font:500 11.5px var(--font-body);color:var(--muted)}.st-tempo-mio .fin{width:84px;margin:0;text-align:center}body.dark .st-tempo-mio{background:#12203A;border-color:#22345A}body.dark .st-tempo-mio b{color:#fff}',
    '#mppFoglio .st-daytab[data-k="mappa"]{display:none}.st-domanda{margin:-2px 6px 14px;text-align:center;font:italic 500 clamp(12.5px,3.7vw,16px)/1.4 var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#mppFoglio .st-days{padding-right:40px}',
    '#mppFoglio .st-modo{display:none}#tab-sveglia .st-daytab[data-k="mappa"]{display:none}',
    /* Domani e Calendario in START: scivolano via insieme all'ostacolo (in larghezza, stanno in fila) */
    '#tab-sveglia .st-note:not(.st-tutto) .st-daytab[data-k="domani"],#tab-sveglia .st-note:not(.st-tutto) .st-daytab[data-k="cal"]{animation:stScivolaW 5.72s cubic-bezier(.5,0,.7,1) forwards;overflow:hidden;white-space:nowrap;max-width:160px;will-change:transform,opacity}',
    '#tab-sveglia .st-note.st-tutto .st-daytab[data-k="cal"]{display:none}',
    /* le tre schede intere, e quando Domani e Calendario scivolano via il contenitore si stringe su Oggi */
    '#tab-sveglia .st-days{flex:none;max-width:none;width:auto;gap:0}#tab-sveglia .st-daytab{flex:none;white-space:nowrap;padding:7px 14px}#tab-sveglia .st-daytab + .st-daytab{margin-left:2px}',
    /* Finche' Domani e Calendario non sono ancora scivolate via, le tre schede intere possono stare
       piu' larghe della card: senza un bordo che le tagli, l'ultima (Calendario) si vedeva uscire
       dal riquadro arrotondato. */
    '#tab-sveglia .st-notehead{overflow:hidden}',
    '@keyframes stScivolaW{0%,70%{opacity:1;transform:none}100%{opacity:0;transform:translateX(60px)}}',

    '#stPark{padding:0 18px}',
    '#stMidHero{margin-top:40px;margin-bottom:40px}',
    '.st-tappa{display:flex;align-items:center;gap:12px}.st-tappa-ico{font-size:24px;flex:none}.st-tappa .st-lab{flex:1;font-weight:700}',
    '.st-tappa-via{flex:none;border:0;border-radius:999px;padding:10px 18px;background:#0075E3;color:#fff;font:800 14px var(--font-body);cursor:pointer}',
    '#stMidHero .st-cit-s{background:#000}#stMidHero .st-cit{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:40px 24px}#stMidHero .st-cit .bh-title{width:100%;text-align:center}',
    '#stMidHero .st-cit .bh-title{font:400 30px/1.25 "Segoe UI",system-ui,-apple-system,sans-serif;letter-spacing:0;text-transform:none;color:#fff;margin:0}',
    '#stMidHero .st-cit .st-cit-a{display:block;margin-top:16px;font:700 15px var(--font-body);color:rgba(255,255,255,.62)}',
    '#stMidHero .bh-dots{bottom:22px}',
    /* l'intermezzo non ha nuvole: non e' un cielo, e' una pausa */
    '#stMidHero .bh-img{transform:none;animation:none}',
    '#stFocus .life-sub{color:var(--muted)}',
    '#stFocus .life-sub i{color:var(--faint)}',
    /* la priorita' del giorno, con la sua spunta */
    '.st-task{display:flex;align-items:flex-start;gap:14px;margin:18px 0 0;padding:16px;border-radius:16px;background:rgba(255,255,255,.06);cursor:pointer;text-align:left}',
    '.st-task input{width:22px;height:22px;flex:none;margin-top:1px;accent-color:#2F8BFF}',
    '.st-task span{flex:1;font:600 15.5px/1.5 var(--font-body);color:#fff}',
    '.st-task.done span{opacity:.5;text-decoration:line-through}',
    '.st-again{margin-top:18px}',

    /* l'esercizio: una cosa alla volta anche qui, con l'aria che serve */
    '.ot-wrap{padding:0 22px calc(40px + env(safe-area-inset-bottom));text-align:center}',
    '.ot-top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 0 8px}',
    '.ot-top > span{width:34px}',
    '.ot-back{width:34px;height:34px;border-radius:50%;border:0;background:#EEF2F7;color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .ot-back{background:#16233A;color:#fff}',
    '.ot-dots{display:flex;gap:7px}',
    '.ot-dots i{width:26px;height:3px;border-radius:99px;background:var(--line)}',
    '.ot-dots i.on{background:var(--blue,#006FCF)}',
    '.ot-ic{font-size:50px;line-height:1;margin-top:32px}',
    '.ot-h{font:800 25px var(--font-display);font-style:italic;color:var(--navy);margin:18px 0 0}',
    'body.dark .ot-h{color:#fff}',
    '.ot-p{font:500 14px/1.65 var(--font-body);color:var(--muted);margin:16px 0 0}',
    '.ot-q{margin:32px 0 0;padding:0 6px;font:500 14.5px/1.7 var(--font-body);font-style:italic;color:var(--navy)}',
    'body.dark .ot-q{color:#E7EDF6}',
    '.ot-q i{display:block;margin-top:12px;font:600 12.5px var(--font-body);font-style:normal;color:var(--muted)}',
    '.ot-q--big{font-size:16px;margin-top:24px}',
    '.ot-when{display:flex;gap:6px;background:#EEF2F7;border-radius:99px;padding:5px;margin-top:28px}',
    'body.dark .ot-when{background:#0E1B33}',
    '.ot-when button{flex:1;border:0;border-radius:99px;background:transparent;color:var(--muted);padding:11px 8px;font:700 13.5px var(--font-body);cursor:pointer}',
    '.ot-when button.on{background:#fff;color:var(--navy);box-shadow:0 2px 8px rgba(0,0,0,.08)}',
    'body.dark .ot-when button.on{background:#1B2B47;color:#fff}',
    '.ot-list{display:flex;flex-direction:column;gap:10px;margin-top:32px}',
    '.ot-item{display:flex;align-items:center;gap:12px;border:1px solid var(--line);border-radius:14px;padding:14px 16px;text-align:left}',
    'body.dark .ot-item{border-color:#22345A}',
    '.ot-item span{flex:1;font:500 14.5px/1.45 var(--font-body);color:var(--navy)}',
    'body.dark .ot-item span{color:#fff}',
    '.ot-item button{border:0;background:transparent;color:var(--muted);font:600 16px var(--font-body);cursor:pointer;padding:4px 6px}',
    '.ot-pick{display:flex;align-items:center;gap:14px;width:100%;border:1px solid var(--line);background:#fff;border-radius:16px;padding:16px;text-align:left;cursor:pointer}',
    'body.dark .ot-pick{background:#12203A;border-color:#22345A}',
    '.ot-pick span{flex:1;font:600 14.5px/1.45 var(--font-body);color:var(--navy)}',
    'body.dark .ot-pick span{color:#fff}',
    '.ot-pick i{width:22px;height:22px;border-radius:7px;border:2px solid var(--line);flex:none}',
    '.ot-pick.on{border-color:var(--blue,#006FCF);background:#F2F8FF}',
    'body.dark .ot-pick.on{background:#16233A}',
    '.ot-pick.on i{border-color:var(--blue,#006FCF);background:var(--blue,#006FCF);box-shadow:inset 0 0 0 3px #fff}',
    '.ot-final{justify-content:center;text-align:center}.ot-final span{flex:0 1 auto;font-size:16px}',
    '.ot-add{display:flex;align-items:center;gap:10px;margin-top:16px;border:1px solid var(--line);border-radius:16px;padding:0 6px 0 16px;background:#fff}',
    'body.dark .ot-add{background:#12203A;border-color:#22345A}',
    '.ot-add input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:var(--navy);padding:15px 0;font:500 15px var(--font-body)}',
    'body.dark .ot-add input{color:#fff}',
    '.ot-add button{border:0;border-radius:12px;background:var(--blue,#006FCF);color:#fff;width:40px;height:40px;font:600 22px/1 var(--font-body);cursor:pointer;flex:none}',
    '.ot-note{margin-top:20px;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.ot-go{margin-top:32px}',
    '.ot-go[disabled]{opacity:.45}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   IL MINUTO, SUL TABELLONE DELLA SCHEDA START

   Con la partita a tempo il punteggio da solo non basta: «2-0» al 12° e «2-0» all'88° sono
   due partite diverse, e solo la seconda ti fa alzare dalla sedia. Quando invece si gioca il
   campionato non c'è nessun orologio da mostrare, e qui non compare niente.
   --------------------------------------------------------------------------------------- */
function mtTempoHtml(){
  try{
    const c = (typeof mgCfg === 'function') ? mgCfg() : {};
    if (c.season !== 'tempo') return '';

    if (typeof koRunning === 'function' && koRunning()){
      return '<div class="mt-clock sev-rise" style="--d:.98s">'
        + '<b>' + esc(koLabel()) + '</b><small>ancora ' + koLeft() + ' min</small></div>';
    }
    return '<button type="button" class="mt-kick sev-rise" style="--d:.98s" onclick="mtKick()">'
      + '⚽ Fischia l\'inizio · ' + koDurata() + ' min</button>';
  }catch(_){ return ''; }
}

function mtKick(){
  if (typeof koStart !== 'function') return;
  koStart();
  mtPaint();
}

(function mtTempoStyle(){
  const css = [
    '.mt-kick{display:block;margin:14px auto 0;border:0;border-radius:99px;padding:12px 22px;',
      'background:rgba(255,255,255,.14);color:#fff;font:800 13.5px var(--font-body);cursor:pointer;',
      'backdrop-filter:blur(6px)}',
    '.mt-clock{display:inline-flex;align-items:baseline;gap:8px;margin:14px auto 0;padding:8px 16px;',
      'border-radius:99px;background:rgba(255,255,255,.14);backdrop-filter:blur(6px)}',
    '.mt-clock b{font:800 17px var(--font-display);color:#fff}',
    '.mt-clock small{font:600 12px var(--font-body);color:rgba(255,255,255,.72)}'
  ].join('');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* 0.9.267: la chiusura dello spazio dopo la scivolata (vedi il CSS di stScivola) */
document.addEventListener('animationend', function(e){
  if (!e || (e.animationName !== 'stScivola' && e.animationName !== 'stScivolaW')) return;
  const el = e.target; if (el && el.classList) el.classList.add('st-via');
});
