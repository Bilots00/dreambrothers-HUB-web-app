/* ===========================================================================================
   FOCUS INSIEME — una sessione di Full Focus in due, allo stesso momento

   Inviti un amico per una durata fissa. Quando accetta, il server fissa la stessa ora di fine
   per tutti e due, e ognuno fa la sua sessione sul suo telefono, con le regole normali del Full
   Focus. Alla fine ogni telefono manda solo due cose: portata a termine si'/no, e i minuti
   resistiti. La schermata dei risultati mostra tutti e due, con le reazioni e la «Rivincita».

   Niente in tempo reale: si chiede al server ogni pochi secondi finche' l'invito e' aperto.
   L'invito scade dopo dieci minuti se nessuno accetta. Non esistono notifiche push: l'invito
   viaggia nel messaggio che si condivide (WhatsApp, Telegram, quello che vuoi) con il codice, e
   chi lo riceve lo vede a schermo intero, come una chiamata in arrivo (disegno di Claude Design).
   =========================================================================================== */
const IN = { invito: null, poll: 0, sync: null, at: 0, visti: {} };
const IN_KEY = 'fl_insieme';
const IN_DURATE = [25, 45, 90];

function inLeggi(){ try{ return JSON.parse(localStorage.getItem(IN_KEY) || '{}') || {}; }catch(_){ return {}; } }
function inScrivi(o){ try{ localStorage.setItem(IN_KEY, JSON.stringify(o)); }catch(_){ } }
function inT(k, v){ return (typeof amT === 'function') ? amT('insieme.' + k, v) : k; }
function inTempo(ms){
  ms = Math.max(0, ms);
  const m = Math.floor(ms / 60000), s = Math.floor((ms % 60000) / 1000);
  return m >= 1 ? m + ' min' : s + ' s';
}
function inJs(v){ return JSON.stringify(String(v == null ? '' : v)).replace(/"/g, '&quot;'); }
function inAv(nome, seed, cls){ return (typeof frAv === 'function') ? frAv(nome, seed, cls) : '<span class="am-av ' + (cls || '') + '">' + esc(String(nome || '?').charAt(0).toUpperCase()) + '</span>'; }

/* ---------------------------------------------------------------- invitare */
function inScegli(device, nome){
  const html = '<div class="am-sheet center"><b class="am-sh-title">' + esc(inT('invita', { nome: nome || '' })) + '</b><p class="am-sh-p">' + esc(inT('sotto')) + '</p>'
    + '<small class="am-lbl">' + esc(inT('durata')) + '</small>'
    + '<div class="in-durate">' + IN_DURATE.map(function(m){ return '<button type="button" class="in-dur" onclick="inCrea(' + inJs(device) + ',' + inJs(nome) + ',' + m + ')">' + m + '<small>min</small></button>'; }).join('') + '</div>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">' + esc(inT('annulla')) + '</button></div>';
  inSheet(html);
}
function inSheet(html){
  let w = document.getElementById('inSheet');
  if (!w){ w = document.createElement('div'); w.id = 'inSheet'; w.className = 'in-sheet'; (document.getElementById('phone') || document.body).appendChild(w); w.addEventListener('click', function(e){ if (e.target === w) inSheetChiudi(); }); }
  /* 0.9.341, Andrea: "nel foglio Il ponte si attraversa decidendo non c'e' la X: ogni popover ha sempre la bolla in alto a destra
     per richiuderlo". Chi apre un foglio senza la sua X la riceve qui */
  const x = /aria-label="Chiudi"/.test(String(html)) ? '' : '<button type="button" class="in-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>';
  w.innerHTML = '<div class="in-sheet-in"><i class="in-grip"></i>' + x + html + '</div>'; w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  /* 0.9.260: la freccia "Torna in cima" restava sopra al foglio */
  document.body.classList.add('sheet-aperto');
}
function inSheetChiudi(){ document.body.classList.remove('sheet-aperto'); const w = document.getElementById('inSheet'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; }, 220); }
async function inCrea(device, nome, minuti){
  inSheetChiudi();
  try{
    const r = await frApi('POST', '/api/focuslock/social/insieme', { device: frDevice(), a: device || '', minuti: minuti });
    if (!r || !r.id) throw new Error('nessun invito');
    IN.invito = { id: r.id, codice: r.codice, minuti: minuti, con: nome || '', conDevice: device || '', scadeAt: new Date(r.scadeAt).getTime(), ruolo: 'da' };
    const o = inLeggi(); o.invito = IN.invito; inScrivi(o);
    if (typeof FR !== 'undefined' && device) FR.inviati[device] = true;
    const txt = inT('testo', { min: minuti, codice: r.codice });
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: inT('titolo') }); }catch(_){ } }
    else { try{ await navigator.clipboard.writeText(txt); }catch(_){ } }
    toast(inT('inviato', { nome: nome || 'amico', min: minuti }));
    inPollAvvia();
    if (typeof frPaint === 'function') frPaint();
  }catch(e){ toast(e && e.message ? e.message : 'Invito non creato'); }
}
async function inAnnulla(){
  const inv = IN.invito || inLeggi().invito;
  if (inv && inv.id){ try{ await frApi('POST', '/api/focuslock/social/insieme/annulla', { device: frDevice(), id: inv.id }); }catch(_){ } }
  if (inv && inv.conDevice && typeof FR !== 'undefined') delete FR.inviati[inv.conDevice];
  IN.invito = null; const o = inLeggi(); delete o.invito; inScrivi(o);
  inPollFerma();
  if (typeof frPaint === 'function') frPaint();
}
async function inAccetta(codice, id){
  try{
    const r = await frApi('POST', '/api/focuslock/social/insieme/accetta', { device: frDevice(), codice: codice || '', id: id || 0 });
    if (!r || !r.ok) throw new Error('non accettato');
    inFullChiudi();
    toast(inT('accettato', { nome: r.con || '' }));
    inAvvia({ id: r.id, minuti: r.minuti, endAt: new Date(r.endAt).getTime(), con: r.con || '', conDevice: r.conDevice || '', ruolo: 'a' });
  }catch(e){ toast(e && e.message ? e.message : 'Invito non accettato'); }
}
function inAccettaDaCampo(){ const i = document.getElementById('inCodice'); const c = i ? i.value.trim().toUpperCase() : ''; if (!c){ toast(inT('campo')); return; } inAccetta(c, 0); }

/* ---------------------------------------------------------------- l'invito ricevuto, a schermo intero */
function inFull(html, cls){
  let w = document.getElementById('inFull');
  if (!w){ w = document.createElement('div'); w.id = 'inFull'; (document.getElementById('phone') || document.body).appendChild(w); }
  w.className = 'in-full ' + (cls || '');
  w.innerHTML = html; w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function inFullChiudi(){ const w = document.getElementById('inFull'); if (!w) return; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; w.innerHTML = ''; }, 260); }
function inInvitoApri(i){
  IN.visti[i.id] = true;
  let mia = 0; try{ mia = (typeof serStreak === 'function') ? serStreak() : 0; }catch(_){ }
  inFull('<div class="in-cielo"><button type="button" class="in-x" aria-label="Chiudi" onclick="inFullChiudi()">✕</button>'
    + '<div class="in-cielo-in">' + inAv(i.con, i.conDevice, 'xl') + '<small>' + esc(inT('etichetta')) + '</small><h2>' + esc(inT('sfida', { nome: i.con || 'Un amico', min: i.minuti })) + '</h2></div>'
    + '<div class="in-nuvole"><svg viewBox="0 0 390 40" preserveAspectRatio="none"><path fill="currentColor" d="M0 40V22c30-14 60-14 90-4 30-16 70-18 105-4 35-14 75-12 105 2 30-12 60-10 90 4v20z"/></svg></div></div>'
    + '<div class="in-sotto"><div class="am-board in-punti"><div><i>⏱</i><span>' + esc(inT('punto1', { min: i.minuti })) + '</span></div><div><i>🔒</i><span>' + esc(inT('punto2')) + '</span></div><div><i>👀</i><span>' + esc(inT('punto3')) + '</span></div></div>'
    + (mia ? '<div class="in-chips"><span>🔥 ' + esc((typeof amT === 'function') ? amT('lega.tu') : 'Tu') + ' · ' + mia + '</span></div>' : '')
    + '<div class="in-spazio"></div>'
    + '<button type="button" class="am-cta" onclick="inAccetta(\'\',' + (+i.id || 0) + ')">' + esc(inT('accetta')) + '</button>'
    + '<button type="button" class="am-link" onclick="inFullChiudi()">' + esc(inT('nonOra')) + '</button></div>', 'invito');
}

/* ---------------------------------------------------------------- la sessione condivisa */
function inAvvia(s){
  const o = inLeggi(); o.attiva = s; delete o.invito; inScrivi(o);
  IN.invito = null; inPollFerma();
  try{
    const p = ffPref();
    p.minutes = Math.max(5, Math.min(typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 180, s.minuti));
    ffSavePref();
    ffOpen();
    setTimeout(async function(){
      await ffStart();
      if (FF.run){
        FF.run.endAt = s.endAt;
        FF.run.minutes = s.minuti;
        FF.run.insieme = { id: s.id, con: s.con, conDevice: s.conDevice, ruolo: s.ruolo };
        ffWrite('fl_ff_session', FF.run);
        ffTellEngine(FF.run.endAt, FF.run);
        ffPaint();
      }
    }, 250);
  }catch(_){ }
}
/** Chiamata da ffFinish: l'esito va al server e si aspetta quello dell'amico. */
async function inDopoSessione(run, ok, spentMs){
  const s = run.insieme; if (!s) return;
  const minuti = Math.round((spentMs || 0) / 60000);
  const o = inLeggi(); o.attiva = null; o.esito = { id: s.id, con: s.con, conDevice: s.conDevice, minuti: s.minuti || run.minutes, mio: { ok: !!ok, minuti: minuti }, at: Date.now() }; inScrivi(o);
  try{ await frApi('POST', '/api/focuslock/social/insieme/esito', { device: frDevice(), id: s.id, ok: !!ok, minuti: minuti }); }catch(_){ }
  setTimeout(function(){ inRisultati(); }, 1500);
}
/* la card di un partecipante nel risultato: anello, avatar, minuti */
function inCardEsito(nome, seed, es, tot, me){
  const min = es ? Math.min(tot, es.ok ? tot : (es.minuti || 0)) : 0;
  const C = 2 * Math.PI * 40, dash = (tot ? min / tot : 0) * C;
  const col = es ? (es.ok ? '#1B9E6A' : '#8B99AC') : 'rgba(0,30,68,.15)';
  const av = me ? ((typeof flAvMio === 'function' && flAvMio()) || '<span class="am-av me">Tu</span>') : inAv(nome, seed);
  const testo = !es ? '<div class="in-att">' + esc(inT('esito.attesa')) + '</div>'
    : (es.ok ? '<div class="in-min">' + esc(me ? inT('esito.resistito') : inT('esito.haResistito')) + '<br><b>' + tot + '/' + tot + ' min</b></div><span class="in-tag ok">' + esc(inT('esito.completata')) + '</span>'
             : '<div class="in-min">' + esc(inT('esito.uscito')) + '<br><b>' + esc(inT('esito.minuto', { n: es.minuti || 0 })) + '</b></div><span class="in-tag">' + esc(inT('esito.minDiFocus', { n: es.minuti || 0 })) + '</span>');
  return '<div class="in-card' + (me ? ' me' : '') + '"><div class="in-ring"><svg viewBox="0 0 88 88"><circle cx="44" cy="44" r="40" fill="none" stroke="rgba(0,30,68,.08)" stroke-width="6"/><circle cx="44" cy="44" r="40" fill="none" stroke="' + col + '" stroke-width="6" stroke-linecap="round" stroke-dasharray="' + dash.toFixed(1) + ' ' + C.toFixed(1) + '"/></svg>' + av + '</div>'
    + '<b class="in-nome">' + esc(me ? inT('esito.tu') : nome) + '</b>' + testo + '</div>';
}
async function inRisultati(){
  const o = inLeggi(); const e = o.esito; if (!e) return;
  let suo = null;
  try{
    const r = await frApi('GET', '/api/focuslock/social/insieme?device=' + encodeURIComponent(frDevice()));
    const tutti = (r.miei || []).concat(r.ricevuti || []);
    const x = tutti.filter(function(i){ return i.id === e.id; })[0];
    if (x){ suo = x.suo || null; if (x.mio && !e.mio) e.mio = x.mio; }
  }catch(_){ }
  const tot = +e.minuti || 0;
  const mioMin = e.mio ? (e.mio.ok ? tot : (e.mio.minuti || 0)) : 0;
  const suoMin = suo ? (suo.ok ? tot : (suo.minuti || 0)) : 0;
  const reaz = (typeof frReazioniHtml === 'function' && e.conDevice) ? frReazioniHtml(e.conDevice, e.con, []) : '';
  inFull('<div class="in-ris"><button type="button" class="in-x scuro" aria-label="Chiudi" onclick="inFullChiudi();inEsitoVisto()">✕</button>'
    + '<small class="in-eti">' + esc(inT('esito.etichetta', { min: tot })) + '</small><h2>' + esc(inT('esito.titolo')) + '</h2>'
    + '<div class="in-due">' + inCardEsito(inT('esito.tu'), frDevice(), e.mio, tot, true) + inCardEsito(e.con || 'Amico', e.conDevice, suo, tot, false) + '</div>'
    + (suo ? '<p class="in-tot">' + esc(inT('esito.insieme', { n: mioMin + suoMin })) + '</p>' : '')
    + (reaz ? '<div class="am-sh-lbl">' + esc(inT('esito.manda', { nome: e.con || '' })) + '</div>' + reaz : '')
    + '<div class="in-spazio"></div>'
    + (e.conDevice ? '<button type="button" class="am-cta" onclick="inFullChiudi();inEsitoVisto();inScegli(' + inJs(e.conDevice) + ',' + inJs(e.con || '') + ')">' + esc(inT('esito.rivincita')) + '</button>' : '')
    + '<button type="button" class="am-link" onclick="inFullChiudi();inEsitoVisto();if(typeof frOpen===\'function\')frOpen(\'amici\')">' + esc(inT('esito.chiudi')) + '</button></div>', 'risultato');
  if (!suo && Date.now() - (e.at || 0) < 10 * 60000) setTimeout(function(){ const w = document.getElementById('inFull'); if (w && !w.hidden && w.classList.contains('risultato')) inRisultati(); }, 8000);
}
function inEsitoVisto(){ const o = inLeggi(); delete o.esito; inScrivi(o); }

/* ---------------------------------------------------------------- lo stato per la scheda Amici */
async function inSync(){
  if (typeof frApi !== 'function') return null;
  try{
    const r = await frApi('GET', '/api/focuslock/social/insieme?device=' + encodeURIComponent(frDevice()));
    IN.sync = r; IN.at = Date.now();
    /* il mio invito e' stato accettato: si parte */
    const inv = IN.invito || inLeggi().invito;
    if (inv){
      const mio = (r.miei || []).filter(function(i){ return i.id === inv.id; })[0];
      if (mio && mio.stato === 'in corso' && !inLeggi().attiva){
        inAvvia({ id: mio.id, minuti: mio.minuti, endAt: new Date(mio.endAt).getTime(), con: mio.con || inv.con, conDevice: mio.conDevice || inv.conDevice, ruolo: 'da' });
        return r;
      }
      if (mio && mio.stato === 'scaduto'){ IN.invito = null; const o = inLeggi(); delete o.invito; inScrivi(o); inPollFerma(); toast(inT('scaduto')); if (typeof frPaint === 'function') frPaint(); }
    }
    /* un invito nuovo per me: a schermo intero, una volta sola */
    const nuovo = (r.ricevuti || []).filter(function(i){ return i.stato === 'attesa' && !IN.visti[i.id]; })[0];
    if (nuovo && !(typeof FF !== 'undefined' && FF.run) && !document.hidden) inInvitoApri(nuovo);
    return r;
  }catch(_){ return IN.sync; }
}
function inPollAvvia(){
  inPollFerma();
  const giro = async function(){
    if (!IN.invito && !inLeggi().invito){ inPollFerma(); return; }
    await inSync();
    IN.poll = setTimeout(giro, 4000);
  };
  IN.poll = setTimeout(giro, 3000);
}
function inPollFerma(){ if (IN.poll){ clearTimeout(IN.poll); IN.poll = 0; } }
/** I blocchi per la scheda Amici: il mio invito in attesa e gli inviti ricevuti. */
function inHtml(){
  const inv = IN.invito || inLeggi().invito;
  let h = '';
  if (inv && inv.scadeAt > Date.now()){
    h += '<div class="in-riga attesa"><span class="in-riga-ico">⏱</span><div><b>' + esc(inT('titolo')) + ' · ' + inv.minuti + ' min</b><small>' + esc(inT('attesa', { nome: inv.con || 'un amico', t: inTempo(inv.scadeAt - Date.now()) })) + '</small></div>'
      + '<button type="button" class="ghostmini" onclick="inAnnulla()">' + esc(inT('annulla')) + '</button></div>';
  }
  const ric = ((IN.sync && IN.sync.ricevuti) || []).filter(function(i){ return i.stato === 'attesa'; });
  ric.forEach(function(i){
    h += '<div class="in-riga ricevuto" onclick="inInvitoApri(' + inJs(JSON.stringify(i)).replace(/&quot;/g, '\\&quot;') + ')">' + inAv(i.con, i.conDevice) + '<div><b>' + esc(inT('ricevuto', { nome: i.con, min: i.minuti })) + '</b><small>' + esc(inT('scadeTra', { t: inTempo(new Date(i.scadeAt).getTime() - Date.now()) })) + '</small></div>'
      + '<button type="button" class="am-fi" onclick="event.stopPropagation();inInvitoApri(' + inJs(JSON.stringify(i)).replace(/&quot;/g, '\\&quot;') + ')">' + esc(inT('apri')) + '</button></div>';
  });
  return h;
}
/* le righe passano l'invito come JSON: si riapre da qui */
const _inInvitoApri = inInvitoApri;
inInvitoApri = function(i){ if (typeof i === 'string'){ try{ i = JSON.parse(i); }catch(_){ return; } } _inInvitoApri(i); };
function inCampoHtml(){ return ''; }
/* all'avvio: un esito da mostrare, o un invito ancora aperto */
setTimeout(function(){
  const o = inLeggi();
  if (o.invito && o.invito.scadeAt > Date.now()){ IN.invito = o.invito; inPollAvvia(); }
  else if (o.invito){ delete o.invito; inScrivi(o); }
  if (o.esito && Date.now() - (o.esito.at || 0) < 6 * 3600000 && !(typeof FF !== 'undefined' && FF.run)) setTimeout(inRisultati, 4000);
}, 5000);

(function(){
  const css = [
    '.in-sheet{position:fixed;inset:0;z-index:10050;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,19,43,.5);opacity:0;transition:opacity .22s}',
    '.in-sheet.in{opacity:1}.in-sheet[hidden]{display:none}',
    '.in-sheet-in{width:100%;max-width:480px;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:10px 20px calc(26px + env(safe-area-inset-bottom,0px));box-shadow:0 -18px 50px rgba(0,19,43,.28);transform:translateY(24px);transition:transform .3s cubic-bezier(.2,.8,.2,1)}',
    '.in-sheet.in .in-sheet-in{transform:none}body.dark .in-sheet-in{background:#141C2C}',
    /* 0.9.342, Andrea: "ti ho gia' detto 20.000 volte che il foglio del ponte deve avere la X". La X c'era, ma la regola della X dei
       fogli a tutto schermo (sotto: left 22px, top 46px) vinceva e la spingeva dietro all'immagine. Adesso la X dei fogli ha la sua regola */
    '.in-sheet-in{position:relative}.in-sheet-in > .in-x{position:absolute;left:auto;top:14px;right:14px;z-index:6;width:38px;height:38px;border:0;border-radius:50%;background:#fff;color:#001E44;box-shadow:0 2px 12px rgba(0,19,43,.25);font-size:15px;font-weight:800;display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .in-sheet-in > .in-x{background:#22345A;color:#fff}',
    '.in-grip{display:block;width:40px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 14px}',
    '.in-durate{display:flex;gap:10px;justify-content:center}',
    '.in-dur{flex:1;max-width:110px;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:18px;padding:14px 0;font:800 24px var(--font-display);color:var(--navy);cursor:pointer}',
    '.in-dur small{display:block;font:600 11px var(--font-body);color:var(--muted);margin-top:2px}.in-dur:active{background:var(--blue-soft,#E3F1FF);border-color:#0075E3}',
    'body.dark .in-dur{background:#12203A;border-color:#22345A;color:#fff}',
    /* le righe nella scheda Amici */
    '.in-riga{display:flex;align-items:center;gap:12px;padding:12px 12px;border-radius:18px;border:1.5px solid #0075E3;margin-bottom:12px;background:var(--card,#fff);cursor:pointer}body.dark .in-riga{background:#12203A}',
    '.in-riga > div{flex:1;min-width:0}.in-riga b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .in-riga b{color:#fff}',
    '.in-riga small{display:block;margin-top:2px;font:500 12px/1.4 var(--font-body);color:var(--muted)}',
    '.in-riga .ghostmini,.in-riga .am-fi{margin:0;flex:none}',
    '.in-riga-ico{width:44px;height:44px;border-radius:50%;background:var(--blue-soft,#E3F1FF);display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}',
    /* a schermo intero */
    '.in-full{position:fixed;inset:0;z-index:9150;display:flex;flex-direction:column;background:var(--bg,#F4F9FF);opacity:0;transition:opacity .26s;overflow-y:auto}',
    '.in-full.in{opacity:1}.in-full[hidden]{display:none}body.dark .in-full{background:#0B1220}',
    '.in-cielo{position:relative;flex:none;min-height:52vh;color:#fff;background:linear-gradient(180deg,rgba(2,9,38,.5),rgba(2,9,38,.74)),url(img/dream-night.jpg) center/cover no-repeat,#020926}',
    '.in-x{position:absolute;left:22px;top:calc(46px + env(safe-area-inset-top,0px));width:34px;height:34px;border:none;background:rgba(255,255,255,.16);border-radius:50%;font-size:14px;color:#fff;cursor:pointer;z-index:3}',
    '.in-x.scuro{background:rgba(0,30,68,.07);color:var(--ink)}body.dark .in-x.scuro{background:rgba(255,255,255,.12);color:#fff}',
    '.in-cielo-in{position:relative;z-index:1;text-align:center;padding:calc(100px + env(safe-area-inset-top,0px)) 28px 70px}',
    '.am-av.xl{width:104px;height:104px;font-size:42px;box-shadow:0 0 0 6px rgba(255,255,255,.18),0 0 0 18px rgba(255,255,255,.06),0 16px 40px rgba(0,0,0,.45)}',
    '.in-cielo-in small{display:block;margin-top:26px;font:700 11px var(--font-body);letter-spacing:.18em;text-transform:uppercase;color:#9EC1FF}',
    '.in-cielo-in h2{margin:10px auto 0;max-width:15em;font:800 27px/1.22 var(--font-display);font-style:italic;text-shadow:0 2px 12px rgba(0,0,0,.5);text-wrap:balance}',
    '.in-nuvole{position:absolute;left:0;right:0;bottom:-1px;line-height:0;color:var(--bg,#F4F9FF);pointer-events:none}.in-nuvole svg{display:block;width:100%;height:40px}body.dark .in-nuvole{color:#0B1220}',
    '.in-sotto{flex:1;display:flex;flex-direction:column;padding:4px 22px calc(24px + env(safe-area-inset-bottom,0px))}',
    '.in-punti{padding:6px 16px}.in-punti > div{display:flex;gap:12px;align-items:center;padding:10px 0;font:600 13px/1.4 var(--font-body);color:var(--navy)}.in-punti > div + div{border-top:1px solid var(--line)}.in-punti i{font-style:normal;font-size:18px}body.dark .in-punti > div{color:#fff}',
    '.in-chips{display:flex;justify-content:center;gap:10px;margin-top:14px}.in-chips span{background:rgba(0,30,68,.06);border-radius:99px;padding:6px 14px;font:600 12px var(--font-body);color:var(--navy)}body.dark .in-chips span{background:rgba(255,255,255,.1);color:#fff}',
    '.in-spazio{flex:1;min-height:14px}',
    /* il risultato */
    '.in-ris{position:relative;flex:1;display:flex;flex-direction:column;padding:calc(56px + env(safe-area-inset-top,0px)) 22px calc(24px + env(safe-area-inset-bottom,0px));text-align:center;background:linear-gradient(rgba(255,255,255,.55),rgba(244,249,255,.92) 55%),var(--dream)}',
    'body.dark .in-ris{background:linear-gradient(rgba(11,18,32,.6),rgba(11,18,32,.94) 55%),var(--dream)}',
    '.in-ris .in-x{left:22px;top:calc(46px + env(safe-area-inset-top,0px))}',
    '.in-eti{display:block;margin-top:36px;font:600 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}',
    '.in-ris h2{margin:8px 0 0;font:800 28px/1.15 var(--font-display);font-style:italic;color:var(--navy)}body.dark .in-ris h2{color:#fff}',
    '.in-due{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:22px}',
    '.in-card{background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:18px 10px 16px;text-align:center;box-shadow:0 10px 30px rgba(0,30,68,.08)}.in-card.me{border:2px solid #0075E3}body.dark .in-card{background:#12203A;border-color:#22345A}',
    '.in-ring{position:relative;width:88px;height:88px;margin:0 auto}.in-ring svg{position:absolute;inset:0;width:88px;height:88px;transform:rotate(-90deg)}',
    '.in-ring .am-av{position:absolute;inset:12px;width:auto;height:auto;font-size:22px}.in-ring .am-av.me{font-size:20px;box-shadow:none}',
    '.in-nome{display:block;margin-top:10px;font:700 14px var(--font-body);color:var(--navy)}body.dark .in-nome{color:#fff}',
    '.in-min{margin-top:3px;font:600 12px/1.4 var(--font-body);color:var(--muted)}.in-min b{font:800 18px var(--font-display);color:var(--navy)}body.dark .in-min b{color:#fff}',
    '.in-att{margin-top:8px;font:600 12px/1.4 var(--font-body);color:var(--faint)}',
    '.in-tag{display:inline-block;margin-top:10px;font:700 11px var(--font-body);padding:5px 10px;border-radius:99px;background:rgba(0,30,68,.07);color:var(--muted)}.in-tag.ok{background:#E2F6F2;color:#0E7C6B}',
    '.in-tot{margin:14px 0 0;font:600 12px var(--font-body);color:var(--muted)}',
    '.in-ris .am-sh-lbl{text-align:left}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
