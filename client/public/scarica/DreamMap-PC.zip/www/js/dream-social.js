/* ===========================================================================================
   SOCIAL (0.9.321, Andrea): come Duolingo per la serie di gruppo, i regali, il feed e la missione del
   mese; come SweetCase per i duelli (tre round, chi ne vince due vince la sfida).

   - LA SERIE DI GRUPPO: la scheda "Con gli amici" della serie. Fino a 5 amici. I giorni insieme sono
     quelli in cui avete tenuto la serie tutti e due da quando l'hai iniziata: il minimo fra la mia
     serie, la sua e i giorni passati. Vive sul telefono (fl_serie_gruppo).
   - I REGALI: le bolle degli amici e "Invia regali", una volta ogni 23 ore. Ogni regalo e' il dono vero
     del server (/social/dono, una pozione): l'amico lo trova nella sua scheda Social e lo apre.
   - LA MISSIONE DEL MESE: resta in vista in cima alla scheda Sfide. Il conto e' missione-mese.js.
   - I DUELLI: tre round di rompicapi (content/rompicapi.json), un rompicapo a round. Contro il Genio
     (facile, medio, difficile), un amico sullo stesso telefono, un amico o un avversario online: questi
     due giocano a turni sulle stesse domande (/social/duello sul server). Vince il round chi risponde
     giusto, a pari risposte il piu' veloce.
   - IL TORNEO: quarti, semifinale e finale, una settimana per fase, per i primi 10 della Lega Diamante.
     Lo gestisce il server (focuslockArena.ts, chiudiSettimane); qui si mostra a che punto sei.
   Prefisso dso-.
   =========================================================================================== */
const DSO = { edit: false, duelli: null, duelliAt: 0, g: null };
const DSO_GR_K = 'fl_serie_gruppo', DSO_GR_MAX = 5, DSO_REG_K = 'fl_regali_at', DSO_REG_MS = 23 * 3600000, DSO_DUE_K = 'fl_duelli', DSO_TRO_K = 'fl_duelli_trofei';

function dsoEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function dsoJs(v){ return JSON.stringify(String(v == null ? '' : v)).replace(/"/g, '&quot;'); }
function dsoLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? d : v; }catch(_){ return d; } }
function dsoScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function dsoVibra(p){ try{ if (typeof flVibra === 'function') flVibra(p); }catch(_){ } }
function dsoToast(m){ try{ if (typeof toast === 'function') toast(m); }catch(_){ } }
function dsoAmici(){ try{ return (FR.amici && FR.amici.amici) || []; }catch(_){ return []; } }
function dsoAv(nome, seed, cls){ return (typeof frAv === 'function') ? frAv(nome, seed, cls) : '<span class="am-av">' + dsoEsc(String(nome || '?').charAt(0)) + '</span>'; }
function dsoTu(cls){ const m = (typeof flAvMio === 'function') ? flAvMio(cls) : ''; if (m) return m; let n = ''; try{ n = (typeof frName === 'function' ? frName() : '') || ''; }catch(_){ } return dsoAv(n || 'Tu', 'me', 'me ' + (cls || '')); }
const DSO_PIU = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
const DSO_FIAMMA = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M12 2c1 3.5 5.5 6 5.5 11.5a5.5 5.5 0 0 1-11 0C6.500 10.500 8 9 9 7c.5 1.500 1.300 2.300 2 2.800C11.300 7.500 11 4.500 12 2z"/></svg>';
const DSO_AMICI_ICO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="4"/><path d="M2.500 20a6.500 6.500 0 0 1 13 0"/><path d="M19 8v6M16 11h6"/></svg>';

/* ---------------------------------------------------------------- la serie di gruppo */
function dsoGruppo(){ const l = dsoLeggi(DSO_GR_K, []); return Array.isArray(l) ? l : []; }
/* "Il Genio" e "Il tuo amico" dentro a una frase: "al Genio", "ha vinto il Genio" */
function dsoAl(n){ return /^Il /.test(n) ? 'al ' + n.slice(3) : 'a ' + n; }
function dsoIl(n){ return /^Il /.test(n) ? 'il ' + n.slice(3) : n; }
function dsoGiorniInsieme(v, a){
  let mio = 0; try{ mio = (typeof hdSerie === 'function') ? hdSerie() : 0; }catch(_){ }
  const lui = a ? (+a.streak || 0) : 0, passati = Math.floor((Date.now() - (v.at || 0)) / 86400000) + 1;
  return Math.max(0, Math.min(mio, lui, passati));
}
/* 0.9.343, Andrea: "quando inviti qualcuno in una serie di gruppo deve poter accettare, come su Duolingo". L'invito parte dal server
   (focuslockArena.ts, /social/serie-gruppo); la serie comincia quando l'amico accetta. Qui sotto resta la copia sul telefono
   (fl_serie_gruppo: { d, at, stato: 'attiva' | 'inviato', nome }), aggiornata da dsoGruppoSync. */
const DSO_SG = { ricevute: [], at: 0, p: null };
function dsoAmicoDi(v){ return dsoAmici().filter(function(x){ return x.device === v.d; })[0] || { nome: v.nome || 'Il tuo amico', device: v.d, streak: 0 }; }
function dsoGruppoAttive(){ return dsoGruppo().filter(function(v){ return v.stato === 'attiva'; }); }
function dsoGruppoSync(forza){
  if (DSO_SG.p) return DSO_SG.p;
  if (!forza && Date.now() - DSO_SG.at < 60000) return null;
  if (typeof frApi !== 'function' || typeof frDevice !== 'function' || !frDevice()) return null;
  DSO_SG.at = Date.now();
  DSO_SG.p = (async function(){
    try{
      /* le serie aggiunte prima della 0.9.343, senza chiedere niente all'amico, diventano inviti veri */
      for (const v of dsoGruppo().filter(function(x){ return !x.stato; })){ try{ await frApi('POST', '/api/focuslock/social/serie-gruppo/invita', { device: frDevice(), a: v.d }); }catch(_){ } }
      const r = await frApi('GET', '/api/focuslock/social/serie-gruppo?device=' + encodeURIComponent(frDevice()));
      if (r && Array.isArray(r.attive)){
        const l = r.attive.map(function(x){ return { d: x.device, at: Date.parse(x.at) || Date.now(), stato: 'attiva', nome: x.nome }; })
          .concat((r.inviate || []).map(function(x){ return { d: x.device, at: Date.parse(x.at) || Date.now(), stato: 'inviato', nome: x.nome }; }));
        const prima = JSON.stringify(dsoGruppo()) + JSON.stringify(DSO_SG.ricevute);
        dsoScrivi(DSO_GR_K, l); DSO_SG.ricevute = Array.isArray(r.ricevute) ? r.ricevute : [];
        if (prima !== JSON.stringify(l) + JSON.stringify(DSO_SG.ricevute)){ try{ if (document.querySelector('.dso-gr-l, .dso-gr-vuoto') && typeof hdSeriePaint === 'function') hdSeriePaint(); }catch(_){ } }
        dsoInvitiAvvisa();
      }
    }catch(_){ } finally { DSO_SG.p = null; }
  })();
  return DSO_SG.p;
}
/* un invito nuovo si annuncia una volta, mai nei momenti sacri */
function dsoInvitiAvvisa(){
  try{
    if (typeof spZitto === 'function' && spZitto()) return;
    const visti = dsoLeggi('fl_sg_avvisati', []); const nuovi = DSO_SG.ricevute.filter(function(x){ return visti.indexOf(x.id) < 0; });
    if (!nuovi.length) return;
    dsoScrivi('fl_sg_avvisati', visti.concat(nuovi.map(function(x){ return x.id; })).slice(-50));
    dsoToast(nuovi.length === 1 ? nuovi[0].nome + ' vuole iniziare una serie di gruppo con te. La trovi nella tua serie, in Con gli amici.' : nuovi.length + ' amici vogliono iniziare una serie di gruppo con te.');
  }catch(_){ }
}
async function dsoGruppoRispondi(id, si){
  dsoVibra(si ? [12, 40, 12] : 10);
  try{
    const r = await frApi('POST', '/api/focuslock/social/serie-gruppo/rispondi', { device: frDevice(), id: id, si: !!si });
    const x = DSO_SG.ricevute.filter(function(v){ return v.id === id; })[0];
    if (r && r.ok && si && x) dsoToast('Serie di gruppo iniziata con ' + x.nome + '!');
  }catch(e){ dsoToast(String((e && e.message) || 'Non riesco a rispondere: riprova fra un attimo')); }
  DSO_SG.ricevute = DSO_SG.ricevute.filter(function(v){ return v.id !== id; });
  await dsoGruppoSync(true);
  try{ if (typeof hdSeriePaint === 'function') hdSeriePaint(); }catch(_){ }
}
setTimeout(function(){ try{ dsoGruppoSync(true); }catch(_){ } }, 6000);
function dsoGruppoHtml(){
  try{ dsoGruppoSync(false); }catch(_){ }
  const amici = dsoAmici(), gr = dsoGruppo().filter(function(v){ return v.stato || amici.some(function(a){ return a.device === v.d; }); });
  const ric = DSO_SG.ricevute || [];
  const ricHtml = ric.length ? '<div class="dso-gr-inv"><p>Inviti per te</p>' + ric.map(function(x){
      return '<div class="dso-gr-r">' + dsoAv(x.nome, x.device) + '<div class="dso-gr-n"><b>' + dsoEsc(x.nome) + '</b><small>Vuole fare la serie con te</small></div>'
        + '<button type="button" class="dso-gr-si" onclick="dsoGruppoRispondi(' + (+x.id) + ',true)">Accetta</button><button type="button" class="dso-gr-no" aria-label="Rifiuta" onclick="dsoGruppoRispondi(' + (+x.id) + ',false)">✕</button></div>';
    }).join('') + '</div>' : '';
  if (!gr.length){
    /* come Duolingo: un'illustrazione, una frase, un pulsante */
    return ricHtml + '<div class="dso-gr-vuoto"><div class="dso-gr-art"><img src="img/genio/genio-saluta.png" alt=""><span class="dso-gr-fuoco">🔥</span></div>'
      + '<h2>Inizia una <b>Serie di gruppo</b> per fare progressi ogni giorno insieme!</h2>'
      + '<button type="button" class="dso-cta" onclick="dsoGruppoInvita()">' + DSO_AMICI_ICO + '<span>Aggiungi amici</span></button></div>';
  }
  let righe = '';
  gr.forEach(function(v){
    const a = dsoAmicoDi(v), g = dsoGiorniInsieme(v, a), attesa = v.stato === 'inviato';
    righe += '<div class="dso-gr-r' + (attesa ? ' attesa' : '') + '">' + dsoAv(a.nome, a.device) + '<div class="dso-gr-n"><b>' + dsoEsc(a.nome) + '</b>'
      + (attesa ? '<small class="dso-gr-att">In attesa che accetti</small>' : '<small class="' + (g > 0 ? 'on' : '') + '">' + DSO_FIAMMA + g + '</small>') + '</div>'
      + (DSO.edit ? '<button type="button" class="dso-gr-via" onclick="dsoGruppoTermina(' + dsoJs(v.d) + ')">' + (attesa ? 'Annulla' : 'Termina') + '</button>' : '') + '</div>';
  });
  righe = ricHtml.replace('<div class="dso-gr-inv">', '<div class="dso-gr-inv dentro">') + righe;
  for (let i = gr.length; i < DSO_GR_MAX; i++) righe += '<button type="button" class="dso-gr-r piu" onclick="dsoGruppoInvita()"><span class="dso-gr-piu">' + DSO_PIU + '</span><b>Invita un amico</b></button>';
  return '<div class="dso-gr-hero"><img src="img/genio/genio-rivela.png" alt=""><span class="dso-gr-fuoco">🔥</span></div>'
    + '<div class="dso-gr-testa"><h3>Serie di gruppo</h3><button type="button" onclick="DSO.edit=!DSO.edit;dsoVibra(8);hdSeriePaint()">' + (DSO.edit ? 'Fatto' : 'Modifica') + '</button></div>'
    + '<div class="dso-gr-l">' + righe + '</div>';
}
function dsoGruppoInvita(){
  const dentro = dsoGruppo().map(function(v){ return v.d; }), l = dsoAmici().filter(function(a){ return dentro.indexOf(a.device) < 0; });
  if (!l.length){
    try{ if (typeof hdSerieChiudi === 'function') hdSerieChiudi(); if (typeof frAggiungiApri === 'function') frAggiungiApri('start'); }catch(_){ }
    return;
  }
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><b class="am-sh-title">Con chi vuoi iniziare?</b><div class="dso-sc-l">'
    + l.map(function(a){ return '<button type="button" onclick="dsoGruppoAggiungi(' + dsoJs(a.device) + ')">' + dsoAv(a.nome, a.device) + '<b>' + dsoEsc(a.nome) + '</b><small>' + DSO_FIAMMA + (+a.streak || 0) + '</small></button>'; }).join('')
    + '</div></div>');
}
async function dsoGruppoAggiungi(d){
  const g = dsoGruppo(); if (g.length >= DSO_GR_MAX) return;
  const a = dsoAmici().filter(function(x){ return x.device === d; })[0], nome = a ? a.nome : 'il tuo amico';
  dsoVibra([12, 40, 12]);
  try{ inSheetChiudi(); }catch(_){ }
  try{
    const r = await frApi('POST', '/api/focuslock/social/serie-gruppo/invita', { device: frDevice(), a: d });
    if (!g.some(function(v){ return v.d === d; })) g.push({ d: d, at: Date.now(), stato: r && r.stato === 'attiva' ? 'attiva' : 'inviato', nome: nome });
    dsoScrivi(DSO_GR_K, g);
    dsoToast(r && r.stato === 'attiva' ? 'Serie di gruppo iniziata con ' + nome + '!' : 'Invito mandato a ' + nome + '. La serie parte quando accetta.');
  }catch(e){ dsoToast(String((e && e.message) || 'L’invito non è partito: riprova fra un attimo')); }
  try{ if (typeof hdSeriePaint === 'function') hdSeriePaint(); }catch(_){ }
  dsoGruppoSync(true);
}
/* come Duolingo: si conferma, e "No, grazie" torna indietro senza cambiare niente */
function dsoGruppoTermina(d){
  const a = dsoAmici().filter(function(x){ return x.device === d; })[0], v = dsoGruppo().filter(function(x){ return x.d === d; })[0];
  const g = v ? dsoGiorniInsieme(v, a) : 0, nome = a ? a.nome : 'questo amico';
  inSheet('<div class="am-sheet center dso-fine"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="dso-fine-ico">🔥</span>'
    + '<b class="am-sh-title">Vuoi terminare la serie di gruppo con ' + dsoEsc(nome) + '?</b>'
    + (g > 0 ? '<p class="am-sh-p">' + (g === 1 ? 'Il giorno che avete fatto insieme si perde.' : 'I ' + g + ' giorni che avete fatto insieme si perdono.') + '</p>' : '')
    + '<button type="button" class="dso-cta rosso" onclick="dsoGruppoToglie(' + dsoJs(d) + ')">Termina la serie</button>'
    + '<button type="button" class="am-link" onclick="inSheetChiudi()">No, grazie</button></div>');
}
function dsoGruppoToglie(d){
  try{ if (typeof frApi === 'function') frApi('POST', '/api/focuslock/social/serie-gruppo/termina', { device: frDevice(), a: d }).catch(function(){ }); }catch(_){ }
  dsoScrivi(DSO_GR_K, dsoGruppo().filter(function(v){ return v.d !== d; }));
  DSO.edit = false; dsoVibra(14);
  try{ inSheetChiudi(); }catch(_){ }
  try{ if (typeof hdSeriePaint === 'function') hdSeriePaint(); }catch(_){ }
}

/* ---------------------------------------------------------------- le protezioni della serie */
function dsoProtMax(){ return (typeof GR_MAX === 'number') ? GR_MAX : 2; }
function dsoProtezioneHtml(){
  let g = 0; try{ g = snStato().serie.gettoni || 0; }catch(_){ }
  const max = dsoProtMax();
  return '<div class="hd-ser-card dso-prot"><span aria-hidden="true">🧊</span><div><p><b>' + g + '/' + max + '</b> protezioni della serie rimaste</p>'
    + '<button type="button" class="hd-ser-cta" onclick="try{hdSerieChiudi()}catch(_){};if(typeof ngApri===\'function\')ngApri()">Ricarica</button></div>'
    + '<button type="button" class="dso-prot-i" onclick="dsoProtezioneInfo()" aria-label="Come funzionano le protezioni">i</button></div>';
}
function dsoProtezioneInfo(){
  let g = 0; try{ g = snStato().serie.gettoni || 0; }catch(_){ }
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Proteggi la tua serie</h3>'
    + '<p class="sp-count' + (g ? '' : ' zero') + '" style="text-align:center">' + (g ? 'Ne hai ' + g + ' su ' + dsoProtMax() : 'Le hai usate tutte') + '</p>'
    + flInfoRighe([
        ['🧊', 'Copre un giorno saltato', 'Un giorno senza tappe non spezza la serie. Due di fila sì.'],
        ['🤖', 'Scatta da sola', 'Non devi ricordarti niente: se salti un giorno, la usa l’app.'],
        ['🔥', 'Come se ne guadagna una', 'Facendo la tappa: al secondo giorno di fila, al quarto, poi ogni cinque.']
      ])
    + '<button type="button" class="en-cta" onclick="inSheetChiudi()">Ho capito</button></div>');
}

/* ---------------------------------------------------------------- i regali, nelle bolle */
function dsoRegaloResta(){ const t = +localStorage.getItem(DSO_REG_K) || 0; return Math.max(0, t + DSO_REG_MS - Date.now()); }
function dsoRegaliHtml(){
  const l = dsoAmici(), resta = dsoRegaloResta();
  let bolle = l.map(function(a){ return '<button type="button" class="dso-bolla" data-dev="' + dsoEsc(a.device) + '" onclick="frScheda(' + dsoJs(a.device) + ')" aria-label="' + dsoEsc(a.nome) + '">' + dsoAv(a.nome, a.device, 'grande') + '</button>'; }).join('');
  for (let i = l.length; i < 5; i++) bolle += '<button type="button" class="dso-bolla vuota" onclick="frAggiungiApri(\'amici\')" aria-label="Aggiungi un amico">' + DSO_PIU + '</button>';
  const ore = Math.max(1, Math.ceil(resta / 3600000));
  return '<div class="dso-bolle" id="dsoBolle">' + bolle + '</div>'
    + (l.length ? '<button type="button" class="dso-reg' + (resta ? ' spento' : '') + '" id="dsoReg" ' + (resta ? 'disabled' : '') + ' onclick="dsoRegaliManda(this)"><span aria-hidden="true">🎁</span>' + (resta ? 'Invia di nuovo regali tra ' + ore + 'h' : 'Invia regali ai tuoi amici') + '</button>' : '');
}
async function dsoRegaliManda(btn){
  if (dsoRegaloResta() > 0) return;
  const l = dsoAmici();
  if (!l.length) return;
  try{ localStorage.setItem(DSO_REG_K, String(Date.now())); }catch(_){ }
  dsoVibra([12, 50, 12]);
  try{ if (typeof muJingle === 'function') muJingle('moneta'); }catch(_){ }
  /* le luci partono dal pulsante e arrivano alle bolle, una dopo l'altra */
  const q = btn.getBoundingClientRect(), bolle = document.querySelectorAll('#dsoBolle .dso-bolla:not(.vuota)');
  Array.prototype.forEach.call(bolle, function(b, i){
    const r = b.getBoundingClientRect(), o = document.createElement('i');
    o.className = 'dso-luce'; o.style.left = (q.left + q.width / 2 - 9) + 'px'; o.style.top = (q.top - 4) + 'px';
    document.body.appendChild(o);
    const dx = r.left + r.width / 2 - (q.left + q.width / 2), dy = r.top + r.height / 2 - q.top;
    const an = o.animate([{ transform: 'translate(0,0) scale(.5)', opacity: 0 }, { transform: 'translate(' + dx * .4 + 'px,' + (dy - 26) + 'px) scale(1.2)', opacity: 1, offset: .55 }, { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(.5)', opacity: 0 }], { duration: 800, delay: i * 130, easing: 'cubic-bezier(.3,.7,.4,1)', fill: 'both' });
    an.onfinish = function(){ o.remove(); b.classList.add('presa'); setTimeout(function(){ b.classList.remove('presa'); }, 500); };
  });
  btn.disabled = true; btn.classList.add('spento');
  btn.innerHTML = '<span aria-hidden="true">🎁</span>Invia di nuovo regali tra 23h';
  /* il dono vero: uno per amico, chi l'ha gia' avuto oggi lo dice il server. Gli amici simulati dell'anteprima non passano dal server */
  for (let i = 0; i < l.length; i++){
    const a = l[i]; if (a.bot || a.donoOggi) continue;
    try{ const r = await frApi('POST', '/api/focuslock/social/dono', { device: frDevice(), a: a.device, tipo: 'pozione' }); if (r && r.ok) a.donoOggi = true; }catch(_){ }
  }
}
/* il feed vero, per chi ha amici veri: le stesse voci che prima stavano nella serie */
function dsoFeedHtml(){
  const feed = (typeof hdFeedHtml === 'function') ? hdFeedHtml() : '';
  return '<div class="am-sect"><b>Feed</b></div>' + dsoRegaliHtml() + (feed ? '<div class="dso-feed">' + feed + '</div>' : (dsoAmici().length ? '<p class="am-hint">I traguardi dei tuoi amici compaiono qui appena arrivano.</p>' : ''));
}

/* ---------------------------------------------------------------- la missione del mese, sempre in vista */
function dsoMeseHtml(){
  try{
    if (typeof mdmDati !== 'function') return '';
    const d = mdmDati(), oggi = new Date();
    const restano = new Date(oggi.getFullYear(), oggi.getMonth() + 1, 0).getDate() - oggi.getDate() + 1;
    const pct = Math.round(d.n / d.tot * 100), tocca = d.fatta && !d.presa;
    return '<div class="dso-mese' + (tocca ? ' tocca' : '') + '"' + (tocca ? ' role="button" onclick="mdmApri()"' : '') + '>'
      + '<div class="dso-mese-top"><div><b>Missione di ' + dsoEsc(d.mese) + '</b><small>⏱ ' + (restano === 1 ? 'ULTIMO GIORNO' : restano + ' GIORNI') + '</small></div><img src="img/genio/genio-rivela.png" alt=""></div>'
      + '<div class="dso-mese-c"><p>' + (d.presa ? 'Completata: la prossima arriva il mese dopo' : (tocca ? 'Completata: tocca per aprire la mystery box' : 'Completa ' + d.tot + ' tappe della mappa')) + '</p>'
      + '<div class="dso-mese-bar"><i style="width:' + pct + '%"></i><span>' + d.n + '/' + d.tot + '</span></div></div></div>';
  }catch(_){ return ''; }
}

/* ---------------------------------------------------------------- il torneo */
const DSO_FASI = [['quarti', 'Quarti'], ['semi', 'Semifinale'], ['finale', 'Finale']];
/* 0.9.322, Andrea: "il torneo non sotto alla lega: la seconda slide del pannello". Stessa testata della prima slide */
function dsoTorneoHtml(L){
  const t = (L && L.torneo) || {}, fase = t.fase || '', i = DSO_FASI.map(function(x){ return x[0]; }).indexOf(fase);
  const sotto = fase === 'finale' ? 'I primi 3 vincono il torneo'
    : fase ? 'I primi 10 passano alla fase dopo'
    : (L && L.tier === 'diamante') ? 'Finisci fra i primi 10 per entrare' : 'Si entra dalla Lega Diamante';
  return '<div class="am-lg-top"><div><b>Torneo Diamante</b><small>' + dsoEsc(sotto) + '</small></div><button type="button" class="am-lg-i" onclick="dsoTorneoInfo()" aria-label="Come funziona il torneo">i</button></div>'
    + '<div class="dso-tor-art">' + ((typeof frCoppa === 'function') ? frCoppa('diamante') : '') + '</div>'
    + '<div class="dso-tor-f">' + DSO_FASI.map(function(x, k){ return '<span class="' + (k === i ? 'ora' : (k < i ? 'fatta' : '')) + '">' + x[1] + '</span>'; }).join('') + '</div>'
    + (t.vinti ? '<p class="dso-tor-v">' + (t.vinti === 1 ? 'Hai vinto 1 torneo' : 'Hai vinto ' + t.vinti + ' tornei') + '</p>' : '');
}
function dsoTorneoInfo(){
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Come funziona il torneo</h3>'
    + flInfoRighe([
        ['🎟️', 'Per entrare', 'Finisci una settimana fra i primi 10 della Lega Diamante.'],
        ['⚔️', 'Quarti e semifinale', 'Una settimana a fase: passano i primi 10.'],
        ['🏆', 'Finale', 'Una settimana sola: i primi 3 vincono il torneo.'],
        ['🛡️', 'Se esci', 'Torni nella Lega Diamante, senza perdere niente.']
      ]) + '</div>');
}

/* ---------------------------------------------------------------- i duelli */
/* 0.9.322, Andrea: "i problemi di matematica fanno schifo: deve farti sentire preparato, vince chi e' piu' ferrato nel suo settore".
   Le domande stanno in content/duelli.json: quelle generali sulla crescita e quelle del settore di chi lancia la sfida. Il settore sta
   dentro al seed: chi risponde riceve le stesse domande, nello stesso ordine, senza che il server debba saperne niente. */
let DSO_ENIGMI = null;
const DSO_CAT = ['generali', 'imprenditori', 'studenti', 'lavoratori', 'creator', 'sportivi'];
async function dsoEnigmi(){
  if (DSO_ENIGMI) return DSO_ENIGMI;
  try{ DSO_ENIGMI = await (await fetch('content/duelli.json')).json(); }catch(_){ return {}; }
  return DSO_ENIGMI;
}
function dsoSeed(generali){
  let c = 0;
  if (!generali){ try{ c = Math.max(0, DSO_CAT.indexOf(frCategoria() || frCategoriaSuggerita())); }catch(_){ } }
  return Math.floor(Math.random() * 300000000) * DSO_CAT.length + c;
}
/* le stesse tre domande per tutti e due, dal seed: due del settore e una generale; le risposte mescolate allo stesso modo */
function dsoTre(banca, seed){
  let x = Math.abs(seed | 0) || 1;
  const caso = function(n){ x = (x * 1664525 + 1013904223) >>> 0; return (x >>> 8) % n; };
  const pesca = function(l, quante, out){ const dove = l.slice(); while (quante-- > 0 && dove.length) out.push(dove.splice(caso(dove.length), 1)[0]); return out; };
  const sett = banca[DSO_CAT[Math.abs(seed) % DSO_CAT.length]] || [], gen = banca.generali || [];
  const l = (sett !== gen && sett.length >= 2) ? pesca(gen, 1, pesca(sett, 2, [])) : pesca(gen, 3, []);
  return l.map(function(q){
    const o = q.o.slice();
    for (let i = o.length - 1; i > 0; i--){ const j = caso(i + 1), t = o[i]; o[i] = o[j]; o[j] = t; }
    return { domanda: q.d, opzioni: o, risposta_corretta: q.o[0], effetto_eureka: q.e };
  });
}
const DSO_BOT = { facile: { n: 'Il Genio, facile', ok: .5, a: 9000, b: 24000 }, medio: { n: 'Il Genio, medio', ok: .72, a: 6000, b: 18000 }, difficile: { n: 'Il Genio, difficile', ok: .9, a: 4000, b: 12000 } };
function dsoBotRound(k){ const b = DSO_BOT[k] || DSO_BOT.medio; return { ok: Math.random() < b.ok, ms: Math.round(b.a + Math.random() * (b.b - b.a)) }; }
function dsoVinceRound(a, b){ if (!a || !b) return 0; if (a.ok && !b.ok) return 1; if (b.ok && !a.ok) return -1; if (!a.ok && !b.ok) return 0; return a.ms === b.ms ? 0 : (a.ms < b.ms ? 1 : -1); }
function dsoConto(mie, sue){
  let io = 0, lui = 0;
  (mie || []).forEach(function(r, i){ const v = dsoVinceRound(r, (sue || [])[i]); if (v > 0) io++; else if (v < 0) lui++; });
  let esito = io > lui ? 'vittoria' : (io < lui ? 'sconfitta' : 'pari');
  /* a pari round vince chi ci ha messo meno in tutto, se ha risposto giusto almeno una volta */
  if (esito === 'pari' && io > 0){ const t = function(l){ return (l || []).reduce(function(s, r){ return s + (r.ok ? r.ms : 30000); }, 0); }; const a = t(mie), b = t(sue); if (a !== b) esito = a < b ? 'vittoria' : 'sconfitta'; }
  return { io: io, lui: lui, esito: esito };
}
function dsoTrofei(){ return +localStorage.getItem(DSO_TRO_K) || 0; }
function dsoRegistra(v){
  const l = dsoLeggi(DSO_DUE_K, []); l.unshift(v); dsoScrivi(DSO_DUE_K, l.slice(0, 40));
  const d = v.esito === 'vittoria' ? 30 : (v.esito === 'sconfitta' ? -15 : 5);
  try{ localStorage.setItem(DSO_TRO_K, String(Math.max(0, dsoTrofei() + d))); }catch(_){ }
  if (v.esito === 'vittoria'){ try{ if (typeof ffAddCoins === 'function') ffAddCoins(20); }catch(_){ } }
}
async function dsoDuelliCarica(){
  if (Date.now() - DSO.duelliAt < 30000) return;
  DSO.duelliAt = Date.now();
  try{
    const r = await frApi('GET', '/api/focuslock/social/duello?device=' + encodeURIComponent(frDevice()));
    if (r && r.duelli){ DSO.duelli = r.duelli; if (typeof FR !== 'undefined' && FR.tab === 'sfide' && typeof frPaint === 'function') frPaint(); }
  }catch(_){ }
}
/* il registro, da questo telefono e dal server */
function dsoRegistro(){
  const out = dsoLeggi(DSO_DUE_K, []).map(function(v){ return Object.assign({ locale: true }, v); });
  (DSO.duelli || []).forEach(function(d){
    if (d.stato !== 'fatto' || !d.mieiRound || !d.suoiRound) return;
    const c = dsoConto(d.mieiRound, d.suoiRound);
    out.push({ nome: d.nome || 'Giocatore', seed: d.altro, io: c.io, lui: c.lui, esito: c.esito, at: Date.parse(d.at) || 0, rivale: d.altro, modo: 'amico' });
  });
  out.sort(function(a, b){ return (b.at || 0) - (a.at || 0); });
  return out.slice(0, 14);
}
function dsoStelle(n){ let h = ''; for (let i = 0; i < 2; i++) h += '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true" class="' + (i < n ? 'on' : '') + '"><path fill="currentColor" d="M12 2.500l2.900 6 6.600.900-4.800 4.600 1.200 6.500L12 17.400l-5.900 3.100 1.200-6.500L2.500 9.400l6.600-.900z"/></svg>'; return h; }
function dsoDuelliHtml(){
  setTimeout(dsoDuelliCarica, 0);
  const daGiocare = (DSO.duelli || []).filter(function(d){ return d.stato === 'aperto' && !d.mio; });
  const inAttesa = (DSO.duelli || []).filter(function(d){ return d.stato === 'aperto' && d.mio; });
  const reg = dsoRegistro();
  let h = '<div class="am-sect"><b>Duelli</b><span>🏆 ' + dsoTrofei() + '</span></div>'
    + '<div class="dso-arena"><div class="dso-ar-vs">' + dsoTu('grande') + '<b>VS</b><span class="am-av grande dso-ar-q">?</span></div>'
    + '<p>Tre domande sul tuo settore e su come si cresce: vince chi ne sa di più.</p>'
    + '<div class="or-grid quattro dso-ar-g">'
    + '<button type="button" class="dso-mo" onclick="dsoScegliAmico()"><span aria-hidden="true">🤝</span>Sfida un amico<small>Da un telefono all’altro</small></button>'
    + '<button type="button" class="dso-mo" onclick="dsoACaso()"><span aria-hidden="true">🌍</span>Online<small>Un sognatore da tutto il mondo</small></button>'
    + '<button type="button" class="dso-mo" onclick="dsoScegliBot()"><span aria-hidden="true">🧞</span>Contro il Genio<small>Contro il computer</small></button>'
    + '<button type="button" class="dso-mo" onclick="dsoParti({ modo: \'telefono\', nome: \'Il tuo amico\' })"><span aria-hidden="true">📱</span>Sullo stesso telefono<small>In due, a turno</small></button>'
    + '</div></div>';
  if (daGiocare.length) h += '<div class="dso-col">' + daGiocare.map(function(d){ return '<div class="dso-att su">' + dsoAv(d.nome, d.altro) + '<div><b>' + dsoEsc(d.nome) + '</b><small>Ti ha sfidato</small></div><button type="button" onclick="dsoParti({ modo: \'risposta\', id: ' + (+d.id) + ', seed: ' + (+d.seed) + ', nome: ' + dsoJs(d.nome) + ', rivale: ' + dsoJs(d.altro) + ', suoi: ' + dsoJs(JSON.stringify(d.suoiRound || [])) + ' })">Gioca</button></div>'; }).join('') + '</div>';
  if (inAttesa.length) h += '<div class="dso-col">' + inAttesa.slice(0, 4).map(function(d){ return '<div class="dso-att">' + (d.altro ? dsoAv(d.nome, d.altro) : '<span class="am-av dso-ar-q">?</span>') + '<div><b>' + dsoEsc(d.altro ? d.nome : 'Avversario online') + '</b><small>' + (d.altro ? 'Deve ancora giocare' : 'Stai aspettando un avversario') + '</small></div></div>'; }).join('') + '</div>';
  h += '<div class="am-sect"><b>Registro delle partite</b></div>';
  if (!reg.length) return h + '<p class="am-hint">Il primo duello finisce qui, con il suo risultato.</p>';
  return h + '<div class="dso-reg-l">' + reg.map(function(v){
    const rivi = v.modo === 'bot' ? "dsoParti({ modo: 'bot', livello: " + dsoJs(v.livello) + ", nome: " + dsoJs(v.nome) + " })" : v.modo === 'telefono' ? "dsoParti({ modo: 'telefono', nome: " + dsoJs(v.nome) + " })" : (v.rivale ? "dsoParti({ modo: 'amico', rivale: " + dsoJs(v.rivale) + ", nome: " + dsoJs(v.nome) + " })" : '');
    return '<div class="dso-reg-r ' + v.esito + '"><i class="dso-reg-b"></i><div class="dso-reg-s"><span>' + dsoStelle(v.io) + '</span><b>' + v.io + ' - ' + v.lui + '</b><span>' + dsoStelle(v.lui) + '</span></div>'
      + '<div class="dso-reg-n"><b>' + (v.esito === 'vittoria' ? 'Vittoria' : v.esito === 'sconfitta' ? 'Sconfitta' : 'Pareggio') + '</b><small>contro ' + dsoEsc(dsoIl(v.nome)) + (v.at ? ' · ' + new Date(v.at).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }) : '') + '</small></div>'
      + (rivi ? '<button type="button" onclick="' + rivi + '">Rivincita</button>' : '') + '</div>';
  }).join('') + '</div>';
}
function dsoScegliBot(){
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><b class="am-sh-title">Quanto forte lo vuoi?</b><p class="am-sh-p">Se perde, il Genio non si offende.</p><div class="dso-sc-l">'
    + [['facile', 'Facile', '🌱'], ['medio', 'Medio', '🔥'], ['difficile', 'Difficile', '⚡']].map(function(x){ return '<button type="button" onclick="inSheetChiudi();dsoParti({ modo: \'bot\', livello: \'' + x[0] + '\', nome: ' + dsoJs(DSO_BOT[x[0]].n) + ' })"><span class="dso-sc-e">' + x[2] + '</span><b>' + x[1] + '</b></button>'; }).join('')
    + '</div></div>');
}
function dsoScegliAmico(){
  const l = dsoAmici();
  if (!l.length){ try{ frAggiungiApri('amici'); }catch(_){ } return; }
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><b class="am-sh-title">Chi vuoi sfidare?</b><p class="am-sh-p">Giochi adesso. Lui risponde quando può, sulle stesse domande.</p><div class="dso-sc-l">'
    + l.map(function(a){ return '<button type="button" onclick="inSheetChiudi();dsoParti({ modo: \'amico\', rivale: ' + dsoJs(a.device) + ', nome: ' + dsoJs(a.nome) + ', bot: ' + (a.bot ? 'true' : 'false') + ' })">' + dsoAv(a.nome, a.device) + '<b>' + dsoEsc(a.nome) + '</b></button>'; }).join('')
    + '</div></div>');
}
async function dsoACaso(){
  dsoVibra(10);
  try{
    const r = await frApi('GET', '/api/focuslock/social/duello/trova?device=' + encodeURIComponent(frDevice()));
    if (r && r.duello){ dsoParti({ modo: 'risposta', id: r.duello.id, seed: r.duello.seed, nome: r.duello.nome, rivale: r.duello.altro, suoi: null }); return; }
    dsoParti({ modo: 'caso', nome: 'Avversario online', seed: dsoSeed(true) });
  }catch(_){ dsoToast('Serve la rete per trovare un avversario'); }
}

/* --- la partita --- */
function dsoAperto(){ return !!document.getElementById('dsoG'); }
async function dsoParti(o){
  const banca = await dsoEnigmi();
  const seed = o.seed || dsoSeed();
  const tre = dsoTre(banca, seed);
  if (tre.length < 3){ dsoToast('Le domande non si sono caricate: riprova'); return; }
  DSO.g = { o: o, seed: seed, tre: tre, i: 0, mie: [], sue: o.suoi ? (function(){ try{ return JSON.parse(o.suoi); }catch(_){ return null; } })() : null, seconde: [], turno: 1, t0: 0, tm: 0 };
  if (o.modo === 'bot' || o.bot) DSO.g.sue = [dsoBotRound(o.livello), dsoBotRound(o.livello), dsoBotRound(o.livello)];
  if (o.modo === 'telefono') DSO.g.sue = [];
  let w = document.getElementById('dsoG');
  if (!w){ w = document.createElement('div'); w.id = 'dsoG'; (document.getElementById('phone') || document.body).appendChild(w); }
  dsoVibra(14);
  dsoIntro();
}
function dsoTesta(){
  const g = DSO.g, pip = function(l, altra){ let h = ''; for (let k = 0; k < 3; k++){ const v = k < l.length ? dsoVinceRound(l[k], (altra || [])[k]) : null; h += '<i class="' + (v === null || !altra || k >= altra.length ? '' : v > 0 ? 'v' : v < 0 ? 'p' : 'x') + '"></i>'; } return h; };
  const mostra = g.o.modo === 'bot' || g.o.bot || (g.sue && g.o.modo === 'risposta' && g.sue.length);
  const sue = g.o.modo === 'telefono' ? g.sue : (mostra ? (g.sue || []).slice(0, g.mie.length) : null);
  return '<div class="dso-g-top"><button type="button" class="dso-g-x" aria-label="Esci dal duello" onclick="dsoEsciChiedi()">✕</button>'
    + '<div class="dso-g-pl">' + dsoTu() + '<div class="dso-pip">' + pip(g.mie, sue) + '</div></div><div class="dso-g-m"><small>Round ' + Math.min(3, g.i + 1) + ' di 3</small><button type="button" class="dso-g-so" id="dsoSo" onclick="dsoSuonoTocca()" aria-label="La musica del duello">' + dsoSuonoIco() + '</button></div>'
    + '<div class="dso-g-pl dx"><div class="dso-pip">' + (sue ? pip(sue, g.mie) : '<i></i><i></i><i></i>') + '</div>' + dsoAv(g.o.nome, g.o.rivale || g.o.nome) + '</div></div>';
}
function dsoIntro(){
  const w = document.getElementById('dsoG'), g = DSO.g; if (!w) return;
  w.innerHTML = '<div class="dso-g dso-g-in"><div class="dso-g-vs">' + dsoTu('grande') + '<b>VS</b>' + dsoAv(g.o.nome, g.o.rivale || g.o.nome, 'grande') + '</div>'
    + '<h2>' + dsoEsc(g.o.nome) + '</h2><p>' + (g.o.modo === 'telefono' ? 'Prima tu, poi il tuo amico: ogni round le stesse domande.' : 'Tre round. A parità di risposta giusta vince il più veloce.') + '</p>'
    + '<button type="button" class="dso-cta" onclick="dsoRound()">Comincia</button><button type="button" class="am-link dso-g-link" onclick="dsoChiudi()">Non ora</button></div>';
}
function dsoSuonoAcceso(){ try{ return localStorage.getItem('fl_duello_muto') !== '1' && !(typeof muMuto === 'function' && muMuto()); }catch(_){ return true; } }
function dsoSuonoIco(){
  return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10v4h4l5 4V6L8 10z" fill="currentColor"/>' + (dsoSuonoAcceso() ? '<path d="M16.500 9a4 4 0 0 1 0 6M19 6.500a8 8 0 0 1 0 11"/>' : '<path d="M17 10l4 4m0-4l-4 4"/>') + '</svg>';
}
function dsoSuonoTocca(){
  const acceso = dsoSuonoAcceso();
  try{ localStorage.setItem('fl_duello_muto', acceso ? '1' : '0'); }catch(_){ }
  try{ if (acceso){ if (typeof muDuelloOff === 'function') muDuelloOff(); } else if (typeof muDuello === 'function') muDuello(); }catch(_){ }
  const b = document.getElementById('dsoSo'); if (b) b.innerHTML = dsoSuonoIco();
}
function dsoRound(){
  const w = document.getElementById('dsoG'), g = DSO.g; if (!w) return;
  try{ if (typeof muDuello === 'function') muDuello(); }catch(_){ }
  const e = g.tre[g.i];
  const nomi = g.o.modo === 'telefono' ? '<p class="dso-g-chi">Tocca ' + (g.turno === 1 ? 'a te' : dsoEsc(dsoAl(g.o.nome))) + '</p>' : '';
  w.innerHTML = '<div class="dso-g">' + dsoTesta() + '<div class="dso-g-t"><i id="dsoT"></i></div>' + nomi
    + '<div class="dso-g-e"><h3>' + dsoEsc(e.domanda) + '</h3></div>'
    + '<div class="dso-g-op">' + e.opzioni.map(function(x){ return '<button type="button" onclick="dsoRispondi(' + dsoJs(x) + ')">' + dsoEsc(x) + '</button>'; }).join('') + '</div></div>';
  g.t0 = Date.now();
  clearInterval(g.tm);
  const MAX = 30000;
  g.tm = setInterval(function(){
    const r = Date.now() - g.t0, b = document.getElementById('dsoT');
    if (b) b.style.width = Math.max(0, 100 - r / MAX * 100) + '%';
    if (r >= MAX){ clearInterval(g.tm); dsoRispondi(null); }
  }, 200);
}
function dsoRispondi(v){
  const g = DSO.g; if (!g) return;
  clearInterval(g.tm);
  const e = g.tre[g.i], ms = Date.now() - g.t0;
  const ok = v !== null && v === e.risposta_corretta;
  const r = { ok: ok, ms: ms };
  try{ if (typeof muJingle === 'function') muJingle(ok ? 'giusta' : 'sbagliata'); }catch(_){ }
  dsoVibra(ok ? [12, 40, 12] : [40]);
  if (g.o.modo === 'telefono' && g.turno === 2){ g.sue.push(r); }
  else g.mie.push(r);
  dsoEsitoRound(r, e);
}
function dsoEsitoRound(r, e){
  const w = document.getElementById('dsoG'), g = DSO.g; if (!w) return;
  const sec = function(x){ return (x.ms / 1000).toFixed(1).replace('.', ',') + ' s'; };
  const tel = g.o.modo === 'telefono';
  /* sullo stesso telefono: dopo il primo si passa il telefono, e la risposta giusta si vede solo a round chiuso */
  if (tel && g.turno === 1){
    g.turno = 2;
    w.innerHTML = '<div class="dso-g dso-g-pass"><span aria-hidden="true">📱</span><h2>Passa il telefono</h2><p>Adesso tocca a chi ti sta accanto: stesse domande, senza guardare.</p><button type="button" class="dso-cta" onclick="dsoRound()">Ci sono</button></div>';
    return;
  }
  const sua = tel ? g.sue[g.i] : ((g.o.modo === 'bot' || g.o.bot || (g.sue && g.sue.length)) ? (g.sue || [])[g.i] : null), mia = g.mie[g.i];
  const v = sua ? dsoVinceRound(mia, sua) : null;
  const tit = v === null ? (mia.ok ? 'Risposta giusta!' : 'Risposta sbagliata') : (v > 0 ? 'Round ' + (g.i + 1) + ' a te!' : v < 0 ? 'Round ' + (g.i + 1) + ' ' + dsoEsc(dsoAl(g.o.nome)) : 'Round ' + (g.i + 1) + ' pari');
  w.innerHTML = '<div class="dso-g">' + dsoTesta() + '<div class="dso-g-r ' + (v === null ? (mia.ok ? 'v' : 'p') : (v > 0 ? 'v' : v < 0 ? 'p' : 'x')) + '"><h2>' + tit + '</h2>'
    + '<div class="dso-g-cmp"><div><small>Tu</small><b>' + (mia.ok ? sec(mia) : 'Sbagliata') + '</b></div>' + (sua ? '<div><small>' + dsoEsc(g.o.nome) + '</small><b>' + (sua.ok ? sec(sua) : 'Sbagliata') + '</b></div>' : '') + '</div>'
    + '<p class="dso-g-giu">La risposta era <b>' + dsoEsc(e.risposta_corretta) + '</b></p>' + (e.effetto_eureka ? '<p class="dso-g-eu">' + dsoEsc(e.effetto_eureka) + '</p>' : '')
    + '<button type="button" class="dso-cta" onclick="dsoAvanti()">' + (g.i < 2 ? 'Prossimo round' : 'Vedi il risultato') + '</button></div></div>';
}
function dsoAvanti(){
  const g = DSO.g; if (!g) return;
  /* due round vinti chiudono il duello solo se si sa gia' come ha risposto l'altro */
  g.i++; g.turno = 1;
  if (g.i >= 3){ dsoFine(); return; }
  dsoRound();
}
async function dsoFine(){
  const w = document.getElementById('dsoG'), g = DSO.g; if (!w) return;
  try{ if (typeof muDuelloOff === 'function') muDuelloOff(); }catch(_){ }
  const o = g.o;
  const soloMio = o.modo === 'caso' || (o.modo === 'amico' && !o.bot);
  if (soloMio){
    let salvato = true;
    try{ const r = await frApi('POST', '/api/focuslock/social/duello', { device: frDevice(), a: o.rivale || '', seed: g.seed, round: g.mie }); salvato = !!(r && r.ok); }catch(_){ salvato = false; }
    DSO.duelliAt = 0;
    const giuste = g.mie.filter(function(x){ return x.ok; }).length;
    w.innerHTML = '<div class="dso-g dso-g-fine"><span class="dso-g-big" aria-hidden="true">⏳</span><h2>' + (salvato ? (o.rivale ? 'Ora tocca a ' + dsoEsc(o.nome) : 'Ora si aspetta un avversario') : 'Il duello non è partito') + '</h2>'
      + '<p>' + (salvato ? 'Hai risposto giusto a ' + giuste + ' su 3. Il risultato arriva nel registro appena ha giocato.' : 'Non ho raggiunto il server. Controlla la connessione e riprova.') + '</p>'
      + '<button type="button" class="dso-cta" onclick="dsoChiudi()">Ok</button></div>';
    return;
  }
  /* a chi risponde a una sfida il server rimanda le risposte dell'altro (il duello a caso non le mostra prima) */
  if (o.modo === 'risposta'){
    try{ const r = await frApi('POST', '/api/focuslock/social/duello/rispondi', { device: frDevice(), id: o.id, round: g.mie }); if (r && r.roundLui) g.sue = r.roundLui; }catch(_){ }
    DSO.duelliAt = 0;
  }
  const c = dsoConto(g.mie, g.sue);
  if (o.modo !== 'risposta') dsoRegistra({ nome: o.nome, io: c.io, lui: c.lui, esito: c.esito, at: Date.now(), modo: o.bot ? 'amico' : o.modo, livello: o.livello || '', rivale: o.rivale || '' });
  else { const d = c.esito === 'vittoria' ? 30 : (c.esito === 'sconfitta' ? -15 : 5); try{ localStorage.setItem(DSO_TRO_K, String(Math.max(0, dsoTrofei() + d))); }catch(_){ } if (c.esito === 'vittoria'){ try{ if (typeof ffAddCoins === 'function') ffAddCoins(20); }catch(_){ } } }
  const vinta = c.esito === 'vittoria', tit = vinta ? 'Hai vinto!' : c.esito === 'sconfitta' ? 'Ha vinto ' + dsoIl(o.nome) : 'Pareggio';
  try{ if (typeof muJingle === 'function') muJingle(vinta ? 'giusta' : 'sbagliata'); }catch(_){ }
  dsoVibra(vinta ? [20, 50, 20, 50, 60] : [40]);
  w.innerHTML = '<div class="dso-g dso-g-fine ' + c.esito + '"><span class="dso-g-big" aria-hidden="true">' + (vinta ? '🏆' : c.esito === 'pari' ? '🤝' : '💪') + '</span><h2>' + dsoEsc(tit) + '</h2>'
    + '<div class="dso-g-score"><div>' + dsoTu('grande') + '<b>' + c.io + '</b></div><i>-</i><div><b>' + c.lui + '</b>' + dsoAv(o.nome, o.rivale || o.nome, 'grande') + '</div></div>'
    + '<p>' + (vinta ? '+30 trofei e +20 monete.' : c.esito === 'pari' ? '+5 trofei.' : '-15 trofei. La rivincita è a un tocco.') + '</p>'
    + (o.modo !== 'risposta' ? '<button type="button" class="dso-cta" onclick=\'dsoRivincita()\'>Rivincita</button>' : '') + '<button type="button" class="am-link dso-g-link" onclick="dsoChiudi()">Chiudi</button></div>';
}
function dsoRivincita(){ const o = DSO.g && DSO.g.o; if (!o) return; dsoParti(Object.assign({}, o, { seed: 0 })); }
function dsoEsciChiedi(){
  inSheet('<div class="am-sheet center"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><b class="am-sh-title">Vuoi uscire dal duello?</b><p class="am-sh-p">I punti fin qui si perdono.</p>'
    + '<button type="button" class="dso-cta rosso" onclick="inSheetChiudi();dsoChiudi()">Esco</button><button type="button" class="am-link" onclick="inSheetChiudi()">Resto</button></div>');
}
function dsoChiudi(){
  try{ if (typeof muDuelloOff === 'function') muDuelloOff(); }catch(_){ }
  const g = DSO.g; if (g) clearInterval(g.tm);
  DSO.g = null;
  const w = document.getElementById('dsoG'); if (w) w.remove();
  try{ if (typeof frPaint === 'function' && typeof FR !== 'undefined' && FR.tab === 'sfide') frPaint(); }catch(_){ }
}
function dsoIndietro(){ if (!dsoAperto()) return false; const v = document.querySelector('#dsoG .dso-g-t, #dsoG .dso-g-r'); if (v) dsoEsciChiedi(); else dsoChiudi(); return true; }

/* ---------------------------------------------------------------- lo stile */
(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* la serie di gruppo */
    '.dso-gr-vuoto{display:flex;flex-direction:column;align-items:center;text-align:center;padding:44px 22px 24px}.dso-gr-vuoto h2{margin:26px 0 26px;font:800 23px/1.32 var(--font-display);color:var(--navy)}body.dark .dso-gr-vuoto h2{color:#fff}.dso-gr-vuoto h2 b{display:inline;font:inherit;color:#0075E3}body.dark .dso-gr-vuoto h2 b{color:#8CC6FF}',
    '.dso-gr-art{position:relative;width:190px;height:190px}.dso-gr-art img{width:100%;height:100%;object-fit:contain}.dso-gr-fuoco{position:absolute;right:6px;top:4px;font-size:44px;animation:dsoFuoco 1.6s ease-in-out infinite}@keyframes dsoFuoco{50%{transform:scale(1.12)}}',
    '.dso-gr-hero{position:relative;height:170px;margin:12px 16px 0;border-radius:22px;overflow:hidden;background:linear-gradient(135deg,#0075E3,#00459A)}.dso-gr-hero img{position:absolute;left:50%;bottom:-18px;height:178px;transform:translateX(-50%)}.dso-gr-hero .dso-gr-fuoco{right:calc(50% - 110px);top:18px;font-size:48px}',
    '.dso-gr-testa{display:flex;align-items:center;justify-content:space-between;margin:20px 18px 12px}.dso-gr-testa h3{margin:0;font:800 22px var(--font-display);color:var(--navy)}body.dark .dso-gr-testa h3{color:#fff}.dso-gr-testa button{border:0;background:none;padding:8px 2px;color:#0075E3;font:800 14px var(--font-body);text-transform:uppercase;letter-spacing:.04em;cursor:pointer}',
    'body.dark .dso-gr-testa button{color:#8CC6FF}.dso-gr-l{margin:0 16px 20px;border:2px solid #C9D9EE;border-radius:18px;overflow:hidden}.dso-gr-r{display:flex;align-items:center;gap:14px;width:100%;min-height:74px;box-sizing:border-box;padding:10px 14px;border:0;border-bottom:2px solid #C9D9EE;background:none;color:var(--navy);text-align:left;font:inherit}.dso-gr-r:last-child{border-bottom:0}body.dark .dso-gr-l,body.dark .dso-gr-r{border-color:#2C4170}',
    '.dso-gr-n{flex:1;min-width:0}.dso-gr-n b{display:block;font:800 15.5px var(--font-body);color:var(--navy)}body.dark .dso-gr-n b{color:#fff}.dso-gr-n small{display:inline-flex;align-items:center;gap:3px;margin-top:3px;font:800 13px var(--font-body);color:#7E91B3}.dso-gr-n small.on{color:#FF8A3D}',
    '.dso-gr-r.piu{cursor:pointer}.dso-gr-r.piu b{font:700 15px var(--font-body);color:#6A7F9E}.dso-gr-piu{flex:none;width:46px;height:46px;border-radius:50%;border:2px dashed #4A6193;display:flex;align-items:center;justify-content:center;color:#7E91B3}',
    '.dso-gr-via{flex:none;padding:8px 13px;border:1.5px solid #E63946;border-radius:99px;background:none;color:#FF8A92;font:800 13px var(--font-body);cursor:pointer}',
    '.dso-cta{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:54px;padding:14px 18px;box-sizing:border-box;border:0;border-radius:16px;background:#0075E3;box-shadow:0 4px 0 #00459A;color:#fff;font:800 16px var(--font-body);cursor:pointer}.dso-cta:active{transform:translateY(3px);box-shadow:0 1px 0 #00459A}.dso-cta:disabled{opacity:.45}.dso-cta.rosso{background:#E63946;box-shadow:0 4px 0 #A9202B}',
    '.dso-fine-ico{display:block;font-size:46px;text-align:center;margin-bottom:8px}.dso-fine .dso-cta{margin-top:16px}',
    '.dso-sc-l{display:flex;flex-direction:column;gap:8px;margin-top:14px}.dso-sc-l button{display:flex;align-items:center;gap:12px;width:100%;min-height:62px;box-sizing:border-box;padding:8px 14px;border:1.5px solid #BCE0FF;border-radius:16px;background:var(--card,#fff);color:var(--navy);text-align:left;cursor:pointer}.dso-sc-l b{flex:1;font:800 15px var(--font-body)}.dso-sc-l small{display:inline-flex;align-items:center;gap:3px;color:#FF8A3D;font:800 13px var(--font-body)}.dso-sc-e{font-size:24px}body.dark .dso-sc-l button{background:#12203A;border-color:#2C4170;color:#fff}',
    /* la protezione della serie */
    '.dso-prot{position:relative}.dso-prot-i{position:absolute;right:10px;top:10px;width:26px;height:26px;padding:0;border:1.5px solid rgba(188,224,255,.7);border-radius:50%;background:none;color:#BCE0FF;font:800 13px var(--font-body);cursor:pointer}',
    /* le bolle e i regali */
    '.dso-bolle{display:flex;gap:14px;overflow-x:auto;scrollbar-width:none;margin:0 -8px;padding:14px 12px 18px}.dso-bolle::-webkit-scrollbar{display:none}',
    '.dso-bolla{flex:none;width:68px;height:68px;padding:0;border:0;border-radius:50%;background:none;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .2s cubic-bezier(.3,1.8,.5,1)}.dso-bolla .am-av{width:64px;height:64px;font-size:25px;box-shadow:0 0 0 2px var(--card,#fff),0 0 0 4px #0075E3}.dso-bolla.presa{transform:scale(1.14)}',
    '.dso-bolla.vuota{border:2px dashed #BCE0FF;color:#8CA5C4}body.dark .dso-bolla.vuota{border-color:#3A4F78;color:#7E91B3}',
    '.dso-reg{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:50px;margin:0 0 18px;border:2px solid #0075E3;border-radius:14px;background:none;color:#0075E3;font:800 14px var(--font-body);cursor:pointer;box-shadow:0 3px 0 #0075E3}.dso-reg:active{transform:translateY(2px);box-shadow:0 1px 0 #0075E3}.dso-reg.spento{border-color:#C9D6EA;color:#8CA5C4;box-shadow:0 3px 0 #C9D6EA;cursor:default}body.dark .dso-reg{color:#8CC6FF;border-color:#3F9FF4;box-shadow:0 3px 0 #3F9FF4}body.dark .dso-reg.spento{color:#7E91B3;border-color:#2C4170;box-shadow:0 3px 0 #2C4170}',
    '.dso-luce{position:fixed;z-index:9999;width:18px;height:18px;border-radius:50%;background:radial-gradient(circle,#fff 15%,#8CC6FF 55%,rgba(0,117,227,0) 75%);pointer-events:none}',
    '.dso-feed .hd-feed{margin:0;padding:0}',
    /* la missione del mese */
    '.dso-mese{position:sticky;top:66px;z-index:6;margin:0 0 16px;padding:14px;border-radius:22px;background:linear-gradient(135deg,#0075E3,#00459A);color:#fff;box-shadow:0 8px 20px rgba(0,30,68,.22)}.dso-mese.tocca{cursor:pointer}',
    '.dso-mese-top{position:relative;display:flex;justify-content:space-between;min-height:64px}.dso-mese-top b{display:block;font:800 21px/1.2 var(--font-display);color:#fff}.dso-mese-top small{display:block;margin-top:4px;font:800 12px var(--font-body);letter-spacing:.06em;color:#CFE8FF}.dso-mese-top img{position:absolute;right:-6px;top:-6px;height:92px;pointer-events:none}',
    '.dso-mese-c{position:relative;padding:12px 14px;border-radius:14px;background:#00132B}.dso-mese-c p{margin:0 0 8px;font:700 14.5px var(--font-body);color:#fff}.dso-mese-bar{position:relative;height:20px;border-radius:99px;background:#223659;overflow:hidden}.dso-mese-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(180deg,#8CC6FF,#3F9FF4)}.dso-mese-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:800 12px var(--font-body);color:#fff}',
    /* il torneo */
    '.dso-tor-art{flex:1;display:flex;align-items:center;justify-content:center;padding:14px 0 6px}.dso-tor-art svg{width:96px;filter:drop-shadow(0 0 16px rgba(140,198,255,.7))}',
    '.dso-tor-f{display:flex;gap:6px;margin:6px 16px 0}.dso-tor-f span{flex:1;padding:8px 2px;border-radius:10px;background:rgba(255,255,255,.1);color:#D6E8FF;font:800 12px var(--font-body);text-align:center}.dso-tor-f span.ora{background:#0075E3;color:#fff}.dso-tor-f span.fatta{background:#BCE0FF;color:#00459A}',
    '.dso-tor-v{margin:10px 0 0;font:800 13px var(--font-body);color:#8CC6FF;text-align:center}',
    /* l'arena dei duelli */
    '.dso-arena{padding:18px 14px 16px;border-radius:22px;background:radial-gradient(circle at 50% 0,#1A4A8F,#00132B 72%);color:#fff;text-align:center}.dso-arena > p{margin:12px auto 16px;max-width:27ch;font:600 14.5px/1.4 var(--font-body);color:#D6E8FF}',
    '.dso-ar-vs{display:flex;align-items:center;justify-content:center;gap:18px}.dso-ar-vs b{font:900 20px var(--font-display);color:#FF8A92;letter-spacing:.04em}.dso-ar-vs .am-av{width:64px;height:64px;font-size:25px;box-shadow:0 0 0 3px #fff}.dso-ar-q{background:#223659 !important;color:#8CC6FF !important}',
    '.dso-ar-g{margin:0;display:grid;grid-template-columns:1fr 1fr;gap:8px}.dso-mo{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-height:82px;padding:10px 8px;border:1.5px solid rgba(140,198,255,.4);border-radius:16px;background:rgba(255,255,255,.08);color:#fff;font:800 13.5px/1.2 var(--font-body);cursor:pointer}.dso-mo span{font-size:24px}.dso-mo small{display:block;font:500 11.5px/1.25 var(--font-body);color:#BFD3EC}.dso-mo:active{transform:scale(.97)}',
    '.dso-col{display:flex;flex-direction:column;gap:8px;margin-top:10px}.dso-att{display:flex;align-items:center;gap:12px;padding:10px 12px;border:1.5px solid #BCE0FF;border-radius:16px;background:var(--card,#fff)}.dso-att.su{border-color:#0075E3}.dso-att > div{flex:1;min-width:0}.dso-att b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}.dso-att small{font:500 12.5px var(--font-body);color:var(--muted)}.dso-att button{flex:none;padding:9px 16px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13px var(--font-body);cursor:pointer}body.dark .dso-att{background:#12203A;border-color:#2C4170}body.dark .dso-att b{color:#fff}',
    /* il registro delle partite */
    '.dso-reg-l{display:flex;flex-direction:column;gap:8px}.dso-reg-r{position:relative;display:flex;align-items:center;gap:12px;padding:12px 12px 12px 18px;border:1.5px solid #DCE9F7;border-radius:16px;background:var(--card,#fff);overflow:hidden}body.dark .dso-reg-r{background:#12203A;border-color:#2C4170}',
    '.dso-reg-b{position:absolute;left:0;top:0;bottom:0;width:6px;background:#2F55D4}.dso-reg-r.vittoria .dso-reg-b{background:#0075E3}.dso-reg-r.sconfitta .dso-reg-b{background:#E63946}',
    '.dso-reg-s{flex:none;display:flex;flex-direction:column;align-items:center;gap:2px;width:60px}.dso-reg-s b{font:900 16px var(--font-display);color:var(--navy)}body.dark .dso-reg-s b{color:#fff}.dso-reg-s span{display:flex;gap:1px;color:#D5DFEC}.dso-reg-s span svg.on{color:#F4B400}body.dark .dso-reg-s span{color:#2C4170}',
    '.dso-reg-n{flex:1;min-width:0}.dso-reg-n b{display:block;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .dso-reg-n b{color:#fff}.dso-reg-n small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.dso-reg-r.vittoria .dso-reg-n b{color:#0075E3}body.dark .dso-reg-r.vittoria .dso-reg-n b{color:#8CC6FF}.dso-reg-r.sconfitta .dso-reg-n b{color:#E63946}',
    '.dso-reg-r > button{flex:none;padding:8px 11px;border:1.5px solid #0075E3;border-radius:99px;background:none;color:#0075E3;font:800 12px var(--font-body);cursor:pointer}body.dark .dso-reg-r > button{color:#8CC6FF;border-color:#3F9FF4}',
    /* la partita */
    '#dsoG{position:fixed;inset:0;z-index:9990;background:linear-gradient(180deg,#00132B,#000);color:#fff;overflow:auto;-webkit-overflow-scrolling:touch}',
    '.dso-g{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:calc(env(safe-area-inset-top,0px) + 14px) 18px calc(env(safe-area-inset-bottom,0px) + 18px);animation:dsoEntra .35s ease-out}@keyframes dsoEntra{from{opacity:0}to{opacity:1}}',
    '.dso-g-in,.dso-g-pass,.dso-g-fine{align-items:center;justify-content:center;text-align:center}.dso-g h2{margin:16px 0 10px;font:800 25px/1.25 var(--font-display);color:#fff}.dso-g-in p,.dso-g-pass p,.dso-g-fine p{margin:0 0 26px;max-width:28ch;font:500 15.5px/1.5 var(--font-body);color:#D6E8FF}',
    '.dso-g-vs{display:flex;align-items:center;gap:18px}.dso-g-vs b{font:900 24px var(--font-display);color:#FF8A92}.dso-g .am-av.grande{width:78px;height:78px;font-size:30px;box-shadow:0 0 0 3px #fff}.dso-g-link{margin-top:14px;color:#BFE0FF;background:none;border:0;font:700 14px var(--font-body);cursor:pointer}',
    '.dso-g-pass > span,.dso-g-big{font-size:64px}',
    '.dso-g-top{position:relative;display:flex;align-items:center;justify-content:space-between;gap:8px;padding-left:44px}.dso-g-x{position:absolute;left:0;top:50%;transform:translateY(-50%);width:36px;height:36px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;cursor:pointer}.dso-g-top small{font:800 12.5px var(--font-body);color:#BFE0FF;white-space:nowrap}',
    '.dso-g-pl{display:flex;align-items:center;gap:7px}.dso-g-pl .am-av{width:36px;height:36px;font-size:15px}.dso-pip{display:flex;gap:3px}.dso-pip i{width:10px;height:10px;border-radius:50%;background:#223659}.dso-pip i.v{background:#3F9FF4}.dso-pip i.p{background:#E63946}.dso-pip i.x{background:#7E91B3}',
    '.dso-g-t{height:6px;margin:14px 0 18px;border-radius:99px;background:#223659;overflow:hidden}.dso-g-t i{display:block;width:100%;height:100%;background:#3F9FF4;transition:width .2s linear}',
    '.dso-g-chi{margin:0 0 10px;font:800 14px var(--font-body);color:#FF8A92;text-align:center}',
    '.dso-g-e{padding:22px 18px;border-radius:18px;background:#fff;text-align:center}.dso-g-e h3{margin:0;font:800 20px/1.3 var(--font-display);color:#0E2350}',
    '.dso-g-op{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px}.dso-g-op button{min-height:104px;padding:12px 10px;border:1.5px solid rgba(140,198,255,.45);border-radius:16px;background:rgba(255,255,255,.08);color:#fff;font:700 14.5px/1.3 var(--font-body);cursor:pointer}.dso-g-op button:active{background:rgba(63,159,244,.35)}',
    '.dso-g-r{flex:1;display:flex;flex-direction:column;justify-content:center;text-align:center;padding:18px 0}.dso-g-r.v h2{color:#8CC6FF}.dso-g-r.p h2{color:#FF8A92}',
    '.dso-g-cmp{display:flex;gap:10px;margin:8px 0 18px}.dso-g-cmp div{flex:1;padding:12px;border-radius:14px;background:rgba(255,255,255,.08)}.dso-g-cmp small{display:block;font:700 12.5px var(--font-body);color:#BFE0FF}.dso-g-cmp b{display:block;margin-top:4px;font:800 18px var(--font-display);color:#fff}',
    '.dso-g-giu{margin:0;font:500 15px var(--font-body);color:#fff}.dso-g-giu b{font-weight:800}.dso-g-eu{margin:8px 0 22px;font:500 14px/1.45 var(--font-body);color:#D6E8FF}',
    '.dso-g-score{display:flex;align-items:center;justify-content:center;gap:14px;margin:6px 0 18px}.dso-g-score > div{display:flex;align-items:center;gap:12px}.dso-g-score b{font:900 36px var(--font-display);color:#fff}.dso-g-score i{font:800 26px var(--font-display);font-style:normal;color:#7E91B3}'
  ].join('\n');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '.dso-g-m{display:flex;flex-direction:column;align-items:center;gap:4px}.dso-g-so{width:32px;height:32px;padding:0;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:inherit;cursor:pointer}';
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------- 0.9.343: SERIE DI GRUPPO ALLUNGATE
   Andrea: "come Duolingo: una schermata con solo il fuoco, che si sdoppia, poi Serie di gruppo allungate con le persone con cui
   l'hai iniziata, e Continua". Una volta al giorno, alla prima tappa, se c'e' almeno una serie di gruppo attiva. */
const DSO_DOPPIA = '<svg class="dso-sl-ff" viewBox="0 0 34 24" aria-hidden="true"><path fill="#FF8A3D" d="M12 2c1 3.500 5.500 6 5.500 11.500a5.500 5.500 0 0 1-11 0C6.500 10.500 8 9 9 7c.5 1.500 1.300 2.300 2 2.800C11.300 7.500 11 4.500 12 2z"/><path fill="#E63946" d="M22 2c1 3.500 5.500 6 5.500 11.500a5.500 5.500 0 0 1-11 0C16.500 10.500 18 9 19 7c.5 1.500 1.300 2.300 2 2.800C21.300 7.500 21 4.500 22 2z"/></svg>';
function dsoOggiFatto(a){ try{ return !!(a && a.visto && new Date(a.visto).toDateString() === new Date().toDateString() && (+a.streak || 0) > 0); }catch(_){ return false; } }
function dsoSlancioForse(dopo){
  try{
    const gr = dsoGruppoAttive(); if (!gr.length) return false;
    const oggi = new Date().toDateString(); if (localStorage.getItem('fl_slancio_visto') === oggi) return false;
    localStorage.setItem('fl_slancio_visto', oggi);
    dsoSlancioApri(gr, dopo); return true;
  }catch(_){ return false; }
}
function dsoSlancioApri(gr, dopo){
  const righe = gr.map(function(v){
    const a = dsoAmicoDi(v), su = dsoOggiFatto(a), g = dsoGiorniInsieme(v, a);
    return '<div class="dso-sl-r' + (su ? ' on' : '') + '"><span class="dso-sl-avs">' + dsoTu('dso-sl-io') + dsoAv(a.nome, a.device, 'dso-sl-lui') + '</span>'
      + '<span class="dso-sl-n"><b>' + dsoEsc(a.nome) + '</b>' + (su ? '' : '<small>Manca la sua tappa di oggi</small>') + '</span>'
      + '<span class="dso-sl-v">' + DSO_DOPPIA + '<em>' + Math.max(1, g) + '</em></span></div>';
  }).join('');
  const quante = gr.filter(function(v){ return dsoOggiFatto(dsoAmicoDi(v)); }).length;
  const w = document.createElement('div'); w.id = 'dsoSl'; w.className = 'dso-sl';
  w.innerHTML = '<div class="dso-sl-fuoco" aria-hidden="true"><span class="f1">🔥</span><span class="f2">🔥</span></div>'
    + '<div class="dso-sl-in"><h2>' + (quante ? (gr.length === 1 ? 'Serie di gruppo allungata!' : 'Serie di gruppo allungate!') : 'Hai fatto la tua parte!') + '</h2>'
    + '<div class="dso-sl-l">' + righe + '</div>'
    + '<button type="button" class="dso-sl-cta" onclick="dsoSlancioChiudi()">Continua</button></div>';
  document.body.appendChild(w); w._dopo = dopo;
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ w.classList.add('in'); }); });
  setTimeout(function(){ w.classList.add('split'); dsoVibra([14, 50, 14]); try{ if (typeof gnAu !== 'undefined') gnAu.punto(); }catch(_){ } }, 1000);
  setTimeout(function(){ w.classList.add('lista'); }, 2000);
}
function dsoSlancioChiudi(){
  const w = document.getElementById('dsoSl'); if (!w) return;
  const dopo = w._dopo; w.classList.remove('in');
  setTimeout(function(){ w.remove(); if (dopo) dopo(); }, 260);
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.dso-gr-inv{margin:16px 18px 6px}.dso-gr-inv.dentro{margin:0 0 10px}.dso-gr-inv > p{margin:0 0 8px;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3}body.dark .dso-gr-inv > p{color:#8CC6FF}',
    '.dso-gr-si{flex:none;padding:10px 14px;border:0;border-radius:12px;background:#0075E3;color:#fff;font:800 13.5px var(--font-body);cursor:pointer}.dso-gr-no{flex:none;width:38px;height:38px;margin-left:6px;border:0;border-radius:50%;background:var(--line);color:var(--navy);font:800 14px var(--font-body);cursor:pointer}body.dark .dso-gr-no{background:#22345A;color:#fff}',
    '.dso-gr-r.attesa{opacity:.75}.dso-gr-att{color:var(--muted)!important}',
    '.dso-sl{position:fixed;inset:0;z-index:9500;background:radial-gradient(120% 80% at 50% 30%,#0B2A63 0%,#001E44 60%,#00132B 100%);opacity:0;transition:opacity .28s}.dso-sl.in{opacity:1}',
    '.dso-sl-fuoco{position:absolute;left:50%;top:40%;width:240px;height:160px;transform:translate(-50%,-50%);transition:opacity .45s}.dso-sl.lista .dso-sl-fuoco{opacity:0}',
    '.dso-sl-fuoco span{position:absolute;left:50%;top:50%;font-size:120px;line-height:1;transform:translate(-50%,-50%) scale(.2);filter:drop-shadow(0 0 30px rgba(255,138,61,.6));transition:transform .7s cubic-bezier(.2,1.4,.4,1)}',
    '.dso-sl.in .dso-sl-fuoco span{transform:translate(-50%,-50%) scale(1)}.dso-sl.split .dso-sl-fuoco .f1{transform:translate(-100%,-50%) scale(.8) rotate(-10deg)}.dso-sl.split .dso-sl-fuoco .f2{transform:translate(0%,-50%) scale(.8) rotate(10deg)}',
    '.dso-sl-in{position:absolute;inset:0;display:flex;flex-direction:column;padding:calc(env(safe-area-inset-top,0px) + 16vh) 24px calc(env(safe-area-inset-bottom,0px) + 26px);box-sizing:border-box;opacity:0;transform:translateY(24px);transition:opacity .45s,transform .45s}.dso-sl.lista .dso-sl-in{opacity:1;transform:none}',
    '.dso-sl-in h2{margin:0 0 30px;text-align:center;font:800 27px/1.25 var(--font-display);color:#fff}',
    '.dso-sl-l{display:flex;flex-direction:column;gap:20px}.dso-sl-r{display:flex;align-items:center;gap:16px;opacity:.6}.dso-sl-r.on{opacity:1}',
    '.dso-sl-avs{position:relative;flex:none;width:84px;height:52px}.dso-sl-avs .am-av{position:absolute;top:0;width:52px!important;height:52px!important;font-size:20px;box-shadow:0 0 0 3px #FF8A3D}.dso-sl-avs > :first-child{left:0;z-index:1}.dso-sl-avs > :last-child{left:32px}',
    '.dso-sl-n{flex:1;min-width:0}.dso-sl-n b{display:block;font:800 17px var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.dso-sl-n small{display:block;margin-top:3px;font:500 13px var(--font-body);color:#BFD3EC}',
    '.dso-sl-v{flex:none;display:flex;align-items:center;gap:6px}.dso-sl-ff{width:34px;height:24px}.dso-sl-v em{font:900 22px var(--font-display);font-style:normal;color:#FF8A3D}',
    '.dso-sl-cta{margin-top:auto;width:100%;padding:17px;border:0;border-radius:18px;background:#0075E3;color:#fff;font:800 16px var(--font-body);box-shadow:0 6px 0 #00459A;cursor:pointer}.dso-sl-cta:active{transform:translateY(3px);box-shadow:0 3px 0 #00459A}'
  ].join('\n');
  document.head.appendChild(st);
})();
