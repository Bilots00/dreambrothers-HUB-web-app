/* ===========================================================================================
   IL TESTO SCRITTO DALL'AGENTE, IN ITALIANO VERO (0.9.290)

   Andrea: "Scrivere l'offerta quadro piu' piano su misura". L'agente scrive spesso l'apostrofo
   al posto dell'accento (piu', e', perche', gia'): a schermo deve leggersi più, è, perché, già.
   flAccenti lo sistema ovunque si mostri un testo dell'agente (roadmap, passi, chat).

   Restano come sono: "po'", "un po'", gli imperativi corti ("va'", "fa'", "da'", "di'"), le
   elisioni ("dell'acqua") e le parole fra apici ('ciao').
   =========================================================================================== */
function flAccenti(t){
  t = String(t == null ? '' : t);
  if (t.indexOf("'") < 0 && t.indexOf('’') < 0) return t;
  const GRAVE = { a: 'à', i: 'ì', o: 'ò', u: 'ù', A: 'À', I: 'Ì', O: 'Ò', U: 'Ù' };
  return t.replace(/\p{L}+['’](?!\p{L})/gu, function(m, at, tutto){
    const prima = at > 0 ? tutto.charAt(at - 1) : '';
    /* un apice aperto prima della parola ('ciao'): e' una citazione, non un accento */
    if (prima === "'" || prima === '’'){
      const ancora = at > 1 ? tutto.charAt(at - 2) : '';
      if (!/\p{L}/u.test(ancora)) return m;
    }
    const w = m.slice(0, -1), low = w.toLowerCase();
    if (low === 'e') return w === 'E' ? 'È' : 'è';
    if (low === 'si') return w.charAt(0) + (w.charAt(1) === 'I' ? 'Ì' : 'ì');
    if (low.length >= 4 && /che$/.test(low)) return w.slice(0, -1) + (w.slice(-1) === 'E' ? 'É' : 'é');
    if (low === 'cioe' || low === 'caffe' || low === 'ahime') return w.slice(0, -1) + (w.slice(-1) === 'E' ? 'È' : 'è');
    const v = w.slice(-1);
    if (low.length >= 3 && GRAVE[v]) return w.slice(0, -1) + GRAVE[v];
    return m;
  });
}
