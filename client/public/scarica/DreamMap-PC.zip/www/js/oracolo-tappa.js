/* ===========================================================================================
   LA PROSSIMA TAPPA — l'Oracolo del giorno (0.9.207), dalla sfida del Genio

   Tre domande (energia, tempo che hai, cosa stai rimandando) e il Genio indovina l'unica
   micro-azione da fare nelle prossime due ore per sbloccare la giornata. Con la bottiglia:
   tutte le aree del tuo campo, e il collo di bottiglia evidenziato, l'unica area da mettere a
   fuoco adesso. Tutto sul telefono, dalle righe che hai gia' scritto nel foglio.
   =========================================================================================== */
const OT2 = { passo: 0, energia: 2, tempo: 30, riga: '', righe: [], umore: '', da: 'dream', respirato: false };
/* COME TI SENTI (0.9.210): la prima domanda. L'ansia chiede prima due minuti di respiro (la
   radice, non il sintomo); la stanchezza un respiro che sveglia; la confusione i passi. */
const ORC_UMORI = [
  { k: 'ansia', ico: '😰', t: 'Ansia e agitazione', energia: 2, esercizio: 'rilassamento' },
  { k: 'stanco', ico: '🥱', t: 'Stanchezza', energia: 0, esercizio: 'motivazione' },
  { k: 'confuso', ico: '🌫️', t: 'Confusione: non so da dove partire', energia: 2, esercizio: 'scomponi' },
  { k: 'calma', ico: '🙂', t: 'Calma', energia: 2 },
  { k: 'carica', ico: '🔥', t: 'Carica a mille', energia: 3 }
];
function orcEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
const ORC_CAMPI = [
  { k: 'business', re: /business|azienda|impresa|vend|lanci|client|negozio|shop|startup|agenzia|freelance|soldi|fattur|e-?commerce|dropship/i, aree: ['Marketing', 'Vendite', 'Prodotto', 'Finanza', 'Operazioni', 'Clienti'] },
  { k: 'studio', re: /stud|esam|univers|laure|scuol|lezion|corso|certific/i, aree: ['Lezioni', 'Appunti', 'Esercizi', 'Ripasso', 'Esami', 'Metodo'] },
  { k: 'corpo', re: /sport|palestra|corp|peso|allen|corsa|marat|forma|salute|dieta/i, aree: ['Allenamento', 'Alimentazione', 'Sonno', 'Recupero', 'Tecnica', 'Costanza'] },
  { k: 'creativo', re: /libro|scriv|roman|musica|canzon|album|video|canale|film|arte|dipin|podcast|contenut|social/i, aree: ['Idee', 'Bozza', 'Revisione', 'Pubblicazione', 'Pubblico', 'Stile'] }
];
const ORC_PAROLE = {
  Marketing: /market|ads|annunc|post|social|contenut|brand|pubblic/i, Vendite: /vend|offert|prezz|chiam|lead|chius|pitch/i, Prodotto: /prodott|funzion|prototip|app|design|cod|svilupp/i, Finanza: /soldi|budget|cost|fattur|prezz|cont|bilanc|iva/i, Operazioni: /spedi|fornit|process|ordin|magazz|organizz/i, Clienti: /client|recens|support|assist|rispost/i,
  Lezioni: /lezion|video|segu|frequent/i, Appunti: /appunt|schem|riassun|mapp/i, Esercizi: /eserciz|problem|pratic|simul/i, Ripasso: /ripass|ripet|rivedere|rilegg/i, Esami: /esam|prova|test|verific/i, Metodo: /metod|piano|orari|tecnic/i,
  Allenamento: /allen|sess|serie|corsa|palestra/i, Alimentazione: /mang|dieta|past|cib|cucin/i, Sonno: /dorm|sonno|letto|svegl/i, Recupero: /recup|ripos|stretch|massagg/i, Tecnica: /tecnic|form|postur|video/i, Costanza: /costan|abitud|ogni giorno|serie/i,
  Idee: /idea|brainstorm|spunt|appunt/i, Bozza: /bozz|scriv|prim[ao]|regist|gir/i, Revisione: /revis|correg|montag|edit|rilegg/i, Pubblicazione: /pubblic|post|upload|caric|invia/i, Pubblico: /pubblic[oi]|follower|comunit|lettor|ascolt/i, Stile: /stil|voce|tono|font|graf/i
};
function orcCampo(){
  let txt = ''; try{ const d = (typeof agDati === 'function') ? agDati() : {}; txt = [d.sogno, d.tipo, d.target, d.goal].filter(Boolean).join(' '); }catch(_){ }
  return ORC_CAMPI.filter(function(c){ return c.re.test(txt); })[0] || { k: 'vita', aree: ['Tempo', 'Energia', 'Priorità', 'Abitudini', 'Ambiente', 'Persone'] };
}
function orcRighe(){
  const out = [];
  try{ const day = stDayKey('today'); stRigheDi(day).forEach(function(r){ if (r && !stIsDone(r, day)) out.push(r); }); }catch(_){ }
  try{ ['oggi', 'settimana'].forEach(function(k){ const a = ozAnello(k); (a.passi || []).forEach(function(p){ if (p && p.t && !p.fatto && out.indexOf(p.t) < 0) out.push(p.t); }); }); }catch(_){ }
  return out.slice(0, 8);
}
function orcApri(da){
  OT2.passo = 0; OT2.riga = ''; OT2.righe = orcRighe(); OT2.umore = ''; OT2.respirato = false; OT2.da = da || 'dream';
  goId('s-oracolo'); orcPaint();
}
registerScreen('s-oracolo',
  '<div class="topbar"><button class="iconbtn" onclick="orcIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">La prossima tappa</b></div>'
  + '<div id="orcBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });
/* si torna nella scheda Sogno, dove sta la sfida (0.9.210) */
function orcEsci(){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } }
function orcIndietro(){ if (OT2.passo > 0){ OT2.passo--; orcPaint(); return; } orcEsci(); }
function orcPaint(){
  const h = document.getElementById('orcBody'); if (!h) return;
  const dots = '<div class="orc-dots">' + [0, 1, 2, 3].map(function(i){ return '<i class="' + (i <= OT2.passo ? 'on' : '') + '"></i>'; }).join('') + '</div>';
  if (OT2.passo === 0){
    h.innerHTML = dots + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div><p class="orc-q">Adesso, in questo momento, <b>come ti senti</b>?</p>'
      + '<div class="orc-opz orc-umori">' + ORC_UMORI.map(function(o, i){ return '<button type="button" class="' + (OT2.umore === o.k ? 'on' : '') + '" onclick="OT2.umore=ORC_UMORI[' + i + '].k;OT2.energia=ORC_UMORI[' + i + '].energia;OT2.passo=1;orcPaint()"><span>' + o.ico + '</span>' + o.t + '</button>'; }).join('') + '</div>';
    return;
  }
  if (OT2.passo === 1){
    h.innerHTML = dots + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div><p class="orc-q">Nelle prossime due ore, <b>quanto tempo libero</b> hai davvero?</p>'
      + '<div class="orc-opz"><button type="button" onclick="OT2.tempo=10;OT2.passo=2;orcPaint()"><span>⏱️</span>Dieci minuti</button><button type="button" onclick="OT2.tempo=25;OT2.passo=2;orcPaint()"><span>⏳</span>Mezz’ora</button><button type="button" onclick="OT2.tempo=60;OT2.passo=2;orcPaint()"><span>🕐</span>Un’ora</button><button type="button" onclick="OT2.tempo=120;OT2.passo=2;orcPaint()"><span>🕑</span>Due ore</button></div>';
    return;
  }
  if (OT2.passo === 2){
    h.innerHTML = dots + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div><p class="orc-q">Fra le cose che hai scritto, <b>quale stai rimandando</b> da più tempo?</p>'
      + (OT2.righe.length ? '<div class="orc-lista">' + OT2.righe.map(function(r, i){ return '<button type="button" class="' + (OT2.riga === r ? 'on' : '') + '" onclick="OT2.riga=OT2.righe[' + i + '];OT2.passo=3;orcPaint()">' + orcEsc(r) + '</button>'; }).join('') + '</div>' : '')
      + '<div class="orc-libera"><input class="fin" id="orcLibera" placeholder="' + (OT2.righe.length ? 'Oppure scrivila qui' : 'Scrivila qui: la cosa che rimandi') + '" autocomplete="off" onkeydown="if(event.key===\'Enter\')orcLibera()"><button type="button" class="ghostmini" onclick="orcLibera()">Questa</button></div>';
    return;
  }
  /* il responso */
  const campo = orcCampo(); const riga = OT2.riga || 'la cosa che rimandi';
  const collo = campo.aree.filter(function(a){ return ORC_PAROLE[a] && ORC_PAROLE[a].test(riga); })[0] || campo.aree[2];
  const min = Math.min(OT2.tempo, OT2.energia <= 1 ? 10 : 25);
  const micro = OT2.energia <= 1
    ? 'Bastano due minuti. Apri quello che serve per "' + riga + '" e fai solo la prima riga. Se poi vuoi smettere, smetti.'
    : (OT2.tempo <= 10 ? 'Dedica dieci minuti a "' + riga + '". Prepara tutto quello che serve, così la prossima volta parti senza attrito.' : min + ' minuti di Full Focus su "' + riga + '". Una cosa sola, tutto il resto chiuso.');
  h.innerHTML = dots + '<div class="orc-genio"><img src="img/genio/genio-rivela.png" alt=""></div>'
    + '<p class="orc-eti">L’unica cosa, adesso</p><h2 class="orc-h">' + orcEsc(riga) + '</h2>'

    + orcPrimaHtml(riga)
    + '<div class="orc-card"><span>⚡</span><p>' + orcEsc(micro) + '</p></div>'
    + '<button type="button" class="cta orc-cta" onclick="orcVia()">Fai la tappa adesso</button>'
    + '<button type="button" class="sd-btn-link" onclick="orcNelFoglio();orcEsci()">Mettila nel foglio di oggi</button>';
}
/** Il passo prima della tappa, secondo come ti senti: il respiro, o i passi. */
function orcPrimaHtml(riga){
  const u = ORC_UMORI.filter(function(x){ return x.k === OT2.umore; })[0];
  try{ localStorage.setItem('fl_orc_giorno', (function(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); })()); }catch(_){ }
  if (!u || !u.esercizio) return '';
  if (u.esercizio === 'scomponi')
    return '<div class="orc-prima"><span>🪜</span><div><b>Prima, spezzala in passi</b><p>Con la testa confusa la tappa sembra una montagna. Il tuo agente personale la spezza in passi da pochi minuti, e il primo diventa ovvio.</p><button type="button" class="ghostmini" onclick="if(typeof stScompChiedi===\'function\')stScompChiedi(OT2.riga, stDayKey(\'today\'))">Scomponi in passi</button></div></div>';
  if (OT2.respirato) return '<div class="orc-prima fatto"><span>🌬️</span><div><b>Respiro fatto</b><p>Il battito è più lento. Adesso la tappa pesa meno.</p></div></div>';
  const ansia = u.esercizio === 'rilassamento';
  return '<div class="orc-prima"><span>🌬️</span><div><b>' + (ansia ? 'Prima, due minuti di respiro' : 'Prima, un minuto di respiro che sveglia') + '</b><p>'
    + (ansia ? 'Con l’ansia addosso la tappa pesa il doppio. Il respiro Rilassamento, quattro secondi dentro e sei fuori, rallenta il battito e spegne l’allarme del corpo.' : 'Con la stanchezza addosso anche dieci minuti sembrano tanti. Il respiro Motivazione, quattro secondi dentro e due fuori, sveglia il corpo e l’attenzione.')
    + '</p><button type="button" class="ghostmini" onclick="orcRespira()">' + (ansia ? 'Respira 2 minuti' : 'Respira 1 minuto') + '</button></div></div>';
}
function orcRespira(){
  const u = ORC_UMORI.filter(function(x){ return x.k === OT2.umore; })[0]; if (!u || typeof rsApri !== 'function') return;
  rsApri({ tecnica: u.esercizio, durata: u.esercizio === 'rilassamento' ? 120 : 60, libera: u.esercizio, dopo: function(fatto){ if (fatto) OT2.respirato = true; goId('s-oracolo'); orcPaint(); } });
}
function orcLibera(){ const i = document.getElementById('orcLibera'); const v = i ? i.value.trim() : ''; if (!v){ toast('Scrivi la cosa che rimandi'); return; } OT2.riga = v; OT2.passo = 3; orcPaint(); }
/** La bottiglia: le aree del campo nel corpo, il collo con l'unica area da mettere a fuoco. */
function orcBottiglia(aree, collo){
  const altre = aree.filter(function(a){ return a !== collo; });
  const righe = altre.map(function(a, i){ const y = 215 + i * 36; return '<text x="160" y="' + y + '" text-anchor="middle" class="orc-area">' + orcEsc(a) + '</text>'; }).join('');
  /* la bottiglia grande quanto lo schermo: il collo e' largo abbastanza da tenere il nome dell'area */
  return '<svg class="orc-bott" viewBox="0 0 320 440" aria-hidden="true">'
    + '<text x="160" y="18" text-anchor="middle" class="orc-collo-eti">IL COLLO DI BOTTIGLIA</text>'
    /* 0.9.214: il fianco sinistro saliva fino a 238 invece che a 208, e il collo era sbilenco */
    + '<path d="M100 30h120v14H100zM106 44h108v52c0 12 8 20 20 28 30 20 54 46 54 84v176c0 14-11 24-24 24H56c-13 0-24-10-24-24V208c0-38 24-64 54-84 12-8 20-16 20-28z" fill="#EAF2FF" stroke="#9DB7D6" stroke-width="2.5"/>'
    + '<rect x="110" y="48" width="100" height="60" rx="10" fill="#FFE3E6" stroke="#E63946" stroke-width="2.5"/>'
    + '<text x="160" y="84" text-anchor="middle" class="orc-collo"' + (String(collo).length > 9 ? ' style="font-size:' + (String(collo).length > 12 ? 12 : 14) + 'px"' : '') + '>' + orcEsc(collo) + '</text>'
    + '<text x="160" y="178" text-anchor="middle" class="orc-area-eti">TUTTO IL RESTO ASPETTA</text>'
    + righe + '</svg>';
}
function orcNelFoglio(){
  const t = OT2.riga; if (!t) return;
  try{
    const day = stDayKey('today'); const righe = stRigheDi(day);
    if (righe.indexOf(t) < 0){ localStorage.setItem('fl_notes_' + day, righe.concat([t]).join('\n')); try{ if (typeof fsToccato === 'function') fsToccato(day); }catch(_){ } }
    toast('È nel foglio di oggi');
  }catch(_){ }
}
function orcVia(){
  orcNelFoglio();
  try{ flVibra([20, 30, 60]); }catch(_){ }
  goId('s-home'); try{ switchTab('sveglia'); }catch(_){ }
  setTimeout(function(){ try{ const p = ffPref(); p.minutes = Math.min(OT2.tempo, OT2.energia <= 1 ? 10 : 25); ffSavePref(); }catch(_){ } try{ if (typeof stGoFocus === 'function') stGoFocus(); }catch(_){ } }, 350);
}
(function(){
  const css = [
    '#orcBody{padding:0 18px}.orc-dots{display:flex;justify-content:center;gap:6px;margin:14px 0 6px}.orc-dots i{width:8px;height:8px;border-radius:50%;background:var(--line)}.orc-dots i.on{background:#0075E3}',
    '.orc-genio{text-align:center;margin:6px 0 10px}.orc-genio img{height:120px;width:auto;filter:drop-shadow(0 10px 20px rgba(0,0,0,.25))}',
    '.orc-q{margin:0 0 16px;text-align:center;font:600 18px/1.45 var(--font-body);color:var(--navy)}body.dark .orc-q{color:#fff}.orc-q b{color:#0075E3}',
    '.orc-opz{display:grid;grid-template-columns:1fr 1fr;gap:12px}.orc-opz button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:18px 10px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);font:700 14px var(--font-body);color:var(--navy);cursor:pointer}.orc-opz button span{font-size:30px}.orc-opz button.on{border-color:#0075E3;background:rgba(0,117,227,.1)}body.dark .orc-opz button{background:#12203A;border-color:#22345A;color:#fff}',
    '.orc-lista{display:flex;flex-direction:column;gap:8px;margin-bottom:14px}.orc-lista button{text-align:left;padding:14px 16px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);font:600 14.5px/1.4 var(--font-body);color:var(--navy);cursor:pointer}.orc-lista button.on{border-color:#0075E3}body.dark .orc-lista button{background:#12203A;border-color:#22345A;color:#fff}.orc-libera{display:flex;gap:8px;align-items:center}.orc-libera .fin{flex:1;margin:0}',
    '.orc-eti{margin:0;text-align:center;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.orc-h{margin:6px 0 10px;text-align:center;font:800 22px/1.3 var(--font-display);color:var(--navy)}body.dark .orc-h{color:#fff}',
    '.orc-bott{display:block;width:100%;max-width:340px;height:auto;margin:6px auto 0}.orc-area{font:600 17px var(--font-body);fill:#6B7A90}.orc-area-eti{font:800 10px var(--font-body);letter-spacing:.12em;fill:#9DB7D6}.orc-collo{font:800 18px var(--font-body);fill:#B91C2C}.orc-collo-eti{font:800 11px var(--font-body);letter-spacing:.12em;fill:#E63946}',
    '.orc-p{margin:14px 0 0;text-align:center;font:500 14px/1.55 var(--font-body);color:var(--muted)}.orc-p b{color:var(--navy)}body.dark .orc-p b{color:#fff}',
    '.orc-card{display:flex;gap:12px;align-items:center;margin:18px 0 0;padding:16px;border-radius:18px;background:#E6F2FF}.orc-card span{font-size:28px}.orc-card p{margin:0;font:600 14.5px/1.5 var(--font-body);color:#001E44}',
    '.orc-cta{width:100%;margin-top:20px;background:#E63946 !important;color:#fff !important}',
    '.orc-umori{grid-template-columns:1fr 1fr}.orc-umori button:first-child{grid-column:1 / -1}',
    '.orc-prima{display:flex;gap:12px;align-items:flex-start;margin:18px 0 0;padding:16px;border-radius:18px;border:1.5px solid #8CC6FF;background:rgba(140,198,255,.14);text-align:left}.orc-prima > span{font-size:28px}.orc-prima b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .orc-prima b{color:#fff}.orc-prima p{margin:4px 0 10px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}.orc-prima.fatto{border-color:#0075E3;background:rgba(0,117,227,.08)}.orc-prima.fatto p{margin-bottom:0}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
