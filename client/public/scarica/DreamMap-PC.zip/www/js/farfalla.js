/* ===========================================================================================
   L'EFFETTO FARFALLA (0.9.254 → 0.9.273) — le decisioni alla Until Dawn

   0.9.273, Andrea: il pannello «Capitolo 1 · Effetto farfalla — Questa scelta avrà conseguenze» era
   un copy che mette pressione e suona come una minaccia. L'effetto farfalla e' un'altra cosa: "sei
   a una decisione da una vita completamente diversa". E la scelta non sta piu' in un pannello a
   parte: e' un LIVELLO della mappa alla Duolingo (sentiero-mappa.js, nodo «strada», capitolo 1),
   il momento in cui comincia tutto. Come in Until Dawn:
   - la scena scura, la musica dell'intro del Genio (musica.js, muIntro), due scelte in tempo reale
     che si prendono TENENDO PREMUTO (l'anello si riempie), senza un conto alla rovescia che spinge;
   - scelto, le farfalle attraversano lo schermo (faFarfalle): la storia ha preso un'altra strada.
   Lo stesso motore fa la scelta della Modalita' severa (pillola rossa, pillola blu: porte.js).

   LE SCELTE NON SI RIPRESENTANO. Il livello fatto resta fatto. Si cambiano solo:
   - dalle Impostazioni, «Le tue scelte» (settings.js chiama faCambia);
   - quando il Genio lo propone, la «seconda chance» (faSecondaChanceHtml, nel sentiero): se dopo
     una settimana la strada scelta non sta portando risultati, chiede se provare l'altra. Lo sa
     anche l'agente (agente.js legge faContestoAgente).
   =========================================================================================== */
const FA_KEY = 'fl_farfalla';          // [{ at, giorno, scelta: 'mia'|'rotta', cap }]  la strada
const FA_SEV_KEY = 'fl_scelta_severa';  // { at, scelta: 'rossa'|'blu' }                 la pillola
const FA_CHANCE_KEY = 'fl_fa_chance';   // ora dell'ultima seconda chance proposta
const FA = { in: false, dopo: null };
const FA_NOMI = { mia: 'Pianifico io', rotta: 'Seguo la strada del Genio' };
const FA_PILLOLE = { rossa: 'Pillola rossa', blu: 'Pillola blu' };
function faEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function faLista(){ try{ return JSON.parse(localStorage.getItem(FA_KEY) || '[]') || []; }catch(_){ return []; } }
function faSalva(l){ try{ localStorage.setItem(FA_KEY, JSON.stringify(l.slice(-40))); }catch(_){ } }
function faOggi(){ const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
/** La strada scelta adesso: { scelta, at } o null. */
function faStrada(){ const l = faLista(); return l.length ? l[l.length - 1] : null; }
function faSevera(){ try{ return JSON.parse(localStorage.getItem(FA_SEV_KEY) || 'null'); }catch(_){ return null; } }
/** I fatti da un momento in poi: tappe, sessioni, giorni vinti e persi. */
function faDopo(da){
  const o = { tappe: 0, ff: 0, min: 0, vinti: 0, persi: 0 };
  try{ const g = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; Object.keys(g).forEach(function(k){ if (g[k] > 0 && new Date(k + 'T12:00:00').getTime() >= da - 43200000) o.tappe += g[k]; }); }catch(_){ }
  try{ (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){ if (x && x.ok && !x.meditazione && x.at >= da){ o.ff++; o.min += (x.spentMs || 0) / 60000; } }); }catch(_){ }
  try{
    if (typeof piPunti === 'function'){
      const giorni = Math.min(60, Math.floor((Date.now() - da) / 86400000) + 1);
      for (let i = 0; i < giorni; i++){ const x = new Date(); x.setHours(12, 0, 0, 0); x.setDate(x.getDate() - i); if (x.getTime() < da - 43200000) break; const p = piPunti(piGiorno(x.getTime())); if (p.nuovo > p.vecchio) o.vinti++; else if (p.nuovo < p.vecchio) o.persi++; }
    }
  }catch(_){ }
  return o;
}

/* ---------------------------------------------------------------- la scena della scelta
   cfg = { kick, titolo, sotto, opzioni: [{ k, ico, n, s, colore }], attuale, onScelta(k), dopoTitolo(k), dopoSotto(k), annulla } */
function faScena(cfg){
  FA.cfg = cfg;
  let w = document.getElementById('faScena');
  if (!w){ w = document.createElement('div'); w.id = 'faScena'; w.className = 'fa-scena'; document.body.appendChild(w); }
  /* 0.9.288: il titolo bianco diventava blu scuro dopo un attimo: la guardia del contrasto (darkfix.js) non legge il
     gradiente della scena e vedeva sotto la pagina chiara. La scena dice da se' che il suo testo e' giusto. */
  w.setAttribute('data-cg-no', '');
  /* 0.9.280, Andrea (le pillole): "troppo testo, il nero grigio non e' il mio brand, il titolo non con quel font,
     un elemento alla volta, e due pannelli rettangolari con il bordo che si illumina tenendo premuto, che
     racchiudono anche il testo: devono sembrare un bivio cliccabile, non due immagini". cfg.pannelli */
  /* 0.9.288, Andrea: "trasforma la domanda in una rappresentazione della decisione: una strada che si divide in due".
     cfg.bivio disegna il bivio (bivio.js) sopra ai due pannelli: tenuto premuto un pannello, la luce imbocca quella
     strada e l'altra si spegne. */
  const bivio = !!cfg.bivio && cfg.opzioni.length === 2 && typeof bivSvg === 'function';
  if (bivio) cfg.pannelli = true;
  w.classList.toggle('fa-pannelli', !!cfg.pannelli);
  w.classList.toggle('fa-vert', !!cfg.verticale && !bivio);
  w.classList.toggle('fa-bivio', bivio);
  w.innerHTML = '<div class="fa-nebbia"></div><div class="fa-in">'
    + '<p class="fa-kick">' + faEsc(cfg.kick || 'Effetto farfalla') + '</p>'
    + '<h2>' + faEsc(cfg.titolo) + '</h2>'
    + (cfg.sotto ? '<p class="fa-sotto">' + faEsc(cfg.sotto) + '</p>' : '')
    + (bivio ? bivSvg({ sx: { t: cfg.opzioni[0].n, s: cfg.opzioni[0].cartello || '', tinta: cfg.opzioni[0].tinta || '' }, dx: { t: cfg.opzioni[1].n, s: cfg.opzioni[1].cartello || '', tinta: cfg.opzioni[1].tinta || '' }, scuro: cfg.bivioScuro || '' }) : '')
    + '<div class="fa-qte">' + cfg.opzioni.map(function(o){
        if (cfg.pannelli) return '<button type="button" class="fa-op fa-pan' + (cfg.attuale === o.k ? ' attuale' : '') + (o.fondo ? ' tinta' : '') + '" data-k="' + o.k + '" style="--c:' + (o.colore || '#FFFFFF') + (o.fondo ? ';--f:' + o.fondo : '') + '">'
          + '<svg class="fa-bordo" aria-hidden="true"><rect class="fa-traccia" rx="22" ry="22"/><rect class="fa-pieno" rx="22" ry="22" pathLength="100"/></svg>'
          + '<i class="fa-pan-ico">' + o.ico + '</i><b>' + faEsc(o.n) + '</b><small>' + faEsc(o.s) + '</small>'
          + (cfg.attuale === o.k ? '<em>' + faEsc(cfg.attualeEti || 'la tua scelta di adesso') + '</em>' : '') + '</button>';
        return '<button type="button" class="fa-op' + (cfg.attuale === o.k ? ' attuale' : '') + '" data-k="' + o.k + '" style="--c:' + (o.colore || '#FFFFFF') + '">'
          + '<span class="fa-anello"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="fa-traccia" cx="50" cy="50" r="44"/><circle class="fa-pieno" cx="50" cy="50" r="44"/></svg><i>' + o.ico + '</i></span>'
          + '<b>' + faEsc(o.n) + '</b><small>' + faEsc(o.s) + '</small>'
          + (cfg.attuale === o.k ? '<em>la tua scelta di adesso</em>' : '') + '</button>';
      }).join('') + '</div>'
    + (cfg.dopoHtml || '')
    + '<p class="fa-hint">Tieni premuto per scegliere</p>'
    + '<button type="button" class="fa-x" onclick="faChiudi()">Non adesso</button></div>';
  w.hidden = false; FA.in = true;
  if (bivio) bivPronto(w);
  w.querySelectorAll('.fa-op').forEach(faTieni);
  try{ flVibra([10, 40, 20]); }catch(_){ }
  try{ if (typeof muIntro === 'function') muIntro(); }catch(_){ }
}
/* TENERE PREMUTO come in Until Dawn: l'anello si riempie in 1,1 s; lasciando prima si svuota. Niente tempo che
   scade: la scelta la fa chi la tiene, non il conto alla rovescia. */
function faTieni(b){
  let t0 = 0, raf = 0, vibr = 0;
  const pieno = b.querySelector('.fa-pieno');
  /* il pannello rettangolare: il bordo segue la misura vera del pulsante (pathLength = 100) */
  const rett = pieno.tagName.toLowerCase() === 'rect';
  if (rett){
    const misura = function(){ const W = b.offsetWidth, H = b.offsetHeight; if (!W) return; b.querySelectorAll('.fa-bordo rect').forEach(function(r){ r.setAttribute('x', 1.5); r.setAttribute('y', 1.5); r.setAttribute('width', Math.max(0, W - 3)); r.setAttribute('height', Math.max(0, H - 3)); }); };
    misura(); setTimeout(misura, 60); setTimeout(misura, 700);
  }
  const DUR = 1100, L = rett ? 100 : 2 * Math.PI * 44;
  pieno.style.strokeDasharray = L; pieno.style.strokeDashoffset = L;
  /* 0.9.299, Andrea: "non mi piace quel puntino in alto a sinistra da cui parte il bordo prima ancora di tenere premuto".
     Con lunghezza zero l'estremita' arrotondata del tratto disegna un punto: il tratto resta spento finche' non parte */
  pieno.style.opacity = '0';
  const giro = function(){
    const p = Math.min(1, (performance.now() - t0) / DUR);
    pieno.style.opacity = p > 0.01 ? '1' : '0';
    pieno.style.strokeDashoffset = String(L * (1 - p));
    if (p >= 1){ stop(true); return; }
    if (performance.now() - vibr > 180){ vibr = performance.now(); try{ flVibra(6); }catch(_){ } }
    raf = requestAnimationFrame(giro);
  };
  /* 0.9.288, Andrea: "trascinando il dito sopra alle tre strade per scorrere, lo prende come se tenessi premuto". Il
     tocco non blocca piu' lo scorrimento della pagina (niente preventDefault, niente cattura): l'anello parte dopo un
     attimo, e se il dito si muove di piu' di 10 px (o la pagina comincia a scorrere) la pressione si annulla. */
  let attesa = 0, x0 = 0, y0 = 0;
  const via = function(e){
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    x0 = e.clientX; y0 = e.clientY;
    clearTimeout(attesa);
    attesa = setTimeout(function(){
      t0 = performance.now(); vibr = 0; b.classList.add('premo');
      cancelAnimationFrame(raf); raf = requestAnimationFrame(giro);
    }, e.pointerType === 'mouse' ? 0 : 140);
  };
  const muove = function(e){
    if (!attesa && !raf) return;
    if (Math.abs(e.clientX - x0) > 10 || Math.abs(e.clientY - y0) > 10){ clearTimeout(attesa); attesa = 0; if (raf) stop(false); }
  };
  const stop = function(fatto){
    cancelAnimationFrame(raf); raf = 0; b.classList.remove('premo');
    if (fatto === true){ faScegliCfg(b.dataset.k); return; }
    pieno.style.transition = 'stroke-dashoffset .35s ease'; pieno.style.strokeDashoffset = L;
    setTimeout(function(){ pieno.style.transition = ''; pieno.style.opacity = '0'; }, 380);
  };
  b.addEventListener('pointerdown', via);
  b.addEventListener('pointermove', muove);
  b.addEventListener('pointerup', function(){ clearTimeout(attesa); attesa = 0; if (raf) stop(false); });
  b.addEventListener('pointercancel', function(){ clearTimeout(attesa); attesa = 0; if (raf) stop(false); });
  b.addEventListener('pointerleave', function(){ clearTimeout(attesa); attesa = 0; if (raf) stop(false); });
  b.style.touchAction = 'pan-y';
  b.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  /* da tastiera (o con il lettore dello schermo) Invio vale come tenere premuto */
  b.addEventListener('keydown', function(e){ if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); faScegliCfg(b.dataset.k); } });
}
function faChiudi(){
  const w = document.getElementById('faScena'); if (w) w.hidden = true; FA.in = false;
  try{ if (typeof muIntroOff === 'function') muIntroOff(); }catch(_){ }
}
function faScegliCfg(k){
  const cfg = FA.cfg; if (!cfg) return;
  const w = document.getElementById('faScena');
  const biv = w && !w.hidden ? w.querySelector('.biv') : null;
  if (biv && !FA.vaiInCorso){
    FA.vaiInCorso = true;
    const i = cfg.opzioni.findIndex(function(o){ return o.k === k; });
    /* 0.9.302, Andrea: "i due pannelli si avvicinano e si attaccano come attratti da una calamita". La scena prendeva la
       classe fa-bivio-via, che e' anche il pulsante "Hai scelto la pillola" di porte.js: il suo padding 12px 14px, il
       centrato e le pillole 12x28 finivano sulla scena intera mentre la luce partiva. Nome suo, e i pannelli restano fermi. */
    w.classList.add('fa-scelta-via');
    bivVai(biv, i === 0 ? 'sx' : 'dx', function(){ FA.vaiInCorso = false; faScegliProcedi(cfg, k); });
    return;
  }
  faScegliProcedi(cfg, k);
}
function faScegliProcedi(cfg, k){
  const w = document.getElementById('faScena'); if (w){ w.hidden = true; w.classList.remove('fa-scelta-via'); } FA.in = false;
  try{ flVibra([20, 30, 60]); }catch(_){ }
  try{ cfg.onScelta(k); }catch(_){ }
  try{ if (typeof fsScelteDipingi === 'function') fsScelteDipingi(); }catch(_){ }
  /* 0.9.288, Andrea: "quando volano le farfalle la musica e' sempre la stessa: in Until Dawn cambia, e fa capire che il
     corso del futuro e' appena cambiato". La musica dell'intro si spegne e parte quella delle farfalle (musica.js). */
  try{ if (typeof muIntroOff === 'function') muIntroOff(); }catch(_){ }
  /* 0.9.297: una scelta che non cambia strada (Resto come oggi, in Rientra in rotta) non fa volare le farfalle */
  if (typeof cfg.senzaFarfalle === 'function' && cfg.senzaFarfalle(k)){ try{ if (typeof cfg.poi === 'function') cfg.poi(k); }catch(_){ } return; }
  try{ if (typeof muFarfalla === 'function') muFarfalla(); else if (typeof muIntro === 'function') muIntro(); }catch(_){ }
  faFarfalle(cfg.dopoTitolo ? cfg.dopoTitolo(k) : 'La tua storia ha preso un’altra strada', cfg.dopoSotto ? cfg.dopoSotto(k) : '', function(){
    try{ if (typeof muIntroOff === 'function') muIntroOff(); }catch(_){ }
    try{ if (typeof cfg.poi === 'function') cfg.poi(k); }catch(_){ }
  });
}

/* ---------------------------------------------------------------- le farfalle (come la schermata di Until Dawn)
   Uno sciame grigio che attraversa lo schermo scuro dal basso a sinistra verso l'alto a destra, ogni farfalla con
   le ali che battono e una grandezza sua, e al centro la frase. Disegnato su un canvas: niente video da scaricare. */
function faFarfalle(titolo, sotto, poi){
  let w = document.getElementById('faVolo');
  if (!w){ w = document.createElement('div'); w.id = 'faVolo'; w.className = 'fa-volo'; document.body.appendChild(w); }
  w.innerHTML = '<canvas></canvas><div class="fa-volo-t"><b>' + faEsc(titolo) + '</b>' + (sotto ? '<small>' + faEsc(sotto) + '</small>' : '') + '</div><button type="button" class="fa-volo-x">Tocca per continuare</button>';
  w.hidden = false;
  const cv = w.querySelector('canvas'), g = cv.getContext('2d');
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const dim = function(){ const r = w.getBoundingClientRect(); cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); cv.style.width = r.width + 'px'; cv.style.height = r.height + 'px'; return r; };
  let R = dim();
  const N = 110, F = [];
  for (let i = 0; i < N; i++){
    const piccola = Math.random() < 0.7;
    F.push({
      x: -0.15 * R.width + Math.random() * R.width * 0.55, y: R.height * (0.75 + Math.random() * 0.45),
      s: piccola ? 5 + Math.random() * 9 : 14 + Math.random() * 22,
      vx: 0.9 + Math.random() * 1.4, vy: -(1.1 + Math.random() * 1.6),
      fase: Math.random() * Math.PI * 2, batti: 9 + Math.random() * 7,
      onda: Math.random() * Math.PI * 2, nasce: Math.random() * 2600,
      grigio: 120 + Math.floor(Math.random() * 60), a: 0.45 + Math.random() * 0.45
    });
  }
  const farfalla = function(x, y, s, ali, col){
    g.save(); g.translate(x, y); g.rotate(0.55);
    g.fillStyle = col;
    [-1, 1].forEach(function(lato){
      g.save(); g.scale(lato * Math.max(0.12, Math.abs(ali)), 1);
      g.beginPath(); g.moveTo(0, 0);
      g.bezierCurveTo(s * 0.35, -s * 0.95, s * 1.05, -s * 0.85, s * 0.9, -s * 0.2);
      g.bezierCurveTo(s * 0.85, s * 0.1, s * 0.4, s * 0.05, 0, 0);
      g.bezierCurveTo(s * 0.35, s * 0.15, s * 0.8, s * 0.4, s * 0.55, s * 0.75);
      g.bezierCurveTo(s * 0.35, s * 0.95, s * 0.1, s * 0.4, 0, 0);
      g.fill(); g.restore();
    });
    g.fillRect(-s * 0.04, -s * 0.35, s * 0.08, s * 0.8);
    g.restore();
  };
  const t0 = performance.now(); let raf = 0, fine = false;
  const DURATA = 7200;
  const giro = function(t){
    const el = t - t0;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, R.width, R.height);
    for (let i = 0; i < F.length; i++){
      const f = F[i]; if (el < f.nasce) continue;
      const k = (el - f.nasce) / 16.7;
      const x = f.x + f.vx * k + Math.sin(f.onda + k * 0.035) * 22;
      const y = f.y + f.vy * k + Math.cos(f.onda + k * 0.03) * 10;
      if (x > R.width + 60 || y < -60) continue;
      const ali = Math.sin(f.fase + (el / 1000) * f.batti);
      farfalla(x, y, f.s, ali, 'rgba(' + f.grigio + ',' + f.grigio + ',' + (f.grigio + 4) + ',' + f.a + ')');
    }
    if (el < DURATA && !fine) raf = requestAnimationFrame(giro); else chiudi();
  };
  /* 0.9.288, Andrea: "quando volano le farfalle si esce per un attimo dal livello e si vede la scheda Roadmap". La scena
     dopo si apriva solo a dissolvenza finita: per 650 ms sotto c'era la scheda. Adesso si apre subito, sotto le
     farfalle, e le farfalle sfumano sopra di lei. */
  const chiudi = function(){
    if (fine) return; fine = true; cancelAnimationFrame(raf);
    try{ if (typeof muFarfallaOff === 'function') muFarfallaOff(); }catch(_){ }
    if (typeof poi === 'function') try{ poi(); }catch(_){ }
    w.classList.add('via');
    setTimeout(function(){ w.hidden = true; w.classList.remove('via'); w.innerHTML = ''; }, 650);
  };
  w.querySelector('.fa-volo-x').onclick = chiudi;
  addEventListener('resize', function(){ R = dim(); }, { once: true });
  raf = requestAnimationFrame(giro);
  try{ flVibra([10, 60, 10, 60, 10]); }catch(_){ }
}

/* ---------------------------------------------------------------- la strada: Pianifico io, o il Genio */
function faApriStrada(dopo){
  const cur = faStrada();
  /* 0.9.297, Andrea: "cambiando la scelta dalle impostazioni il capitolo sale ogni volta (8, 9, 10...)", e "il testo da
     quando hai scelto... e' superfluo, troppe cose nella pagina". Il numero contava le scelte, non i capitoli: via
     tutti e due. Restano il titolo, il bivio e i due pannelli. */
  faScena({
    kick: 'Effetto farfalla',
    titolo: 'Sei a una decisione da una vita completamente diversa.',
    sotto: '',
    bivio: true,
    attuale: cur ? cur.scelta : '',
    opzioni: [
      /* 0.9.295, Andrea: "da una parte improvvisi e puoi sbagliare strada, dall'altra segui un percorso gia' tracciato e
         arrivi prima"; dentro i pannelli piu' scuri, chiari solo verso il bordo, cosi' il testo si legge */
      /* 0.9.297, Andrea: "il rosso di Seguo il Genio sembra sangue, da film horror (Redrum di Shining): i pannelli devono
         essere uguali a quelli delle pillole". Stessa carta per tutti, il colore sta nel bordo. */
      { k: 'mia', ico: '🗺️', n: 'Pianifico io', s: 'Ogni giorno decidi tu cosa fare. Più libertà, ma improvvisi e puoi sbagliare strada.', colore: '#4FB8FF', tinta: 'blu' },
      { k: 'rotta', ico: '🧞', n: 'Seguo il Genio', s: 'Segui la roadmap di chi ha già realizzato un sogno come il tuo, senza improvvisare. Arrivi prima.', colore: '#FF5A66', tinta: 'rosso' }
    ],
    onScelta: function(k){
      const l = faLista();
      l.push({ at: Date.now(), giorno: faOggi(), scelta: k, cap: l.length + 1 });
      faSalva(l);
      try{ if (typeof mppVista === 'function') mppVista(k); }catch(_){ }
    },
    dopoTitolo: function(){ return 'La tua storia ha preso un’altra strada'; },
    dopoSotto: function(k){ return (k === 'rotta' ? 'Da oggi il Genio ti traccia la strada. Tu pensi solo alla prossima tappa.' : 'Da oggi la rotta la tracci tu, un giorno alla volta.') + ' Quando questa scelta cambierà qualcosa, comparirà la farfalla.'; },
    poi: function(k){ try{ if (typeof mppPaint === 'function') mppPaint(); }catch(_){ } if (typeof dopo === 'function') dopo(k); }
  });
}
/* compatibilita': chi chiamava faApri(verso, dopo) apre la stessa scena */
function faApri(verso, dopo){ faApriStrada(dopo); }

/* ---------------------------------------------------------------- la pillola: la Modalita' severa */
function faApriPillola(){ faScena(faPillolaCfg()); }
/* LA STESSA SCELTA DENTRO ALLA PAGINA (porte.js, in fondo a "Proteggi i tuoi sogni"): le due pillole si tengono
   premute li', senza aprire niente prima. Fatta la scelta, le farfalle. */
function faPillolaInlineHtml(){
  const c = faPillolaCfg();
  return '<div class="fa-inline"><p class="fa-kick">' + faEsc(c.kick) + '</p><h3>' + faEsc(c.titolo) + '</h3>'
    + '<div class="fa-qte">' + c.opzioni.map(function(o){
        return '<button type="button" class="fa-op" data-k="' + o.k + '" style="--c:' + o.colore + '"><span class="fa-anello"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="fa-traccia" cx="50" cy="50" r="44"/><circle class="fa-pieno" cx="50" cy="50" r="44"/></svg><i>' + o.ico + '</i></span><b>' + faEsc(o.n) + '</b><small>' + faEsc(o.s) + '</small></button>';
      }).join('') + '</div><p class="fa-hint">Tieni premuto per scegliere</p></div>';
}
function faInlineAggancia(box){
  if (!box) return;
  const ops = box.querySelectorAll('.fa-inline .fa-op'); if (!ops.length) return;
  FA.cfg = faPillolaCfg();
  ops.forEach(faTieni);
}
function faPillolaCfg(){
  const cur = faSevera();
  return {
    kick: 'Effetto farfalla',
    titolo: 'Una porta che si chiude, o tutto come oggi.',
    sotto: '',
    /* 0.9.297, Andrea: "la pillola blu non ha il bordo blu e non c'e' la strada che si divide, come in Pianifico io / Seguo il Genio" */
    bivio: true,
    attuale: cur ? cur.scelta : '',
    opzioni: [
      { k: 'rossa', ico: '<span class="fa-pill rossa"></span>', n: 'Pillola rossa', s: 'Chiudo la porta alle app che mi rubano il tempo.', colore: '#FF5A66', tinta: 'rosso' },
      { k: 'blu', ico: '<span class="fa-pill blu"></span>', n: 'Pillola blu', s: 'Resto come oggi, le app restano aperte.', colore: '#4FB8FF', tinta: 'blu' }
    ],
    onScelta: function(k){ try{ localStorage.setItem(FA_SEV_KEY, JSON.stringify({ at: Date.now(), scelta: k })); }catch(_){ } },
    dopoTitolo: function(k){ return k === 'rossa' ? 'Hai scelto la pillola rossa' : 'Hai scelto la pillola blu'; },
    dopoSotto: function(k){ return k === 'rossa' ? 'Adesso scegli per quanto: la chiave la tiene l’app.' : 'La porta resta aperta. La pillola rossa è qui quando la vuoi.'; },
    poi: function(k){
      try{ if (typeof svpPillolaPaint === 'function') svpPillolaPaint(); }catch(_){ }
      try{ if (typeof blPaginaApri === 'function' && document.getElementById('blSeveraFondo')){ const f = document.getElementById('blSeveraFondo'); if (f && typeof ptSeveraSezioneHtml === 'function') f.innerHTML = ptSeveraSezioneHtml(); } }catch(_){ }
      if (k === 'rossa'){ try{ if (typeof svpApri === 'function') svpApri(); }catch(_){ } }
    }
  };
}

/* ---------------------------------------------------------------- cambiarle: Impostazioni e seconda chance */
function faCambia(cosa){ if (cosa === 'pillola') faApriPillola(); else faApriStrada(); }
/* La seconda chance (Andrea): non un pannello fisso. Il Genio la propone una volta, nel sentiero, quando la strada
   scelta da almeno sette giorni non sta portando risultati (meno di tre tappe o due sessioni nell'ultima
   settimana), e non piu' di una volta ogni quattordici giorni. */
function faSecondaChance(){
  const u = faStrada(); if (!u) return null;
  if (Date.now() - u.at < 7 * 86400000) return null;
  let ultima = 0; try{ ultima = +localStorage.getItem(FA_CHANCE_KEY) || 0; }catch(_){ }
  if (Date.now() - ultima < 14 * 86400000) return null;
  const o = faDopo(Date.now() - 7 * 86400000);
  const debole = u.scelta === 'rotta' ? o.tappe < 3 : o.ff < 2;
  return debole ? { scelta: u.scelta, giorni: Math.floor((Date.now() - u.at) / 86400000) } : null;
}
function faSecondaChanceHtml(){
  const c = faSecondaChance(); if (!c) return '';
  const altra = c.scelta === 'rotta' ? 'mia' : 'rotta';
  return '<div class="fa-chance"><img src="img/genio/genio-pensa.png" alt=""><div><small>Il Genio ti chiede</small>'
    + '<b>' + c.giorni + ' giorni fa hai scelto "' + faEsc(FA_NOMI[c.scelta]) + '". Ti sta portando dove vuoi?</b>'
    + '<div class="fa-chance-b"><button type="button" onclick="faChanceRisposta(false)">Sì, continuo</button><button type="button" class="alt" onclick="faChanceRisposta(true)">Proviamo "' + faEsc(FA_NOMI[altra]) + '"</button></div></div></div>';
}
function faChanceRisposta(cambia){
  try{ localStorage.setItem(FA_CHANCE_KEY, String(Date.now())); }catch(_){ }
  if (cambia) faApriStrada(); else { try{ toast('Bene: si continua così'); }catch(_){ } }
  try{ if (typeof mppPaint === 'function') mppPaint(); }catch(_){ }
}
/** Per l'agente: le due scelte, quando, e come sono andate. */
function faContestoAgente(){
  const r = [];
  const u = faStrada();
  if (u){ const o = faDopo(u.at); r.push('Effetto farfalla, la strada: "' + FA_NOMI[u.scelta] + '" dal ' + u.giorno + ' (da allora ' + o.tappe + ' tappe, ' + o.ff + ' sessioni di Full Focus). La scelta va rispettata: non proporre di cambiarla. Solo se dopo settimane i dati dicono che non sta avanzando (tappe e sessioni ferme), proponigli come piano B di cambiare strada o di ricominciare il gioco.'); }
  const p = faSevera();
  if (p) r.push('Modalità severa: ha scelto la ' + FA_PILLOLE[p.scelta] + ' il ' + new Date(p.at).toLocaleDateString('it-IT') + '. Non proporre di cambiarla.');
  return r.join('\n');
}

/* ---------------------------------------------------------------- l'eco della farfalla (0.9.274)
   In Until Dawn, quando una scelta di prima cambia qualcosa, in alto a sinistra sbatte una farfalla: la conseguenza
   si VEDE nel momento in cui arriva, ed e' questo che fa sentire il peso della scelta (Bandersnatch invece ti fa
   tornare indietro e rifare: la responsabilita' sparisce). Qui la conseguenza e' misurata: le tappe fatte da chi
   segue il Genio, le sessioni di Full Focus di chi pianifica da se'. Ai traguardi 1, 3, 7, 15, 30, 60, 100 compare
   l'eco, una volta per traguardo e per scelta. Niente toni di colpa: un fatto, e di chi e' il merito. */
const FA_ECO_KEY = 'fl_fa_eco';
const FA_ECO_SOGLIE = [1, 3, 7, 15, 30, 60, 100];
let FA_ECO_T = 0;
function faEcoControlla(){
  clearTimeout(FA_ECO_T);
  FA_ECO_T = setTimeout(function(){
    try{
      if (FA.in) return;
      const u = faStrada(); if (!u) return;
      let st = {}; try{ st = JSON.parse(localStorage.getItem(FA_ECO_KEY) || '{}') || {}; }catch(_){ }
      if (st.at !== u.at){ st = { at: u.at, visti: 0 }; }
      const o = faDopo(u.at), n = u.scelta === 'rotta' ? o.tappe : o.ff;
      let i = st.visti || 0;
      while (i < FA_ECO_SOGLIE.length && n >= FA_ECO_SOGLIE[i]) i++;
      if (i === (st.visti || 0)){ try{ localStorage.setItem(FA_ECO_KEY, JSON.stringify(st)); }catch(_){ } return; }
      st.visti = i; try{ localStorage.setItem(FA_ECO_KEY, JSON.stringify(st)); }catch(_){ }
      const cosa = u.scelta === 'rotta' ? (n === 1 ? 'la prima tappa' : n + ' tappe') : (n === 1 ? 'la prima sessione di Full Focus' : n + ' sessioni di Full Focus');
      faEco(u.scelta === 'rotta' ? 'Hai scelto di seguire il Genio: da allora ' + cosa + '.' : 'Hai scelto di pianificare tu: da allora ' + cosa + '.');
    }catch(_){ }
  }, 900);
}
function faEco(testo){
  let e = document.getElementById('faEco');
  /* dentro al telefono: sul computer (la cornice) l'angolo in alto a sinistra e' quello del telefono, non della finestra */
  if (!e){ e = document.createElement('div'); e.id = 'faEco'; e.className = 'fa-eco'; e.setAttribute('role', 'status'); (document.getElementById('phone') || document.body).appendChild(e); }
  e.innerHTML = '<svg class="fa-eco-svg" viewBox="0 0 40 32" aria-hidden="true"><path fill="#D9DCE1" d="M20 16C14 4 3 2 2 9c-1 6 5 9 11 9-6 1-10 5-8 9 2 4 11 1 15-8zM20 16c6-12 17-14 18-7 1 6-5 9-11 9 6 1 10 5 8 9-2 4-11 1-15-8z"/><rect x="19.2" y="10" width="1.6" height="13" rx=".8" fill="#9EA3AA"/></svg><div><small>Effetto farfalla</small><b>' + faEsc(testo) + '</b></div>';
  e.classList.remove('su'); void e.offsetWidth; e.classList.add('su');
  try{ flVibra([8, 40, 8]); }catch(_){ }
  try{ if (typeof muJingle === 'function') muJingle('moneta'); }catch(_){ }
  clearTimeout(e._t); e._t = setTimeout(function(){ e.classList.remove('su'); }, 5200);
  e.onclick = function(){ e.classList.remove('su'); };
}
document.addEventListener('fl:tab', faEcoControlla);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') faEcoControlla(); });
setTimeout(faEcoControlla, 4000);

/* il vecchio pannello del bivio in fondo a Mappa e Roadmap non c'e' piu': la scelta e' un livello del sentiero */
function faCardPaint(){ const h = document.getElementById('mppFarfalla'); if (h) h.remove(); }
setTimeout(faCardPaint, 1500);

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.fa-scena{position:fixed;inset:0;z-index:9700;display:flex;align-items:center;justify-content:center;overflow:hidden;background:radial-gradient(110% 80% at 50% 35%,#1C1E22 0%,#0B0C0E 70%);color:#fff;animation:faIn .6s ease-out}.fa-scena[hidden]{display:none}',
    '@keyframes faIn{from{opacity:0}to{opacity:1}}',
    '.fa-nebbia{position:absolute;inset:-20%;background:radial-gradient(40% 30% at 30% 70%,rgba(255,255,255,.05),transparent 70%),radial-gradient(35% 25% at 75% 30%,rgba(255,255,255,.04),transparent 70%);animation:faNebbia 14s ease-in-out infinite alternate;pointer-events:none}',
    '@keyframes faNebbia{from{transform:translate3d(-3%,2%,0)}to{transform:translate3d(3%,-2%,0)}}',
    '.fa-in{position:relative;width:100%;max-width:440px;padding:28px 22px calc(24px + env(safe-area-inset-bottom));text-align:center}',
    '.fa-kick{margin:0 0 14px;font:600 12px Georgia,"Times New Roman",serif;letter-spacing:.32em;text-transform:uppercase;color:#C8CCD2}',
    '.fa-in h2{margin:0 0 14px;font:400 27px/1.3 Georgia,"Times New Roman",serif;letter-spacing:.02em}',
    '.fa-sotto{margin:0 auto 30px;max-width:34ch;font:500 14px/1.55 var(--font-body);color:#AEB4BC}',
    '.fa-qte{display:flex;gap:14px;justify-content:center}',
    '.fa-op{flex:1;max-width:190px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:6px 4px;border:0;background:transparent;color:#fff;cursor:pointer;-webkit-touch-callout:none;user-select:none;-webkit-user-select:none;touch-action:none}',
    '.fa-anello{position:relative;width:96px;height:96px;display:grid;place-items:center;transition:transform .2s}.fa-op.premo .fa-anello{transform:scale(1.06)}',
    '.fa-anello svg{position:absolute;inset:0;transform:rotate(-90deg)}.fa-traccia{fill:rgba(255,255,255,.04);stroke:rgba(255,255,255,.28);stroke-width:3}.fa-pieno{fill:none;stroke:var(--c);stroke-width:5;stroke-linecap:round;filter:drop-shadow(0 0 6px var(--c))}',
    '.fa-anello i{font-style:normal;font-size:36px;line-height:1}',
    '.fa-op b{margin-top:6px;font:600 15px Georgia,"Times New Roman",serif;letter-spacing:.18em;text-transform:uppercase}',
    '.fa-op small{font:500 12.5px/1.45 var(--font-body);color:#AEB4BC;max-width:22ch}',
    '.fa-op em{font:italic 500 11.5px var(--font-body);color:var(--c)}',
    '.fa-pill{display:block;width:22px;height:52px;border-radius:11px;box-shadow:0 8px 20px rgba(0,0,0,.4);background-image:linear-gradient(180deg,rgba(255,255,255,.45),rgba(255,255,255,0) 45%)}.fa-pill.rossa{background-color:#E63946}.fa-pill.blu{background-color:#0075E3}',
    /* 0.9.280: la scena delle pillole, nei colori del brand e a pannelli */
    '.fa-scena.fa-pannelli{background:radial-gradient(110% 80% at 50% 30%,#1A2F66 0%,#0B1A3D 55%,#050D22 100%)}',
    '.fa-pannelli .fa-in h2{font:800 26px/1.25 var(--font-display);letter-spacing:0;margin-bottom:34px}',
    '.fa-pannelli .fa-in > *{opacity:0;animation:faSu .6s cubic-bezier(.2,.8,.3,1) forwards}',
    '.fa-pannelli .fa-kick{animation-delay:.15s!important}.fa-pannelli .fa-in h2{animation-delay:.55s!important}.fa-pannelli .fa-qte{opacity:1!important;animation:none!important}',
    '.fa-pannelli .fa-hint{animation-delay:2s!important}.fa-pannelli .fa-x{animation-delay:2.2s!important}',
    /* 0.9.297, Andrea: "prima il sottotitolo, poi il titolo, poi la strada che si divide, poi i due pannelli" */
    '.fa-bivio .fa-in > .biv{animation-delay:1s!important}.fa-bivio .fa-pan:nth-child(1){animation-delay:1.55s}.fa-bivio .fa-pan:nth-child(2){animation-delay:1.85s}.fa-bivio .fa-hint{animation-delay:2.4s!important}.fa-bivio .fa-x{animation-delay:2.6s!important}',
    /* e tutti e due i pannelli con il bordo del loro colore, non solo quello scelto */
    '.fa-pan .fa-traccia{stroke:var(--c)!important;stroke-opacity:.42}.fa-pan.attuale .fa-traccia{stroke-opacity:.85}',
    '.fa-pannelli .fa-pan{opacity:0;animation:faSu .6s cubic-bezier(.2,.8,.3,1) forwards}.fa-pannelli .fa-pan:nth-child(1){animation-delay:1.1s}.fa-pannelli .fa-pan:nth-child(2){animation-delay:1.45s}',
    '@keyframes faSu{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}',
    '.fa-pan{position:relative;gap:10px!important;padding:22px 12px 20px!important;border-radius:22px!important;background:rgba(255,255,255,.06)!important}',
    '.fa-pan .fa-bordo{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none}',
    '.fa-pan .fa-traccia{fill:none;stroke:rgba(255,255,255,.26);stroke-width:1.5}',
    '.fa-pan .fa-pieno{fill:none;stroke:var(--c);stroke-width:3;stroke-linecap:round;filter:drop-shadow(0 0 8px var(--c))}',
    '.fa-pan.premo{box-shadow:0 0 26px -6px var(--c);transition:box-shadow .2s}.fa-pan.attuale .fa-traccia{stroke:var(--c);stroke-opacity:.6}',
    '.fa-pan-ico{font-style:normal;display:grid;place-items:center;height:60px}',
    '.fa-hint{margin:26px 0 0;font:600 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#7D848D}',
    '.fa-x{margin-top:14px;border:0;background:transparent;color:#8C939C;font:600 13px var(--font-body);cursor:pointer}',
    /* 0.9.290, Andrea: "il titolo e' attaccato all'intestazione, nessuna distanza". La scena era centrata e senza scorrimento:
       quando il contenuto era piu' alto dello schermo, si tagliava sopra (il titolo contro la barra) e sotto (Non adesso).
       Adesso parte dall'alto con la sua aria e scorre se serve. */
    '.fa-scena.fa-bivio{align-items:flex-start;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:pan-y}',
    '.fa-bivio .fa-in{margin:auto;padding:calc(env(safe-area-inset-top,0px) + 56px) 20px calc(env(safe-area-inset-bottom,0px) + 32px)}.fa-bivio .fa-kick{margin-bottom:12px}',
    '.fa-bivio .biv{margin:0 0 24px}.fa-bivio h2{margin-bottom:24px!important}',
    '.fa-pan.tinta{background:var(--f)!important}.fa-pan.tinta .fa-traccia{stroke:var(--c);stroke-opacity:.6}.fa-pan.tinta b{color:#fff}',
    '.fa-bivio .fa-pan-ico{font-size:46px;height:64px;line-height:1}',
    '.fa-bivio .fa-sotto{margin-bottom:14px!important}.fa-bivio .fa-qte{gap:12px}.fa-bivio .fa-pan{flex:1;max-width:none!important;min-height:0!important;padding:16px 12px!important}',
    '.fa-scelta-via .fa-qte,.fa-scelta-via .fa-hint,.fa-scelta-via .fa-x{opacity:.35;pointer-events:none;transition:opacity .4s}',
    '.fa-volo{position:fixed;inset:0;z-index:9800;background:#1F201F;opacity:1;transition:opacity .6s ease;animation:faIn .5s ease-out}.fa-volo[hidden]{display:none}.fa-volo.via{opacity:0}',
    '.fa-volo canvas{position:absolute;inset:0;display:block}',
    '.fa-volo-t{position:absolute;left:24px;right:24px;top:50%;transform:translateY(-50%);text-align:center;color:#EDEDED;pointer-events:none;animation:faTesto 7s ease forwards}',
    '.fa-volo-t b{display:block;font:400 24px/1.35 Georgia,"Times New Roman",serif;letter-spacing:.16em;text-transform:uppercase}',
    '.fa-volo-t small{display:block;margin:16px auto 0;max-width:30ch;font:500 14px/1.55 var(--font-body);color:#B9BDC2;letter-spacing:.02em}',
    '@keyframes faTesto{0%{opacity:0}18%{opacity:0}34%{opacity:1}88%{opacity:1}100%{opacity:.85}}',
    '.fa-volo-x{position:absolute;left:50%;bottom:calc(28px + env(safe-area-inset-bottom));transform:translateX(-50%);border:0;background:transparent;color:#8C939C;font:600 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;cursor:pointer}',
    /* la scelta dentro alla pagina: la stessa scena, in una card scura */
    '.fa-inline{position:relative;overflow:hidden;border-radius:24px;padding:24px 14px 20px;text-align:center;color:#fff;background:radial-gradient(120% 90% at 50% 20%,#24272C 0%,#0E0F12 75%)}',
    '.fa-inline h3{margin:0 0 20px;font:400 21px/1.3 Georgia,"Times New Roman",serif}.fa-inline .fa-hint{margin-top:16px}.fa-inline .fa-anello{width:84px;height:84px}',
    '.fa-bivio-via{display:flex;align-items:center;gap:10px;margin:0 0 12px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);font:600 13.5px var(--font-body);color:var(--navy)}body.dark .fa-bivio-via{background:#12203A;border-color:#22345A;color:#fff}.fa-bivio-via .fa-pill{width:12px;height:28px;border-radius:6px;flex:none}.fa-bivio-via small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    /* l'eco: in alto a sinistra come la farfalla di Until Dawn, entra, resta cinque secondi, esce */
    '.fa-eco{position:fixed;left:12px;top:calc(12px + env(safe-area-inset-top,0px));z-index:9900;display:flex;align-items:center;gap:10px;max-width:min(340px,calc(100% - 24px));padding:10px 14px 10px 10px;border-radius:16px;background:rgba(14,16,20,.92);color:#fff;box-shadow:0 10px 28px rgba(0,0,0,.35);transform:translate3d(-120%,0,0);opacity:0;transition:transform .45s cubic-bezier(.2,.8,.2,1),opacity .45s;pointer-events:none}',
    '.fa-eco.su{transform:none;opacity:1;pointer-events:auto}',
    '.fa-eco small{display:block;font:600 10px Georgia,"Times New Roman",serif;letter-spacing:.24em;text-transform:uppercase;color:#C8CCD2}.fa-eco b{display:block;margin-top:2px;font:600 13px/1.35 var(--font-body)}',
    '.fa-eco-svg{flex:none;width:32px;height:26px;animation:faEcoBatti .55s ease-in-out infinite alternate;will-change:transform}',
    '@keyframes faEcoBatti{from{transform:scaleX(1)}to{transform:scaleX(.45)}}',
    '.fa-chance{display:flex;gap:12px;align-items:flex-start;margin:0 18px 14px;padding:14px;border-radius:18px;background:linear-gradient(135deg,#1A2A5C,#0F2041);color:#fff}.fa-chance img{width:46px;height:auto;flex:none}',
    '.fa-chance small{display:block;font:800 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}.fa-chance b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}',
    '.fa-chance-b{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.fa-chance-b button{border:0;border-radius:99px;padding:8px 14px;background:rgba(255,255,255,.14);color:#fff;font:700 13px var(--font-body);cursor:pointer}.fa-chance-b button.alt{background:#BCE0FF;color:#14234A}'
  ].join('');
  document.head.appendChild(st);
})();
