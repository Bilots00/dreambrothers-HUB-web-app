/* ===========================================================================================
   COME STA LA TUA TESTA? — il Reset (0.9.211)

   Tre domande sulla testa di adesso (com'e', cosa ti ferma, quanto tempo hai per rimetterti in
   sesto) e il Genio propone l'esercizio giusto: il sospiro fisiologico, il respiro lento, il
   respiro che sveglia (solo di giorno), il caveau delle idee per svuotare la RAM, la pausa per
   gli occhi. La prima volta il Genio fa anche due domande sul tuo ritmo (pause o fine giornata,
   quanto dura una sessione prima di fermarti): servono al tuo agente personale per una rotta su misura.

   SE STAI BENE NON C'E' NESSUNA DIAGNOSI. Solo un riepilogo: la riserva di dopamina (quella che
   l'app stima dai tuoi ultimi giorni) e lo stress di adesso (da come hai risposto). Il testo
   dice cosa fa un esercizio, mai che cura qualcosa.
   =========================================================================================== */
const RST = { i: 0, r: {} };
const RST_PROF_KEY = 'fl_reset_profilo';
const RST_DOMANDE = [
  { k: 'testa', q: 'In questo momento, <b>come senti la testa</b>?', o: [
    ['giri', '🌀', 'A 3000 giri: caotica'], ['nebbia', '🌫️', 'Nella nebbia: stanchissima'], ['ansia', '😰', 'In ansia, sotto pressione'], ['forma', '🚀', 'In forma: carica']] },
  { k: 'ostacolo', q: 'Adesso, <b>qual è l’ostacolo principale</b>?', o: [
    ['idee', '💡', 'Troppe idee: la testa non si ferma'], ['motivazione', '🪫', 'Zero motivazione: niente si muove'], ['fisico', '🤕', 'Mal di testa e fatica fisica'], ['nessuno', '✅', 'Nessun ostacolo']] },
  { k: 'tempo', q: 'Per rimetterti in sesto, <b>quanto tempo hai</b>?', o: [
    ['1', '⏱️', 'Un minuto'], ['5', '⏳', 'Cinque minuti'], ['15', '🕐', 'Quindici minuti o più']] }
];
const RST_PROFILO = [
  { k: 'quando', q: 'Il Genio vuole conoscerti: preferisci esercizi <b>da fare nelle pause</b>, mentre lavori, o <b>per staccare a fine giornata</b>?', o: [
    ['pause', '☕', 'Nelle pause, mentre lavoro'], ['sera', '🌙', 'Per staccare a fine giornata'], ['entrambi', '🔁', 'Tutti e due']] },
  { k: 'sessione', q: 'Di solito, <b>quanto dura una tua sessione di lavoro</b> prima che ti fermi?', o: [
    ['30', '⏱️', 'Meno di mezz’ora'], ['60', '⏳', 'Da mezz’ora a un’ora'], ['120', '🕐', 'Da una a due ore'], ['240', '🕓', 'Più di due ore']] }
];
function rstEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function rstProfilo(){ try{ return JSON.parse(localStorage.getItem(RST_PROF_KEY) || 'null'); }catch(_){ return null; } }
/** Per il tuo agente personale: quando preferisci gli esercizi e quanto dura una sessione. */
function rstPerAgente(){
  const p = rstProfilo(); if (!p) return '';
  const q = { pause: 'nelle pause', sera: 'a fine giornata', entrambi: 'nelle pause e a fine giornata' }[p.quando] || '';
  const s = { '30': 'meno di mezz’ora', '60': 'da mezz’ora a un’ora', '120': 'da una a due ore', '240': 'più di due ore' }[p.sessione] || '';
  return 'Esercizi di recupero preferiti ' + q + '; una sessione di lavoro dura di solito ' + s + '.';
}
function rstLista(){ return (rstProfilo() ? [] : RST_PROFILO).concat(RST_DOMANDE); }

registerScreen('s-reset',
  '<div class="topbar"><button class="iconbtn" onclick="rstIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Come sta la tua testa?</b></div>'
  + '<div id="rstBody"></div><div class="spacer"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });
/* 0.9.350, Andrea: "le sfide del pannello Sfide si fanno su una schermata grigia: le voglio nell'ambientazione del Genio, il cielo stellato
   sopra le montagne" (lo sfondo di #s-genio, genio-intro.js) */
(function(){ const s = document.createElement('style'); s.textContent = '#s-reset{background:#00132B!important;color:#fff}#s-reset::before{content:"";position:fixed;inset:0;background:#00132B url("img/bg/montagne.jpg") center bottom/cover no-repeat;pointer-events:none;z-index:0}#s-reset::after{content:"";position:fixed;inset:0;background:linear-gradient(180deg,rgba(0,19,43,.25) 0%,rgba(0,19,43,.6) 55%,rgba(0,19,43,.9) 100%);pointer-events:none;z-index:0}#s-reset > *{position:relative;z-index:1}'
  + '#s-reset .blk-title,#s-reset h1,#s-reset h2,#s-reset h3,#s-reset .rst-q,#s-reset p,#s-reset small{color:#fff!important}#s-reset .iconbtn{background:rgba(255,255,255,.16)!important;color:#fff!important}#s-reset h2 b,#s-reset h2 span,#s-reset h2 em,#s-reset h2 strong,#s-reset .rst-q b,#s-reset .rst-q span{color:#8CC6FF!important}'; document.head.appendChild(s); })();
function rstApri(){ RST.i = 0; RST.r = {}; RST.lista = rstLista(); goId('s-reset'); rstPaint(); }
function rstIndietro(){ if (RST.i > 0 && RST.i <= RST.lista.length){ RST.i--; rstPaint(); return; } if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } } }
function rstRisp(j){
  const d = RST.lista[RST.i]; RST.r[d.k] = d.o[j][0];
  try{ flVibra(10); }catch(_){ }
  if (d.k === 'sessione' || d.k === 'quando'){
    const p = rstProfilo() || {}; p[d.k] = d.o[j][0]; p.at = Date.now();
    try{ localStorage.setItem(RST_PROF_KEY, JSON.stringify(p)); }catch(_){ }
  }
  RST.i++; rstPaint();
}
/** La dopamina stimata (dopamina.js) e lo stress di adesso, da 0 a 100. */
function rstLivelli(){
  let dop = null;
  try{ if (typeof DP !== 'undefined' && DP && isFinite(DP.L)) dop = Math.round(DP.L); }catch(_){ }
  const base = { giri: 65, nebbia: 50, ansia: 78, forma: 18 }[RST.r.testa] || 40;
  const piu = { idee: 10, motivazione: 6, fisico: 10, nessuno: -6 }[RST.r.ostacolo] || 0;
  return { dop: dop, stress: Math.max(5, Math.min(95, base + piu)) };
}
function rstStressTxt(v){ return v < 30 ? 'basso' : (v < 60 ? 'medio' : 'alto'); }
function rstConsigli(){
  const t = RST.r.testa, o = RST.r.ostacolo, min = +(RST.r.tempo || 5);
  const giorno = new Date().getHours() >= 7 && new Date().getHours() < 18;
  const c = [];
  const resp = function(k, sec, titolo, perche){ c.push({ ico: '🌬️', t: titolo, s: perche, durata: sec >= 60 ? Math.round(sec / 60) + ' min' : sec + ' s', via: 'rstRespira(\'' + k + '\',' + sec + ')' }); };
  if (o === 'idee' || t === 'giri'){
    c.push({ ico: '🔒', t: 'Scarica la RAM nel caveau', s: 'Scrivi tutte le idee che ti girano in testa: vanno al sicuro e spariscono dalla vista. La testa si ferma quando sa che non le perderà.', durata: '1 min', via: 'rstCaveau()' });
    if (min >= 5) resp('sospiro', 60, 'Il sospiro ciclico', 'Due inspirazioni dal naso e un’espirazione lunga: abbassa i giri in un minuto.');
  }
  if (t === 'ansia'){
    resp('sospiro', 60, 'Il sospiro ciclico', 'Il modo più rapido di abbassare l’agitazione: un minuto, alla scrivania.');
    if (min >= 5) resp(new Date().getHours() >= 20 ? 'distensione' : 'rilassamento', new Date().getHours() >= 20 ? 76 : 300, new Date().getHours() >= 20 ? 'Il 4-7-8 per dormire' : 'Rilassamento 4-6', 'Espirazioni più lunghe delle inspirazioni: il battito rallenta e l’allarme del corpo si spegne.');
  }
  if (t === 'nebbia' || o === 'motivazione'){
    if (giorno && min >= 5) resp('attivante', 135, 'Il respiro che sveglia', 'Un giro di Huberman Focus: trenta respiri profondi e una pausa a polmoni vuoti. Il corpo si sveglia, la testa si schiarisce. Solo di giorno, seduto.');
    else resp('rilassamento', 120, 'Rilassamento 4-6', 'A quest’ora la testa non va spinta: va calmata, perché domani riparta.');
    c.push({ ico: '⏱️', t: 'La regola dei cinque minuti', s: 'Cinque minuti di Full Focus sull’unica cosa, con il permesso di smettere dopo. La voglia arriva cominciando.', durata: '5 min', via: 'rstCinque()' });
  }
  if (o === 'fisico'){
    c.unshift({ ico: '👀', t: 'Palmi sugli occhi e regola 20-20-20', s: 'I palmi caldi sugli occhi chiusi, poi lo sguardo lontano: gli occhi e il collo si rilassano, il mal di testa da schermo cala.', durata: '2 min', via: 'rstOcchi()' });
  }
  if (!c.length) resp('sospiro', 60, 'Il sospiro ciclico', 'Un minuto per scaricare la tensione prima di ripartire.');
  const visti = {}; return c.filter(function(x){ if (visti[x.t]) return false; visti[x.t] = 1; return true; }).slice(0, 3);
}
function rstPaint(){
  const h = document.getElementById('rstBody'); if (!h) return;
  if (RST.i < RST.lista.length){
    const d = RST.lista[RST.i];
    h.innerHTML = '<div class="orc-dots">' + RST.lista.map(function(_, i){ return '<i class="' + (i <= RST.i ? 'on' : '') + '"></i>'; }).join('') + '</div>'
      + '<div class="orc-genio"><img src="img/genio/genio-pensa.png" alt=""></div><p class="orc-q">' + d.q + '</p>'
      + '<div class="orc-lista rst-opz">' + d.o.map(function(o, j){ return '<button type="button" onclick="rstRisp(' + j + ')"><span>' + o[1] + '</span>' + rstEsc(o[2]) + '</button>'; }).join('') + '</div>';
    return;
  }
  const L = rstLivelli();
  const livelli = '<div class="rst-livelli"><div><small>Riserva di dopamina</small><b>' + (L.dop == null ? '—' : L.dop + '%') + '</b><em>' + (L.dop == null ? 'si stima dai tuoi primi giorni' : 'stimata dai tuoi ultimi giorni') + '</em></div><div><small>Stress di adesso</small><b>' + rstStressTxt(L.stress) + '</b><em>da come ti senti</em></div></div>';
  try{ localStorage.setItem('fl_reset_ultimo', JSON.stringify({ r: RST.r, at: Date.now(), stress: L.stress })); }catch(_){ }
  if (RST.r.testa === 'forma' && RST.r.ostacolo === 'nessuno'){
    h.innerHTML = '<div class="rst-ok"><div class="orc-genio"><img src="img/genio/genio-rivela.png" alt=""></div><h2>Il tuo motore gira bene 🚀</h2>' + livelli
      + '<p>Continua così, e fermati per una pausa prima di finire le batterie: una pausa presa prima vale il doppio di una presa dopo.</p>'
      + '<button type="button" class="cta" onclick="goId(\'s-home\');switchTab(\'sveglia\')">Torna al lavoro</button></div>';
    return;
  }
  const c = rstConsigli();
  h.innerHTML = '<div class="orc-genio"><img src="img/genio/genio-rivela.png" alt=""></div><p class="orc-eti">Il Genio ti propone</p><h2 class="orc-h">' + (c.length === 1 ? 'Un esercizio, adesso' : c.length + ' esercizi: scegline uno') + '</h2>'
    + livelli
    + c.map(function(x){ return '<button type="button" class="rst-es" onclick="' + x.via + '"><span>' + x.ico + '</span><div><b>' + rstEsc(x.t) + '</b><p>' + rstEsc(x.s) + '</p></div><em>' + x.durata + '</em></button>'; }).join('')
    + '<p class="rst-nota">Sono esercizi per stare meglio adesso, non una diagnosi. Se la testa non si ferma da settimane, parlane con un medico.</p>';
}
function rstRespira(k, sec){ if (typeof rsApri === 'function') rsApri({ tecnica: k, durata: sec, libera: k, da: 'dream' }); }
function rstCaveau(){
  goId('s-home'); try{ switchTab('mappa'); if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ }
  setTimeout(function(){ try{ if (typeof stTabSet === 'function') stTabSet('oggi'); const a = document.getElementById('cvIn'); if (a){ a.scrollIntoView({ behavior: 'smooth', block: 'center' }); setTimeout(function(){ a.focus(); }, 400); } }catch(_){ } }, 500);
}
function rstCinque(){ goId('s-home'); try{ switchTab('sveglia'); }catch(_){ } setTimeout(function(){ try{ const p = ffPref(); p.minutes = 5; ffSavePref(); if (typeof stGoFocus === 'function') stGoFocus(); }catch(_){ } }, 350); }
/* ---- palmi sugli occhi e 20-20-20: una guida a tempo ---- */
const RST_OCCHI = [['Strofina le mani finché sono calde', 10], ['Chiudi gli occhi e appoggia i palmi, senza premere: buio totale', 60], ['Apri gli occhi piano e guarda un punto lontano, oltre i 6 metri', 20], ['Spalle giù, collo morbido: ruota piano la testa', 20]];
function rstOcchi(){
  let w = document.getElementById('rstGuida');
  if (!w){ w = document.createElement('div'); w.id = 'rstGuida'; w.className = 'rsp-sess'; document.body.appendChild(w); }
  let i = 0, fine = 0, t = 0;
  const passo = function(){
    if (i >= RST_OCCHI.length){ clearInterval(t); w.innerHTML = '<div class="rsp-fatto"><h2>Fatto</h2><p>Gli occhi e il collo hanno avuto la loro pausa. Ogni 20 minuti, 20 secondi lontano: lo sguardo ringrazia.</p><button type="button" class="cta rsp-via" onclick="document.getElementById(\'rstGuida\').remove()">Continua</button></div>'; return; }
    fine = Date.now() + RST_OCCHI[i][1] * 1000;
    w.innerHTML = '<div class="rsp-sess-top"><span>' + (i + 1) + ' di ' + RST_OCCHI.length + '</span><button type="button" onclick="document.getElementById(\'rstGuida\').remove()">Termina</button></div><div class="rst-g"><span>👀</span><b>' + rstEsc(RST_OCCHI[i][0]) + '</b><em id="rstGs"></em></div>';
    try{ flVibra(14); }catch(_){ }
  };
  passo();
  t = setInterval(function(){
    if (!document.body.contains(w)){ clearInterval(t); return; }
    const r = Math.max(0, fine - Date.now()); const s = document.getElementById('rstGs'); if (s) s.textContent = Math.ceil(r / 1000) + ' s';
    if (r <= 0){ i++; passo(); }
  }, 200);
}

(function(){
  const css = [
    '#rstBody{padding:0 18px}.rst-opz button{display:flex;align-items:center;gap:12px}.rst-opz button span{font-size:24px}',
    '.rst-livelli{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0 16px}.rst-livelli > div{padding:14px 12px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);text-align:center}body.dark .rst-livelli > div{background:#12203A;border-color:#22345A}.rst-livelli small{display:block;font:700 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}.rst-livelli b{display:block;margin:6px 0 2px;font:900 26px var(--font-display);color:#0075E3}.rst-livelli em{display:block;font:500 11.5px var(--font-body);font-style:normal;color:var(--muted)}',
    '.rst-es{display:flex;align-items:flex-start;gap:12px;width:100%;margin:0 0 10px;padding:16px 14px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer;box-shadow:0 3px 0 var(--line)}body.dark .rst-es{background:#12203A;border-color:#22345A;box-shadow:0 3px 0 #22345A}.rst-es > span{font-size:28px}.rst-es > div{flex:1}.rst-es b{display:block;font:800 15.5px var(--font-body);color:var(--navy)}body.dark .rst-es b{color:#fff}.rst-es p{margin:4px 0 0;font:500 13px/1.5 var(--font-body);color:var(--muted)}.rst-es em{flex:none;padding:5px 9px;border-radius:99px;background:rgba(0,117,227,.1);font:800 12px var(--font-body);font-style:normal;color:#0075E3}',
    '.rst-nota{margin:14px 0 0;font:500 12.5px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.rst-ok{text-align:center}.rst-ok h2{margin:6px 0 4px;font:800 24px var(--font-display);color:var(--navy)}body.dark .rst-ok h2{color:#fff}.rst-ok p{margin:0 0 18px;font:500 14.5px/1.55 var(--font-body);color:var(--muted)}.rst-ok .cta{width:100%}',
    '.rst-g{max-width:340px;text-align:center}.rst-g span{font-size:56px}.rst-g b{display:block;margin:16px 0 14px;font:700 21px/1.4 var(--font-body);color:#fff}.rst-g em{display:block;font:600 40px var(--font-body);font-style:normal;font-variant-numeric:tabular-nums;color:rgba(255,255,255,.85)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
