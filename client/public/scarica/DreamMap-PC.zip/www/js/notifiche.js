/* ===========================================================================================
   IL PERMESSO DELLE NOTIFICHE, CHIESTO DOVE SERVE

   Da Android 13 le notifiche vanno concesse a mano, e questa app lo chiedeva in un posto solo:
   la pagina delle Sveglie, e solo a chi ci entrava e leggeva l'avviso rosso. Chi accendeva il
   promemoria della sera senza esserci mai passato non concedeva niente — e `notify()` senza
   permesso non fallisce: non fa niente, in silenzio. La notifica delle 22:15 partiva davvero e
   il sistema la buttava.

   LA REGOLA CHE NE ESCE, e vale per qualsiasi permesso: si chiede nel momento in cui l'utente
   accende la cosa che ne ha bisogno. Non prima (non si capisce perché), non altrove (non ci
   passa), non dopo (è già troppo tardi).
   =========================================================================================== */

let NT_STATO = null;

async function ntStato(force){
  if (NT_STATO && !force) return NT_STATO;
  NT_STATO = { granted: true, canAsk: false };
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.notifState){
      const r = await NATIVE.notifState();
      NT_STATO = { granted: !!(r && r.granted), canAsk: !!(r && r.canAsk) };
    }
  }catch(_){ }
  return NT_STATO;
}

/**
 * Chiede il permesso, se manca.
 *
 * <p>Restituisce vero quando alla fine le notifiche sono accese. La richiesta di sistema porta
 * fuori dall'app, quindi al rientro si ricontrolla: l'avviso deve sparire da solo appena la
 * cosa è vera, o resta lì a dire una bugia.</p>
 */
async function ntChiedi(){
  const s = await ntStato(true);
  if (s.granted) return true;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.requestAlarmAccess){
      await NATIVE.requestAlarmAccess({ what: 'notifications' });
    }
  }catch(_){ }
  const ricontrolla = function(){ ntStato(true).then(function(){ ntAvvisoPaint(); }); };
  const rientro = function(){
    if (document.hidden) return;
    ricontrolla();
    setTimeout(ricontrolla, 900);
    setTimeout(ricontrolla, 2500);
    document.removeEventListener('visibilitychange', rientro);
  };
  document.addEventListener('visibilitychange', rientro);
  setTimeout(ricontrolla, 1500);
  return false;
}

/* L'avviso: compare solo dove una notifica è stata davvero chiesta dall'utente, e sparisce da
   solo. Si disegna in ogni contenitore con id che comincia per «ntWarn». */
function ntAvvisoHtml(){
  /* NON LO SAPPIAMO ANCORA = SI TACE. `NT_STATO` è null finché il motore non risponde, e la
     pagina si disegna prima: con la vecchia riga l'avviso rosso compariva a chi le notifiche
     le aveva concesse, e restava lì fino al giro successivo. Nel dubbio non si accusa. */
  if (!NT_STATO || NT_STATO.granted) return '';
  return '<div class="nt-warn" onclick="ntChiedi()">'
    + '<span>🔕</span><div><b>Le notifiche sono spente</b>'
    + '<small>Finché restano spente, questo promemoria non può farsi vedere. Tocca per attivarle.</small></div></div>';
}

function ntAvvisoPaint(){
  document.querySelectorAll('[id^="ntWarn"]').forEach(function(el){
    el.innerHTML = ntAvvisoHtml();
  });
}

(function ntStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.nt-warn{display:flex;align-items:center;gap:12px;text-align:left;margin-top:14px;',
      'background:rgba(229,81,95,.14);border:1px solid rgba(229,81,95,.45);border-radius:14px;',
      'padding:12px 14px;cursor:pointer}',
    '.nt-warn span{font-size:22px;line-height:1;flex:none}',
    '.nt-warn b{display:block;font:800 13px var(--font-body);color:#FF8A9B}',
    '.nt-warn small{display:block;margin-top:3px;font:500 11.5px/1.5 var(--font-body);color:rgba(200,218,242,.8)}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* Allo stato reale ci si allinea appena l'app è in piedi, e ogni volta che torna davanti: il
   permesso può essere stato tolto dalle impostazioni di sistema mentre l'app era chiusa. */
setTimeout(function(){ ntStato(true).then(ntAvvisoPaint); }, 2400);
/* E ogni volta che si apre una pagina che ha un posto per l'avviso: è lì che si vede, ed è lì
   che deve essere vero. */
document.addEventListener('fl:screen', function(){
  setTimeout(function(){
    if (!document.querySelector('[id^="ntWarn"]')) return;
    ntStato(true).then(ntAvvisoPaint);
  }, 120);
});
document.addEventListener('visibilitychange', function(){
  if (!document.hidden) ntStato(true).then(ntAvvisoPaint);
});
