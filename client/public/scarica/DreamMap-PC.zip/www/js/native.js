/* native.js - the bridge to the Android engine: the shared NATIVE handle on the Capacitor
   FocusLock plugin, the jump to the native engine page, and the hardware back button
   listener. In a plain browser NATIVE is null and every feature module degrades to a
   preview instead of pretending to block anything. */

/* ---------- NATIVE BRIDGE ---------- *
 * Everything below talks to the real blocking engine. When the page is opened in a plain
 * browser (no Capacitor) the calls simply no-op and the UI degrades to a preview, instead of
 * pretending to work — which was the whole problem with the old mock buttons.
 */
const NATIVE = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.FocusLock
  ? window.Capacitor.Plugins.FocusLock : null;

/* Lo schermo acceso (0.9.252). Durante il respiro e la dettatura il telefono si spegneva da solo
   (Andrea, 14/10/2026): qui si chiede ad Android di tenerlo acceso finche' la cosa dura, e si
   lascia andare appena finisce. Chi accende deve spegnere: ogni pezzo passa il suo nome, e lo
   schermo resta acceso finche' almeno uno lo chiede. Nel browser non fa niente. */
const FL_SCHERMO = {};
function flSchermoAcceso(chi, on){
  if (on) FL_SCHERMO[chi] = 1; else delete FL_SCHERMO[chi];
  const vuole = Object.keys(FL_SCHERMO).length > 0;
  try{ if (NATIVE && NATIVE.schermoAcceso) NATIVE.schermoAcceso({ on: vuole }); }catch(_){ }
}

/* La vibrazione: sul telefono passa dal motore nativo (navigator.vibrate nella WebView spesso
   non vibra affatto), nel browser resta navigator.vibrate. p = numero o [vibra, pausa, vibra...]
   come navigator.vibrate; amp = forza 1-255 per ogni tratto di vibrazione, facoltativa. */
/* Un colpetto di sistema (EFFECT_TICK / EFFECT_CLICK) per le tacche dei righelli, con ripiego su una vibrazione breve. */
function flTacca(forte){
  try{
    if (NATIVE && NATIVE.vibra){ NATIVE.vibra({ ms: [0, forte ? 14 : 8], amp: [0, forte ? 200 : 120], effetto: forte ? 'click' : 'tick' }).catch(function(){ }); return; }
    if (navigator.vibrate) navigator.vibrate(forte ? 14 : 8);
  }catch(_){ }
}
function flVibra(p, amp){
  try{
    const arr = Array.isArray(p) ? p.slice() : [p];
    if (NATIVE && NATIVE.vibra){
      const ms = [0].concat(arr);
      const a = [0];
      for (let i = 0; i < arr.length; i++) a.push(i % 2 === 0 ? ((amp && amp[i >> 1]) || 200) : 0);
      NATIVE.vibra({ ms: ms, amp: a }).catch(function(){ });
      return;
    }
    if (navigator.vibrate) navigator.vibrate(p);
  }catch(_){ }
}

// v1: the standalone "Motore di blocco" page (blocco.html) is gone. It was a second technical
// UI in a different style, unreachable in normal use but shipped inside the AAB — exactly the
// kind of screen that makes a reviewer read the app as a prototype. The only caller is a
// fallback in blocco.js that fires when openPerm is missing, which never happens: perms.js is
// always loaded. Kept as a no-op so that impossible path degrades to nothing, not a 404.
function goEngine(){ try { if (typeof toast === 'function') toast('Apri le impostazioni di accessibilità dal profilo.'); } catch(e){} }

/* The phone's own back button is the only "indietro": during onboarding it steps back one
   screen; on the home shell it lets Android background the app, as every native app does. */
if(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App){
  window.Capacitor.Plugins.App.addListener('backButton', ({canGoBack}) => {
    if(!handleBack()) window.Capacitor.Plugins.App.minimizeApp();
  });
}
