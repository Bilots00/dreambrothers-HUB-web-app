/* ===========================================================================================
   LA PARTITA — le regole del gioco, e l'arbitro che le applica

   Il tabellone fra il vecchio te e il nuovo te c'era già. Quello che non c'era è ARBITRARE:
   `mtFocusPoint` e `mtOldPoint` esistevano da settimane e non li chiamava nessuno. Il punteggio
   restava 0 a 0 qualunque cosa succedesse — sessioni portate a termine, promesse rotte, blocchi
   interrotti — e un tabellone che segna sempre zero non è un tabellone, è una decorazione.

   Qui dentro ci sono tre cose:

   · LE REGOLE, scritte una volta e visibili in una pagina sola (Impostazioni → La partita).
     Quanto è severo il gioco, se il punteggio prosegue come un campionato o se ogni giorno è
     una partita nuova, se il vecchio te segna quando molli, e la parola che la bolla usa per
     dire quei minuti («spesi» o «buttati»: non è la stessa frase, e non fa lo stesso effetto).

   · L'ARBITRO: le due sole funzioni da cui passa ogni punto, così le regole si applicano in un
     posto e non sparse in dieci file.

   · IL REFERTO: il risultato delle partite dei giorni scorsi, che è la ragione per cui tenere
     il punteggio ha senso — un numero da solo non dice niente, una serie sì.

   UNA REGOLA CHE NON SI PIEGA: con la Modalità severa accesa queste impostazioni si leggono e
   non si toccano. Un gioco in cui puoi cambiare le regole nel momento in cui stai perdendo non
   è un gioco, ed è esattamente il momento in cui uno le cambierebbe.
   =========================================================================================== */

const MG_KEY  = 'fl_match_cfg';
const MG_HIST = 'fl_match_hist';

const MG_DEF = {
  severity: 'normale',       // morbido | normale | severo
  word: '',                  // la parola della bolla; vuoto = quella del livello
  season: 'campionato',      // campionato (i punti restano) | giorno | tempo (90 minuti)
  matchMin: 90,              // quanto dura una partita a tempo
  oldScores: true,           // il vecchio te segna quando molli
  tickNeedsSession: true,    // la spunta vale solo con una sessione a prova
  goalPopup: true,           // il cartello «GOL» quando qualcuno segna
  goalSound: true,           // e il suono
  decMin: 1                  // i minuti per rispondere a una decisione del tuo agente personale (prenota.js)
};

/* La parola di serie per ogni livello. «Spesi» è un fatto, «buttati» è un giudizio: è la stessa
   informazione detta da due allenatori diversi, e uno dei due ti fa alzare dalla sedia. */
const MG_WORDS = { morbido: 'passati', normale: 'spesi', severo: 'buttati' };

function mgCfg(){
  let c = {};
  try{ c = JSON.parse(localStorage.getItem(MG_KEY) || '{}') || {}; }catch(_){ }
  const out = Object.assign({}, MG_DEF, c);
  /* Il livello severo non lascia scegliere: se il vecchio te non segnasse, «severo» sarebbe
     solo una parola diversa sulla stessa partita. */
  if (out.severity === 'severo'){ out.oldScores = true; out.tickNeedsSession = true; }
  if (out.severity === 'morbido') out.tickNeedsSession = false;
  return out;
}

function mgWord(){
  const c = mgCfg();
  return (c.word || '').trim() || MG_WORDS[c.severity] || 'spesi';
}

async function mgSave(patch){
  if (await mgLocked()){ toast('Modalità severa: le regole della partita non si cambiano adesso'); return false; }
  const c = Object.assign({}, mgCfg(), patch || {});
  try{ localStorage.setItem(MG_KEY, JSON.stringify(c)); }catch(_){ }
  mgPushWord();
  try{
    if (patch && ('goalPopup' in patch || 'goalSound' in patch) && NATIVE && NATIVE.setSettings)
      NATIVE.setSettings({ goalPopup: c.goalPopup !== false, goalSound: c.goalSound !== false }).catch(function(){ });
  }catch(_){ }
  mgPaint();
  return true;
}

/* La parola va anche al telefono: è lui che disegna la bolla sopra le altre app. */
function mgPushWord(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setSettings) return;
    const w = mgWord();
    if (typeof SETTINGS !== 'undefined') SETTINGS.bubbleWord = w;
    NATIVE.setSettings({ bubbleWord: w });
  }catch(_){ }
}

/* Con la Modalità severa attiva le regole sono in lettura. */
async function mgLocked(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getStrictState) return false;
    const s = await NATIVE.getStrictState();
    return !!(s && s.level >= 1);
  }catch(_){ return false; }
}

/* ---------------------------------------------------------------------------------------
   IL COMPUTER DI CASA

   Il tabellone deve essere uno solo. Se il vecchio te segna qui, il numero sul computer si
   deve muovere nello stesso istante — non al prossimo avvio, non fra dieci minuti.

   La strada e' quella dritta: telefono e computer sulla stessa rete, un indirizzo incollato
   una volta. Passare dal server sarebbe stato piu' elegante da disegnare e piu' lento da
   vivere, e un tabellone in ritardo non serve a niente.

   L'invio e' a perdere: se il computer e' spento, se sei fuori casa, se il Wi-Fi e' un altro,
   non succede niente e nessuno se ne accorge. Un tabellone non deve mai far aspettare.
   --------------------------------------------------------------------------------------- */

const MG_PC = 'fl_match_pc';

function mgPcUrl(){
  try{ return localStorage.getItem(MG_PC) || ''; }catch(_){ return ''; }
}

function mgPcSet(u){
  const v = String(u || '').trim().replace(/\/+$/, '');
  try{ localStorage.setItem(MG_PC, v); }catch(_){ }
}

let MG_SEND_T = 0;
function mgSendScore(payload){
  const base = mgPcUrl();
  if (!base) return;
  /* Un invio alla volta: il punteggio cambia a raffica quando si recuperano piu' giorni. */
  clearTimeout(MG_SEND_T);
  MG_SEND_T = setTimeout(function(){
    try{
      const corpo = JSON.stringify({ old: payload.old, neo: payload.neo, goal: payload.goal || '' });
      /* La chiamata la fa il lato nativo, non la pagina: la pagina gira su https e un
         indirizzo http della rete di casa sarebbe contenuto misto, bloccato dal WebView
         prima ancora di partire. Nella vista telefono sul computer il nativo non c'e' e
         non serve — quel computer e' gia' questo. */
      if (NATIVE && NATIVE.lanCall) NATIVE.lanCall({ url: base + '/score', method: 'POST', body: corpo }).catch(function(){ });
      else fetch(base + '/score', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: corpo }).catch(function(){ });
    }catch(_){ }
  }, 150);
}

async function mgPcTest(){
  const base = mgPcUrl();
  if (!base){ toast('Prima incolla l\'indirizzo che ti mostra il computer'); return; }
  try{
    let j = null;
    if (NATIVE && NATIVE.lanCall){
      const r = await NATIVE.lanCall({ url: base + '/ping', method: 'GET' });
      j = JSON.parse((r && r.body) || '{}');
    } else {
      const r = await fetch(base + '/ping');
      j = await r.json();
    }
    toast(j && j.app === 'focuslock' ? 'Collegato a ' + (j.device || 'questo computer') : 'Risponde, ma non e\' DreamMap');
    try{ if (typeof mtRoll === 'function') mgSendScore(mtRoll()); }catch(_){ }
  }catch(_){
    toast('Nessuna risposta: il computer deve essere acceso, sulla stessa rete, con DreamMap aperto');
  }
}

function mgPcSave(){
  const i = document.getElementById('mgPcIn');
  mgPcSet(i ? i.value : '');
  mgPcTest();
}

/* ---------------------------------------------------------------------------------------
   L'ARBITRO
   --------------------------------------------------------------------------------------- */

/* Un punto al nuovo te. `prova` è vero quando c'è una sessione di concentrazione a dimostrarlo.
   Al livello normale e severo un punto senza prova non si dà: spuntare una casella è una cosa
   che si fa in mezzo secondo, e un punteggio che si può regalare da soli non misura niente. */
function mgFocusPoint(motivo, prova){
  const c = mgCfg();
  if (c.tickNeedsSession && !prova){
    toast('L\'arbitro dà il punto a una sessione di concentrazione portata a termine');
    return false;
  }
  /* PRIMA IL MOTIVO, POI IL PUNTO. Il cartello del gol legge il registro per dire perche' e'
     stato assegnato: scrivendo dopo, mostrava il motivo del punto PRECEDENTE. */
  /* IL MODELLO DI PARTITA decide quanto vale (modelli.js): una mossa chiusa prima delle 12
     puo' valere due, la mossa del giorno tre. Senza modello, uno come sempre. */
  let m = { n: 1, nota: '' };
  try{ if (typeof mdMolt === 'function' && typeof mdEvento === 'function'){ const ev = mdEvento('neo', motivo); if (ev) m = mdMolt('neo', ev); } }catch(_){ }
  if (m.n <= 0) return false;
  mgLog('neo', (motivo || '') + (m.nota || ''), m.n > 1 ? { punti: m.n } : null);
  if (typeof mtFocusPoint === 'function') for (let i = 0; i < m.n; i++) mtFocusPoint();
  return true;
}

/* Un punto al vecchio te: molli una sessione, interrompi un blocco, fermi il blocco rapido.
   Non è una multa — è il tabellone che registra chi ha vinto quello scambio. */
function mgOldPoint(motivo){
  if (!mgCfg().oldScores) return false;
  let m = { n: 1, nota: '' };
  try{ if (typeof mdMolt === 'function' && typeof mdEvento === 'function'){ const ev = mdEvento('old', motivo); if (ev) m = mdMolt('old', ev); } }catch(_){ }
  if (m.n <= 0) return false;
  mgLog('old', (motivo || '') + (m.nota || ''), m.n > 1 ? { punti: m.n } : null);
  if (typeof mtOldPoint === 'function') for (let i = 0; i < m.n; i++) mtOldPoint();
  return true;
}

/* La prova che l'arbitro cerca quando spunti la riga: una sessione intensiva finita oggi. */
function mgProofToday(){
  let h = [];
  try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  const alba = new Date(); alba.setHours(0, 0, 0, 0);
  return h.some(function(x){ return x && x.ok && x.intensive && x.at >= alba.getTime(); });
}

function mgLog(chi, motivo, extra){
  try{
    const g = mgToday();
    g.eventi = g.eventi || [];
    /* `extra.da`: la riga descrive un punto segnato su un ALTRO dispositivo. Serve a non
       rispedirla indietro: e' cosi' che «giorno senza piano scritto (2026-09-15)» rimbalzava
       fra telefono e computer prendendosi un «(dal …)» in piu' a ogni giro. */
    g.eventi.push(Object.assign({ chi: chi, motivo: motivo, at: Date.now() }, extra || {}));
    mgWriteToday(g);
  }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   IL REFERTO — le partite dei giorni scorsi
   --------------------------------------------------------------------------------------- */

function mgDayKey(t){
  const d = new Date(t || Date.now());
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function mgHist(){
  try{ return JSON.parse(localStorage.getItem(MG_HIST) || '[]') || []; }catch(_){ return []; }
}

function mgToday(){
  const k = mgDayKey();
  const h = mgHist();
  const g = h.filter(function(x){ return x.day === k; })[0];
  return g || { day: k, eventi: [] };
}

function mgWriteToday(g){
  const h = mgHist().filter(function(x){ return x.day !== g.day; });
  h.push(g);
  try{ localStorage.setItem(MG_HIST, JSON.stringify(h.slice(-120))); }catch(_){ }
}

/* IL FISCHIO FINALE DELLA GIORNATA.

   Serve solo a chi gioca "una partita al giorno": a mezzanotte il risultato va in archivio e il
   tabellone riparte da zero a zero. Chi gioca il campionato non passa mai di qui — i suoi punti
   sono la stessa partita che continua, ed è un'altra cosa. */
function mgRollDay(){
  if (mgCfg().season !== 'giorno') return;
  if (typeof mtState !== 'function' || typeof mtWrite !== 'function') return;

  let ultimo = '';
  try{ ultimo = localStorage.getItem('fl_match_lastday') || ''; }catch(_){ }
  const oggi = mgDayKey();
  if (ultimo === oggi) return;

  const s = mtState();
  /* LE REGOLE DI MEZZANOTTE del modello (giornata pulita, mezzanotte senza mossa): si
     assegnano alla giornata che si chiude, prima di archiviarla. */
  if (ultimo){
    try{
      const gg = mgHist().filter(function(x){ return x.day === ultimo; })[0] || mgToday();
      const extra = (typeof mdMezzanotte === 'function') ? mdMezzanotte(ultimo, gg.eventi || []) : [];
      extra.forEach(function(e){
        for (let i = 0; i < e.n; i++){ if (e.chi === 'neo') s.neo++; else s.old++; }
        gg.eventi = gg.eventi || []; gg.eventi.push({ chi: e.chi, motivo: e.motivo + (e.n > 1 ? ' (×' + e.n + ')' : ''), at: Date.now(), punti: e.n });
      });
      if (extra.length){ const h0 = mgHist().filter(function(x){ return x.day !== ultimo; }); h0.push(gg); localStorage.setItem(MG_HIST, JSON.stringify(h0.slice(-120))); }
    }catch(_){ }
  }
  if (ultimo && (s.old || s.neo)){
    const h = mgHist().filter(function(x){ return x.day !== ultimo; });
    const g = mgToday();
    h.push({ day: ultimo, old: s.old, neo: s.neo, eventi: (g && g.day === ultimo ? g.eventi : []) || [] });
    try{ localStorage.setItem(MG_HIST, JSON.stringify(h.slice(-120))); }catch(_){ }
    s.old = 0; s.neo = 0;
    mtWrite(MT_KEY, s);
    /* Il fischio finale vale per tutti i dispositivi, non solo per quello che era acceso a
       mezzanotte: la partita nuova parte insieme o non e' la stessa partita. */
    try{ if (typeof lsResetEpoch === 'function') lsResetEpoch(); }catch(_){ }
  }
  try{ localStorage.setItem('fl_match_lastday', oggi); }catch(_){ }
}

/* ---------------------------------------------------------------------------------------
   La pagina: Impostazioni → La partita
   --------------------------------------------------------------------------------------- */

registerScreen('s-match', `
  <div class="topbar"><button class="iconbtn" onclick="mgBack()">‹</button><b class="blk-title">La partita</b></div>
  <div class="hintline" id="mgLock" style="padding:0 2px 12px" hidden></div>
  <div id="mgBody"></div>
  <div class="spacer"></div>
`, { back: 's-settings' });

function mgOpen(){ goId('s-match'); mgPaint(); }
function mgBack(){
  goId('s-settings');
  try{ if (typeof settingsPaintExits === 'function') settingsPaintExits(); }catch(_){ }
}

/* Dove gira questa pagina: nella vista telefono di FocusLock per Windows c'e' window.chrome.webview,
   sul telefono no. Serve perche' sul computer il gol lo festeggia il programma (cartello sopra
   a tutto, suono, bagliore sul tabellone) e la pagina deve stare zitta, o suona due volte. */
function mgDesktop(){ try{ return !!(window.chrome && window.chrome.webview); }catch(_){ return false; } }

/* ---------------------------------------------------------------------------------------
   IL GOL SI SENTE

   Un punto che compare in un tabellone che non stai guardando non premia nessuno: il suono
   arriva anche a chi ha gli occhi altrove. Di serie una salita di tre note che finisce
   sull'ottava — un gol da videogioco, non una campanella — e chi vuole ci mette il suo file.
   Sul telefono un file scelto lo suona il nativo (un content:// la pagina non lo apre); il
   suono di serie lo suona la pagina. Sul computer suona il programma.
   --------------------------------------------------------------------------------------- */
let MG_AUDIO = null;
function mgPlayGoal(){
  try{
    if (mgDesktop()){ if (NATIVE && NATIVE.goalCue) NATIVE.goalCue({}); return; }
    const uri = (typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.goalSoundUri) || '';
    if (uri && NATIVE && NATIVE.playUri){ NATIVE.playUri({ uri: uri }).catch(function(){ }); return; }
    if (!MG_AUDIO) MG_AUDIO = new Audio('sounds/gol.wav');
    MG_AUDIO.currentTime = 0;
    const p = MG_AUDIO.play(); if (p && p.catch) p.catch(function(){ });
  }catch(_){ }
}

async function mgPickGoalSound(){
  try{
    if (!NATIVE || !NATIVE.pickMedia){ toast('Disponibile nell\'app installata'); return; }
    const r = await NATIVE.pickMedia({ kind: 'audio' });
    if (!r || !(r.uri || r.path)) return;
    const uri = r.uri || r.path;
    if (typeof settingsSave === 'function') await settingsSave({ goalSoundUri: uri, goalSoundName: r.name || '' });
    else if (NATIVE.setSettings) await NATIVE.setSettings({ goalSoundUri: uri, goalSoundName: r.name || '' });
    mgPaint();
  }catch(e){ if (!(e && e.code === 'cancelled')) toast('Nessun file scelto'); }
}

async function mgGoalSoundDefault(){
  if (typeof settingsSave === 'function') await settingsSave({ goalSoundUri: '', goalSoundName: '' });
  else if (NATIVE && NATIVE.setSettings) await NATIVE.setSettings({ goalSoundUri: '', goalSoundName: '' });
  mgPaint();
}

function mgGoalHtml(c){
  const nome = (typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.goalSoundName) || '';
  const custom = !!((typeof SETTINGS !== 'undefined' && SETTINGS && SETTINGS.goalSoundUri) || '');
  return '<div class="sect" style="margin-top:24px"><b>Quando qualcuno segna</b></div>'
    + '<p class="hintline" style="padding:0 2px 10px">Valgono per QUESTO dispositivo: sul computer puoi tenere il cartello spento per non essere interrotto e lasciarlo sul telefono, o il contrario.</p>'
    + '<div class="ps-block">'
    +   '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udce3 Cartello del gol</b><small>Il cartello con il punteggio e la frase, sopra a tutto, per due secondi e mezzo.</small></div>'
    +   '<button class="switch' + (c.goalPopup !== false ? ' on' : '') + '" onclick="mgToggle(\'goalPopup\')"></button></div>'
    + '</div>'
    + '<div class="ps-block">'
    +   '<div class="blk-swrow" style="margin-top:0"><div><b>\ud83d\udd0a Suono del gol</b><small>Per accorgersene anche a occhi altrove. Il tabellone sul computer si illumina comunque.</small></div>'
    +   '<button class="switch' + (c.goalSound !== false ? ' on' : '') + '" onclick="mgToggle(\'goalSound\')"></button></div>'
    +   '<p class="hintline" style="padding:8px 0 0">Suono: <b>' + (custom ? esc(nome || 'file scelto da te') : 'quello di serie') + '</b></p>'
    +   '<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">'
    +     '<button type="button" class="ghostmini" onclick="mgPlayGoal()">\u25b6 Prova</button>'
    +     '<button type="button" class="ghostmini" onclick="mgPickGoalSound()">Scegli un file\u2026</button>'
    +     (custom ? '<button type="button" class="ghostmini" onclick="mgGoalSoundDefault()">Torna a quello di serie</button>' : '')
    +   '</div>'
    + '</div>';
}

async function mgPaint(){
  const box = document.getElementById('mgBody');
  if (!box) return;
  const c = mgCfg();

  const bloccata = await mgLocked();
  const avviso = document.getElementById('mgLock');
  if (avviso){
    avviso.hidden = !bloccata;
    avviso.textContent = '🔒 La Modalità severa è attiva: le regole si leggono ma non si cambiano. È il momento in cui uno le cambierebbe, ed è per questo che non si può.';
  }

  const chip = function(gruppo, val, cur, etichetta, sotto){
    return '<button type="button" class="mg-chip' + (cur === val ? ' on' : '') + '"'
      + ' onclick="mgSet(\'' + gruppo + '\',\'' + val + '\')">'
      + '<b>' + etichetta + '</b>' + (sotto ? '<small>' + sotto + '</small>' : '') + '</button>';
  };

  const sw = function(campo, acceso, titolo, sotto, forzato){
    return '<div class="blk-swrow" style="margin-top:0"><div><b>' + titolo + '</b><small>' + sotto + '</small></div>'
      + '<button class="switch' + (acceso ? ' on' : '') + (forzato ? ' locked' : '') + '"'
      + ' onclick="' + (forzato ? 'toast(\'Al livello severo questa non si spegne\')' : 'mgToggle(\'' + campo + '\')') + '"></button></div>';
  };

  box.innerHTML =
      '<div class="sect"><b>Quanto è severo il gioco</b></div>'
    + '<p class="hintline" style="padding:0 2px 10px">Cambia le parole e cambia chi segna. Non cambia quello che fai: cambia quanto ti costa non farlo.</p>'
    + '<div class="mg-chips">'
    +   chip('severity', 'morbido', c.severity, 'Morbido', 'Nessuno ti punisce')
    +   chip('severity', 'normale', c.severity, 'Normale', 'Come una partita')
    +   chip('severity', 'severo',  c.severity, 'Severo',  'Ogni errore si paga')
    + '</div>'

    + '<div class="sect" style="margin-top:24px"><b>La parola della bolla</b></div>'
    + '<p class="hintline" style="padding:0 2px 10px">Quella che compare sopra le altre app: "30 min <b>'
    +   esc(mgWord()) + '</b> su Chrome oggi". Scrivi la tua, o lasciala vuota per quella del livello.</p>'
    + '<div class="fl-search"><span class="fl-plus">✍️</span>'
    +   '<input id="mgWord" value="' + esc(c.word || '') + '" placeholder="' + esc(MG_WORDS[c.severity]) + '"'
    +   ' onchange="mgSetWord()" onkeydown="if(event.key===\'Enter\'){event.preventDefault();mgSetWord();}"></div>'

    + '<div class="sect" style="margin-top:24px"><b>Che partita giochi</b></div>'
    + '<div class="mg-chips">'
    +   chip('season', 'campionato', c.season, 'Campionato', 'I punti restano')
    +   chip('season', 'giorno',     c.season, 'Ogni giorno', 'A mezzanotte da capo')
    + '</div>'
    /* La terza sta su una riga sua, a tutta larghezza: non è una variante delle prime due,
       è l'unica che ha un orologio — e un orologio cambia come si gioca, non solo quando si
       azzera il punteggio. */
    + '<button type="button" class="mg-wide' + (c.season === 'tempo' ? ' on' : '') + '" onclick="mgSet(\'season\',\'tempo\')">'
    +   '<b>⏱️ A tempo</b><small>Novanta minuti (o quanti vuoi tu) con il minuto che corre sul tabellone, e un fischio finale</small>'
    + '</button>'
    /* TUTTO QUELLO CHE SI APRE SCEGLIENDO «A TEMPO» STA DENTRO A UN PANNELLO SOLO.
       Sono sei controlli diversi — durata, calcio d'inizio, fasce orarie — e sparpagliati sulla
       pagina sembravano sei impostazioni indipendenti lasciate li' da qualcuno. Il pannello
       scuro dice una cosa sola, e la dice in silenzio: questa roba esiste perche' hai scelto
       quella modalita', e vale solo per quella. */
    + (c.season === 'tempo' ? '<div class="mg-tempo">' + mgTempoHtml(c) + '</div>' : '')

    + '<div class="sect" style="margin-top:24px"><b>Chi segna</b></div>'
    + '<div class="ps-block">'
    +   sw('oldScores', c.oldScores, '🕳️ Il vecchio te segna quando molli',
          'Una sessione abbandonata, un blocco interrotto, il blocco rapido fermato: sono scambi persi, e sul tabellone si vedono.',
          c.severity === 'severo')
    + '</div>'
    + '<div class="ps-block">'
    +   sw('tickNeedsSession', c.tickNeedsSession, '🚀 Il punto vuole una prova',
          'La spunta da sola non basta: serve una sessione di concentrazione intensiva portata a termine oggi.',
          c.severity !== 'normale')
    + '</div>'

    /* L'ARBITRO, QUI E NON ALTROVE. Decide come si guadagna il punto del nuovo te — è la
       stessa domanda di "chi segna" qui sopra, solo più in dettaglio. Prima stava nella
       pagina Personalizza, sotto un titolo che parlava di mantra: un pannello sulle regole
       del gioco non ha nesso con la faccia del promemoria. */
    + '<div class="ps-block"><b>⚖️ L\'arbitro della partita</b>'
    +   '<p class="hintline" style="padding:4px 0 10px">Il punto va al nuovo te solo quando l\'app ha visto il lavoro. Non prima: un premio che arriva sull\'intenzione svuota la voglia di farla.</p>'
    +   '<div class="blk-swrow"><div><b>Punto solo con una sessione FullFocus</b><small>La riga spuntata vale un punto se oggi c\'è stata una sessione intensiva, finita, con quella riga come intenzione. Spenta, basta la spunta.</small></div>'
    +     '<button class="switch on" id="psRefSess" onclick="refToggleSession()"></button></div>'
    +   '<div class="ps-sub" style="margin-top:16px">Durata minima della sessione</div>'
    +   '<div class="sev-chips" id="psRefMin"></div>'
    +   '<div class="ps-sub" style="margin-top:16px">Il piano di domani va scritto entro</div>'
    +   '<div class="ps-row"><input class="fin" id="psRefBy" type="time" step="60" onchange="refSetPlanBy(this.value)"><span class="ps-val" id="psRefByTxt"></span></div>'
    +   '<p class="hintline" style="padding:8px 2px 0">00:00 vuol dire entro mezzanotte. Oltre l\'ora scelta, il piano di domani non conta per la serie.</p></div>'

    /* L'interruttore «sempre in vista» e' andato dove stanno le altre bolle, in Impostazioni:
       qui resta l'ASPETTO, che e' una regola della partita come le altre — chi sono le due
       squadre e di che colore e' il tuo punteggio. */
    /* LE DECISIONI A TEMPO. Il tuo agente personale ti mette davanti a una scelta; il conto alla rovescia
       parte da qui, si vede tre secondi e poi sparisce (sotto pressione non si decide). */
    + '<div class="sect" style="margin-top:24px"><b>\u23f1\ufe0f Decidere in fretta</b></div>'
    + '<p class="hintline" style="padding:0 2px 10px">Quando il tuo agente personale ti chiede di scegliere, hai questo tempo per rispondere e prenotare il punto. Il conto si vede tre secondi, poi resta solo la domanda.</p>'
    + '<div class="mg-chips">'
    +   chip('decMin', 1, +c.decMin || 1, '1 min', 'Di serie')
    +   chip('decMin', 2, +c.decMin || 1, '2 min', '')
    +   chip('decMin', 3, +c.decMin || 1, '3 min', '')
    +   chip('decMin', 5, +c.decMin || 1, '5 min', 'Con calma')
    + '</div>'
    + '<div class="sect" style="margin-top:24px"><b>Il tabellone</b></div>'
    + '<div class="setrow" onclick="slOpen()"><span>\ud83c\udfdf\ufe0f</span><b>Aspetto del tabellone</b>'
    +   '<small>' + ((typeof SL_MODI !== 'undefined' && typeof slSkin === 'function')
        ? esc((SL_MODI.filter(function(x){ return x.k === slSkin(); })[0] || SL_MODI[0]).n.toLowerCase())
        : 'stemmi e colori') + '</small><span class="chev"></span></div>'

    + mgGoalHtml(c)
    + mgSyncHtml()
    + mgResultsHtml();

  if (typeof refPaint === 'function') refPaint();   // popola i controlli dell'arbitro appena scritti
  mgRegistroFill();
}
/* Il registro e' asincrono (legge i blocchi del motore): si riempie dopo che la pagina c'e'. */
async function mgRegistroFill(){
  const b = document.getElementById('mgRegistro');
  if (!b || typeof insPuntiCorpo !== 'function') return;
  try{
    b.innerHTML = await insPuntiCorpo();
    if (typeof ubFillIcons === 'function') ubFillIcons(b);
  }catch(_){ }
}

/* IL TABELLONE SU TUTTI I DISPOSITIVI.

   Qui non si configura niente, ed è esattamente la funzione: il punteggio segue l'account,
   quindi segue la persona. Telefono e computer restano allineati sul Wi-Fi di casa, su quello
   di un albergo all'estero o sui dati del telefono, perché l'unica cosa che serve è una
   connessione — come il risultato di una partita, che arriva ovunque senza che tu debba dire
   da dove lo stai guardando.

   Il collegamento diretto sulla rete di casa resta, chiuso lì sotto: non serve a nessuno per
   far funzionare il tabellone, serve a chi lo vuole istantaneo invece che entro venti secondi. */
function mgSyncHtml(){
  const st = (typeof lsStatus === 'function') ? lsStatus() : { on: false, testo: '' };
  const lan = (typeof mgPcUrl === 'function') ? mgPcUrl() : '';
  return '<div class="sect" style="margin-top:24px"><b>Il tabellone su tutti i tuoi dispositivi</b></div>'
    + '<div class="ps-block">'
    +   '<div class="mg-sync' + (st.on ? ' on' : '') + '"><span>' + (st.on ? '🌐' : '⚠️') + '</span>'
    +   '<div><b>' + (st.on ? 'Punteggio in diretta' : 'Punteggio solo su questo dispositivo') + '</b>'
    +   '<small>' + esc(st.testo) + '</small></div></div>'
    +   '<p class="hintline" style="padding:8px 0 0">Il punteggio viaggia con il tuo account Google, come il backup. '
    +   'Qualsiasi connessione va bene: il Wi-Fi di casa, quello di un albergo, il 4G o il 5G. Non c\'è nessun indirizzo da copiare.</p>'
    +   '<button type="button" class="ghostmini" style="width:100%;margin-top:10px" onclick="lsSyncNow()">Sincronizza adesso</button>'
    + '</div>'
    + '<details class="mg-adv"><summary>Collegamento diretto sulla rete di casa (facoltativo)</summary>'
    +   '<p class="hintline" style="padding:8px 2px 10px">Sulla stessa rete Wi-Fi il punto compare sul computer nello stesso istante, senza aspettare il giro di sincronizzazione. '
    +   'Sul computer: Impostazioni → «Copia l\'indirizzo per il telefono».</p>'
    +   '<div class="fl-search"><span class="fl-plus">🔗</span>'
    +     '<input id="mgPcIn" value="' + esc(lan) + '" placeholder="http://192.168.1.5:8732/s/…" autocomplete="off"'
    +     ' onchange="mgPcSave()" onkeydown="if(event.key===\'Enter\'){event.preventDefault();mgPcSave();}"></div>'
    +   '<button type="button" class="ghostmini ff-addsite" onclick="mgPcSave()">Collega e prova</button>'
    + '</details>';
}

function mgResultsHtml(){
  /* NEL CAMPIONATO LA PARTITA E' UNA SOLA: non ci sono «ultimi risultati» da elencare, e la
     sezione restava un cartello vuoto. Al suo posto va il registro dei punti — le righe che
     dicono chi ha segnato e perche' — che e' l'unica storia che un campionato ha. */
  const cfg = (typeof mgCfg === 'function') ? mgCfg() : {};
  if (cfg.season === 'campionato'){
    return '<div class="sect" style="margin-top:24px"><b>\ud83d\udcdd Il registro dei punti</b></div>'
      + '<div id="mgRegistro"><p class="pz-vuoto">Leggo la partita\u2026</p></div>';
  }
  const h = mgHist().filter(function(x){ return typeof x.old === 'number'; }).slice(-14).reverse();
  if (!h.length){
    return '<div class="sect" style="margin-top:24px"><b>Ultimi risultati</b></div>'
      + '<p class="ff-empty">Qui finiscono le partite dei giorni scorsi. Con il campionato acceso la partita è una sola e questa sezione resta vuota.</p>';
  }
  return '<div class="sect" style="margin-top:24px"><b>Ultimi risultati</b></div>'
    + '<div class="mg-res">' + h.map(function(g){
        const vinta = g.neo > g.old, pari = g.neo === g.old;
        return '<div class="mg-row"><span class="mg-day">' + esc(mgNiceDay(g.day)) + '</span>'
          + '<b class="mg-score"><i class="old">' + g.old + '</i>–<i class="neo">' + g.neo + '</i></b>'
          + '<span class="mg-tag ' + (vinta ? 'w' : pari ? 'p' : 'l') + '">'
          + (vinta ? 'V' : pari ? 'N' : 'P') + '</span></div>';
      }).join('') + '</div>';
}

function mgNiceDay(k){
  try{
    const d = new Date(k + 'T12:00:00');
    return d.toLocaleDateString('it-IT', { weekday: 'short', day: '2-digit', month: '2-digit' });
  }catch(_){ return k; }
}

async function mgSet(campo, val){
  const p = {}; p[campo] = val;
  await mgSave(p);
}
async function mgToggle(campo){
  const p = {}; p[campo] = !mgCfg()[campo];
  await mgSave(p);
}
async function mgSetWord(){
  const i = document.getElementById('mgWord');
  await mgSave({ word: String(i ? i.value : '').trim().slice(0, 24) });
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */

(function mgSyncStyle(){
  const css = [
    '.mg-sync{display:flex;gap:12px;align-items:flex-start}',
    '.mg-sync>span{font-size:20px;line-height:1.2}',
    '.mg-sync b{display:block;font-size:14.5px}',
    '.mg-sync small{display:block;color:#93A4C4;font-size:12.5px;line-height:1.5;margin-top:3px}',
    '.mg-sync.on b{color:#8CF0C8}',
    '.mg-adv{margin-top:12px;border-radius:14px;background:rgba(255,255,255,.04);padding:10px 14px}',
    '.mg-adv summary{cursor:pointer;font:600 12.5px/1.6 inherit;color:#93A4C4;list-style:none}',
    '.mg-adv summary::-webkit-details-marker{display:none}'
  ].join('');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function mgStyle(){
  const css = [
    '.mg-chips{display:flex;gap:8px}',
    '.mg-chip{flex:1;min-width:0;border:1px solid var(--line);background:#fff;border-radius:16px;padding:12px 8px;text-align:center;cursor:pointer}',
    '.mg-chip b{display:block;font:700 13px var(--font-body);color:var(--navy)}',
    '.mg-chip small{display:block;margin-top:3px;font:500 10.5px/1.35 var(--font-body);color:var(--muted)}',
    '.mg-chip.on{background:var(--navy);border-color:var(--navy)}',
    '.mg-chip.on b,.mg-chip.on small{color:#fff}',
    'body.dark .mg-chip{background:#12203A;border-color:#22345A}',
    'body.dark .mg-chip.on{background:#fff}body.dark .mg-chip.on b,body.dark .mg-chip.on small{color:#0E1B33}',
    '.switch.locked{opacity:.55}',
    '.mg-res{border:1px solid var(--line);border-radius:18px;overflow:hidden}',
    'body.dark .mg-res{border-color:#22345A}',
    '.mg-row{display:flex;align-items:center;gap:12px;padding:12px 14px;border-bottom:1px solid var(--line)}',
    '.mg-row:last-child{border-bottom:0}',
    'body.dark .mg-row{border-bottom-color:#22345A}',
    '.mg-day{flex:1;font:600 13px var(--font-body);color:var(--muted);text-transform:capitalize}',
    '.mg-score{font:800 16px var(--font-body);color:var(--navy)}',
    '.mg-score .old{font-style:normal;color:#E5515F}.mg-score .neo{font-style:normal;color:var(--neo,#0075E3)}',
    'body.dark .mg-score{color:#fff}',
    '.mg-tag{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:800 11px var(--font-body);color:#fff}',
    '.mg-tag.w{background:#1B9E6A}.mg-tag.p{background:#8FA3BF}.mg-tag.l{background:#E5515F}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* All'avvio: il fischio finale di ieri, e la parola al telefono. */
setTimeout(function(){ try{ mgRollDay(); mgPushWord(); }catch(_){ } }, 1500);

/* ---------------------------------------------------------------------------------------
   LA PARTITA A TEMPO — durata, calcio d'inizio, fasce orarie

   Due modi di cominciare, e sono due persone diverse: chi vuole decidere lui quando si gioca
   (il pulsante, anche dalla scheda START), e chi vuole che la partita lo trovi già iniziata
   a un'ora fissa, senza doverci pensare. Tutti e due qui, uno sotto l'altro.
   --------------------------------------------------------------------------------------- */

const MG_DURATE = [25, 45, 60, 90, 120];

function mgTempoHtml(c){
  const durata = Math.max(1, +c.matchMin || 90);
  const live = (typeof koRunning === 'function') && koRunning();

  const chips = MG_DURATE.map(function(m){
    return '<button type="button" class="mg-min' + (durata === m ? ' on' : '') + '" onclick="mgSetDurata(' + m + ')">'
      + (m >= 60 ? (m % 60 ? (m / 60).toFixed(1).replace('.0', '') : (m / 60)) + 'h' : m + 'm') + '</button>';
  }).join('');

  /* Se una partita è in corso, la prima cosa che si deve leggere è a che minuto siamo —
     non la durata, che ormai è decisa. */
  const testa = live
    ? '<div class="ps-block mg-live"><b>⏱️ Partita in corso · ' + esc(koLabel()) + '</b>'
      + '<p class="hintline" style="padding:4px 0 10px">Mancano ' + koLeft() + ' minuti. Al fischio finale il risultato va nel referto e il tabellone riparte da zero.</p>'
      + '<button type="button" class="ghostmini" style="width:100%" onclick="koEnd();mgPaint()">Fischia la fine adesso</button></div>'
    : '<div class="ps-block"><b>⚽ Calcio d\'inizio</b>'
      + '<p class="hintline" style="padding:4px 0 10px">Comincia quando sei pronto: da qui, o dal pulsante nella scheda START.</p>'
      + '<button type="button" class="cta" style="margin:0" onclick="koStart();mgPaint()">Fischia l\'inizio · ' + durata + ' minuti</button></div>';

  const piano = koPlan();
  const righe = piano.length
    ? piano.map(function(f){
        /* La fascia si legge come si e' scritta: DALLE ... ALLE. L'ora di fine e' l'inizio
           piu' la durata — la stessa cosa, detta nel modo in cui la pensa una persona che
           guarda un calendario. */
        const hh = mgOra(f.h, f.m) + ' \u2013 ' + mgOra(f.h, f.m + f.min);
        return '<div class="mg-fascia' + (f.on === false ? ' off' : '') + '">'
          + '<b>' + hh + '</b><small>' + f.min + ' minuti</small>'
          + '<button type="button" onclick="koPlanToggle(\'' + f.id + '\');mgPaint()">' + (f.on === false ? '▶' : '⏸') + '</button>'
          + '<button type="button" class="del" onclick="koPlanDel(\'' + f.id + '\');mgPaint()">✕</button>'
          + '</div>';
      }).join('')
    : '<p class="ff-empty">Nessuna fascia. Senza, la partita comincia solo quando la fischi tu.</p>';

  return testa
    + '<div class="ps-sub" style="margin-top:18px">Quanto dura</div>'
    + '<div class="mg-mins">' + chips
    +   '<button type="button" class="mg-min' + (MG_DURATE.indexOf(durata) < 0 ? ' on' : '') + '" onclick="mgDurataCustom()">'
    +   (MG_DURATE.indexOf(durata) < 0 ? durata + 'm' : 'Scegli tu') + '</button>'
    + '</div>'
    + '<div class="ps-sub" style="margin-top:18px">Oppure comincia da sola</div>'
    + '<p class="hintline" style="padding:0 2px 10px">Un\'ora fissa, e alla fine sai com\'è andata senza aver deciso niente.</p>'
    + '<div class="mg-fasce">' + righe + '</div>'
    /* DUE ORARI, NON UNO. «Aggiungi fascia» che chiedeva un'ora sola non era una fascia: era
       una sveglia. Una fascia ha un inizio e una fine, e la durata della partita esce da li'
       invece di arrivare da un'altra impostazione che l'utente in quel momento non guarda. */
    + '<div class="mg-addfascia">'
    +   '<label>Dalle<input id="mgFasciaDa" type="time" step="60" value="09:00" onchange="mgFasciaEcho()"></label>'
    +   '<label>Alle<input id="mgFasciaA" type="time" step="60" value="10:30" onchange="mgFasciaEcho()"></label>'
    + '</div>'
    + '<p class="mg-fascia-echo" id="mgFasciaEcho">90 minuti di partita</p>'
    + '<button type="button" class="ghostmini" style="width:100%" onclick="mgAddFascia()">Aggiungi questa fascia</button>';
}

async function mgSetDurata(m){
  if (await mgSave({ matchMin: m })) mgPaint();
}

async function mgDurataCustom(){
  const v = prompt('Quanti minuti dura una partita?', String(koDurata()));
  if (v === null) return;
  const n = Math.round(+v || 0);
  if (n < 1 || n > 600){ toast('Fra 1 e 600 minuti'); return; }
  if (await mgSave({ matchMin: n })) mgPaint();
}

/** «09:00» da ore e minuti, con i minuti che possono sforare le 24 e rientrare dal giro. */
function mgOra(h, m){
  const tot = ((h * 60 + m) % 1440 + 1440) % 1440;
  return String(Math.floor(tot / 60)).padStart(2, '0') + ':' + String(tot % 60).padStart(2, '0');
}

/** I minuti fra i due orari scelti. Oltre la mezzanotte si conta il giro, non un negativo. */
function mgFasciaMin(){
  const da = (document.getElementById('mgFasciaDa') || {}).value || '';
  const a = (document.getElementById('mgFasciaA') || {}).value || '';
  const p1 = da.split(':'), p2 = a.split(':');
  if (p1.length !== 2 || p2.length !== 2) return 0;
  const m1 = (+p1[0] || 0) * 60 + (+p1[1] || 0);
  const m2 = (+p2[0] || 0) * 60 + (+p2[1] || 0);
  let d = m2 - m1;
  if (d <= 0) d += 1440;
  return d;
}

/* Mentre si spostano i due orari, sotto compare quanto durera' la partita: e' l'unica cosa
   che la persona sta davvero decidendo, e prima non si vedeva da nessuna parte. */
function mgFasciaEcho(){
  const e = document.getElementById('mgFasciaEcho');
  if (!e) return;
  const d = mgFasciaMin();
  e.textContent = d ? d + ' minuti di partita' : 'Scegli due orari';
}

function mgAddFascia(){
  const da = (document.getElementById('mgFasciaDa') || {}).value || '';
  const p = da.split(':');
  const d = mgFasciaMin();
  if (p.length !== 2 || !d){ toast('Scegli l\'ora di inizio e quella di fine'); return; }
  if (d > 600){ toast('Una partita non pu\u00f2 durare pi\u00f9 di 10 ore'); return; }
  koPlanAdd(+p[0] || 0, +p[1] || 0, d);
  mgPaint();
  toast('Fascia aggiunta: dalle ' + mgOra(+p[0] || 0, +p[1] || 0) + ' per ' + d + ' minuti');
}

(function mgTempoStyle(){
  const css = [
    /* AL CENTRO. Su questa riga ci sono un'emoji, un titolo e due righe di spiegazione: con
       tre informazioni in un punto solo, l'allineamento a sinistra fa tre partenze diverse e
       l'occhio non sa da dove cominciare. */
    '.mg-wide{display:block;width:100%;text-align:center;margin-top:10px;border:1px solid var(--line);',
      'background:#fff;border-radius:18px;padding:14px 16px;cursor:pointer;font:inherit}',
    'body.dark .mg-wide{background:#12203A;border-color:#22345A}',
    '.mg-wide.on{border-color:#0075E3;background:rgba(0,117,227,.07)}',
    '.mg-wide b{display:block;font:800 15px var(--font-body);color:var(--navy)}',
    'body.dark .mg-wide b{color:#fff}',
    '.mg-wide.on b{color:#0075E3}',
    '.mg-wide small{display:block;margin-top:3px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.mg-mins{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;padding:2px;scrollbar-width:none}',
    '.mg-mins::-webkit-scrollbar{display:none}',
    '.mg-min{flex:0 0 auto;border:1px solid var(--line);background:#fff;border-radius:99px;',
      'padding:9px 15px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer;white-space:nowrap}',
    'body.dark .mg-min{background:#12203A;border-color:#22345A;color:#fff}',
    '.mg-min.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .mg-min.on{background:#fff;color:#0E1B33}',
    '.mg-live{border:1px solid #0075E3;background:rgba(0,117,227,.06)}',
    '.mg-fasce{display:flex;flex-direction:column;gap:8px}',
    '.mg-fascia{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--line);',
      'border-radius:14px;padding:11px 14px}',
    'body.dark .mg-fascia{background:#12203A;border-color:#22345A}',
    '.mg-fascia.off{opacity:.55}',
    '.mg-fascia b{font:800 16px var(--font-body);color:var(--navy)}',
    'body.dark .mg-fascia b{color:#fff}',
    '.mg-fascia small{flex:1;font:500 12px var(--font-body);color:var(--muted)}',
    '.mg-fascia button{border:0;background:rgba(14,35,80,.06);border-radius:9px;padding:6px 10px;',
      'font:700 12px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .mg-fascia button{background:rgba(255,255,255,.08);color:#fff}',
    '.mg-fascia button.del{color:#E5515F}',
    '.mg-addfascia{display:flex;gap:10px;margin-top:10px}',
    '.mg-addfascia label{flex:1;display:block;font:700 10.5px var(--font-body);letter-spacing:.1em;',
      'text-transform:uppercase;color:var(--muted);text-align:center}',
    '.mg-addfascia input{display:block;width:100%;margin-top:6px;border:1px solid var(--line);',
      'border-radius:14px;padding:11px 10px;font:700 15px var(--font-body);color:var(--navy);',
      'background:#fff;text-align:center;box-sizing:border-box}',
    'body.dark .mg-addfascia input{background:#12203A;border-color:#22345A;color:#fff}',
    '.mg-fascia-echo{text-align:center;font:700 12px var(--font-body);color:var(--muted);margin:10px 0}',

    /* ---------------------------------------------------------------- il pannello scuro
       Stesso vestito del pannello in fondo alla scheda Blocco: quando due cose sono «un
       blocco di roba che sta insieme», devono assomigliarsi, o l'utente impara due volte. */
    '.mg-tempo{background:linear-gradient(160deg,#12203A,#1E3A6B);border-radius:20px;',
      'padding:22px 18px;margin-top:12px;color:#fff;text-align:center}',
    '.mg-tempo .ps-block{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);',
      'border-radius:16px;padding:16px 14px;text-align:center}',
    '.mg-tempo .ps-block b{color:#fff}',
    '.mg-tempo .ps-sub{color:rgba(200,218,242,.86);text-align:center;font:800 10.5px var(--font-body);',
      'letter-spacing:.1em;text-transform:uppercase}',
    '.mg-tempo .hintline{color:#C8DAF2;text-align:center}',
    '.mg-tempo .ff-empty{color:#9FB6D8;text-align:center}',
    '.mg-tempo .mg-mins{justify-content:center}',
    '.mg-tempo .mg-min{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2);color:#fff}',
    '.mg-tempo .mg-min.on{background:#fff;border-color:#fff;color:#0E1B33}',
    '.mg-tempo .mg-live{border-color:#4FB8FF;background:rgba(79,184,255,.12)}',
    '.mg-tempo .mg-fascia{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.14)}',
    '.mg-tempo .mg-fascia b{color:#fff}',
    '.mg-tempo .mg-fascia small{color:#C8DAF2}',
    '.mg-tempo .mg-fascia button{background:rgba(255,255,255,.12);color:#fff}',
    '.mg-tempo .mg-fascia button.del{color:#FF8A9B}',
    '.mg-tempo .mg-addfascia label{color:rgba(200,218,242,.8)}',
    '.mg-tempo .mg-addfascia input{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2);color:#fff}',
    '.mg-tempo .mg-fascia-echo{color:#C8DAF2}',
    '.mg-tempo .ghostmini{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.22);color:#fff}'
  ].join('');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
