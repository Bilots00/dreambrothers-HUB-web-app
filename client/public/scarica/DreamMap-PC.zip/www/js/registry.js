/* registry.js - the screen registry, loaded FIRST.

   Every area of the app now owns its own module, and an area that needs a new screen adds it
   here at load time instead of editing index.html. Two reasons: several areas are worked on at
   once and a single shared markup file is a guaranteed collision, and a screen that lives next
   to the code driving it is easier to follow than one parked 400 lines away in the HTML.

   `order` lives here rather than in nav.js because modules register their screens while they
   load, and nav.js is deliberately loaded last. */

/* ===========================================================================================
   LA DATA DEL PRIMO AVVIO

   E' stata scritta in due formati da due moduli diversi — un numero da decision.js, una data
   ISO da profile.js — e letta da quattro posti che ne conoscevano uno solo: `new Date()` su
   una stringa numerica non e' una data, e da li' in poi ogni conto che parte dal primo avvio
   dava un risultato inventato, in silenzio.

   Sta qui perche' questo e' il primo file caricato: chiunque, da qualunque modulo, puo'
   chiamarla — anche chi lavora mentre il proprio file viene letto.
   =========================================================================================== */

/** Quando quest'app e' stata aperta la prima volta, in millisecondi. Zero se non lo sappiamo. */
function flPrimoAvvio(){
  let v = '';
  try{ v = localStorage.getItem('fl_first_run') || ''; }catch(_){ return 0; }
  if (!v) return 0;
  if (/^\d+$/.test(v)) return +v;              // il vecchio formato, ancora sui telefoni veri
  const d = new Date(v);
  return isNaN(d) ? 0 : d.getTime();
}

/** Segna il primo avvio se non c'e' ancora, e restituisce la data. Sempre in ISO, da adesso. */
function flPrimoAvvioSegna(){
  const t = flPrimoAvvio();
  if (t) return t;
  const ora = Date.now();
  try{ localStorage.setItem('fl_first_run', new Date(ora).toISOString()); }catch(_){ }
  return ora;
}

/** Da quanti giorni interi l'app e' su questo telefono. Zero se non lo sappiamo. */
function flGiorniDaPrimoAvvio(){
  const t = flPrimoAvvio();
  return t ? Math.max(0, Math.floor((Date.now() - t) / 86400000)) : 0;
}

const order = ["s0","s1","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","s12","s13",
               "s14","s15","s16","s-home","s-newtype","s-editor","s-blocklist","s-restricted"];

/* Where "back" leads from a registered screen. The onboarding screens are a line and walking
   to cur-1 is right for them; a screen summoned from somewhere else is not on that line, and
   without this it would drop the user into whatever happens to precede it in `order`. */
const BACK_TO = { "s-restricted": null, // null = ask the module (closeRestricted)
  /*
   * Indietro da un programma.
   *
   * s-editor e s-newtype sono scritti nell'HTML, non registrati, quindi nessuno diceva dove
   * porta il tasto Indietro e si finiva su cur-1: per l'editor quello è s-newtype, cioè la
   * schermata "che tipo di blocco vuoi", chiesta di nuovo per un blocco che esisteva già.
   * Da un programma che esiste si torna a casa; da uno che si sta creando si torna indietro
   * di un passo, alla scelta del tipo, che è il passo che l'ha portato lì.
   */
  "s-editor": function(){
    try{ return (typeof DRAFT !== 'undefined' && DRAFT && (DRAFT.idx >= 0 || DRAFT.id)) ? 's-home' : 's-newtype'; }
    catch(_){ return 's-home'; }
  },
  "s-newtype": "s-home",
  // The paywall is reachable from the home shell: back must return THERE, not to the onboarding
  // step that happens to precede it in this list.
  "s11": function(){ try{ return localStorage.getItem('fl_onboarded') === '1' ? 's-home' : 's10'; }catch(_){ return 's10'; } } };

/* Adds a screen to the DOM and to `order`. Idempotent: registering the same id twice returns
   the existing section instead of producing a duplicate that would break getElementById. */
function registerScreen(id, html, opts) {
  opts = opts || {};
  const existing = document.getElementById(id);
  if (existing) return existing;

  const sec = document.createElement("section");
  sec.className = "screen" + (opts.hero ? " hero" : "");
  sec.id = id;
  sec.innerHTML = html;

  // Before the sheet and the toast, which must stay the last children so they layer on top.
  const phone = document.getElementById("phone");
  const sheet = document.getElementById("sheetwrap");
  if (phone && sheet) phone.insertBefore(sec, sheet);
  else if (phone) phone.appendChild(sec);

  if (order.indexOf(id) < 0) order.push(id);
  if (opts.back) BACK_TO[id] = opts.back;
  return sec;
}

/* I FOGLI DENTRO AL TELEFONO, ANCHE QUELLI AGGANCIATI ALLA FINESTRA (0.9.272, Andrea). Sul computer l'app e' un
   telefono disegnato in mezzo alla finestra (#phone, app.css): "fisso" vale rispetto al telefono solo per chi sta
   DENTRO #phone. Una trentina di fogli (la card di "Per te", i fogli della Mappa, del Genio, dell'umore...) si
   aggiungevano a document.body: sul PC uscivano dalla cornice, larghi quanto la finestra, e stavano sopra a tutto il
   telefono, anche sopra ai fogli che si aprivano dopo (Sempre consentiti finiva DIETRO alla card).
   Regola sola, per quelli di adesso e quelli che verranno: un elemento aggiunto alla pagina che copre tutto
   (position:fixed con inset 0) va dentro al telefono, subito, prima che chi l'ha creato ci metta il fuoco. Sul
   telefono vero la finestra E' il telefono e non cambia niente; i fantasmi del trascinamento, i menu piccoli, i file
   da scegliere restano dove sono. */
(function(){
  const aggancia = function(){
    const body = document.body; if (!body || body.__flTel) return; body.__flTel = true;
    const orig = Node.prototype.appendChild;
    const cornice = function(){ try{ return window.matchMedia('(min-width:480px)').matches; }catch(_){ return false; } };
    body.appendChild = function(n){
      const r = orig.call(this, n);
      try{
        const ph = document.getElementById('phone');
        if (ph && n && n.nodeType === 1 && n !== ph && cornice()){
          const cs = getComputedStyle(n);
          if (cs.position === 'fixed' && cs.top === '0px' && cs.left === '0px' && cs.right === '0px' && cs.bottom === '0px') orig.call(ph, n);
        }
      }catch(_){ }
      return r;
    };
  };
  if (document.body) aggancia(); else document.addEventListener('DOMContentLoaded', aggancia);
})();

/* Registers a block of markup that is not a screen — a bottom sheet, a modal, an overlay.
   Same reasoning, same idempotence. */
function registerOverlay(id, html) {
  if (document.getElementById(id)) return document.getElementById(id);
  const el = document.createElement("div");
  el.id = id;
  el.innerHTML = html;
  const phone = document.getElementById("phone");
  if (phone) phone.appendChild(el);
  return el;
}

/* Which screen the app opens on, decided HERE and not at the end of nav.js.

   nav.js is the last of thirteen scripts: by the time it ran, the browser had already painted
   s0 — the welcome and login screen — and the swap to the home shell looked like the app
   forgetting you were logged in and then remembering. This file is the first script, and
   scripts at the end of <body> run before the first paint, so the swap is invisible. */
const LANDING = (function(){
  try{
    if(localStorage.getItem('fl_onboarded') !== '1') return 's0';
    const first = document.getElementById('s0');
    const home  = document.getElementById('s-home');
    if(!first || !home) return 's0';
    first.classList.remove('active');
    home.classList.add('active');
    // The gate in <head> (html.fl-home) kept the home shell visible from the first frame; from
    // here on the classes decide, or the shell would stay under every other screen.
    document.documentElement.classList.remove('fl-home');
    return 's-home';
  }catch(_){ return 's0'; }
})();


/* ---------------------------------------------------------------------------------------
   Gli slider.

   `accent-color` disegna il riempimento della barra, ma in questa WebView non lo ridisegna
   mentre si trascina: restava fermo al valore iniziale mentre il pallino andava avanti, e
   sembrava che l'app non stesse capendo il gesto. Il riempimento lo facciamo noi, con un
   gradiente che si aggiorna a ogni evento `input`; il pallino è disegnato sopra allo stesso
   punto, quindi i due non possono più separarsi.

   L'ascolto è delegato al documento: vale anche per gli slider creati dopo, senza doverli
   registrare uno per uno. */
function flRangeSync(el){
  if (!el || el.type !== 'range') return;
  const min = parseFloat(el.min) || 0;
  const max = parseFloat(el.max);
  const hi = isNaN(max) ? 100 : max;
  const v = parseFloat(el.value);
  const p = hi > min ? Math.max(0, Math.min(100, ((isNaN(v) ? min : v) - min) / (hi - min) * 100)) : 0;
  el.style.setProperty('--p', p.toFixed(2) + '%');
}
function flRangeAll(root){
  try{ (root || document).querySelectorAll('input[type=range]').forEach(flRangeSync); }catch(_){ }
}
document.addEventListener('input', function(e){ flRangeSync(e.target); }, true);
document.addEventListener('change', function(e){ flRangeSync(e.target); }, true);
document.addEventListener('fl:screen', function(){ setTimeout(flRangeAll, 30); });
document.addEventListener('fl:tab', function(){ setTimeout(flRangeAll, 30); });
/* LA BARRA PIENA DAL PRIMO DISEGNO, PER OGNI SLIDER, CHIUNQUE LO INSERISCA.
   Tre volte uno slider e' nato vuoto: la parte blu compariva solo dopo aver mosso la maniglia.
   La causa era sempre la stessa: questo foglio disegna la traccia con --p, e --p lo scriveva
   solo un evento (input, cambio scheda). Uno slider inserito da uno script dopo il cambio
   scheda restava a --p:0 finche' non lo toccavi. Da qui in poi lo vede un osservatore del DOM:
   qualunque input[type=range] che entra nella pagina viene riempito nello stesso giro. */
try{
  new MutationObserver(function(muts){
    for (let i = 0; i < muts.length; i++){
      const add = muts[i].addedNodes;
      for (let k = 0; k < add.length; k++){
        const n = add[k]; if (!n || n.nodeType !== 1) continue;
        if (n.tagName === 'INPUT' && n.type === 'range') flRangeSync(n);
        else if (n.querySelectorAll) n.querySelectorAll('input[type=range]').forEach(flRangeSync);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
}catch(_){ }

(function(){
  const css = [
    'input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:34px;background:transparent;margin:0}',
    'input[type=range]::-webkit-slider-runnable-track{height:6px;border-radius:99px;',
    '  background:linear-gradient(90deg,var(--rc,#006FCF) 0 var(--p,0%),var(--rt,rgba(127,127,140,.28)) var(--p,0%) 100%)}',
    'input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:26px;height:26px;margin-top:-10px;',
    '  border-radius:50%;background:#fff;border:3px solid var(--rc,#006FCF);box-shadow:0 2px 8px rgba(0,20,60,.35);cursor:pointer}',
    'input[type=range]:active::-webkit-slider-thumb{transform:scale(1.08)}',
    'input[type=range]::-moz-range-track{height:6px;border-radius:99px;background:var(--rt,rgba(127,127,140,.28))}',
    'input[type=range]::-moz-range-progress{height:6px;border-radius:99px;background:var(--rc,#006FCF)}',
    'input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:#fff;border:3px solid var(--rc,#006FCF)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
/* 0.9.380, Andrea: "il Salva del blocco rapido non e' fisso come nei programmi: ogni pagina con il pulsante Salva e un contenuto che
   scorre deve averlo attaccato al bordo in basso". La regola vale per tutte le pagine: l'ultimo pulsante principale della pagina (o il
   suo piede) resta attaccato al bordo, con lo sfondo della pagina dietro, come #s-editor .ed-piede */
(function(){ if (typeof document === 'undefined') return; const st = document.createElement('style'); st.textContent =
  '.screen > button.cta:last-child,.screen > .rp-addfoot:last-child,.screen > .cst-nome-piede:last-child{position:sticky;bottom:calc(-20px - env(safe-area-inset-bottom));z-index:6;flex:none;margin-bottom:calc(-20px - env(safe-area-inset-bottom));box-shadow:0 -12px 18px -4px var(--bg,#F4F9FF),0 0 0 14px var(--bg,#F4F9FF)}'
  + '.screen > .rp-addfoot:last-child,.screen > .cst-nome-piede:last-child{background:var(--bg,#F4F9FF);padding-bottom:calc(20px + env(safe-area-inset-bottom))}'
  /* 0.9.381, Andrea: "il Salva del blocco rapido tocca il bordo basso dello schermo, nei programmi c'e' un margine: copia quello che
     funziona". Il pulsante resta fisso ma a 16px dal bordo, con lo sfondo della pagina sotto e intorno (come il piede dei programmi) */
  + '.screen > button.cta:last-child{bottom:calc(16px + env(safe-area-inset-bottom))!important;margin-bottom:0!important;margin-top:24px;box-shadow:0 -14px 18px -4px var(--bg,#F4F9FF),0 0 0 14px var(--bg,#F4F9FF),0 30px 0 14px var(--bg,#F4F9FF)!important}'
  + '.psc-salva,.fl-salva{position:sticky!important;bottom:calc(16px + env(safe-area-inset-bottom));z-index:6;box-shadow:0 -14px 18px -4px var(--bg,#F4F9FF),0 0 0 14px var(--bg,#F4F9FF),0 30px 0 14px var(--bg,#F4F9FF)}'
  + '.fl-salva-attesa{display:none!important}'
  /* 0.9.382: la fascia del Salva, copiata da #s-editor .ed-piede (stesse misure, stesso sfondo) */
  + '.screen > .fl-piede{position:sticky;bottom:calc(-20px - env(safe-area-inset-bottom));z-index:6;flex:none;margin:18px -22px calc(-20px - env(safe-area-inset-bottom));padding:14px 22px calc(20px + env(safe-area-inset-bottom));background:var(--bg,#F4F9FF);box-shadow:0 -10px 18px -6px var(--bg,#F4F9FF)}'
  + '.screen > .fl-piede > button{position:static!important;margin:0!important;width:100%;min-height:57px;box-shadow:0 12px 26px rgba(0,117,227,.35)!important;bottom:auto!important}'
  + 'body.kbd .screen > button.cta:last-child{box-shadow:none}'; document.head.appendChild(st); })();
/* 0.9.380, Andrea: "Mostra altro, toccato, apre il contenuto ma resta li' sopra: come il Read more del mio tema deve sparire e tornare
   dopo il contenuto come Mostra meno". Vale per ogni Mostra altro dell'app fatto con <details> */
(function(){
  if (typeof document === 'undefined') return;
  const ALTRO = /^(Mostra altro|Mostra altre|Leggi tutto|Scopri di più)$/i;
  document.addEventListener('toggle', function(e){
    const d = e.target; if (!d || d.tagName !== 'DETAILS') return;
    const s = d.querySelector(':scope > summary'); if (!s) return;
    const t = (s.textContent || '').trim();
    if (!d.dataset.altro){ if (!ALTRO.test(t)) return; d.dataset.altro = t; d.classList.add('fl-altro'); }
    s.textContent = d.open ? 'Mostra meno' : d.dataset.altro;
  }, true);
  const st = document.createElement('style');
  st.textContent = 'details.fl-altro[open]{display:flex;flex-direction:column}details.fl-altro[open] > summary{order:99;margin-top:12px}';
  document.head.appendChild(st);
})();

/* 0.9.381, Andrea: "voglio sempre la stessa (i), non una volta in corsivo e un'altra diversa; e' leggermente spostata a destra; e non deve
   mai andare a capo da sola: piuttosto va a capo con lei l'ultima parola della riga". UNA forma per tutte le (i) dell'app: cerchio di 22px,
   Georgia corsiva, centrata a occhio (il corsivo pende a destra, quindi il carattere sta mezzo pixel a sinistra). Il colore segue il testo
   intorno: cosi' su un pannello scuro e' chiara e su un foglio chiaro e' scura, e non sparisce mai (la (i) del computer era chiara su chiaro).
   E un aggancio che, quando una (i) arriva dopo un testo, la incolla all'ultima parola con uno span che non va a capo. */
const FL_I_SEL = '.st-info,.or-info,.rmp-i,.dp-i,.am-lg-i,.suo-tm-i,.sfd-i,.sd-task-i,.rt-i,.pz-i,.pst-i,.pr-dt-i,.pnt-i,.nvs-ctl-i,.mm-hero-i,.hd-ser-i,.fr-ti,.fl-tip-i,.eta-d-ri,.dv-cal-i,.dso-prot-i,.clo-i2,.fl-i';
(function(){
  if (typeof document === 'undefined') return;
  const sel = FL_I_SEL.split(',');
  const st = document.createElement('style');
  st.textContent = sel.join(',') + '{box-sizing:border-box!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:none!important;width:22px!important;height:22px!important;min-width:22px!important;padding:0 1px 0 0!important;border-radius:50%!important;border:1.5px solid currentColor!important;background:none!important;font:italic 800 12.5px/1 Georgia,"Times New Roman",serif!important;letter-spacing:0!important;text-transform:none!important;text-indent:0!important;vertical-align:middle!important;cursor:pointer}'
    + '.fl-inw{white-space:nowrap}';
  document.head.appendChild(st);
  function incolla(b){
    if (!b || b.__flI) return; b.__flI = 1;
    const p = b.parentNode; if (!p || (p.classList && (p.classList.contains('fl-inw') || p.classList.contains('psc-nw')))) return;
    const t = b.previousSibling; if (!t || t.nodeType !== 3) return;
    const s = t.nodeValue; const m = /(\S+)(\s*)$/.exec(s); if (!m) return;
    const sp = document.createElement('span'); sp.className = 'fl-inw';
    t.nodeValue = s.slice(0, s.length - m[0].length);
    p.insertBefore(sp, b);
    sp.appendChild(document.createTextNode(m[1] + ' '));
    sp.appendChild(b);
  }
  let coda = false;
  function giro(){ coda = false; try{ document.querySelectorAll(FL_I_SEL).forEach(incolla); }catch(_){ } }
  try{ new MutationObserver(function(){ if (!coda){ coda = true; setTimeout(giro, 60); } }).observe(document.documentElement, { childList: true, subtree: true }); }catch(_){ }
  setTimeout(giro, 500);
})();

/* 0.9.381, Andrea: "il pulsante Salva deve comparire solo dopo che si e' fatta davvero una modifica: a un programma, al blocco rapido, a
   qualsiasi card. Se non hai cambiato niente e' inutile". Vale per ogni Salva dell'app: l'ultimo pulsante principale di una pagina che dice
   Salva, i Salva dei fogli delle card (.psc-salva) e chi lo chiede (.fl-salva). Restano nascosti finche' nella pagina (o in una sua
   sotto-pagina, come la lista del blocco rapido) non cambia qualcosa: un campo scritto, un interruttore, una scelta. Uscire dalla pagina
   verso un'altra azzera; tornare da una sua sotto-pagina no */
const FL_SALVA = { sporca: {}, ultima: '' };
function flSalvaBottoni(sc){
  if (!sc) return [];
  const out = [];
  const ult = sc.lastElementChild;
  if (ult && ult.matches && ult.matches('button.cta') && /^\s*Salva/i.test(ult.textContent || '')) out.push(ult);
  sc.querySelectorAll('.fl-piede > button').forEach(function(b){ if (out.indexOf(b) < 0) out.push(b); });
  sc.querySelectorAll('.psc-salva,.fl-salva').forEach(function(b){ if (out.indexOf(b) < 0) out.push(b); });
  return out;
}
/* 0.9.382, Andrea: "il footer che contiene il Salva nel blocco rapido e nel Salva luogo deve essere IDENTICO a quello della pagina dei
   programmi: non reinventare la ruota, copialo". Il piede dei programmi e' #s-editor .ed-piede: una fascia piena, attaccata al fondo,
   14px sopra al pulsante e 20px sotto. Ogni Salva di una pagina viene messo dentro a una fascia con le STESSE misure (.fl-piede), come
   ultimo figlio della pagina: niente piu' pulsanti appoggiati da soli con un'ombra che finge lo sfondo */
function flPiedeSistema(sc){
  if (!sc || !sc.classList || !sc.classList.contains('screen') || sc.id === 's-editor') return;
  const nuovi = flSalvaBottoni(sc).filter(function(b){ return !(b.parentElement && b.parentElement.classList.contains('fl-piede')); });
  if (!nuovi.length) return;
  /* un ridisegno ha creato un Salva nuovo: il piede vecchio (con il pulsante di prima) si toglie, cosi' non ce ne sono due */
  sc.querySelectorAll(':scope > .fl-piede').forEach(function(p){ p.remove(); });
  const b = nuovi[nuovi.length - 1];
  const p = document.createElement('div'); p.className = 'fl-piede';
  sc.appendChild(p); p.appendChild(b);
}
/* Pagine che sanno dire da sole se qualcosa e' cambiato: il blocco rapido confronta app, siti, parole e modalita' con quelli di quando
   l'hai aperto (una categoria accesa nella lista, Lista di blocco -> Elenco consentiti, un'opzione extra: tutto vale come modifica) */
const FL_SALVA_STATO = {
  's-quick': function(){ try{ return JSON.stringify([QUICK.apps, QUICK.sites, QUICK.keywords, EXTRA.listMode, EXTRA.allowApps, (typeof ubFunzScelte === 'function' ? ubFunzScelte() : 0)]); }catch(_){ return ''; } }
};
const FL_SALVA_FOTO = {};
function flSalvaApplica(id){
  const sc = document.getElementById(id); if (!sc) return;
  try{ flPiedeSistema(sc); }catch(_){ }
  if (FL_SALVA_STATO[id] && FL_SALVA_FOTO[id] !== undefined && FL_SALVA_STATO[id]() !== FL_SALVA_FOTO[id]) FL_SALVA.sporca[id] = true;
  const sporca = !!FL_SALVA.sporca[id];
  flSalvaBottoni(sc).forEach(function(b){
    b.classList.toggle('fl-salva-attesa', !sporca);
    const p = b.parentElement; if (p && p.classList.contains('fl-piede')) p.classList.toggle('fl-salva-attesa', !sporca);
  });
}
function flModificato(id){
  if (!id) return;
  FL_SALVA.sporca[id] = true; flSalvaApplica(id);
  const su = (typeof BACK_TO !== 'undefined') ? BACK_TO[id] : null;
  if (su && su !== 's-home'){ FL_SALVA.sporca[su] = true; }
}
(function(){
  if (typeof document === 'undefined') return;
  const NO = '.topbar,.iconbtn,.setrow,summary,a,[aria-label="Chiudi"],.am-x,.chev,.psc-salva,.fl-salva,' + (typeof FL_I_SEL === 'string' ? FL_I_SEL : '.pst-i');
  const SI = 'input,select,textarea,label,.switch,[role="switch"],[role="radio"],[role="checkbox"],[aria-checked],.chip,.sev-chips button,.md-step button,.psc-step button,.psc-casa-emo button,.psc-casa-sf button,.psc-unita button,.ql-row,.ub-row,.al-row,[data-mod]';
  function schermoDi(el){ const s = el && el.closest ? el.closest('.screen') : null; return s ? s.id : ''; }
  function segna(e){
    const t = e.target; if (!t || !t.closest) return;
    if (e.type === 'click'){
      if (t.closest(NO)) return;
      if (!t.closest(SI)) return;
      if (t.closest('button.cta') && /^\s*Salva/i.test(t.closest('button.cta').textContent || '')) return;
    }
    const id = schermoDi(t); if (id) flModificato(id);
  }
  document.addEventListener('input', segna, true);
  document.addEventListener('change', segna, true);
  document.addEventListener('click', segna, true);
  document.addEventListener('fl:screen', function(e){
    const id = e && e.detail, prima = FL_SALVA.ultima; FL_SALVA.ultima = id || '';
    if (!id) return;
    const figlio = prima && typeof BACK_TO !== 'undefined' && BACK_TO[prima] === id;
    if (prima !== id && !figlio){ FL_SALVA.sporca[id] = false; if (FL_SALVA_STATO[id]) FL_SALVA_FOTO[id] = FL_SALVA_STATO[id](); }
    flSalvaApplica(id);
    setTimeout(function(){ flSalvaApplica(id); }, 120);
  });
  /* i fogli e le pagine che si ridisegnano dopo l'ingresso (le card del luogo, della casa) */
  let coda = false;
  try{ new MutationObserver(function(){ if (coda) return; coda = true; setTimeout(function(){ coda = false; if (FL_SALVA.ultima) flSalvaApplica(FL_SALVA.ultima); document.querySelectorAll('#inSheet .psc-salva, #inSheet .fl-salva').forEach(function(b){ if (!b.__flS){ b.__flS = 1; b.classList.add('fl-salva-attesa'); const f = b.closest('#inSheet'); if (f && !f.__flS){ f.__flS = 1; f.addEventListener('input', function(){ f.querySelectorAll('.psc-salva,.fl-salva').forEach(function(x){ x.classList.remove('fl-salva-attesa'); }); }, true); f.addEventListener('click', function(ev){ const tt = ev.target; if (tt && tt.closest && tt.closest(SI) && !tt.closest(NO)) f.querySelectorAll('.psc-salva,.fl-salva').forEach(function(x){ x.classList.remove('fl-salva-attesa'); }); }, true); } } }); }, 80); }).observe(document.documentElement, { childList: true, subtree: true }); }catch(_){ }
})();
