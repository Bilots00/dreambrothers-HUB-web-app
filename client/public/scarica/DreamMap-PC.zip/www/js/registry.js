/* registry.js - the screen registry, loaded FIRST.

   Every area of the app now owns its own module, and an area that needs a new screen adds it
   here at load time instead of editing index.html. Two reasons: several areas are worked on at
   once and a single shared markup file is a guaranteed collision, and a screen that lives next
   to the code driving it is easier to follow than one parked 400 lines away in the HTML.

   `order` lives here rather than in nav.js because modules register their screens while they
   load, and nav.js is deliberately loaded last. */

/* ===========================================================================================
   LA DATA DEL PRIMO AVVIO

   E' stata scritta in due formati da due moduli diversi — un numero da decision.js, una data
   ISO da profile.js — e letta da quattro posti che ne conoscevano uno solo: `new Date()` su
   una stringa numerica non e' una data, e da li' in poi ogni conto che parte dal primo avvio
   dava un risultato inventato, in silenzio.

   Sta qui perche' questo e' il primo file caricato: chiunque, da qualunque modulo, puo'
   chiamarla — anche chi lavora mentre il proprio file viene letto.
   =========================================================================================== */

/** Quando quest'app e' stata aperta la prima volta, in millisecondi. Zero se non lo sappiamo. */
function flPrimoAvvio(){
  let v = '';
  try{ v = localStorage.getItem('fl_first_run') || ''; }catch(_){ return 0; }
  if (!v) return 0;
  if (/^\d+$/.test(v)) return +v;              // il vecchio formato, ancora sui telefoni veri
  const d = new Date(v);
  return isNaN(d) ? 0 : d.getTime();
}

/** Segna il primo avvio se non c'e' ancora, e restituisce la data. Sempre in ISO, da adesso. */
function flPrimoAvvioSegna(){
  const t = flPrimoAvvio();
  if (t) return t;
  const ora = Date.now();
  try{ localStorage.setItem('fl_first_run', new Date(ora).toISOString()); }catch(_){ }
  return ora;
}

/** Da quanti giorni interi l'app e' su questo telefono. Zero se non lo sappiamo. */
function flGiorniDaPrimoAvvio(){
  const t = flPrimoAvvio();
  return t ? Math.max(0, Math.floor((Date.now() - t) / 86400000)) : 0;
}

const order = ["s0","s1","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","s12","s13",
               "s14","s15","s16","s-home","s-newtype","s-editor","s-blocklist","s-restricted"];

/* Where "back" leads from a registered screen. The onboarding screens are a line and walking
   to cur-1 is right for them; a screen summoned from somewhere else is not on that line, and
   without this it would drop the user into whatever happens to precede it in `order`. */
const BACK_TO = { "s-restricted": null, // null = ask the module (closeRestricted)
  /*
   * Indietro da un programma.
   *
   * s-editor e s-newtype sono scritti nell'HTML, non registrati, quindi nessuno diceva dove
   * porta il tasto Indietro e si finiva su cur-1: per l'editor quello è s-newtype, cioè la
   * schermata "che tipo di blocco vuoi", chiesta di nuovo per un blocco che esisteva già.
   * Da un programma che esiste si torna a casa; da uno che si sta creando si torna indietro
   * di un passo, alla scelta del tipo, che è il passo che l'ha portato lì.
   */
  "s-editor": function(){
    try{ return (typeof DRAFT !== 'undefined' && DRAFT && (DRAFT.idx >= 0 || DRAFT.id)) ? 's-home' : 's-newtype'; }
    catch(_){ return 's-home'; }
  },
  "s-newtype": "s-home",
  // The paywall is reachable from the home shell: back must return THERE, not to the onboarding
  // step that happens to precede it in this list.
  "s11": function(){ try{ return localStorage.getItem('fl_onboarded') === '1' ? 's-home' : 's10'; }catch(_){ return 's10'; } } };

/* Adds a screen to the DOM and to `order`. Idempotent: registering the same id twice returns
   the existing section instead of producing a duplicate that would break getElementById. */
function registerScreen(id, html, opts) {
  opts = opts || {};
  const existing = document.getElementById(id);
  if (existing) return existing;

  const sec = document.createElement("section");
  sec.className = "screen" + (opts.hero ? " hero" : "");
  sec.id = id;
  sec.innerHTML = html;

  // Before the sheet and the toast, which must stay the last children so they layer on top.
  const phone = document.getElementById("phone");
  const sheet = document.getElementById("sheetwrap");
  if (phone && sheet) phone.insertBefore(sec, sheet);
  else if (phone) phone.appendChild(sec);

  if (order.indexOf(id) < 0) order.push(id);
  if (opts.back) BACK_TO[id] = opts.back;
  return sec;
}

/* I FOGLI DENTRO AL TELEFONO, ANCHE QUELLI AGGANCIATI ALLA FINESTRA (0.9.272, Andrea). Sul computer l'app e' un
   telefono disegnato in mezzo alla finestra (#phone, app.css): "fisso" vale rispetto al telefono solo per chi sta
   DENTRO #phone. Una trentina di fogli (la card di "Per te", i fogli della Mappa, del Genio, dell'umore...) si
   aggiungevano a document.body: sul PC uscivano dalla cornice, larghi quanto la finestra, e stavano sopra a tutto il
   telefono, anche sopra ai fogli che si aprivano dopo (Sempre consentiti finiva DIETRO alla card).
   Regola sola, per quelli di adesso e quelli che verranno: un elemento aggiunto alla pagina che copre tutto
   (position:fixed con inset 0) va dentro al telefono, subito, prima che chi l'ha creato ci metta il fuoco. Sul
   telefono vero la finestra E' il telefono e non cambia niente; i fantasmi del trascinamento, i menu piccoli, i file
   da scegliere restano dove sono. */
(function(){
  const aggancia = function(){
    const body = document.body; if (!body || body.__flTel) return; body.__flTel = true;
    const orig = Node.prototype.appendChild;
    const cornice = function(){ try{ return window.matchMedia('(min-width:480px)').matches; }catch(_){ return false; } };
    body.appendChild = function(n){
      const r = orig.call(this, n);
      try{
        const ph = document.getElementById('phone');
        if (ph && n && n.nodeType === 1 && n !== ph && cornice()){
          const cs = getComputedStyle(n);
          if (cs.position === 'fixed' && cs.top === '0px' && cs.left === '0px' && cs.right === '0px' && cs.bottom === '0px') orig.call(ph, n);
        }
      }catch(_){ }
      return r;
    };
  };
  if (document.body) aggancia(); else document.addEventListener('DOMContentLoaded', aggancia);
})();

/* Registers a block of markup that is not a screen — a bottom sheet, a modal, an overlay.
   Same reasoning, same idempotence. */
function registerOverlay(id, html) {
  if (document.getElementById(id)) return document.getElementById(id);
  const el = document.createElement("div");
  el.id = id;
  el.innerHTML = html;
  const phone = document.getElementById("phone");
  if (phone) phone.appendChild(el);
  return el;
}

/* Which screen the app opens on, decided HERE and not at the end of nav.js.

   nav.js is the last of thirteen scripts: by the time it ran, the browser had already painted
   s0 — the welcome and login screen — and the swap to the home shell looked like the app
   forgetting you were logged in and then remembering. This file is the first script, and
   scripts at the end of <body> run before the first paint, so the swap is invisible. */
const LANDING = (function(){
  try{
    if(localStorage.getItem('fl_onboarded') !== '1') return 's0';
    const first = document.getElementById('s0');
    const home  = document.getElementById('s-home');
    if(!first || !home) return 's0';
    first.classList.remove('active');
    home.classList.add('active');
    // The gate in <head> (html.fl-home) kept the home shell visible from the first frame; from
    // here on the classes decide, or the shell would stay under every other screen.
    document.documentElement.classList.remove('fl-home');
    return 's-home';
  }catch(_){ return 's0'; }
})();


/* ---------------------------------------------------------------------------------------
   Gli slider.

   `accent-color` disegna il riempimento della barra, ma in questa WebView non lo ridisegna
   mentre si trascina: restava fermo al valore iniziale mentre il pallino andava avanti, e
   sembrava che l'app non stesse capendo il gesto. Il riempimento lo facciamo noi, con un
   gradiente che si aggiorna a ogni evento `input`; il pallino è disegnato sopra allo stesso
   punto, quindi i due non possono più separarsi.

   L'ascolto è delegato al documento: vale anche per gli slider creati dopo, senza doverli
   registrare uno per uno. */
function flRangeSync(el){
  if (!el || el.type !== 'range') return;
  const min = parseFloat(el.min) || 0;
  const max = parseFloat(el.max);
  const hi = isNaN(max) ? 100 : max;
  const v = parseFloat(el.value);
  const p = hi > min ? Math.max(0, Math.min(100, ((isNaN(v) ? min : v) - min) / (hi - min) * 100)) : 0;
  el.style.setProperty('--p', p.toFixed(2) + '%');
}
function flRangeAll(root){
  try{ (root || document).querySelectorAll('input[type=range]').forEach(flRangeSync); }catch(_){ }
}
document.addEventListener('input', function(e){ flRangeSync(e.target); }, true);
document.addEventListener('change', function(e){ flRangeSync(e.target); }, true);
document.addEventListener('fl:screen', function(){ setTimeout(flRangeAll, 30); });
document.addEventListener('fl:tab', function(){ setTimeout(flRangeAll, 30); });
/* LA BARRA PIENA DAL PRIMO DISEGNO, PER OGNI SLIDER, CHIUNQUE LO INSERISCA.
   Tre volte uno slider e' nato vuoto: la parte blu compariva solo dopo aver mosso la maniglia.
   La causa era sempre la stessa: questo foglio disegna la traccia con --p, e --p lo scriveva
   solo un evento (input, cambio scheda). Uno slider inserito da uno script dopo il cambio
   scheda restava a --p:0 finche' non lo toccavi. Da qui in poi lo vede un osservatore del DOM:
   qualunque input[type=range] che entra nella pagina viene riempito nello stesso giro. */
try{
  new MutationObserver(function(muts){
    for (let i = 0; i < muts.length; i++){
      const add = muts[i].addedNodes;
      for (let k = 0; k < add.length; k++){
        const n = add[k]; if (!n || n.nodeType !== 1) continue;
        if (n.tagName === 'INPUT' && n.type === 'range') flRangeSync(n);
        else if (n.querySelectorAll) n.querySelectorAll('input[type=range]').forEach(flRangeSync);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
}catch(_){ }

(function(){
  const css = [
    'input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:34px;background:transparent;margin:0}',
    'input[type=range]::-webkit-slider-runnable-track{height:6px;border-radius:99px;',
    '  background:linear-gradient(90deg,var(--rc,#006FCF) 0 var(--p,0%),var(--rt,rgba(127,127,140,.28)) var(--p,0%) 100%)}',
    'input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:26px;height:26px;margin-top:-10px;',
    '  border-radius:50%;background:#fff;border:3px solid var(--rc,#006FCF);box-shadow:0 2px 8px rgba(0,20,60,.35);cursor:pointer}',
    'input[type=range]:active::-webkit-slider-thumb{transform:scale(1.08)}',
    'input[type=range]::-moz-range-track{height:6px;border-radius:99px;background:var(--rt,rgba(127,127,140,.28))}',
    'input[type=range]::-moz-range-progress{height:6px;border-radius:99px;background:var(--rc,#006FCF)}',
    'input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:#fff;border:3px solid var(--rc,#006FCF)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
