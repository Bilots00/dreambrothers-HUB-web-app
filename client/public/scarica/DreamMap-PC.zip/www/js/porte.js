/* ===========================================================================================
   LE PORTE — la ristrutturazione della barra in basso (27/09/2026, esperimento in transizione)

   Prima: Blocco · Roadmap · START · Profilo. Adesso: Rotta · Mappa · Roadmap · START · Profilo.
   «Blocco» non e' piu' una scheda ma una PAGINA (s-blocco): dentro c'e' TUTTO quello che c'era
   nella scheda, nodo per nodo — il DOM della vecchia scheda viene spostato qui, non copiato,
   cosi' programmi, blocco rapido, pannello Full Focus e panoramica continuano a funzionare con
   le stesse funzioni e gli stessi id. Ci si arriva dallo Scudo nella scheda START e dal menu.

   Qui vivono anche:
   · i pannelli nuovi della scheda START (Scudo, Modalita' Severa «scegli la pillola», Chiama
     il tuo Io futuro, Sveglia), presi dal prototipo di Claude Design, sotto al cielo;
   · la pagina dedicata della Modalita' severa (s-severa-pagina), che ADOTTA i nodi della
     sezione che sta nella Roadmap e li restituisce quando si esce: una sezione sola, due porte;
   · la bolla della partita al centro dell'intestazione (Nuovo te · Vecchio te), e la scelta,
     in Personalizza, fra quella e il tempo di schermo;
   · i pedaggi della schermata di blocco «Uscita di rotta»: quanti giorni costa ogni app, calcolati
     dalle abitudini vere (media degli ultimi 14 giorni) e dal piano dell'ETA, e spediti al
     motore nativo che li disegna.
   =========================================================================================== */

/* ---------------------------------------------------------------- la pagina Blocco */
registerScreen('s-blocco',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">🛡️ Proteggi i tuoi sogni</b></div>'
  + '<div id="blHost"></div><div class="spacer"></div>', { back: 's-home' });

(function blAdotta(){
  const tb = document.getElementById('tab-blocco'), host = document.getElementById('blHost');
  if (!tb || !host) return;
  host.appendChild(tb);
  tb.classList.add('on', 'bl-pagina');
  /* un id per ogni blocco: serve a «Personalizza la pagina» (0.9.204) per spostarli e toglierli */
  const dai = function(sel, id){ const el = tb.querySelector(':scope > ' + sel); if (el && !el.id) el.id = id; };
  dai('.qb', 'blQb'); dai('.sect', 'blProgSect'); dai('.blk-tplhead', 'blTplHead'); dai('.sev-intro', 'blIntro'); dai('.blk-doom', 'blDoom');
})();
function blPaginaApri(){
  goId('s-blocco');
  /* la Modalita' severa chiude la pagina, dopo le app del doom-scrolling */
  try{
    const host = document.getElementById('blHost');
    let f = document.getElementById('blSeveraFondo');
    if (!f && host){ f = document.createElement('div'); f.id = 'blSeveraFondo'; f.className = 'bl-severa-fondo'; host.appendChild(f); }
    if (f){ f.innerHTML = ptSeveraSezioneHtml(); try{ if (typeof faInlineAggancia === 'function') faInlineAggancia(f); }catch(_){ } }
  }catch(_){ }
  try{ document.dispatchEvent(new CustomEvent('fl:tab', { detail: 'blocco' })); }catch(_){ }
  try{ if (typeof syncNative === 'function') syncNative(); }catch(_){ }
  try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ }
}

/* ---------------------------------------------------------------- VISUALIZATION: il Mind Movie in una pagina sua
   La sala (#cnSlides + #cnBox, cinema.js) trasloca dalla Roadmap a questa pagina. Si apre da
   «Le tue pagine» nella Mappa e dalla pagina della partita. */
registerScreen('s-visualization',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title">🎬 Visualizzazione</b></div>'
  + '<div id="vzHost"></div><div class="spacer"></div>', { back: 's-home' });
(function vzAdotta(){
  const host = document.getElementById('vzHost'); if (!host) return;
  ['cnSlides', 'cnBox'].forEach(function(id){ const el = document.getElementById(id); if (el) host.appendChild(el); });
})();
/* 0.9.322, Andrea: "la Visualizzazione, il film e la videochiamata restano bloccati, in arrivo: li devo ancora finire" */
function flInArrivo(){ try{ toast('In arrivo'); flVibra(10); }catch(_){ } }
function vzApri(){
  flInArrivo(); return;
  goId('s-visualization');
  setTimeout(function(){
    try{ if (typeof cnSlides === 'function') cnSlides(); }catch(_){ }
    try{ if (typeof cnPaint === 'function') cnPaint('cnBox'); }catch(_){ }
  }, 60);
}

/* ---------------------------------------------------------------- la pagina Modalita' severa */
registerScreen('s-severa-pagina',
  /* 0.9.291, Andrea: "il titolo in alto non e' centrato, e manca la (i) che spiega cosa e' bloccato quando e' attiva" */
  '<div class="topbar svp-top"><button class="iconbtn" onclick="svpChiudi();flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title">Modalità severa</b><button type="button" class="iconbtn svp-i" onclick="svhInfoApri()" aria-label="Cosa è bloccato quando è attiva"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg></button></div>'
  + '<div id="svpHost"></div><div class="spacer"></div>', { back: function(){ svpChiudi(); return 's-home'; } });

const SVP_IDS = ['sevTabBox', 'ifCardHost', 'sevStreakFoot'];
function svpNodi(){
  const out = [];
  const tab = document.getElementById('tab-severa');
  const intro = tab ? Array.prototype.filter.call(tab.children, function(el){ return el.classList.contains('sev-intro') && !el.classList.contains('cn-intro'); })[0] : null;
  if (intro) out.push(intro);
  SVP_IDS.forEach(function(id){ const el = document.getElementById(id); if (el) out.push(el); });
  return out;
}
/* La Roadmap non c'e' piu' (0.9.169): la sezione si adotta una volta, all'avvio, e resta qui. */
function svpAdotta(){
  const host = document.getElementById('svpHost'); if (!host || host.children.length) return;
  svpNodi().forEach(function(el){ host.appendChild(el); });
}
setTimeout(svpAdotta, 0);
function svpApri(){
  const host = document.getElementById('svpHost'); if (!host) return;
  svpAdotta();
  if (!host.children.length){
    svpNodi().forEach(function(el){
      const ph = document.createElement('div'); ph.hidden = true; ph.className = 'svp-ph';
      el.parentNode.insertBefore(ph, el);
      el._svpPh = ph;
      host.appendChild(el);
    });
  }
  goId('s-severa-pagina');
  try{ svpPillolaPaint(); }catch(_){ }
  try{ if (typeof sevSyncTab === 'function') sevSyncTab(); }catch(_){ }
  try{ if (typeof ifCardPaint === 'function') ifCardPaint(); }catch(_){ }
}
function svpChiudi(){
  return;   /* la sezione non torna piu' indietro: la sua casa e' questa pagina */
  const host = document.getElementById('svpHost'); if (!host) return;
  Array.prototype.slice.call(host.children).forEach(function(el){
    const ph = el._svpPh;
    if (ph && ph.parentNode){ ph.parentNode.insertBefore(el, ph); ph.remove(); }
    el._svpPh = null;
  });
}

/* ---------------------------------------------------------------- i pannelli della scheda START */
function ptOra(ms){ const d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function ptScudoTesto(){
  let prog = 0; try{ prog = (PROGRAMS || []).filter(function(p){ return p && p.on !== false; }).length; }catch(_){ }
  let quick = false; try{ quick = !!(typeof QUICK !== 'undefined' && QUICK && QUICK.enabled); }catch(_){ }
  const bits = [];
  if (quick) bits.push('Blocco rapido acceso');
  if (prog) bits.push(prog + (prog === 1 ? ' programma attivo' : ' programmi attivi'));
  return bits.length ? bits.join(' · ') : 'Niente bloccato adesso. Tocca per scegliere.';
}
function ptSeveraTesto(){
  try{
    const s = (typeof sevState !== 'undefined') ? sevState : null;
    if (s && s.level > 0){
      const u = +s.strictUntil || 0;
      return u > Date.now() ? 'Accesa fino alle ' + ptOra(u) + (new Date(u).toDateString() !== new Date().toDateString() ? ' di ' + new Date(u).toLocaleDateString('it-IT', { weekday: 'long' }) : '') : 'Accesa';
    }
  }catch(_){ }
  return 'Scegli la pillola';
}
function ptSvegliaTesto(){
  try{
    const l = (typeof AL !== 'undefined' && AL && AL.list) ? AL.list.filter(function(a){ return a && a.on !== false && a.enabled !== false; }) : [];
    if (l.length){
      const a = l.slice().sort(function(x, y){ return (x.h * 60 + x.m) - (y.h * 60 + y.m); })[0];
      if (typeof a.h === 'number') return 'Sveglia ' + a.h + ':' + String(a.m || 0).padStart(2, '0');
    }
  }catch(_){ }
  return 'Sveglia';
}
/* la card della Severa: nella Rotta non c'e' piu' (0.9.177), sta in fondo alla pagina Blocco */
function ptSeveraCardHtml(){
  return '<button type="button" class="pt-card nera" onclick="svpApri()"><span class="pt-pillole"><i class="rossa"></i><i class="blu"></i></span><div><b>Modalità Severa</b><small>' + esc(ptSeveraTesto()) + '</small></div><i class="pt-chev">›</i></button>';
}
/* IN FONDO AL BLOCCO: il titolo, le due pillole di Matrix e la card. «La scelta e' tua». */
/* 0.9.273, Andrea: le due pillole non erano una scelta, erano un disegno. Adesso si scelgono davvero, tenendole
   premute come in Until Dawn (farfalla.js). Scelta fatta, qui resta solo cosa hai scelto e la card: si cambia da
   Impostazioni → Le tue scelte, o quando il Genio lo propone. */
function ptSeveraSezioneHtml(){
  const scelta = (typeof faSevera === 'function') ? faSevera() : null;
  const testa = '<div class="bl-sev-t"><span>🔒</span><h2>Modalità Severa</h2><p>Il blocco che non si può spegnere: la chiave la tiene l’app, per il tempo che scegli tu.</p></div>';
  /* 0.9.297, Andrea: "la scelta delle pillole non va fatta in un pannello di questa pagina ma sulla schermata a tutto schermo
     dell'effetto farfalla". Qui resta la scorciatoia: una riga che apre quella schermata, per scegliere o per cambiare. */
  const SVG_CHEV = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  /* 0.9.335, Andrea: "nella sezione ci deve essere solo la modalita' severa: la prima volta 'Scegli la pillola' fa partire
     l'effetto farfalla; dopo, un pannello grande e scuro come quello del contratto, con la pillola scelta. La pillola si
     cambia dalla pagina della modalita' severa, e il contratto sta li', non qui" */
  if (!scelta) return testa + '<button type="button" class="pt-sev-grande" onclick="faApriPillola()"><span class="pt-sev-pill"><span class="fa-pill rossa"></span><span class="fa-pill blu"></span></span>'
    + '<b>Scegli la pillola</b><small>Rossa o blu: la scelta cambia la tua strada.</small></button>';
  const rossa = scelta.scelta === 'rossa';
  return testa + '<button type="button" class="pt-sev-grande" onclick="svpApri()"><span class="pt-sev-pill"><span class="fa-pill ' + (rossa ? 'rossa' : 'blu') + '"></span></span>'
    + '<b>Modalità Severa</b><small>' + esc(ptSeveraTesto() === 'Scegli la pillola' ? 'Hai scelto la pillola ' + (rossa ? 'rossa' : 'blu') + '. Tocca per accenderla.' : ptSeveraTesto()) + '</small>' + SVG_CHEV + '</button>';
}
/* nella pagina della modalita' severa, in cima: la pillola scelta, che da qui si cambia */
function svpPillolaPaint(){
  const host = document.getElementById('svpHost'); if (!host) return;
  let h = document.getElementById('svpPillola');
  if (!h){ h = document.createElement('div'); h.id = 'svpPillola'; h.className = 'svp-pillola'; const box = document.getElementById('sevTabBox'); if (box && box.parentNode === host) host.insertBefore(h, box); else host.insertBefore(h, host.firstChild); }
  const scelta = (typeof faSevera === 'function') ? faSevera() : null;
  const chev = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  h.innerHTML = scelta
    ? '<button type="button" class="fa-bivio-via pt-scelta pt-scegli" onclick="faApriPillola()"><span class="fa-pill ' + (scelta.scelta === 'rossa' ? 'rossa' : 'blu') + '"></span><div>Hai scelto la pillola ' + (scelta.scelta === 'rossa' ? 'rossa' : 'blu') + '<small>Tocca per cambiare</small></div>' + chev + '</button>'
    : '<button type="button" class="fa-bivio-via pt-scelta pt-scegli" onclick="faApriPillola()"><span class="fa-pill rossa"></span><span class="fa-pill blu"></span><div>Scegli la pillola<small>Rossa o blu</small></div>' + chev + '</button>';
}
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-severa-pagina') setTimeout(svpPillolaPaint, 30); });
function ptPortePaint(){
  /* 0.9.186: le due porte sono due blocchi della pagina, ognuno spostabile da solo */
  const ch = document.getElementById('nvChiama'), sv = document.getElementById('nvSveglia');
  if (ch) ch.innerHTML = '<div class="pt-porte"><button type="button" class="pt-mini pt-largo" onclick="ptChiamaApri()"><span>📞</span><b>Chiama il tuo Io futuro</b></button></div>';
  /* 0.9.193 (Andrea): al posto della sveglia la videochiamata con l'Io futuro, «In arrivo».
     Chiamata e videochiamata sono Premium: il controllo sta in iofuturo-chiamata.js. */
  if (sv) sv.innerHTML = '<div class="pt-porte"><button type="button" class="pt-mini pt-largo" onclick="flInArrivo()"><span>🎥</span><b>Videochiama il tuo Io futuro</b><i class="pt-arrivo">In arrivo</i></button></div>';
  const h = document.getElementById('nvPorte'); if (!h) return;
  /* Lo Scudo e la Severa non stanno piu' qui: lo Scudo e' una scorciatoia sopra, la Severa
     e' in fondo alla pagina Blocco (dopo le app del doom-scrolling). Restano le due piccole. */
  h.innerHTML = '<div class="pt-porte">'
    + '<div class="pt-due">'
    +   '<button type="button" class="pt-mini" onclick="ptChiamaApri()"><span>📞</span><b>Chiama il tuo Io futuro</b></button>'
    +   '<button type="button" class="pt-mini" onclick="flInArrivo()"><span>🎥</span><b>Videochiama il tuo Io futuro</b><i class="pt-arrivo">In arrivo</i></button>'
    + '</div></div>';
}
function ptChiamaApri(){
  /* 0.9.193: la chiamata vera con l'Io futuro; le impostazioni della «chiamata dei sogni»
     restano in Impostazioni */
  if (typeof icApri === 'function'){ icApri(); return; }
  goId('s-settings');
  setTimeout(function(){ const el = document.getElementById('dcBlock'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 300);
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'rotta') setTimeout(ptPortePaint, 50); });
setTimeout(ptPortePaint, 1200);
setInterval(ptPortePaint, 60000);

/* ---------------------------------------------------------------- la bolla nell'intestazione */
const PT_BOLLA_KEY = 'fl_hdr_bolla';
/* TRE MODI (1/10): la partita, il tempo di schermo, oppure i CONTATORI come su Duolingo: i
   giorni di Modalita' severa di fila, i giorni di Full Focus di fila, le monete. Di serie i
   contatori: sono i numeri che prima stavano in fondo alla Rotta. */
function hdrBolla(){ try{ return localStorage.getItem(PT_BOLLA_KEY) || 'contatori'; }catch(_){ return 'contatori'; } }
/* LE TRE BOLLE (0.9.202, Andrea): la percentuale del percorso, la serie, il carburante (la
   riserva di dopamina di oggi). Prima: serie severa, serie Full Focus, monete. */
function hdrContatori(){
  let pct = 0, serie = 0, carb = null;
  try{ pct = (typeof hdPercorso === 'function') ? hdPercorso().pct : 0; }catch(_){ }
  try{ serie = (typeof hdSerie === 'function') ? hdSerie() : 0; }catch(_){ }
  try{ carb = (typeof hdCarburante === 'function') ? hdCarburante() : null; }catch(_){ }
  return { pct: pct, serie: serie, carb: carb };
}
function hdrContatoriApply(mostra){
  let c = document.getElementById('hdrCont');
  const centro = document.querySelector('.home-head .hdr-center');
  if (!c && centro){ c = document.createElement('div'); c.id = 'hdrCont'; c.className = 'hdr-cont'; centro.appendChild(c); }
  if (!c) return;
  if (!mostra){ c.hidden = true; return; }
  const n = hdrContatori();
  const html = '<button type="button" onclick="if(typeof hdPercorsoApri===\'function\')hdPercorsoApri()" aria-label="Percorso fatto"><span>🧭</span><b>' + ((typeof hdPctTxt === 'function') ? hdPctTxt(n.pct) : Math.round(n.pct * 100)) + '%</b></button>'
    /* 0.9.278, Andrea: come su Duolingo, la fiamma e' spenta finche' oggi non hai fatto la tappa: la serie non e'
       ancora in tasca. Si accende quando la tappa e' fatta. */
    + '<button type="button" class="hd-fuoco' + (hdOggiFatto() ? '' : ' spento') + '" onclick="if(typeof hdSerieApri===\'function\')hdSerieApri()" aria-label="Giorni di fila"><span>🔥</span>' + ((n.serie > 0 && !hdOggiFatto() && new Date().getHours() >= 11) ? '<i class="hd-rischio" aria-label="La serie è a rischio">!</i>' : '') + '<b>' + n.serie + '</b></button>'
    + '<button type="button" onclick="if(typeof dpApri===\'function\')dpApri()" aria-label="Carburante di oggi"><span>⛽</span><b>' + (n.carb == null ? '–' : n.carb) + '</b></button>';
  /* 0.9.265 (lag): si ridisegna solo se i numeri cambiano. Prima si ricreavano i tre pulsanti ogni due secondi, e
     ogni volta ripartiva il controllo dei contrasti. */
  if (c._html !== html){ c._html = html; c.innerHTML = html; }
  c.hidden = false;
}
function hdrBollaSet(v){
  try{ localStorage.setItem(PT_BOLLA_KEY, v); }catch(_){ }
  hdrMatchApply();
  try{ if (typeof refreshHeaderToday === 'function') refreshHeaderToday(); }catch(_){ }
  try{ if (typeof hdrTodayApply === 'function') hdrTodayApply(); }catch(_){ }
  ptPersonalizzaPaint();
  toast(v === 'partita' ? 'In alto vedi la partita' : (v === 'contatori' ? 'In alto vedi le tue serie e le monete' : 'In alto vedi il tempo di schermo'));
}
function hdrMatchApply(){
  const b = document.getElementById('hdrMatch'); if (!b) return;
  const home = document.getElementById('s-home');
  const su = home && home.classList.contains('active');
  /* il menu ☰ solo nella scheda Profilo (0.9.202): nelle altre e' un pulsante in piu' che nessuno usa */
  try{ const db = document.getElementById('drawerBtn'), tp = document.getElementById('tab-profilo'); if (db) db.style.visibility = (tp && tp.classList.contains('on')) ? '' : 'hidden'; }catch(_){ }
  /* NIENTE BOLLA DOVE L'INTESTAZIONE HA UN TITOLO. Nel Report la bolla e la parola «Report»
     non ci stavano insieme: il titolo finiva schiacciato sotto al pulsante del menu. La
     partita si guarda dalle schede senza titolo (Rotta, Mappa, START, Profilo). */
  const tit = document.getElementById('headTitle');
  const conTitolo = !!(tit && String(tit.textContent || '').trim());
  try{ hdrContatoriApply(hdrBolla() === 'contatori' && su && !conTitolo); }catch(_){ }
  if (hdrBolla() !== 'partita' || !su || conTitolo){ b.hidden = true; return; }
  let s = null; try{ s = (typeof mtState === 'function') ? mtState() : null; }catch(_){ }
  const n = document.getElementById('hmN'), v = document.getElementById('hmV');
  if (n) n.textContent = s ? (+s.neo || 0) : 0;
  if (v) v.textContent = s ? (+s.old || 0) : 0;
  b.hidden = false;
}
/* 0.9.290, Andrea: "passando alla Mappa il punteggio non compare piu' con la stessa animazione della mappa: deve comparire
   in dissolvenza quando si passa da una scheda all'altra". La stessa salita della cartina (sevRise, 0,6 s). */
let HM_TAB = '';
function hdrMatchEntra(tab){
  const b = document.getElementById('hdrMatch'); if (!b || b.hidden) return;
  if (tab && tab === HM_TAB) return; HM_TAB = tab || '';
  b.classList.remove('hm-entra'); void b.offsetWidth; b.classList.add('hm-entra');
}
document.addEventListener('fl:tab', function(e){ setTimeout(function(){ hdrMatchApply(); hdrMatchEntra(e && e.detail); }, 20); });
document.addEventListener('fl:screen', function(){ setTimeout(hdrMatchApply, 20); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) hdrMatchApply(); });
setInterval(hdrMatchApply, 30000);
setTimeout(hdrMatchApply, 800);

/* la scelta in Personalizza: tempo di schermo o partita */
function ptPersonalizzaPaint(){
  const sc = document.getElementById('s-personalize'); if (!sc) return;
  let box = document.getElementById('psBollaBox');
  if (!box){
    box = document.createElement('div'); box.id = 'psBollaBox';
    const top = sc.querySelector('.topbar');
    if (top && top.nextSibling) top.parentNode.insertBefore(box, top.nextSibling); else sc.appendChild(box);
  }
  const cur = hdrBolla();
  box.innerHTML = '<div class="sect"><b>Intestazione</b></div>'
    + '<div class="ps-block"><b>🎯 In alto, al centro</b><p class="hintline" style="padding:4px 0 10px">La bolla della partita (Nuovo te contro Vecchio te) porta alla pagina della partita. Il tempo di schermo porta al Report.</p>'
    + '<div class="am-cats"><button type="button" class="am-cat' + (cur === 'partita' ? ' on' : '') + '" onclick="hdrBollaSet(\'partita\')">😈 Partita</button><button type="button" class="am-cat' + (cur === 'tempo' ? ' on' : '') + '" onclick="hdrBollaSet(\'tempo\')">⏱ Tempo di schermo</button><button type="button" class="am-cat' + (cur === 'contatori' ? ' on' : '') + '" onclick="hdrBollaSet(\'contatori\')">🔥 Serie e monete</button></div></div>';
}
setTimeout(ptPersonalizzaPaint, 1500);
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-personalize') ptPersonalizzaPaint(); });

/* ---------------------------------------------------------------- i pedaggi della schermata «Uscita di rotta»

   Per ogni app che distrae: i minuti al giorno degli ultimi 14 giorni, divisi per i minuti al
   giorno del piano dell'ETA, per sette. E' «un'altra settimana cosi' quanto ti allontana
   dall'arrivo». Nessun numero a caso: se non c'e' un piano o non ci sono dati, niente pedaggio
   e la schermata torna alla Base. */
/* ---------- IL COSTO DI RIENTRO (0.9.297) ----------
   Andrea: "cinque minuti su Chrome non spostano di un giorno, e la sera, fuori dalle ore di lavoro, non spostano
   affatto". Un'interruzione durante il lavoro costa il tempo fuori, piu' il tempo per tornare concentrati
   (resumption lag) e la qualita' piu' bassa dopo il rientro (attention residue). Qui la versione di partenza:
   lag 10 minuti e qualita' al 70% per tutti, finche' il motore dell'arrivo non la misura per ogni persona (sostituisce
   questa funzione con lo stesso nome e la stessa firma). Fuori dalle ore del piano il costo e' zero. */
const PT_RIENTRO = { lagMin: 10, residuo: 0.7, finestraMin: 15 };
function etaCostoRientroOrario(t){
  const d = new Date(t || Date.now());
  let giorni = null, da = 8, a = 22;
  try{ const p = etaPiano(); giorni = p.giorni || null; }catch(_){ }
  try{ if (typeof ETA_CFG !== 'undefined' && ETA_CFG.finestraGiorno){ da = ETA_CFG.finestraGiorno.da; a = ETA_CFG.finestraGiorno.a; } }catch(_){ }
  const lavora = !giorni || !!giorni[d.getDay()];
  const h = d.getHours() + d.getMinutes() / 60;
  return lavora && h >= da && h < a;
}
if (typeof window.etaCostoRientro !== 'function'){
  window.etaCostoRientro = function(pkg, minutiSessione){
    const inOrario = etaCostoRientroOrario();
    const sess = Math.max(1, +minutiSessione || 5);
    if (!inOrario) return { minuti: 0, lagMin: PT_RIENTRO.lagMin, misurato: false, inOrario: false };
    const minuti = sess + PT_RIENTRO.lagMin + PT_RIENTRO.finestraMin * (1 - PT_RIENTRO.residuo);
    return { minuti: Math.round(minuti), lagMin: PT_RIENTRO.lagMin, misurato: false, inOrario: true };
  };
}

async function ptPedaggiSync(forza){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps || !NATIVE.setSettings) return;
    const last = +localStorage.getItem('fl_pedaggi_at') || 0;
    /* la forma dei pedaggi e' cambiata (0.9.172: ore oltre ai giorni): si riscrive una volta */
    let ver = ''; try{ ver = localStorage.getItem('fl_pedaggi_v') || ''; }catch(_){ }
    if (!forza && ver === '3' && Date.now() - last < 6 * 3600000){ await ptRottaStella(); return; }
    let pianoMin = 0;
    try{ const p = etaPiano(); pianoMin = Math.round((+p.oreSettimana || 0) * 60 / 7); }catch(_){ }
    if (pianoMin < 15) pianoMin = 60;
    let arrivo = 0; try{ const a = etaArrivo(); arrivo = a && isFinite(a.at) ? a.at : 0; }catch(_){ }
    const to = Date.now(), from = to - 14 * 86400000;
    const t = await NATIVE.getTopApps({ from: from, to: to, limit: 40, by: 'ms', icons: 0 });
    const apps = (t && t.apps) || [];
    const out = {};
    let somma = 0, n = 0;
    /* PERCHE' DICEVA SEMPRE «+1 GIORNO». Il costo si arrotondava ai giorni con un pavimento
       a uno: con un piano da quattro ore al giorno, venti minuti di WhatsApp valgono 0,6
       giorni, e 0,6 con il pavimento a uno fa uno — per WhatsApp, per Instagram, per tutto.
       Adesso il costo si tiene in ore (h) e in giorni (g): sotto al giorno la schermata dice
       «+14 ore», e per le app che non conosce non inventa una media. */
    apps.forEach(function(a){
      if (!a || a.self) return;
      let distrae = true; try{ distrae = (typeof scIsDistracting === 'function') ? scIsDistracting(a.packageName) : true; }catch(_){ }
      if (!distrae) return;
      const dayMin = (a.ms || 0) / 60000 / 14;
      if (dayMin < 3) return;
      const giorniF = dayMin * 7 / pianoMin;
      /* 0.9.297: la durata media di un'apertura (minuti), per il costo di rientro della schermata "fuori rotta" */
      const sess = (a.launches > 0) ? Math.max(1, Math.min(60, Math.round((a.ms || 0) / a.launches / 60000))) : 5;
      /* 0.9.298: il carburante che costa un'apertura media (lo stesso motore della riserva: sotto i 10 minuti e' uso
         leggero, da 10 a 60 minuti e' un picco col suo debito) */
      let cfgD = null; try{ cfgD = (typeof DM_CFG !== 'undefined') ? DM_CFG : null; }catch(_){ }
      const dmin = (cfgD && cfgD.altoMinMin) || 10, deb = (cfgD && cfgD.debito) || [3, 8], per = (cfgD && cfgD.piccoMinPer) || [10, 60];
      const fuelC = sess < dmin ? Math.max(0.2, Math.round(sess * ((cfgD && cfgD.costoMedioMin) || 0.06) * 8 * 10) / 10)
        : Math.round((deb[0] + (deb[1] - deb[0]) * Math.max(0, Math.min(1, (sess - per[0]) / (per[1] - per[0])))) * 10) / 10;
      out[a.packageName] = { g: Math.round(giorniF), h: Math.max(1, Math.round(giorniF * 24)), m: Math.round(dayMin), s: sess, c: fuelC };
      somma += giorniF; n++;
    });
    /* 0.9.324: gli ultimi sette giorni, app per app, per la slide "Le tue ultime scelte" della schermata raccontata. Mai un numero inventato: senza dati la slide non c'e' */
    try{
      const giornoZero = new Date(); giornoZero.setHours(0, 0, 0, 0);
      for (let i = 6; i >= 0; i--){
        const a0 = giornoZero.getTime() - i * 86400000, a1 = i === 0 ? Date.now() : a0 + 86400000;
        const r7 = await NATIVE.getTopApps({ from: a0, to: a1, limit: 40, by: 'ms', icons: 0 });
        const m7 = {}; ((r7 && r7.apps) || []).forEach(function(x){ if (x && x.packageName) m7[x.packageName] = Math.round((x.ms || 0) / 60000); });
        Object.keys(out).forEach(function(p){ (out[p].d7 = out[p].d7 || []).push(m7[p] || 0); });
      }
    }catch(_){ }
    /* 0.9.297: quello che serve alla schermata "fuori rotta" per ricalcolare da sola, nel momento del blocco:
       la percentuale del percorso, i giorni di lavoro, la finestra del giorno e il costo di rientro */
    /* 0.9.299, Andrea: "dice 0% del percorso, quando l'app mostra un'altra percentuale". La percentuale e' quella
       dell'intestazione (hdPercorso), non quella del calcolo dell'arrivo */
    const pct = ptPctPercorso();
    let giorniL = [1, 1, 1, 1, 1, 1, 1]; try{ const pp = etaPiano(); if (Array.isArray(pp.giorni)) giorniL = pp.giorni.map(function(x){ return x ? 1 : 0; }); }catch(_){ }
    let da = 8, aOra = 22; try{ if (ETA_CFG.finestraGiorno){ da = ETA_CFG.finestraGiorno.da; aOra = ETA_CFG.finestraGiorno.a; } }catch(_){ }
    let rc = { lagMin: PT_RIENTRO.lagMin, misurato: false }, residuo = PT_RIENTRO.residuo;
    try{ const x = window.etaCostoRientro('*', 5); if (x){ rc = x; if (x.inOrario && x.minuti > 0) residuo = Math.max(0.5, Math.min(1, 1 - (x.minuti - 5 - x.lagMin) / PT_RIENTRO.finestraMin)); } }catch(_){ }
    out['*'] = { g: n ? Math.round(somma / n) : 0, h: n ? Math.max(1, Math.round(somma / n * 24)) : 0, m: 0, arrivo: arrivo, piano: pianoMin,
                 pct: pct, giorni: giorniL, da: da, a: aOra, lag: rc.lagMin || PT_RIENTRO.lagMin, res: residuo, mis: !!rc.misurato };
    /* 0.9.298: la combo di aperture riparte dopo una sessione o una task chiusa (reset); il carburante di adesso (L);
       chi stai diventando (id, dal livello dell'Io Futuro) */
    try{ out['*'].reset = +localStorage.getItem('fl_rotta_reset') || 0; }catch(_){ }
    try{ if (typeof DP !== 'undefined' && DP && typeof DP.L === 'number') out['*'].L = Math.round(DP.L); }catch(_){ }
    try{ const io = (typeof ifNuovoMe === 'function') ? (ifNuovoMe().identita || null) : null; if (io && io.identity_statement) out['*'].id = String(io.identity_statement).slice(0, 160); }catch(_){ }
    ptStellaViva(out['*']);
    await ptCopertinaSync();
    await NATIVE.setSettings({ lockRotta: JSON.stringify(out) });
    try{ localStorage.setItem('fl_pedaggi_at', String(Date.now())); localStorage.setItem('fl_pedaggi_v', '3'); localStorage.setItem('fl_pedaggi', JSON.stringify(out)); }catch(_){ }
  }catch(_){ }
}
/* 0.9.299: la percentuale come nell'intestazione (con o senza decimali, come l'ha scelta l'utente) */
function ptPctPercorso(){
  try{ if (typeof hdPercorso === 'function'){ const h = hdPercorso(); if (h && isFinite(h.pct)) return h.pct; } }catch(_){ }
  try{ const aa = etaArrivo(); return aa && isFinite(aa.pct) ? aa.pct : 0; }catch(_){ return 0; }
}
/* i pezzi della stella che cambiano durante il giorno: percentuale, arrivo, carburante, copertina */
/* la schermata raccontata si sblocca nella storia: con l'episodio del collo di bottiglia (il 6) */
const PT_STORIA_EP = 6;
function ptStoriaSbloccata(){ try{ if (typeof flAdmin === 'function' && flAdmin()) return true; return !!(typeof epiStato === 'function' && epiStato().visti[PT_STORIA_EP]); }catch(_){ return false; } }
function ptStellaViva(st){
  st.pct = ptPctPercorso();
  st.storia = ptStoriaSbloccata();
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); st.frase = String((u && u.bio) || '').slice(0, 120); }catch(_){ st.frase = ''; }
  try{ st.dec = (typeof serOpzioni === 'function') && serOpzioni().pctDec === true; }catch(_){ st.dec = false; }
  try{ const a = etaArrivo(); if (a && isFinite(a.at)) st.arrivo = a.at; }catch(_){ }
  try{ if (typeof DP !== 'undefined' && DP && typeof DP.L === 'number') st.L = Math.round(DP.L); }catch(_){ }
  try{ st.reset = +localStorage.getItem('fl_rotta_reset') || 0; }catch(_){ }
  st.cover = ptCopertina().k;
  /* 0.9.308: i minuti del piano in un giorno di lavoro, quelli con cui il navigatore chiude la giornata (eta.js): sono la
     "strada di un giorno" del prezzo. "piano" (la media su sette giorni) resta per chi ha la schermata di prima. */
  try{ const p = etaPiano(); if (p && p.nGiorni > 0) st.pianoG = Math.round(p.oreSettimana * 60 / p.nGiorni); }catch(_){ }
  /* il bollino di Dream, lo stesso testo e colore (eta.js, etaSpostamento): la schermata lo mostra solo il giorno k */
  try{
    const sp = (typeof etaSpostamento === 'function') ? etaSpostamento() : null;
    st.boll = sp ? { k: etaOggiK(), g: sp.giorni || 0, txt: etaSpostamentoTxt(sp) } : null;
  }catch(_){ st.boll = null; }
  /* quanto hanno gia' preso oggi (e nei prossimi giorni) le app aperte comunque: il tetto di un giorno */
  try{ st.rottaG = (typeof etaRottaGiorni === 'function') ? etaRottaGiorni() : {}; }catch(_){ st.rottaG = {}; }
  return st;
}
/* LA COPERTINA DELLA SLIDE "ARRIVO PREVISTO" (0.9.299). Andrea: "non sta venendo mostrata la stessa immagine che
   l'utente ha scelto nella slide di arrivo previsto della scheda Sogno". La schermata nativa la riceve cosi':
   un'immagine dell'app ("asset:img/..."), un gradiente ("grad:#a,#b") o la foto dell'utente, salvata una volta
   in un file del telefono ("file") */
function ptCopertina(){
  let c = ''; try{ c = (typeof cstCfg === 'function') ? (cstCfg().cover || '') : ''; }catch(_){ }
  if (c === 'mia'){ let d = ''; try{ d = localStorage.getItem('fl_mappa_cover_img') || ''; }catch(_){ } return d ? { k: 'file', d: d } : { k: 'asset:img/dream-night.jpg' }; }
  if (c.indexOf('grad:') === 0) return { k: c };
  if (c && !/^(https?:|data:)/.test(c)) return { k: 'asset:' + c.replace(/^\.?\//, '') };
  return { k: 'asset:img/dream-night.jpg' };
}
async function ptCopertinaSync(){
  const cp = ptCopertina();
  if (cp.k !== 'file' || !cp.d) return;
  const firma = cp.d.length + ':' + cp.d.slice(-40);
  let prima = ''; try{ prima = localStorage.getItem('fl_rotta_cover_firma') || ''; }catch(_){ }
  if (prima === firma) return;
  try{ await NATIVE.setSettings({ rottaCover: cp.d }); localStorage.setItem('fl_rotta_cover_firma', firma); }catch(_){ }
}
/* fra un ricalcolo pesante e l'altro (ogni 6 ore) si aggiornano solo i pezzi vivi, senza rileggere le app */
async function ptRottaStella(){
  try{
    let out = null; try{ out = JSON.parse(localStorage.getItem('fl_pedaggi') || 'null'); }catch(_){ }
    if (!out || !out['*']) return;
    const prima = JSON.stringify(out['*']);
    ptStellaViva(out['*']);
    await ptCopertinaSync();
    if (JSON.stringify(out['*']) === prima) return;
    await NATIVE.setSettings({ lockRotta: JSON.stringify(out) });
    try{ localStorage.setItem('fl_pedaggi', JSON.stringify(out)); }catch(_){ }
  }catch(_){ }
}
setTimeout(function(){ ptPedaggiSync(false); }, 9000);
document.addEventListener('fl:tab', function(){ setTimeout(function(){ ptPedaggiSync(false); }, 1500); });
/* 0.9.308: quando DreamMap va in secondo piano la schermata fuori rotta riceve subito il bollino e la data di adesso:
   e' proprio allora che l'utente apre le altre app */
document.addEventListener('visibilitychange', function(){ if (!document.hidden) ptPedaggiSync(false); else ptRottaStella(); });
/* cambia il piano, cambia il prezzo: si ricalcola subito */
document.addEventListener('fl:piano', function(){ setTimeout(function(){ ptPedaggiSync(true); }, 2000); });

(function(){
  const css = [
    /* A TUTTA LARGHEZZA come nella scheda: la pagina non ha margini laterali, li ha il suo
       contenuto (gli stessi 18px della scheda), e il cielo li scavalca con --bleed. */
    '#s-blocco,#s-visualization{padding-left:0;padding-right:0}',
    '#s-blocco > .topbar,#s-visualization > .topbar{padding-left:22px;padding-right:22px}',
    '#blHost .tabpage{display:block !important;overflow:visible;height:auto;flex:none;padding:0 18px 12px;margin-top:0 !important}',
    '#vzHost{padding:0 18px}',
    '#blHost .tabpage.hero-top{margin-top:0 !important}',
    '.pt-porte{display:flex;flex-direction:column;gap:12px;margin:16px 0 20px}',
    '.hdr-cont{display:flex;align-items:center;gap:12px;pointer-events:auto}.hdr-cont[hidden]{display:none}',
    '.hdr-cont button{display:flex;align-items:center;gap:4px;border:0;border-radius:99px;background:rgba(2,9,38,.42);color:#fff;padding:7px 11px;font:800 13px var(--font-body);cursor:pointer;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}',
    '.hdr-cont button span{font-size:14px;line-height:1}',
    '.bl-severa-fondo{margin:30px 18px 24px}.bl-sev-t{text-align:center;margin-bottom:22px}.bl-sev-t span{display:block;font-size:52px;line-height:1.15;margin:0 0 14px}.bl-sev-t h2{margin:0 0 12px;font:800 24px/1.2 var(--font-display);font-style:italic;color:var(--navy)}body.dark .bl-sev-t h2{color:#fff}.bl-sev-t p{margin:0 auto 6px;max-width:30ch;font:500 13.5px/1.55 var(--font-body);color:var(--muted)}',
    '.bl-pillole{background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:22px 18px;text-align:center;margin-bottom:4px}body.dark .bl-pillole{background:#12203A;border-color:#22345A}',
    '.bl-pillole-art{display:flex;justify-content:center;gap:26px;margin-bottom:14px}.bl-pillole-art i{width:30px;height:74px;border-radius:15px;box-shadow:0 10px 24px rgba(0,0,0,.25);background:linear-gradient(180deg,rgba(255,255,255,.55),rgba(255,255,255,0) 45%,rgba(0,0,0,.18))}',
    '.bl-pillole-art .rossa{background-color:#E63946}.bl-pillole-art .blu{background-color:#0075E3}',
    '.bl-pillole b{display:block;font:800 22px/1.2 var(--font-display);font-style:italic;color:var(--navy);letter-spacing:.02em}body.dark .bl-pillole b{color:#fff}',
    '.bl-pillole p{margin:12px auto 0;max-width:32ch;font:500 13.5px/1.6 var(--font-body);color:var(--muted);text-align:left}',
    '.bl-due{display:flex;gap:10px;margin-top:16px}.bl-pil-card{flex:1;background:var(--bg,#F4F9FF);border-radius:18px;padding:16px 12px;text-align:center}body.dark .bl-pil-card{background:rgba(255,255,255,.05)}',
    '.bl-pil-card .pillola{display:block;width:30px;height:74px;margin:0 auto 12px;border-radius:15px;box-shadow:0 10px 24px rgba(0,0,0,.25);background-image:linear-gradient(180deg,rgba(255,255,255,.55),rgba(255,255,255,0) 45%,rgba(0,0,0,.18))}.bl-pil-card .pillola.rossa{background-color:#E63946}.bl-pil-card .pillola.blu{background-color:#0075E3}',
    '.bl-pil-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--navy)}body.dark .bl-pil-card small{color:#fff}.bl-pil-card p{margin:6px 0 0;max-width:none;text-align:center;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    '.pt-card{display:flex;align-items:center;gap:12px;width:100%;text-align:left;background:var(--card,#fff);border:1px solid var(--line);border-radius:20px;padding:16px;cursor:pointer;color:var(--navy)}',
    'body.dark .pt-card{background:#12203A;border-color:#22345A;color:#fff}',
    '.pt-card > div{flex:1;min-width:0}.pt-card b{display:block;font:700 15px var(--font-display);color:inherit}.pt-card small{display:block;margin-top:2px;font:500 12px/1.4 var(--font-body);color:var(--muted)}',
    '.pt-card.nera{background:#000D1F;border-color:#000D1F;color:#fff}.pt-card.nera small{color:rgba(255,255,255,.7)}',
    '.pt-ico{width:44px;height:44px;border-radius:22px;background:var(--blue-soft,#E3F1FF);display:flex;align-items:center;justify-content:center;font-size:22px;flex:none}body.dark .pt-ico{background:#0F2A4A}',
    '.pt-sev-grande{position:relative;display:flex;flex-direction:column;align-items:center;gap:8px;width:100%;margin:6px 0 4px;padding:26px 20px 24px;border:0;border-radius:24px;background:linear-gradient(165deg,#0B3470,#001E44 60%,#00132B);color:#fff;text-align:center;cursor:pointer;box-shadow:0 12px 30px rgba(0,30,68,.22)}'
      + '.pt-sev-grande b{font:800 20px var(--font-display);color:#fff}.pt-sev-grande small{max-width:280px;font:500 14px/1.45 var(--font-body);color:#BFD3EC}.pt-sev-grande > svg{position:absolute;right:18px;top:50%;margin-top:-9px;color:#8CC6FF}'
      + '.pt-sev-pill{display:flex;gap:10px;justify-content:center;margin-bottom:6px}.pt-sev-pill .fa-pill{width:26px;height:62px;border-radius:13px}body.dark .pt-sev-grande{box-shadow:0 0 0 1px rgba(140,198,255,.18)}.svp-pillola{margin:0 0 14px}',
    '.pt-pillole{display:flex;gap:4px;flex:none}.pt-pillole i{width:14px;height:34px;border-radius:7px}.pt-pillole .rossa{background:#E63946}.pt-pillole .blu{background:#0075E3}',
    '.pt-chev{font-style:normal;font-size:22px;color:var(--faint);flex:none}.pt-card.nera .pt-chev{color:rgba(255,255,255,.6)}',
    '.pt-due{display:grid;grid-template-columns:1fr 1fr;gap:12px}','.pt-largo{width:100%}',
    '.pt-mini{background:var(--card,#fff);border:1px solid var(--line);border-radius:20px;padding:16px 10px;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer}',
    'body.dark .pt-mini{background:#12203A;border-color:#22345A}',
    '.pt-mini span{font-size:24px;line-height:1}.pt-mini b{font:700 13px/1.3 var(--font-display);color:var(--navy);text-align:center}body.dark .pt-mini b{color:#fff}',
    /* la bolla della partita */
    '.hdr-center{position:relative}',
    '.home-head .hdr-match,.home-head.glass .hdr-match{pointer-events:auto}',
    '.hdr-match{display:inline-flex;align-items:center;gap:6px;border:1px solid rgba(255,255,255,.14);background:rgba(0,19,43,.86);backdrop-filter:blur(10px);border-radius:999px;padding:6px 14px;font:700 11px var(--font-display);color:#fff;letter-spacing:.04em;white-space:nowrap;cursor:pointer}',
    '.hdr-match .hm-l{color:#8CC6FF}.hdr-match .hm-l.v{color:rgba(255,255,255,.6)}.hdr-match b{font:800 14px var(--font-display);color:#fff}.hdr-match b.v{color:rgba(255,255,255,.75)}.hdr-match i{opacity:.4;font-style:normal}',
    '.hdr-match[hidden]{display:none}',
    '.hdr-match.hm-entra{animation:hmEntra .6s ease-out .1s both}@keyframes hmEntra{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = '.pt-scegli{width:100%;text-align:left;cursor:pointer}.pt-scegli>div{flex:1;min-width:0}.pt-scegli small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}.pt-scegli>svg{flex:none;color:var(--muted)}';
  document.head.appendChild(st);
})();
