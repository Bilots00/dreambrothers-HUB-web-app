/* ===========================================================================================
   LE SESSIONI PRONTE — due file di card in fondo alla scheda START

   Aprire FullFocus e decidere ogni volta tag, minuti, suono e cosa resta acceso è la ragione
   per cui una sessione non parte: cinque scelte prima di cominciare sono cinque occasioni per
   rimandare. Una card con sopra scritto «Studio profondo · 1h 30m» e un pulsante è una scelta
   sola, e si fa in un secondo.

   DUE FILE, PERCHÉ SONO DUE COSE DIVERSE:

     · PER TE — sessioni di concentrazione, da mezz'ora a tre ore. Sono FullFocus con i campi
       già compilati: partono adesso, finiscono da sole, e la pianta cresce.
     · DOPAMINE DETOX — i digiuni lunghi, da un giorno a una settimana. Non possono essere una
       sessione di FullFocus (che si ferma a tre ore, ed è giusto così: nessuno resta a fissare
       un timer per due giorni). Sono un PROGRAMMA che blocca le distrazioni per N giorni e si
       toglie da solo alla scadenza.

   IL «TIENI PREMUTO PER INIZIARE» non è un vezzo. Un digiuno di cinque giorni che parte con un
   tocco distratto è un disastro; mezzo secondo di pressione è la differenza fra un gesto e una
   decisione, ed è lo stesso motivo per cui certe cose, nella vita vera, si firmano.

   LE IMMAGINI SONO DISEGNATE QUI, non file. Sfumature e forme in CSS: restano nitide su
   qualsiasi schermo, pesano zero e non invecchiano male come una foto stock.
   =========================================================================================== */

const PR_KEY = 'fl_presets';        // i preset scritti dall'utente
const PR_DETOX_KEY = 'fl_detox';    // il digiuno in corso: { id, fino, nome }
/* I tre registri che rendono queste card ROBA DELL'UTENTE e non un menu nostro.
   Stanno separati dalle card apposta: le card di serie sono costanti di questo file e un
   aggiornamento dell'app le riscrive: se la durata scelta o l'ordine vivessero li' dentro,
   ogni versione nuova cancellerebbe le preferenze di chi la installa. */
const PR_ORD_KEY = 'fl_pr_ordine';  // { perte: [id...], detox: [id...] }
const PR_NAS_KEY = 'fl_pr_nascosti';// [id...] — quelle di serie messe via, recuperabili
const PR_DUR_KEY = 'fl_pr_durata';  // LASCITO: { id: minuti-o-giorni }, solo la durata
const PR_MOD_KEY = 'fl_pr_mod';     // { id: { dur, nome, tag, intent, ico, sfondo } }

/* Le facce e i fondi fra cui si sceglie. Disegnati, non fotografati: restano nitidi su
   qualsiasi schermo, pesano zero, e non invecchiano male come una foto stock. */
const PR_EMOJI = ['\uD83D\uDCDA', '\uD83D\uDEE0\uFE0F', '\uD83C\uDFC3', '\uD83D\uDCD6', '\uD83D\uDE97', '\uD83C\uDFAF', '\u270D\uFE0F', '\uD83E\uDDD8',
                 '\uD83D\uDCBB', '\uD83C\uDFB8', '\uD83C\uDFA8', '\uD83C\uDF31', '\uD83C\uDF19', '\u2600\uFE0F', '\uD83D\uDD25', '\u26A1',
                 '\uD83E\uDDE0', '\uD83D\uDC8E', '\uD83C\uDFDD\uFE0F', '\uD83D\uDE80'];

const PR_SFONDI = [
  ['Notte',    'linear-gradient(160deg,#14234A,#005BB0 45%,#001E44)'],
  ['Tramonto', 'linear-gradient(160deg,#C2410C,#EA580C 40%,#0F2041)'],
  ['Oceano',   'linear-gradient(160deg,#0369A1,#22D3EE 45%,#1E293B)'],
  ['Aurora',   'linear-gradient(160deg,#0E2350,#E71D4F 50%,#0F2041)'],
  ['Bosco',    'linear-gradient(160deg,#065F46,#10B981 45%,#052E2B)'],
  ['Alba',     'linear-gradient(160deg,#93C5FD,#FDE68A 45%,#166534)'],
  ['Cielo',    'linear-gradient(160deg,#7DD3FC,#38BDF8 40%,#065F46)'],
  ['Lavanda',  'linear-gradient(160deg,#818CF8,#A5B4FC 35%,#1E3A8A)'],
  ['Notte',  'linear-gradient(160deg,#0075E3,#001E44)'],
  ['Brace',    'linear-gradient(160deg,#7F1D1D,#E63946 45%,#1A0A0D)']
];

function prLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function prScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }

function prOrdine(){ const v = prLeggi(PR_ORD_KEY, {}); return { perte: v.perte || [], detox: v.detox || [] }; }
function prNascosti(){ const v = prLeggi(PR_NAS_KEY, []); return Array.isArray(v) ? v : []; }
/**
 * Le modifiche dell'utente alle card.
 *
 * <p>Fuori dalle card, e non per pignoleria: le card di serie sono costanti di questo file e
 * ogni versione nuova dell'app le riscrive. Tenerci dentro una scelta dell'utente vorrebbe
 * dire cancellargliela a ogni aggiornamento.</p>
 */
function prModifiche(){
  let v = prLeggi(PR_MOD_KEY, null);
  if (v && typeof v === 'object') return v;
  /* LASCITO. Fino alla 0.9.107 esisteva solo la durata, in una chiave sua e col valore nudo.
     La si porta dentro una volta: nessuno deve riscegliere una cosa che aveva gia' scelto. */
  v = {};
  const vecchie = prLeggi(PR_DUR_KEY, {});
  Object.keys(vecchie || {}).forEach(function(k){
    if (typeof vecchie[k] === 'number') v[k] = { dur: vecchie[k] };
  });
  prScrivi(PR_MOD_KEY, v);
  return v;
}

function prSetMod(id, patch){
  const m = prModifiche();
  m[id] = Object.assign(m[id] || {}, patch || {});
  prScrivi(PR_MOD_KEY, m);
}

/* ---------------------------------------------------------------------------------------
   Quelli di serie
   --------------------------------------------------------------------------------------- */

const PR_PER_TE = [
  { id: 'studio',   nome: 'Studio profondo', min: 90,  tag: 'studio', sfondo: 'linear-gradient(160deg,#14234A,#005BB0 45%,#001E44)', ico: '📚' },
  { id: 'commute',  nome: 'Tragitto',        min: 30,  tag: 'altro',  sfondo: 'linear-gradient(160deg,#C2410C,#EA580C 40%,#0F2041)', ico: '🚗' },
  { id: 'workout',  nome: 'Allenamento',     min: 60,  tag: 'sport',  sfondo: 'linear-gradient(160deg,#0369A1,#22D3EE 45%,#1E293B)', ico: '🏃' },
  { id: 'lettura',  nome: 'Lettura',         min: 30,  tag: 'riposo', sfondo: 'linear-gradient(160deg,#0E2350,#E71D4F 50%,#0F2041)', ico: '📖' },
  { id: 'lavoro',   nome: 'Blocco di lavoro', min: 120, tag: 'lavoro', sfondo: 'linear-gradient(160deg,#065F46,#10B981 45%,#052E2B)', ico: '🛠️' }
];

const PR_DETOX = [
  { id: 'quieto',   nome: 'Giorno quieto',   giorni: 1, sotto: 'Niente app che distraggono', sfondo: 'linear-gradient(160deg,#7DD3FC,#38BDF8 40%,#065F46)', ico: '🌾' },
  { id: 'sabbath',  nome: 'Sabato digitale', giorni: 2, sotto: 'Niente social',              sfondo: 'linear-gradient(160deg,#818CF8,#A5B4FC 35%,#1E3A8A)', ico: '🪑' },
  { id: 'ritiro',   nome: 'Il ritiro',       giorni: 5, sotto: 'Niente di tutto questo',     sfondo: 'linear-gradient(160deg,#93C5FD,#FDE68A 45%,#166534)', ico: '🏝️' }
];

/* ---------------------------------------------------------------------------------------
   Quelli scritti dall'utente
   --------------------------------------------------------------------------------------- */

function prMiei(){
  try{ return JSON.parse(localStorage.getItem(PR_KEY) || '[]') || []; }catch(_){ return []; }
}
function prSalva(list){
  try{ localStorage.setItem(PR_KEY, JSON.stringify(list || [])); }catch(_){ }
}

/* Una COPIA, sempre, con sopra le modifiche dell'utente.
   La copia non e' pignoleria: le card di serie sono costanti condivise, e chi ricevesse
   l'originale potrebbe modificarle per tutta la sessione senza accorgersene. */
function prConMod(p){
  if (!p) return null;
  const q = Object.assign({}, p);
  const m = prModifiche()[q.id];
  if (!m) return q;
  if (typeof m.dur === 'number' && m.dur > 0){ if (q.giorni) q.giorni = m.dur; else q.min = m.dur; }
  if (m.nome) q.nome = m.nome;
  if (m.tag) q.tag = m.tag;
  if (m.intent !== undefined) q.intent = m.intent;
  if (m.ico) q.ico = m.ico;
  /* Scegliere un colore toglie la fotografia: un fondo colorato sotto a un'immagine non si
     vede, e lasciarli tutti e due vorrebbe dire far scegliere una cosa senza effetto. */
  if (m.sfondo){ q.sfondo = m.sfondo; q.img = ''; }
  if (m.img){ q.img = m.img; }
  return q;
}
/* Il vecchio nome resta come porta: qualcuno potrebbe chiamarla ancora. */
function prConDurata(p){ return prConMod(p); }

/**
 * L'obiettivo con cui parte la sessione.
 *
 * <p>Di serie e' il NOME della card. Sembra ovvio e invece era il difetto peggiore di questa
 * sezione: senza, FullFocus si apriva tenendosi l'obiettivo di prima — quello scritto nel
 * foglio della pianificazione — e chi aveva appena scelto «Lettura» si trovava davanti
 * tutt'altra cosa.</p>
 */
function prObiettivo(p){
  const scritto = (p && p.intent !== undefined && p.intent !== null) ? String(p.intent).trim() : '';
  return scritto || (p ? String(p.nome || '').trim() : '');
}

function prTrova(id){
  const p = prMiei().filter(function(x){ return x.id === id; })[0]
    || PR_PER_TE.filter(function(x){ return x.id === id; })[0]
    || PR_DETOX.filter(function(x){ return x.id === id; })[0]
    || null;
  return prConMod(p);
}

/**
 * Le card di una fila, nell'ordine scelto e senza quelle messe via.
 *
 * <p>Chi non compare nell'ordine salvato va in fondo: e' il caso di una card appena creata e
 * di una card di serie aggiunta da un aggiornamento. In fondo e' il posto giusto per
 * entrambe — chi la vuole davanti ce la porta col dito, e l'ordine di prima non si sposta
 * sotto agli occhi di nessuno.</p>
 */
function prLista(detox){
  const miei = prMiei().filter(function(x){ return detox ? !!x.giorni : !x.giorni; });
  const nascosti = prNascosti();
  const tutte = (detox ? PR_DETOX : PR_PER_TE).concat(miei)
    .filter(function(p){ return nascosti.indexOf(p.id) < 0; });
  const ord = prOrdine()[detox ? 'detox' : 'perte'];
  tutte.sort(function(a, b){
    const ia = ord.indexOf(a.id), ib = ord.indexOf(b.id);
    if (ia < 0 && ib < 0) return 0;
    if (ia < 0) return 1;
    if (ib < 0) return -1;
    return ia - ib;
  });
  return tutte.map(prConMod);
}

function prDurata(p){
  if (p.giorni) return p.giorni === 1 ? '1 giorno' : p.giorni + ' giorni';
  const h = Math.floor(p.min / 60), m = p.min % 60;
  return h ? (h + 'h' + (m ? ' ' + m + 'm' : '')) : (p.min + 'm');
}

/* ---------------------------------------------------------------------------------------
   Le card
   --------------------------------------------------------------------------------------- */

function prCardHtml(p, detox){
  const sfondo = p.img
    ? 'background-image:url(' + String(p.img).replace(/[()"]/g, '') + ');background-size:cover;background-position:center'
    : 'background:' + prSfondo(p.sfondo);
  return '<button type="button" class="pr-card" data-id="' + p.id + '" style="' + sfondo + '" onclick="prApri(\'' + p.id + '\')">'
    + (p.img ? '' : '<span class="pr-art">' + (p.ico || '🎯') + '</span>')
    + '<span class="pr-veil"></span>'
    + '<span class="pr-txt">'
    +   '<b>' + esc(p.nome) + '</b>'
    +   (detox && p.sotto ? '<i>' + esc(p.sotto) + '</i>' : '')
    +   '<span class="pr-go">▶ ' + esc(prDurata(p)) + '</span>'
    + '</span>'
    + '<span class="pr-x" onclick="prButta(event, \'' + p.id + '\')">✕</span>'
    + '<span class="pr-mov">'
    +   '<i onclick="prSposta(event,\'' + p.id + '\',' + (detox ? 'true' : 'false') + ',-1)">‹</i>'
    +   '<i onclick="prSposta(event,\'' + p.id + '\',' + (detox ? 'true' : 'false') + ',1)">›</i>'
    + '</span>'
    + '</button>';
}

function prPiuHtml(detox){
  return '<button type="button" class="pr-card pr-piu" onclick="prNuovo(' + (detox ? 'true' : 'false') + ')">'
    + '<span class="pr-piu-ic">+</span>'
    + '<span class="pr-piu-t">' + (detox ? 'Il tuo digiuno' : 'La tua sessione') + '</span>'
    + '<span class="pr-piu-s">Durata, immagine e cosa resta acceso</span></button>';
}

function prPaint(){
  const host = document.getElementById('prHost');
  if (!host) return;
  /* LO SCORRIMENTO DELLE FILE SI CONSERVA.
     Qui sotto si riscrive tutto l'HTML, e una fila riscritta nasce con lo scorrimento a zero:
     tenendo premuto sull'ultima card, la modalita' riordino si accendeva e la fila saltava
     all'inizio — il dito fermo, la card scappata via da sotto. */
  const dove = {};
  host.querySelectorAll('.pr-row').forEach(function(r){ dove[r.dataset.riga] = r.scrollLeft; });
  const perTe = prLista(false);
  const detox = prLista(true);
  const corso = prDetoxCorso();
  host.classList.toggle('pr-riordina', PR_MODO);

  host.innerHTML = prBarraHtml()
    + '<div class="pr-sect"><div class="pr-sect-t"><b>Per te</b>' + prRiordinaBtn() + '</div>'
    +   '<small>Una sessione già pronta: parte adesso.</small></div>'
    + '<div class="pr-row fl-fade-x" data-riga="perte">' + perTe.map(function(p){ return prCardHtml(p, false); }).join('') + prPiuHtml(false) + '</div>'
    + '<div class="pr-sect"><div class="pr-sect-t"><b>Dopamine Detox</b>' + prRiordinaBtn() + '</div>'
    +   '<small>Un digiuno più lungo, da un giorno in su.</small></div>'
    + (corso
        ? '<div class="pr-corso"><div><b>' + esc(corso.nome) + '</b>'
          + '<small>Finisce ' + prQuando(corso.fino) + '</small></div>'
          + '<button type="button" onclick="prDetoxStop()">Interrompi</button></div>'
        : '')
    + '<div class="pr-row fl-fade-x" data-riga="detox">' + detox.map(function(p){ return prCardHtml(p, true); }).join('') + prPiuHtml(true) + '</div>';

  host.querySelectorAll('.pr-row').forEach(function(r){
    const x = dove[r.dataset.riga];
    if (x) r.scrollLeft = x;
  });
}

function prQuando(ts){
  const d = new Date(ts);
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const gg = Math.round((new Date(ts).setHours(0, 0, 0, 0) - oggi.getTime()) / 86400000);
  const ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  if (gg <= 0) return 'oggi alle ' + ora;
  if (gg === 1) return 'domani alle ' + ora;
  return 'fra ' + gg + ' giorni, alle ' + ora;
}


/* ===========================================================================================
   RIORDINARE CON LE FRECCE, E BUTTARE

   QUI C'ERA IL TRASCINAMENTO, e non era un bug da aggiustare: era la forma sbagliata. Dentro a
   una fila che scorre di lato, trascinare e scorrere sono lo stesso gesto — un dito che si
   muove in orizzontale — e qualunque regola inventata per distinguerli sbaglia in un caso su
   tre. Il caso peggiore era proprio quello piu' utile: per portare una card all'INIZIO della
   fila bisogna trascinarla mentre la fila scorre sotto al dito, e i due movimenti si
   annullavano a vicenda. La card restava indietro.

   Le frecce non hanno niente da distinguere. Un tocco, uno spostamento, e la card torna sotto
   gli occhi da sola — che e' la meta' che mancava: spostare qualcosa e perderlo di vista non
   e' spostarlo, e' farlo sparire.
   =========================================================================================== */

let PR_MODO = false;                 // modalita' riordina accesa

function prBarraHtml(){
  if (!PR_MODO) return '';
  const nasc = prNascosti().length;
  return '<div class="pr-barra">'
    + '<span>Con le frecce le sposti, con \u2715 le togli.</span>'
    + (nasc ? '<button type="button" class="pr-barra-b" onclick="prRipristina()">Rimetti quelle di serie (' + nasc + ')</button>' : '')
    + '</div>';
}

/** Il pulsante accanto al titolo di una fila: e' da li' che si entra, non da un gesto nascosto. */
function prRiordinaBtn(){
  return '<button type="button" class="pr-rio" onclick="prModo(' + (PR_MODO ? 'false' : 'true') + ')">'
    + (PR_MODO ? '\u2713 Fatto' : '\u21C4 Riordina') + '</button>';
}

function prModo(on){
  PR_MODO = !!on;
  prPaint();
}

/**
 * Sposta una card di un posto.
 *
 * <p>L'ordine si legge da `prLista`, che e' lo stesso elenco che si vede a schermo: leggere
 * altrove vorrebbe dire tenere allineate due liste, e due liste che devono restare allineate
 * prima o poi non lo sono. Dopo lo spostamento la card si riporta in vista — senza, portarla
 * all'inizio della fila vuol dire vederla uscire dallo schermo.</p>
 */
function prSposta(ev, id, detox, dir){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const ids = prLista(!!detox).map(function(x){ return x.id; });
  const i = ids.indexOf(id), j = i + dir;
  if (i < 0 || j < 0 || j >= ids.length) return;
  ids[i] = ids[j]; ids[j] = id;
  const ord = prOrdine();
  ord[detox ? 'detox' : 'perte'] = ids;
  prScrivi(PR_ORD_KEY, ord);
  prPaint();
  setTimeout(function(){
    const c = document.querySelector('.pr-card[data-id="' + id + '"]');
    if (c && c.scrollIntoView) c.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
  }, 40);
}

/* ---------------------------------------------------------------- la X */

/**
 * Toglie una card.
 *
 * <p>Quelle scritte dall'utente spariscono davvero: le ha fatte lui, puo' disfarle. Quelle di
 * serie si nascondono soltanto — cancellare per sempre una cosa che non hai scritto tu e' una
 * porta che si chiude senza motivo, e il pulsante «rimetti quelle di serie» la riapre.</p>
 */
async function prButta(ev, id){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  const mio = prMiei().filter(function(x){ return x.id === id; })[0];
  const p = mio || prTrova(id);
  if (!p) return;
  if (!(await blkEliminaChiedi(mio ? PR_ELIMINA_CARD
    : { titolo: 'Togli dalle card', testo: 'Vuoi togliere "' + p.nome + '" dalle card? Puoi rimetterla quando vuoi.', si: 'TOGLI' }))) return;
  if (mio) prSalva(prMiei().filter(function(x){ return x.id !== id; }));
  else {
    const n = prNascosti();
    if (n.indexOf(id) < 0) n.push(id);
    prScrivi(PR_NAS_KEY, n);
  }
  /* Anche dall'ordine e dalle durate: un registro che accumula riferimenti a cose che non
     esistono piu' e' un archivio di fantasmi che prima o poi qualcuno prova a disegnare. */
  const ord = prOrdine();
  ord.perte = ord.perte.filter(function(x){ return x !== id; });
  ord.detox = ord.detox.filter(function(x){ return x !== id; });
  prScrivi(PR_ORD_KEY, ord);
  if (mio){ const m = prModifiche(); delete m[id]; prScrivi(PR_MOD_KEY, m); }
  prPaint();
  if (typeof toast === 'function') toast(mio ? 'Eliminata' : 'Tolta');
}

function prRipristina(){
  prScrivi(PR_NAS_KEY, []);
  prPaint();
  if (typeof toast === 'function') toast('Rimesse');
}

/* ---------------------------------------------------------------- il piu' e il meno */

/**
 * La durata, cinque minuti per volta (un giorno per volta, nei digiuni).
 *
 * <p>Il valore scelto NON finisce dentro alla card: le card di serie sono costanti di questo
 * file, e la prossima versione dell'app le riscriverebbe cancellando la scelta. Vive in un
 * registro a parte — «questa card, per me, dura tanto» — che sopravvive agli aggiornamenti.</p>
 */
function prRegola(delta){
  const p = PR_SEL;
  if (!p) return;
  if (p.giorni) p.giorni = Math.max(1, Math.min(30, p.giorni + (delta > 0 ? 1 : -1)));
  else p.min = Math.max(5, Math.min(180, p.min + delta * 5));
  prSetMod(p.id, { dur: p.giorni || p.min });
  const el = document.getElementById('prDurVal');
  if (el) el.textContent = prDurata(p);
  prPaint();
}


/* ---------------------------------------------------------------------------------------
   Il foglio: tieni premuto per iniziare
   --------------------------------------------------------------------------------------- */

let PR_HOLD = 0, PR_SEL = null;

function prApri(id){
  const p = prTrova(id);
  if (!p) return;
  PR_SEL = p;
  let w = document.getElementById('prSheet');
  if (!w){
    w = document.createElement('div');
    w.id = 'prSheet';
    w.className = 'pr-sheet';
    w.addEventListener('click', function(e){ if (e.target === w) prChiudi(); });
    document.body.appendChild(w);
  }
  const sfondo = p.img
    ? 'background-image:url(' + String(p.img).replace(/[()"]/g, '') + ');background-size:cover;background-position:center'
    : 'background:' + prSfondo(p.sfondo);
  const spento = prQuanteBloccate();
  w.innerHTML = '<div class="pr-sheet-in">'
    + '<i class="pr-grab"></i>'
    /* I TRE PUNTINI, e non una riga «Modifica» in mezzo alle altre.
       Rinominare una card, cambiarle faccia o obiettivo non sono azioni da fare ogni volta:
       stanno dietro a un gesto in piu', come in tutte le altre pagine di quest'app. E ci
       stanno per TUTTE le card, non solo per quelle scritte dall'utente — anche una di serie
       si puo' voler chiamare come la si chiama davvero. */
    + '<button type="button" class="pr-dots" onclick="prMenuOpen(event, \'' + p.id + '\')" aria-label="Opzioni">⋯</button>'
    + '<div class="pr-big" style="' + sfondo + '">' + (p.img ? '' : (p.ico || '🎯')) + '</div>'
    + '<h3>' + esc(p.nome) + '</h3>'
    /* 0.9.319, Andrea: il meno e il piu' compaiono solo dopo aver toccato il tempo, come nelle prime versioni, e la matita dice che si puo' cambiare */
    + '<div class="pr-dur" id="prDur">'
    +   '<button type="button" class="pr-pm" onclick="prRegola(-1)" aria-label="Meno tempo">'
    +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 12h12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg></button>'
    +   '<button type="button" class="pr-durval" onclick="prDurToggle()" aria-label="Cambia il tempo"><b id="prDurVal">' + esc(prDurata(p)) + '</b><svg class="pr-durpen" viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg></button>'
    +   '<button type="button" class="pr-pm" onclick="prRegola(1)" aria-label="Più tempo">'
    +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 12h12M12 6v12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg></button>'
    + '</div>'
    + '<button type="button" class="pr-row-btn" onclick="prVaiConsentite()">'
    +   '<span>Cosa resta acceso</span><b>' + spento + '</b><i>›</i></button>'
    /* L'obiettivo con cui partira' la sessione, scritto qui perche' e' la cosa che si legge
       in alto a FullFocus: vederlo prima di premere e' l'unico modo di accorgersi se e' quello
       sbagliato. */
    + '<button type="button" class="pr-row-btn" onclick="prCardEdit(\'' + p.id + '\', \'obiettivo\')">'
    +   '<span>Obiettivo</span><b>' + esc(prObiettivo(p)) + '</b><i>›</i></button>'
    + '<button type="button" class="pr-hold" id="prHold"'
    +   ' onmousedown="prHoldStart()" onmouseup="prHoldStop()" onmouseleave="prHoldStop()"'
    +   ' ontouchstart="prHoldStart()" ontouchend="prHoldStop()" ontouchcancel="prHoldStop()">'
    +   '<i class="pr-fill"></i><span>Tieni premuto per iniziare</span></button>'
    + '</div>';
  w.hidden = false;
}

function prChiudi(){
  prHoldStop();
  const w = document.getElementById('prSheet');
  if (w){ w.hidden = true; w.innerHTML = ''; }
}

/* 0.9.315: il fondo di serie era grigio: adesso e' il blu del brand, anche per le card gia' salvate con il vecchio grafite */
function prSfondo(s){ return (!s || s === 'linear-gradient(160deg,#334155,#0F172A)') ? 'linear-gradient(160deg,#0075E3,#001E44)' : s; }
function prQuanteBloccate(){
  try{
    const p = (typeof ffPref === 'function') ? ffPref() : {};
    const n = (p.allow || []).length + (p.allowSites || []).length;
    return n ? n + (n === 1 ? ' consentita' : ' consentite') : 'Nessuna';
  }catch(_){ return 'Niente'; }
}

/**
 * Cosa resta acceso — senza uscire dalla scheda.
 *
 * <p>Prima portava dentro a FullFocus, con il timer davanti, e poi bisognava tornare indietro:
 * cambiare pagina per rispondere a una domanda che ci si e' fatti qui e' perdere il filo. Il
 * foglio delle consentite e' una sovrapposizione attaccata al telefono, non un pezzo della
 * pagina di FullFocus, quindi si puo' aprire da qualsiasi posto — basta dirgli dove tornare.</p>
 */
function prVaiConsentite(){
  if (typeof ffAllowOpen !== 'function'){ toast('Disponibile nell\'app installata'); return; }
  if (typeof FF !== 'undefined') FF.allowDaPreset = true;
  /* 0.9.272, Andrea: le consentite si aprono SOPRA e la card si chiude (resta la scelta, PR_SEL): con "Fatto" o
     indietro ffAllowChiudi riapre la card col numero nuovo. Aperte con la card dietro, si vedevano sotto di lei. */
  prHoldStop();
  const w = document.getElementById('prSheet'); if (w) w.hidden = true;
  ffAllowOpen('apps');
}

/* ---------------------------------------------------------------------------------------
   Il menu di una card
   --------------------------------------------------------------------------------------- */

function prMenuClose(){
  const m = document.getElementById('prMenu');
  if (m) m.remove();
  const v = document.getElementById('prMenuVelo');
  if (v) v.remove();
}

/* 0.9.309, Andrea (716): il menu ha DUE voci e il suo velo. Prima erano quattro voci
   ("Cambia il nome", "Cambia l'obiettivo", "Faccia e colore", "Togli dalle card") senza niente
   dietro: il menu galleggiava sul foglio e non si capiva come chiuderlo. Adesso il velo scurisce
   il foglio, un tocco fuori chiude, e le tre modifiche stanno in UNA pagina con tre schede. */
function prMenuOpen(ev, id){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('prMenu')){ prMenuClose(); return; }
  const dentro = document.querySelector('#prSheet .pr-sheet-in');
  if (!dentro) return;
  const mio = prMiei().some(function(x){ return x.id === id; });
  const velo = document.createElement('div');
  velo.id = 'prMenuVelo';
  velo.className = 'pr-menu-velo';
  velo.addEventListener('click', function(e){ e.stopPropagation(); prMenuClose(); });
  const m = document.createElement('div');
  m.className = 'arb-menu pr-menu';
  m.id = 'prMenu';
  m.innerHTML = '<p class="arb-mtit">Questa card</p>'
    + '<button type="button" onclick="prMenuClose(); prCardEdit(\'' + id + '\', \'nome\')">Modifica la card</button>'
    + '<button type="button" class="pr-menu-via" onclick="prMenuClose(); prChiudi(); prButta(null, \'' + id + '\')">'
    +   (mio ? 'Elimina la card' : 'Togli dalle card') + '</button>';
  dentro.appendChild(velo);
  dentro.appendChild(m);
}

/** Dove finisce una modifica: nelle card dell'utente se e' sua, nel registro se e' di serie. */
function prApplica(id, patch){
  const list = prMiei();
  const i = list.findIndex(function(x){ return x.id === id; });
  if (i >= 0){ Object.assign(list[i], patch); prSalva(list); }
  else prSetMod(id, patch);
  if (PR_SEL && PR_SEL.id === id) PR_SEL = prTrova(id);
  prPaint();
  if (document.getElementById('prSheet') && !document.getElementById('prSheet').hidden) prApri(id);
}

/* ---------------------------------------------------------------------------------------
   Modifica la card: una pagina, tre schede (Nome | Obiettivo | Aspetto)
   ---------------------------------------------------------------------------------------
   0.9.309, Andrea: "Faccia e colore" era un titolo brutto, e nome e obiettivo si cambiavano in
   due finestrelle del sistema diverse. Adesso e' un foglio solo: si passa da una scheda
   all'altra senza perdere quello che si e' scritto (bozza in PR_CE), e "Salva" scrive tutto
   insieme. La X o un tocco fuori lasciano la card com'era. */

let PR_CE = null;
const PR_CE_TABS = [['nome', 'Nome'], ['obiettivo', 'Obiettivo'], ['aspetto', 'Aspetto']];
/* Niente viola e niente giallo fra i colori da scegliere (brand): "Lavanda" e "Alba" restano
   nell'elenco solo perche' una card che li ha gia' continui a disegnarsi. */
const PR_CE_SFONDI = PR_SFONDI.filter(function(c){ return c[0] !== 'Lavanda' && c[0] !== 'Alba'; });

function prCardEdit(id, tab){
  const p = prTrova(id);
  if (!p) return;
  prMenuClose();
  /* Il foglio della card si toglie di mezzo finche' si modifica (due fogli impilati si leggono
     male) e torna, aggiornato, quando si chiude. */
  const sotto = document.getElementById('prSheet');
  const dalFoglio = !!(sotto && !sotto.hidden);
  if (dalFoglio){ prHoldStop(); sotto.hidden = true; }
  PR_CE = {
    id: id, tab: tab || 'nome', dalFoglio: dalFoglio,
    nome: p.nome || '', intent: (p.intent === undefined || p.intent === null) ? '' : String(p.intent),
    ico: p.ico || '🎯', sfondo: p.sfondo || '', img: p.img || '',
    tag: p.tag || '', scriviTag: false,
    mio: prMiei().some(function(x){ return x.id === id; }),
    prima: { nome: p.nome || '', intent: p.intent, ico: p.ico, sfondo: p.sfondo, img: p.img, tag: p.tag || '' }
  };
  prCePaint();
}

function prCeLeggi(){
  if (!PR_CE) return;
  const n = document.getElementById('prCeNome'); if (n) PR_CE.nome = n.value;
  const o = document.getElementById('prCeObi'); if (o) PR_CE.intent = o.value;
}

function prCePaint(){
  const c = PR_CE;
  if (!c) return;
  let w = document.getElementById('prCardEdit');
  if (!w){
    w = document.createElement('div');
    w.id = 'prCardEdit';
    w.className = 'pr-sheet';
    w.addEventListener('click', function(e){ if (e.target === w) prCeChiudi(); });
    document.body.appendChild(w);
  }
  const sfondo = c.img
    ? 'background-image:url(' + String(c.img).replace(/[()"]/g, '') + ');background-size:cover;background-position:center'
    : 'background:' + prSfondo(c.sfondo);
  let corpo = '';
  if (c.tab === 'nome'){
    corpo = '<label class="pr-ce-lab" for="prCeNome">Il nome che vedi sulla card</label>'
      + '<input class="fin pr-ce-in" id="prCeNome" value="' + esc(c.nome) + '" placeholder="Come chiami questa sessione" autocomplete="off" enterkeyhint="done">';
  } else if (c.tab === 'obiettivo'){
    corpo = '<label class="pr-ce-lab" for="prCeObi">Lo leggi in alto mentre sei in Full Focus</label>'
      + '<textarea class="fin pr-ce-in pr-ce-ta" id="prCeObi" rows="3" placeholder="Se lo lasci vuoto, vale il nome della card">' + esc(c.intent) + '</textarea>'
      /* 0.9.319, Andrea: la categoria dell'obiettivo, con la sua emoji: finisce nel report (insCategorieCard) */
      + '<p class="pr-ce-lab pr-ce-lab2">Di che tipo è questo obiettivo?</p><div class="pr-cats">' + prCeCategorie().map(function(t){
          return '<button type="button" class="pr-cat' + (c.tag === t.id ? ' on' : '') + '" onclick="prCeTag(\'' + t.id + '\')"><span>' + ffTagIco(t) + '</span>' + esc(t.name) + '</button>';
        }).join('')
      + (c.scriviTag
          ? '<div class="pr-cat-nuova"><input class="fin" id="prCeNuovaCat" maxlength="24" placeholder="Il nome della categoria" enterkeyhint="done"><button type="button" onclick="prCeTagAggiungi()">Aggiungi</button></div>'
          : '<button type="button" class="pr-cat scrivi" onclick="prCeTagScrivi()"><span>✍️</span>La scrivo io</button>')
      + '</div>';
  } else {
    corpo = '<div class="pr-big pr-ce-prev" style="' + sfondo + '">' + (c.img ? '' : esc(c.ico)) + '</div>'
      + '<p class="pr-ce-lab">L\'icona</p>'
      + '<div class="pr-emo">' + PR_EMOJI.map(function(e){
          return '<button type="button" class="pr-emo-b' + (!c.img && c.ico === e ? ' on' : '') + '" onclick="prCeSet(\'ico\',\'' + e + '\')">' + e + '</button>';
        }).join('') + '</div>'
      + '<p class="pr-ce-lab">Il colore dietro</p>'
      + '<div class="pr-col">' + PR_CE_SFONDI.map(function(s, i){
          return '<button type="button" class="pr-col-b' + (!c.img && c.sfondo === s[1] ? ' on' : '') + '" aria-label="' + s[0] + '"'
            + ' style="background:' + s[1] + '" onclick="prCeSet(\'sfondo\',' + i + ')"></button>';
        }).join('') + '</div>'
      + '<button type="button" class="pr-row-btn pr-ce-foto" onclick="prCeFoto()">'
      +   '<span>' + (c.img ? 'Cambia la fotografia' : 'Usa una tua fotografia') + '</span>'
      +   '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
  }
  w.innerHTML = '<div class="pr-sheet-in pr-ce">'
    + '<i class="pr-grab"></i>'
    + '<button type="button" class="pr-ce-x" onclick="prCeChiudi()" aria-label="Chiudi">'
    +   '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '<h3>Modifica la card</h3>'
    + '<div class="pr-ce-tabs" role="tablist">' + PR_CE_TABS.map(function(t){
        return '<button type="button" role="tab" aria-selected="' + (c.tab === t[0]) + '" class="' + (c.tab === t[0] ? 'on' : '') + '" onclick="prCeTab(\'' + t[0] + '\')">' + t[1] + '</button>';
      }).join('') + '</div>'
    + '<div class="pr-ce-body">' + corpo + '</div>'
    + '<button type="button" class="pr-ce-salva" onclick="prCeSalva()">Salva</button>'
    + (c.mio ? '<button type="button" class="pr-ce-altro" onclick="prCeAltro()">Durata e tipo di sessione</button>' : '')
    + '</div>';
  w.hidden = false;
}

function prCeCategorie(){ try{ return ffTags().filter(function(t){ return t && t.id !== 'meditazione'; }); }catch(_){ return []; } }
function prCeTag(id){ if (!PR_CE) return; prCeLeggi(); PR_CE.tag = PR_CE.tag === id ? '' : id; prCePaint(); try{ flVibra(8); }catch(_){ } }
function prCeTagScrivi(){ if (!PR_CE) return; prCeLeggi(); PR_CE.scriviTag = true; prCePaint(); setTimeout(function(){ const i = document.getElementById('prCeNuovaCat'); if (i) i.focus(); }, 60); }
function prCeTagAggiungi(){
  const i = document.getElementById('prCeNuovaCat'), n = String(i ? i.value : '').trim(); if (!n || !PR_CE){ if (i) i.focus(); return; }
  prCeLeggi();
  const tags = ffTags(), id = 't' + Date.now();
  tags.push({ id: id, name: n, col: '#0075E3' }); ffWrite('fl_ff_tags', tags);
  PR_CE.tag = id; PR_CE.scriviTag = false; prCePaint();
}
function prCeTab(t){
  if (!PR_CE) return;
  prCeLeggi();
  PR_CE.tab = t;
  prCePaint();
}

/* Un'icona o un colore tolgono la fotografia: con la fotografia sopra non si vedrebbero. */
function prCeSet(k, v){
  if (!PR_CE) return;
  prCeLeggi();
  if (k === 'sfondo') PR_CE.sfondo = PR_CE_SFONDI[v][1];
  else PR_CE.ico = v;
  PR_CE.img = '';
  prCePaint();
}

function prCeFoto(){
  if (!PR_CE) return;
  prCeLeggi();
  prFoto(function(out){
    if (!PR_CE) return;
    PR_CE.img = out;
    prCePaint();
  });
}

function prCeChiudi(riapri){
  const c = PR_CE;
  const w = document.getElementById('prCardEdit');
  if (w) w.remove();
  PR_CE = null;
  if (c && c.dalFoglio && riapri !== false) prApri(c.id);
}

function prCeAltro(){
  const c = PR_CE;
  if (!c) return;
  prCeChiudi(false);
  prModifica(c.id);
}

/* Si scrive solo quello che e' cambiato: una card di serie che si porta dietro nel registro
   anche i campi non toccati non vedrebbe piu' le correzioni delle versioni nuove. */
function prCeSalva(){
  const c = PR_CE;
  if (!c) return;
  prCeLeggi();
  const nome = String(c.nome || '').trim();
  if (!nome){
    c.tab = 'nome';
    prCePaint();
    if (typeof toast === 'function') toast('Scrivi un nome per la card');
    return;
  }
  const v = c.prima, patch = {};
  if (nome !== v.nome) patch.nome = nome;
  const obi = String(c.intent || '').trim();
  if (obi !== String(v.intent == null ? '' : v.intent).trim()) patch.intent = obi;
  if (c.ico !== (v.ico || '\uD83C\uDFAF')) patch.ico = c.ico;
  if ((c.sfondo || '') !== (v.sfondo || '')) patch.sfondo = c.sfondo;
  if ((c.img || '') !== (v.img || '')) patch.img = c.img;
  if ((c.tag || '') !== (v.tag || '')) patch.tag = c.tag;
  const id = c.id;
  prCeChiudi();
  if (Object.keys(patch).length){
    prApplica(id, patch);
    if (typeof toast === 'function') toast('Card aggiornata');
  }
}

/* Ottocento millisecondi: abbastanza da non partire per sbaglio, pochi da non sembrare rotto. */
const PR_HOLD_MS = 800;

function prDurToggle(){ const d = document.getElementById('prDur'); if (d) d.classList.toggle('aperto'); try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ } }
function prHoldStart(){
  const b = document.getElementById('prHold');
  if (!b) return;
  b.classList.add('holding');
  clearTimeout(PR_HOLD);
  PR_HOLD = setTimeout(prVia, PR_HOLD_MS);
}

function prHoldStop(){
  clearTimeout(PR_HOLD);
  const b = document.getElementById('prHold');
  if (b) b.classList.remove('holding');
}

async function prVia(){
  const p = PR_SEL;
  prChiudi();
  if (!p) return;
  if (p.giorni) return prDetoxStart(p);
  return prSessione(p);
}

/* ---------------------------------------------------------------------------------------
   Le due strade
   --------------------------------------------------------------------------------------- */

/** Una sessione: si scrivono i campi nelle preferenze di FullFocus e si fa partire la sua. */
async function prSessione(p){
  if (typeof ffPref !== 'function' || typeof ffStart !== 'function'){
    toast('Disponibile nell\'app installata');
    return;
  }
  const pref = ffPref();
  pref.minutes = Math.max(5, Math.min(180, p.min || 30));
  if (p.tag) pref.tag = p.tag;
  /* L'OBIETTIVO E' SEMPRE QUELLO DELLA CARD. Prima si scriveva solo se la card ne aveva uno
     suo — e le card di serie non ce l'hanno — quindi restava quello di prima, cioe' la riga
     della pianificazione: si sceglieva «Lettura» e FullFocus diceva un'altra cosa. */
  pref.intent = prObiettivo(p);
  /* E non basta scriverlo: ffOpen() chiama stSyncToFF(), che rimetterebbe subito la riga del
     foglio al posto di questa. La bandierina vale per questa apertura sola. */
  if (typeof stSaltaSync === 'function') stSaltaSync();
  /* Le app consentite NON si toccano: sono una scelta dell'utente che vale per tutte le
     sessioni, e un preset che se la porta dietro cambierebbe le regole alle spalle di chi
     l'ha toccato l'ultima volta. Il preset decide quanto dura e come si chiama. */
  if (typeof ffSavePref === 'function') ffSavePref();
  if (typeof ffOpen === 'function') ffOpen();
  setTimeout(function(){ try{ ffStart(); }catch(_){ } }, 240);
}

/**
 * Un digiuno: un programma che blocca le distrazioni e si toglie da solo alla scadenza.
 *
 * <p>Non è una sessione di FullFocus perché FullFocus si ferma a tre ore, e deve fermarsi: un
 * timer da cinque giorni non lo guarda nessuno. Un programma invece è esattamente la forma
 * giusta — vive nel motore, sopravvive al riavvio del telefono, e non ha bisogno che l'app
 * resti aperta.</p>
 */
async function prDetoxStart(p){
  if (typeof PROGRAMS === 'undefined' || typeof pushRules !== 'function'){
    toast('Disponibile nell\'app installata');
    return;
  }
  if (prDetoxCorso()){ toast('Un digiuno è già in corso'); return; }
  const id = 'p' + Date.now().toString(36);
  const fino = Date.now() + (p.giorni || 1) * 86400000;
  PROGRAMS.push({
    id: id,
    name: p.nome,
    type: 'schedule', icon: p.ico || '🌾',
    from: '00:00', to: '23:59',
    days: [true, true, true, true, true, true, true],
    allDay: true,
    apps: prAppDistraenti(),
    sites: (typeof DISTRACTIONS !== 'undefined' ? DISTRACTIONS.slice() : []),
    keywords: [], allow: [],
    blockLaunch: true, blockNotifications: true, on: true
  });
  if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
  if (typeof renderPrograms === 'function') renderPrograms();
  await pushRules();
  if (typeof syncNative === 'function') syncNative();
  try{ localStorage.setItem(PR_DETOX_KEY, JSON.stringify({ id: id, fino: fino, nome: p.nome })); }catch(_){ }
  prPaint();
  toast(p.nome + ': si comincia. Finisce ' + prQuando(fino) + '.');
}

/** Le app che l'app stessa considera distrazioni, se le sa. */
function prAppDistraenti(){
  try{
    const cats = (typeof insCats === 'function') ? insCats() : {};
    return Object.keys(cats).filter(function(k){ return cats[k] === 'distr'; });
  }catch(_){ return []; }
}

function prDetoxCorso(){
  let d = null;
  try{ d = JSON.parse(localStorage.getItem(PR_DETOX_KEY) || 'null'); }catch(_){ }
  if (!d || !d.fino) return null;
  if (Date.now() >= d.fino){ prDetoxFine(true); return null; }
  return d;
}

async function prDetoxFine(finito){
  let d = null;
  try{ d = JSON.parse(localStorage.getItem(PR_DETOX_KEY) || 'null'); }catch(_){ }
  try{ localStorage.removeItem(PR_DETOX_KEY); }catch(_){ }
  if (!d || typeof PROGRAMS === 'undefined') return;
  const i = PROGRAMS.findIndex(function(x){ return x && x.id === d.id; });
  if (i >= 0){
    PROGRAMS.splice(i, 1);
    if (typeof saveProgramsLocal === 'function') saveProgramsLocal();
    if (typeof renderPrograms === 'function') renderPrograms();
    try{ await pushRules(); }catch(_){ }
    if (typeof syncNative === 'function') syncNative();
  }
  if (finito && typeof toast === 'function') toast(d.nome + ': finito. Bentornato.');
  prPaint();
}

function prDetoxStop(){
  const d = prDetoxCorso();
  if (!d) return;
  /* Interrompere un digiuno è un'interruzione come le altre: l'arbitro deve saperlo, o il
     tabellone racconterebbe una settimana più pulita di quella vera. */
  try{ if (typeof itBump === 'function') itBump('detox'); }catch(_){ }
  prDetoxFine(false);
  toast('Digiuno interrotto');
}

/* Alla scadenza il programma si toglie da solo: un blocco che resta acceso dopo la fine è il
   modo più rapido di far disinstallare l'app. */
setInterval(function(){ try{ prDetoxCorso(); }catch(_){ } }, 60000);

/* ---------------------------------------------------------------------------------------
   Il tuo preset
   --------------------------------------------------------------------------------------- */

let PR_EDIT = null;

function prNuovo(detox){
  PR_EDIT = detox
    ? { id: 'u' + Date.now().toString(36), mio: true, nome: '', giorni: 1, sotto: '', img: '', ico: '🌙' }
    : { id: 'u' + Date.now().toString(36), mio: true, nome: '', min: 45, tag: 'lavoro', intent: '', img: '', ico: '🎯' };
  prEditPaint();
}

function prModifica(id){
  const p = prTrova(id);
  if (!p || !p.mio) return;
  prChiudi();
  PR_EDIT = JSON.parse(JSON.stringify(p));
  prEditPaint();
}

function prEditPaint(){
  const p = PR_EDIT;
  if (!p) return;
  let w = document.getElementById('prEdit');
  if (!w){
    w = document.createElement('div');
    w.id = 'prEdit';
    w.className = 'pr-edit';
    document.body.appendChild(w);
  }
  const detox = !!p.giorni;
  const sfondo = p.img
    ? 'background-image:url(' + String(p.img).replace(/[()"]/g, '') + ');background-size:cover;background-position:center'
    : 'background:' + prSfondo(p.sfondo);

  w.innerHTML = '<div class="pr-edit-top">'
    + '<button type="button" class="iconbtn" onclick="prEditClose()">‹</button>'
    + '<b>' + (detox ? 'Il tuo digiuno' : 'La tua sessione') + '</b></div>'
    + '<button type="button" class="pr-big pr-big-edit" style="' + sfondo + '" onclick="prFoto()">'
    +   (p.img ? '' : (p.ico || '🎯')) + '<i>Cambia immagine</i></button>'
    + '<input class="fin pr-nome" id="prNome" maxlength="28" placeholder="' + (detox ? 'Come si chiama il digiuno' : 'Come si chiama la sessione') + '" value="' + esc(p.nome || '') + '" onchange="prSet(\'nome\', this.value)">'
    + (detox
        ? '<div class="pr-sub2">⏳ Quanti giorni dura</div>'
          + '<div class="pr-chips">' + [1, 2, 3, 5, 7, 14].map(function(g){
              return '<button type="button" class="pr-chip' + (p.giorni === g ? ' on' : '') + '" onclick="prSet(\'giorni\',' + g + ')">'
                + g + (g === 1 ? ' giorno' : ' giorni') + '</button>';
            }).join('') + '</div>'
          + '<input class="fin pr-nome" maxlength="34" placeholder="Una riga sotto al nome" value="' + esc(p.sotto || '') + '" onchange="prSet(\'sotto\', this.value)">'
        : '<div class="pr-sub2">⏱️ Quanto dura la sessione</div>'
          /* 45 minuti e 2 ore erano due gradini in mezzo a sette: adesso che dal foglio della
             card si regola di cinque in cinque, un gradino in meno e' un'esitazione in meno.
             E «3h» lascia il posto a una durata a scelta: era l'ultimo gradino di una scala
             che si fermava li', e chi ne voleva due e un quarto non era previsto. */
          + '<div class="pr-chips">' + [15, 25, 60, 90].map(function(m){
              return '<button type="button" class="pr-chip' + (p.min === m ? ' on' : '') + '" onclick="prSet(\'min\',' + m + ')">'
                + prDurata({ min: m }) + '</button>';
            }).join('')
            + '<button type="button" class="pr-chip' + ([15, 25, 60, 90].indexOf(p.min) < 0 ? ' on' : '') + '" onclick="prDurataMia()">'
            + ([15, 25, 60, 90].indexOf(p.min) < 0 ? prDurata({ min: p.min }) + ' ✎' : 'Altro…') + '</button>'
            + '</div>'
          + '<div class="pr-sub2">🏷️ Che tipo di sessione è</div>'
          + '<div class="pr-chips">' + ((typeof ffTags === 'function') ? ffTags() : []).map(function(t){
              return '<button type="button" class="pr-chip' + (p.tag === t.id ? ' on' : '') + '" onclick="prSet(\'tag\',\'' + t.id + '\')">'
                + esc(t.name) + '</button>';
            }).join('') + '</div>')
    + '<div class="pr-sub2">✅ Cosa resta aperto</div>'
    + '<button type="button" class="pr-row-btn pr-cons" onclick="prVaiConsentite()">'
    +   '<span>App, siti e parole consentite</span><b>' + prQuanteBloccate() + '</b><i>›</i></button>'
    + '<p class="pr-note">Valgono per tutte le tue sessioni.</p>'
    + '<button type="button" class="cta" onclick="prEditSave()">Salva</button>'
    + (prMiei().some(function(x){ return x.id === p.id; })
        ? '<button type="button" class="pr-del" onclick="prEditDel()">Elimina</button>' : '');
  w.hidden = false;
}

function prSet(k, v){
  if (!PR_EDIT) return;
  PR_EDIT[k] = v;
  prEditPaint();
}

/** Una durata qualsiasi, fra cinque minuti e tre ore: oltre non e' piu' una sessione. */
function prDurataMia(){
  if (!PR_EDIT) return;
  const v = prompt('Quanti minuti? (da 5 a 180)', String(PR_EDIT.min || 45));
  if (v === null) return;
  const n = parseInt(String(v).replace(/[^0-9]/g, ''), 10);
  if (!n || n < 5 || n > 180){ if (typeof toast === 'function') toast('Fra 5 e 180 minuti'); return; }
  prSet('min', n);
}

function prEditClose(){
  const w = document.getElementById('prEdit');
  if (w) w.remove();
  PR_EDIT = null;
}

function prEditSave(){
  const p = PR_EDIT;
  if (!p) return;
  const nome = document.getElementById('prNome');
  if (nome) p.nome = String(nome.value || '').trim().slice(0, 28);
  if (!p.nome){ toast('Dagli un nome'); return; }
  const list = prMiei().filter(function(x){ return x.id !== p.id; });
  list.push(p);
  prSalva(list);
  prEditClose();
  prPaint();
  toast('Salvata');
}

const PR_ELIMINA_CARD = { titolo: 'Elimina la card', testo: 'Vuoi davvero eliminare la card? L\u2019operazione non può essere annullata.' };
async function prEditDel(){
  const p = PR_EDIT;
  if (!p) return;
  if (!(await blkEliminaChiedi(PR_ELIMINA_CARD))) return;
  prSalva(prMiei().filter(function(x){ return x.id !== p.id; }));
  prEditClose();
  prPaint();
  toast('Eliminata');
}

/* La faccia della card: ridotta prima di essere tenuta, come tutte le immagini di quest'app. */
/* `dopo` opzionale: senza, l'immagine finisce nella card in modifica (il vecchio uso); con,
   la riceve chi l'ha chiesta. Serve per cambiare la fotografia di una card DI SERIE, che non
   passa dall'editor — passarci vorrebbe dire trasformarla in una card dell'utente. */
function prFoto(dopo){
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0];
    try{ inp.remove(); }catch(_){ }
    if (!f) return;
    const fr = new FileReader();
    fr.onload = function(){
      const img = new Image();
      img.onload = function(){
        try{
          const W = 420, H = 560, cv = document.createElement('canvas');
          cv.width = W; cv.height = H;
          const ctx = cv.getContext('2d');
          const s = Math.max(W / img.width, H / img.height);
          const w = img.width * s, h = img.height * s;
          ctx.drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
          let out = cv.toDataURL('image/jpeg', 0.78);
          if (out.length > 420000) out = cv.toDataURL('image/jpeg', 0.6);
          if (typeof dopo === 'function') dopo(out);
          else if (PR_EDIT){ PR_EDIT.img = out; prEditPaint(); }
        }catch(e){ toast('Immagine troppo grande'); }
      };
      img.onerror = function(){ toast('Non riesco a leggere questa immagine'); };
      img.src = fr.result;
    };
    fr.readAsDataURL(f);
  });
  document.body.appendChild(inp);
  inp.click();
}

/* ---------------------------------------------------------------------------------------
   Lo stile
   --------------------------------------------------------------------------------------- */

(function prStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.pr-sect{margin:28px 0 12px}',
    '.pr-sect b{display:block;font:800 19px var(--font-display);color:var(--navy)}',
    'body.dark .pr-sect b{color:#fff}',
    '.pr-sect small{display:block;margin-top:3px;font:500 12.5px var(--font-body);color:var(--muted)}',
    /* La fila scorre di lato e sborda dai margini della pagina: le card devono sembrare
       continuare oltre il bordo, o non si capisce che ce ne sono altre. */
    '.pr-row{display:flex;gap:12px;overflow-x:auto;padding:2px 18px 6px;margin:0 -18px;',
      'scrollbar-width:none;scroll-snap-type:x mandatory}',
    '.pr-row::-webkit-scrollbar{display:none}',
    '.pr-card{position:relative;flex:0 0 66%;max-width:250px;aspect-ratio:3/4;border:0;padding:0;',
      'border-radius:22px;overflow:hidden;cursor:pointer;scroll-snap-align:center;',
      'display:flex;align-items:flex-end;text-align:left}',
    '.pr-art{position:absolute;top:50%;left:50%;transform:translate(-50%,-58%);font-size:74px;opacity:.9}',
    '.pr-veil{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,0) 38%,rgba(0,0,0,.72))}',
    '.pr-txt{position:relative;padding:16px;width:100%}',
    '.pr-txt b{display:block;font:800 19px/1.2 var(--font-display);color:#fff}',
    '.pr-txt i{display:block;margin-top:3px;font:500 12px var(--font-body);font-style:normal;color:rgba(255,255,255,.72)}',
    '.pr-go{display:inline-block;margin-top:12px;background:rgba(255,255,255,.18);color:#fff;',
      'border-radius:99px;padding:8px 15px;font:700 12.5px var(--font-body);backdrop-filter:blur(6px)}',
    '.pr-piu{background:transparent;border:1.5px dashed var(--line);flex-direction:column;',
      'align-items:center;justify-content:center;text-align:center;padding:18px}',
    '.pr-piu-ic{font:300 42px/1 var(--font-body);color:var(--blue)}',
    '.pr-piu-t{display:block;margin-top:10px;font:800 15px var(--font-display);color:var(--navy)}',
    'body.dark .pr-piu-t{color:#fff}',
    '.pr-piu-s{display:block;margin-top:5px;font:500 11.5px/1.45 var(--font-body);color:var(--muted)}',
    '.pr-corso{display:flex;align-items:center;gap:12px;background:rgba(0,117,227,.1);',
      'border:1px solid rgba(0,117,227,.35);border-radius:16px;padding:13px 15px;margin-bottom:12px}',
    '.pr-corso > div{flex:1}',
    '.pr-corso b{display:block;font:800 14px var(--font-body);color:var(--navy)}',
    'body.dark .pr-corso b{color:#fff}',
    '.pr-corso small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.pr-corso button{border:0;background:transparent;color:#E5515F;font:700 13px var(--font-body);cursor:pointer}',

    '.pr-sheet{position:fixed;inset:0;z-index:9994;background:rgba(0,8,20,.7);display:flex;',
      'align-items:flex-end;justify-content:center}',
    '.pr-sheet-in{width:100%;max-width:460px;background:var(--card,#fff);border-radius:26px 26px 0 0;',
      'padding:12px 22px calc(24px + env(safe-area-inset-bottom,0px));text-align:center;',
      'animation:prUp .22s ease-out}',
    '@keyframes prUp{from{transform:translateY(22px);opacity:.4}to{transform:none;opacity:1}}',
    '.pr-grab{display:block;width:38px;height:4px;border-radius:99px;background:var(--line);margin:0 auto 18px}',
    '.pr-big{width:126px;height:126px;margin:0 auto;border-radius:26px;display:flex;align-items:center;',
      'justify-content:center;font-size:56px;border:0;position:relative}',
    '.pr-sheet-in h3{margin:18px 0 4px;font:800 21px var(--font-display);color:var(--navy)}',
    'body.dark .pr-sheet-in h3{color:#fff}',
    '.pr-dur{margin:0 0 18px;font:600 13.5px var(--font-body);color:var(--muted)}',
    '.pr-row-btn{display:flex;align-items:center;gap:10px;width:100%;border:0;border-radius:16px;',
      'background:rgba(0,30,68,.05);padding:15px 16px;margin-bottom:10px;cursor:pointer;',
      'font:600 13.5px var(--font-body);color:var(--navy)}',
    'body.dark .pr-row-btn{background:rgba(255,255,255,.07);color:#fff}',
    '.pr-row-btn span{flex:1;text-align:left}',
    '.pr-row-btn b{font-weight:700;color:var(--muted)}',
    '.pr-row-btn i{font-style:normal;color:var(--faint)}',
    /* TIENI PREMUTO: la barra che si riempie è il contratto — finché non è piena non è
       successo niente, e lasciare la presa non costa nulla. */
    '.pr-hold{position:relative;width:100%;border:0;border-radius:99px;overflow:hidden;cursor:pointer;',
      /* 0.9.319, Andrea: fermo e senza alone finche' non lo si tiene premuto: come il pulsante Aggiungi al carrello di dream-brothers.it, dove il colore sale dal basso con il bordo inclinato */
      'background:#0075E3;color:#fff;font:800 15px var(--font-body);',
      'padding:17px 20px;margin-top:8px}',
    '@keyframes prSogna{0%{background-position:0 0}100%{background-position:400% 0}}',
    '.pr-fill{position:absolute;left:0;right:0;top:-8%;bottom:0;background:#00459A;clip-path:polygon(0 7%,100% 0,100% 100%,0 100%);transform:translateY(102%);transition:transform .25s ease-out}',
    '.pr-hold.holding .pr-fill{transform:none;transition:transform ' + 800 + 'ms linear}',
    '@media (hover:hover){.pr-hold:hover .pr-fill{transform:translateY(82%)}.pr-hold.holding:hover .pr-fill{transform:none}}',
    '.pr-hold span{position:relative}',

    '.pr-edit{position:fixed;inset:0;z-index:9995;background:var(--bg,#0B1220);overflow-y:auto;',
      'padding:calc(env(safe-area-inset-top,0px) + 10px) 18px calc(env(safe-area-inset-bottom,0px) + 26px)}',
    /* 0.9.315, Andrea: colori del brand, titoli che si leggono, aria fra un blocco e l'altro */
    '.pr-edit-top{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;margin-bottom:18px}',
    '.pr-edit-top b{text-align:center;font:800 19px var(--font-display);color:var(--navy)}',
    'body.dark .pr-edit-top b{color:#fff}',
    '.pr-big-edit{cursor:pointer}',
    '.pr-big-edit i{position:absolute;left:0;right:0;bottom:-24px;font:600 11.5px var(--font-body);',
      'font-style:normal;color:var(--blue)}',
    '.pr-nome{display:block;width:100%;margin:36px 0 0;text-align:center;box-sizing:border-box}',
    '.pr-sub2{margin:30px 0 12px;font:800 18px var(--font-display);color:var(--navy)}',
    'body.dark .pr-sub2{color:#fff}',
    '.pr-chips{display:flex;gap:10px;flex-wrap:wrap}',
    '.pr-chip{min-height:46px;border:1.5px solid #BCE0FF;background:var(--card,#fff);border-radius:99px;',
      'padding:10px 18px;font:700 14.5px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .pr-chip{background:#14234A;border-color:rgba(188,224,255,.22);color:#fff}',
    '.pr-chip.on,body.dark .pr-chip.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.pr-cons{min-height:64px;margin:0;padding:14px 18px;border-radius:20px;background:#E3F1FF;font:700 15px/1.3 var(--font-body);color:#001E44}',
    '.pr-cons b{flex:none;color:#0075E3;font-weight:800}.pr-cons i{color:#0075E3;font-size:18px}',
    'body.dark .pr-cons{background:#14234A;color:#fff}body.dark .pr-cons b,body.dark .pr-cons i{color:#8CC6FF}',
    '.pr-note{margin:10px 0 26px;text-align:center;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.pr-del{display:block;margin:14px auto 0;border:0;background:transparent;color:#E5515F;',
      'font:700 13px var(--font-body);cursor:pointer}',

    /* ---- IL NUMERO CHE SI REGOLA ---- */
    '.pr-sheet-in{position:relative}',
    '.pr-dots{position:absolute;top:14px;right:16px;width:36px;height:36px;border:0;border-radius:50%;',
      'background:rgba(0,30,68,.07);color:var(--navy);font:800 17px var(--font-body);cursor:pointer;line-height:1;z-index:4}',
    'body.dark .pr-dots{background:rgba(255,255,255,.1);color:#fff}',
    '.pr-menu{top:56px;right:16px;left:auto}',
    '.pr-emo{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:6px}',
    '.pr-emo-b{width:44px;height:44px;border:1.5px solid var(--line);border-radius:14px;',
      'background:var(--card,#fff);font-size:22px;line-height:1;cursor:pointer}',
    '.pr-emo-b.on{border-color:var(--blue);box-shadow:0 0 0 2px rgba(0,117,227,.25)}',
    '.pr-col{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin-bottom:14px}',
    '.pr-col-b{width:46px;height:46px;border:0;border-radius:50%;cursor:pointer;',
      'box-shadow:0 2px 8px rgba(0,30,68,.2)}',
    '.pr-col-b.on{box-shadow:0 0 0 3px var(--blue)}',
    '.pr-dur{display:flex;align-items:center;justify-content:center;gap:4px;margin:0 0 18px}',
    '.pr-durval{display:flex;align-items:center;gap:6px;border:0;background:transparent;cursor:pointer;',
      'font:600 13.5px var(--font-body);color:var(--muted)}',
    'body.dark .pr-durval{color:#A7B6CC}',
    '.pr-durval i{font-style:normal;font-size:11px;opacity:.6}',
    /* 0.9.309: il meno e il piu' ci sono SEMPRE, cerchi da 40px contornati di blu, il numero in
       mezzo largo abbastanza da non far ballare i pulsanti quando cambia. */
    '.pr-pm{display:none;align-items:center;justify-content:center;flex:none;width:34px;height:34px;padding:0;',
      'border:1px solid var(--line);border-radius:50%;background:var(--card,#fff);color:var(--navy);cursor:pointer}',
    '.pr-dur.aperto .pr-pm{display:flex}',
    'body.dark .pr-pm{color:#fff}',
    '.pr-durpen{color:var(--muted)}.pr-dur.aperto .pr-durpen{display:none}',
    '.pr-pm:active{transform:scale(.92)}',
    '#prDur{gap:14px;margin:10px 0 22px}',
    '#prDur .pr-durval{min-width:84px;justify-content:center;cursor:default;font:800 16px var(--font-body);color:var(--navy)}',
    'body.dark #prDur .pr-durval{color:#fff}',

    /* ---- IL MENU DEI TRE PUNTINI: velo sul foglio, tocco fuori chiude ---- */
    '.pr-menu-velo{position:absolute;inset:0;z-index:29;border-radius:inherit;background:rgba(0,8,20,.45);',
      'animation:prVelo .18s ease-out}',
    '@keyframes prVelo{from{opacity:0}to{opacity:1}}',
    'body.dark .pr-menu-velo{background:rgba(0,4,14,.6)}',
    '.pr-menu{min-width:210px;border-radius:16px}',
    '.pr-menu button{padding:15px 16px;font:700 14.5px var(--font-body)}',
    '.arb-menu.pr-menu button.pr-menu-via{color:#C42B38}',
    'body.dark #prMenu.arb-menu,body.dark #prMenu button,body.dark #prMenu .arb-mtit{background:#22376B !important}',
    'body.dark #prMenu.arb-menu{border:1px solid rgba(188,224,255,.3);box-shadow:0 18px 44px rgba(0,0,0,.6)}',
    'body.dark #prMenu button + button{border-top-color:rgba(188,224,255,.16) !important}',
    'body.dark #prMenu .arb-mtit{color:#BCE0FF !important}',
    'body.dark #prMenu button:not(.pr-menu-via){color:#fff !important}',
    'body.dark #prMenu button.pr-menu-via{color:#FF9AA3 !important}',

    /* ---- IL FOGLIO DELLA CARD, in scuro: piu' chiaro del velo, bordo chiaro in cima ---- */
    'body.dark #prSheet .pr-sheet-in,body.dark #prCardEdit .pr-sheet-in{background:#1C2E5A;',
      'box-shadow:0 -1px 0 rgba(188,224,255,.35),0 -14px 40px rgba(0,0,0,.45)}',

    /* ---- MODIFICA LA CARD: tre schede ---- */
    '.pr-ce{max-height:92vh;overflow-y:auto;padding-left:20px;padding-right:20px}',
    '.pr-ce h3{margin:10px 0 0}',
    '.pr-ce-x{position:absolute;top:14px;right:16px;width:36px;height:36px;border:0;border-radius:50%;z-index:4;',
      'display:flex;align-items:center;justify-content:center;background:rgba(0,30,68,.07);color:#0F2041;cursor:pointer}',
    'body.dark #prSheet .pr-grab,body.dark #prCardEdit .pr-grab{background:rgba(188,224,255,.4)}',
    'body.dark .pr-ce-x{background:rgba(255,255,255,.14);color:#fff}',
    '.pr-ce-tabs{display:flex;gap:4px;margin:20px 0 0;padding:4px;border-radius:50px;background:rgba(0,30,68,.06)}',
    'body.dark .pr-ce-tabs{background:rgba(0,8,24,.35)}',
    '.pr-ce-tabs button{flex:1;border:0;border-radius:50px;padding:11px 6px;background:transparent;cursor:pointer;',
      'font:700 14px var(--font-body);color:#4A5B78}',
    'body.dark .pr-ce-tabs button{color:#BCE0FF}',
    '.pr-ce-tabs button.on{background:#0075E3;color:#fff;box-shadow:0 4px 12px rgba(0,117,227,.3)}',
    '.pr-ce-body{min-height:132px;padding-top:24px;text-align:center}',
    '.pr-ce .pr-ce-lab.pr-ce-lab2{margin-top:30px}.pr-cats{display:grid;grid-template-columns:1fr 1fr;gap:8px}.pr-cat{display:flex;align-items:center;gap:8px;min-height:46px;padding:8px 12px;box-sizing:border-box;border:1.5px solid #BCE0FF;border-radius:14px;background:var(--card,#fff);color:var(--navy);font:700 13.5px/1.2 var(--font-body);text-align:left;cursor:pointer}.pr-cat span{flex:none;font-size:19px;line-height:1}.pr-cat.on{border-color:#0075E3;background:#E3F1FF;box-shadow:0 0 0 1px #0075E3}body.dark .pr-cat{background:#14234A;color:#fff;border-color:rgba(188,224,255,.25)}body.dark .pr-cat.on{background:rgba(0,117,227,.3);border-color:#3F9FF4}.pr-cat.scrivi{border-style:dashed}',
    '.pr-cat-nuova{grid-column:1/-1;display:flex;gap:8px}.pr-cat-nuova input{flex:1;min-width:0}.pr-cat-nuova button{flex:none;border:0;border-radius:14px;background:#0075E3;color:#fff;font:800 13.5px var(--font-body);padding:0 14px;cursor:pointer}',
    '.pr-ce-lab{display:block;margin:0 0 12px;font:600 13.5px var(--font-body);color:var(--muted);text-align:center}',
    'body.dark .pr-ce-lab{color:#C9D8EE}',
    '.pr-ce .pr-emo + .pr-ce-lab,.pr-ce .pr-col + .pr-ce-lab{margin-top:22px}',
    '.pr-ce-in{display:block;width:100%;box-sizing:border-box;text-align:center;font:600 16px var(--font-body)}',
    '.pr-ce-ta{resize:none;line-height:1.45}',
    '.pr-ce-prev{width:96px;height:96px;font-size:44px;border-radius:22px;margin:0 auto 22px}',
    '.pr-ce .pr-col{margin-bottom:22px}',
    '.pr-ce .pr-emo-b{background:transparent}',
    'body.dark .pr-ce .pr-emo-b{border-color:rgba(188,224,255,.22)}',
    'body.dark .pr-ce .pr-emo-b.on{border-color:#8CC6FF;box-shadow:0 0 0 2px rgba(140,198,255,.35)}',
    '.pr-ce-foto{margin:0}',
    '.pr-ce-foto svg{flex:none;color:var(--faint)}',
    'body.dark .pr-ce .pr-row-btn{background:rgba(255,255,255,.09)}',
    '.pr-ce-salva{display:block;width:100%;margin-top:28px;border:0;border-radius:50px;padding:16px 20px;',
      'background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.28)}',
    '.pr-ce-altro{display:block;margin:12px auto 0;border:0;background:transparent;padding:8px;cursor:pointer;',
      'font:700 13.5px var(--font-body);color:#0075E3}',
    'body.dark .pr-ce-altro{color:#8CC6FF}',

    /* ---- MODALITA' RIORDINA ---- */
    '.pr-barra{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin:28px 0 0;',
      'padding:12px 14px;border-radius:16px;background:rgba(0,117,227,.1);',
      'border:1px solid rgba(0,117,227,.35)}',
    '.pr-barra > span{flex:1;min-width:120px;font:500 12.5px var(--font-body);color:var(--navy)}',
    'body.dark .pr-barra > span{color:#fff}',
    '.pr-barra-b{border:0;background:transparent;color:var(--blue);font:700 12.5px var(--font-body);cursor:pointer}',
    '.pr-barra-ok{border:0;border-radius:99px;padding:8px 18px;background:var(--blue);color:#fff;',
      'font:800 12.5px var(--font-body);cursor:pointer}',
    /* Il tremolio dice «adesso si sposta», ed e' la stessa convenzione della schermata
       principale del telefono: non c'e' niente da imparare. */
    '.pr-sect-t{display:flex;align-items:center;justify-content:space-between;gap:12px}',
    '.pr-rio{flex:none;border:1px solid var(--line);background:var(--card,#fff);border-radius:99px;',
      'padding:7px 14px;font:700 11.5px var(--font-body);color:var(--blue);cursor:pointer}',
    '.pr-riordina .pr-rio{background:var(--blue);border-color:var(--blue);color:#fff}',
    '.pr-riordina .pr-row{scroll-snap-type:none}',
    '.pr-riordina .pr-piu{opacity:.45}',
    /* LE FRECCE, in fondo alla card e larghe da prendere col pollice: mezza card ciascuna.
       Un bersaglio piccolo in una fila che scorre e' un bersaglio che si manca. */
    '.pr-mov{display:none;position:absolute;left:8px;right:8px;bottom:8px;z-index:5;gap:8px}',
    '.pr-riordina .pr-card .pr-mov{display:flex}',
    '.pr-riordina .pr-piu .pr-mov{display:none}',
    '.pr-mov i{flex:1;height:42px;border-radius:12px;background:rgba(8,14,26,.88);color:#fff;',
      'font:700 24px/42px var(--font-body);font-style:normal;text-align:center}',
    /* Mentre si riordina la pillola della durata sparisce: le frecce le finiscono sopra, e
       due cose sovrapposte in fondo a una card sono due cose che non si toccano bene. */
    '.pr-riordina .pr-go{visibility:hidden}',
    '.pr-x{display:none;position:absolute;top:8px;left:8px;width:28px;height:28px;border-radius:50%;',
      'background:rgba(8,14,26,.82);color:#fff;font:700 13px/28px var(--font-body);text-align:center;z-index:5}',
    '.pr-riordina .pr-card .pr-x{display:block}',
    '.pr-riordina .pr-piu .pr-x{display:none}'
  ].join('\n');
  document.head.appendChild(st);
})();

/* In fondo alla scheda START, dopo tutto il resto: è il posto dove si arriva quando si è
   deciso cosa fare e si vuole solo cominciare. */
(function prGraft(){
  const tab = document.getElementById('tab-sveglia');
  if (!tab || document.getElementById('prHost')) return;
  const box = document.createElement('div');
  box.id = 'prHost';
  tab.appendChild(box);
})();

/* In modalita' riordino il tocco su una card non deve aprirne il foglio: le frecce e la ✕
   hanno i loro gestori, il resto della card non fa niente. L'ascoltatore sta sul PADRE perche'
   prPaint() riscrive tutto l'HTML delle due file a ogni ridisegno. */
(function prGesti(){
  const host = document.getElementById('prHost');
  if (!host) return;
  host.addEventListener('click', function(ev){
    if (!PR_MODO) return;
    const card = ev.target.closest ? ev.target.closest('.pr-card') : null;
    if (!card || card.classList.contains('pr-piu')) return;
    const t = ev.target.classList;
    if (t && (t.contains('pr-x') || ev.target.parentNode.classList.contains('pr-mov'))) return;
    ev.stopPropagation();
    ev.preventDefault();
  }, true);
})();

document.addEventListener('fl:tab', function(e){ if (e.detail === 'sveglia') setTimeout(prPaint, 260); });
setTimeout(prPaint, 2600);
