/* ===========================================================================================
   LA ROADMAP A LIVELLI (0.9.222)

   Andrea: «Applica la roadmap» diceva «Era già tutto al suo posto» e non mostrava niente. Chi
   non VEDE il percorso ricalcolato non crede che sia stato ricalcolato. Adesso:
     - nella vista «Roadmap» della scheda Mappa, sopra al sentiero, c'e' «La tua roadmap»: un
       livello per ogni passo e una tappa (milestone) per ogni orizzonte, da oggi fino a fra
       cinque anni, come le tappe di Duolingo. Oggi e questa settimana mostrano i passi; mese,
       anno e cinque anni si aprono toccando la tappa (una cosa alla volta, niente muro di passi);
     - «Applica la roadmap» sostituisce i passi ancora da fare con quelli nuovi (i passi gia'
       fatti restano), chiude la chat e porta qui: i livelli nuovi entrano con un'animazione.
   I dati sono gli orizzonti di sempre (orizzonti.js, fl_orizzonti): ozAnello / ozSpunta.
   =========================================================================================== */
const RML = { nuovi: {}, cambiati: {}, aperti: { oggi: true, settimana: true }, at: 0 };
const RML_ORDINE = ['oggi', 'settimana', 'mese', 'anno', 'cinque'];
const RML_NOMI = { oggi: 'Oggi', settimana: 'Questa settimana', mese: 'Questo mese', anno: 'Quest’anno', cinque: 'Fra cinque anni' };
const RML_ICO = { oggi: '🎯', settimana: '📅', mese: '🗓️', anno: '🏔️', cinque: '🏁' };
function rmlEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function rmlNorm(t){ return String(t || '').trim().toLowerCase().replace(/\s+/g, ' '); }
function rmlAnelli(){ return RML_ORDINE.map(function(k){ const a = (typeof ozAnello === 'function') ? ozAnello(k) : { testo: '', passi: [] }; return { k: k, testo: a.testo, passi: a.passi || [] }; }); }
function rmlVuota(){ return rmlAnelli().every(function(a){ return !a.testo && !a.passi.length; }); }

function rmlHtml(){
  if (rmlVuota()){
    return '<section class="rml rml-vuota-l"><div class="rml-h"><b>La tua roadmap</b></div><div class="rml-vuota"><p>La roadmap non c’è ancora. Il tuo agente personale la costruisce dal tuo sogno: i passi di oggi, della settimana, del mese, fino alla destinazione.</p>'
      + '<button type="button" class="cta" onclick="rmlCostruisci()">Costruiscila con il tuo agente personale</button></div></section>';
  }
  const an = rmlAnelli();
  /* il livello in corso: il primo passo non fatto, a partire da oggi */
  let corrente = null;
  an.forEach(function(a){ if (corrente) return; a.passi.forEach(function(p, j){ if (!corrente && !p.fatto) corrente = a.k + ':' + j; }); });
  const OFF = [0, 30, 48, 30, 0, -30, -48, -30];
  let n = 0;
  const corpo = an.map(function(a){
    if (!a.testo && !a.passi.length) return '';
    /* 0.9.305: un orizzonte che finisce dopo la data del sogno non e' sulla strada (ozVisibile, orizzonti.js) */
    if (typeof ozVisibile === 'function' && !ozVisibile(a.k)) return '';
    const fatti = a.passi.filter(function(p){ return p.fatto; }).length;
    const aperto = !!RML.aperti[a.k];
    const nuovaTappa = RML.cambiati[a.k] ? ' nuovo' : '';
    let h = '<div class="rml-tappa' + nuovaTappa + (a.k === 'cinque' ? ' meta' : '') + '" onclick="rmlApri(\'' + a.k + '\')" role="button">'
      + '<span class="rml-tappa-ico">' + RML_ICO[a.k] + '</span><div><small>' + RML_NOMI[a.k] + (a.passi.length ? ' · ' + fatti + (fatti === 1 ? ' passo fatto su ' : ' passi fatti su ') + a.passi.length : '') + '</small><b>' + rmlEsc(a.testo || 'Senza traguardo') + '</b></div>'
      + (a.passi.length ? '<svg class="rml-chev' + (aperto ? ' su' : '') + '" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>' : '') + '</div>';
    if (aperto && a.passi.length){
      h += '<div class="rml-livelli">' + a.passi.map(function(p, j){
        const id = a.k + ':' + j;
        const stato = p.fatto ? 'fatto' : (id === corrente ? 'corrente' : 'chiuso');
        const nuovo = RML.nuovi[rmlNorm(p.t)] ? ' nuovo' : '';
        const off = OFF[(n++) % OFF.length];
        return '<div class="rml-liv ' + stato + nuovo + '" style="--x:' + off + 'px;--d:' + (j * 90) + 'ms">'
          + (stato === 'corrente' ? '<span class="rml-fum">INIZIA</span>' : '')
          + '<button type="button" onclick="rmlTocca(\'' + a.k + '\',' + j + ')" aria-label="' + rmlEsc(p.t) + '">' + (p.fatto ? '✓' : (stato === 'corrente' ? '★' : (j + 1))) + '</button>'
          + '<p>' + rmlEsc(p.t) + '</p></div>';
      }).join('') + '</div>';
    }
    return h;
  }).join('');
  return '<section class="rml"><div class="rml-h"><b>La tua roadmap</b></div>'
    + '<p class="rml-p">Ogni livello è un passo. Ogni tappa è un traguardo sulla strada verso il sogno.</p>' + corpo + '</section>';
}
/* 0.9.308, Andrea: "La tua roadmap" nella Mappa (Pianifica tu) deve comparire ESATTAMENTE come nella Roadmap: l'autostrada
   verso il sogno, non un pannello blu scuro con un'altra grafica. Quando l'agente ha costruito la roadmap, sotto al foglio
   c'e' il titolo, centrato, e sotto il sentiero VERO (#mppSentiero di sentiero-mappa.js, lo stesso nodo della vista
   Roadmap: si sposta qui, non si copia). Senza roadmap resta l'invito a costruirla, chiaro e centrato. Tornando alla
   Roadmap (o spegnendo il blocco da Personalizza Mappa) il sentiero torna al suo posto. */
function rmlVistaMia(){ try{ return (typeof mppVistaCur === 'function') && mppVistaCur() === 'mia'; }catch(_){ return false; } }
function rmlSentieroQui(){
  if (!rmlVistaMia() || rmlVuota()) return false;
  const h = document.getElementById('mppRoadmap');
  return !!h && !h.classList.contains('scs-off');
}
function rmlSentieroPosto(){
  const tab = document.getElementById('tab-mappa'), h = document.getElementById('mppRoadmap'), sent = document.getElementById('mppSentiero');
  if (!tab || !sent) return;
  if (h && rmlSentieroQui()){
    if (sent.parentElement !== h) h.appendChild(sent);
    sent.classList.remove('mpp-via');
    return;
  }
  if (sent.parentElement === tab) return;
  /* a casa, con chi gli sta attaccato (la revisione prima, il piano e la stagione dopo), nell'ordine in cui sono */
  const mossa = document.getElementById('mppMossa');
  const ref = (mossa && mossa.parentElement === tab) ? mossa : null;
  const via = h ? Array.prototype.filter.call(h.children, function(c){ return !!c.id; }) : [sent];
  via.forEach(function(c){ tab.insertBefore(c, ref); });
  if (sent.parentElement !== tab) tab.insertBefore(sent, ref);
  let v = 'rotta'; try{ v = mppVistaCur(); }catch(_){ }
  sent.classList.toggle('mpp-via', v !== 'rotta');
}
function rmlPaint(){
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  /* 0.9.234, Andrea: una roadmap sola nella Roadmap (il sentiero). "La tua roadmap" si sposta nella
     Mappa, sotto al pannello di pianificazione, senza "Ricalcola". Il posto lo tiene Personalizza Mappa. */
  let h = document.getElementById('mppRoadmap');
  const fo = document.getElementById('mppFoglio');
  if (!h){ h = document.createElement('div'); h.id = 'mppRoadmap'; h.className = 'mpp-slot'; }
  if (!h.parentNode){ if (fo && fo.parentNode) fo.parentNode.insertBefore(h, fo.nextSibling); else tab.appendChild(h); try{ if (typeof scsOrdinaBlocchi === 'function') scsOrdinaBlocchi('mappa-mia'); }catch(_){ } }
  h.classList.toggle('mpp-via', !rmlVistaMia());
  const qui = rmlSentieroQui();
  h.classList.toggle('rml-strada', qui);
  if (qui){
    /* il titolo si scrive una volta: il resto dentro (il sentiero e chi lo segue) non si tocca */
    if (!h.firstElementChild || !h.firstElementChild.classList.contains('rml-testa')){
      Array.prototype.slice.call(h.children).forEach(function(c){ if (!c.id) c.remove(); });
      h.insertAdjacentHTML('afterbegin', '<h2 class="rml-testa">La tua roadmap</h2>');
    }
    rmlSentieroPosto();
  } else {
    rmlSentieroPosto();
    const html = rmlVuota() ? rmlHtml() : '';
    if (h.__h !== html || h.querySelector('.rml-testa')){ h.innerHTML = html; h.__h = html; }
  }
  try{ rmpPaint(); }catch(_){ }
}

/* =========================================================================================
   IL PIANO DELLA ROADMAP (0.9.234)
   Andrea: la scheda Mappa e' per chi si costruisce la strada da solo; la Roadmap ("l'autostrada
   verso il sogno") e' per chi non vuole improvvisare. In fondo al sentiero c'e' lo stesso pannello
   di pianificazione della Mappa, ma scritto dalla roadmap: Oggi = i passi di oggi; Domani = i passi
   che seguono, divisi sui giorni che restano fino alla fine dell'orizzonte (la settimana, poi il
   mese), cosi' si arriva in tempo. Di serie non si modifica e la scheda Note non c'e'; dalle
   Impostazioni del piano si puo' renderlo modificabile (righe tue sotto ai passi, e la scheda Note).
   ========================================================================================= */
const RMP = { tab: 'oggi' };
function rmpModificabile(){ try{ return localStorage.getItem('fl_rm_piano_mod') === '1'; }catch(_){ return false; } }
function rmpModificabileSet(on){ try{ localStorage.setItem('fl_rm_piano_mod', on ? '1' : '0'); }catch(_){ } rmpPaint(); try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ } }
function rmpGiorniA(k){
  const d = new Date(); d.setHours(0, 0, 0, 0);
  const fine = new Date(d);
  if (k === 'settimana'){ fine.setDate(d.getDate() + ((7 - d.getDay()) % 7)); }
  else if (k === 'mese'){ fine.setMonth(d.getMonth() + 1, 0); }
  else if (k === 'anno'){ fine.setMonth(11, 31); }
  else return 1;
  return Math.max(1, Math.round((fine - d) / 86400000));
}
/** I passi della roadmap per oggi e per domani: [{ k, j, t, fatto }]. */
function rmpPassi(){
  const an = rmlAnelli(); const di = function(k){ return (an.filter(function(a){ return a.k === k; })[0] || { passi: [] }).passi; };
  const oggi = di('oggi').map(function(p, j){ return { k: 'oggi', j: j, t: p.t, fatto: !!p.fatto }; });
  /* se oggi la roadmap non ha passi, il primo passo aperto della settimana (o del mese) e' quello di oggi */
  let resto = [];
  ['settimana', 'mese'].some(function(k){ const aperti = di(k).map(function(p, j){ return { k: k, j: j, t: p.t, fatto: !!p.fatto }; }).filter(function(x){ return !x.fatto && x.t; }); if (aperti.length){ resto = aperti.map(function(x){ x.giorni = rmpGiorniA(k); return x; }); return true; } return false; });
  if (!oggi.length && resto.length) oggi.push(resto.shift());
  /* domani: i passi che restano divisi sui giorni che mancano alla fine dell'orizzonte (domani compreso) */
  let domani = [];
  if (resto.length){ const g = Math.max(1, resto[0].giorni - (resto[0].giorni > 1 ? 1 : 0)); domani = resto.slice(0, Math.max(1, Math.ceil(resto.length / g))); }
  /* il calendario: gli stessi passi, a gruppi, sui giorni che seguono (7 giorni) */
  const giorni = [oggi, domani];
  let resto2 = resto.slice(domani.length);
  const quota = Math.max(1, domani.length || 1);
  for (let d = 2; d < 7 && resto2.length; d++){ giorni.push(resto2.slice(0, quota)); resto2 = resto2.slice(quota); }
  return { oggi: oggi, domani: domani, giorni: giorni };
}
/* LE IMPOSTAZIONI DEL PIANO DELLA ROADMAP (0.9.238): separate da quelle della Mappa.
   fl_rm_schede { via: [...] } (di serie la scheda Note e' spenta), fl_rm_oggi 'tutti'|'uno',
   fl_rm_domani { passi, fine }: Domani si apre dopo i passi di oggi e/o dopo la fine del lavoro. */
const RMP_SCHEDE = [['oggi', 'Oggi'], ['domani', 'Domani'], ['cal', 'Calendario'], ['note', 'Note']];
function rmpCfgLeggi(k, def){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? def : v; }catch(_){ return def; } }
function rmpCfgScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } rmpPaint(); try{ if (typeof ulImpPaint === 'function') ulImpPaint(); }catch(_){ } }
function rmpSchede(){ const c = rmpCfgLeggi('fl_rm_schede', { via: ['note'] }); const via = Array.isArray(c.via) ? c.via : ['note']; const l = RMP_SCHEDE.filter(function(x){ return via.indexOf(x[0]) < 0; }); return l.length ? l : [RMP_SCHEDE[0]]; }
function rmpSchedaMostra(k, on){ const c = rmpCfgLeggi('fl_rm_schede', { via: ['note'] }); let via = (Array.isArray(c.via) ? c.via : ['note']).filter(function(x){ return x !== k; }); if (!on) via.push(k); if (RMP_SCHEDE.length - via.length < 1){ toast('Almeno una scheda resta'); return; } rmpCfgScrivi('fl_rm_schede', { via: via }); }
function rmpSchedeRipristina(){ rmpCfgScrivi('fl_rm_schede', { via: ['note'] }); toast('Schede ripristinate'); }
function rmpOggiTutti(){ return rmpCfgLeggi('fl_rm_oggi', 'tutti') !== 'uno'; }
function rmpDomaniCond(){ const c = rmpCfgLeggi('fl_rm_domani', {}); return { passi: !!c.passi, fine: !!c.fine }; }
function rmpDomaniChiuso(P){
  const c = rmpDomaniCond();
  if (c.passi && P.oggi.some(function(x){ return !x.fatto; })) return 'Si apre quando hai fatto i passi di oggi.';
  if (c.fine){ let f = '18:00'; try{ if (typeof pnFineLavoro === 'function') f = pnFineLavoro(); }catch(_){ } const p = String(f).split(':'); const d = new Date(); d.setHours(+p[0] || 18, +p[1] || 0, 0, 0); if (Date.now() < d.getTime()) return 'Si apre alle ' + f + ', a fine lavoro.'; }
  return '';
}
function rmpImpHtml(){
  const c = rmpCfgLeggi('fl_rm_schede', { via: ['note'] }), via = Array.isArray(c.via) ? c.via : ['note'];
  const sw = function(on, onclick, label){ return '<button type="button" class="switch' + (on ? ' on' : '') + '" aria-label="' + label + '" onclick="' + onclick + '"></button>'; };
  const d = rmpDomaniCond(), mod = rmpModificabile(), tutti = rmpOggiTutti();
  return '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🗂️</span><div><b>Le schede</b><small>Scegli quali schede mostrare nel piano della Roadmap. Queste impostazioni valgono solo qui, non nella Mappa.</small></div></div>'
    + RMP_SCHEDE.map(function(x){ const on = via.indexOf(x[0]) < 0; return '<div class="blk-swrow"><div><b>' + x[1] + '</b></div>' + sw(on, "rmpSchedaMostra('" + x[0] + "'," + (on ? 'false' : 'true') + ")", 'Mostra la scheda ' + x[1]) + '</div>'; }).join('')
    + '<button type="button" class="ul-ripristina" onclick="rmpSchedeRipristina()">Ripristina le schede di partenza</button></div>'
    + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🛣️</span><div><b>Il piano della Roadmap</b><small>Di serie i passi li scrive la roadmap e non si possono cambiare: se li segui, arrivi in tempo.</small></div></div>'
    + '<div class="blk-swrow"><div><b>Voglio poterlo modificare</b><small>Accendilo per aggiungere le tue righe sotto ai passi della roadmap.</small></div>' + sw(mod, 'rmpModificabileSet(' + (mod ? 'false' : 'true') + ')', 'Il piano della Roadmap si puo modificare') + '</div></div>'
    + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">📝</span><div><b>Cosa mostrare nella scheda Oggi</b><small>Scegli se vedere tutti i passi di oggi o solo il prossimo da fare.</small></div></div>'
    + '<div class="ul-scelta"><button type="button" class="' + (tutti ? 'on' : '') + '" onclick="rmpCfgScrivi(\'fl_rm_oggi\',\'tutti\')"><b>Mostra tutti i passi</b><small>Vedi tutti i passi di oggi, uno sotto l’altro</small></button>'
    + '<button type="button" class="' + (tutti ? '' : 'on') + '" onclick="rmpCfgScrivi(\'fl_rm_oggi\',\'uno\')"><b>Mostra un passo alla volta</b><small>Vedi solo il prossimo passo: quando lo finisci, arriva quello dopo</small></button></div></div>'
    + '<div class="ul-card"><div class="ul-testa"><span class="ul-ico">🔒</span><div><b>Quando mostrare la scheda Domani</b><small>Se li lasci spenti tutti e due, i passi di domani si vedono sempre.</small></div></div>'
    + '<div class="blk-swrow"><div><b>Solo dopo i passi di oggi</b><small>La scheda Domani si apre quando hai finito i passi di oggi.</small></div>' + sw(d.passi, "rmpCfgScrivi('fl_rm_domani',{passi:" + (!d.passi) + ",fine:" + d.fine + "})", 'Domani dopo i passi di oggi') + '</div>'
    + '<div class="blk-swrow"><div><b>Solo dopo la fine del lavoro</b><small>La scheda Domani si apre all’ora in cui finisci di lavorare.</small></div>' + sw(d.fine, "rmpCfgScrivi('fl_rm_domani',{passi:" + d.passi + ",fine:" + (!d.fine) + "})", 'Domani dopo la fine del lavoro') + '</div></div>';
}
function rmpCalHtml(P){
  const nomi = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
  return '<p class="st-onelbl">I prossimi sette giorni</p>' + P.giorni.map(function(l, i){
    const d = new Date(Date.now() + i * 86400000);
    const tit = i === 0 ? 'Oggi' : (i === 1 ? 'Domani' : nomi[d.getDay()].charAt(0).toUpperCase() + nomi[d.getDay()].slice(1) + ' ' + d.getDate());
    return '<div class="rmp-cal-g"><b>' + tit + '</b>' + (l && l.length ? l.map(function(x){ return '<div class="rmp-cal-r' + (x.fatto ? ' fatta' : '') + '" onclick="rmlTocca(\'' + x.k + '\',' + x.j + ')" role="button">' + rmlEsc(x.t) + '</div>'; }).join('') : '<small>Nessun passo</small>') + '</div>';
  }).join('')
    + (typeof psApri === 'function' ? '<button type="button" class="rmp-prenota" onclick="psApri()">Pianifica la settimana</button>' : '');
}
/* 0.9.331, Andrea: "non voglio mai piu' di due o tre righe, e il testo deve essere chiaro": la spiegazione sta in un foglio */
function rmpPassiInfo(){
  try{ flVibra(8); }catch(_){ }
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="rmp-i-ico" aria-hidden="true">🗓️</span><h3>Come si dividono i passi</h3>'
    + '<p>Il Genio prende i passi che mancano a questo traguardo e li divide per i giorni che restano.</p><p>Così ogni giorno ne fai pochi, e arrivi in tempo.</p></div>');
}
function rmpPrenotaHtml(){
  const n = (typeof pkPuntiDomani === 'function') ? pkPuntiDomani().length : 0;
  return '<button type="button" class="rmp-prenota" onclick="pkPuntoApri()">'
    + '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4M12 13v4M10 15h4"/></svg>'
    + 'Prenota il punto' + (n ? ' <small>(' + n + ' già in calendario)</small>' : '') + '</button>';
}
function rmpRigaHtml(x, quando){
  const tocca = quando === 'oggi' && !x.fatto;
  return '<div class="mf-riga rmp-riga' + (x.fatto ? ' fatta' : '') + '">'
    + (quando === 'oggi'
        ? '<button type="button" class="mf-box' + (x.fatto ? ' on' : '') + '" ' + (tocca ? 'onclick="rmpSpunta(\'' + x.k + '\',' + x.j + ',this)"' : 'disabled') + ' aria-label="' + (x.fatto ? 'Fatto' : 'Segna come fatto') + '">' + (x.fatto ? '✓' : '') + '</button>'
        : '<span class="mf-box rmp-poi" aria-hidden="true"></span>')
    + '<div class="mf-t" onclick="rmlTocca(\'' + x.k + '\',' + x.j + ')" role="button">' + rmlEsc(x.t) + '</div></div>';
}
function rmpHtml(){
  if (rmlVuota()) return '<section class="rmp"><div class="rmp-testa"><b>Il piano della Roadmap</b></div><p class="rmp-p">Quando c’è la roadmap, qui trovi i passi di oggi e di domani, già scritti per arrivare in tempo.</p><button type="button" class="cta" onclick="rmlCostruisci()">Costruisci la roadmap con il tuo agente personale</button></section>';
  const mod = rmpModificabile(); const P = rmpPassi();
  const tabs = rmpSchede();
  if (!tabs.some(function(t){ return t[0] === RMP.tab; })) RMP.tab = 'oggi';
  const lucchetto = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>';
  let corpo = '';
  const chiuso = RMP.tab === 'domani' ? rmpDomaniChiuso(P) : '';
  if (RMP.tab === 'note'){
    corpo = (typeof mnVelociHtml === 'function' ? mnVelociHtml('roadmap') : '') + (typeof cvBoxHtml === 'function' ? cvBoxHtml() : '');
  } else if (RMP.tab === 'cal'){
    /* 0.9.286, Andrea: "la scheda Calendario della Roadmap e' diversa da quella di Pianifica tu e non ha la rotella".
       Adesso e' lo stesso calendario (calendario.js), con la rotella e i Turni da WhatsApp */
    corpo = typeof calCorpo === 'function' ? calCorpo({ dove: 'roadmap' }) : rmpCalHtml(P);
  } else if (chiuso){
    corpo = '<div class="rmp-chiuso">' + lucchetto + '<b>' + chiuso + '</b></div>';
  } else if (RMP.tab === 'oggi' && typeof sdCorrente === 'function'){
    /* 0.9.278, Andrea: "deve mostrare massimo una task di oggi: il prossimo livello della mappa. Se lo completo va in
       Completate e compare il successivo". La scheda Oggi e' la mappa vista da vicino. */
    let nd = null; try{ nd = sdCorrente().nodo; }catch(_){ }
    let fatte = []; try{ fatte = sdFatteOggi(); }catch(_){ }
    corpo = '<p class="st-onelbl">Il prossimo passo</p>'
      + (nd ? '<div class="mf-lista"><div class="mf-riga rmp-riga rmp-tappa"><span class="mf-box rmp-ico" aria-hidden="true">' + ((typeof SD_ICO !== 'undefined' && SD_ICO[nd.tipo]) || '') + '</span>'
          + '<div class="mf-t" onclick="rmpTappaVia()" role="button">' + rmlEsc(sdNomeTappa(nd)) + '</div>'
          + '<button type="button" class="rmp-via" onclick="rmpTappaVia()">Inizia</button></div></div>'
        : '<p class="rmp-p">Per oggi hai fatto tutte le tappe.</p>')
      + (fatte.length ? '<details class="st-fatte rmp-fatte"' + (RMP.fatteAperte !== false ? ' open' : '') + ' ontoggle="RMP.fatteAperte=this.open"><summary><b>Completate oggi</b><small>' + fatte.length + '</small></summary><div class="mf-lista">'
          + fatte.map(function(x){ return '<div class="mf-riga rmp-riga fatta"><span class="mf-box on">✓</span><div class="mf-t">' + rmlEsc(sdNomeTappa(x)) + '</div></div>'; }).join('') + '</div></details>' : '');
  } else {
    let l = P[RMP.tab] || [];
    if (RMP.tab === 'oggi' && !rmpOggiTutti()){ const primo = l.filter(function(x){ return !x.fatto; })[0]; l = primo ? [primo] : l.slice(-1); }
    const iso = (typeof mtKey === 'function') ? mtKey(Date.now() + (RMP.tab === 'domani' ? 86400000 : 0)) : '';
    const mie = mod && typeof stRigheDi === 'function' ? stRigheDi(iso).filter(function(r){ return !l.some(function(x){ return (typeof stNormRiga === 'function' ? stNormRiga(x.t) === stNormRiga(r) : x.t === r); }); }) : [];
    corpo = '<p class="st-onelbl rmp-lbl">' + (RMP.tab === 'oggi' ? 'I passi di oggi' : 'I passi di domani') + '<button type="button" class="rmp-i" onclick="rmpPassiInfo()" aria-label="Come si dividono i passi">i</button></p>'
      + (l.length ? '<div class="mf-lista">' + l.map(function(x){ return rmpRigaHtml(x, RMP.tab); }).join('') + '</div>' : '<p class="rmp-p">' + (RMP.tab === 'oggi' ? 'Per oggi la roadmap non ha passi: domani si riparte.' : 'I passi di domani arrivano quando finisci quelli di questa settimana.') + '</p>')
      + (mod ? '<p class="st-onelbl" style="margin-top:14px">Le tue righe</p><div class="mf-lista rmp-mie">' + mie.map(function(r){ return '<div class="mf-riga"><span class="mf-box vuota"></span><div class="mf-t">' + rmlEsc(r) + '</div></div>'; }).join('')
          + '<div class="mf-riga mf-nuova"><span class="mf-box vuota"></span><div class="mf-t" contenteditable="true" data-ph="Aggiungi una riga tua" onkeydown="rmpTasto(event,this,\'' + iso + '\')" onblur="rmpAggiungi(this,\'' + iso + '\')"></div></div></div>' : '')
      /* 0.9.242: PRENOTA IL PUNTO (prenota.js), i passi di domani a un'ora precisa del calendario */
      + (RMP.tab === 'domani' && typeof pkPuntoApri === 'function' ? rmpPrenotaHtml() : '');
  }
  return '<section class="st-sec mf rmp">'
    + '<div class="rmp-testa"><b>Il piano della Roadmap</b>' + (mod ? '' : '<span class="rmp-pill">' + lucchetto + 'Scritto dalla roadmap</span>') + '</div>'
    + '<div class="st-note st-tutto mf-note">'
    +   '<div class="mf-head"><div class="mf-tabs">' + tabs.map(function(t){ return '<button type="button" class="st-daytab' + (RMP.tab === t[0] ? ' on' : '') + '" onclick="rmpTab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('') + '</div>'
    +     '<button type="button" class="mf-dots" onclick="if(typeof ulImpApri===\'function\')ulImpApri(\'roadmap\')" aria-label="Impostazioni della Roadmap">⋯</button></div>'
    +   '<div class="mf-corpo">' + corpo + '</div>'
    + '</div></section>';
}
function rmpPaint(){
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  let h = document.getElementById('mppPianoRm');
  const sent = document.getElementById('mppSentiero');
  if (!h){ h = document.createElement('div'); h.id = 'mppPianoRm'; h.className = 'mpp-slot'; }
  if (sent && sent.parentNode && h.previousElementSibling !== sent) sent.parentNode.insertBefore(h, sent.nextSibling);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  h.classList.toggle('mpp-via', v !== 'rotta');
  /* si aspetta solo mentre si scrive una riga (0.9.237: prima bastava il fuoco sul pulsante della scheda
     per non ridisegnare, e Oggi/Domani sembravano bloccate) */
  if (document.activeElement && h.contains(document.activeElement) && document.activeElement.isContentEditable) return;
  h.innerHTML = '<div class="mpp-page">' + rmpHtml() + '</div>';
  try{ if (RMP.tab === 'note' && typeof mnRigheAggancia === 'function') mnRigheAggancia(); }catch(_){ }
  try{ if (RMP.tab === 'cal' && typeof calDopo === 'function') calDopo(); }catch(_){ }
}
function rmpTappaVia(){ try{ const c = sdCorrente(); if (c && c.nodo) sdTapVia(c.nodo.id); }catch(_){ } }
function rmpTab(k){ RMP.tab = k; try{ flVibra(6); }catch(_){ } rmpPaint(); }
function rmpSpunta(k, j, btn){
  const riga = btn && btn.closest ? btn.closest('.mf-riga') : null;
  const fai = function(){ if (typeof ozSpunta === 'function') ozSpunta(k, j); rmlPaint(); };
  if (typeof stChiedi === 'function'){
    const p = ozAnello(k).passi[j] || {};
    stChiedi({ titolo: 'L’hai fatto davvero?', riga: p.t || '', nota: 'Spunta solo il passo che hai finito: la data d’arrivo si muove con lui.', no: 'Non ancora', si: 'Sì, fatto',
      fn: function(){ if (riga && typeof stAnimaFatta === 'function') stAnimaFatta(riga, fai); else fai(); } });
    return;
  }
  fai();
}
function rmpTasto(e, el, iso){ if (e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); rmpAggiungi(el, iso); } }
function rmpAggiungi(el, iso){
  const t = String(el.textContent || '').replace(/\s+/g, ' ').trim(); if (!t) return;
  try{ const r = (typeof stRigheDi === 'function') ? stRigheDi(iso) : []; localStorage.setItem('fl_notes_' + iso, r.concat([t]).join('\n')); if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
  el.textContent = ''; el.blur(); rmpPaint();
}
function rmlApri(k){ RML.aperti[k] = !RML.aperti[k]; try{ flVibra(8); }catch(_){ } rmlPaint(); }
function rmlTocca(k, j){
  const p = ozAnello(k).passi[j]; if (!p) return;
  try{ flVibra(10); }catch(_){ }
  if (typeof inSheet !== 'function') return;
  if (p.fatto){
    inSheet('<div class="rml-sh"><b>' + rmlEsc(p.t) + '</b><p>Livello fatto' + (p.il ? ' il ' + rmlEsc(p.il.split('-').reverse().join('/')) : '') + '.</p><button type="button" class="prc-link" onclick="inSheetChiudi();ozSpunta(\'' + k + '\',' + j + ');rmlPaint()">Non l’ho fatto davvero: riaprilo</button></div>');
    return;
  }
  const min = (/\((\d+)\s*min/i.exec(p.t) || [])[1];
  inSheet('<div class="rml-sh"><small>' + RML_NOMI[k] + '</small><b>' + rmlEsc(p.t) + '</b>'
    + '<button type="button" class="cta" onclick="inSheetChiudi();rmlFocus(\'' + k + '\',' + j + ')">Fallo adesso' + (min ? ', ' + min + ' minuti' : '') + ' in Full Focus</button>'
    + '<button type="button" class="prc-link" onclick="inSheetChiudi();rmlFatto(\'' + k + '\',' + j + ')">L’ho già fatto</button></div>');
}
function rmlFatto(k, j){
  if (typeof ozSpunta === 'function') ozSpunta(k, j);
  try{ flVibra([10, 30, 10]); }catch(_){ }
  rmlPaint();
}
function rmlFocus(k, j){
  const p = ozAnello(k).passi[j]; if (!p) return;
  const min = +((/\((\d+)\s*min/i.exec(p.t) || [])[1]) || 25;
  goId('s-home'); try{ switchTab('sveglia'); }catch(_){ }
  setTimeout(function(){ try{ const f = ffPref(); f.minutes = Math.min(90, Math.max(5, min)); f.intent = String(p.t).replace(/\s*\(\d+\s*min[^)]*\)\s*$/i, ''); ffSavePref(); if (typeof stGoFocus === 'function') stGoFocus(); else if (typeof ffOpen === 'function') ffOpen(); }catch(_){ } }, 350);
}
function rmlCostruisci(){ if (typeof agNuovaConversazione === 'function') agNuovaConversazione('Costruisci la mia roadmap'); }
function rmlChiediAgente(){ if (typeof agNuovaConversazione === 'function') agNuovaConversazione('Ricalcola la mia roadmap partendo da dove sono adesso.'); }

/**
 * Applica la roadmap proposta dall'agente: per ogni orizzonte il traguardo nuovo, i passi gia'
 * fatti restano, quelli ancora da fare diventano quelli nuovi. Torna { nuovi, tolti, cambiati }.
 */
function rmlApplica(piano){
  const out = { nuovi: 0, tolti: 0, cambiati: 0 };
  RML.nuovi = {}; RML.cambiati = {};
  RML_ORDINE.forEach(function(k){
    const x = piano && piano[k];
    if (!x || !x.testo) return;
    const mio = ozAnello(k);
    const fatti = (mio.passi || []).filter(function(p){ return p.fatto; });
    const vecchiAperti = {}; (mio.passi || []).forEach(function(p){ if (!p.fatto) vecchiAperti[rmlNorm(p.t)] = 1; });
    const visti = {}; fatti.forEach(function(p){ visti[rmlNorm(p.t)] = 1; });
    const aperti = [];
    (Array.isArray(x.passi) ? x.passi : []).forEach(function(t){
      const key = rmlNorm(t); if (!key || visti[key]) return;
      visti[key] = 1; aperti.push({ t: (typeof flAccenti === 'function' ? flAccenti(String(t)) : String(t)).slice(0, 160), fatto: false, il: '' });
      if (!vecchiAperti[key]){ RML.nuovi[key] = 1; out.nuovi++; } else delete vecchiAperti[key];
    });
    out.tolti += Object.keys(vecchiAperti).length;
    const testo = (typeof flAccenti === 'function' ? flAccenti(String(x.testo)) : String(x.testo)).slice(0, 160);
    if (rmlNorm(testo) !== rmlNorm(mio.testo)){ RML.cambiati[k] = 1; out.cambiati++; }
    ozSalvaAnello(k, { testo: testo, passi: fatti.concat(aperti) });
  });
  RML.at = Date.now();
  RML.aperti.oggi = true; RML.aperti.settimana = true;
  /* le animazioni dei livelli nuovi durano un giro: poi tornano normali */
  setTimeout(function(){ RML.nuovi = {}; RML.cambiati = {}; }, 6000);
  return out;
}
/** Porta l'utente davanti alla roadmap aggiornata. */
function rmlMostra(){
  goId('s-home');
  try{ switchTab('mappa'); }catch(_){ }
  /* 0.9.234: "La tua roadmap" sta nella Mappa, sotto al pannello di pianificazione */
  try{ if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ }
  setTimeout(function(){
    rmlPaint();
    const h = document.getElementById('mppRoadmap');
    if (h){ try{ h.scrollIntoView({ behavior: 'smooth', block: 'start' }); }catch(_){ h.scrollIntoView(); } }
  }, 350);
}

/* l'aggancio: la Mappa si ridisegna, la roadmap con lei; e la vista la mostra solo in «Roadmap» */
(function(){
  if (typeof mppPaint === 'function'){ const v = mppPaint; window.mppPaint = mppPaint = function(){ const r = v.apply(this, arguments); try{ rmlPaint(); }catch(_){ } return r; }; }
  if (typeof mppApplicaVista === 'function'){ const v2 = mppApplicaVista; window.mppApplicaVista = mppApplicaVista = function(){ const r = v2.apply(this, arguments); const h = document.getElementById('mppRoadmap'); if (h) h.classList.toggle('mpp-via', mppVistaCur() !== 'mia'); const pr = document.getElementById('mppPianoRm'); if (pr) pr.classList.toggle('mpp-via', mppVistaCur() !== 'rotta');
    /* 0.9.308: cambiando vista il sentiero va dove serve (dentro «La tua roadmap» o nella Roadmap) */
    try{ if (h && h.classList.contains('rml-strada') !== rmlSentieroQui()) rmlPaint(); else rmlSentieroPosto(); }catch(_){ }
    return r; }; }
  if (typeof ozSpunta === 'function'){ const v3 = ozSpunta; window.ozSpunta = ozSpunta = function(){ const r = v3.apply(this, arguments); try{ rmlPaint(); }catch(_){ } return r; }; }
  const st = document.createElement('style');
  st.textContent = [
    '#mppRoadmap{padding:0 16px;margin:8px 0 18px}.rml{padding:18px 16px 20px;border-radius:24px;background:linear-gradient(180deg,#0F2041,#14234A);color:#fff;box-shadow:0 12px 28px rgba(0,20,60,.2)}',
    /* 0.9.308: niente pannello scuro. Il titolo al centro, staccato dal foglio, e sotto il sentiero com'e' nella Roadmap
       (stessa larghezza: #mppRoadmap senza padding suo, come il sentiero che sta diretto nella scheda) */
    '#mppRoadmap.rml-strada{padding:0;margin:36px 0 0}',
    /* 0.9.308: sotto al foglio le pillole del sentiero ripetono quelle dell'intestazione: qui no */
    '#mppRoadmap .sd-top{display:none}',
    '.rml-testa{margin:0 0 6px;text-align:center;font:800 24px/1.2 var(--font-display);color:var(--navy,#14234A)}body.dark .rml-testa{color:#fff}',
    '#mppRoadmap .rml-vuota-l{margin-top:28px;padding:0;border-radius:0;background:none;box-shadow:none;color:var(--navy,#14234A);text-align:center}',
    '#mppRoadmap .rml-vuota-l .rml-h{justify-content:center}#mppRoadmap .rml-vuota-l .rml-h b{font-size:24px;color:var(--navy,#14234A)}body.dark #mppRoadmap .rml-vuota-l .rml-h b{color:#fff}',
    '#mppRoadmap .rml-vuota-l .rml-vuota p{color:var(--muted,#5B6B86);text-align:center}body.dark #mppRoadmap .rml-vuota-l .rml-vuota p{color:#B9C7E2}',
    '#mppRoadmap .rml-vuota-l .cta{border-radius:50px;background:#0075E3;color:#fff}',
    '.rml-h{display:flex;align-items:center;justify-content:space-between}.rml-h b{font:800 21px var(--font-display);color:#fff}.rml-h button{border:1px solid rgba(255,255,255,.3);border-radius:99px;background:transparent;color:#fff;padding:7px 14px;font:700 13px var(--font-body);cursor:pointer}',
    '.rml-p{margin:6px 0 14px;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.7)}',
    '.rml-vuota p{margin:10px 0 14px;font:500 14px/1.55 var(--font-body);color:rgba(255,255,255,.8)}.rml-vuota .cta{width:100%}',
    '.rml-tappa{display:flex;align-items:center;gap:12px;margin:14px 0 6px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);cursor:pointer}.rml-tappa > div{flex:1;min-width:0}',
    '.rml-tappa-ico{font-size:26px;flex:none}.rml-tappa small{display:block;font:800 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.rml-tappa b{display:block;margin-top:3px;font:800 15px/1.35 var(--font-body);color:#fff}',
    '.rml-tappa.meta{background:linear-gradient(135deg,rgba(140,198,255,.22),rgba(140,198,255,.06));border-color:rgba(140,198,255,.5)}.rml-tappa.meta small{color:#8CC6FF}',
    '.rml-chev{flex:none;color:rgba(255,255,255,.7);transition:transform .2s}.rml-chev.su{transform:rotate(180deg)}',
    '.rml-tappa.nuovo{animation:rmlTappa 1.4s ease both}@keyframes rmlTappa{0%{box-shadow:0 0 0 0 rgba(140,198,255,.8)}60%{box-shadow:0 0 0 10px rgba(140,198,255,0)}100%{box-shadow:none}}',
    '.rml-livelli{display:flex;flex-direction:column;align-items:center;gap:26px;padding:26px 0 6px}',
    '.rml-liv{position:relative;display:flex;flex-direction:column;align-items:center;transform:translateX(var(--x));max-width:210px;text-align:center}',
    '.rml-liv button{width:62px;height:58px;border-radius:50%;border:0;font:800 20px var(--font-body);cursor:pointer;background:#3A4A6B;color:rgba(255,255,255,.75);box-shadow:0 6px 0 #26334F}',
    '.rml-liv.fatto button{background:#FFC93C;color:#7A4E00;box-shadow:0 6px 0 #D19A12}.rml-liv.corrente button{background:#0075E3;color:#fff;box-shadow:0 6px 0 #00509E;animation:rmlPulsa 1.6s ease-in-out infinite}',
    '@keyframes rmlPulsa{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}',
    '.rml-liv p{margin:8px 0 6px;font:600 12.5px/1.4 var(--font-body);color:rgba(255,255,255,.85)}.rml-liv.chiuso p{color:rgba(255,255,255,.6)}',
    '.rml-fum{position:absolute;top:-28px;z-index:1;padding:5px 10px;border-radius:10px;background:#fff;color:#0075E3;font:800 11px var(--font-body);letter-spacing:.08em;white-space:nowrap}',
    '.rml-liv.nuovo{animation:rmlEntra .7s cubic-bezier(.2,1.4,.4,1) both;animation-delay:var(--d)}@keyframes rmlEntra{0%{opacity:0;transform:translateX(var(--x)) scale(.4)}100%{opacity:1;transform:translateX(var(--x)) scale(1)}}',
    '.rml-sh{padding:6px 4px 4px;text-align:center}.rml-sh small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}.rml-sh b{display:block;margin:6px 0 16px;font:800 18px/1.4 var(--font-body);color:var(--navy)}body.dark .rml-sh b{color:#fff}.rml-sh p{margin:0 0 12px;color:var(--muted)}.rml-sh .cta{width:100%}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#mppPianoRm{padding:0 16px;margin:10px 0 14px}#mppPianoRm .mpp-page{padding:0}',
    '.rmp-testa{display:flex;flex-direction:column;align-items:center;gap:10px;margin:0 2px 16px;text-align:center}.rmp-testa b{text-align:center;font:800 18px var(--font-display,var(--font-body));color:var(--navy,#14234A)}',
    '.rmp-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 10px;border-radius:99px;background:#EAF3FE;color:#0B4F9C;font:700 11.5px var(--font-body)}',
    '.rmp-p,.rmp-nota{font:500 13.5px/1.45 var(--font-body);color:var(--muted,#5B6B86);margin:6px 2px 10px}.rmp-nota{font-size:12.5px;margin-top:10px}',
    '.rmp .mf-t[role=button]{cursor:pointer}.rmp-poi{border-style:dashed!important;opacity:.55}.rmp .mf-box[disabled]{cursor:default}',
    '#mppPianoRm .st-note{margin:0}',
    '.rmp-cal-g{padding:10px 2px;border-bottom:1px solid var(--line,#E5ECF6)}.rmp-cal-g>b{display:block;font:800 13.5px var(--font-body);color:var(--navy,#14234A);margin-bottom:4px}.rmp-cal-g small{font:500 12.5px var(--font-body);color:var(--muted,#5B6B86)}',
    '.rmp-cal-r{font:500 14px/1.45 var(--font-body);color:var(--navy,#14234A);padding:3px 0 3px 12px;border-left:3px solid #0075E3;margin:4px 0;cursor:pointer}.rmp-cal-r.fatta{text-decoration:line-through;color:var(--muted,#5B6B86);border-left-color:#9FB3D6}',
    '.rmp-chiuso{display:flex;align-items:center;gap:10px;padding:18px 6px;color:var(--muted,#5B6B86)}.rmp-chiuso b{font:600 14px/1.45 var(--font-body)}'
  ].join('');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '.rmp-lbl{display:flex;align-items:center;justify-content:center;gap:8px}.rmp-i{width:20px;height:20px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1.5px solid var(--line);border-radius:50%;background:none;color:var(--muted);font:800 11px var(--font-body);cursor:pointer}.rmp-i-ico{display:block;font-size:40px;line-height:1;text-align:center;margin:4px 0 10px}';
  document.head.appendChild(st);
})();
