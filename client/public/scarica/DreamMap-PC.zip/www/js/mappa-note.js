/* ===========================================================================================
   LE NOTE (0.9.229): la replica di Samsung Notes fatta con Lovable (repo perfect-notes-replica,
   build in www/note/ con build-app.sh) dentro DreamMap.

   - s-note: le note a schermo intero, in un iframe sulla stessa origine. Le note vivono nel
     telefono, in localStorage `fl_note_v1` ([{ id, title, text, html, date, folder, favorite, mod }]).
   - Nella Mappa, sopra a "Le tue pagine", la sezione "Le tue note":
       1. LE NOTE VELOCI: un pannello dove si scrive (o si detta col microfono rosa, dettatura.js)
          un pensiero per riga; ogni riga diventa un punto della nota "💡 Idee e note". Il pulsante
          in alto a destra la apre a schermo intero (0.9.311, vedi mnIdee...).
       2. i riquadri: il primo e' "+ Nuova nota" (se non ci sono note) o l'ultima nota toccata; il
          secondo e' IL CAVEAU (ulisse.js): tenendo premuta una nota e trascinandola sul caveau, la
          nota va al sicuro li' e sparisce dalle note. Poi le altre note recenti e "Tutte le note".
   =========================================================================================== */
const MN_KEY = 'fl_note_v1';
const MN_INBOX = 'inbox';
const MN = { aperto: false, ritorno: '', drag: null };
const MN_MESI = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
function mnData(t){ const d = new Date(t || Date.now()); return d.getDate() + ' ' + MN_MESI[d.getMonth()]; }
function mnLista(){ try{ const l = JSON.parse(localStorage.getItem(MN_KEY) || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; } }
function mnSalva(l){ try{ localStorage.setItem(MN_KEY, JSON.stringify(l)); mnMarca(); }catch(_){ toast('Il telefono è pieno: togli qualche nota'); } }
/* 0.9.311: quando la Mappa ha toccato le note per ultima. La replica (notes-provider) preferisce la sua copia in IndexedDB
   se ha una nota piu' recente: una nota TOLTA da qui non cambia nessuna data, e senza questo segno sarebbe tornata. */
function mnMarca(){ try{ localStorage.setItem(MN_KEY + '_at', String(Date.now())); }catch(_){ } }
function mnEsc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function mnOrdinate(){ const i = mnInbox(); return mnLista().filter(function(n){ return n && (!i || n.id !== i.id); }).sort(function(a, b){ return (b.mod || 0) - (a.mod || 0); }); }

/* ---------- LE NOTE VELOCI SONO UNA NOTA SOLA: "💡 Idee e note" (0.9.311, Andrea) ----------
   Il pulsante che espande il pannello apre sempre la stessa nota nella replica di Samsung Notes.
   LA CAUSA VERA della "nota nuova ogni volta": mnInboxScrivi cancellava la nota appena restava senza righe (basta portare
   l'ultima riga nel caveau) e noApri la ricreava da capo con la riga inventata "Il primo pensiero"; in piu' ogni riga scritta
   dalla Mappa riscriveva titolo, cartella e tutto l'html da zero, perdendo cio' che l'utente aveva formattato nella nota.
   Adesso: la nota si crea una volta sola e non si cancella mai; se c'e' gia' una nota con quel titolo (le note portate da
   Samsung Notes) e' lei; una riga cambiata tocca solo quella riga dell'html (mnInboxScrivi), il resto non si muove.
   I doppioni "Note veloci" si uniscono in lei una volta (mnIdeeMigra): righe e immagini che mancano si aggiungono in fondo, e
   la nota originale resta nel cestino per 30 giorni. La stessa nota e' la fonte dell'esercizio Taglia (mnIdeePerTaglia). */
const MN_IDEE_TITOLO = '💡 Idee e note', MN_IDEE_KEY = 'fl_note_idee_id';
function mnTitoloNorm(t){ return String(t || '').toLowerCase().replace(/[^a-z0-9àèéìòù ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
function mnTitoloVeloci(t){ return /^note veloci( \d+)?$/.test(mnTitoloNorm(t)); }
function mnPiuRecenti(a, b){ return (b.mod || 0) - (a.mod || 0); }
function mnIdeeTrova(l){
  let id = ''; try{ id = localStorage.getItem(MN_IDEE_KEY) || ''; }catch(_){ }
  const per = id ? l.filter(function(x){ return x && x.id === id; })[0] : null; if (per) return per;
  const pari = l.filter(function(x){ return x && mnTitoloNorm(x.title) === 'idee e note'; }).sort(mnPiuRecenti)[0]; if (pari) return pari;
  return l.filter(function(x){ return x && x.id === MN_INBOX; })[0] || l.filter(function(x){ return x && mnTitoloVeloci(x.title); }).sort(mnPiuRecenti)[0] || null;
}
function mnInbox(){ return mnIdeeTrova(mnLista()); }

/* -- le righe della nota, sull'html vero (in memoria: l'html si riscrive solo quando una riga cambia) -- */
const MN_BLOCCO = 'div,p,li,h1,h2,h3,h4,h5,h6,blockquote,pre';
function mnDaTesto(t){
  return String(t || '').split('\n').map(function(r){
    const box = /^([☐☑])\s?/.exec(r);
    if (box) return '<div class="nc-item" data-c="' + (box[1] === '☑' ? '1' : '0') + '">' + mnEsc(r.slice(box[0].length)) + '</div>';
    return '<div>' + (mnEsc(r.replace(/^•\s*/, '')) || '<br>') + '</div>';
  }).join('');
}
/* il testo fuori dai blocchi e le righe separate da un a-capo diventano blocchi: una riga, un blocco */
function mnSistema(box, d){
  const inBlocco = function(c){ return c.nodeType === 1 && c.matches(MN_BLOCCO + ',ul,ol'); };
  const figli = Array.prototype.slice.call(box.childNodes);
  if (box === d.body || figli.some(inBlocco)){
    let run = null;
    figli.forEach(function(c){
      if (inBlocco(c)){ run = null; mnSistema(c, d); return; }
      if (c.nodeType === 1 && c.tagName === 'BR'){ run = null; return; }
      if (c.nodeType === 3 && !c.nodeValue.trim() && !run) return;
      if (!run){ run = d.createElement('div'); box.insertBefore(run, c); }
      run.appendChild(c);
    });
  }
  if (box !== d.body && /^(DIV|P)$/.test(box.tagName) && !box.classList.contains('nc-item') && box.querySelector(':scope > br') && !figli.some(inBlocco)){
    const pezzi = [[]]; figli.forEach(function(c){ if (c.nodeType === 1 && c.tagName === 'BR') pezzi.push([]); else pezzi[pezzi.length - 1].push(c); });
    const pieni = pezzi.filter(function(p){ return p.some(function(c){ return c.nodeType === 1 || c.nodeValue.trim(); }); });
    if (pieni.length > 1){ pieni.forEach(function(p){ const x = box.cloneNode(false); p.forEach(function(c){ x.appendChild(c); }); box.parentNode.insertBefore(x, box); }); box.remove(); }
  }
}
function mnDoc(n){
  const d = new DOMParser().parseFromString('<!doctype html><body>' + (n.html || (n.text ? mnDaTesto(n.text) : '')) + '</body>', 'text/html');
  mnSistema(d.body, d);
  return d;
}
function mnRigaTesto(el){ return String(el.textContent || '').replace(/\u200B/g, '').replace(/\s+/g, ' ').trim().replace(/^[•\-]\s*/, ''); }
function mnBlocchi(body){
  return Array.prototype.slice.call(body.querySelectorAll(MN_BLOCCO))
    .filter(function(el){ return !el.querySelector(MN_BLOCCO) && mnRigaTesto(el); })
    .map(function(el){ return { el: el, t: mnRigaTesto(el) }; });
}
/* lo stesso testo che scrive la replica (htmlToText in notes-data.ts): anteprima e ricerca */
function mnHtmlTesto(root){
  let out = ''; const aCapo = function(){ if (out && out.slice(-1) !== '\n') out += '\n'; };
  const giro = function(c){
    if (c.nodeType === 3){ out += String(c.nodeValue || '').replace(/\u200B/g, ''); return; }
    if (c.nodeType !== 1) return;
    const tag = c.tagName;
    if (tag === 'BR'){ out += '\n'; return; }
    if (tag === 'IMG' || /^svg$/i.test(tag)) return;
    const bl = /^(DIV|P|LI|UL|OL|H[1-6]|BLOCKQUOTE|PRE)$/.test(tag);
    if (bl) aCapo();
    if (c.classList.contains('nc-item')) out += c.getAttribute('data-c') === '1' ? '☑ ' : '☐ ';
    if (tag === 'LI'){ const u = c.parentElement; if (u && u.tagName === 'OL') out += (Array.prototype.filter.call(u.children, function(x){ return x.tagName === 'LI'; }).indexOf(c) + 1) + '. '; else out += '• '; }
    c.childNodes.forEach(giro);
    if (bl) aCapo();
  };
  root.childNodes.forEach(giro);
  return out.replace(/\n+$/, '');
}
function mnFissaHtml(n, d){
  if (!d.body.textContent.trim() && !d.body.querySelector('img')) d.body.innerHTML = '';
  n.html = d.body.innerHTML; n.text = mnHtmlTesto(d.body); n.date = mnData(); n.mod = Date.now();
}
function mnIdeeNuovaId(){ return mnCestino().some(function(x){ return x.id === MN_INBOX; }) ? 'idee-' + Date.now() : MN_INBOX; }
function mnIdeeNuova(){ return { id: mnIdeeNuovaId(), title: MN_IDEE_TITOLO, text: '', html: '', date: mnData(), folder: 'Cartelle', mod: Date.now() }; }
function mnIdeeRicorda(n){ try{ localStorage.setItem(MN_IDEE_KEY, n.id); }catch(_){ } }

/* -- i doppioni "Note veloci", e il vecchio titolo -- */
function mnIdeeMigra(){
  const l = mnLista();
  const n = mnIdeeTrova(l); if (!n) return null;
  const doppi = l.filter(function(x){ return x && x !== n && (x.id === MN_INBOX || mnTitoloVeloci(x.title)); });
  mnIdeeRicorda(n);
  const rinomina = mnTitoloVeloci(n.title);
  if (!doppi.length && !rinomina) return n;
  if (rinomina){
    n.title = MN_IDEE_TITOLO; if (n.folder === 'Note veloci') n.folder = 'Cartelle';
    /* la riga "Il primo pensiero" non l'ha scritta l'utente: la metteva noApri su una nota vuota */
    const d0 = mnDoc(n), finta = mnBlocchi(d0.body).filter(function(x){ return x.t === 'Il primo pensiero'; });
    if (finta.length){ finta.forEach(function(x){ mnRigaVia(x.el, d0.body); }); mnFissaHtml(n, d0); }
  }
  if (doppi.length){
    const d = mnDoc(n), ci = { 'Il primo pensiero': 1 };
    mnBlocchi(d.body).forEach(function(b){ ci[b.t] = 1; });
    doppi.slice().sort(function(a, b){ return (a.mod || 0) - (b.mod || 0); }).forEach(function(x){
      const dx = mnDoc(x);
      mnBlocchi(dx.body).forEach(function(b){
        if (ci[b.t]) return; ci[b.t] = 1;
        const el = d.importNode(b.el, true);
        if (el.tagName === 'LI'){ let u = d.body.lastElementChild; if (!u || u.tagName !== 'UL'){ u = d.createElement('ul'); d.body.appendChild(u); } u.appendChild(el); }
        else d.body.appendChild(el);
      });
      dx.body.querySelectorAll('img').forEach(function(im){
        const src = im.getAttribute('src') || ''; if (!src || d.body.innerHTML.indexOf(src) >= 0) return;
        const riga = d.createElement('div'); riga.appendChild(d.importNode(im, true)); d.body.appendChild(riga);
      });
    });
    mnFissaHtml(n, d);
  } else n.mod = Date.now();
  /* una scrittura sola: o entra tutto, o non si toglie niente */
  const via = {}; doppi.forEach(function(x){ via[x.id] = 1; });
  try{ localStorage.setItem(MN_KEY, JSON.stringify(l.filter(function(x){ return x && (x === n || !via[x.id]); }))); mnMarca(); }catch(_){ return n; }
  const piene = doppi.filter(function(x){ return String(x.text || '').trim() || String(x.html || '').trim(); });
  if (piene.length){ const ora = Date.now(); mnCestinoSalva(piene.map(function(x){ return Object.assign({}, x, { via: ora }); }).concat(mnCestino().filter(function(c){ return !via[c.id]; }))); }
  return n;
}
/* la nota c'e' sempre, quando serve: nasce qui e una volta sola */
function mnIdeeAssicura(){
  const n = mnIdeeMigra(); if (n) return n;
  const nuova = mnIdeeNuova(), l = mnLista(); l.unshift(nuova); mnSalva(l); mnIdeeRicorda(nuova);
  return nuova;
}

function mnInboxPunti(){
  const n = mnInbox(); if (!n) return [];
  const chiave = String(n.html || '') + '\u0000' + String(n.text || '');
  if (MN.righeDi !== chiave){ MN.righeDi = chiave; MN.righe = mnBlocchi(mnDoc(n).body).map(function(b){ return b.t; }); }
  return MN.righe.slice();
}
function mnRigaImposta(el, t){
  if (el.querySelector('img')){ Array.prototype.slice.call(el.childNodes).forEach(function(c){ if (c.nodeType === 3) c.remove(); }); el.appendChild(el.ownerDocument.createTextNode(' ' + t)); return; }
  const pre = /^\s*[•\-]\s/.test(el.textContent || '') ? '• ' : '';
  el.textContent = pre + t;
}
function mnRigaVia(el, body){
  if (el.querySelector('img')){ Array.prototype.slice.call(el.childNodes).forEach(function(c){ if (c.nodeType === 3) c.remove(); }); return; }
  let su = el.parentElement; el.remove();
  while (su && su !== body && !su.textContent.trim() && !su.querySelector('img')){ const x = su.parentElement; su.remove(); su = x; }
}
/* la lista nuova delle righe: si tocca solo cio' che e' cambiato, il resto della nota (colori, immagini, caselle) non si muove */
function mnInboxScrivi(punti){
  const l = mnLista();
  let n = mnIdeeTrova(l);
  if (!n){ n = mnIdeeNuova(); l.unshift(n); mnIdeeRicorda(n); }
  const d = mnDoc(n), bl = mnBlocchi(d.body), vecchie = bl.map(function(b){ return b.t; });
  let p = 0; while (p < vecchie.length && p < punti.length && vecchie[p] === punti[p]) p++;
  let z = 0; while (z < vecchie.length - p && z < punti.length - p && vecchie[vecchie.length - 1 - z] === punti[punti.length - 1 - z]) z++;
  const tolte = bl.slice(p, bl.length - z), nuove = punti.slice(p, punti.length - z);
  const k = Math.min(tolte.length, nuove.length);
  for (let i = 0; i < k; i++) mnRigaImposta(tolte[i].el, nuove[i]);
  for (let i = k; i < tolte.length; i++) mnRigaVia(tolte[i].el, d.body);
  let dopo = k > 0 ? tolte[k - 1].el : (p > 0 ? bl[p - 1].el : null);
  const prima = z > 0 ? bl[bl.length - z].el : null;
  nuove.slice(k).forEach(function(t){
    let el;
    if (dopo && dopo.tagName === 'LI'){ el = d.createElement('li'); dopo.after(el); }
    else if (prima){ el = d.createElement('div'); if (dopo) dopo.after(el); else prima.before(el); }
    else { let u = d.body.lastElementChild; if (!u || u.tagName !== 'UL'){ u = d.createElement('ul'); d.body.appendChild(u); } el = d.createElement('li'); u.appendChild(el); }
    el.textContent = t; dopo = el;
  });
  mnFissaHtml(n, d);
  if (n.folder === 'Note veloci') n.folder = 'Cartelle';
  if (mnTitoloVeloci(n.title)) n.title = MN_IDEE_TITOLO;
  mnSalva([n].concat(l.filter(function(x){ return x && x !== n; })));
}
/* -- il Taglia (esercizi.js): le righe da tagliare, dalla piu' vecchia; quelle tagliate vanno nel cestino delle note -- */
function mnIdeePerTaglia(max){
  const n = mnInbox(); if (!n) return [];
  const viste = {};
  return mnBlocchi(mnDoc(n).body).filter(function(b){
    if (viste[b.t] || /^H\d$/.test(b.el.tagName) || b.t.length < 3 || /:$/.test(b.t)) return false;
    if (b.el.classList.contains('nc-item') && b.el.getAttribute('data-c') === '1') return false;
    viste[b.t] = 1; return true;
  }).map(function(b){ return b.t; }).slice(0, max || 8);
}
function mnIdeeTaglia(righe){
  const p = mnInboxPunti(); let tolte = 0;
  (righe || []).forEach(function(t){ const i = p.indexOf(t); if (i >= 0){ p.splice(i, 1); tolte++; } });
  if (!tolte) return 0;
  mnInboxScrivi(p);
  const ora = Date.now();
  mnCestinoSalva(righe.map(function(t, i){ return { id: 'v' + ora + '-' + i, title: t.slice(0, 60), text: t, html: '<div>' + mnEsc(t) + '</div>', date: mnData(), folder: 'Cartelle', via: ora }; }).concat(mnCestino()));
  try{ mnPaint(); }catch(_){ }
  return tolte;
}
function mnInboxAggiungi(t){
  const righe = String(t || '').split(/\n+/).map(function(x){ return x.trim(); }).filter(Boolean);
  if (!righe.length) return false;
  mnInboxScrivi(mnInboxPunti().concat(righe));
  try{ flVibra(8); }catch(_){ }
  return true;
}
/* ---------- il cestino (0.9.231) ---------- */
const MN_CESTINO = 'fl_note_cestino', MN_CESTINO_GIORNI = 30;
function mnCestino(){
  let l = []; try{ l = JSON.parse(localStorage.getItem(MN_CESTINO) || '[]'); }catch(_){ l = []; }
  if (!Array.isArray(l)) l = [];
  const limite = Date.now() - MN_CESTINO_GIORNI * 864e5;
  const vive = l.filter(function(n){ return n && n.id && (n.via || 0) > limite; });
  if (vive.length !== l.length){ try{ localStorage.setItem(MN_CESTINO, JSON.stringify(vive)); }catch(_){ } }
  return vive;
}
function mnCestinoSalva(l){ try{ localStorage.setItem(MN_CESTINO, JSON.stringify(l)); }catch(_){ toast('Il telefono è pieno'); } }
function mnNelCestino(id){
  const l = mnLista(); const n = l.filter(function(x){ return x && x.id === id; })[0]; if (!n) return;
  mnCestinoSalva([Object.assign({}, n, { via: Date.now() })].concat(mnCestino().filter(function(x){ return x.id !== id; })));
  mnSalva(l.filter(function(x){ return x && x.id !== id; }));
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Nel cestino per ' + MN_CESTINO_GIORNI + ' giorni');
  mnPaint();
}
function mnRipristina(id){
  const c = mnCestino(); const n = c.filter(function(x){ return x.id === id; })[0]; if (!n) return;
  const nota = Object.assign({}, n); delete nota.via; nota.mod = Date.now();
  const l = mnLista().filter(function(x){ return x && x.id !== id; }); l.unshift(nota); mnSalva(l);
  mnCestinoSalva(c.filter(function(x){ return x.id !== id; }));
  toast('Rimessa tra le note');
  mnPaint(); mnCestinoApri(true);
}
function mnCestinoSvuota(){
  if (!confirm('Eliminare per sempre le note nel cestino?')) return;
  mnCestinoSalva([]); mnPaint(); mnCestinoApri(true);
}
function mnCestinoApri(ridisegna){
  if (MN.drag || MN.mosso) return;
  let f = document.getElementById('mnCestinoFoglio');
  if (!f){ if (ridisegna) return; f = document.createElement('div'); f.id = 'mnCestinoFoglio'; f.className = 'mn-cf'; f.addEventListener('click', function(e){ if (e.target === f) f.remove(); }); document.body.appendChild(f); }
  const c = mnCestino();
  f.innerHTML = '<div class="mn-cf-box" role="dialog" aria-label="Il cestino delle note"><div class="mn-cf-testa"><b>Il cestino</b><button type="button" aria-label="Chiudi" onclick="document.getElementById(\'mnCestinoFoglio\').remove()"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>'
    + '<p class="mn-cf-nota">Le note restano qui ' + MN_CESTINO_GIORNI + ' giorni, poi spariscono da sole.</p>'
    + (c.length ? c.map(function(n){ const giorni = Math.max(1, MN_CESTINO_GIORNI - Math.floor((Date.now() - (n.via || 0)) / 864e5)); return '<div class="mn-cf-riga"><div><b>' + mnEsc(n.title || 'Nota senza titolo') + '</b><small>' + (giorni === 1 ? 'resta ancora 1 giorno' : 'resta ancora ' + giorni + ' giorni') + '</small></div><button type="button" onclick="mnRipristina(\'' + mnEsc(n.id).replace(/'/g, '') + '\')">Rimetti tra le note</button></div>'; }).join('') + '<button type="button" class="mn-cf-svuota" onclick="mnCestinoSvuota()">Svuota il cestino</button>'
      : '<p class="mn-cf-vuoto">Il cestino è vuoto. Tieni premuta una nota e trascinala qui per buttarla.</p>')
    + '</div>';
}
/* il microfono del pannello (0.9.231): si detta senza aprire la tastiera, la frase diventa un punto */
/* 0.9.319, Andrea: "non c'e' nessuna text area, il testo viene tagliato: deve essere bella alta e ridimensionabile". L'altezza scelta resta. */
const MN_CAMPO_K = 'fl_mn_campo_h';
function mnCampoAltezza(){ let h = 0; try{ h = +localStorage.getItem(MN_CAMPO_K) || 0; }catch(_){ } return Math.max(90, Math.min(520, h || 150)); }
function mnCampoTira(e, presa){
  const el = presa.previousElementSibling; if (!el) return;
  e.preventDefault(); e.stopPropagation();
  const y0 = e.clientY, h0 = el.offsetHeight;
  try{ presa.setPointerCapture(e.pointerId); }catch(_){ }
  const muovi = function(ev){ el.style.height = Math.max(90, Math.min(520, h0 + ev.clientY - y0)) + 'px'; };
  const fine = function(){ presa.removeEventListener('pointermove', muovi); presa.removeEventListener('pointerup', fine); presa.removeEventListener('pointercancel', fine); try{ localStorage.setItem(MN_CAMPO_K, String(el.offsetHeight)); }catch(_){ } };
  presa.addEventListener('pointermove', muovi); presa.addEventListener('pointerup', fine); presa.addEventListener('pointercancel', fine);
}
function mnMic(btn){
  if (typeof dtVia !== 'function' || typeof dtPuo !== 'function'){ toast('La dettatura non è pronta'); return; }
  if (!dtPuo()){ toast('Accendi la dettatura in Personalizza: Dettatura vocale'); return; }
  const v = btn && btn.closest ? btn.closest('.mn-veloci') : null;
  const el = (v && v.querySelector('.mn-v-scrivi')) || document.querySelector('#mppNote .mn-v-scrivi'); if (!el) return;
  MN.dove = v ? v.getAttribute('data-dove') : 'mappa';
  el.setAttribute('data-dt-aggiungi', 'mnMicFatto');
  DT.el = el; DT.doc = document;
  const w = dtW(); w.hidden = false; dtPosiziona();
  dtVia();
}
function mnMicFatto(t){
  document.querySelectorAll('.mn-v-scrivi[data-dt-aggiungi]').forEach(function(el){ el.removeAttribute('data-dt-aggiungi'); });
  if (mnInboxAggiungi(t)) mnPaint();
  const w = document.getElementById('dtW'); if (w && !DT.on) w.hidden = true;
}
/* lo stesso per il piano (il blocco "Le tue note" in Note e idee) */
function mnDettaVeloce(){
  if (typeof dtVia !== 'function' || typeof dtPuo !== 'function' || !dtPuo()){ toast('Accendi la dettatura in Personalizza: Dettatura vocale'); return; }
  const fin = { isContentEditable: false, tagName: 'DIV', ownerDocument: document, focus: function(){ }, getAttribute: function(k){ return k === 'data-dt-aggiungi' ? 'mnMicFatto' : null; }, dataset: { dtAggiungi: 'mnMicFatto' }, removeAttribute: function(){ } };
  DT.el = fin; DT.doc = document;
  const w = dtW(); w.hidden = false; dtPosiziona();
  dtVia();
}
function mnInboxTogli(i){ const p = mnInboxPunti(); p.splice(i, 1); mnInboxScrivi(p); mnPaint(); }
const MN_VISTI = 8;
function mnCaret(el){
  const s = window.getSelection(); if (!s || !s.rangeCount || !el.contains(s.anchorNode)) return el.textContent.length;
  const r = s.getRangeAt(0).cloneRange(); r.selectNodeContents(el); r.setEnd(s.getRangeAt(0).endContainer, s.getRangeAt(0).endOffset); return r.toString().length;
}
function mnCursore(el, at){
  el.focus();
  try{
    let resto = at; const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n = w.nextNode();
    while (n){ if (resto <= n.textContent.length){ const r = document.createRange(); r.setStart(n, resto); r.collapse(true); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); return; } resto -= n.textContent.length; n = w.nextNode(); }
    const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
  }catch(_){ }
}
/* una riga cambiata: si salva all'uscita; vuota, sparisce */
function mnRigaBlur(el){
  if (MN.ridisegna) return;
  mnDove(el);
  const i = +el.getAttribute('data-i'); const p = mnInboxPunti(); if (!(i >= 0 && i < p.length)) return;
  const t = el.textContent.replace(/\s+/g, ' ').trim();
  if (t === p[i]) return;
  if (t) p[i] = t; else p.splice(i, 1);
  mnInboxScrivi(p);
  if (!t) mnPaint();
}
/* invio: la riga si spezza dove sta il cursore (a fine riga si apre una riga nuova sotto);
   Backspace all'inizio: la riga si unisce a quella sopra */
function mnRigaTasto(e, el){
  mnDove(el);
  const i = +el.getAttribute('data-i'); const p = mnInboxPunti(); if (!(i >= 0 && i < p.length)) return;
  const testo = el.textContent || ''; const sel = window.getSelection(); const unico = !sel || sel.isCollapsed;
  if (e.key === 'Enter' && !e.shiftKey){
    e.preventDefault();
    const o = mnCaret(el); const prima = testo.slice(0, o).replace(/\s+/g, ' ').trim(), dopo = testo.slice(o).replace(/\s+/g, ' ').trim();
    if (!prima && !dopo) return;
    if (prima) p[i] = prima; else p[i] = dopo;
    if (prima && dopo) p.splice(i + 1, 0, dopo);
    mnInboxScrivi(p);
    if (prima && dopo){ MN.fuoco = { i: i + 1, at: 0 }; mnPaint(); return; }
    /* a fine riga: una riga nuova, vuota, subito sotto */
    MN.nuovaDopo = i; mnPaint(); return;
  }
  if (e.key === 'Backspace' && unico && mnCaret(el) === 0 && i > 0){
    e.preventDefault();
    const su = p[i - 1]; const t = testo.replace(/\s+/g, ' ').trim();
    p[i - 1] = t ? su + ' ' + t : su; p.splice(i, 1);
    mnInboxScrivi(p); MN.fuoco = { i: i - 1, at: su.length }; mnPaint();
  }
}
/* la riga nuova aperta con invio sotto una riga: scritta e confermata entra li', non in fondo */
function mnNuovaTasto(e, el){
  mnDove(el);
  if (e.key === 'Backspace' && !el.textContent){ e.preventDefault(); const i = +el.getAttribute('data-dopo'); MN.fuoco = { i: i, at: 1e9 }; mnPaint(); return; }
  if (e.key !== 'Enter' || e.shiftKey) return;
  e.preventDefault();
  const t = el.textContent.replace(/\s+/g, ' ').trim(); if (!t) return;
  const i = +el.getAttribute('data-dopo'); const p = mnInboxPunti(); p.splice(i + 1, 0, t); mnInboxScrivi(p);
  MN.nuovaDopo = i + 1; mnPaint();
}
function mnNuovaBlur(el){
  if (MN.ridisegna) return;
  const t = el.textContent.replace(/\s+/g, ' ').trim(); if (!t) return;
  const i = +el.getAttribute('data-dopo'); const p = mnInboxPunti(); p.splice(i + 1, 0, t); mnInboxScrivi(p); mnPaint();
}
function mnTasto(e, el){
  mnDove(el);
  if (e.key !== 'Enter' || e.shiftKey) return;
  e.preventDefault();
  if (mnInboxAggiungi(el.textContent)){ el.textContent = ''; mnPaint(true); }
}
function mnBlur(el){ mnDove(el); if (el.textContent.trim() && mnInboxAggiungi(el.textContent)){ el.textContent = ''; mnPaint(); } }

/* ---------- la sezione nella Mappa ---------- */
function mnTileNota(n, cls){
  return '<button type="button" class="mn-t mn-nota' + (cls || '') + '" data-nid="' + mnEsc(n.id) + '" onclick="mnTocca(event,\'' + mnEsc(n.id) + '\')">'
    /* 0.9.290, Andrea: "le card delle note sono scure, con il testo che si vede sotto al titolo, tutte buggate: solo il titolo" */
    + '<span class="mn-nota-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg></span><b>' + mnEsc(n.title || 'Nota senza titolo') + '</b><small>' + mnEsc(n.date || '') + '</small></button>';
}
/** Il pannello delle note veloci. `dove`: 'mappa' (Le tue note) o 'foglio' (la scheda Note del pannello). */
function mnVelociHtml(dove){
  const punti = mnInboxPunti();
  const ico = function(p){ return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
  return '<div class="mn-veloci" data-dove="' + dove + '">'
    +   '<div class="mn-v-testa"><span>' + ico('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>') + '</span><b>Note veloci</b><button type="button" class="mn-v-mic" aria-label="Detta una nota veloce" onclick="mnMic(this)">' + ico('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>') + '</button><button type="button" class="mn-v-apri" aria-label="Apri le note veloci a schermo intero" onclick="noApri(\'' + MN_INBOX + '\')">' + ico('<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>') + '</button></div>'
    +   (punti.length > MN_VISTI ? '<button type="button" class="mn-v-altri" onclick="noApri(\'' + MN_INBOX + '\')">Altri ' + (punti.length - MN_VISTI) + ' punti, sopra</button>' : '')
    +   '<div class="mn-v-punti">' + punti.map(function(p, i){ return i < punti.length - MN_VISTI ? '' : '<div class="mn-v-riga" data-i="' + i + '"><span class="mn-v-dot" title="Tieni premuto e trascina nel caveau o in una nota"></span><div class="mn-v-t" contenteditable="true" data-i="' + i + '" onkeydown="mnRigaTasto(event,this)" onblur="mnRigaBlur(this)">' + mnEsc(p) + '</div></div>'; }).join('') + '</div>'
    +   '<div class="mn-v-campo"><div class="mn-v-scrivi" contenteditable="true" data-ph="Scrivi un pensiero, o detta col microfono" style="height:' + mnCampoAltezza() + 'px" onkeydown="mnTasto(event,this)" onblur="mnBlur(this)"></div><i class="mn-v-presa" aria-hidden="true" onpointerdown="mnCampoTira(event,this)"></i></div>'
    + '</div>';
}
/** In quale pannello si sta scrivendo (per rimettere il cursore nel posto giusto dopo il ridisegno). */
function mnDove(el){ const v = el && el.closest ? el.closest('.mn-veloci') : null; MN.dove = v ? (v.getAttribute('data-dove') || 'mappa') : 'mappa'; }
function mnHtml(){
  const punti = mnInboxPunti(), note = mnOrdinate();
  let nCv = 0; try{ nCv = (typeof cvChiuse === 'function') ? cvChiuse().length : 0; }catch(_){ }
  const nCe = mnCestino().length;
  const ico = function(p){ return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
  return '<div class="mpp-sez"><b>Le tue note</b></div>'
    + mnVelociHtml('mappa')
    + '<div class="mpp-pagine mn-griglia">'
    +   (note.length ? mnTileNota(note[0], ' ultima') : '<button type="button" class="mpp-pag tratt" onclick="noApri(\'new\')"><span>＋</span>Nuova nota</button>')
    +   '<button type="button" class="mn-t mn-caveau" id="mnCaveau" onclick="mnCaveauApri()"><span class="mn-cv-ico">' + (typeof cvApribile === 'function' && cvApribile() ? '🔓' : '🔒') + '</span><b>Il caveau</b><small>' + (nCv ? nCv + (nCv === 1 ? ' idea al sicuro' : ' idee al sicuro') : 'Trascina qui una nota') + '</small></button>'
    +   (note[1] ? mnTileNota(note[1], '') : (note.length ? '<button type="button" class="mpp-pag tratt" onclick="noApri(\'new\')"><span>＋</span>Nuova nota</button>' : '<span></span>'))
    +   '<button type="button" class="mn-t mn-cestino" id="mnCestino" onclick="mnCestinoApri()"><span class="mn-cv-ico"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/></svg></span><b>Il cestino</b><small>' + (nCe ? nCe + (nCe === 1 ? ' nota, per 30 giorni' : ' note, per 30 giorni') : 'Trascina qui una nota') + '</small></button>'
    +   (note[2] ? mnTileNota(note[2], '') : '')
    +   (note[1] ? '<button type="button" class="mpp-pag tratt" onclick="noApri(\'new\')"><span>＋</span>Nuova nota</button>' : '')
    + '</div>'
    + '<button type="button" class="mn-tutte" onclick="noApri()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg>Tutte le note' + (note.length ? '<small>' + note.length + (note.length === 1 ? ' nota' : ' note') + '</small>' : '') + '</button>';
}
function mnPaint(fuoco){
  const pag = document.getElementById('mppPagine'); if (!pag || !pag.parentElement) return;
  if (!MN.migrata){ MN.migrata = true; try{ mnIdeeMigra(); }catch(_){ } }
  let h = document.getElementById('mppNote');
  if (!h){ h = document.createElement('div'); h.id = 'mppNote'; h.className = 'mpp-slot'; }
  /* 0.9.232: "Le tue note" e' un blocco di Personalizza Mappa: il posto lo decide lui (scsOrdinaBlocchi) */
  if (!h.parentElement){ pag.parentElement.insertBefore(h, pag); try{ if (typeof scsOrdinaBlocchi === 'function') scsOrdinaBlocchi('mappa-mia'); }catch(_){ } }
  h.classList.toggle('mpp-via', pag.classList.contains('mpp-via'));
  MN.ridisegna = true;
  h.innerHTML = '<div class="mpp-page mpp-page-pagine">' + mnHtml() + '</div>';
  MN.ridisegna = false;
  /* 0.9.232: lo stesso pannello nella scheda Note del foglio */
  document.querySelectorAll('.mn-veloci:not([data-dove="mappa"])').forEach(function(v){ const d = v.getAttribute('data-dove') || 'foglio'; MN.ridisegna = true; v.outerHTML = mnVelociHtml(d); MN.ridisegna = false; });
  mnDragAggancia();
  mnRigheAggancia();
  const qui = (MN.dove && MN.dove !== 'mappa') ? (document.querySelector('.mn-veloci[data-dove="' + MN.dove + '"]') || h) : h;
  MN.dove = '';
  if (MN.nuovaDopo !== undefined && MN.nuovaDopo !== null){
    const i = MN.nuovaDopo; MN.nuovaDopo = null;
    const r = qui.querySelector('.mn-v-riga[data-i="' + i + '"]');
    if (r){ const n = document.createElement('div'); n.className = 'mn-v-riga mn-v-nuova'; n.innerHTML = '<span class="mn-v-dot"></span><div class="mn-v-t" contenteditable="true" data-dopo="' + i + '" onkeydown="mnNuovaTasto(event,this)" onblur="mnNuovaBlur(this)"></div>'; r.after(n); n.querySelector('.mn-v-t').focus(); return; }
  }
  if (MN.fuoco){ const f = MN.fuoco; MN.fuoco = null; const el = qui.querySelector('.mn-v-t[data-i="' + f.i + '"]'); if (el){ mnCursore(el, f.at); return; } }
  if (fuoco){ const s = qui.querySelector('.mn-v-scrivi'); if (s) s.focus(); }
}
function mnCaveauApri(){
  if (MN.drag || MN.mosso) return;
  /* 0.9.232: la pagina del caveau (ulisse.js); il foglio della Mappa resta il ripiego */
  if (typeof cvPaginaApri === 'function'){ cvPaginaApri(); return; }
  try{ if (typeof mppVista === 'function') mppVista('mia'); }catch(_){ }
  try{ if (typeof mfTab === 'function') mfTab('note'); }catch(_){ }
  setTimeout(function(){ const f = document.getElementById('cvBox') || document.getElementById('mppFoglio'); if (f && f.scrollIntoView) f.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 200);
}
function mnTocca(e, id){ if (MN.drag || MN.mosso){ MN.mosso = false; e.preventDefault(); return; } noApri(id); }

/* ---------- tieni premuta una nota e portala nel caveau ---------- */
function mnDragAggancia(){
  document.querySelectorAll('#mppNote .mn-nota').forEach(function(t){
    t.addEventListener('pointerdown', function(e){
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const x0 = e.clientX, y0 = e.clientY;
      const timer = setTimeout(function(){ mnDragInizia(t, x0, y0); }, 380);
      const via = function(){ clearTimeout(timer); t.removeEventListener('pointermove', mv); t.removeEventListener('pointerup', via); t.removeEventListener('pointercancel', via); };
      const mv = function(ev){ if (Math.hypot(ev.clientX - x0, ev.clientY - y0) > 8) via(); };
      t.addEventListener('pointermove', mv); t.addEventListener('pointerup', via); t.addEventListener('pointercancel', via);
    });
    t.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  });
}
function mnDragInizia(t, x, y){
  const r = t.getBoundingClientRect();
  const fant = t.cloneNode(true); fant.classList.add('mn-fantasma');
  fant.style.width = r.width + 'px'; fant.style.height = r.height + 'px';
  document.body.appendChild(fant);
  MN.drag = { id: t.getAttribute('data-nid'), fant: fant, dx: x - r.left, dy: y - r.top };
  t.classList.add('mn-tirata');
  try{ flVibra(15); }catch(_){ }
  const dentro = function(el, ev){ if (!el) return false; const c = el.getBoundingClientRect(); return ev.clientX > c.left && ev.clientX < c.right && ev.clientY > c.top && ev.clientY < c.bottom; };
  /* 0.9.294, Andrea: "trascinando una nota nel cestino resta li'". Sul telefono Android annullava il gesto del puntatore
     (pointercancel) appena il dito si muoveva, per scorrere la pagina: la nota tornava al suo posto. Adesso il dito si
     segue anche con gli eventi touch, e la nota si lascia dove il dito si e' alzato davvero. */
  const pos = { x: x, y: y };
  const sopra = function(){ const ev = { clientX: pos.x, clientY: pos.y }; ['mnCaveau', 'mnCestino'].forEach(function(k){ const el = document.getElementById(k); if (el) el.classList.toggle('mn-sopra', dentro(el, ev)); }); };
  const muovi = function(cx, cy){ if (!MN.drag) return; pos.x = cx; pos.y = cy; fant.style.left = (cx - MN.drag.dx) + 'px'; fant.style.top = (cy - MN.drag.dy) + 'px'; sopra(); };
  const sposta = function(ev){ if (!MN.drag) return; ev.preventDefault(); muovi(ev.clientX, ev.clientY); };
  const tocca = function(ev){ if (!MN.drag) return; ev.preventDefault(); const p = ev.touches && ev.touches[0]; if (p) muovi(p.clientX, p.clientY); };
  let finito = false, sicura = 0;
  const fine = function(ev){
    if (finito) return;
    /* l'annullamento del puntatore non e' la fine: il dito e' ancora giu', la seguono gli eventi touch */
    if (ev && ev.type === 'pointercancel'){ clearTimeout(sicura); sicura = setTimeout(function(){ fine({ type: 'scaduto' }); }, 8000); return; }
    finito = true; clearTimeout(sicura);
    document.removeEventListener('pointermove', sposta); document.removeEventListener('pointerup', fine); document.removeEventListener('pointercancel', fine);
    document.removeEventListener('touchmove', tocca); document.removeEventListener('touchend', fine); document.removeEventListener('touchcancel', fine);
    const d = MN.drag; MN.drag = null; MN.mosso = true; setTimeout(function(){ MN.mosso = false; }, 400);
    fant.remove(); t.classList.remove('mn-tirata');
    const cv = document.getElementById('mnCaveau'), ce = document.getElementById('mnCestino');
    [cv, ce].forEach(function(el){ if (el) el.classList.remove('mn-sopra'); });
    if (!d || (ev.type !== 'pointerup' && ev.type !== 'touchend')) return;
    if (ev.type === 'pointerup'){ pos.x = ev.clientX; pos.y = ev.clientY; }
    const giu = { clientX: pos.x, clientY: pos.y };
    if (dentro(cv, giu)) mnNelCaveau(d.id);
    else if (dentro(ce, giu)) mnNelCestino(d.id);
  };
  fant.style.left = r.left + 'px'; fant.style.top = r.top + 'px';
  document.addEventListener('pointermove', sposta, { passive: false }); document.addEventListener('pointerup', fine); document.addEventListener('pointercancel', fine);
  document.addEventListener('touchmove', tocca, { passive: false }); document.addEventListener('touchend', fine); document.addEventListener('touchcancel', fine);
}
function mnRigheAggancia(){
  document.querySelectorAll('.mn-veloci .mn-v-riga:not(.mn-v-nuova)').forEach(function(r){
    const dot = r.querySelector('.mn-v-dot'); if (!dot || dot._mn) return; dot._mn = true;
    dot.addEventListener('pointerdown', function(e){
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault();
      const x0 = e.clientX, y0 = e.clientY;
      const timer = setTimeout(function(){ via(); mnRigaTira(r, x0, y0); }, e.pointerType === 'mouse' ? 120 : 300);
      const via = function(){ clearTimeout(timer); document.removeEventListener('pointerup', via); document.removeEventListener('pointercancel', via); };
      document.addEventListener('pointerup', via); document.addEventListener('pointercancel', via);
    });
    dot.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  });
}
function mnBersaglio(x, y){
  const cv = document.getElementById('mnCaveau');
  const dentro = function(el){ const c = el.getBoundingClientRect(); return x > c.left && x < c.right && y > c.top && y < c.bottom; };
  if (cv && dentro(cv)) return { tipo: 'caveau', el: cv };
  const box = document.getElementById('cvBox');
  if (box && box.offsetParent && dentro(box)) return { tipo: 'caveau', el: box };
  const ce = document.getElementById('mnCestino');
  if (ce && dentro(ce)) return { tipo: 'cestino', el: ce };
  const n = Array.from(document.querySelectorAll('#mppNote .mn-nota')).filter(dentro)[0];
  return n ? { tipo: 'nota', el: n, id: n.getAttribute('data-nid') } : null;
}
function mnRigaTira(r, x, y){
  const i = +r.getAttribute('data-i'); const testo = (mnInboxPunti()[i] || '').trim(); if (!testo) return;
  const fant = document.createElement('div'); fant.className = 'mn-fantasma mn-fant-riga'; fant.textContent = testo;
  document.body.appendChild(fant); r.classList.add('mn-tirata');
  try{ flVibra(15); }catch(_){ }
  let sopra = null;
  const metti = function(cx, cy){ fant.style.left = (cx - 30) + 'px'; fant.style.top = (cy - 22) + 'px'; };
  metti(x, y);
  const sposta = function(ev){ ev.preventDefault(); metti(ev.clientX, ev.clientY); const b = mnBersaglio(ev.clientX, ev.clientY); if (sopra && (!b || b.el !== sopra)) sopra.classList.remove('mn-sopra'); sopra = b ? b.el : null; if (sopra) sopra.classList.add('mn-sopra'); };
  const blocca = function(ev){ ev.preventDefault(); };
  const fine = function(ev){
    document.removeEventListener('pointermove', sposta); document.removeEventListener('pointerup', fine); document.removeEventListener('pointercancel', fine); document.removeEventListener('touchmove', blocca);
    fant.remove(); r.classList.remove('mn-tirata'); if (sopra) sopra.classList.remove('mn-sopra');
    if (ev.type !== 'pointerup') return;
    const b = mnBersaglio(ev.clientX, ev.clientY); if (!b) return;
    const p = mnInboxPunti();
    if (b.tipo === 'caveau'){
      if (typeof cvAggiungi !== 'function' || !cvAggiungi(testo, false)){ toast('Il caveau non è pronto: riprova'); return; }
      p.splice(i, 1); mnInboxScrivi(p); toast('Al sicuro nel caveau');
    } else if (b.tipo === 'cestino'){
      p.splice(i, 1); mnInboxScrivi(p);
      mnCestinoSalva([{ id: 'v' + Date.now(), title: testo.slice(0, 60), text: testo, html: '<div>' + mnEsc(testo) + '</div>', date: mnData(), folder: 'Cartelle', via: Date.now() }].concat(mnCestino()));
      toast('Nel cestino per ' + MN_CESTINO_GIORNI + ' giorni');
    } else {
      const l = mnLista(); const n = l.filter(function(x){ return x && x.id === b.id; })[0]; if (!n) return;
      n.text = (String(n.text || '').replace(/\s+$/, '') + '\n' + testo).replace(/^\n/, '');
      n.html = (n.html || '') + '<div>' + mnEsc(testo) + '</div>'; n.mod = Date.now();
      mnSalva(l); p.splice(i, 1); mnInboxScrivi(p); toast('Aggiunto a "' + (n.title || 'la nota') + '"');
    }
    try{ flVibra([10, 30, 10]); }catch(_){ }
    mnPaint();
  };
  document.addEventListener('pointermove', sposta, { passive: false }); document.addEventListener('pointerup', fine); document.addEventListener('pointercancel', fine);
  document.addEventListener('touchmove', blocca, { passive: false });
}
function mnNelCaveau(id){
  const l = mnLista(); const n = l.filter(function(x){ return x && x.id === id; })[0]; if (!n) return;
  const testo = [n.title && !/^Nota (testuale )?senza titolo/i.test(n.title) ? n.title : '', String(n.text || '').trim()].filter(Boolean).join(': ').replace(/\n+/g, ' · ');
  if (typeof cvAggiungi !== 'function' || !cvAggiungi(testo.slice(0, 400), false)){ toast('Il caveau non è pronto: riprova'); return; }
  mnSalva(l.filter(function(x){ return x && x.id !== id; }));
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Nota al sicuro nel caveau');
  mnPaint();
}

/* ---------- LE NOTE DI SAMSUNG NOTES (0.9.233) ----------
   Andrea ha chiesto di portare qui tutte le sue note di Samsung Notes, con la loro formattazione. Il PC
   le converte (caselle, colori, elenchi, immagini) e le lascia sul server sotto la chiave privata del
   piano; l'app, che ha la stessa chiave, le prende e le unisce per id: niente doppioni, e una nota
   buttata nel cestino non torna. Se sul server arriva un import piu' nuovo, si aggiungono solo le note
   che mancano. */
async function mnImporta(){
  if (MN.importo) return; MN.importo = true;
  try{
    let k = ''; try{ k = localStorage.getItem('fl_piano_chiave') || ''; }catch(_){ }
    if (!/^[A-Za-z0-9_-]{32,64}$/.test(k)) return;
    const path = '/api/focuslock/piano/' + k + '/note-import';
    let r = null;
    try{ r = await frApi('GET', path); }catch(_){ try{ r = await (await fetch('https://meta-ai-media-buyer-production.up.railway.app' + path, { cache: 'no-store' })).json(); }catch(__){ r = null; } }
    if (!r || !r.dati) return;
    let fatto = 0; try{ fatto = +localStorage.getItem('fl_note_import_at') || 0; }catch(_){ }
    if ((+r.at || 0) <= fatto) return;
    let nuove = []; try{ nuove = JSON.parse(r.dati); }catch(_){ return; }
    const l = mnLista(); const ci = {}; l.forEach(function(n){ if (n && n.id) ci[n.id] = 1; }); mnCestino().forEach(function(n){ ci[n.id] = 1; });
    let n = 0; nuove.forEach(function(x){ if (x && x.id && !ci[x.id]){ l.push(x); ci[x.id] = 1; n++; } });
    if (n){
      try{ localStorage.setItem(MN_KEY, JSON.stringify(l)); mnMarca(); }catch(_){ toast('Il telefono è pieno: le note di Samsung Notes non sono entrate'); return; }
    }
    try{ localStorage.setItem('fl_note_import_at', String(r.at)); }catch(_){ }
    if (n){ toast(n === 1 ? '1 nota portata da Samsung Notes' : n + ' note portate da Samsung Notes'); mnPaint(); }
  }finally{ MN.importo = false; }
}
setTimeout(function(){ try{ mnImporta(); }catch(_){ } }, 5000);

/* ---------- le note a schermo intero ---------- */
registerScreen('s-note', '<iframe id="noFrame" class="nt-frame" title="Le note" src="about:blank"></iframe>', { back: 's-home' });
function noApri(id, daHome){
  const f = document.getElementById('noFrame'); if (!f) return;
  /* 0.9.311: "inbox" non e' piu' un indirizzo, e' "la nota delle idee", qualunque id abbia */
  if (id === MN_INBOX){ try{ id = mnIdeeAssicura().id; }catch(_){ } } else { try{ mnIdeeMigra(); }catch(_){ } }
  /* IL LAMPO NERO, LA CAUSA VERA (0.9.242). Le note si aprivano DUE volte. Dall'icona sulla Home,
     con l'app ancora viva, Android rimette davanti la schermata di prima (spesso le note, gia'
     aperte); poi arriva l'intento "apri" e noApri ricaricava l'iframe da capo: velo, nero, note di
     nuovo. Se le note sono gia' a schermo e il documento e' carico non si ricarica niente: al
     massimo si va alla nota chiesta cambiando l'indirizzo dentro l'iframe. */
  if (typeof order !== 'undefined' && order[cur] === 's-note' && f.__noCarico && /note\/index\.html/.test(f.getAttribute('src') || '')){
    if (daHome) MN.tieniFino = Date.now() + 5000;
    MN.aperto = true;
    if (id){ try{ f.contentWindow.location.hash = '#/note/' + encodeURIComponent(id); }catch(_){ } }
    return;
  }
  /* dall'icona della Home: per qualche secondo nessun passo dell'avvio puo' portare via le note */
  if (daHome){ MN.tieniFino = Date.now() + 5000; try{ noGuardia(); }catch(_){ } }
  if (!MN.aperto){
    /* 0.9.231: aperte dal piano (il blocco "Le tue note" in Note e idee) si torna al piano */
    MN.ritornoScr = (typeof order !== 'undefined' && order[cur] === 's-notion') ? 's-notion' : '';
    try{ MN.ritorno = localStorage.getItem('fl_tab') || 'mappa'; }catch(_){ MN.ritorno = 'mappa'; }
  }
  const h = id ? '#/note/' + encodeURIComponent(id) : '#/';
  /* IL LAMPO NERO. L'iframe si mostrava subito, vuoto, e la pagina delle note arrivava dopo:
     uno schermo nero e poi il contenuto di colpo. Adesso resta trasparente sopra lo stesso
     nero delle note (quello della replica) e compare in dissolvenza solo quando la lista e'
     disegnata davvero. */
  noVela(f);
  f.__noCarico = false;
  f.setAttribute('src', 'note/index.html?v=' + Date.now() + h);
  MN.aperto = true;
  goId('s-note');
}
function noVela(f){
  const giro = (f.__noGiro || 0) + 1; f.__noGiro = giro;
  f.style.transition = 'none'; f.style.opacity = '0';
  let fatto = false;
  const mostra = function(){
    if (fatto || f.__noGiro !== giro) return; fatto = true;
    f.style.transition = 'opacity .22s ease'; f.style.opacity = '1';
  };
  f.onload = function(){
    /* il documento e' carico, la lista puo' arrivare un attimo dopo: si aspetta che ci sia */
    let n = 0;
    const guarda = function(){
      let pronta = false;
      try{ const r = f.contentDocument && f.contentDocument.getElementById('root'); pronta = !!(r && r.children.length); }catch(_){ pronta = true; }
      if (pronta || ++n > 20){ f.__noCarico = true; mostra(); } else setTimeout(guarda, 30);
    };
    guarda();
  };
  /* se il caricamento non dice niente, le note si mostrano comunque */
  setTimeout(mostra, 1800);
}
function noBack(){
  if (order[cur] !== 's-note') return false;
  MN.tieniFino = 0;
  /* dentro una nota o nella ricerca si preme il SUO pulsante indietro (salva la nota). Mai
     history.back(): la cronologia dell'iframe e' la stessa della pagina e ricaricava l'app */
  try{
    const d = document.getElementById('noFrame').contentDocument;
    /* 0.9.294, Andrea: "nelle note indietro non tornava piu' alla casa". Il pulsante si cerca solo se si vede davvero
       (una nota aperta, la ricerca); e se due Indietro di fila non hanno cambiato niente, si esce dalle note. */
    const vis = function(el){ return !!(el && el.offsetParent !== null && el.getBoundingClientRect().width > 0); };
    const b = d && [].concat(Array.from(d.querySelectorAll('[aria-label="Salva e torna alle note"]')), Array.from(d.querySelectorAll('[aria-label="Torna alle note"]'))).filter(vis)[0];
    const ora = Date.now();
    if (b && !(MN.ultimoBack && ora - MN.ultimoBack.at < 2500 && MN.ultimoBack.el === b)){ MN.ultimoBack = { at: ora, el: b }; b.click(); return true; }
    MN.ultimoBack = null;
  }catch(_){ }
  noChiudi();
  return true;
}
function noChiudi(){
  MN.aperto = false; MN.tieniFino = 0;
  if (MN.ritornoScr){ const r = MN.ritornoScr; MN.ritornoScr = ''; goId(r); setTimeout(mnPaint, 160); return; }
  goId('s-home'); try{ switchTab(MN.ritorno || 'mappa'); }catch(_){ } MN.ritorno = '';
  setTimeout(mnPaint, 160);
}
/* aperte dall'icona sulla Home: i passi dell'avvio (la scheda di sempre, le schermate del
   ritorno) non portano via le note nei primi secondi. Indietro e la chiusura vera passano. */
function noGuardia(){
  /* nav.js arriva dopo questo file: la guardia si mette quando go() c'e' */
  if (typeof go !== 'function'){ setTimeout(noGuardia, 60); return; }
  if (go.__noGuardia) return;
  const vero = go;
  const g = function(n){
    try{ if (MN.tieniFino && Date.now() < MN.tieniFino && order[cur] === 's-note' && order[n] !== 's-note') return; }catch(_){ }
    return vero.apply(this, arguments);
  };
  g.__noGuardia = true;
  window.go = go = g;
}
setTimeout(noGuardia, 0);
BACK_TO['s-note'] = function(){ MN.aperto = false; MN.tieniFino = 0; setTimeout(mnPaint, 160); const r = MN.ritornoScr || 's-home'; MN.ritornoScr = ''; return r; };

(function(){
  if (typeof mppPaint === 'function'){ const v = mppPaint; window.mppPaint = mppPaint = function(){ const r = v.apply(this, arguments); try{ mnPaint(); }catch(_){ } return r; }; }
  if (typeof mppApplicaVista === 'function'){ const v2 = mppApplicaVista; window.mppApplicaVista = mppApplicaVista = function(){ const r = v2.apply(this, arguments); try{ const h = document.getElementById('mppNote'), p = document.getElementById('mppPagine'); if (h && p) h.classList.toggle('mpp-via', p.classList.contains('mpp-via')); }catch(_){ } return r; }; }
  const st = document.createElement('style');
  st.textContent = [
    '#s-note{padding:0 !important;overflow:hidden !important;background:#000}#s-note .nt-frame{background:#000}',
    '#mppNote{padding:0 16px;margin:6px 0 10px}#mppNote[hidden]{display:none}',
    '.mn-veloci{border-radius:18px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:12px 14px 10px;margin:4px 0 12px}',
    '.mn-v-testa{display:flex;align-items:center;gap:8px;color:var(--navy)}.mn-v-testa b{flex:1;font:800 15px var(--font-display,var(--font-body))}.mn-v-testa span{display:grid;place-items:center;color:#0075E3}',
    '.mn-v-apri{width:34px;height:34px;border:0;border-radius:10px;background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}',
    '.mn-v-punti{margin:8px 0 2px}.mn-v-riga{display:flex;align-items:flex-start;gap:4px;padding:2px 0}',
    '.mn-v-dot{flex:none;width:24px;height:26px;display:grid;place-items:center;cursor:grab;touch-action:none;-webkit-user-select:none;user-select:none}.mn-v-dot::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--navy)}',
    '.mn-v-t{flex:1;min-width:0;padding:2px 0;font:500 14.5px/1.5 var(--font-body);color:var(--navy);outline:none;word-break:break-word}',
    '.mn-v-nuova .mn-v-t:empty::before{content:"";}.mn-fant-riga{padding:8px 12px;border-radius:12px;background:var(--navy,#14234A);color:#fff;font:600 14px var(--font-body);max-width:70vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.mn-nota.mn-sopra{transform:scale(1.05);box-shadow:0 0 0 3px #0075E3}',
    '.mn-t.mn-nota{background:var(--card,#fff);color:var(--navy,#14234A);box-shadow:0 0 0 1.5px var(--line,#DCE8F5) inset;justify-content:flex-start;gap:6px}.mn-t.mn-nota b{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;margin-top:auto;font:800 15px/1.3 var(--font-body);color:var(--navy,#14234A)}.mn-t.mn-nota small{font:600 12px var(--font-body);color:var(--muted,#5B6B86)}.mn-nota-ico{color:#0075E3}',
    'body.dark .mn-t.mn-nota{background:#12203A;box-shadow:0 0 0 1.5px #22345A inset}body.dark .mn-t.mn-nota b{color:#fff}body.dark .mn-nota-ico{color:#5BC0F8}',
    '.mn-v-altri{border:0;background:transparent;color:#0075E3;font:700 13px var(--font-body);padding:2px 0 4px;cursor:pointer}',
    '.mn-v-campo{position:relative;margin-top:10px}.mn-v-scrivi{box-sizing:border-box;overflow-y:auto;padding:12px 14px 22px;border:1.5px solid #BCE0FF;border-radius:14px;background:rgba(227,241,255,.28);font:500 15px/1.45 var(--font-body);color:var(--navy);outline:none;white-space:pre-wrap;overflow-wrap:anywhere}.mn-v-scrivi:focus{border-color:#0075E3}.mn-v-scrivi:empty::before{content:attr(data-ph);color:var(--muted)}',
    '.mn-v-presa{position:absolute;right:2px;bottom:2px;width:30px;height:30px;cursor:ns-resize;touch-action:none;background:linear-gradient(135deg,transparent 58%,#7FA9D6 58%,#7FA9D6 64%,transparent 64%,transparent 74%,#7FA9D6 74%,#7FA9D6 80%,transparent 80%)}',
    '.mn-t{position:relative;display:flex;flex-direction:column;justify-content:flex-end;gap:2px;text-align:left;min-height:132px;padding:12px;border:0;border-radius:18px;background:#14234A;color:#fff;cursor:pointer;overflow:hidden;font:inherit;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:pan-y}',
    '.mn-t .mn-prev{position:absolute;inset:10px 12px auto 12px;max-height:70px;overflow:hidden;font:500 11.5px/1.4 var(--font-body);color:rgba(255,255,255,.72);white-space:pre-line}',
    '.mn-t b{font:800 14px/1.25 var(--font-body);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.mn-t small{font:600 11.5px var(--font-body);color:rgba(255,255,255,.6)}',
    '.mn-caveau{background:linear-gradient(160deg,#1E2A5A,#0F2041);justify-content:center;align-items:center;text-align:center;transition:transform .15s,box-shadow .15s}.mn-cv-ico{font-size:30px;margin-bottom:4px}',
    '.mn-caveau.mn-sopra{transform:scale(1.05);box-shadow:0 0 0 3px #8CC6FF,0 12px 26px rgba(0,20,60,.3)}',
    '.mn-v-mic{width:34px;height:34px;border:0;border-radius:50%;background:#E3F1FF;color:#0075E3;display:grid;place-items:center;cursor:pointer}',
    '.mn-cestino{background:#E8EEF7;color:#14234A;justify-content:center;align-items:center;text-align:center;transition:transform .15s,box-shadow .15s}.mn-cestino small{color:#5B6B86}.mn-cestino .mn-cv-ico{color:#14234A}',
    '.mn-cestino.mn-sopra{transform:scale(1.05);box-shadow:0 0 0 3px #0075E3,0 12px 26px rgba(0,20,60,.2)}',
    '.mn-tutte{display:flex;align-items:center;gap:10px;width:100%;margin-top:12px;padding:14px 16px;border:0;border-radius:16px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:800 15px var(--font-body);cursor:pointer;text-align:left}.mn-tutte svg{color:#0075E3}.mn-tutte small{margin-left:auto;font:600 13px var(--font-body);color:var(--muted,#5B6B86)}',
    '.mn-cf{position:fixed;inset:0;z-index:9600;background:rgba(15,32,65,.45);display:flex;align-items:flex-end}.mn-cf-box{width:100%;max-height:78vh;overflow:auto;background:var(--card,#fff);border-radius:22px 22px 0 0;padding:16px 16px calc(18px + env(safe-area-inset-bottom))}',
    '.mn-cf-testa{display:flex;align-items:center}.mn-cf-testa b{flex:1;font:800 18px var(--font-display,var(--font-body));color:var(--navy,#14234A)}.mn-cf-testa button{width:38px;height:38px;border:0;border-radius:50%;background:transparent;color:var(--muted,#5B6B86);display:grid;place-items:center}',
    '.mn-cf-nota,.mn-cf-vuoto{font:500 14px/1.45 var(--font-body);color:var(--muted,#5B6B86);margin:4px 0 12px}',
    '.mn-cf-riga{display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid var(--line,#E5ECF6)}.mn-cf-riga div{flex:1;min-width:0}.mn-cf-riga b{display:block;font:700 15px var(--font-body);color:var(--navy,#14234A);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mn-cf-riga small{font:500 12.5px var(--font-body);color:var(--muted,#5B6B86)}',
    '.mn-cf-riga button{flex:none;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 13px var(--font-body);padding:9px 12px;cursor:pointer}',
    '.mn-cf-svuota{display:block;width:100%;margin-top:14px;padding:13px;border:0;border-radius:99px;background:transparent;box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);font:700 14px var(--font-body);cursor:pointer}',
    '.mn-tirata{opacity:.35}.mn-fantasma{position:fixed;z-index:9999;pointer-events:none;transform:rotate(-3deg) scale(1.04);box-shadow:0 18px 36px rgba(0,0,0,.35);opacity:.95}'
  ].join('');
  document.head.appendChild(st);
  setTimeout(function(){ try{ mnPaint(); }catch(_){ } }, 600);
})();
