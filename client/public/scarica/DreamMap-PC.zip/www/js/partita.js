/* ===========================================================================================
   LA PARTITA — la pagina del tabellone (dal prototipo di Claude Design, 27/09/2026)

   In alto il tabellone del giorno (Nuovo te contro Vecchio te, da mtState), poi il livello con
   l'anello e i punti (levels.js), la serie e le vittorie di stagione (mgHist), il cammino dei
   livelli con il prossimo premio, come si fanno i punti, il Mind Movie (cinema.js) e il Monito
   (memento.js). Ci si arriva dalla bolla al centro dell'intestazione.
   =========================================================================================== */
registerScreen('s-partita', '<div id="paBody"></div>', { back: 's-home' });

function paApri(){ goId('s-partita'); paPaint(); }
function paIniziale(){ let n = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); n = (u && u.name) || ''; }catch(_){ } return (n || 'T').charAt(0).toUpperCase(); }
function paVittorieStagione(){
  let v = 0, tot = 0;
  try{
    const hist = (typeof mgHist === 'function') ? mgHist() : [];
    const da = Date.now() - 30 * 86400000;
    hist.forEach(function(g){
      if (!g || !g.day || new Date(g.day + 'T12:00:00').getTime() < da) return;
      let neo = 0, old = 0;
      (g.eventi || []).forEach(function(e){ if (!e || e.stornato) return; if (e.chi === 'neo') neo++; else if (e.chi === 'old') old++; });
      if (!neo && !old) return;
      tot++; if (neo > old) v++;
    });
  }catch(_){ }
  return { v: v, tot: tot };
}
function paCammino(info){
  const L = (typeof LV_LEVELS !== 'undefined') ? LV_LEVELS : [];
  if (!L.length) return '';
  const cur = info.level;
  const righe = [];
  for (let n = Math.min(L.length, cur + 3); n >= Math.max(1, cur - 1); n--){
    const l = L[n - 1]; if (!l) continue;
    const qui = n === cur, sotto = n < cur;
    const premio = l.perk ? 'Premio: ' + l.perk : (n === cur + 1 ? 'Mancano ' + info.toNext + ' punti' : l.name + ' · ancora chiuso');
    righe.push('<div class="pa-step' + (qui ? ' qui' : (sotto ? ' fatto' : (l.perk ? ' premio' : ''))) + '"><span class="pa-n">' + n + '</span><div><b>' + esc(qui ? 'Sei qui' : (sotto ? 'Superato' : (l.perk ? l.name : (n === cur + 1 ? 'Prossimo livello' : 'Livello ' + n)))) + '</b><small>' + esc(qui ? l.name + (l.perk ? ' · ' + l.perk : '') : premio) + '</small></div><i>' + (qui ? '📍' : (sotto ? '✓' : (l.perk ? '🎁' : '🔒'))) + '</i></div>');
  }
  return righe.join('');
}
/* 0.9.317, Andrea: "nelle bolle del vecchio te e del nuovo te ci vuole lo stemma della squadra, l'emoji o l'immagine scelta": la stessa
   della slide della partita (scorelook.js, slCrestTag) */
function paStemma(lato, ini){
  try{ if (typeof slCrestTag === 'function'){ const h = slCrestTag(lato, 50); if (h) return h; } }catch(_){ }
  return esc(ini || '');
}
/* 0.9.317: lo stesso tabellone per la scheda Identita' del pannello di Dream (rotta-tab.js, nvpIdentitaPaint) */
function paTabelloneDati(){
  let s = { neo: 0, old: 0 }; try{ s = (typeof mtState === 'function') ? mtState() : s; }catch(_){ }
  const neo = +s.neo || 0, old = +s.old || 0;
  let stag = 'campionato'; try{ stag = (typeof mgCfg === 'function' && mgCfg().season) || 'campionato'; }catch(_){ }
  const etichetta = stag === 'giorno' ? 'Partita di oggi' : (stag === 'tempo' ? 'Partita a tempo · in diretta' : 'Il campionato · in diretta');
  const linea = stag === 'giorno'
    ? (neo > old ? 'Stai vincendo. Finisce a mezzanotte.' : (neo < old ? 'Il Vecchio te è avanti. Hai tempo fino a mezzanotte.' : 'Parità. La prossima mossa decide.'))
    : (neo > old ? 'Stai vincendo il campionato.' : (neo < old ? 'Il Vecchio te è avanti nel campionato.' : 'Parità. La prossima mossa decide.'));
  return { neo: neo, old: old, etichetta: etichetta, linea: linea, ini: paIniziale() };
}
function paPaint(){
  const body = document.getElementById('paBody'); if (!body) return;
  let s = { neo: 0, old: 0 }; try{ s = (typeof mtState === 'function') ? mtState() : s; }catch(_){ }
  const neo = +s.neo || 0, old = +s.old || 0;
  /* 0.9.293, Andrea: "se ha scelto il campionato non c'e' scritto Partita di oggi: il campionato, il risultato in diretta" */
  let stag = 'campionato'; try{ stag = (typeof mgCfg === 'function' && mgCfg().season) || 'campionato'; }catch(_){ }
  const etichetta = stag === 'giorno' ? 'Partita di oggi' : (stag === 'tempo' ? 'Partita a tempo · in diretta' : 'Il campionato · in diretta');
  const linea = stag === 'giorno'
    ? (neo > old ? 'Stai vincendo. Finisce a mezzanotte.' : (neo < old ? 'Il Vecchio te è avanti. Hai tempo fino a mezzanotte.' : 'Parità. La prossima mossa decide.'))
    : (neo > old ? 'Stai vincendo il campionato.' : (neo < old ? 'Il Vecchio te è avanti nel campionato.' : 'Parità. La prossima mossa decide.'));
  let info = { level: 1, name: 'Seme', xp: 0, toNext: 0, pct: 0, next: null };
  try{ if (typeof lvInfo === 'function') info = lvInfo(); }catch(_){ }
  const deg = Math.round(Math.max(0, Math.min(100, info.pct || 0)) * 3.6);
  let serie = 0, record = 0;
  try{ serie = (typeof serStreak === 'function') ? serStreak() : 0; }catch(_){ }
  try{ const r = JSON.parse(localStorage.getItem('fl_records') || 'null'); record = (r && r.streak) || 0; }catch(_){ }
  const vs = paVittorieStagione();
  let porta = 'chiusa', mancano = '';
  try{ const c = cnControlla(); porta = cnPorta(c); mancano = (c && c.mancano) ? 'Mancano ' + c.mancano + ' vittorie.' : ''; }catch(_){ }
  const ini = paIniziale();
  body.innerHTML = '<div class="pa-page">'
    + '<div class="pa-testa"><div class="pa-top"><button type="button" class="pa-back" aria-label="Indietro" onclick="flIndietro()"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><small>' + esc(etichetta) + '</small><button type="button" class="pa-x" aria-label="Chiudi" onclick="paChiudi()"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>'
    +   '<div class="pa-tab"><div class="pa-lato"><span class="pa-av old">' + paStemma('Old', ini) + '</span><small>Vecchio te</small></div><div class="pa-score">' + old + '<i>:</i>' + neo + '</div><div class="pa-lato"><span class="pa-av neo">' + paStemma('Neo', ini) + '</span><small>Nuovo te</small></div></div>'
    +   '<p>' + esc(linea) + '</p></div>'
    /* 0.9.293, Andrea: "il riscaldamento di START anche nella pagina della partita, prima del livello; quando e' finito
       sparisce" (rscHtml torna vuoto a riscaldamento finito) */
    + '<div id="paRisc" class="pa-risc"></div>'
    /* 0.9.299, Andrea: le statistiche come a fine partita in FIFA (partita-stats.js). 0.9.300: "mettile dopo la
       sezione riscaldamento" */
    + '<div id="pstBox" class="pst"></div>'
    + '<div class="pa-liv"><div class="pa-ring" style="background:conic-gradient(#0075E3 0 ' + deg + 'deg,#E3F1FF ' + deg + 'deg 360deg)"><div><b>' + info.level + '</b><small>livello</small></div></div>'
    +   '<div class="pa-liv-in"><b>' + esc(info.name || '') + '</b><div class="pa-bar"><i style="width:' + (info.pct || 0) + '%"></i></div><small>' + (info.xp || 0).toLocaleString('it-IT') + ' punti' + (info.next ? ' · ancora ' + info.toNext + ' al livello ' + (info.level + 1) : ' · livello massimo') + '</small></div></div>'
    + '<div class="pa-sez"><b>Il tuo cammino</b></div><div class="pa-steps">' + paCammino(info) + '</div>'
    /* 0.9.293, Andrea: "le vittorie del mese e la serie record dopo le regole, prima del registro dei punti" */
    + ((typeof mdRiquadroHtml === 'function') ? mdRiquadroHtml() : '')
    + '<div class="pa-due"><div class="pa-stat"><span>🔥</span><b>' + serie + (serie === 1 ? ' giorno' : ' giorni') + '</b><small>di serie · record ' + Math.max(record, serie) + '</small></div><div class="pa-stat"><span>🏆</span><b>' + vs.v + ' / ' + Math.max(vs.tot, 1) + '</b><small>vittorie del mese</small></div></div>'
    /* LE REGOLE NON SONO PIU' SCRITTE NEL CODICE: le sceglie chi gioca (modelli.js); stanno sopra, prima della serie. */
    /* IL REGISTRO DEI PUNTI sta qui dalla 0.9.171: e' la cronaca di QUESTA partita, e nel
       Report era una riga fra i grafici dello schermo che non c'entrava. */
    + paRegistroHtml()
    + '<button type="button" class="pa-movie" onclick="paMindMovie()"><div><span>' + (porta === 'aperta' ? '✨' : '🔒') + '</span><b>Mind Movie</b><small>' + esc(porta === 'aperta' ? 'La sala è aperta: guarda il film della tua vita.' : ('Il film della tua stagione. ' + (mancano || 'Si apre vincendo la stagione.'))) + '</small>'
    /* 0.9.326, Andrea: "non deve comparire perche' il mind movie e' bloccato: deve essere un pulsante dentro al pannello, disabilitato" */
    + (porta === 'aperta'
        ? '<span class="pa-movie-b" role="button" onclick="event.stopPropagation();if(typeof monApri===\'function\')monApri({ manuale: true, ritorno: \'s-partita\' });else if(typeof mmOpen===\'function\')mmOpen(\'s-partita\')">Guarda dove vai se non cambi niente</span>'
        : '<span class="pa-movie-b off" aria-disabled="true">Guarda dove vai se non cambi niente</span>')
    + '</div></button>'
    + '<div class="pa-spazio"></div>'
    + '<button type="button" class="am-cta" onclick="goId(\'s-home\');if(typeof stGoFocus===\'function\')stGoFocus();else ffOpen()">Gioca la prossima mossa</button>'
    + '</div>';
  try{ if (typeof pstPaint === 'function') pstPaint(); }catch(_){ }
  try{ if (typeof rscPaint === 'function') rscPaint(); }catch(_){ }
}
/* 0.9.294, Andrea: "sono rimasto intrappolato nella partita: manca la X in alto a destra". La X chiude tutto e torna alla
   scheda da cui si era partiti. */
function paChiudi(){
  let tab = '';
  try{ for (let i = NAV_STORIA.length - 1; i >= 0; i--){ if (NAV_STORIA[i].s === 's-home' && NAV_STORIA[i].tab){ tab = NAV_STORIA[i].tab; break; } } }catch(_){ }
  if (typeof navCasa === 'function') navCasa(tab || 'sveglia'); else { goId('s-home'); try{ switchTab(tab || 'sveglia'); }catch(_){ } }
}
function paMindMovie(){ if (typeof vzApri === 'function') vzApri(); }
function paRegistroHtml(){
  let n = 0, ultimo = null;
  try{
    const ev = (typeof insPuntiEventi === 'function') ? insPuntiEventi() : [];
    n = ev.length; ultimo = ev[0] || null;
  }catch(_){ }
  const riga = ultimo
    ? (ultimo.chi === 'old' ? 'Ultimo: punto al Vecchio te' : 'Ultimo: punto al Nuovo te') + (ultimo.motivo ? ', ' + ultimo.motivo : '')
    : 'Ancora nessun punto negli ultimi 14 giorni.';
  return '<button type="button" class="pa-reg" onclick="if(typeof insApriRegistro===\'function\')insApriRegistro(\'s-partita\')">'
    + '<span class="pa-reg-ico">📝</span>'
    + '<div><b>Il registro dei punti</b><small>' + n + (n === 1 ? ' punto' : ' punti') + ' negli ultimi 14 giorni</small>'
    + '<em>' + esc(riga) + '</em></div><span class="chev"></span></button>';
}

(function(){
  const css = [
    '#s-partita{padding:0}',
    '.pa-page{display:flex;flex-direction:column;gap:24px;padding:0 16px calc(28px + env(safe-area-inset-bottom,0px))}',
    '.pa-testa{margin:0 -16px;background:linear-gradient(170deg,#0B3F7A,#001E44);color:#fff;border-radius:0 0 32px 32px;padding:calc(56px + env(safe-area-inset-top,0px)) 20px 28px;display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.pa-top{width:100%;display:flex;justify-content:space-between;align-items:center}.pa-top small{font:600 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#8CC6FF}.pa-top span{width:40px}',
    /* 0.9.291: l'icona della freccia nell'angolo in alto a sinistra, lontana dalla bolla del Vecchio te */
    '.pa-testa{position:relative}.pa-back{position:absolute;top:calc(14px + env(safe-area-inset-top,0px));left:14px;width:42px;height:42px;border-radius:21px;border:0;background:rgba(255,255,255,.12);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.pa-top{justify-content:center}.pa-top span{display:none}',
    '.pa-x{position:absolute;top:calc(14px + env(safe-area-inset-top,0px));right:14px;width:42px;height:42px;border-radius:21px;border:0;background:rgba(255,255,255,.12);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2}',
    '.pa-tab{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:12px;width:100%;margin-top:20px}',
    '.pa-lato{display:flex;flex-direction:column;align-items:center;gap:6px}.pa-lato small{font:600 12px var(--font-body)}',
    '.pa-av img.sl-crest{display:block;border-radius:50%;object-fit:cover}',
    '.pa-av{width:64px;height:64px;border-radius:32px;display:flex;align-items:center;justify-content:center;font:800 32px var(--font-display);line-height:1;overflow:hidden}.pa-av.neo{background:#0075E3;box-shadow:0 0 0 4px rgba(63,159,244,.35)}.pa-av.old{background:rgba(255,255,255,.12);color:rgba(255,255,255,.6)}',
    '.pa-score{font:900 56px var(--font-display);letter-spacing:-.02em;font-variant-numeric:tabular-nums}.pa-score i{font-style:normal;opacity:.35;margin:0 8px}',
    '.pa-testa p{margin:16px 0 0;font:500 13px var(--font-body);color:rgba(255,255,255,.75)}',
    '.pa-liv{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:20px;display:flex;align-items:center;gap:16px}body.dark .pa-liv{background:#12203A;border-color:#22345A}',
    '.pa-ring{width:76px;height:76px;flex:none;border-radius:38px;display:flex;align-items:center;justify-content:center}.pa-ring > div{width:62px;height:62px;border-radius:31px;background:var(--card,#fff);display:flex;flex-direction:column;align-items:center;justify-content:center}body.dark .pa-ring > div{background:#12203A}',
    '.pa-ring b{font:900 24px/1 var(--font-display);color:var(--navy)}body.dark .pa-ring b{color:#fff}.pa-ring small{font:500 9px var(--font-body);color:var(--faint)}',
    '.pa-liv-in{flex:1;display:flex;flex-direction:column;gap:6px;text-align:left}.pa-liv-in > b{font:800 18px var(--font-display);color:var(--navy)}body.dark .pa-liv-in > b{color:#fff}',
    '.pa-bar{height:10px;border-radius:5px;background:#E3F1FF;overflow:hidden}.pa-bar i{display:block;height:100%;border-radius:5px;background:linear-gradient(90deg,#3F9FF4,#0075E3)}body.dark .pa-bar{background:rgba(255,255,255,.12)}',
    '.pa-liv-in small{font:500 12px var(--font-body);color:var(--muted)}',
    '.pa-due{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.pa-risc:empty{display:none}',
    /* 0.9.293, Andrea: "il pannello delle regole in questa pagina scuro, con il testo chiaro" */
    '.pa-page .pa-regole{background:linear-gradient(160deg,#0E2350,#0B3E86);border-color:transparent;color:#fff}',
    '.pa-page .pa-regole > b,.pa-page .pa-regole > div,.pa-page .pa-regole .md-p{color:#fff}',
    '.pa-page .pa-regole > div small{color:rgba(255,255,255,.65)}',
    '.pa-page .pa-regole > div b{color:#7CC4FF}.pa-page .pa-regole > div b.rosso{color:#FF8A94}',
    '.pa-page .pa-regole p{color:rgba(255,255,255,.72);border-top-color:rgba(255,255,255,.16)}',
    '.pa-page .pa-regole .am-link{color:#7CC4FF}',
    '.pa-stat{background:var(--card,#fff);border:1px solid var(--line);border-radius:20px;padding:16px;text-align:center}body.dark .pa-stat{background:#12203A;border-color:#22345A}',
    '.pa-stat span{font-size:24px}.pa-stat b{display:block;font:800 22px var(--font-display);color:var(--navy)}body.dark .pa-stat b{color:#fff}.pa-stat small{font:500 12px var(--font-body);color:var(--faint)}',
    '.pa-sez{text-align:center}.pa-sez b{font:800 20px var(--font-display);color:var(--navy)}body.dark .pa-sez b{color:#fff}',
    '.pa-steps{display:flex;flex-direction:column;gap:12px;margin-top:-12px}',
    '.pa-step{display:flex;align-items:center;gap:12px;background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;padding:12px 16px;color:var(--navy)}body.dark .pa-step{background:#12203A;border-color:#22345A;color:#fff}',
    '.pa-step.qui{background:var(--blue-soft,#E3F1FF);border:2px solid #0075E3}body.dark .pa-step.qui{background:#0F2A4A}.pa-step.premio{background:#001E44;border-color:#001E44;color:#fff}.pa-step.fatto{color:var(--faint)}',
    '.pa-n{width:40px;height:40px;flex:none;border-radius:20px;background:var(--blue-soft,#E3F1FF);color:var(--navy);display:flex;align-items:center;justify-content:center;font:800 15px var(--font-display)}.pa-step.qui .pa-n,.pa-step.premio .pa-n{background:#0075E3;color:#fff}.pa-step.fatto .pa-n{background:var(--bg,#F4F9FF);color:var(--faint)}',
    '.pa-step > div{flex:1;text-align:left}.pa-step b{display:block;font:700 14px var(--font-display)}.pa-step small{display:block;font:500 12px var(--font-body);opacity:.75}.pa-step i{font-style:normal;font-size:18px;opacity:.8}',
    '.pa-regole{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:20px;display:flex;flex-direction:column;gap:12px}body.dark .pa-regole{background:#12203A;border-color:#22345A}',
    '.pa-regole > b{font:800 18px var(--font-display);color:var(--navy);text-align:center}body.dark .pa-regole > b{color:#fff}',
    '.pa-regole > div{display:flex;justify-content:space-between;gap:12px;font:500 14px var(--font-body);color:var(--navy)}body.dark .pa-regole > div{color:#fff}.pa-regole > div b{color:#0075E3}.pa-regole > div b.rosso{color:#E63946}.pa-regole > div.muto{color:var(--faint)}.pa-regole > div.muto b{color:var(--faint)}',
    '.pa-regole p{margin:0;font:500 12px/1.5 var(--font-body);color:var(--muted);text-align:center;border-top:1px solid var(--line);padding-top:12px}',
    '.pa-movie{border:0;padding:0;border-radius:24px;overflow:hidden;position:relative;height:230px;background:#001E44 url(img/dream-night.jpg) center/cover;color:#fff;cursor:pointer;text-align:center}',
    '.pa-movie > div{position:absolute;inset:0;background:rgba(0,19,43,.6);backdrop-filter:blur(3px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;padding:16px}.pa-movie span{font-size:28px}.pa-movie b{font:800 18px var(--font-display)}.pa-movie small{font:500 13px var(--font-body);opacity:.85}',
    '.pa-movie .pa-movie-b{margin-top:10px;padding:10px 16px;border-radius:99px;background:#fff;color:#001E44;font:700 13px var(--font-body)}.pa-movie .pa-movie-b.off{background:rgba(255,255,255,.14);color:rgba(255,255,255,.55)}',
    '.pa-reg{display:flex;align-items:center;gap:14px;width:100%;background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:18px 20px;cursor:pointer;text-align:left;color:var(--navy)}',
    'body.dark .pa-reg{background:#12203A;border-color:#22345A;color:#fff}',
    '.pa-reg-ico{width:44px;height:44px;flex:none;border-radius:14px;background:var(--blue-soft,#E3F1FF);display:flex;align-items:center;justify-content:center;font-size:22px}body.dark .pa-reg-ico{background:rgba(255,255,255,.08)}',
    '.pa-reg > div{flex:1;min-width:0}.pa-reg b{display:block;font:800 16px var(--font-display)}',
    '.pa-reg small{display:block;margin-top:2px;font:600 12px var(--font-body);color:var(--muted)}',
    '.pa-reg em{display:block;margin-top:6px;font:500 12px/1.4 var(--font-body);font-style:normal;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.pa-spazio{height:8px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
