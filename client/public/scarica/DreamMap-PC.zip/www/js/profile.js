/* profile.js — Profilo, Premium e paywall.
 *
 * THREE THINGS THIS FILE IS RESPONSIBLE FOR, AND WHY THEY LIVE TOGETHER:
 *
 * 1. THE BILLING ABSTRACTION (`Premium`). Everything else in the app asks one question —
 *    "is this user paying?" — and it must have exactly one answer. ads.js gates on it, the
 *    paywall gates on it, Profilo prints it. There is no Play Console account yet, so the
 *    implementation underneath is FAKE and says so out loud; the seam where RevenueCat or
 *    Play Billing gets plugged in is a single function, registerBillingProvider().
 *
 * 2. THE PAYWALL (screen s11). It is rebuilt from here rather than edited in index.html,
 *    because index.html is shared by six lanes and is frozen. What was there before had to
 *    go for legal reasons, not cosmetic ones — see the block above rebuildPaywall().
 *
 * 3. THE PROFILO TAB. Honest account state (there is no backend, so nothing syncs), the real
 *    permission state read back from the engine, the app version, the legal links, the
 *    permanent "Impostazioni privacy" entry AdMob requires, and the way back into the strict
 *    mode wizard.
 *
 * Style: injected from here with a `uf-` prefix so it cannot collide with the other lanes'
 * rules; existing classes from css/app.css are reused wherever one already fits.
 */

/* ========================================================================================
 * VERSION / LEGAL — the two constants that have to be updated before publication
 * ====================================================================================== */

/* Mirrors versionName in android/app/build.gradle, which is the number the user sees in
   Profilo and quotes in a support ticket; overwritten at runtime with the real versionName
   read back from the installed package, so this value only shows in a plain browser. */
let APP_VERSION = '0.8.1';

/* ----------------------------------------------------------------------------------------
 * THE PUBLIC ADDRESS OF THE TWO LEGAL DOCUMENTS
 *
 * Google Play requires a privacy policy that is reachable OUTSIDE the app: the copy shipped
 * in www/legal/ satisfies the user, not the reviewer, and a store listing without a working
 * URL is refused before anyone reads a line of it.
 *
 * ⚠️ WHAT ANDREA HAS TO DO — four steps, no code involved:
 *   1. In the repository `Bilots00/dreambrothers-HUB-web-app`, create the folder
 *      `docs/focuslock/` and copy into it the two files as they are:
 *          www/legal/privacy.html  →  docs/focuslock/privacy.html
 *          www/legal/termini.html  →  docs/focuslock/termini.html
 *      Copy, never rewrite: these two files and the published pages must stay the same text.
 *   2. GitHub → Settings → Pages → Source: "Deploy from a branch", branch `main`, folder
 *      `/docs`. Wait for the green check, then open the two addresses below in a browser and
 *      make sure they really answer (a 404 page still returns a page — read what is on it).
 *   3. Flip LEGAL_URLS_PUBLISHED to true here, rebuild, done.
 *   4. Paste the privacy address into Play Console → Store listing → Privacy policy, and into
 *      App content → Data safety. It has to be the same address as the one below.
 *
 * Until step 3 the app behaves exactly as it does today: the documents open from the local
 * files and no network request is made. Even after step 3 the local copy stays the one shown
 * on screen — the published address is offered as an extra link, and only after a probe has
 * confirmed it answers, so a wrong or offline address can never become a dead link.
 * -------------------------------------------------------------------------------------- */
const LEGAL_URLS = {
  termini: 'https://bilots00.github.io/dreambrothers-HUB-web-app/focuslock/termini.html',
  privacy: 'https://bilots00.github.io/dreambrothers-HUB-web-app/focuslock/privacy.html'
};

/* ⬅ the switch of step 3. False = the addresses above are a plan, not a fact. */
const LEGAL_URLS_PUBLISHED = false;

/* null = never probed, false = probed and did not answer, true = answered.
   Only the last one makes legalPublicUrl() return anything. */
let legalPublicOk = null;
let legalProbeRunning = false;

/* The address of a document, but only when there is proof that something is there. Called by
   ueLegalOnlineLink() in onboarding.js to decide whether to show the "Apri online" link. */
function legalPublicUrl(kind){
  if (!LEGAL_URLS_PUBLISHED || legalPublicOk !== true) return '';
  const url = LEGAL_URLS[kind === 'termini' || kind === 'terms' ? 'termini' : 'privacy'];
  return (typeof url === 'string' && url.indexOf('https://') === 0) ? url : '';
}

/* One probe per launch, fired when a legal document is opened — never at startup, so an app
   that promises to keep to itself does not phone anything on launch. Its answer decides the
   NEXT open; nothing on screen ever waits for it. A network error, a timeout, a 404: all of
   them land on false, and false means the user simply keeps reading the local copy. */
function legalProbePublic(){
  if (!LEGAL_URLS_PUBLISHED || legalPublicOk !== null || legalProbeRunning) return;
  if (typeof fetch !== 'function') { legalPublicOk = false; return; }
  legalProbeRunning = true;
  let ctrl = null, timer = null;
  try { ctrl = new AbortController(); timer = setTimeout(() => ctrl.abort(), 2500); } catch(e){}
  fetch(LEGAL_URLS.privacy, { method: 'GET', cache: 'no-store', signal: ctrl ? ctrl.signal : undefined })
    .then(res => { legalPublicOk = !!(res && res.ok); })
    .catch(() => { legalPublicOk = false; })
    .then(() => { if (timer) clearTimeout(timer); legalProbeRunning = false; });
}

/* ========================================================================================
 * 1 · BILLING ABSTRACTION
 * ====================================================================================== */

/* The catalogue. Prices are the ones the product already used (2,49 €/mese, 29,99 €/anno);
   the discounted 20,99 € is 30% off the annual price and 1,75 € is that figure divided by
   twelve. No number here is invented — every one of them is derived from those two.
   `id` is the Play Console product id that will have to be created with exactly these names. */
const PREMIUM_PLANS = {
  annual: {
    id: 'focuslock_premium_annual',
    label: 'Premium annuale',
    listPrice: '29,99 €',
    price: '20,99 €',
    perMonth: '1,75 €',
    discount: '30%',
    billing: 'Addebito ogni anno'
  },
  monthly: {
    id: 'focuslock_premium_monthly',
    label: 'Premium mensile',
    listPrice: '2,49 €',
    price: '2,49 €',
    perMonth: '2,49 €',
    discount: null,
    billing: 'Addebito ogni mese'
  }
};

/* ⚠️ PREMIUM ACCESO PER LE PROVE.
   Finche' si sta costruendo, tutto quello che e' dietro a Premium deve essere visibile: la
   prova di sette giorni era scaduta e mezza app si era chiusa a chiave proprio mentre la si
   stava disegnando. Questa riga e' l'unica cosa da togliere quando arriva il pagamento vero
   (e la cerca chiunque grep-pi «DEBUG»): non tocca il provider, non finge un acquisto, e nel
   Profilo la riga dell'abbonamento dice esattamente che e' una prova di sviluppo. */
const FL_DEBUG_PREMIUM = true;

const Premium = (function(){
  const KEY = 'fl_premium';
  const listeners = [];

  /* The seam. A real provider is an object with these four methods; until one is registered
     every call falls through to the honest refusal below. */
  let provider = null;

  function notify(){ listeners.forEach(fn => { try { fn(); } catch(e){} }); }

  /* ------------------------------------------------------------------------------------
     ⚠️⚠️  FAKE IMPLEMENTATION — NO PURCHASE IS EVER MADE HERE  ⚠️⚠️

     FocusLock has no Google Play Console account yet, so there is no product to buy and no
     receipt to verify. The one thing this stub must never do is pretend otherwise: buy() and
     restore() FAIL, loudly and in plain Italian, and neither of them ever writes the premium
     flag. A stub that flipped the flag would be worse than useless — it would ship an app
     that tells users they paid when they did not.

     TO GO LIVE, replace nothing in this file except the provider. Either:

       A) RevenueCat — npm i @revenuecat/purchases-capacitor, then somewhere after login:
            registerBillingProvider({
              isPremium: () => cachedEntitlements.active['premium'] != null,
              buy:      async (planId) => { await Purchases.purchasePackage({...}); return {ok:true}; },
              restore:  async () => { const i = await Purchases.restorePurchases(); return {ok: ...}; },
              refresh:  async () => { cachedEntitlements = await Purchases.getCustomerInfo(); }
            });
          RevenueCat is the shorter road: it does receipt validation and the cross-device
          entitlement server we do not have.

       B) Play Billing directly — @capacitor-community/in-app-purchases (or a native wrapper).
          Cheaper per sale, but then WE own receipt verification, and without a backend the
          entitlement lives only on the device.

     What is needed either way, and cannot be done from code:
       · a Google Play Console developer account (25 $ one-off);
       · the app uploaded at least once to a closed track — subscriptions cannot be created
         before a build with the Billing library exists in the console;
       · the two subscription products created with the ids in PREMIUM_PLANS above;
       · for a personal developer account opened after Nov 2023: 12 testers for 14 days
         before production access can even be requested;
       · licence testers added, otherwise every test purchase is a real charge.
     ---------------------------------------------------------------------------------- */
  const FAKE_MESSAGE = 'Gli acquisti non sono ancora attivi: DreamMap non ha ancora un account '
    + 'Google Play. Non è stato fatto nessun addebito e non è stata sbloccata nessuna funzione.';

  const fallback = {
    isPremium(){
      if (FL_DEBUG_PREMIUM) return true;
      // True if something local set it (see __flDevSetPremium below) or if a Guest Pass from
      // the server is still running (fl_premium_until, mirrored by partner.js). Never set by buy().
      try {
        if (localStorage.getItem(KEY) === '1') return true;
        const until = localStorage.getItem('fl_premium_until');
        return !!(until && new Date(until).getTime() > Date.now());
      } catch(e){ return false; }
    },
    async buy(){ return { ok:false, reason:'not-configured', message: FAKE_MESSAGE }; },
    async restore(){ return { ok:false, reason:'not-configured', message: FAKE_MESSAGE }; },
    async refresh(){}
  };

  return {
    /* The single source of truth for "is this user paying". ads.js reads it before touching
       the AdMob SDK, so getting this wrong means either ads on paying users or an SDK that
       was started for someone who paid not to have it. */
    isPremium(){
      if (FL_DEBUG_PREMIUM) return true;
      try { return provider ? !!provider.isPremium() : fallback.isPremium(); }
      catch(e){ return false; }
    },
    /* Which implementation is answering — printed in Profilo so nobody has to guess whether
       a build has real billing wired up. */
    source(){ return provider ? (provider.name || 'provider') : 'non configurato'; },
    configured(){ return !!provider; },
    plans(){ return PREMIUM_PLANS; },
    plan(key){ return PREMIUM_PLANS[key] || PREMIUM_PLANS.annual; },

    async buy(planKey){
      const p = (provider || fallback);
      const plan = PREMIUM_PLANS[planKey] || PREMIUM_PLANS.annual;
      let res;
      try { res = await p.buy(plan.id, plan); }
      catch(e){ res = { ok:false, reason:'error', message: (e && e.message) || 'Acquisto non riuscito' }; }
      if (res && res.ok) notify();
      return res || { ok:false, reason:'error', message:'Acquisto non riuscito' };
    },
    async restore(){
      const p = (provider || fallback);
      let res;
      try { res = await p.restore(); }
      catch(e){ res = { ok:false, reason:'error', message: (e && e.message) || 'Ripristino non riuscito' }; }
      if (res && res.ok) notify();
      return res || { ok:false, reason:'error', message:'Ripristino non riuscito' };
    },
    async refresh(){
      try { await (provider || fallback).refresh(); notify(); } catch(e){}
    },
    onChange(fn){ if (typeof fn === 'function') listeners.push(fn); },
    _notify: notify,
    _install(impl){ provider = impl; notify(); }
  };
})();

/* A top-level `const` in a classic script lives in the global lexical scope and is NOT a
   property of window, so anything reaching for it through `window.` (a console session, a
   future module, a native callback) would get undefined. Mirrored once, here. */
window.Premium = Premium;

/* THE ONE FUNCTION TO CALL when real billing arrives. Everything else — paywall, ads gating,
   Profilo — already reads through Premium and needs no change. */
function registerBillingProvider(impl){ Premium._install(impl); }

/* QA only, deliberately not reachable from any button: lets a tester flip the entitlement from
   the browser/adb console to verify the ad gating in both directions. It writes the same local
   flag the fallback reads, so it disappears the moment a real provider is registered. */
function __flDevSetPremium(on){
  try { on ? localStorage.setItem('fl_premium','1') : localStorage.removeItem('fl_premium'); } catch(e){}
  Premium._notify();
  renderProfile();
  return Premium.isPremium();
}

/* ========================================================================================
 * STYLE (prefixed uf-, injected from here: css/app.css is frozen)
 * ====================================================================================== */
(function ufInjectStyle(){
  const s = document.createElement('style');
  s.id = 'uf-profile-style';
  s.textContent = `
  .uf-pw-head{display:flex;align-items:center;gap:10px;margin:2px 0 2px}
  .uf-pw-gem{font-size:26px}
  .uf-pw-title{font:800 26px/1.1 var(--font-display);font-style:italic;color:var(--navy)}
  .uf-pw-sub{font:500 12.5px var(--font-body);color:var(--muted);margin-bottom:14px}

  .uf-inc{background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);
    padding:16px;box-shadow:var(--shadow)}
  .uf-inc-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
  .uf-inc-top b{font:800 15px var(--font-display);font-style:italic;color:var(--navy)}
  .uf-inc-top span{font:700 9.5px var(--font-body);letter-spacing:.09em;color:var(--blue);
    background:var(--blue-soft);padding:4px 9px;border-radius:99px}
  .uf-ben{display:flex;gap:11px;align-items:flex-start;padding:9px 0;border-top:1px solid var(--line)}
  .uf-ben:first-of-type{border-top:none;padding-top:0}
  .uf-ben i{font-style:normal;font-size:18px;line-height:1.2;flex:none;width:24px;text-align:center}
  .uf-ben b{display:block;font:700 13px var(--font-body);color:var(--navy);margin-bottom:2px}
  .uf-ben p{font:500 11.5px/1.5 var(--font-body);color:var(--muted)}
  .uf-noads{display:flex;align-items:center;gap:8px;margin-top:12px;padding:10px 12px;
    background:var(--blue-soft);border-radius:12px;font:600 11.5px var(--font-body);color:var(--blue-deep)}

  .uf-price{text-align:center;margin-top:16px}
  .uf-disc{display:inline-block;background:var(--red);color:#fff;font:800 10px var(--font-body);
    letter-spacing:.05em;padding:4px 11px;border-radius:99px;margin-bottom:8px}
  .uf-plan-name{font:700 13px var(--font-body);color:var(--muted)}
  .uf-amount{font:800 34px/1.1 var(--font-display);font-style:italic;color:var(--navy);margin-top:2px}
  .uf-amount s{font:700 16px var(--font-display);font-style:normal;color:var(--faint);margin-right:9px}
  .uf-amount-sub{font:600 12px var(--font-body);color:var(--blue);margin-top:3px}

  .uf-plans{display:none;margin-top:12px}
  .uf-plans.on{display:block}
  .uf-planrow{display:flex;align-items:center;gap:11px;width:100%;text-align:left;background:#fff;
    border:1.5px solid var(--line);border-radius:14px;padding:12px 14px;margin-bottom:8px;cursor:pointer;
    font-family:var(--font-body)}
  .uf-planrow.sel{border-color:var(--blue);background:var(--blue-soft)}
  .uf-planrow .uf-radio{width:18px;height:18px;border-radius:50%;border:2px solid var(--line);flex:none}
  .uf-planrow.sel .uf-radio{border-color:var(--blue);background:radial-gradient(circle,var(--blue) 0 45%,#fff 47%)}
  .uf-planrow b{display:block;font:700 13px var(--font-body);color:var(--navy)}
  .uf-planrow small{font:500 11px var(--font-body);color:var(--muted)}
  .uf-planrow em{margin-left:auto;font-style:normal;font:800 14px var(--font-display);color:var(--navy)}

  .uf-links{display:flex;justify-content:center;gap:16px;flex-wrap:wrap;margin-top:14px}
  .uf-links button{border:none;background:none;cursor:pointer;font:600 11.5px var(--font-body);
    color:var(--blue);text-decoration:underline;padding:2px;font-family:var(--font-body)}
  .uf-legal{font:500 10px/1.55 var(--font-body);color:var(--faint);margin-top:12px;text-align:left}
  .uf-legal b{color:var(--muted);font-weight:700}

  .uf-offer{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:10px;
    font:700 12px var(--font-body);color:var(--red-deep)}
  .uf-offer.gone{color:var(--faint);font-weight:600}
  .uf-cd{font-variant-numeric:tabular-nums}

  .uf-menu{position:absolute;right:20px;top:56px;z-index:60;background:#fff;border:1px solid var(--line);
    border-radius:14px;box-shadow:0 18px 44px rgba(0,30,68,.20);padding:6px;display:none;min-width:212px}
  .uf-menu.on{display:block}
  .uf-menu button{display:block;width:100%;text-align:left;border:none;background:none;cursor:pointer;
    padding:10px 12px;border-radius:10px;font:600 12.5px var(--font-body);color:var(--navy);font-family:var(--font-body)}
  .uf-menu button:hover{background:var(--blue-soft)}

  .uf-honest{display:flex;gap:9px;align-items:flex-start;background:#fff;border:1px solid var(--line);
    border-radius:14px;padding:12px 13px;margin-bottom:12px}
  .uf-honest span{font-size:15px;line-height:1.3;flex:none}
  .uf-honest p{font:500 11.5px/1.55 var(--font-body);color:var(--muted)}
  .uf-honest p b{color:var(--navy);font-weight:700}

  .uf-ver{text-align:center;font:500 11px var(--font-body);color:var(--faint);margin:16px 0 4px}
  `;
  document.head.appendChild(s);
})();

/* Local escaper: nav.js defines esc() but loads after this file, and the paywall and the
   Profilo tab are both built at load time. */
function ufEsc(s){
  return String(s == null ? '' : s).replace(/[&<>"]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
}

/* ========================================================================================
 * 2 · PAYWALL (s11)
 * ====================================================================================== */

/* WHAT WAS REMOVED HERE, AND WHY IT COULD NOT STAY (gap analysis R7/R8, G61, G68):
 *   · three reviews signed "Marco R.", "Giulia T.", "Andrea P." — invented. Fabricated
 *     testimonials are misrepresentation under the Play Store policy: not a stylistic
 *     objection, a rejection reason.
 *   · "150k+ utenti felici" and "4,8 ★" — invented too. FocusLock has never been published,
 *     so there is no user count and no rating to quote.
 *   · "Un solo abbonamento: app mobile E programma Desktop" and "Sincronizzato col tuo PC" —
 *     there is no desktop program and no backend. Selling a feature that does not exist is
 *     the same policy violation seen from the other side.
 * What replaced them are claims anyone can verify by using the app: what Premium unlocks,
 * that Premium removes the ads, and that the subscription is cancelled from Google Play.
 * NOTHING here may be replaced by a number until there are real users to count. */

let pwPlan = 'annual';           // which plan the CTA will buy
let pwOfferTimer = null;

/* The countdown is real, and that matters: an offer that resets on every app launch is a
   dark pattern. The deadline is written once and honoured — when it passes the discount is
   actually gone and the paywall shows the full price. */
const OFFER_MINUTES = 60;
function pwOfferDeadline(){
  let v = 0;
  try { v = +(localStorage.getItem('fl_offer_until') || 0); } catch(e){}
  if (!v){
    v = Date.now() + OFFER_MINUTES * 60000;
    try { localStorage.setItem('fl_offer_until', String(v)); } catch(e){}
  }
  return v;
}
function pwOfferAlive(){ return Date.now() < pwOfferDeadline(); }

function pwBenefitsHTML(){
  /* Four advantages, each one mapped onto something the app actually does. The wording
     follows AppBlock's paywall (gap analysis §1.5) because the brief asks for parity, but
     every description was rewritten to describe OUR features, not theirs. */
  const B = [
    ['🛡','Blocco illimitato',
     'Blocca tutte le app, i siti e le parole chiave che vuoi, con quanti programmi vuoi. Nella versione gratuita i programmi attivi sono limitati.'],
    ['⚡','Modalità severa completa',
     'Tutti i metodi di sblocco: PIN, attesa prima di cedere, blocco fino a una data. Nella versione gratuita ne sono disponibili solo i primi.'],
    ['📊','Statistiche precise',
     'Tempo di schermo reale letto da Android, app più usate, andamento giorno per giorno e per fascia oraria.'],
    ['💾','Import, export e backup',
     'Importa le liste da un file CSV, esporta le tue regole e rimettile su un altro telefono senza riscriverle.']
  ];
  return B.map(b => `<div class="uf-ben"><i>${b[0]}</i><div><b>${ufEsc(b[1])}</b><p>${ufEsc(b[2])}</p></div></div>`).join('');
}

function pwPriceHTML(){
  const p = Premium.plan(pwPlan);
  const discounted = (pwPlan === 'annual') && pwOfferAlive() && p.discount;
  const amount = discounted
    ? `<s>${ufEsc(p.listPrice)}</s>${ufEsc(p.price)}`
    : ufEsc(p.listPrice);
  const perMonth = discounted ? p.perMonth : (pwPlan === 'annual' ? '2,50 €' : p.perMonth);
  return `
    ${discounted ? `<div class="uf-disc">${ufEsc(p.discount)} DI SCONTO!</div>` : ''}
    <div class="uf-plan-name">${ufEsc(p.label)}</div>
    <div class="uf-amount">${amount}</div>
    <div class="uf-amount-sub">${ufEsc(p.billing)} · ${ufEsc(perMonth)} / mese</div>`;
}

function pwPlansHTML(){
  return Object.keys(PREMIUM_PLANS).map(k => {
    const p = PREMIUM_PLANS[k];
    const show = (k === 'annual' && pwOfferAlive() && p.discount) ? p.price : p.listPrice;
    return `<button class="uf-planrow${k === pwPlan ? ' sel' : ''}" data-plan="${k}" onclick="pwPickPlan('${k}')">
      <span class="uf-radio"></span>
      <span><b>${ufEsc(p.label)}</b><small>${ufEsc(p.billing)}</small></span>
      <em>${ufEsc(show)}</em>
    </button>`;
  }).join('');
}

/* The auto-renewal disclosure. Play rejects a subscription paywall that does not state, on
   the purchase screen itself, what is charged, when, at what price it renews and how to
   cancel. Every clause below is required; none of it is decoration. */
function pwLegalHTML(){
  return `<div class="uf-legal">
    <b>Rinnovo automatico.</b> Pagando confermi che: l’importo viene addebitato sul tuo account
    Google Play al momento della conferma dell’acquisto; l’abbonamento si rinnova automaticamente
    al prezzo di listino — 29,99 € l’anno per il piano annuale, 2,49 € al mese per quello mensile —
    salvo disdetta effettuata almeno 24 ore prima della fine del periodo in corso; il prezzo
    scontato di 20,99 € vale solo per il primo anno, dal secondo anno l’addebito è di 29,99 €;
    il rinnovo viene addebitato nelle 24 ore che precedono la scadenza del periodo; puoi gestire
    o disdire l’abbonamento in qualsiasi momento da Google Play → Pagamenti e abbonamenti →
    Abbonamenti; la disdetta ha effetto alla fine del periodo già pagato e non dà diritto al
    rimborso della parte non utilizzata; gli eventuali rimborsi sono gestiti da Google Play
    secondo le sue condizioni.
  </div>`;
}

function rebuildPaywall(){
  // The paywall is back on the owner's request. It stays honest: with no billing provider the
  // subscribe button says so, and the three ways that DO give Premium today are on the page —
  // the 7-day trial, the gift card, the Guest Pass.

  const s11 = document.getElementById('s11');
  if (!s11) return;
  s11.innerHTML = `
    <div class="topbar">
      <button class="iconbtn" onclick="pwClose()">✕</button>
      <div class="spacer"></div>
      <button class="iconbtn" onclick="pwToggleMenu()" aria-label="Altro">⋮</button>
    </div>
    <div class="uf-menu" id="uf-pw-menu">
      <button onclick="pwToggleMenu();openLegal('terms')">Condizioni d’Uso</button>
      <button onclick="pwToggleMenu();openLegal('privacy')">Informativa sulla privacy</button>
      <button onclick="pwToggleMenu();adsPrivacySettings()">Impostazioni privacy</button>
    </div>

    <div class="uf-pw-head"><span class="uf-pw-gem">💎</span><span class="uf-pw-title">Ottieni Premium</span></div>
    <div class="uf-pw-sub">Goditi DreamMap senza limiti</div>

    <div class="uf-inc">
      <div class="uf-inc-top"><b>Premium</b><span>INCLUDE</span></div>
      ${pwBenefitsHTML()}
      <div class="uf-noads">🚫 Nessuna pubblicità: gli annunci sostengono la versione gratuita, con Premium spariscono del tutto.</div>
    </div>

    <div class="proof">
      <div class="proofbox"><b>0</b><span>annunci con Premium</span></div>
      <div class="proofbox"><b>Disdici<br>quando vuoi</b><span>da Google Play</span></div>
    </div>

    <div class="uf-price" id="uf-price">${pwPriceHTML()}</div>

    <button class="ghost" onclick="pwTogglePlans()" id="uf-more-btn">Altre opzioni</button>
    <div class="uf-plans" id="uf-plans">${pwPlansHTML()}</div>

    <div class="uf-links">
      <button onclick="openLegal('terms')">Condizioni d’Uso</button>
    </div>

    ${pwLegalHTML()}

    <div class="spacer"></div>
    <div id="uf-trial"></div>
    <button class="cta red" onclick="premiumBuy()">Abbonati ora</button>
    <div class="uf-offer" id="uf-offer"></div>
    <div class="sect" style="margin-top:18px"><b>Altri modi per avere Premium</b></div>
    <div class="setrow" onclick="ufOpenUrl('https://dream-brothers.com/products/focuslock-premium-carta-regalo')"><span>🎁</span><b>Carta regalo</b><small>1 anno o Lifetime</small><span class="chev"></span></div>
    <div class="setrow" onclick="frOpen('amici')"><span>🎫</span><b>Pass Ospite</b><small>14 giorni, invitando un amico</small><span class="chev"></span></div>
    <div class="spacer"></div>
  `;
  pwPaintTrial();
  pwTick();
}

/* ---- the 7-day trial ----
   One per install, kept locally like the Guest Pass: it turns Premium on for real for a week,
   which is the only honest version of "prova gratuita" while there is no billing to attach a
   trial to. */
/* ---- SALTA GLI ANNUNCI (0.9.206): la schermata di Duolingo, con il Genio e i colori nostri ----
   Si apre a tappa finita per chi non ha Premium. Prova gratuita di 7 giorni (pwStartTrial), oppure
   «No, grazie» e si va avanti. Chi la prova l'ha gia' usata vede «Scopri Premium». */
function pwUpsellApri(dopo){
  let w = document.getElementById('pwUp');
  if (!w){ w = document.createElement('div'); w.id = 'pwUp'; w.className = 'pw-up'; (document.getElementById('phone') || document.body).appendChild(w); }
  const usata = pwTrialUsed();
  w.innerHTML = '<div class="pw-up-in"><span class="pw-up-badge">PREMIUM</span>'
    + '<h2>' + (usata ? 'Senza annunci, con <i>Premium</i>' : 'Salta gli annunci con la prova gratuita di <i>7 giorni</i> di Premium!') + '</h2>'
    + '<div class="pw-up-art"><div class="pw-up-phone"><span class="pw-up-no">⃠</span></div><img src="img/genio/genio-saluta.png" alt=""><i class="pw-up-nuvola"></i></div>'
    + '<p class="pw-up-nota">🔔 ' + (usata ? 'Niente annunci, l’agente, il Full Focus in gruppo e la rotta su misura.' : 'Nessuna carta: fra 7 giorni torna la versione gratuita da sola.') + '</p>'
    + '<button type="button" class="pw-up-cta" onclick="pwUpsellSi()">' + (usata ? 'Scopri Premium' : 'Prova per 0,00 €') + '</button>'
    + '<button type="button" class="pw-up-no-btn" onclick="pwUpsellChiudi()">No, grazie</button></div>';
  w.hidden = false; requestAnimationFrame(function(){ w.classList.add('in'); });
  w._dopo = typeof dopo === 'function' ? dopo : null;
  try{ flVibra(10); }catch(_){ }
}
function pwUpsellChiudi(){ const w = document.getElementById('pwUp'); if (!w) return; const d = w._dopo; w._dopo = null; w.classList.remove('in'); setTimeout(function(){ w.hidden = true; if (d) d(); }, 220); }
function pwUpsellSi(){ const w = document.getElementById('pwUp'); const usata = pwTrialUsed(); pwUpsellChiudi(); if (usata){ setTimeout(function(){ pfApri(); }, 240); return; } try{ pwStartTrial(); }catch(_){ } }
(function(){
  const css = [
    '.pw-up{position:absolute;inset:0;z-index:9996;background:linear-gradient(180deg,#0B2A5B 0%,#001E44 60%,#00132B 100%);color:#fff;opacity:0;transition:opacity .22s;display:flex;flex-direction:column}.pw-up.in{opacity:1}.pw-up[hidden]{display:none}',
    '.pw-up-in{flex:1;display:flex;flex-direction:column;align-items:center;padding:calc(env(safe-area-inset-top,0px) + 22px) 24px calc(env(safe-area-inset-bottom,0px) + 26px);text-align:center}',
    '.pw-up-badge{align-self:flex-end;padding:5px 12px;border-radius:99px;background:linear-gradient(90deg,#E71D4F,#0075E3);font:900 12px var(--font-display);letter-spacing:.1em}',
    '.pw-up h2{margin:14px 0 0;font:800 24px/1.3 var(--font-display);color:#fff}.pw-up h2 i{font-style:normal;color:#7FD3FF}',
    '.pw-up-art{position:relative;flex:1;width:100%;max-height:440px;display:flex;align-items:flex-end;justify-content:center;margin:10px 0}.pw-up-phone{position:absolute;top:8%;left:50%;transform:translateX(-50%);width:170px;height:300px;border-radius:30px;background:#fff;border:8px solid #2B3A55;display:flex;align-items:center;justify-content:center}.pw-up-no{font-size:120px;line-height:1;color:#E71D4F}',
    '.pw-up-art img{position:relative;z-index:2;height:190px;width:auto;filter:drop-shadow(0 14px 24px rgba(0,0,0,.45))}.pw-up-nuvola{position:absolute;left:-10%;right:-10%;bottom:-6px;height:90px;background:#fff;border-radius:50% 50% 0 0/100% 100% 0 0;z-index:1}',
    '.pw-up-nota{margin:14px 0 18px;font:600 14px/1.5 var(--font-body);color:rgba(255,255,255,.9)}',
    '.pw-up-cta{width:100%;border:0;border-radius:16px;background:#0075E3;color:#fff;font:900 15px var(--font-body);letter-spacing:.06em;text-transform:uppercase;padding:18px;box-shadow:0 6px 0 #004FA0;cursor:pointer}.pw-up-no-btn{margin-top:18px;border:0;background:transparent;color:#7FD3FF;font:900 14px var(--font-body);letter-spacing:.06em;text-transform:uppercase;cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
function pwTrialUsed(){ try{ return localStorage.getItem('fl_trial_used') === '1'; }catch(e){ return false; } }
function pwPaintTrial(){
  const host = document.getElementById('uf-trial');
  if (!host) return;
  if (Premium.isPremium() || pwTrialUsed()){ host.innerHTML = ''; return; }
  host.innerHTML = '<button class="cta" onclick="pwStartTrial()">🎁 Prova gratis 7 giorni</button>'
    + '<p class="hintline" style="text-align:center;padding:8px 0 4px">Nessuna carta, nessun addebito: fra 7 giorni torna la versione gratuita da sola.</p>';
}
function pwStartTrial(){
  if (pwTrialUsed()){ toast('La prova gratuita è già stata usata'); return; }
  const until = new Date(Date.now() + 7 * 86400000).toISOString();
  try {
    const cur = localStorage.getItem('fl_premium_until');
    if (!cur || new Date(cur).getTime() < new Date(until).getTime()) localStorage.setItem('fl_premium_until', until);
    localStorage.setItem('fl_trial_used', '1');
  } catch(e){}
  Premium._notify();
  renderProfile();
  toast('Premium attivo per 7 giorni 🎉');
  pwClose();
}

/* ✕ leads on to the next onboarding step when the paywall is met during onboarding, and back
   to the home shell when it is opened from the trial band. Reading `cur` tells us which. */
function pwClose(){
  if (typeof order !== 'undefined' && typeof cur === 'number' && order[cur] === 's11'
      && localStorage.getItem('fl_onboarded') === '1'){
    goId('s-home');
  } else {
    goId('s12');
  }
}
function pwToggleMenu(){
  const m = document.getElementById('uf-pw-menu');
  if (m) m.classList.toggle('on');
}
function pwTogglePlans(){
  const el = document.getElementById('uf-plans');
  const btn = document.getElementById('uf-more-btn');
  if (!el) return;
  const on = el.classList.toggle('on');
  if (btn) btn.textContent = on ? 'Nascondi le opzioni' : 'Altre opzioni';
}
function pwPickPlan(k){
  if (!PREMIUM_PLANS[k]) return;
  pwPlan = k;
  const price = document.getElementById('uf-price');
  if (price) price.innerHTML = pwPriceHTML();
  const plans = document.getElementById('uf-plans');
  if (plans){
    plans.querySelectorAll('.uf-planrow').forEach(b => b.classList.toggle('sel', b.dataset.plan === k));
  }
}

/* One tick a second, and only while the paywall is the visible screen: a timer running behind
   a screen nobody is looking at is just battery. */
function pwTick(){
  const el = document.getElementById('uf-offer');
  if (!el) return;
  const left = pwOfferDeadline() - Date.now();
  if (left > 0){
    const m = Math.floor(left / 60000), s = Math.floor((left % 60000) / 1000);
    el.className = 'uf-offer';
    el.innerHTML = `🎁 Offerta limitata <span class="uf-cd">${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}</span>`;
  } else {
    el.className = 'uf-offer gone';
    el.textContent = 'Offerta scaduta — resta valido il prezzo di listino';
    const price = document.getElementById('uf-price');
    if (price) price.innerHTML = pwPriceHTML();     // the discount is really gone, not just hidden
    const plans = document.getElementById('uf-plans');
    if (plans) plans.innerHTML = pwPlansHTML();
  }
}
pwOfferTimer = setInterval(() => {
  const s11 = document.getElementById('s11');
  if (s11 && s11.classList.contains('active')) pwTick();
}, 1000);

/* ---------- purchase + restore ---------- */

/* The rule this obeys: the user must never come away thinking a purchase happened when it did
   not. With the stub provider both of these end in a plain-Italian refusal and nothing is
   unlocked. When a real provider is registered the same two functions carry the real result. */
async function premiumBuy(){
  const plan = Premium.plan(pwPlan);
  const res = await Premium.buy(pwPlan);
  if (res && res.ok){
    toast('Premium attivo — grazie!');
    renderProfile();
    goId('s-home');
    return;
  }
  toast(res && res.message ? res.message : 'Acquisto non riuscito');
  // Not configured is not a failure the user caused: say what it means and leave them here.
  if (res && res.reason === 'not-configured'){
    const el = document.getElementById('uf-offer');
    if (el){
      el.className = 'uf-offer gone';
      el.textContent = 'Abbonamento ' + plan.label + ' non ancora acquistabile in questa versione';
    }
  }
}

async function premiumRestore(){
  const res = await Premium.restore();
  if (res && res.ok){ toast('Acquisti ripristinati'); renderProfile(); return; }
  toast(res && res.message ? res.message : 'Nessun acquisto da ripristinare');
}

/* ========================================================================================
 * LEGAL LINKS — they all lead to the same viewer
 *
 * There used to be a second legal screen here ('s-legal') with the two documents written
 * inline as HTML strings. It is gone on purpose. The real documents are the files in
 * www/legal/ — the same files that get published at the address declared on Play — and a
 * second copy of the same text is a second version of it: correct one, forget the other, and
 * the app starts telling the user something different from what the store says.
 *
 * So Profilo, the paywall, s0, s1, s2 and the accessibility disclosure now all end up in
 * ueOpenLegal() (onboarding.js), which shows the file itself. The addresses in LEGAL_URLS at
 * the top of this file are the published twin of those same files, offered inside the viewer
 * once the probe has confirmed they answer.
 * ====================================================================================== */

/* Returns false, always: callers such as perms.js use it as
   <a href="legal/privacy.html" onclick="return openLegal('privacy')">, and only a falsy return
   cancels the anchor's own navigation and keeps the document inside the app. */
function openLegal(kind){
  if (typeof ueOpenLegal === 'function') return ueOpenLegal(kind);
  // onboarding.js missing (should be impossible: it is loaded before this file). Rather than
  // swallow the tap, fall back to the plain file — the anchor's href would have done the same.
  window.location.href = (kind === 'termini' || kind === 'terms')
    ? 'legal/termini.html' : 'legal/privacy.html';
  return false;
}

/* ========================================================================================
 * 3 · PROFILO TAB
 * ====================================================================================== */

/* Ids that existed in the frozen index.html markup of this tab. perms.js and severe.js write
   into them, so they are reproduced verbatim below — renaming one would break another lane
   silently, with no error anywhere. */
const UF_ORIGINAL_PROFILE_IDS = ['profAv','profName','profMail','profBtn','strictchipLbl',
                                 'setAcc','setUsage','setNotif'];

/* This module redraws the whole tab, and it is not the only lane that puts something in it:
   perms.js appends four rows of its own (overlay, battery, disclosure, ROM guide) at parse
   time, before this file runs, and its mount function is guarded so it will not re-add them.
   Wiping innerHTML would delete another lane's work with no error to notice. So foreign rows
   are detached first and put back after, inside the permissions section where they belong. */
function ufHarvestForeignRows(tab){
  const keep = [];
  Array.from(tab.children).forEach(el => {
    // Ours, all of it: rebuilt from scratch every time. Leaving these in "foreign" is what
    // made a second "Primo passo fatto" appear - the old sky was harvested and put back.
    if (el.classList.contains('prof-sky') || el.classList.contains('prof-cards')
        || el.id === 'profReport' || el.id === 'blkScores'
        || el.classList.contains('blk-streak') || el.classList.contains('wl-host')) return;
    if (el.classList.contains('profcard') || el.classList.contains('procard')
        || el.classList.contains('sect') || el.classList.contains('uf-honest')) return;
    if (el.id === 'sevIntroRow') return;                 // we render an equivalent row ourselves
    if (el.classList.contains('setrow')
        && UF_ORIGINAL_PROFILE_IDS.some(id => el.querySelector('#' + id))) return;
    keep.push(el);
  });
  return keep;
}

function rebuildProfileTab(){
  const tab = document.getElementById('tab-profilo');
  if (!tab) return;
  const foreign = ufHarvestForeignRows(tab);
  // Overlay and battery belong to the permissions lane. Ours are a fallback for a build where
  // that lane's rows are not there — never a second copy of the same two switches.
  const ownsOverlay = foreign.some(el => el.id === 'ue-set-overlay');
  const ownsBattery = foreign.some(el => el.id === 'ue-set-battery');
  tab.innerHTML = `
    <div class="prof-sky" id="profSky">
      <div class="starfield" id="profStars"></div>
      <div class="prof-hero">
        <div class="av" id="profAv" onclick="profileAuth()">?<span class="pb" id="profBadge" hidden>PREMIUM</span></div>
        <div class="pf-prem-riga"><span class="pf-prem" id="profPrem" hidden>Premium</span></div>
        <h2 id="profName">Ospite</h2>
        <div class="since" id="profSince">—</div>
        <small id="profMail" hidden></small>
      </div>
      <div id="profSlides"></div>
      <div class="prof-clouds" aria-hidden="true"><svg viewBox="0 0 1079 222" preserveAspectRatio="none"><path fill="currentColor" d="M1892 85.955V222H-812V101.045C-807.936 99.2828 -803.785 97.9292 -799.442 96.9236C-767.887 89.6201 -739.625 97.8605 -725.622 118.451L-722.365 123.24L-720.18 111.329C-711.532 64.2599 -669.839 21.6916 -612.442 1.32756C-560.803 -16.994 -500.245 -14.7645 -454.1 7.1579C-427.701 19.6973 -406.341 38.8233 -394.304 60.7072L-387.784 72.5618L-383.052 64.1362C-371.016 42.7166 -342.658 20.6163 -312.438 9.10685C-253.434 -13.3629 -183.179 -2.84902 -143.746 34.3515C-121.792 55.0648 -110.995 81.5502 -114.083 107.122C-114.948 114.318 -115.388 120.514 -115.051 120.89C-114.714 121.265 -111.816 119.287 -108.618 116.495C-99.8454 108.828 -82.8208 100.457 -68.9061 96.9635C-54.2727 93.2865 -24.6977 92.467 -11.8026 95.3794C11.4716 100.637 35.3839 116.329 44.2814 132.181C47.6922 138.267 50.7876 140.542 50.7216 136.922C50.6629 133.526 64.13 114.744 74.8686 103.258C86.2306 91.1033 107.964 74.9154 124.432 66.3469C147.302 54.4419 172.19 47.3937 206.394 43.1341C254.086 37.1933 311.175 50.769 346.714 76.5023C371.301 94.3036 390.13 118.921 395.844 140.736L397.274 146.22L402.834 135.393C417.482 106.859 451.143 88.9582 491.662 88.1524C511.533 87.7587 523.217 90.1367 541.724 98.3427C564.763 108.554 580.959 124.924 584.817 141.885L586.24 148.166L591.8 137.128C603.837 113.227 631.637 92.4166 664.307 82.8634C677.203 79.0934 684.384 78.2321 705.809 77.8943C734.482 77.4415 749.079 79.8084 772.786 88.7538C795.495 97.3224 824.344 118.382 836.447 135.222L839.366 139.281L847.42 132.893C858.569 124.053 871.002 120.075 888.298 119.805C906.731 119.52 919.245 123.614 939.761 136.644L945.072 140.017L943.715 131.846C939.981 109.392 951.263 79.4647 971.053 59.3248C1032.66 -3.35963 1152.65 -5.07344 1228.87 55.6419C1251.27 73.4767 1268.77 99.5913 1276.93 127.367L1280.29 138.788L1285.3 131.59C1295.14 117.474 1321.27 108.532 1342.52 112.002C1369.84 116.463 1391.47 134.742 1397.24 158.24L1399.78 168.601L1402.91 161.716C1407.58 151.435 1425.24 130.001 1436.78 120.586C1466.59 96.2649 1504.7 83.319 1549.19 82.3959C1594.07 81.4645 1629.71 92.1071 1662.34 116.18C1674.05 124.823 1692.02 145.838 1698.27 158.225C1702.45 166.493 1705.98 169.223 1705.89 164.121C1705.81 159.461 1718.12 135.955 1725.43 126.834C1749.99 96.1609 1791.04 77.9736 1837.82 77.0454C1857.53 76.6535 1875.5 79.5921 1892 85.955Z"/></svg></div>
    </div>


    <div class="prof-cards">
      <div class="prof-card pass" onclick="frOpen()">
        <b>Amici</b><small>Sfide, lega, Pass Ospite</small><span class="art">👥</span><span class="go"></span>
      </div>
      <div class="prof-card gift" onclick="ufOpenUrl('https://dream-brothers.com/products/focuslock-premium-carta-regalo')">
        <b>Acquista Carta Regalo Premium</b><span class="art">🎁</span><span class="go"></span>
      </div>
    </div>

    <div id="profSaved"></div>

    <!-- Il pannello del report lo disegna profcaro.js: due numeri e una porta, come in
         AppBlock. Qui resta solo il posto dove va. -->
    <div id="profReportBox"></div>

    <div class="procard" id="uf-procard"></div>
    <!-- CINQUE RIGHE IN COLONNA, COME BRAIN.FM.
         Prima erano diciotto voci in fila; poi quattro riquadri quadrati, che occupavano mezzo
         schermo per dire quattro parole. Brain.fm mette righe basse dentro a una scheda sola,
         con l'icona a sinistra e la freccia a destra: si leggono dall'alto in basso in un
         secondo, e lo spazio risparmiato è quello che fa respirare il resto della pagina.

         L'ORDINE NON È CASUALE: prima quello che si tocca ogni settimana (impostazioni,
         aspetto), poi quello che si tocca una volta al mese (blocco), poi quello che si tocca
         una volta l'anno (account, aiuto). -->
    <div class="sect" style="margin-top:18px"><b>Le tue impostazioni</b></div>
    <div class="pf-rows">
      <button type="button" class="pf-row" onclick="pfOpen('impostazioni')">
        <span class="pf-ico">⚙️</span>
        <span class="pf-txt"><b>Impostazioni</b><small>Lingua, aspetto, la partita, bianco e nero</small></span>
        <span class="pf-go"></span>
      </button>
      <button type="button" class="pf-row" onclick="pfOpen('personalizza')">
        <span class="pf-ico">🎨</span>
        <span class="pf-txt"><b>Personalizza</b><small>Schermata di blocco, mantra, sveglia</small></span>
        <span class="pf-go"></span>
      </button>
      <button type="button" class="pf-row" onclick="if(typeof ifIdentitaApri==='function')ifIdentitaApri()">
        <span class="pf-ico">🪞</span>
        <span class="pf-txt"><b>Chi sarò</b><small>Il tuo Io Futuro, il perché, il tuo profilo</small></span>
        <span class="pf-go"></span>
      </button>
      <button type="button" class="pf-row" onclick="pfOpen('sicurezza')">
        <span class="pf-ico">🔒</span>
        <span class="pf-txt"><b>Blocco e sicurezza</b><small>Modalità severa, categorie, blocco in-App</small></span>
        <span class="pf-go"></span>
      </button>
      <button type="button" class="pf-row" onclick="pfOpen('account')">
        <span class="pf-ico">👤</span>
        <span class="pf-txt"><b>Account</b><small id="pfAccountSub">Backup, abbonamento</small></span>
        <span class="pf-go"></span>
      </button>
      <button type="button" class="pf-row" onclick="pfOpen('aiuto')">
        <span class="pf-ico">❓</span>
        <span class="pf-txt"><b>Aiuto e altro</b><small>Assistenza, valutazioni, legale</small></span>
        <span class="pf-go"></span>
      </button>
    </div>
    </div>

    <div class="sect" style="margin-top:18px"><b>Esplora</b></div>
    <div id="uf-explore"></div>

    <div class="sect" style="margin-top:14px"><b>Seguici</b></div>
    <div id="uf-social"></div>

    <div id="uf-perms-end" hidden></div>
    <div class="uf-ver" id="uf-version"></div>
  `;
  // The permission rows (ours and the other lanes') now live in Risoluzione dei problemi,
  // the way AppBlock does it: the profile is for what you choose, not for what the system
  // took away. They are still one tap from the profile, under Aiuto.
  ufFillTroubleScreen(foreign);
  ufPaintExploreSocial();
}

/* ---------------------------------------------------------------------------------------
   LE QUATTRO CARTELLE

   Ogni voce che prima stava in fila nel Profilo ora vive in una di queste quattro pagine —
   stessi id, stessi onclick, nessuna funzione toccata: gli altri moduli (severe.js, perms.js,
   ufRefreshExtraPerms) continuano a trovare i loro elementi con document.getElementById,
   ovunque siano. Cambia solo DOVE, non COME funzionano.
   --------------------------------------------------------------------------------------- */

function pfOpen(key){
  /* Due voci non hanno una cartella loro: aprono la pagina vera, con il suo paint.
     Una cartella che contiene una riga sola con lo stesso nome non e' una cartella, e'
     un passaggio in piu' fra la persona e quello che cercava. */
  if (key === 'impostazioni'){ drawerGo('s-settings'); return; }
  if (key === 'personalizza'){ drawerGo('s-personalize'); return; }
  goId('s-prof-' + key);
  if (key === 'account'){ try{ ufRefreshSyncCard(); }catch(_){ } try{ ufRefreshExtraPerms(); }catch(_){ } }
}

registerScreen('s-prof-sicurezza',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">🔒 Blocco e sicurezza</b></div>' +
  '<div class="setrow" onclick="switchTab(\'severa\')"><span>🔒</span><b>Modalità severa</b><small id="strictchipLbl">disattivata</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="flCatsOpen(\'s-home\')"><span>🗂️</span><b>Categorie</b><small>Social, video, shopping… i siti e le app di ogni lista</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="inappOpen()"><span>🛡️</span><b>Blocco in-App</b><small>Shorts, Reels, storie, stati…</small><span class="chev"></span></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

registerScreen('s-prof-account',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">👤 Account</b></div>' +
  '<div class="uf-honest" id="ufSyncCard" onclick="ufOpenBackup()" style="cursor:pointer">' +
    '<span>☁️</span>' +
    '<p id="ufSyncTxt"><b>Nessuna sincronizzazione.</b> Regole e statistiche restano su questo telefono. Accedi con Google per salvarne un backup sul tuo account e ritrovarlo su qualsiasi telefono.</p>' +
  '</div>' +
  /* PORTA AL PROFILO, NON AL BACKUP. Questa riga e quella qui sotto aprivano la stessa
     identica pagina: chi cercava il proprio account — il nome, la foto, la mail — finiva
     davanti a un elenco di copie di sicurezza e tornava indietro convinto che l'app non
     avesse una pagina del profilo. */
  '<div class="setrow" onclick="profileAuth()"><span>👤</span><b id="uf-setAccountLbl">Account</b><small id="uf-setAccount">—</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="profileManageSubscription()"><span>💳</span><b>Il mio abbonamento</b><small id="uf-setSub">—</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="ufOpenBackup()"><span>💾</span><b>Backup e ripristino</b><small id="uf-setBackup">Account · file</small><span class="chev"></span></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

registerScreen('s-prof-aiuto',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button><b class="blk-title">❓ Aiuto e altro</b></div>' +
  '<div class="sect"><b>Aiuto</b></div>' +
  '<div class="setrow" onclick="helpOpen()"><span>❓</span><b>Assistenza e domande frequenti</b><span class="chev"></span></div>' +
  '<div class="setrow" onclick="troubleOpen()"><span>🛠️</span><b>Risoluzione dei problemi</b><small id="uf-troubleState">permessi del sistema</small><span class="chev"></span></div>' +
  /* 0.9.291, Andrea: "anche qui la scorciatoia ad Aiuto e feedback del menu laterale". 0.9.299: lo sblocco di emergenza
     non sta piu' qui, compare fra i motivi di Contatta l'assistenza solo con la Modalita' severa accesa */
  '<div class="setrow" onclick="assistenzaApri()"><span>💬</span><b>Aiuto e feedback</b><small>Assistenza</small><span class="chev"></span></div>' +
  '<div class="sect" style="margin-top:18px"><b>Altro</b></div>' +
  '<div class="setrow" onclick="rateApp()"><span>⭐</span><b>Valuta l\'app</b><small>Google Play</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="adsPrivacySettings()"><span>🎯</span><b>Impostazioni privacy</b><small id="uf-setAds">—</small><span class="chev"></span></div>' +
  '<div class="setrow" onclick="openLegal(\'terms\')"><span>📄</span><b>Condizioni d\'Uso</b><span class="chev"></span></div>' +
  '<div class="setrow" onclick="openLegal(\'privacy\')"><span>🔐</span><b>Informativa sulla privacy</b><span class="chev"></span></div>' +
  '<div class="setrow" onclick="drawerGo(\'s-about\')"><span>ℹ️</span><b>Informazioni</b><span class="chev"></span></div>' +
  '<div class="spacer"></div>', { back: 's-home' });

(function pfStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* Una scheda sola, righe basse divise da una linea: e' la forma della scheda Profilo di
       Brain.fm, e sta in un terzo dello spazio che prendevano quattro quadrati. */
    '.pf-rows{background:#fff;border:1px solid var(--line);border-radius:20px;overflow:hidden;margin:4px 0 8px}',
    'body.dark .pf-rows{background:#12203A;border-color:#22345A}',
    '.pf-row{width:100%;display:flex;align-items:center;gap:14px;padding:15px 16px;border:0;',
      'background:transparent;cursor:pointer;font:inherit;text-align:left}',
    '.pf-row + .pf-row{border-top:1px solid var(--line)}',
    'body.dark .pf-row + .pf-row{border-top-color:#22345A}',
    '.pf-row:active{background:rgba(0,117,227,.06)}',
    '.pf-ico{font-size:21px;line-height:1;flex:none;width:26px;text-align:center}',
    '.pf-txt{flex:1;min-width:0}',
    '.pf-txt b{display:block;font:700 15px var(--font-body);color:var(--navy)}',
    'body.dark .pf-txt b{color:#fff}',
    '.pf-txt small{display:block;margin-top:2px;font:500 12px/1.4 var(--font-body);color:var(--muted)}',
    /* La freccia: la stessa forma della .chev delle altre righe dell'app, cosi' si riconosce. */
    '.pf-go{flex:none;width:8px;height:8px;border-right:2px solid var(--muted);',
      'border-bottom:2px solid var(--muted);transform:rotate(-45deg);opacity:.55}'
  ].join('');
  document.head.appendChild(st);
})();

/* Esplora and Seguici are built by academy.js, which loads AFTER this file: on the first
   paint those functions do not exist yet. Called again from there, so the two sections are
   never a heading with nothing under it. */
function ufPaintExploreSocial(){
  const ex = document.getElementById('uf-explore');
  if (ex && typeof exploreCardsHtml === 'function') ex.innerHTML = exploreCardsHtml();
  const so = document.getElementById('uf-social');
  if (so && typeof socialsHtml === 'function') so.innerHTML = socialsHtml();
}

/* Builds the troubleshooting screen: our own permission rows plus whatever perms.js added. */
function ufFillTroubleScreen(foreign){
  const host = document.getElementById('troubleRows');
  if (!host){ // the screen module has not registered yet: keep the nodes alive for later
    UF_PENDING_PERM_ROWS = (UF_PENDING_PERM_ROWS || []).concat(foreign || []);
    return;
  }
  host.innerHTML = `
    <div class="setrow" onclick="openPerm('accessibility')"><span>🛡️</span><b>Servizio di blocco</b><small id="setAcc">—</small><span class="chev"></span></div>
    <div class="setrow" onclick="openPerm('usage')"><span>📊</span><b>Dati di utilizzo</b><small id="setUsage">—</small><span class="chev"></span></div>
    <div class="setrow" onclick="openPerm('notif')"><span>🔔</span><b>Accesso alle notifiche</b><small id="setNotif">—</small><span class="chev"></span></div>`;
  const rows = (UF_PENDING_PERM_ROWS || []).concat(foreign || []);
  UF_PENDING_PERM_ROWS = [];
  rows.forEach(el => host.appendChild(el));
  if (typeof refreshPerms === 'function') refreshPerms();
  if (typeof ufRefreshExtraPerms === 'function') ufRefreshExtraPerms();
}
let UF_PENDING_PERM_ROWS = [];

/* Premium state, said plainly. "Non attivo" plus a way in, or "Attivo" plus where to manage it —
   never a badge that implies a subscription that does not exist. */
function ufRenderProCard(){
  const el = document.getElementById('uf-procard');
  if (!el) return;
  if (Premium.isPremium()){ el.hidden = true; el.style.display = 'none'; el.innerHTML = ''; return; }
  el.hidden = false; el.style.display = '';
  el.onclick = function(){ go(11); };
  el.innerHTML = '<span class="probadge">PREMIUM</span>'
    + '<b>Sblocca tutto DreamMap</b>'
    + '<p>Programmi illimitati, tutti i metodi della Modalità severa, nessuna pubblicità.'
    + (pwTrialUsed() ? '' : ' La prima settimana è gratis.') + '</p>'
    + '<div style="margin-top:12px;font:800 13px var(--font-body);color:#fff">' + (pwTrialUsed() ? 'Passa a Premium ›' : 'Prova gratis 7 giorni ›') + '</div>';
}

/* Overlay and battery are exposed by the bridge but nothing else in the UI reads them back;
   the labels here are the only place the user can see whether the engine has what it needs. */
async function ufRefreshExtraPerms(){
  const setTxt = (id, txt, ok) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = txt;
    el.style.color = ok === undefined ? '' : (ok ? '#0F7A3D' : 'var(--red)');
  };
  setTxt('uf-setAds', typeof adsStatusLabel === 'function' ? adsStatusLabel() : '—');
  (async function(){
    let label = 'Non collegato';
    try{
      if(NATIVE && NATIVE.googleAccount){ const a = await NATIVE.googleAccount(); if(a && a.signedIn) label = a.email || 'Collegato'; }
      else { const u = JSON.parse(localStorage.getItem('fl_user')||'null'); if(u && u.mail) label = u.mail; }
    }catch(_){ }
    setTxt('uf-setAccount', label);
    try{
      const u = JSON.parse(localStorage.getItem('fl_user')||'null');
      const prov = u && u.provider === 'facebook' ? 'Account Facebook' : (u && u.provider === 'apple' ? 'Account Apple' : 'Account Google');
      const lb = document.getElementById('uf-setAccountLbl'); if(lb) lb.textContent = prov;
    }catch(_){ }
    (function(){
      let until = null; try{ until = localStorage.getItem('fl_premium_until'); }catch(_){ }
      const pass = until && new Date(until).getTime() > Date.now();
      let flag = false; try{ flag = localStorage.getItem('fl_premium') === '1'; }catch(_){ }
      if (FL_DEBUG_PREMIUM){ setTxt('uf-setSub', 'Premium acceso per le prove (build di sviluppo)'); return; }
      setTxt('uf-setSub', flag ? 'Premium attivo · Google Play'
        : pass ? 'Pass Ospite fino al ' + new Date(until).toLocaleDateString('it-IT')
        : 'Gratuito · passa a Premium');
    })();
  })();
  setTxt('uf-setBilling', Premium.configured() ? Premium.source() : 'non ancora attivi');

  if (!NATIVE){
    setTxt('uf-setOverlay', 'solo nell’app installata');
    setTxt('uf-setBattery', 'solo nell’app installata');
    return;
  }
  try {
    if (NATIVE.isOverlayGranted){
      const o = await NATIVE.isOverlayGranted();
      setTxt('uf-setOverlay', !o.required ? 'non necessaria' : (o.granted ? 'attiva' : 'non attiva'),
             !o.required ? undefined : !!o.granted);
    }
  } catch(e){ setTxt('uf-setOverlay', 'non leggibile'); }
  try {
    if (NATIVE.isBatteryOptimizationIgnored){
      const b = await NATIVE.isBatteryOptimizationIgnored();
      setTxt('uf-setBattery', !b.supported ? 'non necessaria' : (b.ignored ? 'esclusa ✓' : 'attiva — può fermare il blocco'),
             !b.supported ? undefined : !!b.ignored);
    }
  } catch(e){ setTxt('uf-setBattery', 'non leggibile'); }
}

/* Every native call gets both the missing-plugin case and the reject case: a rejected promise
   that nobody catches leaves the row saying "—" forever and the user pressing a dead button. */
async function profileOpenOverlay(){
  if (!NATIVE || !NATIVE.openOverlaySettings){ toast('Disponibile solo nell’app installata'); return; }
  try { const r = await NATIVE.openOverlaySettings();
        if (r && r.via === 'not-needed') toast('Su questa versione di Android non serve');
  } catch(e){ toast(e && e.message ? e.message : 'Impossibile aprire le impostazioni'); }
  ufRefreshExtraPerms();
}
async function profileOpenBattery(){
  if (!NATIVE || !NATIVE.openBatteryOptimizationSettings){ toast('Disponibile solo nell’app installata'); return; }
  try { const r = await NATIVE.openBatteryOptimizationSettings();
        if (r && r.via === 'not-needed') toast('Su questa versione di Android non serve');
  } catch(e){ toast(e && e.message ? e.message : 'Impossibile aprire le impostazioni'); }
  ufRefreshExtraPerms();
}

/* The wizard belongs to the strict-mode lane (severe.js), whose own "rivedi l'introduzione"
   row is inserted next to #strictchipLbl at parse time — and then wiped when this file redraws
   the tab. Rather than leave a hole, the row above replaces it and calls the same entry point;
   the fallbacks keep it from ever being a dead end if that lane renames things. */
function profileOpenStrictWizard(){
  if (typeof sevReplayIntro === 'function') return sevReplayIntro();
  if (typeof openStrictWizard === 'function') return openStrictWizard();
  if (typeof goId === 'function' && document.getElementById('sev-w1')) return goId('sev-w1');
  switchTab('severa');
  toast('La configurazione guidata si apre da qui');
}

function profileManageSubscription(){
  // Play's own subscription centre is the only place a subscription can legitimately be
  // cancelled, and Play requires us to point at it rather than build a cancel flow.
  const url = 'https://play.google.com/store/account/subscriptions';
  try { window.open(url, '_blank'); }
  catch(e){ toast('Apri Google Play → Pagamenti e abbonamenti → Abbonamenti'); }
}

/* ---------- account card ---------- */

/* There is no login. There is a nickname stored on the device, and the card says exactly that:
   the previous copy read "Accedi per sincronizzare i tuoi dati", which promised a backend that
   has never existed (gap analysis R8/G68). */
function renderProfile(){
  ufRenderProCard();
  let u = null;
  try { u = JSON.parse(localStorage.getItem('fl_user') || 'null'); } catch(e){ u = null; }
  const av = document.getElementById('profAv'), nm = document.getElementById('profName'),
        ml = document.getElementById('profMail'), bt = document.getElementById('profBtn');   // may be absent by design
  const badge = document.getElementById('profBadge'), since = document.getElementById('profSince');
  const premium = Premium.isPremium();
  if (badge) badge.hidden = !premium;
  /* 0.9.308: sotto alla bolla col livello resta solo la pillola PREMIUM (per chi lo e').
     La riga "Membro Premium dal ..." e' sparita dal Profilo: il mese d'iscrizione ora sta
     nella pagina Account ("Su DreamMap da agosto 2026"), uguale per tutti. Sotto al nome
     si alternano soltanto i due mantra. */
  const pp = document.getElementById('profPrem');
  if (pp) pp.hidden = !premium;
  if (since) ufSinceRotate('', (u && u.bio) ? String(u.bio).trim() : '');
  if (typeof scoresRefresh === 'function') scoresRefresh();
  if (typeof lvPaintProfile === 'function') lvPaintProfile();
  ufPaintSaved();
  ufRefreshSyncCard();
  if (av){
    // The portrait carries the picture when there is one; the letter is the fallback.
    const pic = (typeof flImgGet === 'function') ? flImgGet(UF_AVATAR_KEY) : '';
    av.classList.toggle('has-pic', !!pic);
    av.style.backgroundImage = pic ? 'url(' + pic + ')' : '';
    if (u && u.name){
      av.firstChild.nodeValue = String(u.name).trim().charAt(0).toUpperCase() || '?';
      nm.textContent = u.name;
      ml.textContent = 'Profilo locale su questo telefono';
      if (bt) bt.textContent = 'Modifica';
    } else {
      av.firstChild.nodeValue = '?';
      nm.textContent = 'Ospite';
      ml.textContent = 'Nessun profilo — l’app funziona lo stesso';
      if (bt) bt.textContent = 'Dai un nome';
    }
  }
  const v = document.getElementById('uf-version');
  if (v) v.textContent = 'DreamMap ' + APP_VERSION + ' · tutti i dati restano su questo dispositivo';
  ufRefreshExtraPerms();
}

/* The account screen: the way in is the round portrait above the name, so the night sky under
   it carries nothing but the name and the month. */
registerScreen('s-account',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">✕</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Account</b></div>' +
  '<div class="acc-av"><div class="av" id="accAv" onclick="profiloModificaApri()">?</div></div>' +
  /* 0.9.308: la matita accanto al nome apre la modifica del profilo; il pulsante "Modifica
     profilo" e' sceso nella sezione "Chi sono" dell'About. Al suo posto, sopra al pannello dei
     seguiti, il mese in cui la persona e' arrivata (per tutti, Premium o no). */
  '<div class="acc-nome-riga"><span class="acc-nome-in"><h2 class="acc-nome" id="accNome">Ospite</h2>' +
    '<button type="button" class="acc-matita" onclick="profiloModificaApri()" aria-label="Modifica profilo"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg></button></span></div>' +
  '<button type="button" class="acc-pub-link" onclick="accPubblicoApri()">Vedi profilo pubblico</button>' +
  '<p class="acc-da" id="accDa"></p>' +
  /* I TRE NUMERI, SUBITO SOTTO AL NOME. E' la riga che Forest mette nello stesso punto, e
     funziona per un motivo preciso: sono tre risultati, non tre impostazioni — si guardano,
     non si toccano. Forest pero' mostra solo gli alberi vivi; qui ci sono anche quelli
     appassiti, perche' una percentuale di successo senza il denominatore e' una decorazione. */
  /* IL PANNELLO A DUE SLIDE (0.9.204): la prima dice dove sei e con chi (percorso, seguiti,
     follower), la seconda cosa hai costruito (successo, alberi, sogni realizzati). */
  '<div class="acc-top3" id="accSlider"></div>' +
  '<div class="acc-social"><button type="button" class="acc-amici" onclick="if(typeof frAggiungiApri===\'function\')frAggiungiApri()"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6"/><path d="M19 8v6M16 11h6"/></svg> Aggiungi amici</button>' +
    '<button type="button" class="acc-qr" onclick="accQrApri()" aria-label="Il tuo QR code"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M14 14h3v3M21 14v3M14 21h3M21 21h-1"/></svg></button></div>' +

  /* LE QUATTRO SCHEDE DEL PROFILO, come una pagina-memoria: la Timeline degli eventi del
     viaggio, chi sono (About), le foto (Media) e la Story, cioe' il diario di viaggio da
     sfogliare, che si puo' aprire agli amici. */
  '<div class="acc-tabs" id="accTabs"></div>' +
  '<div id="accTabBody" class="acc-tabbody"></div>' +
  '<div class="spacer"></div>',
  { back: function(){ switchTab('profilo'); return 's-home'; } });

/* ---- MODIFICA PROFILO, come su Instagram: una pagina sola per nome, mantra dell'inizio,
   data di nascita e account. Prima quei campi stavano in fondo alle quattro schede. ---- */
registerScreen('s-profilo-modifica',
  '<div class="topbar"><button class="iconbtn" onclick="profileAuth()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Modifica profilo</b></div>' +
  '<div class="acc-av"><div class="av" id="accAv2" onclick="profileAvatarPick()">?</div>' +
    '<button type="button" class="acc-av-edit" onclick="profileAvatarPick()">Cambia immagine</button>' +
    '<button type="button" class="acc-av-x" id="accAvX" hidden onclick="profileAvatarClear()">Togli l\'immagine</button></div>' +
  '<div class="sect" style="margin-top:6px"><b>Nome</b></div>' +
  '<input class="fin" id="uf-name" type="text" placeholder="Il tuo nome" maxlength="24" autocomplete="off">' +
  '<div class="sect" style="margin-top:22px"><b>Sesso</b></div>' +
  '<div class="acc-sesso" id="ufSesso"></div>' +
  '<div class="sect" style="margin-top:22px"><b>Il mantra dell\'inizio</b></div>' +
  '<textarea class="fin acc-bio" id="uf-bio" rows="2" placeholder="Chi eri, e cosa ti sei promesso, il giorno che hai iniziato" maxlength="140"></textarea>' +
  '<small class="acc-hint">Resta com\'è: è la frase che ti sei detto all\'inizio del viaggio. Sotto il nome si alterna con quella di adesso, che scrivi nella Modalità severa.</small>' +
  '<div id="accMantraNow" class="acc-now"></div>' +
  /* 0.9.332, Andrea: come la pagina profilo di Where is the Toilet: l'icona del calendario nel campo, la spiegazione nella (i); il sogno pubblico sta con gli altri interruttori */
  '<div class="sect acc-sect-i" style="margin-top:24px"><b>Data di nascita</b><button type="button" class="rmp-i" onclick="accNascitaInfo()" aria-label="Perché serve">i</button></div>' +
  '<label class="acc-birth-w"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0075E3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.500" y="5" width="17" height="15.500" rx="2.500"/><path d="M3.500 10h17M8 3v4M16 3v4M8 14h.01M12 14h.01M16 14h.01M8 17.500h.01M12 17.500h.01"/></svg><input class="fin acc-birth" id="uf-birth" type="date"></label>' +
  '<div class="sect" style="margin-top:22px"><b>Account</b></div>' +
  '<div id="accMailBox"></div>' +
  '<div id="accActions" style="text-align:center;margin-top:14px"></div>' +
  '<div class="spacer"></div>' +
  '<button class="cta" onclick="profileSaveName()">Salva</button>',
  { back: 's-account' });

async function profiloModificaApri(){
  await profileAuth();
  goId('s-profilo-modifica');
}

async function profileAuth(){
  goId('s-account');
  let u = null;
  try { u = JSON.parse(localStorage.getItem('fl_user') || 'null'); } catch(e){}
  const name = (u && u.name) ? String(u.name) : '';
  const i = document.getElementById('uf-name');
  if (i) i.value = name;
  const nn = document.getElementById('accNome');
  if (nn) nn.textContent = name || 'Ospite';
  const da = document.getElementById('accDa');
  if (da){
    /* il mese vero del primo avvio (fl_first_run, che il backup riporta sul telefono nuovo) */
    const t = (typeof flPrimoAvvioSegna === 'function') ? flPrimoAvvioSegna() : 0;
    const dt = t ? new Date(t) : null;
    da.textContent = dt && !isNaN(dt) ? 'Su DreamMap da ' + dt.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' }) : '';
    da.hidden = !da.textContent;
  }
  const bi = document.getElementById('uf-bio');
  if (bi) bi.value = (u && u.bio) ? String(u.bio) : '';
  const bd = document.getElementById('uf-birth');
  if (bd){
    bd.max = new Date().toISOString().slice(0, 10);
    bd.value = (u && u.birth) ? String(u.birth) : ((typeof scFuture === 'function') ? (scFuture().birth || '') : '');
  }
  const now = document.getElementById('accMantraNow');
  if (now){
    const m = (typeof whyMantra === 'function') ? whyMantra() : '';
    /* UN TITOLO, NON UNA DIDASCALIA. In grassetto piccolo sembrava l'etichetta del campo
       qui sopra; e invece e' un'altra cosa — la frase che ti dici ADESSO, contro quella che ti
       dicevi all'inizio. Rosso perche' e' l'unica riga di questa pagina che deve interrompere
       la lettura, e in tutta l'app il rosso e' il colore di chi ti sta parlando sul serio. */
    now.innerHTML = '<h3 class="acc-now-h">Il tuo mantra adesso</h3><p>' + (m ? esc(m) : 'Non l\'hai ancora scritto.')
      + '</p><button type="button" class="ghostmini" onclick="whyOpen()">' + (m ? 'Cambialo' : 'Scrivilo') + '</button>';
  }
  // nothing is staged when the screen opens: a picture chosen and then abandoned is gone
  UF_AVATAR_STAGED = null;
  profileAvatarPaint(name);

  let acc = null;
  if (NATIVE && NATIVE.googleAccount){ try{ acc = await NATIVE.googleAccount(); }catch(_){ acc = null; } }
  const box = document.getElementById('accMailBox');
  if (box){
    box.innerHTML = (acc && acc.signedIn && acc.email)
      ? '<div class="acc-mail"><span>✉</span><b>' + esc(acc.email) + '</b></div>'
      : '<div class="setrow" onclick="ufOpenBackup()"><span>☁️</span><b>Accedi con Google</b><small>per il backup</small><span class="chev"></span></div>';
  }
  accForestPaint();
  try{ accSessoPaint(); }catch(_){ }

  try{ accTabsPaint(); }catch(_){ }

  const act = document.getElementById('accActions');
  if (act){
    act.innerHTML = (acc && acc.signedIn ? '<button class="ghostmini" onclick="ufOpenBackup()">Esci</button>' : '')
      + (u ? '<div><button class="acc-del" onclick="profileClearName()">Rimuovi il profilo locale</button></div>' : '');
  }
  /* 0.9.230: niente fuoco automatico sul nome: apriva la tastiera da sola toccando la bolla del profilo */
}
/* ---- "Tempo risparmiato": what the blocks gave back, by period ---------------------------

   A block is a session that did not happen. How long that session would have lasted is not
   knowable, so the estimate uses this person's own average session (screen time divided by
   sessions over the last seven days), capped at fifteen minutes so one long evening cannot
   inflate a whole month. The assumption is written under the figures; the counts are exact. */
/* Time saved, one figure at a time.

   Four cells side by side asked the eye to read four numbers to get one message, and the
   message is for people whose attention is exactly what the app is protecting. So: one
   timeframe on screen (this year by default, or everything since the first day), one figure
   in days and hours, not "33h", and one emoji that grows with the figure. The estimate is the
   same as before: every block is a session avoided, worth the person's own average session. */
let UF_SAVED_TF = null;
const UF_SAVED_TFS = [['day', 'Oggi'], ['week', 'Questa settimana'], ['month', 'Questo mese'], ['year', 'Quest\'anno'], ['all', 'Da sempre']];
function ufSavedTf(){
  if (!UF_SAVED_TF){ try{ UF_SAVED_TF = localStorage.getItem('fl_saved_tf') || 'year'; }catch(_){ UF_SAVED_TF = 'year'; } }
  return UF_SAVED_TFS.some(x => x[0] === UF_SAVED_TF) ? UF_SAVED_TF : 'year';
}
function ufSavedSetTf(tf){
  UF_SAVED_TF = tf;
  try{ localStorage.setItem('fl_saved_tf', tf); }catch(_){ }
  ufPaintSaved();
}
/* "1 giorno 9 ore", "2 settimane 3 giorni", "1 anno 2 mesi": the two largest units that are
   not zero. Seconds never: 86 400 of them are a day, and a day is what this panel is for. */
function ufSavedFmt(ms){
  const MIN = 60000, H = 60 * MIN, D = 24 * H, W = 7 * D, MO = 30 * D, Y = 365 * D;
  const units = [[Y, 'anno', 'anni'], [MO, 'mese', 'mesi'], [W, 'settimana', 'settimane'], [D, 'giorno', 'giorni'], [H, 'ora', 'ore'], [MIN, 'min', 'min']];
  const out = [];
  let left = Math.max(0, ms);
  for (let i = 0; i < units.length && out.length < 2; i++){
    const n = Math.floor(left / units[i][0]);
    if (n <= 0) continue;
    out.push(n + ' ' + (n === 1 ? units[i][1] : units[i][2]));
    left -= n * units[i][0];
  }
  return out.length ? out.join(' ') : '0 min';
}
/* The climax: from a seed to a superhero, one step per order of magnitude. */
function ufSavedEmoji(ms){
  const H = 3600000, D = 24 * H;
  if (ms < H) return ['🌱', 'Il primo passo'];
  if (ms < 6 * H) return ['☕', 'Una mattinata tornata tua'];
  if (ms < D) return ['🌤️', 'Quasi una giornata intera'];
  if (ms < 7 * D) return ['🏃', 'Giorni interi, non minuti'];
  if (ms < 30 * D) return ['🚀', 'Una settimana di vita in più'];
  if (ms < 182 * D) return ['🏆', 'Un mese intero riconquistato'];
  if (ms < 365 * D) return ['👑', 'Mezzo anno di attenzione'];
  return ['🦸', 'Un anno di vita salvato'];
}
/* Adesso e' una delle tre schede del carosello (profcaro.js), quindi restituisce il suo
   corpo invece di scriverselo da sola: il contenitore, i puntini e il menu' del periodo li
   mette chi tiene il carosello. Un pannello che disegna anche la propria cornice non si puo'
   mettere dentro a nient'altro. */
async function ufPaintSaved(){
  if (typeof pfcPaint === 'function') return pfcPaint();
}

async function ufSavedHtml(){
  if (!NATIVE || !NATIVE.getInsights || typeof scReport !== 'function') return '';
  let hist = [];
  try{ const r = await NATIVE.getInsights({ days: 400 }); hist = (r && r.history) || []; }catch(_){ hist = []; }
  if (!hist.length) return '<p class="pfc-eyebrow">Tempo risparmiato</p>'
    + '<b class="pfc-big">—</b><p class="pfc-line">Il primo blocco che scatta apre il conto.</p>';

  // the average session, from the last seven days that have one
  let ms = 0, n = 0;
  for (let i = 0; i < 7; i++){
    const r = await scReport(i);
    if (r && r.granted && r.sessions > 0 && r.screenMs > 0){ ms += r.screenMs; n += r.sessions; }
  }
  const perBlock = Math.min(15 * 60000, n > 0 ? ms / n : 5 * 60000);

  const tf = ufSavedTf();
  const key = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const y0 = new Date(); y0.setHours(0, 0, 0, 0);
  let from = '0000';
  if (tf === 'day') from = key(y0);
  else if (tf === 'week'){ const d = new Date(y0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); from = key(d); }
  else if (tf === 'month') from = y0.getFullYear() + '-' + String(y0.getMonth() + 1).padStart(2, '0') + '-01';
  else if (tf === 'year') from = y0.getFullYear() + '-01-01';
  const blocks = hist.filter(h => h.day >= from).reduce((a, h) => a + (h.blocks || 0), 0);
  let first = '';
  try{ first = localStorage.getItem('fl_first_run') || ''; }catch(_){ }
  const firstDt = (typeof flPrimoAvvio === 'function' && flPrimoAvvio()) ? new Date(flPrimoAvvio()) : (first ? new Date(first) : null);
  const firstTxt = (firstDt && !isNaN(firstDt)) ? firstDt.toLocaleDateString('it-IT', { day: 'numeric', month: 'short', year: 'numeric' }) : '';
  // Nobody can have saved more time than has passed: thirty blocks at half past four in the
  // morning are not five hours. The time elapsed in the frame is the ceiling.
  const nowMs = Date.now();
  let capMs = Infinity;
  if (tf === 'day') capMs = nowMs - y0.getTime();
  else if (tf === 'week'){ const d = new Date(y0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); capMs = nowMs - d.getTime(); }
  else if (tf === 'month') capMs = nowMs - new Date(y0.getFullYear(), y0.getMonth(), 1).getTime();
  else if (tf === 'year') capMs = nowMs - new Date(y0.getFullYear(), 0, 1).getTime();
  else if (firstDt && !isNaN(firstDt)) capMs = Math.max(0, nowMs - firstDt.getTime());
  const saved = Math.min(blocks * perBlock, capMs);
  const em = ufSavedEmoji(saved);
  const tfTxt = { day: 'oggi', week: 'questa settimana', month: 'questo mese', year: 'nel ' + y0.getFullYear(), all: firstTxt ? 'dal ' + firstTxt : 'da sempre' }[tf];
  const sub = blocks + (blocks === 1 ? ' blocco' : ' blocchi') + ' ' + tfTxt;
  /* IL NUMERO PIU' GRANDE DELLA SCHEDA, E AL CENTRO. Il periodo non e' piu' un menu' a tendina
     largo quanto la scheda: sta nei tre puntini in alto, come in tutte le altre schede — un
     controllo che si usa una volta al mese non deve stare davanti al numero che si guarda
     tutti i giorni. */
  return '<p class="pfc-eyebrow">Tempo risparmiato · ' + tfTxt + '</p>'
    + '<span class="saved-emoji">' + em[0] + '</span>'
    + '<b class="pfc-big">' + ufSavedFmt(saved) + '</b>'
    + '<p class="pfc-line"><b>' + em[1] + '</b><br>' + sub + '</p>'
    + '<small class="saved-note">Ogni blocco vale una sessione media di ' + scFmtShort(perBlock) + '.</small>';
}

/* ---------------------------------------------------------------------------------------
   La riga sotto il nome: una per volta.

   Tre cose vorrebbero stare lì — da quando usi l'app, il mantra dell'inizio, il mantra di
   adesso — e stampate insieme diventano un muro. Si alternano ogni sei secondi, con la
   stessa dissolvenza dal basso delle card del sito, e chi non ha scritto nessun mantra vede
   soltanto la data, ferma, come prima.
   --------------------------------------------------------------------------------------- */
let UF_SINCE_TIMER = 0, UF_SINCE_I = 0;
function ufSinceRotate(sinceTxt, bio){
  const el = document.getElementById('profSince');
  if (!el) return;
  const now = (typeof whyMantra === 'function') ? whyMantra() : '';
  const slides = [];
  /* 0.9.305: "Membro Premium dal ..." e' UNA delle frasi che si alternano coi mantra, come prima
     della 0.9.304, solo con la pillola rossa PREMIUM dentro. Fissa sopra le frasi faceva leggere
     due righe insieme ("Membro Premium dal ..." e "All'inizio del viaggio ..."). */
  const prem = /^Membro Premium dal /.test(sinceTxt || '');
  /* le virgolette a schermo sono quelle normali: si tolgono quelle che il mantra si porta dai
     dati (« » e " ") e se ne mette un paio solo */
  const virg = t => '"' + String(t).trim().replace(/^[«»"“”\s]+|[«»"“”\s]+$/g, '') + '"';
  if (sinceTxt) slides.push(prem
    ? { k: '', h: 'Membro <span class="pf-prem">Premium</span> ' + esc(sinceTxt.slice(15)) }
    : { k: '', t: sinceTxt });
  if (bio) slides.push({ k: 'All\'inizio del viaggio', t: virg(bio) });
  if (now) slides.push({ k: 'Il tuo mantra adesso', t: virg(now) });
  clearInterval(UF_SINCE_TIMER);
  if (!slides.length){ el.innerHTML = ''; return; }
  if (UF_SINCE_I >= slides.length) UF_SINCE_I = 0;
  const paint = () => {
    const s = slides[UF_SINCE_I % slides.length];
    el.innerHTML = '<span class="since-in">' + (s.k ? '<i>' + esc(s.k) + '</i>' : '') + (s.h || esc(s.t)) + '</span>';
  };
  paint();
  if (slides.length < 2) return;
  UF_SINCE_TIMER = setInterval(() => {
    const home = document.getElementById('s-home'), tab = document.getElementById('tab-profilo');
    if (document.hidden || !home || !home.classList.contains('active') || !tab || !tab.classList.contains('on')) return;
    UF_SINCE_I++;
    paint();
  }, 6000);
}

/* The portrait, on the account screen: tap it or the button under it to choose a picture.
   It is squared, scaled to 320px and kept on this phone only - the same handling as the
   picture of why you started in Modalita severa. */
const UF_AVATAR_KEY = 'fl_avatar_img';

/* The portrait is STAGED on this screen: a picture chosen, or "take it away", becomes real
   only with Salva. Leaving with the back arrow or the cross forgets it. The first version
   wrote the picture to storage the moment it was chosen, so the profile changed behind a
   screen the user had not confirmed. */
let UF_AVATAR_STAGED = null;      // null = untouched, '' = removal staged, 'data:...' = picture staged
const UF_AVATAR_TMP = 'fl_avatar_img_tmp';
function profileAvatarPaint(name){
  const x = document.getElementById('accAvX');
  const stored = (typeof flImgGet === 'function') ? flImgGet(UF_AVATAR_KEY) : '';
  const pic = UF_AVATAR_STAGED === null ? stored : UF_AVATAR_STAGED;
  ['accAv', 'accAv2'].forEach(function(id){
    const av = document.getElementById(id); if (!av) return;
    av.textContent = pic ? '' : ((String(name || '').trim().charAt(0) || '?').toUpperCase());
    av.classList.toggle('has-pic', !!pic);
    av.style.backgroundImage = pic ? 'url(' + pic + ')' : '';
  });
  if (x) x.hidden = !pic;
}
const ACC_SESSI = [['m', 'Maschio'], ['f', 'Femmina'], ['altro', 'Altro'], ['no', 'Preferisco non specificarlo']];
function accSesso(){
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); if (u && u.sesso) return u.sesso; }catch(_){ }
  try{ const g = (typeof ifIdentita === 'function') ? ifIdentita().genere : ''; if (g === 'm' || g === 'f') return g; }catch(_){ }
  return 'no';
}
function accSessoPaint(){
  const h = document.getElementById('ufSesso'); if (!h) return;
  const s = accSesso();
  h.innerHTML = ACC_SESSI.map(function(x){ return '<button type="button" class="' + (s === x[0] ? 'on' : '') + '" onclick="accSessoSet(\'' + x[0] + '\')"><i></i>' + x[1] + '</button>'; }).join('');
}
/* solo maschio e femmina cambiano le desinenze dei testi; le altre scelte restano neutre */
function accSessoSet(k){
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || '{}') || {}; u.sesso = k; localStorage.setItem('fl_user', JSON.stringify(u)); }catch(_){ }
  const g = (k === 'm' || k === 'f') ? k : '';
  try{ if (typeof gnDati === 'function'){ gnDati().sesso = g; if (typeof gnSalva === 'function') gnSalva(); } }catch(_){ }
  try{ if (typeof ifIdentita === 'function' && typeof ifScrivi === 'function' && typeof IF_KEYS !== 'undefined'){ const id = ifIdentita(); id.genere = g; ifScrivi(IF_KEYS.ident, id); } }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  accSessoPaint();
}
function accNascitaInfo(){
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="rmp-i-ico" aria-hidden="true">🎂</span><h3>Perché serve la data di nascita</h3><p>Serve alla scheda Identità per contare gli anni che hai davanti.</p><p>Resta su questo telefono.</p></div>');
}
function accSognoPub(){ try{ return localStorage.getItem('fl_sogno_pubblico') === '1'; }catch(_){ return false; } }
function accSognoPubSet(on){ try{ localStorage.setItem('fl_sogno_pubblico', on ? '1' : '0'); }catch(_){ } }
function profileAvatarPick(){
  if (typeof flImgPick !== 'function') return;
  flImgPick(UF_AVATAR_TMP, function(out){
    UF_AVATAR_STAGED = out || '';
    try{ localStorage.removeItem(UF_AVATAR_TMP); }catch(_){ }
    const i = document.getElementById('uf-name');
    profileAvatarPaint(i ? i.value : '');
    toast('Immagine scelta: tocca Salva per confermarla');
  }, true);
}
function profileAvatarClear(){
  UF_AVATAR_STAGED = '';
  const i = document.getElementById('uf-name');
  profileAvatarPaint(i ? i.value : '');
}
function profileAvatarCommit(){
  if (UF_AVATAR_STAGED === null) return;
  try{
    if (UF_AVATAR_STAGED) localStorage.setItem(UF_AVATAR_KEY, UF_AVATAR_STAGED);
    else localStorage.removeItem(UF_AVATAR_KEY);
  }catch(_){ }
  UF_AVATAR_STAGED = null;
}

function profileSaveName(){
  let u = null; try { u = JSON.parse(localStorage.getItem('fl_user') || 'null'); } catch(e){ u = null; }
  const i = document.getElementById('uf-name');
  const name = i ? i.value.trim() : '';
  if (!name){ toast('Scrivi un nome, oppure annulla'); return; }
  const bi = document.getElementById('uf-bio');
  const bio = bi ? bi.value.trim().slice(0, 140) : '';
  const bd = document.getElementById('uf-birth');
  const birth = bd && /^\d{4}-\d{2}-\d{2}$/.test(bd.value) ? bd.value : ((u && u.birth) || '');
  /* e viceversa: il Salva del profilo cancellava email e provider dell'accesso */
  try { localStorage.setItem('fl_user', JSON.stringify(Object.assign({}, u || {}, { name: name, bio: bio, birth: birth, local: true }))); } catch(e){}
  // la stessa data serve al pannello del futuro, che la legge da qui
  if (birth && typeof scFutureSetBirth === 'function') scFutureSetBirth(birth);
  profileAvatarCommit();
  closeSheet();
  renderProfile();
  profileAuth();
  toast('Fatto, ' + name);
}
function profileClearName(){
  try { localStorage.removeItem('fl_user'); } catch(e){}
  closeSheet();
  goId('s-home'); switchTab('profilo');
  renderProfile();
  toast('Profilo locale rimosso');
}
/* Kept because index.html may still call it from an old handler; it does the honest thing. */
function logout(){ profileClearName(); }

/* ========================================================================================
 * FALSE-CLAIM SWEEP over markup owned by other lanes
 * ====================================================================================== */

/* index.html is frozen for every lane, but two of the strings the client ordered removed live
   in it: the "Sincronizzato col tuo PC" summary row (s16) and the trial band that sells a
   desktop program and a free week that do not exist. Both are R8 misrepresentation, so they
   are neutralised here at runtime instead of being left in place waiting for a file nobody is
   allowed to open. Idempotent, and safe to run again after another lane redraws its tab. */
function sanitizeFalseClaims(){
  document.querySelectorAll('.sumrow').forEach(row => {
    if (/Sincronizzat/i.test(row.textContent)) row.remove();
  });
}

/* ========================================================================================
 * START
 * ====================================================================================== */

rebuildPaywall();
rebuildProfileTab();

/* After nav.js has finished its bootstrap (and after the other lanes have drawn their tabs),
   so the sweep sees the final markup. renderProfile() is called by nav.js itself. */
setTimeout(() => {
  sanitizeFalseClaims();
  // The real versionName beats the constant above: it is what a support ticket will quote.
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (App && App.getInfo){
    App.getInfo().then(i => { if (i && i.version){ APP_VERSION = i.version; renderProfile(); } }).catch(() => {});
  }
}, 0);

document.addEventListener('visibilitychange', () => { if (!document.hidden) ufRefreshExtraPerms(); });
Premium.onChange(() => { ufRenderProCard(); ufRefreshExtraPerms(); });

/* ================= BACKUP E RIPRISTINO =================

   Like AppBlock: the backup lives on OUR server, keyed by the Google account, so it is there
   the moment you sign in on a new phone - no Drive, no hidden folders, nothing an uninstall
   can make invisible. One backup per phone; saving again overwrites this phone's. Restore is
   on demand and always confirmed. The file export/import stays for people without an account.

   Native surface: googleAccount / googleSignIn / googleSignOut / backupList / backupSave /
   backupRestore({id, apply}) / backupDelete({id}). */

const UF_BACKUP_HTML =
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\')">‹</button>' +
    '<span style="flex:1"></span><button class="ghost" id="ufSignOutBtn" onclick="ufSignOut()" style="width:auto;padding:8px 12px;color:var(--blue);font-weight:700" hidden>Esci</button></div>' +
  '<div id="ufBackupBody"></div>' +
  '<div class="panelcard" style="margin-top:14px">' +
    '<b style="font:700 14px var(--font-display)">Su file</b>' +
    '<p style="font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin:4px 0 10px">Un file .json che tieni dove vuoi. Funziona anche senza account.</p>' +
    '<div style="display:flex;gap:8px">' +
      '<button class="ghost" style="flex:1" onclick="ufFileExport()">Esporta</button>' +
      '<button class="ghost" style="flex:1" onclick="ufFileImport()">Importa</button>' +
    '</div>' +
  '</div>' +
  '<p style="font:500 11px/1.5 var(--font-body);color:var(--muted);text-align:center;margin-top:10px">' +
    'Un ripristino sostituisce tutte le regole di questo telefono con quelle del backup. La Modalità severa, se attiva, non viaggia e blocca il ripristino finché non finisce.</p>' +
  '<div class="spacer"></div>';

registerScreen('s-backup', UF_BACKUP_HTML, { back: 's-home' });

function ufOpenBackup(){ goId('s-backup'); ufBackupPaint(); }

/* 0.9.306: le card degli altri dispositivi (ufBackupPaint) */
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.uf-devs{margin-top:24px}',
    '.uf-devs-t{display:block;text-align:center;font:800 15px var(--font-display);color:var(--navy);margin-bottom:12px}',
    '.uf-dev{border:1px solid var(--line);border-radius:16px;padding:14px;background:var(--bg)}',
    '.uf-dev + .uf-dev{margin-top:12px}',
    '.uf-dev-riga{display:flex;align-items:center;gap:12px}',
    '.uf-dev-ico{flex:none;display:flex;align-items:center;justify-content:center;width:42px;height:42px;border-radius:50%;background:#fff;border:1px solid var(--line);font-size:21px;line-height:1}',
    '.uf-dev-txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}',
    '.uf-dev-txt b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:700 14px var(--font-body);color:var(--navy)}',
    '.uf-dev-txt small{font:500 12px var(--font-body);color:var(--muted)}',
    '.uf-dev-nota{font:600 12px/1.4 var(--font-body);color:var(--ink)}',
    '.uf-dev-del{flex:none;display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;border:1.5px solid rgba(230,57,70,.45);background:rgba(230,57,70,.08);color:#E63946;cursor:pointer;padding:0}',
    '.uf-dev-del:active{transform:scale(.94)}',
    '.uf-dev-rip{display:block;width:100%;margin-top:12px;border:0;border-radius:99px;padding:11px 14px;background:#0075E3;color:#fff;font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .uf-dev{background:rgba(255,255,255,.04)}',
    'body.dark .uf-dev-del{color:#FF8A94;border-color:rgba(255,138,148,.5);background:rgba(230,57,70,.14)}'
  ].join('\n');
  document.head.appendChild(st);
})();

function ufWhen(iso){
  if(!iso) return '';
  const d = new Date(iso);
  if(isNaN(d)) return iso;
  return d.toLocaleDateString('it-IT', {day:'2-digit', month:'2-digit', year:'2-digit'}) + ' ' + d.toLocaleTimeString('it-IT', {hour:'2-digit', minute:'2-digit'});
}

function ufHero(icon, title, sub, extra){
  return '<div style="text-align:center;padding:26px 8px 6px">' +
    '<div style="font-size:64px;line-height:1">' + icon + '</div>' +
    '<h2 style="font:800 22px var(--font-display);color:var(--navy);margin:14px 0 4px">' + title + '</h2>' +
    (sub ? '<p style="font:600 13px/1.5 var(--font-body);color:var(--muted);margin:0">' + sub + '</p>' : '') +
    (extra || '') + '</div>';
}

async function ufBackupPaint(){
  const body = document.getElementById('ufBackupBody');
  const out = document.getElementById('ufSignOutBtn');
  if(!body) return;
  if(!NATIVE){
    body.innerHTML = ufHero('☁️', 'Anteprima', 'Il backup sull\'account funziona nell\'app installata.');
    return;
  }
  /* Sul computer l'accesso con Google non c'e' ancora: mostrare il pulsante voleva dire far
     premere una cosa che risponde "googleSignIn is not a function". Un pulsante che non puo'
     funzionare e' peggio di un pulsante che non c'e'. La card "Su file" qui sotto invece
     funziona, ed e' lo stesso identico file del telefono: e' cosi' che i dati passano
     dall'uno all'altro. */
  if(!NATIVE.googleSignIn || !NATIVE.googleAccount){
    if(out) out.hidden = true;
    body.innerHTML = ufHero('💾', 'Backup e ripristino',
      'Su questo computer il backup si fa con un file. È lo stesso formato del telefono: esporta di là, importa di qua.');
    return;
  }
  let a = null;
  try{ a = await NATIVE.googleAccount(); }catch(_){ }
  if(!(a && a.signedIn)){
    if(out) out.hidden = true;
    body.innerHTML = ufHero('☁️', 'Backup e ripristino',
      'Accedi con Google: il backup è legato al tuo account e lo ritrovi su qualsiasi telefono.',
      '<button class="cta" style="margin-top:18px" onclick="ufSignIn()">Accedi con Google</button>');
    return;
  }
  if(out) out.hidden = false;
  body.innerHTML = ufHero('☁️', 'Il tuo backup', esc(a.email || ''), '<div class="hintline" style="margin-top:12px">Leggo i backup del tuo account…</div>');

  let r = null, err = null;
  try{ r = await NATIVE.backupList(); }catch(e){ err = e; }
  if(!r){
    const why = err ? (err.message || String(err)) : 'nessuna risposta';
    body.innerHTML = ufHero('⚠️', 'Backup non leggibile', esc(why),
      '<button class="ghost" style="margin-top:14px" onclick="ufBackupPaint()">Riprova</button>');
    return;
  }
  /* Le righe di sistema (prefisso «fl:») non sono backup di nessun dispositivo: sono documenti
     che l'app usa per parlare con se' stessa. Il motore Android le toglie gia' dall'elenco, ma
     il filtro sta anche qui perche' questa schermata gira anche dentro alla vista telefono del
     computer, che quel filtro non ce l'ha. */
  const list = (r.backups || []).filter(function(b){ return !ufRigaDiSistema(b && b.deviceId); });
  const mine = list.find(function(b){ return b.deviceId === r.thisDevice; });
  const others = list.filter(function(b){ return b.deviceId !== r.thisDevice; });

  let html = '';
  if(!list.length){
    html += ufHero('☁️', 'Nessun backup ancora', 'Salva quello di questo telefono: lo ritroverai al prossimo accesso, anche dopo una reinstallazione.');
  } else {
    const b = mine || others[0];
    html += ufHero('✅', 'Il tuo backup',
      esc(b.deviceName || b.deviceId) + '<br>' + ufWhen(b.updatedAt || b.createdAt),
      '<p style="font:600 13.5px/1.5 var(--font-body);color:var(--ink);margin:14px 0 0">Puoi ripristinare i Programmi e il Blocco rapido da questo backup' +
        ' <span style="color:var(--muted);font-weight:500">(' + (b.programs||0) + ' programmi · ' + (b.apps||0) + ' app · ' + (b.sites||0) + ' siti · ' + (b.keywords||0) + ' parole)</span>.</p>' +
      '<div style="display:flex;gap:10px;margin-top:16px">' +
        '<button class="cta" style="flex:1" onclick="ufBackupRestore(' + b.id + ', \'' + esc(b.deviceName || '') + '\')">Ripristina</button>' +
        '<button class="cta" style="flex:1;background:var(--red);box-shadow:none" onclick="ufBackupDelete(' + b.id + ', \'' + esc(b.deviceName || '') + '\')">Elimina</button>' +
      '</div>');
    if(others.length && mine){
      /* 0.9.306, Andrea (screenshot 664): "Elimina" usciva dal pannello, il nome andava a capo, la frase del computer era
         spezzata su cinque righe e l'icona era quella di un telefono. LA CAUSA: ogni dispositivo era una .setrow (una riga
         sola con nome, data, frase e due pulsanti in fila) dentro a un pannello largo poco piu' di 300 punti: non ci stava,
         e il pulsante finiva fuori. Adesso ogni dispositivo e' una card sua: icona giusta, nome su una riga (con i puntini
         se e' lungo), data sotto, la frase, il cestino dentro la card; il Ripristina, quando si puo', sotto e largo. */
      html += '<div class="panelcard uf-devs"><b class="uf-devs-t">Altri dispositivi con questo account</b>';
      others.forEach(function(o){
        const pc = ufDaComputer(o);
        /* "(Windows)" in coda lo dice gia' l'icona del computer: senza, il nome intero ci sta */
        const nome = esc(String(o.deviceName || o.deviceId || '').replace(/\s*\((Windows|Android)\)\s*$/i, '') || o.deviceId);
        const arg = o.id + ', \'' + esc(o.deviceName || '') + '\'';
        html += '<div class="uf-dev">'
          + '<div class="uf-dev-riga">'
          +   '<span class="uf-dev-ico" aria-hidden="true">' + (pc ? '💻' : '📱') + '</span>'
          +   '<div class="uf-dev-txt"><b>' + nome + '</b><small>' + ufWhen(o.updatedAt || o.createdAt) + '</small>'
          /* Niente pulsante, e il motivo scritto: e' il backup dell'altra specie di dispositivo, e i due motori di blocco
             non parlano la stessa lingua. Toccarlo qui vorrebbe dire solo cancellarsi le regole del telefono, ed e' successo. */
          +     (ufCompatibile(o) ? '' : '<span class="uf-dev-nota">' + (pc ? 'Si ripristina dal computer' : 'Si ripristina dal telefono') + '</span>')
          +   '</div>'
          +   '<button type="button" class="uf-dev-del" aria-label="Elimina" title="Elimina" onclick="ufBackupDelete(' + arg + ')">'
          +     '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
          +   '</button>'
          + '</div>'
          + (ufCompatibile(o) ? '<button type="button" class="uf-dev-rip" onclick="ufBackupRestore(' + arg + ')">Ripristina</button>' : '')
          + '</div>';
      });
      html += '</div>';
    }
  }
  /* La via di ritorno, visibile solo se c'e' davvero qualcosa da annullare. */
  const undo = list.filter(function(b){ return b.deviceId === UF_UNDO; })[0];
  if (undo){
    html += '<div class="panelcard" style="margin-top:14px">'
      + '<b style="font:700 13px var(--font-display)">\u21a9\ufe0f Torna indietro</b>'
      + '<p style="font:500 12.5px/1.6 var(--font-body);color:var(--muted);margin:8px 0 12px">'
      +   'Com\'era subito prima dell\'ultimo ripristino, del ' + ufWhen(undo.updatedAt || undo.createdAt)
      +   ' (' + (undo.programs || 0) + ' programmi · ' + (undo.sites || 0) + ' siti).</p>'
      + '<button class="cta" style="width:100%" onclick="ufAnnullaRipristino()">Annulla l\'ultimo ripristino</button>'
      + '</div>';
  }

  html += '<p style="font:600 13px var(--font-body);color:var(--muted);text-align:center;margin:26px 0 8px">' + (list.length ? 'Oppure puoi aggiornare il backup:' : 'Crea il backup di questo telefono:') + '</p>' +
    '<button class="cta" id="ufBackupSaveBtn" style="margin-top:4px" onclick="ufBackupSave()">' + (mine ? 'Aggiorna il backup adesso' : 'Completa subito il backup') + '</button>'
;
  body.innerHTML = html;
}

async function ufSignIn(){
  if(!NATIVE){ toast('Disponibile nell\'app installata'); return; }
  if(!NATIVE.googleSignIn){ toast('Su questo computer usa il file qui sotto'); return; }
  try{
    const r = await NATIVE.googleSignIn();
    if(r && r.signedIn) toast('Collegato: ' + r.email);
  }catch(e){ toast(e && e.message ? e.message : 'Accesso non riuscito'); }
  ufBackupPaint();
}

async function ufSignOut(){
  try{ await NATIVE.googleSignOut(); }catch(_){ }
  toast('Account scollegato');
  ufBackupPaint();
}

/* ------------------------------------------------------------------------------------------
   QUELLO CHE LA PAGINA SI PORTA DIETRO.

   Meta' di questa app vive nel localStorage della pagina, non nelle regole del motore: il
   mantra, la foto del "tuo perche'", gli appunti, i punteggi, i livelli, le preferenze, le
   personalizzazioni. Il lato nativo quella roba non la puo' leggere, quindi finiva fuori dal
   backup senza che nessuno lo dicesse — e chi disinstallava l'app per qualunque motivo si
   ritrovava a rifare tutto da capo. Adesso gliela passa la pagina, e al ripristino se la
   riprende.

   Cosa NON viaggia: la sessione di concentrazione in corso e le chiavi di servizio. Sono cose
   di questo minuto su questo telefono. */
/* Le righe di sistema dell'archivio: non sono backup di nessun dispositivo, sono documenti
   che l'app usa per parlare con se' stessa fra telefono e computer (il tabellone della partita,
   i minuti d'uso del PC). Il prefisso «fl:» le raccoglie tutte, comprese quelle future. */
function ufRigaDiSistema(id){
  id = String(id || '');
  return id === 'match-score' || id.indexOf('fl:') === 0;
}

/* IL TABELLONE NON VA NEL BACKUP (6/10/2026). Ogni dispositivo tiene il conto dei punti segnati
   da LUI (livescore.js): ripristinarlo su un dispositivo nuovo gli fa dichiarare come suoi i
   punti di un altro, e alla somma valgono due volte. E' cosi' che il 6-3 e' diventato 9-6
   installando DreamMap su un secondo computer. Il punteggio vero arriva dall'account. */
const UF_SKIP = ['fl_ff_session', 'fl_boot', 'fl_tab', 'fl_match', 'fl_match_hist', 'fl_match_sync', 'fl_match_lastday'];

function flWebDump(){
  const out = {};
  let total = 0;
  try{
    for (let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if (!k || k.indexOf('fl_') !== 0) continue;
      if (UF_SKIP.indexOf(k) >= 0) continue;
      const v = localStorage.getItem(k);
      if (v === null) continue;
      /* Un tetto, perche' il backup viaggia in rete: le immagini sono gia' ritagliate a 320
         pixel e pesano poche decine di KB, ma se qualcosa fosse enorme meglio lasciarlo fuori
         che far fallire tutto il salvataggio. */
      if (v.length > 700000) continue;
      /* 0.9.307: continue e non break. L'ordine del localStorage e' casuale: con break, oltre il tetto restavano
         fuori TUTTE le chiavi seguenti, anche le piccole (nella foto del 15/10 mancava fl_onboarded) */
      if (total + v.length > 3000000) continue;
      out[k] = v;
      total += v.length;
    }
  }catch(_){ }
  return out;
}

function flWebRestore(web){
  if (!web) return 0;
  let n = 0;
  try{
    Object.keys(web).forEach(function(k){
      if (!k || k.indexOf('fl_') !== 0 || UF_SKIP.indexOf(k) >= 0) return;
      try{ localStorage.setItem(k, String(web[k])); n++; }catch(_){ }
    });
  }catch(_){ }
  return n;
}

async function ufBackupSave(quiet){
  const btn = document.getElementById('ufBackupSaveBtn');
  if(btn && !quiet){ btn.disabled = true; btn.textContent = 'Salvo…'; }
  try{
    const r = await NATIVE.backupSave({ web: flWebDump() });
    const s = (r && r.summary) || {};
    try{ localStorage.setItem('fl_backup_at', String(Date.now())); }catch(_){ }
    if(!quiet) toast('Backup salvato: ' + (s.programs||0) + ' programmi, ' + ((s.sites||0)+(s.keywords||0))
      + ' siti e parole, ' + (s.personal||0) + ' personalizzazioni');
  }catch(e){ if(!quiet) toast(e && e.message ? e.message : 'Backup non salvato'); }
  if(!quiet) ufBackupPaint();
}

/* IL BACKUP CHE NON BISOGNA RICORDARSI DI FARE.

   Un backup manuale lo fa chi ha gia' perso tutto una volta. Chi non l'ha ancora perso non ci
   pensa — ed e' esattamente quello a cui serve. Quindi: se c'e' un account collegato e l'ultimo
   salvataggio ha piu' di un giorno, se ne fa uno in silenzio, qualche secondo dopo l'avvio. */
async function ufBackupAuto(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupSave || !NATIVE.googleAccount) return;
    const acc = await NATIVE.googleAccount();
    if (!acc || !acc.email) return;
    let last = 0;
    try{ last = parseInt(localStorage.getItem('fl_backup_at') || '0', 10) || 0; }catch(_){ }
    if (Date.now() - last < 20 * 3600000) return;
    await ufBackupSave(true);
    console.log('backup automatico fatto');
  }catch(_){ }
}
setTimeout(ufBackupAuto, 9000);

/* ------------------------------------------------------------------------------------------
   IL FILE, CHE RESTA A TE.

   Il backup sull'account dipende da tre cose che possono mancare tutte insieme: essere
   collegati, avere rete, e che il server risponda. Un file no. Lo salvi dove vuoi e vale anche
   fra un anno, anche su un altro telefono. E' l'unica copia che non dipende da noi. */
async function ufBackupFile(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupToFile){ toast('Disponibile nell\'app installata'); return; }
  /* 0.9.289: il backup di tutta l'app va dritto in Download (niente "Salva con nome"), con Condividi */
  if (NATIVE.backupInDownload){
    try{
      const r = await NATIVE.backupInDownload({ web: flWebDump() });
      if (r && r.saved){
        try{ localStorage.setItem('fl_backup_at', String(Date.now())); }catch(_){ }
        if (typeof flFileSalvato === 'function') flFileSalvato('Backup salvato in Download (' + Math.max(1, Math.round((r.bytes || 0) / 1024)) + ' KB)', r.uri, 'application/json');
        else toast('Backup salvato in Download');
      }
    }catch(e){ toast((e && e.message) || 'Backup non salvato'); }
    return;
  }
  try{
    const r = await NATIVE.backupToFile({ web: flWebDump() });
    if (r && r.saved){
      try{ localStorage.setItem('fl_backup_at', String(Date.now())); }catch(_){ }
      toast('Backup salvato nel file');
    }
  }catch(e){
    const m = (e && e.message) || '';
    if (!/annullat/i.test(m)) toast(m || 'Backup non salvato');
  }
}

async function ufRestoreFile(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupFromFile){ toast('Disponibile nell\'app installata'); return; }
  const ok = await ufAsk('Ripristinare da un file?',
    'Sostituisce regole e personalizzazioni di questo telefono con quelle del file.', 'Scegli il file', true);
  if (!ok) return;
  try{
    const r = await NATIVE.backupFromFile();
    if (r && r.applied){
      const n = flWebRestore(r.web);
      const s = r.summary || {};
      toast('Ripristinati: ' + (s.programs||0) + ' programmi, ' + n + ' personalizzazioni');
      setTimeout(function(){ location.reload(); }, 1500);
    }
  }catch(e){
    const m = (e && e.message) || '';
    if (!/nessun file/i.test(m)) toast(m || 'Ripristino non riuscito');
  }
}

/* IL PRIMO AVVIO DOPO UN'INSTALLAZIONE.

   Qui c'e' l'unico momento in cui si puo' evitare a qualcuno di rifare tutto da capo: l'app e'
   appena nata, non ha niente dentro, e sull'account potrebbe esserci la sua vita di prima.
   Chiederlo dopo non serve — a quel punto ha gia' ricominciato a configurare a mano. */
async function ufOfferRestore(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.backupList) return;
    let fresh = false;
    try{ fresh = !localStorage.getItem('fl_restore_asked'); }catch(_){ }
    if (!fresh) return;
    /* "Appena installata" vuol dire: nessun mantra, nessuna immagine, nessun appunto. Se c'e'
       gia' roba dentro non si tocca niente e non si chiede niente. */
    let has = false;
    try{
      has = !!(localStorage.getItem('fl_why') || localStorage.getItem('fl_why_img')
            || localStorage.getItem('fl_match') || localStorage.getItem('fl_ff_hist'));
    }catch(_){ }
    try{ localStorage.setItem('fl_restore_asked', '1'); }catch(_){ }
    if (has) return;
    const acc = await NATIVE.googleAccount();
    if (!acc || !acc.email) return;
    const l = await NATIVE.backupList();
    const list = (l && l.backups) || [];
    if (!list.length) return;
    const b = list[0];
    const when = b.createdAt ? ufWhen(b.createdAt) : '';
    const ok = await ufAsk('Ho trovato un tuo backup',
      'Sul tuo account c\'\u00e8 un backup' + (when ? ' di ' + when : '') + ' con regole, mantra, immagini e personalizzazioni. Lo rimetto?',
      'Ripristina', false);
    if (!ok) return;
    await ufBackupRestore(b.id, b.device || 'il tuo backup');
  }catch(_){ }
}
setTimeout(ufOfferRestore, 6000);

function ufAsk(title, text, ok, danger){
  if(typeof blkConfirm === 'function') return blkConfirm(title, text, ok, danger);
  return Promise.resolve(window.confirm(title + '\n\n' + (text || '')));
}

/* ---------------------------------------------------------------------------------------
   LE DUE SPECIE DI BACKUP

   Il computer scrive il suo backup nello stesso archivio del telefono, ed e' giusto: e' lo
   stesso account. Ma i due motori di blocco sono DIVERSI — programmi, app, regole: su Windows
   sono un'altra cosa. Ripristinare un backup di Windows su un telefono non e' una funzione
   avanzata, e' solo un modo per cancellarsi le regole, ed e' successo davvero.

   Si riconosce dallo slot, non dal nome visibile: il desktop scrive sempre `win-…`. Un nome si
   puo' cambiare, un identificativo no.
   --------------------------------------------------------------------------------------- */
function ufDaComputer(b){
  return String((b && b.deviceId) || '').indexOf('win-') === 0;
}
function ufSonoTelefono(){
  try{ return !(typeof Capacitor !== 'undefined' && Capacitor.getPlatform && Capacitor.getPlatform() === 'desktop'); }
  catch(_){ return true; }
}
/** Se questa riga puo' essere ripristinata QUI: stessa specie, o niente. */
function ufCompatibile(b){
  return ufDaComputer(b) !== ufSonoTelefono();
}

const UF_UNDO = 'fl:undo';

/**
 * La copia di sicurezza che precede ogni ripristino.
 *
 * <p>Va in una riga riservata dell'archivio: l'elenco dei backup non la mostra (prefisso
 * «fl:») e quindi nessuno puo' cancellarla per sbaglio, ma vive nell'account e sopravvive
 * anche a una reinstallazione. Se questa fallisce, il ripristino NON si fa: meglio non
 * ripristinare che ripristinare senza poter tornare indietro.</p>
 */
async function ufSnapshot(){
  try{
    const r = await NATIVE.backupSave({
      web: (typeof flWebDump === 'function') ? flWebDump() : {},
      slot: UF_UNDO,
      slotName: 'Prima dell\'ultimo ripristino'
    });
    if (r && r.saved){
      try{ localStorage.setItem('fl_undo_at', String(Date.now())); }catch(_){ }
      return true;
    }
  }catch(_){ }
  return false;
}

/** Torna indietro: rimette quello che c'era un attimo prima dell'ultimo ripristino. */
async function ufAnnullaRipristino(){
  let riga = null;
  try{
    const r = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    riga = ((r && r.backups) || []).filter(function(b){ return b.deviceId === UF_UNDO; })[0] || null;
  }catch(_){ }
  if (!riga){ toast('Non c\'è niente da annullare'); return; }

  const ok = await ufAsk('Annullare l\'ultimo ripristino?',
    'Rimette le regole e le personalizzazioni com\'erano subito prima. Quello che hai '
    + 'ripristinato dopo viene sostituito.', 'Annulla il ripristino', true);
  if (!ok) return;
  try{
    const r = await NATIVE.backupRestore({ id: riga.id, apply: true });
    if (r && r.applied){
      const n = flWebRestore(r.web);
      const g = r.restored || {};
      toast('Rimesso com\'era: ' + (g.programs || 0) + ' programmi, ' + n + ' personalizzazioni');
      setTimeout(function(){ location.reload(); }, 1400);
    } else if (r && r.refusal) toast(r.refusal);
  }catch(e){ toast(e && e.message ? e.message : 'Non sono riuscito ad annullare'); }
}

async function ufBackupRestore(id, label){
  let peek = null;
  try{ peek = await NATIVE.backupRestore({ id: id, apply: false }); }
  catch(e){ toast(e && e.message ? e.message : 'Backup non leggibile'); return; }
  if(peek && peek.refusal){ toast(peek.refusal); return; }
  const s = (peek && peek.summary) || {};

  /* QUANTO HAI ADESSO. La domanda di prima diceva solo cosa sarebbe arrivato: «0 programmi»
     letto come numero in arrivo non allarma nessuno. Detto come «perdi i tuoi 12», ferma la
     mano — ed e' l'unica informazione che conta davvero in quella schermata. */
  let ora = { programs: 0 };
  try{
    const stato = await NATIVE.getRulesFull();
    ora.programs = ((stato && stato.config && stato.config.schedules) || []).length;
  }catch(_){ }

  const perdita = ora.programs > (s.programs || 0)
    ? '\u26a0\ufe0f Adesso hai ' + ora.programs + ' programmi: dopo il ripristino ne avrai '
      + (s.programs || 0) + '. I tuoi verranno sostituiti.\n\n'
    : '';

  const ok = await ufAsk('Ripristinare da ' + (label || 'questo backup') + '?',
    perdita
    + 'Il backup contiene ' + (s.programs||0) + ' programmi, ' + (s.apps||0) + ' app, ' + (s.sites||0) + ' siti, ' + (s.keywords||0) + ' parole'
    + ((s.personal||0) ? ', ' + s.personal + ' personalizzazioni (mantra, immagini, appunti)' : '') +
    (s.createdAt ? ' · salvato ' + ufWhen(s.createdAt) : '') +
    '.\n\nPrima di sostituire, salvo com\'è adesso: potrai annullare.', 'Ripristina', true);
  if(!ok) return;

  /* LA RETE, PRIMA DEL SALTO. Se non riesce a mettere da parte lo stato attuale, non si
     ripristina: un'operazione che cancella e non si puo' annullare non va fatta. */
  toast('Metto da parte com\'è adesso…');
  if (!(await ufSnapshot())){
    const lo = await ufAsk('Non riesco a salvare una copia di sicurezza',
      'Senza quella copia, il ripristino non si può annullare e le regole di adesso si perdono '
      + 'per sempre. Vuoi farlo lo stesso?', 'Ripristina comunque', true);
    if (!lo) return;
  }
  try{
    const r = await NATIVE.backupRestore({ id: id, apply: true });
    if(r && r.applied){
      const g = r.restored || {};
      /* Prima il localStorage, poi il ricaricamento: i moduli rileggono tutto all'avvio, e
         quello che si e' appena rimesso dev'essere gia' li' quando ripartono. */
      const n = flWebRestore(r.web);
      toast('Ripristinati: ' + (g.programs||0) + ' programmi, ' + (g.sites||0) + ' siti, ' + (g.keywords||0)
        + ' parole, ' + n + ' personalizzazioni');
      // A full reload, on purpose: every module re-reads the engine at boot, so nothing
      // that was in memory before the restore can overwrite or hide what was restored.
      setTimeout(function(){ location.reload(); }, 1400);
    } else if(r && r.refusal){ toast(r.refusal); }
  }catch(e){ toast(e && e.message ? e.message : 'Ripristino non riuscito'); }
}

async function ufBackupDelete(id, label){
  const ok = await ufAsk('Eliminare il backup' + (label ? ' di ' + label : '') + '?', 'Sparisce dall\'account. Le regole su questo telefono restano come sono.', 'Elimina', true);
  if(!ok) return;
  try{
    const r = await NATIVE.backupDelete({ id: id });
    if(r && r.deleted){ toast('Backup eliminato'); }
  }catch(e){ toast(e && e.message ? e.message : 'Eliminazione non riuscita'); }
  ufBackupPaint();
}

/* UN SOLO MODO DI SALVARE SU FILE.
   Questi due pulsanti c'erano gia' e salvavano solo le regole: e' il motivo per cui reinstallando
   sparivano mantra, immagini e personalizzazioni. Adesso passano dalla strada completa —
   impostazioni, localStorage e immagini comprese — e la vecchia resta come ripiego per un motore
   non aggiornato. Due pulsanti che fanno la stessa cosa in due modi diversi sono il modo migliore
   per non sapere piu' quale funziona. */
async function ufFileExport(){
  if(!NATIVE){ toast('Disponibile nell\'app installata'); return; }
  if(NATIVE.backupToFile) return ufBackupFile();
  try{ await NATIVE.shareBackupFile(); }catch(e){ toast(e && e.message ? e.message : 'Esportazione non riuscita'); }
}

async function ufFileImport(){
  if(!NATIVE){ toast('Disponibile nell\'app installata'); return; }
  if(NATIVE.backupFromFile) return ufRestoreFile();
  let picked = null;
  try{ picked = await NATIVE.pickBackupFile(); }
  catch(e){ if(e && e.code !== 'cancelled') toast(e.message || 'File non leggibile'); return; }
  if(!picked || !picked.backup) return;
  if(picked.refusal){ toast(picked.refusal); return; }
  const s = picked.summary || {};
  const ok = await ufAsk('Importare questo backup?',
    (s.programs||0) + ' programmi, ' + (s.apps||0) + ' app, ' + (s.sites||0) + ' siti, ' + (s.keywords||0) + ' parole' +
    (s.device ? ' · da ' + s.device : '') + '. Sostituisce tutte le regole di questo telefono.', 'Importa', true);
  if(!ok) return;
  try{
    await NATIVE.importBackup({ backup: picked.backup });
    toast('Ripristinato dal file');
    setTimeout(function(){ location.reload(); }, 1200);
    if(typeof syncNative === 'function') syncNative();
  }catch(e){ toast(e && e.message ? e.message : 'Importazione non riuscita'); }
}

/* ---- Profilo: settimana scorsa vs oggi, sincronizzazione, link esterni ---- */
function ufOpenUrl(url){
  try{
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser){ window.Capacitor.Plugins.Browser.open({ url: url }); return; }
  }catch(_){ }
  window.open(url, '_blank');
}
async function ufRefreshWeekCard(){
  const card = document.getElementById('profWeek');
  if(!card) return;
  if(!NATIVE || !NATIVE.getScreenTimeRange){ card.hidden = true; return; }
  try{
    const now = Date.now();
    const start = new Date(); start.setHours(0,0,0,0);
    const dayMs = 86400000;
    const r = await NATIVE.getScreenTimeRange({ from: start.getTime() - 7*dayMs, to: start.getTime(), bucket: 'day' });
    const today = await NATIVE.getScreenTimeToday();
    if(!(r && r.granted)){ card.hidden = true; return; }
    const days = (r.buckets || []).map(b => b.minutes || 0);
    const avg = days.length ? Math.round(days.reduce((a,b)=>a+b,0) / days.length) : 0;
    const t = (today && today.minutes) || 0;
    const fmt = m => (m >= 60 ? Math.floor(m/60) + 'h ' : '') + (m % 60) + 'm';
    document.getElementById('pwAvg').textContent = fmt(avg);
    document.getElementById('pwToday').textContent = fmt(t);
    const tr = document.getElementById('pwTrend');
    tr.textContent = t > avg ? '↗' : (t < avg ? '↘' : '→');
    tr.style.color = t > avg ? 'var(--red)' : '#22B14C';
    card.hidden = false;
  }catch(_){ card.hidden = true; }
}
/* The card is an invitation to sign in. Once the Google account is there it has nothing
   left to say: the Account row below carries the email, Backup carries the rest. */
async function ufRefreshSyncCard(){
  const card = document.getElementById('ufSyncCard');
  if(!card || !NATIVE || !NATIVE.googleAccount) return;
  try{
    const a = await NATIVE.googleAccount();
    card.hidden = !!(a && a.signedIn);
  }catch(_){ }
}


/* ---- Account screen ---- */
(function accStyle(){
  const st = document.createElement('style');
  st.textContent = '.acc-av{text-align:center;margin:10px 0 22px}'
    + '.acc-av .av{width:112px;height:112px;border-radius:50%;background:var(--blue);color:#fff;display:inline-flex;align-items:center;justify-content:center;font:800 46px var(--font-display);cursor:pointer;background-size:cover;background-position:center}'
    + '.av.has-pic{background-color:#0A1A2F;color:transparent}'
    + '.acc-av-edit{display:block;margin:14px auto 0;border:1px solid var(--line);background:#fff;border-radius:99px;padding:9px 18px;font:700 12.5px var(--font-body);color:var(--navy);cursor:pointer}'
    + '.acc-av-x{display:block;margin:8px auto 0;border:0;background:none;font:600 12px var(--font-body);color:var(--muted);cursor:pointer;text-decoration:underline}'
    + '.acc-av-x[hidden]{display:none}'
    + '.acc-bio{margin-top:10px;resize:none;line-height:1.5}'
    + '.acc-birth{margin-top:0}.acc-birth-w{position:relative;display:block}.acc-birth-w svg{position:absolute;left:14px;top:50%;margin-top:-12px;pointer-events:none;z-index:1}.acc-birth-w .acc-birth{width:100%;box-sizing:border-box;padding-left:50px;position:relative}.acc-birth-w .acc-birth::-webkit-calendar-picker-indicator{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer}'
    + '.chi-f-r small{white-space:normal!important;overflow:visible!important;text-overflow:clip!important}.acc-sect-i{display:flex;align-items:center;justify-content:center;gap:8px}.acc-sesso{display:flex;flex-direction:column;gap:2px;margin-top:4px}.acc-sesso button{display:flex;align-items:center;gap:12px;padding:10px 4px;border:0;background:none;color:var(--navy);font:600 15px var(--font-body);text-align:left;cursor:pointer}body.dark .acc-sesso button{color:#fff}.acc-sesso i{flex:none;width:20px;height:20px;box-sizing:border-box;border:2px solid #9FB2D0;border-radius:50%}.acc-sesso button.on{color:#0075E3}.acc-sesso button.on i{border:6px solid #0075E3}'
    + '.prof-report{display:flex;align-items:center;gap:14px;background:linear-gradient(135deg,#0B2A55,#001E44);color:#fff;border-radius:20px;padding:18px;margin:14px 0 4px;cursor:pointer}'
    + '.prof-report .art{font-size:30px;line-height:1;flex:none}'
    + '.prof-report > div{flex:1;min-width:0}'
    + '.prof-report b{display:block;font:800 17px var(--font-display);font-style:italic}'
    + '.prof-report small{display:block;font:500 12px/1.5 var(--font-body);color:rgba(255,255,255,.8);margin-top:3px}'
    + '.prof-report .go{width:10px;height:10px;border-right:2px solid rgba(255,255,255,.85);border-top:2px solid rgba(255,255,255,.85);transform:rotate(45deg);flex:none}'
    + '.acc-hint{display:block;margin:6px 4px 0;font:500 11.5px var(--font-body);color:var(--faint)}'
    + '.acc-now{background:#F4F9FF;border-radius:14px;padding:14px;margin-top:14px}'
    + '.acc-now b{display:block;font:700 11px var(--font-body);letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}'
    + '.acc-now p{margin:6px 0 10px;font:600 14px/1.5 var(--font-body);color:var(--navy)}'
    + '.acc-now .ghostmini{margin:0}'
    + 'body.dark .acc-now{background:#0E1E3A}body.dark .acc-now p{color:#fff}'
    /* 0.9.305: l'altezza della frase piu' alta (etichetta + mantra), cosi' il punteggio sotto non salta
       di qualche pixel ogni sei secondi quando arriva la riga "Membro Premium dal ..." */
    + '#profSince{min-height:40px;display:flex;flex-direction:column;justify-content:center}'
    + '.prof-hero .since .since-in{display:block;animation:ufSinceIn .55s ease-out both}'
    + '.prof-hero .since i{display:block;font:700 10px var(--font-body);font-style:normal;letter-spacing:.12em;text-transform:uppercase;opacity:.72;margin-bottom:3px}'
    + '@keyframes ufSinceIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
    /* "Tempo risparmiato", under the two cards */
    + '.saved{background:#fff;border:1px solid var(--line);border-radius:18px;padding:16px 16px 14px;margin:14px 0 4px}'
    + '.saved-head{display:flex;align-items:center;gap:8px;margin-bottom:12px}'
    + '.saved-head b{font:800 15px var(--font-display);color:var(--navy);flex:1}'
    + '.saved-i{width:20px;height:20px;border-radius:50%;border:1px solid var(--line);background:none;font:700 11px var(--font-body);color:var(--muted);cursor:pointer}'
    + '.saved-sel{position:relative;display:block;margin-bottom:14px}'
    + '.saved-sel select{width:100%;appearance:none;-webkit-appearance:none;border:1px solid var(--line);background:#fff;border-radius:14px;padding:12px 40px 12px 14px;font:700 13px var(--font-body);color:var(--navy);outline:none}'
    + '.saved-sel .blk-tplchev{position:absolute;right:14px;top:50%;transform:translateY(-50%);pointer-events:none}'
    + '.saved-hero{display:flex;flex-direction:column;align-items:center;text-align:center;background:#F4F9FF;border-radius:16px;padding:18px 14px 16px}'
    + '.saved-emoji{font-size:54px;line-height:1;margin-bottom:10px}'
    + '.saved-big{display:block;font:800 30px/1.1 var(--font-display);font-style:italic;color:#0E7C6B}'
    + '.saved-cap{display:block;font:700 12.5px var(--font-body);color:var(--navy);margin-top:8px}'
    + '.saved-sub{display:block;font:500 11.5px var(--font-body);color:var(--muted);margin-top:3px}'
    + '.saved-note{display:block;margin-top:12px;font:500 11px/1.45 var(--font-body);color:var(--faint);text-align:center}'
    + 'body.dark .saved{background:#12203A;border-color:#22345A}body.dark .saved-head b{color:#fff}body.dark .saved-hero{background:#0E1E3A}body.dark .saved-sel select{background:#12203A;border-color:#22345A;color:#fff}'
    + 'body.dark .acc-av-edit{background:#12203A;border-color:#22345A;color:#fff}'
    + '.acc-name{text-align:center;font:700 17px var(--font-body) !important}'
    + '.acc-nome{margin:10px 0 0;text-align:center;font:800 22px var(--font-display);font-style:italic;color:var(--navy)}body.dark .acc-nome{color:#fff}'
    + '.acc-edit{display:block;margin:10px auto 0;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:9px 18px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}body.dark .acc-edit{background:#12203A;border-color:#22345A;color:#fff}'
    /* 0.9.308: nome con la matita accanto (il nome resta al centro: la matita gli sta di fianco, fuori dal conto),
       "Su DreamMap da ..." sopra al pannello dei seguiti, "Modifica profilo" in fondo a "Chi sono" */
    + '.acc-nome-riga{display:flex;justify-content:center;margin:10px 0 0}.acc-nome-in{position:relative;display:inline-block;max-width:calc(100% - 88px)}'
    + '.acc-nome-riga .acc-nome{margin:0;overflow-wrap:anywhere}'
    + '.acc-matita{position:absolute;left:100%;top:50%;transform:translateY(-50%);margin-left:8px;width:34px;height:34px;border-radius:50%;border:1.5px solid var(--line);background:var(--card,#fff);color:#0075E3;display:grid;place-items:center;padding:0;cursor:pointer;-webkit-tap-highlight-color:transparent}'
    + 'body.dark .acc-matita{background:#12203A;border-color:#22345A;color:#8CC6FF}'
    + '.acc-da{margin:12px 0 -8px;text-align:center;font:600 13px var(--font-body);color:var(--muted)}body.dark .acc-da{color:#BCE0FF}'
    + '.acc-ab-sez .acc-edit{margin-top:16px}'
    + '.pf-prem-riga{margin:10px 0 -6px;line-height:1}.pf-prem-riga .pf-prem{margin:0;font-size:11.5px;padding:5px 12px 4px}.pf-prem[hidden]{display:none!important}'
    + '#profSince:empty{min-height:0}'
    + '.acc-cinema{margin-top:24px}.acc-memento .mm-top{display:none}'
    + '.acc-mail{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px}'
    + '.acc-mail b{font:600 13.5px var(--font-body);color:var(--navy);word-break:break-all}'
    + '.acc-del{border:none;background:none;color:var(--faint);font:600 13px var(--font-body);margin-top:14px;cursor:pointer}'
    + 'body.dark .acc-mail{background:#12203A;border-color:#22345A}body.dark .acc-mail b{color:#fff}';
  document.head.appendChild(st);
})();

/* ===========================================================================================
   I TRE NUMERI DEL PROFILO

   Percentuale di successo, alberi, alberi veri: la stessa riga della scheda profilo di Forest,
   con una differenza voluta. Forest conta solo gli alberi cresciuti; qui accanto a quelli ci
   sono anche quelli appassiti, perche' una percentuale senza il suo denominatore e' una
   medaglia, e una medaglia non insegna niente.

   Da dove vengono i numeri:
     · la percentuale  — le distrazioni fermate sul totale delle occasioni, gli stessi due
       numeri del tabellone dell'arbitro nella scheda Blocco. Un numero solo, contato in un
       posto solo: se qui dicesse una cosa e li' un'altra, nessuno dei due varrebbe niente.
     · gli alberi      — le sessioni di FullFocus portate a termine, e quelle abbandonate.
     · gli alberi veri — quelli piantati davvero con Tree-Nation, che sono cinque in tutta la
       vita dell'account: e' l'unico numero qui dentro che esiste anche fuori dal telefono.
   =========================================================================================== */
async function accForestPaint(){
  const box = document.getElementById('accSlider');
  if (!box) return;

  const sani = (typeof ffHist === 'function') ? ffHist().filter(function(x){ return x && x.ok; }).length : 0;
  const secchi = (typeof ffWithered === 'function') ? ffWithered() : 0;
  let veri = 0;
  try{ veri = (JSON.parse(localStorage.getItem('fl_trees') || '[]') || []).length; }catch(_){ }

  let pct = null;
  try{
    if (typeof arbCeduto === 'function' && typeof arbTenuto === 'function'){
      const si = arbCeduto(3650);
      const no = await arbTenuto(3650);
      if (si + no > 0) pct = Math.round(no * 100 / (si + no));
    }
  }catch(_){ }

  /* in cima: dove sei, e con chi (0.9.205: una riga sola, niente carosello) */
  let perc = 0; try{ perc = (typeof hdPercorso === 'function') ? Math.round(hdPercorso().pct * 100) : 0; }catch(_){ }
  let seguiti = 0, follower = 0;
  try{ const A = (typeof FR !== 'undefined' && FR && FR.amici) || null; if (A){ seguiti = A.seguiti != null ? A.seguiti : (A.amici || []).length; follower = A.follower || 0; } }catch(_){ }
  box.innerHTML = '<div class="acc-forest">'
    + accStat('🧭 ' + perc + '%', 'Del percorso', 'Quanto del viaggio verso il sogno hai già fatto: tappe della mappa e strada percorsa.')
    + '<i class="sep"></i>' + accStat(String(seguiti), 'Seguiti', 'Le persone che segui.')
    + '<i class="sep"></i>' + accStat(String(follower), 'Follower', 'Le persone che seguono te.') + '</div>';
  ACC_NUM = { sani: sani, secchi: secchi, veri: veri, pctBlocchi: pct };
  try{ accPanCarPaint(); }catch(_){ }
  /* gli amici si chiedono UNA volta per apertura: se il server risponde vuoto, non si rientra qui in loop */
  try{ if (typeof frAmiciCarica === 'function' && !(FR.amici && FR.amici.amici) && !box.dataset.amiciChiesti){ box.dataset.amiciChiesti = '1'; frAmiciCarica(false).then(function(){ if (document.getElementById('accSlider') && FR.amici && FR.amici.amici) accForestPaint(); }); } }catch(_){ }
}
let ACC_NUM = null;
/* ---- LA PANORAMICA (0.9.205): un carosello, UN numero per slide ---- */
function accPanCarHtml(){
  const N = ACC_NUM || { sani: 0, secchi: 0, veri: 0, pctBlocchi: null };
  let app = 0, sev = 0, ff = 0, liv = 1, nome = '';
  try{ app = hdSerie(); }catch(_){ }
  try{ sev = sevStreakDays(typeof sevState !== 'undefined' ? sevState : null) || 0; }catch(_){ }
  try{ ff = serStreak() || 0; }catch(_){ }
  try{ liv = (typeof LV !== 'undefined' && LV.level) || 1; nome = (typeof LV_LEVELS !== 'undefined' && LV_LEVELS[liv - 1] && LV_LEVELS[liv - 1].name) || ''; }catch(_){ }
  const tot = N.sani + N.secchi; const pctA = tot ? Math.round(N.sani * 100 / tot) : null;
  const g = function(ico, v, t, sotto){ return '<div class="acc-car-s"><span class="acc-car-ico">' + ico + '</span><b>' + v + '</b><small>' + t + '</small><em>' + sotto + '</em></div>'; };
  const gg = function(n, u){ return n + ' ' + (n === 1 ? u[0] : u[1]); };
  const slides = [
    g('⭐', pctA === null ? '0%' : pctA + '%', 'Stelle accese', tot ? N.sani + ' su ' + tot + ' · ' + N.veri + (N.veri === 1 ? ' albero vero' : ' alberi veri') : 'La prima sessione di Full Focus accende la prima'),
    g('🔒', gg(sev, ['giorno', 'giorni']), 'Modalità severa di fila', N.pctBlocchi === null ? 'Nessun blocco scattato ancora' : N.pctBlocchi + '% dei blocchi fermati'),
    g('🔥', gg(app, ['giorno', 'giorni']), 'Serie nell’app', 'Una tappa al giorno la allunga'),
    g('⏱️', gg(ff, ['giorno', 'giorni']), 'Full Focus di fila', 'Una sessione al giorno'),
    g('⭐', 'Livello ' + liv, nome || 'Il tuo livello', 'Gli XP delle tappe lo alzano')
  ];
  return '<div class="acc-car" onscroll="accCarDot(this)">' + slides.join('') + '</div><div class="acc-dots acc-car-dots">' + slides.map(function(_, i){ return '<i' + (i === 0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div>';
}
function accCarDot(el){ const i = Math.round(el.scrollLeft / Math.max(1, el.clientWidth)); const dots = el.parentElement.querySelector('.acc-car-dots'); if (dots) dots.querySelectorAll('i').forEach(function(d, j){ d.classList.toggle('on', j === i); }); }
function accPanCarPaint(){ document.querySelectorAll('.acc-pan-car').forEach(function(h){ h.innerHTML = accPanCarHtml(); }); }
function accOnlineHtml(){
  let att = 'Nell’app, adesso';
  try{ if (typeof FF !== 'undefined' && FF && FF.run) att = 'In Full Focus' + (FF.run.intent ? ' su «' + esc(String(FF.run.intent).slice(0, 40)) + '»' : ''); else if (typeof sevState !== 'undefined' && sevState && sevState.level > 0) att = 'Modalità severa accesa'; }catch(_){ }
  return '<div class="acc-online"><span class="acc-dot"></span><div><b>Online</b><small>' + att + '</small></div></div>';
}
function accSliderDot(el){ const i = Math.round(el.scrollLeft / Math.max(1, el.clientWidth)); document.querySelectorAll('#accDots i').forEach(function(d, j){ d.classList.toggle('on', j === i); }); }
/** I sogni realizzati: la rotta arrivata a destinazione li scrive qui (fl_sogni_realizzati). */
function accSogniRealizzati(){ try{ return JSON.parse(localStorage.getItem('fl_sogni_realizzati') || '[]') || []; }catch(_){ return []; } }
function accSogniApri(){
  const l = accSogniRealizzati();
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3 class="fr-agg-h">Sogni realizzati</h3>'
    + (l.length ? '<div class="acc-sogni">' + l.map(function(x){ return '<div class="acc-sogno"><span>🏁</span><div><b>' + esc(x.nome || x.n || 'Un sogno') + '</b><small>' + esc(x.quando || '') + '</small></div></div>'; }).join('') + '</div>'
      : '<p class="sf-mis-vuoto">Il primo lo scrive la rotta, il giorno in cui arrivi a destinazione. Fino ad allora, una tappa al giorno.</p>') + '</div>');
}
/* ---- amici, stato, panoramica (0.9.204) ---- */
function accSocialPaint(){ /* i due pulsanti sono nel markup; qui niente da ridisegnare */ }
function accOnlinePaint(){
  const box = document.getElementById('accOnline'); if (!box) return;
  let att = 'Nell’app, adesso';
  try{ if (typeof FF !== 'undefined' && FF && FF.run) att = 'In Full Focus' + (FF.run.intent ? ' su «' + esc(String(FF.run.intent).slice(0, 40)) + '»' : ''); else if (typeof sevState !== 'undefined' && sevState && sevState.level > 0) att = 'Modalità severa accesa'; }catch(_){ }
  box.innerHTML = '<span class="acc-dot"></span><div><b>Online</b><small>' + att + '</small></div>';
}
function accPanPaint(){
  const box = document.getElementById('accPan'); if (!box) return;
  let app = 0, sev = 0, ff = 0, liv = 1, nome = '';
  try{ app = hdSerie(); }catch(_){ }
  try{ sev = sevStreakDays(typeof sevState !== 'undefined' ? sevState : null) || 0; }catch(_){ }
  try{ ff = serStreak() || 0; }catch(_){ }
  try{ liv = (typeof LV !== 'undefined' && LV.level) || 1; nome = (typeof LV_LEVELS !== 'undefined' && LV_LEVELS[liv - 1] && LV_LEVELS[liv - 1].name) || ''; }catch(_){ }
  const g = function(ico, v, t){ return '<div class="acc-pan-c"><span>' + ico + '</span><div><b>' + v + '</b><small>' + t + '</small></div></div>'; };
  box.innerHTML = g('🔥', app + (app === 1 ? ' giorno' : ' giorni'), 'Serie nell’app') + g('🔒', sev + (sev === 1 ? ' giorno' : ' giorni'), 'Modalità severa') + g('⏱️', ff + (ff === 1 ? ' giorno' : ' giorni'), 'Full Focus') + g('⭐', 'Livello ' + liv, nome || 'Il tuo livello');
}
/* ---- la card polaroid con il QR code, come su Duolingo (0.9.210) ----
   La card bianca STA SOPRA, da sola; sotto, un foglio scuro con la X in alto a sinistra, la
   riga delle app (Instagram, Facebook, WhatsApp, Messaggi... con le loro icone vere, solo
   quelle installate) e sotto Salva e Altro. Toccando un'app parte l'immagine con il testo. */
function accQrApri(){
  FLC.canvas = null; FLC.testo = null;
  let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ }
  const nome = (u && u.name) ? String(u.name) : 'Ospite';
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  if (!code){ toast('Il codice arriva con il nome del profilo: dai un nome e riprova fra un attimo'); if (typeof frSync === 'function') frSync(true); return; }
  const link = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + '?invito=' + encodeURIComponent(code);
  const pic = (typeof flImgGet === 'function') ? flImgGet(UF_AVATAR_KEY) : '';
  const qr = (typeof qrSvg === 'function') ? qrSvg(link, 96) : '';
  try{ if (typeof inSheetChiudi === 'function') inSheetChiudi(); }catch(_){ }
  let w = document.getElementById('accQrW');
  if (!w){ w = document.createElement('div'); w.id = 'accQrW'; w.className = 'qrw'; w.addEventListener('click', function(e){ if (e.target === w) accQrChiudi(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="qrw-card"><div class="acc-pola" id="accPola"><div class="acc-pola-img' + (pic ? ' has-pic' : '') + '" style="' + (pic ? 'background-image:url(' + pic + ')' : '') + '">' + (pic ? '' : '<span>' + esc(nome.charAt(0).toUpperCase()) + '</span>') + '</div>'
    + '<div class="acc-pola-piede"><div><b>' + esc(nome) + '</b><small>' + esc(code) + '</small><em>DreamMap</em></div><div class="acc-pola-qr">' + qr + '<img class="acc-qr-logo" src="icons/icon-192.png" alt=""></div></div></div></div>'
    + '<div class="qrw-sheet"><button type="button" class="qrw-x" aria-label="Chiudi" onclick="accQrChiudi()">✕</button>'
    + '<div class="qrw-app" id="qrwApp"></div>'
    + '<div class="qrw-app qrw-due"><button type="button" onclick="accQrSalva()"><span class="qrw-tondo"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="M7 10l5 5 5-5"/><path d="M5 20h14"/></svg></span><small>Salva</small></button>'
    + '<button type="button" onclick="accQrCondividi()"><span class="qrw-tondo">⋯</span><small>Altro</small></button></div></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  accQrApp();
}
function accQrChiudi(){ const w = document.getElementById('accQrW'); if (w) w.remove(); FLC.canvas = null; FLC.testo = null; FLC.titolo = ''; }
/* LA STESSA CONDIVISIONE PER OGNI IMMAGINE (0.9.213): la card sopra, il foglio scuro con le app
   sotto. La usa la serie («Condividi la serie», come «Condividi slancio» di Duolingo). */
const FLC = { canvas: null, testo: null, titolo: '' };
async function flCondividiApri(canvasFn, testo, titolo){
  FLC.canvas = canvasFn; FLC.testo = testo; FLC.titolo = titolo || 'Condividi';
  let cv = null; try{ cv = await canvasFn(); }catch(_){ }
  if (!cv){ toast('Non riesco a preparare l’immagine'); return; }
  let w = document.getElementById('accQrW');
  if (!w){ w = document.createElement('div'); w.id = 'accQrW'; w.className = 'qrw'; w.addEventListener('click', function(e){ if (e.target === w) accQrChiudi(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="qrw-testa"><button type="button" class="qrw-x2" aria-label="Chiudi" onclick="accQrChiudi()">✕</button><b>' + esc(FLC.titolo) + '</b></div>'
    + '<div class="qrw-card"><img class="qrw-img" src="' + cv.toDataURL('image/png') + '" alt=""></div>'
    + '<div class="qrw-sheet sola"><div class="qrw-app qrw-due"><button type="button" onclick="accQrSalva()"><span class="qrw-tondo"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="M7 10l5 5 5-5"/><path d="M5 20h14"/></svg></span><small>Salva</small></button><span id="qrwApp" class="qrw-app-in"></span>'
    + '<button type="button" onclick="accQrCondividi()"><span class="qrw-tondo">⋯</span><small>Altro</small></button></div></div>';
  w.classList.add('pieno');
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  accQrApp();
}
async function accQrApp(){
  const h = document.getElementById('qrwApp'); if (!h) return;
  let app = [];
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareTargets){ const r = await NATIVE.shareTargets(); app = (r && r.app) || []; } }catch(_){ app = []; }
  if (!app.length){ h.remove(); return; }
  h.innerHTML = app.map(function(a){ return '<button type="button" onclick="accQrA(' + esc(JSON.stringify(a.pkg)) + ')"><span class="qrw-ico" style="background-image:url(' + a.icona + ')"></span><small>' + esc(a.nome) + '</small></button>'; }).join('');
}
async function accQrA(pkg){
  const txt = FLC.testo != null ? FLC.testo : ((typeof frInvitoTesto === 'function') ? frInvitoTesto('') : '');
  try{
    const cv = await (FLC.canvas || accQrCanvas)();
    await NATIVE.shareImage({ base64: cv.toDataURL('image/png'), text: txt, title: 'Il mio profilo DreamMap', pkg: pkg });
  }catch(e){ toast('Quell’app non riceve l’immagine: usa Altro'); }
}
/** La polaroid dipinta su un canvas: serve per condividerla come immagine. */
async function accQrCanvas(){
  let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ }
  const nome = (u && u.name) ? String(u.name) : 'Ospite';
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const link = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + '?invito=' + encodeURIComponent(code);
  const pic = (typeof flImgGet === 'function') ? flImgGet(UF_AVATAR_KEY) : '';
  const W = 900, H = 1200, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
  x.fillStyle = '#0B2A4A'; x.fillRect(40, 40, W - 80, 820);
  /* 0.9.343: la foto si allinea in alto (il viso sta li'), non al centro */
  if (pic){ try{ const im = await new Promise(function(ok, ko){ const i = new Image(); i.onload = function(){ ok(i); }; i.onerror = ko; i.src = pic; }); const s = Math.max((W - 80) / im.width, 820 / im.height); const w = im.width * s, h = im.height * s; x.save(); x.beginPath(); x.rect(40, 40, W - 80, 820); x.clip(); x.drawImage(im, 40 + ((W - 80) - w) / 2, 40 + (820 - h) * 0.25, w, h); x.restore(); }catch(_){ } }
  else { x.fillStyle = '#4FB8FF'; x.font = '800 300px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(nome.charAt(0).toUpperCase(), W / 2, 450); }
  x.textAlign = 'left'; x.textBaseline = 'alphabetic';
  x.fillStyle = '#001E44'; x.font = '800 64px sans-serif'; x.fillText(nome.slice(0, 16), 60, 960);
  x.fillStyle = '#6B7A90'; x.font = '600 36px sans-serif'; x.fillText(code, 60, 1015);
  x.fillStyle = '#0075E3'; x.font = '800 52px sans-serif'; x.fillText('DreamMap', 60, 1110);
  try{ const g = qrMatrice(link); if (g){ const n = g.length, size = 280, cell = size / n, ox = W - 60 - size, oy = 900; x.fillStyle = '#fff'; x.fillRect(ox - 10, oy - 10, size + 20, size + 20); x.fillStyle = '#001E44'; for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c]) x.fillRect(ox + c * cell, oy + r * cell, Math.ceil(cell), Math.ceil(cell));
    /* 0.9.343, Andrea: "come Duolingo, sul QR l'icona dell'app". La correzione M regge un logo di un quinto del lato */
    try{ const lg = await new Promise(function(ok, ko){ const i = new Image(); i.onload = function(){ ok(i); }; i.onerror = ko; i.src = 'icons/icon-192.png'; }); const L = Math.round(size * 0.2), lx = ox + (size - L) / 2, ly = oy + (size - L) / 2; x.fillStyle = '#fff'; x.beginPath(); if (x.roundRect) x.roundRect(lx - 6, ly - 6, L + 12, L + 12, 12); else x.rect(lx - 6, ly - 6, L + 12, L + 12); x.fill(); x.save(); x.beginPath(); if (x.roundRect) x.roundRect(lx, ly, L, L, 10); else x.rect(lx, ly, L, L); x.clip(); x.drawImage(lg, lx, ly, L, L); x.restore(); }catch(_){ }
  } }catch(_){ }
  return cv;
}
async function accQrCondividi(){
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const txt = FLC.testo != null ? FLC.testo : ((typeof frInvitoTesto === 'function') ? frInvitoTesto('') : 'Seguimi su DreamMap: il mio codice è ' + code + '.');
  const accQrCanvas = FLC.canvas || window.accQrCanvas;
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareImage){ const cv0 = await accQrCanvas(); await NATIVE.shareImage({ base64: cv0.toDataURL('image/png'), text: txt, title: 'Il mio profilo DreamMap' }); return; } }catch(_){ }
  try{
    const cv = await accQrCanvas();
    const blob = await new Promise(function(ok){ cv.toBlob(ok, 'image/png'); });
    if (blob && navigator.share && navigator.canShare){ const f = new File([blob], 'dreammap-' + code + '.png', { type: 'image/png' }); if (navigator.canShare({ files: [f] })){ await navigator.share({ files: [f], text: txt }); return; } }
  }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: 'Il mio profilo DreamMap' }); return; }catch(_){ } }
  try{ await navigator.clipboard.writeText(txt); toast('Copiato'); }catch(_){ }
}
async function accQrSalva(){
  try{
    const cv = await (FLC.canvas || accQrCanvas)();
    const url = cv.toDataURL('image/png');
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.saveImage){ try{ await NATIVE.saveImage({ dataUrl: url, name: 'dreammap-profilo-' + Date.now() + '.png' }); toast('Salvata nella galleria, in Immagini › DreamMap'); return; }catch(_){ toast('La galleria non risponde: usa Altro'); return; } }
    const a = document.createElement('a'); a.href = url; a.download = 'dreammap-profilo.png'; document.body.appendChild(a); a.click(); a.remove();
  }catch(_){ toast('Non riesco a salvarla: usa Condividi'); }
}

/* ---- le schede del profilo: Timeline, About, Media, Story ---------------------------- */
/* 0.9.322, Andrea: "about e story in italiano non vanno" */
const ACC_TABS = [['about', 'Info'], ['story', 'Storia'], ['media', 'Media'], ['timeline', 'Timeline']];
let ACC_TAB = 'about';
function accTab(k){ ACC_TAB = k; accTabsPaint(); }
function accTabsPaint(){
  const tabs = document.getElementById('accTabs'), body = document.getElementById('accTabBody');
  if (!tabs || !body) return;
  tabs.innerHTML = ACC_TABS.map(function(t){ return '<button type="button" class="' + (ACC_TAB === t[0] ? 'on' : '') + '" onclick="accTab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('');
  if (typeof dvEventi !== 'function'){ body.innerHTML = ''; return; }
  if (ACC_TAB === 'timeline'){
    body.innerHTML = '<div id="mmBodyAcc" class="acc-memento"></div>';
    try{ if (typeof mmPaint === 'function') mmPaint('mmBodyAcc'); }catch(_){ }
  }
  else if (ACC_TAB === 'about'){ body.innerHTML = accAboutHtml(); try{ accPanCarPaint(); }catch(_){ } }
  else if (ACC_TAB === 'media') body.innerHTML = accMediaHtml();
  else body.innerHTML = accStoryHtml();
}
function accTimelineHtml(){
  const ev = dvEventi();
  if (!ev.length) return '<div class="acc-vuoto"><span>🗓️</span><b>Nessun evento ancora</b><p>La prima pagina la scrive la lettura del Genio.</p></div>';
  let h = '<div class="acc-tl">', anno = 0;
  ev.slice(0, 40).forEach(function(p){
    const d = new Date(p.t);
    if (d.getFullYear() !== anno){ anno = d.getFullYear(); h += '<div class="acc-tl-anno"><i></i><b>' + anno + '</b><i></i></div>'; }
    h += '<div class="acc-tl-ev"><small class="acc-tl-cat">' + esc(p.ico) + ' ' + esc(p.cat) + '</small>'
      + '<small class="acc-tl-data">' + esc(d.getDate() + ' ' + DV_MESI[d.getMonth()] + ' ' + d.getFullYear()) + '</small>'
      + '<b>' + esc(p.titolo) + '</b>' + (p.testo && p.tipo !== 'lettera' ? '<p>' + esc(String(p.testo).slice(0, 140)) + '</p>' : '') + '</div>';
  });
  return h + '</div>';
}
function accAboutHtml(pub){
  /* ABOUT (0.9.205): prima lo stato, poi la panoramica (un numero per slide), le conquiste, chi sono */
  const sogno = (function(){ try{ return accSognoPub() && typeof nvSogno === 'function' ? nvSogno() : ''; }catch(_){ return ''; } })();
  /* lo stato online lo vedono gli altri (0.9.209): nel tuo About non serve, nel profilo pubblico si' */
  let h = (pub ? '<div class="acc-ab-sez">' + accOnlineHtml() + '</div>' : '')
    + '<div class="acc-ab-sez"><div class="sect acc-sect"><b>Panoramica</b></div><div class="acc-pan-car"></div></div>'
    + '<div class="acc-ab-sez"><div class="sect acc-sect"><b>Conquiste</b><span class="acc-presto">in arrivo</span></div><div class="acc-conq"><span>🏅</span><span>🏆</span><span>💎</span><span>🎖️</span></div></div>';
  if (pub){ return h + (sogno ? '<div class="acc-ab-sez"><div class="sect acc-sect"><b>Il sogno</b></div><div class="acc-ab"><b>' + esc(sogno) + '</b></div></div>' : ''); }
  const d = (typeof agDati === 'function') ? agDati() : {};
  const id = (typeof ifIdentita === 'function') ? ifIdentita() : {};
  let bio = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); bio = (u && u.bio) || ''; }catch(_){ }
  /* 0.9.322, Andrea: il foglietto per primo, prima di Panoramica e Conquiste: cosi' non ha bisogno di un titolo di sezione */
  return accChiHtml(d, id, bio) + h;
}
/* CHI SONO (0.9.319). Andrea: "sembra un documento, e' bruttissimo: mettilo su una pagina del diario, e che l'utente scelga cosa mostrare".
   Una pagina di carta a righe, scritta a mano come il diario: in alto il nastro, in fondo il timbro dell'arrivo e la firma. Dai tre puntini si
   sceglie quali voci stanno sulla pagina. */
const ACC_CHI_K = 'fl_acc_chi_no';
/* 0.9.322, Andrea: "i toggle non bastano: voglio scrivere io il testo, il titolo, il colore, un'emoji, un'immagine, aggiungere le mie voci".
   Il foglietto di serie resta quello che arriva dall'app; quello che cambi vive qui, solo per questa pagina (il sogno vero non si tocca). */
const ACC_PAG_K = 'fl_acc_chi_pag';
const ACC_COLORI = ['#C22D3A', '#0059B3', '#0075E3', '#14284D'];
const ACC_FRECCIA = '<svg class="chi-fr" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h15"/><path d="M13 6l6 6-6 6"/></svg>';
function accChiNo(){ try{ return JSON.parse(localStorage.getItem(ACC_CHI_K) || '[]') || []; }catch(_){ return []; } }
function accPag(){ try{ const o = JSON.parse(localStorage.getItem(ACC_PAG_K) || 'null'); return (o && typeof o === 'object') ? { titolo: o.titolo || '', voci: o.voci || {}, extra: o.extra || [] } : { titolo: '', voci: {}, extra: [] }; }catch(_){ return { titolo: '', voci: {}, extra: [] }; } }
function accPagSalva(p){ try{ localStorage.setItem(ACC_PAG_K, JSON.stringify(p)); }catch(_){ try{ toast('Il telefono è pieno: non riesco a salvarlo'); }catch(_e){ } } }
/* l'emoji del sogno, la stessa dell'inizio */
function accSognoEmoji(){
  try{
    const t = (typeof gnDati === 'function' && gnDati().target) || (typeof orTargetDaSogno === 'function' ? orTargetDaSogno(nvSogno()) : '');
    const v = (typeof OR_TARGETS !== 'undefined' ? OR_TARGETS : []).filter(function(x){ return x.id === t; })[0];
    return v ? v.ico : '✨';
  }catch(_){ return '✨'; }
}
function accChiVoci(d, id, bio){
  const p = accPag();
  const base = [
    { k: 'sogno', t: 'Il mio sogno', v: d.sogno, gr: 1, ed: 1, emo: accSognoEmoji() }, { k: 'dest', t: 'Dove voglio arrivare', v: d.a ? (d.da ? d.da + ' → ' : '') + d.a : '', fr: d.da && d.a ? [d.da, d.a] : null },
    { k: 'quando', t: 'Entro quando', v: d.quando }, { k: 'oggi', t: 'Chi sono oggi', v: d.profilo, ed: 1 },
    { k: 'saro', t: 'Chi sarò', v: id.chiSaro, ed: 1 }, { k: 'perche', t: 'Perché lo faccio', v: id.perche, ed: 1 },
    { k: 'promessa', t: 'Il mantra dell’inizio', v: bio, ed: 1 }, { k: 'arrivo', t: 'Arrivo stimato', v: d.arrivo, timbro: 1 }
  ];
  const tutte = base.map(function(x){ const m = p.voci[x.k] || {}; return Object.assign({}, x, { t: m.t || x.t, v: (x.ed && m.v) ? m.v : x.v, col: m.col || '', emo: m.emo != null ? m.emo : (x.emo || ''), img: m.img || '', mio: !!(x.ed && m.v) }); });
  const prima = tutte.filter(function(x){ return !x.timbro; }), timbro = tutte.filter(function(x){ return x.timbro; });
  return prima.concat((p.extra || []).map(function(x){ return Object.assign({ ed: 1, extra: 1 }, x); })).concat(timbro).filter(function(x){ return x.v || x.extra; });
}
function accChiValore(x){ return x.fr && !x.mio ? esc(x.fr[0]) + ACC_FRECCIA + esc(x.fr[1]) : esc(x.v); }
function accChiFirma(){ let n = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); n = (u && (u.name || u.nome)) || ''; }catch(_){ } try{ if (!n && typeof gnNome === 'function') n = gnNome(); }catch(_){ } return n; }
function accChiHtml(d, id, bio){
  const no = accChiNo(), tutte = accChiVoci(d, id, bio);
  const voci = tutte.filter(function(x){ return no.indexOf(x.k) < 0; });
  if (!tutte.length) return '<div class="acc-ab-sez"><div class="acc-vuoto"><span>🧞</span><b>Ancora niente da raccontare</b><p>Fai la lettura del Genio: da lì nasce questa pagina.</p></div><button type="button" class="acc-edit" onclick="profiloModificaApri()">Modifica profilo</button></div>';
  const righe = voci.filter(function(x){ return !x.timbro; }), timbro = voci.filter(function(x){ return x.timbro; })[0], firma = accChiFirma();
  return '<div class="acc-ab-sez chi-sez"><article class="chi-pag"><i class="chi-nastro" aria-hidden="true"></i>'
    + '<button type="button" class="chi-menu" onclick="accChiMenu()" aria-label="Modifica la tua pagina"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg></button>'
    + '<h3>' + esc(accPag().titolo || 'Chi sono') + '</h3>'
    + righe.map(function(x, i){ return '<section class="chi-v' + (x.gr ? ' grande' : '') + '" style="--i:' + i + '"><small' + (x.col ? ' style="color:' + esc(x.col) + '"' : '') + '>' + esc(x.t) + '</small>' + (x.img ? '<img class="chi-img" src="' + x.img + '" alt="">' : '') + '<p>' + (x.emo ? esc(x.emo) + ' ' : '') + accChiValore(x) + '</p></section>'; }).join('')
    + (voci.length ? '' : '<p class="chi-vuota">Dai tre puntini scegli cosa scrivere su questa pagina.</p>')
    + (timbro || firma ? '<footer class="chi-piede">' + (timbro ? '<span class="chi-timbro"><small>' + esc(timbro.t) + '</small><b>' + esc(timbro.v) + '</b></span>' : '') + (firma ? '<span class="chi-firma">' + esc(firma) + '</span>' : '') + '</footer>' : '')
    + '</article><button type="button" class="acc-edit" onclick="profiloModificaApri()">Modifica profilo</button></div>';
}
function accChiDati(){
  const d = (typeof agDati === 'function') ? agDati() : {}, id = (typeof ifIdentita === 'function') ? ifIdentita() : {};
  let bio = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); bio = (u && u.bio) || ''; }catch(_){ }
  return accChiVoci(d, id, bio);
}
const ACC_MATITA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.5 5.500l4 4L9 19H5v-4z"/></svg>';
function accChiMenu(){
  const no = accChiNo(), p = accPag(), cambiata = p.titolo || Object.keys(p.voci).length || p.extra.length;
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  inSheet('<div class="en-foglio chi-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>La tua pagina</h3>'
    + '<label class="chi-campo"><span>Il titolo della pagina</span><input type="text" id="chiTitolo" maxlength="30" placeholder="Chi sono" value="' + esc(p.titolo) + '" onchange="accChiTitolo(this.value)"></label>'
    + accChiDati().map(function(x){ const on = no.indexOf(x.k) < 0; const fissa = !!x.timbro;
        return '<div class="chi-f-r"><button type="button" class="chi-f-t"' + (fissa ? ' disabled' : ' onclick="accChiEdita(\'' + x.k + '\')"') + '><b' + (x.col ? ' style="color:' + esc(x.col) + '"' : '') + '>' + esc(x.t) + '</b><small>' + (x.emo ? esc(x.emo) + ' ' : '') + accChiValore(x) + '</small></button>'
          + (fissa ? '' : '<button type="button" class="chi-f-m" onclick="accChiEdita(\'' + x.k + '\')" aria-label="Modifica ' + esc(x.t) + '">' + ACC_MATITA + '</button>')
          + '<button type="button" class="switch' + (on ? ' on' : '') + '" aria-label="' + esc(x.t) + '" onclick="accChiSet(\'' + x.k + '\')"></button></div>'; }).join('')
    + '<button type="button" class="en-cta chi-piu" onclick="accChiEdita(\'\')">Aggiungi una voce</button>'
    + (cambiata ? '<button type="button" class="en-no" onclick="accChiDiSerie()">Rimetti la pagina di serie</button>' : '')
    + '</div>');
}
function accChiTitolo(v){ const p = accPag(); p.titolo = String(v || '').trim().slice(0, 30); accPagSalva(p); try{ accTabsPaint(); }catch(_){ } }
function accChiDiSerie(){ try{ localStorage.removeItem(ACC_PAG_K); }catch(_){ } accChiMenu(); try{ accTabsPaint(); }catch(_){ } }
function accChiSet(k){
  const no = accChiNo(), i = no.indexOf(k);
  if (i >= 0) no.splice(i, 1); else no.push(k);
  try{ localStorage.setItem(ACC_CHI_K, JSON.stringify(no)); }catch(_){ }
  accChiMenu();
  try{ accTabsPaint(); }catch(_){ }
}
/* una voce alla volta: titolo, testo (dove si puo' scrivere), emoji, colore del titolo, immagine */
const ACC_ED = { k: '', col: '', img: '' };
function accChiEdita(k){
  const x = k ? accChiDati().filter(function(v){ return v.k === k; })[0] : { k: '', t: '', v: '', ed: 1, extra: 1, emo: '', col: '', img: '' };
  if (!x) return;
  ACC_ED.k = k; ACC_ED.col = x.col || ''; ACC_ED.img = x.img || '';
  inSheet('<div class="en-foglio chi-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="accChiMenu()">✕</button><h3>' + (k ? 'Modifica la voce' : 'Una voce nuova') + '</h3>'
    + '<label class="chi-campo"><span>Il titolo</span><input type="text" id="chiEdT" maxlength="30" value="' + esc(x.t) + '" placeholder="Per esempio: Cosa mi muove"></label>'
    + (x.ed ? '<label class="chi-campo"><span>Il testo</span><textarea id="chiEdV" rows="3" maxlength="200" placeholder="Scrivilo con parole tue">' + esc(x.v) + '</textarea></label>' : '<p class="chi-fisso">Il testo lo scrive l’app: ' + accChiValore(x) + '</p>')
    + '<label class="chi-campo"><span>L’emoji</span><input type="text" id="chiEdE" maxlength="4" value="' + esc(x.emo) + '" placeholder="🚀"></label>'
    + '<div class="chi-campo"><span>Il colore del titolo</span><div class="chi-col">' + ACC_COLORI.map(function(c){ return '<button type="button" class="' + ((x.col || ACC_COLORI[0]) === c ? 'on' : '') + '" style="background:' + c + '" onclick="accChiColore(this,\'' + c + '\')" aria-label="Colore"></button>'; }).join('') + '</div></div>'
    + '<div class="chi-campo"><span>L’immagine</span><button type="button" class="en-no chi-imgb" onclick="accChiImmagine()" id="chiEdI">' + (x.img ? 'Cambia l’immagine' : 'Scegli un’immagine') + '</button></div>'
    + '<button type="button" class="en-cta" onclick="accChiSalvaVoce()">Salva</button>'
    + (x.extra && k ? '<button type="button" class="en-no" onclick="accChiViaVoce()">Elimina la voce</button>' : '')
    + '</div>');
}
function accChiColore(b, c){ ACC_ED.col = c; b.parentNode.querySelectorAll('button').forEach(function(x){ x.classList.toggle('on', x === b); }); }
function accChiImmagine(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){
    const f = inp.files && inp.files[0]; inp.remove(); if (!f) return;
    const url = URL.createObjectURL(f), img = new Image();
    img.onload = function(){
      try{ const r = Math.min(1, 420 / img.width), cv = document.createElement('canvas'); cv.width = Math.round(img.width * r); cv.height = Math.round(img.height * r); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); ACC_ED.img = cv.toDataURL('image/jpeg', .72); const b = document.getElementById('chiEdI'); if (b) b.textContent = 'Immagine scelta: tocca Salva'; }catch(_){ }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });
  document.body.appendChild(inp); inp.click();
}
function accChiSalvaVoce(){
  const p = accPag(), g = function(i){ const e = document.getElementById(i); return e ? e.value.trim() : ''; };
  const t = g('chiEdT'), v = g('chiEdV'), emo = g('chiEdE'), k = ACC_ED.k;
  if (k && !/^x\d/.test(k)){
    p.voci[k] = { t: t, v: v, emo: emo, col: ACC_ED.col, img: ACC_ED.img };
  } else {
    if (!t && !v){ accChiMenu(); return; }
    const nuova = { k: k || 'x' + Date.now(), t: t || 'Una voce', v: v, emo: emo, col: ACC_ED.col, img: ACC_ED.img };
    const i = p.extra.map(function(x){ return x.k; }).indexOf(nuova.k);
    if (i >= 0) p.extra[i] = nuova; else p.extra.push(nuova);
  }
  accPagSalva(p); accChiMenu();
  try{ accTabsPaint(); }catch(_){ }
}
function accChiViaVoce(){ const p = accPag(); p.extra = p.extra.filter(function(x){ return x.k !== ACC_ED.k; }); accPagSalva(p); accChiMenu(); try{ accTabsPaint(); }catch(_){ } }
/* LA SCHEDA MEDIA (0.9.319). Andrea: "come su Instagram: una scheda con un pulsante piu' per creare un post". Il primo riquadro e' il piu'; i
   post stanno in questa griglia, il file nel telefono (IndexedDB fl_vita, lo stesso delle pagine delle settimane) e l'elenco in fl_post. Chi sceglie
   "Fallo vedere agli amici" lo manda sul server come pagina dalla settimana 5000 in su: arriva dalla tua Timeline se le settimane sono pubbliche. */
const AP_K = 'fl_post';
const AP = { file: null, url: '', tipo: '' };
function apLista(){ try{ return JSON.parse(localStorage.getItem(AP_K) || '[]') || []; }catch(_){ return []; } }
function apSalva(l){ try{ localStorage.setItem(AP_K, JSON.stringify(l)); }catch(_){ try{ toast('Il telefono è pieno: il post non è stato salvato'); }catch(_e){ } } }
function accMediaHtml(){
  const f = (typeof dvFoto === 'function') ? dvFoto() : [], post = apLista();
  const src = function(u){ try{ return (u && window.Capacitor && Capacitor.convertFileSrc && !/^(data:|https?:)/.test(u)) ? Capacitor.convertFileSrc(u) : u; }catch(_){ return u; } };
  setTimeout(apMiniature, 0);
  return '<div class="acc-post-griglia"><button type="button" class="acc-post piu" onclick="apNuovo()" aria-label="Crea un post"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><small>Nuovo post</small></button>'
    + post.map(function(x){ return '<button type="button" class="acc-post" data-ap="' + esc(x.id) + '" onclick="apVedi(\'' + esc(x.id) + '\')"></button>'; }).join('')
    + f.map(function(x){ return '<figure class="acc-post"><img src="' + esc(src(x.src)) + '" alt=""></figure>'; }).join('')
    + '</div>' + (post.length || f.length ? '' : '<p class="acc-post-nota">Le foto e i video che pubblichi, e le prove delle cose fatte, finiscono qui.</p>');
}
async function apMiniature(){
  const hs = document.querySelectorAll('.acc-post[data-ap]');
  for (const h of hs){
    if (h.firstChild) continue;
    const p = apLista().filter(function(x){ return x.id === h.getAttribute('data-ap'); })[0]; if (!p) continue;
    const m = await vsMediaLeggi(p.media); if (!m || !m.blob) continue;
    const u = URL.createObjectURL(m.blob);
    h.innerHTML = m.tipo === 'video' ? '<video src="' + u + '" muted playsinline preload="metadata"></video><i class="acc-post-v" aria-hidden="true"></i>' : '<img src="' + u + '" alt="">';
  }
}
function apNuovo(){
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*,video/*'; inp.style.display = 'none';
  inp.addEventListener('change', function(){ const f = inp.files && inp.files[0]; inp.remove(); if (f) apComponi(f); });
  document.body.appendChild(inp); inp.click();
}
function apComponi(f){
  AP.file = f; AP.tipo = /^video/.test(f.type) ? 'video' : 'foto';
  if (AP.url) URL.revokeObjectURL(AP.url);
  AP.url = URL.createObjectURL(f);
  inSheet('<div class="en-foglio ap-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Nuovo post</h3>'
    + '<div class="ap-prev">' + (AP.tipo === 'video' ? '<video src="' + AP.url + '" controls playsinline></video>' : '<img src="' + AP.url + '" alt="">') + '</div>'
    + '<textarea class="fin ap-testo" id="apTesto" rows="3" maxlength="2000" placeholder="Scrivi una didascalia"></textarea>'
    + '<div class="chi-f-r"><div><b>Fallo vedere agli amici</b><small>Lo aprono dalla tua Timeline, se le tue settimane sono pubbliche</small></div><button type="button" class="switch" id="apPub" aria-label="Fallo vedere agli amici" onclick="this.classList.toggle(\'on\')"></button></div>'
    + '<button type="button" class="en-cta" onclick="apPubblica()">Pubblica</button></div>');
}
function apRiduci(f){
  return new Promise(function(ok){
    if (!/^image\//.test(f.type) || /gif$/.test(f.type)){ ok(f); return; }
    const u = URL.createObjectURL(f), img = new Image();
    img.onload = function(){
      URL.revokeObjectURL(u);
      const k = Math.min(1, 1600 / Math.max(img.width, img.height));
      if (k >= 1 && f.size < 2500000){ ok(f); return; }
      const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      cv.toBlob(function(b){ ok(b || f); }, 'image/jpeg', .86);
    };
    img.onerror = function(){ URL.revokeObjectURL(u); ok(f); };
    img.src = u;
  });
}
async function apPubblica(){
  if (!AP.file) return;
  const t = document.getElementById('apTesto'), sw = document.getElementById('apPub');
  const testo = String(t ? t.value : '').trim(), pub = !!(sw && sw.classList.contains('on'));
  const blob = await apRiduci(AP.file);
  const id = vsNuovoId();
  try{ await vsMediaScrivi({ id: id, tipo: AP.tipo, mime: blob.type || AP.file.type || '', blob: blob, su: false }); }
  catch(_){ try{ toast('Il telefono è pieno: il post non è stato salvato'); }catch(_e){ } return; }
  const l = apLista(), slot = AP_SLOT + (l.reduce(function(m, x){ return Math.max(m, (x.slot || AP_SLOT) - AP_SLOT + 1); }, 0) % 900);
  const p = { id: 'p' + id, media: id, testo: testo, at: Date.now(), pub: pub, su: false, slot: slot };
  l.unshift(p); apSalva(l);
  AP.file = null;
  inSheetChiudi();
  try{ toast('Post pubblicato'); if (typeof flVibra === 'function') flVibra([10, 30, 10]); }catch(_){ }
  try{ accTabsPaint(); }catch(_){ }
  if (pub) apManda(p);
}
async function apManda(p){
  try{
    if (typeof frDevice !== 'function') return;
    const dev = frDevice(); if (!dev) return;
    const m = await vsMediaLeggi(p.media); if (!m) return;
    if (!(await vsCarica(m, dev, p.slot))) return;
    await frApi('POST', '/api/focuslock/vita/pagina', { device: dev, settimana: p.slot, inizio: '', testo: p.testo || '', media: [p.media] });
    const l = apLista(), x = l.filter(function(y){ return y.id === p.id; })[0]; if (x){ x.su = true; apSalva(l); }
  }catch(_){ }
}
async function apVedi(id){
  const p = apLista().filter(function(x){ return x.id === id; })[0]; if (!p) return;
  const m = await vsMediaLeggi(p.media); if (!m || !m.blob) return;
  const u = URL.createObjectURL(m.blob), d = new Date(p.at);
  inSheet('<div class="en-foglio ap-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il tuo post</h3>'
    + '<div class="ap-prev">' + (m.tipo === 'video' ? '<video src="' + u + '" controls playsinline></video>' : '<img src="' + u + '" alt="">') + '</div>'
    + (p.testo ? '<p class="ap-cap">' + esc(p.testo) + '</p>' : '')
    + '<p class="ap-data">' + d.getDate() + ' ' + DV_MESI[d.getMonth()] + ' ' + d.getFullYear() + (p.pub ? ' · lo vedono gli amici' : ' · lo vedi solo tu') + '</p>'
    + '<button type="button" class="en-no" onclick="apTogli(\'' + id + '\')">Elimina il post</button></div>');
}
async function apTogli(id){
  const l = apLista(), p = l.filter(function(x){ return x.id === id; })[0]; if (!p) return;
  apSalva(l.filter(function(x){ return x.id !== id; }));
  inSheetChiudi();
  try{ await vsMediaTogli(p.media); }catch(_){ }
  try{ accTabsPaint(); }catch(_){ }
  try{ if (p.pub && typeof frDevice === 'function' && frDevice()) await frApi('POST', '/api/focuslock/vita/pagina', { device: frDevice(), settimana: p.slot, via: true }); }catch(_){ }
}
/* 0.9.322, Andrea: "gli interruttori dentro ai tre puntini; il film della tua vita e la Visualizzazione bloccati, in arrivo: devo ancora finirli" */
const ACC_FILM_K = 'fl_film_pubblico';
function accFilmPanel(){ return '<div class="acc-story acc-film acc-bloccata" aria-disabled="true" onclick="flInArrivo()"><span class="acc-story-cov film">🎬</span><div><b>Il film della tua vita</b><small>Nightmare e ✨ Dreamlife</small></div><i class="pt-arrivo">In arrivo</i></div>'; }
function accStoryHtml(pubblico){
  const n = Math.max(0, (typeof dvPagine === 'function' ? dvPagine().length : 2) - 2);
  const pub = (typeof dvPubblico === 'function') && dvPubblico();
  if (pubblico) return '<div class="acc-ab-sez">' + (pub ? '<button type="button" class="acc-story" onclick="dvApri()"><span class="acc-story-cov">📔</span><div><b>Il diario di viaggio</b><small>' + n + (n === 1 ? ' pagina' : ' pagine') + ' · tocca per sfogliarlo</small></div><span class="chev"></span></button>' : '<div class="acc-vuoto"><span>📔</span><b>Diario privato</b><p>Lo apri agli amici dai tre puntini della tua Storia.</p></div>') + '</div>'
    + '<div class="acc-ab-sez">' + accFilmPanel() + '</div>';
  return '<div class="acc-story-top"><button type="button" class="acc-tre" onclick="accStoryMenu()" aria-label="Cosa vedono gli amici"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg></button></div>'
    + '<button type="button" class="acc-story" onclick="dvApri()"><span class="acc-story-cov">📔</span><div><b>Il mio diario di viaggio</b><small>' + n + (n === 1 ? ' pagina scritta' : ' pagine scritte') + ' · tocca per sfogliarlo</small></div><span class="chev"></span></button>'
    + accFilmPanel();
}
function accStoryMenu(){
  const pub = (typeof dvPubblico === 'function') && dvPubblico();
  let film = false; try{ film = localStorage.getItem(ACC_FILM_K) === '1'; }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  inSheet('<div class="en-foglio chi-f"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Cosa vedono gli amici</h3>'
    + '<div class="chi-f-r"><div><b>Diario pubblico</b><small>Possono sfogliarlo dal tuo profilo. Le foto restano sul telefono.</small></div><button type="button" class="switch' + (pub ? ' on' : '') + '" aria-label="Diario pubblico" onclick="dvPubblicoSet(' + (pub ? 'false' : 'true') + ');setTimeout(accStoryMenu,60)"></button></div>'
    /* 0.9.332, Andrea: "metti tutto insieme, senza quella lista della spesa": gli interruttori di tutto il profilo pubblico stanno qui */
    + '<div class="chi-f-r"><div><b>Sogno pubblico</b><small>Vedono quale sogno insegui e quelli realizzati.</small></div><button type="button" class="switch' + (accSognoPub() ? ' on' : '') + '" aria-label="Sogno pubblico" onclick="accSognoPubSet(!accSognoPub());accStoryMenu()"></button></div>'
    + '<div class="chi-f-r"><div><b>Tempo di schermo</b><small>Lo vedono i tuoi amici e chi è nella tua lega.</small></div><button type="button" class="switch' + ((function(){ try{ return localStorage.getItem('fl_privacy_extra') === '1'; }catch(_){ return false; } })() ? ' on' : '') + '" aria-label="Tempo di schermo" onclick="frPrivacyExtra()"></button></div>'
    + '<div class="chi-f-r"><div><b>Il film della tua vita pubblico</b><small>Lo vedranno quando il film sarà pronto.</small></div><button type="button" class="switch' + (film ? ' on' : '') + '" aria-label="Il film della tua vita pubblico" onclick="accFilmSet(' + (film ? 'false' : 'true') + ')"></button></div></div>');
}
function accFilmSet(on){ try{ localStorage.setItem(ACC_FILM_K, on ? '1' : '0'); }catch(_){ } accStoryMenu(); }
registerScreen('s-film',
  '<div class="topbar"><button class="iconbtn" onclick="cnPaginaIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Il film della tua vita</b></div>'
  + '<div id="cnBoxFilm" class="acc-cinema-pag"></div><div class="spacer"></div>', { back: 's-account' });
let CN_PAG_PUB = false;
function cnPaginaApri(pubblico){
  /* in arrivo: quando sara' pronto il pannello aprira' la stessa pagina della Visualizzazione (vzApri) */
  if (typeof flInArrivo === 'function'){ flInArrivo(); return; }
  CN_PAG_PUB = !!pubblico;
  goId('s-film');
  const h = document.getElementById('cnBoxFilm'); if (h){ h.classList.toggle('cn-pubblico', CN_PAG_PUB); }
  try{ cnPaint('cnBoxFilm'); }catch(_){ }
}
function cnPaginaIndietro(){ if (CN_PAG_PUB) goId('s-profilo-pubblico'); else profileAuth(); }
/* ---- IL PROFILO PUBBLICO (0.9.205): una pagina intera, con le stesse schede, come su Instagram ---- */
registerScreen('s-profilo-pubblico',
  '<div class="topbar"><button class="iconbtn" onclick="profileAuth()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Profilo pubblico</b></div>'
  + '<p class="acc-pub-eti">Così ti vedono gli amici</p>'
  + '<div class="acc-av"><div class="av" id="accAvPub">?</div></div><h2 class="acc-nome" id="accNomePub">Ospite</h2><p class="acc-pub-liv" id="accLivPub"></p>'
  + '<div class="acc-top3" id="accTop3Pub"></div>'
  + '<div class="acc-tabs" id="accTabsPub"></div><div id="accTabBodyPub" class="acc-tabbody"></div><div class="spacer"></div>', { back: 's-account' });
let ACC_TAB_PUB = 'about';
function accPubblicoApri(){
  goId('s-profilo-pubblico');
  let u = null; try{ u = JSON.parse(localStorage.getItem('fl_user') || 'null'); }catch(_){ }
  const nome = (u && u.name) ? String(u.name) : 'Ospite';
  const pic = (typeof flImgGet === 'function') ? flImgGet(UF_AVATAR_KEY) : '';
  const av = document.getElementById('accAvPub'); if (av){ av.textContent = pic ? '' : nome.charAt(0).toUpperCase(); av.classList.toggle('has-pic', !!pic); av.style.backgroundImage = pic ? 'url(' + pic + ')' : ''; }
  const nn = document.getElementById('accNomePub'); if (nn) nn.textContent = nome;
  let liv = 1; try{ liv = (typeof LV !== 'undefined' && LV.level) || 1; }catch(_){ }
  const lv = document.getElementById('accLivPub'); if (lv) lv.textContent = 'Livello ' + liv + ' · 🟢 online';
  let perc = 0; try{ perc = Math.round(hdPercorso().pct * 100); }catch(_){ }
  let seguiti = 0, follower = 0; try{ const A = FR.amici; seguiti = A.seguiti != null ? A.seguiti : (A.amici || []).length; follower = A.follower || 0; }catch(_){ }
  const t3 = document.getElementById('accTop3Pub'); if (t3) t3.innerHTML = '<div class="acc-forest">' + accStat('🧭 ' + perc + '%', 'Del percorso', 'Quanto del viaggio ha già fatto.') + '<i class="sep"></i>' + accStat(String(seguiti), 'Seguiti', 'Le persone che segue.') + '<i class="sep"></i>' + accStat(String(follower), 'Follower', 'Le persone che lo seguono.') + '</div>';
  accPubTabsPaint();
}
function accPubTab(k){ ACC_TAB_PUB = k; accPubTabsPaint(); }
function accPubTabsPaint(){
  const tabs = document.getElementById('accTabsPub'), body = document.getElementById('accTabBodyPub'); if (!tabs || !body) return;
  tabs.innerHTML = ACC_TABS.map(function(t){ return '<button type="button" class="' + (ACC_TAB_PUB === t[0] ? 'on' : '') + '" onclick="accPubTab(\'' + t[0] + '\')">' + t[1] + '</button>'; }).join('');
  if (ACC_TAB_PUB === 'about'){ body.innerHTML = accAboutHtml(true); try{ accPanCarPaint(); }catch(_){ } }
  else if (ACC_TAB_PUB === 'story') body.innerHTML = accStoryHtml(true);
  else if (ACC_TAB_PUB === 'media') body.innerHTML = '<div class="acc-vuoto"><span>📷</span><b>Gli amici vedono solo quello che scegli</b><p>I post con "Fallo vedere agli amici" e le pagine delle settimane pubbliche. Tutto il resto resta sul telefono.</p></div>';
  /* 0.9.286: la Timeline che vedono gli amici e' la tua vita in settimane, con le pagine pubbliche (vita-settimane.js) */
  else if (typeof vsAnteprimaHtml === 'function'){ body.innerHTML = vsAnteprimaHtml(); vsAnteprimaDisegna(); }
  else body.innerHTML = accTimelineHtml();
}
(function accTabsStyle(){
  const css = [
    '.acc-tabs{display:flex;border-bottom:1.5px solid var(--line);margin:18px 0 0}',
    '.acc-tabs button{flex:1;border:0;background:transparent;padding:12px 4px;font:700 14px var(--font-body);color:var(--muted);cursor:pointer;border-bottom:2.5px solid transparent;margin-bottom:-1.5px}',
    '.acc-tabs button.on{color:var(--blue,#0075E3);border-bottom-color:var(--blue,#0075E3)}',
    '.acc-tabbody{padding:16px 0 4px}',
    '.acc-vuoto{text-align:center;padding:24px 12px;color:var(--muted)}',
    '.acc-vuoto span{display:block;font-size:34px;margin-bottom:8px}',
    '.acc-vuoto b{display:block;font:800 16px var(--font-body);color:var(--navy);margin-bottom:4px}',
    'body.dark .acc-vuoto b{color:#fff}',
    '.acc-vuoto p{margin:0;font:500 13.5px/1.45 var(--font-body)}',
    '.acc-tl-anno{display:flex;align-items:center;gap:12px;margin:8px 0 12px}',
    '.acc-tl-anno i{flex:1;height:1.5px;background:var(--line)}',
    '.acc-tl-anno b{font:800 18px var(--font-body);color:#C99A2E}',
    '.acc-tl-ev{text-align:center;padding:10px 8px 16px}',
    '.acc-tl-cat{display:block;font:800 13px var(--font-body);color:var(--navy)}',
    'body.dark .acc-tl-cat{color:#fff}',
    '.acc-tl-data{display:block;margin:4px 0 6px;font:600 12.5px var(--font-body);color:var(--faint)}',
    '.acc-tl-ev b{display:block;font:800 15px/1.3 var(--font-body);color:var(--navy)}',
    'body.dark .acc-tl-ev b{color:#fff}',
    '.acc-tl-ev p{margin:4px 0 0;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.acc-ab{padding:10px 0;border-bottom:1px solid var(--line)}',
    '.acc-ab small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint);margin-bottom:3px}',
    '.acc-ab b{font:700 15px/1.4 var(--font-body);color:var(--navy)}',
    'body.dark .acc-ab b{color:#fff}',
    '.acc-post-griglia{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}',
    '.acc-post{position:relative;display:block;aspect-ratio:1;margin:0;padding:0;border:0;overflow:hidden;background:#E3F1FF;cursor:pointer}body.dark .acc-post{background:#14234A}.acc-post img,.acc-post video{display:block;width:100%;height:100%;object-fit:cover}',
    '.acc-post.piu{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;background:#0075E3;color:#fff}.acc-post.piu small{font:700 11.5px var(--font-body)}',
    '.acc-post-v{position:absolute;right:6px;top:6px;width:0;height:0;border-left:11px solid #fff;border-top:7px solid transparent;border-bottom:7px solid transparent;filter:drop-shadow(0 1px 2px rgba(0,0,0,.6))}',
    '.acc-post-nota{margin:16px 12px 0;font:500 14px/1.45 var(--font-body);color:var(--muted);text-align:center}',
    '.ap-prev{margin:0 0 14px;border-radius:16px;overflow:hidden;background:#001E44}.ap-prev img,.ap-prev video{display:block;width:100%;max-height:42vh;object-fit:contain}',
    '.ap-testo{display:block;width:100%;box-sizing:border-box;margin:0 0 6px;text-align:left}.ap-cap{margin:0 0 6px;font:500 15px/1.45 var(--font-body);color:var(--navy);white-space:pre-wrap}body.dark .ap-cap{color:#fff}.ap-data{margin:0 0 8px;font:600 12.5px var(--font-body);color:var(--muted)}.ap-f .chi-f-r{margin-bottom:14px;text-align:left}',
    /* la pagina di diario di Chi sono: carta, righe, nastro, timbro. Colori fissi, uguali nei due temi. */
    '.chi-sez{padding-top:6px}',
    '.chi-pag{position:relative;margin:6px 2px 16px;padding:34px 22px 20px;border-radius:6px;text-align:center;color:#14284D;background-color:#F4E9CF;background-image:repeating-linear-gradient(180deg,transparent 0,transparent 33px,rgba(0,75,160,.12) 33px,rgba(0,75,160,.12) 34px),radial-gradient(ellipse at 15% 8%,rgba(255,255,255,.55),transparent 55%),radial-gradient(ellipse at 90% 92%,rgba(140,90,30,.16),transparent 55%);box-shadow:0 1px 0 #fff inset,0 14px 30px rgba(0,30,68,.2);transform:rotate(-.5deg)}',
    '.chi-nastro{position:absolute;left:50%;top:-13px;width:104px;height:28px;margin-left:-52px;background:rgba(63,159,244,.5);transform:rotate(-2.5deg);box-shadow:0 1px 3px rgba(0,30,68,.2)}',
    '.chi-menu{position:absolute;right:8px;top:8px;width:40px;height:40px;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:rgba(20,40,77,.08);color:#14284D;cursor:pointer}',
    '.chi-pag h3{margin:0 34px 4px;font:700 36px/1 "Caveat","Segoe Print","Bradley Hand",cursive;color:#14284D}',
    '.chi-v{margin:14px 0 0;animation:chiEntra .5s ease-out both;animation-delay:calc(var(--i) * 70ms)}',
    '@keyframes chiEntra{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}',
    '.chi-v small{display:block;font:800 10.5px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#C22D3A}',
    '.chi-v p{margin:3px 0 0;font:600 23px/1.15 "Caveat","Segoe Print","Bradley Hand",cursive;color:#14284D;overflow-wrap:anywhere}.chi-v.grande p{font-size:29px;font-weight:700;color:#0059B3}.chi-fr{vertical-align:-3px;margin:0 5px}.chi-img{display:block;width:100%;max-height:150px;object-fit:cover;margin:6px 0 2px;border-radius:6px}',
    '.chi-vuota{margin:24px 0 0;font:600 22px/1.2 "Caveat","Segoe Print",cursive;color:#14284D}',
    '.chi-piede{display:flex;flex-direction:column;align-items:center;gap:12px;margin-top:20px}',
    '.chi-timbro{display:inline-flex;flex-direction:column;align-items:center;gap:3px;padding:12px 18px;border:3px double #D92F3D;border-radius:14px;color:#D92F3D;transform:rotate(-6deg);opacity:.92}.chi-timbro small{font:900 10px var(--font-body);letter-spacing:.14em;text-transform:uppercase}.chi-timbro b{font:800 17px var(--font-display)}',
    '.chi-firma{font:600 28px/1 "Caveat","Segoe Print",cursive;color:#14284D;padding:0 18px 6px;border-bottom:1.5px solid rgba(20,40,77,.45)}',
    '.chi-f-t{flex:1;min-width:0;padding:0;border:0;background:none;text-align:left;cursor:pointer;font:inherit}.chi-f-m{flex:none;width:36px;height:36px;padding:0;border:0;border-radius:50%;background:#E3F1FF;color:#0075E3;cursor:pointer;display:flex;align-items:center;justify-content:center}body.dark .chi-f-m{background:#1B2C4F;color:#8CC6FF}.chi-campo{display:block;margin:0 0 14px;text-align:left}.chi-campo > span{display:block;margin-bottom:6px;font:700 13px var(--font-body);color:var(--muted)}.chi-campo input,.chi-campo textarea{display:block;width:100%;box-sizing:border-box;padding:12px 14px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);color:var(--navy);font:500 15px var(--font-body);resize:none}body.dark .chi-campo input,body.dark .chi-campo textarea{background:#12203A;color:#fff}.chi-col{display:flex;gap:12px}.chi-col button{width:34px;height:34px;padding:0;border:0;border-radius:50%;cursor:pointer}.chi-col button.on{box-shadow:0 0 0 2px var(--card,#fff),0 0 0 4px #0075E3}.chi-fisso{margin:0 0 14px;font:500 14px var(--font-body);color:var(--muted);text-align:left}.chi-imgb{margin:0 !important;width:100%}.chi-piu{margin-top:14px}',
    '.acc-story-top{display:flex;justify-content:flex-end;margin:-6px 0 8px}.acc-tre{width:40px;height:40px;padding:0;border:0;border-radius:50%;background:#E3F1FF;color:#0075E3;cursor:pointer;display:flex;align-items:center;justify-content:center}body.dark .acc-tre{background:#1B2C4F;color:#8CC6FF}',
    '.acc-bloccata{position:relative;overflow:hidden;margin-top:12px;filter:saturate(.7)}.acc-bloccata .pt-arrivo{position:absolute;top:15px;right:-38px;width:132px;box-sizing:border-box;padding:4px 0;transform:rotate(38deg);text-align:center;background:linear-gradient(135deg,#f6cce4,#0075E3);color:#fff;font:800 10.5px var(--font-body);font-style:normal;text-shadow:0 1px 2px rgba(0,0,0,.4)}',
    '.chi-f h3{margin:10px 42px 12px}.chi-f-r{display:flex;align-items:center;gap:14px;padding:13px 2px;border-top:1px solid var(--line)}.chi-f-r > div{flex:1;min-width:0;text-align:left}.chi-f-r b{display:block;font:700 15px var(--font-body);color:var(--navy)}body.dark .chi-f-r b{color:#fff}.chi-f-r small{display:block;margin-top:2px;font:500 12.5px/1.35 var(--font-body);color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ap-f .chi-f-r small{white-space:normal}',
    '.acc-media{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.acc-media figure{margin:0;border-radius:14px;overflow:hidden;background:var(--card,#fff);box-shadow:0 4px 12px rgba(0,30,68,.1)}',
    '.acc-media img{display:block;width:100%;aspect-ratio:1;object-fit:cover}',
    '.acc-media figcaption{padding:6px 8px;font:600 12px var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.acc-story{width:100%;display:flex;align-items:center;gap:12px;padding:14px;border:1.5px solid var(--line);border-radius:16px;background:transparent;text-align:left;cursor:pointer}',
    '.acc-story-cov{width:46px;height:56px;border-radius:4px 8px 8px 4px;background:#4a2c1c;display:flex;align-items:center;justify-content:center;font-size:24px;box-shadow:0 4px 10px rgba(0,0,0,.25)}',
    '.acc-story div{flex:1}.acc-story b{display:block;font:800 15px var(--font-body);color:var(--navy)}',
    'body.dark .acc-story b{color:#fff}',
    '.acc-story small{font:500 12.5px var(--font-body);color:var(--muted)}',
    '.acc-pub{margin-top:14px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

function accStat(n, titolo, spiega){
  return '<button type="button" class="acc-stat" onclick="toast(' + esc(JSON.stringify(spiega)) + ')">'
    + '<b>' + esc(n) + '</b><small>' + esc(titolo) + '</small></button>';
}

(function accForestStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.acc-forest{display:flex;align-items:stretch;justify-content:center;gap:2px;margin:0}.acc-forest-4 > *{min-width:0}',
    '.acc-top3{margin:22px 0 0;padding:16px 6px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .acc-top3{background:#12203A;border-color:#22345A}',
    '.acc-ab-sez{margin:0 0 30px}.acc-ab-sez .acc-sect{margin:0 2px 12px}.acc-ab-sez:first-child{margin-top:20px}',
    '.acc-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;gap:12px}.acc-car::-webkit-scrollbar{display:none}.acc-car-s{flex:0 0 100%;scroll-snap-align:start;text-align:center;padding:26px 20px 24px;border:1px solid var(--line);border-radius:20px;background:var(--card,#fff)}body.dark .acc-car-s{background:#12203A;border-color:#22345A}',
    '.acc-car-ico{display:block;font-size:44px;line-height:1}.acc-car-s b{display:block;margin-top:12px;font:900 40px/1 var(--font-display);color:var(--navy)}body.dark .acc-car-s b{color:#fff}.acc-car-s small{display:block;margin-top:10px;font:700 13px var(--font-body);letter-spacing:.04em;text-transform:uppercase;color:var(--navy)}body.dark .acc-car-s small{color:#fff}.acc-car-s em{display:block;margin-top:8px;font:500 13px/1.5 var(--font-body);font-style:normal;color:var(--muted)}',
    '.acc-car-dots{margin-top:12px}.acc-pub-liv{margin:6px 0 0;text-align:center;font:600 13px var(--font-body);color:var(--muted)}.acc-story-cov.film{background:#0B2A4A}.acc-film{margin-top:14px}.acc-cinema-pag{padding-top:6px}.cn-pubblico .cn-intro,.cn-pubblico .cn-pitch{display:none}',
    '.acc-slider-w{margin:18px 0 4px}.acc-slider{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none}.acc-slider::-webkit-scrollbar{display:none}.acc-slide{flex:0 0 100%;scroll-snap-align:start;padding:14px 6px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .acc-slide{background:#12203A;border-color:#22345A}',
    '.acc-dots{display:flex;justify-content:center;gap:6px;margin-top:10px}.acc-dots i{width:7px;height:7px;border-radius:50%;background:var(--line)}.acc-dots i.on{background:#0075E3}',
    '.acc-stat-btn{border:0;background:transparent;padding:0;font:inherit;color:inherit;cursor:pointer;flex:1;display:flex}.acc-stat-btn > *{flex:1}',
    '.acc-pub-link{display:block;margin:6px auto 0;border:0;background:transparent;font:700 13.5px var(--font-body);color:#0075E3;cursor:pointer}',
    '.acc-social{display:flex;gap:10px;margin:18px 0 6px}.acc-amici{flex:1;display:flex;align-items:center;justify-content:center;gap:10px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);padding:14px;font:800 14px var(--font-body);letter-spacing:.04em;text-transform:uppercase;color:var(--navy);cursor:pointer}.acc-qr{width:54px;border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);color:#0075E3;cursor:pointer}body.dark .acc-amici,body.dark .acc-qr{background:#12203A;border-color:#22345A;color:#fff}',
    '.acc-online{display:flex;align-items:center;gap:12px;margin:14px 0 0;padding:12px 14px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .acc-online{background:#12203A;border-color:#22345A}.acc-dot{width:12px;height:12px;border-radius:50%;background:#1B9E6A;box-shadow:0 0 0 4px rgba(27,158,106,.2)}.acc-online b{display:block;font:800 14px var(--font-body);color:var(--navy)}body.dark .acc-online b{color:#fff}.acc-online small{font:500 12.5px var(--font-body);color:var(--muted)}',
    '.acc-sect{margin:24px 2px 10px}.acc-presto{font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.acc-pan{display:grid;grid-template-columns:1fr 1fr;gap:10px}.acc-pan-c{display:flex;align-items:center;gap:10px;padding:12px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .acc-pan-c{background:#12203A;border-color:#22345A}.acc-pan-c > span{font-size:26px}.acc-pan-c b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .acc-pan-c b{color:#fff}.acc-pan-c small{font:500 11.5px var(--font-body);color:var(--muted)}',
    '.acc-conq{display:flex;gap:10px}.acc-conq span{width:64px;height:64px;display:flex;align-items:center;justify-content:center;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);font-size:28px;filter:grayscale(1);opacity:.45}body.dark .acc-conq span{background:#12203A;border-color:#22345A}',
    '.acc-pub-eti{margin:4px 0 12px;font:700 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}.acc-pub-card{text-align:center;padding:18px 14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .acc-pub-card{background:#12203A;border-color:#22345A}.acc-pub-card .av{width:84px;height:84px;margin:0 auto 10px;border-radius:50%;background:var(--blue);color:#fff;display:flex;align-items:center;justify-content:center;font:800 36px var(--font-display);background-size:cover;background-position:center}.acc-pub-card > b{display:block;font:800 20px var(--font-display);color:var(--navy)}body.dark .acc-pub-card > b{color:#fff}.acc-pub-card > small{display:block;font:600 12.5px var(--font-body);color:var(--muted)}.acc-pub-sogno{margin:10px 0 0;font:600 14px var(--font-body);color:var(--navy)}body.dark .acc-pub-sogno{color:#fff}',
    '.acc-pub-n{display:flex;justify-content:center;gap:26px;margin-top:14px}.acc-pub-n span{display:flex;flex-direction:column;font:600 11.5px var(--font-body);color:var(--muted)}.acc-pub-n b{font:900 20px var(--font-display);color:var(--navy)}body.dark .acc-pub-n b{color:#fff}.acc-pub-nota{margin:12px 0 0;font:500 12.5px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.acc-pola{margin:6px auto 0;width:min(100%,300px);background:#fff;border-radius:8px;box-shadow:0 14px 34px rgba(0,0,0,.25);padding:12px 12px 14px}.acc-pola-img{height:250px;border-radius:4px;background:#0B2A4A center/cover;display:flex;align-items:center;justify-content:center}.acc-pola-img span{font:800 120px var(--font-display);color:#4FB8FF}.acc-pola-piede{display:flex;align-items:flex-end;justify-content:space-between;margin-top:12px}.acc-pola-piede b{display:block;font:800 22px var(--font-display);color:#001E44}.acc-pola-piede small{display:block;font:600 13px var(--font-body);color:#6B7A90}.acc-pola-piede em{display:block;margin-top:10px;font:800 17px var(--font-display);font-style:normal;color:#0075E3}.acc-pola-qr svg{display:block}',
    '.acc-qr-btn{display:flex;flex-direction:column;align-items:center;gap:8px;margin-top:14px}.acc-qr-btn .cta{width:100%}.acc-sogni{display:flex;flex-direction:column;gap:8px}.acc-sogno{display:flex;align-items:center;gap:12px;padding:12px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line)}.acc-sogno b{display:block;font:800 14px var(--font-body);color:var(--navy)}.acc-sogno small{color:var(--muted)}',
    '.acc-forest .sep{width:1px;background:var(--line);margin:6px 0}',
    '.acc-stat{flex:1;min-width:0;border:0;background:transparent;padding:6px 4px;cursor:pointer;text-align:center}',
    '.acc-stat b{display:block;font:800 22px/1 var(--font-display);color:var(--navy)}body.dark .acc-stat b{color:#fff}',
    '.acc-stat small{display:block;margin-top:5px;font:600 10px/1.3 var(--font-body);color:var(--muted)}',
    'body.dark .acc-stat b{color:#8CF0C8}',
    /* Il mantra di adesso: un titolo vero, e rosso — l'unica riga della pagina che deve
       fermare l'occhio invece di lasciarsi scorrere. */
    '.acc-now-h{margin:0 0 6px;font:800 17px/1.25 var(--font-display);color:#E5515F}',
    'body.dark .acc-now-h{color:#FF8A9B}'
  ].join('\n');
  document.head.appendChild(st);
})();

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.qrw{position:fixed;inset:0;z-index:9995;display:flex;flex-direction:column;justify-content:flex-end;background:rgba(0,0,0,0);transition:background .25s}.qrw.in{background:rgba(0,0,0,.62)}',
    /* 0.9.341, Andrea: "la card viene tagliata in altezza": con la card piu' alta dello spazio il foglio la spingeva fuori dallo
       schermo in alto. Si scorre, la card parte dall'alto, e la foto si accorcia sui telefoni bassi */
    /* 0.9.343, Andrea: "la nostra card e' piu' alta e la foto viene tagliata; sul QR di Duolingo c'e' l'icona dell'app". La foto
       e' quadrata e allineata in alto (il viso), la card piu' stretta, l'icona di DreamMap al centro del QR */
    '.acc-pola-qr{position:relative}.acc-qr-logo{position:absolute;left:50%;top:50%;width:22%;height:22%;transform:translate(-50%,-50%);border-radius:6px;box-shadow:0 0 0 3px #fff}',
    '.qrw-card .acc-pola{max-width:min(300px,calc(40vh + 24px))!important}.qrw .acc-pola-img,.acc-pola-img{height:auto!important;aspect-ratio:1/1;background-position:center 25%!important}',
    '.qrw{justify-content:flex-start;overflow-y:auto}.qrw .qrw-card{margin-top:auto;padding-top:calc(env(safe-area-inset-top,0px) + 16px)}.qrw .acc-pola-img{height:min(250px,30vh)}.qrw .qrw-sheet{flex:none}',
    '.qrw-card{display:flex;justify-content:center;padding:0 26px 18px;transform:translateY(30px);opacity:0;transition:transform .35s cubic-bezier(.2,1.2,.4,1),opacity .25s}.qrw.in .qrw-card{transform:none;opacity:1}.qrw-card .acc-pola{width:100%;max-width:340px;margin:0;box-shadow:0 18px 40px rgba(0,0,0,.45)}',
    '.qrw-sheet{position:relative;background:#1B232E;border-radius:24px 24px 0 0;padding:58px 0 calc(env(safe-area-inset-bottom,0px) + 22px);transform:translateY(100%);transition:transform .32s cubic-bezier(.2,1,.3,1)}.qrw.in .qrw-sheet{transform:none}',
    '.qrw-x{position:absolute;left:14px;top:12px;width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:#C9D3E0;font-size:22px;cursor:pointer}',
    '.qrw-app{display:flex;gap:18px;overflow-x:auto;padding:0 20px 18px;scrollbar-width:none}.qrw-app::-webkit-scrollbar{display:none}.qrw-app button{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:8px;width:68px;border:0;background:transparent;cursor:pointer}.qrw-app small{font:600 12.5px var(--font-body);color:#E6ECF3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:72px}',
    '.qrw-testa{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;justify-content:center;height:calc(env(safe-area-inset-top,0px) + 60px);padding-top:env(safe-area-inset-top,0px);color:#fff;font:800 18px var(--font-body)}.qrw-x2{position:absolute;left:12px;bottom:10px;width:40px;height:40px;border:0;background:transparent;color:#C9D3E0;font-size:22px;cursor:pointer}',
    '.qrw.pieno.in{background:#141B24}.qrw.pieno{justify-content:space-between}.qrw.pieno .qrw-card{padding-top:calc(env(safe-area-inset-top,0px) + 90px)}',
    '.qrw-img{display:block;width:100%;max-width:300px;border-radius:22px;box-shadow:0 18px 40px rgba(0,0,0,.45)}.qrw-sheet.sola{padding-top:22px}.qrw-app-in{display:contents}.qrw-app-in button{flex:0 0 auto}',
    /* 0.9.341, Andrea: "Instagram, Facebook, WhatsApp hanno un bordo bianco circolare": l'icona tiene la sua forma, niente cerchio bianco dietro */
    '.qrw-ico{width:60px;height:60px;border-radius:0;background:transparent center/contain no-repeat}.qrw-tondo{width:60px;height:60px;border-radius:50%;background:#E6ECF3;color:#1B232E;display:flex;align-items:center;justify-content:center;font:900 24px var(--font-body)}.qrw-due{padding-top:4px;border-top:1px solid rgba(255,255,255,.08);padding-top:18px}'
  ].join('\n');
  document.head.appendChild(st);
})();
