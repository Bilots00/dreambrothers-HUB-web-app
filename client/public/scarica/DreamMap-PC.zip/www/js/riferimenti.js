/* ===========================================================================================
   I DOCUMENTI DI RIFERIMENTO (0.9.253)

   Andrea: come in Claude Cowork, si deve poter allegare un file Markdown (.md), un testo o
   delle immagini per personalizzare il proprio agente e per dare un'identita' all'Io futuro.
   Un file .md con "chi voglio essere" vale piu' di un campo da 120 caratteri.

   Un posto solo per tutti e due (scope: 'agente' | 'iofuturo'), in localStorage:
     fl_rif_<scope> = [{ id, nome, tipo: 'testo'|'foto', testo?, mime?, dati?, anteprima?, at }]
   - .md, .txt, .markdown: si legge il testo e si tiene (fino a 20.000 caratteri per file,
     40.000 in tutto per scope); va nel brief dell'agente e nella memoria dell'Io futuro.
   - immagini: si riducono con agFotoRiduci (agente.js: 1568 px sul lato lungo, anteprima a
     160) e si tengono al massimo in due; all'agente vanno come allegati del primo messaggio
     di ogni conversazione nuova, all'Io futuro restano come volto e riferimento visivo.
   - PDF: qui non si leggono; si dice di usare il testo o un .md (nella chat dell'agente il PDF
     si puo' allegare al messaggio, e lo legge il server).
   =========================================================================================== */
const RF_MAX_TESTO = 20000, RF_MAX_TOT = 40000, RF_MAX_FOTO = 2;
function rfEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function rfKey(scope){ return 'fl_rif_' + (scope === 'iofuturo' ? 'iofuturo' : 'agente'); }
function rfLista(scope){ try{ return JSON.parse(localStorage.getItem(rfKey(scope)) || '[]') || []; }catch(_){ return []; } }
function rfSalva(scope, l){
  try{ localStorage.setItem(rfKey(scope), JSON.stringify(l)); return true; }
  catch(_){ if (typeof toast === 'function') toast('Non c’è spazio per salvare questo file: togline uno'); return false; }
}
/** Il testo dei riferimenti, pronto per un brief: ogni file con il suo nome. */
function rfTesto(scope, max){
  const l = rfLista(scope).filter(function(x){ return x.tipo === 'testo' && x.testo; });
  if (!l.length) return '';
  let out = l.map(function(x){ return 'DOCUMENTO «' + x.nome + '»:\n' + x.testo; }).join('\n\n');
  if (max && out.length > max) out = out.slice(0, max) + '…';
  return out;
}
/** Gli stessi testi a pezzi (un pezzo per file), per chi li vuole in lista. */
function rfPezzi(scope, maxPerFile){
  return rfLista(scope).filter(function(x){ return x.tipo === 'testo' && x.testo; }).map(function(x){ return 'DOCUMENTO «' + x.nome + '» (lo ha scritto lui, vale come sua voce): ' + String(x.testo).slice(0, maxPerFile || 2500); });
}
/** Le immagini come allegati della chat (stessa forma di agAllegatoDa). */
function rfAllegati(scope){
  return rfLista(scope).filter(function(x){ return x.tipo === 'foto' && x.dati; }).map(function(x){ return { tipo: 'foto', mime: x.mime || 'image/jpeg', nome: x.nome, dati: x.dati, anteprima: x.anteprima || '' }; });
}
function rfQuanti(scope){ return rfLista(scope).length; }
function rfSezioneHtml(scope, titolo, sotto){
  const l = rfLista(scope);
  const righe = l.map(function(x){
    const ico = x.tipo === 'foto' ? (x.anteprima ? '<img src="' + x.anteprima + '" alt="">' : '🖼️') : '📄';
    const misura = x.tipo === 'foto' ? 'immagine' : (Math.round((x.testo || '').length / 100) / 10).toFixed(1).replace('.', ',') + ' mila caratteri';
    return '<div class="rf-riga"><span class="rf-ico">' + ico + '</span><div><b>' + rfEsc(x.nome) + '</b><small>' + misura + '</small></div>'
      + '<button type="button" class="rf-x" onclick="rfTogli(\'' + scope + '\',\'' + x.id + '\')" aria-label="Togli ' + rfEsc(x.nome) + '">✕</button></div>';
  }).join('');
  return '<div class="rf-sez" id="rfSez-' + scope + '"><div class="sect"><b>' + rfEsc(titolo || 'Documenti di riferimento') + '</b></div>'
    + '<p class="hintline">' + rfEsc(sotto || 'Un file .md o un testo con quello che deve sapere, o un’immagine. Come dare un dossier a una persona nuova.') + '</p>'
    + (righe ? '<div class="rf-lista">' + righe + '</div>' : '')
    + '<button type="button" class="rf-btn" onclick="rfAllegaApri(\'' + scope + '\')"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.5l-8.6 8.6a5 5 0 0 1-7.1-7.1l9.2-9.2a3.3 3.3 0 0 1 4.7 4.7l-9.2 9.2a1.7 1.7 0 0 1-2.4-2.4l8.5-8.5"/></svg><span>Allega un file .md, un testo o un’immagine</span></button></div>';
}
function rfRipaint(scope){
  const h = document.getElementById('rfSez-' + scope); if (!h) return;
  const sotto = h.querySelector('.hintline'), tit = h.querySelector('.sect b');
  h.outerHTML = rfSezioneHtml(scope, tit ? tit.textContent : '', sotto ? sotto.textContent : '');
}
function rfTogli(scope, id){
  rfSalva(scope, rfLista(scope).filter(function(x){ return x.id !== id; }));
  rfRipaint(scope);
  try{ flVibra(8); }catch(_){ }
}
function rfAllegaApri(scope){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.multiple = true; inp.style.display = 'none';
  inp.accept = 'text/plain,text/markdown,image/*,.md,.markdown,.txt';
  inp.addEventListener('change', function(){ const f = Array.prototype.slice.call(inp.files || []); inp.remove(); rfAllegaFile(scope, f); });
  document.body.appendChild(inp);
  inp.click();
}
function rfLeggiTesto(f){
  return new Promise(function(ok, no){ const r = new FileReader(); r.onload = function(){ ok(String(r.result || '')); }; r.onerror = function(){ no(new Error('leggi')); }; r.readAsText(f); });
}
async function rfAllegaFile(scope, files){
  const l = rfLista(scope);
  let aggiunti = 0;
  for (let i = 0; i < files.length; i++){
    const f = files[i];
    const nome = String(f.name || 'file').slice(0, 120);
    const n = nome.toLowerCase();
    const mime = String(f.type || '').toLowerCase();
    try{
      if (/^image\//.test(mime) || /\.(jpe?g|png|webp|gif|heic)$/.test(n)){
        if (l.filter(function(x){ return x.tipo === 'foto'; }).length >= RF_MAX_FOTO){ toast('Al massimo ' + RF_MAX_FOTO + ' immagini: togline una'); continue; }
        if (typeof agFotoRiduci !== 'function'){ toast('Le immagini non si possono leggere adesso'); continue; }
        const a = await agFotoRiduci(f);
        l.push({ id: 'rf' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), nome: nome, tipo: 'foto', mime: a.mime || 'image/jpeg', dati: a.dati, anteprima: a.anteprima || '', at: Date.now() });
        aggiunti++;
      } else if (/\.pdf$/.test(n) || mime === 'application/pdf'){
        toast('I PDF qui non li leggo: incolla il testo in un file .md o .txt');
      } else {
        if (f.size > 2 * 1024 * 1024){ toast('«' + nome + '» è troppo grande: fino a 2 MB di testo'); continue; }
        let t = String(await rfLeggiTesto(f) || '').replace(/\r\n/g, '\n').trim();
        if (!t){ toast('«' + nome + '» è vuoto'); continue; }
        if (t.length > RF_MAX_TESTO) t = t.slice(0, RF_MAX_TESTO) + '\n…';
        const tot = l.filter(function(x){ return x.tipo === 'testo'; }).reduce(function(a, x){ return a + (x.testo || '').length; }, 0);
        if (tot + t.length > RF_MAX_TOT){ toast('Troppo testo in tutto: togli un documento prima di aggiungerne un altro'); continue; }
        l.push({ id: 'rf' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), nome: nome, tipo: 'testo', testo: t, at: Date.now() });
        aggiunti++;
      }
    }catch(_){ toast('Non riesco a leggere «' + nome + '»'); }
  }
  if (aggiunti){
    if (!rfSalva(scope, l)) return;
    try{ flVibra([10, 30, 10]); }catch(_){ }
    toast(aggiunti === 1 ? 'Allegato: da adesso ne tiene conto' : aggiunti + ' allegati: da adesso ne tiene conto');
  }
  rfRipaint(scope);
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.rf-sez{margin:6px 0 10px}',
    '.rf-lista{margin:0 0 10px;border-radius:16px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);overflow:hidden}body.dark .rf-lista{background:rgba(255,255,255,.06);box-shadow:0 0 0 1.5px rgba(255,255,255,.18)}',
    '.rf-riga{display:flex;align-items:center;gap:10px;padding:10px 12px;border-top:1px solid var(--line,#E5ECF6)}.rf-riga:first-child{border-top:0}body.dark .rf-riga{border-color:rgba(255,255,255,.12)}',
    '.rf-riga > div{flex:1;min-width:0}.rf-riga b{display:block;font:700 13.5px var(--font-body);color:var(--navy,#14234A);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .rf-riga b{color:#fff}',
    '.rf-riga small{font:600 11.5px var(--font-body);color:var(--muted,#5B6B86)}body.dark .rf-riga small{color:#C9D6EE}',
    '.rf-ico{flex:none;width:36px;height:36px;border-radius:10px;display:grid;place-items:center;font-size:20px;background:var(--bg,#F3F6FB);overflow:hidden}.rf-ico img{width:100%;height:100%;object-fit:cover}body.dark .rf-ico{background:rgba(255,255,255,.08)}',
    '.rf-x{flex:none;width:30px;height:30px;border:0;border-radius:50%;background:transparent;color:var(--muted,#5B6B86);font-size:14px;cursor:pointer}body.dark .rf-x{color:#C9D6EE}',
    '.rf-btn{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:12px;border:1.5px dashed var(--line,#C9D3E3);border-radius:14px;background:transparent;color:var(--blue,#0075E3);font:700 13.5px var(--font-body);cursor:pointer}body.dark .rf-btn{border-color:rgba(255,255,255,.3);color:#8CC6FF}'
  ].join('');
  document.head.appendChild(st);
})();
