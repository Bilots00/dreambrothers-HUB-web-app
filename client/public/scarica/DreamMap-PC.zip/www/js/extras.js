/* extras.js — le tre uscite e il tono della schermata di blocco.

   Tre pagine che hanno in comune una cosa sola: riguardano il momento in cui la regola viene
   messa alla prova.

   1. LA SALA D'ATTESA. Un blocco senza nessuna uscita non è più severo, è più fragile: quando
      l'unica strada rimasta è disinstallare l'app, prima o poi qualcuno la disinstalla — e da
      quel momento non blocca più niente, per sempre. L'attesa è un'uscita che costa e non
      discute. In modalità crescente ogni passaggio della giornata raddoppia: la prima volta
      entri quasi subito, la quinta non ne vale più la pena. È la stessa idea dell'attrito che
      cresce, ed è la cosa più intelligente che si possa fare con una tentazione.

   2. IL PASS D'EMERGENZA. Uno. Non uno al mese: uno e basta. Serve per la volta in cui serve
      davvero, e sapere che è l'unico è esattamente ciò che impedisce di bruciarlo per noia.

   3. LE SCHERMATE A TEMA. La frase del blocco è l'unico momento in cui l'app ha la parola.
      Sempre la stessa diventa arredamento in tre giorni. Il tono però non è uno: c'è chi si
      ferma davanti a Seneca e chi ha bisogno che glielo dicano in faccia. */

/* ============================================================================
   1. LA SALA D'ATTESA
   ============================================================================ */
const WAIT_SECS = [5, 10, 20, 30, 60];

registerScreen('s-waiting',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-settings\')">‹</button><b class="blk-title">Sala d\'attesa</b></div>'
  + '<div id="waitBody"></div><div class="spacer"></div>', { back: 's-settings' });

function waitOpen(){ goId('s-waiting'); waitPaint(); }

function waitMode(){ return (typeof SETTINGS !== 'undefined' && SETTINGS.waitMode) || 'off'; }
function waitSec(){ return +(typeof SETTINGS !== 'undefined' && SETTINGS.waitSec) || 10; }

async function waitSet(patch){
  if (typeof settingsSave === 'function') await settingsSave(patch);
  waitPaint();
}
function waitSetMode(m){ waitSet({ waitMode: m }); }
function waitSetSec(s){ waitSet({ waitSec: s, waitMode: waitMode() === 'off' ? 'standard' : waitMode() }); }

function waitPaint(){
  const host = document.getElementById('waitBody');
  if (!host) return;
  const mode = waitMode(), sec = waitSec();
  const card = function(k, name, desc){
    return '<button type="button" class="wr-card' + (mode === k ? ' on' : '') + '" onclick="waitSetMode(\'' + k + '\')">'
      + '<div><b>' + name + '</b><small>' + desc + '</small></div><i class="wr-dot"></i></button>';
  };
  host.innerHTML =
      /* Il disegno prima delle parole: si capisce a colpo d'occhio cosa succede. */
      '<div class="wr-demo"><div class="wr-phone">'
    +   '<div class="wr-screen"><div class="wr-lock">🛡️</div><div class="wr-l1"></div><div class="wr-l2"></div>'
    +     '<div class="wr-btn">' + (mode === 'off' ? 'Torna indietro' : 'Entro lo stesso · ' + sec + 's') + '</div></div>'
    + '</div></div>'
    + '<p class="wr-p">Quando una app è bloccata puoi entrare lo stesso, ma aspettando. Nessuna scusa da scrivere, nessuna domanda: solo tempo.</p>'
    + '<div class="sect"><b>Resistenza</b></div>'
    + card('off', 'Spenta', 'Nessuna uscita: la regola è la regola.')
    + card('standard', 'Costante', 'La stessa attesa tutte le volte.')
    + card('increasing', 'Crescente', 'Raddoppia a ogni volta della giornata: 10s, 20s, 40s…')
    + (mode === 'off' ? '' :
        '<div class="sect" style="margin-top:20px"><b>Attesa di partenza</b></div>'
      + '<div class="sev-chips">' + WAIT_SECS.map(function(s){
          return '<button type="button" class="sev-chip' + (sec === s ? ' on' : '') + '" onclick="waitSetSec(' + s + ')">' + s + 's</button>';
        }).join('') + '</div>'
      + '<p class="hintline" style="padding:12px 2px 0">Passata l\'attesa, quell\'app resta aperta per cinque minuti. Poi la regola torna da sola.</p>')
    + '<p class="hintline" style="padding:14px 2px 0">Con la modalità severa accesa la sala d\'attesa non compare: severa esiste per non avere uscite.</p>';
}

/* ============================================================================
   2. IL PASS D'EMERGENZA
   ============================================================================ */
registerScreen('s-emergency',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-settings\')">‹</button><b class="blk-title">Pass d\'emergenza</b></div>'
  + '<div id="emgBody"></div><div class="spacer"></div>', { back: 's-settings' });

const EMG = { hold: 0, t0: 0 };

async function emgOpen(){ goId('s-emergency'); await emgPaint(); }

async function emgState(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.emergencyState) return null;
  try{ return await NATIVE.emergencyState(); }catch(_){ return null; }
}

async function emgPaint(){
  const host = document.getElementById('emgBody');
  if (!host) return;
  const st = await emgState();
  if (!st){
    host.innerHTML = '<p class="hintline" style="padding:20px 2px">Disponibile solo nell\'app installata.</p>';
    return;
  }
  /* 0.9.292, Andrea: "il pass identico a quello di Opal": la pagina scura (il biglietto su fondo bianco non si vede), il
     biglietto stretto al centro, le tacche dove si strappa, il timbro con "DreamMap non si prende nessuna
     responsabilita'", "Non tenere questa parte", e il pulsante che diventa grigio dopo averlo usato. */
  const active = st.activeUntil && st.activeUntil > Date.now();
  const used = !st.available;
  const codice = Array.from({ length: 46 }).map(function(_, i){
    const w = [3, 1, 2, 1, 4, 1, 2, 3, 1, 1, 2][i % 11];
    return '<i style="width:' + w + 'px;margin-right:' + (i % 4 === 0 ? 3 : 2) + 'px"></i>';
  }).join('');
  host.innerHTML =
      '<div class="emg-tw"><div class="emg-ticket' + (used ? ' spent' : '') + '" id="emgTicket">'
    +   '<div class="emg-top"><b>PASS<br>D’EMERGENZA</b><span class="emg-seal"><svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M7 10V7.5a5 5 0 0 1 9.6-1.9" fill="none" stroke="#0B2A5C" stroke-width="2.2" stroke-linecap="round"/><rect x="4" y="10" width="16" height="12" rx="3.2" fill="#0B2A5C"/></svg></span></div>'
    +   '<div class="emg-issued">EMESSO DALL’UFFICIO SPECIALE DELLE ECCEZIONI TEMPORANEE</div>'
    +   '<div class="emg-grid">'
    /* 0.9.293, Andrea: "era meglio il testo di prima: serve davvero, tutto sbloccato; validita' come Opal, solo
       per oggi". Etichette ferme, niente verbi all'imperativo. */
    +     '<div><i>MOTIVO</i><b>SERVE DAVVERO</b></div>'
    +     '<div><i>ACCESSO</i><b>TUTTO SBLOCCATO</b></div>'
    +     '<div><i>COSTO</i><b>IL TUO UNICO PASS</b></div>'
    +     '<div><i>VALIDITÀ</i><b>SOLO PER OGGI</b></div>'
    +   '</div>'
    +   '<div class="emg-timbro"><svg viewBox="0 0 100 100" width="74" height="74" aria-hidden="true"><defs><path id="emgCerchio" d="M50,50 m-38,0 a38,38 0 1,1 76,0 a38,38 0 1,1 -76,0"/></defs>'
    +     '<circle cx="50" cy="50" r="47" fill="none" stroke="#3B4A63" stroke-width="1.4"/><circle cx="50" cy="50" r="29" fill="none" stroke="#3B4A63" stroke-width="1.2"/>'
    +     '<text font-size="8.6" letter-spacing="1.6" fill="#3B4A63" font-family="ui-monospace,monospace" font-weight="700"><textPath href="#emgCerchio">DREAMMAP · UFFICIO DELLE ECCEZIONI ·</textPath></text>'
    +     '<path d="M50 33 L54 46 L67 50 L54 54 L50 67 L46 54 L33 50 L46 46 Z" fill="#0B2A5C"/></svg>'
    +     '<p>DREAMMAP NON SI PRENDE NESSUNA RESPONSABILITÀ PER QUELLO CHE SUCCEDE DOPO</p></div>'
    +   '<div class="emg-cut"><i></i><span></span><i></i></div>'
    +   '<div class="emg-code">' + codice + '</div>'
    +   '<div class="emg-foot">NON TENERE QUESTA PARTE</div>'
    + '</div></div>'
    + '<p class="emg-sotto">' + (active
        ? 'Tutto sbloccato fino alle ' + new Date(st.activeUntil).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) + '.'
        : (used ? 'L’hai usato il ' + new Date(st.usedAt).toLocaleDateString('it-IT') + '. Ne esisteva uno solo.'
                : 'Supera tutte le regole e sblocca tutte le app, una volta sola. Con la Modalità severa accesa, la spegne.')) + '</p>'
    + '<button type="button" class="emg-hold" id="emgHold"' + (used ? ' disabled' : '') + '><span>Tieni premuto per usarlo</span></button>';
  /* le tacche sono buchi veri nel biglietto (maschera), non due pallini colorati: si vede lo sfondo che c'e' dietro */
  const tk = document.getElementById('emgTicket'), cut = tk && tk.querySelector('.emg-cut');
  if (tk && cut) tk.style.setProperty('--cy', (cut.offsetTop + cut.offsetHeight / 2) + 'px');
  const btn = document.getElementById('emgHold');
  if (btn && !used) emgBindHold(btn);
}

/* Tieni premuto, non toccare: un gesto che dura due secondi non si fa per sbaglio, ed è
   l'unica protezione sensata per una cosa che non si può annullare. */
function emgBindHold(btn){
  /* 0.9.291, Andrea: "tenendo premuto voglio la vibrazione, e il pulsante nero non c'entra con i colori del brand" */
  if (typeof flTieniPremuto === 'function'){ flTieniPremuto(btn, 2000, emgUse); return; }
  const HOLD = 2000;
  const start = function(e){
    e.preventDefault();
    EMG.t0 = Date.now();
    btn.classList.add('holding');
    EMG.hold = setInterval(function(){
      const p = Math.min(1, (Date.now() - EMG.t0) / HOLD);
      btn.style.setProperty('--p', (p * 100) + '%');
      if (p >= 1){ stop(); emgUse(); }
    }, 40);
  };
  const stop = function(){
    clearInterval(EMG.hold); EMG.hold = 0;
    btn.classList.remove('holding');
    btn.style.setProperty('--p', '0%');
  };
  btn.addEventListener('pointerdown', start);
  btn.addEventListener('pointerup', stop);
  btn.addEventListener('pointercancel', stop);
  btn.addEventListener('pointerleave', stop);
}

async function emgUse(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.useEmergency) return;
  try{
    const r = await NATIVE.useEmergency();
    if (r && r.ok){
      /* 0.9.292, Andrea: "ho usato il pass d'emergenza e la Modalita' severa e' rimasta accesa". Il pass sbloccava le app
         per un'ora ma non toccava la severa: con la severa accesa ora la spegne (il pass e' gia' speso qui sopra). */
      let severa = false;
      try{ const st = await NATIVE.getStrictState(); severa = !!(st && st.level); }catch(_){ }
      if (severa && NATIVE.emergencyDisableStrict){
        try{ await NATIVE.emergencyDisableStrict({ usaPass: false }); }catch(_){ }
        try{ if (typeof efContoSegna === 'function') efContoSegna(true); }catch(_){ }
        try{ if (typeof sevLoadState === 'function') await sevLoadState(); if (typeof sevSyncTab === 'function') sevSyncTab(); }catch(_){ }
        toast('Pass usato: Modalità severa spenta e app sbloccate per un\'ora.');
      } else toast('Pass usato. Tutto sbloccato per un\'ora.');
    }
    else toast('Il pass era già stato usato');
  }catch(_){ toast('Non riesco a usare il pass'); }
  await emgPaint();
}

/* ============================================================================
   3. LE SCHERMATE A TEMA
   ============================================================================ */
/* «Predefinito» non sta piu' qui dentro: quella frase — "questa app e' bloccata da
   FocusLock" — e' la schermata BASE, che si sceglie una riga piu' su. Tenerla anche fra i
   gruppi voleva dire mettere in un elenco di TONI una voce che non e' un tono.

   Al suo posto, in testa e di serie, c'e' CASUALE: un gruppo fisso dopo una settimana e'
   arredamento — lo riconosci dalla forma prima ancora di leggerlo, e riconoscere qualcosa e'
   l'esatto contrario di fermarsi davanti. */
const LOCK_PACKS = [
  /* 0.9.291: pesca solo fra le frasi che parlano dell'app che hai aperto o del tuo obiettivo (BlockPacks.DINAMICI) */
  { k: 'shuffle',   ico: '🎲', n: 'Casuale',        d: 'Ogni blocco pesca una frase diversa fra quelle sul tuo obiettivo: motivazionali, Sogna in grande, stoici, cose da fare.' },
  { k: 'stoici',    ico: '🏛️', n: 'Stoici',          d: 'Seneca e Marco Aurelio, una riga alla volta.' },
  { k: 'opal',      ico: '⭐', n: 'Sogna in grande', d: 'Un’emoji, il nome dell’app, una citazione e un pulsante che risponde: "Ruggisci", "Spicca il volo ora", "Credici!".' },
  { k: 'appblock',  ico: '🏁', n: 'Motivazionali',   d: '"Procrastinazione bloccata, hai vinto!", "Rimani in pista, campione!": le schermate alla AppBlock, con il programma che blocca e i tentativi.' },
  { k: 'scintilla', ico: '🔥', n: 'Scintilla',       d: '«Accendi la tua passione, non Instagram!» — con il nome dell\'app che hai appena aperto.' },
  { k: 'haiku',     ico: '🪶', n: 'Haiku',           d: 'Tre righe, e il pollice si ferma da solo.' },
  { k: 'menti',     ico: '💡', n: 'Grandi menti',    d: 'Chi ha costruito qualcosa, e come la pensava.' },
  { k: 'offline',   ico: '🚶', n: 'Cose da fare',    d: 'Una piccola cosa vera al posto dello scorrimento.' },
  { k: 'popcult',   ico: '🍿', n: 'Cultura pop',     d: 'Il tono dei film che hai visto tutti.' },
  { k: 'schietto',  ico: '👀', n: 'Senza sconti',    d: 'Te lo dice in faccia. Non è per tutti.', pro: true },
  { k: 'offese',    ico: '🥷', n: 'Offese pesanti',  d: 'Nessun riguardo. Insulta la scelta, non te.', pro: true },
  { k: 'vangelo',   ico: '🙏', n: 'Vangelo',         d: 'Versetti brevi, traduzione storica.', pro: true },
  { k: 'curiosita', ico: '🔬', n: 'Curiosità',       d: 'Una cosa che non sapevi, a ogni blocco.', pro: true },
  { k: 'spazio',    ico: '🪐', n: 'Spazio',          d: 'Quanto è grande tutto il resto.', pro: true },
  { k: 'papa',      ico: '😎', n: 'Battute',         d: 'Quelle che fanno gemere. Funzionano lo stesso.', pro: true }
];

registerScreen('s-lockpacks',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-lockscreen\')">‹</button><b class="blk-title">Cosa c\'è scritto</b></div>'
  + '<p class="hintline" style="padding:2px 2px 14px">La frase che compare quando un blocco scatta. Cambia a ogni volta, dentro al gruppo che scegli.</p>'
  + '<div id="lpBody"></div><div class="spacer"></div>', { back: 's-lockscreen' });

function lpOpen(){ goId('s-lockpacks'); lpPaint(); }

function lpCur(){ return (typeof SETTINGS !== 'undefined' && SETTINGS.lockPack) || 'shuffle'; }

/** Vero quando l'abbonamento e' attivo: e' l'unica cosa che la pagina sa e il motore no. */
function lpPro(){ return (typeof Premium !== 'undefined') && Premium.isPremium(); }

/* Il gruppo di frasi si disegna in due posti: nella sua pagina, e dentro alla pagina dello
   stile (dove sceglierlo ha davvero senso, perche' sono i temi della schermata dinamica). */
function lpPaint(hostId){
  const host = document.getElementById(hostId || 'lpBody');
  if (!host) return;
  const cur = lpCur();
  const premium = lpPro();
  host.innerHTML = LOCK_PACKS.map(function(p){
    const on = cur === p.k;
    /* Casuale e' di tutti, ma senza Premium pesca solo fra i gruppi liberi: dirlo sulla riga
       e' piu' onesto che lasciarglielo capire da quello che non esce mai. */
    const d = (p.k === 'shuffle' && !premium)
        ? p.d + ' Con Premium entrano nel mazzo anche i gruppi ⚡.'
        : p.d;
    return '<button type="button" class="lp-row' + (on ? ' on' : '') + '" onclick="lpPick(\'' + p.k + '\')">'
      + '<span class="lp-ic">' + p.ico + '</span>'
      + '<div class="lp-txt"><b>' + p.n + (p.pro && !premium ? '<i class="lp-pro">⚡ PRO</i>' : '') + '</b><small>' + d + '</small></div>'
      + '<i class="lp-sw' + (on ? ' on' : '') + '"></i></button>';
  }).join('');
}

async function lpPick(k){
  const pack = LOCK_PACKS.filter(function(p){ return p.k === k; })[0];
  const premium = lpPro();
  if (pack && pack.pro && !premium){
    toast('Questo gruppo è Premium');
    if (typeof pwOpen === 'function') pwOpen();
    return;
  }
  /* Un gruppo di frasi è la schermata "dinamica": sceglierne uno la accende, perché scegliere
     il tono e poi non vederlo è il genere di impostazione che fa pensare che l'app sia rotta. */
  /* lockShuffleAll dice al motore cosa puo' mettere nel mazzo quando pesca a caso: l'unico
     che sa se l'abbonamento e' attivo e' questo lato, e il motore non deve indovinarlo. */
  if (typeof settingsSave === 'function') await settingsSave({ lockPack: k, lockStyle: 'dynamic', lockShuffleAll: premium });
  /* Ridisegna dove si sta davvero guardando: nella pagina dello stile la scelta cambia ANCHE
     l'anteprima selezionata li' sopra, e lasciarla indietro era il modo piu' veloce di far
     credere che il tocco non avesse fatto niente. */
  lpPaint();
  if (typeof lockScreenPaint === 'function' && document.getElementById('lsPacks')) lockScreenPaint();
  toast('Schermata di blocco aggiornata');
}

/* ============================================================================
   4. LA FACCIA DEL PROMEMORIA
   Il mantra con l'immagine di chi te lo sta dicendo. Se non ne scegli una vale quella del
   "tuo perché": è già la faccia che l'app associa alle tue ragioni.
   ============================================================================ */
const MANTRA_AV_KEY = 'fl_mantra_avatar';

function mantraAvatarData(){
  try{ return localStorage.getItem(MANTRA_AV_KEY) || localStorage.getItem('fl_why_img') || ''; }
  catch(_){ return ''; }
}
async function mantraAvatarSync(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setMantraAvatar) return;
  try{ await NATIVE.setMantraAvatar({ data: mantraAvatarData() }); }catch(_){ }
}
function mantraAvatarPick(){
  if (typeof flImgPick !== 'function'){ toast('Non disponibile qui'); return; }
  flImgPick(MANTRA_AV_KEY, async function(){
    await mantraAvatarSync();
    if (typeof personalizePaint === 'function') personalizePaint();
    toast('Immagine impostata');
  });
}
async function mantraAvatarClear(){
  try{ localStorage.removeItem(MANTRA_AV_KEY); }catch(_){ }
  await mantraAvatarSync();
  if (typeof personalizePaint === 'function') personalizePaint();
}

/* All'avvio si allinea da sola: se l'utente ha cambiato la foto del "tuo perché", la card del
   mantra deve mostrare quella, senza che nessuno debba ricordarsi di premere niente. */
setTimeout(mantraAvatarSync, 2500);

/* ---------------------------------------------------------------------------------------- */
(function(){
  const css = [
    /* la sala d'attesa */
    '.wr-demo{display:flex;justify-content:center;padding:18px 0 6px}',
    '.wr-phone{width:170px;height:210px;border-radius:22px;background:#0B1730;border:2px solid #1E2F52;padding:12px;overflow:hidden}',
    '.wr-screen{height:100%;border-radius:14px;background:linear-gradient(170deg,#0E2350,#061634);display:flex;',
    '  flex-direction:column;align-items:center;justify-content:center;gap:7px;padding:10px}',
    '.wr-lock{font-size:26px}',
    '.wr-l1,.wr-l2{height:5px;border-radius:99px;background:rgba(255,255,255,.22)}',
    '.wr-l1{width:78%}.wr-l2{width:52%}',
    '.wr-btn{margin-top:6px;padding:6px 10px;border-radius:99px;border:1px solid rgba(200,239,253,.4);',
    '  color:#C8EFFD;font:700 9px var(--font-body);white-space:nowrap}',
    '.wr-p{margin:14px 2px 0;font:500 13.5px/1.6 var(--font-body);color:var(--muted);text-align:center}',
    '.wr-card{display:flex;align-items:center;gap:14px;width:100%;margin-top:10px;padding:15px 16px;border-radius:16px;',
    '  border:1px solid var(--line);background:#fff;color:var(--navy);text-align:left;cursor:pointer}',
    'body.dark .wr-card{background:#12203A;border-color:#22345A;color:#fff}',
    '.wr-card > div{flex:1;min-width:0}',
    '.wr-card b{display:block;font:700 15px var(--font-body)}',
    '.wr-card small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.wr-dot{flex:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--line)}',
    '.wr-card.on{border-color:var(--blue,#006FCF);box-shadow:0 0 0 1px var(--blue,#006FCF)}',
    '.wr-card.on .wr-dot{border-color:var(--blue,#006FCF);background:radial-gradient(circle,var(--blue,#006FCF) 0 45%,transparent 46%)}',
    /* il biglietto, come quello di Opal (0.9.292) */
    '#s-emergency{background:linear-gradient(180deg,#0B2A5C 0%,#00132D 60%)!important;color:#fff}#s-emergency .topbar .blk-title{color:#fff;font-style:normal}#s-emergency .topbar .iconbtn{background:rgba(255,255,255,.12)!important;color:#fff!important}',
    '.emg-tw{margin:18px auto 0;width:min(90%,370px);filter:drop-shadow(0 18px 30px rgba(0,0,0,.35))}',
    '.emg-ticket{--cy:72%;position:relative;padding:22px 20px 14px;border-radius:22px;background:linear-gradient(180deg,#FFFFFF,#E9ECF1);color:#14234A;font-family:ui-monospace,"Roboto Mono","Courier New",monospace;'
    + '-webkit-mask:radial-gradient(circle 11px at left var(--cy),#0000 10.5px,#000 11px) left/51% 100% no-repeat,radial-gradient(circle 11px at right var(--cy),#0000 10.5px,#000 11px) right/51% 100% no-repeat;'
    + 'mask:radial-gradient(circle 11px at left var(--cy),#0000 10.5px,#000 11px) left/51% 100% no-repeat,radial-gradient(circle 11px at right var(--cy),#0000 10.5px,#000 11px) right/51% 100% no-repeat}',
    '.emg-ticket.spent .emg-code,.emg-ticket.spent .emg-top b{opacity:.75}',
    '.emg-top{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}',
    '.emg-top b{flex:1;min-width:0;font:900 22px/1.06 var(--font-display);letter-spacing:.01em;color:#0B1530;overflow-wrap:anywhere}',
    '.emg-seal{width:40px;height:40px;border-radius:13px;background:linear-gradient(135deg,#C8F5DC,#8FD9FF);display:flex;align-items:center;justify-content:center;flex:none}',
    '.emg-issued{margin-top:12px;padding-bottom:12px;border-bottom:1px solid rgba(20,35,74,.18);font-size:10.5px;line-height:1.45;letter-spacing:.04em;color:#3B4A63}',
    '.emg-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px 14px;padding:14px 0;border-bottom:1px solid rgba(20,35,74,.18)}',
    '.emg-grid i{display:block;font-size:10.5px;letter-spacing:.04em;color:#14234A;font-style:normal}',
    '.emg-grid b{display:block;margin-top:3px;font-size:11px;line-height:1.35;font-weight:500;letter-spacing:.03em;color:#14234A}',
    '.emg-timbro{display:flex;align-items:center;gap:12px;padding:14px 0 4px}.emg-timbro svg{flex:none}.emg-timbro p{margin:0;font-size:10px;line-height:1.5;letter-spacing:.04em;color:#3B4A63}',
    '.emg-cut{position:relative;display:flex;align-items:center;margin:12px -20px 0;height:20px}.emg-cut i{flex:none;width:12px;height:20px}',
    '.emg-cut span{flex:1;height:0;border-top:2.5px dashed #0B1530;margin:0 4px}',
    '.emg-code{display:flex;align-items:stretch;justify-content:center;height:42px;margin-top:12px}',
    '.emg-code i{display:block;background:#0B1530}',
    '.emg-foot{margin-top:7px;text-align:center;font-size:9px;letter-spacing:.12em;color:#7C8799}',
    '.emg-sotto{margin:22px auto 0;max-width:30ch;text-align:center;font:500 15.5px/1.5 var(--font-body);color:rgba(220,234,255,.75)}',
    '.emg-note{margin:16px 2px 0;font:600 13px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.emg-note.ok{color:#1B7F4F}',
    '.emg-hold{position:relative;display:block;width:100%;min-height:60px;margin:22px 0 0;padding:16px 20px;border:0;border-radius:30px;overflow:hidden;',
    '  background:linear-gradient(180deg,#2F9BFF,#0075E3);color:#fff;font:700 16px/1.3 var(--font-body);cursor:pointer;--p:0%;',
    '  box-shadow:0 12px 30px rgba(0,117,227,.32);user-select:none;-webkit-user-select:none;touch-action:none}',
    '.emg-hold:disabled{background:rgba(255,255,255,.14);color:rgba(255,255,255,.45);box-shadow:none;cursor:default}',
    '.emg-hold::before{content:"";position:absolute;inset:0;width:var(--p);background:linear-gradient(90deg,rgba(255,255,255,.18),rgba(255,255,255,.4));pointer-events:none}',
    '.emg-hold span{position:relative}.emg-hold.holding{transform:scale(.985)}',
    /* i gruppi di frasi */
    '.lp-row{display:flex;align-items:center;gap:14px;width:100%;margin-top:8px;padding:14px 14px;border-radius:16px;',
    '  border:1px solid var(--line);background:#fff;color:var(--navy);text-align:left;cursor:pointer}',
    'body.dark .lp-row{background:#12203A;border-color:#22345A;color:#fff}',
    '.lp-row.on{border-color:var(--blue,#006FCF);box-shadow:0 0 0 1px var(--blue,#006FCF)}',
    '.lp-ic{font-size:24px;flex:none}',
    '.lp-txt{flex:1;min-width:0}',
    '.lp-txt b{display:flex;align-items:center;gap:8px;font:700 15px var(--font-body)}',
    '.lp-txt small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.lp-pro{flex:none;padding:2px 7px;border-radius:99px;border:1px solid #8CF0C8;color:#1B7F4F;',
    '  font:700 9.5px var(--font-body);font-style:normal;letter-spacing:.06em}',
    'body.dark .lp-pro{color:#8CF0C8}',
    '.lp-sw{flex:none;width:40px;height:24px;border-radius:99px;background:var(--line);position:relative;transition:background .2s}',
    '.lp-sw::after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;transition:transform .2s}',
    '.lp-sw.on{background:#34C759}',
    '.lp-sw.on::after{transform:translateX(16px)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();

/* Se l'abbonamento cambia (o scade) mentre il gruppo scelto e' «Casuale», il mazzo del motore
   va rifatto: senza questa riga chi ha appena pagato continuerebbe a pescare solo fra i gruppi
   liberi fino alla volta in cui si ricorda di ritoccare l'impostazione. */
setTimeout(function(){
  try{
    if (typeof SETTINGS === 'undefined' || !SETTINGS) return;
    const vero = lpPro();
    if (!!SETTINGS.lockShuffleAll === vero) return;
    /* SILENZIOSO. E' una riparazione di fondo, non una scelta dell'utente: passando da
       settingsSave compariva «Impostazioni salvate» a ogni apertura dell'app, senza che
       nessuno avesse toccato niente. Il motore riceve lo stesso valore, senza cartello. */
    SETTINGS.lockShuffleAll = vero;
    try{ if (NATIVE && NATIVE.setSettings) NATIVE.setSettings({ lockShuffleAll: vero }).catch(function(){ }); }catch(_){ }
  }catch(_){ }
}, 4000);
