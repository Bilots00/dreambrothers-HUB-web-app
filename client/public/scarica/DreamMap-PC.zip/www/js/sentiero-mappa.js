/* ===========================================================================================
   IL SENTIERO NELLA MAPPA — sezioni, capitoli, nodi, scrigni (0.9.178), come Duolingo

   Studiato sui 26 screenshot di Duolingo di Andrea (30/09/2026) e sull'app dentro BlueStacks:
     · in alto la scheda blu del capitolo: «SEZIONE 1, CAPITOLO 1 · titolo»;
     · sotto, il sentiero: un nodo per tappa, che serpeggia; quello in corso e' grande, con il
       fumetto «INIZIA»; quelli fatti sono d'oro con la spunta; quelli dopo sono grigi;
     · ogni capitolo finisce con uno scrigno, e accanto c'e' un personaggio (qui il Genio) con
       le tre stelle del capitolo;
     · a fine tappa una schermata sola: il personaggio, «Tappa completata!», i tre riquadri
       (esperienza, serie, tempo) e «RICEVI XP»;
     · lo scrigno si apre toccandolo tre volte, e dentro non c'e' mai la stessa cosa.

   Quello che Duolingo fa con una lingua, qui si fa con il sogno: le tappe sono gli episodi
   della lettura del Genio (domande.js), le missioni del sogno (content/sentiero.json), le
   sessioni di Full Focus e il check settimanale. Il percorso e' lineare: si tocca il prossimo.
   =========================================================================================== */

const SD_KEY = 'fl_sd';
const SD = { fine: null, scrignoId: '', tocchi: 0, ripeti: null };
/* ---------- XP DOPPI (0.9.202): il premio della sfera a fine episodio ----------
   Per un quarto d'ora ogni tappa vale il doppio: e' il motivo per fare la tappa dopo ADESSO,
   non domani. Come il potenziamento XP di Duolingo. */
const SD_BOOST_MIN = 15, SD_BOOST_KEY = 'fl_sd_boost';
function sdBoostFino(){ try{ return +localStorage.getItem(SD_BOOST_KEY) || 0; }catch(_){ return 0; } }
function sdBoostResta(){ return Math.max(0, sdBoostFino() - Date.now()); }
function sdBoostDai(min, x){ try{ localStorage.setItem(SD_BOOST_KEY, String(Date.now() + (min || SD_BOOST_MIN) * 60000)); localStorage.setItem(SD_BOOST_KEY + '_x', String(x || 2)); }catch(_){ } }
function sdBoostX(){ if (!sdBoostResta()) return 1; try{ return Math.max(2, +localStorage.getItem(SD_BOOST_KEY + '_x') || 2); }catch(_){ return 2; } }
function sdBoostTxt(){ const ms = sdBoostResta(); if (!ms) return ''; const s = Math.ceil(ms / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function sdBoostNome(){ return sdBoostX() >= 3 ? 'XP tripli' : 'XP doppi'; }
function sdXpPer(tipo, base){ const x = base != null ? base : (SD_XP[tipo] || 0); return x * sdBoostX(); }
/* l'esperienza di oggi, per le missioni giornaliere */
function sdXpOggiAdd(n){ try{ if (typeof ftXpAggiungi === 'function') ftXpAggiungi(n); }catch(_){ } try{ const s = sdStato(); const k = sdK(Date.now()); if (!s.xpOggi || s.xpOggi.k !== k) s.xpOggi = { k: k, n: 0 }; s.xpOggi.n += n; sdSalva(s); }catch(_){ } }
function sdXpOggi(){ try{ const s = sdStato(); return (s.xpOggi && s.xpOggi.k === sdK(Date.now())) ? s.xpOggi.n : 0; }catch(_){ return 0; } }
/* ---------- RIPETERE UNA TAPPA (0.9.202): Leggendario, poi un ripasso, poi basta ----------
   Un episodio o un esercizio gia' fatti si possono rifare: la seconda volta e' il Leggendario
   (il nodo diventa d'oro, +25 XP), la terza un ripasso da 5 XP, poi la tappa e' chiusa. Come
   su Duolingo: rifare non vale quanto fare, e non si rifa' all'infinito. */
const SD_RIP_XP = [25, 5], SD_RIP_MAX = 2;
function sdRipetute(id){ const s = sdStato(); return (s.ripet || {})[id] || 0; }
function sdLeggendario(id, s){ return !!(((s || sdStato()).ripet || {})[id]); }
/* 0.9.306, Andrea: "il popup del piano su misura non mostra piu' gli XP". La causa: SD_XP non aveva i tipi di tappa nati
   dopo la 0.9.178 (piano, primo passo, stagione, Leggi il mio futuro, Io Futuro, chiamata, strada, pillole): per loro il
   valore era 0, il fumetto nascondeva "+XP" e la tappa fatta non dava niente. Adesso ogni tappa ha i suoi XP (la mystery
   box resta a 0: dalla 0.9.209 niente XP per aver aperto una scatola, ha i suoi premi). */
const SD_XP = { partenza: 20, ep: 15, mis: 20, ff: 25, ck: 15, fin: 50, sc: 0, es: 20, boss: 40, eser: 20, rx: 40, piano: 20, primo: 15, stg: 15, prev: 15, nf: 20, ic: 25, strada: 10, pill: 10 };

function sdStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(SD_KEY) || 'null'); }catch(_){ }
  if (!s) s = {};
  s.fatti = s.fatti || {}; s.unlockAt = s.unlockAt || {}; s.xp = s.xp || 0; s.visti = s.visti || {};
  return s;
}
function sdSalva(s){ try{ localStorage.setItem(SD_KEY, JSON.stringify(s)); }catch(_){ } }
function sdEsc(x){ return (typeof esc === 'function') ? esc(x) : String(x == null ? '' : x); }
function sdXp(){ return sdStato().xp || 0; }

/* ---------- i capitoli ---------- */
const SD_TITOLI = {
  1: ['Il Genio ti legge', 'I primi passi', 'La tua giornata', 'Il vecchio te'],
  2: ['La stagione 2', 'Le tue mattine', 'Cosa sai fare', 'Il giorno dell’arrivo'],
  3: ['Ogni settimana', 'La settimana']
};
function sdTitoloEp(n, fb){
  try{ const e = DQ_EPISODI.filter(function(x){ return x.n === n; })[0]; if (e && e.titolo) return e.titolo; }catch(_){ }
  return fb;
}
/* LA ROADMAP GRATIS FINO AL CAPITOLO 7 (0.9.207): la prima settimana con il Genio la fanno tutti;
   dal capitolo 8 le tappe le scrive l'agente, ed e' Premium. */
const SD_FREE_CAP = 7;
function sdPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
/* 0.9.310, Andrea: "il tuo agente personale" da solo sembra il procuratore di un calciatore. Chi e' Premium ha il suo
   agente personale (col nome che gli ha dato, se gliel'ha dato); chi non lo e' parla con il Genio. */
function sdChiPiano(){
  if (!sdPremium()) return 'Il Genio';
  try{ const i = (typeof agIdentita === 'function') ? agIdentita() : null; if (i && i.tipo === 'mio' && i.nome) return i.nome; }catch(_){ }
  return 'Il tuo agente personale';
}
function sdPremiumApri(){ try{ flVibra(12); }catch(_){ } if (typeof pwUpsellApri === 'function') pwUpsellApri(); else if (typeof go === 'function') go(11); }
/* 0.9.299: la chiamata con l'Io futuro e' Premium. Chi non ce l'ha la vede con il lucchetto e la strada va avanti:
   prima restava ferma li' per sempre (sdCorrente la dava come tappa in corso, e il tocco apriva solo Premium). */
function sdSaltata(nd){ return !!(nd && nd.tipo === 'ic' && !sdPremium()); }

/* ===========================================================================================
   IL VIAGGIO DELL'EROE E I PREMI (0.9.299)

   Andrea: "oggi l'ordine dei livelli e dei premi non ha una logica e manca lo storytelling: il percorso deve seguire
   il viaggio dell'eroe, e ogni capitolo racconta un pezzo di storia; i premi al punto giusto, con quello che il Brain
   dice sulla dopamina". Un capitolo per tappa del viaggio (un episodio per capitolo resta, regola della 0.9.201):
     1  il mondo ordinario e la chiamata: il Genio legge il sogno, la giornata di oggi, il primo passo;
     2  il rifiuto e il mentore: il Sabotatore invisibile, e SUBITO DOPO "Il tuo Io Futuro ti sta chiamando" (0.9.298);
     3  la soglia: l'effetto farfalla (la strada), il piano su misura, la prima sessione vera;
     4  le prove, gli alleati e i nemici: le due pillole, la prima missione;
     5  il nemico ha un nome: l'esercizio del blocco, la missione, l'interrogatorio;
     6  la caverna: "Leggi il mio futuro" (chi rischi di diventare), il bivio, l'Io futuro che richiama;
     7  la prova centrale e la ricompensa: il patto, il finale, una sessione, il premio della settimana;
     8  la strada del ritorno: il ripasso dei sette giorni, la stagione di spinta;
     9  gli alleati: le persone intorno, il pitch da 60 secondi;
    10-12 le prove del ritorno: cosa sai fare, soldi e tempo, corpo ed energia;
    13  la resurrezione: la voce dentro, l'ultimo bivio;
    14  il ritorno con l'elisir: il giorno dell'arrivo, il piano dell'anno.
   Gli episodi restano uno al giorno: le tappe di un giorno sono quelle fra un episodio e il successivo (3-5 al giorno).
   Per questo l'episodio non sta sempre in testa al capitolo. Gli id dei nodi sono quelli di prima: cambia solo il
   posto, le tappe fatte restano fatte (sdNodoFatto legge gli stessi id e gli stessi dati).

   LE REGOLE DEI PREMI (mystery box, gettoni, momenti "wow"), dal Company Brain:
   1. Il premio arriva DOPO una fatica, mai prima: la ricompensa prima toglie dopamina all'attivita' che segue.
      Fonte: areas/marketing/social-media/dopamina-e-attesa.md, meccanismo 3 (Huberman). Ogni mystery box sta subito
      dopo una sessione di Full Focus o una missione.
   2. Subito dopo il premio, un problema nuovo: dopo il Reward l'attenzione cala e va rigenerato un problema.
      Fonte: areas/video-editing/metodo-ariele-damici.md, par. 2 (ciclo Hook, Retain, Reward di Ariele d'Amici).
      Dopo una box viene una scelta, un esercizio o la caverna; il capitolo non finisce sempre sul premio.
   3. Rapporto variabile: una box ogni 7-11 tappe, mai alla stessa distanza, e non sempre nello stesso punto del
      capitolo. Fonte: dopamina-e-attesa.md, "Ricompense intermittenti" (~1 su 7, posizione del pagamento variabile).
      Nessuna box nel capitolo 1 (Andrea, 0.9.294) e non tutti i giorni: giorni 3, 5, 7, 10, 12, 14.
   4. Mai due picchi di fila: una box non sta accanto a un momento "wow" di contenuto (l'Io Futuro, il finale, la
      chiamata), perche' il picco scava la buca sotto la linea di base. Fonte: dopamina-e-attesa.md, meccanismo 1.
   5. Il jackpot vero e' il contenuto, non la scatola ("la stellina d'oro"; "il jackpot e' un contenuto migliore").
      Fonte: dopamina-e-attesa.md, meccanismo 4. I picchi alti sono l'Io Futuro (cap. 2), "Leggi il mio futuro"
      (cap. 6) e il finale (cap. 7); le box pagano la fatica che sta in mezzo.
   6. Il primo pagamento dimostra che l'anello si chiude ("primo micro-pagamento"). Fonte: dopamina-e-attesa.md,
      architettura. La prima box (cap. 3, dopo la prima sessione vera) da' sempre il gettone che congela la serie:
      protegge la serie proprio quando comincia la parte dura (SD_BOX_GARANZIA).
   7. La porta d'ingresso resta leggera: il primo giorno niente scelte pesanti e niente boss. Fonte:
      concepts/porta-d-ingresso.md ("le scelte pesanti arrivano solo quando l'utente e' gia' entrato"). L'effetto
      farfalla passa alla soglia (cap. 3), il Sabotatore al secondo giorno.
   8. Il premio prima del muro, non prima della fatica: la box della ricompensa (cap. 7) e' l'ultima prima dei capitoli
      Premium e regala un giorno di Premium a chi non ce l'ha (il premio leggendario a chi ce l'ha). Fonte:
      areas/comando/notion-todo.md, "errore di predizione della ricompensa": la rarita' pesa piu' del valore.
   =========================================================================================== */
/* 0.9.300, Andrea: "quella frase che compare sotto al nome del capitolo non la voglio: per me quello non e' storytelling".
   La storia sta negli episodi della serie del Genio (episodi.js, scheda Sogno); qui restano i titoli, uno per capitolo, e
   ogni titolo dice cosa c'e' da fare davvero. */
const SD_EROE = {
  1: { titolo: 'Il primo passo' },
  2: { titolo: 'La prima sessione vera' },
  3: { titolo: 'La prima missione' },
  4: { titolo: 'Il blocco da allenare' },
  5: { titolo: 'Le domande scomode' },
  6: { titolo: 'Il bivio' },
  7: { titolo: 'La settimana chiusa' },
  8: { titolo: 'La strada del ritorno' },
  9: { titolo: 'Gli alleati' },
  10: { titolo: 'Cosa sai fare' },
  11: { titolo: 'Soldi e tempo' },
  12: { titolo: 'Corpo ed energia' },
  13: { titolo: 'La voce dentro' },
  /* 0.9.301, Andrea: "La settimana 1 sta dopo Il giorno dell'arrivo". L'arrivo e' il sogno, in fondo a tutto: il capitolo
     14 chiude la seconda settimana con il piano dell'anno (l'esercizio "taglia" sull'anno), e si chiama cosi'. */
  14: { titolo: 'Il piano dell’anno' }
};
/* i testi dei capitoli si possono riscrivere da content/sentiero.json (chiave "capitoli"), come gli altri del Copywriter */
function sdCapInfo(cap){
  let c = null; try{ c = (typeof SN !== 'undefined' && SN.cfg && SN.cfg.capitoli) ? SN.cfg.capitoli[String(cap)] : null; }catch(_){ }
  return Object.assign({}, SD_EROE[cap] || {}, c || {});
}
function sdCapitoliBase(){
  const n = function(tipo, k, extra){ return Object.assign({ id: tipo + ':' + k, tipo: tipo }, extra || {}); };
  const C = function(sez, cap, nodi){ const i = sdCapInfo(cap); return { sez: sez, cap: cap, titolo: i.titolo || sdTitoloEp(cap, 'Capitolo ' + cap), nodi: nodi }; };
  /* il piano su misura c'e' solo per chi segue la strada del Genio (la strada si sceglie nell'episodio 5 della serie) */
  const piano = sdStradaMia() ? [] : [n('piano', 1, {})];
  /* 0.9.300, Andrea: "l'episodio e' una cosa, il livello un'altra: devono essere scollegati". La Roadmap ha solo tappe di
     vita reale. Gli episodi, il finale (la data), le pillole, l'effetto farfalla, il sabotatore invisibile e la chiamata
     dell'Io Futuro sono scene della serie del Genio (episodi.js). Gli id dei nodi restano quelli di prima: le tappe fatte
     restano fatte, l'XP e la serie non cambiano. Le regole dei premi sopra valgono ancora: la box dopo una fatica, mai
     nel capitolo 1, mai accanto a un momento "wow". */
  return [
    /* 0.9.337, Andrea: "la prima tappa della roadmap e' Taglia, non ha senso: deve essere Crea il tuo piano su misura". Il piano
       apre anche il bivio (pianifico io o seguo il Genio), se non e' ancora stato scelto. Gli id restano quelli di prima. */
    C(1, 1, piano.concat([n('es', 'taglia-c1', { es: 'taglia', arco: 'oggi' }), n('primo', 1, {})])),
    C(1, 2, [n('ff', 'c1', {}), n('sc', 'c1', {})]),
    C(1, 3, [n('mis', 1, { i: 1 }), n('es', 'riordina-c2', { es: 'riordina' })]),
    C(1, 4, [n('eser', 1, {}), n('mis', 2, { i: 2 }), n('sc', 'c2', {})]),
    C(1, 5, [n('es', 'inter-c2', { es: 'interrogatorio' }), n('prev', 'c2', {})]),
    C(1, 6, [n('es', 'bivio-c3', { es: 'bivio' }), n('ic', 'c5', {})]),
    C(1, 7, [n('ff', 'c2', {}), n('sc', 'c3', {})]),
    /* la radiografia non si rifa' dopo una settimana: ogni tre mesi, proposta dalla mappa (sdCapitoli, 0.9.278) */
    C(2, 8, [n('es', 'ripasso-c3', { es: 'ripasso' }), n('stg', 1, {}), n('es', 'taglia-abit-c4', { es: 'taglia', arco: 'abitudini' })]),
    C(2, 9, [n('mis', 3, { i: 3 }), n('es', 'pitch-c4', { es: 'pitch' }), n('ic', 'c9', {})]),
    C(2, 10, [n('ff', 'c3', {}), n('sc', 'c4', {}), n('es', 'taglia-sett-c3', { es: 'taglia', arco: 'settimana' })]),
    C(2, 11, [n('mis', 4, { i: 4 }), n('ff', 'c4', {}), n('es', 'riordina-c5', { es: 'riordina' }), n('es', 'taglia-mese-c4', { es: 'taglia', arco: 'mese' })]),
    C(2, 12, [n('ff', 'c5', {}), n('sc', 'c5', {}), n('es', 'inter-c5', { es: 'interrogatorio' })]),
    C(2, 13, [n('es', 'bivio-c6', { es: 'bivio' }), n('mis', 5, { i: 5 }), n('ic', 'c13', {})]),
    C(2, 14, [n('ff', 'c6', {}), n('sc', 'c6', {}), n('es', 'taglia-anno-c6', { es: 'taglia', arco: 'anno' })])
  ];
}
/* dopo la stagione 2 il sentiero continua ogni settimana: check, ripasso, missione, un esercizio che gira (taglia,
   interrogatorio, bivio), sessione, pitch, mystery box. 0.9.299: la box sta dopo una fatica (sessione o missione) e
   cambia posto di settimana in settimana (regole 1-3 dei premi); la chiamata non le sta mai accanto (regola 4). */
const SD_GIRO = [{ es: 'taglia', arco: 'oggi' }, { es: 'interrogatorio' }, { es: 'taglia', arco: 'abitudini' }, { es: 'riordina' }, { es: 'bivio' }, { es: 'taglia', arco: 'settimana' }];
function sdCapitoloSettimana(k){
  const n = function(tipo, key, extra){ return Object.assign({ id: tipo + ':' + key, tipo: tipo }, extra || {}); };
  const cap = 14 + k;
  const ck = n('ck', 'c' + cap, {}), rip = n('es', 'ripasso-c' + cap, { es: 'ripasso' }), mis = n('mis', 'w' + k + 'a', { i: (6 + (k - 1)) % 8 }),
    giro = n('es', 'giro-c' + cap, SD_GIRO[(k - 1) % SD_GIRO.length]), ff = n('ff', 'c' + cap, {}), pitch = n('es', 'pitch-c' + cap, { es: 'pitch' }), sc = n('sc', 'c' + cap, {});
  let nodi;
  if (k % 3 === 1) nodi = [ck, rip, mis, giro, ff, sc, pitch];
  else if (k % 3 === 2) nodi = [ck, mis, sc, rip, giro, ff, pitch];
  else nodi = [ck, rip, ff, sc, giro, mis, n('ic', 'w' + k, {}), pitch];
  /* 0.9.301: i capitoli 1-14 sono le prime due settimane (uno al giorno), quindi il capitolo 15 e' la TERZA settimana del
     viaggio. Prima si chiamava "La settimana 1" e sembrava ripartire da capo dopo il capitolo 14. L'ultimo capitolo della
     fase 4 e' il traguardo dei cinque anni: dopo c'e' solo il sogno. */
  /* 0.9.302: la Roadmap non dura piu' sempre cinque anni (sdDurata), e l'ultimo capitolo e' l'ultima settimana prima del sogno */
  const ultimo = cap === sdUltimoCap();
  return { sez: 3, cap: cap, titolo: ultimo ? 'L’ultima settimana prima del sogno' : SD_TITOLI[3][1] + ' ' + (k + 2), storia: '', nodi: nodi, ultimo: ultimo };
}
/* ---------- QUANTO DURA LA ROADMAP (0.9.302) ----------
   Andrea: "la Roadmap va dal punto in cui ti trovi a dove vuoi arrivare, nel tempo che l'utente ha scelto. Se e' un
   sogno piccolo non c'e' bisogno di una roadmap di 5 anni". Prima l'ultimo capitolo era sempre il 274 (cinque anni),
   anche per chi nel primo avvio aveva risposto "6 mesi" a "Entro quando vuoi arrivarci?" (gnDati().scadenza).
   La durata, in mesi, in quest'ordine:
     1. quella decisa con il tuo agente personale (Premium), applicata solo con il si' dell'utente (fl_sd_durata, da 'agente');
     2. quella scelta nel primo avvio ("Entro quando vuoi arrivarci?", 6 mesi, 1 anno, 2 anni);
     3. chi ha risposto "Non ho una data": la stima d'arrivo (ETA, p50) o, prima che ci sia, la lettura del Genio
        (gnLettura().mesi). La stima si fissa la prima volta e non si muove piu' da sola: la Roadmap non si accorcia e
        non si allunga ogni giorno alle spalle dell'utente (regola: mai ricalcolare senza il suo si').
   I capitoli restano quelli di sempre (1-14 uno al giorno, poi uno a settimana, con gli stessi id): cambia solo dove
   finisce la strada. Le fasi si ricavano dalla durata (sdFasi). */
const SD_DUR_KEY = 'fl_sd_durata', SD_SETT_MESE = 52.1775 / 12;
function sdDurata(){
  if (SD.durCache && Date.now() - SD.durCache.t < 1500) return SD.durCache.v;
  let v = null;
  let fissa = null; try{ fissa = JSON.parse(localStorage.getItem(SD_DUR_KEY) || 'null'); }catch(_){ }
  if (fissa && fissa.da === 'agente' && +fissa.mesi > 0) v = { mesi: +fissa.mesi, da: 'agente', at: fissa.at || 0 };
  if (!v){ try{ const d = (typeof gnDati === 'function') ? gnDati() : null; if (d && +d.scadenza > 0) v = { mesi: +d.scadenza, da: 'scelta' }; }catch(_){ } }
  if (!v && fissa && +fissa.mesi > 0) v = { mesi: +fissa.mesi, da: fissa.da || 'stima', at: fissa.at || 0 };
  if (!v){
    let mesi = 0, da = 'stima';
    try{
      const st = (typeof ETA !== 'undefined' && ETA.stato) || ((typeof etaLeggi === 'function') ? etaLeggi('stato', null) : null);
      const vg = (typeof etaViaggio === 'function') ? etaViaggio() : null;
      if (st && isFinite(st.p50) && vg && vg.inizio && !st.senzaPiano) mesi = Math.round((st.p50 - vg.inizio) / (30.4375 * 86400000));
    }catch(_){ }
    if (!(mesi > 0)){ try{ const L = (typeof gnLettura === 'function') ? gnLettura() : null; if (L && +L.mesi > 0){ mesi = +L.mesi; da = 'genio'; } }catch(_){ } }
    if (mesi > 0){
      v = { mesi: mesi, da: da };
      /* si fissa solo quando c'e' gia' un sogno letto: prima del primo avvio la lettura e' quella di serie */
      try{ const d = (typeof gnDati === 'function') ? gnDati() : null; if (d && d.at) localStorage.setItem(SD_DUR_KEY, JSON.stringify({ mesi: mesi, da: da, at: Date.now() })); }catch(_){ }
    }
  }
  if (!v) v = { mesi: 12, da: 'serie' };
  v.mesi = Math.max(1, Math.min(120, Math.round(v.mesi)));
  SD.durCache = { t: Date.now(), v: v };
  return v;
}
/** La durata detta a parole: "6 mesi", "un anno e 6 mesi", "4 anni". */
function sdDurataTxt(mesi){
  mesi = Math.round(mesi || 0);
  const a = Math.floor(mesi / 12), m = mesi % 12;
  const at = a ? (a === 1 ? 'un anno' : a + ' anni') : '', mt = m ? (m === 1 ? 'un mese' : m + ' mesi') : '';
  return at && mt ? at + ' e ' + mt : (at || mt || 'un mese');
}
/** La durata nuova, decisa con il tuo agente personale: si applica solo dal pulsante che l'utente tocca (sdDurataApplica). */
function sdDurataImposta(mesi, da){
  mesi = Math.max(1, Math.min(120, Math.round(+mesi || 0))); if (!mesi) return;
  try{ localStorage.setItem(SD_DUR_KEY, JSON.stringify({ mesi: mesi, da: da || 'agente', at: Date.now() })); }catch(_){ }
  SD.durCache = null; SD.fasiCache = null;
}
/* L'ULTIMO CAPITOLO DEL VIAGGIO: la settimana in cui cade la fine della durata. I capitoli 1-14 sono le prime due
   settimane, poi la settimana w (dalla terza in poi) e' il capitolo 12 + w. Mai prima di un capitolo con tappe gia'
   fatte: la strada fatta non sparisce mai dalla Roadmap. */
function sdUltimoCap(){
  if (SD.ultCache && Date.now() - SD.ultCache.t < 1500) return SD.ultCache.v;
  let u = 64;
  try{
    const sett = Math.max(4, Math.round(sdDurata().mesi * SD_SETT_MESE));
    u = 12 + sett;
    const s = sdStato(); let max = 0;
    Object.keys(s.fatti || {}).forEach(function(id){
      let m = /[-:]c(\d+)$/.exec(id), c = m ? +m[1] : 0;
      if (!m){ m = /:w(\d+)a?$/.exec(id); c = m ? 14 + +m[1] : 0; }
      if (c > max) max = c;
    });
    if (max > u) u = max;
  }catch(_){ }
  SD.ultCache = { t: Date.now(), v: u };
  return u;
}
/* LA RADIOGRAFIA OGNI TRE MESI (0.9.278): dalla prima fatta, ogni 90 giorni la mappa la ripropone come tappa del
   capitolo in corso. Mai prima: rifarla subito non dice niente, il paradigma si sposta in mesi. */
const SD_RX_GIORNI = 90;
function sdRxDovute(){
  let b = null; try{ b = (typeof bqLeggi === 'function') ? bqLeggi() : null; }catch(_){ }
  if (!b || !b.at) return [];
  let prima = b.at;
  try{ const st = JSON.parse(localStorage.getItem('fl_bq_storia') || '[]') || []; if (st.length && st[0].at) prima = st[0].at; }catch(_){ }
  const q = Math.floor((Date.now() - prima) / (SD_RX_GIORNI * 86400000));
  const out = []; for (let i = 1; i <= q; i++) out.push('t' + i);
  return out;
}
function sdCapitoli(){
  const base = sdCapitoliBase();
  /* quante settimane servono: fino al primo capitolo non finito. 0.9.301: fino all'ultimo capitolo del viaggio (prima si
     fermava alla settimana 60, e la strada finiva li'). I capitoli dopo quello in corso li disegna sdFuturoHtml. */
  let k = 1;
  const s = sdStato();
  while (14 + k <= sdUltimoCap()){
    const c = sdCapitoloSettimana(k);
    base.push(c);
    const fatti = c.nodi.every(function(nd){ return sdNodoFatto(nd, s); });
    if (!fatti) break;
    k++;
  }
  /* le radiografie dovute vanno nell'ultimo capitolo, quello in corso */
  try{
    const n = function(tipo, key, extra){ return Object.assign({ id: tipo + ':' + key, tipo: tipo }, extra || {}); };
    const ultimo = base[base.length - 1];
    sdRxDovute().forEach(function(q){ ultimo.nodi.push(n('rx', q, {})); });
  }catch(_){ }
  return base;
}
function sdTutti(){ return sdCapitoli().reduce(function(a, c){ return a.concat(c.nodi.map(function(nd){ nd.cap = c; return nd; })); }, []); }

/* ---------- lo stato di ogni nodo ---------- */
function sdNodoFatto(nd, s){
  s = s || sdStato();
  if (s.fatti[nd.id]) return true;
  try{
    if (nd.tipo === 'ep') return !!dqStato().fatti[nd.n];
    if (nd.tipo === 'fin') return !!dqStato().finale;
    if (nd.tipo === 'partenza') return !!(typeof ptzLeggi === 'function' && ptzLeggi());
    if (nd.tipo === 'boss') return !!(typeof bqLeggi === 'function' && bqLeggi() && bqLeggi().primario);
    if (nd.tipo === 'strada') return !!(typeof faStrada === 'function' && faStrada());
    /* fatta se le pillole sono state scelte; chi era gia' oltre il capitolo 3 prima della 0.9.280 non torna indietro */
    if (nd.tipo === 'pill') return !!((typeof faSevera === 'function' && faSevera()) || Object.keys((s && s.fatti) || {}).length >= 14);
    if (nd.tipo === 'eser') return !!(typeof bqLeggi === 'function' && bqLeggi() && bqLeggi().esercizio);
    if (nd.tipo === 'nf') return !!(typeof ifNuovoMe === 'function' && ifNuovoMe().partita);
    if (nd.tipo === 'rx'){ try{ return !!(JSON.parse(localStorage.getItem('fl_bq_ck') || '{}') || {})[nd.id]; }catch(_){ return false; } }
    /* la storia del futuro letta (fl_fu_visto) e la chiamata fatta (fl_ic_ultima) dopo che la tappa si e' aperta */
    if (nd.tipo === 'prev'){ try{ const t = +localStorage.getItem('fl_fu_visto') || 0; return t > 0 && t >= (s.unlockAt[nd.id] || 0); }catch(_){ return false; } }
    if (nd.tipo === 'ic'){ try{ const t = +localStorage.getItem('fl_ic_ultima') || 0; return t > 0 && t >= (s.unlockAt[nd.id] || 0); }catch(_){ return false; } }
    if (nd.tipo === 'mis' && sdMisRm()[nd.id]) return false;   /* missione della roadmap: fatta solo con "Fatta" o la sessione (s.fatti) */
    if (nd.tipo === 'mis'){ const m = snStato().missioni, ix = sdMisIndice(nd); return m.fatte.indexOf(ix) >= 0 && !!s.unlockAt[nd.id] && (m.fatteAt || {})[ix] >= s.unlockAt[nd.id]; }
    if (nd.tipo === 'primo'){ const p = sdPrimoLeggi(); return !!(p && p.fatto); }
    /* 0.9.290, Andrea: "ho completato il piano su misura e non mi ha dato punti, e il livello non e' mai finito". La tappa
       si segnava fatta appena partiva l'intervista (fl_piano_visto), mentre lui era ancora in chat: la festa e il livello
       dopo non li vedeva nessuno. Adesso e' fatta quando la roadmap e' APPLICATA (fl_piano_fatto), o saltata apposta. */
    if (nd.tipo === 'piano'){ try{ return !!localStorage.getItem('fl_piano_fatto') || !!localStorage.getItem('fl_piano_saltato') || (!!localStorage.getItem('fl_piano_visto') && !localStorage.getItem('fl_piano_avviato') && typeof rmlVuota === 'function' && !rmlVuota()); }catch(_){ return false; } }
    if (nd.tipo === 'stg'){ try{ return !!(localStorage.getItem('fl_stg_proposta') || (typeof flStagioneAttiva === 'function' && flStagioneAttiva()) || (JSON.parse(localStorage.getItem('fl_stagione_storia') || '[]') || []).length); }catch(_){ return false; } }
  }catch(_){ }
  return false;
}
function sdCorrente(){
  const s = sdStato();
  const tutti = sdTutti();
  for (let i = 0; i < tutti.length; i++){
    if (sdNodoFatto(tutti[i], s) || sdSaltata(tutti[i])) continue;
    if (!s.unlockAt[tutti[i].id]){ s.unlockAt[tutti[i].id] = Date.now(); sdSalva(s); }
    return { nodo: tutti[i], i: i, tutti: tutti };
  }
  return { nodo: null, i: tutti.length, tutti: tutti };
}
/* la sessione di Full Focus che vale il nodo: portata a termine dopo che il nodo e' arrivato */
function sdSessioneDopo(t0){
  let h = []; try{ h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ }
  return h.filter(function(x){ return x && x.ok && !x.meditazione && x.at >= (t0 || 0); }).sort(function(a, b){ return b.at - a.at; })[0] || null;
}
function sdCheckDopo(t0){
  try{ const f = dqStato().fatti; return Object.keys(f).some(function(k){ return k.indexOf('ck') === 0 && f[k] && f[k].at >= (t0 || 0); }); }catch(_){ return false; }
}
/* Si guarda cosa e' successo: il nodo in corso si chiude da solo se la cosa e' stata fatta
   (sessione, check, episodio), l'esperienza sale, e la schermata di fine tappa compare. */
/* RIPARA LE TAPPE CHIUSE DAL BUG (0.9.189): una sessione o un check segnati fatti senza che il
   nodo sia mai stato sbloccato. Tornano aperti e l'esperienza presa per loro si restituisce.
   Gira una volta sola. */
function sdRipara189(){
  const s = sdStato(); if (s.rip189) return;
  Object.keys(s.fatti).forEach(function(id){
    if ((id.indexOf('ff:') === 0 || id.indexOf('ck:') === 0) && !s.unlockAt[id]){
      delete s.fatti[id];
      if (s.visti[id]){ delete s.visti[id]; s.xp = Math.max(0, (s.xp || 0) - (SD_XP[id.split(':')[0]] || 0)); }
    }
  });
  s.rip189 = Date.now(); sdSalva(s);
}
/* 0.9.292: chi ha applicato il piano con la 0.9.290-291 (fl_piano_fatto) ma aveva la tappa "vista" da prima: il giorno
   in cui l'ha applicato conta per la serie. Una volta sola. */
function sdRiparaPiano292(){
  const s = sdStato(); if (s.ripPiano292) return;
  let t = 0; try{ t = +localStorage.getItem('fl_piano_fatto') || 0; }catch(_){ }
  if (t){
    sdTutti().forEach(function(nd){
      if (nd.tipo !== 'piano') return;
      if (!s.fatti[nd.id] || sdK(s.fatti[nd.id]) !== sdK(t)){ s.fatti[nd.id] = t; s.visti[nd.id] = s.visti[nd.id] || Date.now(); }
    });
  }
  s.ripPiano292 = Date.now(); sdSalva(s);
}
function sdAggiorna(mostra){
  setTimeout(function(){ try{ if (typeof rmpPaint === 'function') rmpPaint(); }catch(_){ } }, 50);
  try{ sdRipara189(); }catch(_){ }
  try{ sdRiparaPiano292(); }catch(_){ }
  try{ sdNuovoViaggioApplica(); }catch(_){ }
  const s = sdStato();
  const tutti = sdTutti();
  let nuovo = null;
  for (let i = 0; i < tutti.length; i++){
    const nd = tutti[i];
    if (s.visti[nd.id]) continue;
    const cur = sdCorrente();
    const corrente = !!(cur.nodo && cur.nodo.id === nd.id);
    /* L'ORA DI SBLOCCO SI RILEGGE (0.9.189). sdCorrente() la scrive su disco quando il nodo
       diventa quello in corso, ma `s` era stato letto prima: per il nodo appena arrivato
       valeva «nessuna», cioe' 0, cioe' «dall'inizio dei tempi». Una sessione di Full Focus
       di giorni prima chiudeva cosi' la tappa della sessione appena si finiva l'esercizio, e
       il sentiero correva da solo fino alla mystery box. E il salvataggio di `s` cancellava
       l'ora appena scritta. */
    Object.assign(s.unlockAt, sdStato().unlockAt);
    const t0 = s.unlockAt[nd.id] || Date.now();
    let fatto = false, dettaglio = null;
    if (nd.tipo === 'ff'){ if (corrente){ const x = sdSessioneDopo(t0); if (x){ fatto = true; dettaglio = { min: x.min }; } } }
    else if (nd.tipo === 'primo' && !sdNodoFatto(nd, s)){
      /* il primo passo si chiude con la sessione di Full Focus fatta su di lui (o con "Fatto") */
      const p = sdPrimoLeggi();
      if (corrente && p && p.t){ const x = sdSessioneDopo(Math.max(t0, p.at || 0)); if (x && (!x.intent || x.intent.slice(0, 30) === String(p.t).slice(0, 30) || p.mia)){ sdPrimoFatto(true); fatto = true; dettaglio = { min: x.min }; } }
    }
    else if (nd.tipo === 'ck'){ if (corrente) fatto = sdCheckDopo(t0); }
    else if (nd.tipo === 'sc'){ fatto = !!s.fatti[nd.id]; }
    else {
      fatto = sdNodoFatto(nd, s);
      if (fatto && nd.tipo === 'es'){ try{ dettaglio = esDettaglio(nd.id); }catch(_){ } }
      if (fatto && nd.tipo === 'ep'){ try{ const f = dqStato().fatti[nd.n]; if (f && f.sec) dettaglio = { sec: f.sec }; }catch(_){ } }
    }
    if (!fatto) continue;
    if (!s.fatti[nd.id]){ let quando = Date.now(); try{ if (nd.tipo === 'ep' && dqStato().fatti[nd.n] && dqStato().fatti[nd.n].at) quando = dqStato().fatti[nd.n].at; }catch(_){ } s.fatti[nd.id] = quando; }
    s.visti[nd.id] = Date.now();
    const guadagno = sdXpPer(nd.tipo);
    s.xp += guadagno;
    sdSalva(s);
    sdXpOggiAdd(guadagno);
    try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
    if (nd.tipo !== 'sc') nuovo = { nd: nd, det: Object.assign({}, dettaglio || {}, { xp: guadagno }) };
    try{ if (typeof rgmSegna === 'function') rgmSegna('tappa', sdNomeTappa(nd) || nd.tipo); }catch(_){ }
  }
  sdCorrente();   /* sblocca il prossimo (unlockAt) */
  try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  if (nuovo) sdWidget();
  if (nuovo && mostra !== false) sdFineApri(nuovo.nd, nuovo.det);
  /* 0.9.301: l'ultima tappa fatta apre il sogno. Se c'e' prima la fine della tappa, il livello finale arriva al prossimo
     ritorno sulla Mappa (sdAggiorna(true) di fl:tab); si apre da solo una volta, poi dal nodo del sogno. */
  else if (mostra !== false){
    try{ const s2 = sdStato(); if (!s2.sognoVisto && sdSognoRaggiunto()){ s2.sognoVisto = Date.now(); sdSalva(s2); sdFinaleApri(false); } }catch(_){ }
  }
}

/* ---------- il disegno ---------- */
const SD_ICO = { piano: '🗺️', stg: '🏔️', primo: '👣', partenza: '🧭', ep: '🔮', mis: '🎯', ff: '⏱️', ck: '📋', sc: '🎁', fin: '🏆', es: '⏳', boss: '🐉', eser: '✍️', rx: '🩻', prev: '🔭', ic: '📞', strada: '🦋', pill: '💊' };
const SD_NOMI = { piano: 'Il tuo piano su misura', stg: 'Sfida: la stagione di spinta', primo: 'Il tuo primo passo', partenza: 'Da dove parti?', ep: 'Le domande del Genio', mis: 'Missione', ff: 'Una sessione di Full Focus', ck: 'Il check della settimana', sc: 'Mystery box', fin: 'Il finale', es: 'Esercizio a tempo', boss: 'Il boss: il sabotatore invisibile', eser: 'L’esercizio del blocco', rx: 'Il sabotatore invisibile', prev: 'Leggi il mio futuro', nf: 'Il tuo Io Futuro ti sta chiamando', ic: 'Chiamata con l’Io futuro', strada: 'Effetto farfalla: la tua strada', pill: 'La scelta è tua: le due pillole' };
/* 0.9.275: le missioni che l'utente aveva gia' fatto prima di cominciare (le tocca nel "primo passo") non si
   ripropongono, e nemmeno quella scelta come primo passo: le tappe "missione" scorrono sulle altre. */
function sdMisGia(){ try{ const v = JSON.parse(localStorage.getItem('fl_mis_gia') || '[]'); return Array.isArray(v) ? v : []; }catch(_){ return []; } }
function sdPrimoLeggi(){ try{ return JSON.parse(localStorage.getItem('fl_primo_passo') || 'null'); }catch(_){ return null; } }
function sdMisIndice(nd){
  const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : [];
  if (!l.length) return nd.i;
  const via = sdMisGia().slice(); const p = sdPrimoLeggi(); if (p && p.idx != null) via.push(p.idx);
  const libere = l.map(function(_, i){ return i; }).filter(function(i){ return via.indexOf(i) < 0; });
  if (!libere.length) return nd.i % l.length;
  const k = Math.max(0, nd.i - 1);
  return libere[((k % libere.length) + libere.length) % libere.length];
}
/** Il nome di una tappa della mappa, come si legge sotto al suo cerchio. */
/* 0.9.280, Andrea: "la tappa si chiama Una sessione di Full Focus e apre il piano su misura: non ha senso".
   Quando la tappa di Full Focus porta a costruire la roadmap (autostrada scelta, roadmap ancora vuota), si
   chiama per quello che fa. */
/* 0.9.299, Andrea: "Il tuo piano su misura e subito dopo Crea il tuo piano su misura: sembra lo stesso livello". La tappa
   di Full Focus si travestiva da piano ogni volta che la roadmap era vuota, quindi anche PRIMA della tappa del piano, che
   le sta proprio sopra. Adesso il piano lo fa la sua tappa; la sessione dopo e' una sessione (sul primo passo della
   roadmap). Resta solo il caso vecchio: tappa del piano chiusa senza roadmap e senza averla saltata apposta. */
function sdFfPiano(nd){
  if (!nd || nd.tipo !== 'ff') return false;
  try{
    if (sdStradaMia() || localStorage.getItem('fl_piano_saltato') || sdRoadmapPassi().length) return false;
    if (!sdNodoFatto({ id: 'piano:1', tipo: 'piano' })) return false;
    const u = (typeof faStrada === 'function') ? faStrada() : null;
    return !!(u && u.scelta && u.scelta !== 'mia');
  }catch(_){ }
  return false;
}
function sdNomeTappa(nd){
  if (!nd) return '';
  if (sdFfPiano(nd)) return 'Finisci il tuo piano su misura';
  if (nd.tipo === 'ep') return 'Episodio ' + nd.n;
  if (nd.tipo === 'mis'){ const m = sdMissione(nd); if (m && m.t) return m.t.replace(/\s*\(\d+ min\)$/, ''); }
  if (nd.tipo === 'es'){ try{ const e = esNomeNodo(nd); if (e) return e; }catch(_){ } }
  return SD_NOMI[nd.tipo] || '';
}
/** Le tappe fatte oggi, dalla piu' recente. */
function sdFatteOggi(){
  const s = sdStato(); const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  return sdTutti().filter(function(nd){ const t = s.fatti[nd.id]; return t && t >= d0.getTime(); }).sort(function(a, b){ return s.fatti[b.id] - s.fatti[a.id]; });
}
function sdStradaMia(){ try{ const u = (typeof faStrada === 'function') ? faStrada() : null; return !!(u && u.scelta === 'mia'); }catch(_){ return false; } }
/* I passi della roadmap ancora da fare, dal piu' vicino (oggi) al piu' lontano: sono le missioni della mappa. */
function sdRoadmapPassi(){
  const out = [];
  try{
    ['oggi', 'settimana', 'mese', 'anno'].forEach(function(k){
      const a = (typeof ozAnello === 'function') ? ozAnello(k) : { passi: [] };
      (a.passi || []).forEach(function(p, j){
        if (!p || !p.t || p.fatto) return;
        const m = /\((\d+)\s*minut/i.exec(p.t);
        out.push({ t: sdAcc(String(p.t).replace(/\s*\(\d+\s*minut[^)]*\)\s*$/i, '')), s: k === 'oggi' ? 'Dalla tua roadmap: il passo di oggi.' : 'Dalla tua roadmap, per ' + ({ settimana: 'questa settimana', mese: 'questo mese', anno: 'quest’anno' }[k]) + '.', min: m ? Math.max(10, Math.min(120, +m[1])) : 30, k: k, j: j, rm: true });
      });
    });
  }catch(_){ }
  return out;
}
function sdAcc(t){ return typeof flAccenti === 'function' ? flAccenti(t) : String(t || ''); }
function sdMisRm(){ try{ return JSON.parse(localStorage.getItem('fl_mis_rm') || '{}') || {}; }catch(_){ return {}; } }
function sdMissione(nd){
  /* chi segue la strada del Genio e ha la roadmap: la missione e' il prossimo passo della SUA roadmap, legato al
     nodo la prima volta che compare (cosi' non cambia sotto agli occhi) */
  if (nd && nd.tipo === 'mis' && !sdStradaMia()){
    const mappa = sdMisRm();
    if (mappa[nd.id]){ const x = mappa[nd.id]; if (x && x.t) x.t = sdAcc(x.t); return x; }
    const presi = {}; Object.keys(mappa).forEach(function(k){ const x = mappa[k]; if (x) presi[x.k + ':' + x.j] = 1; });
    try{ const pp = sdPrimoLeggi(); if (pp && pp.rm) presi[pp.rm.k + ':' + pp.rm.j] = 1; }catch(_){ }
    const p = sdRoadmapPassi().filter(function(x){ return !presi[x.k + ':' + x.j]; })[0];
    if (p){ mappa[nd.id] = p; try{ localStorage.setItem('fl_mis_rm', JSON.stringify(mappa)); }catch(_){ } return p; }
  }
  const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : []; return l[sdMisIndice(nd) % Math.max(1, l.length)] || null;
}
function sdSerie(){ return sdSerieMappa(); }

/* ---------- LA SERIE DELLA MAPPA (0.9.181) ----------
   Un giorno conta se dentro c'e' almeno UNA tappa della mappa completata, di qualunque tipo:
   un episodio, un esercizio, una missione, una sessione. Non serve entrare in Full Focus per
   tenerla accesa: prima si costruisce l'abitudine di aprire l'app e fare un passo, poi il resto.
   E' il numero del widget e della schermata della serie. Il gettone salva-serie (comprato con
   le monete o trovato in uno scrigno) copre un giorno saltato: si usa da solo. */
const SD_META_GIORNO = 3;   /* tre tappe in un giorno: la giornata e' completa */
function sdK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function sdGiorniFatti(s){
  if (!s){ try{ sdRiparaPiano292(); }catch(_){ } }
  s = s || sdStato();
  const g = {};
  Object.keys(s.fatti || {}).forEach(function(id){ if (id.indexOf('sc:') === 0) return; const t = s.fatti[id]; if (t) g[sdK(t)] = (g[sdK(t)] || 0) + 1; });
  /* 0.9.301: i giorni dei viaggi conclusi (sdNuovoViaggioApplica): la serie non si spezza perche' si cambia sogno */
  Object.keys(s.giorniPrima || {}).forEach(function(k){ const v = +s.giorniPrima[k] || 0; if (v > 0) g[k] = (g[k] > 0 ? g[k] : 0) + v; });
  Object.keys(s.coperti || {}).forEach(function(k){ if (!g[k]) g[k] = -1; });
  return g;
}
function sdSerieMappa(){
  const g = sdGiorniFatti();
  const base = new Date(); base.setHours(12, 0, 0, 0);
  let n = 0;
  for (let i = 0; i < 800; i++){
    const k = sdK(base.getTime() - i * 86400000);
    if (g[k] > 0){ n++; continue; }
    if (g[k] === -1) continue;          /* coperto da un gettone: non conta, non spezza */
    if (i === 0) continue;              /* oggi non e' finito */
    break;
  }
  return n;
}
/* I giorni saltati fra l'ultima tappa e ieri: se i gettoni bastano, si coprono da soli. */
function sdCopriBuchi(){
  try{
    const s = sdStato(), g = sdGiorniFatti(s);
    const base = new Date(); base.setHours(12, 0, 0, 0);
    const buchi = [];
    for (let i = 1; i < 60; i++){
      const k = sdK(base.getTime() - i * 86400000);
      if (g[k]) break;
      buchi.push(k);
    }
    if (!buchi.length || buchi.length >= 59) return;
    const sn = snStato(); const hai = sn.serie.gettoni || 0;
    if (!hai || buchi.length > hai) return;
    s.coperti = s.coperti || {};
    buchi.forEach(function(k){ s.coperti[k] = Date.now(); });
    sn.serie.gettoni = hai - buchi.length; snSalva(sn);
    sdSalva(s);
    /* 0.9.260: al ritorno si propone di ricaricarle (premi-serie.js) */
    try{ if (typeof flGeloUsato === 'function') flGeloUsato(buchi.length); }catch(_){ }
  }catch(_){ }
}
function sdTappeOggi(){ const g = sdGiorniFatti(); return Math.max(0, g[sdK(Date.now())] || 0); }
/* La prossima tappa si puo' fare oggi? null se e' chiusa fino a domani (o piu'). */
function sdProssimaOggi(){
  const nd = sdCorrente().nodo; if (!nd) return null;
  try{
    if (nd.tipo === 'ep' && dqFattoOggi()) return null;
    if (nd.tipo === 'ck' && !snCheckDovuto()) return null;
    if (nd.tipo === 'es' && typeof esMancano === 'function' && esMancano(nd.es) > 0) return null;
  }catch(_){ }
  return nd;
}
function sdGiornoCompleto(){ return sdTappeOggi() >= SD_META_GIORNO || !sdProssimaOggi(); }
/* il widget sulla schermata iniziale conta questa serie */
function sdWidget(){ try{ if (typeof wgAggiorna === 'function') wgAggiorna(); }catch(_){ } }
function sdHtml(){
  const cur = sdCorrente();
  const caps = sdCapitoli();
  const s = sdStato();
  let pct = 0; try{ pct = dqConoscenza(); }catch(_){ }
  /* IL CAPITOLO IN CORSO SI CERCA PER NUMERO (0.9.189). cur.nodo.cap e' un oggetto di un'altra
     chiamata a sdCapitoli(): indexOf non lo trovava mai, dava -1, e la mappa mostrava sempre e
     solo il capitolo 1, anche con il sentiero gia' al 2 (l'episodio 3 non c'era). */
  let ci = cur.nodo ? caps.findIndex(function(c){ return c.cap === cur.nodo.cap.cap; }) : caps.length - 1;
  if (ci < 0) ci = caps.length - 1;
  const capCorrente = caps[ci];
  /* LA SERPENTINA (0.9.203): ogni capitolo parte dal lato opposto al Genio e fa la S, come su
     Duolingo; il Genio sta in alto, di fianco al primo nodo, e non copre niente */
  const OFF_DX = [-72, -34, 30, 72, 34, -30], OFF_SX = [72, 34, -30, -72, -34, 30];
  let html = '';
  const salto = sdSaltoPossibile();
  html += (sdBoostResta() ? '<div class="sd-boost"><span>⚡</span><b>' + sdBoostNome() + '</b><small>ancora <i id="sdBoostT">' + sdBoostTxt() + '</i></small></div>' : '')
    /* 0.9.273, Andrea: via gli XP ("non interessano a nessuno"). Primo numero: quanto del percorso e' fatto. Poi quanto
       il Genio ti conosce (sparisce a 100%: non c'e' piu' niente da scoprire), la serie e le monete. */
    + (function(){
        let tot = 0, fatti = 0;
        caps.forEach(function(c){ c.nodi.forEach(function(nd){ tot++; if (sdNodoFatto(nd, s)) fatti++; }); });
        const perc = tot ? Math.round(fatti / tot * 100) : 0;
        /* 0.9.281, Andrea: 17% qui e 39% nell'intestazione confondono. Il numero e' uno solo: quello dell'intestazione */
        let percH = perc; try{ if (typeof hdPercorso === 'function') percH = (typeof hdPctTxt === 'function') ? hdPctTxt(hdPercorso().pct) : Math.round(hdPercorso().pct * 100); }catch(_){ }
        return '<div class="sd-top"><span class="sd-pill" title="Il percorso fatto" onclick="if(typeof hdPercorsoApri===\'function\')hdPercorsoApri()" role="button">🧭 <b>' + percH + '%</b></span>'
          + (pct < 100 ? '<span class="sd-pill" title="Quanto ti conosce il Genio">🔮 <b>' + pct + '%</b></span>' : '')
          + '<span class="sd-pill' + ((typeof hdOggiFatto === 'function' && !hdOggiFatto()) ? ' spento' : '') + '" title="La serie" onclick="if(typeof hdSerieApri===\'function\')hdSerieApri()" role="button">🔥 <b>' + sdSerie() + '</b></span>'
          + '<button type="button" class="sd-pill" onclick="ngApri()" title="Le monete">🪙 <b>' + ((typeof ffCoins === 'function') ? ffCoins() : 0) + '</b></button></div>';
      })();
  /* 0.9.282, Andrea: la prossima mossa anche qui, sotto ai numeri e sopra al capitolo: Inizia porta dritti alla tappa */
  try{ if (!sdStradaMia() && typeof nvMossaHtml === 'function') html += '<div class="sd-mossa">' + nvMossaHtml() + '</div>'; }catch(_){ }
  /* la seconda chance dell'effetto farfalla: il Genio chiede se la strada scelta sta funzionando (farfalla.js) */
  try{ if (typeof faSecondaChanceHtml === 'function') html += faSecondaChanceHtml(); }catch(_){ }
  /* 0.9.281, Andrea: "quanti giorni di fila vuoi fare" non sta nella Mappa: si chiede dopo la schermata della serie (sdObChiedi) */
  /* 0.9.289, Andrea: il nome del capitolo va a capo, sotto a "Fase 1, capitolo 2" */
  html += '<div class="sd-testa" onclick="sdListaApri()" role="button"><div class="sd-testa-t"><small>Fase ' + sdFase(capCorrente.cap).n + ', capitolo ' + capCorrente.cap + '</small><b>' + sdEsc(capCorrente.titolo) + '</b></div><button type="button" class="sd-lista" onclick="event.stopPropagation();sdListaApri()" aria-label="Le fasi del viaggio"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button></div>';
  /* si mostrano il capitolo in corso, quello prima (chiuso, a memoria) e quello dopo (grigio) */
  /* 0.9.208: si scorre fino in fondo, come su Duolingo: tutti i capitoli, i futuri in grigio */
  const mostra = caps;
  const ctx = { cur: cur, s: s, capCorrente: capCorrente, salto: salto, OFF_DX: OFF_DX, OFF_SX: OFF_SX };
  mostra.forEach(function(c){ html += sdCapHtml(c, ctx); });
  /* 0.9.301, Andrea: "e la fase 3, la fase 4, perche' non compaiono? Il sogno realizzato compare in un punto a cazzo di
     cane". I capitoli settimanali si generano uno alla volta (sdCapitoli si ferma al primo non finito): la strada finiva
     al capitolo in corso e subito sotto c'era il sogno. Adesso dopo il capitolo in corso si vede tutto il resto del
     viaggio: il capitolo dopo, le fasi che mancano, l'ultimo capitolo e in fondo il sogno. 0.9.302: tutti i capitoli, uno per uno,
     fino all'ultimo della durata scelta (sdDurata), senza righe che li riassumono. */
  html += sdFuturoHtml(caps, ctx);
  html += sdSognoNodoHtml(caps, s);
  return '<div class="sd">' + html + '</div>';
}
/** Un capitolo del sentiero. ctx.futuro: un capitolo che ancora non esiste (sdFuturoHtml), tutto grigio e senza stato. */
function sdCapHtml(c, ctx){
  const s = ctx.s, cur = ctx.cur, capCorrente = ctx.capCorrente, futuro = !!ctx.futuro;
  let html = '';
  const fattiCap = futuro ? 0 : c.nodi.filter(function(nd){ return sdNodoFatto(nd, s); }).length;
  const stelle = Math.round(fattiCap / c.nodi.length * 3);
  const dopo = capCorrente && c.cap > capCorrente.cap;
  /* 0.9.302, Andrea: sotto all'ultimo capitolo la frase "Il traguardo che hai scritto per i prossimi cinque anni" non ci va */
  html += '<div class="sd-cap' + (c === capCorrente ? ' on' : '') + (futuro ? ' futuro' : '') + (c.ultimo ? ' ultimo' : '') + '" data-cap="' + c.cap + '" data-n="' + c.nodi.length + '">'
    + sdCapTestaHtml(c)
    + (dopo && ctx.salto && !futuro ? '<div class="sd-salto-w"><span class="sd-salto-fum">VUOI SALTARE FINO A QUI?</span><button type="button" class="sd-salto" onclick="sdSaltoApri(' + c.cap + ')" aria-label="Salta a questo capitolo">⏩</button></div>' : '')
    + '<div class="sd-genio ' + ((c.cap % 2) ? 'dx' : 'sx') + (fattiCap === c.nodi.length ? '' : ' chiuso') + '" onclick="' + (futuro ? 'sdFuturoTip(this, ' + c.cap + ', true)' : 'sdGenioSfida(' + c.cap + ', this)') + '" role="button"><img src="img/genio/' + (fattiCap === c.nodi.length ? 'genio-rivela' : (c === capCorrente ? 'genio-saluta' : 'genio-pensa')) + '.png" alt=""' + (futuro ? ' loading="lazy"' : '') + '><div class="sd-stelle">' + [0, 1, 2].map(function(j){ return '<i class="' + (j < stelle ? 'on' : '') + '">★</i>'; }).join('') + '</div></div>';
  const OFF = (c.cap % 2) ? ctx.OFF_DX : ctx.OFF_SX;
  c.nodi.forEach(function(nd, k){
    const fatto = !futuro && sdNodoFatto(nd, s);
    const corrente = !futuro && cur.nodo && cur.nodo.id === nd.id;
    const premiumBloccato = !sdPremium() && !fatto && (c.cap > SD_FREE_CAP || nd.tipo === 'ic');
    const off = OFF[k % OFF.length];
    let stato = premiumBloccato ? 'chiuso prem' : (fatto ? (sdLeggendario(nd.id, s) ? 'fatto legg' : 'fatto') : (corrente ? 'corrente' : 'chiuso'));
    let fumetto = '';
    if (corrente){
      let t = 'INIZIA';
      try{ if (nd.tipo === 'ep' && dqFattoOggi()) t = 'DOMANI'; if (nd.tipo === 'sc') t = 'APRI'; if (nd.tipo === 'ff') t = 'INIZIA'; if (nd.tipo === 'ic') t = 'CHIAMA'; if (nd.tipo === 'prev') t = 'LEGGI'; if (nd.tipo === 'nf') t = 'RISPONDI'; if (nd.tipo === 'strada') t = 'SCEGLI'; if (nd.tipo === 'ck' && !snCheckDovuto()) t = 'FRA ' + Math.max(1, sdGiorniAlCheck()) + ' GG'; if (nd.tipo === 'es' && esMancano(nd.es) > 0) t = 'FRA ' + esMancano(nd.es) + ' GG'; }catch(_){ }
      /* 0.9.295: il fumetto resta solo quando dice una cosa diversa da Inizia (domani, fra N giorni) */
      fumetto = (t === 'INIZIA' || t === 'APRI' || t === 'SCEGLI' || t === 'LEGGI' || t === 'CHIAMA') ? '' : '<span class="sd-fumetto">' + t + '</span>';
    }
    /* un capitolo futuro non lega le missioni ai passi della roadmap (sdMissione lo scrive su disco): si chiamano Missione */
    const mis = (nd.tipo === 'mis' && !futuro) ? sdMissione(nd) : null;
    let esN = '', esI = ''; if (nd.tipo === 'es'){ try{ esN = esNomeNodo(nd); esI = esIco(nd.es); }catch(_){ } }
    const eti = nd.tipo === 'ep' ? 'Episodio ' + nd.n : (mis ? mis.t.replace(/\s*\(\d+ min\)$/, '') : (esN || (!fatto && !futuro && sdFfPiano(nd) ? 'Finisci il tuo piano su misura' : SD_NOMI[nd.tipo])));
    if (!fatto && !futuro && sdFfPiano(nd)) esI = '🗺️';
    /* IL BIVIO DELL'EFFETTO FARFALLA (0.9.282, come in New Super Mario Bros. Wii): dalla tappa della scelta parte una
       seconda strada che esce dallo schermo. Non si sa dove porta: si vede solo che c'era. */
    /* 0.9.284, Andrea: "il bivio non si vede, e' tagliato e non sembra due strade separate: come nelle mappe di Super
       Mario, o come le venature delle ali della farfalla di Until Dawn". Una strada vera che dalla tappa si divide in
       due: quella scelta porta al nodo dopo e si accende (la venatura luminosa), l'altra curva dall'altra parte e
       svanisce nella nebbia prima del bordo. I tracciati li disegna sdBivioDisegna sulle posizioni vere dei nodi. */
    const bivio = nd.tipo === 'strada' ? '<span class="sd-bv' + (fatto ? ' preso' : '') + '" data-altra="' + ((OFF[(k + 1) % OFF.length] > off) ? 'sx' : 'dx') + '" aria-hidden="true"></span>' : '';
    const tocco = premiumBloccato ? 'sdPremiumApri()' : (futuro ? 'sdFuturoTip(this, ' + c.cap + ')' : 'sdTap(\'' + nd.id + '\')');
    html += '<div class="sd-riga' + (bivio ? ' con-bivio' : '') + '" style="--off:' + off + 'px">' + bivio + '<button type="button" class="sd-nodo ' + stato + ' t-' + nd.tipo + '"' + (futuro ? '' : ' data-id="' + nd.id + '"') + ' onclick="' + tocco + '" aria-label="' + sdEsc(eti) + '">' + (premiumBloccato ? '' : fumetto) + '<span class="sd-ico">' + (fatto && nd.tipo !== 'sc' ? (sdLeggendario(nd.id, s) ? '👑' : '✓') : (esI || SD_ICO[nd.tipo])) + '</span></button><small class="sd-eti">' + sdEsc(eti) + (!futuro && sdLeggendario(nd.id, s) ? ' · Leggendario' : '') + '</small></div>';
  });
  html += '</div>';
  return html;
}

/* ---------- IL RESTO DEL VIAGGIO (0.9.301, rifatto nella 0.9.302) ----------
   Dopo il capitolo in corso si vedono TUTTI i capitoli che mancano, uno per uno, fino all'ultimo, con la scheda di ogni
   fase dove la fase comincia. Sotto, il sogno. Andrea (0.9.302): "i capitoli devono comparire tutti, senza salti ne'
   riassunti": prima i capitoli in mezzo erano contati in una riga sola ("Ti aspettano altri 208 capitoli").
   Per non appesantire la Mappa (un sogno di quattro anni ha piu' di duecento capitoli): i primi capitoli dopo quello in
   corso si disegnano interi; gli altri si disegnano con il titolo e lo spazio delle loro tappe (sdCapLeggeroHtml), e le
   tappe entrano quando, scorrendo, ci si avvicina (sdLeggeriOsserva). Il titolo c'e' sempre, nessun capitolo e' nascosto. */
const SD_FASE_ARCO = { settimana: 'questa settimana', mese: 'questo mese', anno: 'quest’anno' };
const SD_VICINI = 3;
function sdFuturoHtml(caps, ctx){
  const ultimo = caps[caps.length - 1]; if (!ultimo) return '';
  const fine = sdUltimoCap();
  if (ultimo.cap >= fine) return '';
  const fctx = Object.assign({}, ctx, { futuro: true });
  SD.fctx = fctx;
  let faseN = sdFase(ultimo.cap).n, html = '';
  for (let cap = Math.max(15, ultimo.cap + 1); cap <= fine; cap++){
    const f = sdFase(cap);
    if (f.n !== faseN){ html += sdFaseCardHtml(f); faseN = f.n; }
    const c = sdCapitoloSettimana(cap - 14);
    html += (cap - ultimo.cap <= SD_VICINI) ? sdCapHtml(c, fctx) : sdCapLeggeroHtml(c);
  }
  return html;
}
/** Il titolo di un capitolo: "Fase 3, capitolo 40" e il nome. */
function sdCapTestaHtml(c){
  return '<div class="sd-div"><i></i><div><span>Fase ' + sdFase(c.cap).n + ', capitolo ' + c.cap + '</span><b>' + sdEsc(c.titolo) + '</b></div><i></i></div>';
}
/* l'altezza di un capitolo futuro con n tappe: misurata sui capitoli disegnati (sdLeggeriMisura), cosi' quando le tappe
   entrano la pagina non salta */
SD.hCap = SD.hCap || {};
function sdCapAltezza(n){ return SD.hCap[n] || (136 + n * 121); }
function sdCapLeggeroHtml(c){
  return '<div class="sd-cap futuro leggero' + (c.ultimo ? ' ultimo' : '') + '" data-cap="' + c.cap + '" data-n="' + c.nodi.length + '" style="height:' + sdCapAltezza(c.nodi.length) + 'px">'
    + sdCapTestaHtml(c) + '</div>';
}
function sdLeggeroRiempi(el){
  if (!el || !el.classList.contains('leggero') || !el.parentNode) return;
  try{ if (SD.io) SD.io.unobserve(el); }catch(_){ }
  const cap = +el.getAttribute('data-cap'); if (!(cap > 14) || !SD.fctx) return;
  const tmp = document.createElement('div');
  tmp.innerHTML = sdCapHtml(sdCapitoloSettimana(cap - 14), SD.fctx);
  const nuovo = tmp.firstElementChild; if (nuovo) el.parentNode.replaceChild(nuovo, el);
}
function sdLeggeriMisura(box){
  try{
    box.querySelectorAll('.sd-cap.futuro:not(.leggero)').forEach(function(c){ const n = +c.getAttribute('data-n'); if (n && c.offsetHeight && !SD.hCap[n]) SD.hCap[n] = c.offsetHeight; });
    box.querySelectorAll('.sd-cap.leggero').forEach(function(c){ const h = sdCapAltezza(+c.getAttribute('data-n')) + 'px'; if (c.style.height !== h) c.style.height = h; });
  }catch(_){ }
}
function sdLeggeriOsserva(){
  const box = document.getElementById('mppSentiero'); if (!box) return;
  try{ if (SD.io) SD.io.disconnect(); }catch(_){ }
  const leggeri = box.querySelectorAll('.sd-cap.leggero'); if (!leggeri.length) return;
  sdLeggeriMisura(box);
  if (typeof IntersectionObserver !== 'function'){
    /* senza IntersectionObserver si riempiono a pezzi, dopo il primo disegno */
    const tutti = Array.prototype.slice.call(leggeri); let i = 0;
    (function pezzo(){ tutti.slice(i, i + 8).forEach(sdLeggeroRiempi); i += 8; if (i < tutti.length) setTimeout(pezzo, 60); })();
    return;
  }
  let root = document.getElementById('tab-mappa');
  if (root && !root.contains(box)) root = null;
  /* si riempiono in coda, al massimo per 6 ms a fotogramma: scorrendo veloce non si blocca lo scroll */
  SD.coda = [];
  const giro = function(){
    SD.codaRaf = 0;
    const t0 = performance.now();
    while (SD.coda.length && performance.now() - t0 < 6) sdLeggeroRiempi(SD.coda.shift());
    if (SD.coda.length) SD.codaRaf = requestAnimationFrame(giro);
  };
  SD.io = new IntersectionObserver(function(es){
    es.forEach(function(e){ if (e.isIntersecting && SD.coda.indexOf(e.target) < 0) SD.coda.push(e.target); });
    /* prima quelli piu' vicini a quello che si vede */
    const r = root ? root.getBoundingClientRect() : { top: 0, bottom: window.innerHeight };
    const mid = (r.top + r.bottom) / 2;
    SD.coda.sort(function(a, b){ return Math.abs(a.getBoundingClientRect().top - mid) - Math.abs(b.getBoundingClientRect().top - mid); });
    if (SD.coda.length && !SD.codaRaf) SD.codaRaf = requestAnimationFrame(giro);
  }, { root: root, rootMargin: '2200px 0px 2200px 0px' });
  leggeri.forEach(function(el){ SD.io.observe(el); });
}
function sdFaseCardHtml(f){
  /* 0.9.302: il traguardo scritto si ricorda solo per gli orizzonti che l'utente ha davvero scritto (settimana, mese, anno);
     quello dei cinque anni non c'entra con una Roadmap che dura quanto ha scelto lui */
  let meta = '';
  try{ meta = SD_FASE_ARCO[f.oz] ? (((typeof ozAnello === 'function') ? ozAnello(f.oz) : {}).testo || '') : ''; }catch(_){ meta = ''; }
  const n = f.a - f.da + 1;
  const dura = f.da > 14 ? 'Dura ' + (n === 1 ? 'una settimana, un capitolo.' : n + ' settimane, un capitolo a settimana.') : 'Dura ' + n + (n === 1 ? ' capitolo.' : ' capitoli.');
  return '<div class="sd-fase-card" onclick="sdListaApri()" role="button"><small>Fase ' + f.n + '</small><b>' + sdEsc(f.nome) + '</b>'
    + '<p>' + dura + '</p>'
    + (meta ? '<p class="sd-fc-meta">Il traguardo che hai scritto per ' + SD_FASE_ARCO[f.oz] + ' è "' + sdEsc(meta) + '".</p>' : '')
    + '<em><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Si apre dopo la fase ' + (f.n - 1) + '.</em></div>';
}
/* il tocco su una tappa o sul Genio di un capitolo che ancora non c'e' */
function sdFuturoTip(el, cap, genio){
  const f = sdFase(cap);
  sdTip(el, '<b>' + (genio ? 'La sfida del Genio' : sdEsc(el.getAttribute('aria-label') || 'Questa tappa')) + '</b><p>Si apre più avanti nel viaggio, nella fase ' + f.n + ' (' + sdEsc(f.nome.toLowerCase()) + '), al capitolo ' + cap + '.</p>', true);
}

/* ---------- IL SOGNO REALIZZATO, IN FONDO A TUTTO (0.9.301) ----------
   Andrea: "un cerchio con un gradiente rosso-blu e una bandierina bianca fa cagare, non e' il vero gradiente del mio
   brand". Il nodo e' grigio e chiuso come tutti gli altri finche' le tappe non sono tutte fatte; poi prende il gradiente
   del pulsante "Crea il tuo bundle" del sito (fondo rosa e azzurro, bordo dal rosso al blu) e apre il livello finale. */
function sdSognoRaggiunto(caps){
  try{
    caps = caps || sdCapitoli();
    const u = caps[caps.length - 1]; if (!u || u.cap < sdUltimoCap()) return false;
    const s = sdStato();
    return caps.every(function(c){ return c.nodi.every(function(nd){ return sdNodoFatto(nd, s) || sdSaltata(nd); }); });
  }catch(_){ return false; }
}
function sdSognoAperto(caps){ return !!SD.anteprimaSogno || sdSognoRaggiunto(caps); }
/** Le tappe che mancano al sogno: quelle dei capitoli gia' sul sentiero e quelle dei capitoli che verranno. */
function sdTappeAlSogno(){
  try{
    const caps = sdCapitoli(), s = sdStato();
    let n = 0;
    caps.forEach(function(c){ c.nodi.forEach(function(nd){ if (!sdNodoFatto(nd, s) && !sdSaltata(nd)) n++; }); });
    for (let cap = caps[caps.length - 1].cap + 1; cap <= sdUltimoCap(); cap++) n += sdCapitoloSettimana(cap - 14).nodi.length;
    return n;
  }catch(_){ return 0; }
}
function sdSognoNodoHtml(caps){
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function' && nvSogno()) || ''; }catch(_){ }
  const aperto = sdSognoAperto(caps);
  return '<div class="sd-traguardo' + (aperto ? ' aperto' : '') + '"><button type="button" class="sd-sogno-n ' + (aperto ? 'aperto' : 'chiuso') + '" onclick="sdSognoTap(this)" aria-label="Il tuo sogno realizzato"><span class="sd-ico">🏁</span></button>'
    + '<b>Il tuo sogno realizzato</b>' + (sogno ? '<small>' + sdEsc(sogno) + '</small>' : '') + '</div>';
}
function sdSognoTap(el){
  if (sdSognoAperto()){ sdFinaleApri(!!SD.anteprimaSogno && !sdSognoRaggiunto()); return; }
  const n = sdTappeAlSogno();
  const admin = (typeof flAdmin === 'function') && flAdmin();
  sdTip(el, '<b>Il tuo sogno realizzato</b><p>Si apre quando hai fatto tutte le tappe della Roadmap. Te ne ' + (n === 1 ? 'manca una' : 'mancano ' + n) + '.</p>'
    + (admin ? '<button type="button" class="sd-tip-go" onclick="event.stopPropagation();sdTipChiudi();sdFinaleAnteprima()">Guarda l’anteprima del livello finale</button>' : ''), !admin);
}
function sdGiorniAlCheck(){
  try{
    const f = dqStato().fatti; let ultimo = dqStato().finale || 0;
    Object.keys(f).forEach(function(k){ if (f[k] && f[k].at > ultimo) ultimo = f[k].at; });
    return Math.ceil((ultimo + 6.5 * 86400000 - Date.now()) / 86400000);
  }catch(_){ return 7; }
}
/* 0.9.293, Andrea: "il pannello blu del capitolo resta troppo in basso, non tiene conto dell'interruttore sotto
   all'intestazione". L'altezza dell'intestazione si misurava una volta sola, mentre dentro c'era ancora l'interruttore
   (o un avviso): da li' in poi il pannello si fermava piu' giu'. Adesso si misura dove finisce DAVVERO l'intestazione
   rispetto alla scheda che scorre, ogni volta che si apre la Mappa e mentre si scorre. */
function sdTestaTop(){
  try{
    const t = document.querySelector('#s-home .home-head'), sc = document.getElementById('tab-mappa');
    if (!t || !t.offsetHeight || !sc || !sc.offsetHeight) return;
    const v = Math.max(0, Math.round(t.getBoundingClientRect().bottom - sc.getBoundingClientRect().top)) + 8;
    if (document.documentElement.style.getPropertyValue('--sd-testa-top') !== v + 'px') document.documentElement.style.setProperty('--sd-testa-top', v + 'px');
  }catch(_){ }
}
/* 0.9.294, Andrea: "scorrendo fino alla fase 2, capitolo 9, il pannello blu dice ancora Fase 1, capitolo 1". Come su
   Duolingo il pannello dice il capitolo che si sta guardando: l'ultimo il cui titolo e' gia' passato sotto al pannello. */
function sdTestaSegui(){
  try{
    const t = document.querySelector('#mppSentiero .sd-testa'); if (!t || !t.offsetParent) return;
    const fondo = t.getBoundingClientRect().bottom;
    let cap = null;
    /* 0.9.302: con tutti i capitoli fino al sogno (anche piu' di duecento) si cerca a meta': i capitoli sono in ordine */
    const tutti = document.querySelectorAll('#mppSentiero .sd-cap');
    let lo = 0, hi = tutti.length - 1;
    while (lo <= hi){ const m = (lo + hi) >> 1, d = tutti[m].querySelector('.sd-div') || tutti[m]; if (d.getBoundingClientRect().top <= fondo + 4){ cap = tutti[m]; lo = m + 1; } else hi = m - 1; }
    if (!cap) cap = document.querySelector('#mppSentiero .sd-cap.on') || document.querySelector('#mppSentiero .sd-cap');
    if (!cap) return;
    const sp = cap.querySelector('.sd-div span'), b = cap.querySelector('.sd-div b');
    const ts = t.querySelector('.sd-testa-t small'), tb = t.querySelector('.sd-testa-t b');
    if (sp && ts && ts.textContent !== sp.textContent) ts.textContent = sp.textContent;
    if (b && tb && tb.textContent !== b.textContent) tb.textContent = b.textContent;
    t.classList.toggle('futuro', !!cap.querySelector('.sd-nodo.chiuso') && !cap.querySelector('.sd-nodo.corrente, .sd-nodo.fatto'));
  }catch(_){ }
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') [60, 400, 1200].forEach(function(ms){ setTimeout(function(){ sdTestaTop(); sdTestaSegui(); }, ms); }); });
document.addEventListener('DOMContentLoaded', function(){
  const sc = document.getElementById('tab-mappa'); if (!sc) return;
  let q = 0; sc.addEventListener('scroll', function(){ if (q) return; q = requestAnimationFrame(function(){ q = 0; sdTestaTop(); sdTestaSegui(); }); }, { passive: true });
});
function sdMetti(el, html){
  if (!el) return false;
  if (!SD.forza && el.__sdHtml === html && el.firstChild) return false;
  SD.forza = false;
  el.innerHTML = html; el.__sdHtml = html;
  /* 0.9.302: i capitoli lontani entrano con le loro tappe quando ci si avvicina scorrendo (anche quando la Mappa la
     ridisegna mappa-tab.js, che chiama sdMetti direttamente) */
  if (el.id === 'mppSentiero'){ try{ sdLeggeriOsserva(); }catch(_){ } }
  return true;
}
function sdPaint(){
  const h = document.getElementById('mppSentiero'); if (!h) return;
  sdTestaTop();
  sdCopriBuchi();
  try{ sdAggiorna(false); }catch(_){ }
  /* 0.9.290, Andrea: "passando alla Mappa l'animazione si vede due volte, un lampo". La Mappa si ridisegnava da capo tre
     volte in mezzo secondo (mppPaint, poi qui a 120 ms): le immagini del Genio si ricaricavano e le animazioni
     ripartivano. Un disegno identico a quello che c'e' gia' non si rifa'. */
  if (!sdMetti(h, sdHtml())) return;
  try{ requestAnimationFrame(sdBivioDisegna); setTimeout(sdBivioDisegna, 400); }catch(_){ }
  clearInterval(SD.boostTick);
  if (sdBoostResta()) SD.boostTick = setInterval(function(){ const t = document.getElementById('sdBoostT'); if (!t || !sdBoostResta()){ clearInterval(SD.boostTick); if (t) sdPaint(); return; } t.textContent = sdBoostTxt(); }, 1000);
}

/* IL BIVIO, DISEGNATO SULLE POSIZIONI VERE. L'origine e' il centro della tappa della farfalla; la strada scelta arriva
   al centro della tappa dopo (che le sta sopra), l'altra parte verso il lato opposto e sfuma. Prima della scelta le due
   strade sono uguali (due possibilita'); dopo, quella presa si accende e l'altra si spegne. */
function sdBivioDisegna(){
  document.querySelectorAll('.sd-bv').forEach(function(el){
    const riga = el.closest('.sd-riga'); if (!riga) return;
    const nodo = riga.querySelector('.sd-nodo'); const dopo = riga.nextElementSibling && riga.nextElementSibling.querySelector('.sd-nodo');
    if (!nodo) return;
    const a = nodo.getBoundingClientRect(), r = riga.getBoundingClientRect();
    /* la Y parte da sotto l'etichetta della tappa: cosi' la biforcazione si vede intera */
    const eti = riga.querySelector('.sd-eti'); const e0 = eti ? eti.getBoundingClientRect().bottom : a.bottom;
    const cx = a.left + a.width / 2 - r.left, cy = e0 - r.top - 4;
    let dx = 0, dy = 110;
    if (dopo){ const b = dopo.getBoundingClientRect(); dx = (b.left + b.width / 2) - (a.left + a.width / 2); dy = (b.top + b.height / 2) - e0 + 4; }
    const altraSx = el.getAttribute('data-altra') === 'sx';
    const preso = el.classList.contains('preso');
    /* fino al bordo dello schermo dal lato dell'altra strada, meno un margine: la nebbia arriva prima del taglio */
    const lato = altraSx ? -(a.left + a.width / 2) + 14 : (window.innerWidth - (a.left + a.width / 2)) - 14;
    const W = 1200, H = Math.max(dy, 160) + 40, ox = W / 2, oy = 0;
    const p1 = 'M' + ox + ',' + oy + ' C' + ox + ',' + (oy + dy * 0.5) + ' ' + (ox + dx) + ',' + (oy + dy * 0.45) + ' ' + (ox + dx) + ',' + (oy + dy);
    const ex = ox + lato, ey = oy + Math.max(70, Math.min(dy, 120));
    const p2 = 'M' + ox + ',' + oy + ' C' + ox + ',' + (oy + 40) + ' ' + (ox + lato * 0.3) + ',' + (oy + 52) + ' ' + ex + ',' + ey;
    const id = 'sdBv' + Math.random().toString(36).slice(2, 7);
    const sfuma = '<linearGradient id="' + id + 'n" gradientUnits="userSpaceOnUse" x1="' + ox + '" y1="0" x2="' + ex + '" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="1"/><stop offset=".55" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
      + '<mask id="' + id + 'm" maskUnits="userSpaceOnUse" x="0" y="0" width="' + W + '" height="' + H + '"><rect x="0" y="0" width="' + W + '" height="' + H + '" fill="url(#' + id + 'n)"/></mask>'
      + '<linearGradient id="' + id + 'g" gradientUnits="userSpaceOnUse" x1="' + ox + '" y1="0" x2="' + (ox + dx) + '" y2="' + dy + '"><stop offset="0" stop-color="#FF8AC2"/><stop offset="1" stop-color="#5BC0F8"/></linearGradient>';
    const strada = function(d, cls, extra){ return '<g class="' + cls + '"' + (extra || '') + '><path class="bv-bordo" d="' + d + '"/><path class="bv-fondo" d="' + d + '"/><path class="bv-linea" d="' + d + '"/></g>'; };
    el.innerHTML = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" style="left:' + (cx - ox) + 'px;top:' + cy + 'px"><defs>' + sfuma + '</defs>'
      + strada(p2, 'bv-altra', ' mask="url(#' + id + 'm)"')
      + strada(p1, 'bv-mia')
      + (preso ? '<path class="bv-vena" d="' + p1 + '" stroke="url(#' + id + 'g)"/>' : '')
      + '<g class="bv-nebbia" mask="url(#' + id + 'm)"><text x="' + (ox + lato * 0.55) + '" y="' + (oy + 52) + '">?</text></g>'
      + '</svg>';
  });
}

/* ---------- il tocco ---------- */
/* la pozione messa da parte ieri si accende alla prima tappa di oggi */
function sdPozioneAccendi(){
  let da = 0; try{ da = +localStorage.getItem('fl_sd_pozione') || 0; }catch(_){ }
  if (!da || Date.now() < da) return;
  try{ localStorage.removeItem('fl_sd_pozione'); }catch(_){ }
  sdBoostDai(SD_BOOST_MIN, 3);
  try{ toast('Pozione XP tripli accesa: per 15 minuti ogni tappa vale il triplo'); flVibra([10, 40, 20]); }catch(_){ }
}
/* 0.9.295, Andrea: "come Duolingo: niente scritta INIZIA, il cerchio che pulsa intorno alla tappa; toccandola un fumetto
   con Inizia +XP, e sulle tappe chiuse Completa ancora N tappe per sbloccarla". */
function sdTip(el, html, scuro){
  sdTipChiudi();
  if (!el) return;
  /* 0.9.299, Andrea: "toccando un livello il fumetto compare SOTTO e spinge giu' tutto: si crea un buco fra Il tuo piano
     su misura e il livello dopo. Deve stare in overlay come Duolingo". Il fumetto era un figlio della riga della tappa,
     dentro il flusso: occupava spazio e allungava la riga. Adesso e' appeso alla mappa intera (.sd) in posizione
     assoluta, sopra a tutto il resto, sotto la tappa toccata con la freccia verso di lei: niente si sposta. */
  const host = el.closest('.sd') || document.getElementById('mppSentiero') || document.body;
  const t = document.createElement('div');
  t.className = 'sd-tip' + (scuro ? ' scuro' : '');
  t.innerHTML = html;
  t.addEventListener('click', function(e){ e.stopPropagation(); });
  host.appendChild(t);
  try{
    const n = el.getBoundingClientRect(), h = host.getBoundingClientRect(), r0 = t.getBoundingClientRect();
    /* dentro lo schermo con 8px di margine: il bordo che conta e' quello del primo contenitore che taglia */
    let c = host;
    while (c && c !== document.body && getComputedStyle(c).overflowX === 'visible') c = c.parentElement;
    const bx = (c && c !== document.body) ? c.getBoundingClientRect() : { left: 0, right: document.documentElement.clientWidth };
    const centro = n.left + n.width / 2;
    const sx = Math.max(bx.left + 8, Math.min(bx.right - 8 - r0.width, centro - r0.width / 2));
    t.style.left = Math.round(sx - h.left) + 'px';
    t.style.top = Math.round(n.bottom - h.top + 12) + 'px';
    t.style.setProperty('--fx', Math.round(Math.max(18, Math.min(r0.width - 18, centro - sx))) + 'px');
    /* se finisce sotto la barra in basso, la mappa scorre quanto basta per mostrarlo (scorrere non sposta le tappe) */
    requestAnimationFrame(function(){
      try{
        const r = t.getBoundingClientRect(), sc = document.getElementById('tab-mappa');
        const fondo = (window.innerHeight || document.documentElement.clientHeight) - 96;
        if (sc && r.bottom > fondo) sc.scrollBy({ top: Math.round(r.bottom - fondo), behavior: 'smooth' });
      }catch(_){ }
    });
  }catch(_){ }
  /* il tocco fuori chiude il fumetto; il listener si toglie sempre, cosi' il tocco su un'altra tappa non chiude il nuovo */
  setTimeout(function(){ document.addEventListener('click', sdTipFuori); }, 30);
  try{ flVibra(8); }catch(_){ }
}
/* cambiando scheda il fumetto si chiude */
document.addEventListener('fl:tab', function(){ try{ sdTipChiudi(); }catch(_){ } });
function sdTipFuori(e){ if (e && e.target && e.target.closest && e.target.closest('.sd-tip, .sd-nodo, .sd-genio')) return; sdTipChiudi(); }
function sdTipChiudi(){ document.removeEventListener('click', sdTipFuori); document.querySelectorAll('.sd-tip').forEach(function(x){ x.remove(); }); }
function sdTap(id){
  const cur = sdCorrente();
  const nd = cur.tutti.filter(function(x){ return x.id === id; })[0]; if (!nd) return;
  const el = document.querySelector('#mppSentiero .sd-nodo[data-id="' + id + '"]');
  const s = sdStato();
  if (sdNodoFatto(nd, s)){ sdTapVia(id); return; }
  const eti = el ? (el.getAttribute('aria-label') || '') : '';
  if (!cur.nodo || cur.nodo.id !== id){
    const i = cur.tutti.indexOf(nd), mancano = Math.max(1, i - cur.i);
    const xpC = nd.tipo === 'sc' ? 0 : sdXpPer(nd.tipo);
    sdTip(el, '<b>' + sdEsc(eti) + '</b>' + (xpC ? '<span class="sd-tip-xp">+' + xpC + ' XP</span>' : '') + '<p>Completa ancora ' + mancano + (mancano === 1 ? ' tappa' : ' tappe') + ' per sbloccare ' + (nd.tipo === 'sc' ? 'questa mystery box' : 'questa tappa') + '.</p>', true);
    return;
  }
  /* le sessioni e le missioni hanno gia' il loro foglio (sdTaskApri), con gli XP fra le pillole in alto */
  if (nd.tipo === 'ff' || nd.tipo === 'mis'){ sdTapVia(id); return; }
  const xp = nd.tipo === 'sc' ? 0 : sdXpPer(nd.tipo);
  sdTip(el, '<b>' + sdEsc(eti) + '</b><button type="button" class="sd-tip-go" onclick="event.stopPropagation();sdTipChiudi();sdTapVia(\'' + id + '\')">' + (nd.tipo === 'sc' ? 'Apri' : 'Inizia') + (xp ? ' +' + xp + ' XP' : '') + '</button>', false);
}
function sdTapVia(id){
  try{ sdPozioneAccendi(); }catch(_){ }
  const cur = sdCorrente();
  const nd = cur.tutti.filter(function(x){ return x.id === id; })[0]; if (!nd) return;
  const s = sdStato();
  if (sdNodoFatto(nd, s)){
    if (nd.tipo === 'fin'){ try{ dqFinaleApri(); }catch(_){ } return; }
    if (nd.tipo === 'partenza'){ try{ ptzApri(); }catch(_){ } return; }
    if (nd.tipo === 'primo'){ const p = sdPrimoLeggi(); toast(p && p.t ? 'Il tuo primo passo: ' + p.t : 'Tappa già fatta'); return; }
    /* 0.9.290, Andrea: "dopo averlo completato non da' la possibilita' di rifarlo, e toccandolo la scheda si ricarica" */
    if (nd.tipo === 'piano'){ sdPianoApri(true); return; }
    if (nd.tipo === 'stg'){ try{ stgApri(); }catch(_){ } return; }
    if (nd.tipo === 'sc'){ toast('Mystery box già aperta'); return; }
    if (nd.tipo === 'ep' || nd.tipo === 'es'){ sdRipetiSheet(nd); return; }
    if (nd.tipo === 'boss'){ try{ blocchiApri(true); }catch(_){ } return; }
    if (nd.tipo === 'eser'){ try{ bqEsercizioApri(); }catch(_){ } return; }
    if (nd.tipo === 'rx'){ try{ blocchiApri(false); }catch(_){ } return; }
    if (nd.tipo === 'prev'){ try{ scFutureStory(); }catch(_){ } return; }
    if (nd.tipo === 'nf'){ try{ nfApri(); }catch(_){ } return; }
    if (nd.tipo === 'ic'){ try{ if (!sdPremium()){ sdPremiumApri(); return; } icApri(); }catch(_){ } return; }
    /* la scelta non si ripresenta: si dice qual e', e dove si cambia */
    /* 0.9.282, Andrea: la scelta non si rimangia. Niente "si cambia da Impostazioni": come in Until Dawn, la strada e' quella */
    if (nd.tipo === 'strada'){ try{ const u = faStrada(); toast('Hai scelto "' + FA_NOMI[u.scelta] + '". Questa è la tua strada.'); }catch(_){ } return; }
    if (nd.tipo === 'pill'){ try{ faApriPillola(); }catch(_){ } return; }
    toast('Tappa già fatta'); return;
  }
  if (!cur.nodo || cur.nodo.id !== id){ toast('Prima finisci la tappa in corso'); try{ flVibra(12); }catch(_){ } return; }
  if (nd.tipo === 'partenza'){ try{ ptzApri(); }catch(_){ } return; }
  if (nd.tipo === 'primo'){ sdPrimoApri(); return; }
  if (nd.tipo === 'piano'){
    /* 0.9.337: prima il bivio, poi il piano. Chi sceglie "Pianifico io" vede la sua Mappa; chi segue il Genio fa il piano */
    if (typeof faStrada === 'function' && !faStrada() && typeof faApriStrada === 'function'){ faApriStrada(function(k){ if (k === 'rotta') sdPianoApri(); }); return; }
    sdPianoApri(); return;
  }
  /* la proposta e' la tappa: vista e decisa (accettata o rimandata), si chiude quando il foglio si chiude */
  if (nd.tipo === 'stg'){ try{ localStorage.setItem('fl_stg_proposta', String(Date.now())); STG.daMappa = true; stgApri(); }catch(_){ } return; }
  if (nd.tipo === 'ep'){ try{ if (dqFattoOggi()){ toast('Il prossimo episodio è domani: il Genio ha bisogno di una notte'); return; } dqApri(); }catch(_){ } return; }
  if (nd.tipo === 'ck'){ try{ if (!snCheckDovuto()){ toast('Il check si apre fra ' + Math.max(1, sdGiorniAlCheck()) + ' giorni'); return; } snCheckApri(); }catch(_){ } return; }
  if (nd.tipo === 'fin'){ try{ dqFinaleApri(); }catch(_){ } return; }
  if (nd.tipo === 'ff' || nd.tipo === 'mis'){ sdTaskApri(nd); return; }
  if (nd.tipo === 'es'){ try{ esApri(nd); }catch(_){ } return; }
  if (nd.tipo === 'sc'){ sdScrignoApri(nd.id); return; }
  if (nd.tipo === 'boss'){ try{ blocchiApri(true); }catch(_){ } return; }
  /* 0.9.300: il sabotatore invisibile adesso si smaschera nell'episodio 2 della serie; chi arriva qui prima lo fa adesso */
  if (nd.tipo === 'eser'){ try{ const b = bqLeggi(); if (!b || !b.primario){ blocchiApri(true); return; } bqEsercizioApri(); }catch(_){ } return; }
  if (nd.tipo === 'rx'){ try{ blocchiApri(false, nd.id); }catch(_){ } return; }
  if (nd.tipo === 'prev'){ try{ scFutureStory(); }catch(_){ } return; }
  if (nd.tipo === 'nf'){ try{ nfApri(); }catch(_){ } return; }
  if (nd.tipo === 'ic'){ try{ if (!sdPremium()){ sdPremiumApri(); return; } icApri(); }catch(_){ } return; }
  if (nd.tipo === 'strada'){ try{ faApriStrada(function(){ try{ sdAggiorna(true); }catch(_){ } }); }catch(_){ } return; }
  if (nd.tipo === 'pill'){ try{ const c = faPillolaCfg(); const poi = c.poi; c.poi = function(k){ try{ poi(k); }catch(_){ } try{ sdAggiorna(true); sdPaint(); }catch(_){ } }; faScena(c); }catch(_){ } return; }
}

/* ---------- IL GENIO LUNGO IL SENTIERO (0.9.208): una sfida che fa salire la fiducia ----------
   Toccando il Genio di un capitolo parte una sfida lampo: tre domande prese dalle risposte VERE
   date al Genio, una vita sola. Vinta = «boss battuto», XP e un punto di fiducia (fl_sd_fiducia).
   Non e' una stella fine a se stessa: e' la prova che quello che hai detto lo sai ancora. */
function sdGenioSfida(cap, el){
  /* 0.9.295, Andrea: "il Genio del capitolo si puo' sfidare subito: come su Duolingo resta oscurato finche' non hai fatto
     tutte le tappe del capitolo" */
  try{
    const c = sdCapitoli().filter(function(x){ return x.cap === cap; })[0], st = sdStato();
    const mancano = c ? c.nodi.filter(function(nd){ return !sdNodoFatto(nd, st) && !sdSaltata(nd); }).length : 0;
    if (mancano > 0){ sdTip(el, '<b>La sfida del Genio</b><p>Completa ancora ' + mancano + (mancano === 1 ? ' tappa' : ' tappe') + ' del capitolo per sbloccarla.</p>', true); return; }
  }catch(_){ }
  const d = (typeof sdEsameDomande === 'function') ? sdEsameDomande().slice(0, 3) : [];
  if (d.length < 3){ toast('Il Genio ti sfida dopo i primi episodi: deve conoscerti'); return; }
  let w = document.getElementById('sdSheet');
  if (!w){ w = document.createElement('div'); w.id = 'sdSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) sdMissioneChiudi(); }); document.body.appendChild(w); }
  const f = sdFiducia();
  w.innerHTML = '<div class="sd-sheet-in"><i class="pr-grab"></i><div class="sd-salto-art">🧞</div><h3>La sfida del Genio · capitolo ' + cap + '</h3><p>Tre domande su quello che gli hai raccontato, una vita sola. Se le passi, il boss del capitolo è battuto: +30 XP e un punto di fiducia' + (f ? ' (ne hai ' + f + ')' : '') + '.</p>'
    + '<button type="button" class="cta" onclick="sdGenioSfidaVia(' + cap + ')">Accetto la sfida</button><button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Non ora</button></div>';
  w.hidden = false;
}
function sdFiducia(){ try{ return +localStorage.getItem('fl_sd_fiducia') || 0; }catch(_){ return 0; } }
function sdGenioSfidaVia(cap){
  sdMissioneChiudi();
  const d = sdEsameDomande().slice(0, 3);
  SD.esame = { cap: cap, d: d, i: 0, vite: 1, giuste: 0, t0: Date.now(), sfida: true };
  goId('s-sd-esame'); sdEsamePaint();
}
/* ---------- SALTARE A UN CAPITOLO (0.9.203): il test ----------
   Come su Duolingo: chi e' gia' avanti non rifa' la strada, ma lo deve dimostrare. Solo Premium,
   e solo dopo la prima settimana con il Genio (deve conoscerti, prima). Il test: otto domande
   prese da quello che hai raccontato al Genio, tre vite. Prima versione: l'esame fatto dal tuo
   agente personale (domande sue, sul tuo obiettivo) arriva dopo. */
function sdSaltoPossibile(){
  try{ if (!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium())) return false; }catch(_){ return false; }
  /* 0.9.300: "dopo la prima settimana con il Genio" = la stagione 1 della serie vista (episodi.js) */
  try{ if (typeof epiStato === 'function'){ const v = epiStato().visti; for (let n = 1; n <= 7; n++) if (!v[n]) return false; return true; } }catch(_){ }
  try{ const f = dqStato().fatti; for (let n = 1; n <= 7; n++) if (!f[n]) return false; return true; }catch(_){ return false; }
}
function sdSaltoApri(cap){
  let w = document.getElementById('sdSheet');
  if (!w){ w = document.createElement('div'); w.id = 'sdSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) sdMissioneChiudi(); }); document.body.appendChild(w); }
  const c = sdCapitoli().filter(function(x){ return x.cap === cap; })[0];
  w.innerHTML = '<div class="sd-sheet-in"><i class="pr-grab"></i><div class="sd-salto-art">🏁</div><h3>Passa il test per saltare al capitolo ' + cap + '</h3><p>' + (c ? sdEsc(c.titolo) + '. ' : '') + 'Otto domande su quello che hai raccontato al Genio, tre vite. Se lo passi, le tappe in mezzo sono tue.</p>'
    + '<button type="button" class="cta" onclick="sdEsameVia(' + cap + ')">Comincia</button><button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Non ora</button></div>';
  w.hidden = false;
}
registerScreen('s-sd-esame', '<div class="sd-esame" id="sdEsame"></div>', { back: function(){ SD.esame = null; try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
function sdEsameDomande(){
  const out = [];
  try{
    DQ_EPISODI.forEach(function(ep){ if (typeof ep.n !== 'number' || ep.n > 7) return; (ep.domande || []).forEach(function(q){
      if ((q.tipo !== 'scelta' && q.tipo !== 'due') || !q.opz) return;
      const r = dqRisp(q.id); if (!r || r.v == null) return;
      const opz = q.opz.map(function(o){ return o[1]; }); if (opz.indexOf(r.v) < 0) return;
      out.push({ t: String(q.t).replace(/\*/g, ''), opz: opz, ok: r.v });
    }); });
  }catch(_){ }
  for (let i = out.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); const t = out[i]; out[i] = out[j]; out[j] = t; }
  return out.slice(0, 8);
}
function sdEsameVia(cap){
  sdMissioneChiudi();
  const d = sdEsameDomande();
  if (d.length < 4){ toast('Il Genio ti conosce ancora poco per un test'); return; }
  SD.esame = { cap: cap, d: d, i: 0, vite: 3, giuste: 0, t0: Date.now() };
  goId('s-sd-esame'); sdEsamePaint();
}
function sdEsamePaint(){
  const e = SD.esame, h = document.getElementById('sdEsame'); if (!e || !h) return;
  const q = e.d[e.i];
  const cuori = [0, 1, 2].map(function(i){ return '<i class="' + (i < e.vite ? 'on' : '') + '">❤</i>'; }).join('');
  h.innerHTML = '<div class="sd-es-top"><button type="button" class="sd-es-x" onclick="if(typeof sdEsameX===\'function\')sdEsameX();else sdEsameEsci()">✕</button><div class="sd-es-bar"><i style="width:' + Math.round(e.i / e.d.length * 100) + '%"></i></div><div class="sd-es-vite">' + cuori + '</div></div>'
    + '<small class="sd-es-eti">Domanda ' + (e.i + 1) + ' di ' + e.d.length + '</small><h2 class="sd-es-q">' + sdEsc(q.t) + '</h2><p class="sd-es-sotto">Cos’hai risposto al Genio?</p>'
    + '<div class="sd-es-opz">' + q.opz.map(function(o, i){ return '<button type="button" onclick="sdEsameRisp(' + i + ')">' + sdEsc(o) + '</button>'; }).join('') + '</div>';
}
function sdEsameRisp(i){
  const e = SD.esame; if (!e) return; const q = e.d[e.i];
  const giusta = q.opz[i] === q.ok;
  const b = document.querySelectorAll('#sdEsame .sd-es-opz button')[i]; if (b) b.classList.add(giusta ? 'ok' : 'ko');
  try{ flVibra(giusta ? 18 : [40, 30, 40]); if (typeof gnAu !== 'undefined') gnAu.scelta(giusta ? 3 : 0); }catch(_){ }
  if (giusta) e.giuste++; else e.vite--;
  setTimeout(function(){
    if (e.vite <= 0){ sdEsameFine(false); return; }
    e.i++;
    if (e.i >= e.d.length) sdEsameFine(true); else sdEsamePaint();
  }, 520);
}
function sdEsameEsci(){ SD.esame = null; goId('s-home'); try{ switchTab('mappa'); }catch(_){ } }
function sdEsameFine(passato){
  if (SD.esame && SD.esame.sfida){
    const cap = SD.esame.cap; SD.esame = null;
    if (passato){
      try{ const s = sdStato(); s.xp += 30; sdSalva(s); if (typeof sdXpOggiAdd === 'function') sdXpOggiAdd(30); localStorage.setItem('fl_sd_fiducia', String(sdFiducia() + 1)); localStorage.setItem('fl_sd_boss_' + cap, String(Date.now())); }catch(_){ }
      try{ flVibra([30, 40, 90]); if (typeof lvBump === 'function') lvBump(); }catch(_){ }
      const h = document.getElementById('sdEsame'); if (h) h.innerHTML = '<div class="sd-es-fine"><span>🏆</span><h2>Boss battuto</h2><p>Quello che hai detto al Genio lo sai ancora. Fiducia: <b>' + sdFiducia() + '</b> · +30 XP.</p><button type="button" class="cta" onclick="sdEsameEsci()">Torna alla mappa</button></div>';
    } else {
      const h = document.getElementById('sdEsame'); if (h) h.innerHTML = '<div class="sd-es-fine"><span>😮‍💨</span><h2>Non oggi</h2><p>Il Genio ti rifà la sfida quando vuoi: le risposte vere sono nei tuoi episodi.</p><button type="button" class="cta" onclick="sdEsameEsci()">Torna alla mappa</button></div>';
    }
    return;
  }
  const e = SD.esame; SD.esame = null; if (!e) return;
  if (passato){
    const s = sdStato(); let saltate = 0;
    sdTutti().forEach(function(nd){ if (nd.cap.cap < e.cap && !sdNodoFatto(nd, s)){ s.fatti[nd.id] = Date.now(); s.visti[nd.id] = Date.now(); saltate++; } });
    s.salti = s.salti || []; s.salti.push({ cap: e.cap, at: Date.now(), saltate: saltate });
    sdSalva(s);
    try{ flVibra([30, 40, 30, 40, 90]); }catch(_){ }
    goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
    setTimeout(function(){ sdPaint(); toast('Test passato: sei al capitolo ' + e.cap); }, 300);
  } else {
    const h = document.getElementById('sdEsame'); if (!h) return;
    h.innerHTML = '<div class="sd-es-fine"><span>💔</span><h2>Vite finite</h2><p>La strada la fai tappa per tappa, come tutti. Riprova fra qualche giorno.</p><button type="button" class="cta" onclick="sdEsameEsci()">Torna alla mappa</button></div>';
  }
}

/* ---------- rifare una tappa: il foglio ---------- */
function sdRipetiSheet(nd){
  const n = sdRipetute(nd.id);
  let eti = ''; try{ eti = nd.tipo === 'ep' ? 'Episodio ' + nd.n : esNomeNodo(nd); }catch(_){ eti = SD_NOMI[nd.tipo]; }
  let w = document.getElementById('sdSheet');
  if (!w){ w = document.createElement('div'); w.id = 'sdSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) sdMissioneChiudi(); }); document.body.appendChild(w); }
  const boost = sdBoostResta() ? ' <em class="sd-x2">×2</em>' : '';
  let corpo;
  if (n === 0) corpo = '<small>Tappa fatta</small><h3>' + sdEsc(eti) + '</h3><p>Rifalla da leggenda: alza la posta e il nodo diventa d’oro.</p>'
    + '<button type="button" class="cta sd-legg-cta" onclick="sdRipetiVia(\'' + nd.id + '\')">👑 Leggendario +' + sdXpPer(null, SD_RIP_XP[0]) + ' XP' + boost + '</button>';
  else if (n < SD_RIP_MAX) corpo = '<small>Leggendario</small><h3>' + sdEsc(eti) + '</h3><p>Un ripasso vale meno di una tappa nuova, ma vale.</p>'
    + '<button type="button" class="cta" onclick="sdRipetiVia(\'' + nd.id + '\')">Ripassa +' + sdXpPer(null, SD_RIP_XP[1]) + ' XP' + boost + '</button>';
  else corpo = '<small>Leggendario</small><h3>' + sdEsc(eti) + '</h3><p>Fatta tre volte: questa tappa è tua. Il resto della strada ti aspetta.</p>';
  w.innerHTML = '<div class="sd-sheet-in' + (n ? ' legg' : '') + '"><i class="pr-grab"></i>' + corpo + '<button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">' + (n >= SD_RIP_MAX ? 'Chiudi' : 'Non ora') + '</button></div>';
  w.hidden = false;
}
function sdRipetiVia(id){
  const nd = sdNodo(id); if (!nd) return;
  sdMissioneChiudi();
  SD.ripeti = { id: id, n: sdRipetute(id) + 1 };
  if (nd.tipo === 'ep'){ try{ if (typeof dqApriEp === 'function') dqApriEp(nd.n, true); }catch(_){ } return; }
  if (nd.tipo === 'es'){ try{ esApri(nd); }catch(_){ } }
}
/* La fine di una ripetizione: l'esperienza ridotta, il nodo d'oro, la schermata di fine. */
function sdRipetiFine(id, det){
  const r = SD.ripeti; SD.ripeti = null;
  if (!r || r.id !== id) return false;
  const nd = sdNodo(id); if (!nd) return false;
  const s = sdStato(); s.ripet = s.ripet || {}; s.ripet[id] = Math.min(SD_RIP_MAX, r.n);
  const xp = sdXpPer(null, SD_RIP_XP[Math.min(SD_RIP_XP.length - 1, r.n - 1)]);
  s.xp += xp; sdSalva(s);
  sdXpOggiAdd(xp);
  try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  const d = Object.assign({}, det || {}, { xp: xp, ripeti: true, titolo: r.n === 1 ? 'Leggendario!' : 'Ripasso fatto!', sotto: r.n === 1 ? 'Hai alzato la posta, e l’hai presa. Il nodo è d’oro.' : 'Rifare una strada già fatta: è così che la memoria la tiene.' });
  sdFineApri(nd, d);
  return true;
}

/* ---------- LA TAPPA DI FULL FOCUS (0.9.210): il foglio della task, come il punto sulla mappa ----------
   Prima la tappa portava dritta dentro al Full Focus. Adesso si apre il foglio: il 📍 grande,
   la task con la sua descrizione, la priorita' e il tempo previsto, due aiuti del tuo agente personale
   (scomporla in passi, trovare un tutorial) e il pulsante con il tempo scritto sopra. */
/* 0.9.290, Andrea: "tutti i popover hanno la X per chiudersi, il velo scuro dietro, e si chiudono toccando fuori" */
const SD_X = '<button type="button" class="sd-x" aria-label="Chiudi" onclick="sdMissioneChiudi()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
function sdSheetW(){
  let w = document.getElementById('sdSheet');
  if (!w){ w = document.createElement('div'); w.id = 'sdSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) sdMissioneChiudi(); }); document.body.appendChild(w); }
  return w;
}
function sdTaskDati(nd){
  const day = (typeof stDayKey === 'function') ? stDayKey('today') : '';
  if (nd.tipo === 'mis'){
    const m = sdMissione(nd); if (!m) return null;
    return { t: m.t.replace(/\s*\(\d+ min\)$/, ''), s: m.s || '', min: m.min || 15, pri: 'media', mis: true, day: day };
  }
  let t = '', pri = 'alta', s = '';
  try{ const one = stOne(); if (one && !one.done && one.task) t = String(one.task.text || one.task.t || one.task).trim(); }catch(_){ }
  if (t) s = 'È la priorità di oggi, dal tuo foglio. Una sessione di Full Focus la porta a termine e chiude la tappa.';
  /* 0.9.279, Andrea: "il primo passo verso il mio sogno, 10 minuti, telefono chiuso: che cazzo di task e'?". Chi ha
     la roadmap fa il suo prossimo passo, scritto per lui; la riga generica del foglio viene dopo. */
  let minRm = 0;
  if (!t && !sdStradaMia()){ try{ const r = sdRoadmapPassi()[0]; if (r){ t = r.t; s = r.s; pri = 'alta'; minRm = r.min || 0; } }catch(_){ } }
  if (!t){ try{ const r = stRigheDi(day).filter(function(x){ return x && !stIsDone(x, day); }); if (r.length){ t = String(r[0]).trim(); pri = 'media'; s = 'È la prima cosa ancora aperta nel tuo foglio di oggi. Una sessione di Full Focus la porta a termine e chiude la tappa.'; } }catch(_){ } }
  if (!t){ t = 'Una sessione sulla cosa più importante di oggi'; pri = 'alta'; s = 'Il foglio di oggi è vuoto: scegli la cosa nel foglio di START, oppure parti e decidila nei primi due minuti.'; }
  let min = 25, passi = [];
  /* 0.9.290, Andrea: "in START la stessa cosa dura 60 minuti, nella Mappa 10". La Mappa prendeva i minuti dell'ultima
     sessione; adesso vale quello che dice il passo della roadmap ("(60 minuti)"), come in START. */
  try{ const m = stMeta(t, day); if (m && m.stima) min = +m.stima || min; else if (minRm) min = minRm; else { const p = ffPref(); if (p && p.minutes >= 10) min = p.minutes; } if (m && m.micro) passi = m.micro.filter(Boolean); }catch(_){ }
  return { t: t, s: s, min: min, pri: pri, passi: passi, day: day };
}
function sdTaskApri(nd){
  /* chi ha scelto l'autostrada (la strada del Genio) e non ha ancora la roadmap: prima si costruisce quella,
     con il suo agente. Una sessione di Full Focus su un passo che nessuno ha scritto non porta da nessuna parte. */
  try{
    const u = (typeof faStrada === 'function') ? faStrada() : null;
    if (sdFfPiano(nd) && typeof sdPianoApri === 'function'){ sdPianoApri(); return; }
  }catch(_){ }
  const d = sdTaskDati(nd); if (!d){ toast('Il catalogo delle missioni sta arrivando'); return; }
  /* la vecchia riga del primo giorno (fino alla 0.9.278) era un passo senza contenuto: diventa la roadmap */
  if (/primo passo verso il mio sogno|costruire la mia roadmap/i.test(d.t) && typeof sdPianoApri === 'function'){ sdPianoApri(); return; }
  SD.task = { id: nd.id, tipo: nd.tipo, t: d.t, min: d.min, day: d.day };
  const pri = d.pri === 'alta' ? ['alta', 'Priorità alta'] : (d.pri === 'bassa' ? ['bassa', 'Priorità bassa'] : ['media', 'Priorità media']);
  const w = sdSheetW();
  /* 0.9.290, Andrea: "il punteruolo attaccato al testo, la frase attaccata alle etichette, tutto ammassato; e in START la
     stessa cosa ha la mano che scrive". La stessa immagine della riga in START, e le distanze delle regole. */
  let em = { ico: '🎯', bg: '#0075E3,#001E44' }; try{ if (typeof stEmojiDi === 'function') em = stEmojiDi(d.t) || em; }catch(_){ }
  w.innerHTML = '<div class="sd-sheet-in sd-task">' + SD_X + '<i class="pr-grab"></i><div class="sd-task-img" style="background:linear-gradient(160deg,' + em.bg + ')">' + em.ico + '</div>'
    + '<h3>' + sdEsc(sdAcc(d.t)) + '</h3>' + (d.s ? '<p>' + sdEsc(d.s) + '</p>' : '')
    + '<div class="sd-task-badge"><span class="pri ' + pri[0] + '">' + pri[1] + '</span><span>⏱ ' + d.min + ' minuti</span>' + (sdXpPer(nd.tipo) ? '<span class="xp">+' + sdXpPer(nd.tipo) + ' XP</span>' : '') + '</div>'
    + (d.passi && d.passi.length ? '<div class="sd-task-passi"><small>I passi</small><ol>' + d.passi.slice(0, 6).map(function(p){ return '<li>' + sdEsc(p) + '</li>'; }).join('') + '</ol></div>' : '')
    + '<div class="sd-task-due"><button type="button" onclick="sdTaskScomponi()"><span>🪜</span>Scomponi in passi</button><button type="button" onclick="sdTaskTutorial()"><span>🎬</span>Cerca un tutorial</button></div>'
    + '<button type="button" class="cta sd-task-go" onclick="sdTaskVia()">INIZIA • ' + d.min + ' min<span class="chev"></span></button>'
    + (d.mis ? '<button type="button" class="sd-btn-sec" onclick="sdMissioneFatta(\'' + nd.id + '\')">' + sdEsc((typeof snT === 'function') ? snT('missione_fatta_btn') : 'Fatta') + '</button>' : '')
    + '<button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Non ora</button></div>';
  w.hidden = false;
}
function sdTaskScomponi(){
  const k = SD.task; if (!k) return;
  if (typeof stScompChiedi === 'function' && stScompChiedi(k.t, k.day)) sdMissioneChiudi();
}
function sdTaskTutorial(){
  const k = SD.task; if (!k) return;
  sdMissioneChiudi();
  const q = (typeof aiQueryDa === 'function') ? aiQueryDa(k.t) : k.t;
  const conAgente = typeof agAbilitatoOra === 'function' && agAbilitatoOra() && typeof agPuo === 'function' && agPuo() && typeof agStato === 'function' && agStato().impostato;
  if (!conAgente){ if (typeof aiApri === 'function'){ AI.query = q; aiApri(k.t); } return; }
  /* la chat del tuo agente personale: il tutorial arriva li', e l'agente riceve la richiesta */
  const st = agStato();
  st.msgs.push({ id: 0, direzione: 'out', canale: 'app', locale: true, at: Date.now(),
    testo: 'Ho cercato un tutorial per "' + k.t + '". Lo guardi qui dentro, con un tempo deciso prima: poi si passa al Full Focus.',
    azioni: { tutorial: { q: q, task: k.t } } });
  agSalva();
  Promise.resolve(agApri()).then(function(){ AG.vista = 'chat'; agPaint(); });
  setTimeout(function(){ try{ agBozza('Trovami il tutorial migliore per cominciare questa cosa: ' + k.t); }catch(_){ } }, 900);
}
function sdTaskVia(){
  const k = SD.task; if (!k) return;
  if (k.tipo === 'mis'){ sdMissioneFocus(k.id); return; }
  sdMissioneChiudi();
  try{ const p = ffPref(); p.minutes = Math.max(10, Math.min(180, k.min || 25)); p.intent = String(k.t).slice(0, 250); ffSavePref(); if (typeof stSaltaSync === 'function') stSaltaSync(); ffOpen(); }catch(_){ }
}

/* ---------- la missione: un foglio ---------- */
function sdMissioneApri(nd){
  const mis = sdMissione(nd); if (!mis){ toast('Il catalogo delle missioni sta arrivando'); return; }
  let w = document.getElementById('sdSheet');
  if (!w){ w = document.createElement('div'); w.id = 'sdSheet'; w.className = 'sd-sheet'; w.addEventListener('click', function(e){ if (e.target === w) sdMissioneChiudi(); }); document.body.appendChild(w); }
  w.innerHTML = '<div class="sd-sheet-in"><i class="pr-grab"></i><small>Missione · ' + (mis.min || 10) + ' min</small><h3>' + sdEsc(mis.t.replace(/\s*\(\d+ min\)$/, '')) + '</h3><p>' + sdEsc(mis.s || '') + '</p>'
    + '<button type="button" class="cta" onclick="sdMissioneFocus(\'' + nd.id + '\')">' + sdEsc((typeof snT === 'function') ? snT('missione_focus_btn') : 'Falla in Full Focus') + '</button>'
    + '<button type="button" class="sd-btn-sec" onclick="sdMissioneFatta(\'' + nd.id + '\')">' + sdEsc((typeof snT === 'function') ? snT('missione_fatta_btn') : 'Fatta') + '</button>'
    + '<button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Non ora</button></div>';
  w.hidden = false;
}
function sdMissioneChiudi(){ const w = document.getElementById('sdSheet'); if (w) w.remove(); }
function sdNodo(id){ return sdTutti().filter(function(x){ return x.id === id; })[0]; }
function sdMissioneFocus(id){
  const nd = sdNodo(id), mis = nd && sdMissione(nd); if (!mis) return;
  sdMissioneChiudi();
  try{ const p = ffPref(); p.intent = mis.t.slice(0, 250); p.minutes = Math.max(10, Math.min(90, mis.min || 15)); ffSavePref(); if (typeof stSaltaSync === 'function') stSaltaSync(); ffOpen(); }catch(_){ }
}
function sdMissioneFatta(id){
  const nd = sdNodo(id); if (!nd) return;
  sdMissioneChiudi();
  try{ const x = sdMisRm()[nd.id]; if (x && x.rm && typeof ozAnello === 'function' && typeof ozSpunta === 'function'){ const p = ozAnello(x.k).passi[x.j]; if (p && !p.fatto) ozSpunta(x.k, x.j); } }catch(_){ }
  try{ const ix = sdMisIndice(nd), sn = snStato(); if (sn.missioni.fatte.indexOf(ix) < 0) sn.missioni.fatte.push(ix); sn.missioni.fatteAt = sn.missioni.fatteAt || {}; sn.missioni.fatteAt[ix] = Date.now(); snSalva(sn); }catch(_){ }
  const s = sdStato(); s.fatti[nd.id] = Date.now(); sdSalva(s);
  sdAggiorna(true);
  sdPaint();
}
/* la missione fatta dentro Full Focus: l'intento della sessione e' il titolo della missione */
function sdControllaMissioneFocus(){
  const cur = sdCorrente(); const nd = cur.nodo; if (!nd || nd.tipo !== 'mis') return;
  const mis = sdMissione(nd); if (!mis) return;
  const x = sdSessioneDopo(sdStato().unlockAt[nd.id] || 0);
  if (x && x.intent && x.intent.slice(0, 40) === mis.t.slice(0, 40)) sdMissioneFatta(nd.id);
}

/* ---------- IL TUO PRIMO PASSO (0.9.275) ----------
   Andrea: "magari uno quell'esercizio l'ha gia' fatto", "la roadmap dovrebbe essere ritagliata su misura,
   non uguale per tutti", "le domande come se parlasse con il suo agente". Niente da scrivere: il Genio mostra
   le prime cose che si fanno per quel sogno e chiede quali sono gia' fatte (tocchi, come le carte
   dell'onboarding). Quelle non tornano piu' nella mappa; il primo passo e' la prima che manca davvero.
   Chi ha scelto "Pianifico io" non riceve un passo dal catalogo: il primo passo e' la sua priorita' di oggi.
   Con Premium il tuo agente personale lo puo' riscrivere su misura (bozza nel campo, parte solo con invio). */
const SD_PRIMO = { gia: [], fase: 0 };
registerScreen('s-sd-primo', '<div class="sd-pp" id="sdPrimo"></div>', { back: function(){ try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
function sdPrimoMia(){ try{ const u = (typeof faStrada === 'function') ? faStrada() : null; return !!(u && u.scelta === 'mia'); }catch(_){ return false; } }
function sdPrimoSalva(o){ try{ localStorage.setItem('fl_primo_passo', JSON.stringify(o)); }catch(_){ } }
function sdPrimoFatto(silenzio){
  const p = sdPrimoLeggi() || {}; p.fatto = Date.now(); sdPrimoSalva(p);
  try{ if (p.rm && typeof ozAnello === 'function' && typeof ozSpunta === 'function'){ const q = ozAnello(p.rm.k).passi[p.rm.j]; if (q && !q.fatto) ozSpunta(p.rm.k, p.rm.j); } }catch(_){ }
  if (p.idx != null){ try{ const sn = snStato(); if (sn.missioni.fatte.indexOf(p.idx) < 0) sn.missioni.fatte.push(p.idx); sn.missioni.fatteAt = sn.missioni.fatteAt || {}; sn.missioni.fatteAt[p.idx] = Date.now(); snSalva(sn); }catch(_){ } }
  if (silenzio) return;
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
  sdAggiorna(true); sdPaint();
}
function sdPrimoApri(){
  SD_PRIMO.gia = sdMisGia().slice(); SD_PRIMO.fase = sdPrimoMia() ? 2 : (sdPrimoLeggi() && sdPrimoLeggi().t ? 1 : 0);
  /* 0.9.276: con la roadmap su misura il primo passo e' il suo primo passo, senza domande */
  if (SD_PRIMO.fase === 0 && typeof sdRoadmapPassi === 'function'){
    const r = sdRoadmapPassi()[0];
    if (r){ sdPrimoSalva({ at: Date.now(), t: r.t, s: r.s, min: r.min, rm: r }); SD_PRIMO.fase = 1; }
  }
  goId('s-sd-primo'); sdPrimoPaint();
}
function sdPrimoTocca(i){
  const k = SD_PRIMO.gia.indexOf(i);
  if (k >= 0) SD_PRIMO.gia.splice(k, 1); else SD_PRIMO.gia.push(i);
  try{ flVibra(8); }catch(_){ }
  sdPrimoPaint();
}
function sdPrimoAvanti(){
  try{ localStorage.setItem('fl_mis_gia', JSON.stringify(SD_PRIMO.gia)); }catch(_){ }
  const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : [];
  const idx = l.map(function(_, i){ return i; }).filter(function(i){ return SD_PRIMO.gia.indexOf(i) < 0; })[0];
  if (idx == null){ sdPrimoSalva({ at: Date.now(), t: 'Sei già oltre i primi passi', tutte: true }); }
  else { const m = l[idx]; sdPrimoSalva({ at: Date.now(), idx: idx, t: m.t.replace(/\s*\(\d+ min\)$/, ''), s: m.s || '', min: m.min || 10 }); }
  SD_PRIMO.fase = 1;
  try{ flVibra([10, 30, 10]); }catch(_){ }
  sdPrimoPaint();
}
function sdPrimoVia(){
  const p = sdPrimoLeggi(); if (!p || !p.t) return;
  try{ const f = ffPref(); f.intent = String(p.t).slice(0, 250); f.minutes = Math.max(10, Math.min(90, p.min || 15)); ffSavePref(); if (typeof stSaltaSync === 'function') stSaltaSync(); ffOpen(); }catch(_){ }
}
function sdPrimoAgente(){
  const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : [];
  const gia = SD_PRIMO.gia.map(function(i){ return l[i] ? l[i].t.replace(/\s*\(\d+ min\)$/, '') : ''; }).filter(Boolean);
  const sogno = (typeof nvSogno === 'function' && nvSogno()) || 'il mio sogno';
  const testo = 'Il mio sogno è "' + sogno + '". ' + (gia.length ? 'Queste cose le ho già fatte: ' + gia.join('; ') + '. ' : 'Sono all\u2019inizio. ')
    + 'Fammi due domande su dove sono adesso, poi dammi il mio primo passo da 10-15 minuti, su misura per me.';
  if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo);
}
function sdPrimoPaint(){
  const h = document.getElementById('sdPrimo'); if (!h) return;
  const l = (typeof snMissioniDi === 'function') ? snMissioniDi() : [];
  const sogno = (typeof nvSogno === 'function' && nvSogno()) || '';
  const top = '<div class="sd-pp-top"><button type="button" class="iconbtn" onclick="goId(\'s-home\');try{switchTab(\'mappa\')}catch(_){}" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><small>IL TUO PRIMO PASSO</small></div>';
  const premium = sdPremium() && typeof agNuovaConversazione === 'function';
  if (SD_PRIMO.fase === 2){
    /* "Pianifico io": il passo e' suo */
    const d = sdTaskDati({ tipo: 'ff' });
    sdPrimoSalva(Object.assign({}, sdPrimoLeggi() || {}, { at: (sdPrimoLeggi() || {}).at || Date.now(), t: d.t, min: d.min, mia: true }));
    h.innerHTML = top + '<div class="sd-pp-in"><img class="sd-pp-genio" src="img/genio/genio-saluta.png" alt="">'
      + '<h2>Hai scelto di pianificare tu: il primo passo è tuo</h2>'
      + '<div class="sd-pp-passo"><b>' + sdEsc(d.t) + '</b><small>⏱ ' + d.min + ' min</small></div>'
      + '<p class="sd-pp-sub">Fallo in una sessione di Full Focus: quando finisce, la tappa si chiude da sola.</p>'
      + '<button type="button" class="cta" onclick="sdPrimoVia()">Comincio adesso · ' + d.min + ' min</button>'
      + '<button type="button" class="sd-btn-sec" onclick="sdPrimoFatto()">L\u2019ho già fatto</button></div>';
    return;
  }
  if (SD_PRIMO.fase === 0){
    const lista = l.slice(0, 6);
    h.innerHTML = top + '<div class="sd-pp-in"><img class="sd-pp-genio" src="img/genio/genio-pensa.png" alt="">'
      + '<h2>Per il tuo sogno, cosa hai già fatto di queste?</h2>'
      + (sogno ? '<div class="sd-pp-sogno">' + sdEsc(sogno) + '</div>' : '')
      + '<p class="sd-pp-sub">Tocca quelle già fatte: non te le farò rifare.</p>'
      + '<div class="sd-pp-lista">' + lista.map(function(m, i){
          const on = SD_PRIMO.gia.indexOf(i) >= 0;
          return '<button type="button" class="sd-pp-voce' + (on ? ' on' : '') + '" onclick="sdPrimoTocca(' + i + ')"><b>' + sdEsc(m.t.replace(/\s*\(\d+ min\)$/, '')) + '</b></button>';
        }).join('') + '</div>'
      + '<button type="button" class="cta" onclick="sdPrimoAvanti()">' + (SD_PRIMO.gia.length ? 'Avanti' : 'Non ne ho fatta nessuna') + '</button></div>';
    return;
  }
  const p = sdPrimoLeggi() || {};
  if (p.tutte){
    h.innerHTML = top + '<div class="sd-pp-in"><img class="sd-pp-genio" src="img/genio/genio-rivela.png" alt="">'
      + '<h2>Sei già oltre i primi passi</h2><p class="sd-pp-sub">Il prossimo te lo scrive su misura il tuo agente personale: sa dove sei arrivato.</p>'
      + (premium ? '<button type="button" class="cta" onclick="sdPrimoAgente()">Chiedilo al tuo agente personale</button>' : '')
      + '<button type="button" class="' + (premium ? 'sd-btn-sec' : 'cta') + '" onclick="sdPrimoFatto()">Avanti</button></div>';
    return;
  }
  h.innerHTML = top + '<div class="sd-pp-in"><img class="sd-pp-genio" src="img/genio/genio-rivela.png" alt="">'
    + '<h2>Allora il tuo primo passo è questo</h2>'
    + '<div class="sd-pp-passo"><b>' + sdEsc(p.t || '') + '</b>' + (p.s ? '<p>' + sdEsc(p.s) + '</p>' : '') + '<small>⏱ ' + (p.min || 10) + ' min</small></div>'
    + '<button type="button" class="cta" onclick="sdPrimoVia()">Lo faccio adesso · ' + (p.min || 10) + ' min</button>'
    + '<button type="button" class="sd-btn-sec" onclick="sdPrimoFatto()">Fatto</button>'
    + (premium ? '<button type="button" class="sd-btn-link" onclick="sdPrimoAgente()">Fallo su misura con il tuo agente personale</button>' : '')
    + (p.rm ? '' : '<button type="button" class="sd-btn-link" onclick="SD_PRIMO.fase=0;sdPrimoPaint()">Cambia le risposte</button>') + '</div>';
}

/* ---------- IL TUO PIANO SU MISURA (0.9.276) ----------
   Il tuo agente personale ti fa qualche domanda, una alla volta, e scompone il sogno all'indietro: fra cinque anni,
   quest'anno, questo mese, questa settimana, oggi. Da li' vengono le missioni della mappa. */
function sdPianoApri(rifai){
  const premium = sdPremium() && typeof agNuovaConversazione === 'function';
  /* 0.9.331, Andrea: "non dovrebbe neanche comparire: dovrebbe iniziare direttamente la tappa, e' una ripetizione" */
  if (premium && !rifai){ sdPianoVia(); return; }
  const w = sdSheetW();
  w.innerHTML = '<div class="sd-sheet-in sd-piano">' + SD_X + '<i class="pr-grab"></i>'
    + '<img class="sd-piano-genio" src="img/genio/genio-saluta.png" alt="">'
    + '<h3>Il tuo piano su misura</h3>'
    + (rifai
        ? '<p>' + esc(sdChiPiano()) + ' ti rifà le domande partendo da dove sei adesso, e ridisegna le tappe della mappa.</p>'
          + (premium ? '<button type="button" class="cta" onclick="sdPianoVia()">Rifai il piano</button>' : '<button type="button" class="cta" onclick="sdPremiumApri()">Scopri Premium</button>')
          + '<button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Chiudi</button>'
        : '<p>' + esc(sdChiPiano()) + ' ti fa qualche domanda e divide il sogno in tappe, da qui al giorno in cui ci arrivi. Le missioni della mappa diventano le tue.</p>'
          + (premium ? '<button type="button" class="cta" onclick="sdPianoVia()">Cominciamo</button>' : '<button type="button" class="cta" onclick="sdPianoSalta();sdPremiumApri()">Scopri Premium</button>')
          + (premium ? '<button type="button" class="sd-btn-link" onclick="sdMissioneChiudi()">Più tardi</button>' : '<button type="button" class="sd-btn-link" onclick="sdPianoSalta();sdMissioneChiudi()">Continuo con le missioni del Genio</button>'))
    + '</div>';
  w.hidden = false;
}
function sdPianoVisto(){ try{ localStorage.setItem('fl_piano_visto', String(Date.now())); }catch(_){ } setTimeout(function(){ try{ sdAggiorna(true); sdPaint(); }catch(_){ } }, 300); }
/* chi non ha Premium la salta apposta: la tappa si chiude e si va avanti con le missioni del Genio */
function sdPianoSalta(){ try{ localStorage.setItem('fl_piano_saltato', String(Date.now())); }catch(_){ } sdPianoVisto(); }
/** La roadmap e' stata applicata (agente.js, agApplica): la tappa del piano e' fatta. */
function sdPianoApplicato(){
  try{ localStorage.setItem('fl_piano_fatto', String(Date.now())); }catch(_){ }
  /* 0.9.292, Andrea: "ho fatto la tappa di oggi, Crea il tuo piano su misura, e la serie dice ancora che mi restano 6 ore".
     Chi aveva gia' visto la tappa del piano nelle versioni di prima la aveva "vista" con una data vecchia: il giro delle
     tappe la saltava e oggi non contava. Applicare il piano e' la tappa fatta adesso: si segna oggi, e il giro la
     riprende (punti e fine tappa compresi). */
  try{
    const st = sdStato(), oggi = sdK(Date.now()); let mosso = false;
    sdTutti().forEach(function(nd){
      if (nd.tipo !== 'piano') return;
      if (st.fatti[nd.id] && sdK(st.fatti[nd.id]) === oggi) return;
      delete st.fatti[nd.id]; delete st.visti[nd.id]; mosso = true;
    });
    if (mosso){ sdSalva(st); setTimeout(function(){ try{ sdAggiorna(true); }catch(_){ } try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ } }, 400); }
  }catch(_){ }
  /* LE MISSIONI SI RIFANNO SULLA ROADMAP NUOVA: le tappe ancora da fare erano legate ai passi di prima (fl_mis_rm) */
  try{
    const m = sdMisRm(), st = sdStato(); let cambiate = 0;
    Object.keys(m).forEach(function(id){ if (!st.fatti[id]){ delete m[id]; cambiate++; } });
    if (cambiate) localStorage.setItem('fl_mis_rm', JSON.stringify(m));
  }catch(_){ }
}
function sdPianoVia(){
  sdMissioneChiudi();
  try{ localStorage.setItem('fl_piano_avviato', String(Date.now())); }catch(_){ }
  const sogno = (typeof nvSogno === 'function' && nvSogno()) || 'il mio sogno';
  /* 0.9.280: l'intervista vera, sulla scena del Genio (intervista.js); senza agente, la chat come prima */
  /* 0.9.281: prima la strada (facile, normale, difficile) e i pedaggi, ad effetto farfalla; poi l'intervista */
  if (typeof ivApri === 'function'){ if (typeof mdStradaScegli === 'function') mdStradaScegli(ivApri); else ivApri(); return; }
  agNuovaConversazione('Costruisci la mia roadmap su misura per "' + sogno + '". Prima fammi le tue domande, una alla volta.');
}

/* ---------- lo scrigno: si tocca tre volte ---------- */
registerScreen('s-sd-scrigno', '<div class="sd-scr" id="sdScr"></div>', { back: function(){ try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
function sdScrignoApri(id){
  SD.scrignoId = id; SD.tocchi = 0; SD.nero = false;
  goId('s-sd-scrigno');
  sdScrignoPaint();
}
/* 0.9.278, Andrea: "i raggi dietro come nell'app di Wim Hof, le stelline, e un forziere vero come quelli di Clash
   Royale, non un'emoji". Poi: "niente forziere, e' un plagio; si chiama mystery box, e resta una mystery box". Una
   scatola blu laccata con gli angoli rossi e i punti di domanda di cristallo rosa-azzurro, senza nastro ne fiocco ("non ci deve essere per forza"), disegnata apposta e scontornata (img/mystery/); a ogni
   tocco si accende di piu'. La sfera di cristallo del Genio (img/sfera/) resta da parte per un altro momento del gioco. */
const SD_STELLA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 0c.6 6.2 5.8 11.4 12 12-6.2.6-11.4 5.8-12 12-.6-6.2-5.8-11.4-12-12C6.2 11.4 11.4 6.2 12 0z" fill="currentColor"/></svg>';
function sdScrFondo(){
  const st = [[14, 18, 18, 0], [80, 14, 12, .8], [88, 46, 22, 1.6], [10, 58, 14, 2.4], [70, 72, 16, .4], [24, 80, 10, 1.2], [56, 24, 10, 2]];
  return '<div class="sd-scr-fondo" aria-hidden="true"><i class="sd-scr-raggi"></i>'
    + st.map(function(x){ return '<span class="sd-scr-stella" style="left:' + x[0] + '%;top:' + x[1] + '%;width:' + x[2] + 'px;height:' + x[2] + 'px;animation-delay:' + x[3] + 's">' + SD_STELLA + '</span>'; }).join('') + '</div>';
}
function sdScrignoPaint(premio){
  const h = document.getElementById('sdScr'); if (!h) return;
  /* 0.9.322: la scatola si apre, un secondo di nero, poi il premio da solo (come mbPaint di scrigni.js) */
  if (premio && SD.tocchi >= 3 && !SD.nero && typeof mbNeroPoi === 'function'){
    SD.nero = true;
    h.innerHTML = sdScrFondo() + '<div class="sd-scr-in aperto"><div class="sd-scr-aperto mb-solo-box"><img src="img/mystery/aperta.webp" alt="" onerror="this.remove()"></div></div>';
    mbNeroPoi(h, function(){ sdScrignoPaint(premio); });
    return;
  }
  if (!premio){
    h.innerHTML = sdScrFondo() + '<div class="sd-scr-in" onclick="sdScrignoTocca()"><small>Mystery box</small><p class="sd-scr-sotto">Toccala tre volte per aprirla</p>'
      + '<div class="sd-scr-box forziere t' + SD.tocchi + '"><img src="img/mystery/chiusa.webp" alt="La mystery box"></div>'
      + '<div class="sd-scr-dots">' + [0, 1, 2].map(function(j){ return '<i class="' + (j < SD.tocchi ? 'on' : '') + '"></i>'; }).join('') + '</div></div>';
    return;
  }
  if (premio.widget && typeof wgSkinPremioHtml === 'function'){ h.innerHTML = sdScrFondo() + '<div class="sd-scr-in aperto">' + wgSkinPremioHtml(premio) + '</div>'; return; }
  /* RICEVI ALTRI XP (0.9.206): come su Duolingo, un annuncio in cambio del doppio del premio */
  const altri = (premio.monete && !premio.raddoppiato && typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile())
    ? '<button type="button" class="cta sd-scr-piu" onclick="sdScrignoRaddoppia()">▶ Ricevi altre ' + premio.monete + ' monete</button>' : '';
  h.innerHTML = sdScrFondo() + '<div class="sd-scr-in aperto"><div class="sd-scr-premio"><span>' + premio.ico + '</span></div><small>' + sdEsc(premio.eti) + '</small><b>' + sdEsc(premio.t) + '</b><p>' + sdEsc(premio.s || '') + '</p>'
    + altri + '<button type="button" class="' + (altri ? 'sd-btn-link' : 'cta sd-scr-cta') + '" onclick="sdScrignoContinua()">Continua</button></div>';
}
function sdScrignoRaddoppia(){
  const s = sdStato(); const premio = s.premi && s.premi[SD.scrignoId]; if (!premio || !premio.monete || premio.raddoppiato) return;
  adsRicompensa(function(){
    const st = sdStato(); const p = st.premi[SD.scrignoId]; if (!p || p.raddoppiato) return;
    try{ if (typeof ffAddCoins === 'function') ffAddCoins(p.monete); }catch(_){ }
    p.raddoppiato = true; p.t = '+' + (p.monete * 2) + ' monete'; sdSalva(st);
    try{ flVibra([20, 30, 60]); }catch(_){ }
    try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
    sdScrignoPaint(p);
  });
}
const SD_BOX_GARANZIA = { 'sc:c1': 'gelo', 'sc:c3': 'premium' };
function sdScrignoTocca(){
  SD.tocchi++;
  try{ flVibra(SD.tocchi === 3 ? [30, 40, 90] : 16); if (typeof gnAu !== 'undefined') gnAu.scelta(SD.tocchi + 1); }catch(_){ }
  if (SD.tocchi < 3){ sdScrignoPaint(); return; }
  const s = sdStato(); const id = SD.scrignoId;
  /* I PREMI (0.9.209): niente XP «per aver aperto una scatola». Ricompense che servono, variabili,
     mai la stessa due volte di fila: monete per il negozio, una congelazione della serie, un suono,
     un giorno di Premium, e raro il moltiplicatore per le prossime tappe. */
  const suoni = ['sound:ocean', 'sound:wind', 'sound:fire', 'sound:night', 'sound:cafe'].filter(function(x){ try{ return !lvHas(x); }catch(_){ return false; } });
  let gett = 0; try{ gett = snStato().serie.gettoni || 0; }catch(_){ }
  const prem = (function(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } })();
  const pool = [
    { k: 'monete', p: 46 },
    { k: 'gelo', p: gett < 3 ? 18 : 0 },
    { k: 'suono', p: suoni.length ? 14 : 0 },
    { k: 'boost', p: 12 },
    { k: 'premium', p: prem ? 0 : 6 },
    { k: 'monete_big', p: 4 },
    /* 0.9.315: i suoni prodotti ogni notte si aprono anche finendo le tappe */
    { k: 'traccia', p: (typeof suoQuanteChiuse === 'function' && suoQuanteChiuse()) ? 30 : 0 },
    /* 0.9.260, Andrea: ogni tanto un widget nuovo per la schermata iniziale, come su Duolingo */
    { k: 'widget', p: (typeof wgSkinDaSbloccare === 'function' && wgSkinDaSbloccare().length) ? 10 : 0 }
  ];
  let ultimo = ''; try{ ultimo = localStorage.getItem('fl_box_ultimo') || ''; }catch(_){ }
  const scegli = function(){ const tot = pool.reduce(function(a, x){ return a + (x.k === ultimo ? 0 : x.p); }, 0); let r = Math.random() * tot; for (const x of pool){ const w = x.k === ultimo ? 0 : x.p; if (r < w) return x.k; r -= w; } return 'monete'; };
  let tipo = scegli();
  /* 0.9.299, regole dei premi 6 e 8 (vedi IL VIAGGIO DELL'EROE E I PREMI): la prima box della strada da' il gettone che
     congela la serie (il primo pagamento dimostra che l'anello si chiude), quella della ricompensa (fine settimana 1)
     un giorno di Premium prima dei capitoli Premium, o il leggendario a chi ce l'ha gia'. Le altre restano a sorte. */
  const garanzia = SD_BOX_GARANZIA[id];
  if (garanzia === 'gelo') tipo = gett < 3 ? 'gelo' : 'monete';
  else if (garanzia === 'premium') tipo = prem ? 'monete_big' : 'premium';
  try{ localStorage.setItem('fl_box_ultimo', tipo); }catch(_){ }
  let premio;
  if (tipo === 'monete' || tipo === 'monete_big'){
    const n = tipo === 'monete_big' ? 1000 : (100 + Math.floor(Math.random() * 11) * 10);
    try{ if (typeof ffAddCoins === 'function') ffAddCoins(n); }catch(_){ }
    premio = { eti: tipo === 'monete_big' ? 'LEGGENDARIO' : 'MONETE', ico: '🪙', t: '+' + n + ' monete', s: 'Da spendere nel negozio: suoni, temi, congelazioni della serie.', monete: n };
  } else if (tipo === 'widget' && typeof wgSkinPremio === 'function' && (premio = wgSkinPremio())){
    /* il premio e' gia' pronto: il widget sbloccato e 15 monete */
  } else if (tipo === 'traccia' && typeof suoTracciaDaBox === 'function' && (premio = suoPremioTraccia())){
    /* il premio e' gia' pronto: il suono aperto */
  } else if (tipo === 'gelo'){
    try{ const sn = snStato(); sn.serie.gettoni = Math.min(3, (sn.serie.gettoni || 0) + 1); snSalva(sn); }catch(_){ }
    premio = { eti: 'RARO', ico: '🧊', t: 'Una protezione della serie', s: 'Se salti un giorno, la protezione lo copre e la serie non si spezza.' };
  } else if (tipo === 'suono'){
    const sg = suoni[Math.floor(Math.random() * suoni.length)]; try{ lvGrantExtra(sg); }catch(_){ }
    premio = { eti: 'RARO', ico: '🎵', t: 'Un suono nuovo per il Full Focus', s: { 'sound:ocean': 'Onde del mare', 'sound:wind': 'Vento', 'sound:fire': 'Camino', 'sound:night': 'Notte d’estate', 'sound:cafe': 'Caffè' }[sg] || 'Lo trovi fra i suoni.' };
  } else if (tipo === 'premium'){
    try{ const cur = Date.parse(localStorage.getItem('fl_premium_until') || '') || 0; const da = Math.max(cur, Date.now()); localStorage.setItem('fl_premium_until', new Date(da + 86400000).toISOString()); if (typeof Premium !== 'undefined' && Premium._notify) Premium._notify(); }catch(_){ }
    premio = { eti: 'EPICO', ico: '👑', t: 'Un giorno di Premium', s: 'Per 24 ore: niente annunci, l’agente, la Roadmap intera.' };
  } else if (sdTappeOggi() >= SD_META_GIORNO){
    /* 0.9.287, Andrea (come Duolingo): "se oggi hai gia' fatto tante tappe, la pozione non si usa subito: torna domani".
       Si accende alla prima tappa di domani, per un quarto d'ora. */
    const domani = new Date(); domani.setHours(24, 0, 0, 0);
    try{ localStorage.setItem('fl_sd_pozione', String(domani.getTime())); }catch(_){ }
    const ore = Math.max(1, Math.ceil((domani.getTime() - Date.now()) / 3600000));
    premio = { eti: 'RARO', ico: '🧪', t: 'Pozione XP tripli', s: '🔒 ' + ore + (ore === 1 ? ' ora' : ' ore') + '. Torna domani: la prima tappa di domani vale il triplo per 15 minuti.' };
  } else {
    sdBoostDai(SD_BOOST_MIN, 3);
    premio = { eti: 'RARO', ico: '🧪', t: 'Pozione XP tripli', s: 'Per 15 minuti ogni tappa vale il triplo: falla adesso.' };
  }
  s.fatti[id] = Date.now(); s.visti[id] = Date.now(); s.premi = s.premi || {}; s.premi[id] = premio;
  try{ localStorage.setItem('fl_box_giorno', (typeof gcOggi === 'function') ? gcOggi() : new Date().toDateString()); }catch(_){ }
  sdSalva(s);
  try{ if (typeof gnAu !== 'undefined') gnAu.punto(); }catch(_){ }
  try{ if (typeof lvBump === 'function') lvBump(); }catch(_){ }
  /* 0.9.294, Andrea: "su Duolingo lo scrigno si apre, lo schermo va al nero un attimo, e poi il premio compare DA SOLO sui
     raggi; noi mostravamo la scatola aperta con il premio sopra". La scatola aperta brilla, il buio, poi il premio. */
  const hh = document.getElementById('sdScr');
  if (hh){
    hh.innerHTML = sdScrFondo() + '<div class="sd-scr-in"><div class="sd-scr-box forziere apre"><img src="img/mystery/aperta.webp" alt="La mystery box aperta" onerror="this.src=\'img/mystery/chiusa.webp\'"></div></div><i class="sd-scr-buio"></i>';
    setTimeout(function(){ const b = hh.querySelector('.sd-scr-buio'); if (b) b.classList.add('on'); }, 750);
    setTimeout(function(){ sdScrignoPaint(premio); const b2 = document.createElement('i'); b2.className = 'sd-scr-buio on'; hh.appendChild(b2); requestAnimationFrame(function(){ requestAnimationFrame(function(){ b2.classList.remove('on'); setTimeout(function(){ b2.remove(); }, 500); }); }); }, 1150);
  } else sdScrignoPaint(premio);
  sdAggiorna(false);
}

/* ---------- la fine della tappa: il Genio, il titolo, i tre riquadri, RICEVI XP ---------- */
registerScreen('s-sd-fine', '<div class="sd-fine" id="sdFine"></div>', { back: function(){ try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
function sdMmSs(sec){ sec = Math.max(0, Math.round(sec || 0)); return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); }
function sdFineApri(nd, dettaglio){
  SD.fine = { nd: nd, det: dettaglio || {} };
  goId('s-sd-fine');
  const h = document.getElementById('sdFine'); if (!h) return;
  const de = SD.fine.det;
  const xp = de.xp != null ? de.xp : (SD_XP[nd.tipo] || 0);
  const doppi = de.xp != null && de.xp > (SD_XP[nd.tipo] || 0) && !de.ripeti;
  /* IL VOTO SUL TEMPO (0.9.203), come il maestro di Duolingo: sotto i due minuti «Rapido»,
     sotto i sei «Motivato», poi il tempo e basta */
  const voto = sdFineVoto(de.sec || 0);
  /* LA COMBO (0.9.214): dalla seconda cosa fatta di fila, il titolo e la frase cambiano */
  let combo = 0; try{ if (!de.ripeti && typeof fcComboPiu === 'function') combo = fcComboPiu(); }catch(_){ }
  if (combo >= 2 && !de.titolo){ de.titolo = fcComboTitolo(combo); de.sotto = fcComboFrase(combo); }
  const tit = de.titolo || { ep: 'Episodio completato!', mis: 'Missione completata!', ff: 'Sessione completata!', ck: 'Check completato!', fin: 'Il finale è tuo!' }[nd.tipo] || 'Tappa completata!';
  const sotto = de.sotto || { ep: 'Il Genio ti conosce un po’ di più.', mis: 'Un passo vero verso il sogno.', ff: 'Il telefono l’ha misurata: è tua.', ck: 'Sette giorni letti, uno per uno.', fin: 'Adesso sai dove stai andando.' }[nd.tipo] || '';
  /* IL TERZO RIQUADRO E' IL TEMPO CHE CI HAI MESSO (0.9.201): prima c'era l'ora del giorno, che
     non dice niente a nessuno. Le tappe senza un orologio (una missione spuntata a mano, il
     finale) mostrano le tappe di oggi. */
  let eti3 = 'Tempo', val3 = '';
  if (de.tempo){ eti3 = voto || de.boxTempo || 'Tempo'; val3 = de.tempo; }
  else if (de.sec){ eti3 = voto || 'Tempo'; val3 = sdMmSs(de.sec); }
  else if (de.min){ val3 = de.min + ' min'; }
  else { eti3 = 'Oggi'; val3 = sdTappeOggi() + '/' + SD_META_GIORNO; }
  sdFineDisegna(h, {
    tit: tit, sotto: sotto,
    box: '<div class="sd-box gialla"><small>' + (doppi ? sdBoostNome() : 'Totale XP') + '</small><b>⚡ ' + xp + '</b></div>'
      + (combo >= 2 ? '<div class="sd-box ciano giro"><small>Combo</small><b>🎯 ×' + combo + '</b></div>' : (de.monete != null ? '<div class="sd-box verde"><small>' + sdEsc(de.boxMonete) + '</small><b>🪙 +' + de.monete + '</b></div>' : '<div class="sd-box verde giro"><small>Serie</small><b>🔥 ' + sdSerie() + '</b></div>'))
      + '<div class="sd-box blu"><small>' + sdEsc(eti3) + '</small><b>⏱ ' + sdEsc(String(val3)) + '</b></div>',
    cta: '<button type="button" class="cta sd-fine-cta" onclick="sdRiceviXp()">Ricevi XP</button>'
  });
}
/* 0.9.308: LA SCHERMATA DI FINE e' un componente solo. La usano la fine della tappa (qui) e la fine dell'episodio
   della tua storia (episodi.js, epiFine): stesso Genio, stesso titolo, stessi tre riquadri che entrano uno alla volta,
   stesso pulsante. o = { tit, sotto, box (i tre .sd-box), dopo (html fra i riquadri e il pulsante), cta, cls } */
function sdFineVoto(sec){ return sec ? (sec < 120 ? 'Rapido' : (sec < 360 ? 'Motivato' : '')) : ''; }
function sdFineDisegna(h, o){
  h.className = 'sd-fine' + (o.cls ? ' ' + o.cls : '');
  h.innerHTML = '<div class="sd-fine-in"><img src="img/genio/genio-rivela.png" alt=""><h2>' + o.tit + '</h2><p>' + o.sotto + '</p>'
    + '<div class="sd-box3">' + o.box + '</div>'
    + (o.dopo || '')
    + o.cta + '</div>';
  /* UNO ALLA VOLTA, come su Duolingo: ogni riquadro entra con il suo suono, e quello della serie
     ha il bordo che gira finche' la serie e' accesa */
  h.querySelectorAll('.sd-box').forEach(function(b, i){
    setTimeout(function(){ b.classList.add('via'); try{ if (typeof gnAu !== 'undefined') gnAu.scelta(i + 1); flVibra(12); }catch(_){ } }, 420 + i * 460);
  });
  try{ if (typeof gnAu !== 'undefined') gnAu.punto(); flVibra([20, 30, 60]); }catch(_){ }
}
function sdRiceviXp(){
  try{ if (typeof gnAu !== 'undefined') gnAu.punto(); }catch(_){ }
  sdSerieApri();
}

/* ---------- LA SCHERMATA DELLA SERIE, a tutto schermo, dopo ogni tappa ----------
   Il Genio con il fumetto, il numero grande, la settimana con i giorni fatti, e due pulsanti:
   condividi, e «Ci vediamo domani» se la giornata e' completa, altrimenti la tappa dopo. */
registerScreen('s-sd-serie', '<div class="sd-ser" id="sdSer"></div>', { back: function(){ try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
const SD_SETT = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
function sdSerieApri(){
  sdCopriBuchi();
  goId('s-sd-serie');
  const h = document.getElementById('sdSer'); if (!h) return;
  const n = sdSerieMappa(), g = sdGiorniFatti();
  const completo = sdGiornoCompleto();
  const oggi = new Date(); oggi.setHours(12, 0, 0, 0);
  const lun = new Date(oggi.getTime() - ((oggi.getDay() + 6) % 7) * 86400000);
  let sett = '';
  for (let i = 0; i < 7; i++){
    const d = new Date(lun.getTime() + i * 86400000), k = sdK(d.getTime());
    const stato = g[k] > 0 ? 'fatto' : (g[k] === -1 ? 'coperto' : (d.getTime() > oggi.getTime() ? 'dopo' : (k === sdK(oggi.getTime()) ? 'oggi' : 'saltato')));
    sett += '<div class="sd-ser-g ' + stato + (k === sdK(oggi.getTime()) ? ' qui' : '') + '" style="--d:' + (0.9 + i * 0.07).toFixed(2) + 's"><small>' + SD_SETT[i] + '</small><i>' + (stato === 'fatto' ? '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' : (stato === 'coperto' ? '🛡️' : '')) + '</i></div>';
  }
  const nome = (typeof gnNome === 'function') ? gnNome() : '';
  /* 0.9.202: la serie di oggi e' al sicuro dalla prima tappa, e la cosa da dire e' una:
     ricordati di tornare domani (come Duolingo) */
  /* 0.9.343, Andrea: "se completa una tappa in extremis, a pochi minuti dalla fine della giornata, come Duolingo: Niente ferma Andrea".
     Fino a 90 minuti da mezzanotte, con la prima tappa di oggi, la frase lo dice e il pulsante lo premia */
  const mezzanotte = new Date(); mezzanotte.setHours(24, 0, 0, 0);
  const minFine = Math.round((mezzanotte.getTime() - Date.now()) / 60000);
  let tappeOggi = 0; try{ tappeOggi = sdTappeOggi(); }catch(_){ }
  const extremis = minFine <= 90 && tappeOggi <= 1;
  const frase = extremis
    ? 'Hai allungato la serie a soli ' + (minFine <= 1 ? 'un minuto' : minFine + ' minuti') + ' dalla fine della giornata. Ben fatto' + (nome ? ', ' + nome : '') + '!'
    : completo
    ? (n <= 1 ? 'Il primo giorno è quello che conta di più. Ricordati di tornare domani' + (nome ? ', ' + nome : '') + '!' : 'Per oggi hai fatto tutto' + (nome ? ', ' + nome : '') + '. Ricordati di tornare domani!')
    : 'Serie al sicuro per oggi. Ricordati di tornare domani' + (nome ? ', ' + nome : '') + '!';
  /* il pulsante cambia con il momento, come le frasi di Duolingo: in extremis "Niente ferma", poi a turno parole che spingono */
  let etichetta = completo ? 'Ci vediamo domani' : 'Prossima tappa';
  if (extremis) etichetta = nome ? 'Niente ferma ' + nome : 'Niente ti ferma';
  else if (nome && completo && n >= 2){
    const giro = ['Niente ferma ' + nome, 'Avanti così, ' + nome, 'Inarrestabile, ' + nome, 'Ci vediamo domani, ' + nome];
    etichetta = n % 7 === 0 ? 'Una settimana intera, ' + nome + '!' : giro[n % giro.length];
  }
  /* 0.9.276, Andrea: "il fuoco sopra il numero rosso, come su Duolingo, al posto di mostrare sempre il Genio".
     Di solito la fiamma grande, il numero rosso e la frase sotto la settimana; il Genio torna nei giorni che
     contano (il primo, ogni settimana piena) e ogni tanto, e quando c'e' lui la fiamma non c'e'. */
  const conGenio = n <= 1 || n % 7 === 0 || n % 5 === 0;
  /* 0.9.296, Andrea: "la persona potrebbe voler andare alla tappa dopo, non solo Ci vediamo domani" */
  const ancora = completo && !!sdProssimaOggi();
  const BOT = '<div class="sd-ser-bot"><button type="button" class="sd-ser-share" onclick="sdSerieCondividi()" aria-label="Condividi"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3"/><path d="M7 8l5-5 5 5"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/></svg></button>'
    + '<button type="button" class="cta sd-ser-cta" onclick="sdSerieAvanti()">' + sdEsc(etichetta) + '</button></div>'
    + (ancora ? '<button type="button" class="sd-ser-ancora" onclick="SD.ancora=true;sdSerieAvanti()">Fai la tappa dopo</button>' : '');
  /* 0.9.296, Andrea: "il bagliore del fuoco cresce con la serie" */
  const bagl = n >= 100 ? 4 : (n >= 30 ? 3 : (n >= 7 ? 2 : 1));
  if (!conGenio){
    /* 0.9.296, Andrea: "le spunte dei giorni piu' lontane dal numero e piu' vicine ai pulsanti; la frase per ultima,
       a macchina da scrivere, dopo il fuoco e tutte le animazioni". In alto fuoco, numero, giorni di fila; in basso,
       in un blocco solo, la settimana, la frase e i pulsanti. */
    h.innerHTML = '<div class="sd-ser-in sd-ser-fuoco">'
      + '<div class="sd-ser-grande b' + bagl + '" aria-hidden="true">\uD83D\uDD25</div>'
      + '<b class="sd-ser-n" id="sdSerN">' + n + '</b>'
      + '<div class="sd-ser-eti">' + (n === 1 ? 'giorno di fila!' : 'giorni di fila!') + '</div>'
      + '<div class="sd-ser-giu"><div class="sd-ser-sett">' + sett + '</div>'
      + '<p class="sd-ser-frase" id="sdSerFrase"></p>'
      + BOT + '</div></div>';
    sdSerieScrivi(frase, 'sdSerFrase', 1500);
    try{ flVibra([20, 30, 60]); }catch(_){ }
    return;
  }
  h.innerHTML = '<div class="sd-ser-in">'
    + '<div class="sd-ser-fumetto" id="sdSerFrase">&nbsp;</div>'
    + '<div class="sd-ser-genio"><img src="img/genio/genio-rivela.png" alt=""></div>'
    /* 0.9.210: il fuoco sta allo stesso posto del numero, un livello sotto: il numero sopra al
       fuoco, non il fuoco sotto al numero (che spingeva i giorni contro al pulsante) */
    + '<div class="sd-ser-num sd-ser-solo"><b class="sd-ser-n" id="sdSerN">' + n + '</b></div>'
    + '<div class="sd-ser-eti">' + (n === 1 ? 'giorno di fila' : 'giorni di fila') + '</div>'
    + '<div class="sd-ser-giu"><div class="sd-ser-sett">' + sett + '</div>'
    + BOT + '</div></div>';
  sdSerieScrivi(frase, 'sdSerFrase', 1500);
  try{ flVibra([20, 30, 60]); }catch(_){ }
}
/* la frase a macchina da scrivere, dopo le animazioni; il suo spazio e' gia' riservato, cosi' niente salta */
let SD_SER_TW = 0;
function sdSerieScrivi(t, id, ritardo){
  clearTimeout(SD_SER_TW);
  const el = document.getElementById(id); if (!el) return;
  el.style.minHeight = '3.1em';
  let i = 0;
  const passo = function(){
    const e = document.getElementById(id); if (!e) return;
    i++; e.textContent = t.slice(0, i);
    if (i < t.length) SD_SER_TW = setTimeout(passo, 26);
  };
  SD_SER_TW = setTimeout(passo, ritardo || 0);
}
/* 0.9.296, Andrea: "ogni tanto, non tutte le settimane, la domenica una mystery box come lo scrigno di Duolingo".
   La domenica, con almeno sette giorni di fila, una settimana su tre; una volta sola per settimana. */
function sdDomenicaBox(poi){
  try{
    const d = new Date();
    if (d.getDay() !== 0 || sdSerieMappa() < 7) return false;
    const sett = Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / (7 * 86400000));
    if (sett % 3 !== 0 || localStorage.getItem('fl_box_domenica') === String(sett)) return false;
    if (typeof scrApriPremio !== 'function' || document.getElementById('mbBox')) return false;
    if (typeof gcScatolaPermessa === 'function' && !gcScatolaPermessa()) return false;
    localStorage.setItem('fl_box_domenica', String(sett));
    scrApriPremio('argento', { titolo: 'Il premio della domenica', sotto: 'Una settimana senza saltare: toccala tre volte per aprirla', motivo: 'domenica', onChiudi: poi });
    return true;
  }catch(_){ return false; }
}
/* LA DOMANDA DELLA SERIE, dopo la schermata della serie (0.9.281): "Quanti giorni di fila vuoi fare?" */
registerScreen('s-sd-ob', '<div class="sd-ob-pag" id="sdObPag"></div>', { back: function(){ sdObFatto(); return null; } });
let SD_OB_POI = null;
function sdObChiedi(poi){
  if (typeof hdObiettivo !== 'function' || hdObiettivo()) return false;
  SD_OB_POI = poi || null;
  goId('s-sd-ob');
  const h = document.getElementById('sdObPag'); if (!h) return false;
  h.innerHTML = '<img class="sd-ob-genio" src="img/genio/genio-pensa.png" alt=""><small>Il Genio ti chiede</small><h2>Quanti giorni di fila vuoi fare?</h2>'
    + '<p>Un traguardo per la tua serie. Quando lo raggiungi, ne scegli uno nuovo.</p>'
    /* 0.9.294, Andrea: "7, 14, 30 e 50 sono troppo vicini: 7, 14, 30 e poi 90, un trimestre; e la scelta personalizzata" */
    /* 0.9.295, Andrea: "90 giorni e basta; niente Lo scelgo piu' avanti, sembra procrastinare; Lo scrivo io sottolineato
       sotto alle quattro, che porta a una casella sola con Confermo" */
    + '<div class="sd-ob-griglia">' + [7, 14, 30, 90].map(function(g){ return '<button type="button" onclick="hdObiettivoSet(' + g + ');sdObFatto()"><b>' + g + '</b><span>giorni</span></button>'; }).join('') + '</div>'
    + '<button type="button" class="sd-ob-scrivo" onclick="sdObMio()">Lo scrivo io</button>';
  return true;
}
function sdObMio(){
  const h = document.getElementById('sdObPag'); if (!h) return;
  h.innerHTML = '<img class="sd-ob-genio" src="img/genio/genio-pensa.png" alt=""><small>Il Genio ti chiede</small><h2>Quanti giorni di fila vuoi fare?</h2>'
    + '<input type="number" inputmode="numeric" min="3" max="1000" id="sdObNum" class="sd-ob-num" placeholder="Es. 365" data-no-mic>'
    + '<button type="button" class="sd-ob-conf" onclick="sdObMioOk()">Confermo</button>';
  try{ document.getElementById('sdObNum').focus(); }catch(_){ }
}
function sdObMioOk(){
  const v = Math.round(+((document.getElementById('sdObNum') || {}).value) || 0);
  if (v < 3 || v > 1000){ if (typeof toast === 'function') toast('Scegli un numero da 3 a 1000'); return; }
  hdObiettivoSet(v); sdObFatto();
}
function sdObFatto(){ const f = SD_OB_POI; SD_OB_POI = null; if (f) f(); else { goId('s-home'); try{ switchTab('mappa'); }catch(_){ } } }
function sdSerieAvanti(){
  /* 0.9.343, Andrea: "come Duolingo: il fuoco che si sdoppia, poi Serie di gruppo allungate con le persone, e Continua" (dream-social.js) */
  if (!SD.slFatto){ SD.slFatto = true; if (typeof dsoSlancioForse === 'function' && dsoSlancioForse(sdSerieAvanti)) return; }
  SD.slFatto = false;
  /* 0.9.344, Andrea: "dopo X giorni di fila, come Duolingo: Hai ottenuto uno Slancio perfetto, e poi il premio da dividere" */
  if (!SD.spfFatto){ SD.spfFatto = true; if (typeof spfForse === 'function' && spfForse(sdSerieAvanti)) return; }
  SD.spfFatto = false;
  if (!SD.domFatto){ SD.domFatto = true; if (sdDomenicaBox(sdSerieAvanti)) return; }
  SD.domFatto = false;
  if (!SD.obFatto){ SD.obFatto = true; if (sdObChiedi(sdSerieAvanti)) return; }
  SD.obFatto = false;
  /* 0.9.279: "Tieni il ritmo" come Duolingo, finche' la tappa non sta nel calendario del telefono */
  if (typeof ritmoForse === 'function' && !SD.ritmoFatto){ SD.ritmoFatto = true; if (ritmoForse(sdSerieAvanti)) return; }
  SD.ritmoFatto = false;
  /* 0.9.300: l'invito alle notifiche come Duolingo, se sono spente (invito-notifiche.js decide quando) */
  if (typeof ivnForse === 'function' && !SD.ivnFatto){ SD.ivnFatto = true; if (ivnForse(sdSerieAvanti)) return; }
  SD.ivnFatto = false;
  /* 0.9.213: prima le missioni del giorno, se una e' avanzata; poi il resto */
  /* 0.9.287: dopo le missioni la lega che sale, le Olimpiadi e la velocita' della settimana (fine-tappa.js) */
  const dopo = function(){ if (typeof ftDopoTappa === 'function') ftDopoTappa(sdSerieAvantiResto); else sdSerieAvantiResto(); };
  if (sdMisApri(dopo)) return;
  dopo();
}
function sdSerieAvantiResto(){
  /* LA SFERA DELL'EPISODIO SI APRE QUI (0.9.201), dopo l'XP e la serie, come su Duolingo il
     premio arriva a livello finito: prima stava in mezzo alle domande, con il Genio davanti. */
  try{ const nd = SD.fine && SD.fine.nd; if (nd && nd.tipo === 'ep' && typeof dqSferaApri === 'function' && dqSferaApri(nd.n)) return; }catch(_){ }
  /* LA PUBBLICITA' (0.9.206): a tappa finita, per chi non ha Premium, un annuncio e poi la
     proposta di saltarli con la prova gratuita. Solo quando c'e' il modulo: senza, si va avanti. */
  try{ if (typeof adsDopoTappa === 'function' && adsDopoTappa(function(){ sdSerieDopo(); })) return; }catch(_){ }
  sdSerieDopo();
}
function sdSerieDopo(){
  goId('s-home');
  try{ switchTab('mappa'); }catch(_){ }
  const fatto = SD.fine && SD.fine.nd ? SD.fine.nd.id : '';
  const ancora = !!SD.ancora; SD.ancora = false;
  const avanti = function(){
    if (sdGiornoCompleto() && !(ancora && sdProssimaOggi())) return;
    const nd = sdProssimaOggi(); if (!nd) return;
    setTimeout(function(){ try{ sdTapVia(nd.id); }catch(_){ } }, 250);
  };
  /* 0.9.288, Andrea: "la mappa dovrebbe animarsi ogni volta che si completa un livello, come in Super Mario: il livello
     appena fatto si colora, la visuale scorre al prossimo che si sblocca, e se era un bivio si vede la strada scelta".
     Prima si saltava dritti nel livello dopo e la mappa non si vedeva mai avanzare. */
  if (fatto) setTimeout(function(){ sdAnimaAvanza(fatto, avanti); }, 120); else avanti();
}
function sdAnimaAvanza(idFatto, poi){
  const fine = function(){ if (typeof poi === 'function') try{ poi(); }catch(_){ } };
  try{ SD.forza = true; sdPaint(); }catch(_){ }
  try{ NAV_SCROLL_MANO = Date.now(); }catch(_){ }
  const n1 = document.querySelector('#mppSentiero .sd-nodo[data-id="' + idFatto + '"]');
  if (!n1){ fine(); return; }
  const cur = sdCorrente(), id2 = cur && cur.nodo ? cur.nodo.id : '';
  const n2 = id2 ? document.querySelector('#mppSentiero .sd-nodo[data-id="' + id2 + '"]') : null;
  const scorri = function(el){ try{ el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }catch(_){ } };
  /* 1. il livello appena fatto: la visuale ci va, e si colora con un salto */
  n1.classList.add('sd-in-attesa');
  scorri(n1);
  setTimeout(function(){
    n1.classList.remove('sd-in-attesa'); n1.classList.add('sd-appena-fatto');
    try{ if (typeof muJingle === 'function') muJingle('moneta'); flVibra([10, 30, 10]); }catch(_){ }
    const bv = n1.closest('.sd-riga') ? n1.closest('.sd-riga').querySelector('.sd-bv') : null;
    if (bv) bv.classList.add('sd-bv-disegna');
    /* 2. la visuale scorre al livello dopo, che si sblocca */
    setTimeout(function(){
      if (!n2){ fine(); return; }
      n2.classList.add('sd-in-sblocco');
      scorri(n2);
      setTimeout(function(){
        n2.classList.remove('sd-in-sblocco'); n2.classList.add('sd-sbloccato');
        /* 0.9.290, Andrea: "per il livello sbloccato voglio la vibrazione" (prima un tocco di 14 ms, quasi non si sentiva) */
        try{ if (typeof muJingle === 'function') muJingle('giusta'); flVibra([30, 60, 90]); }catch(_){ }
        setTimeout(fine, 1100);
      }, 750);
    }, 1100);
  }, 650);
}
/* 0.9.290, Andrea: "quando si applica la roadmap si deve vedere la roadmap ridisegnata, come in un videogioco: i livelli e
   le tappe che si ristrutturano sotto gli occhi, con la visuale che scorre tutti i capitoli e le fasi". La Mappa si
   apre, le tappe spariscono, la visuale scende dal primo capitolo all'ultimo e le tappe entrano una per una mentre
   passa; poi torna sulla tappa in corso e chiude il livello del piano (con i punti e il livello dopo). */
function sdRicostruisci(poi){
  const fine = function(){ if (typeof poi === 'function') try{ poi(); }catch(_){ } };
  try{ goId('s-home'); switchTab('mappa'); }catch(_){ }
  setTimeout(function(){
    try{ NAV_SCROLL_MANO = Date.now(); }catch(_){ }
    try{ SD.forza = true; sdPaint(); }catch(_){ }
    const tab = document.getElementById('tab-mappa'), box = document.getElementById('mppSentiero');
    if (!tab || !box || box.offsetParent === null){ fine(); return; }
    const nodi = Array.prototype.slice.call(box.querySelectorAll('.sd-nodo, .sd-eti, .sd-genio'));
    if (!nodi.length){ fine(); return; }
    const sopra = function(el){ let y = 0, e = el; while (e && e !== tab){ y += e.offsetTop; e = e.offsetParent; } return y; };
    const ban = document.createElement('div'); ban.className = 'sd-rc-ban'; ban.innerHTML = '<span>🗺️</span><b>Ridisegno il tuo percorso</b>';
    document.body.appendChild(ban); requestAnimationFrame(function(){ ban.classList.add('on'); });
    try{ flVibra([20, 50, 20]); }catch(_){ }
    box.classList.add('sd-ricostruisce');
    /* 0.9.302: la Roadmap ha tutti i capitoli fino al sogno; il ridisegno scorre fino all'ultimo capitolo disegnato intero,
       non per anni di capitoli */
    const ultInt = Array.prototype.slice.call(box.querySelectorAll('.sd-cap:not(.leggero)')).pop();
    const fondo = ultInt ? sopra(ultInt) + ultInt.offsetHeight : sopra(box) + box.offsetHeight;
    const y0 = Math.max(0, sopra(box) - 90), y1 = Math.max(y0, fondo - tab.clientHeight + 40);
    tab.scrollTop = y0;
    const D = Math.max(2600, Math.min(8000, nodi.length * 110)), t0 = performance.now();
    let ultimoSuono = 0;
    const passo = function(t){
      try{ NAV_SCROLL_MANO = Date.now(); }catch(_){ }
      const q = Math.min(1, (t - t0) / D), e = q < .5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2;
      tab.scrollTop = y0 + (y1 - y0) * e;
      const lim = tab.scrollTop + tab.clientHeight * 0.82;
      nodi.forEach(function(n){
        if (n.classList.contains('sd-rc-on') || sopra(n) > lim) return;
        n.classList.add('sd-rc-on');
        if (n.classList.contains('sd-nodo') && t - ultimoSuono > 140){ ultimoSuono = t; try{ flVibra(18); if (typeof muJingle === 'function' && Math.random() < .35) muJingle('tic'); }catch(_){ } }
      });
      if (q < 1){ requestAnimationFrame(passo); return; }
      nodi.forEach(function(n){ n.classList.add('sd-rc-on'); });
      setTimeout(function(){
        ban.classList.remove('on'); setTimeout(function(){ ban.remove(); }, 400);
        try{ flVibra([30, 60, 90]); if (typeof muJingle === 'function') muJingle('capitolo'); }catch(_){ }
        const cur = sdCorrente(); const nc = cur && cur.nodo ? box.querySelector('.sd-nodo[data-id="' + cur.nodo.id + '"]') : null;
        try{ if (nc) nc.scrollIntoView({ behavior: 'smooth', block: 'center' }); }catch(_){ }
        setTimeout(function(){
          box.classList.remove('sd-ricostruisce');
          nodi.forEach(function(n){ n.classList.remove('sd-rc-on'); });
          fine();
        }, 900);
      }, 500);
    };
    requestAnimationFrame(passo);
  }, 450);
}
/* CONDIVIDI LA SERIE (0.9.213), come «Condividi slancio» di Duolingo: un'immagine, non un testo */
async function sdSerieCanvas(){
  const n = sdSerieMappa();
  const W = 900, H = 1300, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  x.fillStyle = '#ffffff'; x.fillRect(0, 0, W, H);
  x.textAlign = 'center'; x.textBaseline = 'alphabetic';
  x.fillStyle = '#0075E3'; x.font = '900 64px sans-serif'; x.fillText('DreamMap', W / 2, 150);
  x.font = '330px sans-serif'; x.textBaseline = 'middle'; x.fillText('🔥', W / 2, 520);
  x.textBaseline = 'alphabetic'; x.fillStyle = '#E63946'; x.font = '900 300px sans-serif'; x.fillText(String(n), W / 2, 1000);
  x.font = '800 70px sans-serif'; x.fillText(n === 1 ? 'giorno di fila' : 'giorni di fila', W / 2, 1095);
  let nome = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = (u && u.name) ? String(u.name) : ''; }catch(_){ }
  const MESI = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic']; const d = new Date();
  x.fillStyle = '#6B7A90'; x.font = '700 42px sans-serif';
  x.textAlign = 'left'; x.fillText(nome ? '@' + nome.split(' ')[0] : 'DreamMap', 70, 1230);
  x.textAlign = 'right'; x.fillText(d.getDate() + ' ' + MESI[d.getMonth()] + ' ' + d.getFullYear(), W - 70, 1230);
  return cv;
}
async function sdSerieCondividi(){
  const n = sdSerieMappa();
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const url = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + (code ? '?invito=' + encodeURIComponent(code) : '');
  const testo = n + (n === 1 ? ' giorno' : ' giorni') + ' di fila. 🔥 Tu fin dove arrivi?\n' + url;
  if (typeof flCondividiApri === 'function'){ flCondividiApri(sdSerieCanvas, testo, 'Condividi la serie'); return; }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'DreamMap' }); } }catch(_){ }
}

/* ---------- LE MISSIONI DEL GIORNO DOPO LA SERIE (0.9.213), come su Duolingo ----------
   Dopo la schermata della serie, se una missione e' avanzata, le tre barre salgono davanti agli
   occhi (dal punto di prima a quello di adesso). Con una missione appena finita: «Apri il
   forziere». Prima l'avanzamento si vedeva solo andando in Amici › Sfide. */
registerScreen('s-sd-missioni', '<div class="sd-mis" id="sdMis"></div>', { back: function(){ setTimeout(sdMisContinua, 0); return 's-sd-missioni'; } });
function sdMisViste(){ try{ return JSON.parse(localStorage.getItem('fl_mis_viste') || '{}') || {}; }catch(_){ return {}; } }
function sdMisApri(dopo){
  if (typeof sfMissioniOggi !== 'function') return false;
  const o = sfMissioniOggi(); const v = sdMisViste(); const prima = (v.k === o.k && v.n) ? v.n : [0, 0, 0];
  const cambiate = o.m.filter(function(m, i){ return m.n > (prima[i] || 0); });
  /* 0.9.310: anche per la missione del mese appena completata (missione-mese.js), che ha la sua mystery box */
  const meseNuova = (typeof mdmNuovaFatta === 'function') && mdmNuovaFatta();
  if (!cambiate.length && !meseNuova) return false;
  try{ localStorage.setItem('fl_mis_viste', JSON.stringify({ k: o.k, n: o.m.map(function(m){ return m.n; }) })); }catch(_){ }
  SD.misDopo = dopo;
  const nuove = o.m.filter(function(m, i){ return m.fatta && (prima[i] || 0) < m.tot; }).length;
  const daAprire = o.m.filter(function(m){ return m.fatta && !m.presa; });
  const meseDa = (typeof mdmDaRiscuotere === 'function') ? mdmDaRiscuotere().length : 0;
  const box = daAprire.length + meseDa;
  goId('s-sd-missioni');
  const h = document.getElementById('sdMis'); if (!h) return true;
  h.innerHTML = '<div class="sd-mis-in"><h2>' + (o.m.every(function(m){ return m.fatta; }) ? 'Hai completato tutte le missioni giornaliere!' : (nuove ? (nuove === 1 ? 'Missione completata!' : nuove + ' missioni completate!') : 'Le missioni di oggi')) + '</h2>'
    + '<div class="sd-mis-card">' + o.m.map(function(m, i){
        const da = Math.min(100, Math.round((prima[i] || 0) / m.tot * 100)), a = Math.min(100, Math.round(m.n / m.tot * 100));
        return '<div class="sd-mis-r"><b>' + sdEsc(m.t) + '</b><div class="sd-mis-riga"><div class="sd-mis-bar"><i style="width:' + da + '%" data-a="' + a + '"></i><span>' + m.n + '/' + m.tot + '</span></div><span class="sd-mis-ico' + (m.fatta ? ' pronto' : '') + '">' + (m.presa ? '✅' : m.ico) + '</span></div></div>';
      }).join('') + '</div>'
    + ((typeof mdmBoxHtml === 'function') ? mdmBoxHtml('scuro') : '')
    + (box ? '<button type="button" class="cta sd-mis-cta" onclick="sdMisForzieri()">' + (box === 1 ? 'APRI LA MYSTERY BOX' : 'APRI LE MYSTERY BOX') + '</button>' : '<button type="button" class="cta sd-mis-cta" onclick="sdMisContinua()">CONTINUA</button>')
    + '</div>';
  /* 0.9.267, Andrea: come Duolingo, una barra alla volta: ognuna si riempie con il suo suono e la sua vibrazione, e
     quella dopo parte quando la prima e' arrivata. Una missione completata suona e vibra piu' forte. */
  const barre = Array.prototype.slice.call(document.querySelectorAll('#sdMis .sd-mis-r'));
  let ritardo = 450;
  barre.forEach(function(r, i){
    const el = r.querySelector('.sd-mis-bar i'); if (!el) return;
    const da = parseFloat(el.style.width) || 0, a = parseFloat(el.getAttribute('data-a')) || 0;
    if (a <= da) return;
    const durata = 500 + Math.round((a - da) * 6);
    setTimeout(function(){
      el.style.transition = 'width ' + durata + 'ms cubic-bezier(.2,.8,.2,1)';
      el.style.width = a + '%';
      try{ if (typeof muJingle === 'function') muJingle('barra'); }catch(_){ }
      try{ flVibra([12, 40, 12]); }catch(_){ }
      if (a >= 100){
        setTimeout(function(){
          try{ if (typeof muJingle === 'function') muJingle('missione'); }catch(_){ }
          try{ flVibra([25, 50, 25, 50, 70]); }catch(_){ }
          const ico = r.querySelector('.sd-mis-ico'); if (ico) ico.classList.add('pronto', 'salta');
        }, durata - 60);
      }
    }, ritardo);
    ritardo += durata + 260;
  });
  return true;
}
function sdMisContinua(){ const f = SD.misDopo; SD.misDopo = null; if (typeof f === 'function') f(); else { goId('s-home'); try{ switchTab('mappa'); }catch(_){ } } }
/** I forzieri delle missioni finite, uno dopo l'altro; dopo l'ultimo si continua. */
function sdMisForzieri(){
  const o = sfMissioniOggi(); const da = o.m.filter(function(m){ return m.fatta && !m.presa; });
  let prese = {}; try{ prese = JSON.parse(localStorage.getItem('fl_mis_prese') || '{}') || {}; }catch(_){ }
  prese = { [o.k]: (prese[o.k] || []).concat(da.map(function(m){ return m.i; })) };
  try{ localStorage.setItem('fl_mis_prese', JSON.stringify(prese)); }catch(_){ }
  SD.codaScrigni = da.map(function(m){ return 'sc:m:' + o.k + ':' + m.i; });
  if (typeof mdmRiscuoti === 'function') SD.codaScrigni = SD.codaScrigni.concat(mdmRiscuoti());
  SD.dopoScrigni = SD.misDopo; SD.misDopo = null;
  sdScrignoContinua();
}
function sdScrignoContinua(){
  if (SD.codaScrigni && SD.codaScrigni.length){ sdScrignoApri(SD.codaScrigni.shift()); return; }
  const f = SD.dopoScrigni; SD.dopoScrigni = null;
  if (typeof f === 'function'){ f(); return; }
  goId('s-home'); try{ switchTab('mappa'); }catch(_){ }
}

/* ---------- IL LIVELLO FINALE: IL SOGNO REALIZZATO (0.9.301) ----------
   Si apre quando il nodo del sogno si sblocca (tutte le tappe fatte). Andrea, citando Huberman: troppa festa e la dopamina
   crolla subito dopo. Quindi niente coriandoli e niente fuochi: tre schermate ferme, come i titoli di coda di un gioco
   finito. 1) l'arrivo; 2) il viaggio in numeri, presi dall'app (giorni, tappe, ore di Full Focus, il record della serie);
   3) il prossimo sogno, che si sceglie con Ricomincia da capo (ricomincia.js), dopo una conferma.
   Il viaggio concluso resta: va nei sogni realizzati del Profilo (fl_sogni_realizzati, accSogniApri) e la Roadmap fatta
   si copia in fl_sd_viaggi prima di ripartire. Anteprima senza toccare niente: sdFinaleAnteprima() e sdSognoAnteprima(). */
registerScreen('s-sd-sogno', '<div class="sd-sg" id="sdSg"></div>', { back: function(){ SD.finale = null; try{ switchTab('mappa'); }catch(_){ } return 's-home'; } });
const SD_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
function sdData(t){ const d = new Date(t); return d.getDate() + ' ' + SD_MESI[d.getMonth()] + ' ' + d.getFullYear(); }
/** I numeri veri del viaggio, dalla Roadmap (fl_sd) e dalle sessioni di Full Focus (fl_ff_hist). */
function sdViaggioNumeri(){
  const s = sdStato();
  const tempi = Object.keys(s.fatti || {}).filter(function(id){ return id.indexOf('sc:') !== 0; }).map(function(id){ return +s.fatti[id] || 0; }).filter(function(t){ return t > 0; });
  const inizio = tempi.length ? Math.min.apply(null, tempi) : Date.now();
  const d0 = new Date(inizio); d0.setHours(12, 0, 0, 0);
  const oggi = new Date(); oggi.setHours(12, 0, 0, 0);
  const giorni = Math.max(1, Math.round((oggi.getTime() - d0.getTime()) / 86400000) + 1);
  const attivi = {}; tempi.forEach(function(t){ attivi[sdK(t)] = 1; });
  /* il record: i giorni di fila con almeno una tappa; un giorno coperto dal gettone non spezza e non conta */
  let record = 0, run = 0;
  for (let i = 0; i < giorni; i++){
    const k = sdK(d0.getTime() + i * 86400000);
    if (attivi[k]){ run++; if (run > record) record = run; }
    else if (!(s.coperti || {})[k]) run = 0;
  }
  let min = 0, sessioni = 0;
  try{ (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){ if (x && x.ok && !x.meditazione && (x.at || 0) >= inizio - 86400000){ min += +x.min || 0; sessioni++; } }); }catch(_){ }
  return { inizio: inizio, giorni: giorni, attivi: Object.keys(attivi).length, tappe: tempi.length, ore: min / 60, sessioni: sessioni, record: record };
}
function sdOreTxt(h){ return h > 0 && h < 10 ? String(Math.round(h * 10) / 10).replace('.', ',') : String(Math.round(h)); }
function sdSognoMaiuscolo(t){ t = String(t || '').trim(); return t ? t.charAt(0).toUpperCase() + t.slice(1) : ''; }
/* il sogno realizzato si scrive una volta sola per viaggio (s.sognoReg), con i suoi numeri */
function sdSognoRegistra(n, sogno){
  const s = sdStato(); if (s.sognoReg) return;
  let l = []; try{ l = JSON.parse(localStorage.getItem('fl_sogni_realizzati') || '[]') || []; }catch(_){ l = []; }
  l.push({ nome: sdSognoMaiuscolo(sogno) || 'Il tuo sogno', quando: 'Realizzato il ' + sdData(Date.now()) + ', dopo ' + n.giorni + (n.giorni === 1 ? ' giorno' : ' giorni') + ' di viaggio', at: Date.now(), inizio: n.inizio, giorni: n.giorni, tappe: n.tappe, ore: Math.round(n.ore * 10) / 10, record: n.record, viaggio: s.viaggio || 1 });
  try{ localStorage.setItem('fl_sogni_realizzati', JSON.stringify(l)); }catch(_){ }
  s.sognoReg = Date.now(); sdSalva(s);
}
function sdFinaleApri(anteprima){
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function' && nvSogno()) || ''; }catch(_){ }
  SD.finale = { passo: 0, anteprima: !!anteprima, n: sdViaggioNumeri(), sogno: sogno };
  if (!anteprima) sdSognoRegistra(SD.finale.n, sogno);
  try{ sdTipChiudi(); }catch(_){ }
  goId('s-sd-sogno'); sdFinalePaint();
  try{ flVibra(24); }catch(_){ }
}
/** Anteprima del livello finale (console, o dal nodo del sogno per l'admin): non scrive niente. */
function sdFinaleAnteprima(passo){ sdFinaleApri(true); if (passo){ SD.finale.passo = Math.max(0, Math.min(2, passo)); sdFinalePaint(); } }
/** Anteprima del nodo del sogno sbloccato sulla Mappa (sdSognoAnteprima(false) lo rimette com'e'). */
function sdSognoAnteprima(on){ SD.anteprimaSogno = on !== false; SD.forza = true; try{ sdPaint(); }catch(_){ } }
function sdFinalePaint(){
  const F = SD.finale, h = document.getElementById('sdSg'); if (!F || !h) return;
  const n = F.n, sogno = sdSognoMaiuscolo(F.sogno);
  const pl = function(v, u){ return v === 1 ? u[0] : u[1]; };
  let corpo = '';
  if (F.passo === 0){
    corpo = '<div class="sd-sg-ico" aria-hidden="true"><span>🏁</span></div>'
      + '<small class="sd-sg-eti">Hai fatto tutte le tappe</small>'
      + '<h2>Hai realizzato il tuo sogno.</h2>'
      + (sogno ? '<p class="sd-sg-sogno">"' + sdEsc(sogno) + '"</p>' : '')
      + '<p class="sd-sg-p">Il ' + sdData(n.inizio) + ' era una frase scritta sul telefono. Oggi è una cosa che hai fatto.</p>'
      + '<button type="button" class="sd-sg-cta" data-cg-no onclick="sdFinaleAvanti()">Guarda il tuo viaggio</button>';
  } else if (F.passo === 1){
    const box = function(v, t){ return '<div class="sd-sg-num"><b>' + v + '</b><small>' + t + '</small></div>'; };
    corpo = '<small class="sd-sg-eti">Il viaggio verso il tuo sogno</small>'
      + '<h2>Ecco la strada che hai fatto.</h2>'
      + '<div class="sd-sg-griglia">'
      +   box(n.giorni, pl(n.giorni, ['giorno dal primo passo', 'giorni dal primo passo']))
      +   box(n.tappe, pl(n.tappe, ['tappa completata', 'tappe completate']))
      +   box(sdOreTxt(n.ore), (sdOreTxt(n.ore) === '1' ? 'ora' : 'ore') + ' di Full Focus')
      +   box(n.record, pl(n.record, ['giorno di fila, il tuo record', 'giorni di fila, il tuo record']))
      + '</div>'
      + '<p class="sd-sg-p">' + (n.attivi >= n.giorni ? 'Non hai saltato neanche un giorno.' : 'Hai fatto almeno una tappa in ' + n.attivi + ' giorni su ' + n.giorni + '. Gli altri giorni la strada ti ha aspettato.') + '</p>'
      + '<button type="button" class="sd-sg-cta" data-cg-no onclick="sdFinaleAvanti()">E adesso?</button>';
  } else {
    corpo = '<small class="sd-sg-eti">Il prossimo viaggio</small>'
      + '<h2>Dove vuoi andare adesso?</h2>'
      + '<p class="sd-sg-p">Il viaggio verso ' + (sogno ? '"' + sdEsc(sogno) + '"' : 'il tuo sogno') + ' resta tuo. Le tappe, le ore e la data dell’arrivo stanno nei tuoi sogni realizzati, nel Profilo.</p>'
      + '<p class="sd-sg-p sd-sg-ultima">Il prossimo sogno può aspettare domani: oggi goditi questo.</p>'
      + '<button type="button" class="sd-sg-cta" data-cg-no onclick="sdFinaleNuovo()">Scegli il prossimo sogno</button>'
      + '<button type="button" class="sd-sg-link" onclick="sdFinaleChiudi()">Resto qui ancora un po’</button>';
  }
  const dots = '<div class="sd-sg-dots" aria-hidden="true">' + [0, 1, 2].map(function(i){ return '<i' + (i === F.passo ? ' class="on"' : '') + '></i>'; }).join('') + '</div>';
  h.innerHTML = '<button type="button" class="sd-sg-x" onclick="sdFinaleChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg></button>'
    + dots + '<div class="sd-sg-in p' + F.passo + '">' + corpo + '</div>';
}
function sdFinaleAvanti(){ if (!SD.finale) return; SD.finale.passo = Math.min(2, SD.finale.passo + 1); sdFinalePaint(); try{ flVibra(8); }catch(_){ } }
function sdFinaleChiudi(){ SD.finale = null; goId('s-home'); try{ switchTab('mappa'); }catch(_){ } }
async function sdFinaleNuovo(){
  const F = SD.finale; if (!F) return;
  const nome = sdSognoMaiuscolo(F.sogno);
  const testo = 'Il viaggio verso ' + (nome ? '"' + nome + '"' : 'il tuo sogno') + ' resta nei tuoi sogni realizzati, con le tappe e le ore. Poi si apre Ricomincia da capo: il Genio ti legge di nuovo e scegli tu cosa tenere.';
  const ok = (typeof blkConfirm === 'function') ? await blkConfirm('Scegli il prossimo sogno?', testo, 'Scegli il prossimo sogno') : window.confirm(testo);
  if (!ok) return;
  if (F.anteprima){ try{ toast('Questa è un’anteprima: non è cambiato niente'); }catch(_){ } return; }
  sdSognoRegistra(F.n, F.sogno);
  sdNuovoViaggioPrepara(F.sogno);
  SD.finale = null;
  if (typeof rcApri === 'function') rcApri(); else if (typeof rivediOnboarding === 'function') rivediOnboarding();
}
/* IL VIAGGIO NUOVO. Qui si copia la Roadmap fatta (fl_sd_viaggi) e si lascia un segno (fl_sd_nuovo). La strada riparte
   solo se Ricomincia da capo va fino in fondo (fl_reset_ultimo piu' recente del segno): chi torna indietro senza
   confermare ritrova tutto com'era. Le tappe del viaggio concluso escono dal sentiero, ma i loro giorni restano nella
   serie (s.giorniPrima) e l'XP resta. Senza conferma entro un giorno il segno si toglie da solo. */
function sdNuovoViaggioPrepara(sogno){
  let v = []; try{ v = JSON.parse(localStorage.getItem('fl_sd_viaggi') || '[]') || []; }catch(_){ v = []; }
  v.push({ at: Date.now(), sogno: sdSognoMaiuscolo(sogno), sd: sdStato() });
  try{ localStorage.setItem('fl_sd_viaggi', JSON.stringify(v)); localStorage.setItem('fl_sd_nuovo', JSON.stringify({ at: Date.now(), sogno: sogno || '' })); }catch(_){ }
}
function sdNuovoViaggioApplica(){
  let p = null; try{ p = JSON.parse(localStorage.getItem('fl_sd_nuovo') || 'null'); }catch(_){ p = null; }
  if (!p || !p.at) return;
  const reset = +localStorage.getItem('fl_reset_ultimo') || 0;
  if (reset < p.at){ if (Date.now() - p.at > 86400000){ try{ localStorage.removeItem('fl_sd_nuovo'); }catch(_){ } } return; }
  const s = sdStato();
  s.giorniPrima = s.giorniPrima || {};
  Object.keys(s.fatti).forEach(function(id){ if (id.indexOf('sc:') === 0) return; const t = s.fatti[id]; if (t){ const k = sdK(t); s.giorniPrima[k] = (s.giorniPrima[k] || 0) + 1; } });
  s.fatti = {}; s.visti = {}; s.unlockAt = {}; s.ripet = {};
  delete s.sognoVisto; delete s.sognoReg;
  s.viaggio = (s.viaggio || 1) + 1;
  sdSalva(s);
  try{ localStorage.removeItem('fl_sd_nuovo'); localStorage.removeItem('fl_mis_rm'); }catch(_){ }
}

/* ---------- LE FASI DEL VIAGGIO (0.9.234) ----------
   Andrea: al posto delle "sezioni", le fasi, perche' e' un viaggio; ogni fase e' un orizzonte di
   tempo. Toccando la scheda blu del capitolo si apre una pagina come quella di Duolingo: una card per
   fase con i capitoli, la barra di avanzamento, e nella fase in corso il Genio con il traguardo di
   quell'orizzonte. Toccando una fase si va al suo capitolo nel sentiero.
   Capitoli: 1-7 la prima settimana (un capitolo al giorno), 8-14 la seconda, poi uno a settimana.
   0.9.302: le fasi non sono piu' quattro fisse fino a cinque anni. Si ricavano dalla durata della Roadmap (sdDurata):
   gli orizzonti che servono a scomporre il sogno, piu' fitti se il sogno e' vicino, piu' larghi se e' lontano.
     fino a 3 mesi        la prima settimana, il primo mese, fino al sogno;
     da 3 mesi a un anno  + un trimestre alla volta (fino al terzo, al sesto, al nono mese);
     da uno a due anni    + fino al terzo mese, fino al sesto mese, il primo anno;
     oltre due anni       + fino al terzo mese, il primo anno, poi un anno alla volta.
   L'ultima fase e' sempre "Fino al sogno" e finisce con l'ultimo capitolo; una fase di meno di quattro settimane si
   unisce all'ultima. Esempi: 6 mesi = 4 fasi e 38 capitoli; 18 mesi = 5 fasi e 90 capitoli; 4 anni = 7 fasi e 221. */
const SD_ORD = ['primo', 'secondo', 'terzo', 'quarto', 'quinto', 'sesto', 'settimo', 'ottavo', 'nono', 'decimo'];
function sdFasi(){
  const u = sdUltimoCap();
  if (SD.fasiCache && SD.fasiCache.u === u) return SD.fasiCache.v;
  const W = u - 12;                                       /* le settimane del viaggio */
  let tagli = [];
  if (W > 52 * 2) tagli = [13, 52].concat([2, 3, 4, 5, 6, 7, 8, 9, 10].map(function(a){ return 52 * a; }));
  else if (W > 52) tagli = [13, 26, 52];
  else if (W > 13) tagli = [13, 26, 39];
  tagli = tagli.filter(function(w){ return w <= W - 4; });
  const nome = function(w){
    if (w === 13) return 'Fino al terzo mese';
    if (w === 26) return 'Fino al sesto mese';
    if (w === 39) return 'Fino al nono mese';
    const a = Math.round(w / 52); return 'Il ' + (SD_ORD[a - 1] || (a + '°')) + ' anno';
  };
  const v = [{ n: 1, da: 1, a: 7, oz: 'settimana', nome: 'La prima settimana', frase: 'Questa settimana' }];
  if (u > 7) v.push({ n: 2, da: 8, a: Math.min(16, u), oz: 'mese', nome: 'Il primo mese', frase: 'Questo mese' });
  let da = 17;
  tagli.forEach(function(w){ const a = 12 + w; v.push({ n: v.length + 1, da: da, a: a, oz: w === 52 ? 'anno' : '', nome: nome(w), frase: w === 52 ? 'Quest’anno' : '' }); da = a + 1; });
  if (u >= da) v.push({ n: v.length + 1, da: da, a: u, oz: '', nome: 'Fino al sogno', frase: '' });
  SD.fasiCache = { u: u, v: v };
  return v;
}
function sdFase(cap){ const F = sdFasi(); return F.filter(function(f){ return cap >= f.da && cap <= f.a; })[0] || F[F.length - 1]; }
function sdFaseAvanzamento(f, caps, s){
  const qui = caps.filter(function(c){ return c.cap >= f.da && c.cap <= f.a; });
  let fatti = 0;
  qui.forEach(function(c){ const tot = c.nodi.length || 1; fatti += c.nodi.filter(function(nd){ return sdNodoFatto(nd, s); }).length / tot; });
  return Math.max(0, Math.min(1, fatti / (f.a - f.da + 1)));
}
function sdListaApri(){
  const caps = sdCapitoli(), s = sdStato(), cur = sdCorrente();
  const capOra = (cur.nodo && cur.nodo.cap) ? cur.nodo.cap.cap : 1;
  const faseOra = sdFase(capOra);
  let w = document.getElementById('sdFasi');
  if (!w){ w = document.createElement('div'); w.id = 'sdFasi'; w.className = 'sd-fasi'; document.body.appendChild(w); }
  const traguardo = function(f){ if (!f.oz || !f.frase) return ''; try{ const a = (typeof ozAnello === 'function') ? ozAnello(f.oz) : null; return a && a.testo ? f.frase + ': ' + a.testo : ''; }catch(_){ return ''; } };
  const card = function(f){
    const p = sdFaseAvanzamento(f, caps, s), on = f.n === faseOra.n, dopo = f.n > faseOra.n, finita = p >= 0.999;
    const tr = traguardo(f);
    return '<button type="button" class="sdf-card' + (on ? ' on' : '') + (dopo ? ' dopo' : '') + (finita ? ' finita' : '') + '" onclick="sdFaseVai(' + f.n + ')">'
      + (on ? '<div class="sdf-genio"><div class="sdf-fum">' + sdEsc(tr || ('Sei nella fase ' + f.n + '. Un capitolo alla volta, fino al sogno.')) + '</div><img src="img/genio/genio-saluta.png" alt=""></div>' : '')
      + '<div class="sdf-riga"><b>Fase ' + f.n + '</b><span class="sdf-badge">capitoli ' + sdDalAl(f.da, f.a) + '</span></div>'
      + '<small class="sdf-nome">' + sdEsc(f.nome) + (!on && tr ? ' · ' + sdEsc(tr.split(': ').slice(1).join(': ')) : '') + '</small>'
      + '<div class="sdf-barra"><i style="width:' + Math.round(p * 100) + '%"></i></div>'
      + (dopo ? '<span class="sdf-poi">Si apre dopo la fase ' + (f.n - 1) + '</span>' : '')
      + '</button>';
  };
  w.innerHTML = '<div class="sdf-top"><button type="button" class="sdf-x" onclick="sdFasiChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg></button><b>Il tuo viaggio</b><span></span></div>'
    + '<div class="sdf-lista">' + sdDurataBoxHtml() + sdFasi().map(card).join('') + '</div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('aperta'); const c = w.querySelector('.sdf-card.on'); if (c && c.scrollIntoView) c.scrollIntoView({ block: 'center' }); });
  try{ flVibra(8); }catch(_){ }
}
function sdFasiChiudi(){ const w = document.getElementById('sdFasi'); if (!w) return; w.classList.remove('aperta'); setTimeout(function(){ w.hidden = true; }, 200); }
function sdFaseVai(n){
  const f = sdFasi().filter(function(x){ return x.n === n; })[0]; if (!f) return;
  const cur = sdCorrente(); const capOra = (cur.nodo && cur.nodo.cap) ? cur.nodo.cap.cap : 1;
  if (f.da > capOra && sdFase(capOra).n < n){ toast('Questa fase si apre dopo la fase ' + (n - 1)); return; }
  /* il capitolo in corso se e' in questa fase, altrimenti il primo della fase */
  const cap = (capOra >= f.da && capOra <= f.a) ? capOra : f.da;
  sdFasiChiudi();
  try{ if (typeof mppVista === 'function') mppVista('rotta'); }catch(_){ }
  setTimeout(function(){ const el = document.querySelector('#mppSentiero .sd-cap[data-cap="' + cap + '"]'); if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 250);
}
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') sdFasiChiudi(); });
/* "dal 17 al 25", "dall'8 al 16" */
function sdDalAl(da, a){
  const apo = function(n){ return n === 1 || n === 8 || n === 11 || (n >= 80 && n <= 89) || (n >= 800 && n <= 899); };
  return (apo(da) ? 'dall’' : 'dal ') + da + (apo(a) ? ' all’' : ' al ') + a;
}
/* QUANTO DURA, IN CIMA ALLE FASI (0.9.302): la durata detta a parole e da dove viene. Chi ha Premium la fa ricalcolare
   al suo agente: la richiesta si scrive nel campo della chat e parte solo con invio; la durata nuova arriva con il
   pulsante "Applica" sotto alla risposta (sdDurataAgenteHtml), mai da sola. */
const SD_DUR_DA = {
  scelta: 'il tempo che hai scelto all’inizio per arrivare al tuo sogno',
  stima: 'il tempo che serve per arrivare al tuo sogno secondo la stima d’arrivo',
  genio: 'il tempo che il Genio ha stimato per arrivare al tuo sogno',
  serie: 'la durata di partenza, finché non scegli entro quando vuoi arrivare al tuo sogno'
};
function sdDurataBoxHtml(){
  const d = sdDurata(), u = sdUltimoCap();
  return '<div class="sdf-durata"><small>La tua Roadmap</small><b>Dura ' + sdDurataTxt(d.mesi) + '</b>'
    + '<p>Sono ' + u + ' capitoli. ' + (d.da === 'agente' ? 'Questa durata l’hai decisa con il tuo agente personale.' : 'È ' + (SD_DUR_DA[d.da] || SD_DUR_DA.serie) + '.') + '</p>'
    + (sdPremium() ? '<button type="button" class="sdf-dur-btn" onclick="sdDurataChiedi()">Chiedi al tuo agente personale di ricalcolarla</button>'
                   : '<button type="button" class="sdf-dur-btn prem" onclick="sdFasiChiudi();sdPremiumApri()">Fattela ricalcolare dal tuo agente personale con Premium</button>')
    + '</div>';
}
function sdDurataChiedi(){
  const d = sdDurata();
  let fine = '';
  try{
    const vg = (typeof etaViaggio === 'function') ? etaViaggio() : null;
    const x = new Date(((vg && vg.inizio) || Date.now()) + d.mesi * 30.4375 * 86400000);
    fine = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][x.getMonth()] + ' ' + x.getFullYear();
  }catch(_){ }
  const testo = 'Vorrei rivedere la durata della mia Roadmap. Adesso dura ' + sdDurataTxt(d.mesi) + (fine ? ' e finisce a ' + fine : '') + '. Guardando a che punto sono, dimmi se è giusta, troppo corta o troppo lunga, e proponimi una durata nuova.';
  sdFasiChiudi();
  try{ if (typeof agNuovaConversazione === 'function') agNuovaConversazione(testo, { titolo: 'La durata della Roadmap' }); else if (typeof agApri === 'function') agApri(); }catch(_){ }
}
/** Sotto alla risposta del tuo agente personale che chiude con {"durata": {"mesi": N}}: la proposta e il pulsante per applicarla. */
function sdDurataAgenteHtml(p, id){
  const mesi = Math.round(+(p && (p.mesi || p.durata)) || 0); if (!(mesi > 0)) return '';
  const ora = sdDurata().mesi;
  if (mesi === ora) return '<div class="sd-dur-ag"><small>La durata della Roadmap</small><b>Resta di ' + sdDurataTxt(mesi) + '</b></div>';
  return '<div class="sd-dur-ag"><small>La durata della Roadmap</small><b>Da ' + sdDurataTxt(ora) + ' a ' + sdDurataTxt(mesi) + '</b>'
    + '<p>La Roadmap ' + (mesi < ora ? 'si accorcia' : 'si allunga') + ' solo se tocchi il pulsante. Le tappe che hai già fatto restano fatte.</p>'
    + '<button type="button" class="sd-dur-ok" onclick="sdDurataApplica(' + mesi + ', this)">Applica: la Roadmap dura ' + sdDurataTxt(mesi) + '</button>'
    + '</div>';
}
function sdDurataApplica(mesi, btn){
  sdDurataImposta(mesi, 'agente');
  try{ if (btn){ btn.disabled = true; btn.textContent = 'Fatto: la Roadmap dura ' + sdDurataTxt(mesi); } }catch(_){ }
  try{ SD.forza = true; sdPaint(); }catch(_){ }
  try{ if (typeof HD_RESTA !== 'undefined') HD_RESTA = null; if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ }
  try{ if (typeof toast === 'function') toast('La Roadmap adesso dura ' + sdDurataTxt(mesi)); }catch(_){ }
  try{ flVibra([12, 40, 20]); }catch(_){ }
}

/* ---------- gli agganci ---------- */
document.addEventListener('fl:tab', function(e){ if (e.detail === 'mappa') setTimeout(function(){ try{ sdControllaMissioneFocus(); sdAggiorna(true); sdPaint(); }catch(_){ } }, 120); });
document.addEventListener('fl:piano', function(){ setTimeout(function(){ try{ sdAggiorna(true); sdPaint(); }catch(_){ } }, 300); });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(function(){ try{ sdAggiorna(false); }catch(_){ } }, 5000); });

(function(){
  const css = [
    '.sd{position:relative;margin:0 -4px 18px;padding:0 4px}',
    '.sd-testa{cursor:pointer}',
    '.sd-fasi{position:fixed;inset:0;z-index:9600;background:#0F2041;color:#fff;overflow-y:auto;opacity:0;transform:translateY(16px);transition:opacity .2s ease,transform .2s ease;padding-bottom:calc(24px + env(safe-area-inset-bottom))}.sd-fasi.aperta{opacity:1;transform:none}.sd-fasi[hidden]{display:none}',
    '.sdf-top{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:8px;padding:calc(10px + env(safe-area-inset-top)) 12px 10px;background:#0F2041;border-bottom:1px solid rgba(255,255,255,.08)}.sdf-top b{flex:1;text-align:center;font:800 17px var(--font-display,var(--font-body));color:#C9D6EE}.sdf-top span{width:44px}',
    '.sdf-x{width:44px;height:44px;border:0;border-radius:50%;background:transparent;color:#C9D6EE;display:grid;place-items:center;cursor:pointer}',
    '.sdf-lista{padding:14px 16px;display:flex;flex-direction:column;gap:14px}',
    '.sdf-card{display:block;width:100%;text-align:left;border:2px solid rgba(255,255,255,.12);border-radius:20px;padding:16px 16px 18px;background:repeating-linear-gradient(135deg,rgba(255,255,255,.03) 0 26px,transparent 26px 52px),#14234A;color:#fff;cursor:pointer;font:inherit}',
    '.sdf-card.on{border-color:#8CC6FF;box-shadow:0 0 0 3px rgba(140,198,255,.18)}.sdf-card.dopo{opacity:.62}',
    '.sdf-riga{display:flex;align-items:center;gap:10px}.sdf-riga b{flex:1;font:900 24px var(--font-display,var(--font-body))}',
    '.sdf-badge{flex:none;padding:5px 10px;border-radius:10px;background:rgba(255,255,255,.1);font:800 12.5px var(--font-body);color:#C9D6EE}',
    '.sdf-nome{display:block;margin:4px 0 12px;font:600 13.5px/1.4 var(--font-body);color:#9FB3D6}',
    '.sdf-barra{height:16px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}.sdf-barra i{display:block;height:100%;min-width:16px;border-radius:99px;background:linear-gradient(180deg,#8CC6FF,#0075E3);box-shadow:inset 0 -3px 0 rgba(0,0,0,.12)}',
    '.sdf-card.finita .sdf-barra i{background:linear-gradient(180deg,#3E9BFF,#0075E3)}',
    '.sdf-poi{display:block;margin-top:10px;font:800 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#8CC6FF}',
    '.sdf-genio{display:flex;align-items:flex-end;gap:6px;margin:-4px -4px 12px}.sdf-genio img{width:92px;height:auto;flex:none;filter:drop-shadow(0 8px 14px rgba(0,0,0,.35))}',
    '.sdf-fum{position:relative;flex:1;background:#1E2F5E;border-radius:16px;padding:12px 14px;font:700 15px/1.4 var(--font-body);color:#fff;margin-bottom:26px}.sdf-fum::after{content:"";position:absolute;right:-8px;bottom:14px;border:8px solid transparent;border-left-color:#1E2F5E}',
    '.sd-top{display:flex;justify-content:space-between;gap:8px;margin:0 0 12px}.sd-pill{flex:1;text-align:center;padding:9px 6px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line);font:700 13px var(--font-body);color:var(--navy)}body.dark .sd-pill{background:#12203A;border-color:#22345A;color:#fff}.sd-pill b{font-weight:800}',
    '.sd-testa{position:sticky;top:0;z-index:3;display:flex;align-items:center;gap:12px;background:#0075E3;color:#fff;border-radius:18px;padding:14px 16px;box-shadow:0 6px 0 #005BB0,0 12px 24px rgba(0,117,227,.25);margin-bottom:26px}',
    '.sd-testa small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;opacity:.9}.sd-testa b{display:block;font:800 17px/1.2 var(--font-display)}.sd-testa > small,.sd-testa > b{flex:none}',
    '.sd-testa-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.sd-testa-t b{white-space:normal}',
    /* 0.9.289: l'intestazione della scheda (alta circa 64 px) sta SOPRA la scheda che scorre: il pannello si ferma sotto
       di lei, non a 0 (dove finiva tagliato). sdTestaTop la misura davvero. */
    '#tab-mappa .sd-testa{top:var(--sd-testa-top,72px)}',
    '.sd-testa{flex-wrap:wrap}.sd-testa .sd-lista{margin-left:auto;width:40px;height:40px;border:0;border-left:1px solid rgba(255,255,255,.35);border-radius:0;background:transparent;color:#fff;font-size:20px;cursor:pointer;padding-left:12px}',
    '.sd-cap{position:relative;padding:0 0 26px;min-height:330px}.sd-cap:not(.on){opacity:.75}',
    '.sd-div{display:flex;align-items:center;gap:12px;margin:8px 0 58px}.sd-div > i{flex:1;height:2px;background:#B7C5D9}body.dark .sd-div > i{background:#3B5283}',
    '.sd-div > div{text-align:center}.sd-div span{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.sd-div b{display:block;font:800 16px var(--font-display);color:var(--navy)}body.dark .sd-div b{color:#fff}',
    '.sd-salto-w{display:flex;flex-direction:column;align-items:center;gap:8px;margin:-8px 0 22px}.sd-salto-fum{font:900 11.5px var(--font-display);letter-spacing:.08em;color:#E71D4F;background:var(--card,#fff);border:2px solid #FFD2DC;border-radius:12px;padding:7px 12px}body.dark .sd-salto-fum{background:#12203A;border-color:#5A1F2E}',
    '.sd-salto{width:66px;height:66px;border-radius:50%;border:0;background:#E71D4F;color:#fff;font-size:26px;box-shadow:0 7px 0 #C42B38;cursor:pointer}',
    '.sd-salto-art{font-size:56px;text-align:center;margin-bottom:6px}',
    '#s-sd-esame{padding:0;background:var(--bg)}.sd-esame{padding:16px 20px 30px}',
    '.sd-es-top{display:flex;align-items:center;gap:12px}.sd-es-x{width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:var(--muted);font-size:20px;cursor:pointer}',
    '.sd-es-bar{flex:1;height:14px;border-radius:99px;background:var(--line);overflow:hidden}.sd-es-bar i{display:block;height:100%;background:#58CC02;border-radius:99px;transition:width .3s}body.dark .sd-es-bar{background:#22345A}',
    '.sd-es-vite i{font-style:normal;font-size:18px;color:#C9D6EA;margin-left:2px}.sd-es-vite i.on{color:#FF4B4B}',
    '.sd-es-eti{display:block;margin:34px 0 8px;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}',
    '.sd-es-q{margin:0;font:800 23px/1.25 var(--font-display);color:var(--navy)}body.dark .sd-es-q{color:#fff}.sd-es-sotto{margin:8px 0 22px;font:500 14px var(--font-body);color:var(--muted)}',
    '.sd-es-opz{display:flex;flex-direction:column;gap:10px}.sd-es-opz button{text-align:left;padding:16px 18px;border-radius:16px;border:2px solid var(--line);border-bottom-width:4px;background:var(--card,#fff);font:700 15px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .sd-es-opz button{background:#12203A;border-color:#22345A;color:#fff}.sd-es-opz button.ok{border-color:#58CC02;background:rgba(88,204,2,.14)}.sd-es-opz button.ko{border-color:#FF4B4B;background:rgba(255,75,75,.14)}',
    '.sd-es-fine{text-align:center;padding-top:80px}.sd-es-fine span{font-size:70px}.sd-es-fine h2{margin:12px 0 6px;font:900 26px var(--font-display);color:var(--navy)}body.dark .sd-es-fine h2{color:#fff}.sd-es-fine p{margin:0 auto 22px;max-width:30ch;color:var(--muted);font:500 14.5px/1.5 var(--font-body)}',
    '.sd-cap-eti{text-align:center;margin:0 0 18px}.sd-cap-eti span{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.sd-cap-eti b{display:block;font:800 15px var(--font-display);color:var(--navy)}body.dark .sd-cap-eti b{color:#fff}',
    '.sd-riga{display:flex;flex-direction:column;align-items:center;margin:0 0 22px;transform:translateX(var(--off,0px))}',
    '.sd-mossa{margin:0 18px 18px}.sd-mossa .nv-mossa{margin:0}',
    '.sd-cap{overflow-x:clip}.sd-riga.con-bivio{position:relative;z-index:0}',
    '.sd-bv{position:absolute;inset:0;z-index:-1;pointer-events:none;overflow:visible}.sd-bv svg{position:absolute;overflow:visible}',
    '.sd-nodo.sd-in-attesa .sd-ico{opacity:.35;transform:scale(.8)}',
    '.sd-nodo.sd-appena-fatto{animation:sdFattoSalta .7s cubic-bezier(.2,1.6,.4,1)}',
    '@keyframes sdFattoSalta{0%{transform:scale(.85)}45%{transform:scale(1.22)}100%{transform:scale(1)}}',
    '.sd-nodo.sd-appena-fatto::after{content:"";position:absolute;inset:-10px;border-radius:50%;border:4px solid #5BC0F8;opacity:0;animation:sdOnda .9s ease-out}',
    '@keyframes sdOnda{0%{opacity:.9;transform:scale(.7)}100%{opacity:0;transform:scale(1.45)}}',
    '.sd-nodo.sd-in-sblocco{filter:grayscale(1) brightness(.85);transform:scale(.85)}',
    '.sd-nodo.sd-sbloccato{animation:sdSblocco .8s cubic-bezier(.2,1.5,.4,1)}',
    '@keyframes sdSblocco{0%{filter:grayscale(1);transform:scale(.8)}50%{filter:grayscale(0);transform:scale(1.18)}100%{transform:scale(1)}}',
    '.sd-bv.sd-bv-disegna .bv-vena{stroke-dasharray:600;stroke-dashoffset:600;animation:sdVena 1s ease-out forwards}',
    '@keyframes sdVena{to{stroke-dashoffset:0}}',
    '.sd-bv .bv-bordo{fill:none;stroke:#A3BCDD;stroke-width:22;stroke-linecap:round}.sd-bv .bv-fondo{fill:none;stroke:#DCE9F9;stroke-width:16;stroke-linecap:round}',
    '.sd-bv .bv-linea{fill:none;stroke:#fff;stroke-width:2.5;stroke-dasharray:7 9;stroke-linecap:round}',
    'body.dark .sd-bv .bv-bordo{stroke:#2B4170}body.dark .sd-bv .bv-fondo{stroke:#3A5487}body.dark .sd-bv .bv-linea{stroke:#A9C8F2}',
    '.sd-bv .bv-vena{fill:none;stroke-width:6;stroke-linecap:round;filter:drop-shadow(0 0 6px rgba(255,138,194,.75));stroke-dasharray:14 10;animation:bvVena 1.6s linear infinite}',
    '@keyframes bvVena{to{stroke-dashoffset:-48}}',
    '.sd-bv.preso .bv-altra{opacity:.55}',
    '.sd-bv text{font:900 26px var(--font-display);fill:#9DB4D4;text-anchor:middle}body.dark .sd-bv text{fill:#5D78A8}',
    '.sd-riga.con-bivio .sd-eti{position:relative;z-index:1}',
    '.sd-cap{overflow-x:visible}#mppSentiero{overflow-x:clip}',
    '.sd-bivio{position:absolute;left:50%;top:37px;width:0;height:0;z-index:-1;pointer-events:none}',
    '.sd-bivio i{position:absolute;left:-14px;top:-14px;width:28px;height:28px;border-radius:50%;background:#C9D6EA;box-shadow:0 4px 0 #A9B8CE}',
    'body.dark .sd-bivio i{background:#2A3A5E;box-shadow:0 4px 0 #1B2742}',
    '.sd-bivio.dx i:nth-child(1){transform:translate(70px,40px)}.sd-bivio.dx i:nth-child(2){transform:translate(130px,95px) scale(1.4)}.sd-bivio.dx i:nth-child(3){transform:translate(190px,160px) scale(1.8)}.sd-bivio.dx i:nth-child(4){transform:translate(260px,235px) scale(2.2)}',
    '.sd-bivio.sx i:nth-child(1){transform:translate(-70px,40px)}.sd-bivio.sx i:nth-child(2){transform:translate(-130px,95px) scale(1.4)}.sd-bivio.sx i:nth-child(3){transform:translate(-190px,160px) scale(1.8)}.sd-bivio.sx i:nth-child(4){transform:translate(-260px,235px) scale(2.2)}',
    '.sd-bivio i:nth-child(1){opacity:.75}.sd-bivio i:nth-child(2){opacity:.55}.sd-bivio i:nth-child(3){opacity:.35}.sd-bivio i:nth-child(4){opacity:.18}',
    '.sd-bivio.preso i{filter:grayscale(1);opacity:.22!important}',
    '.sd-nodo{position:relative;width:74px;height:74px;border-radius:50%;border:0;cursor:pointer;display:flex;align-items:center;justify-content:center;background:#C9D6EA;box-shadow:0 7px 0 #A9B8CE;transition:transform .12s}body.dark .sd-nodo{background:#2A3550;box-shadow:0 7px 0 #1A2338}',
    '.sd-nodo:active{transform:translateY(5px);box-shadow:0 2px 0 #A9B8CE}.sd-nodo.prem{background:#EEF2F8;box-shadow:0 6px 0 #C9D3E2}.sd-nodo.prem .sd-ico{filter:grayscale(1);opacity:.35}.sd-nodo.prem::after{content:"🔒";position:absolute;right:-6px;top:-6px;font-size:22px;filter:none}',
    '.sd-nodo .sd-ico{font-size:30px;line-height:1;filter:grayscale(1);opacity:.55}',
    '.sd-nodo.corrente,body.dark .sd-nodo.corrente{background:#0075E3;box-shadow:0 7px 0 #005BB0,0 0 0 8px rgba(0,117,227,.18);width:84px;height:84px}.sd-nodo.corrente .sd-ico{filter:none;opacity:1;font-size:36px}',
    '.sd-nodo.fatto,body.dark .sd-nodo.fatto{background:var(--dream);box-shadow:0 7px 0 #A9C3E8}.sd-nodo.fatto .sd-ico{filter:none;opacity:1;color:#001E44;font:900 34px var(--font-display)}',
    '.sd-nodo.fatto.t-sc .sd-ico{font-size:32px}',
    '.sd-nodo.corrente::after{content:"";position:absolute;inset:-10px;border-radius:50%;border:4px solid rgba(63,159,244,.75);animation:sdSonar 1.6s ease-out infinite;pointer-events:none}',
    '@keyframes sdSonar{0%{transform:scale(.92);opacity:1}70%{transform:scale(1.18);opacity:0}100%{transform:scale(1.18);opacity:0}}',
    /* 0.9.306, Andrea: "il popup e la tappa sono tutti e due blu". Il fumetto e' ROSSO del brand, la tappa da fare resta blu */
    '.sd-tip{position:absolute;z-index:30;margin:0;width:max-content;min-width:230px;max-width:290px;padding:16px;border-radius:18px;background:#E63946;color:#fff;text-align:center;box-shadow:0 10px 26px rgba(120,20,30,.32);animation:sdTipIn .18s ease-out}',
    '.sd-tip::before{content:"";position:absolute;top:-8px;left:var(--fx,50%);width:16px;height:16px;background:inherit;transform:translateX(-50%) rotate(45deg);border-radius:3px}',
    '.sd-tip b{display:block;font:800 16px/1.3 var(--font-display)}.sd-tip p{margin:6px 0 0;font:600 13.5px/1.45 var(--font-body);color:inherit;opacity:.85}',
    '.sd-tip.scuro{background:#2B3A55;color:#C9D4E5}body.dark .sd-tip.scuro{background:#33456A;color:#DCE5F3;box-shadow:0 10px 26px rgba(0,0,0,.45)}',
    '.sd-tip-xp{display:inline-block;margin-top:8px;padding:4px 12px;border-radius:99px;background:#fff;color:#E63946;font:900 13px var(--font-body);letter-spacing:.02em}.sd-tip.scuro .sd-tip-xp{background:rgba(255,255,255,.14);color:#fff}',
    '.sd-tip-go{display:block;width:100%;margin-top:12px;border:0;border-radius:14px;padding:13px;background:#fff;color:#E63946;font:900 15px var(--font-body);letter-spacing:.04em;box-shadow:0 4px 0 rgba(0,0,0,.15);cursor:pointer}',
    '@keyframes sdTipIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}',
    '.sd-genio.chiuso img{filter:grayscale(1) brightness(.75);opacity:.55}',
    '.sd-fumetto{position:absolute;left:50%;top:-44px;transform:translateX(-50%);background:#fff;color:#0075E3;font:900 12px var(--font-display);letter-spacing:.1em;padding:8px 12px;border-radius:12px;border:2px solid #C9D6EA;white-space:nowrap;animation:sdSu 1.1s ease-in-out infinite}',
    '.sd-fumetto::after{content:"";position:absolute;left:50%;bottom:-8px;width:12px;height:12px;background:#fff;border-right:2px solid #C9D6EA;border-bottom:2px solid #C9D6EA;transform:translateX(-50%) rotate(45deg)}',
    '@keyframes sdSu{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(-5px)}}',
    '.sd-eti{margin-top:8px;font:600 11.5px var(--font-body);color:var(--muted);max-width:150px;text-align:center}',
    '.sd-genio{position:absolute;top:92px;width:96px;text-align:center;cursor:pointer}.sd-genio.dx{right:-4px}.sd-genio.sx{left:-4px}.sd-genio img{width:84px;height:auto;filter:drop-shadow(0 8px 16px rgba(14,35,80,.25))}',
    '.sd-cap:not(.on) .sd-genio img{filter:grayscale(1);opacity:.5}',
    '.sd-ob-chiedi{display:flex;align-items:center;gap:12px;margin:0 18px 14px;padding:14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .sd-ob-chiedi{background:#12203A;border-color:#22345A}.sd-ob-chiedi img{width:56px;height:auto}.sd-ob-chiedi small{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.sd-ob-chiedi b{display:block;margin:2px 0 8px;font:800 15px var(--font-body);color:var(--navy)}body.dark .sd-ob-chiedi b{color:#fff}.sd-ob-opz{display:flex;gap:6px}.sd-ob-opz button{flex:1;border:1.5px solid var(--line);border-radius:10px;background:transparent;padding:8px 2px;font:800 13px var(--font-body);color:#0075E3;cursor:pointer}',
    '.sd-es-fine{text-align:center;padding:40px 24px}.sd-es-fine span{font-size:72px}.sd-es-fine h2{margin:12px 0 8px;font:800 26px var(--font-display);color:var(--navy)}body.dark .sd-es-fine h2{color:#fff}.sd-es-fine p{margin:0 auto 22px;max-width:32ch;font:500 15px/1.5 var(--font-body);color:var(--muted)}.sd-es-fine .cta{width:100%}',
    '.sd-stelle{margin-top:2px}.sd-stelle i{font-style:normal;font-size:18px;color:#C9D6EA}.sd-stelle i.on{color:#0075E3}',
    /* il foglio della missione e la lista */
    '.sd-sheet{position:fixed;inset:0;z-index:9994;background:rgba(0,8,20,.7);display:flex;align-items:flex-end;justify-content:center}.sd-sheet[hidden]{display:none}',
    '.sd-sheet-in{width:100%;max-width:460px;max-height:80vh;overflow:auto;background:var(--card,#fff);border-radius:26px 26px 0 0;padding:14px 20px calc(24px + env(safe-area-inset-bottom));text-align:center}body.dark .sd-sheet-in{background:#141C2C}',
    '.sd-sheet-in small{display:block;font:700 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0075E3;margin-top:10px}.sd-sheet-in h3{margin:10px 0 8px;font:800 22px/1.25 var(--font-display);color:var(--navy)}body.dark .sd-sheet-in h3{color:#fff}.sd-sheet-in p{margin:0 0 18px;font:500 14px/1.55 var(--font-body);color:var(--muted)}',
    '.sd-btn-sec{display:block;width:100%;margin-top:10px;border:0;border-radius:99px;background:var(--blue-soft,#E3F1FF);color:#0075E3;padding:14px;font:800 15px var(--font-body);cursor:pointer}.sd-btn-link{display:block;width:100%;margin-top:6px;border:0;background:transparent;color:var(--muted);font:600 13px var(--font-body);cursor:pointer;padding:10px}',
    '.sd-lrow{display:flex;flex-wrap:wrap;align-items:center;gap:2px 10px;text-align:left;padding:12px 4px;border-bottom:1px solid var(--line)}.sd-lrow small{width:100%;margin:0;color:var(--muted);letter-spacing:.08em}.sd-lrow b{flex:1;font:700 14px var(--font-body);color:var(--navy)}body.dark .sd-lrow b{color:#fff}.sd-lrow span{font:700 13px var(--font-body);color:var(--muted)}.sd-lrow.on b{color:#0075E3}.sd-lrow.ok span{color:#1B9E6A}',
    /* lo scrigno */
    /* 0.9.278: blu notte del brand con i raggi che girano piano e le stelline, come la schermata del ghiaccio di Wim Hof */
    '#s-sd-scrigno{background:radial-gradient(circle at 50% 46%,#1F6FD1 0%,#0B3E86 38%,#001E44 78%)!important}',
    '.sd-scr-fondo{position:absolute;inset:0;overflow:hidden;pointer-events:none}',
    '.sd-scr-raggi{position:absolute;left:50%;top:46%;width:180vmax;height:180vmax;margin:-90vmax 0 0 -90vmax;background:repeating-conic-gradient(from 0deg,rgba(255,255,255,.13) 0deg 9deg,rgba(255,255,255,0) 9deg 22deg);-webkit-mask:radial-gradient(circle,#000 0,rgba(0,0,0,.6) 22%,transparent 52%);mask:radial-gradient(circle,#000 0,rgba(0,0,0,.6) 22%,transparent 52%);animation:sdRaggi 40s linear infinite}',
    '@keyframes sdRaggi{to{transform:rotate(360deg)}}',
    '.sd-scr-stella{position:absolute;color:#fff;opacity:0;animation:sdBrilla 3.2s ease-in-out infinite}.sd-scr-stella svg{display:block;width:100%;height:100%;filter:drop-shadow(0 0 6px rgba(255,255,255,.9))}',
    '@keyframes sdBrilla{0%,100%{opacity:0;transform:scale(.4)}50%{opacity:1;transform:scale(1)}}',
    /* 0.9.294, Andrea: "la testa del Genio viene tagliata": centrato in verticale, il contenuto piu' alto dello schermo
       usciva sopra. Parte dall'alto, con lo spazio della barra di stato, e la pagina scorre se serve. */
    '#s-sd-ob{background:#0E1B33!important;overflow-y:auto}.sd-ob-pag{min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:safe center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 30px) 24px calc(env(safe-area-inset-bottom,0px) + 30px);color:#fff}',
    '.sd-ob-mio{width:100%;max-width:340px;margin:0 0 18px;display:flex;gap:10px}.sd-ob-mio-btn{flex:1;border:1.5px solid rgba(255,255,255,.35);border-radius:18px;padding:16px;background:transparent;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.sd-ob-mio input{flex:1;min-width:0;border:0;border-radius:16px;padding:14px 16px;font:800 20px var(--font-display);text-align:center;color:#0E2350;background:#fff}.sd-ob-mio-ok{flex:none;border:0;border-radius:16px;padding:0 18px;background:#0075E3;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.sd-ob-genio{width:120px;height:auto;margin-bottom:30px;flex:none}',
    '.sd-ob-scrivo{border:0;background:none;color:#BCE0FF;font:700 15px var(--font-body);text-decoration:underline;text-underline-offset:4px;cursor:pointer;padding:8px}',
    '.sd-ob-num{width:100%;max-width:340px;box-sizing:border-box;margin:22px 0 14px;border:0;border-radius:18px;padding:18px;font:800 26px var(--font-display);text-align:center;color:#0E2350;background:#fff}.sd-ob-num::placeholder{font-style:italic;font-weight:600;color:#9AA6BC}',
    '.sd-ob-conf{width:100%;max-width:340px;border:0;border-radius:18px;padding:17px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer}.sd-ob-pag small{font:700 13px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.sd-ob-pag h2{margin:12px 0 12px;font:800 26px/1.25 var(--font-display);color:#fff}.sd-ob-pag p{margin:0 0 32px;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.75);max-width:30ch}',
    '.sd-ob-griglia{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;width:100%;max-width:340px;margin-bottom:24px}',
    '.sd-ob-griglia button{border:0;border-radius:18px;padding:18px 8px;background:rgba(255,255,255,.1);color:#fff;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px}',
    '.sd-ob-griglia b{font:900 30px var(--font-display);color:#fff}.sd-ob-griglia span{font:600 13px var(--font-body);color:rgba(255,255,255,.7)}',
    '#s-sd-ob .sd-btn-link{color:#8CC6FF}',
    '.sd-scr-in{position:relative;z-index:1}.sd-scr-in small{font:900 15px var(--font-display)!important;letter-spacing:.2em!important;text-transform:uppercase;color:#BCE0FF;margin-bottom:12px!important}',
    '.sd-scr-sotto{margin:0 0 36px!important;font:700 18px var(--font-body)!important;color:#fff}',
    '.sd-scr-box.forziere{font-size:0;filter:drop-shadow(0 26px 34px rgba(0,8,30,.55)) drop-shadow(0 0 40px rgba(110,190,255,.35))}.sd-scr-box.forziere img{display:block;width:min(68vw,270px);height:auto}',
    '.sd-scr-box.forziere.t1{animation:sdScossa .35s ease}.sd-scr-box.forziere.t1 img{filter:brightness(1.12) drop-shadow(0 0 30px rgba(246,204,228,.6))}.sd-scr-box.forziere.t2{animation:sdScossa2 .35s ease;transform:scale(1.06)}.sd-scr-box.forziere.t2 img{filter:brightness(1.25) drop-shadow(0 0 50px rgba(188,224,255,.85))}',
    '@keyframes sdScossa{0%,100%{transform:rotate(0)}25%{transform:rotate(-7deg) scale(1.04)}75%{transform:rotate(6deg) scale(1.04)}}',
    '@keyframes sdScossa2{0%,100%{transform:rotate(0) scale(1.06)}25%{transform:rotate(9deg) scale(1.1)}75%{transform:rotate(-8deg) scale(1.1)}}',
    '.sd-scr-premio{margin:120px 0 30px;display:flex;justify-content:center}.sd-scr-premio span{font-size:132px;line-height:1;filter:drop-shadow(0 0 40px rgba(140,210,255,.65));animation:sdPremioEntra .6s cubic-bezier(.2,1.4,.4,1) both}',
    '@keyframes sdPremioEntra{0%{transform:scale(.3);opacity:0}100%{transform:scale(1);opacity:1}}',
    '.sd-scr-buio{position:absolute;inset:0;z-index:20;background:#000;opacity:0;pointer-events:none;transition:opacity .38s ease}.sd-scr-buio.on{opacity:1}',
    '.sd-scr-box.apre img{animation:sdApre .7s ease both}@keyframes sdApre{0%{transform:scale(1)}40%{transform:scale(1.12)}100%{transform:scale(1.04);filter:drop-shadow(0 0 60px rgba(255,230,160,.8))}}',
    '.sd-traguardo{display:flex;flex-direction:column;align-items:center;gap:6px;margin:34px 0 80px;text-align:center}',
    '.sd-traguardo b{margin-top:12px;font:800 18px var(--font-display);color:var(--navy)}body.dark .sd-traguardo b{color:#fff}.sd-traguardo small{max-width:30ch;font:600 13px/1.4 var(--font-body);color:var(--muted)}',
    /* 0.9.301: il nodo del sogno. Chiuso: grigio come ogni tappa chiusa. Aperto: il gradiente del pulsante "Crea il tuo bundle"
       del sito, fondo rosa e azzurro, bordo dal rosso al blu; la bandiera sta su un tondo bianco per non mimetizzarsi. */
    '.sd-sogno-n{position:relative;width:96px;height:96px;border-radius:50%;border:0;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;background:#C9D6EA;box-shadow:0 8px 0 #A9B8CE;transition:transform .12s}body.dark .sd-sogno-n{background:#2A3550;box-shadow:0 8px 0 #1A2338}',
    '.sd-sogno-n .sd-ico{font-size:40px;line-height:1;filter:grayscale(1);opacity:.55}.sd-sogno-n:active{transform:translateY(5px)}',
    '.sd-sogno-n.aperto,body.dark .sd-sogno-n.aperto{width:104px;height:104px;border:3px solid transparent;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;box-shadow:0 8px 0 #8FA9D6,0 16px 32px rgba(0,117,227,.22)}',
    '.sd-sogno-n.aperto .sd-ico{filter:none;opacity:1;width:60px;height:60px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:32px;box-shadow:0 3px 10px rgba(14,35,80,.14)}',
    '.sd-sogno-n.aperto::after{content:"";position:absolute;inset:-12px;border-radius:50%;border:3px solid rgba(231,29,79,.35);animation:sdSonar 2.4s ease-out infinite;pointer-events:none}',
    /* il resto del viaggio: le schede delle fasi che mancano e tutti i capitoli; quelli lontani (leggero) hanno il titolo e
       lo spazio delle tappe finche' non ci si avvicina scorrendo (0.9.302) */
    '.sd-cap.futuro{min-height:0}.sd-cap.leggero{box-sizing:border-box;overflow:hidden}',
    /* la durata della Roadmap in cima alle fasi, e la proposta del tuo agente personale in chat (0.9.302) */
    '.sdf-durata{text-align:center;border-radius:20px;padding:16px 16px 18px;background:#1E2F5E;border:2px solid rgba(140,198,255,.35)}.sdf-durata small{display:block;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#9FB3D6}.sdf-durata b{display:block;margin:4px 0 6px;font:900 20px var(--font-display,var(--font-body));color:#fff}.sdf-durata p{margin:0 auto 14px;max-width:34ch;font:600 14px/1.45 var(--font-body);color:#C9D6EE}',
    '.sdf-dur-btn{border:0;border-radius:14px;padding:12px 16px;background:#0075E3;color:#fff;font:800 14.5px var(--font-body);box-shadow:0 4px 0 #005BB0;cursor:pointer}.sdf-dur-btn:active{transform:translateY(3px);box-shadow:0 1px 0 #005BB0}',
    '.sd-dur-ag{margin:10px 0 4px;padding:14px;border-radius:16px;border:1px solid var(--line);background:var(--card,#fff);text-align:center}body.dark .sd-dur-ag{background:#12203A;border-color:#22345A}.sd-dur-ag small{display:block;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.sd-dur-ag b{display:block;margin:4px 0 6px;font:800 17px var(--font-display);color:var(--navy)}body.dark .sd-dur-ag b{color:#fff}.sd-dur-ag p{margin:0 0 10px;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    '.sd-dur-ok{border:0;border-radius:14px;padding:11px 14px;background:#0075E3;color:#fff;font:800 14px var(--font-body);box-shadow:0 4px 0 #005BB0;cursor:pointer}.sd-dur-ok:disabled{opacity:.75;box-shadow:none}',
    '.sd-fase-card{margin:6px 14px 44px;padding:20px 18px 18px;border-radius:22px;border:2px dashed #B7C5D9;background:var(--card,#fff);text-align:center;cursor:pointer}body.dark .sd-fase-card{background:#12203A;border-color:#3B5283}',
    '.sd-fase-card small{display:block;font:800 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}.sd-fase-card b{display:block;margin:4px 0 10px;font:800 20px var(--font-display);color:var(--navy)}body.dark .sd-fase-card b{color:#fff}',
    '.sd-fase-card p{margin:0 auto 6px;max-width:32ch;font:500 14px/1.5 var(--font-body);color:var(--muted)}.sd-fase-card .sd-fc-meta{font-weight:600;color:var(--navy)}body.dark .sd-fase-card .sd-fc-meta{color:#DCE5F3}',
    '.sd-fase-card em{display:inline-flex;align-items:center;gap:6px;margin-top:8px;padding:6px 12px;border-radius:99px;background:rgba(0,30,68,.06);font:700 12.5px var(--font-body);font-style:normal;color:var(--muted)}body.dark .sd-fase-card em{background:rgba(255,255,255,.08)}',
    /* il livello finale: tre schermate ferme, centrate, chiare con il tema chiaro e blu notte con quello scuro */
    '#s-sd-sogno{padding:0;background:var(--bg,#F4F8FF)}body.dark #s-sd-sogno{background:#0B1530}.sd-sg{position:absolute;inset:0;overflow-y:auto}',
    '.sd-sg-in{min-height:100%;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:safe center;text-align:center;padding:calc(env(safe-area-inset-top,0px) + 76px) 24px calc(env(safe-area-inset-bottom,0px) + 30px);animation:sdSgIn .7s ease both}',
    '@keyframes sdSgIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}',
    '.sd-sg-x{position:absolute;z-index:2;top:calc(env(safe-area-inset-top,0px) + 14px);left:12px;width:44px;height:44px;border:0;border-radius:50%;background:transparent;color:var(--muted);display:grid;place-items:center;cursor:pointer}body.dark .sd-sg-x{color:#C9D6EE}',
    '.sd-sg-dots{position:absolute;z-index:2;top:calc(env(safe-area-inset-top,0px) + 32px);left:50%;transform:translateX(-50%);display:flex;gap:8px}.sd-sg-dots i{width:8px;height:8px;border-radius:99px;background:#C9D6EA;transition:width .3s}.sd-sg-dots i.on{width:24px;background:#0075E3}body.dark .sd-sg-dots i{background:#2A3A5E}body.dark .sd-sg-dots i.on{background:#8CC6FF}',
    /* 0.9.304, Andrea: tre gradienti nella stessa schermata (cerchio, sogno, pulsante) si rubavano il focus. Il gradiente
       resta solo sul sogno; il cerchio e' azzurro pieno e il pulsante blu. */
    '.sd-sg-ico{width:136px;height:136px;border-radius:50%;background:#E3F1FF;display:flex;align-items:center;justify-content:center;margin:0 0 22px}body.dark .sd-sg-ico{background:#14234A}',
    '.sd-sg-ico span{width:80px;height:80px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:44px;line-height:1;box-shadow:0 4px 12px rgba(14,35,80,.12)}',
    '@keyframes sdSgIco{from{opacity:0;transform:scale(.88)}to{opacity:1;transform:none}}',
    '.sd-sg-eti{display:block;margin:0 0 10px;font:800 12px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#0075E3}body.dark .sd-sg-eti{color:#8CC6FF}',
    '.sd-sg-in h2{margin:0 0 18px;font:800 28px/1.2 var(--font-display);color:var(--navy)}body.dark .sd-sg-in h2{color:#fff}',
    '.sd-sg-sogno{margin:0 0 20px;max-width:330px;padding:10px 18px;border-radius:16px;background:linear-gradient(135deg,#f6cce4 0%,#dfd2f8 40%,#c1dbff 60%,#b6e9fe 88%,#ddfefc 100%);color:#0E2350;font:800 16px/1.35 var(--font-body)}',
    '.sd-sg-p{margin:0 auto 14px;max-width:32ch;font:500 15.5px/1.55 var(--font-body);color:var(--muted)}body.dark .sd-sg-p{color:#C8D6EA}.sd-sg-ultima{font-weight:700;color:var(--navy)}body.dark .sd-sg-ultima{color:#fff}',
    '.sd-sg-griglia{display:grid;grid-template-columns:1fr 1fr;gap:12px;width:100%;max-width:360px;margin:4px 0 22px}',
    '.sd-sg-num{border-radius:18px;padding:16px 10px 14px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6)}body.dark .sd-sg-num{background:#12203A;box-shadow:0 0 0 1.5px #22345A}',
    '.sd-sg-num b{display:block;font:900 32px/1.1 var(--font-display);color:#0075E3}body.dark .sd-sg-num b{color:#8CC6FF}.sd-sg-num small{display:block;margin-top:6px;font:600 13px/1.35 var(--font-body);color:var(--muted)}body.dark .sd-sg-num small{color:#AFC0DA}',
    '.sd-sg-cta{width:100%;max-width:360px;margin-top:22px;border:0;border-radius:99px;padding:17px 20px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.3)}',
    '.sd-sg-link{margin-top:8px;border:0;background:none;color:var(--muted);font:700 14.5px var(--font-body);padding:12px;cursor:pointer}body.dark .sd-sg-link{color:#AFC0DA}',
    '.sd-scr-aperto{position:relative;display:inline-block;margin:110px 0 28px}.sd-scr-aperto img{display:block;width:min(56vw,220px);height:auto;filter:drop-shadow(0 0 46px rgba(255,220,140,.55))}',
    '.sd-scr-aperto .sd-scr-box.aperto{position:absolute;left:50%;top:-46%;transform:translateX(-50%);font-size:84px;margin:0!important;animation:sdEsce .7s .15s cubic-bezier(.2,1.4,.4,1) both}',
    '@keyframes sdEsce{from{opacity:0;transform:translate(-50%,60%) scale(.3)}to{opacity:1;transform:translate(-50%,0) scale(1)}}',
    '#s-sd-scrigno{padding:0;background:#5CC3FF}.sd-scr{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;color:#fff}',
    '.sd-scr-in{cursor:pointer;padding:20px;width:100%}.sd-scr-in small{display:block;font:900 20px var(--font-display);letter-spacing:.14em;margin-bottom:20px;min-height:24px}',
    '.sd-scr-box{font-size:150px;line-height:1;display:inline-block;filter:drop-shadow(0 20px 30px rgba(0,60,140,.35));transition:transform .15s}.sd-scr-box.t1{transform:rotate(-8deg) scale(1.05)}.sd-scr-box.t2{transform:rotate(8deg) scale(1.1)}.sd-scr-box.aperto{animation:sdApri .6s cubic-bezier(.2,1.4,.4,1) both}',
    '@keyframes sdApri{from{transform:scale(.4);opacity:0}to{transform:scale(1);opacity:1}}',
    '.sd-scr-dots{display:flex;justify-content:center;gap:16px;margin:34px 0 22px}.sd-scr-dots i{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.35)}.sd-scr-dots i.on{background:#fff}',
    /* 0.9.265, Andrea: "+30 monete" stava attaccato alla moneta (l'emoji grande sborda sotto la sua riga) */
    '.sd-scr-in .sd-scr-box.aperto{line-height:1.15;margin-bottom:28px}',
    '.sd-scr-in b{display:block;margin-top:4px;font:900 26px var(--font-display)}.sd-scr-in p{margin:8px auto 24px;max-width:30ch;font:600 15px/1.5 var(--font-body)}.sd-scr-cta{width:auto;padding-inline:44px;background:#fff;color:#0075E3}',
    /* la fine della tappa */
    '#s-sd-fine{padding:0;background:#001E44}.sd-fine{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:20px}',
    '.sd-fine-in{width:100%;text-align:center;color:#fff}.sd-fine-in img{height:180px;width:auto;filter:drop-shadow(0 12px 22px rgba(0,0,0,.45))}',
    '.sd-fine-in h2{margin:14px 0 6px;font:900 28px/1.15 var(--font-display);color:#fff}.sd-fine-in p{margin:0 0 22px;font:600 15px var(--font-body);color:#C8D6EA}',
    '.sd-box3{display:flex;gap:10px;margin:0 0 34px}.sd-box{flex:1;border:3px solid;border-radius:16px;padding:0;overflow:hidden;background:#0A2A57}.sd-box small{display:block;padding:6px 4px;font:900 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#001E44}.sd-box b{display:block;padding:12px 4px;font:900 20px var(--font-display);color:#fff}',
    '.sd-box{position:relative;opacity:0;transform:translateY(16px) scale(.86)}',
    '.sd-box.via{animation:sdPop .5s cubic-bezier(.2,.9,.3,1.25) forwards}',
    '@keyframes sdPop{to{opacity:1;transform:none}}',
    '@property --sdA{syntax:"<angle>";inherits:false;initial-value:0deg}',
    '.sd-box.giro{border-color:transparent;background:linear-gradient(#0A2A57,#0A2A57) padding-box,conic-gradient(from var(--sdA),#F6CCE4 0 55%,#FF7A59 72%,#FFD166 84%,#F6CCE4 100%) border-box}',
    '.sd-box.giro.via{animation:sdPop .5s cubic-bezier(.2,.9,.3,1.25) forwards,sdGiro 2.2s linear .5s infinite}',
    '@keyframes sdGiro{to{--sdA:360deg}}',
    '.sd-x2{font-style:normal;margin-left:6px;padding:2px 7px;border-radius:99px;background:#FFD166;color:#3A2A00;font:900 12px var(--font-body)}',
    '.sd-legg-cta{background:linear-gradient(135deg,#E63946,#C42B38) !important;color:#FFFFFF !important;box-shadow:0 5px 0 #8E1E28 !important}',
    '.sd-sheet-in.legg h3{color:#FF9F1C}',
    '.sd-boost{display:flex;align-items:center;gap:10px;margin:0 0 10px;padding:10px 14px;border-radius:14px;background:linear-gradient(135deg,#FFD166,#FF9F1C);color:#3A2200}.sd-boost span{font-size:20px}.sd-boost b{font:900 14px var(--font-body)}.sd-boost small{margin-left:auto;font:700 12.5px var(--font-body)}.sd-boost i{font-style:normal;font-variant-numeric:tabular-nums}',
    '.sd-nodo.legg{background:linear-gradient(180deg,#FFD166,#FF9F1C) !important;box-shadow:0 7px 0 #B86A00,0 10px 22px rgba(255,159,28,.35) !important;color:#3A2200 !important}',
    '.sd-box.gialla{border-color:#3F9FF4}.sd-box.gialla small{background:#3F9FF4}.sd-box.gialla b{color:#BCE0FF}.sd-box.verde{border-color:#F6CCE4}.sd-box.verde small{background:var(--dream)}.sd-box.verde b{color:#F6CCE4}.sd-box.ciano{border-color:#22D3EE}.sd-box.ciano small{background:linear-gradient(90deg,#22D3EE,#3B82F6);color:#062240}.sd-box.ciano b{color:#67E8F9}.sd-box.blu{border-color:#C1DBFF}.sd-box.blu small{background:#C1DBFF}.sd-box.blu b{color:#DDFEFC}',
    '.sd-fine-cta{background:#0075E3;color:#fff;box-shadow:0 5px 0 #005BB0;font-weight:900;letter-spacing:.06em;text-transform:uppercase}',
    /* la schermata della serie */
    /* 0.9.294, Andrea: "Prossima tappa e condividi tagliati in fondo": la pagina era alta quanto lo schermo e quello che
       non ci stava finiva sotto il bordo. Adesso scorre, e sugli schermi bassi il Genio e il numero si fanno piu' piccoli. */
    '#s-sd-serie{padding:0;background:#001E44}.sd-ser{position:absolute;inset:0;overflow-y:auto;display:flex;justify-content:center;padding:calc(18px + env(safe-area-inset-top)) 20px calc(24px + env(safe-area-inset-bottom))}',
    '.sd-ser-in{width:100%;min-height:100%;height:auto;display:flex;flex-direction:column;align-items:center;color:#fff;text-align:center}',
    '@media (max-height:780px){.sd-ser-genio{height:150px!important}.sd-ser-genio img{height:140px!important}.sd-ser-num{height:112px!important}.sd-ser-n{font-size:92px!important}.sd-ser-fumetto{margin:4px 0 14px!important}.sd-ser-eti{margin:4px 0 18px!important}.sd-ser-sett{margin-bottom:20px!important}}',
    '.sd-piano{text-align:center}.sd-piano-genio{display:block;width:110px;height:auto;margin:6px auto 18px}.sd-piano h3{margin:0 0 14px}.sd-piano p{margin:0 0 28px}.sd-piano .sd-btn-link{margin-top:12px}',
    /* 0.9.275 il tuo primo passo: colori del brand (blu, azzurri, gradiente rosa-azzurro), niente giallo */
    '#s-sd-primo{background:var(--bg)}.sd-pp{min-height:100%;padding:0 18px calc(env(safe-area-inset-bottom,0px) + 24px)}',
    '.sd-pp-top{display:flex;align-items:center;gap:10px;padding:calc(env(safe-area-inset-top,0px) + 10px) 0 4px}.sd-pp-top small{font:800 12px var(--font-display);letter-spacing:.12em;color:#0075E3}',
    '.sd-pp-in{display:flex;flex-direction:column;align-items:stretch;text-align:center}.sd-pp-genio{width:118px;height:auto;margin:4px auto 2px;filter:drop-shadow(0 10px 18px rgba(0,117,227,.25))}',
    '.sd-pp-in h2{margin:20px 0 18px;font:800 22px/1.25 var(--font-display);color:var(--navy)}.sd-pp-sub{margin:0 0 28px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.sd-pp-sogno{align-self:center;max-width:92%;margin:0 0 22px;padding:8px 14px;border-radius:14px;background:var(--dream);color:#0E2350;font:700 13.5px/1.35 var(--font-body)}',
    '.sd-pp-lista{display:flex;flex-direction:column;gap:12px;margin:0 0 36px}.sd-pp-voce{display:flex;align-items:center;gap:14px;text-align:left;border:2px solid var(--line);background:var(--card);border-radius:16px;padding:16px;cursor:pointer;color:var(--ink);transition:transform .15s,border-color .15s}',
    '.sd-pp-voce:active{transform:scale(.98)}.sd-pp-voce span{flex:0 0 26px;height:26px;border-radius:50%;border:2px solid var(--line);display:flex;align-items:center;justify-content:center;font:900 14px var(--font-body);color:#fff}.sd-pp-voce b{font:700 14.5px/1.35 var(--font-body)}',
    '.sd-pp-voce.on{border-color:#0075E3;background:var(--blue-soft)}.sd-pp-voce.on span{background:#0075E3;border-color:#0075E3}',
    '.sd-pp-passo{margin:10px 0 32px;padding:18px 16px;border-radius:20px;background:var(--dream);color:#0E2350;box-shadow:0 10px 26px rgba(0,117,227,.14)}.sd-pp-passo b{display:block;font:800 18px/1.35 var(--font-display)}.sd-pp-passo p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:#33476A}.sd-pp-passo small{display:inline-block;margin-top:10px;font:800 13px var(--font-body);color:#0075E3}',
    '#s-sd-missioni{background:#0B1530}.sd-mis{min-height:100%;padding:0 20px;display:flex}.sd-mis-in{flex:1;display:flex;flex-direction:column;justify-content:center;gap:22px;padding:calc(env(safe-area-inset-top,0px) + 30px) 0 calc(env(safe-area-inset-bottom,0px) + 24px)}.sd-mis-in h2{margin:0;text-align:center;font:900 28px var(--font-display);color:#FFB020}',
    '.sd-mis-card{border:2px solid #22345A;border-radius:22px;overflow:hidden;flex:none}.sd-mis-r{padding:14px 16px;border-top:2px solid #22345A}.sd-mis-r:first-child{border-top:0}.sd-mis-r b{display:block;margin-bottom:10px;font:800 15.5px var(--font-body);color:#fff}',
    '.sd-mis-riga{display:flex;align-items:center;gap:10px}.sd-mis-bar{position:relative;flex:1;height:26px;border-radius:99px;background:#22345A;overflow:hidden}.sd-mis-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(180deg,#FFB020,#FF8A00);transition:width 1.1s cubic-bezier(.3,1,.4,1)}.sd-mis-bar span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:900 13px var(--font-body);color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.4)}',
    '.sd-mis-ico{font-size:30px;filter:grayscale(.3)}.sd-mis-ico.pronto{filter:none;animation:sdMisSalta 1s ease-in-out infinite}@keyframes sdMisSalta{50%{transform:translateY(-6px) rotate(-6deg)}}',
    '.sd-mis-cta{margin-top:6px !important;flex:none;width:100%;background:#3F9FF4 !important;color:#062240 !important;box-shadow:0 5px 0 #1E6FBF;font-weight:900;letter-spacing:.08em}',
    '.sd-sheet-in{position:relative}.sd-x{position:absolute;top:14px;right:14px;z-index:2;width:38px;height:38px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy,#14234A);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .sd-x{background:rgba(255,255,255,.1);color:#fff}',
    '.sd-task{text-align:center;padding-top:22px}.sd-task-img{width:76px;height:76px;margin:10px auto 18px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:40px;line-height:1;box-shadow:0 8px 20px rgba(0,30,68,.18)}.sd-task h3{margin:0 0 12px;padding:0 28px}.sd-task p{margin:0 auto 20px;max-width:34ch}.sd-task-badge{display:flex;justify-content:center;flex-wrap:wrap;gap:10px;margin:0 0 28px}.sd-task-badge span{padding:7px 12px;border-radius:99px;background:rgba(0,117,227,.1);font:800 12.5px var(--font-body);color:#0075E3}.sd-task-badge .pri.alta{background:rgba(230,57,70,.12);color:#E63946}.sd-task-badge .pri.bassa{background:rgba(107,122,144,.14);color:#6B7A90}.sd-task-badge .xp{background:#0075E3;color:#fff}',
    '.sd-task-passi{text-align:left;margin:0 0 24px;padding:12px 14px;border-radius:14px;background:rgba(0,117,227,.06)}.sd-task-passi small{display:block;font:700 10.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:6px}.sd-task-passi ol{margin:0;padding-left:20px}.sd-task-passi li{font:500 14px/1.45 var(--font-body);color:var(--navy);margin:0 0 4px}body.dark .sd-task-passi li{color:#fff}',
    '.sd-task-due{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:0 0 28px}.sd-task-due button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 8px;border:1.5px solid var(--line);border-radius:16px;background:var(--card,#fff);font:800 13.5px var(--font-body);color:var(--navy);cursor:pointer;box-shadow:0 3px 0 var(--line)}.sd-task-due button span{font-size:24px}body.dark .sd-task-due button{background:#12203A;border-color:#22345A;color:#fff;box-shadow:0 3px 0 #22345A}',
    '.sd-task-go{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;background:#E63946 !important;color:#fff !important;font-weight:900;letter-spacing:.06em}.sd-task-go .chev{border-color:#fff !important;color:#fff}.sd-task .sd-btn-sec{margin-top:14px}.sd-task .sd-btn-link{margin-top:10px}',
    '.sd-ricostruisce .sd-nodo,.sd-ricostruisce .sd-eti,.sd-ricostruisce .sd-genio{opacity:0;transform:scale(.35) translateY(18px);transition:opacity .35s ease,transform .5s cubic-bezier(.2,1.5,.4,1)}.sd-ricostruisce .sd-rc-on{opacity:1;transform:none}',
    '.sd-rc-ban{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 86px);z-index:9993;display:flex;align-items:center;gap:10px;padding:12px 18px;border-radius:99px;background:#0E2350;color:#fff;box-shadow:0 12px 30px rgba(0,20,60,.35);transform:translate(-50%,-20px);opacity:0;transition:transform .35s cubic-bezier(.2,1.4,.4,1),opacity .3s}.sd-rc-ban.on{transform:translate(-50%,0);opacity:1}.sd-rc-ban span{font-size:20px}.sd-rc-ban b{font:800 14.5px var(--font-body)}',
    '.sd-ser-fumetto{position:relative;margin:8px 0 22px;padding:16px 18px;border:2px solid #3F6FA8;border-radius:18px;background:#0A2A57;font:600 16px/1.45 var(--font-body);color:#fff;max-width:340px}.sd-ser-fumetto::after{content:"";position:absolute;left:50%;bottom:-9px;width:14px;height:14px;background:#0A2A57;border-right:2px solid #3F6FA8;border-bottom:2px solid #3F6FA8;transform:translateX(-50%) rotate(45deg)}',
    '.sd-ser-genio{position:relative;height:200px;display:flex;align-items:flex-end;justify-content:center}.sd-ser-genio img{position:relative;height:190px;width:auto;filter:drop-shadow(0 14px 24px rgba(0,0,0,.45));animation:sdSerSu .7s cubic-bezier(.2,1.4,.4,1) both}.sd-ser-fiamma{position:absolute;bottom:20px;left:50%;transform:translateX(-62%);font-size:150px;line-height:1;opacity:.95;filter:drop-shadow(0 0 30px rgba(246,204,228,.45))}',
    '@keyframes sdSerSu{from{transform:scale(.6) translateY(30px);opacity:0}to{transform:none;opacity:1}}',
    '.sd-ser-num{position:relative;display:flex;justify-content:center;align-items:center;margin-top:8px;height:150px}.sd-ser-n{position:relative;z-index:2;margin:0;font:900 120px/1 var(--font-display);color:#E63946;-webkit-text-stroke:6px #fff;paint-order:stroke fill;text-shadow:0 6px 24px rgba(0,10,30,.55);animation:sdSerSu .6s .15s cubic-bezier(.2,1.4,.4,1) both}.sd-ser-num .sd-ser-fiamma{position:absolute;z-index:1;left:50%;top:50%;bottom:auto;font-size:150px;line-height:1;opacity:0;transform:translate(-50%,-54%) scale(.3);animation:sdFiamma .8s 1s cubic-bezier(.2,1.5,.4,1) forwards;filter:drop-shadow(0 0 30px rgba(255,120,0,.5))}@keyframes sdFiamma{0%{opacity:0;transform:translate(-50%,-54%) scale(.3)}60%{opacity:.95;transform:translate(-50%,-54%) scale(1.18)}100%{opacity:.9;transform:translate(-50%,-54%) scale(1)}}.sd-scr-piu{margin-top:14px}',
    '.sd-ser-eti{margin:6px 0 26px;font:900 26px var(--font-display);color:#BCE0FF}.sd-ser-sett{margin-bottom:28px}',
    /* 0.9.277, Andrea: "il fuoco attaccato ai numeri" e "perche' hai tolto il contorno bianco al numero rosso".
       Fiamma, numero, scritta e settimana con aria fra loro (40 / 20 / 44 / 32 px); il numero resta rosso col bordo bianco. */
    '.sd-ser-fuoco{justify-content:flex-start;padding-top:7vh}.sd-ser-grande{font-size:132px;line-height:1;margin:0 0 40px;filter:drop-shadow(0 0 34px rgba(255,110,0,.45));animation:sdSerSu .7s cubic-bezier(.2,1.4,.4,1) both}',
    '.sd-ser-fuoco .sd-ser-n{font:900 104px/1 var(--font-display);color:#E63946;-webkit-text-stroke:6px #fff;paint-order:stroke fill;text-shadow:0 6px 24px rgba(0,10,30,.55);margin:0}',
    '.sd-ser-fuoco .sd-ser-eti{margin:14px 0 24px;color:#BCE0FF}.sd-ser-fuoco .sd-ser-sett{margin-bottom:18px}',
    /* 0.9.296: settimana, frase e pulsanti in un blocco solo, in fondo */
    '.sd-ser-giu{margin-top:auto;width:100%;display:flex;flex-direction:column;align-items:center}.sd-ser-giu .sd-ser-sett{margin:0 0 18px}.sd-ser-giu .sd-ser-frase{margin:0 0 20px}.sd-ser-giu .sd-ser-bot{margin-top:0}',
    '.sd-ser-g i{animation:sdSerSu .45s var(--d,.9s) cubic-bezier(.2,1.5,.4,1) both}.sd-ser-g.fatto i{color:#fff}',
    '.sd-ser-ancora{margin:14px auto 0;border:0;background:none;color:#BCE0FF;font:800 14.5px var(--font-body);text-decoration:underline;text-underline-offset:3px;cursor:pointer}',
    '.sd-ser-grande.b1{filter:drop-shadow(0 0 22px rgba(255,110,0,.35))}.sd-ser-grande.b2{filter:drop-shadow(0 0 40px rgba(255,110,0,.55))}',
    '.sd-ser-grande.b3{filter:drop-shadow(0 0 58px rgba(255,120,0,.7)) drop-shadow(0 0 18px rgba(255,200,80,.5))}.sd-ser-grande.b4{filter:drop-shadow(0 0 80px rgba(255,120,0,.85)) drop-shadow(0 0 28px rgba(255,210,90,.65))}',
    '.sd-ser-grande.b3,.sd-ser-grande.b4{animation:sdSerSu .7s cubic-bezier(.2,1.4,.4,1) both,sdSerBagl 2.4s .8s ease-in-out infinite}@keyframes sdSerBagl{50%{transform:scale(1.06)}}',
    '.sd-ser-frase{margin:0 0 32px;max-width:320px;font:600 16px/1.55 var(--font-body);color:#DCE8F7}',
    /* con il Genio la fiamma non c'e' (o il Genio, o la fiamma): il numero sta da solo, con aria */
    '.sd-ser-solo{margin-top:28px;height:auto}.sd-ser-solo + .sd-ser-eti{margin:20px 0 40px}',
    '.sd-ser-sett{display:flex;justify-content:center;gap:9px;width:100%;max-width:360px}.sd-ser-g{flex:1;display:flex;flex-direction:column;align-items:center;gap:8px}.sd-ser-g small{font:900 15px var(--font-display);color:#5F7FAA}.sd-ser-g.qui small{color:#BCE0FF}',
    '.sd-ser-g i{width:40px;height:40px;border-radius:50%;background:#16365F;display:flex;align-items:center;justify-content:center;font:900 18px var(--font-display);font-style:normal;color:#001E44}.sd-ser-g.fatto i{background:var(--dream)}.sd-ser-g.coperto i{background:#0A2A57;border:2px solid #3F9FF4;font-size:16px}.sd-ser-g.oggi i{border:3px solid #3F9FF4;background:transparent}',
    '.sd-ser-bot{margin-top:auto;display:flex;gap:12px;width:100%}.sd-ser-share{flex:none;width:58px;border:2px solid #3F6FA8;border-radius:18px;background:transparent;color:#BCE0FF;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.sd-ser-cta{flex:1;margin:0;background:#0075E3;color:#fff;box-shadow:0 5px 0 #005BB0;font-weight:900;letter-spacing:.06em;text-transform:uppercase}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
