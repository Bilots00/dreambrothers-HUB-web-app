/* ===========================================================================================
   LA PROVA SOCIALE IN TEMPO REALE E LA MISSIONE (socialproof.js)

   Tre righe vive e un carosello, tutti inseriti da qui senza toccare i file delle schede:
     · START: una riga sotto al pulsante di Full Focus (dentro alla carta dell'oblo');
     · Mappa: una riga che gira ogni 6 secondi sotto alla scheda blu del capitolo;
     · Dream: in fondo alla pagina, un carosello a due schede (chi lavora al proprio sogno
       adesso, e La missione con la catena dei sogni accesi e l'anello del traguardo).

   I NUMERI SONO VERI. Arrivano dal server (/api/focuslock/socialproof/stato) e sono solo
   conteggi: nessun nome, nessun id, nessun testo dell'utente. Sotto le soglie la riga sparisce
   o passa al conteggio di oggi; mai un numero inventato. I numeri finti esistono solo con la
   chiave di prova fl_sp_mock (1 | medio | basso), che l'app non scrive mai da sola.

   IL BATTITO. Ogni 60 secondi mentre gira una sessione di Full Focus o mentre si fa un livello
   della mappa, e subito quando lo stato cambia. Con il battito partono gli eventi che contano
   per il sogno acceso: un livello superato e una sessione finita da almeno 25 minuti. Si
   leggono da fl_ff_session, fl_ff_hist e fl_sd, senza modificare fullfocus.js o
   sentiero-mappa.js. La categoria viene dai tag della lettura del Genio (chiavi fisse), mai
   dalle parole scritte dall'utente.

   Testi e soglie: content/socialproof.json (config). Avatar generici: img/avatar/a1..a6.svg.
   =========================================================================================== */

const SP = {
  cfg: { heartbeatSec: 60, refreshSec: 60, liveMin: 50, todayMin: 10, categoryMin: 30, rotateSec: 6, scrollPausaMs: 1500,
    milestones: [1000, 10000, 100000, 1000000], avvisiAlGiorno: 1, avvisoMs: 5000, ffMinAcceso: 25, rollMs: 800 },
  testi: null, dati: null, caricatoAt: 0, inCarico: false,
  ultimi: {}, statoInviato: '', battitoAt: 0, schermo: '',
  rot: { i: 0, at: 0, scrollAt: 0 }, albero: '', obs: null, montaT: 0
};
const SP_TESTI_KEY = 'fl_sp_testi', SP_CODA = 'fl_sp_coda', SP_FF = 'fl_sp_ff', SP_SD = 'fl_sp_sd', SP_VISTI = 'fl_sp_visti', SP_AVVISO = 'fl_sp_avviso_g';
const SP_SCHERMI_CAMMINO = ['s-esercizio', 's-sd-esame', 's-sd-missioni', 's-sd-fine', 's-genio'];
const SP_AVATAR = ['img/avatar/a1.svg', 'img/avatar/a2.svg', 'img/avatar/a3.svg', 'img/avatar/a4.svg', 'img/avatar/a5.svg', 'img/avatar/a6.svg'];

/* ---------------------------------------------------------------- utilita' */
function spLs(k, def){ try{ const v = localStorage.getItem(k); return v == null ? def : JSON.parse(v); }catch(_){ return def; } }
function spLsSet(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function spEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
/* 12525 -> 12.525 (separatore delle migliaia italiano, anche a quattro cifre) */
function spFmt(n){ n = Math.max(0, Math.round(+n || 0)); return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
/* la percentuale con la virgola: due decimali, quattro sotto lo 0,01%, senza zeri in coda */
function spPct(v, goal){
  if (!goal || v <= 0) return '0';
  const p = Math.min(100, v / goal * 100);
  if (p >= 100) return '100';
  let s = p.toFixed(p < 0.01 ? 4 : 2);
  s = s.replace(/\.?0+$/, '');
  return s.replace('.', ',');
}
function spGiorno(){ const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function spDevice(){ try{ return (typeof frDevice === 'function') ? frDevice() : (localStorage.getItem('fl_device_id') || ''); }catch(_){ return ''; } }
function spMock(){ try{ return localStorage.getItem('fl_sp_mock') || ''; }catch(_){ return ''; } }

/* ---------------------------------------------------------------- i testi */
function spT(path, vars){
  let v = SP.testi;
  String(path).split('.').forEach(function(p){ v = (v && typeof v === 'object') ? v[p] : undefined; });
  if (Array.isArray(v)) return v;
  let s = typeof v === 'string' ? v : '';
  if (vars) Object.keys(vars).forEach(function(x){ s = s.split('{' + x + '}').join(String(vars[x])); });
  return s;
}
/* il modello giusto per il numero: la variante _uno quando e' 1 */
function spTn(path, n){
  if (n === 1){ const u = spT(path + '_uno'); if (u) return u; }
  return spT(path);
}
async function spTestiCarica(){
  if (!SP.testi){ SP.testi = spLs(SP_TESTI_KEY, null); spCfgApplica(); }
  try{
    const r = await fetch('content/socialproof.json', { cache: 'no-cache' });
    const j = await r.json();
    if (j && j.start){ SP.testi = j; spLsSet(SP_TESTI_KEY, j); spCfgApplica(); }
  }catch(_){ }
}
function spCfgApplica(){ if (SP.testi && SP.testi.config) Object.assign(SP.cfg, SP.testi.config); }

/* ---------------------------------------------------------------- la categoria (tag del Genio) */
const SP_DA_SOGNO = { progetto: 'business', voce: 'creativita', passione: 'studio', corpo: 'fitness', capolavoro: 'creativita', fede: 'fede', liberta: 'viaggi' };
const SP_DA_TARGET = { studio: 'studio', corpo: 'fitness', lavoro: 'business', arte: 'creativita', carriera: 'carriera' };
function spCategoria(){
  let g = null;
  try{ g = (typeof gnDati === 'function') ? gnDati() : spLs('fl_intro', null); }catch(_){ g = null; }
  if (g){
    /* il sogno scritto a parole sue non dice la categoria con certezza: si usa la frase di tutti */
    if (g.sognoK === 'scrivo') return '';
    if (g.sognoK && SP_DA_SOGNO[g.sognoK]) return SP_DA_SOGNO[g.sognoK];
    if (g.sognoK && g.sognoK !== 'meglio') return '';
    if (g.target && SP_DA_TARGET[g.target]) return SP_DA_TARGET[g.target];
  }
  const o = spLs('fl_oracle', null);
  if (o && o.target && SP_DA_TARGET[o.target] && (+o.conf || 0) >= 50) return SP_DA_TARGET[o.target];
  return '';
}

/* ---------------------------------------------------------------- il battito */
function spStatoAdesso(){
  const run = spLs('fl_ff_session', null);
  if (run && !run.pausedAt && !run.meditazione && (!run.endAt || run.endAt > Date.now())) return 'focus';
  let sc = SP.schermo;
  try{ if (!sc && typeof order !== 'undefined' && typeof cur !== 'undefined') sc = order[cur]; }catch(_){ }
  if (SP_SCHERMI_CAMMINO.indexOf(sc) >= 0) return 'path';
  return '';
}
function spCodaAdd(tipo, at){
  const c = spLs(SP_CODA, []) || [];
  if (c.some(function(e){ return e.tipo === tipo && e.at === at; })) return;
  c.push({ tipo: tipo, at: at });
  spLsSet(SP_CODA, c.slice(-20));
}
/* Gli eventi che contano, letti dallo stato che l'app tiene gia'. La prima volta si manda il
   piu' vecchio (serve al server per sapere se il sogno si e' acceso entro 7 giorni). */
function spOsservaEventi(){
  const minMs = (SP.cfg.ffMinAcceso || 25) * 60000;
  try{
    const h = (typeof ffHist === 'function') ? ffHist() : spLs('fl_ff_hist', []);
    const buone = (h || []).filter(function(x){ return x && x.ok && !x.meditazione && (x.spentMs || (x.min || 0) * 60000) >= minMs && x.at; });
    const visto = spLs(SP_FF, null);
    if (buone.length){
      const max = Math.max.apply(null, buone.map(function(x){ return x.at; }));
      if (visto == null){ spCodaAdd('focus25', Math.min.apply(null, buone.map(function(x){ return x.at; }))); if (Date.now() - max < 2 * 86400000) spCodaAdd('focus25', max); }
      else if (max > visto) spCodaAdd('focus25', max);
      if (visto == null || max > visto) spLsSet(SP_FF, max);
    } else if (visto == null) spLsSet(SP_FF, 0);
  }catch(_){ }
  try{
    const s = spLs('fl_sd', null);
    const f = (s && s.fatti) || {};
    const t = Object.keys(f).filter(function(k){ return k.indexOf('sc:') !== 0 && typeof f[k] === 'number' && f[k] > 0; }).map(function(k){ return f[k]; });
    const visto = spLs(SP_SD, null);
    if (t.length){
      const max = Math.max.apply(null, t);
      if (visto == null){ spCodaAdd('livello', Math.min.apply(null, t)); if (Date.now() - max < 2 * 86400000) spCodaAdd('livello', max); }
      else if (max > visto) spCodaAdd('livello', max);
      if (visto == null || max > visto) spLsSet(SP_SD, max);
    } else if (visto == null) spLsSet(SP_SD, 0);
  }catch(_){ }
}
async function spBattito(forza){
  if (typeof frApi !== 'function') return;
  const device = spDevice(); if (!device) return;
  spOsservaEventi();
  const stato = spStatoAdesso();
  const coda = spLs(SP_CODA, []) || [];
  const dovuto = (stato && (stato !== SP.statoInviato || Date.now() - SP.battitoAt >= SP.cfg.heartbeatSec * 1000))
    || (!stato && SP.statoInviato) || coda.length || forza;
  if (!dovuto) return;
  try{
    await frApi('POST', '/api/focuslock/socialproof/battito', { device: device, stato: stato, cat: stato === 'focus' ? spCategoria() : '', eventi: coda });
    SP.statoInviato = stato; SP.battitoAt = Date.now();
    const resto = (spLs(SP_CODA, []) || []).filter(function(e){ return !coda.some(function(x){ return x.tipo === e.tipo && x.at === e.at; }); });
    spLsSet(SP_CODA, resto);
  }catch(_){ }
}

/* ---------------------------------------------------------------- i dati */
function spDatiMock(){
  const m = spMock();
  const j = function(n){ return Math.max(0, Math.round(n * (1 + (Math.random() - 0.5) * 0.01))); };
  if (m === 'basso') return { active_focus_now: 3, on_path_now: 1, levels_passed_today: 4, focus_today: 6, worked_on_dream_today: 7, dreams_lit: 2,
    active_by_category_now: { business: 1, studio: 1, fitness: 0, creativita: 0, carriera: 0, viaggi: 0, fede: 0 },
    me: { diretti: 0, catena: 0, albero: [], altri: 0, accesi: [] } };
  if (m === 'medio') return { active_focus_now: 31, on_path_now: 12, levels_passed_today: 64, focus_today: 412, worked_on_dream_today: 530, dreams_lit: 37,
    active_by_category_now: { business: 9, studio: 8, fitness: 4, creativita: 3, carriera: 4, viaggi: 2, fede: 1 },
    me: { diretti: 1, catena: 1, albero: [{ id: 'm1', nome: 'Giulia', gen2: 0, gen3: 0, oltre: 0 }], altri: 0, accesi: [{ id: 'm1', nome: 'Giulia' }] } };
  return { active_focus_now: j(12525), on_path_now: j(3410), levels_passed_today: j(8240), focus_today: j(40210), worked_on_dream_today: j(51200), dreams_lit: 4321,
    active_by_category_now: { business: j(3120), studio: j(4210), fitness: j(1830), creativita: j(1270), carriera: j(1105), viaggi: j(560), fede: j(430) },
    me: { diretti: 2, catena: 9, albero: [{ id: 'm1', nome: 'Giulia', gen2: 3, gen3: 2, oltre: 1 }, { id: 'm2', nome: null, gen2: 1, gen3: 0, oltre: 0 }], altri: 0, accesi: [{ id: 'm1', nome: 'Giulia' }, { id: 'm2', nome: null }] } };
}
async function spCarica(forza){
  if (SP.inCarico) return;
  if (!forza && Date.now() - SP.caricatoAt < 10000) return;
  SP.inCarico = true;
  try{
    if (!SP.testi) await spTestiCarica();
    let d = null;
    if (spMock()) d = spDatiMock();
    else if (typeof frApi === 'function'){
      try{ d = await frApi('GET', '/api/focuslock/socialproof/stato?device=' + encodeURIComponent(spDevice())); }catch(_){ d = null; }
      if (d && d.error) d = null;
    }
    if (d){
      SP.dati = d; SP.caricatoAt = Date.now();
      /* solo i numeri del traguardo e della catena restano dopo un riavvio: non dicono "adesso" */
      spLsSet('fl_sp_cache', { dreams_lit: d.dreams_lit, me: d.me ? { diretti: d.me.diretti, catena: d.me.catena } : null });
      if (d.me) spAvvisi(d.me);
    }
  }finally{ SP.inCarico = false; }
  spMonta(true);
}

/* ---------------------------------------------------------------- i numeri che rotolano */
function spNum(k, n, cls){
  const prima = SP.ultimi[k];
  return '<span class="sp-n' + (cls ? ' ' + cls : '') + '" data-k="' + spEsc(k) + '" data-to="' + Math.round(n) + '">' + spFmt(prima == null ? n : prima) + '</span>';
}
function spRotola(root){
  (root || document).querySelectorAll('.sp-n[data-to]').forEach(function(el){
    const k = el.getAttribute('data-k'), to = +el.getAttribute('data-to');
    el.removeAttribute('data-to');
    const da = SP.ultimi[k];
    SP.ultimi[k] = to;
    if (da == null || da === to){ el.textContent = spFmt(to); return; }
    const t0 = performance.now(), ms = SP.cfg.rollMs || 800;
    const passo = function(t){
      const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
      el.textContent = spFmt(da + (to - da) * e);
      if (p < 1 && el.isConnected) requestAnimationFrame(passo);
    };
    requestAnimationFrame(passo);
  });
}
/* una frase con il numero dentro: il numero e' un elemento a parte, per farlo rotolare */
function spFrase(tpl, k, n){
  const p = String(tpl).split('{n}');
  return spEsc(p[0]) + spNum(k, n) + spEsc(p.slice(1).join(''));
}

/* ---------------------------------------------------------------- START */
function spStart(){
  const go = document.querySelector('#tab-sveglia .oblo-go');
  if (!go || !go.parentNode) return;
  let el = go.parentNode.querySelector(':scope > .sp-start');
  if (!el){ el = document.createElement('p'); el.className = 'sp-start'; el.hidden = true; el.setAttribute('aria-live', 'polite'); go.insertAdjacentElement('afterend', el); }
  else if (el.previousElementSibling !== go) go.insertAdjacentElement('afterend', el);
  const d = SP.dati;
  if (!d || !SP.testi || (d.focus_today || 0) < SP.cfg.todayMin){ el.hidden = true; return; }
  const live = (d.active_focus_now || 0) >= SP.cfg.liveMin;
  const n = live ? d.active_focus_now : d.focus_today;
  const chiave = (live ? 'live' : 'oggi') + ':' + n;
  if (el.dataset.v === chiave && !el.hidden) return;
  el.dataset.v = chiave;
  el.classList.toggle('live', live);
  el.innerHTML = (live ? '<i class="sp-pulse" aria-hidden="true"></i>' : '') + '<span>' + spFrase(spTn(live ? 'start.live' : 'start.oggi', n), live ? 'startLive' : 'startOggi', n) + '</span>';
  el.hidden = false;
  spRotola(el);
}

/* ---------------------------------------------------------------- Mappa */
function spMappaOpzioni(){
  const d = SP.dati;
  if (!d || !SP.testi || (d.levels_passed_today || 0) < SP.cfg.todayMin) return [];
  const o = [];
  if ((d.on_path_now || 0) >= SP.cfg.liveMin) o.push({ k: 'mappaA', live: true, n: d.on_path_now, tpl: spTn('mappa.live', d.on_path_now) });
  o.push({ k: 'mappaB', live: false, n: d.levels_passed_today, tpl: spTn('mappa.oggi', d.levels_passed_today) });
  return o;
}
function spMappa(){
  const testa = document.querySelector('#mppSentiero .sd-testa');
  if (!testa || !testa.parentNode) return;
  let el = testa.parentNode.querySelector(':scope > .sp-mappa');
  if (!el){ SP.rot.at = Date.now(); el = document.createElement('p'); el.className = 'sp-mappa'; el.hidden = true; el.setAttribute('aria-live', 'polite'); testa.insertAdjacentElement('afterend', el); }
  else if (el.previousElementSibling !== testa) testa.insertAdjacentElement('afterend', el);
  const o = spMappaOpzioni();
  if (!o.length){ el.hidden = true; el.dataset.v = ''; return; }
  const x = o[SP.rot.i % o.length];
  const chiave = x.k + ':' + x.n;
  if (el.dataset.v === chiave && !el.hidden) return;
  el.dataset.v = chiave;
  el.classList.toggle('live', x.live);
  el.innerHTML = (x.live ? '<i class="sp-pulse" aria-hidden="true"></i>' : '') + '<span>' + spFrase(x.tpl, x.k, x.n) + '</span>';
  el.hidden = false;
  spRotola(el);
}
/* ogni 6 secondi l'altra frase, con una dissolvenza; ferma mentre si scorre */
function spMappaGira(){
  const o = spMappaOpzioni();
  if (o.length < 2) return;
  if (Date.now() - SP.rot.scrollAt < SP.cfg.scrollPausaMs) return;
  if (Date.now() - SP.rot.at < SP.cfg.rotateSec * 1000) return;
  const el = document.querySelector('#mppSentiero .sp-mappa');
  if (!el || el.hidden || !el.offsetParent) return;
  SP.rot.at = Date.now();
  el.classList.add('fuori');
  setTimeout(function(){ SP.rot.i++; el.dataset.v = ''; spMappa(); el.classList.remove('fuori'); }, 320);
}

/* ---------------------------------------------------------------- Dream: il carosello */
function spAvatarDi(id){ let h = 0; String(id || '').split('').forEach(function(c){ h = (h * 31 + c.charCodeAt(0)) >>> 0; }); return SP_AVATAR[h % SP_AVATAR.length]; }
function spMiaFoto(){ try{ return localStorage.getItem('fl_avatar_img') || ''; }catch(_){ return ''; } }

function spLiveHtml(){
  const d = SP.dati;
  if (!d || !SP.testi) return '';
  const cat = spCategoria();
  const nCat = cat && d.active_by_category_now ? (d.active_by_category_now[cat] || 0) : 0;
  let tpl, n, live = true, k;
  if (cat && nCat >= SP.cfg.categoryMin){ n = nCat; tpl = spTn('dream.categorie.' + cat, n); k = 'dreamCat'; }
  else if ((d.active_focus_now || 0) >= SP.cfg.liveMin){ n = d.active_focus_now; tpl = spTn('dream.tutti', n); k = 'dreamTutti'; }
  else { n = d.worked_on_dream_today || 0; tpl = spTn('dream.oggi', n); live = false; k = 'dreamOggi'; }
  if (!live && n < SP.cfg.todayMin) return '';
  const p = String(tpl).split('{n}');
  const prima = p[0].trim(), dopo = p.slice(1).join('').trim();
  return (live ? '<span class="sp-badge"><i aria-hidden="true"></i>' + spEsc(spT('dream.badge')) + '</span>' : '')
    + (prima ? '<small class="sp-pre">' + spEsc(prima) + '</small>' : '')
    + '<div class="sp-big">' + spNum(k, n) + '</div>'
    + '<p class="sp-frase">' + spEsc(dopo) + '</p>';
}
/* 0.9.332, Andrea: "sono tutte blu e gialle: metti anche le emoji dello scienziato, dell'artista, di chi si diploma, e il rosso del brand" */
const SP_MESTIERI = ['🧑‍🔬', '🧑‍🎨', '🧑‍🎓', '🧑‍💻', '🧑‍⚕️', '🧑‍🍳', '🧑‍🚀', '🧑‍🏫', '🧑‍🎤'];
const SP_FONDI = ['#E63946', '#0075E3', '#BCE0FF', '#F0FBFF', '#E63946', '#3F9FF4', '#001E44'];
/* 0.9.337, Andrea: "le bolle fanno schifo, non le voglio rosse: devono essere bolle vere, trasparenti, con l'emoji che si vede bene,
   e devono fluttuare meglio riempiendo lo spazio". Le bolle stanno sul bordo (il centro e' del numero), salgono piano come bolle
   d'aria e respirano. Le emoji dentro al vetro; le facce disegnate tengono il loro fondo. */
function spBolleHtml(){
  const P = [[6, 8, 50, 0], [30, 3, 34, 3], [70, 5, 42, 1], [88, 20, 36, 5], [2, 34, 34, 7], [90, 46, 46, 2],
             [2, 72, 36, 4], [86, 72, 38, 6], [16, 84, 34, 8], [40, 88, 30, 3], [64, 86, 40, 5], [24, 22, 26, 9]];
  return P.map(function(p, i){
    const emoji = i % 3 !== 1;
    const dentro = emoji ? '<i style="font-size:' + Math.round(p[2] * .58) + 'px">' + SP_MESTIERI[i % SP_MESTIERI.length] + '</i>' : '<img src="' + SP_AVATAR[i % SP_AVATAR.length] + '" alt="">';
    return '<span class="sp-bolla' + (emoji ? ' vetro' : '') + '" style="left:' + p[0] + '%;top:' + p[1] + '%;width:' + p[2] + 'px;height:' + p[2] + 'px;animation-delay:-' + (p[3] * 1.9) + 's;animation-duration:' + (11 + (i % 5) * 2.5) + 's">' + dentro + '</span>';
  }).join('');
}

function spBolla(src, cls){ return '<span class="sp-b ' + (cls || '') + '"><img src="' + spEsc(src) + '" alt=""></span>'; }
function spAlberoBase(me){
  const albero = (me && me.albero) || [];
  const foto = spMiaFoto() || SP_AVATAR[0];
  let h = '<div class="sp-io">' + spBolla(foto, 'sp-b-io') + '<small>' + spEsc(spT('missione.tu')) + '</small></div>';
  /* tre fili dal centro alle tre bolle; quelli accesi portano una luce che scende */
  h += '<svg class="sp-fili" viewBox="0 0 300 56" preserveAspectRatio="none" aria-hidden="true">';
  [50, 150, 250].forEach(function(x, i){
    const acceso = !!albero[i];
    const d = 'M150 0 C150 30 ' + x + ' 24 ' + x + ' 56';
    h += '<path d="' + d + '" class="sp-filo' + (acceso ? ' on' : '') + '"/>' + (acceso ? '<path d="' + d + '" class="sp-luce" style="animation-delay:-' + (i * 0.7) + 's"/>' : '');
  });
  h += '</svg><div class="sp-posti">';
  for (let i = 0; i < 3; i++){
    const x = albero[i];
    if (!x){ h += '<div class="sp-posto vuoto"><span class="sp-b sp-b-vuoto"></span></div>'; continue; }
    let sotto = '';
    const g2 = Math.min(3, x.gen2 || 0), g3 = Math.min(3, x.gen3 || 0);
    if (g2){ sotto += '<div class="sp-g2">'; for (let j = 0; j < g2; j++) sotto += spBolla(spAvatarDi(x.id + 'g2' + j), 'sp-b-g2'); sotto += '</div>'; }
    if (g3){ sotto += '<div class="sp-g3">'; for (let j = 0; j < g3; j++) sotto += spBolla(spAvatarDi(x.id + 'g3' + j), 'sp-b-g3'); sotto += '</div>'; }
    const resto = Math.max(0, (x.gen2 || 0) - 3) + Math.max(0, (x.gen3 || 0) - 3) + (x.oltre || 0);
    if (resto) sotto += '<span class="sp-piu">' + spEsc(spT('missione.piu', { n: spFmt(resto) })) + '</span>';
    h += '<div class="sp-posto on">' + spBolla(spAvatarDi(x.id), 'sp-b-on') + '<small>' + spEsc(x.nome || spT('missione.acceso')) + '</small>' + sotto + '</div>';
  }
  h += '</div>';
  if (me && me.altri) h += '<span class="sp-piu sp-piu-altri">' + spEsc(spT('missione.piu', { n: spFmt(me.altri) })) + '</span>';
  if (!albero.length) h += '<p class="sp-vuoto">' + spEsc(spT('missione.vuoto')) + '</p>';
  return h;
}
function spTraguardo(v){
  const m = (SP.cfg.milestones || [1000]).slice().sort(function(a, b){ return a - b; });
  for (let i = 0; i < m.length; i++) if (v < m[i]) return { i: i + 1, tot: m.length, goal: m[i] };
  return { i: m.length, tot: m.length, goal: m[m.length - 1] };
}
function spAnelloHtml(v){
  const t = spTraguardo(v);
  const pct = spPct(v, t.goal);
  const tplC = String(spT('missione.anello')).split('{percentuale}');
  /* il simbolo % resta attaccato al numero grande, il resto va sotto in piccolo */
  let dopoC = tplC.slice(1).join('');
  const simbolo = /^%/.test(dopoC) ? '%' : '';
  dopoC = dopoC.replace(/^%/, '').trim();
  return '<div class="sp-anello"><svg viewBox="0 0 160 160" aria-hidden="true"><defs><linearGradient id="spGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0075E3"/><stop offset="1" stop-color="#8CC6FF"/></linearGradient></defs>'
    + '<circle cx="80" cy="80" r="68" class="sp-an-fondo"/><circle cx="80" cy="80" r="68" class="sp-an-arco" id="spArco"/></svg>'
    + '<div class="sp-an-c"><b>' + spEsc(tplC[0]) + pct + simbolo + '</b><small>' + spEsc(dopoC) + '</small></div></div>'
    + '<span class="sp-trag">' + spEsc(spT('missione.traguardo', { i: t.i, tot: t.tot })) + '</span>'
    + '<p class="sp-mondo">' + spFrase(spTn('missione.accesiMondo', v), 'mondo', v) + '</p>'
    + '<div class="sp-box"><div><small>' + spEsc(spT('missione.mancano')) + '</small>' + spNum('mancano', Math.max(0, t.goal - v)) + '</div><div><small>' + spEsc(spT('missione.obiettivo')) + '</small><b>' + spFmt(t.goal) + '</b></div></div>';
}
function spArcoImposta(v){
  const arco = document.getElementById('spArco'); if (!arco) return;
  const t = spTraguardo(v);
  const C = 2 * Math.PI * 68;
  let f = Math.min(1, v / t.goal);
  if (v > 0) f = Math.max(f, 0.012); /* un filo di luce visibile anche allo 0,4% */
  arco.style.strokeDasharray = C.toFixed(1);
  requestAnimationFrame(function(){ arco.style.strokeDashoffset = (C * (1 - f)).toFixed(1); });
}
function spMissioneHtml(){
  const m = SP.testi && SP.testi.missione; if (!m) return '';
  const br = function(a){ return (Array.isArray(a) ? a : [a]).map(spEsc).join('<br>'); };
  return '<div class="sp-mis-testo"><small class="sp-kicker">' + spEsc(m.kicker) + '</small>'
    + '<h3>' + br(m.titolo) + '</h3><p>' + br(m.corpo) + '</p><p class="sp-chiusa">' + spEsc(m.chiusa) + '</p></div>'
    + '<div class="sp-albero" id="spAlbero"></div>'
    + '<div class="sp-anello-w" id="spAnelloW"></div>'
    + '<p class="sp-tuoi" id="spTuoi"></p>'
    + '<button type="button" class="sp-regala" onclick="spRegala()"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/></svg>' + spEsc(m.bottone) + '</button>'
    + '<p class="sp-firma">' + spEsc(m.firma) + '</p>';
}
function spDreamBase(){
  const page = document.querySelector('#tab-rotta .nv-page');
  if (!page || !SP.testi) return;
  let box = document.getElementById('spDream');
  if (!box || box.parentNode !== page){
    if (box) box.remove();
    box = document.createElement('section');
    box.id = 'spDream'; box.className = 'sp-dream';
    box.innerHTML = '<div class="sp-car" id="spCar">'
      + '<div class="sp-sl sp-sl-live" aria-label="' + spEsc(spT('dream.slide')) + '"><div class="sp-bolle" aria-hidden="true">' + spBolleHtml() + '</div><div class="sp-live-c" id="spLive"></div></div>'
      + '<div class="sp-sl sp-sl-mis" aria-label="' + spEsc(spT('dream.slideMissione')) + '">' + spMissioneHtml() + '</div>'
      + '</div><div class="sp-dots" id="spDots"><button type="button" class="on" aria-label="1"></button><button type="button" aria-label="2"></button></div>';
    SP.albero = '';
    const car = box.querySelector('#spCar');
    car.addEventListener('scroll', function(){ clearTimeout(car._t); car._t = setTimeout(spDotsAggiorna, 80); }, { passive: true });
    box.querySelectorAll('#spDots button').forEach(function(b, i){ b.addEventListener('click', function(){ spVaiSlide(i); }); });
  }
  /* 0.9.242: si mette una volta sola; poi il posto lo decide Personalizza (blocco spDream) */
  if (box.parentNode !== page){
    const giu = document.getElementById('nvConsigli') || document.getElementById('nvBottom');
    if (giu && giu.parentNode === page) page.insertBefore(box, giu); else page.appendChild(box);
    try{ if (typeof cstOrdinaBlocchi === 'function') cstOrdinaBlocchi(); }catch(_){ }
  }
  spDreamDati();
}
function spDreamDati(){
  const box = document.getElementById('spDream'); if (!box) return;
  const live = spLiveHtml();
  const slLive = box.querySelector('.sp-sl-live');
  slLive.hidden = !live;
  box.querySelector('#spDots').hidden = !live;
  const lc = box.querySelector('#spLive');
  if (live && lc.dataset.v !== live){ lc.dataset.v = live; lc.innerHTML = live; spRotola(lc); }
  const cache = spLs('fl_sp_cache', null);
  const d = SP.dati || cache || {};
  const me = (SP.dati && SP.dati.me) || (cache && cache.me) || null;
  const firma = JSON.stringify((me && me.albero) || []) + '|' + (me ? me.altri : '') + '|' + spMiaFoto().length;
  const al = box.querySelector('#spAlbero');
  if (al && firma !== SP.albero){ SP.albero = firma; al.innerHTML = spAlberoHtml(me); }
  const aw = box.querySelector('#spAnelloW');
  if (aw){
    if (d.dreams_lit == null){ aw.hidden = true; }
    else {
      aw.hidden = false;
      const v = +d.dreams_lit || 0;
      if (aw.dataset.v !== String(v)){ aw.dataset.v = String(v); aw.innerHTML = spAnelloHtml(v); spRotola(aw); spArcoImposta(v); }
    }
  }
  const tu = box.querySelector('#spTuoi');
  if (tu){
    if (!me){ tu.hidden = true; }
    else {
      const v = (me.diretti || 0) + ':' + (me.catena || 0);
      if (tu.dataset.v !== v){
        tu.dataset.v = v;
        const p = String(spT('missione.tuoi')).split('{direct}');
        const q = p.slice(1).join('{direct}').split('{total}');
        tu.innerHTML = spEsc(p[0]) + spNum('diretti', me.diretti || 0) + spEsc(q[0]) + spNum('catena', me.catena || 0) + spEsc(q.slice(1).join(''));
        spRotola(tu);
      }
      tu.hidden = false;
    }
  }
  spAltezza();
}
function spSlideAttiva(){
  const car = document.getElementById('spCar'); if (!car) return 0;
  const vis = Array.prototype.filter.call(car.children, function(s){ return !s.hidden; });
  return { car: car, vis: vis, i: Math.max(0, Math.min(vis.length - 1, Math.round(car.scrollLeft / Math.max(1, car.clientWidth)))) };
}
function spAltezza(){
  const a = spSlideAttiva(); if (!a || !a.vis.length) return;
  a.car.style.height = a.vis[a.i].offsetHeight + 'px';
}
function spDotsAggiorna(){
  const a = spSlideAttiva(); if (!a) return;
  document.querySelectorAll('#spDots button').forEach(function(b, i){ b.classList.toggle('on', i === a.i); });
  spAltezza();
}
function spVaiSlide(i){
  const car = document.getElementById('spCar'); if (!car) return;
  car.scrollTo({ left: i * car.clientWidth, behavior: 'smooth' });
}
/* Regala la mappa: lo stesso invito degli Amici, con il pass di 14 giorni (friends.js) */
function spRegala(){
  try{ if (typeof flVibra === 'function') flVibra(12); }catch(_){ }
  if (typeof frInvite === 'function'){ frInvite(); return; }
  if (typeof accQrApri === 'function'){ accQrApri(); return; }
  try{ if (typeof switchTab === 'function') switchTab('profilo'); }catch(_){ }
}

/* ---------------------------------------------------------------- gli avvisi della catena */
/* Al massimo uno al giorno, solo dentro all'app (il toast), solo con la schermata principale. */
/* 0.9.342, Andrea: "durante l'onboarding, l'intro con il Genio e il tour compaiono 'Giulia ha acceso il suo sogno grazie a te' sopra
   a quello che scrive il Genio. Quel momento e' sacro". Gli avvisi aspettano: non si consumano, arrivano dopo. */
function spZitto(){
  try{
    const b = document.body.classList;
    if (b.contains('gt-on') || b.contains('or-on') || b.contains('dec-on')) return true;
    if (localStorage.getItem('fl_onboarded') !== '1') return true;
    if (typeof GN !== 'undefined' && GN.on) return true;
    if (typeof EPI !== 'undefined' && EPI.ep) return true;
    if (typeof gnDati === 'function' && !gnDati().tourFatto) return true;
  }catch(_){ }
  return false;
}
function spAvvisi(me){
  if (!me || !SP.testi) return;
  if (spZitto()) return;
  try{ if (typeof order !== 'undefined' && typeof cur !== 'undefined' && order[cur] !== 's-home') return; }catch(_){ }
  const oggi = spGiorno();
  const conta = spLs(SP_AVVISO, null);
  if (conta && conta.g === oggi && conta.n >= (SP.cfg.avvisiAlGiorno || 1)) return;
  const visti = spLs(SP_VISTI, null) || { ids: [], indiretti: 0 };
  const indiretti = Math.max(0, (me.catena || 0) - (me.diretti || 0));
  let msg = '';
  const nuovo = (me.accesi || []).filter(function(a){ return a && a.id && visti.ids.indexOf(a.id) < 0; })[0];
  if (nuovo){
    msg = nuovo.nome ? spT('avvisi.diretto', { nome: nuovo.nome }) : spT('avvisi.direttoAnonimo');
    visti.ids.push(nuovo.id);
  } else if (indiretti > (visti.indiretti || 0)){
    const n = indiretti - (visti.indiretti || 0);
    msg = String(spTn('avvisi.catena', n)).split('{n}').join(spFmt(n));
    visti.indiretti = indiretti;
  } else if (indiretti < (visti.indiretti || 0)) visti.indiretti = indiretti;
  spLsSet(SP_VISTI, visti);
  if (!msg) return;
  spLsSet(SP_AVVISO, { g: oggi, n: (conta && conta.g === oggi ? conta.n : 0) + 1 });
  if (typeof toast === 'function'){
    toast(msg);
    /* il toast dura poco: questa frase si legge con calma */
    try{ const t = document.getElementById('toast'); if (t){ clearTimeout(t._h); t._h = setTimeout(function(){ t.classList.remove('show'); }, SP.cfg.avvisoMs || 5000); } }catch(_){ }
  }
}

/* ---------------------------------------------------------------- montaggio e tempi */
function spMonta(){
  try{ spStart(); }catch(_){ }
  try{ spMappa(); }catch(_){ }
  try{ spDream(); }catch(_){ }
}
function spMontaPresto(){ clearTimeout(SP.montaT); SP.montaT = setTimeout(spMonta, 150); }
function spOsservaDom(){
  if (SP.obs || typeof MutationObserver === 'undefined') return;
  SP.obs = new MutationObserver(function(list){
    /* le mutazioni dentro ai nostri elementi (i numeri che rotolano) non contano */
    for (let i = 0; i < list.length; i++){
      const t = list[i].target;
      if (t && t.closest && t.closest('.sp-start,.sp-mappa,#spDream,.sp-sez-tab')) continue;
      /* 0.9.263: un testo che cambia (i contatori ogni secondo) non e' una sezione nuova */
      const a = list[i].addedNodes; let el = false;
      for (let j = 0; j < a.length; j++){ if (a[j].nodeType === 1){ el = true; break; } }
      if (!el) continue;
      spMontaPresto(); return;
    }
  });
  ['tab-sveglia', 'tab-mappa', 'tab-rotta'].forEach(function(id){ const el = document.getElementById(id); if (el) SP.obs.observe(el, { childList: true, subtree: true }); });
}
function spStile(){
  if (document.getElementById('spStile')) return;
  const s = document.createElement('style'); s.id = 'spStile';
  s.textContent = [
    '.sp-start[hidden],.sp-mappa[hidden],#spDream [hidden]{display:none!important}',
    '@keyframes spPulse{0%{box-shadow:0 0 0 0 rgba(140,198,255,.7)}70%{box-shadow:0 0 0 8px rgba(140,198,255,0)}100%{box-shadow:0 0 0 0 rgba(140,198,255,0)}}',
    '.sp-pulse{flex:none;width:8px;height:8px;border-radius:50%;background:#BCE0FF;animation:spPulse 2s infinite}',
    '.sp-n{display:inline;font:inherit;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:inherit;margin:0;padding:0}',
    /* START: dentro alla carta navy dell'oblo' */
    '.sp-start{display:flex;align-items:center;justify-content:center;gap:8px;margin:12px 4px 0;color:rgba(255,255,255,.88);font:500 13px/1.4 var(--font-body);text-align:center}',
    '.sp-start .sp-n{color:#8CC6FF}',
    /* Mappa: sotto alla scheda blu del capitolo */
    '.sp-mappa{display:flex;align-items:center;justify-content:center;gap:8px;margin:-12px 6px 22px;color:var(--navy);font:500 13px/1.4 var(--font-body);text-align:center;transition:opacity .3s ease}',
    '.sp-mappa.fuori{opacity:0}.sp-mappa .sp-n{color:#0075E3}body.dark .sp-mappa .sp-n{color:#8CC6FF}',
    '.sp-mappa .sp-pulse{background:#0075E3;animation:none}',
    /* Dream: il carosello */
    '.sp-dream{margin:6px 0 4px}',
    '.sp-car{display:flex;align-items:flex-start;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;border-radius:24px;transition:height .35s ease}',
    '.sp-car::-webkit-scrollbar{display:none}',
    '.sp-sl{flex:0 0 100%;scroll-snap-align:start;box-sizing:border-box;border-radius:24px;color:#fff;position:relative;overflow:hidden}',
    '.sp-sl-live{min-height:320px;background:radial-gradient(120% 90% at 50% 0%,#1F4B8F 0%,#14234A 50%,#0F2041 100%);display:flex;align-items:center;justify-content:center;padding:28px 22px}',
    '.sp-sl-mis{background:linear-gradient(180deg,#14234A 0%,#0F2041 55%,#0E2350 100%);padding:28px 20px 24px;text-align:center}',
    '.sp-bolle{position:absolute;inset:0;pointer-events:none}',
    '@keyframes spDeriva{0%{transform:translate(0,0)}25%{transform:translate(10px,-14px)}50%{transform:translate(-6px,-24px)}75%{transform:translate(-12px,-8px)}100%{transform:translate(0,0)}}',
    '.sp-bolla > i{display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-style:normal;line-height:1}.sp-bolla{position:absolute;border-radius:50%;overflow:hidden;opacity:.85;box-shadow:0 0 0 2px rgba(255,255,255,.25),0 6px 18px rgba(0,117,227,.35);animation:spDeriva 16s ease-in-out infinite}',
    /* 0.9.337: le bolle di vetro, e un moto da bolla: sale, ondeggia, respira */
    '@keyframes spBolla{0%{transform:translate(0,0) scale(1)}20%{transform:translate(6px,-10px) scale(1.04)}45%{transform:translate(-5px,-22px) scale(.98)}70%{transform:translate(8px,-12px) scale(1.03)}100%{transform:translate(0,0) scale(1)}}',
    '.sp-bolla{opacity:1;animation-name:spBolla;animation-timing-function:ease-in-out}',
    '.sp-bolla.vetro{background:radial-gradient(circle at 32% 26%,rgba(255,255,255,.55) 0,rgba(255,255,255,.14) 22%,rgba(188,224,255,.08) 55%,rgba(188,224,255,.22) 100%)!important;box-shadow:inset 0 0 0 1.5px rgba(255,255,255,.45),inset -4px -6px 12px rgba(140,198,255,.25),0 6px 16px rgba(0,10,30,.25);backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}',
    '.sp-bolla.vetro > i{filter:drop-shadow(0 2px 3px rgba(0,0,0,.25))}',
    /* il LIVE e' rosso, come una diretta */
    /* 0.9.340, Andrea: "dentro al badge LIVE il testo chiaro su quel rosso scuro non si legge": rosso pieno, testo bianco, punto bianco che pulsa */
    '.sp-sl-live .sp-badge{background:#E63946;color:#fff;box-shadow:0 4px 14px rgba(230,57,70,.45);padding:6px 13px}.sp-sl-live .sp-badge i{background:#fff;box-shadow:0 0 6px rgba(255,255,255,.9)}',
    /* ogni scheda il suo cielo, sempre nei colori del brand: Sogno la notte, Mappa l'oceano, START il blu acceso dell'azione */
    '#spSez-mappa .sp-sl-live{background:radial-gradient(120% 90% at 50% 0%,#1478C2 0%,#0A4C8C 45%,#06305E 100%)}',
    '#spSez-start .sp-sl-live{background:radial-gradient(120% 90% at 50% 0%,#2E8EF0 0%,#0060C8 42%,#003A80 100%)}',
    '#spDream .sp-sl-live{background:radial-gradient(120% 90% at 50% 0%,#24407A 0%,#14234A 50%,#0A1632 100%)}',
    '.sp-bolla img{width:100%;height:100%;display:block}',
    '@media (prefers-reduced-motion:reduce){.sp-bolla,.sp-luce,.sp-pulse{animation:none!important}}',
    '.sp-live-c{position:relative;z-index:1;text-align:center;max-width:300px}',
    '.sp-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:999px;background:rgba(140,198,255,.16);color:#8CC6FF;font:800 11px var(--font-body);letter-spacing:.14em}',
    '.sp-badge i{width:7px;height:7px;border-radius:50%;background:#BCE0FF;animation:spPulse 2s infinite}',
    '.sp-pre{display:block;margin-top:14px;color:rgba(255,255,255,.8);font:600 14px var(--font-body)}',
    '.sp-big{margin:10px 0 6px;font:800 54px/1 var(--font-display);letter-spacing:-.02em;color:#fff;text-shadow:0 0 24px rgba(111,192,255,.45)}',
    '.sp-big .sp-n{font-weight:800;color:#fff!important}.sp-box .sp-n{color:#fff!important;font:800 20px var(--font-display)}.sp-frase,.sp-pre{text-shadow:none}',
    '.sp-frase{margin:0;color:rgba(255,255,255,.9);font:500 16px/1.45 var(--font-body)}',
    '.sp-dots{display:flex;justify-content:center;gap:8px;margin-top:12px}',
    '.sp-dots button{width:8px;height:8px;padding:0;border:0;border-radius:4px;background:rgba(0,117,227,.28);cursor:pointer;transition:width .25s ease,background .25s ease}',
    '.sp-dots button.on{width:22px;background:#0075E3}body.dark .sp-dots button{background:rgba(255,255,255,.3)}body.dark .sp-dots button.on{background:#BCE0FF}',
    /* La missione. 0.9.305, Andrea: il giallo resta SOLO all'energia (le bolle e i fili che collegano le persone);
       l'etichetta "La missione" e' rossa del brand, i numeri azzurri, il pulsante col gradiente del brand */
    '.sp-kicker{display:block;color:#E63946;font:800 12px var(--font-body);letter-spacing:.18em}',
    /* 0.9.306, Andrea: "La missione" nel pannello di Dream va nell'azzurro del brand; #8CC6FF stacca dal blu notte piu' di #3F9FF4 */
    '.sp-mis-testo .sp-kicker{color:#8CC6FF}',
    '.sp-mis-testo h3{margin:12px 0 14px;color:#fff;font:800 24px/1.22 var(--font-display)}',
    '.sp-mis-testo p{margin:0 0 12px;color:rgba(255,255,255,.86);font:500 14.5px/1.6 var(--font-body)}',
    '.sp-mis-testo .sp-chiusa{color:#fff;font-weight:700}',
    '.sp-albero{position:relative;margin:22px auto 8px;max-width:320px}',
    '.sp-io{display:flex;flex-direction:column;align-items:center;gap:4px}',
    '.sp-io small,.sp-posto small{color:rgba(255,255,255,.8);font:600 11.5px var(--font-body);max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.sp-b{display:inline-block;border-radius:50%;overflow:hidden;flex:none}.sp-b img{width:100%;height:100%;object-fit:cover;display:block}',
    '.sp-b-io{width:64px;height:64px;box-shadow:0 0 0 3px #FFD66B,0 0 26px rgba(255,214,107,.6)}',
    '.sp-fili{display:block;width:100%;height:56px;margin-top:2px}',
    '.sp-filo{fill:none;stroke:rgba(255,255,255,.22);stroke-width:2;stroke-dasharray:4 5;vector-effect:non-scaling-stroke}',
    '.sp-filo.on{stroke:rgba(255,214,107,.55);stroke-dasharray:none}',
    '@keyframes spLuce{from{stroke-dashoffset:120}to{stroke-dashoffset:-20}}',
    '.sp-luce{fill:none;stroke:#FFF3C4;stroke-width:3;stroke-linecap:round;stroke-dasharray:14 120;animation:spLuce 2.2s linear infinite;filter:drop-shadow(0 0 4px #FFD66B);vector-effect:non-scaling-stroke}',
    '.sp-posti{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;align-items:start}',
    '.sp-posto{display:flex;flex-direction:column;align-items:center;gap:5px}',
    '.sp-b-on{width:48px;height:48px;box-shadow:0 0 0 2px #FFD66B,0 0 20px rgba(255,214,107,.55)}',
    '.sp-b-vuoto{width:48px;height:48px;border:2px dashed rgba(255,255,255,.4);box-sizing:border-box}',
    '.sp-g2,.sp-g3{display:flex;gap:4px;justify-content:center}',
    '.sp-b-g2{width:22px;height:22px;opacity:.7}.sp-b-g3{width:14px;height:14px;opacity:.45}',
    '.sp-piu{color:rgba(255,255,255,.75);font:700 11.5px var(--font-body)}.sp-piu-altri{display:block;margin-top:8px}',
    '.sp-vuoto{margin:14px 0 0;color:rgba(255,255,255,.85);font:500 14px/1.5 var(--font-body)}',
    '.sp-anello-w{margin:26px 0 4px;display:flex;flex-direction:column;align-items:center}',
    '.sp-anello{position:relative;width:172px;height:172px}.sp-anello svg{width:100%;height:100%;transform:rotate(-90deg)}',
    '.sp-an-fondo{fill:none;stroke:rgba(255,255,255,.12);stroke-width:12}',
    '.sp-an-arco{fill:none;stroke:url(#spGrad);stroke-width:12;stroke-linecap:round;transition:stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)}',
    '.sp-an-c{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 22px}',
    '.sp-an-c b{color:#fff;font:800 22px/1.1 var(--font-display)}.sp-an-c small{color:rgba(255,255,255,.75);font:500 12px var(--font-body);margin-top:4px}',
    '.sp-trag{margin-top:12px;padding:5px 12px;border-radius:999px;background:rgba(0,117,227,.28);color:#CFE6FF;font:700 12px var(--font-body)}',
    '.sp-mondo{margin:12px 0 14px;color:#fff;font:700 19px/1.3 var(--font-display)}.sp-mondo .sp-n{color:#8CC6FF}',
    '.sp-box{display:grid;grid-template-columns:1fr 1fr;gap:10px;width:100%;max-width:320px}',
    '.sp-box > div{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:12px 8px;display:flex;flex-direction:column;gap:4px;color:#fff}',
    '.sp-box small{color:rgba(255,255,255,.7);font:600 12px var(--font-body)}.sp-box b{color:#fff;font:800 20px var(--font-display)}',
    '.sp-tuoi{margin:18px 0 0;color:rgba(255,255,255,.88);font:500 14px/1.5 var(--font-body)}.sp-tuoi .sp-n{color:#8CC6FF}',
    '.sp-regala{display:inline-flex;align-items:center;justify-content:center;gap:10px;width:100%;max-width:320px;margin:18px auto 0;padding:15px;border:2px solid transparent;border-radius:16px;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;color:#fff;text-shadow:1px 2.5px 3px rgba(0,0,0,.9);font:800 16px var(--font-body);cursor:pointer;box-shadow:0 8px 22px rgba(0,30,68,.35)}',
    '.sp-regala svg{filter:drop-shadow(1px 2px 2px rgba(0,0,0,.8))}',
    '.sp-regala:active{transform:translateY(2px);box-shadow:0 3px 10px rgba(0,30,68,.35)}',
    '.sp-firma{margin:18px 0 0;color:rgba(255,255,255,.7);font:italic 600 13px var(--font-display);letter-spacing:.04em}'
  ].join('\n');
  document.head.appendChild(s);
}

function spAvvia(){
  if (SP.avviato) return; SP.avviato = true;
  spStile();
  spTestiCarica().then(function(){ spMonta(); });
  spOsservaDom();
  document.addEventListener('fl:screen', function(e){ SP.schermo = e && e.detail || ''; spBattito(false); if (SP.schermo === 's-home') spCarica(false); });
  document.addEventListener('fl:tab', function(){ spMontaPresto(); spCarica(false); });
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible'){ spCarica(true); spBattito(false); } });
  /* lo scorrimento della Mappa ferma il giro delle frasi */
  document.addEventListener('scroll', function(e){ const t = e.target; if (t && t.id === 'tab-mappa') SP.rot.scrollAt = Date.now(); }, true);
  /* gli eventi delle altre schede: una spunta, un piano, un capitolo: si guarda subito */
  ['fl:spunta', 'fl:piano', 'fl:roadmap'].forEach(function(ev){ document.addEventListener(ev, function(){ setTimeout(function(){ spBattito(false); }, 500); }); });
  setInterval(function(){ spBattito(false); }, 10000);
  setInterval(function(){ if (document.visibilityState === 'visible') spCarica(true); }, Math.max(15, SP.cfg.refreshSec || 60) * 1000);
  setInterval(spMappaGira, 1000);
  window.addEventListener('resize', spAltezza);
  setTimeout(function(){ spCarica(true); spBattito(true); }, 3000);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', spAvvia); else setTimeout(spAvvia, 0);

/* =========================================================================================
   0.9.241, Andrea (demo per un investitore): la prova sociale la vede SOLO l'admin, come
   anteprima con numeri di prova (segnati come tali). Al posto delle righe di testo, in fondo
   a START e alla Mappa c'e' la stessa sezione con le bolle che si muovono di Dream. La missione
   e' piu' corta: titolo, una riga, la tua bolla con tre posti e, sbiadite, le tre bolle che ognuno
   accendera'; un pulsante apre la pagina della catena che cresce (1, 3, 9, 27...).
   Le funzioni qui sotto sostituiscono quelle con lo stesso nome piu' in alto.
   ========================================================================================= */
function spAdmin(){ return typeof flAdmin === 'function' && flAdmin(); }
function spMock(){
  let m = ''; try{ m = localStorage.getItem('fl_sp_mock') || ''; }catch(_){ m = ''; }
  if (m === '0') return '';
  if (m) return m;
  return spAdmin() ? '1' : '';
}
/* le vecchie righe di testo non si mostrano piu' */
function spStart(){ document.querySelectorAll('#tab-sveglia .sp-start').forEach(function(e){ e.remove(); }); spSezione('tab-sveglia', 'start'); }
function spMappa(){ document.querySelectorAll('#tab-mappa .sp-mappa').forEach(function(e){ e.remove(); }); spSezione('tab-mappa', 'mappa'); }
function spMappaGira(){ }
function spSezioneHtml(tipo){
  const d = SP.dati; if (!d || !SP.testi) return '';
  let n, tpl, live, k;
  if (tipo === 'start'){
    live = (d.active_focus_now || 0) >= SP.cfg.liveMin; n = live ? d.active_focus_now : (d.focus_today || 0);
    tpl = spTn(live ? 'start.live' : 'start.oggi', n); k = live ? 'stLive' : 'stOggi';
  } else if (tipo === 'sfide'){
    /* 0.9.350, Andrea: "nelle Sfide non deve dire che sono in cammino verso il sogno: deve parlare di sfide". Il numero e' quello vero di
       chi e' iscritto alle sfide (GET social/sfide, SF.conta in sfide.js) */
    live = false; n = 0;
    try{ const c = (typeof SF !== 'undefined' && SF.conta) || {}; Object.keys(c).forEach(function(x){ n += +c[x] || 0; }); }catch(_){ }
    tpl = spTn('sfide.oggi', n); k = 'sfOggi';
    if (!tpl || tpl === 'sfide.oggi') return '';
  } else {
    live = (d.on_path_now || 0) >= SP.cfg.liveMin; n = live ? d.on_path_now : (d.levels_passed_today || 0);
    tpl = spTn(live ? 'mappa.live' : 'mappa.oggi', n); k = live ? 'mpLive' : 'mpOggi';
  }
  if (!live && n < SP.cfg.todayMin) return '';
  const p = String(tpl).split('{n}'); const prima = p[0].trim(), dopo = p.slice(1).join('').trim();
  return (live ? '<span class="sp-badge"><i aria-hidden="true"></i>' + spEsc(spT('dream.badge')) + '</span>' : '')
    + (prima ? '<small class="sp-pre">' + spEsc(prima) + '</small>' : '')
    + '<div class="sp-big">' + spNum(k, n) + '</div><p class="sp-frase">' + spEsc(dopo) + '</p>';
}
function spSezione(tabId, tipo){
  const tab = document.getElementById(tabId); if (!tab) return;
  let box = document.getElementById('spSez-' + tipo);
  const html = spAdmin() ? spSezioneHtml(tipo) : '';
  if (!html){ if (box) box.remove(); return; }
  if (!box){
    box = document.createElement('section'); box.id = 'spSez-' + tipo; box.className = 'sp-dream sp-sez-tab';
    box.innerHTML = '<div class="sp-sl sp-sl-live sp-sl-sola"><div class="sp-bolle" aria-hidden="true">' + spBolleHtml() + '</div><div class="sp-live-c"></div></div>' + spAnteprimaHtml();
  }
  if (box.parentNode !== tab){
    const rif = tipo === 'start' ? document.getElementById('prHost') : tab.querySelector(':scope > .hd-piede');
    if (rif && rif.parentNode === tab) tab.insertBefore(box, rif); else tab.appendChild(box);
    /* 0.9.340, Andrea: "nella scheda Mappa non vedo il pannello": si nascondeva nella vista Roadmap. Ora c'e' in tutte e due */
    try{ if (typeof scsOrdinaBlocchi === 'function') scsOrdinaBlocchi(tipo === 'start' ? 'start' : ((typeof mppVistaCur === 'function' && mppVistaCur() === 'rotta') ? 'mappa-rotta' : 'mappa-mia')); }catch(_){ }
  }
  const c = box.querySelector('.sp-live-c');
  if (c.dataset.v !== html){ c.dataset.v = html; c.innerHTML = html; spRotola(c); }
}
/* 0.9.342, Andrea: "il pannello di social proof come quello di Sogno, Mappa e START, con le bolle che fluttuano, anche nella scheda
   Sfide della pagina Amici". La scheda Sfide si ridisegna da sola (sfPaginaHtml): il pannello entra come HTML, con il numero
   delle persone in cammino adesso (o delle tappe di oggi), e le bolle che si muovono */
function spSfideHtml(){
  try{
    if (!spAdmin()) return '';
    const html = spSezioneHtml('sfide'); if (!html) return '';
    setTimeout(function(){ try{ const c = document.querySelector('#spSez-sfide .sp-live-c'); if (c && !c.__rot){ c.__rot = 1; spRotola(c); } }catch(_){ } }, 60);
    return '<section class="sp-dream sp-sez-tab sp-sfide" id="spSez-sfide"><div class="sp-sl sp-sl-live sp-sl-sola"><div class="sp-bolle" aria-hidden="true">' + spBolleHtml() + '</div><div class="sp-live-c">' + html + '</div></div>' + spAnteprimaHtml() + '</section>';
  }catch(_){ return ''; }
}
function spAnteprimaHtml(){ return spMock() ? '<p class="sp-anteprima">' + spEsc(spT('missione.anteprima')) + '</p>' : ''; }
/* Dream: solo per l'admin */
function spDream(){
  if (!spAdmin()){ const b = document.getElementById('spDream'); if (b) b.remove(); return; }
  return spDreamBase();
}
/* la missione, corta */
function spMissioneHtml(){
  const m = SP.testi && SP.testi.missione; if (!m) return '';
  const br = function(a){ return (Array.isArray(a) ? a : [a]).map(spEsc).join('<br>'); };
  return '<div class="sp-mis-testo"><small class="sp-kicker">' + spEsc(m.kicker) + '</small>'
    + '<h3>' + br(m.titolo) + '</h3><p>' + spEsc(m.breve || '') + '</p></div>'
    + '<div class="sp-albero" id="spAlbero"></div>'
    + '<button type="button" class="sp-catena-btn" onclick="spCatenaApri()">' + spEsc(m.bottoneCatena || '') + '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></button>'
    + '<div class="sp-anello-w" id="spAnelloW" hidden></div><p class="sp-tuoi" id="spTuoi" hidden></p>'
    + '<button type="button" class="sp-regala" onclick="spRegala()"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/></svg>' + spEsc(m.bottone) + '</button>'
    + spAnteprimaHtml();
}
/* l'albero: tu, tre posti, e sotto ognuno le tre bolle che accendera', quasi trasparenti */
function spAlberoHtml(me){
  let h = spAlberoBase(me).replace(/<p class="sp-vuoto">[\s\S]*?<\/p>/, '');
  h = h.replace(/<div class="sp-posto vuoto"><span class="sp-b sp-b-vuoto"><\/span><\/div>/g, '<div class="sp-posto vuoto"><span class="sp-b sp-b-vuoto"></span><div class="sp-futuro"><i></i><i></i><i></i></div></div>');
  /* chi ha acceso meno di tre persone: i posti che mancano, sbiaditi */
  try{
    const t = document.createElement('div'); t.innerHTML = h;
    t.querySelectorAll('.sp-posto.on').forEach(function(p){
      const n = p.querySelectorAll('.sp-b-g2').length; if (n >= 3) return;
      const f = document.createElement('div'); f.className = 'sp-futuro'; f.innerHTML = new Array(3 - n + 1).join('<i></i>');
      const g2 = p.querySelector('.sp-g2'); if (g2) g2.appendChild(f); else p.appendChild(f);
    });
    h = t.innerHTML;
  }catch(_){ }
  return h;
}
/* ---------- la pagina della catena: la crescita, una generazione alla volta ---------- */
registerScreen('s-catena',
  '<div class="sp-cat-top"><button type="button" class="sp-cat-x" onclick="spCatenaChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>'
  + '<div id="spCatBody"></div>', { back: function(){ setTimeout(function(){ try{ switchTab('rotta'); }catch(_){ } }, 0); return 's-home'; } });
function spCatenaApri(){
  try{ if (typeof flVibra === 'function') flVibra(10); }catch(_){ }
  goId('s-catena'); spCatenaPaint();
}
function spCatenaChiudi(){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } }
function spCatenaPaint(){
  const h = document.getElementById('spCatBody'); if (!h) return;
  const m = (SP.testi && SP.testi.missione) || {};
  const br = function(a){ return (Array.isArray(a) ? a : [a]).map(spEsc).join('<br>'); };
  const foto = spMiaFoto() || SP_AVATAR[0];
  /* quattro generazioni disegnate (1, 3, 9, 27), una alla volta; poi i numeri */
  const W = 340, G = [1, 3, 9, 27], Y = [30, 128, 228, 318];
  const pos = G.map(function(n, g){ const out = []; for (let i = 0; i < n; i++) out.push([((i + 0.5) / n) * W, Y[g]]); return out; });
  let svg = '<svg class="sp-cat-svg" viewBox="0 0 ' + W + ' 340" aria-hidden="true">', rit = 0.3;
  for (let g = 1; g < G.length; g++){
    pos[g].forEach(function(p, i){
      const pa = pos[g - 1][Math.floor(i / 3)];
      svg += '<path class="sp-cat-filo" style="animation-delay:' + rit.toFixed(2) + 's" d="M' + pa[0].toFixed(1) + ' ' + (pa[1] + 12) + ' C' + pa[0].toFixed(1) + ' ' + (pa[1] + 52) + ' ' + p[0].toFixed(1) + ' ' + (p[1] - 52) + ' ' + p[0].toFixed(1) + ' ' + (p[1] - 12) + '"/>';
      svg += '<circle class="sp-cat-b g' + g + '" style="animation-delay:' + (rit + 0.3).toFixed(2) + 's" cx="' + p[0].toFixed(1) + '" cy="' + p[1] + '" r="' + [0, 16, 9, 5][g] + '"/>';
      rit += g === 1 ? 0.45 : (g === 2 ? 0.16 : 0.05);
    });
  }
  svg += '</svg>';
  const fine = rit + 0.4;
  const RIGHE = [[1, 'persone: quelle a cui la regali tu'], [2, 'persone: quelle a cui la regalano loro'], [3, 'persone al giro dopo'], [5, 'persone dopo 5 giri'], [10, 'persone dopo 10 giri']];
  const gen = RIGHE.map(function(r, i){
    return '<li style="animation-delay:' + (fine + i * 0.25).toFixed(2) + 's"><b>' + spFmt(Math.pow(3, r[0])) + '</b><small>' + r[1] + '</small></li>';
  }).join('');
  h.innerHTML = '<small class="sp-kicker">' + spEsc(m.kicker || '') + '</small><h2 class="sp-cat-tit">' + spEsc(m.catenaTitolo || '') + '</h2>'
    + '<div class="sp-cat-alb"><span class="sp-b sp-b-io sp-cat-io"><img src="' + spEsc(foto) + '" alt=""></span>' + svg + '</div>'
    + '<ul class="sp-cat-gen">' + gen + '</ul>'
    + '<p class="sp-cat-testo">' + br(m.catenaCorpo || m.corpo || '') + '</p>'
    + '<p class="sp-cat-testo sp-cat-forte">' + spEsc(m.chiusa || '') + '</p>'
    + '<div class="sp-anello-w" id="spCatAnello"></div>'
    + '<p class="sp-cat-vuoto">' + spEsc(m.catenaVuoto || '') + '</p>'
    + '<button type="button" class="sp-regala" onclick="spRegala()">' + spEsc(m.bottone || '') + '</button>'
    + '<p class="sp-firma">' + spEsc(m.firma || '') + '</p>' + spAnteprimaHtml();
  const d = SP.dati || spLs('fl_sp_cache', null) || {};
  const aw = document.getElementById('spCatAnello');
  if (aw && d.dreams_lit != null){
    const v = +d.dreams_lit || 0;
    /* l'anello di Dream ha lo stesso id: qui si disegna solo il suo, poi si rimette */
    const vecchio = document.getElementById('spArco'); if (vecchio) vecchio.id = 'spArcoDream';
    /* 0.9.305: l'arco non si vedeva. Il gradiente #spGrad esiste due volte (anche nell'anello di Dream, nascosto con
       display:none) e il browser prende il primo, che non si disegna: qui il gradiente ha un nome suo */
    aw.innerHTML = spAnelloHtml(v).replace('id="spGrad"', 'id="spGradCat"').replace('class="sp-an-arco"', 'class="sp-an-arco" style="stroke:url(#spGradCat)"'); spRotola(aw);
    setTimeout(function(){ spArcoImposta(v); const a = document.getElementById('spArco'); if (a) a.id = 'spArcoCat'; const dr = document.getElementById('spArcoDream'); if (dr) dr.id = 'spArco'; }, 60);
  } else if (aw) aw.hidden = true;
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#spDream .sp-mis-testo h3{font-size:21px;line-height:1.25}.sp-g2 .sp-futuro{display:inline-flex;margin:0 0 0 4px;vertical-align:middle}#spDream .sp-sl-mis #spAnelloW,#spDream .sp-sl-mis #spTuoi,#spDream .sp-sl-mis .sp-firma{display:none!important}.sp-sez-tab{margin:18px 16px 14px}.sp-sl-sola{position:relative;min-height:300px}',
    '.sp-anteprima{margin:8px 0 0;text-align:center;font:700 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#9FB3D6;opacity:.85}',
    '.sp-futuro{display:flex;justify-content:center;gap:6px;margin-top:10px}.sp-futuro i{width:14px;height:14px;border-radius:50%;border:1.5px dashed rgba(255,255,255,.5);opacity:.4}',
    '.sp-catena-btn{display:flex;align-items:center;justify-content:center;gap:6px;width:100%;margin:14px 0 4px;padding:13px;border:0;border-radius:99px;background:rgba(255,255,255,.12);color:#fff;font:700 14.5px var(--font-body);cursor:pointer}',
    '#s-catena{padding:0!important;background:radial-gradient(120% 70% at 50% 0%,#14234A,#0F2041 60%,#001E44);color:#fff;overflow-y:auto}',
    '.sp-cat-top{position:sticky;top:0;z-index:2;display:flex;padding:calc(10px + env(safe-area-inset-top)) 12px 4px}.sp-cat-x{width:44px;height:44px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;display:grid;place-items:center;cursor:pointer}',
    '#spCatBody{padding:0 18px 40px;text-align:center}.sp-cat-tit{margin:6px 0 10px;font:900 26px/1.2 var(--font-display,var(--font-body));color:#fff}',
    '.sp-cat-alb{position:relative;margin:4px auto 10px;max-width:360px}.sp-cat-io{position:absolute!important;left:50%;top:0;transform:translateX(-50%);z-index:1}',
    '.sp-cat-svg{width:100%;height:auto;display:block}.sp-cat-filo{fill:none;stroke:#FFD66B;stroke-width:1.4;opacity:0;stroke-dasharray:200;stroke-dashoffset:200;animation:spFilo .7s ease forwards}',
    '.sp-cat-b{fill:#0075E3;stroke:#FFD66B;stroke-width:1.5;opacity:0;transform-box:fill-box;transform-origin:center;animation:spBollaSu .5s cubic-bezier(.2,1.4,.4,1) forwards}.sp-cat-b.g2{fill:#3E8EF0}.sp-cat-b.g3{fill:#7FB6FF;stroke-width:1}',
    '@keyframes spFilo{to{opacity:.7;stroke-dashoffset:0}}@keyframes spBollaSu{0%{opacity:0;transform:scale(.2)}100%{opacity:1;transform:scale(1)}}',
    '.sp-cat-gen{list-style:none;margin:6px 0 18px;padding:0;display:flex;flex-direction:column;gap:8px;text-align:left}.sp-cat-gen li{display:flex;align-items:center;gap:14px;background:rgba(255,255,255,.07);border-radius:14px;padding:10px 14px;opacity:0;animation:spBollaSu .5s ease forwards}.sp-cat-gen b{flex:none;min-width:84px;text-align:right;font:900 22px var(--font-display,var(--font-body));color:#8CC6FF}.sp-cat-gen small{font:600 14px/1.35 var(--font-body);color:#DCE6F7}',
    '.sp-cat-testo{font:500 15px/1.6 var(--font-body);color:#DCE6F7;margin:0 0 10px}.sp-cat-forte{font-weight:800;color:#fff}.sp-cat-vuoto{font:700 16px/1.5 var(--font-body);color:#BCE0FF;margin:14px 0}'
  ].join('');
  document.head.appendChild(st);
  document.addEventListener('fl:admin', function(){ try{ spCarica(true); }catch(_){ } });
})();
