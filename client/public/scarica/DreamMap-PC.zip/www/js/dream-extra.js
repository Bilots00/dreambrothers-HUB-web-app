/* ===========================================================================================
   LA SCHEDA DREAM, COME MEDITOPIA (0.9.239)

   1. "Consigliato per te": schede che scorrono di lato ("In base al tuo sogno", "In base al tuo
      umore", "Per quest'ora") con proposte vere dell'app: un respiro, un suono, una sessione sul
      prossimo passo. Non e' sempre li' (cosi' vale di piu'): compare la mattina (6-11), la sera
      (dalle 20) e quando hai votato l'umore di oggi.
   2. "Ascoltati di recente": i suoni per concentrarsi ascoltati di recente, da riprendere o fermare.
   =========================================================================================== */
const DX_RECENTI = 'fl_snd_recenti';
const DX = { tab: '' };
function dxRecenti(){ try{ const l = JSON.parse(localStorage.getItem(DX_RECENTI) || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; } }
function dxChiuso(id){ try{ return typeof scrSuonoChiuso === 'function' && scrSuonoChiuso(id); }catch(_){ return false; } }
function dxSegnaSuono(id){
  if (!id || id === 'none' || dxChiuso(id)) return;
  const l = dxRecenti().filter(function(x){ return x && x.id !== id; }); l.unshift({ id: id, at: Date.now() });
  try{ localStorage.setItem(DX_RECENTI, JSON.stringify(l.slice(0, 6))); }catch(_){ }
}
function dxSuono(id){ try{ return sndAll().filter(function(x){ return x.id === id; })[0] || null; }catch(_){ return null; } }
function dxSuonaOra(id){ try{ return SND.id === id && SND.playing !== false; }catch(_){ return false; } }
function dxFaFa(t){ const m = Math.round((Date.now() - t) / 60000); if (m < 60) return m <= 1 ? 'adesso' : m + ' minuti fa'; const h = Math.round(m / 60); if (h < 24) return h === 1 ? '1 ora fa' : h + ' ore fa'; const g = Math.round(h / 24); return g === 1 ? 'ieri' : g + ' giorni fa'; }
function dxIco(k){
  const p = { play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/>', stop: '<rect x="7" y="7" width="10" height="10" rx="1.5" fill="currentColor" stroke="none"/>' }[k] || '';
  return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' + p + '</svg>';
}
function dxUmoreOggi(){ try{ const d = new Date(); const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); return (typeof umLeggi === 'function') ? umLeggi(k) : null; }catch(_){ return null; } }
function dxProssimoPasso(){ try{ const p = (typeof stPassoRoadmap === 'function') ? stPassoRoadmap() : null; return p ? p.testo : ''; }catch(_){ return ''; } }
/** Le proposte, per scheda. Ogni carta: { t, s, tag, min, col, az } (az = codice da eseguire) */
function dxProposte(){
  const h = new Date().getHours(), mattina = h >= 6 && h < 11, sera = h >= 20 || h < 1;
  const um = dxUmoreOggi(); const basso = um && ((+um.sodd || 3) <= 2 || (+um.prod || 3) <= 2);
  const passo = dxProssimoPasso();
  const DXC = { concentrazione: ['#0075E3', '🧘'], sospiro: ['#1E5FBF', '🌬️'], rilassamento: ['#0B3E86', '🌊'], motivazione: ['#E63946', '⚡'], attivante: ['#E63946', '☀️'], distensione: ['#14234A', '🌙'] };
  const resp = function(k, t, s, min){ const x = DXC[k] || ['#0075E3', '🫁']; return { t: t, s: s, tag: 'Respiro', min: min, col: x[0], emo: x[1], az: "rsApri({tecnica:'" + k + "'})" }; };
  const suono = function(id, s){ const x = dxChiuso(id) ? null : dxSuono(id); return x ? { t: x.n, s: s, tag: 'Suono', min: 0, col: '#0B3E86', ico: x.ico, az: "dxSuona('" + id + "')" } : null; };
  const tabs = [];
  const sogno = [];
  if (passo) sogno.push({ t: 'Il prossimo passo', s: passo, tag: 'Full Focus', min: 25, col: '#0075E3', emo: '🎯', az: "if(typeof stGoFocus==='function')stGoFocus();else switchTab('sveglia')" });
  sogno.push(resp('concentrazione', 'Il respiro quadrato', 'Prima di cominciare: la testa si ferma e resta lucida', 5, '#3F9FF4'));
  const s1 = suono('forest', 'Per lavorare senza distrazioni'); if (s1) sogno.push(s1);
  tabs.push(['sogno', 'In base al tuo sogno', sogno]);
  if (um){
    const l = basso
      ? [resp('sospiro', 'Il sospiro ciclico', 'Quando la giornata pesa: due inspirazioni e un’espirazione lunga', 3, '#3BA7A0'), resp('rilassamento', 'Il rilassamento', 'Il respiro 4-6 che abbassa i giri', 5, '#2E9C84'), suono('river', 'Acqua che corre: per calmarti')]
      : [resp('motivazione', 'La carica breve', 'Hai energia: usala sul lavoro che conta', 2, '#E08A2E'), passo ? { t: 'Sfrutta il momento', s: passo, tag: 'Full Focus', min: 50, col: '#0075E3', emo: '🚀', az: "if(typeof stGoFocus==='function')stGoFocus();else switchTab('sveglia')" } : null];
    tabs.push(['umore', 'In base al tuo umore', l.filter(Boolean)]);
  }
  if (mattina) tabs.push(['ora', 'Per questa mattina', [resp('attivante', 'Il respiro che sveglia', 'Corpo e testa accesi per il lavoro più difficile', 3, '#E0732E'), suono('forest', 'Bosco al mattino, per partire')].filter(Boolean)]);
  else if (sera) tabs.push(['ora', 'Per questa sera', [resp('distensione', 'Il 4-7-8 per dormire', 'Quattro cicli, poco più di un minuto', 2, '#4B5BD6'), resp('sospiro', 'Il sospiro ciclico', 'Per spegnere la giornata', 3, '#3BA7A0'), suono('night', 'Grilli e aria ferma, per addormentarti')].filter(Boolean)]);
  const admin = typeof flAdmin === 'function' && flAdmin();
  if (admin && !mattina && !sera) tabs.push(['ora', 'Per questo pomeriggio', [resp('concentrazione', 'Il respiro quadrato', 'Dopo pranzo la testa rallenta: quattro minuti e riparti', 4, '#3F9FF4'), suono('forest', 'Bosco e vento leggero, per il lavoro lungo')].filter(Boolean)]);
  const noResp = typeof flSezioneBloccata === 'function' && flSezioneBloccata('respiro');
  if (noResp) tabs.forEach(function(t){ t[2] = t[2].filter(function(c){ return c && c.tag !== 'Respiro'; }); });
  return { visibile: admin || mattina || sera || !!um, tabs: tabs.filter(function(t){ return t[2].length; }) };
}
function dxSuona(id){ try{ if (dxSuonaOra(id)){ dxFerma(); return; } sndPlay(id); }catch(_){ } setTimeout(dxPaint, 400); }
function dxFerma(){ try{ sndStop(); SND.id = 'none'; SND.playing = false; if (typeof sndPaint === 'function') sndPaint(); }catch(_){ } setTimeout(dxPaint, 200); }
function dxConsigliHtml(){
  const P = dxProposte(); if (!P.visibile || !P.tabs.length) return '';
  if (!P.tabs.some(function(t){ return t[0] === DX.tab; })) DX.tab = P.tabs[P.tabs.length - 1][0];
  const tab = P.tabs.filter(function(t){ return t[0] === DX.tab; })[0];
  return '<section class="dx-sez"><b class="dx-tit">Consigliato per te</b><p class="dx-sot">Proposte scelte sul tuo sogno, sul tuo umore e sull’ora del giorno</p>'
    + '<div class="dx-chips">' + P.tabs.map(function(t){ return '<button type="button" class="' + (t[0] === DX.tab ? 'on' : '') + '" onclick="DX.tab=\'' + t[0] + '\';dxPaint()">' + t[1] + '</button>'; }).join('') + '</div>'
    + '<div class="dx-carte">' + tab[2].map(function(c){
        return '<button type="button" class="dx-carta" style="--c:' + c.col + '" onclick="' + c.az + '"><span class="dx-tag">' + c.tag + '</span><span class="dx-ico">' + (c.emo || c.ico || '') + '</span>' + '<span class="dx-piede">' + (c.min ? '<i>' + c.min + ' min</i>' : '') + '<b>' + esc(c.t) + '</b><small>' + esc(c.s) + '</small></span></button>';
      }).join('') + '</div></section>';
}
function dxRecentiHtml(){
  /* 0.9.255, Andrea: un suono ancora chiuso in una mystery box non e' mai stato ascoltato: qui non ci sta */
  const l = dxRecenti().map(function(x){ const s = dxSuono(x.id); return s && !dxChiuso(x.id) ? { s: s, at: x.at } : null; }).filter(Boolean).slice(0, 6);
  if (!l.length) return '';
  return '<section class="dx-sez"><b class="dx-tit">Ascoltati di recente</b><p class="dx-sot">I suoni per concentrarti: riprendi da qui</p><div class="dx-carte">'
    + l.map(function(x){ const on = dxSuonaOra(x.s.id);
        return '<div class="dx-ultimo' + (on ? ' on' : '') + '"><span class="dx-ultimo-ico">' + x.s.ico + '</span><b>' + esc(x.s.n) + '</b><small>' + (on ? 'In ascolto' : dxFaFa(x.at)) + '</small>'
          + '<button type="button" onclick="' + (on ? 'dxFerma()' : "dxSuona('" + x.s.id + "')") + '" aria-label="' + (on ? 'Ferma' : 'Riprendi') + '">' + dxIco(on ? 'stop' : 'play') + (on ? 'Ferma' : 'Riprendi') + '</button></div>';
      }).join('') + '</div></section>';
}
/* 0.9.242: Consigliato, Recenti, il tempo di schermo e il tuo agente personale sono BLOCCHI di Dream
   (costruisci.js CST_BLOCCHI): si creano una volta sola, poi il posto e l'acceso/spento li decide
   Personalizza. "dx-vuoto" (una classe) quando non c'e' niente da mostrare: `hidden` lo usa
   Personalizza per i blocchi tolti. */
function dxSlot(id){
  const pg = document.querySelector('#tab-rotta .nv-page'); if (!pg) return null;
  let el = document.getElementById(id);
  if (!el){ el = document.createElement('div'); el.id = id; }
  if (el.parentNode !== pg){
    const giu = document.getElementById('nvBottom');
    if (giu && giu.parentNode === pg) pg.insertBefore(el, giu); else pg.appendChild(el);
    DX.nuovi = true;
  }
  return el;
}
function dxMetti(el, html){ if (!el) return; if (el.dataset.v !== html){ el.dataset.v = html; el.innerHTML = html; } el.classList.toggle('dx-vuoto', !html); }
function dxPaint(){
  if (DX.dentro) return; DX.dentro = true;
  try{
    const vecchio = document.getElementById('nvExtra'); if (vecchio) vecchio.remove();
    DX.nuovi = false;
    const t = dxSlot('nvTempo'), g = dxSlot('nvGuida'), c = dxSlot('nvConsigli'), r = dxSlot('nvRecenti');
    if (!c) return;
    const bloccato = typeof flSezioneBloccata === 'function' && flSezioneBloccata('consigliati');
    dxMetti(c, bloccato ? '' : dxConsigliHtml());
    dxMetti(r, dxRecentiHtml());
    dxTempoPaint(t);
    dxGuidaPaint(g);
    /* 0.9.306: "Le tue pagine" della Mappa in Dream (costruisci.js): stesso html, stesso aspetto.
       0.9.309: di serie acceso e sempre l'ultimo blocco (CST_BLOCCHI ultimo: true) */
    const pg = dxSlot('nvPagine');
    dxMetti(pg, typeof mppPagineHtml === 'function' ? '<div class="mpp-page mpp-page-pagine">' + mppPagineHtml() + '</div>' : '');
    if (DX.nuovi && typeof cstOrdinaBlocchi === 'function') cstOrdinaBlocchi();
  } finally { DX.dentro = false; }
}
/* il tempo di schermo di oggi: lo stesso pannello di "Proteggi i tuoi sogni" (scores.js lo
   disegna in #blkReport); qui una copia da guardare, e un tocco porta alla pagina */
function dxTempoCopia(){
  /* 0.9.245: non piu' una copia: il pannello VERO (#blkReport) si sposta qui, cosi' i "⋯", le
     schede e le app funzionano dentro Dream; quando si apre la Protezione torna a casa sua */
  const t = document.getElementById('nvTempo'), rep = document.getElementById('blkReport'); if (!t) return;
  /* 0.9.294, LA CAUSA VERA del pannello che sparisce da "Proteggi i tuoi sogni" (Andrea: "a volte c'e', a volte no").
     Il pannello e' uno solo e si sposta fra le due pagine. dxPaint gira ogni 60 secondi e a ogni ritorno su Dream, e lo
     portava in Dream anche mentre si stava guardando la Protezione; tornava a casa solo aprendo la pagina da
     blPaginaApri. Adesso non si sposta mai mentre la Protezione e' davanti, e torna a casa ogni volta che si apre. */
  if (dxProtezioneDavanti()){ dxTempoACasa(); return; }
  /* 0.9.301: il blocco e' facoltativo e di serie e' spento (costruisci.js). Spento, il pannello non viene in Dream a
     nascondersi in un contenitore invisibile: resta nella pagina "Proteggi i tuoi sogni". */
  if (t.hidden){ dxTempoACasa(); return; }
  if (rep && rep.parentElement !== t){ t.innerHTML = ''; t.appendChild(rep); }
  t.classList.toggle('dx-vuoto', !(rep && rep.innerHTML.trim()));
}
function dxProtezioneDavanti(){
  try{
    /* le pagine non attive restano disegnate fuori schermo: conta solo la pagina accesa */
    const sc = document.getElementById('s-blocco');
    return !!(sc && sc.classList.contains('active') && typeof order !== 'undefined' && order[cur] === 's-blocco');
  }catch(_){ return false; }
}
function dxTempoACasa(){
  const rep = document.getElementById('blkReport'), tab = document.getElementById('tab-blocco');
  if (!rep || !tab || rep.parentElement === tab) return;
  const qb = tab.querySelector('.qb'); if (qb) tab.insertBefore(rep, qb); else tab.appendChild(rep);
}
function dxTempoPaint(t){
  if (!t) return;
  dxTempoCopia();
  if (Date.now() - (DX.tempoAt || 0) < 60000 || typeof scBlockScores !== 'function') return;
  DX.tempoAt = Date.now();
  try{ Promise.resolve(scBlockScores()).then(dxTempoCopia, dxTempoCopia); }catch(_){ }
}
/* la guida 1-1 (il tuo agente personale) vive qui; nella Roadmap ne resta una riga (dxAgenteMiniHtml) */
function dxGuidaPaint(g){
  if (!g) return;
  const gh = document.getElementById('guidaHost'); if (!gh) return;
  if (gh.parentElement !== g){ g.innerHTML = ''; g.appendChild(gh); try{ if (typeof guidaPaint === 'function') guidaPaint(); }catch(_){ } }
  g.classList.toggle('dx-vuoto', !gh.innerHTML.trim());
}
function dxAgenteMiniHtml(){
  return '<button type="button" class="dx-ag-mini" onclick="dxAgenteVai()"><span class="dx-ag-ico">🧞</span><span><b>Il tuo agente personale</b><small>Rivede la tua roadmap e ti dice da quale passo partire oggi</small></span>'
    + '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
}
/* 0.9.262, Andrea: dalla Roadmap il pannello portava alla scheda Sogno. Adesso apre la chat SOPRA alla
   Roadmap, come "Il tuo agente personale rivede il piano di oggi" nella Mappa, con la richiesta gia' scritta nel campo:
   la manda l'utente. */
function dxAgenteVai(){
  const testo = 'Guarda la mia roadmap e dimmi da quale passo partire oggi, cosa togliere e cosa spostare per arrivare in tempo.';
  if (typeof agPopover === 'function'){ agPopover(testo, { titolo: 'La mia roadmap' }); return; }
  if (typeof agNuovaConversazione === 'function'){ agNuovaConversazione(testo); return; }
  try{ switchTab('rotta'); }catch(_){ }
}
(function(){
  if (typeof blPaginaApri === 'function'){ const vb = blPaginaApri; window.blPaginaApri = blPaginaApri = function(){ dxTempoACasa(); return vb.apply(this, arguments); }; }
  if (typeof sndPlay === 'function'){ const v = sndPlay; window.sndPlay = sndPlay = function(id){ dxSegnaSuono(id); const r = v.apply(this, arguments); setTimeout(dxPaint, 500); return r; }; }
  if (typeof cstOrdinaBlocchi === 'function'){ const v2 = cstOrdinaBlocchi; window.cstOrdinaBlocchi = cstOrdinaBlocchi = function(){ const r = v2.apply(this, arguments); try{ dxPaint(); }catch(_){ } return r; }; }
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'rotta') setTimeout(dxPaint, 200); if (e.detail === 'blocco') dxTempoACasa(); });
  document.addEventListener('fl:screen', function(e){ if (e.detail === 's-blocco'){ dxTempoACasa(); setTimeout(dxTempoACasa, 300); } });
  /* 0.9.288: la stagione di spinta che comincia spegne subito "Consigliato per te", senza cambiare scheda */
  document.addEventListener('fl:blocchi', function(){ setTimeout(dxPaint, 50); try{ if (typeof scLifePaint === 'function') scLifePaint(); }catch(_){ } });
  setTimeout(dxPaint, 2500); setInterval(function(){ try{ dxPaint(); }catch(_){ } }, 60000);
  const st = document.createElement('style');
  st.textContent = [
    '.dx-vuoto,#nvConsigli[hidden],#nvRecenti[hidden],#nvTempo[hidden],#nvGuida[hidden],#nvPagine[hidden]{display:none!important}#nvPagine{margin:0 0 22px}#nvPagine .mpp-page{padding:8px 0 0}#nvConsigli,#nvRecenti{margin:6px 0 4px}.dx-sez{margin:0 0 22px}',
    '#nvTempo{margin:4px 0 14px}',
    '.dx-ag-mini{display:flex;align-items:center;gap:12px;width:calc(100% - 36px);margin:4px 18px 12px;padding:14px 16px;border:0;border-radius:18px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);color:var(--navy,#14234A);text-align:left;cursor:pointer;font:inherit}',
    /* 0.9.350, Andrea: "il pannello del tuo agente nella Mappa uguale a quello scuro della scheda Sogno, molto piu' bello col contrasto" (.gd-card, iofuturo.js) */
    '.dx-ag-mini{background:linear-gradient(135deg,#0A1024,#141B3A)!important;box-shadow:0 10px 24px rgba(0,30,68,.22)!important;border:1px solid rgba(255,255,255,.14)!important;color:#fff!important;padding:18px 16px!important;border-radius:20px!important}.dx-ag-mini b{color:#fff!important;font-size:16px!important}.dx-ag-mini small{color:rgba(255,255,255,.72)!important}.dx-ag-mini svg{color:#BCE0FF}.dx-ag-ico{flex:none;width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:24px;background:radial-gradient(circle,#2A4C8C,#14234A);box-shadow:0 0 0 3px rgba(140,198,255,.18)}',
    '.dx-ag-mini>span:nth-child(2){flex:1}.dx-ag-mini b{display:block;font:800 15px var(--font-body)}.dx-ag-mini small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:var(--muted,#5B6B86)}body.dark .dx-ag-mini{color:#fff}',
    '.dx-ag-ico{width:40px;height:40px;border-radius:12px;background:#EAF3FE;display:grid;place-items:center;font-size:22px}',
    '.dx-tit{display:block;font:800 21px var(--font-display,var(--font-body));color:var(--navy,#14234A)}body.dark .dx-tit{color:#fff}',
    '.dx-sot{margin:4px 0 12px;font:500 13.5px/1.45 var(--font-body);color:var(--muted,#5B6B86)}',
    '.dx-chips{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin:0 -18px 12px;padding:0 18px}.dx-chips::-webkit-scrollbar{display:none}',
    '.dx-chips button{flex:none;border:1.5px solid #0075E3;border-radius:99px;background:transparent;color:var(--navy,#14234A);font:800 12.5px var(--font-body);letter-spacing:.04em;text-transform:uppercase;padding:10px 16px;cursor:pointer}body.dark .dx-chips button{color:#fff}.dx-chips button.on{background:#0075E3;color:#fff;box-shadow:0 6px 16px rgba(0,117,227,.3)}',
    '.dx-carte{display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;margin:-4px -18px 0;padding:4px 18px 6px;scroll-snap-type:x mandatory;scroll-padding:0 18px}.dx-carte::-webkit-scrollbar{display:none}',
    '.dx-carta{flex:none;width:210px;height:250px;scroll-snap-align:start;border:0;border-radius:24px;position:relative;overflow:hidden;text-align:left;cursor:pointer;color:#fff;background:radial-gradient(circle at 50% 30%,rgba(255,255,255,.22),transparent 50%),linear-gradient(165deg,var(--c),#0F2041 88%);box-shadow:0 10px 24px rgba(15,32,65,.22)}',
    '.dx-tag{position:absolute;top:12px;left:12px;padding:5px 10px;border-radius:99px;background:#BCE0FF;color:#14234A;font:800 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase}',
    '.dx-ico{position:absolute;top:44px;left:50%;width:84px;height:84px;margin-left:-42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:46px;background:rgba(255,255,255,.12);box-shadow:0 0 0 10px rgba(255,255,255,.06),0 0 40px rgba(140,198,255,.25)}.dx-ico svg{width:44px;height:44px}',
    '.dx-piede{position:absolute;left:14px;right:14px;bottom:14px}.dx-piede i{display:inline-block;font-style:normal;font:700 11.5px var(--font-body);padding:4px 9px;border-radius:99px;background:rgba(15,32,65,.5);margin-bottom:8px}',
    '.dx-piede b{display:block;font:800 17px/1.25 var(--font-display,var(--font-body))}.dx-piede small{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-top:4px;font:500 12.5px/1.4 var(--font-body);color:rgba(255,255,255,.82)}',
    '.dx-ultimo{flex:none;width:160px;scroll-snap-align:start;border-radius:20px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);padding:14px;display:flex;flex-direction:column;gap:4px}.dx-ultimo.on{box-shadow:0 0 0 2px #0075E3}',
    '.dx-ultimo-ico{font-size:34px}.dx-ultimo b{font:800 15px var(--font-body);color:var(--navy,#14234A)}body.dark .dx-ultimo b{color:#fff}.dx-ultimo small{font:600 12px var(--font-body);color:var(--muted,#5B6B86)}',
    '.dx-ultimo button{margin-top:8px;display:flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 13px var(--font-body);padding:9px 0;cursor:pointer}.dx-ultimo.on button{background:#0F2041}'
  ].join('');
  document.head.appendChild(st);
})();
