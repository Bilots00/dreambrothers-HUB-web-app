/* insights.js - the Approfondimenti section (corsia U-D) and the onboarding usage reveal.

   Every figure on these screens comes out of the native plugin: getScreenTimeRange for the
   charts, getTopApps for the per-app breakdown, getInsights for pickups/notifications/blocks.
   Nothing is estimated, extrapolated or padded: when a number is not available the card says
   so and disappears instead of drawing a convincing zero. The two things computed here in
   JavaScript are arithmetic over those figures (percentages, averages, week-over-week deltas)
   and the app categories, which are a user opinion and not a measurement.

   The whole section is built into #insData from this module. index.html is frozen and shared
   with five other lanes, so the markup lives next to the code that drives it. */

/* ---------------------------------------------------------------------------------------
   CONSTANTS AND STATE
   --------------------------------------------------------------------------------------- */

/* The three buckets, in the brand's own colours (0.9.303, Andrea: no purple, nothing copied from
   AppBlock): neutral = light brand azure, distracting = brand red.
   0.9.305, Andrea: "Produttivo e Neutrale sono due blu troppo simili, nel grafico non si distinguono":
   produttivo diventa VERDE, come un semaforo (rosso distrattivo, azzurro neutrale, verde produttivo). */
const INS_CAT = {
  distr:  { label: 'Distrattivo', color: '#E63946' },
  /* 0.9.351, Andrea: "rosso, blu e verde insieme fanno cagare: colori del brand, con contrasto fra neutrale e produttivo". Distrattivo rosso, neutrale azzurrino, produttivo blu pieno */
  neutro: { label: 'Neutrale',    color: '#8CC6FF' },
  prod:   { label: 'Produttivo',  color: '#0075E3' }
};
/* 0.9.353, Andrea: "filtrando per il computer le barre da blu diventano grigie". Il grigio era questo colore: la
   seconda passata del grafico dipingeva "Non categorizzato" ogni minuto senza un'app dietro, e col computer le ore
   arrivano senza app (pcGiorno().ore, dal 0.9.346) e i programmi non stanno nelle categorie del telefono. Adesso il
   tempo senza app resta nel blu della barra (insSegs), i programmi prendono la categoria scelta sul computer
   (insCatPc), e quello che resta senza categoria ha un colore del brand, non piu' il grigio. */
const INS_NONE = { label: 'Non categorizzato', color: '#C8EFFD' };
/* LE FACCINE DEI GIUDIZI (0.9.302): felice = produttiva (verde dal 0.9.305), normale = neutra (azzurro), triste =
   distrattiva (rosso). Disegnate, non caratteri: ☺ e ☹ cambiano faccia da un telefono all'altro, e il
   tondo verde del cartello "Segna o escludi" restava vuoto. Le stesse nelle carte dell'ordinamento e
   nel cartello del Report. */
function insFaccia(k){
  const bocca = k === 'prod' ? 'M7.5 13.8c1.1 1.9 2.7 2.9 4.5 2.9s3.4-1 4.5-2.9'
              : k === 'distr' ? 'M7.5 16.8c1.1-1.9 2.7-2.9 4.5-2.9s3.4 1 4.5 2.9'
              : 'M8 15.3h8';
  return '<svg class="ins-faccia" viewBox="0 0 24 24" aria-hidden="true"><circle cx="8.7" cy="9.2" r="1.45" fill="currentColor"/><circle cx="15.3" cy="9.2" r="1.45" fill="currentColor"/>'
    + '<path d="' + bocca + '" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/></svg>';
}

/* Packages whose screen time is really "time on websites". The engine measures foreground time
   per package and knows nothing about which page was open, so these get an expandable row that
   says exactly that instead of a made-up list of domains. */
const INS_BROWSERS = [
  'com.android.chrome','com.chrome.beta','com.chrome.dev','org.mozilla.firefox',
  'com.microsoft.emmx','com.opera.browser','com.opera.mini.native','com.brave.browser',
  'com.duckduckgo.mobile.android','com.sec.android.app.sbrowser','com.UCMobile.intl',
  'com.vivaldi.browser','com.kiwibrowser.browser','com.yandex.browser','org.torproject.torbrowser'
];

const INS = {
  view: 'giorno',     // giorno | settimana | tendenza
  dayOff: 0,          // 0 = today, 1 = yesterday …
  weekOff: 0,         // 0 = this week
  filter: 'all',      // all | distr | neutro | prod
  token: 0,           // bumped on every render, so a late fetch cannot paint over a newer view
  built: false,
  granted: false,
  forceRender: false,
  menu: '',           // '' | 'filter' | 'settings'
  showAllApps: false,
  detail: null,       // packageName currently open in the detail screen
  detailView: 'giorno'
};

/* 0.9.353, Andrea: "in alto la freccia indietro e' un chevron, e sotto ci sono i chevron per cambiare giorno".
   L'intestazione usa la freccia della Timeline; i chevron restano solo per spostarsi fra i giorni. Icone, non caratteri. */
const INS_SVG_A = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
const INS_CHEV = { sx: INS_SVG_A + '<path d="M15 5l-7 7 7 7"/></svg>', dx: INS_SVG_A + '<path d="M9 5l7 7-7 7"/></svg>' };
const INS_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/></svg>';

/* Short-lived cache: syncNative() fires on every tab switch and every return to the foreground,
   and each render is several queryEvents scans on the phone. */
const INS_CACHE = new Map();
const INS_TTL = 45000;

/* ---------------------------------------------------------------------------------------
   SMALL HELPERS
   --------------------------------------------------------------------------------------- */

function insFmt(ms){
  ms = Math.max(0, Math.round(ms || 0));
  const m = Math.floor(ms / 60000);
  if (m < 1) return Math.floor(ms / 1000) + 's';
  if (m < 60) return m + 'm';
  const h = Math.floor(m / 60);
  return h >= 24
    ? Math.floor(h / 24) + 'd ' + (h % 24) + 'h'
    : h + 'h ' + String(m % 60).padStart(2, '0') + 'm';
}
function insPad(n){ return String(n).padStart(2, '0'); }
function insDayStart(ts){ const d = new Date(ts); d.setHours(0,0,0,0); return d.getTime(); }
function insAddDays(ts, n){ const d = new Date(ts); d.setDate(d.getDate() + n); return d.getTime(); }
/* Monday-first, like the Lun→Dom row AppBlock draws. */
function insWeekStart(ts){
  const d = new Date(insDayStart(ts));
  const dow = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - dow);
  return d.getTime();
}
/* La data come la scrive il paese di chi guarda (locale.js), non come la scriviamo noi. */
function insDateLabel(ts){
  try{ if (typeof flData === 'function') return flData(ts); }catch(_){ }
  const d = new Date(ts); return insPad(d.getDate()) + '/' + insPad(d.getMonth()+1) + '/' + d.getFullYear();
}
/* Oltre a ieri, un numero da solo non dice niente: «19/09» puo' essere un martedì qualunque
   o il sabato in cui non hai toccato il telefono. Il nome del giorno lo ricolloca. */
function insDataPeriodo(ts, off){
  if (off === 0) return 'Oggi';
  if (off === 1) return 'Ieri';
  try{ if (typeof flDataConGiorno === 'function') return flDataConGiorno(ts); }catch(_){ }
  return insDateLabel(ts);
}
function insDayKey(ts){ const d = new Date(ts); return d.getFullYear() + '-' + insPad(d.getMonth()+1) + '-' + insPad(d.getDate()); }
const INS_MONTHS = ['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
const INS_DOW = ['Lun','Mar','Mer','Gio','Ven','Sab','Dom'];

/* Categories are an opinion, not a measurement: the plugin has no store for them (its whole
   surface is rules, permissions and counters), so they live in localStorage. If a Categories
   store ever lands in the engine, only these four functions have to change. */
function insCatsBase(){ try { return JSON.parse(localStorage.getItem('fl_ins_cat') || '{}'); } catch(e){ return {}; } }
/* LE FASCE ORARIE (0.9.212). La stessa app puo' essere distrattiva la mattina e produttiva
   mentre lavori o guidi: YouTube o Spotify con un podcast di marketing valgono piu' della radio
   o dei colleghi che parlano di calcio. Per ogni app, fasce «dalle … alle … conta come …»; fuori
   dalle fasce vale la categoria di sempre.
   insCats(ts): la categoria in vigore all'ora ts (adesso, se ts manca); insCats(null): solo
   quella di sempre, senza fasce. */
const INS_FASCE_KEY = 'fl_ins_fasce';
function insFasce(){ try { return JSON.parse(localStorage.getItem(INS_FASCE_KEY) || '{}') || {}; } catch(e){ return {}; } }
function insSetFasce(pkg, l){
  const all = insFasce();
  if (l && l.length) all[pkg] = l; else delete all[pkg];
  try { localStorage.setItem(INS_FASCE_KEY, JSON.stringify(all)); } catch(e){}
  try { if (typeof dcSave === 'function') dcSave({}); } catch(e){}
}
function insHM(v){ const p = String(v || '').split(':'); return (+p[0] || 0) * 60 + (+p[1] || 0); }
/** La categoria di una lista di fasce all'ora ts, o null se ts non cade in nessuna fascia. */
function insFasciaCat(l, ts){
  const d = new Date(ts); const m = d.getHours() * 60 + d.getMinutes();
  for (let i = 0; i < (l || []).length; i++){
    const f = l[i], a = insHM(f.da), b = insHM(f.a);
    if (a === b) continue;
    if (a < b ? (m >= a && m < b) : (m >= a || m < b)) return f.cat;
  }
  return null;
}
function insCats(ts){
  const b = insCatsBase();
  if (ts === null) return b;
  const f = insFasce(); const k = Object.keys(f);
  if (!k.length) return b;
  const t = ts || Date.now(); const out = Object.assign({}, b);
  k.forEach(function(p){ const c = insFasciaCat(f[p], t); if (c) out[p] = c; });
  return out;
}
function insSetCat(pkg, cat){
  const all = insCatsBase();
  if (cat) all[pkg] = cat; else delete all[pkg];
  try { localStorage.setItem('fl_ins_cat', JSON.stringify(all)); } catch(e){}
}
/* LE ESCLUSIONI DI FABBRICA.
   Il compositore telefonico, le impostazioni, il launcher e i servizi Google non sono app
   che si «usano»: sono il telefono. Contarli nel tempo di schermo gonfia il totale con
   minuti su cui non c'e' niente da decidere, e sposta in alto nella classifica righe che
   nessuno ha scelto di aprire. Stanno qui e non in FL_CATS perche' non sono una categoria:
   sono una risposta alla domanda «questo conta?», che viene prima.

   OGNI RIGA SI PUO' RIMETTERE DENTRO. Un'esclusione decisa dall'app e non annullabile e' una
   misura falsata che non si puo' correggere; una che si vede e si annulla e' una scelta
   predefinita. La differenza si vede nella pagina «App escluse», scheda Predefinite. */
/* 0.9.307, Andrea: il 29/10 ha telefonato piu' di un'ora e il Report diceva 2 minuti. Le telefonate sono tempo
   passato al telefono quanto una chat: il compositore, la schermata della chiamata e com.android.phone non sono
   piu' esclusi di fabbrica (il motore li fonde nella riga dell'app telefono, Chiamate.java). */
const INS_PREDEF = [
  'com.android.settings', 'com.android.systemui',
  'com.android.contacts', 'com.google.android.contacts', 'com.samsung.android.app.contacts',
  'com.google.android.gms', 'com.google.android.gsf',
  'com.google.android.googlequicksearchbox',
  'com.android.packageinstaller', 'com.google.android.packageinstaller',
  'com.android.permissioncontroller', 'com.google.android.permissioncontroller',
  'com.sec.android.app.launcher', 'com.google.android.apps.nexuslauncher',
  'com.android.launcher3', 'com.miui.home', 'com.huawei.android.launcher',
  'com.sec.android.app.settings', 'com.samsung.android.lool',
  'com.android.settings.intelligence', 'com.samsung.android.oneconnect'
];
const INS_EXCL_ON = 'fl_ins_excl_riam';     // le predefinite che l'utente ha rimesso dentro
/* Una volta sola: le predefinite tornano escluse. Erano state riammesse tutte per una prova
   che non c'entrava con loro (il tempo dietro al blocco schermo), e restare cosi' sposta in
   classifica il compositore e le impostazioni. */
(function insExclRipristina(){
  try{
    if (localStorage.getItem('fl_excl_reset_v1')) return;
    localStorage.removeItem(INS_EXCL_ON);
    localStorage.setItem('fl_excl_reset_v1', '1');
  }catch(_){ }
})();

/* 0.9.307, una volta sola: chi aveva il telefono fra le escluse lo aveva per via del vecchio elenco di fabbrica
   (o lo aveva tolto a mano dalla scheda Predefinite). Torna nel conto, e dalle riammesse si tolgono le voci che
   non sono piu' predefinite. */
const INS_TELEFONO = /(^|\.)(dialer|incallui)(\.|$)|^com\.android\.phone$|server\.telecom/;
(function insEsclTelefonoVia(){
  try{
    if (localStorage.getItem('fl_excl_telefono_v307')) return;
    const via = function(k){
      let l = []; try{ l = JSON.parse(localStorage.getItem(k) || '[]') || []; }catch(_){ l = []; }
      const n = l.filter(function(p){ return !INS_TELEFONO.test(String(p || '')); });
      if (n.length !== l.length) localStorage.setItem(k, JSON.stringify(n));
    };
    via('fl_ins_excl');
    via(INS_EXCL_ON);
    localStorage.setItem('fl_excl_telefono_v307', '1');
  }catch(_){ }
})();

/** Le esclusioni di fabbrica che l'utente NON ha rimesso dentro. */
function insPredefAttive(){
  let riam = [];
  try { riam = JSON.parse(localStorage.getItem(INS_EXCL_ON) || '[]') || []; } catch(e){ riam = []; }
  return INS_PREDEF.filter(p => riam.indexOf(p) < 0);
}
/** Solo quelle scelte a mano: e' l'elenco che la pagina «Personalizzate» mostra e svuota. */
function insExclMie(){ try { return JSON.parse(localStorage.getItem('fl_ins_excl') || '[]'); } catch(e){ return []; } }

/** Tutto quello che non deve contare. Chi misura chiede questa, non le due sopra. */
function insExcl(){
  const mie = insExclMie();
  return mie.concat(insPredefAttive().filter(p => mie.indexOf(p) < 0));
}

/**
 * Dentro o fuori, da qualunque delle due liste arrivi.
 *
 * <p>Le combinazioni sono quattro e vanno distinte tutte: togliere una predefinita vuol dire
 * scriverla fra le riammesse, non aggiungerla all'elenco personale — dove sarebbe esclusa
 * due volte e il tocco successivo non l'avrebbe rimessa dentro.</p>
 *
 * @return vero se dopo il tocco il pacchetto resta escluso.
 */
function insToggleExcl(pkg){
  const predef = INS_PREDEF.indexOf(pkg) >= 0;
  let riam = [];
  try { riam = JSON.parse(localStorage.getItem(INS_EXCL_ON) || '[]') || []; } catch(e){ riam = []; }
  let mie = insExclMie();

  if (predef){
    const dentro = riam.indexOf(pkg) >= 0;          // riammessa = NON esclusa
    riam = dentro ? riam.filter(p => p !== pkg) : riam.concat([pkg]);
    try { localStorage.setItem(INS_EXCL_ON, JSON.stringify(riam)); } catch(e){}
    return dentro;
  }
  mie = mie.indexOf(pkg) >= 0 ? mie.filter(p => p !== pkg) : mie.concat([pkg]);
  try { localStorage.setItem('fl_ins_excl', JSON.stringify(mie)); } catch(e){}
  return mie.indexOf(pkg) >= 0;
}
function insHasCats(){ return Object.keys(insCats()).length > 0; }

/* One place to talk to the plugin: caches, and turns a rejection into a message the card can
   show. A rejected plugin method must never leave a promise hanging or a spinner spinning. */
async function insGet(key, fn){
  /* LA SORGENTE FA PARTE DELLA DOMANDA. Senza, «le app piu' usate di oggi» e' una chiave
     sola per tre risposte diverse (telefono, computer, tutti e due) e vince chi arriva
     primo. Con la sorgente davanti, ogni risposta ha il suo posto e il cambio si vede
     nello stesso istante. */
  try{ if (typeof mwFonte === 'function') key = mwFonte() + '|' + key; }catch(_){ }
  const hit = INS_CACHE.get(key);
  if (hit && Date.now() - hit.t < INS_TTL) return hit.v;
  const v = await fn();
  INS_CACHE.set(key, { t: Date.now(), v: v });
  return v;
}
function insErr(e){
  const m = e && (e.message || e.errorMessage);
  return m ? String(m) : 'Il motore non ha risposto.';
}
function insCard(title, body, extra){
  return '<div class="ins-card' + (extra ? ' ' + extra : '') + '">'
       + (title ? '<div class="ins-ct">' + title + '</div>' : '') + body + '</div>';
}
function insNote(txt){ return '<div class="ins-miss">' + esc(txt) + '</div>'; }

/* ---------------------------------------------------------------------------------------
   STYLE (prefixed ins-, injected from here: css/app.css is frozen)
   --------------------------------------------------------------------------------------- */
(function insStyle(){
  if (document.getElementById('ins-style')) return;
  const s = document.createElement('style');
  s.id = 'ins-style';
  s.textContent = `
.ins-head{display:flex;align-items:center;gap:8px;padding:10px 0 4px;position:relative}
.ins-head .ins-sp{flex:1}
.ins-ic{width:32px;height:32px;border:none;border-radius:50%;background:rgba(0,30,68,.07);color:var(--ink);font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.ins-dots{display:flex;gap:3px;padding:8px 9px;border:none;border-radius:99px;background:rgba(0,30,68,.07);cursor:pointer}
.ins-dots i{width:7px;height:7px;border-radius:50%;display:block}
.ins-menu{position:absolute;right:0;top:44px;z-index:30;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);overflow:hidden;min-width:184px}
.ins-menu button{display:flex;align-items:center;gap:9px;width:100%;border:none;background:#fff;padding:11px 13px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}
.ins-menu button+button{border-top:1px solid var(--line)}
.ins-menu .ck{margin-left:auto;color:var(--blue);font-size:13px}
/* sopra a tutto, anche alla barra in basso (z-index 40) */
.arb-veil.ins-fveil{z-index:9000}
.arb-menu.ins-fmenu{z-index:9001;min-width:208px}
.arb-menu.ins-fmenu button{display:flex;align-items:center;gap:10px}
.ins-fmenu .ck{margin-left:auto;padding-left:14px;color:var(--blue);font-size:13px}
body.dark .arb-veil.ins-fveil{background:rgba(0,8,20,.62)}
body.dark .arb-menu.ins-fmenu{background:#1C2E5A !important;border:1px solid rgba(188,224,255,.28);box-shadow:0 18px 44px rgba(0,0,0,.55)}
body.dark .arb-menu.ins-fmenu button,body.dark .ins-fmenu .arb-mtit{background:#1C2E5A !important;color:#fff !important}
body.dark .arb-menu.ins-fmenu button + button{border-top-color:rgba(188,224,255,.16) !important}
body.dark .arb-menu.ins-fmenu .arb-mtit{color:#BCE0FF !important}
body.dark .arb-menu.ins-fmenu button.on{color:#8CC6FF !important}
body.dark .ins-fmenu .ck{color:#8CC6FF}
.ins-dot{width:9px;height:9px;border-radius:50%;display:inline-block;flex:none}
.ins-tabs{display:flex;background:rgba(0,30,68,.06);border-radius:99px;padding:3px;margin:8px 0 12px}
.ins-tabs button{flex:1;border:none;background:transparent;border-radius:99px;padding:8px 0;font:700 12px var(--font-body);color:var(--muted);cursor:pointer}
.ins-tabs button.on{background:#fff;color:var(--navy);box-shadow:0 2px 8px rgba(0,30,68,.12)}
.ins-sitelist{margin-top:6px}
.ins-sitelist div{display:flex;justify-content:space-between;gap:10px;padding:5px 0;font:600 12px var(--font-body);color:var(--navy)}
.ins-sitelist div span:last-child{color:var(--muted)}
.ins-per{display:flex;align-items:center;justify-content:center;gap:14px;margin-bottom:10px}
.ins-per button{border:none;background:transparent;font-size:19px;line-height:1;color:var(--blue);cursor:pointer;padding:2px 6px}
.ins-per button[disabled]{visibility:hidden}
.ins-per b{font:700 12.5px var(--font-body);letter-spacing:.06em;color:var(--navy);text-transform:uppercase}
.ins-big{font:800 40px/1 var(--font-display);font-style:italic;color:var(--navy);text-align:center;margin-top:6px}
.ins-testa{position:relative}
.ins-testa .ins-fonte{position:absolute;top:2px;right:0;width:36px;height:36px;border-radius:50%;
  background:#fff !important;border:1.5px solid var(--line) !important;color:var(--navy) !important;
  box-shadow:0 2px 8px rgba(0,30,68,.10);font-size:18px;line-height:1;display:grid;place-items:center}
body.dark .ins-testa .ins-fonte{background:#12203A !important;border-color:#22345A !important;color:#fff !important}
.ins-lbl{font:700 10px var(--font-body);letter-spacing:.1em;color:var(--muted);text-align:center;text-transform:uppercase;margin:6px 0 10px}
.ins-badge{display:block;width:fit-content;margin:0 auto 12px;font:700 11px var(--font-body);padding:5px 12px;border-radius:99px}
.ins-badge.up{color:var(--red);background:var(--red-soft)}
.ins-badge.down{color:#0E7C6B;background:#E2F6F2}
.ins-badge.flat{color:var(--muted);background:rgba(0,30,68,.07)}
.ins-chips{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;margin-bottom:12px}
.ins-chip{display:flex;align-items:center;gap:6px;background:#fff;border:1px solid var(--line);border-radius:99px;padding:5px 11px;font:600 11px var(--font-body);color:var(--muted)}
.ins-chip b{font:700 11.5px var(--font-body);color:var(--navy)}
.ins-plot{display:flex;gap:7px;background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);padding:14px 12px 10px;box-shadow:var(--shadow);margin-bottom:14px}
.ins-y{display:flex;flex-direction:column;justify-content:space-between;font:600 9px var(--font-body);color:var(--faint);height:150px;text-align:right;flex:none;min-width:30px}
.ins-plotbody{flex:1;min-width:0;position:relative}
.ins-hours{gap:2px;padding:0}
.ins-hours .col,.ins-week .col{gap:0;background:rgba(120,140,170,.10);border-radius:4px;overflow:hidden;transition:opacity .25s}
body.dark .ins-hours .col,body.dark .ins-week .col{background:rgba(255,255,255,.06)}
.ins-hours .col i,.ins-hours .col i+i,.ins-week .col i,.ins-week .col i+i{border-radius:0;min-height:0}
.ins-hours .col i:first-child,.ins-week .col i:first-child{border-radius:3px 3px 0 0}
.ins-week{gap:9px;padding:0}
.ins-hours{cursor:pointer}
.ins-hours.ins-sel .col{opacity:.3}
.ins-hours.ins-sel .col.on{opacity:1}
.ins-sale .col i{transform-origin:50% 100%;animation:insSale .7s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i,0) * 22ms)}
@keyframes insSale{from{transform:scaleY(0)}to{transform:scaleY(1)}}
.ins-x{display:flex;font:600 9px var(--font-body);color:var(--faint);margin-top:4px}
.ins-x span{flex:1;text-align:center;min-width:0}
.ins-avg{position:absolute;left:0;right:0;border-top:2px dashed #9FB6CF;pointer-events:none}
/* 0.9.305, Andrea: la linea tratteggiata della settimana non diceva cos'era */
.ins-avgl{position:absolute;left:2px;top:0;transform:translateY(-50%);padding:1px 6px;border-radius:6px;background:var(--card,#fff);color:#5E7391;font:700 10px/1.4 var(--font-body);letter-spacing:.02em;white-space:nowrap}
body.dark .ins-avgl{background:var(--card);color:#BCE0FF}
.ins-flag{position:absolute;right:0;transform:translateY(-50%);background:var(--navy);color:#fff;font:700 9.5px var(--font-body);padding:3px 7px;border-radius:6px;white-space:nowrap}
.ins-card{background:var(--card);border:1px solid var(--line);border-radius:var(--r-lg);padding:15px;box-shadow:var(--shadow);margin-bottom:12px}
.ins-ct{font:700 13.5px var(--font-display);color:var(--navy);margin-bottom:10px;display:flex;align-items:center;gap:6px}
.ins-ct .info{font:600 10px var(--font-body);color:var(--faint);border:1px solid var(--line);border-radius:50%;width:15px;height:15px;display:flex;align-items:center;justify-content:center}
.ins-row{display:flex;align-items:center;gap:8px;font:600 12px var(--font-body);color:var(--muted);margin-bottom:7px}
.ins-row b{margin-left:auto;color:var(--navy);font:700 12px var(--font-body)}
.ins-track{height:7px;border-radius:99px;background:#EDF3FA;overflow:hidden;margin-bottom:11px;display:flex}
.ins-track i{display:block;height:100%}
.ins-sub{font:500 11px/1.55 var(--font-body);color:var(--faint)}
.ins-miss{font:500 11.5px/1.6 var(--font-body);color:var(--faint);background:rgba(0,30,68,.04);border-radius:12px;padding:10px 12px;margin-bottom:12px}
.ins-approx{font:600 12px/1.5 var(--font-body);color:#005BB0;background:#E3F1FF;border:1px solid #BCE0FF;border-radius:12px;padding:9px 12px;margin-bottom:12px;text-align:center}
body.dark .ins-approx{color:#BCE0FF;background:#14234A;border-color:#22376B}
.ins-week-vuota{height:150px;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 14px;font:600 12.5px/1.5 var(--font-body);color:var(--muted)}
.ins-week .col.ins-perso{background:repeating-linear-gradient(135deg,rgba(120,140,170,.16) 0 4px,transparent 4px 8px)}
.ins-promo{display:flex;gap:10px;align-items:flex-start;background:var(--blue-soft);border-radius:var(--r-md);padding:13px;margin-bottom:12px}
.ins-promo p{font:600 12px/1.5 var(--font-body);color:var(--navy);margin-bottom:9px}
.ins-promo .x{border:none;background:transparent;color:var(--muted);font-size:14px;cursor:pointer;flex:none}
.ins-promo button.go{border:none;background:var(--blue);color:#fff;border-radius:99px;padding:7px 15px;font:700 11.5px var(--font-body);cursor:pointer}
.ins-app{display:flex;align-items:center;gap:11px;background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);padding:11px 13px;margin-bottom:9px;cursor:pointer}
.ins-ico{width:36px;height:36px;border-radius:11px;flex:none;display:flex;align-items:center;justify-content:center;font:800 15px var(--font-display);color:#fff}
.ins-app .nm{min-width:0;flex:1}
.ins-app .nm b{display:block;font:600 12.5px var(--font-body);color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ins-app .nm span{display:flex;align-items:center;gap:5px;font:600 10px var(--font-body);color:var(--faint);margin-top:3px}
.ins-app .tm{font:700 11.5px var(--font-body);color:var(--muted);flex:none}
.ins-app .chev{color:var(--faint);font-size:17px;flex:none}
.ins-more{display:flex;align-items:center;gap:7px;margin:0 auto 12px;border:1px solid var(--line);background:#fff;border-radius:99px;padding:8px 18px;font:700 11.5px var(--font-body);color:var(--navy);cursor:pointer}
.ins-sites{background:#F7FBFF;border:1px dashed var(--line);border-radius:12px;padding:11px 13px;margin:-4px 0 9px;font:500 11.5px/1.6 var(--font-body);color:var(--muted)}
.ins-total{display:flex;align-items:center;background:var(--navy);border-radius:var(--r-md);padding:12px 14px;margin-bottom:10px}
.ins-total span{font:600 11.5px var(--font-body);color:#B8D6F5}
.ins-total b{margin-left:auto;font:800 15px var(--font-display);font-style:italic;color:#fff}
.ins-sect-note{margin-left:auto;font:500 12px var(--font-body);color:var(--muted)}
.ins-per-left{justify-content:center;gap:10px;margin:4px 0 8px}
.ins-per-left b{font-size:14px;letter-spacing:.08em}
.ins-round{width:34px;height:34px;border-radius:50%;border:none;background:rgba(0,30,68,.06);color:var(--navy);font-size:20px;line-height:1;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
.ins-round[disabled]{opacity:.25}
.ins-plot.right{flex-direction:row-reverse}
.ins-plot.right .ins-y{text-align:left}
.ins-catbadge{display:inline-block;margin:0 auto 6px;font:700 11px var(--font-body);padding:4px 10px;border-radius:99px}
.ins-avoid{text-align:center}
.ins-avoid .big{font:800 34px/1 var(--font-display);font-style:italic;color:var(--navy)}
.ins-avoid .lbl{font:600 12.5px var(--font-body);color:var(--muted);margin-top:6px}
.ins-exrow{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);padding:13px 14px;margin-top:6px}
.ins-exrow .x{width:26px;height:26px;border-radius:50%;background:var(--red);color:#fff;display:flex;align-items:center;justify-content:center;font:800 13px var(--font-body);flex:none}
.ins-exrow > div{flex:1;min-width:0}
.ins-exrow b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}
.ins-exrow small{display:block;font:500 11px/1.45 var(--font-body);color:var(--muted);margin-top:2px}
.ins-addlist{max-height:46vh;overflow-y:auto;margin:6px 0 4px}
.ins-addrow{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);padding:12px 14px;margin-bottom:8px;cursor:pointer}
.ins-addrow .ic{font-size:20px;flex:none}
.ins-addrow > div{flex:1;min-width:0}
.ins-addrow b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}
.ins-addrow small{display:block;font:600 11px var(--font-body);color:var(--muted);margin-top:2px}
.ins-addrow small.on{color:var(--blue)}
.ins-addrow input{width:22px;height:22px;accent-color:var(--blue);flex:none}
.ins-3{display:flex;gap:9px;margin:4px 0 12px}
/* la pagina a carte */
#s-ins-cat{display:flex;flex-direction:column;padding:0 18px calc(18px + env(safe-area-inset-bottom))}
.ic-top{display:flex;align-items:center;height:56px;margin:0 -6px}
.ic-x{width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:#0075E3;font:800 20px var(--font-body);cursor:pointer}
.ic-titolo{margin:0 0 14px;text-align:center;font:800 24px/1.2 var(--font-display);color:var(--navy)}body.dark .ic-titolo{color:#fff}
.ic-mazzo{position:relative;height:56vh;min-height:330px;max-height:470px;margin:0 6px}
.ic-card{position:absolute;inset:0;border-radius:26px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 14px 34px rgba(0,30,68,.18);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;text-align:center;touch-action:pan-y;user-select:none;cursor:grab;transition:transform .25s ease,background .2s,border-color .2s}
body.dark .ic-card{background:#141C2C;border-color:#25314A}
.ic-card.dietro{transform:scale(.94) translateY(14px);opacity:.75;box-shadow:none}
.ic-ico{width:96px;height:96px;border-radius:26px;overflow:hidden;display:flex;align-items:center;justify-content:center;background:rgba(0,117,227,.08)}
.ic-ico img{width:100%;height:100%;object-fit:cover}
.ic-lettera{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#fff;font:800 40px var(--font-display)}
.ic-card b{font:800 24px/1.15 var(--font-display);color:var(--navy);margin-top:6px}body.dark .ic-card b{color:#fff}
.ic-card small{font:600 14px var(--font-body);color:var(--muted)}
.ic-tag{position:absolute;top:22px;padding:8px 14px;border-radius:12px;border:3px solid;font:900 15px var(--font-display);letter-spacing:.06em;text-transform:uppercase;opacity:0;transform:rotate(-12deg);transition:opacity .15s}
.ic-tag.prod{left:22px;color:#fff;border-color:#fff}.ic-tag.distr{right:22px;color:#fff;border-color:#fff;transform:rotate(12deg)}
.ic-card.prod{background:#0075E3;border-color:#0075E3}.ic-card.prod b,.ic-card.prod small{color:#fff}.ic-card.prod .ic-tag.prod{opacity:1}
.ic-card.distr{background:#E63946;border-color:#E63946}.ic-card.distr b,.ic-card.distr small{color:#fff}.ic-card.distr .ic-tag.distr{opacity:1}
.ic-card.neutro{background:#8CC6FF;border-color:#8CC6FF}.ic-card.neutro b,.ic-card.neutro small{color:#001E44}
.ic-tondi{display:flex;justify-content:space-around;align-items:flex-start;margin:22px 6px 10px}
.ic-tondo{border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer;padding:0}
.ic-tondo span{width:76px;height:76px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font:800 30px var(--font-body);box-shadow:0 8px 20px rgba(0,30,68,.2);transition:transform .15s}
.ic-tondo:active span{transform:scale(.92)}
.ic-tondo.distr span{background:#E63946}.ic-tondo.neutro span{background:#8CC6FF}.ic-tondo.prod span{background:#0075E3}
.ic-tondo.on span{color:#fff}
.ic-tondo.distr.on span{box-shadow:0 0 0 4px rgba(255,255,255,.9),0 0 0 7px #E63946}.ic-tondo.neutro.on span{box-shadow:0 0 0 4px rgba(255,255,255,.9),0 0 0 7px #8CC6FF}.ic-tondo.prod.on span{box-shadow:0 0 0 4px rgba(255,255,255,.9),0 0 0 7px #0075E3}
.ic-tondo small{font:700 13px var(--font-body);color:var(--navy)}body.dark .ic-tondo small{color:#fff}
.ic-escludi{display:block;margin:8px auto 0;border:0;background:transparent;color:var(--muted);font:600 14px var(--font-body);cursor:pointer;padding:10px}
.ic-conta{text-align:center;font:600 12px var(--font-body);color:var(--muted);margin-top:4px}
.ic-fine{text-align:center;padding:40px 10px}.ic-fine-ico{font-size:56px}.ic-fine h3{margin:12px 0 6px;font:800 22px var(--font-display);color:var(--navy)}body.dark .ic-fine h3{color:#fff}.ic-fine p{margin:0 0 20px;font:500 14px var(--font-body);color:var(--muted)}
.ins-pick{flex:1;border:2px solid var(--line);background:#fff;border-radius:var(--r-md);padding:13px 6px;text-align:center;cursor:pointer}
.ins-pick .face{width:38px;height:38px;border-radius:50%;margin:0 auto 7px;display:flex;align-items:center;justify-content:center;font-size:19px;color:#fff}.ins-pick .face .ins-faccia{width:26px;height:26px;display:block;color:#fff}
.ins-pick b{font:700 11px var(--font-body);color:var(--navy);display:block}
.ins-pick.on{border-color:var(--blue);background:var(--blue-soft)}
.ins-prem{display:flex;align-items:center;gap:10px;border:1.5px dashed var(--line);border-radius:var(--r-md);padding:13px;margin-bottom:12px;background:#fff;cursor:pointer;width:100%;text-align:left}
.ins-prem b{font:700 12.5px var(--font-body);color:var(--navy)}
.ins-prem small{display:block;font:500 10.5px var(--font-body);color:var(--faint);margin-top:2px}
.ins-line{width:100%;height:150px;display:block}
.ins-detail-head{display:flex;align-items:center;justify-content:center;gap:11px;margin-bottom:8px;text-align:center}
.ins-chiam{margin:14px 0 4px;padding:14px 16px;border:1.5px solid var(--line,#E5ECF6);border-radius:18px;background:#fff;text-align:center}
.ins-chiam p{margin:0 0 12px;font:500 13px/1.5 var(--font-body);color:var(--muted)}
.ins-chiam-btn{display:inline-block;border:2px solid #0075E3;background:#fff;color:#0075E3;border-radius:50px;padding:11px 20px;font:800 14px var(--font-body);cursor:pointer}
.ins-chiam-btn:active{transform:scale(.97)}
body.dark .ins-chiam{background:#1C2E5A;border-color:#2D4478}
body.dark .ins-chiam p{color:#BCE0FF}
body.dark .ins-chiam-btn{background:transparent;color:#8CC6FF;border-color:#8CC6FF}
.ins-detail-head b{font:800 17px var(--font-display);font-style:italic;color:var(--navy)}
.ins-load{font:600 11px var(--font-body);color:var(--faint);text-align:center;margin-bottom:10px}
.ins-scheletro{display:flex;flex-direction:column;gap:12px;padding:6px 0}.ins-scheletro i{display:block;height:64px;border-radius:16px;background:linear-gradient(90deg,var(--line,#E5ECF6) 0%,rgba(229,236,246,.45) 50%,var(--line,#E5ECF6) 100%);background-size:200% 100%;animation:insSch 1.2s linear infinite}.ins-scheletro i.g{height:120px}.ins-scheletro i.b{height:180px}@keyframes insSch{from{background-position:100% 0}to{background-position:-100% 0}}
`;
  document.head.appendChild(s);
})();

/* ---------------------------------------------------------------------------------------
   SCREENS (registered here, never in index.html)
   --------------------------------------------------------------------------------------- */

registerScreen('s-ins-app', `
  <div class="topbar"><button class="iconbtn" onclick="insCloseDetail()" aria-label="Indietro">${INS_INDIETRO}</button></div>
  <div class="ins-detail-head" id="insDetHead"></div>
  <div id="insDetBody"></div>
`, { back: function(){ return insDetailBack(); } });

registerScreen('s-ins-cat', `
  <div class="ic-top"><button type="button" class="ic-x" onclick="insCatClose()" aria-label="Chiudi">✕</button></div>
  <h2 class="ic-titolo">Questa app è per me…</h2>
  <div id="insCatBody"></div>
`, { back: function(){ return insCatBackTarget(); } });

/* ---------------------------------------------------------------------------------------
   ENTRY POINT — called by nav.js syncNative()
   --------------------------------------------------------------------------------------- */

async function refreshScreenTime(){
  const empty = document.getElementById('insEmpty');
  const data  = document.getElementById('insData');
  if (!empty || !data) return;

  insBuildShell();

  // Browser preview: no engine, so no numbers. Say it once, next to the empty state, instead
  // of drawing a section full of dashes.
  if (!NATIVE){
    empty.hidden = false; data.hidden = true;
    let n = document.getElementById('insPreview');
    if (!n){
      n = document.createElement('div');
      n.id = 'insPreview';
      n.className = 'ins-miss';
      n.style.marginTop = '14px';
      n.textContent = 'Anteprima nel browser: i dati di utilizzo arrivano dal motore Android, qui non c\'è nulla da leggere.';
      empty.appendChild(n);
    }
    return;
  }

  let granted = false;
  try {
    const g = NATIVE.isUsageAccessGranted ? await NATIVE.isUsageAccessGranted()
                                          : await NATIVE.getScreenTimeToday();
    granted = !!(g.granted);
  } catch(e){ granted = false; }

  INS.granted = granted;
  empty.hidden = granted;
  data.hidden = !granted;
  if (!granted) return;

  // Only paint when the section is actually on screen: syncNative() also fires from the other
  // three tabs and every render costs the phone several usage-event scans.
  const page = document.getElementById('tab-insights');
  if (page && !page.classList.contains('on') && !INS.forceRender) return;
  INS.forceRender = false;
  insRender();
}

/* The onboarding "reveal": after usage access is granted, replace the mystery chart with the
   real screen time and how it compares to the guess — the moment the app proves it knows
   something the user does not. */
async function refreshUsageReveal(){
  if (order[cur] !== 's6' || !NATIVE) return;
  try{
    const st = await NATIVE.getScreenTimeToday();
    if (!st.granted) return;
    if (window.__s6done) return;
    window.__s6done = true;
    await onbRunAnalysis(st);
  }catch(e){ console.warn('reveal', e); }
}

/* The report the permission was asked for. Like StayFocused: a ring that fills while the
   numbers are really being read, then everything at once - 7-day average against the
   user's own estimate, the longest day, a bar per day, pickups when we have them, the years
   of life at this pace, and what a daily block typically gives back. */
function onbFmt(m){ m = Math.round(m || 0); return (m >= 60 ? Math.floor(m/60) + 'h ' : '') + (m % 60) + 'm'; }
function onbFmtLong(m){ m = Math.round(m || 0); const h = Math.floor(m/60); return (h ? h + ' ' + (h === 1 ? 'ora' : 'ore') + ' e ' : '') + (m % 60) + ' min'; }

async function onbRunAnalysis(todayStat){
  const ask = document.getElementById('s6ask'), ring = document.getElementById('s6ring'), rep = document.getElementById('s6report');
  const grant = document.getElementById('usageGrantBtn'), skip = document.getElementById('usageSkipBtn');
  if (!ask || !ring || !rep) return;
  ask.hidden = true; ring.hidden = false; grant.hidden = true; if (skip) skip.hidden = true;

  // the ring fills on a clock, the data is fetched underneath; whichever is slower ends it
  const fg = document.getElementById('ringFg'), pct = document.getElementById('ringPct'), msg = document.getElementById('ringMsg');
  const C = 326.7; let p = 0;
  const msgs = ['Leggo gli ultimi sette giorni.', 'Conto le app più usate.', 'Cerco il giorno più lungo.', 'Preparo il tuo rapporto.'];
  const tick = setInterval(function(){
    p = Math.min(96, p + 3);
    fg.style.strokeDashoffset = C - C * p / 100; pct.textContent = p + '%';
    msg.textContent = msgs[Math.min(msgs.length - 1, Math.floor(p / 25))];
  }, 90);

  let days = [], avg = 0, longest = null, pickups = 0;
  try{
    const start = new Date(); start.setHours(0,0,0,0);
    const dayMs = 86400000;
    const r = await NATIVE.getScreenTimeRange({ from: start.getTime() - 6*dayMs, to: Date.now(), bucket: 'day' });
    const bs = (r && r.buckets) || [];
    days = bs.map(function(b){ const d = new Date(b.start); return { d: d, min: b.minutes || 0 }; });
    // today is partial: count it only if it is already the longest, otherwise average the full days
    const full = days.slice(0, -1);
    const base = full.length ? full : days;
    avg = base.reduce(function(a, x){ return a + x.min; }, 0) / (base.length || 1);
    longest = days.reduce(function(m, x){ return (!m || x.min > m.min) ? x : m; }, null);
  }catch(e){ days = []; avg = todayStat.minutes || 0; }
  try{ const ins = await NATIVE.getInsights({ days: 1 }); pickups = (ins && ins.pickupsToday) || 0; }catch(_){ }

  await new Promise(function(res){ setTimeout(res, 2600); });
  clearInterval(tick);
  fg.style.strokeDashoffset = 0; pct.textContent = '100%';
  await new Promise(function(res){ setTimeout(res, 450); });

  // ---- fill the report, then reveal it in stages: one number at a time, the detail on request ----
  const est = parseInt(localStorage.getItem('fl_estimate') || '0', 10);
  const estEl = document.getElementById('repEst');
  if (est){ estEl.hidden = false; document.getElementById('repEstV').textContent = est + 'h'; }
  document.getElementById('repAvg').textContent = onbFmt(avg);
  const dn = ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'];
  if (longest) document.getElementById('repLong').textContent = 'Giorno più lungo: ' + dn[longest.d.getDay()] + ', ' + onbFmtLong(longest.min);
  const chart = document.getElementById('repChart');
  const maxMin = Math.max(60, days.reduce(function(m, x){ return Math.max(m, x.min); }, 0));
  chart.innerHTML = days.map(function(x){
    const h = Math.max(2, Math.round(x.min / maxMin * 100));
    return '<div class="b' + (longest && x === longest ? ' max' : '') + '"><i style="height:' + h + '%"></i><small>' + dn[x.d.getDay()] + '</small></div>';
  }).join('') + '<div class="avg" style="bottom:' + (22 + Math.round(avg / maxMin * 120)) + 'px"></div>';
  if (pickups > 0){ document.getElementById('repPick').hidden = false; document.getElementById('repPickV').textContent = pickups + 'x'; }
  const years = (avg / 1440) * 30;
  document.getElementById('lifeDaily').textContent = onbFmt(avg);
  document.getElementById('lifeYears').textContent = years.toFixed(1).replace('.', ',') + ' anni';
  document.getElementById('potYou').textContent = onbFmt(avg);
  document.getElementById('potUs').textContent = onbFmt(avg * 0.2);
  localStorage.setItem('fl_report', JSON.stringify({ avg: Math.round(avg), years: years, at: Date.now() }));

  // the three most distracting apps of the week, like AppBlock
  try{
    const start = new Date(); start.setHours(0,0,0,0);
    const top = await NATIVE.getTopApps({ from: start.getTime() - 6*86400000, to: Date.now(), limit: 3 });
    const box = document.getElementById('repTop');
    const apps = (top && top.apps) || [];
    if (box && apps.length){
      box.hidden = false;
      box.querySelector('.rows').innerHTML = apps.map(function(a){
        const ico = a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="lt">' + ((a.label||'?').charAt(0)) + '</span>';
        return '<div class="tr">' + ico + '<b>' + (a.label || a.packageName) + '</b><span>' + onbFmt(a.minutes) + '</span></div>';
      }).join('');
    }
  }catch(_){ }

  // reveal
  const st = ['repStageA','repStageB','repStageC'].map(function(id){ return document.getElementById(id); });
  st.forEach(function(el){ if(el){ el.hidden = true; el.classList.remove('in'); } });
  const showBtn = document.getElementById('repShowBtn'); if (showBtn) showBtn.hidden = true;
  const reveal = function(el, delay){ return new Promise(function(res){ setTimeout(function(){ if(el){ el.hidden = false; requestAnimationFrame(function(){ el.classList.add('in'); }); } res(); }, delay); }); };
  grant.hidden = true;
  ring.hidden = true; rep.hidden = false;
  const sc = document.getElementById('s6'); if (sc) sc.scrollTop = 0;
  /* UN NUMERO ALLA VOLTA. Prima c'erano la media, gli anni di vita e il pulsante del
     rapporto completo tutti insieme, e Andrea l'ha detto: confusionario. AppBlock (e Detox,
     con il suo «8 years back on track» su schermo nero) mostrano UN dato, e aspettano il
     dito prima del successivo. Cosi' adesso: la media da sola → tocco → gli anni di vita da
     soli → tocco → il rapporto completo solo a chi lo chiede. */
  const dopo = function(){
    if (typeof gnPonte === 'function') gnPonte(); else go(4);
  };
  await reveal(st[0], 120);          // the average, alone
  grant.hidden = false; grant.textContent = 'Continua';
  grant.onclick = function(){
    if (st[0]) st[0].hidden = true;
    grant.hidden = true;
    reveal(st[1], 80).then(function(){   // the years of life, alone
      grant.hidden = false; grant.textContent = 'Continua';
      grant.onclick = dopo;
      if (showBtn){
        showBtn.hidden = false;
        showBtn.onclick = async function(){
          showBtn.hidden = true;
          await reveal(st[2], 60);       // the breakdown, only when asked
          grant.hidden = false; grant.textContent = 'Continua'; grant.onclick = dopo;
          setTimeout(function(){ try{ st[2].scrollIntoView({ behavior: 'smooth', block: 'start' }); }catch(_){ } }, 250);
        };
      }
    });
  };
}

/* ---------------------------------------------------------------------------------------
   SHELL: header, segmented control, period navigator
   --------------------------------------------------------------------------------------- */

function insBuildShell(){
  const data = document.getElementById('insData');
  if (!data || INS.built) return;
  data.innerHTML = `
    <div class="ins-sticky">
    <div class="ins-head">
      <button class="ins-ic" onclick="insSettings()" aria-label="Impostazioni del report">⚙️</button>

      <span class="ins-sp"></span>
      <button class="ins-dots" onclick="insToggleMenu(event)" aria-label="Filtro categorie">
        <i style="background:${INS_CAT.distr.color}"></i>
        <i style="background:${INS_CAT.neutro.color}"></i>
        <i style="background:${INS_CAT.prod.color}"></i>
      </button>
    </div>
    <div class="ins-tabs" id="insTabs">
      <button data-v="giorno" onclick="insSetView('giorno')">Giorno</button>
      <button data-v="settimana" onclick="insSetView('settimana')">Settimana</button>
      <button data-v="tendenza" onclick="insSetView('tendenza')">Tendenza</button>
    </div>
    <div class="ins-per" id="insPer"></div>
    </div>
    <div id="insBody"></div>
  `;
  INS.built = true;
  insTestaSposta();
}
/* 0.9.288, Andrea: "l'ingranaggio e i tre pallini non sono sulla stessa altezza del titolo Report: devono stare in alto
   come su AppBlock". L'intestazione con il titolo sta fuori dalla scheda che scorre: la riga dei due pulsanti si
   sposta li' dentro, sopra al titolo centrato, e si vede solo nella scheda Report. Sotto restano, ferme in cima mentre
   si scorre, Giorno/Settimana/Tendenza e i giorni. */
function insTestaSposta(){
  const testa = document.querySelector('#s-home .home-head');
  const riga = document.querySelector('#insData .ins-head');
  if (!testa || !riga) return;
  riga.classList.add('ins-head-top');
  testa.appendChild(riga);
  insTestaMostra();
}
function insTestaMostra(){
  const riga = document.querySelector('.home-head .ins-head-top'); if (!riga) return;
  const tab = document.getElementById('tab-insights');
  riga.hidden = !(tab && tab.classList.contains('on'));
}
document.addEventListener('fl:tab', function(){ setTimeout(insTestaMostra, 0); });
document.addEventListener('fl:screen', function(){ setTimeout(insTestaMostra, 0); });

function insSetView(v){
  INS.view = v;
  INS.oraSel = null;
  INS.showAllApps = false;
  INS.forceRender = true;
  insRender();
}
function insStep(dir){
  INS.oraSel = null;
  if (INS.view === 'giorno'){ INS.dayOff = Math.max(0, INS.dayOff - dir); }
  else if (INS.view === 'settimana'){ INS.weekOff = Math.max(0, INS.weekOff - dir); }
  INS.showAllApps = false;
  INS.forceRender = true;
  insRender();
}
/* One popover, two contents: the three-dot category filter (G46) and the ⚙ menu (G57). */
/* 0.9.305, Andrea: "il menu dei tre puntini non ha il velo dietro, la card del grafico gli passa sopra, c'e' un pezzo
   bianco in alto e toccando fuori non si chiude". CAUSA VERA: il menu era assoluto dentro alla riga dei pulsanti, che
   insTestaSposta ha spostato nell'intestazione della Home; la fascia ferma di Giorno/Settimana/Tendenza (sticky) ha il
   suo contesto di impilamento e gli passava sopra, e senza velo non c'era niente da toccare per chiudere. Adesso e'
   come il menu della sorgente: velo scuro e menu fisso appesi al telefono (flVeloCasa), posizionati sui tre puntini. */
function insMenu(kind, trigger){
  if (INS.menu === kind && document.getElementById('insMenuF')){ insMenuClose(); return; }
  insMenuClose();
  INS.menu = kind;
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const v = document.createElement('div');
  v.id = 'insMenuV'; v.className = 'arb-veil ins-fveil';
  v.addEventListener('click', function(e){ e.stopPropagation(); insMenuClose(); });
  casa.appendChild(v);
  const m = document.createElement('div');
  m.id = 'insMenuF'; m.className = 'arb-menu ins-fmenu';
  casa.appendChild(m);
  if (kind === 'filter'){
    const row = (k, label, color) =>
      '<button onclick="insSetFilter(\'' + k + '\')"><span class="ins-dot" style="background:'
      + (color || 'linear-gradient(90deg,' + INS_CAT.distr.color + ',' + INS_CAT.prod.color + ')')
      + '"></span>' + label + '<span class="ck">' + (INS.filter === k ? '✓' : '') + '</span></button>';
    /* DA QUALE DISPOSITIVO. Sopra al grafico, dentro ai tre puntini che ci sono gia', e solo
       se il secondo dispositivo esiste davvero: telefono, computer, o i due insieme. */
    const fonti = (typeof mwMenuHtml === 'function') ? mwMenuHtml() : '';
    m.innerHTML = (fonti ? fonti + '<p class="arb-mtit">Categorie</p>' : '')
                + row('all', 'Tutto', null)
                + row('distr', INS_CAT.distr.label, INS_CAT.distr.color)
                + row('neutro', INS_CAT.neutro.label, INS_CAT.neutro.color)
                + row('prod', INS_CAT.prod.label, INS_CAT.prod.color);
  } else {
    m.innerHTML = '<button onclick="insMenuClose();insSortApps()">🎯 Ordina le app</button>'
                + '<button onclick="insResetCats()">↺ Azzera le categorie</button>'
                + '<button onclick="insResetExcl()">👁 Reinserisci le app escluse</button>';
  }
  const trig = (trigger && trigger.getBoundingClientRect) ? trigger
    : document.querySelector(kind === 'settings' ? '.ins-head-top .ins-ic, .ins-head .ins-ic' : '.ins-head-top .ins-dots, .ins-head .ins-dots');
  if (typeof flMenuFissa === 'function') flMenuFissa(m, trig);
}
function insMenuClose(){
  INS.menu = '';
  ['insMenuF', 'insMenuV'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); });
}

/* Il menu della sorgente, appeso ai tre puntini sopra al grafico. */
function insFonteMenu(ev){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('insFonteM')){ insFonteChiudi(); return; }
  const v = document.createElement('div');
  v.id = 'insFonteV'; v.className = 'arb-veil ins-fveil';
  v.addEventListener('click', function(e){ e.stopPropagation(); insFonteChiudi(); });
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(v);
  const m = document.createElement('div');
  m.id = 'insFonteM'; m.className = 'arb-menu ins-fmenu';
  m.innerHTML = (typeof mwMenuHtml === 'function') ? mwMenuHtml() : '';
  (typeof flVeloCasa === 'function' ? flVeloCasa() : document.body).appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, ev && ev.currentTarget);
}
function insFonteChiudi(){
  ['insFonteM', 'insFonteV'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); });
}

function insToggleMenu(ev){ if (ev) ev.stopPropagation(); insMenu('filter', ev && ev.currentTarget); }
/* L'ingranaggio apre una PAGINA, non piu' un menu di tre voci appeso all'icona.
   Le impostazioni del Report decidono cosa i numeri SIGNIFICANO — quali app contano, come
   sono classificate, cosa e' escluso — e una cosa cosi' non sta in un menu che si chiude se
   sbagli a toccare. Il menu vecchio resta raggiungibile per i tre puntini del filtro. */
function insSettings(){
  if (typeof rpImpostazioni === 'function'){ rpImpostazioni(); return; }
  insMenu('settings');
}
function insSetFilter(k){
  INS.filter = k;
  insMenuClose();
  INS.forceRender = true;
  insRender();
}
function insResetCats(){
  try { localStorage.removeItem('fl_ins_cat'); } catch(e){}
  INS_CACHE.clear();
  insMenuClose(); toast('Categorie azzerate');
  INS.forceRender = true; insRender();
}
function insResetExcl(){
  try { localStorage.removeItem('fl_ins_excl'); } catch(e){}
  insMenuClose(); toast('Nessuna app è più esclusa');
  INS.forceRender = true; insRender();
}
async function insShare(){
  // Shares the figures currently on screen, and only those: nothing is recomputed or rounded
  // up for the occasion.
  const t = document.getElementById('insShareText');
  const txt = t ? t.value : '';
  if (!txt){ toast('Niente da condividere'); return; }
  try{
    if (navigator.share){ await navigator.share({ text: txt }); return; }
    if (navigator.clipboard){ await navigator.clipboard.writeText(txt); toast('Copiato negli appunti'); return; }
  }catch(e){ /* user dismissed the sheet: nothing to report */ return; }
  toast('Condivisione non disponibile qui');
}

function insPeriodBar(){
  const bar = document.getElementById('insPer');
  if (!bar) return;
  document.querySelectorAll('#insTabs button').forEach(b => b.classList.toggle('on', b.dataset.v === INS.view));

  bar.classList.toggle('trend', INS.view === 'tendenza');
  if (INS.view === 'tendenza'){
    const start = insAddDays(insDayStart(Date.now()), -59);
    const d = new Date(start);
    bar.innerHTML = '<b>Da ' + INS_MONTHS[d.getMonth()] + ' ' + d.getFullYear() + '</b>';
    return;
  }
  let label, atNow;
  if (INS.view === 'giorno'){
    const ts = insAddDays(insDayStart(Date.now()), -INS.dayOff);
    label = insDataPeriodo(ts, INS.dayOff);
    atNow = INS.dayOff === 0;
  } else {
    const ws = insAddDays(insWeekStart(Date.now()), -7 * INS.weekOff);
    label = insDateLabel(ws) + ' - ' + insDateLabel(insAddDays(ws, 6));
    atNow = INS.weekOff === 0;
  }
  // The forward arrow is not disabled, it is absent: there is no data after today and an arrow
  // that does nothing is a promise the app cannot keep.
  const cosa = INS.view === 'giorno' ? 'Giorno' : 'Settimana';
  bar.innerHTML = '<button onclick="insStep(-1)" aria-label="' + cosa + ' prima">' + INS_CHEV.sx + '</button><b>' + esc(label) + '</b>'
                + '<button onclick="insStep(1)" aria-label="' + cosa + ' dopo" ' + (atNow ? 'disabled' : '') + '>' + INS_CHEV.dx + '</button>';
}

/* ---------------------------------------------------------------------------------------
   RENDER DISPATCH
   --------------------------------------------------------------------------------------- */

/* GLI INTERRUTTORI DELLA PAGINA «Impostazioni» (report.js).
   Qui si legge il loro effetto, non il loro valore: chi disegna non deve sapere dove sono
   scritti, e il giorno in cui si spostano cambia un posto solo. */
function insStatOn(){
  const S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
  return S.statsOn !== false;
}
function insStatApps(){
  const S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
  return S.statsOn !== false && S.statsApps !== false;
}

/* 0.9.260, Andrea: AppBlock mostra i numeri due secondi dopo l'apertura dell'app, anche la prima volta. Qui
   la pagina del Report si disegna (nascosta) appena l'app e' su: quando la apri, c'e' gia'. */
function insPrecarica(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return;
    if (!document.getElementById('insData')) return;
    const att = document.querySelector('.tab.active, [data-tab].on');
    insRender();
  }catch(_){ }
}
setTimeout(insPrecarica, 1800);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(function(){ try{ if (localStorage.getItem('fl_tab') !== 'insights') insPrecarica(); }catch(_){ } }, 1200); });
function insRender(){
  insBuildShell();
  insPeriodBar();
  const body = document.getElementById('insBody');
  if (!body) return;
  /* SPENTO VUOL DIRE SPENTO, e va detto da chi l'ha spento.
     Una pagina vuota lascia pensare a un guasto, e chi sospetta un guasto non va a cercare
     l'interruttore: aspetta. Qui c'e' scritto cos'e' successo e dov'e' la levetta. */
  if (!insStatOn()){
    body.innerHTML = '<div class="ins-card" style="text-align:center;padding:30px 20px">'
      + '<div style="font-size:40px;line-height:1">\u{1F4CA}</div>'
      + '<div class="ins-ct" style="margin:12px 0 6px">Statistiche spente</div>'
      + '<p style="font:500 13px/1.6 var(--font-body);color:var(--muted);margin:0 0 20px">'
      +   'Hai chiesto tu a DreamMap di non misurare niente. Finch\u00e9 resta cos\u00ec, '
      +   'questa pagina non ha numeri da mostrarti.</p>'
      + '<button class="cta" onclick="rpStatApri()">Riaccendile</button></div>';
    return;
  }
  const token = ++INS.token;
  /* 0.9.259, Andrea: niente «Leggo i dati»: si mostra SUBITO l'ultima pagina disegnata per questa vista
     (fl_ins_cache_*) e i numeri freschi la sostituiscono appena arrivano. AppBlock fa cosi'. */
  /* 0.9.353: la pagina salvata ha anche la sorgente nel nome. Con un nome solo, passando al computer si vedevano
     per qualche secondo i numeri del telefono; adesso si vede subito l'ultima pagina del computer, poi quella fresca */
  const fonteSnap = insFonteOra();
  const snapKey = insSnapChiave();
  let vecchio = ''; try{ vecchio = localStorage.getItem(snapKey) || ''; }catch(_){ }
  /* 0.9.260, Andrea: mai "Un attimo". Senza pagina di prima si vede lo scheletro della pagina, senza parole,
     e la pagina e' gia' stata disegnata all'avvio (insPrecarica): di solito qui c'e' sempre. */
  body.innerHTML = vecchio || '<div class="ins-scheletro"><i class="g"></i><i class="b"></i><i></i><i></i><i></i></div>';
  if (vecchio) try{ insIconeRiempi(body); }catch(_){ }
  const job = INS.view === 'giorno' ? insRenderDay
            : INS.view === 'settimana' ? insRenderWeek
            : insRenderTrend;
  job(token).then(() => { if (token === INS.token){ insWarm(); if (fonteSnap === insFonteOra()) insSnapSalva(); } }).catch(e => {
    if (token !== INS.token) return;
    body.innerHTML = insNote('Non sono riuscito a leggere i dati: ' + insErr(e));
  });
}

/* la pagina salvata di una vista, per sorgente (0.9.353): si salva dopo il disegno e di nuovo quando le barre
   prendono i colori, cosi' la volta dopo la pagina si vede subito gia' colorata */
function insSnapChiave(){ const f = insFonteOra(); return 'fl_ins_cache_' + INS.view + (f === 'telefono' ? '' : '_' + f); }
function insSnapSalva(){
  try{
    const body = document.getElementById('insBody');
    if (!body || !body.innerHTML || body.innerHTML.indexOf('ins-load') >= 0 || body.querySelector('.ins-scheletro')) return;
    /* una pagina non ancora divisa nei suoi blocchi (report-blocchi.js) si mostrerebbe nell'ordine sbagliato */
    if (typeof rpbAvvolgi === 'function' && body.querySelector(':scope > .rp-mk')) return;
    localStorage.setItem(insSnapChiave(), insSnapshotLeggero(body.innerHTML));
  }catch(_){ }
}

/* After a view is on screen, the figures of the other two are read in the background, so the
   next tap finds them in the cache instead of waiting on the usage stream. One pass, and only
   the queries the views open with. */
let INS_WARMED = 0;
function insWarm(){
  if (!NATIVE || !NATIVE.getScreenTimeRange || Date.now() - INS_WARMED < INS_TTL) return;
  INS_WARMED = Date.now();
  const now = Date.now();
  const d0 = insDayStart(now), ws = insWeekStart(now), we = Math.min(now, insAddDays(ws, 7));
  const jobs = [];
  if (INS.view !== 'giorno') jobs.push(
    () => insGet('day:' + d0 + ':h', () => NATIVE.getScreenTimeRange({ from: d0, to: Math.min(now, insAddDays(d0, 1)), bucket: 'hour' })),
    () => insGet('day:' + d0 + ':t', () => NATIVE.getTopApps({ from: d0, to: Math.min(now, insAddDays(d0, 1)), limit: 50, icons: 12 })));
  if (INS.view !== 'settimana') jobs.push(
    () => insGet('w:' + ws, () => NATIVE.getScreenTimeRange({ from: ws, to: we, bucket: 'day' })),
    () => insGet('wt:' + ws, () => NATIVE.getTopApps({ from: ws, to: we, limit: 50, icons: 12 })),
    () => insGet('wh:' + ws, () => NATIVE.getScreenTimeRange({ from: ws, to: we, bucket: 'hour' })));
  if (INS.view !== 'tendenza') jobs.push(
    () => insGet('trend:' + insDayKey(insAddDays(d0, -59)), () => NATIVE.getScreenTimeRange({ from: insAddDays(d0, -59), to: now, bucket: 'day' })));
  (async () => { for (const j of jobs){ try{ await j(); }catch(_){ } } })();
}

/* Category split of a list of getTopApps entries. `totalMs` is the period total measured by the
   engine: apps under a minute are dropped by getTopApps, so whatever is left over is real time
   that simply has no app attached — it is shown as such, never redistributed. */
function insSplit(apps, totalMs, ts){
  /* con l'ora (le colonne del grafico di un giorno) valgono le fasce; senza, la categoria di sempre */
  const cats = insCats(ts === undefined ? null : ts), ex = insExcl();
  const acc = { distr:0, neutro:0, prod:0, none:0 };
  let listed = 0, excluded = 0;
  (apps || []).forEach(a => {
    if (ex.indexOf(a.packageName) >= 0){ excluded += a.ms; return; }
    /* 0.9.353: un programma del computer senza categoria sul telefono prende quella scelta sul computer */
    acc[insCatRiga(a, cats) || 'none'] += a.ms;
    listed += a.ms;
  });
  const eff = Math.max(0, (totalMs || 0) - excluded);
  acc.none += Math.max(0, eff - listed);
  acc.total = acc.distr + acc.neutro + acc.prod + acc.none;
  return acc;
}
function insFilterApps(apps){
  if (INS.filter === 'all') return apps;
  const cats = insCats();
  return apps.filter(a => cats[a.packageName] === INS.filter);
}

/* ---------------------------------------------------------------------------------------
   LA SELEZIONE: la linguetta di categoria (FL_CATS, report.js) e il filtro dei tre puntini
   (distraente / neutro / produttivo). Due domande diverse — «in che cosa» e «con che
   giudizio» — che possono valere insieme. Tutto quello che mostra un numero le chiede qui,
   cosi' il numero grande, il grafico e l'elenco raccontano la stessa fetta di giornata.
   --------------------------------------------------------------------------------------- */
function insSelAttiva(){ return !!INS.catFiltro || INS.filter !== 'all'; }
function insInSel(pkg){
  if (INS.catFiltro && typeof rpCatDi === 'function' && (rpCatDi(pkg) || 'altro') !== INS.catFiltro) return false;
  if (INS.filter !== 'all' && insCats()[pkg] !== INS.filter) return false;
  return true;
}
function insSelNome(){
  const parti = [];
  if (INS.catFiltro){
    const c = (typeof rpCatInfo === 'function') ? rpCatInfo(INS.catFiltro) : null;
    parti.push(c ? c.name : INS.catFiltro);
  }
  if (INS.filter !== 'all') parti.push(INS_CAT[INS.filter].label);
  return parti.join(' \u00b7 ');
}
/** Le app che contano davvero: non FocusLock, non le escluse. */
function insAppsVive(apps){
  const ex = insExcl();
  return (apps || []).filter(a => a && !a.self && ex.indexOf(a.packageName) < 0);
}
function insSelMs(apps){
  return insAppsVive(apps).filter(a => insInSel(a.packageName)).reduce((t, a) => t + (a.ms || 0), 0);
}
/** Una colonna con la fetta scelta in evidenza e il resto della barra spento. */
function insColumnSel(total, sel, max, extraClass){
  const resto = Math.max(0, total - sel);
  let parti = '';
  if (resto > 0) parti += '<i class="dim" style="height:' + (resto / max * 100).toFixed(2) + '%"></i>';
  if (sel > 0) parti += '<i class="hi" style="height:' + (sel / max * 100).toFixed(2) + '%"></i>';
  return '<div class="col' + (extraClass ? ' ' + extraClass : '') + '">' + parti + '</div>';
}

/* ---------------------------------------------------------------------------------------
   LE BARRE A COLORI, SUBITO E SENZA GRIGIO (0.9.353)

   Andrea: "cambiando filtro (telefono, computer, tutti) i numeri e le barre ci mettono troppo ad aggiornarsi e a
   dividersi per colore". LE CAUSE VERE, nel grafico:
   1. per dividere le colonne si faceva UNA DOMANDA AL MOTORE PER OGNI ORA (24 getTopApps una dopo l'altra), e il
      motore del telefono ne serve una alla volta; col computer ognuna rifaceva anche la ricerca delle icone;
   2. i colori aspettavano sempre 1,3 secondi dopo il disegno (insAspettaSalita), anche quando le barre non salivano;
   3. la divisione stava in una cache svuotata a ogni cambio di sorgente, e la sua chiave non diceva la sorgente.
   Adesso si legge la cronologia della giornata UNA volta (i granelli: gli stessi di motore-web.js, della Timeline)
   e si divide ora per ora qui; la divisione resta in memoria per sorgente e giorno, e il disegno successivo parte gia'
   colorato. E le ore senza app (il computer manda i minuti di ogni ora senza dire di cosa) restano blu.
   --------------------------------------------------------------------------------------- */
function insFonteOra(){ try{ return (typeof mwFonte === 'function') ? mwFonte() : 'telefono'; }catch(_){ return 'telefono'; } }
function insQui(){ try{ return (typeof mwQui === 'function') ? mwQui() : 'telefono'; }catch(_){ return 'telefono'; } }
function insNomeBase(n){ return String(n || '').toLowerCase().replace(/\.exe$/, '').replace(/[^a-z0-9]+/g, ''); }
/* le categorie scelte sul computer: arrivano con i suoi totali di ogni giorno (pcdati.js, top[].c) */
let INS_PC_CAT = { at: 0, m: {} };
function insCatPc(nome){
  const b = insNomeBase(nome); if (!b) return null;
  if (Date.now() - INS_PC_CAT.at > 60000){
    const m = {};
    try{
      const g = (typeof PC !== 'undefined' && PC && PC.doc && PC.doc.giorni) || {};
      Object.keys(g).sort().forEach(function(k){
        ((g[k] && g[k].top) || []).forEach(function(t){
          const x = insNomeBase(t && t.k); if (!x) return;
          const c = /^prod/i.test(t.c) ? 'prod' : /^distr/i.test(t.c) ? 'distr' : /^neut/i.test(t.c) ? 'neutro' : '';
          if (c) m[x] = c;
        });
      });
    }catch(_){ }
    INS_PC_CAT = { at: Date.now(), m: m };
  }
  return INS_PC_CAT.m[b] || null;
}
/** La categoria di una riga: quella scelta sul telefono, poi quella che porta con se' (i totali del computer), poi quella del computer. */
function insCatRiga(a, cats){
  if (!a) return null;
  const c = (cats || {})[a.packageName];
  if (INS_CAT[c]) return c;
  if (a.cat && INS_CAT[a.cat]) return a.cat;
  if ((a.fonte || a.dev) === 'computer') return insCatPc(a.label) || insCatPc(a.packageName);
  return null;
}
/** I granelli di un dispositivo per un giorno. Null se qui non si possono leggere. */
async function insGraniDev(dev, dayStart, dayEnd){
  try{
    if (dayStart === insDayStart(Date.now())){
      const fn = dev === 'computer' ? (typeof mwGraniComputer === 'function' ? mwGraniComputer : null)
                                    : (typeof mwGraniTelefono === 'function' ? mwGraniTelefono : null);
      if (fn){ const g = await fn(dayStart); return (g || []).map(function(x){ return { p: x.p, l: x.l || x.p, s: x.s, ms: x.ms || 0, fonte: dev }; }); }
    }
    /* l'altro dispositivo pubblica i granelli solo della giornata di oggi */
    if (dev !== insQui()) return [];
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTimeline) return null;
    const d = await insGet('grani:' + dev + ':' + dayStart + ':' + Math.floor(dayEnd / 60000), function(){ return NATIVE.getTimeline({ from: dayStart, to: dayEnd, minMs: 0, limit: 30000 }); });
    if (!d || !d.granted) return null;
    return (d.grani || []).map(function(x){ return { p: x.p, l: x.l || x.p, s: x.s, ms: x.ms || 0, fonte: dev }; });
  }catch(_){ return null; }
}
/** I granelli della sorgente scelta: telefono, computer, o tutti e due. */
async function insGraniGiorno(dayStart, dayEnd){
  const f = insFonteOra();
  const devs = f === 'insieme' ? ['telefono', 'computer'] : [f === 'computer' ? 'computer' : 'telefono'];
  let out = [], letto = false;
  for (let i = 0; i < devs.length; i++){
    const g = await insGraniDev(devs[i], dayStart, dayEnd);
    if (g){ letto = true; out = out.concat(g); }
  }
  return letto ? out : null;
}
/** Da granelli a { ora: [righe come getTopApps] }: i minuti di ogni app tagliati sul bordo di ogni ora. */
function insGraniPerOra(grani, dayStart){
  const acc = {};
  (grani || []).forEach(function(g){
    let s = Math.max(g.s, dayStart);
    const e = g.s + (g.ms || 0);
    let giri = 0;
    while (s < e && giri++ < 30){
      if (insDayStart(s) !== dayStart) break;
      const d = new Date(s); const h = d.getHours(); d.setHours(h + 1, 0, 0, 0);
      const fine = Math.min(e, d.getTime());
      const k = (g.fonte || '') + '|' + g.p;
      const o = acc[h] || (acc[h] = {});
      const r = o[k] || (o[k] = { packageName: g.p, label: g.l || g.p, ms: 0, fonte: g.fonte || '' });
      r.ms += fine - s;
      s = fine;
    }
  });
  const per = {};
  Object.keys(acc).forEach(function(h){ per[h] = Object.keys(acc[h]).map(function(k){ return acc[h][k]; }); });
  return per;
}
/** I pezzi colorati di una colonna. Null se dentro non c'e' nessuna app: allora la colonna resta blu, mai grigia. */
function insSegs(lista, totMs, ts){
  if (!lista || !lista.length) return null;
  const cats = insCats(ts === undefined ? null : ts), ex = insExcl();
  const acc = { distr: 0, neutro: 0, prod: 0, none: 0, resto: 0 };
  let listed = 0, excluded = 0;
  lista.forEach(function(a){
    const ms = Math.max(0, +a.ms || 0);
    if (ex.indexOf(a.packageName) >= 0){ excluded += ms; return; }
    acc[insCatRiga(a, cats) || 'none'] += ms;
    listed += ms;
  });
  const eff = Math.max(0, (totMs || 0) - excluded);
  if (!listed){ if (!excluded) return null; acc.resto = eff; return acc; }
  /* la cronologia di un minuto fa contro il totale di adesso: le differenze piccole si spalmano, quelle grandi
     (le ore del computer senza granelli) restano blu */
  if (listed > eff || eff - listed < 90000){ const k = eff / listed; ['distr', 'neutro', 'prod', 'none'].forEach(function(x){ acc[x] *= k; }); }
  else acc.resto = eff - listed;
  return acc;
}
/* la divisione di ogni ora, per sorgente e giorno: non si butta cambiando sorgente, cosi' tornare indietro e' immediato */
const INS_ORE_MEM = new Map();
function insOreChiave(dayStart){ return insFonteOra() + '|' + dayStart; }
function insOreRicordo(dayStart, maxMs){ const m = INS_ORE_MEM.get(insOreChiave(dayStart)); return m && Date.now() - m.t < (maxMs || INS_TTL) ? m.per : null; }
/** Le app di ogni ora di un giorno: una lettura della cronologia; senza cronologia, una domanda per ora come prima. */
async function insPerOraLeggi(token, dayStart, hours){
  const dayEnd = Math.min(Date.now(), insAddDays(dayStart, 1));
  const g = await insGraniGiorno(dayStart, dayEnd);
  if (g) return insGraniPerOra(g, dayStart);
  const per = {};
  for (let h = 0; h < 24; h++){
    if (token != null && token !== INS.token) return null;
    if (!(hours && hours[h] > 0)) continue;
    const s = new Date(dayStart); s.setHours(h, 0, 0, 0);
    const e = new Date(dayStart); e.setHours(h + 1, 0, 0, 0);
    const to = Math.min(e.getTime(), Date.now());
    if (to <= s.getTime()) continue;
    try{ per[h] = (await NATIVE.getTopApps({ from: s.getTime(), to: to, limit: 30, icons: 0 })).apps || []; }
    catch(err){ per[h] = []; }
  }
  return per;
}
/** Le 24 colonne di un giorno con la divisione `per` (o senza, se manca). */
function insColsGiorno(hours, max, per, dayStart, oraOn){
  const sel = insSelAttiva();
  let cols = '';
  for (let h = 0; h < 24; h++){
    const cls = h === oraOn ? 'on' : '';
    const lista = per ? per[h] : null;
    if (sel) cols += insColumnSel(hours[h], lista ? Math.min(hours[h], insSelMs(lista)) : 0, max, cls);
    else cols += insColumn(hours[h], max, lista ? insSegs(lista, hours[h], new Date(dayStart).setHours(h, 30, 0, 0)) : null, cls);
  }
  return cols;
}

/* ---------------------------------------------------------------------------------------
   CHARTS
   --------------------------------------------------------------------------------------- */

/* A "nice" ceiling so the Y axis reads 1h / 30m / 0s like AppBlock's does. */
function insCeil(ms){
  const H = 3600000;
  if (ms <= H) return H;
  return Math.ceil(ms / (H / 2)) * (H / 2);
}
/* One column: either a plain bar, or a stack of category segments when the per-slot app
   breakdown has been loaded. */
function insColumn(ms, max, segs, extraClass){
  const parts = [];
  if (segs){
    /* 0.9.353: il tempo senza il nome di un'app (le ore del computer arrivano cosi') resta nel blu della barra, in cima */
    if (segs.resto > 0) parts.push('<i style="height:' + (segs.resto / max * 100).toFixed(2) + '%"></i>');
    ['distr','neutro','prod','none'].forEach(k => {
      const v = segs[k] || 0;
      if (v <= 0) return;
      const col = k === 'none' ? INS_NONE.color : INS_CAT[k].color;
      parts.push('<i style="height:' + (v / max * 100).toFixed(2) + '%;background:' + col + '"></i>');
    });
  }
  if (!parts.length && ms > 0) parts.push('<i style="height:' + (ms / max * 100).toFixed(2) + '%"></i>');
  return '<div class="col' + (extraClass ? ' ' + extraClass : '') + '">' + parts.join('') + '</div>';
}
function insHourAxis(){
  let x = '';
  for (let h = 0; h < 24; h++) x += '<span>' + (h % 6 === 0 ? h : '') + '</span>';
  return '<div class="ins-x">' + x + '</div>';
}
/* The Y axis reads "1h", not "1h 00m": on an axis the minutes are noise. */
function insFmtAxis(ms){ return ms >= 3600000 && ms % 3600000 === 0 ? (ms / 3600000) + 'h' : insFmt(ms); }
function insPlot(inner, max, axis, fmt){
  const f = fmt || insFmtAxis;
  return '<div class="ins-plot">'
       + '<div class="ins-y"><span>' + f(max) + '</span><span>' + f(max/2) + '</span><span>' + (fmt ? '0' : '0s') + '</span></div>'
       + '<div class="ins-plotbody">' + inner + axis + '</div></div>';
}

/* ---------------------------------------------------------------------------------------
   VIEW · GIORNO
   --------------------------------------------------------------------------------------- */

async function insRenderDay(token){
  const body = document.getElementById('insBody');
  const dayStart = insAddDays(insDayStart(Date.now()), -INS.dayOff);
  const now = Date.now();
  const dayEnd = Math.min(now, insAddDays(dayStart, 1));
  if (dayEnd <= dayStart){ body.innerHTML = insNote('Giornata non ancora iniziata.'); return; }

  const rangeKey = 'day:' + dayStart;
  const range = await insGet(rangeKey + ':h', () => NATIVE.getScreenTimeRange({ from: dayStart, to: dayEnd, bucket: 'hour' }));
  const top   = await insGet(rangeKey + ':t', () => NATIVE.getTopApps({ from: dayStart, to: dayEnd, limit: 50, icons: 12 }));
  if (token !== INS.token) return;

  // Hour-of-day buckets, indexed by the local hour of their own start so a DST day cannot
  // shift every bar after 03:00.
  const hours = new Array(24).fill(0);
  (range.buckets || []).forEach(b => { hours[new Date(b.start).getHours()] += b.ms; });
  /* la guardia (0.9.306): un'ora non contiene piu' di un'ora, un giorno non piu' di quanto ne e' passato */
  for (let h = 0; h < 24; h++) hours[h] = Math.min(hours[h], 3600000);
  if (range.ms > dayEnd - dayStart) range.ms = dayEnd - dayStart;
  const max = insCeil(Math.max.apply(null, hours.concat([0])));

  /* L'ORA SCELTA (0.9.299). Andrea: "quando si clicca su una barra deve mostrare il tempo sullo schermo di quella
     fascia, 'dalle 13 alle 14', e sotto le app piu' usate solo in quell'ora, come AppBlock; le altre barre sbiadite". */
  const oraSel = (INS.oraSel != null && INS.oraSelDay === dayStart) ? INS.oraSel : null;
  let topV = top, baseMs = range.ms;
  if (oraSel != null){
    const s0 = new Date(dayStart); s0.setHours(oraSel, 0, 0, 0);
    const e0 = new Date(dayStart); e0.setHours(oraSel + 1, 0, 0, 0);
    const to0 = Math.min(e0.getTime(), Date.now());
    if (to0 > s0.getTime()){
      try{ topV = await insGet('ora:' + s0.getTime() + ':' + Math.floor(to0 / 60000), () => NATIVE.getTopApps({ from: s0.getTime(), to: to0, limit: 50, icons: 12 })); }catch(_){ topV = { apps: [] }; }
      if (token !== INS.token) return;
    } else topV = { apps: [] };
    baseMs = hours[oraSel];
  }
  INS.selfApp = (topV.apps || []).filter(function(a){ return a && a.self; })[0] || null;
  const vive = insAppsVive(topV.apps || []);
  try{ if (typeof jdImparaNomi === 'function') jdImparaNomi(top.apps || []); }catch(_){ }
  const selOn = insSelAttiva();
  /* IL NUMERO GRANDE SEGUE LA SCELTA. Con una linguetta o un filtro acceso il numero e' il
     tempo di QUELLA fetta, e l'etichetta dice quale: «TEMPO SULLO SCHERMO • GIOCHI». Un
     totale immobile sopra a un grafico che cambia sarebbe due risposte a due domande. */
  const bigMs = selOn ? insSelMs(topV.apps || []) : baseMs;

  let html = '';
  /* 0.9.306: la frase vera (prima diceva che il telefono "non espone lo storico", e lo espone per una decina di giorni) */
  if (range.approx) html += '<div class="ins-approx">' + (range.dettaglioPerso
    ? 'Di questo giorno il telefono conserva solo un riepilogo: il totale è una stima e le ore non si vedono più.'
    : 'Di questo giorno il telefono conserva solo un riepilogo: il totale e le ore sono una stima.') + '</div>';

  /* I TRE PUNTINI DELLA SORGENTE stanno QUI: sopra al grafico, a destra, sotto all'ora.
     Compaiono solo con due dispositivi collegati allo stesso account. */
  const conFonte = (typeof mwDueDispositivi === 'function') && mwDueDispositivi();
  html += '<div class="ins-testa">'
    + '<div class="ins-big">' + insFmt(bigMs) + '</div>'
    + '<div class="ins-lbl">Tempo sullo schermo' + (oraSel != null ? ' \u2022 ' + insPad(oraSel) + ':00 - ' + insPad((oraSel + 1) % 24) + ':00' : '') + (selOn ? ' \u2022 ' + esc(insSelNome()) : '')
    +   ((typeof mwEtichetta === 'function' && conFonte) ? ' \u2022 ' + esc(mwEtichetta()) : '') + '</div>'
    + (conFonte ? '<button type="button" class="pb-dots ins-fonte" onclick="insFonteMenu(event)" aria-label="Da quale dispositivo">\u22ef</button>' : '')
    + '</div>';

  // Chart
  /* 0.9.353: se la divisione di queste ore e' gia' in memoria (stessa sorgente, ultimi 15 minuti) le barre nascono
     gia' colorate: niente piu' blu che diventa colorato secondi dopo, a ogni cambio di filtro */
  const colora = insHasCats() || selOn;
  const perSubito = colora ? insOreRicordo(dayStart, 15 * 60000) : null;
  let cols = '';
  if (perSubito) cols = insColsGiorno(hours, max, perSubito, dayStart, oraSel == null ? -1 : oraSel);
  else for (let h = 0; h < 24; h++) cols += insColumn(hours[h], max, null, h === oraSel ? 'on' : '');
  html += insPlot('<div class="chart ins-hours' + (oraSel != null ? ' ins-sel' : '') + insSale('g:' + dayStart) + '" id="insDayChart">' + cols + '</div>', max, insHourAxis());

  /* LE LINGUETTE, come su AppBlock: la prima e' il totale, poi una per categoria. Niente
     «Tutto» e niente pillole con i nomi delle app: quelle stanno gia' nell'elenco sotto. */
  const perTab = INS.filter === 'all' ? vive : vive.filter(a => insCats()[a.packageName] === INS.filter);
  if (insStatApps() && typeof rpCatChips === 'function'){
    html += rpCatChips(perTab, INS.filter === 'all' ? baseMs : perTab.reduce((t, a) => t + (a.ms || 0), 0));
  }

  html += insPromo();

  /* SUBITO SOTTO ALLE LINGUETTE, nell'ordine del modello: prima le app, poi le distrazioni
     evitate, poi le abitudini. La Timeline e l'umore vanno in fondo. */
  const apps = vive.filter(a => insInSel(a.packageName));
  html += '<i class="rp-mk" data-k="rpApp" hidden></i>';
  if (insStatApps()){
    html += '<div class="sect"><b>App pi\u00f9 usate' + (oraSel != null ? ' \u00b7 ' + insPad(oraSel) + ':00 - ' + insPad((oraSel + 1) % 24) + ':00' : '') + '</b></div>';
    html += insAppRows(apps, baseMs);
  }

  html += '<i class="rp-mk" data-k="rpEvitate" hidden></i>';
  html += await insAvoidedCard(dayStart, 1, INS.dayOff === 0 ? 'oggi' : insDateLabel(dayStart));
  if (token !== INS.token) return;

  html += '<i class="rp-mk" data-k="rpAbitudini" hidden></i>';
  html += '<div class="sect"><b>Abitudini</b></div>';
  html += await insBalanceCard([hours], range.ms, [dayStart]);
  if (token !== INS.token) return;
  html += insPeakCard(hours);

  html += insFocusCard([hours]);
  html += insCategorieCard(dayStart, dayStart + 86400000, 'Oggi');
  html += await insDistractionCard(dayStart, 1);
  if (token !== INS.token) return;

  html += '<i class="rp-mk" data-k="rpUtilizzo" hidden></i>';
  html += insUsageCard(top.apps || [], range.ms);

  /* PRIMA QUI C'ERANO «Il tuo computer» (o «Il tuo telefono») e il registro dei punti.
     Il primo era un secondo Report in piccolo dell'altro dispositivo: adesso quei numeri
     passano dai tre puntini sopra al grafico (telefono, computer, tutti e due), e un
     cassetto in fondo che li ripete e' la stessa cosa detta due volte. Il registro dei
     punti e' della partita, e sta nella sua pagina (partita.js). Resta la Timeline, poi
     - ultimo - il controllo dell'umore: un'opinione si chiede DOPO aver visto i fatti. */
  html += '<i class="rp-mk" data-k="rpTimeline" hidden></i>';
  if (typeof tlCardEntrata === 'function') html += tlCardEntrata(INS.dayOff || 0);
  html += '<i class="rp-mk" data-k="rpUmore" hidden></i>';
  if (typeof umCard === 'function' && !(typeof rpUmoreOff === 'function' && rpUmoreOff())){
    const kg = new Date(dayStart);
    const key = kg.getFullYear() + '-' + String(kg.getMonth() + 1).padStart(2, '0')
      + '-' + String(kg.getDate()).padStart(2, '0');
    setTimeout(insIconeMancanti, 250);
    /* 0.9.353, Andrea: "il pannello Informazioni sull'umore va SOTTO il titolo Controllo dell'umore, non sopra".
       Prima il pannello stava davanti a tutto il blocco e il titolo arrivava dopo; adesso titolo, pannello, umore */
    const uc = umCard(key, INS.dayOff === 0);
    const info = (typeof umInfoPannelloHtml === 'function') ? umInfoPannelloHtml() : '';
    const testa = /^<div class="um-testa">[\s\S]*?<\/div>/.exec(uc);
    html += testa ? testa[0] + info + uc.slice(testa[0].length) : info + uc;
  }

  html += '<i class="rp-mk" data-k="fine" hidden></i>';
  html += '<textarea id="insShareText" hidden>' + esc(
    'DreamMap \u00b7 ' + (INS.dayOff === 0 ? 'oggi' : insDateLabel(dayStart)) + ': ' + insFmt(range.ms) + ' di schermo'
  ) + '</textarea>';

  body.innerHTML = html;
  insDopoDisegno(body);
  INS.disegnoAt = Date.now();
  /* 0.9.353: i colori aspettano la fine della salita solo se le barre stanno salendo davvero */
  if (body.querySelector('#insDayChart.ins-sale')) INS.saleAt = INS.disegnoAt;
  INS.oreGiorno = hours;
  /* i totali dell'altro dispositivo si leggono ancora: dicono ai tre puntini che esiste */
  if (typeof pcAltroSync === 'function') try{ pcAltroSync(false).then(function(d){
    if (d && d.giorni && typeof mwSegnaAltro === 'function') mwSegnaAltro([1]);
  }).catch(function(){ }); }catch(_){ }

  // Segments are a second pass on purpose: the bars above are already true. Nothing to colour
  // until the user has sorted at least one app or chosen a category, so new installs never pay for it.
  if (colora) insColourDay(token, dayStart, hours, max);
}

/* ---------------------------------------------------------------------------------------
   IL REGISTRO DEI PUNTI: la partita e l'arbitro, con l'ora e il motivo
   --------------------------------------------------------------------------------------- */
const INS_PUNTI_KEY = 'fl_ins_punti_aperto';
function insPuntiAperto(){ try{ return localStorage.getItem(INS_PUNTI_KEY) !== '0'; }catch(_){ return true; } }
function insPuntiToggle(){
  try{ localStorage.setItem(INS_PUNTI_KEY, insPuntiAperto() ? '0' : '1'); }catch(_){ }
  INS.forceRender = true; insRender();
}
function insPuntiOra(t){ const d = new Date(t || 0); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function insPuntiGiorno(k){
  const d = new Date(k + 'T12:00:00');
  if (isNaN(d)) return k;
  return d.getDate() + ' ' + INS_MONTHS[d.getMonth()].slice(0, 3);
}

/* Gli eventi della partita degli ultimi 14 giorni, dal piu' recente. */
function insPuntiEventi(){
  const out = [];
  try{
    const hist = (typeof mgHist === 'function') ? mgHist() : [];
    hist.slice(-14).forEach(function(g){
      (g.eventi || []).forEach(function(e){ out.push({ day: g.day, chi: e.chi, motivo: e.motivo || '', at: e.at || 0, punti: e.punti || 1 }); });
    });
  }catch(_){ }
  out.sort(function(a, b){ return (b.at || 0) - (a.at || 0); });
  return out;
}

/**
 * Nel Report resta una riga sola che porta al registro.
 *
 * <p>PERCHE' NON E' PIU' UN CASSETTO. Il cartello di fine sessione dice «vedi il registro»,
 * e portava qui dentro: si apriva il Report, si apriva il cassetto, e chi guardava vedeva
 * comparire una pagina piena di grafici con il registro da qualche parte piu' in basso. Un
 * cartello che promette un posto deve portare in quel posto.</p>
 */
async function insPuntiCard(dayStart){
  const n = insPuntiEventi().length;
  return '<div class="ins-card pz-link" onclick="insApriRegistro()">'
    + '<div><b>\ud83d\udcdd Il registro dei punti</b>'
    + '<small>' + n + (n === 1 ? ' punto' : ' punti') + ' \u00b7 ultimi 14 giorni</small></div>'
    + '<span class="pz-chev">\u203a</span></div>';
}

/* Il corpo del registro: la partita (le scelte) e l'arbitro (i blocchi del motore). */
async function insPuntiCorpo(){
  const eventi = insPuntiEventi();
  let giorni = [];
  try{
    const ins = NATIVE && NATIVE.getInsights ? await insGet('insights', () => NATIVE.getInsights({ days: 30 })) : null;
    const ceduti = (typeof itLog === 'function') ? itLog() : {};
    const righe = ((ins && ins.history) || []).slice(-14).reverse();
    righe.forEach(function(r){
      const ced = Object.keys(ceduti[r.day] || {}).reduce(function(t, k){ return t + (+ceduti[r.day][k] || 0); }, 0);
      const ten = +r.blocks || 0;
      if (!ten && !ced) return;
      giorni.push({ day: r.day, tenuto: ten, ceduto: ced, apps: r.apps || [] });
    });
  }catch(_){ giorni = []; }

  /* 0.9.322, Andrea: "fa cagare". Prima una riga in fila all'altra, tutte uguali. Adesso: il tabellone in alto (le stesse facce della
     bolla sopra alle app), una cosa alla volta (partita o arbitro), i giorni come capitoli, e a destra il punto che salta all'occhio. */
  const s = (typeof mtState === 'function') ? mtState() : { old: 0, neo: 0 };
  const perGiorno = function(l, chiave){ const o = []; l.forEach(function(x){ const k = chiave(x); let g = o.filter(function(v){ return v.k === k; })[0]; if (!g){ g = { k: k, l: [] }; o.push(g); } g.l.push(x); }); return o; };
  const riga = function(e){
    const tipo = e.chi === 'old' ? 'old' : ((e.chi === 'revoca' || e.chi === 'annullo') ? 'revoca' : 'neo');
    const m = String(e.motivo || 'Senza motivo registrato').replace(/\s*\(×\d+[^)]*\)\s*$/, ''), c = m.indexOf(': ');
    const tit = c > 0 ? m.slice(0, c) : m, det = c > 0 ? m.slice(c + 2) : '';
    const n = +e.punti || 1;
    const sotto = (e.chi === 'revoca' ? 'Punto tolto al nuovo te' : e.chi === 'annullo' ? 'Punto tolto al vecchio te' : '') || det;
    return '<div class="pz-r ' + tipo + '"><span class="pz-fac" aria-hidden="true">' + (tipo === 'old' ? '😈' : tipo === 'neo' ? '🚀' : '↩️') + '</span>'
      + '<div class="pz-t"><b>' + esc(tit.charAt(0).toUpperCase() + tit.slice(1)) + '</b>' + (sotto ? '<small>' + esc(sotto) + '</small>' : '') + '</div>'
      + '<div class="pz-d"><em>' + (tipo === 'revoca' ? '−' : '+') + n + '</em><small>' + insPuntiOra(e.at) + '</small></div></div>';
  };
  const partita = eventi.length
    ? perGiorno(eventi.slice(0, 60), function(e){ return e.day; }).map(function(g){ return '<h3 class="pz-g">' + insPuntiGiorno(g.k) + '</h3><div class="pz-l">' + g.l.map(riga).join('') + '</div>'; }).join('')
    : '<div class="pz-vuoto"><span aria-hidden="true">⚽</span><b>Ancora nessun punto</b><p>Il primo arriva con la prossima scelta.</p></div>';
  const arbitro = giorni.length
    ? '<div class="pz-l">' + giorni.slice(0, 14).map(function(g){
        return '<div class="pz-r blk"><span class="pz-fac" aria-hidden="true">🛡️</span><div class="pz-t"><b>' + g.tenuto + (g.tenuto === 1 ? ' distrazione fermata' : ' distrazioni fermate') + '</b>'
          + '<small class="pz-th">' + g.apps.slice(0, 5).map(function(p){ return '<img class="ub-appico" data-pkg="' + esc(p) + '" alt="">'; }).join('') + '</small></div>'
          + '<div class="pz-d">' + (g.ceduto ? '<em class="ced">' + g.ceduto + (g.ceduto === 1 ? ' ceduta' : ' cedute') + '</em>' : '') + '<small>' + insPuntiGiorno(g.day) + '</small></div></div>';
      }).join('') + '</div>'
    : '<div class="pz-vuoto"><span aria-hidden="true">🛡️</span><b>Ancora nessun blocco</b><p>Quando una regola ti ferma, lo trovi qui giorno per giorno.</p></div>';
  return '<div class="pz-hero"><button type="button" class="pz-i" onclick="insPuntiInfo()" aria-label="Cosa c’è in questa pagina">i</button>'
    + '<div class="pz-sq"><span aria-hidden="true">😈</span><b class="o">' + (s.old || 0) + '</b><small>Il vecchio te</small></div><i>-</i><div class="pz-sq"><span aria-hidden="true">🚀</span><b class="n">' + (s.neo || 0) + '</b><small>Il nuovo te</small></div></div>'
    + '<div class="pz-tabs" role="tablist"><button type="button" class="on" onclick="insPuntiScheda(this,0)">La partita</button><button type="button" onclick="insPuntiScheda(this,1)">L’arbitro</button></div>'
    + '<div class="pz-pag">' + partita + '</div><div class="pz-pag" hidden>' + arbitro + '</div>';
}
function insPuntiScheda(b, i){
  const box = document.getElementById('pzBody'); if (!box) return;
  box.querySelectorAll('.pz-tabs button').forEach(function(x, k){ x.classList.toggle('on', k === i); });
  box.querySelectorAll('.pz-pag').forEach(function(x, k){ x.hidden = k !== i; });
  try{ flVibra(8); }catch(_){ }
}
function insPuntiInfo(){
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Il registro dei punti</h3>'
    + flInfoRighe([
        ['⚽', 'La partita', 'Ogni punto con il suo motivo: le regole della partita le scegli tu.'],
        ['🛡️', 'L’arbitro', 'I blocchi che ti hanno fermato, giorno per giorno. Sono una misura a parte.'],
        ['↩️', 'I punti tolti', 'Se una prova si rivela sbagliata, il punto torna indietro e lo vedi qui.']
      ]) + '</div>');
}

registerScreen('s-punti', '<div class="topbar"><button class="iconbtn" onclick="insPuntiIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button>'
  + '<b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Il registro dei punti</b></div>'
  + '<div class="pz-page" id="pzBody"><p class="pz-vuoto">Leggo la partita\u2026</p></div>'
  + '<div class="spacer"></div>', { back: function(){ return INS_PUNTI_DA || 's-home'; } });

let INS_PUNTI_DA = 's-home';
function insPuntiIndietro(){ goId(INS_PUNTI_DA || 's-home'); }

/** Il registro, nella sua pagina: ci arriva il cartello del gol e la riga del Report. */
async function insApriRegistro(da){
  INS_PUNTI_DA = da || 's-home';
  goId('s-punti');
  const b = document.getElementById('pzBody');
  if (!b) return;
  b.innerHTML = await insPuntiCorpo();
  if (typeof ubFillIcons === 'function') try{ ubFillIcons(b); }catch(_){ }
}

/* Dopo che il corpo e' a schermo: le icone delle miniature e i siti sotto ai browser. */
function insDopoDisegno(body){
  try{ insIconeRiempi(body); }catch(_){ }
  if (typeof ubFillIcons === 'function') try{ ubFillIcons(body); }catch(_){ }
  insSitiAuto(body);
  try{ insSocAuto(body); }catch(_){ }
  /* l'ordine di salita delle barre, da sinistra */
  body.querySelectorAll('.ins-hours, .ins-week').forEach(function(ch){
    Array.prototype.forEach.call(ch.children, function(c, i){ c.style.setProperty('--i', i); });
  });
  const ch = body.querySelector('#insDayChart');
  if (ch && !ch.dataset.tap){
    ch.dataset.tap = '1';
    ch.addEventListener('click', function(ev){
      const r = ch.getBoundingClientRect(); if (!r.width) return;
      insOraTap(Math.max(0, Math.min(23, Math.floor((ev.clientX - r.left) / r.width * 24))));
    });
  }
}
/* LE BARRE SALGONO DAL BASSO (0.9.299), come nel grafico dell'umore: una volta ogni volta che la pagina si apre,
   non a ogni ridisegno (la seconda passata dei colori, il tocco su un'ora) */
const INS_SALITE = {};
function insSale(k){
  if (INS_SALITE[INS.view + k]) return '';
  INS_SALITE[INS.view + k] = 1;
  return ' ins-sale';
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') Object.keys(INS_SALITE).forEach(function(k){ delete INS_SALITE[k]; }); });
/* 0.9.353: prima contava dall'ultimo disegno qualsiasi (INS.disegnoAt), e ogni cambio di filtro aspettava 1,3 secondi
   prima di dividere le barre per colore anche senza nessuna salita in corso. Adesso conta solo una salita vera */
function insAspettaSalita(){
  const resta = 24 * 22 + 750 - (Date.now() - (INS.saleAt || 0));
  return resta > 0 ? new Promise(function(ok){ setTimeout(ok, resta); }) : Promise.resolve();
}
/* il tocco su una barra: quell'ora in evidenza, le altre sbiadite; lo stesso tocco la toglie */
function insOraTap(h){
  const dayStart = insAddDays(insDayStart(Date.now()), -INS.dayOff);
  const ore = INS.oreGiorno || [];
  if (INS.oraSel === h && INS.oraSelDay === dayStart){ INS.oraSel = null; }
  else {
    if (!(ore[h] > 0)) return;
    INS.oraSel = h; INS.oraSelDay = dayStart;
  }
  try{ if (typeof flVibra === 'function') flVibra([8]); }catch(_){ }
  INS.forceRender = true;
  insRender();
}

/* L'ORA SCELTA SI TOGLIE TOCCANDO FUORI (0.9.300). Andrea: "toccando in qualunque altro punto dello schermo il filtro
   si tolga e torni la vista completa". Il tocco sul grafico resta di insOraTap (un'altra barra la sceglie, la stessa la
   toglie); un tocco altrove dentro al Report toglie solo il filtro e non apre niente sotto (la pagina si ridisegna, e
   quello che stava sotto al dito cambia); un tocco fuori dal Report (la barra in basso) passa e il filtro si toglie. */
document.addEventListener('click', function(ev){
  if (INS.oraSel == null) return;
  const body = document.getElementById('insBody');
  if (!body || body.offsetParent === null) return;
  const t = ev.target;
  const ch = document.getElementById('insDayChart');
  if (ch && t && ch.contains(t)) return;
  INS.oraSel = null;
  INS.forceRender = true;
  if (t && body.contains(t)){ ev.preventDefault(); ev.stopPropagation(); }
  setTimeout(function(){ const b = document.getElementById('insBody'); if (b && b.offsetParent !== null) insRender(); }, 0);
}, true);

/* Per-hour app breakdown: one read of the day's timeline (0.9.353), split hour by hour here. */
async function insColourDay(token, dayStart, hours, max){
  const chiave = insOreChiave(dayStart);
  let per = insOreRicordo(dayStart);
  if (!per){
    per = await insPerOraLeggi(token, dayStart, hours);
    if (!per || token !== INS.token) return;
    INS_ORE_MEM.set(chiave, { t: Date.now(), per: per });
  }
  if (token !== INS.token || chiave !== insOreChiave(dayStart)) return;
  try{
    if (Object.keys(insFasce()).length){
      const acc = { distr: 0, neutro: 0, prod: 0, none: 0 };
      for (let h = 0; h < 24; h++){ if (!per[h]) continue; const x = insSplit(per[h], hours[h], new Date(dayStart).setHours(h, 30, 0, 0)); ['distr', 'neutro', 'prod', 'none'].forEach(function(k){ acc[k] += x[k]; }); }
      acc.total = acc.distr + acc.neutro + acc.prod + acc.none;
      const card = document.getElementById('insUsoCard'); if (card && acc.total) card.innerHTML = insUsageCardDa(acc);
    }
  }catch(_){ }
  await insAspettaSalita();
  if (token !== INS.token) return;
  const chart = document.getElementById('insDayChart');
  if (!chart) return;
  const oraOn = (INS.oraSel != null && INS.oraSelDay === dayStart) ? INS.oraSel : -1;
  /* CON UNA SCELTA ATTIVA il grafico evidenzia la fetta scelta ora per ora e spegne il resto:
     e' la risposta a «a che ora ho giocato?», che il grafico intero non sa dare. */
  const cols = insColsGiorno(hours, max, per, dayStart, oraOn);
  chart.classList.remove('ins-sale');
  if (chart.innerHTML !== cols) chart.innerHTML = cols;
  insSnapSalva();
}

/* ---------------------------------------------------------------------------------------
   VIEW · SETTIMANA
   --------------------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------------------
   I CONTI DELLA SETTIMANA (0.9.306), separati dal disegno perche' si possano provare
   (tools/test-report-settimana.js).

   Andrea, screenshot del 29/10: andando alla settimana prima, "5h 10m tempo medio" e
   "\u25bc 58%", ma le barre vuote; un'altra settimana "1d 3h" di media (piu' di un giorno al giorno),
   barre vuote, chip "7d 21h" e il cartello giallo.
   LE CAUSE VERE, tre:
   1. Le barre vuote: la settimana si leggeva con la chiave 'w:<lunedi'>' e la settimana PRIMA,
      per il confronto, con la stessa chiave ma senza barre (bucket 'none'). Aperta una
      settimana, la precedente finiva in cache sotto quel nome senza i giorni: spostandosi
      indietro arrivava dalla cache il totale giusto e zero barre. Adesso la settimana prima si
      legge come una settimana, con i giorni: stessa domanda, stessa chiave, e la freccia
      indietro la trova gia' pronta.
   2. La media sopra le 24 ore: per le settimane piu' vecchie di una decina di giorni Android non
      tiene piu' gli eventi, e il motore ripiegava sui riepiloghi di sistema contandoli INTERI
      (due settimane o un mese al posto di una settimana): corretto nel motore
      (FocusLockPlugin.fallbackAggregate). Qui resta la guardia: un giorno non contiene piu'
      tempo di quanto dura, e la settimana nemmeno.
   3. Il cartello giallo diceva che il telefono "non espone lo storico": falso, lo espone per una
      decina di giorni. Adesso dice la cosa vera, nei colori del brand.
   --------------------------------------------------------------------------------------- */
const INS_GIORNO_MS = 86400000;
/* i giorni che il telefono non conserva piu': quelli finiti prima del primo evento, se la settimana e' vecchia */
const INS_EVENTI_GIORNI = 8;
function insSettimanaConti(range, prev, ws, we, adesso){
  const r = range || {};
  const ora = adesso || Date.now();
  const giorno = function(i){
    const a = new Date(ws); a.setDate(a.getDate() + i);
    const b = new Date(ws); b.setDate(b.getDate() + i + 1);
    return [a.getTime(), b.getTime()];
  };
  const days = [0, 0, 0, 0, 0, 0, 0];
  (r.buckets || []).forEach(function(b){
    const d = new Date(b.start); d.setHours(0, 0, 0, 0);
    const idx = Math.round((d.getTime() - ws) / INS_GIORNO_MS);
    if (idx >= 0 && idx < 7) days[idx] += Math.max(0, +b.ms || 0);
  });
  /* la guardia: un giorno non contiene piu' tempo di quanto dura (oggi: di quanto ne e' passato) */
  let tagliato = false;
  for (let i = 0; i < 7; i++){
    const g = giorno(i), dur = Math.max(0, Math.min(we, g[1]) - g[0]);
    if (days[i] > dur){ days[i] = dur; tagliato = true; }
  }
  /* i giorni persi: finiti prima del primo evento che il telefono conserva (solo per settimane vecchie) */
  const persi = [false, false, false, false, false, false, false];
  if (!r.approx && r.eventiDa > ws && ws < ora - INS_EVENTI_GIORNI * INS_GIORNO_MS){
    for (let i = 0; i < 7; i++){ const g = giorno(i); if (g[1] <= r.eventiDa && days[i] === 0) persi[i] = true; }
  }
  const giorniTot = Math.max(1, Math.min(7, Math.ceil((we - ws) / INS_GIORNO_MS)));
  const nPersi = persi.slice(0, giorniTot).filter(Boolean).length;
  const elapsed = Math.max(1, giorniTot - nPersi);
  let tot = Math.max(0, +r.ms || 0);
  const periodo = Math.max(0, we - ws);
  if (tot > periodo){ tot = periodo; tagliato = true; }
  const somma = days.reduce(function(a, x){ return a + x; }, 0);
  if (somma > 0 && tot > somma && !r.approx){ tot = somma; }
  const media = Math.min(INS_GIORNO_MS, tot / elapsed);
  const barre = somma > 0 && !r.dettaglioPerso;
  /* il confronto solo fra due settimane misurate davvero: con un riepilogo di mezzo e' una stima contro una stima */
  let confronto = null;
  const p = prev || null;
  if (p && p.ms > 0 && !p.approx && !r.approx){
    const pc = insSettimanaConti(p, null, insAddDays(ws, -7), ws, ora);
    if (pc.media > 0) confronto = Math.round((media - pc.media) / pc.media * 100);
  }
  return { days: days, persi: persi, nPersi: nPersi, tot: tot, media: media, elapsed: elapsed, barre: barre,
           stima: !!r.approx, dettaglioPerso: !!r.dettaglioPerso, tagliato: tagliato, confronto: confronto,
           prevStima: !!(p && p.approx), prevVuota: !(p && p.ms > 0) };
}
/** Le tre letture della settimana: i giorni, le app, e la settimana prima. La settimana prima si legge come una
 *  settimana, con i giorni (causa 1 qui sopra): stessa domanda e stessa chiave di quando la si apre. */
async function insSettimanaLeggi(ws, we){
  const range = await insGet('w:' + ws, () => NATIVE.getScreenTimeRange({ from: ws, to: we, bucket: 'day' }));
  const top   = await insGet('wt:' + ws, () => NATIVE.getTopApps({ from: ws, to: we, limit: 50, icons: 12 }));
  const prevS = insAddDays(ws, -7);
  let prev = null;
  try { prev = await insGet('w:' + prevS, () => NATIVE.getScreenTimeRange({ from: prevS, to: ws, bucket: 'day' })); } catch(e){ prev = null; }
  return { range: range, top: top, prev: prev };
}
/* fine insSettimanaConti */

async function insRenderWeek(token){
  const body = document.getElementById('insBody');
  const ws = insAddDays(insWeekStart(Date.now()), -7 * INS.weekOff);
  const now = Date.now();
  const we = Math.min(now, insAddDays(ws, 7));
  if (we <= ws){ body.innerHTML = insNote('Settimana non ancora iniziata.'); return; }

  const L = await insSettimanaLeggi(ws, we);
  const range = L.range, top = L.top, prev = L.prev;
  if (token !== INS.token) return;

  const C = insSettimanaConti(range, prev, ws, we, now);
  const days = C.days;
  const elapsed = C.elapsed;
  INS.selfApp = (top.apps || []).filter(function(a){ return a && a.self; })[0] || null;
  const vive = insAppsVive(top.apps || []);
  try{ if (typeof jdImparaNomi === 'function') jdImparaNomi(top.apps || []); }catch(_){ }
  const selOn = insSelAttiva();
  const totMs = selOn ? Math.min(C.tot, insSelMs(top.apps || []) + (typeof rpDentroSelMs === 'function' ? rpDentroSelMs() : 0)) : C.tot;
  const avg = Math.min(INS_GIORNO_MS, totMs / elapsed);
  const mediaTot = C.media;
  const max = insCeil(Math.max.apply(null, days.concat([mediaTot])));

  let html = '';
  /* senza le barre il cartello sta dentro al grafico: una frase sola, non due che dicono la stessa cosa */
  if (C.stima && C.barre) html += '<div class="ins-approx">Di questa settimana il telefono conserva solo un riepilogo: il tempo medio \u00e8 una stima.</div>';
  else if (C.nPersi) html += '<div class="ins-approx">Il telefono conserva il dettaglio solo degli ultimi giorni: la media conta i giorni che ha ancora.</div>';
  html += '<div class="ins-big">' + insFmt(avg) + '</div>';
  html += '<div class="ins-lbl">Tempo medio sullo schermo' + (selOn ? ' \u2022 ' + esc(insSelNome()) : '') + '</div>';

  if (!selOn && C.confronto !== null){
    const delta = C.confronto;
    const cls = delta > 0 ? 'up' : (delta < 0 ? 'down' : 'flat');
    const arrow = delta > 0 ? '\u25b2' : (delta < 0 ? '\u25bc' : '=');
    html += '<div class="ins-badge ' + cls + '">' + arrow + ' ' + Math.abs(delta) + '% vs settimana precedente</div>';
  } else if (!selOn && C.prevVuota) {
    html += '<div class="ins-badge flat">Nessun dato sulla settimana precedente</div>';
  }

  /* 0.9.353: come nel giorno, se la divisione della settimana e' in memoria le barre nascono gia' colorate */
  const coloraSett = C.barre && (insHasCats() || selOn);
  const memSett = coloraSett ? INS_SETT_MEM.get(insFonteOra() + '|' + ws) : null;
  const perSett = memSett && Date.now() - memSett.t < 15 * 60000 ? memSett.per : null;
  const plot = C.barre
    ? '<div class="chart ins-week' + insSale('s:' + ws) + '" id="insWeekChart">' + (perSett ? insColsSett(days, max, perSett, C.persi) : days.map(function(ms, i){ return insColumn(ms, max, null, C.persi[i] ? 'ins-perso' : ''); }).join('')) + '</div>'
      + '<div class="ins-avg" style="top:' + (100 - mediaTot / max * 100).toFixed(2) + '%"><span class="ins-avgl">Media</span><span class="ins-flag" style="top:0">' + insFmt(mediaTot) + '</span></div>'
    /* senza il dettaglio dei giorni niente barre a zero, che direbbero "zero minuti": si dice cosa manca */
    : '<div class="ins-week-vuota">' + (C.stima || C.dettaglioPerso
        ? 'Di questa settimana il telefono conserva solo un riepilogo: il tempo medio \u00e8 una stima e i singoli giorni non ci sono pi\u00f9.'
        : 'In questa settimana non c\u2019\u00e8 tempo sullo schermo da mostrare.') + '</div>';
  const axis = '<div class="ins-x">' + INS_DOW.map(d => '<span>' + d + '</span>').join('') + '</div>';
  html += insPlot(plot, max, axis);

  const perTab = INS.filter === 'all' ? vive : vive.filter(a => insCats()[a.packageName] === INS.filter);
  if (insStatApps() && typeof rpCatChips === 'function'){
    html += rpCatChips(perTab, INS.filter === 'all' ? C.tot : perTab.reduce((t, a) => t + (a.ms || 0), 0));
  }
  html += insPromo();

  const apps = vive.filter(a => insInSel(a.packageName));
  html += '<i class="rp-mk" data-k="rpApp" hidden></i>';
  if (insStatApps()){
    html += '<div class="sect"><b>App pi\u00f9 usate</b></div>';
    html += insAppRows(apps, C.tot);
  }
  html += '<i class="rp-mk" data-k="rpEvitate" hidden></i>';
  html += await insAvoidedCard(ws, elapsed, 'questa settimana');
  if (token !== INS.token) return;

  // Abitudini: one extra hourly query over the whole week gives the real hour-of-day profile,
  // kept per day as well as aggregated — Focus has to look at each day separately.
  let hours = null, perDay = null, hApprox = false;
  try{
    const hr = await insGet('wh:' + ws, () => NATIVE.getScreenTimeRange({ from: ws, to: we, bucket: 'hour' }));
    if (token !== INS.token) return;
    hApprox = !!hr.approx;
    const acc = new Array(24).fill(0);
    const grid = []; for (let i = 0; i < 7; i++) grid.push(new Array(24).fill(0));
    let any = false;
    (hr.buckets || []).forEach(b => {
      const d = new Date(b.start);
      const idx = Math.round((insDayStart(b.start) - ws) / 86400000);
      acc[d.getHours()] += b.ms;
      if (idx >= 0 && idx < 7) grid[idx][d.getHours()] += b.ms;
      if (b.ms > 0) any = true;
    });
    if (any){ hours = acc; perDay = grid; }
  }catch(e){ hours = null; perDay = null; }

  html += '<i class="rp-mk" data-k="rpAbitudini" hidden></i>';
  html += '<div class="sect"><b>Abitudini</b></div>';
  if (hours){
    html += await insBalanceCard(perDay, C.tot, [0, 1, 2, 3, 4, 5, 6].map(function(i){ return insAddDays(ws, i); }));
    if (token !== INS.token) return;
    html += insPeakCard(hours);
  } else {
    html += insCard('Abitudini', insNote(hApprox
      ? 'Il riepilogo approssimato del tuo telefono non contiene la distribuzione oraria: senza quella non posso dirti la tua fascia di punta, e non la invento.'
      : 'Non ci sono ancora ore registrate in questa settimana.'));
  }

  html += insFocusCard(perDay || []);
  html += insCategorieCard(ws, ws + 7 * 86400000, 'Questa settimana');
  html += await insDistractionCard(ws, elapsed);
  if (token !== INS.token) return;
  html += '<i class="rp-mk" data-k="rpUtilizzo" hidden></i>';
  html += insUsageCard(top.apps || [], C.tot);

  html += '<i class="rp-mk" data-k="fine" hidden></i>';
  html += '<textarea id="insShareText" hidden>' + esc(
    'DreamMap \u00b7 ' + insDateLabel(ws) + '-' + insDateLabel(insAddDays(ws, 6)) + ': media ' + insFmt(C.media) + ' al giorno'
  ) + '</textarea>';

  body.innerHTML = html;
  insDopoDisegno(body);
  if (body.querySelector('#insWeekChart.ins-sale')) INS.saleAt = Date.now();
  if (coloraSett) insColourWeek(token, ws, days, max, elapsed, C.persi);
}

/* LA SETTIMANA A COLORI (0.9.353). Prima ogni giorno chiedeva le sue app alla sorgente scelta: col computer i giorni
   passati non hanno granelli, le liste tornavano vuote e le barre diventavano tutte grigie. Il computer pero' manda
   per ogni giorno la sua divisione (produttivo, distrattivo, neutrale, pcdati.js): adesso si usa quella. Il telefono
   risponde con il suo motore, una domanda per giorno. La divisione resta in memoria per sorgente e settimana. */
const INS_SETT_MEM = new Map();
async function insSettRighe(s, e){
  const f = insFonteOra();
  const off = Math.round((insDayStart(Date.now()) - s) / 86400000);
  /* sul computer resta la strada di prima: il suo motore e' gia' la ricostruzione in pagina */
  if (insQui() === 'computer') return ((await NATIVE.getTopApps({ from: s, to: e, limit: 30, icons: 0 })) || {}).apps || [];
  const out = [];
  if (f !== 'computer'){
    /* con "tutti e due" il telefono si chiede al suo motore vero: dalla ricostruzione in pagina ogni giorno passato
       rileggeva la cronologia di piu' giorni (mwGrani) solo per scartarla */
    const q = { from: s, to: e, limit: 30, icons: 0 };
    let r = null;
    if (f === 'insieme'){ if (typeof MW_NATIVO !== 'undefined' && MW_NATIVO && MW_NATIVO.getTopApps) r = await MW_NATIVO.getTopApps(q); }
    else r = await NATIVE.getTopApps(q);
    ((r && r.apps) || []).forEach(function(a){ out.push(Object.assign({ fonte: 'telefono' }, a)); });
  }
  if (f !== 'telefono'){
    const d = (typeof pcGiorno === 'function') ? pcGiorno(off) : null;
    if (d) [['prod', d.prod], ['distr', d.distr], ['neutro', d.neutro]].forEach(function(x){
      if (x[1] > 0) out.push({ packageName: '__pc_' + x[0], label: 'computer', ms: x[1] * 60000, cat: x[0], fonte: 'computer' });
    });
  }
  return out;
}
function insColsSett(days, max, per, persi){
  const sel = insSelAttiva();
  let cols = '';
  for (let i = 0; i < 7; i++){
    const pc = persi && persi[i] ? 'ins-perso' : '';
    if (sel) cols += insColumnSel(days[i], per[i] ? Math.min(days[i], insSelMs(per[i])) : 0, max, pc);
    else cols += insColumn(days[i], max, per[i] ? insSegs(per[i], days[i]) : null, pc);
  }
  return cols;
}
async function insColourWeek(token, ws, days, max, elapsed, persi){
  const key = insFonteOra() + '|' + ws;
  const m = INS_SETT_MEM.get(key);
  let per = m && Date.now() - m.t < INS_TTL ? m.per : null;
  if (!per){
    per = {};
    for (let i = 0; i < elapsed; i++){
      if (token !== INS.token) return;
      if (days[i] <= 0) continue;
      const s = insAddDays(ws, i), e = Math.min(Date.now(), insAddDays(ws, i + 1));
      if (e <= s) continue;
      try{ per[i] = await insSettRighe(s, e); }
      catch(err){ per[i] = []; }
    }
    if (token !== INS.token) return;
    INS_SETT_MEM.set(key, { t: Date.now(), per: per });
  }
  if (token !== INS.token || key !== insFonteOra() + '|' + ws) return;
  await insAspettaSalita();
  if (token !== INS.token) return;
  const chart = document.getElementById('insWeekChart');
  if (!chart) return;
  chart.classList.remove('ins-sale');
  const cols = insColsSett(days, max, per, persi);
  if (chart.innerHTML !== cols) chart.innerHTML = cols;
  insSnapSalva();
}

/* ---------------------------------------------------------------------------------------
   VIEW · TENDENZA
   --------------------------------------------------------------------------------------- */

async function insRenderTrend(token){
  const body = document.getElementById('insBody');
  const to = Date.now();
  const from = insAddDays(insDayStart(to), -59);
  const range = await insGet('trend:' + insDayKey(from), () => NATIVE.getScreenTimeRange({ from: from, to: to, bucket: 'day' }));
  if (token !== INS.token) return;

  const pts = (range.buckets || []).map(b => ({ t: b.start, ms: b.ms }));
  if (pts.length < 8){
    body.innerHTML = insNote('Servono almeno otto giorni di storico per disegnare una tendenza. Al momento il motore ne ha ' + pts.length + '.');
    return;
  }

  // Last 7 days against the 7 before them. Both averages are sums of engine buckets divided by
  // seven — no smoothing, no projection.
  const last7 = pts.slice(-7).reduce((s, p) => s + p.ms, 0) / 7;
  const prev7 = pts.slice(-14, -7).reduce((s, p) => s + p.ms, 0) / (Math.min(7, Math.max(1, pts.length - 7)));
  const diff = last7 - prev7;
  const pct = prev7 > 0 ? Math.round(diff / prev7 * 100) : null;
  const down = diff < 0;
  /* 0.9.353: il rosso e' quello del brand; il verde resta solo per il miglioramento */
  const tinta = down ? '#22C55E' : '#E63946';

  let html = '';
  if (range.approx) html += '<div class="ins-approx">Per i giorni più vecchi il telefono conserva solo un riepilogo: quella parte della curva è una stima.</div>';
  /* IL CERCHIO CON LA FRECCIA, poi il numero: rosso quando sale, verde quando scende. */
  html += '<div class="tr-arrow" style="background:' + tinta + '">' + (down ? INS_ICO.giu : INS_ICO.su) + '</div>';
  html += '<div class="ins-big">' + (down ? '-' : '+') + insFmt(Math.abs(diff)) + '</div>';
  html += '<div class="ins-lbl">' + (down ? 'Meno' : 'Pi\u00f9') + ' tempo sullo schermo al giorno</div>';
  if (pct !== null){
    html += '<div class="ins-badge ' + (down ? 'down' : 'up') + '">' + (down ? '\u25bc ' : '\u25b2 ') + Math.abs(pct) + '% di variazione in questo periodo</div>';
  }

  html += insTrendCurva(pts);

  /* LA CARD DEI DUE GRADINI: la prima settimana del periodo contro l'ultima. */
  const prima = pts.slice(0, 7), ultima = pts.slice(-7);
  const mPrima = prima.reduce((a, p) => a + p.ms, 0) / prima.length;
  html += '<div class="ins-card tr-cmp">'
    + '<b class="tr-t">Il tuo tempo sullo schermo \u00e8 ' + (down ? 'diminuito' : 'aumentato') + '</b>'
    + '<p class="tr-s">La settimana scorsa, il tuo tempo sullo schermo \u00e8 ' + (down ? 'diminuito' : 'aumentato') + ' di ' + insFmt(Math.abs(diff)) + ' al giorno.</p>'
    + insTrendGradini(prima, ultima, mPrima, last7, tinta)
    + '</div>';

  // I due podi: le app di questa settimana contro la precedente.
  const from7 = insAddDays(insDayStart(to), -6), from14 = insAddDays(insDayStart(to), -13);
  let top7 = null, top14 = null;
  try{ top7 = await insGet('t7:' + insDayKey(from7), () => NATIVE.getTopApps({ from: from7, to: to, limit: 50, icons: 12 })); }catch(e){ top7 = null; }
  try{ top14 = await insGet('t14:' + insDayKey(from14), () => NATIVE.getTopApps({ from: from14, to: from7, limit: 50, icons: 12 })); }catch(e){ top14 = null; }
  if (token !== INS.token) return;
  if (top7 && top14) html += insTrendPodi(insAppsVive(top7.apps || []), insAppsVive(top14.apps || []));

  html += '<i class="rp-mk" data-k="rpApp" hidden></i>';
  if (top7){
    html += '<div class="sect"><b>App pi\u00f9 usate</b><span class="ins-sect-note">ultimi 7 giorni</span></div>';
    INS.selfApp = (top7.apps || []).filter(function(a){ return a && a.self; })[0] || null;
    html += insAppRows(insAppsVive(top7.apps || []).filter(a => insInSel(a.packageName)), top7.ms);
  }
  html += '<i class="rp-mk" data-k="rpEvitate" hidden></i>';
  html += await insAvoidedCard(insAddDays(insDayStart(to), -29), 30, 'ultimi 30 giorni');
  if (token !== INS.token) return;

  html += '<i class="rp-mk" data-k="fine" hidden></i>';
  html += '<textarea id="insShareText" hidden>' + esc(
    'DreamMap \u00b7 ultimi 7 giorni: ' + insFmt(last7) + ' al giorno (' + (down ? '-' : '+') + insFmt(Math.abs(diff)) + ' rispetto ai 7 precedenti)'
  ) + '</textarea>';

  body.innerHTML = html;
  insDopoDisegno(body);
}

/* LA CURVA MORBIDA: i punti giorno per giorno passati per una spline (Catmull-Rom scritta come
   cubiche), l'area sotto in azzurro, l'asse a destra con cinque tacche, la media tratteggiata
   con la sua pillola, i mesi sotto dove cominciano. */
function insTrendCurva(pts){
  const W = 320, H = 170, R = 4;
  const max = insCeil(Math.max.apply(null, pts.map(p => p.ms)));
  const avg = pts.reduce((s, p) => s + p.ms, 0) / pts.length;
  const X = i => (i / (pts.length - 1) * (W - R * 2) + R);
  const Y = ms => (H - ms / max * (H - 10) - 4);
  const p = pts.map((q, i) => [X(i), Y(q.ms)]);
  let d = 'M' + p[0][0].toFixed(1) + ',' + p[0][1].toFixed(1);
  for (let i = 0; i < p.length - 1; i++){
    const p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(p.length - 1, i + 2)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ' C' + c1x.toFixed(1) + ',' + c1y.toFixed(1) + ' ' + c2x.toFixed(1) + ',' + c2y.toFixed(1) + ' ' + p2[0].toFixed(1) + ',' + p2[1].toFixed(1);
  }
  const area = d + ' L' + p[p.length - 1][0].toFixed(1) + ',' + H + ' L' + p[0][0].toFixed(1) + ',' + H + ' Z';
  const ay = Y(avg).toFixed(1);
  /* I mesi: un'etichetta dove ogni mese comincia, come nel modello («Set»). */
  let mesi = '';
  let ultimo = -1;
  pts.forEach((q, i) => {
    const m = new Date(q.t).getMonth();
    if (m !== ultimo){
      ultimo = m;
      if (i > 0 || pts.length < 20) mesi += '<span style="left:' + (X(i) / W * 100).toFixed(1) + '%">' + INS_MONTHS[m].slice(0, 3).replace(/^./, c => c.toUpperCase()) + '</span>';
    }
  });
  const tacche = [1, .75, .5, .25, 0].map(f => '<span>' + (f ? insFmt(max * f) : '0s') + '</span>').join('');
  const griglia = [1, .75, .5, .25].map(f => '<line x1="0" x2="' + W + '" y1="' + Y(max * f).toFixed(1) + '" y2="' + Y(max * f).toFixed(1) + '"/>').join('');
  return '<div class="tr-plot">'
    + '<div class="tr-plotbody">'
    +   '<svg class="tr-svg" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">'
    +     '<defs><linearGradient id="trFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0075E3" stop-opacity=".28"/><stop offset="1" stop-color="#0075E3" stop-opacity="0"/></linearGradient></defs>'
    +     '<g class="tr-grid">' + griglia + '</g>'
    +     '<path d="' + area + '" fill="url(#trFill)"/>'
    +     '<line class="tr-avg" x1="0" x2="' + W + '" y1="' + ay + '" y2="' + ay + '"/>'
    +     '<path d="' + d + '" fill="none" stroke="#0075E3" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>'
    +   '</svg>'
    +   '<span class="tr-avgl" style="top:' + (Y(avg) / H * 100).toFixed(1) + '%">Media</span>'
    +   '<span class="tr-avgv" style="top:' + (Y(avg) / H * 100).toFixed(1) + '%">' + insFmt(avg) + '</span>'
    +   '<div class="tr-mesi">' + mesi + '</div>'
    + '</div>'
    + '<div class="tr-y">' + tacche + '</div>'
    + '</div>';
}

/* I DUE GRADINI: sette barre della prima settimana con la loro media, sette dell'ultima con la
   sua, colorate col verso della variazione. */
function insTrendGradini(prima, ultima, mPrima, mUltima, tinta){
  const max = insCeil(Math.max.apply(null, prima.concat(ultima).map(p => p.ms).concat([mPrima, mUltima])));
  const barre = (lista, col) => lista.map(p => '<i style="height:' + Math.max(3, p.ms / max * 100).toFixed(1) + '%;background:' + col + '"></i>').join('');
  const top = m => (100 - m / max * 100).toFixed(1);
  return '<div class="tr-grad">'
    + '<div class="tr-g"><div class="tr-gbars">' + barre(prima, '#8CC6FF') + '<span class="tr-gline" style="top:' + top(mPrima) + '%;background:#3F9FF4"><b style="color:#fff">' + insFmt(mPrima) + '</b></span></div><small>Media della prima settimana</small></div>'
    + '<div class="tr-g"><div class="tr-gbars">' + barre(ultima, '#C8EFFD') + '<span class="tr-gline" style="top:' + top(mUltima) + '%;background:' + tinta + '"><b style="color:' + tinta + '">' + insFmt(mUltima) + '</b></span></div><small>Media sett. scorsa</small></div>'
    + '</div>';
}

/* I DUE PODI. Per ogni app: i minuti di questa settimana meno quelli della precedente. Chi
   scende va sul podio del risparmio (1, 2, 3 con gli allori); chi sale su quello
   dell'aumento (con la freccia rossa e l'avviso). Tre per parte, con l'icona vera. */
function insTrendPodi(ora, prima){
  const mappa = {};
  prima.forEach(a => { mappa[a.packageName] = { label: a.label, icon: a.icon, prima: a.ms || 0, ora: 0 }; });
  ora.forEach(a => {
    if (!mappa[a.packageName]) mappa[a.packageName] = { label: a.label, icon: a.icon, prima: 0, ora: 0 };
    mappa[a.packageName].ora = a.ms || 0;
    if (a.icon) mappa[a.packageName].icon = a.icon;
    mappa[a.packageName].label = a.label || mappa[a.packageName].label;
  });
  const righe = Object.keys(mappa).map(k => Object.assign({ pkg: k, delta: mappa[k].ora - mappa[k].prima }, mappa[k]));
  const giu = righe.filter(r => r.delta < -5 * 60000).sort((a, b) => a.delta - b.delta).slice(0, 3);
  const su = righe.filter(r => r.delta > 5 * 60000).sort((a, b) => b.delta - a.delta).slice(0, 3);
  /* 0.9.322, Andrea: "c'e' una M e non si capisce che app e'". L'icona si chiede al telefono anche qui, e sotto c'e' il nome */
  const icona = r => insIcoHtml({ packageName: r.pkg, label: r.label, icon: r.icon }) + '<small class="tr-nome">' + esc(r.label || '') + '</small>';
  const alt = [100, 78, 58];
  let out = '';
  if (giu.length){
    out += '<div class="ins-card tr-podio">'
      + '<div class="tr-ph"><div><b>Maggior risparmio di tempo</b><small>In queste app hai passato meno tempo</small></div><span class="tr-badge" style="background:#22C55E">' + INS_ICO.giu + '</span></div>'
      + '<div class="tr-cols">' + giu.map((r, i) =>
          '<div class="tr-col" style="height:' + alt[i] + '%">' + icona(r)
          + '<span class="tr-rank">\uD83C\uDF3F ' + (i + 1) + ' \uD83C\uDF3F</span>'
          + '<b>-' + insFmt(-r.delta) + '</b></div>').join('')
      + '</div></div>';
  }
  if (su.length){
    out += '<div class="ins-card tr-podio">'
      + '<div class="tr-ph"><div><b>Maggior aumento</b><small>Queste app ti hanno preso pi\u00f9 tempo</small></div><span class="tr-badge" style="background:#E63946">' + INS_ICO.su + '</span></div>'
      + '<div class="tr-cols">' + su.map((r, i) =>
          '<div class="tr-col" style="height:' + alt[i] + '%">' + icona(r)
          + '<span class="tr-up">' + INS_ICO.su + '</span>'
          + '<b>+' + insFmt(r.delta) + '</b></div>').join('')
      + '</div>'
      + '<div class="tr-warn">\u26A0 Fai attenzione a queste app</div></div>';
  }
  return out;
}

/* ---------------------------------------------------------------------------------------
   CARDS
   --------------------------------------------------------------------------------------- */

/* IL CARTELLO DI APPBLOCK, com'e' li': scuro, il titolo su due righe, il bottone a pillola
   «Ordina app», a destra quattro barre con le tre bolle dei giudizi sopra, la X in alto. Con
   aria intorno: prima stava incollato ai pannelli vicini. */
function insPromo(){
  if (localStorage.getItem('fl_ins_promo') === 'off') return '';
  return insPromoHtml(true);
}
/* lo stesso cartello scuro, anche nella pagina «Controllo sensazione app» (senza la X) */
function insPromoHtml(conX, testo, tab){
  return '<div class="ins-promo">'
       + '<div class="ins-promo-t"><p>' + esc(testo || 'Segna o escludi le tue app per ottenere statistiche migliori') + '</p>'
       +   '<button type="button" class="ordina" onclick="insSortApps(\'' + (tab || 'insights') + '\')">Ordina app</button></div>'
       + '<div class="ins-promo-art"><i class="b1"></i><i class="b2"></i><i class="b3"></i><i class="b4"></i>'
       +   '<span class="c1">' + insFaccia('distr') + '</span><span class="c2">' + insFaccia('prod') + '</span><span class="c3">' + insFaccia('neutro') + '</span></div>'
       + (conX ? '<button type="button" class="x" onclick="insHidePromo()" aria-label="Chiudi">\u2715</button>' : '') + '</div>';
}
function insHidePromo(){ try{ localStorage.setItem('fl_ins_promo','off'); }catch(e){} INS.forceRender = true; insRender(); }

/* G47 — Utilizzo. Percentages of the period total the engine measured. */
function insUsageCard(apps, totalMs){
  return '<div id="insUsoCard">' + insUsageCardDa(insSplit(apps, totalMs)) + '</div>';
}
function insUsageCardDa(s){
  if (!s.total) return insCard('Utilizzo', insNote('Nessun tempo di utilizzo registrato in questo periodo.'));
  const pc = v => Math.round(v / s.total * 100);
  const rows = ['distr','neutro','prod'].map(k =>
      '<div class="ins-row"><span class="ins-dot" style="background:' + INS_CAT[k].color + '"></span>'
    + INS_CAT[k].label + '<b>' + pc(s[k]) + ' %</b></div>'
    + '<div class="ins-track"><i style="width:' + pc(s[k]) + '%;background:' + INS_CAT[k].color + '"></i></div>').join('');
  const none = s.none > 0
    ? '<div class="ins-row"><span class="ins-dot" style="background:' + INS_NONE.color + '"></span>'
      + INS_NONE.label + '<b>' + pc(s.none) + ' %</b></div>'
      + '<div class="ins-track"><i style="width:' + pc(s.none) + '%;background:' + INS_NONE.color + '"></i></div>'
      + '<div class="ins-sub">Le app che non hai ancora ordinato, più il tempo sotto il minuto che il motore non attribuisce a nessuna app.</div>'
    : '';
  return insCard('Utilizzo <span class="info">i</span>', rows + none);
}

/* G48 — Bilancia. AppBlock says "% del tempo in cui eri sveglio"; FocusLock does not know when
   you sleep, so the denominator is the span between your first and last recorded use and the
   card says so. Claiming to measure wakefulness would be exactly the unverified estimate the
   client complained about. */
/* BILANCIA, con le parole del modello: «96 % del tempo in cui eri sveglio», grande e blu.
   «Sveglio» qui e' l'arco fra la prima e l'ultima ora di utilizzo: FocusLock non sa quando
   dormi, e la riga piccola in fondo lo dice. Il numero e' quello, la frase e' la sua. */
/* 0.9.305, Andrea alle 18:30, dopo 7h 45m di sonno: "19h 00m da sveglio" e "6h 31m al telefono".
   CAUSA VERA: "da sveglio" era l'arco fra la prima e l'ultima ORA del giorno di calendario con un po' di uso.
   Bastava toccare il telefono fra mezzanotte e l'una (la sera prima, prima di dormire) perche' l'arco partisse
   dalle 00:00: alle 18:xx diventava 19 ore, con dentro tutta la notte. Adesso il tempo da sveglio e' il giorno
   trascorso (da mezzanotte ad adesso, o a mezzanotte per i giorni passati) MENO il sonno che ci cade dentro,
   preso dal motore unico del sonno (sonno.js -> snNotteDi): la notte che finisce stamattina e, per i giorni
   chiusi, quella che comincia la sera. Senza la notte misurata c'e' un ripiego dichiarato a schermo: contano
   come sonno le ore fra le 23 e le 7 in cui il telefono non e' stato usato. */
const INS_NOTTE_STIMA = { da: 23, a: 7 };
/** Il tempo da sveglio dentro al giorno [ds, fine). Puro (lo prova tools/test-sveglio.js).
    n0: la notte che finisce la mattina di ds; n1: quella che comincia la sera di ds (solo giorni chiusi);
    hours: i 24 valori di uso per ora, servono solo al ripiego. */
function insSveglioGiorno(ds, fine, n0, n1, hours){
  const trascorso = Math.max(0, fine - ds);
  const dentro = function(a, b){ return Math.max(0, Math.min(b, fine) - Math.max(a, ds)); };
  const vera = function(n){ return !!(n && n.ok && n.inizio && n.sveglia && n.sveglia > n.inizio); };
  if (vera(n0)){
    let sonno = dentro(n0.inizio, n0.sveglia);
    const sera = vera(n1) && n1.inizio < fine ? n1.inizio : 0;
    if (sera) sonno += dentro(n1.inizio, n1.sveglia);
    return { ms: Math.max(0, trascorso - sonno), stima: false, sveglia: n0.sveglia, letto: sera };
  }
  let sonno = 0;
  for (let h = 0; h < 24; h++){
    const a = new Date(ds); a.setHours(h, 0, 0, 0);
    const t = a.getTime();
    if (t >= fine) break;
    const notte = h < INS_NOTTE_STIMA.a || h >= INS_NOTTE_STIMA.da;
    if (notte && !(hours && hours[h] > 0)){
      const b = new Date(ds); b.setHours(h + 1, 0, 0, 0);
      sonno += Math.max(0, Math.min(b.getTime(), fine) - t);
    }
  }
  return { ms: Math.max(0, trascorso - sonno), stima: true, sveglia: 0, letto: 0 };
}
/* fine insSveglioGiorno */
/** La notte che finisce la mattina di ds: dal motore del sonno sul telefono; sul computer quella arrivata
    dentro alla giornata pubblicata dal telefono o salvata. Mai piu' di quattro secondi di attesa. */
/* 0.9.353: la notte non cambia cambiando filtro. Prima ogni ridisegno del Report aspettava di nuovo il motore del sonno
   (fino a 4 secondi) prima di mostrare i numeri freschi: adesso una notte gia' letta vale per cinque minuti */
const INS_NOTTI = {};
async function insNotte(ds){
  const m = INS_NOTTI[ds];
  if (m && Date.now() - m.t < 5 * 60000) return m.n;
  try{
    if (typeof snNotteDi === 'function'){
      const n = await Promise.race([snNotteDi(ds), new Promise(function(r){ setTimeout(function(){ r(null); }, 4000); })]);
      if (n){ INS_NOTTI[ds] = { t: Date.now(), n: n }; return n; }
    }
  }catch(_){ }
  try{ if (typeof SW_GIORNO !== 'undefined' && SW_GIORNO && SW_GIORNO.rep && SW_GIORNO.rep.dayStart === ds && SW_GIORNO.rep.notte) return SW_GIORNO.rep.notte; }catch(_){ }
  try{ if (typeof scKey === 'function'){ const v = JSON.parse(localStorage.getItem('fl_dayrep_' + scKey(ds)) || 'null'); if (v && v.notte) return v.notte; } }catch(_){ }
  return null;
}
/* in ore anche oltre un giorno: "47h 15m da sveglio" in una settimana si legge, "1d 23h" no */
function insFmtOre(ms){ const m = Math.floor(Math.max(0, ms || 0) / 60000); return m < 60 ? m + 'm' : Math.floor(m / 60) + 'h ' + String(m % 60).padStart(2, '0') + 'm'; }
function insHHMM(t){ const d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
async function insBalanceCard(daysHours, totalMs, dayStarts){
  const adesso = Date.now();
  const giorni = [];
  (dayStarts || []).forEach(function(ds, i){
    if (!(ds < adesso)) return;
    const domani = insAddDays(ds, 1);
    giorni.push({ ds: ds, domani: domani, fine: Math.min(adesso, domani), hours: daysHours[i] || [] });
  });
  const notti = await Promise.all(giorni.map(function(g){
    return Promise.all([insNotte(g.ds), g.fine >= g.domani ? insNotte(g.domani) : Promise.resolve(null)]);
  }));
  let awakeMs = 0, stime = 0;
  const conti = giorni.map(function(g, i){
    const c = insSveglioGiorno(g.ds, g.fine, notti[i][0], notti[i][1], g.hours);
    awakeMs += c.ms; if (c.stima) stime++;
    return c;
  });
  const used = totalMs || 0;
  /* al telefono si sta da svegli: il tempo da sveglio non puo' essere meno di quello al telefono */
  awakeMs = Math.max(awakeMs, used);
  /* 0.9.289, Andrea: "Bilancia sembra un segno zodiacale; togli la nota 'Sveglio = ...', e se e' oggi non 'eri sveglio'".
     Il titolo dice cosa si confronta; sotto, i due tempi con le loro etichette, con lo spazio fra le righe. */
  /* 0.9.290, Andrea: "togli il titolo, lascia solo la frase; e un italiano direbbe: oggi il 24% del tempo in cui sei stato
     sveglio lo hai passato sul telefono". Un tempo verbale solo, e l'articolo giusto davanti al numero (l'80%, lo 0%). */
  if (!giorni.length || awakeMs <= 0) return insCard('Il telefono quando sei sveglio', insNote('Servono ore con utilizzo registrato per fare il confronto.'));
  const pct = Math.min(100, Math.round(used / awakeMs * 100));
  const oggi = INS.view === 'giorno' && !INS.dayOff;
  /* da dove viene il tempo da sveglio, in una riga sola */
  let nota = '';
  if (conti.length === 1){
    const c = conti[0];
    if (c.stima) nota = 'Mancano i dati del sonno di ' + (oggi ? 'stanotte' : 'quella notte') + ': conto come sonno le ore fra le 23 e le 7 in cui non hai usato il telefono.';
    else if (oggi) nota = 'Contato da quando ti sei svegliato, alle ' + insHHMM(c.sveglia) + '.';
    else nota = 'Contato da quando ti sei svegliato, alle ' + insHHMM(c.sveglia) + ', ' + (c.letto ? 'a quando sei andato a dormire, alle ' + insHHMM(c.letto) + '.' : 'fino a mezzanotte.');
  } else if (stime){
    nota = (stime === 1 ? 'Per un giorno mancano' : 'Per ' + stime + ' giorni mancano') + ' i dati del sonno: conto come sonno le ore fra le 23 e le 7 in cui non hai usato il telefono.';
  } else nota = 'Contato giorno per giorno, da quando ti sei svegliato a quando sei andato a dormire.';
  /* 0.9.302, Andrea: "Il 36% del tempo in cui sei sveglio", tutta nello stesso blu delle ore al telefono,
     senza "lo passi sul telefono" (come AppBlock: "96 % del tempo in cui eri sveglio"). */
  /* 0.9.351, Andrea: "il 46% di cosa? Prima le due cifre con le icone (al telefono, da sveglio), poi la frase con la barra" */
  /* 0.9.353, Andrea: "la frase va SOTTO la barra blu, prima della riga con 'contato da quando ti sei svegliato'".
     Ordine: i due numeri, la barra, la frase, la riga, la nota. E nella settimana "23h 32m al telefono, 74h 53m da
     sveglio" non diceva che e' la somma dei giorni: la frase lo dice, con quanti giorni conta. Col computer i
     numeri non sono "al telefono": l'etichetta segue la sorgente scelta. */
  const fonte = insFonteOra();
  const dove = fonte === 'computer' ? 'al computer' : (fonte === 'insieme' ? 'al telefono e al computer' : 'al telefono');
  const etichetta = fonte === 'insieme' ? 'su telefono e computer' : dove;
  let frase;
  if (conti.length > 1 || INS.view === 'settimana'){
    const n = conti.length, corrente = !INS.weekOff;
    const quanti = n === 1 ? 'contando solo oggi' : 'sommando i ' + n + ' giorni';
    frase = (corrente ? 'In questa settimana, ' : 'In quella settimana, ') + quanti + ', hai passato ' + dove + ' <b>'
      + flArticoloPct(pct) + pct + '%</b> del tempo da sveglio.';
  } else frase = '<b>' + flMaiuscola(flArticoloPct(pct)) + pct + '% del tempo in cui ' + (oggi ? 'sei' : 'eri') + ' sveglio</b>';
  return '<div class="ins-card ins-bil ins-bil2 ins-bil3">'
    + '<div class="ft"><span class="a">' + (fonte === 'computer' ? INS_ICO.pc : INS_ICO.phone) + '<span><b>' + insFmtOre(used) + '</b><small>' + etichetta + '</small></span></span>'
    +   '<span class="b"><span><b>' + insFmtOre(awakeMs) + '</b><small>da sveglio</small></span>' + INS_ICO.sun + '</span></div>'
    + '<div class="ins-track big"><i style="width:' + pct + '%"></i></div>'
    + '<p class="pct">' + frase + '</p>'
    + '<p class="ins-bil-n">' + esc(nota) + '</p>'
    + '</div>';
}

/** L'articolo davanti a una percentuale, come si legge: "lo 0%", "l'1%", "l'8%", "l'11%", "l'80%"…"l'89%", "il" per gli altri. */
function flArticoloPct(n){
  n = Math.round(+n || 0);
  if (n === 0) return 'lo ';
  if (n === 1 || n === 8 || n === 11 || (n >= 80 && n <= 89)) return 'l’';
  return 'il ';
}
function flMaiuscola(t){ t = String(t || ''); return t ? t.charAt(0).toUpperCase() + t.slice(1) : t; }
/* LE ICONE DELLE CARD: a tratto, blu, come nel modello. Inline perche' sono quattro e non
   vale un file; currentColor cosi' seguono il tema. */
const INS_ICO = {
  target: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><path d="M12 3v3M21 12h-3"/></svg>',
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M9 6h2M9 9h6M9 12h6"/><circle cx="12" cy="18" r=".9" fill="currentColor"/></svg>',
  pc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8.5 20h7M12 16v4"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z"/><path d="M10 21h4"/></svg>',
  hand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2.5" width="9" height="13" rx="2"/><path d="M13 15.5v3.5M9 19l-4-4.5c-.6-.7-.2-1.7.7-1.9.5-.1 1 .1 1.3.5L9 15"/><path d="M9 19v2h8v-4"/></svg>',
  su: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7M9 7h8v8"/></svg>',
  giu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7l10 10M17 9v8H9"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5 4.5 5.5v6c0 4.6 3.2 8.4 7.5 10 4.3-1.6 7.5-5.4 7.5-10v-6z"/><path d="m10.6 14.2-2.3-2.3 1.2-1.2 1.1 1.1 3.6-3.6 1.2 1.2z" fill="#fff"/></svg>'
};
/** Una card quadrata del modello: la (i), l'icona, l'etichetta, il numero. */
function insSq(ico, label, value, tip){
  return '<div class="sq">'
    + '<i class="info" onclick="insSqTip(this, ' + esc(JSON.stringify(tip || '')) + ')">i</i>'
    + '<span class="ico">' + ico + '</span>'
    + '<span class="lbl">' + label + '</span>'
    + '<b>' + value + '</b></div>';
}
function insSqTip(el, txt){
  if (!txt) return;
  if (typeof scTipAt === 'function'){ scTipAt(el, txt); return; }
  if (typeof toast === 'function') toast(txt);
}

/* G49 — FASCIA ORARIA DI MAGGIORE UTILIZZO, ritratto dal vero della card di AppBlock (0.9.302).
   Andrea: "fa cagare rispetto a quella di AppBlock". Come nel modello: il titolo a sinistra su due
   righe e l'orario blu A DESTRA del titolo; sotto, 24 barre a pillola staccate fra loro, senza
   assi ne' etichette; la barra dell'ora di picco sfuma dal blu in basso al rosso in alto; le ore
   senza dati sono trattini bassi. La barra piu' alta e' il picco. */
/* 0.9.319, Andrea: l'obiettivo di una sessione ha la sua categoria, e la categoria finisce nel report */
function insCategorieCard(da, a){
  let l = [], tags = [];
  try{ l = (typeof ffHist === 'function' ? ffHist() : []).filter(function(x){ return x && x.at >= da && x.at < a && !x.stornato && !x.meditazione && x.spentMs > 0; }); }catch(_){ l = []; }
  if (!l.length) return '';
  try{ tags = (typeof ffTags === 'function') ? ffTags() : []; }catch(_){ tags = []; }
  const per = {};
  l.forEach(function(x){ const k = x.tag || 'altro'; per[k] = (per[k] || 0) + x.spentMs; });
  const tot = Object.keys(per).reduce(function(t, k){ return t + per[k]; }, 0) || 1;
  const righe = Object.keys(per).sort(function(p, q){ return per[q] - per[p]; }).map(function(k){
    const t = tags.filter(function(x){ return x.id === k; })[0] || { name: k, ico: '🎯' };
    const min = Math.max(1, Math.round(per[k] / 60000)), h = Math.floor(min / 60);
    return '<li><span>' + ((typeof ffTagIco === 'function') ? ffTagIco(t) : '🎯') + '</span><div><b>' + esc(t.name || k) + '</b><i><u style="width:' + Math.round(per[k] / tot * 100) + '%"></u></i></div><em>' + (h ? h + 'h ' : '') + (min % 60 || !h ? (min % 60) + 'm' : '') + '</em></li>';
  }).join('');
  return '<div class="ins-card ins-cat"><div class="pk-hd"><b>Su cosa hai fatto Full Focus</b></div><ul>' + righe + '</ul></div>';
}
function insPeakCard(hours){
  let peak = -1;
  for (let h = 0; h < 24; h++) if (hours[h] > 0 && (peak < 0 || hours[h] > hours[peak])) peak = h;
  if (peak < 0) return '';
  const max = hours[peak];
  let cols = '';
  for (let h = 0; h < 24; h++){
    cols += '<span class="pk-c">' + (hours[h] > 0
      ? '<i' + (h === peak ? ' class="pk-top"' : '') + ' style="height:' + (hours[h] / max * 100).toFixed(2) + '%"></i>'
      : '<b></b>') + '</span>';
  }
  return '<div class="ins-card ins-picco">'
    + '<div class="pk-hd"><b>Fascia oraria di maggiore utilizzo</b><span>' + insPad(peak) + ':00 - ' + insPad((peak + 1) % 24) + ':00</span></div>'
    + '<div class="pk-bars">' + cols + '</div></div>';
}

/* G50 — Focus. Both figures come from the engine's hourly buckets, so their resolution is one
   hour and the card says it: a "1h 59m" claimed to the minute would be a number we do not have. */
function insFocusCard(daysHours){
  let bestGap = 0, bestRunMs = 0, any = false;
  // Each day is scanned on its own: a run that "spans" midnight between two separate days is
  // not one stretch of use, and the longest silence of the week is the longest silence of one
  // of its days, not of their sum.
  daysHours.forEach(hours => {
    let gap = 0, run = 0, runMs = 0, seen = false;
    for (let h = 0; h < 24; h++){
      if (hours[h] > 0){
        seen = true; any = true;
        gap = 0; run++; runMs += hours[h];
        if (runMs > bestRunMs) bestRunMs = runMs;
      } else {
        run = 0; runMs = 0;
        if (seen) { gap++; if (gap > bestGap) bestGap = gap; }
      }
    }
  });
  if (!any) return '';
  return '<div class="sect"><b>Focus</b></div>'
    + '<div class="sqgrid">'
    + insSq(INS_ICO.target, 'Focus pi\u00f9 lungo', bestGap ? bestGap + 'h' : '\u2014',
        'La serie pi\u00f9 lunga di ore senza schermo. Il motore conta ora per ora: la risoluzione \u00e8 quella, non il minuto.')
    + insSq(INS_ICO.phone, 'Utilizzo continuo', bestRunMs ? insFmt(bestRunMs) : '\u2014',
        'Il totale della serie pi\u00f9 lunga di ore consecutive con schermo acceso.')
    + '</div>';
}

/* G51 — Distrazioni. Notifiche silenziate e sblocchi del telefono, contati dal motore. */
async function insDistractionCard(fromTs, days){
  if (!NATIVE.getInsights) return '';
  let ins;
  try { ins = await insGet('insights', () => NATIVE.getInsights({ days: 30 })); }
  catch(e){ return insCard('Distrazioni', insNote('Contatori non disponibili: ' + insErr(e))); }

  let notif = 0, pick = 0, found = 0;
  const hist = ins.history || [];
  for (let i = 0; i < days; i++){
    const key = insDayKey(insAddDays(fromTs, i));
    const row = hist.filter(r => r.day === key)[0];
    if (!row) continue;
    found++;
    notif += row.notifications || 0;
    pick  += row.pickups || 0;
  }
  // Today's row is written as the day goes on; the live counters are the fresher truth for it.
  if (days === 1 && insDayKey(fromTs) === insDayKey(Date.now())){
    notif = ins.notificationsToday || notif;
    pick  = ins.pickupsToday || pick;
    found = 1;
  }
  if (!found) return '<div class="sect"><b>Distrazioni</b></div>' + insNote('Il motore non ha registrato nulla in questo periodo.');
  return '<div class="sect"><b>Distrazioni</b></div>'
    + '<div class="sqgrid">'
    + insSq(INS_ICO.bell, 'Notifiche', notif + '\u00d7', 'Le notifiche silenziate dal servizio di DreamMap nel periodo.')
    + insSq(INS_ICO.hand, 'Risposte', pick + '\u00d7', 'Le volte che hai preso in mano e sbloccato il telefono, contate dal motore.')
    + '</div>';
}

async function insBlocks(){
  try { return await insGet('stats', () => NATIVE.getStats()); }
  catch(e){ return null; }
}
function insBlocksCard(s){
  if (!s) return '';
  return '<div class="statgrid">'
       + '<div class="statbox"><b id="stBlocked">' + (s.today || 0) + '</b><span>bloccati oggi</span></div>'
       + '<div class="statbox"><b id="stTotal">' + (s.total || 0) + '</b><span>bloccati in totale</span></div>'
       + '</div>';
}

/* AppBlock's "Distrazioni evitate": the attempts the engine stopped in the period, and the
   notifications it silenced. Counted, not estimated. */
/* «DISTRAZIONI EVITATE» come nel modello: una riga, a sinistra il titolo e «Schermata di
   blocco visualizzata», a destra la pillola sfumata con lo scudo, il numero e le miniature
   delle app fermate. Le miniature arrivano dal motore (Stats: le app bloccate del giorno),
   quindi sono le app VERE, non un'illustrazione. */
async function insAvoidedCard(fromTs, days, periodLabel){
  if (!NATIVE.getInsights) return '';
  let ins;
  try { ins = await insGet('insights', () => NATIVE.getInsights({ days: 30 })); }
  catch(e){ return ''; }
  let blocks = 0;
  const conteggio = {};
  const hist = ins.history || [];
  for (let i = 0; i < days; i++){
    const key = insDayKey(insAddDays(fromTs, i));
    const row = hist.filter(r => r.day === key)[0];
    if (!row) continue;
    blocks += row.blocks || 0;
    (row.apps || []).forEach(p => { conteggio[p] = (conteggio[p] || 0) + 1; });
  }
  if (days === 1 && insDayKey(fromTs) === insDayKey(Date.now())){
    blocks = ins.today || blocks;
    (ins.appsToday || []).forEach(p => { conteggio[p] = (conteggio[p] || 0) + 10; });
  }
  const pkgs = Object.keys(conteggio).sort((a, b) => conteggio[b] - conteggio[a]).slice(0, 3);
  const thumbs = pkgs.map(p => '<span class="th"><img class="ub-appico" data-pkg="' + esc(p) + '" alt=""></span>').join('');
  return '<div class="ins-card ins-avoid">'
    + '<div class="t"><b>Distrazioni evitate</b><small>Schermata di blocco visualizzata' + (periodLabel && days > 1 ? ' \u00b7 ' + esc(periodLabel) : '') + '</small></div>'
    + '<div class="pill"><span class="sh">' + INS_ICO.shield + '</span><b>' + blocks + '</b>' + thumbs + '</div>'
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   G54 — APP PIÙ USATE
   --------------------------------------------------------------------------------------- */

function insIcoColor(pkg){
  // Stable per package so the same app keeps the same tile between renders. The engine does not
  // hand icons to JavaScript, so this is a letter tile, not a fake icon.
  // 0.9.303: the tile used any hue of the wheel, purple included ("imo" came out as a white I on
  // purple). Now it is one of the brand colours, still stable per package.
  const pal = ['#0075E3', '#005BB0', '#3F9FF4', '#E63946', '#C42B38', '#0E2350', '#14234A', '#E71D4F'];
  let h = 0;
  for (let i = 0; i < String(pkg || '').length; i++) h = (h * 31 + pkg.charCodeAt(i)) % 9973;
  return pal[h % pal.length];
}
function insAppRows(apps, totalMs){
  if (!apps || !apps.length){
    return insNote(insSelAttiva()
      ? 'Nessuna app di questa categoria in questo periodo.'
      : 'Nessuna app ha superato il minuto di utilizzo in questo periodo.');
  }
  const cats = insCats(), ex = insExcl();
  const webOn = insSitiOn();
  /* DREAMMAP E' UN CASSETTO COME CHROME (0.9.299). Andrea: "gli insights di DreamMap devono stare in App piu'
     usate, dentro un toggle con il +, come Chrome; sotto al grafico solo le categorie generali". L'app nostra entra
     nell'elenco al suo posto per tempo, e dentro ci sono le aree dell'app (taRiassunto, report.js rpDentro). */
  const io = (!insSelAttiva() && INS.selfApp && (INS.selfApp.ms || 0) >= 60000) ? INS.selfApp : null;
  if (io && !apps.some(function(a){ return a.packageName === io.packageName; })){
    apps = apps.slice();
    let k = 0; while (k < apps.length && (apps[k].ms || 0) >= (io.ms || 0)) k++;
    apps.splice(k, 0, Object.assign({}, io, { label: 'DreamMap', __io: true }));
  }
  const shown = INS.showAllApps ? apps : apps.slice(0, 6);
  let html = shown.map(a => {
    /* 0.9.353: un programma del computer mostra la categoria scelta sul computer, non "Non categorizzato" */
    const c = insCatRiga(a, cats);
    const meta = c ? INS_CAT[c] : (a.__io && INS_CAT.prod ? INS_CAT.prod : INS_NONE);
    const excl = ex.indexOf(a.packageName) >= 0;
    const isBrowser = INS_BROWSERS.indexOf(a.packageName) >= 0;
    const aperto = isBrowser && webOn && insBrAperto(a.packageName);
    const faccia = insIcoHtml(a)
      + '<div class="nm"><b>' + esc(a.label || a.packageName) + '</b>'
      + '<span><span class="ins-dot" style="background:' + meta.color + '"></span>' + esc(meta.label)
      + (excl ? ' \u00b7 escl.' : '') + (a.blocked ? ' \u00b7 bloccata' : '') + '</span></div>'
      + '<span class="tm">' + insFmt(a.ms) + '</span>';
    if (a.__io) return insIoGruppo(a, faccia);
    if (!isBrowser && typeof socE === 'function' && socE(a.packageName)) return insSocGruppo(a, faccia);
    if (!isBrowser){
      return '<div class="ins-app" onclick="insOpenDetail(\'' + esc(a.packageName) + '\')">' + faccia + '<span class="chev"></span></div>';
    }
    /* IL BROWSER E' UN CASSETTO, COME SU APPBLOCK. Prima i siti stavano in un secondo
       riquadro tratteggiato staccato sotto alla riga, e la freccia girata di 180 gradi
       puntava a sinistra. Adesso riga e siti sono lo stesso riquadro: i siti stanno dentro,
       rientrati sotto al nome, e il segno e' il + del tema del sito (.animated-plus) che
       gira di un quarto e diventa -. Tutta la riga apre e chiude; il dettaglio dell'app e'
       l'ultima voce del cassetto. */
    const p = esc(a.packageName);
    return '<div class="ins-grp' + (aperto ? ' on' : '') + '" id="grp-' + p + '">'
      + '<div class="ins-app" role="button" aria-expanded="' + (aperto ? 'true' : 'false') + '" onclick="insToggleSites(\'' + p + '\')">'
      +   faccia + '<span class="animated-plus"></span></div>'
      + '<div class="ins-sites" id="sites-' + p + '"' + (aperto ? '' : ' hidden') + '></div>'
      + '</div>';
  }).join('');
  if (!INS.showAllApps && apps.length > 6){
    html += '<button class="ins-more" onclick="insShowAll()">Altro <span class="blk-tplchev"></span></button>';
  }
  return html;
}
function insShowAll(){ INS.showAllApps = true; INS.forceRender = true; insRender(); }
function insIoAperto(){ try{ return localStorage.getItem('fl_io_chiuso') !== '1'; }catch(_){ return true; } }
function insIoGruppo(a, faccia){
  const aperto = insIoAperto();
  let dentro = [];
  try{ dentro = (typeof rpDentro === 'function') ? rpDentro() : []; }catch(_){ dentro = []; }
  const righe = dentro.slice(0, 8).map(function(x){
    const info = (typeof rpCatInfo === 'function') ? rpCatInfo(x.chip) : null;
    const col = (typeof taCat === 'function') ? taCat(x.c).col : '#0075E3';
    return '<div class="s"><i style="background:' + col + '">' + (info && info.ic ? info.ic : esc(String(x.l || '?').charAt(0).toUpperCase())) + '</i>'
      + '<span class="nm">' + esc(x.l) + '</span><span class="tm">' + insFmt(x.ms) + '</span></div>';
  }).join('');
  const corpo = righe ? '<div class="ins-sitelist ins-io">' + righe + '</div>'
    : '<div class="ins-sitenote">Il tempo dentro DreamMap si divide per area mentre la usi: torna qui fra poco.</div>';
  return '<div class="ins-grp' + (aperto ? ' on' : '') + '" id="grp-io">'
    + '<div class="ins-app" role="button" aria-expanded="' + (aperto ? 'true' : 'false') + '" onclick="insToggleIo()">'
    +   faccia + '<span class="animated-plus"></span></div>'
    + '<div class="ins-sites" id="sites-io" data-loaded="1"' + (aperto ? '' : ' hidden') + '>' + corpo
    +   '<button type="button" class="ins-br-det" onclick="insOpenDetail(\'' + esc(a.packageName) + '\')">Dettagli dell\'app<span class="chev"></span></button></div>'
    + '</div>';
}
function insToggleIo(){
  const el = document.getElementById('sites-io'); if (!el) return;
  el.hidden = !el.hidden;
  const g = document.getElementById('grp-io');
  if (g){ g.classList.toggle('on', !el.hidden); const r = g.querySelector('.ins-app'); if (r) r.setAttribute('aria-expanded', el.hidden ? 'false' : 'true'); }
  try{ localStorage.setItem('fl_io_chiuso', el.hidden ? '1' : '0'); }catch(_){ }
}
/* LE APP SOCIAL SONO UN CASSETTO, COME DREAMMAP (0.9.300). Andrea: "ogni app social nelle App piu' usate ha un
   cassetto con il tempo per sezione, lo stesso approfondimento della pagina Blocco funzionalita'". Dentro: l'anello
   piccolo e le sezioni (sezioni-social.js, dal motore), e con telefono + computer anche il tempo del computer, che
   per sezione non si divide: si somma al totale e si dice. Di serie chiuso: cinque cassetti aperti allungherebbero
   la pagina; aperto o chiuso resta come l'hai lasciato. */
function insSocAperto(pkg){ try{ return localStorage.getItem('fl_soc_aperto_' + pkg) === '1'; }catch(_){ return false; } }
function insSocGruppo(a, faccia){
  const p = esc(a.packageName), aperto = insSocAperto(a.packageName);
  return '<div class="ins-grp' + (aperto ? ' on' : '') + '" id="socg-' + p + '">'
    + '<div class="ins-app" role="button" aria-expanded="' + (aperto ? 'true' : 'false') + '" onclick="insToggleSoc(\'' + p + '\')">'
    +   faccia + '<span class="animated-plus"></span></div>'
    + '<div class="ins-sites ins-soc" id="socs-' + p + '" data-loaded="1" data-soc="' + p + '" data-ms="' + (+a.ms || 0) + '"' + (aperto ? '' : ' hidden') + '></div>'
    + '</div>';
}
function insToggleSoc(pkg){
  const el = document.getElementById('socs-' + pkg); if (!el) return;
  el.hidden = !el.hidden;
  const g = document.getElementById('socg-' + pkg);
  if (g){ g.classList.toggle('on', !el.hidden); const r = g.querySelector('.ins-app'); if (r) r.setAttribute('aria-expanded', el.hidden ? 'false' : 'true'); }
  try{ localStorage.setItem('fl_soc_aperto_' + pkg, el.hidden ? '0' : '1'); }catch(_){ }
  if (!el.hidden) insSocCarica(el);
}
function insSocAuto(body){
  (body || document).querySelectorAll('.ins-soc[data-soc]:not([hidden])').forEach(function(el){ insSocCarica(el); });
}
/* La finestra del cassetto: quella della vista, o la sola ora scelta sul grafico del giorno. */
function insSocFinestra(){
  const r = insRangeNow();
  if (INS.view === 'giorno' && INS.oraSel != null && INS.oraSelDay === r.from){
    const s0 = new Date(r.from); s0.setHours(INS.oraSel, 0, 0, 0);
    const e0 = new Date(r.from); e0.setHours(INS.oraSel + 1, 0, 0, 0);
    return { from: s0.getTime(), to: Math.min(Date.now(), e0.getTime()), ora: true };
  }
  return { from: r.from, to: r.to, ora: false };
}
/* Il tempo di questa app sul COMPUTER nella finestra: il programma con lo stesso nome e il suo sito.
   Oggi dai granelli (con l'ora), i giorni passati dai totali che il computer pubblica (senza ora). */
async function insSocPcMs(pkg, w){
  const app = (typeof SOC_APPS !== 'undefined' && SOC_APPS[pkg]) || null;
  if (!app) return { ms: 0, senzaOra: false };
  const nome = app.nome.toLowerCase(), host = app.host || [];
  const suo = function(n){
    n = String(n || '').toLowerCase().replace(/^www\./, '');
    if (!n) return false;
    if (n === nome || n.indexOf(nome + ' ') === 0) return true;
    return host.some(function(h){ return n === h || n.slice(-(h.length + 1)) === '.' + h; });
  };
  let ms = 0, senzaOra = false;
  const oggi = (typeof mwMezzanotte === 'function') ? mwMezzanotte(0) : insDayStart(Date.now());
  for (let t = insDayStart(w.from); t < w.to; t = insAddDays(t, 1)){
    if (t === oggi){
      let g = [];
      try{ g = (typeof mwGraniComputer === 'function') ? (await mwGraniComputer(oggi)) || [] : []; }catch(_){ g = []; }
      g.forEach(function(x){
        if (!suo((typeof mwNome === 'function') ? mwNome(x) : (x.l || x.p))) return;
        const a = Math.max(x.s, w.from), b = Math.min(x.s + x.ms, w.to);
        if (b > a) ms += b - a;
      });
    } else {
      const off = Math.round((oggi - t) / 86400000);
      const agg = (typeof mwGiornoAggregato === 'function') ? mwGiornoAggregato(off) : null;
      if (!agg) continue;
      if (w.ora){ senzaOra = true; continue; }
      (agg.top || []).forEach(function(x){ if (suo(x.label || x.packageName)) ms += x.ms || 0; });
    }
  }
  return { ms: ms, senzaOra: senzaOra };
}
async function insSocCarica(el){
  const pkg = el.getAttribute('data-soc'); if (!pkg || typeof socLeggi !== 'function') return;
  const w = insSocFinestra();
  const firma = w.from + ':' + Math.floor(w.to / 60000) + ':' + ((typeof mwFonte === 'function') ? mwFonte() : '');
  if (el.dataset.firma === firma) return;
  el.dataset.firma = firma;
  if (!el.innerHTML) el.innerHTML = '<div class="ins-sitenote">Leggo le sezioni\u2026</div>';
  const dati = await socLeggi(w.from, w.to);
  const righe = ((dati && dati.apps && dati.apps[socPkg(pkg)]) || []).map(function(x){ return Object.assign({}, x); });
  const insieme = (typeof mwFonte === 'function') && mwFonte() === 'insieme';
  /* il totale dell'anello e' quello della riga: «Altro» e' la parte del tempo dell'app che nessuna sezione ha riconosciuto */
  const rigaMs = +el.getAttribute('data-ms') || 0;
  if (rigaMs > 0 && !((typeof mwFonte === 'function') && mwFonte() !== 'telefono')){
    const nominate = righe.reduce(function(t, x){ return t + (x.k === 'altro' ? 0 : (x.ms || 0)); }, 0);
    righe.forEach(function(x){ if (x.k === 'altro') x.ms = Math.max(0, rigaMs - nominate); });
  }
  const tel = socTotale(righe);
  const pc = insieme ? await insSocPcMs(socPkg(pkg), w) : { ms: 0, senzaOra: false };
  let html = '<div class="ins-soc-in">' + socAnello(righe, { piccolo: true })
    + '<div class="ins-soc-l">' + righe.map(function(x){
        return '<div class="r"><i style="background:' + x.col + '"></i><span class="nm">' + esc(x.l) + '</span><span class="tm">' + insFmt(x.ms) + '</span></div>';
      }).join('') + '</div></div>';
  if (insieme){
    html += '<div class="ins-soc-pc"><div class="r"><span class="nm">Sul telefono</span><span class="tm">' + insFmt(tel) + '</span></div>'
      + '<div class="r"><span class="nm">Sul computer</span><span class="tm">' + insFmt(pc.ms) + '</span></div>'
      + '<div class="r tot"><span class="nm">In tutto</span><span class="tm">' + insFmt(tel + pc.ms) + '</span></div></div>'
      + '<div class="ins-sitenote">Il computer non divide il tempo per sezione: qui si somma solo il totale.'
      + (pc.senzaOra ? ' Per i giorni passati il computer non dice l\'ora, e nell\'ora scelta non c\'\u00e8.' : '') + '</div>';
  }
  if (!(tel > 0) && !(dati && dati.motore)) html += '<div class="ins-sitenote">Il tempo per sezione si misura sul telefono, con DreamMap installata.</div>';
  html += '<button type="button" class="ins-br-det" onclick="insOpenDetail(\'' + esc(pkg) + '\')">Dettagli dell\'app<span class="chev"></span></button>';
  el.innerHTML = html;
}
/* LE ICONE DELLE APP, SEMPRE (0.9.307).

   Andrea (30/10, foto della scheda Settimana): Shazam, Orologio, Studio, CapCut, Messaggi, Gmail con la sola
   iniziale, dopo "Altro" e a volte anche nel Giorno tornando indietro. LE CAUSE VERE erano tre:
   1. il motore mette l'icona solo nelle prime 12 righe di getTopApps (icons: 12): dalla tredicesima la riga
      nasceva con la lettera;
   2. chi doveva chiedere le icone mancanti (insIconeMancanti) partiva SOLO nel Giorno, e solo dentro al ramo
      del controllo dell'umore: nella Settimana e dopo "Altro" non partiva mai. E quando partiva, chiedeva le
      icone una alla volta e le metteva negli elementi che aveva in mano: se intanto la pagina si ridisegnava
      (i numeri freschi dopo la pagina salvata), le icone finivano in elementi gia' staccati;
   3. la cache era solo in memoria, per sessione, e separata da quella delle altre liste (ubFillIcons).

   ADESSO: una cache sola, in memoria e in IndexedDB (icone piccole, 64 px), che si apre all'avvio; ogni riga
   che conosce gia' la sua icona la disegna subito, nell'HTML; quelle che non la conoscono la chiedono a lotti
   (quattro alla volta, nessun limite di righe), e l'icona arrivata va a TUTTI gli elementi di quel pacchetto
   che sono a schermo in quel momento, non a quelli di prima. */
const INS_ICONE = {};                 // pkg -> data URI, oppure '' (nessuna icona)
const INS_ICO_ATTESE = {};
const INS_ICO_CODA = [];
let INS_ICO_IN = 0;
let INS_ICO_DB = null;
/* 0.9.326, Andrea: "le immagini sono troppo sgranate". 64 px su un'icona da 58 punti, su uno schermo a densita' 3: si salva a 144, come le da' il telefono */
const INS_ICO_PX = 144;

function insIcoDb(){
  if (INS_ICO_DB) return INS_ICO_DB;
  INS_ICO_DB = new Promise(function(res){
    try{
      if (typeof indexedDB === 'undefined'){ res(null); return; }
      const r = indexedDB.open('dm-icone', 1);
      r.onupgradeneeded = function(){ try{ r.result.createObjectStore('icone'); }catch(_){ } };
      r.onsuccess = function(){ res(r.result); };
      r.onerror = function(){ res(null); };
      r.onblocked = function(){ res(null); };
    }catch(_){ res(null); }
  });
  return INS_ICO_DB;
}
/** All'avvio: tutte le icone salvate in memoria, poi si riempie quello che e' gia' a schermo. */
async function insIcoApri(){
  const db = await insIcoDb();
  if (!db) return;
  await new Promise(function(res){
    try{
      const rq = db.transaction('icone', 'readonly').objectStore('icone').openCursor();
      rq.onsuccess = function(){
        const c = rq.result;
        if (!c){ res(); return; }
        const v = c.value;
        if (v && v.i && v.p === INS_ICO_PX && INS_ICONE[c.key] === undefined) INS_ICONE[c.key] = v.i;
        c.continue();
      };
      rq.onerror = function(){ res(); };
    }catch(_){ res(); }
  });
  insIconeRiempi(document);
}
/** Un'icona grande diventa una piccola (64 px): in IndexedDB ne stanno centinaia senza pesare. */
function insIcoPiccola(uri){
  return new Promise(function(res){
    try{
      if (!uri || uri.indexOf('data:image') !== 0 || uri.length < 6000 || typeof document === 'undefined'){ res(uri); return; }
      const im = new Image();
      im.onload = function(){
        try{
          const cv = document.createElement('canvas'); cv.width = INS_ICO_PX; cv.height = INS_ICO_PX;
          cv.getContext('2d').drawImage(im, 0, 0, INS_ICO_PX, INS_ICO_PX);
          let out = cv.toDataURL('image/webp', 0.9);
          if (out.indexOf('data:image/webp') !== 0) out = cv.toDataURL('image/png');
          res(out.length < uri.length ? out : uri);
        }catch(_){ res(uri); }
      };
      im.onerror = function(){ res(uri); };
      im.src = uri;
    }catch(_){ res(uri); }
  });
}
function insIcoSalva(pkg, uri){
  if (!pkg || !uri || uri.indexOf('data:image') !== 0) return;
  insIcoPiccola(uri).then(function(pic){
    INS_ICONE[pkg] = pic;
    return insIcoDb().then(function(db){
      if (!db) return;
      try{ db.transaction('icone', 'readwrite').objectStore('icone').put({ i: pic, p: INS_ICO_PX, t: Date.now() }, pkg); }catch(_){ }
    });
  }).catch(function(){ });
}
/** L'icona che si conosce gia', subito (o ''). */
function insIconaSubito(pkg){ const v = INS_ICONE[pkg]; return v ? v : ''; }
/** L'icona di un pacchetto: dalla cache, o chiesta al motore in coda (quattro alla volta). */
function insIcona(pkg){
  if (!pkg) return Promise.resolve('');
  const m = INS_ICONE[pkg];
  if (m !== undefined) return Promise.resolve(m);
  if (INS_ICO_ATTESE[pkg]) return INS_ICO_ATTESE[pkg];
  const pr = new Promise(function(res){ INS_ICO_CODA.push({ pkg: pkg, res: res }); });
  INS_ICO_ATTESE[pkg] = pr;
  insIcoGira();
  return pr;
}
function insIcoGira(){
  while (INS_ICO_IN < 4 && INS_ICO_CODA.length){
    const j = INS_ICO_CODA.shift();
    INS_ICO_IN++;
    (async function(){
      let ic = '';
      /* prima si aspetta la cache salvata: chi chiede un'icona nel primo mezzo secondo non deve rifarla */
      try{ await insIcoPronte(); }catch(_){ }
      if (INS_ICONE[j.pkg]){ ic = INS_ICONE[j.pkg]; delete INS_ICO_ATTESE[j.pkg]; insIcoAggiornaDom(j.pkg, ic); j.res(ic); return; }
      try{
        if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getAppIcon){
          const r = await NATIVE.getAppIcon({ packageName: j.pkg });
          ic = (r && r.icon) || '';
        }
      }catch(_){ ic = ''; }
      if (ic && ic.indexOf('data:image') === 0){ try{ ic = await insIcoPiccola(ic); }catch(_){ } insIcoSalva(j.pkg, ic); }
      /* senza icona dal telefono: per i programmi del computer, la favicon del sito (mai salvata) */
      if (!ic && !/^[a-z][a-z0-9_]*(\.[a-z0-9_]+){2,}$/i.test(j.pkg)){ try{ ic = insSitoIcona(j.pkg) || ''; }catch(_){ ic = ''; } }
      INS_ICONE[j.pkg] = ic;
      delete INS_ICO_ATTESE[j.pkg];
      if (ic) insIcoAggiornaDom(j.pkg, ic);
      j.res(ic);
    })().catch(function(){ }).then(function(){ INS_ICO_IN--; insIcoGira(); });
  }
}
/** Mette l'icona in un elemento: la tessera con la lettera diventa un'immagine, l'immagine prende la sorgente. */
function insIcoMetti(el, ic){
  if (!el || !ic) return;
  if (el.tagName === 'IMG'){
    if (el.getAttribute('src') !== ic) el.src = ic;
    el.dataset.done = '1';
    return;
  }
  if (!el.parentElement) return;
  const img = document.createElement('img');
  img.className = 'ins-appimg';
  img.setAttribute('data-pkg', el.getAttribute('data-pkg') || '');
  img.alt = '';
  img.src = ic;
  el.replaceWith(img);
}
function insIcoSel(pkg){
  const q = (typeof CSS !== 'undefined' && CSS.escape) ? CSS.escape(pkg) : String(pkg).replace(/"/g, '\\"');
  return '.ins-ico[data-pkg="' + q + '"], img.ins-appimg[data-pkg="' + q + '"], img.ub-appico[data-pkg="' + q + '"]';
}
function insIcoAggiornaDom(pkg, ic){
  try{ document.querySelectorAll(insIcoSel(pkg)).forEach(function(el){ insIcoMetti(el, ic); }); }catch(_){ }
}
/** Ogni tessera con la lettera e ogni immagine senza sorgente prende la sua icona: subito se e' in cache, se no in coda. */
function insIconeRiempi(root){
  const box = root || document;
  let els = [];
  try{ els = box.querySelectorAll('.ins-ico[data-pkg], img.ins-appimg[data-pkg]:not([src]), img.ub-appico[data-pkg]:not([src])'); }catch(_){ return; }
  const chiesti = {};
  Array.prototype.forEach.call(els, function(el){
    const pkg = el.getAttribute('data-pkg'); if (!pkg) return;
    const ic = INS_ICONE[pkg];
    if (ic){ insIcoMetti(el, ic); return; }
    if (ic === '' || chiesti[pkg]) return;
    chiesti[pkg] = 1;
    insIcona(pkg);
  });
}
/** La faccia di una riga: l'icona arrivata col dato o quella in cache, nell'HTML; se no la lettera, che si riempie dopo. */
function insIcoHtml(a){
  const pkg = a.packageName || '';
  if (a.icon && String(a.icon).indexOf('data:image') === 0 && !INS_ICONE[pkg]) insIcoSalva(pkg, a.icon);
  const ic = INS_ICONE[pkg] || a.icon || '';
  if (ic) return '<img class="ins-appimg" data-pkg="' + esc(pkg) + '" src="' + ic + '" alt="">';
  return '<div class="ins-ico" data-pkg="' + esc(pkg) + '" style="background:' + insIcoColor(pkg) + '">' + esc((a.label || '?').charAt(0).toUpperCase()) + '</div>';
}
/** Precarica: le icone di un elenco di pacchetti, in coda, senza disegnare niente. */
function insIconePrecarica(pkgs){ (pkgs || []).forEach(function(p){ if (p && INS_ICONE[p] === undefined) insIcona(p); }); }
/* la pagina salvata (fl_ins_cache_*) non si porta dietro le icone in base64: pesava centinaia di KB in localStorage */
function insSnapshotLeggero(html){
  return String(html || '').replace(/(<img class="ins-appimg" data-pkg="[^"]*") src="data:[^"]*"/g, '$1');
}
/* il vecchio nome resta: lo chiamano il Giorno e il ritorno alla scheda */
function insIconeMancanti(){ insIconeRiempi(document); }
document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') setTimeout(insIconeMancanti, 300); });
let INS_ICO_PRONTE = null;
function insIcoPronte(){ if (!INS_ICO_PRONTE) INS_ICO_PRONTE = insIcoApri().catch(function(){ }); return INS_ICO_PRONTE; }
insIcoPronte();

/** Le statistiche di navigazione sono accese? (pagina «Impostazioni» del Report) */
function insSitiOn(){
  const S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
  return S.statsOn !== false && S.statsWeb !== false;
}
/* Under a browser row: the sites of the period, from the service's own per-site clock. */
/* Aperto o chiuso resta come l'hai lasciato: di serie aperto, e' il motivo per cui le
   statistiche di navigazione si accendono. */
function insBrAperto(pkg){ try{ return localStorage.getItem('fl_br_chiuso_' + pkg) !== '1'; }catch(_){ return true; } }
function insToggleSites(pkg){
  const el = document.getElementById('sites-' + pkg);
  if (!el) return;
  if (!insSitiOn()){ toast('Accendi le statistiche di navigazione dalle impostazioni del Report'); return; }
  el.hidden = !el.hidden;
  const g = document.getElementById('grp-' + pkg);
  if (g){
    g.classList.toggle('on', !el.hidden);
    const r = g.querySelector('.ins-app'); if (r) r.setAttribute('aria-expanded', el.hidden ? 'false' : 'true');
  }
  try{ localStorage.setItem('fl_br_chiuso_' + pkg, el.hidden ? '1' : '0'); }catch(_){ }
  if (el.hidden || el.dataset.loaded) return;
  insCaricaSiti(el);
}
/* Riempie tutti i riquadri dei siti lasciati aperti dal disegno: una lettura sola, condivisa. */
function insSitiAuto(body){
  const box = body || document;
  box.querySelectorAll('.ins-sites:not([hidden])').forEach(el => { if (!el.dataset.loaded) insCaricaSiti(el); });
}
function insCaricaSiti(el){
  el.dataset.loaded = '1';
  const r = insRangeNow();
  el.innerHTML = '<div class="ins-sitelist"><div class="s"><span class="nm">Leggo i siti\u2026</span></div></div>';
  insGet('web:' + r.from + ':' + r.to + ':none', () => NATIVE.getWebTime({ from: r.from, to: r.to, bucket: 'none', limit: 8 }))
    .then(w => {
      const sites = (w && w.sites) || [];
      if (!sites.length){ el.innerHTML = '<div class="ins-sitenote">Nessun sito registrato in questo periodo. Il tempo per sito si misura mentre navighi, dalla barra degli indirizzi dei browser supportati.</div>'; return; }
      /* LA TESSERA CON L'INIZIALE, non la favicon. AppBlock la scarica da Google: per avere
         una miniatura manderebbe fuori l'elenco dei siti visitati, e la pagina Impostazioni
         promette il contrario. La tessera si disegna qui e non esce niente. */
      const pkg = String(el.id || '').replace(/^sites-/, '');
      el.innerHTML = '<div class="ins-sitelist">' + sites.slice(0, 6).map(x =>
          '<div class="s"><i style="background:' + insIcoColor(x.host || '?') + '">' + esc(String(x.host || '?').replace(/^www\./, '').charAt(0).toUpperCase()) + '</i>'
        + '<span class="nm">' + esc(String(x.host || '').replace(/^www\./, '')) + '</span><span class="tm">' + insFmt(x.ms) + '</span></div>').join('') + '</div>'
        + (pkg ? '<button type="button" class="ins-br-det" onclick="insOpenDetail(\'' + esc(pkg) + '\')">Dettagli dell\'app<span class="chev"></span></button>' : '');
    })
    .catch(e => { el.innerHTML = '<div class="ins-sitenote">Non sono riuscito a leggere i siti: ' + esc(insErr(e)) + '</div>'; });
}

/* The window the current view is looking at. */
function insRangeNow(){
  const now = Date.now();
  if (INS.view === 'giorno'){
    const from = insAddDays(insDayStart(now), -INS.dayOff);
    return { from: from, to: Math.min(now, insAddDays(from, 1)) };
  }
  if (INS.view === 'settimana'){
    const ws = insAddDays(insWeekStart(now), -7 * INS.weekOff);
    return { from: ws, to: Math.min(now, insAddDays(ws, 7)) };
  }
  return { from: insAddDays(insDayStart(now), -59), to: now };
}

/* ---------------------------------------------------------------------------------------
   G55 — DETTAGLIO DELLA SINGOLA APP
   --------------------------------------------------------------------------------------- */

function insDetailBack(){
  if (INS.detailFrom === 'blocco'){ INS.detailFrom = ''; try{ if (typeof scBlockScores === 'function') scBlockScores(); }catch(_){ } return 's-blocco'; }
  switchTab('insights'); return 's-home';
}
function insCloseDetail(){ goId(insDetailBack()); }

function insDetailSetView(v){ INS.detailView = v; if (INS.detail) insOpenDetail(INS.detail); }
function insDetailStep(dir){ INS.dayOff = Math.max(0, INS.dayOff - dir); INS.forceRender = true; if (INS.detail) insOpenDetail(INS.detail); }

async function insOpenDetail(pkg){
  INS.detail = pkg;
  goId('s-ins-app');
  const head = document.getElementById('insDetHead');
  const body = document.getElementById('insDetBody');
  body.innerHTML = '<div class="ins-load">Leggo i dati di questa app…</div>';

  const dayStart = insAddDays(insDayStart(Date.now()), -INS.dayOff);
  const dayEnd = Math.min(Date.now(), insAddDays(dayStart, 1));
  let label = pkg, ms = 0, blocked = false, icon = '';
  try{
    const top = await insGet('day:' + dayStart + ':t', () => NATIVE.getTopApps({ from: dayStart, to: dayEnd, limit: 50 }));
    const row = (top.apps || []).filter(a => a.packageName === pkg)[0];
    if (row){ label = row.label || pkg; ms = row.ms; blocked = !!row.blocked; icon = row.icon || ''; }
  }catch(e){}
  if (!icon) icon = insIconaSubito(pkg);
  if (!icon){ try{ icon = await insIcona(pkg); }catch(e){ icon = ''; } }
  if (!icon) icon = insSitoIcona(pkg);
  if (label === pkg && typeof ubAppLabel === 'function'){ try{ label = ubAppLabel(pkg) || pkg; }catch(e){} }

  head.innerHTML = insIcoHtml({ packageName: pkg, label: label, icon: icon })
    + '<b>' + esc(label) + '</b>';

  const cats = insCats();
  const cur = insCatsBase()[pkg];
  const ora = cats[pkg];
  const excl = insExcl().indexOf(pkg) >= 0;
  const v = INS.detailView || 'giorno';
  const tabs = '<div class="ins-tabs">'
    + ['giorno','settimana','tendenza'].map(k => '<button class="' + (v === k ? 'on' : '') + '" onclick="insDetailSetView(\'' + k + '\')">' + { giorno:'Giorno', settimana:'Settimana', tendenza:'Tendenza' }[k] + '</button>').join('')
    + '</div>';

  let html = tabs;
  if (v === 'giorno'){
      /* LE DUE FRECCE ERANO INVERTITE. `insDetailStep(dir)` fa `dayOff - dir`: per andare
         INDIETRO serve -1, e qui la freccia indietro chiamava +1, cioe' avanti — bloccata a
         oggi, quindi non faceva niente. Nella pagina del Report, con la stessa formula, era
         scritta giusta: da una parte si tornava indietro, dall'altra no. */
    html += '<div class="ins-per ins-per-left"><button class="ins-round" onclick="insDetailStep(-1)" aria-label="Giorno prima">' + INS_CHEV.sx + '</button><b>' + insDataPeriodo(dayStart, INS.dayOff).toUpperCase() + '</b><button class="ins-round" onclick="insDetailStep(1)" aria-label="Giorno dopo" ' + (INS.dayOff === 0 ? 'disabled' : '') + '>' + INS_CHEV.dx + '</button></div>'
      /* 0.9.307, Andrea: niente etichetta della categoria sopra al tempo. La sensazione dell'app sta solo nel
         pannello "Sensazione app" qui sotto, dove si sceglie. */
      + '<div class="ins-big">' + insFmt(ms) + '</div>'
      + '<div class="ins-lbl">TEMPO SULLO SCHERMO</div>'
      + '<div id="insDetChart"><div class="ins-load">Calcolo la distribuzione oraria…</div></div>'
      + '<div id="insDetChiamate"></div>';
  } else {
    html += '<div id="insDetChart"><div class="ins-load">Leggo i giorni…</div></div>';
  }
  html += '<div class="sect" style="margin-top:20px"><b>Sensazione app</b><span class="ins-sect-note">Questa app è per me…</span></div>'
    + insPickRow(pkg, cur)
    + insFasceHtml(pkg)
    + '<div class="ins-exrow"><span class="x">✕</span><div><b>Escludi questa app</b><small>L\'app non verrà conteggiata in nessuna statistica, tempo sullo schermo o nel report settimanale.</small></div>'
    + '<button class="switch' + (excl ? ' on' : '') + '" onclick="insToggleExcluded(\'' + esc(pkg) + '\')"></button></div>'
    + '<button class="cta" style="margin-top:14px" onclick="insAddToBlock(\'' + esc(pkg) + '\')">Aggiungere al blocco</button>'
    + (blocked ? '<p class="ins-sub" style="text-align:center;margin-top:8px">Già nel Blocco rapido.</p>' : '')
    + '<div class="spacer"></div>';
  body.innerHTML = html;

  if (v === 'giorno') insDetailChart(pkg, dayStart, dayEnd);
  else if (v === 'settimana') insDetailWeek(pkg);
  else insDetailTrend(pkg);
  if (v === 'giorno') insDetChiamate(pkg);
}

/* 0.9.307, IL TEMPO DELLE CHIAMATE (Chiamate.java). Nella pagina dell'app telefono, solo nell'app scaricata dal
   sito (il Play Store non concede il registro chiamate) e solo finche' il permesso non c'e': un pulsante che lo
   chiede, con il perche' in una riga. Le chiamate da oggi in poi si contano comunque, senza permessi. */
let INS_CHIAMATE = null;
async function insChiamateStato(forza){
  if (INS_CHIAMATE && !forza) return INS_CHIAMATE;
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.chiamateStato !== 'function') return null;
  try{ INS_CHIAMATE = await NATIVE.chiamateStato(); }catch(_){ INS_CHIAMATE = null; }
  return INS_CHIAMATE;
}
function insEAppTelefono(pkg, st){
  return !!pkg && ((st && st.dialer === pkg) || INS_TELEFONO.test(pkg));
}
async function insDetChiamate(pkg){
  const st = await insChiamateStato(false);
  const box = document.getElementById('insDetChiamate');
  if (!box || INS.detail !== pkg) return;
  if (!st || !st.registro || st.permesso || !insEAppTelefono(pkg, st)){ box.innerHTML = ''; return; }
  box.innerHTML = '<div class="ins-chiam">'
    + '<p>Con il telefono all\u2019orecchio lo schermo si spegne e quei minuti si perdono. Dal registro chiamate DreamMap legge solo ora e durata, anche dei giorni passati.</p>'
    + '<button type="button" class="ins-chiam-btn" onclick="insChiamatePermesso(\'' + esc(pkg) + '\')">Conta tutto il tempo delle chiamate</button>'
    + '</div>';
}
async function insChiamatePermesso(pkg){
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.chiamatePermesso !== 'function') return;
  try{
    INS_CHIAMATE = await NATIVE.chiamatePermesso();
    if (typeof INS_CACHE !== 'undefined' && INS_CACHE.clear) INS_CACHE.clear();
    INS.forceRender = true;
    if (typeof toast === 'function') toast('Fatto: il tempo delle chiamate adesso si conta tutto');
    insOpenDetail(pkg);
  }catch(e){
    if (typeof toast === 'function') toast('Senza il registro chiamate DreamMap conta le chiamate da oggi in poi');
  }
}

/* Seven daily bars for this one app: one usage query per day, cached like the rest. */
async function insDetailWeek(pkg){
  const holder = document.getElementById('insDetChart');
  if (!holder) return;
  const ws = insWeekStart(Date.now());
  const now = Date.now();
  const days = new Array(7).fill(0);
  let total = 0;
  for (let i = 0; i < 7; i++){
    const s = insAddDays(ws, i), e = Math.min(now, insAddDays(ws, i + 1));
    if (e <= s) continue;
    let apps = [];
    try{ apps = (await insGet('dayapps:' + s, () => NATIVE.getTopApps({ from: s, to: e, limit: 60, icons: 0 }))).apps || []; }catch(err){ apps = []; }
    const row = apps.filter(a => a.packageName === pkg)[0];
    if (row){ days[i] = row.ms; total += row.ms; }
  }
  if (INS.detail !== pkg || INS.detailView !== 'settimana') return;
  const max = insCeil(Math.max.apply(null, days.concat([0])));
  let cols = '';
  for (let i = 0; i < 7; i++) cols += insColumn(days[i], max, null);
  const axis = '<div class="ins-x">' + INS_DOW.map(d => '<span>' + d + '</span>').join('') + '</div>';
  holder.innerHTML = '<div class="ins-per"><b>QUESTA SETTIMANA</b></div>'
    + '<div class="ins-big">' + insFmt(total) + '</div><div class="ins-lbl">TEMPO SULLO SCHERMO</div>'
    + insPlot('<div class="chart ins-week">' + cols + '</div>', max, axis);
}

/* Four weekly totals for this app: the direction, not the detail. */
async function insDetailTrend(pkg){
  const holder = document.getElementById('insDetChart');
  if (!holder) return;
  const now = Date.now();
  const thisWs = insWeekStart(now);
  const weeks = [];
  for (let w = 3; w >= 0; w--){
    const s = insAddDays(thisWs, -7 * w), e = Math.min(now, insAddDays(s, 7));
    let ms = 0;
    if (e > s){
      let apps = [];
      try{ apps = (await insGet('wkapps:' + s, () => NATIVE.getTopApps({ from: s, to: e, limit: 60, icons: 0 }))).apps || []; }catch(err){ apps = []; }
      const row = apps.filter(a => a.packageName === pkg)[0];
      if (row) ms = row.ms;
    }
    weeks.push({ s: s, ms: ms });
  }
  if (INS.detail !== pkg || INS.detailView !== 'tendenza') return;
  const max = insCeil(Math.max.apply(null, weeks.map(w => w.ms).concat([0])));
  const last = weeks[3].ms, prev = weeks[2].ms;
  const diff = last - prev;
  let cols = '';
  weeks.forEach(w => { cols += insColumn(w.ms, max, null); });
  const axis = '<div class="ins-x">' + weeks.map(w => '<span>' + insDateLabel(w.s).slice(0, 5) + '</span>').join('') + '</div>';
  holder.innerHTML = '<div class="ins-per"><b>ULTIME 4 SETTIMANE</b></div>'
    + '<div class="ins-big" style="color:' + (diff <= 0 ? '#0E7C6B' : 'var(--red)') + '">' + (diff <= 0 ? '-' : '+') + insFmt(Math.abs(diff)) + '</div>'
    + '<div class="ins-lbl">' + (diff <= 0 ? 'MENO' : 'PIÙ') + ' DELLA SETTIMANA PRIMA</div>'
    + insPlot('<div class="chart ins-week">' + cols + '</div>', max, axis);
}

/* AppBlock's popover: every program with a box, the quick block first, a new-program button
   and Salva. Saving writes the app into the chosen programs through the same path the
   Blocco tab uses, so the engine hears about it at once. */
let INS_ADD = { pkg: null };
function insAddToBlock(pkg){
  INS_ADD.pkg = pkg;
  let sw = document.getElementById('insAddSheet');
  if (!sw){
    sw = registerOverlay('insAddSheet', '<div class="blk-scrim"></div><div class="blk-sheet"><div class="grab"></div><h3>Aggiungere al blocco</h3>'
      + '<div class="ins-addlist" id="insAddList"></div>'
      + '<button class="ghost" style="width:100%;margin-top:8px" onclick="insAddNewProgram()">+ Nuovo programma</button>'
      + '<button class="cta" style="margin-top:10px" onclick="insAddSave()">Salva</button></div>');
    sw.className = 'blk-sw';
    sw.querySelector('.blk-scrim').addEventListener('click', insAddClose);
  }
  const list = document.getElementById('insAddList');
  const progs = (typeof PROGRAMS !== 'undefined') ? PROGRAMS : [];
  const quickHas = (typeof QUICK !== 'undefined') && (QUICK.apps || []).indexOf(pkg) >= 0;
  let html = '<label class="ins-addrow"><span class="ic">⏱</span><div><b>Blocco rapido</b><small>' + ((typeof EXTRA !== 'undefined' && EXTRA.enabled) ? 'Attiva' : 'Inattivo') + '</small></div>'
    + '<input type="checkbox" data-k="quick"' + (quickHas ? ' checked' : '') + '></label>';
  progs.forEach(function(p, i){
    const has = (p.apps || []).indexOf(pkg) >= 0;
    html += '<label class="ins-addrow"><span class="ic">' + esc(p.icon || '🚫') + '</span><div><b>' + esc(p.name || 'Programma') + '</b>'
      + '<small class="' + (p.on === false ? 'off' : 'on') + '">' + (p.on === false ? 'Inattivo' : 'Attiva') + '</small></div>'
      + '<input type="checkbox" data-k="' + i + '"' + (has ? ' checked' : '') + '></label>';
  });
  if (!progs.length) html += '<p class="ins-sub" style="padding:6px 2px">Non hai ancora programmi: il Blocco rapido, oppure creane uno nuovo.</p>';
  list.innerHTML = html;
  sw.classList.add('open');
}
function insAddClose(){ const sw = document.getElementById('insAddSheet'); if (sw) sw.classList.remove('open'); }
async function insAddSave(){
  const pkg = INS_ADD.pkg;
  if (!pkg) return;
  const boxes = Array.prototype.slice.call(document.querySelectorAll('#insAddList input[type=checkbox]'));
  let changed = 0, quickChange = null;
  boxes.forEach(function(b){
    const k = b.getAttribute('data-k');
    if (k === 'quick'){ quickChange = b.checked; return; }
    const p = (typeof PROGRAMS !== 'undefined') ? PROGRAMS[+k] : null;
    if (!p) return;
    p.apps = p.apps || [];
    const has = p.apps.indexOf(pkg) >= 0;
    if (b.checked && !has){ p.apps.push(pkg); changed++; }
    if (!b.checked && has){ p.apps = p.apps.filter(a => a !== pkg); changed++; }
  });
  try{
    if (quickChange !== null && NATIVE){
      const quickHas = (typeof QUICK !== 'undefined') && (QUICK.apps || []).indexOf(pkg) >= 0;
      if (quickChange && !quickHas && NATIVE.blockApp){ await NATIVE.blockApp({ packageName: pkg }); changed++; }
      if (!quickChange && quickHas && NATIVE.unblockApp){ await NATIVE.unblockApp({ packageName: pkg }); changed++; }
      if (typeof loadQuick === 'function') await loadQuick();
    }
    if (changed && typeof pushRules === 'function') await pushRules();
    if (typeof renderPrograms === 'function') renderPrograms();
  }catch(e){ toast(insErr(e)); return; }
  insAddClose();
  INS_CACHE.clear();
  toast(changed ? 'Blocco aggiornato' : 'Nessuna modifica');
  insOpenDetail(pkg);
}
/* A fresh program with this app already in its list: the editor opens as from the Blocco tab. */
function insAddNewProgram(){
  const pkg = INS_ADD.pkg;
  insAddClose();
  if (typeof pickType !== 'function'){ toast('Disponibile dalla scheda Blocco'); return; }
  pickType('sempre');
  if (typeof DRAFT !== 'undefined' && DRAFT){ DRAFT.apps = [pkg]; if (typeof refreshEditorCounts === 'function') refreshEditorCounts(); if (typeof paintWhatLabel === 'function') paintWhatLabel(); }
}

function insPickRow(pkg, cur){
  return '<div class="ins-3">' + ['distr','neutro','prod'].map(k =>
      '<div class="ins-pick' + (cur === k ? ' on' : '') + '" onclick="insPick(\'' + esc(pkg) + '\',\'' + k + '\')">'
    + '<div class="face" style="background:' + INS_CAT[k].color + '">' + insFaccia(k) + '</div>'
    + '<b>' + INS_CAT[k].label + '</b></div>').join('') + '</div>';
}
/* Picking a category repaints whichever surface the user picked it from: the full-screen
   categoriser advances, the detail screen redraws, the section behind them re-renders. */
function insFasceHtml(pkg){
  const l = insFasce()[pkg] || [];
  const ora = insFasciaCat(l, Date.now());
  return '<div class="ins-fasce"><div class="ins-fasce-h"><b>Dipende dall’ora</b><small>La stessa app può distrarti la mattina ed esserti utile mentre lavori o guidi: con un podcast di marketing nelle orecchie, YouTube vale più della radio.</small></div>'
    + l.map(function(f, i){ const c = INS_CAT[f.cat] || INS_CAT.neutro; return '<div class="ins-fascia"><span class="dot" style="background:' + c.color + '"></span><b>Dalle ' + esc(f.da) + ' alle ' + esc(f.a) + '</b><em style="color:' + c.color + '">' + c.label + '</em><button type="button" onclick="insFasciaVia(\'' + esc(pkg) + '\',' + i + ')" aria-label="Togli la fascia">✕</button></div>'; }).join('')
    + (l.length ? '<p class="ins-fasce-ora">' + (ora ? 'A quest’ora l’app conta come <b>' + INS_CAT[ora].label.toLowerCase() + '</b>.' : 'A quest’ora vale la categoria di sempre.') + '</p>' : '')
    + '<button type="button" class="ghostmini ins-fasce-piu" onclick="insFasciaNuova(\'' + esc(pkg) + '\')">＋ Aggiungi una fascia oraria</button></div>';
}
const INS_FN = { cat: 'prod' };
function insFasciaNuova(pkg){
  if (typeof inSheet !== 'function') return;
  INS_FN.pkg = pkg; INS_FN.cat = 'prod';
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3 class="fr-agg-h">Una fascia oraria</h3>'
    + '<p class="ins-fn-p">In questa fascia l’app conta in un altro modo: per esempio produttiva dalle 8 alle 18, mentre lavori o guidi.</p>'
    + '<div class="ins-fn-ore"><label><small>Dalle</small><input class="fin" type="time" id="insFnDa" value="08:00" onclick="try{this.showPicker()}catch(_){}"></label><label><small>Alle</small><input class="fin" type="time" id="insFnA" value="18:00" onclick="try{this.showPicker()}catch(_){}"></label></div>'
    + '<p class="ins-fn-l">In questa fascia conta come</p><div class="ins-3" id="insFnCat">' + insFnCatHtml() + '</div>'
    + '<button type="button" class="cta" style="width:100%;margin-top:18px" onclick="insFasciaSalva()">Salva la fascia</button></div>');
}
function insFnCatHtml(){
  return ['distr', 'neutro', 'prod'].map(function(k){ return '<div class="ins-pick' + (INS_FN.cat === k ? ' on' : '') + '" onclick="INS_FN.cat=\'' + k + '\';document.getElementById(\'insFnCat\').innerHTML=insFnCatHtml()"><div class="face" style="background:' + INS_CAT[k].color + '">' + insFaccia(k) + '</div><b>' + INS_CAT[k].label + '</b></div>'; }).join('');
}
function insFasciaSalva(){
  const da = (document.getElementById('insFnDa') || {}).value, a = (document.getElementById('insFnA') || {}).value;
  if (!da || !a || da === a){ toast('Scegli un’ora d’inizio e una di fine diverse'); return; }
  const l = (insFasce()[INS_FN.pkg] || []).concat([{ da: da, a: a, cat: INS_FN.cat }]);
  insSetFasce(INS_FN.pkg, l);
  try{ inSheetChiudi(); }catch(_){ }
  INS_CACHE.delete('hourapps:' + insAddDays(insDayStart(Date.now()), -INS.dayOff));
  toast('Dalle ' + da + ' alle ' + a + ': ' + INS_CAT[INS_FN.cat].label.toLowerCase());
  insOpenDetail(INS_FN.pkg);
}
function insFasciaVia(pkg, i){
  const l = (insFasce()[pkg] || []).slice(); l.splice(i, 1);
  insSetFasce(pkg, l);
  INS_CACHE.delete('hourapps:' + insAddDays(insDayStart(Date.now()), -INS.dayOff));
  insOpenDetail(pkg);
}
function insPick(pkg, cat){
  const current = insCatsBase()[pkg];
  insSetCat(pkg, current === cat ? null : cat);
  // The cached per-hour breakdown is keyed by day, not by category: only the colouring changes,
  // but the split is computed from it, so it has to be recomputed.
  INS_CACHE.delete('hourapps:' + insAddDays(insDayStart(Date.now()), -INS.dayOff));
  const sorter = document.getElementById('s-ins-cat');
  if (sorter && sorter.classList.contains('active')){ insCatRender(); return; }
  toast(current === cat ? 'Categoria rimossa' : 'Segnata come ' + INS_CAT[cat].label.toLowerCase());
  const detail = document.getElementById('s-ins-app');
  if (detail && detail.classList.contains('active') && INS.detail === pkg){ insOpenDetail(pkg); return; }
  INS.forceRender = true;
  insRender();
}
function insToggleExcluded(pkg){
  const now = insToggleExcl(pkg);
  toast(now ? 'Esclusa dal Report' : 'Reinserita nel Report');
  INS.forceRender = true;
  insOpenDetail(pkg);
}
async function insBlockApp(pkg){
  if (!NATIVE || !NATIVE.blockApp){ toast('Disponibile solo nell\'app installata'); return; }
  try{
    await NATIVE.blockApp({ packageName: pkg });
    toast('Aggiunta alla lista di blocco');
    INS_CACHE.clear();
    insOpenDetail(pkg);
  }catch(e){
    // A rejected plugin call must say what happened: under Modalità severa the engine refuses
    // and its message is already in Italian.
    toast(insErr(e));
  }
}

/* The app's own hour-by-hour day. Reuses the per-hour breakdown the day view may already have
   fetched; otherwise fetches it here, once, for the hours that had any usage at all. */
async function insDetailChart(pkg, dayStart, dayEnd){
  const holder = document.getElementById('insDetChart');
  if (!holder) return;
  let hours;
  try{
    const range = await insGet('day:' + dayStart + ':h', () => NATIVE.getScreenTimeRange({ from: dayStart, to: dayEnd, bucket: 'hour' }));
    hours = new Array(24).fill(0);
    (range.buckets || []).forEach(b => { hours[new Date(b.start).getHours()] += b.ms; });
  }catch(e){ holder.innerHTML = insNote('Distribuzione oraria non disponibile: ' + insErr(e)); return; }

  /* 0.9.353: la stessa divisione per ora del grafico del Report (una lettura della cronologia, per sorgente) */
  let per = insOreRicordo(dayStart);
  if (!per){
    per = (await insPerOraLeggi(null, dayStart, hours)) || {};
    INS_ORE_MEM.set(insOreChiave(dayStart), { t: Date.now(), per: per });
  }
  if (INS.detail !== pkg) return;

  const mine = new Array(24).fill(0);
  let any = false;
  for (let h = 0; h < 24; h++){
    const row = (per[h] || []).filter(a => a.packageName === pkg)[0];
    if (row){ mine[h] = row.ms; any = true; }
  }
  if (!any){
    // Under a minute in every hour is not zero: getTopApps drops those rows, and saying "0"
    // would be a number the engine never produced.
    holder.innerHTML = insNote('In nessuna singola ora questa app ha superato il minuto: il motore non attribuisce quel tempo ora per ora.');
    return;
  }
  const max = insCeil(Math.max.apply(null, mine));
  let cols = '';
  for (let h = 0; h < 24; h++) cols += insColumn(mine[h], max, null);
  holder.innerHTML = insPlot('<div class="chart ins-hours">' + cols + '</div>', max, insHourAxis()).replace('class="ins-plot"', 'class="ins-plot right"');
}

/* ---------------------------------------------------------------------------------------
   G45 — "QUESTA APP È PER ME…" A TUTTO SCHERMO / ORDINA APP
   --------------------------------------------------------------------------------------- */

let INS_SORT = { queue: [], i: 0, from: 's-home', tab: 'insights' };

/* indietro (o la X) riporta alla scheda da cui si e' partiti: il Report, o START per chi
   arriva dal riscaldamento */
function insCatBackTarget(){ if (INS_SORT.from === 's-home') switchTab(INS_SORT.tab || 'insights'); return INS_SORT.from; }
function insCatClose(){ goId(insCatBackTarget()); }

/* LE CARTE SI PREPARANO PRIMA: la lista delle app la si chiede al motore appena si apre il
   Report (e all'avvio), cosi' la pagina si apre subito invece di aspettare la risposta. */
async function insSortPrefetch(){
  if (!NATIVE || !NATIVE.getTopApps) return null;
  const to = Date.now(), from = insAddDays(insDayStart(to), -6);
  try{ return await insGet('sort7', () => NATIVE.getTopApps({ from: from, to: to, limit: 40 })); }catch(_){ return null; }
}
document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') insSortPrefetch(); });
document.addEventListener('DOMContentLoaded', function(){ setTimeout(insSortPrefetch, 6000); });
async function insSortApps(tab){
  if (!NATIVE){ toast('Disponibile solo nell\'app installata'); return; }
  INS_SORT.from = 's-home'; INS_SORT.tab = tab || 'insights';
  /* la pagina si apre SUBITO, con quello che c'e'; la lista arriva un attimo dopo se manca */
  goId('s-ins-cat');
  const box = document.getElementById('insCatBody'); if (box && !INS_SORT.queue.length) box.innerHTML = '<div class="ic-fine"><p>Leggo le tue app…</p></div>';
  let apps = [];
  try{
    const r = await insSortPrefetch();
    apps = ((r && r.apps) || []).filter(a => !a.self);
  }catch(e){ toast(insErr(e)); return; }
  /* 0.9.268, Andrea: sul computer getTopApps non c'e' e il pannello diceva "il motore non ha ancora dati", mentre
     programmi e siti del PC stanno nei report dei giorni (quelli di "App piu' usate"). Si sommano gli ultimi sette
     giorni e si ordinano quelli: la categoria scelta (fl_ins_cat) vale anche per il Report del computer. */
  /* 0.9.272, Andrea: nella versione PC "Questa app e' per me…" mostrava One UI Home, cioe' le app del TELEFONO.
     Sul computer il Report del giorno e' quello pubblicato dal telefono, e il pannello sommava quello. I programmi e
     i siti del PC li sa il PC: la sua cronologia (getTimeline, la stessa della pagina Timeline) degli ultimi sette
     giorni, sommata per programma o sito. Il telefono qui non entra piu'. */
  const suPc = (function(){ try{ return !!(window.chrome && window.chrome.webview); }catch(_){ return false; } })();
  if (!apps.length && suPc && NATIVE.getTimeline){
    const a7 = Date.now(), da7 = insAddDays(insDayStart(a7), -6);
    let d = null;
    try{ d = await NATIVE.getTimeline({ from: da7, to: a7, minMs: 0, limit: 30000 }); }catch(_){ d = null; }
    const agg = {};
    ((d && d.grani) || []).forEach(function(x){
      if (!x || !x.p) return;
      const k = String(x.p);
      if (/dreambrothers|focuslock|dreammap/i.test(k) || /^(dreammap|focuslock)$/i.test(String(x.l || ''))) return;
      /* lo schermo bloccato e il computer fermo non sono un programma */
      if (/^(idle|lock|locked|inattivo|schermo bloccato|lockapp(\.exe)?|searchhost(\.exe)?|shellexperiencehost(\.exe)?)$/i.test(k)) return;
      if (!agg[k]) agg[k] = { packageName: k, label: x.l || k, ms: 0 };
      agg[k].ms += x.ms || 0;
    });
    apps = Object.keys(agg).map(function(k){ return agg[k]; }).filter(function(a){ return a.ms >= 60000; })
      .sort(function(a, b){ return b.ms - a.ms; }).slice(0, 40);
  }
  if (!apps.length && !suPc && typeof scReport === 'function'){
    const agg = {};
    for (let i = 0; i < 7; i++){
      let r = null; try{ r = await scReport(i); }catch(_){ r = null; }
      ((r && r.top) || []).forEach(function(a){
        if (!a || !a.packageName || a.self) return;
        const k = a.packageName;
        /* l'app stessa (sul telefono il pacchetto, sul computer il programma DreamMap/FocusLock) non si ordina */
        if (/dreambrothers|focuslock|dreammap/i.test(k) || /^(dreammap|focuslock)$/i.test(String(a.label || ''))) return;
        if (!agg[k]) agg[k] = { packageName: k, label: a.label || k, ms: 0, launcher: !!a.launcher };
        agg[k].ms += a.ms || 0;
      });
    }
    apps = Object.keys(agg).map(function(k){ return agg[k]; }).filter(function(a){ return !a.launcher && a.ms > 0; })
      .sort(function(a, b){ return b.ms - a.ms; }).slice(0, 40);
  }
  if (!apps.length){ toast('Nessuna app da ordinare: il motore non ha ancora dati'); insCatClose(); return; }
  /* SOLO QUELLE DA FARE. Chi ne ha gia' etichettate venti non ricomincia dalla prima: vede le
     mancanti. Se non ne manca nessuna, il giro e' una revisione e le mostra tutte. */
  const cats = insCats();
  const daFare = apps.filter(a => !cats[a.packageName]);
  INS_SORT.revisione = !daFare.length;
  INS_SORT.queue = daFare.length ? daFare : apps;
  INS_SORT.i = 0;
  insCatRender();
}
/* LE CARTE (0.9.177). Una carta per app, come su Tinder: si trascina a destra e diventa verde
   (produttiva), a sinistra e diventa rossa (distrattiva); i tre tondi sotto fanno lo stesso
   senza trascinare, e il neutro sta in mezzo. Dietro alla carta si vede gia' la prossima. */
const INS_CAT_COL = { prod: '#0075E3', distr: '#E63946', neutro: '#8CC6FF' };
/* 0.9.276, Andrea: sul PC i siti nel riordino avevano solo una lettera. Un sito ha la sua icona (favicon);
   un programma la chiede al ponte del PC (getAppIcon, DesktopApps.IconJson). */
/* 0.9.278, Andrea: "Claude non ha l'immagine, Shopify e' pixelata, accounts.shopify.com e' tutta sgranata".
   Tre cause: le app del PC (Claude, Spotify...) non hanno un dominio; i sottodomini (accounts.) spesso non hanno
   un'icona propria e Google restituisce il globo sfocato; e un'icona da 16px stirata a 96 si vede a quadretti.
   Rimedio: nome dell'app -> il suo sito; prima il dominio principale; e se l'immagine arrivata e' piccola si
   prova la fonte dopo, fino alla lettera colorata. Mai un'icona sgranata a schermo. */
const INS_APP_SITI = { claude: 'claude.ai', chatgpt: 'chatgpt.com', chrome: 'google.com', 'google chrome': 'google.com', msedge: 'microsoft.com', edge: 'microsoft.com', firefox: 'firefox.com',
  spotify: 'spotify.com', discord: 'discord.com', telegram: 'telegram.org', whatsapp: 'whatsapp.com', slack: 'slack.com', notion: 'notion.so', figma: 'figma.com', zoom: 'zoom.us', teams: 'microsoft.com',
  code: 'code.visualstudio.com', 'visual studio code': 'code.visualstudio.com', capcut: 'capcut.com', resolve: 'blackmagicdesign.com', 'davinci resolve': 'blackmagicdesign.com', photoshop: 'adobe.com', premiere: 'adobe.com',
  steam: 'steampowered.com', obs: 'obsproject.com', 'obs studio': 'obsproject.com', canva: 'canva.com', netflix: 'netflix.com', youtube: 'youtube.com', instagram: 'instagram.com', tiktok: 'tiktok.com', excel: 'microsoft.com', word: 'microsoft.com', outlook: 'microsoft.com' };
function insDominioBase(n){
  const p = n.split('.'); if (p.length <= 2) return n;
  const due = p.slice(-2).join('.');
  return /^(co|com|org|net|gov|ac)\.[a-z]{2}$/.test(due) ? p.slice(-3).join('.') : due;
}
function insIconeFonti(nome, label){
  const out = [];
  const g = function(d){ return 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(d) + '&sz=128'; };
  [nome, label].forEach(function(v){
    let n = String(v || '').trim().toLowerCase().replace(/\.exe$/, '');
    const app = INS_APP_SITI[n] || INS_APP_SITI[n.split(/[\s.]/)[0]];
    if (app){ out.push(g(app)); return; }
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(n) || /\.app$/.test(n)) return;
    const base = insDominioBase(n);
    if (base !== n) out.push(g(base));
    out.push(g(n), 'https://icons.duckduckgo.com/ip3/' + base + '.ico');
  });
  return out.filter(function(u, i){ return out.indexOf(u) === i; });
}
function insSitoIcona(nome){ return insIconeFonti(nome)[0] || ''; }
/* un'icona sotto i 48px si vede sgranata: si passa alla fonte dopo, poi alla lettera */
function insIcoProva(img){
  if (img.naturalWidth >= 48) { img.style.visibility = ''; return; }
  insIcoSucc(img);
}
function insIcoSucc(img){
  const l = (img.dataset.fonti || '').split('|').filter(Boolean);
  if (l.length){ img.dataset.fonti = l.slice(1).join('|'); img.src = l[0]; return; }
  const sp = document.createElement('span'); sp.className = 'ic-lettera'; sp.style.background = img.dataset.col || '#0075E3'; sp.textContent = img.dataset.l || '?';
  img.replaceWith(sp);
}
function insIcoImg(src, fonti, col, lettera){
  return '<img src="' + src + '" alt="" style="visibility:hidden" data-fonti="' + esc(fonti.join('|')) + '" data-col="' + col + '" data-l="' + esc(lettera) + '" onload="insIcoProva(this)" onerror="insIcoSucc(this)">';
}
function insCatCardHtml(a, dietro){
  const lett = (a.label || '?').charAt(0).toUpperCase(), col = insIcoColor(a.packageName);
  let ico;
  if (a.icon && a.icon.indexOf('data:') === 0) ico = '<img src="' + a.icon + '" alt="">';
  else {
    const f = insIconeFonti(a.packageName, a.label);
    ico = f.length ? insIcoImg(f[0], f.slice(1), col, lett) : '<span class="ic-lettera" style="background:' + col + '">' + esc(lett) + '</span>';
  }
  return '<div class="ic-card' + (dietro ? ' dietro' : '') + '" data-pkg="' + esc(a.packageName) + '">'
    + '<div class="ic-ico">' + ico + '</div>'
    + '<b>' + esc(a.label || a.packageName) + '</b>'
    + '<small>' + insFmt(a.ms) + ' negli ultimi 7 giorni</small>'
    + '<span class="ic-tag prod">Produttiva</span><span class="ic-tag distr">Distrattiva</span>'
    + '</div>';
}
async function insCatIcona(a){
  if (!a || a.icon || !NATIVE || !NATIVE.getAppIcon) return;
  try{ const r = await NATIVE.getAppIcon({ packageName: a.packageName }); if (r && r.icon && String(r.icon).indexOf('data:') === 0){ a.icon = r.icon; const el = document.querySelector('.ic-card[data-pkg="' + CSS.escape(a.packageName) + '"] .ic-ico'); if (el) el.innerHTML = '<img src="' + a.icon + '" alt="">'; } }catch(_){ }
}
function insCatRender(){
  const box = document.getElementById('insCatBody');
  const a = INS_SORT.queue[INS_SORT.i];
  if (!a){
    box.innerHTML = '<div class="ic-fine"><div class="ic-fine-ico">✅</div><h3>Hai ordinato tutto</h3><p>Da adesso i numeri del Report parlano di te.</p>'
      + '<button type="button" class="cta" onclick="insCatClose()">Ho finito</button>'
      + '<button type="button" class="ic-escludi" onclick="INS_SORT.queue=[];insSortApps(INS_SORT.tab)">Rivedi tutte le etichette</button></div>';
    return;
  }
  const dietro = INS_SORT.queue[INS_SORT.i + 1];
  const cur = insCats()[a.packageName];
  const excl = insExcl().indexOf(a.packageName) >= 0;
  box.innerHTML = '<div class="ic-mazzo" id="icMazzo">' + (dietro ? insCatCardHtml(dietro, true) : '') + insCatCardHtml(a, false) + '</div>'
    + '<div class="ic-tondi">'
    +   '<button type="button" class="ic-tondo distr' + (cur === 'distr' ? ' on' : '') + '" onclick="insCatScegli(\'distr\')"><span>' + insFaccia('distr') + '</span><small>Distrattiva</small></button>'
    +   '<button type="button" class="ic-tondo neutro' + (cur === 'neutro' ? ' on' : '') + '" onclick="insCatScegli(\'neutro\')"><span>' + insFaccia('neutro') + '</span><small>Neutrale</small></button>'
    +   '<button type="button" class="ic-tondo prod' + (cur === 'prod' ? ' on' : '') + '" onclick="insCatScegli(\'prod\')"><span>' + insFaccia('prod') + '</span><small>Produttiva</small></button>'
    + '</div>'
    + '<button type="button" class="ic-escludi" onclick="insCatExclude(\'' + esc(a.packageName) + '\')">' + (excl ? '↺ Rimetti nel Report' : '✕ Escludi dal Report') + '</button>'
    + '<div class="ic-conta">' + (INS_SORT.i + 1) + ' di ' + INS_SORT.queue.length + '</div>';
  insCatTrascina();
  insCatIcona(a); if (dietro) insCatIcona(dietro);
}
/* la scelta: si segna, la carta vola via, arriva la prossima */
function insCatScegli(cat){
  const a = INS_SORT.queue[INS_SORT.i]; if (!a) return;
  insSetCat(a.packageName, cat);
  INS_CACHE.delete('hourapps:' + insAddDays(insDayStart(Date.now()), -INS.dayOff));
  try{ flVibra(14); }catch(_){ }
  const card = document.querySelector('#icMazzo .ic-card:not(.dietro)');
  if (card){
    card.classList.add(cat === 'prod' ? 'prod' : (cat === 'distr' ? 'distr' : 'neutro'));
    card.style.transition = 'transform .32s ease-in, opacity .32s';
    card.style.transform = 'translateX(' + (cat === 'prod' ? '130%' : (cat === 'distr' ? '-130%' : '0')) + ') rotate(' + (cat === 'prod' ? '18deg' : (cat === 'distr' ? '-18deg' : '0')) + ')' + (cat === 'neutro' ? ' scale(.8)' : '');
    card.style.opacity = '0';
  }
  setTimeout(function(){ INS_SORT.i++; insCatRender(); }, 300);
}
function insCatNext(){ INS_SORT.i++; insCatRender(); }
function insCatExclude(pkg){ insToggleExcl(pkg); insCatRender(); }
/* il trascinamento: oltre un terzo della larghezza decide, sotto torna al centro */
function insCatTrascina(){
  const card = document.querySelector('#icMazzo .ic-card:not(.dietro)'); if (!card) return;
  let x0 = 0, dx = 0, giu = false;
  const soglia = Math.max(90, card.offsetWidth * 0.33);
  const muovi = function(e){
    if (!giu) return;
    dx = (e.clientX || 0) - x0;
    card.style.transition = 'none';
    card.style.transform = 'translateX(' + dx + 'px) rotate(' + (dx / 14) + 'deg)';
    card.classList.toggle('prod', dx > 40); card.classList.toggle('distr', dx < -40);
  };
  const fine = function(){
    if (!giu) return; giu = false;
    card.releasePointerCapture && card.releasePointerCapture(fine.pid);
    if (dx > soglia) insCatScegli('prod');
    else if (dx < -soglia) insCatScegli('distr');
    else { card.style.transition = 'transform .25s ease'; card.style.transform = ''; card.classList.remove('prod', 'distr'); }
    dx = 0;
  };
  card.addEventListener('pointerdown', function(e){ giu = true; x0 = e.clientX; fine.pid = e.pointerId; try{ card.setPointerCapture(e.pointerId); }catch(_){ } });
  card.addEventListener('pointermove', muovi);
  card.addEventListener('pointerup', fine);
  card.addEventListener('pointercancel', fine);
}


/* ===========================================================================================
   LO STILE DELLE CARD DEL MODELLO (giro 0.9.113)
   =========================================================================================== */
function insStileTesta(){
  if (document.getElementById('insTestaSt')) return;
  const st = document.createElement('style'); st.id = 'insTestaSt';
  st.textContent = '.home-head .ins-head-top{position:absolute;left:0;right:0;top:0;bottom:0;padding:0 18px;margin:0;display:flex;align-items:center;pointer-events:none;z-index:7}'
    + '.home-head .ins-head-top[hidden]{display:none}.home-head .ins-head-top > button{pointer-events:auto}.home-head .ins-head-top .ins-menu{pointer-events:auto;top:54px;right:14px}'
    + '#tab-insights .ins-sticky{padding-top:6px}';
  document.head.appendChild(st);
}
insStileTesta();
(function insStileModello(){
  const st = document.createElement('style');
  st.textContent = [
    /* il grafico con la fetta scelta in evidenza */
    '.ins-hours .col i.dim,.ins-week .col i.dim{background:rgba(120,140,170,.28)}',
    '.ins-hours .col i.hi,.ins-week .col i.hi{background:linear-gradient(180deg,var(--sky),var(--blue))}',

    /* il cartello «Segna o escludi» */
    '.ins-promo{position:relative;display:flex;align-items:center;gap:14px;background:#151A26;',
      'border-radius:22px;padding:20px 44px 20px 18px;margin:18px 0 22px}',
    '.ins-promo-t{flex:1;min-width:0}',
    '.ins-promo-t p{margin:0 0 14px;font:800 15px/1.3 var(--font-display);color:#fff}',
    /* «ordina», non «go»: `.go` in app.css e' la freccia a maschera e trasformava il bottone
       in un chevron senza testo. */
    '.ins-promo-t .ordina{border:0;background:var(--blue);color:#fff;border-radius:99px;padding:10px 18px;',
      'font:700 13px var(--font-body);cursor:pointer}',
    '.ins-promo .x{position:absolute;top:12px;right:12px;width:32px;height:32px;border:0;border-radius:50%;',
      'background:transparent;color:#fff;font:700 15px var(--font-body);cursor:pointer}',
    '.ins-promo-art{position:relative;width:84px;height:92px;flex:none}',
    '.ins-promo-art i{position:absolute;bottom:0;width:18px;border-radius:5px 5px 0 0;background:rgba(255,255,255,.12)}',
    '.ins-promo-art .b1{left:2px;height:34px}.ins-promo-art .b2{left:26px;height:64px}',
    '.ins-promo-art .b3{left:50px;height:46px}.ins-promo-art .b4{left:74px;height:78px}',
    '.ins-promo-art span{position:absolute;width:32px;height:32px;border-radius:50%;display:grid;',
      'place-items:center;color:#fff;font:800 18px/1 var(--font-body)}',
    '.ins-promo-art .c1{left:8px;top:28px;background:#E63946}',
    '.ins-promo-art .c2{right:0;top:2px;background:#0075E3}',
    '.ins-promo-art .c3{left:38px;top:52px;background:#8CC6FF}',
    '.ins-promo-art .ins-faccia{width:24px;height:24px;display:block;color:#fff}',
    '.ic-tondo .ins-faccia{width:46px;height:46px;display:block;color:#fff}',

    /* Distrazioni evitate */
    '.ins-avoid{display:flex;align-items:center;gap:12px;text-align:left;padding:14px 16px}',
    '.ins-avoid .t{flex:1;min-width:0}',
    '.ins-avoid .t b{display:block;font:800 15px var(--font-display);color:var(--navy)}',
    'body.dark .ins-avoid .t b{color:#fff}',
    '.ins-avoid .t small{display:block;font:500 11.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.ins-avoid .pill{display:flex;align-items:center;gap:6px;flex:none;border-radius:99px;padding:6px 8px 6px 10px;',
      'background:linear-gradient(90deg,#005BB0,#0075E3 55%,#3F9FF4)}',
    '.ins-avoid .pill .sh{width:22px;height:22px;color:#fff;display:block}',
    '.ins-avoid .pill .sh svg{width:22px;height:22px}',
    '.ins-avoid .pill b{font:800 17px var(--font-display);color:#fff;margin-right:2px}',
    '.ins-avoid .pill .th{width:26px;height:26px;border-radius:7px;overflow:hidden;background:rgba(255,255,255,.18);flex:none}',
    '.ins-avoid .pill .th img{width:26px;height:26px;display:block;opacity:0}',
    '.ins-avoid .pill .th img[src]{opacity:1}',

    /* Bilancia */
    '.ins-bil .hd{display:flex;align-items:flex-start;gap:12px;margin-bottom:6px}.ins-bil .hd b{font-size:19px!important;line-height:1.25}',
    '.ins-bil p.pct{margin:0 0 20px!important;text-align:left!important;font:600 16px/1.5 var(--font-body)!important;color:var(--ink,#1B2B45)!important}.ins-bil p.pct b{font-weight:800;color:var(--blue)}body.dark .ins-bil p.pct{color:#E6EEF8!important}',
    '.ins-bil .ft{margin-top:18px!important;align-items:flex-start}.ins-bil .ft > span > span{display:flex;flex-direction:column;line-height:1.2}.ins-bil .ft b{font:800 17px var(--font-display)}.ins-bil .ft small{margin-top:3px;font:600 12.5px var(--font-body);color:var(--muted)}.ins-bil .ft .b > span{align-items:flex-end}',
    '.ins-bil .hd b{font:800 22px var(--font-display);color:var(--navy);flex:none}',
    /* 0.9.305: da dove viene il tempo da sveglio (il risveglio vero, o il ripiego dichiarato) */
    '.ins-bil p.ins-bil-n{margin:14px 0 0;padding-top:12px;border-top:1px solid var(--line);font:500 12px/1.5 var(--font-body);color:var(--muted);text-align:left}',
    'body.dark .ins-bil p.ins-bil-n{color:#B8C6DC;border-top-color:rgba(255,255,255,.1)}',
    'body.dark .ins-bil .hd b{color:#fff}',
    '.ins-bil .pct{margin-left:auto;text-align:right;font:800 17px/1.3 var(--font-display);color:var(--blue)}',
    '.ins-bil .ins-track.big{height:14px;border-radius:99px;background:rgba(120,140,170,.25)}',
    '.ins-bil .ins-track.big i{display:block;height:100%;border-radius:99px;background:var(--blue)}',
    '.ins-bil .ft{display:flex;justify-content:space-between;margin-top:12px;font:700 15px var(--font-body)}',
    '.ins-bil2 .ft{margin-top:0!important}.ins-bil2 .ft b{font-size:22px!important}.ins-bil2 .pct{margin:22px 0 10px!important;text-align:left!important}',
    '.ins-bil .ft span{display:flex;align-items:center;gap:6px}',
    '.ins-bil .ft svg{width:20px;height:20px}',
    '.ins-bil .ft .a{color:var(--blue)}.ins-bil .ft .b{color:var(--muted)}',
    /* 0.9.353: i due numeri, la barra, la frase, la riga, la nota (prima la frase stava attaccata ai numeri, sopra la barra) */
    '.ins-card.ins-bil.ins-bil3 .ins-track.big{margin:18px 0 0}',
    '.ins-card.ins-bil.ins-bil3 p.pct{margin:16px 0 0!important}',
    '.ins-card.ins-bil.ins-bil3 p.ins-bil-n{margin:16px 0 0;padding-top:12px}',
    /* la scelta evidenziata e il resto spento: il resto in un azzurro del brand, non piu' grigio */
    '.ins-hours .col i.dim,.ins-week .col i.dim{background:#C8EFFD}',
    'body.dark .ins-hours .col i.dim,body.dark .ins-week .col i.dim{background:rgba(200,239,253,.2)}',
    /* le frecce dei giorni sono icone */
    '.ins-per button{display:flex;align-items:center;justify-content:center;min-width:34px;min-height:34px}.ins-per button svg{display:block}',
    /* il titolo del controllo dell umore e sotto il pannello delle informazioni */
    '#insBody .um-testa + .umi-porta{margin:26px 0 16px}',
    /* i blocchi spostati (statistiche globali, cronologia, umore) con almeno 30px fra un blocco e l altro */
    '#insBody > #sgPannello{margin-top:30px!important;margin-bottom:30px!important}',
    '#insBody > #rpUmore > .um-testa:first-child{margin-top:30px}',

    '.ins-cat ul{list-style:none;margin:18px 0 0;padding:0;display:flex;flex-direction:column;gap:16px}.ins-cat li{display:flex;align-items:center;gap:12px}.ins-cat li > span{flex:none;font-size:24px;line-height:1}.ins-cat li > div{flex:1;min-width:0}.ins-cat li b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .ins-cat li b{color:#fff}.ins-cat li i{display:block;height:6px;margin-top:7px;border-radius:99px;background:rgba(0,117,227,.14);overflow:hidden}.ins-cat li u{display:block;height:100%;border-radius:99px;background:#0075E3}.ins-cat li em{flex:none;font:800 14px var(--font-body);font-style:normal;color:var(--navy)}body.dark .ins-cat li em{color:#fff}',
    /* Fascia oraria di maggiore utilizzo, come la card di AppBlock */
    '.ins-picco{padding:20px 18px 18px!important;border-radius:26px!important}',
    '.pk-hd{display:flex;align-items:center;gap:12px}',
    '.pk-hd b{flex:1;min-width:0;font:800 21px/1.28 var(--font-display);color:var(--navy);text-align:left}',
    'body.dark .pk-hd b{color:#fff}',
    '.pk-hd span{flex:none;font:700 17px var(--font-display);color:var(--blue);white-space:nowrap}',
    '.pk-bars{display:flex;align-items:flex-end;gap:5px;height:60px;margin-top:46px}',
    '.pk-c{flex:1;min-width:0;height:100%;display:flex;align-items:flex-end;justify-content:center}',
    '.pk-c i{display:block;width:100%;max-width:8px;min-height:8px;border-radius:99px;background:var(--blue)}',
    /* 0.9.319, Andrea: come AppBlock: la barra piu' alta sfuma piano dal rosso in cima al blu in basso, senza uno scalino */
    '.pk-c i.pk-top{background:linear-gradient(180deg,#E8343F 0%,#E8343F 14%,#A65683 42%,#4E79DC 68%,var(--blue) 86%)}',
    '.pk-c b{display:block;width:70%;max-width:7px;height:2px;border-radius:1px;background:rgba(120,140,170,.55)}',

    /* le card quadrate di Focus e Distrazioni */
    '.sqgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:12px 0 18px}',
    '.sq{position:relative;aspect-ratio:1/1;display:flex;flex-direction:column;align-items:center;',
      'justify-content:center;gap:8px;background:var(--card);border:1px solid var(--line);',
      'border-radius:26px;padding:18px 12px;text-align:center}',
    '.sq .info{position:absolute;top:12px;right:12px;width:18px;height:18px;border-radius:50%;',
      'border:1.5px solid var(--muted);color:var(--muted);font:700 10px/16px var(--font-body);',
      'font-style:normal;text-align:center;cursor:pointer}',
    '.sq .ico{width:48px;height:48px;color:var(--blue);display:block}',
    '.sq .ico svg{width:48px;height:48px}',
    '.sq .lbl{font:700 11px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}',
    '.sq b{font:800 22px/1 var(--font-display);color:var(--navy)}',
    'body.dark .sq b{color:#fff}',

    /* TENDENZA */
    '.ins-sticky{position:sticky;top:0;z-index:6;background:var(--bg);margin:0 -18px;padding:0 18px 2px}',
    '.ins-per.trend b{color:var(--blue);text-transform:uppercase;letter-spacing:.06em;font-size:15px}',
    '.tr-arrow{width:64px;height:64px;border-radius:50%;margin:8px auto 4px;display:grid;place-items:center;color:#fff}',
    '.tr-arrow svg{width:34px;height:34px}',
    '.tr-plot{display:flex;gap:6px;margin:14px 0 10px;height:200px}',
    '.tr-plotbody{position:relative;flex:1;min-width:0;height:170px}',
    '.tr-svg{width:100%;height:170px;display:block}',
    '.tr-grid line{stroke:rgba(120,140,170,.25);stroke-width:1}',
    '.tr-avg{stroke:#3F9FF4;stroke-width:2;stroke-dasharray:6 5}',
    '.tr-avgl{position:absolute;left:0;transform:translateY(-120%);font:600 11px var(--font-body);color:#3F9FF4}',
    '.tr-avgv{position:absolute;right:-4px;transform:translate(100%,-50%);background:#F0FBFF;color:#001E44;',
      'font:800 11px var(--font-body);padding:4px 7px;border-radius:6px;white-space:nowrap}',
    '.tr-avgv::before{content:"";position:absolute;left:-5px;top:50%;transform:translateY(-50%);border:5px solid transparent;border-right-color:#F0FBFF;border-left:0}',
    '.tr-mesi{position:relative;height:22px;margin-top:4px}',
    '.tr-mesi span{position:absolute;transform:translateX(-50%);font:600 11px var(--font-body);color:var(--muted)}',
    '.tr-y{display:flex;flex-direction:column;justify-content:space-between;height:170px;padding:0 0 0 2px;flex:none;min-width:44px}',
    '.tr-y span{font:600 11px var(--font-body);color:var(--muted);text-align:right;line-height:1}',
    '.tr-cmp .tr-t{display:block;font:800 21px/1.25 var(--font-display);color:var(--navy);margin-bottom:8px}',
    'body.dark .tr-cmp .tr-t{color:#fff}',
    '.tr-cmp .tr-s{margin:0 0 14px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.tr-grad{display:flex;gap:16px;align-items:flex-end}',
    '.tr-g{flex:1;min-width:0;text-align:center}',
    '.tr-gbars{position:relative;display:flex;align-items:flex-end;gap:6px;height:120px;padding:26px 2px 0}',
    '.tr-gbars i{flex:1;border-radius:99px;display:block}',
    '.tr-gline{position:absolute;left:0;right:0;height:3px;border-radius:2px}',
    '.tr-gline b{position:absolute;left:0;bottom:6px;font:800 16px var(--font-display);white-space:nowrap}',
    '.tr-g:first-child .tr-gline b{color:var(--navy) !important}',
    'body.dark .tr-g:first-child .tr-gline b{color:#fff !important}',
    '.tr-g small{display:block;margin-top:10px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.tr-podio .tr-ph{display:flex;align-items:flex-start;gap:12px;margin-bottom:10px}',
    '.tr-podio .tr-ph b{display:block;font:800 21px/1.25 var(--font-display);color:var(--navy)}',
    'body.dark .tr-podio .tr-ph b{color:#fff}',
    '.tr-podio .tr-ph small{display:block;margin-top:4px;font:500 13.5px var(--font-body);color:var(--muted)}',
    '.tr-badge{margin-left:auto;flex:none;width:44px;height:44px;border-radius:50%;display:grid;place-items:center;color:#fff}',
    '.tr-badge svg{width:24px;height:24px}',
    '.tr-cols{display:flex;align-items:flex-end;gap:8px;height:240px;padding-top:34px}',
    '.tr-col{flex:1 1 0;min-width:0;position:relative;background:rgba(120,140,170,.16);border-radius:18px 18px 8px 8px;',
      'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:34px 6px 14px}',
    /* niente quadrante bianco dietro alle icone: l'icona e basta */
    '.tr-col img,.tr-col > .ins-ico{position:absolute;top:-30px;left:50%;transform:translateX(-50%);width:58px;height:58px;border-radius:16px;',
      'display:grid;place-items:center;font:800 24px var(--font-body);font-style:normal;color:#fff;object-fit:contain}',
    /* 0.9.326, Andrea: il nome clippato e lontano dall'icona, e l'app l'utente la conosce: il nome resta solo dove l'icona manca */
    '.tr-nome{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:700 12px var(--font-body);color:var(--muted)}.tr-col img ~ .tr-nome{display:none}.tr-col{min-height:122px;box-sizing:border-box}',
    '.tr-rank{font:800 22px var(--font-display);color:var(--navy);white-space:nowrap;letter-spacing:-.02em}',
    'body.dark .tr-rank{color:#fff}',
    '.tr-up{width:34px;height:34px;color:#E63946}.tr-up svg{width:34px;height:34px}',
    '.tr-col b{font:800 14px var(--font-display);color:var(--navy);white-space:nowrap}',
    'body.dark .tr-col b{color:#fff}',
    '.tr-warn{margin:14px auto 0;width:fit-content;background:rgba(255,59,48,.14);color:#FF3B30;',
      'font:700 12.5px var(--font-body);padding:6px 12px;border-radius:8px}',
    /* 0.9.353, Andrea: "Maggior risparmio di tempo e Maggior aumento su fondo blu scuro del brand, testi bianchi,
       contrasto vero". Le due card del podio sul gradiente scuro, in chiaro e in scuro, con colori fissi */
    '#insBody .ins-card.tr-podio{background:linear-gradient(160deg,#0B3470,#001E44)!important;border-color:#0B3470!important;color:#FFFFFF;box-shadow:0 10px 26px rgba(0,30,68,.22)}',
    '#insBody .tr-podio .tr-ph b{color:#FFFFFF}',
    '#insBody .tr-podio .tr-ph small{color:#C8EFFD}',
    /* il nome della terza app finiva sotto l icona nella colonna piu bassa: il contenuto sta in fondo alla colonna */
    '#insBody .tr-podio .tr-col{background:rgba(200,239,253,.12);justify-content:flex-end;min-height:150px}',
    '#insBody .tr-podio .tr-nome{color:#C8EFFD}',
    '#insBody .tr-podio .tr-rank,#insBody .tr-podio .tr-col b{color:#FFFFFF}',
    '#insBody .tr-podio .tr-up{color:#E63946}',
    '#insBody .tr-podio .tr-warn{background:rgba(230,57,70,.3);color:#FFFFFF}',
    '#insBody .tr-podio .tr-badge{box-shadow:0 0 0 3px rgba(255,255,255,.14)}',
    '#insBody .tr-podio .tr-col > .ins-ico{box-shadow:0 0 0 2px rgba(200,239,253,.4)}',

    /* il registro dei punti */
    '.pz{padding:0;overflow:hidden}',
    /* La riga che porta al registro: una carta come le altre, con la freccia a destra. */
    '.pz-link{display:flex;align-items:center;gap:12px;cursor:pointer}',
    '.pz-link > div{flex:1}',
    '.pz-link b{display:block;font:800 14px var(--font-body);color:var(--navy)}',
    '.pz-link small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    '.pz-link .pz-chev{font:700 20px var(--font-body);color:var(--muted)}',
    '.pz-page{padding:0 16px 20px}',
    '.pz-hero{position:relative;display:flex;align-items:center;justify-content:center;gap:22px;padding:24px 16px 20px;border-radius:24px;background:linear-gradient(160deg,#06204A,#00132B);box-shadow:0 12px 28px rgba(0,30,68,.22)}',
    '.pz-sq{text-align:center;min-width:92px}.pz-sq span{display:block;font-size:30px;line-height:1}.pz-sq b{display:block;margin-top:8px;font:900 52px/1 var(--font-display)}.pz-sq b.o{color:#FF8A92}.pz-sq b.n{color:#8DF0CF}.pz-sq small{display:block;margin-top:6px;font:700 12.5px var(--font-body);color:#BFD3EC}.pz-hero > i{font:800 30px var(--font-display);font-style:normal;color:#5F789E}',
    '.pz-i{position:absolute;right:12px;top:12px;width:28px;height:28px;padding:0;border:1.5px solid rgba(188,224,255,.7);border-radius:50%;background:none;color:#BCE0FF;font:800 14px var(--font-body);cursor:pointer}',
    '.pz-tabs{display:flex;gap:4px;margin:16px 0 4px;padding:4px;border-radius:99px;background:#E6ECF4}body.dark .pz-tabs{background:#14234A}.pz-tabs button{flex:1;padding:11px 0;border:0;border-radius:99px;background:none;color:var(--muted);font:700 14px var(--font-body);cursor:pointer}.pz-tabs button.on{background:#fff;color:#001E44;box-shadow:0 2px 8px rgba(0,30,68,.12)}body.dark .pz-tabs button.on{background:#0075E3;color:#fff}',
    '.pz-g{margin:22px 4px 10px;font:800 13px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}',
    '.pz-l{display:flex;flex-direction:column;gap:8px;margin-top:10px}.pz-g + .pz-l{margin-top:0}',
    '.pz-cap{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;padding:15px 16px;cursor:pointer;text-align:left}',
    '.pz-cap b{font:800 14px var(--font-display);color:var(--navy)}',
    'body.dark .pz-cap b{color:#fff}',
    '.pz-cap small{margin-left:auto;font:700 12px var(--font-body);color:var(--muted)}',
    '.pz.on .pcz-chev{transform:rotate(225deg) translate(-1px,-1px)}',
    '.pz-sez{display:flex;align-items:baseline;gap:8px;padding:12px 16px 6px;border-top:1px solid var(--line)}',
    '.pz-sez b{font:800 13px var(--font-body);color:var(--navy)}',
    'body.dark .pz-sez b{color:#fff}',
    '.pz-sez small{font:600 11px var(--font-body);color:var(--muted)}',
    '.pz-r{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .pz-r{background:#12203A;border-color:#22345A}',
    '.pz-fac{flex:none;width:42px;height:42px;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:21px;background:#E3F1FF}.pz-r.old .pz-fac{background:#FFE7E9}.pz-r.revoca .pz-fac{background:#EDF1F6}body.dark .pz-fac{background:#1B2C4F}body.dark .pz-r.old .pz-fac{background:#40202C}',
    '.pz-t{flex:1;min-width:0}.pz-t b{display:block;font:700 14.5px/1.3 var(--font-body);color:var(--navy)}body.dark .pz-t b{color:#fff}.pz-t small{display:block;margin-top:2px;font:500 12.5px/1.35 var(--font-body);color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.pz-d{flex:none;text-align:right}.pz-d em{display:block;font:900 19px/1 var(--font-display);font-style:normal;color:#0075E3}body.dark .pz-d em{color:#8CC6FF}.pz-r.old .pz-d em,.pz-d em.ced{color:#E63946}.pz-d em.ced{font:800 12.5px var(--font-body);margin-bottom:3px}.pz-r.revoca .pz-d em{color:var(--muted)}.pz-d small{display:block;margin-top:3px;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.pz-r.revoca .pz-t b{color:var(--muted);text-decoration:line-through}',
    '.pz-th{display:flex !important;gap:5px;margin-top:6px !important}',
    '.pz-th img{width:24px;height:24px;border-radius:6px;opacity:0}.pz-th img[src]{opacity:1}',
    '.pz-vuoto{margin:0;padding:34px 16px;text-align:center}.pz-vuoto span{display:block;font-size:36px}.pz-vuoto b{display:block;margin-top:8px;font:800 16px var(--font-display);color:var(--navy)}body.dark .pz-vuoto b{color:#fff}.pz-vuoto p{margin:4px 0 0;font:500 13.5px var(--font-body);color:var(--muted)}',

    /* i siti DENTRO al riquadro del browser, rientrati sotto al nome (13 + 40 + 11 px) */
    '.ins-grp{background:var(--card);border:1px solid var(--line);border-radius:var(--r-md);margin-bottom:9px;overflow:hidden}',
    '.ins-grp > .ins-app{border:0;margin:0;border-radius:0;background:transparent}',
    '.ins-grp > .ins-sites{background:transparent;border:0;border-radius:0;margin:0;padding:0 13px 12px 64px}',
    '.ins-grp > .ins-sites.ins-soc{padding:4px 13px 12px}',
    '.ins-soc-in{display:flex;align-items:center;gap:14px}',
    '.ins-soc-in .soc-ring{width:104px;flex:none}',
    '.ins-soc-l{flex:1;min-width:0}',
    '.ins-soc-l .r,.ins-soc-pc .r{display:flex;align-items:center;gap:8px;padding:4px 0;font:600 12.5px var(--font-body);color:var(--navy)}',
    '.ins-soc-l i{width:11px;height:11px;border-radius:2px;flex:none}',
    '.ins-soc-l .nm,.ins-soc-pc .nm{flex:1;min-width:0}',
    '.ins-soc-l .tm,.ins-soc-pc .tm{flex:none;color:var(--muted)}',
    '.ins-soc-pc{margin-top:10px;border-top:1px solid var(--line);padding-top:6px}',
    '.ins-soc-pc .r.tot{font-weight:800}',
    '.ins-soc-pc .r.tot .tm{color:var(--navy)}',
    '.ins-soc .ins-sitenote{margin-top:8px}',
    'body.dark .ins-soc-l .r,body.dark .ins-soc-pc .r,body.dark .ins-soc-pc .r.tot .tm{color:#fff}',
    'body.dark .ins-soc-pc{border-color:#22345A}',
    '.ins-grp.on > .ins-sites{border-top:1px solid var(--line);padding-top:8px}',
    'body.dark .ins-grp > .ins-sites{background:transparent}',
    '.ins-br-det{display:flex;align-items:center;gap:8px;margin-top:6px;padding:6px 0 0;border:0;background:transparent;',
      'font:700 12px var(--font-body);color:var(--blue,#0075E3);cursor:pointer}',
    /* IL + DEL TEMA (snippets e CSS del sito, .animated-plus): due barrette, chiuso girate di
       -90 gradi; aperto tornano a 0 e la verticale sparisce, quindi il + ruota e diventa -. */
    '.animated-plus{position:relative;flex:none;width:12px;height:12px;color:var(--muted)}',
    '.animated-plus::before,.animated-plus::after{content:"";position:absolute;top:50%;left:50%;background:currentColor;',
      'border-radius:1px;transform:translate(-50%,-50%) rotate(-90deg);transition:transform .25s ease-in-out,opacity .25s ease-in-out}',
    '.animated-plus::before{width:12px;height:2px}',
    '.animated-plus::after{width:2px;height:12px}',
    '[aria-expanded="true"] > .animated-plus::before,[aria-expanded="true"] > .animated-plus::after{transform:translate(-50%,-50%) rotate(0deg)}',
    '[aria-expanded="true"] > .animated-plus::after{opacity:0}',
    '.ins-sitelist .s{display:flex;align-items:center;gap:10px;padding:6px 0}',
    '.ins-sitelist .s i{width:22px;height:22px;border-radius:6px;flex:none;display:grid;place-items:center;',
      'font:800 11px var(--font-body);font-style:normal;color:#fff}',
    '.ins-sitelist .s .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;',
      'font:600 12.5px var(--font-body);color:var(--navy)}',
    'body.dark .ins-sitelist .s .nm{color:#fff}',
    '.ins-sitelist .s .tm{font:700 12px var(--font-body);color:var(--muted)}',
    '.ins-sitenote{font:500 11.5px/1.6 var(--font-body);color:var(--muted)}',
    /* Il riquadro dei siti era bianco anche di notte: in scuro il testo (chiaro) spariva. */
    'body.dark .ins-sites{background:rgba(255,255,255,.04);border-color:var(--line)}'
  ].join('\n');
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.ins-fasce{margin:14px 0 4px;padding:16px 14px;border-radius:18px;border:1px solid var(--line);background:var(--card,#fff)}body.dark .ins-fasce{background:#12203A;border-color:#22345A}',
    '.ins-fasce-h b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .ins-fasce-h b{color:#fff}.ins-fasce-h small{display:block;margin:4px 0 12px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    '.ins-fascia{display:flex;align-items:center;gap:10px;padding:10px 0;border-top:1px solid var(--line)}.ins-fascia .dot{width:10px;height:10px;border-radius:50%}.ins-fascia b{flex:1;font:700 14px var(--font-body);color:var(--navy)}body.dark .ins-fascia b{color:#fff}.ins-fascia em{font:800 12.5px var(--font-body);font-style:normal}.ins-fascia button{width:30px;height:30px;border:0;border-radius:50%;background:transparent;color:var(--muted);cursor:pointer}',
    '.ins-fasce-ora{margin:8px 0 0;font:500 13px var(--font-body);color:var(--muted)}.ins-fasce-ora b{color:var(--navy)}body.dark .ins-fasce-ora b{color:#fff}.ins-fasce-piu{margin-top:12px;width:100%}',
    '.ins-fn-p{margin:0 0 14px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}.ins-fn-ore{display:grid;grid-template-columns:1fr 1fr;gap:10px}.ins-fn-ore small{display:block;margin-bottom:4px;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.ins-fn-ore .fin{width:100%;box-sizing:border-box;margin:0}.ins-fn-l{margin:16px 0 8px;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}'
  ].join('\n');
  document.head.appendChild(st);
})();
