/* ===========================================================================================
   MENTRE SI SCORRE, IL LAVORO CHE PUO' ASPETTARE ASPETTA (0.9.265 → 0.9.268, Andrea: "lo scroll scatta")

   Misurato su BlueStacks, e sentito sul suo Galaxy S21 FE (120 Hz: 8 ms a fotogramma): durante lo
   scroll la pagina veniva ricalcolata da chi toccava il DOM in quel momento — i ridisegni rimandati
   del cambio scheda (l'intestazione, il sentiero, le misure), i timer ripetuti (ogni 1, 10, 30, 60
   secondi), le risposte del telefono ai plugin. Sulla Mappa (17.000 px) un ricalcolo costa decine
   di millisecondi: ogni volta e' un fotogramma perso, e si sente come uno scatto.

   Questo file si carica PRIMA di tutti gli altri e tiene una regola sola: mentre si scorre (e per
   300 ms dopo) nessun lavoro rimandabile tocca la pagina. Quello che scade in quel momento va in
   CODA e riparte a scroll fermo, UNO PER FOTOGRAMMA (0.9.268: non piu' tutto insieme — la raffica
   della 0.9.266 era essa stessa uno scatto). Vale per:
   - i setTimeout da 150 ms in su e i setInterval da 1 s in su (quelli corti — animazioni,
     cronometri a vista, lo slideshow che guarda l'orologio — non si toccano);
   - le risposte native del ponte Capacitor (androidBridge.onmessage): arrivano in coda e si
     consegnano a scroll fermo, al massimo 1,5 s dopo;
   - le decorazioni infinite (bagliore, fumetto, farfalla, anello della bolla, telefono che
     squilla): in pausa con uno stile inline sui singoli elementi (una classe sulla radice
     invalidava tutto lo stile a ogni gesto), con la lista preparata FUORI dallo scroll.
   =========================================================================================== */
window.FL_SCROLL_AT = 0;
function flInScroll(){ return Date.now() - window.FL_SCROLL_AT < 300; }

/* ---- la coda di quello che riparte a scroll fermo, un pezzo per fotogramma ---- */
const FL_CODA = [];
let FL_CODA_T = 0, FL_CODA_RAF = 0;
function flCodaGira(){
  FL_CODA_RAF = 0;
  if (!FL_CODA.length) return;
  /* mentre si scorre parte solo chi aspetta da piu' di 2,5 s (uno scroll lungo non deve fermare tutto per sempre) */
  if (flInScroll() && Date.now() - FL_CODA[0].at < 2500){ flCodaArma(); return; }
  const f = FL_CODA.shift().fn;
  try{ f(); }catch(e){ setTimeout(function(){ throw e; }, 0); }
  if (FL_CODA.length) FL_CODA_RAF = requestAnimationFrame(flCodaGira);
}
function flCodaArma(){
  clearTimeout(FL_CODA_T);
  FL_CODA_T = setTimeout(function(){ if (!FL_CODA_RAF) FL_CODA_RAF = requestAnimationFrame(flCodaGira); }, 320);
}
/** Esegue subito se la pagina e' ferma; altrimenti in coda, a scroll fermo, un pezzo per fotogramma. */
function flDopoScroll(fn){
  if (!flInScroll()){ fn(); return; }
  FL_CODA.push({ fn: fn, at: Date.now() });
  flCodaArma();
}

/* ---- i timer ---- */
(function(){
  const origT = window.setTimeout, origC = window.clearTimeout, origI = window.setInterval;
  const vivi = new Map();   /* id visibile → ancora in coda? (clearTimeout dopo lo scadere la toglie) */
  window.setTimeout = function(fn, ms){
    if (typeof fn !== 'function' || !(+ms >= 150)) return origT.apply(window, arguments);
    const args = Array.prototype.slice.call(arguments, 2);
    let id = 0;
    const corri = function(){
      if (!flInScroll()){ vivi.delete(id); fn.apply(window, args); return; }
      vivi.set(id, true);
      flDopoScroll(function(){ if (!vivi.has(id)) return; vivi.delete(id); fn.apply(window, args); });
    };
    id = origT.call(window, corri, ms);
    return id;
  };
  window.clearTimeout = function(id){ vivi.delete(id); return origC.call(window, id); };
  window.setInterval = function(fn, ms){
    if (typeof fn !== 'function' || !(+ms >= 1000)) return origI.apply(window, arguments);
    const args = Array.prototype.slice.call(arguments, 2);
    let attesa = false;
    return origI.call(window, function(){
      if (!flInScroll()){ try{ fn.apply(window, args); }catch(e){ origT.call(window, function(){ throw e; }, 0); } return; }
      if (attesa) return;
      attesa = true;
      flDopoScroll(function(){ attesa = false; fn.apply(window, args); });
    }, ms);
  };
})();

/* ---- le risposte del telefono ---- */
(function(){
  let tentativi = 0;
  const aggancia = function(){
    const b = window.androidBridge;
    if (!b || typeof b.onmessage !== 'function'){ if (++tentativi < 40) setTimeout(aggancia, 100); return; }
    if (b.onmessage._flGate) return;
    const orig = b.onmessage;
    const coda = []; let primo = 0, t = 0;
    const svuota = function(){
      t = 0;
      while (coda.length){
        const m = coda.shift();
        try{ orig.call(b, m); }catch(e){ setTimeout(function(){ throw e; }, 0); }
        /* uno per fotogramma, salvo urgenza */
        if (coda.length && !flInScroll() && Date.now() - primo < 1500){ t = setTimeout(svuota, 16); return; }
      }
      primo = 0;
    };
    const gate = function(m){
      if (!flInScroll() && !coda.length){ return orig.call(b, m); }
      if (!coda.length) primo = Date.now();
      coda.push(m);
      /* a scroll fermo, oppure comunque dopo 1,5 s: una risposta non puo' aspettare per sempre */
      clearTimeout(t);
      t = setTimeout(svuota, Date.now() - primo > 1500 ? 0 : 320);
    };
    gate._flGate = true;
    b.onmessage = gate;
  };
  aggancia();
})();

/* ---- le decorazioni, in pausa mentre si scorre ---- */
(function(){
  const SEL = '.glw > b, .sd-fumetto, .fa-ali-w, .fa-ala, .dco-si i, .nv-cover-aura i, .ic-onda';
  let t = 0, on = false, lista = [], raccoltaT = 0;
  /* la lista si prepara fuori dallo scroll: dopo un cambio scheda o un ridisegno, a pagina ferma */
  const raccogli = function(){
    lista = Array.prototype.slice.call(document.querySelectorAll(SEL)).filter(function(e){ return e.isConnected && !e.closest('.tabpage:not(.on), .screen:not(.active)'); });
    const b = document.getElementById('strictBubble'); if (b) lista.push(b);
  };
  /* un rinvio di 300 ms a ogni nodo nuovo, ma con un tetto: la pagina aggiunge nodi di continuo e la lista non si
     costruiva mai (0.9.268) */
  let raccoltaMax = 0;
  const giro = function(){ clearTimeout(raccoltaT); clearTimeout(raccoltaMax); raccoltaT = raccoltaMax = 0; flDopoScroll(raccogli); };
  const raccogliPresto = function(){
    clearTimeout(raccoltaT); raccoltaT = setTimeout(giro, 300);
    if (!raccoltaMax) raccoltaMax = setTimeout(giro, 1500);
  };
  const ferma = function(){
    on = true;
    /* 0.9.282, Andrea: il bagliore che gira intorno al lucchetto della modalita' severa non si ferma mai, nemmeno scorrendo */
    for (let i = 0; i < lista.length; i++){ const e = lista[i]; if (e.id === 'strictBubble') continue; e.style.animationPlayState = 'paused'; }
  };
  const via = function(){
    on = false;
    for (let i = 0; i < lista.length; i++){ const e = lista[i]; if (e.id === 'strictBubble') e.classList.remove('fl-ferma'); else e.style.animationPlayState = ''; }
  };
  document.addEventListener('scroll', function(e){
    const tg = e.target;
    if (!tg || !tg.classList || !tg.classList.contains('tabpage')) return;
    window.FL_SCROLL_AT = Date.now();
    if (!on) ferma();
    clearTimeout(t); t = setTimeout(via, 300);
  }, { capture: true, passive: true });
  document.addEventListener('fl:tab', raccogliPresto);
  document.addEventListener('fl:screen', raccogliPresto);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', raccogliPresto); else raccogliPresto();
  try{
    new MutationObserver(function(m){
      for (let i = 0; i < m.length; i++){ const a = m[i].addedNodes; for (let j = 0; j < a.length; j++){ if (a[j].nodeType === 1){ raccogliPresto(); return; } } }
    }).observe(document.body || document.documentElement, { childList: true, subtree: true });
  }catch(_){ }
  const st = document.createElement('style');
  st.textContent = '.strict-bubble.fl-ferma::before{animation-play-state:paused !important}';
  document.head.appendChild(st);
})();

/* METTERE IN ORDINE SENZA SPOSTARE (0.9.265, lag). Tre schede rimettevano i blocchi nell'ordine scelto spostandoli
   TUTTI in fondo a ogni disegno, anche quando l'ordine era gia' giusto (il piede «Personalizza» in fondo faceva
   sembrare ogni blocco fuori posto). Spostare un elemento lo toglie e lo rimette: pagina ricalcolata e animazioni
   che ripartono da capo, ogni pochi secondi. flOrdina sposta solo se l'ordine e' davvero diverso. */
function flOrdina(padre, elementi){
  if (!padre) return false;
  const voluti = elementi.filter(function(e){ return e && e.nodeType === 1; });
  if (!voluti.length) return false;
  const set = new Set(voluti);
  const ora = [];
  for (let c = padre.firstElementChild; c; c = c.nextElementSibling) if (set.has(c)) ora.push(c);
  let giusto = ora.length === voluti.length;
  for (let i = 0; giusto && i < voluti.length; i++) if (ora[i] !== voluti[i]) giusto = false;
  if (giusto) return false;
  voluti.forEach(function(e){ padre.appendChild(e); });
  return true;
}

/* esc di riserva: qualche pannello si disegna all'avvio prima che nav.js (che ha quella vera) sia caricato
   ("esc is not defined" in rotta-tab.js). nav.js la ridefinisce uguale. */
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }

/* ===========================================================================================
   0.9.342 — DUE REGOLE PER TUTTE LE SCHERMATE

   1. SCEGLI, POI CONTINUA. Andrea: "in alcune domande, se uno tocca una carta passa direttamente alla domanda dopo, senza
      vedere la carta evidenziata e il pulsante Continua. Non te lo voglio piu' dover ripetere". Una carta di scelta (.gn-card in
      .gn-cards) al primo tocco si accende e sotto compare "Continua"; e' Continua a mandare avanti, con la scelta di quella carta.
      Restano fuori "Lo scrivo io" (apre il suo campo) e le scelte multiple (che hanno gia' il loro Continua).
   2. LE FILE CHE SCORRONO DI LATO SFUMANO AI BORDI, come nei breadcrumb: si capisce che c'e' altro, senza tagli netti.
   =========================================================================================== */
function flCartaMulti(b){ const o = b.getAttribute('onclick') || ''; return /Toggle|Multi|multi\(/.test(o) || !!b.closest('.gn-multi, .fl-subito'); }
document.addEventListener('click', function(e){
  const b = e.target && e.target.closest ? e.target.closest('.gn-cards > .gn-card') : null;
  if (!b || b.classList.contains('tratt') || b.disabled) return;
  if (b.__flOk){ b.__flOk = false; return; }
  if (flCartaMulti(b)) return;
  /* 0.9.344, Andrea: "il pulsante Continua ci deve essere solo per le scelte multiple: con una scelta sola che senso ha?". Una
     scelta sola si accende un attimo (si vede cosa hai toccato) e passa da sola alla domanda dopo. "Continua" resta alle scelte
     multiple, che hanno gia' il loro pulsante. */
  e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
  const box = b.parentElement;
  if (box.__flVa) return;
  box.__flVa = true;
  box.querySelectorAll(':scope > .gn-card').forEach(function(c){ c.classList.toggle('on', c === b); });
  try{ if (typeof flVibra === 'function') flVibra(8); }catch(_){ }
  setTimeout(function(){ box.__flVa = false; if (!b.isConnected) return; b.__flOk = true; b.click(); }, 200);
}, true);

/* 0.9.344, Andrea: "Lo scrivo io non deve stare in un pannello con una carta: e' un testo sottolineato, fuori dal pannello. E nelle
   domande con due risposte opposte (due parole e via / spiego tutto per bene) non ci deve essere proprio: o e' nero o e' bianco".
   Ogni carta tratteggiata "Lo scrivo io" dentro una griglia di carte diventa un link sotto al pannello; con due sole carte sparisce,
   a meno che la griglia non dica data-scrivo="si". Vale per tutte le schermate, anche quelle disegnate dopo. */
function flScrivoLink(){
  document.querySelectorAll('.gn-cards > .gn-card.tratt').forEach(function(c){
    const box = c.parentElement; if (!box) return;
    const altre = box.querySelectorAll(':scope > .gn-card:not(.tratt)').length;
    const tieni = altre !== 2 || box.getAttribute('data-scrivo') === 'si' || c.classList.contains('on');
    const pannello = box.closest('.gn-carta') || box;
    c.remove();
    box.classList.remove('dispari-s');
    box.classList.toggle('fl-dispari', altre % 2 === 1);
    if (!tieni) return;
    const l = document.createElement('button'); l.type = 'button'; l.className = 'gn-link fl-scrivo-link' + (c.classList.contains('on') ? ' on' : '');
    l.textContent = (c.querySelector('b') || c).textContent.trim() || 'Lo scrivo io';
    const oc = c.getAttribute('onclick'); if (oc) l.setAttribute('onclick', oc);
    if (pannello.nextElementSibling && pannello.nextElementSibling.classList && pannello.nextElementSibling.classList.contains('fl-scrivo-link')) pannello.nextElementSibling.remove();
    pannello.parentNode.insertBefore(l, pannello.nextSibling);
  });
}
(function(){
  let inCoda = false;
  const giro = function(){ inCoda = false; try{ flScrivoLink(); }catch(_){ } };
  const oss = new MutationObserver(function(){ if (!inCoda){ inCoda = true; requestAnimationFrame(giro); } });
  const via = function(){ try{ oss.observe(document.body, { childList: true, subtree: true }); giro(); }catch(_){ } };
  if (document.body) via(); else document.addEventListener('DOMContentLoaded', via);
  const st = document.createElement('style');
  st.textContent = '.fl-scrivo-link{display:block;margin:16px auto 2px;padding:8px 10px;border:0;background:none;font:700 15px var(--font-body);text-decoration:underline;text-underline-offset:4px;color:#BCE0FF;cursor:pointer}.fl-scrivo-link.on{color:#fff}'
    + 'body:not(.dark) .screen:not(.gn-scuro) .fl-scrivo-link{color:#0075E3}#gnScena .fl-scrivo-link,#orWrap .fl-scrivo-link{color:#BCE0FF!important}'
    + '.gn-cards.fl-dispari > .gn-card:last-child{grid-column:1 / -1}';
  document.head.appendChild(st);
})();

/* 0.9.344, Andrea: "come nell'app di Claude: la casella della chat resta bassa e si alza, mostrando la scelta del modello, solo quando
   la tocco". La casella prende "aperto" quando il campo ha il fuoco, e lo perde quando il fuoco esce e il campo e' vuoto. */
document.addEventListener('focusin', function(e){
  const t = e.target; if (!t || t.tagName !== 'TEXTAREA') return;
  const c = t.closest('#agComp, .cv-comp'); if (c) c.classList.add('aperto');
});
document.addEventListener('focusout', function(e){
  const t = e.target; const c = t && t.closest ? t.closest('#agComp, .cv-comp') : null; if (!c) return;
  setTimeout(function(){
    if (!c.isConnected || c.contains(document.activeElement)) return;
    const ta = c.querySelector('textarea');
    if (ta && ta.value.trim()) return;
    c.classList.remove('aperto');
  }, 180);
});

const FL_FADE_SEL = '.am-ord-l,.am-met,.nv-chips-wrap,.drs-all,.am-coppe,.hd-ob-scorri,.am-tabs,.fl-fade-x';
function flFadeX(el){
  if (!el || !el.clientWidth) return;
  /* 0.9.348, Andrea: "nella sezione Per te niente sfumatura ai lati: le card sono grandi e da' fastidio". Una riga con data-fade="no" resta netta */
  if (el.dataset && el.dataset.fade === 'no'){ if (el.__flFx !== 'no'){ el.__flFx = 'no'; el.style.webkitMaskImage = ''; el.style.maskImage = ''; el.classList.remove('fl-fade-x'); } return; }
  const max = el.scrollWidth - el.clientWidth;
  let sx = max > 2 && el.scrollLeft > 2 ? 28 : 0, dx = max > 2 && el.scrollLeft < max - 2 ? 28 : 0;
  /* 0.9.351, Andrea: "la sfumatura mai su tutti e due i bordi insieme: a destra mentre vai verso il fondo, a sinistra quando torni
     indietro verso la prima card". Si guarda da che parte si sta scorrendo */
  const prima = el.__flSx == null ? el.scrollLeft : el.__flSx; if (el.scrollLeft !== prima) el.__flDir = el.scrollLeft > prima ? 1 : -1; el.__flSx = el.scrollLeft;
  if (sx && dx){ if (el.__flDir === -1) dx = 0; else sx = 0; }
  const v = sx + ',' + dx; if (el.__flFx === v) return; el.__flFx = v;
  if (!sx && !dx){ el.style.webkitMaskImage = ''; el.style.maskImage = ''; return; }
  const m = 'linear-gradient(90deg,transparent 0,#000 ' + sx + 'px,#000 calc(100% - ' + dx + 'px),transparent 100%)';
  el.style.webkitMaskImage = m; el.style.maskImage = m;
}
document.addEventListener('scroll', function(e){ const t = e.target; if (t && t.matches && t.matches(FL_FADE_SEL)) flFadeX(t); }, true);
/* oltre alle file note, ogni fila di pillole o di schede che scorre di lato (si riconosce dal nome della classe e dallo stile) */
const FL_FADE_AUTO = '[class*="chip"],[class*="pill"],[class*="tabs"],[class*="seg"],[class*="scorr"],[class*="-ord"]';
function flFadeCerca(){
  try{
    document.querySelectorAll(FL_FADE_AUTO).forEach(function(el){
      if (el.__flFxV !== undefined || el.offsetParent === null) return;
      const cs = getComputedStyle(el); el.__flFxV = (cs.overflowX === 'auto' || cs.overflowX === 'scroll') ? 1 : 0;
      if (el.__flFxV) el.classList.add('fl-fade-x');
    });
  }catch(_){ }
}
/* 0.9.363 (lavoro 16): "la sfumatura ai lati delle file e' ferma: c'e' da subito, non arriva dopo". Al cambio di scheda si
   calcola subito (prima arrivava con il giro dei 900 ms, perche' una scheda nascosta non ha misure) */
function flFadeOra(){ try{ flFadeCerca(); document.querySelectorAll(FL_FADE_SEL).forEach(function(el){ if (el.offsetParent !== null) flFadeX(el); }); }catch(_){ } }
document.addEventListener('fl:tab', function(){ flFadeOra(); requestAnimationFrame(flFadeOra); setTimeout(flFadeOra, 60); });
document.addEventListener('fl:screen', function(){ requestAnimationFrame(flFadeOra); });
setInterval(function(){ if (document.hidden) return; flFadeCerca(); try{ document.querySelectorAll(FL_FADE_SEL).forEach(function(el){ if (el.offsetParent !== null) flFadeX(el); }); }catch(_){ } }, 900);
(function(){
  const st = document.createElement('style');
  st.textContent = '.fl-continua-w{margin:16px 0 4px;animation:flContIn .25s ease}.fl-continua{display:block;width:100%;padding:16px;border:0;border-radius:50px;background:#0075E3;color:#fff;font:800 16px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.35)}'
    + '@keyframes flContIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}';
  document.head.appendChild(st);
})();

/* 0.9.351, Andrea: "i pallini dei caroselli si aggiornano troppo tardi: appena scorro deve accendersi quello della slide nuova".
   Il pallino seguiva la posizione, e cambiava solo a meta' strada dello scatto. Adesso, appena il dito si stacca, si capisce dove
   andra' la slide (verso cui hai spinto) e il pallino si accende subito; per lo scatto che segue resta fermo su quella */
(function(){
  const carosello = function(el){
    for (let n = el; n && n !== document.body; n = n.parentElement){
      if (n.scrollWidth > n.clientWidth + 4){ const cs = getComputedStyle(n); if ((cs.overflowX === 'auto' || cs.overflowX === 'scroll') && /x|both|inline/.test(cs.scrollSnapType || '')) return n; }
    }
    return null;
  };
  const pallini = function(c){ let d = c.nextElementSibling; if (!d || !/dot/i.test(d.className || '')) d = c.parentElement && c.parentElement.querySelector(':scope > [class*="dot"]'); return d && d.children.length >= 2 ? d : null; };
  const accendi = function(c, i){ const d = pallini(c); if (!d) return; Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); }); };
  let ini = null;
  document.addEventListener('touchstart', function(e){ const c = (e.touches.length === 1) ? carosello(e.target) : null; ini = c ? { c: c, x: e.touches[0].clientX, y: e.touches[0].clientY, sl: c.scrollLeft } : null; }, { passive: true });
  document.addEventListener('touchend', function(e){
    if (!ini) return; const o = ini; ini = null;
    const t = e.changedTouches[0], dx = t.clientX - o.x, dy = t.clientY - o.y, w = Math.max(1, o.c.clientWidth);
    if (Math.abs(dx) < 24 || Math.abs(dx) < Math.abs(dy)) return;
    const n = o.c.children.length, i0 = Math.round(o.sl / w);
    const i = Math.max(0, Math.min(n - 1, i0 + (dx < 0 ? 1 : -1)));
    o.c.__flDot = { i: i, fino: Date.now() + 800 };
    accendi(o.c, i);
  }, { passive: true });
  document.addEventListener('scroll', function(e){ const c = e.target; if (!c || !c.__flDot) return; if (Date.now() > c.__flDot.fino){ c.__flDot = null; return; } const i = c.__flDot.i; requestAnimationFrame(function(){ accendi(c, i); }); }, true);
})();

/* 0.9.367, Andrea: "ti avevo detto di non tagliare mai il testo: la text area deve essere alta quanto il placeholder" (Una nota breve,
   se vuoi..., Scrivi una frase su di te...). Ogni casella di testo vuota prende almeno l'altezza del suo placeholder intero. Fuori:
   la casella della chat (#agTesto, .ag-comp), che di proposito resta su una riga con i puntini, e chi ha data-noph. */
function flTaPh(t){
  try{
    if (!t || t.__flPh === t.placeholder + '|' + t.clientWidth || !t.placeholder || t.value || !t.clientWidth) return;
    if (t.id === 'agTesto' || t.dataset.noph != null || t.closest('.ag-comp,.cv-comp')) return;
    const prima = t.style.minHeight; t.style.minHeight = '0px';
    const h0 = t.style.height; t.style.height = 'auto';
    t.value = t.placeholder; const h = t.scrollHeight; t.value = '';
    t.style.height = h0; t.style.minHeight = prima;
    const bordi = t.offsetHeight - t.clientHeight;
    if (h + bordi > t.offsetHeight + 1) t.style.minHeight = (h + bordi) + 'px';
    t.__flPh = t.placeholder + '|' + t.clientWidth;
  }catch(_){ }
}
function flTaPhTutte(){ try{ document.querySelectorAll('textarea[placeholder]').forEach(function(t){ if (t.offsetParent !== null) flTaPh(t); }); }catch(_){ } }
(function(){
  let giro = 0;
  const fra = function(){ if (giro) return; giro = setTimeout(function(){ giro = 0; flTaPhTutte(); }, 120); };
  try{ new MutationObserver(fra).observe(document.documentElement, { childList: true, subtree: true }); }catch(_){ }
  document.addEventListener('fl:tab', fra); document.addEventListener('fl:screen', fra); window.addEventListener('resize', fra);
  document.addEventListener('input', function(e){ const t = e.target; if (t && t.tagName === 'TEXTAREA' && !t.value){ t.__flPh = ''; flTaPh(t); } }, true);
})();
