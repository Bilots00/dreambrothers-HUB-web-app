/* ===========================================================================================
   LIVELLI — l'anello intorno al ritratto, come il profilo di Skool.

   I punti vengono da ciò che l'app misura davvero: i blocchi scattati, i giorni di fila della
   Modalità severa, i minuti di FullFocus portati a termine, le sfide completate e gli alberi
   piantati. Ogni livello sblocca qualcosa di concreto (un suono di FullFocus, una durata più
   lunga, un anello diverso, una pianta rara): l'elenco è in LV_LEVELS ed è quello che il
   resto dell'app consulta (lvHas('sound:ocean'), lvMaxMinutes()).
   =========================================================================================== */

/* ------------------------------------------------------------------ la scala

   Cinquanta gradini per ciclo, con la curva quadratica di qualsiasi gioco: i primi si salgono
   in un giorno, gli ultimi costano settimane. Al cinquantesimo si ricomincia da uno con una
   stella in piu' — il prestigio — e le stelle sono venti. E' il sistema di Modern Warfare 3, e
   funziona per un motivo solo: il numero grande non e' il livello, e' quante volte hai
   ricominciato da capo dopo esserci arrivato.

   I dieci nomi di prima restano, uno ogni cinque gradini: un rango che cambia a ogni livello
   non e' un rango, e' un contatore. */

const LV_PER_CICLO = 50;
const LV_PRESTIGI = 20;
/* 40.000 e non 17.000, con esponente 1,8 e non 2. Con la scala di prima il livello 13
   costava 1.020 punti e una decisione ne dava 300: dieci livelli in un tocco. Adesso:
   liv. 2 = 36, liv. 5 = 445, liv. 13 = 3.184, liv. 30 = 16.700, liv. 50 = 40.000.
   I primi gradini in un pomeriggio, dal ventesimo in poi una settimana l'uno. */
const LV_XP_CICLO = 40000;
const LV_ESP = 1.8;

const LV_RANGHI = [
  { name: 'Seme',        perk: 'Suoni FullFocus: Pioggia e Rumore bianco', grants: ['sound:rain', 'sound:white'] },
  { name: 'Germoglio',   perk: 'Suono Oceano in FullFocus',                grants: ['sound:ocean'] },
  { name: 'Esploratore', perk: 'Suono Vento e anello d\'argento',          grants: ['sound:wind', 'ring:silver'] },
  { name: 'Guardiano',   perk: 'Suono Fuoco e sessioni fino a 120 minuti', grants: ['sound:fire', 'minutes:120'] },
  { name: 'Astronauta',  perk: 'Suono Foresta notturna e anello d\'oro',   grants: ['sound:night', 'ring:gold'] },
  { name: 'Stratega',    perk: 'Stella rara in Full Focus',                 grants: ['plant:rare'] },
  { name: 'Maestro',     perk: 'Suono Bosco',                            grants: ['sound:cafe'] },
  { name: 'Mentore',     perk: 'Sessioni fino a 180 minuti',               grants: ['minutes:180'] },
  { name: 'Leggenda',    perk: 'Anello arcobaleno',                        grants: ['ring:rainbow'] },
  { name: 'Sognatore',   perk: 'Cornice animata e titolo Sognatore',       grants: ['ring:animated', 'title:sognatore'] }
];

/* La curva: xp(n) = XP_CICLO * ((n-1)/49)^2. Il primo gradino costa zero, il cinquantesimo
   tutto il ciclo, e in mezzo la salita accelera invece di restare piatta. */
const LV_LEVELS = (function(){
  const out = [];
  for (let n = 1; n <= LV_PER_CICLO; n++){
    const r = LV_RANGHI[Math.min(LV_RANGHI.length - 1, Math.floor((n - 1) / 5))];
    out.push({
      n: n,
      xp: Math.round(LV_XP_CICLO * Math.pow((n - 1) / (LV_PER_CICLO - 1), LV_ESP)),
      name: r.name,
      /* Il vantaggio si sblocca al PRIMO gradino di ogni rango: negli altri quattro il rango
         resta lo stesso e non si promette niente di nuovo. */
      perk: (n - 1) % 5 === 0 ? r.perk : '',
      grants: (n - 1) % 5 === 0 ? r.grants : []
    });
  }
  return out;
})();
const LV_CHALLENGES = [
  { id: 'first_block', name: 'Il primo blocco',      hint: 'Crea un programma o riempi il Blocco rapido', pts: 20 },
  { id: 'why',         name: 'Il tuo perché',        hint: 'Metti l\'immagine del perché in Modalità severa', pts: 10 },
  { id: 'first_ff',    name: 'Prima concentrazione', hint: 'Completa una sessione FullFocus', pts: 30 },
  { id: 'ff_10',       name: 'Dieci sessioni',       hint: 'Completa dieci sessioni FullFocus', pts: 100 },
  { id: 'streak_7',    name: 'Una settimana di fila', hint: 'Sette giorni con la Modalità severa attiva', pts: 50 },
  { id: 'streak_30',   name: 'Un mese di fila',      hint: 'Trenta giorni con la Modalità severa attiva', pts: 150 },
  { id: 'blocks_100',  name: 'Cento tentazioni',     hint: 'Cento blocchi scattati', pts: 50 },
  { id: 'tree',        name: 'Un albero vero',       hint: 'Pianta il primo albero dal tuo cielo', pts: 200 },
  { id: 'mantra_7',    name: 'Sette volte il perché', hint: 'Ascolta il tuo mantra sette giorni di fila', pts: 250 },
  { id: 'renew_1',     name: 'Ci hai rimesso la firma', hint: 'Rinnova la Modalità severa quando scade', pts: 300 },
  { id: 'renew_3',     name: 'Tre volte di fila',     hint: 'Rinnova la Modalità severa tre volte', pts: 800 }
];
const LV = { xp: 0, level: 1, parts: null, at: 0 };

function lvRead(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }

/* The figures, from the data the app already keeps. Async only for the block history. */
async function lvCompute(){
  const parts = { blocks: 0, streak: 0, ffMin: 0, ffSessions: 0, trees: 0, mantraDays: 0, mantraTotal: 0, decisions: 0, votes: 0, done: [] };
  let hist = [];
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInsights){
    try{ const r = await NATIVE.getInsights({ days: 400 }); hist = (r && r.history) || []; }catch(_){ hist = []; }
  }
  parts.blocks = hist.reduce((a, h) => a + (h.blocks || 0), 0);
  const st = lvRead('fl_sev_streak', null);
  if (st && st.start && typeof blkDaysBetween === 'function' && typeof blkToday === 'function') parts.streak = Math.max(1, blkDaysBetween(st.start, blkToday()) + 1);
  const ff = lvRead('fl_ff_hist', []);
  ff.forEach(s => { if (s && s.ok){ parts.ffSessions++; parts.ffMin += (s.min || 0); } });
  parts.trees = (lvRead('fl_trees', []) || []).length;
  /* LE PROVE IN FOTO: facoltative, e valgono esperienza (non punti della partita). */
  try{
    const meta = lvRead('fl_notes_meta', {}) || {};
    parts.prove = Object.keys(meta).filter(function(k){ return meta[k] && meta[k].foto; }).length;
  }catch(_){ parts.prove = 0; }
  if (typeof decPoints === 'function'){
    /* Ogni voto tagliato a ±60 PRIMA di sommarlo: i voti vecchi sono registrati a 300, e
       lasciarli pesare per intero vorrebbe dire che chi ha gia' votato resta dieci livelli
       sopra a chi vota da domani con la scala nuova. */
    let dec = 0;
    try{ (decLog().votes || []).forEach(function(v){ dec += Math.max(-60, Math.min(60, +v.pts || 0)); }); }
    catch(_){ dec = decPoints(); }
    parts.decisions = dec;
    parts.votes = decCount(true);
    /* i rinnovi: solo le firme della Modalita' severa (prima ogni "si'" contava, anche la riga messa sul foglio) */
    try{ parts.firme = (decLog().votes || []).filter(function(v){ return v && v.yes && (v.kind === 'strict' || v.kind === 'blinda'); }).length; }catch(_){ parts.firme = 0; }
  }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getMantraLog){
    try{ const m = await NATIVE.getMantraLog(); parts.mantraDays = (m && m.days) || 0; parts.mantraTotal = (m && m.total) || 0; }catch(_){ }
  }

  const hasBlock = (typeof PROGRAMS !== 'undefined' && PROGRAMS && PROGRAMS.length > 0)
    || (typeof QUICK !== 'undefined' && QUICK && ((QUICK.apps || []).length + (QUICK.sites || []).length + (QUICK.keywords || []).length) > 0);
  let why = ''; try{ why = localStorage.getItem('fl_why_img') || ''; }catch(_){ }
  const done = {
    first_block: hasBlock, why: !!why, first_ff: parts.ffSessions >= 1, ff_10: parts.ffSessions >= 10,
    streak_7: parts.streak >= 7, streak_30: parts.streak >= 30, blocks_100: parts.blocks >= 100, tree: parts.trees >= 1,
    mantra_7: parts.mantraDays >= 7,
    /* 0.9.264, Andrea: firmare la Modalita' severa nel giro del Genio portava dal livello 1 al 4. La prima
       firma contava gia' come "rinnovo" (300 punti): rinnovare vuol dire firmare DI NUOVO, quindi dalla seconda. */
    renew_1: (parts.firme || 0) >= 2, renew_3: (parts.firme || 0) >= 4
  };
  parts.done = LV_CHALLENGES.filter(c => done[c.id]).map(c => c.id);
  /* Ascoltare il mantra è il gesto che costa meno e vale di più: è l'unico momento in cui si
     sceglie a mente fredda di ricordarsi perché si è cominciato. Quaranta punti al giorno di
     striscia e quindici a ascolto lo mettono sopra a tutto il resto. */
  /* Le decisioni pesano più di tutto il resto messo insieme, ed è giusto così: un giorno di
     blocchi è un'abitudine che gira da sola, mentre firmare di nuovo quando potresti smettere
     è l'unico momento in cui scegli davvero. Il rifiuto toglie punti, perché anche quello è
     una scelta e va contata come tale. */
  /* Le protezioni serie spese si pagano qui. A mano costano poco, in automatico quattro
     volte tanto: la differenza fra "oggi non ce la faccio, lo dico" e un giorno passato senza
     accorgersene. Il conto lo tiene start.js in fl_sp_toll, che sa quale delle due e' stata. */
  const toll = lvRead('fl_sp_toll', 0) || 0;

  /* I GIORNI CON IL PIANO: il gesto piu' piccolo e piu' importante di tutta l'app, e finora
     non valeva un punto. Scrivere stasera l'unica cosa di domani e' l'unica cosa che una
     persona puo' fare adesso, sempre, anche in una giornata storta. */
  let pianiFatti = 0;
  try{
    const m = JSON.parse(localStorage.getItem('fl_plan_days') || '{}') || {};
    pianiFatti = Object.keys(m).length;
  }catch(_){ }

  /* QUELLO CHE NON VALE PIU' NIENTE: `parts.blocks`.
     Un punto per blocco scattato pagava la persona ogni volta che provava ad aprire l'app che
     si era vietata — piu' cedevi, piu' salivi. Il numero resta contato nel tabellone
     dell'arbitro, che e' il posto giusto per una tentazione: li' dice qualcosa, qui diceva
     il contrario di quello che serviva.

     E gli ascolti del mantra sono scesi da quindici punti a due: la costanza vale (i GIORNI
     di fila), la ripetizione nello stesso giorno no — quindici punti a tocco erano una
     macchinetta da premere. */
  let xp = parts.streak * 8
         + parts.ffMin * 1 + parts.ffSessions * 20
         + parts.trees * 150
         + parts.mantraDays * 10 + parts.mantraTotal * 2
         + pianiFatti * 12
         + (parts.prove || 0) * 25
         + parts.decisions - toll;
  /* il sentiero di oggi (sentiero.js): tappe fatte e scrigni aperti, gia' contati li' */
  try{ if (typeof snXp === 'function') xp += snXp(); }catch(_){ }
  try{ if (typeof sdXp === 'function') xp += sdXp(); }catch(_){ }
  LV_CHALLENGES.forEach(c => { if (done[c.id]) xp += c.pts; });
  /* 0.9.262, Andrea: "Ricomincia da capo" deve riportare il livello all'inizio. Il livello e' la somma di tante
     storie dell'app, e il reset ne toglieva solo alcune (da 14 si scendeva a 12). Adesso al reset si segna lo
     ZERO: i punti che c'erano in quel momento diventano la base, e da li' si riparte dal livello 1. */
  try{
    if (localStorage.getItem('fl_lv_azzera')){ localStorage.setItem('fl_lv_base', String(Math.max(0, Math.round(xp)))); localStorage.removeItem('fl_lv_azzera'); }
    xp -= (+localStorage.getItem('fl_lv_base') || 0);
  }catch(_){ }
  LV.parts = parts; LV.xp = Math.max(0, Math.round(xp)); LV.at = Date.now();
  lvTelefono();

  /* Il ciclo: quanti giri interi sono stati fatti (il prestigio) e a che punto e' quello in
     corso. I punti NON si azzerano: azzerarli vorrebbe dire cancellare quello che e' successo,
     e qui l'unica cosa che conta e' proprio che sia successo. */
  const cicli = Math.min(LV_PRESTIGI, Math.floor(LV.xp / LV_XP_CICLO));
  const resto = LV.xp - cicli * LV_XP_CICLO;
  let lvl = 1;
  LV_LEVELS.forEach(l => { if (resto >= l.xp) lvl = l.n; });
  const before = LV.level;
  LV.prestigio = cicli;
  LV.restoXp = resto;
  LV.level = cicli >= LV_PRESTIGI ? LV_PER_CICLO : lvl;
  lvNotice(before);
  try{ lvFestaControlla(); }catch(_){ }
  return LV;
}
/* ---------------------------------------------------------------------------------------
   UN LIVELLO SOLO FRA TELEFONO E COMPUTER (0.9.306)

   Andrea: "il livello del profilo sul PC e' diverso da quello del telefono, e sono collegati allo stesso account".
   LA CAUSA. Il livello non viaggia: ogni dispositivo lo ricalcola da solo (lvCompute) dai pezzi che ha in mano. Il
   computer riceve dal telefono le chiavi dell'app (lo specchio, specchio-web.js), ma due pezzi degli XP non sono
   chiavi: i giorni e gli ascolti del mantra (getMantraLog) e i blocchi scattati (getInsights, la sfida "Cento
   tentazioni") li sa solo il motore del telefono, e sul computer valevano zero. Il computer contava meno XP e
   mostrava un livello piu' basso.
   LA DECISIONE: la fonte della verita' sono gli XP del telefono. Il telefono, che misura tutto, scrive i suoi XP in
   fl_lv_tel (una chiave del viaggio: lo specchio la porta al computer entro mezzo minuto, regole-sync.js); il
   computer, quando la trova, mostra quelli. Non si sommano: quello che si fa sul computer (le tappe, le sessioni)
   vive in chiavi che lo specchio riporta dal telefono, quindi una somma conterebbe due volte la stessa vita.
   Senza un telefono collegato il computer conta da solo, come prima.
   --------------------------------------------------------------------------------------- */
const LV_TEL_KEY = 'fl_lv_tel';
function lvSuComputer(){
  try{ if (typeof swSpecchio === 'function') return swSpecchio(); }catch(_){ }
  try{ return typeof pcQui === 'function' && pcQui() === 'desktop'; }catch(_){ return false; }
}
function lvTelefono(){
  try{
    if (lvSuComputer()){
      const t = JSON.parse(localStorage.getItem(LV_TEL_KEY) || 'null');
      if (t && typeof t.xp === 'number' && isFinite(t.xp) && t.xp >= 0){
        LV.xpQui = LV.xp; LV.xp = Math.round(t.xp); LV.daTelefono = true;
        /* anche "Da dove vengono i punti" e le sfide sono quelli del telefono: le righe tornano con il totale */
        if (t.parts && typeof t.parts === 'object') LV.parts = Object.assign({}, LV.parts || {}, t.parts);
      }
      return;
    }
    const t = JSON.parse(localStorage.getItem(LV_TEL_KEY) || 'null');
    const parts = JSON.stringify(LV.parts || {});
    if (!t || t.xp !== LV.xp || JSON.stringify(t.parts || {}) !== parts) localStorage.setItem(LV_TEL_KEY, JSON.stringify({ xp: LV.xp, at: Date.now(), parts: LV.parts || {} }));
  }catch(_){ }
}
function lvInfo(){
  const cur = LV_LEVELS[LV.level - 1], next = LV_LEVELS[LV.level] || null;
  const resto = (typeof LV.restoXp === 'number') ? LV.restoXp : LV.xp;
  const span = next ? next.xp - cur.xp : 1;
  const pct = next ? Math.min(100, Math.round((resto - cur.xp) / span * 100)) : 100;
  const pres = LV.prestigio || 0;
  return {
    level: LV.level, name: cur.name, xp: LV.xp, next: next,
    toNext: next ? next.xp - resto : 0, pct: pct,
    prestigio: pres,
    /* Come si dice a voce: «prestigio 3, livello 12». Senza stelle, «livello 12» al terzo giro
       sembrerebbe un passo indietro rispetto al cinquanta di prima. */
    etichetta: (pres ? 'prestigio ' + pres + ' \u00b7 ' : '') + 'livello ' + LV.level
      + (pres >= LV_PRESTIGI ? ' \u00b7 massimo' : '')
  };
}
/* What the levels have unlocked so far: lvHas('sound:ocean'), lvMaxMinutes(). */
function lvHas(grant){
  for (let i = 0; i < LV.level; i++) if (LV_LEVELS[i].grants.indexOf(grant) >= 0) return true;
  try{ if ((JSON.parse(localStorage.getItem('fl_grants_extra') || '[]') || []).indexOf(grant) >= 0) return true; }catch(_){ }
  return false;
}
/** Uno sblocco regalato fuori dai livelli (il tassello del giorno, domande.js). */
function lvGrantExtra(grant){
  try{
    const l = JSON.parse(localStorage.getItem('fl_grants_extra') || '[]') || [];
    if (l.indexOf(grant) < 0){ l.push(grant); localStorage.setItem('fl_grants_extra', JSON.stringify(l)); }
  }catch(_){ }
}
function lvMaxMinutes(){ return lvHas('minutes:180') ? 180 : (lvHas('minutes:120') ? 120 : 90); }
function lvRing(){ return lvHas('ring:rainbow') ? 'rainbow' : (lvHas('ring:gold') ? 'gold' : (lvHas('ring:silver') ? 'silver' : 'blue')); }
function lvLevelFor(grant){ const l = LV_LEVELS.filter(x => x.grants.indexOf(grant) >= 0)[0]; return l ? l.n : 1; }

/* A level reached is told once, with what it unlocks. */
function lvNotice(before){
  let seen = 1; try{ seen = +localStorage.getItem('fl_lv_seen') || 1; }catch(_){ }
  if (LV.level > seen){
    try{ localStorage.setItem('fl_lv_seen', String(LV.level)); }catch(_){ }
    /* Il livello nuovo non lo dice piu' un toast: lo festeggia il popup qui sotto
       (lvFestaControlla), che sa anche del prestigio e non scatta al primo avvio. */
  }
}
async function lvBump(){
  const prima = LV.level;
  await lvCompute(); lvPaintProfile();
  /* si sente anche con le mani (0.9.203): un livello in piu' e' un evento, non una riga */
  /* se il popup del livello e' appena partito, vibra lui insieme ai coriandoli */
  try{ if (LV.level > prima && !(LV.festaAt && Date.now() - LV.festaAt < 4000)) flVibra([30, 40, 30, 40, 90]); }catch(_){ }
  if (typeof frSyncMaybe === 'function') frSyncMaybe();
}

/* ---------------------------------------------------------------------------------------
   The ring around the portrait, and the line under the name
   --------------------------------------------------------------------------------------- */
function lvRingSvg(pct, size, stroke){
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const ring = lvRing();
  const col = ring === 'gold' ? '#F5B301' : ring === 'silver' ? '#C9D3E0' : ring === 'rainbow' ? 'url(#lvRainbow)' : '#5B8DEF';
  return '<svg class="lv-ring' + (lvHas('ring:animated') ? ' anim' : '') + '" viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '">'
    + '<defs><linearGradient id="lvRainbow" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3F9FF4"/><stop offset=".5" stop-color="#0075E3"/><stop offset="1" stop-color="#E63946"/></linearGradient></defs>'
    + '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="' + stroke + '"/>'
    + '<circle class="lv-prog" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="' + stroke + '" stroke-linecap="round"'
    + ' stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + (c * (1 - pct / 100)).toFixed(1) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/>'
    + '</svg>';
}
/* The level and the points are not printed under the name: they are behind the badge. One
   tap shows them, another (or the page of the levels) takes them away again. */
function lvToggleLine(){
  const line = document.querySelector('.prof-hero .lv-line');
  if (!line){ lvOpen(); return; }
  line.hidden = !line.hidden;
  if (!line.hidden){
    clearTimeout(lvToggleLine.t);
    lvToggleLine.t = setTimeout(() => { line.hidden = true; }, 9000);
  }
}
async function lvPaintProfile(){
  const av = document.getElementById('profAv');
  if (!av) return;
  if (!LV.parts || Date.now() - LV.at > 30000) await lvCompute();
  const info = lvInfo();
  let wrap = av.parentElement && av.parentElement.classList.contains('lv-wrap') ? av.parentElement : null;
  if (!wrap){
    wrap = document.createElement('div'); wrap.className = 'lv-wrap';
    av.parentNode.insertBefore(wrap, av);
    wrap.appendChild(av);
  }
  let ring = wrap.querySelector('.lv-ring'); if (ring) ring.remove();
  wrap.insertAdjacentHTML('beforeend', lvRingSvg(info.pct, 104, 6));
  let badge = wrap.querySelector('.lv-badge');
  if (!badge){ badge = document.createElement('b'); badge.className = 'lv-badge'; badge.onclick = function(e){ e.stopPropagation(); lvToggleLine(); }; wrap.appendChild(badge); }
  /* Il pallino sull'avatar: il livello, e se ci sono stelle il numero del prestigio davanti.
     «3·12» sta in due caratteri e mezzo e dice piu' di «12». */
  badge.textContent = info.prestigio ? info.prestigio + '·' + info.level : info.level;
  const hero = wrap.closest('.prof-hero');
  let line = hero ? hero.querySelector('.lv-line') : null;
  if (!line && hero){
    line = document.createElement('div'); line.className = 'lv-line'; line.hidden = true; line.onclick = lvOpen;
    // above the name: the level is what the ring says, the name is who it belongs to
    const name = hero.querySelector('h2');
    if (name) hero.insertBefore(line, name); else hero.appendChild(line);
  }
  if (line) line.innerHTML = '<b>Livello ' + info.level + ' · ' + esc(info.name) + '</b>'
    + (info.next ? '<small>' + info.toNext + ' punti al prossimo livello</small>' : '<small>Livello massimo raggiunto</small>');
}

/* ---------------------------------------------------------------------------------------
   The Levels page: where the points come from, what each level unlocks, the challenges
   --------------------------------------------------------------------------------------- */
registerScreen('s-levels', `
  <div class="topbar"><button class="iconbtn" onclick="lvClose()">‹</button><b class="blk-title">Il tuo livello</b></div>
  <div id="lvBody"></div>
  <div class="spacer"></div>
`, { back: 's-home' });

async function lvOpen(){ goId('s-levels'); await lvCompute(); lvPaintPage(); }
function lvClose(){ if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); if (typeof switchTab === 'function') switchTab('profilo'); } }
/** Le stelle del prestigio: fino a dieci disegnate, oltre si scrive il numero. */
function lvStelle(n){
  if (n <= 0) return '';
  if (n <= 10) return new Array(n + 1).join('★');
  return '★ × ' + n;
}

function lvPaintPage(){
  const box = document.getElementById('lvBody'); if (!box) return;
  const info = lvInfo(), p = LV.parts || {};
  /* L'elenco dice esattamente cosa paga, e quanto. I blocchi scattati NON ci sono piu': erano
     la riga che premiava il tentativo di aprire l'app vietata. Restano contati nel tabellone
     dell'arbitro, dove un tentativo bloccato vuol dire qualcosa. */
  let piani = 0;
  try{ piani = Object.keys(JSON.parse(localStorage.getItem('fl_plan_days') || '{}') || {}).length; }catch(_){ }
  const rows = [
    ['📝', 'Giorni chiusi con il piano di domani', piani + ' × 12', piani * 12],
    ['🌱', 'Minuti di FullFocus completati', (p.ffMin || 0) + ' × 1', (p.ffMin || 0)],
    ['🎯', 'Sessioni portate a termine', (p.ffSessions || 0) + ' × 20', (p.ffSessions || 0) * 20],
    ['🔒', 'Giorni di fila in Modalità severa', (p.streak || 0) + ' × 8', (p.streak || 0) * 8],
    ['🔥', 'Giorni di fila con il mantra', (p.mantraDays || 0) + ' × 10', (p.mantraDays || 0) * 10],
    ['🌳', 'Alberi veri piantati', (p.trees || 0) + ' × 150', (p.trees || 0) * 150]
  ];
  const chDone = p.done || [];
  box.innerHTML = '<div class="lv-hero"><div class="lv-wrap big"><div class="lv-big">' + info.level + '</div>' + lvRingSvg(info.pct, 132, 8) + '</div>'
    + (info.prestigio ? '<div class="lv-pres">' + lvStelle(info.prestigio) + '</div>' : '')
    + '<h2>Livello ' + info.level + ' · ' + esc(info.name) + '</h2>'
    + '<div class="lv-bar"><i style="width:' + info.pct + '%"></i></div>'
    + '<small>' + info.xp + ' punti' + (info.next ? ' · ' + info.toNext + ' al livello ' + info.next.n
        : ' · fine del ciclo: il prossimo punto e\' un prestigio') + '</small>'
    + '<p class="lv-pres-txt">Prestigio <b>' + (info.prestigio || 0) + '</b> di ' + LV_PRESTIGI
    +   ' · cinquanta livelli per ciclo. Al cinquantesimo si ricomincia da uno con una stella in piu\'.</p>'
    + '</div>'
    + '<div class="sect"><b>Da dove vengono i punti</b></div>'
    + rows.map(r => '<div class="lv-row"><span class="em">' + r[0] + '</span><div><b>' + r[1] + '</b><small>' + r[2] + '</small></div><b class="pt">' + r[3] + '</b></div>').join('')
    + '<div class="sect"><b>Sfide</b></div>'
    + LV_CHALLENGES.map(c => { const ok = chDone.indexOf(c.id) >= 0; return '<div class="lv-row' + (ok ? ' ok' : '') + '"><span class="em">' + (ok ? '✅' : '⬜') + '</span><div><b>' + esc(c.name) + '</b><small>' + esc(c.hint) + '</small></div><b class="pt">' + (ok ? '+' : '') + c.pts + '</b></div>'; }).join('')
    + '<div class="sect"><b>I livelli e cosa sbloccano</b></div>'
    + LV_LEVELS.map(l => '<div class="lv-row' + (l.n <= info.level ? ' ok' : ' locked') + '"><span class="em">' + (l.n <= info.level ? '🔓' : '🔒') + '</span><div><b>Livello ' + l.n + ' · ' + esc(l.name) + '</b><small>' + esc(l.perk) + '</small></div><b class="pt">' + l.xp + '</b></div>').join('');
}

(function lvStyle(){
  const css = [
    '.lv-wrap{position:relative;display:inline-block;width:104px;height:104px;vertical-align:top;z-index:2;margin-bottom:14px}',
    '.lv-badge{z-index:3}',
    '.lv-wrap .av{position:absolute;left:6px;top:6px;margin:0}',
    '.prof-sky .prof-hero .lv-wrap .av{width:92px;height:92px;font-size:38px}',
    '.lv-wrap .lv-ring{position:absolute;left:0;top:0;pointer-events:none}',
    '.lv-ring.anim .lv-prog{animation:lvPulse 2.4s ease-in-out infinite}',
    '@keyframes lvPulse{0%,100%{opacity:1}50%{opacity:.55}}',
    /* the badge sits ON the ring, at one o'clock: under the portrait there is the name, and
       at five o'clock it landed on the PREMIUM ribbon */
    '.lv-badge{position:absolute;right:-6px;top:-4px;width:40px;height:40px;border-radius:50%;background:#3F7BEA;color:#fff;border:3px solid #FFFFFF;',
    '  display:flex;align-items:center;justify-content:center;font:800 18px var(--font-display);cursor:pointer;box-shadow:0 6px 16px rgba(0,0,0,.4)}',
    '.lv-line{margin:6px 0 10px;cursor:pointer;animation:ufSinceIn .45s ease-out both}',
    '.lv-line[hidden]{display:none}',
    '.lv-line b{display:block;font:800 14px var(--font-display);color:#9EC1FF}',
    '.lv-line small{display:block;font:500 12px var(--font-body);color:rgba(255,255,255,.75);margin-top:2px}',
    '.lv-hero{text-align:center;padding:10px 0 6px}',
    '.lv-wrap.big{width:132px;height:132px}',
    '.lv-big{position:absolute;left:8px;top:8px;width:116px;height:116px;border-radius:50%;background:var(--blue);color:#fff;display:flex;align-items:center;justify-content:center;font:800 48px var(--font-display)}',
    '.lv-wrap.big .lv-ring circle:first-of-type{stroke:rgba(0,30,68,.1)}',
    '.lv-hero h2{font:800 22px var(--font-display);font-style:italic;color:var(--navy);margin:14px 0 8px}',
    /* Le stelle sopra al nome del rango: sono la cosa che si guarda per prima quando ci sono,
       e l'unica differenza visibile fra chi ha ricominciato tre volte e chi zero. */
    '.lv-pres{margin-top:12px;font-size:17px;letter-spacing:3px;color:#F5C542}',
    '.lv-pres-txt{margin:12px 26px 0;font:500 11.5px/1.6 var(--font-body);color:var(--muted)}',
    '.lv-pres-txt b{color:var(--navy);font-weight:800}',
    'body.dark .lv-pres-txt b{color:#fff}',
    '.lv-bar{height:8px;border-radius:99px;background:rgba(0,30,68,.08);overflow:hidden;margin:0 30px}',
    '.lv-bar i{display:block;height:100%;background:var(--blue);border-radius:99px}',
    '.lv-hero small{display:block;margin-top:8px;font:600 12px var(--font-body);color:var(--muted)}',
    '.lv-row{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin-bottom:8px}',
    '.lv-row .em{font-size:20px;line-height:1;flex:none}',
    '.lv-row > div{flex:1;min-width:0}',
    '.lv-row b{display:block;font:700 13.5px var(--font-body);color:var(--navy)}',
    '.lv-row small{display:block;font:500 11.5px var(--font-body);color:var(--muted);margin-top:2px}',
    '.lv-row .pt{flex:none;font:800 14px var(--font-display);color:var(--blue)}',
    '.lv-row.locked{opacity:.6}',
    'body.dark .lv-row{background:#12203A;border-color:#22345A}body.dark .lv-row b,body.dark .lv-hero h2{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();

/* ===========================================================================================
   IL LIVELLO NUOVO SI FESTEGGIA (0.9.214), come su Meditopia: popup al centro sopra lo sfondo
   scurito, coriandoli sparati dal basso, il distintivo del rango, «Livello N», una frase scritta
   per QUEL livello e «Condividi».

   UNA VOLTA PER LIVELLO. In fl_lv_festa c'e' l'ultimo livello festeggiato, contato sul ciclo
   intero (prestigio × 50 + livello): al prestigio il livello torna a 1, e senza contare il
   ciclo il livello 1 con una stella sembrerebbe un passo indietro. Se i punti scendono (un
   rifiuto, una protezione spesa) il segno resta dov'era: riprendere un livello gia' festeggiato
   non si festeggia di nuovo.

   MAI AL PRIMO AVVIO. Chiave assente = prima volta che questo codice gira (installazione nuova
   o aggiornamento): si segna il livello di adesso in silenzio. Lo stesso durante l'onboarding.
   =========================================================================================== */
const LV_FESTA_K = 'fl_lv_festa';
/* il distintivo di ogni rango (Seme, Germoglio, ... Sognatore) */
const LV_FESTA_EMOJI = ['🌱', '🌿', '🧭', '🛡️', '🚀', '♟️', '🎓', '🤝', '🏆', '🌠'];
/* Una frase per livello (l'indice 0 e' il livello 1, che si raggiunge solo con il prestigio).
   Al primo gradino di un rango la frase non ripete il nome del rango: e' gia' il titolo sopra.
   Il soggetto e' sempre «tu», e la frase dice cosa e' cambiato a quel gradino. */
const LV_FESTA_FRASI = [
  'Ricominci dal livello 1 con una stella in più: il giro che hai chiuso resta tuo.',
  /* 0.9.293, Andrea: "dice che ho riaperto l'app il giorno dopo, ma l'ho appena aperta per la prima volta" */
  'Hai fatto il primo passo vero: è quello che quasi tutti rimandano.',
  'La tua rotta adesso ha un primo tratto segnato, non solo una destinazione.',
  'Il tuo telefono comincia a lavorare per il tuo sogno, non contro.',
  'Cinque livelli: la concentrazione per te non è più un esperimento.',
  'Quello che scrivi la sera nel piano di domani, adesso lo fai davvero.',
  'Sette gradini: la tua giornata comincia dall’unica cosa, non dalle notifiche.',
  'Otto livelli: il tuo sogno riceve ore vere, non solo pensieri prima di dormire.',
  'Il livello 9 lo raggiunge chi ha smesso di aspettare il lunedì giusto per cominciare.',
  'Dieci livelli: la tua costanza adesso pesa più della voglia del giorno.',
  'Hai lasciato i primi giorni alle spalle, da qui la strada la scegli tu.',
  'Dodici: arrivi al Full Focus con una cosa sola in testa, e si vede da quanto dura.',
  'Tredici gradini: i tuoi giorni chiusi con un piano sono più di quelli lasciati al caso.',
  'Quattordici: quando la giornata va storta, sai qual è il passo minimo per non perderla.',
  'Quindici livelli: la tua rotta ha superato il primo tratto in salita.',
  'Proteggi le tue ore migliori come si protegge un appuntamento.',
  'Diciassette: il tempo che finiva nello scroll adesso ha un nome nel tuo piano.',
  'Diciotto livelli: per te la Modalità severa è una scelta, non una punizione.',
  'Diciannove: le tue regole reggono anche nei giorni in cui non hai voglia di rispettarle.',
  'Venti livelli: da qui ogni gradino costa una settimana, e tu l’hai già messa in conto.',
  'Il tuo sogno ha smesso di essere lontano, adesso ha una data stimata.',
  'Ventidue: le tue sessioni portate a termine sono più di quelle interrotte.',
  'Ventitré: il tuo piano di domani lo scrivi in due minuti, perché sai cosa conta.',
  'Ventiquattro: la tua settimana ha un ritmo che riconosci anche senza guardare l’app.',
  'Metà ciclo: venticinque livelli su cinquanta, saliti un giorno alla volta.',
  'Scegli cosa non fare con la stessa cura con cui scegli cosa fare.',
  'Ventisette: le distrazioni ti rubano meno tempo, perché le vedi arrivare prima.',
  'Ventotto: i tuoi giorni migliori non sono più un caso, sai come ripeterli.',
  'Ventinove livelli: chi ti guarda vede una persona costante, e ha ragione.',
  'Trenta livelli: settimane di lavoro vero dietro a un numero solo.',
  'Quello che all’inizio ti costava fatica adesso lo fai senza pensarci.',
  'Trentadue: il tuo Full Focus parte prima che arrivi la voglia di rimandare.',
  'Trentatré: le tue giornate storte durano un giorno, non una settimana.',
  'Trentaquattro: il tuo piano non ha più bisogno di promemoria, ci pensi tu.',
  'Trentacinque livelli: mesi di sere con il piano scritto, una sopra l’altra.',
  'Quello che sai fare adesso puoi insegnarlo a un amico, dal primo blocco.',
  'Trentasette: le tue regole non le rinegozi più ogni mattina.',
  'Trentotto: il tempo che hai protetto in questi mesi vale più di una giornata perfetta.',
  'Trentanove: chi parte oggi da zero guarda il tuo numero per capire che si può.',
  'Quaranta livelli: dieci alla fine del ciclo, e ognuno è una settimana vera.',
  'Per arrivare qui sono servite centinaia di sere con il piano già scritto.',
  'Quarantadue: per te la concentrazione è il modo normale di lavorare, non l’eccezione.',
  'Quarantatré: la Modalità severa per te è una cosa che scegli, non che subisci.',
  'Quarantaquattro: le scuse che ti fermavano un anno fa oggi non le riconosci più.',
  'Quarantacinque livelli: cinque gradini al prestigio, e la stella si vede già.',
  'Il titolo che arriva solo a chi il sogno l’ha messo in calendario.',
  'Quarantasette: la tua rotta è quasi tutta disegnata dai passi che hai già fatto.',
  'Quarantotto: chi guarda il tuo profilo vede mesi di lavoro, non un colpo di fortuna.',
  'Un livello al prestigio: il prossimo ti fa ripartire da uno, con una stella.',
  'Cinquanta: hai chiuso il ciclo. Al prossimo passo ricominci con una stella, e il conto resta.'
];
function lvFestaAssoluto(){ return (LV.prestigio || 0) * LV_PER_CICLO + LV.level; }
function lvFestaControlla(){
  const ora = lvFestaAssoluto();
  let ultimo = null;
  try{ const v = localStorage.getItem(LV_FESTA_K); ultimo = (v === null || v === '') ? null : +v; }catch(_){ return; }
  let onb = true; try{ onb = localStorage.getItem('fl_onboarded') === '1'; }catch(_){ }
  /* 0.9.293: durante il giro del Genio e nel giorno dell'installazione i livelli si segnano in silenzio: nessuna festa
     per punti presi mentre si sta ancora imparando dove sono le cose */
  try{
    if (typeof GT !== 'undefined' && GT.on) onb = false;
    const tf = (typeof gnDati === 'function') ? +gnDati().tourFatto || 0 : 0;
    if (!tf || new Date(tf).toDateString() === new Date().toDateString()) onb = false;
  }catch(_){ }
  if (ultimo === null || !isFinite(ultimo) || !onb){
    if (ultimo === null || !isFinite(ultimo) || ora > ultimo){ try{ localStorage.setItem(LV_FESTA_K, String(ora)); }catch(_){ } }
    return;
  }
  if (ora <= ultimo) return;
  if (document.getElementById('lvFesta')) return;
  /* 0.9.264, Andrea: UN LIVELLO ALLA VOLTA. Se i punti ne fanno salire piu' d'uno, si festeggia il
     prossimo; quando la festa si chiude arriva quello dopo (lvFestaChiudi richiama questa funzione). */
  const prossimo = ultimo + 1;
  try{ localStorage.setItem(LV_FESTA_K, String(prossimo)); }catch(_){ }
  LV.festaAt = Date.now();
  const dati = { level: ((prossimo - 1) % LV_PER_CICLO) + 1, prestigio: Math.floor((prossimo - 1) / LV_PER_CICLO), salti: 1 };
  /* a schermo spento si aspetta che torni visibile: un popup che nessuno vede e' un popup perso */
  const via = function(){ setTimeout(function(){ lvFestaApri(dati); }, 450); };
  if (document.hidden){
    const f = function(){ if (!document.hidden){ document.removeEventListener('visibilitychange', f); via(); } };
    document.addEventListener('visibilitychange', f);
  } else via();
}
function lvFestaFrase(level, prestigio){
  if (level === 1 && prestigio > 0) return LV_FESTA_FRASI[0];
  return LV_FESTA_FRASI[Math.max(0, Math.min(LV_FESTA_FRASI.length - 1, level - 1))];
}
function lvFestaEmoji(level){ return LV_FESTA_EMOJI[Math.min(LV_FESTA_EMOJI.length - 1, Math.floor((level - 1) / 5))]; }
/** Il popup. dati = { level, prestigio, salti }; senza argomenti mostra il livello di adesso. */
function lvFestaApri(dati){
  /* 0.9.290, Andrea: "per il livello sbloccato voglio la vibrazione" */
  try{ flVibra([30, 60, 30, 60, 120]); }catch(_){ }
  dati = dati || { level: LV.level, prestigio: LV.prestigio || 0, salti: 1 };
  const l = LV_LEVELS[dati.level - 1]; if (!l) return;
  lvFestaChiudi(true);
  LV.festa = dati;
  const w = document.createElement('div');
  w.id = 'lvFesta'; w.className = 'lvf-w';
  w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true'); w.setAttribute('aria-label', 'Livello ' + dati.level);
  w.innerHTML = '<canvas class="lvf-cv" id="lvfCv"></canvas>'
    + '<div class="lvf-card">'
    +   '<button type="button" class="lvf-x" aria-label="Chiudi" onclick="lvFestaChiudi()">✕</button>'
    +   '<div class="lvf-badge"><span>' + lvFestaEmoji(dati.level) + '</span><b>' + dati.level + '</b></div>'
    +   (dati.prestigio ? '<div class="lvf-stelle">' + lvStelle(dati.prestigio) + '</div>' : '')
    +   '<small class="lvf-liv">' + (dati.prestigio ? 'Prestigio ' + dati.prestigio + ' · ' : '') + 'Livello ' + dati.level + '</small>'
    +   '<h2>' + esc(l.name) + '</h2>'
    +   '<p>' + esc(lvFestaFrase(dati.level, dati.prestigio)) + '</p>'
    +   (l.perk ? '<div class="lvf-perk"><small>Sbloccato</small><b>' + esc(l.perk) + '</b></div>' : '')
    +   '<button type="button" class="lvf-share" onclick="lvFestaCondividi()">Condividi</button>'
    + '</div>';
  w.addEventListener('click', function(e){ if (e.target === w) lvFestaChiudi(); });
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ flVibra([30, 40, 30, 40, 90]); }catch(_){ }
  lvFestaCoriandoli(document.getElementById('lvfCv'));
}
function lvFestaChiudi(subito){
  const w = document.getElementById('lvFesta'); if (!w) return;
  if (w._raf) cancelAnimationFrame(w._raf);
  w._fine = true;
  if (subito === true){ w.remove(); return; }
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 260);
  /* il livello dopo, se i punti ne avevano fatti salire piu' d'uno */
  setTimeout(function(){ try{ lvFestaControlla(); }catch(_){ } }, 700);
}
/* 0.9.299, Andrea: "quando si clicca su Congratulati ci devono essere i coriandoli, gli stessi di quando si sale di
   livello, prima del messaggio". Gli stessi cannoni della festa del livello, su una tela che non si tocca. */
function flCoriandoli(){
  try{
    const vecchia = document.getElementById('flFesta'); if (vecchia){ vecchia._fine = true; vecchia.remove(); }
    const d = document.createElement('div');
    d.id = 'flFesta';
    d.style.cssText = 'position:fixed;inset:0;z-index:9700;pointer-events:none';
    const cv = document.createElement('canvas');
    d.appendChild(cv);
    document.body.appendChild(d);
    lvFestaCoriandoli(cv, d);
    setTimeout(function(){ d._fine = true; d.remove(); }, 2700);
  }catch(_){ }
  return Date.now();
}
/* I coriandoli: sparati dal basso verso l'alto da tre cannoni, poi la gravita' li riporta giu'.
   Colori del brand piu' l'oro; due secondi e mezzo, poi la tela si spegne. */
function lvFestaCoriandoli(cv, casa){
  if (!cv) return;
  const w = casa || document.getElementById('lvFesta');
  let ridotto = false; try{ ridotto = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); }catch(_){ }
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const W = window.innerWidth, H = window.innerHeight;
  cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
  const x = cv.getContext('2d'); if (!x) return;
  x.scale(dpr, dpr);
  const COL = ['#E63946', '#0075E3', '#F5B301', '#FFD166', '#FFFFFF', '#5B8DEF'];
  const N = ridotto ? 40 : 150;
  const P = [];
  for (let i = 0; i < N; i++){
    const lato = i % 3;                       // 0 = centro, 1 = sinistra, 2 = destra
    const sx = lato === 0 ? W / 2 : (lato === 1 ? W * 0.12 : W * 0.88);
    const ang = -Math.PI / 2 + (lato === 1 ? 0.35 : (lato === 2 ? -0.35 : 0)) + (Math.random() - 0.5) * 0.9;
    const v = (H * 0.016) + Math.random() * (H * 0.012);
    P.push({ x: sx + (Math.random() - 0.5) * 30, y: H + 10, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v,
      w: 6 + Math.random() * 6, h: 9 + Math.random() * 8, r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.35,
      c: COL[i % COL.length], tondo: Math.random() < 0.25, ritardo: Math.floor(Math.random() * 14) });
  }
  const DUR = 2500; let t0 = 0;
  const giro = function(t){
    if (!w || w._fine) return;
    if (!t0) t0 = t;
    const dt = t - t0;
    x.clearRect(0, 0, W, H);
    x.globalAlpha = dt > DUR - 500 ? Math.max(0, (DUR - dt) / 500) : 1;
    P.forEach(function(p){
      if (p.ritardo > 0){ p.ritardo--; return; }
      p.vy += H * 0.00045; p.vx *= 0.99; p.vy *= 0.992;
      p.x += p.vx + Math.sin((t + p.r * 100) / 220) * 0.6; p.y += p.vy; p.r += p.vr;
      x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c;
      if (p.tondo){ x.beginPath(); x.arc(0, 0, p.w / 2, 0, 6.283); x.fill(); }
      else x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * Math.abs(Math.cos(p.r * 1.7)) + 2);
      x.restore();
    });
    if (dt < DUR) w._raf = requestAnimationFrame(giro);
    else x.clearRect(0, 0, W, H);
  };
  w._raf = requestAnimationFrame(giro);
}
/** La card da condividere: bianca, come quella della serie (sdSerieCanvas). */
async function lvFestaCanvas(){
  const d = LV.festa || { level: LV.level, prestigio: LV.prestigio || 0 };
  const l = LV_LEVELS[d.level - 1] || LV_LEVELS[0];
  const W = 900, H = 1300, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  x.fillStyle = '#ffffff'; x.fillRect(0, 0, W, H);
  x.textAlign = 'center'; x.textBaseline = 'alphabetic';
  x.fillStyle = '#0075E3'; x.font = '900 64px sans-serif'; x.fillText('DreamMap', W / 2, 140);
  /* il distintivo: cerchio blu con l'anello d'oro e l'emoji del rango */
  x.beginPath(); x.arc(W / 2, 400, 175, 0, 6.283); x.fillStyle = '#F5B301'; x.fill();
  x.beginPath(); x.arc(W / 2, 400, 156, 0, 6.283); x.fillStyle = '#0075E3'; x.fill();
  x.textBaseline = 'middle'; x.font = '170px sans-serif'; x.fillText(lvFestaEmoji(d.level), W / 2, 410);
  x.textBaseline = 'alphabetic';
  if (d.prestigio){ x.fillStyle = '#F5B301'; x.font = '700 46px sans-serif'; x.fillText(lvStelle(d.prestigio), W / 2, 640); }
  x.fillStyle = '#E63946'; x.font = '900 120px sans-serif'; x.fillText('Livello ' + d.level, W / 2, 790);
  x.fillStyle = '#001E44'; x.font = '800 64px sans-serif'; x.fillText(l.name, W / 2, 880);
  /* la frase, mandata a capo a mano: il canvas non lo fa */
  x.fillStyle = '#4A5A72'; x.font = '600 38px sans-serif';
  const parole = lvFestaFrase(d.level, d.prestigio).split(' '); const righe = []; let r = '';
  parole.forEach(function(p){ const t = r ? r + ' ' + p : p; if (x.measureText(t).width > W - 160 && r){ righe.push(r); r = p; } else r = t; });
  if (r) righe.push(r);
  righe.slice(0, 4).forEach(function(t, i){ x.fillText(t, W / 2, 970 + i * 52); });
  let nome = ''; try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); nome = (u && u.name) ? String(u.name) : ''; }catch(_){ }
  const MESI = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic']; const g = new Date();
  x.fillStyle = '#6B7A90'; x.font = '700 42px sans-serif';
  x.textAlign = 'left'; x.fillText(nome ? '@' + nome.split(' ')[0] : 'DreamMap', 70, 1240);
  x.textAlign = 'right'; x.fillText(g.getDate() + ' ' + MESI[g.getMonth()] + ' ' + g.getFullYear(), W - 70, 1240);
  return cv;
}
async function lvFestaCondividi(){
  const d = LV.festa || { level: LV.level, prestigio: LV.prestigio || 0 };
  const l = LV_LEVELS[d.level - 1] || LV_LEVELS[0];
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const url = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + (code ? '?invito=' + encodeURIComponent(code) : '');
  const testo = 'Sono al livello ' + d.level + ' su DreamMap: ' + l.name + '. Tu a che livello sei?\n' + url;
  if (typeof flCondividiApri === 'function'){ flCondividiApri(lvFestaCanvas, testo, 'Condividi il livello'); return; }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'DreamMap' }); } }catch(_){ }
}
(function lvFestaStile(){
  const css = [
    /* sotto al foglio di condivisione (.qrw, 9995): «Condividi» lo apre sopra, e chiuso quello si torna qui */
    '.lvf-w{position:fixed;inset:0;z-index:9994;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,14,34,0);transition:background .25s}',
    '.lvf-w.in{background:rgba(0,14,34,.66)}',
    '.lvf-cv{position:fixed;inset:0;pointer-events:none;z-index:2}',
    '.lvf-card{position:relative;z-index:1;width:100%;max-width:340px;box-sizing:border-box;padding:30px 22px 20px;border-radius:26px;background:#FFFFFF;color:#001E44;text-align:center;',
    '  box-shadow:0 24px 60px rgba(0,0,0,.35);transform:scale(.82);opacity:0;transition:transform .42s cubic-bezier(.2,1.4,.4,1),opacity .25s}',
    '.lvf-w.in .lvf-card{transform:scale(1);opacity:1}',
    '.lvf-x{position:absolute;right:12px;top:12px;width:34px;height:34px;border:0;border-radius:50%;background:rgba(0,30,68,.07);color:#001E44;font-size:15px;cursor:pointer}',
    '.lvf-badge{position:relative;width:112px;height:112px;margin:0 auto 14px;border-radius:50%;background:#0075E3;box-shadow:0 0 0 6px #F5B301,0 10px 26px rgba(0,117,227,.35);display:flex;align-items:center;justify-content:center}',
    '.lvf-badge span{font-size:54px;line-height:1}',
    '.lvf-badge b{position:absolute;right:-8px;bottom:-6px;min-width:38px;height:38px;padding:0 6px;box-sizing:border-box;border-radius:99px;background:#E63946;color:#FFFFFF;border:3px solid #FFFFFF;display:flex;align-items:center;justify-content:center;font:800 17px var(--font-display)}',
    '.lvf-stelle{font-size:15px;letter-spacing:3px;color:#F5B301;margin-bottom:4px}',
    '.lvf-liv{display:block;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#E63946}',
    '.lvf-card h2{margin:6px 0 10px;font:800 28px/1.15 var(--font-display);font-style:italic;color:#001E44}',
    '.lvf-card p{margin:0 4px;font:500 14.5px/1.5 var(--font-body);color:#4A5A72}',
    '.lvf-perk{margin:16px 0 0;padding:10px 12px;border-radius:14px;background:rgba(0,117,227,.08)}',
    '.lvf-perk small{display:block;font:700 10.5px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#6B7A90}',
    '.lvf-perk b{display:block;margin-top:2px;font:700 13px/1.35 var(--font-body);color:#001E44}',
    '.lvf-share{display:block;width:100%;margin-top:20px;padding:14px;border:0;border-radius:99px;background:#0075E3;color:#FFFFFF;font:800 15px var(--font-body);cursor:pointer;box-shadow:0 8px 20px rgba(0,117,227,.3)}',
    'body.dark .lvf-card{background:#12203A;color:#FFFFFF}',
    'body.dark .lvf-card h2,body.dark .lvf-perk b{color:#FFFFFF}',
    'body.dark .lvf-card p{color:rgba(255,255,255,.78)}',
    'body.dark .lvf-x{background:rgba(255,255,255,.1);color:#FFFFFF}',
    'body.dark .lvf-badge b{border-color:#12203A}',
    'body.dark .lvf-perk{background:rgba(255,255,255,.07)}body.dark .lvf-perk small{color:rgba(255,255,255,.6)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
/** Il tasto indietro di Android chiude il popup prima di cambiare pagina (nav.js, handleBack). */
function lvFestaBack(){
  if (!document.getElementById('lvFesta')) return false;
  /* se sopra c'e' il foglio di condivisione, indietro chiude prima quello */
  const sh = document.getElementById('accQrW');
  if (sh && typeof accQrChiudi === 'function'){ accQrChiudi(); return true; }
  lvFestaChiudi(); return true;
}
