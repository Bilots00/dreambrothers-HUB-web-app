/* =========================================================================================
   TIENI IL RITMO (0.9.279), come Duolingo

   Andrea, 16/10: "dopo che ha completato un livello, una schermata tipo «Tieni il ritmo! Imposta
   un orario e impara ogni giorno», che gli chiede di aggiungere al calendario la tappa del giorno.
   Poi il calendario di Android mi ha mostrato «Fai Duolingo, inizia tra 30 minuti» a schermo
   intero: aumenta la retention e riduce l'abbandono".

   Dopo la schermata della serie, finche' l'appuntamento non c'e': una volta, poi di nuovo dopo
   tre giorni se ha detto "Non ora", al massimo tre volte. Il calendario del telefono apre la sua
   schermata di inserimento gia' compilata (ogni giorno, alla stessa ora): salva lui, e il
   promemoria lo suona il calendario.
   ========================================================================================= */
const RITMO_KEY = 'fl_ritmo';
function ritmoStato(){ try{ return JSON.parse(localStorage.getItem(RITMO_KEY) || '{}') || {}; }catch(_){ return {}; } }
function ritmoSalva(s){ try{ localStorage.setItem(RITMO_KEY, JSON.stringify(s)); }catch(_){ } }
function ritmoPuo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.calendarioAggiungi === 'function'; }
let RITMO_POI = null, RITMO_ORA = '20:30';
/* 0.9.300: il link del promemoria. I calendari rendono toccabili solo i link https: la pagina /apri/
   passa la mano all'app (dreammap://mappa, MainActivity.leggiLink), o porta a /scarica/ se l'app non c'e'. */
const RITMO_LINK = 'https://meta-ai-media-buyer-production.up.railway.app/apri/';
const RITMO_DESCR = 'Apri DreamMap e fai la tappa di oggi: la tua serie resta accesa.\nTocca qui per aprire DreamMap 👉 ' + RITMO_LINK;

/** Se e' il momento, apre la schermata e chiama `poi` alla fine. Torna true se l'ha aperta. */
function ritmoForse(poi){
  const s = ritmoStato();
  /* 0.9.300: chi l'aveva salvato con l'app del calendario (finito in "Famiglia", senza avviso all'ora) e non ha
     ancora dato il permesso del calendario: una volta sola si ripropone, e "Aggiungi" lo sposta senza doppioni */
  const daRifare = s.aggiunto && !s.diretto && s.riproponi && !s.riproposto;
  if (!daRifare && (s.aggiunto || (s.no || 0) >= 3)) return false;
  if (!daRifare && s.visto && Date.now() - s.visto < 3 * 86400000) return false;
  if (!ritmoPuo() && !window.__ritmoProva) return false;
  RITMO_POI = poi || null;
  s.visto = Date.now(); if (daRifare) s.riproposto = Date.now(); ritmoSalva(s);
  /* l'ora proposta: quella in cui ha fatto la tappa di oggi, arrotondata al quarto d'ora */
  const d = new Date(); let m = Math.round((d.getHours() * 60 + d.getMinutes()) / 15) * 15;
  if (m < 7 * 60) m = 20 * 60 + 30; if (m > 22 * 60) m = 21 * 60;
  RITMO_ORA = String(Math.floor(m / 60) % 24).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  if (daRifare && /^\d\d:\d\d$/.test(s.ora || '')) RITMO_ORA = s.ora;
  goId('s-ritmo'); ritmoPaint();
  return true;
}
function ritmoFine(m){ const p = String(m).split(':'); const t = (+p[0]) * 60 + (+p[1]) + 15; return String(Math.floor(t / 60) % 24).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
function ritmoPaint(){
  const h = document.getElementById('ritmoBody'); if (!h) return;
  const oggi = new Date().toLocaleDateString('it-IT', { day: 'numeric', month: 'long' });
  const ore = ['07:30', '13:00', '18:30', RITMO_ORA].filter(function(x, i, a){ return a.indexOf(x) === i; }).sort();
  h.innerHTML = '<h2 class="rt-h">Tieni il ritmo! Scegli un orario e fai la tua tappa ogni giorno.</h2>'
    + '<div class="rt-tel"><div class="rt-tel-in"><small>Oggi, ' + oggi + '</small>'
    +   '<div class="rt-ev"><i></i><div><b>La tua tappa di DreamMap 🔥</b><span>' + RITMO_ORA + ' - ' + ritmoFine(RITMO_ORA) + '</span></div></div>'
    +   '<div class="rt-ev vuoto"><i></i><div><b></b><span></span></div></div></div>'
    +   '<img class="rt-genio" src="img/genio/genio-saluta.png" alt=""></div>'
    + '<div class="rt-ore">' + ore.map(function(o){ return '<button type="button" class="' + (o === RITMO_ORA ? 'on' : '') + '" onclick="RITMO_ORA=\'' + o + '\';ritmoPaint()">' + o + '</button>'; }).join('')
    +   '<label class="rt-altra">Un’altra ora<input type="time" value="' + RITMO_ORA + '" onchange="if(this.value){RITMO_ORA=this.value;ritmoPaint()}"></label></div>'
    + '<button type="button" class="cta rt-si" onclick="ritmoAggiungi()">Aggiungi al calendario</button>'
    + '<button type="button" class="rt-no" onclick="ritmoNonOra()">Non ora</button>';
}
/* 0.9.302: il calendario in cui DreamMap scrive gia' gli altri eventi (Calendario > Collega): la tappa va li'.
   Quegli eventi arrivano sull'account e suonano; prima la tappa finiva nel primo account in ordine alfabetico. */
function ritmoCalId(){
  try{
    const g = JSON.parse(localStorage.getItem('fl_cal_gcal') || '{}') || {};
    if (g.collegato && g.scrivi && g.scrivi.id != null && g.scrivi.id !== '') return Number(g.scrivi.id);
  }catch(_){ }
  return -1;
}
function ritmoEsc(x){ return String(x == null ? '' : x).replace(/[<>&"]/g, ''); }
/* "oggi alle 21:15", "domani alle 21:15", "giovedì alle 21:15" */
function ritmoQuando(ms){
  const d = new Date(ms), oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const g = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - oggi) / 86400000);
  const ora = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  if (g === 0) return 'oggi alle ' + ora;
  if (g === 1) return 'domani alle ' + ora;
  return d.toLocaleDateString('it-IT', { weekday: 'long' }) + ' alle ' + ora;
}
async function ritmoAggiungi(){
  const p = RITMO_ORA.split(':'); const d = new Date(); d.setHours(+p[0], +p[1], 0, 0);
  if (d.getTime() < Date.now() + 5 * 60000) d.setDate(d.getDate() + 1);
  let r = null;
  try{
    r = await NATIVE.calendarioAggiungi({ titolo: 'La tua tappa di DreamMap 🔥', inizio: d.getTime(), fine: d.getTime() + 15 * 60000, rrule: 'FREQ=DAILY',
      descrizione: RITMO_DESCR, luogo: RITMO_LINK, calId: ritmoCalId() });
  }catch(e){ if (typeof toast === 'function') toast('Non trovo un calendario sul telefono'); return; }
  /* 0.9.300: con il permesso del calendario l'evento lo scrive l'app, con i due avvisi: e' gia' salvato */
  if (r && r.diretto){ ritmoSalvato(r); return; }
  /* 0.9.282, Andrea: mentre sceglieva l'app del calendario, l'app era gia' passata alle missioni. La schermata resta
     qui finche' non torni e dici che l'appuntamento e' salvato. */
  const h = document.getElementById('ritmoBody'); if (!h) return;
  h.innerHTML = '<h2 class="rt-h">Salva l’appuntamento nel tuo calendario</h2>'
    + '<p class="rt-attesa">Si è aperto il calendario con la tappa di ogni giorno alle ' + RITMO_ORA + '. Scegli l’app, tocca Salva e torna qui.</p>'
    + '<p class="rt-attesa">Prima di salvare, nel calendario aggiungi una notifica all’ora dell’evento: senza notifica il telefono non ti avvisa.</p>'
    + '<button type="button" class="cta rt-si" onclick="ritmoFatto()">Fatto, l’ho salvato</button>'
    + '<button type="button" class="rt-no" onclick="ritmoAggiungi()">Riapri il calendario</button>'
    + '<button type="button" class="rt-no" onclick="ritmoNonOra()">Non ora</button>';
}
/* La tappa e' nel calendario: si dice dove, quando arriva il prossimo avviso (letto dal calendario, non
   immaginato) e si puo' provare subito con un evento fra 2 minuti. */
function ritmoSalvato(r){
  const s = ritmoStato(); s.aggiunto = Date.now(); s.diretto = Date.now(); s.v302 = Date.now();
  if (r && /^\d\d:\d\d$/.test(r.ora || '')) RITMO_ORA = r.ora;
  s.ora = RITMO_ORA; ritmoSalva(s);
  const h = document.getElementById('ritmoBody'); if (!h){ ritmoChiudi(); return; }
  h.innerHTML = ritmoSalvatoHtml(r) + '<button type="button" class="cta rt-si" onclick="ritmoChiudi()">Continua</button>';
}
function ritmoSalvatoHtml(r){
  const cal = r && r.calendario ? ritmoEsc(r.calendario) : '';
  const acc = r && r.account ? ritmoEsc(r.account) : '';
  let h = '<h2 class="rt-h">La tua tappa è nel calendario</h2>'
    + '<div class="rt-box"><p>Ogni giorno alle <b>' + ritmoEsc(RITMO_ORA) + '</b> il calendario ti avvisa: la prima volta 10 minuti prima, la seconda all’ora della tappa.</p>'
    /* il calendario principale di Google si chiama come l'account: "nel calendario x@gmail.com" non dice niente */
    + (acc && (!cal || cal === acc) ? '<p>L’appuntamento è nel calendario principale dell’account ' + acc + '.</p>'
      : cal ? '<p>L’appuntamento è nel calendario "' + cal + '"' + (acc ? ' dell’account ' + acc : '') + '.</p>' : '')
    + (r && r.prossimo ? '<p>Il prossimo avviso arriva ' + ritmoQuando(r.prossimo) + '.</p>' : '')
    + '</div>'
    + '<p class="rt-attesa">Vuoi essere sicuro che il telefono suoni? Fai una prova: fra 2 minuti arriva un avviso del calendario, poi la prova si cancella da sola.</p>'
    + '<button type="button" class="rt-prova" data-cg-no onclick="ritmoProva()">Prova il promemoria fra 2 minuti</button>'
    + '<button type="button" class="rt-no" onclick="ritmoCambiaOra()">Cambia l’ora della tappa</button>';
  return h;
}
function ritmoCambiaOra(){ ritmoPaint(); }

/* La prova (0.9.302): un evento normale fra 2 minuti nello stesso calendario della tappa, con l'avviso
   all'ora. Se suona questo, suona anche la tappa. Si toglie da solo dopo che e' suonato. */
let RITMO_PROVA_T = 0;
async function ritmoProva(){
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.calendarioTappaProva !== 'function'){
    if (typeof toast === 'function') toast('La prova funziona nell’app installata sul telefono'); return;
  }
  let r = null;
  try{ r = await NATIVE.calendarioTappaProva({ minuti: 2, descrizione: RITMO_DESCR, luogo: RITMO_LINK, calId: ritmoCalId() }); }
  catch(e){
    if (typeof toast === 'function') toast(e && e.code === 'permission' ? 'Per la prova serve il permesso del calendario' : 'Non sono riuscito a scrivere la prova nel calendario');
    return;
  }
  const s = ritmoStato(); s.prova = { alle: r.alle, cal: r.calendario || '', fatta: Date.now() }; ritmoSalva(s);
  clearTimeout(RITMO_PROVA_T);
  RITMO_PROVA_T = setTimeout(ritmoProveVia, Math.max(60000, (r.alle || Date.now()) - Date.now() + 6 * 60000));
  const h = document.getElementById('ritmoBody'); if (!h) return;
  h.innerHTML = '<h2 class="rt-h">Prova in arrivo alle ' + ritmoEsc(r.ora) + '</h2>'
    + '<div class="rt-box"><p>Fra 2 minuti il calendario ti avvisa con "Prova del promemoria di DreamMap"' + ritmoDove(r) + '.</p>'
    + '<p>Puoi chiudere DreamMap e bloccare lo schermo: l’avviso arriva lo stesso.</p></div>'
    + '<p class="rt-attesa">Se alle ' + ritmoEsc(r.ora) + ' non arriva niente, il telefono tiene spente le notifiche del calendario. Controlla queste tre cose:</p>'
    + '<ol class="rt-aiuto">'
    +   '<li>Nell’app Google Calendar apri Impostazioni, poi Generali, e accendi "Notifiche su questo dispositivo".</li>'
    +   '<li>Nelle impostazioni del telefono apri Notifiche, cerca Calendar e accendi le notifiche degli eventi.</li>'
    +   '<li>Nelle impostazioni del telefono apri Account, tocca il tuo account Google e controlla che Calendar sia sincronizzato.</li>'
    + '</ol>'
    + '<button type="button" class="cta rt-si" onclick="ritmoChiudi()">Ho capito</button>'
    + '<button type="button" class="rt-no" onclick="ritmoProva()">Rifai la prova</button>';
}
function ritmoDove(r){
  const cal = r && r.calendario ? ritmoEsc(r.calendario) : '', acc = r && r.account ? ritmoEsc(r.account) : '';
  if (acc && (!cal || cal === acc)) return ', dal calendario principale dell’account ' + acc;
  return cal ? ', dal calendario "' + cal + '"' : '';
}
function ritmoProveVia(){
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.calendarioTappaProveVia !== 'function') return;
  NATIVE.calendarioTappaProveVia({ dopoMs: 5 * 60000 }).catch(function(){ });
}

/* Da Calendario > Impostazioni (0.9.302): la pagina della tappa si apre quando vuoi, con lo stato vero. */
let RITMO_DA_IMP = false;
async function ritmoApri(){
  const da = (document.querySelector('.screen.active') || {}).id || 's-home';
  RITMO_DA_IMP = true;
  RITMO_POI = function(){ RITMO_DA_IMP = false; goId(da); if (typeof calImpApri === 'function' && da !== 's-ritmo') setTimeout(calImpApri, 60); };
  try{ if (typeof calChiudi === 'function') calChiudi(); }catch(_){ }
  const s = ritmoStato();
  if (/^\d\d:\d\d$/.test(s.ora || '')) RITMO_ORA = s.ora;
  goId('s-ritmo');
  const h = document.getElementById('ritmoBody');
  if (h) h.innerHTML = '<h2 class="rt-h">La tua tappa ogni giorno</h2><p class="rt-attesa">Sto guardando il calendario del telefono...</p>';
  let st = null;
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.calendarioTappaStato === 'function') st = await NATIVE.calendarioTappaStato(); }catch(_){ st = null; }
  if (st && st.trovati > 0){
    if (/^\d\d:\d\d$/.test(st.ora || '')) RITMO_ORA = st.ora;
    if (h) h.innerHTML = ritmoSalvatoHtml(st) + '<button type="button" class="cta rt-si" onclick="ritmoChiudi()">Fatto</button>';
    return;
  }
  ritmoPaint();
}

/* 0.9.300: le tappe gia' salvate prima (app del calendario, calendario "Famiglia", solo "10 min prima") si
   rimettono a posto da sole se il permesso del calendario c'e' gia'; se manca, si ripropone la schermata una volta.
   0.9.302: la 0.9.300 segnava "a posto" anche quando nel telefono non trovava NESSUNA tappa (era sparita): cosi'
   il promemoria scelto non tornava piu'. Ora, una volta, si guarda il calendario vero: se la tappa non c'e' e
   l'ora scelta e' nota si riscrive a quell'ora (l'hai chiesta tu); se l'ora non c'e' si ripropone la schermata. */
function ritmoRipara(){
  ritmoProveVia();
  const s = ritmoStato();
  if (!s.aggiunto || (s.diretto && s.v302)) return;
  if (typeof NATIVE === 'undefined' || !NATIVE || typeof NATIVE.calendarioTappaRipara !== 'function') return;
  const ora = /^\d\d:\d\d$/.test(s.ora || '') ? s.ora : null;
  NATIVE.calendarioTappaRipara({ descrizione: RITMO_DESCR, luogo: RITMO_LINK, ora: ora, calId: ritmoCalId() }).then(function(r){
    const t = ritmoStato();
    if (r && r.permesso && r.eventId != null){
      t.diretto = Date.now(); t.v302 = Date.now(); if (r.ora) t.ora = r.ora;
    } else if (r && r.permesso){
      /* nel telefono non c'e' nessuna tappa e non so a che ora: alla prossima tappa finita si ripropone la schermata */
      delete t.diretto; t.v302 = Date.now(); t.riproponi = Date.now(); delete t.riproposto;
    } else t.riproponi = Date.now();
    ritmoSalva(t);
  }).catch(function(){ });
}
setTimeout(ritmoRipara, 7000);
function ritmoFatto(){ const s = ritmoStato(); s.aggiunto = Date.now(); s.ora = RITMO_ORA; ritmoSalva(s); ritmoChiudi(); }
function ritmoNonOra(){ if (RITMO_DA_IMP){ ritmoChiudi(); return; } const s = ritmoStato(); s.no = (s.no || 0) + 1; ritmoSalva(s); ritmoChiudi(); }
function ritmoChiudi(){ const f = RITMO_POI; RITMO_POI = null; RITMO_DA_IMP = false; if (f) f(); else { goId('s-home'); try{ switchTab('mappa'); }catch(_){ } } }

registerScreen('s-ritmo', '<div class="rt-in" id="ritmoBody"></div>', { back: function(){ ritmoNonOra(); return null; } });
(function ritmoStile(){
  const st = document.createElement('style');
  st.textContent = [
    '#s-ritmo{background:#0E1B33!important}',
    '.rt-in{min-height:100%;display:flex;flex-direction:column;padding:36px 24px calc(env(safe-area-inset-bottom,0px) + 28px);box-sizing:border-box;color:#fff}',
    '.rt-h{margin:0 0 32px;text-align:center;font:800 24px/1.3 var(--font-display);color:#fff}',
    '.rt-tel{position:relative;margin:0 auto 28px;width:min(78vw,300px);padding:14px;border-radius:30px;background:linear-gradient(180deg,#7FA6E8,#3E63A8);box-shadow:0 18px 40px rgba(0,0,0,.35),inset 0 0 0 3px rgba(255,255,255,.25)}',
    '.rt-tel-in{border-radius:20px;background:#DCE8FB;padding:16px 14px 150px}',
    '.rt-tel-in small{display:block;margin-bottom:12px;text-align:center;font:700 14px var(--font-body);color:#3E5F92}',
    '.rt-ev{display:flex;gap:10px;align-items:stretch;padding:12px;border-radius:14px;background:#6E86B8;margin-bottom:10px}.rt-ev i{width:4px;border-radius:4px;background:#0075E3;flex:none}',
    '.rt-ev b{display:block;font:800 15px var(--font-body);color:#fff}.rt-ev span{display:block;margin-top:4px;font:700 13px var(--font-body);color:rgba(255,255,255,.8)}',
    '.rt-ev.vuoto{background:rgba(110,134,184,.35);height:44px}.rt-ev.vuoto i{background:transparent}',
    '.rt-genio{position:absolute;left:50%;bottom:-30px;width:118px;transform:translateX(-50%);filter:drop-shadow(0 10px 18px rgba(0,0,0,.35))}',
    '.rt-ore{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:40px 0 24px}',
    '.rt-ore button{border:0;border-radius:999px;padding:10px 16px;background:rgba(255,255,255,.1);color:#fff;font:700 15px var(--font-body);cursor:pointer}.rt-ore button.on{background:#fff;color:#0E2350}',
    '.rt-altra{display:flex;align-items:center;gap:8px;padding:6px 6px 6px 14px;border-radius:999px;background:rgba(255,255,255,.1);font:700 14px var(--font-body);color:rgba(255,255,255,.85)}',
    '.rt-altra input{border:0;border-radius:999px;padding:6px 8px;background:#fff;color:#0E2350;font:700 14px var(--font-body)}',
    '.rt-box{margin:0 0 24px;padding:16px 18px;border-radius:18px;background:rgba(255,255,255,.08);text-align:center}.rt-box p{margin:0;font:500 16px/1.55 var(--font-body);color:#fff}.rt-box p+p{margin-top:10px}.rt-box b{font-weight:800}',
    '.rt-prova{display:block;width:100%;margin:0 0 4px;padding:15px;border:2px solid transparent;border-radius:999px;background:linear-gradient(135deg,#f6cce4 0%,#f6cce4 30%,#eccfef 35%,#dfd2f8 40%,#d0d7fd 50%,#c1dbff 60%,#bce0ff 70%,#b8e5ff 80%,#b6e9fe 88%,#beeffd 94%,#c7f4fc 97%,#d2f9fb 99%,#ddfefc 100%) padding-box,linear-gradient(135deg,#E71D4F 0%,#0075E3 100%) border-box;color:#fff;text-shadow:1px 2.5px 3px rgba(0,0,0,.9);font:800 15px var(--font-body);white-space:nowrap;cursor:pointer}',
    '.rt-aiuto{margin:-16px 0 28px;padding:0;list-style-position:inside;text-align:center;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.85)}.rt-aiuto li+li{margin-top:8px}',
    '.rt-attesa{margin:0 0 32px;text-align:center;font:500 16px/1.55 var(--font-body);color:rgba(255,255,255,.8)}.rt-si{width:100%;margin-top:auto}.rt-no{display:block;width:100%;margin-top:14px;padding:14px;border:0;background:none;font:800 15px var(--font-body);letter-spacing:.04em;color:#8CC6FF;cursor:pointer}'
  ].join('\n');
  document.head.appendChild(st);
})();
