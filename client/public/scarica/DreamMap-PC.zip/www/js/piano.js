/* ===========================================================================================
   IL PIANO A TUTTO SCHERMO — come il Notion di Andrea, dentro all'app

   Sei schede in fila, nell'ordine in cui si pensa un piano: Calendario, Trimestri, Mesi,
   Settimane, Giorni, Note. Le Note stanno per ultime apposta: sono il posto delle idee nuove,
   e un'idea nuova e' quasi sempre una distrazione dal piano A. Ci si arriva, ma per ultimo.

   COLLEGATO COME IL SUO NOTION. Nel suo database ogni task del giorno ha una data e una
   casella «Fatto», ed e' legata alla sua settimana, al suo mese e al suo trimestre: la
   percentuale di ognuno e' «spuntate diviso totali», calcolata da sola. Qui e' lo stesso: le
   task sono le righe dei fogli di ogni giorno (`fl_notes_<giorno>`), le spunte sono quelle del
   registro (`fl_notes_done`), e ogni periodo somma i giorni che contiene. In piu' ogni periodo
   ha il suo obiettivo e le sue milestone — le sole cose da fare in quel periodo — che contano
   nella stessa barra. Spunti una casella, e la barra del giorno, della settimana, del mese e
   del trimestre avanzano insieme.

   DOMANI SI GUADAGNA. La scheda «Domani» del pannello resta chiusa finche' la priorita' di oggi
   non e' fatta E la giornata di lavoro non e' finita (l'ora si sceglie dai tre puntini). Chi
   guarda domani mentre oggi e' ancora aperto scappa in avanti; chi lo guarda la sera, a lavoro
   chiuso, ci dorme sopra e la mattina parte gia' sapendo cosa fare.
   =========================================================================================== */

const PN = { m: null, anno: null, mSett: null, aperto: '', pagina: '', cerca: '' };
const PN_TABS = [['cal', 'Calendario'], ['trim', 'Trimestri'], ['mesi', 'Mesi'], ['sett', 'Settimane'], ['giorni', 'Giorni'], ['note', 'Note']];
const PN_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const PN_PER_KEY = 'fl_periodi';
const PN_NOTE_KEY = 'fl_note_pagine';

function pnPad(n){ return String(n).padStart(2, '0'); }
function pnIso(d){ return d.getFullYear() + '-' + pnPad(d.getMonth() + 1) + '-' + pnPad(d.getDate()); }
function pnData(iso){ return new Date(iso + 'T12:00:00'); }
function pnCap(s){ return s.charAt(0).toUpperCase() + s.slice(1); }
/** La settimana ISO (lunedi'-domenica, W01 = quella del primo giovedi'), come nel suo Notion. */
function pnSettimana(d){
  const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const g = x.getUTCDay() || 7;
  x.setUTCDate(x.getUTCDate() + 4 - g);
  const inizio = new Date(Date.UTC(x.getUTCFullYear(), 0, 1));
  return { anno: x.getUTCFullYear(), w: Math.ceil(((x - inizio) / 86400000 + 1) / 7) };
}
function pnLunedi(d){ const x = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x; }

/* ---------------------------------------------------------------------------------------
   I NUMERI: task e spunte di ogni giorno, sommate per periodo
   --------------------------------------------------------------------------------------- */
/** { '2026-09-25': { t: totali, f: fatte } } — letto una volta per disegno. */
function pnGiorniConti(){
  const fatte = {};
  try{ (stDone() || []).forEach(function(d){ if (d && d.day) fatte[d.day + '|' + d.text] = 1; }); }catch(_){ }
  let meta = {};
  try{ meta = (typeof stMetaAll === 'function') ? stMetaAll() : {}; }catch(_){ meta = {}; }
  const out = {};
  for (let i = 0; i < localStorage.length; i++){
    const k = localStorage.key(i);
    const m = /^fl_notes_(\d{4}-\d{2}-\d{2})$/.exec(k || '');
    if (!m) continue;
    const day = m[1];
    let t = 0, f = 0;
    stRigheDi(day).forEach(function(r){
      /* le idee per il futuro non sono task: non contano, come nel suo Notion non conta l'inbox */
      let mk = null; try{ mk = meta[stMetaKey(r, day)]; }catch(_){ }
      if (mk && mk.sez === 'idee') return;
      t++;
      if (fatte[day + '|' + r.trim().toLowerCase()]) f++;
    });
    if (t) out[day] = { t: t, f: f };
  }
  return out;
}
function pnSomma(conti, da, a){
  let t = 0, f = 0;
  Object.keys(conti).forEach(function(d){ if (d >= da && d <= a){ t += conti[d].t; f += conti[d].f; } });
  return { t: t, f: f };
}

/* ---------------------------------------------------------------------------------------
   I PERIODI: obiettivo e milestone
   --------------------------------------------------------------------------------------- */
function pnPeriodi(){ try{ return JSON.parse(localStorage.getItem(PN_PER_KEY) || '{}') || {}; }catch(_){ return {}; } }
function pnPeriodiSalva(p){ try{ localStorage.setItem(PN_PER_KEY, JSON.stringify(p)); }catch(_){ } }
function pnPeriodo(key){ const p = pnPeriodi()[key] || {}; return { ob: p.ob || '', ms: Array.isArray(p.ms) ? p.ms : [] }; }

/** Il periodo corrente di quel tipo e' legato all'anello degli Orizzonti che gli corrisponde. */
function pnAnelloDi(tipo, key){
  const oggi = new Date();
  if (tipo === 'mesi' && key === 'M' + oggi.getFullYear() + '-' + pnPad(oggi.getMonth() + 1)) return 'mese';
  if (tipo === 'sett'){ const s = pnSettimana(oggi); if (key === 'W' + s.anno + '-' + pnPad(s.w)) return 'settimana'; }
  return '';
}
/** Obiettivo e milestone da mostrare: quelle scritte qui, piu' i passi della Roadmap se il periodo e' quello in corso. */
function pnContenuto(tipo, key){
  const p = pnPeriodo(key);
  const an = pnAnelloDi(tipo, key);
  let ob = p.ob, ms = p.ms.map(function(x, i){ return { t: x.t, f: !!x.f, dove: 'p', i: i }; });
  if (an && typeof ozAnello === 'function'){
    const a = ozAnello(an);
    if (!ob) ob = a.testo || '';
    const rm = (a.passi || []).map(function(x, i){ return { t: x.t, f: !!x.fatto, dove: an, i: i }; }).filter(function(x){ return x.t; });
    ms = rm.concat(ms);
  }
  return { ob: ob, ms: ms, anello: an };
}

/* ---------------------------------------------------------------------------------------
   LE SCHEDE
   --------------------------------------------------------------------------------------- */
function pnTabsPaint(){
  const el = document.getElementById('pnTabs'); if (!el) return;
  const t = STF.tab || 'giorni';
  el.innerHTML = PN_TABS.map(function(x){
    return '<button type="button" class="' + (x[0] === t ? 'on' : '') + '" data-t="' + x[0] + '" onclick="pnTab(\'' + x[0] + '\')">' + x[1] + '</button>';
  }).join('');
  const on = el.querySelector('.on');
  if (on) try{ on.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }catch(_){ }
  pnFabSync();
}
/* I MIEI APPUNTI (0.9.177): la scheda Note del foglio grande, da sola, con la stessa UI.
   Si apre dalle scorciatoie della Rotta; le altre schede e il giorno restano nascosti. */
function apNoteApri(ritorno){
  if (typeof stFullOpen !== 'function') return;
  STF.ritorno = ritorno || 'rotta';
  stFullOpen();
  setTimeout(function(){
    try{
      const sn = document.getElementById('s-notes'); if (sn) sn.classList.add('solo-note');
      STF.tab = 'note'; PN.pagina = ''; PN.aperto = ''; PN.vista = '';
      stfPaint();
      const tt = document.querySelector('#s-notes .pn-head-t'); if (tt) tt.textContent = '🪶 I miei appunti';
    }catch(_){ }
  }, 60);
}
function pnTab(t){
  try{ stfNoteSalva(); }catch(_){ }
  STF.tab = t;
  if (t !== 'note') PN.pagina = '';
  PN.aperto = '';
  stfPaint();
  const b = document.getElementById('stfBody'); if (b) b.scrollTop = 0;
}
/** Disegna la scheda che non e' «Giorni» (quella la disegna stfPaint). */
function pnPaintTab(){
  const host = document.getElementById('stfBody'); if (!host) return;
  const nav = document.getElementById('stfDayNav'); if (nav) nav.hidden = true;
  const add = document.getElementById('stfAdd'); if (add) add.hidden = true;
  const t = STF.tab;
  const conti = (t === 'note') ? null : pnGiorniConti();
  if (t === 'cal') host.innerHTML = pnCalHtml(conti);
  else if (t === 'trim') host.innerHTML = pnTrimHtml(conti);
  else if (t === 'mesi') host.innerHTML = pnMesiHtml(conti);
  else if (t === 'sett') host.innerHTML = pnSettHtml(conti);
  else if (t === 'note') pnNotePaint(host);
  /* le barre partono da zero e crescono: il progresso si vede muovere, non si legge e basta */
  requestAnimationFrame(function(){ requestAnimationFrame(function(){
    host.querySelectorAll('.pn-bar i[data-w]').forEach(function(i){ i.style.width = i.dataset.w + '%'; });
  }); });
}

/* ---- una riga di periodo, come una riga del database di Notion ---- */
function pnPct(s){ return s.t ? Math.round(s.f / s.t * 100) : 0; }
function pnRiga(tipo, key, titolo, sotto, conti, da, a, corrente){
  const c = pnContenuto(tipo, key);
  const base = pnSomma(conti, da, a);
  const msF = c.ms.filter(function(x){ return x.f; }).length;
  const s = { t: base.t + c.ms.length, f: base.f + msF };
  const pct = pnPct(s);
  const aperto = PN.aperto ? PN.aperto === key : corrente;
  return '<div class="pn-per' + (corrente ? ' ora' : '') + (aperto ? ' aperto' : '') + (pct === 100 ? ' pieno' : '') + '">'
    + '<button type="button" class="pn-per-h" onclick="pnApri(\'' + key + '\')">'
    +   '<span class="pn-per-t"><b>' + esc(titolo) + '</b>' + (c.ob ? '<small>' + esc(c.ob) + '</small>' : (sotto ? '<small>' + esc(sotto) + '</small>' : '')) + '</span>'
    +   '<span class="pn-per-n"><em>' + (s.t ? pct + '%' : '—') + '</em><span class="pn-bar"><i data-w="' + pct + '"></i></span></span>'
    + '</button>'
    + (aperto ? pnDettaglio(tipo, key, c, base) : '')
    + '</div>';
}
function pnDettaglio(tipo, key, c, base){
  const nome = tipo === 'trim' ? 'del trimestre' : tipo === 'mesi' ? 'del mese' : 'della settimana';
  return '<div class="pn-det">'
    + '<small class="pn-lbl">L’obiettivo ' + nome + '</small>'
    + '<div class="pn-ob" contenteditable="true" data-placeholder="Scrivi l’obiettivo" onblur="pnObSalva(\'' + key + '\', this)">' + esc(c.ob) + '</div>'
    + '<small class="pn-lbl">Milestone · le sole cose da fare</small>'
    + (c.ms.length ? c.ms.map(function(x){
        return '<div class="stf-row pn-ms' + (x.f ? ' done' : '') + '">'
          + '<button type="button" class="stf-box' + (x.f ? ' on' : '') + '" onclick="pnMsTick(\'' + key + '\',\'' + x.dove + '\',' + x.i + ')" aria-label="Spunta">' + (x.f ? '✓' : '') + '</button>'
          + '<div class="stf-txt">' + esc(x.t) + (x.dove !== 'p' ? '<small class="stf-quad">dalla Roadmap</small>' : '') + '</div>'
          + (x.dove === 'p' ? '<button type="button" class="st-del" onclick="pnMsVia(\'' + key + '\',' + x.i + ')" aria-label="Togli">✕</button>' : '')
          + '</div>';
      }).join('') : '<p class="stf-vuoto piccolo">Una, due, al massimo tre. Tutto il resto diventa superfluo.</p>')
    + '<input class="fin pn-ms-add" placeholder="＋ Aggiungi una milestone" onkeydown="if(event.key===\'Enter\'){event.preventDefault();pnMsAggiungi(\'' + key + '\', this)}">'
    + '<p class="pn-conto">' + base.f + ' task fatte su ' + base.t + ' nei fogli di questo periodo</p>'
    + '</div>';
}
function pnApri(key){ PN.aperto = (PN.aperto === key) ? '-' : key; pnPaintTab(); }
function pnObSalva(key, el){
  const v = String(el.innerText || '').trim().slice(0, 300);
  const p = pnPeriodi(); p[key] = Object.assign({ ob: '', ms: [] }, p[key] || {}); p[key].ob = v; pnPeriodiSalva(p);
}
function pnMsAggiungi(key, el){
  const v = String(el.value || '').trim().slice(0, 160); if (!v) return;
  const p = pnPeriodi(); p[key] = Object.assign({ ob: '', ms: [] }, p[key] || {});
  p[key].ms = (p[key].ms || []).concat([{ t: v, f: false }]); pnPeriodiSalva(p);
  PN.aperto = key; pnPaintTab();
}
function pnMsVia(key, i){
  const p = pnPeriodi(); if (!p[key]) return;
  p[key].ms.splice(i, 1); pnPeriodiSalva(p); PN.aperto = key; pnPaintTab();
}
function pnMsTick(key, dove, i){
  if (dove === 'p'){
    const p = pnPeriodi(); if (!p[key] || !p[key].ms[i]) return;
    p[key].ms[i].f = !p[key].ms[i].f; pnPeriodiSalva(p);
    if (p[key].ms[i].f) pnFesta();
  } else if (typeof ozAnello === 'function'){
    const a = ozAnello(dove); const x = a.passi[i]; if (!x) return;
    x.fatto = !x.fatto; x.il = x.fatto ? ozGiorno() : '';
    ozSalvaAnello(dove, a);
    if (x.fatto) pnFesta();
  }
  PN.aperto = key; pnPaintTab();
}
function pnFesta(){ try{ if (typeof flVibra === 'function') flVibra(20); else flVibra(20); }catch(_){ } }

/* ---- il navigatore di un periodo (anno o mese) ---- */
function pnNav(fn, titolo){
  return '<div class="stfd-nav pn-nav"><button type="button" onclick="' + fn + '(-1)">‹</button><b>' + titolo + '</b><button type="button" onclick="' + fn + '(1)">›</button></div>';
}
function pnAnno(){ if (!PN.anno) PN.anno = new Date().getFullYear(); return PN.anno; }
function pnAnnoVai(d){ PN.anno = pnAnno() + d; PN.aperto = ''; pnPaintTab(); }

function pnTrimHtml(conti){
  const y = pnAnno(), oggi = new Date();
  const nomi = ['Gen–Mar', 'Apr–Giu', 'Lug–Set', 'Ott–Dic'];
  let h = pnNav('pnAnnoVai', String(y));
  for (let q = 1; q <= 4; q++){
    const da = y + '-' + pnPad(q * 3 - 2) + '-01', a = pnIso(new Date(y, q * 3, 0));
    const corr = y === oggi.getFullYear() && Math.floor(oggi.getMonth() / 3) + 1 === q;
    h += pnRiga('trim', 'Q' + y + '-' + q, 'Q' + q + ' ' + y, nomi[q - 1], conti, da, a, corr);
  }
  return h;
}
function pnMesiHtml(conti){
  const y = pnAnno(), oggi = new Date();
  let h = pnNav('pnAnnoVai', String(y));
  for (let m = 0; m < 12; m++){
    const da = y + '-' + pnPad(m + 1) + '-01', a = pnIso(new Date(y, m + 1, 0));
    const corr = y === oggi.getFullYear() && oggi.getMonth() === m;
    h += pnRiga('mesi', 'M' + y + '-' + pnPad(m + 1), pnPad(m + 1) + ' · ' + pnCap(PN_MESI[m]), '', conti, da, a, corr);
  }
  return h;
}
function pnSettMese(){ if (!PN.mSett){ const d = new Date(); PN.mSett = new Date(d.getFullYear(), d.getMonth(), 1); } return PN.mSett; }
function pnSettVai(d){ const m = pnSettMese(); PN.mSett = new Date(m.getFullYear(), m.getMonth() + d, 1); PN.aperto = ''; pnPaintTab(); }
function pnSettHtml(conti){
  const m = pnSettMese(), oggi = new Date();
  const sOggi = pnSettimana(oggi);
  let h = pnNav('pnSettVai', pnCap(PN_MESI[m.getMonth()]) + ' ' + m.getFullYear());
  let lun = pnLunedi(m);
  const fine = new Date(m.getFullYear(), m.getMonth() + 1, 0, 12);
  while (lun <= fine){
    const dom = new Date(lun); dom.setDate(dom.getDate() + 6);
    const s = pnSettimana(lun);
    const key = 'W' + s.anno + '-' + pnPad(s.w);
    const corr = s.anno === sOggi.anno && s.w === sOggi.w;
    const sotto = lun.getDate() + ' ' + PN_MESI[lun.getMonth()].slice(0, 3) + ' – ' + dom.getDate() + ' ' + PN_MESI[dom.getMonth()].slice(0, 3);
    h += pnRiga('sett', key, 'W' + pnPad(s.w), sotto, conti, pnIso(lun), pnIso(dom), corr);
    lun = new Date(lun); lun.setDate(lun.getDate() + 7);
  }
  return h;
}

/* ---- il calendario (era nel cassetto dei tre puntini) ---- */
function pnCalMese(){ if (!PN.m){ const d = new Date(); PN.m = new Date(d.getFullYear(), d.getMonth(), 1); } return PN.m; }
function pnCalVai(d){ const m = pnCalMese(); PN.m = new Date(m.getFullYear(), m.getMonth() + d, 1); pnPaintTab(); }
function pnCalHtml(conti){
  const m = pnCalMese(), y = m.getFullYear(), mi = m.getMonth();
  const oggi = mtKey(Date.now());
  const vuoti = new Date(y, mi, 1).getDay();
  const nGiorni = new Date(y, mi + 1, 0).getDate();
  let celle = '';
  for (let i = 0; i < vuoti; i++) celle += '<i></i>';
  for (let g = 1; g <= nGiorni; g++){
    const iso = y + '-' + pnPad(mi + 1) + '-' + pnPad(g);
    const c = conti[iso];
    const cls = c ? (c.f >= c.t ? ' fatte' : (c.f ? ' meta' : ' scritte')) : '';
    celle += '<button type="button" class="stfd-g' + (iso === oggi ? ' oggi' : '') + cls + '" onclick="pnCalGiorno(\'' + iso + '\')"><b>' + g + '</b>' + (c ? '<i></i>' : '') + '</button>';
  }
  const s = pnSomma(conti, y + '-' + pnPad(mi + 1) + '-01', pnIso(new Date(y, mi + 1, 0)));
  const pct = pnPct(s);
  return pnNav('pnCalVai', pnCap(PN_MESI[mi]) + ' ' + y)
    + '<div class="stfd-sett">' + ['dom', 'lun', 'mar', 'mer', 'gio', 'ven', 'sab'].map(function(x){ return '<span>' + x + '</span>'; }).join('') + '</div>'
    + '<div class="stfd-griglia">' + celle + '</div>'
    + '<div class="pn-calfoot"><span class="pn-bar"><i data-w="' + pct + '"></i></span><em>' + (s.t ? pct + '% del mese · ' + s.f + ' su ' + s.t : 'Ancora niente questo mese') + '</em></div>'
    + '<p class="pn-leg"><i class="v"></i>tutto fatto <i class="m"></i>a metà <i class="s"></i>scritto</p>';
}
function pnCalGiorno(iso){
  const off = Math.round((pnData(iso) - pnData(mtKey(Date.now()))) / 86400000);
  if (off > 2){ toast('Il foglio si scrive fino a dopodomani'); return; }
  if (off < -60){ toast('Qui si torna indietro di due mesi al massimo'); return; }
  STF.off = off; pnTab('giorni');
}

/* ---------------------------------------------------------------------------------------
   LE NOTE: la inbox, a pagine, con la ricerca
   --------------------------------------------------------------------------------------- */
function pnPagine(){ try{ return JSON.parse(localStorage.getItem(PN_NOTE_KEY) || '[]') || []; }catch(_){ return []; } }
function pnPagineSalva(l){ try{ localStorage.setItem(PN_NOTE_KEY, JSON.stringify(l)); }catch(_){ } }
function pnTesto(html){ const d = document.createElement('div'); d.innerHTML = String(html || '').replace(/<\/(p|div|li|h\d)>|<br\s*\/?>/gi, ' '); return (d.textContent || '').replace(/\s+/g, ' ').trim(); }
/** Una volta sola: le note di ogni giorno e gli appunti del pannello diventano pagine. */
function pnNoteMigra(){
  try{ if (localStorage.getItem('fl_note_pagine_v1')) return; }catch(_){ return; }
  const l = pnPagine();
  const chiavi = [];
  for (let i = 0; i < localStorage.length; i++) chiavi.push(localStorage.key(i));
  chiavi.sort().forEach(function(k){
    let m = /^fl_note_html_(\d{4}-\d{2}-\d{2})$/.exec(k || '');
    if (m){
      const html = localStorage.getItem(k) || '';
      if (pnTesto(html)) l.push({ id: 'n' + m[1].replace(/-/g, ''), titolo: 'Note del ' + pnDataTxt(m[1]), html: html, at: pnData(m[1]).getTime(), mod: pnData(m[1]).getTime() });
      return;
    }
    m = /^fl_appunti_(\d{4}-\d{2}-\d{2})$/.exec(k || '');
    if (m){
      let a = []; try{ a = JSON.parse(localStorage.getItem(k) || '[]') || []; }catch(_){ }
      if (a.length) l.push({ id: 'a' + m[1].replace(/-/g, ''), titolo: 'Appunti del ' + pnDataTxt(m[1]), html: a.map(function(x){ return '<p>' + esc(x.t) + '</p>'; }).join(''), at: pnData(m[1]).getTime(), mod: pnData(m[1]).getTime() });
    }
  });
  pnPagineSalva(l);
  try{ localStorage.setItem('fl_note_pagine_v1', '1'); }catch(_){ }
}
function pnDataTxt(iso){ const d = pnData(iso); return d.getDate() + ' ' + PN_MESI[d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : ''); }
/* COME SAMSUNG NOTES. Il titolo grande con il conto delle note, la lente e i tre puntini
   sotto, le note raggruppate per quando le hai toccate (Oggi, Ieri, Questa settimana...), in
   una griglia di anteprime a due colonne con il titolo e l'ora sotto a ogni anteprima, e il
   pulsante tondo in basso a destra per scriverne una nuova. La barra di ricerca non c'e'
   finche' non tocchi la lente. */
function pnNotePaint(host){
  pnNoteMigra();
  if (PN.pagina){ pnPaginaPaint(host); pnFabSync(); return; }
  if (PN.vista === 'rev'){ pnRevPaint(host); pnFabSync(); return; }
  const tutte = pnPagine();
  host.innerHTML = '<div class="sn-head">'
    + (PN.cercaAperta
        ? '<div class="sn-cerca"><input class="fin" id="pnCerca" type="search" placeholder="Cerca nelle note" value="' + esc(PN.cerca) + '" oninput="pnCerca(this.value)">'
          + '<button type="button" class="sn-annulla" onclick="pnCercaChiudi()">Annulla</button></div>'
        : '<h1 class="sn-tit">Tutte le note</h1><p class="sn-conto">' + tutte.length + (tutte.length === 1 ? ' nota' : ' note') + '</p>')
    + '</div>'
    + (PN.cercaAperta ? '' : '<div class="sn-bar"><span></span>'
        + '<button type="button" class="sn-ic" onclick="pnCercaApri()" aria-label="Cerca"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg></button>'
        + '<button type="button" class="sn-ic" onclick="pnMenu(event)" aria-label="Altro">⋮</button></div>')
    + '<div id="pnLista">' + pnListaHtml(pnFiltrate()) + '</div>';
  pnFabSync();
  if (PN.cercaAperta) setTimeout(function(){ const i = document.getElementById('pnCerca'); if (i){ i.focus(); const v = i.value; i.value = ''; i.value = v; } }, 40);
}
function pnFiltrate(){
  const q = (PN.cerca || '').toLowerCase().trim();
  return pnPagine().slice().sort(function(a, b){ return (b.mod || 0) - (a.mod || 0); })
    .filter(function(p){ return !q || (p.titolo + ' ' + pnTesto(p.html)).toLowerCase().indexOf(q) >= 0; });
}
/** Le righe dell'anteprima: i paragrafi veri, non un blocco unico. */
function pnRighe(html){
  const d = document.createElement('div');
  d.innerHTML = String(html || '').replace(/<\/(p|div|li|h\d)>|<br\s*\/?>/gi, '\n');
  return (d.textContent || '').split('\n').map(function(r){ return r.trim(); }).filter(Boolean).slice(0, 9);
}
function pnGruppo(ms){
  const d = new Date(ms), oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  const t = new Date(d); t.setHours(0, 0, 0, 0);
  const giorni = Math.round((oggi - t) / 86400000);
  if (giorni <= 0) return 'Oggi';
  if (giorni === 1) return 'Ieri';
  if (giorni < ((oggi.getDay() + 6) % 7) + 1) return 'Questa settimana';
  if (d.getMonth() === oggi.getMonth() && d.getFullYear() === oggi.getFullYear()) return 'Questo mese';
  return pnCap(PN_MESI[d.getMonth()]) + (d.getFullYear() !== oggi.getFullYear() ? ' ' + d.getFullYear() : '');
}
function pnQuando(ms){
  const d = new Date(ms), g = pnGruppo(ms);
  if (g === 'Oggi') return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  return d.getDate() + ' ' + PN_MESI[d.getMonth()].slice(0, 3);
}
function pnListaHtml(l){
  if (!l.length) return '<p class="stf-vuoto piccolo">' + (PN.cerca ? 'Nessuna nota con queste parole.' : 'Idee, appunti, diario: tocca la matita per scrivere la prima.') + '</p>';
  let h = '', gruppo = '';
  l.forEach(function(p){
    const ms = p.mod || p.at || Date.now();
    const g = PN.cerca ? 'Risultati' : pnGruppo(ms);
    if (g !== gruppo){ h += (gruppo ? '</div>' : '') + '<h3 class="sn-gr">' + esc(g) + '</h3><div class="sn-griglia">'; gruppo = g; }
    const righe = pnRighe(p.html);
    h += '<button type="button" class="sn-nota" onclick="pnPaginaApri(\'' + p.id + '\')">'
      + '<span class="sn-prev">' + (righe.length ? righe.map(esc).join('<br>') : '<i>Vuota</i>') + '</span>'
      + '<b>' + esc(p.titolo || (righe[0] || 'Senza titolo')) + '</b>'
      + '<small>' + pnQuando(ms) + '</small></button>';
  });
  return h + '</div>';
}
function pnCerca(v){
  PN.cerca = String(v || '');
  const el = document.getElementById('pnLista'); if (el) el.innerHTML = pnListaHtml(pnFiltrate());
}
function pnCercaApri(){ PN.cercaAperta = true; pnPaintTab(); }
function pnCercaChiudi(){ PN.cercaAperta = false; PN.cerca = ''; pnPaintTab(); }
/* i tre puntini: le idee mandate in revisione a Jordan */
function pnMenu(ev){
  if (ev) ev.stopPropagation();
  const n = (typeof stRevLista === 'function') ? stRevLista().filter(function(x){ return x.stato === 'attesa'; }).length : 0;
  let m = document.getElementById('snMenu');
  if (m){ m.remove(); return; }
  m = document.createElement('div'); m.id = 'snMenu'; m.className = 'sn-menu';
  m.innerHTML = '<button type="button" onclick="pnRevApri()">🧞 Da rivedere' + (n ? ' (' + n + ')' : '') + '</button>';
  (document.getElementById('stfWrap') || document.body).appendChild(m);
  setTimeout(function(){ document.addEventListener('click', function via(){ const x = document.getElementById('snMenu'); if (x) x.remove(); document.removeEventListener('click', via); }); }, 0);
}
function pnRevApri(){ const x = document.getElementById('snMenu'); if (x) x.remove(); PN.vista = 'rev'; pnPaintTab(); }
function pnRevPaint(host){
  host.innerHTML = '<button type="button" class="pn-indietro" onclick="PN.vista=\'\';pnPaintTab()">‹ Tutte le note</button>'
    + '<h2 class="sn-sub">Da rivedere</h2>'
    + '<div class="stf-rev" id="stfRev"></div>';
  stRevPaint();
}
/* il pulsante tondo in basso a destra, come quello della matita di Samsung Notes */
function pnFabSync(){
  const wrap = document.getElementById('stfWrap'); if (!wrap) return;
  let f = document.getElementById('pnFab');
  const serve = STF.tab === 'note' && !PN.pagina && PN.vista !== 'rev';
  if (!serve){ if (f) f.hidden = true; return; }
  if (!f){
    f = document.createElement('button');
    f.id = 'pnFab'; f.type = 'button'; f.className = 'sn-fab'; f.setAttribute('aria-label', 'Nuova nota');
    f.innerHTML = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6"/><path d="M17.5 3.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>';
    f.onclick = pnPaginaNuova;
    wrap.appendChild(f);
  }
  f.hidden = false;
}
function pnPaginaNuova(){
  const l = pnPagine();
  const p = { id: 'p' + Date.now().toString(36), titolo: '', html: '', at: Date.now(), mod: Date.now() };
  l.push(p); pnPagineSalva(l);
  PN.pagina = p.id; pnPaintTab();
  setTimeout(function(){ const t = document.getElementById('pnPagTit'); if (t) t.focus(); }, 60);
}
function pnPaginaApri(id){ PN.pagina = id; pnPaintTab(); }
function pnPaginaChiudi(){
  try{ stfNoteSalva(); }catch(_){ }
  /* una pagina lasciata vuota non resta nell'elenco */
  const l = pnPagine(), p = l.filter(function(x){ return x.id === PN.pagina; })[0];
  if (p && !p.titolo && !pnTesto(p.html) && !/<img/i.test(p.html || '')) pnPagineSalva(l.filter(function(x){ return x !== p; }));
  PN.pagina = ''; stfBarShow(false); pnPaintTab();
}
function pnPaginaPaint(host){
  const p = pnPagine().filter(function(x){ return x.id === PN.pagina; })[0];
  if (!p){ PN.pagina = ''; pnNotePaint(host); return; }
  host.innerHTML = '<button type="button" class="pn-indietro" onclick="pnPaginaChiudi()">‹ Tutte le note</button>'
    + '<input class="pn-tit" id="pnPagTit" placeholder="Titolo" value="' + esc(p.titolo || '') + '" oninput="pnTitolo(this.value)">'
    + '<div class="stf-note pn-editor" id="stfNote" contenteditable="true" spellcheck="true" data-placeholder="Scrivi come vuoi: la barra sotto formatta." '
    +   'onfocus="stfBarShow(true)" onpointerdown="stfBarShow(true)" onblur="stfNoteSalva()" oninput="stfNoteDirty()"></div>'
    + '<button type="button" class="pn-del" onclick="pnPaginaElimina()">Elimina la pagina</button>';
  const ed = document.getElementById('stfNote'); if (ed) ed.innerHTML = p.html || '';
  STF_NOTE_DIRTY = false;
}
function pnTitolo(v){
  const l = pnPagine(), p = l.filter(function(x){ return x.id === PN.pagina; })[0]; if (!p) return;
  p.titolo = String(v || '').slice(0, 120); p.mod = Date.now(); pnPagineSalva(l);
}
function pnPaginaElimina(){
  if (!confirm('Eliminare questa pagina?')) return;
  pnPagineSalva(pnPagine().filter(function(x){ return x.id !== PN.pagina; }));
  PN.pagina = ''; stfBarShow(false); pnPaintTab();
}
/* Il salvataggio dell'editor: la pagina aperta. Sostituisce quello per giorno di start.js. */
function stfNoteSalva(){
  const ed = document.getElementById('stfNote'); if (!ed) return;
  if (!STF_NOTE_DIRTY) return;
  STF_NOTE_DIRTY = false;
  if (PN.pagina){
    const l = pnPagine(), p = l.filter(function(x){ return x.id === PN.pagina; })[0];
    if (p){ p.html = ed.innerHTML; p.mod = Date.now(); pnPagineSalva(l); }
  }
  stfBarShow(false);
}
/* La barra di scrittura nasconde e rimette il campo «scrivi una cosa»: fuori da Giorni resta nascosto. */
(function(){
  if (typeof stfBarShow !== 'function') return;
  const orig = stfBarShow;
  stfBarShow = function(on){
    orig(on);
    const add = document.getElementById('stfAdd');
    if (add && (STF.tab || 'giorni') !== 'giorni') add.hidden = true;
  };
})();

/* ---------------------------------------------------------------------------------------
   DOMANI: chiuso finche' oggi non e' finito
   --------------------------------------------------------------------------------------- */
function pnFineLavoro(){ try{ return localStorage.getItem('fl_fine_lavoro') || '18:00'; }catch(_){ return '18:00'; } }
function pnFineSet(v){
  if (!/^\d{1,2}:\d{2}$/.test(v || '')) return;
  try{ localStorage.setItem('fl_fine_lavoro', v); }catch(_){ }
  toast('Fine del lavoro: ' + v);
  try{ stPaint(); }catch(_){ }
}
function pnFineMin(){ const p = pnFineLavoro().split(':'); return (+p[0]) * 60 + (+p[1] || 0); }
function pnDopoFine(){ const d = new Date(); return d.getHours() * 60 + d.getMinutes() >= pnFineMin(); }
/** La priorita' di oggi e' fatta? Il flag lo scrive la spunta; se il foglio non ha niente da fare, lo e'. */
function pnPrioFatta(){
  const day = mtKey(Date.now());
  try{ if (localStorage.getItem('fl_prio_fatta_' + day)) return true; }catch(_){ }
  const righe = stRigheDi(day);
  if (!righe.length) return true;
  return !stPriorita(day, righe);
}
/* Le due condizioni si accendono dai tre puntini, e di serie sono spente: c'e' chi vuole
   vedere domani comunque. Accese, domani si apre solo quando valgono tutte e due. */
function pnCond(k){ try{ return localStorage.getItem('fl_domani_' + k) === '1'; }catch(_){ return false; } }
function pnCondSet(k){
  try{ localStorage.setItem('fl_domani_' + k, pnCond(k) ? '0' : '1'); }catch(_){ }
  stfDrawerPaint();
  try{ stPaint(); }catch(_){ }
  try{ if (document.getElementById('stfBody')) stfPaint(); }catch(_){ }
}
function pnDomaniAperto(){ return (!pnCond('prio') || pnPrioFatta()) && (!pnCond('fine') || pnDopoFine()); }
function pnLucchettoHtml(){
  const a = pnPrioFatta(), b = pnDopoFine();
  return '<div class="pn-lock">'
    + '<div class="pn-lock-ic">🔒</div>'
    + '<b>' + (pnCond('fine') ? 'Domani si apre a fine giornata' : 'Domani si apre a priorità fatta') + '</b>'
    + '<p>Prima chiudi oggi. Poi guardi domani, e ci dormi sopra.</p>'
    + (pnCond('prio') ? '<div class="pn-cond' + (a ? ' ok' : '') + '"><i>' + (a ? '✓' : '') + '</i>La priorità di oggi</div>' : '')
    + (pnCond('fine') ? '<div class="pn-cond' + (b ? ' ok' : '') + '"><i>' + (b ? '✓' : '') + '</i>Dopo le ' + pnFineLavoro() + '</div>' : '')
    + '</div>';
}
function pnDomaniHtml(){
  if (!pnDomaniAperto()) return pnLucchettoHtml();
  const day = mtKey(Date.now() + 86400000);
  const righe = stRigheDi(day);
  const man = righe.filter(function(r){ return stSezManuale(r, day) === 'one'; })[0];
  const rm = (typeof stPassoRoadmap === 'function') ? stPassoRoadmap() : null;
  const prio = man || (rm && rm.testo) || righe[0] || '';
  const altre = righe.filter(function(r){ return r !== prio && stNormRiga(r) !== stNormRiga(prio); }).slice(0, 4);
  if (!prio) return '<p class="st-onelbl">La priorità di domani</p>'
    + '<p class="st-vuoto">Il piano di domani non c’è ancora. Lo scrive il tuo agente personale dalla rotta.</p>'
    + (typeof agApri === 'function' ? '<button type="button" class="st-tutto" onclick="agApri()">Chiedilo al tuo agente personale <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="vertical-align:-2px"><path d="M9 6l6 6-6 6"/></svg></button>' : '');
  return '<p class="st-onelbl">La priorità di domani</p>'
    + '<div class="st-row st-one"><div class="st-lab">' + esc(prio) + '</div></div>'
    + (altre.length ? '<p class="st-onelbl pn-poi">Poi</p>' + altre.map(function(r){ return '<div class="st-row"><div class="st-lab pn-muto">' + esc(r) + '</div></div>'; }).join('') : '')
    + '<button type="button" class="st-tutto" onclick="pnApriDomani()">Apri domani nel foglio grande ›</button>';
}
function pnApriDomani(){ stFullOpen(); setTimeout(function(){ STF.off = 1; STF.tab = 'giorni'; stfPaint(); }, 60); }
/* chi tiene aperta la scheda Domani la vede aprirsi all'ora giusta, senza toccare niente */
let PN_APERTO_PRIMA = null;
setInterval(function(){
  try{
    const ora = pnDomaniAperto();
    if (PN_APERTO_PRIMA !== null && ora !== PN_APERTO_PRIMA && typeof STN !== 'undefined' && STN.tab === 'domani') stPaint();
    PN_APERTO_PRIMA = ora;
  }catch(_){ }
}, 60000);
document.addEventListener('fl:spunta', function(){
  setTimeout(function(){ try{ if (STN.tab === 'domani') stPaint(); }catch(_){ } }, 300);
});

/* ---------------------------------------------------------------------------------------
   I TRE PUNTINI: al posto del cassetto con calendario e obiettivi, l'ora di fine lavoro
   --------------------------------------------------------------------------------------- */
function stfDrawerPaint(){
  const el = document.getElementById('stfDrawer'); if (!el) return;
  el.innerHTML = '<div class="stfd-scrim" onclick="stfDrawerClose()"></div>'
    + '<div class="stfd-pane">'
    +   '<div class="pn-dr-top"><b>Impostazioni del piano</b><button type="button" class="stfd-x" onclick="stfDrawerClose()" aria-label="Chiudi">✕</button></div>'
    +   '<div class="pn-set">'
    +     '<div class="pn-set-h"><span>🔒</span><b>Quando si apre domani</b></div>'
    +     '<p>Spenti tutti e due, il piano di domani si vede sempre.</p>'
    +     '<div class="blk-swrow"><div><b>Dopo la priorità di oggi</b><small>Prima chiudi la cosa che conta.</small></div>'
    +       '<button type="button" class="switch' + (pnCond('prio') ? ' on' : '') + '" onclick="pnCondSet(\'prio\')"></button></div>'
    +     '<div class="blk-swrow"><div><b>Dopo la fine del lavoro</b><small>Domani si guarda a giornata chiusa.</small></div>'
    +       '<button type="button" class="switch' + (pnCond('fine') ? ' on' : '') + '" onclick="pnCondSet(\'fine\')"></button></div>'
    +   '</div>'
    +   '<div class="pn-set">'
    +     '<div class="pn-set-h"><span>🕕</span><b>Fine della giornata di lavoro</b></div>'
    +     '<p>L’ora da cui la giornata di lavoro è chiusa.</p>'
    +     '<input type="time" class="fin pn-ora" value="' + pnFineLavoro() + '" onchange="pnFineSet(this.value)">'
    +   '</div>'
    + '</div>';
}

/* ---------------------------------------------------------------------------------------
   LA ROADMAP: niente sezione mappa (c'e' gia' nel pannello e nella seconda diapositiva),
   e la seconda diapositiva apre la mappa
   --------------------------------------------------------------------------------------- */
document.addEventListener('click', function(e){
  const s = e.target && e.target.closest ? e.target.closest('#sevGlobo') : null;
  if (!s || e.target.closest('button, a, input')) return;
  if (!s.querySelector('.sev-globo-in')) return;
  try{ localStorage.setItem('fl_mp_vista', 'globo'); }catch(_){ }
  if (typeof mpOpen === 'function'){
    const prima = !!document.getElementById('mpFull');
    mpOpen();
    if (!prima && !document.getElementById('mpFull') && typeof toast === 'function') toast('La mappa si apre dopo la lettura del Genio');
  }
});

(function(){
  const css = [
    '#tab-severa #scMap{display:none !important}',
    '#sevGlobo .sev-globo-in{cursor:pointer}',
    /* le schede in fila, che scorrono di lato */
    '.pn-head .pn-head-t{flex:1;text-align:center;font:800 17px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .pn-head .pn-head-t{color:#fff}',
    '#s-notes.solo-note .pn-tabs,#s-notes.solo-note .stf-daynav,#s-notes.solo-note .stf-add{display:none !important}',
    '.pn-tabs{flex:none;min-width:0;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;padding:4px 0 8px;margin:0 -18px;padding-left:18px;padding-right:18px;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 22px,#000 calc(100% - 22px),transparent 100%);mask-image:linear-gradient(90deg,transparent 0,#000 22px,#000 calc(100% - 22px),transparent 100%)}',
    '.pn-tabs::-webkit-scrollbar{display:none}',
    '.pn-tabs button{flex:none;border:0;border-radius:999px;background:transparent;color:var(--muted);font:700 13px var(--font-body);padding:8px 12px;cursor:pointer;white-space:nowrap}',
    '.pn-tabs button.on{background:var(--blue,#0075E3);color:#fff}',
    '.stf-daynav{display:flex;align-items:center;justify-content:center;gap:12px;padding:4px 0 8px}',
    '.stf-daynav[hidden]{display:none}',
    '.stf-daynav b{min-width:150px;text-align:center;font:800 17px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .stf-daynav b{color:#fff}',
    '.pn-nav{margin:4px 0 12px}',
    /* le righe dei periodi */
    '.pn-per{border:1.5px solid var(--line);border-radius:16px;margin-bottom:8px;overflow:hidden}',
    '.pn-per.ora{border-color:var(--blue,#0075E3)}',
    '.pn-per-h{width:100%;display:flex;align-items:center;gap:12px;padding:12px 14px;border:0;background:transparent;text-align:left;cursor:pointer}',
    '.pn-per-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}',
    '.pn-per-t b{font:800 15px var(--font-body);color:var(--navy)}',
    'body.dark .pn-per-t b{color:#fff}',
    '.pn-per-t small{font:500 12.5px/1.4 var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.pn-per-n{flex:none;width:92px;display:flex;flex-direction:column;align-items:flex-end;gap:6px}',
    '.pn-per-n em{font:800 14px var(--font-body);font-style:normal;color:var(--navy)}',
    'body.dark .pn-per-n em{color:#fff}',
    '.pn-per.pieno .pn-per-n em{color:#1B9E6A}',
    '.pn-bar{display:block;width:100%;height:6px;border-radius:99px;background:var(--line);overflow:hidden}',
    '.pn-bar i{display:block;height:100%;width:0;border-radius:99px;background:#1B9E6A;transition:width .8s cubic-bezier(.2,.8,.2,1)}',
    '.pn-det{padding:0 14px 14px}',
    '.pn-lbl{display:block;margin:12px 0 6px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.pn-ob{min-height:24px;padding:10px 12px;border:1.5px dashed var(--line);border-radius:12px;font:700 14.5px/1.45 var(--font-body);color:var(--navy);outline:0}',
    'body.dark .pn-ob{color:#fff}',
    '.pn-ob:empty::before{content:attr(data-placeholder);color:var(--faint);font-weight:500}',
    '.pn-ms .stf-txt{font-size:14.5px}',
    '.pn-ms-add{width:100%;margin-top:8px}',
    '.pn-conto{margin:12px 0 0;font:600 12px var(--font-body);color:var(--faint)}',
    /* il calendario */
    '.pn-calfoot{display:flex;align-items:center;gap:12px;margin:16px 0 8px}',
    '.pn-calfoot .pn-bar{flex:1}',
    '.pn-calfoot em{font:700 12.5px var(--font-body);font-style:normal;color:var(--muted);white-space:nowrap}',
    '.stfd-g.meta i{background:#F2A900}',
    '.pn-leg{display:flex;gap:12px;align-items:center;justify-content:center;margin:8px 0 0;font:600 11.5px var(--font-body);color:var(--faint)}',
    '.pn-leg i{display:inline-block;width:6px;height:6px;border-radius:50%;margin-right:-6px}',
    '.pn-leg i.v{background:#1B9E6A}.pn-leg i.m{background:#F2A900}.pn-leg i.s{background:var(--faint)}',
    /* le note */
    '.pn-cerca{margin:4px 0 12px}.pn-cerca input{width:100%}',
    '.pn-nuova{width:100%;margin-bottom:16px;border:1.5px dashed var(--line);border-radius:14px;background:transparent;padding:12px;color:var(--blue,#0075E3);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .pn-nuova{color:#7FC3FF}',
    '.pn-nota{width:100%;display:flex;flex-direction:column;align-items:flex-start;gap:4px;padding:12px 14px;margin-bottom:8px;border:1.5px solid var(--line);border-radius:14px;background:transparent;text-align:left;cursor:pointer}',
    '.pn-nota b{font:800 15px var(--font-body);color:var(--navy)}',
    'body.dark .pn-nota b{color:#fff}',
    '.pn-nota span{font:500 13px/1.45 var(--font-body);color:var(--muted);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '.pn-nota small{font:600 11.5px var(--font-body);color:var(--faint)}',
    '.pn-indietro{border:0;background:transparent;padding:4px 0 12px;color:var(--blue,#0075E3);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .pn-indietro{color:#7FC3FF}',
    '.pn-tit{width:100%;border:0;outline:0;background:transparent;padding:0 0 12px;font:800 22px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .pn-tit{color:#fff}',
    '.pn-editor{min-height:260px}',
    '.pn-del{display:block;margin:24px auto 8px;border:0;background:transparent;color:#E63946;font:700 13px var(--font-body);cursor:pointer}',
    /* le note, come Samsung Notes */
    '.stf-wrap{position:relative}',
    '.sn-head{text-align:center;padding:32px 0 24px}',
    '.sn-tit{margin:0;font:800 32px/1.15 var(--font-body);color:var(--navy)}',
    'body.dark .sn-tit{color:#fff}',
    '.sn-conto{margin:8px 0 0;font:600 16px var(--font-body);color:var(--faint)}',
    '.sn-cerca{display:flex;gap:12px;align-items:center}.sn-cerca input{flex:1;min-width:0}',
    '.sn-annulla{border:0;background:transparent;color:var(--blue,#0075E3);font:700 14px var(--font-body);cursor:pointer}',
    'body.dark .sn-annulla{color:#7FC3FF}',
    '.sn-bar{display:flex;align-items:center;gap:8px;margin-bottom:8px}.sn-bar span{flex:1}',
    '.sn-ic{width:44px;height:44px;border:0;border-radius:50%;background:transparent;color:var(--navy);font:800 22px var(--font-body);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .sn-ic{color:#fff}',
    '.sn-gr{margin:16px 2px 12px;font:800 17px var(--font-body);color:var(--navy)}',
    'body.dark .sn-gr{color:#fff}',
    '.sn-griglia{display:grid;grid-template-columns:1fr 1fr;gap:16px 12px}',
    '.sn-nota{display:flex;flex-direction:column;align-items:center;gap:6px;border:0;background:transparent;padding:0;cursor:pointer;min-width:0}',
    '.sn-prev{display:block;width:100%;height:196px;overflow:hidden;padding:16px;border-radius:18px;background:#EEF1F5;text-align:left;font:500 14px/1.55 var(--font-body);color:var(--navy);-webkit-mask-image:linear-gradient(#000 78%,transparent);mask-image:linear-gradient(#000 78%,transparent)}',
    'body.dark .sn-prev{background:#1E232B;color:#fff}',
    '.sn-prev i{color:var(--faint)}',
    '.sn-nota b{max-width:100%;font:800 15px/1.3 var(--font-body);color:var(--navy);text-align:center;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    'body.dark .sn-nota b{color:#fff}',
    '.sn-nota small{font:600 12px var(--font-body);color:var(--faint)}',
    '.sn-fab{position:absolute;right:18px;bottom:calc(24px + env(safe-area-inset-bottom));z-index:5;width:64px;height:64px;border:0;border-radius:50%;background:#EEF1F5;color:#E5484D;box-shadow:0 8px 24px rgba(0,20,50,.18);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .sn-fab{background:#2A2F38;color:#FF5A5F}',
    '.sn-fab[hidden]{display:none}',
    '.sn-menu{position:absolute;right:18px;top:170px;z-index:8;min-width:190px;padding:6px;border-radius:14px;background:var(--card,#fff);box-shadow:0 12px 32px rgba(0,20,50,.2)}',
    '.sn-menu button{width:100%;border:0;background:transparent;padding:12px;text-align:left;font:700 14px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .sn-menu button{color:#fff}',
    '.sn-sub{margin:0 0 12px;font:800 22px var(--font-body);color:var(--navy)}body.dark .sn-sub{color:#fff}',
    '.pn-editor{border:0 !important;padding:4px 0 !important;min-height:60vh}',
    /* domani */
    '.pn-lock{text-align:center;padding:12px 8px 8px}',
    '.pn-lock-ic{font-size:30px;margin-bottom:8px}',
    '.pn-lock b{display:block;font:800 17px var(--font-body);color:var(--navy);margin-bottom:6px}',
    'body.dark .pn-lock b{color:#fff}',
    '.pn-lock p{margin:0 0 16px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.pn-cond{display:flex;align-items:center;gap:10px;justify-content:center;margin:8px 0;font:600 14px var(--font-body);color:var(--faint)}',
    '.pn-cond i{width:20px;height:20px;border-radius:50%;border:2px solid var(--line);display:inline-flex;align-items:center;justify-content:center;font:800 11px var(--font-body);font-style:normal;color:#fff}',
    '.pn-cond.ok{color:var(--navy)}body.dark .pn-cond.ok{color:#fff}',
    '.pn-cond.ok i{background:#1B9E6A;border-color:#1B9E6A}',
    '.pn-poi{margin-top:16px}',
    '.pn-muto{color:var(--muted) !important;font-size:14px}',
    /* i tre puntini */
    '.pn-dr-top{display:flex;align-items:center;margin-bottom:24px}',
    '.pn-dr-top b{flex:1;font:800 20px var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .pn-dr-top b{color:#fff}',
    '.pn-dr-top .stfd-x{border:0;width:36px;height:36px;border-radius:50%;background:transparent;color:var(--muted);font:700 16px var(--font-body);cursor:pointer}',
    '.pn-set{padding:16px;border:1.5px solid var(--line);border-radius:16px;margin-bottom:12px}',
    '.pn-set .blk-swrow{margin-top:12px}',
    '.pn-set-h{display:flex;align-items:center;gap:8px}',
    '.pn-set-h b{font:800 16px var(--font-body);color:var(--navy)}',
    'body.dark .pn-set-h b{color:#fff}',
    '.pn-set p{margin:6px 0 12px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}',
    '.pn-ora{width:100%;text-align:center;font-size:18px}'
  ].join('\n');
  const st = document.createElement('style'); st.id = 'pn-css'; st.textContent = css;
  document.head.appendChild(st);
})();
