/* ads.js — advertising for free users, nothing at all for Premium.
 *
 * WHY THIS FILE EXISTS AT ALL: the free tier has to pay for itself, and an app-blocker that
 * shows ads on top of a block screen gets removed from Play as "disruptive advertising". So
 * the whole point of this module is that every rule that could get us removed is enforced in
 * ONE place instead of being sprinkled across the UI.
 *
 * THE FOUR RULES, in the order they are enforced below:
 *   1. Premium is gated UPSTREAM. For a Premium user we never call initialize() and never
 *      load anything. Hiding a banner is not enough: the banner is a NATIVE view attached to
 *      the WebView, so "hidden" still means the SDK was started and the network call went out.
 *   2. UMP consent FIRST, then initialize(), then the ad request. Never the other way round:
 *      requesting an ad before the consent form has resolved is what gets an AdMob account
 *      suspended in the EEA/UK.
 *   3. "Impostazioni privacy" is a PERMANENT entry point, not a one-off dialog. Google
 *      requires the user to be able to change their consent at any moment.
 *   4. Never over the block screen. See adsSuspendForBlocking().
 *
 * NO PLUGIN, NO ADS, NO ERRORS: everything below detects @capacitor-community/admob at
 * runtime. In a plain browser (and in any build where the plugin is missing) this module
 * quietly does nothing, exactly like the rest of the app degrades without NATIVE.
 */

/* ============================================================================
 * ⬇⬇⬇  THE SINGLE POINT TO REPLACE WHEN THE REAL ADMOB ACCOUNT EXISTS  ⬇⬇⬇
 *
 * These are GOOGLE'S OFFICIAL TEST IDS. They are safe to ship in development and they are
 * the only correct thing to use while no AdMob account exists: requesting real ads with a
 * real unit id from a device you own is click/impression fraud and gets the account banned.
 *
 * To go live:
 *   1. Create the AdMob account and the app, get the App ID (the one with the "~").
 *   2. Replace it in android/app/src/main/res/values/strings.xml → admob_app_id.
 *      (It is ALREADY wired in AndroidManifest.xml as com.google.android.gms.ads.APPLICATION_ID.
 *       If that meta-data is missing or wrong the app CRASHES at launch — do not remove it.)
 *   3. Replace AD_UNITS.banner below with the real banner unit id (the one with the "/").
 *   4. Set AD_TESTING to false.
 *   5. In the AdMob console create the GDPR/UMP message, otherwise requestConsentInfo()
 *      returns isConsentFormAvailable:false and no form can ever be shown.
 * Nothing else in the codebase needs to change.
 * ========================================================================== */
const AD_UNITS = {
  // Interstitial only. The banner was killed on the owner's call: it ate a strip of every
  // screen, mismeasured against --ad-height leaving a white band over the nav, and looked
  // cheap. A full-screen ad at a natural transition shows less often and is worth more.
  interstitial: 'ca-app-pub-7654891718335397/2703582701',  // FocusLock Interstitial (reale)
  // IL VIDEO CON RICOMPENSA (0.9.206): la mystery box raddoppia il premio a chi lo guarda. Finche'
  // Andrea non crea l'unita' «Rewarded» su AdMob, qui c'e' l'id di prova ufficiale di Google:
  // mostra annunci di prova, non guadagna, non fa bandire nessuno. Da sostituire con quello vero.
  rewarded: 'ca-app-pub-3940256099942544/5224354917'
};
const AD_TESTING = false;  // ID reali attivi dal 11/09/2026
/* ========================================================================== */

/* Screens that must NEVER carry a banner. The full-screen block screen is the one that would
   cost us the listing; the paywall is here because an ad next to a price is a dark pattern
   and reads as one to a reviewer. */
const ADS_FORBIDDEN_SCREENS = ['s11', 's-block', 's-blocked', 's-lock', 's-blocking'];

/* One object instead of five loose flags, so every early-return below can say WHY. */
const adsState = {
  plugin: null,        // the AdMob plugin handle, or null
  reason: 'boot',      // why ads are currently off — shown in Profilo, useful in support
  consent: null,       // last AdmobConsentInfo
  initialized: false,  // initialize() actually called (never true for Premium)
  showing: false,      // a banner is on screen right now
  suspended: false,    // a block screen (or another forbidden surface) is up
  height: 0            // px reserved in layout for the banner
};

/* The banner is a native view laid over the bottom of the WebView: without reserving room the
   bottom nav sits underneath it. --ad-height is 0px for Premium and for anyone with no ads,
   so nobody ever sees an empty strip. */
(function adsInjectStyle(){
  const css = document.createElement('style');
  css.id = 'uf-ads-style';
  css.textContent = `
    :root{ --ad-height: 0px; }
    /* Room for the banner: the tab pages scroll, so they get extra bottom padding, and the
       fixed bottom nav is lifted by exactly the banner height. */
    .tabpage{ padding-bottom: calc(96px + var(--ad-height)) !important; }
    .bottomnav{ bottom: var(--ad-height) !important; }
    .screen{ padding-bottom: calc(20px + env(safe-area-inset-bottom) + var(--ad-height)) !important; }
    .uf-ads-note{ font:500 11px/1.5 var(--font-body); color:var(--faint); margin-top:8px; }
  `;
  document.head.appendChild(css);
})();

function adsSetHeight(px){
  adsState.height = px || 0;
  document.documentElement.style.setProperty('--ad-height', (px || 0) + 'px');
}

function adsPlugin(){
  if (adsState.plugin) return adsState.plugin;
  const p = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob;
  adsState.plugin = p || null;
  return adsState.plugin;
}

/* True when this user must not see ads at all. Premium is read through the billing module so
   there is exactly one definition of "is this user paying" in the whole app.
   `typeof` and not `window.Premium`: these are classic scripts, and a top-level `const` lands
   in the global LEXICAL scope, never as a property of window. profile.js also mirrors it onto
   window, but this guard is what makes the module safe if profile.js ever fails to load —
   and a missing billing module must mean "not premium", not a thrown error mid-boot. */
function adsUserIsPremium(){
  try { return typeof Premium !== 'undefined' && !!Premium.isPremium(); } catch(e){ return false; }
}
function adsPremiumModule(){
  try { return typeof Premium !== 'undefined' ? Premium : null; } catch(e){ return null; }
}

/* ---------- BOOT: consent → initialize → banner, in that order and no other ---------- */

async function adsBoot(){
  // RULE 1 — Premium gating happens BEFORE anything else touches the SDK.
  if (adsUserIsPremium()){
    adsState.reason = 'premium';
    await adsTeardown();       // covers the upgrade case: they just paid, the banner must go
    adsSetHeight(0);
    return;
  }
  const AdMob = adsPlugin();
  if (!AdMob){
    // Browser preview, or a build without the plugin. Not an error, not a toast: no ads.
    adsState.reason = 'no-plugin';
    adsSetHeight(0);
    return;
  }
  try {
    // RULE 2 — consent first. requestConsentInfo() is what talks to the UMP SDK; outside the
    // EEA/UK it comes back NOT_REQUIRED in a few ms and we simply carry on.
    adsState.consent = await AdMob.requestConsentInfo({});
    if (adsState.consent && adsState.consent.status === 'REQUIRED'
        && adsState.consent.isConsentFormAvailable){
      adsState.consent = await AdMob.showConsentForm();
    }
  } catch(e){
    // A consent failure must not become a silent "show ads anyway": that is the exact
    // behaviour that gets an AdMob account suspended. We stop here instead.
    adsState.reason = 'consent-failed: ' + (e && e.message ? e.message : 'errore sconosciuto');
    adsSetHeight(0);
    return;
  }

  try {
    await AdMob.initialize({ initializeForTesting: AD_TESTING });
    adsState.initialized = true;
  } catch(e){
    adsState.reason = 'init-failed: ' + (e && e.message ? e.message : 'errore sconosciuto');
    adsSetHeight(0);
    return;
  }

  adsState.reason = 'ok';
  adsPrepareInterstitial();
}

/* ---------- INTERSTITIAL CYCLE ----------

   prepare -> (transition happens) -> maybeShow -> prepare again.

   The cadence rules live in one place, here:
   - never for Premium, never before consent+init, never over a block screen (RULE 4);
   - a cooldown between showings, because a full-screen ad at EVERY transition is how an app
     earns one-star reviews and an "annoying ads" policy strike;
   - the first transition after launch never shows an ad: someone who has just opened the app
     to fix a rule must not be paywalled by advertising before doing anything.
*/
const ADS_INTERSTITIAL_COOLDOWN_MS = 3 * 60 * 1000;
let adsInterstitialReady = false;
let adsLastInterstitialAt = 0;
let adsFirstTransitionSeen = false;

function adsPrepareInterstitial(){
  const AdMob = adsPlugin();
  if (!AdMob || !adsState.initialized || adsUserIsPremium()) return;
  try {
    AdMob.prepareInterstitial({
      adId: AD_UNITS.interstitial,
      isTesting: AD_TESTING,
      // Non-personalised whenever the user did not (or could not) consent: serving
      // personalised ads without OBTAINED consent is the GDPR violation, not the ad itself.
      npa: !(adsState.consent && adsState.consent.status === 'OBTAINED')
    }).then(() => { adsInterstitialReady = true; })
      .catch((e) => {
        adsInterstitialReady = false;
        adsState.reason = 'no-fill' + (e && e.code !== undefined ? ' (' + e.code + ')' : '');
      });
  } catch(e){ adsInterstitialReady = false; }
}

/* Called by the UI at natural transitions (a program saved, a new program opened). Decides
   on its own whether this particular transition earns an ad; callers never need to know. */
let adsBootStarted = false;
function adsEnsureBooted(){
  if (adsBootStarted) return;
  adsBootStarted = true;
  adsBoot();
}
function adsMaybeInterstitial(trigger){
  const AdMob = adsPlugin();
  if (!AdMob) return;
  if (adsUserIsPremium()) return;
  if (adsState.suspended || adsOnForbiddenScreen()) return;
  if (!adsFirstTransitionSeen){ adsFirstTransitionSeen = true; adsEnsureBooted(); return; }
  if (!adsState.initialized) return;
  const now = Date.now();
  if (now - adsLastInterstitialAt < ADS_INTERSTITIAL_COOLDOWN_MS) return;
  if (!adsInterstitialReady){ adsPrepareInterstitial(); return; }

  adsInterstitialReady = false;
  adsLastInterstitialAt = now;
  try {
    AdMob.showInterstitial()
      .then(() => { adsState.reason = 'ok (' + (trigger || 'transition') + ')'; })
      .catch((e) => { adsState.reason = 'show-failed: ' + (e && e.message ? e.message : '?'); });
  } catch(e){ adsState.reason = 'show-failed: ' + (e && e.message ? e.message : '?'); }
  // The next one starts loading right away, so the cooldown - not the network - is the gate.
  setTimeout(adsPrepareInterstitial, 4000);
}

/* removeBanner(), not hideBanner(): a hidden native view is still an attached view, and on an
   upgrade to Premium the user must be left with nothing at all. */
async function adsTeardown(){
  const AdMob = adsPlugin();
  adsState.showing = false;
  adsSetHeight(0);
  if (!AdMob) return;
  try { await AdMob.removeBanner(); } catch(e){ /* nothing was showing */ }
}

/* ---------- RULE 4 — never over a block screen ---------- */

function adsOnForbiddenScreen(){
  if (document.body && document.body.dataset && document.body.dataset.blocking === '1') return true;
  for (const id of ADS_FORBIDDEN_SCREENS){
    const el = document.getElementById(id);
    if (el && el.classList.contains('active')) return true;
  }
  return false;
}

/* Public, and meant to be called by whoever puts a full-screen block UI on top: the banner is
   torn down, not hidden, and nothing can reload it until adsEndBlocking() says so. */
async function adsSuspendForBlocking(){
  adsState.suspended = true;
  await adsTeardown();
}
async function adsEndBlocking(){
  adsState.suspended = false;   // interstitials check this flag at show time; nothing to redraw
}

/* Belt and braces: if a screen becomes .active while a banner is up, or body[data-blocking]
   flips, we react without the other lanes having to remember to call us. Attributes only, so
   this observer costs nothing on ordinary DOM churn. */
(function adsWatchSurface(){
  const phone = document.getElementById('phone');
  if (!phone || typeof MutationObserver === 'undefined') return;
  const obs = new MutationObserver(() => {
    // With interstitials there is nothing on screen to tear down; the flag is enough, because
    // adsMaybeInterstitial() consults it before every show.
    adsState.suspended = adsOnForbiddenScreen();
  });
  obs.observe(phone, { attributes: true, subtree: true, attributeFilter: ['class'] });
  if (document.body) obs.observe(document.body, { attributes: true, attributeFilter: ['data-blocking'] });
})();

/* ---------- RULE 3 — the permanent privacy entry point ---------- */

/* Wired to the "Impostazioni privacy" row in Profilo. Google requires this to be reachable at
   any time, not only at first launch.
   NOTE for whoever upgrades the plugin: @capacitor-community/admob 6.2.0 has no
   showPrivacyOptionsForm(); resetConsentInfo() + requestConsentInfo() + showConsentForm() is
   the equivalent round trip with this version. If a later version adds it, call it here — this
   function is the only place that has to change. */
async function adsPrivacySettings(){
  const AdMob = adsPlugin();
  if (!AdMob){
    toast('Le impostazioni privacy della pubblicità sono disponibili solo nell’app installata');
    return;
  }
  if (adsUserIsPremium()){
    toast('Sei Premium: DreamMap non carica pubblicità, non c’è nessun consenso da gestire');
    return;
  }
  try {
    await AdMob.resetConsentInfo();
    adsState.consent = await AdMob.requestConsentInfo({});
    if (adsState.consent && adsState.consent.isConsentFormAvailable){
      adsState.consent = await AdMob.showConsentForm();
      toast('Preferenze aggiornate');
      // A changed consent changes what we are allowed to request: reload with the new npa.
      adsInterstitialReady = false;
      adsPrepareInterstitial();
    } else {
      toast('Nessun modulo di consenso disponibile per il tuo Paese');
    }
  } catch(e){
    toast(e && e.message ? e.message : 'Impossibile aprire le impostazioni privacy');
  }
}

/* What Profilo prints under the privacy row, so the state is never a mystery in support. */
function adsStatusLabel(){
  if (adsUserIsPremium()) return 'nessuna pubblicità (Premium)';
  if (!adsPlugin()) return 'non disponibile in anteprima';
  if (adsState.reason === 'ok' && adsState.showing) return 'attiva';
  if (adsState.reason === 'ok') return 'in caricamento';
  if (adsState.reason === 'no-fill') return 'nessun annuncio disponibile';
  return adsState.reason;
}

/* Called by the billing module the moment Premium turns on or off, so a downgrade brings the
   banner back and an upgrade removes it — both without a restart. */
async function adsOnPremiumChanged(){
  if (adsUserIsPremium()){
    adsState.reason = 'premium';
    await adsTeardown();
  } else if (adsBootStarted){
    await adsBoot();          // a downgrade brings the banner back only where it already was
  }
  if (typeof renderProfile === 'function') renderProfile();
}

/* ---------- start ---------- */
/* Deferred one tick: profile.js defines Premium just above us in load order, but nav.js (which
   builds the home shell state) runs after us, and booting the SDK before the first paint just
   makes the launch slower. */
setTimeout(() => {
  const P = adsPremiumModule();
  if (P && typeof P.onChange === 'function') P.onChange(adsOnPremiumChanged);
  // Never at launch, never after onboarding, never after a restore: the SDK (and, in the EEA,
  // the consent form) starts the first time the app is about to show an interstitial, i.e. on
  // a transition the user caused (a program saved or opened) - and then only once.
}, 0);


/* ============================================================================
 * LA RICOMPENSA (0.9.206): un video intero in cambio del doppio del premio della mystery box.
 * Solo con il modulo nativo e solo per chi non ha Premium (a Premium i premi sono gia' pieni).
 * ============================================================================ */
let adsRewardReady = false;
function adsRicompensaPossibile(){ return !!adsPlugin() && !adsUserIsPremium() && !!AD_UNITS.rewarded; }
function adsPrepareRewarded(){
  const AdMob = adsPlugin();
  if (!AdMob || !adsState.initialized || adsUserIsPremium() || !AD_UNITS.rewarded) return Promise.resolve(false);
  return AdMob.prepareRewardVideoAd({ adId: AD_UNITS.rewarded, isTesting: AD_TESTING || AD_UNITS.rewarded.indexOf('3940256099942544') >= 0, npa: !(adsState.consent && adsState.consent.status === 'OBTAINED') })
    .then(function(){ adsRewardReady = true; return true; })
    .catch(function(){ adsRewardReady = false; return false; });
}
async function adsRicompensa(dopo){
  const AdMob = adsPlugin();
  if (!AdMob || adsUserIsPremium()){ return; }
  adsEnsureBooted();
  if (!adsState.initialized){ toast('Gli annunci non sono pronti: riprova fra poco'); return; }
  try{
    if (!adsRewardReady){ const ok = await adsPrepareRewarded(); if (!ok){ toast('Nessun video disponibile adesso'); return; } }
    adsRewardReady = false;
    const r = await AdMob.showRewardVideoAd();
    /* il premio arriva solo a video finito: il plugin risolve con la ricompensa */
    if (r && (r.amount !== undefined || r.type !== undefined)){ if (typeof dopo === 'function') dopo(r); }
    else if (typeof dopo === 'function') dopo(r || {});
  }catch(e){ adsState.reason = 'reward-failed: ' + (e && e.message ? e.message : '?'); toast('Il video non è partito'); }
  setTimeout(adsPrepareRewarded, 3000);
}
/* ============================================================================
 * DOPO LA TAPPA (0.9.206): per chi non ha Premium, prima un annuncio (se c'e'), poi la schermata
 * che propone di saltarli con la prova gratuita. Una volta al giorno, non a ogni tappa.
 * Risponde true se si prende in carico la continuazione (`dopo`), false se non c'e' niente da fare.
 * ============================================================================ */
function adsDopoTappa(dopo){
  if (adsUserIsPremium()) return false;
  let g = ''; try{ g = localStorage.getItem('fl_upsell_giorno') || ''; }catch(_){ }
  const oggi = new Date().toDateString();
  try{ adsMaybeInterstitial('tappa'); }catch(_){ }
  if (g === oggi) return false;
  try{ localStorage.setItem('fl_upsell_giorno', oggi); }catch(_){ }
  if (typeof pwUpsellApri !== 'function') return false;
  /* l'annuncio, se parte, copre tutto: la proposta si apre dopo che si e' chiuso */
  setTimeout(function(){ pwUpsellApri(dopo); }, adsPlugin() ? 1200 : 0);
  return true;
}
