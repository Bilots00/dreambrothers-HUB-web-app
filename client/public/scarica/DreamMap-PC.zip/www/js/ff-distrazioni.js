/* ===========================================================================================
   IL FOGLIO DELLE DISTRAZIONI (0.9.350, Andrea, ritratto di Clarify "Create your distraction paper")

   Durante una sessione di Full Focus viene sempre in mente qualcos'altro: la mail da mandare,
   la cosa da comprare. Inseguirla rompe la sessione; tenerla in testa la rompe lo stesso.
   La si scrive da qualche parte e si torna al lavoro. Due strade, e la sceglie l'utente:

     - SU UN FOGLIO DI CARTA, accanto a te: il telefono resta chiuso.
     - NEL TELEFONO: si mette in pausa e si scrive nell'appunto della pausa. L'appunto finisce
       nella nota "Idee e note" (mappa-note.js, mnInboxAggiungi), cioe' proprio la lista che
       l'esercizio serale Taglia legge (mnIdeePerTaglia): la sera si taglia quello che non conta.

   La pagina con le quattro vignette compare dopo il primo saluto del Genio sulla pagina del
   Full Focus (dream-storia.js, drsPagina) e si riapre dalle Impostazioni del Full Focus.

   Chiavi:
     fl_ff_distrazioni   'carta' | 'telefono'  la scelta
     fl_ff_appunti       [{ t, at, start }]    gli appunti presi in pausa (il segno da dove vengono)
   =========================================================================================== */

const FFD_KEY = 'fl_ff_distrazioni', FFD_APPUNTI = 'fl_ff_appunti';
/* il segno davanti alla riga nella nota: dice che l'appunto viene da una pausa del Full Focus */
const FFD_SEGNO = '⏸️ ';
const FFD = { modo: '', da: '' };

function ffdScelta(){ try{ const v = localStorage.getItem(FFD_KEY) || ''; return (v === 'carta' || v === 'telefono') ? v : ''; }catch(_){ return ''; } }
function ffdSceltaSalva(v){ try{ localStorage.setItem(FFD_KEY, v); }catch(_){ } }
function ffdEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s || '').replace(/[&<>"']/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function ffdVibra(v){ try{ if (typeof flVibra === 'function') flVibra(v); }catch(_){ } }

/* ---------------------------------------------------------------- l'appunto della pausa */
/* Solo nella pausa di una sessione: col timer acceso non c'e', e nella pausa libera dopo la sessione nemmeno. */
function ffdAppuntoMonta(w){
  if (!w || document.getElementById('ffdA')) return;
  const c = w.querySelector('.ffp-c'); if (!c) return;
  const box = document.createElement('div');
  box.id = 'ffdA'; box.className = 'ffda';
  box.innerHTML = '<b class="ffda-t">Appunta una distrazione</b>'
    + '<p class="ffda-s">Scrivila qui e torna al lavoro. Stasera la ritrovi in Taglia.</p>'
    + '<textarea id="ffdaIn" class="ffda-in" rows="3" maxlength="300" placeholder="Cosa ti è venuto in mente?"></textarea>'
    + '<button type="button" class="ffda-ok" onclick="ffdAppuntoSalva()">Salva</button>';
  c.appendChild(box);
  w.classList.add('ffp-con-appunto');
}
function ffdAppuntoTesto(){ const ta = document.getElementById('ffdaIn'); return ta ? String(ta.value || '').trim() : ''; }
/* Le righe vanno nella nota "Idee e note": la stessa lista che Taglia legge la sera. */
function ffdAppuntoScrivi(t){
  const righe = String(t || '').split(/\n+/).map(function(x){ return x.trim(); }).filter(Boolean);
  if (!righe.length) return false;
  let ok = false;
  try{ if (typeof mnInboxAggiungi === 'function') ok = !!mnInboxAggiungi(righe.map(function(r){ return FFD_SEGNO + r; }).join('\n')); }catch(_){ ok = false; }
  try{
    const l = JSON.parse(localStorage.getItem(FFD_APPUNTI) || '[]') || [];
    const start = (typeof FF !== 'undefined' && FF.run && FF.run.startAt) || 0;
    righe.forEach(function(r){ l.push({ t: r.slice(0, 300), at: Date.now(), start: start, nota: ok }); });
    localStorage.setItem(FFD_APPUNTI, JSON.stringify(l.slice(-200)));
  }catch(_){ }
  return ok;
}
function ffdAppuntoSalva(){
  const t = ffdAppuntoTesto();
  const ta = document.getElementById('ffdaIn');
  if (!t){ if (ta) ta.focus(); return; }
  const ok = ffdAppuntoScrivi(t);
  if (ta){ ta.value = ''; ta.blur(); }
  ffdVibra(12);
  if (typeof toast === 'function') toast(ok ? 'Salvato. Lo ritrovi stasera in Taglia' : 'Salvato tra gli appunti della sessione');
}
/* la pausa che finisce da sola (o "Ho finito prima") con il testo ancora nel campo: si salva, non si butta */
function ffdAppuntoBozza(){
  const t = ffdAppuntoTesto(); if (!t) return;
  const ta = document.getElementById('ffdaIn'); if (ta) ta.value = '';
  const ok = ffdAppuntoScrivi(t);
  if (typeof toast === 'function') toast(ok ? 'Appunto salvato. Lo ritrovi stasera in Taglia' : 'Appunto salvato');
}

/* ---------------------------------------------------------------- le vignette */
/* Disegni fatti di forme semplici ed emoji, sui colori del brand: niente immagini da scaricare. */
const FFD_FOGLIO = function(righe, x, y, r){
  return '<svg class="ffdv-foglio" viewBox="0 0 70 86" style="left:' + x + ';top:' + y + ';transform:rotate(' + (r || 0) + 'deg)" aria-hidden="true">'
    + '<path d="M4 4h46l16 16v62H4z" fill="#fff" stroke="#001E44" stroke-width="2.4" stroke-linejoin="round"/>'
    + '<path d="M50 4v16h16" fill="#C8EFFD" stroke="#001E44" stroke-width="2.4" stroke-linejoin="round"/>'
    + (righe ? '<path d="M14 34h34M14 46h40M14 58h28" stroke="#3F9FF4" stroke-width="3" stroke-linecap="round"/>' : '<path d="M14 34h40M14 46h40M14 58h40M14 70h40" stroke="#C8EFFD" stroke-width="2"/>')
    + '</svg>';
};
const FFD_TELEFONO = function(dentro, x, y, r){
  return '<div class="ffdv-tel" style="left:' + x + ';top:' + y + ';transform:rotate(' + (r || 0) + 'deg)"><i></i>' + dentro + '</div>';
};
const FFD_STELLA = '<svg class="ffdv-st" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 2.5l2.900 6.100 6.600.800-4.900 4.600 1.300 6.600L12 17.300 6.100 20.600l1.300-6.600L2.500 9.400l6.600-.800z" fill="#8CC6FF"/></svg>';
const FFD_LUNA = '<svg class="ffdv-luna" viewBox="0 0 40 40" aria-hidden="true"><path d="M26 5a15 15 0 1 0 9 26A13 13 0 0 1 26 5z" fill="#3F9FF4" stroke="#001E44" stroke-width="2.400" stroke-linejoin="round"/></svg>';
const FFD_TIMER = FFD_STELLA + '<b class="ffdv-ora">25:00</b>';
const FFD_PAUSA = '<span class="ffdv-pausa"><i></i><i></i></span><b class="ffdv-ora">12:40</b>';
const FFD_APPUNTO = '<span class="ffdv-campo"><i></i><i></i><i></i></span><span class="ffdv-salva">Salva</span>';
const FFD_E = function(e, x, y, cls, rot){ return '<span class="ffdv-e' + (cls ? ' ' + cls : '') + '" style="left:' + x + ';top:' + y + (rot ? ';transform:rotate(' + rot + 'deg)' : '') + '">' + e + '</span>'; };
const FFD_ICO_CARTA = '<svg viewBox="0 0 70 86" width="58" height="72" aria-hidden="true"><path d="M4 4h46l16 16v62H4z" fill="#fff" stroke="#001E44" stroke-width="2.400" stroke-linejoin="round"/><path d="M50 4v16h16" fill="#C8EFFD" stroke="#001E44" stroke-width="2.400" stroke-linejoin="round"/><path d="M14 34h34M14 46h40M14 58h28" stroke="#3F9FF4" stroke-width="3" stroke-linecap="round"/></svg>';
const FFD_ICO_TEL = '<svg viewBox="0 0 50 86" width="44" height="76" aria-hidden="true"><rect x="2" y="2" width="46" height="82" rx="10" fill="#001E44"/><rect x="7" y="12" width="36" height="62" rx="5" fill="#C8EFFD"/><rect x="18" y="5" width="14" height="3" rx="1.500" fill="#3F9FF4"/><path d="M13 30h24M13 40h24M13 50h16" stroke="#0075E3" stroke-width="3" stroke-linecap="round"/></svg>';
function ffdVignette(modo){
  if (modo === 'carta') return [
    { t: 'Prendi un foglio', d: '<div class="ffdv-sf a"></div>' + FFD_FOGLIO(false, '30%', '2%', -6) + FFD_E('✏️', '64%', '38%', '', 18) },
    { t: 'Avvia la sessione di Full Focus', d: '<div class="ffdv-sf b"></div>' + FFD_TELEFONO(FFD_TIMER, '40%', '0%', 4) + FFD_E('👆', '12%', '42%') },
    { t: 'Ti viene in mente altro? Scrivilo sul foglio:<br>ti aspetta lì', l: true, d: '<div class="ffdv-sf a"></div>' + FFD_FOGLIO(true, '34%', '0%', -4) + FFD_E('🐈', '52%', '18%', 'big') + FFD_E('💭', '67%', '0%') + FFD_E('✍️', '18%', '24%') },
    { t: 'Torna al tuo lavoro', l: true, d: '<div class="ffdv-sf b"></div><div class="ffdv-banco"></div>' + FFD_E('🧑‍💻', '28%', '6%', 'big') + FFD_FOGLIO(true, '56%', '6%', 8) + FFD_E('⏰', '78%', '0%') }
  ];
  return [
    { t: 'Avvia la sessione di Full Focus', d: '<div class="ffdv-sf b"></div>' + FFD_TELEFONO(FFD_TIMER, '40%', '0%', -4) + FFD_E('👆', '12%', '42%') },
    { t: 'Ti viene in mente altro? Metti in pausa', d: '<div class="ffdv-sf a"></div>' + FFD_TELEFONO(FFD_PAUSA, '28%', '0%', 4) + FFD_E('💭', '66%', '4%') },
    { t: 'Scrivilo nell’appunto:<br>ti aspetta lì', l: true, d: '<div class="ffdv-sf b"></div>' + FFD_TELEFONO(FFD_APPUNTO, '34%', '0%', -3) + FFD_E('🐈', '54%', '18%', 'big') + FFD_E('✍️', '18%', '24%') },
    { t: 'Stasera lo tagli in Taglia', l: true, d: '<div class="ffdv-sf a"></div>' + FFD_LUNA + '<div class="ffdv-lista"><i></i><i class="via"></i><i></i><i class="via"></i></div>' + FFD_E('✂️', '66%', '12%', 'big', -20) }
  ];
}
/* il numero davanti a ogni didascalia, come nelle vignette di un fumetto */
function ffdDidascalia(v, i){ return (i + 1) + '. ' + String(v.t); }

/* ---------------------------------------------------------------- la pagina */
function ffdFoglioApri(da){
  FFD.da = da || '';
  FFD.modo = ffdScelta();
  let w = document.getElementById('ffdFoglio');
  if (!w){
    w = document.createElement('div'); w.id = 'ffdFoglio'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true');
    (document.getElementById('phone') || document.body).appendChild(w);
  }
  /* da Impostazioni con la scelta gia' fatta si vedono subito le vignette; la prima volta si sceglie */
  if (FFD.modo && FFD.da === 'impostazioni') ffdVignettePaint(); else ffdScegliPaint();
  requestAnimationFrame(function(){ w.classList.add('in'); });
  ffdVibra(8);
}
function ffdX(){ return '<button type="button" class="ffdf-x" onclick="ffdFoglioChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'; }
function ffdScegliPaint(){
  const w = document.getElementById('ffdFoglio'); if (!w) return;
  const m = FFD.modo;
  w.innerHTML = '<div class="ffdf-c centro">' + ffdX()
    + '<h2 class="ffdf-h">Il foglio delle distrazioni</h2>'
    + '<p class="ffdf-p">Durante la sessione ti viene in mente altro?<br>Scegli dove lo scrivi.</p>'
    + '<div class="ffdf-due">'
    +   '<button type="button" class="ffdf-op' + (m === 'carta' ? ' on' : '') + '" onclick="ffdScegli(\'carta\')"><span class="ffdf-op-e">' + FFD_ICO_CARTA + '</span><b>Su un foglio di carta</b><small>Il telefono resta chiuso.</small></button>'
    +   '<button type="button" class="ffdf-op' + (m === 'telefono' ? ' on' : '') + '" onclick="ffdScegli(\'telefono\')"><span class="ffdf-op-e">' + FFD_ICO_TEL + '</span><b>Nel telefono</b><small>Lo scrivi nella pausa.</small></button>'
    + '</div></div>';
}
function ffdScegli(v){
  FFD.modo = v; ffdSceltaSalva(v);
  ffdVibra(10);
  try{ if (typeof fxSuona === 'function') fxSuona('scelta'); }catch(_){ }
  ffdVignettePaint();
}
function ffdVignettePaint(){
  const w = document.getElementById('ffdFoglio'); if (!w) return;
  const m = FFD.modo || 'telefono', v = ffdVignette(m);
  w.innerHTML = '<div class="ffdf-c">' + ffdX()
    + '<h2 class="ffdf-h">Il foglio delle distrazioni</h2>'
    + '<div class="ffdf-scelta"><span>' + (m === 'carta' ? 'Su un foglio di carta' : 'Nel telefono') + '</span><button type="button" onclick="ffdScegliPaint()">Cambia</button></div>'
    + '<div class="ffdf-griglia">' + v.map(function(x, i){
        return '<div class="ffdv' + (x.l ? ' larga' : '') + '" style="--r:' + [-1.2, 1, .7, -.8][i] + 'deg"><p class="ffdv-t">' + ffdDidascalia(x, i) + '</p><div class="ffdv-d">' + x.d + '</div></div>';
      }).join('') + '</div>'
    + '<button type="button" class="ffdf-go" onclick="ffdFoglioFine()">Continua</button>'
    + '</div>';
}
function ffdFoglioFine(){
  if (FFD.modo) ffdSceltaSalva(FFD.modo);
  ffdFoglioChiudi();
}
function ffdFoglioChiudi(){
  const w = document.getElementById('ffdFoglio'); if (!w) return;
  w.classList.remove('in'); w.classList.add('via');
  setTimeout(function(){ w.remove(); }, 240);
  if (FFD.da === 'impostazioni'){ try{ if (typeof ffImpPaint === 'function') ffImpPaint(); }catch(_){ } }
  FFD.da = '';
}

/* ---------------------------------------------------------------- quando compare */
/* Dopo il primo saluto del Genio sulla pagina del Full Focus: il Genio dice cos'e' la pagina, "Ho capito", e subito dopo
   si sceglie dove scrivere le distrazioni. Le stesse condizioni di drsPagina: utente entrato, nessun tour in corso. */
document.addEventListener('fl:screen', function(e){
  if (!e || e.detail !== 's-fullfocus' || ffdScelta()) return;
  let prima = false;
  try{
    if (localStorage.getItem('fl_onboarded') !== '1') return;
    if (typeof GT !== 'undefined' && GT.on) return;
    if (typeof GN !== 'undefined' && GN.on) return;
    const viste = JSON.parse(localStorage.getItem('fl_pagine_viste') || '{}') || {};
    prima = !viste['s-fullfocus'];
  }catch(_){ return; }
  if (!prima) return;
  const t0 = Date.now();
  clearInterval(FFD.attesa);
  FFD.attesa = setInterval(function(){
    const scr = document.getElementById('s-fullfocus');
    const qui = scr && scr.classList.contains('active');
    if (!qui || Date.now() - t0 > 120000 || ffdScelta()){ clearInterval(FFD.attesa); return; }
    /* aspetta che il Genio abbia finito di parlare (il fumetto #drsPg compare dopo mezzo secondo) */
    if (Date.now() - t0 < 1100 || document.getElementById('drsPg')) return;
    if (typeof FF !== 'undefined' && FF.run) return;
    if (document.querySelector('#ffSheetWrap.open')) return;
    clearInterval(FFD.attesa);
    ffdFoglioApri('tour');
  }, 300);
});

/* La riga nelle Impostazioni del Full Focus (ff-cicli.js): si aggiunge in fondo alla lista, prima dello spazio. */
(function(){
  const monta = function(){
    const o = window.ffImpPaint; if (typeof o !== 'function' || o.__ffd) return;
    const n = function(){
      const r = o.apply(this, arguments);
      try{
        const box = document.getElementById('ffImpBody'); if (!box || box.querySelector('.ffd-riga')) return r;
        const s = ffdScelta();
        const riga = document.createElement('div');
        riga.className = 'setrow ffd-riga'; riga.setAttribute('onclick', "ffdFoglioApri('impostazioni')");
        riga.innerHTML = '<span>📝</span><b>Il foglio delle distrazioni</b><small>' + ffdEsc(s === 'carta' ? 'Su carta' : s === 'telefono' ? 'Nel telefono' : 'Da scegliere') + '</small><span class="chev"></span>';
        const sp = box.querySelector('.spacer'); if (sp) box.insertBefore(riga, sp); else box.appendChild(riga);
      }catch(_){ }
      return r;
    };
    n.__ffd = true; window.ffImpPaint = n;
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else setTimeout(monta, 0);
})();

(function ffdStile(){
  const MANO = '"DM Caveat","Segoe Print","Comic Sans MS",cursive';
  const css = [
    /* l'appunto della pausa: sul velo blu, che e' blu in tutti e due i temi */
    '.ffp.ffp-con-appunto{overflow-y:auto;align-items:flex-start;padding:calc(40px + env(safe-area-inset-top)) 0 calc(30px + env(safe-area-inset-bottom));box-sizing:border-box}',
    '.ffp.ffp-con-appunto .ffp-c{width:100%;max-width:400px;box-sizing:border-box;margin:auto}',
    '.ffda{margin:32px 0 0;padding:20px 18px 18px;border-radius:24px;background:rgba(188,224,255,.14);box-shadow:inset 0 0 0 1px rgba(188,224,255,.28);text-align:left}',
    '.ffda-t{display:block;text-align:center;font:800 18px/1.25 var(--font-display);color:#fff}',
    '.ffda-s{margin:8px 0 16px;text-align:center;font:500 14px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.ffda-in{display:block;width:100%;box-sizing:border-box;min-height:84px;resize:none;border:0;border-radius:16px;padding:13px 14px;background:#F0FBFF;color:#001E44;font:500 16px/1.45 var(--font-body);outline:0}',
    '.ffda-in::placeholder{color:#5A7394}',
    '.ffda-in:focus{box-shadow:0 0 0 3px #8CC6FF}',
    '.ffda-ok{display:block;width:100%;min-height:52px;margin-top:12px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 16px var(--font-body);cursor:pointer}',
    '.ffda-ok:active{transform:scale(.98)}',
    /* la pagina: carta chiara di proposito in tutti e due i temi, inchiostro scritto a mano (mai le variabili del tema) */
    '#ffdFoglio{position:fixed;inset:0;z-index:9990;overflow-y:auto;background:#F0FBFF;color:#001E44;opacity:0;transform:translateY(16px);transition:opacity .24s ease,transform .24s ease}',
    '#ffdFoglio.in{opacity:1;transform:none}#ffdFoglio.via{opacity:0;transform:translateY(16px)}',
    '.ffdf-c{position:relative;min-height:100%;box-sizing:border-box;max-width:460px;margin:0 auto;padding:calc(22px + env(safe-area-inset-top)) 16px calc(26px + env(safe-area-inset-bottom));display:flex;flex-direction:column}',
    '.ffdf-c.centro{justify-content:center;padding-bottom:calc(90px + env(safe-area-inset-bottom))}',
    '.ffdf-x{position:absolute;top:calc(14px + env(safe-area-inset-top));right:14px;width:40px;height:40px;border:0;border-radius:50%;background:#C8EFFD;color:#001E44;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2}',
    '.ffdf-h{margin:30px 40px 0;text-align:center;font:800 27px/1.15 var(--font-display);color:#001E44}',
    /* body.dark h2 di app.css lo farebbe chiaro: qui la carta resta chiara, e l'inchiostro resta blu notte */
    'body.dark #ffdFoglio .ffdf-h,body.dark #ffdFoglio .ffdf-op b,body.dark #ffdFoglio .ffdv-t,body.dark #ffdFoglio .ffdf-scelta{color:#001E44}body.dark #ffdFoglio .ffdf-p,body.dark #ffdFoglio .ffdf-op small{color:#33507A}',
    '.ffdf-p{margin:16px 6px 0;text-align:center;font:500 16px/1.5 var(--font-body);color:#33507A}',
    '.ffdf-due{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:28px}',
    '.ffdf-op{display:flex;flex-direction:column;align-items:center;gap:8px;min-height:190px;padding:22px 12px 18px;border:2.5px solid #3F9FF4;border-radius:255px 18px 225px 18px/18px 225px 18px 255px;background:#fff;color:#001E44;text-align:center;cursor:pointer;font:inherit}',
    '.ffdf-op:nth-child(1){transform:rotate(-1deg)}.ffdf-op:nth-child(2){transform:rotate(1deg)}',
    '.ffdf-op.on{background:#C8EFFD;border-color:#0075E3}',
    '.ffdf-op-e{display:flex;align-items:flex-end;justify-content:center;height:78px;margin-bottom:6px}',
    '.ffdf-op b{font:800 16px/1.25 var(--font-body);color:#001E44}',
    '.ffdf-op small{font:500 13px/1.4 var(--font-body);color:#33507A}',
    '.ffdf-scelta{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:10px;font:700 14px var(--font-body);color:#001E44}',
    '.ffdf-scelta button{border:0;background:none;padding:6px 2px;color:#0075E3;font:800 14px var(--font-body);text-decoration:underline;cursor:pointer}',
    '.ffdf-griglia{display:grid;grid-template-columns:1fr 1fr;gap:14px 12px;margin-top:24px}',
    '.ffdv{position:relative;display:flex;flex-direction:column;min-width:0;height:184px;box-sizing:border-box;padding:10px 12px 8px;border:2.5px solid #3F9FF4;border-radius:14px 22px 12px 26px/24px 12px 22px 14px;background:#fff;overflow:hidden;transform:rotate(var(--r,0deg));box-shadow:3px 4px 0 rgba(63,159,244,.18)}',
    '.ffdv.larga{grid-column:1 / -1;height:148px}',
    '.ffdv-t{flex:none;position:relative;z-index:2;margin:0;max-width:100%;font:700 19px/1.08 ' + MANO + ';color:#001E44;text-align:left}',
    '.ffdv-d{position:relative;flex:1;min-height:0;margin-top:6px;z-index:1}',
    '.ffdv-sf{position:absolute;left:4%;right:4%;bottom:0;height:72%;border-radius:50% 46% 40% 52%/44% 52% 46% 50%}',
    '.ffdv-sf.a{background:#F0FBFF}.ffdv-sf.b{background:#C8EFFD}',
    '.ffdv.larga .ffdv-sf{left:12%;right:6%;height:80%}',
    '.ffdv-e{position:absolute;font-size:28px;line-height:1}.ffdv-e.big{font-size:40px}',
    '.ffdv-foglio{position:absolute;width:50px;height:auto}',
    '.ffdv.larga .ffdv-foglio{width:46px}',
    '.ffdv-tel{position:absolute;width:50px;height:84px;box-sizing:border-box;border:2.4px solid #001E44;border-radius:13px;background:#001E44;padding:12px 5px 6px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;overflow:hidden}',
    '.ffdv-tel > i{position:absolute;top:4px;left:50%;width:14px;height:3px;margin-left:-7px;border-radius:2px;background:#3F9FF4}',
    '.ffdv-st{display:block;width:20px;height:20px}.ffdv-luna{position:absolute;left:8%;top:8%;width:38px;height:38px}',
    '.ffdv-ora{font:800 11px var(--font-body);color:#fff;letter-spacing:.02em}',
    '.ffdv-pausa{display:flex;gap:4px}.ffdv-pausa i{width:6px;height:18px;border-radius:2px;background:#8CC6FF}',
    '.ffdv-campo{display:flex;flex-direction:column;gap:4px;width:100%;padding:6px 5px;box-sizing:border-box;border-radius:6px;background:#F0FBFF}.ffdv-campo i{height:3px;border-radius:2px;background:#3F9FF4}.ffdv-campo i:last-child{width:60%}',
    '.ffdv-salva{margin-top:2px;padding:2px 7px;border-radius:99px;background:#fff;color:#001E44;font:800 8px var(--font-body)}',
    '.ffdv-banco{position:absolute;left:14%;right:8%;bottom:8px;height:6px;border-radius:3px;background:#001E44}',
    '.ffdv-lista{position:absolute;left:28%;top:12%;width:32%;padding:9px 10px;box-sizing:border-box;border:2.4px solid #001E44;border-radius:8px;background:#fff;display:flex;flex-direction:column;gap:7px;transform:rotate(-3deg)}',
    '.ffdv-lista i{position:relative;height:4px;border-radius:2px;background:#3F9FF4}',
    '.ffdv-lista i.via{background:#8CC6FF}.ffdv-lista i.via::after{content:"";position:absolute;left:-4px;right:-4px;top:1px;height:2.4px;background:#E63946;border-radius:2px}',
    '.ffdf-go{display:block;width:100%;min-height:58px;margin-top:28px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 17px var(--font-body);cursor:pointer;box-shadow:0 10px 24px rgba(0,117,227,.3)}',
    '.ffdf-go:active{transform:scale(.98)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
