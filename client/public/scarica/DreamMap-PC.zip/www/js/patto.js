/* ===========================================================================================
   IL PATTO CON IL TUO DREAMBROTHER (0.9.285, Andrea)

   "Il contratto di abitudine con il proprio Dreambrother, con un deterrente economico: dare soldi a
   una persona firmando un contratto con lei, cosi' l'automazione lavora per loro e il garante non
   deve mai sorvegliare attivamente ne' ricordarsi di chiedere: i soldi gli arrivano da soli."
   Per ora nessuna penitenza: solo il contratto e i soldi.

   - Si scrive il patto una domanda alla volta (Atomic Habits: cosa, quando, dopo cosa, dove, la
     versione da due minuti), scegliendo come la verifica l'app: cose che il telefono vede da solo.
   - Il garante riceve un codice e firma dalla sua app (il server: focuslockPatti.ts).
   - Ogni giorno questo telefono controlla da solo e manda il verdetto. Un giorno mancato: i soldi
     partono verso il garante (quando i pagamenti sono collegati, Stripe). Un giorno senza verdetto
     lo segna il server, e dopo due giorni vale come mancato.
   - Il garante, aprendo l'app, vede cosa e' successo: non deve chiedere niente.
   =========================================================================================== */
const PAT = { lista: null, w: null, passo: 0, firma: null, pagamenti: false };
const PAT_INVIATI_K = 'fl_patti_inviati';    // { "<id>|<giorno>": esito } i verdetti gia' mandati
const PAT_VISTI_K = 'fl_patti_visti';        // { "<id>|<giorno>": 1 } quello che il garante ha gia' visto
const PAT_VERIFICHE = [
  { k: 'sessione', ico: '🚀', n: 'Una sessione di Full Focus', s: 'Di almeno {m} minuti, entro l’ora del patto', par: 'minuti' },
  { k: 'schermo', ico: '📱', n: 'Poco telefono', s: 'Al massimo {h} ore di schermo in tutta la giornata', par: 'ore' },
  { k: 'passo', ico: '🛤️', n: 'Un passo della roadmap', s: 'Almeno un passo chiuso nella giornata' },
  { k: 'riga', ico: '✅', n: 'Una riga del foglio', s: 'Una riga spuntata entro l’ora del patto, che contiene la parola che scegli', par: 'parola' },
  { k: 'coppia', ico: '👥', n: 'Una sessione in coppia', s: 'Portata a termine, anche solo in parte' },
  /* 0.9.302: il patto dei soldi del contratto di abitudine (contratto.js). Non si sceglie qui: lo crea il contratto. */
  { k: 'contratto', ico: '📜', n: 'Il contratto di abitudine', s: 'Nessuno sgarro nella giornata', nascosta: true }
];
const PAT_GIORNI = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
const PAT_I = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
function patEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function patJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function patScrivi(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function patPuo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.accountApi === 'function'; }
async function patApi(method, path, body){
  if (!patPuo()) throw new Error('Il patto funziona nell’app sul telefono');
  return NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
}
function patEuro(cent){ const e = (+cent || 0) / 100; return (e % 1 ? e.toFixed(2).replace('.', ',') : String(e)) + ' €'; }
function patGiornoK(ms){ const d = new Date(ms); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function patData(k){ const d = new Date(k + 'T12:00:00'); return d.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' }); }

registerScreen('s-patto', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PAT_I + '</button><b class="blk-title">Il patto con il tuo Dreambrother</b></div><div id="patBody"></div><div class="spacer"></div>');
registerScreen('s-patto-nuovo', '<div class="topbar"><button class="iconbtn" onclick="patIndietroW()" aria-label="Indietro">' + PAT_I + '</button><b class="blk-title" id="patWTit">Un patto nuovo</b></div><div class="md-prog" id="patProg"></div><div id="patW"></div><div class="spacer"></div>', { back: function(){ patIndietroW(); return null; } });
registerScreen('s-patto-firma', '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + PAT_I + '</button><b class="blk-title">Firma come garante</b></div><div id="patF"></div><div class="spacer"></div>');

/* ---------------------------------------------------------------------------------------
   LA PAGINA: i tuoi patti e quelli in cui fai da garante
   --------------------------------------------------------------------------------------- */
async function patApri(){ goId('s-patto'); patPaint(); await patCarica(); patPaint(); }
async function patCarica(){
  try{ const r = await patApi('GET', '/api/focuslock/patti'); PAT.lista = (r && r.patti) || []; PAT.pagamenti = !!(r && r.pagamenti); }
  catch(e){ PAT.lista = { errore: String((e && e.message) || e) }; }
}
function patCardHtml(p){
  const ab = p.abitudine || {};
  const ver = PAT_VERIFICHE.filter(function(v){ return v.k === (ab.verifica && ab.verifica.tipo); })[0];
  const io = p.ruolo === 'autore';
  /* 0.9.302: un patto verso un ente (dal contratto di abitudine): niente garante, i soldi sono da donare */
  if (p.destinazione && p.destinazione.tipo === 'beneficenza') return patCardEnteHtml(p, ver, ultimi7(p));
  const stato = p.stato === 'attesa' ? (io ? 'Aspetta la firma di ' + (p.garante || 'chi hai scelto') : 'Da firmare') : p.stato === 'attivo' ? 'Attivo fino al ' + patData(p.aGiorno) : p.stato === 'sciolto' ? 'Sciolto dal garante' : 'Finito';
  const ultimi = (p.giorni || []).slice(0, 7).reverse().map(function(g){ return '<i class="pat-pal ' + g.esito + '" title="' + patData(g.giorno) + '"></i>'; }).join('');
  const soldi = io
    ? (p.totali.inviati ? 'Hai dato ' + patEuro(p.totali.inviati) + ' a ' + patEsc(p.garante || 'il tuo garante') : (p.totali.dovuti ? patEuro(p.totali.dovuti) + ' da dare a ' + patEsc(p.garante || 'il tuo garante') : 'Ancora nessun giorno mancato'))
    : (p.totali.inviati ? 'Hai ricevuto ' + patEuro(p.totali.inviati) + ' da ' + patEsc(p.autore) : (p.totali.dovuti ? patEsc(p.autore) + ' ti deve ' + patEuro(p.totali.dovuti) : patEsc(p.autore) + ' non ha ancora mancato un giorno'));
  let az = '';
  if (io && p.stato === 'attesa') az = '<button type="button" class="am-cta" onclick="patManda(' + p.id + ')">Manda il patto a ' + patEsc(p.garante || 'il tuo garante') + '</button>';
  if (PAT.pagamenti && p.stato === 'attivo' && io && !p.pagamenti.carta) az += '<button type="button" class="am-cta" onclick="patCarta(' + p.id + ')">Collega la carta per il patto</button>';
  if (PAT.pagamenti && p.stato === 'attivo' && !io && !p.pagamenti.conto) az += '<button type="button" class="am-cta" onclick="patConto(' + p.id + ')">Collega il conto per ricevere i soldi</button>';
  if (!io && p.stato === 'attivo') az += '<button type="button" class="am-link" onclick="patSciogli(' + p.id + ')">Sciogli il patto</button>';
  if (io && p.stato === 'attesa') az += '<button type="button" class="am-link" onclick="patSciogli(' + p.id + ')">Annulla il patto</button>';
  /* 0.9.317, Andrea: "fa cagare, e' tutto ammassato. Deve essere un contratto vintage sulla pagina del diario di viaggio, tutto al centro" */
  return '<div class="pat-card pat-carta dv-carta' + (io ? '' : ' garante') + '">'
    + '<small class="pat-eti">' + (io ? 'Il tuo patto' : 'Fai da garante a ' + patEsc(p.autore)) + '</small>'
    + '<p class="pat-stato">' + patEsc(stato) + '</p>'
    + '<h3 class="pat-cosa">' + patEsc(ab.cosa || '') + '</h3>'
    + '<svg class="pat-onda" viewBox="0 0 160 8" preserveAspectRatio="none" fill="none" stroke="#b23a3a" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 5C22 1 42 7 62 4s40-3 58 0 26 2 38 0"/></svg>'
    + (ver ? '<div class="pat-clausola"><small>Ogni giorno</small><p>' + ver.ico + ' ' + patEsc(patMaiuscola(patVerTxt(ab))) + '</p></div>' : '')
    + '<div class="pat-clausola"><small>Se manco un giorno</small><p><b>' + patEuro(p.posta) + '</b> per ogni giorno, al massimo ' + patEuro(p.tetto) + ' al mese</p></div>'
    + (ultimi ? '<div class="pat-clausola"><small>Gli ultimi giorni</small><div class="pat-pals">' + ultimi + '</div></div>' : '')
    + '<p class="pat-soldi">' + soldi + '</p>'
    + (p.stato === 'attivo' && !PAT.pagamenti ? '<p class="pat-nota">I soldi partono da soli quando i pagamenti sono collegati. Intanto ogni giorno mancato resta scritto qui.</p>' : '')
    + '<div class="pat-firme"><div><i>' + patEsc(io ? 'Tu' : (p.autore || '')) + '</i><small>firma di chi promette</small></div><div><i>' + (p.stato === 'attesa' ? '&nbsp;' : patEsc(io ? (p.garante || '') : 'Tu')) + '</i><small>firma del garante</small></div></div>'
    + (az ? '<div class="pat-az">' + az + '</div>' : '') + '</div>';
}
function ultimi7(p){ return (p.giorni || []).slice(0, 7).reverse().map(function(g){ return '<i class="pat-pal ' + g.esito + '" title="' + patData(g.giorno) + '"></i>'; }).join(''); }
function patCardEnteHtml(p, ver, ultimi){
  const ente = (p.destinazione && p.destinazione.ente) || 'l’ente che hai scelto';
  const stato = p.stato === 'attivo' ? 'Attivo fino al ' + patData(p.aGiorno) : p.stato === 'sciolto' ? 'Sciolto' : 'Finito';
  return '<div class="pat-card">'
    + '<small class="pat-eti">Il tuo patto in beneficenza · ' + patEsc(stato) + '</small>'
    + '<b class="pat-cosa">' + patEsc((p.abitudine && p.abitudine.cosa) || '') + '</b>'
    + (ver ? '<p class="pat-ver">' + ver.ico + ' ' + patEsc(patMaiuscola(patVerTxt(p.abitudine || {}))) + '</p>' : '')
    + '<p class="pat-posta"><b>' + patEuro(p.posta) + '</b> per ogni giorno mancato, al massimo ' + patEuro(p.tetto) + ' al mese</p>'
    + (ultimi ? '<div class="pat-pals">' + ultimi + '<small>gli ultimi giorni</small></div>' : '')
    + '<p class="pat-soldi">' + (p.totali.dovuti ? patEuro(p.totali.dovuti) + ' da donare a ' + patEsc(ente) : 'Ancora nessun giorno mancato') + '</p>'
    + '<p class="pat-nota">Le donazioni non partono da sole: ogni giorno mancato resta scritto qui con la sua cifra.</p>'
    + '</div>';
}
/** La verifica detta come una frase sola: "una sessione di Full Focus di almeno 25 minuti, entro le 21:00". */
function patVerTxt(ab){
  const v = ab.verifica || {}, entro = ab.entro || '23:59';
  if (v.tipo === 'sessione') return 'una sessione di Full Focus di almeno ' + (v.minuti || 25) + ' minuti, entro le ' + entro;
  if (v.tipo === 'schermo') return 'al massimo ' + String(v.ore || 3).replace('.', ',') + ' ore di schermo in tutta la giornata';
  if (v.tipo === 'passo') return 'almeno un passo della roadmap chiuso nella giornata';
  if (v.tipo === 'riga') return 'una riga del foglio con "' + ((v.parole || [])[0] || '') + '" spuntata entro le ' + entro;
  if (v.tipo === 'coppia') return 'una sessione in coppia portata a termine nella giornata';
  if (v.tipo === 'contratto') return 'nessuno sgarro al contratto di abitudine nella giornata';
  return '';
}
function patMaiuscola(t){ t = String(t || ''); return t.charAt(0).toUpperCase() + t.slice(1); }
function patMinuscola(t){ t = String(t || ''); return t.charAt(0).toLowerCase() + t.slice(1); }
function patPaint(){
  const host = document.getElementById('patBody'); if (!host) return;
  if (!patPuo()){ host.innerHTML = '<p class="pat-intro">Il patto funziona nell’app sul telefono, con il tuo account Google.</p>'; return; }
  const intro = '<p class="pat-intro">Scegli un’abitudine e un amico che fa da garante. <b>Se manchi un giorno, i soldi gli arrivano da soli:</b> lui non deve controllare niente.</p>';
  if (!PAT.lista){ host.innerHTML = intro + '<p class="pat-carica">Carico i tuoi patti…</p>'; return; }
  if (PAT.lista.errore){ host.innerHTML = intro + '<p class="pat-carica">Non riesco a leggere i patti: ' + patEsc(PAT.lista.errore) + '</p><button type="button" class="am-cta" onclick="patApri()">Riprova</button>'; return; }
  const miei = PAT.lista.filter(function(p){ return p.ruolo === 'autore'; }), suoi = PAT.lista.filter(function(p){ return p.ruolo === 'garante'; });
  host.innerHTML = intro
    + miei.map(patCardHtml).join('')
    + '<button type="button" class="am-cta pat-nuovo" onclick="patNuovo()">' + (miei.length ? 'Scrivi un altro patto' : 'Scrivi il tuo patto') + '</button>'
    + (suoi.length ? '<p class="pat-sez">Fai da garante</p>' + suoi.map(patCardHtml).join('') : '')
    + '<button type="button" class="pat-firma-riga" onclick="patFirmaApri()"><span>✍️</span><span><b>Un amico ti ha chiesto di fargli da garante?</b><small>Scrivi il suo codice e firma il patto</small></span><span class="chev"></span></button>';
}
async function patManda(id){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0]; if (!p) return;
  const t = 'Ti chiedo di farmi da garante su DreamMap. Il mio patto: ' + (p.abitudine && p.abitudine.cosa) + '. Per ogni giorno che manco ti arrivano ' + patEuro(p.posta) + ' (al massimo ' + patEuro(p.tetto) + ' al mese), senza che tu debba controllare niente.\nApri DreamMap, vai su "Il patto con il tuo Dreambrother" e firma con il codice: ' + p.codice;
  try{ if (NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: t, title: 'Il mio patto' }); return; } }catch(_){ }
  try{ await navigator.clipboard.writeText(t); toast('Messaggio copiato: incollalo al tuo garante'); }catch(_){ toast('Il codice del patto è ' + p.codice); }
}
async function patSciogli(id){
  const p = (PAT.lista || []).filter(function(x){ return x.id === id; })[0]; if (!p) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm(p.ruolo === 'autore' ? 'Annullare il patto?' : 'Sciogliere il patto?', p.ruolo === 'autore' ? 'Non è ancora firmato: sparisce e basta.' : 'Da domani i giorni mancati non costano più niente.', p.ruolo === 'autore' ? 'Annulla il patto' : 'Sciogli', true); }catch(_){ }
  if (!ok) return;
  try{ await patApi('POST', '/api/focuslock/patti/sciogli', { id: id }); }catch(_){ toast('Non sono riuscito a farlo'); return; }
  await patCarica(); patPaint();
}
async function patCarta(id){
  try{ const r = await patApi('POST', '/api/focuslock/patti/carta', { id: id }); if (r && r.url) patApriFuori(r.url, id); }catch(e){ toast(String((e && e.message) || 'Pagamenti non disponibili')); }
}
async function patConto(id){
  try{ const r = await patApi('POST', '/api/focuslock/patti/conto', { id: id }); if (r && r.url) patApriFuori(r.url, id); }catch(e){ toast(String((e && e.message) || 'Pagamenti non disponibili')); }
}
function patApriFuori(url, id){
  try{ if (NATIVE && NATIVE.openUrl){ NATIVE.openUrl({ url: url }); } else window.open(url, '_blank'); }catch(_){ window.open(url, '_blank'); }
  PAT.attesaPagamento = id;
}

/* ---------------------------------------------------------------------------------------
   IL PATTO NUOVO: una domanda per schermata
   --------------------------------------------------------------------------------------- */
const PAT_PASSI = ['cosa', 'verifica', 'quando', 'facile', 'garante', 'posta', 'firma'];
function patNuovo(){
  PAT.w = { cosa: '', verifica: { tipo: 'sessione', minuti: 25, ore: 3, parole: [] }, giorni: [true, true, true, true, true, false, false], entro: '21:00', dopoDi: '', dove: '', dueMinuti: '', garante: '', posta: 5, tetto: 50, durata: 30 };
  PAT.passo = 0;
  goId('s-patto-nuovo'); patWPaint();
}
function patIndietroW(){ if (PAT.passo > 0){ PAT.passo--; patWPaint(); return; } if (typeof navTornaDietro === 'function' && navTornaDietro('s-patto-nuovo')) return; goId('s-patto'); }
function patAvanti(){ patLeggiCampi(); const err = patControlla(); if (err){ toast(err); return; } PAT.passo = Math.min(PAT_PASSI.length - 1, PAT.passo + 1); patWPaint(); }
function patLeggiCampi(){
  const w = PAT.w; const v = function(id){ const e = document.getElementById(id); return e ? e.value.trim() : null; };
  if (v('patCosa') !== null) w.cosa = v('patCosa');
  if (v('patParola') !== null) w.verifica.parole = v('patParola') ? [v('patParola').toLowerCase()] : [];
  if (v('patDopo') !== null) w.dopoDi = v('patDopo');
  if (v('patDove') !== null) w.dove = v('patDove');
  if (v('patDue') !== null) w.dueMinuti = v('patDue');
  if (v('patGarante') !== null) w.garante = v('patGarante');
}
function patControlla(){
  const w = PAT.w, p = PAT_PASSI[PAT.passo];
  if (p === 'cosa' && !w.cosa) return 'Scrivi l’abitudine che vuoi costruire';
  if (p === 'verifica' && w.verifica.tipo === 'riga' && !(w.verifica.parole || []).length) return 'Scrivi la parola che deve avere la riga';
  if (p === 'quando' && !w.giorni.some(Boolean)) return 'Scegli almeno un giorno';
  if (p === 'garante' && !w.garante) return 'Scrivi il nome del tuo garante';
  return '';
}
function patWPaint(){
  const host = document.getElementById('patW'); if (!host || !PAT.w) return;
  const w = PAT.w, p = PAT_PASSI[PAT.passo];
  const prog = document.getElementById('patProg'); if (prog) prog.innerHTML = '<i style="width:' + Math.round((PAT.passo + 1) / PAT_PASSI.length * 100) + '%"></i>';
  const avanti = '<button type="button" class="am-cta" onclick="patAvanti()">Avanti</button>';
  let h = '';
  if (p === 'cosa'){
    h = '<h2 class="pat-q">Quale abitudine vuoi costruire?</h2><p class="pat-qs">Una cosa sola, detta come la diresti a un amico.</p>'
      + '<input id="patCosa" class="fin" maxlength="160" placeholder="Per esempio: lavorare al negozio online ogni mattina" value="' + patEsc(w.cosa) + '">'
      + '<div class="pat-esempi">' + ['Lavorare al mio progetto ogni mattina', 'Stare lontano dal telefono la sera', 'Chiudere un passo della roadmap al giorno', 'Fare una sessione in coppia al giorno'].map(function(e){ return '<button type="button" onclick="document.getElementById(\'patCosa\').value=this.textContent">' + patEsc(e) + '</button>'; }).join('') + '</div>' + avanti;
  } else if (p === 'verifica'){
    h = '<h2 class="pat-q">Come la controlla l’app, ogni giorno?</h2><p class="pat-qs">Scegli una cosa che il telefono vede da solo: così il tuo garante non deve controllare niente.</p>'
      + '<div class="pat-ver-l">' + PAT_VERIFICHE.filter(function(v){ return !v.nascosta; }).map(function(v){ return '<button type="button" class="' + (v.k === w.verifica.tipo ? 'on' : '') + '" onclick="patLeggiCampi();PAT.w.verifica.tipo=\'' + v.k + '\';patWPaint()"><span>' + v.ico + '</span><span><b>' + patEsc(v.n) + '</b><small>' + patEsc(v.s.replace('{m}', String(w.verifica.minuti)).replace('{h}', String(w.verifica.ore))) + '</small></span></button>'; }).join('') + '</div>';
    if (w.verifica.tipo === 'sessione') h += '<div class="md-row"><span>Minuti della sessione</span><div class="md-step"><button type="button" onclick="PAT.w.verifica.minuti=Math.max(10,PAT.w.verifica.minuti-5);patWPaint()" aria-label="Meno">−</button><b>' + w.verifica.minuti + '</b><button type="button" onclick="PAT.w.verifica.minuti=Math.min(180,PAT.w.verifica.minuti+5);patWPaint()" aria-label="Più">+</button></div></div>';
    if (w.verifica.tipo === 'schermo') h += '<div class="md-row"><span>Ore di schermo al massimo</span><div class="md-step"><button type="button" onclick="PAT.w.verifica.ore=Math.max(0.5,PAT.w.verifica.ore-0.5);patWPaint()" aria-label="Meno">−</button><b>' + String(w.verifica.ore).replace('.', ',') + '</b><button type="button" onclick="PAT.w.verifica.ore=Math.min(12,PAT.w.verifica.ore+0.5);patWPaint()" aria-label="Più">+</button></div></div>';
    if (w.verifica.tipo === 'riga') h += '<input id="patParola" class="fin" maxlength="40" placeholder="La parola della riga, per esempio: video" value="' + patEsc((w.verifica.parole || [])[0] || '') + '">';
    h += avanti;
  } else if (p === 'quando'){
    h = '<h2 class="pat-q">In quali giorni, ed entro che ora?</h2><p class="pat-qs">' + (w.verifica.tipo === 'schermo' ? 'Il tempo sul telefono si conta a fine giornata.' : 'Dopo quell’ora, se non l’hai fatto, il giorno è mancato.') + '</p>'
      + '<div class="pat-gg">' + PAT_GIORNI.map(function(g, i){ return '<button type="button" class="' + (w.giorni[i] ? 'on' : '') + '" onclick="PAT.w.giorni[' + i + ']=!PAT.w.giorni[' + i + '];patWPaint()">' + g + '</button>'; }).join('') + '</div>'
      + (w.verifica.tipo === 'schermo' || w.verifica.tipo === 'passo' || w.verifica.tipo === 'coppia' ? '' : '<div class="md-row"><span>Entro le</span><div class="md-step"><button type="button" onclick="PAT.w.entro=patOraPiu(PAT.w.entro,-30);patWPaint()" aria-label="Prima">−</button><b>' + w.entro + '</b><button type="button" onclick="PAT.w.entro=patOraPiu(PAT.w.entro,30);patWPaint()" aria-label="Dopo">+</button></div></div>')
      + avanti;
  } else if (p === 'facile'){
    h = '<h2 class="pat-q">Rendila facile da cominciare</h2><p class="pat-qs">Le abitudini si attaccano a quelle che hai già. Puoi lasciare vuoto.</p>'
      + '<label class="pat-l" for="patDopo">Dopo cosa la fai?</label><input id="patDopo" class="fin" maxlength="120" placeholder="Per esempio: dopo il caffè del mattino" value="' + patEsc(w.dopoDi) + '">'
      + '<label class="pat-l" for="patDove">Dove?</label><input id="patDove" class="fin" maxlength="80" placeholder="Per esempio: alla scrivania in camera" value="' + patEsc(w.dove) + '">'
      + '<label class="pat-l" for="patDue">La versione da due minuti</label><input id="patDue" class="fin" maxlength="120" placeholder="Per esempio: aprire il computer e scrivere una riga" value="' + patEsc(w.dueMinuti) + '">' + avanti;
  } else if (p === 'garante'){
    h = '<h2 class="pat-q">Chi è il tuo Dreambrother?</h2><p class="pat-qs">L’amico che fa da garante: firma il patto dalla sua app e riceve i soldi dei giorni che manchi.</p>'
      + '<input id="patGarante" class="fin" maxlength="60" placeholder="Il suo nome" value="' + patEsc(w.garante) + '">' + avanti;
  } else if (p === 'posta'){
    h = '<h2 class="pat-q">Quanto ti costa un giorno mancato?</h2><p class="pat-qs">Abbastanza da non volerlo perdere, non tanto da metterti in difficoltà.</p>'
      + '<div class="pat-poste">' + [2, 5, 10, 20, 50].map(function(e){ return '<button type="button" class="' + (w.posta === e ? 'on' : '') + '" onclick="PAT.w.posta=' + e + ';PAT.w.tetto=Math.max(PAT.w.tetto,' + e + ');patWPaint()">' + e + ' €</button>'; }).join('') + '</div>'
      + '<div class="md-row"><span>Al massimo al mese</span><div class="md-step"><button type="button" onclick="PAT.w.tetto=Math.max(PAT.w.posta,PAT.w.tetto-10);patWPaint()" aria-label="Meno">−</button><b>' + w.tetto + ' €</b><button type="button" onclick="PAT.w.tetto=Math.min(500,PAT.w.tetto+10);patWPaint()" aria-label="Più">+</button></div></div>'
      + '<div class="md-row"><span>Quanto dura il patto</span><div class="md-step"><button type="button" onclick="PAT.w.durata=Math.max(7,PAT.w.durata-7);patWPaint()" aria-label="Meno">−</button><b>' + w.durata + ' giorni</b><button type="button" onclick="PAT.w.durata=Math.min(180,PAT.w.durata+7);patWPaint()" aria-label="Più">+</button></div></div>' + avanti;
  } else {
    const ab = { cosa: w.cosa, verifica: w.verifica, entro: w.entro };
    const gg = PAT_GIORNI.filter(function(_, i){ return w.giorni[i]; }).length === 7 ? 'tutti i giorni' : ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'].filter(function(_, i){ return w.giorni[i]; }).join(', ');
    h = '<h2 class="pat-q">Il tuo patto</h2>'
      + '<div class="pat-contratto"><p>Io mi impegno a <b>' + patEsc(patMinuscola(w.cosa)) + '</b>, ' + patEsc(gg) + (w.dopoDi ? ', ' + patEsc(w.dopoDi.charAt(0).toLowerCase() + w.dopoDi.slice(1)) : '') + (w.dove ? ', ' + patEsc(w.dove.charAt(0).toLowerCase() + w.dove.slice(1)) : '') + '.</p>'
      + '<p>L’app lo controlla da sola: ' + patEsc(patVerTxt(ab)) + '.</p>'
      + '<p>Per ogni giorno che manco, <b>' + patEsc(w.garante) + ' riceve ' + w.posta + ' €</b>, al massimo ' + w.tetto + ' € al mese, per ' + w.durata + ' giorni a partire da domani.</p>'
      + (w.dueMinuti ? '<p>Quando non ho voglia, comincio così: ' + patEsc(w.dueMinuti) + '.</p>' : '') + '</div>'
      + '<button type="button" class="am-cta" onclick="patFirmaMio()">Firmo il patto</button>';
  }
  host.innerHTML = '<div class="pat-w">' + h + '</div>';
  const tit = document.getElementById('patWTit'); if (tit) tit.textContent = 'Un patto nuovo · ' + (PAT.passo + 1) + ' di ' + PAT_PASSI.length;
}
function patOraPiu(hhmm, min){ const p = String(hhmm).split(':'); let t = (+p[0]) * 60 + (+p[1]) + min; t = Math.max(6 * 60, Math.min(23 * 60 + 30, t)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
async function patFirmaMio(){
  const w = PAT.w; if (!w) return;
  const entro = (w.verifica.tipo === 'schermo' || w.verifica.tipo === 'passo' || w.verifica.tipo === 'coppia') ? '23:59' : w.entro;
  let r;
  try{
    r = await patApi('POST', '/api/focuslock/patti', { abitudine: { cosa: w.cosa, verifica: w.verifica, giorni: w.giorni, entro: entro, dopoDi: w.dopoDi, dove: w.dove, dueMinuti: w.dueMinuti }, posta: w.posta, tetto: w.tetto, durataGiorni: w.durata, garanteNome: w.garante, nome: (typeof nvNome === 'function' && nvNome()) || '' });
  }catch(e){ toast('Non sono riuscito a salvare il patto: ' + String((e && e.message) || e)); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  PAT.w = null; PAT.passo = 0;
  goId('s-patto'); await patCarica(); patPaint();
  if (r && r.patto){ toast('Patto firmato da te: adesso mandalo a ' + (r.patto.garante || 'il tuo garante')); setTimeout(function(){ patManda(r.patto.id); }, 600); }
}

/* ---------------------------------------------------------------------------------------
   IL GARANTE FIRMA
   --------------------------------------------------------------------------------------- */
function patFirmaApri(){ PAT.firma = null; goId('s-patto-firma'); patFirmaPaint(); }
function patFirmaPaint(){
  const host = document.getElementById('patF'); if (!host) return;
  const f = PAT.firma;
  if (!f){
    host.innerHTML = '<p class="pat-intro">Scrivi il codice che ti ha mandato il tuo amico: <b>leggi il suo patto prima di firmare.</b></p>'
      + '<input id="patCod" class="fin pat-cod" maxlength="12" placeholder="Il codice" autocomplete="off" autocapitalize="characters">'
      + '<button type="button" class="am-cta" onclick="patLeggiCodice()">Leggi il patto</button>';
    return;
  }
  host.innerHTML = patCardHtml(f) + '<p class="pat-intro">Firmando fai da garante: <b>non devi controllare niente.</b> Se ' + patEsc(f.autore) + ' manca un giorno, i soldi ti arrivano da soli.</p>'
    + '<button type="button" class="am-cta" onclick="patFirmaGarante(\'' + patEsc(f.codice) + '\')">Firmo come garante</button>';
}
async function patLeggiCodice(){
  const c = ((document.getElementById('patCod') || {}).value || '').trim().toUpperCase();
  if (!c){ toast('Scrivi il codice del patto'); return; }
  try{ const r = await patApi('GET', '/api/focuslock/patti/codice/' + encodeURIComponent(c)); PAT.firma = r && r.patto; patFirmaPaint(); }
  catch(e){ toast(/tuo patto/.test(String(e && e.message)) ? 'Questo è il tuo patto: il garante deve essere un’altra persona' : 'Non trovo un patto con questo codice'); }
}
async function patFirmaGarante(codice){
  try{ await patApi('POST', '/api/focuslock/patti/firma', { codice: codice, nome: (typeof nvNome === 'function' && nvNome()) || '' }); }
  catch(_){ toast('Non sono riuscito a firmare: riprova'); return; }
  try{ flVibra([12, 40, 12]); }catch(_){ }
  toast('Hai firmato: da domani il patto è attivo');
  goId('s-patto'); await patCarica(); patPaint();
}

/* ---------------------------------------------------------------------------------------
   IL CONTROLLO DI OGNI GIORNO, da solo: il verdetto parte dal telefono di chi si impegna
   --------------------------------------------------------------------------------------- */
function patScadenzaMs(giorno, entro){ const p = String(entro || '23:59').split(':'); const d = new Date(giorno + 'T00:00:00'); d.setHours(+p[0] || 23, +p[1] || 0, 59, 0); return d.getTime(); }
function patPrevisti(p, fino){
  const ab = p.abitudine || {}; const out = [];
  const d = new Date(p.daGiorno + 'T12:00:00');
  for (let i = 0; i < 200; i++){ const k = patGiornoK(d.getTime()); if (k > fino || k > p.aGiorno) break; if (ab.giorni && ab.giorni[(d.getDay() + 6) % 7]) out.push(k); d.setDate(d.getDate() + 1); }
  return out;
}
/** Il verdetto di un giorno: true fatto, false mancato, null non si sa ancora. */
async function patVerdetto(ab, giorno){
  const v = ab.verifica || {};
  const inizio = new Date(giorno + 'T00:00:00').getTime(), fine = inizio + 86400000;
  const scad = patScadenzaMs(giorno, ab.entro);
  const passata = Date.now() > scad;
  if (v.tipo === 'sessione'){
    const h = patJ('fl_ff_hist', []) || [];
    const ok = h.some(function(x){ const t = +(x.start || x.at || 0); const min = Math.round((x.spentMs || (x.min || 0) * 60000) / 60000); return x && x.ok && !x.meditazione && t >= inizio && t <= scad && min >= (v.minuti || 25); });
    return ok ? true : (passata ? false : null);
  }
  if (v.tipo === 'passo'){
    const oz = patJ('fl_orizzonti', {}) || {};
    const ok = Object.keys(oz).some(function(k){ return ((oz[k] && oz[k].passi) || []).some(function(x){ return x && x.fatto && x.il === giorno; }); });
    return ok ? true : (Date.now() > fine ? false : null);
  }
  if (v.tipo === 'riga'){
    const l = patJ('fl_notes_done', []) || [];
    const par = (v.parole || [])[0] || '';
    const ok = l.some(function(x){ return x && x.day === giorno && (!par || String(x.text || '').toLowerCase().indexOf(par) >= 0) && (!x.at || +x.at <= scad); });
    return ok ? true : (passata ? false : null);
  }
  if (v.tipo === 'coppia'){
    const l = patJ('fl_coppia_storia', []) || [];
    const ok = l.some(function(x){ return x && x.esito !== 'no' && +x.slotAt >= inizio && +x.slotAt < fine; });
    return ok ? true : (Date.now() > fine ? false : null);
  }
  if (v.tipo === 'contratto') return (typeof ctrVerdetto === 'function') ? ctrVerdetto(giorno) : null;
  if (v.tipo === 'schermo'){
    if (Date.now() < fine) return null;
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return null;
    try{ const r = await NATIVE.getScreenTimeRange({ from: inizio, to: fine, bucket: 'day' }); if (!r || typeof r.ms !== 'number') return null; return r.ms <= (v.ore || 3) * 3600000; }catch(_){ return null; }
  }
  return null;
}
let PAT_CONTROLLO = false;
async function patControllaGiorni(){
  if (!patPuo() || PAT_CONTROLLO) return;
  PAT_CONTROLLO = true;
  try{
    let lista = PAT.lista;
    if (!Array.isArray(lista)){ await patCarica(); lista = PAT.lista; }
    if (!Array.isArray(lista)) return;
    const inviati = patJ(PAT_INVIATI_K, {}) || {};
    const oggi = patGiornoK(Date.now());
    let cambiato = false;
    for (const p of lista){
      if (p.ruolo !== 'autore' || p.stato !== 'attivo') continue;
      const gia = {}; (p.giorni || []).forEach(function(g){ if (g.esito !== 'nessundato') gia[g.giorno] = g.esito; });
      for (const g of patPrevisti(p, oggi)){
        const k = p.id + '|' + g;
        if (gia[g] || inviati[k]) continue;
        const v = await patVerdetto(p.abitudine || {}, g);
        if (v === null) continue;
        const esito = v ? 'rispettato' : 'mancato';
        try{
          const r = await patApi('POST', '/api/focuslock/patti/giorno', { id: p.id, giorno: g, esito: esito, dettaglio: v ? 'Fatto, visto dal telefono' : 'Non fatto entro l’ora del patto' });
          inviati[k] = esito; cambiato = true;
          if (!v) toast('Patto mancato ' + patData(g) + ': ' + patEuro((r && r.importo) || p.posta) + (p.destinazione && p.destinazione.tipo === 'beneficenza' ? ' da donare a ' + (p.destinazione.ente || 'l’ente che hai scelto') : ' vanno a ' + (p.garante || 'il tuo garante')));
        }catch(_){ }
      }
    }
    if (cambiato){ patScrivi(PAT_INVIATI_K, inviati); await patCarica(); if (document.getElementById('patBody')) patPaint(); }
    /* il garante: quello che e' successo dall'ultima volta, senza dover chiedere */
    const visti = patJ(PAT_VISTI_K, {}) || {};
    let nuovi = 0, soldi = 0, chi = '';
    lista.forEach(function(p){
      if (p.ruolo !== 'garante') return;
      (p.giorni || []).forEach(function(g){ const k = p.id + '|' + g.giorno; if (g.esito === 'mancato' && !visti[k]){ visti[k] = 1; nuovi++; soldi += g.importo || 0; chi = p.autore; } });
    });
    if (nuovi){ patScrivi(PAT_VISTI_K, visti); toast(chi + ' ha mancato ' + (nuovi === 1 ? 'un giorno' : nuovi + ' giorni') + ' del patto: ' + patEuro(soldi) + (PAT.pagamenti ? ' per te' : ' da ricevere')); }
  } finally { PAT_CONTROLLO = false; }
}
(function(){
  setTimeout(patControllaGiorni, 9000);
  document.addEventListener('visibilitychange', function(){
    if (document.hidden) return;
    setTimeout(patControllaGiorni, 2500);
    /* tornando dalla pagina di Stripe: la carta o il conto si leggono subito */
    if (PAT.attesaPagamento){ const id = PAT.attesaPagamento; PAT.attesaPagamento = 0; patApi('POST', '/api/focuslock/patti/aggiorna-pagamento', { id: id }).then(function(){ return patCarica(); }).then(patPaint).catch(function(){ }); }
  });
  setInterval(patControllaGiorni, 15 * 60000);
  const css = [
    '.pat-intro{margin:4px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.pat-intro b{color:var(--navy)}body.dark .pat-intro b{color:#fff}',
    '.pat-carica{text-align:center;font:600 13px var(--font-body);color:var(--muted)}',
    '.pat-card{display:flex;flex-direction:column;gap:6px;padding:18px 16px;border-radius:22px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:14px}body.dark .pat-card{background:#12203A;border-color:#22345A}',
    '.pat-card.garante{border-color:#E63946}',
    /* il foglio del diario (la carta .dv-carta di diario.js): sta sempre nei suoi colori, anche al buio */
    '.pat-carta,body.dark .pat-carta{background-color:#efe3c6;background-image:radial-gradient(ellipse at 20% 10%,rgba(255,255,255,.35),transparent 55%),radial-gradient(ellipse at 90% 90%,rgba(120,80,30,.16),transparent 50%)}',
    '.pat-carta{position:relative;align-items:center;text-align:center;gap:0;padding:30px 26px 26px;border:0;border-radius:6px 16px 16px 6px;box-shadow:0 14px 30px rgba(0,30,68,.22),inset 0 0 0 1px rgba(0,0,0,.06);margin-bottom:22px}',
    '.pat-carta::before{left:12px}',
    '.pat-carta > *{position:relative;z-index:1}',
    '.pat-carta .pat-eti,.pat-carta.garante .pat-eti{font:700 12px var(--font-body);letter-spacing:.14em;color:#7a6248}',
    '.pat-stato{margin:6px 0 0;font:500 19px/1.2 "Caveat","Segoe Print","Bradley Hand",cursive;color:#b23a3a}',
    '.pat-carta .pat-cosa,body.dark .pat-carta .pat-cosa{margin:20px 0 6px;font:700 28px/1.15 "Caveat","Segoe Print","Bradley Hand",cursive;color:#2b1f14;overflow-wrap:anywhere}',
    '.pat-onda{display:block;width:150px;height:8px;margin:0 auto 22px}',
    '.pat-clausola{width:100%;margin-bottom:22px}.pat-clausola small{display:block;font:700 11.5px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#7a6248}',
    '.pat-clausola p,body.dark .pat-clausola p{margin:6px 0 0;font:500 21px/1.25 "Caveat","Segoe Print","Bradley Hand",cursive;color:#3b2d20}.pat-clausola p b{font-weight:700;color:#b23a3a}',
    '.pat-carta .pat-pals{justify-content:center;margin:10px 0 0}',
    '.pat-carta .pat-soldi,body.dark .pat-carta .pat-soldi{margin:0 0 22px;font:700 21px/1.25 "Caveat","Segoe Print","Bradley Hand",cursive;color:#2b1f14}',
    '.pat-carta .pat-nota,body.dark .pat-carta .pat-nota{margin:0 0 22px;background:rgba(120,80,30,.1);color:#5a4634}',
    '.pat-firme{display:grid;grid-template-columns:1fr 1fr;gap:18px;width:100%;margin:6px 0 24px}.pat-firme i{display:block;min-height:30px;padding-bottom:2px;border-bottom:1.5px solid #5a4634;font:700 24px/1.2 "Caveat","Segoe Print","Bradley Hand",cursive;font-style:normal;color:#2b1f14;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.pat-firme small{display:block;margin-top:5px;font:500 11.5px var(--font-body);color:#7a6248}',
    '.pat-az{display:flex;flex-direction:column;gap:6px;width:100%}.pat-carta .am-link{color:#5a4634}',
    '.pat-eti{font:800 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#0075E3}.pat-card.garante .pat-eti{color:#D63384}',
    '.pat-cosa{font:800 19px/1.3 var(--font-display);color:var(--navy)}body.dark .pat-cosa{color:#fff}',
    '.pat-ver,.pat-posta,.pat-soldi{margin:0;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.pat-posta b{color:#E63946;font-weight:800}.pat-soldi{color:var(--navy);font-weight:700}body.dark .pat-soldi{color:#fff}',
    '.pat-nota{margin:2px 0 0;padding:8px 10px;border-radius:12px;background:var(--bg,#F4F9FF);font:500 12px/1.4 var(--font-body);color:var(--muted)}body.dark .pat-nota{background:#0F1B33}',
    '.pat-pals{display:flex;align-items:center;gap:6px;margin:4px 0}.pat-pals small{margin-left:4px;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.pat-pal{width:16px;height:16px;border-radius:50%;background:var(--line)}.pat-pal.rispettato{background:#0075E3}.pat-pal.mancato{background:#E63946}.pat-pal.nessundato{background:#B9C6DD}',
    '.pat-card .am-cta{margin-top:8px}.pat-nuovo{margin:2px 0 20px}',
    '.pat-sez{margin:6px 4px 10px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.pat-firma-riga{display:flex;align-items:center;gap:12px;width:100%;text-align:left;border:0;background:transparent;padding:14px 4px;border-top:1px solid var(--line);cursor:pointer}.pat-firma-riga > span:first-child{font-size:22px}.pat-firma-riga > span:nth-child(2){flex:1}',
    '.pat-firma-riga b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .pat-firma-riga b{color:#fff}.pat-firma-riga small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.pat-w{display:flex;flex-direction:column;gap:12px}',
    '.pat-q{margin:6px 0 0;font:800 24px/1.25 var(--font-display);color:var(--navy);text-align:center;text-wrap:balance}body.dark .pat-q{color:#fff}',
    '.pat-qs{margin:0 0 6px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}',
    '.pat-esempi{display:flex;flex-wrap:wrap;gap:8px}.pat-esempi button{border:1px dashed var(--line);background:transparent;border-radius:99px;padding:8px 12px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-esempi button{color:#fff}',
    '.pat-ver-l{display:flex;flex-direction:column;gap:8px}.pat-ver-l button{display:flex;align-items:center;gap:12px;text-align:left;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:16px;padding:12px;cursor:pointer}body.dark .pat-ver-l button{background:#12203A;border-color:#22345A}',
    '.pat-ver-l button.on{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4}.pat-ver-l span:first-child{font-size:22px}.pat-ver-l b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .pat-ver-l b{color:#fff}.pat-ver-l small{display:block;font:500 12px/1.35 var(--font-body);color:var(--muted)}',
    '.pat-gg{display:flex;justify-content:space-between;gap:6px}.pat-gg button{flex:1;aspect-ratio:1;border-radius:50%;border:1.5px solid var(--line);background:var(--card,#fff);font:800 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-gg button{background:#12203A;border-color:#22345A;color:#fff}.pat-gg button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.pat-l{font:700 13px var(--font-body);color:var(--navy);margin-top:4px}body.dark .pat-l{color:#fff}',
    '.pat-poste{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.pat-poste button{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;padding:12px 0;font:800 15px var(--font-body);color:var(--navy);cursor:pointer}body.dark .pat-poste button{background:#12203A;border-color:#22345A;color:#fff}.pat-poste button.on{background:#E63946;border-color:#E63946;color:#fff}',
    '.pat-contratto{padding:18px 16px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .pat-contratto{background:#12203A;border-color:#22345A}.pat-contratto p{margin:0 0 10px;font:500 14.5px/1.55 var(--font-body);color:var(--navy)}body.dark .pat-contratto p{color:#fff}.pat-contratto p:last-child{margin:0}',
    '.pat-cod{text-align:center;font:800 22px var(--font-body);letter-spacing:.2em;text-transform:uppercase}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
